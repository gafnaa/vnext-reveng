// lib: , url: package:flutter/src/material/bottom_navigation_bar.dart

// class id: 1048851, size: 0x8
class :: {
}

// class id: 3123, size: 0x1c, field offset: 0x8
class _Circle extends Object {

  late AnimationController controller; // offset: 0x14
}

// class id: 4339, size: 0x14, field offset: 0xc
class _RadialPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0xb763ac, size: 0x70
    // 0xb763ac: EnterFrame
    //     0xb763ac: stp             fp, lr, [SP, #-0x10]!
    //     0xb763b0: mov             fp, SP
    // 0xb763b4: AllocStack(0x10)
    //     0xb763b4: sub             SP, SP, #0x10
    // 0xb763b8: CheckStackOverflow
    //     0xb763b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb763bc: cmp             SP, x16
    //     0xb763c0: b.ls            #0xb76410
    // 0xb763c4: LoadField: r0 = r1->field_b
    //     0xb763c4: ldur            w0, [x1, #0xb]
    // 0xb763c8: DecompressPointer r0
    //     0xb763c8: add             x0, x0, HEAP, lsl #32
    // 0xb763cc: LoadField: r1 = r0->field_b
    //     0xb763cc: ldur            w1, [x0, #0xb]
    // 0xb763d0: r0 = LoadInt32Instr(r1)
    //     0xb763d0: sbfx            x0, x1, #1, #0x1f
    // 0xb763d4: cmp             x0, #0
    // 0xb763d8: b.gt            #0xb763ec
    // 0xb763dc: r0 = Null
    //     0xb763dc: mov             x0, NULL
    // 0xb763e0: LeaveFrame
    //     0xb763e0: mov             SP, fp
    //     0xb763e4: ldp             fp, lr, [SP], #0x10
    // 0xb763e8: ret
    //     0xb763e8: ret             
    // 0xb763ec: r1 = 0
    //     0xb763ec: mov             x1, #0
    // 0xb763f0: cmp             x1, x0
    // 0xb763f4: b.hs            #0xb76418
    // 0xb763f8: r16 = 136
    //     0xb763f8: mov             x16, #0x88
    // 0xb763fc: stp             x16, NULL, [SP]
    // 0xb76400: r0 = ByteData()
    //     0xb76400: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb76404: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xb76404: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xb76408: r0 = Throw()
    //     0xb76408: bl              #0x13ddb2c  ; ThrowStub
    // 0xb7640c: brk             #0
    // 0xb76410: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb76410: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb76414: b               #0xb763c4
    // 0xb76418: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb76418: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xb9330c, size: 0x168
    // 0xb9330c: EnterFrame
    //     0xb9330c: stp             fp, lr, [SP, #-0x10]!
    //     0xb93310: mov             fp, SP
    // 0xb93314: AllocStack(0x10)
    //     0xb93314: sub             SP, SP, #0x10
    // 0xb93318: SetupParameters(_RadialPainter this /* r1 => fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb93318: mov             x0, x2
    //     0xb9331c: mov             x4, x1
    //     0xb93320: mov             x3, x2
    //     0xb93324: stur            x1, [fp, #-8]
    //     0xb93328: stur            x2, [fp, #-0x10]
    //     0xb9332c: mov             x2, NULL
    //     0xb93330: mov             x1, NULL
    //     0xb93334: mov             x4, #0x3c
    // 0xb9332c: r2 = Null
    // 0xb93330: r1 = Null
    // 0xb93334: r4 = 60
    // 0xb93338: branchIfSmi(r0, 0xb93344)
    //     0xb93338: tbz             w0, #0, #0xb93344
    // 0xb9333c: r4 = LoadClassIdInstr(r0)
    //     0xb9333c: ldur            x4, [x0, #-1]
    //     0xb93340: ubfx            x4, x4, #0xc, #0x14
    // 0xb93344: r17 = 4339
    //     0xb93344: mov             x17, #0x10f3
    // 0xb93348: cmp             x4, x17
    // 0xb9334c: b.eq            #0xb93364
    // 0xb93350: r8 = _RadialPainter
    //     0xb93350: add             x8, PP, #0x9a, lsl #12  ; [pp+0x9a538] Type: _RadialPainter
    //     0xb93354: ldr             x8, [x8, #0x538]
    // 0xb93358: r3 = Null
    //     0xb93358: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a540] Null
    //     0xb9335c: ldr             x3, [x3, #0x540]
    // 0xb93360: r0 = DefaultTypeTest()
    //     0xb93360: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb93364: ldur            x2, [fp, #-8]
    // 0xb93368: LoadField: r3 = r2->field_f
    //     0xb93368: ldur            w3, [x2, #0xf]
    // 0xb9336c: DecompressPointer r3
    //     0xb9336c: add             x3, x3, HEAP, lsl #32
    // 0xb93370: ldur            x4, [fp, #-0x10]
    // 0xb93374: LoadField: r5 = r4->field_f
    //     0xb93374: ldur            w5, [x4, #0xf]
    // 0xb93378: DecompressPointer r5
    //     0xb93378: add             x5, x5, HEAP, lsl #32
    // 0xb9337c: cmp             w3, w5
    // 0xb93380: b.eq            #0xb93394
    // 0xb93384: r0 = true
    //     0xb93384: add             x0, NULL, #0x20  ; true
    // 0xb93388: LeaveFrame
    //     0xb93388: mov             SP, fp
    //     0xb9338c: ldp             fp, lr, [SP], #0x10
    // 0xb93390: ret
    //     0xb93390: ret             
    // 0xb93394: LoadField: r3 = r2->field_b
    //     0xb93394: ldur            w3, [x2, #0xb]
    // 0xb93398: DecompressPointer r3
    //     0xb93398: add             x3, x3, HEAP, lsl #32
    // 0xb9339c: LoadField: r2 = r4->field_b
    //     0xb9339c: ldur            w2, [x4, #0xb]
    // 0xb933a0: DecompressPointer r2
    //     0xb933a0: add             x2, x2, HEAP, lsl #32
    // 0xb933a4: cmp             w3, w2
    // 0xb933a8: b.ne            #0xb933bc
    // 0xb933ac: r0 = false
    //     0xb933ac: add             x0, NULL, #0x30  ; false
    // 0xb933b0: LeaveFrame
    //     0xb933b0: mov             SP, fp
    //     0xb933b4: ldp             fp, lr, [SP], #0x10
    // 0xb933b8: ret
    //     0xb933b8: ret             
    // 0xb933bc: LoadField: r4 = r3->field_b
    //     0xb933bc: ldur            w4, [x3, #0xb]
    // 0xb933c0: LoadField: r5 = r2->field_b
    //     0xb933c0: ldur            w5, [x2, #0xb]
    // 0xb933c4: r6 = LoadInt32Instr(r4)
    //     0xb933c4: sbfx            x6, x4, #1, #0x1f
    // 0xb933c8: r7 = LoadInt32Instr(r5)
    //     0xb933c8: sbfx            x7, x5, #1, #0x1f
    // 0xb933cc: cmp             w4, w5
    // 0xb933d0: b.eq            #0xb933e4
    // 0xb933d4: r0 = true
    //     0xb933d4: add             x0, NULL, #0x20  ; true
    // 0xb933d8: LeaveFrame
    //     0xb933d8: mov             SP, fp
    //     0xb933dc: ldp             fp, lr, [SP], #0x10
    // 0xb933e0: ret
    //     0xb933e0: ret             
    // 0xb933e4: LoadField: r4 = r3->field_f
    //     0xb933e4: ldur            w4, [x3, #0xf]
    // 0xb933e8: DecompressPointer r4
    //     0xb933e8: add             x4, x4, HEAP, lsl #32
    // 0xb933ec: LoadField: r3 = r2->field_f
    //     0xb933ec: ldur            w3, [x2, #0xf]
    // 0xb933f0: DecompressPointer r3
    //     0xb933f0: add             x3, x3, HEAP, lsl #32
    // 0xb933f4: r2 = 0
    //     0xb933f4: mov             x2, #0
    // 0xb933f8: CheckStackOverflow
    //     0xb933f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb933fc: cmp             SP, x16
    //     0xb93400: b.ls            #0xb93468
    // 0xb93404: cmp             x2, x6
    // 0xb93408: b.ge            #0xb93458
    // 0xb9340c: ArrayLoad: r5 = r4[r2]  ; Unknown_4
    //     0xb9340c: add             x16, x4, x2, lsl #2
    //     0xb93410: ldur            w5, [x16, #0xf]
    // 0xb93414: DecompressPointer r5
    //     0xb93414: add             x5, x5, HEAP, lsl #32
    // 0xb93418: mov             x0, x7
    // 0xb9341c: mov             x1, x2
    // 0xb93420: cmp             x1, x0
    // 0xb93424: b.hs            #0xb93470
    // 0xb93428: ArrayLoad: r1 = r3[r2]  ; Unknown_4
    //     0xb93428: add             x16, x3, x2, lsl #2
    //     0xb9342c: ldur            w1, [x16, #0xf]
    // 0xb93430: DecompressPointer r1
    //     0xb93430: add             x1, x1, HEAP, lsl #32
    // 0xb93434: cmp             w5, w1
    // 0xb93438: b.ne            #0xb93448
    // 0xb9343c: add             x0, x2, #1
    // 0xb93440: mov             x2, x0
    // 0xb93444: b               #0xb933f8
    // 0xb93448: r0 = true
    //     0xb93448: add             x0, NULL, #0x20  ; true
    // 0xb9344c: LeaveFrame
    //     0xb9344c: mov             SP, fp
    //     0xb93450: ldp             fp, lr, [SP], #0x10
    // 0xb93454: ret
    //     0xb93454: ret             
    // 0xb93458: r0 = false
    //     0xb93458: add             x0, NULL, #0x30  ; false
    // 0xb9345c: LeaveFrame
    //     0xb9345c: mov             SP, fp
    //     0xb93460: ldp             fp, lr, [SP], #0x10
    // 0xb93464: ret
    //     0xb93464: ret             
    // 0xb93468: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb93468: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9346c: b               #0xb93404
    // 0xb93470: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb93470: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 5781, size: 0x2c, field offset: 0x1c
class _BottomNavigationBarState extends _MixinApplication11&State&TickerProviderStateMixin {

  static late final Animatable<double> _flexTween; // offset: 0x5cc

  _ build(/* No info */) {
    // ** addr: 0xd0a23c, size: 0x340
    // 0xd0a23c: EnterFrame
    //     0xd0a23c: stp             fp, lr, [SP, #-0x10]!
    //     0xd0a240: mov             fp, SP
    // 0xd0a244: AllocStack(0x60)
    //     0xd0a244: sub             SP, SP, #0x60
    // 0xd0a248: SetupParameters(_BottomNavigationBarState this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xd0a248: mov             x0, x2
    //     0xd0a24c: stur            x2, [fp, #-0x10]
    //     0xd0a250: mov             x2, x1
    //     0xd0a254: stur            x1, [fp, #-8]
    // 0xd0a258: CheckStackOverflow
    //     0xd0a258: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0a25c: cmp             SP, x16
    //     0xd0a260: b.ls            #0xd0a568
    // 0xd0a264: mov             x1, x0
    // 0xd0a268: r0 = of()
    //     0xd0a268: bl              #0xd0becc  ; [package:flutter/src/material/bottom_navigation_bar_theme.dart] BottomNavigationBarTheme::of
    // 0xd0a26c: mov             x2, x0
    // 0xd0a270: ldur            x0, [fp, #-8]
    // 0xd0a274: stur            x2, [fp, #-0x18]
    // 0xd0a278: LoadField: r1 = r0->field_b
    //     0xd0a278: ldur            w1, [x0, #0xb]
    // 0xd0a27c: DecompressPointer r1
    //     0xd0a27c: add             x1, x1, HEAP, lsl #32
    // 0xd0a280: cmp             w1, NULL
    // 0xd0a284: b.eq            #0xd0a570
    // 0xd0a288: ldur            x1, [fp, #-0x10]
    // 0xd0a28c: r0 = viewPaddingOf()
    //     0xd0a28c: bl              #0xd0be80  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::viewPaddingOf
    // 0xd0a290: LoadField: d0 = r0->field_1f
    //     0xd0a290: ldur            d0, [x0, #0x1f]
    // 0xd0a294: ldur            x1, [fp, #-8]
    // 0xd0a298: stur            d0, [fp, #-0x40]
    // 0xd0a29c: r0 = _effectiveType()
    //     0xd0a29c: bl              #0xd0bddc  ; [package:flutter/src/material/bottom_navigation_bar.dart] _BottomNavigationBarState::_effectiveType
    // 0xd0a2a0: LoadField: r1 = r0->field_7
    //     0xd0a2a0: ldur            x1, [x0, #7]
    // 0xd0a2a4: cmp             x1, #0
    // 0xd0a2a8: b.gt            #0xd0a2cc
    // 0xd0a2ac: ldur            x1, [fp, #-8]
    // 0xd0a2b0: LoadField: r0 = r1->field_b
    //     0xd0a2b0: ldur            w0, [x1, #0xb]
    // 0xd0a2b4: DecompressPointer r0
    //     0xd0a2b4: add             x0, x0, HEAP, lsl #32
    // 0xd0a2b8: cmp             w0, NULL
    // 0xd0a2bc: b.eq            #0xd0a574
    // 0xd0a2c0: LoadField: r2 = r0->field_23
    //     0xd0a2c0: ldur            w2, [x0, #0x23]
    // 0xd0a2c4: DecompressPointer r2
    //     0xd0a2c4: add             x2, x2, HEAP, lsl #32
    // 0xd0a2c8: b               #0xd0a2d4
    // 0xd0a2cc: ldur            x1, [fp, #-8]
    // 0xd0a2d0: r2 = Null
    //     0xd0a2d0: mov             x2, NULL
    // 0xd0a2d4: ldur            x0, [fp, #-0x18]
    // 0xd0a2d8: stur            x2, [fp, #-0x20]
    // 0xd0a2dc: LoadField: r3 = r1->field_b
    //     0xd0a2dc: ldur            w3, [x1, #0xb]
    // 0xd0a2e0: DecompressPointer r3
    //     0xd0a2e0: add             x3, x3, HEAP, lsl #32
    // 0xd0a2e4: cmp             w3, NULL
    // 0xd0a2e8: b.eq            #0xd0a578
    // 0xd0a2ec: LoadField: r3 = r0->field_b
    //     0xd0a2ec: ldur            w3, [x0, #0xb]
    // 0xd0a2f0: DecompressPointer r3
    //     0xd0a2f0: add             x3, x3, HEAP, lsl #32
    // 0xd0a2f4: cmp             w3, NULL
    // 0xd0a2f8: b.ne            #0xd0a304
    // 0xd0a2fc: d2 = 8.000000
    //     0xd0a2fc: fmov            d2, #8.00000000
    // 0xd0a300: b               #0xd0a30c
    // 0xd0a304: LoadField: d0 = r3->field_7
    //     0xd0a304: ldur            d0, [x3, #7]
    // 0xd0a308: mov             v2.16b, v0.16b
    // 0xd0a30c: ldur            d0, [fp, #-0x40]
    // 0xd0a310: d1 = 56.000000
    //     0xd0a310: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a70] IMM: double(56) from 0x404c000000000000
    //     0xd0a314: ldr             d1, [x17, #0xa70]
    // 0xd0a318: stur            d2, [fp, #-0x50]
    // 0xd0a31c: fadd            d3, d0, d1
    // 0xd0a320: stur            d3, [fp, #-0x48]
    // 0xd0a324: r0 = BoxConstraints()
    //     0xd0a324: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xd0a328: stur            x0, [fp, #-0x18]
    // 0xd0a32c: StoreField: r0->field_7 = rZR
    //     0xd0a32c: stur            xzr, [x0, #7]
    // 0xd0a330: d0 = inf
    //     0xd0a330: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xd0a334: StoreField: r0->field_f = d0
    //     0xd0a334: stur            d0, [x0, #0xf]
    // 0xd0a338: ldur            d1, [fp, #-0x48]
    // 0xd0a33c: ArrayStore: r0[0] = d1  ; List_8
    //     0xd0a33c: stur            d1, [x0, #0x17]
    // 0xd0a340: StoreField: r0->field_1f = d0
    //     0xd0a340: stur            d0, [x0, #0x1f]
    // 0xd0a344: ldur            x2, [fp, #-8]
    // 0xd0a348: LoadField: r1 = r2->field_23
    //     0xd0a348: ldur            w1, [x2, #0x23]
    // 0xd0a34c: DecompressPointer r1
    //     0xd0a34c: add             x1, x1, HEAP, lsl #32
    // 0xd0a350: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd0a350: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd0a354: r0 = toList()
    //     0xd0a354: bl              #0xb07ee4  ; [dart:collection] ListQueue::toList
    // 0xd0a358: ldur            x1, [fp, #-0x10]
    // 0xd0a35c: stur            x0, [fp, #-0x28]
    // 0xd0a360: r0 = of()
    //     0xd0a360: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xd0a364: stur            x0, [fp, #-0x30]
    // 0xd0a368: r0 = _RadialPainter()
    //     0xd0a368: bl              #0xd0bdd0  ; Allocate_RadialPainterStub -> _RadialPainter (size=0x14)
    // 0xd0a36c: mov             x1, x0
    // 0xd0a370: ldur            x0, [fp, #-0x28]
    // 0xd0a374: stur            x1, [fp, #-0x38]
    // 0xd0a378: StoreField: r1->field_b = r0
    //     0xd0a378: stur            w0, [x1, #0xb]
    // 0xd0a37c: ldur            x0, [fp, #-0x30]
    // 0xd0a380: StoreField: r1->field_f = r0
    //     0xd0a380: stur            w0, [x1, #0xf]
    // 0xd0a384: r0 = EdgeInsets()
    //     0xd0a384: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xd0a388: stur            x0, [fp, #-0x28]
    // 0xd0a38c: StoreField: r0->field_7 = rZR
    //     0xd0a38c: stur            xzr, [x0, #7]
    // 0xd0a390: StoreField: r0->field_f = rZR
    //     0xd0a390: stur            xzr, [x0, #0xf]
    // 0xd0a394: ArrayStore: r0[0] = rZR  ; List_8
    //     0xd0a394: stur            xzr, [x0, #0x17]
    // 0xd0a398: ldur            d0, [fp, #-0x40]
    // 0xd0a39c: StoreField: r0->field_1f = d0
    //     0xd0a39c: stur            d0, [x0, #0x1f]
    // 0xd0a3a0: ldur            x1, [fp, #-8]
    // 0xd0a3a4: r0 = _createTiles()
    //     0xd0a3a4: bl              #0xd0b178  ; [package:flutter/src/material/bottom_navigation_bar.dart] _BottomNavigationBarState::_createTiles
    // 0xd0a3a8: stur            x0, [fp, #-8]
    // 0xd0a3ac: r0 = Row()
    //     0xd0a3ac: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xd0a3b0: mov             x1, x0
    // 0xd0a3b4: r0 = Instance_Axis
    //     0xd0a3b4: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xd0a3b8: StoreField: r1->field_f = r0
    //     0xd0a3b8: stur            w0, [x1, #0xf]
    // 0xd0a3bc: r0 = Instance_MainAxisAlignment
    //     0xd0a3bc: add             x0, PP, #0x17, lsl #12  ; [pp+0x177b0] Obj!MainAxisAlignment@12c45c1
    //     0xd0a3c0: ldr             x0, [x0, #0x7b0]
    // 0xd0a3c4: StoreField: r1->field_13 = r0
    //     0xd0a3c4: stur            w0, [x1, #0x13]
    // 0xd0a3c8: r0 = Instance_MainAxisSize
    //     0xd0a3c8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xd0a3cc: ldr             x0, [x0, #0x828]
    // 0xd0a3d0: ArrayStore: r1[0] = r0  ; List_4
    //     0xd0a3d0: stur            w0, [x1, #0x17]
    // 0xd0a3d4: r0 = Instance_CrossAxisAlignment
    //     0xd0a3d4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xd0a3d8: ldr             x0, [x0, #0x888]
    // 0xd0a3dc: StoreField: r1->field_1b = r0
    //     0xd0a3dc: stur            w0, [x1, #0x1b]
    // 0xd0a3e0: r0 = Instance_VerticalDirection
    //     0xd0a3e0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xd0a3e4: ldr             x0, [x0, #0x838]
    // 0xd0a3e8: StoreField: r1->field_23 = r0
    //     0xd0a3e8: stur            w0, [x1, #0x23]
    // 0xd0a3ec: r0 = Instance_Clip
    //     0xd0a3ec: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xd0a3f0: ldr             x0, [x0, #0x840]
    // 0xd0a3f4: StoreField: r1->field_2b = r0
    //     0xd0a3f4: stur            w0, [x1, #0x2b]
    // 0xd0a3f8: StoreField: r1->field_2f = rZR
    //     0xd0a3f8: stur            xzr, [x1, #0x2f]
    // 0xd0a3fc: ldur            x2, [fp, #-8]
    // 0xd0a400: StoreField: r1->field_b = r2
    //     0xd0a400: stur            w2, [x1, #0xb]
    // 0xd0a404: r16 = Instance_TextOverflow
    //     0xd0a404: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1ac18] Obj!TextOverflow@12c47a1
    //     0xd0a408: ldr             x16, [x16, #0xc18]
    // 0xd0a40c: str             x16, [SP]
    // 0xd0a410: r4 = const [0, 0x2, 0x1, 0x1, overflow, 0x1, null]
    //     0xd0a410: add             x4, PP, #0x89, lsl #12  ; [pp+0x89f68] List(7) [0, 0x2, 0x1, 0x1, "overflow", 0x1, Null]
    //     0xd0a414: ldr             x4, [x4, #0xf68]
    // 0xd0a418: r0 = merge()
    //     0xd0a418: bl              #0xd0af30  ; [package:flutter/src/widgets/text.dart] DefaultTextStyle::merge
    // 0xd0a41c: r1 = <_MediaQueryAspect>
    //     0xd0a41c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12828] TypeArguments: <_MediaQueryAspect>
    //     0xd0a420: ldr             x1, [x1, #0x828]
    // 0xd0a424: stur            x0, [fp, #-8]
    // 0xd0a428: r0 = MediaQuery()
    //     0xd0a428: bl              #0xd0af24  ; AllocateMediaQueryStub -> MediaQuery (size=0x18)
    // 0xd0a42c: stur            x0, [fp, #-0x30]
    // 0xd0a430: r16 = true
    //     0xd0a430: add             x16, NULL, #0x20  ; true
    // 0xd0a434: str             x16, [SP]
    // 0xd0a438: mov             x1, x0
    // 0xd0a43c: ldur            x2, [fp, #-8]
    // 0xd0a440: ldur            x3, [fp, #-0x10]
    // 0xd0a444: r4 = const [0, 0x4, 0x1, 0x3, removeBottom, 0x3, null]
    //     0xd0a444: add             x4, PP, #0x90, lsl #12  ; [pp+0x909c0] List(7) [0, 0x4, 0x1, 0x3, "removeBottom", 0x3, Null]
    //     0xd0a448: ldr             x4, [x4, #0x9c0]
    // 0xd0a44c: r0 = MediaQuery.removePadding()
    //     0xd0a44c: bl              #0xd0a5a0  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::MediaQuery.removePadding
    // 0xd0a450: r0 = Padding()
    //     0xd0a450: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xd0a454: mov             x1, x0
    // 0xd0a458: ldur            x0, [fp, #-0x28]
    // 0xd0a45c: stur            x1, [fp, #-8]
    // 0xd0a460: StoreField: r1->field_f = r0
    //     0xd0a460: stur            w0, [x1, #0xf]
    // 0xd0a464: ldur            x0, [fp, #-0x30]
    // 0xd0a468: StoreField: r1->field_b = r0
    //     0xd0a468: stur            w0, [x1, #0xb]
    // 0xd0a46c: r0 = Material()
    //     0xd0a46c: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xd0a470: mov             x1, x0
    // 0xd0a474: r0 = Instance_MaterialType
    //     0xd0a474: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8c618] Obj!MaterialType@12c5361
    //     0xd0a478: ldr             x0, [x0, #0x618]
    // 0xd0a47c: stur            x1, [fp, #-0x10]
    // 0xd0a480: StoreField: r1->field_f = r0
    //     0xd0a480: stur            w0, [x1, #0xf]
    // 0xd0a484: ArrayStore: r1[0] = rZR  ; List_8
    //     0xd0a484: stur            xzr, [x1, #0x17]
    // 0xd0a488: r0 = true
    //     0xd0a488: add             x0, NULL, #0x20  ; true
    // 0xd0a48c: StoreField: r1->field_33 = r0
    //     0xd0a48c: stur            w0, [x1, #0x33]
    // 0xd0a490: r0 = Instance_Clip
    //     0xd0a490: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xd0a494: ldr             x0, [x0, #0x840]
    // 0xd0a498: StoreField: r1->field_37 = r0
    //     0xd0a498: stur            w0, [x1, #0x37]
    // 0xd0a49c: r0 = Instance_Duration
    //     0xd0a49c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xd0a4a0: ldr             x0, [x0, #0x318]
    // 0xd0a4a4: StoreField: r1->field_3b = r0
    //     0xd0a4a4: stur            w0, [x1, #0x3b]
    // 0xd0a4a8: ldur            x0, [fp, #-8]
    // 0xd0a4ac: StoreField: r1->field_b = r0
    //     0xd0a4ac: stur            w0, [x1, #0xb]
    // 0xd0a4b0: r0 = false
    //     0xd0a4b0: add             x0, NULL, #0x30  ; false
    // 0xd0a4b4: StoreField: r1->field_13 = r0
    //     0xd0a4b4: stur            w0, [x1, #0x13]
    // 0xd0a4b8: r0 = CustomPaint()
    //     0xd0a4b8: bl              #0xd0a594  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0xd0a4bc: mov             x1, x0
    // 0xd0a4c0: ldur            x0, [fp, #-0x38]
    // 0xd0a4c4: stur            x1, [fp, #-8]
    // 0xd0a4c8: StoreField: r1->field_f = r0
    //     0xd0a4c8: stur            w0, [x1, #0xf]
    // 0xd0a4cc: r0 = Instance_Size
    //     0xd0a4cc: ldr             x0, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xd0a4d0: ArrayStore: r1[0] = r0  ; List_4
    //     0xd0a4d0: stur            w0, [x1, #0x17]
    // 0xd0a4d4: r0 = false
    //     0xd0a4d4: add             x0, NULL, #0x30  ; false
    // 0xd0a4d8: StoreField: r1->field_1b = r0
    //     0xd0a4d8: stur            w0, [x1, #0x1b]
    // 0xd0a4dc: StoreField: r1->field_1f = r0
    //     0xd0a4dc: stur            w0, [x1, #0x1f]
    // 0xd0a4e0: ldur            x0, [fp, #-0x10]
    // 0xd0a4e4: StoreField: r1->field_b = r0
    //     0xd0a4e4: stur            w0, [x1, #0xb]
    // 0xd0a4e8: r0 = ConstrainedBox()
    //     0xd0a4e8: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xd0a4ec: mov             x1, x0
    // 0xd0a4f0: ldur            x0, [fp, #-0x18]
    // 0xd0a4f4: stur            x1, [fp, #-0x10]
    // 0xd0a4f8: StoreField: r1->field_f = r0
    //     0xd0a4f8: stur            w0, [x1, #0xf]
    // 0xd0a4fc: ldur            x0, [fp, #-8]
    // 0xd0a500: StoreField: r1->field_b = r0
    //     0xd0a500: stur            w0, [x1, #0xb]
    // 0xd0a504: r0 = _Bar()
    //     0xd0a504: bl              #0xd0a57c  ; Allocate_BarStub -> _Bar (size=0x20)
    // 0xd0a508: mov             x1, x0
    // 0xd0a50c: ldur            x0, [fp, #-0x10]
    // 0xd0a510: stur            x1, [fp, #-8]
    // 0xd0a514: StoreField: r1->field_b = r0
    //     0xd0a514: stur            w0, [x1, #0xb]
    // 0xd0a518: r0 = Instance_BottomNavigationBarLandscapeLayout
    //     0xd0a518: add             x0, PP, #0x90, lsl #12  ; [pp+0x909c8] Obj!BottomNavigationBarLandscapeLayout@12c59a1
    //     0xd0a51c: ldr             x0, [x0, #0x9c8]
    // 0xd0a520: StoreField: r1->field_f = r0
    //     0xd0a520: stur            w0, [x1, #0xf]
    // 0xd0a524: ldur            d0, [fp, #-0x50]
    // 0xd0a528: StoreField: r1->field_13 = d0
    //     0xd0a528: stur            d0, [x1, #0x13]
    // 0xd0a52c: ldur            x0, [fp, #-0x20]
    // 0xd0a530: StoreField: r1->field_1b = r0
    //     0xd0a530: stur            w0, [x1, #0x1b]
    // 0xd0a534: r0 = Semantics()
    //     0xd0a534: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xd0a538: stur            x0, [fp, #-0x10]
    // 0xd0a53c: r16 = true
    //     0xd0a53c: add             x16, NULL, #0x20  ; true
    // 0xd0a540: ldur            lr, [fp, #-8]
    // 0xd0a544: stp             lr, x16, [SP]
    // 0xd0a548: mov             x1, x0
    // 0xd0a54c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, explicitChildNodes, 0x1, null]
    //     0xd0a54c: add             x4, PP, #0x80, lsl #12  ; [pp+0x80e48] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "explicitChildNodes", 0x1, Null]
    //     0xd0a550: ldr             x4, [x4, #0xe48]
    // 0xd0a554: r0 = Semantics()
    //     0xd0a554: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xd0a558: ldur            x0, [fp, #-0x10]
    // 0xd0a55c: LeaveFrame
    //     0xd0a55c: mov             SP, fp
    //     0xd0a560: ldp             fp, lr, [SP], #0x10
    // 0xd0a564: ret
    //     0xd0a564: ret             
    // 0xd0a568: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0a568: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0a56c: b               #0xd0a264
    // 0xd0a570: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0a570: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0a574: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0a574: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0a578: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0a578: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _createTiles(/* No info */) {
    // ** addr: 0xd0b178, size: 0x90c
    // 0xd0b178: EnterFrame
    //     0xd0b178: stp             fp, lr, [SP, #-0x10]!
    //     0xd0b17c: mov             fp, SP
    // 0xd0b180: AllocStack(0x98)
    //     0xd0b180: sub             SP, SP, #0x98
    // 0xd0b184: SetupParameters(_BottomNavigationBarState this /* r1 => r1, fp-0x8 */)
    //     0xd0b184: stur            x1, [fp, #-8]
    // 0xd0b188: CheckStackOverflow
    //     0xd0b188: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0b18c: cmp             SP, x16
    //     0xd0b190: b.ls            #0xd0ba10
    // 0xd0b194: r1 = 1
    //     0xd0b194: mov             x1, #1
    // 0xd0b198: r0 = AllocateContext()
    //     0xd0b198: bl              #0x13de838  ; AllocateContextStub
    // 0xd0b19c: mov             x2, x0
    // 0xd0b1a0: ldur            x0, [fp, #-8]
    // 0xd0b1a4: stur            x2, [fp, #-0x10]
    // 0xd0b1a8: StoreField: r2->field_f = r0
    //     0xd0b1a8: stur            w0, [x2, #0xf]
    // 0xd0b1ac: LoadField: r1 = r0->field_f
    //     0xd0b1ac: ldur            w1, [x0, #0xf]
    // 0xd0b1b0: DecompressPointer r1
    //     0xd0b1b0: add             x1, x1, HEAP, lsl #32
    // 0xd0b1b4: cmp             w1, NULL
    // 0xd0b1b8: b.eq            #0xd0ba18
    // 0xd0b1bc: r0 = of()
    //     0xd0b1bc: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xd0b1c0: mov             x2, x0
    // 0xd0b1c4: ldur            x0, [fp, #-8]
    // 0xd0b1c8: stur            x2, [fp, #-0x18]
    // 0xd0b1cc: LoadField: r1 = r0->field_f
    //     0xd0b1cc: ldur            w1, [x0, #0xf]
    // 0xd0b1d0: DecompressPointer r1
    //     0xd0b1d0: add             x1, x1, HEAP, lsl #32
    // 0xd0b1d4: cmp             w1, NULL
    // 0xd0b1d8: b.eq            #0xd0ba1c
    // 0xd0b1dc: r0 = of()
    //     0xd0b1dc: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd0b1e0: ldur            x0, [fp, #-8]
    // 0xd0b1e4: LoadField: r1 = r0->field_f
    //     0xd0b1e4: ldur            w1, [x0, #0xf]
    // 0xd0b1e8: DecompressPointer r1
    //     0xd0b1e8: add             x1, x1, HEAP, lsl #32
    // 0xd0b1ec: cmp             w1, NULL
    // 0xd0b1f0: b.eq            #0xd0ba20
    // 0xd0b1f4: r0 = of()
    //     0xd0b1f4: bl              #0xd0becc  ; [package:flutter/src/material/bottom_navigation_bar_theme.dart] BottomNavigationBarTheme::of
    // 0xd0b1f8: mov             x2, x0
    // 0xd0b1fc: ldur            x0, [fp, #-8]
    // 0xd0b200: stur            x2, [fp, #-0x20]
    // 0xd0b204: LoadField: r1 = r0->field_b
    //     0xd0b204: ldur            w1, [x0, #0xb]
    // 0xd0b208: DecompressPointer r1
    //     0xd0b208: add             x1, x1, HEAP, lsl #32
    // 0xd0b20c: cmp             w1, NULL
    // 0xd0b210: b.eq            #0xd0ba24
    // 0xd0b214: LoadField: r3 = r1->field_3f
    //     0xd0b214: ldur            w3, [x1, #0x3f]
    // 0xd0b218: DecompressPointer r3
    //     0xd0b218: add             x3, x3, HEAP, lsl #32
    // 0xd0b21c: mov             x1, x3
    // 0xd0b220: d0 = 14.000000
    //     0xd0b220: fmov            d0, #14.00000000
    // 0xd0b224: r0 = _effectiveTextStyle()
    //     0xd0b224: bl              #0xd0bb60  ; [package:flutter/src/material/bottom_navigation_bar.dart] _BottomNavigationBarState::_effectiveTextStyle
    // 0xd0b228: mov             x2, x0
    // 0xd0b22c: ldur            x0, [fp, #-8]
    // 0xd0b230: stur            x2, [fp, #-0x28]
    // 0xd0b234: LoadField: r1 = r0->field_b
    //     0xd0b234: ldur            w1, [x0, #0xb]
    // 0xd0b238: DecompressPointer r1
    //     0xd0b238: add             x1, x1, HEAP, lsl #32
    // 0xd0b23c: cmp             w1, NULL
    // 0xd0b240: b.eq            #0xd0ba28
    // 0xd0b244: LoadField: r3 = r1->field_43
    //     0xd0b244: ldur            w3, [x1, #0x43]
    // 0xd0b248: DecompressPointer r3
    //     0xd0b248: add             x3, x3, HEAP, lsl #32
    // 0xd0b24c: mov             x1, x3
    // 0xd0b250: d0 = 12.000000
    //     0xd0b250: fmov            d0, #12.00000000
    // 0xd0b254: r0 = _effectiveTextStyle()
    //     0xd0b254: bl              #0xd0bb60  ; [package:flutter/src/material/bottom_navigation_bar.dart] _BottomNavigationBarState::_effectiveTextStyle
    // 0xd0b258: mov             x3, x0
    // 0xd0b25c: ldur            x0, [fp, #-8]
    // 0xd0b260: stur            x3, [fp, #-0x38]
    // 0xd0b264: LoadField: r1 = r0->field_b
    //     0xd0b264: ldur            w1, [x0, #0xb]
    // 0xd0b268: DecompressPointer r1
    //     0xd0b268: add             x1, x1, HEAP, lsl #32
    // 0xd0b26c: cmp             w1, NULL
    // 0xd0b270: b.eq            #0xd0ba2c
    // 0xd0b274: ldur            x4, [fp, #-0x20]
    // 0xd0b278: LoadField: r5 = r4->field_f
    //     0xd0b278: ldur            w5, [x4, #0xf]
    // 0xd0b27c: DecompressPointer r5
    //     0xd0b27c: add             x5, x5, HEAP, lsl #32
    // 0xd0b280: stur            x5, [fp, #-0x30]
    // 0xd0b284: LoadField: r2 = r1->field_2f
    //     0xd0b284: ldur            w2, [x1, #0x2f]
    // 0xd0b288: DecompressPointer r2
    //     0xd0b288: add             x2, x2, HEAP, lsl #32
    // 0xd0b28c: mov             x1, x5
    // 0xd0b290: r0 = _effectiveIconTheme()
    //     0xd0b290: bl              #0xd0bb28  ; [package:flutter/src/material/bottom_navigation_bar.dart] _BottomNavigationBarState::_effectiveIconTheme
    // 0xd0b294: mov             x3, x0
    // 0xd0b298: ldur            x0, [fp, #-8]
    // 0xd0b29c: stur            x3, [fp, #-0x48]
    // 0xd0b2a0: LoadField: r1 = r0->field_b
    //     0xd0b2a0: ldur            w1, [x0, #0xb]
    // 0xd0b2a4: DecompressPointer r1
    //     0xd0b2a4: add             x1, x1, HEAP, lsl #32
    // 0xd0b2a8: cmp             w1, NULL
    // 0xd0b2ac: b.eq            #0xd0ba30
    // 0xd0b2b0: ldur            x2, [fp, #-0x20]
    // 0xd0b2b4: LoadField: r4 = r2->field_13
    //     0xd0b2b4: ldur            w4, [x2, #0x13]
    // 0xd0b2b8: DecompressPointer r4
    //     0xd0b2b8: add             x4, x4, HEAP, lsl #32
    // 0xd0b2bc: stur            x4, [fp, #-0x40]
    // 0xd0b2c0: LoadField: r2 = r1->field_33
    //     0xd0b2c0: ldur            w2, [x1, #0x33]
    // 0xd0b2c4: DecompressPointer r2
    //     0xd0b2c4: add             x2, x2, HEAP, lsl #32
    // 0xd0b2c8: mov             x1, x4
    // 0xd0b2cc: r0 = _effectiveIconTheme()
    //     0xd0b2cc: bl              #0xd0bb28  ; [package:flutter/src/material/bottom_navigation_bar.dart] _BottomNavigationBarState::_effectiveIconTheme
    // 0xd0b2d0: ldur            x1, [fp, #-8]
    // 0xd0b2d4: stur            x0, [fp, #-0x20]
    // 0xd0b2d8: r0 = _effectiveType()
    //     0xd0b2d8: bl              #0xd0bddc  ; [package:flutter/src/material/bottom_navigation_bar.dart] _BottomNavigationBarState::_effectiveType
    // 0xd0b2dc: LoadField: r1 = r0->field_7
    //     0xd0b2dc: ldur            x1, [x0, #7]
    // 0xd0b2e0: cmp             x1, #0
    // 0xd0b2e4: b.gt            #0xd0b33c
    // 0xd0b2e8: ldur            x0, [fp, #-8]
    // 0xd0b2ec: LoadField: r1 = r0->field_b
    //     0xd0b2ec: ldur            w1, [x0, #0xb]
    // 0xd0b2f0: DecompressPointer r1
    //     0xd0b2f0: add             x1, x1, HEAP, lsl #32
    // 0xd0b2f4: cmp             w1, NULL
    // 0xd0b2f8: b.eq            #0xd0ba34
    // 0xd0b2fc: LoadField: r2 = r1->field_33
    //     0xd0b2fc: ldur            w2, [x1, #0x33]
    // 0xd0b300: DecompressPointer r2
    //     0xd0b300: add             x2, x2, HEAP, lsl #32
    // 0xd0b304: stur            x2, [fp, #-0x58]
    // 0xd0b308: LoadField: r3 = r1->field_2f
    //     0xd0b308: ldur            w3, [x1, #0x2f]
    // 0xd0b30c: DecompressPointer r3
    //     0xd0b30c: add             x3, x3, HEAP, lsl #32
    // 0xd0b310: stur            x3, [fp, #-0x50]
    // 0xd0b314: r1 = <Color?>
    //     0xd0b314: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd0b318: ldr             x1, [x1, #0xa40]
    // 0xd0b31c: r0 = ColorTween()
    //     0xd0b31c: bl              #0x915f2c  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0xd0b320: mov             x1, x0
    // 0xd0b324: ldur            x0, [fp, #-0x58]
    // 0xd0b328: StoreField: r1->field_b = r0
    //     0xd0b328: stur            w0, [x1, #0xb]
    // 0xd0b32c: ldur            x0, [fp, #-0x50]
    // 0xd0b330: StoreField: r1->field_f = r0
    //     0xd0b330: stur            w0, [x1, #0xf]
    // 0xd0b334: mov             x0, x1
    // 0xd0b338: b               #0xd0b38c
    // 0xd0b33c: ldur            x0, [fp, #-8]
    // 0xd0b340: LoadField: r1 = r0->field_b
    //     0xd0b340: ldur            w1, [x0, #0xb]
    // 0xd0b344: DecompressPointer r1
    //     0xd0b344: add             x1, x1, HEAP, lsl #32
    // 0xd0b348: cmp             w1, NULL
    // 0xd0b34c: b.eq            #0xd0ba38
    // 0xd0b350: LoadField: r2 = r1->field_33
    //     0xd0b350: ldur            w2, [x1, #0x33]
    // 0xd0b354: DecompressPointer r2
    //     0xd0b354: add             x2, x2, HEAP, lsl #32
    // 0xd0b358: stur            x2, [fp, #-0x58]
    // 0xd0b35c: LoadField: r3 = r1->field_2f
    //     0xd0b35c: ldur            w3, [x1, #0x2f]
    // 0xd0b360: DecompressPointer r3
    //     0xd0b360: add             x3, x3, HEAP, lsl #32
    // 0xd0b364: stur            x3, [fp, #-0x50]
    // 0xd0b368: r1 = <Color?>
    //     0xd0b368: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd0b36c: ldr             x1, [x1, #0xa40]
    // 0xd0b370: r0 = ColorTween()
    //     0xd0b370: bl              #0x915f2c  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0xd0b374: mov             x1, x0
    // 0xd0b378: ldur            x0, [fp, #-0x58]
    // 0xd0b37c: StoreField: r1->field_b = r0
    //     0xd0b37c: stur            w0, [x1, #0xb]
    // 0xd0b380: ldur            x0, [fp, #-0x50]
    // 0xd0b384: StoreField: r1->field_f = r0
    //     0xd0b384: stur            w0, [x1, #0xf]
    // 0xd0b388: mov             x0, x1
    // 0xd0b38c: ldur            x1, [fp, #-8]
    // 0xd0b390: stur            x0, [fp, #-0x50]
    // 0xd0b394: r0 = _effectiveType()
    //     0xd0b394: bl              #0xd0bddc  ; [package:flutter/src/material/bottom_navigation_bar.dart] _BottomNavigationBarState::_effectiveType
    // 0xd0b398: LoadField: r1 = r0->field_7
    //     0xd0b398: ldur            x1, [x0, #7]
    // 0xd0b39c: cmp             x1, #0
    // 0xd0b3a0: b.gt            #0xd0b3fc
    // 0xd0b3a4: ldur            x0, [fp, #-0x38]
    // 0xd0b3a8: LoadField: r1 = r0->field_b
    //     0xd0b3a8: ldur            w1, [x0, #0xb]
    // 0xd0b3ac: DecompressPointer r1
    //     0xd0b3ac: add             x1, x1, HEAP, lsl #32
    // 0xd0b3b0: cmp             w1, NULL
    // 0xd0b3b4: b.ne            #0xd0b3d0
    // 0xd0b3b8: ldur            x2, [fp, #-8]
    // 0xd0b3bc: LoadField: r1 = r2->field_b
    //     0xd0b3bc: ldur            w1, [x2, #0xb]
    // 0xd0b3c0: DecompressPointer r1
    //     0xd0b3c0: add             x1, x1, HEAP, lsl #32
    // 0xd0b3c4: cmp             w1, NULL
    // 0xd0b3c8: b.eq            #0xd0ba3c
    // 0xd0b3cc: b               #0xd0b3d4
    // 0xd0b3d0: ldur            x2, [fp, #-8]
    // 0xd0b3d4: ldur            x3, [fp, #-0x28]
    // 0xd0b3d8: LoadField: r1 = r3->field_b
    //     0xd0b3d8: ldur            w1, [x3, #0xb]
    // 0xd0b3dc: DecompressPointer r1
    //     0xd0b3dc: add             x1, x1, HEAP, lsl #32
    // 0xd0b3e0: cmp             w1, NULL
    // 0xd0b3e4: b.ne            #0xd0b448
    // 0xd0b3e8: LoadField: r1 = r2->field_b
    //     0xd0b3e8: ldur            w1, [x2, #0xb]
    // 0xd0b3ec: DecompressPointer r1
    //     0xd0b3ec: add             x1, x1, HEAP, lsl #32
    // 0xd0b3f0: cmp             w1, NULL
    // 0xd0b3f4: b.eq            #0xd0ba40
    // 0xd0b3f8: b               #0xd0b448
    // 0xd0b3fc: ldur            x2, [fp, #-8]
    // 0xd0b400: ldur            x3, [fp, #-0x28]
    // 0xd0b404: ldur            x0, [fp, #-0x38]
    // 0xd0b408: LoadField: r1 = r0->field_b
    //     0xd0b408: ldur            w1, [x0, #0xb]
    // 0xd0b40c: DecompressPointer r1
    //     0xd0b40c: add             x1, x1, HEAP, lsl #32
    // 0xd0b410: cmp             w1, NULL
    // 0xd0b414: b.ne            #0xd0b428
    // 0xd0b418: LoadField: r1 = r2->field_b
    //     0xd0b418: ldur            w1, [x2, #0xb]
    // 0xd0b41c: DecompressPointer r1
    //     0xd0b41c: add             x1, x1, HEAP, lsl #32
    // 0xd0b420: cmp             w1, NULL
    // 0xd0b424: b.eq            #0xd0ba44
    // 0xd0b428: LoadField: r1 = r3->field_b
    //     0xd0b428: ldur            w1, [x3, #0xb]
    // 0xd0b42c: DecompressPointer r1
    //     0xd0b42c: add             x1, x1, HEAP, lsl #32
    // 0xd0b430: cmp             w1, NULL
    // 0xd0b434: b.ne            #0xd0b448
    // 0xd0b438: LoadField: r1 = r2->field_b
    //     0xd0b438: ldur            w1, [x2, #0xb]
    // 0xd0b43c: DecompressPointer r1
    //     0xd0b43c: add             x1, x1, HEAP, lsl #32
    // 0xd0b440: cmp             w1, NULL
    // 0xd0b444: b.eq            #0xd0ba48
    // 0xd0b448: mov             x1, x2
    // 0xd0b44c: r0 = _effectiveType()
    //     0xd0b44c: bl              #0xd0bddc  ; [package:flutter/src/material/bottom_navigation_bar.dart] _BottomNavigationBarState::_effectiveType
    // 0xd0b450: LoadField: r1 = r0->field_7
    //     0xd0b450: ldur            x1, [x0, #7]
    // 0xd0b454: cmp             x1, #0
    // 0xd0b458: b.gt            #0xd0b4b4
    // 0xd0b45c: ldur            x0, [fp, #-0x48]
    // 0xd0b460: LoadField: r1 = r0->field_1b
    //     0xd0b460: ldur            w1, [x0, #0x1b]
    // 0xd0b464: DecompressPointer r1
    //     0xd0b464: add             x1, x1, HEAP, lsl #32
    // 0xd0b468: cmp             w1, NULL
    // 0xd0b46c: b.ne            #0xd0b488
    // 0xd0b470: ldur            x3, [fp, #-8]
    // 0xd0b474: LoadField: r0 = r3->field_b
    //     0xd0b474: ldur            w0, [x3, #0xb]
    // 0xd0b478: DecompressPointer r0
    //     0xd0b478: add             x0, x0, HEAP, lsl #32
    // 0xd0b47c: cmp             w0, NULL
    // 0xd0b480: b.eq            #0xd0ba4c
    // 0xd0b484: b               #0xd0b48c
    // 0xd0b488: ldur            x3, [fp, #-8]
    // 0xd0b48c: ldur            x1, [fp, #-0x20]
    // 0xd0b490: LoadField: r0 = r1->field_1b
    //     0xd0b490: ldur            w0, [x1, #0x1b]
    // 0xd0b494: DecompressPointer r0
    //     0xd0b494: add             x0, x0, HEAP, lsl #32
    // 0xd0b498: cmp             w0, NULL
    // 0xd0b49c: b.ne            #0xd0b500
    // 0xd0b4a0: LoadField: r0 = r3->field_b
    //     0xd0b4a0: ldur            w0, [x3, #0xb]
    // 0xd0b4a4: DecompressPointer r0
    //     0xd0b4a4: add             x0, x0, HEAP, lsl #32
    // 0xd0b4a8: cmp             w0, NULL
    // 0xd0b4ac: b.eq            #0xd0ba50
    // 0xd0b4b0: b               #0xd0b500
    // 0xd0b4b4: ldur            x3, [fp, #-8]
    // 0xd0b4b8: ldur            x0, [fp, #-0x48]
    // 0xd0b4bc: ldur            x1, [fp, #-0x20]
    // 0xd0b4c0: LoadField: r2 = r1->field_1b
    //     0xd0b4c0: ldur            w2, [x1, #0x1b]
    // 0xd0b4c4: DecompressPointer r2
    //     0xd0b4c4: add             x2, x2, HEAP, lsl #32
    // 0xd0b4c8: cmp             w2, NULL
    // 0xd0b4cc: b.ne            #0xd0b4e0
    // 0xd0b4d0: LoadField: r1 = r3->field_b
    //     0xd0b4d0: ldur            w1, [x3, #0xb]
    // 0xd0b4d4: DecompressPointer r1
    //     0xd0b4d4: add             x1, x1, HEAP, lsl #32
    // 0xd0b4d8: cmp             w1, NULL
    // 0xd0b4dc: b.eq            #0xd0ba54
    // 0xd0b4e0: LoadField: r1 = r0->field_1b
    //     0xd0b4e0: ldur            w1, [x0, #0x1b]
    // 0xd0b4e4: DecompressPointer r1
    //     0xd0b4e4: add             x1, x1, HEAP, lsl #32
    // 0xd0b4e8: cmp             w1, NULL
    // 0xd0b4ec: b.ne            #0xd0b500
    // 0xd0b4f0: LoadField: r0 = r3->field_b
    //     0xd0b4f0: ldur            w0, [x3, #0xb]
    // 0xd0b4f4: DecompressPointer r0
    //     0xd0b4f4: add             x0, x0, HEAP, lsl #32
    // 0xd0b4f8: cmp             w0, NULL
    // 0xd0b4fc: b.eq            #0xd0ba58
    // 0xd0b500: ldur            x0, [fp, #-0x10]
    // 0xd0b504: r1 = <Widget>
    //     0xd0b504: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd0b508: r2 = 0
    //     0xd0b508: mov             x2, #0
    // 0xd0b50c: r0 = _GrowableList()
    //     0xd0b50c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd0b510: stur            x0, [fp, #-0x20]
    // 0xd0b514: r1 = 1
    //     0xd0b514: mov             x1, #1
    // 0xd0b518: r0 = AllocateContext()
    //     0xd0b518: bl              #0x13de838  ; AllocateContextStub
    // 0xd0b51c: mov             x1, x0
    // 0xd0b520: ldur            x0, [fp, #-0x10]
    // 0xd0b524: StoreField: r1->field_b = r0
    //     0xd0b524: stur            w0, [x1, #0xb]
    // 0xd0b528: StoreField: r1->field_f = rZR
    //     0xd0b528: stur            wzr, [x1, #0xf]
    // 0xd0b52c: mov             x10, x1
    // 0xd0b530: r9 = 0
    //     0xd0b530: mov             x9, #0
    // 0xd0b534: ldur            x2, [fp, #-8]
    // 0xd0b538: ldur            x8, [fp, #-0x18]
    // 0xd0b53c: ldur            x4, [fp, #-0x28]
    // 0xd0b540: ldur            x3, [fp, #-0x38]
    // 0xd0b544: ldur            x7, [fp, #-0x30]
    // 0xd0b548: ldur            x6, [fp, #-0x40]
    // 0xd0b54c: ldur            x5, [fp, #-0x50]
    // 0xd0b550: ldur            x0, [fp, #-0x20]
    // 0xd0b554: stur            x10, [fp, #-0x48]
    // 0xd0b558: stur            x9, [fp, #-0x60]
    // 0xd0b55c: CheckStackOverflow
    //     0xd0b55c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0b560: cmp             SP, x16
    //     0xd0b564: b.ls            #0xd0ba5c
    // 0xd0b568: LoadField: r11 = r2->field_b
    //     0xd0b568: ldur            w11, [x2, #0xb]
    // 0xd0b56c: DecompressPointer r11
    //     0xd0b56c: add             x11, x11, HEAP, lsl #32
    // 0xd0b570: stur            x11, [fp, #-0x10]
    // 0xd0b574: cmp             w11, NULL
    // 0xd0b578: b.eq            #0xd0ba64
    // 0xd0b57c: LoadField: r1 = r11->field_b
    //     0xd0b57c: ldur            w1, [x11, #0xb]
    // 0xd0b580: DecompressPointer r1
    //     0xd0b580: add             x1, x1, HEAP, lsl #32
    // 0xd0b584: LoadField: r12 = r1->field_b
    //     0xd0b584: ldur            w12, [x1, #0xb]
    // 0xd0b588: r1 = LoadInt32Instr(r12)
    //     0xd0b588: sbfx            x1, x12, #1, #0x1f
    // 0xd0b58c: cmp             x9, x1
    // 0xd0b590: b.ge            #0xd0ba00
    // 0xd0b594: r1 = <WidgetState>
    //     0xd0b594: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a10] TypeArguments: <WidgetState>
    //     0xd0b598: ldr             x1, [x1, #0xa10]
    // 0xd0b59c: r0 = _Set()
    //     0xd0b59c: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xd0b5a0: mov             x1, x0
    // 0xd0b5a4: r0 = _Uint32List
    //     0xd0b5a4: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0xd0b5a8: stur            x1, [fp, #-0x58]
    // 0xd0b5ac: StoreField: r1->field_1b = r0
    //     0xd0b5ac: stur            w0, [x1, #0x1b]
    // 0xd0b5b0: StoreField: r1->field_b = rZR
    //     0xd0b5b0: stur            wzr, [x1, #0xb]
    // 0xd0b5b4: r2 = const []
    //     0xd0b5b4: ldr             x2, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0xd0b5b8: StoreField: r1->field_f = r2
    //     0xd0b5b8: stur            w2, [x1, #0xf]
    // 0xd0b5bc: StoreField: r1->field_13 = rZR
    //     0xd0b5bc: stur            wzr, [x1, #0x13]
    // 0xd0b5c0: ArrayStore: r1[0] = rZR  ; List_4
    //     0xd0b5c0: stur            wzr, [x1, #0x17]
    // 0xd0b5c4: ldur            x3, [fp, #-0x10]
    // 0xd0b5c8: LoadField: r4 = r3->field_13
    //     0xd0b5c8: ldur            x4, [x3, #0x13]
    // 0xd0b5cc: ldur            x3, [fp, #-0x60]
    // 0xd0b5d0: cmp             x3, x4
    // 0xd0b5d4: b.ne            #0xd0b5fc
    // 0xd0b5d8: r16 = Instance_WidgetState
    //     0xd0b5d8: add             x16, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd0b5dc: ldr             x16, [x16, #0x100]
    // 0xd0b5e0: str             x16, [SP]
    // 0xd0b5e4: r0 = _getHash()
    //     0xd0b5e4: bl              #0x84c644  ; [dart:core] ::_getHash
    // 0xd0b5e8: r3 = LoadInt32Instr(r0)
    //     0xd0b5e8: sbfx            x3, x0, #1, #0x1f
    // 0xd0b5ec: ldur            x1, [fp, #-0x58]
    // 0xd0b5f0: r2 = Instance_WidgetState
    //     0xd0b5f0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd0b5f4: ldr             x2, [x2, #0x100]
    // 0xd0b5f8: r0 = _add()
    //     0xd0b5f8: bl              #0x84ba3c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_add
    // 0xd0b5fc: ldur            x3, [fp, #-8]
    // 0xd0b600: LoadField: r0 = r3->field_b
    //     0xd0b600: ldur            w0, [x3, #0xb]
    // 0xd0b604: DecompressPointer r0
    //     0xd0b604: add             x0, x0, HEAP, lsl #32
    // 0xd0b608: cmp             w0, NULL
    // 0xd0b60c: b.eq            #0xd0ba68
    // 0xd0b610: r0 = Null
    //     0xd0b610: mov             x0, NULL
    // 0xd0b614: r2 = Null
    //     0xd0b614: mov             x2, NULL
    // 0xd0b618: r1 = <MouseCursor?>
    //     0xd0b618: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ab8] TypeArguments: <MouseCursor?>
    //     0xd0b61c: ldr             x1, [x1, #0xab8]
    // 0xd0b620: cmp             w0, NULL
    // 0xd0b624: b.eq            #0xd0b670
    // 0xd0b628: branchIfSmi(r0, 0xd0b670)
    //     0xd0b628: tbz             w0, #0, #0xd0b670
    // 0xd0b62c: r3 = SubtypeTestCache
    //     0xd0b62c: add             x3, PP, #0x90, lsl #12  ; [pp+0x909d8] SubtypeTestCache
    //     0xd0b630: ldr             x3, [x3, #0x9d8]
    // 0xd0b634: r30 = Subtype4TestCacheStub
    //     0xd0b634: ldr             lr, [PP, #0x20]  ; [pp+0x20] Stub: Subtype4TestCache (0x7d2a64)
    // 0xd0b638: LoadField: r30 = r30->field_7
    //     0xd0b638: ldur            lr, [lr, #7]
    // 0xd0b63c: blr             lr
    // 0xd0b640: cmp             w7, NULL
    // 0xd0b644: b.eq            #0xd0b650
    // 0xd0b648: tbnz            w7, #4, #0xd0b670
    // 0xd0b64c: b               #0xd0b678
    // 0xd0b650: r8 = WidgetStateProperty<Y0>
    //     0xd0b650: add             x8, PP, #0x90, lsl #12  ; [pp+0x909e0] Type: WidgetStateProperty<Y0>
    //     0xd0b654: ldr             x8, [x8, #0x9e0]
    // 0xd0b658: r3 = SubtypeTestCache
    //     0xd0b658: add             x3, PP, #0x90, lsl #12  ; [pp+0x909e8] SubtypeTestCache
    //     0xd0b65c: ldr             x3, [x3, #0x9e8]
    // 0xd0b660: r30 = InstanceOfStub
    //     0xd0b660: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xd0b664: LoadField: r30 = r30->field_7
    //     0xd0b664: ldur            lr, [lr, #7]
    // 0xd0b668: blr             lr
    // 0xd0b66c: b               #0xd0b67c
    // 0xd0b670: r0 = false
    //     0xd0b670: add             x0, NULL, #0x30  ; false
    // 0xd0b674: b               #0xd0b67c
    // 0xd0b678: r0 = true
    //     0xd0b678: add             x0, NULL, #0x20  ; true
    // 0xd0b67c: tbnz            w0, #4, #0xd0b6a0
    // 0xd0b680: ldur            x2, [fp, #-0x58]
    // 0xd0b684: r0 = 171
    //     0xd0b684: mov             x0, #0xab
    // 0xd0b688: r1 = Null
    //     0xd0b688: mov             x1, NULL
    // 0xd0b68c: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd0b68c: mov             x17, #0x7c77
    //     0xd0b690: movk            x17, #1, lsl #16
    //     0xd0b694: add             lr, x0, x17
    //     0xd0b698: ldr             lr, [x21, lr, lsl #3]
    //     0xd0b69c: blr             lr
    // 0xd0b6a0: ldur            x0, [fp, #-8]
    // 0xd0b6a4: ldur            x1, [fp, #-0x58]
    // 0xd0b6a8: r0 = _clickable()
    //     0xd0b6a8: bl              #0xd0bac0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateMouseCursor::_clickable
    // 0xd0b6ac: mov             x2, x0
    // 0xd0b6b0: ldur            x0, [fp, #-8]
    // 0xd0b6b4: stur            x2, [fp, #-0x10]
    // 0xd0b6b8: LoadField: r1 = r0->field_b
    //     0xd0b6b8: ldur            w1, [x0, #0xb]
    // 0xd0b6bc: DecompressPointer r1
    //     0xd0b6bc: add             x1, x1, HEAP, lsl #32
    // 0xd0b6c0: cmp             w1, NULL
    // 0xd0b6c4: b.eq            #0xd0ba6c
    // 0xd0b6c8: LoadField: r1 = r0->field_f
    //     0xd0b6c8: ldur            w1, [x0, #0xf]
    // 0xd0b6cc: DecompressPointer r1
    //     0xd0b6cc: add             x1, x1, HEAP, lsl #32
    // 0xd0b6d0: cmp             w1, NULL
    // 0xd0b6d4: b.eq            #0xd0ba70
    // 0xd0b6d8: r0 = of()
    //     0xd0b6d8: bl              #0xd0becc  ; [package:flutter/src/material/bottom_navigation_bar_theme.dart] BottomNavigationBarTheme::of
    // 0xd0b6dc: ldur            x2, [fp, #-8]
    // 0xd0b6e0: LoadField: r0 = r2->field_b
    //     0xd0b6e0: ldur            w0, [x2, #0xb]
    // 0xd0b6e4: DecompressPointer r0
    //     0xd0b6e4: add             x0, x0, HEAP, lsl #32
    // 0xd0b6e8: cmp             w0, NULL
    // 0xd0b6ec: b.eq            #0xd0ba74
    // 0xd0b6f0: LoadField: r3 = r0->field_b
    //     0xd0b6f0: ldur            w3, [x0, #0xb]
    // 0xd0b6f4: DecompressPointer r3
    //     0xd0b6f4: add             x3, x3, HEAP, lsl #32
    // 0xd0b6f8: LoadField: r0 = r3->field_b
    //     0xd0b6f8: ldur            w0, [x3, #0xb]
    // 0xd0b6fc: r1 = LoadInt32Instr(r0)
    //     0xd0b6fc: sbfx            x1, x0, #1, #0x1f
    // 0xd0b700: cmp             x1, #3
    // 0xd0b704: b.gt            #0xd0b714
    // 0xd0b708: r13 = Instance_BottomNavigationBarType
    //     0xd0b708: add             x13, PP, #0x90, lsl #12  ; [pp+0x909f0] Obj!BottomNavigationBarType@12c59e1
    //     0xd0b70c: ldr             x13, [x13, #0x9f0]
    // 0xd0b710: b               #0xd0b71c
    // 0xd0b714: r13 = Instance_BottomNavigationBarType
    //     0xd0b714: add             x13, PP, #0x90, lsl #12  ; [pp+0x909f8] Obj!BottomNavigationBarType@12c59c1
    //     0xd0b718: ldr             x13, [x13, #0x9f8]
    // 0xd0b71c: ldur            x11, [fp, #-0x18]
    // 0xd0b720: ldur            x7, [fp, #-0x28]
    // 0xd0b724: ldur            x6, [fp, #-0x38]
    // 0xd0b728: ldur            x10, [fp, #-0x30]
    // 0xd0b72c: ldur            x9, [fp, #-0x40]
    // 0xd0b730: ldur            x8, [fp, #-0x50]
    // 0xd0b734: ldur            x5, [fp, #-0x20]
    // 0xd0b738: ldur            x12, [fp, #-0x48]
    // 0xd0b73c: ldur            x4, [fp, #-0x10]
    // 0xd0b740: stur            x13, [fp, #-0x70]
    // 0xd0b744: LoadField: r0 = r12->field_f
    //     0xd0b744: ldur            w0, [x12, #0xf]
    // 0xd0b748: DecompressPointer r0
    //     0xd0b748: add             x0, x0, HEAP, lsl #32
    // 0xd0b74c: r14 = LoadInt32Instr(r0)
    //     0xd0b74c: sbfx            x14, x0, #1, #0x1f
    //     0xd0b750: tbz             w0, #0, #0xd0b758
    //     0xd0b754: ldur            x14, [x0, #7]
    // 0xd0b758: mov             x0, x1
    // 0xd0b75c: mov             x1, x14
    // 0xd0b760: cmp             x1, x0
    // 0xd0b764: b.hs            #0xd0ba78
    // 0xd0b768: LoadField: r0 = r3->field_f
    //     0xd0b768: ldur            w0, [x3, #0xf]
    // 0xd0b76c: DecompressPointer r0
    //     0xd0b76c: add             x0, x0, HEAP, lsl #32
    // 0xd0b770: ArrayLoad: r3 = r0[r14]  ; Unknown_4
    //     0xd0b770: add             x16, x0, x14, lsl #2
    //     0xd0b774: ldur            w3, [x16, #0xf]
    // 0xd0b778: DecompressPointer r3
    //     0xd0b778: add             x3, x3, HEAP, lsl #32
    // 0xd0b77c: stur            x3, [fp, #-0x68]
    // 0xd0b780: LoadField: r19 = r2->field_1f
    //     0xd0b780: ldur            w19, [x2, #0x1f]
    // 0xd0b784: DecompressPointer r19
    //     0xd0b784: add             x19, x19, HEAP, lsl #32
    // 0xd0b788: LoadField: r0 = r19->field_b
    //     0xd0b788: ldur            w0, [x19, #0xb]
    // 0xd0b78c: r1 = LoadInt32Instr(r0)
    //     0xd0b78c: sbfx            x1, x0, #1, #0x1f
    // 0xd0b790: mov             x0, x1
    // 0xd0b794: mov             x1, x14
    // 0xd0b798: cmp             x1, x0
    // 0xd0b79c: b.hs            #0xd0ba7c
    // 0xd0b7a0: LoadField: r0 = r19->field_f
    //     0xd0b7a0: ldur            w0, [x19, #0xf]
    // 0xd0b7a4: DecompressPointer r0
    //     0xd0b7a4: add             x0, x0, HEAP, lsl #32
    // 0xd0b7a8: ArrayLoad: r1 = r0[r14]  ; Unknown_4
    //     0xd0b7a8: add             x16, x0, x14, lsl #2
    //     0xd0b7ac: ldur            w1, [x16, #0xf]
    // 0xd0b7b0: DecompressPointer r1
    //     0xd0b7b0: add             x1, x1, HEAP, lsl #32
    // 0xd0b7b4: stur            x1, [fp, #-0x58]
    // 0xd0b7b8: r0 = LoadStaticField(0x5cc)
    //     0xd0b7b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd0b7bc: ldr             x0, [x0, #0xb98]
    // 0xd0b7c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd0b7c4: cmp             w0, w16
    // 0xd0b7c8: b.ne            #0xd0b7d8
    // 0xd0b7cc: r2 = _flexTween
    //     0xd0b7cc: add             x2, PP, #0x90, lsl #12  ; [pp+0x90a00] Field <_BottomNavigationBarState@40237691._flexTween@40237691>: static late final (offset: 0x5cc)
    //     0xd0b7d0: ldr             x2, [x2, #0xa00]
    // 0xd0b7d4: r0 = InitLateFinalStaticField()
    //     0xd0b7d4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd0b7d8: mov             x1, x0
    // 0xd0b7dc: ldur            x2, [fp, #-0x58]
    // 0xd0b7e0: r0 = evaluate()
    //     0xd0b7e0: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xd0b7e4: mov             x5, x0
    // 0xd0b7e8: ldur            x4, [fp, #-0x48]
    // 0xd0b7ec: stur            x5, [fp, #-0x80]
    // 0xd0b7f0: LoadField: r0 = r4->field_f
    //     0xd0b7f0: ldur            w0, [x4, #0xf]
    // 0xd0b7f4: DecompressPointer r0
    //     0xd0b7f4: add             x0, x0, HEAP, lsl #32
    // 0xd0b7f8: ldur            x6, [fp, #-8]
    // 0xd0b7fc: LoadField: r1 = r6->field_b
    //     0xd0b7fc: ldur            w1, [x6, #0xb]
    // 0xd0b800: DecompressPointer r1
    //     0xd0b800: add             x1, x1, HEAP, lsl #32
    // 0xd0b804: cmp             w1, NULL
    // 0xd0b808: b.eq            #0xd0ba80
    // 0xd0b80c: LoadField: r2 = r1->field_13
    //     0xd0b80c: ldur            x2, [x1, #0x13]
    // 0xd0b810: r3 = LoadInt32Instr(r0)
    //     0xd0b810: sbfx            x3, x0, #1, #0x1f
    //     0xd0b814: tbz             w0, #0, #0xd0b81c
    //     0xd0b818: ldur            x3, [x0, #7]
    // 0xd0b81c: cmp             x3, x2
    // 0xd0b820: r16 = true
    //     0xd0b820: add             x16, NULL, #0x20  ; true
    // 0xd0b824: r17 = false
    //     0xd0b824: add             x17, NULL, #0x30  ; false
    // 0xd0b828: csel            x7, x16, x17, eq
    // 0xd0b82c: stur            x7, [fp, #-0x78]
    // 0xd0b830: add             x0, x3, #1
    // 0xd0b834: LoadField: r2 = r1->field_b
    //     0xd0b834: ldur            w2, [x1, #0xb]
    // 0xd0b838: DecompressPointer r2
    //     0xd0b838: add             x2, x2, HEAP, lsl #32
    // 0xd0b83c: LoadField: r1 = r2->field_b
    //     0xd0b83c: ldur            w1, [x2, #0xb]
    // 0xd0b840: r2 = LoadInt32Instr(r1)
    //     0xd0b840: sbfx            x2, x1, #1, #0x1f
    // 0xd0b844: ldur            x8, [fp, #-0x18]
    // 0xd0b848: r1 = LoadClassIdInstr(r8)
    //     0xd0b848: ldur            x1, [x8, #-1]
    //     0xd0b84c: ubfx            x1, x1, #0xc, #0x14
    // 0xd0b850: mov             x3, x0
    // 0xd0b854: mov             x0, x1
    // 0xd0b858: mov             x1, x8
    // 0xd0b85c: r0 = GDT[cid_x0 + 0x15fa0]()
    //     0xd0b85c: mov             x17, #0x5fa0
    //     0xd0b860: movk            x17, #1, lsl #16
    //     0xd0b864: add             lr, x0, x17
    //     0xd0b868: ldr             lr, [x21, lr, lsl #3]
    //     0xd0b86c: blr             lr
    // 0xd0b870: stur            x0, [fp, #-0x88]
    // 0xd0b874: r0 = _BottomNavigationTile()
    //     0xd0b874: bl              #0xd0bab4  ; Allocate_BottomNavigationTileStub -> _BottomNavigationTile (size=0x60)
    // 0xd0b878: mov             x3, x0
    // 0xd0b87c: ldur            x0, [fp, #-0x70]
    // 0xd0b880: stur            x3, [fp, #-0x90]
    // 0xd0b884: StoreField: r3->field_b = r0
    //     0xd0b884: stur            w0, [x3, #0xb]
    // 0xd0b888: ldur            x0, [fp, #-0x68]
    // 0xd0b88c: StoreField: r3->field_f = r0
    //     0xd0b88c: stur            w0, [x3, #0xf]
    // 0xd0b890: ldur            x0, [fp, #-0x58]
    // 0xd0b894: StoreField: r3->field_13 = r0
    //     0xd0b894: stur            w0, [x3, #0x13]
    // 0xd0b898: d0 = 24.000000
    //     0xd0b898: fmov            d0, #24.00000000
    // 0xd0b89c: ArrayStore: r3[0] = d0  ; List_8
    //     0xd0b89c: stur            d0, [x3, #0x17]
    // 0xd0b8a0: ldur            x2, [fp, #-0x48]
    // 0xd0b8a4: r1 = Function '<anonymous closure>':.
    //     0xd0b8a4: add             x1, PP, #0x90, lsl #12  ; [pp+0x90a08] AnonymousClosure: (0xd0bc50), in [package:flutter/src/material/bottom_navigation_bar.dart] _BottomNavigationBarState::_createTiles (0xd0b178)
    //     0xd0b8a8: ldr             x1, [x1, #0xa08]
    // 0xd0b8ac: r0 = AllocateClosure()
    //     0xd0b8ac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0b8b0: mov             x1, x0
    // 0xd0b8b4: ldur            x0, [fp, #-0x90]
    // 0xd0b8b8: StoreField: r0->field_1f = r1
    //     0xd0b8b8: stur            w1, [x0, #0x1f]
    // 0xd0b8bc: ldur            x2, [fp, #-0x50]
    // 0xd0b8c0: StoreField: r0->field_23 = r2
    //     0xd0b8c0: stur            w2, [x0, #0x23]
    // 0xd0b8c4: StoreField: r0->field_27 = r2
    //     0xd0b8c4: stur            w2, [x0, #0x27]
    // 0xd0b8c8: ldur            x1, [fp, #-0x80]
    // 0xd0b8cc: LoadField: d0 = r1->field_7
    //     0xd0b8cc: ldur            d0, [x1, #7]
    // 0xd0b8d0: StoreField: r0->field_2b = d0
    //     0xd0b8d0: stur            d0, [x0, #0x2b]
    // 0xd0b8d4: ldur            x1, [fp, #-0x78]
    // 0xd0b8d8: StoreField: r0->field_33 = r1
    //     0xd0b8d8: stur            w1, [x0, #0x33]
    // 0xd0b8dc: ldur            x3, [fp, #-0x28]
    // 0xd0b8e0: StoreField: r0->field_3f = r3
    //     0xd0b8e0: stur            w3, [x0, #0x3f]
    // 0xd0b8e4: ldur            x4, [fp, #-0x38]
    // 0xd0b8e8: StoreField: r0->field_43 = r4
    //     0xd0b8e8: stur            w4, [x0, #0x43]
    // 0xd0b8ec: ldur            x5, [fp, #-0x30]
    // 0xd0b8f0: StoreField: r0->field_37 = r5
    //     0xd0b8f0: stur            w5, [x0, #0x37]
    // 0xd0b8f4: ldur            x6, [fp, #-0x40]
    // 0xd0b8f8: StoreField: r0->field_3b = r6
    //     0xd0b8f8: stur            w6, [x0, #0x3b]
    // 0xd0b8fc: r7 = true
    //     0xd0b8fc: add             x7, NULL, #0x20  ; true
    // 0xd0b900: StoreField: r0->field_4b = r7
    //     0xd0b900: stur            w7, [x0, #0x4b]
    // 0xd0b904: StoreField: r0->field_4f = r7
    //     0xd0b904: stur            w7, [x0, #0x4f]
    // 0xd0b908: ldur            x1, [fp, #-0x88]
    // 0xd0b90c: StoreField: r0->field_47 = r1
    //     0xd0b90c: stur            w1, [x0, #0x47]
    // 0xd0b910: ldur            x1, [fp, #-0x10]
    // 0xd0b914: StoreField: r0->field_53 = r1
    //     0xd0b914: stur            w1, [x0, #0x53]
    // 0xd0b918: StoreField: r0->field_57 = r7
    //     0xd0b918: stur            w7, [x0, #0x57]
    // 0xd0b91c: r8 = Instance_BottomNavigationBarLandscapeLayout
    //     0xd0b91c: add             x8, PP, #0x90, lsl #12  ; [pp+0x909c8] Obj!BottomNavigationBarLandscapeLayout@12c59a1
    //     0xd0b920: ldr             x8, [x8, #0x9c8]
    // 0xd0b924: StoreField: r0->field_5b = r8
    //     0xd0b924: stur            w8, [x0, #0x5b]
    // 0xd0b928: ldur            x9, [fp, #-0x20]
    // 0xd0b92c: LoadField: r1 = r9->field_b
    //     0xd0b92c: ldur            w1, [x9, #0xb]
    // 0xd0b930: LoadField: r10 = r9->field_f
    //     0xd0b930: ldur            w10, [x9, #0xf]
    // 0xd0b934: DecompressPointer r10
    //     0xd0b934: add             x10, x10, HEAP, lsl #32
    // 0xd0b938: LoadField: r11 = r10->field_b
    //     0xd0b938: ldur            w11, [x10, #0xb]
    // 0xd0b93c: r10 = LoadInt32Instr(r1)
    //     0xd0b93c: sbfx            x10, x1, #1, #0x1f
    // 0xd0b940: stur            x10, [fp, #-0x60]
    // 0xd0b944: r1 = LoadInt32Instr(r11)
    //     0xd0b944: sbfx            x1, x11, #1, #0x1f
    // 0xd0b948: cmp             x10, x1
    // 0xd0b94c: b.ne            #0xd0b958
    // 0xd0b950: mov             x1, x9
    // 0xd0b954: r0 = _growToNextCapacity()
    //     0xd0b954: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd0b958: ldur            x2, [fp, #-0x20]
    // 0xd0b95c: ldur            x3, [fp, #-0x60]
    // 0xd0b960: add             x0, x3, #1
    // 0xd0b964: lsl             x1, x0, #1
    // 0xd0b968: StoreField: r2->field_b = r1
    //     0xd0b968: stur            w1, [x2, #0xb]
    // 0xd0b96c: LoadField: r1 = r2->field_f
    //     0xd0b96c: ldur            w1, [x2, #0xf]
    // 0xd0b970: DecompressPointer r1
    //     0xd0b970: add             x1, x1, HEAP, lsl #32
    // 0xd0b974: ldur            x0, [fp, #-0x90]
    // 0xd0b978: ArrayStore: r1[r3] = r0  ; List_4
    //     0xd0b978: add             x25, x1, x3, lsl #2
    //     0xd0b97c: add             x25, x25, #0xf
    //     0xd0b980: str             w0, [x25]
    //     0xd0b984: tbz             w0, #0, #0xd0b9a0
    //     0xd0b988: ldurb           w16, [x1, #-1]
    //     0xd0b98c: ldurb           w17, [x0, #-1]
    //     0xd0b990: and             x16, x17, x16, lsr #2
    //     0xd0b994: tst             x16, HEAP, lsr #32
    //     0xd0b998: b.eq            #0xd0b9a0
    //     0xd0b99c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd0b9a0: ldur            x5, [fp, #-0x48]
    // 0xd0b9a4: r0 = CloneContext()
    //     0xd0b9a4: bl              #0x13de1f4  ; CloneContextStub
    // 0xd0b9a8: mov             x2, x0
    // 0xd0b9ac: LoadField: r3 = r2->field_f
    //     0xd0b9ac: ldur            w3, [x2, #0xf]
    // 0xd0b9b0: DecompressPointer r3
    //     0xd0b9b0: add             x3, x3, HEAP, lsl #32
    // 0xd0b9b4: r4 = LoadInt32Instr(r3)
    //     0xd0b9b4: sbfx            x4, x3, #1, #0x1f
    //     0xd0b9b8: tbz             w3, #0, #0xd0b9c0
    //     0xd0b9bc: ldur            x4, [x3, #7]
    // 0xd0b9c0: add             x9, x4, #1
    // 0xd0b9c4: r0 = BoxInt64Instr(r9)
    //     0xd0b9c4: sbfiz           x0, x9, #1, #0x1f
    //     0xd0b9c8: cmp             x9, x0, asr #1
    //     0xd0b9cc: b.eq            #0xd0b9d8
    //     0xd0b9d0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xd0b9d4: stur            x9, [x0, #7]
    // 0xd0b9d8: StoreField: r2->field_f = r0
    //     0xd0b9d8: stur            w0, [x2, #0xf]
    //     0xd0b9dc: tbz             w0, #0, #0xd0b9f8
    //     0xd0b9e0: ldurb           w16, [x2, #-1]
    //     0xd0b9e4: ldurb           w17, [x0, #-1]
    //     0xd0b9e8: and             x16, x17, x16, lsr #2
    //     0xd0b9ec: tst             x16, HEAP, lsr #32
    //     0xd0b9f0: b.eq            #0xd0b9f8
    //     0xd0b9f4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd0b9f8: mov             x10, x2
    // 0xd0b9fc: b               #0xd0b534
    // 0xd0ba00: ldur            x0, [fp, #-0x20]
    // 0xd0ba04: LeaveFrame
    //     0xd0ba04: mov             SP, fp
    //     0xd0ba08: ldp             fp, lr, [SP], #0x10
    // 0xd0ba0c: ret
    //     0xd0ba0c: ret             
    // 0xd0ba10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0ba10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0ba14: b               #0xd0b194
    // 0xd0ba18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba18: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba1c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba20: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba24: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba28: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba2c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba30: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba34: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba38: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba44: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba48: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba4c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba54: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba58: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0ba5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0ba60: b               #0xd0b568
    // 0xd0ba64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba64: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba68: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba70: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba74: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0ba78: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd0ba78: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd0ba7c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd0ba7c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd0ba80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0ba80: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ _effectiveIconTheme(/* No info */) {
    // ** addr: 0xd0bb28, size: 0x38
    // 0xd0bb28: EnterFrame
    //     0xd0bb28: stp             fp, lr, [SP, #-0x10]!
    //     0xd0bb2c: mov             fp, SP
    // 0xd0bb30: AllocStack(0x8)
    //     0xd0bb30: sub             SP, SP, #8
    // 0xd0bb34: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0xd0bb34: stur            x2, [fp, #-8]
    // 0xd0bb38: cmp             w1, NULL
    // 0xd0bb3c: b.ne            #0xd0bb50
    // 0xd0bb40: r0 = IconThemeData()
    //     0xd0bb40: bl              #0x8ac78c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0xd0bb44: ldur            x2, [fp, #-8]
    // 0xd0bb48: StoreField: r0->field_1b = r2
    //     0xd0bb48: stur            w2, [x0, #0x1b]
    // 0xd0bb4c: b               #0xd0bb54
    // 0xd0bb50: mov             x0, x1
    // 0xd0bb54: LeaveFrame
    //     0xd0bb54: mov             SP, fp
    //     0xd0bb58: ldp             fp, lr, [SP], #0x10
    // 0xd0bb5c: ret
    //     0xd0bb5c: ret             
  }
  static _ _effectiveTextStyle(/* No info */) {
    // ** addr: 0xd0bb60, size: 0x98
    // 0xd0bb60: EnterFrame
    //     0xd0bb60: stp             fp, lr, [SP, #-0x10]!
    //     0xd0bb64: mov             fp, SP
    // 0xd0bb68: AllocStack(0x8)
    //     0xd0bb68: sub             SP, SP, #8
    // 0xd0bb6c: CheckStackOverflow
    //     0xd0bb6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0bb70: cmp             SP, x16
    //     0xd0bb74: b.ls            #0xd0bbd8
    // 0xd0bb78: LoadField: r0 = r1->field_1f
    //     0xd0bb78: ldur            w0, [x1, #0x1f]
    // 0xd0bb7c: DecompressPointer r0
    //     0xd0bb7c: add             x0, x0, HEAP, lsl #32
    // 0xd0bb80: cmp             w0, NULL
    // 0xd0bb84: b.ne            #0xd0bbc8
    // 0xd0bb88: r0 = inline_Allocate_Double()
    //     0xd0bb88: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xd0bb8c: add             x0, x0, #0x10
    //     0xd0bb90: cmp             x2, x0
    //     0xd0bb94: b.ls            #0xd0bbe0
    //     0xd0bb98: str             x0, [THR, #0x60]  ; THR::top
    //     0xd0bb9c: sub             x0, x0, #0xf
    //     0xd0bba0: mov             x2, #0xe19c
    //     0xd0bba4: movk            x2, #3, lsl #16
    //     0xd0bba8: stur            x2, [x0, #-1]
    // 0xd0bbac: dmb             ishst
    // 0xd0bbb0: StoreField: r0->field_7 = d0
    //     0xd0bbb0: stur            d0, [x0, #7]
    // 0xd0bbb4: str             x0, [SP]
    // 0xd0bbb8: r4 = const [0, 0x2, 0x1, 0x1, fontSize, 0x1, null]
    //     0xd0bbb8: add             x4, PP, #0x13, lsl #12  ; [pp+0x13da8] List(7) [0, 0x2, 0x1, 0x1, "fontSize", 0x1, Null]
    //     0xd0bbbc: ldr             x4, [x4, #0xda8]
    // 0xd0bbc0: r0 = copyWith()
    //     0xd0bbc0: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xd0bbc4: b               #0xd0bbcc
    // 0xd0bbc8: mov             x0, x1
    // 0xd0bbcc: LeaveFrame
    //     0xd0bbcc: mov             SP, fp
    //     0xd0bbd0: ldp             fp, lr, [SP], #0x10
    // 0xd0bbd4: ret
    //     0xd0bbd4: ret             
    // 0xd0bbd8: r0 = StackOverflowSharedWithFPURegs()
    //     0xd0bbd8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd0bbdc: b               #0xd0bb78
    // 0xd0bbe0: SaveReg d0
    //     0xd0bbe0: str             q0, [SP, #-0x10]!
    // 0xd0bbe4: SaveReg r1
    //     0xd0bbe4: str             x1, [SP, #-8]!
    // 0xd0bbe8: r0 = AllocateDouble()
    //     0xd0bbe8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd0bbec: RestoreReg r1
    //     0xd0bbec: ldr             x1, [SP], #8
    // 0xd0bbf0: RestoreReg d0
    //     0xd0bbf0: ldr             q0, [SP], #0x10
    // 0xd0bbf4: b               #0xd0bbb0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd0bc50, size: 0x88
    // 0xd0bc50: EnterFrame
    //     0xd0bc50: stp             fp, lr, [SP, #-0x10]!
    //     0xd0bc54: mov             fp, SP
    // 0xd0bc58: ldr             x0, [fp, #0x10]
    // 0xd0bc5c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd0bc5c: ldur            w1, [x0, #0x17]
    // 0xd0bc60: DecompressPointer r1
    //     0xd0bc60: add             x1, x1, HEAP, lsl #32
    // 0xd0bc64: CheckStackOverflow
    //     0xd0bc64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0bc68: cmp             SP, x16
    //     0xd0bc6c: b.ls            #0xd0bcc8
    // 0xd0bc70: LoadField: r0 = r1->field_b
    //     0xd0bc70: ldur            w0, [x1, #0xb]
    // 0xd0bc74: DecompressPointer r0
    //     0xd0bc74: add             x0, x0, HEAP, lsl #32
    // 0xd0bc78: LoadField: r2 = r0->field_f
    //     0xd0bc78: ldur            w2, [x0, #0xf]
    // 0xd0bc7c: DecompressPointer r2
    //     0xd0bc7c: add             x2, x2, HEAP, lsl #32
    // 0xd0bc80: LoadField: r0 = r2->field_b
    //     0xd0bc80: ldur            w0, [x2, #0xb]
    // 0xd0bc84: DecompressPointer r0
    //     0xd0bc84: add             x0, x0, HEAP, lsl #32
    // 0xd0bc88: cmp             w0, NULL
    // 0xd0bc8c: b.eq            #0xd0bcd0
    // 0xd0bc90: LoadField: r2 = r0->field_f
    //     0xd0bc90: ldur            w2, [x0, #0xf]
    // 0xd0bc94: DecompressPointer r2
    //     0xd0bc94: add             x2, x2, HEAP, lsl #32
    // 0xd0bc98: LoadField: r0 = r1->field_f
    //     0xd0bc98: ldur            w0, [x1, #0xf]
    // 0xd0bc9c: DecompressPointer r0
    //     0xd0bc9c: add             x0, x0, HEAP, lsl #32
    // 0xd0bca0: cmp             w2, NULL
    // 0xd0bca4: b.eq            #0xd0bcd4
    // 0xd0bca8: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd0bca8: ldur            w1, [x2, #0x17]
    // 0xd0bcac: DecompressPointer r1
    //     0xd0bcac: add             x1, x1, HEAP, lsl #32
    // 0xd0bcb0: mov             x2, x0
    // 0xd0bcb4: r0 = changeTabIndex()
    //     0xd0bcb4: bl              #0xd0bd50  ; [package:simaster_ugm/app/modules/landing/controllers/landing_controller.dart] LandingController::changeTabIndex
    // 0xd0bcb8: r0 = Null
    //     0xd0bcb8: mov             x0, NULL
    // 0xd0bcbc: LeaveFrame
    //     0xd0bcbc: mov             SP, fp
    //     0xd0bcc0: ldp             fp, lr, [SP], #0x10
    // 0xd0bcc4: ret
    //     0xd0bcc4: ret             
    // 0xd0bcc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0bcc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0bccc: b               #0xd0bc70
    // 0xd0bcd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0bcd0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0bcd4: r0 = NullErrorSharedWithoutFPURegs()
    //     0xd0bcd4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  static Animatable<double> _flexTween() {
    // ** addr: 0xd0bda0, size: 0x30
    // 0xd0bda0: EnterFrame
    //     0xd0bda0: stp             fp, lr, [SP, #-0x10]!
    //     0xd0bda4: mov             fp, SP
    // 0xd0bda8: r1 = <double>
    //     0xd0bda8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd0bdac: r0 = Tween()
    //     0xd0bdac: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xd0bdb0: r1 = 1.000000
    //     0xd0bdb0: ldr             x1, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xd0bdb4: StoreField: r0->field_b = r1
    //     0xd0bdb4: stur            w1, [x0, #0xb]
    // 0xd0bdb8: r1 = 1.500000
    //     0xd0bdb8: add             x1, PP, #0x7b, lsl #12  ; [pp+0x7b590] 1.5
    //     0xd0bdbc: ldr             x1, [x1, #0x590]
    // 0xd0bdc0: StoreField: r0->field_f = r1
    //     0xd0bdc0: stur            w1, [x0, #0xf]
    // 0xd0bdc4: LeaveFrame
    //     0xd0bdc4: mov             SP, fp
    //     0xd0bdc8: ldp             fp, lr, [SP], #0x10
    // 0xd0bdcc: ret
    //     0xd0bdcc: ret             
  }
  get _ _effectiveType(/* No info */) {
    // ** addr: 0xd0bddc, size: 0xa4
    // 0xd0bddc: EnterFrame
    //     0xd0bddc: stp             fp, lr, [SP, #-0x10]!
    //     0xd0bde0: mov             fp, SP
    // 0xd0bde4: AllocStack(0x8)
    //     0xd0bde4: sub             SP, SP, #8
    // 0xd0bde8: SetupParameters(_BottomNavigationBarState this /* r1 => r0, fp-0x8 */)
    //     0xd0bde8: mov             x0, x1
    //     0xd0bdec: stur            x1, [fp, #-8]
    // 0xd0bdf0: CheckStackOverflow
    //     0xd0bdf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0bdf4: cmp             SP, x16
    //     0xd0bdf8: b.ls            #0xd0be6c
    // 0xd0bdfc: LoadField: r1 = r0->field_b
    //     0xd0bdfc: ldur            w1, [x0, #0xb]
    // 0xd0be00: DecompressPointer r1
    //     0xd0be00: add             x1, x1, HEAP, lsl #32
    // 0xd0be04: cmp             w1, NULL
    // 0xd0be08: b.eq            #0xd0be74
    // 0xd0be0c: LoadField: r1 = r0->field_f
    //     0xd0be0c: ldur            w1, [x0, #0xf]
    // 0xd0be10: DecompressPointer r1
    //     0xd0be10: add             x1, x1, HEAP, lsl #32
    // 0xd0be14: cmp             w1, NULL
    // 0xd0be18: b.eq            #0xd0be78
    // 0xd0be1c: r0 = of()
    //     0xd0be1c: bl              #0xd0becc  ; [package:flutter/src/material/bottom_navigation_bar_theme.dart] BottomNavigationBarTheme::of
    // 0xd0be20: ldur            x1, [fp, #-8]
    // 0xd0be24: LoadField: r2 = r1->field_b
    //     0xd0be24: ldur            w2, [x1, #0xb]
    // 0xd0be28: DecompressPointer r2
    //     0xd0be28: add             x2, x2, HEAP, lsl #32
    // 0xd0be2c: cmp             w2, NULL
    // 0xd0be30: b.eq            #0xd0be7c
    // 0xd0be34: LoadField: r1 = r2->field_b
    //     0xd0be34: ldur            w1, [x2, #0xb]
    // 0xd0be38: DecompressPointer r1
    //     0xd0be38: add             x1, x1, HEAP, lsl #32
    // 0xd0be3c: LoadField: r2 = r1->field_b
    //     0xd0be3c: ldur            w2, [x1, #0xb]
    // 0xd0be40: r1 = LoadInt32Instr(r2)
    //     0xd0be40: sbfx            x1, x2, #1, #0x1f
    // 0xd0be44: cmp             x1, #3
    // 0xd0be48: b.gt            #0xd0be58
    // 0xd0be4c: r0 = Instance_BottomNavigationBarType
    //     0xd0be4c: add             x0, PP, #0x90, lsl #12  ; [pp+0x909f0] Obj!BottomNavigationBarType@12c59e1
    //     0xd0be50: ldr             x0, [x0, #0x9f0]
    // 0xd0be54: b               #0xd0be60
    // 0xd0be58: r0 = Instance_BottomNavigationBarType
    //     0xd0be58: add             x0, PP, #0x90, lsl #12  ; [pp+0x909f8] Obj!BottomNavigationBarType@12c59c1
    //     0xd0be5c: ldr             x0, [x0, #0x9f8]
    // 0xd0be60: LeaveFrame
    //     0xd0be60: mov             SP, fp
    //     0xd0be64: ldp             fp, lr, [SP], #0x10
    // 0xd0be68: ret
    //     0xd0be68: ret             
    // 0xd0be6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0be6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0be70: b               #0xd0bdfc
    // 0xd0be74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0be74: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0be78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0be78: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0be7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0be7c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf36a98, size: 0x218
    // 0xf36a98: EnterFrame
    //     0xf36a98: stp             fp, lr, [SP, #-0x10]!
    //     0xf36a9c: mov             fp, SP
    // 0xf36aa0: AllocStack(0x18)
    //     0xf36aa0: sub             SP, SP, #0x18
    // 0xf36aa4: SetupParameters(_BottomNavigationBarState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf36aa4: mov             x4, x1
    //     0xf36aa8: mov             x3, x2
    //     0xf36aac: stur            x1, [fp, #-8]
    //     0xf36ab0: stur            x2, [fp, #-0x10]
    // 0xf36ab4: CheckStackOverflow
    //     0xf36ab4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf36ab8: cmp             SP, x16
    //     0xf36abc: b.ls            #0xf36c90
    // 0xf36ac0: mov             x0, x3
    // 0xf36ac4: r2 = Null
    //     0xf36ac4: mov             x2, NULL
    // 0xf36ac8: r1 = Null
    //     0xf36ac8: mov             x1, NULL
    // 0xf36acc: r4 = 60
    //     0xf36acc: mov             x4, #0x3c
    // 0xf36ad0: branchIfSmi(r0, 0xf36adc)
    //     0xf36ad0: tbz             w0, #0, #0xf36adc
    // 0xf36ad4: r4 = LoadClassIdInstr(r0)
    //     0xf36ad4: ldur            x4, [x0, #-1]
    //     0xf36ad8: ubfx            x4, x4, #0xc, #0x14
    // 0xf36adc: r17 = 6502
    //     0xf36adc: mov             x17, #0x1966
    // 0xf36ae0: cmp             x4, x17
    // 0xf36ae4: b.eq            #0xf36afc
    // 0xf36ae8: r8 = BottomNavigationBar
    //     0xf36ae8: add             x8, PP, #0x90, lsl #12  ; [pp+0x90a18] Type: BottomNavigationBar
    //     0xf36aec: ldr             x8, [x8, #0xa18]
    // 0xf36af0: r3 = Null
    //     0xf36af0: add             x3, PP, #0x90, lsl #12  ; [pp+0x90a20] Null
    //     0xf36af4: ldr             x3, [x3, #0xa20]
    // 0xf36af8: r0 = BottomNavigationBar()
    //     0xf36af8: bl              #0xacced8  ; IsType_BottomNavigationBar_Stub
    // 0xf36afc: ldur            x3, [fp, #-8]
    // 0xf36b00: LoadField: r2 = r3->field_7
    //     0xf36b00: ldur            w2, [x3, #7]
    // 0xf36b04: DecompressPointer r2
    //     0xf36b04: add             x2, x2, HEAP, lsl #32
    // 0xf36b08: ldur            x0, [fp, #-0x10]
    // 0xf36b0c: r1 = Null
    //     0xf36b0c: mov             x1, NULL
    // 0xf36b10: cmp             w2, NULL
    // 0xf36b14: b.eq            #0xf36b38
    // 0xf36b18: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf36b18: ldur            w4, [x2, #0x17]
    // 0xf36b1c: DecompressPointer r4
    //     0xf36b1c: add             x4, x4, HEAP, lsl #32
    // 0xf36b20: r8 = X0 bound StatefulWidget
    //     0xf36b20: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf36b24: ldr             x8, [x8, #0x498]
    // 0xf36b28: LoadField: r9 = r4->field_7
    //     0xf36b28: ldur            x9, [x4, #7]
    // 0xf36b2c: r3 = Null
    //     0xf36b2c: add             x3, PP, #0x90, lsl #12  ; [pp+0x90a30] Null
    //     0xf36b30: ldr             x3, [x3, #0xa30]
    // 0xf36b34: blr             x9
    // 0xf36b38: ldur            x0, [fp, #-8]
    // 0xf36b3c: LoadField: r1 = r0->field_b
    //     0xf36b3c: ldur            w1, [x0, #0xb]
    // 0xf36b40: DecompressPointer r1
    //     0xf36b40: add             x1, x1, HEAP, lsl #32
    // 0xf36b44: cmp             w1, NULL
    // 0xf36b48: b.eq            #0xf36c98
    // 0xf36b4c: LoadField: r2 = r1->field_b
    //     0xf36b4c: ldur            w2, [x1, #0xb]
    // 0xf36b50: DecompressPointer r2
    //     0xf36b50: add             x2, x2, HEAP, lsl #32
    // 0xf36b54: LoadField: r3 = r2->field_b
    //     0xf36b54: ldur            w3, [x2, #0xb]
    // 0xf36b58: ldur            x2, [fp, #-0x10]
    // 0xf36b5c: LoadField: r4 = r2->field_b
    //     0xf36b5c: ldur            w4, [x2, #0xb]
    // 0xf36b60: DecompressPointer r4
    //     0xf36b60: add             x4, x4, HEAP, lsl #32
    // 0xf36b64: LoadField: r5 = r4->field_b
    //     0xf36b64: ldur            w5, [x4, #0xb]
    // 0xf36b68: r4 = LoadInt32Instr(r3)
    //     0xf36b68: sbfx            x4, x3, #1, #0x1f
    // 0xf36b6c: cmp             w3, w5
    // 0xf36b70: b.eq            #0xf36b8c
    // 0xf36b74: mov             x1, x0
    // 0xf36b78: r0 = _resetState()
    //     0xf36b78: bl              #0xf36d00  ; [package:flutter/src/material/bottom_navigation_bar.dart] _BottomNavigationBarState::_resetState
    // 0xf36b7c: r0 = Null
    //     0xf36b7c: mov             x0, NULL
    // 0xf36b80: LeaveFrame
    //     0xf36b80: mov             SP, fp
    //     0xf36b84: ldp             fp, lr, [SP], #0x10
    // 0xf36b88: ret
    //     0xf36b88: ret             
    // 0xf36b8c: LoadField: r3 = r1->field_13
    //     0xf36b8c: ldur            x3, [x1, #0x13]
    // 0xf36b90: LoadField: r5 = r2->field_13
    //     0xf36b90: ldur            x5, [x2, #0x13]
    // 0xf36b94: stur            x5, [fp, #-0x18]
    // 0xf36b98: cmp             x3, x5
    // 0xf36b9c: b.eq            #0xf36c70
    // 0xf36ba0: mov             x1, x0
    // 0xf36ba4: r0 = _effectiveType()
    //     0xf36ba4: bl              #0xd0bddc  ; [package:flutter/src/material/bottom_navigation_bar.dart] _BottomNavigationBarState::_effectiveType
    // 0xf36ba8: LoadField: r1 = r0->field_7
    //     0xf36ba8: ldur            x1, [x0, #7]
    // 0xf36bac: cmp             x1, #0
    // 0xf36bb0: b.le            #0xf36bd4
    // 0xf36bb4: ldur            x0, [fp, #-8]
    // 0xf36bb8: LoadField: r1 = r0->field_b
    //     0xf36bb8: ldur            w1, [x0, #0xb]
    // 0xf36bbc: DecompressPointer r1
    //     0xf36bbc: add             x1, x1, HEAP, lsl #32
    // 0xf36bc0: cmp             w1, NULL
    // 0xf36bc4: b.eq            #0xf36c9c
    // 0xf36bc8: LoadField: r2 = r1->field_13
    //     0xf36bc8: ldur            x2, [x1, #0x13]
    // 0xf36bcc: mov             x1, x0
    // 0xf36bd0: r0 = _pushCircle()
    //     0xf36bd0: bl              #0xf36cb0  ; [package:flutter/src/material/bottom_navigation_bar.dart] _BottomNavigationBarState::_pushCircle
    // 0xf36bd4: ldur            x2, [fp, #-8]
    // 0xf36bd8: ldur            x3, [fp, #-0x18]
    // 0xf36bdc: LoadField: r4 = r2->field_1b
    //     0xf36bdc: ldur            w4, [x2, #0x1b]
    // 0xf36be0: DecompressPointer r4
    //     0xf36be0: add             x4, x4, HEAP, lsl #32
    // 0xf36be4: LoadField: r0 = r4->field_b
    //     0xf36be4: ldur            w0, [x4, #0xb]
    // 0xf36be8: r1 = LoadInt32Instr(r0)
    //     0xf36be8: sbfx            x1, x0, #1, #0x1f
    // 0xf36bec: mov             x0, x1
    // 0xf36bf0: mov             x1, x3
    // 0xf36bf4: cmp             x1, x0
    // 0xf36bf8: b.hs            #0xf36ca0
    // 0xf36bfc: LoadField: r0 = r4->field_f
    //     0xf36bfc: ldur            w0, [x4, #0xf]
    // 0xf36c00: DecompressPointer r0
    //     0xf36c00: add             x0, x0, HEAP, lsl #32
    // 0xf36c04: ArrayLoad: r1 = r0[r3]  ; Unknown_4
    //     0xf36c04: add             x16, x0, x3, lsl #2
    //     0xf36c08: ldur            w1, [x16, #0xf]
    // 0xf36c0c: DecompressPointer r1
    //     0xf36c0c: add             x1, x1, HEAP, lsl #32
    // 0xf36c10: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf36c10: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf36c14: r0 = reverse()
    //     0xf36c14: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xf36c18: ldur            x0, [fp, #-8]
    // 0xf36c1c: LoadField: r2 = r0->field_1b
    //     0xf36c1c: ldur            w2, [x0, #0x1b]
    // 0xf36c20: DecompressPointer r2
    //     0xf36c20: add             x2, x2, HEAP, lsl #32
    // 0xf36c24: LoadField: r1 = r0->field_b
    //     0xf36c24: ldur            w1, [x0, #0xb]
    // 0xf36c28: DecompressPointer r1
    //     0xf36c28: add             x1, x1, HEAP, lsl #32
    // 0xf36c2c: cmp             w1, NULL
    // 0xf36c30: b.eq            #0xf36ca4
    // 0xf36c34: LoadField: r3 = r1->field_13
    //     0xf36c34: ldur            x3, [x1, #0x13]
    // 0xf36c38: LoadField: r0 = r2->field_b
    //     0xf36c38: ldur            w0, [x2, #0xb]
    // 0xf36c3c: r1 = LoadInt32Instr(r0)
    //     0xf36c3c: sbfx            x1, x0, #1, #0x1f
    // 0xf36c40: mov             x0, x1
    // 0xf36c44: mov             x1, x3
    // 0xf36c48: cmp             x1, x0
    // 0xf36c4c: b.hs            #0xf36ca8
    // 0xf36c50: LoadField: r0 = r2->field_f
    //     0xf36c50: ldur            w0, [x2, #0xf]
    // 0xf36c54: DecompressPointer r0
    //     0xf36c54: add             x0, x0, HEAP, lsl #32
    // 0xf36c58: ArrayLoad: r1 = r0[r3]  ; Unknown_4
    //     0xf36c58: add             x16, x0, x3, lsl #2
    //     0xf36c5c: ldur            w1, [x16, #0xf]
    // 0xf36c60: DecompressPointer r1
    //     0xf36c60: add             x1, x1, HEAP, lsl #32
    // 0xf36c64: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf36c64: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf36c68: r0 = forward()
    //     0xf36c68: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xf36c6c: b               #0xf36c80
    // 0xf36c70: mov             x0, x4
    // 0xf36c74: mov             x1, x3
    // 0xf36c78: cmp             x1, x0
    // 0xf36c7c: b.hs            #0xf36cac
    // 0xf36c80: r0 = Null
    //     0xf36c80: mov             x0, NULL
    // 0xf36c84: LeaveFrame
    //     0xf36c84: mov             SP, fp
    //     0xf36c88: ldp             fp, lr, [SP], #0x10
    // 0xf36c8c: ret
    //     0xf36c8c: ret             
    // 0xf36c90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf36c90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf36c94: b               #0xf36ac0
    // 0xf36c98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf36c98: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf36c9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf36c9c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf36ca0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf36ca0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xf36ca4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf36ca4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf36ca8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf36ca8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xf36cac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf36cac: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _pushCircle(/* No info */) {
    // ** addr: 0xf36cb0, size: 0x50
    // 0xf36cb0: EnterFrame
    //     0xf36cb0: stp             fp, lr, [SP, #-0x10]!
    //     0xf36cb4: mov             fp, SP
    // 0xf36cb8: mov             x0, x1
    // 0xf36cbc: mov             x1, x2
    // 0xf36cc0: LoadField: r2 = r0->field_b
    //     0xf36cc0: ldur            w2, [x0, #0xb]
    // 0xf36cc4: DecompressPointer r2
    //     0xf36cc4: add             x2, x2, HEAP, lsl #32
    // 0xf36cc8: cmp             w2, NULL
    // 0xf36ccc: b.eq            #0xf36cf8
    // 0xf36cd0: LoadField: r3 = r2->field_b
    //     0xf36cd0: ldur            w3, [x2, #0xb]
    // 0xf36cd4: DecompressPointer r3
    //     0xf36cd4: add             x3, x3, HEAP, lsl #32
    // 0xf36cd8: LoadField: r2 = r3->field_b
    //     0xf36cd8: ldur            w2, [x3, #0xb]
    // 0xf36cdc: r0 = LoadInt32Instr(r2)
    //     0xf36cdc: sbfx            x0, x2, #1, #0x1f
    // 0xf36ce0: cmp             x1, x0
    // 0xf36ce4: b.hs            #0xf36cfc
    // 0xf36ce8: r0 = Null
    //     0xf36ce8: mov             x0, NULL
    // 0xf36cec: LeaveFrame
    //     0xf36cec: mov             SP, fp
    //     0xf36cf0: ldp             fp, lr, [SP], #0x10
    // 0xf36cf4: ret
    //     0xf36cf4: ret             
    // 0xf36cf8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf36cf8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf36cfc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf36cfc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _resetState(/* No info */) {
    // ** addr: 0xf36d00, size: 0x638
    // 0xf36d00: EnterFrame
    //     0xf36d00: stp             fp, lr, [SP, #-0x10]!
    //     0xf36d04: mov             fp, SP
    // 0xf36d08: AllocStack(0x60)
    //     0xf36d08: sub             SP, SP, #0x60
    // 0xf36d0c: SetupParameters(_BottomNavigationBarState this /* r1 => r2, fp-0x20 */)
    //     0xf36d0c: mov             x2, x1
    //     0xf36d10: stur            x1, [fp, #-0x20]
    // 0xf36d14: CheckStackOverflow
    //     0xf36d14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf36d18: cmp             SP, x16
    //     0xf36d1c: b.ls            #0xf372d4
    // 0xf36d20: LoadField: r0 = r2->field_1b
    //     0xf36d20: ldur            w0, [x2, #0x1b]
    // 0xf36d24: DecompressPointer r0
    //     0xf36d24: add             x0, x0, HEAP, lsl #32
    // 0xf36d28: stur            x0, [fp, #-0x18]
    // 0xf36d2c: LoadField: r1 = r0->field_b
    //     0xf36d2c: ldur            w1, [x0, #0xb]
    // 0xf36d30: r3 = LoadInt32Instr(r1)
    //     0xf36d30: sbfx            x3, x1, #1, #0x1f
    // 0xf36d34: stur            x3, [fp, #-0x10]
    // 0xf36d38: r1 = 0
    //     0xf36d38: mov             x1, #0
    // 0xf36d3c: CheckStackOverflow
    //     0xf36d3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf36d40: cmp             SP, x16
    //     0xf36d44: b.ls            #0xf372dc
    // 0xf36d48: LoadField: r4 = r0->field_b
    //     0xf36d48: ldur            w4, [x0, #0xb]
    // 0xf36d4c: r5 = LoadInt32Instr(r4)
    //     0xf36d4c: sbfx            x5, x4, #1, #0x1f
    // 0xf36d50: cmp             x3, x5
    // 0xf36d54: b.ne            #0xf372b8
    // 0xf36d58: cmp             x1, x5
    // 0xf36d5c: b.ge            #0xf36d98
    // 0xf36d60: LoadField: r4 = r0->field_f
    //     0xf36d60: ldur            w4, [x0, #0xf]
    // 0xf36d64: DecompressPointer r4
    //     0xf36d64: add             x4, x4, HEAP, lsl #32
    // 0xf36d68: ArrayLoad: r5 = r4[r1]  ; Unknown_4
    //     0xf36d68: add             x16, x4, x1, lsl #2
    //     0xf36d6c: ldur            w5, [x16, #0xf]
    // 0xf36d70: DecompressPointer r5
    //     0xf36d70: add             x5, x5, HEAP, lsl #32
    // 0xf36d74: add             x4, x1, #1
    // 0xf36d78: mov             x1, x5
    // 0xf36d7c: stur            x4, [fp, #-8]
    // 0xf36d80: r0 = dispose()
    //     0xf36d80: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xf36d84: ldur            x1, [fp, #-8]
    // 0xf36d88: ldur            x2, [fp, #-0x20]
    // 0xf36d8c: ldur            x0, [fp, #-0x18]
    // 0xf36d90: ldur            x3, [fp, #-0x10]
    // 0xf36d94: b               #0xf36d3c
    // 0xf36d98: LoadField: r0 = r2->field_23
    //     0xf36d98: ldur            w0, [x2, #0x23]
    // 0xf36d9c: DecompressPointer r0
    //     0xf36d9c: add             x0, x0, HEAP, lsl #32
    // 0xf36da0: mov             x1, x0
    // 0xf36da4: stur            x0, [fp, #-0x28]
    // 0xf36da8: r0 = iterator()
    //     0xf36da8: bl              #0xb09254  ; [dart:collection] ListQueue::iterator
    // 0xf36dac: stur            x0, [fp, #-0x38]
    // 0xf36db0: CheckStackOverflow
    //     0xf36db0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf36db4: cmp             SP, x16
    //     0xf36db8: b.ls            #0xf372e4
    // 0xf36dbc: LoadField: r3 = r0->field_b
    //     0xf36dbc: ldur            w3, [x0, #0xb]
    // 0xf36dc0: DecompressPointer r3
    //     0xf36dc0: add             x3, x3, HEAP, lsl #32
    // 0xf36dc4: stur            x3, [fp, #-0x30]
    // 0xf36dc8: ArrayLoad: r2 = r0[0]  ; List_8
    //     0xf36dc8: ldur            x2, [x0, #0x17]
    // 0xf36dcc: mov             x1, x3
    // 0xf36dd0: r0 = _checkModification()
    //     0xf36dd0: bl              #0x802db8  ; [dart:collection] ListQueue::_checkModification
    // 0xf36dd4: ldur            x2, [fp, #-0x38]
    // 0xf36dd8: LoadField: r3 = r2->field_1f
    //     0xf36dd8: ldur            x3, [x2, #0x1f]
    // 0xf36ddc: LoadField: r0 = r2->field_f
    //     0xf36ddc: ldur            x0, [x2, #0xf]
    // 0xf36de0: cmp             x3, x0
    // 0xf36de4: b.ne            #0xf371e0
    // 0xf36de8: ldur            x0, [fp, #-0x20]
    // 0xf36dec: StoreField: r2->field_27 = rNULL
    //     0xf36dec: stur            NULL, [x2, #0x27]
    // 0xf36df0: LoadField: r3 = r0->field_1f
    //     0xf36df0: ldur            w3, [x0, #0x1f]
    // 0xf36df4: DecompressPointer r3
    //     0xf36df4: add             x3, x3, HEAP, lsl #32
    // 0xf36df8: stur            x3, [fp, #-0x48]
    // 0xf36dfc: LoadField: r1 = r3->field_b
    //     0xf36dfc: ldur            w1, [x3, #0xb]
    // 0xf36e00: r4 = LoadInt32Instr(r1)
    //     0xf36e00: sbfx            x4, x1, #1, #0x1f
    // 0xf36e04: stur            x4, [fp, #-0x10]
    // 0xf36e08: r1 = 0
    //     0xf36e08: mov             x1, #0
    // 0xf36e0c: CheckStackOverflow
    //     0xf36e0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf36e10: cmp             SP, x16
    //     0xf36e14: b.ls            #0xf372ec
    // 0xf36e18: LoadField: r2 = r3->field_b
    //     0xf36e18: ldur            w2, [x3, #0xb]
    // 0xf36e1c: r5 = LoadInt32Instr(r2)
    //     0xf36e1c: sbfx            x5, x2, #1, #0x1f
    // 0xf36e20: cmp             x4, x5
    // 0xf36e24: b.ne            #0xf371c0
    // 0xf36e28: cmp             x1, x5
    // 0xf36e2c: b.ge            #0xf36ea0
    // 0xf36e30: LoadField: r2 = r3->field_f
    //     0xf36e30: ldur            w2, [x3, #0xf]
    // 0xf36e34: DecompressPointer r2
    //     0xf36e34: add             x2, x2, HEAP, lsl #32
    // 0xf36e38: ArrayLoad: r5 = r2[r1]  ; Unknown_4
    //     0xf36e38: add             x16, x2, x1, lsl #2
    //     0xf36e3c: ldur            w5, [x16, #0xf]
    // 0xf36e40: DecompressPointer r5
    //     0xf36e40: add             x5, x5, HEAP, lsl #32
    // 0xf36e44: add             x6, x1, #1
    // 0xf36e48: stur            x6, [fp, #-8]
    // 0xf36e4c: LoadField: r7 = r5->field_b
    //     0xf36e4c: ldur            w7, [x5, #0xb]
    // 0xf36e50: DecompressPointer r7
    //     0xf36e50: add             x7, x7, HEAP, lsl #32
    // 0xf36e54: mov             x2, x5
    // 0xf36e58: stur            x7, [fp, #-0x40]
    // 0xf36e5c: r1 = Function '_updateCurveDirection@63411118':.
    //     0xf36e5c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16de0] AnonymousClosure: (0x915e10), in [package:flutter/src/animation/animations.dart] CurvedAnimation::_updateCurveDirection (0x915d94)
    //     0xf36e60: ldr             x1, [x1, #0xde0]
    // 0xf36e64: r0 = AllocateClosure()
    //     0xf36e64: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf36e68: ldur            x1, [fp, #-0x40]
    // 0xf36e6c: r2 = LoadClassIdInstr(r1)
    //     0xf36e6c: ldur            x2, [x1, #-1]
    //     0xf36e70: ubfx            x2, x2, #0xc, #0x14
    // 0xf36e74: mov             x16, x0
    // 0xf36e78: mov             x0, x2
    // 0xf36e7c: mov             x2, x16
    // 0xf36e80: r0 = GDT[cid_x0 + 0xabe]()
    //     0xf36e80: add             lr, x0, #0xabe
    //     0xf36e84: ldr             lr, [x21, lr, lsl #3]
    //     0xf36e88: blr             lr
    // 0xf36e8c: ldur            x1, [fp, #-8]
    // 0xf36e90: ldur            x0, [fp, #-0x20]
    // 0xf36e94: ldur            x3, [fp, #-0x48]
    // 0xf36e98: ldur            x4, [fp, #-0x10]
    // 0xf36e9c: b               #0xf36e0c
    // 0xf36ea0: mov             x2, x0
    // 0xf36ea4: ldur            x1, [fp, #-0x28]
    // 0xf36ea8: r0 = clear()
    //     0xf36ea8: bl              #0xa05eb4  ; [dart:collection] ListQueue::clear
    // 0xf36eac: ldur            x0, [fp, #-0x20]
    // 0xf36eb0: LoadField: r1 = r0->field_b
    //     0xf36eb0: ldur            w1, [x0, #0xb]
    // 0xf36eb4: DecompressPointer r1
    //     0xf36eb4: add             x1, x1, HEAP, lsl #32
    // 0xf36eb8: cmp             w1, NULL
    // 0xf36ebc: b.eq            #0xf372f4
    // 0xf36ec0: LoadField: r2 = r1->field_b
    //     0xf36ec0: ldur            w2, [x1, #0xb]
    // 0xf36ec4: DecompressPointer r2
    //     0xf36ec4: add             x2, x2, HEAP, lsl #32
    // 0xf36ec8: LoadField: r1 = r2->field_b
    //     0xf36ec8: ldur            w1, [x2, #0xb]
    // 0xf36ecc: r2 = LoadInt32Instr(r1)
    //     0xf36ecc: sbfx            x2, x1, #1, #0x1f
    // 0xf36ed0: r1 = <AnimationController>
    //     0xf36ed0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15790] TypeArguments: <AnimationController>
    //     0xf36ed4: ldr             x1, [x1, #0x790]
    // 0xf36ed8: r0 = _GrowableList()
    //     0xf36ed8: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xf36edc: ldur            x2, [fp, #-0x20]
    // 0xf36ee0: r1 = Function '_rebuild@40237691':.
    //     0xf36ee0: add             x1, PP, #0x90, lsl #12  ; [pp+0x90a40] AnonymousClosure: (0xf37358), in [package:flutter/src/material/bottom_navigation_bar.dart] _BottomNavigationBarState::_rebuild (0xf37390)
    //     0xf36ee4: ldr             x1, [x1, #0xa40]
    // 0xf36ee8: stur            x0, [fp, #-0x28]
    // 0xf36eec: r0 = AllocateClosure()
    //     0xf36eec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf36ef0: stur            x0, [fp, #-0x40]
    // 0xf36ef4: ldur            x2, [fp, #-0x28]
    // 0xf36ef8: r3 = 0
    //     0xf36ef8: mov             x3, #0
    // 0xf36efc: stur            x3, [fp, #-8]
    // 0xf36f00: CheckStackOverflow
    //     0xf36f00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf36f04: cmp             SP, x16
    //     0xf36f08: b.ls            #0xf372f8
    // 0xf36f0c: LoadField: r1 = r2->field_b
    //     0xf36f0c: ldur            w1, [x2, #0xb]
    // 0xf36f10: r4 = LoadInt32Instr(r1)
    //     0xf36f10: sbfx            x4, x1, #1, #0x1f
    // 0xf36f14: cmp             x3, x4
    // 0xf36f18: b.ge            #0xf36fb8
    // 0xf36f1c: r1 = <double>
    //     0xf36f1c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf36f20: r0 = AnimationController()
    //     0xf36f20: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf36f24: stur            x0, [fp, #-0x50]
    // 0xf36f28: r16 = Instance_Duration
    //     0xf36f28: add             x16, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xf36f2c: ldr             x16, [x16, #0x318]
    // 0xf36f30: str             x16, [SP]
    // 0xf36f34: mov             x1, x0
    // 0xf36f38: ldur            x2, [fp, #-0x20]
    // 0xf36f3c: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xf36f3c: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xf36f40: ldr             x4, [x4, #0x5a0]
    // 0xf36f44: r0 = AnimationController()
    //     0xf36f44: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf36f48: ldur            x1, [fp, #-0x50]
    // 0xf36f4c: ldur            x2, [fp, #-0x40]
    // 0xf36f50: r0 = addListener()
    //     0xf36f50: bl              #0xd0440c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::addListener
    // 0xf36f54: ldur            x2, [fp, #-0x28]
    // 0xf36f58: LoadField: r0 = r2->field_b
    //     0xf36f58: ldur            w0, [x2, #0xb]
    // 0xf36f5c: r1 = LoadInt32Instr(r0)
    //     0xf36f5c: sbfx            x1, x0, #1, #0x1f
    // 0xf36f60: mov             x0, x1
    // 0xf36f64: ldur            x1, [fp, #-8]
    // 0xf36f68: cmp             x1, x0
    // 0xf36f6c: b.hs            #0xf37300
    // 0xf36f70: LoadField: r1 = r2->field_f
    //     0xf36f70: ldur            w1, [x2, #0xf]
    // 0xf36f74: DecompressPointer r1
    //     0xf36f74: add             x1, x1, HEAP, lsl #32
    // 0xf36f78: ldur            x0, [fp, #-0x50]
    // 0xf36f7c: ldur            x3, [fp, #-8]
    // 0xf36f80: ArrayStore: r1[r3] = r0  ; List_4
    //     0xf36f80: add             x25, x1, x3, lsl #2
    //     0xf36f84: add             x25, x25, #0xf
    //     0xf36f88: str             w0, [x25]
    //     0xf36f8c: tbz             w0, #0, #0xf36fa8
    //     0xf36f90: ldurb           w16, [x1, #-1]
    //     0xf36f94: ldurb           w17, [x0, #-1]
    //     0xf36f98: and             x16, x17, x16, lsr #2
    //     0xf36f9c: tst             x16, HEAP, lsr #32
    //     0xf36fa0: b.eq            #0xf36fa8
    //     0xf36fa4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf36fa8: add             x0, x3, #1
    // 0xf36fac: mov             x3, x0
    // 0xf36fb0: ldur            x0, [fp, #-0x40]
    // 0xf36fb4: b               #0xf36efc
    // 0xf36fb8: ldur            x3, [fp, #-0x20]
    // 0xf36fbc: mov             x0, x2
    // 0xf36fc0: StoreField: r3->field_1b = r0
    //     0xf36fc0: stur            w0, [x3, #0x1b]
    //     0xf36fc4: ldurb           w16, [x3, #-1]
    //     0xf36fc8: ldurb           w17, [x0, #-1]
    //     0xf36fcc: and             x16, x17, x16, lsr #2
    //     0xf36fd0: tst             x16, HEAP, lsr #32
    //     0xf36fd4: b.eq            #0xf36fdc
    //     0xf36fd8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf36fdc: LoadField: r0 = r3->field_b
    //     0xf36fdc: ldur            w0, [x3, #0xb]
    // 0xf36fe0: DecompressPointer r0
    //     0xf36fe0: add             x0, x0, HEAP, lsl #32
    // 0xf36fe4: cmp             w0, NULL
    // 0xf36fe8: b.eq            #0xf37304
    // 0xf36fec: LoadField: r1 = r0->field_b
    //     0xf36fec: ldur            w1, [x0, #0xb]
    // 0xf36ff0: DecompressPointer r1
    //     0xf36ff0: add             x1, x1, HEAP, lsl #32
    // 0xf36ff4: LoadField: r0 = r1->field_b
    //     0xf36ff4: ldur            w0, [x1, #0xb]
    // 0xf36ff8: r2 = LoadInt32Instr(r0)
    //     0xf36ff8: sbfx            x2, x0, #1, #0x1f
    // 0xf36ffc: r1 = <CurvedAnimation>
    //     0xf36ffc: add             x1, PP, #0x85, lsl #12  ; [pp+0x85370] TypeArguments: <CurvedAnimation>
    //     0xf37000: ldr             x1, [x1, #0x370]
    // 0xf37004: r0 = _GrowableList()
    //     0xf37004: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xf37008: mov             x2, x0
    // 0xf3700c: stur            x2, [fp, #-0x40]
    // 0xf37010: r4 = 0
    //     0xf37010: mov             x4, #0
    // 0xf37014: ldur            x3, [fp, #-0x20]
    // 0xf37018: stur            x4, [fp, #-8]
    // 0xf3701c: CheckStackOverflow
    //     0xf3701c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf37020: cmp             SP, x16
    //     0xf37024: b.ls            #0xf37308
    // 0xf37028: LoadField: r0 = r2->field_b
    //     0xf37028: ldur            w0, [x2, #0xb]
    // 0xf3702c: r1 = LoadInt32Instr(r0)
    //     0xf3702c: sbfx            x1, x0, #1, #0x1f
    // 0xf37030: cmp             x4, x1
    // 0xf37034: b.ge            #0xf37104
    // 0xf37038: LoadField: r5 = r3->field_1b
    //     0xf37038: ldur            w5, [x3, #0x1b]
    // 0xf3703c: DecompressPointer r5
    //     0xf3703c: add             x5, x5, HEAP, lsl #32
    // 0xf37040: LoadField: r0 = r5->field_b
    //     0xf37040: ldur            w0, [x5, #0xb]
    // 0xf37044: r1 = LoadInt32Instr(r0)
    //     0xf37044: sbfx            x1, x0, #1, #0x1f
    // 0xf37048: mov             x0, x1
    // 0xf3704c: mov             x1, x4
    // 0xf37050: cmp             x1, x0
    // 0xf37054: b.hs            #0xf37310
    // 0xf37058: LoadField: r0 = r5->field_f
    //     0xf37058: ldur            w0, [x5, #0xf]
    // 0xf3705c: DecompressPointer r0
    //     0xf3705c: add             x0, x0, HEAP, lsl #32
    // 0xf37060: ArrayLoad: r5 = r0[r4]  ; Unknown_4
    //     0xf37060: add             x16, x0, x4, lsl #2
    //     0xf37064: ldur            w5, [x16, #0xf]
    // 0xf37068: DecompressPointer r5
    //     0xf37068: add             x5, x5, HEAP, lsl #32
    // 0xf3706c: stur            x5, [fp, #-0x28]
    // 0xf37070: r1 = Instance_Cubic
    //     0xf37070: ldr             x1, [PP, #0x5660]  ; [pp+0x5660] Obj!Cubic@129f451
    // 0xf37074: r0 = flipped()
    //     0xf37074: bl              #0xb6f40c  ; [package:flutter/src/animation/curves.dart] Curve::flipped
    // 0xf37078: r1 = <double>
    //     0xf37078: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3707c: stur            x0, [fp, #-0x50]
    // 0xf37080: r0 = CurvedAnimation()
    //     0xf37080: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xf37084: stur            x0, [fp, #-0x58]
    // 0xf37088: ldur            x16, [fp, #-0x50]
    // 0xf3708c: str             x16, [SP]
    // 0xf37090: mov             x1, x0
    // 0xf37094: ldur            x3, [fp, #-0x28]
    // 0xf37098: r2 = Instance_Cubic
    //     0xf37098: ldr             x2, [PP, #0x5660]  ; [pp+0x5660] Obj!Cubic@129f451
    // 0xf3709c: r4 = const [0, 0x4, 0x1, 0x3, reverseCurve, 0x3, null]
    //     0xf3709c: add             x4, PP, #0x16, lsl #12  ; [pp+0x16dc0] List(7) [0, 0x4, 0x1, 0x3, "reverseCurve", 0x3, Null]
    //     0xf370a0: ldr             x4, [x4, #0xdc0]
    // 0xf370a4: r0 = CurvedAnimation()
    //     0xf370a4: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xf370a8: ldur            x2, [fp, #-0x40]
    // 0xf370ac: LoadField: r0 = r2->field_b
    //     0xf370ac: ldur            w0, [x2, #0xb]
    // 0xf370b0: r1 = LoadInt32Instr(r0)
    //     0xf370b0: sbfx            x1, x0, #1, #0x1f
    // 0xf370b4: mov             x0, x1
    // 0xf370b8: ldur            x1, [fp, #-8]
    // 0xf370bc: cmp             x1, x0
    // 0xf370c0: b.hs            #0xf37314
    // 0xf370c4: LoadField: r1 = r2->field_f
    //     0xf370c4: ldur            w1, [x2, #0xf]
    // 0xf370c8: DecompressPointer r1
    //     0xf370c8: add             x1, x1, HEAP, lsl #32
    // 0xf370cc: ldur            x0, [fp, #-0x58]
    // 0xf370d0: ldur            x3, [fp, #-8]
    // 0xf370d4: ArrayStore: r1[r3] = r0  ; List_4
    //     0xf370d4: add             x25, x1, x3, lsl #2
    //     0xf370d8: add             x25, x25, #0xf
    //     0xf370dc: str             w0, [x25]
    //     0xf370e0: tbz             w0, #0, #0xf370fc
    //     0xf370e4: ldurb           w16, [x1, #-1]
    //     0xf370e8: ldurb           w17, [x0, #-1]
    //     0xf370ec: and             x16, x17, x16, lsr #2
    //     0xf370f0: tst             x16, HEAP, lsr #32
    //     0xf370f4: b.eq            #0xf370fc
    //     0xf370f8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf370fc: add             x4, x3, #1
    // 0xf37100: b               #0xf37014
    // 0xf37104: mov             x0, x2
    // 0xf37108: StoreField: r3->field_1f = r0
    //     0xf37108: stur            w0, [x3, #0x1f]
    //     0xf3710c: ldurb           w16, [x3, #-1]
    //     0xf37110: ldurb           w17, [x0, #-1]
    //     0xf37114: and             x16, x17, x16, lsr #2
    //     0xf37118: tst             x16, HEAP, lsr #32
    //     0xf3711c: b.eq            #0xf37124
    //     0xf37120: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf37124: LoadField: r2 = r3->field_1b
    //     0xf37124: ldur            w2, [x3, #0x1b]
    // 0xf37128: DecompressPointer r2
    //     0xf37128: add             x2, x2, HEAP, lsl #32
    // 0xf3712c: LoadField: r0 = r3->field_b
    //     0xf3712c: ldur            w0, [x3, #0xb]
    // 0xf37130: DecompressPointer r0
    //     0xf37130: add             x0, x0, HEAP, lsl #32
    // 0xf37134: cmp             w0, NULL
    // 0xf37138: b.eq            #0xf37318
    // 0xf3713c: LoadField: r4 = r0->field_13
    //     0xf3713c: ldur            x4, [x0, #0x13]
    // 0xf37140: LoadField: r0 = r2->field_b
    //     0xf37140: ldur            w0, [x2, #0xb]
    // 0xf37144: r1 = LoadInt32Instr(r0)
    //     0xf37144: sbfx            x1, x0, #1, #0x1f
    // 0xf37148: mov             x0, x1
    // 0xf3714c: mov             x1, x4
    // 0xf37150: cmp             x1, x0
    // 0xf37154: b.hs            #0xf3731c
    // 0xf37158: LoadField: r0 = r2->field_f
    //     0xf37158: ldur            w0, [x2, #0xf]
    // 0xf3715c: DecompressPointer r0
    //     0xf3715c: add             x0, x0, HEAP, lsl #32
    // 0xf37160: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0xf37160: add             x16, x0, x4, lsl #2
    //     0xf37164: ldur            w1, [x16, #0xf]
    // 0xf37168: DecompressPointer r1
    //     0xf37168: add             x1, x1, HEAP, lsl #32
    // 0xf3716c: r2 = 1.000000
    //     0xf3716c: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xf37170: r0 = value=()
    //     0xf37170: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xf37174: ldur            x2, [fp, #-0x20]
    // 0xf37178: LoadField: r0 = r2->field_b
    //     0xf37178: ldur            w0, [x2, #0xb]
    // 0xf3717c: DecompressPointer r0
    //     0xf3717c: add             x0, x0, HEAP, lsl #32
    // 0xf37180: cmp             w0, NULL
    // 0xf37184: b.eq            #0xf37320
    // 0xf37188: LoadField: r1 = r0->field_b
    //     0xf37188: ldur            w1, [x0, #0xb]
    // 0xf3718c: DecompressPointer r1
    //     0xf3718c: add             x1, x1, HEAP, lsl #32
    // 0xf37190: LoadField: r3 = r0->field_13
    //     0xf37190: ldur            x3, [x0, #0x13]
    // 0xf37194: LoadField: r0 = r1->field_b
    //     0xf37194: ldur            w0, [x1, #0xb]
    // 0xf37198: r1 = LoadInt32Instr(r0)
    //     0xf37198: sbfx            x1, x0, #1, #0x1f
    // 0xf3719c: mov             x0, x1
    // 0xf371a0: mov             x1, x3
    // 0xf371a4: cmp             x1, x0
    // 0xf371a8: b.hs            #0xf37324
    // 0xf371ac: StoreField: r2->field_27 = rNULL
    //     0xf371ac: stur            NULL, [x2, #0x27]
    // 0xf371b0: r0 = Null
    //     0xf371b0: mov             x0, NULL
    // 0xf371b4: LeaveFrame
    //     0xf371b4: mov             SP, fp
    //     0xf371b8: ldp             fp, lr, [SP], #0x10
    // 0xf371bc: ret
    //     0xf371bc: ret             
    // 0xf371c0: mov             x0, x3
    // 0xf371c4: r0 = ConcurrentModificationError()
    //     0xf371c4: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xf371c8: mov             x1, x0
    // 0xf371cc: ldur            x0, [fp, #-0x48]
    // 0xf371d0: StoreField: r1->field_b = r0
    //     0xf371d0: stur            w0, [x1, #0xb]
    // 0xf371d4: mov             x0, x1
    // 0xf371d8: r0 = Throw()
    //     0xf371d8: bl              #0x13ddb2c  ; ThrowStub
    // 0xf371dc: brk             #0
    // 0xf371e0: ldur            x0, [fp, #-0x30]
    // 0xf371e4: LoadField: r4 = r0->field_b
    //     0xf371e4: ldur            w4, [x0, #0xb]
    // 0xf371e8: DecompressPointer r4
    //     0xf371e8: add             x4, x4, HEAP, lsl #32
    // 0xf371ec: LoadField: r0 = r4->field_b
    //     0xf371ec: ldur            w0, [x4, #0xb]
    // 0xf371f0: r5 = LoadInt32Instr(r0)
    //     0xf371f0: sbfx            x5, x0, #1, #0x1f
    // 0xf371f4: mov             x0, x5
    // 0xf371f8: mov             x1, x3
    // 0xf371fc: cmp             x1, x0
    // 0xf37200: b.hs            #0xf37328
    // 0xf37204: ArrayLoad: r6 = r4[r3]  ; Unknown_4
    //     0xf37204: add             x16, x4, x3, lsl #2
    //     0xf37208: ldur            w6, [x16, #0xf]
    // 0xf3720c: DecompressPointer r6
    //     0xf3720c: add             x6, x6, HEAP, lsl #32
    // 0xf37210: mov             x0, x6
    // 0xf37214: stur            x6, [fp, #-0x20]
    // 0xf37218: StoreField: r2->field_27 = r0
    //     0xf37218: stur            w0, [x2, #0x27]
    //     0xf3721c: tbz             w0, #0, #0xf37238
    //     0xf37220: ldurb           w16, [x2, #-1]
    //     0xf37224: ldurb           w17, [x0, #-1]
    //     0xf37228: and             x16, x17, x16, lsr #2
    //     0xf3722c: tst             x16, HEAP, lsr #32
    //     0xf37230: b.eq            #0xf37238
    //     0xf37234: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf37238: ubfx            x3, x3, #0, #0x20
    // 0xf3723c: add             w0, w3, #1
    // 0xf37240: ubfx            x5, x5, #0, #0x20
    // 0xf37244: sub             w1, w5, #1
    // 0xf37248: and             x3, x0, x1
    // 0xf3724c: ubfx            x3, x3, #0, #0x20
    // 0xf37250: StoreField: r2->field_1f = r3
    //     0xf37250: stur            x3, [x2, #0x1f]
    // 0xf37254: cmp             w6, NULL
    // 0xf37258: b.ne            #0xf37294
    // 0xf3725c: LoadField: r0 = r2->field_7
    //     0xf3725c: ldur            w0, [x2, #7]
    // 0xf37260: DecompressPointer r0
    //     0xf37260: add             x0, x0, HEAP, lsl #32
    // 0xf37264: mov             x2, x0
    // 0xf37268: mov             x0, x6
    // 0xf3726c: r1 = Null
    //     0xf3726c: mov             x1, NULL
    // 0xf37270: cmp             w2, NULL
    // 0xf37274: b.eq            #0xf37294
    // 0xf37278: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf37278: ldur            w4, [x2, #0x17]
    // 0xf3727c: DecompressPointer r4
    //     0xf3727c: add             x4, x4, HEAP, lsl #32
    // 0xf37280: r8 = X0
    //     0xf37280: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xf37284: LoadField: r9 = r4->field_7
    //     0xf37284: ldur            x9, [x4, #7]
    // 0xf37288: r3 = Null
    //     0xf37288: add             x3, PP, #0x90, lsl #12  ; [pp+0x90a48] Null
    //     0xf3728c: ldr             x3, [x3, #0xa48]
    // 0xf37290: blr             x9
    // 0xf37294: ldur            x0, [fp, #-0x20]
    // 0xf37298: LoadField: r1 = r0->field_13
    //     0xf37298: ldur            w1, [x0, #0x13]
    // 0xf3729c: DecompressPointer r1
    //     0xf3729c: add             x1, x1, HEAP, lsl #32
    // 0xf372a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf372a4: cmp             w1, w16
    // 0xf372a8: b.eq            #0xf3732c
    // 0xf372ac: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xf372ac: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xf372b0: r0 = Throw()
    //     0xf372b0: bl              #0x13ddb2c  ; ThrowStub
    // 0xf372b4: brk             #0
    // 0xf372b8: r0 = ConcurrentModificationError()
    //     0xf372b8: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xf372bc: mov             x1, x0
    // 0xf372c0: ldur            x0, [fp, #-0x18]
    // 0xf372c4: StoreField: r1->field_b = r0
    //     0xf372c4: stur            w0, [x1, #0xb]
    // 0xf372c8: mov             x0, x1
    // 0xf372cc: r0 = Throw()
    //     0xf372cc: bl              #0x13ddb2c  ; ThrowStub
    // 0xf372d0: brk             #0
    // 0xf372d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf372d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf372d8: b               #0xf36d20
    // 0xf372dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf372dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf372e0: b               #0xf36d48
    // 0xf372e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf372e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf372e8: b               #0xf36dbc
    // 0xf372ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf372ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf372f0: b               #0xf36e18
    // 0xf372f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf372f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf372f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf372f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf372fc: b               #0xf36f0c
    // 0xf37300: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf37300: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xf37304: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf37304: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf37308: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf37308: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3730c: b               #0xf37028
    // 0xf37310: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf37310: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xf37314: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf37314: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xf37318: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf37318: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3731c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf3731c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xf37320: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf37320: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf37324: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf37324: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xf37328: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf37328: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xf3732c: r9 = controller
    //     0xf3732c: add             x9, PP, #0x90, lsl #12  ; [pp+0x90a58] Field <_Circle@40237691.controller>: late (offset: 0x14)
    //     0xf37330: ldr             x9, [x9, #0xa58]
    // 0xf37334: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf37334: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _rebuild(dynamic) {
    // ** addr: 0xf37358, size: 0x38
    // 0xf37358: EnterFrame
    //     0xf37358: stp             fp, lr, [SP, #-0x10]!
    //     0xf3735c: mov             fp, SP
    // 0xf37360: ldr             x0, [fp, #0x10]
    // 0xf37364: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf37364: ldur            w1, [x0, #0x17]
    // 0xf37368: DecompressPointer r1
    //     0xf37368: add             x1, x1, HEAP, lsl #32
    // 0xf3736c: CheckStackOverflow
    //     0xf3736c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf37370: cmp             SP, x16
    //     0xf37374: b.ls            #0xf37388
    // 0xf37378: r0 = _rebuild()
    //     0xf37378: bl              #0xf37390  ; [package:flutter/src/material/bottom_navigation_bar.dart] _BottomNavigationBarState::_rebuild
    // 0xf3737c: LeaveFrame
    //     0xf3737c: mov             SP, fp
    //     0xf37380: ldp             fp, lr, [SP], #0x10
    // 0xf37384: ret
    //     0xf37384: ret             
    // 0xf37388: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf37388: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3738c: b               #0xf37378
  }
  _ _rebuild(/* No info */) {
    // ** addr: 0xf37390, size: 0x54
    // 0xf37390: EnterFrame
    //     0xf37390: stp             fp, lr, [SP, #-0x10]!
    //     0xf37394: mov             fp, SP
    // 0xf37398: AllocStack(0x8)
    //     0xf37398: sub             SP, SP, #8
    // 0xf3739c: SetupParameters(_BottomNavigationBarState this /* r1 => r0, fp-0x8 */)
    //     0xf3739c: mov             x0, x1
    //     0xf373a0: stur            x1, [fp, #-8]
    // 0xf373a4: CheckStackOverflow
    //     0xf373a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf373a8: cmp             SP, x16
    //     0xf373ac: b.ls            #0xf373dc
    // 0xf373b0: r1 = Function '<anonymous closure>':.
    //     0xf373b0: add             x1, PP, #0x90, lsl #12  ; [pp+0x90a60] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xf373b4: ldr             x1, [x1, #0xa60]
    // 0xf373b8: r2 = Null
    //     0xf373b8: mov             x2, NULL
    // 0xf373bc: r0 = AllocateClosure()
    //     0xf373bc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf373c0: ldur            x1, [fp, #-8]
    // 0xf373c4: mov             x2, x0
    // 0xf373c8: r0 = setState()
    //     0xf373c8: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf373cc: r0 = Null
    //     0xf373cc: mov             x0, NULL
    // 0xf373d0: LeaveFrame
    //     0xf373d0: mov             SP, fp
    //     0xf373d4: ldp             fp, lr, [SP], #0x10
    // 0xf373d8: ret
    //     0xf373d8: ret             
    // 0xf373dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf373dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf373e0: b               #0xf373b0
  }
  _ initState(/* No info */) {
    // ** addr: 0xf79164, size: 0x30
    // 0xf79164: EnterFrame
    //     0xf79164: stp             fp, lr, [SP, #-0x10]!
    //     0xf79168: mov             fp, SP
    // 0xf7916c: CheckStackOverflow
    //     0xf7916c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf79170: cmp             SP, x16
    //     0xf79174: b.ls            #0xf7918c
    // 0xf79178: r0 = _resetState()
    //     0xf79178: bl              #0xf36d00  ; [package:flutter/src/material/bottom_navigation_bar.dart] _BottomNavigationBarState::_resetState
    // 0xf7917c: r0 = Null
    //     0xf7917c: mov             x0, NULL
    // 0xf79180: LeaveFrame
    //     0xf79180: mov             SP, fp
    //     0xf79184: ldp             fp, lr, [SP], #0x10
    // 0xf79188: ret
    //     0xf79188: ret             
    // 0xf7918c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7918c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf79190: b               #0xf79178
  }
  _ _BottomNavigationBarState(/* No info */) {
    // ** addr: 0xfa0b30, size: 0xd8
    // 0xfa0b30: EnterFrame
    //     0xfa0b30: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0b34: mov             fp, SP
    // 0xfa0b38: AllocStack(0x10)
    //     0xfa0b38: sub             SP, SP, #0x10
    // 0xfa0b3c: SetupParameters(_BottomNavigationBarState this /* r1 => r0, fp-0x8 */)
    //     0xfa0b3c: mov             x0, x1
    //     0xfa0b40: stur            x1, [fp, #-8]
    // 0xfa0b44: CheckStackOverflow
    //     0xfa0b44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa0b48: cmp             SP, x16
    //     0xfa0b4c: b.ls            #0xfa0c00
    // 0xfa0b50: r1 = <AnimationController>
    //     0xfa0b50: add             x1, PP, #0x15, lsl #12  ; [pp+0x15790] TypeArguments: <AnimationController>
    //     0xfa0b54: ldr             x1, [x1, #0x790]
    // 0xfa0b58: r2 = 0
    //     0xfa0b58: mov             x2, #0
    // 0xfa0b5c: r0 = _GrowableList()
    //     0xfa0b5c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfa0b60: ldur            x3, [fp, #-8]
    // 0xfa0b64: StoreField: r3->field_1b = r0
    //     0xfa0b64: stur            w0, [x3, #0x1b]
    //     0xfa0b68: ldurb           w16, [x3, #-1]
    //     0xfa0b6c: ldurb           w17, [x0, #-1]
    //     0xfa0b70: and             x16, x17, x16, lsr #2
    //     0xfa0b74: tst             x16, HEAP, lsr #32
    //     0xfa0b78: b.eq            #0xfa0b80
    //     0xfa0b7c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xfa0b80: r1 = <CurvedAnimation>
    //     0xfa0b80: add             x1, PP, #0x85, lsl #12  ; [pp+0x85370] TypeArguments: <CurvedAnimation>
    //     0xfa0b84: ldr             x1, [x1, #0x370]
    // 0xfa0b88: r2 = 0
    //     0xfa0b88: mov             x2, #0
    // 0xfa0b8c: r0 = _GrowableList()
    //     0xfa0b8c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfa0b90: ldur            x2, [fp, #-8]
    // 0xfa0b94: StoreField: r2->field_1f = r0
    //     0xfa0b94: stur            w0, [x2, #0x1f]
    //     0xfa0b98: ldurb           w16, [x2, #-1]
    //     0xfa0b9c: ldurb           w17, [x0, #-1]
    //     0xfa0ba0: and             x16, x17, x16, lsr #2
    //     0xfa0ba4: tst             x16, HEAP, lsr #32
    //     0xfa0ba8: b.eq            #0xfa0bb0
    //     0xfa0bac: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfa0bb0: r1 = <_Circle>
    //     0xfa0bb0: add             x1, PP, #0x85, lsl #12  ; [pp+0x85378] TypeArguments: <_Circle>
    //     0xfa0bb4: ldr             x1, [x1, #0x378]
    // 0xfa0bb8: r0 = ListQueue()
    //     0xfa0bb8: bl              #0x8217c0  ; AllocateListQueueStub -> ListQueue<X0> (size=0x28)
    // 0xfa0bbc: mov             x1, x0
    // 0xfa0bc0: stur            x0, [fp, #-0x10]
    // 0xfa0bc4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xfa0bc4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xfa0bc8: r0 = ListQueue()
    //     0xfa0bc8: bl              #0x821650  ; [dart:collection] ListQueue::ListQueue
    // 0xfa0bcc: ldur            x0, [fp, #-0x10]
    // 0xfa0bd0: ldur            x1, [fp, #-8]
    // 0xfa0bd4: StoreField: r1->field_23 = r0
    //     0xfa0bd4: stur            w0, [x1, #0x23]
    //     0xfa0bd8: ldurb           w16, [x1, #-1]
    //     0xfa0bdc: ldurb           w17, [x0, #-1]
    //     0xfa0be0: and             x16, x17, x16, lsr #2
    //     0xfa0be4: tst             x16, HEAP, lsr #32
    //     0xfa0be8: b.eq            #0xfa0bf0
    //     0xfa0bec: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa0bf0: r0 = Null
    //     0xfa0bf0: mov             x0, NULL
    // 0xfa0bf4: LeaveFrame
    //     0xfa0bf4: mov             SP, fp
    //     0xfa0bf8: ldp             fp, lr, [SP], #0x10
    // 0xfa0bfc: ret
    //     0xfa0bfc: ret             
    // 0xfa0c00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa0c00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa0c04: b               #0xfa0b50
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10dbe10, size: 0x2f8
    // 0x10dbe10: EnterFrame
    //     0x10dbe10: stp             fp, lr, [SP, #-0x10]!
    //     0x10dbe14: mov             fp, SP
    // 0x10dbe18: AllocStack(0x40)
    //     0x10dbe18: sub             SP, SP, #0x40
    // 0x10dbe1c: SetupParameters(_BottomNavigationBarState this /* r1 => r0, fp-0x20 */)
    //     0x10dbe1c: mov             x0, x1
    //     0x10dbe20: stur            x1, [fp, #-0x20]
    // 0x10dbe24: CheckStackOverflow
    //     0x10dbe24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10dbe28: cmp             SP, x16
    //     0x10dbe2c: b.ls            #0x10dc0d8
    // 0x10dbe30: LoadField: r2 = r0->field_1b
    //     0x10dbe30: ldur            w2, [x0, #0x1b]
    // 0x10dbe34: DecompressPointer r2
    //     0x10dbe34: add             x2, x2, HEAP, lsl #32
    // 0x10dbe38: stur            x2, [fp, #-0x18]
    // 0x10dbe3c: LoadField: r1 = r2->field_b
    //     0x10dbe3c: ldur            w1, [x2, #0xb]
    // 0x10dbe40: r3 = LoadInt32Instr(r1)
    //     0x10dbe40: sbfx            x3, x1, #1, #0x1f
    // 0x10dbe44: stur            x3, [fp, #-0x10]
    // 0x10dbe48: r1 = 0
    //     0x10dbe48: mov             x1, #0
    // 0x10dbe4c: CheckStackOverflow
    //     0x10dbe4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10dbe50: cmp             SP, x16
    //     0x10dbe54: b.ls            #0x10dc0e0
    // 0x10dbe58: LoadField: r4 = r2->field_b
    //     0x10dbe58: ldur            w4, [x2, #0xb]
    // 0x10dbe5c: r5 = LoadInt32Instr(r4)
    //     0x10dbe5c: sbfx            x5, x4, #1, #0x1f
    // 0x10dbe60: cmp             x3, x5
    // 0x10dbe64: b.ne            #0x10dc0b8
    // 0x10dbe68: cmp             x1, x5
    // 0x10dbe6c: b.ge            #0x10dbea8
    // 0x10dbe70: LoadField: r4 = r2->field_f
    //     0x10dbe70: ldur            w4, [x2, #0xf]
    // 0x10dbe74: DecompressPointer r4
    //     0x10dbe74: add             x4, x4, HEAP, lsl #32
    // 0x10dbe78: ArrayLoad: r5 = r4[r1]  ; Unknown_4
    //     0x10dbe78: add             x16, x4, x1, lsl #2
    //     0x10dbe7c: ldur            w5, [x16, #0xf]
    // 0x10dbe80: DecompressPointer r5
    //     0x10dbe80: add             x5, x5, HEAP, lsl #32
    // 0x10dbe84: add             x4, x1, #1
    // 0x10dbe88: mov             x1, x5
    // 0x10dbe8c: stur            x4, [fp, #-8]
    // 0x10dbe90: r0 = dispose()
    //     0x10dbe90: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10dbe94: ldur            x1, [fp, #-8]
    // 0x10dbe98: ldur            x0, [fp, #-0x20]
    // 0x10dbe9c: ldur            x2, [fp, #-0x18]
    // 0x10dbea0: ldur            x3, [fp, #-0x10]
    // 0x10dbea4: b               #0x10dbe4c
    // 0x10dbea8: LoadField: r1 = r0->field_23
    //     0x10dbea8: ldur            w1, [x0, #0x23]
    // 0x10dbeac: DecompressPointer r1
    //     0x10dbeac: add             x1, x1, HEAP, lsl #32
    // 0x10dbeb0: r0 = iterator()
    //     0x10dbeb0: bl              #0xb09254  ; [dart:collection] ListQueue::iterator
    // 0x10dbeb4: stur            x0, [fp, #-0x30]
    // 0x10dbeb8: CheckStackOverflow
    //     0x10dbeb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10dbebc: cmp             SP, x16
    //     0x10dbec0: b.ls            #0x10dc0e8
    // 0x10dbec4: LoadField: r3 = r0->field_b
    //     0x10dbec4: ldur            w3, [x0, #0xb]
    // 0x10dbec8: DecompressPointer r3
    //     0x10dbec8: add             x3, x3, HEAP, lsl #32
    // 0x10dbecc: stur            x3, [fp, #-0x28]
    // 0x10dbed0: ArrayLoad: r2 = r0[0]  ; List_8
    //     0x10dbed0: ldur            x2, [x0, #0x17]
    // 0x10dbed4: mov             x1, x3
    // 0x10dbed8: r0 = _checkModification()
    //     0x10dbed8: bl              #0x802db8  ; [dart:collection] ListQueue::_checkModification
    // 0x10dbedc: ldur            x2, [fp, #-0x30]
    // 0x10dbee0: LoadField: r3 = r2->field_1f
    //     0x10dbee0: ldur            x3, [x2, #0x1f]
    // 0x10dbee4: LoadField: r0 = r2->field_f
    //     0x10dbee4: ldur            x0, [x2, #0xf]
    // 0x10dbee8: cmp             x3, x0
    // 0x10dbeec: b.ne            #0x10dbfe0
    // 0x10dbef0: ldur            x0, [fp, #-0x20]
    // 0x10dbef4: StoreField: r2->field_27 = rNULL
    //     0x10dbef4: stur            NULL, [x2, #0x27]
    // 0x10dbef8: LoadField: r3 = r0->field_1f
    //     0x10dbef8: ldur            w3, [x0, #0x1f]
    // 0x10dbefc: DecompressPointer r3
    //     0x10dbefc: add             x3, x3, HEAP, lsl #32
    // 0x10dbf00: stur            x3, [fp, #-0x40]
    // 0x10dbf04: LoadField: r1 = r3->field_b
    //     0x10dbf04: ldur            w1, [x3, #0xb]
    // 0x10dbf08: r4 = LoadInt32Instr(r1)
    //     0x10dbf08: sbfx            x4, x1, #1, #0x1f
    // 0x10dbf0c: stur            x4, [fp, #-0x10]
    // 0x10dbf10: r1 = 0
    //     0x10dbf10: mov             x1, #0
    // 0x10dbf14: CheckStackOverflow
    //     0x10dbf14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10dbf18: cmp             SP, x16
    //     0x10dbf1c: b.ls            #0x10dc0f0
    // 0x10dbf20: LoadField: r2 = r3->field_b
    //     0x10dbf20: ldur            w2, [x3, #0xb]
    // 0x10dbf24: r5 = LoadInt32Instr(r2)
    //     0x10dbf24: sbfx            x5, x2, #1, #0x1f
    // 0x10dbf28: cmp             x4, x5
    // 0x10dbf2c: b.ne            #0x10dbfc0
    // 0x10dbf30: cmp             x1, x5
    // 0x10dbf34: b.ge            #0x10dbfa8
    // 0x10dbf38: LoadField: r2 = r3->field_f
    //     0x10dbf38: ldur            w2, [x3, #0xf]
    // 0x10dbf3c: DecompressPointer r2
    //     0x10dbf3c: add             x2, x2, HEAP, lsl #32
    // 0x10dbf40: ArrayLoad: r5 = r2[r1]  ; Unknown_4
    //     0x10dbf40: add             x16, x2, x1, lsl #2
    //     0x10dbf44: ldur            w5, [x16, #0xf]
    // 0x10dbf48: DecompressPointer r5
    //     0x10dbf48: add             x5, x5, HEAP, lsl #32
    // 0x10dbf4c: add             x6, x1, #1
    // 0x10dbf50: stur            x6, [fp, #-8]
    // 0x10dbf54: LoadField: r7 = r5->field_b
    //     0x10dbf54: ldur            w7, [x5, #0xb]
    // 0x10dbf58: DecompressPointer r7
    //     0x10dbf58: add             x7, x7, HEAP, lsl #32
    // 0x10dbf5c: mov             x2, x5
    // 0x10dbf60: stur            x7, [fp, #-0x38]
    // 0x10dbf64: r1 = Function '_updateCurveDirection@63411118':.
    //     0x10dbf64: add             x1, PP, #0x16, lsl #12  ; [pp+0x16de0] AnonymousClosure: (0x915e10), in [package:flutter/src/animation/animations.dart] CurvedAnimation::_updateCurveDirection (0x915d94)
    //     0x10dbf68: ldr             x1, [x1, #0xde0]
    // 0x10dbf6c: r0 = AllocateClosure()
    //     0x10dbf6c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10dbf70: ldur            x1, [fp, #-0x38]
    // 0x10dbf74: r2 = LoadClassIdInstr(r1)
    //     0x10dbf74: ldur            x2, [x1, #-1]
    //     0x10dbf78: ubfx            x2, x2, #0xc, #0x14
    // 0x10dbf7c: mov             x16, x0
    // 0x10dbf80: mov             x0, x2
    // 0x10dbf84: mov             x2, x16
    // 0x10dbf88: r0 = GDT[cid_x0 + 0xabe]()
    //     0x10dbf88: add             lr, x0, #0xabe
    //     0x10dbf8c: ldr             lr, [x21, lr, lsl #3]
    //     0x10dbf90: blr             lr
    // 0x10dbf94: ldur            x1, [fp, #-8]
    // 0x10dbf98: ldur            x0, [fp, #-0x20]
    // 0x10dbf9c: ldur            x3, [fp, #-0x40]
    // 0x10dbfa0: ldur            x4, [fp, #-0x10]
    // 0x10dbfa4: b               #0x10dbf14
    // 0x10dbfa8: ldur            x1, [fp, #-0x20]
    // 0x10dbfac: r0 = dispose()
    //     0x10dbfac: bl              #0x10dc108  ; [dart:mixin_deduplication] _MixinApplication11&State&TickerProviderStateMixin::dispose
    // 0x10dbfb0: r0 = Null
    //     0x10dbfb0: mov             x0, NULL
    // 0x10dbfb4: LeaveFrame
    //     0x10dbfb4: mov             SP, fp
    //     0x10dbfb8: ldp             fp, lr, [SP], #0x10
    // 0x10dbfbc: ret
    //     0x10dbfbc: ret             
    // 0x10dbfc0: mov             x0, x3
    // 0x10dbfc4: r0 = ConcurrentModificationError()
    //     0x10dbfc4: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x10dbfc8: mov             x1, x0
    // 0x10dbfcc: ldur            x0, [fp, #-0x40]
    // 0x10dbfd0: StoreField: r1->field_b = r0
    //     0x10dbfd0: stur            w0, [x1, #0xb]
    // 0x10dbfd4: mov             x0, x1
    // 0x10dbfd8: r0 = Throw()
    //     0x10dbfd8: bl              #0x13ddb2c  ; ThrowStub
    // 0x10dbfdc: brk             #0
    // 0x10dbfe0: ldur            x0, [fp, #-0x28]
    // 0x10dbfe4: LoadField: r4 = r0->field_b
    //     0x10dbfe4: ldur            w4, [x0, #0xb]
    // 0x10dbfe8: DecompressPointer r4
    //     0x10dbfe8: add             x4, x4, HEAP, lsl #32
    // 0x10dbfec: LoadField: r0 = r4->field_b
    //     0x10dbfec: ldur            w0, [x4, #0xb]
    // 0x10dbff0: r5 = LoadInt32Instr(r0)
    //     0x10dbff0: sbfx            x5, x0, #1, #0x1f
    // 0x10dbff4: mov             x0, x5
    // 0x10dbff8: mov             x1, x3
    // 0x10dbffc: cmp             x1, x0
    // 0x10dc000: b.hs            #0x10dc0f8
    // 0x10dc004: ArrayLoad: r6 = r4[r3]  ; Unknown_4
    //     0x10dc004: add             x16, x4, x3, lsl #2
    //     0x10dc008: ldur            w6, [x16, #0xf]
    // 0x10dc00c: DecompressPointer r6
    //     0x10dc00c: add             x6, x6, HEAP, lsl #32
    // 0x10dc010: mov             x0, x6
    // 0x10dc014: stur            x6, [fp, #-0x20]
    // 0x10dc018: StoreField: r2->field_27 = r0
    //     0x10dc018: stur            w0, [x2, #0x27]
    //     0x10dc01c: tbz             w0, #0, #0x10dc038
    //     0x10dc020: ldurb           w16, [x2, #-1]
    //     0x10dc024: ldurb           w17, [x0, #-1]
    //     0x10dc028: and             x16, x17, x16, lsr #2
    //     0x10dc02c: tst             x16, HEAP, lsr #32
    //     0x10dc030: b.eq            #0x10dc038
    //     0x10dc034: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x10dc038: ubfx            x3, x3, #0, #0x20
    // 0x10dc03c: add             w0, w3, #1
    // 0x10dc040: ubfx            x5, x5, #0, #0x20
    // 0x10dc044: sub             w1, w5, #1
    // 0x10dc048: and             x3, x0, x1
    // 0x10dc04c: ubfx            x3, x3, #0, #0x20
    // 0x10dc050: StoreField: r2->field_1f = r3
    //     0x10dc050: stur            x3, [x2, #0x1f]
    // 0x10dc054: cmp             w6, NULL
    // 0x10dc058: b.ne            #0x10dc094
    // 0x10dc05c: LoadField: r0 = r2->field_7
    //     0x10dc05c: ldur            w0, [x2, #7]
    // 0x10dc060: DecompressPointer r0
    //     0x10dc060: add             x0, x0, HEAP, lsl #32
    // 0x10dc064: mov             x2, x0
    // 0x10dc068: mov             x0, x6
    // 0x10dc06c: r1 = Null
    //     0x10dc06c: mov             x1, NULL
    // 0x10dc070: cmp             w2, NULL
    // 0x10dc074: b.eq            #0x10dc094
    // 0x10dc078: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x10dc078: ldur            w4, [x2, #0x17]
    // 0x10dc07c: DecompressPointer r4
    //     0x10dc07c: add             x4, x4, HEAP, lsl #32
    // 0x10dc080: r8 = X0
    //     0x10dc080: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x10dc084: LoadField: r9 = r4->field_7
    //     0x10dc084: ldur            x9, [x4, #7]
    // 0x10dc088: r3 = Null
    //     0x10dc088: add             x3, PP, #0x90, lsl #12  ; [pp+0x90a68] Null
    //     0x10dc08c: ldr             x3, [x3, #0xa68]
    // 0x10dc090: blr             x9
    // 0x10dc094: ldur            x0, [fp, #-0x20]
    // 0x10dc098: LoadField: r1 = r0->field_13
    //     0x10dc098: ldur            w1, [x0, #0x13]
    // 0x10dc09c: DecompressPointer r1
    //     0x10dc09c: add             x1, x1, HEAP, lsl #32
    // 0x10dc0a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10dc0a4: cmp             w1, w16
    // 0x10dc0a8: b.eq            #0x10dc0fc
    // 0x10dc0ac: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x10dc0ac: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x10dc0b0: r0 = Throw()
    //     0x10dc0b0: bl              #0x13ddb2c  ; ThrowStub
    // 0x10dc0b4: brk             #0
    // 0x10dc0b8: mov             x0, x2
    // 0x10dc0bc: r0 = ConcurrentModificationError()
    //     0x10dc0bc: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x10dc0c0: mov             x1, x0
    // 0x10dc0c4: ldur            x0, [fp, #-0x18]
    // 0x10dc0c8: StoreField: r1->field_b = r0
    //     0x10dc0c8: stur            w0, [x1, #0xb]
    // 0x10dc0cc: mov             x0, x1
    // 0x10dc0d0: r0 = Throw()
    //     0x10dc0d0: bl              #0x13ddb2c  ; ThrowStub
    // 0x10dc0d4: brk             #0
    // 0x10dc0d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dc0d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dc0dc: b               #0x10dbe30
    // 0x10dc0e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dc0e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dc0e4: b               #0x10dbe58
    // 0x10dc0e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dc0e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dc0ec: b               #0x10dbec4
    // 0x10dc0f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dc0f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dc0f4: b               #0x10dbf20
    // 0x10dc0f8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x10dc0f8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x10dc0fc: r9 = controller
    //     0x10dc0fc: add             x9, PP, #0x90, lsl #12  ; [pp+0x90a58] Field <_Circle@40237691.controller>: late (offset: 0x14)
    //     0x10dc100: ldr             x9, [x9, #0xa58]
    // 0x10dc104: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10dc104: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 6179, size: 0x20, field offset: 0xc
//   const constructor, 
class _Bar extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfb2b74, size: 0xb0
    // 0xfb2b74: EnterFrame
    //     0xfb2b74: stp             fp, lr, [SP, #-0x10]!
    //     0xfb2b78: mov             fp, SP
    // 0xfb2b7c: AllocStack(0x20)
    //     0xfb2b7c: sub             SP, SP, #0x20
    // 0xfb2b80: SetupParameters(_Bar this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r1 */)
    //     0xfb2b80: mov             x0, x1
    //     0xfb2b84: stur            x1, [fp, #-0x10]
    //     0xfb2b88: mov             x1, x2
    // 0xfb2b8c: CheckStackOverflow
    //     0xfb2b8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb2b90: cmp             SP, x16
    //     0xfb2b94: b.ls            #0xfb2c1c
    // 0xfb2b98: LoadField: r2 = r0->field_b
    //     0xfb2b98: ldur            w2, [x0, #0xb]
    // 0xfb2b9c: DecompressPointer r2
    //     0xfb2b9c: add             x2, x2, HEAP, lsl #32
    // 0xfb2ba0: stur            x2, [fp, #-8]
    // 0xfb2ba4: r0 = orientationOf()
    //     0xfb2ba4: bl              #0xd172a4  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::orientationOf
    // 0xfb2ba8: ldur            x0, [fp, #-0x10]
    // 0xfb2bac: LoadField: d0 = r0->field_13
    //     0xfb2bac: ldur            d0, [x0, #0x13]
    // 0xfb2bb0: stur            d0, [fp, #-0x20]
    // 0xfb2bb4: LoadField: r1 = r0->field_1b
    //     0xfb2bb4: ldur            w1, [x0, #0x1b]
    // 0xfb2bb8: DecompressPointer r1
    //     0xfb2bb8: add             x1, x1, HEAP, lsl #32
    // 0xfb2bbc: stur            x1, [fp, #-0x18]
    // 0xfb2bc0: r0 = Material()
    //     0xfb2bc0: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xfb2bc4: r1 = Instance_MaterialType
    //     0xfb2bc4: add             x1, PP, #0x17, lsl #12  ; [pp+0x17210] Obj!MaterialType@12c5341
    //     0xfb2bc8: ldr             x1, [x1, #0x210]
    // 0xfb2bcc: StoreField: r0->field_f = r1
    //     0xfb2bcc: stur            w1, [x0, #0xf]
    // 0xfb2bd0: ldur            d0, [fp, #-0x20]
    // 0xfb2bd4: ArrayStore: r0[0] = d0  ; List_8
    //     0xfb2bd4: stur            d0, [x0, #0x17]
    // 0xfb2bd8: ldur            x1, [fp, #-0x18]
    // 0xfb2bdc: StoreField: r0->field_1f = r1
    //     0xfb2bdc: stur            w1, [x0, #0x1f]
    // 0xfb2be0: r1 = true
    //     0xfb2be0: add             x1, NULL, #0x20  ; true
    // 0xfb2be4: StoreField: r0->field_33 = r1
    //     0xfb2be4: stur            w1, [x0, #0x33]
    // 0xfb2be8: r1 = Instance_Clip
    //     0xfb2be8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb2bec: ldr             x1, [x1, #0x840]
    // 0xfb2bf0: StoreField: r0->field_37 = r1
    //     0xfb2bf0: stur            w1, [x0, #0x37]
    // 0xfb2bf4: r1 = Instance_Duration
    //     0xfb2bf4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xfb2bf8: ldr             x1, [x1, #0x318]
    // 0xfb2bfc: StoreField: r0->field_3b = r1
    //     0xfb2bfc: stur            w1, [x0, #0x3b]
    // 0xfb2c00: ldur            x1, [fp, #-8]
    // 0xfb2c04: StoreField: r0->field_b = r1
    //     0xfb2c04: stur            w1, [x0, #0xb]
    // 0xfb2c08: r1 = false
    //     0xfb2c08: add             x1, NULL, #0x30  ; false
    // 0xfb2c0c: StoreField: r0->field_13 = r1
    //     0xfb2c0c: stur            w1, [x0, #0x13]
    // 0xfb2c10: LeaveFrame
    //     0xfb2c10: mov             SP, fp
    //     0xfb2c14: ldp             fp, lr, [SP], #0x10
    // 0xfb2c18: ret
    //     0xfb2c18: ret             
    // 0xfb2c1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb2c1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb2c20: b               #0xfb2b98
  }
}

// class id: 6180, size: 0x28, field offset: 0xc
//   const constructor, 
class _Label extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfb0a6c, size: 0x224
    // 0xfb0a6c: EnterFrame
    //     0xfb0a6c: stp             fp, lr, [SP, #-0x10]!
    //     0xfb0a70: mov             fp, SP
    // 0xfb0a74: AllocStack(0x40)
    //     0xfb0a74: sub             SP, SP, #0x40
    // 0xfb0a78: SetupParameters(_Label this /* r1 => r0, fp-0x30 */)
    //     0xfb0a78: mov             x0, x1
    //     0xfb0a7c: stur            x1, [fp, #-0x30]
    // 0xfb0a80: CheckStackOverflow
    //     0xfb0a80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb0a84: cmp             SP, x16
    //     0xfb0a88: b.ls            #0xfb0c68
    // 0xfb0a8c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xfb0a8c: ldur            w2, [x0, #0x17]
    // 0xfb0a90: DecompressPointer r2
    //     0xfb0a90: add             x2, x2, HEAP, lsl #32
    // 0xfb0a94: stur            x2, [fp, #-0x28]
    // 0xfb0a98: LoadField: r3 = r2->field_1f
    //     0xfb0a98: ldur            w3, [x2, #0x1f]
    // 0xfb0a9c: DecompressPointer r3
    //     0xfb0a9c: add             x3, x3, HEAP, lsl #32
    // 0xfb0aa0: stur            x3, [fp, #-0x20]
    // 0xfb0aa4: LoadField: r4 = r0->field_1b
    //     0xfb0aa4: ldur            w4, [x0, #0x1b]
    // 0xfb0aa8: DecompressPointer r4
    //     0xfb0aa8: add             x4, x4, HEAP, lsl #32
    // 0xfb0aac: stur            x4, [fp, #-0x18]
    // 0xfb0ab0: LoadField: r5 = r4->field_1f
    //     0xfb0ab0: ldur            w5, [x4, #0x1f]
    // 0xfb0ab4: DecompressPointer r5
    //     0xfb0ab4: add             x5, x5, HEAP, lsl #32
    // 0xfb0ab8: stur            x5, [fp, #-0x10]
    // 0xfb0abc: LoadField: r6 = r0->field_f
    //     0xfb0abc: ldur            w6, [x0, #0xf]
    // 0xfb0ac0: DecompressPointer r6
    //     0xfb0ac0: add             x6, x6, HEAP, lsl #32
    // 0xfb0ac4: mov             x1, x6
    // 0xfb0ac8: stur            x6, [fp, #-8]
    // 0xfb0acc: r0 = value()
    //     0xfb0acc: bl              #0xae5f84  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xfb0ad0: ldur            x1, [fp, #-0x18]
    // 0xfb0ad4: ldur            x2, [fp, #-0x28]
    // 0xfb0ad8: mov             x3, x0
    // 0xfb0adc: r0 = lerp()
    //     0xfb0adc: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xfb0ae0: mov             x3, x0
    // 0xfb0ae4: ldur            x0, [fp, #-0x30]
    // 0xfb0ae8: stur            x3, [fp, #-0x18]
    // 0xfb0aec: LoadField: r1 = r0->field_b
    //     0xfb0aec: ldur            w1, [x0, #0xb]
    // 0xfb0af0: DecompressPointer r1
    //     0xfb0af0: add             x1, x1, HEAP, lsl #32
    // 0xfb0af4: ldur            x2, [fp, #-8]
    // 0xfb0af8: r0 = evaluate()
    //     0xfb0af8: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xfb0afc: ldur            x16, [fp, #-0x20]
    // 0xfb0b00: stp             x0, x16, [SP]
    // 0xfb0b04: ldur            x1, [fp, #-0x18]
    // 0xfb0b08: r4 = const [0, 0x3, 0x2, 0x1, color, 0x2, fontSize, 0x1, null]
    //     0xfb0b08: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1fc10] List(9) [0, 0x3, 0x2, 0x1, "color", 0x2, "fontSize", 0x1, Null]
    //     0xfb0b0c: ldr             x4, [x4, #0xc10]
    // 0xfb0b10: r0 = copyWith()
    //     0xfb0b10: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xfb0b14: mov             x2, x0
    // 0xfb0b18: ldur            x0, [fp, #-0x10]
    // 0xfb0b1c: stur            x2, [fp, #-0x18]
    // 0xfb0b20: cmp             w0, NULL
    // 0xfb0b24: b.eq            #0xfb0c70
    // 0xfb0b28: ldur            x1, [fp, #-0x20]
    // 0xfb0b2c: cmp             w1, NULL
    // 0xfb0b30: b.eq            #0xfb0c74
    // 0xfb0b34: LoadField: d0 = r0->field_7
    //     0xfb0b34: ldur            d0, [x0, #7]
    // 0xfb0b38: LoadField: d1 = r1->field_7
    //     0xfb0b38: ldur            d1, [x1, #7]
    // 0xfb0b3c: fdiv            d2, d0, d1
    // 0xfb0b40: r0 = inline_Allocate_Double()
    //     0xfb0b40: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xfb0b44: add             x0, x0, #0x10
    //     0xfb0b48: cmp             x1, x0
    //     0xfb0b4c: b.ls            #0xfb0c78
    //     0xfb0b50: str             x0, [THR, #0x60]  ; THR::top
    //     0xfb0b54: sub             x0, x0, #0xf
    //     0xfb0b58: mov             x1, #0xe19c
    //     0xfb0b5c: movk            x1, #3, lsl #16
    //     0xfb0b60: stur            x1, [x0, #-1]
    // 0xfb0b64: dmb             ishst
    // 0xfb0b68: StoreField: r0->field_7 = d2
    //     0xfb0b68: stur            d2, [x0, #7]
    // 0xfb0b6c: stur            x0, [fp, #-0x10]
    // 0xfb0b70: r1 = <double>
    //     0xfb0b70: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfb0b74: r0 = Tween()
    //     0xfb0b74: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xfb0b78: mov             x1, x0
    // 0xfb0b7c: ldur            x0, [fp, #-0x10]
    // 0xfb0b80: StoreField: r1->field_b = r0
    //     0xfb0b80: stur            w0, [x1, #0xb]
    // 0xfb0b84: r0 = 1.000000
    //     0xfb0b84: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xfb0b88: StoreField: r1->field_f = r0
    //     0xfb0b88: stur            w0, [x1, #0xf]
    // 0xfb0b8c: ldur            x2, [fp, #-8]
    // 0xfb0b90: r0 = evaluate()
    //     0xfb0b90: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xfb0b94: LoadField: d0 = r0->field_7
    //     0xfb0b94: ldur            d0, [x0, #7]
    // 0xfb0b98: r1 = Null
    //     0xfb0b98: mov             x1, NULL
    // 0xfb0b9c: r0 = Vector3.all()
    //     0xfb0b9c: bl              #0xfb0d10  ; [package:vector_math/vector_math_64.dart] Vector3::Vector3.all
    // 0xfb0ba0: mov             x2, x0
    // 0xfb0ba4: r1 = Null
    //     0xfb0ba4: mov             x1, NULL
    // 0xfb0ba8: r0 = Matrix4.diagonal3()
    //     0xfb0ba8: bl              #0xfb0c90  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.diagonal3
    // 0xfb0bac: mov             x1, x0
    // 0xfb0bb0: ldur            x0, [fp, #-0x30]
    // 0xfb0bb4: stur            x1, [fp, #-0x10]
    // 0xfb0bb8: LoadField: r2 = r0->field_13
    //     0xfb0bb8: ldur            w2, [x0, #0x13]
    // 0xfb0bbc: DecompressPointer r2
    //     0xfb0bbc: add             x2, x2, HEAP, lsl #32
    // 0xfb0bc0: LoadField: r0 = r2->field_13
    //     0xfb0bc0: ldur            w0, [x2, #0x13]
    // 0xfb0bc4: DecompressPointer r0
    //     0xfb0bc4: add             x0, x0, HEAP, lsl #32
    // 0xfb0bc8: stur            x0, [fp, #-8]
    // 0xfb0bcc: r0 = Text()
    //     0xfb0bcc: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xfb0bd0: mov             x1, x0
    // 0xfb0bd4: ldur            x0, [fp, #-8]
    // 0xfb0bd8: stur            x1, [fp, #-0x20]
    // 0xfb0bdc: StoreField: r1->field_b = r0
    //     0xfb0bdc: stur            w0, [x1, #0xb]
    // 0xfb0be0: r0 = Transform()
    //     0xfb0be0: bl              #0xd30150  ; AllocateTransformStub -> Transform (size=0x24)
    // 0xfb0be4: mov             x1, x0
    // 0xfb0be8: ldur            x0, [fp, #-0x10]
    // 0xfb0bec: StoreField: r1->field_f = r0
    //     0xfb0bec: stur            w0, [x1, #0xf]
    // 0xfb0bf0: r0 = Instance_Alignment
    //     0xfb0bf0: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1b8] Obj!Alignment@129e6f1
    //     0xfb0bf4: ldr             x0, [x0, #0x1b8]
    // 0xfb0bf8: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb0bf8: stur            w0, [x1, #0x17]
    // 0xfb0bfc: r2 = true
    //     0xfb0bfc: add             x2, NULL, #0x20  ; true
    // 0xfb0c00: StoreField: r1->field_1b = r2
    //     0xfb0c00: stur            w2, [x1, #0x1b]
    // 0xfb0c04: ldur            x2, [fp, #-0x20]
    // 0xfb0c08: StoreField: r1->field_b = r2
    //     0xfb0c08: stur            w2, [x1, #0xb]
    // 0xfb0c0c: ldur            x16, [fp, #-0x18]
    // 0xfb0c10: str             x16, [SP]
    // 0xfb0c14: r4 = const [0, 0x2, 0x1, 0x1, style, 0x1, null]
    //     0xfb0c14: add             x4, PP, #0x99, lsl #12  ; [pp+0x99a98] List(7) [0, 0x2, 0x1, 0x1, "style", 0x1, Null]
    //     0xfb0c18: ldr             x4, [x4, #0xa98]
    // 0xfb0c1c: r0 = merge()
    //     0xfb0c1c: bl              #0xd0af30  ; [package:flutter/src/widgets/text.dart] DefaultTextStyle::merge
    // 0xfb0c20: stur            x0, [fp, #-8]
    // 0xfb0c24: r0 = Align()
    //     0xfb0c24: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xfb0c28: mov             x1, x0
    // 0xfb0c2c: r0 = Instance_Alignment
    //     0xfb0c2c: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1b8] Obj!Alignment@129e6f1
    //     0xfb0c30: ldr             x0, [x0, #0x1b8]
    // 0xfb0c34: StoreField: r1->field_f = r0
    //     0xfb0c34: stur            w0, [x1, #0xf]
    // 0xfb0c38: r0 = 1.000000
    //     0xfb0c38: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xfb0c3c: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb0c3c: stur            w0, [x1, #0x17]
    // 0xfb0c40: ldur            x0, [fp, #-8]
    // 0xfb0c44: StoreField: r1->field_b = r0
    //     0xfb0c44: stur            w0, [x1, #0xb]
    // 0xfb0c48: r16 = 1.000000
    //     0xfb0c48: ldr             x16, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xfb0c4c: str             x16, [SP]
    // 0xfb0c50: r4 = const [0, 0x2, 0x1, 0x1, maxScaleFactor, 0x1, null]
    //     0xfb0c50: add             x4, PP, #0x90, lsl #12  ; [pp+0x90d70] List(7) [0, 0x2, 0x1, 0x1, "maxScaleFactor", 0x1, Null]
    //     0xfb0c54: ldr             x4, [x4, #0xd70]
    // 0xfb0c58: r0 = withClampedTextScaling()
    //     0xfb0c58: bl              #0xd16294  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::withClampedTextScaling
    // 0xfb0c5c: LeaveFrame
    //     0xfb0c5c: mov             SP, fp
    //     0xfb0c60: ldp             fp, lr, [SP], #0x10
    // 0xfb0c64: ret
    //     0xfb0c64: ret             
    // 0xfb0c68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb0c68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb0c6c: b               #0xfb0a8c
    // 0xfb0c70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfb0c70: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfb0c74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfb0c74: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfb0c78: SaveReg d2
    //     0xfb0c78: str             q2, [SP, #-0x10]!
    // 0xfb0c7c: SaveReg r2
    //     0xfb0c7c: str             x2, [SP, #-8]!
    // 0xfb0c80: r0 = AllocateDouble()
    //     0xfb0c80: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfb0c84: RestoreReg r2
    //     0xfb0c84: ldr             x2, [SP], #8
    // 0xfb0c88: RestoreReg d2
    //     0xfb0c88: ldr             q2, [SP], #0x10
    // 0xfb0c8c: b               #0xfb0b68
  }
}

// class id: 6181, size: 0x2c, field offset: 0xc
//   const constructor, 
class _TileIcon extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfafff0, size: 0x13c
    // 0xfafff0: EnterFrame
    //     0xfafff0: stp             fp, lr, [SP, #-0x10]!
    //     0xfafff4: mov             fp, SP
    // 0xfafff8: AllocStack(0x20)
    //     0xfafff8: sub             SP, SP, #0x20
    // 0xfafffc: SetupParameters(_TileIcon this /* r1 => r0, fp-0x10 */)
    //     0xfafffc: mov             x0, x1
    //     0xfb0000: stur            x1, [fp, #-0x10]
    // 0xfb0004: CheckStackOverflow
    //     0xfb0004: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb0008: cmp             SP, x16
    //     0xfb000c: b.ls            #0xfb0124
    // 0xfb0010: LoadField: r1 = r0->field_b
    //     0xfb0010: ldur            w1, [x0, #0xb]
    // 0xfb0014: DecompressPointer r1
    //     0xfb0014: add             x1, x1, HEAP, lsl #32
    // 0xfb0018: LoadField: r3 = r0->field_f
    //     0xfb0018: ldur            w3, [x0, #0xf]
    // 0xfb001c: DecompressPointer r3
    //     0xfb001c: add             x3, x3, HEAP, lsl #32
    // 0xfb0020: mov             x2, x3
    // 0xfb0024: stur            x3, [fp, #-8]
    // 0xfb0028: r0 = evaluate()
    //     0xfb0028: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xfb002c: stur            x0, [fp, #-0x18]
    // 0xfb0030: r0 = IconThemeData()
    //     0xfb0030: bl              #0x8ac78c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0xfb0034: mov             x3, x0
    // 0xfb0038: r0 = 24.000000
    //     0xfb0038: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0xfb003c: ldr             x0, [x0, #0x4d0]
    // 0xfb0040: stur            x3, [fp, #-0x20]
    // 0xfb0044: StoreField: r3->field_7 = r0
    //     0xfb0044: stur            w0, [x3, #7]
    // 0xfb0048: ldur            x0, [fp, #-0x18]
    // 0xfb004c: StoreField: r3->field_1b = r0
    //     0xfb004c: stur            w0, [x3, #0x1b]
    // 0xfb0050: ldur            x0, [fp, #-0x10]
    // 0xfb0054: LoadField: r2 = r0->field_27
    //     0xfb0054: ldur            w2, [x0, #0x27]
    // 0xfb0058: DecompressPointer r2
    //     0xfb0058: add             x2, x2, HEAP, lsl #32
    // 0xfb005c: mov             x1, x3
    // 0xfb0060: r0 = merge()
    //     0xfb0060: bl              #0xd0c674  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::merge
    // 0xfb0064: mov             x3, x0
    // 0xfb0068: ldur            x0, [fp, #-0x10]
    // 0xfb006c: stur            x3, [fp, #-0x18]
    // 0xfb0070: LoadField: r2 = r0->field_23
    //     0xfb0070: ldur            w2, [x0, #0x23]
    // 0xfb0074: DecompressPointer r2
    //     0xfb0074: add             x2, x2, HEAP, lsl #32
    // 0xfb0078: ldur            x1, [fp, #-0x20]
    // 0xfb007c: r0 = merge()
    //     0xfb007c: bl              #0xd0c674  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::merge
    // 0xfb0080: ldur            x1, [fp, #-8]
    // 0xfb0084: stur            x0, [fp, #-8]
    // 0xfb0088: r0 = value()
    //     0xfb0088: bl              #0xae5f84  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xfb008c: ldur            x1, [fp, #-0x18]
    // 0xfb0090: ldur            x2, [fp, #-8]
    // 0xfb0094: mov             x3, x0
    // 0xfb0098: r0 = lerp()
    //     0xfb0098: bl              #0xfb012c  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::lerp
    // 0xfb009c: mov             x1, x0
    // 0xfb00a0: ldur            x0, [fp, #-0x10]
    // 0xfb00a4: stur            x1, [fp, #-0x18]
    // 0xfb00a8: LoadField: r2 = r0->field_1b
    //     0xfb00a8: ldur            w2, [x0, #0x1b]
    // 0xfb00ac: DecompressPointer r2
    //     0xfb00ac: add             x2, x2, HEAP, lsl #32
    // 0xfb00b0: tbnz            w2, #4, #0xfb00c8
    // 0xfb00b4: LoadField: r2 = r0->field_1f
    //     0xfb00b4: ldur            w2, [x0, #0x1f]
    // 0xfb00b8: DecompressPointer r2
    //     0xfb00b8: add             x2, x2, HEAP, lsl #32
    // 0xfb00bc: LoadField: r0 = r2->field_f
    //     0xfb00bc: ldur            w0, [x2, #0xf]
    // 0xfb00c0: DecompressPointer r0
    //     0xfb00c0: add             x0, x0, HEAP, lsl #32
    // 0xfb00c4: b               #0xfb00d8
    // 0xfb00c8: LoadField: r2 = r0->field_1f
    //     0xfb00c8: ldur            w2, [x0, #0x1f]
    // 0xfb00cc: DecompressPointer r2
    //     0xfb00cc: add             x2, x2, HEAP, lsl #32
    // 0xfb00d0: LoadField: r0 = r2->field_b
    //     0xfb00d0: ldur            w0, [x2, #0xb]
    // 0xfb00d4: DecompressPointer r0
    //     0xfb00d4: add             x0, x0, HEAP, lsl #32
    // 0xfb00d8: stur            x0, [fp, #-8]
    // 0xfb00dc: r0 = IconTheme()
    //     0xfb00dc: bl              #0xd0c668  ; AllocateIconThemeStub -> IconTheme (size=0x14)
    // 0xfb00e0: mov             x1, x0
    // 0xfb00e4: ldur            x0, [fp, #-0x18]
    // 0xfb00e8: stur            x1, [fp, #-0x10]
    // 0xfb00ec: StoreField: r1->field_f = r0
    //     0xfb00ec: stur            w0, [x1, #0xf]
    // 0xfb00f0: ldur            x0, [fp, #-8]
    // 0xfb00f4: StoreField: r1->field_b = r0
    //     0xfb00f4: stur            w0, [x1, #0xb]
    // 0xfb00f8: r0 = Align()
    //     0xfb00f8: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xfb00fc: r1 = Instance_Alignment
    //     0xfb00fc: add             x1, PP, #0x19, lsl #12  ; [pp+0x197a8] Obj!Alignment@129e7d1
    //     0xfb0100: ldr             x1, [x1, #0x7a8]
    // 0xfb0104: StoreField: r0->field_f = r1
    //     0xfb0104: stur            w1, [x0, #0xf]
    // 0xfb0108: r1 = 1.000000
    //     0xfb0108: ldr             x1, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xfb010c: ArrayStore: r0[0] = r1  ; List_4
    //     0xfb010c: stur            w1, [x0, #0x17]
    // 0xfb0110: ldur            x1, [fp, #-0x10]
    // 0xfb0114: StoreField: r0->field_b = r1
    //     0xfb0114: stur            w1, [x0, #0xb]
    // 0xfb0118: LeaveFrame
    //     0xfb0118: mov             SP, fp
    //     0xfb011c: ldp             fp, lr, [SP], #0x10
    // 0xfb0120: ret
    //     0xfb0120: ret             
    // 0xfb0124: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb0124: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb0128: b               #0xfb0010
  }
}

// class id: 6182, size: 0x18, field offset: 0xc
//   const constructor, 
class _Tile extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfaff00, size: 0xf0
    // 0xfaff00: EnterFrame
    //     0xfaff00: stp             fp, lr, [SP, #-0x10]!
    //     0xfaff04: mov             fp, SP
    // 0xfaff08: AllocStack(0x18)
    //     0xfaff08: sub             SP, SP, #0x18
    // 0xfaff0c: SetupParameters(_Tile this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xfaff0c: mov             x0, x1
    //     0xfaff10: stur            x1, [fp, #-8]
    //     0xfaff14: mov             x1, x2
    // 0xfaff18: CheckStackOverflow
    //     0xfaff18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaff1c: cmp             SP, x16
    //     0xfaff20: b.ls            #0xfaffe8
    // 0xfaff24: r0 = orientationOf()
    //     0xfaff24: bl              #0xd172a4  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::orientationOf
    // 0xfaff28: ldur            x0, [fp, #-8]
    // 0xfaff2c: LoadField: r3 = r0->field_f
    //     0xfaff2c: ldur            w3, [x0, #0xf]
    // 0xfaff30: DecompressPointer r3
    //     0xfaff30: add             x3, x3, HEAP, lsl #32
    // 0xfaff34: stur            x3, [fp, #-0x18]
    // 0xfaff38: LoadField: r4 = r0->field_13
    //     0xfaff38: ldur            w4, [x0, #0x13]
    // 0xfaff3c: DecompressPointer r4
    //     0xfaff3c: add             x4, x4, HEAP, lsl #32
    // 0xfaff40: stur            x4, [fp, #-0x10]
    // 0xfaff44: r1 = Null
    //     0xfaff44: mov             x1, NULL
    // 0xfaff48: r2 = 4
    //     0xfaff48: mov             x2, #4
    // 0xfaff4c: r0 = AllocateArray()
    //     0xfaff4c: bl              #0x13df928  ; AllocateArrayStub
    // 0xfaff50: mov             x2, x0
    // 0xfaff54: ldur            x0, [fp, #-0x18]
    // 0xfaff58: stur            x2, [fp, #-8]
    // 0xfaff5c: StoreField: r2->field_f = r0
    //     0xfaff5c: stur            w0, [x2, #0xf]
    // 0xfaff60: ldur            x0, [fp, #-0x10]
    // 0xfaff64: StoreField: r2->field_13 = r0
    //     0xfaff64: stur            w0, [x2, #0x13]
    // 0xfaff68: r1 = <Widget>
    //     0xfaff68: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfaff6c: r0 = AllocateGrowableArray()
    //     0xfaff6c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xfaff70: mov             x1, x0
    // 0xfaff74: ldur            x0, [fp, #-8]
    // 0xfaff78: stur            x1, [fp, #-0x10]
    // 0xfaff7c: StoreField: r1->field_f = r0
    //     0xfaff7c: stur            w0, [x1, #0xf]
    // 0xfaff80: r0 = 4
    //     0xfaff80: mov             x0, #4
    // 0xfaff84: StoreField: r1->field_b = r0
    //     0xfaff84: stur            w0, [x1, #0xb]
    // 0xfaff88: r0 = Column()
    //     0xfaff88: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xfaff8c: r1 = Instance_Axis
    //     0xfaff8c: ldr             x1, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xfaff90: StoreField: r0->field_f = r1
    //     0xfaff90: stur            w1, [x0, #0xf]
    // 0xfaff94: r1 = Instance_MainAxisAlignment
    //     0xfaff94: add             x1, PP, #0x17, lsl #12  ; [pp+0x177b0] Obj!MainAxisAlignment@12c45c1
    //     0xfaff98: ldr             x1, [x1, #0x7b0]
    // 0xfaff9c: StoreField: r0->field_13 = r1
    //     0xfaff9c: stur            w1, [x0, #0x13]
    // 0xfaffa0: r1 = Instance_MainAxisSize
    //     0xfaffa0: add             x1, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xfaffa4: ldr             x1, [x1, #0x200]
    // 0xfaffa8: ArrayStore: r0[0] = r1  ; List_4
    //     0xfaffa8: stur            w1, [x0, #0x17]
    // 0xfaffac: r1 = Instance_CrossAxisAlignment
    //     0xfaffac: add             x1, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xfaffb0: ldr             x1, [x1, #0x888]
    // 0xfaffb4: StoreField: r0->field_1b = r1
    //     0xfaffb4: stur            w1, [x0, #0x1b]
    // 0xfaffb8: r1 = Instance_VerticalDirection
    //     0xfaffb8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xfaffbc: ldr             x1, [x1, #0x838]
    // 0xfaffc0: StoreField: r0->field_23 = r1
    //     0xfaffc0: stur            w1, [x0, #0x23]
    // 0xfaffc4: r1 = Instance_Clip
    //     0xfaffc4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfaffc8: ldr             x1, [x1, #0x840]
    // 0xfaffcc: StoreField: r0->field_2b = r1
    //     0xfaffcc: stur            w1, [x0, #0x2b]
    // 0xfaffd0: StoreField: r0->field_2f = rZR
    //     0xfaffd0: stur            xzr, [x0, #0x2f]
    // 0xfaffd4: ldur            x1, [fp, #-0x10]
    // 0xfaffd8: StoreField: r0->field_b = r1
    //     0xfaffd8: stur            w1, [x0, #0xb]
    // 0xfaffdc: LeaveFrame
    //     0xfaffdc: mov             SP, fp
    //     0xfaffe0: ldp             fp, lr, [SP], #0x10
    // 0xfaffe4: ret
    //     0xfaffe4: ret             
    // 0xfaffe8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaffe8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaffec: b               #0xfaff24
  }
}

// class id: 6183, size: 0x60, field offset: 0xc
//   const constructor, 
class _BottomNavigationTile extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfaf970, size: 0x56c
    // 0xfaf970: EnterFrame
    //     0xfaf970: stp             fp, lr, [SP, #-0x10]!
    //     0xfaf974: mov             fp, SP
    // 0xfaf978: AllocStack(0x90)
    //     0xfaf978: sub             SP, SP, #0x90
    // 0xfaf97c: SetupParameters(_BottomNavigationTile this /* r1 => r0, fp-0x28 */)
    //     0xfaf97c: mov             x0, x1
    //     0xfaf980: stur            x1, [fp, #-0x28]
    // 0xfaf984: CheckStackOverflow
    //     0xfaf984: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaf988: cmp             SP, x16
    //     0xfaf98c: b.ls            #0xfafe6c
    // 0xfaf990: LoadField: r2 = r0->field_3f
    //     0xfaf990: ldur            w2, [x0, #0x3f]
    // 0xfaf994: DecompressPointer r2
    //     0xfaf994: add             x2, x2, HEAP, lsl #32
    // 0xfaf998: stur            x2, [fp, #-0x20]
    // 0xfaf99c: LoadField: r1 = r2->field_1f
    //     0xfaf99c: ldur            w1, [x2, #0x1f]
    // 0xfaf9a0: DecompressPointer r1
    //     0xfaf9a0: add             x1, x1, HEAP, lsl #32
    // 0xfaf9a4: cmp             w1, NULL
    // 0xfaf9a8: b.eq            #0xfafe74
    // 0xfaf9ac: LoadField: r3 = r0->field_37
    //     0xfaf9ac: ldur            w3, [x0, #0x37]
    // 0xfaf9b0: DecompressPointer r3
    //     0xfaf9b0: add             x3, x3, HEAP, lsl #32
    // 0xfaf9b4: stur            x3, [fp, #-0x18]
    // 0xfaf9b8: cmp             w3, NULL
    // 0xfaf9bc: b.ne            #0xfaf9c8
    // 0xfaf9c0: r4 = Null
    //     0xfaf9c0: mov             x4, NULL
    // 0xfaf9c4: b               #0xfaf9d0
    // 0xfaf9c8: LoadField: r4 = r3->field_7
    //     0xfaf9c8: ldur            w4, [x3, #7]
    // 0xfaf9cc: DecompressPointer r4
    //     0xfaf9cc: add             x4, x4, HEAP, lsl #32
    // 0xfaf9d0: cmp             w4, NULL
    // 0xfaf9d4: b.ne            #0xfaf9e0
    // 0xfaf9d8: d0 = 24.000000
    //     0xfaf9d8: fmov            d0, #24.00000000
    // 0xfaf9dc: b               #0xfaf9e4
    // 0xfaf9e0: LoadField: d0 = r4->field_7
    //     0xfaf9e0: ldur            d0, [x4, #7]
    // 0xfaf9e4: LoadField: r4 = r0->field_3b
    //     0xfaf9e4: ldur            w4, [x0, #0x3b]
    // 0xfaf9e8: DecompressPointer r4
    //     0xfaf9e8: add             x4, x4, HEAP, lsl #32
    // 0xfaf9ec: stur            x4, [fp, #-0x10]
    // 0xfaf9f0: cmp             w4, NULL
    // 0xfaf9f4: b.ne            #0xfafa00
    // 0xfaf9f8: r5 = Null
    //     0xfaf9f8: mov             x5, NULL
    // 0xfaf9fc: b               #0xfafa08
    // 0xfafa00: LoadField: r5 = r4->field_7
    //     0xfafa00: ldur            w5, [x4, #7]
    // 0xfafa04: DecompressPointer r5
    //     0xfafa04: add             x5, x5, HEAP, lsl #32
    // 0xfafa08: cmp             w5, NULL
    // 0xfafa0c: b.ne            #0xfafa18
    // 0xfafa10: d3 = 24.000000
    //     0xfafa10: fmov            d3, #24.00000000
    // 0xfafa14: b               #0xfafa20
    // 0xfafa18: LoadField: d1 = r5->field_7
    //     0xfafa18: ldur            d1, [x5, #7]
    // 0xfafa1c: mov             v3.16b, v1.16b
    // 0xfafa20: d2 = 0.000000
    //     0xfafa20: eor             v2.16b, v2.16b, v2.16b
    // 0xfafa24: d1 = 2.000000
    //     0xfafa24: fmov            d1, #2.00000000
    // 0xfafa28: fsub            d4, d0, d3
    // 0xfafa2c: fmax            v5.2d, v4.2d, v2.2d
    // 0xfafa30: fsub            d4, d3, d0
    // 0xfafa34: fmax            v0.2d, v4.2d, v2.2d
    // 0xfafa38: LoadField: d2 = r1->field_7
    //     0xfafa38: ldur            d2, [x1, #7]
    // 0xfafa3c: fdiv            d3, d2, d1
    // 0xfafa40: fdiv            d2, d5, d1
    // 0xfafa44: fadd            d4, d3, d2
    // 0xfafa48: fdiv            d2, d0, d1
    // 0xfafa4c: fadd            d0, d3, d2
    // 0xfafa50: stur            d0, [fp, #-0x70]
    // 0xfafa54: r5 = inline_Allocate_Double()
    //     0xfafa54: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0xfafa58: add             x5, x5, #0x10
    //     0xfafa5c: cmp             x1, x5
    //     0xfafa60: b.ls            #0xfafe78
    //     0xfafa64: str             x5, [THR, #0x60]  ; THR::top
    //     0xfafa68: sub             x5, x5, #0xf
    //     0xfafa6c: mov             x1, #0xe19c
    //     0xfafa70: movk            x1, #3, lsl #16
    //     0xfafa74: stur            x1, [x5, #-1]
    // 0xfafa78: dmb             ishst
    // 0xfafa7c: StoreField: r5->field_7 = d4
    //     0xfafa7c: stur            d4, [x5, #7]
    // 0xfafa80: stur            x5, [fp, #-8]
    // 0xfafa84: r1 = <double>
    //     0xfafa84: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfafa88: r0 = Tween()
    //     0xfafa88: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xfafa8c: mov             x1, x0
    // 0xfafa90: ldur            x0, [fp, #-8]
    // 0xfafa94: StoreField: r1->field_b = r0
    //     0xfafa94: stur            w0, [x1, #0xb]
    // 0xfafa98: ldur            d0, [fp, #-0x70]
    // 0xfafa9c: r3 = inline_Allocate_Double()
    //     0xfafa9c: ldp             x3, x2, [THR, #0x60]  ; THR::top
    //     0xfafaa0: add             x3, x3, #0x10
    //     0xfafaa4: cmp             x2, x3
    //     0xfafaa8: b.ls            #0xfafe9c
    //     0xfafaac: str             x3, [THR, #0x60]  ; THR::top
    //     0xfafab0: sub             x3, x3, #0xf
    //     0xfafab4: mov             x2, #0xe19c
    //     0xfafab8: movk            x2, #3, lsl #16
    //     0xfafabc: stur            x2, [x3, #-1]
    // 0xfafac0: dmb             ishst
    // 0xfafac4: StoreField: r3->field_7 = d0
    //     0xfafac4: stur            d0, [x3, #7]
    // 0xfafac8: stur            x3, [fp, #-0x38]
    // 0xfafacc: StoreField: r1->field_f = r3
    //     0xfafacc: stur            w3, [x1, #0xf]
    // 0xfafad0: ldur            x4, [fp, #-0x28]
    // 0xfafad4: LoadField: r5 = r4->field_13
    //     0xfafad4: ldur            w5, [x4, #0x13]
    // 0xfafad8: DecompressPointer r5
    //     0xfafad8: add             x5, x5, HEAP, lsl #32
    // 0xfafadc: mov             x2, x5
    // 0xfafae0: stur            x5, [fp, #-0x30]
    // 0xfafae4: r0 = evaluate()
    //     0xfafae4: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xfafae8: r1 = <double>
    //     0xfafae8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfafaec: stur            x0, [fp, #-0x40]
    // 0xfafaf0: r0 = Tween()
    //     0xfafaf0: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xfafaf4: mov             x1, x0
    // 0xfafaf8: ldur            x0, [fp, #-8]
    // 0xfafafc: StoreField: r1->field_b = r0
    //     0xfafafc: stur            w0, [x1, #0xb]
    // 0xfafb00: ldur            x0, [fp, #-0x38]
    // 0xfafb04: StoreField: r1->field_f = r0
    //     0xfafb04: stur            w0, [x1, #0xf]
    // 0xfafb08: ldur            x2, [fp, #-0x30]
    // 0xfafb0c: r0 = evaluate()
    //     0xfafb0c: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xfafb10: mov             x20, x0
    // 0xfafb14: ldur            x19, [fp, #-0x28]
    // 0xfafb18: stur            x20, [fp, #-0x50]
    // 0xfafb1c: LoadField: r0 = r19->field_b
    //     0xfafb1c: ldur            w0, [x19, #0xb]
    // 0xfafb20: DecompressPointer r0
    //     0xfafb20: add             x0, x0, HEAP, lsl #32
    // 0xfafb24: LoadField: r1 = r0->field_7
    //     0xfafb24: ldur            x1, [x0, #7]
    // 0xfafb28: cmp             x1, #0
    // 0xfafb2c: b.gt            #0xfafb38
    // 0xfafb30: r5 = 1
    //     0xfafb30: mov             x5, #1
    // 0xfafb34: b               #0xfafbac
    // 0xfafb38: d0 = 1000.000000
    //     0xfafb38: add             x17, PP, #0x16, lsl #12  ; [pp+0x16a58] IMM: double(1000) from 0x408f400000000000
    //     0xfafb3c: ldr             d0, [x17, #0xa58]
    // 0xfafb40: LoadField: d1 = r19->field_2b
    //     0xfafb40: ldur            d1, [x19, #0x2b]
    // 0xfafb44: fmul            d2, d1, d0
    // 0xfafb48: mov             v0.16b, v2.16b
    // 0xfafb4c: stp             fp, lr, [SP, #-0x10]!
    // 0xfafb50: mov             fp, SP
    // 0xfafb54: CallRuntime_LibcRound(double) -> double
    //     0xfafb54: and             SP, SP, #0xfffffffffffffff0
    //     0xfafb58: mov             sp, SP
    //     0xfafb5c: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0xfafb60: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xfafb64: blr             x16
    //     0xfafb68: mov             x16, #8
    //     0xfafb6c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xfafb70: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xfafb74: sub             sp, x16, #1, lsl #12
    //     0xfafb78: mov             SP, fp
    //     0xfafb7c: ldp             fp, lr, [SP], #0x10
    // 0xfafb80: fcmp            d0, d0
    // 0xfafb84: b.vs            #0xfafeb8
    // 0xfafb88: fcvtzs          x0, d0
    // 0xfafb8c: asr             x16, x0, #0x1e
    // 0xfafb90: cmp             x16, x0, asr #63
    // 0xfafb94: b.ne            #0xfafeb8
    // 0xfafb98: lsl             x0, x0, #1
    // 0xfafb9c: r1 = LoadInt32Instr(r0)
    //     0xfafb9c: sbfx            x1, x0, #1, #0x1f
    //     0xfafba0: tbz             w0, #0, #0xfafba8
    //     0xfafba4: ldur            x1, [x0, #7]
    // 0xfafba8: mov             x5, x1
    // 0xfafbac: ldur            x2, [fp, #-0x20]
    // 0xfafbb0: ldur            x3, [fp, #-0x18]
    // 0xfafbb4: ldur            x4, [fp, #-0x10]
    // 0xfafbb8: ldur            x1, [fp, #-0x30]
    // 0xfafbbc: ldur            x0, [fp, #-0x40]
    // 0xfafbc0: stur            x5, [fp, #-0x48]
    // 0xfafbc4: LoadField: r6 = r19->field_1f
    //     0xfafbc4: ldur            w6, [x19, #0x1f]
    // 0xfafbc8: DecompressPointer r6
    //     0xfafbc8: add             x6, x6, HEAP, lsl #32
    // 0xfafbcc: stur            x6, [fp, #-0x38]
    // 0xfafbd0: LoadField: r7 = r19->field_53
    //     0xfafbd0: ldur            w7, [x19, #0x53]
    // 0xfafbd4: DecompressPointer r7
    //     0xfafbd4: add             x7, x7, HEAP, lsl #32
    // 0xfafbd8: stur            x7, [fp, #-8]
    // 0xfafbdc: r0 = EdgeInsets()
    //     0xfafbdc: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xfafbe0: stur            x0, [fp, #-0x60]
    // 0xfafbe4: StoreField: r0->field_7 = rZR
    //     0xfafbe4: stur            xzr, [x0, #7]
    // 0xfafbe8: ldur            x1, [fp, #-0x50]
    // 0xfafbec: LoadField: d0 = r1->field_7
    //     0xfafbec: ldur            d0, [x1, #7]
    // 0xfafbf0: StoreField: r0->field_f = d0
    //     0xfafbf0: stur            d0, [x0, #0xf]
    // 0xfafbf4: ArrayStore: r0[0] = rZR  ; List_8
    //     0xfafbf4: stur            xzr, [x0, #0x17]
    // 0xfafbf8: ldur            x1, [fp, #-0x40]
    // 0xfafbfc: LoadField: d0 = r1->field_7
    //     0xfafbfc: ldur            d0, [x1, #7]
    // 0xfafc00: StoreField: r0->field_1f = d0
    //     0xfafc00: stur            d0, [x0, #0x1f]
    // 0xfafc04: ldur            x1, [fp, #-0x28]
    // 0xfafc08: LoadField: r2 = r1->field_27
    //     0xfafc08: ldur            w2, [x1, #0x27]
    // 0xfafc0c: DecompressPointer r2
    //     0xfafc0c: add             x2, x2, HEAP, lsl #32
    // 0xfafc10: stur            x2, [fp, #-0x58]
    // 0xfafc14: LoadField: r3 = r1->field_33
    //     0xfafc14: ldur            w3, [x1, #0x33]
    // 0xfafc18: DecompressPointer r3
    //     0xfafc18: add             x3, x3, HEAP, lsl #32
    // 0xfafc1c: stur            x3, [fp, #-0x50]
    // 0xfafc20: LoadField: r4 = r1->field_f
    //     0xfafc20: ldur            w4, [x1, #0xf]
    // 0xfafc24: DecompressPointer r4
    //     0xfafc24: add             x4, x4, HEAP, lsl #32
    // 0xfafc28: stur            x4, [fp, #-0x40]
    // 0xfafc2c: r0 = _TileIcon()
    //     0xfafc2c: bl              #0xfafef4  ; Allocate_TileIconStub -> _TileIcon (size=0x2c)
    // 0xfafc30: mov             x1, x0
    // 0xfafc34: ldur            x0, [fp, #-0x58]
    // 0xfafc38: stur            x1, [fp, #-0x68]
    // 0xfafc3c: StoreField: r1->field_b = r0
    //     0xfafc3c: stur            w0, [x1, #0xb]
    // 0xfafc40: ldur            x0, [fp, #-0x30]
    // 0xfafc44: StoreField: r1->field_f = r0
    //     0xfafc44: stur            w0, [x1, #0xf]
    // 0xfafc48: d0 = 24.000000
    //     0xfafc48: fmov            d0, #24.00000000
    // 0xfafc4c: StoreField: r1->field_13 = d0
    //     0xfafc4c: stur            d0, [x1, #0x13]
    // 0xfafc50: ldur            x2, [fp, #-0x50]
    // 0xfafc54: StoreField: r1->field_1b = r2
    //     0xfafc54: stur            w2, [x1, #0x1b]
    // 0xfafc58: ldur            x3, [fp, #-0x40]
    // 0xfafc5c: StoreField: r1->field_1f = r3
    //     0xfafc5c: stur            w3, [x1, #0x1f]
    // 0xfafc60: ldur            x4, [fp, #-0x18]
    // 0xfafc64: StoreField: r1->field_23 = r4
    //     0xfafc64: stur            w4, [x1, #0x23]
    // 0xfafc68: ldur            x4, [fp, #-0x10]
    // 0xfafc6c: StoreField: r1->field_27 = r4
    //     0xfafc6c: stur            w4, [x1, #0x27]
    // 0xfafc70: ldur            x4, [fp, #-0x28]
    // 0xfafc74: LoadField: r5 = r4->field_23
    //     0xfafc74: ldur            w5, [x4, #0x23]
    // 0xfafc78: DecompressPointer r5
    //     0xfafc78: add             x5, x5, HEAP, lsl #32
    // 0xfafc7c: stur            x5, [fp, #-0x18]
    // 0xfafc80: LoadField: r6 = r4->field_43
    //     0xfafc80: ldur            w6, [x4, #0x43]
    // 0xfafc84: DecompressPointer r6
    //     0xfafc84: add             x6, x6, HEAP, lsl #32
    // 0xfafc88: stur            x6, [fp, #-0x10]
    // 0xfafc8c: r0 = _Label()
    //     0xfafc8c: bl              #0xfafee8  ; Allocate_LabelStub -> _Label (size=0x28)
    // 0xfafc90: mov             x1, x0
    // 0xfafc94: ldur            x0, [fp, #-0x18]
    // 0xfafc98: stur            x1, [fp, #-0x58]
    // 0xfafc9c: StoreField: r1->field_b = r0
    //     0xfafc9c: stur            w0, [x1, #0xb]
    // 0xfafca0: ldur            x0, [fp, #-0x30]
    // 0xfafca4: StoreField: r1->field_f = r0
    //     0xfafca4: stur            w0, [x1, #0xf]
    // 0xfafca8: ldur            x0, [fp, #-0x40]
    // 0xfafcac: StoreField: r1->field_13 = r0
    //     0xfafcac: stur            w0, [x1, #0x13]
    // 0xfafcb0: ldur            x0, [fp, #-0x20]
    // 0xfafcb4: ArrayStore: r1[0] = r0  ; List_4
    //     0xfafcb4: stur            w0, [x1, #0x17]
    // 0xfafcb8: ldur            x0, [fp, #-0x10]
    // 0xfafcbc: StoreField: r1->field_1b = r0
    //     0xfafcbc: stur            w0, [x1, #0x1b]
    // 0xfafcc0: r0 = true
    //     0xfafcc0: add             x0, NULL, #0x20  ; true
    // 0xfafcc4: StoreField: r1->field_1f = r0
    //     0xfafcc4: stur            w0, [x1, #0x1f]
    // 0xfafcc8: StoreField: r1->field_23 = r0
    //     0xfafcc8: stur            w0, [x1, #0x23]
    // 0xfafccc: r0 = _Tile()
    //     0xfafccc: bl              #0xfafedc  ; Allocate_TileStub -> _Tile (size=0x18)
    // 0xfafcd0: mov             x1, x0
    // 0xfafcd4: r0 = Instance_BottomNavigationBarLandscapeLayout
    //     0xfafcd4: add             x0, PP, #0x90, lsl #12  ; [pp+0x909c8] Obj!BottomNavigationBarLandscapeLayout@12c59a1
    //     0xfafcd8: ldr             x0, [x0, #0x9c8]
    // 0xfafcdc: stur            x1, [fp, #-0x10]
    // 0xfafce0: StoreField: r1->field_b = r0
    //     0xfafce0: stur            w0, [x1, #0xb]
    // 0xfafce4: ldur            x0, [fp, #-0x68]
    // 0xfafce8: StoreField: r1->field_f = r0
    //     0xfafce8: stur            w0, [x1, #0xf]
    // 0xfafcec: ldur            x0, [fp, #-0x58]
    // 0xfafcf0: StoreField: r1->field_13 = r0
    //     0xfafcf0: stur            w0, [x1, #0x13]
    // 0xfafcf4: r0 = Padding()
    //     0xfafcf4: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xfafcf8: mov             x1, x0
    // 0xfafcfc: ldur            x0, [fp, #-0x60]
    // 0xfafd00: stur            x1, [fp, #-0x18]
    // 0xfafd04: StoreField: r1->field_f = r0
    //     0xfafd04: stur            w0, [x1, #0xf]
    // 0xfafd08: ldur            x0, [fp, #-0x10]
    // 0xfafd0c: StoreField: r1->field_b = r0
    //     0xfafd0c: stur            w0, [x1, #0xb]
    // 0xfafd10: r0 = InkResponse()
    //     0xfafd10: bl              #0xdf1b70  ; AllocateInkResponseStub -> InkResponse (size=0x94)
    // 0xfafd14: mov             x1, x0
    // 0xfafd18: ldur            x0, [fp, #-0x18]
    // 0xfafd1c: stur            x1, [fp, #-0x10]
    // 0xfafd20: StoreField: r1->field_b = r0
    //     0xfafd20: stur            w0, [x1, #0xb]
    // 0xfafd24: ldur            x0, [fp, #-0x38]
    // 0xfafd28: StoreField: r1->field_f = r0
    //     0xfafd28: stur            w0, [x1, #0xf]
    // 0xfafd2c: ldur            x0, [fp, #-8]
    // 0xfafd30: StoreField: r1->field_43 = r0
    //     0xfafd30: stur            w0, [x1, #0x43]
    // 0xfafd34: r0 = false
    //     0xfafd34: add             x0, NULL, #0x30  ; false
    // 0xfafd38: StoreField: r1->field_47 = r0
    //     0xfafd38: stur            w0, [x1, #0x47]
    // 0xfafd3c: r2 = Instance_BoxShape
    //     0xfafd3c: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1abf0] Obj!BoxShape@12c4941
    //     0xfafd40: ldr             x2, [x2, #0xbf0]
    // 0xfafd44: StoreField: r1->field_4b = r2
    //     0xfafd44: stur            w2, [x1, #0x4b]
    // 0xfafd48: r2 = true
    //     0xfafd48: add             x2, NULL, #0x20  ; true
    // 0xfafd4c: StoreField: r1->field_73 = r2
    //     0xfafd4c: stur            w2, [x1, #0x73]
    // 0xfafd50: StoreField: r1->field_77 = r0
    //     0xfafd50: stur            w0, [x1, #0x77]
    // 0xfafd54: StoreField: r1->field_87 = r2
    //     0xfafd54: stur            w2, [x1, #0x87]
    // 0xfafd58: StoreField: r1->field_7f = r0
    //     0xfafd58: stur            w0, [x1, #0x7f]
    // 0xfafd5c: ldur            x0, [fp, #-0x28]
    // 0xfafd60: LoadField: r2 = r0->field_47
    //     0xfafd60: ldur            w2, [x0, #0x47]
    // 0xfafd64: DecompressPointer r2
    //     0xfafd64: add             x2, x2, HEAP, lsl #32
    // 0xfafd68: stur            x2, [fp, #-8]
    // 0xfafd6c: r0 = Semantics()
    //     0xfafd6c: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xfafd70: stur            x0, [fp, #-0x18]
    // 0xfafd74: ldur            x16, [fp, #-8]
    // 0xfafd78: str             x16, [SP]
    // 0xfafd7c: mov             x1, x0
    // 0xfafd80: r4 = const [0, 0x2, 0x1, 0x1, label, 0x1, null]
    //     0xfafd80: add             x4, PP, #0x9a, lsl #12  ; [pp+0x9a528] List(7) [0, 0x2, 0x1, 0x1, "label", 0x1, Null]
    //     0xfafd84: ldr             x4, [x4, #0x528]
    // 0xfafd88: r0 = Semantics()
    //     0xfafd88: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xfafd8c: r1 = Null
    //     0xfafd8c: mov             x1, NULL
    // 0xfafd90: r2 = 4
    //     0xfafd90: mov             x2, #4
    // 0xfafd94: r0 = AllocateArray()
    //     0xfafd94: bl              #0x13df928  ; AllocateArrayStub
    // 0xfafd98: mov             x2, x0
    // 0xfafd9c: ldur            x0, [fp, #-0x10]
    // 0xfafda0: stur            x2, [fp, #-8]
    // 0xfafda4: StoreField: r2->field_f = r0
    //     0xfafda4: stur            w0, [x2, #0xf]
    // 0xfafda8: ldur            x0, [fp, #-0x18]
    // 0xfafdac: StoreField: r2->field_13 = r0
    //     0xfafdac: stur            w0, [x2, #0x13]
    // 0xfafdb0: r1 = <Widget>
    //     0xfafdb0: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfafdb4: r0 = AllocateGrowableArray()
    //     0xfafdb4: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xfafdb8: mov             x1, x0
    // 0xfafdbc: ldur            x0, [fp, #-8]
    // 0xfafdc0: stur            x1, [fp, #-0x10]
    // 0xfafdc4: StoreField: r1->field_f = r0
    //     0xfafdc4: stur            w0, [x1, #0xf]
    // 0xfafdc8: r0 = 4
    //     0xfafdc8: mov             x0, #4
    // 0xfafdcc: StoreField: r1->field_b = r0
    //     0xfafdcc: stur            w0, [x1, #0xb]
    // 0xfafdd0: r0 = Stack()
    //     0xfafdd0: bl              #0xd1a854  ; AllocateStackStub -> Stack (size=0x20)
    // 0xfafdd4: mov             x1, x0
    // 0xfafdd8: r0 = Instance_AlignmentDirectional
    //     0xfafdd8: add             x0, PP, #0x15, lsl #12  ; [pp+0x158d8] Obj!AlignmentDirectional@129e611
    //     0xfafddc: ldr             x0, [x0, #0x8d8]
    // 0xfafde0: stur            x1, [fp, #-8]
    // 0xfafde4: StoreField: r1->field_f = r0
    //     0xfafde4: stur            w0, [x1, #0xf]
    // 0xfafde8: r0 = Instance_StackFit
    //     0xfafde8: add             x0, PP, #0x15, lsl #12  ; [pp+0x158e0] Obj!StackFit@12c4221
    //     0xfafdec: ldr             x0, [x0, #0x8e0]
    // 0xfafdf0: ArrayStore: r1[0] = r0  ; List_4
    //     0xfafdf0: stur            w0, [x1, #0x17]
    // 0xfafdf4: r0 = Instance_Clip
    //     0xfafdf4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xfafdf8: ldr             x0, [x0, #0x850]
    // 0xfafdfc: StoreField: r1->field_1b = r0
    //     0xfafdfc: stur            w0, [x1, #0x1b]
    // 0xfafe00: ldur            x0, [fp, #-0x10]
    // 0xfafe04: StoreField: r1->field_b = r0
    //     0xfafe04: stur            w0, [x1, #0xb]
    // 0xfafe08: r0 = Semantics()
    //     0xfafe08: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xfafe0c: stur            x0, [fp, #-0x10]
    // 0xfafe10: ldur            x16, [fp, #-0x50]
    // 0xfafe14: r30 = true
    //     0xfafe14: add             lr, NULL, #0x20  ; true
    // 0xfafe18: stp             lr, x16, [SP, #0x10]
    // 0xfafe1c: r16 = true
    //     0xfafe1c: add             x16, NULL, #0x20  ; true
    // 0xfafe20: ldur            lr, [fp, #-8]
    // 0xfafe24: stp             lr, x16, [SP]
    // 0xfafe28: mov             x1, x0
    // 0xfafe2c: r4 = const [0, 0x5, 0x4, 0x1, button, 0x2, child, 0x4, container, 0x3, selected, 0x1, null]
    //     0xfafe2c: add             x4, PP, #0x9a, lsl #12  ; [pp+0x9a530] List(13) [0, 0x5, 0x4, 0x1, "button", 0x2, "child", 0x4, "container", 0x3, "selected", 0x1, Null]
    //     0xfafe30: ldr             x4, [x4, #0x530]
    // 0xfafe34: r0 = Semantics()
    //     0xfafe34: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xfafe38: r1 = <FlexParentData>
    //     0xfafe38: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xfafe3c: ldr             x1, [x1, #0x878]
    // 0xfafe40: r0 = Expanded()
    //     0xfafe40: bl              #0x8a5b10  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0xfafe44: ldur            x1, [fp, #-0x48]
    // 0xfafe48: StoreField: r0->field_13 = r1
    //     0xfafe48: stur            x1, [x0, #0x13]
    // 0xfafe4c: r1 = Instance_FlexFit
    //     0xfafe4c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15880] Obj!FlexFit@12c4641
    //     0xfafe50: ldr             x1, [x1, #0x880]
    // 0xfafe54: StoreField: r0->field_1b = r1
    //     0xfafe54: stur            w1, [x0, #0x1b]
    // 0xfafe58: ldur            x1, [fp, #-0x10]
    // 0xfafe5c: StoreField: r0->field_b = r1
    //     0xfafe5c: stur            w1, [x0, #0xb]
    // 0xfafe60: LeaveFrame
    //     0xfafe60: mov             SP, fp
    //     0xfafe64: ldp             fp, lr, [SP], #0x10
    // 0xfafe68: ret
    //     0xfafe68: ret             
    // 0xfafe6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfafe6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfafe70: b               #0xfaf990
    // 0xfafe74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfafe74: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfafe78: stp             q0, q4, [SP, #-0x20]!
    // 0xfafe7c: stp             x3, x4, [SP, #-0x10]!
    // 0xfafe80: stp             x0, x2, [SP, #-0x10]!
    // 0xfafe84: r0 = AllocateDouble()
    //     0xfafe84: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfafe88: mov             x5, x0
    // 0xfafe8c: ldp             x0, x2, [SP], #0x10
    // 0xfafe90: ldp             x3, x4, [SP], #0x10
    // 0xfafe94: ldp             q0, q4, [SP], #0x20
    // 0xfafe98: b               #0xfafa7c
    // 0xfafe9c: SaveReg d0
    //     0xfafe9c: str             q0, [SP, #-0x10]!
    // 0xfafea0: stp             x0, x1, [SP, #-0x10]!
    // 0xfafea4: r0 = AllocateDouble()
    //     0xfafea4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfafea8: mov             x3, x0
    // 0xfafeac: ldp             x0, x1, [SP], #0x10
    // 0xfafeb0: RestoreReg d0
    //     0xfafeb0: ldr             q0, [SP], #0x10
    // 0xfafeb4: b               #0xfafac4
    // 0xfafeb8: SaveReg d0
    //     0xfafeb8: str             q0, [SP, #-0x10]!
    // 0xfafebc: stp             x19, x20, [SP, #-0x10]!
    // 0xfafec0: r0 = 76
    //     0xfafec0: mov             x0, #0x4c
    // 0xfafec4: r30 = DoubleToIntegerStub
    //     0xfafec4: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xfafec8: LoadField: r30 = r30->field_7
    //     0xfafec8: ldur            lr, [lr, #7]
    // 0xfafecc: blr             lr
    // 0xfafed0: ldp             x19, x20, [SP], #0x10
    // 0xfafed4: RestoreReg d0
    //     0xfafed4: ldr             q0, [SP], #0x10
    // 0xfafed8: b               #0xfafb9c
  }
}

// class id: 6502, size: 0x70, field offset: 0xc
class BottomNavigationBar extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa0ae8, size: 0x48
    // 0xfa0ae8: EnterFrame
    //     0xfa0ae8: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0aec: mov             fp, SP
    // 0xfa0af0: AllocStack(0x8)
    //     0xfa0af0: sub             SP, SP, #8
    // 0xfa0af4: CheckStackOverflow
    //     0xfa0af4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa0af8: cmp             SP, x16
    //     0xfa0afc: b.ls            #0xfa0b28
    // 0xfa0b00: r1 = <BottomNavigationBar>
    //     0xfa0b00: add             x1, PP, #0x85, lsl #12  ; [pp+0x85368] TypeArguments: <BottomNavigationBar>
    //     0xfa0b04: ldr             x1, [x1, #0x368]
    // 0xfa0b08: r0 = _BottomNavigationBarState()
    //     0xfa0b08: bl              #0xfa0c08  ; Allocate_BottomNavigationBarStateStub -> _BottomNavigationBarState (size=0x2c)
    // 0xfa0b0c: mov             x1, x0
    // 0xfa0b10: stur            x0, [fp, #-8]
    // 0xfa0b14: r0 = _BottomNavigationBarState()
    //     0xfa0b14: bl              #0xfa0b30  ; [package:flutter/src/material/bottom_navigation_bar.dart] _BottomNavigationBarState::_BottomNavigationBarState
    // 0xfa0b18: ldur            x0, [fp, #-8]
    // 0xfa0b1c: LeaveFrame
    //     0xfa0b1c: mov             SP, fp
    //     0xfa0b20: ldp             fp, lr, [SP], #0x10
    // 0xfa0b24: ret
    //     0xfa0b24: ret             
    // 0xfa0b28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa0b28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa0b2c: b               #0xfa0b00
  }
  _ BottomNavigationBar(/* No info */) {
    // ** addr: 0x1013cdc, size: 0x13c
    // 0x1013cdc: EnterFrame
    //     0x1013cdc: stp             fp, lr, [SP, #-0x10]!
    //     0x1013ce0: mov             fp, SP
    // 0x1013ce4: r4 = true
    //     0x1013ce4: add             x4, NULL, #0x20  ; true
    // 0x1013ce8: d2 = 24.000000
    //     0x1013ce8: fmov            d2, #24.00000000
    // 0x1013cec: d1 = 14.000000
    //     0x1013cec: fmov            d1, #14.00000000
    // 0x1013cf0: d0 = 12.000000
    //     0x1013cf0: fmov            d0, #12.00000000
    // 0x1013cf4: mov             x0, x5
    // 0x1013cf8: mov             x16, x7
    // 0x1013cfc: mov             x7, x1
    // 0x1013d00: mov             x1, x16
    // 0x1013d04: mov             x16, x6
    // 0x1013d08: mov             x6, x2
    // 0x1013d0c: mov             x2, x16
    // 0x1013d10: StoreField: r7->field_b = r0
    //     0x1013d10: stur            w0, [x7, #0xb]
    //     0x1013d14: ldurb           w16, [x7, #-1]
    //     0x1013d18: ldurb           w17, [x0, #-1]
    //     0x1013d1c: and             x16, x17, x16, lsr #2
    //     0x1013d20: tst             x16, HEAP, lsr #32
    //     0x1013d24: b.eq            #0x1013d2c
    //     0x1013d28: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0x1013d2c: mov             x0, x2
    // 0x1013d30: StoreField: r7->field_f = r0
    //     0x1013d30: stur            w0, [x7, #0xf]
    //     0x1013d34: ldurb           w16, [x7, #-1]
    //     0x1013d38: ldurb           w17, [x0, #-1]
    //     0x1013d3c: and             x16, x17, x16, lsr #2
    //     0x1013d40: tst             x16, HEAP, lsr #32
    //     0x1013d44: b.eq            #0x1013d4c
    //     0x1013d48: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0x1013d4c: StoreField: r7->field_13 = r3
    //     0x1013d4c: stur            x3, [x7, #0x13]
    // 0x1013d50: mov             x0, x6
    // 0x1013d54: StoreField: r7->field_23 = r0
    //     0x1013d54: stur            w0, [x7, #0x23]
    //     0x1013d58: ldurb           w16, [x7, #-1]
    //     0x1013d5c: ldurb           w17, [x0, #-1]
    //     0x1013d60: and             x16, x17, x16, lsr #2
    //     0x1013d64: tst             x16, HEAP, lsr #32
    //     0x1013d68: b.eq            #0x1013d70
    //     0x1013d6c: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0x1013d70: StoreField: r7->field_27 = d2
    //     0x1013d70: stur            d2, [x7, #0x27]
    // 0x1013d74: ldr             x0, [fp, #0x18]
    // 0x1013d78: StoreField: r7->field_33 = r0
    //     0x1013d78: stur            w0, [x7, #0x33]
    //     0x1013d7c: ldurb           w16, [x7, #-1]
    //     0x1013d80: ldurb           w17, [x0, #-1]
    //     0x1013d84: and             x16, x17, x16, lsr #2
    //     0x1013d88: tst             x16, HEAP, lsr #32
    //     0x1013d8c: b.eq            #0x1013d94
    //     0x1013d90: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0x1013d94: StoreField: r7->field_47 = d1
    //     0x1013d94: stur            d1, [x7, #0x47]
    // 0x1013d98: StoreField: r7->field_4f = d0
    //     0x1013d98: stur            d0, [x7, #0x4f]
    // 0x1013d9c: ldr             x0, [fp, #0x20]
    // 0x1013da0: StoreField: r7->field_3f = r0
    //     0x1013da0: stur            w0, [x7, #0x3f]
    //     0x1013da4: ldurb           w16, [x7, #-1]
    //     0x1013da8: ldurb           w17, [x0, #-1]
    //     0x1013dac: and             x16, x17, x16, lsr #2
    //     0x1013db0: tst             x16, HEAP, lsr #32
    //     0x1013db4: b.eq            #0x1013dbc
    //     0x1013db8: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0x1013dbc: ldr             x0, [fp, #0x10]
    // 0x1013dc0: StoreField: r7->field_43 = r0
    //     0x1013dc0: stur            w0, [x7, #0x43]
    //     0x1013dc4: ldurb           w16, [x7, #-1]
    //     0x1013dc8: ldurb           w17, [x0, #-1]
    //     0x1013dcc: and             x16, x17, x16, lsr #2
    //     0x1013dd0: tst             x16, HEAP, lsr #32
    //     0x1013dd4: b.eq            #0x1013ddc
    //     0x1013dd8: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0x1013ddc: StoreField: r7->field_5b = r4
    //     0x1013ddc: stur            w4, [x7, #0x5b]
    // 0x1013de0: StoreField: r7->field_57 = r4
    //     0x1013de0: stur            w4, [x7, #0x57]
    // 0x1013de4: StoreField: r7->field_6b = r4
    //     0x1013de4: stur            w4, [x7, #0x6b]
    // 0x1013de8: mov             x0, x1
    // 0x1013dec: StoreField: r7->field_2f = r0
    //     0x1013dec: stur            w0, [x7, #0x2f]
    //     0x1013df0: ldurb           w16, [x7, #-1]
    //     0x1013df4: ldurb           w17, [x0, #-1]
    //     0x1013df8: and             x16, x17, x16, lsr #2
    //     0x1013dfc: tst             x16, HEAP, lsr #32
    //     0x1013e00: b.eq            #0x1013e08
    //     0x1013e04: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0x1013e08: r0 = Null
    //     0x1013e08: mov             x0, NULL
    // 0x1013e0c: LeaveFrame
    //     0x1013e0c: mov             SP, fp
    //     0x1013e10: ldp             fp, lr, [SP], #0x10
    // 0x1013e14: ret
    //     0x1013e14: ret             
  }
}

// class id: 8299, size: 0x14, field offset: 0x14
enum BottomNavigationBarLandscapeLayout extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9d74, size: 0x64
    // 0x11a9d74: EnterFrame
    //     0x11a9d74: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9d78: mov             fp, SP
    // 0x11a9d7c: AllocStack(0x10)
    //     0x11a9d7c: sub             SP, SP, #0x10
    // 0x11a9d80: SetupParameters(BottomNavigationBarLandscapeLayout this /* r1 => r0, fp-0x8 */)
    //     0x11a9d80: mov             x0, x1
    //     0x11a9d84: stur            x1, [fp, #-8]
    // 0x11a9d88: CheckStackOverflow
    //     0x11a9d88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9d8c: cmp             SP, x16
    //     0x11a9d90: b.ls            #0x11a9dd0
    // 0x11a9d94: r1 = Null
    //     0x11a9d94: mov             x1, NULL
    // 0x11a9d98: r2 = 4
    //     0x11a9d98: mov             x2, #4
    // 0x11a9d9c: r0 = AllocateArray()
    //     0x11a9d9c: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9da0: r16 = "BottomNavigationBarLandscapeLayout."
    //     0x11a9da0: add             x16, PP, #0x9a, lsl #12  ; [pp+0x9a550] "BottomNavigationBarLandscapeLayout."
    //     0x11a9da4: ldr             x16, [x16, #0x550]
    // 0x11a9da8: StoreField: r0->field_f = r16
    //     0x11a9da8: stur            w16, [x0, #0xf]
    // 0x11a9dac: ldur            x1, [fp, #-8]
    // 0x11a9db0: LoadField: r2 = r1->field_f
    //     0x11a9db0: ldur            w2, [x1, #0xf]
    // 0x11a9db4: DecompressPointer r2
    //     0x11a9db4: add             x2, x2, HEAP, lsl #32
    // 0x11a9db8: StoreField: r0->field_13 = r2
    //     0x11a9db8: stur            w2, [x0, #0x13]
    // 0x11a9dbc: str             x0, [SP]
    // 0x11a9dc0: r0 = _interpolate()
    //     0x11a9dc0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9dc4: LeaveFrame
    //     0x11a9dc4: mov             SP, fp
    //     0x11a9dc8: ldp             fp, lr, [SP], #0x10
    // 0x11a9dcc: ret
    //     0x11a9dcc: ret             
    // 0x11a9dd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9dd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9dd4: b               #0x11a9d94
  }
}

// class id: 8300, size: 0x14, field offset: 0x14
enum BottomNavigationBarType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9d10, size: 0x64
    // 0x11a9d10: EnterFrame
    //     0x11a9d10: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9d14: mov             fp, SP
    // 0x11a9d18: AllocStack(0x10)
    //     0x11a9d18: sub             SP, SP, #0x10
    // 0x11a9d1c: SetupParameters(BottomNavigationBarType this /* r1 => r0, fp-0x8 */)
    //     0x11a9d1c: mov             x0, x1
    //     0x11a9d20: stur            x1, [fp, #-8]
    // 0x11a9d24: CheckStackOverflow
    //     0x11a9d24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9d28: cmp             SP, x16
    //     0x11a9d2c: b.ls            #0x11a9d6c
    // 0x11a9d30: r1 = Null
    //     0x11a9d30: mov             x1, NULL
    // 0x11a9d34: r2 = 4
    //     0x11a9d34: mov             x2, #4
    // 0x11a9d38: r0 = AllocateArray()
    //     0x11a9d38: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9d3c: r16 = "BottomNavigationBarType."
    //     0x11a9d3c: add             x16, PP, #0x9a, lsl #12  ; [pp+0x9a520] "BottomNavigationBarType."
    //     0x11a9d40: ldr             x16, [x16, #0x520]
    // 0x11a9d44: StoreField: r0->field_f = r16
    //     0x11a9d44: stur            w16, [x0, #0xf]
    // 0x11a9d48: ldur            x1, [fp, #-8]
    // 0x11a9d4c: LoadField: r2 = r1->field_f
    //     0x11a9d4c: ldur            w2, [x1, #0xf]
    // 0x11a9d50: DecompressPointer r2
    //     0x11a9d50: add             x2, x2, HEAP, lsl #32
    // 0x11a9d54: StoreField: r0->field_13 = r2
    //     0x11a9d54: stur            w2, [x0, #0x13]
    // 0x11a9d58: str             x0, [SP]
    // 0x11a9d5c: r0 = _interpolate()
    //     0x11a9d5c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9d60: LeaveFrame
    //     0x11a9d60: mov             SP, fp
    //     0x11a9d64: ldp             fp, lr, [SP], #0x10
    // 0x11a9d68: ret
    //     0x11a9d68: ret             
    // 0x11a9d6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9d6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9d70: b               #0x11a9d30
  }
}
