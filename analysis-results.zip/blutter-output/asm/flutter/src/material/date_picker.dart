// lib: , url: package:flutter/src/material/date_picker.dart

// class id: 1048875, size: 0x8
class :: {

  static _ showDatePicker(/* No info */) async {
    // ** addr: 0xe822b0, size: 0x15c
    // 0xe822b0: EnterFrame
    //     0xe822b0: stp             fp, lr, [SP, #-0x10]!
    //     0xe822b4: mov             fp, SP
    // 0xe822b8: AllocStack(0x78)
    //     0xe822b8: sub             SP, SP, #0x78
    // 0xe822bc: SetupParameters(dynamic _ /* r1 => r6, fp-0x18 */, dynamic _ /* r2 => r5, fp-0x20 */, dynamic _ /* r3 => r4, fp-0x28 */, dynamic _ /* r5 => r3, fp-0x30 */, dynamic _ /* r6 => r2, fp-0x38 */, dynamic _ /* r7 => r1, fp-0x40 */, dynamic _ /* r7, fp-0x10 */)
    //     0xe822bc: stur            NULL, [fp, #-8]
    //     0xe822c0: mov             x0, #0
    //     0xe822c4: mov             x4, x3
    //     0xe822c8: stur            x3, [fp, #-0x28]
    //     0xe822cc: mov             x3, x5
    //     0xe822d0: stur            x5, [fp, #-0x30]
    //     0xe822d4: mov             x5, x2
    //     0xe822d8: stur            x2, [fp, #-0x20]
    //     0xe822dc: mov             x2, x6
    //     0xe822e0: stur            x6, [fp, #-0x38]
    //     0xe822e4: mov             x6, x1
    //     0xe822e8: stur            x1, [fp, #-0x18]
    //     0xe822ec: mov             x1, x7
    //     0xe822f0: stur            x7, [fp, #-0x40]
    //     0xe822f4: add             x7, fp, w0, sxtw #2
    //     0xe822f8: ldr             x7, [x7, #0x10]
    //     0xe822fc: stur            x7, [fp, #-0x10]
    // 0xe82300: CheckStackOverflow
    //     0xe82300: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe82304: cmp             SP, x16
    //     0xe82308: b.ls            #0xe82404
    // 0xe8230c: r1 = 2
    //     0xe8230c: mov             x1, #2
    // 0xe82310: r0 = AllocateContext()
    //     0xe82310: bl              #0x13de838  ; AllocateContextStub
    // 0xe82314: mov             x1, x0
    // 0xe82318: ldur            x0, [fp, #-0x18]
    // 0xe8231c: stur            x1, [fp, #-0x48]
    // 0xe82320: StoreField: r1->field_f = r0
    //     0xe82320: stur            w0, [x1, #0xf]
    // 0xe82324: InitAsync() -> Future<DateTime?>
    //     0xe82324: add             x0, PP, #0x28, lsl #12  ; [pp+0x28500] TypeArguments: <DateTime?>
    //     0xe82328: ldr             x0, [x0, #0x500]
    //     0xe8232c: bl              #0x7f5e44  ; InitAsyncStub
    // 0xe82330: ldur            x1, [fp, #-0x38]
    // 0xe82334: r0 = dateOnly()
    //     0xe82334: bl              #0xd18a20  ; [package:flutter/src/material/date.dart] DateUtils::dateOnly
    // 0xe82338: ldur            x1, [fp, #-0x30]
    // 0xe8233c: stur            x0, [fp, #-0x18]
    // 0xe82340: r0 = dateOnly()
    //     0xe82340: bl              #0xd18a20  ; [package:flutter/src/material/date.dart] DateUtils::dateOnly
    // 0xe82344: ldur            x1, [fp, #-0x40]
    // 0xe82348: stur            x0, [fp, #-0x30]
    // 0xe8234c: r0 = dateOnly()
    //     0xe8234c: bl              #0xd18a20  ; [package:flutter/src/material/date.dart] DateUtils::dateOnly
    // 0xe82350: stur            x0, [fp, #-0x38]
    // 0xe82354: r0 = DatePickerDialog()
    //     0xe82354: bl              #0xe82648  ; AllocateDatePickerDialogStub -> DatePickerDialog (size=0x60)
    // 0xe82358: mov             x1, x0
    // 0xe8235c: ldur            x2, [fp, #-0x20]
    // 0xe82360: ldur            x3, [fp, #-0x30]
    // 0xe82364: ldur            x5, [fp, #-0x18]
    // 0xe82368: ldur            x6, [fp, #-0x38]
    // 0xe8236c: stur            x0, [fp, #-0x18]
    // 0xe82370: r0 = DatePickerDialog()
    //     0xe82370: bl              #0xe824f0  ; [package:flutter/src/material/date_picker.dart] DatePickerDialog::DatePickerDialog
    // 0xe82374: ldur            x0, [fp, #-0x18]
    // 0xe82378: ldur            x4, [fp, #-0x48]
    // 0xe8237c: StoreField: r4->field_13 = r0
    //     0xe8237c: stur            w0, [x4, #0x13]
    //     0xe82380: ldurb           w16, [x4, #-1]
    //     0xe82384: ldurb           w17, [x0, #-1]
    //     0xe82388: and             x16, x17, x16, lsr #2
    //     0xe8238c: tst             x16, HEAP, lsr #32
    //     0xe82390: b.eq            #0xe82398
    //     0xe82394: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xe82398: ldur            x2, [fp, #-0x18]
    // 0xe8239c: ldur            x3, [fp, #-0x28]
    // 0xe823a0: ldur            x5, [fp, #-0x10]
    // 0xe823a4: r1 = Null
    //     0xe823a4: mov             x1, NULL
    // 0xe823a8: r0 = Localizations.override()
    //     0xe823a8: bl              #0xe8240c  ; [package:flutter/src/widgets/localizations.dart] Localizations::Localizations.override
    // 0xe823ac: ldur            x2, [fp, #-0x48]
    // 0xe823b0: StoreField: r2->field_13 = r0
    //     0xe823b0: stur            w0, [x2, #0x13]
    //     0xe823b4: ldurb           w16, [x2, #-1]
    //     0xe823b8: ldurb           w17, [x0, #-1]
    //     0xe823bc: and             x16, x17, x16, lsr #2
    //     0xe823c0: tst             x16, HEAP, lsr #32
    //     0xe823c4: b.eq            #0xe823cc
    //     0xe823c8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xe823cc: r1 = Function '<anonymous closure>': static.
    //     0xe823cc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28508] AnonymousClosure: static (0xe82654), in [package:flutter/src/material/date_picker.dart] ::showDatePicker (0xe822b0)
    //     0xe823d0: ldr             x1, [x1, #0x508]
    // 0xe823d4: r0 = AllocateClosure()
    //     0xe823d4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe823d8: r16 = <DateTime>
    //     0xe823d8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14b10] TypeArguments: <DateTime>
    //     0xe823dc: ldr             x16, [x16, #0xb10]
    // 0xe823e0: stp             x0, x16, [SP, #0x20]
    // 0xe823e4: ldur            x16, [fp, #-0x28]
    // 0xe823e8: r30 = true
    //     0xe823e8: add             lr, NULL, #0x20  ; true
    // 0xe823ec: stp             lr, x16, [SP, #0x10]
    // 0xe823f0: stp             NULL, NULL, [SP]
    // 0xe823f4: r4 = const [0x1, 0x5, 0x5, 0x2, barrierColor, 0x3, barrierDismissible, 0x2, routeSettings, 0x4, null]
    //     0xe823f4: add             x4, PP, #0x28, lsl #12  ; [pp+0x28510] List(11) [0x1, 0x5, 0x5, 0x2, "barrierColor", 0x3, "barrierDismissible", 0x2, "routeSettings", 0x4, Null]
    //     0xe823f8: ldr             x4, [x4, #0x510]
    // 0xe823fc: r0 = showDialog()
    //     0xe823fc: bl              #0xd94f50  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0xe82400: r0 = ReturnAsync()
    //     0xe82400: b               #0x82fdf0  ; ReturnAsyncStub
    // 0xe82404: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe82404: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe82408: b               #0xe8230c
  }
  [closure] static Widget <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xe82654, size: 0x60
    // 0xe82654: EnterFrame
    //     0xe82654: stp             fp, lr, [SP, #-0x10]!
    //     0xe82658: mov             fp, SP
    // 0xe8265c: AllocStack(0x18)
    //     0xe8265c: sub             SP, SP, #0x18
    // 0xe82660: SetupParameters([dynamic _ /* r0 */])
    //     0xe82660: ldr             x0, [fp, #0x18]
    //     0xe82664: ldur            w1, [x0, #0x17]
    //     0xe82668: add             x1, x1, HEAP, lsl #32
    // 0xe8266c: CheckStackOverflow
    //     0xe8266c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe82670: cmp             SP, x16
    //     0xe82674: b.ls            #0xe826ac
    // 0xe82678: LoadField: r0 = r1->field_f
    //     0xe82678: ldur            w0, [x1, #0xf]
    // 0xe8267c: DecompressPointer r0
    //     0xe8267c: add             x0, x0, HEAP, lsl #32
    // 0xe82680: LoadField: r2 = r1->field_13
    //     0xe82680: ldur            w2, [x1, #0x13]
    // 0xe82684: DecompressPointer r2
    //     0xe82684: add             x2, x2, HEAP, lsl #32
    // 0xe82688: ldr             x16, [fp, #0x10]
    // 0xe8268c: stp             x16, x0, [SP, #8]
    // 0xe82690: str             x2, [SP]
    // 0xe82694: ClosureCall
    //     0xe82694: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xe82698: ldur            x2, [x0, #0x1f]
    //     0xe8269c: blr             x2
    // 0xe826a0: LeaveFrame
    //     0xe826a0: mov             SP, fp
    //     0xe826a4: ldp             fp, lr, [SP], #0x10
    // 0xe826a8: ret
    //     0xe826a8: ret             
    // 0xe826ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe826ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe826b0: b               #0xe82678
  }
}

// class id: 4509, size: 0x3c, field offset: 0x38
class _RestorableAutovalidateMode extends RestorableValue<dynamic> {

  _ toPrimitives(/* No info */) {
    // ** addr: 0x116f38c, size: 0x7c
    // 0x116f38c: EnterFrame
    //     0x116f38c: stp             fp, lr, [SP, #-0x10]!
    //     0x116f390: mov             fp, SP
    // 0x116f394: AllocStack(0x8)
    //     0x116f394: sub             SP, SP, #8
    // 0x116f398: LoadField: r3 = r1->field_33
    //     0x116f398: ldur            w3, [x1, #0x33]
    // 0x116f39c: DecompressPointer r3
    //     0x116f39c: add             x3, x3, HEAP, lsl #32
    // 0x116f3a0: stur            x3, [fp, #-8]
    // 0x116f3a4: cmp             w3, NULL
    // 0x116f3a8: b.ne            #0x116f3e0
    // 0x116f3ac: LoadField: r2 = r1->field_23
    //     0x116f3ac: ldur            w2, [x1, #0x23]
    // 0x116f3b0: DecompressPointer r2
    //     0x116f3b0: add             x2, x2, HEAP, lsl #32
    // 0x116f3b4: mov             x0, x3
    // 0x116f3b8: r1 = Null
    //     0x116f3b8: mov             x1, NULL
    // 0x116f3bc: cmp             w2, NULL
    // 0x116f3c0: b.eq            #0x116f3e0
    // 0x116f3c4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x116f3c4: ldur            w4, [x2, #0x17]
    // 0x116f3c8: DecompressPointer r4
    //     0x116f3c8: add             x4, x4, HEAP, lsl #32
    // 0x116f3cc: r8 = X0
    //     0x116f3cc: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x116f3d0: LoadField: r9 = r4->field_7
    //     0x116f3d0: ldur            x9, [x4, #7]
    // 0x116f3d4: r3 = Null
    //     0x116f3d4: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3e80] Null
    //     0x116f3d8: ldr             x3, [x3, #0xe80]
    // 0x116f3dc: blr             x9
    // 0x116f3e0: ldur            x2, [fp, #-8]
    // 0x116f3e4: LoadField: r3 = r2->field_7
    //     0x116f3e4: ldur            x3, [x2, #7]
    // 0x116f3e8: r0 = BoxInt64Instr(r3)
    //     0x116f3e8: sbfiz           x0, x3, #1, #0x1f
    //     0x116f3ec: cmp             x3, x0, asr #1
    //     0x116f3f0: b.eq            #0x116f3fc
    //     0x116f3f4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x116f3f8: stur            x3, [x0, #7]
    // 0x116f3fc: LeaveFrame
    //     0x116f3fc: mov             SP, fp
    //     0x116f400: ldp             fp, lr, [SP], #0x10
    // 0x116f404: ret
    //     0x116f404: ret             
  }
  _ createDefaultValue(/* No info */) {
    // ** addr: 0x1193014, size: 0xc
    // 0x1193014: r0 = Instance_AutovalidateMode
    //     0x1193014: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a608] Obj!AutovalidateMode@12c3061
    //     0x1193018: ldr             x0, [x0, #0x608]
    // 0x119301c: ret
    //     0x119301c: ret             
  }
}

// class id: 4510, size: 0x3c, field offset: 0x38
class _RestorableDatePickerEntryMode extends RestorableValue<dynamic> {

  _ toPrimitives(/* No info */) {
    // ** addr: 0x116f310, size: 0x7c
    // 0x116f310: EnterFrame
    //     0x116f310: stp             fp, lr, [SP, #-0x10]!
    //     0x116f314: mov             fp, SP
    // 0x116f318: AllocStack(0x8)
    //     0x116f318: sub             SP, SP, #8
    // 0x116f31c: LoadField: r3 = r1->field_33
    //     0x116f31c: ldur            w3, [x1, #0x33]
    // 0x116f320: DecompressPointer r3
    //     0x116f320: add             x3, x3, HEAP, lsl #32
    // 0x116f324: stur            x3, [fp, #-8]
    // 0x116f328: cmp             w3, NULL
    // 0x116f32c: b.ne            #0x116f364
    // 0x116f330: LoadField: r2 = r1->field_23
    //     0x116f330: ldur            w2, [x1, #0x23]
    // 0x116f334: DecompressPointer r2
    //     0x116f334: add             x2, x2, HEAP, lsl #32
    // 0x116f338: mov             x0, x3
    // 0x116f33c: r1 = Null
    //     0x116f33c: mov             x1, NULL
    // 0x116f340: cmp             w2, NULL
    // 0x116f344: b.eq            #0x116f364
    // 0x116f348: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x116f348: ldur            w4, [x2, #0x17]
    // 0x116f34c: DecompressPointer r4
    //     0x116f34c: add             x4, x4, HEAP, lsl #32
    // 0x116f350: r8 = X0
    //     0x116f350: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x116f354: LoadField: r9 = r4->field_7
    //     0x116f354: ldur            x9, [x4, #7]
    // 0x116f358: r3 = Null
    //     0x116f358: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3eb0] Null
    //     0x116f35c: ldr             x3, [x3, #0xeb0]
    // 0x116f360: blr             x9
    // 0x116f364: ldur            x2, [fp, #-8]
    // 0x116f368: LoadField: r3 = r2->field_7
    //     0x116f368: ldur            x3, [x2, #7]
    // 0x116f36c: r0 = BoxInt64Instr(r3)
    //     0x116f36c: sbfiz           x0, x3, #1, #0x1f
    //     0x116f370: cmp             x3, x0, asr #1
    //     0x116f374: b.eq            #0x116f380
    //     0x116f378: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x116f37c: stur            x3, [x0, #7]
    // 0x116f380: LeaveFrame
    //     0x116f380: mov             SP, fp
    //     0x116f384: ldp             fp, lr, [SP], #0x10
    // 0x116f388: ret
    //     0x116f388: ret             
  }
  _ createDefaultValue(/* No info */) {
    // ** addr: 0x1193008, size: 0xc
    // 0x1193008: r0 = Instance_DatePickerEntryMode
    //     0x1193008: add             x0, PP, #0x28, lsl #12  ; [pp+0x28520] Obj!DatePickerEntryMode@12c58c1
    //     0x119300c: ldr             x0, [x0, #0x520]
    // 0x1193010: ret
    //     0x1193010: ret             
  }
}

// class id: 5765, size: 0x38, field offset: 0x24
class _DatePickerDialogState extends _MixinApplication31&State&RestorationMixin {

  late final _RestorableDatePickerEntryMode _entryMode; // offset: 0x28
  late final RestorableDateTimeN _selectedDate; // offset: 0x24

  _ build(/* No info */) {
    // ** addr: 0xd14660, size: 0x11b0
    // 0xd14660: EnterFrame
    //     0xd14660: stp             fp, lr, [SP, #-0x10]!
    //     0xd14664: mov             fp, SP
    // 0xd14668: AllocStack(0xc0)
    //     0xd14668: sub             SP, SP, #0xc0
    // 0xd1466c: SetupParameters(_DatePickerDialogState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd1466c: mov             x0, x1
    //     0xd14670: stur            x1, [fp, #-8]
    //     0xd14674: mov             x1, x2
    //     0xd14678: stur            x2, [fp, #-0x10]
    // 0xd1467c: CheckStackOverflow
    //     0xd1467c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd14680: cmp             SP, x16
    //     0xd14684: b.ls            #0xd1577c
    // 0xd14688: r1 = 8
    //     0xd14688: mov             x1, #8
    // 0xd1468c: r0 = AllocateContext()
    //     0xd1468c: bl              #0x13de838  ; AllocateContextStub
    // 0xd14690: mov             x2, x0
    // 0xd14694: ldur            x0, [fp, #-8]
    // 0xd14698: stur            x2, [fp, #-0x18]
    // 0xd1469c: StoreField: r2->field_f = r0
    //     0xd1469c: stur            w0, [x2, #0xf]
    // 0xd146a0: ldur            x1, [fp, #-0x10]
    // 0xd146a4: r0 = of()
    //     0xd146a4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd146a8: stur            x0, [fp, #-0x28]
    // 0xd146ac: LoadField: r2 = r0->field_2f
    //     0xd146ac: ldur            w2, [x0, #0x2f]
    // 0xd146b0: DecompressPointer r2
    //     0xd146b0: add             x2, x2, HEAP, lsl #32
    // 0xd146b4: ldur            x3, [fp, #-0x18]
    // 0xd146b8: stur            x2, [fp, #-0x20]
    // 0xd146bc: StoreField: r3->field_13 = r2
    //     0xd146bc: stur            w2, [x3, #0x13]
    // 0xd146c0: ldur            x1, [fp, #-0x10]
    // 0xd146c4: r0 = of()
    //     0xd146c4: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xd146c8: ldur            x1, [fp, #-0x10]
    // 0xd146cc: stur            x0, [fp, #-0x30]
    // 0xd146d0: r0 = orientationOf()
    //     0xd146d0: bl              #0xd172a4  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::orientationOf
    // 0xd146d4: mov             x3, x0
    // 0xd146d8: ldur            x2, [fp, #-0x18]
    // 0xd146dc: stur            x3, [fp, #-0x40]
    // 0xd146e0: ArrayStore: r2[0] = r0  ; List_4
    //     0xd146e0: stur            w0, [x2, #0x17]
    //     0xd146e4: ldurb           w16, [x2, #-1]
    //     0xd146e8: ldurb           w17, [x0, #-1]
    //     0xd146ec: and             x16, x17, x16, lsr #2
    //     0xd146f0: tst             x16, HEAP, lsr #32
    //     0xd146f4: b.eq            #0xd146fc
    //     0xd146f8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd146fc: r16 = Instance_Orientation
    //     0xd146fc: add             x16, PP, #0x14, lsl #12  ; [pp+0x143c0] Obj!Orientation@12c2ee1
    //     0xd14700: ldr             x16, [x16, #0x3c0]
    // 0xd14704: cmp             w3, w16
    // 0xd14708: r16 = true
    //     0xd14708: add             x16, NULL, #0x20  ; true
    // 0xd1470c: r17 = false
    //     0xd1470c: add             x17, NULL, #0x30  ; false
    // 0xd14710: csel            x0, x16, x17, eq
    // 0xd14714: ldur            x1, [fp, #-0x10]
    // 0xd14718: stur            x0, [fp, #-0x38]
    // 0xd1471c: r0 = of()
    //     0xd1471c: bl              #0xd0ff6c  ; [package:flutter/src/material/date_picker_theme.dart] DatePickerTheme::of
    // 0xd14720: mov             x3, x0
    // 0xd14724: ldur            x2, [fp, #-0x18]
    // 0xd14728: stur            x3, [fp, #-0x48]
    // 0xd1472c: StoreField: r2->field_1b = r0
    //     0xd1472c: stur            w0, [x2, #0x1b]
    //     0xd14730: ldurb           w16, [x2, #-1]
    //     0xd14734: ldurb           w17, [x0, #-1]
    //     0xd14738: and             x16, x17, x16, lsr #2
    //     0xd1473c: tst             x16, HEAP, lsr #32
    //     0xd14740: b.eq            #0xd14748
    //     0xd14744: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd14748: ldur            x1, [fp, #-0x10]
    // 0xd1474c: r0 = defaults()
    //     0xd1474c: bl              #0xd0fd74  ; [package:flutter/src/material/date_picker_theme.dart] DatePickerTheme::defaults
    // 0xd14750: mov             x2, x0
    // 0xd14754: ldur            x0, [fp, #-0x28]
    // 0xd14758: stur            x2, [fp, #-0x58]
    // 0xd1475c: LoadField: r3 = r0->field_87
    //     0xd1475c: ldur            w3, [x0, #0x87]
    // 0xd14760: DecompressPointer r3
    //     0xd14760: add             x3, x3, HEAP, lsl #32
    // 0xd14764: ldur            x4, [fp, #-0x20]
    // 0xd14768: stur            x3, [fp, #-0x50]
    // 0xd1476c: tbnz            w4, #4, #0xd148dc
    // 0xd14770: r1 = LoadClassIdInstr(r2)
    //     0xd14770: ldur            x1, [x2, #-1]
    //     0xd14774: ubfx            x1, x1, #0xc, #0x14
    // 0xd14778: r17 = 5167
    //     0xd14778: mov             x17, #0x142f
    // 0xd1477c: cmp             x1, x17
    // 0xd14780: b.ne            #0xd14794
    // 0xd14784: LoadField: r1 = r2->field_23
    //     0xd14784: ldur            w1, [x2, #0x23]
    // 0xd14788: DecompressPointer r1
    //     0xd14788: add             x1, x1, HEAP, lsl #32
    // 0xd1478c: mov             x0, x1
    // 0xd14790: b               #0xd14804
    // 0xd14794: r17 = 5168
    //     0xd14794: mov             x17, #0x1430
    // 0xd14798: cmp             x1, x17
    // 0xd1479c: b.ne            #0xd147d4
    // 0xd147a0: mov             x1, x2
    // 0xd147a4: LoadField: r0 = r1->field_b7
    //     0xd147a4: ldur            w0, [x1, #0xb7]
    // 0xd147a8: DecompressPointer r0
    //     0xd147a8: add             x0, x0, HEAP, lsl #32
    // 0xd147ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd147b0: cmp             w0, w16
    // 0xd147b4: b.ne            #0xd147c4
    // 0xd147b8: r2 = _textTheme
    //     0xd147b8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0xd147bc: ldr             x2, [x2, #0x418]
    // 0xd147c0: r0 = InitLateFinalInstanceField()
    //     0xd147c0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd147c4: LoadField: r1 = r0->field_13
    //     0xd147c4: ldur            w1, [x0, #0x13]
    // 0xd147c8: DecompressPointer r1
    //     0xd147c8: add             x1, x1, HEAP, lsl #32
    // 0xd147cc: mov             x0, x1
    // 0xd147d0: b               #0xd14804
    // 0xd147d4: ldur            x1, [fp, #-0x58]
    // 0xd147d8: LoadField: r0 = r1->field_b7
    //     0xd147d8: ldur            w0, [x1, #0xb7]
    // 0xd147dc: DecompressPointer r0
    //     0xd147dc: add             x0, x0, HEAP, lsl #32
    // 0xd147e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd147e4: cmp             w0, w16
    // 0xd147e8: b.ne            #0xd147f8
    // 0xd147ec: r2 = _textTheme
    //     0xd147ec: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0xd147f0: ldr             x2, [x2, #0x420]
    // 0xd147f4: r0 = InitLateFinalInstanceField()
    //     0xd147f4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd147f8: LoadField: r1 = r0->field_1b
    //     0xd147f8: ldur            w1, [x0, #0x1b]
    // 0xd147fc: DecompressPointer r1
    //     0xd147fc: add             x1, x1, HEAP, lsl #32
    // 0xd14800: mov             x0, x1
    // 0xd14804: ldur            x1, [fp, #-8]
    // 0xd14808: stur            x0, [fp, #-0x60]
    // 0xd1480c: LoadField: r0 = r1->field_27
    //     0xd1480c: ldur            w0, [x1, #0x27]
    // 0xd14810: DecompressPointer r0
    //     0xd14810: add             x0, x0, HEAP, lsl #32
    // 0xd14814: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd14818: cmp             w0, w16
    // 0xd1481c: b.ne            #0xd1482c
    // 0xd14820: r2 = _entryMode
    //     0xd14820: add             x2, PP, #0x99, lsl #12  ; [pp+0x99ba8] Field <_DatePickerDialogState@75078594._entryMode@75078594>: late final (offset: 0x28)
    //     0xd14824: ldr             x2, [x2, #0xba8]
    // 0xd14828: r0 = InitLateFinalInstanceField()
    //     0xd14828: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd1482c: LoadField: r3 = r0->field_33
    //     0xd1482c: ldur            w3, [x0, #0x33]
    // 0xd14830: DecompressPointer r3
    //     0xd14830: add             x3, x3, HEAP, lsl #32
    // 0xd14834: stur            x3, [fp, #-0x68]
    // 0xd14838: cmp             w3, NULL
    // 0xd1483c: b.ne            #0xd14874
    // 0xd14840: LoadField: r2 = r0->field_23
    //     0xd14840: ldur            w2, [x0, #0x23]
    // 0xd14844: DecompressPointer r2
    //     0xd14844: add             x2, x2, HEAP, lsl #32
    // 0xd14848: mov             x0, x3
    // 0xd1484c: r1 = Null
    //     0xd1484c: mov             x1, NULL
    // 0xd14850: cmp             w2, NULL
    // 0xd14854: b.eq            #0xd14874
    // 0xd14858: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd14858: ldur            w4, [x2, #0x17]
    // 0xd1485c: DecompressPointer r4
    //     0xd1485c: add             x4, x4, HEAP, lsl #32
    // 0xd14860: r8 = X0
    //     0xd14860: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd14864: LoadField: r9 = r4->field_7
    //     0xd14864: ldur            x9, [x4, #7]
    // 0xd14868: r3 = Null
    //     0xd14868: add             x3, PP, #0x99, lsl #12  ; [pp+0x99bb0] Null
    //     0xd1486c: ldr             x3, [x3, #0xbb0]
    // 0xd14870: blr             x9
    // 0xd14874: ldur            x0, [fp, #-0x68]
    // 0xd14878: LoadField: r1 = r0->field_7
    //     0xd14878: ldur            x1, [x0, #7]
    // 0xd1487c: cmp             x1, #1
    // 0xd14880: b.gt            #0xd14890
    // 0xd14884: cmp             x1, #0
    // 0xd14888: b.gt            #0xd148a4
    // 0xd1488c: b               #0xd14898
    // 0xd14890: cmp             x1, #2
    // 0xd14894: b.gt            #0xd148a4
    // 0xd14898: ldur            x1, [fp, #-0x60]
    // 0xd1489c: ldur            x0, [fp, #-0x40]
    // 0xd148a0: b               #0xd148d0
    // 0xd148a4: ldur            x0, [fp, #-0x40]
    // 0xd148a8: r16 = Instance_Orientation
    //     0xd148a8: add             x16, PP, #0x14, lsl #12  ; [pp+0x143c0] Obj!Orientation@12c2ee1
    //     0xd148ac: ldr             x16, [x16, #0x3c0]
    // 0xd148b0: cmp             w0, w16
    // 0xd148b4: b.ne            #0xd148cc
    // 0xd148b8: ldur            x1, [fp, #-0x50]
    // 0xd148bc: LoadField: r2 = r1->field_1b
    //     0xd148bc: ldur            w2, [x1, #0x1b]
    // 0xd148c0: DecompressPointer r2
    //     0xd148c0: add             x2, x2, HEAP, lsl #32
    // 0xd148c4: mov             x1, x2
    // 0xd148c8: b               #0xd148d0
    // 0xd148cc: ldur            x1, [fp, #-0x60]
    // 0xd148d0: mov             x4, x1
    // 0xd148d4: ldur            x2, [fp, #-0x38]
    // 0xd148d8: b               #0xd1490c
    // 0xd148dc: ldur            x0, [fp, #-0x40]
    // 0xd148e0: mov             x1, x3
    // 0xd148e4: ldur            x2, [fp, #-0x38]
    // 0xd148e8: tbnz            w2, #4, #0xd148fc
    // 0xd148ec: LoadField: r3 = r1->field_1b
    //     0xd148ec: ldur            w3, [x1, #0x1b]
    // 0xd148f0: DecompressPointer r3
    //     0xd148f0: add             x3, x3, HEAP, lsl #32
    // 0xd148f4: mov             x1, x3
    // 0xd148f8: b               #0xd14908
    // 0xd148fc: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xd148fc: ldur            w3, [x1, #0x17]
    // 0xd14900: DecompressPointer r3
    //     0xd14900: add             x3, x3, HEAP, lsl #32
    // 0xd14904: mov             x1, x3
    // 0xd14908: mov             x4, x1
    // 0xd1490c: ldur            x3, [fp, #-0x48]
    // 0xd14910: stur            x4, [fp, #-0x50]
    // 0xd14914: LoadField: r1 = r3->field_1f
    //     0xd14914: ldur            w1, [x3, #0x1f]
    // 0xd14918: DecompressPointer r1
    //     0xd14918: add             x1, x1, HEAP, lsl #32
    // 0xd1491c: cmp             w1, NULL
    // 0xd14920: b.ne            #0xd14a34
    // 0xd14924: ldur            x5, [fp, #-0x58]
    // 0xd14928: r1 = LoadClassIdInstr(r5)
    //     0xd14928: ldur            x1, [x5, #-1]
    //     0xd1492c: ubfx            x1, x1, #0xc, #0x14
    // 0xd14930: r17 = 5167
    //     0xd14930: mov             x17, #0x142f
    // 0xd14934: cmp             x1, x17
    // 0xd14938: b.ne            #0xd1494c
    // 0xd1493c: LoadField: r1 = r5->field_1f
    //     0xd1493c: ldur            w1, [x5, #0x1f]
    // 0xd14940: DecompressPointer r1
    //     0xd14940: add             x1, x1, HEAP, lsl #32
    // 0xd14944: mov             x0, x1
    // 0xd14948: b               #0xd14a38
    // 0xd1494c: r17 = 5168
    //     0xd1494c: mov             x17, #0x1430
    // 0xd14950: cmp             x1, x17
    // 0xd14954: b.ne            #0xd149a4
    // 0xd14958: mov             x1, x5
    // 0xd1495c: LoadField: r0 = r1->field_b3
    //     0xd1495c: ldur            w0, [x1, #0xb3]
    // 0xd14960: DecompressPointer r0
    //     0xd14960: add             x0, x0, HEAP, lsl #32
    // 0xd14964: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd14968: cmp             w0, w16
    // 0xd1496c: b.ne            #0xd1497c
    // 0xd14970: r2 = _colors
    //     0xd14970: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xd14974: ldr             x2, [x2, #0x400]
    // 0xd14978: r0 = InitLateFinalInstanceField()
    //     0xd14978: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd1497c: LoadField: r1 = r0->field_a3
    //     0xd1497c: ldur            w1, [x0, #0xa3]
    // 0xd14980: DecompressPointer r1
    //     0xd14980: add             x1, x1, HEAP, lsl #32
    // 0xd14984: cmp             w1, NULL
    // 0xd14988: b.ne            #0xd1499c
    // 0xd1498c: LoadField: r1 = r0->field_7f
    //     0xd1498c: ldur            w1, [x0, #0x7f]
    // 0xd14990: DecompressPointer r1
    //     0xd14990: add             x1, x1, HEAP, lsl #32
    // 0xd14994: mov             x0, x1
    // 0xd14998: b               #0xd14a38
    // 0xd1499c: mov             x0, x1
    // 0xd149a0: b               #0xd14a38
    // 0xd149a4: ldur            x1, [fp, #-0x58]
    // 0xd149a8: LoadField: r0 = r1->field_bb
    //     0xd149a8: ldur            w0, [x1, #0xbb]
    // 0xd149ac: DecompressPointer r0
    //     0xd149ac: add             x0, x0, HEAP, lsl #32
    // 0xd149b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd149b4: cmp             w0, w16
    // 0xd149b8: b.ne            #0xd149c8
    // 0xd149bc: r2 = _isDark
    //     0xd149bc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26408] Field <_DatePickerDefaultsM2@738353974._isDark@738353974>: late final (offset: 0xbc)
    //     0xd149c0: ldr             x2, [x2, #0x408]
    // 0xd149c4: r0 = InitLateFinalInstanceField()
    //     0xd149c4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd149c8: tbnz            w0, #4, #0xd14a00
    // 0xd149cc: ldur            x1, [fp, #-0x58]
    // 0xd149d0: LoadField: r0 = r1->field_b3
    //     0xd149d0: ldur            w0, [x1, #0xb3]
    // 0xd149d4: DecompressPointer r0
    //     0xd149d4: add             x0, x0, HEAP, lsl #32
    // 0xd149d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd149dc: cmp             w0, w16
    // 0xd149e0: b.ne            #0xd149f0
    // 0xd149e4: r2 = _colors
    //     0xd149e4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xd149e8: ldr             x2, [x2, #0x410]
    // 0xd149ec: r0 = InitLateFinalInstanceField()
    //     0xd149ec: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd149f0: LoadField: r1 = r0->field_7f
    //     0xd149f0: ldur            w1, [x0, #0x7f]
    // 0xd149f4: DecompressPointer r1
    //     0xd149f4: add             x1, x1, HEAP, lsl #32
    // 0xd149f8: mov             x0, x1
    // 0xd149fc: b               #0xd14a38
    // 0xd14a00: ldur            x1, [fp, #-0x58]
    // 0xd14a04: LoadField: r0 = r1->field_b3
    //     0xd14a04: ldur            w0, [x1, #0xb3]
    // 0xd14a08: DecompressPointer r0
    //     0xd14a08: add             x0, x0, HEAP, lsl #32
    // 0xd14a0c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd14a10: cmp             w0, w16
    // 0xd14a14: b.ne            #0xd14a24
    // 0xd14a18: r2 = _colors
    //     0xd14a18: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xd14a1c: ldr             x2, [x2, #0x410]
    // 0xd14a20: r0 = InitLateFinalInstanceField()
    //     0xd14a20: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd14a24: LoadField: r1 = r0->field_f
    //     0xd14a24: ldur            w1, [x0, #0xf]
    // 0xd14a28: DecompressPointer r1
    //     0xd14a28: add             x1, x1, HEAP, lsl #32
    // 0xd14a2c: mov             x0, x1
    // 0xd14a30: b               #0xd14a38
    // 0xd14a34: mov             x0, x1
    // 0xd14a38: ldur            x1, [fp, #-0x50]
    // 0xd14a3c: stur            x0, [fp, #-0x60]
    // 0xd14a40: cmp             w1, NULL
    // 0xd14a44: b.ne            #0xd14a50
    // 0xd14a48: r1 = Null
    //     0xd14a48: mov             x1, NULL
    // 0xd14a4c: b               #0xd14a64
    // 0xd14a50: str             x0, [SP]
    // 0xd14a54: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xd14a54: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xd14a58: ldr             x4, [x4, #0x7f0]
    // 0xd14a5c: r0 = copyWith()
    //     0xd14a5c: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xd14a60: mov             x1, x0
    // 0xd14a64: ldur            x0, [fp, #-0x38]
    // 0xd14a68: stur            x1, [fp, #-0x50]
    // 0xd14a6c: tbnz            w0, #4, #0xd14a7c
    // 0xd14a70: d0 = 1.600000
    //     0xd14a70: add             x17, PP, #0x99, lsl #12  ; [pp+0x99bc0] IMM: double(1.6) from 0x3ff999999999999a
    //     0xd14a74: ldr             d0, [x17, #0xbc0]
    // 0xd14a78: b               #0xd14a80
    // 0xd14a7c: d0 = 3.000000
    //     0xd14a7c: fmov            d0, #3.00000000
    // 0xd14a80: ldur            x2, [fp, #-0x48]
    // 0xd14a84: stur            d0, [fp, #-0x90]
    // 0xd14a88: LoadField: r3 = r2->field_97
    //     0xd14a88: ldur            w3, [x2, #0x97]
    // 0xd14a8c: DecompressPointer r3
    //     0xd14a8c: add             x3, x3, HEAP, lsl #32
    // 0xd14a90: cmp             w3, NULL
    // 0xd14a94: b.ne            #0xd14af0
    // 0xd14a98: ldur            x3, [fp, #-0x58]
    // 0xd14a9c: r4 = LoadClassIdInstr(r3)
    //     0xd14a9c: ldur            x4, [x3, #-1]
    //     0xd14aa0: ubfx            x4, x4, #0xc, #0x14
    // 0xd14aa4: r17 = 5167
    //     0xd14aa4: mov             x17, #0x142f
    // 0xd14aa8: cmp             x4, x17
    // 0xd14aac: b.ne            #0xd14ac0
    // 0xd14ab0: LoadField: r4 = r3->field_97
    //     0xd14ab0: ldur            w4, [x3, #0x97]
    // 0xd14ab4: DecompressPointer r4
    //     0xd14ab4: add             x4, x4, HEAP, lsl #32
    // 0xd14ab8: mov             x0, x4
    // 0xd14abc: b               #0xd14ae8
    // 0xd14ac0: r17 = 5168
    //     0xd14ac0: mov             x17, #0x1430
    // 0xd14ac4: cmp             x4, x17
    // 0xd14ac8: b.ne            #0xd14adc
    // 0xd14acc: r4 = const [0, 0, 0, 0, null]
    //     0xd14acc: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1eed8] List(5) [0, 0, 0, 0, Null]
    //     0xd14ad0: ldr             x4, [x4, #0xed8]
    // 0xd14ad4: r0 = styleFrom()
    //     0xd14ad4: bl              #0xd16538  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0xd14ad8: b               #0xd14ae8
    // 0xd14adc: r4 = const [0, 0, 0, 0, null]
    //     0xd14adc: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1eed8] List(5) [0, 0, 0, 0, Null]
    //     0xd14ae0: ldr             x4, [x4, #0xed8]
    // 0xd14ae4: r0 = styleFrom()
    //     0xd14ae4: bl              #0xd16538  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0xd14ae8: mov             x1, x0
    // 0xd14aec: b               #0xd14af4
    // 0xd14af0: mov             x1, x3
    // 0xd14af4: ldur            x2, [fp, #-8]
    // 0xd14af8: ldur            x0, [fp, #-0x48]
    // 0xd14afc: stur            x1, [fp, #-0x70]
    // 0xd14b00: LoadField: r3 = r2->field_b
    //     0xd14b00: ldur            w3, [x2, #0xb]
    // 0xd14b04: DecompressPointer r3
    //     0xd14b04: add             x3, x3, HEAP, lsl #32
    // 0xd14b08: cmp             w3, NULL
    // 0xd14b0c: b.eq            #0xd15784
    // 0xd14b10: LoadField: r4 = r3->field_23
    //     0xd14b10: ldur            w4, [x3, #0x23]
    // 0xd14b14: DecompressPointer r4
    //     0xd14b14: add             x4, x4, HEAP, lsl #32
    // 0xd14b18: stur            x4, [fp, #-0x68]
    // 0xd14b1c: r0 = Text()
    //     0xd14b1c: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xd14b20: mov             x1, x0
    // 0xd14b24: ldur            x0, [fp, #-0x68]
    // 0xd14b28: stur            x1, [fp, #-0x78]
    // 0xd14b2c: StoreField: r1->field_b = r0
    //     0xd14b2c: stur            w0, [x1, #0xb]
    // 0xd14b30: r0 = TextButton()
    //     0xd14b30: bl              #0xd1652c  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0xd14b34: mov             x3, x0
    // 0xd14b38: r0 = false
    //     0xd14b38: add             x0, NULL, #0x30  ; false
    // 0xd14b3c: stur            x3, [fp, #-0x68]
    // 0xd14b40: StoreField: r3->field_3b = r0
    //     0xd14b40: stur            w0, [x3, #0x3b]
    // 0xd14b44: ldur            x2, [fp, #-8]
    // 0xd14b48: r1 = Function '_handleCancel@75078594':.
    //     0xd14b48: add             x1, PP, #0x99, lsl #12  ; [pp+0x99bc8] AnonymousClosure: (0xd19b24), in [package:flutter/src/material/date_picker.dart] _DatePickerDialogState::_handleCancel (0xd19b5c)
    //     0xd14b4c: ldr             x1, [x1, #0xbc8]
    // 0xd14b50: r0 = AllocateClosure()
    //     0xd14b50: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd14b54: mov             x1, x0
    // 0xd14b58: ldur            x0, [fp, #-0x68]
    // 0xd14b5c: StoreField: r0->field_b = r1
    //     0xd14b5c: stur            w1, [x0, #0xb]
    // 0xd14b60: ldur            x1, [fp, #-0x70]
    // 0xd14b64: StoreField: r0->field_1b = r1
    //     0xd14b64: stur            w1, [x0, #0x1b]
    // 0xd14b68: r1 = false
    //     0xd14b68: add             x1, NULL, #0x30  ; false
    // 0xd14b6c: StoreField: r0->field_27 = r1
    //     0xd14b6c: stur            w1, [x0, #0x27]
    // 0xd14b70: r2 = true
    //     0xd14b70: add             x2, NULL, #0x20  ; true
    // 0xd14b74: StoreField: r0->field_2f = r2
    //     0xd14b74: stur            w2, [x0, #0x2f]
    // 0xd14b78: ldur            x3, [fp, #-0x78]
    // 0xd14b7c: StoreField: r0->field_37 = r3
    //     0xd14b7c: stur            w3, [x0, #0x37]
    // 0xd14b80: ldur            x3, [fp, #-0x48]
    // 0xd14b84: LoadField: r4 = r3->field_9b
    //     0xd14b84: ldur            w4, [x3, #0x9b]
    // 0xd14b88: DecompressPointer r4
    //     0xd14b88: add             x4, x4, HEAP, lsl #32
    // 0xd14b8c: cmp             w4, NULL
    // 0xd14b90: b.ne            #0xd14bec
    // 0xd14b94: ldur            x4, [fp, #-0x58]
    // 0xd14b98: r5 = LoadClassIdInstr(r4)
    //     0xd14b98: ldur            x5, [x4, #-1]
    //     0xd14b9c: ubfx            x5, x5, #0xc, #0x14
    // 0xd14ba0: r17 = 5167
    //     0xd14ba0: mov             x17, #0x142f
    // 0xd14ba4: cmp             x5, x17
    // 0xd14ba8: b.ne            #0xd14bbc
    // 0xd14bac: LoadField: r5 = r4->field_9b
    //     0xd14bac: ldur            w5, [x4, #0x9b]
    // 0xd14bb0: DecompressPointer r5
    //     0xd14bb0: add             x5, x5, HEAP, lsl #32
    // 0xd14bb4: mov             x0, x5
    // 0xd14bb8: b               #0xd14be4
    // 0xd14bbc: r17 = 5168
    //     0xd14bbc: mov             x17, #0x1430
    // 0xd14bc0: cmp             x5, x17
    // 0xd14bc4: b.ne            #0xd14bd8
    // 0xd14bc8: r4 = const [0, 0, 0, 0, null]
    //     0xd14bc8: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1eed8] List(5) [0, 0, 0, 0, Null]
    //     0xd14bcc: ldr             x4, [x4, #0xed8]
    // 0xd14bd0: r0 = styleFrom()
    //     0xd14bd0: bl              #0xd16538  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0xd14bd4: b               #0xd14be4
    // 0xd14bd8: r4 = const [0, 0, 0, 0, null]
    //     0xd14bd8: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1eed8] List(5) [0, 0, 0, 0, Null]
    //     0xd14bdc: ldr             x4, [x4, #0xed8]
    // 0xd14be0: r0 = styleFrom()
    //     0xd14be0: bl              #0xd16538  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0xd14be4: mov             x6, x0
    // 0xd14be8: b               #0xd14bf0
    // 0xd14bec: mov             x6, x4
    // 0xd14bf0: ldur            x3, [fp, #-8]
    // 0xd14bf4: ldur            x4, [fp, #-0x18]
    // 0xd14bf8: ldur            x5, [fp, #-0x30]
    // 0xd14bfc: ldur            d0, [fp, #-0x90]
    // 0xd14c00: ldur            x2, [fp, #-0x68]
    // 0xd14c04: stur            x6, [fp, #-0x70]
    // 0xd14c08: LoadField: r0 = r3->field_b
    //     0xd14c08: ldur            w0, [x3, #0xb]
    // 0xd14c0c: DecompressPointer r0
    //     0xd14c0c: add             x0, x0, HEAP, lsl #32
    // 0xd14c10: cmp             w0, NULL
    // 0xd14c14: b.eq            #0xd15788
    // 0xd14c18: r0 = LoadClassIdInstr(r5)
    //     0xd14c18: ldur            x0, [x5, #-1]
    //     0xd14c1c: ubfx            x0, x0, #0xc, #0x14
    // 0xd14c20: mov             x1, x5
    // 0xd14c24: r0 = GDT[cid_x0 + 0x15418]()
    //     0xd14c24: mov             x17, #0x5418
    //     0xd14c28: movk            x17, #1, lsl #16
    //     0xd14c2c: add             lr, x0, x17
    //     0xd14c30: ldr             lr, [x21, lr, lsl #3]
    //     0xd14c34: blr             lr
    // 0xd14c38: stur            x0, [fp, #-0x78]
    // 0xd14c3c: r0 = Text()
    //     0xd14c3c: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xd14c40: mov             x1, x0
    // 0xd14c44: ldur            x0, [fp, #-0x78]
    // 0xd14c48: stur            x1, [fp, #-0x80]
    // 0xd14c4c: StoreField: r1->field_b = r0
    //     0xd14c4c: stur            w0, [x1, #0xb]
    // 0xd14c50: r0 = TextButton()
    //     0xd14c50: bl              #0xd1652c  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0xd14c54: mov             x3, x0
    // 0xd14c58: r0 = false
    //     0xd14c58: add             x0, NULL, #0x30  ; false
    // 0xd14c5c: stur            x3, [fp, #-0x78]
    // 0xd14c60: StoreField: r3->field_3b = r0
    //     0xd14c60: stur            w0, [x3, #0x3b]
    // 0xd14c64: ldur            x2, [fp, #-8]
    // 0xd14c68: r1 = Function '_handleOk@75078594':.
    //     0xd14c68: add             x1, PP, #0x99, lsl #12  ; [pp+0x99bd0] AnonymousClosure: (0xd18e88), in [package:flutter/src/material/date_picker.dart] _DatePickerDialogState::_handleOk (0xd18ec0)
    //     0xd14c6c: ldr             x1, [x1, #0xbd0]
    // 0xd14c70: r0 = AllocateClosure()
    //     0xd14c70: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd14c74: mov             x1, x0
    // 0xd14c78: ldur            x0, [fp, #-0x78]
    // 0xd14c7c: StoreField: r0->field_b = r1
    //     0xd14c7c: stur            w1, [x0, #0xb]
    // 0xd14c80: ldur            x1, [fp, #-0x70]
    // 0xd14c84: StoreField: r0->field_1b = r1
    //     0xd14c84: stur            w1, [x0, #0x1b]
    // 0xd14c88: r3 = false
    //     0xd14c88: add             x3, NULL, #0x30  ; false
    // 0xd14c8c: StoreField: r0->field_27 = r3
    //     0xd14c8c: stur            w3, [x0, #0x27]
    // 0xd14c90: r1 = true
    //     0xd14c90: add             x1, NULL, #0x20  ; true
    // 0xd14c94: StoreField: r0->field_2f = r1
    //     0xd14c94: stur            w1, [x0, #0x2f]
    // 0xd14c98: ldur            x1, [fp, #-0x80]
    // 0xd14c9c: StoreField: r0->field_37 = r1
    //     0xd14c9c: stur            w1, [x0, #0x37]
    // 0xd14ca0: r1 = Null
    //     0xd14ca0: mov             x1, NULL
    // 0xd14ca4: r2 = 4
    //     0xd14ca4: mov             x2, #4
    // 0xd14ca8: r0 = AllocateArray()
    //     0xd14ca8: bl              #0x13df928  ; AllocateArrayStub
    // 0xd14cac: mov             x2, x0
    // 0xd14cb0: ldur            x0, [fp, #-0x68]
    // 0xd14cb4: stur            x2, [fp, #-0x70]
    // 0xd14cb8: StoreField: r2->field_f = r0
    //     0xd14cb8: stur            w0, [x2, #0xf]
    // 0xd14cbc: ldur            x0, [fp, #-0x78]
    // 0xd14cc0: StoreField: r2->field_13 = r0
    //     0xd14cc0: stur            w0, [x2, #0x13]
    // 0xd14cc4: r1 = <Widget>
    //     0xd14cc4: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd14cc8: r0 = AllocateGrowableArray()
    //     0xd14cc8: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd14ccc: mov             x1, x0
    // 0xd14cd0: ldur            x0, [fp, #-0x70]
    // 0xd14cd4: stur            x1, [fp, #-0x68]
    // 0xd14cd8: StoreField: r1->field_f = r0
    //     0xd14cd8: stur            w0, [x1, #0xf]
    // 0xd14cdc: r0 = 4
    //     0xd14cdc: mov             x0, #4
    // 0xd14ce0: StoreField: r1->field_b = r0
    //     0xd14ce0: stur            w0, [x1, #0xb]
    // 0xd14ce4: r0 = OverflowBar()
    //     0xd14ce4: bl              #0xd16520  ; AllocateOverflowBarStub -> OverflowBar (size=0x30)
    // 0xd14ce8: d0 = 8.000000
    //     0xd14ce8: fmov            d0, #8.00000000
    // 0xd14cec: stur            x0, [fp, #-0x70]
    // 0xd14cf0: StoreField: r0->field_f = d0
    //     0xd14cf0: stur            d0, [x0, #0xf]
    // 0xd14cf4: StoreField: r0->field_1b = rZR
    //     0xd14cf4: stur            xzr, [x0, #0x1b]
    // 0xd14cf8: r1 = Instance_OverflowBarAlignment
    //     0xd14cf8: add             x1, PP, #0x99, lsl #12  ; [pp+0x99bd8] Obj!OverflowBarAlignment@12c2861
    //     0xd14cfc: ldr             x1, [x1, #0xbd8]
    // 0xd14d00: StoreField: r0->field_23 = r1
    //     0xd14d00: stur            w1, [x0, #0x23]
    // 0xd14d04: r1 = Instance_VerticalDirection
    //     0xd14d04: add             x1, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xd14d08: ldr             x1, [x1, #0x838]
    // 0xd14d0c: StoreField: r0->field_27 = r1
    //     0xd14d0c: stur            w1, [x0, #0x27]
    // 0xd14d10: ldur            x1, [fp, #-0x68]
    // 0xd14d14: StoreField: r0->field_b = r1
    //     0xd14d14: stur            w1, [x0, #0xb]
    // 0xd14d18: r0 = Align()
    //     0xd14d18: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xd14d1c: mov             x1, x0
    // 0xd14d20: r0 = Instance_AlignmentDirectional
    //     0xd14d20: add             x0, PP, #0x99, lsl #12  ; [pp+0x99aa0] Obj!AlignmentDirectional@129e631
    //     0xd14d24: ldr             x0, [x0, #0xaa0]
    // 0xd14d28: stur            x1, [fp, #-0x68]
    // 0xd14d2c: StoreField: r1->field_f = r0
    //     0xd14d2c: stur            w0, [x1, #0xf]
    // 0xd14d30: ldur            x0, [fp, #-0x70]
    // 0xd14d34: StoreField: r1->field_b = r0
    //     0xd14d34: stur            w0, [x1, #0xb]
    // 0xd14d38: r0 = Padding()
    //     0xd14d38: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xd14d3c: mov             x1, x0
    // 0xd14d40: r0 = Instance_EdgeInsets
    //     0xd14d40: add             x0, PP, #0x7a, lsl #12  ; [pp+0x7abf0] Obj!EdgeInsets@129cd21
    //     0xd14d44: ldr             x0, [x0, #0xbf0]
    // 0xd14d48: StoreField: r1->field_f = r0
    //     0xd14d48: stur            w0, [x1, #0xf]
    // 0xd14d4c: ldur            x0, [fp, #-0x68]
    // 0xd14d50: StoreField: r1->field_b = r0
    //     0xd14d50: stur            w0, [x1, #0xb]
    // 0xd14d54: ldur            d0, [fp, #-0x90]
    // 0xd14d58: r0 = inline_Allocate_Double()
    //     0xd14d58: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xd14d5c: add             x0, x0, #0x10
    //     0xd14d60: cmp             x2, x0
    //     0xd14d64: b.ls            #0xd1578c
    //     0xd14d68: str             x0, [THR, #0x60]  ; THR::top
    //     0xd14d6c: sub             x0, x0, #0xf
    //     0xd14d70: mov             x2, #0xe19c
    //     0xd14d74: movk            x2, #3, lsl #16
    //     0xd14d78: stur            x2, [x0, #-1]
    // 0xd14d7c: dmb             ishst
    // 0xd14d80: StoreField: r0->field_7 = d0
    //     0xd14d80: stur            d0, [x0, #7]
    // 0xd14d84: str             x0, [SP]
    // 0xd14d88: r4 = const [0, 0x2, 0x1, 0x1, maxScaleFactor, 0x1, null]
    //     0xd14d88: add             x4, PP, #0x90, lsl #12  ; [pp+0x90d70] List(7) [0, 0x2, 0x1, 0x1, "maxScaleFactor", 0x1, Null]
    //     0xd14d8c: ldr             x4, [x4, #0xd70]
    // 0xd14d90: r0 = withClampedTextScaling()
    //     0xd14d90: bl              #0xd16294  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::withClampedTextScaling
    // 0xd14d94: stur            x0, [fp, #-0x68]
    // 0xd14d98: r0 = ConstrainedBox()
    //     0xd14d98: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xd14d9c: mov             x1, x0
    // 0xd14da0: r0 = Instance_BoxConstraints
    //     0xd14da0: add             x0, PP, #0x99, lsl #12  ; [pp+0x99be0] Obj!BoxConstraints@129c201
    //     0xd14da4: ldr             x0, [x0, #0xbe0]
    // 0xd14da8: StoreField: r1->field_f = r0
    //     0xd14da8: stur            w0, [x1, #0xf]
    // 0xd14dac: ldur            x0, [fp, #-0x68]
    // 0xd14db0: StoreField: r1->field_b = r0
    //     0xd14db0: stur            w0, [x1, #0xb]
    // 0xd14db4: mov             x0, x1
    // 0xd14db8: ldur            x3, [fp, #-0x18]
    // 0xd14dbc: StoreField: r3->field_1f = r0
    //     0xd14dbc: stur            w0, [x3, #0x1f]
    //     0xd14dc0: ldurb           w16, [x3, #-1]
    //     0xd14dc4: ldurb           w17, [x0, #-1]
    //     0xd14dc8: and             x16, x17, x16, lsr #2
    //     0xd14dcc: tst             x16, HEAP, lsr #32
    //     0xd14dd0: b.eq            #0xd14dd8
    //     0xd14dd4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd14dd8: mov             x2, x3
    // 0xd14ddc: r1 = Function 'calendarDatePicker':.
    //     0xd14ddc: add             x1, PP, #0x99, lsl #12  ; [pp+0x99be8] AnonymousClosure: (0xd18b80), in [package:flutter/src/material/date_picker.dart] _DatePickerDialogState::build (0xd14660)
    //     0xd14de0: ldr             x1, [x1, #0xbe8]
    // 0xd14de4: r0 = AllocateClosure()
    //     0xd14de4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd14de8: ldur            x2, [fp, #-0x18]
    // 0xd14dec: r1 = Function 'inputDatePicker':.
    //     0xd14dec: add             x1, PP, #0x99, lsl #12  ; [pp+0x99bf0] AnonymousClosure: (0xd18528), in [package:flutter/src/material/date_picker.dart] _DatePickerDialogState::build (0xd14660)
    //     0xd14df0: ldr             x1, [x1, #0xbf0]
    // 0xd14df4: stur            x0, [fp, #-0x68]
    // 0xd14df8: r0 = AllocateClosure()
    //     0xd14df8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd14dfc: ldur            x2, [fp, #-0x18]
    // 0xd14e00: stur            x0, [fp, #-0x70]
    // 0xd14e04: StoreField: r2->field_23 = rNULL
    //     0xd14e04: stur            NULL, [x2, #0x23]
    // 0xd14e08: ldur            x1, [fp, #-8]
    // 0xd14e0c: LoadField: r0 = r1->field_27
    //     0xd14e0c: ldur            w0, [x1, #0x27]
    // 0xd14e10: DecompressPointer r0
    //     0xd14e10: add             x0, x0, HEAP, lsl #32
    // 0xd14e14: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd14e18: cmp             w0, w16
    // 0xd14e1c: b.ne            #0xd14e2c
    // 0xd14e20: r2 = _entryMode
    //     0xd14e20: add             x2, PP, #0x99, lsl #12  ; [pp+0x99ba8] Field <_DatePickerDialogState@75078594._entryMode@75078594>: late final (offset: 0x28)
    //     0xd14e24: ldr             x2, [x2, #0xba8]
    // 0xd14e28: r0 = InitLateFinalInstanceField()
    //     0xd14e28: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd14e2c: LoadField: r3 = r0->field_33
    //     0xd14e2c: ldur            w3, [x0, #0x33]
    // 0xd14e30: DecompressPointer r3
    //     0xd14e30: add             x3, x3, HEAP, lsl #32
    // 0xd14e34: stur            x3, [fp, #-0x78]
    // 0xd14e38: cmp             w3, NULL
    // 0xd14e3c: b.ne            #0xd14e74
    // 0xd14e40: LoadField: r2 = r0->field_23
    //     0xd14e40: ldur            w2, [x0, #0x23]
    // 0xd14e44: DecompressPointer r2
    //     0xd14e44: add             x2, x2, HEAP, lsl #32
    // 0xd14e48: mov             x0, x3
    // 0xd14e4c: r1 = Null
    //     0xd14e4c: mov             x1, NULL
    // 0xd14e50: cmp             w2, NULL
    // 0xd14e54: b.eq            #0xd14e74
    // 0xd14e58: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd14e58: ldur            w4, [x2, #0x17]
    // 0xd14e5c: DecompressPointer r4
    //     0xd14e5c: add             x4, x4, HEAP, lsl #32
    // 0xd14e60: r8 = X0
    //     0xd14e60: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd14e64: LoadField: r9 = r4->field_7
    //     0xd14e64: ldur            x9, [x4, #7]
    // 0xd14e68: r3 = Null
    //     0xd14e68: add             x3, PP, #0x99, lsl #12  ; [pp+0x99bf8] Null
    //     0xd14e6c: ldr             x3, [x3, #0xbf8]
    // 0xd14e70: blr             x9
    // 0xd14e74: ldur            x0, [fp, #-0x78]
    // 0xd14e78: LoadField: r1 = r0->field_7
    //     0xd14e78: ldur            x1, [x0, #7]
    // 0xd14e7c: cmp             x1, #1
    // 0xd14e80: b.gt            #0xd150a0
    // 0xd14e84: cmp             x1, #0
    // 0xd14e88: b.gt            #0xd14fa8
    // 0xd14e8c: ldur            x1, [fp, #-8]
    // 0xd14e90: ldur            x2, [fp, #-0x18]
    // 0xd14e94: ldur            x3, [fp, #-0x20]
    // 0xd14e98: ldur            x16, [fp, #-0x68]
    // 0xd14e9c: str             x16, [SP]
    // 0xd14ea0: ldur            x0, [fp, #-0x68]
    // 0xd14ea4: ClosureCall
    //     0xd14ea4: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xd14ea8: ldur            x2, [x0, #0x1f]
    //     0xd14eac: blr             x2
    // 0xd14eb0: ldur            x2, [fp, #-0x18]
    // 0xd14eb4: StoreField: r2->field_23 = r0
    //     0xd14eb4: stur            w0, [x2, #0x23]
    //     0xd14eb8: tbz             w0, #0, #0xd14ed4
    //     0xd14ebc: ldurb           w16, [x2, #-1]
    //     0xd14ec0: ldurb           w17, [x0, #-1]
    //     0xd14ec4: and             x16, x17, x16, lsr #2
    //     0xd14ec8: tst             x16, HEAP, lsr #32
    //     0xd14ecc: b.eq            #0xd14ed4
    //     0xd14ed0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd14ed4: ldur            x0, [fp, #-8]
    // 0xd14ed8: LoadField: r1 = r0->field_b
    //     0xd14ed8: ldur            w1, [x0, #0xb]
    // 0xd14edc: DecompressPointer r1
    //     0xd14edc: add             x1, x1, HEAP, lsl #32
    // 0xd14ee0: cmp             w1, NULL
    // 0xd14ee4: b.eq            #0xd157a4
    // 0xd14ee8: ldur            x1, [fp, #-0x20]
    // 0xd14eec: tbnz            w1, #4, #0xd14efc
    // 0xd14ef0: r5 = Instance_IconData
    //     0xd14ef0: add             x5, PP, #0x99, lsl #12  ; [pp+0x99c08] Obj!IconData@128a271
    //     0xd14ef4: ldr             x5, [x5, #0xc08]
    // 0xd14ef8: b               #0xd14f04
    // 0xd14efc: r5 = Instance_IconData
    //     0xd14efc: add             x5, PP, #0x1a, lsl #12  ; [pp+0x1ada0] Obj!IconData@128a291
    //     0xd14f00: ldr             x5, [x5, #0xda0]
    // 0xd14f04: ldur            x3, [fp, #-0x30]
    // 0xd14f08: ldur            x4, [fp, #-0x60]
    // 0xd14f0c: stur            x5, [fp, #-0x78]
    // 0xd14f10: r0 = Icon()
    //     0xd14f10: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xd14f14: mov             x2, x0
    // 0xd14f18: ldur            x0, [fp, #-0x78]
    // 0xd14f1c: stur            x2, [fp, #-0x80]
    // 0xd14f20: StoreField: r2->field_b = r0
    //     0xd14f20: stur            w0, [x2, #0xb]
    // 0xd14f24: ldur            x3, [fp, #-0x30]
    // 0xd14f28: r0 = LoadClassIdInstr(r3)
    //     0xd14f28: ldur            x0, [x3, #-1]
    //     0xd14f2c: ubfx            x0, x0, #0xc, #0x14
    // 0xd14f30: mov             x1, x3
    // 0xd14f34: r0 = GDT[cid_x0 + 0x123d9]()
    //     0xd14f34: mov             x17, #0x23d9
    //     0xd14f38: movk            x17, #1, lsl #16
    //     0xd14f3c: add             lr, x0, x17
    //     0xd14f40: ldr             lr, [x21, lr, lsl #3]
    //     0xd14f44: blr             lr
    // 0xd14f48: stur            x0, [fp, #-0x78]
    // 0xd14f4c: r0 = IconButton()
    //     0xd14f4c: bl              #0xd16288  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0xd14f50: ldur            x1, [fp, #-0x60]
    // 0xd14f54: stur            x0, [fp, #-0x88]
    // 0xd14f58: StoreField: r0->field_2b = r1
    //     0xd14f58: stur            w1, [x0, #0x2b]
    // 0xd14f5c: ldur            x2, [fp, #-8]
    // 0xd14f60: r1 = Function '_handleEntryModeToggle@75078594':.
    //     0xd14f60: add             x1, PP, #0x99, lsl #12  ; [pp+0x99c10] AnonymousClosure: (0xd17b28), in [package:flutter/src/material/date_picker.dart] _DatePickerDialogState::_handleEntryModeToggle (0xd17b60)
    //     0xd14f64: ldr             x1, [x1, #0xc10]
    // 0xd14f68: r0 = AllocateClosure()
    //     0xd14f68: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd14f6c: mov             x1, x0
    // 0xd14f70: ldur            x0, [fp, #-0x88]
    // 0xd14f74: StoreField: r0->field_3b = r1
    //     0xd14f74: stur            w1, [x0, #0x3b]
    // 0xd14f78: r2 = false
    //     0xd14f78: add             x2, NULL, #0x30  ; false
    // 0xd14f7c: StoreField: r0->field_4f = r2
    //     0xd14f7c: stur            w2, [x0, #0x4f]
    // 0xd14f80: ldur            x1, [fp, #-0x78]
    // 0xd14f84: StoreField: r0->field_53 = r1
    //     0xd14f84: stur            w1, [x0, #0x53]
    // 0xd14f88: ldur            x1, [fp, #-0x80]
    // 0xd14f8c: StoreField: r0->field_1f = r1
    //     0xd14f8c: stur            w1, [x0, #0x1f]
    // 0xd14f90: r3 = Instance__IconButtonVariant
    //     0xd14f90: add             x3, PP, #0x17, lsl #12  ; [pp+0x177a8] Obj!_IconButtonVariant@12c57a1
    //     0xd14f94: ldr             x3, [x3, #0x7a8]
    // 0xd14f98: StoreField: r0->field_6f = r3
    //     0xd14f98: stur            w3, [x0, #0x6f]
    // 0xd14f9c: mov             x5, x0
    // 0xd14fa0: ldur            x2, [fp, #-0x18]
    // 0xd14fa4: b               #0xd15138
    // 0xd14fa8: ldur            x6, [fp, #-8]
    // 0xd14fac: ldur            x5, [fp, #-0x18]
    // 0xd14fb0: ldur            x4, [fp, #-0x30]
    // 0xd14fb4: ldur            x1, [fp, #-0x60]
    // 0xd14fb8: r2 = false
    //     0xd14fb8: add             x2, NULL, #0x30  ; false
    // 0xd14fbc: r3 = Instance__IconButtonVariant
    //     0xd14fbc: add             x3, PP, #0x17, lsl #12  ; [pp+0x177a8] Obj!_IconButtonVariant@12c57a1
    //     0xd14fc0: ldr             x3, [x3, #0x7a8]
    // 0xd14fc4: ldur            x16, [fp, #-0x70]
    // 0xd14fc8: str             x16, [SP]
    // 0xd14fcc: ldur            x0, [fp, #-0x70]
    // 0xd14fd0: ClosureCall
    //     0xd14fd0: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xd14fd4: ldur            x2, [x0, #0x1f]
    //     0xd14fd8: blr             x2
    // 0xd14fdc: ldur            x2, [fp, #-0x18]
    // 0xd14fe0: StoreField: r2->field_23 = r0
    //     0xd14fe0: stur            w0, [x2, #0x23]
    //     0xd14fe4: tbz             w0, #0, #0xd15000
    //     0xd14fe8: ldurb           w16, [x2, #-1]
    //     0xd14fec: ldurb           w17, [x0, #-1]
    //     0xd14ff0: and             x16, x17, x16, lsr #2
    //     0xd14ff4: tst             x16, HEAP, lsr #32
    //     0xd14ff8: b.eq            #0xd15000
    //     0xd14ffc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd15000: ldur            x3, [fp, #-8]
    // 0xd15004: LoadField: r0 = r3->field_b
    //     0xd15004: ldur            w0, [x3, #0xb]
    // 0xd15008: DecompressPointer r0
    //     0xd15008: add             x0, x0, HEAP, lsl #32
    // 0xd1500c: cmp             w0, NULL
    // 0xd15010: b.eq            #0xd157a8
    // 0xd15014: ldur            x4, [fp, #-0x30]
    // 0xd15018: r0 = LoadClassIdInstr(r4)
    //     0xd15018: ldur            x0, [x4, #-1]
    //     0xd1501c: ubfx            x0, x0, #0xc, #0x14
    // 0xd15020: mov             x1, x4
    // 0xd15024: r0 = GDT[cid_x0 + 0x12058]()
    //     0xd15024: mov             x17, #0x2058
    //     0xd15028: movk            x17, #1, lsl #16
    //     0xd1502c: add             lr, x0, x17
    //     0xd15030: ldr             lr, [x21, lr, lsl #3]
    //     0xd15034: blr             lr
    // 0xd15038: stur            x0, [fp, #-0x78]
    // 0xd1503c: r0 = IconButton()
    //     0xd1503c: bl              #0xd16288  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0xd15040: mov             x3, x0
    // 0xd15044: ldur            x0, [fp, #-0x60]
    // 0xd15048: stur            x3, [fp, #-0x80]
    // 0xd1504c: StoreField: r3->field_2b = r0
    //     0xd1504c: stur            w0, [x3, #0x2b]
    // 0xd15050: ldur            x2, [fp, #-8]
    // 0xd15054: r1 = Function '_handleEntryModeToggle@75078594':.
    //     0xd15054: add             x1, PP, #0x99, lsl #12  ; [pp+0x99c10] AnonymousClosure: (0xd17b28), in [package:flutter/src/material/date_picker.dart] _DatePickerDialogState::_handleEntryModeToggle (0xd17b60)
    //     0xd15058: ldr             x1, [x1, #0xc10]
    // 0xd1505c: r0 = AllocateClosure()
    //     0xd1505c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd15060: mov             x1, x0
    // 0xd15064: ldur            x0, [fp, #-0x80]
    // 0xd15068: StoreField: r0->field_3b = r1
    //     0xd15068: stur            w1, [x0, #0x3b]
    // 0xd1506c: r2 = false
    //     0xd1506c: add             x2, NULL, #0x30  ; false
    // 0xd15070: StoreField: r0->field_4f = r2
    //     0xd15070: stur            w2, [x0, #0x4f]
    // 0xd15074: ldur            x1, [fp, #-0x78]
    // 0xd15078: StoreField: r0->field_53 = r1
    //     0xd15078: stur            w1, [x0, #0x53]
    // 0xd1507c: r1 = Instance_Icon
    //     0xd1507c: add             x1, PP, #0x99, lsl #12  ; [pp+0x99c18] Obj!Icon@12b5ca1
    //     0xd15080: ldr             x1, [x1, #0xc18]
    // 0xd15084: StoreField: r0->field_1f = r1
    //     0xd15084: stur            w1, [x0, #0x1f]
    // 0xd15088: r1 = Instance__IconButtonVariant
    //     0xd15088: add             x1, PP, #0x17, lsl #12  ; [pp+0x177a8] Obj!_IconButtonVariant@12c57a1
    //     0xd1508c: ldr             x1, [x1, #0x7a8]
    // 0xd15090: StoreField: r0->field_6f = r1
    //     0xd15090: stur            w1, [x0, #0x6f]
    // 0xd15094: mov             x5, x0
    // 0xd15098: ldur            x2, [fp, #-0x18]
    // 0xd1509c: b               #0xd15138
    // 0xd150a0: r2 = false
    //     0xd150a0: add             x2, NULL, #0x30  ; false
    // 0xd150a4: cmp             x1, #2
    // 0xd150a8: b.gt            #0xd150f4
    // 0xd150ac: ldur            x1, [fp, #-0x18]
    // 0xd150b0: ldur            x16, [fp, #-0x68]
    // 0xd150b4: str             x16, [SP]
    // 0xd150b8: ldur            x0, [fp, #-0x68]
    // 0xd150bc: ClosureCall
    //     0xd150bc: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xd150c0: ldur            x2, [x0, #0x1f]
    //     0xd150c4: blr             x2
    // 0xd150c8: ldur            x2, [fp, #-0x18]
    // 0xd150cc: StoreField: r2->field_23 = r0
    //     0xd150cc: stur            w0, [x2, #0x23]
    //     0xd150d0: tbz             w0, #0, #0xd150ec
    //     0xd150d4: ldurb           w16, [x2, #-1]
    //     0xd150d8: ldurb           w17, [x0, #-1]
    //     0xd150dc: and             x16, x17, x16, lsr #2
    //     0xd150e0: tst             x16, HEAP, lsr #32
    //     0xd150e4: b.eq            #0xd150ec
    //     0xd150e8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd150ec: r5 = Null
    //     0xd150ec: mov             x5, NULL
    // 0xd150f0: b               #0xd15138
    // 0xd150f4: ldur            x2, [fp, #-0x18]
    // 0xd150f8: ldur            x16, [fp, #-0x70]
    // 0xd150fc: str             x16, [SP]
    // 0xd15100: ldur            x0, [fp, #-0x70]
    // 0xd15104: ClosureCall
    //     0xd15104: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xd15108: ldur            x2, [x0, #0x1f]
    //     0xd1510c: blr             x2
    // 0xd15110: ldur            x2, [fp, #-0x18]
    // 0xd15114: StoreField: r2->field_23 = r0
    //     0xd15114: stur            w0, [x2, #0x23]
    //     0xd15118: tbz             w0, #0, #0xd15134
    //     0xd1511c: ldurb           w16, [x2, #-1]
    //     0xd15120: ldurb           w17, [x0, #-1]
    //     0xd15124: and             x16, x17, x16, lsr #2
    //     0xd15128: tst             x16, HEAP, lsr #32
    //     0xd1512c: b.eq            #0xd15134
    //     0xd15130: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd15134: r5 = Null
    //     0xd15134: mov             x5, NULL
    // 0xd15138: ldur            x3, [fp, #-8]
    // 0xd1513c: ldur            x4, [fp, #-0x20]
    // 0xd15140: stur            x5, [fp, #-0x60]
    // 0xd15144: LoadField: r0 = r3->field_b
    //     0xd15144: ldur            w0, [x3, #0xb]
    // 0xd15148: DecompressPointer r0
    //     0xd15148: add             x0, x0, HEAP, lsl #32
    // 0xd1514c: cmp             w0, NULL
    // 0xd15150: b.eq            #0xd157ac
    // 0xd15154: tbnz            w4, #4, #0xd15180
    // 0xd15158: ldur            x6, [fp, #-0x30]
    // 0xd1515c: r0 = LoadClassIdInstr(r6)
    //     0xd1515c: ldur            x0, [x6, #-1]
    //     0xd15160: ubfx            x0, x0, #0xc, #0x14
    // 0xd15164: mov             x1, x6
    // 0xd15168: r0 = GDT[cid_x0 + 0x15a33]()
    //     0xd15168: mov             x17, #0x5a33
    //     0xd1516c: movk            x17, #1, lsl #16
    //     0xd15170: add             lr, x0, x17
    //     0xd15174: ldr             lr, [x21, lr, lsl #3]
    //     0xd15178: blr             lr
    // 0xd1517c: b               #0xd151c0
    // 0xd15180: ldur            x2, [fp, #-0x30]
    // 0xd15184: r0 = LoadClassIdInstr(r2)
    //     0xd15184: ldur            x0, [x2, #-1]
    //     0xd15188: ubfx            x0, x0, #0xc, #0x14
    // 0xd1518c: mov             x1, x2
    // 0xd15190: r0 = GDT[cid_x0 + 0x15a33]()
    //     0xd15190: mov             x17, #0x5a33
    //     0xd15194: movk            x17, #1, lsl #16
    //     0xd15198: add             lr, x0, x17
    //     0xd1519c: ldr             lr, [x21, lr, lsl #3]
    //     0xd151a0: blr             lr
    // 0xd151a4: r1 = LoadClassIdInstr(r0)
    //     0xd151a4: ldur            x1, [x0, #-1]
    //     0xd151a8: ubfx            x1, x1, #0xc, #0x14
    // 0xd151ac: str             x0, [SP]
    // 0xd151b0: mov             x0, x1
    // 0xd151b4: r0 = GDT[cid_x0 + -0xff8]()
    //     0xd151b4: sub             lr, x0, #0xff8
    //     0xd151b8: ldr             lr, [x21, lr, lsl #3]
    //     0xd151bc: blr             lr
    // 0xd151c0: ldur            x1, [fp, #-8]
    // 0xd151c4: stur            x0, [fp, #-0x68]
    // 0xd151c8: LoadField: r0 = r1->field_23
    //     0xd151c8: ldur            w0, [x1, #0x23]
    // 0xd151cc: DecompressPointer r0
    //     0xd151cc: add             x0, x0, HEAP, lsl #32
    // 0xd151d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd151d4: cmp             w0, w16
    // 0xd151d8: b.ne            #0xd151e8
    // 0xd151dc: r2 = _selectedDate
    //     0xd151dc: add             x2, PP, #0x99, lsl #12  ; [pp+0x99c20] Field <_DatePickerDialogState@75078594._selectedDate@75078594>: late final (offset: 0x24)
    //     0xd151e0: ldr             x2, [x2, #0xc20]
    // 0xd151e4: r0 = InitLateFinalInstanceField()
    //     0xd151e4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd151e8: LoadField: r3 = r0->field_33
    //     0xd151e8: ldur            w3, [x0, #0x33]
    // 0xd151ec: DecompressPointer r3
    //     0xd151ec: add             x3, x3, HEAP, lsl #32
    // 0xd151f0: stur            x3, [fp, #-0x70]
    // 0xd151f4: cmp             w3, NULL
    // 0xd151f8: b.ne            #0xd15230
    // 0xd151fc: LoadField: r2 = r0->field_23
    //     0xd151fc: ldur            w2, [x0, #0x23]
    // 0xd15200: DecompressPointer r2
    //     0xd15200: add             x2, x2, HEAP, lsl #32
    // 0xd15204: mov             x0, x3
    // 0xd15208: r1 = Null
    //     0xd15208: mov             x1, NULL
    // 0xd1520c: cmp             w2, NULL
    // 0xd15210: b.eq            #0xd15230
    // 0xd15214: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd15214: ldur            w4, [x2, #0x17]
    // 0xd15218: DecompressPointer r4
    //     0xd15218: add             x4, x4, HEAP, lsl #32
    // 0xd1521c: r8 = X0
    //     0xd1521c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd15220: LoadField: r9 = r4->field_7
    //     0xd15220: ldur            x9, [x4, #7]
    // 0xd15224: r3 = Null
    //     0xd15224: add             x3, PP, #0x99, lsl #12  ; [pp+0x99c28] Null
    //     0xd15228: ldr             x3, [x3, #0xc28]
    // 0xd1522c: blr             x9
    // 0xd15230: ldur            x2, [fp, #-0x70]
    // 0xd15234: cmp             w2, NULL
    // 0xd15238: b.ne            #0xd15244
    // 0xd1523c: r8 = ""
    //     0xd1523c: ldr             x8, [PP, #0x900]  ; [pp+0x900] ""
    // 0xd15240: b               #0xd1526c
    // 0xd15244: ldur            x0, [fp, #-8]
    // 0xd15248: LoadField: r1 = r0->field_b
    //     0xd15248: ldur            w1, [x0, #0xb]
    // 0xd1524c: DecompressPointer r1
    //     0xd1524c: add             x1, x1, HEAP, lsl #32
    // 0xd15250: cmp             w1, NULL
    // 0xd15254: b.eq            #0xd157b0
    // 0xd15258: ldur            x3, [fp, #-0x30]
    // 0xd1525c: r1 = Instance_GregorianCalendarDelegate
    //     0xd1525c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xd15260: ldr             x1, [x1, #0x538]
    // 0xd15264: r0 = formatMediumDate()
    //     0xd15264: bl              #0xd1623c  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::formatMediumDate
    // 0xd15268: mov             x8, x0
    // 0xd1526c: ldur            x2, [fp, #-0x18]
    // 0xd15270: ldur            x7, [fp, #-0x28]
    // 0xd15274: ldur            x6, [fp, #-0x40]
    // 0xd15278: ldur            x3, [fp, #-0x48]
    // 0xd1527c: ldur            x5, [fp, #-0x50]
    // 0xd15280: ldur            x1, [fp, #-0x60]
    // 0xd15284: ldur            x0, [fp, #-0x68]
    // 0xd15288: ldur            x4, [fp, #-0x38]
    // 0xd1528c: stur            x8, [fp, #-0x30]
    // 0xd15290: r0 = _DatePickerHeader()
    //     0xd15290: bl              #0xd16230  ; Allocate_DatePickerHeaderStub -> _DatePickerHeader (size=0x28)
    // 0xd15294: mov             x1, x0
    // 0xd15298: ldur            x0, [fp, #-0x68]
    // 0xd1529c: StoreField: r1->field_b = r0
    //     0xd1529c: stur            w0, [x1, #0xb]
    // 0xd152a0: ldur            x0, [fp, #-0x30]
    // 0xd152a4: StoreField: r1->field_f = r0
    //     0xd152a4: stur            w0, [x1, #0xf]
    // 0xd152a8: ldur            x0, [fp, #-0x50]
    // 0xd152ac: ArrayStore: r1[0] = r0  ; List_4
    //     0xd152ac: stur            w0, [x1, #0x17]
    // 0xd152b0: ldur            x0, [fp, #-0x40]
    // 0xd152b4: StoreField: r1->field_1b = r0
    //     0xd152b4: stur            w0, [x1, #0x1b]
    // 0xd152b8: ldur            x0, [fp, #-0x38]
    // 0xd152bc: StoreField: r1->field_1f = r0
    //     0xd152bc: stur            w0, [x1, #0x1f]
    // 0xd152c0: ldur            x0, [fp, #-0x60]
    // 0xd152c4: StoreField: r1->field_23 = r0
    //     0xd152c4: stur            w0, [x1, #0x23]
    // 0xd152c8: mov             x0, x1
    // 0xd152cc: ldur            x2, [fp, #-0x18]
    // 0xd152d0: StoreField: r2->field_27 = r0
    //     0xd152d0: stur            w0, [x2, #0x27]
    //     0xd152d4: ldurb           w16, [x2, #-1]
    //     0xd152d8: ldurb           w17, [x0, #-1]
    //     0xd152dc: and             x16, x17, x16, lsr #2
    //     0xd152e0: tst             x16, HEAP, lsr #32
    //     0xd152e4: b.eq            #0xd152ec
    //     0xd152e8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd152ec: ldur            x1, [fp, #-0x10]
    // 0xd152f0: r0 = textScalerOf()
    //     0xd152f0: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0xd152f4: r1 = LoadClassIdInstr(r0)
    //     0xd152f4: ldur            x1, [x0, #-1]
    //     0xd152f8: ubfx            x1, x1, #0xc, #0x14
    // 0xd152fc: mov             x16, x0
    // 0xd15300: mov             x0, x1
    // 0xd15304: mov             x1, x16
    // 0xd15308: d0 = 3.000000
    //     0xd15308: fmov            d0, #3.00000000
    // 0xd1530c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xd1530c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xd15310: r0 = GDT[cid_x0 + -0xffa]()
    //     0xd15310: sub             lr, x0, #0xffa
    //     0xd15314: ldr             lr, [x21, lr, lsl #3]
    //     0xd15318: blr             lr
    // 0xd1531c: r1 = LoadClassIdInstr(r0)
    //     0xd1531c: ldur            x1, [x0, #-1]
    //     0xd15320: ubfx            x1, x1, #0xc, #0x14
    // 0xd15324: mov             x16, x0
    // 0xd15328: mov             x0, x1
    // 0xd1532c: mov             x1, x16
    // 0xd15330: d0 = 14.000000
    //     0xd15330: fmov            d0, #14.00000000
    // 0xd15334: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd15334: sub             lr, x0, #1, lsl #12
    //     0xd15338: ldr             lr, [x21, lr, lsl #3]
    //     0xd1533c: blr             lr
    // 0xd15340: LoadField: d0 = r0->field_7
    //     0xd15340: ldur            d0, [x0, #7]
    // 0xd15344: d1 = 14.000000
    //     0xd15344: fmov            d1, #14.00000000
    // 0xd15348: fdiv            d2, d0, d1
    // 0xd1534c: ldur            x1, [fp, #-8]
    // 0xd15350: ldur            x2, [fp, #-0x10]
    // 0xd15354: stur            d2, [fp, #-0x90]
    // 0xd15358: r0 = _dialogSize()
    //     0xd15358: bl              #0xd15d5c  ; [package:flutter/src/material/date_picker.dart] _DatePickerDialogState::_dialogSize
    // 0xd1535c: mov             x1, x0
    // 0xd15360: ldur            d0, [fp, #-0x90]
    // 0xd15364: r0 = *()
    //     0xd15364: bl              #0x81d1f4  ; [dart:ui] Size::*
    // 0xd15368: mov             x3, x0
    // 0xd1536c: ldur            x2, [fp, #-0x18]
    // 0xd15370: stur            x3, [fp, #-0x30]
    // 0xd15374: StoreField: r2->field_2b = r0
    //     0xd15374: stur            w0, [x2, #0x2b]
    //     0xd15378: ldurb           w16, [x2, #-1]
    //     0xd1537c: ldurb           w17, [x0, #-1]
    //     0xd15380: and             x16, x17, x16, lsr #2
    //     0xd15384: tst             x16, HEAP, lsr #32
    //     0xd15388: b.eq            #0xd15390
    //     0xd1538c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd15390: ldur            x0, [fp, #-0x28]
    // 0xd15394: LoadField: r4 = r0->field_c7
    //     0xd15394: ldur            w4, [x0, #0xc7]
    // 0xd15398: DecompressPointer r4
    //     0xd15398: add             x4, x4, HEAP, lsl #32
    // 0xd1539c: ldur            x0, [fp, #-0x48]
    // 0xd153a0: stur            x4, [fp, #-0x10]
    // 0xd153a4: LoadField: r1 = r0->field_7
    //     0xd153a4: ldur            w1, [x0, #7]
    // 0xd153a8: DecompressPointer r1
    //     0xd153a8: add             x1, x1, HEAP, lsl #32
    // 0xd153ac: cmp             w1, NULL
    // 0xd153b0: b.ne            #0xd15448
    // 0xd153b4: ldur            x5, [fp, #-0x58]
    // 0xd153b8: r1 = LoadClassIdInstr(r5)
    //     0xd153b8: ldur            x1, [x5, #-1]
    //     0xd153bc: ubfx            x1, x1, #0xc, #0x14
    // 0xd153c0: r17 = 5167
    //     0xd153c0: mov             x17, #0x142f
    // 0xd153c4: cmp             x1, x17
    // 0xd153c8: b.ne            #0xd153d4
    // 0xd153cc: mov             x0, x5
    // 0xd153d0: b               #0xd15438
    // 0xd153d4: r17 = 5168
    //     0xd153d4: mov             x17, #0x1430
    // 0xd153d8: cmp             x1, x17
    // 0xd153dc: b.ne            #0xd15434
    // 0xd153e0: mov             x1, x5
    // 0xd153e4: LoadField: r0 = r1->field_b3
    //     0xd153e4: ldur            w0, [x1, #0xb3]
    // 0xd153e8: DecompressPointer r0
    //     0xd153e8: add             x0, x0, HEAP, lsl #32
    // 0xd153ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd153f0: cmp             w0, w16
    // 0xd153f4: b.ne            #0xd15404
    // 0xd153f8: r2 = _colors
    //     0xd153f8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xd153fc: ldr             x2, [x2, #0x400]
    // 0xd15400: r0 = InitLateFinalInstanceField()
    //     0xd15400: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd15404: LoadField: r1 = r0->field_9b
    //     0xd15404: ldur            w1, [x0, #0x9b]
    // 0xd15408: DecompressPointer r1
    //     0xd15408: add             x1, x1, HEAP, lsl #32
    // 0xd1540c: cmp             w1, NULL
    // 0xd15410: b.ne            #0xd15424
    // 0xd15414: LoadField: r1 = r0->field_7b
    //     0xd15414: ldur            w1, [x0, #0x7b]
    // 0xd15418: DecompressPointer r1
    //     0xd15418: add             x1, x1, HEAP, lsl #32
    // 0xd1541c: mov             x0, x1
    // 0xd15420: b               #0xd15428
    // 0xd15424: mov             x0, x1
    // 0xd15428: mov             x1, x0
    // 0xd1542c: ldur            x0, [fp, #-0x58]
    // 0xd15430: b               #0xd15440
    // 0xd15434: ldur            x0, [fp, #-0x58]
    // 0xd15438: LoadField: r1 = r0->field_7
    //     0xd15438: ldur            w1, [x0, #7]
    // 0xd1543c: DecompressPointer r1
    //     0xd1543c: add             x1, x1, HEAP, lsl #32
    // 0xd15440: mov             x3, x1
    // 0xd15444: b               #0xd15450
    // 0xd15448: ldur            x0, [fp, #-0x58]
    // 0xd1544c: mov             x3, x1
    // 0xd15450: ldur            x1, [fp, #-0x20]
    // 0xd15454: stur            x3, [fp, #-0x40]
    // 0xd15458: tbnz            w1, #4, #0xd15494
    // 0xd1545c: ldur            x2, [fp, #-0x48]
    // 0xd15460: LoadField: r4 = r2->field_b
    //     0xd15460: ldur            w4, [x2, #0xb]
    // 0xd15464: DecompressPointer r4
    //     0xd15464: add             x4, x4, HEAP, lsl #32
    // 0xd15468: cmp             w4, NULL
    // 0xd1546c: b.ne            #0xd15488
    // 0xd15470: LoadField: r4 = r0->field_b
    //     0xd15470: ldur            w4, [x0, #0xb]
    // 0xd15474: DecompressPointer r4
    //     0xd15474: add             x4, x4, HEAP, lsl #32
    // 0xd15478: cmp             w4, NULL
    // 0xd1547c: b.eq            #0xd157b4
    // 0xd15480: LoadField: d0 = r4->field_7
    //     0xd15480: ldur            d0, [x4, #7]
    // 0xd15484: b               #0xd1548c
    // 0xd15488: LoadField: d0 = r4->field_7
    //     0xd15488: ldur            d0, [x4, #7]
    // 0xd1548c: ldur            x5, [fp, #-0x10]
    // 0xd15490: b               #0xd154d0
    // 0xd15494: ldur            x2, [fp, #-0x48]
    // 0xd15498: LoadField: r4 = r2->field_b
    //     0xd15498: ldur            w4, [x2, #0xb]
    // 0xd1549c: DecompressPointer r4
    //     0xd1549c: add             x4, x4, HEAP, lsl #32
    // 0xd154a0: cmp             w4, NULL
    // 0xd154a4: b.ne            #0xd154b8
    // 0xd154a8: ldur            x5, [fp, #-0x10]
    // 0xd154ac: LoadField: r4 = r5->field_b
    //     0xd154ac: ldur            w4, [x5, #0xb]
    // 0xd154b0: DecompressPointer r4
    //     0xd154b0: add             x4, x4, HEAP, lsl #32
    // 0xd154b4: b               #0xd154bc
    // 0xd154b8: ldur            x5, [fp, #-0x10]
    // 0xd154bc: cmp             w4, NULL
    // 0xd154c0: b.ne            #0xd154cc
    // 0xd154c4: d0 = 24.000000
    //     0xd154c4: fmov            d0, #24.00000000
    // 0xd154c8: b               #0xd154d0
    // 0xd154cc: LoadField: d0 = r4->field_7
    //     0xd154cc: ldur            d0, [x4, #7]
    // 0xd154d0: stur            d0, [fp, #-0xa0]
    // 0xd154d4: r4 = LoadClassIdInstr(r0)
    //     0xd154d4: ldur            x4, [x0, #-1]
    //     0xd154d8: ubfx            x4, x4, #0xc, #0x14
    // 0xd154dc: r17 = 5167
    //     0xd154dc: mov             x17, #0x142f
    // 0xd154e0: cmp             x4, x17
    // 0xd154e4: b.eq            #0xd15500
    // 0xd154e8: r17 = 5168
    //     0xd154e8: mov             x17, #0x1430
    // 0xd154ec: cmp             x4, x17
    // 0xd154f0: b.ne            #0xd15500
    // 0xd154f4: r6 = Instance_Color
    //     0xd154f4: add             x6, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xd154f8: ldr             x6, [x6, #0x810]
    // 0xd154fc: b               #0xd15508
    // 0xd15500: LoadField: r6 = r0->field_f
    //     0xd15500: ldur            w6, [x0, #0xf]
    // 0xd15504: DecompressPointer r6
    //     0xd15504: add             x6, x6, HEAP, lsl #32
    // 0xd15508: stur            x6, [fp, #-0x38]
    // 0xd1550c: LoadField: r7 = r2->field_13
    //     0xd1550c: ldur            w7, [x2, #0x13]
    // 0xd15510: DecompressPointer r7
    //     0xd15510: add             x7, x7, HEAP, lsl #32
    // 0xd15514: cmp             w7, NULL
    // 0xd15518: b.ne            #0xd1554c
    // 0xd1551c: r17 = 5167
    //     0xd1551c: mov             x17, #0x142f
    // 0xd15520: cmp             x4, x17
    // 0xd15524: b.eq            #0xd15540
    // 0xd15528: r17 = 5168
    //     0xd15528: mov             x17, #0x1430
    // 0xd1552c: cmp             x4, x17
    // 0xd15530: b.ne            #0xd15540
    // 0xd15534: r4 = Instance_Color
    //     0xd15534: add             x4, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xd15538: ldr             x4, [x4, #0x810]
    // 0xd1553c: b               #0xd15550
    // 0xd15540: LoadField: r4 = r0->field_13
    //     0xd15540: ldur            w4, [x0, #0x13]
    // 0xd15544: DecompressPointer r4
    //     0xd15544: add             x4, x4, HEAP, lsl #32
    // 0xd15548: b               #0xd15550
    // 0xd1554c: mov             x4, x7
    // 0xd15550: stur            x4, [fp, #-0x28]
    // 0xd15554: tbnz            w1, #4, #0xd15584
    // 0xd15558: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd15558: ldur            w1, [x2, #0x17]
    // 0xd1555c: DecompressPointer r1
    //     0xd1555c: add             x1, x1, HEAP, lsl #32
    // 0xd15560: cmp             w1, NULL
    // 0xd15564: b.ne            #0xd15578
    // 0xd15568: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd15568: ldur            w1, [x0, #0x17]
    // 0xd1556c: DecompressPointer r1
    //     0xd1556c: add             x1, x1, HEAP, lsl #32
    // 0xd15570: mov             x0, x1
    // 0xd15574: b               #0xd1557c
    // 0xd15578: mov             x0, x1
    // 0xd1557c: mov             x5, x0
    // 0xd15580: b               #0xd155bc
    // 0xd15584: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd15584: ldur            w1, [x2, #0x17]
    // 0xd15588: DecompressPointer r1
    //     0xd15588: add             x1, x1, HEAP, lsl #32
    // 0xd1558c: cmp             w1, NULL
    // 0xd15590: b.ne            #0xd1559c
    // 0xd15594: ArrayLoad: r1 = r5[0]  ; List_4
    //     0xd15594: ldur            w1, [x5, #0x17]
    // 0xd15598: DecompressPointer r1
    //     0xd15598: add             x1, x1, HEAP, lsl #32
    // 0xd1559c: cmp             w1, NULL
    // 0xd155a0: b.ne            #0xd155b4
    // 0xd155a4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd155a4: ldur            w1, [x0, #0x17]
    // 0xd155a8: DecompressPointer r1
    //     0xd155a8: add             x1, x1, HEAP, lsl #32
    // 0xd155ac: mov             x0, x1
    // 0xd155b0: b               #0xd155b8
    // 0xd155b4: mov             x0, x1
    // 0xd155b8: mov             x5, x0
    // 0xd155bc: ldur            x1, [fp, #-8]
    // 0xd155c0: ldur            x0, [fp, #-0x30]
    // 0xd155c4: stur            x5, [fp, #-0x10]
    // 0xd155c8: LoadField: r2 = r1->field_b
    //     0xd155c8: ldur            w2, [x1, #0xb]
    // 0xd155cc: DecompressPointer r2
    //     0xd155cc: add             x2, x2, HEAP, lsl #32
    // 0xd155d0: cmp             w2, NULL
    // 0xd155d4: b.eq            #0xd157b8
    // 0xd155d8: LoadField: d1 = r0->field_7
    //     0xd155d8: ldur            d1, [x0, #7]
    // 0xd155dc: stur            d1, [fp, #-0x98]
    // 0xd155e0: LoadField: d2 = r0->field_f
    //     0xd155e0: ldur            d2, [x0, #0xf]
    // 0xd155e4: ldur            x2, [fp, #-0x18]
    // 0xd155e8: stur            d2, [fp, #-0x90]
    // 0xd155ec: r1 = Function '<anonymous closure>':.
    //     0xd155ec: add             x1, PP, #0x99, lsl #12  ; [pp+0x99c38] AnonymousClosure: (0xd17310), in [package:flutter/src/material/date_picker.dart] _DatePickerDialogState::build (0xd14660)
    //     0xd155f0: ldr             x1, [x1, #0xc38]
    // 0xd155f4: r0 = AllocateClosure()
    //     0xd155f4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd155f8: r1 = <BoxConstraints>
    //     0xd155f8: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c3f0] TypeArguments: <BoxConstraints>
    //     0xd155fc: ldr             x1, [x1, #0x3f0]
    // 0xd15600: stur            x0, [fp, #-8]
    // 0xd15604: r0 = LayoutBuilder()
    //     0xd15604: bl              #0xd15d50  ; AllocateLayoutBuilderStub -> LayoutBuilder (size=0x14)
    // 0xd15608: mov             x1, x0
    // 0xd1560c: ldur            x0, [fp, #-8]
    // 0xd15610: StoreField: r1->field_f = r0
    //     0xd15610: stur            w0, [x1, #0xf]
    // 0xd15614: r16 = 3.000000
    //     0xd15614: add             x16, PP, #0x22, lsl #12  ; [pp+0x223f8] 3
    //     0xd15618: ldr             x16, [x16, #0x3f8]
    // 0xd1561c: str             x16, [SP]
    // 0xd15620: r4 = const [0, 0x2, 0x1, 0x1, maxScaleFactor, 0x1, null]
    //     0xd15620: add             x4, PP, #0x90, lsl #12  ; [pp+0x90d70] List(7) [0, 0x2, 0x1, 0x1, "maxScaleFactor", 0x1, Null]
    //     0xd15624: ldr             x4, [x4, #0xd70]
    // 0xd15628: r0 = withClampedTextScaling()
    //     0xd15628: bl              #0xd16294  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::withClampedTextScaling
    // 0xd1562c: ldur            d0, [fp, #-0x98]
    // 0xd15630: stur            x0, [fp, #-0x20]
    // 0xd15634: r1 = inline_Allocate_Double()
    //     0xd15634: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xd15638: add             x1, x1, #0x10
    //     0xd1563c: cmp             x2, x1
    //     0xd15640: b.ls            #0xd157bc
    //     0xd15644: str             x1, [THR, #0x60]  ; THR::top
    //     0xd15648: sub             x1, x1, #0xf
    //     0xd1564c: mov             x2, #0xe19c
    //     0xd15650: movk            x2, #3, lsl #16
    //     0xd15654: stur            x2, [x1, #-1]
    // 0xd15658: dmb             ishst
    // 0xd1565c: StoreField: r1->field_7 = d0
    //     0xd1565c: stur            d0, [x1, #7]
    // 0xd15660: ldur            d0, [fp, #-0x90]
    // 0xd15664: stur            x1, [fp, #-0x18]
    // 0xd15668: r2 = inline_Allocate_Double()
    //     0xd15668: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xd1566c: add             x2, x2, #0x10
    //     0xd15670: cmp             x3, x2
    //     0xd15674: b.ls            #0xd157d8
    //     0xd15678: str             x2, [THR, #0x60]  ; THR::top
    //     0xd1567c: sub             x2, x2, #0xf
    //     0xd15680: mov             x3, #0xe19c
    //     0xd15684: movk            x3, #3, lsl #16
    //     0xd15688: stur            x3, [x2, #-1]
    // 0xd1568c: dmb             ishst
    // 0xd15690: StoreField: r2->field_7 = d0
    //     0xd15690: stur            d0, [x2, #7]
    // 0xd15694: stur            x2, [fp, #-8]
    // 0xd15698: r0 = AnimatedContainer()
    //     0xd15698: bl              #0xd15d44  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0xd1569c: stur            x0, [fp, #-0x30]
    // 0xd156a0: ldur            x16, [fp, #-0x18]
    // 0xd156a4: ldur            lr, [fp, #-8]
    // 0xd156a8: stp             lr, x16, [SP, #0x10]
    // 0xd156ac: r16 = Instance_Cubic
    //     0xd156ac: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e970] Obj!Cubic@129f541
    //     0xd156b0: ldr             x16, [x16, #0x970]
    // 0xd156b4: ldur            lr, [fp, #-0x20]
    // 0xd156b8: stp             lr, x16, [SP]
    // 0xd156bc: mov             x1, x0
    // 0xd156c0: r2 = Instance_Duration
    //     0xd156c0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xd156c4: ldr             x2, [x2, #0x318]
    // 0xd156c8: r4 = const [0, 0x6, 0x4, 0x2, child, 0x5, curve, 0x4, height, 0x3, width, 0x2, null]
    //     0xd156c8: add             x4, PP, #0x99, lsl #12  ; [pp+0x99c40] List(13) [0, 0x6, 0x4, 0x2, "child", 0x5, "curve", 0x4, "height", 0x3, "width", 0x2, Null]
    //     0xd156cc: ldr             x4, [x4, #0xc40]
    // 0xd156d0: r0 = AnimatedContainer()
    //     0xd156d0: bl              #0xd15840  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0xd156d4: r0 = Dialog()
    //     0xd156d4: bl              #0xd15834  ; AllocateDialogStub -> Dialog (size=0x44)
    // 0xd156d8: ldur            x1, [fp, #-0x40]
    // 0xd156dc: StoreField: r0->field_b = r1
    //     0xd156dc: stur            w1, [x0, #0xb]
    // 0xd156e0: ldur            d0, [fp, #-0xa0]
    // 0xd156e4: r1 = inline_Allocate_Double()
    //     0xd156e4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xd156e8: add             x1, x1, #0x10
    //     0xd156ec: cmp             x2, x1
    //     0xd156f0: b.ls            #0xd157f4
    //     0xd156f4: str             x1, [THR, #0x60]  ; THR::top
    //     0xd156f8: sub             x1, x1, #0xf
    //     0xd156fc: mov             x2, #0xe19c
    //     0xd15700: movk            x2, #3, lsl #16
    //     0xd15704: stur            x2, [x1, #-1]
    // 0xd15708: dmb             ishst
    // 0xd1570c: StoreField: r1->field_7 = d0
    //     0xd1570c: stur            d0, [x1, #7]
    // 0xd15710: StoreField: r0->field_f = r1
    //     0xd15710: stur            w1, [x0, #0xf]
    // 0xd15714: ldur            x1, [fp, #-0x38]
    // 0xd15718: StoreField: r0->field_13 = r1
    //     0xd15718: stur            w1, [x0, #0x13]
    // 0xd1571c: ldur            x1, [fp, #-0x28]
    // 0xd15720: ArrayStore: r0[0] = r1  ; List_4
    //     0xd15720: stur            w1, [x0, #0x17]
    // 0xd15724: r1 = Instance_Duration
    //     0xd15724: ldr             x1, [PP, #0x5668]  ; [pp+0x5668] Obj!Duration@12c8941
    // 0xd15728: StoreField: r0->field_1b = r1
    //     0xd15728: stur            w1, [x0, #0x1b]
    // 0xd1572c: r1 = Instance__DecelerateCurve
    //     0xd1572c: ldr             x1, [PP, #0x5150]  ; [pp+0x5150] Obj!_DecelerateCurve@129f3d1
    // 0xd15730: StoreField: r0->field_1f = r1
    //     0xd15730: stur            w1, [x0, #0x1f]
    // 0xd15734: r1 = Instance_EdgeInsets
    //     0xd15734: add             x1, PP, #0x28, lsl #12  ; [pp+0x28530] Obj!EdgeInsets@129cd81
    //     0xd15738: ldr             x1, [x1, #0x530]
    // 0xd1573c: StoreField: r0->field_23 = r1
    //     0xd1573c: stur            w1, [x0, #0x23]
    // 0xd15740: r1 = Instance_Clip
    //     0xd15740: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e6f0] Obj!Clip@12c8101
    //     0xd15744: ldr             x1, [x1, #0x6f0]
    // 0xd15748: StoreField: r0->field_27 = r1
    //     0xd15748: stur            w1, [x0, #0x27]
    // 0xd1574c: ldur            x1, [fp, #-0x10]
    // 0xd15750: StoreField: r0->field_2b = r1
    //     0xd15750: stur            w1, [x0, #0x2b]
    // 0xd15754: ldur            x1, [fp, #-0x30]
    // 0xd15758: StoreField: r0->field_33 = r1
    //     0xd15758: stur            w1, [x0, #0x33]
    // 0xd1575c: r1 = Instance_SemanticsRole
    //     0xd1575c: add             x1, PP, #0x7b, lsl #12  ; [pp+0x7b7b8] Obj!SemanticsRole@12c78c1
    //     0xd15760: ldr             x1, [x1, #0x7b8]
    // 0xd15764: StoreField: r0->field_3b = r1
    //     0xd15764: stur            w1, [x0, #0x3b]
    // 0xd15768: r1 = false
    //     0xd15768: add             x1, NULL, #0x30  ; false
    // 0xd1576c: StoreField: r0->field_37 = r1
    //     0xd1576c: stur            w1, [x0, #0x37]
    // 0xd15770: LeaveFrame
    //     0xd15770: mov             SP, fp
    //     0xd15774: ldp             fp, lr, [SP], #0x10
    // 0xd15778: ret
    //     0xd15778: ret             
    // 0xd1577c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1577c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd15780: b               #0xd14688
    // 0xd15784: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd15784: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd15788: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd15788: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd1578c: SaveReg d0
    //     0xd1578c: str             q0, [SP, #-0x10]!
    // 0xd15790: SaveReg r1
    //     0xd15790: str             x1, [SP, #-8]!
    // 0xd15794: r0 = AllocateDouble()
    //     0xd15794: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd15798: RestoreReg r1
    //     0xd15798: ldr             x1, [SP], #8
    // 0xd1579c: RestoreReg d0
    //     0xd1579c: ldr             q0, [SP], #0x10
    // 0xd157a0: b               #0xd14d80
    // 0xd157a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd157a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd157a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd157a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd157ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd157ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd157b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd157b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd157b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd157b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd157b8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd157b8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd157bc: SaveReg d0
    //     0xd157bc: str             q0, [SP, #-0x10]!
    // 0xd157c0: SaveReg r0
    //     0xd157c0: str             x0, [SP, #-8]!
    // 0xd157c4: r0 = AllocateDouble()
    //     0xd157c4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd157c8: mov             x1, x0
    // 0xd157cc: RestoreReg r0
    //     0xd157cc: ldr             x0, [SP], #8
    // 0xd157d0: RestoreReg d0
    //     0xd157d0: ldr             q0, [SP], #0x10
    // 0xd157d4: b               #0xd1565c
    // 0xd157d8: SaveReg d0
    //     0xd157d8: str             q0, [SP, #-0x10]!
    // 0xd157dc: stp             x0, x1, [SP, #-0x10]!
    // 0xd157e0: r0 = AllocateDouble()
    //     0xd157e0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd157e4: mov             x2, x0
    // 0xd157e8: ldp             x0, x1, [SP], #0x10
    // 0xd157ec: RestoreReg d0
    //     0xd157ec: ldr             q0, [SP], #0x10
    // 0xd157f0: b               #0xd15690
    // 0xd157f4: SaveReg d0
    //     0xd157f4: str             q0, [SP, #-0x10]!
    // 0xd157f8: SaveReg r0
    //     0xd157f8: str             x0, [SP, #-8]!
    // 0xd157fc: r0 = AllocateDouble()
    //     0xd157fc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd15800: mov             x1, x0
    // 0xd15804: RestoreReg r0
    //     0xd15804: ldr             x0, [SP], #8
    // 0xd15808: RestoreReg d0
    //     0xd15808: ldr             q0, [SP], #0x10
    // 0xd1580c: b               #0xd1570c
  }
  _ _dialogSize(/* No info */) {
    // ** addr: 0xd15d5c, size: 0x3e8
    // 0xd15d5c: EnterFrame
    //     0xd15d5c: stp             fp, lr, [SP, #-0x10]!
    //     0xd15d60: mov             fp, SP
    // 0xd15d64: AllocStack(0x18)
    //     0xd15d64: sub             SP, SP, #0x18
    // 0xd15d68: SetupParameters(_DatePickerDialogState this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xd15d68: mov             x0, x2
    //     0xd15d6c: stur            x2, [fp, #-0x10]
    //     0xd15d70: mov             x2, x1
    //     0xd15d74: stur            x1, [fp, #-8]
    // 0xd15d78: CheckStackOverflow
    //     0xd15d78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd15d7c: cmp             SP, x16
    //     0xd15d80: b.ls            #0xd1613c
    // 0xd15d84: mov             x1, x0
    // 0xd15d88: r0 = of()
    //     0xd15d88: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd15d8c: LoadField: r2 = r0->field_2f
    //     0xd15d8c: ldur            w2, [x0, #0x2f]
    // 0xd15d90: DecompressPointer r2
    //     0xd15d90: add             x2, x2, HEAP, lsl #32
    // 0xd15d94: ldur            x1, [fp, #-8]
    // 0xd15d98: stur            x2, [fp, #-0x18]
    // 0xd15d9c: LoadField: r0 = r1->field_27
    //     0xd15d9c: ldur            w0, [x1, #0x27]
    // 0xd15da0: DecompressPointer r0
    //     0xd15da0: add             x0, x0, HEAP, lsl #32
    // 0xd15da4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd15da8: cmp             w0, w16
    // 0xd15dac: b.ne            #0xd15dbc
    // 0xd15db0: r2 = _entryMode
    //     0xd15db0: add             x2, PP, #0x99, lsl #12  ; [pp+0x99ba8] Field <_DatePickerDialogState@75078594._entryMode@75078594>: late final (offset: 0x28)
    //     0xd15db4: ldr             x2, [x2, #0xba8]
    // 0xd15db8: r0 = InitLateFinalInstanceField()
    //     0xd15db8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd15dbc: LoadField: r3 = r0->field_33
    //     0xd15dbc: ldur            w3, [x0, #0x33]
    // 0xd15dc0: DecompressPointer r3
    //     0xd15dc0: add             x3, x3, HEAP, lsl #32
    // 0xd15dc4: stur            x3, [fp, #-8]
    // 0xd15dc8: cmp             w3, NULL
    // 0xd15dcc: b.ne            #0xd15e04
    // 0xd15dd0: LoadField: r2 = r0->field_23
    //     0xd15dd0: ldur            w2, [x0, #0x23]
    // 0xd15dd4: DecompressPointer r2
    //     0xd15dd4: add             x2, x2, HEAP, lsl #32
    // 0xd15dd8: mov             x0, x3
    // 0xd15ddc: r1 = Null
    //     0xd15ddc: mov             x1, NULL
    // 0xd15de0: cmp             w2, NULL
    // 0xd15de4: b.eq            #0xd15e04
    // 0xd15de8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd15de8: ldur            w4, [x2, #0x17]
    // 0xd15dec: DecompressPointer r4
    //     0xd15dec: add             x4, x4, HEAP, lsl #32
    // 0xd15df0: r8 = X0
    //     0xd15df0: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd15df4: LoadField: r9 = r4->field_7
    //     0xd15df4: ldur            x9, [x4, #7]
    // 0xd15df8: r3 = Null
    //     0xd15df8: add             x3, PP, #0x99, lsl #12  ; [pp+0x99d48] Null
    //     0xd15dfc: ldr             x3, [x3, #0xd48]
    // 0xd15e00: blr             x9
    // 0xd15e04: ldur            x0, [fp, #-8]
    // 0xd15e08: r16 = Instance_DatePickerEntryMode
    //     0xd15e08: add             x16, PP, #0x28, lsl #12  ; [pp+0x28520] Obj!DatePickerEntryMode@12c58c1
    //     0xd15e0c: ldr             x16, [x16, #0x520]
    // 0xd15e10: cmp             w0, w16
    // 0xd15e14: b.eq            #0xd15e28
    // 0xd15e18: r16 = Instance_DatePickerEntryMode
    //     0xd15e18: add             x16, PP, #0x99, lsl #12  ; [pp+0x99d58] Obj!DatePickerEntryMode@12c5861
    //     0xd15e1c: ldr             x16, [x16, #0xd58]
    // 0xd15e20: cmp             w0, w16
    // 0xd15e24: b.ne            #0xd15e30
    // 0xd15e28: r0 = true
    //     0xd15e28: add             x0, NULL, #0x20  ; true
    // 0xd15e2c: b               #0xd15e5c
    // 0xd15e30: r16 = Instance_DatePickerEntryMode
    //     0xd15e30: add             x16, PP, #0x99, lsl #12  ; [pp+0x99c80] Obj!DatePickerEntryMode@12c58a1
    //     0xd15e34: ldr             x16, [x16, #0xc80]
    // 0xd15e38: cmp             w0, w16
    // 0xd15e3c: b.eq            #0xd15e50
    // 0xd15e40: r16 = Instance_DatePickerEntryMode
    //     0xd15e40: add             x16, PP, #0x99, lsl #12  ; [pp+0x99c68] Obj!DatePickerEntryMode@12c5881
    //     0xd15e44: ldr             x16, [x16, #0xc68]
    // 0xd15e48: cmp             w0, w16
    // 0xd15e4c: b.ne            #0xd15e58
    // 0xd15e50: r0 = false
    //     0xd15e50: add             x0, NULL, #0x30  ; false
    // 0xd15e54: b               #0xd15e5c
    // 0xd15e58: r0 = Null
    //     0xd15e58: mov             x0, NULL
    // 0xd15e5c: ldur            x1, [fp, #-0x10]
    // 0xd15e60: stur            x0, [fp, #-8]
    // 0xd15e64: r0 = orientationOf()
    //     0xd15e64: bl              #0xd172a4  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::orientationOf
    // 0xd15e68: ldur            x1, [fp, #-8]
    // 0xd15e6c: tbnz            w1, #4, #0xd15ecc
    // 0xd15e70: r16 = Instance_Orientation
    //     0xd15e70: add             x16, PP, #0x14, lsl #12  ; [pp+0x143c8] Obj!Orientation@12c2ec1
    //     0xd15e74: ldr             x16, [x16, #0x3c8]
    // 0xd15e78: cmp             w0, w16
    // 0xd15e7c: r16 = true
    //     0xd15e7c: add             x16, NULL, #0x20  ; true
    // 0xd15e80: r17 = false
    //     0xd15e80: add             x17, NULL, #0x30  ; false
    // 0xd15e84: csel            x2, x16, x17, eq
    // 0xd15e88: tbnz            w2, #4, #0xd15eb4
    // 0xd15e8c: ldur            x3, [fp, #-0x18]
    // 0xd15e90: tbnz            w3, #4, #0xd15ea0
    // 0xd15e94: r0 = Instance_Size
    //     0xd15e94: add             x0, PP, #0x99, lsl #12  ; [pp+0x99d60] Obj!Size@12a7651
    //     0xd15e98: ldr             x0, [x0, #0xd60]
    // 0xd15e9c: b               #0xd16130
    // 0xd15ea0: mov             x6, x2
    // 0xd15ea4: mov             x4, x0
    // 0xd15ea8: r5 = true
    //     0xd15ea8: add             x5, NULL, #0x20  ; true
    // 0xd15eac: r2 = true
    //     0xd15eac: add             x2, NULL, #0x20  ; true
    // 0xd15eb0: b               #0xd15ee0
    // 0xd15eb4: ldur            x3, [fp, #-0x18]
    // 0xd15eb8: mov             x6, x2
    // 0xd15ebc: mov             x4, x0
    // 0xd15ec0: r5 = true
    //     0xd15ec0: add             x5, NULL, #0x20  ; true
    // 0xd15ec4: r2 = true
    //     0xd15ec4: add             x2, NULL, #0x20  ; true
    // 0xd15ec8: b               #0xd15ee0
    // 0xd15ecc: ldur            x3, [fp, #-0x18]
    // 0xd15ed0: r6 = Null
    //     0xd15ed0: mov             x6, NULL
    // 0xd15ed4: r5 = false
    //     0xd15ed4: add             x5, NULL, #0x30  ; false
    // 0xd15ed8: r4 = Null
    //     0xd15ed8: mov             x4, NULL
    // 0xd15edc: r2 = false
    //     0xd15edc: add             x2, NULL, #0x30  ; false
    // 0xd15ee0: tbnz            w1, #4, #0xd15eec
    // 0xd15ee4: r7 = false
    //     0xd15ee4: add             x7, NULL, #0x30  ; false
    // 0xd15ee8: b               #0xd15ef0
    // 0xd15eec: r7 = true
    //     0xd15eec: add             x7, NULL, #0x20  ; true
    // 0xd15ef0: tbnz            w7, #4, #0xd15f88
    // 0xd15ef4: tbnz            w5, #4, #0xd15f0c
    // 0xd15ef8: mov             x11, x6
    // 0xd15efc: mov             x10, x6
    // 0xd15f00: mov             x9, x2
    // 0xd15f04: mov             x8, x4
    // 0xd15f08: b               #0xd15f44
    // 0xd15f0c: tbnz            w2, #4, #0xd15f1c
    // 0xd15f10: mov             x9, x4
    // 0xd15f14: mov             x8, x4
    // 0xd15f18: b               #0xd15f24
    // 0xd15f1c: mov             x9, x0
    // 0xd15f20: mov             x8, x0
    // 0xd15f24: r16 = Instance_Orientation
    //     0xd15f24: add             x16, PP, #0x14, lsl #12  ; [pp+0x143c8] Obj!Orientation@12c2ec1
    //     0xd15f28: ldr             x16, [x16, #0x3c8]
    // 0xd15f2c: cmp             w9, w16
    // 0xd15f30: r16 = true
    //     0xd15f30: add             x16, NULL, #0x20  ; true
    // 0xd15f34: r17 = false
    //     0xd15f34: add             x17, NULL, #0x30  ; false
    // 0xd15f38: csel            x10, x16, x17, eq
    // 0xd15f3c: mov             x11, x10
    // 0xd15f40: r9 = true
    //     0xd15f40: add             x9, NULL, #0x20  ; true
    // 0xd15f44: r16 = true
    //     0xd15f44: add             x16, NULL, #0x20  ; true
    // 0xd15f48: cmp             w11, w16
    // 0xd15f4c: b.ne            #0xd15f74
    // 0xd15f50: tbnz            w3, #4, #0xd15f60
    // 0xd15f54: r0 = Instance_Size
    //     0xd15f54: add             x0, PP, #0x99, lsl #12  ; [pp+0x99c48] Obj!Size@12a7691
    //     0xd15f58: ldr             x0, [x0, #0xc48]
    // 0xd15f5c: b               #0xd16130
    // 0xd15f60: mov             x5, x10
    // 0xd15f64: mov             x3, x8
    // 0xd15f68: mov             x2, x9
    // 0xd15f6c: r4 = true
    //     0xd15f6c: add             x4, NULL, #0x20  ; true
    // 0xd15f70: b               #0xd15f94
    // 0xd15f74: mov             x5, x10
    // 0xd15f78: mov             x3, x8
    // 0xd15f7c: mov             x2, x9
    // 0xd15f80: r4 = true
    //     0xd15f80: add             x4, NULL, #0x20  ; true
    // 0xd15f84: b               #0xd15f94
    // 0xd15f88: mov             x3, x4
    // 0xd15f8c: mov             x4, x5
    // 0xd15f90: mov             x5, x6
    // 0xd15f94: tbnz            w1, #4, #0xd16010
    // 0xd15f98: tbnz            w4, #4, #0xd15fb0
    // 0xd15f9c: mov             x10, x5
    // 0xd15fa0: mov             x9, x5
    // 0xd15fa4: mov             x8, x2
    // 0xd15fa8: mov             x6, x3
    // 0xd15fac: b               #0xd15fe8
    // 0xd15fb0: tbnz            w2, #4, #0xd15fc0
    // 0xd15fb4: mov             x8, x3
    // 0xd15fb8: mov             x6, x3
    // 0xd15fbc: b               #0xd15fc8
    // 0xd15fc0: mov             x8, x0
    // 0xd15fc4: mov             x6, x0
    // 0xd15fc8: r16 = Instance_Orientation
    //     0xd15fc8: add             x16, PP, #0x14, lsl #12  ; [pp+0x143c8] Obj!Orientation@12c2ec1
    //     0xd15fcc: ldr             x16, [x16, #0x3c8]
    // 0xd15fd0: cmp             w8, w16
    // 0xd15fd4: r16 = true
    //     0xd15fd4: add             x16, NULL, #0x20  ; true
    // 0xd15fd8: r17 = false
    //     0xd15fd8: add             x17, NULL, #0x30  ; false
    // 0xd15fdc: csel            x9, x16, x17, eq
    // 0xd15fe0: mov             x10, x9
    // 0xd15fe4: r8 = true
    //     0xd15fe4: add             x8, NULL, #0x20  ; true
    // 0xd15fe8: r16 = true
    //     0xd15fe8: add             x16, NULL, #0x20  ; true
    // 0xd15fec: cmp             w10, w16
    // 0xd15ff0: b.ne            #0xd16000
    // 0xd15ff4: r0 = Instance_Size
    //     0xd15ff4: add             x0, PP, #0x99, lsl #12  ; [pp+0x99d68] Obj!Size@12a7631
    //     0xd15ff8: ldr             x0, [x0, #0xd68]
    // 0xd15ffc: b               #0xd16130
    // 0xd16000: mov             x5, x9
    // 0xd16004: mov             x3, x6
    // 0xd16008: mov             x2, x8
    // 0xd1600c: r4 = true
    //     0xd1600c: add             x4, NULL, #0x20  ; true
    // 0xd16010: tbnz            w7, #4, #0xd16080
    // 0xd16014: tbnz            w4, #4, #0xd16028
    // 0xd16018: mov             x6, x5
    // 0xd1601c: mov             x5, x3
    // 0xd16020: mov             x4, x2
    // 0xd16024: b               #0xd16060
    // 0xd16028: tbnz            w2, #4, #0xd16038
    // 0xd1602c: mov             x5, x3
    // 0xd16030: mov             x4, x3
    // 0xd16034: b               #0xd16040
    // 0xd16038: mov             x5, x0
    // 0xd1603c: mov             x4, x0
    // 0xd16040: r16 = Instance_Orientation
    //     0xd16040: add             x16, PP, #0x14, lsl #12  ; [pp+0x143c8] Obj!Orientation@12c2ec1
    //     0xd16044: ldr             x16, [x16, #0x3c8]
    // 0xd16048: cmp             w5, w16
    // 0xd1604c: r16 = true
    //     0xd1604c: add             x16, NULL, #0x20  ; true
    // 0xd16050: r17 = false
    //     0xd16050: add             x17, NULL, #0x30  ; false
    // 0xd16054: csel            x6, x16, x17, eq
    // 0xd16058: mov             x5, x4
    // 0xd1605c: r4 = true
    //     0xd1605c: add             x4, NULL, #0x20  ; true
    // 0xd16060: r16 = true
    //     0xd16060: add             x16, NULL, #0x20  ; true
    // 0xd16064: cmp             w6, w16
    // 0xd16068: b.ne            #0xd16078
    // 0xd1606c: r0 = Instance_Size
    //     0xd1606c: add             x0, PP, #0x99, lsl #12  ; [pp+0x99c50] Obj!Size@12a7671
    //     0xd16070: ldr             x0, [x0, #0xc50]
    // 0xd16074: b               #0xd16130
    // 0xd16078: mov             x3, x5
    // 0xd1607c: mov             x2, x4
    // 0xd16080: tbnz            w1, #4, #0xd160d8
    // 0xd16084: tbnz            w2, #4, #0xd16094
    // 0xd16088: mov             x4, x3
    // 0xd1608c: mov             x1, x3
    // 0xd16090: b               #0xd1609c
    // 0xd16094: mov             x4, x0
    // 0xd16098: mov             x1, x0
    // 0xd1609c: r16 = Instance_Orientation
    //     0xd1609c: add             x16, PP, #0x14, lsl #12  ; [pp+0x143c0] Obj!Orientation@12c2ee1
    //     0xd160a0: ldr             x16, [x16, #0x3c0]
    // 0xd160a4: cmp             w4, w16
    // 0xd160a8: r16 = true
    //     0xd160a8: add             x16, NULL, #0x20  ; true
    // 0xd160ac: r17 = false
    //     0xd160ac: add             x17, NULL, #0x30  ; false
    // 0xd160b0: csel            x5, x16, x17, eq
    // 0xd160b4: tbnz            w5, #4, #0xd160c4
    // 0xd160b8: r0 = Instance_Size
    //     0xd160b8: add             x0, PP, #0x99, lsl #12  ; [pp+0x99d70] Obj!Size@12a7611
    //     0xd160bc: ldr             x0, [x0, #0xd70]
    // 0xd160c0: b               #0xd16130
    // 0xd160c4: mov             x4, x1
    // 0xd160c8: mov             x2, x5
    // 0xd160cc: r3 = true
    //     0xd160cc: add             x3, NULL, #0x20  ; true
    // 0xd160d0: r1 = true
    //     0xd160d0: add             x1, NULL, #0x20  ; true
    // 0xd160d4: b               #0xd160e8
    // 0xd160d8: mov             x4, x3
    // 0xd160dc: mov             x3, x2
    // 0xd160e0: r2 = Null
    //     0xd160e0: mov             x2, NULL
    // 0xd160e4: r1 = false
    //     0xd160e4: add             x1, NULL, #0x30  ; false
    // 0xd160e8: tbnz            w7, #4, #0xd1612c
    // 0xd160ec: tbnz            w1, #4, #0xd16100
    // 0xd160f0: r16 = true
    //     0xd160f0: add             x16, NULL, #0x20  ; true
    // 0xd160f4: cmp             w2, w16
    // 0xd160f8: b.ne            #0xd1612c
    // 0xd160fc: b               #0xd16120
    // 0xd16100: tbnz            w3, #4, #0xd1610c
    // 0xd16104: mov             x1, x4
    // 0xd16108: b               #0xd16110
    // 0xd1610c: mov             x1, x0
    // 0xd16110: r16 = Instance_Orientation
    //     0xd16110: add             x16, PP, #0x14, lsl #12  ; [pp+0x143c0] Obj!Orientation@12c2ee1
    //     0xd16114: ldr             x16, [x16, #0x3c0]
    // 0xd16118: cmp             w1, w16
    // 0xd1611c: b.ne            #0xd1612c
    // 0xd16120: r0 = Instance_Size
    //     0xd16120: add             x0, PP, #0x99, lsl #12  ; [pp+0x99d78] Obj!Size@12a75f1
    //     0xd16124: ldr             x0, [x0, #0xd78]
    // 0xd16128: b               #0xd16130
    // 0xd1612c: r0 = Null
    //     0xd1612c: mov             x0, NULL
    // 0xd16130: LeaveFrame
    //     0xd16130: mov             SP, fp
    //     0xd16134: ldp             fp, lr, [SP], #0x10
    // 0xd16138: ret
    //     0xd16138: ret             
    // 0xd1613c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1613c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd16140: b               #0xd15d84
  }
  [closure] Flex <anonymous closure>(dynamic, BuildContext, BoxConstraints) {
    // ** addr: 0xd17310, size: 0x71c
    // 0xd17310: EnterFrame
    //     0xd17310: stp             fp, lr, [SP, #-0x10]!
    //     0xd17314: mov             fp, SP
    // 0xd17318: AllocStack(0x38)
    //     0xd17318: sub             SP, SP, #0x38
    // 0xd1731c: SetupParameters([dynamic _ /* r0 */])
    //     0xd1731c: ldr             x0, [fp, #0x20]
    //     0xd17320: ldur            w2, [x0, #0x17]
    //     0xd17324: add             x2, x2, HEAP, lsl #32
    //     0xd17328: stur            x2, [fp, #-0x18]
    // 0xd1732c: CheckStackOverflow
    //     0xd1732c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd17330: cmp             SP, x16
    //     0xd17334: b.ls            #0xd17a20
    // 0xd17338: LoadField: r0 = r2->field_13
    //     0xd17338: ldur            w0, [x2, #0x13]
    // 0xd1733c: DecompressPointer r0
    //     0xd1733c: add             x0, x0, HEAP, lsl #32
    // 0xd17340: stur            x0, [fp, #-0x10]
    // 0xd17344: tbnz            w0, #4, #0xd17354
    // 0xd17348: r3 = Instance_Size
    //     0xd17348: add             x3, PP, #0x99, lsl #12  ; [pp+0x99c48] Obj!Size@12a7691
    //     0xd1734c: ldr             x3, [x3, #0xc48]
    // 0xd17350: b               #0xd1735c
    // 0xd17354: r3 = Instance_Size
    //     0xd17354: add             x3, PP, #0x99, lsl #12  ; [pp+0x99c50] Obj!Size@12a7671
    //     0xd17358: ldr             x3, [x3, #0xc50]
    // 0xd1735c: ldr             x1, [fp, #0x10]
    // 0xd17360: LoadField: d0 = r1->field_1f
    //     0xd17360: ldur            d0, [x1, #0x1f]
    // 0xd17364: LoadField: r1 = r2->field_2b
    //     0xd17364: ldur            w1, [x2, #0x2b]
    // 0xd17368: DecompressPointer r1
    //     0xd17368: add             x1, x1, HEAP, lsl #32
    // 0xd1736c: LoadField: d1 = r1->field_f
    //     0xd1736c: ldur            d1, [x1, #0xf]
    // 0xd17370: LoadField: d2 = r3->field_f
    //     0xd17370: ldur            d2, [x3, #0xf]
    // 0xd17374: fmin            v3.2d, v1.2d, v2.2d
    // 0xd17378: fcmp            d0, d3
    // 0xd1737c: r16 = true
    //     0xd1737c: add             x16, NULL, #0x20  ; true
    // 0xd17380: r17 = false
    //     0xd17380: add             x17, NULL, #0x30  ; false
    // 0xd17384: csel            x3, x16, x17, ge
    // 0xd17388: stur            x3, [fp, #-8]
    // 0xd1738c: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd1738c: ldur            w1, [x2, #0x17]
    // 0xd17390: DecompressPointer r1
    //     0xd17390: add             x1, x1, HEAP, lsl #32
    // 0xd17394: LoadField: r4 = r1->field_7
    //     0xd17394: ldur            x4, [x1, #7]
    // 0xd17398: cmp             x4, #0
    // 0xd1739c: b.gt            #0xd17724
    // 0xd173a0: LoadField: r1 = r2->field_f
    //     0xd173a0: ldur            w1, [x2, #0xf]
    // 0xd173a4: DecompressPointer r1
    //     0xd173a4: add             x1, x1, HEAP, lsl #32
    // 0xd173a8: LoadField: r0 = r1->field_27
    //     0xd173a8: ldur            w0, [x1, #0x27]
    // 0xd173ac: DecompressPointer r0
    //     0xd173ac: add             x0, x0, HEAP, lsl #32
    // 0xd173b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd173b4: cmp             w0, w16
    // 0xd173b8: b.ne            #0xd173c8
    // 0xd173bc: r2 = _entryMode
    //     0xd173bc: add             x2, PP, #0x99, lsl #12  ; [pp+0x99ba8] Field <_DatePickerDialogState@75078594._entryMode@75078594>: late final (offset: 0x28)
    //     0xd173c0: ldr             x2, [x2, #0xba8]
    // 0xd173c4: r0 = InitLateFinalInstanceField()
    //     0xd173c4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd173c8: LoadField: r3 = r0->field_33
    //     0xd173c8: ldur            w3, [x0, #0x33]
    // 0xd173cc: DecompressPointer r3
    //     0xd173cc: add             x3, x3, HEAP, lsl #32
    // 0xd173d0: stur            x3, [fp, #-0x20]
    // 0xd173d4: cmp             w3, NULL
    // 0xd173d8: b.ne            #0xd17410
    // 0xd173dc: LoadField: r2 = r0->field_23
    //     0xd173dc: ldur            w2, [x0, #0x23]
    // 0xd173e0: DecompressPointer r2
    //     0xd173e0: add             x2, x2, HEAP, lsl #32
    // 0xd173e4: mov             x0, x3
    // 0xd173e8: r1 = Null
    //     0xd173e8: mov             x1, NULL
    // 0xd173ec: cmp             w2, NULL
    // 0xd173f0: b.eq            #0xd17410
    // 0xd173f4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd173f4: ldur            w4, [x2, #0x17]
    // 0xd173f8: DecompressPointer r4
    //     0xd173f8: add             x4, x4, HEAP, lsl #32
    // 0xd173fc: r8 = X0
    //     0xd173fc: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd17400: LoadField: r9 = r4->field_7
    //     0xd17400: ldur            x9, [x4, #7]
    // 0xd17404: r3 = Null
    //     0xd17404: add             x3, PP, #0x99, lsl #12  ; [pp+0x99c58] Null
    //     0xd17408: ldr             x3, [x3, #0xc58]
    // 0xd1740c: blr             x9
    // 0xd17410: ldur            x0, [fp, #-0x20]
    // 0xd17414: r16 = Instance_DatePickerEntryMode
    //     0xd17414: add             x16, PP, #0x99, lsl #12  ; [pp+0x99c68] Obj!DatePickerEntryMode@12c5881
    //     0xd17418: ldr             x16, [x16, #0xc68]
    // 0xd1741c: cmp             w0, w16
    // 0xd17420: b.ne            #0xd1742c
    // 0xd17424: r1 = true
    //     0xd17424: add             x1, NULL, #0x20  ; true
    // 0xd17428: b               #0xd174bc
    // 0xd1742c: ldur            x0, [fp, #-0x18]
    // 0xd17430: LoadField: r1 = r0->field_f
    //     0xd17430: ldur            w1, [x0, #0xf]
    // 0xd17434: DecompressPointer r1
    //     0xd17434: add             x1, x1, HEAP, lsl #32
    // 0xd17438: LoadField: r0 = r1->field_27
    //     0xd17438: ldur            w0, [x1, #0x27]
    // 0xd1743c: DecompressPointer r0
    //     0xd1743c: add             x0, x0, HEAP, lsl #32
    // 0xd17440: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd17444: cmp             w0, w16
    // 0xd17448: b.ne            #0xd17458
    // 0xd1744c: r2 = _entryMode
    //     0xd1744c: add             x2, PP, #0x99, lsl #12  ; [pp+0x99ba8] Field <_DatePickerDialogState@75078594._entryMode@75078594>: late final (offset: 0x28)
    //     0xd17450: ldr             x2, [x2, #0xba8]
    // 0xd17454: r0 = InitLateFinalInstanceField()
    //     0xd17454: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd17458: LoadField: r3 = r0->field_33
    //     0xd17458: ldur            w3, [x0, #0x33]
    // 0xd1745c: DecompressPointer r3
    //     0xd1745c: add             x3, x3, HEAP, lsl #32
    // 0xd17460: stur            x3, [fp, #-0x20]
    // 0xd17464: cmp             w3, NULL
    // 0xd17468: b.ne            #0xd174a0
    // 0xd1746c: LoadField: r2 = r0->field_23
    //     0xd1746c: ldur            w2, [x0, #0x23]
    // 0xd17470: DecompressPointer r2
    //     0xd17470: add             x2, x2, HEAP, lsl #32
    // 0xd17474: mov             x0, x3
    // 0xd17478: r1 = Null
    //     0xd17478: mov             x1, NULL
    // 0xd1747c: cmp             w2, NULL
    // 0xd17480: b.eq            #0xd174a0
    // 0xd17484: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd17484: ldur            w4, [x2, #0x17]
    // 0xd17488: DecompressPointer r4
    //     0xd17488: add             x4, x4, HEAP, lsl #32
    // 0xd1748c: r8 = X0
    //     0xd1748c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd17490: LoadField: r9 = r4->field_7
    //     0xd17490: ldur            x9, [x4, #7]
    // 0xd17494: r3 = Null
    //     0xd17494: add             x3, PP, #0x99, lsl #12  ; [pp+0x99c70] Null
    //     0xd17498: ldr             x3, [x3, #0xc70]
    // 0xd1749c: blr             x9
    // 0xd174a0: ldur            x0, [fp, #-0x20]
    // 0xd174a4: r16 = Instance_DatePickerEntryMode
    //     0xd174a4: add             x16, PP, #0x99, lsl #12  ; [pp+0x99c80] Obj!DatePickerEntryMode@12c58a1
    //     0xd174a8: ldr             x16, [x16, #0xc80]
    // 0xd174ac: cmp             w0, w16
    // 0xd174b0: r16 = true
    //     0xd174b0: add             x16, NULL, #0x20  ; true
    // 0xd174b4: r17 = false
    //     0xd174b4: add             x17, NULL, #0x30  ; false
    // 0xd174b8: csel            x1, x16, x17, eq
    // 0xd174bc: ldur            x0, [fp, #-8]
    // 0xd174c0: tbnz            w0, #4, #0xd174cc
    // 0xd174c4: r3 = true
    //     0xd174c4: add             x3, NULL, #0x20  ; true
    // 0xd174c8: b               #0xd174d4
    // 0xd174cc: eor             x2, x1, #0x10
    // 0xd174d0: mov             x3, x2
    // 0xd174d4: stur            x3, [fp, #-0x20]
    // 0xd174d8: tbnz            w0, #4, #0xd174e4
    // 0xd174dc: r0 = true
    //     0xd174dc: add             x0, NULL, #0x20  ; true
    // 0xd174e0: b               #0xd174e8
    // 0xd174e4: mov             x0, x1
    // 0xd174e8: stur            x0, [fp, #-8]
    // 0xd174ec: r1 = <Widget>
    //     0xd174ec: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd174f0: r2 = 0
    //     0xd174f0: mov             x2, #0
    // 0xd174f4: r0 = _GrowableList()
    //     0xd174f4: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd174f8: mov             x2, x0
    // 0xd174fc: ldur            x0, [fp, #-0x20]
    // 0xd17500: stur            x2, [fp, #-0x30]
    // 0xd17504: tbnz            w0, #4, #0xd1758c
    // 0xd17508: ldur            x0, [fp, #-0x18]
    // 0xd1750c: LoadField: r3 = r0->field_27
    //     0xd1750c: ldur            w3, [x0, #0x27]
    // 0xd17510: DecompressPointer r3
    //     0xd17510: add             x3, x3, HEAP, lsl #32
    // 0xd17514: stur            x3, [fp, #-0x20]
    // 0xd17518: LoadField: r1 = r2->field_b
    //     0xd17518: ldur            w1, [x2, #0xb]
    // 0xd1751c: LoadField: r4 = r2->field_f
    //     0xd1751c: ldur            w4, [x2, #0xf]
    // 0xd17520: DecompressPointer r4
    //     0xd17520: add             x4, x4, HEAP, lsl #32
    // 0xd17524: LoadField: r5 = r4->field_b
    //     0xd17524: ldur            w5, [x4, #0xb]
    // 0xd17528: r4 = LoadInt32Instr(r1)
    //     0xd17528: sbfx            x4, x1, #1, #0x1f
    // 0xd1752c: stur            x4, [fp, #-0x28]
    // 0xd17530: r1 = LoadInt32Instr(r5)
    //     0xd17530: sbfx            x1, x5, #1, #0x1f
    // 0xd17534: cmp             x4, x1
    // 0xd17538: b.ne            #0xd17544
    // 0xd1753c: mov             x1, x2
    // 0xd17540: r0 = _growToNextCapacity()
    //     0xd17540: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd17544: ldur            x2, [fp, #-0x30]
    // 0xd17548: ldur            x3, [fp, #-0x28]
    // 0xd1754c: add             x0, x3, #1
    // 0xd17550: lsl             x1, x0, #1
    // 0xd17554: StoreField: r2->field_b = r1
    //     0xd17554: stur            w1, [x2, #0xb]
    // 0xd17558: LoadField: r1 = r2->field_f
    //     0xd17558: ldur            w1, [x2, #0xf]
    // 0xd1755c: DecompressPointer r1
    //     0xd1755c: add             x1, x1, HEAP, lsl #32
    // 0xd17560: ldur            x0, [fp, #-0x20]
    // 0xd17564: ArrayStore: r1[r3] = r0  ; List_4
    //     0xd17564: add             x25, x1, x3, lsl #2
    //     0xd17568: add             x25, x25, #0xf
    //     0xd1756c: str             w0, [x25]
    //     0xd17570: tbz             w0, #0, #0xd1758c
    //     0xd17574: ldurb           w16, [x1, #-1]
    //     0xd17578: ldurb           w17, [x0, #-1]
    //     0xd1757c: and             x16, x17, x16, lsr #2
    //     0xd17580: tst             x16, HEAP, lsr #32
    //     0xd17584: b.eq            #0xd1758c
    //     0xd17588: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd1758c: ldur            x0, [fp, #-0x10]
    // 0xd17590: tbnz            w0, #4, #0xd17620
    // 0xd17594: r0 = Divider()
    //     0xd17594: bl              #0xd17a38  ; AllocateDividerStub -> Divider (size=0x24)
    // 0xd17598: mov             x2, x0
    // 0xd1759c: r0 = 0.000000
    //     0xd1759c: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd175a0: stur            x2, [fp, #-0x20]
    // 0xd175a4: StoreField: r2->field_b = r0
    //     0xd175a4: stur            w0, [x2, #0xb]
    // 0xd175a8: ldur            x0, [fp, #-0x30]
    // 0xd175ac: LoadField: r1 = r0->field_b
    //     0xd175ac: ldur            w1, [x0, #0xb]
    // 0xd175b0: LoadField: r3 = r0->field_f
    //     0xd175b0: ldur            w3, [x0, #0xf]
    // 0xd175b4: DecompressPointer r3
    //     0xd175b4: add             x3, x3, HEAP, lsl #32
    // 0xd175b8: LoadField: r4 = r3->field_b
    //     0xd175b8: ldur            w4, [x3, #0xb]
    // 0xd175bc: r3 = LoadInt32Instr(r1)
    //     0xd175bc: sbfx            x3, x1, #1, #0x1f
    // 0xd175c0: stur            x3, [fp, #-0x28]
    // 0xd175c4: r1 = LoadInt32Instr(r4)
    //     0xd175c4: sbfx            x1, x4, #1, #0x1f
    // 0xd175c8: cmp             x3, x1
    // 0xd175cc: b.ne            #0xd175d8
    // 0xd175d0: mov             x1, x0
    // 0xd175d4: r0 = _growToNextCapacity()
    //     0xd175d4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd175d8: ldur            x2, [fp, #-0x30]
    // 0xd175dc: ldur            x3, [fp, #-0x28]
    // 0xd175e0: add             x0, x3, #1
    // 0xd175e4: lsl             x1, x0, #1
    // 0xd175e8: StoreField: r2->field_b = r1
    //     0xd175e8: stur            w1, [x2, #0xb]
    // 0xd175ec: LoadField: r1 = r2->field_f
    //     0xd175ec: ldur            w1, [x2, #0xf]
    // 0xd175f0: DecompressPointer r1
    //     0xd175f0: add             x1, x1, HEAP, lsl #32
    // 0xd175f4: ldur            x0, [fp, #-0x20]
    // 0xd175f8: ArrayStore: r1[r3] = r0  ; List_4
    //     0xd175f8: add             x25, x1, x3, lsl #2
    //     0xd175fc: add             x25, x25, #0xf
    //     0xd17600: str             w0, [x25]
    //     0xd17604: tbz             w0, #0, #0xd17620
    //     0xd17608: ldurb           w16, [x1, #-1]
    //     0xd1760c: ldurb           w17, [x0, #-1]
    //     0xd17610: and             x16, x17, x16, lsr #2
    //     0xd17614: tst             x16, HEAP, lsr #32
    //     0xd17618: b.eq            #0xd17620
    //     0xd1761c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd17620: ldur            x0, [fp, #-8]
    // 0xd17624: tbnz            w0, #4, #0xd176c0
    // 0xd17628: ldur            x0, [fp, #-0x18]
    // 0xd1762c: LoadField: r3 = r0->field_23
    //     0xd1762c: ldur            w3, [x0, #0x23]
    // 0xd17630: DecompressPointer r3
    //     0xd17630: add             x3, x3, HEAP, lsl #32
    // 0xd17634: stur            x3, [fp, #-8]
    // 0xd17638: r1 = <FlexParentData>
    //     0xd17638: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xd1763c: ldr             x1, [x1, #0x878]
    // 0xd17640: r0 = Expanded()
    //     0xd17640: bl              #0x8a5b10  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0xd17644: r3 = 1
    //     0xd17644: mov             x3, #1
    // 0xd17648: stur            x0, [fp, #-0x20]
    // 0xd1764c: StoreField: r0->field_13 = r3
    //     0xd1764c: stur            x3, [x0, #0x13]
    // 0xd17650: r4 = Instance_FlexFit
    //     0xd17650: add             x4, PP, #0x15, lsl #12  ; [pp+0x15880] Obj!FlexFit@12c4641
    //     0xd17654: ldr             x4, [x4, #0x880]
    // 0xd17658: StoreField: r0->field_1b = r4
    //     0xd17658: stur            w4, [x0, #0x1b]
    // 0xd1765c: ldur            x1, [fp, #-8]
    // 0xd17660: StoreField: r0->field_b = r1
    //     0xd17660: stur            w1, [x0, #0xb]
    // 0xd17664: ldur            x5, [fp, #-0x18]
    // 0xd17668: LoadField: r3 = r5->field_1f
    //     0xd17668: ldur            w3, [x5, #0x1f]
    // 0xd1766c: DecompressPointer r3
    //     0xd1766c: add             x3, x3, HEAP, lsl #32
    // 0xd17670: stur            x3, [fp, #-8]
    // 0xd17674: r1 = Null
    //     0xd17674: mov             x1, NULL
    // 0xd17678: r2 = 4
    //     0xd17678: mov             x2, #4
    // 0xd1767c: r0 = AllocateArray()
    //     0xd1767c: bl              #0x13df928  ; AllocateArrayStub
    // 0xd17680: mov             x2, x0
    // 0xd17684: ldur            x0, [fp, #-0x20]
    // 0xd17688: stur            x2, [fp, #-0x38]
    // 0xd1768c: StoreField: r2->field_f = r0
    //     0xd1768c: stur            w0, [x2, #0xf]
    // 0xd17690: ldur            x0, [fp, #-8]
    // 0xd17694: StoreField: r2->field_13 = r0
    //     0xd17694: stur            w0, [x2, #0x13]
    // 0xd17698: r1 = <Widget>
    //     0xd17698: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd1769c: r0 = AllocateGrowableArray()
    //     0xd1769c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd176a0: mov             x1, x0
    // 0xd176a4: ldur            x0, [fp, #-0x38]
    // 0xd176a8: StoreField: r1->field_f = r0
    //     0xd176a8: stur            w0, [x1, #0xf]
    // 0xd176ac: r6 = 4
    //     0xd176ac: mov             x6, #4
    // 0xd176b0: StoreField: r1->field_b = r6
    //     0xd176b0: stur            w6, [x1, #0xb]
    // 0xd176b4: mov             x2, x1
    // 0xd176b8: ldur            x1, [fp, #-0x30]
    // 0xd176bc: r0 = addAll()
    //     0xd176bc: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0xd176c0: ldur            x0, [fp, #-0x30]
    // 0xd176c4: r0 = Column()
    //     0xd176c4: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xd176c8: r7 = Instance_Axis
    //     0xd176c8: ldr             x7, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xd176cc: StoreField: r0->field_f = r7
    //     0xd176cc: stur            w7, [x0, #0xf]
    // 0xd176d0: r8 = Instance_MainAxisAlignment
    //     0xd176d0: add             x8, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xd176d4: ldr             x8, [x8, #0x820]
    // 0xd176d8: StoreField: r0->field_13 = r8
    //     0xd176d8: stur            w8, [x0, #0x13]
    // 0xd176dc: r9 = Instance_MainAxisSize
    //     0xd176dc: add             x9, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xd176e0: ldr             x9, [x9, #0x200]
    // 0xd176e4: ArrayStore: r0[0] = r9  ; List_4
    //     0xd176e4: stur            w9, [x0, #0x17]
    // 0xd176e8: r10 = Instance_CrossAxisAlignment
    //     0xd176e8: add             x10, PP, #0x7b, lsl #12  ; [pp+0x7bc40] Obj!CrossAxisAlignment@12c4521
    //     0xd176ec: ldr             x10, [x10, #0xc40]
    // 0xd176f0: StoreField: r0->field_1b = r10
    //     0xd176f0: stur            w10, [x0, #0x1b]
    // 0xd176f4: r11 = Instance_VerticalDirection
    //     0xd176f4: add             x11, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xd176f8: ldr             x11, [x11, #0x838]
    // 0xd176fc: StoreField: r0->field_23 = r11
    //     0xd176fc: stur            w11, [x0, #0x23]
    // 0xd17700: r12 = Instance_Clip
    //     0xd17700: add             x12, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xd17704: ldr             x12, [x12, #0x840]
    // 0xd17708: StoreField: r0->field_2b = r12
    //     0xd17708: stur            w12, [x0, #0x2b]
    // 0xd1770c: StoreField: r0->field_2f = rZR
    //     0xd1770c: stur            xzr, [x0, #0x2f]
    // 0xd17710: ldur            x1, [fp, #-0x30]
    // 0xd17714: StoreField: r0->field_b = r1
    //     0xd17714: stur            w1, [x0, #0xb]
    // 0xd17718: LeaveFrame
    //     0xd17718: mov             SP, fp
    //     0xd1771c: ldp             fp, lr, [SP], #0x10
    // 0xd17720: ret
    //     0xd17720: ret             
    // 0xd17724: mov             x5, x2
    // 0xd17728: r9 = Instance_MainAxisSize
    //     0xd17728: add             x9, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xd1772c: ldr             x9, [x9, #0x200]
    // 0xd17730: r10 = Instance_CrossAxisAlignment
    //     0xd17730: add             x10, PP, #0x7b, lsl #12  ; [pp+0x7bc40] Obj!CrossAxisAlignment@12c4521
    //     0xd17734: ldr             x10, [x10, #0xc40]
    // 0xd17738: r13 = 2
    //     0xd17738: mov             x13, #2
    // 0xd1773c: r4 = Instance_FlexFit
    //     0xd1773c: add             x4, PP, #0x15, lsl #12  ; [pp+0x15880] Obj!FlexFit@12c4641
    //     0xd17740: ldr             x4, [x4, #0x880]
    // 0xd17744: r6 = 4
    //     0xd17744: mov             x6, #4
    // 0xd17748: r8 = Instance_MainAxisAlignment
    //     0xd17748: add             x8, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xd1774c: ldr             x8, [x8, #0x820]
    // 0xd17750: r11 = Instance_VerticalDirection
    //     0xd17750: add             x11, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xd17754: ldr             x11, [x11, #0x838]
    // 0xd17758: r7 = Instance_Axis
    //     0xd17758: ldr             x7, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xd1775c: r12 = Instance_Clip
    //     0xd1775c: add             x12, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xd17760: ldr             x12, [x12, #0x840]
    // 0xd17764: r3 = 1
    //     0xd17764: mov             x3, #1
    // 0xd17768: LoadField: r14 = r5->field_27
    //     0xd17768: ldur            w14, [x5, #0x27]
    // 0xd1776c: DecompressPointer r14
    //     0xd1776c: add             x14, x14, HEAP, lsl #32
    // 0xd17770: mov             x2, x13
    // 0xd17774: stur            x14, [fp, #-8]
    // 0xd17778: r1 = Null
    //     0xd17778: mov             x1, NULL
    // 0xd1777c: r0 = AllocateArray()
    //     0xd1777c: bl              #0x13df928  ; AllocateArrayStub
    // 0xd17780: mov             x2, x0
    // 0xd17784: ldur            x0, [fp, #-8]
    // 0xd17788: stur            x2, [fp, #-0x20]
    // 0xd1778c: StoreField: r2->field_f = r0
    //     0xd1778c: stur            w0, [x2, #0xf]
    // 0xd17790: r1 = <Widget>
    //     0xd17790: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd17794: r0 = AllocateGrowableArray()
    //     0xd17794: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd17798: mov             x1, x0
    // 0xd1779c: ldur            x0, [fp, #-0x20]
    // 0xd177a0: stur            x1, [fp, #-8]
    // 0xd177a4: StoreField: r1->field_f = r0
    //     0xd177a4: stur            w0, [x1, #0xf]
    // 0xd177a8: r2 = 2
    //     0xd177a8: mov             x2, #2
    // 0xd177ac: StoreField: r1->field_b = r2
    //     0xd177ac: stur            w2, [x1, #0xb]
    // 0xd177b0: ldur            x2, [fp, #-0x10]
    // 0xd177b4: tbnz            w2, #4, #0xd17814
    // 0xd177b8: r0 = VerticalDivider()
    //     0xd177b8: bl              #0xd17a2c  ; AllocateVerticalDividerStub -> VerticalDivider (size=0x28)
    // 0xd177bc: stur            x0, [fp, #-0x10]
    // 0xd177c0: StoreField: r0->field_b = rZR
    //     0xd177c0: stur            xzr, [x0, #0xb]
    // 0xd177c4: ldur            x1, [fp, #-8]
    // 0xd177c8: r0 = _growToNextCapacity()
    //     0xd177c8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd177cc: ldur            x2, [fp, #-8]
    // 0xd177d0: r3 = 4
    //     0xd177d0: mov             x3, #4
    // 0xd177d4: StoreField: r2->field_b = r3
    //     0xd177d4: stur            w3, [x2, #0xb]
    // 0xd177d8: LoadField: r4 = r2->field_f
    //     0xd177d8: ldur            w4, [x2, #0xf]
    // 0xd177dc: DecompressPointer r4
    //     0xd177dc: add             x4, x4, HEAP, lsl #32
    // 0xd177e0: mov             x1, x4
    // 0xd177e4: ldur            x0, [fp, #-0x10]
    // 0xd177e8: ArrayStore: r1[1] = r0  ; List_4
    //     0xd177e8: add             x25, x1, #0x13
    //     0xd177ec: str             w0, [x25]
    //     0xd177f0: tbz             w0, #0, #0xd1780c
    //     0xd177f4: ldurb           w16, [x1, #-1]
    //     0xd177f8: ldurb           w17, [x0, #-1]
    //     0xd177fc: and             x16, x17, x16, lsr #2
    //     0xd17800: tst             x16, HEAP, lsr #32
    //     0xd17804: b.eq            #0xd1780c
    //     0xd17808: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd1780c: r5 = 2
    //     0xd1780c: mov             x5, #2
    // 0xd17810: b               #0xd17824
    // 0xd17814: mov             x2, x1
    // 0xd17818: r3 = 4
    //     0xd17818: mov             x3, #4
    // 0xd1781c: mov             x4, x0
    // 0xd17820: r5 = 1
    //     0xd17820: mov             x5, #1
    // 0xd17824: ldur            x0, [fp, #-0x18]
    // 0xd17828: stur            x5, [fp, #-0x28]
    // 0xd1782c: stur            x4, [fp, #-0x20]
    // 0xd17830: LoadField: r6 = r0->field_23
    //     0xd17830: ldur            w6, [x0, #0x23]
    // 0xd17834: DecompressPointer r6
    //     0xd17834: add             x6, x6, HEAP, lsl #32
    // 0xd17838: stur            x6, [fp, #-0x10]
    // 0xd1783c: r1 = <FlexParentData>
    //     0xd1783c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xd17840: ldr             x1, [x1, #0x878]
    // 0xd17844: r0 = Expanded()
    //     0xd17844: bl              #0x8a5b10  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0xd17848: mov             x3, x0
    // 0xd1784c: r0 = 1
    //     0xd1784c: mov             x0, #1
    // 0xd17850: stur            x3, [fp, #-0x30]
    // 0xd17854: StoreField: r3->field_13 = r0
    //     0xd17854: stur            x0, [x3, #0x13]
    // 0xd17858: r1 = Instance_FlexFit
    //     0xd17858: add             x1, PP, #0x15, lsl #12  ; [pp+0x15880] Obj!FlexFit@12c4641
    //     0xd1785c: ldr             x1, [x1, #0x880]
    // 0xd17860: StoreField: r3->field_1b = r1
    //     0xd17860: stur            w1, [x3, #0x1b]
    // 0xd17864: ldur            x1, [fp, #-0x10]
    // 0xd17868: StoreField: r3->field_b = r1
    //     0xd17868: stur            w1, [x3, #0xb]
    // 0xd1786c: ldur            x1, [fp, #-0x18]
    // 0xd17870: LoadField: r4 = r1->field_1f
    //     0xd17870: ldur            w4, [x1, #0x1f]
    // 0xd17874: DecompressPointer r4
    //     0xd17874: add             x4, x4, HEAP, lsl #32
    // 0xd17878: stur            x4, [fp, #-0x10]
    // 0xd1787c: r1 = Null
    //     0xd1787c: mov             x1, NULL
    // 0xd17880: r2 = 4
    //     0xd17880: mov             x2, #4
    // 0xd17884: r0 = AllocateArray()
    //     0xd17884: bl              #0x13df928  ; AllocateArrayStub
    // 0xd17888: mov             x2, x0
    // 0xd1788c: ldur            x0, [fp, #-0x30]
    // 0xd17890: stur            x2, [fp, #-0x18]
    // 0xd17894: StoreField: r2->field_f = r0
    //     0xd17894: stur            w0, [x2, #0xf]
    // 0xd17898: ldur            x0, [fp, #-0x10]
    // 0xd1789c: StoreField: r2->field_13 = r0
    //     0xd1789c: stur            w0, [x2, #0x13]
    // 0xd178a0: r1 = <Widget>
    //     0xd178a0: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd178a4: r0 = AllocateGrowableArray()
    //     0xd178a4: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd178a8: mov             x1, x0
    // 0xd178ac: ldur            x0, [fp, #-0x18]
    // 0xd178b0: stur            x1, [fp, #-0x10]
    // 0xd178b4: StoreField: r1->field_f = r0
    //     0xd178b4: stur            w0, [x1, #0xf]
    // 0xd178b8: r0 = 4
    //     0xd178b8: mov             x0, #4
    // 0xd178bc: StoreField: r1->field_b = r0
    //     0xd178bc: stur            w0, [x1, #0xb]
    // 0xd178c0: r0 = Column()
    //     0xd178c0: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xd178c4: mov             x2, x0
    // 0xd178c8: r0 = Instance_Axis
    //     0xd178c8: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xd178cc: stur            x2, [fp, #-0x18]
    // 0xd178d0: StoreField: r2->field_f = r0
    //     0xd178d0: stur            w0, [x2, #0xf]
    // 0xd178d4: r0 = Instance_MainAxisAlignment
    //     0xd178d4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xd178d8: ldr             x0, [x0, #0x820]
    // 0xd178dc: StoreField: r2->field_13 = r0
    //     0xd178dc: stur            w0, [x2, #0x13]
    // 0xd178e0: r3 = Instance_MainAxisSize
    //     0xd178e0: add             x3, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xd178e4: ldr             x3, [x3, #0x200]
    // 0xd178e8: ArrayStore: r2[0] = r3  ; List_4
    //     0xd178e8: stur            w3, [x2, #0x17]
    // 0xd178ec: r4 = Instance_CrossAxisAlignment
    //     0xd178ec: add             x4, PP, #0x7b, lsl #12  ; [pp+0x7bc40] Obj!CrossAxisAlignment@12c4521
    //     0xd178f0: ldr             x4, [x4, #0xc40]
    // 0xd178f4: StoreField: r2->field_1b = r4
    //     0xd178f4: stur            w4, [x2, #0x1b]
    // 0xd178f8: r5 = Instance_VerticalDirection
    //     0xd178f8: add             x5, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xd178fc: ldr             x5, [x5, #0x838]
    // 0xd17900: StoreField: r2->field_23 = r5
    //     0xd17900: stur            w5, [x2, #0x23]
    // 0xd17904: r6 = Instance_Clip
    //     0xd17904: add             x6, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xd17908: ldr             x6, [x6, #0x840]
    // 0xd1790c: StoreField: r2->field_2b = r6
    //     0xd1790c: stur            w6, [x2, #0x2b]
    // 0xd17910: StoreField: r2->field_2f = rZR
    //     0xd17910: stur            xzr, [x2, #0x2f]
    // 0xd17914: ldur            x1, [fp, #-0x10]
    // 0xd17918: StoreField: r2->field_b = r1
    //     0xd17918: stur            w1, [x2, #0xb]
    // 0xd1791c: r1 = <FlexParentData>
    //     0xd1791c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xd17920: ldr             x1, [x1, #0x878]
    // 0xd17924: r0 = Flexible()
    //     0xd17924: bl              #0xd0fd68  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0xd17928: mov             x2, x0
    // 0xd1792c: r0 = 1
    //     0xd1792c: mov             x0, #1
    // 0xd17930: stur            x2, [fp, #-0x10]
    // 0xd17934: StoreField: r2->field_13 = r0
    //     0xd17934: stur            x0, [x2, #0x13]
    // 0xd17938: r0 = Instance_FlexFit
    //     0xd17938: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ac30] Obj!FlexFit@12c4661
    //     0xd1793c: ldr             x0, [x0, #0xc30]
    // 0xd17940: StoreField: r2->field_1b = r0
    //     0xd17940: stur            w0, [x2, #0x1b]
    // 0xd17944: ldur            x0, [fp, #-0x18]
    // 0xd17948: StoreField: r2->field_b = r0
    //     0xd17948: stur            w0, [x2, #0xb]
    // 0xd1794c: ldur            x0, [fp, #-0x20]
    // 0xd17950: LoadField: r1 = r0->field_b
    //     0xd17950: ldur            w1, [x0, #0xb]
    // 0xd17954: r0 = LoadInt32Instr(r1)
    //     0xd17954: sbfx            x0, x1, #1, #0x1f
    // 0xd17958: ldur            x3, [fp, #-0x28]
    // 0xd1795c: cmp             x3, x0
    // 0xd17960: b.ne            #0xd1796c
    // 0xd17964: ldur            x1, [fp, #-8]
    // 0xd17968: r0 = _growToNextCapacity()
    //     0xd17968: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd1796c: ldur            x3, [fp, #-8]
    // 0xd17970: ldur            x2, [fp, #-0x28]
    // 0xd17974: add             x0, x2, #1
    // 0xd17978: lsl             x1, x0, #1
    // 0xd1797c: StoreField: r3->field_b = r1
    //     0xd1797c: stur            w1, [x3, #0xb]
    // 0xd17980: mov             x1, x2
    // 0xd17984: cmp             x1, x0
    // 0xd17988: b.hs            #0xd17a28
    // 0xd1798c: LoadField: r1 = r3->field_f
    //     0xd1798c: ldur            w1, [x3, #0xf]
    // 0xd17990: DecompressPointer r1
    //     0xd17990: add             x1, x1, HEAP, lsl #32
    // 0xd17994: ldur            x0, [fp, #-0x10]
    // 0xd17998: ArrayStore: r1[r2] = r0  ; List_4
    //     0xd17998: add             x25, x1, x2, lsl #2
    //     0xd1799c: add             x25, x25, #0xf
    //     0xd179a0: str             w0, [x25]
    //     0xd179a4: tbz             w0, #0, #0xd179c0
    //     0xd179a8: ldurb           w16, [x1, #-1]
    //     0xd179ac: ldurb           w17, [x0, #-1]
    //     0xd179b0: and             x16, x17, x16, lsr #2
    //     0xd179b4: tst             x16, HEAP, lsr #32
    //     0xd179b8: b.eq            #0xd179c0
    //     0xd179bc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd179c0: r0 = Row()
    //     0xd179c0: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xd179c4: r1 = Instance_Axis
    //     0xd179c4: ldr             x1, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xd179c8: StoreField: r0->field_f = r1
    //     0xd179c8: stur            w1, [x0, #0xf]
    // 0xd179cc: r1 = Instance_MainAxisAlignment
    //     0xd179cc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xd179d0: ldr             x1, [x1, #0x820]
    // 0xd179d4: StoreField: r0->field_13 = r1
    //     0xd179d4: stur            w1, [x0, #0x13]
    // 0xd179d8: r1 = Instance_MainAxisSize
    //     0xd179d8: add             x1, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xd179dc: ldr             x1, [x1, #0x200]
    // 0xd179e0: ArrayStore: r0[0] = r1  ; List_4
    //     0xd179e0: stur            w1, [x0, #0x17]
    // 0xd179e4: r1 = Instance_CrossAxisAlignment
    //     0xd179e4: add             x1, PP, #0x7b, lsl #12  ; [pp+0x7bc40] Obj!CrossAxisAlignment@12c4521
    //     0xd179e8: ldr             x1, [x1, #0xc40]
    // 0xd179ec: StoreField: r0->field_1b = r1
    //     0xd179ec: stur            w1, [x0, #0x1b]
    // 0xd179f0: r1 = Instance_VerticalDirection
    //     0xd179f0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xd179f4: ldr             x1, [x1, #0x838]
    // 0xd179f8: StoreField: r0->field_23 = r1
    //     0xd179f8: stur            w1, [x0, #0x23]
    // 0xd179fc: r1 = Instance_Clip
    //     0xd179fc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xd17a00: ldr             x1, [x1, #0x840]
    // 0xd17a04: StoreField: r0->field_2b = r1
    //     0xd17a04: stur            w1, [x0, #0x2b]
    // 0xd17a08: StoreField: r0->field_2f = rZR
    //     0xd17a08: stur            xzr, [x0, #0x2f]
    // 0xd17a0c: ldur            x1, [fp, #-8]
    // 0xd17a10: StoreField: r0->field_b = r1
    //     0xd17a10: stur            w1, [x0, #0xb]
    // 0xd17a14: LeaveFrame
    //     0xd17a14: mov             SP, fp
    //     0xd17a18: ldp             fp, lr, [SP], #0x10
    // 0xd17a1c: ret
    //     0xd17a1c: ret             
    // 0xd17a20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd17a20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd17a24: b               #0xd17338
    // 0xd17a28: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd17a28: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  RestorableDateTimeN _selectedDate(_DatePickerDialogState) {
    // ** addr: 0xd17a44, size: 0xa8
    // 0xd17a44: EnterFrame
    //     0xd17a44: stp             fp, lr, [SP, #-0x10]!
    //     0xd17a48: mov             fp, SP
    // 0xd17a4c: AllocStack(0x10)
    //     0xd17a4c: sub             SP, SP, #0x10
    // 0xd17a50: CheckStackOverflow
    //     0xd17a50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd17a54: cmp             SP, x16
    //     0xd17a58: b.ls            #0xd17ae0
    // 0xd17a5c: ldr             x0, [fp, #0x10]
    // 0xd17a60: LoadField: r1 = r0->field_b
    //     0xd17a60: ldur            w1, [x0, #0xb]
    // 0xd17a64: DecompressPointer r1
    //     0xd17a64: add             x1, x1, HEAP, lsl #32
    // 0xd17a68: cmp             w1, NULL
    // 0xd17a6c: b.eq            #0xd17ae8
    // 0xd17a70: LoadField: r0 = r1->field_b
    //     0xd17a70: ldur            w0, [x1, #0xb]
    // 0xd17a74: DecompressPointer r0
    //     0xd17a74: add             x0, x0, HEAP, lsl #32
    // 0xd17a78: stur            x0, [fp, #-8]
    // 0xd17a7c: r1 = <DateTime?>
    //     0xd17a7c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28500] TypeArguments: <DateTime?>
    //     0xd17a80: ldr             x1, [x1, #0x500]
    // 0xd17a84: r0 = RestorableDateTimeN()
    //     0xd17a84: bl              #0xd17aec  ; AllocateRestorableDateTimeNStub -> RestorableDateTimeN (size=0x3c)
    // 0xd17a88: mov             x1, x0
    // 0xd17a8c: ldur            x0, [fp, #-8]
    // 0xd17a90: stur            x1, [fp, #-0x10]
    // 0xd17a94: StoreField: r1->field_37 = r0
    //     0xd17a94: stur            w0, [x1, #0x37]
    // 0xd17a98: r0 = false
    //     0xd17a98: add             x0, NULL, #0x30  ; false
    // 0xd17a9c: StoreField: r1->field_27 = r0
    //     0xd17a9c: stur            w0, [x1, #0x27]
    // 0xd17aa0: StoreField: r1->field_7 = rZR
    //     0xd17aa0: stur            xzr, [x1, #7]
    // 0xd17aa4: StoreField: r1->field_13 = rZR
    //     0xd17aa4: stur            xzr, [x1, #0x13]
    // 0xd17aa8: StoreField: r1->field_1b = rZR
    //     0xd17aa8: stur            xzr, [x1, #0x1b]
    // 0xd17aac: r0 = LoadStaticField(0x45c)
    //     0xd17aac: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd17ab0: ldr             x0, [x0, #0x8b8]
    // 0xd17ab4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd17ab8: cmp             w0, w16
    // 0xd17abc: b.ne            #0xd17ac8
    // 0xd17ac0: r2 = _emptyListeners
    //     0xd17ac0: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xd17ac4: r0 = InitLateFinalStaticField()
    //     0xd17ac4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd17ac8: mov             x1, x0
    // 0xd17acc: ldur            x0, [fp, #-0x10]
    // 0xd17ad0: StoreField: r0->field_f = r1
    //     0xd17ad0: stur            w1, [x0, #0xf]
    // 0xd17ad4: LeaveFrame
    //     0xd17ad4: mov             SP, fp
    //     0xd17ad8: ldp             fp, lr, [SP], #0x10
    // 0xd17adc: ret
    //     0xd17adc: ret             
    // 0xd17ae0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd17ae0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd17ae4: b               #0xd17a5c
    // 0xd17ae8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd17ae8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleEntryModeToggle(dynamic) {
    // ** addr: 0xd17b28, size: 0x38
    // 0xd17b28: EnterFrame
    //     0xd17b28: stp             fp, lr, [SP, #-0x10]!
    //     0xd17b2c: mov             fp, SP
    // 0xd17b30: ldr             x0, [fp, #0x10]
    // 0xd17b34: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd17b34: ldur            w1, [x0, #0x17]
    // 0xd17b38: DecompressPointer r1
    //     0xd17b38: add             x1, x1, HEAP, lsl #32
    // 0xd17b3c: CheckStackOverflow
    //     0xd17b3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd17b40: cmp             SP, x16
    //     0xd17b44: b.ls            #0xd17b58
    // 0xd17b48: r0 = _handleEntryModeToggle()
    //     0xd17b48: bl              #0xd17b60  ; [package:flutter/src/material/date_picker.dart] _DatePickerDialogState::_handleEntryModeToggle
    // 0xd17b4c: LeaveFrame
    //     0xd17b4c: mov             SP, fp
    //     0xd17b50: ldp             fp, lr, [SP], #0x10
    // 0xd17b54: ret
    //     0xd17b54: ret             
    // 0xd17b58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd17b58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd17b5c: b               #0xd17b48
  }
  _ _handleEntryModeToggle(/* No info */) {
    // ** addr: 0xd17b60, size: 0x64
    // 0xd17b60: EnterFrame
    //     0xd17b60: stp             fp, lr, [SP, #-0x10]!
    //     0xd17b64: mov             fp, SP
    // 0xd17b68: AllocStack(0x8)
    //     0xd17b68: sub             SP, SP, #8
    // 0xd17b6c: SetupParameters(_DatePickerDialogState this /* r1 => r1, fp-0x8 */)
    //     0xd17b6c: stur            x1, [fp, #-8]
    // 0xd17b70: CheckStackOverflow
    //     0xd17b70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd17b74: cmp             SP, x16
    //     0xd17b78: b.ls            #0xd17bbc
    // 0xd17b7c: r1 = 1
    //     0xd17b7c: mov             x1, #1
    // 0xd17b80: r0 = AllocateContext()
    //     0xd17b80: bl              #0x13de838  ; AllocateContextStub
    // 0xd17b84: mov             x1, x0
    // 0xd17b88: ldur            x0, [fp, #-8]
    // 0xd17b8c: StoreField: r1->field_f = r0
    //     0xd17b8c: stur            w0, [x1, #0xf]
    // 0xd17b90: mov             x2, x1
    // 0xd17b94: r1 = Function '<anonymous closure>':.
    //     0xd17b94: add             x1, PP, #0x99, lsl #12  ; [pp+0x99c88] AnonymousClosure: (0xd17bc4), in [package:flutter/src/material/date_picker.dart] _DatePickerDialogState::_handleEntryModeToggle (0xd17b60)
    //     0xd17b98: ldr             x1, [x1, #0xc88]
    // 0xd17b9c: r0 = AllocateClosure()
    //     0xd17b9c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd17ba0: ldur            x1, [fp, #-8]
    // 0xd17ba4: mov             x2, x0
    // 0xd17ba8: r0 = setState()
    //     0xd17ba8: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd17bac: r0 = Null
    //     0xd17bac: mov             x0, NULL
    // 0xd17bb0: LeaveFrame
    //     0xd17bb0: mov             SP, fp
    //     0xd17bb4: ldp             fp, lr, [SP], #0x10
    // 0xd17bb8: ret
    //     0xd17bb8: ret             
    // 0xd17bbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd17bbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd17bc0: b               #0xd17b7c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd17bc4, size: 0x1d8
    // 0xd17bc4: EnterFrame
    //     0xd17bc4: stp             fp, lr, [SP, #-0x10]!
    //     0xd17bc8: mov             fp, SP
    // 0xd17bcc: AllocStack(0x10)
    //     0xd17bcc: sub             SP, SP, #0x10
    // 0xd17bd0: SetupParameters([dynamic _ /* r0 */])
    //     0xd17bd0: ldr             x0, [fp, #0x10]
    //     0xd17bd4: ldur            w2, [x0, #0x17]
    //     0xd17bd8: add             x2, x2, HEAP, lsl #32
    //     0xd17bdc: stur            x2, [fp, #-8]
    // 0xd17be0: CheckStackOverflow
    //     0xd17be0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd17be4: cmp             SP, x16
    //     0xd17be8: b.ls            #0xd17d88
    // 0xd17bec: LoadField: r1 = r2->field_f
    //     0xd17bec: ldur            w1, [x2, #0xf]
    // 0xd17bf0: DecompressPointer r1
    //     0xd17bf0: add             x1, x1, HEAP, lsl #32
    // 0xd17bf4: LoadField: r0 = r1->field_27
    //     0xd17bf4: ldur            w0, [x1, #0x27]
    // 0xd17bf8: DecompressPointer r0
    //     0xd17bf8: add             x0, x0, HEAP, lsl #32
    // 0xd17bfc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd17c00: cmp             w0, w16
    // 0xd17c04: b.ne            #0xd17c14
    // 0xd17c08: r2 = _entryMode
    //     0xd17c08: add             x2, PP, #0x99, lsl #12  ; [pp+0x99ba8] Field <_DatePickerDialogState@75078594._entryMode@75078594>: late final (offset: 0x28)
    //     0xd17c0c: ldr             x2, [x2, #0xba8]
    // 0xd17c10: r0 = InitLateFinalInstanceField()
    //     0xd17c10: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd17c14: LoadField: r3 = r0->field_33
    //     0xd17c14: ldur            w3, [x0, #0x33]
    // 0xd17c18: DecompressPointer r3
    //     0xd17c18: add             x3, x3, HEAP, lsl #32
    // 0xd17c1c: stur            x3, [fp, #-0x10]
    // 0xd17c20: cmp             w3, NULL
    // 0xd17c24: b.ne            #0xd17c5c
    // 0xd17c28: LoadField: r2 = r0->field_23
    //     0xd17c28: ldur            w2, [x0, #0x23]
    // 0xd17c2c: DecompressPointer r2
    //     0xd17c2c: add             x2, x2, HEAP, lsl #32
    // 0xd17c30: mov             x0, x3
    // 0xd17c34: r1 = Null
    //     0xd17c34: mov             x1, NULL
    // 0xd17c38: cmp             w2, NULL
    // 0xd17c3c: b.eq            #0xd17c5c
    // 0xd17c40: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd17c40: ldur            w4, [x2, #0x17]
    // 0xd17c44: DecompressPointer r4
    //     0xd17c44: add             x4, x4, HEAP, lsl #32
    // 0xd17c48: r8 = X0
    //     0xd17c48: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd17c4c: LoadField: r9 = r4->field_7
    //     0xd17c4c: ldur            x9, [x4, #7]
    // 0xd17c50: r3 = Null
    //     0xd17c50: add             x3, PP, #0x99, lsl #12  ; [pp+0x99c90] Null
    //     0xd17c54: ldr             x3, [x3, #0xc90]
    // 0xd17c58: blr             x9
    // 0xd17c5c: ldur            x0, [fp, #-0x10]
    // 0xd17c60: LoadField: r1 = r0->field_7
    //     0xd17c60: ldur            x1, [x0, #7]
    // 0xd17c64: cmp             x1, #1
    // 0xd17c68: b.gt            #0xd17d78
    // 0xd17c6c: cmp             x1, #0
    // 0xd17c70: b.gt            #0xd17cf4
    // 0xd17c74: ldur            x0, [fp, #-8]
    // 0xd17c78: LoadField: r1 = r0->field_f
    //     0xd17c78: ldur            w1, [x0, #0xf]
    // 0xd17c7c: DecompressPointer r1
    //     0xd17c7c: add             x1, x1, HEAP, lsl #32
    // 0xd17c80: LoadField: r2 = r1->field_2b
    //     0xd17c80: ldur            w2, [x1, #0x2b]
    // 0xd17c84: DecompressPointer r2
    //     0xd17c84: add             x2, x2, HEAP, lsl #32
    // 0xd17c88: mov             x1, x2
    // 0xd17c8c: r2 = Instance_AutovalidateMode
    //     0xd17c8c: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a608] Obj!AutovalidateMode@12c3061
    //     0xd17c90: ldr             x2, [x2, #0x608]
    // 0xd17c94: r0 = value=()
    //     0xd17c94: bl              #0x86c6b4  ; [package:flutter/src/widgets/restoration_properties.dart] RestorableValue::value=
    // 0xd17c98: ldur            x0, [fp, #-8]
    // 0xd17c9c: LoadField: r1 = r0->field_f
    //     0xd17c9c: ldur            w1, [x0, #0xf]
    // 0xd17ca0: DecompressPointer r1
    //     0xd17ca0: add             x1, x1, HEAP, lsl #32
    // 0xd17ca4: LoadField: r0 = r1->field_27
    //     0xd17ca4: ldur            w0, [x1, #0x27]
    // 0xd17ca8: DecompressPointer r0
    //     0xd17ca8: add             x0, x0, HEAP, lsl #32
    // 0xd17cac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd17cb0: cmp             w0, w16
    // 0xd17cb4: b.ne            #0xd17cc4
    // 0xd17cb8: r2 = _entryMode
    //     0xd17cb8: add             x2, PP, #0x99, lsl #12  ; [pp+0x99ba8] Field <_DatePickerDialogState@75078594._entryMode@75078594>: late final (offset: 0x28)
    //     0xd17cbc: ldr             x2, [x2, #0xba8]
    // 0xd17cc0: r0 = InitLateFinalInstanceField()
    //     0xd17cc0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd17cc4: mov             x1, x0
    // 0xd17cc8: r2 = Instance_DatePickerEntryMode
    //     0xd17cc8: add             x2, PP, #0x99, lsl #12  ; [pp+0x99c80] Obj!DatePickerEntryMode@12c58a1
    //     0xd17ccc: ldr             x2, [x2, #0xc80]
    // 0xd17cd0: r0 = value=()
    //     0xd17cd0: bl              #0x86c6b4  ; [package:flutter/src/widgets/restoration_properties.dart] RestorableValue::value=
    // 0xd17cd4: ldur            x0, [fp, #-8]
    // 0xd17cd8: LoadField: r1 = r0->field_f
    //     0xd17cd8: ldur            w1, [x0, #0xf]
    // 0xd17cdc: DecompressPointer r1
    //     0xd17cdc: add             x1, x1, HEAP, lsl #32
    // 0xd17ce0: LoadField: r0 = r1->field_b
    //     0xd17ce0: ldur            w0, [x1, #0xb]
    // 0xd17ce4: DecompressPointer r0
    //     0xd17ce4: add             x0, x0, HEAP, lsl #32
    // 0xd17ce8: cmp             w0, NULL
    // 0xd17cec: b.eq            #0xd17d90
    // 0xd17cf0: b               #0xd17d78
    // 0xd17cf4: ldur            x0, [fp, #-8]
    // 0xd17cf8: LoadField: r1 = r0->field_f
    //     0xd17cf8: ldur            w1, [x0, #0xf]
    // 0xd17cfc: DecompressPointer r1
    //     0xd17cfc: add             x1, x1, HEAP, lsl #32
    // 0xd17d00: LoadField: r2 = r1->field_33
    //     0xd17d00: ldur            w2, [x1, #0x33]
    // 0xd17d04: DecompressPointer r2
    //     0xd17d04: add             x2, x2, HEAP, lsl #32
    // 0xd17d08: mov             x1, x2
    // 0xd17d0c: r0 = currentState()
    //     0xd17d0c: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0xd17d10: cmp             w0, NULL
    // 0xd17d14: b.eq            #0xd17d94
    // 0xd17d18: mov             x1, x0
    // 0xd17d1c: r0 = save()
    //     0xd17d1c: bl              #0xd17d9c  ; [package:flutter/src/widgets/form.dart] FormState::save
    // 0xd17d20: ldur            x0, [fp, #-8]
    // 0xd17d24: LoadField: r1 = r0->field_f
    //     0xd17d24: ldur            w1, [x0, #0xf]
    // 0xd17d28: DecompressPointer r1
    //     0xd17d28: add             x1, x1, HEAP, lsl #32
    // 0xd17d2c: LoadField: r0 = r1->field_27
    //     0xd17d2c: ldur            w0, [x1, #0x27]
    // 0xd17d30: DecompressPointer r0
    //     0xd17d30: add             x0, x0, HEAP, lsl #32
    // 0xd17d34: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd17d38: cmp             w0, w16
    // 0xd17d3c: b.ne            #0xd17d4c
    // 0xd17d40: r2 = _entryMode
    //     0xd17d40: add             x2, PP, #0x99, lsl #12  ; [pp+0x99ba8] Field <_DatePickerDialogState@75078594._entryMode@75078594>: late final (offset: 0x28)
    //     0xd17d44: ldr             x2, [x2, #0xba8]
    // 0xd17d48: r0 = InitLateFinalInstanceField()
    //     0xd17d48: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd17d4c: mov             x1, x0
    // 0xd17d50: r2 = Instance_DatePickerEntryMode
    //     0xd17d50: add             x2, PP, #0x28, lsl #12  ; [pp+0x28520] Obj!DatePickerEntryMode@12c58c1
    //     0xd17d54: ldr             x2, [x2, #0x520]
    // 0xd17d58: r0 = value=()
    //     0xd17d58: bl              #0x86c6b4  ; [package:flutter/src/widgets/restoration_properties.dart] RestorableValue::value=
    // 0xd17d5c: ldur            x1, [fp, #-8]
    // 0xd17d60: LoadField: r2 = r1->field_f
    //     0xd17d60: ldur            w2, [x1, #0xf]
    // 0xd17d64: DecompressPointer r2
    //     0xd17d64: add             x2, x2, HEAP, lsl #32
    // 0xd17d68: LoadField: r1 = r2->field_b
    //     0xd17d68: ldur            w1, [x2, #0xb]
    // 0xd17d6c: DecompressPointer r1
    //     0xd17d6c: add             x1, x1, HEAP, lsl #32
    // 0xd17d70: cmp             w1, NULL
    // 0xd17d74: b.eq            #0xd17d98
    // 0xd17d78: r0 = Null
    //     0xd17d78: mov             x0, NULL
    // 0xd17d7c: LeaveFrame
    //     0xd17d7c: mov             SP, fp
    //     0xd17d80: ldp             fp, lr, [SP], #0x10
    // 0xd17d84: ret
    //     0xd17d84: ret             
    // 0xd17d88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd17d88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd17d8c: b               #0xd17bec
    // 0xd17d90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd17d90: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd17d94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd17d94: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd17d98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd17d98: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleDateChanged(dynamic, DateTime) {
    // ** addr: 0xd181e8, size: 0x3c
    // 0xd181e8: EnterFrame
    //     0xd181e8: stp             fp, lr, [SP, #-0x10]!
    //     0xd181ec: mov             fp, SP
    // 0xd181f0: ldr             x0, [fp, #0x18]
    // 0xd181f4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd181f4: ldur            w1, [x0, #0x17]
    // 0xd181f8: DecompressPointer r1
    //     0xd181f8: add             x1, x1, HEAP, lsl #32
    // 0xd181fc: CheckStackOverflow
    //     0xd181fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd18200: cmp             SP, x16
    //     0xd18204: b.ls            #0xd1821c
    // 0xd18208: ldr             x2, [fp, #0x10]
    // 0xd1820c: r0 = _handleDateChanged()
    //     0xd1820c: bl              #0xd18224  ; [package:flutter/src/material/date_picker.dart] _DatePickerDialogState::_handleDateChanged
    // 0xd18210: LeaveFrame
    //     0xd18210: mov             SP, fp
    //     0xd18214: ldp             fp, lr, [SP], #0x10
    // 0xd18218: ret
    //     0xd18218: ret             
    // 0xd1821c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1821c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd18220: b               #0xd18208
  }
  _ _handleDateChanged(/* No info */) {
    // ** addr: 0xd18224, size: 0x70
    // 0xd18224: EnterFrame
    //     0xd18224: stp             fp, lr, [SP, #-0x10]!
    //     0xd18228: mov             fp, SP
    // 0xd1822c: AllocStack(0x10)
    //     0xd1822c: sub             SP, SP, #0x10
    // 0xd18230: SetupParameters(_DatePickerDialogState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd18230: stur            x1, [fp, #-8]
    //     0xd18234: stur            x2, [fp, #-0x10]
    // 0xd18238: CheckStackOverflow
    //     0xd18238: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1823c: cmp             SP, x16
    //     0xd18240: b.ls            #0xd1828c
    // 0xd18244: r1 = 2
    //     0xd18244: mov             x1, #2
    // 0xd18248: r0 = AllocateContext()
    //     0xd18248: bl              #0x13de838  ; AllocateContextStub
    // 0xd1824c: mov             x1, x0
    // 0xd18250: ldur            x0, [fp, #-8]
    // 0xd18254: StoreField: r1->field_f = r0
    //     0xd18254: stur            w0, [x1, #0xf]
    // 0xd18258: ldur            x2, [fp, #-0x10]
    // 0xd1825c: StoreField: r1->field_13 = r2
    //     0xd1825c: stur            w2, [x1, #0x13]
    // 0xd18260: mov             x2, x1
    // 0xd18264: r1 = Function '<anonymous closure>':.
    //     0xd18264: add             x1, PP, #0x99, lsl #12  ; [pp+0x99cc0] AnonymousClosure: (0xd18294), in [package:flutter/src/material/date_picker.dart] _DatePickerDialogState::_handleDateChanged (0xd18224)
    //     0xd18268: ldr             x1, [x1, #0xcc0]
    // 0xd1826c: r0 = AllocateClosure()
    //     0xd1826c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd18270: ldur            x1, [fp, #-8]
    // 0xd18274: mov             x2, x0
    // 0xd18278: r0 = setState()
    //     0xd18278: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd1827c: r0 = Null
    //     0xd1827c: mov             x0, NULL
    // 0xd18280: LeaveFrame
    //     0xd18280: mov             SP, fp
    //     0xd18284: ldp             fp, lr, [SP], #0x10
    // 0xd18288: ret
    //     0xd18288: ret             
    // 0xd1828c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1828c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd18290: b               #0xd18244
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd18294, size: 0x84
    // 0xd18294: EnterFrame
    //     0xd18294: stp             fp, lr, [SP, #-0x10]!
    //     0xd18298: mov             fp, SP
    // 0xd1829c: AllocStack(0x10)
    //     0xd1829c: sub             SP, SP, #0x10
    // 0xd182a0: SetupParameters([dynamic _ /* r0 */])
    //     0xd182a0: ldr             x0, [fp, #0x10]
    //     0xd182a4: ldur            w2, [x0, #0x17]
    //     0xd182a8: add             x2, x2, HEAP, lsl #32
    //     0xd182ac: stur            x2, [fp, #-8]
    // 0xd182b0: CheckStackOverflow
    //     0xd182b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd182b4: cmp             SP, x16
    //     0xd182b8: b.ls            #0xd18310
    // 0xd182bc: LoadField: r1 = r2->field_f
    //     0xd182bc: ldur            w1, [x2, #0xf]
    // 0xd182c0: DecompressPointer r1
    //     0xd182c0: add             x1, x1, HEAP, lsl #32
    // 0xd182c4: LoadField: r0 = r1->field_23
    //     0xd182c4: ldur            w0, [x1, #0x23]
    // 0xd182c8: DecompressPointer r0
    //     0xd182c8: add             x0, x0, HEAP, lsl #32
    // 0xd182cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd182d0: cmp             w0, w16
    // 0xd182d4: b.ne            #0xd182e4
    // 0xd182d8: r2 = _selectedDate
    //     0xd182d8: add             x2, PP, #0x99, lsl #12  ; [pp+0x99c20] Field <_DatePickerDialogState@75078594._selectedDate@75078594>: late final (offset: 0x24)
    //     0xd182dc: ldr             x2, [x2, #0xc20]
    // 0xd182e0: r0 = InitLateFinalInstanceField()
    //     0xd182e0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd182e4: mov             x1, x0
    // 0xd182e8: ldur            x0, [fp, #-8]
    // 0xd182ec: LoadField: r3 = r0->field_13
    //     0xd182ec: ldur            w3, [x0, #0x13]
    // 0xd182f0: DecompressPointer r3
    //     0xd182f0: add             x3, x3, HEAP, lsl #32
    // 0xd182f4: mov             x2, x3
    // 0xd182f8: stur            x3, [fp, #-0x10]
    // 0xd182fc: r0 = value=()
    //     0xd182fc: bl              #0x86c6b4  ; [package:flutter/src/widgets/restoration_properties.dart] RestorableValue::value=
    // 0xd18300: ldur            x0, [fp, #-0x10]
    // 0xd18304: LeaveFrame
    //     0xd18304: mov             SP, fp
    //     0xd18308: ldp             fp, lr, [SP], #0x10
    // 0xd1830c: ret
    //     0xd1830c: ret             
    // 0xd18310: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd18310: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd18314: b               #0xd182bc
  }
  [closure] Form inputDatePicker(dynamic) {
    // ** addr: 0xd18528, size: 0x384
    // 0xd18528: EnterFrame
    //     0xd18528: stp             fp, lr, [SP, #-0x10]!
    //     0xd1852c: mov             fp, SP
    // 0xd18530: AllocStack(0x40)
    //     0xd18530: sub             SP, SP, #0x40
    // 0xd18534: SetupParameters([dynamic _ /* r0 */])
    //     0xd18534: ldr             x0, [fp, #0x10]
    //     0xd18538: ldur            w3, [x0, #0x17]
    //     0xd1853c: add             x3, x3, HEAP, lsl #32
    //     0xd18540: stur            x3, [fp, #-0x20]
    // 0xd18544: CheckStackOverflow
    //     0xd18544: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd18548: cmp             SP, x16
    //     0xd1854c: b.ls            #0xd18884
    // 0xd18550: LoadField: r4 = r3->field_f
    //     0xd18550: ldur            w4, [x3, #0xf]
    // 0xd18554: DecompressPointer r4
    //     0xd18554: add             x4, x4, HEAP, lsl #32
    // 0xd18558: stur            x4, [fp, #-0x18]
    // 0xd1855c: LoadField: r5 = r4->field_33
    //     0xd1855c: ldur            w5, [x4, #0x33]
    // 0xd18560: DecompressPointer r5
    //     0xd18560: add             x5, x5, HEAP, lsl #32
    // 0xd18564: stur            x5, [fp, #-0x10]
    // 0xd18568: LoadField: r0 = r4->field_2b
    //     0xd18568: ldur            w0, [x4, #0x2b]
    // 0xd1856c: DecompressPointer r0
    //     0xd1856c: add             x0, x0, HEAP, lsl #32
    // 0xd18570: LoadField: r6 = r0->field_33
    //     0xd18570: ldur            w6, [x0, #0x33]
    // 0xd18574: DecompressPointer r6
    //     0xd18574: add             x6, x6, HEAP, lsl #32
    // 0xd18578: stur            x6, [fp, #-8]
    // 0xd1857c: cmp             w6, NULL
    // 0xd18580: b.ne            #0xd185b8
    // 0xd18584: LoadField: r2 = r0->field_23
    //     0xd18584: ldur            w2, [x0, #0x23]
    // 0xd18588: DecompressPointer r2
    //     0xd18588: add             x2, x2, HEAP, lsl #32
    // 0xd1858c: mov             x0, x6
    // 0xd18590: r1 = Null
    //     0xd18590: mov             x1, NULL
    // 0xd18594: cmp             w2, NULL
    // 0xd18598: b.eq            #0xd185b8
    // 0xd1859c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd1859c: ldur            w4, [x2, #0x17]
    // 0xd185a0: DecompressPointer r4
    //     0xd185a0: add             x4, x4, HEAP, lsl #32
    // 0xd185a4: r8 = X0
    //     0xd185a4: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd185a8: LoadField: r9 = r4->field_7
    //     0xd185a8: ldur            x9, [x4, #7]
    // 0xd185ac: r3 = Null
    //     0xd185ac: add             x3, PP, #0x99, lsl #12  ; [pp+0x99cc8] Null
    //     0xd185b0: ldr             x3, [x3, #0xcc8]
    // 0xd185b4: blr             x9
    // 0xd185b8: ldur            x0, [fp, #-0x20]
    // 0xd185bc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd185bc: ldur            w1, [x0, #0x17]
    // 0xd185c0: DecompressPointer r1
    //     0xd185c0: add             x1, x1, HEAP, lsl #32
    // 0xd185c4: r16 = Instance_Orientation
    //     0xd185c4: add             x16, PP, #0x14, lsl #12  ; [pp+0x143c8] Obj!Orientation@12c2ec1
    //     0xd185c8: ldr             x16, [x16, #0x3c8]
    // 0xd185cc: cmp             w1, w16
    // 0xd185d0: b.ne            #0xd185e0
    // 0xd185d4: d0 = 98.000000
    //     0xd185d4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13438] IMM: double(98) from 0x4058800000000000
    //     0xd185d8: ldr             d0, [x17, #0x438]
    // 0xd185dc: b               #0xd185e8
    // 0xd185e0: d0 = 108.000000
    //     0xd185e0: add             x17, PP, #0x13, lsl #12  ; [pp+0x132e0] IMM: double(108) from 0x405b000000000000
    //     0xd185e4: ldr             d0, [x17, #0x2e0]
    // 0xd185e8: ldur            x1, [fp, #-0x18]
    // 0xd185ec: stur            d0, [fp, #-0x38]
    // 0xd185f0: LoadField: r2 = r1->field_b
    //     0xd185f0: ldur            w2, [x1, #0xb]
    // 0xd185f4: DecompressPointer r2
    //     0xd185f4: add             x2, x2, HEAP, lsl #32
    // 0xd185f8: cmp             w2, NULL
    // 0xd185fc: b.eq            #0xd1888c
    // 0xd18600: LoadField: r0 = r1->field_23
    //     0xd18600: ldur            w0, [x1, #0x23]
    // 0xd18604: DecompressPointer r0
    //     0xd18604: add             x0, x0, HEAP, lsl #32
    // 0xd18608: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd1860c: cmp             w0, w16
    // 0xd18610: b.ne            #0xd18620
    // 0xd18614: r2 = _selectedDate
    //     0xd18614: add             x2, PP, #0x99, lsl #12  ; [pp+0x99c20] Field <_DatePickerDialogState@75078594._selectedDate@75078594>: late final (offset: 0x24)
    //     0xd18618: ldr             x2, [x2, #0xc20]
    // 0xd1861c: r0 = InitLateFinalInstanceField()
    //     0xd1861c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd18620: LoadField: r3 = r0->field_33
    //     0xd18620: ldur            w3, [x0, #0x33]
    // 0xd18624: DecompressPointer r3
    //     0xd18624: add             x3, x3, HEAP, lsl #32
    // 0xd18628: stur            x3, [fp, #-0x18]
    // 0xd1862c: cmp             w3, NULL
    // 0xd18630: b.ne            #0xd18668
    // 0xd18634: LoadField: r2 = r0->field_23
    //     0xd18634: ldur            w2, [x0, #0x23]
    // 0xd18638: DecompressPointer r2
    //     0xd18638: add             x2, x2, HEAP, lsl #32
    // 0xd1863c: mov             x0, x3
    // 0xd18640: r1 = Null
    //     0xd18640: mov             x1, NULL
    // 0xd18644: cmp             w2, NULL
    // 0xd18648: b.eq            #0xd18668
    // 0xd1864c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd1864c: ldur            w4, [x2, #0x17]
    // 0xd18650: DecompressPointer r4
    //     0xd18650: add             x4, x4, HEAP, lsl #32
    // 0xd18654: r8 = X0
    //     0xd18654: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd18658: LoadField: r9 = r4->field_7
    //     0xd18658: ldur            x9, [x4, #7]
    // 0xd1865c: r3 = Null
    //     0xd1865c: add             x3, PP, #0x99, lsl #12  ; [pp+0x99cd8] Null
    //     0xd18660: ldr             x3, [x3, #0xcd8]
    // 0xd18664: blr             x9
    // 0xd18668: ldur            x0, [fp, #-0x20]
    // 0xd1866c: ldur            x3, [fp, #-0x10]
    // 0xd18670: ldur            d0, [fp, #-0x38]
    // 0xd18674: ldur            x4, [fp, #-8]
    // 0xd18678: LoadField: r2 = r0->field_f
    //     0xd18678: ldur            w2, [x0, #0xf]
    // 0xd1867c: DecompressPointer r2
    //     0xd1867c: add             x2, x2, HEAP, lsl #32
    // 0xd18680: LoadField: r0 = r2->field_b
    //     0xd18680: ldur            w0, [x2, #0xb]
    // 0xd18684: DecompressPointer r0
    //     0xd18684: add             x0, x0, HEAP, lsl #32
    // 0xd18688: cmp             w0, NULL
    // 0xd1868c: b.eq            #0xd18890
    // 0xd18690: LoadField: r5 = r0->field_f
    //     0xd18690: ldur            w5, [x0, #0xf]
    // 0xd18694: DecompressPointer r5
    //     0xd18694: add             x5, x5, HEAP, lsl #32
    // 0xd18698: stur            x5, [fp, #-0x28]
    // 0xd1869c: LoadField: r6 = r0->field_13
    //     0xd1869c: ldur            w6, [x0, #0x13]
    // 0xd186a0: DecompressPointer r6
    //     0xd186a0: add             x6, x6, HEAP, lsl #32
    // 0xd186a4: stur            x6, [fp, #-0x20]
    // 0xd186a8: r1 = Function '_handleDateChanged@75078594':.
    //     0xd186a8: add             x1, PP, #0x99, lsl #12  ; [pp+0x99ce8] AnonymousClosure: (0xd181e8), in [package:flutter/src/material/date_picker.dart] _DatePickerDialogState::_handleDateChanged (0xd18224)
    //     0xd186ac: ldr             x1, [x1, #0xce8]
    // 0xd186b0: r0 = AllocateClosure()
    //     0xd186b0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd186b4: stur            x0, [fp, #-0x30]
    // 0xd186b8: r0 = InputDatePickerFormField()
    //     0xd186b8: bl              #0xd18b2c  ; AllocateInputDatePickerFormFieldStub -> InputDatePickerFormField (size=0x48)
    // 0xd186bc: mov             x1, x0
    // 0xd186c0: ldur            x2, [fp, #-0x28]
    // 0xd186c4: ldur            x3, [fp, #-0x18]
    // 0xd186c8: ldur            x5, [fp, #-0x20]
    // 0xd186cc: ldur            x6, [fp, #-0x30]
    // 0xd186d0: ldur            x7, [fp, #-0x30]
    // 0xd186d4: stur            x0, [fp, #-0x18]
    // 0xd186d8: r0 = InputDatePickerFormField()
    //     0xd186d8: bl              #0xd188e8  ; [package:flutter/src/material/input_date_picker_form_field.dart] InputDatePickerFormField::InputDatePickerFormField
    // 0xd186dc: r16 = 2.000000
    //     0xd186dc: add             x16, PP, #0x1b, lsl #12  ; [pp+0x1b1e0] 2
    //     0xd186e0: ldr             x16, [x16, #0x1e0]
    // 0xd186e4: str             x16, [SP]
    // 0xd186e8: ldur            x1, [fp, #-0x18]
    // 0xd186ec: r4 = const [0, 0x2, 0x1, 0x1, maxScaleFactor, 0x1, null]
    //     0xd186ec: add             x4, PP, #0x90, lsl #12  ; [pp+0x90d70] List(7) [0, 0x2, 0x1, 0x1, "maxScaleFactor", 0x1, Null]
    //     0xd186f0: ldr             x4, [x4, #0xd70]
    // 0xd186f4: r0 = withClampedTextScaling()
    //     0xd186f4: bl              #0xd16294  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::withClampedTextScaling
    // 0xd186f8: r1 = <FlexParentData>
    //     0xd186f8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xd186fc: ldr             x1, [x1, #0x878]
    // 0xd18700: stur            x0, [fp, #-0x18]
    // 0xd18704: r0 = Flexible()
    //     0xd18704: bl              #0xd0fd68  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0xd18708: mov             x3, x0
    // 0xd1870c: r0 = 1
    //     0xd1870c: mov             x0, #1
    // 0xd18710: stur            x3, [fp, #-0x20]
    // 0xd18714: StoreField: r3->field_13 = r0
    //     0xd18714: stur            x0, [x3, #0x13]
    // 0xd18718: r0 = Instance_FlexFit
    //     0xd18718: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ac30] Obj!FlexFit@12c4661
    //     0xd1871c: ldr             x0, [x0, #0xc30]
    // 0xd18720: StoreField: r3->field_1b = r0
    //     0xd18720: stur            w0, [x3, #0x1b]
    // 0xd18724: ldur            x0, [fp, #-0x18]
    // 0xd18728: StoreField: r3->field_b = r0
    //     0xd18728: stur            w0, [x3, #0xb]
    // 0xd1872c: r1 = Null
    //     0xd1872c: mov             x1, NULL
    // 0xd18730: r2 = 2
    //     0xd18730: mov             x2, #2
    // 0xd18734: r0 = AllocateArray()
    //     0xd18734: bl              #0x13df928  ; AllocateArrayStub
    // 0xd18738: mov             x2, x0
    // 0xd1873c: ldur            x0, [fp, #-0x20]
    // 0xd18740: stur            x2, [fp, #-0x18]
    // 0xd18744: StoreField: r2->field_f = r0
    //     0xd18744: stur            w0, [x2, #0xf]
    // 0xd18748: r1 = <Widget>
    //     0xd18748: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd1874c: r0 = AllocateGrowableArray()
    //     0xd1874c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd18750: mov             x1, x0
    // 0xd18754: ldur            x0, [fp, #-0x18]
    // 0xd18758: stur            x1, [fp, #-0x20]
    // 0xd1875c: StoreField: r1->field_f = r0
    //     0xd1875c: stur            w0, [x1, #0xf]
    // 0xd18760: r0 = 2
    //     0xd18760: mov             x0, #2
    // 0xd18764: StoreField: r1->field_b = r0
    //     0xd18764: stur            w0, [x1, #0xb]
    // 0xd18768: r0 = Column()
    //     0xd18768: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xd1876c: mov             x1, x0
    // 0xd18770: r0 = Instance_Axis
    //     0xd18770: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xd18774: stur            x1, [fp, #-0x18]
    // 0xd18778: StoreField: r1->field_f = r0
    //     0xd18778: stur            w0, [x1, #0xf]
    // 0xd1877c: r0 = Instance_MainAxisAlignment
    //     0xd1877c: add             x0, PP, #0x18, lsl #12  ; [pp+0x180f0] Obj!MainAxisAlignment@12c4581
    //     0xd18780: ldr             x0, [x0, #0xf0]
    // 0xd18784: StoreField: r1->field_13 = r0
    //     0xd18784: stur            w0, [x1, #0x13]
    // 0xd18788: r0 = Instance_MainAxisSize
    //     0xd18788: add             x0, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xd1878c: ldr             x0, [x0, #0x828]
    // 0xd18790: ArrayStore: r1[0] = r0  ; List_4
    //     0xd18790: stur            w0, [x1, #0x17]
    // 0xd18794: r0 = Instance_CrossAxisAlignment
    //     0xd18794: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xd18798: ldr             x0, [x0, #0x888]
    // 0xd1879c: StoreField: r1->field_1b = r0
    //     0xd1879c: stur            w0, [x1, #0x1b]
    // 0xd187a0: r0 = Instance_VerticalDirection
    //     0xd187a0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xd187a4: ldr             x0, [x0, #0x838]
    // 0xd187a8: StoreField: r1->field_23 = r0
    //     0xd187a8: stur            w0, [x1, #0x23]
    // 0xd187ac: r0 = Instance_Clip
    //     0xd187ac: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xd187b0: ldr             x0, [x0, #0x840]
    // 0xd187b4: StoreField: r1->field_2b = r0
    //     0xd187b4: stur            w0, [x1, #0x2b]
    // 0xd187b8: StoreField: r1->field_2f = rZR
    //     0xd187b8: stur            xzr, [x1, #0x2f]
    // 0xd187bc: ldur            x0, [fp, #-0x20]
    // 0xd187c0: StoreField: r1->field_b = r0
    //     0xd187c0: stur            w0, [x1, #0xb]
    // 0xd187c4: r0 = Shortcuts()
    //     0xd187c4: bl              #0xd188b8  ; AllocateShortcutsStub -> Shortcuts (size=0x20)
    // 0xd187c8: mov             x1, x0
    // 0xd187cc: ldur            x0, [fp, #-0x18]
    // 0xd187d0: stur            x1, [fp, #-0x20]
    // 0xd187d4: StoreField: r1->field_13 = r0
    //     0xd187d4: stur            w0, [x1, #0x13]
    // 0xd187d8: r0 = true
    //     0xd187d8: add             x0, NULL, #0x20  ; true
    // 0xd187dc: StoreField: r1->field_1b = r0
    //     0xd187dc: stur            w0, [x1, #0x1b]
    // 0xd187e0: r0 = _ConstMap len:1
    //     0xd187e0: add             x0, PP, #0x99, lsl #12  ; [pp+0x99cf0] Map<ShortcutActivator, Intent>(1)
    //     0xd187e4: ldr             x0, [x0, #0xcf0]
    // 0xd187e8: StoreField: r1->field_f = r0
    //     0xd187e8: stur            w0, [x1, #0xf]
    // 0xd187ec: r0 = Padding()
    //     0xd187ec: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xd187f0: mov             x1, x0
    // 0xd187f4: r0 = Instance_EdgeInsets
    //     0xd187f4: add             x0, PP, #0x26, lsl #12  ; [pp+0x26518] Obj!EdgeInsets@129cd51
    //     0xd187f8: ldr             x0, [x0, #0x518]
    // 0xd187fc: stur            x1, [fp, #-0x28]
    // 0xd18800: StoreField: r1->field_f = r0
    //     0xd18800: stur            w0, [x1, #0xf]
    // 0xd18804: ldur            x0, [fp, #-0x20]
    // 0xd18808: StoreField: r1->field_b = r0
    //     0xd18808: stur            w0, [x1, #0xb]
    // 0xd1880c: ldur            d0, [fp, #-0x38]
    // 0xd18810: r0 = inline_Allocate_Double()
    //     0xd18810: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xd18814: add             x0, x0, #0x10
    //     0xd18818: cmp             x2, x0
    //     0xd1881c: b.ls            #0xd18894
    //     0xd18820: str             x0, [THR, #0x60]  ; THR::top
    //     0xd18824: sub             x0, x0, #0xf
    //     0xd18828: mov             x2, #0xe19c
    //     0xd1882c: movk            x2, #3, lsl #16
    //     0xd18830: stur            x2, [x0, #-1]
    // 0xd18834: dmb             ishst
    // 0xd18838: StoreField: r0->field_7 = d0
    //     0xd18838: stur            d0, [x0, #7]
    // 0xd1883c: stur            x0, [fp, #-0x18]
    // 0xd18840: r0 = SizedBox()
    //     0xd18840: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xd18844: mov             x1, x0
    // 0xd18848: ldur            x0, [fp, #-0x18]
    // 0xd1884c: stur            x1, [fp, #-0x20]
    // 0xd18850: StoreField: r1->field_13 = r0
    //     0xd18850: stur            w0, [x1, #0x13]
    // 0xd18854: ldur            x0, [fp, #-0x28]
    // 0xd18858: StoreField: r1->field_b = r0
    //     0xd18858: stur            w0, [x1, #0xb]
    // 0xd1885c: r0 = Form()
    //     0xd1885c: bl              #0xd188ac  ; AllocateFormStub -> Form (size=0x28)
    // 0xd18860: ldur            x1, [fp, #-0x20]
    // 0xd18864: StoreField: r0->field_b = r1
    //     0xd18864: stur            w1, [x0, #0xb]
    // 0xd18868: ldur            x1, [fp, #-8]
    // 0xd1886c: StoreField: r0->field_23 = r1
    //     0xd1886c: stur            w1, [x0, #0x23]
    // 0xd18870: ldur            x1, [fp, #-0x10]
    // 0xd18874: StoreField: r0->field_7 = r1
    //     0xd18874: stur            w1, [x0, #7]
    // 0xd18878: LeaveFrame
    //     0xd18878: mov             SP, fp
    //     0xd1887c: ldp             fp, lr, [SP], #0x10
    // 0xd18880: ret
    //     0xd18880: ret             
    // 0xd18884: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd18884: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd18888: b               #0xd18550
    // 0xd1888c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd1888c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd18890: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd18890: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd18894: SaveReg d0
    //     0xd18894: str             q0, [SP, #-0x10]!
    // 0xd18898: SaveReg r1
    //     0xd18898: str             x1, [SP, #-8]!
    // 0xd1889c: r0 = AllocateDouble()
    //     0xd1889c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd188a0: RestoreReg r1
    //     0xd188a0: ldr             x1, [SP], #8
    // 0xd188a4: RestoreReg d0
    //     0xd188a4: ldr             q0, [SP], #0x10
    // 0xd188a8: b               #0xd18838
  }
  [closure] CalendarDatePicker calendarDatePicker(dynamic) {
    // ** addr: 0xd18b80, size: 0x150
    // 0xd18b80: EnterFrame
    //     0xd18b80: stp             fp, lr, [SP, #-0x10]!
    //     0xd18b84: mov             fp, SP
    // 0xd18b88: AllocStack(0x40)
    //     0xd18b88: sub             SP, SP, #0x40
    // 0xd18b8c: SetupParameters([dynamic _ /* r0 */])
    //     0xd18b8c: ldr             x0, [fp, #0x10]
    //     0xd18b90: ldur            w2, [x0, #0x17]
    //     0xd18b94: add             x2, x2, HEAP, lsl #32
    //     0xd18b98: stur            x2, [fp, #-0x10]
    // 0xd18b9c: CheckStackOverflow
    //     0xd18b9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd18ba0: cmp             SP, x16
    //     0xd18ba4: b.ls            #0xd18cc0
    // 0xd18ba8: LoadField: r1 = r2->field_f
    //     0xd18ba8: ldur            w1, [x2, #0xf]
    // 0xd18bac: DecompressPointer r1
    //     0xd18bac: add             x1, x1, HEAP, lsl #32
    // 0xd18bb0: LoadField: r0 = r1->field_b
    //     0xd18bb0: ldur            w0, [x1, #0xb]
    // 0xd18bb4: DecompressPointer r0
    //     0xd18bb4: add             x0, x0, HEAP, lsl #32
    // 0xd18bb8: cmp             w0, NULL
    // 0xd18bbc: b.eq            #0xd18cc8
    // 0xd18bc0: LoadField: r6 = r1->field_2f
    //     0xd18bc0: ldur            w6, [x1, #0x2f]
    // 0xd18bc4: DecompressPointer r6
    //     0xd18bc4: add             x6, x6, HEAP, lsl #32
    // 0xd18bc8: stur            x6, [fp, #-8]
    // 0xd18bcc: LoadField: r0 = r1->field_23
    //     0xd18bcc: ldur            w0, [x1, #0x23]
    // 0xd18bd0: DecompressPointer r0
    //     0xd18bd0: add             x0, x0, HEAP, lsl #32
    // 0xd18bd4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd18bd8: cmp             w0, w16
    // 0xd18bdc: b.ne            #0xd18bec
    // 0xd18be0: r2 = _selectedDate
    //     0xd18be0: add             x2, PP, #0x99, lsl #12  ; [pp+0x99c20] Field <_DatePickerDialogState@75078594._selectedDate@75078594>: late final (offset: 0x24)
    //     0xd18be4: ldr             x2, [x2, #0xc20]
    // 0xd18be8: r0 = InitLateFinalInstanceField()
    //     0xd18be8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd18bec: LoadField: r3 = r0->field_33
    //     0xd18bec: ldur            w3, [x0, #0x33]
    // 0xd18bf0: DecompressPointer r3
    //     0xd18bf0: add             x3, x3, HEAP, lsl #32
    // 0xd18bf4: stur            x3, [fp, #-0x18]
    // 0xd18bf8: cmp             w3, NULL
    // 0xd18bfc: b.ne            #0xd18c34
    // 0xd18c00: LoadField: r2 = r0->field_23
    //     0xd18c00: ldur            w2, [x0, #0x23]
    // 0xd18c04: DecompressPointer r2
    //     0xd18c04: add             x2, x2, HEAP, lsl #32
    // 0xd18c08: mov             x0, x3
    // 0xd18c0c: r1 = Null
    //     0xd18c0c: mov             x1, NULL
    // 0xd18c10: cmp             w2, NULL
    // 0xd18c14: b.eq            #0xd18c34
    // 0xd18c18: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd18c18: ldur            w4, [x2, #0x17]
    // 0xd18c1c: DecompressPointer r4
    //     0xd18c1c: add             x4, x4, HEAP, lsl #32
    // 0xd18c20: r8 = X0
    //     0xd18c20: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd18c24: LoadField: r9 = r4->field_7
    //     0xd18c24: ldur            x9, [x4, #7]
    // 0xd18c28: r3 = Null
    //     0xd18c28: add             x3, PP, #0x99, lsl #12  ; [pp+0x99cf8] Null
    //     0xd18c2c: ldr             x3, [x3, #0xcf8]
    // 0xd18c30: blr             x9
    // 0xd18c34: ldur            x0, [fp, #-0x10]
    // 0xd18c38: LoadField: r2 = r0->field_f
    //     0xd18c38: ldur            w2, [x0, #0xf]
    // 0xd18c3c: DecompressPointer r2
    //     0xd18c3c: add             x2, x2, HEAP, lsl #32
    // 0xd18c40: LoadField: r0 = r2->field_b
    //     0xd18c40: ldur            w0, [x2, #0xb]
    // 0xd18c44: DecompressPointer r0
    //     0xd18c44: add             x0, x0, HEAP, lsl #32
    // 0xd18c48: cmp             w0, NULL
    // 0xd18c4c: b.eq            #0xd18ccc
    // 0xd18c50: LoadField: r3 = r0->field_f
    //     0xd18c50: ldur            w3, [x0, #0xf]
    // 0xd18c54: DecompressPointer r3
    //     0xd18c54: add             x3, x3, HEAP, lsl #32
    // 0xd18c58: stur            x3, [fp, #-0x28]
    // 0xd18c5c: LoadField: r7 = r0->field_13
    //     0xd18c5c: ldur            w7, [x0, #0x13]
    // 0xd18c60: DecompressPointer r7
    //     0xd18c60: add             x7, x7, HEAP, lsl #32
    // 0xd18c64: stur            x7, [fp, #-0x20]
    // 0xd18c68: ArrayLoad: r4 = r0[0]  ; List_4
    //     0xd18c68: ldur            w4, [x0, #0x17]
    // 0xd18c6c: DecompressPointer r4
    //     0xd18c6c: add             x4, x4, HEAP, lsl #32
    // 0xd18c70: stur            x4, [fp, #-0x10]
    // 0xd18c74: r1 = Function '_handleDateChanged@75078594':.
    //     0xd18c74: add             x1, PP, #0x99, lsl #12  ; [pp+0x99ce8] AnonymousClosure: (0xd181e8), in [package:flutter/src/material/date_picker.dart] _DatePickerDialogState::_handleDateChanged (0xd18224)
    //     0xd18c78: ldr             x1, [x1, #0xce8]
    // 0xd18c7c: r0 = AllocateClosure()
    //     0xd18c7c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd18c80: stur            x0, [fp, #-0x30]
    // 0xd18c84: r0 = CalendarDatePicker()
    //     0xd18c84: bl              #0xd18e7c  ; AllocateCalendarDatePickerStub -> CalendarDatePicker (size=0x30)
    // 0xd18c88: stur            x0, [fp, #-0x38]
    // 0xd18c8c: ldur            x16, [fp, #-0x30]
    // 0xd18c90: str             x16, [SP]
    // 0xd18c94: mov             x1, x0
    // 0xd18c98: ldur            x2, [fp, #-0x10]
    // 0xd18c9c: ldur            x3, [fp, #-0x28]
    // 0xd18ca0: ldur            x5, [fp, #-0x18]
    // 0xd18ca4: ldur            x6, [fp, #-8]
    // 0xd18ca8: ldur            x7, [fp, #-0x20]
    // 0xd18cac: r0 = CalendarDatePicker()
    //     0xd18cac: bl              #0xd18cd0  ; [package:flutter/src/material/calendar_date_picker.dart] CalendarDatePicker::CalendarDatePicker
    // 0xd18cb0: ldur            x0, [fp, #-0x38]
    // 0xd18cb4: LeaveFrame
    //     0xd18cb4: mov             SP, fp
    //     0xd18cb8: ldp             fp, lr, [SP], #0x10
    // 0xd18cbc: ret
    //     0xd18cbc: ret             
    // 0xd18cc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd18cc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd18cc4: b               #0xd18ba8
    // 0xd18cc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd18cc8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd18ccc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd18ccc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleOk(dynamic) {
    // ** addr: 0xd18e88, size: 0x38
    // 0xd18e88: EnterFrame
    //     0xd18e88: stp             fp, lr, [SP, #-0x10]!
    //     0xd18e8c: mov             fp, SP
    // 0xd18e90: ldr             x0, [fp, #0x10]
    // 0xd18e94: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd18e94: ldur            w1, [x0, #0x17]
    // 0xd18e98: DecompressPointer r1
    //     0xd18e98: add             x1, x1, HEAP, lsl #32
    // 0xd18e9c: CheckStackOverflow
    //     0xd18e9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd18ea0: cmp             SP, x16
    //     0xd18ea4: b.ls            #0xd18eb8
    // 0xd18ea8: r0 = _handleOk()
    //     0xd18ea8: bl              #0xd18ec0  ; [package:flutter/src/material/date_picker.dart] _DatePickerDialogState::_handleOk
    // 0xd18eac: LeaveFrame
    //     0xd18eac: mov             SP, fp
    //     0xd18eb0: ldp             fp, lr, [SP], #0x10
    // 0xd18eb4: ret
    //     0xd18eb4: ret             
    // 0xd18eb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd18eb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd18ebc: b               #0xd18ea8
  }
  _ _handleOk(/* No info */) {
    // ** addr: 0xd18ec0, size: 0x22c
    // 0xd18ec0: EnterFrame
    //     0xd18ec0: stp             fp, lr, [SP, #-0x10]!
    //     0xd18ec4: mov             fp, SP
    // 0xd18ec8: AllocStack(0x38)
    //     0xd18ec8: sub             SP, SP, #0x38
    // 0xd18ecc: SetupParameters(_DatePickerDialogState this /* r1 => r1, fp-0x8 */)
    //     0xd18ecc: stur            x1, [fp, #-8]
    // 0xd18ed0: CheckStackOverflow
    //     0xd18ed0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd18ed4: cmp             SP, x16
    //     0xd18ed8: b.ls            #0xd190dc
    // 0xd18edc: r1 = 1
    //     0xd18edc: mov             x1, #1
    // 0xd18ee0: r0 = AllocateContext()
    //     0xd18ee0: bl              #0x13de838  ; AllocateContextStub
    // 0xd18ee4: mov             x2, x0
    // 0xd18ee8: ldur            x0, [fp, #-8]
    // 0xd18eec: stur            x2, [fp, #-0x10]
    // 0xd18ef0: StoreField: r2->field_f = r0
    //     0xd18ef0: stur            w0, [x2, #0xf]
    // 0xd18ef4: mov             x1, x0
    // 0xd18ef8: LoadField: r0 = r1->field_27
    //     0xd18ef8: ldur            w0, [x1, #0x27]
    // 0xd18efc: DecompressPointer r0
    //     0xd18efc: add             x0, x0, HEAP, lsl #32
    // 0xd18f00: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd18f04: cmp             w0, w16
    // 0xd18f08: b.ne            #0xd18f18
    // 0xd18f0c: r2 = _entryMode
    //     0xd18f0c: add             x2, PP, #0x99, lsl #12  ; [pp+0x99ba8] Field <_DatePickerDialogState@75078594._entryMode@75078594>: late final (offset: 0x28)
    //     0xd18f10: ldr             x2, [x2, #0xba8]
    // 0xd18f14: r0 = InitLateFinalInstanceField()
    //     0xd18f14: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd18f18: mov             x3, x0
    // 0xd18f1c: stur            x3, [fp, #-0x20]
    // 0xd18f20: LoadField: r4 = r3->field_33
    //     0xd18f20: ldur            w4, [x3, #0x33]
    // 0xd18f24: DecompressPointer r4
    //     0xd18f24: add             x4, x4, HEAP, lsl #32
    // 0xd18f28: stur            x4, [fp, #-0x18]
    // 0xd18f2c: cmp             w4, NULL
    // 0xd18f30: b.ne            #0xd18f68
    // 0xd18f34: LoadField: r2 = r3->field_23
    //     0xd18f34: ldur            w2, [x3, #0x23]
    // 0xd18f38: DecompressPointer r2
    //     0xd18f38: add             x2, x2, HEAP, lsl #32
    // 0xd18f3c: mov             x0, x4
    // 0xd18f40: r1 = Null
    //     0xd18f40: mov             x1, NULL
    // 0xd18f44: cmp             w2, NULL
    // 0xd18f48: b.eq            #0xd18f68
    // 0xd18f4c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd18f4c: ldur            w4, [x2, #0x17]
    // 0xd18f50: DecompressPointer r4
    //     0xd18f50: add             x4, x4, HEAP, lsl #32
    // 0xd18f54: r8 = X0
    //     0xd18f54: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd18f58: LoadField: r9 = r4->field_7
    //     0xd18f58: ldur            x9, [x4, #7]
    // 0xd18f5c: r3 = Null
    //     0xd18f5c: add             x3, PP, #0x99, lsl #12  ; [pp+0x99d08] Null
    //     0xd18f60: ldr             x3, [x3, #0xd08]
    // 0xd18f64: blr             x9
    // 0xd18f68: ldur            x3, [fp, #-0x18]
    // 0xd18f6c: r16 = Instance_DatePickerEntryMode
    //     0xd18f6c: add             x16, PP, #0x99, lsl #12  ; [pp+0x99c80] Obj!DatePickerEntryMode@12c58a1
    //     0xd18f70: ldr             x16, [x16, #0xc80]
    // 0xd18f74: cmp             w3, w16
    // 0xd18f78: b.eq            #0xd18fd0
    // 0xd18f7c: cmp             w3, NULL
    // 0xd18f80: b.ne            #0xd18fbc
    // 0xd18f84: ldur            x0, [fp, #-0x20]
    // 0xd18f88: LoadField: r2 = r0->field_23
    //     0xd18f88: ldur            w2, [x0, #0x23]
    // 0xd18f8c: DecompressPointer r2
    //     0xd18f8c: add             x2, x2, HEAP, lsl #32
    // 0xd18f90: mov             x0, x3
    // 0xd18f94: r1 = Null
    //     0xd18f94: mov             x1, NULL
    // 0xd18f98: cmp             w2, NULL
    // 0xd18f9c: b.eq            #0xd18fbc
    // 0xd18fa0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd18fa0: ldur            w4, [x2, #0x17]
    // 0xd18fa4: DecompressPointer r4
    //     0xd18fa4: add             x4, x4, HEAP, lsl #32
    // 0xd18fa8: r8 = X0
    //     0xd18fa8: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd18fac: LoadField: r9 = r4->field_7
    //     0xd18fac: ldur            x9, [x4, #7]
    // 0xd18fb0: r3 = Null
    //     0xd18fb0: add             x3, PP, #0x99, lsl #12  ; [pp+0x99d18] Null
    //     0xd18fb4: ldr             x3, [x3, #0xd18]
    // 0xd18fb8: blr             x9
    // 0xd18fbc: ldur            x0, [fp, #-0x18]
    // 0xd18fc0: r16 = Instance_DatePickerEntryMode
    //     0xd18fc0: add             x16, PP, #0x99, lsl #12  ; [pp+0x99c68] Obj!DatePickerEntryMode@12c5881
    //     0xd18fc4: ldr             x16, [x16, #0xc68]
    // 0xd18fc8: cmp             w0, w16
    // 0xd18fcc: b.ne            #0xd1902c
    // 0xd18fd0: ldur            x0, [fp, #-8]
    // 0xd18fd4: LoadField: r1 = r0->field_33
    //     0xd18fd4: ldur            w1, [x0, #0x33]
    // 0xd18fd8: DecompressPointer r1
    //     0xd18fd8: add             x1, x1, HEAP, lsl #32
    // 0xd18fdc: r0 = currentState()
    //     0xd18fdc: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0xd18fe0: stur            x0, [fp, #-0x18]
    // 0xd18fe4: cmp             w0, NULL
    // 0xd18fe8: b.eq            #0xd190e4
    // 0xd18fec: mov             x1, x0
    // 0xd18ff0: r0 = validate()
    //     0xd18ff0: bl              #0xd19198  ; [package:flutter/src/widgets/form.dart] FormState::validate
    // 0xd18ff4: tbz             w0, #4, #0xd19024
    // 0xd18ff8: ldur            x2, [fp, #-0x10]
    // 0xd18ffc: r1 = Function '<anonymous closure>':.
    //     0xd18ffc: add             x1, PP, #0x99, lsl #12  ; [pp+0x99d28] AnonymousClosure: (0xd19acc), in [package:flutter/src/material/date_picker.dart] _DatePickerDialogState::_handleOk (0xd18ec0)
    //     0xd19000: ldr             x1, [x1, #0xd28]
    // 0xd19004: r0 = AllocateClosure()
    //     0xd19004: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd19008: ldur            x1, [fp, #-8]
    // 0xd1900c: mov             x2, x0
    // 0xd19010: r0 = setState()
    //     0xd19010: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd19014: r0 = Null
    //     0xd19014: mov             x0, NULL
    // 0xd19018: LeaveFrame
    //     0xd19018: mov             SP, fp
    //     0xd1901c: ldp             fp, lr, [SP], #0x10
    // 0xd19020: ret
    //     0xd19020: ret             
    // 0xd19024: ldur            x1, [fp, #-0x18]
    // 0xd19028: r0 = save()
    //     0xd19028: bl              #0xd17d9c  ; [package:flutter/src/widgets/form.dart] FormState::save
    // 0xd1902c: ldur            x1, [fp, #-8]
    // 0xd19030: LoadField: r0 = r1->field_f
    //     0xd19030: ldur            w0, [x1, #0xf]
    // 0xd19034: DecompressPointer r0
    //     0xd19034: add             x0, x0, HEAP, lsl #32
    // 0xd19038: stur            x0, [fp, #-0x10]
    // 0xd1903c: cmp             w0, NULL
    // 0xd19040: b.eq            #0xd190e8
    // 0xd19044: LoadField: r0 = r1->field_23
    //     0xd19044: ldur            w0, [x1, #0x23]
    // 0xd19048: DecompressPointer r0
    //     0xd19048: add             x0, x0, HEAP, lsl #32
    // 0xd1904c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd19050: cmp             w0, w16
    // 0xd19054: b.ne            #0xd19064
    // 0xd19058: r2 = _selectedDate
    //     0xd19058: add             x2, PP, #0x99, lsl #12  ; [pp+0x99c20] Field <_DatePickerDialogState@75078594._selectedDate@75078594>: late final (offset: 0x24)
    //     0xd1905c: ldr             x2, [x2, #0xc20]
    // 0xd19060: r0 = InitLateFinalInstanceField()
    //     0xd19060: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd19064: LoadField: r3 = r0->field_33
    //     0xd19064: ldur            w3, [x0, #0x33]
    // 0xd19068: DecompressPointer r3
    //     0xd19068: add             x3, x3, HEAP, lsl #32
    // 0xd1906c: stur            x3, [fp, #-8]
    // 0xd19070: cmp             w3, NULL
    // 0xd19074: b.ne            #0xd190ac
    // 0xd19078: LoadField: r2 = r0->field_23
    //     0xd19078: ldur            w2, [x0, #0x23]
    // 0xd1907c: DecompressPointer r2
    //     0xd1907c: add             x2, x2, HEAP, lsl #32
    // 0xd19080: mov             x0, x3
    // 0xd19084: r1 = Null
    //     0xd19084: mov             x1, NULL
    // 0xd19088: cmp             w2, NULL
    // 0xd1908c: b.eq            #0xd190ac
    // 0xd19090: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd19090: ldur            w4, [x2, #0x17]
    // 0xd19094: DecompressPointer r4
    //     0xd19094: add             x4, x4, HEAP, lsl #32
    // 0xd19098: r8 = X0
    //     0xd19098: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd1909c: LoadField: r9 = r4->field_7
    //     0xd1909c: ldur            x9, [x4, #7]
    // 0xd190a0: r3 = Null
    //     0xd190a0: add             x3, PP, #0x99, lsl #12  ; [pp+0x99d30] Null
    //     0xd190a4: ldr             x3, [x3, #0xd30]
    // 0xd190a8: blr             x9
    // 0xd190ac: r16 = <DateTime>
    //     0xd190ac: add             x16, PP, #0x14, lsl #12  ; [pp+0x14b10] TypeArguments: <DateTime>
    //     0xd190b0: ldr             x16, [x16, #0xb10]
    // 0xd190b4: ldur            lr, [fp, #-0x10]
    // 0xd190b8: stp             lr, x16, [SP, #8]
    // 0xd190bc: ldur            x16, [fp, #-8]
    // 0xd190c0: str             x16, [SP]
    // 0xd190c4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd190c4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd190c8: r0 = pop()
    //     0xd190c8: bl              #0xd190ec  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0xd190cc: r0 = Null
    //     0xd190cc: mov             x0, NULL
    // 0xd190d0: LeaveFrame
    //     0xd190d0: mov             SP, fp
    //     0xd190d4: ldp             fp, lr, [SP], #0x10
    // 0xd190d8: ret
    //     0xd190d8: ret             
    // 0xd190dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd190dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd190e0: b               #0xd18edc
    // 0xd190e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd190e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd190e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd190e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd19acc, size: 0x58
    // 0xd19acc: EnterFrame
    //     0xd19acc: stp             fp, lr, [SP, #-0x10]!
    //     0xd19ad0: mov             fp, SP
    // 0xd19ad4: ldr             x0, [fp, #0x10]
    // 0xd19ad8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd19ad8: ldur            w1, [x0, #0x17]
    // 0xd19adc: DecompressPointer r1
    //     0xd19adc: add             x1, x1, HEAP, lsl #32
    // 0xd19ae0: CheckStackOverflow
    //     0xd19ae0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd19ae4: cmp             SP, x16
    //     0xd19ae8: b.ls            #0xd19b1c
    // 0xd19aec: LoadField: r0 = r1->field_f
    //     0xd19aec: ldur            w0, [x1, #0xf]
    // 0xd19af0: DecompressPointer r0
    //     0xd19af0: add             x0, x0, HEAP, lsl #32
    // 0xd19af4: LoadField: r1 = r0->field_2b
    //     0xd19af4: ldur            w1, [x0, #0x2b]
    // 0xd19af8: DecompressPointer r1
    //     0xd19af8: add             x1, x1, HEAP, lsl #32
    // 0xd19afc: r2 = Instance_AutovalidateMode
    //     0xd19afc: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fe48] Obj!AutovalidateMode@12c3081
    //     0xd19b00: ldr             x2, [x2, #0xe48]
    // 0xd19b04: r0 = value=()
    //     0xd19b04: bl              #0x86c6b4  ; [package:flutter/src/widgets/restoration_properties.dart] RestorableValue::value=
    // 0xd19b08: r0 = Instance_AutovalidateMode
    //     0xd19b08: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8fe48] Obj!AutovalidateMode@12c3081
    //     0xd19b0c: ldr             x0, [x0, #0xe48]
    // 0xd19b10: LeaveFrame
    //     0xd19b10: mov             SP, fp
    //     0xd19b14: ldp             fp, lr, [SP], #0x10
    // 0xd19b18: ret
    //     0xd19b18: ret             
    // 0xd19b1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd19b1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd19b20: b               #0xd19aec
  }
  [closure] void _handleCancel(dynamic) {
    // ** addr: 0xd19b24, size: 0x38
    // 0xd19b24: EnterFrame
    //     0xd19b24: stp             fp, lr, [SP, #-0x10]!
    //     0xd19b28: mov             fp, SP
    // 0xd19b2c: ldr             x0, [fp, #0x10]
    // 0xd19b30: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd19b30: ldur            w1, [x0, #0x17]
    // 0xd19b34: DecompressPointer r1
    //     0xd19b34: add             x1, x1, HEAP, lsl #32
    // 0xd19b38: CheckStackOverflow
    //     0xd19b38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd19b3c: cmp             SP, x16
    //     0xd19b40: b.ls            #0xd19b54
    // 0xd19b44: r0 = _handleCancel()
    //     0xd19b44: bl              #0xd19b5c  ; [package:flutter/src/material/date_picker.dart] _DatePickerDialogState::_handleCancel
    // 0xd19b48: LeaveFrame
    //     0xd19b48: mov             SP, fp
    //     0xd19b4c: ldp             fp, lr, [SP], #0x10
    // 0xd19b50: ret
    //     0xd19b50: ret             
    // 0xd19b54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd19b54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd19b58: b               #0xd19b44
  }
  _ _handleCancel(/* No info */) {
    // ** addr: 0xd19b5c, size: 0x54
    // 0xd19b5c: EnterFrame
    //     0xd19b5c: stp             fp, lr, [SP, #-0x10]!
    //     0xd19b60: mov             fp, SP
    // 0xd19b64: AllocStack(0x10)
    //     0xd19b64: sub             SP, SP, #0x10
    // 0xd19b68: CheckStackOverflow
    //     0xd19b68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd19b6c: cmp             SP, x16
    //     0xd19b70: b.ls            #0xd19ba4
    // 0xd19b74: LoadField: r0 = r1->field_f
    //     0xd19b74: ldur            w0, [x1, #0xf]
    // 0xd19b78: DecompressPointer r0
    //     0xd19b78: add             x0, x0, HEAP, lsl #32
    // 0xd19b7c: cmp             w0, NULL
    // 0xd19b80: b.eq            #0xd19bac
    // 0xd19b84: r16 = <Object?>
    //     0xd19b84: ldr             x16, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0xd19b88: stp             x0, x16, [SP]
    // 0xd19b8c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd19b8c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd19b90: r0 = pop()
    //     0xd19b90: bl              #0xd190ec  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0xd19b94: r0 = Null
    //     0xd19b94: mov             x0, NULL
    // 0xd19b98: LeaveFrame
    //     0xd19b98: mov             SP, fp
    //     0xd19b9c: ldp             fp, lr, [SP], #0x10
    // 0xd19ba0: ret
    //     0xd19ba0: ret             
    // 0xd19ba4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd19ba4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd19ba8: b               #0xd19b74
    // 0xd19bac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd19bac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _RestorableDatePickerEntryMode _entryMode(_DatePickerDialogState) {
    // ** addr: 0xd19bb0, size: 0xa0
    // 0xd19bb0: EnterFrame
    //     0xd19bb0: stp             fp, lr, [SP, #-0x10]!
    //     0xd19bb4: mov             fp, SP
    // 0xd19bb8: AllocStack(0x8)
    //     0xd19bb8: sub             SP, SP, #8
    // 0xd19bbc: CheckStackOverflow
    //     0xd19bbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd19bc0: cmp             SP, x16
    //     0xd19bc4: b.ls            #0xd19c44
    // 0xd19bc8: ldr             x0, [fp, #0x10]
    // 0xd19bcc: LoadField: r1 = r0->field_b
    //     0xd19bcc: ldur            w1, [x0, #0xb]
    // 0xd19bd0: DecompressPointer r1
    //     0xd19bd0: add             x1, x1, HEAP, lsl #32
    // 0xd19bd4: cmp             w1, NULL
    // 0xd19bd8: b.eq            #0xd19c4c
    // 0xd19bdc: r1 = <DatePickerEntryMode>
    //     0xd19bdc: add             x1, PP, #0x99, lsl #12  ; [pp+0x99d40] TypeArguments: <DatePickerEntryMode>
    //     0xd19be0: ldr             x1, [x1, #0xd40]
    // 0xd19be4: r0 = _RestorableDatePickerEntryMode()
    //     0xd19be4: bl              #0xd19c50  ; Allocate_RestorableDatePickerEntryModeStub -> _RestorableDatePickerEntryMode (size=0x3c)
    // 0xd19be8: mov             x1, x0
    // 0xd19bec: r0 = Instance_DatePickerEntryMode
    //     0xd19bec: add             x0, PP, #0x28, lsl #12  ; [pp+0x28520] Obj!DatePickerEntryMode@12c58c1
    //     0xd19bf0: ldr             x0, [x0, #0x520]
    // 0xd19bf4: stur            x1, [fp, #-8]
    // 0xd19bf8: StoreField: r1->field_37 = r0
    //     0xd19bf8: stur            w0, [x1, #0x37]
    // 0xd19bfc: r0 = false
    //     0xd19bfc: add             x0, NULL, #0x30  ; false
    // 0xd19c00: StoreField: r1->field_27 = r0
    //     0xd19c00: stur            w0, [x1, #0x27]
    // 0xd19c04: StoreField: r1->field_7 = rZR
    //     0xd19c04: stur            xzr, [x1, #7]
    // 0xd19c08: StoreField: r1->field_13 = rZR
    //     0xd19c08: stur            xzr, [x1, #0x13]
    // 0xd19c0c: StoreField: r1->field_1b = rZR
    //     0xd19c0c: stur            xzr, [x1, #0x1b]
    // 0xd19c10: r0 = LoadStaticField(0x45c)
    //     0xd19c10: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd19c14: ldr             x0, [x0, #0x8b8]
    // 0xd19c18: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd19c1c: cmp             w0, w16
    // 0xd19c20: b.ne            #0xd19c2c
    // 0xd19c24: r2 = _emptyListeners
    //     0xd19c24: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xd19c28: r0 = InitLateFinalStaticField()
    //     0xd19c28: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd19c2c: mov             x1, x0
    // 0xd19c30: ldur            x0, [fp, #-8]
    // 0xd19c34: StoreField: r0->field_f = r1
    //     0xd19c34: stur            w1, [x0, #0xf]
    // 0xd19c38: LeaveFrame
    //     0xd19c38: mov             SP, fp
    //     0xd19c3c: ldp             fp, lr, [SP], #0x10
    // 0xd19c40: ret
    //     0xd19c40: ret             
    // 0xd19c44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd19c44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd19c48: b               #0xd19bc8
    // 0xd19c4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd19c4c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _DatePickerDialogState(/* No info */) {
    // ** addr: 0xfa1294, size: 0x150
    // 0xfa1294: EnterFrame
    //     0xfa1294: stp             fp, lr, [SP, #-0x10]!
    //     0xfa1298: mov             fp, SP
    // 0xfa129c: AllocStack(0x20)
    //     0xfa129c: sub             SP, SP, #0x20
    // 0xfa12a0: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa12a4: mov             x2, x1
    // 0xfa12a8: stur            x1, [fp, #-8]
    // 0xfa12ac: CheckStackOverflow
    //     0xfa12ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa12b0: cmp             SP, x16
    //     0xfa12b4: b.ls            #0xfa13dc
    // 0xfa12b8: StoreField: r2->field_23 = r0
    //     0xfa12b8: stur            w0, [x2, #0x23]
    // 0xfa12bc: StoreField: r2->field_27 = r0
    //     0xfa12bc: stur            w0, [x2, #0x27]
    // 0xfa12c0: r1 = <AutovalidateMode>
    //     0xfa12c0: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8ff28] TypeArguments: <AutovalidateMode>
    //     0xfa12c4: ldr             x1, [x1, #0xf28]
    // 0xfa12c8: r0 = _RestorableAutovalidateMode()
    //     0xfa12c8: bl              #0xfa13e4  ; Allocate_RestorableAutovalidateModeStub -> _RestorableAutovalidateMode (size=0x3c)
    // 0xfa12cc: mov             x1, x0
    // 0xfa12d0: r0 = Instance_AutovalidateMode
    //     0xfa12d0: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a608] Obj!AutovalidateMode@12c3061
    //     0xfa12d4: ldr             x0, [x0, #0x608]
    // 0xfa12d8: stur            x1, [fp, #-0x10]
    // 0xfa12dc: StoreField: r1->field_37 = r0
    //     0xfa12dc: stur            w0, [x1, #0x37]
    // 0xfa12e0: r0 = false
    //     0xfa12e0: add             x0, NULL, #0x30  ; false
    // 0xfa12e4: StoreField: r1->field_27 = r0
    //     0xfa12e4: stur            w0, [x1, #0x27]
    // 0xfa12e8: StoreField: r1->field_7 = rZR
    //     0xfa12e8: stur            xzr, [x1, #7]
    // 0xfa12ec: StoreField: r1->field_13 = rZR
    //     0xfa12ec: stur            xzr, [x1, #0x13]
    // 0xfa12f0: StoreField: r1->field_1b = rZR
    //     0xfa12f0: stur            xzr, [x1, #0x1b]
    // 0xfa12f4: r0 = LoadStaticField(0x45c)
    //     0xfa12f4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfa12f8: ldr             x0, [x0, #0x8b8]
    // 0xfa12fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa1300: cmp             w0, w16
    // 0xfa1304: b.ne            #0xfa1310
    // 0xfa1308: r2 = _emptyListeners
    //     0xfa1308: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xfa130c: r0 = InitLateFinalStaticField()
    //     0xfa130c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xfa1310: mov             x1, x0
    // 0xfa1314: ldur            x0, [fp, #-0x10]
    // 0xfa1318: StoreField: r0->field_f = r1
    //     0xfa1318: stur            w1, [x0, #0xf]
    // 0xfa131c: ldur            x2, [fp, #-8]
    // 0xfa1320: StoreField: r2->field_2b = r0
    //     0xfa1320: stur            w0, [x2, #0x2b]
    //     0xfa1324: ldurb           w16, [x2, #-1]
    //     0xfa1328: ldurb           w17, [x0, #-1]
    //     0xfa132c: and             x16, x17, x16, lsr #2
    //     0xfa1330: tst             x16, HEAP, lsr #32
    //     0xfa1334: b.eq            #0xfa133c
    //     0xfa1338: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfa133c: r1 = <State<StatefulWidget>>
    //     0xfa133c: ldr             x1, [PP, #0x4df8]  ; [pp+0x4df8] TypeArguments: <State<StatefulWidget>>
    // 0xfa1340: r0 = LabeledGlobalKey()
    //     0xfa1340: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa1344: ldur            x2, [fp, #-8]
    // 0xfa1348: StoreField: r2->field_2f = r0
    //     0xfa1348: stur            w0, [x2, #0x2f]
    //     0xfa134c: ldurb           w16, [x2, #-1]
    //     0xfa1350: ldurb           w17, [x0, #-1]
    //     0xfa1354: and             x16, x17, x16, lsr #2
    //     0xfa1358: tst             x16, HEAP, lsr #32
    //     0xfa135c: b.eq            #0xfa1364
    //     0xfa1360: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfa1364: r1 = <FormState>
    //     0xfa1364: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8ff30] TypeArguments: <FormState>
    //     0xfa1368: ldr             x1, [x1, #0xf30]
    // 0xfa136c: r0 = LabeledGlobalKey()
    //     0xfa136c: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa1370: ldur            x1, [fp, #-8]
    // 0xfa1374: StoreField: r1->field_33 = r0
    //     0xfa1374: stur            w0, [x1, #0x33]
    //     0xfa1378: ldurb           w16, [x1, #-1]
    //     0xfa137c: ldurb           w17, [x0, #-1]
    //     0xfa1380: and             x16, x17, x16, lsr #2
    //     0xfa1384: tst             x16, HEAP, lsr #32
    //     0xfa1388: b.eq            #0xfa1390
    //     0xfa138c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa1390: r0 = true
    //     0xfa1390: add             x0, NULL, #0x20  ; true
    // 0xfa1394: StoreField: r1->field_1b = r0
    //     0xfa1394: stur            w0, [x1, #0x1b]
    // 0xfa1398: r16 = <RestorableProperty<Object?>, (dynamic this) => void?>
    //     0xfa1398: add             x16, PP, #0x26, lsl #12  ; [pp+0x26c60] TypeArguments: <RestorableProperty<Object?>, (dynamic this) => void?>
    //     0xfa139c: ldr             x16, [x16, #0xc60]
    // 0xfa13a0: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xfa13a4: stp             lr, x16, [SP]
    // 0xfa13a8: r0 = Map._fromLiteral()
    //     0xfa13a8: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xfa13ac: ldur            x1, [fp, #-8]
    // 0xfa13b0: ArrayStore: r1[0] = r0  ; List_4
    //     0xfa13b0: stur            w0, [x1, #0x17]
    //     0xfa13b4: ldurb           w16, [x1, #-1]
    //     0xfa13b8: ldurb           w17, [x0, #-1]
    //     0xfa13bc: and             x16, x17, x16, lsr #2
    //     0xfa13c0: tst             x16, HEAP, lsr #32
    //     0xfa13c4: b.eq            #0xfa13cc
    //     0xfa13c8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa13cc: r0 = Null
    //     0xfa13cc: mov             x0, NULL
    // 0xfa13d0: LeaveFrame
    //     0xfa13d0: mov             SP, fp
    //     0xfa13d4: ldp             fp, lr, [SP], #0x10
    // 0xfa13d8: ret
    //     0xfa13d8: ret             
    // 0xfa13dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa13dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa13e0: b               #0xfa12b8
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10dc658, size: 0xa8
    // 0x10dc658: EnterFrame
    //     0x10dc658: stp             fp, lr, [SP, #-0x10]!
    //     0x10dc65c: mov             fp, SP
    // 0x10dc660: AllocStack(0x8)
    //     0x10dc660: sub             SP, SP, #8
    // 0x10dc664: SetupParameters(_DatePickerDialogState this /* r1 => r0, fp-0x8 */)
    //     0x10dc664: mov             x0, x1
    //     0x10dc668: stur            x1, [fp, #-8]
    // 0x10dc66c: CheckStackOverflow
    //     0x10dc66c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10dc670: cmp             SP, x16
    //     0x10dc674: b.ls            #0x10dc6f8
    // 0x10dc678: mov             x1, x0
    // 0x10dc67c: LoadField: r0 = r1->field_23
    //     0x10dc67c: ldur            w0, [x1, #0x23]
    // 0x10dc680: DecompressPointer r0
    //     0x10dc680: add             x0, x0, HEAP, lsl #32
    // 0x10dc684: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10dc688: cmp             w0, w16
    // 0x10dc68c: b.ne            #0x10dc69c
    // 0x10dc690: r2 = _selectedDate
    //     0x10dc690: add             x2, PP, #0x99, lsl #12  ; [pp+0x99c20] Field <_DatePickerDialogState@75078594._selectedDate@75078594>: late final (offset: 0x24)
    //     0x10dc694: ldr             x2, [x2, #0xc20]
    // 0x10dc698: r0 = InitLateFinalInstanceField()
    //     0x10dc698: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x10dc69c: mov             x1, x0
    // 0x10dc6a0: r0 = dispose()
    //     0x10dc6a0: bl              #0x10ef0d0  ; [package:flutter/src/widgets/restoration.dart] RestorableProperty::dispose
    // 0x10dc6a4: ldur            x1, [fp, #-8]
    // 0x10dc6a8: LoadField: r0 = r1->field_27
    //     0x10dc6a8: ldur            w0, [x1, #0x27]
    // 0x10dc6ac: DecompressPointer r0
    //     0x10dc6ac: add             x0, x0, HEAP, lsl #32
    // 0x10dc6b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10dc6b4: cmp             w0, w16
    // 0x10dc6b8: b.ne            #0x10dc6c8
    // 0x10dc6bc: r2 = _entryMode
    //     0x10dc6bc: add             x2, PP, #0x99, lsl #12  ; [pp+0x99ba8] Field <_DatePickerDialogState@75078594._entryMode@75078594>: late final (offset: 0x28)
    //     0x10dc6c0: ldr             x2, [x2, #0xba8]
    // 0x10dc6c4: r0 = InitLateFinalInstanceField()
    //     0x10dc6c4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x10dc6c8: mov             x1, x0
    // 0x10dc6cc: r0 = dispose()
    //     0x10dc6cc: bl              #0x10ef0d0  ; [package:flutter/src/widgets/restoration.dart] RestorableProperty::dispose
    // 0x10dc6d0: ldur            x0, [fp, #-8]
    // 0x10dc6d4: LoadField: r1 = r0->field_2b
    //     0x10dc6d4: ldur            w1, [x0, #0x2b]
    // 0x10dc6d8: DecompressPointer r1
    //     0x10dc6d8: add             x1, x1, HEAP, lsl #32
    // 0x10dc6dc: r0 = dispose()
    //     0x10dc6dc: bl              #0x10ef0d0  ; [package:flutter/src/widgets/restoration.dart] RestorableProperty::dispose
    // 0x10dc6e0: ldur            x1, [fp, #-8]
    // 0x10dc6e4: r0 = dispose()
    //     0x10dc6e4: bl              #0x10dc700  ; [dart:mixin_deduplication] _MixinApplication31&State&RestorationMixin::dispose
    // 0x10dc6e8: r0 = Null
    //     0x10dc6e8: mov             x0, NULL
    // 0x10dc6ec: LeaveFrame
    //     0x10dc6ec: mov             SP, fp
    //     0x10dc6f0: ldp             fp, lr, [SP], #0x10
    // 0x10dc6f4: ret
    //     0x10dc6f4: ret             
    // 0x10dc6f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dc6f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dc6fc: b               #0x10dc678
  }
  _ restoreState(/* No info */) {
    // ** addr: 0x1196690, size: 0xc4
    // 0x1196690: EnterFrame
    //     0x1196690: stp             fp, lr, [SP, #-0x10]!
    //     0x1196694: mov             fp, SP
    // 0x1196698: AllocStack(0x8)
    //     0x1196698: sub             SP, SP, #8
    // 0x119669c: SetupParameters(_DatePickerDialogState this /* r1 => r0, fp-0x8 */)
    //     0x119669c: mov             x0, x1
    //     0x11966a0: stur            x1, [fp, #-8]
    // 0x11966a4: CheckStackOverflow
    //     0x11966a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11966a8: cmp             SP, x16
    //     0x11966ac: b.ls            #0x119674c
    // 0x11966b0: mov             x1, x0
    // 0x11966b4: LoadField: r0 = r1->field_23
    //     0x11966b4: ldur            w0, [x1, #0x23]
    // 0x11966b8: DecompressPointer r0
    //     0x11966b8: add             x0, x0, HEAP, lsl #32
    // 0x11966bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11966c0: cmp             w0, w16
    // 0x11966c4: b.ne            #0x11966d4
    // 0x11966c8: r2 = _selectedDate
    //     0x11966c8: add             x2, PP, #0x99, lsl #12  ; [pp+0x99c20] Field <_DatePickerDialogState@75078594._selectedDate@75078594>: late final (offset: 0x24)
    //     0x11966cc: ldr             x2, [x2, #0xc20]
    // 0x11966d0: r0 = InitLateFinalInstanceField()
    //     0x11966d0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11966d4: ldur            x1, [fp, #-8]
    // 0x11966d8: mov             x2, x0
    // 0x11966dc: r3 = "selected_date"
    //     0x11966dc: add             x3, PP, #0x9b, lsl #12  ; [pp+0x9b620] "selected_date"
    //     0x11966e0: ldr             x3, [x3, #0x620]
    // 0x11966e4: r0 = registerForRestoration()
    //     0x11966e4: bl              #0x1196754  ; [dart:mixin_deduplication] _MixinApplication31&State&RestorationMixin::registerForRestoration
    // 0x11966e8: ldur            x0, [fp, #-8]
    // 0x11966ec: LoadField: r2 = r0->field_2b
    //     0x11966ec: ldur            w2, [x0, #0x2b]
    // 0x11966f0: DecompressPointer r2
    //     0x11966f0: add             x2, x2, HEAP, lsl #32
    // 0x11966f4: mov             x1, x0
    // 0x11966f8: r3 = "autovalidateMode"
    //     0x11966f8: add             x3, PP, #0x9b, lsl #12  ; [pp+0x9b628] "autovalidateMode"
    //     0x11966fc: ldr             x3, [x3, #0x628]
    // 0x1196700: r0 = registerForRestoration()
    //     0x1196700: bl              #0x1196754  ; [dart:mixin_deduplication] _MixinApplication31&State&RestorationMixin::registerForRestoration
    // 0x1196704: ldur            x1, [fp, #-8]
    // 0x1196708: LoadField: r0 = r1->field_27
    //     0x1196708: ldur            w0, [x1, #0x27]
    // 0x119670c: DecompressPointer r0
    //     0x119670c: add             x0, x0, HEAP, lsl #32
    // 0x1196710: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1196714: cmp             w0, w16
    // 0x1196718: b.ne            #0x1196728
    // 0x119671c: r2 = _entryMode
    //     0x119671c: add             x2, PP, #0x99, lsl #12  ; [pp+0x99ba8] Field <_DatePickerDialogState@75078594._entryMode@75078594>: late final (offset: 0x28)
    //     0x1196720: ldr             x2, [x2, #0xba8]
    // 0x1196724: r0 = InitLateFinalInstanceField()
    //     0x1196724: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1196728: ldur            x1, [fp, #-8]
    // 0x119672c: mov             x2, x0
    // 0x1196730: r3 = "calendar_entry_mode"
    //     0x1196730: add             x3, PP, #0x9b, lsl #12  ; [pp+0x9b630] "calendar_entry_mode"
    //     0x1196734: ldr             x3, [x3, #0x630]
    // 0x1196738: r0 = registerForRestoration()
    //     0x1196738: bl              #0x1196754  ; [dart:mixin_deduplication] _MixinApplication31&State&RestorationMixin::registerForRestoration
    // 0x119673c: r0 = Null
    //     0x119673c: mov             x0, NULL
    // 0x1196740: LeaveFrame
    //     0x1196740: mov             SP, fp
    //     0x1196744: ldp             fp, lr, [SP], #0x10
    // 0x1196748: ret
    //     0x1196748: ret             
    // 0x119674c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119674c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1196750: b               #0x11966b0
  }
}

// class id: 6169, size: 0x28, field offset: 0xc
//   const constructor, 
class _DatePickerHeader extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfb6270, size: 0xd6c
    // 0xfb6270: EnterFrame
    //     0xfb6270: stp             fp, lr, [SP, #-0x10]!
    //     0xfb6274: mov             fp, SP
    // 0xfb6278: AllocStack(0x88)
    //     0xfb6278: sub             SP, SP, #0x88
    // 0xfb627c: SetupParameters(_DatePickerHeader this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfb627c: mov             x0, x2
    //     0xfb6280: stur            x2, [fp, #-0x10]
    //     0xfb6284: mov             x2, x1
    //     0xfb6288: stur            x1, [fp, #-8]
    // 0xfb628c: CheckStackOverflow
    //     0xfb628c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb6290: cmp             SP, x16
    //     0xfb6294: b.ls            #0xfb6f94
    // 0xfb6298: mov             x1, x0
    // 0xfb629c: r0 = of()
    //     0xfb629c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb62a0: ldur            x1, [fp, #-0x10]
    // 0xfb62a4: stur            x0, [fp, #-0x18]
    // 0xfb62a8: r0 = of()
    //     0xfb62a8: bl              #0xd0ff6c  ; [package:flutter/src/material/date_picker_theme.dart] DatePickerTheme::of
    // 0xfb62ac: ldur            x1, [fp, #-0x10]
    // 0xfb62b0: stur            x0, [fp, #-0x20]
    // 0xfb62b4: r0 = defaults()
    //     0xfb62b4: bl              #0xd0fd74  ; [package:flutter/src/material/date_picker_theme.dart] DatePickerTheme::defaults
    // 0xfb62b8: stur            x0, [fp, #-0x30]
    // 0xfb62bc: r2 = LoadClassIdInstr(r0)
    //     0xfb62bc: ldur            x2, [x0, #-1]
    //     0xfb62c0: ubfx            x2, x2, #0xc, #0x14
    // 0xfb62c4: stur            x2, [fp, #-0x28]
    // 0xfb62c8: r17 = 5167
    //     0xfb62c8: mov             x17, #0x142f
    // 0xfb62cc: cmp             x2, x17
    // 0xfb62d0: b.ne            #0xfb62e4
    // 0xfb62d4: LoadField: r1 = r0->field_1b
    //     0xfb62d4: ldur            w1, [x0, #0x1b]
    // 0xfb62d8: DecompressPointer r1
    //     0xfb62d8: add             x1, x1, HEAP, lsl #32
    // 0xfb62dc: mov             x2, x1
    // 0xfb62e0: b               #0xfb638c
    // 0xfb62e4: r17 = 5168
    //     0xfb62e4: mov             x17, #0x1430
    // 0xfb62e8: cmp             x2, x17
    // 0xfb62ec: b.ne            #0xfb62fc
    // 0xfb62f0: r2 = Instance_Color
    //     0xfb62f0: add             x2, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xfb62f4: ldr             x2, [x2, #0x810]
    // 0xfb62f8: b               #0xfb638c
    // 0xfb62fc: mov             x1, x0
    // 0xfb6300: LoadField: r0 = r1->field_bb
    //     0xfb6300: ldur            w0, [x1, #0xbb]
    // 0xfb6304: DecompressPointer r0
    //     0xfb6304: add             x0, x0, HEAP, lsl #32
    // 0xfb6308: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb630c: cmp             w0, w16
    // 0xfb6310: b.ne            #0xfb6320
    // 0xfb6314: r2 = _isDark
    //     0xfb6314: add             x2, PP, #0x26, lsl #12  ; [pp+0x26408] Field <_DatePickerDefaultsM2@738353974._isDark@738353974>: late final (offset: 0xbc)
    //     0xfb6318: ldr             x2, [x2, #0x408]
    // 0xfb631c: r0 = InitLateFinalInstanceField()
    //     0xfb631c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfb6320: tbnz            w0, #4, #0xfb6358
    // 0xfb6324: ldur            x1, [fp, #-0x30]
    // 0xfb6328: LoadField: r0 = r1->field_b3
    //     0xfb6328: ldur            w0, [x1, #0xb3]
    // 0xfb632c: DecompressPointer r0
    //     0xfb632c: add             x0, x0, HEAP, lsl #32
    // 0xfb6330: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb6334: cmp             w0, w16
    // 0xfb6338: b.ne            #0xfb6348
    // 0xfb633c: r2 = _colors
    //     0xfb633c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xfb6340: ldr             x2, [x2, #0x410]
    // 0xfb6344: r0 = InitLateFinalInstanceField()
    //     0xfb6344: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfb6348: LoadField: r1 = r0->field_7b
    //     0xfb6348: ldur            w1, [x0, #0x7b]
    // 0xfb634c: DecompressPointer r1
    //     0xfb634c: add             x1, x1, HEAP, lsl #32
    // 0xfb6350: mov             x0, x1
    // 0xfb6354: b               #0xfb6388
    // 0xfb6358: ldur            x1, [fp, #-0x30]
    // 0xfb635c: LoadField: r0 = r1->field_b3
    //     0xfb635c: ldur            w0, [x1, #0xb3]
    // 0xfb6360: DecompressPointer r0
    //     0xfb6360: add             x0, x0, HEAP, lsl #32
    // 0xfb6364: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb6368: cmp             w0, w16
    // 0xfb636c: b.ne            #0xfb637c
    // 0xfb6370: r2 = _colors
    //     0xfb6370: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xfb6374: ldr             x2, [x2, #0x410]
    // 0xfb6378: r0 = InitLateFinalInstanceField()
    //     0xfb6378: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfb637c: LoadField: r1 = r0->field_b
    //     0xfb637c: ldur            w1, [x0, #0xb]
    // 0xfb6380: DecompressPointer r1
    //     0xfb6380: add             x1, x1, HEAP, lsl #32
    // 0xfb6384: mov             x0, x1
    // 0xfb6388: mov             x2, x0
    // 0xfb638c: ldur            x0, [fp, #-0x20]
    // 0xfb6390: stur            x2, [fp, #-0x38]
    // 0xfb6394: LoadField: r1 = r0->field_1f
    //     0xfb6394: ldur            w1, [x0, #0x1f]
    // 0xfb6398: DecompressPointer r1
    //     0xfb6398: add             x1, x1, HEAP, lsl #32
    // 0xfb639c: cmp             w1, NULL
    // 0xfb63a0: b.ne            #0xfb64b8
    // 0xfb63a4: ldur            x0, [fp, #-0x28]
    // 0xfb63a8: r17 = 5167
    //     0xfb63a8: mov             x17, #0x142f
    // 0xfb63ac: cmp             x0, x17
    // 0xfb63b0: b.ne            #0xfb63c8
    // 0xfb63b4: ldur            x3, [fp, #-0x30]
    // 0xfb63b8: LoadField: r1 = r3->field_1f
    //     0xfb63b8: ldur            w1, [x3, #0x1f]
    // 0xfb63bc: DecompressPointer r1
    //     0xfb63bc: add             x1, x1, HEAP, lsl #32
    // 0xfb63c0: mov             x0, x1
    // 0xfb63c4: b               #0xfb64b0
    // 0xfb63c8: ldur            x3, [fp, #-0x30]
    // 0xfb63cc: r17 = 5168
    //     0xfb63cc: mov             x17, #0x1430
    // 0xfb63d0: cmp             x0, x17
    // 0xfb63d4: b.ne            #0xfb6424
    // 0xfb63d8: mov             x1, x3
    // 0xfb63dc: LoadField: r0 = r1->field_b3
    //     0xfb63dc: ldur            w0, [x1, #0xb3]
    // 0xfb63e0: DecompressPointer r0
    //     0xfb63e0: add             x0, x0, HEAP, lsl #32
    // 0xfb63e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb63e8: cmp             w0, w16
    // 0xfb63ec: b.ne            #0xfb63fc
    // 0xfb63f0: r2 = _colors
    //     0xfb63f0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xfb63f4: ldr             x2, [x2, #0x400]
    // 0xfb63f8: r0 = InitLateFinalInstanceField()
    //     0xfb63f8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfb63fc: LoadField: r1 = r0->field_a3
    //     0xfb63fc: ldur            w1, [x0, #0xa3]
    // 0xfb6400: DecompressPointer r1
    //     0xfb6400: add             x1, x1, HEAP, lsl #32
    // 0xfb6404: cmp             w1, NULL
    // 0xfb6408: b.ne            #0xfb641c
    // 0xfb640c: LoadField: r1 = r0->field_7f
    //     0xfb640c: ldur            w1, [x0, #0x7f]
    // 0xfb6410: DecompressPointer r1
    //     0xfb6410: add             x1, x1, HEAP, lsl #32
    // 0xfb6414: mov             x0, x1
    // 0xfb6418: b               #0xfb64b0
    // 0xfb641c: mov             x0, x1
    // 0xfb6420: b               #0xfb64b0
    // 0xfb6424: ldur            x1, [fp, #-0x30]
    // 0xfb6428: LoadField: r0 = r1->field_bb
    //     0xfb6428: ldur            w0, [x1, #0xbb]
    // 0xfb642c: DecompressPointer r0
    //     0xfb642c: add             x0, x0, HEAP, lsl #32
    // 0xfb6430: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb6434: cmp             w0, w16
    // 0xfb6438: b.ne            #0xfb6448
    // 0xfb643c: r2 = _isDark
    //     0xfb643c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26408] Field <_DatePickerDefaultsM2@738353974._isDark@738353974>: late final (offset: 0xbc)
    //     0xfb6440: ldr             x2, [x2, #0x408]
    // 0xfb6444: r0 = InitLateFinalInstanceField()
    //     0xfb6444: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfb6448: tbnz            w0, #4, #0xfb6480
    // 0xfb644c: ldur            x1, [fp, #-0x30]
    // 0xfb6450: LoadField: r0 = r1->field_b3
    //     0xfb6450: ldur            w0, [x1, #0xb3]
    // 0xfb6454: DecompressPointer r0
    //     0xfb6454: add             x0, x0, HEAP, lsl #32
    // 0xfb6458: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb645c: cmp             w0, w16
    // 0xfb6460: b.ne            #0xfb6470
    // 0xfb6464: r2 = _colors
    //     0xfb6464: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xfb6468: ldr             x2, [x2, #0x410]
    // 0xfb646c: r0 = InitLateFinalInstanceField()
    //     0xfb646c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfb6470: LoadField: r1 = r0->field_7f
    //     0xfb6470: ldur            w1, [x0, #0x7f]
    // 0xfb6474: DecompressPointer r1
    //     0xfb6474: add             x1, x1, HEAP, lsl #32
    // 0xfb6478: mov             x0, x1
    // 0xfb647c: b               #0xfb64b0
    // 0xfb6480: ldur            x1, [fp, #-0x30]
    // 0xfb6484: LoadField: r0 = r1->field_b3
    //     0xfb6484: ldur            w0, [x1, #0xb3]
    // 0xfb6488: DecompressPointer r0
    //     0xfb6488: add             x0, x0, HEAP, lsl #32
    // 0xfb648c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb6490: cmp             w0, w16
    // 0xfb6494: b.ne            #0xfb64a4
    // 0xfb6498: r2 = _colors
    //     0xfb6498: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xfb649c: ldr             x2, [x2, #0x410]
    // 0xfb64a0: r0 = InitLateFinalInstanceField()
    //     0xfb64a0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfb64a4: LoadField: r1 = r0->field_f
    //     0xfb64a4: ldur            w1, [x0, #0xf]
    // 0xfb64a8: DecompressPointer r1
    //     0xfb64a8: add             x1, x1, HEAP, lsl #32
    // 0xfb64ac: mov             x0, x1
    // 0xfb64b0: mov             x2, x0
    // 0xfb64b4: b               #0xfb64bc
    // 0xfb64b8: mov             x2, x1
    // 0xfb64bc: ldur            x0, [fp, #-0x28]
    // 0xfb64c0: stur            x2, [fp, #-0x20]
    // 0xfb64c4: r17 = 5167
    //     0xfb64c4: mov             x17, #0x142f
    // 0xfb64c8: cmp             x0, x17
    // 0xfb64cc: b.ne            #0xfb64e4
    // 0xfb64d0: ldur            x1, [fp, #-0x30]
    // 0xfb64d4: LoadField: r0 = r1->field_27
    //     0xfb64d4: ldur            w0, [x1, #0x27]
    // 0xfb64d8: DecompressPointer r0
    //     0xfb64d8: add             x0, x0, HEAP, lsl #32
    // 0xfb64dc: mov             x1, x0
    // 0xfb64e0: b               #0xfb6548
    // 0xfb64e4: ldur            x1, [fp, #-0x30]
    // 0xfb64e8: r17 = 5168
    //     0xfb64e8: mov             x17, #0x1430
    // 0xfb64ec: cmp             x0, x17
    // 0xfb64f0: b.ne            #0xfb6520
    // 0xfb64f4: LoadField: r0 = r1->field_b7
    //     0xfb64f4: ldur            w0, [x1, #0xb7]
    // 0xfb64f8: DecompressPointer r0
    //     0xfb64f8: add             x0, x0, HEAP, lsl #32
    // 0xfb64fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb6500: cmp             w0, w16
    // 0xfb6504: b.ne            #0xfb6514
    // 0xfb6508: r2 = _textTheme
    //     0xfb6508: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0xfb650c: ldr             x2, [x2, #0x418]
    // 0xfb6510: r0 = InitLateFinalInstanceField()
    //     0xfb6510: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfb6514: LoadField: r1 = r0->field_37
    //     0xfb6514: ldur            w1, [x0, #0x37]
    // 0xfb6518: DecompressPointer r1
    //     0xfb6518: add             x1, x1, HEAP, lsl #32
    // 0xfb651c: b               #0xfb6548
    // 0xfb6520: LoadField: r0 = r1->field_b7
    //     0xfb6520: ldur            w0, [x1, #0xb7]
    // 0xfb6524: DecompressPointer r0
    //     0xfb6524: add             x0, x0, HEAP, lsl #32
    // 0xfb6528: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb652c: cmp             w0, w16
    // 0xfb6530: b.ne            #0xfb6540
    // 0xfb6534: r2 = _textTheme
    //     0xfb6534: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0xfb6538: ldr             x2, [x2, #0x420]
    // 0xfb653c: r0 = InitLateFinalInstanceField()
    //     0xfb653c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfb6540: LoadField: r1 = r0->field_3f
    //     0xfb6540: ldur            w1, [x0, #0x3f]
    // 0xfb6544: DecompressPointer r1
    //     0xfb6544: add             x1, x1, HEAP, lsl #32
    // 0xfb6548: cmp             w1, NULL
    // 0xfb654c: b.ne            #0xfb6558
    // 0xfb6550: r2 = Null
    //     0xfb6550: mov             x2, NULL
    // 0xfb6554: b               #0xfb6570
    // 0xfb6558: ldur            x16, [fp, #-0x20]
    // 0xfb655c: str             x16, [SP]
    // 0xfb6560: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xfb6560: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xfb6564: ldr             x4, [x4, #0x7f0]
    // 0xfb6568: r0 = copyWith()
    //     0xfb6568: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xfb656c: mov             x2, x0
    // 0xfb6570: ldur            x0, [fp, #-8]
    // 0xfb6574: ldur            x1, [fp, #-0x10]
    // 0xfb6578: stur            x2, [fp, #-0x20]
    // 0xfb657c: r0 = textScalerOf()
    //     0xfb657c: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0xfb6580: r1 = LoadClassIdInstr(r0)
    //     0xfb6580: ldur            x1, [x0, #-1]
    //     0xfb6584: ubfx            x1, x1, #0xc, #0x14
    // 0xfb6588: mov             x16, x0
    // 0xfb658c: mov             x0, x1
    // 0xfb6590: mov             x1, x16
    // 0xfb6594: d0 = 14.000000
    //     0xfb6594: fmov            d0, #14.00000000
    // 0xfb6598: r0 = GDT[cid_x0 + -0x1000]()
    //     0xfb6598: sub             lr, x0, #1, lsl #12
    //     0xfb659c: ldr             lr, [x21, lr, lsl #3]
    //     0xfb65a0: blr             lr
    // 0xfb65a4: LoadField: d0 = r0->field_7
    //     0xfb65a4: ldur            d0, [x0, #7]
    // 0xfb65a8: d1 = 14.000000
    //     0xfb65a8: fmov            d1, #14.00000000
    // 0xfb65ac: fdiv            d2, d0, d1
    // 0xfb65b0: ldur            x0, [fp, #-8]
    // 0xfb65b4: LoadField: r2 = r0->field_23
    //     0xfb65b4: ldur            w2, [x0, #0x23]
    // 0xfb65b8: DecompressPointer r2
    //     0xfb65b8: add             x2, x2, HEAP, lsl #32
    // 0xfb65bc: stur            x2, [fp, #-0x30]
    // 0xfb65c0: cmp             w2, NULL
    // 0xfb65c4: b.eq            #0xfb65d4
    // 0xfb65c8: d0 = 1.400000
    //     0xfb65c8: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1f1f8] IMM: double(1.4) from 0x3ff6666666666666
    //     0xfb65cc: ldr             d0, [x17, #0x1f8]
    // 0xfb65d0: b               #0xfb65dc
    // 0xfb65d4: d0 = 1.600000
    //     0xfb65d4: add             x17, PP, #0x99, lsl #12  ; [pp+0x99bc0] IMM: double(1.6) from 0x3ff999999999999a
    //     0xfb65d8: ldr             d0, [x17, #0xbc0]
    // 0xfb65dc: fmin            v3.2d, v2.2d, v0.2d
    // 0xfb65e0: ldur            x1, [fp, #-0x10]
    // 0xfb65e4: stur            d3, [fp, #-0x70]
    // 0xfb65e8: r0 = textScalerOf()
    //     0xfb65e8: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0xfb65ec: r1 = LoadClassIdInstr(r0)
    //     0xfb65ec: ldur            x1, [x0, #-1]
    //     0xfb65f0: ubfx            x1, x1, #0xc, #0x14
    // 0xfb65f4: mov             x16, x0
    // 0xfb65f8: mov             x0, x1
    // 0xfb65fc: mov             x1, x16
    // 0xfb6600: ldur            d0, [fp, #-0x70]
    // 0xfb6604: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xfb6604: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xfb6608: r0 = GDT[cid_x0 + -0xffa]()
    //     0xfb6608: sub             lr, x0, #0xffa
    //     0xfb660c: ldr             lr, [x21, lr, lsl #3]
    //     0xfb6610: blr             lr
    // 0xfb6614: r1 = LoadClassIdInstr(r0)
    //     0xfb6614: ldur            x1, [x0, #-1]
    //     0xfb6618: ubfx            x1, x1, #0xc, #0x14
    // 0xfb661c: mov             x16, x0
    // 0xfb6620: mov             x0, x1
    // 0xfb6624: mov             x1, x16
    // 0xfb6628: d0 = 14.000000
    //     0xfb6628: fmov            d0, #14.00000000
    // 0xfb662c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xfb662c: sub             lr, x0, #1, lsl #12
    //     0xfb6630: ldr             lr, [x21, lr, lsl #3]
    //     0xfb6634: blr             lr
    // 0xfb6638: LoadField: d0 = r0->field_7
    //     0xfb6638: ldur            d0, [x0, #7]
    // 0xfb663c: d1 = 14.000000
    //     0xfb663c: fmov            d1, #14.00000000
    // 0xfb6640: fdiv            d2, d0, d1
    // 0xfb6644: ldur            x1, [fp, #-0x10]
    // 0xfb6648: stur            d2, [fp, #-0x70]
    // 0xfb664c: r0 = textScalerOf()
    //     0xfb664c: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0xfb6650: ldur            x2, [fp, #-8]
    // 0xfb6654: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xfb6654: ldur            w3, [x2, #0x17]
    // 0xfb6658: DecompressPointer r3
    //     0xfb6658: add             x3, x3, HEAP, lsl #32
    // 0xfb665c: stur            x3, [fp, #-0x40]
    // 0xfb6660: cmp             w3, NULL
    // 0xfb6664: b.ne            #0xfb6670
    // 0xfb6668: r1 = Null
    //     0xfb6668: mov             x1, NULL
    // 0xfb666c: b               #0xfb6678
    // 0xfb6670: LoadField: r1 = r3->field_1f
    //     0xfb6670: ldur            w1, [x3, #0x1f]
    // 0xfb6674: DecompressPointer r1
    //     0xfb6674: add             x1, x1, HEAP, lsl #32
    // 0xfb6678: cmp             w1, NULL
    // 0xfb667c: b.ne            #0xfb668c
    // 0xfb6680: d0 = 32.000000
    //     0xfb6680: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a60] IMM: double(32) from 0x4040000000000000
    //     0xfb6684: ldr             d0, [x17, #0xa60]
    // 0xfb6688: b               #0xfb6690
    // 0xfb668c: LoadField: d0 = r1->field_7
    //     0xfb668c: ldur            d0, [x1, #7]
    // 0xfb6690: ldur            d1, [fp, #-0x70]
    // 0xfb6694: r1 = LoadClassIdInstr(r0)
    //     0xfb6694: ldur            x1, [x0, #-1]
    //     0xfb6698: ubfx            x1, x1, #0xc, #0x14
    // 0xfb669c: mov             x16, x0
    // 0xfb66a0: mov             x0, x1
    // 0xfb66a4: mov             x1, x16
    // 0xfb66a8: r0 = GDT[cid_x0 + -0x1000]()
    //     0xfb66a8: sub             lr, x0, #1, lsl #12
    //     0xfb66ac: ldr             lr, [x21, lr, lsl #3]
    //     0xfb66b0: blr             lr
    // 0xfb66b4: ldur            d0, [fp, #-0x70]
    // 0xfb66b8: d1 = 1.000000
    //     0xfb66b8: fmov            d1, #1.00000000
    // 0xfb66bc: stur            x0, [fp, #-0x50]
    // 0xfb66c0: fcmp            d0, d1
    // 0xfb66c4: b.le            #0xfb66d0
    // 0xfb66c8: mov             v1.16b, v0.16b
    // 0xfb66cc: b               #0xfb66d4
    // 0xfb66d0: d1 = 1.000000
    //     0xfb66d0: fmov            d1, #1.00000000
    // 0xfb66d4: ldur            x2, [fp, #-8]
    // 0xfb66d8: stur            d1, [fp, #-0x78]
    // 0xfb66dc: LoadField: r3 = r2->field_b
    //     0xfb66dc: ldur            w3, [x2, #0xb]
    // 0xfb66e0: DecompressPointer r3
    //     0xfb66e0: add             x3, x3, HEAP, lsl #32
    // 0xfb66e4: ldur            x1, [fp, #-0x10]
    // 0xfb66e8: stur            x3, [fp, #-0x48]
    // 0xfb66ec: r0 = textScalerOf()
    //     0xfb66ec: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0xfb66f0: ldur            x2, [fp, #-8]
    // 0xfb66f4: LoadField: r3 = r2->field_1b
    //     0xfb66f4: ldur            w3, [x2, #0x1b]
    // 0xfb66f8: DecompressPointer r3
    //     0xfb66f8: add             x3, x3, HEAP, lsl #32
    // 0xfb66fc: stur            x3, [fp, #-0x58]
    // 0xfb6700: r16 = Instance_Orientation
    //     0xfb6700: add             x16, PP, #0x14, lsl #12  ; [pp+0x143c8] Obj!Orientation@12c2ec1
    //     0xfb6704: ldr             x16, [x16, #0x3c8]
    // 0xfb6708: cmp             w3, w16
    // 0xfb670c: b.ne            #0xfb671c
    // 0xfb6710: d0 = 1.600000
    //     0xfb6710: add             x17, PP, #0x99, lsl #12  ; [pp+0x99bc0] IMM: double(1.6) from 0x3ff999999999999a
    //     0xfb6714: ldr             d0, [x17, #0xbc0]
    // 0xfb6718: b               #0xfb6724
    // 0xfb671c: d0 = 1.400000
    //     0xfb671c: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1f1f8] IMM: double(1.4) from 0x3ff6666666666666
    //     0xfb6720: ldr             d0, [x17, #0x1f8]
    // 0xfb6724: ldur            x5, [fp, #-0x20]
    // 0xfb6728: ldur            d1, [fp, #-0x70]
    // 0xfb672c: ldur            x4, [fp, #-0x48]
    // 0xfb6730: fmin            v2.2d, v1.2d, v0.2d
    // 0xfb6734: r1 = LoadClassIdInstr(r0)
    //     0xfb6734: ldur            x1, [x0, #-1]
    //     0xfb6738: ubfx            x1, x1, #0xc, #0x14
    // 0xfb673c: mov             x16, x0
    // 0xfb6740: mov             x0, x1
    // 0xfb6744: mov             x1, x16
    // 0xfb6748: mov             v0.16b, v2.16b
    // 0xfb674c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xfb674c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xfb6750: r0 = GDT[cid_x0 + -0xffa]()
    //     0xfb6750: sub             lr, x0, #0xffa
    //     0xfb6754: ldr             lr, [x21, lr, lsl #3]
    //     0xfb6758: blr             lr
    // 0xfb675c: stur            x0, [fp, #-0x60]
    // 0xfb6760: r0 = Text()
    //     0xfb6760: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xfb6764: mov             x2, x0
    // 0xfb6768: ldur            x0, [fp, #-0x48]
    // 0xfb676c: stur            x2, [fp, #-0x68]
    // 0xfb6770: StoreField: r2->field_b = r0
    //     0xfb6770: stur            w0, [x2, #0xb]
    // 0xfb6774: ldur            x0, [fp, #-0x20]
    // 0xfb6778: StoreField: r2->field_13 = r0
    //     0xfb6778: stur            w0, [x2, #0x13]
    // 0xfb677c: r0 = Instance_TextOverflow
    //     0xfb677c: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ac18] Obj!TextOverflow@12c47a1
    //     0xfb6780: ldr             x0, [x0, #0xc18]
    // 0xfb6784: StoreField: r2->field_2b = r0
    //     0xfb6784: stur            w0, [x2, #0x2b]
    // 0xfb6788: ldur            x1, [fp, #-0x60]
    // 0xfb678c: StoreField: r2->field_33 = r1
    //     0xfb678c: stur            w1, [x2, #0x33]
    // 0xfb6790: r3 = 2
    //     0xfb6790: mov             x3, #2
    // 0xfb6794: StoreField: r2->field_37 = r3
    //     0xfb6794: stur            w3, [x2, #0x37]
    // 0xfb6798: ldur            x4, [fp, #-8]
    // 0xfb679c: LoadField: r5 = r4->field_f
    //     0xfb679c: ldur            w5, [x4, #0xf]
    // 0xfb67a0: DecompressPointer r5
    //     0xfb67a0: add             x5, x5, HEAP, lsl #32
    // 0xfb67a4: ldur            x6, [fp, #-0x58]
    // 0xfb67a8: stur            x5, [fp, #-0x20]
    // 0xfb67ac: r16 = Instance_Orientation
    //     0xfb67ac: add             x16, PP, #0x14, lsl #12  ; [pp+0x143c8] Obj!Orientation@12c2ec1
    //     0xfb67b0: ldr             x16, [x16, #0x3c8]
    // 0xfb67b4: cmp             w6, w16
    // 0xfb67b8: b.ne            #0xfb67e8
    // 0xfb67bc: ldur            x1, [fp, #-0x50]
    // 0xfb67c0: d0 = 70.000000
    //     0xfb67c0: add             x17, PP, #0x13, lsl #12  ; [pp+0x137a8] IMM: double(70) from 0x4051800000000000
    //     0xfb67c4: ldr             d0, [x17, #0x7a8]
    // 0xfb67c8: LoadField: d1 = r1->field_7
    //     0xfb67c8: ldur            d1, [x1, #7]
    // 0xfb67cc: fcmp            d1, d0
    // 0xfb67d0: b.le            #0xfb67dc
    // 0xfb67d4: r1 = 2
    //     0xfb67d4: mov             x1, #2
    // 0xfb67d8: b               #0xfb67e0
    // 0xfb67dc: r1 = 1
    //     0xfb67dc: mov             x1, #1
    // 0xfb67e0: mov             x8, x1
    // 0xfb67e4: b               #0xfb6810
    // 0xfb67e8: ldur            x1, [fp, #-0x50]
    // 0xfb67ec: d0 = 40.000000
    //     0xfb67ec: add             x17, PP, #0x13, lsl #12  ; [pp+0x13168] IMM: double(40) from 0x4044000000000000
    //     0xfb67f0: ldr             d0, [x17, #0x168]
    // 0xfb67f4: LoadField: d1 = r1->field_7
    //     0xfb67f4: ldur            d1, [x1, #7]
    // 0xfb67f8: fcmp            d1, d0
    // 0xfb67fc: b.le            #0xfb6808
    // 0xfb6800: r1 = 3
    //     0xfb6800: mov             x1, #3
    // 0xfb6804: b               #0xfb680c
    // 0xfb6808: r1 = 2
    //     0xfb6808: mov             x1, #2
    // 0xfb680c: mov             x8, x1
    // 0xfb6810: ldur            x7, [fp, #-0x40]
    // 0xfb6814: ldur            d0, [fp, #-0x78]
    // 0xfb6818: ldur            x1, [fp, #-0x10]
    // 0xfb681c: stur            x8, [fp, #-0x28]
    // 0xfb6820: r0 = textScalerOf()
    //     0xfb6820: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0xfb6824: r1 = LoadClassIdInstr(r0)
    //     0xfb6824: ldur            x1, [x0, #-1]
    //     0xfb6828: ubfx            x1, x1, #0xc, #0x14
    // 0xfb682c: mov             x16, x0
    // 0xfb6830: mov             x0, x1
    // 0xfb6834: mov             x1, x16
    // 0xfb6838: ldur            d0, [fp, #-0x70]
    // 0xfb683c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xfb683c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xfb6840: r0 = GDT[cid_x0 + -0xffa]()
    //     0xfb6840: sub             lr, x0, #0xffa
    //     0xfb6844: ldr             lr, [x21, lr, lsl #3]
    //     0xfb6848: blr             lr
    // 0xfb684c: stur            x0, [fp, #-0x10]
    // 0xfb6850: r0 = Text()
    //     0xfb6850: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xfb6854: mov             x2, x0
    // 0xfb6858: ldur            x0, [fp, #-0x20]
    // 0xfb685c: stur            x2, [fp, #-0x48]
    // 0xfb6860: StoreField: r2->field_b = r0
    //     0xfb6860: stur            w0, [x2, #0xb]
    // 0xfb6864: ldur            x1, [fp, #-0x40]
    // 0xfb6868: StoreField: r2->field_13 = r1
    //     0xfb6868: stur            w1, [x2, #0x13]
    // 0xfb686c: r1 = Instance_TextOverflow
    //     0xfb686c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1ac18] Obj!TextOverflow@12c47a1
    //     0xfb6870: ldr             x1, [x1, #0xc18]
    // 0xfb6874: StoreField: r2->field_2b = r1
    //     0xfb6874: stur            w1, [x2, #0x2b]
    // 0xfb6878: ldur            x1, [fp, #-0x10]
    // 0xfb687c: StoreField: r2->field_33 = r1
    //     0xfb687c: stur            w1, [x2, #0x33]
    // 0xfb6880: ldur            x1, [fp, #-0x28]
    // 0xfb6884: lsl             x3, x1, #1
    // 0xfb6888: StoreField: r2->field_37 = r3
    //     0xfb6888: stur            w3, [x2, #0x37]
    // 0xfb688c: StoreField: r2->field_3b = r0
    //     0xfb688c: stur            w0, [x2, #0x3b]
    // 0xfb6890: ldur            d0, [fp, #-0x78]
    // 0xfb6894: d1 = 1.300000
    //     0xfb6894: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1f200] IMM: double(1.3) from 0x3ff4cccccccccccd
    //     0xfb6898: ldr             d1, [x17, #0x200]
    // 0xfb689c: fcmp            d0, d1
    // 0xfb68a0: b.le            #0xfb68b8
    // 0xfb68a4: d1 = 0.200000
    //     0xfb68a4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13230] IMM: double(0.2) from 0x3fc999999999999a
    //     0xfb68a8: ldr             d1, [x17, #0x230]
    // 0xfb68ac: fsub            d2, d0, d1
    // 0xfb68b0: mov             v0.16b, v2.16b
    // 0xfb68b4: b               #0xfb68bc
    // 0xfb68b8: d0 = 1.000000
    //     0xfb68b8: fmov            d0, #1.00000000
    // 0xfb68bc: ldur            x0, [fp, #-0x58]
    // 0xfb68c0: LoadField: r1 = r0->field_7
    //     0xfb68c0: ldur            x1, [x0, #7]
    // 0xfb68c4: cmp             x1, #0
    // 0xfb68c8: b.gt            #0xfb6c08
    // 0xfb68cc: ldur            x0, [fp, #-0x30]
    // 0xfb68d0: d1 = 120.000000
    //     0xfb68d0: add             x17, PP, #0x26, lsl #12  ; [pp+0x26190] IMM: double(120) from 0x405e000000000000
    //     0xfb68d4: ldr             d1, [x17, #0x190]
    // 0xfb68d8: fmul            d2, d0, d1
    // 0xfb68dc: stur            d2, [fp, #-0x70]
    // 0xfb68e0: r1 = <FlexParentData>
    //     0xfb68e0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xfb68e4: ldr             x1, [x1, #0x878]
    // 0xfb68e8: r0 = Expanded()
    //     0xfb68e8: bl              #0x8a5b10  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0xfb68ec: mov             x3, x0
    // 0xfb68f0: r0 = 1
    //     0xfb68f0: mov             x0, #1
    // 0xfb68f4: stur            x3, [fp, #-0x10]
    // 0xfb68f8: StoreField: r3->field_13 = r0
    //     0xfb68f8: stur            x0, [x3, #0x13]
    // 0xfb68fc: r1 = Instance_FlexFit
    //     0xfb68fc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15880] Obj!FlexFit@12c4641
    //     0xfb6900: ldr             x1, [x1, #0x880]
    // 0xfb6904: StoreField: r3->field_1b = r1
    //     0xfb6904: stur            w1, [x3, #0x1b]
    // 0xfb6908: ldur            x2, [fp, #-0x48]
    // 0xfb690c: StoreField: r3->field_b = r2
    //     0xfb690c: stur            w2, [x3, #0xb]
    // 0xfb6910: r1 = Null
    //     0xfb6910: mov             x1, NULL
    // 0xfb6914: r2 = 2
    //     0xfb6914: mov             x2, #2
    // 0xfb6918: r0 = AllocateArray()
    //     0xfb6918: bl              #0x13df928  ; AllocateArrayStub
    // 0xfb691c: mov             x2, x0
    // 0xfb6920: ldur            x0, [fp, #-0x10]
    // 0xfb6924: stur            x2, [fp, #-0x20]
    // 0xfb6928: StoreField: r2->field_f = r0
    //     0xfb6928: stur            w0, [x2, #0xf]
    // 0xfb692c: r1 = <Widget>
    //     0xfb692c: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfb6930: r0 = AllocateGrowableArray()
    //     0xfb6930: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xfb6934: mov             x1, x0
    // 0xfb6938: ldur            x0, [fp, #-0x20]
    // 0xfb693c: stur            x1, [fp, #-0x10]
    // 0xfb6940: StoreField: r1->field_f = r0
    //     0xfb6940: stur            w0, [x1, #0xf]
    // 0xfb6944: r0 = 2
    //     0xfb6944: mov             x0, #2
    // 0xfb6948: StoreField: r1->field_b = r0
    //     0xfb6948: stur            w0, [x1, #0xb]
    // 0xfb694c: ldur            x0, [fp, #-0x30]
    // 0xfb6950: cmp             w0, NULL
    // 0xfb6954: b.eq            #0xfb69f8
    // 0xfb6958: r0 = Semantics()
    //     0xfb6958: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xfb695c: stur            x0, [fp, #-0x20]
    // 0xfb6960: r16 = true
    //     0xfb6960: add             x16, NULL, #0x20  ; true
    // 0xfb6964: ldur            lr, [fp, #-0x30]
    // 0xfb6968: stp             lr, x16, [SP]
    // 0xfb696c: mov             x1, x0
    // 0xfb6970: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, container, 0x1, null]
    //     0xfb6970: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8c9b8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "container", 0x1, Null]
    //     0xfb6974: ldr             x4, [x4, #0x9b8]
    // 0xfb6978: r0 = Semantics()
    //     0xfb6978: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xfb697c: ldur            x0, [fp, #-0x10]
    // 0xfb6980: LoadField: r1 = r0->field_b
    //     0xfb6980: ldur            w1, [x0, #0xb]
    // 0xfb6984: LoadField: r2 = r0->field_f
    //     0xfb6984: ldur            w2, [x0, #0xf]
    // 0xfb6988: DecompressPointer r2
    //     0xfb6988: add             x2, x2, HEAP, lsl #32
    // 0xfb698c: LoadField: r3 = r2->field_b
    //     0xfb698c: ldur            w3, [x2, #0xb]
    // 0xfb6990: r2 = LoadInt32Instr(r1)
    //     0xfb6990: sbfx            x2, x1, #1, #0x1f
    // 0xfb6994: stur            x2, [fp, #-0x28]
    // 0xfb6998: r1 = LoadInt32Instr(r3)
    //     0xfb6998: sbfx            x1, x3, #1, #0x1f
    // 0xfb699c: cmp             x2, x1
    // 0xfb69a0: b.ne            #0xfb69ac
    // 0xfb69a4: mov             x1, x0
    // 0xfb69a8: r0 = _growToNextCapacity()
    //     0xfb69a8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfb69ac: ldur            x2, [fp, #-0x10]
    // 0xfb69b0: ldur            x3, [fp, #-0x28]
    // 0xfb69b4: add             x0, x3, #1
    // 0xfb69b8: lsl             x1, x0, #1
    // 0xfb69bc: StoreField: r2->field_b = r1
    //     0xfb69bc: stur            w1, [x2, #0xb]
    // 0xfb69c0: LoadField: r1 = r2->field_f
    //     0xfb69c0: ldur            w1, [x2, #0xf]
    // 0xfb69c4: DecompressPointer r1
    //     0xfb69c4: add             x1, x1, HEAP, lsl #32
    // 0xfb69c8: ldur            x0, [fp, #-0x20]
    // 0xfb69cc: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfb69cc: add             x25, x1, x3, lsl #2
    //     0xfb69d0: add             x25, x25, #0xf
    //     0xfb69d4: str             w0, [x25]
    //     0xfb69d8: tbz             w0, #0, #0xfb69f4
    //     0xfb69dc: ldurb           w16, [x1, #-1]
    //     0xfb69e0: ldurb           w17, [x0, #-1]
    //     0xfb69e4: and             x16, x17, x16, lsr #2
    //     0xfb69e8: tst             x16, HEAP, lsr #32
    //     0xfb69ec: b.eq            #0xfb69f4
    //     0xfb69f0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfb69f4: b               #0xfb69fc
    // 0xfb69f8: mov             x2, x1
    // 0xfb69fc: ldur            x0, [fp, #-0x68]
    // 0xfb6a00: ldur            d0, [fp, #-0x70]
    // 0xfb6a04: ldur            x1, [fp, #-0x38]
    // 0xfb6a08: r0 = Row()
    //     0xfb6a08: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xfb6a0c: mov             x3, x0
    // 0xfb6a10: r0 = Instance_Axis
    //     0xfb6a10: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xfb6a14: stur            x3, [fp, #-0x20]
    // 0xfb6a18: StoreField: r3->field_f = r0
    //     0xfb6a18: stur            w0, [x3, #0xf]
    // 0xfb6a1c: r0 = Instance_MainAxisAlignment
    //     0xfb6a1c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xfb6a20: ldr             x0, [x0, #0x820]
    // 0xfb6a24: StoreField: r3->field_13 = r0
    //     0xfb6a24: stur            w0, [x3, #0x13]
    // 0xfb6a28: r4 = Instance_MainAxisSize
    //     0xfb6a28: add             x4, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xfb6a2c: ldr             x4, [x4, #0x828]
    // 0xfb6a30: ArrayStore: r3[0] = r4  ; List_4
    //     0xfb6a30: stur            w4, [x3, #0x17]
    // 0xfb6a34: r1 = Instance_CrossAxisAlignment
    //     0xfb6a34: add             x1, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xfb6a38: ldr             x1, [x1, #0x888]
    // 0xfb6a3c: StoreField: r3->field_1b = r1
    //     0xfb6a3c: stur            w1, [x3, #0x1b]
    // 0xfb6a40: r5 = Instance_VerticalDirection
    //     0xfb6a40: add             x5, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xfb6a44: ldr             x5, [x5, #0x838]
    // 0xfb6a48: StoreField: r3->field_23 = r5
    //     0xfb6a48: stur            w5, [x3, #0x23]
    // 0xfb6a4c: r6 = Instance_Clip
    //     0xfb6a4c: add             x6, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb6a50: ldr             x6, [x6, #0x840]
    // 0xfb6a54: StoreField: r3->field_2b = r6
    //     0xfb6a54: stur            w6, [x3, #0x2b]
    // 0xfb6a58: StoreField: r3->field_2f = rZR
    //     0xfb6a58: stur            xzr, [x3, #0x2f]
    // 0xfb6a5c: ldur            x1, [fp, #-0x10]
    // 0xfb6a60: StoreField: r3->field_b = r1
    //     0xfb6a60: stur            w1, [x3, #0xb]
    // 0xfb6a64: r1 = Null
    //     0xfb6a64: mov             x1, NULL
    // 0xfb6a68: r2 = 8
    //     0xfb6a68: mov             x2, #8
    // 0xfb6a6c: r0 = AllocateArray()
    //     0xfb6a6c: bl              #0x13df928  ; AllocateArrayStub
    // 0xfb6a70: stur            x0, [fp, #-0x10]
    // 0xfb6a74: r16 = Instance_SizedBox
    //     0xfb6a74: add             x16, PP, #0x18, lsl #12  ; [pp+0x18360] Obj!SizedBox@12b7161
    //     0xfb6a78: ldr             x16, [x16, #0x360]
    // 0xfb6a7c: StoreField: r0->field_f = r16
    //     0xfb6a7c: stur            w16, [x0, #0xf]
    // 0xfb6a80: ldur            x3, [fp, #-0x68]
    // 0xfb6a84: StoreField: r0->field_13 = r3
    //     0xfb6a84: stur            w3, [x0, #0x13]
    // 0xfb6a88: r16 = Instance_Flexible
    //     0xfb6a88: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3e90] Obj!Flexible@12b77e1
    //     0xfb6a8c: ldr             x16, [x16, #0xe90]
    // 0xfb6a90: ArrayStore: r0[0] = r16  ; List_4
    //     0xfb6a90: stur            w16, [x0, #0x17]
    // 0xfb6a94: ldur            x1, [fp, #-0x20]
    // 0xfb6a98: StoreField: r0->field_1b = r1
    //     0xfb6a98: stur            w1, [x0, #0x1b]
    // 0xfb6a9c: r1 = <Widget>
    //     0xfb6a9c: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfb6aa0: r0 = AllocateGrowableArray()
    //     0xfb6aa0: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xfb6aa4: mov             x1, x0
    // 0xfb6aa8: ldur            x0, [fp, #-0x10]
    // 0xfb6aac: stur            x1, [fp, #-0x20]
    // 0xfb6ab0: StoreField: r1->field_f = r0
    //     0xfb6ab0: stur            w0, [x1, #0xf]
    // 0xfb6ab4: r4 = 8
    //     0xfb6ab4: mov             x4, #8
    // 0xfb6ab8: StoreField: r1->field_b = r4
    //     0xfb6ab8: stur            w4, [x1, #0xb]
    // 0xfb6abc: r0 = Column()
    //     0xfb6abc: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xfb6ac0: r5 = Instance_Axis
    //     0xfb6ac0: ldr             x5, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xfb6ac4: stur            x0, [fp, #-0x10]
    // 0xfb6ac8: StoreField: r0->field_f = r5
    //     0xfb6ac8: stur            w5, [x0, #0xf]
    // 0xfb6acc: r6 = Instance_MainAxisAlignment
    //     0xfb6acc: add             x6, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xfb6ad0: ldr             x6, [x6, #0x820]
    // 0xfb6ad4: StoreField: r0->field_13 = r6
    //     0xfb6ad4: stur            w6, [x0, #0x13]
    // 0xfb6ad8: r7 = Instance_MainAxisSize
    //     0xfb6ad8: add             x7, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xfb6adc: ldr             x7, [x7, #0x828]
    // 0xfb6ae0: ArrayStore: r0[0] = r7  ; List_4
    //     0xfb6ae0: stur            w7, [x0, #0x17]
    // 0xfb6ae4: r8 = Instance_CrossAxisAlignment
    //     0xfb6ae4: add             x8, PP, #0x15, lsl #12  ; [pp+0x15830] Obj!CrossAxisAlignment@12c44c1
    //     0xfb6ae8: ldr             x8, [x8, #0x830]
    // 0xfb6aec: StoreField: r0->field_1b = r8
    //     0xfb6aec: stur            w8, [x0, #0x1b]
    // 0xfb6af0: r9 = Instance_VerticalDirection
    //     0xfb6af0: add             x9, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xfb6af4: ldr             x9, [x9, #0x838]
    // 0xfb6af8: StoreField: r0->field_23 = r9
    //     0xfb6af8: stur            w9, [x0, #0x23]
    // 0xfb6afc: r1 = Instance_Clip
    //     0xfb6afc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb6b00: ldr             x1, [x1, #0x840]
    // 0xfb6b04: StoreField: r0->field_2b = r1
    //     0xfb6b04: stur            w1, [x0, #0x2b]
    // 0xfb6b08: StoreField: r0->field_2f = rZR
    //     0xfb6b08: stur            xzr, [x0, #0x2f]
    // 0xfb6b0c: ldur            x2, [fp, #-0x20]
    // 0xfb6b10: StoreField: r0->field_b = r2
    //     0xfb6b10: stur            w2, [x0, #0xb]
    // 0xfb6b14: r0 = Padding()
    //     0xfb6b14: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xfb6b18: mov             x1, x0
    // 0xfb6b1c: r0 = Instance_EdgeInsetsDirectional
    //     0xfb6b1c: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3e98] Obj!EdgeInsetsDirectional@129cab1
    //     0xfb6b20: ldr             x0, [x0, #0xe98]
    // 0xfb6b24: stur            x1, [fp, #-0x20]
    // 0xfb6b28: StoreField: r1->field_f = r0
    //     0xfb6b28: stur            w0, [x1, #0xf]
    // 0xfb6b2c: ldur            x0, [fp, #-0x10]
    // 0xfb6b30: StoreField: r1->field_b = r0
    //     0xfb6b30: stur            w0, [x1, #0xb]
    // 0xfb6b34: r0 = Material()
    //     0xfb6b34: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xfb6b38: r10 = Instance_MaterialType
    //     0xfb6b38: add             x10, PP, #0x17, lsl #12  ; [pp+0x17210] Obj!MaterialType@12c5341
    //     0xfb6b3c: ldr             x10, [x10, #0x210]
    // 0xfb6b40: stur            x0, [fp, #-0x40]
    // 0xfb6b44: StoreField: r0->field_f = r10
    //     0xfb6b44: stur            w10, [x0, #0xf]
    // 0xfb6b48: ArrayStore: r0[0] = rZR  ; List_8
    //     0xfb6b48: stur            xzr, [x0, #0x17]
    // 0xfb6b4c: ldur            x11, [fp, #-0x38]
    // 0xfb6b50: StoreField: r0->field_1f = r11
    //     0xfb6b50: stur            w11, [x0, #0x1f]
    // 0xfb6b54: r12 = true
    //     0xfb6b54: add             x12, NULL, #0x20  ; true
    // 0xfb6b58: StoreField: r0->field_33 = r12
    //     0xfb6b58: stur            w12, [x0, #0x33]
    // 0xfb6b5c: r13 = Instance_Clip
    //     0xfb6b5c: add             x13, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb6b60: ldr             x13, [x13, #0x840]
    // 0xfb6b64: StoreField: r0->field_37 = r13
    //     0xfb6b64: stur            w13, [x0, #0x37]
    // 0xfb6b68: r14 = Instance_Duration
    //     0xfb6b68: add             x14, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xfb6b6c: ldr             x14, [x14, #0x318]
    // 0xfb6b70: StoreField: r0->field_3b = r14
    //     0xfb6b70: stur            w14, [x0, #0x3b]
    // 0xfb6b74: ldur            x1, [fp, #-0x20]
    // 0xfb6b78: StoreField: r0->field_b = r1
    //     0xfb6b78: stur            w1, [x0, #0xb]
    // 0xfb6b7c: r19 = false
    //     0xfb6b7c: add             x19, NULL, #0x30  ; false
    // 0xfb6b80: StoreField: r0->field_13 = r19
    //     0xfb6b80: stur            w19, [x0, #0x13]
    // 0xfb6b84: ldur            d0, [fp, #-0x70]
    // 0xfb6b88: r1 = inline_Allocate_Double()
    //     0xfb6b88: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xfb6b8c: add             x1, x1, #0x10
    //     0xfb6b90: cmp             x2, x1
    //     0xfb6b94: b.ls            #0xfb6f9c
    //     0xfb6b98: str             x1, [THR, #0x60]  ; THR::top
    //     0xfb6b9c: sub             x1, x1, #0xf
    //     0xfb6ba0: mov             x2, #0xe19c
    //     0xfb6ba4: movk            x2, #3, lsl #16
    //     0xfb6ba8: stur            x2, [x1, #-1]
    // 0xfb6bac: dmb             ishst
    // 0xfb6bb0: StoreField: r1->field_7 = d0
    //     0xfb6bb0: stur            d0, [x1, #7]
    // 0xfb6bb4: stur            x1, [fp, #-0x10]
    // 0xfb6bb8: r0 = SizedBox()
    //     0xfb6bb8: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xfb6bbc: mov             x1, x0
    // 0xfb6bc0: ldur            x0, [fp, #-0x10]
    // 0xfb6bc4: stur            x1, [fp, #-0x20]
    // 0xfb6bc8: StoreField: r1->field_13 = r0
    //     0xfb6bc8: stur            w0, [x1, #0x13]
    // 0xfb6bcc: ldur            x0, [fp, #-0x40]
    // 0xfb6bd0: StoreField: r1->field_b = r0
    //     0xfb6bd0: stur            w0, [x1, #0xb]
    // 0xfb6bd4: r0 = Semantics()
    //     0xfb6bd4: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xfb6bd8: stur            x0, [fp, #-0x10]
    // 0xfb6bdc: r16 = true
    //     0xfb6bdc: add             x16, NULL, #0x20  ; true
    // 0xfb6be0: ldur            lr, [fp, #-0x20]
    // 0xfb6be4: stp             lr, x16, [SP]
    // 0xfb6be8: mov             x1, x0
    // 0xfb6bec: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, container, 0x1, null]
    //     0xfb6bec: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8c9b8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "container", 0x1, Null]
    //     0xfb6bf0: ldr             x4, [x4, #0x9b8]
    // 0xfb6bf4: r0 = Semantics()
    //     0xfb6bf4: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xfb6bf8: ldur            x0, [fp, #-0x10]
    // 0xfb6bfc: LeaveFrame
    //     0xfb6bfc: mov             SP, fp
    //     0xfb6c00: ldp             fp, lr, [SP], #0x10
    // 0xfb6c04: ret
    //     0xfb6c04: ret             
    // 0xfb6c08: ldur            x20, [fp, #-8]
    // 0xfb6c0c: ldur            x3, [fp, #-0x68]
    // 0xfb6c10: ldur            x11, [fp, #-0x38]
    // 0xfb6c14: r12 = true
    //     0xfb6c14: add             x12, NULL, #0x20  ; true
    // 0xfb6c18: r8 = Instance_CrossAxisAlignment
    //     0xfb6c18: add             x8, PP, #0x15, lsl #12  ; [pp+0x15830] Obj!CrossAxisAlignment@12c44c1
    //     0xfb6c1c: ldr             x8, [x8, #0x830]
    // 0xfb6c20: r6 = Instance_MainAxisAlignment
    //     0xfb6c20: add             x6, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xfb6c24: ldr             x6, [x6, #0x820]
    // 0xfb6c28: r7 = Instance_MainAxisSize
    //     0xfb6c28: add             x7, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xfb6c2c: ldr             x7, [x7, #0x828]
    // 0xfb6c30: r9 = Instance_VerticalDirection
    //     0xfb6c30: add             x9, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xfb6c34: ldr             x9, [x9, #0x838]
    // 0xfb6c38: r5 = Instance_Axis
    //     0xfb6c38: ldr             x5, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xfb6c3c: r13 = Instance_Clip
    //     0xfb6c3c: add             x13, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb6c40: ldr             x13, [x13, #0x840]
    // 0xfb6c44: r10 = Instance_MaterialType
    //     0xfb6c44: add             x10, PP, #0x17, lsl #12  ; [pp+0x17210] Obj!MaterialType@12c5341
    //     0xfb6c48: ldr             x10, [x10, #0x210]
    // 0xfb6c4c: r14 = Instance_Duration
    //     0xfb6c4c: add             x14, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xfb6c50: ldr             x14, [x14, #0x318]
    // 0xfb6c54: r19 = false
    //     0xfb6c54: add             x19, NULL, #0x30  ; false
    // 0xfb6c58: r1 = Instance_FlexFit
    //     0xfb6c58: add             x1, PP, #0x15, lsl #12  ; [pp+0x15880] Obj!FlexFit@12c4641
    //     0xfb6c5c: ldr             x1, [x1, #0x880]
    // 0xfb6c60: r4 = 8
    //     0xfb6c60: mov             x4, #8
    // 0xfb6c64: r0 = 1
    //     0xfb6c64: mov             x0, #1
    // 0xfb6c68: r0 = Padding()
    //     0xfb6c68: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xfb6c6c: mov             x1, x0
    // 0xfb6c70: r0 = Instance_EdgeInsets
    //     0xfb6c70: add             x0, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0xfb6c74: ldr             x0, [x0, #0x510]
    // 0xfb6c78: stur            x1, [fp, #-0x10]
    // 0xfb6c7c: StoreField: r1->field_f = r0
    //     0xfb6c7c: stur            w0, [x1, #0xf]
    // 0xfb6c80: ldur            x2, [fp, #-0x68]
    // 0xfb6c84: StoreField: r1->field_b = r2
    //     0xfb6c84: stur            w2, [x1, #0xb]
    // 0xfb6c88: ldur            x2, [fp, #-8]
    // 0xfb6c8c: LoadField: r3 = r2->field_1f
    //     0xfb6c8c: ldur            w3, [x2, #0x1f]
    // 0xfb6c90: DecompressPointer r3
    //     0xfb6c90: add             x3, x3, HEAP, lsl #32
    // 0xfb6c94: tbnz            w3, #4, #0xfb6ca0
    // 0xfb6c98: d0 = 16.000000
    //     0xfb6c98: fmov            d0, #16.00000000
    // 0xfb6c9c: b               #0xfb6ca8
    // 0xfb6ca0: d0 = 56.000000
    //     0xfb6ca0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a70] IMM: double(56) from 0x404c000000000000
    //     0xfb6ca4: ldr             d0, [x17, #0xa70]
    // 0xfb6ca8: ldur            x3, [fp, #-0x30]
    // 0xfb6cac: ldur            x2, [fp, #-0x48]
    // 0xfb6cb0: r4 = inline_Allocate_Double()
    //     0xfb6cb0: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xfb6cb4: add             x4, x4, #0x10
    //     0xfb6cb8: cmp             x5, x4
    //     0xfb6cbc: b.ls            #0xfb6fb8
    //     0xfb6cc0: str             x4, [THR, #0x60]  ; THR::top
    //     0xfb6cc4: sub             x4, x4, #0xf
    //     0xfb6cc8: mov             x5, #0xe19c
    //     0xfb6ccc: movk            x5, #3, lsl #16
    //     0xfb6cd0: stur            x5, [x4, #-1]
    // 0xfb6cd4: dmb             ishst
    // 0xfb6cd8: StoreField: r4->field_7 = d0
    //     0xfb6cd8: stur            d0, [x4, #7]
    // 0xfb6cdc: stur            x4, [fp, #-8]
    // 0xfb6ce0: r0 = SizedBox()
    //     0xfb6ce0: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xfb6ce4: mov             x1, x0
    // 0xfb6ce8: ldur            x0, [fp, #-8]
    // 0xfb6cec: stur            x1, [fp, #-0x20]
    // 0xfb6cf0: StoreField: r1->field_13 = r0
    //     0xfb6cf0: stur            w0, [x1, #0x13]
    // 0xfb6cf4: r0 = Padding()
    //     0xfb6cf4: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xfb6cf8: mov             x2, x0
    // 0xfb6cfc: r0 = Instance_EdgeInsets
    //     0xfb6cfc: add             x0, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0xfb6d00: ldr             x0, [x0, #0x510]
    // 0xfb6d04: stur            x2, [fp, #-8]
    // 0xfb6d08: StoreField: r2->field_f = r0
    //     0xfb6d08: stur            w0, [x2, #0xf]
    // 0xfb6d0c: ldur            x0, [fp, #-0x48]
    // 0xfb6d10: StoreField: r2->field_b = r0
    //     0xfb6d10: stur            w0, [x2, #0xb]
    // 0xfb6d14: r1 = <FlexParentData>
    //     0xfb6d14: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xfb6d18: ldr             x1, [x1, #0x878]
    // 0xfb6d1c: r0 = Expanded()
    //     0xfb6d1c: bl              #0x8a5b10  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0xfb6d20: mov             x3, x0
    // 0xfb6d24: r0 = 1
    //     0xfb6d24: mov             x0, #1
    // 0xfb6d28: stur            x3, [fp, #-0x40]
    // 0xfb6d2c: StoreField: r3->field_13 = r0
    //     0xfb6d2c: stur            x0, [x3, #0x13]
    // 0xfb6d30: r0 = Instance_FlexFit
    //     0xfb6d30: add             x0, PP, #0x15, lsl #12  ; [pp+0x15880] Obj!FlexFit@12c4641
    //     0xfb6d34: ldr             x0, [x0, #0x880]
    // 0xfb6d38: StoreField: r3->field_1b = r0
    //     0xfb6d38: stur            w0, [x3, #0x1b]
    // 0xfb6d3c: ldur            x0, [fp, #-8]
    // 0xfb6d40: StoreField: r3->field_b = r0
    //     0xfb6d40: stur            w0, [x3, #0xb]
    // 0xfb6d44: r1 = Null
    //     0xfb6d44: mov             x1, NULL
    // 0xfb6d48: r2 = 8
    //     0xfb6d48: mov             x2, #8
    // 0xfb6d4c: r0 = AllocateArray()
    //     0xfb6d4c: bl              #0x13df928  ; AllocateArrayStub
    // 0xfb6d50: stur            x0, [fp, #-8]
    // 0xfb6d54: r16 = Instance_SizedBox
    //     0xfb6d54: add             x16, PP, #0x18, lsl #12  ; [pp+0x18360] Obj!SizedBox@12b7161
    //     0xfb6d58: ldr             x16, [x16, #0x360]
    // 0xfb6d5c: StoreField: r0->field_f = r16
    //     0xfb6d5c: stur            w16, [x0, #0xf]
    // 0xfb6d60: ldur            x1, [fp, #-0x10]
    // 0xfb6d64: StoreField: r0->field_13 = r1
    //     0xfb6d64: stur            w1, [x0, #0x13]
    // 0xfb6d68: ldur            x1, [fp, #-0x20]
    // 0xfb6d6c: ArrayStore: r0[0] = r1  ; List_4
    //     0xfb6d6c: stur            w1, [x0, #0x17]
    // 0xfb6d70: ldur            x1, [fp, #-0x40]
    // 0xfb6d74: StoreField: r0->field_1b = r1
    //     0xfb6d74: stur            w1, [x0, #0x1b]
    // 0xfb6d78: r1 = <Widget>
    //     0xfb6d78: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfb6d7c: r0 = AllocateGrowableArray()
    //     0xfb6d7c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xfb6d80: mov             x1, x0
    // 0xfb6d84: ldur            x0, [fp, #-8]
    // 0xfb6d88: stur            x1, [fp, #-0x10]
    // 0xfb6d8c: StoreField: r1->field_f = r0
    //     0xfb6d8c: stur            w0, [x1, #0xf]
    // 0xfb6d90: r0 = 8
    //     0xfb6d90: mov             x0, #8
    // 0xfb6d94: StoreField: r1->field_b = r0
    //     0xfb6d94: stur            w0, [x1, #0xb]
    // 0xfb6d98: ldur            x0, [fp, #-0x30]
    // 0xfb6d9c: cmp             w0, NULL
    // 0xfb6da0: b.eq            #0xfb6e88
    // 0xfb6da4: ldur            x2, [fp, #-0x18]
    // 0xfb6da8: LoadField: r3 = r2->field_2f
    //     0xfb6da8: ldur            w3, [x2, #0x2f]
    // 0xfb6dac: DecompressPointer r3
    //     0xfb6dac: add             x3, x3, HEAP, lsl #32
    // 0xfb6db0: tbnz            w3, #4, #0xfb6dc0
    // 0xfb6db4: r2 = Instance_EdgeInsetsDirectional
    //     0xfb6db4: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3ea0] Obj!EdgeInsetsDirectional@129ca81
    //     0xfb6db8: ldr             x2, [x2, #0xea0]
    // 0xfb6dbc: b               #0xfb6dc8
    // 0xfb6dc0: r2 = Instance_EdgeInsets
    //     0xfb6dc0: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1c430] Obj!EdgeInsets@129dc51
    //     0xfb6dc4: ldr             x2, [x2, #0x430]
    // 0xfb6dc8: stur            x2, [fp, #-8]
    // 0xfb6dcc: r0 = Semantics()
    //     0xfb6dcc: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xfb6dd0: stur            x0, [fp, #-0x18]
    // 0xfb6dd4: r16 = true
    //     0xfb6dd4: add             x16, NULL, #0x20  ; true
    // 0xfb6dd8: ldur            lr, [fp, #-0x30]
    // 0xfb6ddc: stp             lr, x16, [SP]
    // 0xfb6de0: mov             x1, x0
    // 0xfb6de4: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, container, 0x1, null]
    //     0xfb6de4: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8c9b8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "container", 0x1, Null]
    //     0xfb6de8: ldr             x4, [x4, #0x9b8]
    // 0xfb6dec: r0 = Semantics()
    //     0xfb6dec: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xfb6df0: r0 = Padding()
    //     0xfb6df0: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xfb6df4: mov             x2, x0
    // 0xfb6df8: ldur            x0, [fp, #-8]
    // 0xfb6dfc: stur            x2, [fp, #-0x20]
    // 0xfb6e00: StoreField: r2->field_f = r0
    //     0xfb6e00: stur            w0, [x2, #0xf]
    // 0xfb6e04: ldur            x0, [fp, #-0x18]
    // 0xfb6e08: StoreField: r2->field_b = r0
    //     0xfb6e08: stur            w0, [x2, #0xb]
    // 0xfb6e0c: ldur            x0, [fp, #-0x10]
    // 0xfb6e10: LoadField: r1 = r0->field_b
    //     0xfb6e10: ldur            w1, [x0, #0xb]
    // 0xfb6e14: LoadField: r3 = r0->field_f
    //     0xfb6e14: ldur            w3, [x0, #0xf]
    // 0xfb6e18: DecompressPointer r3
    //     0xfb6e18: add             x3, x3, HEAP, lsl #32
    // 0xfb6e1c: LoadField: r4 = r3->field_b
    //     0xfb6e1c: ldur            w4, [x3, #0xb]
    // 0xfb6e20: r3 = LoadInt32Instr(r1)
    //     0xfb6e20: sbfx            x3, x1, #1, #0x1f
    // 0xfb6e24: stur            x3, [fp, #-0x28]
    // 0xfb6e28: r1 = LoadInt32Instr(r4)
    //     0xfb6e28: sbfx            x1, x4, #1, #0x1f
    // 0xfb6e2c: cmp             x3, x1
    // 0xfb6e30: b.ne            #0xfb6e3c
    // 0xfb6e34: mov             x1, x0
    // 0xfb6e38: r0 = _growToNextCapacity()
    //     0xfb6e38: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfb6e3c: ldur            x2, [fp, #-0x10]
    // 0xfb6e40: ldur            x3, [fp, #-0x28]
    // 0xfb6e44: add             x0, x3, #1
    // 0xfb6e48: lsl             x1, x0, #1
    // 0xfb6e4c: StoreField: r2->field_b = r1
    //     0xfb6e4c: stur            w1, [x2, #0xb]
    // 0xfb6e50: LoadField: r1 = r2->field_f
    //     0xfb6e50: ldur            w1, [x2, #0xf]
    // 0xfb6e54: DecompressPointer r1
    //     0xfb6e54: add             x1, x1, HEAP, lsl #32
    // 0xfb6e58: ldur            x0, [fp, #-0x20]
    // 0xfb6e5c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfb6e5c: add             x25, x1, x3, lsl #2
    //     0xfb6e60: add             x25, x25, #0xf
    //     0xfb6e64: str             w0, [x25]
    //     0xfb6e68: tbz             w0, #0, #0xfb6e84
    //     0xfb6e6c: ldurb           w16, [x1, #-1]
    //     0xfb6e70: ldurb           w17, [x0, #-1]
    //     0xfb6e74: and             x16, x17, x16, lsr #2
    //     0xfb6e78: tst             x16, HEAP, lsr #32
    //     0xfb6e7c: b.eq            #0xfb6e84
    //     0xfb6e80: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfb6e84: b               #0xfb6e8c
    // 0xfb6e88: mov             x2, x1
    // 0xfb6e8c: ldur            x0, [fp, #-0x38]
    // 0xfb6e90: r0 = Column()
    //     0xfb6e90: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xfb6e94: mov             x1, x0
    // 0xfb6e98: r0 = Instance_Axis
    //     0xfb6e98: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xfb6e9c: stur            x1, [fp, #-8]
    // 0xfb6ea0: StoreField: r1->field_f = r0
    //     0xfb6ea0: stur            w0, [x1, #0xf]
    // 0xfb6ea4: r0 = Instance_MainAxisAlignment
    //     0xfb6ea4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xfb6ea8: ldr             x0, [x0, #0x820]
    // 0xfb6eac: StoreField: r1->field_13 = r0
    //     0xfb6eac: stur            w0, [x1, #0x13]
    // 0xfb6eb0: r0 = Instance_MainAxisSize
    //     0xfb6eb0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xfb6eb4: ldr             x0, [x0, #0x828]
    // 0xfb6eb8: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb6eb8: stur            w0, [x1, #0x17]
    // 0xfb6ebc: r0 = Instance_CrossAxisAlignment
    //     0xfb6ebc: add             x0, PP, #0x15, lsl #12  ; [pp+0x15830] Obj!CrossAxisAlignment@12c44c1
    //     0xfb6ec0: ldr             x0, [x0, #0x830]
    // 0xfb6ec4: StoreField: r1->field_1b = r0
    //     0xfb6ec4: stur            w0, [x1, #0x1b]
    // 0xfb6ec8: r0 = Instance_VerticalDirection
    //     0xfb6ec8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xfb6ecc: ldr             x0, [x0, #0x838]
    // 0xfb6ed0: StoreField: r1->field_23 = r0
    //     0xfb6ed0: stur            w0, [x1, #0x23]
    // 0xfb6ed4: r0 = Instance_Clip
    //     0xfb6ed4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb6ed8: ldr             x0, [x0, #0x840]
    // 0xfb6edc: StoreField: r1->field_2b = r0
    //     0xfb6edc: stur            w0, [x1, #0x2b]
    // 0xfb6ee0: StoreField: r1->field_2f = rZR
    //     0xfb6ee0: stur            xzr, [x1, #0x2f]
    // 0xfb6ee4: ldur            x2, [fp, #-0x10]
    // 0xfb6ee8: StoreField: r1->field_b = r2
    //     0xfb6ee8: stur            w2, [x1, #0xb]
    // 0xfb6eec: r0 = Material()
    //     0xfb6eec: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xfb6ef0: mov             x1, x0
    // 0xfb6ef4: r0 = Instance_MaterialType
    //     0xfb6ef4: add             x0, PP, #0x17, lsl #12  ; [pp+0x17210] Obj!MaterialType@12c5341
    //     0xfb6ef8: ldr             x0, [x0, #0x210]
    // 0xfb6efc: stur            x1, [fp, #-0x10]
    // 0xfb6f00: StoreField: r1->field_f = r0
    //     0xfb6f00: stur            w0, [x1, #0xf]
    // 0xfb6f04: ArrayStore: r1[0] = rZR  ; List_8
    //     0xfb6f04: stur            xzr, [x1, #0x17]
    // 0xfb6f08: ldur            x0, [fp, #-0x38]
    // 0xfb6f0c: StoreField: r1->field_1f = r0
    //     0xfb6f0c: stur            w0, [x1, #0x1f]
    // 0xfb6f10: r0 = true
    //     0xfb6f10: add             x0, NULL, #0x20  ; true
    // 0xfb6f14: StoreField: r1->field_33 = r0
    //     0xfb6f14: stur            w0, [x1, #0x33]
    // 0xfb6f18: r0 = Instance_Clip
    //     0xfb6f18: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb6f1c: ldr             x0, [x0, #0x840]
    // 0xfb6f20: StoreField: r1->field_37 = r0
    //     0xfb6f20: stur            w0, [x1, #0x37]
    // 0xfb6f24: r0 = Instance_Duration
    //     0xfb6f24: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xfb6f28: ldr             x0, [x0, #0x318]
    // 0xfb6f2c: StoreField: r1->field_3b = r0
    //     0xfb6f2c: stur            w0, [x1, #0x3b]
    // 0xfb6f30: ldur            x0, [fp, #-8]
    // 0xfb6f34: StoreField: r1->field_b = r0
    //     0xfb6f34: stur            w0, [x1, #0xb]
    // 0xfb6f38: r0 = false
    //     0xfb6f38: add             x0, NULL, #0x30  ; false
    // 0xfb6f3c: StoreField: r1->field_13 = r0
    //     0xfb6f3c: stur            w0, [x1, #0x13]
    // 0xfb6f40: r0 = SizedBox()
    //     0xfb6f40: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xfb6f44: mov             x1, x0
    // 0xfb6f48: r0 = 152.000000
    //     0xfb6f48: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3ea8] 152
    //     0xfb6f4c: ldr             x0, [x0, #0xea8]
    // 0xfb6f50: stur            x1, [fp, #-8]
    // 0xfb6f54: StoreField: r1->field_f = r0
    //     0xfb6f54: stur            w0, [x1, #0xf]
    // 0xfb6f58: ldur            x0, [fp, #-0x10]
    // 0xfb6f5c: StoreField: r1->field_b = r0
    //     0xfb6f5c: stur            w0, [x1, #0xb]
    // 0xfb6f60: r0 = Semantics()
    //     0xfb6f60: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xfb6f64: stur            x0, [fp, #-0x10]
    // 0xfb6f68: r16 = true
    //     0xfb6f68: add             x16, NULL, #0x20  ; true
    // 0xfb6f6c: ldur            lr, [fp, #-8]
    // 0xfb6f70: stp             lr, x16, [SP]
    // 0xfb6f74: mov             x1, x0
    // 0xfb6f78: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, container, 0x1, null]
    //     0xfb6f78: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8c9b8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "container", 0x1, Null]
    //     0xfb6f7c: ldr             x4, [x4, #0x9b8]
    // 0xfb6f80: r0 = Semantics()
    //     0xfb6f80: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xfb6f84: ldur            x0, [fp, #-0x10]
    // 0xfb6f88: LeaveFrame
    //     0xfb6f88: mov             SP, fp
    //     0xfb6f8c: ldp             fp, lr, [SP], #0x10
    // 0xfb6f90: ret
    //     0xfb6f90: ret             
    // 0xfb6f94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb6f94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb6f98: b               #0xfb6298
    // 0xfb6f9c: SaveReg d0
    //     0xfb6f9c: str             q0, [SP, #-0x10]!
    // 0xfb6fa0: SaveReg r0
    //     0xfb6fa0: str             x0, [SP, #-8]!
    // 0xfb6fa4: r0 = AllocateDouble()
    //     0xfb6fa4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfb6fa8: mov             x1, x0
    // 0xfb6fac: RestoreReg r0
    //     0xfb6fac: ldr             x0, [SP], #8
    // 0xfb6fb0: RestoreReg d0
    //     0xfb6fb0: ldr             q0, [SP], #0x10
    // 0xfb6fb4: b               #0xfb6bb0
    // 0xfb6fb8: SaveReg d0
    //     0xfb6fb8: str             q0, [SP, #-0x10]!
    // 0xfb6fbc: stp             x2, x3, [SP, #-0x10]!
    // 0xfb6fc0: stp             x0, x1, [SP, #-0x10]!
    // 0xfb6fc4: r0 = AllocateDouble()
    //     0xfb6fc4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfb6fc8: mov             x4, x0
    // 0xfb6fcc: ldp             x0, x1, [SP], #0x10
    // 0xfb6fd0: ldp             x2, x3, [SP], #0x10
    // 0xfb6fd4: RestoreReg d0
    //     0xfb6fd4: ldr             q0, [SP], #0x10
    // 0xfb6fd8: b               #0xfb6cd8
  }
}

// class id: 6485, size: 0x60, field offset: 0xc
class DatePickerDialog extends StatefulWidget {

  _ DatePickerDialog(/* No info */) {
    // ** addr: 0xe824f0, size: 0x158
    // 0xe824f0: EnterFrame
    //     0xe824f0: stp             fp, lr, [SP, #-0x10]!
    //     0xe824f4: mov             fp, SP
    // 0xe824f8: AllocStack(0x18)
    //     0xe824f8: sub             SP, SP, #0x18
    // 0xe824fc: r0 = Instance_DatePickerEntryMode
    //     0xe824fc: add             x0, PP, #0x28, lsl #12  ; [pp+0x28520] Obj!DatePickerEntryMode@12c58c1
    //     0xe82500: ldr             x0, [x0, #0x520]
    // 0xe82504: r8 = Instance_DatePickerMode
    //     0xe82504: add             x8, PP, #0x28, lsl #12  ; [pp+0x28528] Obj!DatePickerMode@12c5821
    //     0xe82508: ldr             x8, [x8, #0x528]
    // 0xe8250c: r7 = Instance_EdgeInsets
    //     0xe8250c: add             x7, PP, #0x28, lsl #12  ; [pp+0x28530] Obj!EdgeInsets@129cd81
    //     0xe82510: ldr             x7, [x7, #0x530]
    // 0xe82514: r4 = Instance_GregorianCalendarDelegate
    //     0xe82514: add             x4, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xe82518: ldr             x4, [x4, #0x538]
    // 0xe8251c: stur            x1, [fp, #-8]
    // 0xe82520: mov             x16, x5
    // 0xe82524: mov             x5, x1
    // 0xe82528: mov             x1, x16
    // 0xe8252c: mov             x16, x2
    // 0xe82530: mov             x2, x5
    // 0xe82534: mov             x5, x16
    // 0xe82538: mov             x16, x6
    // 0xe8253c: mov             x6, x2
    // 0xe82540: mov             x2, x16
    // 0xe82544: stur            x3, [fp, #-0x10]
    // 0xe82548: stur            x2, [fp, #-0x18]
    // 0xe8254c: CheckStackOverflow
    //     0xe8254c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe82550: cmp             SP, x16
    //     0xe82554: b.ls            #0xe82640
    // 0xe82558: StoreField: r6->field_1b = r0
    //     0xe82558: stur            w0, [x6, #0x1b]
    // 0xe8255c: mov             x0, x5
    // 0xe82560: StoreField: r6->field_23 = r0
    //     0xe82560: stur            w0, [x6, #0x23]
    //     0xe82564: ldurb           w16, [x6, #-1]
    //     0xe82568: ldurb           w17, [x0, #-1]
    //     0xe8256c: and             x16, x17, x16, lsr #2
    //     0xe82570: tst             x16, HEAP, lsr #32
    //     0xe82574: b.eq            #0xe8257c
    //     0xe82578: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xe8257c: StoreField: r6->field_2f = r8
    //     0xe8257c: stur            w8, [x6, #0x2f]
    // 0xe82580: StoreField: r6->field_57 = r7
    //     0xe82580: stur            w7, [x6, #0x57]
    // 0xe82584: StoreField: r6->field_5b = r4
    //     0xe82584: stur            w4, [x6, #0x5b]
    // 0xe82588: r0 = dateOnly()
    //     0xe82588: bl              #0xd18a20  ; [package:flutter/src/material/date.dart] DateUtils::dateOnly
    // 0xe8258c: ldur            x2, [fp, #-8]
    // 0xe82590: StoreField: r2->field_b = r0
    //     0xe82590: stur            w0, [x2, #0xb]
    //     0xe82594: ldurb           w16, [x2, #-1]
    //     0xe82598: ldurb           w17, [x0, #-1]
    //     0xe8259c: and             x16, x17, x16, lsr #2
    //     0xe825a0: tst             x16, HEAP, lsr #32
    //     0xe825a4: b.eq            #0xe825ac
    //     0xe825a8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xe825ac: ldur            x1, [fp, #-0x10]
    // 0xe825b0: r0 = dateOnly()
    //     0xe825b0: bl              #0xd18a20  ; [package:flutter/src/material/date.dart] DateUtils::dateOnly
    // 0xe825b4: ldur            x2, [fp, #-8]
    // 0xe825b8: StoreField: r2->field_f = r0
    //     0xe825b8: stur            w0, [x2, #0xf]
    //     0xe825bc: ldurb           w16, [x2, #-1]
    //     0xe825c0: ldurb           w17, [x0, #-1]
    //     0xe825c4: and             x16, x17, x16, lsr #2
    //     0xe825c8: tst             x16, HEAP, lsr #32
    //     0xe825cc: b.eq            #0xe825d4
    //     0xe825d0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xe825d4: ldur            x1, [fp, #-0x18]
    // 0xe825d8: r0 = dateOnly()
    //     0xe825d8: bl              #0xd18a20  ; [package:flutter/src/material/date.dart] DateUtils::dateOnly
    // 0xe825dc: ldur            x2, [fp, #-8]
    // 0xe825e0: StoreField: r2->field_13 = r0
    //     0xe825e0: stur            w0, [x2, #0x13]
    //     0xe825e4: ldurb           w16, [x2, #-1]
    //     0xe825e8: ldurb           w17, [x0, #-1]
    //     0xe825ec: and             x16, x17, x16, lsr #2
    //     0xe825f0: tst             x16, HEAP, lsr #32
    //     0xe825f4: b.eq            #0xe825fc
    //     0xe825f8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xe825fc: r1 = Instance_GregorianCalendarDelegate
    //     0xe825fc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xe82600: ldr             x1, [x1, #0x538]
    // 0xe82604: r0 = now()
    //     0xe82604: bl              #0xaf3004  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::now
    // 0xe82608: mov             x1, x0
    // 0xe8260c: r0 = dateOnly()
    //     0xe8260c: bl              #0xd18a20  ; [package:flutter/src/material/date.dart] DateUtils::dateOnly
    // 0xe82610: ldur            x1, [fp, #-8]
    // 0xe82614: ArrayStore: r1[0] = r0  ; List_4
    //     0xe82614: stur            w0, [x1, #0x17]
    //     0xe82618: ldurb           w16, [x1, #-1]
    //     0xe8261c: ldurb           w17, [x0, #-1]
    //     0xe82620: and             x16, x17, x16, lsr #2
    //     0xe82624: tst             x16, HEAP, lsr #32
    //     0xe82628: b.eq            #0xe82630
    //     0xe8262c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xe82630: r0 = Null
    //     0xe82630: mov             x0, NULL
    // 0xe82634: LeaveFrame
    //     0xe82634: mov             SP, fp
    //     0xe82638: ldp             fp, lr, [SP], #0x10
    // 0xe8263c: ret
    //     0xe8263c: ret             
    // 0xe82640: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe82640: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe82644: b               #0xe82558
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa124c, size: 0x48
    // 0xfa124c: EnterFrame
    //     0xfa124c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa1250: mov             fp, SP
    // 0xfa1254: AllocStack(0x8)
    //     0xfa1254: sub             SP, SP, #8
    // 0xfa1258: CheckStackOverflow
    //     0xfa1258: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa125c: cmp             SP, x16
    //     0xfa1260: b.ls            #0xfa128c
    // 0xfa1264: r1 = <DatePickerDialog>
    //     0xfa1264: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8ff20] TypeArguments: <DatePickerDialog>
    //     0xfa1268: ldr             x1, [x1, #0xf20]
    // 0xfa126c: r0 = _DatePickerDialogState()
    //     0xfa126c: bl              #0xfa13f0  ; Allocate_DatePickerDialogStateStub -> _DatePickerDialogState (size=0x38)
    // 0xfa1270: mov             x1, x0
    // 0xfa1274: stur            x0, [fp, #-8]
    // 0xfa1278: r0 = _DatePickerDialogState()
    //     0xfa1278: bl              #0xfa1294  ; [package:flutter/src/material/date_picker.dart] _DatePickerDialogState::_DatePickerDialogState
    // 0xfa127c: ldur            x0, [fp, #-8]
    // 0xfa1280: LeaveFrame
    //     0xfa1280: mov             SP, fp
    //     0xfa1284: ldp             fp, lr, [SP], #0x10
    // 0xfa1288: ret
    //     0xfa1288: ret             
    // 0xfa128c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa128c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa1290: b               #0xfa1264
  }
}
