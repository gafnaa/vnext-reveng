// lib: , url: package:flutter/src/material/theme_data.dart

// class id: 1048969, size: 0x8
class :: {
}

// class id: 2963, size: 0x18, field offset: 0x8
class _FifoCache<X0, X1> extends Object {

  _ putIfAbsent(/* No info */) {
    // ** addr: 0x8a7970, size: 0x12c
    // 0x8a7970: EnterFrame
    //     0x8a7970: stp             fp, lr, [SP, #-0x10]!
    //     0x8a7974: mov             fp, SP
    // 0x8a7978: AllocStack(0x28)
    //     0x8a7978: sub             SP, SP, #0x28
    // 0x8a797c: SetupParameters(_FifoCache<X0, X1> this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x8a797c: mov             x5, x1
    //     0x8a7980: mov             x4, x2
    //     0x8a7984: stur            x1, [fp, #-8]
    //     0x8a7988: stur            x2, [fp, #-0x10]
    //     0x8a798c: stur            x3, [fp, #-0x18]
    // 0x8a7990: CheckStackOverflow
    //     0x8a7990: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a7994: cmp             SP, x16
    //     0x8a7998: b.ls            #0x8a7a94
    // 0x8a799c: LoadField: r2 = r5->field_7
    //     0x8a799c: ldur            w2, [x5, #7]
    // 0x8a79a0: DecompressPointer r2
    //     0x8a79a0: add             x2, x2, HEAP, lsl #32
    // 0x8a79a4: mov             x0, x3
    // 0x8a79a8: r1 = Null
    //     0x8a79a8: mov             x1, NULL
    // 0x8a79ac: r8 = (dynamic this) => X1
    //     0x8a79ac: ldr             x8, [PP, #0x1540]  ; [pp+0x1540] FunctionType: (dynamic this) => X1
    // 0x8a79b0: LoadField: r9 = r8->field_7
    //     0x8a79b0: ldur            x9, [x8, #7]
    // 0x8a79b4: r3 = Null
    //     0x8a79b4: add             x3, PP, #0x12, lsl #12  ; [pp+0x12968] Null
    //     0x8a79b8: ldr             x3, [x3, #0x968]
    // 0x8a79bc: blr             x9
    // 0x8a79c0: ldur            x0, [fp, #-8]
    // 0x8a79c4: LoadField: r3 = r0->field_b
    //     0x8a79c4: ldur            w3, [x0, #0xb]
    // 0x8a79c8: DecompressPointer r3
    //     0x8a79c8: add             x3, x3, HEAP, lsl #32
    // 0x8a79cc: mov             x1, x3
    // 0x8a79d0: ldur            x2, [fp, #-0x10]
    // 0x8a79d4: stur            x3, [fp, #-0x20]
    // 0x8a79d8: r0 = _getValueOrData()
    //     0x8a79d8: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8a79dc: mov             x1, x0
    // 0x8a79e0: ldur            x0, [fp, #-0x20]
    // 0x8a79e4: LoadField: r2 = r0->field_f
    //     0x8a79e4: ldur            w2, [x0, #0xf]
    // 0x8a79e8: DecompressPointer r2
    //     0x8a79e8: add             x2, x2, HEAP, lsl #32
    // 0x8a79ec: cmp             w2, w1
    // 0x8a79f0: b.ne            #0x8a79f8
    // 0x8a79f4: r1 = Null
    //     0x8a79f4: mov             x1, NULL
    // 0x8a79f8: cmp             w1, NULL
    // 0x8a79fc: b.eq            #0x8a7a10
    // 0x8a7a00: mov             x0, x1
    // 0x8a7a04: LeaveFrame
    //     0x8a7a04: mov             SP, fp
    //     0x8a7a08: ldp             fp, lr, [SP], #0x10
    // 0x8a7a0c: ret
    //     0x8a7a0c: ret             
    // 0x8a7a10: LoadField: r1 = r0->field_13
    //     0x8a7a10: ldur            w1, [x0, #0x13]
    // 0x8a7a14: r2 = LoadInt32Instr(r1)
    //     0x8a7a14: sbfx            x2, x1, #1, #0x1f
    // 0x8a7a18: asr             x1, x2, #1
    // 0x8a7a1c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x8a7a1c: ldur            w2, [x0, #0x17]
    // 0x8a7a20: r3 = LoadInt32Instr(r2)
    //     0x8a7a20: sbfx            x3, x2, #1, #0x1f
    // 0x8a7a24: sub             x2, x1, x3
    // 0x8a7a28: cmp             x2, #5
    // 0x8a7a2c: b.ne            #0x8a7a58
    // 0x8a7a30: r1 = <_IdentityThemeDataCacheKey, ThemeData>
    //     0x8a7a30: add             x1, PP, #0x12, lsl #12  ; [pp+0x12978] TypeArguments: <_IdentityThemeDataCacheKey, ThemeData>
    //     0x8a7a34: ldr             x1, [x1, #0x978]
    // 0x8a7a38: r0 = _CompactKeysIterable()
    //     0x8a7a38: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0x8a7a3c: mov             x1, x0
    // 0x8a7a40: ldur            x0, [fp, #-0x20]
    // 0x8a7a44: StoreField: r1->field_b = r0
    //     0x8a7a44: stur            w0, [x1, #0xb]
    // 0x8a7a48: r0 = first()
    //     0x8a7a48: bl              #0xb07084  ; [dart:core] Iterable::first
    // 0x8a7a4c: ldur            x1, [fp, #-0x20]
    // 0x8a7a50: mov             x2, x0
    // 0x8a7a54: r0 = remove()
    //     0x8a7a54: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x8a7a58: ldur            x16, [fp, #-0x18]
    // 0x8a7a5c: str             x16, [SP]
    // 0x8a7a60: ldur            x0, [fp, #-0x18]
    // 0x8a7a64: ClosureCall
    //     0x8a7a64: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x8a7a68: ldur            x2, [x0, #0x1f]
    //     0x8a7a6c: blr             x2
    // 0x8a7a70: ldur            x1, [fp, #-0x20]
    // 0x8a7a74: ldur            x2, [fp, #-0x10]
    // 0x8a7a78: mov             x3, x0
    // 0x8a7a7c: stur            x0, [fp, #-8]
    // 0x8a7a80: r0 = []=()
    //     0x8a7a80: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8a7a84: ldur            x0, [fp, #-8]
    // 0x8a7a88: LeaveFrame
    //     0x8a7a88: mov             SP, fp
    //     0x8a7a8c: ldp             fp, lr, [SP], #0x10
    // 0x8a7a90: ret
    //     0x8a7a90: ret             
    // 0x8a7a94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a7a94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a7a98: b               #0x8a799c
  }
}

// class id: 2964, size: 0x10, field offset: 0x8
//   const constructor, 
class _IdentityThemeDataCacheKey extends Object {

  get _ hashCode(/* No info */) {
    // ** addr: 0x114b690, size: 0x70
    // 0x114b690: EnterFrame
    //     0x114b690: stp             fp, lr, [SP, #-0x10]!
    //     0x114b694: mov             fp, SP
    // 0x114b698: AllocStack(0x10)
    //     0x114b698: sub             SP, SP, #0x10
    // 0x114b69c: CheckStackOverflow
    //     0x114b69c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114b6a0: cmp             SP, x16
    //     0x114b6a4: b.ls            #0x114b6f8
    // 0x114b6a8: ldr             x0, [fp, #0x10]
    // 0x114b6ac: LoadField: r1 = r0->field_7
    //     0x114b6ac: ldur            w1, [x0, #7]
    // 0x114b6b0: DecompressPointer r1
    //     0x114b6b0: add             x1, x1, HEAP, lsl #32
    // 0x114b6b4: str             x1, [SP]
    // 0x114b6b8: r0 = _getHash()
    //     0x114b6b8: bl              #0x84c644  ; [dart:core] ::_getHash
    // 0x114b6bc: mov             x1, x0
    // 0x114b6c0: ldr             x0, [fp, #0x10]
    // 0x114b6c4: stur            x1, [fp, #-8]
    // 0x114b6c8: LoadField: r2 = r0->field_b
    //     0x114b6c8: ldur            w2, [x0, #0xb]
    // 0x114b6cc: DecompressPointer r2
    //     0x114b6cc: add             x2, x2, HEAP, lsl #32
    // 0x114b6d0: str             x2, [SP]
    // 0x114b6d4: r0 = _getHash()
    //     0x114b6d4: bl              #0x84c644  ; [dart:core] ::_getHash
    // 0x114b6d8: ldur            x1, [fp, #-8]
    // 0x114b6dc: r2 = LoadInt32Instr(r1)
    //     0x114b6dc: sbfx            x2, x1, #1, #0x1f
    // 0x114b6e0: r1 = LoadInt32Instr(r0)
    //     0x114b6e0: sbfx            x1, x0, #1, #0x1f
    // 0x114b6e4: eor             x3, x2, x1
    // 0x114b6e8: lsl             x0, x3, #1
    // 0x114b6ec: LeaveFrame
    //     0x114b6ec: mov             SP, fp
    //     0x114b6f0: ldp             fp, lr, [SP], #0x10
    // 0x114b6f4: ret
    //     0x114b6f4: ret             
    // 0x114b6f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114b6f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114b6fc: b               #0x114b6a8
  }
  _ ==(/* No info */) {
    // ** addr: 0x1297d80, size: 0x78
    // 0x1297d80: ldr             x1, [SP]
    // 0x1297d84: cmp             w1, NULL
    // 0x1297d88: b.ne            #0x1297d94
    // 0x1297d8c: r0 = false
    //     0x1297d8c: add             x0, NULL, #0x30  ; false
    // 0x1297d90: ret
    //     0x1297d90: ret             
    // 0x1297d94: r2 = 60
    //     0x1297d94: mov             x2, #0x3c
    // 0x1297d98: branchIfSmi(r1, 0x1297da4)
    //     0x1297d98: tbz             w1, #0, #0x1297da4
    // 0x1297d9c: r2 = LoadClassIdInstr(r1)
    //     0x1297d9c: ldur            x2, [x1, #-1]
    //     0x1297da0: ubfx            x2, x2, #0xc, #0x14
    // 0x1297da4: cmp             x2, #0xb94
    // 0x1297da8: b.ne            #0x1297df0
    // 0x1297dac: ldr             x2, [SP, #8]
    // 0x1297db0: LoadField: r3 = r1->field_7
    //     0x1297db0: ldur            w3, [x1, #7]
    // 0x1297db4: DecompressPointer r3
    //     0x1297db4: add             x3, x3, HEAP, lsl #32
    // 0x1297db8: LoadField: r4 = r2->field_7
    //     0x1297db8: ldur            w4, [x2, #7]
    // 0x1297dbc: DecompressPointer r4
    //     0x1297dbc: add             x4, x4, HEAP, lsl #32
    // 0x1297dc0: cmp             w3, w4
    // 0x1297dc4: b.ne            #0x1297df0
    // 0x1297dc8: LoadField: r3 = r1->field_b
    //     0x1297dc8: ldur            w3, [x1, #0xb]
    // 0x1297dcc: DecompressPointer r3
    //     0x1297dcc: add             x3, x3, HEAP, lsl #32
    // 0x1297dd0: LoadField: r1 = r2->field_b
    //     0x1297dd0: ldur            w1, [x2, #0xb]
    // 0x1297dd4: DecompressPointer r1
    //     0x1297dd4: add             x1, x1, HEAP, lsl #32
    // 0x1297dd8: cmp             w3, w1
    // 0x1297ddc: r16 = true
    //     0x1297ddc: add             x16, NULL, #0x20  ; true
    // 0x1297de0: r17 = false
    //     0x1297de0: add             x17, NULL, #0x30  ; false
    // 0x1297de4: csel            x2, x16, x17, eq
    // 0x1297de8: mov             x0, x2
    // 0x1297dec: b               #0x1297df4
    // 0x1297df0: r0 = false
    //     0x1297df0: add             x0, NULL, #0x30  ; false
    // 0x1297df4: ret
    //     0x1297df4: ret             
  }
}

// class id: 2965, size: 0xc, field offset: 0x8
class CupertinoBasedMaterialThemeData extends Object {

  _ CupertinoBasedMaterialThemeData(/* No info */) {
    // ** addr: 0x8a9b68, size: 0xb0
    // 0x8a9b68: EnterFrame
    //     0x8a9b68: stp             fp, lr, [SP, #-0x10]!
    //     0x8a9b6c: mov             fp, SP
    // 0x8a9b70: AllocStack(0x20)
    //     0x8a9b70: sub             SP, SP, #0x20
    // 0x8a9b74: SetupParameters(CupertinoBasedMaterialThemeData this /* r1 => r0, fp-0x8 */)
    //     0x8a9b74: mov             x0, x1
    //     0x8a9b78: stur            x1, [fp, #-8]
    // 0x8a9b7c: CheckStackOverflow
    //     0x8a9b7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a9b80: cmp             SP, x16
    //     0x8a9b84: b.ls            #0x8a9c10
    // 0x8a9b88: LoadField: r1 = r2->field_2b
    //     0x8a9b88: ldur            w1, [x2, #0x2b]
    // 0x8a9b8c: DecompressPointer r1
    //     0x8a9b8c: add             x1, x1, HEAP, lsl #32
    // 0x8a9b90: LoadField: r2 = r1->field_3f
    //     0x8a9b90: ldur            w2, [x1, #0x3f]
    // 0x8a9b94: DecompressPointer r2
    //     0x8a9b94: add             x2, x2, HEAP, lsl #32
    // 0x8a9b98: LoadField: r1 = r2->field_b
    //     0x8a9b98: ldur            w1, [x2, #0xb]
    // 0x8a9b9c: DecompressPointer r1
    //     0x8a9b9c: add             x1, x1, HEAP, lsl #32
    // 0x8a9ba0: LoadField: r3 = r2->field_7
    //     0x8a9ba0: ldur            w3, [x2, #7]
    // 0x8a9ba4: DecompressPointer r3
    //     0x8a9ba4: add             x3, x3, HEAP, lsl #32
    // 0x8a9ba8: LoadField: r4 = r2->field_f
    //     0x8a9ba8: ldur            w4, [x2, #0xf]
    // 0x8a9bac: DecompressPointer r4
    //     0x8a9bac: add             x4, x4, HEAP, lsl #32
    // 0x8a9bb0: stp             x1, x3, [SP, #8]
    // 0x8a9bb4: str             x4, [SP]
    // 0x8a9bb8: mov             x2, x1
    // 0x8a9bbc: r1 = Null
    //     0x8a9bbc: mov             x1, NULL
    // 0x8a9bc0: r4 = const [0, 0x5, 0x3, 0x2, brightness, 0x2, onPrimary, 0x4, primary, 0x3, null]
    //     0x8a9bc0: add             x4, PP, #0x12, lsl #12  ; [pp+0x12980] List(11) [0, 0x5, 0x3, 0x2, "brightness", 0x2, "onPrimary", 0x4, "primary", 0x3, Null]
    //     0x8a9bc4: ldr             x4, [x4, #0x980]
    // 0x8a9bc8: r0 = ColorScheme.fromSeed()
    //     0x8a9bc8: bl              #0x8ad91c  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::ColorScheme.fromSeed
    // 0x8a9bcc: str             x0, [SP]
    // 0x8a9bd0: r1 = Null
    //     0x8a9bd0: mov             x1, NULL
    // 0x8a9bd4: r4 = const [0, 0x2, 0x1, 0x1, colorScheme, 0x1, null]
    //     0x8a9bd4: add             x4, PP, #0x12, lsl #12  ; [pp+0x12988] List(7) [0, 0x2, 0x1, 0x1, "colorScheme", 0x1, Null]
    //     0x8a9bd8: ldr             x4, [x4, #0x988]
    // 0x8a9bdc: r0 = ThemeData()
    //     0x8a9bdc: bl              #0x8a9c18  ; [package:flutter/src/material/theme_data.dart] ThemeData::ThemeData
    // 0x8a9be0: ldur            x1, [fp, #-8]
    // 0x8a9be4: StoreField: r1->field_7 = r0
    //     0x8a9be4: stur            w0, [x1, #7]
    //     0x8a9be8: ldurb           w16, [x1, #-1]
    //     0x8a9bec: ldurb           w17, [x0, #-1]
    //     0x8a9bf0: and             x16, x17, x16, lsr #2
    //     0x8a9bf4: tst             x16, HEAP, lsr #32
    //     0x8a9bf8: b.eq            #0x8a9c00
    //     0x8a9bfc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8a9c00: r0 = Null
    //     0x8a9c00: mov             x0, NULL
    // 0x8a9c04: LeaveFrame
    //     0x8a9c04: mov             SP, fp
    //     0x8a9c08: ldp             fp, lr, [SP], #0x10
    // 0x8a9c0c: ret
    //     0x8a9c0c: ret             
    // 0x8a9c10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a9c10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a9c14: b               #0x8a9b88
  }
}

// class id: 2966, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class ThemeExtension<X0 bound ThemeExtension> extends Object {
}

// class id: 2971, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class Adaptation<X0> extends Object {
}

// class id: 4618, size: 0x34, field offset: 0x2c
class MaterialBasedCupertinoThemeData extends CupertinoThemeData {

  _ resolveFrom(/* No info */) {
    // ** addr: 0x121ed00, size: 0xb0
    // 0x121ed00: EnterFrame
    //     0x121ed00: stp             fp, lr, [SP, #-0x10]!
    //     0x121ed04: mov             fp, SP
    // 0x121ed08: AllocStack(0x18)
    //     0x121ed08: sub             SP, SP, #0x18
    // 0x121ed0c: SetupParameters(MaterialBasedCupertinoThemeData this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x121ed0c: mov             x0, x1
    //     0x121ed10: stur            x1, [fp, #-0x10]
    //     0x121ed14: stur            x2, [fp, #-0x18]
    // 0x121ed18: CheckStackOverflow
    //     0x121ed18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121ed1c: cmp             SP, x16
    //     0x121ed20: b.ls            #0x121eda8
    // 0x121ed24: LoadField: r3 = r0->field_2f
    //     0x121ed24: ldur            w3, [x0, #0x2f]
    // 0x121ed28: DecompressPointer r3
    //     0x121ed28: add             x3, x3, HEAP, lsl #32
    // 0x121ed2c: mov             x1, x0
    // 0x121ed30: stur            x3, [fp, #-8]
    // 0x121ed34: r0 = textTheme()
    //     0x121ed34: bl              #0x1282dd4  ; [package:flutter/src/cupertino/theme.dart] CupertinoThemeData::textTheme
    // 0x121ed38: ldur            x1, [fp, #-8]
    // 0x121ed3c: mov             x2, x0
    // 0x121ed40: r0 = copyWith()
    //     0x121ed40: bl              #0x121edb0  ; [package:flutter/src/cupertino/theme.dart] NoDefaultCupertinoThemeData::copyWith
    // 0x121ed44: mov             x1, x0
    // 0x121ed48: ldur            x0, [fp, #-0x10]
    // 0x121ed4c: LoadField: r3 = r0->field_2b
    //     0x121ed4c: ldur            w3, [x0, #0x2b]
    // 0x121ed50: DecompressPointer r3
    //     0x121ed50: add             x3, x3, HEAP, lsl #32
    // 0x121ed54: ldur            x2, [fp, #-0x18]
    // 0x121ed58: stur            x3, [fp, #-8]
    // 0x121ed5c: r0 = resolveFrom()
    //     0x121ed5c: bl              #0x121f1e0  ; [package:flutter/src/cupertino/theme.dart] NoDefaultCupertinoThemeData::resolveFrom
    // 0x121ed60: stur            x0, [fp, #-0x10]
    // 0x121ed64: r0 = MaterialBasedCupertinoThemeData()
    //     0x121ed64: bl              #0xfbf138  ; AllocateMaterialBasedCupertinoThemeDataStub -> MaterialBasedCupertinoThemeData (size=0x34)
    // 0x121ed68: ldur            x1, [fp, #-8]
    // 0x121ed6c: StoreField: r0->field_2b = r1
    //     0x121ed6c: stur            w1, [x0, #0x2b]
    // 0x121ed70: ldur            x1, [fp, #-0x10]
    // 0x121ed74: StoreField: r0->field_2f = r1
    //     0x121ed74: stur            w1, [x0, #0x2f]
    // 0x121ed78: LoadField: r2 = r1->field_13
    //     0x121ed78: ldur            w2, [x1, #0x13]
    // 0x121ed7c: DecompressPointer r2
    //     0x121ed7c: add             x2, x2, HEAP, lsl #32
    // 0x121ed80: LoadField: r3 = r1->field_23
    //     0x121ed80: ldur            w3, [x1, #0x23]
    // 0x121ed84: DecompressPointer r3
    //     0x121ed84: add             x3, x3, HEAP, lsl #32
    // 0x121ed88: r1 = Instance__CupertinoThemeDefaults
    //     0x121ed88: add             x1, PP, #0x26, lsl #12  ; [pp+0x26b48] Obj!_CupertinoThemeDefaults@129f2b1
    //     0x121ed8c: ldr             x1, [x1, #0xb48]
    // 0x121ed90: StoreField: r0->field_27 = r1
    //     0x121ed90: stur            w1, [x0, #0x27]
    // 0x121ed94: StoreField: r0->field_13 = r2
    //     0x121ed94: stur            w2, [x0, #0x13]
    // 0x121ed98: StoreField: r0->field_23 = r3
    //     0x121ed98: stur            w3, [x0, #0x23]
    // 0x121ed9c: LeaveFrame
    //     0x121ed9c: mov             SP, fp
    //     0x121eda0: ldp             fp, lr, [SP], #0x10
    // 0x121eda4: ret
    //     0x121eda4: ret             
    // 0x121eda8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121eda8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121edac: b               #0x121ed24
  }
  get _ primaryColor(/* No info */) {
    // ** addr: 0x12b1150, size: 0x1c
    // 0x12b1150: LoadField: r2 = r1->field_2b
    //     0x12b1150: ldur            w2, [x1, #0x2b]
    // 0x12b1154: DecompressPointer r2
    //     0x12b1154: add             x2, x2, HEAP, lsl #32
    // 0x12b1158: LoadField: r1 = r2->field_3f
    //     0x12b1158: ldur            w1, [x2, #0x3f]
    // 0x12b115c: DecompressPointer r1
    //     0x12b115c: add             x1, x1, HEAP, lsl #32
    // 0x12b1160: LoadField: r0 = r1->field_b
    //     0x12b1160: ldur            w0, [x1, #0xb]
    // 0x12b1164: DecompressPointer r0
    //     0x12b1164: add             x0, x0, HEAP, lsl #32
    // 0x12b1168: ret
    //     0x12b1168: ret             
  }
}

// class id: 5053, size: 0x18, field offset: 0x8
//   const constructor, 
class VisualDensity extends _MixinApplication3&Object&Diagnosticable {

  _Mint field_8;
  _Mint field_10;

  get _ baseSizeAdjustment(/* No info */) {
    // ** addr: 0xb2496c, size: 0x5c
    // 0xb2496c: EnterFrame
    //     0xb2496c: stp             fp, lr, [SP, #-0x10]!
    //     0xb24970: mov             fp, SP
    // 0xb24974: AllocStack(0x10)
    //     0xb24974: sub             SP, SP, #0x10
    // 0xb24978: CheckStackOverflow
    //     0xb24978: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2497c: cmp             SP, x16
    //     0xb24980: b.ls            #0xb249c0
    // 0xb24984: LoadField: d0 = r1->field_7
    //     0xb24984: ldur            d0, [x1, #7]
    // 0xb24988: stur            d0, [fp, #-0x10]
    // 0xb2498c: LoadField: d1 = r1->field_f
    //     0xb2498c: ldur            d1, [x1, #0xf]
    // 0xb24990: stur            d1, [fp, #-8]
    // 0xb24994: r0 = Offset()
    //     0xb24994: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb24998: ldur            d0, [fp, #-0x10]
    // 0xb2499c: StoreField: r0->field_7 = d0
    //     0xb2499c: stur            d0, [x0, #7]
    // 0xb249a0: ldur            d0, [fp, #-8]
    // 0xb249a4: StoreField: r0->field_f = d0
    //     0xb249a4: stur            d0, [x0, #0xf]
    // 0xb249a8: mov             x1, x0
    // 0xb249ac: d0 = 4.000000
    //     0xb249ac: fmov            d0, #4.00000000
    // 0xb249b0: r0 = *()
    //     0xb249b0: bl              #0x81cecc  ; [dart:ui] Offset::*
    // 0xb249b4: LeaveFrame
    //     0xb249b4: mov             SP, fp
    //     0xb249b8: ldp             fp, lr, [SP], #0x10
    // 0xb249bc: ret
    //     0xb249bc: ret             
    // 0xb249c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb249c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb249c4: b               #0xb24984
  }
  _ effectiveConstraints(/* No info */) {
    // ** addr: 0xd0cad0, size: 0x188
    // 0xd0cad0: EnterFrame
    //     0xd0cad0: stp             fp, lr, [SP, #-0x10]!
    //     0xd0cad4: mov             fp, SP
    // 0xd0cad8: AllocStack(0x30)
    //     0xd0cad8: sub             SP, SP, #0x30
    // 0xd0cadc: SetupParameters(VisualDensity this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xd0cadc: mov             x0, x2
    //     0xd0cae0: stur            x2, [fp, #-0x10]
    //     0xd0cae4: mov             x2, x1
    //     0xd0cae8: stur            x1, [fp, #-8]
    // 0xd0caec: CheckStackOverflow
    //     0xd0caec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0caf0: cmp             SP, x16
    //     0xd0caf4: b.ls            #0xd0cc1c
    // 0xd0caf8: LoadField: d0 = r0->field_7
    //     0xd0caf8: ldur            d0, [x0, #7]
    // 0xd0cafc: mov             x1, x2
    // 0xd0cb00: stur            d0, [fp, #-0x18]
    // 0xd0cb04: r0 = baseSizeAdjustment()
    //     0xd0cb04: bl              #0xb2496c  ; [package:flutter/src/material/theme_data.dart] VisualDensity::baseSizeAdjustment
    // 0xd0cb08: LoadField: d0 = r0->field_7
    //     0xd0cb08: ldur            d0, [x0, #7]
    // 0xd0cb0c: ldur            d1, [fp, #-0x18]
    // 0xd0cb10: fadd            d2, d1, d0
    // 0xd0cb14: ldur            x0, [fp, #-0x10]
    // 0xd0cb18: LoadField: d0 = r0->field_f
    //     0xd0cb18: ldur            d0, [x0, #0xf]
    // 0xd0cb1c: d1 = 0.000000
    //     0xd0cb1c: eor             v1.16b, v1.16b, v1.16b
    // 0xd0cb20: fcmp            d1, d2
    // 0xd0cb24: b.le            #0xd0cb30
    // 0xd0cb28: d0 = 0.000000
    //     0xd0cb28: eor             v0.16b, v0.16b, v0.16b
    // 0xd0cb2c: b               #0xd0cb44
    // 0xd0cb30: fcmp            d2, d0
    // 0xd0cb34: b.gt            #0xd0cb44
    // 0xd0cb38: fcmp            d2, d2
    // 0xd0cb3c: b.vs            #0xd0cb44
    // 0xd0cb40: mov             v0.16b, v2.16b
    // 0xd0cb44: stur            d0, [fp, #-0x20]
    // 0xd0cb48: ArrayLoad: d2 = r0[0]  ; List_8
    //     0xd0cb48: ldur            d2, [x0, #0x17]
    // 0xd0cb4c: ldur            x1, [fp, #-8]
    // 0xd0cb50: stur            d2, [fp, #-0x18]
    // 0xd0cb54: r0 = baseSizeAdjustment()
    //     0xd0cb54: bl              #0xb2496c  ; [package:flutter/src/material/theme_data.dart] VisualDensity::baseSizeAdjustment
    // 0xd0cb58: LoadField: d0 = r0->field_f
    //     0xd0cb58: ldur            d0, [x0, #0xf]
    // 0xd0cb5c: ldur            d1, [fp, #-0x18]
    // 0xd0cb60: fadd            d2, d1, d0
    // 0xd0cb64: ldur            x1, [fp, #-0x10]
    // 0xd0cb68: LoadField: d0 = r1->field_1f
    //     0xd0cb68: ldur            d0, [x1, #0x1f]
    // 0xd0cb6c: d1 = 0.000000
    //     0xd0cb6c: eor             v1.16b, v1.16b, v1.16b
    // 0xd0cb70: fcmp            d1, d2
    // 0xd0cb74: b.le            #0xd0cb80
    // 0xd0cb78: d1 = 0.000000
    //     0xd0cb78: eor             v1.16b, v1.16b, v1.16b
    // 0xd0cb7c: b               #0xd0cba4
    // 0xd0cb80: fcmp            d2, d0
    // 0xd0cb84: b.le            #0xd0cb90
    // 0xd0cb88: mov             v1.16b, v0.16b
    // 0xd0cb8c: b               #0xd0cba4
    // 0xd0cb90: fcmp            d2, d2
    // 0xd0cb94: b.vc            #0xd0cba0
    // 0xd0cb98: mov             v1.16b, v0.16b
    // 0xd0cb9c: b               #0xd0cba4
    // 0xd0cba0: mov             v1.16b, v2.16b
    // 0xd0cba4: ldur            d0, [fp, #-0x20]
    // 0xd0cba8: r0 = inline_Allocate_Double()
    //     0xd0cba8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xd0cbac: add             x0, x0, #0x10
    //     0xd0cbb0: cmp             x2, x0
    //     0xd0cbb4: b.ls            #0xd0cc24
    //     0xd0cbb8: str             x0, [THR, #0x60]  ; THR::top
    //     0xd0cbbc: sub             x0, x0, #0xf
    //     0xd0cbc0: mov             x2, #0xe19c
    //     0xd0cbc4: movk            x2, #3, lsl #16
    //     0xd0cbc8: stur            x2, [x0, #-1]
    // 0xd0cbcc: dmb             ishst
    // 0xd0cbd0: StoreField: r0->field_7 = d0
    //     0xd0cbd0: stur            d0, [x0, #7]
    // 0xd0cbd4: r2 = inline_Allocate_Double()
    //     0xd0cbd4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xd0cbd8: add             x2, x2, #0x10
    //     0xd0cbdc: cmp             x3, x2
    //     0xd0cbe0: b.ls            #0xd0cc3c
    //     0xd0cbe4: str             x2, [THR, #0x60]  ; THR::top
    //     0xd0cbe8: sub             x2, x2, #0xf
    //     0xd0cbec: mov             x3, #0xe19c
    //     0xd0cbf0: movk            x3, #3, lsl #16
    //     0xd0cbf4: stur            x3, [x2, #-1]
    // 0xd0cbf8: dmb             ishst
    // 0xd0cbfc: StoreField: r2->field_7 = d1
    //     0xd0cbfc: stur            d1, [x2, #7]
    // 0xd0cc00: stp             x2, x0, [SP]
    // 0xd0cc04: r4 = const [0, 0x3, 0x2, 0x1, minHeight, 0x2, minWidth, 0x1, null]
    //     0xd0cc04: add             x4, PP, #0x80, lsl #12  ; [pp+0x80c58] List(9) [0, 0x3, 0x2, 0x1, "minHeight", 0x2, "minWidth", 0x1, Null]
    //     0xd0cc08: ldr             x4, [x4, #0xc58]
    // 0xd0cc0c: r0 = copyWith()
    //     0xd0cc0c: bl              #0xb4cfe8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::copyWith
    // 0xd0cc10: LeaveFrame
    //     0xd0cc10: mov             SP, fp
    //     0xd0cc14: ldp             fp, lr, [SP], #0x10
    // 0xd0cc18: ret
    //     0xd0cc18: ret             
    // 0xd0cc1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0cc1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0cc20: b               #0xd0caf8
    // 0xd0cc24: stp             q0, q1, [SP, #-0x20]!
    // 0xd0cc28: SaveReg r1
    //     0xd0cc28: str             x1, [SP, #-8]!
    // 0xd0cc2c: r0 = AllocateDouble()
    //     0xd0cc2c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd0cc30: RestoreReg r1
    //     0xd0cc30: ldr             x1, [SP], #8
    // 0xd0cc34: ldp             q0, q1, [SP], #0x20
    // 0xd0cc38: b               #0xd0cbd0
    // 0xd0cc3c: SaveReg d1
    //     0xd0cc3c: str             q1, [SP, #-0x10]!
    // 0xd0cc40: stp             x0, x1, [SP, #-0x10]!
    // 0xd0cc44: r0 = AllocateDouble()
    //     0xd0cc44: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd0cc48: mov             x2, x0
    // 0xd0cc4c: ldp             x0, x1, [SP], #0x10
    // 0xd0cc50: RestoreReg d1
    //     0xd0cc50: ldr             q1, [SP], #0x10
    // 0xd0cc54: b               #0xd0cbfc
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x116a5f8, size: 0x234
    // 0x116a5f8: EnterFrame
    //     0x116a5f8: stp             fp, lr, [SP, #-0x10]!
    //     0x116a5fc: mov             fp, SP
    // 0x116a600: AllocStack(0x28)
    //     0x116a600: sub             SP, SP, #0x28
    // 0x116a604: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0x116a604: mov             x4, x1
    //     0x116a608: mov             x0, x2
    //     0x116a60c: stur            x1, [fp, #-0x10]
    //     0x116a610: stur            x2, [fp, #-0x18]
    // 0x116a614: CheckStackOverflow
    //     0x116a614: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116a618: cmp             SP, x16
    //     0x116a61c: b.ls            #0x116a780
    // 0x116a620: cmp             w4, w0
    // 0x116a624: b.ne            #0x116a638
    // 0x116a628: mov             x0, x4
    // 0x116a62c: LeaveFrame
    //     0x116a62c: mov             SP, fp
    //     0x116a630: ldp             fp, lr, [SP], #0x10
    // 0x116a634: ret
    //     0x116a634: ret             
    // 0x116a638: LoadField: d1 = r4->field_7
    //     0x116a638: ldur            d1, [x4, #7]
    // 0x116a63c: LoadField: d2 = r0->field_7
    //     0x116a63c: ldur            d2, [x0, #7]
    // 0x116a640: r5 = inline_Allocate_Double()
    //     0x116a640: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x116a644: add             x5, x5, #0x10
    //     0x116a648: cmp             x1, x5
    //     0x116a64c: b.ls            #0x116a788
    //     0x116a650: str             x5, [THR, #0x60]  ; THR::top
    //     0x116a654: sub             x5, x5, #0xf
    //     0x116a658: mov             x1, #0xe19c
    //     0x116a65c: movk            x1, #3, lsl #16
    //     0x116a660: stur            x1, [x5, #-1]
    // 0x116a664: dmb             ishst
    // 0x116a668: StoreField: r5->field_7 = d0
    //     0x116a668: stur            d0, [x5, #7]
    // 0x116a66c: stur            x5, [fp, #-8]
    // 0x116a670: r1 = inline_Allocate_Double()
    //     0x116a670: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x116a674: add             x1, x1, #0x10
    //     0x116a678: cmp             x2, x1
    //     0x116a67c: b.ls            #0x116a7ac
    //     0x116a680: str             x1, [THR, #0x60]  ; THR::top
    //     0x116a684: sub             x1, x1, #0xf
    //     0x116a688: mov             x2, #0xe19c
    //     0x116a68c: movk            x2, #3, lsl #16
    //     0x116a690: stur            x2, [x1, #-1]
    // 0x116a694: dmb             ishst
    // 0x116a698: StoreField: r1->field_7 = d1
    //     0x116a698: stur            d1, [x1, #7]
    // 0x116a69c: r2 = inline_Allocate_Double()
    //     0x116a69c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x116a6a0: add             x2, x2, #0x10
    //     0x116a6a4: cmp             x3, x2
    //     0x116a6a8: b.ls            #0x116a7d0
    //     0x116a6ac: str             x2, [THR, #0x60]  ; THR::top
    //     0x116a6b0: sub             x2, x2, #0xf
    //     0x116a6b4: mov             x3, #0xe19c
    //     0x116a6b8: movk            x3, #3, lsl #16
    //     0x116a6bc: stur            x3, [x2, #-1]
    // 0x116a6c0: dmb             ishst
    // 0x116a6c4: StoreField: r2->field_7 = d2
    //     0x116a6c4: stur            d2, [x2, #7]
    // 0x116a6c8: mov             x3, x5
    // 0x116a6cc: r0 = lerpDouble()
    //     0x116a6cc: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x116a6d0: mov             x4, x0
    // 0x116a6d4: ldur            x0, [fp, #-0x10]
    // 0x116a6d8: stur            x4, [fp, #-0x20]
    // 0x116a6dc: LoadField: d0 = r0->field_f
    //     0x116a6dc: ldur            d0, [x0, #0xf]
    // 0x116a6e0: ldur            x0, [fp, #-0x18]
    // 0x116a6e4: LoadField: d1 = r0->field_f
    //     0x116a6e4: ldur            d1, [x0, #0xf]
    // 0x116a6e8: r1 = inline_Allocate_Double()
    //     0x116a6e8: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x116a6ec: add             x1, x1, #0x10
    //     0x116a6f0: cmp             x0, x1
    //     0x116a6f4: b.ls            #0x116a7f4
    //     0x116a6f8: str             x1, [THR, #0x60]  ; THR::top
    //     0x116a6fc: sub             x1, x1, #0xf
    //     0x116a700: mov             x0, #0xe19c
    //     0x116a704: movk            x0, #3, lsl #16
    //     0x116a708: stur            x0, [x1, #-1]
    // 0x116a70c: dmb             ishst
    // 0x116a710: StoreField: r1->field_7 = d0
    //     0x116a710: stur            d0, [x1, #7]
    // 0x116a714: r2 = inline_Allocate_Double()
    //     0x116a714: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x116a718: add             x2, x2, #0x10
    //     0x116a71c: cmp             x0, x2
    //     0x116a720: b.ls            #0x116a810
    //     0x116a724: str             x2, [THR, #0x60]  ; THR::top
    //     0x116a728: sub             x2, x2, #0xf
    //     0x116a72c: mov             x0, #0xe19c
    //     0x116a730: movk            x0, #3, lsl #16
    //     0x116a734: stur            x0, [x2, #-1]
    // 0x116a738: dmb             ishst
    // 0x116a73c: StoreField: r2->field_7 = d1
    //     0x116a73c: stur            d1, [x2, #7]
    // 0x116a740: ldur            x3, [fp, #-8]
    // 0x116a744: r0 = lerpDouble()
    //     0x116a744: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x116a748: mov             x1, x0
    // 0x116a74c: ldur            x0, [fp, #-0x20]
    // 0x116a750: stur            x1, [fp, #-8]
    // 0x116a754: LoadField: d0 = r0->field_7
    //     0x116a754: ldur            d0, [x0, #7]
    // 0x116a758: stur            d0, [fp, #-0x28]
    // 0x116a75c: r0 = VisualDensity()
    //     0x116a75c: bl              #0x116a82c  ; AllocateVisualDensityStub -> VisualDensity (size=0x18)
    // 0x116a760: ldur            d0, [fp, #-0x28]
    // 0x116a764: StoreField: r0->field_7 = d0
    //     0x116a764: stur            d0, [x0, #7]
    // 0x116a768: ldur            x1, [fp, #-8]
    // 0x116a76c: LoadField: d0 = r1->field_7
    //     0x116a76c: ldur            d0, [x1, #7]
    // 0x116a770: StoreField: r0->field_f = d0
    //     0x116a770: stur            d0, [x0, #0xf]
    // 0x116a774: LeaveFrame
    //     0x116a774: mov             SP, fp
    //     0x116a778: ldp             fp, lr, [SP], #0x10
    // 0x116a77c: ret
    //     0x116a77c: ret             
    // 0x116a780: r0 = StackOverflowSharedWithFPURegs()
    //     0x116a780: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x116a784: b               #0x116a620
    // 0x116a788: stp             q1, q2, [SP, #-0x20]!
    // 0x116a78c: SaveReg d0
    //     0x116a78c: str             q0, [SP, #-0x10]!
    // 0x116a790: stp             x0, x4, [SP, #-0x10]!
    // 0x116a794: r0 = AllocateDouble()
    //     0x116a794: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116a798: mov             x5, x0
    // 0x116a79c: ldp             x0, x4, [SP], #0x10
    // 0x116a7a0: RestoreReg d0
    //     0x116a7a0: ldr             q0, [SP], #0x10
    // 0x116a7a4: ldp             q1, q2, [SP], #0x20
    // 0x116a7a8: b               #0x116a668
    // 0x116a7ac: stp             q1, q2, [SP, #-0x20]!
    // 0x116a7b0: stp             x4, x5, [SP, #-0x10]!
    // 0x116a7b4: SaveReg r0
    //     0x116a7b4: str             x0, [SP, #-8]!
    // 0x116a7b8: r0 = AllocateDouble()
    //     0x116a7b8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116a7bc: mov             x1, x0
    // 0x116a7c0: RestoreReg r0
    //     0x116a7c0: ldr             x0, [SP], #8
    // 0x116a7c4: ldp             x4, x5, [SP], #0x10
    // 0x116a7c8: ldp             q1, q2, [SP], #0x20
    // 0x116a7cc: b               #0x116a698
    // 0x116a7d0: SaveReg d2
    //     0x116a7d0: str             q2, [SP, #-0x10]!
    // 0x116a7d4: stp             x4, x5, [SP, #-0x10]!
    // 0x116a7d8: stp             x0, x1, [SP, #-0x10]!
    // 0x116a7dc: r0 = AllocateDouble()
    //     0x116a7dc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116a7e0: mov             x2, x0
    // 0x116a7e4: ldp             x0, x1, [SP], #0x10
    // 0x116a7e8: ldp             x4, x5, [SP], #0x10
    // 0x116a7ec: RestoreReg d2
    //     0x116a7ec: ldr             q2, [SP], #0x10
    // 0x116a7f0: b               #0x116a6c4
    // 0x116a7f4: stp             q0, q1, [SP, #-0x20]!
    // 0x116a7f8: SaveReg r4
    //     0x116a7f8: str             x4, [SP, #-8]!
    // 0x116a7fc: r0 = AllocateDouble()
    //     0x116a7fc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116a800: mov             x1, x0
    // 0x116a804: RestoreReg r4
    //     0x116a804: ldr             x4, [SP], #8
    // 0x116a808: ldp             q0, q1, [SP], #0x20
    // 0x116a80c: b               #0x116a710
    // 0x116a810: SaveReg d1
    //     0x116a810: str             q1, [SP, #-0x10]!
    // 0x116a814: stp             x1, x4, [SP, #-0x10]!
    // 0x116a818: r0 = AllocateDouble()
    //     0x116a818: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116a81c: mov             x2, x0
    // 0x116a820: ldp             x1, x4, [SP], #0x10
    // 0x116a824: RestoreReg d1
    //     0x116a824: ldr             q1, [SP], #0x10
    // 0x116a828: b               #0x116a73c
  }
  _ ==(/* No info */) {
    // ** addr: 0x1278250, size: 0xe0
    // 0x1278250: EnterFrame
    //     0x1278250: stp             fp, lr, [SP, #-0x10]!
    //     0x1278254: mov             fp, SP
    // 0x1278258: AllocStack(0x10)
    //     0x1278258: sub             SP, SP, #0x10
    // 0x127825c: CheckStackOverflow
    //     0x127825c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1278260: cmp             SP, x16
    //     0x1278264: b.ls            #0x1278328
    // 0x1278268: ldr             x0, [fp, #0x10]
    // 0x127826c: cmp             w0, NULL
    // 0x1278270: b.ne            #0x1278284
    // 0x1278274: r0 = false
    //     0x1278274: add             x0, NULL, #0x30  ; false
    // 0x1278278: LeaveFrame
    //     0x1278278: mov             SP, fp
    //     0x127827c: ldp             fp, lr, [SP], #0x10
    // 0x1278280: ret
    //     0x1278280: ret             
    // 0x1278284: str             x0, [SP]
    // 0x1278288: r0 = runtimeType()
    //     0x1278288: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x127828c: r1 = LoadClassIdInstr(r0)
    //     0x127828c: ldur            x1, [x0, #-1]
    //     0x1278290: ubfx            x1, x1, #0xc, #0x14
    // 0x1278294: r16 = VisualDensity
    //     0x1278294: add             x16, PP, #0x26, lsl #12  ; [pp+0x26b20] Type: VisualDensity
    //     0x1278298: ldr             x16, [x16, #0xb20]
    // 0x127829c: stp             x16, x0, [SP]
    // 0x12782a0: mov             x0, x1
    // 0x12782a4: mov             lr, x0
    // 0x12782a8: ldr             lr, [x21, lr, lsl #3]
    // 0x12782ac: blr             lr
    // 0x12782b0: tbz             w0, #4, #0x12782c4
    // 0x12782b4: r0 = false
    //     0x12782b4: add             x0, NULL, #0x30  ; false
    // 0x12782b8: LeaveFrame
    //     0x12782b8: mov             SP, fp
    //     0x12782bc: ldp             fp, lr, [SP], #0x10
    // 0x12782c0: ret
    //     0x12782c0: ret             
    // 0x12782c4: ldr             x1, [fp, #0x10]
    // 0x12782c8: r2 = 60
    //     0x12782c8: mov             x2, #0x3c
    // 0x12782cc: branchIfSmi(r1, 0x12782d8)
    //     0x12782cc: tbz             w1, #0, #0x12782d8
    // 0x12782d0: r2 = LoadClassIdInstr(r1)
    //     0x12782d0: ldur            x2, [x1, #-1]
    //     0x12782d4: ubfx            x2, x2, #0xc, #0x14
    // 0x12782d8: r17 = 5053
    //     0x12782d8: mov             x17, #0x13bd
    // 0x12782dc: cmp             x2, x17
    // 0x12782e0: b.ne            #0x1278318
    // 0x12782e4: ldr             x2, [fp, #0x18]
    // 0x12782e8: LoadField: d0 = r1->field_7
    //     0x12782e8: ldur            d0, [x1, #7]
    // 0x12782ec: LoadField: d1 = r2->field_7
    //     0x12782ec: ldur            d1, [x2, #7]
    // 0x12782f0: fcmp            d0, d1
    // 0x12782f4: b.ne            #0x1278318
    // 0x12782f8: LoadField: d0 = r1->field_f
    //     0x12782f8: ldur            d0, [x1, #0xf]
    // 0x12782fc: LoadField: d1 = r2->field_f
    //     0x12782fc: ldur            d1, [x2, #0xf]
    // 0x1278300: fcmp            d0, d1
    // 0x1278304: r16 = true
    //     0x1278304: add             x16, NULL, #0x20  ; true
    // 0x1278308: r17 = false
    //     0x1278308: add             x17, NULL, #0x30  ; false
    // 0x127830c: csel            x1, x16, x17, eq
    // 0x1278310: mov             x0, x1
    // 0x1278314: b               #0x127831c
    // 0x1278318: r0 = false
    //     0x1278318: add             x0, NULL, #0x30  ; false
    // 0x127831c: LeaveFrame
    //     0x127831c: mov             SP, fp
    //     0x1278320: ldp             fp, lr, [SP], #0x10
    // 0x1278324: ret
    //     0x1278324: ret             
    // 0x1278328: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1278328: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x127832c: b               #0x1278268
  }
}

// class id: 5054, size: 0x154, field offset: 0x8
//   const constructor, 
class ThemeData extends _MixinApplication3&Object&Diagnosticable {

  static late final _FifoCache<_IdentityThemeDataCacheKey, ThemeData> _localizedThemeDataCache; // offset: 0x704

  Y0? extension<Y0>(ThemeData) {
    // ** addr: 0x8a75cc, size: 0xe4
    // 0x8a75cc: EnterFrame
    //     0x8a75cc: stp             fp, lr, [SP, #-0x10]!
    //     0x8a75d0: mov             fp, SP
    // 0x8a75d4: AllocStack(0x10)
    //     0x8a75d4: sub             SP, SP, #0x10
    // 0x8a75d8: SetupParameters([dynamic _ /* r0 */])
    //     0x8a75d8: ldur            w0, [x4, #0xf]
    //     0x8a75dc: cbnz            w0, #0x8a75e8
    //     0x8a75e0: mov             x3, NULL
    //     0x8a75e4: b               #0x8a75f8
    //     0x8a75e8: ldur            w0, [x4, #0x17]
    //     0x8a75ec: add             x1, fp, w0, sxtw #2
    //     0x8a75f0: ldr             x1, [x1, #0x10]
    //     0x8a75f4: mov             x3, x1
    //     0x8a75f8: ldr             x0, [fp, #0x10]
    //     0x8a75fc: stur            x3, [fp, #-0x10]
    // 0x8a7600: CheckStackOverflow
    //     0x8a7600: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a7604: cmp             SP, x16
    //     0x8a7608: b.ls            #0x8a76a8
    // 0x8a760c: LoadField: r4 = r0->field_f
    //     0x8a760c: ldur            w4, [x0, #0xf]
    // 0x8a7610: DecompressPointer r4
    //     0x8a7610: add             x4, x4, HEAP, lsl #32
    // 0x8a7614: mov             x1, x3
    // 0x8a7618: stur            x4, [fp, #-8]
    // 0x8a761c: r2 = Null
    //     0x8a761c: mov             x2, NULL
    // 0x8a7620: r3 = Y0
    //     0x8a7620: add             x3, PP, #0x12, lsl #12  ; [pp+0x12888] TypeParameter: Y0
    //     0x8a7624: ldr             x3, [x3, #0x888]
    // 0x8a7628: r30 = InstantiateTypeNonNullableFunctionTypeParameterStub
    //     0x8a7628: ldr             lr, [PP, #0x1fe8]  ; [pp+0x1fe8] Stub: InstantiateTypeNonNullableFunctionTypeParameter (0x7c1180)
    // 0x8a762c: LoadField: r30 = r30->field_7
    //     0x8a762c: ldur            lr, [lr, #7]
    // 0x8a7630: blr             lr
    // 0x8a7634: ldur            x1, [fp, #-8]
    // 0x8a7638: r2 = LoadClassIdInstr(r1)
    //     0x8a7638: ldur            x2, [x1, #-1]
    //     0x8a763c: ubfx            x2, x2, #0xc, #0x14
    // 0x8a7640: mov             x16, x0
    // 0x8a7644: mov             x0, x2
    // 0x8a7648: mov             x2, x16
    // 0x8a764c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8a764c: sub             lr, x0, #0xd48
    //     0x8a7650: ldr             lr, [x21, lr, lsl #3]
    //     0x8a7654: blr             lr
    // 0x8a7658: ldur            x1, [fp, #-0x10]
    // 0x8a765c: mov             x3, x0
    // 0x8a7660: r2 = Null
    //     0x8a7660: mov             x2, NULL
    // 0x8a7664: stur            x3, [fp, #-8]
    // 0x8a7668: cmp             w0, NULL
    // 0x8a766c: b.eq            #0x8a7698
    // 0x8a7670: cmp             w1, NULL
    // 0x8a7674: b.eq            #0x8a7698
    // 0x8a7678: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x8a7678: ldur            w4, [x1, #0x17]
    // 0x8a767c: DecompressPointer r4
    //     0x8a767c: add             x4, x4, HEAP, lsl #32
    // 0x8a7680: r8 = Y0?
    //     0x8a7680: add             x8, PP, #0x12, lsl #12  ; [pp+0x12890] TypeParameter: Y0?
    //     0x8a7684: ldr             x8, [x8, #0x890]
    // 0x8a7688: LoadField: r9 = r4->field_7
    //     0x8a7688: ldur            x9, [x4, #7]
    // 0x8a768c: r3 = Null
    //     0x8a768c: add             x3, PP, #0x12, lsl #12  ; [pp+0x12898] Null
    //     0x8a7690: ldr             x3, [x3, #0x898]
    // 0x8a7694: blr             x9
    // 0x8a7698: ldur            x0, [fp, #-8]
    // 0x8a769c: LeaveFrame
    //     0x8a769c: mov             SP, fp
    //     0x8a76a0: ldp             fp, lr, [SP], #0x10
    // 0x8a76a4: ret
    //     0x8a76a4: ret             
    // 0x8a76a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a76a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a76ac: b               #0x8a760c
  }
  static _ localize(/* No info */) {
    // ** addr: 0x8a78a0, size: 0xd0
    // 0x8a78a0: EnterFrame
    //     0x8a78a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8a78a4: mov             fp, SP
    // 0x8a78a8: AllocStack(0x28)
    //     0x8a78a8: sub             SP, SP, #0x28
    // 0x8a78ac: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8a78ac: stur            x1, [fp, #-8]
    //     0x8a78b0: stur            x2, [fp, #-0x10]
    // 0x8a78b4: CheckStackOverflow
    //     0x8a78b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a78b8: cmp             SP, x16
    //     0x8a78bc: b.ls            #0x8a7968
    // 0x8a78c0: r1 = 2
    //     0x8a78c0: mov             x1, #2
    // 0x8a78c4: r0 = AllocateContext()
    //     0x8a78c4: bl              #0x13de838  ; AllocateContextStub
    // 0x8a78c8: mov             x1, x0
    // 0x8a78cc: ldur            x0, [fp, #-8]
    // 0x8a78d0: stur            x1, [fp, #-0x18]
    // 0x8a78d4: StoreField: r1->field_f = r0
    //     0x8a78d4: stur            w0, [x1, #0xf]
    // 0x8a78d8: ldur            x0, [fp, #-0x10]
    // 0x8a78dc: StoreField: r1->field_13 = r0
    //     0x8a78dc: stur            w0, [x1, #0x13]
    // 0x8a78e0: r0 = LoadStaticField(0x704)
    //     0x8a78e0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8a78e4: ldr             x0, [x0, #0xe08]
    // 0x8a78e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8a78ec: cmp             w0, w16
    // 0x8a78f0: b.ne            #0x8a7900
    // 0x8a78f4: r2 = _localizedThemeDataCache
    //     0x8a78f4: add             x2, PP, #0x12, lsl #12  ; [pp+0x128d8] Field <ThemeData._localizedThemeDataCache@109408314>: static late final (offset: 0x704)
    //     0x8a78f8: ldr             x2, [x2, #0x8d8]
    // 0x8a78fc: r0 = InitLateFinalStaticField()
    //     0x8a78fc: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8a7900: ldur            x2, [fp, #-0x18]
    // 0x8a7904: stur            x0, [fp, #-0x20]
    // 0x8a7908: LoadField: r1 = r2->field_f
    //     0x8a7908: ldur            w1, [x2, #0xf]
    // 0x8a790c: DecompressPointer r1
    //     0x8a790c: add             x1, x1, HEAP, lsl #32
    // 0x8a7910: stur            x1, [fp, #-0x10]
    // 0x8a7914: LoadField: r3 = r2->field_13
    //     0x8a7914: ldur            w3, [x2, #0x13]
    // 0x8a7918: DecompressPointer r3
    //     0x8a7918: add             x3, x3, HEAP, lsl #32
    // 0x8a791c: stur            x3, [fp, #-8]
    // 0x8a7920: r0 = _IdentityThemeDataCacheKey()
    //     0x8a7920: bl              #0x8a7abc  ; Allocate_IdentityThemeDataCacheKeyStub -> _IdentityThemeDataCacheKey (size=0x10)
    // 0x8a7924: mov             x3, x0
    // 0x8a7928: ldur            x0, [fp, #-0x10]
    // 0x8a792c: stur            x3, [fp, #-0x28]
    // 0x8a7930: StoreField: r3->field_7 = r0
    //     0x8a7930: stur            w0, [x3, #7]
    // 0x8a7934: ldur            x0, [fp, #-8]
    // 0x8a7938: StoreField: r3->field_b = r0
    //     0x8a7938: stur            w0, [x3, #0xb]
    // 0x8a793c: ldur            x2, [fp, #-0x18]
    // 0x8a7940: r1 = Function '<anonymous closure>': static.
    //     0x8a7940: add             x1, PP, #0x12, lsl #12  ; [pp+0x128e0] AnonymousClosure: static (0x8a7ac8), in [package:flutter/src/material/theme_data.dart] ThemeData::localize (0x8a78a0)
    //     0x8a7944: ldr             x1, [x1, #0x8e0]
    // 0x8a7948: r0 = AllocateClosure()
    //     0x8a7948: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8a794c: ldur            x1, [fp, #-0x20]
    // 0x8a7950: ldur            x2, [fp, #-0x28]
    // 0x8a7954: mov             x3, x0
    // 0x8a7958: r0 = putIfAbsent()
    //     0x8a7958: bl              #0x8a7970  ; [package:flutter/src/material/theme_data.dart] _FifoCache::putIfAbsent
    // 0x8a795c: LeaveFrame
    //     0x8a795c: mov             SP, fp
    //     0x8a7960: ldp             fp, lr, [SP], #0x10
    // 0x8a7964: ret
    //     0x8a7964: ret             
    // 0x8a7968: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a7968: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a796c: b               #0x8a78c0
  }
  [closure] static ThemeData <anonymous closure>(dynamic) {
    // ** addr: 0x8a7ac8, size: 0xa0
    // 0x8a7ac8: EnterFrame
    //     0x8a7ac8: stp             fp, lr, [SP, #-0x10]!
    //     0x8a7acc: mov             fp, SP
    // 0x8a7ad0: AllocStack(0x28)
    //     0x8a7ad0: sub             SP, SP, #0x28
    // 0x8a7ad4: SetupParameters([dynamic _ /* r0 */])
    //     0x8a7ad4: ldr             x0, [fp, #0x10]
    //     0x8a7ad8: ldur            w3, [x0, #0x17]
    //     0x8a7adc: add             x3, x3, HEAP, lsl #32
    //     0x8a7ae0: stur            x3, [fp, #-0x10]
    // 0x8a7ae4: CheckStackOverflow
    //     0x8a7ae4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a7ae8: cmp             SP, x16
    //     0x8a7aec: b.ls            #0x8a7b60
    // 0x8a7af0: LoadField: r0 = r3->field_f
    //     0x8a7af0: ldur            w0, [x3, #0xf]
    // 0x8a7af4: DecompressPointer r0
    //     0x8a7af4: add             x0, x0, HEAP, lsl #32
    // 0x8a7af8: stur            x0, [fp, #-8]
    // 0x8a7afc: LoadField: r1 = r3->field_13
    //     0x8a7afc: ldur            w1, [x3, #0x13]
    // 0x8a7b00: DecompressPointer r1
    //     0x8a7b00: add             x1, x1, HEAP, lsl #32
    // 0x8a7b04: LoadField: r2 = r0->field_83
    //     0x8a7b04: ldur            w2, [x0, #0x83]
    // 0x8a7b08: DecompressPointer r2
    //     0x8a7b08: add             x2, x2, HEAP, lsl #32
    // 0x8a7b0c: r0 = merge()
    //     0x8a7b0c: bl              #0x8a91f8  ; [package:flutter/src/material/text_theme.dart] TextTheme::merge
    // 0x8a7b10: mov             x3, x0
    // 0x8a7b14: ldur            x0, [fp, #-0x10]
    // 0x8a7b18: stur            x3, [fp, #-0x18]
    // 0x8a7b1c: LoadField: r1 = r0->field_13
    //     0x8a7b1c: ldur            w1, [x0, #0x13]
    // 0x8a7b20: DecompressPointer r1
    //     0x8a7b20: add             x1, x1, HEAP, lsl #32
    // 0x8a7b24: LoadField: r2 = r0->field_f
    //     0x8a7b24: ldur            w2, [x0, #0xf]
    // 0x8a7b28: DecompressPointer r2
    //     0x8a7b28: add             x2, x2, HEAP, lsl #32
    // 0x8a7b2c: LoadField: r0 = r2->field_87
    //     0x8a7b2c: ldur            w0, [x2, #0x87]
    // 0x8a7b30: DecompressPointer r0
    //     0x8a7b30: add             x0, x0, HEAP, lsl #32
    // 0x8a7b34: mov             x2, x0
    // 0x8a7b38: r0 = merge()
    //     0x8a7b38: bl              #0x8a91f8  ; [package:flutter/src/material/text_theme.dart] TextTheme::merge
    // 0x8a7b3c: ldur            x16, [fp, #-0x18]
    // 0x8a7b40: stp             x0, x16, [SP]
    // 0x8a7b44: ldur            x1, [fp, #-8]
    // 0x8a7b48: r4 = const [0, 0x3, 0x2, 0x1, primaryTextTheme, 0x1, textTheme, 0x2, null]
    //     0x8a7b48: add             x4, PP, #0x12, lsl #12  ; [pp+0x128e8] List(9) [0, 0x3, 0x2, 0x1, "primaryTextTheme", 0x1, "textTheme", 0x2, Null]
    //     0x8a7b4c: ldr             x4, [x4, #0x8e8]
    // 0x8a7b50: r0 = copyWith()
    //     0x8a7b50: bl              #0x8a7b68  ; [package:flutter/src/material/theme_data.dart] ThemeData::copyWith
    // 0x8a7b54: LeaveFrame
    //     0x8a7b54: mov             SP, fp
    //     0x8a7b58: ldp             fp, lr, [SP], #0x10
    // 0x8a7b5c: ret
    //     0x8a7b5c: ret             
    // 0x8a7b60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a7b60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a7b64: b               #0x8a7af0
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x8a7b68, size: 0xd28
    // 0x8a7b68: EnterFrame
    //     0x8a7b68: stp             fp, lr, [SP, #-0x10]!
    //     0x8a7b6c: mov             fp, SP
    // 0x8a7b70: AllocStack(0x280)
    //     0x8a7b70: sub             SP, SP, #0x280
    // 0x8a7b74: SetupParameters(ThemeData this /* r1 => r0, fp-0x98 */, {dynamic colorScheme = Null /* r3 */, dynamic cupertinoOverrideTheme, dynamic datePickerTheme = Null /* r5, fp-0x90 */, dynamic dividerColor = Null /* r6, fp-0x88 */, dynamic highlightColor = Null /* r7, fp-0x80 */, dynamic iconTheme = Null /* r8, fp-0x78 */, dynamic primaryTextTheme = Null /* r9, fp-0x70 */, dynamic splashColor = Null /* r10, fp-0x68 */, dynamic textTheme = Null /* r2, fp-0x60 */})
    //     0x8a7b74: mov             x0, x1
    //     0x8a7b78: stur            x1, [fp, #-0x98]
    //     0x8a7b7c: ldur            w1, [x4, #0x13]
    //     0x8a7b80: ldur            w2, [x4, #0x1f]
    //     0x8a7b84: add             x2, x2, HEAP, lsl #32
    //     0x8a7b88: add             x16, PP, #0x12, lsl #12  ; [pp+0x128f0] "colorScheme"
    //     0x8a7b8c: ldr             x16, [x16, #0x8f0]
    //     0x8a7b90: cmp             w2, w16
    //     0x8a7b94: b.ne            #0x8a7bb8
    //     0x8a7b98: ldur            w2, [x4, #0x23]
    //     0x8a7b9c: add             x2, x2, HEAP, lsl #32
    //     0x8a7ba0: sub             w3, w1, w2
    //     0x8a7ba4: add             x2, fp, w3, sxtw #2
    //     0x8a7ba8: ldr             x2, [x2, #8]
    //     0x8a7bac: mov             x3, x2
    //     0x8a7bb0: mov             x2, #1
    //     0x8a7bb4: b               #0x8a7bc0
    //     0x8a7bb8: mov             x3, NULL
    //     0x8a7bbc: mov             x2, #0
    //     0x8a7bc0: lsl             x5, x2, #1
    //     0x8a7bc4: lsl             w6, w5, #1
    //     0x8a7bc8: add             w7, w6, #8
    //     0x8a7bcc: add             x16, x4, w7, sxtw #1
    //     0x8a7bd0: ldur            w6, [x16, #0xf]
    //     0x8a7bd4: add             x6, x6, HEAP, lsl #32
    //     0x8a7bd8: add             x16, PP, #0x12, lsl #12  ; [pp+0x128f8] "cupertinoOverrideTheme"
    //     0x8a7bdc: ldr             x16, [x16, #0x8f8]
    //     0x8a7be0: cmp             w6, w16
    //     0x8a7be4: b.ne            #0x8a7bf4
    //     0x8a7be8: add             w2, w5, #2
    //     0x8a7bec: sbfx            x5, x2, #1, #0x1f
    //     0x8a7bf0: mov             x2, x5
    //     0x8a7bf4: lsl             x5, x2, #1
    //     0x8a7bf8: lsl             w6, w5, #1
    //     0x8a7bfc: add             w7, w6, #8
    //     0x8a7c00: add             x16, x4, w7, sxtw #1
    //     0x8a7c04: ldur            w8, [x16, #0xf]
    //     0x8a7c08: add             x8, x8, HEAP, lsl #32
    //     0x8a7c0c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12900] "datePickerTheme"
    //     0x8a7c10: ldr             x16, [x16, #0x900]
    //     0x8a7c14: cmp             w8, w16
    //     0x8a7c18: b.ne            #0x8a7c4c
    //     0x8a7c1c: add             w2, w6, #0xa
    //     0x8a7c20: add             x16, x4, w2, sxtw #1
    //     0x8a7c24: ldur            w6, [x16, #0xf]
    //     0x8a7c28: add             x6, x6, HEAP, lsl #32
    //     0x8a7c2c: sub             w2, w1, w6
    //     0x8a7c30: add             x6, fp, w2, sxtw #2
    //     0x8a7c34: ldr             x6, [x6, #8]
    //     0x8a7c38: add             w2, w5, #2
    //     0x8a7c3c: sbfx            x5, x2, #1, #0x1f
    //     0x8a7c40: mov             x2, x5
    //     0x8a7c44: mov             x5, x6
    //     0x8a7c48: b               #0x8a7c50
    //     0x8a7c4c: mov             x5, NULL
    //     0x8a7c50: stur            x5, [fp, #-0x90]
    //     0x8a7c54: lsl             x6, x2, #1
    //     0x8a7c58: lsl             w7, w6, #1
    //     0x8a7c5c: add             w8, w7, #8
    //     0x8a7c60: add             x16, x4, w8, sxtw #1
    //     0x8a7c64: ldur            w9, [x16, #0xf]
    //     0x8a7c68: add             x9, x9, HEAP, lsl #32
    //     0x8a7c6c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12908] "dividerColor"
    //     0x8a7c70: ldr             x16, [x16, #0x908]
    //     0x8a7c74: cmp             w9, w16
    //     0x8a7c78: b.ne            #0x8a7cac
    //     0x8a7c7c: add             w2, w7, #0xa
    //     0x8a7c80: add             x16, x4, w2, sxtw #1
    //     0x8a7c84: ldur            w7, [x16, #0xf]
    //     0x8a7c88: add             x7, x7, HEAP, lsl #32
    //     0x8a7c8c: sub             w2, w1, w7
    //     0x8a7c90: add             x7, fp, w2, sxtw #2
    //     0x8a7c94: ldr             x7, [x7, #8]
    //     0x8a7c98: add             w2, w6, #2
    //     0x8a7c9c: sbfx            x6, x2, #1, #0x1f
    //     0x8a7ca0: mov             x2, x6
    //     0x8a7ca4: mov             x6, x7
    //     0x8a7ca8: b               #0x8a7cb0
    //     0x8a7cac: mov             x6, NULL
    //     0x8a7cb0: stur            x6, [fp, #-0x88]
    //     0x8a7cb4: lsl             x7, x2, #1
    //     0x8a7cb8: lsl             w8, w7, #1
    //     0x8a7cbc: add             w9, w8, #8
    //     0x8a7cc0: add             x16, x4, w9, sxtw #1
    //     0x8a7cc4: ldur            w10, [x16, #0xf]
    //     0x8a7cc8: add             x10, x10, HEAP, lsl #32
    //     0x8a7ccc: add             x16, PP, #0x12, lsl #12  ; [pp+0x12910] "highlightColor"
    //     0x8a7cd0: ldr             x16, [x16, #0x910]
    //     0x8a7cd4: cmp             w10, w16
    //     0x8a7cd8: b.ne            #0x8a7d0c
    //     0x8a7cdc: add             w2, w8, #0xa
    //     0x8a7ce0: add             x16, x4, w2, sxtw #1
    //     0x8a7ce4: ldur            w8, [x16, #0xf]
    //     0x8a7ce8: add             x8, x8, HEAP, lsl #32
    //     0x8a7cec: sub             w2, w1, w8
    //     0x8a7cf0: add             x8, fp, w2, sxtw #2
    //     0x8a7cf4: ldr             x8, [x8, #8]
    //     0x8a7cf8: add             w2, w7, #2
    //     0x8a7cfc: sbfx            x7, x2, #1, #0x1f
    //     0x8a7d00: mov             x2, x7
    //     0x8a7d04: mov             x7, x8
    //     0x8a7d08: b               #0x8a7d10
    //     0x8a7d0c: mov             x7, NULL
    //     0x8a7d10: stur            x7, [fp, #-0x80]
    //     0x8a7d14: lsl             x8, x2, #1
    //     0x8a7d18: lsl             w9, w8, #1
    //     0x8a7d1c: add             w10, w9, #8
    //     0x8a7d20: add             x16, x4, w10, sxtw #1
    //     0x8a7d24: ldur            w11, [x16, #0xf]
    //     0x8a7d28: add             x11, x11, HEAP, lsl #32
    //     0x8a7d2c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12918] "iconTheme"
    //     0x8a7d30: ldr             x16, [x16, #0x918]
    //     0x8a7d34: cmp             w11, w16
    //     0x8a7d38: b.ne            #0x8a7d6c
    //     0x8a7d3c: add             w2, w9, #0xa
    //     0x8a7d40: add             x16, x4, w2, sxtw #1
    //     0x8a7d44: ldur            w9, [x16, #0xf]
    //     0x8a7d48: add             x9, x9, HEAP, lsl #32
    //     0x8a7d4c: sub             w2, w1, w9
    //     0x8a7d50: add             x9, fp, w2, sxtw #2
    //     0x8a7d54: ldr             x9, [x9, #8]
    //     0x8a7d58: add             w2, w8, #2
    //     0x8a7d5c: sbfx            x8, x2, #1, #0x1f
    //     0x8a7d60: mov             x2, x8
    //     0x8a7d64: mov             x8, x9
    //     0x8a7d68: b               #0x8a7d70
    //     0x8a7d6c: mov             x8, NULL
    //     0x8a7d70: stur            x8, [fp, #-0x78]
    //     0x8a7d74: lsl             x9, x2, #1
    //     0x8a7d78: lsl             w10, w9, #1
    //     0x8a7d7c: add             w11, w10, #8
    //     0x8a7d80: add             x16, x4, w11, sxtw #1
    //     0x8a7d84: ldur            w12, [x16, #0xf]
    //     0x8a7d88: add             x12, x12, HEAP, lsl #32
    //     0x8a7d8c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12920] "primaryTextTheme"
    //     0x8a7d90: ldr             x16, [x16, #0x920]
    //     0x8a7d94: cmp             w12, w16
    //     0x8a7d98: b.ne            #0x8a7dcc
    //     0x8a7d9c: add             w2, w10, #0xa
    //     0x8a7da0: add             x16, x4, w2, sxtw #1
    //     0x8a7da4: ldur            w10, [x16, #0xf]
    //     0x8a7da8: add             x10, x10, HEAP, lsl #32
    //     0x8a7dac: sub             w2, w1, w10
    //     0x8a7db0: add             x10, fp, w2, sxtw #2
    //     0x8a7db4: ldr             x10, [x10, #8]
    //     0x8a7db8: add             w2, w9, #2
    //     0x8a7dbc: sbfx            x9, x2, #1, #0x1f
    //     0x8a7dc0: mov             x2, x9
    //     0x8a7dc4: mov             x9, x10
    //     0x8a7dc8: b               #0x8a7dd0
    //     0x8a7dcc: mov             x9, NULL
    //     0x8a7dd0: stur            x9, [fp, #-0x70]
    //     0x8a7dd4: lsl             x10, x2, #1
    //     0x8a7dd8: lsl             w11, w10, #1
    //     0x8a7ddc: add             w12, w11, #8
    //     0x8a7de0: add             x16, x4, w12, sxtw #1
    //     0x8a7de4: ldur            w13, [x16, #0xf]
    //     0x8a7de8: add             x13, x13, HEAP, lsl #32
    //     0x8a7dec: add             x16, PP, #0x12, lsl #12  ; [pp+0x12928] "splashColor"
    //     0x8a7df0: ldr             x16, [x16, #0x928]
    //     0x8a7df4: cmp             w13, w16
    //     0x8a7df8: b.ne            #0x8a7e2c
    //     0x8a7dfc: add             w2, w11, #0xa
    //     0x8a7e00: add             x16, x4, w2, sxtw #1
    //     0x8a7e04: ldur            w11, [x16, #0xf]
    //     0x8a7e08: add             x11, x11, HEAP, lsl #32
    //     0x8a7e0c: sub             w2, w1, w11
    //     0x8a7e10: add             x11, fp, w2, sxtw #2
    //     0x8a7e14: ldr             x11, [x11, #8]
    //     0x8a7e18: add             w2, w10, #2
    //     0x8a7e1c: sbfx            x10, x2, #1, #0x1f
    //     0x8a7e20: mov             x2, x10
    //     0x8a7e24: mov             x10, x11
    //     0x8a7e28: b               #0x8a7e30
    //     0x8a7e2c: mov             x10, NULL
    //     0x8a7e30: stur            x10, [fp, #-0x68]
    //     0x8a7e34: lsl             x11, x2, #1
    //     0x8a7e38: lsl             w2, w11, #1
    //     0x8a7e3c: add             w11, w2, #8
    //     0x8a7e40: add             x16, x4, w11, sxtw #1
    //     0x8a7e44: ldur            w12, [x16, #0xf]
    //     0x8a7e48: add             x12, x12, HEAP, lsl #32
    //     0x8a7e4c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12930] "textTheme"
    //     0x8a7e50: ldr             x16, [x16, #0x930]
    //     0x8a7e54: cmp             w12, w16
    //     0x8a7e58: b.ne            #0x8a7e80
    //     0x8a7e5c: add             w11, w2, #0xa
    //     0x8a7e60: add             x16, x4, w11, sxtw #1
    //     0x8a7e64: ldur            w2, [x16, #0xf]
    //     0x8a7e68: add             x2, x2, HEAP, lsl #32
    //     0x8a7e6c: sub             w4, w1, w2
    //     0x8a7e70: add             x1, fp, w4, sxtw #2
    //     0x8a7e74: ldr             x1, [x1, #8]
    //     0x8a7e78: mov             x2, x1
    //     0x8a7e7c: b               #0x8a7e84
    //     0x8a7e80: mov             x2, NULL
    //     0x8a7e84: stur            x2, [fp, #-0x60]
    // 0x8a7e88: CheckStackOverflow
    //     0x8a7e88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a7e8c: cmp             SP, x16
    //     0x8a7e90: b.ls            #0x8a8888
    // 0x8a7e94: LoadField: r4 = r0->field_13
    //     0x8a7e94: ldur            w4, [x0, #0x13]
    // 0x8a7e98: DecompressPointer r4
    //     0x8a7e98: add             x4, x4, HEAP, lsl #32
    // 0x8a7e9c: stur            x4, [fp, #-0x58]
    // 0x8a7ea0: LoadField: r11 = r0->field_7
    //     0x8a7ea0: ldur            w11, [x0, #7]
    // 0x8a7ea4: DecompressPointer r11
    //     0x8a7ea4: add             x11, x11, HEAP, lsl #32
    // 0x8a7ea8: stur            x11, [fp, #-0x50]
    // 0x8a7eac: LoadField: r12 = r0->field_f
    //     0x8a7eac: ldur            w12, [x0, #0xf]
    // 0x8a7eb0: DecompressPointer r12
    //     0x8a7eb0: add             x12, x12, HEAP, lsl #32
    // 0x8a7eb4: stur            x12, [fp, #-0x48]
    // 0x8a7eb8: ArrayLoad: r13 = r0[0]  ; List_4
    //     0x8a7eb8: ldur            w13, [x0, #0x17]
    // 0x8a7ebc: DecompressPointer r13
    //     0x8a7ebc: add             x13, x13, HEAP, lsl #32
    // 0x8a7ec0: stur            x13, [fp, #-0x40]
    // 0x8a7ec4: LoadField: r14 = r0->field_1b
    //     0x8a7ec4: ldur            w14, [x0, #0x1b]
    // 0x8a7ec8: DecompressPointer r14
    //     0x8a7ec8: add             x14, x14, HEAP, lsl #32
    // 0x8a7ecc: stur            x14, [fp, #-0x38]
    // 0x8a7ed0: LoadField: r19 = r0->field_27
    //     0x8a7ed0: ldur            w19, [x0, #0x27]
    // 0x8a7ed4: DecompressPointer r19
    //     0x8a7ed4: add             x19, x19, HEAP, lsl #32
    // 0x8a7ed8: stur            x19, [fp, #-0x30]
    // 0x8a7edc: LoadField: r20 = r0->field_2b
    //     0x8a7edc: ldur            w20, [x0, #0x2b]
    // 0x8a7ee0: DecompressPointer r20
    //     0x8a7ee0: add             x20, x20, HEAP, lsl #32
    // 0x8a7ee4: stur            x20, [fp, #-0x28]
    // 0x8a7ee8: LoadField: r23 = r0->field_2f
    //     0x8a7ee8: ldur            w23, [x0, #0x2f]
    // 0x8a7eec: DecompressPointer r23
    //     0x8a7eec: add             x23, x23, HEAP, lsl #32
    // 0x8a7ef0: stur            x23, [fp, #-0x20]
    // 0x8a7ef4: LoadField: r24 = r0->field_33
    //     0x8a7ef4: ldur            w24, [x0, #0x33]
    // 0x8a7ef8: DecompressPointer r24
    //     0x8a7ef8: add             x24, x24, HEAP, lsl #32
    // 0x8a7efc: stur            x24, [fp, #-0x18]
    // 0x8a7f00: LoadField: r25 = r0->field_37
    //     0x8a7f00: ldur            w25, [x0, #0x37]
    // 0x8a7f04: DecompressPointer r25
    //     0x8a7f04: add             x25, x25, HEAP, lsl #32
    // 0x8a7f08: stur            x25, [fp, #-0x10]
    // 0x8a7f0c: LoadField: r1 = r0->field_3b
    //     0x8a7f0c: ldur            w1, [x0, #0x3b]
    // 0x8a7f10: DecompressPointer r1
    //     0x8a7f10: add             x1, x1, HEAP, lsl #32
    // 0x8a7f14: stur            x1, [fp, #-8]
    // 0x8a7f18: cmp             w3, NULL
    // 0x8a7f1c: b.ne            #0x8a7f28
    // 0x8a7f20: LoadField: r3 = r0->field_3f
    //     0x8a7f20: ldur            w3, [x0, #0x3f]
    // 0x8a7f24: DecompressPointer r3
    //     0x8a7f24: add             x3, x3, HEAP, lsl #32
    // 0x8a7f28: mov             x16, x1
    // 0x8a7f2c: mov             x1, x3
    // 0x8a7f30: mov             x3, x16
    // 0x8a7f34: r0 = copyWith()
    //     0x8a7f34: bl              #0x8a88a4  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::copyWith
    // 0x8a7f38: mov             x1, x0
    // 0x8a7f3c: ldur            x0, [fp, #-0x98]
    // 0x8a7f40: stur            x1, [fp, #-0xa0]
    // 0x8a7f44: LoadField: r2 = r0->field_43
    //     0x8a7f44: ldur            w2, [x0, #0x43]
    // 0x8a7f48: DecompressPointer r2
    //     0x8a7f48: add             x2, x2, HEAP, lsl #32
    // 0x8a7f4c: ldur            x3, [fp, #-0x88]
    // 0x8a7f50: stur            x2, [fp, #-0xa8]
    // 0x8a7f54: cmp             w3, NULL
    // 0x8a7f58: b.ne            #0x8a7f6c
    // 0x8a7f5c: LoadField: r3 = r0->field_47
    //     0x8a7f5c: ldur            w3, [x0, #0x47]
    // 0x8a7f60: DecompressPointer r3
    //     0x8a7f60: add             x3, x3, HEAP, lsl #32
    // 0x8a7f64: mov             x4, x3
    // 0x8a7f68: b               #0x8a7f70
    // 0x8a7f6c: mov             x4, x3
    // 0x8a7f70: ldur            x3, [fp, #-0x80]
    // 0x8a7f74: stur            x4, [fp, #-0x88]
    // 0x8a7f78: LoadField: r5 = r0->field_4b
    //     0x8a7f78: ldur            w5, [x0, #0x4b]
    // 0x8a7f7c: DecompressPointer r5
    //     0x8a7f7c: add             x5, x5, HEAP, lsl #32
    // 0x8a7f80: stur            x5, [fp, #-0xb0]
    // 0x8a7f84: cmp             w3, NULL
    // 0x8a7f88: b.ne            #0x8a7f9c
    // 0x8a7f8c: LoadField: r3 = r0->field_4f
    //     0x8a7f8c: ldur            w3, [x0, #0x4f]
    // 0x8a7f90: DecompressPointer r3
    //     0x8a7f90: add             x3, x3, HEAP, lsl #32
    // 0x8a7f94: mov             x6, x3
    // 0x8a7f98: b               #0x8a7fa0
    // 0x8a7f9c: mov             x6, x3
    // 0x8a7fa0: ldur            x3, [fp, #-0x68]
    // 0x8a7fa4: stur            x6, [fp, #-0x80]
    // 0x8a7fa8: LoadField: r7 = r0->field_53
    //     0x8a7fa8: ldur            w7, [x0, #0x53]
    // 0x8a7fac: DecompressPointer r7
    //     0x8a7fac: add             x7, x7, HEAP, lsl #32
    // 0x8a7fb0: stur            x7, [fp, #-0xb8]
    // 0x8a7fb4: LoadField: r8 = r0->field_57
    //     0x8a7fb4: ldur            w8, [x0, #0x57]
    // 0x8a7fb8: DecompressPointer r8
    //     0x8a7fb8: add             x8, x8, HEAP, lsl #32
    // 0x8a7fbc: stur            x8, [fp, #-0xc0]
    // 0x8a7fc0: LoadField: r9 = r0->field_5b
    //     0x8a7fc0: ldur            w9, [x0, #0x5b]
    // 0x8a7fc4: DecompressPointer r9
    //     0x8a7fc4: add             x9, x9, HEAP, lsl #32
    // 0x8a7fc8: stur            x9, [fp, #-0xc8]
    // 0x8a7fcc: LoadField: r10 = r0->field_5f
    //     0x8a7fcc: ldur            w10, [x0, #0x5f]
    // 0x8a7fd0: DecompressPointer r10
    //     0x8a7fd0: add             x10, x10, HEAP, lsl #32
    // 0x8a7fd4: stur            x10, [fp, #-0xd0]
    // 0x8a7fd8: LoadField: r11 = r0->field_63
    //     0x8a7fd8: ldur            w11, [x0, #0x63]
    // 0x8a7fdc: DecompressPointer r11
    //     0x8a7fdc: add             x11, x11, HEAP, lsl #32
    // 0x8a7fe0: stur            x11, [fp, #-0xd8]
    // 0x8a7fe4: LoadField: r12 = r0->field_67
    //     0x8a7fe4: ldur            w12, [x0, #0x67]
    // 0x8a7fe8: DecompressPointer r12
    //     0x8a7fe8: add             x12, x12, HEAP, lsl #32
    // 0x8a7fec: stur            x12, [fp, #-0xe0]
    // 0x8a7ff0: LoadField: r13 = r0->field_6b
    //     0x8a7ff0: ldur            w13, [x0, #0x6b]
    // 0x8a7ff4: DecompressPointer r13
    //     0x8a7ff4: add             x13, x13, HEAP, lsl #32
    // 0x8a7ff8: stur            x13, [fp, #-0xe8]
    // 0x8a7ffc: LoadField: r14 = r0->field_6f
    //     0x8a7ffc: ldur            w14, [x0, #0x6f]
    // 0x8a8000: DecompressPointer r14
    //     0x8a8000: add             x14, x14, HEAP, lsl #32
    // 0x8a8004: stur            x14, [fp, #-0xf0]
    // 0x8a8008: cmp             w3, NULL
    // 0x8a800c: b.ne            #0x8a8020
    // 0x8a8010: LoadField: r3 = r0->field_73
    //     0x8a8010: ldur            w3, [x0, #0x73]
    // 0x8a8014: DecompressPointer r3
    //     0x8a8014: add             x3, x3, HEAP, lsl #32
    // 0x8a8018: mov             x19, x3
    // 0x8a801c: b               #0x8a8024
    // 0x8a8020: mov             x19, x3
    // 0x8a8024: ldur            x3, [fp, #-0x78]
    // 0x8a8028: r17 = -336
    //     0x8a8028: mov             x17, #-0x150
    // 0x8a802c: str             x19, [fp, x17]
    // 0x8a8030: LoadField: r20 = r0->field_77
    //     0x8a8030: ldur            w20, [x0, #0x77]
    // 0x8a8034: DecompressPointer r20
    //     0x8a8034: add             x20, x20, HEAP, lsl #32
    // 0x8a8038: r17 = -344
    //     0x8a8038: mov             x17, #-0x158
    // 0x8a803c: str             x20, [fp, x17]
    // 0x8a8040: cmp             w3, NULL
    // 0x8a8044: b.ne            #0x8a8058
    // 0x8a8048: LoadField: r3 = r0->field_7b
    //     0x8a8048: ldur            w3, [x0, #0x7b]
    // 0x8a804c: DecompressPointer r3
    //     0x8a804c: add             x3, x3, HEAP, lsl #32
    // 0x8a8050: mov             x23, x3
    // 0x8a8054: b               #0x8a805c
    // 0x8a8058: mov             x23, x3
    // 0x8a805c: ldur            x3, [fp, #-0x70]
    // 0x8a8060: r17 = -352
    //     0x8a8060: mov             x17, #-0x160
    // 0x8a8064: str             x23, [fp, x17]
    // 0x8a8068: LoadField: r24 = r0->field_7f
    //     0x8a8068: ldur            w24, [x0, #0x7f]
    // 0x8a806c: DecompressPointer r24
    //     0x8a806c: add             x24, x24, HEAP, lsl #32
    // 0x8a8070: r17 = -360
    //     0x8a8070: mov             x17, #-0x168
    // 0x8a8074: str             x24, [fp, x17]
    // 0x8a8078: cmp             w3, NULL
    // 0x8a807c: b.ne            #0x8a8090
    // 0x8a8080: LoadField: r3 = r0->field_83
    //     0x8a8080: ldur            w3, [x0, #0x83]
    // 0x8a8084: DecompressPointer r3
    //     0x8a8084: add             x3, x3, HEAP, lsl #32
    // 0x8a8088: mov             x25, x3
    // 0x8a808c: b               #0x8a8094
    // 0x8a8090: mov             x25, x3
    // 0x8a8094: ldur            x3, [fp, #-0x60]
    // 0x8a8098: r17 = -368
    //     0x8a8098: mov             x17, #-0x170
    // 0x8a809c: str             x25, [fp, x17]
    // 0x8a80a0: cmp             w3, NULL
    // 0x8a80a4: b.ne            #0x8a80b8
    // 0x8a80a8: LoadField: r3 = r0->field_87
    //     0x8a80a8: ldur            w3, [x0, #0x87]
    // 0x8a80ac: DecompressPointer r3
    //     0x8a80ac: add             x3, x3, HEAP, lsl #32
    // 0x8a80b0: stur            x3, [fp, #-0x60]
    // 0x8a80b4: b               #0x8a80bc
    // 0x8a80b8: stur            x3, [fp, #-0x60]
    // 0x8a80bc: ldur            x3, [fp, #-0x90]
    // 0x8a80c0: LoadField: r1 = r0->field_8b
    //     0x8a80c0: ldur            w1, [x0, #0x8b]
    // 0x8a80c4: DecompressPointer r1
    //     0x8a80c4: add             x1, x1, HEAP, lsl #32
    // 0x8a80c8: r17 = -328
    //     0x8a80c8: mov             x17, #-0x148
    // 0x8a80cc: str             x1, [fp, x17]
    // 0x8a80d0: LoadField: r2 = r0->field_93
    //     0x8a80d0: ldur            w2, [x0, #0x93]
    // 0x8a80d4: DecompressPointer r2
    //     0x8a80d4: add             x2, x2, HEAP, lsl #32
    // 0x8a80d8: r17 = -320
    //     0x8a80d8: mov             x17, #-0x140
    // 0x8a80dc: str             x2, [fp, x17]
    // 0x8a80e0: LoadField: r4 = r0->field_97
    //     0x8a80e0: ldur            w4, [x0, #0x97]
    // 0x8a80e4: DecompressPointer r4
    //     0x8a80e4: add             x4, x4, HEAP, lsl #32
    // 0x8a80e8: r17 = -312
    //     0x8a80e8: mov             x17, #-0x138
    // 0x8a80ec: str             x4, [fp, x17]
    // 0x8a80f0: LoadField: r5 = r0->field_9b
    //     0x8a80f0: ldur            w5, [x0, #0x9b]
    // 0x8a80f4: DecompressPointer r5
    //     0x8a80f4: add             x5, x5, HEAP, lsl #32
    // 0x8a80f8: r17 = -304
    //     0x8a80f8: mov             x17, #-0x130
    // 0x8a80fc: str             x5, [fp, x17]
    // 0x8a8100: LoadField: r6 = r0->field_9f
    //     0x8a8100: ldur            w6, [x0, #0x9f]
    // 0x8a8104: DecompressPointer r6
    //     0x8a8104: add             x6, x6, HEAP, lsl #32
    // 0x8a8108: r17 = -296
    //     0x8a8108: mov             x17, #-0x128
    // 0x8a810c: str             x6, [fp, x17]
    // 0x8a8110: LoadField: r7 = r0->field_a3
    //     0x8a8110: ldur            w7, [x0, #0xa3]
    // 0x8a8114: DecompressPointer r7
    //     0x8a8114: add             x7, x7, HEAP, lsl #32
    // 0x8a8118: r17 = -288
    //     0x8a8118: mov             x17, #-0x120
    // 0x8a811c: str             x7, [fp, x17]
    // 0x8a8120: LoadField: r8 = r0->field_a7
    //     0x8a8120: ldur            w8, [x0, #0xa7]
    // 0x8a8124: DecompressPointer r8
    //     0x8a8124: add             x8, x8, HEAP, lsl #32
    // 0x8a8128: r17 = -280
    //     0x8a8128: mov             x17, #-0x118
    // 0x8a812c: str             x8, [fp, x17]
    // 0x8a8130: LoadField: r9 = r0->field_ab
    //     0x8a8130: ldur            w9, [x0, #0xab]
    // 0x8a8134: DecompressPointer r9
    //     0x8a8134: add             x9, x9, HEAP, lsl #32
    // 0x8a8138: r17 = -272
    //     0x8a8138: mov             x17, #-0x110
    // 0x8a813c: str             x9, [fp, x17]
    // 0x8a8140: LoadField: r10 = r0->field_af
    //     0x8a8140: ldur            w10, [x0, #0xaf]
    // 0x8a8144: DecompressPointer r10
    //     0x8a8144: add             x10, x10, HEAP, lsl #32
    // 0x8a8148: r17 = -264
    //     0x8a8148: mov             x17, #-0x108
    // 0x8a814c: str             x10, [fp, x17]
    // 0x8a8150: LoadField: r11 = r0->field_b3
    //     0x8a8150: ldur            w11, [x0, #0xb3]
    // 0x8a8154: DecompressPointer r11
    //     0x8a8154: add             x11, x11, HEAP, lsl #32
    // 0x8a8158: stur            x11, [fp, #-0x100]
    // 0x8a815c: LoadField: r12 = r0->field_b7
    //     0x8a815c: ldur            w12, [x0, #0xb7]
    // 0x8a8160: DecompressPointer r12
    //     0x8a8160: add             x12, x12, HEAP, lsl #32
    // 0x8a8164: stur            x12, [fp, #-0xf8]
    // 0x8a8168: LoadField: r13 = r0->field_bb
    //     0x8a8168: ldur            w13, [x0, #0xbb]
    // 0x8a816c: DecompressPointer r13
    //     0x8a816c: add             x13, x13, HEAP, lsl #32
    // 0x8a8170: stur            x13, [fp, #-0x78]
    // 0x8a8174: LoadField: r14 = r0->field_bf
    //     0x8a8174: ldur            w14, [x0, #0xbf]
    // 0x8a8178: DecompressPointer r14
    //     0x8a8178: add             x14, x14, HEAP, lsl #32
    // 0x8a817c: stur            x14, [fp, #-0x70]
    // 0x8a8180: cmp             w3, NULL
    // 0x8a8184: b.ne            #0x8a8198
    // 0x8a8188: LoadField: r3 = r0->field_c3
    //     0x8a8188: ldur            w3, [x0, #0xc3]
    // 0x8a818c: DecompressPointer r3
    //     0x8a818c: add             x3, x3, HEAP, lsl #32
    // 0x8a8190: stur            x3, [fp, #-0x68]
    // 0x8a8194: b               #0x8a819c
    // 0x8a8198: stur            x3, [fp, #-0x68]
    // 0x8a819c: mov             x3, x12
    // 0x8a81a0: mov             x12, x2
    // 0x8a81a4: mov             x2, x13
    // 0x8a81a8: mov             x13, x1
    // 0x8a81ac: mov             x1, x14
    // 0x8a81b0: ldur            x14, [fp, #-0x60]
    // 0x8a81b4: mov             x16, x11
    // 0x8a81b8: mov             x11, x4
    // 0x8a81bc: mov             x4, x16
    // 0x8a81c0: mov             x16, x10
    // 0x8a81c4: mov             x10, x5
    // 0x8a81c8: mov             x5, x16
    // 0x8a81cc: mov             x16, x9
    // 0x8a81d0: mov             x9, x6
    // 0x8a81d4: mov             x6, x16
    // 0x8a81d8: mov             x16, x8
    // 0x8a81dc: mov             x8, x7
    // 0x8a81e0: mov             x7, x16
    // 0x8a81e4: LoadField: r1 = r0->field_c7
    //     0x8a81e4: ldur            w1, [x0, #0xc7]
    // 0x8a81e8: DecompressPointer r1
    //     0x8a81e8: add             x1, x1, HEAP, lsl #32
    // 0x8a81ec: stur            x1, [fp, #-0x90]
    // 0x8a81f0: LoadField: r2 = r0->field_cb
    //     0x8a81f0: ldur            w2, [x0, #0xcb]
    // 0x8a81f4: DecompressPointer r2
    //     0x8a81f4: add             x2, x2, HEAP, lsl #32
    // 0x8a81f8: r17 = -600
    //     0x8a81f8: mov             x17, #-0x258
    // 0x8a81fc: str             x2, [fp, x17]
    // 0x8a8200: LoadField: r3 = r0->field_cf
    //     0x8a8200: ldur            w3, [x0, #0xcf]
    // 0x8a8204: DecompressPointer r3
    //     0x8a8204: add             x3, x3, HEAP, lsl #32
    // 0x8a8208: r17 = -592
    //     0x8a8208: mov             x17, #-0x250
    // 0x8a820c: str             x3, [fp, x17]
    // 0x8a8210: LoadField: r4 = r0->field_d3
    //     0x8a8210: ldur            w4, [x0, #0xd3]
    // 0x8a8214: DecompressPointer r4
    //     0x8a8214: add             x4, x4, HEAP, lsl #32
    // 0x8a8218: r17 = -584
    //     0x8a8218: mov             x17, #-0x248
    // 0x8a821c: str             x4, [fp, x17]
    // 0x8a8220: LoadField: r5 = r0->field_d7
    //     0x8a8220: ldur            w5, [x0, #0xd7]
    // 0x8a8224: DecompressPointer r5
    //     0x8a8224: add             x5, x5, HEAP, lsl #32
    // 0x8a8228: r17 = -576
    //     0x8a8228: mov             x17, #-0x240
    // 0x8a822c: str             x5, [fp, x17]
    // 0x8a8230: LoadField: r6 = r0->field_db
    //     0x8a8230: ldur            w6, [x0, #0xdb]
    // 0x8a8234: DecompressPointer r6
    //     0x8a8234: add             x6, x6, HEAP, lsl #32
    // 0x8a8238: r17 = -568
    //     0x8a8238: mov             x17, #-0x238
    // 0x8a823c: str             x6, [fp, x17]
    // 0x8a8240: LoadField: r7 = r0->field_df
    //     0x8a8240: ldur            w7, [x0, #0xdf]
    // 0x8a8244: DecompressPointer r7
    //     0x8a8244: add             x7, x7, HEAP, lsl #32
    // 0x8a8248: r17 = -560
    //     0x8a8248: mov             x17, #-0x230
    // 0x8a824c: str             x7, [fp, x17]
    // 0x8a8250: LoadField: r8 = r0->field_e3
    //     0x8a8250: ldur            w8, [x0, #0xe3]
    // 0x8a8254: DecompressPointer r8
    //     0x8a8254: add             x8, x8, HEAP, lsl #32
    // 0x8a8258: r17 = -552
    //     0x8a8258: mov             x17, #-0x228
    // 0x8a825c: str             x8, [fp, x17]
    // 0x8a8260: LoadField: r9 = r0->field_e7
    //     0x8a8260: ldur            w9, [x0, #0xe7]
    // 0x8a8264: DecompressPointer r9
    //     0x8a8264: add             x9, x9, HEAP, lsl #32
    // 0x8a8268: r17 = -544
    //     0x8a8268: mov             x17, #-0x220
    // 0x8a826c: str             x9, [fp, x17]
    // 0x8a8270: LoadField: r10 = r0->field_eb
    //     0x8a8270: ldur            w10, [x0, #0xeb]
    // 0x8a8274: DecompressPointer r10
    //     0x8a8274: add             x10, x10, HEAP, lsl #32
    // 0x8a8278: r17 = -536
    //     0x8a8278: mov             x17, #-0x218
    // 0x8a827c: str             x10, [fp, x17]
    // 0x8a8280: LoadField: r11 = r0->field_ef
    //     0x8a8280: ldur            w11, [x0, #0xef]
    // 0x8a8284: DecompressPointer r11
    //     0x8a8284: add             x11, x11, HEAP, lsl #32
    // 0x8a8288: r17 = -528
    //     0x8a8288: mov             x17, #-0x210
    // 0x8a828c: str             x11, [fp, x17]
    // 0x8a8290: LoadField: r12 = r0->field_f3
    //     0x8a8290: ldur            w12, [x0, #0xf3]
    // 0x8a8294: DecompressPointer r12
    //     0x8a8294: add             x12, x12, HEAP, lsl #32
    // 0x8a8298: r17 = -520
    //     0x8a8298: mov             x17, #-0x208
    // 0x8a829c: str             x12, [fp, x17]
    // 0x8a82a0: LoadField: r13 = r0->field_f7
    //     0x8a82a0: ldur            w13, [x0, #0xf7]
    // 0x8a82a4: DecompressPointer r13
    //     0x8a82a4: add             x13, x13, HEAP, lsl #32
    // 0x8a82a8: r17 = -512
    //     0x8a82a8: mov             x17, #-0x200
    // 0x8a82ac: str             x13, [fp, x17]
    // 0x8a82b0: LoadField: r14 = r0->field_fb
    //     0x8a82b0: ldur            w14, [x0, #0xfb]
    // 0x8a82b4: DecompressPointer r14
    //     0x8a82b4: add             x14, x14, HEAP, lsl #32
    // 0x8a82b8: r17 = -504
    //     0x8a82b8: mov             x17, #-0x1f8
    // 0x8a82bc: str             x14, [fp, x17]
    // 0x8a82c0: LoadField: r19 = r0->field_ff
    //     0x8a82c0: ldur            w19, [x0, #0xff]
    // 0x8a82c4: DecompressPointer r19
    //     0x8a82c4: add             x19, x19, HEAP, lsl #32
    // 0x8a82c8: r17 = -496
    //     0x8a82c8: mov             x17, #-0x1f0
    // 0x8a82cc: str             x19, [fp, x17]
    // 0x8a82d0: r17 = 259
    //     0x8a82d0: mov             x17, #0x103
    // 0x8a82d4: ldr             w20, [x0, x17]
    // 0x8a82d8: DecompressPointer r20
    //     0x8a82d8: add             x20, x20, HEAP, lsl #32
    // 0x8a82dc: r17 = -608
    //     0x8a82dc: mov             x17, #-0x260
    // 0x8a82e0: str             x20, [fp, x17]
    // 0x8a82e4: r17 = 263
    //     0x8a82e4: mov             x17, #0x107
    // 0x8a82e8: ldr             w23, [x0, x17]
    // 0x8a82ec: DecompressPointer r23
    //     0x8a82ec: add             x23, x23, HEAP, lsl #32
    // 0x8a82f0: r17 = -616
    //     0x8a82f0: mov             x17, #-0x268
    // 0x8a82f4: str             x23, [fp, x17]
    // 0x8a82f8: r17 = 267
    //     0x8a82f8: mov             x17, #0x10b
    // 0x8a82fc: ldr             w24, [x0, x17]
    // 0x8a8300: DecompressPointer r24
    //     0x8a8300: add             x24, x24, HEAP, lsl #32
    // 0x8a8304: r17 = -624
    //     0x8a8304: mov             x17, #-0x270
    // 0x8a8308: str             x24, [fp, x17]
    // 0x8a830c: r17 = 271
    //     0x8a830c: mov             x17, #0x10f
    // 0x8a8310: ldr             w25, [x0, x17]
    // 0x8a8314: DecompressPointer r25
    //     0x8a8314: add             x25, x25, HEAP, lsl #32
    // 0x8a8318: r17 = -632
    //     0x8a8318: mov             x17, #-0x278
    // 0x8a831c: str             x25, [fp, x17]
    // 0x8a8320: r17 = 275
    //     0x8a8320: mov             x17, #0x113
    // 0x8a8324: ldr             w1, [x0, x17]
    // 0x8a8328: DecompressPointer r1
    //     0x8a8328: add             x1, x1, HEAP, lsl #32
    // 0x8a832c: r17 = -376
    //     0x8a832c: mov             x17, #-0x178
    // 0x8a8330: str             x1, [fp, x17]
    // 0x8a8334: r17 = 279
    //     0x8a8334: mov             x17, #0x117
    // 0x8a8338: ldr             w1, [x0, x17]
    // 0x8a833c: DecompressPointer r1
    //     0x8a833c: add             x1, x1, HEAP, lsl #32
    // 0x8a8340: r17 = -384
    //     0x8a8340: mov             x17, #-0x180
    // 0x8a8344: str             x1, [fp, x17]
    // 0x8a8348: r17 = 283
    //     0x8a8348: mov             x17, #0x11b
    // 0x8a834c: ldr             w1, [x0, x17]
    // 0x8a8350: DecompressPointer r1
    //     0x8a8350: add             x1, x1, HEAP, lsl #32
    // 0x8a8354: r17 = -392
    //     0x8a8354: mov             x17, #-0x188
    // 0x8a8358: str             x1, [fp, x17]
    // 0x8a835c: r17 = 287
    //     0x8a835c: mov             x17, #0x11f
    // 0x8a8360: ldr             w1, [x0, x17]
    // 0x8a8364: DecompressPointer r1
    //     0x8a8364: add             x1, x1, HEAP, lsl #32
    // 0x8a8368: r17 = -400
    //     0x8a8368: mov             x17, #-0x190
    // 0x8a836c: str             x1, [fp, x17]
    // 0x8a8370: r17 = 291
    //     0x8a8370: mov             x17, #0x123
    // 0x8a8374: ldr             w1, [x0, x17]
    // 0x8a8378: DecompressPointer r1
    //     0x8a8378: add             x1, x1, HEAP, lsl #32
    // 0x8a837c: r17 = -408
    //     0x8a837c: mov             x17, #-0x198
    // 0x8a8380: str             x1, [fp, x17]
    // 0x8a8384: r17 = 295
    //     0x8a8384: mov             x17, #0x127
    // 0x8a8388: ldr             w1, [x0, x17]
    // 0x8a838c: DecompressPointer r1
    //     0x8a838c: add             x1, x1, HEAP, lsl #32
    // 0x8a8390: r17 = -416
    //     0x8a8390: mov             x17, #-0x1a0
    // 0x8a8394: str             x1, [fp, x17]
    // 0x8a8398: r17 = 299
    //     0x8a8398: mov             x17, #0x12b
    // 0x8a839c: ldr             w1, [x0, x17]
    // 0x8a83a0: DecompressPointer r1
    //     0x8a83a0: add             x1, x1, HEAP, lsl #32
    // 0x8a83a4: r17 = -424
    //     0x8a83a4: mov             x17, #-0x1a8
    // 0x8a83a8: str             x1, [fp, x17]
    // 0x8a83ac: r17 = 303
    //     0x8a83ac: mov             x17, #0x12f
    // 0x8a83b0: ldr             w1, [x0, x17]
    // 0x8a83b4: DecompressPointer r1
    //     0x8a83b4: add             x1, x1, HEAP, lsl #32
    // 0x8a83b8: r17 = -432
    //     0x8a83b8: mov             x17, #-0x1b0
    // 0x8a83bc: str             x1, [fp, x17]
    // 0x8a83c0: r17 = 307
    //     0x8a83c0: mov             x17, #0x133
    // 0x8a83c4: ldr             w1, [x0, x17]
    // 0x8a83c8: DecompressPointer r1
    //     0x8a83c8: add             x1, x1, HEAP, lsl #32
    // 0x8a83cc: r17 = -440
    //     0x8a83cc: mov             x17, #-0x1b8
    // 0x8a83d0: str             x1, [fp, x17]
    // 0x8a83d4: r17 = 311
    //     0x8a83d4: mov             x17, #0x137
    // 0x8a83d8: ldr             w1, [x0, x17]
    // 0x8a83dc: DecompressPointer r1
    //     0x8a83dc: add             x1, x1, HEAP, lsl #32
    // 0x8a83e0: r17 = -448
    //     0x8a83e0: mov             x17, #-0x1c0
    // 0x8a83e4: str             x1, [fp, x17]
    // 0x8a83e8: r17 = 315
    //     0x8a83e8: mov             x17, #0x13b
    // 0x8a83ec: ldr             w1, [x0, x17]
    // 0x8a83f0: DecompressPointer r1
    //     0x8a83f0: add             x1, x1, HEAP, lsl #32
    // 0x8a83f4: r17 = -456
    //     0x8a83f4: mov             x17, #-0x1c8
    // 0x8a83f8: str             x1, [fp, x17]
    // 0x8a83fc: r17 = 319
    //     0x8a83fc: mov             x17, #0x13f
    // 0x8a8400: ldr             w1, [x0, x17]
    // 0x8a8404: DecompressPointer r1
    //     0x8a8404: add             x1, x1, HEAP, lsl #32
    // 0x8a8408: r17 = -464
    //     0x8a8408: mov             x17, #-0x1d0
    // 0x8a840c: str             x1, [fp, x17]
    // 0x8a8410: r17 = 323
    //     0x8a8410: mov             x17, #0x143
    // 0x8a8414: ldr             w1, [x0, x17]
    // 0x8a8418: DecompressPointer r1
    //     0x8a8418: add             x1, x1, HEAP, lsl #32
    // 0x8a841c: r17 = -472
    //     0x8a841c: mov             x17, #-0x1d8
    // 0x8a8420: str             x1, [fp, x17]
    // 0x8a8424: r17 = 327
    //     0x8a8424: mov             x17, #0x147
    // 0x8a8428: ldr             w1, [x0, x17]
    // 0x8a842c: DecompressPointer r1
    //     0x8a842c: add             x1, x1, HEAP, lsl #32
    // 0x8a8430: r17 = -480
    //     0x8a8430: mov             x17, #-0x1e0
    // 0x8a8434: str             x1, [fp, x17]
    // 0x8a8438: r17 = 331
    //     0x8a8438: mov             x17, #0x14b
    // 0x8a843c: ldr             w1, [x0, x17]
    // 0x8a8440: DecompressPointer r1
    //     0x8a8440: add             x1, x1, HEAP, lsl #32
    // 0x8a8444: r17 = -488
    //     0x8a8444: mov             x17, #-0x1e8
    // 0x8a8448: str             x1, [fp, x17]
    // 0x8a844c: r17 = 335
    //     0x8a844c: mov             x17, #0x14f
    // 0x8a8450: ldr             w1, [x0, x17]
    // 0x8a8454: DecompressPointer r1
    //     0x8a8454: add             x1, x1, HEAP, lsl #32
    // 0x8a8458: r17 = -376
    //     0x8a8458: mov             x17, #-0x178
    // 0x8a845c: ldr             x19, [fp, x17]
    // 0x8a8460: r17 = -384
    //     0x8a8460: mov             x17, #-0x180
    // 0x8a8464: ldr             x14, [fp, x17]
    // 0x8a8468: r17 = -392
    //     0x8a8468: mov             x17, #-0x188
    // 0x8a846c: ldr             x13, [fp, x17]
    // 0x8a8470: r17 = -400
    //     0x8a8470: mov             x17, #-0x190
    // 0x8a8474: ldr             x12, [fp, x17]
    // 0x8a8478: r17 = -408
    //     0x8a8478: mov             x17, #-0x198
    // 0x8a847c: ldr             x11, [fp, x17]
    // 0x8a8480: r17 = -416
    //     0x8a8480: mov             x17, #-0x1a0
    // 0x8a8484: ldr             x10, [fp, x17]
    // 0x8a8488: r17 = -424
    //     0x8a8488: mov             x17, #-0x1a8
    // 0x8a848c: ldr             x9, [fp, x17]
    // 0x8a8490: r17 = -432
    //     0x8a8490: mov             x17, #-0x1b0
    // 0x8a8494: ldr             x8, [fp, x17]
    // 0x8a8498: r17 = -440
    //     0x8a8498: mov             x17, #-0x1b8
    // 0x8a849c: ldr             x7, [fp, x17]
    // 0x8a84a0: r17 = -448
    //     0x8a84a0: mov             x17, #-0x1c0
    // 0x8a84a4: ldr             x6, [fp, x17]
    // 0x8a84a8: r17 = -456
    //     0x8a84a8: mov             x17, #-0x1c8
    // 0x8a84ac: ldr             x5, [fp, x17]
    // 0x8a84b0: r17 = -464
    //     0x8a84b0: mov             x17, #-0x1d0
    // 0x8a84b4: ldr             x4, [fp, x17]
    // 0x8a84b8: r17 = -472
    //     0x8a84b8: mov             x17, #-0x1d8
    // 0x8a84bc: ldr             x3, [fp, x17]
    // 0x8a84c0: r17 = -480
    //     0x8a84c0: mov             x17, #-0x1e0
    // 0x8a84c4: ldr             x2, [fp, x17]
    // 0x8a84c8: r17 = -488
    //     0x8a84c8: mov             x17, #-0x1e8
    // 0x8a84cc: ldr             x0, [fp, x17]
    // 0x8a84d0: r17 = -640
    //     0x8a84d0: mov             x17, #-0x280
    // 0x8a84d4: str             x1, [fp, x17]
    // 0x8a84d8: r0 = ThemeData()
    //     0x8a84d8: bl              #0x8a8890  ; AllocateThemeDataStub -> ThemeData (size=0x154)
    // 0x8a84dc: ldur            x1, [fp, #-0x58]
    // 0x8a84e0: StoreField: r0->field_13 = r1
    //     0x8a84e0: stur            w1, [x0, #0x13]
    // 0x8a84e4: ldur            x1, [fp, #-0x50]
    // 0x8a84e8: StoreField: r0->field_7 = r1
    //     0x8a84e8: stur            w1, [x0, #7]
    // 0x8a84ec: ldur            x1, [fp, #-0x48]
    // 0x8a84f0: StoreField: r0->field_f = r1
    //     0x8a84f0: stur            w1, [x0, #0xf]
    // 0x8a84f4: ldur            x1, [fp, #-0x40]
    // 0x8a84f8: ArrayStore: r0[0] = r1  ; List_4
    //     0x8a84f8: stur            w1, [x0, #0x17]
    // 0x8a84fc: ldur            x1, [fp, #-0x38]
    // 0x8a8500: StoreField: r0->field_1b = r1
    //     0x8a8500: stur            w1, [x0, #0x1b]
    // 0x8a8504: r1 = Instance_PageTransitionsTheme
    //     0x8a8504: add             x1, PP, #0x12, lsl #12  ; [pp+0x12938] Obj!PageTransitionsTheme@12b2a31
    //     0x8a8508: ldr             x1, [x1, #0x938]
    // 0x8a850c: StoreField: r0->field_1f = r1
    //     0x8a850c: stur            w1, [x0, #0x1f]
    // 0x8a8510: r1 = Instance_TargetPlatform
    //     0x8a8510: add             x1, PP, #0x12, lsl #12  ; [pp+0x12940] Obj!TargetPlatform@12c5e81
    //     0x8a8514: ldr             x1, [x1, #0x940]
    // 0x8a8518: StoreField: r0->field_23 = r1
    //     0x8a8518: stur            w1, [x0, #0x23]
    // 0x8a851c: ldur            x1, [fp, #-0x30]
    // 0x8a8520: StoreField: r0->field_27 = r1
    //     0x8a8520: stur            w1, [x0, #0x27]
    // 0x8a8524: ldur            x1, [fp, #-0x28]
    // 0x8a8528: StoreField: r0->field_2b = r1
    //     0x8a8528: stur            w1, [x0, #0x2b]
    // 0x8a852c: ldur            x1, [fp, #-0x20]
    // 0x8a8530: StoreField: r0->field_2f = r1
    //     0x8a8530: stur            w1, [x0, #0x2f]
    // 0x8a8534: ldur            x1, [fp, #-0x18]
    // 0x8a8538: StoreField: r0->field_33 = r1
    //     0x8a8538: stur            w1, [x0, #0x33]
    // 0x8a853c: ldur            x1, [fp, #-0xa0]
    // 0x8a8540: StoreField: r0->field_3f = r1
    //     0x8a8540: stur            w1, [x0, #0x3f]
    // 0x8a8544: ldur            x1, [fp, #-0x10]
    // 0x8a8548: StoreField: r0->field_37 = r1
    //     0x8a8548: stur            w1, [x0, #0x37]
    // 0x8a854c: ldur            x1, [fp, #-8]
    // 0x8a8550: StoreField: r0->field_3b = r1
    //     0x8a8550: stur            w1, [x0, #0x3b]
    // 0x8a8554: ldur            x1, [fp, #-0xa8]
    // 0x8a8558: StoreField: r0->field_43 = r1
    //     0x8a8558: stur            w1, [x0, #0x43]
    // 0x8a855c: ldur            x1, [fp, #-0x88]
    // 0x8a8560: StoreField: r0->field_47 = r1
    //     0x8a8560: stur            w1, [x0, #0x47]
    // 0x8a8564: ldur            x1, [fp, #-0xb0]
    // 0x8a8568: StoreField: r0->field_4b = r1
    //     0x8a8568: stur            w1, [x0, #0x4b]
    // 0x8a856c: ldur            x1, [fp, #-0x80]
    // 0x8a8570: StoreField: r0->field_4f = r1
    //     0x8a8570: stur            w1, [x0, #0x4f]
    // 0x8a8574: ldur            x1, [fp, #-0xb8]
    // 0x8a8578: StoreField: r0->field_53 = r1
    //     0x8a8578: stur            w1, [x0, #0x53]
    // 0x8a857c: ldur            x1, [fp, #-0xc0]
    // 0x8a8580: StoreField: r0->field_57 = r1
    //     0x8a8580: stur            w1, [x0, #0x57]
    // 0x8a8584: ldur            x1, [fp, #-0xc8]
    // 0x8a8588: StoreField: r0->field_5b = r1
    //     0x8a8588: stur            w1, [x0, #0x5b]
    // 0x8a858c: ldur            x1, [fp, #-0xd0]
    // 0x8a8590: StoreField: r0->field_5f = r1
    //     0x8a8590: stur            w1, [x0, #0x5f]
    // 0x8a8594: ldur            x1, [fp, #-0xd8]
    // 0x8a8598: StoreField: r0->field_63 = r1
    //     0x8a8598: stur            w1, [x0, #0x63]
    // 0x8a859c: ldur            x1, [fp, #-0xe0]
    // 0x8a85a0: StoreField: r0->field_67 = r1
    //     0x8a85a0: stur            w1, [x0, #0x67]
    // 0x8a85a4: ldur            x1, [fp, #-0xe8]
    // 0x8a85a8: StoreField: r0->field_6b = r1
    //     0x8a85a8: stur            w1, [x0, #0x6b]
    // 0x8a85ac: ldur            x1, [fp, #-0xf0]
    // 0x8a85b0: StoreField: r0->field_6f = r1
    //     0x8a85b0: stur            w1, [x0, #0x6f]
    // 0x8a85b4: r17 = -336
    //     0x8a85b4: mov             x17, #-0x150
    // 0x8a85b8: ldr             x1, [fp, x17]
    // 0x8a85bc: StoreField: r0->field_73 = r1
    //     0x8a85bc: stur            w1, [x0, #0x73]
    // 0x8a85c0: r17 = -344
    //     0x8a85c0: mov             x17, #-0x158
    // 0x8a85c4: ldr             x1, [fp, x17]
    // 0x8a85c8: StoreField: r0->field_77 = r1
    //     0x8a85c8: stur            w1, [x0, #0x77]
    // 0x8a85cc: r17 = -352
    //     0x8a85cc: mov             x17, #-0x160
    // 0x8a85d0: ldr             x1, [fp, x17]
    // 0x8a85d4: StoreField: r0->field_7b = r1
    //     0x8a85d4: stur            w1, [x0, #0x7b]
    // 0x8a85d8: r17 = -360
    //     0x8a85d8: mov             x17, #-0x168
    // 0x8a85dc: ldr             x1, [fp, x17]
    // 0x8a85e0: StoreField: r0->field_7f = r1
    //     0x8a85e0: stur            w1, [x0, #0x7f]
    // 0x8a85e4: r17 = -368
    //     0x8a85e4: mov             x17, #-0x170
    // 0x8a85e8: ldr             x1, [fp, x17]
    // 0x8a85ec: StoreField: r0->field_83 = r1
    //     0x8a85ec: stur            w1, [x0, #0x83]
    // 0x8a85f0: ldur            x1, [fp, #-0x60]
    // 0x8a85f4: StoreField: r0->field_87 = r1
    //     0x8a85f4: stur            w1, [x0, #0x87]
    // 0x8a85f8: r17 = -328
    //     0x8a85f8: mov             x17, #-0x148
    // 0x8a85fc: ldr             x1, [fp, x17]
    // 0x8a8600: StoreField: r0->field_8b = r1
    //     0x8a8600: stur            w1, [x0, #0x8b]
    // 0x8a8604: r17 = -320
    //     0x8a8604: mov             x17, #-0x140
    // 0x8a8608: ldr             x1, [fp, x17]
    // 0x8a860c: StoreField: r0->field_93 = r1
    //     0x8a860c: stur            w1, [x0, #0x93]
    // 0x8a8610: r17 = -312
    //     0x8a8610: mov             x17, #-0x138
    // 0x8a8614: ldr             x1, [fp, x17]
    // 0x8a8618: StoreField: r0->field_97 = r1
    //     0x8a8618: stur            w1, [x0, #0x97]
    // 0x8a861c: r17 = -304
    //     0x8a861c: mov             x17, #-0x130
    // 0x8a8620: ldr             x1, [fp, x17]
    // 0x8a8624: StoreField: r0->field_9b = r1
    //     0x8a8624: stur            w1, [x0, #0x9b]
    // 0x8a8628: r17 = -296
    //     0x8a8628: mov             x17, #-0x128
    // 0x8a862c: ldr             x1, [fp, x17]
    // 0x8a8630: StoreField: r0->field_9f = r1
    //     0x8a8630: stur            w1, [x0, #0x9f]
    // 0x8a8634: r17 = -288
    //     0x8a8634: mov             x17, #-0x120
    // 0x8a8638: ldr             x1, [fp, x17]
    // 0x8a863c: StoreField: r0->field_a3 = r1
    //     0x8a863c: stur            w1, [x0, #0xa3]
    // 0x8a8640: r17 = -280
    //     0x8a8640: mov             x17, #-0x118
    // 0x8a8644: ldr             x1, [fp, x17]
    // 0x8a8648: StoreField: r0->field_a7 = r1
    //     0x8a8648: stur            w1, [x0, #0xa7]
    // 0x8a864c: r17 = -272
    //     0x8a864c: mov             x17, #-0x110
    // 0x8a8650: ldr             x1, [fp, x17]
    // 0x8a8654: StoreField: r0->field_ab = r1
    //     0x8a8654: stur            w1, [x0, #0xab]
    // 0x8a8658: r17 = -264
    //     0x8a8658: mov             x17, #-0x108
    // 0x8a865c: ldr             x1, [fp, x17]
    // 0x8a8660: StoreField: r0->field_af = r1
    //     0x8a8660: stur            w1, [x0, #0xaf]
    // 0x8a8664: ldur            x1, [fp, #-0x100]
    // 0x8a8668: StoreField: r0->field_b3 = r1
    //     0x8a8668: stur            w1, [x0, #0xb3]
    // 0x8a866c: ldur            x1, [fp, #-0xf8]
    // 0x8a8670: StoreField: r0->field_b7 = r1
    //     0x8a8670: stur            w1, [x0, #0xb7]
    // 0x8a8674: ldur            x1, [fp, #-0x78]
    // 0x8a8678: StoreField: r0->field_bb = r1
    //     0x8a8678: stur            w1, [x0, #0xbb]
    // 0x8a867c: ldur            x1, [fp, #-0x70]
    // 0x8a8680: StoreField: r0->field_bf = r1
    //     0x8a8680: stur            w1, [x0, #0xbf]
    // 0x8a8684: ldur            x1, [fp, #-0x68]
    // 0x8a8688: StoreField: r0->field_c3 = r1
    //     0x8a8688: stur            w1, [x0, #0xc3]
    // 0x8a868c: ldur            x1, [fp, #-0x90]
    // 0x8a8690: StoreField: r0->field_c7 = r1
    //     0x8a8690: stur            w1, [x0, #0xc7]
    // 0x8a8694: r17 = -600
    //     0x8a8694: mov             x17, #-0x258
    // 0x8a8698: ldr             x1, [fp, x17]
    // 0x8a869c: StoreField: r0->field_cb = r1
    //     0x8a869c: stur            w1, [x0, #0xcb]
    // 0x8a86a0: r17 = -592
    //     0x8a86a0: mov             x17, #-0x250
    // 0x8a86a4: ldr             x1, [fp, x17]
    // 0x8a86a8: StoreField: r0->field_cf = r1
    //     0x8a86a8: stur            w1, [x0, #0xcf]
    // 0x8a86ac: r17 = -584
    //     0x8a86ac: mov             x17, #-0x248
    // 0x8a86b0: ldr             x1, [fp, x17]
    // 0x8a86b4: StoreField: r0->field_d3 = r1
    //     0x8a86b4: stur            w1, [x0, #0xd3]
    // 0x8a86b8: r17 = -576
    //     0x8a86b8: mov             x17, #-0x240
    // 0x8a86bc: ldr             x1, [fp, x17]
    // 0x8a86c0: StoreField: r0->field_d7 = r1
    //     0x8a86c0: stur            w1, [x0, #0xd7]
    // 0x8a86c4: r17 = -568
    //     0x8a86c4: mov             x17, #-0x238
    // 0x8a86c8: ldr             x1, [fp, x17]
    // 0x8a86cc: StoreField: r0->field_db = r1
    //     0x8a86cc: stur            w1, [x0, #0xdb]
    // 0x8a86d0: r17 = -560
    //     0x8a86d0: mov             x17, #-0x230
    // 0x8a86d4: ldr             x1, [fp, x17]
    // 0x8a86d8: StoreField: r0->field_df = r1
    //     0x8a86d8: stur            w1, [x0, #0xdf]
    // 0x8a86dc: r17 = -552
    //     0x8a86dc: mov             x17, #-0x228
    // 0x8a86e0: ldr             x1, [fp, x17]
    // 0x8a86e4: StoreField: r0->field_e3 = r1
    //     0x8a86e4: stur            w1, [x0, #0xe3]
    // 0x8a86e8: r17 = -544
    //     0x8a86e8: mov             x17, #-0x220
    // 0x8a86ec: ldr             x1, [fp, x17]
    // 0x8a86f0: StoreField: r0->field_e7 = r1
    //     0x8a86f0: stur            w1, [x0, #0xe7]
    // 0x8a86f4: r17 = -536
    //     0x8a86f4: mov             x17, #-0x218
    // 0x8a86f8: ldr             x1, [fp, x17]
    // 0x8a86fc: StoreField: r0->field_eb = r1
    //     0x8a86fc: stur            w1, [x0, #0xeb]
    // 0x8a8700: r17 = -528
    //     0x8a8700: mov             x17, #-0x210
    // 0x8a8704: ldr             x1, [fp, x17]
    // 0x8a8708: StoreField: r0->field_ef = r1
    //     0x8a8708: stur            w1, [x0, #0xef]
    // 0x8a870c: r17 = -520
    //     0x8a870c: mov             x17, #-0x208
    // 0x8a8710: ldr             x1, [fp, x17]
    // 0x8a8714: StoreField: r0->field_f3 = r1
    //     0x8a8714: stur            w1, [x0, #0xf3]
    // 0x8a8718: r17 = -512
    //     0x8a8718: mov             x17, #-0x200
    // 0x8a871c: ldr             x1, [fp, x17]
    // 0x8a8720: StoreField: r0->field_f7 = r1
    //     0x8a8720: stur            w1, [x0, #0xf7]
    // 0x8a8724: r17 = -504
    //     0x8a8724: mov             x17, #-0x1f8
    // 0x8a8728: ldr             x1, [fp, x17]
    // 0x8a872c: StoreField: r0->field_fb = r1
    //     0x8a872c: stur            w1, [x0, #0xfb]
    // 0x8a8730: r17 = -496
    //     0x8a8730: mov             x17, #-0x1f0
    // 0x8a8734: ldr             x1, [fp, x17]
    // 0x8a8738: StoreField: r0->field_ff = r1
    //     0x8a8738: stur            w1, [x0, #0xff]
    // 0x8a873c: r17 = -608
    //     0x8a873c: mov             x17, #-0x260
    // 0x8a8740: ldr             x1, [fp, x17]
    // 0x8a8744: r17 = 259
    //     0x8a8744: mov             x17, #0x103
    // 0x8a8748: str             w1, [x0, x17]
    // 0x8a874c: r17 = -616
    //     0x8a874c: mov             x17, #-0x268
    // 0x8a8750: ldr             x1, [fp, x17]
    // 0x8a8754: r17 = 263
    //     0x8a8754: mov             x17, #0x107
    // 0x8a8758: str             w1, [x0, x17]
    // 0x8a875c: r17 = -624
    //     0x8a875c: mov             x17, #-0x270
    // 0x8a8760: ldr             x1, [fp, x17]
    // 0x8a8764: r17 = 267
    //     0x8a8764: mov             x17, #0x10b
    // 0x8a8768: str             w1, [x0, x17]
    // 0x8a876c: r17 = -632
    //     0x8a876c: mov             x17, #-0x278
    // 0x8a8770: ldr             x1, [fp, x17]
    // 0x8a8774: r17 = 271
    //     0x8a8774: mov             x17, #0x10f
    // 0x8a8778: str             w1, [x0, x17]
    // 0x8a877c: r17 = -376
    //     0x8a877c: mov             x17, #-0x178
    // 0x8a8780: ldr             x1, [fp, x17]
    // 0x8a8784: r17 = 275
    //     0x8a8784: mov             x17, #0x113
    // 0x8a8788: str             w1, [x0, x17]
    // 0x8a878c: r17 = -384
    //     0x8a878c: mov             x17, #-0x180
    // 0x8a8790: ldr             x1, [fp, x17]
    // 0x8a8794: r17 = 279
    //     0x8a8794: mov             x17, #0x117
    // 0x8a8798: str             w1, [x0, x17]
    // 0x8a879c: r17 = -392
    //     0x8a879c: mov             x17, #-0x188
    // 0x8a87a0: ldr             x1, [fp, x17]
    // 0x8a87a4: r17 = 283
    //     0x8a87a4: mov             x17, #0x11b
    // 0x8a87a8: str             w1, [x0, x17]
    // 0x8a87ac: r17 = -400
    //     0x8a87ac: mov             x17, #-0x190
    // 0x8a87b0: ldr             x1, [fp, x17]
    // 0x8a87b4: r17 = 287
    //     0x8a87b4: mov             x17, #0x11f
    // 0x8a87b8: str             w1, [x0, x17]
    // 0x8a87bc: r17 = -408
    //     0x8a87bc: mov             x17, #-0x198
    // 0x8a87c0: ldr             x1, [fp, x17]
    // 0x8a87c4: r17 = 291
    //     0x8a87c4: mov             x17, #0x123
    // 0x8a87c8: str             w1, [x0, x17]
    // 0x8a87cc: r17 = -416
    //     0x8a87cc: mov             x17, #-0x1a0
    // 0x8a87d0: ldr             x1, [fp, x17]
    // 0x8a87d4: r17 = 295
    //     0x8a87d4: mov             x17, #0x127
    // 0x8a87d8: str             w1, [x0, x17]
    // 0x8a87dc: r17 = -424
    //     0x8a87dc: mov             x17, #-0x1a8
    // 0x8a87e0: ldr             x1, [fp, x17]
    // 0x8a87e4: r17 = 299
    //     0x8a87e4: mov             x17, #0x12b
    // 0x8a87e8: str             w1, [x0, x17]
    // 0x8a87ec: r17 = -432
    //     0x8a87ec: mov             x17, #-0x1b0
    // 0x8a87f0: ldr             x1, [fp, x17]
    // 0x8a87f4: r17 = 303
    //     0x8a87f4: mov             x17, #0x12f
    // 0x8a87f8: str             w1, [x0, x17]
    // 0x8a87fc: r17 = -440
    //     0x8a87fc: mov             x17, #-0x1b8
    // 0x8a8800: ldr             x1, [fp, x17]
    // 0x8a8804: r17 = 307
    //     0x8a8804: mov             x17, #0x133
    // 0x8a8808: str             w1, [x0, x17]
    // 0x8a880c: r17 = -448
    //     0x8a880c: mov             x17, #-0x1c0
    // 0x8a8810: ldr             x1, [fp, x17]
    // 0x8a8814: r17 = 311
    //     0x8a8814: mov             x17, #0x137
    // 0x8a8818: str             w1, [x0, x17]
    // 0x8a881c: r17 = -456
    //     0x8a881c: mov             x17, #-0x1c8
    // 0x8a8820: ldr             x1, [fp, x17]
    // 0x8a8824: r17 = 315
    //     0x8a8824: mov             x17, #0x13b
    // 0x8a8828: str             w1, [x0, x17]
    // 0x8a882c: r17 = -464
    //     0x8a882c: mov             x17, #-0x1d0
    // 0x8a8830: ldr             x1, [fp, x17]
    // 0x8a8834: r17 = 319
    //     0x8a8834: mov             x17, #0x13f
    // 0x8a8838: str             w1, [x0, x17]
    // 0x8a883c: r17 = -472
    //     0x8a883c: mov             x17, #-0x1d8
    // 0x8a8840: ldr             x1, [fp, x17]
    // 0x8a8844: r17 = 323
    //     0x8a8844: mov             x17, #0x143
    // 0x8a8848: str             w1, [x0, x17]
    // 0x8a884c: r17 = -488
    //     0x8a884c: mov             x17, #-0x1e8
    // 0x8a8850: ldr             x1, [fp, x17]
    // 0x8a8854: r17 = 331
    //     0x8a8854: mov             x17, #0x14b
    // 0x8a8858: str             w1, [x0, x17]
    // 0x8a885c: r17 = -640
    //     0x8a885c: mov             x17, #-0x280
    // 0x8a8860: ldr             x1, [fp, x17]
    // 0x8a8864: r17 = 335
    //     0x8a8864: mov             x17, #0x14f
    // 0x8a8868: str             w1, [x0, x17]
    // 0x8a886c: r17 = -480
    //     0x8a886c: mov             x17, #-0x1e0
    // 0x8a8870: ldr             x1, [fp, x17]
    // 0x8a8874: r17 = 327
    //     0x8a8874: mov             x17, #0x147
    // 0x8a8878: str             w1, [x0, x17]
    // 0x8a887c: LeaveFrame
    //     0x8a887c: mov             SP, fp
    //     0x8a8880: ldp             fp, lr, [SP], #0x10
    // 0x8a8884: ret
    //     0x8a8884: ret             
    // 0x8a8888: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a8888: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a888c: b               #0x8a7e94
  }
  static _FifoCache<_IdentityThemeDataCacheKey, ThemeData> _localizedThemeDataCache() {
    // ** addr: 0x8a9afc, size: 0x60
    // 0x8a9afc: EnterFrame
    //     0x8a9afc: stp             fp, lr, [SP, #-0x10]!
    //     0x8a9b00: mov             fp, SP
    // 0x8a9b04: AllocStack(0x18)
    //     0x8a9b04: sub             SP, SP, #0x18
    // 0x8a9b08: CheckStackOverflow
    //     0x8a9b08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a9b0c: cmp             SP, x16
    //     0x8a9b10: b.ls            #0x8a9b54
    // 0x8a9b14: r16 = <_IdentityThemeDataCacheKey, ThemeData>
    //     0x8a9b14: add             x16, PP, #0x12, lsl #12  ; [pp+0x12978] TypeArguments: <_IdentityThemeDataCacheKey, ThemeData>
    //     0x8a9b18: ldr             x16, [x16, #0x978]
    // 0x8a9b1c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x8a9b20: stp             lr, x16, [SP]
    // 0x8a9b24: r0 = Map._fromLiteral()
    //     0x8a9b24: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8a9b28: r1 = <_IdentityThemeDataCacheKey, ThemeData>
    //     0x8a9b28: add             x1, PP, #0x12, lsl #12  ; [pp+0x12978] TypeArguments: <_IdentityThemeDataCacheKey, ThemeData>
    //     0x8a9b2c: ldr             x1, [x1, #0x978]
    // 0x8a9b30: stur            x0, [fp, #-8]
    // 0x8a9b34: r0 = _FifoCache()
    //     0x8a9b34: bl              #0x8a9b5c  ; Allocate_FifoCacheStub -> _FifoCache<X0, X1> (size=0x18)
    // 0x8a9b38: ldur            x1, [fp, #-8]
    // 0x8a9b3c: StoreField: r0->field_b = r1
    //     0x8a9b3c: stur            w1, [x0, #0xb]
    // 0x8a9b40: r1 = 5
    //     0x8a9b40: mov             x1, #5
    // 0x8a9b44: StoreField: r0->field_f = r1
    //     0x8a9b44: stur            x1, [x0, #0xf]
    // 0x8a9b48: LeaveFrame
    //     0x8a9b48: mov             SP, fp
    //     0x8a9b4c: ldp             fp, lr, [SP], #0x10
    // 0x8a9b50: ret
    //     0x8a9b50: ret             
    // 0x8a9b54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a9b54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a9b58: b               #0x8a9b14
  }
  factory _ ThemeData(/* No info */) {
    // ** addr: 0x8a9c18, size: 0x20d0
    // 0x8a9c18: EnterFrame
    //     0x8a9c18: stp             fp, lr, [SP, #-0x10]!
    //     0x8a9c1c: mov             fp, SP
    // 0x8a9c20: AllocStack(0x128)
    //     0x8a9c20: sub             SP, SP, #0x128
    // 0x8a9c24: SetupParameters({dynamic adaptations, dynamic appBarTheme = Null /* r3, fp-0x48 */, dynamic applyElevationOverlayColor, dynamic badgeTheme, dynamic bannerTheme, dynamic bottomAppBarTheme, dynamic bottomNavigationBarTheme, dynamic bottomSheetTheme, dynamic brightness = Null /* r5, fp-0x40 */, dynamic buttonBarTheme, dynamic buttonTheme, dynamic canvasColor, dynamic cardColor, dynamic cardTheme, dynamic carouselViewTheme, dynamic checkboxTheme, dynamic chipTheme, dynamic colorScheme = Null /* r6, fp-0x38 */, dynamic cupertinoOverrideTheme, dynamic dataTableTheme, dynamic datePickerTheme, dynamic dialogBackgroundColor, dynamic dialogTheme, dynamic disabledColor, dynamic dividerColor, dynamic dividerTheme, dynamic drawerTheme, dynamic dropdownMenuTheme, dynamic elevatedButtonTheme, dynamic expansionTileTheme, dynamic extensions = Null /* r2 */, dynamic filledButtonTheme, dynamic floatingActionButtonTheme = Null /* r7, fp-0x30 */, dynamic focusColor, dynamic highlightColor, dynamic hintColor, dynamic hoverColor, dynamic iconButtonTheme, dynamic iconTheme, dynamic indicatorColor, dynamic inputDecorationTheme = Null /* r8, fp-0x28 */, dynamic listTileTheme, dynamic materialTapTargetSize, dynamic menuBarTheme, dynamic menuButtonTheme, dynamic menuTheme, dynamic navigationBarTheme, dynamic navigationDrawerTheme, dynamic navigationRailTheme, dynamic outlinedButtonTheme, dynamic pageTransitionsTheme, dynamic platform, dynamic popupMenuTheme, dynamic primaryColor = Null /* r9, fp-0x20 */, dynamic primaryColorDark, dynamic primaryColorLight, dynamic primaryIconTheme, dynamic primarySwatch, dynamic primaryTextTheme, dynamic progressIndicatorTheme, dynamic radioTheme, dynamic scaffoldBackgroundColor = Null /* r10, fp-0x18 */, dynamic scrollbarTheme, dynamic searchBarTheme, dynamic searchViewTheme, dynamic secondaryHeaderColor, dynamic segmentedButtonTheme, dynamic shadowColor, dynamic sliderTheme, dynamic snackBarTheme, dynamic splashColor, dynamic splashFactory, dynamic switchTheme, dynamic tabBarTheme = Null /* r11, fp-0x10 */, dynamic textButtonTheme, dynamic textSelectionTheme, dynamic textTheme, dynamic timePickerTheme, dynamic toggleButtonsTheme, dynamic tooltipTheme, dynamic typography, dynamic unselectedWidgetColor, dynamic useMaterial3 = Null /* r12, fp-0x8 */, dynamic useSystemColors})
    //     0x8a9c24: ldur            w0, [x4, #0x13]
    //     0x8a9c28: ldur            w1, [x4, #0x1f]
    //     0x8a9c2c: add             x1, x1, HEAP, lsl #32
    //     0x8a9c30: add             x16, PP, #0x12, lsl #12  ; [pp+0x12990] "adaptations"
    //     0x8a9c34: ldr             x16, [x16, #0x990]
    //     0x8a9c38: cmp             w1, w16
    //     0x8a9c3c: b.ne            #0x8a9c48
    //     0x8a9c40: mov             x1, #1
    //     0x8a9c44: b               #0x8a9c4c
    //     0x8a9c48: mov             x1, #0
    //     0x8a9c4c: lsl             x2, x1, #1
    //     0x8a9c50: lsl             w3, w2, #1
    //     0x8a9c54: add             w5, w3, #8
    //     0x8a9c58: add             x16, x4, w5, sxtw #1
    //     0x8a9c5c: ldur            w6, [x16, #0xf]
    //     0x8a9c60: add             x6, x6, HEAP, lsl #32
    //     0x8a9c64: add             x16, PP, #0x12, lsl #12  ; [pp+0x12998] "appBarTheme"
    //     0x8a9c68: ldr             x16, [x16, #0x998]
    //     0x8a9c6c: cmp             w6, w16
    //     0x8a9c70: b.ne            #0x8a9ca0
    //     0x8a9c74: add             w1, w3, #0xa
    //     0x8a9c78: add             x16, x4, w1, sxtw #1
    //     0x8a9c7c: ldur            w3, [x16, #0xf]
    //     0x8a9c80: add             x3, x3, HEAP, lsl #32
    //     0x8a9c84: sub             w1, w0, w3
    //     0x8a9c88: add             x3, fp, w1, sxtw #2
    //     0x8a9c8c: ldr             x3, [x3, #8]
    //     0x8a9c90: add             w1, w2, #2
    //     0x8a9c94: sbfx            x2, x1, #1, #0x1f
    //     0x8a9c98: mov             x1, x2
    //     0x8a9c9c: b               #0x8a9ca4
    //     0x8a9ca0: mov             x3, NULL
    //     0x8a9ca4: stur            x3, [fp, #-0x48]
    //     0x8a9ca8: lsl             x2, x1, #1
    //     0x8a9cac: lsl             w5, w2, #1
    //     0x8a9cb0: add             w6, w5, #8
    //     0x8a9cb4: add             x16, x4, w6, sxtw #1
    //     0x8a9cb8: ldur            w5, [x16, #0xf]
    //     0x8a9cbc: add             x5, x5, HEAP, lsl #32
    //     0x8a9cc0: add             x16, PP, #0x12, lsl #12  ; [pp+0x129a0] "applyElevationOverlayColor"
    //     0x8a9cc4: ldr             x16, [x16, #0x9a0]
    //     0x8a9cc8: cmp             w5, w16
    //     0x8a9ccc: b.ne            #0x8a9cdc
    //     0x8a9cd0: add             w1, w2, #2
    //     0x8a9cd4: sbfx            x2, x1, #1, #0x1f
    //     0x8a9cd8: mov             x1, x2
    //     0x8a9cdc: lsl             x2, x1, #1
    //     0x8a9ce0: lsl             w5, w2, #1
    //     0x8a9ce4: add             w6, w5, #8
    //     0x8a9ce8: add             x16, x4, w6, sxtw #1
    //     0x8a9cec: ldur            w5, [x16, #0xf]
    //     0x8a9cf0: add             x5, x5, HEAP, lsl #32
    //     0x8a9cf4: add             x16, PP, #0x12, lsl #12  ; [pp+0x129a8] "badgeTheme"
    //     0x8a9cf8: ldr             x16, [x16, #0x9a8]
    //     0x8a9cfc: cmp             w5, w16
    //     0x8a9d00: b.ne            #0x8a9d10
    //     0x8a9d04: add             w1, w2, #2
    //     0x8a9d08: sbfx            x2, x1, #1, #0x1f
    //     0x8a9d0c: mov             x1, x2
    //     0x8a9d10: lsl             x2, x1, #1
    //     0x8a9d14: lsl             w5, w2, #1
    //     0x8a9d18: add             w6, w5, #8
    //     0x8a9d1c: add             x16, x4, w6, sxtw #1
    //     0x8a9d20: ldur            w5, [x16, #0xf]
    //     0x8a9d24: add             x5, x5, HEAP, lsl #32
    //     0x8a9d28: add             x16, PP, #0x12, lsl #12  ; [pp+0x129b0] "bannerTheme"
    //     0x8a9d2c: ldr             x16, [x16, #0x9b0]
    //     0x8a9d30: cmp             w5, w16
    //     0x8a9d34: b.ne            #0x8a9d44
    //     0x8a9d38: add             w1, w2, #2
    //     0x8a9d3c: sbfx            x2, x1, #1, #0x1f
    //     0x8a9d40: mov             x1, x2
    //     0x8a9d44: lsl             x2, x1, #1
    //     0x8a9d48: lsl             w5, w2, #1
    //     0x8a9d4c: add             w6, w5, #8
    //     0x8a9d50: add             x16, x4, w6, sxtw #1
    //     0x8a9d54: ldur            w5, [x16, #0xf]
    //     0x8a9d58: add             x5, x5, HEAP, lsl #32
    //     0x8a9d5c: add             x16, PP, #0x12, lsl #12  ; [pp+0x129b8] "bottomAppBarTheme"
    //     0x8a9d60: ldr             x16, [x16, #0x9b8]
    //     0x8a9d64: cmp             w5, w16
    //     0x8a9d68: b.ne            #0x8a9d78
    //     0x8a9d6c: add             w1, w2, #2
    //     0x8a9d70: sbfx            x2, x1, #1, #0x1f
    //     0x8a9d74: mov             x1, x2
    //     0x8a9d78: lsl             x2, x1, #1
    //     0x8a9d7c: lsl             w5, w2, #1
    //     0x8a9d80: add             w6, w5, #8
    //     0x8a9d84: add             x16, x4, w6, sxtw #1
    //     0x8a9d88: ldur            w5, [x16, #0xf]
    //     0x8a9d8c: add             x5, x5, HEAP, lsl #32
    //     0x8a9d90: add             x16, PP, #0x12, lsl #12  ; [pp+0x129c0] "bottomNavigationBarTheme"
    //     0x8a9d94: ldr             x16, [x16, #0x9c0]
    //     0x8a9d98: cmp             w5, w16
    //     0x8a9d9c: b.ne            #0x8a9dac
    //     0x8a9da0: add             w1, w2, #2
    //     0x8a9da4: sbfx            x2, x1, #1, #0x1f
    //     0x8a9da8: mov             x1, x2
    //     0x8a9dac: lsl             x2, x1, #1
    //     0x8a9db0: lsl             w5, w2, #1
    //     0x8a9db4: add             w6, w5, #8
    //     0x8a9db8: add             x16, x4, w6, sxtw #1
    //     0x8a9dbc: ldur            w5, [x16, #0xf]
    //     0x8a9dc0: add             x5, x5, HEAP, lsl #32
    //     0x8a9dc4: add             x16, PP, #0x12, lsl #12  ; [pp+0x129c8] "bottomSheetTheme"
    //     0x8a9dc8: ldr             x16, [x16, #0x9c8]
    //     0x8a9dcc: cmp             w5, w16
    //     0x8a9dd0: b.ne            #0x8a9de0
    //     0x8a9dd4: add             w1, w2, #2
    //     0x8a9dd8: sbfx            x2, x1, #1, #0x1f
    //     0x8a9ddc: mov             x1, x2
    //     0x8a9de0: lsl             x2, x1, #1
    //     0x8a9de4: lsl             w5, w2, #1
    //     0x8a9de8: add             w6, w5, #8
    //     0x8a9dec: add             x16, x4, w6, sxtw #1
    //     0x8a9df0: ldur            w7, [x16, #0xf]
    //     0x8a9df4: add             x7, x7, HEAP, lsl #32
    //     0x8a9df8: add             x16, PP, #0x12, lsl #12  ; [pp+0x129d0] "brightness"
    //     0x8a9dfc: ldr             x16, [x16, #0x9d0]
    //     0x8a9e00: cmp             w7, w16
    //     0x8a9e04: b.ne            #0x8a9e34
    //     0x8a9e08: add             w1, w5, #0xa
    //     0x8a9e0c: add             x16, x4, w1, sxtw #1
    //     0x8a9e10: ldur            w5, [x16, #0xf]
    //     0x8a9e14: add             x5, x5, HEAP, lsl #32
    //     0x8a9e18: sub             w1, w0, w5
    //     0x8a9e1c: add             x5, fp, w1, sxtw #2
    //     0x8a9e20: ldr             x5, [x5, #8]
    //     0x8a9e24: add             w1, w2, #2
    //     0x8a9e28: sbfx            x2, x1, #1, #0x1f
    //     0x8a9e2c: mov             x1, x2
    //     0x8a9e30: b               #0x8a9e38
    //     0x8a9e34: mov             x5, NULL
    //     0x8a9e38: stur            x5, [fp, #-0x40]
    //     0x8a9e3c: lsl             x2, x1, #1
    //     0x8a9e40: lsl             w6, w2, #1
    //     0x8a9e44: add             w7, w6, #8
    //     0x8a9e48: add             x16, x4, w7, sxtw #1
    //     0x8a9e4c: ldur            w6, [x16, #0xf]
    //     0x8a9e50: add             x6, x6, HEAP, lsl #32
    //     0x8a9e54: add             x16, PP, #0x12, lsl #12  ; [pp+0x129d8] "buttonBarTheme"
    //     0x8a9e58: ldr             x16, [x16, #0x9d8]
    //     0x8a9e5c: cmp             w6, w16
    //     0x8a9e60: b.ne            #0x8a9e70
    //     0x8a9e64: add             w1, w2, #2
    //     0x8a9e68: sbfx            x2, x1, #1, #0x1f
    //     0x8a9e6c: mov             x1, x2
    //     0x8a9e70: lsl             x2, x1, #1
    //     0x8a9e74: lsl             w6, w2, #1
    //     0x8a9e78: add             w7, w6, #8
    //     0x8a9e7c: add             x16, x4, w7, sxtw #1
    //     0x8a9e80: ldur            w6, [x16, #0xf]
    //     0x8a9e84: add             x6, x6, HEAP, lsl #32
    //     0x8a9e88: add             x16, PP, #0x12, lsl #12  ; [pp+0x129e0] "buttonTheme"
    //     0x8a9e8c: ldr             x16, [x16, #0x9e0]
    //     0x8a9e90: cmp             w6, w16
    //     0x8a9e94: b.ne            #0x8a9ea4
    //     0x8a9e98: add             w1, w2, #2
    //     0x8a9e9c: sbfx            x2, x1, #1, #0x1f
    //     0x8a9ea0: mov             x1, x2
    //     0x8a9ea4: lsl             x2, x1, #1
    //     0x8a9ea8: lsl             w6, w2, #1
    //     0x8a9eac: add             w7, w6, #8
    //     0x8a9eb0: add             x16, x4, w7, sxtw #1
    //     0x8a9eb4: ldur            w6, [x16, #0xf]
    //     0x8a9eb8: add             x6, x6, HEAP, lsl #32
    //     0x8a9ebc: add             x16, PP, #0x12, lsl #12  ; [pp+0x129e8] "canvasColor"
    //     0x8a9ec0: ldr             x16, [x16, #0x9e8]
    //     0x8a9ec4: cmp             w6, w16
    //     0x8a9ec8: b.ne            #0x8a9ed8
    //     0x8a9ecc: add             w1, w2, #2
    //     0x8a9ed0: sbfx            x2, x1, #1, #0x1f
    //     0x8a9ed4: mov             x1, x2
    //     0x8a9ed8: lsl             x2, x1, #1
    //     0x8a9edc: lsl             w6, w2, #1
    //     0x8a9ee0: add             w7, w6, #8
    //     0x8a9ee4: add             x16, x4, w7, sxtw #1
    //     0x8a9ee8: ldur            w6, [x16, #0xf]
    //     0x8a9eec: add             x6, x6, HEAP, lsl #32
    //     0x8a9ef0: add             x16, PP, #0x12, lsl #12  ; [pp+0x129f0] "cardColor"
    //     0x8a9ef4: ldr             x16, [x16, #0x9f0]
    //     0x8a9ef8: cmp             w6, w16
    //     0x8a9efc: b.ne            #0x8a9f0c
    //     0x8a9f00: add             w1, w2, #2
    //     0x8a9f04: sbfx            x2, x1, #1, #0x1f
    //     0x8a9f08: mov             x1, x2
    //     0x8a9f0c: lsl             x2, x1, #1
    //     0x8a9f10: lsl             w6, w2, #1
    //     0x8a9f14: add             w7, w6, #8
    //     0x8a9f18: add             x16, x4, w7, sxtw #1
    //     0x8a9f1c: ldur            w6, [x16, #0xf]
    //     0x8a9f20: add             x6, x6, HEAP, lsl #32
    //     0x8a9f24: add             x16, PP, #0x12, lsl #12  ; [pp+0x129f8] "cardTheme"
    //     0x8a9f28: ldr             x16, [x16, #0x9f8]
    //     0x8a9f2c: cmp             w6, w16
    //     0x8a9f30: b.ne            #0x8a9f40
    //     0x8a9f34: add             w1, w2, #2
    //     0x8a9f38: sbfx            x2, x1, #1, #0x1f
    //     0x8a9f3c: mov             x1, x2
    //     0x8a9f40: lsl             x2, x1, #1
    //     0x8a9f44: lsl             w6, w2, #1
    //     0x8a9f48: add             w7, w6, #8
    //     0x8a9f4c: add             x16, x4, w7, sxtw #1
    //     0x8a9f50: ldur            w6, [x16, #0xf]
    //     0x8a9f54: add             x6, x6, HEAP, lsl #32
    //     0x8a9f58: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a00] "carouselViewTheme"
    //     0x8a9f5c: ldr             x16, [x16, #0xa00]
    //     0x8a9f60: cmp             w6, w16
    //     0x8a9f64: b.ne            #0x8a9f74
    //     0x8a9f68: add             w1, w2, #2
    //     0x8a9f6c: sbfx            x2, x1, #1, #0x1f
    //     0x8a9f70: mov             x1, x2
    //     0x8a9f74: lsl             x2, x1, #1
    //     0x8a9f78: lsl             w6, w2, #1
    //     0x8a9f7c: add             w7, w6, #8
    //     0x8a9f80: add             x16, x4, w7, sxtw #1
    //     0x8a9f84: ldur            w6, [x16, #0xf]
    //     0x8a9f88: add             x6, x6, HEAP, lsl #32
    //     0x8a9f8c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a08] "checkboxTheme"
    //     0x8a9f90: ldr             x16, [x16, #0xa08]
    //     0x8a9f94: cmp             w6, w16
    //     0x8a9f98: b.ne            #0x8a9fa8
    //     0x8a9f9c: add             w1, w2, #2
    //     0x8a9fa0: sbfx            x2, x1, #1, #0x1f
    //     0x8a9fa4: mov             x1, x2
    //     0x8a9fa8: lsl             x2, x1, #1
    //     0x8a9fac: lsl             w6, w2, #1
    //     0x8a9fb0: add             w7, w6, #8
    //     0x8a9fb4: add             x16, x4, w7, sxtw #1
    //     0x8a9fb8: ldur            w6, [x16, #0xf]
    //     0x8a9fbc: add             x6, x6, HEAP, lsl #32
    //     0x8a9fc0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a10] "chipTheme"
    //     0x8a9fc4: ldr             x16, [x16, #0xa10]
    //     0x8a9fc8: cmp             w6, w16
    //     0x8a9fcc: b.ne            #0x8a9fdc
    //     0x8a9fd0: add             w1, w2, #2
    //     0x8a9fd4: sbfx            x2, x1, #1, #0x1f
    //     0x8a9fd8: mov             x1, x2
    //     0x8a9fdc: lsl             x2, x1, #1
    //     0x8a9fe0: lsl             w6, w2, #1
    //     0x8a9fe4: add             w7, w6, #8
    //     0x8a9fe8: add             x16, x4, w7, sxtw #1
    //     0x8a9fec: ldur            w8, [x16, #0xf]
    //     0x8a9ff0: add             x8, x8, HEAP, lsl #32
    //     0x8a9ff4: add             x16, PP, #0x12, lsl #12  ; [pp+0x128f0] "colorScheme"
    //     0x8a9ff8: ldr             x16, [x16, #0x8f0]
    //     0x8a9ffc: cmp             w8, w16
    //     0x8aa000: b.ne            #0x8aa030
    //     0x8aa004: add             w1, w6, #0xa
    //     0x8aa008: add             x16, x4, w1, sxtw #1
    //     0x8aa00c: ldur            w6, [x16, #0xf]
    //     0x8aa010: add             x6, x6, HEAP, lsl #32
    //     0x8aa014: sub             w1, w0, w6
    //     0x8aa018: add             x6, fp, w1, sxtw #2
    //     0x8aa01c: ldr             x6, [x6, #8]
    //     0x8aa020: add             w1, w2, #2
    //     0x8aa024: sbfx            x2, x1, #1, #0x1f
    //     0x8aa028: mov             x1, x2
    //     0x8aa02c: b               #0x8aa034
    //     0x8aa030: mov             x6, NULL
    //     0x8aa034: stur            x6, [fp, #-0x38]
    //     0x8aa038: lsl             x2, x1, #1
    //     0x8aa03c: lsl             w7, w2, #1
    //     0x8aa040: add             w8, w7, #8
    //     0x8aa044: add             x16, x4, w8, sxtw #1
    //     0x8aa048: ldur            w7, [x16, #0xf]
    //     0x8aa04c: add             x7, x7, HEAP, lsl #32
    //     0x8aa050: add             x16, PP, #0x12, lsl #12  ; [pp+0x128f8] "cupertinoOverrideTheme"
    //     0x8aa054: ldr             x16, [x16, #0x8f8]
    //     0x8aa058: cmp             w7, w16
    //     0x8aa05c: b.ne            #0x8aa06c
    //     0x8aa060: add             w1, w2, #2
    //     0x8aa064: sbfx            x2, x1, #1, #0x1f
    //     0x8aa068: mov             x1, x2
    //     0x8aa06c: lsl             x2, x1, #1
    //     0x8aa070: lsl             w7, w2, #1
    //     0x8aa074: add             w8, w7, #8
    //     0x8aa078: add             x16, x4, w8, sxtw #1
    //     0x8aa07c: ldur            w7, [x16, #0xf]
    //     0x8aa080: add             x7, x7, HEAP, lsl #32
    //     0x8aa084: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a18] "dataTableTheme"
    //     0x8aa088: ldr             x16, [x16, #0xa18]
    //     0x8aa08c: cmp             w7, w16
    //     0x8aa090: b.ne            #0x8aa0a0
    //     0x8aa094: add             w1, w2, #2
    //     0x8aa098: sbfx            x2, x1, #1, #0x1f
    //     0x8aa09c: mov             x1, x2
    //     0x8aa0a0: lsl             x2, x1, #1
    //     0x8aa0a4: lsl             w7, w2, #1
    //     0x8aa0a8: add             w8, w7, #8
    //     0x8aa0ac: add             x16, x4, w8, sxtw #1
    //     0x8aa0b0: ldur            w7, [x16, #0xf]
    //     0x8aa0b4: add             x7, x7, HEAP, lsl #32
    //     0x8aa0b8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12900] "datePickerTheme"
    //     0x8aa0bc: ldr             x16, [x16, #0x900]
    //     0x8aa0c0: cmp             w7, w16
    //     0x8aa0c4: b.ne            #0x8aa0d4
    //     0x8aa0c8: add             w1, w2, #2
    //     0x8aa0cc: sbfx            x2, x1, #1, #0x1f
    //     0x8aa0d0: mov             x1, x2
    //     0x8aa0d4: lsl             x2, x1, #1
    //     0x8aa0d8: lsl             w7, w2, #1
    //     0x8aa0dc: add             w8, w7, #8
    //     0x8aa0e0: add             x16, x4, w8, sxtw #1
    //     0x8aa0e4: ldur            w7, [x16, #0xf]
    //     0x8aa0e8: add             x7, x7, HEAP, lsl #32
    //     0x8aa0ec: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a20] "dialogBackgroundColor"
    //     0x8aa0f0: ldr             x16, [x16, #0xa20]
    //     0x8aa0f4: cmp             w7, w16
    //     0x8aa0f8: b.ne            #0x8aa108
    //     0x8aa0fc: add             w1, w2, #2
    //     0x8aa100: sbfx            x2, x1, #1, #0x1f
    //     0x8aa104: mov             x1, x2
    //     0x8aa108: lsl             x2, x1, #1
    //     0x8aa10c: lsl             w7, w2, #1
    //     0x8aa110: add             w8, w7, #8
    //     0x8aa114: add             x16, x4, w8, sxtw #1
    //     0x8aa118: ldur            w7, [x16, #0xf]
    //     0x8aa11c: add             x7, x7, HEAP, lsl #32
    //     0x8aa120: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a28] "dialogTheme"
    //     0x8aa124: ldr             x16, [x16, #0xa28]
    //     0x8aa128: cmp             w7, w16
    //     0x8aa12c: b.ne            #0x8aa13c
    //     0x8aa130: add             w1, w2, #2
    //     0x8aa134: sbfx            x2, x1, #1, #0x1f
    //     0x8aa138: mov             x1, x2
    //     0x8aa13c: lsl             x2, x1, #1
    //     0x8aa140: lsl             w7, w2, #1
    //     0x8aa144: add             w8, w7, #8
    //     0x8aa148: add             x16, x4, w8, sxtw #1
    //     0x8aa14c: ldur            w7, [x16, #0xf]
    //     0x8aa150: add             x7, x7, HEAP, lsl #32
    //     0x8aa154: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a30] "disabledColor"
    //     0x8aa158: ldr             x16, [x16, #0xa30]
    //     0x8aa15c: cmp             w7, w16
    //     0x8aa160: b.ne            #0x8aa170
    //     0x8aa164: add             w1, w2, #2
    //     0x8aa168: sbfx            x2, x1, #1, #0x1f
    //     0x8aa16c: mov             x1, x2
    //     0x8aa170: lsl             x2, x1, #1
    //     0x8aa174: lsl             w7, w2, #1
    //     0x8aa178: add             w8, w7, #8
    //     0x8aa17c: add             x16, x4, w8, sxtw #1
    //     0x8aa180: ldur            w7, [x16, #0xf]
    //     0x8aa184: add             x7, x7, HEAP, lsl #32
    //     0x8aa188: add             x16, PP, #0x12, lsl #12  ; [pp+0x12908] "dividerColor"
    //     0x8aa18c: ldr             x16, [x16, #0x908]
    //     0x8aa190: cmp             w7, w16
    //     0x8aa194: b.ne            #0x8aa1a4
    //     0x8aa198: add             w1, w2, #2
    //     0x8aa19c: sbfx            x2, x1, #1, #0x1f
    //     0x8aa1a0: mov             x1, x2
    //     0x8aa1a4: lsl             x2, x1, #1
    //     0x8aa1a8: lsl             w7, w2, #1
    //     0x8aa1ac: add             w8, w7, #8
    //     0x8aa1b0: add             x16, x4, w8, sxtw #1
    //     0x8aa1b4: ldur            w7, [x16, #0xf]
    //     0x8aa1b8: add             x7, x7, HEAP, lsl #32
    //     0x8aa1bc: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a38] "dividerTheme"
    //     0x8aa1c0: ldr             x16, [x16, #0xa38]
    //     0x8aa1c4: cmp             w7, w16
    //     0x8aa1c8: b.ne            #0x8aa1d8
    //     0x8aa1cc: add             w1, w2, #2
    //     0x8aa1d0: sbfx            x2, x1, #1, #0x1f
    //     0x8aa1d4: mov             x1, x2
    //     0x8aa1d8: lsl             x2, x1, #1
    //     0x8aa1dc: lsl             w7, w2, #1
    //     0x8aa1e0: add             w8, w7, #8
    //     0x8aa1e4: add             x16, x4, w8, sxtw #1
    //     0x8aa1e8: ldur            w7, [x16, #0xf]
    //     0x8aa1ec: add             x7, x7, HEAP, lsl #32
    //     0x8aa1f0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a40] "drawerTheme"
    //     0x8aa1f4: ldr             x16, [x16, #0xa40]
    //     0x8aa1f8: cmp             w7, w16
    //     0x8aa1fc: b.ne            #0x8aa20c
    //     0x8aa200: add             w1, w2, #2
    //     0x8aa204: sbfx            x2, x1, #1, #0x1f
    //     0x8aa208: mov             x1, x2
    //     0x8aa20c: lsl             x2, x1, #1
    //     0x8aa210: lsl             w7, w2, #1
    //     0x8aa214: add             w8, w7, #8
    //     0x8aa218: add             x16, x4, w8, sxtw #1
    //     0x8aa21c: ldur            w7, [x16, #0xf]
    //     0x8aa220: add             x7, x7, HEAP, lsl #32
    //     0x8aa224: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a48] "dropdownMenuTheme"
    //     0x8aa228: ldr             x16, [x16, #0xa48]
    //     0x8aa22c: cmp             w7, w16
    //     0x8aa230: b.ne            #0x8aa240
    //     0x8aa234: add             w1, w2, #2
    //     0x8aa238: sbfx            x2, x1, #1, #0x1f
    //     0x8aa23c: mov             x1, x2
    //     0x8aa240: lsl             x2, x1, #1
    //     0x8aa244: lsl             w7, w2, #1
    //     0x8aa248: add             w8, w7, #8
    //     0x8aa24c: add             x16, x4, w8, sxtw #1
    //     0x8aa250: ldur            w7, [x16, #0xf]
    //     0x8aa254: add             x7, x7, HEAP, lsl #32
    //     0x8aa258: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a50] "elevatedButtonTheme"
    //     0x8aa25c: ldr             x16, [x16, #0xa50]
    //     0x8aa260: cmp             w7, w16
    //     0x8aa264: b.ne            #0x8aa274
    //     0x8aa268: add             w1, w2, #2
    //     0x8aa26c: sbfx            x2, x1, #1, #0x1f
    //     0x8aa270: mov             x1, x2
    //     0x8aa274: lsl             x2, x1, #1
    //     0x8aa278: lsl             w7, w2, #1
    //     0x8aa27c: add             w8, w7, #8
    //     0x8aa280: add             x16, x4, w8, sxtw #1
    //     0x8aa284: ldur            w7, [x16, #0xf]
    //     0x8aa288: add             x7, x7, HEAP, lsl #32
    //     0x8aa28c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a58] "expansionTileTheme"
    //     0x8aa290: ldr             x16, [x16, #0xa58]
    //     0x8aa294: cmp             w7, w16
    //     0x8aa298: b.ne            #0x8aa2a8
    //     0x8aa29c: add             w1, w2, #2
    //     0x8aa2a0: sbfx            x2, x1, #1, #0x1f
    //     0x8aa2a4: mov             x1, x2
    //     0x8aa2a8: lsl             x2, x1, #1
    //     0x8aa2ac: lsl             w7, w2, #1
    //     0x8aa2b0: add             w8, w7, #8
    //     0x8aa2b4: add             x16, x4, w8, sxtw #1
    //     0x8aa2b8: ldur            w9, [x16, #0xf]
    //     0x8aa2bc: add             x9, x9, HEAP, lsl #32
    //     0x8aa2c0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a60] "extensions"
    //     0x8aa2c4: ldr             x16, [x16, #0xa60]
    //     0x8aa2c8: cmp             w9, w16
    //     0x8aa2cc: b.ne            #0x8aa300
    //     0x8aa2d0: add             w1, w7, #0xa
    //     0x8aa2d4: add             x16, x4, w1, sxtw #1
    //     0x8aa2d8: ldur            w7, [x16, #0xf]
    //     0x8aa2dc: add             x7, x7, HEAP, lsl #32
    //     0x8aa2e0: sub             w1, w0, w7
    //     0x8aa2e4: add             x7, fp, w1, sxtw #2
    //     0x8aa2e8: ldr             x7, [x7, #8]
    //     0x8aa2ec: add             w1, w2, #2
    //     0x8aa2f0: sbfx            x2, x1, #1, #0x1f
    //     0x8aa2f4: mov             x1, x2
    //     0x8aa2f8: mov             x2, x7
    //     0x8aa2fc: b               #0x8aa304
    //     0x8aa300: mov             x2, NULL
    //     0x8aa304: lsl             x7, x1, #1
    //     0x8aa308: lsl             w8, w7, #1
    //     0x8aa30c: add             w9, w8, #8
    //     0x8aa310: add             x16, x4, w9, sxtw #1
    //     0x8aa314: ldur            w8, [x16, #0xf]
    //     0x8aa318: add             x8, x8, HEAP, lsl #32
    //     0x8aa31c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a68] "filledButtonTheme"
    //     0x8aa320: ldr             x16, [x16, #0xa68]
    //     0x8aa324: cmp             w8, w16
    //     0x8aa328: b.ne            #0x8aa338
    //     0x8aa32c: add             w1, w7, #2
    //     0x8aa330: sbfx            x7, x1, #1, #0x1f
    //     0x8aa334: mov             x1, x7
    //     0x8aa338: lsl             x7, x1, #1
    //     0x8aa33c: lsl             w8, w7, #1
    //     0x8aa340: add             w9, w8, #8
    //     0x8aa344: add             x16, x4, w9, sxtw #1
    //     0x8aa348: ldur            w10, [x16, #0xf]
    //     0x8aa34c: add             x10, x10, HEAP, lsl #32
    //     0x8aa350: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a70] "floatingActionButtonTheme"
    //     0x8aa354: ldr             x16, [x16, #0xa70]
    //     0x8aa358: cmp             w10, w16
    //     0x8aa35c: b.ne            #0x8aa390
    //     0x8aa360: add             w1, w8, #0xa
    //     0x8aa364: add             x16, x4, w1, sxtw #1
    //     0x8aa368: ldur            w8, [x16, #0xf]
    //     0x8aa36c: add             x8, x8, HEAP, lsl #32
    //     0x8aa370: sub             w1, w0, w8
    //     0x8aa374: add             x8, fp, w1, sxtw #2
    //     0x8aa378: ldr             x8, [x8, #8]
    //     0x8aa37c: add             w1, w7, #2
    //     0x8aa380: sbfx            x7, x1, #1, #0x1f
    //     0x8aa384: mov             x1, x7
    //     0x8aa388: mov             x7, x8
    //     0x8aa38c: b               #0x8aa394
    //     0x8aa390: mov             x7, NULL
    //     0x8aa394: stur            x7, [fp, #-0x30]
    //     0x8aa398: lsl             x8, x1, #1
    //     0x8aa39c: lsl             w9, w8, #1
    //     0x8aa3a0: add             w10, w9, #8
    //     0x8aa3a4: add             x16, x4, w10, sxtw #1
    //     0x8aa3a8: ldur            w9, [x16, #0xf]
    //     0x8aa3ac: add             x9, x9, HEAP, lsl #32
    //     0x8aa3b0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a78] "focusColor"
    //     0x8aa3b4: ldr             x16, [x16, #0xa78]
    //     0x8aa3b8: cmp             w9, w16
    //     0x8aa3bc: b.ne            #0x8aa3cc
    //     0x8aa3c0: add             w1, w8, #2
    //     0x8aa3c4: sbfx            x8, x1, #1, #0x1f
    //     0x8aa3c8: mov             x1, x8
    //     0x8aa3cc: lsl             x8, x1, #1
    //     0x8aa3d0: lsl             w9, w8, #1
    //     0x8aa3d4: add             w10, w9, #8
    //     0x8aa3d8: add             x16, x4, w10, sxtw #1
    //     0x8aa3dc: ldur            w9, [x16, #0xf]
    //     0x8aa3e0: add             x9, x9, HEAP, lsl #32
    //     0x8aa3e4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12910] "highlightColor"
    //     0x8aa3e8: ldr             x16, [x16, #0x910]
    //     0x8aa3ec: cmp             w9, w16
    //     0x8aa3f0: b.ne            #0x8aa400
    //     0x8aa3f4: add             w1, w8, #2
    //     0x8aa3f8: sbfx            x8, x1, #1, #0x1f
    //     0x8aa3fc: mov             x1, x8
    //     0x8aa400: lsl             x8, x1, #1
    //     0x8aa404: lsl             w9, w8, #1
    //     0x8aa408: add             w10, w9, #8
    //     0x8aa40c: add             x16, x4, w10, sxtw #1
    //     0x8aa410: ldur            w9, [x16, #0xf]
    //     0x8aa414: add             x9, x9, HEAP, lsl #32
    //     0x8aa418: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a80] "hintColor"
    //     0x8aa41c: ldr             x16, [x16, #0xa80]
    //     0x8aa420: cmp             w9, w16
    //     0x8aa424: b.ne            #0x8aa434
    //     0x8aa428: add             w1, w8, #2
    //     0x8aa42c: sbfx            x8, x1, #1, #0x1f
    //     0x8aa430: mov             x1, x8
    //     0x8aa434: lsl             x8, x1, #1
    //     0x8aa438: lsl             w9, w8, #1
    //     0x8aa43c: add             w10, w9, #8
    //     0x8aa440: add             x16, x4, w10, sxtw #1
    //     0x8aa444: ldur            w9, [x16, #0xf]
    //     0x8aa448: add             x9, x9, HEAP, lsl #32
    //     0x8aa44c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a88] "hoverColor"
    //     0x8aa450: ldr             x16, [x16, #0xa88]
    //     0x8aa454: cmp             w9, w16
    //     0x8aa458: b.ne            #0x8aa468
    //     0x8aa45c: add             w1, w8, #2
    //     0x8aa460: sbfx            x8, x1, #1, #0x1f
    //     0x8aa464: mov             x1, x8
    //     0x8aa468: lsl             x8, x1, #1
    //     0x8aa46c: lsl             w9, w8, #1
    //     0x8aa470: add             w10, w9, #8
    //     0x8aa474: add             x16, x4, w10, sxtw #1
    //     0x8aa478: ldur            w9, [x16, #0xf]
    //     0x8aa47c: add             x9, x9, HEAP, lsl #32
    //     0x8aa480: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a90] "iconButtonTheme"
    //     0x8aa484: ldr             x16, [x16, #0xa90]
    //     0x8aa488: cmp             w9, w16
    //     0x8aa48c: b.ne            #0x8aa49c
    //     0x8aa490: add             w1, w8, #2
    //     0x8aa494: sbfx            x8, x1, #1, #0x1f
    //     0x8aa498: mov             x1, x8
    //     0x8aa49c: lsl             x8, x1, #1
    //     0x8aa4a0: lsl             w9, w8, #1
    //     0x8aa4a4: add             w10, w9, #8
    //     0x8aa4a8: add             x16, x4, w10, sxtw #1
    //     0x8aa4ac: ldur            w9, [x16, #0xf]
    //     0x8aa4b0: add             x9, x9, HEAP, lsl #32
    //     0x8aa4b4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12918] "iconTheme"
    //     0x8aa4b8: ldr             x16, [x16, #0x918]
    //     0x8aa4bc: cmp             w9, w16
    //     0x8aa4c0: b.ne            #0x8aa4d0
    //     0x8aa4c4: add             w1, w8, #2
    //     0x8aa4c8: sbfx            x8, x1, #1, #0x1f
    //     0x8aa4cc: mov             x1, x8
    //     0x8aa4d0: lsl             x8, x1, #1
    //     0x8aa4d4: lsl             w9, w8, #1
    //     0x8aa4d8: add             w10, w9, #8
    //     0x8aa4dc: add             x16, x4, w10, sxtw #1
    //     0x8aa4e0: ldur            w9, [x16, #0xf]
    //     0x8aa4e4: add             x9, x9, HEAP, lsl #32
    //     0x8aa4e8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a98] "indicatorColor"
    //     0x8aa4ec: ldr             x16, [x16, #0xa98]
    //     0x8aa4f0: cmp             w9, w16
    //     0x8aa4f4: b.ne            #0x8aa504
    //     0x8aa4f8: add             w1, w8, #2
    //     0x8aa4fc: sbfx            x8, x1, #1, #0x1f
    //     0x8aa500: mov             x1, x8
    //     0x8aa504: lsl             x8, x1, #1
    //     0x8aa508: lsl             w9, w8, #1
    //     0x8aa50c: add             w10, w9, #8
    //     0x8aa510: add             x16, x4, w10, sxtw #1
    //     0x8aa514: ldur            w11, [x16, #0xf]
    //     0x8aa518: add             x11, x11, HEAP, lsl #32
    //     0x8aa51c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12aa0] "inputDecorationTheme"
    //     0x8aa520: ldr             x16, [x16, #0xaa0]
    //     0x8aa524: cmp             w11, w16
    //     0x8aa528: b.ne            #0x8aa55c
    //     0x8aa52c: add             w1, w9, #0xa
    //     0x8aa530: add             x16, x4, w1, sxtw #1
    //     0x8aa534: ldur            w9, [x16, #0xf]
    //     0x8aa538: add             x9, x9, HEAP, lsl #32
    //     0x8aa53c: sub             w1, w0, w9
    //     0x8aa540: add             x9, fp, w1, sxtw #2
    //     0x8aa544: ldr             x9, [x9, #8]
    //     0x8aa548: add             w1, w8, #2
    //     0x8aa54c: sbfx            x8, x1, #1, #0x1f
    //     0x8aa550: mov             x1, x8
    //     0x8aa554: mov             x8, x9
    //     0x8aa558: b               #0x8aa560
    //     0x8aa55c: mov             x8, NULL
    //     0x8aa560: stur            x8, [fp, #-0x28]
    //     0x8aa564: lsl             x9, x1, #1
    //     0x8aa568: lsl             w10, w9, #1
    //     0x8aa56c: add             w11, w10, #8
    //     0x8aa570: add             x16, x4, w11, sxtw #1
    //     0x8aa574: ldur            w10, [x16, #0xf]
    //     0x8aa578: add             x10, x10, HEAP, lsl #32
    //     0x8aa57c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12aa8] "listTileTheme"
    //     0x8aa580: ldr             x16, [x16, #0xaa8]
    //     0x8aa584: cmp             w10, w16
    //     0x8aa588: b.ne            #0x8aa598
    //     0x8aa58c: add             w1, w9, #2
    //     0x8aa590: sbfx            x9, x1, #1, #0x1f
    //     0x8aa594: mov             x1, x9
    //     0x8aa598: lsl             x9, x1, #1
    //     0x8aa59c: lsl             w10, w9, #1
    //     0x8aa5a0: add             w11, w10, #8
    //     0x8aa5a4: add             x16, x4, w11, sxtw #1
    //     0x8aa5a8: ldur            w10, [x16, #0xf]
    //     0x8aa5ac: add             x10, x10, HEAP, lsl #32
    //     0x8aa5b0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ab0] "materialTapTargetSize"
    //     0x8aa5b4: ldr             x16, [x16, #0xab0]
    //     0x8aa5b8: cmp             w10, w16
    //     0x8aa5bc: b.ne            #0x8aa5cc
    //     0x8aa5c0: add             w1, w9, #2
    //     0x8aa5c4: sbfx            x9, x1, #1, #0x1f
    //     0x8aa5c8: mov             x1, x9
    //     0x8aa5cc: lsl             x9, x1, #1
    //     0x8aa5d0: lsl             w10, w9, #1
    //     0x8aa5d4: add             w11, w10, #8
    //     0x8aa5d8: add             x16, x4, w11, sxtw #1
    //     0x8aa5dc: ldur            w10, [x16, #0xf]
    //     0x8aa5e0: add             x10, x10, HEAP, lsl #32
    //     0x8aa5e4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ab8] "menuBarTheme"
    //     0x8aa5e8: ldr             x16, [x16, #0xab8]
    //     0x8aa5ec: cmp             w10, w16
    //     0x8aa5f0: b.ne            #0x8aa600
    //     0x8aa5f4: add             w1, w9, #2
    //     0x8aa5f8: sbfx            x9, x1, #1, #0x1f
    //     0x8aa5fc: mov             x1, x9
    //     0x8aa600: lsl             x9, x1, #1
    //     0x8aa604: lsl             w10, w9, #1
    //     0x8aa608: add             w11, w10, #8
    //     0x8aa60c: add             x16, x4, w11, sxtw #1
    //     0x8aa610: ldur            w10, [x16, #0xf]
    //     0x8aa614: add             x10, x10, HEAP, lsl #32
    //     0x8aa618: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ac0] "menuButtonTheme"
    //     0x8aa61c: ldr             x16, [x16, #0xac0]
    //     0x8aa620: cmp             w10, w16
    //     0x8aa624: b.ne            #0x8aa634
    //     0x8aa628: add             w1, w9, #2
    //     0x8aa62c: sbfx            x9, x1, #1, #0x1f
    //     0x8aa630: mov             x1, x9
    //     0x8aa634: lsl             x9, x1, #1
    //     0x8aa638: lsl             w10, w9, #1
    //     0x8aa63c: add             w11, w10, #8
    //     0x8aa640: add             x16, x4, w11, sxtw #1
    //     0x8aa644: ldur            w10, [x16, #0xf]
    //     0x8aa648: add             x10, x10, HEAP, lsl #32
    //     0x8aa64c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ac8] "menuTheme"
    //     0x8aa650: ldr             x16, [x16, #0xac8]
    //     0x8aa654: cmp             w10, w16
    //     0x8aa658: b.ne            #0x8aa668
    //     0x8aa65c: add             w1, w9, #2
    //     0x8aa660: sbfx            x9, x1, #1, #0x1f
    //     0x8aa664: mov             x1, x9
    //     0x8aa668: lsl             x9, x1, #1
    //     0x8aa66c: lsl             w10, w9, #1
    //     0x8aa670: add             w11, w10, #8
    //     0x8aa674: add             x16, x4, w11, sxtw #1
    //     0x8aa678: ldur            w10, [x16, #0xf]
    //     0x8aa67c: add             x10, x10, HEAP, lsl #32
    //     0x8aa680: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ad0] "navigationBarTheme"
    //     0x8aa684: ldr             x16, [x16, #0xad0]
    //     0x8aa688: cmp             w10, w16
    //     0x8aa68c: b.ne            #0x8aa69c
    //     0x8aa690: add             w1, w9, #2
    //     0x8aa694: sbfx            x9, x1, #1, #0x1f
    //     0x8aa698: mov             x1, x9
    //     0x8aa69c: lsl             x9, x1, #1
    //     0x8aa6a0: lsl             w10, w9, #1
    //     0x8aa6a4: add             w11, w10, #8
    //     0x8aa6a8: add             x16, x4, w11, sxtw #1
    //     0x8aa6ac: ldur            w10, [x16, #0xf]
    //     0x8aa6b0: add             x10, x10, HEAP, lsl #32
    //     0x8aa6b4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ad8] "navigationDrawerTheme"
    //     0x8aa6b8: ldr             x16, [x16, #0xad8]
    //     0x8aa6bc: cmp             w10, w16
    //     0x8aa6c0: b.ne            #0x8aa6d0
    //     0x8aa6c4: add             w1, w9, #2
    //     0x8aa6c8: sbfx            x9, x1, #1, #0x1f
    //     0x8aa6cc: mov             x1, x9
    //     0x8aa6d0: lsl             x9, x1, #1
    //     0x8aa6d4: lsl             w10, w9, #1
    //     0x8aa6d8: add             w11, w10, #8
    //     0x8aa6dc: add             x16, x4, w11, sxtw #1
    //     0x8aa6e0: ldur            w10, [x16, #0xf]
    //     0x8aa6e4: add             x10, x10, HEAP, lsl #32
    //     0x8aa6e8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ae0] "navigationRailTheme"
    //     0x8aa6ec: ldr             x16, [x16, #0xae0]
    //     0x8aa6f0: cmp             w10, w16
    //     0x8aa6f4: b.ne            #0x8aa704
    //     0x8aa6f8: add             w1, w9, #2
    //     0x8aa6fc: sbfx            x9, x1, #1, #0x1f
    //     0x8aa700: mov             x1, x9
    //     0x8aa704: lsl             x9, x1, #1
    //     0x8aa708: lsl             w10, w9, #1
    //     0x8aa70c: add             w11, w10, #8
    //     0x8aa710: add             x16, x4, w11, sxtw #1
    //     0x8aa714: ldur            w10, [x16, #0xf]
    //     0x8aa718: add             x10, x10, HEAP, lsl #32
    //     0x8aa71c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ae8] "outlinedButtonTheme"
    //     0x8aa720: ldr             x16, [x16, #0xae8]
    //     0x8aa724: cmp             w10, w16
    //     0x8aa728: b.ne            #0x8aa738
    //     0x8aa72c: add             w1, w9, #2
    //     0x8aa730: sbfx            x9, x1, #1, #0x1f
    //     0x8aa734: mov             x1, x9
    //     0x8aa738: lsl             x9, x1, #1
    //     0x8aa73c: lsl             w10, w9, #1
    //     0x8aa740: add             w11, w10, #8
    //     0x8aa744: add             x16, x4, w11, sxtw #1
    //     0x8aa748: ldur            w10, [x16, #0xf]
    //     0x8aa74c: add             x10, x10, HEAP, lsl #32
    //     0x8aa750: add             x16, PP, #0x12, lsl #12  ; [pp+0x12af0] "pageTransitionsTheme"
    //     0x8aa754: ldr             x16, [x16, #0xaf0]
    //     0x8aa758: cmp             w10, w16
    //     0x8aa75c: b.ne            #0x8aa76c
    //     0x8aa760: add             w1, w9, #2
    //     0x8aa764: sbfx            x9, x1, #1, #0x1f
    //     0x8aa768: mov             x1, x9
    //     0x8aa76c: lsl             x9, x1, #1
    //     0x8aa770: lsl             w10, w9, #1
    //     0x8aa774: add             w11, w10, #8
    //     0x8aa778: add             x16, x4, w11, sxtw #1
    //     0x8aa77c: ldur            w10, [x16, #0xf]
    //     0x8aa780: add             x10, x10, HEAP, lsl #32
    //     0x8aa784: add             x16, PP, #0x12, lsl #12  ; [pp+0x12af8] "platform"
    //     0x8aa788: ldr             x16, [x16, #0xaf8]
    //     0x8aa78c: cmp             w10, w16
    //     0x8aa790: b.ne            #0x8aa7a0
    //     0x8aa794: add             w1, w9, #2
    //     0x8aa798: sbfx            x9, x1, #1, #0x1f
    //     0x8aa79c: mov             x1, x9
    //     0x8aa7a0: lsl             x9, x1, #1
    //     0x8aa7a4: lsl             w10, w9, #1
    //     0x8aa7a8: add             w11, w10, #8
    //     0x8aa7ac: add             x16, x4, w11, sxtw #1
    //     0x8aa7b0: ldur            w10, [x16, #0xf]
    //     0x8aa7b4: add             x10, x10, HEAP, lsl #32
    //     0x8aa7b8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b00] "popupMenuTheme"
    //     0x8aa7bc: ldr             x16, [x16, #0xb00]
    //     0x8aa7c0: cmp             w10, w16
    //     0x8aa7c4: b.ne            #0x8aa7d4
    //     0x8aa7c8: add             w1, w9, #2
    //     0x8aa7cc: sbfx            x9, x1, #1, #0x1f
    //     0x8aa7d0: mov             x1, x9
    //     0x8aa7d4: lsl             x9, x1, #1
    //     0x8aa7d8: lsl             w10, w9, #1
    //     0x8aa7dc: add             w11, w10, #8
    //     0x8aa7e0: add             x16, x4, w11, sxtw #1
    //     0x8aa7e4: ldur            w12, [x16, #0xf]
    //     0x8aa7e8: add             x12, x12, HEAP, lsl #32
    //     0x8aa7ec: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b08] "primaryColor"
    //     0x8aa7f0: ldr             x16, [x16, #0xb08]
    //     0x8aa7f4: cmp             w12, w16
    //     0x8aa7f8: b.ne            #0x8aa82c
    //     0x8aa7fc: add             w1, w10, #0xa
    //     0x8aa800: add             x16, x4, w1, sxtw #1
    //     0x8aa804: ldur            w10, [x16, #0xf]
    //     0x8aa808: add             x10, x10, HEAP, lsl #32
    //     0x8aa80c: sub             w1, w0, w10
    //     0x8aa810: add             x10, fp, w1, sxtw #2
    //     0x8aa814: ldr             x10, [x10, #8]
    //     0x8aa818: add             w1, w9, #2
    //     0x8aa81c: sbfx            x9, x1, #1, #0x1f
    //     0x8aa820: mov             x1, x9
    //     0x8aa824: mov             x9, x10
    //     0x8aa828: b               #0x8aa830
    //     0x8aa82c: mov             x9, NULL
    //     0x8aa830: stur            x9, [fp, #-0x20]
    //     0x8aa834: lsl             x10, x1, #1
    //     0x8aa838: lsl             w11, w10, #1
    //     0x8aa83c: add             w12, w11, #8
    //     0x8aa840: add             x16, x4, w12, sxtw #1
    //     0x8aa844: ldur            w11, [x16, #0xf]
    //     0x8aa848: add             x11, x11, HEAP, lsl #32
    //     0x8aa84c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b10] "primaryColorDark"
    //     0x8aa850: ldr             x16, [x16, #0xb10]
    //     0x8aa854: cmp             w11, w16
    //     0x8aa858: b.ne            #0x8aa868
    //     0x8aa85c: add             w1, w10, #2
    //     0x8aa860: sbfx            x10, x1, #1, #0x1f
    //     0x8aa864: mov             x1, x10
    //     0x8aa868: lsl             x10, x1, #1
    //     0x8aa86c: lsl             w11, w10, #1
    //     0x8aa870: add             w12, w11, #8
    //     0x8aa874: add             x16, x4, w12, sxtw #1
    //     0x8aa878: ldur            w11, [x16, #0xf]
    //     0x8aa87c: add             x11, x11, HEAP, lsl #32
    //     0x8aa880: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b18] "primaryColorLight"
    //     0x8aa884: ldr             x16, [x16, #0xb18]
    //     0x8aa888: cmp             w11, w16
    //     0x8aa88c: b.ne            #0x8aa89c
    //     0x8aa890: add             w1, w10, #2
    //     0x8aa894: sbfx            x10, x1, #1, #0x1f
    //     0x8aa898: mov             x1, x10
    //     0x8aa89c: lsl             x10, x1, #1
    //     0x8aa8a0: lsl             w11, w10, #1
    //     0x8aa8a4: add             w12, w11, #8
    //     0x8aa8a8: add             x16, x4, w12, sxtw #1
    //     0x8aa8ac: ldur            w11, [x16, #0xf]
    //     0x8aa8b0: add             x11, x11, HEAP, lsl #32
    //     0x8aa8b4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b20] "primaryIconTheme"
    //     0x8aa8b8: ldr             x16, [x16, #0xb20]
    //     0x8aa8bc: cmp             w11, w16
    //     0x8aa8c0: b.ne            #0x8aa8d0
    //     0x8aa8c4: add             w1, w10, #2
    //     0x8aa8c8: sbfx            x10, x1, #1, #0x1f
    //     0x8aa8cc: mov             x1, x10
    //     0x8aa8d0: lsl             x10, x1, #1
    //     0x8aa8d4: lsl             w11, w10, #1
    //     0x8aa8d8: add             w12, w11, #8
    //     0x8aa8dc: add             x16, x4, w12, sxtw #1
    //     0x8aa8e0: ldur            w11, [x16, #0xf]
    //     0x8aa8e4: add             x11, x11, HEAP, lsl #32
    //     0x8aa8e8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b28] "primarySwatch"
    //     0x8aa8ec: ldr             x16, [x16, #0xb28]
    //     0x8aa8f0: cmp             w11, w16
    //     0x8aa8f4: b.ne            #0x8aa904
    //     0x8aa8f8: add             w1, w10, #2
    //     0x8aa8fc: sbfx            x10, x1, #1, #0x1f
    //     0x8aa900: mov             x1, x10
    //     0x8aa904: lsl             x10, x1, #1
    //     0x8aa908: lsl             w11, w10, #1
    //     0x8aa90c: add             w12, w11, #8
    //     0x8aa910: add             x16, x4, w12, sxtw #1
    //     0x8aa914: ldur            w11, [x16, #0xf]
    //     0x8aa918: add             x11, x11, HEAP, lsl #32
    //     0x8aa91c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12920] "primaryTextTheme"
    //     0x8aa920: ldr             x16, [x16, #0x920]
    //     0x8aa924: cmp             w11, w16
    //     0x8aa928: b.ne            #0x8aa938
    //     0x8aa92c: add             w1, w10, #2
    //     0x8aa930: sbfx            x10, x1, #1, #0x1f
    //     0x8aa934: mov             x1, x10
    //     0x8aa938: lsl             x10, x1, #1
    //     0x8aa93c: lsl             w11, w10, #1
    //     0x8aa940: add             w12, w11, #8
    //     0x8aa944: add             x16, x4, w12, sxtw #1
    //     0x8aa948: ldur            w11, [x16, #0xf]
    //     0x8aa94c: add             x11, x11, HEAP, lsl #32
    //     0x8aa950: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b30] "progressIndicatorTheme"
    //     0x8aa954: ldr             x16, [x16, #0xb30]
    //     0x8aa958: cmp             w11, w16
    //     0x8aa95c: b.ne            #0x8aa96c
    //     0x8aa960: add             w1, w10, #2
    //     0x8aa964: sbfx            x10, x1, #1, #0x1f
    //     0x8aa968: mov             x1, x10
    //     0x8aa96c: lsl             x10, x1, #1
    //     0x8aa970: lsl             w11, w10, #1
    //     0x8aa974: add             w12, w11, #8
    //     0x8aa978: add             x16, x4, w12, sxtw #1
    //     0x8aa97c: ldur            w11, [x16, #0xf]
    //     0x8aa980: add             x11, x11, HEAP, lsl #32
    //     0x8aa984: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b38] "radioTheme"
    //     0x8aa988: ldr             x16, [x16, #0xb38]
    //     0x8aa98c: cmp             w11, w16
    //     0x8aa990: b.ne            #0x8aa9a0
    //     0x8aa994: add             w1, w10, #2
    //     0x8aa998: sbfx            x10, x1, #1, #0x1f
    //     0x8aa99c: mov             x1, x10
    //     0x8aa9a0: lsl             x10, x1, #1
    //     0x8aa9a4: lsl             w11, w10, #1
    //     0x8aa9a8: add             w12, w11, #8
    //     0x8aa9ac: add             x16, x4, w12, sxtw #1
    //     0x8aa9b0: ldur            w13, [x16, #0xf]
    //     0x8aa9b4: add             x13, x13, HEAP, lsl #32
    //     0x8aa9b8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b40] "scaffoldBackgroundColor"
    //     0x8aa9bc: ldr             x16, [x16, #0xb40]
    //     0x8aa9c0: cmp             w13, w16
    //     0x8aa9c4: b.ne            #0x8aa9f8
    //     0x8aa9c8: add             w1, w11, #0xa
    //     0x8aa9cc: add             x16, x4, w1, sxtw #1
    //     0x8aa9d0: ldur            w11, [x16, #0xf]
    //     0x8aa9d4: add             x11, x11, HEAP, lsl #32
    //     0x8aa9d8: sub             w1, w0, w11
    //     0x8aa9dc: add             x11, fp, w1, sxtw #2
    //     0x8aa9e0: ldr             x11, [x11, #8]
    //     0x8aa9e4: add             w1, w10, #2
    //     0x8aa9e8: sbfx            x10, x1, #1, #0x1f
    //     0x8aa9ec: mov             x1, x10
    //     0x8aa9f0: mov             x10, x11
    //     0x8aa9f4: b               #0x8aa9fc
    //     0x8aa9f8: mov             x10, NULL
    //     0x8aa9fc: stur            x10, [fp, #-0x18]
    //     0x8aaa00: lsl             x11, x1, #1
    //     0x8aaa04: lsl             w12, w11, #1
    //     0x8aaa08: add             w13, w12, #8
    //     0x8aaa0c: add             x16, x4, w13, sxtw #1
    //     0x8aaa10: ldur            w12, [x16, #0xf]
    //     0x8aaa14: add             x12, x12, HEAP, lsl #32
    //     0x8aaa18: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b48] "scrollbarTheme"
    //     0x8aaa1c: ldr             x16, [x16, #0xb48]
    //     0x8aaa20: cmp             w12, w16
    //     0x8aaa24: b.ne            #0x8aaa34
    //     0x8aaa28: add             w1, w11, #2
    //     0x8aaa2c: sbfx            x11, x1, #1, #0x1f
    //     0x8aaa30: mov             x1, x11
    //     0x8aaa34: lsl             x11, x1, #1
    //     0x8aaa38: lsl             w12, w11, #1
    //     0x8aaa3c: add             w13, w12, #8
    //     0x8aaa40: add             x16, x4, w13, sxtw #1
    //     0x8aaa44: ldur            w12, [x16, #0xf]
    //     0x8aaa48: add             x12, x12, HEAP, lsl #32
    //     0x8aaa4c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b50] "searchBarTheme"
    //     0x8aaa50: ldr             x16, [x16, #0xb50]
    //     0x8aaa54: cmp             w12, w16
    //     0x8aaa58: b.ne            #0x8aaa68
    //     0x8aaa5c: add             w1, w11, #2
    //     0x8aaa60: sbfx            x11, x1, #1, #0x1f
    //     0x8aaa64: mov             x1, x11
    //     0x8aaa68: lsl             x11, x1, #1
    //     0x8aaa6c: lsl             w12, w11, #1
    //     0x8aaa70: add             w13, w12, #8
    //     0x8aaa74: add             x16, x4, w13, sxtw #1
    //     0x8aaa78: ldur            w12, [x16, #0xf]
    //     0x8aaa7c: add             x12, x12, HEAP, lsl #32
    //     0x8aaa80: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b58] "searchViewTheme"
    //     0x8aaa84: ldr             x16, [x16, #0xb58]
    //     0x8aaa88: cmp             w12, w16
    //     0x8aaa8c: b.ne            #0x8aaa9c
    //     0x8aaa90: add             w1, w11, #2
    //     0x8aaa94: sbfx            x11, x1, #1, #0x1f
    //     0x8aaa98: mov             x1, x11
    //     0x8aaa9c: lsl             x11, x1, #1
    //     0x8aaaa0: lsl             w12, w11, #1
    //     0x8aaaa4: add             w13, w12, #8
    //     0x8aaaa8: add             x16, x4, w13, sxtw #1
    //     0x8aaaac: ldur            w12, [x16, #0xf]
    //     0x8aaab0: add             x12, x12, HEAP, lsl #32
    //     0x8aaab4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b60] "secondaryHeaderColor"
    //     0x8aaab8: ldr             x16, [x16, #0xb60]
    //     0x8aaabc: cmp             w12, w16
    //     0x8aaac0: b.ne            #0x8aaad0
    //     0x8aaac4: add             w1, w11, #2
    //     0x8aaac8: sbfx            x11, x1, #1, #0x1f
    //     0x8aaacc: mov             x1, x11
    //     0x8aaad0: lsl             x11, x1, #1
    //     0x8aaad4: lsl             w12, w11, #1
    //     0x8aaad8: add             w13, w12, #8
    //     0x8aaadc: add             x16, x4, w13, sxtw #1
    //     0x8aaae0: ldur            w12, [x16, #0xf]
    //     0x8aaae4: add             x12, x12, HEAP, lsl #32
    //     0x8aaae8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b68] "segmentedButtonTheme"
    //     0x8aaaec: ldr             x16, [x16, #0xb68]
    //     0x8aaaf0: cmp             w12, w16
    //     0x8aaaf4: b.ne            #0x8aab04
    //     0x8aaaf8: add             w1, w11, #2
    //     0x8aaafc: sbfx            x11, x1, #1, #0x1f
    //     0x8aab00: mov             x1, x11
    //     0x8aab04: lsl             x11, x1, #1
    //     0x8aab08: lsl             w12, w11, #1
    //     0x8aab0c: add             w13, w12, #8
    //     0x8aab10: add             x16, x4, w13, sxtw #1
    //     0x8aab14: ldur            w12, [x16, #0xf]
    //     0x8aab18: add             x12, x12, HEAP, lsl #32
    //     0x8aab1c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b70] "shadowColor"
    //     0x8aab20: ldr             x16, [x16, #0xb70]
    //     0x8aab24: cmp             w12, w16
    //     0x8aab28: b.ne            #0x8aab38
    //     0x8aab2c: add             w1, w11, #2
    //     0x8aab30: sbfx            x11, x1, #1, #0x1f
    //     0x8aab34: mov             x1, x11
    //     0x8aab38: lsl             x11, x1, #1
    //     0x8aab3c: lsl             w12, w11, #1
    //     0x8aab40: add             w13, w12, #8
    //     0x8aab44: add             x16, x4, w13, sxtw #1
    //     0x8aab48: ldur            w12, [x16, #0xf]
    //     0x8aab4c: add             x12, x12, HEAP, lsl #32
    //     0x8aab50: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b78] "sliderTheme"
    //     0x8aab54: ldr             x16, [x16, #0xb78]
    //     0x8aab58: cmp             w12, w16
    //     0x8aab5c: b.ne            #0x8aab6c
    //     0x8aab60: add             w1, w11, #2
    //     0x8aab64: sbfx            x11, x1, #1, #0x1f
    //     0x8aab68: mov             x1, x11
    //     0x8aab6c: lsl             x11, x1, #1
    //     0x8aab70: lsl             w12, w11, #1
    //     0x8aab74: add             w13, w12, #8
    //     0x8aab78: add             x16, x4, w13, sxtw #1
    //     0x8aab7c: ldur            w12, [x16, #0xf]
    //     0x8aab80: add             x12, x12, HEAP, lsl #32
    //     0x8aab84: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b80] "snackBarTheme"
    //     0x8aab88: ldr             x16, [x16, #0xb80]
    //     0x8aab8c: cmp             w12, w16
    //     0x8aab90: b.ne            #0x8aaba0
    //     0x8aab94: add             w1, w11, #2
    //     0x8aab98: sbfx            x11, x1, #1, #0x1f
    //     0x8aab9c: mov             x1, x11
    //     0x8aaba0: lsl             x11, x1, #1
    //     0x8aaba4: lsl             w12, w11, #1
    //     0x8aaba8: add             w13, w12, #8
    //     0x8aabac: add             x16, x4, w13, sxtw #1
    //     0x8aabb0: ldur            w12, [x16, #0xf]
    //     0x8aabb4: add             x12, x12, HEAP, lsl #32
    //     0x8aabb8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12928] "splashColor"
    //     0x8aabbc: ldr             x16, [x16, #0x928]
    //     0x8aabc0: cmp             w12, w16
    //     0x8aabc4: b.ne            #0x8aabd4
    //     0x8aabc8: add             w1, w11, #2
    //     0x8aabcc: sbfx            x11, x1, #1, #0x1f
    //     0x8aabd0: mov             x1, x11
    //     0x8aabd4: lsl             x11, x1, #1
    //     0x8aabd8: lsl             w12, w11, #1
    //     0x8aabdc: add             w13, w12, #8
    //     0x8aabe0: add             x16, x4, w13, sxtw #1
    //     0x8aabe4: ldur            w12, [x16, #0xf]
    //     0x8aabe8: add             x12, x12, HEAP, lsl #32
    //     0x8aabec: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b88] "splashFactory"
    //     0x8aabf0: ldr             x16, [x16, #0xb88]
    //     0x8aabf4: cmp             w12, w16
    //     0x8aabf8: b.ne            #0x8aac08
    //     0x8aabfc: add             w1, w11, #2
    //     0x8aac00: sbfx            x11, x1, #1, #0x1f
    //     0x8aac04: mov             x1, x11
    //     0x8aac08: lsl             x11, x1, #1
    //     0x8aac0c: lsl             w12, w11, #1
    //     0x8aac10: add             w13, w12, #8
    //     0x8aac14: add             x16, x4, w13, sxtw #1
    //     0x8aac18: ldur            w12, [x16, #0xf]
    //     0x8aac1c: add             x12, x12, HEAP, lsl #32
    //     0x8aac20: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b90] "switchTheme"
    //     0x8aac24: ldr             x16, [x16, #0xb90]
    //     0x8aac28: cmp             w12, w16
    //     0x8aac2c: b.ne            #0x8aac3c
    //     0x8aac30: add             w1, w11, #2
    //     0x8aac34: sbfx            x11, x1, #1, #0x1f
    //     0x8aac38: mov             x1, x11
    //     0x8aac3c: lsl             x11, x1, #1
    //     0x8aac40: lsl             w12, w11, #1
    //     0x8aac44: add             w13, w12, #8
    //     0x8aac48: add             x16, x4, w13, sxtw #1
    //     0x8aac4c: ldur            w14, [x16, #0xf]
    //     0x8aac50: add             x14, x14, HEAP, lsl #32
    //     0x8aac54: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b98] "tabBarTheme"
    //     0x8aac58: ldr             x16, [x16, #0xb98]
    //     0x8aac5c: cmp             w14, w16
    //     0x8aac60: b.ne            #0x8aac94
    //     0x8aac64: add             w1, w12, #0xa
    //     0x8aac68: add             x16, x4, w1, sxtw #1
    //     0x8aac6c: ldur            w12, [x16, #0xf]
    //     0x8aac70: add             x12, x12, HEAP, lsl #32
    //     0x8aac74: sub             w1, w0, w12
    //     0x8aac78: add             x12, fp, w1, sxtw #2
    //     0x8aac7c: ldr             x12, [x12, #8]
    //     0x8aac80: add             w1, w11, #2
    //     0x8aac84: sbfx            x11, x1, #1, #0x1f
    //     0x8aac88: mov             x1, x11
    //     0x8aac8c: mov             x11, x12
    //     0x8aac90: b               #0x8aac98
    //     0x8aac94: mov             x11, NULL
    //     0x8aac98: stur            x11, [fp, #-0x10]
    //     0x8aac9c: lsl             x12, x1, #1
    //     0x8aaca0: lsl             w13, w12, #1
    //     0x8aaca4: add             w14, w13, #8
    //     0x8aaca8: add             x16, x4, w14, sxtw #1
    //     0x8aacac: ldur            w13, [x16, #0xf]
    //     0x8aacb0: add             x13, x13, HEAP, lsl #32
    //     0x8aacb4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ba0] "textButtonTheme"
    //     0x8aacb8: ldr             x16, [x16, #0xba0]
    //     0x8aacbc: cmp             w13, w16
    //     0x8aacc0: b.ne            #0x8aacd0
    //     0x8aacc4: add             w1, w12, #2
    //     0x8aacc8: sbfx            x12, x1, #1, #0x1f
    //     0x8aaccc: mov             x1, x12
    //     0x8aacd0: lsl             x12, x1, #1
    //     0x8aacd4: lsl             w13, w12, #1
    //     0x8aacd8: add             w14, w13, #8
    //     0x8aacdc: add             x16, x4, w14, sxtw #1
    //     0x8aace0: ldur            w13, [x16, #0xf]
    //     0x8aace4: add             x13, x13, HEAP, lsl #32
    //     0x8aace8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ba8] "textSelectionTheme"
    //     0x8aacec: ldr             x16, [x16, #0xba8]
    //     0x8aacf0: cmp             w13, w16
    //     0x8aacf4: b.ne            #0x8aad04
    //     0x8aacf8: add             w1, w12, #2
    //     0x8aacfc: sbfx            x12, x1, #1, #0x1f
    //     0x8aad00: mov             x1, x12
    //     0x8aad04: lsl             x12, x1, #1
    //     0x8aad08: lsl             w13, w12, #1
    //     0x8aad0c: add             w14, w13, #8
    //     0x8aad10: add             x16, x4, w14, sxtw #1
    //     0x8aad14: ldur            w13, [x16, #0xf]
    //     0x8aad18: add             x13, x13, HEAP, lsl #32
    //     0x8aad1c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12930] "textTheme"
    //     0x8aad20: ldr             x16, [x16, #0x930]
    //     0x8aad24: cmp             w13, w16
    //     0x8aad28: b.ne            #0x8aad38
    //     0x8aad2c: add             w1, w12, #2
    //     0x8aad30: sbfx            x12, x1, #1, #0x1f
    //     0x8aad34: mov             x1, x12
    //     0x8aad38: lsl             x12, x1, #1
    //     0x8aad3c: lsl             w13, w12, #1
    //     0x8aad40: add             w14, w13, #8
    //     0x8aad44: add             x16, x4, w14, sxtw #1
    //     0x8aad48: ldur            w13, [x16, #0xf]
    //     0x8aad4c: add             x13, x13, HEAP, lsl #32
    //     0x8aad50: add             x16, PP, #0x12, lsl #12  ; [pp+0x12bb0] "timePickerTheme"
    //     0x8aad54: ldr             x16, [x16, #0xbb0]
    //     0x8aad58: cmp             w13, w16
    //     0x8aad5c: b.ne            #0x8aad6c
    //     0x8aad60: add             w1, w12, #2
    //     0x8aad64: sbfx            x12, x1, #1, #0x1f
    //     0x8aad68: mov             x1, x12
    //     0x8aad6c: lsl             x12, x1, #1
    //     0x8aad70: lsl             w13, w12, #1
    //     0x8aad74: add             w14, w13, #8
    //     0x8aad78: add             x16, x4, w14, sxtw #1
    //     0x8aad7c: ldur            w13, [x16, #0xf]
    //     0x8aad80: add             x13, x13, HEAP, lsl #32
    //     0x8aad84: add             x16, PP, #0x12, lsl #12  ; [pp+0x12bb8] "toggleButtonsTheme"
    //     0x8aad88: ldr             x16, [x16, #0xbb8]
    //     0x8aad8c: cmp             w13, w16
    //     0x8aad90: b.ne            #0x8aada0
    //     0x8aad94: add             w1, w12, #2
    //     0x8aad98: sbfx            x12, x1, #1, #0x1f
    //     0x8aad9c: mov             x1, x12
    //     0x8aada0: lsl             x12, x1, #1
    //     0x8aada4: lsl             w13, w12, #1
    //     0x8aada8: add             w14, w13, #8
    //     0x8aadac: add             x16, x4, w14, sxtw #1
    //     0x8aadb0: ldur            w13, [x16, #0xf]
    //     0x8aadb4: add             x13, x13, HEAP, lsl #32
    //     0x8aadb8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12bc0] "tooltipTheme"
    //     0x8aadbc: ldr             x16, [x16, #0xbc0]
    //     0x8aadc0: cmp             w13, w16
    //     0x8aadc4: b.ne            #0x8aadd4
    //     0x8aadc8: add             w1, w12, #2
    //     0x8aadcc: sbfx            x12, x1, #1, #0x1f
    //     0x8aadd0: mov             x1, x12
    //     0x8aadd4: lsl             x12, x1, #1
    //     0x8aadd8: lsl             w13, w12, #1
    //     0x8aaddc: add             w14, w13, #8
    //     0x8aade0: add             x16, x4, w14, sxtw #1
    //     0x8aade4: ldur            w13, [x16, #0xf]
    //     0x8aade8: add             x13, x13, HEAP, lsl #32
    //     0x8aadec: add             x16, PP, #0x12, lsl #12  ; [pp+0x12bc8] "typography"
    //     0x8aadf0: ldr             x16, [x16, #0xbc8]
    //     0x8aadf4: cmp             w13, w16
    //     0x8aadf8: b.ne            #0x8aae08
    //     0x8aadfc: add             w1, w12, #2
    //     0x8aae00: sbfx            x12, x1, #1, #0x1f
    //     0x8aae04: mov             x1, x12
    //     0x8aae08: lsl             x12, x1, #1
    //     0x8aae0c: lsl             w13, w12, #1
    //     0x8aae10: add             w14, w13, #8
    //     0x8aae14: add             x16, x4, w14, sxtw #1
    //     0x8aae18: ldur            w13, [x16, #0xf]
    //     0x8aae1c: add             x13, x13, HEAP, lsl #32
    //     0x8aae20: add             x16, PP, #0x12, lsl #12  ; [pp+0x12bd0] "unselectedWidgetColor"
    //     0x8aae24: ldr             x16, [x16, #0xbd0]
    //     0x8aae28: cmp             w13, w16
    //     0x8aae2c: b.ne            #0x8aae3c
    //     0x8aae30: add             w1, w12, #2
    //     0x8aae34: sbfx            x12, x1, #1, #0x1f
    //     0x8aae38: mov             x1, x12
    //     0x8aae3c: lsl             x12, x1, #1
    //     0x8aae40: lsl             w13, w12, #1
    //     0x8aae44: add             w14, w13, #8
    //     0x8aae48: add             x16, x4, w14, sxtw #1
    //     0x8aae4c: ldur            w19, [x16, #0xf]
    //     0x8aae50: add             x19, x19, HEAP, lsl #32
    //     0x8aae54: add             x16, PP, #0x12, lsl #12  ; [pp+0x12bd8] "useMaterial3"
    //     0x8aae58: ldr             x16, [x16, #0xbd8]
    //     0x8aae5c: cmp             w19, w16
    //     0x8aae60: b.ne            #0x8aae98
    //     0x8aae64: add             w1, w13, #0xa
    //     0x8aae68: add             x16, x4, w1, sxtw #1
    //     0x8aae6c: ldur            w13, [x16, #0xf]
    //     0x8aae70: add             x13, x13, HEAP, lsl #32
    //     0x8aae74: sub             w1, w0, w13
    //     0x8aae78: add             x0, fp, w1, sxtw #2
    //     0x8aae7c: ldr             x0, [x0, #8]
    //     0x8aae80: add             w1, w12, #2
    //     0x8aae84: sbfx            x12, x1, #1, #0x1f
    //     0x8aae88: mov             x16, x12
    //     0x8aae8c: mov             x12, x0
    //     0x8aae90: mov             x0, x16
    //     0x8aae94: b               #0x8aaea0
    //     0x8aae98: mov             x0, x1
    //     0x8aae9c: mov             x12, NULL
    //     0x8aaea0: stur            x12, [fp, #-8]
    //     0x8aaea4: lsl             x1, x0, #1
    //     0x8aaea8: lsl             w0, w1, #1
    //     0x8aaeac: add             w1, w0, #8
    //     0x8aaeb0: add             x16, x4, w1, sxtw #1
    //     0x8aaeb4: ldur            w0, [x16, #0xf]
    //     0x8aaeb8: add             x0, x0, HEAP, lsl #32
    //     0x8aaebc: add             x16, PP, #0x12, lsl #12  ; [pp+0x12be0] "useSystemColors"
    //     0x8aaec0: ldr             x16, [x16, #0xbe0]
    //     0x8aaec4: cmp             w0, w16
    //     0x8aaec8: b.eq            #0x8aaecc
    // 0x8aaecc: CheckStackOverflow
    //     0x8aaecc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8aaed0: cmp             SP, x16
    //     0x8aaed4: b.ls            #0x8abca0
    // 0x8aaed8: cmp             w2, NULL
    // 0x8aaedc: b.ne            #0x8aaef8
    // 0x8aaee0: r1 = <ThemeExtension<ThemeExtension>>
    //     0x8aaee0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12be8] TypeArguments: <ThemeExtension<ThemeExtension>>
    //     0x8aaee4: ldr             x1, [x1, #0xbe8]
    // 0x8aaee8: r2 = 0
    //     0x8aaee8: mov             x2, #0
    // 0x8aaeec: r0 = _GrowableList()
    //     0x8aaeec: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x8aaef0: mov             x3, x0
    // 0x8aaef4: b               #0x8aaefc
    // 0x8aaef8: mov             x3, x2
    // 0x8aaefc: ldur            x0, [fp, #-0x28]
    // 0x8aaf00: stur            x3, [fp, #-0x50]
    // 0x8aaf04: r1 = <Adaptation<Object>>
    //     0x8aaf04: add             x1, PP, #0x12, lsl #12  ; [pp+0x12bf0] TypeArguments: <Adaptation<Object>>
    //     0x8aaf08: ldr             x1, [x1, #0xbf0]
    // 0x8aaf0c: r2 = 0
    //     0x8aaf0c: mov             x2, #0
    // 0x8aaf10: r0 = _GrowableList()
    //     0x8aaf10: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x8aaf14: ldur            x1, [fp, #-0x28]
    // 0x8aaf18: stur            x0, [fp, #-0x58]
    // 0x8aaf1c: cmp             w1, NULL
    // 0x8aaf20: b.eq            #0x8aaf2c
    // 0x8aaf24: r0 = data()
    //     0x8aaf24: bl              #0x8ad7e8  ; [package:flutter/src/material/input_decorator.dart] InputDecorationTheme::data
    // 0x8aaf28: b               #0x8aaf30
    // 0x8aaf2c: mov             x0, x1
    // 0x8aaf30: cmp             w0, NULL
    // 0x8aaf34: b.ne            #0x8aaf44
    // 0x8aaf38: r1 = Instance_InputDecorationThemeData
    //     0x8aaf38: add             x1, PP, #0x12, lsl #12  ; [pp+0x12bf8] Obj!InputDecorationThemeData@12b2b91
    //     0x8aaf3c: ldr             x1, [x1, #0xbf8]
    // 0x8aaf40: b               #0x8aaf48
    // 0x8aaf44: mov             x1, x0
    // 0x8aaf48: ldur            x0, [fp, #-8]
    // 0x8aaf4c: stur            x1, [fp, #-0x28]
    // 0x8aaf50: r0 = visualDensity()
    //     0x8aaf50: bl              #0x1245f38  ; [package:flutter/src/material/icon_button.dart] _OutlinedIconButtonDefaultsM3::visualDensity
    // 0x8aaf54: mov             x3, x0
    // 0x8aaf58: ldur            x0, [fp, #-8]
    // 0x8aaf5c: stur            x3, [fp, #-0x98]
    // 0x8aaf60: cmp             w0, NULL
    // 0x8aaf64: b.ne            #0x8aaf6c
    // 0x8aaf68: r0 = true
    //     0x8aaf68: add             x0, NULL, #0x20  ; true
    // 0x8aaf6c: stur            x0, [fp, #-0x90]
    // 0x8aaf70: tbnz            w0, #4, #0x8aaf80
    // 0x8aaf74: r4 = Instance__InkSparkleFactory
    //     0x8aaf74: add             x4, PP, #0x12, lsl #12  ; [pp+0x12c00] Obj!_InkSparkleFactory@129ecc1
    //     0x8aaf78: ldr             x4, [x4, #0xc00]
    // 0x8aaf7c: b               #0x8aaf88
    // 0x8aaf80: r4 = Instance__InkSplashFactory
    //     0x8aaf80: add             x4, PP, #0x12, lsl #12  ; [pp+0x12c08] Obj!_InkSplashFactory@129ecb1
    //     0x8aaf84: ldr             x4, [x4, #0xc08]
    // 0x8aaf88: ldur            x1, [fp, #-0x40]
    // 0x8aaf8c: stur            x4, [fp, #-0x88]
    // 0x8aaf90: cmp             w1, NULL
    // 0x8aaf94: b.ne            #0x8aafb8
    // 0x8aaf98: ldur            x2, [fp, #-0x38]
    // 0x8aaf9c: cmp             w2, NULL
    // 0x8aafa0: b.ne            #0x8aafac
    // 0x8aafa4: r5 = Null
    //     0x8aafa4: mov             x5, NULL
    // 0x8aafa8: b               #0x8aafc0
    // 0x8aafac: LoadField: r5 = r2->field_7
    //     0x8aafac: ldur            w5, [x2, #7]
    // 0x8aafb0: DecompressPointer r5
    //     0x8aafb0: add             x5, x5, HEAP, lsl #32
    // 0x8aafb4: b               #0x8aafc0
    // 0x8aafb8: ldur            x2, [fp, #-0x38]
    // 0x8aafbc: mov             x5, x1
    // 0x8aafc0: cmp             w5, NULL
    // 0x8aafc4: b.ne            #0x8aafcc
    // 0x8aafc8: r5 = Instance_Brightness
    //     0x8aafc8: ldr             x5, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0x8aafcc: stur            x5, [fp, #-0x80]
    // 0x8aafd0: r16 = Instance_Brightness
    //     0x8aafd0: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x8aafd4: cmp             w5, w16
    // 0x8aafd8: r16 = true
    //     0x8aafd8: add             x16, NULL, #0x20  ; true
    // 0x8aafdc: r17 = false
    //     0x8aafdc: add             x17, NULL, #0x30  ; false
    // 0x8aafe0: csel            x6, x16, x17, eq
    // 0x8aafe4: stur            x6, [fp, #-0x78]
    // 0x8aafe8: tbnz            w0, #4, #0x8ab0b8
    // 0x8aafec: cmp             w2, NULL
    // 0x8aaff0: b.ne            #0x8ab00c
    // 0x8aaff4: tbnz            w6, #4, #0x8ab004
    // 0x8aaff8: r2 = Instance_ColorScheme
    //     0x8aaff8: add             x2, PP, #0x12, lsl #12  ; [pp+0x12c10] Obj!ColorScheme@12b3041
    //     0x8aaffc: ldr             x2, [x2, #0xc10]
    // 0x8ab000: b               #0x8ab00c
    // 0x8ab004: r2 = Instance_ColorScheme
    //     0x8ab004: add             x2, PP, #0x12, lsl #12  ; [pp+0x12c18] Obj!ColorScheme@12b2f71
    //     0x8ab008: ldr             x2, [x2, #0xc18]
    // 0x8ab00c: tbnz            w6, #4, #0x8ab01c
    // 0x8ab010: LoadField: r7 = r2->field_7b
    //     0x8ab010: ldur            w7, [x2, #0x7b]
    // 0x8ab014: DecompressPointer r7
    //     0x8ab014: add             x7, x7, HEAP, lsl #32
    // 0x8ab018: b               #0x8ab024
    // 0x8ab01c: LoadField: r7 = r2->field_b
    //     0x8ab01c: ldur            w7, [x2, #0xb]
    // 0x8ab020: DecompressPointer r7
    //     0x8ab020: add             x7, x7, HEAP, lsl #32
    // 0x8ab024: tbnz            w6, #4, #0x8ab038
    // 0x8ab028: LoadField: r8 = r2->field_7f
    //     0x8ab028: ldur            w8, [x2, #0x7f]
    // 0x8ab02c: DecompressPointer r8
    //     0x8ab02c: add             x8, x8, HEAP, lsl #32
    // 0x8ab030: mov             x9, x8
    // 0x8ab034: b               #0x8ab044
    // 0x8ab038: LoadField: r8 = r2->field_f
    //     0x8ab038: ldur            w8, [x2, #0xf]
    // 0x8ab03c: DecompressPointer r8
    //     0x8ab03c: add             x8, x8, HEAP, lsl #32
    // 0x8ab040: mov             x9, x8
    // 0x8ab044: ldur            x8, [fp, #-0x20]
    // 0x8ab048: cmp             w8, NULL
    // 0x8ab04c: b.ne            #0x8ab054
    // 0x8ab050: mov             x8, x7
    // 0x8ab054: ldur            x7, [fp, #-0x18]
    // 0x8ab058: LoadField: r10 = r2->field_7b
    //     0x8ab058: ldur            w10, [x2, #0x7b]
    // 0x8ab05c: DecompressPointer r10
    //     0x8ab05c: add             x10, x10, HEAP, lsl #32
    // 0x8ab060: cmp             w7, NULL
    // 0x8ab064: b.ne            #0x8ab06c
    // 0x8ab068: mov             x7, x10
    // 0x8ab06c: LoadField: r11 = r2->field_a7
    //     0x8ab06c: ldur            w11, [x2, #0xa7]
    // 0x8ab070: DecompressPointer r11
    //     0x8ab070: add             x11, x11, HEAP, lsl #32
    // 0x8ab074: cmp             w11, NULL
    // 0x8ab078: b.ne            #0x8ab084
    // 0x8ab07c: LoadField: r11 = r2->field_cb
    //     0x8ab07c: ldur            w11, [x2, #0xcb]
    // 0x8ab080: DecompressPointer r11
    //     0x8ab080: add             x11, x11, HEAP, lsl #32
    // 0x8ab084: r16 = Instance_Brightness
    //     0x8ab084: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x8ab088: cmp             w1, w16
    // 0x8ab08c: r16 = true
    //     0x8ab08c: add             x16, NULL, #0x20  ; true
    // 0x8ab090: r17 = false
    //     0x8ab090: add             x17, NULL, #0x30  ; false
    // 0x8ab094: csel            x12, x16, x17, eq
    // 0x8ab098: mov             x1, x8
    // 0x8ab09c: mov             x8, x9
    // 0x8ab0a0: mov             x9, x11
    // 0x8ab0a4: mov             x11, x2
    // 0x8ab0a8: mov             x2, x12
    // 0x8ab0ac: mov             x13, x10
    // 0x8ab0b0: mov             x12, x10
    // 0x8ab0b4: b               #0x8ab0e0
    // 0x8ab0b8: ldur            x8, [fp, #-0x20]
    // 0x8ab0bc: ldur            x7, [fp, #-0x18]
    // 0x8ab0c0: mov             x11, x2
    // 0x8ab0c4: mov             x1, x8
    // 0x8ab0c8: r2 = Null
    //     0x8ab0c8: mov             x2, NULL
    // 0x8ab0cc: r13 = Null
    //     0x8ab0cc: mov             x13, NULL
    // 0x8ab0d0: r12 = Null
    //     0x8ab0d0: mov             x12, NULL
    // 0x8ab0d4: r10 = Null
    //     0x8ab0d4: mov             x10, NULL
    // 0x8ab0d8: r9 = Null
    //     0x8ab0d8: mov             x9, NULL
    // 0x8ab0dc: r8 = Null
    //     0x8ab0dc: mov             x8, NULL
    // 0x8ab0e0: stur            x13, [fp, #-0x18]
    // 0x8ab0e4: stur            x12, [fp, #-0x20]
    // 0x8ab0e8: stur            x11, [fp, #-0x38]
    // 0x8ab0ec: stur            x10, [fp, #-0x40]
    // 0x8ab0f0: stur            x9, [fp, #-0x60]
    // 0x8ab0f4: stur            x8, [fp, #-0x68]
    // 0x8ab0f8: stur            x7, [fp, #-0x70]
    // 0x8ab0fc: cmp             w2, NULL
    // 0x8ab100: b.ne            #0x8ab10c
    // 0x8ab104: r14 = false
    //     0x8ab104: add             x14, NULL, #0x30  ; false
    // 0x8ab108: b               #0x8ab110
    // 0x8ab10c: mov             x14, x2
    // 0x8ab110: stur            x14, [fp, #-8]
    // 0x8ab114: cmp             w1, NULL
    // 0x8ab118: b.ne            #0x8ab14c
    // 0x8ab11c: tbnz            w6, #4, #0x8ab13c
    // 0x8ab120: r1 = _ConstMap len:12
    //     0x8ab120: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c20] Map<int, Color>(12)
    //     0x8ab124: ldr             x1, [x1, #0xc20]
    // 0x8ab128: r2 = 1800
    //     0x8ab128: mov             x2, #0x708
    // 0x8ab12c: r0 = []()
    //     0x8ab12c: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8ab130: cmp             w0, NULL
    // 0x8ab134: b.eq            #0x8abca8
    // 0x8ab138: b               #0x8ab144
    // 0x8ab13c: r0 = Instance_MaterialColor
    //     0x8ab13c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c28] Obj!MaterialColor@12a6e31
    //     0x8ab140: ldr             x0, [x0, #0xc28]
    // 0x8ab144: mov             x2, x0
    // 0x8ab148: b               #0x8ab150
    // 0x8ab14c: mov             x2, x1
    // 0x8ab150: ldur            x0, [fp, #-0x78]
    // 0x8ab154: mov             x1, x2
    // 0x8ab158: stur            x2, [fp, #-0xa0]
    // 0x8ab15c: r0 = estimateBrightnessForColor()
    //     0x8ab15c: bl              #0x8ad774  ; [package:flutter/src/material/theme_data.dart] ThemeData::estimateBrightnessForColor
    // 0x8ab160: mov             x3, x0
    // 0x8ab164: ldur            x0, [fp, #-0x78]
    // 0x8ab168: stur            x3, [fp, #-0xa8]
    // 0x8ab16c: tbnz            w0, #4, #0x8ab190
    // 0x8ab170: r1 = _ConstMap len:12
    //     0x8ab170: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c20] Map<int, Color>(12)
    //     0x8ab174: ldr             x1, [x1, #0xc20]
    // 0x8ab178: r2 = 1000
    //     0x8ab178: mov             x2, #0x3e8
    // 0x8ab17c: r0 = []()
    //     0x8ab17c: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8ab180: cmp             w0, NULL
    // 0x8ab184: b.eq            #0x8abcac
    // 0x8ab188: mov             x3, x0
    // 0x8ab18c: b               #0x8ab1ac
    // 0x8ab190: r1 = _ConstMap len:10
    //     0x8ab190: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c30] Map<int, Color>(10)
    //     0x8ab194: ldr             x1, [x1, #0xc30]
    // 0x8ab198: r2 = 200
    //     0x8ab198: mov             x2, #0xc8
    // 0x8ab19c: r0 = []()
    //     0x8ab19c: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8ab1a0: cmp             w0, NULL
    // 0x8ab1a4: b.eq            #0x8abcb0
    // 0x8ab1a8: mov             x3, x0
    // 0x8ab1ac: ldur            x0, [fp, #-0x78]
    // 0x8ab1b0: stur            x3, [fp, #-0xb0]
    // 0x8ab1b4: tbnz            w0, #4, #0x8ab1c4
    // 0x8ab1b8: r2 = Instance_Color
    //     0x8ab1b8: add             x2, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x8ab1bc: ldr             x2, [x2, #0x948]
    // 0x8ab1c0: b               #0x8ab1e4
    // 0x8ab1c4: r1 = _ConstMap len:10
    //     0x8ab1c4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c30] Map<int, Color>(10)
    //     0x8ab1c8: ldr             x1, [x1, #0xc30]
    // 0x8ab1cc: r2 = 1400
    //     0x8ab1cc: mov             x2, #0x578
    // 0x8ab1d0: r0 = []()
    //     0x8ab1d0: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8ab1d4: cmp             w0, NULL
    // 0x8ab1d8: b.eq            #0x8abcb4
    // 0x8ab1dc: mov             x2, x0
    // 0x8ab1e0: ldur            x0, [fp, #-0x78]
    // 0x8ab1e4: ldur            x1, [fp, #-0xa8]
    // 0x8ab1e8: stur            x2, [fp, #-0xc0]
    // 0x8ab1ec: r16 = Instance_Brightness
    //     0x8ab1ec: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x8ab1f0: cmp             w1, w16
    // 0x8ab1f4: r16 = true
    //     0x8ab1f4: add             x16, NULL, #0x20  ; true
    // 0x8ab1f8: r17 = false
    //     0x8ab1f8: add             x17, NULL, #0x30  ; false
    // 0x8ab1fc: csel            x3, x16, x17, eq
    // 0x8ab200: stur            x3, [fp, #-0xb8]
    // 0x8ab204: tbnz            w0, #4, #0x8ab224
    // 0x8ab208: r1 = Instance_Color
    //     0x8ab208: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x8ab20c: ldr             x1, [x1, #0xc38]
    // 0x8ab210: d0 = 0.120000
    //     0x8ab210: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x8ab214: ldr             d0, [x17, #0xc40]
    // 0x8ab218: r0 = withOpacity()
    //     0x8ab218: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x8ab21c: mov             x2, x0
    // 0x8ab220: b               #0x8ab23c
    // 0x8ab224: r1 = Instance_Color
    //     0x8ab224: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x8ab228: ldr             x1, [x1, #0x948]
    // 0x8ab22c: d0 = 0.120000
    //     0x8ab22c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x8ab230: ldr             d0, [x17, #0xc40]
    // 0x8ab234: r0 = withOpacity()
    //     0x8ab234: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x8ab238: mov             x2, x0
    // 0x8ab23c: ldur            x0, [fp, #-0x78]
    // 0x8ab240: stur            x2, [fp, #-0xa8]
    // 0x8ab244: tbnz            w0, #4, #0x8ab264
    // 0x8ab248: r1 = Instance_Color
    //     0x8ab248: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x8ab24c: ldr             x1, [x1, #0xc38]
    // 0x8ab250: d0 = 0.040000
    //     0x8ab250: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c48] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x8ab254: ldr             d0, [x17, #0xc48]
    // 0x8ab258: r0 = withOpacity()
    //     0x8ab258: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x8ab25c: mov             x3, x0
    // 0x8ab260: b               #0x8ab27c
    // 0x8ab264: r1 = Instance_Color
    //     0x8ab264: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x8ab268: ldr             x1, [x1, #0x948]
    // 0x8ab26c: d0 = 0.040000
    //     0x8ab26c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c48] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x8ab270: ldr             d0, [x17, #0xc48]
    // 0x8ab274: r0 = withOpacity()
    //     0x8ab274: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x8ab278: mov             x3, x0
    // 0x8ab27c: ldur            x0, [fp, #-0x18]
    // 0x8ab280: stur            x3, [fp, #-0xc8]
    // 0x8ab284: cmp             w0, NULL
    // 0x8ab288: b.ne            #0x8ab2d0
    // 0x8ab28c: ldur            x0, [fp, #-0x78]
    // 0x8ab290: tbnz            w0, #4, #0x8ab2b0
    // 0x8ab294: r1 = _ConstMap len:12
    //     0x8ab294: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c20] Map<int, Color>(12)
    //     0x8ab298: ldr             x1, [x1, #0xc20]
    // 0x8ab29c: r2 = 1700
    //     0x8ab29c: mov             x2, #0x6a4
    // 0x8ab2a0: r0 = []()
    //     0x8ab2a0: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8ab2a4: cmp             w0, NULL
    // 0x8ab2a8: b.eq            #0x8abcb8
    // 0x8ab2ac: b               #0x8ab2c8
    // 0x8ab2b0: r1 = _ConstMap len:12
    //     0x8ab2b0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c20] Map<int, Color>(12)
    //     0x8ab2b4: ldr             x1, [x1, #0xc20]
    // 0x8ab2b8: r2 = 100
    //     0x8ab2b8: mov             x2, #0x64
    // 0x8ab2bc: r0 = []()
    //     0x8ab2bc: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8ab2c0: cmp             w0, NULL
    // 0x8ab2c4: b.eq            #0x8abcbc
    // 0x8ab2c8: mov             x3, x0
    // 0x8ab2cc: b               #0x8ab2d4
    // 0x8ab2d0: mov             x3, x0
    // 0x8ab2d4: ldur            x0, [fp, #-0x70]
    // 0x8ab2d8: stur            x3, [fp, #-0xd0]
    // 0x8ab2dc: cmp             w0, NULL
    // 0x8ab2e0: b.ne            #0x8ab2ec
    // 0x8ab2e4: mov             x4, x3
    // 0x8ab2e8: b               #0x8ab2f0
    // 0x8ab2ec: mov             x4, x0
    // 0x8ab2f0: ldur            x0, [fp, #-0x20]
    // 0x8ab2f4: stur            x4, [fp, #-0x18]
    // 0x8ab2f8: cmp             w0, NULL
    // 0x8ab2fc: b.ne            #0x8ab334
    // 0x8ab300: ldur            x0, [fp, #-0x78]
    // 0x8ab304: tbnz            w0, #4, #0x8ab324
    // 0x8ab308: r1 = _ConstMap len:12
    //     0x8ab308: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c20] Map<int, Color>(12)
    //     0x8ab30c: ldr             x1, [x1, #0xc20]
    // 0x8ab310: r2 = 1600
    //     0x8ab310: mov             x2, #0x640
    // 0x8ab314: r0 = []()
    //     0x8ab314: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8ab318: cmp             w0, NULL
    // 0x8ab31c: b.eq            #0x8abcc0
    // 0x8ab320: b               #0x8ab32c
    // 0x8ab324: r0 = Instance_Color
    //     0x8ab324: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x8ab328: ldr             x0, [x0, #0xc38]
    // 0x8ab32c: mov             x6, x0
    // 0x8ab330: b               #0x8ab338
    // 0x8ab334: mov             x6, x0
    // 0x8ab338: ldur            x0, [fp, #-0x60]
    // 0x8ab33c: stur            x6, [fp, #-0x70]
    // 0x8ab340: cmp             w0, NULL
    // 0x8ab344: b.ne            #0x8ab36c
    // 0x8ab348: ldur            x3, [fp, #-0x78]
    // 0x8ab34c: tbnz            w3, #4, #0x8ab35c
    // 0x8ab350: r0 = Instance_Color
    //     0x8ab350: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c50] Obj!Color@12a1a71
    //     0x8ab354: ldr             x0, [x0, #0xc50]
    // 0x8ab358: b               #0x8ab364
    // 0x8ab35c: r0 = Instance_Color
    //     0x8ab35c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c58] Obj!Color@12a1a41
    //     0x8ab360: ldr             x0, [x0, #0xc58]
    // 0x8ab364: mov             x4, x0
    // 0x8ab368: b               #0x8ab374
    // 0x8ab36c: ldur            x3, [fp, #-0x78]
    // 0x8ab370: mov             x4, x0
    // 0x8ab374: ldur            x0, [fp, #-0x38]
    // 0x8ab378: stur            x4, [fp, #-0x20]
    // 0x8ab37c: cmp             w0, NULL
    // 0x8ab380: b.ne            #0x8ab444
    // 0x8ab384: tbnz            w3, #4, #0x8ab3a8
    // 0x8ab388: r1 = _ConstMap len:4
    //     0x8ab388: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c60] Map<int, Color>(4)
    //     0x8ab38c: ldr             x1, [x1, #0xc60]
    // 0x8ab390: r2 = 400
    //     0x8ab390: mov             x2, #0x190
    // 0x8ab394: r0 = []()
    //     0x8ab394: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8ab398: cmp             w0, NULL
    // 0x8ab39c: b.eq            #0x8abcc4
    // 0x8ab3a0: mov             x3, x0
    // 0x8ab3a4: b               #0x8ab3c4
    // 0x8ab3a8: r1 = _ConstMap len:10
    //     0x8ab3a8: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c30] Map<int, Color>(10)
    //     0x8ab3ac: ldr             x1, [x1, #0xc30]
    // 0x8ab3b0: r2 = 1000
    //     0x8ab3b0: mov             x2, #0x3e8
    // 0x8ab3b4: r0 = []()
    //     0x8ab3b4: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8ab3b8: cmp             w0, NULL
    // 0x8ab3bc: b.eq            #0x8abcc8
    // 0x8ab3c0: mov             x3, x0
    // 0x8ab3c4: ldur            x0, [fp, #-0x78]
    // 0x8ab3c8: stur            x3, [fp, #-0x60]
    // 0x8ab3cc: tbnz            w0, #4, #0x8ab3f0
    // 0x8ab3d0: r1 = _ConstMap len:12
    //     0x8ab3d0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c20] Map<int, Color>(12)
    //     0x8ab3d4: ldr             x1, [x1, #0xc20]
    // 0x8ab3d8: r2 = 1400
    //     0x8ab3d8: mov             x2, #0x578
    // 0x8ab3dc: r0 = []()
    //     0x8ab3dc: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8ab3e0: cmp             w0, NULL
    // 0x8ab3e4: b.eq            #0x8abccc
    // 0x8ab3e8: mov             x3, x0
    // 0x8ab3ec: b               #0x8ab40c
    // 0x8ab3f0: r1 = _ConstMap len:10
    //     0x8ab3f0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c30] Map<int, Color>(10)
    //     0x8ab3f4: ldr             x1, [x1, #0xc30]
    // 0x8ab3f8: r2 = 400
    //     0x8ab3f8: mov             x2, #0x190
    // 0x8ab3fc: r0 = []()
    //     0x8ab3fc: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8ab400: cmp             w0, NULL
    // 0x8ab404: b.eq            #0x8abcd0
    // 0x8ab408: mov             x3, x0
    // 0x8ab40c: stur            x3, [fp, #-0xd8]
    // 0x8ab410: r1 = _ConstMap len:10
    //     0x8ab410: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c68] Map<int, Color>(10)
    //     0x8ab414: ldr             x1, [x1, #0xc68]
    // 0x8ab418: r2 = 1400
    //     0x8ab418: mov             x2, #0x578
    // 0x8ab41c: r0 = []()
    //     0x8ab41c: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8ab420: ldur            x2, [fp, #-0x60]
    // 0x8ab424: ldur            x3, [fp, #-0xd8]
    // 0x8ab428: ldur            x5, [fp, #-0x80]
    // 0x8ab42c: ldur            x6, [fp, #-0x70]
    // 0x8ab430: mov             x7, x0
    // 0x8ab434: r1 = Null
    //     0x8ab434: mov             x1, NULL
    // 0x8ab438: r0 = ColorScheme.fromSwatch()
    //     0x8ab438: bl              #0x8ad59c  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::ColorScheme.fromSwatch
    // 0x8ab43c: mov             x3, x0
    // 0x8ab440: b               #0x8ab448
    // 0x8ab444: mov             x3, x0
    // 0x8ab448: ldur            x0, [fp, #-0x78]
    // 0x8ab44c: stur            x3, [fp, #-0x60]
    // 0x8ab450: tbnz            w0, #4, #0x8ab460
    // 0x8ab454: r4 = Instance_Color
    //     0x8ab454: add             x4, PP, #0x12, lsl #12  ; [pp+0x12c70] Obj!Color@12a1771
    //     0x8ab458: ldr             x4, [x4, #0xc70]
    // 0x8ab45c: b               #0x8ab468
    // 0x8ab460: r4 = Instance_Color
    //     0x8ab460: add             x4, PP, #0x12, lsl #12  ; [pp+0x12c78] Obj!Color@12a1741
    //     0x8ab464: ldr             x4, [x4, #0xc78]
    // 0x8ab468: stur            x4, [fp, #-0x38]
    // 0x8ab46c: tbnz            w0, #4, #0x8ab490
    // 0x8ab470: r1 = _ConstMap len:12
    //     0x8ab470: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c20] Map<int, Color>(12)
    //     0x8ab474: ldr             x1, [x1, #0xc20]
    // 0x8ab478: r2 = 1400
    //     0x8ab478: mov             x2, #0x578
    // 0x8ab47c: r0 = []()
    //     0x8ab47c: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8ab480: cmp             w0, NULL
    // 0x8ab484: b.eq            #0x8abcd4
    // 0x8ab488: mov             x2, x0
    // 0x8ab48c: b               #0x8ab4ac
    // 0x8ab490: r1 = _ConstMap len:10
    //     0x8ab490: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c30] Map<int, Color>(10)
    //     0x8ab494: ldr             x1, [x1, #0xc30]
    // 0x8ab498: r2 = 100
    //     0x8ab498: mov             x2, #0x64
    // 0x8ab49c: r0 = []()
    //     0x8ab49c: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8ab4a0: cmp             w0, NULL
    // 0x8ab4a4: b.eq            #0x8abcd8
    // 0x8ab4a8: mov             x2, x0
    // 0x8ab4ac: ldur            x0, [fp, #-0x78]
    // 0x8ab4b0: stur            x2, [fp, #-0x80]
    // 0x8ab4b4: tbnz            w0, #4, #0x8ab4c4
    // 0x8ab4b8: r3 = Instance_Color
    //     0x8ab4b8: add             x3, PP, #0x12, lsl #12  ; [pp+0x12c80] Obj!Color@12a1711
    //     0x8ab4bc: ldr             x3, [x3, #0xc80]
    // 0x8ab4c0: b               #0x8ab4e0
    // 0x8ab4c4: r1 = Instance_Color
    //     0x8ab4c4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x8ab4c8: ldr             x1, [x1, #0x948]
    // 0x8ab4cc: d0 = 0.600000
    //     0x8ab4cc: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0x8ab4d0: ldr             d0, [x17, #0xc88]
    // 0x8ab4d4: r0 = withOpacity()
    //     0x8ab4d4: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x8ab4d8: mov             x3, x0
    // 0x8ab4dc: ldur            x0, [fp, #-0x78]
    // 0x8ab4e0: stur            x3, [fp, #-0xd8]
    // 0x8ab4e4: tbnz            w0, #4, #0x8ab508
    // 0x8ab4e8: r1 = _ConstMap len:10
    //     0x8ab4e8: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c30] Map<int, Color>(10)
    //     0x8ab4ec: ldr             x1, [x1, #0xc30]
    // 0x8ab4f0: r2 = 1200
    //     0x8ab4f0: mov             x2, #0x4b0
    // 0x8ab4f4: r0 = []()
    //     0x8ab4f4: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8ab4f8: cmp             w0, NULL
    // 0x8ab4fc: b.eq            #0x8abcdc
    // 0x8ab500: mov             x4, x0
    // 0x8ab504: b               #0x8ab524
    // 0x8ab508: r1 = _ConstMap len:12
    //     0x8ab508: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c20] Map<int, Color>(12)
    //     0x8ab50c: ldr             x1, [x1, #0xc20]
    // 0x8ab510: r2 = 600
    //     0x8ab510: mov             x2, #0x258
    // 0x8ab514: r0 = []()
    //     0x8ab514: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8ab518: cmp             w0, NULL
    // 0x8ab51c: b.eq            #0x8abce0
    // 0x8ab520: mov             x4, x0
    // 0x8ab524: ldur            x3, [fp, #-0xa8]
    // 0x8ab528: ldur            x1, [fp, #-0xc8]
    // 0x8ab52c: ldur            x2, [fp, #-0x60]
    // 0x8ab530: ldur            x0, [fp, #-0x78]
    // 0x8ab534: stur            x4, [fp, #-0xe0]
    // 0x8ab538: r0 = ButtonThemeData()
    //     0x8ab538: bl              #0x8ad590  ; AllocateButtonThemeDataStub -> ButtonThemeData (size=0x4c)
    // 0x8ab53c: mov             x3, x0
    // 0x8ab540: r0 = Instance_ButtonTextTheme
    //     0x8ab540: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c90] Obj!ButtonTextTheme@12c5981
    //     0x8ab544: ldr             x0, [x0, #0xc90]
    // 0x8ab548: stur            x3, [fp, #-0xf8]
    // 0x8ab54c: ArrayStore: r3[0] = r0  ; List_4
    //     0x8ab54c: stur            w0, [x3, #0x17]
    // 0x8ab550: d0 = 88.000000
    //     0x8ab550: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c98] IMM: double(88) from 0x4056000000000000
    //     0x8ab554: ldr             d0, [x17, #0xc98]
    // 0x8ab558: StoreField: r3->field_7 = d0
    //     0x8ab558: stur            d0, [x3, #7]
    // 0x8ab55c: d0 = 36.000000
    //     0x8ab55c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12ca0] IMM: double(36) from 0x4042000000000000
    //     0x8ab560: ldr             d0, [x17, #0xca0]
    // 0x8ab564: StoreField: r3->field_f = d0
    //     0x8ab564: stur            d0, [x3, #0xf]
    // 0x8ab568: r0 = Instance_ButtonBarLayoutBehavior
    //     0x8ab568: add             x0, PP, #0x12, lsl #12  ; [pp+0x12ca8] Obj!ButtonBarLayoutBehavior@12c5961
    //     0x8ab56c: ldr             x0, [x0, #0xca8]
    // 0x8ab570: StoreField: r3->field_1b = r0
    //     0x8ab570: stur            w0, [x3, #0x1b]
    // 0x8ab574: r0 = false
    //     0x8ab574: add             x0, NULL, #0x30  ; false
    // 0x8ab578: StoreField: r3->field_27 = r0
    //     0x8ab578: stur            w0, [x3, #0x27]
    // 0x8ab57c: ldur            x0, [fp, #-0x60]
    // 0x8ab580: StoreField: r3->field_43 = r0
    //     0x8ab580: stur            w0, [x3, #0x43]
    // 0x8ab584: ldur            x1, [fp, #-0xe0]
    // 0x8ab588: StoreField: r3->field_2b = r1
    //     0x8ab588: stur            w1, [x3, #0x2b]
    // 0x8ab58c: ldur            x4, [fp, #-0xa8]
    // 0x8ab590: StoreField: r3->field_33 = r4
    //     0x8ab590: stur            w4, [x3, #0x33]
    // 0x8ab594: ldur            x5, [fp, #-0xc8]
    // 0x8ab598: StoreField: r3->field_37 = r5
    //     0x8ab598: stur            w5, [x3, #0x37]
    // 0x8ab59c: r6 = Instance_MaterialTapTargetSize
    //     0x8ab59c: add             x6, PP, #0x12, lsl #12  ; [pp+0x12cb0] Obj!MaterialTapTargetSize@12c4b81
    //     0x8ab5a0: ldr             x6, [x6, #0xcb0]
    // 0x8ab5a4: StoreField: r3->field_47 = r6
    //     0x8ab5a4: stur            w6, [x3, #0x47]
    // 0x8ab5a8: ldur            x7, [fp, #-0x78]
    // 0x8ab5ac: tbnz            w7, #4, #0x8ab5bc
    // 0x8ab5b0: r8 = Instance_Color
    //     0x8ab5b0: add             x8, PP, #0x12, lsl #12  ; [pp+0x12cb8] Obj!Color@12a16e1
    //     0x8ab5b4: ldr             x8, [x8, #0xcb8]
    // 0x8ab5b8: b               #0x8ab5c4
    // 0x8ab5bc: r8 = Instance_Color
    //     0x8ab5bc: add             x8, PP, #0x12, lsl #12  ; [pp+0x12cc0] Obj!Color@12a16b1
    //     0x8ab5c0: ldr             x8, [x8, #0xcc0]
    // 0x8ab5c4: stur            x8, [fp, #-0xf0]
    // 0x8ab5c8: tbnz            w7, #4, #0x8ab5d8
    // 0x8ab5cc: r9 = Instance_Color
    //     0x8ab5cc: add             x9, PP, #0x12, lsl #12  ; [pp+0x12cc8] Obj!Color@12a1681
    //     0x8ab5d0: ldr             x9, [x9, #0xcc8]
    // 0x8ab5d4: b               #0x8ab5e0
    // 0x8ab5d8: r9 = Instance_Color
    //     0x8ab5d8: add             x9, PP, #0x12, lsl #12  ; [pp+0x12cd0] Obj!Color@12a1651
    //     0x8ab5dc: ldr             x9, [x9, #0xcd0]
    // 0x8ab5e0: stur            x9, [fp, #-0xe8]
    // 0x8ab5e4: tbnz            w7, #4, #0x8ab5f4
    // 0x8ab5e8: r11 = Instance_Color
    //     0x8ab5e8: add             x11, PP, #0x12, lsl #12  ; [pp+0x12cc8] Obj!Color@12a1681
    //     0x8ab5ec: ldr             x11, [x11, #0xcc8]
    // 0x8ab5f0: b               #0x8ab5fc
    // 0x8ab5f4: r11 = Instance_Color
    //     0x8ab5f4: add             x11, PP, #0x12, lsl #12  ; [pp+0x12cd8] Obj!Color@12a1621
    //     0x8ab5f8: ldr             x11, [x11, #0xcd8]
    // 0x8ab5fc: ldur            x10, [fp, #-0x90]
    // 0x8ab600: stur            x11, [fp, #-0xe0]
    // 0x8ab604: tbnz            w10, #4, #0x8ab61c
    // 0x8ab608: mov             x2, x0
    // 0x8ab60c: r1 = Null
    //     0x8ab60c: mov             x1, NULL
    // 0x8ab610: r0 = Typography.material2021()
    //     0x8ab610: bl              #0x8ac95c  ; [package:flutter/src/material/typography.dart] Typography::Typography.material2021
    // 0x8ab614: mov             x3, x0
    // 0x8ab618: b               #0x8ab628
    // 0x8ab61c: r1 = Null
    //     0x8ab61c: mov             x1, NULL
    // 0x8ab620: r0 = Typography.material2014()
    //     0x8ab620: bl              #0x8ac808  ; [package:flutter/src/material/typography.dart] Typography::Typography.material2014
    // 0x8ab624: mov             x3, x0
    // 0x8ab628: ldur            x0, [fp, #-0x78]
    // 0x8ab62c: r17 = -264
    //     0x8ab62c: mov             x17, #-0x108
    // 0x8ab630: str             x3, [fp, x17]
    // 0x8ab634: tbnz            w0, #4, #0x8ab644
    // 0x8ab638: LoadField: r1 = r3->field_b
    //     0x8ab638: ldur            w1, [x3, #0xb]
    // 0x8ab63c: DecompressPointer r1
    //     0x8ab63c: add             x1, x1, HEAP, lsl #32
    // 0x8ab640: b               #0x8ab64c
    // 0x8ab644: LoadField: r1 = r3->field_7
    //     0x8ab644: ldur            w1, [x3, #7]
    // 0x8ab648: DecompressPointer r1
    //     0x8ab648: add             x1, x1, HEAP, lsl #32
    // 0x8ab64c: ldur            x4, [fp, #-0xb8]
    // 0x8ab650: tbnz            w4, #4, #0x8ab664
    // 0x8ab654: LoadField: r2 = r3->field_b
    //     0x8ab654: ldur            w2, [x3, #0xb]
    // 0x8ab658: DecompressPointer r2
    //     0x8ab658: add             x2, x2, HEAP, lsl #32
    // 0x8ab65c: mov             x5, x2
    // 0x8ab660: b               #0x8ab670
    // 0x8ab664: LoadField: r2 = r3->field_7
    //     0x8ab664: ldur            w2, [x3, #7]
    // 0x8ab668: DecompressPointer r2
    //     0x8ab668: add             x2, x2, HEAP, lsl #32
    // 0x8ab66c: mov             x5, x2
    // 0x8ab670: stur            x5, [fp, #-0x100]
    // 0x8ab674: r2 = Null
    //     0x8ab674: mov             x2, NULL
    // 0x8ab678: r0 = merge()
    //     0x8ab678: bl              #0x8a91f8  ; [package:flutter/src/material/text_theme.dart] TextTheme::merge
    // 0x8ab67c: ldur            x1, [fp, #-0x100]
    // 0x8ab680: r2 = Null
    //     0x8ab680: mov             x2, NULL
    // 0x8ab684: stur            x0, [fp, #-0x100]
    // 0x8ab688: r0 = merge()
    //     0x8ab688: bl              #0x8a91f8  ; [package:flutter/src/material/text_theme.dart] TextTheme::merge
    // 0x8ab68c: mov             x1, x0
    // 0x8ab690: ldur            x0, [fp, #-0x78]
    // 0x8ab694: r17 = -272
    //     0x8ab694: mov             x17, #-0x110
    // 0x8ab698: str             x1, [fp, x17]
    // 0x8ab69c: tbnz            w0, #4, #0x8ab6e4
    // 0x8ab6a0: r0 = LoadStaticField(0xb80)
    //     0x8ab6a0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8ab6a4: ldr             x0, [x0, #0x1700]
    // 0x8ab6a8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ab6ac: cmp             w0, w16
    // 0x8ab6b0: b.ne            #0x8ab6c0
    // 0x8ab6b4: r2 = kDefaultIconLightColor
    //     0x8ab6b4: add             x2, PP, #0x12, lsl #12  ; [pp+0x12ce0] Field <::.kDefaultIconLightColor>: static late final (offset: 0xb80)
    //     0x8ab6b8: ldr             x2, [x2, #0xce0]
    // 0x8ab6bc: r0 = InitLateFinalStaticField()
    //     0x8ab6bc: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8ab6c0: r17 = -280
    //     0x8ab6c0: mov             x17, #-0x118
    // 0x8ab6c4: str             x0, [fp, x17]
    // 0x8ab6c8: r0 = IconThemeData()
    //     0x8ab6c8: bl              #0x8ac78c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0x8ab6cc: mov             x1, x0
    // 0x8ab6d0: r17 = -280
    //     0x8ab6d0: mov             x17, #-0x118
    // 0x8ab6d4: ldr             x0, [fp, x17]
    // 0x8ab6d8: StoreField: r1->field_1b = r0
    //     0x8ab6d8: stur            w0, [x1, #0x1b]
    // 0x8ab6dc: mov             x2, x1
    // 0x8ab6e0: b               #0x8ab724
    // 0x8ab6e4: r0 = LoadStaticField(0xb84)
    //     0x8ab6e4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8ab6e8: ldr             x0, [x0, #0x1708]
    // 0x8ab6ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ab6f0: cmp             w0, w16
    // 0x8ab6f4: b.ne            #0x8ab704
    // 0x8ab6f8: r2 = kDefaultIconDarkColor
    //     0x8ab6f8: add             x2, PP, #0x12, lsl #12  ; [pp+0x12ce8] Field <::.kDefaultIconDarkColor>: static late final (offset: 0xb84)
    //     0x8ab6fc: ldr             x2, [x2, #0xce8]
    // 0x8ab700: r0 = InitLateFinalStaticField()
    //     0x8ab700: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8ab704: r17 = -280
    //     0x8ab704: mov             x17, #-0x118
    // 0x8ab708: str             x0, [fp, x17]
    // 0x8ab70c: r0 = IconThemeData()
    //     0x8ab70c: bl              #0x8ac78c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0x8ab710: mov             x1, x0
    // 0x8ab714: r17 = -280
    //     0x8ab714: mov             x17, #-0x118
    // 0x8ab718: ldr             x0, [fp, x17]
    // 0x8ab71c: StoreField: r1->field_1b = r0
    //     0x8ab71c: stur            w0, [x1, #0x1b]
    // 0x8ab720: mov             x2, x1
    // 0x8ab724: ldur            x0, [fp, #-0xb8]
    // 0x8ab728: r17 = -280
    //     0x8ab728: mov             x17, #-0x118
    // 0x8ab72c: str             x2, [fp, x17]
    // 0x8ab730: tbnz            w0, #4, #0x8ab740
    // 0x8ab734: r0 = Instance_IconThemeData
    //     0x8ab734: add             x0, PP, #0x12, lsl #12  ; [pp+0x12cf0] Obj!IconThemeData@12b3fc1
    //     0x8ab738: ldr             x0, [x0, #0xcf0]
    // 0x8ab73c: b               #0x8ab748
    // 0x8ab740: r0 = Instance_IconThemeData
    //     0x8ab740: add             x0, PP, #0x12, lsl #12  ; [pp+0x12cf8] Obj!IconThemeData@12b3f91
    //     0x8ab744: ldr             x0, [x0, #0xcf8]
    // 0x8ab748: ldur            x1, [fp, #-0x48]
    // 0x8ab74c: stur            x0, [fp, #-0xb8]
    // 0x8ab750: cmp             w1, NULL
    // 0x8ab754: b.eq            #0x8ab764
    // 0x8ab758: r0 = data()
    //     0x8ab758: bl              #0x8ac6dc  ; [package:flutter/src/material/app_bar_theme.dart] AppBarTheme::data
    // 0x8ab75c: mov             x3, x0
    // 0x8ab760: b               #0x8ab768
    // 0x8ab764: mov             x3, x1
    // 0x8ab768: ldur            x0, [fp, #-0x30]
    // 0x8ab76c: stur            x3, [fp, #-0x48]
    // 0x8ab770: cmp             w0, NULL
    // 0x8ab774: b.ne            #0x8ab784
    // 0x8ab778: r4 = Instance_FloatingActionButtonThemeData
    //     0x8ab778: add             x4, PP, #0x12, lsl #12  ; [pp+0x12d00] Obj!FloatingActionButtonThemeData@12b2c41
    //     0x8ab77c: ldr             x4, [x4, #0xd00]
    // 0x8ab780: b               #0x8ab788
    // 0x8ab784: mov             x4, x0
    // 0x8ab788: ldur            x0, [fp, #-0x10]
    // 0x8ab78c: stur            x4, [fp, #-0x30]
    // 0x8ab790: cmp             w0, NULL
    // 0x8ab794: b.ne            #0x8ab7a4
    // 0x8ab798: r5 = Instance_TabBarThemeData
    //     0x8ab798: add             x5, PP, #0x12, lsl #12  ; [pp+0x12d08] Obj!TabBarThemeData@12b2051
    //     0x8ab79c: ldr             x5, [x5, #0xd08]
    // 0x8ab7a0: b               #0x8ab7a8
    // 0x8ab7a4: mov             x5, x0
    // 0x8ab7a8: ldur            x0, [fp, #-0x40]
    // 0x8ab7ac: stur            x5, [fp, #-0x10]
    // 0x8ab7b0: cmp             w0, NULL
    // 0x8ab7b4: b.ne            #0x8ab7ec
    // 0x8ab7b8: ldur            x0, [fp, #-0x78]
    // 0x8ab7bc: tbnz            w0, #4, #0x8ab7dc
    // 0x8ab7c0: r1 = _ConstMap len:12
    //     0x8ab7c0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c20] Map<int, Color>(12)
    //     0x8ab7c4: ldr             x1, [x1, #0xc20]
    // 0x8ab7c8: r2 = 1600
    //     0x8ab7c8: mov             x2, #0x640
    // 0x8ab7cc: r0 = []()
    //     0x8ab7cc: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8ab7d0: cmp             w0, NULL
    // 0x8ab7d4: b.eq            #0x8abce4
    // 0x8ab7d8: b               #0x8ab7e4
    // 0x8ab7dc: r0 = Instance_Color
    //     0x8ab7dc: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x8ab7e0: ldr             x0, [x0, #0xc38]
    // 0x8ab7e4: mov             x1, x0
    // 0x8ab7e8: b               #0x8ab7f0
    // 0x8ab7ec: mov             x1, x0
    // 0x8ab7f0: ldur            x0, [fp, #-0x68]
    // 0x8ab7f4: stur            x1, [fp, #-0x78]
    // 0x8ab7f8: cmp             w0, NULL
    // 0x8ab7fc: b.ne            #0x8ab848
    // 0x8ab800: ldur            x2, [fp, #-0x60]
    // 0x8ab804: LoadField: r3 = r2->field_2b
    //     0x8ab804: ldur            w3, [x2, #0x2b]
    // 0x8ab808: DecompressPointer r3
    //     0x8ab808: add             x3, x3, HEAP, lsl #32
    // 0x8ab80c: stur            x3, [fp, #-0x40]
    // 0x8ab810: r0 = LoadClassIdInstr(r3)
    //     0x8ab810: ldur            x0, [x3, #-1]
    //     0x8ab814: ubfx            x0, x0, #0xc, #0x14
    // 0x8ab818: ldur            x16, [fp, #-0xa0]
    // 0x8ab81c: stp             x16, x3, [SP]
    // 0x8ab820: mov             lr, x0
    // 0x8ab824: ldr             lr, [x21, lr, lsl #3]
    // 0x8ab828: blr             lr
    // 0x8ab82c: tbnz            w0, #4, #0x8ab83c
    // 0x8ab830: r0 = Instance_Color
    //     0x8ab830: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x8ab834: ldr             x0, [x0, #0xc38]
    // 0x8ab838: b               #0x8ab840
    // 0x8ab83c: ldur            x0, [fp, #-0x40]
    // 0x8ab840: mov             x2, x0
    // 0x8ab844: b               #0x8ab84c
    // 0x8ab848: mov             x2, x0
    // 0x8ab84c: ldur            x0, [fp, #-0x48]
    // 0x8ab850: ldur            x1, [fp, #-0x58]
    // 0x8ab854: stur            x2, [fp, #-0x40]
    // 0x8ab858: r0 = _createAdaptationMap()
    //     0x8ab858: bl              #0x8ac530  ; [package:flutter/src/material/theme_data.dart] ThemeData::_createAdaptationMap
    // 0x8ab85c: ldur            x1, [fp, #-0x50]
    // 0x8ab860: stur            x0, [fp, #-0x50]
    // 0x8ab864: r0 = _themeExtensionIterableToMap()
    //     0x8ab864: bl              #0x8abe00  ; [package:flutter/src/material/theme_data.dart] ThemeData::_themeExtensionIterableToMap
    // 0x8ab868: mov             x1, x0
    // 0x8ab86c: ldur            x0, [fp, #-0x48]
    // 0x8ab870: stur            x1, [fp, #-0x58]
    // 0x8ab874: cmp             w0, NULL
    // 0x8ab878: b.ne            #0x8ab894
    // 0x8ab87c: SaveReg r0
    //     0x8ab87c: str             x0, [SP, #-8]!
    // 0x8ab880: r0 = Instance_AppBarThemeData
    //     0x8ab880: add             x0, PP, #0x12, lsl #12  ; [pp+0x12d10] Obj!AppBarThemeData@12b33c1
    //     0x8ab884: ldr             x0, [x0, #0xd10]
    // 0x8ab888: stur            x0, [fp, #-0x48]
    // 0x8ab88c: RestoreReg r0
    //     0x8ab88c: ldr             x0, [SP], #8
    // 0x8ab890: b               #0x8ab898
    // 0x8ab894: stur            x0, [fp, #-0x48]
    // 0x8ab898: ldur            x23, [fp, #-0x90]
    // 0x8ab89c: ldur            x13, [fp, #-0xa8]
    // 0x8ab8a0: ldur            x14, [fp, #-0xc8]
    // 0x8ab8a4: ldur            x4, [fp, #-0x60]
    // 0x8ab8a8: ldur            x25, [fp, #-0xd8]
    // 0x8ab8ac: ldur            x12, [fp, #-0xf8]
    // 0x8ab8b0: ldur            x19, [fp, #-0xf0]
    // 0x8ab8b4: ldur            x20, [fp, #-0xe8]
    // 0x8ab8b8: ldur            x24, [fp, #-0xe0]
    // 0x8ab8bc: r17 = -264
    //     0x8ab8bc: mov             x17, #-0x108
    // 0x8ab8c0: ldr             x11, [fp, x17]
    // 0x8ab8c4: ldur            x10, [fp, #-0x100]
    // 0x8ab8c8: r17 = -272
    //     0x8ab8c8: mov             x17, #-0x110
    // 0x8ab8cc: ldr             x9, [fp, x17]
    // 0x8ab8d0: r17 = -280
    //     0x8ab8d0: mov             x17, #-0x118
    // 0x8ab8d4: ldr             x7, [fp, x17]
    // 0x8ab8d8: ldur            x8, [fp, #-0xb8]
    // 0x8ab8dc: ldur            x5, [fp, #-0x30]
    // 0x8ab8e0: ldur            x6, [fp, #-0x10]
    // 0x8ab8e4: ldur            x3, [fp, #-0x78]
    // 0x8ab8e8: ldur            x2, [fp, #-0x40]
    // 0x8ab8ec: ldur            x0, [fp, #-0x50]
    // 0x8ab8f0: r0 = ThemeData()
    //     0x8ab8f0: bl              #0x8a8890  ; AllocateThemeDataStub -> ThemeData (size=0x154)
    // 0x8ab8f4: ldur            x1, [fp, #-0x50]
    // 0x8ab8f8: StoreField: r0->field_13 = r1
    //     0x8ab8f8: stur            w1, [x0, #0x13]
    // 0x8ab8fc: ldur            x1, [fp, #-8]
    // 0x8ab900: StoreField: r0->field_7 = r1
    //     0x8ab900: stur            w1, [x0, #7]
    // 0x8ab904: ldur            x1, [fp, #-0x58]
    // 0x8ab908: StoreField: r0->field_f = r1
    //     0x8ab908: stur            w1, [x0, #0xf]
    // 0x8ab90c: ldur            x1, [fp, #-0x28]
    // 0x8ab910: ArrayStore: r0[0] = r1  ; List_4
    //     0x8ab910: stur            w1, [x0, #0x17]
    // 0x8ab914: r1 = Instance_MaterialTapTargetSize
    //     0x8ab914: add             x1, PP, #0x12, lsl #12  ; [pp+0x12cb0] Obj!MaterialTapTargetSize@12c4b81
    //     0x8ab918: ldr             x1, [x1, #0xcb0]
    // 0x8ab91c: StoreField: r0->field_1b = r1
    //     0x8ab91c: stur            w1, [x0, #0x1b]
    // 0x8ab920: r1 = Instance_PageTransitionsTheme
    //     0x8ab920: add             x1, PP, #0x12, lsl #12  ; [pp+0x12938] Obj!PageTransitionsTheme@12b2a31
    //     0x8ab924: ldr             x1, [x1, #0x938]
    // 0x8ab928: StoreField: r0->field_1f = r1
    //     0x8ab928: stur            w1, [x0, #0x1f]
    // 0x8ab92c: r1 = Instance_TargetPlatform
    //     0x8ab92c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12940] Obj!TargetPlatform@12c5e81
    //     0x8ab930: ldr             x1, [x1, #0x940]
    // 0x8ab934: StoreField: r0->field_23 = r1
    //     0x8ab934: stur            w1, [x0, #0x23]
    // 0x8ab938: r1 = Instance_ScrollbarThemeData
    //     0x8ab938: add             x1, PP, #0x12, lsl #12  ; [pp+0x12d18] Obj!ScrollbarThemeData@12b2931
    //     0x8ab93c: ldr             x1, [x1, #0xd18]
    // 0x8ab940: StoreField: r0->field_27 = r1
    //     0x8ab940: stur            w1, [x0, #0x27]
    // 0x8ab944: ldur            x1, [fp, #-0x88]
    // 0x8ab948: StoreField: r0->field_2b = r1
    //     0x8ab948: stur            w1, [x0, #0x2b]
    // 0x8ab94c: ldur            x1, [fp, #-0x90]
    // 0x8ab950: StoreField: r0->field_2f = r1
    //     0x8ab950: stur            w1, [x0, #0x2f]
    // 0x8ab954: ldur            x1, [fp, #-0x98]
    // 0x8ab958: StoreField: r0->field_33 = r1
    //     0x8ab958: stur            w1, [x0, #0x33]
    // 0x8ab95c: ldur            x1, [fp, #-0x60]
    // 0x8ab960: StoreField: r0->field_3f = r1
    //     0x8ab960: stur            w1, [x0, #0x3f]
    // 0x8ab964: ldur            x1, [fp, #-0xd0]
    // 0x8ab968: StoreField: r0->field_37 = r1
    //     0x8ab968: stur            w1, [x0, #0x37]
    // 0x8ab96c: ldur            x1, [fp, #-0x70]
    // 0x8ab970: StoreField: r0->field_3b = r1
    //     0x8ab970: stur            w1, [x0, #0x3b]
    // 0x8ab974: ldur            x1, [fp, #-0xf0]
    // 0x8ab978: StoreField: r0->field_43 = r1
    //     0x8ab978: stur            w1, [x0, #0x43]
    // 0x8ab97c: ldur            x1, [fp, #-0x20]
    // 0x8ab980: StoreField: r0->field_47 = r1
    //     0x8ab980: stur            w1, [x0, #0x47]
    // 0x8ab984: ldur            x1, [fp, #-0xa8]
    // 0x8ab988: StoreField: r0->field_4b = r1
    //     0x8ab988: stur            w1, [x0, #0x4b]
    // 0x8ab98c: ldur            x1, [fp, #-0xe8]
    // 0x8ab990: StoreField: r0->field_4f = r1
    //     0x8ab990: stur            w1, [x0, #0x4f]
    // 0x8ab994: ldur            x1, [fp, #-0xd8]
    // 0x8ab998: StoreField: r0->field_53 = r1
    //     0x8ab998: stur            w1, [x0, #0x53]
    // 0x8ab99c: ldur            x1, [fp, #-0xc8]
    // 0x8ab9a0: StoreField: r0->field_57 = r1
    //     0x8ab9a0: stur            w1, [x0, #0x57]
    // 0x8ab9a4: ldur            x1, [fp, #-0xa0]
    // 0x8ab9a8: StoreField: r0->field_5b = r1
    //     0x8ab9a8: stur            w1, [x0, #0x5b]
    // 0x8ab9ac: ldur            x1, [fp, #-0xc0]
    // 0x8ab9b0: StoreField: r0->field_5f = r1
    //     0x8ab9b0: stur            w1, [x0, #0x5f]
    // 0x8ab9b4: ldur            x1, [fp, #-0xb0]
    // 0x8ab9b8: StoreField: r0->field_63 = r1
    //     0x8ab9b8: stur            w1, [x0, #0x63]
    // 0x8ab9bc: ldur            x1, [fp, #-0x18]
    // 0x8ab9c0: StoreField: r0->field_67 = r1
    //     0x8ab9c0: stur            w1, [x0, #0x67]
    // 0x8ab9c4: ldur            x1, [fp, #-0x80]
    // 0x8ab9c8: StoreField: r0->field_6b = r1
    //     0x8ab9c8: stur            w1, [x0, #0x6b]
    // 0x8ab9cc: r1 = Instance_Color
    //     0x8ab9cc: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x8ab9d0: ldr             x1, [x1, #0x948]
    // 0x8ab9d4: StoreField: r0->field_6f = r1
    //     0x8ab9d4: stur            w1, [x0, #0x6f]
    // 0x8ab9d8: ldur            x1, [fp, #-0xe0]
    // 0x8ab9dc: StoreField: r0->field_73 = r1
    //     0x8ab9dc: stur            w1, [x0, #0x73]
    // 0x8ab9e0: ldur            x1, [fp, #-0x38]
    // 0x8ab9e4: StoreField: r0->field_77 = r1
    //     0x8ab9e4: stur            w1, [x0, #0x77]
    // 0x8ab9e8: r17 = -280
    //     0x8ab9e8: mov             x17, #-0x118
    // 0x8ab9ec: ldr             x1, [fp, x17]
    // 0x8ab9f0: StoreField: r0->field_7b = r1
    //     0x8ab9f0: stur            w1, [x0, #0x7b]
    // 0x8ab9f4: ldur            x1, [fp, #-0xb8]
    // 0x8ab9f8: StoreField: r0->field_7f = r1
    //     0x8ab9f8: stur            w1, [x0, #0x7f]
    // 0x8ab9fc: r17 = -272
    //     0x8ab9fc: mov             x17, #-0x110
    // 0x8aba00: ldr             x1, [fp, x17]
    // 0x8aba04: StoreField: r0->field_83 = r1
    //     0x8aba04: stur            w1, [x0, #0x83]
    // 0x8aba08: ldur            x1, [fp, #-0x100]
    // 0x8aba0c: StoreField: r0->field_87 = r1
    //     0x8aba0c: stur            w1, [x0, #0x87]
    // 0x8aba10: r17 = -264
    //     0x8aba10: mov             x17, #-0x108
    // 0x8aba14: ldr             x1, [fp, x17]
    // 0x8aba18: StoreField: r0->field_8b = r1
    //     0x8aba18: stur            w1, [x0, #0x8b]
    // 0x8aba1c: ldur            x1, [fp, #-0x48]
    // 0x8aba20: StoreField: r0->field_93 = r1
    //     0x8aba20: stur            w1, [x0, #0x93]
    // 0x8aba24: r1 = Instance_BadgeThemeData
    //     0x8aba24: add             x1, PP, #0x12, lsl #12  ; [pp+0x12d20] Obj!BadgeThemeData@12b3391
    //     0x8aba28: ldr             x1, [x1, #0xd20]
    // 0x8aba2c: StoreField: r0->field_97 = r1
    //     0x8aba2c: stur            w1, [x0, #0x97]
    // 0x8aba30: r1 = Instance_MaterialBannerThemeData
    //     0x8aba30: add             x1, PP, #0x12, lsl #12  ; [pp+0x12d28] Obj!MaterialBannerThemeData@12b3361
    //     0x8aba34: ldr             x1, [x1, #0xd28]
    // 0x8aba38: StoreField: r0->field_9b = r1
    //     0x8aba38: stur            w1, [x0, #0x9b]
    // 0x8aba3c: r1 = Instance_BottomAppBarThemeData
    //     0x8aba3c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12d30] Obj!BottomAppBarThemeData@12b3331
    //     0x8aba40: ldr             x1, [x1, #0xd30]
    // 0x8aba44: StoreField: r0->field_9f = r1
    //     0x8aba44: stur            w1, [x0, #0x9f]
    // 0x8aba48: r1 = Instance_BottomNavigationBarThemeData
    //     0x8aba48: add             x1, PP, #0x12, lsl #12  ; [pp+0x12d38] Obj!BottomNavigationBarThemeData@12b32f1
    //     0x8aba4c: ldr             x1, [x1, #0xd38]
    // 0x8aba50: StoreField: r0->field_a3 = r1
    //     0x8aba50: stur            w1, [x0, #0xa3]
    // 0x8aba54: r1 = Instance_BottomSheetThemeData
    //     0x8aba54: add             x1, PP, #0x12, lsl #12  ; [pp+0x12d40] Obj!BottomSheetThemeData@12b32b1
    //     0x8aba58: ldr             x1, [x1, #0xd40]
    // 0x8aba5c: StoreField: r0->field_a7 = r1
    //     0x8aba5c: stur            w1, [x0, #0xa7]
    // 0x8aba60: ldur            x1, [fp, #-0xf8]
    // 0x8aba64: StoreField: r0->field_ab = r1
    //     0x8aba64: stur            w1, [x0, #0xab]
    // 0x8aba68: r1 = Instance_CardThemeData
    //     0x8aba68: add             x1, PP, #0x12, lsl #12  ; [pp+0x12d48] Obj!CardThemeData@12b31d1
    //     0x8aba6c: ldr             x1, [x1, #0xd48]
    // 0x8aba70: StoreField: r0->field_af = r1
    //     0x8aba70: stur            w1, [x0, #0xaf]
    // 0x8aba74: r1 = Instance_CarouselViewThemeData
    //     0x8aba74: add             x1, PP, #0x12, lsl #12  ; [pp+0x12d50] Obj!CarouselViewThemeData@12b31b1
    //     0x8aba78: ldr             x1, [x1, #0xd50]
    // 0x8aba7c: StoreField: r0->field_b3 = r1
    //     0x8aba7c: stur            w1, [x0, #0xb3]
    // 0x8aba80: r1 = Instance_CheckboxThemeData
    //     0x8aba80: add             x1, PP, #0x12, lsl #12  ; [pp+0x12d58] Obj!CheckboxThemeData@12b3181
    //     0x8aba84: ldr             x1, [x1, #0xd58]
    // 0x8aba88: StoreField: r0->field_b7 = r1
    //     0x8aba88: stur            w1, [x0, #0xb7]
    // 0x8aba8c: r1 = Instance_ChipThemeData
    //     0x8aba8c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12d60] Obj!ChipThemeData@12b3111
    //     0x8aba90: ldr             x1, [x1, #0xd60]
    // 0x8aba94: StoreField: r0->field_bb = r1
    //     0x8aba94: stur            w1, [x0, #0xbb]
    // 0x8aba98: r1 = Instance_DataTableThemeData
    //     0x8aba98: add             x1, PP, #0x12, lsl #12  ; [pp+0x12d68] Obj!DataTableThemeData@12b2f21
    //     0x8aba9c: ldr             x1, [x1, #0xd68]
    // 0x8abaa0: StoreField: r0->field_bf = r1
    //     0x8abaa0: stur            w1, [x0, #0xbf]
    // 0x8abaa4: r1 = Instance_DatePickerThemeData
    //     0x8abaa4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12d70] Obj!DatePickerThemeData@12b2e71
    //     0x8abaa8: ldr             x1, [x1, #0xd70]
    // 0x8abaac: StoreField: r0->field_c3 = r1
    //     0x8abaac: stur            w1, [x0, #0xc3]
    // 0x8abab0: r1 = Instance_DialogThemeData
    //     0x8abab0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12d78] Obj!DialogThemeData@12b2e31
    //     0x8abab4: ldr             x1, [x1, #0xd78]
    // 0x8abab8: StoreField: r0->field_c7 = r1
    //     0x8abab8: stur            w1, [x0, #0xc7]
    // 0x8ababc: r1 = Instance_DividerThemeData
    //     0x8ababc: add             x1, PP, #0x12, lsl #12  ; [pp+0x12d80] Obj!DividerThemeData@12b2e11
    //     0x8abac0: ldr             x1, [x1, #0xd80]
    // 0x8abac4: StoreField: r0->field_cb = r1
    //     0x8abac4: stur            w1, [x0, #0xcb]
    // 0x8abac8: r1 = Instance_DrawerThemeData
    //     0x8abac8: add             x1, PP, #0x12, lsl #12  ; [pp+0x12d88] Obj!DrawerThemeData@12b2de1
    //     0x8abacc: ldr             x1, [x1, #0xd88]
    // 0x8abad0: StoreField: r0->field_cf = r1
    //     0x8abad0: stur            w1, [x0, #0xcf]
    // 0x8abad4: r1 = Instance_DropdownMenuThemeData
    //     0x8abad4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12d90] Obj!DropdownMenuThemeData@12b2dc1
    //     0x8abad8: ldr             x1, [x1, #0xd90]
    // 0x8abadc: StoreField: r0->field_d3 = r1
    //     0x8abadc: stur            w1, [x0, #0xd3]
    // 0x8abae0: r1 = Instance_ElevatedButtonThemeData
    //     0x8abae0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12d98] Obj!ElevatedButtonThemeData@12b2db1
    //     0x8abae4: ldr             x1, [x1, #0xd98]
    // 0x8abae8: StoreField: r0->field_d7 = r1
    //     0x8abae8: stur            w1, [x0, #0xd7]
    // 0x8abaec: r1 = Instance_ExpansionTileThemeData
    //     0x8abaec: add             x1, PP, #0x12, lsl #12  ; [pp+0x12da0] Obj!ExpansionTileThemeData@12b2d71
    //     0x8abaf0: ldr             x1, [x1, #0xda0]
    // 0x8abaf4: StoreField: r0->field_db = r1
    //     0x8abaf4: stur            w1, [x0, #0xdb]
    // 0x8abaf8: r1 = Instance_FilledButtonThemeData
    //     0x8abaf8: add             x1, PP, #0x12, lsl #12  ; [pp+0x12da8] Obj!FilledButtonThemeData@12b2d61
    //     0x8abafc: ldr             x1, [x1, #0xda8]
    // 0x8abb00: StoreField: r0->field_df = r1
    //     0x8abb00: stur            w1, [x0, #0xdf]
    // 0x8abb04: ldur            x1, [fp, #-0x30]
    // 0x8abb08: StoreField: r0->field_e3 = r1
    //     0x8abb08: stur            w1, [x0, #0xe3]
    // 0x8abb0c: r1 = Instance_IconButtonThemeData
    //     0x8abb0c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12db0] Obj!IconButtonThemeData@12b2c31
    //     0x8abb10: ldr             x1, [x1, #0xdb0]
    // 0x8abb14: StoreField: r0->field_e7 = r1
    //     0x8abb14: stur            w1, [x0, #0xe7]
    // 0x8abb18: r1 = Instance_ListTileThemeData
    //     0x8abb18: add             x1, PP, #0x12, lsl #12  ; [pp+0x12db8] Obj!ListTileThemeData@12b2b31
    //     0x8abb1c: ldr             x1, [x1, #0xdb8]
    // 0x8abb20: StoreField: r0->field_eb = r1
    //     0x8abb20: stur            w1, [x0, #0xeb]
    // 0x8abb24: r1 = Instance_MenuBarThemeData
    //     0x8abb24: add             x1, PP, #0x12, lsl #12  ; [pp+0x12dc0] Obj!MenuBarThemeData@12b2b21
    //     0x8abb28: ldr             x1, [x1, #0xdc0]
    // 0x8abb2c: StoreField: r0->field_ef = r1
    //     0x8abb2c: stur            w1, [x0, #0xef]
    // 0x8abb30: r1 = Instance_MenuButtonThemeData
    //     0x8abb30: add             x1, PP, #0x12, lsl #12  ; [pp+0x12dc8] Obj!MenuButtonThemeData@12b2b01
    //     0x8abb34: ldr             x1, [x1, #0xdc8]
    // 0x8abb38: StoreField: r0->field_f3 = r1
    //     0x8abb38: stur            w1, [x0, #0xf3]
    // 0x8abb3c: r1 = Instance_MenuThemeData
    //     0x8abb3c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12dd0] Obj!MenuThemeData@12b2b11
    //     0x8abb40: ldr             x1, [x1, #0xdd0]
    // 0x8abb44: StoreField: r0->field_f7 = r1
    //     0x8abb44: stur            w1, [x0, #0xf7]
    // 0x8abb48: r1 = Instance_NavigationBarThemeData
    //     0x8abb48: add             x1, PP, #0x12, lsl #12  ; [pp+0x12dd8] Obj!NavigationBarThemeData@12b2ac1
    //     0x8abb4c: ldr             x1, [x1, #0xdd8]
    // 0x8abb50: StoreField: r0->field_fb = r1
    //     0x8abb50: stur            w1, [x0, #0xfb]
    // 0x8abb54: r1 = Instance_NavigationDrawerThemeData
    //     0x8abb54: add             x1, PP, #0x12, lsl #12  ; [pp+0x12de0] Obj!NavigationDrawerThemeData@12b2a91
    //     0x8abb58: ldr             x1, [x1, #0xde0]
    // 0x8abb5c: StoreField: r0->field_ff = r1
    //     0x8abb5c: stur            w1, [x0, #0xff]
    // 0x8abb60: r1 = Instance_NavigationRailThemeData
    //     0x8abb60: add             x1, PP, #0x12, lsl #12  ; [pp+0x12de8] Obj!NavigationRailThemeData@12b2a51
    //     0x8abb64: ldr             x1, [x1, #0xde8]
    // 0x8abb68: r17 = 259
    //     0x8abb68: mov             x17, #0x103
    // 0x8abb6c: str             w1, [x0, x17]
    // 0x8abb70: r1 = Instance_OutlinedButtonThemeData
    //     0x8abb70: add             x1, PP, #0x12, lsl #12  ; [pp+0x12df0] Obj!OutlinedButtonThemeData@12b2a41
    //     0x8abb74: ldr             x1, [x1, #0xdf0]
    // 0x8abb78: r17 = 263
    //     0x8abb78: mov             x17, #0x107
    // 0x8abb7c: str             w1, [x0, x17]
    // 0x8abb80: r1 = Instance_PopupMenuThemeData
    //     0x8abb80: add             x1, PP, #0x12, lsl #12  ; [pp+0x12df8] Obj!PopupMenuThemeData@12b29f1
    //     0x8abb84: ldr             x1, [x1, #0xdf8]
    // 0x8abb88: r17 = 267
    //     0x8abb88: mov             x17, #0x10b
    // 0x8abb8c: str             w1, [x0, x17]
    // 0x8abb90: r1 = Instance_ProgressIndicatorThemeData
    //     0x8abb90: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e00] Obj!ProgressIndicatorThemeData@12b29a1
    //     0x8abb94: ldr             x1, [x1, #0xe00]
    // 0x8abb98: r17 = 271
    //     0x8abb98: mov             x17, #0x10f
    // 0x8abb9c: str             w1, [x0, x17]
    // 0x8abba0: r1 = Instance_RadioThemeData
    //     0x8abba0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e08] Obj!RadioThemeData@12b2971
    //     0x8abba4: ldr             x1, [x1, #0xe08]
    // 0x8abba8: r17 = 275
    //     0x8abba8: mov             x17, #0x113
    // 0x8abbac: str             w1, [x0, x17]
    // 0x8abbb0: r1 = Instance_SearchBarThemeData
    //     0x8abbb0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e10] Obj!SearchBarThemeData@12b28f1
    //     0x8abbb4: ldr             x1, [x1, #0xe10]
    // 0x8abbb8: r17 = 279
    //     0x8abbb8: mov             x17, #0x117
    // 0x8abbbc: str             w1, [x0, x17]
    // 0x8abbc0: r1 = Instance_SearchViewThemeData
    //     0x8abbc0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e18] Obj!SearchViewThemeData@12b28b1
    //     0x8abbc4: ldr             x1, [x1, #0xe18]
    // 0x8abbc8: r17 = 283
    //     0x8abbc8: mov             x17, #0x11b
    // 0x8abbcc: str             w1, [x0, x17]
    // 0x8abbd0: r1 = Instance_SegmentedButtonThemeData
    //     0x8abbd0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e20] Obj!SegmentedButtonThemeData@12b28a1
    //     0x8abbd4: ldr             x1, [x1, #0xe20]
    // 0x8abbd8: r17 = 287
    //     0x8abbd8: mov             x17, #0x11f
    // 0x8abbdc: str             w1, [x0, x17]
    // 0x8abbe0: r1 = Instance_SliderThemeData
    //     0x8abbe0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e28] Obj!SliderThemeData@12b2121
    //     0x8abbe4: ldr             x1, [x1, #0xe28]
    // 0x8abbe8: r17 = 291
    //     0x8abbe8: mov             x17, #0x123
    // 0x8abbec: str             w1, [x0, x17]
    // 0x8abbf0: r1 = Instance_SnackBarThemeData
    //     0x8abbf0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e30] Obj!SnackBarThemeData@12b20d1
    //     0x8abbf4: ldr             x1, [x1, #0xe30]
    // 0x8abbf8: r17 = 295
    //     0x8abbf8: mov             x17, #0x127
    // 0x8abbfc: str             w1, [x0, x17]
    // 0x8abc00: r1 = Instance_SwitchThemeData
    //     0x8abc00: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e38] Obj!SwitchThemeData@12b20a1
    //     0x8abc04: ldr             x1, [x1, #0xe38]
    // 0x8abc08: r17 = 299
    //     0x8abc08: mov             x17, #0x12b
    // 0x8abc0c: str             w1, [x0, x17]
    // 0x8abc10: ldur            x1, [fp, #-0x10]
    // 0x8abc14: r17 = 303
    //     0x8abc14: mov             x17, #0x12f
    // 0x8abc18: str             w1, [x0, x17]
    // 0x8abc1c: r1 = Instance_TextButtonThemeData
    //     0x8abc1c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e40] Obj!TextButtonThemeData@12b2041
    //     0x8abc20: ldr             x1, [x1, #0xe40]
    // 0x8abc24: r17 = 307
    //     0x8abc24: mov             x17, #0x133
    // 0x8abc28: str             w1, [x0, x17]
    // 0x8abc2c: r1 = Instance_TextSelectionThemeData
    //     0x8abc2c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e48] Obj!TextSelectionThemeData@12b2021
    //     0x8abc30: ldr             x1, [x1, #0xe48]
    // 0x8abc34: r17 = 311
    //     0x8abc34: mov             x17, #0x137
    // 0x8abc38: str             w1, [x0, x17]
    // 0x8abc3c: r1 = Instance_TimePickerThemeData
    //     0x8abc3c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e50] Obj!TimePickerThemeData@12b1cf1
    //     0x8abc40: ldr             x1, [x1, #0xe50]
    // 0x8abc44: r17 = 315
    //     0x8abc44: mov             x17, #0x13b
    // 0x8abc48: str             w1, [x0, x17]
    // 0x8abc4c: r1 = Instance_ToggleButtonsThemeData
    //     0x8abc4c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e58] Obj!ToggleButtonsThemeData@12b1ca1
    //     0x8abc50: ldr             x1, [x1, #0xe58]
    // 0x8abc54: r17 = 319
    //     0x8abc54: mov             x17, #0x13f
    // 0x8abc58: str             w1, [x0, x17]
    // 0x8abc5c: r1 = Instance_TooltipThemeData
    //     0x8abc5c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e60] Obj!TooltipThemeData@12b1c51
    //     0x8abc60: ldr             x1, [x1, #0xe60]
    // 0x8abc64: r17 = 323
    //     0x8abc64: mov             x17, #0x143
    // 0x8abc68: str             w1, [x0, x17]
    // 0x8abc6c: ldur            x1, [fp, #-0x78]
    // 0x8abc70: r17 = 331
    //     0x8abc70: mov             x17, #0x14b
    // 0x8abc74: str             w1, [x0, x17]
    // 0x8abc78: ldur            x1, [fp, #-0x40]
    // 0x8abc7c: r17 = 335
    //     0x8abc7c: mov             x17, #0x14f
    // 0x8abc80: str             w1, [x0, x17]
    // 0x8abc84: r1 = Instance_ButtonBarThemeData
    //     0x8abc84: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e68] Obj!ButtonBarThemeData@12b3281
    //     0x8abc88: ldr             x1, [x1, #0xe68]
    // 0x8abc8c: r17 = 327
    //     0x8abc8c: mov             x17, #0x147
    // 0x8abc90: str             w1, [x0, x17]
    // 0x8abc94: LeaveFrame
    //     0x8abc94: mov             SP, fp
    //     0x8abc98: ldp             fp, lr, [SP], #0x10
    // 0x8abc9c: ret
    //     0x8abc9c: ret             
    // 0x8abca0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8abca0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8abca4: b               #0x8aaed8
    // 0x8abca8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8abca8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8abcac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8abcac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8abcb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8abcb0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8abcb4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8abcb4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8abcb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8abcb8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8abcbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8abcbc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8abcc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8abcc0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8abcc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8abcc4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8abcc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8abcc8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8abccc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8abccc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8abcd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8abcd0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8abcd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8abcd4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8abcd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8abcd8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8abcdc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8abcdc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8abce0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8abce0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8abce4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8abce4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ _themeExtensionIterableToMap(/* No info */) {
    // ** addr: 0x8abe00, size: 0x16c
    // 0x8abe00: EnterFrame
    //     0x8abe00: stp             fp, lr, [SP, #-0x10]!
    //     0x8abe04: mov             fp, SP
    // 0x8abe08: AllocStack(0x40)
    //     0x8abe08: sub             SP, SP, #0x40
    // 0x8abe0c: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0x8abe0c: stur            x1, [fp, #-8]
    // 0x8abe10: CheckStackOverflow
    //     0x8abe10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8abe14: cmp             SP, x16
    //     0x8abe18: b.ls            #0x8abf5c
    // 0x8abe1c: r16 = <Object, ThemeExtension<ThemeExtension>>
    //     0x8abe1c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12e70] TypeArguments: <Object, ThemeExtension<ThemeExtension>>
    //     0x8abe20: ldr             x16, [x16, #0xe70]
    // 0x8abe24: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x8abe28: stp             lr, x16, [SP]
    // 0x8abe2c: r0 = Map._fromLiteral()
    //     0x8abe2c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8abe30: mov             x3, x0
    // 0x8abe34: ldur            x0, [fp, #-8]
    // 0x8abe38: stur            x3, [fp, #-0x28]
    // 0x8abe3c: LoadField: r1 = r0->field_b
    //     0x8abe3c: ldur            w1, [x0, #0xb]
    // 0x8abe40: r4 = LoadInt32Instr(r1)
    //     0x8abe40: sbfx            x4, x1, #1, #0x1f
    // 0x8abe44: stur            x4, [fp, #-0x20]
    // 0x8abe48: r1 = 0
    //     0x8abe48: mov             x1, #0
    // 0x8abe4c: CheckStackOverflow
    //     0x8abe4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8abe50: cmp             SP, x16
    //     0x8abe54: b.ls            #0x8abf64
    // 0x8abe58: LoadField: r2 = r0->field_b
    //     0x8abe58: ldur            w2, [x0, #0xb]
    // 0x8abe5c: r5 = LoadInt32Instr(r2)
    //     0x8abe5c: sbfx            x5, x2, #1, #0x1f
    // 0x8abe60: cmp             x4, x5
    // 0x8abe64: b.ne            #0x8abf40
    // 0x8abe68: cmp             x1, x5
    // 0x8abe6c: b.ge            #0x8abf04
    // 0x8abe70: LoadField: r2 = r0->field_f
    //     0x8abe70: ldur            w2, [x0, #0xf]
    // 0x8abe74: DecompressPointer r2
    //     0x8abe74: add             x2, x2, HEAP, lsl #32
    // 0x8abe78: ArrayLoad: r5 = r2[r1]  ; Unknown_4
    //     0x8abe78: add             x16, x2, x1, lsl #2
    //     0x8abe7c: ldur            w5, [x16, #0xf]
    // 0x8abe80: DecompressPointer r5
    //     0x8abe80: add             x5, x5, HEAP, lsl #32
    // 0x8abe84: stur            x5, [fp, #-0x18]
    // 0x8abe88: add             x6, x1, #1
    // 0x8abe8c: stur            x6, [fp, #-0x10]
    // 0x8abe90: LoadField: r2 = r5->field_7
    //     0x8abe90: ldur            w2, [x5, #7]
    // 0x8abe94: DecompressPointer r2
    //     0x8abe94: add             x2, x2, HEAP, lsl #32
    // 0x8abe98: r1 = Null
    //     0x8abe98: mov             x1, NULL
    // 0x8abe9c: r3 = X0 bound ThemeExtension
    //     0x8abe9c: add             x3, PP, #0x12, lsl #12  ; [pp+0x12e78] TypeParameter: X0 bound ThemeExtension
    //     0x8abea0: ldr             x3, [x3, #0xe78]
    // 0x8abea4: r30 = InstantiateTypeNonNullableClassTypeParameterStub
    //     0x8abea4: add             lr, PP, #0x12, lsl #12  ; [pp+0x12e80] Stub: InstantiateTypeNonNullableClassTypeParameter (0x7c1258)
    //     0x8abea8: ldr             lr, [lr, #0xe80]
    // 0x8abeac: LoadField: r30 = r30->field_7
    //     0x8abeac: ldur            lr, [lr, #7]
    // 0x8abeb0: blr             lr
    // 0x8abeb4: ldur            x1, [fp, #-0x28]
    // 0x8abeb8: mov             x2, x0
    // 0x8abebc: stur            x0, [fp, #-0x30]
    // 0x8abec0: r0 = _hashCode()
    //     0x8abec0: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x8abec4: mov             x2, x0
    // 0x8abec8: r0 = BoxInt64Instr(r2)
    //     0x8abec8: sbfiz           x0, x2, #1, #0x1f
    //     0x8abecc: cmp             x2, x0, asr #1
    //     0x8abed0: b.eq            #0x8abedc
    //     0x8abed4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8abed8: stur            x2, [x0, #7]
    // 0x8abedc: ldur            x1, [fp, #-0x28]
    // 0x8abee0: ldur            x2, [fp, #-0x30]
    // 0x8abee4: ldur            x3, [fp, #-0x18]
    // 0x8abee8: mov             x5, x0
    // 0x8abeec: r0 = _set()
    //     0x8abeec: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x8abef0: ldur            x1, [fp, #-0x10]
    // 0x8abef4: ldur            x0, [fp, #-8]
    // 0x8abef8: ldur            x3, [fp, #-0x28]
    // 0x8abefc: ldur            x4, [fp, #-0x20]
    // 0x8abf00: b               #0x8abe4c
    // 0x8abf04: ldur            x2, [fp, #-0x28]
    // 0x8abf08: r1 = <Object, ThemeExtension>
    //     0x8abf08: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e88] TypeArguments: <Object, ThemeExtension>
    //     0x8abf0c: ldr             x1, [x1, #0xe88]
    // 0x8abf10: r0 = LinkedHashMap.from()
    //     0x8abf10: bl              #0x8ac2e4  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x8abf14: r1 = <Object, ThemeExtension>
    //     0x8abf14: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e88] TypeArguments: <Object, ThemeExtension>
    //     0x8abf18: ldr             x1, [x1, #0xe88]
    // 0x8abf1c: stur            x0, [fp, #-0x18]
    // 0x8abf20: r0 = UnmodifiableMapView()
    //     0x8abf20: bl              #0x8abfbc  ; AllocateUnmodifiableMapViewStub -> UnmodifiableMapView<X0, X1> (size=0x10)
    // 0x8abf24: mov             x1, x0
    // 0x8abf28: ldur            x0, [fp, #-0x18]
    // 0x8abf2c: StoreField: r1->field_b = r0
    //     0x8abf2c: stur            w0, [x1, #0xb]
    // 0x8abf30: mov             x0, x1
    // 0x8abf34: LeaveFrame
    //     0x8abf34: mov             SP, fp
    //     0x8abf38: ldp             fp, lr, [SP], #0x10
    // 0x8abf3c: ret
    //     0x8abf3c: ret             
    // 0x8abf40: r0 = ConcurrentModificationError()
    //     0x8abf40: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x8abf44: mov             x1, x0
    // 0x8abf48: ldur            x0, [fp, #-8]
    // 0x8abf4c: StoreField: r1->field_b = r0
    //     0x8abf4c: stur            w0, [x1, #0xb]
    // 0x8abf50: mov             x0, x1
    // 0x8abf54: r0 = Throw()
    //     0x8abf54: bl              #0x13ddb2c  ; ThrowStub
    // 0x8abf58: brk             #0
    // 0x8abf5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8abf5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8abf60: b               #0x8abe1c
    // 0x8abf64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8abf64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8abf68: b               #0x8abe58
  }
  static _ _createAdaptationMap(/* No info */) {
    // ** addr: 0x8ac530, size: 0x13c
    // 0x8ac530: EnterFrame
    //     0x8ac530: stp             fp, lr, [SP, #-0x10]!
    //     0x8ac534: mov             fp, SP
    // 0x8ac538: AllocStack(0x40)
    //     0x8ac538: sub             SP, SP, #0x40
    // 0x8ac53c: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0x8ac53c: stur            x1, [fp, #-8]
    // 0x8ac540: CheckStackOverflow
    //     0x8ac540: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ac544: cmp             SP, x16
    //     0x8ac548: b.ls            #0x8ac65c
    // 0x8ac54c: r16 = <Type, Adaptation<Object>>
    //     0x8ac54c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12e90] TypeArguments: <Type, Adaptation<Object>>
    //     0x8ac550: ldr             x16, [x16, #0xe90]
    // 0x8ac554: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x8ac558: stp             lr, x16, [SP]
    // 0x8ac55c: r0 = Map._fromLiteral()
    //     0x8ac55c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8ac560: mov             x3, x0
    // 0x8ac564: ldur            x0, [fp, #-8]
    // 0x8ac568: stur            x3, [fp, #-0x28]
    // 0x8ac56c: LoadField: r1 = r0->field_b
    //     0x8ac56c: ldur            w1, [x0, #0xb]
    // 0x8ac570: r4 = LoadInt32Instr(r1)
    //     0x8ac570: sbfx            x4, x1, #1, #0x1f
    // 0x8ac574: stur            x4, [fp, #-0x20]
    // 0x8ac578: r1 = 0
    //     0x8ac578: mov             x1, #0
    // 0x8ac57c: CheckStackOverflow
    //     0x8ac57c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ac580: cmp             SP, x16
    //     0x8ac584: b.ls            #0x8ac664
    // 0x8ac588: LoadField: r2 = r0->field_b
    //     0x8ac588: ldur            w2, [x0, #0xb]
    // 0x8ac58c: r5 = LoadInt32Instr(r2)
    //     0x8ac58c: sbfx            x5, x2, #1, #0x1f
    // 0x8ac590: cmp             x4, x5
    // 0x8ac594: b.ne            #0x8ac640
    // 0x8ac598: cmp             x1, x5
    // 0x8ac59c: b.ge            #0x8ac630
    // 0x8ac5a0: LoadField: r2 = r0->field_f
    //     0x8ac5a0: ldur            w2, [x0, #0xf]
    // 0x8ac5a4: DecompressPointer r2
    //     0x8ac5a4: add             x2, x2, HEAP, lsl #32
    // 0x8ac5a8: ArrayLoad: r5 = r2[r1]  ; Unknown_4
    //     0x8ac5a8: add             x16, x2, x1, lsl #2
    //     0x8ac5ac: ldur            w5, [x16, #0xf]
    // 0x8ac5b0: DecompressPointer r5
    //     0x8ac5b0: add             x5, x5, HEAP, lsl #32
    // 0x8ac5b4: stur            x5, [fp, #-0x18]
    // 0x8ac5b8: add             x6, x1, #1
    // 0x8ac5bc: stur            x6, [fp, #-0x10]
    // 0x8ac5c0: LoadField: r2 = r5->field_7
    //     0x8ac5c0: ldur            w2, [x5, #7]
    // 0x8ac5c4: DecompressPointer r2
    //     0x8ac5c4: add             x2, x2, HEAP, lsl #32
    // 0x8ac5c8: r1 = Null
    //     0x8ac5c8: mov             x1, NULL
    // 0x8ac5cc: r3 = X0
    //     0x8ac5cc: ldr             x3, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x8ac5d0: r30 = InstantiateTypeNonNullableClassTypeParameterStub
    //     0x8ac5d0: add             lr, PP, #0x12, lsl #12  ; [pp+0x12e80] Stub: InstantiateTypeNonNullableClassTypeParameter (0x7c1258)
    //     0x8ac5d4: ldr             lr, [lr, #0xe80]
    // 0x8ac5d8: LoadField: r30 = r30->field_7
    //     0x8ac5d8: ldur            lr, [lr, #7]
    // 0x8ac5dc: blr             lr
    // 0x8ac5e0: ldur            x1, [fp, #-0x28]
    // 0x8ac5e4: mov             x2, x0
    // 0x8ac5e8: stur            x0, [fp, #-0x30]
    // 0x8ac5ec: r0 = _hashCode()
    //     0x8ac5ec: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x8ac5f0: mov             x2, x0
    // 0x8ac5f4: r0 = BoxInt64Instr(r2)
    //     0x8ac5f4: sbfiz           x0, x2, #1, #0x1f
    //     0x8ac5f8: cmp             x2, x0, asr #1
    //     0x8ac5fc: b.eq            #0x8ac608
    //     0x8ac600: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8ac604: stur            x2, [x0, #7]
    // 0x8ac608: ldur            x1, [fp, #-0x28]
    // 0x8ac60c: ldur            x2, [fp, #-0x30]
    // 0x8ac610: ldur            x3, [fp, #-0x18]
    // 0x8ac614: mov             x5, x0
    // 0x8ac618: r0 = _set()
    //     0x8ac618: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x8ac61c: ldur            x1, [fp, #-0x10]
    // 0x8ac620: ldur            x0, [fp, #-8]
    // 0x8ac624: ldur            x3, [fp, #-0x28]
    // 0x8ac628: ldur            x4, [fp, #-0x20]
    // 0x8ac62c: b               #0x8ac57c
    // 0x8ac630: ldur            x0, [fp, #-0x28]
    // 0x8ac634: LeaveFrame
    //     0x8ac634: mov             SP, fp
    //     0x8ac638: ldp             fp, lr, [SP], #0x10
    // 0x8ac63c: ret
    //     0x8ac63c: ret             
    // 0x8ac640: r0 = ConcurrentModificationError()
    //     0x8ac640: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x8ac644: mov             x1, x0
    // 0x8ac648: ldur            x0, [fp, #-8]
    // 0x8ac64c: StoreField: r1->field_b = r0
    //     0x8ac64c: stur            w0, [x1, #0xb]
    // 0x8ac650: mov             x0, x1
    // 0x8ac654: r0 = Throw()
    //     0x8ac654: bl              #0x13ddb2c  ; ThrowStub
    // 0x8ac658: brk             #0
    // 0x8ac65c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ac65c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ac660: b               #0x8ac54c
    // 0x8ac664: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ac664: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ac668: b               #0x8ac588
  }
  static _ estimateBrightnessForColor(/* No info */) {
    // ** addr: 0x8ad774, size: 0x74
    // 0x8ad774: EnterFrame
    //     0x8ad774: stp             fp, lr, [SP, #-0x10]!
    //     0x8ad778: mov             fp, SP
    // 0x8ad77c: CheckStackOverflow
    //     0x8ad77c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ad780: cmp             SP, x16
    //     0x8ad784: b.ls            #0x8ad7e0
    // 0x8ad788: r0 = LoadClassIdInstr(r1)
    //     0x8ad788: ldur            x0, [x1, #-1]
    //     0x8ad78c: ubfx            x0, x0, #0xc, #0x14
    // 0x8ad790: r0 = GDT[cid_x0 + 0x2763]()
    //     0x8ad790: mov             x17, #0x2763
    //     0x8ad794: add             lr, x0, x17
    //     0x8ad798: ldr             lr, [x21, lr, lsl #3]
    //     0x8ad79c: blr             lr
    // 0x8ad7a0: mov             v1.16b, v0.16b
    // 0x8ad7a4: d0 = 0.050000
    //     0x8ad7a4: ldr             d0, [PP, #0x57a0]  ; [pp+0x57a0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x8ad7a8: fadd            d2, d1, d0
    // 0x8ad7ac: fmul            d0, d2, d2
    // 0x8ad7b0: d1 = 0.150000
    //     0x8ad7b0: add             x17, PP, #0x12, lsl #12  ; [pp+0x12ee8] IMM: double(0.15) from 0x3fc3333333333333
    //     0x8ad7b4: ldr             d1, [x17, #0xee8]
    // 0x8ad7b8: fcmp            d0, d1
    // 0x8ad7bc: b.le            #0x8ad7d0
    // 0x8ad7c0: r0 = Instance_Brightness
    //     0x8ad7c0: ldr             x0, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0x8ad7c4: LeaveFrame
    //     0x8ad7c4: mov             SP, fp
    //     0x8ad7c8: ldp             fp, lr, [SP], #0x10
    // 0x8ad7cc: ret
    //     0x8ad7cc: ret             
    // 0x8ad7d0: r0 = Instance_Brightness
    //     0x8ad7d0: ldr             x0, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x8ad7d4: LeaveFrame
    //     0x8ad7d4: mov             SP, fp
    //     0x8ad7d8: ldp             fp, lr, [SP], #0x10
    // 0x8ad7dc: ret
    //     0x8ad7dc: ret             
    // 0x8ad7e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ad7e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ad7e4: b               #0x8ad788
  }
  factory ThemeData ThemeData.light(dynamic) {
    // ** addr: 0x8bdfdc, size: 0x44
    // 0x8bdfdc: EnterFrame
    //     0x8bdfdc: stp             fp, lr, [SP, #-0x10]!
    //     0x8bdfe0: mov             fp, SP
    // 0x8bdfe4: AllocStack(0x10)
    //     0x8bdfe4: sub             SP, SP, #0x10
    // 0x8bdfe8: CheckStackOverflow
    //     0x8bdfe8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bdfec: cmp             SP, x16
    //     0x8bdff0: b.ls            #0x8be018
    // 0x8bdff4: r16 = Instance_Brightness
    //     0x8bdff4: ldr             x16, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0x8bdff8: stp             NULL, x16, [SP]
    // 0x8bdffc: r1 = Null
    //     0x8bdffc: mov             x1, NULL
    // 0x8be000: r4 = const [0, 0x3, 0x2, 0x1, brightness, 0x1, useMaterial3, 0x2, null]
    //     0x8be000: add             x4, PP, #0x13, lsl #12  ; [pp+0x13a48] List(9) [0, 0x3, 0x2, 0x1, "brightness", 0x1, "useMaterial3", 0x2, Null]
    //     0x8be004: ldr             x4, [x4, #0xa48]
    // 0x8be008: r0 = ThemeData()
    //     0x8be008: bl              #0x8a9c18  ; [package:flutter/src/material/theme_data.dart] ThemeData::ThemeData
    // 0x8be00c: LeaveFrame
    //     0x8be00c: mov             SP, fp
    //     0x8be010: ldp             fp, lr, [SP], #0x10
    // 0x8be014: ret
    //     0x8be014: ret             
    // 0x8be018: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8be018: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8be01c: b               #0x8bdff4
  }
  Adaptation<Y0>? getAdaptation<Y0>(ThemeData) {
    // ** addr: 0xd42188, size: 0xd8
    // 0xd42188: EnterFrame
    //     0xd42188: stp             fp, lr, [SP, #-0x10]!
    //     0xd4218c: mov             fp, SP
    // 0xd42190: AllocStack(0x10)
    //     0xd42190: sub             SP, SP, #0x10
    // 0xd42194: SetupParameters([dynamic _ /* r0 */])
    //     0xd42194: ldur            w0, [x4, #0xf]
    //     0xd42198: cbnz            w0, #0xd421a4
    //     0xd4219c: mov             x3, NULL
    //     0xd421a0: b               #0xd421b4
    //     0xd421a4: ldur            w0, [x4, #0x17]
    //     0xd421a8: add             x1, fp, w0, sxtw #2
    //     0xd421ac: ldr             x1, [x1, #0x10]
    //     0xd421b0: mov             x3, x1
    //     0xd421b4: ldr             x0, [fp, #0x10]
    //     0xd421b8: stur            x3, [fp, #-0x10]
    // 0xd421bc: CheckStackOverflow
    //     0xd421bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd421c0: cmp             SP, x16
    //     0xd421c4: b.ls            #0xd42258
    // 0xd421c8: LoadField: r4 = r0->field_13
    //     0xd421c8: ldur            w4, [x0, #0x13]
    // 0xd421cc: DecompressPointer r4
    //     0xd421cc: add             x4, x4, HEAP, lsl #32
    // 0xd421d0: mov             x1, x3
    // 0xd421d4: stur            x4, [fp, #-8]
    // 0xd421d8: r2 = Null
    //     0xd421d8: mov             x2, NULL
    // 0xd421dc: r3 = Y0
    //     0xd421dc: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa36b0] TypeParameter: Y0
    //     0xd421e0: ldr             x3, [x3, #0x6b0]
    // 0xd421e4: r30 = InstantiateTypeNonNullableFunctionTypeParameterStub
    //     0xd421e4: ldr             lr, [PP, #0x1fe8]  ; [pp+0x1fe8] Stub: InstantiateTypeNonNullableFunctionTypeParameter (0x7c1180)
    // 0xd421e8: LoadField: r30 = r30->field_7
    //     0xd421e8: ldur            lr, [lr, #7]
    // 0xd421ec: blr             lr
    // 0xd421f0: ldur            x1, [fp, #-8]
    // 0xd421f4: mov             x2, x0
    // 0xd421f8: r0 = _getValueOrData()
    //     0xd421f8: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xd421fc: mov             x1, x0
    // 0xd42200: ldur            x0, [fp, #-8]
    // 0xd42204: LoadField: r2 = r0->field_f
    //     0xd42204: ldur            w2, [x0, #0xf]
    // 0xd42208: DecompressPointer r2
    //     0xd42208: add             x2, x2, HEAP, lsl #32
    // 0xd4220c: cmp             w2, w1
    // 0xd42210: b.ne            #0xd4221c
    // 0xd42214: r3 = Null
    //     0xd42214: mov             x3, NULL
    // 0xd42218: b               #0xd42220
    // 0xd4221c: mov             x3, x1
    // 0xd42220: mov             x0, x3
    // 0xd42224: ldur            x1, [fp, #-0x10]
    // 0xd42228: stur            x3, [fp, #-8]
    // 0xd4222c: r2 = Null
    //     0xd4222c: mov             x2, NULL
    // 0xd42230: r8 = Adaptation<Y0>?
    //     0xd42230: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa36b8] Type: Adaptation<Y0>?
    //     0xd42234: ldr             x8, [x8, #0x6b8]
    // 0xd42238: LoadField: r9 = r8->field_7
    //     0xd42238: ldur            x9, [x8, #7]
    // 0xd4223c: r3 = Null
    //     0xd4223c: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa36c0] Null
    //     0xd42240: ldr             x3, [x3, #0x6c0]
    // 0xd42244: blr             x9
    // 0xd42248: ldur            x0, [fp, #-8]
    // 0xd4224c: LeaveFrame
    //     0xd4224c: mov             SP, fp
    //     0xd42250: ldp             fp, lr, [SP], #0x10
    // 0xd42254: ret
    //     0xd42254: ret             
    // 0xd42258: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd42258: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4225c: b               #0xd421c8
  }
  factory ThemeData ThemeData.dark(dynamic) {
    // ** addr: 0xfbec20, size: 0x44
    // 0xfbec20: EnterFrame
    //     0xfbec20: stp             fp, lr, [SP, #-0x10]!
    //     0xfbec24: mov             fp, SP
    // 0xfbec28: AllocStack(0x10)
    //     0xfbec28: sub             SP, SP, #0x10
    // 0xfbec2c: CheckStackOverflow
    //     0xfbec2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbec30: cmp             SP, x16
    //     0xfbec34: b.ls            #0xfbec5c
    // 0xfbec38: r16 = Instance_Brightness
    //     0xfbec38: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xfbec3c: stp             NULL, x16, [SP]
    // 0xfbec40: r1 = Null
    //     0xfbec40: mov             x1, NULL
    // 0xfbec44: r4 = const [0, 0x3, 0x2, 0x1, brightness, 0x1, useMaterial3, 0x2, null]
    //     0xfbec44: add             x4, PP, #0x13, lsl #12  ; [pp+0x13a48] List(9) [0, 0x3, 0x2, 0x1, "brightness", 0x1, "useMaterial3", 0x2, Null]
    //     0xfbec48: ldr             x4, [x4, #0xa48]
    // 0xfbec4c: r0 = ThemeData()
    //     0xfbec4c: bl              #0x8a9c18  ; [package:flutter/src/material/theme_data.dart] ThemeData::ThemeData
    // 0xfbec50: LeaveFrame
    //     0xfbec50: mov             SP, fp
    //     0xfbec54: ldp             fp, lr, [SP], #0x10
    // 0xfbec58: ret
    //     0xfbec58: ret             
    // 0xfbec5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbec5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbec60: b               #0xfbec38
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x1138904, size: 0x265c
    // 0x1138904: EnterFrame
    //     0x1138904: stp             fp, lr, [SP, #-0x10]!
    //     0x1138908: mov             fp, SP
    // 0x113890c: AllocStack(0x20)
    //     0x113890c: sub             SP, SP, #0x20
    // 0x1138910: CheckStackOverflow
    //     0x1138910: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1138914: cmp             SP, x16
    //     0x1138918: b.ls            #0x113af58
    // 0x113891c: ldr             x0, [fp, #0x10]
    // 0x1138920: LoadField: r2 = r0->field_13
    //     0x1138920: ldur            w2, [x0, #0x13]
    // 0x1138924: DecompressPointer r2
    //     0x1138924: add             x2, x2, HEAP, lsl #32
    // 0x1138928: stur            x2, [fp, #-8]
    // 0x113892c: r1 = <Type, Adaptation<Object>>
    //     0x113892c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e90] TypeArguments: <Type, Adaptation<Object>>
    //     0x1138930: ldr             x1, [x1, #0xe90]
    // 0x1138934: r0 = _CompactKeysIterable()
    //     0x1138934: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0x1138938: mov             x1, x0
    // 0x113893c: ldur            x0, [fp, #-8]
    // 0x1138940: StoreField: r1->field_b = r0
    //     0x1138940: stur            w0, [x1, #0xb]
    // 0x1138944: mov             x2, x1
    // 0x1138948: r1 = <Object?>
    //     0x1138948: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x113894c: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x113894c: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x1138950: r1 = <Adaptation<Object>>
    //     0x1138950: add             x1, PP, #0x12, lsl #12  ; [pp+0x12bf0] TypeArguments: <Adaptation<Object>>
    //     0x1138954: ldr             x1, [x1, #0xbf0]
    // 0x1138958: stur            x0, [fp, #-0x10]
    // 0x113895c: r0 = _CompactValuesIterable()
    //     0x113895c: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0x1138960: mov             x1, x0
    // 0x1138964: ldur            x0, [fp, #-8]
    // 0x1138968: StoreField: r1->field_b = r0
    //     0x1138968: stur            w0, [x1, #0xb]
    // 0x113896c: mov             x2, x1
    // 0x1138970: ldur            x1, [fp, #-0x10]
    // 0x1138974: r0 = addAll()
    //     0x1138974: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x1138978: ldr             x0, [fp, #0x10]
    // 0x113897c: LoadField: r2 = r0->field_7
    //     0x113897c: ldur            w2, [x0, #7]
    // 0x1138980: DecompressPointer r2
    //     0x1138980: add             x2, x2, HEAP, lsl #32
    // 0x1138984: ldur            x3, [fp, #-0x10]
    // 0x1138988: stur            x2, [fp, #-8]
    // 0x113898c: LoadField: r1 = r3->field_b
    //     0x113898c: ldur            w1, [x3, #0xb]
    // 0x1138990: LoadField: r4 = r3->field_f
    //     0x1138990: ldur            w4, [x3, #0xf]
    // 0x1138994: DecompressPointer r4
    //     0x1138994: add             x4, x4, HEAP, lsl #32
    // 0x1138998: LoadField: r5 = r4->field_b
    //     0x1138998: ldur            w5, [x4, #0xb]
    // 0x113899c: r4 = LoadInt32Instr(r1)
    //     0x113899c: sbfx            x4, x1, #1, #0x1f
    // 0x11389a0: stur            x4, [fp, #-0x18]
    // 0x11389a4: r1 = LoadInt32Instr(r5)
    //     0x11389a4: sbfx            x1, x5, #1, #0x1f
    // 0x11389a8: cmp             x4, x1
    // 0x11389ac: b.ne            #0x11389b8
    // 0x11389b0: mov             x1, x3
    // 0x11389b4: r0 = _growToNextCapacity()
    //     0x11389b4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x11389b8: ldur            x0, [fp, #-8]
    // 0x11389bc: ldur            x2, [fp, #-0x10]
    // 0x11389c0: ldur            x1, [fp, #-0x18]
    // 0x11389c4: add             x3, x1, #1
    // 0x11389c8: stur            x3, [fp, #-0x20]
    // 0x11389cc: lsl             x4, x3, #1
    // 0x11389d0: StoreField: r2->field_b = r4
    //     0x11389d0: stur            w4, [x2, #0xb]
    // 0x11389d4: LoadField: r4 = r2->field_f
    //     0x11389d4: ldur            w4, [x2, #0xf]
    // 0x11389d8: DecompressPointer r4
    //     0x11389d8: add             x4, x4, HEAP, lsl #32
    // 0x11389dc: ArrayStore: r4[r1] = r0  ; Unknown_4
    //     0x11389dc: add             x5, x4, x1, lsl #2
    //     0x11389e0: stur            w0, [x5, #0xf]
    // 0x11389e4: LoadField: r0 = r4->field_b
    //     0x11389e4: ldur            w0, [x4, #0xb]
    // 0x11389e8: r1 = LoadInt32Instr(r0)
    //     0x11389e8: sbfx            x1, x0, #1, #0x1f
    // 0x11389ec: cmp             x3, x1
    // 0x11389f0: b.ne            #0x11389fc
    // 0x11389f4: mov             x1, x2
    // 0x11389f8: r0 = _growToNextCapacity()
    //     0x11389f8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x11389fc: ldr             x3, [fp, #0x10]
    // 0x1138a00: ldur            x0, [fp, #-0x20]
    // 0x1138a04: ldur            x2, [fp, #-0x10]
    // 0x1138a08: add             x1, x0, #1
    // 0x1138a0c: lsl             x4, x1, #1
    // 0x1138a10: StoreField: r2->field_b = r4
    //     0x1138a10: stur            w4, [x2, #0xb]
    // 0x1138a14: LoadField: r1 = r2->field_f
    //     0x1138a14: ldur            w1, [x2, #0xf]
    // 0x1138a18: DecompressPointer r1
    //     0x1138a18: add             x1, x1, HEAP, lsl #32
    // 0x1138a1c: ArrayStore: r1[r0] = rNULL  ; Unknown_4
    //     0x1138a1c: add             x4, x1, x0, lsl #2
    //     0x1138a20: stur            NULL, [x4, #0xf]
    // 0x1138a24: LoadField: r4 = r3->field_f
    //     0x1138a24: ldur            w4, [x3, #0xf]
    // 0x1138a28: DecompressPointer r4
    //     0x1138a28: add             x4, x4, HEAP, lsl #32
    // 0x1138a2c: stur            x4, [fp, #-8]
    // 0x1138a30: r0 = LoadClassIdInstr(r4)
    //     0x1138a30: ldur            x0, [x4, #-1]
    //     0x1138a34: ubfx            x0, x0, #0xc, #0x14
    // 0x1138a38: mov             x1, x4
    // 0x1138a3c: r0 = GDT[cid_x0 + 0x44d]()
    //     0x1138a3c: add             lr, x0, #0x44d
    //     0x1138a40: ldr             lr, [x21, lr, lsl #3]
    //     0x1138a44: blr             lr
    // 0x1138a48: ldur            x1, [fp, #-0x10]
    // 0x1138a4c: mov             x2, x0
    // 0x1138a50: r0 = addAll()
    //     0x1138a50: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x1138a54: ldur            x1, [fp, #-8]
    // 0x1138a58: r0 = LoadClassIdInstr(r1)
    //     0x1138a58: ldur            x0, [x1, #-1]
    //     0x1138a5c: ubfx            x0, x0, #0xc, #0x14
    // 0x1138a60: r0 = GDT[cid_x0 + 0x116a8]()
    //     0x1138a60: mov             x17, #0x16a8
    //     0x1138a64: movk            x17, #1, lsl #16
    //     0x1138a68: add             lr, x0, x17
    //     0x1138a6c: ldr             lr, [x21, lr, lsl #3]
    //     0x1138a70: blr             lr
    // 0x1138a74: ldur            x1, [fp, #-0x10]
    // 0x1138a78: mov             x2, x0
    // 0x1138a7c: r0 = addAll()
    //     0x1138a7c: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x1138a80: ldr             x0, [fp, #0x10]
    // 0x1138a84: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x1138a84: ldur            w2, [x0, #0x17]
    // 0x1138a88: DecompressPointer r2
    //     0x1138a88: add             x2, x2, HEAP, lsl #32
    // 0x1138a8c: ldur            x3, [fp, #-0x10]
    // 0x1138a90: stur            x2, [fp, #-8]
    // 0x1138a94: LoadField: r1 = r3->field_b
    //     0x1138a94: ldur            w1, [x3, #0xb]
    // 0x1138a98: LoadField: r4 = r3->field_f
    //     0x1138a98: ldur            w4, [x3, #0xf]
    // 0x1138a9c: DecompressPointer r4
    //     0x1138a9c: add             x4, x4, HEAP, lsl #32
    // 0x1138aa0: LoadField: r5 = r4->field_b
    //     0x1138aa0: ldur            w5, [x4, #0xb]
    // 0x1138aa4: r4 = LoadInt32Instr(r1)
    //     0x1138aa4: sbfx            x4, x1, #1, #0x1f
    // 0x1138aa8: stur            x4, [fp, #-0x18]
    // 0x1138aac: r1 = LoadInt32Instr(r5)
    //     0x1138aac: sbfx            x1, x5, #1, #0x1f
    // 0x1138ab0: cmp             x4, x1
    // 0x1138ab4: b.ne            #0x1138ac0
    // 0x1138ab8: mov             x1, x3
    // 0x1138abc: r0 = _growToNextCapacity()
    //     0x1138abc: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1138ac0: ldr             x2, [fp, #0x10]
    // 0x1138ac4: ldur            x3, [fp, #-0x10]
    // 0x1138ac8: ldur            x4, [fp, #-0x18]
    // 0x1138acc: add             x5, x4, #1
    // 0x1138ad0: stur            x5, [fp, #-0x20]
    // 0x1138ad4: lsl             x0, x5, #1
    // 0x1138ad8: StoreField: r3->field_b = r0
    //     0x1138ad8: stur            w0, [x3, #0xb]
    // 0x1138adc: LoadField: r6 = r3->field_f
    //     0x1138adc: ldur            w6, [x3, #0xf]
    // 0x1138ae0: DecompressPointer r6
    //     0x1138ae0: add             x6, x6, HEAP, lsl #32
    // 0x1138ae4: mov             x1, x6
    // 0x1138ae8: ldur            x0, [fp, #-8]
    // 0x1138aec: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1138aec: add             x25, x1, x4, lsl #2
    //     0x1138af0: add             x25, x25, #0xf
    //     0x1138af4: str             w0, [x25]
    //     0x1138af8: tbz             w0, #0, #0x1138b14
    //     0x1138afc: ldurb           w16, [x1, #-1]
    //     0x1138b00: ldurb           w17, [x0, #-1]
    //     0x1138b04: and             x16, x17, x16, lsr #2
    //     0x1138b08: tst             x16, HEAP, lsr #32
    //     0x1138b0c: b.eq            #0x1138b14
    //     0x1138b10: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1138b14: LoadField: r0 = r2->field_1b
    //     0x1138b14: ldur            w0, [x2, #0x1b]
    // 0x1138b18: DecompressPointer r0
    //     0x1138b18: add             x0, x0, HEAP, lsl #32
    // 0x1138b1c: stur            x0, [fp, #-8]
    // 0x1138b20: LoadField: r1 = r6->field_b
    //     0x1138b20: ldur            w1, [x6, #0xb]
    // 0x1138b24: r4 = LoadInt32Instr(r1)
    //     0x1138b24: sbfx            x4, x1, #1, #0x1f
    // 0x1138b28: cmp             x5, x4
    // 0x1138b2c: b.ne            #0x1138b38
    // 0x1138b30: mov             x1, x3
    // 0x1138b34: r0 = _growToNextCapacity()
    //     0x1138b34: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1138b38: ldur            x3, [fp, #-0x20]
    // 0x1138b3c: ldur            x2, [fp, #-0x10]
    // 0x1138b40: add             x4, x3, #1
    // 0x1138b44: stur            x4, [fp, #-0x18]
    // 0x1138b48: lsl             x0, x4, #1
    // 0x1138b4c: StoreField: r2->field_b = r0
    //     0x1138b4c: stur            w0, [x2, #0xb]
    // 0x1138b50: LoadField: r5 = r2->field_f
    //     0x1138b50: ldur            w5, [x2, #0xf]
    // 0x1138b54: DecompressPointer r5
    //     0x1138b54: add             x5, x5, HEAP, lsl #32
    // 0x1138b58: mov             x1, x5
    // 0x1138b5c: ldur            x0, [fp, #-8]
    // 0x1138b60: ArrayStore: r1[r3] = r0  ; List_4
    //     0x1138b60: add             x25, x1, x3, lsl #2
    //     0x1138b64: add             x25, x25, #0xf
    //     0x1138b68: str             w0, [x25]
    //     0x1138b6c: tbz             w0, #0, #0x1138b88
    //     0x1138b70: ldurb           w16, [x1, #-1]
    //     0x1138b74: ldurb           w17, [x0, #-1]
    //     0x1138b78: and             x16, x17, x16, lsr #2
    //     0x1138b7c: tst             x16, HEAP, lsr #32
    //     0x1138b80: b.eq            #0x1138b88
    //     0x1138b84: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1138b88: LoadField: r0 = r5->field_b
    //     0x1138b88: ldur            w0, [x5, #0xb]
    // 0x1138b8c: r1 = LoadInt32Instr(r0)
    //     0x1138b8c: sbfx            x1, x0, #1, #0x1f
    // 0x1138b90: cmp             x4, x1
    // 0x1138b94: b.ne            #0x1138ba0
    // 0x1138b98: mov             x1, x2
    // 0x1138b9c: r0 = _growToNextCapacity()
    //     0x1138b9c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1138ba0: ldur            x1, [fp, #-0x18]
    // 0x1138ba4: ldur            x0, [fp, #-0x10]
    // 0x1138ba8: add             x2, x1, #1
    // 0x1138bac: stur            x2, [fp, #-0x20]
    // 0x1138bb0: lsl             x3, x2, #1
    // 0x1138bb4: StoreField: r0->field_b = r3
    //     0x1138bb4: stur            w3, [x0, #0xb]
    // 0x1138bb8: LoadField: r3 = r0->field_f
    //     0x1138bb8: ldur            w3, [x0, #0xf]
    // 0x1138bbc: DecompressPointer r3
    //     0x1138bbc: add             x3, x3, HEAP, lsl #32
    // 0x1138bc0: add             x4, x3, x1, lsl #2
    // 0x1138bc4: r16 = Instance_PageTransitionsTheme
    //     0x1138bc4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12938] Obj!PageTransitionsTheme@12b2a31
    //     0x1138bc8: ldr             x16, [x16, #0x938]
    // 0x1138bcc: StoreField: r4->field_f = r16
    //     0x1138bcc: stur            w16, [x4, #0xf]
    // 0x1138bd0: LoadField: r1 = r3->field_b
    //     0x1138bd0: ldur            w1, [x3, #0xb]
    // 0x1138bd4: r3 = LoadInt32Instr(r1)
    //     0x1138bd4: sbfx            x3, x1, #1, #0x1f
    // 0x1138bd8: cmp             x2, x3
    // 0x1138bdc: b.ne            #0x1138be8
    // 0x1138be0: mov             x1, x0
    // 0x1138be4: r0 = _growToNextCapacity()
    //     0x1138be4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1138be8: ldr             x2, [fp, #0x10]
    // 0x1138bec: ldur            x1, [fp, #-0x20]
    // 0x1138bf0: ldur            x0, [fp, #-0x10]
    // 0x1138bf4: add             x3, x1, #1
    // 0x1138bf8: stur            x3, [fp, #-0x18]
    // 0x1138bfc: lsl             x4, x3, #1
    // 0x1138c00: StoreField: r0->field_b = r4
    //     0x1138c00: stur            w4, [x0, #0xb]
    // 0x1138c04: LoadField: r4 = r0->field_f
    //     0x1138c04: ldur            w4, [x0, #0xf]
    // 0x1138c08: DecompressPointer r4
    //     0x1138c08: add             x4, x4, HEAP, lsl #32
    // 0x1138c0c: add             x5, x4, x1, lsl #2
    // 0x1138c10: r16 = Instance_TargetPlatform
    //     0x1138c10: add             x16, PP, #0x12, lsl #12  ; [pp+0x12940] Obj!TargetPlatform@12c5e81
    //     0x1138c14: ldr             x16, [x16, #0x940]
    // 0x1138c18: StoreField: r5->field_f = r16
    //     0x1138c18: stur            w16, [x5, #0xf]
    // 0x1138c1c: LoadField: r5 = r2->field_27
    //     0x1138c1c: ldur            w5, [x2, #0x27]
    // 0x1138c20: DecompressPointer r5
    //     0x1138c20: add             x5, x5, HEAP, lsl #32
    // 0x1138c24: stur            x5, [fp, #-8]
    // 0x1138c28: LoadField: r1 = r4->field_b
    //     0x1138c28: ldur            w1, [x4, #0xb]
    // 0x1138c2c: r4 = LoadInt32Instr(r1)
    //     0x1138c2c: sbfx            x4, x1, #1, #0x1f
    // 0x1138c30: cmp             x3, x4
    // 0x1138c34: b.ne            #0x1138c40
    // 0x1138c38: mov             x1, x0
    // 0x1138c3c: r0 = _growToNextCapacity()
    //     0x1138c3c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1138c40: ldr             x3, [fp, #0x10]
    // 0x1138c44: ldur            x4, [fp, #-0x18]
    // 0x1138c48: ldur            x2, [fp, #-0x10]
    // 0x1138c4c: add             x5, x4, #1
    // 0x1138c50: stur            x5, [fp, #-0x20]
    // 0x1138c54: lsl             x0, x5, #1
    // 0x1138c58: StoreField: r2->field_b = r0
    //     0x1138c58: stur            w0, [x2, #0xb]
    // 0x1138c5c: LoadField: r6 = r2->field_f
    //     0x1138c5c: ldur            w6, [x2, #0xf]
    // 0x1138c60: DecompressPointer r6
    //     0x1138c60: add             x6, x6, HEAP, lsl #32
    // 0x1138c64: mov             x1, x6
    // 0x1138c68: ldur            x0, [fp, #-8]
    // 0x1138c6c: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1138c6c: add             x25, x1, x4, lsl #2
    //     0x1138c70: add             x25, x25, #0xf
    //     0x1138c74: str             w0, [x25]
    //     0x1138c78: tbz             w0, #0, #0x1138c94
    //     0x1138c7c: ldurb           w16, [x1, #-1]
    //     0x1138c80: ldurb           w17, [x0, #-1]
    //     0x1138c84: and             x16, x17, x16, lsr #2
    //     0x1138c88: tst             x16, HEAP, lsr #32
    //     0x1138c8c: b.eq            #0x1138c94
    //     0x1138c90: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1138c94: LoadField: r0 = r3->field_2b
    //     0x1138c94: ldur            w0, [x3, #0x2b]
    // 0x1138c98: DecompressPointer r0
    //     0x1138c98: add             x0, x0, HEAP, lsl #32
    // 0x1138c9c: stur            x0, [fp, #-8]
    // 0x1138ca0: LoadField: r1 = r6->field_b
    //     0x1138ca0: ldur            w1, [x6, #0xb]
    // 0x1138ca4: r4 = LoadInt32Instr(r1)
    //     0x1138ca4: sbfx            x4, x1, #1, #0x1f
    // 0x1138ca8: cmp             x5, x4
    // 0x1138cac: b.ne            #0x1138cb8
    // 0x1138cb0: mov             x1, x2
    // 0x1138cb4: r0 = _growToNextCapacity()
    //     0x1138cb4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1138cb8: ldr             x3, [fp, #0x10]
    // 0x1138cbc: ldur            x4, [fp, #-0x20]
    // 0x1138cc0: ldur            x2, [fp, #-0x10]
    // 0x1138cc4: add             x5, x4, #1
    // 0x1138cc8: stur            x5, [fp, #-0x18]
    // 0x1138ccc: lsl             x0, x5, #1
    // 0x1138cd0: StoreField: r2->field_b = r0
    //     0x1138cd0: stur            w0, [x2, #0xb]
    // 0x1138cd4: LoadField: r6 = r2->field_f
    //     0x1138cd4: ldur            w6, [x2, #0xf]
    // 0x1138cd8: DecompressPointer r6
    //     0x1138cd8: add             x6, x6, HEAP, lsl #32
    // 0x1138cdc: mov             x1, x6
    // 0x1138ce0: ldur            x0, [fp, #-8]
    // 0x1138ce4: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1138ce4: add             x25, x1, x4, lsl #2
    //     0x1138ce8: add             x25, x25, #0xf
    //     0x1138cec: str             w0, [x25]
    //     0x1138cf0: tbz             w0, #0, #0x1138d0c
    //     0x1138cf4: ldurb           w16, [x1, #-1]
    //     0x1138cf8: ldurb           w17, [x0, #-1]
    //     0x1138cfc: and             x16, x17, x16, lsr #2
    //     0x1138d00: tst             x16, HEAP, lsr #32
    //     0x1138d04: b.eq            #0x1138d0c
    //     0x1138d08: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1138d0c: LoadField: r0 = r3->field_2f
    //     0x1138d0c: ldur            w0, [x3, #0x2f]
    // 0x1138d10: DecompressPointer r0
    //     0x1138d10: add             x0, x0, HEAP, lsl #32
    // 0x1138d14: stur            x0, [fp, #-8]
    // 0x1138d18: LoadField: r1 = r6->field_b
    //     0x1138d18: ldur            w1, [x6, #0xb]
    // 0x1138d1c: r4 = LoadInt32Instr(r1)
    //     0x1138d1c: sbfx            x4, x1, #1, #0x1f
    // 0x1138d20: cmp             x5, x4
    // 0x1138d24: b.ne            #0x1138d30
    // 0x1138d28: mov             x1, x2
    // 0x1138d2c: r0 = _growToNextCapacity()
    //     0x1138d2c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1138d30: ldr             x2, [fp, #0x10]
    // 0x1138d34: ldur            x3, [fp, #-8]
    // 0x1138d38: ldur            x1, [fp, #-0x18]
    // 0x1138d3c: ldur            x0, [fp, #-0x10]
    // 0x1138d40: add             x4, x1, #1
    // 0x1138d44: stur            x4, [fp, #-0x20]
    // 0x1138d48: lsl             x5, x4, #1
    // 0x1138d4c: StoreField: r0->field_b = r5
    //     0x1138d4c: stur            w5, [x0, #0xb]
    // 0x1138d50: LoadField: r5 = r0->field_f
    //     0x1138d50: ldur            w5, [x0, #0xf]
    // 0x1138d54: DecompressPointer r5
    //     0x1138d54: add             x5, x5, HEAP, lsl #32
    // 0x1138d58: ArrayStore: r5[r1] = r3  ; Unknown_4
    //     0x1138d58: add             x6, x5, x1, lsl #2
    //     0x1138d5c: stur            w3, [x6, #0xf]
    // 0x1138d60: LoadField: r3 = r2->field_33
    //     0x1138d60: ldur            w3, [x2, #0x33]
    // 0x1138d64: DecompressPointer r3
    //     0x1138d64: add             x3, x3, HEAP, lsl #32
    // 0x1138d68: stur            x3, [fp, #-8]
    // 0x1138d6c: LoadField: r1 = r5->field_b
    //     0x1138d6c: ldur            w1, [x5, #0xb]
    // 0x1138d70: r5 = LoadInt32Instr(r1)
    //     0x1138d70: sbfx            x5, x1, #1, #0x1f
    // 0x1138d74: cmp             x4, x5
    // 0x1138d78: b.ne            #0x1138d84
    // 0x1138d7c: mov             x1, x0
    // 0x1138d80: r0 = _growToNextCapacity()
    //     0x1138d80: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1138d84: ldr             x3, [fp, #0x10]
    // 0x1138d88: ldur            x4, [fp, #-0x20]
    // 0x1138d8c: ldur            x2, [fp, #-0x10]
    // 0x1138d90: add             x5, x4, #1
    // 0x1138d94: stur            x5, [fp, #-0x18]
    // 0x1138d98: lsl             x0, x5, #1
    // 0x1138d9c: StoreField: r2->field_b = r0
    //     0x1138d9c: stur            w0, [x2, #0xb]
    // 0x1138da0: LoadField: r6 = r2->field_f
    //     0x1138da0: ldur            w6, [x2, #0xf]
    // 0x1138da4: DecompressPointer r6
    //     0x1138da4: add             x6, x6, HEAP, lsl #32
    // 0x1138da8: mov             x1, x6
    // 0x1138dac: ldur            x0, [fp, #-8]
    // 0x1138db0: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1138db0: add             x25, x1, x4, lsl #2
    //     0x1138db4: add             x25, x25, #0xf
    //     0x1138db8: str             w0, [x25]
    //     0x1138dbc: tbz             w0, #0, #0x1138dd8
    //     0x1138dc0: ldurb           w16, [x1, #-1]
    //     0x1138dc4: ldurb           w17, [x0, #-1]
    //     0x1138dc8: and             x16, x17, x16, lsr #2
    //     0x1138dcc: tst             x16, HEAP, lsr #32
    //     0x1138dd0: b.eq            #0x1138dd8
    //     0x1138dd4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1138dd8: LoadField: r0 = r3->field_37
    //     0x1138dd8: ldur            w0, [x3, #0x37]
    // 0x1138ddc: DecompressPointer r0
    //     0x1138ddc: add             x0, x0, HEAP, lsl #32
    // 0x1138de0: stur            x0, [fp, #-8]
    // 0x1138de4: LoadField: r1 = r6->field_b
    //     0x1138de4: ldur            w1, [x6, #0xb]
    // 0x1138de8: r4 = LoadInt32Instr(r1)
    //     0x1138de8: sbfx            x4, x1, #1, #0x1f
    // 0x1138dec: cmp             x5, x4
    // 0x1138df0: b.ne            #0x1138dfc
    // 0x1138df4: mov             x1, x2
    // 0x1138df8: r0 = _growToNextCapacity()
    //     0x1138df8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1138dfc: ldr             x3, [fp, #0x10]
    // 0x1138e00: ldur            x4, [fp, #-0x18]
    // 0x1138e04: ldur            x2, [fp, #-0x10]
    // 0x1138e08: add             x5, x4, #1
    // 0x1138e0c: stur            x5, [fp, #-0x20]
    // 0x1138e10: lsl             x0, x5, #1
    // 0x1138e14: StoreField: r2->field_b = r0
    //     0x1138e14: stur            w0, [x2, #0xb]
    // 0x1138e18: LoadField: r6 = r2->field_f
    //     0x1138e18: ldur            w6, [x2, #0xf]
    // 0x1138e1c: DecompressPointer r6
    //     0x1138e1c: add             x6, x6, HEAP, lsl #32
    // 0x1138e20: mov             x1, x6
    // 0x1138e24: ldur            x0, [fp, #-8]
    // 0x1138e28: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1138e28: add             x25, x1, x4, lsl #2
    //     0x1138e2c: add             x25, x25, #0xf
    //     0x1138e30: str             w0, [x25]
    //     0x1138e34: tbz             w0, #0, #0x1138e50
    //     0x1138e38: ldurb           w16, [x1, #-1]
    //     0x1138e3c: ldurb           w17, [x0, #-1]
    //     0x1138e40: and             x16, x17, x16, lsr #2
    //     0x1138e44: tst             x16, HEAP, lsr #32
    //     0x1138e48: b.eq            #0x1138e50
    //     0x1138e4c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1138e50: LoadField: r0 = r3->field_3b
    //     0x1138e50: ldur            w0, [x3, #0x3b]
    // 0x1138e54: DecompressPointer r0
    //     0x1138e54: add             x0, x0, HEAP, lsl #32
    // 0x1138e58: stur            x0, [fp, #-8]
    // 0x1138e5c: LoadField: r1 = r6->field_b
    //     0x1138e5c: ldur            w1, [x6, #0xb]
    // 0x1138e60: r4 = LoadInt32Instr(r1)
    //     0x1138e60: sbfx            x4, x1, #1, #0x1f
    // 0x1138e64: cmp             x5, x4
    // 0x1138e68: b.ne            #0x1138e74
    // 0x1138e6c: mov             x1, x2
    // 0x1138e70: r0 = _growToNextCapacity()
    //     0x1138e70: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1138e74: ldr             x3, [fp, #0x10]
    // 0x1138e78: ldur            x4, [fp, #-0x20]
    // 0x1138e7c: ldur            x2, [fp, #-0x10]
    // 0x1138e80: add             x5, x4, #1
    // 0x1138e84: stur            x5, [fp, #-0x18]
    // 0x1138e88: lsl             x0, x5, #1
    // 0x1138e8c: StoreField: r2->field_b = r0
    //     0x1138e8c: stur            w0, [x2, #0xb]
    // 0x1138e90: LoadField: r6 = r2->field_f
    //     0x1138e90: ldur            w6, [x2, #0xf]
    // 0x1138e94: DecompressPointer r6
    //     0x1138e94: add             x6, x6, HEAP, lsl #32
    // 0x1138e98: mov             x1, x6
    // 0x1138e9c: ldur            x0, [fp, #-8]
    // 0x1138ea0: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1138ea0: add             x25, x1, x4, lsl #2
    //     0x1138ea4: add             x25, x25, #0xf
    //     0x1138ea8: str             w0, [x25]
    //     0x1138eac: tbz             w0, #0, #0x1138ec8
    //     0x1138eb0: ldurb           w16, [x1, #-1]
    //     0x1138eb4: ldurb           w17, [x0, #-1]
    //     0x1138eb8: and             x16, x17, x16, lsr #2
    //     0x1138ebc: tst             x16, HEAP, lsr #32
    //     0x1138ec0: b.eq            #0x1138ec8
    //     0x1138ec4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1138ec8: LoadField: r0 = r3->field_3f
    //     0x1138ec8: ldur            w0, [x3, #0x3f]
    // 0x1138ecc: DecompressPointer r0
    //     0x1138ecc: add             x0, x0, HEAP, lsl #32
    // 0x1138ed0: stur            x0, [fp, #-8]
    // 0x1138ed4: LoadField: r1 = r6->field_b
    //     0x1138ed4: ldur            w1, [x6, #0xb]
    // 0x1138ed8: r4 = LoadInt32Instr(r1)
    //     0x1138ed8: sbfx            x4, x1, #1, #0x1f
    // 0x1138edc: cmp             x5, x4
    // 0x1138ee0: b.ne            #0x1138eec
    // 0x1138ee4: mov             x1, x2
    // 0x1138ee8: r0 = _growToNextCapacity()
    //     0x1138ee8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1138eec: ldr             x3, [fp, #0x10]
    // 0x1138ef0: ldur            x4, [fp, #-0x18]
    // 0x1138ef4: ldur            x2, [fp, #-0x10]
    // 0x1138ef8: add             x5, x4, #1
    // 0x1138efc: stur            x5, [fp, #-0x20]
    // 0x1138f00: lsl             x0, x5, #1
    // 0x1138f04: StoreField: r2->field_b = r0
    //     0x1138f04: stur            w0, [x2, #0xb]
    // 0x1138f08: LoadField: r6 = r2->field_f
    //     0x1138f08: ldur            w6, [x2, #0xf]
    // 0x1138f0c: DecompressPointer r6
    //     0x1138f0c: add             x6, x6, HEAP, lsl #32
    // 0x1138f10: mov             x1, x6
    // 0x1138f14: ldur            x0, [fp, #-8]
    // 0x1138f18: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1138f18: add             x25, x1, x4, lsl #2
    //     0x1138f1c: add             x25, x25, #0xf
    //     0x1138f20: str             w0, [x25]
    //     0x1138f24: tbz             w0, #0, #0x1138f40
    //     0x1138f28: ldurb           w16, [x1, #-1]
    //     0x1138f2c: ldurb           w17, [x0, #-1]
    //     0x1138f30: and             x16, x17, x16, lsr #2
    //     0x1138f34: tst             x16, HEAP, lsr #32
    //     0x1138f38: b.eq            #0x1138f40
    //     0x1138f3c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1138f40: LoadField: r0 = r3->field_43
    //     0x1138f40: ldur            w0, [x3, #0x43]
    // 0x1138f44: DecompressPointer r0
    //     0x1138f44: add             x0, x0, HEAP, lsl #32
    // 0x1138f48: stur            x0, [fp, #-8]
    // 0x1138f4c: LoadField: r1 = r6->field_b
    //     0x1138f4c: ldur            w1, [x6, #0xb]
    // 0x1138f50: r4 = LoadInt32Instr(r1)
    //     0x1138f50: sbfx            x4, x1, #1, #0x1f
    // 0x1138f54: cmp             x5, x4
    // 0x1138f58: b.ne            #0x1138f64
    // 0x1138f5c: mov             x1, x2
    // 0x1138f60: r0 = _growToNextCapacity()
    //     0x1138f60: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1138f64: ldr             x3, [fp, #0x10]
    // 0x1138f68: ldur            x4, [fp, #-0x20]
    // 0x1138f6c: ldur            x2, [fp, #-0x10]
    // 0x1138f70: add             x5, x4, #1
    // 0x1138f74: stur            x5, [fp, #-0x18]
    // 0x1138f78: lsl             x0, x5, #1
    // 0x1138f7c: StoreField: r2->field_b = r0
    //     0x1138f7c: stur            w0, [x2, #0xb]
    // 0x1138f80: LoadField: r6 = r2->field_f
    //     0x1138f80: ldur            w6, [x2, #0xf]
    // 0x1138f84: DecompressPointer r6
    //     0x1138f84: add             x6, x6, HEAP, lsl #32
    // 0x1138f88: mov             x1, x6
    // 0x1138f8c: ldur            x0, [fp, #-8]
    // 0x1138f90: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1138f90: add             x25, x1, x4, lsl #2
    //     0x1138f94: add             x25, x25, #0xf
    //     0x1138f98: str             w0, [x25]
    //     0x1138f9c: tbz             w0, #0, #0x1138fb8
    //     0x1138fa0: ldurb           w16, [x1, #-1]
    //     0x1138fa4: ldurb           w17, [x0, #-1]
    //     0x1138fa8: and             x16, x17, x16, lsr #2
    //     0x1138fac: tst             x16, HEAP, lsr #32
    //     0x1138fb0: b.eq            #0x1138fb8
    //     0x1138fb4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1138fb8: LoadField: r0 = r3->field_47
    //     0x1138fb8: ldur            w0, [x3, #0x47]
    // 0x1138fbc: DecompressPointer r0
    //     0x1138fbc: add             x0, x0, HEAP, lsl #32
    // 0x1138fc0: stur            x0, [fp, #-8]
    // 0x1138fc4: LoadField: r1 = r6->field_b
    //     0x1138fc4: ldur            w1, [x6, #0xb]
    // 0x1138fc8: r4 = LoadInt32Instr(r1)
    //     0x1138fc8: sbfx            x4, x1, #1, #0x1f
    // 0x1138fcc: cmp             x5, x4
    // 0x1138fd0: b.ne            #0x1138fdc
    // 0x1138fd4: mov             x1, x2
    // 0x1138fd8: r0 = _growToNextCapacity()
    //     0x1138fd8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1138fdc: ldr             x3, [fp, #0x10]
    // 0x1138fe0: ldur            x4, [fp, #-0x18]
    // 0x1138fe4: ldur            x2, [fp, #-0x10]
    // 0x1138fe8: add             x5, x4, #1
    // 0x1138fec: stur            x5, [fp, #-0x20]
    // 0x1138ff0: lsl             x0, x5, #1
    // 0x1138ff4: StoreField: r2->field_b = r0
    //     0x1138ff4: stur            w0, [x2, #0xb]
    // 0x1138ff8: LoadField: r6 = r2->field_f
    //     0x1138ff8: ldur            w6, [x2, #0xf]
    // 0x1138ffc: DecompressPointer r6
    //     0x1138ffc: add             x6, x6, HEAP, lsl #32
    // 0x1139000: mov             x1, x6
    // 0x1139004: ldur            x0, [fp, #-8]
    // 0x1139008: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139008: add             x25, x1, x4, lsl #2
    //     0x113900c: add             x25, x25, #0xf
    //     0x1139010: str             w0, [x25]
    //     0x1139014: tbz             w0, #0, #0x1139030
    //     0x1139018: ldurb           w16, [x1, #-1]
    //     0x113901c: ldurb           w17, [x0, #-1]
    //     0x1139020: and             x16, x17, x16, lsr #2
    //     0x1139024: tst             x16, HEAP, lsr #32
    //     0x1139028: b.eq            #0x1139030
    //     0x113902c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139030: LoadField: r0 = r3->field_4b
    //     0x1139030: ldur            w0, [x3, #0x4b]
    // 0x1139034: DecompressPointer r0
    //     0x1139034: add             x0, x0, HEAP, lsl #32
    // 0x1139038: stur            x0, [fp, #-8]
    // 0x113903c: LoadField: r1 = r6->field_b
    //     0x113903c: ldur            w1, [x6, #0xb]
    // 0x1139040: r4 = LoadInt32Instr(r1)
    //     0x1139040: sbfx            x4, x1, #1, #0x1f
    // 0x1139044: cmp             x5, x4
    // 0x1139048: b.ne            #0x1139054
    // 0x113904c: mov             x1, x2
    // 0x1139050: r0 = _growToNextCapacity()
    //     0x1139050: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1139054: ldr             x3, [fp, #0x10]
    // 0x1139058: ldur            x4, [fp, #-0x20]
    // 0x113905c: ldur            x2, [fp, #-0x10]
    // 0x1139060: add             x5, x4, #1
    // 0x1139064: stur            x5, [fp, #-0x18]
    // 0x1139068: lsl             x0, x5, #1
    // 0x113906c: StoreField: r2->field_b = r0
    //     0x113906c: stur            w0, [x2, #0xb]
    // 0x1139070: LoadField: r6 = r2->field_f
    //     0x1139070: ldur            w6, [x2, #0xf]
    // 0x1139074: DecompressPointer r6
    //     0x1139074: add             x6, x6, HEAP, lsl #32
    // 0x1139078: mov             x1, x6
    // 0x113907c: ldur            x0, [fp, #-8]
    // 0x1139080: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139080: add             x25, x1, x4, lsl #2
    //     0x1139084: add             x25, x25, #0xf
    //     0x1139088: str             w0, [x25]
    //     0x113908c: tbz             w0, #0, #0x11390a8
    //     0x1139090: ldurb           w16, [x1, #-1]
    //     0x1139094: ldurb           w17, [x0, #-1]
    //     0x1139098: and             x16, x17, x16, lsr #2
    //     0x113909c: tst             x16, HEAP, lsr #32
    //     0x11390a0: b.eq            #0x11390a8
    //     0x11390a4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11390a8: LoadField: r0 = r3->field_4f
    //     0x11390a8: ldur            w0, [x3, #0x4f]
    // 0x11390ac: DecompressPointer r0
    //     0x11390ac: add             x0, x0, HEAP, lsl #32
    // 0x11390b0: stur            x0, [fp, #-8]
    // 0x11390b4: LoadField: r1 = r6->field_b
    //     0x11390b4: ldur            w1, [x6, #0xb]
    // 0x11390b8: r4 = LoadInt32Instr(r1)
    //     0x11390b8: sbfx            x4, x1, #1, #0x1f
    // 0x11390bc: cmp             x5, x4
    // 0x11390c0: b.ne            #0x11390cc
    // 0x11390c4: mov             x1, x2
    // 0x11390c8: r0 = _growToNextCapacity()
    //     0x11390c8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x11390cc: ldr             x3, [fp, #0x10]
    // 0x11390d0: ldur            x4, [fp, #-0x18]
    // 0x11390d4: ldur            x2, [fp, #-0x10]
    // 0x11390d8: add             x5, x4, #1
    // 0x11390dc: stur            x5, [fp, #-0x20]
    // 0x11390e0: lsl             x0, x5, #1
    // 0x11390e4: StoreField: r2->field_b = r0
    //     0x11390e4: stur            w0, [x2, #0xb]
    // 0x11390e8: LoadField: r6 = r2->field_f
    //     0x11390e8: ldur            w6, [x2, #0xf]
    // 0x11390ec: DecompressPointer r6
    //     0x11390ec: add             x6, x6, HEAP, lsl #32
    // 0x11390f0: mov             x1, x6
    // 0x11390f4: ldur            x0, [fp, #-8]
    // 0x11390f8: ArrayStore: r1[r4] = r0  ; List_4
    //     0x11390f8: add             x25, x1, x4, lsl #2
    //     0x11390fc: add             x25, x25, #0xf
    //     0x1139100: str             w0, [x25]
    //     0x1139104: tbz             w0, #0, #0x1139120
    //     0x1139108: ldurb           w16, [x1, #-1]
    //     0x113910c: ldurb           w17, [x0, #-1]
    //     0x1139110: and             x16, x17, x16, lsr #2
    //     0x1139114: tst             x16, HEAP, lsr #32
    //     0x1139118: b.eq            #0x1139120
    //     0x113911c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139120: LoadField: r0 = r3->field_53
    //     0x1139120: ldur            w0, [x3, #0x53]
    // 0x1139124: DecompressPointer r0
    //     0x1139124: add             x0, x0, HEAP, lsl #32
    // 0x1139128: stur            x0, [fp, #-8]
    // 0x113912c: LoadField: r1 = r6->field_b
    //     0x113912c: ldur            w1, [x6, #0xb]
    // 0x1139130: r4 = LoadInt32Instr(r1)
    //     0x1139130: sbfx            x4, x1, #1, #0x1f
    // 0x1139134: cmp             x5, x4
    // 0x1139138: b.ne            #0x1139144
    // 0x113913c: mov             x1, x2
    // 0x1139140: r0 = _growToNextCapacity()
    //     0x1139140: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1139144: ldr             x3, [fp, #0x10]
    // 0x1139148: ldur            x4, [fp, #-0x20]
    // 0x113914c: ldur            x2, [fp, #-0x10]
    // 0x1139150: add             x5, x4, #1
    // 0x1139154: stur            x5, [fp, #-0x18]
    // 0x1139158: lsl             x0, x5, #1
    // 0x113915c: StoreField: r2->field_b = r0
    //     0x113915c: stur            w0, [x2, #0xb]
    // 0x1139160: LoadField: r6 = r2->field_f
    //     0x1139160: ldur            w6, [x2, #0xf]
    // 0x1139164: DecompressPointer r6
    //     0x1139164: add             x6, x6, HEAP, lsl #32
    // 0x1139168: mov             x1, x6
    // 0x113916c: ldur            x0, [fp, #-8]
    // 0x1139170: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139170: add             x25, x1, x4, lsl #2
    //     0x1139174: add             x25, x25, #0xf
    //     0x1139178: str             w0, [x25]
    //     0x113917c: tbz             w0, #0, #0x1139198
    //     0x1139180: ldurb           w16, [x1, #-1]
    //     0x1139184: ldurb           w17, [x0, #-1]
    //     0x1139188: and             x16, x17, x16, lsr #2
    //     0x113918c: tst             x16, HEAP, lsr #32
    //     0x1139190: b.eq            #0x1139198
    //     0x1139194: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139198: LoadField: r0 = r3->field_57
    //     0x1139198: ldur            w0, [x3, #0x57]
    // 0x113919c: DecompressPointer r0
    //     0x113919c: add             x0, x0, HEAP, lsl #32
    // 0x11391a0: stur            x0, [fp, #-8]
    // 0x11391a4: LoadField: r1 = r6->field_b
    //     0x11391a4: ldur            w1, [x6, #0xb]
    // 0x11391a8: r4 = LoadInt32Instr(r1)
    //     0x11391a8: sbfx            x4, x1, #1, #0x1f
    // 0x11391ac: cmp             x5, x4
    // 0x11391b0: b.ne            #0x11391bc
    // 0x11391b4: mov             x1, x2
    // 0x11391b8: r0 = _growToNextCapacity()
    //     0x11391b8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x11391bc: ldr             x3, [fp, #0x10]
    // 0x11391c0: ldur            x4, [fp, #-0x18]
    // 0x11391c4: ldur            x2, [fp, #-0x10]
    // 0x11391c8: add             x5, x4, #1
    // 0x11391cc: stur            x5, [fp, #-0x20]
    // 0x11391d0: lsl             x0, x5, #1
    // 0x11391d4: StoreField: r2->field_b = r0
    //     0x11391d4: stur            w0, [x2, #0xb]
    // 0x11391d8: LoadField: r6 = r2->field_f
    //     0x11391d8: ldur            w6, [x2, #0xf]
    // 0x11391dc: DecompressPointer r6
    //     0x11391dc: add             x6, x6, HEAP, lsl #32
    // 0x11391e0: mov             x1, x6
    // 0x11391e4: ldur            x0, [fp, #-8]
    // 0x11391e8: ArrayStore: r1[r4] = r0  ; List_4
    //     0x11391e8: add             x25, x1, x4, lsl #2
    //     0x11391ec: add             x25, x25, #0xf
    //     0x11391f0: str             w0, [x25]
    //     0x11391f4: tbz             w0, #0, #0x1139210
    //     0x11391f8: ldurb           w16, [x1, #-1]
    //     0x11391fc: ldurb           w17, [x0, #-1]
    //     0x1139200: and             x16, x17, x16, lsr #2
    //     0x1139204: tst             x16, HEAP, lsr #32
    //     0x1139208: b.eq            #0x1139210
    //     0x113920c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139210: LoadField: r0 = r3->field_5b
    //     0x1139210: ldur            w0, [x3, #0x5b]
    // 0x1139214: DecompressPointer r0
    //     0x1139214: add             x0, x0, HEAP, lsl #32
    // 0x1139218: stur            x0, [fp, #-8]
    // 0x113921c: LoadField: r1 = r6->field_b
    //     0x113921c: ldur            w1, [x6, #0xb]
    // 0x1139220: r4 = LoadInt32Instr(r1)
    //     0x1139220: sbfx            x4, x1, #1, #0x1f
    // 0x1139224: cmp             x5, x4
    // 0x1139228: b.ne            #0x1139234
    // 0x113922c: mov             x1, x2
    // 0x1139230: r0 = _growToNextCapacity()
    //     0x1139230: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1139234: ldr             x3, [fp, #0x10]
    // 0x1139238: ldur            x4, [fp, #-0x20]
    // 0x113923c: ldur            x2, [fp, #-0x10]
    // 0x1139240: add             x5, x4, #1
    // 0x1139244: stur            x5, [fp, #-0x18]
    // 0x1139248: lsl             x0, x5, #1
    // 0x113924c: StoreField: r2->field_b = r0
    //     0x113924c: stur            w0, [x2, #0xb]
    // 0x1139250: LoadField: r6 = r2->field_f
    //     0x1139250: ldur            w6, [x2, #0xf]
    // 0x1139254: DecompressPointer r6
    //     0x1139254: add             x6, x6, HEAP, lsl #32
    // 0x1139258: mov             x1, x6
    // 0x113925c: ldur            x0, [fp, #-8]
    // 0x1139260: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139260: add             x25, x1, x4, lsl #2
    //     0x1139264: add             x25, x25, #0xf
    //     0x1139268: str             w0, [x25]
    //     0x113926c: tbz             w0, #0, #0x1139288
    //     0x1139270: ldurb           w16, [x1, #-1]
    //     0x1139274: ldurb           w17, [x0, #-1]
    //     0x1139278: and             x16, x17, x16, lsr #2
    //     0x113927c: tst             x16, HEAP, lsr #32
    //     0x1139280: b.eq            #0x1139288
    //     0x1139284: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139288: LoadField: r0 = r3->field_5f
    //     0x1139288: ldur            w0, [x3, #0x5f]
    // 0x113928c: DecompressPointer r0
    //     0x113928c: add             x0, x0, HEAP, lsl #32
    // 0x1139290: stur            x0, [fp, #-8]
    // 0x1139294: LoadField: r1 = r6->field_b
    //     0x1139294: ldur            w1, [x6, #0xb]
    // 0x1139298: r4 = LoadInt32Instr(r1)
    //     0x1139298: sbfx            x4, x1, #1, #0x1f
    // 0x113929c: cmp             x5, x4
    // 0x11392a0: b.ne            #0x11392ac
    // 0x11392a4: mov             x1, x2
    // 0x11392a8: r0 = _growToNextCapacity()
    //     0x11392a8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x11392ac: ldr             x3, [fp, #0x10]
    // 0x11392b0: ldur            x4, [fp, #-0x18]
    // 0x11392b4: ldur            x2, [fp, #-0x10]
    // 0x11392b8: add             x5, x4, #1
    // 0x11392bc: stur            x5, [fp, #-0x20]
    // 0x11392c0: lsl             x0, x5, #1
    // 0x11392c4: StoreField: r2->field_b = r0
    //     0x11392c4: stur            w0, [x2, #0xb]
    // 0x11392c8: LoadField: r6 = r2->field_f
    //     0x11392c8: ldur            w6, [x2, #0xf]
    // 0x11392cc: DecompressPointer r6
    //     0x11392cc: add             x6, x6, HEAP, lsl #32
    // 0x11392d0: mov             x1, x6
    // 0x11392d4: ldur            x0, [fp, #-8]
    // 0x11392d8: ArrayStore: r1[r4] = r0  ; List_4
    //     0x11392d8: add             x25, x1, x4, lsl #2
    //     0x11392dc: add             x25, x25, #0xf
    //     0x11392e0: str             w0, [x25]
    //     0x11392e4: tbz             w0, #0, #0x1139300
    //     0x11392e8: ldurb           w16, [x1, #-1]
    //     0x11392ec: ldurb           w17, [x0, #-1]
    //     0x11392f0: and             x16, x17, x16, lsr #2
    //     0x11392f4: tst             x16, HEAP, lsr #32
    //     0x11392f8: b.eq            #0x1139300
    //     0x11392fc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139300: LoadField: r0 = r3->field_63
    //     0x1139300: ldur            w0, [x3, #0x63]
    // 0x1139304: DecompressPointer r0
    //     0x1139304: add             x0, x0, HEAP, lsl #32
    // 0x1139308: stur            x0, [fp, #-8]
    // 0x113930c: LoadField: r1 = r6->field_b
    //     0x113930c: ldur            w1, [x6, #0xb]
    // 0x1139310: r4 = LoadInt32Instr(r1)
    //     0x1139310: sbfx            x4, x1, #1, #0x1f
    // 0x1139314: cmp             x5, x4
    // 0x1139318: b.ne            #0x1139324
    // 0x113931c: mov             x1, x2
    // 0x1139320: r0 = _growToNextCapacity()
    //     0x1139320: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1139324: ldr             x3, [fp, #0x10]
    // 0x1139328: ldur            x4, [fp, #-0x20]
    // 0x113932c: ldur            x2, [fp, #-0x10]
    // 0x1139330: add             x5, x4, #1
    // 0x1139334: stur            x5, [fp, #-0x18]
    // 0x1139338: lsl             x0, x5, #1
    // 0x113933c: StoreField: r2->field_b = r0
    //     0x113933c: stur            w0, [x2, #0xb]
    // 0x1139340: LoadField: r6 = r2->field_f
    //     0x1139340: ldur            w6, [x2, #0xf]
    // 0x1139344: DecompressPointer r6
    //     0x1139344: add             x6, x6, HEAP, lsl #32
    // 0x1139348: mov             x1, x6
    // 0x113934c: ldur            x0, [fp, #-8]
    // 0x1139350: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139350: add             x25, x1, x4, lsl #2
    //     0x1139354: add             x25, x25, #0xf
    //     0x1139358: str             w0, [x25]
    //     0x113935c: tbz             w0, #0, #0x1139378
    //     0x1139360: ldurb           w16, [x1, #-1]
    //     0x1139364: ldurb           w17, [x0, #-1]
    //     0x1139368: and             x16, x17, x16, lsr #2
    //     0x113936c: tst             x16, HEAP, lsr #32
    //     0x1139370: b.eq            #0x1139378
    //     0x1139374: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139378: LoadField: r0 = r3->field_67
    //     0x1139378: ldur            w0, [x3, #0x67]
    // 0x113937c: DecompressPointer r0
    //     0x113937c: add             x0, x0, HEAP, lsl #32
    // 0x1139380: stur            x0, [fp, #-8]
    // 0x1139384: LoadField: r1 = r6->field_b
    //     0x1139384: ldur            w1, [x6, #0xb]
    // 0x1139388: r4 = LoadInt32Instr(r1)
    //     0x1139388: sbfx            x4, x1, #1, #0x1f
    // 0x113938c: cmp             x5, x4
    // 0x1139390: b.ne            #0x113939c
    // 0x1139394: mov             x1, x2
    // 0x1139398: r0 = _growToNextCapacity()
    //     0x1139398: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113939c: ldr             x3, [fp, #0x10]
    // 0x11393a0: ldur            x4, [fp, #-0x18]
    // 0x11393a4: ldur            x2, [fp, #-0x10]
    // 0x11393a8: add             x5, x4, #1
    // 0x11393ac: stur            x5, [fp, #-0x20]
    // 0x11393b0: lsl             x0, x5, #1
    // 0x11393b4: StoreField: r2->field_b = r0
    //     0x11393b4: stur            w0, [x2, #0xb]
    // 0x11393b8: LoadField: r6 = r2->field_f
    //     0x11393b8: ldur            w6, [x2, #0xf]
    // 0x11393bc: DecompressPointer r6
    //     0x11393bc: add             x6, x6, HEAP, lsl #32
    // 0x11393c0: mov             x1, x6
    // 0x11393c4: ldur            x0, [fp, #-8]
    // 0x11393c8: ArrayStore: r1[r4] = r0  ; List_4
    //     0x11393c8: add             x25, x1, x4, lsl #2
    //     0x11393cc: add             x25, x25, #0xf
    //     0x11393d0: str             w0, [x25]
    //     0x11393d4: tbz             w0, #0, #0x11393f0
    //     0x11393d8: ldurb           w16, [x1, #-1]
    //     0x11393dc: ldurb           w17, [x0, #-1]
    //     0x11393e0: and             x16, x17, x16, lsr #2
    //     0x11393e4: tst             x16, HEAP, lsr #32
    //     0x11393e8: b.eq            #0x11393f0
    //     0x11393ec: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11393f0: LoadField: r0 = r3->field_6b
    //     0x11393f0: ldur            w0, [x3, #0x6b]
    // 0x11393f4: DecompressPointer r0
    //     0x11393f4: add             x0, x0, HEAP, lsl #32
    // 0x11393f8: stur            x0, [fp, #-8]
    // 0x11393fc: LoadField: r1 = r6->field_b
    //     0x11393fc: ldur            w1, [x6, #0xb]
    // 0x1139400: r4 = LoadInt32Instr(r1)
    //     0x1139400: sbfx            x4, x1, #1, #0x1f
    // 0x1139404: cmp             x5, x4
    // 0x1139408: b.ne            #0x1139414
    // 0x113940c: mov             x1, x2
    // 0x1139410: r0 = _growToNextCapacity()
    //     0x1139410: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1139414: ldr             x3, [fp, #0x10]
    // 0x1139418: ldur            x4, [fp, #-0x20]
    // 0x113941c: ldur            x2, [fp, #-0x10]
    // 0x1139420: add             x5, x4, #1
    // 0x1139424: stur            x5, [fp, #-0x18]
    // 0x1139428: lsl             x0, x5, #1
    // 0x113942c: StoreField: r2->field_b = r0
    //     0x113942c: stur            w0, [x2, #0xb]
    // 0x1139430: LoadField: r6 = r2->field_f
    //     0x1139430: ldur            w6, [x2, #0xf]
    // 0x1139434: DecompressPointer r6
    //     0x1139434: add             x6, x6, HEAP, lsl #32
    // 0x1139438: mov             x1, x6
    // 0x113943c: ldur            x0, [fp, #-8]
    // 0x1139440: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139440: add             x25, x1, x4, lsl #2
    //     0x1139444: add             x25, x25, #0xf
    //     0x1139448: str             w0, [x25]
    //     0x113944c: tbz             w0, #0, #0x1139468
    //     0x1139450: ldurb           w16, [x1, #-1]
    //     0x1139454: ldurb           w17, [x0, #-1]
    //     0x1139458: and             x16, x17, x16, lsr #2
    //     0x113945c: tst             x16, HEAP, lsr #32
    //     0x1139460: b.eq            #0x1139468
    //     0x1139464: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139468: LoadField: r0 = r3->field_6f
    //     0x1139468: ldur            w0, [x3, #0x6f]
    // 0x113946c: DecompressPointer r0
    //     0x113946c: add             x0, x0, HEAP, lsl #32
    // 0x1139470: stur            x0, [fp, #-8]
    // 0x1139474: LoadField: r1 = r6->field_b
    //     0x1139474: ldur            w1, [x6, #0xb]
    // 0x1139478: r4 = LoadInt32Instr(r1)
    //     0x1139478: sbfx            x4, x1, #1, #0x1f
    // 0x113947c: cmp             x5, x4
    // 0x1139480: b.ne            #0x113948c
    // 0x1139484: mov             x1, x2
    // 0x1139488: r0 = _growToNextCapacity()
    //     0x1139488: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113948c: ldr             x3, [fp, #0x10]
    // 0x1139490: ldur            x4, [fp, #-0x18]
    // 0x1139494: ldur            x2, [fp, #-0x10]
    // 0x1139498: add             x5, x4, #1
    // 0x113949c: stur            x5, [fp, #-0x20]
    // 0x11394a0: lsl             x0, x5, #1
    // 0x11394a4: StoreField: r2->field_b = r0
    //     0x11394a4: stur            w0, [x2, #0xb]
    // 0x11394a8: LoadField: r6 = r2->field_f
    //     0x11394a8: ldur            w6, [x2, #0xf]
    // 0x11394ac: DecompressPointer r6
    //     0x11394ac: add             x6, x6, HEAP, lsl #32
    // 0x11394b0: mov             x1, x6
    // 0x11394b4: ldur            x0, [fp, #-8]
    // 0x11394b8: ArrayStore: r1[r4] = r0  ; List_4
    //     0x11394b8: add             x25, x1, x4, lsl #2
    //     0x11394bc: add             x25, x25, #0xf
    //     0x11394c0: str             w0, [x25]
    //     0x11394c4: tbz             w0, #0, #0x11394e0
    //     0x11394c8: ldurb           w16, [x1, #-1]
    //     0x11394cc: ldurb           w17, [x0, #-1]
    //     0x11394d0: and             x16, x17, x16, lsr #2
    //     0x11394d4: tst             x16, HEAP, lsr #32
    //     0x11394d8: b.eq            #0x11394e0
    //     0x11394dc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11394e0: LoadField: r0 = r3->field_73
    //     0x11394e0: ldur            w0, [x3, #0x73]
    // 0x11394e4: DecompressPointer r0
    //     0x11394e4: add             x0, x0, HEAP, lsl #32
    // 0x11394e8: stur            x0, [fp, #-8]
    // 0x11394ec: LoadField: r1 = r6->field_b
    //     0x11394ec: ldur            w1, [x6, #0xb]
    // 0x11394f0: r4 = LoadInt32Instr(r1)
    //     0x11394f0: sbfx            x4, x1, #1, #0x1f
    // 0x11394f4: cmp             x5, x4
    // 0x11394f8: b.ne            #0x1139504
    // 0x11394fc: mov             x1, x2
    // 0x1139500: r0 = _growToNextCapacity()
    //     0x1139500: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1139504: ldr             x3, [fp, #0x10]
    // 0x1139508: ldur            x4, [fp, #-0x20]
    // 0x113950c: ldur            x2, [fp, #-0x10]
    // 0x1139510: add             x5, x4, #1
    // 0x1139514: stur            x5, [fp, #-0x18]
    // 0x1139518: lsl             x0, x5, #1
    // 0x113951c: StoreField: r2->field_b = r0
    //     0x113951c: stur            w0, [x2, #0xb]
    // 0x1139520: LoadField: r6 = r2->field_f
    //     0x1139520: ldur            w6, [x2, #0xf]
    // 0x1139524: DecompressPointer r6
    //     0x1139524: add             x6, x6, HEAP, lsl #32
    // 0x1139528: mov             x1, x6
    // 0x113952c: ldur            x0, [fp, #-8]
    // 0x1139530: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139530: add             x25, x1, x4, lsl #2
    //     0x1139534: add             x25, x25, #0xf
    //     0x1139538: str             w0, [x25]
    //     0x113953c: tbz             w0, #0, #0x1139558
    //     0x1139540: ldurb           w16, [x1, #-1]
    //     0x1139544: ldurb           w17, [x0, #-1]
    //     0x1139548: and             x16, x17, x16, lsr #2
    //     0x113954c: tst             x16, HEAP, lsr #32
    //     0x1139550: b.eq            #0x1139558
    //     0x1139554: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139558: LoadField: r0 = r3->field_77
    //     0x1139558: ldur            w0, [x3, #0x77]
    // 0x113955c: DecompressPointer r0
    //     0x113955c: add             x0, x0, HEAP, lsl #32
    // 0x1139560: stur            x0, [fp, #-8]
    // 0x1139564: LoadField: r1 = r6->field_b
    //     0x1139564: ldur            w1, [x6, #0xb]
    // 0x1139568: r4 = LoadInt32Instr(r1)
    //     0x1139568: sbfx            x4, x1, #1, #0x1f
    // 0x113956c: cmp             x5, x4
    // 0x1139570: b.ne            #0x113957c
    // 0x1139574: mov             x1, x2
    // 0x1139578: r0 = _growToNextCapacity()
    //     0x1139578: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113957c: ldr             x3, [fp, #0x10]
    // 0x1139580: ldur            x4, [fp, #-0x18]
    // 0x1139584: ldur            x2, [fp, #-0x10]
    // 0x1139588: add             x5, x4, #1
    // 0x113958c: stur            x5, [fp, #-0x20]
    // 0x1139590: lsl             x0, x5, #1
    // 0x1139594: StoreField: r2->field_b = r0
    //     0x1139594: stur            w0, [x2, #0xb]
    // 0x1139598: LoadField: r6 = r2->field_f
    //     0x1139598: ldur            w6, [x2, #0xf]
    // 0x113959c: DecompressPointer r6
    //     0x113959c: add             x6, x6, HEAP, lsl #32
    // 0x11395a0: mov             x1, x6
    // 0x11395a4: ldur            x0, [fp, #-8]
    // 0x11395a8: ArrayStore: r1[r4] = r0  ; List_4
    //     0x11395a8: add             x25, x1, x4, lsl #2
    //     0x11395ac: add             x25, x25, #0xf
    //     0x11395b0: str             w0, [x25]
    //     0x11395b4: tbz             w0, #0, #0x11395d0
    //     0x11395b8: ldurb           w16, [x1, #-1]
    //     0x11395bc: ldurb           w17, [x0, #-1]
    //     0x11395c0: and             x16, x17, x16, lsr #2
    //     0x11395c4: tst             x16, HEAP, lsr #32
    //     0x11395c8: b.eq            #0x11395d0
    //     0x11395cc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11395d0: LoadField: r0 = r3->field_7b
    //     0x11395d0: ldur            w0, [x3, #0x7b]
    // 0x11395d4: DecompressPointer r0
    //     0x11395d4: add             x0, x0, HEAP, lsl #32
    // 0x11395d8: stur            x0, [fp, #-8]
    // 0x11395dc: LoadField: r1 = r6->field_b
    //     0x11395dc: ldur            w1, [x6, #0xb]
    // 0x11395e0: r4 = LoadInt32Instr(r1)
    //     0x11395e0: sbfx            x4, x1, #1, #0x1f
    // 0x11395e4: cmp             x5, x4
    // 0x11395e8: b.ne            #0x11395f4
    // 0x11395ec: mov             x1, x2
    // 0x11395f0: r0 = _growToNextCapacity()
    //     0x11395f0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x11395f4: ldr             x3, [fp, #0x10]
    // 0x11395f8: ldur            x4, [fp, #-0x20]
    // 0x11395fc: ldur            x2, [fp, #-0x10]
    // 0x1139600: add             x5, x4, #1
    // 0x1139604: stur            x5, [fp, #-0x18]
    // 0x1139608: lsl             x0, x5, #1
    // 0x113960c: StoreField: r2->field_b = r0
    //     0x113960c: stur            w0, [x2, #0xb]
    // 0x1139610: LoadField: r6 = r2->field_f
    //     0x1139610: ldur            w6, [x2, #0xf]
    // 0x1139614: DecompressPointer r6
    //     0x1139614: add             x6, x6, HEAP, lsl #32
    // 0x1139618: mov             x1, x6
    // 0x113961c: ldur            x0, [fp, #-8]
    // 0x1139620: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139620: add             x25, x1, x4, lsl #2
    //     0x1139624: add             x25, x25, #0xf
    //     0x1139628: str             w0, [x25]
    //     0x113962c: tbz             w0, #0, #0x1139648
    //     0x1139630: ldurb           w16, [x1, #-1]
    //     0x1139634: ldurb           w17, [x0, #-1]
    //     0x1139638: and             x16, x17, x16, lsr #2
    //     0x113963c: tst             x16, HEAP, lsr #32
    //     0x1139640: b.eq            #0x1139648
    //     0x1139644: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139648: LoadField: r0 = r3->field_7f
    //     0x1139648: ldur            w0, [x3, #0x7f]
    // 0x113964c: DecompressPointer r0
    //     0x113964c: add             x0, x0, HEAP, lsl #32
    // 0x1139650: stur            x0, [fp, #-8]
    // 0x1139654: LoadField: r1 = r6->field_b
    //     0x1139654: ldur            w1, [x6, #0xb]
    // 0x1139658: r4 = LoadInt32Instr(r1)
    //     0x1139658: sbfx            x4, x1, #1, #0x1f
    // 0x113965c: cmp             x5, x4
    // 0x1139660: b.ne            #0x113966c
    // 0x1139664: mov             x1, x2
    // 0x1139668: r0 = _growToNextCapacity()
    //     0x1139668: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113966c: ldr             x3, [fp, #0x10]
    // 0x1139670: ldur            x4, [fp, #-0x18]
    // 0x1139674: ldur            x2, [fp, #-0x10]
    // 0x1139678: add             x5, x4, #1
    // 0x113967c: stur            x5, [fp, #-0x20]
    // 0x1139680: lsl             x0, x5, #1
    // 0x1139684: StoreField: r2->field_b = r0
    //     0x1139684: stur            w0, [x2, #0xb]
    // 0x1139688: LoadField: r6 = r2->field_f
    //     0x1139688: ldur            w6, [x2, #0xf]
    // 0x113968c: DecompressPointer r6
    //     0x113968c: add             x6, x6, HEAP, lsl #32
    // 0x1139690: mov             x1, x6
    // 0x1139694: ldur            x0, [fp, #-8]
    // 0x1139698: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139698: add             x25, x1, x4, lsl #2
    //     0x113969c: add             x25, x25, #0xf
    //     0x11396a0: str             w0, [x25]
    //     0x11396a4: tbz             w0, #0, #0x11396c0
    //     0x11396a8: ldurb           w16, [x1, #-1]
    //     0x11396ac: ldurb           w17, [x0, #-1]
    //     0x11396b0: and             x16, x17, x16, lsr #2
    //     0x11396b4: tst             x16, HEAP, lsr #32
    //     0x11396b8: b.eq            #0x11396c0
    //     0x11396bc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11396c0: LoadField: r0 = r3->field_83
    //     0x11396c0: ldur            w0, [x3, #0x83]
    // 0x11396c4: DecompressPointer r0
    //     0x11396c4: add             x0, x0, HEAP, lsl #32
    // 0x11396c8: stur            x0, [fp, #-8]
    // 0x11396cc: LoadField: r1 = r6->field_b
    //     0x11396cc: ldur            w1, [x6, #0xb]
    // 0x11396d0: r4 = LoadInt32Instr(r1)
    //     0x11396d0: sbfx            x4, x1, #1, #0x1f
    // 0x11396d4: cmp             x5, x4
    // 0x11396d8: b.ne            #0x11396e4
    // 0x11396dc: mov             x1, x2
    // 0x11396e0: r0 = _growToNextCapacity()
    //     0x11396e0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x11396e4: ldr             x3, [fp, #0x10]
    // 0x11396e8: ldur            x4, [fp, #-0x20]
    // 0x11396ec: ldur            x2, [fp, #-0x10]
    // 0x11396f0: add             x5, x4, #1
    // 0x11396f4: stur            x5, [fp, #-0x18]
    // 0x11396f8: lsl             x0, x5, #1
    // 0x11396fc: StoreField: r2->field_b = r0
    //     0x11396fc: stur            w0, [x2, #0xb]
    // 0x1139700: LoadField: r6 = r2->field_f
    //     0x1139700: ldur            w6, [x2, #0xf]
    // 0x1139704: DecompressPointer r6
    //     0x1139704: add             x6, x6, HEAP, lsl #32
    // 0x1139708: mov             x1, x6
    // 0x113970c: ldur            x0, [fp, #-8]
    // 0x1139710: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139710: add             x25, x1, x4, lsl #2
    //     0x1139714: add             x25, x25, #0xf
    //     0x1139718: str             w0, [x25]
    //     0x113971c: tbz             w0, #0, #0x1139738
    //     0x1139720: ldurb           w16, [x1, #-1]
    //     0x1139724: ldurb           w17, [x0, #-1]
    //     0x1139728: and             x16, x17, x16, lsr #2
    //     0x113972c: tst             x16, HEAP, lsr #32
    //     0x1139730: b.eq            #0x1139738
    //     0x1139734: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139738: LoadField: r0 = r3->field_87
    //     0x1139738: ldur            w0, [x3, #0x87]
    // 0x113973c: DecompressPointer r0
    //     0x113973c: add             x0, x0, HEAP, lsl #32
    // 0x1139740: stur            x0, [fp, #-8]
    // 0x1139744: LoadField: r1 = r6->field_b
    //     0x1139744: ldur            w1, [x6, #0xb]
    // 0x1139748: r4 = LoadInt32Instr(r1)
    //     0x1139748: sbfx            x4, x1, #1, #0x1f
    // 0x113974c: cmp             x5, x4
    // 0x1139750: b.ne            #0x113975c
    // 0x1139754: mov             x1, x2
    // 0x1139758: r0 = _growToNextCapacity()
    //     0x1139758: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113975c: ldr             x3, [fp, #0x10]
    // 0x1139760: ldur            x4, [fp, #-0x18]
    // 0x1139764: ldur            x2, [fp, #-0x10]
    // 0x1139768: add             x5, x4, #1
    // 0x113976c: stur            x5, [fp, #-0x20]
    // 0x1139770: lsl             x0, x5, #1
    // 0x1139774: StoreField: r2->field_b = r0
    //     0x1139774: stur            w0, [x2, #0xb]
    // 0x1139778: LoadField: r6 = r2->field_f
    //     0x1139778: ldur            w6, [x2, #0xf]
    // 0x113977c: DecompressPointer r6
    //     0x113977c: add             x6, x6, HEAP, lsl #32
    // 0x1139780: mov             x1, x6
    // 0x1139784: ldur            x0, [fp, #-8]
    // 0x1139788: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139788: add             x25, x1, x4, lsl #2
    //     0x113978c: add             x25, x25, #0xf
    //     0x1139790: str             w0, [x25]
    //     0x1139794: tbz             w0, #0, #0x11397b0
    //     0x1139798: ldurb           w16, [x1, #-1]
    //     0x113979c: ldurb           w17, [x0, #-1]
    //     0x11397a0: and             x16, x17, x16, lsr #2
    //     0x11397a4: tst             x16, HEAP, lsr #32
    //     0x11397a8: b.eq            #0x11397b0
    //     0x11397ac: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11397b0: LoadField: r0 = r3->field_8b
    //     0x11397b0: ldur            w0, [x3, #0x8b]
    // 0x11397b4: DecompressPointer r0
    //     0x11397b4: add             x0, x0, HEAP, lsl #32
    // 0x11397b8: stur            x0, [fp, #-8]
    // 0x11397bc: LoadField: r1 = r6->field_b
    //     0x11397bc: ldur            w1, [x6, #0xb]
    // 0x11397c0: r4 = LoadInt32Instr(r1)
    //     0x11397c0: sbfx            x4, x1, #1, #0x1f
    // 0x11397c4: cmp             x5, x4
    // 0x11397c8: b.ne            #0x11397d4
    // 0x11397cc: mov             x1, x2
    // 0x11397d0: r0 = _growToNextCapacity()
    //     0x11397d0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x11397d4: ldur            x3, [fp, #-0x20]
    // 0x11397d8: ldur            x2, [fp, #-0x10]
    // 0x11397dc: add             x4, x3, #1
    // 0x11397e0: stur            x4, [fp, #-0x18]
    // 0x11397e4: lsl             x0, x4, #1
    // 0x11397e8: StoreField: r2->field_b = r0
    //     0x11397e8: stur            w0, [x2, #0xb]
    // 0x11397ec: LoadField: r5 = r2->field_f
    //     0x11397ec: ldur            w5, [x2, #0xf]
    // 0x11397f0: DecompressPointer r5
    //     0x11397f0: add             x5, x5, HEAP, lsl #32
    // 0x11397f4: mov             x1, x5
    // 0x11397f8: ldur            x0, [fp, #-8]
    // 0x11397fc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x11397fc: add             x25, x1, x3, lsl #2
    //     0x1139800: add             x25, x25, #0xf
    //     0x1139804: str             w0, [x25]
    //     0x1139808: tbz             w0, #0, #0x1139824
    //     0x113980c: ldurb           w16, [x1, #-1]
    //     0x1139810: ldurb           w17, [x0, #-1]
    //     0x1139814: and             x16, x17, x16, lsr #2
    //     0x1139818: tst             x16, HEAP, lsr #32
    //     0x113981c: b.eq            #0x1139824
    //     0x1139820: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139824: LoadField: r0 = r5->field_b
    //     0x1139824: ldur            w0, [x5, #0xb]
    // 0x1139828: r1 = LoadInt32Instr(r0)
    //     0x1139828: sbfx            x1, x0, #1, #0x1f
    // 0x113982c: cmp             x4, x1
    // 0x1139830: b.ne            #0x113983c
    // 0x1139834: mov             x1, x2
    // 0x1139838: r0 = _growToNextCapacity()
    //     0x1139838: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113983c: ldr             x2, [fp, #0x10]
    // 0x1139840: ldur            x1, [fp, #-0x18]
    // 0x1139844: ldur            x0, [fp, #-0x10]
    // 0x1139848: add             x3, x1, #1
    // 0x113984c: stur            x3, [fp, #-0x20]
    // 0x1139850: lsl             x4, x3, #1
    // 0x1139854: StoreField: r0->field_b = r4
    //     0x1139854: stur            w4, [x0, #0xb]
    // 0x1139858: LoadField: r4 = r0->field_f
    //     0x1139858: ldur            w4, [x0, #0xf]
    // 0x113985c: DecompressPointer r4
    //     0x113985c: add             x4, x4, HEAP, lsl #32
    // 0x1139860: ArrayStore: r4[r1] = rNULL  ; Unknown_4
    //     0x1139860: add             x5, x4, x1, lsl #2
    //     0x1139864: stur            NULL, [x5, #0xf]
    // 0x1139868: LoadField: r5 = r2->field_93
    //     0x1139868: ldur            w5, [x2, #0x93]
    // 0x113986c: DecompressPointer r5
    //     0x113986c: add             x5, x5, HEAP, lsl #32
    // 0x1139870: stur            x5, [fp, #-8]
    // 0x1139874: LoadField: r1 = r4->field_b
    //     0x1139874: ldur            w1, [x4, #0xb]
    // 0x1139878: r4 = LoadInt32Instr(r1)
    //     0x1139878: sbfx            x4, x1, #1, #0x1f
    // 0x113987c: cmp             x3, x4
    // 0x1139880: b.ne            #0x113988c
    // 0x1139884: mov             x1, x0
    // 0x1139888: r0 = _growToNextCapacity()
    //     0x1139888: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113988c: ldr             x3, [fp, #0x10]
    // 0x1139890: ldur            x4, [fp, #-0x20]
    // 0x1139894: ldur            x2, [fp, #-0x10]
    // 0x1139898: add             x5, x4, #1
    // 0x113989c: stur            x5, [fp, #-0x18]
    // 0x11398a0: lsl             x0, x5, #1
    // 0x11398a4: StoreField: r2->field_b = r0
    //     0x11398a4: stur            w0, [x2, #0xb]
    // 0x11398a8: LoadField: r6 = r2->field_f
    //     0x11398a8: ldur            w6, [x2, #0xf]
    // 0x11398ac: DecompressPointer r6
    //     0x11398ac: add             x6, x6, HEAP, lsl #32
    // 0x11398b0: mov             x1, x6
    // 0x11398b4: ldur            x0, [fp, #-8]
    // 0x11398b8: ArrayStore: r1[r4] = r0  ; List_4
    //     0x11398b8: add             x25, x1, x4, lsl #2
    //     0x11398bc: add             x25, x25, #0xf
    //     0x11398c0: str             w0, [x25]
    //     0x11398c4: tbz             w0, #0, #0x11398e0
    //     0x11398c8: ldurb           w16, [x1, #-1]
    //     0x11398cc: ldurb           w17, [x0, #-1]
    //     0x11398d0: and             x16, x17, x16, lsr #2
    //     0x11398d4: tst             x16, HEAP, lsr #32
    //     0x11398d8: b.eq            #0x11398e0
    //     0x11398dc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11398e0: LoadField: r0 = r3->field_97
    //     0x11398e0: ldur            w0, [x3, #0x97]
    // 0x11398e4: DecompressPointer r0
    //     0x11398e4: add             x0, x0, HEAP, lsl #32
    // 0x11398e8: stur            x0, [fp, #-8]
    // 0x11398ec: LoadField: r1 = r6->field_b
    //     0x11398ec: ldur            w1, [x6, #0xb]
    // 0x11398f0: r4 = LoadInt32Instr(r1)
    //     0x11398f0: sbfx            x4, x1, #1, #0x1f
    // 0x11398f4: cmp             x5, x4
    // 0x11398f8: b.ne            #0x1139904
    // 0x11398fc: mov             x1, x2
    // 0x1139900: r0 = _growToNextCapacity()
    //     0x1139900: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1139904: ldr             x3, [fp, #0x10]
    // 0x1139908: ldur            x4, [fp, #-0x18]
    // 0x113990c: ldur            x2, [fp, #-0x10]
    // 0x1139910: add             x5, x4, #1
    // 0x1139914: stur            x5, [fp, #-0x20]
    // 0x1139918: lsl             x0, x5, #1
    // 0x113991c: StoreField: r2->field_b = r0
    //     0x113991c: stur            w0, [x2, #0xb]
    // 0x1139920: LoadField: r6 = r2->field_f
    //     0x1139920: ldur            w6, [x2, #0xf]
    // 0x1139924: DecompressPointer r6
    //     0x1139924: add             x6, x6, HEAP, lsl #32
    // 0x1139928: mov             x1, x6
    // 0x113992c: ldur            x0, [fp, #-8]
    // 0x1139930: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139930: add             x25, x1, x4, lsl #2
    //     0x1139934: add             x25, x25, #0xf
    //     0x1139938: str             w0, [x25]
    //     0x113993c: tbz             w0, #0, #0x1139958
    //     0x1139940: ldurb           w16, [x1, #-1]
    //     0x1139944: ldurb           w17, [x0, #-1]
    //     0x1139948: and             x16, x17, x16, lsr #2
    //     0x113994c: tst             x16, HEAP, lsr #32
    //     0x1139950: b.eq            #0x1139958
    //     0x1139954: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139958: LoadField: r0 = r3->field_9b
    //     0x1139958: ldur            w0, [x3, #0x9b]
    // 0x113995c: DecompressPointer r0
    //     0x113995c: add             x0, x0, HEAP, lsl #32
    // 0x1139960: stur            x0, [fp, #-8]
    // 0x1139964: LoadField: r1 = r6->field_b
    //     0x1139964: ldur            w1, [x6, #0xb]
    // 0x1139968: r4 = LoadInt32Instr(r1)
    //     0x1139968: sbfx            x4, x1, #1, #0x1f
    // 0x113996c: cmp             x5, x4
    // 0x1139970: b.ne            #0x113997c
    // 0x1139974: mov             x1, x2
    // 0x1139978: r0 = _growToNextCapacity()
    //     0x1139978: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113997c: ldr             x3, [fp, #0x10]
    // 0x1139980: ldur            x4, [fp, #-0x20]
    // 0x1139984: ldur            x2, [fp, #-0x10]
    // 0x1139988: add             x5, x4, #1
    // 0x113998c: stur            x5, [fp, #-0x18]
    // 0x1139990: lsl             x0, x5, #1
    // 0x1139994: StoreField: r2->field_b = r0
    //     0x1139994: stur            w0, [x2, #0xb]
    // 0x1139998: LoadField: r6 = r2->field_f
    //     0x1139998: ldur            w6, [x2, #0xf]
    // 0x113999c: DecompressPointer r6
    //     0x113999c: add             x6, x6, HEAP, lsl #32
    // 0x11399a0: mov             x1, x6
    // 0x11399a4: ldur            x0, [fp, #-8]
    // 0x11399a8: ArrayStore: r1[r4] = r0  ; List_4
    //     0x11399a8: add             x25, x1, x4, lsl #2
    //     0x11399ac: add             x25, x25, #0xf
    //     0x11399b0: str             w0, [x25]
    //     0x11399b4: tbz             w0, #0, #0x11399d0
    //     0x11399b8: ldurb           w16, [x1, #-1]
    //     0x11399bc: ldurb           w17, [x0, #-1]
    //     0x11399c0: and             x16, x17, x16, lsr #2
    //     0x11399c4: tst             x16, HEAP, lsr #32
    //     0x11399c8: b.eq            #0x11399d0
    //     0x11399cc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11399d0: LoadField: r0 = r3->field_9f
    //     0x11399d0: ldur            w0, [x3, #0x9f]
    // 0x11399d4: DecompressPointer r0
    //     0x11399d4: add             x0, x0, HEAP, lsl #32
    // 0x11399d8: stur            x0, [fp, #-8]
    // 0x11399dc: LoadField: r1 = r6->field_b
    //     0x11399dc: ldur            w1, [x6, #0xb]
    // 0x11399e0: r4 = LoadInt32Instr(r1)
    //     0x11399e0: sbfx            x4, x1, #1, #0x1f
    // 0x11399e4: cmp             x5, x4
    // 0x11399e8: b.ne            #0x11399f4
    // 0x11399ec: mov             x1, x2
    // 0x11399f0: r0 = _growToNextCapacity()
    //     0x11399f0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x11399f4: ldr             x3, [fp, #0x10]
    // 0x11399f8: ldur            x4, [fp, #-0x18]
    // 0x11399fc: ldur            x2, [fp, #-0x10]
    // 0x1139a00: add             x5, x4, #1
    // 0x1139a04: stur            x5, [fp, #-0x20]
    // 0x1139a08: lsl             x0, x5, #1
    // 0x1139a0c: StoreField: r2->field_b = r0
    //     0x1139a0c: stur            w0, [x2, #0xb]
    // 0x1139a10: LoadField: r6 = r2->field_f
    //     0x1139a10: ldur            w6, [x2, #0xf]
    // 0x1139a14: DecompressPointer r6
    //     0x1139a14: add             x6, x6, HEAP, lsl #32
    // 0x1139a18: mov             x1, x6
    // 0x1139a1c: ldur            x0, [fp, #-8]
    // 0x1139a20: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139a20: add             x25, x1, x4, lsl #2
    //     0x1139a24: add             x25, x25, #0xf
    //     0x1139a28: str             w0, [x25]
    //     0x1139a2c: tbz             w0, #0, #0x1139a48
    //     0x1139a30: ldurb           w16, [x1, #-1]
    //     0x1139a34: ldurb           w17, [x0, #-1]
    //     0x1139a38: and             x16, x17, x16, lsr #2
    //     0x1139a3c: tst             x16, HEAP, lsr #32
    //     0x1139a40: b.eq            #0x1139a48
    //     0x1139a44: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139a48: LoadField: r0 = r3->field_a3
    //     0x1139a48: ldur            w0, [x3, #0xa3]
    // 0x1139a4c: DecompressPointer r0
    //     0x1139a4c: add             x0, x0, HEAP, lsl #32
    // 0x1139a50: stur            x0, [fp, #-8]
    // 0x1139a54: LoadField: r1 = r6->field_b
    //     0x1139a54: ldur            w1, [x6, #0xb]
    // 0x1139a58: r4 = LoadInt32Instr(r1)
    //     0x1139a58: sbfx            x4, x1, #1, #0x1f
    // 0x1139a5c: cmp             x5, x4
    // 0x1139a60: b.ne            #0x1139a6c
    // 0x1139a64: mov             x1, x2
    // 0x1139a68: r0 = _growToNextCapacity()
    //     0x1139a68: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1139a6c: ldr             x3, [fp, #0x10]
    // 0x1139a70: ldur            x4, [fp, #-0x20]
    // 0x1139a74: ldur            x2, [fp, #-0x10]
    // 0x1139a78: add             x5, x4, #1
    // 0x1139a7c: stur            x5, [fp, #-0x18]
    // 0x1139a80: lsl             x0, x5, #1
    // 0x1139a84: StoreField: r2->field_b = r0
    //     0x1139a84: stur            w0, [x2, #0xb]
    // 0x1139a88: LoadField: r6 = r2->field_f
    //     0x1139a88: ldur            w6, [x2, #0xf]
    // 0x1139a8c: DecompressPointer r6
    //     0x1139a8c: add             x6, x6, HEAP, lsl #32
    // 0x1139a90: mov             x1, x6
    // 0x1139a94: ldur            x0, [fp, #-8]
    // 0x1139a98: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139a98: add             x25, x1, x4, lsl #2
    //     0x1139a9c: add             x25, x25, #0xf
    //     0x1139aa0: str             w0, [x25]
    //     0x1139aa4: tbz             w0, #0, #0x1139ac0
    //     0x1139aa8: ldurb           w16, [x1, #-1]
    //     0x1139aac: ldurb           w17, [x0, #-1]
    //     0x1139ab0: and             x16, x17, x16, lsr #2
    //     0x1139ab4: tst             x16, HEAP, lsr #32
    //     0x1139ab8: b.eq            #0x1139ac0
    //     0x1139abc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139ac0: LoadField: r0 = r3->field_a7
    //     0x1139ac0: ldur            w0, [x3, #0xa7]
    // 0x1139ac4: DecompressPointer r0
    //     0x1139ac4: add             x0, x0, HEAP, lsl #32
    // 0x1139ac8: stur            x0, [fp, #-8]
    // 0x1139acc: LoadField: r1 = r6->field_b
    //     0x1139acc: ldur            w1, [x6, #0xb]
    // 0x1139ad0: r4 = LoadInt32Instr(r1)
    //     0x1139ad0: sbfx            x4, x1, #1, #0x1f
    // 0x1139ad4: cmp             x5, x4
    // 0x1139ad8: b.ne            #0x1139ae4
    // 0x1139adc: mov             x1, x2
    // 0x1139ae0: r0 = _growToNextCapacity()
    //     0x1139ae0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1139ae4: ldr             x3, [fp, #0x10]
    // 0x1139ae8: ldur            x4, [fp, #-0x18]
    // 0x1139aec: ldur            x2, [fp, #-0x10]
    // 0x1139af0: add             x5, x4, #1
    // 0x1139af4: stur            x5, [fp, #-0x20]
    // 0x1139af8: lsl             x0, x5, #1
    // 0x1139afc: StoreField: r2->field_b = r0
    //     0x1139afc: stur            w0, [x2, #0xb]
    // 0x1139b00: LoadField: r6 = r2->field_f
    //     0x1139b00: ldur            w6, [x2, #0xf]
    // 0x1139b04: DecompressPointer r6
    //     0x1139b04: add             x6, x6, HEAP, lsl #32
    // 0x1139b08: mov             x1, x6
    // 0x1139b0c: ldur            x0, [fp, #-8]
    // 0x1139b10: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139b10: add             x25, x1, x4, lsl #2
    //     0x1139b14: add             x25, x25, #0xf
    //     0x1139b18: str             w0, [x25]
    //     0x1139b1c: tbz             w0, #0, #0x1139b38
    //     0x1139b20: ldurb           w16, [x1, #-1]
    //     0x1139b24: ldurb           w17, [x0, #-1]
    //     0x1139b28: and             x16, x17, x16, lsr #2
    //     0x1139b2c: tst             x16, HEAP, lsr #32
    //     0x1139b30: b.eq            #0x1139b38
    //     0x1139b34: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139b38: LoadField: r0 = r3->field_ab
    //     0x1139b38: ldur            w0, [x3, #0xab]
    // 0x1139b3c: DecompressPointer r0
    //     0x1139b3c: add             x0, x0, HEAP, lsl #32
    // 0x1139b40: stur            x0, [fp, #-8]
    // 0x1139b44: LoadField: r1 = r6->field_b
    //     0x1139b44: ldur            w1, [x6, #0xb]
    // 0x1139b48: r4 = LoadInt32Instr(r1)
    //     0x1139b48: sbfx            x4, x1, #1, #0x1f
    // 0x1139b4c: cmp             x5, x4
    // 0x1139b50: b.ne            #0x1139b5c
    // 0x1139b54: mov             x1, x2
    // 0x1139b58: r0 = _growToNextCapacity()
    //     0x1139b58: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1139b5c: ldr             x3, [fp, #0x10]
    // 0x1139b60: ldur            x4, [fp, #-0x20]
    // 0x1139b64: ldur            x2, [fp, #-0x10]
    // 0x1139b68: add             x5, x4, #1
    // 0x1139b6c: stur            x5, [fp, #-0x18]
    // 0x1139b70: lsl             x0, x5, #1
    // 0x1139b74: StoreField: r2->field_b = r0
    //     0x1139b74: stur            w0, [x2, #0xb]
    // 0x1139b78: LoadField: r6 = r2->field_f
    //     0x1139b78: ldur            w6, [x2, #0xf]
    // 0x1139b7c: DecompressPointer r6
    //     0x1139b7c: add             x6, x6, HEAP, lsl #32
    // 0x1139b80: mov             x1, x6
    // 0x1139b84: ldur            x0, [fp, #-8]
    // 0x1139b88: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139b88: add             x25, x1, x4, lsl #2
    //     0x1139b8c: add             x25, x25, #0xf
    //     0x1139b90: str             w0, [x25]
    //     0x1139b94: tbz             w0, #0, #0x1139bb0
    //     0x1139b98: ldurb           w16, [x1, #-1]
    //     0x1139b9c: ldurb           w17, [x0, #-1]
    //     0x1139ba0: and             x16, x17, x16, lsr #2
    //     0x1139ba4: tst             x16, HEAP, lsr #32
    //     0x1139ba8: b.eq            #0x1139bb0
    //     0x1139bac: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139bb0: LoadField: r0 = r3->field_af
    //     0x1139bb0: ldur            w0, [x3, #0xaf]
    // 0x1139bb4: DecompressPointer r0
    //     0x1139bb4: add             x0, x0, HEAP, lsl #32
    // 0x1139bb8: stur            x0, [fp, #-8]
    // 0x1139bbc: LoadField: r1 = r6->field_b
    //     0x1139bbc: ldur            w1, [x6, #0xb]
    // 0x1139bc0: r4 = LoadInt32Instr(r1)
    //     0x1139bc0: sbfx            x4, x1, #1, #0x1f
    // 0x1139bc4: cmp             x5, x4
    // 0x1139bc8: b.ne            #0x1139bd4
    // 0x1139bcc: mov             x1, x2
    // 0x1139bd0: r0 = _growToNextCapacity()
    //     0x1139bd0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1139bd4: ldr             x3, [fp, #0x10]
    // 0x1139bd8: ldur            x4, [fp, #-0x18]
    // 0x1139bdc: ldur            x2, [fp, #-0x10]
    // 0x1139be0: add             x5, x4, #1
    // 0x1139be4: stur            x5, [fp, #-0x20]
    // 0x1139be8: lsl             x0, x5, #1
    // 0x1139bec: StoreField: r2->field_b = r0
    //     0x1139bec: stur            w0, [x2, #0xb]
    // 0x1139bf0: LoadField: r6 = r2->field_f
    //     0x1139bf0: ldur            w6, [x2, #0xf]
    // 0x1139bf4: DecompressPointer r6
    //     0x1139bf4: add             x6, x6, HEAP, lsl #32
    // 0x1139bf8: mov             x1, x6
    // 0x1139bfc: ldur            x0, [fp, #-8]
    // 0x1139c00: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139c00: add             x25, x1, x4, lsl #2
    //     0x1139c04: add             x25, x25, #0xf
    //     0x1139c08: str             w0, [x25]
    //     0x1139c0c: tbz             w0, #0, #0x1139c28
    //     0x1139c10: ldurb           w16, [x1, #-1]
    //     0x1139c14: ldurb           w17, [x0, #-1]
    //     0x1139c18: and             x16, x17, x16, lsr #2
    //     0x1139c1c: tst             x16, HEAP, lsr #32
    //     0x1139c20: b.eq            #0x1139c28
    //     0x1139c24: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139c28: LoadField: r0 = r3->field_b3
    //     0x1139c28: ldur            w0, [x3, #0xb3]
    // 0x1139c2c: DecompressPointer r0
    //     0x1139c2c: add             x0, x0, HEAP, lsl #32
    // 0x1139c30: stur            x0, [fp, #-8]
    // 0x1139c34: LoadField: r1 = r6->field_b
    //     0x1139c34: ldur            w1, [x6, #0xb]
    // 0x1139c38: r4 = LoadInt32Instr(r1)
    //     0x1139c38: sbfx            x4, x1, #1, #0x1f
    // 0x1139c3c: cmp             x5, x4
    // 0x1139c40: b.ne            #0x1139c4c
    // 0x1139c44: mov             x1, x2
    // 0x1139c48: r0 = _growToNextCapacity()
    //     0x1139c48: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1139c4c: ldr             x3, [fp, #0x10]
    // 0x1139c50: ldur            x4, [fp, #-0x20]
    // 0x1139c54: ldur            x2, [fp, #-0x10]
    // 0x1139c58: add             x5, x4, #1
    // 0x1139c5c: stur            x5, [fp, #-0x18]
    // 0x1139c60: lsl             x0, x5, #1
    // 0x1139c64: StoreField: r2->field_b = r0
    //     0x1139c64: stur            w0, [x2, #0xb]
    // 0x1139c68: LoadField: r6 = r2->field_f
    //     0x1139c68: ldur            w6, [x2, #0xf]
    // 0x1139c6c: DecompressPointer r6
    //     0x1139c6c: add             x6, x6, HEAP, lsl #32
    // 0x1139c70: mov             x1, x6
    // 0x1139c74: ldur            x0, [fp, #-8]
    // 0x1139c78: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139c78: add             x25, x1, x4, lsl #2
    //     0x1139c7c: add             x25, x25, #0xf
    //     0x1139c80: str             w0, [x25]
    //     0x1139c84: tbz             w0, #0, #0x1139ca0
    //     0x1139c88: ldurb           w16, [x1, #-1]
    //     0x1139c8c: ldurb           w17, [x0, #-1]
    //     0x1139c90: and             x16, x17, x16, lsr #2
    //     0x1139c94: tst             x16, HEAP, lsr #32
    //     0x1139c98: b.eq            #0x1139ca0
    //     0x1139c9c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139ca0: LoadField: r0 = r3->field_b7
    //     0x1139ca0: ldur            w0, [x3, #0xb7]
    // 0x1139ca4: DecompressPointer r0
    //     0x1139ca4: add             x0, x0, HEAP, lsl #32
    // 0x1139ca8: stur            x0, [fp, #-8]
    // 0x1139cac: LoadField: r1 = r6->field_b
    //     0x1139cac: ldur            w1, [x6, #0xb]
    // 0x1139cb0: r4 = LoadInt32Instr(r1)
    //     0x1139cb0: sbfx            x4, x1, #1, #0x1f
    // 0x1139cb4: cmp             x5, x4
    // 0x1139cb8: b.ne            #0x1139cc4
    // 0x1139cbc: mov             x1, x2
    // 0x1139cc0: r0 = _growToNextCapacity()
    //     0x1139cc0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1139cc4: ldr             x3, [fp, #0x10]
    // 0x1139cc8: ldur            x4, [fp, #-0x18]
    // 0x1139ccc: ldur            x2, [fp, #-0x10]
    // 0x1139cd0: add             x5, x4, #1
    // 0x1139cd4: stur            x5, [fp, #-0x20]
    // 0x1139cd8: lsl             x0, x5, #1
    // 0x1139cdc: StoreField: r2->field_b = r0
    //     0x1139cdc: stur            w0, [x2, #0xb]
    // 0x1139ce0: LoadField: r6 = r2->field_f
    //     0x1139ce0: ldur            w6, [x2, #0xf]
    // 0x1139ce4: DecompressPointer r6
    //     0x1139ce4: add             x6, x6, HEAP, lsl #32
    // 0x1139ce8: mov             x1, x6
    // 0x1139cec: ldur            x0, [fp, #-8]
    // 0x1139cf0: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139cf0: add             x25, x1, x4, lsl #2
    //     0x1139cf4: add             x25, x25, #0xf
    //     0x1139cf8: str             w0, [x25]
    //     0x1139cfc: tbz             w0, #0, #0x1139d18
    //     0x1139d00: ldurb           w16, [x1, #-1]
    //     0x1139d04: ldurb           w17, [x0, #-1]
    //     0x1139d08: and             x16, x17, x16, lsr #2
    //     0x1139d0c: tst             x16, HEAP, lsr #32
    //     0x1139d10: b.eq            #0x1139d18
    //     0x1139d14: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139d18: LoadField: r0 = r3->field_bb
    //     0x1139d18: ldur            w0, [x3, #0xbb]
    // 0x1139d1c: DecompressPointer r0
    //     0x1139d1c: add             x0, x0, HEAP, lsl #32
    // 0x1139d20: stur            x0, [fp, #-8]
    // 0x1139d24: LoadField: r1 = r6->field_b
    //     0x1139d24: ldur            w1, [x6, #0xb]
    // 0x1139d28: r4 = LoadInt32Instr(r1)
    //     0x1139d28: sbfx            x4, x1, #1, #0x1f
    // 0x1139d2c: cmp             x5, x4
    // 0x1139d30: b.ne            #0x1139d3c
    // 0x1139d34: mov             x1, x2
    // 0x1139d38: r0 = _growToNextCapacity()
    //     0x1139d38: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1139d3c: ldr             x3, [fp, #0x10]
    // 0x1139d40: ldur            x4, [fp, #-0x20]
    // 0x1139d44: ldur            x2, [fp, #-0x10]
    // 0x1139d48: add             x5, x4, #1
    // 0x1139d4c: stur            x5, [fp, #-0x18]
    // 0x1139d50: lsl             x0, x5, #1
    // 0x1139d54: StoreField: r2->field_b = r0
    //     0x1139d54: stur            w0, [x2, #0xb]
    // 0x1139d58: LoadField: r6 = r2->field_f
    //     0x1139d58: ldur            w6, [x2, #0xf]
    // 0x1139d5c: DecompressPointer r6
    //     0x1139d5c: add             x6, x6, HEAP, lsl #32
    // 0x1139d60: mov             x1, x6
    // 0x1139d64: ldur            x0, [fp, #-8]
    // 0x1139d68: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139d68: add             x25, x1, x4, lsl #2
    //     0x1139d6c: add             x25, x25, #0xf
    //     0x1139d70: str             w0, [x25]
    //     0x1139d74: tbz             w0, #0, #0x1139d90
    //     0x1139d78: ldurb           w16, [x1, #-1]
    //     0x1139d7c: ldurb           w17, [x0, #-1]
    //     0x1139d80: and             x16, x17, x16, lsr #2
    //     0x1139d84: tst             x16, HEAP, lsr #32
    //     0x1139d88: b.eq            #0x1139d90
    //     0x1139d8c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139d90: LoadField: r0 = r3->field_bf
    //     0x1139d90: ldur            w0, [x3, #0xbf]
    // 0x1139d94: DecompressPointer r0
    //     0x1139d94: add             x0, x0, HEAP, lsl #32
    // 0x1139d98: stur            x0, [fp, #-8]
    // 0x1139d9c: LoadField: r1 = r6->field_b
    //     0x1139d9c: ldur            w1, [x6, #0xb]
    // 0x1139da0: r4 = LoadInt32Instr(r1)
    //     0x1139da0: sbfx            x4, x1, #1, #0x1f
    // 0x1139da4: cmp             x5, x4
    // 0x1139da8: b.ne            #0x1139db4
    // 0x1139dac: mov             x1, x2
    // 0x1139db0: r0 = _growToNextCapacity()
    //     0x1139db0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1139db4: ldr             x3, [fp, #0x10]
    // 0x1139db8: ldur            x4, [fp, #-0x18]
    // 0x1139dbc: ldur            x2, [fp, #-0x10]
    // 0x1139dc0: add             x5, x4, #1
    // 0x1139dc4: stur            x5, [fp, #-0x20]
    // 0x1139dc8: lsl             x0, x5, #1
    // 0x1139dcc: StoreField: r2->field_b = r0
    //     0x1139dcc: stur            w0, [x2, #0xb]
    // 0x1139dd0: LoadField: r6 = r2->field_f
    //     0x1139dd0: ldur            w6, [x2, #0xf]
    // 0x1139dd4: DecompressPointer r6
    //     0x1139dd4: add             x6, x6, HEAP, lsl #32
    // 0x1139dd8: mov             x1, x6
    // 0x1139ddc: ldur            x0, [fp, #-8]
    // 0x1139de0: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139de0: add             x25, x1, x4, lsl #2
    //     0x1139de4: add             x25, x25, #0xf
    //     0x1139de8: str             w0, [x25]
    //     0x1139dec: tbz             w0, #0, #0x1139e08
    //     0x1139df0: ldurb           w16, [x1, #-1]
    //     0x1139df4: ldurb           w17, [x0, #-1]
    //     0x1139df8: and             x16, x17, x16, lsr #2
    //     0x1139dfc: tst             x16, HEAP, lsr #32
    //     0x1139e00: b.eq            #0x1139e08
    //     0x1139e04: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139e08: LoadField: r0 = r3->field_c3
    //     0x1139e08: ldur            w0, [x3, #0xc3]
    // 0x1139e0c: DecompressPointer r0
    //     0x1139e0c: add             x0, x0, HEAP, lsl #32
    // 0x1139e10: stur            x0, [fp, #-8]
    // 0x1139e14: LoadField: r1 = r6->field_b
    //     0x1139e14: ldur            w1, [x6, #0xb]
    // 0x1139e18: r4 = LoadInt32Instr(r1)
    //     0x1139e18: sbfx            x4, x1, #1, #0x1f
    // 0x1139e1c: cmp             x5, x4
    // 0x1139e20: b.ne            #0x1139e2c
    // 0x1139e24: mov             x1, x2
    // 0x1139e28: r0 = _growToNextCapacity()
    //     0x1139e28: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1139e2c: ldr             x3, [fp, #0x10]
    // 0x1139e30: ldur            x4, [fp, #-0x20]
    // 0x1139e34: ldur            x2, [fp, #-0x10]
    // 0x1139e38: add             x5, x4, #1
    // 0x1139e3c: stur            x5, [fp, #-0x18]
    // 0x1139e40: lsl             x0, x5, #1
    // 0x1139e44: StoreField: r2->field_b = r0
    //     0x1139e44: stur            w0, [x2, #0xb]
    // 0x1139e48: LoadField: r6 = r2->field_f
    //     0x1139e48: ldur            w6, [x2, #0xf]
    // 0x1139e4c: DecompressPointer r6
    //     0x1139e4c: add             x6, x6, HEAP, lsl #32
    // 0x1139e50: mov             x1, x6
    // 0x1139e54: ldur            x0, [fp, #-8]
    // 0x1139e58: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139e58: add             x25, x1, x4, lsl #2
    //     0x1139e5c: add             x25, x25, #0xf
    //     0x1139e60: str             w0, [x25]
    //     0x1139e64: tbz             w0, #0, #0x1139e80
    //     0x1139e68: ldurb           w16, [x1, #-1]
    //     0x1139e6c: ldurb           w17, [x0, #-1]
    //     0x1139e70: and             x16, x17, x16, lsr #2
    //     0x1139e74: tst             x16, HEAP, lsr #32
    //     0x1139e78: b.eq            #0x1139e80
    //     0x1139e7c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139e80: LoadField: r0 = r3->field_c7
    //     0x1139e80: ldur            w0, [x3, #0xc7]
    // 0x1139e84: DecompressPointer r0
    //     0x1139e84: add             x0, x0, HEAP, lsl #32
    // 0x1139e88: stur            x0, [fp, #-8]
    // 0x1139e8c: LoadField: r1 = r6->field_b
    //     0x1139e8c: ldur            w1, [x6, #0xb]
    // 0x1139e90: r4 = LoadInt32Instr(r1)
    //     0x1139e90: sbfx            x4, x1, #1, #0x1f
    // 0x1139e94: cmp             x5, x4
    // 0x1139e98: b.ne            #0x1139ea4
    // 0x1139e9c: mov             x1, x2
    // 0x1139ea0: r0 = _growToNextCapacity()
    //     0x1139ea0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1139ea4: ldr             x3, [fp, #0x10]
    // 0x1139ea8: ldur            x4, [fp, #-0x18]
    // 0x1139eac: ldur            x2, [fp, #-0x10]
    // 0x1139eb0: add             x5, x4, #1
    // 0x1139eb4: stur            x5, [fp, #-0x20]
    // 0x1139eb8: lsl             x0, x5, #1
    // 0x1139ebc: StoreField: r2->field_b = r0
    //     0x1139ebc: stur            w0, [x2, #0xb]
    // 0x1139ec0: LoadField: r6 = r2->field_f
    //     0x1139ec0: ldur            w6, [x2, #0xf]
    // 0x1139ec4: DecompressPointer r6
    //     0x1139ec4: add             x6, x6, HEAP, lsl #32
    // 0x1139ec8: mov             x1, x6
    // 0x1139ecc: ldur            x0, [fp, #-8]
    // 0x1139ed0: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139ed0: add             x25, x1, x4, lsl #2
    //     0x1139ed4: add             x25, x25, #0xf
    //     0x1139ed8: str             w0, [x25]
    //     0x1139edc: tbz             w0, #0, #0x1139ef8
    //     0x1139ee0: ldurb           w16, [x1, #-1]
    //     0x1139ee4: ldurb           w17, [x0, #-1]
    //     0x1139ee8: and             x16, x17, x16, lsr #2
    //     0x1139eec: tst             x16, HEAP, lsr #32
    //     0x1139ef0: b.eq            #0x1139ef8
    //     0x1139ef4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139ef8: LoadField: r0 = r3->field_cb
    //     0x1139ef8: ldur            w0, [x3, #0xcb]
    // 0x1139efc: DecompressPointer r0
    //     0x1139efc: add             x0, x0, HEAP, lsl #32
    // 0x1139f00: stur            x0, [fp, #-8]
    // 0x1139f04: LoadField: r1 = r6->field_b
    //     0x1139f04: ldur            w1, [x6, #0xb]
    // 0x1139f08: r4 = LoadInt32Instr(r1)
    //     0x1139f08: sbfx            x4, x1, #1, #0x1f
    // 0x1139f0c: cmp             x5, x4
    // 0x1139f10: b.ne            #0x1139f1c
    // 0x1139f14: mov             x1, x2
    // 0x1139f18: r0 = _growToNextCapacity()
    //     0x1139f18: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1139f1c: ldr             x3, [fp, #0x10]
    // 0x1139f20: ldur            x4, [fp, #-0x20]
    // 0x1139f24: ldur            x2, [fp, #-0x10]
    // 0x1139f28: add             x5, x4, #1
    // 0x1139f2c: stur            x5, [fp, #-0x18]
    // 0x1139f30: lsl             x0, x5, #1
    // 0x1139f34: StoreField: r2->field_b = r0
    //     0x1139f34: stur            w0, [x2, #0xb]
    // 0x1139f38: LoadField: r6 = r2->field_f
    //     0x1139f38: ldur            w6, [x2, #0xf]
    // 0x1139f3c: DecompressPointer r6
    //     0x1139f3c: add             x6, x6, HEAP, lsl #32
    // 0x1139f40: mov             x1, x6
    // 0x1139f44: ldur            x0, [fp, #-8]
    // 0x1139f48: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139f48: add             x25, x1, x4, lsl #2
    //     0x1139f4c: add             x25, x25, #0xf
    //     0x1139f50: str             w0, [x25]
    //     0x1139f54: tbz             w0, #0, #0x1139f70
    //     0x1139f58: ldurb           w16, [x1, #-1]
    //     0x1139f5c: ldurb           w17, [x0, #-1]
    //     0x1139f60: and             x16, x17, x16, lsr #2
    //     0x1139f64: tst             x16, HEAP, lsr #32
    //     0x1139f68: b.eq            #0x1139f70
    //     0x1139f6c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139f70: LoadField: r0 = r3->field_cf
    //     0x1139f70: ldur            w0, [x3, #0xcf]
    // 0x1139f74: DecompressPointer r0
    //     0x1139f74: add             x0, x0, HEAP, lsl #32
    // 0x1139f78: stur            x0, [fp, #-8]
    // 0x1139f7c: LoadField: r1 = r6->field_b
    //     0x1139f7c: ldur            w1, [x6, #0xb]
    // 0x1139f80: r4 = LoadInt32Instr(r1)
    //     0x1139f80: sbfx            x4, x1, #1, #0x1f
    // 0x1139f84: cmp             x5, x4
    // 0x1139f88: b.ne            #0x1139f94
    // 0x1139f8c: mov             x1, x2
    // 0x1139f90: r0 = _growToNextCapacity()
    //     0x1139f90: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1139f94: ldr             x3, [fp, #0x10]
    // 0x1139f98: ldur            x4, [fp, #-0x18]
    // 0x1139f9c: ldur            x2, [fp, #-0x10]
    // 0x1139fa0: add             x5, x4, #1
    // 0x1139fa4: stur            x5, [fp, #-0x20]
    // 0x1139fa8: lsl             x0, x5, #1
    // 0x1139fac: StoreField: r2->field_b = r0
    //     0x1139fac: stur            w0, [x2, #0xb]
    // 0x1139fb0: LoadField: r6 = r2->field_f
    //     0x1139fb0: ldur            w6, [x2, #0xf]
    // 0x1139fb4: DecompressPointer r6
    //     0x1139fb4: add             x6, x6, HEAP, lsl #32
    // 0x1139fb8: mov             x1, x6
    // 0x1139fbc: ldur            x0, [fp, #-8]
    // 0x1139fc0: ArrayStore: r1[r4] = r0  ; List_4
    //     0x1139fc0: add             x25, x1, x4, lsl #2
    //     0x1139fc4: add             x25, x25, #0xf
    //     0x1139fc8: str             w0, [x25]
    //     0x1139fcc: tbz             w0, #0, #0x1139fe8
    //     0x1139fd0: ldurb           w16, [x1, #-1]
    //     0x1139fd4: ldurb           w17, [x0, #-1]
    //     0x1139fd8: and             x16, x17, x16, lsr #2
    //     0x1139fdc: tst             x16, HEAP, lsr #32
    //     0x1139fe0: b.eq            #0x1139fe8
    //     0x1139fe4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1139fe8: LoadField: r0 = r3->field_d3
    //     0x1139fe8: ldur            w0, [x3, #0xd3]
    // 0x1139fec: DecompressPointer r0
    //     0x1139fec: add             x0, x0, HEAP, lsl #32
    // 0x1139ff0: stur            x0, [fp, #-8]
    // 0x1139ff4: LoadField: r1 = r6->field_b
    //     0x1139ff4: ldur            w1, [x6, #0xb]
    // 0x1139ff8: r4 = LoadInt32Instr(r1)
    //     0x1139ff8: sbfx            x4, x1, #1, #0x1f
    // 0x1139ffc: cmp             x5, x4
    // 0x113a000: b.ne            #0x113a00c
    // 0x113a004: mov             x1, x2
    // 0x113a008: r0 = _growToNextCapacity()
    //     0x113a008: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113a00c: ldr             x3, [fp, #0x10]
    // 0x113a010: ldur            x4, [fp, #-0x20]
    // 0x113a014: ldur            x2, [fp, #-0x10]
    // 0x113a018: add             x5, x4, #1
    // 0x113a01c: stur            x5, [fp, #-0x18]
    // 0x113a020: lsl             x0, x5, #1
    // 0x113a024: StoreField: r2->field_b = r0
    //     0x113a024: stur            w0, [x2, #0xb]
    // 0x113a028: LoadField: r6 = r2->field_f
    //     0x113a028: ldur            w6, [x2, #0xf]
    // 0x113a02c: DecompressPointer r6
    //     0x113a02c: add             x6, x6, HEAP, lsl #32
    // 0x113a030: mov             x1, x6
    // 0x113a034: ldur            x0, [fp, #-8]
    // 0x113a038: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113a038: add             x25, x1, x4, lsl #2
    //     0x113a03c: add             x25, x25, #0xf
    //     0x113a040: str             w0, [x25]
    //     0x113a044: tbz             w0, #0, #0x113a060
    //     0x113a048: ldurb           w16, [x1, #-1]
    //     0x113a04c: ldurb           w17, [x0, #-1]
    //     0x113a050: and             x16, x17, x16, lsr #2
    //     0x113a054: tst             x16, HEAP, lsr #32
    //     0x113a058: b.eq            #0x113a060
    //     0x113a05c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113a060: LoadField: r0 = r3->field_d7
    //     0x113a060: ldur            w0, [x3, #0xd7]
    // 0x113a064: DecompressPointer r0
    //     0x113a064: add             x0, x0, HEAP, lsl #32
    // 0x113a068: stur            x0, [fp, #-8]
    // 0x113a06c: LoadField: r1 = r6->field_b
    //     0x113a06c: ldur            w1, [x6, #0xb]
    // 0x113a070: r4 = LoadInt32Instr(r1)
    //     0x113a070: sbfx            x4, x1, #1, #0x1f
    // 0x113a074: cmp             x5, x4
    // 0x113a078: b.ne            #0x113a084
    // 0x113a07c: mov             x1, x2
    // 0x113a080: r0 = _growToNextCapacity()
    //     0x113a080: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113a084: ldr             x3, [fp, #0x10]
    // 0x113a088: ldur            x4, [fp, #-0x18]
    // 0x113a08c: ldur            x2, [fp, #-0x10]
    // 0x113a090: add             x5, x4, #1
    // 0x113a094: stur            x5, [fp, #-0x20]
    // 0x113a098: lsl             x0, x5, #1
    // 0x113a09c: StoreField: r2->field_b = r0
    //     0x113a09c: stur            w0, [x2, #0xb]
    // 0x113a0a0: LoadField: r6 = r2->field_f
    //     0x113a0a0: ldur            w6, [x2, #0xf]
    // 0x113a0a4: DecompressPointer r6
    //     0x113a0a4: add             x6, x6, HEAP, lsl #32
    // 0x113a0a8: mov             x1, x6
    // 0x113a0ac: ldur            x0, [fp, #-8]
    // 0x113a0b0: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113a0b0: add             x25, x1, x4, lsl #2
    //     0x113a0b4: add             x25, x25, #0xf
    //     0x113a0b8: str             w0, [x25]
    //     0x113a0bc: tbz             w0, #0, #0x113a0d8
    //     0x113a0c0: ldurb           w16, [x1, #-1]
    //     0x113a0c4: ldurb           w17, [x0, #-1]
    //     0x113a0c8: and             x16, x17, x16, lsr #2
    //     0x113a0cc: tst             x16, HEAP, lsr #32
    //     0x113a0d0: b.eq            #0x113a0d8
    //     0x113a0d4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113a0d8: LoadField: r0 = r3->field_db
    //     0x113a0d8: ldur            w0, [x3, #0xdb]
    // 0x113a0dc: DecompressPointer r0
    //     0x113a0dc: add             x0, x0, HEAP, lsl #32
    // 0x113a0e0: stur            x0, [fp, #-8]
    // 0x113a0e4: LoadField: r1 = r6->field_b
    //     0x113a0e4: ldur            w1, [x6, #0xb]
    // 0x113a0e8: r4 = LoadInt32Instr(r1)
    //     0x113a0e8: sbfx            x4, x1, #1, #0x1f
    // 0x113a0ec: cmp             x5, x4
    // 0x113a0f0: b.ne            #0x113a0fc
    // 0x113a0f4: mov             x1, x2
    // 0x113a0f8: r0 = _growToNextCapacity()
    //     0x113a0f8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113a0fc: ldr             x3, [fp, #0x10]
    // 0x113a100: ldur            x4, [fp, #-0x20]
    // 0x113a104: ldur            x2, [fp, #-0x10]
    // 0x113a108: add             x5, x4, #1
    // 0x113a10c: stur            x5, [fp, #-0x18]
    // 0x113a110: lsl             x0, x5, #1
    // 0x113a114: StoreField: r2->field_b = r0
    //     0x113a114: stur            w0, [x2, #0xb]
    // 0x113a118: LoadField: r6 = r2->field_f
    //     0x113a118: ldur            w6, [x2, #0xf]
    // 0x113a11c: DecompressPointer r6
    //     0x113a11c: add             x6, x6, HEAP, lsl #32
    // 0x113a120: mov             x1, x6
    // 0x113a124: ldur            x0, [fp, #-8]
    // 0x113a128: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113a128: add             x25, x1, x4, lsl #2
    //     0x113a12c: add             x25, x25, #0xf
    //     0x113a130: str             w0, [x25]
    //     0x113a134: tbz             w0, #0, #0x113a150
    //     0x113a138: ldurb           w16, [x1, #-1]
    //     0x113a13c: ldurb           w17, [x0, #-1]
    //     0x113a140: and             x16, x17, x16, lsr #2
    //     0x113a144: tst             x16, HEAP, lsr #32
    //     0x113a148: b.eq            #0x113a150
    //     0x113a14c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113a150: LoadField: r0 = r3->field_df
    //     0x113a150: ldur            w0, [x3, #0xdf]
    // 0x113a154: DecompressPointer r0
    //     0x113a154: add             x0, x0, HEAP, lsl #32
    // 0x113a158: stur            x0, [fp, #-8]
    // 0x113a15c: LoadField: r1 = r6->field_b
    //     0x113a15c: ldur            w1, [x6, #0xb]
    // 0x113a160: r4 = LoadInt32Instr(r1)
    //     0x113a160: sbfx            x4, x1, #1, #0x1f
    // 0x113a164: cmp             x5, x4
    // 0x113a168: b.ne            #0x113a174
    // 0x113a16c: mov             x1, x2
    // 0x113a170: r0 = _growToNextCapacity()
    //     0x113a170: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113a174: ldr             x3, [fp, #0x10]
    // 0x113a178: ldur            x4, [fp, #-0x18]
    // 0x113a17c: ldur            x2, [fp, #-0x10]
    // 0x113a180: add             x5, x4, #1
    // 0x113a184: stur            x5, [fp, #-0x20]
    // 0x113a188: lsl             x0, x5, #1
    // 0x113a18c: StoreField: r2->field_b = r0
    //     0x113a18c: stur            w0, [x2, #0xb]
    // 0x113a190: LoadField: r6 = r2->field_f
    //     0x113a190: ldur            w6, [x2, #0xf]
    // 0x113a194: DecompressPointer r6
    //     0x113a194: add             x6, x6, HEAP, lsl #32
    // 0x113a198: mov             x1, x6
    // 0x113a19c: ldur            x0, [fp, #-8]
    // 0x113a1a0: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113a1a0: add             x25, x1, x4, lsl #2
    //     0x113a1a4: add             x25, x25, #0xf
    //     0x113a1a8: str             w0, [x25]
    //     0x113a1ac: tbz             w0, #0, #0x113a1c8
    //     0x113a1b0: ldurb           w16, [x1, #-1]
    //     0x113a1b4: ldurb           w17, [x0, #-1]
    //     0x113a1b8: and             x16, x17, x16, lsr #2
    //     0x113a1bc: tst             x16, HEAP, lsr #32
    //     0x113a1c0: b.eq            #0x113a1c8
    //     0x113a1c4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113a1c8: LoadField: r0 = r3->field_e3
    //     0x113a1c8: ldur            w0, [x3, #0xe3]
    // 0x113a1cc: DecompressPointer r0
    //     0x113a1cc: add             x0, x0, HEAP, lsl #32
    // 0x113a1d0: stur            x0, [fp, #-8]
    // 0x113a1d4: LoadField: r1 = r6->field_b
    //     0x113a1d4: ldur            w1, [x6, #0xb]
    // 0x113a1d8: r4 = LoadInt32Instr(r1)
    //     0x113a1d8: sbfx            x4, x1, #1, #0x1f
    // 0x113a1dc: cmp             x5, x4
    // 0x113a1e0: b.ne            #0x113a1ec
    // 0x113a1e4: mov             x1, x2
    // 0x113a1e8: r0 = _growToNextCapacity()
    //     0x113a1e8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113a1ec: ldr             x3, [fp, #0x10]
    // 0x113a1f0: ldur            x4, [fp, #-0x20]
    // 0x113a1f4: ldur            x2, [fp, #-0x10]
    // 0x113a1f8: add             x5, x4, #1
    // 0x113a1fc: stur            x5, [fp, #-0x18]
    // 0x113a200: lsl             x0, x5, #1
    // 0x113a204: StoreField: r2->field_b = r0
    //     0x113a204: stur            w0, [x2, #0xb]
    // 0x113a208: LoadField: r6 = r2->field_f
    //     0x113a208: ldur            w6, [x2, #0xf]
    // 0x113a20c: DecompressPointer r6
    //     0x113a20c: add             x6, x6, HEAP, lsl #32
    // 0x113a210: mov             x1, x6
    // 0x113a214: ldur            x0, [fp, #-8]
    // 0x113a218: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113a218: add             x25, x1, x4, lsl #2
    //     0x113a21c: add             x25, x25, #0xf
    //     0x113a220: str             w0, [x25]
    //     0x113a224: tbz             w0, #0, #0x113a240
    //     0x113a228: ldurb           w16, [x1, #-1]
    //     0x113a22c: ldurb           w17, [x0, #-1]
    //     0x113a230: and             x16, x17, x16, lsr #2
    //     0x113a234: tst             x16, HEAP, lsr #32
    //     0x113a238: b.eq            #0x113a240
    //     0x113a23c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113a240: LoadField: r0 = r3->field_e7
    //     0x113a240: ldur            w0, [x3, #0xe7]
    // 0x113a244: DecompressPointer r0
    //     0x113a244: add             x0, x0, HEAP, lsl #32
    // 0x113a248: stur            x0, [fp, #-8]
    // 0x113a24c: LoadField: r1 = r6->field_b
    //     0x113a24c: ldur            w1, [x6, #0xb]
    // 0x113a250: r4 = LoadInt32Instr(r1)
    //     0x113a250: sbfx            x4, x1, #1, #0x1f
    // 0x113a254: cmp             x5, x4
    // 0x113a258: b.ne            #0x113a264
    // 0x113a25c: mov             x1, x2
    // 0x113a260: r0 = _growToNextCapacity()
    //     0x113a260: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113a264: ldr             x3, [fp, #0x10]
    // 0x113a268: ldur            x4, [fp, #-0x18]
    // 0x113a26c: ldur            x2, [fp, #-0x10]
    // 0x113a270: add             x5, x4, #1
    // 0x113a274: stur            x5, [fp, #-0x20]
    // 0x113a278: lsl             x0, x5, #1
    // 0x113a27c: StoreField: r2->field_b = r0
    //     0x113a27c: stur            w0, [x2, #0xb]
    // 0x113a280: LoadField: r6 = r2->field_f
    //     0x113a280: ldur            w6, [x2, #0xf]
    // 0x113a284: DecompressPointer r6
    //     0x113a284: add             x6, x6, HEAP, lsl #32
    // 0x113a288: mov             x1, x6
    // 0x113a28c: ldur            x0, [fp, #-8]
    // 0x113a290: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113a290: add             x25, x1, x4, lsl #2
    //     0x113a294: add             x25, x25, #0xf
    //     0x113a298: str             w0, [x25]
    //     0x113a29c: tbz             w0, #0, #0x113a2b8
    //     0x113a2a0: ldurb           w16, [x1, #-1]
    //     0x113a2a4: ldurb           w17, [x0, #-1]
    //     0x113a2a8: and             x16, x17, x16, lsr #2
    //     0x113a2ac: tst             x16, HEAP, lsr #32
    //     0x113a2b0: b.eq            #0x113a2b8
    //     0x113a2b4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113a2b8: LoadField: r0 = r3->field_eb
    //     0x113a2b8: ldur            w0, [x3, #0xeb]
    // 0x113a2bc: DecompressPointer r0
    //     0x113a2bc: add             x0, x0, HEAP, lsl #32
    // 0x113a2c0: stur            x0, [fp, #-8]
    // 0x113a2c4: LoadField: r1 = r6->field_b
    //     0x113a2c4: ldur            w1, [x6, #0xb]
    // 0x113a2c8: r4 = LoadInt32Instr(r1)
    //     0x113a2c8: sbfx            x4, x1, #1, #0x1f
    // 0x113a2cc: cmp             x5, x4
    // 0x113a2d0: b.ne            #0x113a2dc
    // 0x113a2d4: mov             x1, x2
    // 0x113a2d8: r0 = _growToNextCapacity()
    //     0x113a2d8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113a2dc: ldr             x3, [fp, #0x10]
    // 0x113a2e0: ldur            x4, [fp, #-0x20]
    // 0x113a2e4: ldur            x2, [fp, #-0x10]
    // 0x113a2e8: add             x5, x4, #1
    // 0x113a2ec: stur            x5, [fp, #-0x18]
    // 0x113a2f0: lsl             x0, x5, #1
    // 0x113a2f4: StoreField: r2->field_b = r0
    //     0x113a2f4: stur            w0, [x2, #0xb]
    // 0x113a2f8: LoadField: r6 = r2->field_f
    //     0x113a2f8: ldur            w6, [x2, #0xf]
    // 0x113a2fc: DecompressPointer r6
    //     0x113a2fc: add             x6, x6, HEAP, lsl #32
    // 0x113a300: mov             x1, x6
    // 0x113a304: ldur            x0, [fp, #-8]
    // 0x113a308: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113a308: add             x25, x1, x4, lsl #2
    //     0x113a30c: add             x25, x25, #0xf
    //     0x113a310: str             w0, [x25]
    //     0x113a314: tbz             w0, #0, #0x113a330
    //     0x113a318: ldurb           w16, [x1, #-1]
    //     0x113a31c: ldurb           w17, [x0, #-1]
    //     0x113a320: and             x16, x17, x16, lsr #2
    //     0x113a324: tst             x16, HEAP, lsr #32
    //     0x113a328: b.eq            #0x113a330
    //     0x113a32c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113a330: LoadField: r0 = r3->field_ef
    //     0x113a330: ldur            w0, [x3, #0xef]
    // 0x113a334: DecompressPointer r0
    //     0x113a334: add             x0, x0, HEAP, lsl #32
    // 0x113a338: stur            x0, [fp, #-8]
    // 0x113a33c: LoadField: r1 = r6->field_b
    //     0x113a33c: ldur            w1, [x6, #0xb]
    // 0x113a340: r4 = LoadInt32Instr(r1)
    //     0x113a340: sbfx            x4, x1, #1, #0x1f
    // 0x113a344: cmp             x5, x4
    // 0x113a348: b.ne            #0x113a354
    // 0x113a34c: mov             x1, x2
    // 0x113a350: r0 = _growToNextCapacity()
    //     0x113a350: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113a354: ldr             x3, [fp, #0x10]
    // 0x113a358: ldur            x4, [fp, #-0x18]
    // 0x113a35c: ldur            x2, [fp, #-0x10]
    // 0x113a360: add             x5, x4, #1
    // 0x113a364: stur            x5, [fp, #-0x20]
    // 0x113a368: lsl             x0, x5, #1
    // 0x113a36c: StoreField: r2->field_b = r0
    //     0x113a36c: stur            w0, [x2, #0xb]
    // 0x113a370: LoadField: r6 = r2->field_f
    //     0x113a370: ldur            w6, [x2, #0xf]
    // 0x113a374: DecompressPointer r6
    //     0x113a374: add             x6, x6, HEAP, lsl #32
    // 0x113a378: mov             x1, x6
    // 0x113a37c: ldur            x0, [fp, #-8]
    // 0x113a380: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113a380: add             x25, x1, x4, lsl #2
    //     0x113a384: add             x25, x25, #0xf
    //     0x113a388: str             w0, [x25]
    //     0x113a38c: tbz             w0, #0, #0x113a3a8
    //     0x113a390: ldurb           w16, [x1, #-1]
    //     0x113a394: ldurb           w17, [x0, #-1]
    //     0x113a398: and             x16, x17, x16, lsr #2
    //     0x113a39c: tst             x16, HEAP, lsr #32
    //     0x113a3a0: b.eq            #0x113a3a8
    //     0x113a3a4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113a3a8: LoadField: r0 = r3->field_f3
    //     0x113a3a8: ldur            w0, [x3, #0xf3]
    // 0x113a3ac: DecompressPointer r0
    //     0x113a3ac: add             x0, x0, HEAP, lsl #32
    // 0x113a3b0: stur            x0, [fp, #-8]
    // 0x113a3b4: LoadField: r1 = r6->field_b
    //     0x113a3b4: ldur            w1, [x6, #0xb]
    // 0x113a3b8: r4 = LoadInt32Instr(r1)
    //     0x113a3b8: sbfx            x4, x1, #1, #0x1f
    // 0x113a3bc: cmp             x5, x4
    // 0x113a3c0: b.ne            #0x113a3cc
    // 0x113a3c4: mov             x1, x2
    // 0x113a3c8: r0 = _growToNextCapacity()
    //     0x113a3c8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113a3cc: ldr             x3, [fp, #0x10]
    // 0x113a3d0: ldur            x4, [fp, #-0x20]
    // 0x113a3d4: ldur            x2, [fp, #-0x10]
    // 0x113a3d8: add             x5, x4, #1
    // 0x113a3dc: stur            x5, [fp, #-0x18]
    // 0x113a3e0: lsl             x0, x5, #1
    // 0x113a3e4: StoreField: r2->field_b = r0
    //     0x113a3e4: stur            w0, [x2, #0xb]
    // 0x113a3e8: LoadField: r6 = r2->field_f
    //     0x113a3e8: ldur            w6, [x2, #0xf]
    // 0x113a3ec: DecompressPointer r6
    //     0x113a3ec: add             x6, x6, HEAP, lsl #32
    // 0x113a3f0: mov             x1, x6
    // 0x113a3f4: ldur            x0, [fp, #-8]
    // 0x113a3f8: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113a3f8: add             x25, x1, x4, lsl #2
    //     0x113a3fc: add             x25, x25, #0xf
    //     0x113a400: str             w0, [x25]
    //     0x113a404: tbz             w0, #0, #0x113a420
    //     0x113a408: ldurb           w16, [x1, #-1]
    //     0x113a40c: ldurb           w17, [x0, #-1]
    //     0x113a410: and             x16, x17, x16, lsr #2
    //     0x113a414: tst             x16, HEAP, lsr #32
    //     0x113a418: b.eq            #0x113a420
    //     0x113a41c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113a420: LoadField: r0 = r3->field_f7
    //     0x113a420: ldur            w0, [x3, #0xf7]
    // 0x113a424: DecompressPointer r0
    //     0x113a424: add             x0, x0, HEAP, lsl #32
    // 0x113a428: stur            x0, [fp, #-8]
    // 0x113a42c: LoadField: r1 = r6->field_b
    //     0x113a42c: ldur            w1, [x6, #0xb]
    // 0x113a430: r4 = LoadInt32Instr(r1)
    //     0x113a430: sbfx            x4, x1, #1, #0x1f
    // 0x113a434: cmp             x5, x4
    // 0x113a438: b.ne            #0x113a444
    // 0x113a43c: mov             x1, x2
    // 0x113a440: r0 = _growToNextCapacity()
    //     0x113a440: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113a444: ldr             x3, [fp, #0x10]
    // 0x113a448: ldur            x4, [fp, #-0x18]
    // 0x113a44c: ldur            x2, [fp, #-0x10]
    // 0x113a450: add             x5, x4, #1
    // 0x113a454: stur            x5, [fp, #-0x20]
    // 0x113a458: lsl             x0, x5, #1
    // 0x113a45c: StoreField: r2->field_b = r0
    //     0x113a45c: stur            w0, [x2, #0xb]
    // 0x113a460: LoadField: r6 = r2->field_f
    //     0x113a460: ldur            w6, [x2, #0xf]
    // 0x113a464: DecompressPointer r6
    //     0x113a464: add             x6, x6, HEAP, lsl #32
    // 0x113a468: mov             x1, x6
    // 0x113a46c: ldur            x0, [fp, #-8]
    // 0x113a470: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113a470: add             x25, x1, x4, lsl #2
    //     0x113a474: add             x25, x25, #0xf
    //     0x113a478: str             w0, [x25]
    //     0x113a47c: tbz             w0, #0, #0x113a498
    //     0x113a480: ldurb           w16, [x1, #-1]
    //     0x113a484: ldurb           w17, [x0, #-1]
    //     0x113a488: and             x16, x17, x16, lsr #2
    //     0x113a48c: tst             x16, HEAP, lsr #32
    //     0x113a490: b.eq            #0x113a498
    //     0x113a494: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113a498: LoadField: r0 = r3->field_fb
    //     0x113a498: ldur            w0, [x3, #0xfb]
    // 0x113a49c: DecompressPointer r0
    //     0x113a49c: add             x0, x0, HEAP, lsl #32
    // 0x113a4a0: stur            x0, [fp, #-8]
    // 0x113a4a4: LoadField: r1 = r6->field_b
    //     0x113a4a4: ldur            w1, [x6, #0xb]
    // 0x113a4a8: r4 = LoadInt32Instr(r1)
    //     0x113a4a8: sbfx            x4, x1, #1, #0x1f
    // 0x113a4ac: cmp             x5, x4
    // 0x113a4b0: b.ne            #0x113a4bc
    // 0x113a4b4: mov             x1, x2
    // 0x113a4b8: r0 = _growToNextCapacity()
    //     0x113a4b8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113a4bc: ldr             x3, [fp, #0x10]
    // 0x113a4c0: ldur            x4, [fp, #-0x20]
    // 0x113a4c4: ldur            x2, [fp, #-0x10]
    // 0x113a4c8: add             x5, x4, #1
    // 0x113a4cc: stur            x5, [fp, #-0x18]
    // 0x113a4d0: lsl             x0, x5, #1
    // 0x113a4d4: StoreField: r2->field_b = r0
    //     0x113a4d4: stur            w0, [x2, #0xb]
    // 0x113a4d8: LoadField: r6 = r2->field_f
    //     0x113a4d8: ldur            w6, [x2, #0xf]
    // 0x113a4dc: DecompressPointer r6
    //     0x113a4dc: add             x6, x6, HEAP, lsl #32
    // 0x113a4e0: mov             x1, x6
    // 0x113a4e4: ldur            x0, [fp, #-8]
    // 0x113a4e8: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113a4e8: add             x25, x1, x4, lsl #2
    //     0x113a4ec: add             x25, x25, #0xf
    //     0x113a4f0: str             w0, [x25]
    //     0x113a4f4: tbz             w0, #0, #0x113a510
    //     0x113a4f8: ldurb           w16, [x1, #-1]
    //     0x113a4fc: ldurb           w17, [x0, #-1]
    //     0x113a500: and             x16, x17, x16, lsr #2
    //     0x113a504: tst             x16, HEAP, lsr #32
    //     0x113a508: b.eq            #0x113a510
    //     0x113a50c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113a510: LoadField: r0 = r3->field_ff
    //     0x113a510: ldur            w0, [x3, #0xff]
    // 0x113a514: DecompressPointer r0
    //     0x113a514: add             x0, x0, HEAP, lsl #32
    // 0x113a518: stur            x0, [fp, #-8]
    // 0x113a51c: LoadField: r1 = r6->field_b
    //     0x113a51c: ldur            w1, [x6, #0xb]
    // 0x113a520: r4 = LoadInt32Instr(r1)
    //     0x113a520: sbfx            x4, x1, #1, #0x1f
    // 0x113a524: cmp             x5, x4
    // 0x113a528: b.ne            #0x113a534
    // 0x113a52c: mov             x1, x2
    // 0x113a530: r0 = _growToNextCapacity()
    //     0x113a530: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113a534: ldr             x3, [fp, #0x10]
    // 0x113a538: ldur            x4, [fp, #-0x18]
    // 0x113a53c: ldur            x2, [fp, #-0x10]
    // 0x113a540: add             x5, x4, #1
    // 0x113a544: stur            x5, [fp, #-0x20]
    // 0x113a548: lsl             x0, x5, #1
    // 0x113a54c: StoreField: r2->field_b = r0
    //     0x113a54c: stur            w0, [x2, #0xb]
    // 0x113a550: LoadField: r6 = r2->field_f
    //     0x113a550: ldur            w6, [x2, #0xf]
    // 0x113a554: DecompressPointer r6
    //     0x113a554: add             x6, x6, HEAP, lsl #32
    // 0x113a558: mov             x1, x6
    // 0x113a55c: ldur            x0, [fp, #-8]
    // 0x113a560: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113a560: add             x25, x1, x4, lsl #2
    //     0x113a564: add             x25, x25, #0xf
    //     0x113a568: str             w0, [x25]
    //     0x113a56c: tbz             w0, #0, #0x113a588
    //     0x113a570: ldurb           w16, [x1, #-1]
    //     0x113a574: ldurb           w17, [x0, #-1]
    //     0x113a578: and             x16, x17, x16, lsr #2
    //     0x113a57c: tst             x16, HEAP, lsr #32
    //     0x113a580: b.eq            #0x113a588
    //     0x113a584: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113a588: r17 = 259
    //     0x113a588: mov             x17, #0x103
    // 0x113a58c: ldr             w0, [x3, x17]
    // 0x113a590: DecompressPointer r0
    //     0x113a590: add             x0, x0, HEAP, lsl #32
    // 0x113a594: stur            x0, [fp, #-8]
    // 0x113a598: LoadField: r1 = r6->field_b
    //     0x113a598: ldur            w1, [x6, #0xb]
    // 0x113a59c: r4 = LoadInt32Instr(r1)
    //     0x113a59c: sbfx            x4, x1, #1, #0x1f
    // 0x113a5a0: cmp             x5, x4
    // 0x113a5a4: b.ne            #0x113a5b0
    // 0x113a5a8: mov             x1, x2
    // 0x113a5ac: r0 = _growToNextCapacity()
    //     0x113a5ac: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113a5b0: ldr             x3, [fp, #0x10]
    // 0x113a5b4: ldur            x4, [fp, #-0x20]
    // 0x113a5b8: ldur            x2, [fp, #-0x10]
    // 0x113a5bc: add             x5, x4, #1
    // 0x113a5c0: stur            x5, [fp, #-0x18]
    // 0x113a5c4: lsl             x0, x5, #1
    // 0x113a5c8: StoreField: r2->field_b = r0
    //     0x113a5c8: stur            w0, [x2, #0xb]
    // 0x113a5cc: LoadField: r6 = r2->field_f
    //     0x113a5cc: ldur            w6, [x2, #0xf]
    // 0x113a5d0: DecompressPointer r6
    //     0x113a5d0: add             x6, x6, HEAP, lsl #32
    // 0x113a5d4: mov             x1, x6
    // 0x113a5d8: ldur            x0, [fp, #-8]
    // 0x113a5dc: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113a5dc: add             x25, x1, x4, lsl #2
    //     0x113a5e0: add             x25, x25, #0xf
    //     0x113a5e4: str             w0, [x25]
    //     0x113a5e8: tbz             w0, #0, #0x113a604
    //     0x113a5ec: ldurb           w16, [x1, #-1]
    //     0x113a5f0: ldurb           w17, [x0, #-1]
    //     0x113a5f4: and             x16, x17, x16, lsr #2
    //     0x113a5f8: tst             x16, HEAP, lsr #32
    //     0x113a5fc: b.eq            #0x113a604
    //     0x113a600: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113a604: r17 = 263
    //     0x113a604: mov             x17, #0x107
    // 0x113a608: ldr             w0, [x3, x17]
    // 0x113a60c: DecompressPointer r0
    //     0x113a60c: add             x0, x0, HEAP, lsl #32
    // 0x113a610: stur            x0, [fp, #-8]
    // 0x113a614: LoadField: r1 = r6->field_b
    //     0x113a614: ldur            w1, [x6, #0xb]
    // 0x113a618: r4 = LoadInt32Instr(r1)
    //     0x113a618: sbfx            x4, x1, #1, #0x1f
    // 0x113a61c: cmp             x5, x4
    // 0x113a620: b.ne            #0x113a62c
    // 0x113a624: mov             x1, x2
    // 0x113a628: r0 = _growToNextCapacity()
    //     0x113a628: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113a62c: ldr             x3, [fp, #0x10]
    // 0x113a630: ldur            x4, [fp, #-0x18]
    // 0x113a634: ldur            x2, [fp, #-0x10]
    // 0x113a638: add             x5, x4, #1
    // 0x113a63c: stur            x5, [fp, #-0x20]
    // 0x113a640: lsl             x0, x5, #1
    // 0x113a644: StoreField: r2->field_b = r0
    //     0x113a644: stur            w0, [x2, #0xb]
    // 0x113a648: LoadField: r6 = r2->field_f
    //     0x113a648: ldur            w6, [x2, #0xf]
    // 0x113a64c: DecompressPointer r6
    //     0x113a64c: add             x6, x6, HEAP, lsl #32
    // 0x113a650: mov             x1, x6
    // 0x113a654: ldur            x0, [fp, #-8]
    // 0x113a658: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113a658: add             x25, x1, x4, lsl #2
    //     0x113a65c: add             x25, x25, #0xf
    //     0x113a660: str             w0, [x25]
    //     0x113a664: tbz             w0, #0, #0x113a680
    //     0x113a668: ldurb           w16, [x1, #-1]
    //     0x113a66c: ldurb           w17, [x0, #-1]
    //     0x113a670: and             x16, x17, x16, lsr #2
    //     0x113a674: tst             x16, HEAP, lsr #32
    //     0x113a678: b.eq            #0x113a680
    //     0x113a67c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113a680: r17 = 267
    //     0x113a680: mov             x17, #0x10b
    // 0x113a684: ldr             w0, [x3, x17]
    // 0x113a688: DecompressPointer r0
    //     0x113a688: add             x0, x0, HEAP, lsl #32
    // 0x113a68c: stur            x0, [fp, #-8]
    // 0x113a690: LoadField: r1 = r6->field_b
    //     0x113a690: ldur            w1, [x6, #0xb]
    // 0x113a694: r4 = LoadInt32Instr(r1)
    //     0x113a694: sbfx            x4, x1, #1, #0x1f
    // 0x113a698: cmp             x5, x4
    // 0x113a69c: b.ne            #0x113a6a8
    // 0x113a6a0: mov             x1, x2
    // 0x113a6a4: r0 = _growToNextCapacity()
    //     0x113a6a4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113a6a8: ldr             x3, [fp, #0x10]
    // 0x113a6ac: ldur            x4, [fp, #-0x20]
    // 0x113a6b0: ldur            x2, [fp, #-0x10]
    // 0x113a6b4: add             x5, x4, #1
    // 0x113a6b8: stur            x5, [fp, #-0x18]
    // 0x113a6bc: lsl             x0, x5, #1
    // 0x113a6c0: StoreField: r2->field_b = r0
    //     0x113a6c0: stur            w0, [x2, #0xb]
    // 0x113a6c4: LoadField: r6 = r2->field_f
    //     0x113a6c4: ldur            w6, [x2, #0xf]
    // 0x113a6c8: DecompressPointer r6
    //     0x113a6c8: add             x6, x6, HEAP, lsl #32
    // 0x113a6cc: mov             x1, x6
    // 0x113a6d0: ldur            x0, [fp, #-8]
    // 0x113a6d4: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113a6d4: add             x25, x1, x4, lsl #2
    //     0x113a6d8: add             x25, x25, #0xf
    //     0x113a6dc: str             w0, [x25]
    //     0x113a6e0: tbz             w0, #0, #0x113a6fc
    //     0x113a6e4: ldurb           w16, [x1, #-1]
    //     0x113a6e8: ldurb           w17, [x0, #-1]
    //     0x113a6ec: and             x16, x17, x16, lsr #2
    //     0x113a6f0: tst             x16, HEAP, lsr #32
    //     0x113a6f4: b.eq            #0x113a6fc
    //     0x113a6f8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113a6fc: r17 = 271
    //     0x113a6fc: mov             x17, #0x10f
    // 0x113a700: ldr             w0, [x3, x17]
    // 0x113a704: DecompressPointer r0
    //     0x113a704: add             x0, x0, HEAP, lsl #32
    // 0x113a708: stur            x0, [fp, #-8]
    // 0x113a70c: LoadField: r1 = r6->field_b
    //     0x113a70c: ldur            w1, [x6, #0xb]
    // 0x113a710: r4 = LoadInt32Instr(r1)
    //     0x113a710: sbfx            x4, x1, #1, #0x1f
    // 0x113a714: cmp             x5, x4
    // 0x113a718: b.ne            #0x113a724
    // 0x113a71c: mov             x1, x2
    // 0x113a720: r0 = _growToNextCapacity()
    //     0x113a720: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113a724: ldr             x3, [fp, #0x10]
    // 0x113a728: ldur            x4, [fp, #-0x18]
    // 0x113a72c: ldur            x2, [fp, #-0x10]
    // 0x113a730: add             x5, x4, #1
    // 0x113a734: stur            x5, [fp, #-0x20]
    // 0x113a738: lsl             x0, x5, #1
    // 0x113a73c: StoreField: r2->field_b = r0
    //     0x113a73c: stur            w0, [x2, #0xb]
    // 0x113a740: LoadField: r6 = r2->field_f
    //     0x113a740: ldur            w6, [x2, #0xf]
    // 0x113a744: DecompressPointer r6
    //     0x113a744: add             x6, x6, HEAP, lsl #32
    // 0x113a748: mov             x1, x6
    // 0x113a74c: ldur            x0, [fp, #-8]
    // 0x113a750: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113a750: add             x25, x1, x4, lsl #2
    //     0x113a754: add             x25, x25, #0xf
    //     0x113a758: str             w0, [x25]
    //     0x113a75c: tbz             w0, #0, #0x113a778
    //     0x113a760: ldurb           w16, [x1, #-1]
    //     0x113a764: ldurb           w17, [x0, #-1]
    //     0x113a768: and             x16, x17, x16, lsr #2
    //     0x113a76c: tst             x16, HEAP, lsr #32
    //     0x113a770: b.eq            #0x113a778
    //     0x113a774: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113a778: r17 = 275
    //     0x113a778: mov             x17, #0x113
    // 0x113a77c: ldr             w0, [x3, x17]
    // 0x113a780: DecompressPointer r0
    //     0x113a780: add             x0, x0, HEAP, lsl #32
    // 0x113a784: stur            x0, [fp, #-8]
    // 0x113a788: LoadField: r1 = r6->field_b
    //     0x113a788: ldur            w1, [x6, #0xb]
    // 0x113a78c: r4 = LoadInt32Instr(r1)
    //     0x113a78c: sbfx            x4, x1, #1, #0x1f
    // 0x113a790: cmp             x5, x4
    // 0x113a794: b.ne            #0x113a7a0
    // 0x113a798: mov             x1, x2
    // 0x113a79c: r0 = _growToNextCapacity()
    //     0x113a79c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113a7a0: ldr             x3, [fp, #0x10]
    // 0x113a7a4: ldur            x4, [fp, #-0x20]
    // 0x113a7a8: ldur            x2, [fp, #-0x10]
    // 0x113a7ac: add             x5, x4, #1
    // 0x113a7b0: stur            x5, [fp, #-0x18]
    // 0x113a7b4: lsl             x0, x5, #1
    // 0x113a7b8: StoreField: r2->field_b = r0
    //     0x113a7b8: stur            w0, [x2, #0xb]
    // 0x113a7bc: LoadField: r6 = r2->field_f
    //     0x113a7bc: ldur            w6, [x2, #0xf]
    // 0x113a7c0: DecompressPointer r6
    //     0x113a7c0: add             x6, x6, HEAP, lsl #32
    // 0x113a7c4: mov             x1, x6
    // 0x113a7c8: ldur            x0, [fp, #-8]
    // 0x113a7cc: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113a7cc: add             x25, x1, x4, lsl #2
    //     0x113a7d0: add             x25, x25, #0xf
    //     0x113a7d4: str             w0, [x25]
    //     0x113a7d8: tbz             w0, #0, #0x113a7f4
    //     0x113a7dc: ldurb           w16, [x1, #-1]
    //     0x113a7e0: ldurb           w17, [x0, #-1]
    //     0x113a7e4: and             x16, x17, x16, lsr #2
    //     0x113a7e8: tst             x16, HEAP, lsr #32
    //     0x113a7ec: b.eq            #0x113a7f4
    //     0x113a7f0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113a7f4: r17 = 279
    //     0x113a7f4: mov             x17, #0x117
    // 0x113a7f8: ldr             w0, [x3, x17]
    // 0x113a7fc: DecompressPointer r0
    //     0x113a7fc: add             x0, x0, HEAP, lsl #32
    // 0x113a800: stur            x0, [fp, #-8]
    // 0x113a804: LoadField: r1 = r6->field_b
    //     0x113a804: ldur            w1, [x6, #0xb]
    // 0x113a808: r4 = LoadInt32Instr(r1)
    //     0x113a808: sbfx            x4, x1, #1, #0x1f
    // 0x113a80c: cmp             x5, x4
    // 0x113a810: b.ne            #0x113a81c
    // 0x113a814: mov             x1, x2
    // 0x113a818: r0 = _growToNextCapacity()
    //     0x113a818: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113a81c: ldr             x3, [fp, #0x10]
    // 0x113a820: ldur            x4, [fp, #-0x18]
    // 0x113a824: ldur            x2, [fp, #-0x10]
    // 0x113a828: add             x5, x4, #1
    // 0x113a82c: stur            x5, [fp, #-0x20]
    // 0x113a830: lsl             x0, x5, #1
    // 0x113a834: StoreField: r2->field_b = r0
    //     0x113a834: stur            w0, [x2, #0xb]
    // 0x113a838: LoadField: r6 = r2->field_f
    //     0x113a838: ldur            w6, [x2, #0xf]
    // 0x113a83c: DecompressPointer r6
    //     0x113a83c: add             x6, x6, HEAP, lsl #32
    // 0x113a840: mov             x1, x6
    // 0x113a844: ldur            x0, [fp, #-8]
    // 0x113a848: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113a848: add             x25, x1, x4, lsl #2
    //     0x113a84c: add             x25, x25, #0xf
    //     0x113a850: str             w0, [x25]
    //     0x113a854: tbz             w0, #0, #0x113a870
    //     0x113a858: ldurb           w16, [x1, #-1]
    //     0x113a85c: ldurb           w17, [x0, #-1]
    //     0x113a860: and             x16, x17, x16, lsr #2
    //     0x113a864: tst             x16, HEAP, lsr #32
    //     0x113a868: b.eq            #0x113a870
    //     0x113a86c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113a870: r17 = 283
    //     0x113a870: mov             x17, #0x11b
    // 0x113a874: ldr             w0, [x3, x17]
    // 0x113a878: DecompressPointer r0
    //     0x113a878: add             x0, x0, HEAP, lsl #32
    // 0x113a87c: stur            x0, [fp, #-8]
    // 0x113a880: LoadField: r1 = r6->field_b
    //     0x113a880: ldur            w1, [x6, #0xb]
    // 0x113a884: r4 = LoadInt32Instr(r1)
    //     0x113a884: sbfx            x4, x1, #1, #0x1f
    // 0x113a888: cmp             x5, x4
    // 0x113a88c: b.ne            #0x113a898
    // 0x113a890: mov             x1, x2
    // 0x113a894: r0 = _growToNextCapacity()
    //     0x113a894: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113a898: ldr             x3, [fp, #0x10]
    // 0x113a89c: ldur            x4, [fp, #-0x20]
    // 0x113a8a0: ldur            x2, [fp, #-0x10]
    // 0x113a8a4: add             x5, x4, #1
    // 0x113a8a8: stur            x5, [fp, #-0x18]
    // 0x113a8ac: lsl             x0, x5, #1
    // 0x113a8b0: StoreField: r2->field_b = r0
    //     0x113a8b0: stur            w0, [x2, #0xb]
    // 0x113a8b4: LoadField: r6 = r2->field_f
    //     0x113a8b4: ldur            w6, [x2, #0xf]
    // 0x113a8b8: DecompressPointer r6
    //     0x113a8b8: add             x6, x6, HEAP, lsl #32
    // 0x113a8bc: mov             x1, x6
    // 0x113a8c0: ldur            x0, [fp, #-8]
    // 0x113a8c4: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113a8c4: add             x25, x1, x4, lsl #2
    //     0x113a8c8: add             x25, x25, #0xf
    //     0x113a8cc: str             w0, [x25]
    //     0x113a8d0: tbz             w0, #0, #0x113a8ec
    //     0x113a8d4: ldurb           w16, [x1, #-1]
    //     0x113a8d8: ldurb           w17, [x0, #-1]
    //     0x113a8dc: and             x16, x17, x16, lsr #2
    //     0x113a8e0: tst             x16, HEAP, lsr #32
    //     0x113a8e4: b.eq            #0x113a8ec
    //     0x113a8e8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113a8ec: r17 = 287
    //     0x113a8ec: mov             x17, #0x11f
    // 0x113a8f0: ldr             w0, [x3, x17]
    // 0x113a8f4: DecompressPointer r0
    //     0x113a8f4: add             x0, x0, HEAP, lsl #32
    // 0x113a8f8: stur            x0, [fp, #-8]
    // 0x113a8fc: LoadField: r1 = r6->field_b
    //     0x113a8fc: ldur            w1, [x6, #0xb]
    // 0x113a900: r4 = LoadInt32Instr(r1)
    //     0x113a900: sbfx            x4, x1, #1, #0x1f
    // 0x113a904: cmp             x5, x4
    // 0x113a908: b.ne            #0x113a914
    // 0x113a90c: mov             x1, x2
    // 0x113a910: r0 = _growToNextCapacity()
    //     0x113a910: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113a914: ldr             x3, [fp, #0x10]
    // 0x113a918: ldur            x4, [fp, #-0x18]
    // 0x113a91c: ldur            x2, [fp, #-0x10]
    // 0x113a920: add             x5, x4, #1
    // 0x113a924: stur            x5, [fp, #-0x20]
    // 0x113a928: lsl             x0, x5, #1
    // 0x113a92c: StoreField: r2->field_b = r0
    //     0x113a92c: stur            w0, [x2, #0xb]
    // 0x113a930: LoadField: r6 = r2->field_f
    //     0x113a930: ldur            w6, [x2, #0xf]
    // 0x113a934: DecompressPointer r6
    //     0x113a934: add             x6, x6, HEAP, lsl #32
    // 0x113a938: mov             x1, x6
    // 0x113a93c: ldur            x0, [fp, #-8]
    // 0x113a940: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113a940: add             x25, x1, x4, lsl #2
    //     0x113a944: add             x25, x25, #0xf
    //     0x113a948: str             w0, [x25]
    //     0x113a94c: tbz             w0, #0, #0x113a968
    //     0x113a950: ldurb           w16, [x1, #-1]
    //     0x113a954: ldurb           w17, [x0, #-1]
    //     0x113a958: and             x16, x17, x16, lsr #2
    //     0x113a95c: tst             x16, HEAP, lsr #32
    //     0x113a960: b.eq            #0x113a968
    //     0x113a964: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113a968: r17 = 291
    //     0x113a968: mov             x17, #0x123
    // 0x113a96c: ldr             w0, [x3, x17]
    // 0x113a970: DecompressPointer r0
    //     0x113a970: add             x0, x0, HEAP, lsl #32
    // 0x113a974: stur            x0, [fp, #-8]
    // 0x113a978: LoadField: r1 = r6->field_b
    //     0x113a978: ldur            w1, [x6, #0xb]
    // 0x113a97c: r4 = LoadInt32Instr(r1)
    //     0x113a97c: sbfx            x4, x1, #1, #0x1f
    // 0x113a980: cmp             x5, x4
    // 0x113a984: b.ne            #0x113a990
    // 0x113a988: mov             x1, x2
    // 0x113a98c: r0 = _growToNextCapacity()
    //     0x113a98c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113a990: ldr             x3, [fp, #0x10]
    // 0x113a994: ldur            x4, [fp, #-0x20]
    // 0x113a998: ldur            x2, [fp, #-0x10]
    // 0x113a99c: add             x5, x4, #1
    // 0x113a9a0: stur            x5, [fp, #-0x18]
    // 0x113a9a4: lsl             x0, x5, #1
    // 0x113a9a8: StoreField: r2->field_b = r0
    //     0x113a9a8: stur            w0, [x2, #0xb]
    // 0x113a9ac: LoadField: r6 = r2->field_f
    //     0x113a9ac: ldur            w6, [x2, #0xf]
    // 0x113a9b0: DecompressPointer r6
    //     0x113a9b0: add             x6, x6, HEAP, lsl #32
    // 0x113a9b4: mov             x1, x6
    // 0x113a9b8: ldur            x0, [fp, #-8]
    // 0x113a9bc: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113a9bc: add             x25, x1, x4, lsl #2
    //     0x113a9c0: add             x25, x25, #0xf
    //     0x113a9c4: str             w0, [x25]
    //     0x113a9c8: tbz             w0, #0, #0x113a9e4
    //     0x113a9cc: ldurb           w16, [x1, #-1]
    //     0x113a9d0: ldurb           w17, [x0, #-1]
    //     0x113a9d4: and             x16, x17, x16, lsr #2
    //     0x113a9d8: tst             x16, HEAP, lsr #32
    //     0x113a9dc: b.eq            #0x113a9e4
    //     0x113a9e0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113a9e4: r17 = 295
    //     0x113a9e4: mov             x17, #0x127
    // 0x113a9e8: ldr             w0, [x3, x17]
    // 0x113a9ec: DecompressPointer r0
    //     0x113a9ec: add             x0, x0, HEAP, lsl #32
    // 0x113a9f0: stur            x0, [fp, #-8]
    // 0x113a9f4: LoadField: r1 = r6->field_b
    //     0x113a9f4: ldur            w1, [x6, #0xb]
    // 0x113a9f8: r4 = LoadInt32Instr(r1)
    //     0x113a9f8: sbfx            x4, x1, #1, #0x1f
    // 0x113a9fc: cmp             x5, x4
    // 0x113aa00: b.ne            #0x113aa0c
    // 0x113aa04: mov             x1, x2
    // 0x113aa08: r0 = _growToNextCapacity()
    //     0x113aa08: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113aa0c: ldr             x3, [fp, #0x10]
    // 0x113aa10: ldur            x4, [fp, #-0x18]
    // 0x113aa14: ldur            x2, [fp, #-0x10]
    // 0x113aa18: add             x5, x4, #1
    // 0x113aa1c: stur            x5, [fp, #-0x20]
    // 0x113aa20: lsl             x0, x5, #1
    // 0x113aa24: StoreField: r2->field_b = r0
    //     0x113aa24: stur            w0, [x2, #0xb]
    // 0x113aa28: LoadField: r6 = r2->field_f
    //     0x113aa28: ldur            w6, [x2, #0xf]
    // 0x113aa2c: DecompressPointer r6
    //     0x113aa2c: add             x6, x6, HEAP, lsl #32
    // 0x113aa30: mov             x1, x6
    // 0x113aa34: ldur            x0, [fp, #-8]
    // 0x113aa38: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113aa38: add             x25, x1, x4, lsl #2
    //     0x113aa3c: add             x25, x25, #0xf
    //     0x113aa40: str             w0, [x25]
    //     0x113aa44: tbz             w0, #0, #0x113aa60
    //     0x113aa48: ldurb           w16, [x1, #-1]
    //     0x113aa4c: ldurb           w17, [x0, #-1]
    //     0x113aa50: and             x16, x17, x16, lsr #2
    //     0x113aa54: tst             x16, HEAP, lsr #32
    //     0x113aa58: b.eq            #0x113aa60
    //     0x113aa5c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113aa60: r17 = 299
    //     0x113aa60: mov             x17, #0x12b
    // 0x113aa64: ldr             w0, [x3, x17]
    // 0x113aa68: DecompressPointer r0
    //     0x113aa68: add             x0, x0, HEAP, lsl #32
    // 0x113aa6c: stur            x0, [fp, #-8]
    // 0x113aa70: LoadField: r1 = r6->field_b
    //     0x113aa70: ldur            w1, [x6, #0xb]
    // 0x113aa74: r4 = LoadInt32Instr(r1)
    //     0x113aa74: sbfx            x4, x1, #1, #0x1f
    // 0x113aa78: cmp             x5, x4
    // 0x113aa7c: b.ne            #0x113aa88
    // 0x113aa80: mov             x1, x2
    // 0x113aa84: r0 = _growToNextCapacity()
    //     0x113aa84: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113aa88: ldr             x3, [fp, #0x10]
    // 0x113aa8c: ldur            x4, [fp, #-0x20]
    // 0x113aa90: ldur            x2, [fp, #-0x10]
    // 0x113aa94: add             x5, x4, #1
    // 0x113aa98: stur            x5, [fp, #-0x18]
    // 0x113aa9c: lsl             x0, x5, #1
    // 0x113aaa0: StoreField: r2->field_b = r0
    //     0x113aaa0: stur            w0, [x2, #0xb]
    // 0x113aaa4: LoadField: r6 = r2->field_f
    //     0x113aaa4: ldur            w6, [x2, #0xf]
    // 0x113aaa8: DecompressPointer r6
    //     0x113aaa8: add             x6, x6, HEAP, lsl #32
    // 0x113aaac: mov             x1, x6
    // 0x113aab0: ldur            x0, [fp, #-8]
    // 0x113aab4: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113aab4: add             x25, x1, x4, lsl #2
    //     0x113aab8: add             x25, x25, #0xf
    //     0x113aabc: str             w0, [x25]
    //     0x113aac0: tbz             w0, #0, #0x113aadc
    //     0x113aac4: ldurb           w16, [x1, #-1]
    //     0x113aac8: ldurb           w17, [x0, #-1]
    //     0x113aacc: and             x16, x17, x16, lsr #2
    //     0x113aad0: tst             x16, HEAP, lsr #32
    //     0x113aad4: b.eq            #0x113aadc
    //     0x113aad8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113aadc: r17 = 303
    //     0x113aadc: mov             x17, #0x12f
    // 0x113aae0: ldr             w0, [x3, x17]
    // 0x113aae4: DecompressPointer r0
    //     0x113aae4: add             x0, x0, HEAP, lsl #32
    // 0x113aae8: stur            x0, [fp, #-8]
    // 0x113aaec: LoadField: r1 = r6->field_b
    //     0x113aaec: ldur            w1, [x6, #0xb]
    // 0x113aaf0: r4 = LoadInt32Instr(r1)
    //     0x113aaf0: sbfx            x4, x1, #1, #0x1f
    // 0x113aaf4: cmp             x5, x4
    // 0x113aaf8: b.ne            #0x113ab04
    // 0x113aafc: mov             x1, x2
    // 0x113ab00: r0 = _growToNextCapacity()
    //     0x113ab00: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113ab04: ldr             x3, [fp, #0x10]
    // 0x113ab08: ldur            x4, [fp, #-0x18]
    // 0x113ab0c: ldur            x2, [fp, #-0x10]
    // 0x113ab10: add             x5, x4, #1
    // 0x113ab14: stur            x5, [fp, #-0x20]
    // 0x113ab18: lsl             x0, x5, #1
    // 0x113ab1c: StoreField: r2->field_b = r0
    //     0x113ab1c: stur            w0, [x2, #0xb]
    // 0x113ab20: LoadField: r6 = r2->field_f
    //     0x113ab20: ldur            w6, [x2, #0xf]
    // 0x113ab24: DecompressPointer r6
    //     0x113ab24: add             x6, x6, HEAP, lsl #32
    // 0x113ab28: mov             x1, x6
    // 0x113ab2c: ldur            x0, [fp, #-8]
    // 0x113ab30: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113ab30: add             x25, x1, x4, lsl #2
    //     0x113ab34: add             x25, x25, #0xf
    //     0x113ab38: str             w0, [x25]
    //     0x113ab3c: tbz             w0, #0, #0x113ab58
    //     0x113ab40: ldurb           w16, [x1, #-1]
    //     0x113ab44: ldurb           w17, [x0, #-1]
    //     0x113ab48: and             x16, x17, x16, lsr #2
    //     0x113ab4c: tst             x16, HEAP, lsr #32
    //     0x113ab50: b.eq            #0x113ab58
    //     0x113ab54: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113ab58: r17 = 307
    //     0x113ab58: mov             x17, #0x133
    // 0x113ab5c: ldr             w0, [x3, x17]
    // 0x113ab60: DecompressPointer r0
    //     0x113ab60: add             x0, x0, HEAP, lsl #32
    // 0x113ab64: stur            x0, [fp, #-8]
    // 0x113ab68: LoadField: r1 = r6->field_b
    //     0x113ab68: ldur            w1, [x6, #0xb]
    // 0x113ab6c: r4 = LoadInt32Instr(r1)
    //     0x113ab6c: sbfx            x4, x1, #1, #0x1f
    // 0x113ab70: cmp             x5, x4
    // 0x113ab74: b.ne            #0x113ab80
    // 0x113ab78: mov             x1, x2
    // 0x113ab7c: r0 = _growToNextCapacity()
    //     0x113ab7c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113ab80: ldr             x3, [fp, #0x10]
    // 0x113ab84: ldur            x4, [fp, #-0x20]
    // 0x113ab88: ldur            x2, [fp, #-0x10]
    // 0x113ab8c: add             x5, x4, #1
    // 0x113ab90: stur            x5, [fp, #-0x18]
    // 0x113ab94: lsl             x0, x5, #1
    // 0x113ab98: StoreField: r2->field_b = r0
    //     0x113ab98: stur            w0, [x2, #0xb]
    // 0x113ab9c: LoadField: r6 = r2->field_f
    //     0x113ab9c: ldur            w6, [x2, #0xf]
    // 0x113aba0: DecompressPointer r6
    //     0x113aba0: add             x6, x6, HEAP, lsl #32
    // 0x113aba4: mov             x1, x6
    // 0x113aba8: ldur            x0, [fp, #-8]
    // 0x113abac: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113abac: add             x25, x1, x4, lsl #2
    //     0x113abb0: add             x25, x25, #0xf
    //     0x113abb4: str             w0, [x25]
    //     0x113abb8: tbz             w0, #0, #0x113abd4
    //     0x113abbc: ldurb           w16, [x1, #-1]
    //     0x113abc0: ldurb           w17, [x0, #-1]
    //     0x113abc4: and             x16, x17, x16, lsr #2
    //     0x113abc8: tst             x16, HEAP, lsr #32
    //     0x113abcc: b.eq            #0x113abd4
    //     0x113abd0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113abd4: r17 = 311
    //     0x113abd4: mov             x17, #0x137
    // 0x113abd8: ldr             w0, [x3, x17]
    // 0x113abdc: DecompressPointer r0
    //     0x113abdc: add             x0, x0, HEAP, lsl #32
    // 0x113abe0: stur            x0, [fp, #-8]
    // 0x113abe4: LoadField: r1 = r6->field_b
    //     0x113abe4: ldur            w1, [x6, #0xb]
    // 0x113abe8: r4 = LoadInt32Instr(r1)
    //     0x113abe8: sbfx            x4, x1, #1, #0x1f
    // 0x113abec: cmp             x5, x4
    // 0x113abf0: b.ne            #0x113abfc
    // 0x113abf4: mov             x1, x2
    // 0x113abf8: r0 = _growToNextCapacity()
    //     0x113abf8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113abfc: ldr             x3, [fp, #0x10]
    // 0x113ac00: ldur            x4, [fp, #-0x18]
    // 0x113ac04: ldur            x2, [fp, #-0x10]
    // 0x113ac08: add             x5, x4, #1
    // 0x113ac0c: stur            x5, [fp, #-0x20]
    // 0x113ac10: lsl             x0, x5, #1
    // 0x113ac14: StoreField: r2->field_b = r0
    //     0x113ac14: stur            w0, [x2, #0xb]
    // 0x113ac18: LoadField: r6 = r2->field_f
    //     0x113ac18: ldur            w6, [x2, #0xf]
    // 0x113ac1c: DecompressPointer r6
    //     0x113ac1c: add             x6, x6, HEAP, lsl #32
    // 0x113ac20: mov             x1, x6
    // 0x113ac24: ldur            x0, [fp, #-8]
    // 0x113ac28: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113ac28: add             x25, x1, x4, lsl #2
    //     0x113ac2c: add             x25, x25, #0xf
    //     0x113ac30: str             w0, [x25]
    //     0x113ac34: tbz             w0, #0, #0x113ac50
    //     0x113ac38: ldurb           w16, [x1, #-1]
    //     0x113ac3c: ldurb           w17, [x0, #-1]
    //     0x113ac40: and             x16, x17, x16, lsr #2
    //     0x113ac44: tst             x16, HEAP, lsr #32
    //     0x113ac48: b.eq            #0x113ac50
    //     0x113ac4c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113ac50: r17 = 315
    //     0x113ac50: mov             x17, #0x13b
    // 0x113ac54: ldr             w0, [x3, x17]
    // 0x113ac58: DecompressPointer r0
    //     0x113ac58: add             x0, x0, HEAP, lsl #32
    // 0x113ac5c: stur            x0, [fp, #-8]
    // 0x113ac60: LoadField: r1 = r6->field_b
    //     0x113ac60: ldur            w1, [x6, #0xb]
    // 0x113ac64: r4 = LoadInt32Instr(r1)
    //     0x113ac64: sbfx            x4, x1, #1, #0x1f
    // 0x113ac68: cmp             x5, x4
    // 0x113ac6c: b.ne            #0x113ac78
    // 0x113ac70: mov             x1, x2
    // 0x113ac74: r0 = _growToNextCapacity()
    //     0x113ac74: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113ac78: ldr             x3, [fp, #0x10]
    // 0x113ac7c: ldur            x4, [fp, #-0x20]
    // 0x113ac80: ldur            x2, [fp, #-0x10]
    // 0x113ac84: add             x5, x4, #1
    // 0x113ac88: stur            x5, [fp, #-0x18]
    // 0x113ac8c: lsl             x0, x5, #1
    // 0x113ac90: StoreField: r2->field_b = r0
    //     0x113ac90: stur            w0, [x2, #0xb]
    // 0x113ac94: LoadField: r6 = r2->field_f
    //     0x113ac94: ldur            w6, [x2, #0xf]
    // 0x113ac98: DecompressPointer r6
    //     0x113ac98: add             x6, x6, HEAP, lsl #32
    // 0x113ac9c: mov             x1, x6
    // 0x113aca0: ldur            x0, [fp, #-8]
    // 0x113aca4: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113aca4: add             x25, x1, x4, lsl #2
    //     0x113aca8: add             x25, x25, #0xf
    //     0x113acac: str             w0, [x25]
    //     0x113acb0: tbz             w0, #0, #0x113accc
    //     0x113acb4: ldurb           w16, [x1, #-1]
    //     0x113acb8: ldurb           w17, [x0, #-1]
    //     0x113acbc: and             x16, x17, x16, lsr #2
    //     0x113acc0: tst             x16, HEAP, lsr #32
    //     0x113acc4: b.eq            #0x113accc
    //     0x113acc8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113accc: r17 = 319
    //     0x113accc: mov             x17, #0x13f
    // 0x113acd0: ldr             w0, [x3, x17]
    // 0x113acd4: DecompressPointer r0
    //     0x113acd4: add             x0, x0, HEAP, lsl #32
    // 0x113acd8: stur            x0, [fp, #-8]
    // 0x113acdc: LoadField: r1 = r6->field_b
    //     0x113acdc: ldur            w1, [x6, #0xb]
    // 0x113ace0: r4 = LoadInt32Instr(r1)
    //     0x113ace0: sbfx            x4, x1, #1, #0x1f
    // 0x113ace4: cmp             x5, x4
    // 0x113ace8: b.ne            #0x113acf4
    // 0x113acec: mov             x1, x2
    // 0x113acf0: r0 = _growToNextCapacity()
    //     0x113acf0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113acf4: ldr             x3, [fp, #0x10]
    // 0x113acf8: ldur            x4, [fp, #-0x18]
    // 0x113acfc: ldur            x2, [fp, #-0x10]
    // 0x113ad00: add             x5, x4, #1
    // 0x113ad04: stur            x5, [fp, #-0x20]
    // 0x113ad08: lsl             x0, x5, #1
    // 0x113ad0c: StoreField: r2->field_b = r0
    //     0x113ad0c: stur            w0, [x2, #0xb]
    // 0x113ad10: LoadField: r6 = r2->field_f
    //     0x113ad10: ldur            w6, [x2, #0xf]
    // 0x113ad14: DecompressPointer r6
    //     0x113ad14: add             x6, x6, HEAP, lsl #32
    // 0x113ad18: mov             x1, x6
    // 0x113ad1c: ldur            x0, [fp, #-8]
    // 0x113ad20: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113ad20: add             x25, x1, x4, lsl #2
    //     0x113ad24: add             x25, x25, #0xf
    //     0x113ad28: str             w0, [x25]
    //     0x113ad2c: tbz             w0, #0, #0x113ad48
    //     0x113ad30: ldurb           w16, [x1, #-1]
    //     0x113ad34: ldurb           w17, [x0, #-1]
    //     0x113ad38: and             x16, x17, x16, lsr #2
    //     0x113ad3c: tst             x16, HEAP, lsr #32
    //     0x113ad40: b.eq            #0x113ad48
    //     0x113ad44: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113ad48: r17 = 323
    //     0x113ad48: mov             x17, #0x143
    // 0x113ad4c: ldr             w0, [x3, x17]
    // 0x113ad50: DecompressPointer r0
    //     0x113ad50: add             x0, x0, HEAP, lsl #32
    // 0x113ad54: stur            x0, [fp, #-8]
    // 0x113ad58: LoadField: r1 = r6->field_b
    //     0x113ad58: ldur            w1, [x6, #0xb]
    // 0x113ad5c: r4 = LoadInt32Instr(r1)
    //     0x113ad5c: sbfx            x4, x1, #1, #0x1f
    // 0x113ad60: cmp             x5, x4
    // 0x113ad64: b.ne            #0x113ad70
    // 0x113ad68: mov             x1, x2
    // 0x113ad6c: r0 = _growToNextCapacity()
    //     0x113ad6c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113ad70: ldr             x3, [fp, #0x10]
    // 0x113ad74: ldur            x4, [fp, #-0x20]
    // 0x113ad78: ldur            x2, [fp, #-0x10]
    // 0x113ad7c: add             x5, x4, #1
    // 0x113ad80: stur            x5, [fp, #-0x18]
    // 0x113ad84: lsl             x0, x5, #1
    // 0x113ad88: StoreField: r2->field_b = r0
    //     0x113ad88: stur            w0, [x2, #0xb]
    // 0x113ad8c: LoadField: r6 = r2->field_f
    //     0x113ad8c: ldur            w6, [x2, #0xf]
    // 0x113ad90: DecompressPointer r6
    //     0x113ad90: add             x6, x6, HEAP, lsl #32
    // 0x113ad94: mov             x1, x6
    // 0x113ad98: ldur            x0, [fp, #-8]
    // 0x113ad9c: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113ad9c: add             x25, x1, x4, lsl #2
    //     0x113ada0: add             x25, x25, #0xf
    //     0x113ada4: str             w0, [x25]
    //     0x113ada8: tbz             w0, #0, #0x113adc4
    //     0x113adac: ldurb           w16, [x1, #-1]
    //     0x113adb0: ldurb           w17, [x0, #-1]
    //     0x113adb4: and             x16, x17, x16, lsr #2
    //     0x113adb8: tst             x16, HEAP, lsr #32
    //     0x113adbc: b.eq            #0x113adc4
    //     0x113adc0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113adc4: r17 = 327
    //     0x113adc4: mov             x17, #0x147
    // 0x113adc8: ldr             w0, [x3, x17]
    // 0x113adcc: DecompressPointer r0
    //     0x113adcc: add             x0, x0, HEAP, lsl #32
    // 0x113add0: stur            x0, [fp, #-8]
    // 0x113add4: LoadField: r1 = r6->field_b
    //     0x113add4: ldur            w1, [x6, #0xb]
    // 0x113add8: r4 = LoadInt32Instr(r1)
    //     0x113add8: sbfx            x4, x1, #1, #0x1f
    // 0x113addc: cmp             x5, x4
    // 0x113ade0: b.ne            #0x113adec
    // 0x113ade4: mov             x1, x2
    // 0x113ade8: r0 = _growToNextCapacity()
    //     0x113ade8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113adec: ldr             x3, [fp, #0x10]
    // 0x113adf0: ldur            x4, [fp, #-0x18]
    // 0x113adf4: ldur            x2, [fp, #-0x10]
    // 0x113adf8: add             x5, x4, #1
    // 0x113adfc: stur            x5, [fp, #-0x20]
    // 0x113ae00: lsl             x0, x5, #1
    // 0x113ae04: StoreField: r2->field_b = r0
    //     0x113ae04: stur            w0, [x2, #0xb]
    // 0x113ae08: LoadField: r6 = r2->field_f
    //     0x113ae08: ldur            w6, [x2, #0xf]
    // 0x113ae0c: DecompressPointer r6
    //     0x113ae0c: add             x6, x6, HEAP, lsl #32
    // 0x113ae10: mov             x1, x6
    // 0x113ae14: ldur            x0, [fp, #-8]
    // 0x113ae18: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113ae18: add             x25, x1, x4, lsl #2
    //     0x113ae1c: add             x25, x25, #0xf
    //     0x113ae20: str             w0, [x25]
    //     0x113ae24: tbz             w0, #0, #0x113ae40
    //     0x113ae28: ldurb           w16, [x1, #-1]
    //     0x113ae2c: ldurb           w17, [x0, #-1]
    //     0x113ae30: and             x16, x17, x16, lsr #2
    //     0x113ae34: tst             x16, HEAP, lsr #32
    //     0x113ae38: b.eq            #0x113ae40
    //     0x113ae3c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113ae40: r17 = 331
    //     0x113ae40: mov             x17, #0x14b
    // 0x113ae44: ldr             w0, [x3, x17]
    // 0x113ae48: DecompressPointer r0
    //     0x113ae48: add             x0, x0, HEAP, lsl #32
    // 0x113ae4c: stur            x0, [fp, #-8]
    // 0x113ae50: LoadField: r1 = r6->field_b
    //     0x113ae50: ldur            w1, [x6, #0xb]
    // 0x113ae54: r4 = LoadInt32Instr(r1)
    //     0x113ae54: sbfx            x4, x1, #1, #0x1f
    // 0x113ae58: cmp             x5, x4
    // 0x113ae5c: b.ne            #0x113ae68
    // 0x113ae60: mov             x1, x2
    // 0x113ae64: r0 = _growToNextCapacity()
    //     0x113ae64: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113ae68: ldr             x3, [fp, #0x10]
    // 0x113ae6c: ldur            x4, [fp, #-0x20]
    // 0x113ae70: ldur            x2, [fp, #-0x10]
    // 0x113ae74: add             x5, x4, #1
    // 0x113ae78: stur            x5, [fp, #-0x18]
    // 0x113ae7c: lsl             x0, x5, #1
    // 0x113ae80: StoreField: r2->field_b = r0
    //     0x113ae80: stur            w0, [x2, #0xb]
    // 0x113ae84: LoadField: r6 = r2->field_f
    //     0x113ae84: ldur            w6, [x2, #0xf]
    // 0x113ae88: DecompressPointer r6
    //     0x113ae88: add             x6, x6, HEAP, lsl #32
    // 0x113ae8c: mov             x1, x6
    // 0x113ae90: ldur            x0, [fp, #-8]
    // 0x113ae94: ArrayStore: r1[r4] = r0  ; List_4
    //     0x113ae94: add             x25, x1, x4, lsl #2
    //     0x113ae98: add             x25, x25, #0xf
    //     0x113ae9c: str             w0, [x25]
    //     0x113aea0: tbz             w0, #0, #0x113aebc
    //     0x113aea4: ldurb           w16, [x1, #-1]
    //     0x113aea8: ldurb           w17, [x0, #-1]
    //     0x113aeac: and             x16, x17, x16, lsr #2
    //     0x113aeb0: tst             x16, HEAP, lsr #32
    //     0x113aeb4: b.eq            #0x113aebc
    //     0x113aeb8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113aebc: r17 = 335
    //     0x113aebc: mov             x17, #0x14f
    // 0x113aec0: ldr             w0, [x3, x17]
    // 0x113aec4: DecompressPointer r0
    //     0x113aec4: add             x0, x0, HEAP, lsl #32
    // 0x113aec8: stur            x0, [fp, #-8]
    // 0x113aecc: LoadField: r1 = r6->field_b
    //     0x113aecc: ldur            w1, [x6, #0xb]
    // 0x113aed0: r3 = LoadInt32Instr(r1)
    //     0x113aed0: sbfx            x3, x1, #1, #0x1f
    // 0x113aed4: cmp             x5, x3
    // 0x113aed8: b.ne            #0x113aee4
    // 0x113aedc: mov             x1, x2
    // 0x113aee0: r0 = _growToNextCapacity()
    //     0x113aee0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x113aee4: ldur            x3, [fp, #-0x18]
    // 0x113aee8: ldur            x2, [fp, #-0x10]
    // 0x113aeec: add             x0, x3, #1
    // 0x113aef0: lsl             x1, x0, #1
    // 0x113aef4: StoreField: r2->field_b = r1
    //     0x113aef4: stur            w1, [x2, #0xb]
    // 0x113aef8: LoadField: r1 = r2->field_f
    //     0x113aef8: ldur            w1, [x2, #0xf]
    // 0x113aefc: DecompressPointer r1
    //     0x113aefc: add             x1, x1, HEAP, lsl #32
    // 0x113af00: ldur            x0, [fp, #-8]
    // 0x113af04: ArrayStore: r1[r3] = r0  ; List_4
    //     0x113af04: add             x25, x1, x3, lsl #2
    //     0x113af08: add             x25, x25, #0xf
    //     0x113af0c: str             w0, [x25]
    //     0x113af10: tbz             w0, #0, #0x113af2c
    //     0x113af14: ldurb           w16, [x1, #-1]
    //     0x113af18: ldurb           w17, [x0, #-1]
    //     0x113af1c: and             x16, x17, x16, lsr #2
    //     0x113af20: tst             x16, HEAP, lsr #32
    //     0x113af24: b.eq            #0x113af2c
    //     0x113af28: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113af2c: mov             x1, x2
    // 0x113af30: r0 = hashAll()
    //     0x113af30: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x113af34: mov             x2, x0
    // 0x113af38: r0 = BoxInt64Instr(r2)
    //     0x113af38: sbfiz           x0, x2, #1, #0x1f
    //     0x113af3c: cmp             x2, x0, asr #1
    //     0x113af40: b.eq            #0x113af4c
    //     0x113af44: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113af48: stur            x2, [x0, #7]
    // 0x113af4c: LeaveFrame
    //     0x113af4c: mov             SP, fp
    //     0x113af50: ldp             fp, lr, [SP], #0x10
    // 0x113af54: ret
    //     0x113af54: ret             
    // 0x113af58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x113af58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x113af5c: b               #0x113891c
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x115e058, size: 0x138c
    // 0x115e058: EnterFrame
    //     0x115e058: stp             fp, lr, [SP, #-0x10]!
    //     0x115e05c: mov             fp, SP
    // 0x115e060: AllocStack(0x290)
    //     0x115e060: sub             SP, SP, #0x290
    // 0x115e064: SetupParameters(dynamic _ /* r1 => r3, fp-0x18 */, dynamic _ /* r2 => r0, fp-0x20 */, dynamic _ /* d0 => d1 */)
    //     0x115e064: mov             x3, x1
    //     0x115e068: mov             x0, x2
    //     0x115e06c: mov             v1.16b, v0.16b
    //     0x115e070: stur            x1, [fp, #-0x18]
    //     0x115e074: stur            x2, [fp, #-0x20]
    //     0x115e078: mov             x17, #-0x290
    // 0x115e078: r17 = -656
    // 0x115e07c: str             d0, [fp, x17]
    // 0x115e080: CheckStackOverflow
    //     0x115e080: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115e084: cmp             SP, x16
    //     0x115e088: b.ls            #0x115f3b0
    // 0x115e08c: cmp             w3, w0
    // 0x115e090: b.ne            #0x115e0a4
    // 0x115e094: mov             x0, x3
    // 0x115e098: LeaveFrame
    //     0x115e098: mov             SP, fp
    //     0x115e09c: ldp             fp, lr, [SP], #0x10
    // 0x115e0a0: ret
    //     0x115e0a0: ret             
    // 0x115e0a4: d2 = 0.500000
    //     0x115e0a4: fmov            d2, #0.50000000
    // 0x115e0a8: fcmp            d2, d1
    // 0x115e0ac: b.le            #0x115e0c0
    // 0x115e0b0: LoadField: r1 = r3->field_13
    //     0x115e0b0: ldur            w1, [x3, #0x13]
    // 0x115e0b4: DecompressPointer r1
    //     0x115e0b4: add             x1, x1, HEAP, lsl #32
    // 0x115e0b8: mov             x4, x1
    // 0x115e0bc: b               #0x115e0cc
    // 0x115e0c0: LoadField: r1 = r0->field_13
    //     0x115e0c0: ldur            w1, [x0, #0x13]
    // 0x115e0c4: DecompressPointer r1
    //     0x115e0c4: add             x1, x1, HEAP, lsl #32
    // 0x115e0c8: mov             x4, x1
    // 0x115e0cc: stur            x4, [fp, #-0x10]
    // 0x115e0d0: fcmp            d2, d1
    // 0x115e0d4: b.le            #0x115e0e8
    // 0x115e0d8: LoadField: r1 = r3->field_7
    //     0x115e0d8: ldur            w1, [x3, #7]
    // 0x115e0dc: DecompressPointer r1
    //     0x115e0dc: add             x1, x1, HEAP, lsl #32
    // 0x115e0e0: mov             x5, x1
    // 0x115e0e4: b               #0x115e0f4
    // 0x115e0e8: LoadField: r1 = r0->field_7
    //     0x115e0e8: ldur            w1, [x0, #7]
    // 0x115e0ec: DecompressPointer r1
    //     0x115e0ec: add             x1, x1, HEAP, lsl #32
    // 0x115e0f0: mov             x5, x1
    // 0x115e0f4: mov             x1, x3
    // 0x115e0f8: mov             x2, x0
    // 0x115e0fc: mov             v0.16b, v1.16b
    // 0x115e100: stur            x5, [fp, #-8]
    // 0x115e104: r0 = _lerpThemeExtensions()
    //     0x115e104: bl              #0x116a974  ; [package:flutter/src/material/theme_data.dart] ThemeData::_lerpThemeExtensions
    // 0x115e108: r17 = -656
    //     0x115e108: mov             x17, #-0x290
    // 0x115e10c: ldr             d1, [fp, x17]
    // 0x115e110: d2 = 0.500000
    //     0x115e110: fmov            d2, #0.50000000
    // 0x115e114: stur            x0, [fp, #-0x38]
    // 0x115e118: fcmp            d2, d1
    // 0x115e11c: b.le            #0x115e138
    // 0x115e120: ldur            x3, [fp, #-0x18]
    // 0x115e124: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x115e124: ldur            w1, [x3, #0x17]
    // 0x115e128: DecompressPointer r1
    //     0x115e128: add             x1, x1, HEAP, lsl #32
    // 0x115e12c: mov             x5, x1
    // 0x115e130: ldur            x4, [fp, #-0x20]
    // 0x115e134: b               #0x115e14c
    // 0x115e138: ldur            x3, [fp, #-0x18]
    // 0x115e13c: ldur            x4, [fp, #-0x20]
    // 0x115e140: ArrayLoad: r1 = r4[0]  ; List_4
    //     0x115e140: ldur            w1, [x4, #0x17]
    // 0x115e144: DecompressPointer r1
    //     0x115e144: add             x1, x1, HEAP, lsl #32
    // 0x115e148: mov             x5, x1
    // 0x115e14c: stur            x5, [fp, #-0x30]
    // 0x115e150: fcmp            d2, d1
    // 0x115e154: b.le            #0x115e168
    // 0x115e158: LoadField: r1 = r3->field_1b
    //     0x115e158: ldur            w1, [x3, #0x1b]
    // 0x115e15c: DecompressPointer r1
    //     0x115e15c: add             x1, x1, HEAP, lsl #32
    // 0x115e160: mov             x6, x1
    // 0x115e164: b               #0x115e174
    // 0x115e168: LoadField: r1 = r4->field_1b
    //     0x115e168: ldur            w1, [x4, #0x1b]
    // 0x115e16c: DecompressPointer r1
    //     0x115e16c: add             x1, x1, HEAP, lsl #32
    // 0x115e170: mov             x6, x1
    // 0x115e174: stur            x6, [fp, #-0x28]
    // 0x115e178: LoadField: r1 = r3->field_27
    //     0x115e178: ldur            w1, [x3, #0x27]
    // 0x115e17c: DecompressPointer r1
    //     0x115e17c: add             x1, x1, HEAP, lsl #32
    // 0x115e180: LoadField: r2 = r4->field_27
    //     0x115e180: ldur            w2, [x4, #0x27]
    // 0x115e184: DecompressPointer r2
    //     0x115e184: add             x2, x2, HEAP, lsl #32
    // 0x115e188: mov             v0.16b, v1.16b
    // 0x115e18c: r0 = lerp()
    //     0x115e18c: bl              #0x116a838  ; [package:flutter/src/material/scrollbar_theme.dart] ScrollbarThemeData::lerp
    // 0x115e190: r17 = -656
    //     0x115e190: mov             x17, #-0x290
    // 0x115e194: ldr             d1, [fp, x17]
    // 0x115e198: d2 = 0.500000
    //     0x115e198: fmov            d2, #0.50000000
    // 0x115e19c: stur            x0, [fp, #-0x50]
    // 0x115e1a0: fcmp            d2, d1
    // 0x115e1a4: b.le            #0x115e1c0
    // 0x115e1a8: ldur            x3, [fp, #-0x18]
    // 0x115e1ac: LoadField: r1 = r3->field_2b
    //     0x115e1ac: ldur            w1, [x3, #0x2b]
    // 0x115e1b0: DecompressPointer r1
    //     0x115e1b0: add             x1, x1, HEAP, lsl #32
    // 0x115e1b4: mov             x5, x1
    // 0x115e1b8: ldur            x4, [fp, #-0x20]
    // 0x115e1bc: b               #0x115e1d4
    // 0x115e1c0: ldur            x3, [fp, #-0x18]
    // 0x115e1c4: ldur            x4, [fp, #-0x20]
    // 0x115e1c8: LoadField: r1 = r4->field_2b
    //     0x115e1c8: ldur            w1, [x4, #0x2b]
    // 0x115e1cc: DecompressPointer r1
    //     0x115e1cc: add             x1, x1, HEAP, lsl #32
    // 0x115e1d0: mov             x5, x1
    // 0x115e1d4: stur            x5, [fp, #-0x48]
    // 0x115e1d8: fcmp            d2, d1
    // 0x115e1dc: b.le            #0x115e1f0
    // 0x115e1e0: LoadField: r1 = r3->field_2f
    //     0x115e1e0: ldur            w1, [x3, #0x2f]
    // 0x115e1e4: DecompressPointer r1
    //     0x115e1e4: add             x1, x1, HEAP, lsl #32
    // 0x115e1e8: mov             x6, x1
    // 0x115e1ec: b               #0x115e1fc
    // 0x115e1f0: LoadField: r1 = r4->field_2f
    //     0x115e1f0: ldur            w1, [x4, #0x2f]
    // 0x115e1f4: DecompressPointer r1
    //     0x115e1f4: add             x1, x1, HEAP, lsl #32
    // 0x115e1f8: mov             x6, x1
    // 0x115e1fc: stur            x6, [fp, #-0x40]
    // 0x115e200: LoadField: r1 = r3->field_33
    //     0x115e200: ldur            w1, [x3, #0x33]
    // 0x115e204: DecompressPointer r1
    //     0x115e204: add             x1, x1, HEAP, lsl #32
    // 0x115e208: LoadField: r2 = r4->field_33
    //     0x115e208: ldur            w2, [x4, #0x33]
    // 0x115e20c: DecompressPointer r2
    //     0x115e20c: add             x2, x2, HEAP, lsl #32
    // 0x115e210: mov             v0.16b, v1.16b
    // 0x115e214: r0 = lerp()
    //     0x115e214: bl              #0x116a5f8  ; [package:flutter/src/material/theme_data.dart] VisualDensity::lerp
    // 0x115e218: mov             x4, x0
    // 0x115e21c: ldur            x0, [fp, #-0x18]
    // 0x115e220: stur            x4, [fp, #-0x60]
    // 0x115e224: LoadField: r1 = r0->field_37
    //     0x115e224: ldur            w1, [x0, #0x37]
    // 0x115e228: DecompressPointer r1
    //     0x115e228: add             x1, x1, HEAP, lsl #32
    // 0x115e22c: ldur            x5, [fp, #-0x20]
    // 0x115e230: LoadField: r2 = r5->field_37
    //     0x115e230: ldur            w2, [x5, #0x37]
    // 0x115e234: DecompressPointer r2
    //     0x115e234: add             x2, x2, HEAP, lsl #32
    // 0x115e238: r17 = -656
    //     0x115e238: mov             x17, #-0x290
    // 0x115e23c: ldr             d0, [fp, x17]
    // 0x115e240: r6 = inline_Allocate_Double()
    //     0x115e240: ldp             x6, x3, [THR, #0x60]  ; THR::top
    //     0x115e244: add             x6, x6, #0x10
    //     0x115e248: cmp             x3, x6
    //     0x115e24c: b.ls            #0x115f3b8
    //     0x115e250: str             x6, [THR, #0x60]  ; THR::top
    //     0x115e254: sub             x6, x6, #0xf
    //     0x115e258: mov             x3, #0xe19c
    //     0x115e25c: movk            x3, #3, lsl #16
    //     0x115e260: stur            x3, [x6, #-1]
    // 0x115e264: dmb             ishst
    // 0x115e268: StoreField: r6->field_7 = d0
    //     0x115e268: stur            d0, [x6, #7]
    // 0x115e26c: mov             x3, x6
    // 0x115e270: stur            x6, [fp, #-0x58]
    // 0x115e274: r0 = lerp()
    //     0x115e274: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x115e278: mov             x4, x0
    // 0x115e27c: ldur            x0, [fp, #-0x18]
    // 0x115e280: stur            x4, [fp, #-0x68]
    // 0x115e284: LoadField: r1 = r0->field_3b
    //     0x115e284: ldur            w1, [x0, #0x3b]
    // 0x115e288: DecompressPointer r1
    //     0x115e288: add             x1, x1, HEAP, lsl #32
    // 0x115e28c: ldur            x5, [fp, #-0x20]
    // 0x115e290: LoadField: r2 = r5->field_3b
    //     0x115e290: ldur            w2, [x5, #0x3b]
    // 0x115e294: DecompressPointer r2
    //     0x115e294: add             x2, x2, HEAP, lsl #32
    // 0x115e298: ldur            x3, [fp, #-0x58]
    // 0x115e29c: r0 = lerp()
    //     0x115e29c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x115e2a0: mov             x3, x0
    // 0x115e2a4: ldur            x0, [fp, #-0x18]
    // 0x115e2a8: stur            x3, [fp, #-0x70]
    // 0x115e2ac: LoadField: r1 = r0->field_3f
    //     0x115e2ac: ldur            w1, [x0, #0x3f]
    // 0x115e2b0: DecompressPointer r1
    //     0x115e2b0: add             x1, x1, HEAP, lsl #32
    // 0x115e2b4: ldur            x4, [fp, #-0x20]
    // 0x115e2b8: LoadField: r2 = r4->field_3f
    //     0x115e2b8: ldur            w2, [x4, #0x3f]
    // 0x115e2bc: DecompressPointer r2
    //     0x115e2bc: add             x2, x2, HEAP, lsl #32
    // 0x115e2c0: r17 = -656
    //     0x115e2c0: mov             x17, #-0x290
    // 0x115e2c4: ldr             d0, [fp, x17]
    // 0x115e2c8: r0 = lerp()
    //     0x115e2c8: bl              #0x1169678  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::lerp
    // 0x115e2cc: mov             x4, x0
    // 0x115e2d0: ldur            x0, [fp, #-0x18]
    // 0x115e2d4: stur            x4, [fp, #-0x78]
    // 0x115e2d8: LoadField: r1 = r0->field_43
    //     0x115e2d8: ldur            w1, [x0, #0x43]
    // 0x115e2dc: DecompressPointer r1
    //     0x115e2dc: add             x1, x1, HEAP, lsl #32
    // 0x115e2e0: ldur            x5, [fp, #-0x20]
    // 0x115e2e4: LoadField: r2 = r5->field_43
    //     0x115e2e4: ldur            w2, [x5, #0x43]
    // 0x115e2e8: DecompressPointer r2
    //     0x115e2e8: add             x2, x2, HEAP, lsl #32
    // 0x115e2ec: ldur            x3, [fp, #-0x58]
    // 0x115e2f0: r0 = lerp()
    //     0x115e2f0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x115e2f4: mov             x4, x0
    // 0x115e2f8: ldur            x0, [fp, #-0x18]
    // 0x115e2fc: stur            x4, [fp, #-0x80]
    // 0x115e300: LoadField: r1 = r0->field_47
    //     0x115e300: ldur            w1, [x0, #0x47]
    // 0x115e304: DecompressPointer r1
    //     0x115e304: add             x1, x1, HEAP, lsl #32
    // 0x115e308: ldur            x5, [fp, #-0x20]
    // 0x115e30c: LoadField: r2 = r5->field_47
    //     0x115e30c: ldur            w2, [x5, #0x47]
    // 0x115e310: DecompressPointer r2
    //     0x115e310: add             x2, x2, HEAP, lsl #32
    // 0x115e314: ldur            x3, [fp, #-0x58]
    // 0x115e318: r0 = lerp()
    //     0x115e318: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x115e31c: mov             x4, x0
    // 0x115e320: ldur            x0, [fp, #-0x18]
    // 0x115e324: stur            x4, [fp, #-0x88]
    // 0x115e328: LoadField: r1 = r0->field_4b
    //     0x115e328: ldur            w1, [x0, #0x4b]
    // 0x115e32c: DecompressPointer r1
    //     0x115e32c: add             x1, x1, HEAP, lsl #32
    // 0x115e330: ldur            x5, [fp, #-0x20]
    // 0x115e334: LoadField: r2 = r5->field_4b
    //     0x115e334: ldur            w2, [x5, #0x4b]
    // 0x115e338: DecompressPointer r2
    //     0x115e338: add             x2, x2, HEAP, lsl #32
    // 0x115e33c: ldur            x3, [fp, #-0x58]
    // 0x115e340: r0 = lerp()
    //     0x115e340: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x115e344: mov             x4, x0
    // 0x115e348: ldur            x0, [fp, #-0x18]
    // 0x115e34c: stur            x4, [fp, #-0x90]
    // 0x115e350: LoadField: r1 = r0->field_4f
    //     0x115e350: ldur            w1, [x0, #0x4f]
    // 0x115e354: DecompressPointer r1
    //     0x115e354: add             x1, x1, HEAP, lsl #32
    // 0x115e358: ldur            x5, [fp, #-0x20]
    // 0x115e35c: LoadField: r2 = r5->field_4f
    //     0x115e35c: ldur            w2, [x5, #0x4f]
    // 0x115e360: DecompressPointer r2
    //     0x115e360: add             x2, x2, HEAP, lsl #32
    // 0x115e364: ldur            x3, [fp, #-0x58]
    // 0x115e368: r0 = lerp()
    //     0x115e368: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x115e36c: mov             x4, x0
    // 0x115e370: ldur            x0, [fp, #-0x18]
    // 0x115e374: stur            x4, [fp, #-0x98]
    // 0x115e378: LoadField: r1 = r0->field_53
    //     0x115e378: ldur            w1, [x0, #0x53]
    // 0x115e37c: DecompressPointer r1
    //     0x115e37c: add             x1, x1, HEAP, lsl #32
    // 0x115e380: ldur            x5, [fp, #-0x20]
    // 0x115e384: LoadField: r2 = r5->field_53
    //     0x115e384: ldur            w2, [x5, #0x53]
    // 0x115e388: DecompressPointer r2
    //     0x115e388: add             x2, x2, HEAP, lsl #32
    // 0x115e38c: ldur            x3, [fp, #-0x58]
    // 0x115e390: r0 = lerp()
    //     0x115e390: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x115e394: mov             x4, x0
    // 0x115e398: ldur            x0, [fp, #-0x18]
    // 0x115e39c: stur            x4, [fp, #-0xa0]
    // 0x115e3a0: LoadField: r1 = r0->field_57
    //     0x115e3a0: ldur            w1, [x0, #0x57]
    // 0x115e3a4: DecompressPointer r1
    //     0x115e3a4: add             x1, x1, HEAP, lsl #32
    // 0x115e3a8: ldur            x5, [fp, #-0x20]
    // 0x115e3ac: LoadField: r2 = r5->field_57
    //     0x115e3ac: ldur            w2, [x5, #0x57]
    // 0x115e3b0: DecompressPointer r2
    //     0x115e3b0: add             x2, x2, HEAP, lsl #32
    // 0x115e3b4: ldur            x3, [fp, #-0x58]
    // 0x115e3b8: r0 = lerp()
    //     0x115e3b8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x115e3bc: mov             x4, x0
    // 0x115e3c0: ldur            x0, [fp, #-0x18]
    // 0x115e3c4: stur            x4, [fp, #-0xa8]
    // 0x115e3c8: LoadField: r1 = r0->field_5b
    //     0x115e3c8: ldur            w1, [x0, #0x5b]
    // 0x115e3cc: DecompressPointer r1
    //     0x115e3cc: add             x1, x1, HEAP, lsl #32
    // 0x115e3d0: ldur            x5, [fp, #-0x20]
    // 0x115e3d4: LoadField: r2 = r5->field_5b
    //     0x115e3d4: ldur            w2, [x5, #0x5b]
    // 0x115e3d8: DecompressPointer r2
    //     0x115e3d8: add             x2, x2, HEAP, lsl #32
    // 0x115e3dc: ldur            x3, [fp, #-0x58]
    // 0x115e3e0: r0 = lerp()
    //     0x115e3e0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x115e3e4: mov             x4, x0
    // 0x115e3e8: ldur            x0, [fp, #-0x18]
    // 0x115e3ec: stur            x4, [fp, #-0xb0]
    // 0x115e3f0: LoadField: r1 = r0->field_5f
    //     0x115e3f0: ldur            w1, [x0, #0x5f]
    // 0x115e3f4: DecompressPointer r1
    //     0x115e3f4: add             x1, x1, HEAP, lsl #32
    // 0x115e3f8: ldur            x5, [fp, #-0x20]
    // 0x115e3fc: LoadField: r2 = r5->field_5f
    //     0x115e3fc: ldur            w2, [x5, #0x5f]
    // 0x115e400: DecompressPointer r2
    //     0x115e400: add             x2, x2, HEAP, lsl #32
    // 0x115e404: ldur            x3, [fp, #-0x58]
    // 0x115e408: r0 = lerp()
    //     0x115e408: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x115e40c: mov             x4, x0
    // 0x115e410: ldur            x0, [fp, #-0x18]
    // 0x115e414: stur            x4, [fp, #-0xb8]
    // 0x115e418: LoadField: r1 = r0->field_63
    //     0x115e418: ldur            w1, [x0, #0x63]
    // 0x115e41c: DecompressPointer r1
    //     0x115e41c: add             x1, x1, HEAP, lsl #32
    // 0x115e420: ldur            x5, [fp, #-0x20]
    // 0x115e424: LoadField: r2 = r5->field_63
    //     0x115e424: ldur            w2, [x5, #0x63]
    // 0x115e428: DecompressPointer r2
    //     0x115e428: add             x2, x2, HEAP, lsl #32
    // 0x115e42c: ldur            x3, [fp, #-0x58]
    // 0x115e430: r0 = lerp()
    //     0x115e430: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x115e434: mov             x4, x0
    // 0x115e438: ldur            x0, [fp, #-0x18]
    // 0x115e43c: stur            x4, [fp, #-0xc0]
    // 0x115e440: LoadField: r1 = r0->field_67
    //     0x115e440: ldur            w1, [x0, #0x67]
    // 0x115e444: DecompressPointer r1
    //     0x115e444: add             x1, x1, HEAP, lsl #32
    // 0x115e448: ldur            x5, [fp, #-0x20]
    // 0x115e44c: LoadField: r2 = r5->field_67
    //     0x115e44c: ldur            w2, [x5, #0x67]
    // 0x115e450: DecompressPointer r2
    //     0x115e450: add             x2, x2, HEAP, lsl #32
    // 0x115e454: ldur            x3, [fp, #-0x58]
    // 0x115e458: r0 = lerp()
    //     0x115e458: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x115e45c: mov             x4, x0
    // 0x115e460: ldur            x0, [fp, #-0x18]
    // 0x115e464: stur            x4, [fp, #-0xc8]
    // 0x115e468: LoadField: r1 = r0->field_6b
    //     0x115e468: ldur            w1, [x0, #0x6b]
    // 0x115e46c: DecompressPointer r1
    //     0x115e46c: add             x1, x1, HEAP, lsl #32
    // 0x115e470: ldur            x5, [fp, #-0x20]
    // 0x115e474: LoadField: r2 = r5->field_6b
    //     0x115e474: ldur            w2, [x5, #0x6b]
    // 0x115e478: DecompressPointer r2
    //     0x115e478: add             x2, x2, HEAP, lsl #32
    // 0x115e47c: ldur            x3, [fp, #-0x58]
    // 0x115e480: r0 = lerp()
    //     0x115e480: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x115e484: mov             x4, x0
    // 0x115e488: ldur            x0, [fp, #-0x18]
    // 0x115e48c: stur            x4, [fp, #-0xd0]
    // 0x115e490: LoadField: r1 = r0->field_6f
    //     0x115e490: ldur            w1, [x0, #0x6f]
    // 0x115e494: DecompressPointer r1
    //     0x115e494: add             x1, x1, HEAP, lsl #32
    // 0x115e498: ldur            x5, [fp, #-0x20]
    // 0x115e49c: LoadField: r2 = r5->field_6f
    //     0x115e49c: ldur            w2, [x5, #0x6f]
    // 0x115e4a0: DecompressPointer r2
    //     0x115e4a0: add             x2, x2, HEAP, lsl #32
    // 0x115e4a4: ldur            x3, [fp, #-0x58]
    // 0x115e4a8: r0 = lerp()
    //     0x115e4a8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x115e4ac: mov             x4, x0
    // 0x115e4b0: ldur            x0, [fp, #-0x18]
    // 0x115e4b4: stur            x4, [fp, #-0xd8]
    // 0x115e4b8: LoadField: r1 = r0->field_73
    //     0x115e4b8: ldur            w1, [x0, #0x73]
    // 0x115e4bc: DecompressPointer r1
    //     0x115e4bc: add             x1, x1, HEAP, lsl #32
    // 0x115e4c0: ldur            x5, [fp, #-0x20]
    // 0x115e4c4: LoadField: r2 = r5->field_73
    //     0x115e4c4: ldur            w2, [x5, #0x73]
    // 0x115e4c8: DecompressPointer r2
    //     0x115e4c8: add             x2, x2, HEAP, lsl #32
    // 0x115e4cc: ldur            x3, [fp, #-0x58]
    // 0x115e4d0: r0 = lerp()
    //     0x115e4d0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x115e4d4: mov             x4, x0
    // 0x115e4d8: ldur            x0, [fp, #-0x18]
    // 0x115e4dc: stur            x4, [fp, #-0xe0]
    // 0x115e4e0: LoadField: r1 = r0->field_77
    //     0x115e4e0: ldur            w1, [x0, #0x77]
    // 0x115e4e4: DecompressPointer r1
    //     0x115e4e4: add             x1, x1, HEAP, lsl #32
    // 0x115e4e8: ldur            x5, [fp, #-0x20]
    // 0x115e4ec: LoadField: r2 = r5->field_77
    //     0x115e4ec: ldur            w2, [x5, #0x77]
    // 0x115e4f0: DecompressPointer r2
    //     0x115e4f0: add             x2, x2, HEAP, lsl #32
    // 0x115e4f4: ldur            x3, [fp, #-0x58]
    // 0x115e4f8: r0 = lerp()
    //     0x115e4f8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x115e4fc: mov             x4, x0
    // 0x115e500: ldur            x0, [fp, #-0x18]
    // 0x115e504: stur            x4, [fp, #-0xe8]
    // 0x115e508: LoadField: r1 = r0->field_7b
    //     0x115e508: ldur            w1, [x0, #0x7b]
    // 0x115e50c: DecompressPointer r1
    //     0x115e50c: add             x1, x1, HEAP, lsl #32
    // 0x115e510: ldur            x5, [fp, #-0x20]
    // 0x115e514: LoadField: r2 = r5->field_7b
    //     0x115e514: ldur            w2, [x5, #0x7b]
    // 0x115e518: DecompressPointer r2
    //     0x115e518: add             x2, x2, HEAP, lsl #32
    // 0x115e51c: ldur            x3, [fp, #-0x58]
    // 0x115e520: r0 = lerp()
    //     0x115e520: bl              #0xfb012c  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::lerp
    // 0x115e524: mov             x4, x0
    // 0x115e528: ldur            x0, [fp, #-0x18]
    // 0x115e52c: stur            x4, [fp, #-0xf0]
    // 0x115e530: LoadField: r1 = r0->field_7f
    //     0x115e530: ldur            w1, [x0, #0x7f]
    // 0x115e534: DecompressPointer r1
    //     0x115e534: add             x1, x1, HEAP, lsl #32
    // 0x115e538: ldur            x5, [fp, #-0x20]
    // 0x115e53c: LoadField: r2 = r5->field_7f
    //     0x115e53c: ldur            w2, [x5, #0x7f]
    // 0x115e540: DecompressPointer r2
    //     0x115e540: add             x2, x2, HEAP, lsl #32
    // 0x115e544: ldur            x3, [fp, #-0x58]
    // 0x115e548: r0 = lerp()
    //     0x115e548: bl              #0xfb012c  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::lerp
    // 0x115e54c: mov             x3, x0
    // 0x115e550: ldur            x0, [fp, #-0x18]
    // 0x115e554: stur            x3, [fp, #-0xf8]
    // 0x115e558: LoadField: r1 = r0->field_83
    //     0x115e558: ldur            w1, [x0, #0x83]
    // 0x115e55c: DecompressPointer r1
    //     0x115e55c: add             x1, x1, HEAP, lsl #32
    // 0x115e560: ldur            x4, [fp, #-0x20]
    // 0x115e564: LoadField: r2 = r4->field_83
    //     0x115e564: ldur            w2, [x4, #0x83]
    // 0x115e568: DecompressPointer r2
    //     0x115e568: add             x2, x2, HEAP, lsl #32
    // 0x115e56c: r17 = -656
    //     0x115e56c: mov             x17, #-0x290
    // 0x115e570: ldr             d0, [fp, x17]
    // 0x115e574: r0 = lerp()
    //     0x115e574: bl              #0x1169308  ; [package:flutter/src/material/text_theme.dart] TextTheme::lerp
    // 0x115e578: mov             x3, x0
    // 0x115e57c: ldur            x0, [fp, #-0x18]
    // 0x115e580: stur            x3, [fp, #-0x100]
    // 0x115e584: LoadField: r1 = r0->field_87
    //     0x115e584: ldur            w1, [x0, #0x87]
    // 0x115e588: DecompressPointer r1
    //     0x115e588: add             x1, x1, HEAP, lsl #32
    // 0x115e58c: ldur            x4, [fp, #-0x20]
    // 0x115e590: LoadField: r2 = r4->field_87
    //     0x115e590: ldur            w2, [x4, #0x87]
    // 0x115e594: DecompressPointer r2
    //     0x115e594: add             x2, x2, HEAP, lsl #32
    // 0x115e598: r17 = -656
    //     0x115e598: mov             x17, #-0x290
    // 0x115e59c: ldr             d0, [fp, x17]
    // 0x115e5a0: r0 = lerp()
    //     0x115e5a0: bl              #0x1169308  ; [package:flutter/src/material/text_theme.dart] TextTheme::lerp
    // 0x115e5a4: mov             x3, x0
    // 0x115e5a8: ldur            x0, [fp, #-0x18]
    // 0x115e5ac: r17 = -264
    //     0x115e5ac: mov             x17, #-0x108
    // 0x115e5b0: str             x3, [fp, x17]
    // 0x115e5b4: LoadField: r1 = r0->field_8b
    //     0x115e5b4: ldur            w1, [x0, #0x8b]
    // 0x115e5b8: DecompressPointer r1
    //     0x115e5b8: add             x1, x1, HEAP, lsl #32
    // 0x115e5bc: ldur            x4, [fp, #-0x20]
    // 0x115e5c0: LoadField: r2 = r4->field_8b
    //     0x115e5c0: ldur            w2, [x4, #0x8b]
    // 0x115e5c4: DecompressPointer r2
    //     0x115e5c4: add             x2, x2, HEAP, lsl #32
    // 0x115e5c8: r17 = -656
    //     0x115e5c8: mov             x17, #-0x290
    // 0x115e5cc: ldr             d0, [fp, x17]
    // 0x115e5d0: r0 = lerp()
    //     0x115e5d0: bl              #0x11691c4  ; [package:flutter/src/material/typography.dart] Typography::lerp
    // 0x115e5d4: mov             x3, x0
    // 0x115e5d8: ldur            x0, [fp, #-0x18]
    // 0x115e5dc: r17 = -272
    //     0x115e5dc: mov             x17, #-0x110
    // 0x115e5e0: str             x3, [fp, x17]
    // 0x115e5e4: LoadField: r1 = r0->field_93
    //     0x115e5e4: ldur            w1, [x0, #0x93]
    // 0x115e5e8: DecompressPointer r1
    //     0x115e5e8: add             x1, x1, HEAP, lsl #32
    // 0x115e5ec: ldur            x4, [fp, #-0x20]
    // 0x115e5f0: LoadField: r2 = r4->field_93
    //     0x115e5f0: ldur            w2, [x4, #0x93]
    // 0x115e5f4: DecompressPointer r2
    //     0x115e5f4: add             x2, x2, HEAP, lsl #32
    // 0x115e5f8: r17 = -656
    //     0x115e5f8: mov             x17, #-0x290
    // 0x115e5fc: ldr             d0, [fp, x17]
    // 0x115e600: r0 = lerp()
    //     0x115e600: bl              #0x1168e98  ; [package:flutter/src/material/app_bar_theme.dart] AppBarThemeData::lerp
    // 0x115e604: mov             x3, x0
    // 0x115e608: ldur            x0, [fp, #-0x18]
    // 0x115e60c: r17 = -280
    //     0x115e60c: mov             x17, #-0x118
    // 0x115e610: str             x3, [fp, x17]
    // 0x115e614: LoadField: r1 = r0->field_97
    //     0x115e614: ldur            w1, [x0, #0x97]
    // 0x115e618: DecompressPointer r1
    //     0x115e618: add             x1, x1, HEAP, lsl #32
    // 0x115e61c: ldur            x4, [fp, #-0x20]
    // 0x115e620: LoadField: r2 = r4->field_97
    //     0x115e620: ldur            w2, [x4, #0x97]
    // 0x115e624: DecompressPointer r2
    //     0x115e624: add             x2, x2, HEAP, lsl #32
    // 0x115e628: r17 = -656
    //     0x115e628: mov             x17, #-0x290
    // 0x115e62c: ldr             d0, [fp, x17]
    // 0x115e630: r0 = lerp()
    //     0x115e630: bl              #0x1168d38  ; [package:flutter/src/material/badge_theme.dart] BadgeThemeData::lerp
    // 0x115e634: mov             x3, x0
    // 0x115e638: ldur            x0, [fp, #-0x18]
    // 0x115e63c: r17 = -288
    //     0x115e63c: mov             x17, #-0x120
    // 0x115e640: str             x3, [fp, x17]
    // 0x115e644: LoadField: r1 = r0->field_9b
    //     0x115e644: ldur            w1, [x0, #0x9b]
    // 0x115e648: DecompressPointer r1
    //     0x115e648: add             x1, x1, HEAP, lsl #32
    // 0x115e64c: ldur            x4, [fp, #-0x20]
    // 0x115e650: LoadField: r2 = r4->field_9b
    //     0x115e650: ldur            w2, [x4, #0x9b]
    // 0x115e654: DecompressPointer r2
    //     0x115e654: add             x2, x2, HEAP, lsl #32
    // 0x115e658: r17 = -656
    //     0x115e658: mov             x17, #-0x290
    // 0x115e65c: ldr             d0, [fp, x17]
    // 0x115e660: r0 = lerp()
    //     0x115e660: bl              #0x1168c04  ; [package:flutter/src/material/banner_theme.dart] MaterialBannerThemeData::lerp
    // 0x115e664: mov             x3, x0
    // 0x115e668: ldur            x0, [fp, #-0x18]
    // 0x115e66c: r17 = -296
    //     0x115e66c: mov             x17, #-0x128
    // 0x115e670: str             x3, [fp, x17]
    // 0x115e674: LoadField: r1 = r0->field_9f
    //     0x115e674: ldur            w1, [x0, #0x9f]
    // 0x115e678: DecompressPointer r1
    //     0x115e678: add             x1, x1, HEAP, lsl #32
    // 0x115e67c: ldur            x4, [fp, #-0x20]
    // 0x115e680: LoadField: r2 = r4->field_9f
    //     0x115e680: ldur            w2, [x4, #0x9f]
    // 0x115e684: DecompressPointer r2
    //     0x115e684: add             x2, x2, HEAP, lsl #32
    // 0x115e688: r17 = -656
    //     0x115e688: mov             x17, #-0x290
    // 0x115e68c: ldr             d0, [fp, x17]
    // 0x115e690: r0 = lerp()
    //     0x115e690: bl              #0x1168a70  ; [package:flutter/src/material/bottom_app_bar_theme.dart] BottomAppBarThemeData::lerp
    // 0x115e694: mov             x3, x0
    // 0x115e698: ldur            x0, [fp, #-0x18]
    // 0x115e69c: r17 = -304
    //     0x115e69c: mov             x17, #-0x130
    // 0x115e6a0: str             x3, [fp, x17]
    // 0x115e6a4: LoadField: r1 = r0->field_a3
    //     0x115e6a4: ldur            w1, [x0, #0xa3]
    // 0x115e6a8: DecompressPointer r1
    //     0x115e6a8: add             x1, x1, HEAP, lsl #32
    // 0x115e6ac: ldur            x4, [fp, #-0x20]
    // 0x115e6b0: LoadField: r2 = r4->field_a3
    //     0x115e6b0: ldur            w2, [x4, #0xa3]
    // 0x115e6b4: DecompressPointer r2
    //     0x115e6b4: add             x2, x2, HEAP, lsl #32
    // 0x115e6b8: r17 = -656
    //     0x115e6b8: mov             x17, #-0x290
    // 0x115e6bc: ldr             d0, [fp, x17]
    // 0x115e6c0: r0 = lerp()
    //     0x115e6c0: bl              #0x11688e4  ; [package:flutter/src/material/bottom_navigation_bar_theme.dart] BottomNavigationBarThemeData::lerp
    // 0x115e6c4: mov             x3, x0
    // 0x115e6c8: ldur            x0, [fp, #-0x18]
    // 0x115e6cc: r17 = -312
    //     0x115e6cc: mov             x17, #-0x138
    // 0x115e6d0: str             x3, [fp, x17]
    // 0x115e6d4: LoadField: r1 = r0->field_a7
    //     0x115e6d4: ldur            w1, [x0, #0xa7]
    // 0x115e6d8: DecompressPointer r1
    //     0x115e6d8: add             x1, x1, HEAP, lsl #32
    // 0x115e6dc: ldur            x4, [fp, #-0x20]
    // 0x115e6e0: LoadField: r2 = r4->field_a7
    //     0x115e6e0: ldur            w2, [x4, #0xa7]
    // 0x115e6e4: DecompressPointer r2
    //     0x115e6e4: add             x2, x2, HEAP, lsl #32
    // 0x115e6e8: r17 = -656
    //     0x115e6e8: mov             x17, #-0x290
    // 0x115e6ec: ldr             d0, [fp, x17]
    // 0x115e6f0: r0 = lerp()
    //     0x115e6f0: bl              #0x116871c  ; [package:flutter/src/material/bottom_sheet_theme.dart] BottomSheetThemeData::lerp
    // 0x115e6f4: r17 = -656
    //     0x115e6f4: mov             x17, #-0x290
    // 0x115e6f8: ldr             d1, [fp, x17]
    // 0x115e6fc: d0 = 0.500000
    //     0x115e6fc: fmov            d0, #0.50000000
    // 0x115e700: r17 = -328
    //     0x115e700: mov             x17, #-0x148
    // 0x115e704: str             x0, [fp, x17]
    // 0x115e708: fcmp            d0, d1
    // 0x115e70c: b.le            #0x115e72c
    // 0x115e710: ldur            x3, [fp, #-0x18]
    // 0x115e714: LoadField: r1 = r3->field_ab
    //     0x115e714: ldur            w1, [x3, #0xab]
    // 0x115e718: DecompressPointer r1
    //     0x115e718: add             x1, x1, HEAP, lsl #32
    // 0x115e71c: r17 = -320
    //     0x115e71c: mov             x17, #-0x140
    // 0x115e720: str             x1, [fp, x17]
    // 0x115e724: ldur            x4, [fp, #-0x20]
    // 0x115e728: b               #0x115e744
    // 0x115e72c: ldur            x3, [fp, #-0x18]
    // 0x115e730: ldur            x4, [fp, #-0x20]
    // 0x115e734: LoadField: r1 = r4->field_ab
    //     0x115e734: ldur            w1, [x4, #0xab]
    // 0x115e738: DecompressPointer r1
    //     0x115e738: add             x1, x1, HEAP, lsl #32
    // 0x115e73c: r17 = -320
    //     0x115e73c: mov             x17, #-0x140
    // 0x115e740: str             x1, [fp, x17]
    // 0x115e744: ldur            x2, [fp, #-0xb8]
    // 0x115e748: ldur            x1, [fp, #-0xc0]
    // 0x115e74c: ldur            x25, [fp, #-0xc8]
    // 0x115e750: ldur            x24, [fp, #-0xd0]
    // 0x115e754: ldur            x23, [fp, #-0xd8]
    // 0x115e758: ldur            x20, [fp, #-0xe0]
    // 0x115e75c: ldur            x19, [fp, #-0xe8]
    // 0x115e760: ldur            x14, [fp, #-0xf0]
    // 0x115e764: ldur            x13, [fp, #-0xf8]
    // 0x115e768: ldur            x12, [fp, #-0x100]
    // 0x115e76c: r17 = -264
    //     0x115e76c: mov             x17, #-0x108
    // 0x115e770: ldr             x11, [fp, x17]
    // 0x115e774: r17 = -272
    //     0x115e774: mov             x17, #-0x110
    // 0x115e778: ldr             x10, [fp, x17]
    // 0x115e77c: r17 = -280
    //     0x115e77c: mov             x17, #-0x118
    // 0x115e780: ldr             x9, [fp, x17]
    // 0x115e784: r17 = -288
    //     0x115e784: mov             x17, #-0x120
    // 0x115e788: ldr             x8, [fp, x17]
    // 0x115e78c: r17 = -296
    //     0x115e78c: mov             x17, #-0x128
    // 0x115e790: ldr             x7, [fp, x17]
    // 0x115e794: r17 = -304
    //     0x115e794: mov             x17, #-0x130
    // 0x115e798: ldr             x6, [fp, x17]
    // 0x115e79c: r17 = -312
    //     0x115e79c: mov             x17, #-0x138
    // 0x115e7a0: ldr             x5, [fp, x17]
    // 0x115e7a4: LoadField: r0 = r3->field_af
    //     0x115e7a4: ldur            w0, [x3, #0xaf]
    // 0x115e7a8: DecompressPointer r0
    //     0x115e7a8: add             x0, x0, HEAP, lsl #32
    // 0x115e7ac: LoadField: r3 = r4->field_af
    //     0x115e7ac: ldur            w3, [x4, #0xaf]
    // 0x115e7b0: DecompressPointer r3
    //     0x115e7b0: add             x3, x3, HEAP, lsl #32
    // 0x115e7b4: mov             x16, x2
    // 0x115e7b8: mov             x2, x0
    // 0x115e7bc: mov             x0, x16
    // 0x115e7c0: mov             x16, x3
    // 0x115e7c4: mov             x3, x2
    // 0x115e7c8: mov             x2, x16
    // 0x115e7cc: mov             x16, x1
    // 0x115e7d0: mov             x1, x3
    // 0x115e7d4: mov             x3, x16
    // 0x115e7d8: mov             v0.16b, v1.16b
    // 0x115e7dc: r0 = lerp()
    //     0x115e7dc: bl              #0x1168570  ; [package:flutter/src/material/card_theme.dart] CardThemeData::lerp
    // 0x115e7e0: mov             x3, x0
    // 0x115e7e4: ldur            x0, [fp, #-0x18]
    // 0x115e7e8: r17 = -336
    //     0x115e7e8: mov             x17, #-0x150
    // 0x115e7ec: str             x3, [fp, x17]
    // 0x115e7f0: LoadField: r1 = r0->field_b3
    //     0x115e7f0: ldur            w1, [x0, #0xb3]
    // 0x115e7f4: DecompressPointer r1
    //     0x115e7f4: add             x1, x1, HEAP, lsl #32
    // 0x115e7f8: ldur            x4, [fp, #-0x20]
    // 0x115e7fc: LoadField: r2 = r4->field_b3
    //     0x115e7fc: ldur            w2, [x4, #0xb3]
    // 0x115e800: DecompressPointer r2
    //     0x115e800: add             x2, x2, HEAP, lsl #32
    // 0x115e804: r17 = -656
    //     0x115e804: mov             x17, #-0x290
    // 0x115e808: ldr             d0, [fp, x17]
    // 0x115e80c: r0 = lerp()
    //     0x115e80c: bl              #0x1168460  ; [package:flutter/src/material/carousel_theme.dart] CarouselViewThemeData::lerp
    // 0x115e810: mov             x3, x0
    // 0x115e814: ldur            x0, [fp, #-0x18]
    // 0x115e818: r17 = -344
    //     0x115e818: mov             x17, #-0x158
    // 0x115e81c: str             x3, [fp, x17]
    // 0x115e820: LoadField: r1 = r0->field_b7
    //     0x115e820: ldur            w1, [x0, #0xb7]
    // 0x115e824: DecompressPointer r1
    //     0x115e824: add             x1, x1, HEAP, lsl #32
    // 0x115e828: ldur            x4, [fp, #-0x20]
    // 0x115e82c: LoadField: r2 = r4->field_b7
    //     0x115e82c: ldur            w2, [x4, #0xb7]
    // 0x115e830: DecompressPointer r2
    //     0x115e830: add             x2, x2, HEAP, lsl #32
    // 0x115e834: r17 = -656
    //     0x115e834: mov             x17, #-0x290
    // 0x115e838: ldr             d0, [fp, x17]
    // 0x115e83c: r0 = lerp()
    //     0x115e83c: bl              #0x116838c  ; [package:flutter/src/material/checkbox_theme.dart] CheckboxThemeData::lerp
    // 0x115e840: mov             x3, x0
    // 0x115e844: ldur            x0, [fp, #-0x18]
    // 0x115e848: r17 = -352
    //     0x115e848: mov             x17, #-0x160
    // 0x115e84c: str             x3, [fp, x17]
    // 0x115e850: LoadField: r1 = r0->field_bb
    //     0x115e850: ldur            w1, [x0, #0xbb]
    // 0x115e854: DecompressPointer r1
    //     0x115e854: add             x1, x1, HEAP, lsl #32
    // 0x115e858: ldur            x4, [fp, #-0x20]
    // 0x115e85c: LoadField: r2 = r4->field_bb
    //     0x115e85c: ldur            w2, [x4, #0xbb]
    // 0x115e860: DecompressPointer r2
    //     0x115e860: add             x2, x2, HEAP, lsl #32
    // 0x115e864: r17 = -656
    //     0x115e864: mov             x17, #-0x290
    // 0x115e868: ldr             d0, [fp, x17]
    // 0x115e86c: r0 = lerp()
    //     0x115e86c: bl              #0x116814c  ; [package:flutter/src/material/chip_theme.dart] ChipThemeData::lerp
    // 0x115e870: mov             x3, x0
    // 0x115e874: ldur            x0, [fp, #-0x18]
    // 0x115e878: r17 = -360
    //     0x115e878: mov             x17, #-0x168
    // 0x115e87c: str             x3, [fp, x17]
    // 0x115e880: LoadField: r1 = r0->field_bf
    //     0x115e880: ldur            w1, [x0, #0xbf]
    // 0x115e884: DecompressPointer r1
    //     0x115e884: add             x1, x1, HEAP, lsl #32
    // 0x115e888: ldur            x4, [fp, #-0x20]
    // 0x115e88c: LoadField: r2 = r4->field_bf
    //     0x115e88c: ldur            w2, [x4, #0xbf]
    // 0x115e890: DecompressPointer r2
    //     0x115e890: add             x2, x2, HEAP, lsl #32
    // 0x115e894: r17 = -656
    //     0x115e894: mov             x17, #-0x290
    // 0x115e898: ldr             d0, [fp, x17]
    // 0x115e89c: r0 = lerp()
    //     0x115e89c: bl              #0x1167f14  ; [package:flutter/src/material/data_table_theme.dart] DataTableThemeData::lerp
    // 0x115e8a0: mov             x3, x0
    // 0x115e8a4: ldur            x0, [fp, #-0x18]
    // 0x115e8a8: r17 = -368
    //     0x115e8a8: mov             x17, #-0x170
    // 0x115e8ac: str             x3, [fp, x17]
    // 0x115e8b0: LoadField: r1 = r0->field_c3
    //     0x115e8b0: ldur            w1, [x0, #0xc3]
    // 0x115e8b4: DecompressPointer r1
    //     0x115e8b4: add             x1, x1, HEAP, lsl #32
    // 0x115e8b8: ldur            x4, [fp, #-0x20]
    // 0x115e8bc: LoadField: r2 = r4->field_c3
    //     0x115e8bc: ldur            w2, [x4, #0xc3]
    // 0x115e8c0: DecompressPointer r2
    //     0x115e8c0: add             x2, x2, HEAP, lsl #32
    // 0x115e8c4: r17 = -656
    //     0x115e8c4: mov             x17, #-0x290
    // 0x115e8c8: ldr             d0, [fp, x17]
    // 0x115e8cc: r0 = lerp()
    //     0x115e8cc: bl              #0x1167b14  ; [package:flutter/src/material/date_picker_theme.dart] DatePickerThemeData::lerp
    // 0x115e8d0: mov             x3, x0
    // 0x115e8d4: ldur            x0, [fp, #-0x18]
    // 0x115e8d8: r17 = -376
    //     0x115e8d8: mov             x17, #-0x178
    // 0x115e8dc: str             x3, [fp, x17]
    // 0x115e8e0: LoadField: r1 = r0->field_c7
    //     0x115e8e0: ldur            w1, [x0, #0xc7]
    // 0x115e8e4: DecompressPointer r1
    //     0x115e8e4: add             x1, x1, HEAP, lsl #32
    // 0x115e8e8: ldur            x4, [fp, #-0x20]
    // 0x115e8ec: LoadField: r2 = r4->field_c7
    //     0x115e8ec: ldur            w2, [x4, #0xc7]
    // 0x115e8f0: DecompressPointer r2
    //     0x115e8f0: add             x2, x2, HEAP, lsl #32
    // 0x115e8f4: r17 = -656
    //     0x115e8f4: mov             x17, #-0x290
    // 0x115e8f8: ldr             d0, [fp, x17]
    // 0x115e8fc: r0 = lerp()
    //     0x115e8fc: bl              #0x11678bc  ; [package:flutter/src/material/dialog_theme.dart] DialogThemeData::lerp
    // 0x115e900: mov             x3, x0
    // 0x115e904: ldur            x0, [fp, #-0x18]
    // 0x115e908: r17 = -384
    //     0x115e908: mov             x17, #-0x180
    // 0x115e90c: str             x3, [fp, x17]
    // 0x115e910: LoadField: r1 = r0->field_cb
    //     0x115e910: ldur            w1, [x0, #0xcb]
    // 0x115e914: DecompressPointer r1
    //     0x115e914: add             x1, x1, HEAP, lsl #32
    // 0x115e918: ldur            x4, [fp, #-0x20]
    // 0x115e91c: LoadField: r2 = r4->field_cb
    //     0x115e91c: ldur            w2, [x4, #0xcb]
    // 0x115e920: DecompressPointer r2
    //     0x115e920: add             x2, x2, HEAP, lsl #32
    // 0x115e924: r17 = -656
    //     0x115e924: mov             x17, #-0x290
    // 0x115e928: ldr             d0, [fp, x17]
    // 0x115e92c: r0 = lerp()
    //     0x115e92c: bl              #0x116770c  ; [package:flutter/src/material/divider_theme.dart] DividerThemeData::lerp
    // 0x115e930: mov             x3, x0
    // 0x115e934: ldur            x0, [fp, #-0x18]
    // 0x115e938: r17 = -392
    //     0x115e938: mov             x17, #-0x188
    // 0x115e93c: str             x3, [fp, x17]
    // 0x115e940: LoadField: r1 = r0->field_cf
    //     0x115e940: ldur            w1, [x0, #0xcf]
    // 0x115e944: DecompressPointer r1
    //     0x115e944: add             x1, x1, HEAP, lsl #32
    // 0x115e948: ldur            x4, [fp, #-0x20]
    // 0x115e94c: LoadField: r2 = r4->field_cf
    //     0x115e94c: ldur            w2, [x4, #0xcf]
    // 0x115e950: DecompressPointer r2
    //     0x115e950: add             x2, x2, HEAP, lsl #32
    // 0x115e954: r17 = -656
    //     0x115e954: mov             x17, #-0x290
    // 0x115e958: ldr             d0, [fp, x17]
    // 0x115e95c: r0 = lerp()
    //     0x115e95c: bl              #0x1167564  ; [package:flutter/src/material/drawer_theme.dart] DrawerThemeData::lerp
    // 0x115e960: mov             x3, x0
    // 0x115e964: ldur            x0, [fp, #-0x18]
    // 0x115e968: r17 = -400
    //     0x115e968: mov             x17, #-0x190
    // 0x115e96c: str             x3, [fp, x17]
    // 0x115e970: LoadField: r1 = r0->field_d3
    //     0x115e970: ldur            w1, [x0, #0xd3]
    // 0x115e974: DecompressPointer r1
    //     0x115e974: add             x1, x1, HEAP, lsl #32
    // 0x115e978: ldur            x4, [fp, #-0x20]
    // 0x115e97c: LoadField: r2 = r4->field_d3
    //     0x115e97c: ldur            w2, [x4, #0xd3]
    // 0x115e980: DecompressPointer r2
    //     0x115e980: add             x2, x2, HEAP, lsl #32
    // 0x115e984: r17 = -656
    //     0x115e984: mov             x17, #-0x290
    // 0x115e988: ldr             d0, [fp, x17]
    // 0x115e98c: r0 = lerp()
    //     0x115e98c: bl              #0x1167464  ; [package:flutter/src/material/dropdown_menu_theme.dart] DropdownMenuThemeData::lerp
    // 0x115e990: mov             x3, x0
    // 0x115e994: ldur            x0, [fp, #-0x18]
    // 0x115e998: r17 = -408
    //     0x115e998: mov             x17, #-0x198
    // 0x115e99c: str             x3, [fp, x17]
    // 0x115e9a0: LoadField: r1 = r0->field_d7
    //     0x115e9a0: ldur            w1, [x0, #0xd7]
    // 0x115e9a4: DecompressPointer r1
    //     0x115e9a4: add             x1, x1, HEAP, lsl #32
    // 0x115e9a8: ldur            x4, [fp, #-0x20]
    // 0x115e9ac: LoadField: r2 = r4->field_d7
    //     0x115e9ac: ldur            w2, [x4, #0xd7]
    // 0x115e9b0: DecompressPointer r2
    //     0x115e9b0: add             x2, x2, HEAP, lsl #32
    // 0x115e9b4: r17 = -656
    //     0x115e9b4: mov             x17, #-0x290
    // 0x115e9b8: ldr             d0, [fp, x17]
    // 0x115e9bc: r0 = lerp()
    //     0x115e9bc: bl              #0x11673ec  ; [package:flutter/src/material/elevated_button_theme.dart] ElevatedButtonThemeData::lerp
    // 0x115e9c0: mov             x3, x0
    // 0x115e9c4: ldur            x0, [fp, #-0x18]
    // 0x115e9c8: r17 = -416
    //     0x115e9c8: mov             x17, #-0x1a0
    // 0x115e9cc: str             x3, [fp, x17]
    // 0x115e9d0: LoadField: r1 = r0->field_db
    //     0x115e9d0: ldur            w1, [x0, #0xdb]
    // 0x115e9d4: DecompressPointer r1
    //     0x115e9d4: add             x1, x1, HEAP, lsl #32
    // 0x115e9d8: ldur            x4, [fp, #-0x20]
    // 0x115e9dc: LoadField: r2 = r4->field_db
    //     0x115e9dc: ldur            w2, [x4, #0xdb]
    // 0x115e9e0: DecompressPointer r2
    //     0x115e9e0: add             x2, x2, HEAP, lsl #32
    // 0x115e9e4: r17 = -656
    //     0x115e9e4: mov             x17, #-0x290
    // 0x115e9e8: ldr             d0, [fp, x17]
    // 0x115e9ec: r0 = lerp()
    //     0x115e9ec: bl              #0x11672a4  ; [package:flutter/src/material/expansion_tile_theme.dart] ExpansionTileThemeData::lerp
    // 0x115e9f0: mov             x3, x0
    // 0x115e9f4: ldur            x0, [fp, #-0x18]
    // 0x115e9f8: r17 = -424
    //     0x115e9f8: mov             x17, #-0x1a8
    // 0x115e9fc: str             x3, [fp, x17]
    // 0x115ea00: LoadField: r1 = r0->field_df
    //     0x115ea00: ldur            w1, [x0, #0xdf]
    // 0x115ea04: DecompressPointer r1
    //     0x115ea04: add             x1, x1, HEAP, lsl #32
    // 0x115ea08: ldur            x4, [fp, #-0x20]
    // 0x115ea0c: LoadField: r2 = r4->field_df
    //     0x115ea0c: ldur            w2, [x4, #0xdf]
    // 0x115ea10: DecompressPointer r2
    //     0x115ea10: add             x2, x2, HEAP, lsl #32
    // 0x115ea14: r17 = -656
    //     0x115ea14: mov             x17, #-0x290
    // 0x115ea18: ldr             d0, [fp, x17]
    // 0x115ea1c: r0 = lerp()
    //     0x115ea1c: bl              #0x116722c  ; [package:flutter/src/material/filled_button_theme.dart] FilledButtonThemeData::lerp
    // 0x115ea20: mov             x3, x0
    // 0x115ea24: ldur            x0, [fp, #-0x18]
    // 0x115ea28: r17 = -432
    //     0x115ea28: mov             x17, #-0x1b0
    // 0x115ea2c: str             x3, [fp, x17]
    // 0x115ea30: LoadField: r1 = r0->field_e3
    //     0x115ea30: ldur            w1, [x0, #0xe3]
    // 0x115ea34: DecompressPointer r1
    //     0x115ea34: add             x1, x1, HEAP, lsl #32
    // 0x115ea38: ldur            x4, [fp, #-0x20]
    // 0x115ea3c: LoadField: r2 = r4->field_e3
    //     0x115ea3c: ldur            w2, [x4, #0xe3]
    // 0x115ea40: DecompressPointer r2
    //     0x115ea40: add             x2, x2, HEAP, lsl #32
    // 0x115ea44: r17 = -656
    //     0x115ea44: mov             x17, #-0x290
    // 0x115ea48: ldr             d0, [fp, x17]
    // 0x115ea4c: r0 = lerp()
    //     0x115ea4c: bl              #0x1166e58  ; [package:flutter/src/material/floating_action_button_theme.dart] FloatingActionButtonThemeData::lerp
    // 0x115ea50: mov             x3, x0
    // 0x115ea54: ldur            x0, [fp, #-0x18]
    // 0x115ea58: r17 = -440
    //     0x115ea58: mov             x17, #-0x1b8
    // 0x115ea5c: str             x3, [fp, x17]
    // 0x115ea60: LoadField: r1 = r0->field_e7
    //     0x115ea60: ldur            w1, [x0, #0xe7]
    // 0x115ea64: DecompressPointer r1
    //     0x115ea64: add             x1, x1, HEAP, lsl #32
    // 0x115ea68: ldur            x4, [fp, #-0x20]
    // 0x115ea6c: LoadField: r2 = r4->field_e7
    //     0x115ea6c: ldur            w2, [x4, #0xe7]
    // 0x115ea70: DecompressPointer r2
    //     0x115ea70: add             x2, x2, HEAP, lsl #32
    // 0x115ea74: r17 = -656
    //     0x115ea74: mov             x17, #-0x290
    // 0x115ea78: ldr             d0, [fp, x17]
    // 0x115ea7c: r0 = lerp()
    //     0x115ea7c: bl              #0x1166dec  ; [package:flutter/src/material/icon_button_theme.dart] IconButtonThemeData::lerp
    // 0x115ea80: mov             x3, x0
    // 0x115ea84: ldur            x0, [fp, #-0x18]
    // 0x115ea88: r17 = -448
    //     0x115ea88: mov             x17, #-0x1c0
    // 0x115ea8c: str             x3, [fp, x17]
    // 0x115ea90: LoadField: r1 = r0->field_eb
    //     0x115ea90: ldur            w1, [x0, #0xeb]
    // 0x115ea94: DecompressPointer r1
    //     0x115ea94: add             x1, x1, HEAP, lsl #32
    // 0x115ea98: ldur            x4, [fp, #-0x20]
    // 0x115ea9c: LoadField: r2 = r4->field_eb
    //     0x115ea9c: ldur            w2, [x4, #0xeb]
    // 0x115eaa0: DecompressPointer r2
    //     0x115eaa0: add             x2, x2, HEAP, lsl #32
    // 0x115eaa4: r17 = -656
    //     0x115eaa4: mov             x17, #-0x290
    // 0x115eaa8: ldr             d0, [fp, x17]
    // 0x115eaac: r0 = lerp()
    //     0x115eaac: bl              #0x1166b08  ; [package:flutter/src/material/list_tile_theme.dart] ListTileThemeData::lerp
    // 0x115eab0: mov             x3, x0
    // 0x115eab4: ldur            x0, [fp, #-0x18]
    // 0x115eab8: r17 = -456
    //     0x115eab8: mov             x17, #-0x1c8
    // 0x115eabc: str             x3, [fp, x17]
    // 0x115eac0: LoadField: r1 = r0->field_ef
    //     0x115eac0: ldur            w1, [x0, #0xef]
    // 0x115eac4: DecompressPointer r1
    //     0x115eac4: add             x1, x1, HEAP, lsl #32
    // 0x115eac8: ldur            x4, [fp, #-0x20]
    // 0x115eacc: LoadField: r2 = r4->field_ef
    //     0x115eacc: ldur            w2, [x4, #0xef]
    // 0x115ead0: DecompressPointer r2
    //     0x115ead0: add             x2, x2, HEAP, lsl #32
    // 0x115ead4: r17 = -656
    //     0x115ead4: mov             x17, #-0x290
    // 0x115ead8: ldr             d0, [fp, x17]
    // 0x115eadc: r0 = lerp()
    //     0x115eadc: bl              #0x1166a90  ; [package:flutter/src/material/menu_bar_theme.dart] MenuBarThemeData::lerp
    // 0x115eae0: mov             x3, x0
    // 0x115eae4: ldur            x0, [fp, #-0x18]
    // 0x115eae8: r17 = -464
    //     0x115eae8: mov             x17, #-0x1d0
    // 0x115eaec: str             x3, [fp, x17]
    // 0x115eaf0: LoadField: r1 = r0->field_f3
    //     0x115eaf0: ldur            w1, [x0, #0xf3]
    // 0x115eaf4: DecompressPointer r1
    //     0x115eaf4: add             x1, x1, HEAP, lsl #32
    // 0x115eaf8: ldur            x4, [fp, #-0x20]
    // 0x115eafc: LoadField: r2 = r4->field_f3
    //     0x115eafc: ldur            w2, [x4, #0xf3]
    // 0x115eb00: DecompressPointer r2
    //     0x115eb00: add             x2, x2, HEAP, lsl #32
    // 0x115eb04: r17 = -656
    //     0x115eb04: mov             x17, #-0x290
    // 0x115eb08: ldr             d0, [fp, x17]
    // 0x115eb0c: r0 = lerp()
    //     0x115eb0c: bl              #0x1166a18  ; [package:flutter/src/material/menu_button_theme.dart] MenuButtonThemeData::lerp
    // 0x115eb10: mov             x3, x0
    // 0x115eb14: ldur            x0, [fp, #-0x18]
    // 0x115eb18: r17 = -472
    //     0x115eb18: mov             x17, #-0x1d8
    // 0x115eb1c: str             x3, [fp, x17]
    // 0x115eb20: LoadField: r1 = r0->field_f7
    //     0x115eb20: ldur            w1, [x0, #0xf7]
    // 0x115eb24: DecompressPointer r1
    //     0x115eb24: add             x1, x1, HEAP, lsl #32
    // 0x115eb28: ldur            x4, [fp, #-0x20]
    // 0x115eb2c: LoadField: r2 = r4->field_f7
    //     0x115eb2c: ldur            w2, [x4, #0xf7]
    // 0x115eb30: DecompressPointer r2
    //     0x115eb30: add             x2, x2, HEAP, lsl #32
    // 0x115eb34: r17 = -656
    //     0x115eb34: mov             x17, #-0x290
    // 0x115eb38: ldr             d0, [fp, x17]
    // 0x115eb3c: r0 = lerp()
    //     0x115eb3c: bl              #0x1166944  ; [package:flutter/src/material/menu_theme.dart] MenuThemeData::lerp
    // 0x115eb40: mov             x3, x0
    // 0x115eb44: ldur            x0, [fp, #-0x18]
    // 0x115eb48: r17 = -480
    //     0x115eb48: mov             x17, #-0x1e0
    // 0x115eb4c: str             x3, [fp, x17]
    // 0x115eb50: LoadField: r1 = r0->field_fb
    //     0x115eb50: ldur            w1, [x0, #0xfb]
    // 0x115eb54: DecompressPointer r1
    //     0x115eb54: add             x1, x1, HEAP, lsl #32
    // 0x115eb58: ldur            x4, [fp, #-0x20]
    // 0x115eb5c: LoadField: r2 = r4->field_fb
    //     0x115eb5c: ldur            w2, [x4, #0xfb]
    // 0x115eb60: DecompressPointer r2
    //     0x115eb60: add             x2, x2, HEAP, lsl #32
    // 0x115eb64: r17 = -656
    //     0x115eb64: mov             x17, #-0x290
    // 0x115eb68: ldr             d0, [fp, x17]
    // 0x115eb6c: r0 = lerp()
    //     0x115eb6c: bl              #0x11667d8  ; [package:flutter/src/material/navigation_bar_theme.dart] NavigationBarThemeData::lerp
    // 0x115eb70: mov             x3, x0
    // 0x115eb74: ldur            x0, [fp, #-0x18]
    // 0x115eb78: r17 = -488
    //     0x115eb78: mov             x17, #-0x1e8
    // 0x115eb7c: str             x3, [fp, x17]
    // 0x115eb80: LoadField: r1 = r0->field_ff
    //     0x115eb80: ldur            w1, [x0, #0xff]
    // 0x115eb84: DecompressPointer r1
    //     0x115eb84: add             x1, x1, HEAP, lsl #32
    // 0x115eb88: ldur            x4, [fp, #-0x20]
    // 0x115eb8c: LoadField: r2 = r4->field_ff
    //     0x115eb8c: ldur            w2, [x4, #0xff]
    // 0x115eb90: DecompressPointer r2
    //     0x115eb90: add             x2, x2, HEAP, lsl #32
    // 0x115eb94: r17 = -656
    //     0x115eb94: mov             x17, #-0x290
    // 0x115eb98: ldr             d0, [fp, x17]
    // 0x115eb9c: r0 = lerp()
    //     0x115eb9c: bl              #0x116667c  ; [package:flutter/src/material/navigation_drawer_theme.dart] NavigationDrawerThemeData::lerp
    // 0x115eba0: mov             x3, x0
    // 0x115eba4: ldur            x0, [fp, #-0x18]
    // 0x115eba8: r17 = -496
    //     0x115eba8: mov             x17, #-0x1f0
    // 0x115ebac: str             x3, [fp, x17]
    // 0x115ebb0: r17 = 259
    //     0x115ebb0: mov             x17, #0x103
    // 0x115ebb4: ldr             w1, [x0, x17]
    // 0x115ebb8: DecompressPointer r1
    //     0x115ebb8: add             x1, x1, HEAP, lsl #32
    // 0x115ebbc: ldur            x4, [fp, #-0x20]
    // 0x115ebc0: r17 = 259
    //     0x115ebc0: mov             x17, #0x103
    // 0x115ebc4: ldr             w2, [x4, x17]
    // 0x115ebc8: DecompressPointer r2
    //     0x115ebc8: add             x2, x2, HEAP, lsl #32
    // 0x115ebcc: r17 = -656
    //     0x115ebcc: mov             x17, #-0x290
    // 0x115ebd0: ldr             d0, [fp, x17]
    // 0x115ebd4: r0 = lerp()
    //     0x115ebd4: bl              #0x11664c4  ; [package:flutter/src/material/navigation_rail_theme.dart] NavigationRailThemeData::lerp
    // 0x115ebd8: mov             x3, x0
    // 0x115ebdc: ldur            x0, [fp, #-0x18]
    // 0x115ebe0: r17 = -504
    //     0x115ebe0: mov             x17, #-0x1f8
    // 0x115ebe4: str             x3, [fp, x17]
    // 0x115ebe8: r17 = 263
    //     0x115ebe8: mov             x17, #0x107
    // 0x115ebec: ldr             w1, [x0, x17]
    // 0x115ebf0: DecompressPointer r1
    //     0x115ebf0: add             x1, x1, HEAP, lsl #32
    // 0x115ebf4: ldur            x4, [fp, #-0x20]
    // 0x115ebf8: r17 = 263
    //     0x115ebf8: mov             x17, #0x107
    // 0x115ebfc: ldr             w2, [x4, x17]
    // 0x115ec00: DecompressPointer r2
    //     0x115ec00: add             x2, x2, HEAP, lsl #32
    // 0x115ec04: r17 = -656
    //     0x115ec04: mov             x17, #-0x290
    // 0x115ec08: ldr             d0, [fp, x17]
    // 0x115ec0c: r0 = lerp()
    //     0x115ec0c: bl              #0x116644c  ; [package:flutter/src/material/outlined_button_theme.dart] OutlinedButtonThemeData::lerp
    // 0x115ec10: mov             x3, x0
    // 0x115ec14: ldur            x0, [fp, #-0x18]
    // 0x115ec18: r17 = -512
    //     0x115ec18: mov             x17, #-0x200
    // 0x115ec1c: str             x3, [fp, x17]
    // 0x115ec20: r17 = 267
    //     0x115ec20: mov             x17, #0x10b
    // 0x115ec24: ldr             w1, [x0, x17]
    // 0x115ec28: DecompressPointer r1
    //     0x115ec28: add             x1, x1, HEAP, lsl #32
    // 0x115ec2c: ldur            x4, [fp, #-0x20]
    // 0x115ec30: r17 = 267
    //     0x115ec30: mov             x17, #0x10b
    // 0x115ec34: ldr             w2, [x4, x17]
    // 0x115ec38: DecompressPointer r2
    //     0x115ec38: add             x2, x2, HEAP, lsl #32
    // 0x115ec3c: r17 = -656
    //     0x115ec3c: mov             x17, #-0x290
    // 0x115ec40: ldr             d0, [fp, x17]
    // 0x115ec44: r0 = lerp()
    //     0x115ec44: bl              #0x11662d0  ; [package:flutter/src/material/popup_menu_theme.dart] PopupMenuThemeData::lerp
    // 0x115ec48: mov             x3, x0
    // 0x115ec4c: ldur            x0, [fp, #-0x18]
    // 0x115ec50: r17 = -520
    //     0x115ec50: mov             x17, #-0x208
    // 0x115ec54: str             x3, [fp, x17]
    // 0x115ec58: r17 = 271
    //     0x115ec58: mov             x17, #0x10f
    // 0x115ec5c: ldr             w1, [x0, x17]
    // 0x115ec60: DecompressPointer r1
    //     0x115ec60: add             x1, x1, HEAP, lsl #32
    // 0x115ec64: ldur            x4, [fp, #-0x20]
    // 0x115ec68: r17 = 271
    //     0x115ec68: mov             x17, #0x10f
    // 0x115ec6c: ldr             w2, [x4, x17]
    // 0x115ec70: DecompressPointer r2
    //     0x115ec70: add             x2, x2, HEAP, lsl #32
    // 0x115ec74: r17 = -656
    //     0x115ec74: mov             x17, #-0x290
    // 0x115ec78: ldr             d0, [fp, x17]
    // 0x115ec7c: r0 = lerp()
    //     0x115ec7c: bl              #0x116609c  ; [package:flutter/src/material/progress_indicator_theme.dart] ProgressIndicatorThemeData::lerp
    // 0x115ec80: mov             x3, x0
    // 0x115ec84: ldur            x0, [fp, #-0x18]
    // 0x115ec88: r17 = -528
    //     0x115ec88: mov             x17, #-0x210
    // 0x115ec8c: str             x3, [fp, x17]
    // 0x115ec90: r17 = 275
    //     0x115ec90: mov             x17, #0x113
    // 0x115ec94: ldr             w1, [x0, x17]
    // 0x115ec98: DecompressPointer r1
    //     0x115ec98: add             x1, x1, HEAP, lsl #32
    // 0x115ec9c: ldur            x4, [fp, #-0x20]
    // 0x115eca0: r17 = 275
    //     0x115eca0: mov             x17, #0x113
    // 0x115eca4: ldr             w2, [x4, x17]
    // 0x115eca8: DecompressPointer r2
    //     0x115eca8: add             x2, x2, HEAP, lsl #32
    // 0x115ecac: r17 = -656
    //     0x115ecac: mov             x17, #-0x290
    // 0x115ecb0: ldr             d0, [fp, x17]
    // 0x115ecb4: r0 = lerp()
    //     0x115ecb4: bl              #0x1165fdc  ; [package:flutter/src/material/radio_theme.dart] RadioThemeData::lerp
    // 0x115ecb8: mov             x3, x0
    // 0x115ecbc: ldur            x0, [fp, #-0x18]
    // 0x115ecc0: r17 = -536
    //     0x115ecc0: mov             x17, #-0x218
    // 0x115ecc4: str             x3, [fp, x17]
    // 0x115ecc8: r17 = 279
    //     0x115ecc8: mov             x17, #0x117
    // 0x115eccc: ldr             w1, [x0, x17]
    // 0x115ecd0: DecompressPointer r1
    //     0x115ecd0: add             x1, x1, HEAP, lsl #32
    // 0x115ecd4: ldur            x4, [fp, #-0x20]
    // 0x115ecd8: r17 = 279
    //     0x115ecd8: mov             x17, #0x117
    // 0x115ecdc: ldr             w2, [x4, x17]
    // 0x115ece0: DecompressPointer r2
    //     0x115ece0: add             x2, x2, HEAP, lsl #32
    // 0x115ece4: r17 = -656
    //     0x115ece4: mov             x17, #-0x290
    // 0x115ece8: ldr             d0, [fp, x17]
    // 0x115ecec: r0 = lerp()
    //     0x115ecec: bl              #0x1165f80  ; [package:flutter/src/material/search_bar_theme.dart] SearchBarThemeData::lerp
    // 0x115ecf0: mov             x3, x0
    // 0x115ecf4: ldur            x0, [fp, #-0x18]
    // 0x115ecf8: r17 = -544
    //     0x115ecf8: mov             x17, #-0x220
    // 0x115ecfc: str             x3, [fp, x17]
    // 0x115ed00: r17 = 283
    //     0x115ed00: mov             x17, #0x11b
    // 0x115ed04: ldr             w1, [x0, x17]
    // 0x115ed08: DecompressPointer r1
    //     0x115ed08: add             x1, x1, HEAP, lsl #32
    // 0x115ed0c: ldur            x4, [fp, #-0x20]
    // 0x115ed10: r17 = 283
    //     0x115ed10: mov             x17, #0x11b
    // 0x115ed14: ldr             w2, [x4, x17]
    // 0x115ed18: DecompressPointer r2
    //     0x115ed18: add             x2, x2, HEAP, lsl #32
    // 0x115ed1c: r17 = -656
    //     0x115ed1c: mov             x17, #-0x290
    // 0x115ed20: ldr             d0, [fp, x17]
    // 0x115ed24: r0 = lerp()
    //     0x115ed24: bl              #0x1165de4  ; [package:flutter/src/material/search_view_theme.dart] SearchViewThemeData::lerp
    // 0x115ed28: mov             x3, x0
    // 0x115ed2c: ldur            x0, [fp, #-0x18]
    // 0x115ed30: r17 = -552
    //     0x115ed30: mov             x17, #-0x228
    // 0x115ed34: str             x3, [fp, x17]
    // 0x115ed38: r17 = 287
    //     0x115ed38: mov             x17, #0x11f
    // 0x115ed3c: ldr             w1, [x0, x17]
    // 0x115ed40: DecompressPointer r1
    //     0x115ed40: add             x1, x1, HEAP, lsl #32
    // 0x115ed44: ldur            x4, [fp, #-0x20]
    // 0x115ed48: r17 = 287
    //     0x115ed48: mov             x17, #0x11f
    // 0x115ed4c: ldr             w2, [x4, x17]
    // 0x115ed50: DecompressPointer r2
    //     0x115ed50: add             x2, x2, HEAP, lsl #32
    // 0x115ed54: r17 = -656
    //     0x115ed54: mov             x17, #-0x290
    // 0x115ed58: ldr             d0, [fp, x17]
    // 0x115ed5c: r0 = lerp()
    //     0x115ed5c: bl              #0x1165d6c  ; [package:flutter/src/material/segmented_button_theme.dart] SegmentedButtonThemeData::lerp
    // 0x115ed60: mov             x3, x0
    // 0x115ed64: ldur            x0, [fp, #-0x18]
    // 0x115ed68: r17 = -560
    //     0x115ed68: mov             x17, #-0x230
    // 0x115ed6c: str             x3, [fp, x17]
    // 0x115ed70: r17 = 291
    //     0x115ed70: mov             x17, #0x123
    // 0x115ed74: ldr             w1, [x0, x17]
    // 0x115ed78: DecompressPointer r1
    //     0x115ed78: add             x1, x1, HEAP, lsl #32
    // 0x115ed7c: ldur            x4, [fp, #-0x20]
    // 0x115ed80: r17 = 291
    //     0x115ed80: mov             x17, #0x123
    // 0x115ed84: ldr             w2, [x4, x17]
    // 0x115ed88: DecompressPointer r2
    //     0x115ed88: add             x2, x2, HEAP, lsl #32
    // 0x115ed8c: r17 = -656
    //     0x115ed8c: mov             x17, #-0x290
    // 0x115ed90: ldr             d0, [fp, x17]
    // 0x115ed94: r0 = lerp()
    //     0x115ed94: bl              #0x11657d4  ; [package:flutter/src/material/slider_theme.dart] SliderThemeData::lerp
    // 0x115ed98: mov             x3, x0
    // 0x115ed9c: ldur            x0, [fp, #-0x18]
    // 0x115eda0: r17 = -568
    //     0x115eda0: mov             x17, #-0x238
    // 0x115eda4: str             x3, [fp, x17]
    // 0x115eda8: r17 = 295
    //     0x115eda8: mov             x17, #0x127
    // 0x115edac: ldr             w1, [x0, x17]
    // 0x115edb0: DecompressPointer r1
    //     0x115edb0: add             x1, x1, HEAP, lsl #32
    // 0x115edb4: ldur            x4, [fp, #-0x20]
    // 0x115edb8: r17 = 295
    //     0x115edb8: mov             x17, #0x127
    // 0x115edbc: ldr             w2, [x4, x17]
    // 0x115edc0: DecompressPointer r2
    //     0x115edc0: add             x2, x2, HEAP, lsl #32
    // 0x115edc4: r17 = -656
    //     0x115edc4: mov             x17, #-0x290
    // 0x115edc8: ldr             d0, [fp, x17]
    // 0x115edcc: r0 = lerp()
    //     0x115edcc: bl              #0x116560c  ; [package:flutter/src/material/snack_bar_theme.dart] SnackBarThemeData::lerp
    // 0x115edd0: mov             x3, x0
    // 0x115edd4: ldur            x0, [fp, #-0x18]
    // 0x115edd8: r17 = -576
    //     0x115edd8: mov             x17, #-0x240
    // 0x115eddc: str             x3, [fp, x17]
    // 0x115ede0: r17 = 299
    //     0x115ede0: mov             x17, #0x12b
    // 0x115ede4: ldr             w1, [x0, x17]
    // 0x115ede8: DecompressPointer r1
    //     0x115ede8: add             x1, x1, HEAP, lsl #32
    // 0x115edec: ldur            x4, [fp, #-0x20]
    // 0x115edf0: r17 = 299
    //     0x115edf0: mov             x17, #0x12b
    // 0x115edf4: ldr             w2, [x4, x17]
    // 0x115edf8: DecompressPointer r2
    //     0x115edf8: add             x2, x2, HEAP, lsl #32
    // 0x115edfc: r17 = -656
    //     0x115edfc: mov             x17, #-0x290
    // 0x115ee00: ldr             d0, [fp, x17]
    // 0x115ee04: r0 = lerp()
    //     0x115ee04: bl              #0x1165534  ; [package:flutter/src/material/switch_theme.dart] SwitchThemeData::lerp
    // 0x115ee08: mov             x3, x0
    // 0x115ee0c: ldur            x0, [fp, #-0x18]
    // 0x115ee10: r17 = -584
    //     0x115ee10: mov             x17, #-0x248
    // 0x115ee14: str             x3, [fp, x17]
    // 0x115ee18: r17 = 303
    //     0x115ee18: mov             x17, #0x12f
    // 0x115ee1c: ldr             w1, [x0, x17]
    // 0x115ee20: DecompressPointer r1
    //     0x115ee20: add             x1, x1, HEAP, lsl #32
    // 0x115ee24: ldur            x4, [fp, #-0x20]
    // 0x115ee28: r17 = 303
    //     0x115ee28: mov             x17, #0x12f
    // 0x115ee2c: ldr             w2, [x4, x17]
    // 0x115ee30: DecompressPointer r2
    //     0x115ee30: add             x2, x2, HEAP, lsl #32
    // 0x115ee34: r17 = -656
    //     0x115ee34: mov             x17, #-0x290
    // 0x115ee38: ldr             d0, [fp, x17]
    // 0x115ee3c: r0 = lerp()
    //     0x115ee3c: bl              #0x116539c  ; [package:flutter/src/material/tab_bar_theme.dart] TabBarThemeData::lerp
    // 0x115ee40: mov             x3, x0
    // 0x115ee44: ldur            x0, [fp, #-0x18]
    // 0x115ee48: r17 = -592
    //     0x115ee48: mov             x17, #-0x250
    // 0x115ee4c: str             x3, [fp, x17]
    // 0x115ee50: r17 = 307
    //     0x115ee50: mov             x17, #0x133
    // 0x115ee54: ldr             w1, [x0, x17]
    // 0x115ee58: DecompressPointer r1
    //     0x115ee58: add             x1, x1, HEAP, lsl #32
    // 0x115ee5c: ldur            x4, [fp, #-0x20]
    // 0x115ee60: r17 = 307
    //     0x115ee60: mov             x17, #0x133
    // 0x115ee64: ldr             w2, [x4, x17]
    // 0x115ee68: DecompressPointer r2
    //     0x115ee68: add             x2, x2, HEAP, lsl #32
    // 0x115ee6c: r17 = -656
    //     0x115ee6c: mov             x17, #-0x290
    // 0x115ee70: ldr             d0, [fp, x17]
    // 0x115ee74: r0 = lerp()
    //     0x115ee74: bl              #0x1165324  ; [package:flutter/src/material/text_button_theme.dart] TextButtonThemeData::lerp
    // 0x115ee78: mov             x3, x0
    // 0x115ee7c: ldur            x0, [fp, #-0x18]
    // 0x115ee80: r17 = -600
    //     0x115ee80: mov             x17, #-0x258
    // 0x115ee84: str             x3, [fp, x17]
    // 0x115ee88: r17 = 311
    //     0x115ee88: mov             x17, #0x137
    // 0x115ee8c: ldr             w1, [x0, x17]
    // 0x115ee90: DecompressPointer r1
    //     0x115ee90: add             x1, x1, HEAP, lsl #32
    // 0x115ee94: ldur            x4, [fp, #-0x20]
    // 0x115ee98: r17 = 311
    //     0x115ee98: mov             x17, #0x137
    // 0x115ee9c: ldr             w2, [x4, x17]
    // 0x115eea0: DecompressPointer r2
    //     0x115eea0: add             x2, x2, HEAP, lsl #32
    // 0x115eea4: r17 = -656
    //     0x115eea4: mov             x17, #-0x290
    // 0x115eea8: ldr             d0, [fp, x17]
    // 0x115eeac: r0 = lerp()
    //     0x115eeac: bl              #0x1165260  ; [package:flutter/src/material/text_selection_theme.dart] TextSelectionThemeData::lerp
    // 0x115eeb0: mov             x3, x0
    // 0x115eeb4: ldur            x0, [fp, #-0x18]
    // 0x115eeb8: r17 = -608
    //     0x115eeb8: mov             x17, #-0x260
    // 0x115eebc: str             x3, [fp, x17]
    // 0x115eec0: r17 = 315
    //     0x115eec0: mov             x17, #0x13b
    // 0x115eec4: ldr             w1, [x0, x17]
    // 0x115eec8: DecompressPointer r1
    //     0x115eec8: add             x1, x1, HEAP, lsl #32
    // 0x115eecc: ldur            x4, [fp, #-0x20]
    // 0x115eed0: r17 = 315
    //     0x115eed0: mov             x17, #0x13b
    // 0x115eed4: ldr             w2, [x4, x17]
    // 0x115eed8: DecompressPointer r2
    //     0x115eed8: add             x2, x2, HEAP, lsl #32
    // 0x115eedc: r17 = -656
    //     0x115eedc: mov             x17, #-0x290
    // 0x115eee0: ldr             d0, [fp, x17]
    // 0x115eee4: r0 = lerp()
    //     0x115eee4: bl              #0x11643f8  ; [package:flutter/src/material/time_picker_theme.dart] TimePickerThemeData::lerp
    // 0x115eee8: mov             x3, x0
    // 0x115eeec: ldur            x0, [fp, #-0x18]
    // 0x115eef0: r17 = -616
    //     0x115eef0: mov             x17, #-0x268
    // 0x115eef4: str             x3, [fp, x17]
    // 0x115eef8: r17 = 319
    //     0x115eef8: mov             x17, #0x13f
    // 0x115eefc: ldr             w1, [x0, x17]
    // 0x115ef00: DecompressPointer r1
    //     0x115ef00: add             x1, x1, HEAP, lsl #32
    // 0x115ef04: ldur            x4, [fp, #-0x20]
    // 0x115ef08: r17 = 319
    //     0x115ef08: mov             x17, #0x13f
    // 0x115ef0c: ldr             w2, [x4, x17]
    // 0x115ef10: DecompressPointer r2
    //     0x115ef10: add             x2, x2, HEAP, lsl #32
    // 0x115ef14: r17 = -656
    //     0x115ef14: mov             x17, #-0x290
    // 0x115ef18: ldr             d0, [fp, x17]
    // 0x115ef1c: r0 = lerp()
    //     0x115ef1c: bl              #0x1164238  ; [package:flutter/src/material/toggle_buttons_theme.dart] ToggleButtonsThemeData::lerp
    // 0x115ef20: mov             x3, x0
    // 0x115ef24: ldur            x0, [fp, #-0x18]
    // 0x115ef28: r17 = -624
    //     0x115ef28: mov             x17, #-0x270
    // 0x115ef2c: str             x3, [fp, x17]
    // 0x115ef30: r17 = 323
    //     0x115ef30: mov             x17, #0x143
    // 0x115ef34: ldr             w1, [x0, x17]
    // 0x115ef38: DecompressPointer r1
    //     0x115ef38: add             x1, x1, HEAP, lsl #32
    // 0x115ef3c: ldur            x4, [fp, #-0x20]
    // 0x115ef40: r17 = 323
    //     0x115ef40: mov             x17, #0x143
    // 0x115ef44: ldr             w2, [x4, x17]
    // 0x115ef48: DecompressPointer r2
    //     0x115ef48: add             x2, x2, HEAP, lsl #32
    // 0x115ef4c: r17 = -656
    //     0x115ef4c: mov             x17, #-0x290
    // 0x115ef50: ldr             d0, [fp, x17]
    // 0x115ef54: r0 = lerp()
    //     0x115ef54: bl              #0x115f500  ; [package:flutter/src/material/tooltip_theme.dart] TooltipThemeData::lerp
    // 0x115ef58: mov             x3, x0
    // 0x115ef5c: ldur            x0, [fp, #-0x18]
    // 0x115ef60: r17 = -632
    //     0x115ef60: mov             x17, #-0x278
    // 0x115ef64: str             x3, [fp, x17]
    // 0x115ef68: r17 = 327
    //     0x115ef68: mov             x17, #0x147
    // 0x115ef6c: ldr             w1, [x0, x17]
    // 0x115ef70: DecompressPointer r1
    //     0x115ef70: add             x1, x1, HEAP, lsl #32
    // 0x115ef74: ldur            x4, [fp, #-0x20]
    // 0x115ef78: r17 = 327
    //     0x115ef78: mov             x17, #0x147
    // 0x115ef7c: ldr             w2, [x4, x17]
    // 0x115ef80: DecompressPointer r2
    //     0x115ef80: add             x2, x2, HEAP, lsl #32
    // 0x115ef84: r17 = -656
    //     0x115ef84: mov             x17, #-0x290
    // 0x115ef88: ldr             d0, [fp, x17]
    // 0x115ef8c: r0 = lerp()
    //     0x115ef8c: bl              #0x115f3e4  ; [package:flutter/src/material/button_bar_theme.dart] ButtonBarThemeData::lerp
    // 0x115ef90: mov             x4, x0
    // 0x115ef94: ldur            x0, [fp, #-0x18]
    // 0x115ef98: r17 = -640
    //     0x115ef98: mov             x17, #-0x280
    // 0x115ef9c: str             x4, [fp, x17]
    // 0x115efa0: r17 = 331
    //     0x115efa0: mov             x17, #0x14b
    // 0x115efa4: ldr             w1, [x0, x17]
    // 0x115efa8: DecompressPointer r1
    //     0x115efa8: add             x1, x1, HEAP, lsl #32
    // 0x115efac: ldur            x5, [fp, #-0x20]
    // 0x115efb0: r17 = 331
    //     0x115efb0: mov             x17, #0x14b
    // 0x115efb4: ldr             w2, [x5, x17]
    // 0x115efb8: DecompressPointer r2
    //     0x115efb8: add             x2, x2, HEAP, lsl #32
    // 0x115efbc: ldur            x3, [fp, #-0x58]
    // 0x115efc0: r0 = lerp()
    //     0x115efc0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x115efc4: mov             x4, x0
    // 0x115efc8: ldur            x0, [fp, #-0x18]
    // 0x115efcc: r17 = -648
    //     0x115efcc: mov             x17, #-0x288
    // 0x115efd0: str             x4, [fp, x17]
    // 0x115efd4: r17 = 335
    //     0x115efd4: mov             x17, #0x14f
    // 0x115efd8: ldr             w1, [x0, x17]
    // 0x115efdc: DecompressPointer r1
    //     0x115efdc: add             x1, x1, HEAP, lsl #32
    // 0x115efe0: ldur            x0, [fp, #-0x20]
    // 0x115efe4: r17 = 335
    //     0x115efe4: mov             x17, #0x14f
    // 0x115efe8: ldr             w2, [x0, x17]
    // 0x115efec: DecompressPointer r2
    //     0x115efec: add             x2, x2, HEAP, lsl #32
    // 0x115eff0: ldur            x3, [fp, #-0x58]
    // 0x115eff4: r0 = lerp()
    //     0x115eff4: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x115eff8: stur            x0, [fp, #-0x18]
    // 0x115effc: r0 = ThemeData()
    //     0x115effc: bl              #0x8a8890  ; AllocateThemeDataStub -> ThemeData (size=0x154)
    // 0x115f000: ldur            x1, [fp, #-0x10]
    // 0x115f004: StoreField: r0->field_13 = r1
    //     0x115f004: stur            w1, [x0, #0x13]
    // 0x115f008: ldur            x1, [fp, #-8]
    // 0x115f00c: StoreField: r0->field_7 = r1
    //     0x115f00c: stur            w1, [x0, #7]
    // 0x115f010: ldur            x1, [fp, #-0x38]
    // 0x115f014: StoreField: r0->field_f = r1
    //     0x115f014: stur            w1, [x0, #0xf]
    // 0x115f018: ldur            x1, [fp, #-0x30]
    // 0x115f01c: ArrayStore: r0[0] = r1  ; List_4
    //     0x115f01c: stur            w1, [x0, #0x17]
    // 0x115f020: ldur            x1, [fp, #-0x28]
    // 0x115f024: StoreField: r0->field_1b = r1
    //     0x115f024: stur            w1, [x0, #0x1b]
    // 0x115f028: r1 = Instance_PageTransitionsTheme
    //     0x115f028: add             x1, PP, #0x12, lsl #12  ; [pp+0x12938] Obj!PageTransitionsTheme@12b2a31
    //     0x115f02c: ldr             x1, [x1, #0x938]
    // 0x115f030: StoreField: r0->field_1f = r1
    //     0x115f030: stur            w1, [x0, #0x1f]
    // 0x115f034: r1 = Instance_TargetPlatform
    //     0x115f034: add             x1, PP, #0x12, lsl #12  ; [pp+0x12940] Obj!TargetPlatform@12c5e81
    //     0x115f038: ldr             x1, [x1, #0x940]
    // 0x115f03c: StoreField: r0->field_23 = r1
    //     0x115f03c: stur            w1, [x0, #0x23]
    // 0x115f040: ldur            x1, [fp, #-0x50]
    // 0x115f044: StoreField: r0->field_27 = r1
    //     0x115f044: stur            w1, [x0, #0x27]
    // 0x115f048: ldur            x1, [fp, #-0x48]
    // 0x115f04c: StoreField: r0->field_2b = r1
    //     0x115f04c: stur            w1, [x0, #0x2b]
    // 0x115f050: ldur            x1, [fp, #-0x40]
    // 0x115f054: StoreField: r0->field_2f = r1
    //     0x115f054: stur            w1, [x0, #0x2f]
    // 0x115f058: ldur            x1, [fp, #-0x60]
    // 0x115f05c: StoreField: r0->field_33 = r1
    //     0x115f05c: stur            w1, [x0, #0x33]
    // 0x115f060: ldur            x1, [fp, #-0x78]
    // 0x115f064: StoreField: r0->field_3f = r1
    //     0x115f064: stur            w1, [x0, #0x3f]
    // 0x115f068: ldur            x1, [fp, #-0x68]
    // 0x115f06c: StoreField: r0->field_37 = r1
    //     0x115f06c: stur            w1, [x0, #0x37]
    // 0x115f070: ldur            x1, [fp, #-0x70]
    // 0x115f074: StoreField: r0->field_3b = r1
    //     0x115f074: stur            w1, [x0, #0x3b]
    // 0x115f078: ldur            x1, [fp, #-0x80]
    // 0x115f07c: StoreField: r0->field_43 = r1
    //     0x115f07c: stur            w1, [x0, #0x43]
    // 0x115f080: ldur            x1, [fp, #-0x88]
    // 0x115f084: StoreField: r0->field_47 = r1
    //     0x115f084: stur            w1, [x0, #0x47]
    // 0x115f088: ldur            x1, [fp, #-0x90]
    // 0x115f08c: StoreField: r0->field_4b = r1
    //     0x115f08c: stur            w1, [x0, #0x4b]
    // 0x115f090: ldur            x1, [fp, #-0x98]
    // 0x115f094: StoreField: r0->field_4f = r1
    //     0x115f094: stur            w1, [x0, #0x4f]
    // 0x115f098: ldur            x1, [fp, #-0xa0]
    // 0x115f09c: StoreField: r0->field_53 = r1
    //     0x115f09c: stur            w1, [x0, #0x53]
    // 0x115f0a0: ldur            x1, [fp, #-0xa8]
    // 0x115f0a4: StoreField: r0->field_57 = r1
    //     0x115f0a4: stur            w1, [x0, #0x57]
    // 0x115f0a8: ldur            x1, [fp, #-0xb0]
    // 0x115f0ac: StoreField: r0->field_5b = r1
    //     0x115f0ac: stur            w1, [x0, #0x5b]
    // 0x115f0b0: ldur            x1, [fp, #-0xb8]
    // 0x115f0b4: StoreField: r0->field_5f = r1
    //     0x115f0b4: stur            w1, [x0, #0x5f]
    // 0x115f0b8: ldur            x1, [fp, #-0xc0]
    // 0x115f0bc: StoreField: r0->field_63 = r1
    //     0x115f0bc: stur            w1, [x0, #0x63]
    // 0x115f0c0: ldur            x1, [fp, #-0xc8]
    // 0x115f0c4: StoreField: r0->field_67 = r1
    //     0x115f0c4: stur            w1, [x0, #0x67]
    // 0x115f0c8: ldur            x1, [fp, #-0xd0]
    // 0x115f0cc: StoreField: r0->field_6b = r1
    //     0x115f0cc: stur            w1, [x0, #0x6b]
    // 0x115f0d0: ldur            x1, [fp, #-0xd8]
    // 0x115f0d4: StoreField: r0->field_6f = r1
    //     0x115f0d4: stur            w1, [x0, #0x6f]
    // 0x115f0d8: ldur            x1, [fp, #-0xe0]
    // 0x115f0dc: StoreField: r0->field_73 = r1
    //     0x115f0dc: stur            w1, [x0, #0x73]
    // 0x115f0e0: ldur            x1, [fp, #-0xe8]
    // 0x115f0e4: StoreField: r0->field_77 = r1
    //     0x115f0e4: stur            w1, [x0, #0x77]
    // 0x115f0e8: ldur            x1, [fp, #-0xf0]
    // 0x115f0ec: StoreField: r0->field_7b = r1
    //     0x115f0ec: stur            w1, [x0, #0x7b]
    // 0x115f0f0: ldur            x1, [fp, #-0xf8]
    // 0x115f0f4: StoreField: r0->field_7f = r1
    //     0x115f0f4: stur            w1, [x0, #0x7f]
    // 0x115f0f8: ldur            x1, [fp, #-0x100]
    // 0x115f0fc: StoreField: r0->field_83 = r1
    //     0x115f0fc: stur            w1, [x0, #0x83]
    // 0x115f100: r17 = -264
    //     0x115f100: mov             x17, #-0x108
    // 0x115f104: ldr             x1, [fp, x17]
    // 0x115f108: StoreField: r0->field_87 = r1
    //     0x115f108: stur            w1, [x0, #0x87]
    // 0x115f10c: r17 = -272
    //     0x115f10c: mov             x17, #-0x110
    // 0x115f110: ldr             x1, [fp, x17]
    // 0x115f114: StoreField: r0->field_8b = r1
    //     0x115f114: stur            w1, [x0, #0x8b]
    // 0x115f118: r17 = -280
    //     0x115f118: mov             x17, #-0x118
    // 0x115f11c: ldr             x1, [fp, x17]
    // 0x115f120: StoreField: r0->field_93 = r1
    //     0x115f120: stur            w1, [x0, #0x93]
    // 0x115f124: r17 = -288
    //     0x115f124: mov             x17, #-0x120
    // 0x115f128: ldr             x1, [fp, x17]
    // 0x115f12c: StoreField: r0->field_97 = r1
    //     0x115f12c: stur            w1, [x0, #0x97]
    // 0x115f130: r17 = -296
    //     0x115f130: mov             x17, #-0x128
    // 0x115f134: ldr             x1, [fp, x17]
    // 0x115f138: StoreField: r0->field_9b = r1
    //     0x115f138: stur            w1, [x0, #0x9b]
    // 0x115f13c: r17 = -304
    //     0x115f13c: mov             x17, #-0x130
    // 0x115f140: ldr             x1, [fp, x17]
    // 0x115f144: StoreField: r0->field_9f = r1
    //     0x115f144: stur            w1, [x0, #0x9f]
    // 0x115f148: r17 = -312
    //     0x115f148: mov             x17, #-0x138
    // 0x115f14c: ldr             x1, [fp, x17]
    // 0x115f150: StoreField: r0->field_a3 = r1
    //     0x115f150: stur            w1, [x0, #0xa3]
    // 0x115f154: r17 = -328
    //     0x115f154: mov             x17, #-0x148
    // 0x115f158: ldr             x1, [fp, x17]
    // 0x115f15c: StoreField: r0->field_a7 = r1
    //     0x115f15c: stur            w1, [x0, #0xa7]
    // 0x115f160: r17 = -320
    //     0x115f160: mov             x17, #-0x140
    // 0x115f164: ldr             x1, [fp, x17]
    // 0x115f168: StoreField: r0->field_ab = r1
    //     0x115f168: stur            w1, [x0, #0xab]
    // 0x115f16c: r17 = -336
    //     0x115f16c: mov             x17, #-0x150
    // 0x115f170: ldr             x1, [fp, x17]
    // 0x115f174: StoreField: r0->field_af = r1
    //     0x115f174: stur            w1, [x0, #0xaf]
    // 0x115f178: r17 = -344
    //     0x115f178: mov             x17, #-0x158
    // 0x115f17c: ldr             x1, [fp, x17]
    // 0x115f180: StoreField: r0->field_b3 = r1
    //     0x115f180: stur            w1, [x0, #0xb3]
    // 0x115f184: r17 = -352
    //     0x115f184: mov             x17, #-0x160
    // 0x115f188: ldr             x1, [fp, x17]
    // 0x115f18c: StoreField: r0->field_b7 = r1
    //     0x115f18c: stur            w1, [x0, #0xb7]
    // 0x115f190: r17 = -360
    //     0x115f190: mov             x17, #-0x168
    // 0x115f194: ldr             x1, [fp, x17]
    // 0x115f198: StoreField: r0->field_bb = r1
    //     0x115f198: stur            w1, [x0, #0xbb]
    // 0x115f19c: r17 = -368
    //     0x115f19c: mov             x17, #-0x170
    // 0x115f1a0: ldr             x1, [fp, x17]
    // 0x115f1a4: StoreField: r0->field_bf = r1
    //     0x115f1a4: stur            w1, [x0, #0xbf]
    // 0x115f1a8: r17 = -376
    //     0x115f1a8: mov             x17, #-0x178
    // 0x115f1ac: ldr             x1, [fp, x17]
    // 0x115f1b0: StoreField: r0->field_c3 = r1
    //     0x115f1b0: stur            w1, [x0, #0xc3]
    // 0x115f1b4: r17 = -384
    //     0x115f1b4: mov             x17, #-0x180
    // 0x115f1b8: ldr             x1, [fp, x17]
    // 0x115f1bc: StoreField: r0->field_c7 = r1
    //     0x115f1bc: stur            w1, [x0, #0xc7]
    // 0x115f1c0: r17 = -392
    //     0x115f1c0: mov             x17, #-0x188
    // 0x115f1c4: ldr             x1, [fp, x17]
    // 0x115f1c8: StoreField: r0->field_cb = r1
    //     0x115f1c8: stur            w1, [x0, #0xcb]
    // 0x115f1cc: r17 = -400
    //     0x115f1cc: mov             x17, #-0x190
    // 0x115f1d0: ldr             x1, [fp, x17]
    // 0x115f1d4: StoreField: r0->field_cf = r1
    //     0x115f1d4: stur            w1, [x0, #0xcf]
    // 0x115f1d8: r17 = -408
    //     0x115f1d8: mov             x17, #-0x198
    // 0x115f1dc: ldr             x1, [fp, x17]
    // 0x115f1e0: StoreField: r0->field_d3 = r1
    //     0x115f1e0: stur            w1, [x0, #0xd3]
    // 0x115f1e4: r17 = -416
    //     0x115f1e4: mov             x17, #-0x1a0
    // 0x115f1e8: ldr             x1, [fp, x17]
    // 0x115f1ec: StoreField: r0->field_d7 = r1
    //     0x115f1ec: stur            w1, [x0, #0xd7]
    // 0x115f1f0: r17 = -424
    //     0x115f1f0: mov             x17, #-0x1a8
    // 0x115f1f4: ldr             x1, [fp, x17]
    // 0x115f1f8: StoreField: r0->field_db = r1
    //     0x115f1f8: stur            w1, [x0, #0xdb]
    // 0x115f1fc: r17 = -432
    //     0x115f1fc: mov             x17, #-0x1b0
    // 0x115f200: ldr             x1, [fp, x17]
    // 0x115f204: StoreField: r0->field_df = r1
    //     0x115f204: stur            w1, [x0, #0xdf]
    // 0x115f208: r17 = -440
    //     0x115f208: mov             x17, #-0x1b8
    // 0x115f20c: ldr             x1, [fp, x17]
    // 0x115f210: StoreField: r0->field_e3 = r1
    //     0x115f210: stur            w1, [x0, #0xe3]
    // 0x115f214: r17 = -448
    //     0x115f214: mov             x17, #-0x1c0
    // 0x115f218: ldr             x1, [fp, x17]
    // 0x115f21c: StoreField: r0->field_e7 = r1
    //     0x115f21c: stur            w1, [x0, #0xe7]
    // 0x115f220: r17 = -456
    //     0x115f220: mov             x17, #-0x1c8
    // 0x115f224: ldr             x1, [fp, x17]
    // 0x115f228: StoreField: r0->field_eb = r1
    //     0x115f228: stur            w1, [x0, #0xeb]
    // 0x115f22c: r17 = -464
    //     0x115f22c: mov             x17, #-0x1d0
    // 0x115f230: ldr             x1, [fp, x17]
    // 0x115f234: StoreField: r0->field_ef = r1
    //     0x115f234: stur            w1, [x0, #0xef]
    // 0x115f238: r17 = -472
    //     0x115f238: mov             x17, #-0x1d8
    // 0x115f23c: ldr             x1, [fp, x17]
    // 0x115f240: StoreField: r0->field_f3 = r1
    //     0x115f240: stur            w1, [x0, #0xf3]
    // 0x115f244: r17 = -480
    //     0x115f244: mov             x17, #-0x1e0
    // 0x115f248: ldr             x1, [fp, x17]
    // 0x115f24c: StoreField: r0->field_f7 = r1
    //     0x115f24c: stur            w1, [x0, #0xf7]
    // 0x115f250: r17 = -488
    //     0x115f250: mov             x17, #-0x1e8
    // 0x115f254: ldr             x1, [fp, x17]
    // 0x115f258: StoreField: r0->field_fb = r1
    //     0x115f258: stur            w1, [x0, #0xfb]
    // 0x115f25c: r17 = -496
    //     0x115f25c: mov             x17, #-0x1f0
    // 0x115f260: ldr             x1, [fp, x17]
    // 0x115f264: StoreField: r0->field_ff = r1
    //     0x115f264: stur            w1, [x0, #0xff]
    // 0x115f268: r17 = -504
    //     0x115f268: mov             x17, #-0x1f8
    // 0x115f26c: ldr             x1, [fp, x17]
    // 0x115f270: r17 = 259
    //     0x115f270: mov             x17, #0x103
    // 0x115f274: str             w1, [x0, x17]
    // 0x115f278: r17 = -512
    //     0x115f278: mov             x17, #-0x200
    // 0x115f27c: ldr             x1, [fp, x17]
    // 0x115f280: r17 = 263
    //     0x115f280: mov             x17, #0x107
    // 0x115f284: str             w1, [x0, x17]
    // 0x115f288: r17 = -520
    //     0x115f288: mov             x17, #-0x208
    // 0x115f28c: ldr             x1, [fp, x17]
    // 0x115f290: r17 = 267
    //     0x115f290: mov             x17, #0x10b
    // 0x115f294: str             w1, [x0, x17]
    // 0x115f298: r17 = -528
    //     0x115f298: mov             x17, #-0x210
    // 0x115f29c: ldr             x1, [fp, x17]
    // 0x115f2a0: r17 = 271
    //     0x115f2a0: mov             x17, #0x10f
    // 0x115f2a4: str             w1, [x0, x17]
    // 0x115f2a8: r17 = -536
    //     0x115f2a8: mov             x17, #-0x218
    // 0x115f2ac: ldr             x1, [fp, x17]
    // 0x115f2b0: r17 = 275
    //     0x115f2b0: mov             x17, #0x113
    // 0x115f2b4: str             w1, [x0, x17]
    // 0x115f2b8: r17 = -544
    //     0x115f2b8: mov             x17, #-0x220
    // 0x115f2bc: ldr             x1, [fp, x17]
    // 0x115f2c0: r17 = 279
    //     0x115f2c0: mov             x17, #0x117
    // 0x115f2c4: str             w1, [x0, x17]
    // 0x115f2c8: r17 = -552
    //     0x115f2c8: mov             x17, #-0x228
    // 0x115f2cc: ldr             x1, [fp, x17]
    // 0x115f2d0: r17 = 283
    //     0x115f2d0: mov             x17, #0x11b
    // 0x115f2d4: str             w1, [x0, x17]
    // 0x115f2d8: r17 = -560
    //     0x115f2d8: mov             x17, #-0x230
    // 0x115f2dc: ldr             x1, [fp, x17]
    // 0x115f2e0: r17 = 287
    //     0x115f2e0: mov             x17, #0x11f
    // 0x115f2e4: str             w1, [x0, x17]
    // 0x115f2e8: r17 = -568
    //     0x115f2e8: mov             x17, #-0x238
    // 0x115f2ec: ldr             x1, [fp, x17]
    // 0x115f2f0: r17 = 291
    //     0x115f2f0: mov             x17, #0x123
    // 0x115f2f4: str             w1, [x0, x17]
    // 0x115f2f8: r17 = -576
    //     0x115f2f8: mov             x17, #-0x240
    // 0x115f2fc: ldr             x1, [fp, x17]
    // 0x115f300: r17 = 295
    //     0x115f300: mov             x17, #0x127
    // 0x115f304: str             w1, [x0, x17]
    // 0x115f308: r17 = -584
    //     0x115f308: mov             x17, #-0x248
    // 0x115f30c: ldr             x1, [fp, x17]
    // 0x115f310: r17 = 299
    //     0x115f310: mov             x17, #0x12b
    // 0x115f314: str             w1, [x0, x17]
    // 0x115f318: r17 = -592
    //     0x115f318: mov             x17, #-0x250
    // 0x115f31c: ldr             x1, [fp, x17]
    // 0x115f320: r17 = 303
    //     0x115f320: mov             x17, #0x12f
    // 0x115f324: str             w1, [x0, x17]
    // 0x115f328: r17 = -600
    //     0x115f328: mov             x17, #-0x258
    // 0x115f32c: ldr             x1, [fp, x17]
    // 0x115f330: r17 = 307
    //     0x115f330: mov             x17, #0x133
    // 0x115f334: str             w1, [x0, x17]
    // 0x115f338: r17 = -608
    //     0x115f338: mov             x17, #-0x260
    // 0x115f33c: ldr             x1, [fp, x17]
    // 0x115f340: r17 = 311
    //     0x115f340: mov             x17, #0x137
    // 0x115f344: str             w1, [x0, x17]
    // 0x115f348: r17 = -616
    //     0x115f348: mov             x17, #-0x268
    // 0x115f34c: ldr             x1, [fp, x17]
    // 0x115f350: r17 = 315
    //     0x115f350: mov             x17, #0x13b
    // 0x115f354: str             w1, [x0, x17]
    // 0x115f358: r17 = -624
    //     0x115f358: mov             x17, #-0x270
    // 0x115f35c: ldr             x1, [fp, x17]
    // 0x115f360: r17 = 319
    //     0x115f360: mov             x17, #0x13f
    // 0x115f364: str             w1, [x0, x17]
    // 0x115f368: r17 = -632
    //     0x115f368: mov             x17, #-0x278
    // 0x115f36c: ldr             x1, [fp, x17]
    // 0x115f370: r17 = 323
    //     0x115f370: mov             x17, #0x143
    // 0x115f374: str             w1, [x0, x17]
    // 0x115f378: r17 = -648
    //     0x115f378: mov             x17, #-0x288
    // 0x115f37c: ldr             x1, [fp, x17]
    // 0x115f380: r17 = 331
    //     0x115f380: mov             x17, #0x14b
    // 0x115f384: str             w1, [x0, x17]
    // 0x115f388: ldur            x1, [fp, #-0x18]
    // 0x115f38c: r17 = 335
    //     0x115f38c: mov             x17, #0x14f
    // 0x115f390: str             w1, [x0, x17]
    // 0x115f394: r17 = -640
    //     0x115f394: mov             x17, #-0x280
    // 0x115f398: ldr             x1, [fp, x17]
    // 0x115f39c: r17 = 327
    //     0x115f39c: mov             x17, #0x147
    // 0x115f3a0: str             w1, [x0, x17]
    // 0x115f3a4: LeaveFrame
    //     0x115f3a4: mov             SP, fp
    //     0x115f3a8: ldp             fp, lr, [SP], #0x10
    // 0x115f3ac: ret
    //     0x115f3ac: ret             
    // 0x115f3b0: r0 = StackOverflowSharedWithFPURegs()
    //     0x115f3b0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x115f3b4: b               #0x115e08c
    // 0x115f3b8: SaveReg d0
    //     0x115f3b8: str             q0, [SP, #-0x10]!
    // 0x115f3bc: stp             x4, x5, [SP, #-0x10]!
    // 0x115f3c0: stp             x1, x2, [SP, #-0x10]!
    // 0x115f3c4: SaveReg r0
    //     0x115f3c4: str             x0, [SP, #-8]!
    // 0x115f3c8: r0 = AllocateDouble()
    //     0x115f3c8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x115f3cc: mov             x6, x0
    // 0x115f3d0: RestoreReg r0
    //     0x115f3d0: ldr             x0, [SP], #8
    // 0x115f3d4: ldp             x1, x2, [SP], #0x10
    // 0x115f3d8: ldp             x4, x5, [SP], #0x10
    // 0x115f3dc: RestoreReg d0
    //     0x115f3dc: ldr             q0, [SP], #0x10
    // 0x115f3e0: b               #0x115e268
  }
  static _ _lerpThemeExtensions(/* No info */) {
    // ** addr: 0x116a974, size: 0x19c
    // 0x116a974: EnterFrame
    //     0x116a974: stp             fp, lr, [SP, #-0x10]!
    //     0x116a978: mov             fp, SP
    // 0x116a97c: AllocStack(0x38)
    //     0x116a97c: sub             SP, SP, #0x38
    // 0x116a980: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x20 */)
    //     0x116a980: stur            x1, [fp, #-8]
    //     0x116a984: stur            x2, [fp, #-0x10]
    //     0x116a988: stur            d0, [fp, #-0x20]
    // 0x116a98c: CheckStackOverflow
    //     0x116a98c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116a990: cmp             SP, x16
    //     0x116a994: b.ls            #0x116aaec
    // 0x116a998: r1 = 3
    //     0x116a998: mov             x1, #3
    // 0x116a99c: r0 = AllocateContext()
    //     0x116a99c: bl              #0x13de838  ; AllocateContextStub
    // 0x116a9a0: mov             x3, x0
    // 0x116a9a4: ldur            x0, [fp, #-8]
    // 0x116a9a8: stur            x3, [fp, #-0x18]
    // 0x116a9ac: StoreField: r3->field_f = r0
    //     0x116a9ac: stur            w0, [x3, #0xf]
    // 0x116a9b0: ldur            x1, [fp, #-0x10]
    // 0x116a9b4: StoreField: r3->field_13 = r1
    //     0x116a9b4: stur            w1, [x3, #0x13]
    // 0x116a9b8: ldur            d0, [fp, #-0x20]
    // 0x116a9bc: r1 = inline_Allocate_Double()
    //     0x116a9bc: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x116a9c0: add             x1, x1, #0x10
    //     0x116a9c4: cmp             x2, x1
    //     0x116a9c8: b.ls            #0x116aaf4
    //     0x116a9cc: str             x1, [THR, #0x60]  ; THR::top
    //     0x116a9d0: sub             x1, x1, #0xf
    //     0x116a9d4: mov             x2, #0xe19c
    //     0x116a9d8: movk            x2, #3, lsl #16
    //     0x116a9dc: stur            x2, [x1, #-1]
    // 0x116a9e0: dmb             ishst
    // 0x116a9e4: StoreField: r1->field_7 = d0
    //     0x116a9e4: stur            d0, [x1, #7]
    // 0x116a9e8: ArrayStore: r3[0] = r1  ; List_4
    //     0x116a9e8: stur            w1, [x3, #0x17]
    // 0x116a9ec: LoadField: r4 = r0->field_f
    //     0x116a9ec: ldur            w4, [x0, #0xf]
    // 0x116a9f0: DecompressPointer r4
    //     0x116a9f0: add             x4, x4, HEAP, lsl #32
    // 0x116a9f4: mov             x2, x3
    // 0x116a9f8: stur            x4, [fp, #-0x10]
    // 0x116a9fc: r1 = Function '<anonymous closure>': static.
    //     0x116a9fc: add             x1, PP, #0xad, lsl #12  ; [pp+0xadd20] AnonymousClosure: static (0x116ab7c), in [package:flutter/src/material/theme_data.dart] ThemeData::_lerpThemeExtensions (0x116a974)
    //     0x116aa00: ldr             x1, [x1, #0xd20]
    // 0x116aa04: r0 = AllocateClosure()
    //     0x116aa04: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x116aa08: mov             x1, x0
    // 0x116aa0c: ldur            x0, [fp, #-0x10]
    // 0x116aa10: r2 = LoadClassIdInstr(r0)
    //     0x116aa10: ldur            x2, [x0, #-1]
    //     0x116aa14: ubfx            x2, x2, #0xc, #0x14
    // 0x116aa18: r16 = <Object, ThemeExtension>
    //     0x116aa18: add             x16, PP, #0x12, lsl #12  ; [pp+0x12e88] TypeArguments: <Object, ThemeExtension>
    //     0x116aa1c: ldr             x16, [x16, #0xe88]
    // 0x116aa20: stp             x0, x16, [SP, #8]
    // 0x116aa24: str             x1, [SP]
    // 0x116aa28: mov             x0, x2
    // 0x116aa2c: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0x116aa2c: ldr             x4, [PP, #0x808]  ; [pp+0x808] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    // 0x116aa30: r0 = GDT[cid_x0 + 0xe626]()
    //     0x116aa30: mov             x17, #0xe626
    //     0x116aa34: add             lr, x0, x17
    //     0x116aa38: ldr             lr, [x21, lr, lsl #3]
    //     0x116aa3c: blr             lr
    // 0x116aa40: mov             x3, x0
    // 0x116aa44: ldur            x2, [fp, #-0x18]
    // 0x116aa48: stur            x3, [fp, #-8]
    // 0x116aa4c: LoadField: r0 = r2->field_13
    //     0x116aa4c: ldur            w0, [x2, #0x13]
    // 0x116aa50: DecompressPointer r0
    //     0x116aa50: add             x0, x0, HEAP, lsl #32
    // 0x116aa54: LoadField: r1 = r0->field_f
    //     0x116aa54: ldur            w1, [x0, #0xf]
    // 0x116aa58: DecompressPointer r1
    //     0x116aa58: add             x1, x1, HEAP, lsl #32
    // 0x116aa5c: r0 = LoadClassIdInstr(r1)
    //     0x116aa5c: ldur            x0, [x1, #-1]
    //     0x116aa60: ubfx            x0, x0, #0xc, #0x14
    // 0x116aa64: r0 = GDT[cid_x0 + 0xfc4]()
    //     0x116aa64: add             lr, x0, #0xfc4
    //     0x116aa68: ldr             lr, [x21, lr, lsl #3]
    //     0x116aa6c: blr             lr
    // 0x116aa70: ldur            x2, [fp, #-0x18]
    // 0x116aa74: r1 = Function '<anonymous closure>': static.
    //     0x116aa74: add             x1, PP, #0xad, lsl #12  ; [pp+0xadd28] AnonymousClosure: static (0x116ab10), in [package:flutter/src/material/theme_data.dart] ThemeData::_lerpThemeExtensions (0x116a974)
    //     0x116aa78: ldr             x1, [x1, #0xd28]
    // 0x116aa7c: stur            x0, [fp, #-0x10]
    // 0x116aa80: r0 = AllocateClosure()
    //     0x116aa80: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x116aa84: ldur            x1, [fp, #-0x10]
    // 0x116aa88: r2 = LoadClassIdInstr(r1)
    //     0x116aa88: ldur            x2, [x1, #-1]
    //     0x116aa8c: ubfx            x2, x2, #0xc, #0x14
    // 0x116aa90: mov             x16, x0
    // 0x116aa94: mov             x0, x2
    // 0x116aa98: mov             x2, x16
    // 0x116aa9c: r0 = GDT[cid_x0 + 0x12f92]()
    //     0x116aa9c: mov             x17, #0x2f92
    //     0x116aaa0: movk            x17, #1, lsl #16
    //     0x116aaa4: add             lr, x0, x17
    //     0x116aaa8: ldr             lr, [x21, lr, lsl #3]
    //     0x116aaac: blr             lr
    // 0x116aab0: ldur            x3, [fp, #-8]
    // 0x116aab4: r1 = LoadClassIdInstr(r3)
    //     0x116aab4: ldur            x1, [x3, #-1]
    //     0x116aab8: ubfx            x1, x1, #0xc, #0x14
    // 0x116aabc: mov             x2, x0
    // 0x116aac0: mov             x0, x1
    // 0x116aac4: mov             x1, x3
    // 0x116aac8: r0 = GDT[cid_x0 + 0x14298]()
    //     0x116aac8: mov             x17, #0x4298
    //     0x116aacc: movk            x17, #1, lsl #16
    //     0x116aad0: add             lr, x0, x17
    //     0x116aad4: ldr             lr, [x21, lr, lsl #3]
    //     0x116aad8: blr             lr
    // 0x116aadc: ldur            x0, [fp, #-8]
    // 0x116aae0: LeaveFrame
    //     0x116aae0: mov             SP, fp
    //     0x116aae4: ldp             fp, lr, [SP], #0x10
    // 0x116aae8: ret
    //     0x116aae8: ret             
    // 0x116aaec: r0 = StackOverflowSharedWithFPURegs()
    //     0x116aaec: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x116aaf0: b               #0x116a998
    // 0x116aaf4: SaveReg d0
    //     0x116aaf4: str             q0, [SP, #-0x10]!
    // 0x116aaf8: stp             x0, x3, [SP, #-0x10]!
    // 0x116aafc: r0 = AllocateDouble()
    //     0x116aafc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116ab00: mov             x1, x0
    // 0x116ab04: ldp             x0, x3, [SP], #0x10
    // 0x116ab08: RestoreReg d0
    //     0x116ab08: ldr             q0, [SP], #0x10
    // 0x116ab0c: b               #0x116a9e4
  }
  [closure] static bool <anonymous closure>(dynamic, MapEntry<Object, ThemeExtension<dynamic>>) {
    // ** addr: 0x116ab10, size: 0x6c
    // 0x116ab10: EnterFrame
    //     0x116ab10: stp             fp, lr, [SP, #-0x10]!
    //     0x116ab14: mov             fp, SP
    // 0x116ab18: ldr             x0, [fp, #0x18]
    // 0x116ab1c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x116ab1c: ldur            w1, [x0, #0x17]
    // 0x116ab20: DecompressPointer r1
    //     0x116ab20: add             x1, x1, HEAP, lsl #32
    // 0x116ab24: CheckStackOverflow
    //     0x116ab24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116ab28: cmp             SP, x16
    //     0x116ab2c: b.ls            #0x116ab74
    // 0x116ab30: LoadField: r0 = r1->field_f
    //     0x116ab30: ldur            w0, [x1, #0xf]
    // 0x116ab34: DecompressPointer r0
    //     0x116ab34: add             x0, x0, HEAP, lsl #32
    // 0x116ab38: LoadField: r1 = r0->field_f
    //     0x116ab38: ldur            w1, [x0, #0xf]
    // 0x116ab3c: DecompressPointer r1
    //     0x116ab3c: add             x1, x1, HEAP, lsl #32
    // 0x116ab40: ldr             x0, [fp, #0x10]
    // 0x116ab44: LoadField: r2 = r0->field_b
    //     0x116ab44: ldur            w2, [x0, #0xb]
    // 0x116ab48: DecompressPointer r2
    //     0x116ab48: add             x2, x2, HEAP, lsl #32
    // 0x116ab4c: r0 = LoadClassIdInstr(r1)
    //     0x116ab4c: ldur            x0, [x1, #-1]
    //     0x116ab50: ubfx            x0, x0, #0xc, #0x14
    // 0x116ab54: r0 = GDT[cid_x0 + -0x104]()
    //     0x116ab54: sub             lr, x0, #0x104
    //     0x116ab58: ldr             lr, [x21, lr, lsl #3]
    //     0x116ab5c: blr             lr
    // 0x116ab60: eor             x1, x0, #0x10
    // 0x116ab64: mov             x0, x1
    // 0x116ab68: LeaveFrame
    //     0x116ab68: mov             SP, fp
    //     0x116ab6c: ldp             fp, lr, [SP], #0x10
    // 0x116ab70: ret
    //     0x116ab70: ret             
    // 0x116ab74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116ab74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116ab78: b               #0x116ab30
  }
  [closure] static MapEntry<Object, ThemeExtension<dynamic>> <anonymous closure>(dynamic, Object, ThemeExtension<dynamic>) {
    // ** addr: 0x116ab7c, size: 0xc8
    // 0x116ab7c: EnterFrame
    //     0x116ab7c: stp             fp, lr, [SP, #-0x10]!
    //     0x116ab80: mov             fp, SP
    // 0x116ab84: AllocStack(0x8)
    //     0x116ab84: sub             SP, SP, #8
    // 0x116ab88: SetupParameters([dynamic _ /* r0 */])
    //     0x116ab88: ldr             x0, [fp, #0x20]
    //     0x116ab8c: ldur            w3, [x0, #0x17]
    //     0x116ab90: add             x3, x3, HEAP, lsl #32
    //     0x116ab94: stur            x3, [fp, #-8]
    // 0x116ab98: CheckStackOverflow
    //     0x116ab98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116ab9c: cmp             SP, x16
    //     0x116aba0: b.ls            #0x116ac3c
    // 0x116aba4: LoadField: r0 = r3->field_13
    //     0x116aba4: ldur            w0, [x3, #0x13]
    // 0x116aba8: DecompressPointer r0
    //     0x116aba8: add             x0, x0, HEAP, lsl #32
    // 0x116abac: LoadField: r1 = r0->field_f
    //     0x116abac: ldur            w1, [x0, #0xf]
    // 0x116abb0: DecompressPointer r1
    //     0x116abb0: add             x1, x1, HEAP, lsl #32
    // 0x116abb4: r0 = LoadClassIdInstr(r1)
    //     0x116abb4: ldur            x0, [x1, #-1]
    //     0x116abb8: ubfx            x0, x0, #0xc, #0x14
    // 0x116abbc: ldr             x2, [fp, #0x18]
    // 0x116abc0: r0 = GDT[cid_x0 + -0xd48]()
    //     0x116abc0: sub             lr, x0, #0xd48
    //     0x116abc4: ldr             lr, [x21, lr, lsl #3]
    //     0x116abc8: blr             lr
    // 0x116abcc: mov             x1, x0
    // 0x116abd0: ldur            x0, [fp, #-8]
    // 0x116abd4: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x116abd4: ldur            w2, [x0, #0x17]
    // 0x116abd8: DecompressPointer r2
    //     0x116abd8: add             x2, x2, HEAP, lsl #32
    // 0x116abdc: LoadField: d0 = r2->field_7
    //     0x116abdc: ldur            d0, [x2, #7]
    // 0x116abe0: ldr             x0, [fp, #0x10]
    // 0x116abe4: r2 = LoadClassIdInstr(r0)
    //     0x116abe4: ldur            x2, [x0, #-1]
    //     0x116abe8: ubfx            x2, x2, #0xc, #0x14
    // 0x116abec: mov             x16, x1
    // 0x116abf0: mov             x1, x2
    // 0x116abf4: mov             x2, x16
    // 0x116abf8: mov             x16, x0
    // 0x116abfc: mov             x0, x1
    // 0x116ac00: mov             x1, x16
    // 0x116ac04: r0 = GDT[cid_x0 + -0xfcc]()
    //     0x116ac04: sub             lr, x0, #0xfcc
    //     0x116ac08: ldr             lr, [x21, lr, lsl #3]
    //     0x116ac0c: blr             lr
    // 0x116ac10: r1 = <Object, ThemeExtension>
    //     0x116ac10: add             x1, PP, #0x12, lsl #12  ; [pp+0x12e88] TypeArguments: <Object, ThemeExtension>
    //     0x116ac14: ldr             x1, [x1, #0xe88]
    // 0x116ac18: stur            x0, [fp, #-8]
    // 0x116ac1c: r0 = MapEntry()
    //     0x116ac1c: bl              #0x8027cc  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0x116ac20: ldr             x1, [fp, #0x18]
    // 0x116ac24: StoreField: r0->field_b = r1
    //     0x116ac24: stur            w1, [x0, #0xb]
    // 0x116ac28: ldur            x1, [fp, #-8]
    // 0x116ac2c: StoreField: r0->field_f = r1
    //     0x116ac2c: stur            w1, [x0, #0xf]
    // 0x116ac30: LeaveFrame
    //     0x116ac30: mov             SP, fp
    //     0x116ac34: ldp             fp, lr, [SP], #0x10
    // 0x116ac38: ret
    //     0x116ac38: ret             
    // 0x116ac3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116ac3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116ac40: b               #0x116aba4
  }
  _ ==(/* No info */) {
    // ** addr: 0x12774c4, size: 0xd8c
    // 0x12774c4: EnterFrame
    //     0x12774c4: stp             fp, lr, [SP, #-0x10]!
    //     0x12774c8: mov             fp, SP
    // 0x12774cc: AllocStack(0x28)
    //     0x12774cc: sub             SP, SP, #0x28
    // 0x12774d0: CheckStackOverflow
    //     0x12774d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12774d4: cmp             SP, x16
    //     0x12774d8: b.ls            #0x1278248
    // 0x12774dc: ldr             x0, [fp, #0x10]
    // 0x12774e0: cmp             w0, NULL
    // 0x12774e4: b.ne            #0x12774f8
    // 0x12774e8: r0 = false
    //     0x12774e8: add             x0, NULL, #0x30  ; false
    // 0x12774ec: LeaveFrame
    //     0x12774ec: mov             SP, fp
    //     0x12774f0: ldp             fp, lr, [SP], #0x10
    // 0x12774f4: ret
    //     0x12774f4: ret             
    // 0x12774f8: str             x0, [SP]
    // 0x12774fc: r0 = runtimeType()
    //     0x12774fc: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1277500: r1 = LoadClassIdInstr(r0)
    //     0x1277500: ldur            x1, [x0, #-1]
    //     0x1277504: ubfx            x1, x1, #0xc, #0x14
    // 0x1277508: r16 = ThemeData
    //     0x1277508: add             x16, PP, #0x26, lsl #12  ; [pp+0x26b18] Type: ThemeData
    //     0x127750c: ldr             x16, [x16, #0xb18]
    // 0x1277510: stp             x16, x0, [SP]
    // 0x1277514: mov             x0, x1
    // 0x1277518: mov             lr, x0
    // 0x127751c: ldr             lr, [x21, lr, lsl #3]
    // 0x1277520: blr             lr
    // 0x1277524: tbz             w0, #4, #0x1277538
    // 0x1277528: r0 = false
    //     0x1277528: add             x0, NULL, #0x30  ; false
    // 0x127752c: LeaveFrame
    //     0x127752c: mov             SP, fp
    //     0x1277530: ldp             fp, lr, [SP], #0x10
    // 0x1277534: ret
    //     0x1277534: ret             
    // 0x1277538: ldr             x0, [fp, #0x10]
    // 0x127753c: r1 = 60
    //     0x127753c: mov             x1, #0x3c
    // 0x1277540: branchIfSmi(r0, 0x127754c)
    //     0x1277540: tbz             w0, #0, #0x127754c
    // 0x1277544: r1 = LoadClassIdInstr(r0)
    //     0x1277544: ldur            x1, [x0, #-1]
    //     0x1277548: ubfx            x1, x1, #0xc, #0x14
    // 0x127754c: r17 = 5054
    //     0x127754c: mov             x17, #0x13be
    // 0x1277550: cmp             x1, x17
    // 0x1277554: b.ne            #0x1278238
    // 0x1277558: ldr             x1, [fp, #0x18]
    // 0x127755c: LoadField: r2 = r0->field_13
    //     0x127755c: ldur            w2, [x0, #0x13]
    // 0x1277560: DecompressPointer r2
    //     0x1277560: add             x2, x2, HEAP, lsl #32
    // 0x1277564: LoadField: r3 = r1->field_13
    //     0x1277564: ldur            w3, [x1, #0x13]
    // 0x1277568: DecompressPointer r3
    //     0x1277568: add             x3, x3, HEAP, lsl #32
    // 0x127756c: r16 = <Type, Adaptation<Object>>
    //     0x127756c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12e90] TypeArguments: <Type, Adaptation<Object>>
    //     0x1277570: ldr             x16, [x16, #0xe90]
    // 0x1277574: stp             x2, x16, [SP, #8]
    // 0x1277578: str             x3, [SP]
    // 0x127757c: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0x127757c: ldr             x4, [PP, #0x808]  ; [pp+0x808] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    // 0x1277580: r0 = mapEquals()
    //     0x1277580: bl              #0xc015b8  ; [package:flutter/src/foundation/collections.dart] ::mapEquals
    // 0x1277584: tbnz            w0, #4, #0x1278238
    // 0x1277588: ldr             x1, [fp, #0x18]
    // 0x127758c: ldr             x0, [fp, #0x10]
    // 0x1277590: LoadField: r2 = r0->field_7
    //     0x1277590: ldur            w2, [x0, #7]
    // 0x1277594: DecompressPointer r2
    //     0x1277594: add             x2, x2, HEAP, lsl #32
    // 0x1277598: LoadField: r3 = r1->field_7
    //     0x1277598: ldur            w3, [x1, #7]
    // 0x127759c: DecompressPointer r3
    //     0x127759c: add             x3, x3, HEAP, lsl #32
    // 0x12775a0: cmp             w2, w3
    // 0x12775a4: b.ne            #0x1278238
    // 0x12775a8: LoadField: r2 = r0->field_f
    //     0x12775a8: ldur            w2, [x0, #0xf]
    // 0x12775ac: DecompressPointer r2
    //     0x12775ac: add             x2, x2, HEAP, lsl #32
    // 0x12775b0: LoadField: r3 = r1->field_f
    //     0x12775b0: ldur            w3, [x1, #0xf]
    // 0x12775b4: DecompressPointer r3
    //     0x12775b4: add             x3, x3, HEAP, lsl #32
    // 0x12775b8: r16 = <Object, ThemeExtension>
    //     0x12775b8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12e88] TypeArguments: <Object, ThemeExtension>
    //     0x12775bc: ldr             x16, [x16, #0xe88]
    // 0x12775c0: stp             x2, x16, [SP, #8]
    // 0x12775c4: str             x3, [SP]
    // 0x12775c8: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0x12775c8: ldr             x4, [PP, #0x808]  ; [pp+0x808] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    // 0x12775cc: r0 = mapEquals()
    //     0x12775cc: bl              #0xc015b8  ; [package:flutter/src/foundation/collections.dart] ::mapEquals
    // 0x12775d0: tbnz            w0, #4, #0x1278238
    // 0x12775d4: ldr             x1, [fp, #0x18]
    // 0x12775d8: ldr             x0, [fp, #0x10]
    // 0x12775dc: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x12775dc: ldur            w2, [x0, #0x17]
    // 0x12775e0: DecompressPointer r2
    //     0x12775e0: add             x2, x2, HEAP, lsl #32
    // 0x12775e4: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x12775e4: ldur            w3, [x1, #0x17]
    // 0x12775e8: DecompressPointer r3
    //     0x12775e8: add             x3, x3, HEAP, lsl #32
    // 0x12775ec: stp             x3, x2, [SP]
    // 0x12775f0: r0 = ==()
    //     0x12775f0: bl              #0x126d8d8  ; [package:flutter/src/material/input_decorator.dart] InputDecorationThemeData::==
    // 0x12775f4: tbnz            w0, #4, #0x1278238
    // 0x12775f8: ldr             x1, [fp, #0x18]
    // 0x12775fc: ldr             x0, [fp, #0x10]
    // 0x1277600: LoadField: r2 = r0->field_1b
    //     0x1277600: ldur            w2, [x0, #0x1b]
    // 0x1277604: DecompressPointer r2
    //     0x1277604: add             x2, x2, HEAP, lsl #32
    // 0x1277608: LoadField: r3 = r1->field_1b
    //     0x1277608: ldur            w3, [x1, #0x1b]
    // 0x127760c: DecompressPointer r3
    //     0x127760c: add             x3, x3, HEAP, lsl #32
    // 0x1277610: cmp             w2, w3
    // 0x1277614: b.ne            #0x1278238
    // 0x1277618: LoadField: r2 = r0->field_27
    //     0x1277618: ldur            w2, [x0, #0x27]
    // 0x127761c: DecompressPointer r2
    //     0x127761c: add             x2, x2, HEAP, lsl #32
    // 0x1277620: LoadField: r3 = r1->field_27
    //     0x1277620: ldur            w3, [x1, #0x27]
    // 0x1277624: DecompressPointer r3
    //     0x1277624: add             x3, x3, HEAP, lsl #32
    // 0x1277628: stp             x3, x2, [SP]
    // 0x127762c: r0 = ==()
    //     0x127762c: bl              #0x1271718  ; [package:flutter/src/material/scrollbar_theme.dart] ScrollbarThemeData::==
    // 0x1277630: tbnz            w0, #4, #0x1278238
    // 0x1277634: ldr             x1, [fp, #0x18]
    // 0x1277638: ldr             x0, [fp, #0x10]
    // 0x127763c: LoadField: r2 = r0->field_2b
    //     0x127763c: ldur            w2, [x0, #0x2b]
    // 0x1277640: DecompressPointer r2
    //     0x1277640: add             x2, x2, HEAP, lsl #32
    // 0x1277644: LoadField: r3 = r1->field_2b
    //     0x1277644: ldur            w3, [x1, #0x2b]
    // 0x1277648: DecompressPointer r3
    //     0x1277648: add             x3, x3, HEAP, lsl #32
    // 0x127764c: cmp             w2, w3
    // 0x1277650: b.ne            #0x1278238
    // 0x1277654: LoadField: r2 = r0->field_2f
    //     0x1277654: ldur            w2, [x0, #0x2f]
    // 0x1277658: DecompressPointer r2
    //     0x1277658: add             x2, x2, HEAP, lsl #32
    // 0x127765c: LoadField: r3 = r1->field_2f
    //     0x127765c: ldur            w3, [x1, #0x2f]
    // 0x1277660: DecompressPointer r3
    //     0x1277660: add             x3, x3, HEAP, lsl #32
    // 0x1277664: cmp             w2, w3
    // 0x1277668: b.ne            #0x1278238
    // 0x127766c: LoadField: r2 = r0->field_33
    //     0x127766c: ldur            w2, [x0, #0x33]
    // 0x1277670: DecompressPointer r2
    //     0x1277670: add             x2, x2, HEAP, lsl #32
    // 0x1277674: stur            x2, [fp, #-0x10]
    // 0x1277678: LoadField: r3 = r1->field_33
    //     0x1277678: ldur            w3, [x1, #0x33]
    // 0x127767c: DecompressPointer r3
    //     0x127767c: add             x3, x3, HEAP, lsl #32
    // 0x1277680: stur            x3, [fp, #-8]
    // 0x1277684: r16 = VisualDensity
    //     0x1277684: add             x16, PP, #0x26, lsl #12  ; [pp+0x26b20] Type: VisualDensity
    //     0x1277688: ldr             x16, [x16, #0xb20]
    // 0x127768c: r30 = VisualDensity
    //     0x127768c: add             lr, PP, #0x26, lsl #12  ; [pp+0x26b20] Type: VisualDensity
    //     0x1277690: ldr             lr, [lr, #0xb20]
    // 0x1277694: stp             lr, x16, [SP]
    // 0x1277698: r0 = ==()
    //     0x1277698: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x127769c: tbnz            w0, #4, #0x1278238
    // 0x12776a0: ldur            x0, [fp, #-0x10]
    // 0x12776a4: ldur            x1, [fp, #-8]
    // 0x12776a8: LoadField: d0 = r1->field_7
    //     0x12776a8: ldur            d0, [x1, #7]
    // 0x12776ac: LoadField: d1 = r0->field_7
    //     0x12776ac: ldur            d1, [x0, #7]
    // 0x12776b0: fcmp            d0, d1
    // 0x12776b4: b.ne            #0x1278238
    // 0x12776b8: LoadField: d0 = r1->field_f
    //     0x12776b8: ldur            d0, [x1, #0xf]
    // 0x12776bc: LoadField: d1 = r0->field_f
    //     0x12776bc: ldur            d1, [x0, #0xf]
    // 0x12776c0: fcmp            d0, d1
    // 0x12776c4: b.ne            #0x1278238
    // 0x12776c8: ldr             x2, [fp, #0x18]
    // 0x12776cc: ldr             x1, [fp, #0x10]
    // 0x12776d0: LoadField: r0 = r1->field_37
    //     0x12776d0: ldur            w0, [x1, #0x37]
    // 0x12776d4: DecompressPointer r0
    //     0x12776d4: add             x0, x0, HEAP, lsl #32
    // 0x12776d8: LoadField: r3 = r2->field_37
    //     0x12776d8: ldur            w3, [x2, #0x37]
    // 0x12776dc: DecompressPointer r3
    //     0x12776dc: add             x3, x3, HEAP, lsl #32
    // 0x12776e0: r4 = LoadClassIdInstr(r0)
    //     0x12776e0: ldur            x4, [x0, #-1]
    //     0x12776e4: ubfx            x4, x4, #0xc, #0x14
    // 0x12776e8: stp             x3, x0, [SP]
    // 0x12776ec: mov             x0, x4
    // 0x12776f0: mov             lr, x0
    // 0x12776f4: ldr             lr, [x21, lr, lsl #3]
    // 0x12776f8: blr             lr
    // 0x12776fc: tbnz            w0, #4, #0x1278238
    // 0x1277700: ldr             x2, [fp, #0x18]
    // 0x1277704: ldr             x1, [fp, #0x10]
    // 0x1277708: LoadField: r0 = r1->field_3b
    //     0x1277708: ldur            w0, [x1, #0x3b]
    // 0x127770c: DecompressPointer r0
    //     0x127770c: add             x0, x0, HEAP, lsl #32
    // 0x1277710: LoadField: r3 = r2->field_3b
    //     0x1277710: ldur            w3, [x2, #0x3b]
    // 0x1277714: DecompressPointer r3
    //     0x1277714: add             x3, x3, HEAP, lsl #32
    // 0x1277718: r4 = LoadClassIdInstr(r0)
    //     0x1277718: ldur            x4, [x0, #-1]
    //     0x127771c: ubfx            x4, x4, #0xc, #0x14
    // 0x1277720: stp             x3, x0, [SP]
    // 0x1277724: mov             x0, x4
    // 0x1277728: mov             lr, x0
    // 0x127772c: ldr             lr, [x21, lr, lsl #3]
    // 0x1277730: blr             lr
    // 0x1277734: tbnz            w0, #4, #0x1278238
    // 0x1277738: ldr             x1, [fp, #0x18]
    // 0x127773c: ldr             x0, [fp, #0x10]
    // 0x1277740: LoadField: r2 = r0->field_3f
    //     0x1277740: ldur            w2, [x0, #0x3f]
    // 0x1277744: DecompressPointer r2
    //     0x1277744: add             x2, x2, HEAP, lsl #32
    // 0x1277748: LoadField: r3 = r1->field_3f
    //     0x1277748: ldur            w3, [x1, #0x3f]
    // 0x127774c: DecompressPointer r3
    //     0x127774c: add             x3, x3, HEAP, lsl #32
    // 0x1277750: stp             x3, x2, [SP]
    // 0x1277754: r0 = ==()
    //     0x1277754: bl              #0x1266a28  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::==
    // 0x1277758: tbnz            w0, #4, #0x1278238
    // 0x127775c: ldr             x1, [fp, #0x18]
    // 0x1277760: ldr             x0, [fp, #0x10]
    // 0x1277764: LoadField: r2 = r0->field_43
    //     0x1277764: ldur            w2, [x0, #0x43]
    // 0x1277768: DecompressPointer r2
    //     0x1277768: add             x2, x2, HEAP, lsl #32
    // 0x127776c: LoadField: r3 = r1->field_43
    //     0x127776c: ldur            w3, [x1, #0x43]
    // 0x1277770: DecompressPointer r3
    //     0x1277770: add             x3, x3, HEAP, lsl #32
    // 0x1277774: stp             x3, x2, [SP]
    // 0x1277778: r0 = ==()
    //     0x1277778: bl              #0x128cb50  ; [dart:ui] Color::==
    // 0x127777c: tbnz            w0, #4, #0x1278238
    // 0x1277780: ldr             x2, [fp, #0x18]
    // 0x1277784: ldr             x1, [fp, #0x10]
    // 0x1277788: LoadField: r0 = r1->field_47
    //     0x1277788: ldur            w0, [x1, #0x47]
    // 0x127778c: DecompressPointer r0
    //     0x127778c: add             x0, x0, HEAP, lsl #32
    // 0x1277790: LoadField: r3 = r2->field_47
    //     0x1277790: ldur            w3, [x2, #0x47]
    // 0x1277794: DecompressPointer r3
    //     0x1277794: add             x3, x3, HEAP, lsl #32
    // 0x1277798: r4 = LoadClassIdInstr(r0)
    //     0x1277798: ldur            x4, [x0, #-1]
    //     0x127779c: ubfx            x4, x4, #0xc, #0x14
    // 0x12777a0: stp             x3, x0, [SP]
    // 0x12777a4: mov             x0, x4
    // 0x12777a8: mov             lr, x0
    // 0x12777ac: ldr             lr, [x21, lr, lsl #3]
    // 0x12777b0: blr             lr
    // 0x12777b4: tbnz            w0, #4, #0x1278238
    // 0x12777b8: ldr             x1, [fp, #0x18]
    // 0x12777bc: ldr             x0, [fp, #0x10]
    // 0x12777c0: LoadField: r2 = r0->field_4b
    //     0x12777c0: ldur            w2, [x0, #0x4b]
    // 0x12777c4: DecompressPointer r2
    //     0x12777c4: add             x2, x2, HEAP, lsl #32
    // 0x12777c8: LoadField: r3 = r1->field_4b
    //     0x12777c8: ldur            w3, [x1, #0x4b]
    // 0x12777cc: DecompressPointer r3
    //     0x12777cc: add             x3, x3, HEAP, lsl #32
    // 0x12777d0: stp             x3, x2, [SP]
    // 0x12777d4: r0 = ==()
    //     0x12777d4: bl              #0x128cb50  ; [dart:ui] Color::==
    // 0x12777d8: tbnz            w0, #4, #0x1278238
    // 0x12777dc: ldr             x1, [fp, #0x18]
    // 0x12777e0: ldr             x0, [fp, #0x10]
    // 0x12777e4: LoadField: r2 = r0->field_4f
    //     0x12777e4: ldur            w2, [x0, #0x4f]
    // 0x12777e8: DecompressPointer r2
    //     0x12777e8: add             x2, x2, HEAP, lsl #32
    // 0x12777ec: LoadField: r3 = r1->field_4f
    //     0x12777ec: ldur            w3, [x1, #0x4f]
    // 0x12777f0: DecompressPointer r3
    //     0x12777f0: add             x3, x3, HEAP, lsl #32
    // 0x12777f4: stp             x3, x2, [SP]
    // 0x12777f8: r0 = ==()
    //     0x12777f8: bl              #0x128cb50  ; [dart:ui] Color::==
    // 0x12777fc: tbnz            w0, #4, #0x1278238
    // 0x1277800: ldr             x1, [fp, #0x18]
    // 0x1277804: ldr             x0, [fp, #0x10]
    // 0x1277808: LoadField: r2 = r0->field_53
    //     0x1277808: ldur            w2, [x0, #0x53]
    // 0x127780c: DecompressPointer r2
    //     0x127780c: add             x2, x2, HEAP, lsl #32
    // 0x1277810: LoadField: r3 = r1->field_53
    //     0x1277810: ldur            w3, [x1, #0x53]
    // 0x1277814: DecompressPointer r3
    //     0x1277814: add             x3, x3, HEAP, lsl #32
    // 0x1277818: stp             x3, x2, [SP]
    // 0x127781c: r0 = ==()
    //     0x127781c: bl              #0x128cb50  ; [dart:ui] Color::==
    // 0x1277820: tbnz            w0, #4, #0x1278238
    // 0x1277824: ldr             x1, [fp, #0x18]
    // 0x1277828: ldr             x0, [fp, #0x10]
    // 0x127782c: LoadField: r2 = r0->field_57
    //     0x127782c: ldur            w2, [x0, #0x57]
    // 0x1277830: DecompressPointer r2
    //     0x1277830: add             x2, x2, HEAP, lsl #32
    // 0x1277834: LoadField: r3 = r1->field_57
    //     0x1277834: ldur            w3, [x1, #0x57]
    // 0x1277838: DecompressPointer r3
    //     0x1277838: add             x3, x3, HEAP, lsl #32
    // 0x127783c: stp             x3, x2, [SP]
    // 0x1277840: r0 = ==()
    //     0x1277840: bl              #0x128cb50  ; [dart:ui] Color::==
    // 0x1277844: tbnz            w0, #4, #0x1278238
    // 0x1277848: ldr             x2, [fp, #0x18]
    // 0x127784c: ldr             x1, [fp, #0x10]
    // 0x1277850: LoadField: r0 = r1->field_5b
    //     0x1277850: ldur            w0, [x1, #0x5b]
    // 0x1277854: DecompressPointer r0
    //     0x1277854: add             x0, x0, HEAP, lsl #32
    // 0x1277858: LoadField: r3 = r2->field_5b
    //     0x1277858: ldur            w3, [x2, #0x5b]
    // 0x127785c: DecompressPointer r3
    //     0x127785c: add             x3, x3, HEAP, lsl #32
    // 0x1277860: r4 = LoadClassIdInstr(r0)
    //     0x1277860: ldur            x4, [x0, #-1]
    //     0x1277864: ubfx            x4, x4, #0xc, #0x14
    // 0x1277868: stp             x3, x0, [SP]
    // 0x127786c: mov             x0, x4
    // 0x1277870: mov             lr, x0
    // 0x1277874: ldr             lr, [x21, lr, lsl #3]
    // 0x1277878: blr             lr
    // 0x127787c: tbnz            w0, #4, #0x1278238
    // 0x1277880: ldr             x2, [fp, #0x18]
    // 0x1277884: ldr             x1, [fp, #0x10]
    // 0x1277888: LoadField: r0 = r1->field_5f
    //     0x1277888: ldur            w0, [x1, #0x5f]
    // 0x127788c: DecompressPointer r0
    //     0x127788c: add             x0, x0, HEAP, lsl #32
    // 0x1277890: LoadField: r3 = r2->field_5f
    //     0x1277890: ldur            w3, [x2, #0x5f]
    // 0x1277894: DecompressPointer r3
    //     0x1277894: add             x3, x3, HEAP, lsl #32
    // 0x1277898: r4 = LoadClassIdInstr(r0)
    //     0x1277898: ldur            x4, [x0, #-1]
    //     0x127789c: ubfx            x4, x4, #0xc, #0x14
    // 0x12778a0: stp             x3, x0, [SP]
    // 0x12778a4: mov             x0, x4
    // 0x12778a8: mov             lr, x0
    // 0x12778ac: ldr             lr, [x21, lr, lsl #3]
    // 0x12778b0: blr             lr
    // 0x12778b4: tbnz            w0, #4, #0x1278238
    // 0x12778b8: ldr             x2, [fp, #0x18]
    // 0x12778bc: ldr             x1, [fp, #0x10]
    // 0x12778c0: LoadField: r0 = r1->field_63
    //     0x12778c0: ldur            w0, [x1, #0x63]
    // 0x12778c4: DecompressPointer r0
    //     0x12778c4: add             x0, x0, HEAP, lsl #32
    // 0x12778c8: LoadField: r3 = r2->field_63
    //     0x12778c8: ldur            w3, [x2, #0x63]
    // 0x12778cc: DecompressPointer r3
    //     0x12778cc: add             x3, x3, HEAP, lsl #32
    // 0x12778d0: r4 = LoadClassIdInstr(r0)
    //     0x12778d0: ldur            x4, [x0, #-1]
    //     0x12778d4: ubfx            x4, x4, #0xc, #0x14
    // 0x12778d8: stp             x3, x0, [SP]
    // 0x12778dc: mov             x0, x4
    // 0x12778e0: mov             lr, x0
    // 0x12778e4: ldr             lr, [x21, lr, lsl #3]
    // 0x12778e8: blr             lr
    // 0x12778ec: tbnz            w0, #4, #0x1278238
    // 0x12778f0: ldr             x2, [fp, #0x18]
    // 0x12778f4: ldr             x1, [fp, #0x10]
    // 0x12778f8: LoadField: r0 = r1->field_67
    //     0x12778f8: ldur            w0, [x1, #0x67]
    // 0x12778fc: DecompressPointer r0
    //     0x12778fc: add             x0, x0, HEAP, lsl #32
    // 0x1277900: LoadField: r3 = r2->field_67
    //     0x1277900: ldur            w3, [x2, #0x67]
    // 0x1277904: DecompressPointer r3
    //     0x1277904: add             x3, x3, HEAP, lsl #32
    // 0x1277908: r4 = LoadClassIdInstr(r0)
    //     0x1277908: ldur            x4, [x0, #-1]
    //     0x127790c: ubfx            x4, x4, #0xc, #0x14
    // 0x1277910: stp             x3, x0, [SP]
    // 0x1277914: mov             x0, x4
    // 0x1277918: mov             lr, x0
    // 0x127791c: ldr             lr, [x21, lr, lsl #3]
    // 0x1277920: blr             lr
    // 0x1277924: tbnz            w0, #4, #0x1278238
    // 0x1277928: ldr             x2, [fp, #0x18]
    // 0x127792c: ldr             x1, [fp, #0x10]
    // 0x1277930: LoadField: r0 = r1->field_6b
    //     0x1277930: ldur            w0, [x1, #0x6b]
    // 0x1277934: DecompressPointer r0
    //     0x1277934: add             x0, x0, HEAP, lsl #32
    // 0x1277938: LoadField: r3 = r2->field_6b
    //     0x1277938: ldur            w3, [x2, #0x6b]
    // 0x127793c: DecompressPointer r3
    //     0x127793c: add             x3, x3, HEAP, lsl #32
    // 0x1277940: r4 = LoadClassIdInstr(r0)
    //     0x1277940: ldur            x4, [x0, #-1]
    //     0x1277944: ubfx            x4, x4, #0xc, #0x14
    // 0x1277948: stp             x3, x0, [SP]
    // 0x127794c: mov             x0, x4
    // 0x1277950: mov             lr, x0
    // 0x1277954: ldr             lr, [x21, lr, lsl #3]
    // 0x1277958: blr             lr
    // 0x127795c: tbnz            w0, #4, #0x1278238
    // 0x1277960: ldr             x1, [fp, #0x18]
    // 0x1277964: ldr             x0, [fp, #0x10]
    // 0x1277968: LoadField: r2 = r0->field_6f
    //     0x1277968: ldur            w2, [x0, #0x6f]
    // 0x127796c: DecompressPointer r2
    //     0x127796c: add             x2, x2, HEAP, lsl #32
    // 0x1277970: LoadField: r3 = r1->field_6f
    //     0x1277970: ldur            w3, [x1, #0x6f]
    // 0x1277974: DecompressPointer r3
    //     0x1277974: add             x3, x3, HEAP, lsl #32
    // 0x1277978: stp             x3, x2, [SP]
    // 0x127797c: r0 = ==()
    //     0x127797c: bl              #0x128cb50  ; [dart:ui] Color::==
    // 0x1277980: tbnz            w0, #4, #0x1278238
    // 0x1277984: ldr             x1, [fp, #0x18]
    // 0x1277988: ldr             x0, [fp, #0x10]
    // 0x127798c: LoadField: r2 = r0->field_73
    //     0x127798c: ldur            w2, [x0, #0x73]
    // 0x1277990: DecompressPointer r2
    //     0x1277990: add             x2, x2, HEAP, lsl #32
    // 0x1277994: LoadField: r3 = r1->field_73
    //     0x1277994: ldur            w3, [x1, #0x73]
    // 0x1277998: DecompressPointer r3
    //     0x1277998: add             x3, x3, HEAP, lsl #32
    // 0x127799c: stp             x3, x2, [SP]
    // 0x12779a0: r0 = ==()
    //     0x12779a0: bl              #0x128cb50  ; [dart:ui] Color::==
    // 0x12779a4: tbnz            w0, #4, #0x1278238
    // 0x12779a8: ldr             x1, [fp, #0x18]
    // 0x12779ac: ldr             x0, [fp, #0x10]
    // 0x12779b0: LoadField: r2 = r0->field_77
    //     0x12779b0: ldur            w2, [x0, #0x77]
    // 0x12779b4: DecompressPointer r2
    //     0x12779b4: add             x2, x2, HEAP, lsl #32
    // 0x12779b8: LoadField: r3 = r1->field_77
    //     0x12779b8: ldur            w3, [x1, #0x77]
    // 0x12779bc: DecompressPointer r3
    //     0x12779bc: add             x3, x3, HEAP, lsl #32
    // 0x12779c0: stp             x3, x2, [SP]
    // 0x12779c4: r0 = ==()
    //     0x12779c4: bl              #0x128cb50  ; [dart:ui] Color::==
    // 0x12779c8: tbnz            w0, #4, #0x1278238
    // 0x12779cc: ldr             x1, [fp, #0x18]
    // 0x12779d0: ldr             x0, [fp, #0x10]
    // 0x12779d4: LoadField: r2 = r0->field_7b
    //     0x12779d4: ldur            w2, [x0, #0x7b]
    // 0x12779d8: DecompressPointer r2
    //     0x12779d8: add             x2, x2, HEAP, lsl #32
    // 0x12779dc: LoadField: r3 = r1->field_7b
    //     0x12779dc: ldur            w3, [x1, #0x7b]
    // 0x12779e0: DecompressPointer r3
    //     0x12779e0: add             x3, x3, HEAP, lsl #32
    // 0x12779e4: stp             x3, x2, [SP]
    // 0x12779e8: r0 = ==()
    //     0x12779e8: bl              #0x12625cc  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::==
    // 0x12779ec: tbnz            w0, #4, #0x1278238
    // 0x12779f0: ldr             x1, [fp, #0x18]
    // 0x12779f4: ldr             x0, [fp, #0x10]
    // 0x12779f8: LoadField: r2 = r0->field_7f
    //     0x12779f8: ldur            w2, [x0, #0x7f]
    // 0x12779fc: DecompressPointer r2
    //     0x12779fc: add             x2, x2, HEAP, lsl #32
    // 0x1277a00: LoadField: r3 = r1->field_7f
    //     0x1277a00: ldur            w3, [x1, #0x7f]
    // 0x1277a04: DecompressPointer r3
    //     0x1277a04: add             x3, x3, HEAP, lsl #32
    // 0x1277a08: stp             x3, x2, [SP]
    // 0x1277a0c: r0 = ==()
    //     0x1277a0c: bl              #0x12625cc  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::==
    // 0x1277a10: tbnz            w0, #4, #0x1278238
    // 0x1277a14: ldr             x1, [fp, #0x18]
    // 0x1277a18: ldr             x0, [fp, #0x10]
    // 0x1277a1c: LoadField: r2 = r0->field_83
    //     0x1277a1c: ldur            w2, [x0, #0x83]
    // 0x1277a20: DecompressPointer r2
    //     0x1277a20: add             x2, x2, HEAP, lsl #32
    // 0x1277a24: LoadField: r3 = r1->field_83
    //     0x1277a24: ldur            w3, [x1, #0x83]
    // 0x1277a28: DecompressPointer r3
    //     0x1277a28: add             x3, x3, HEAP, lsl #32
    // 0x1277a2c: stp             x3, x2, [SP]
    // 0x1277a30: r0 = ==()
    //     0x1277a30: bl              #0x12770f8  ; [package:flutter/src/material/text_theme.dart] TextTheme::==
    // 0x1277a34: tbnz            w0, #4, #0x1278238
    // 0x1277a38: ldr             x1, [fp, #0x18]
    // 0x1277a3c: ldr             x0, [fp, #0x10]
    // 0x1277a40: LoadField: r2 = r0->field_87
    //     0x1277a40: ldur            w2, [x0, #0x87]
    // 0x1277a44: DecompressPointer r2
    //     0x1277a44: add             x2, x2, HEAP, lsl #32
    // 0x1277a48: LoadField: r3 = r1->field_87
    //     0x1277a48: ldur            w3, [x1, #0x87]
    // 0x1277a4c: DecompressPointer r3
    //     0x1277a4c: add             x3, x3, HEAP, lsl #32
    // 0x1277a50: stp             x3, x2, [SP]
    // 0x1277a54: r0 = ==()
    //     0x1277a54: bl              #0x12770f8  ; [package:flutter/src/material/text_theme.dart] TextTheme::==
    // 0x1277a58: tbnz            w0, #4, #0x1278238
    // 0x1277a5c: ldr             x1, [fp, #0x18]
    // 0x1277a60: ldr             x0, [fp, #0x10]
    // 0x1277a64: LoadField: r2 = r0->field_8b
    //     0x1277a64: ldur            w2, [x0, #0x8b]
    // 0x1277a68: DecompressPointer r2
    //     0x1277a68: add             x2, x2, HEAP, lsl #32
    // 0x1277a6c: LoadField: r3 = r1->field_8b
    //     0x1277a6c: ldur            w3, [x1, #0x8b]
    // 0x1277a70: DecompressPointer r3
    //     0x1277a70: add             x3, x3, HEAP, lsl #32
    // 0x1277a74: stp             x3, x2, [SP]
    // 0x1277a78: r0 = ==()
    //     0x1277a78: bl              #0x12786dc  ; [package:flutter/src/material/typography.dart] Typography::==
    // 0x1277a7c: tbnz            w0, #4, #0x1278238
    // 0x1277a80: ldr             x1, [fp, #0x18]
    // 0x1277a84: ldr             x0, [fp, #0x10]
    // 0x1277a88: LoadField: r2 = r0->field_93
    //     0x1277a88: ldur            w2, [x0, #0x93]
    // 0x1277a8c: DecompressPointer r2
    //     0x1277a8c: add             x2, x2, HEAP, lsl #32
    // 0x1277a90: LoadField: r3 = r1->field_93
    //     0x1277a90: ldur            w3, [x1, #0x93]
    // 0x1277a94: DecompressPointer r3
    //     0x1277a94: add             x3, x3, HEAP, lsl #32
    // 0x1277a98: stp             x3, x2, [SP]
    // 0x1277a9c: r0 = ==()
    //     0x1277a9c: bl              #0x126324c  ; [package:flutter/src/material/app_bar_theme.dart] AppBarThemeData::==
    // 0x1277aa0: tbnz            w0, #4, #0x1278238
    // 0x1277aa4: ldr             x1, [fp, #0x18]
    // 0x1277aa8: ldr             x0, [fp, #0x10]
    // 0x1277aac: LoadField: r2 = r0->field_97
    //     0x1277aac: ldur            w2, [x0, #0x97]
    // 0x1277ab0: DecompressPointer r2
    //     0x1277ab0: add             x2, x2, HEAP, lsl #32
    // 0x1277ab4: LoadField: r3 = r1->field_97
    //     0x1277ab4: ldur            w3, [x1, #0x97]
    // 0x1277ab8: DecompressPointer r3
    //     0x1277ab8: add             x3, x3, HEAP, lsl #32
    // 0x1277abc: stp             x3, x2, [SP]
    // 0x1277ac0: r0 = ==()
    //     0x1277ac0: bl              #0x1263f34  ; [package:flutter/src/material/badge_theme.dart] BadgeThemeData::==
    // 0x1277ac4: tbnz            w0, #4, #0x1278238
    // 0x1277ac8: ldr             x1, [fp, #0x18]
    // 0x1277acc: ldr             x0, [fp, #0x10]
    // 0x1277ad0: LoadField: r2 = r0->field_9b
    //     0x1277ad0: ldur            w2, [x0, #0x9b]
    // 0x1277ad4: DecompressPointer r2
    //     0x1277ad4: add             x2, x2, HEAP, lsl #32
    // 0x1277ad8: LoadField: r3 = r1->field_9b
    //     0x1277ad8: ldur            w3, [x1, #0x9b]
    // 0x1277adc: DecompressPointer r3
    //     0x1277adc: add             x3, x3, HEAP, lsl #32
    // 0x1277ae0: stp             x3, x2, [SP]
    // 0x1277ae4: r0 = ==()
    //     0x1277ae4: bl              #0x1264070  ; [package:flutter/src/material/banner_theme.dart] MaterialBannerThemeData::==
    // 0x1277ae8: tbnz            w0, #4, #0x1278238
    // 0x1277aec: ldr             x1, [fp, #0x18]
    // 0x1277af0: ldr             x0, [fp, #0x10]
    // 0x1277af4: LoadField: r2 = r0->field_9f
    //     0x1277af4: ldur            w2, [x0, #0x9f]
    // 0x1277af8: DecompressPointer r2
    //     0x1277af8: add             x2, x2, HEAP, lsl #32
    // 0x1277afc: LoadField: r3 = r1->field_9f
    //     0x1277afc: ldur            w3, [x1, #0x9f]
    // 0x1277b00: DecompressPointer r3
    //     0x1277b00: add             x3, x3, HEAP, lsl #32
    // 0x1277b04: stp             x3, x2, [SP]
    // 0x1277b08: r0 = ==()
    //     0x1277b08: bl              #0x1264174  ; [package:flutter/src/material/bottom_app_bar_theme.dart] BottomAppBarThemeData::==
    // 0x1277b0c: tbnz            w0, #4, #0x1278238
    // 0x1277b10: ldr             x1, [fp, #0x18]
    // 0x1277b14: ldr             x0, [fp, #0x10]
    // 0x1277b18: LoadField: r2 = r0->field_a3
    //     0x1277b18: ldur            w2, [x0, #0xa3]
    // 0x1277b1c: DecompressPointer r2
    //     0x1277b1c: add             x2, x2, HEAP, lsl #32
    // 0x1277b20: LoadField: r3 = r1->field_a3
    //     0x1277b20: ldur            w3, [x1, #0xa3]
    // 0x1277b24: DecompressPointer r3
    //     0x1277b24: add             x3, x3, HEAP, lsl #32
    // 0x1277b28: stp             x3, x2, [SP]
    // 0x1277b2c: r0 = ==()
    //     0x1277b2c: bl              #0x1264614  ; [package:flutter/src/material/bottom_navigation_bar_theme.dart] BottomNavigationBarThemeData::==
    // 0x1277b30: tbnz            w0, #4, #0x1278238
    // 0x1277b34: ldr             x1, [fp, #0x18]
    // 0x1277b38: ldr             x0, [fp, #0x10]
    // 0x1277b3c: LoadField: r2 = r0->field_a7
    //     0x1277b3c: ldur            w2, [x0, #0xa7]
    // 0x1277b40: DecompressPointer r2
    //     0x1277b40: add             x2, x2, HEAP, lsl #32
    // 0x1277b44: LoadField: r3 = r1->field_a7
    //     0x1277b44: ldur            w3, [x1, #0xa7]
    // 0x1277b48: DecompressPointer r3
    //     0x1277b48: add             x3, x3, HEAP, lsl #32
    // 0x1277b4c: stp             x3, x2, [SP]
    // 0x1277b50: r0 = ==()
    //     0x1277b50: bl              #0x1264788  ; [package:flutter/src/material/bottom_sheet_theme.dart] BottomSheetThemeData::==
    // 0x1277b54: tbnz            w0, #4, #0x1278238
    // 0x1277b58: ldr             x1, [fp, #0x18]
    // 0x1277b5c: ldr             x0, [fp, #0x10]
    // 0x1277b60: LoadField: r2 = r0->field_ab
    //     0x1277b60: ldur            w2, [x0, #0xab]
    // 0x1277b64: DecompressPointer r2
    //     0x1277b64: add             x2, x2, HEAP, lsl #32
    // 0x1277b68: LoadField: r3 = r1->field_ab
    //     0x1277b68: ldur            w3, [x1, #0xab]
    // 0x1277b6c: DecompressPointer r3
    //     0x1277b6c: add             x3, x3, HEAP, lsl #32
    // 0x1277b70: stp             x3, x2, [SP]
    // 0x1277b74: r0 = ==()
    //     0x1277b74: bl              #0x12657f0  ; [package:flutter/src/material/button_theme.dart] ButtonThemeData::==
    // 0x1277b78: tbnz            w0, #4, #0x1278238
    // 0x1277b7c: ldr             x1, [fp, #0x18]
    // 0x1277b80: ldr             x0, [fp, #0x10]
    // 0x1277b84: LoadField: r2 = r0->field_af
    //     0x1277b84: ldur            w2, [x0, #0xaf]
    // 0x1277b88: DecompressPointer r2
    //     0x1277b88: add             x2, x2, HEAP, lsl #32
    // 0x1277b8c: LoadField: r3 = r1->field_af
    //     0x1277b8c: ldur            w3, [x1, #0xaf]
    // 0x1277b90: DecompressPointer r3
    //     0x1277b90: add             x3, x3, HEAP, lsl #32
    // 0x1277b94: stp             x3, x2, [SP]
    // 0x1277b98: r0 = ==()
    //     0x1277b98: bl              #0x1265ac0  ; [package:flutter/src/material/card_theme.dart] CardThemeData::==
    // 0x1277b9c: tbnz            w0, #4, #0x1278238
    // 0x1277ba0: ldr             x1, [fp, #0x18]
    // 0x1277ba4: ldr             x0, [fp, #0x10]
    // 0x1277ba8: LoadField: r2 = r0->field_b3
    //     0x1277ba8: ldur            w2, [x0, #0xb3]
    // 0x1277bac: DecompressPointer r2
    //     0x1277bac: add             x2, x2, HEAP, lsl #32
    // 0x1277bb0: LoadField: r3 = r1->field_b3
    //     0x1277bb0: ldur            w3, [x1, #0xb3]
    // 0x1277bb4: DecompressPointer r3
    //     0x1277bb4: add             x3, x3, HEAP, lsl #32
    // 0x1277bb8: stp             x3, x2, [SP]
    // 0x1277bbc: r0 = ==()
    //     0x1277bbc: bl              #0x1265d94  ; [package:flutter/src/material/carousel_theme.dart] CarouselViewThemeData::==
    // 0x1277bc0: tbnz            w0, #4, #0x1278238
    // 0x1277bc4: ldr             x1, [fp, #0x18]
    // 0x1277bc8: ldr             x0, [fp, #0x10]
    // 0x1277bcc: LoadField: r2 = r0->field_b7
    //     0x1277bcc: ldur            w2, [x0, #0xb7]
    // 0x1277bd0: DecompressPointer r2
    //     0x1277bd0: add             x2, x2, HEAP, lsl #32
    // 0x1277bd4: LoadField: r3 = r1->field_b7
    //     0x1277bd4: ldur            w3, [x1, #0xb7]
    // 0x1277bd8: DecompressPointer r3
    //     0x1277bd8: add             x3, x3, HEAP, lsl #32
    // 0x1277bdc: stp             x3, x2, [SP]
    // 0x1277be0: r0 = ==()
    //     0x1277be0: bl              #0x1265e98  ; [package:flutter/src/material/checkbox_theme.dart] CheckboxThemeData::==
    // 0x1277be4: tbnz            w0, #4, #0x1278238
    // 0x1277be8: ldr             x1, [fp, #0x18]
    // 0x1277bec: ldr             x0, [fp, #0x10]
    // 0x1277bf0: LoadField: r2 = r0->field_bb
    //     0x1277bf0: ldur            w2, [x0, #0xbb]
    // 0x1277bf4: DecompressPointer r2
    //     0x1277bf4: add             x2, x2, HEAP, lsl #32
    // 0x1277bf8: LoadField: r3 = r1->field_bb
    //     0x1277bf8: ldur            w3, [x1, #0xbb]
    // 0x1277bfc: DecompressPointer r3
    //     0x1277bfc: add             x3, x3, HEAP, lsl #32
    // 0x1277c00: stp             x3, x2, [SP]
    // 0x1277c04: r0 = ==()
    //     0x1277c04: bl              #0x12668bc  ; [package:flutter/src/material/chip_theme.dart] ChipThemeData::==
    // 0x1277c08: tbnz            w0, #4, #0x1278238
    // 0x1277c0c: ldr             x1, [fp, #0x18]
    // 0x1277c10: ldr             x0, [fp, #0x10]
    // 0x1277c14: LoadField: r2 = r0->field_bf
    //     0x1277c14: ldur            w2, [x0, #0xbf]
    // 0x1277c18: DecompressPointer r2
    //     0x1277c18: add             x2, x2, HEAP, lsl #32
    // 0x1277c1c: LoadField: r3 = r1->field_bf
    //     0x1277c1c: ldur            w3, [x1, #0xbf]
    // 0x1277c20: DecompressPointer r3
    //     0x1277c20: add             x3, x3, HEAP, lsl #32
    // 0x1277c24: stp             x3, x2, [SP]
    // 0x1277c28: r0 = ==()
    //     0x1277c28: bl              #0x126791c  ; [package:flutter/src/material/data_table_theme.dart] DataTableThemeData::==
    // 0x1277c2c: tbnz            w0, #4, #0x1278238
    // 0x1277c30: ldr             x1, [fp, #0x18]
    // 0x1277c34: ldr             x0, [fp, #0x10]
    // 0x1277c38: LoadField: r2 = r0->field_c3
    //     0x1277c38: ldur            w2, [x0, #0xc3]
    // 0x1277c3c: DecompressPointer r2
    //     0x1277c3c: add             x2, x2, HEAP, lsl #32
    // 0x1277c40: LoadField: r3 = r1->field_c3
    //     0x1277c40: ldur            w3, [x1, #0xc3]
    // 0x1277c44: DecompressPointer r3
    //     0x1277c44: add             x3, x3, HEAP, lsl #32
    // 0x1277c48: stp             x3, x2, [SP]
    // 0x1277c4c: r0 = ==()
    //     0x1277c4c: bl              #0x1267b70  ; [package:flutter/src/material/date_picker_theme.dart] DatePickerThemeData::==
    // 0x1277c50: tbnz            w0, #4, #0x1278238
    // 0x1277c54: ldr             x1, [fp, #0x18]
    // 0x1277c58: ldr             x0, [fp, #0x10]
    // 0x1277c5c: LoadField: r2 = r0->field_c7
    //     0x1277c5c: ldur            w2, [x0, #0xc7]
    // 0x1277c60: DecompressPointer r2
    //     0x1277c60: add             x2, x2, HEAP, lsl #32
    // 0x1277c64: LoadField: r3 = r1->field_c7
    //     0x1277c64: ldur            w3, [x1, #0xc7]
    // 0x1277c68: DecompressPointer r3
    //     0x1277c68: add             x3, x3, HEAP, lsl #32
    // 0x1277c6c: stp             x3, x2, [SP]
    // 0x1277c70: r0 = ==()
    //     0x1277c70: bl              #0x126aaf0  ; [package:flutter/src/material/dialog_theme.dart] DialogThemeData::==
    // 0x1277c74: tbnz            w0, #4, #0x1278238
    // 0x1277c78: ldr             x1, [fp, #0x18]
    // 0x1277c7c: ldr             x0, [fp, #0x10]
    // 0x1277c80: LoadField: r2 = r0->field_cb
    //     0x1277c80: ldur            w2, [x0, #0xcb]
    // 0x1277c84: DecompressPointer r2
    //     0x1277c84: add             x2, x2, HEAP, lsl #32
    // 0x1277c88: LoadField: r3 = r1->field_cb
    //     0x1277c88: ldur            w3, [x1, #0xcb]
    // 0x1277c8c: DecompressPointer r3
    //     0x1277c8c: add             x3, x3, HEAP, lsl #32
    // 0x1277c90: stp             x3, x2, [SP]
    // 0x1277c94: r0 = ==()
    //     0x1277c94: bl              #0x126b5b0  ; [package:flutter/src/material/divider_theme.dart] DividerThemeData::==
    // 0x1277c98: tbnz            w0, #4, #0x1278238
    // 0x1277c9c: ldr             x1, [fp, #0x18]
    // 0x1277ca0: ldr             x0, [fp, #0x10]
    // 0x1277ca4: LoadField: r2 = r0->field_cf
    //     0x1277ca4: ldur            w2, [x0, #0xcf]
    // 0x1277ca8: DecompressPointer r2
    //     0x1277ca8: add             x2, x2, HEAP, lsl #32
    // 0x1277cac: LoadField: r3 = r1->field_cf
    //     0x1277cac: ldur            w3, [x1, #0xcf]
    // 0x1277cb0: DecompressPointer r3
    //     0x1277cb0: add             x3, x3, HEAP, lsl #32
    // 0x1277cb4: stp             x3, x2, [SP]
    // 0x1277cb8: r0 = ==()
    //     0x1277cb8: bl              #0x126b888  ; [package:flutter/src/material/drawer_theme.dart] DrawerThemeData::==
    // 0x1277cbc: tbnz            w0, #4, #0x1278238
    // 0x1277cc0: ldr             x1, [fp, #0x18]
    // 0x1277cc4: ldr             x0, [fp, #0x10]
    // 0x1277cc8: LoadField: r2 = r0->field_d3
    //     0x1277cc8: ldur            w2, [x0, #0xd3]
    // 0x1277ccc: DecompressPointer r2
    //     0x1277ccc: add             x2, x2, HEAP, lsl #32
    // 0x1277cd0: LoadField: r3 = r1->field_d3
    //     0x1277cd0: ldur            w3, [x1, #0xd3]
    // 0x1277cd4: DecompressPointer r3
    //     0x1277cd4: add             x3, x3, HEAP, lsl #32
    // 0x1277cd8: stp             x3, x2, [SP]
    // 0x1277cdc: r0 = ==()
    //     0x1277cdc: bl              #0x126bef0  ; [package:flutter/src/material/dropdown_menu_theme.dart] DropdownMenuThemeData::==
    // 0x1277ce0: tbnz            w0, #4, #0x1278238
    // 0x1277ce4: ldr             x1, [fp, #0x18]
    // 0x1277ce8: ldr             x0, [fp, #0x10]
    // 0x1277cec: LoadField: r2 = r0->field_d7
    //     0x1277cec: ldur            w2, [x0, #0xd7]
    // 0x1277cf0: DecompressPointer r2
    //     0x1277cf0: add             x2, x2, HEAP, lsl #32
    // 0x1277cf4: LoadField: r3 = r1->field_d7
    //     0x1277cf4: ldur            w3, [x1, #0xd7]
    // 0x1277cf8: DecompressPointer r3
    //     0x1277cf8: add             x3, x3, HEAP, lsl #32
    // 0x1277cfc: stp             x3, x2, [SP]
    // 0x1277d00: r0 = ==()
    //     0x1277d00: bl              #0x126bff4  ; [package:flutter/src/material/elevated_button_theme.dart] ElevatedButtonThemeData::==
    // 0x1277d04: tbnz            w0, #4, #0x1278238
    // 0x1277d08: ldr             x1, [fp, #0x18]
    // 0x1277d0c: ldr             x0, [fp, #0x10]
    // 0x1277d10: LoadField: r2 = r0->field_db
    //     0x1277d10: ldur            w2, [x0, #0xdb]
    // 0x1277d14: DecompressPointer r2
    //     0x1277d14: add             x2, x2, HEAP, lsl #32
    // 0x1277d18: LoadField: r3 = r1->field_db
    //     0x1277d18: ldur            w3, [x1, #0xdb]
    // 0x1277d1c: DecompressPointer r3
    //     0x1277d1c: add             x3, x3, HEAP, lsl #32
    // 0x1277d20: stp             x3, x2, [SP]
    // 0x1277d24: r0 = ==()
    //     0x1277d24: bl              #0x126c0f0  ; [package:flutter/src/material/expansion_tile_theme.dart] ExpansionTileThemeData::==
    // 0x1277d28: tbnz            w0, #4, #0x1278238
    // 0x1277d2c: ldr             x1, [fp, #0x18]
    // 0x1277d30: ldr             x0, [fp, #0x10]
    // 0x1277d34: LoadField: r2 = r0->field_df
    //     0x1277d34: ldur            w2, [x0, #0xdf]
    // 0x1277d38: DecompressPointer r2
    //     0x1277d38: add             x2, x2, HEAP, lsl #32
    // 0x1277d3c: LoadField: r3 = r1->field_df
    //     0x1277d3c: ldur            w3, [x1, #0xdf]
    // 0x1277d40: DecompressPointer r3
    //     0x1277d40: add             x3, x3, HEAP, lsl #32
    // 0x1277d44: stp             x3, x2, [SP]
    // 0x1277d48: r0 = ==()
    //     0x1277d48: bl              #0x126c73c  ; [package:flutter/src/material/filled_button_theme.dart] FilledButtonThemeData::==
    // 0x1277d4c: tbnz            w0, #4, #0x1278238
    // 0x1277d50: ldr             x1, [fp, #0x18]
    // 0x1277d54: ldr             x0, [fp, #0x10]
    // 0x1277d58: LoadField: r2 = r0->field_e3
    //     0x1277d58: ldur            w2, [x0, #0xe3]
    // 0x1277d5c: DecompressPointer r2
    //     0x1277d5c: add             x2, x2, HEAP, lsl #32
    // 0x1277d60: LoadField: r3 = r1->field_e3
    //     0x1277d60: ldur            w3, [x1, #0xe3]
    // 0x1277d64: DecompressPointer r3
    //     0x1277d64: add             x3, x3, HEAP, lsl #32
    // 0x1277d68: stp             x3, x2, [SP]
    // 0x1277d6c: r0 = ==()
    //     0x1277d6c: bl              #0x126c838  ; [package:flutter/src/material/floating_action_button_theme.dart] FloatingActionButtonThemeData::==
    // 0x1277d70: tbnz            w0, #4, #0x1278238
    // 0x1277d74: ldr             x1, [fp, #0x18]
    // 0x1277d78: ldr             x0, [fp, #0x10]
    // 0x1277d7c: LoadField: r2 = r0->field_e7
    //     0x1277d7c: ldur            w2, [x0, #0xe7]
    // 0x1277d80: DecompressPointer r2
    //     0x1277d80: add             x2, x2, HEAP, lsl #32
    // 0x1277d84: LoadField: r3 = r1->field_e7
    //     0x1277d84: ldur            w3, [x1, #0xe7]
    // 0x1277d88: DecompressPointer r3
    //     0x1277d88: add             x3, x3, HEAP, lsl #32
    // 0x1277d8c: stp             x3, x2, [SP]
    // 0x1277d90: r0 = ==()
    //     0x1277d90: bl              #0x126d7dc  ; [package:flutter/src/material/icon_button_theme.dart] IconButtonThemeData::==
    // 0x1277d94: tbnz            w0, #4, #0x1278238
    // 0x1277d98: ldr             x1, [fp, #0x18]
    // 0x1277d9c: ldr             x0, [fp, #0x10]
    // 0x1277da0: LoadField: r2 = r0->field_eb
    //     0x1277da0: ldur            w2, [x0, #0xeb]
    // 0x1277da4: DecompressPointer r2
    //     0x1277da4: add             x2, x2, HEAP, lsl #32
    // 0x1277da8: LoadField: r3 = r1->field_eb
    //     0x1277da8: ldur            w3, [x1, #0xeb]
    // 0x1277dac: DecompressPointer r3
    //     0x1277dac: add             x3, x3, HEAP, lsl #32
    // 0x1277db0: stp             x3, x2, [SP]
    // 0x1277db4: r0 = ==()
    //     0x1277db4: bl              #0x126ec80  ; [package:flutter/src/material/list_tile_theme.dart] ListTileThemeData::==
    // 0x1277db8: tbnz            w0, #4, #0x1278238
    // 0x1277dbc: ldr             x1, [fp, #0x18]
    // 0x1277dc0: ldr             x0, [fp, #0x10]
    // 0x1277dc4: LoadField: r2 = r0->field_ef
    //     0x1277dc4: ldur            w2, [x0, #0xef]
    // 0x1277dc8: DecompressPointer r2
    //     0x1277dc8: add             x2, x2, HEAP, lsl #32
    // 0x1277dcc: LoadField: r3 = r1->field_ef
    //     0x1277dcc: ldur            w3, [x1, #0xef]
    // 0x1277dd0: DecompressPointer r3
    //     0x1277dd0: add             x3, x3, HEAP, lsl #32
    // 0x1277dd4: stp             x3, x2, [SP]
    // 0x1277dd8: r0 = ==()
    //     0x1277dd8: bl              #0x126fa34  ; [package:flutter/src/material/menu_theme.dart] MenuThemeData::==
    // 0x1277ddc: tbnz            w0, #4, #0x1278238
    // 0x1277de0: ldr             x1, [fp, #0x18]
    // 0x1277de4: ldr             x0, [fp, #0x10]
    // 0x1277de8: LoadField: r2 = r0->field_f3
    //     0x1277de8: ldur            w2, [x0, #0xf3]
    // 0x1277dec: DecompressPointer r2
    //     0x1277dec: add             x2, x2, HEAP, lsl #32
    // 0x1277df0: LoadField: r3 = r1->field_f3
    //     0x1277df0: ldur            w3, [x1, #0xf3]
    // 0x1277df4: DecompressPointer r3
    //     0x1277df4: add             x3, x3, HEAP, lsl #32
    // 0x1277df8: stp             x3, x2, [SP]
    // 0x1277dfc: r0 = ==()
    //     0x1277dfc: bl              #0x126fb18  ; [package:flutter/src/material/menu_button_theme.dart] MenuButtonThemeData::==
    // 0x1277e00: tbnz            w0, #4, #0x1278238
    // 0x1277e04: ldr             x1, [fp, #0x18]
    // 0x1277e08: ldr             x0, [fp, #0x10]
    // 0x1277e0c: LoadField: r2 = r0->field_f7
    //     0x1277e0c: ldur            w2, [x0, #0xf7]
    // 0x1277e10: DecompressPointer r2
    //     0x1277e10: add             x2, x2, HEAP, lsl #32
    // 0x1277e14: LoadField: r3 = r1->field_f7
    //     0x1277e14: ldur            w3, [x1, #0xf7]
    // 0x1277e18: DecompressPointer r3
    //     0x1277e18: add             x3, x3, HEAP, lsl #32
    // 0x1277e1c: stp             x3, x2, [SP]
    // 0x1277e20: r0 = ==()
    //     0x1277e20: bl              #0x126fa34  ; [package:flutter/src/material/menu_theme.dart] MenuThemeData::==
    // 0x1277e24: tbnz            w0, #4, #0x1278238
    // 0x1277e28: ldr             x1, [fp, #0x18]
    // 0x1277e2c: ldr             x0, [fp, #0x10]
    // 0x1277e30: LoadField: r2 = r0->field_fb
    //     0x1277e30: ldur            w2, [x0, #0xfb]
    // 0x1277e34: DecompressPointer r2
    //     0x1277e34: add             x2, x2, HEAP, lsl #32
    // 0x1277e38: LoadField: r3 = r1->field_fb
    //     0x1277e38: ldur            w3, [x1, #0xfb]
    // 0x1277e3c: DecompressPointer r3
    //     0x1277e3c: add             x3, x3, HEAP, lsl #32
    // 0x1277e40: stp             x3, x2, [SP]
    // 0x1277e44: r0 = ==()
    //     0x1277e44: bl              #0x126fce4  ; [package:flutter/src/material/navigation_bar_theme.dart] NavigationBarThemeData::==
    // 0x1277e48: tbnz            w0, #4, #0x1278238
    // 0x1277e4c: ldr             x1, [fp, #0x18]
    // 0x1277e50: ldr             x0, [fp, #0x10]
    // 0x1277e54: LoadField: r2 = r0->field_ff
    //     0x1277e54: ldur            w2, [x0, #0xff]
    // 0x1277e58: DecompressPointer r2
    //     0x1277e58: add             x2, x2, HEAP, lsl #32
    // 0x1277e5c: LoadField: r3 = r1->field_ff
    //     0x1277e5c: ldur            w3, [x1, #0xff]
    // 0x1277e60: DecompressPointer r3
    //     0x1277e60: add             x3, x3, HEAP, lsl #32
    // 0x1277e64: stp             x3, x2, [SP]
    // 0x1277e68: r0 = ==()
    //     0x1277e68: bl              #0x126fe20  ; [package:flutter/src/material/navigation_drawer_theme.dart] NavigationDrawerThemeData::==
    // 0x1277e6c: tbnz            w0, #4, #0x1278238
    // 0x1277e70: ldr             x1, [fp, #0x18]
    // 0x1277e74: ldr             x0, [fp, #0x10]
    // 0x1277e78: r17 = 259
    //     0x1277e78: mov             x17, #0x103
    // 0x1277e7c: ldr             w2, [x0, x17]
    // 0x1277e80: DecompressPointer r2
    //     0x1277e80: add             x2, x2, HEAP, lsl #32
    // 0x1277e84: r17 = 259
    //     0x1277e84: mov             x17, #0x103
    // 0x1277e88: ldr             w3, [x1, x17]
    // 0x1277e8c: DecompressPointer r3
    //     0x1277e8c: add             x3, x3, HEAP, lsl #32
    // 0x1277e90: stp             x3, x2, [SP]
    // 0x1277e94: r0 = ==()
    //     0x1277e94: bl              #0x126ff5c  ; [package:flutter/src/material/navigation_rail_theme.dart] NavigationRailThemeData::==
    // 0x1277e98: tbnz            w0, #4, #0x1278238
    // 0x1277e9c: ldr             x1, [fp, #0x18]
    // 0x1277ea0: ldr             x0, [fp, #0x10]
    // 0x1277ea4: r17 = 263
    //     0x1277ea4: mov             x17, #0x107
    // 0x1277ea8: ldr             w2, [x0, x17]
    // 0x1277eac: DecompressPointer r2
    //     0x1277eac: add             x2, x2, HEAP, lsl #32
    // 0x1277eb0: r17 = 263
    //     0x1277eb0: mov             x17, #0x107
    // 0x1277eb4: ldr             w3, [x1, x17]
    // 0x1277eb8: DecompressPointer r3
    //     0x1277eb8: add             x3, x3, HEAP, lsl #32
    // 0x1277ebc: stp             x3, x2, [SP]
    // 0x1277ec0: r0 = ==()
    //     0x1277ec0: bl              #0x1270100  ; [package:flutter/src/material/outlined_button_theme.dart] OutlinedButtonThemeData::==
    // 0x1277ec4: tbnz            w0, #4, #0x1278238
    // 0x1277ec8: ldr             x1, [fp, #0x18]
    // 0x1277ecc: ldr             x0, [fp, #0x10]
    // 0x1277ed0: r17 = 267
    //     0x1277ed0: mov             x17, #0x10b
    // 0x1277ed4: ldr             w2, [x0, x17]
    // 0x1277ed8: DecompressPointer r2
    //     0x1277ed8: add             x2, x2, HEAP, lsl #32
    // 0x1277edc: r17 = 267
    //     0x1277edc: mov             x17, #0x10b
    // 0x1277ee0: ldr             w3, [x1, x17]
    // 0x1277ee4: DecompressPointer r3
    //     0x1277ee4: add             x3, x3, HEAP, lsl #32
    // 0x1277ee8: stp             x3, x2, [SP]
    // 0x1277eec: r0 = ==()
    //     0x1277eec: bl              #0x1270314  ; [package:flutter/src/material/popup_menu_theme.dart] PopupMenuThemeData::==
    // 0x1277ef0: tbnz            w0, #4, #0x1278238
    // 0x1277ef4: ldr             x1, [fp, #0x18]
    // 0x1277ef8: ldr             x0, [fp, #0x10]
    // 0x1277efc: r17 = 271
    //     0x1277efc: mov             x17, #0x10f
    // 0x1277f00: ldr             w2, [x0, x17]
    // 0x1277f04: DecompressPointer r2
    //     0x1277f04: add             x2, x2, HEAP, lsl #32
    // 0x1277f08: r17 = 271
    //     0x1277f08: mov             x17, #0x10f
    // 0x1277f0c: ldr             w3, [x1, x17]
    // 0x1277f10: DecompressPointer r3
    //     0x1277f10: add             x3, x3, HEAP, lsl #32
    // 0x1277f14: stp             x3, x2, [SP]
    // 0x1277f18: r0 = ==()
    //     0x1277f18: bl              #0x1270a1c  ; [package:flutter/src/material/progress_indicator_theme.dart] ProgressIndicatorThemeData::==
    // 0x1277f1c: tbnz            w0, #4, #0x1278238
    // 0x1277f20: ldr             x1, [fp, #0x18]
    // 0x1277f24: ldr             x0, [fp, #0x10]
    // 0x1277f28: r17 = 275
    //     0x1277f28: mov             x17, #0x113
    // 0x1277f2c: ldr             w2, [x0, x17]
    // 0x1277f30: DecompressPointer r2
    //     0x1277f30: add             x2, x2, HEAP, lsl #32
    // 0x1277f34: r17 = 275
    //     0x1277f34: mov             x17, #0x113
    // 0x1277f38: ldr             w3, [x1, x17]
    // 0x1277f3c: DecompressPointer r3
    //     0x1277f3c: add             x3, x3, HEAP, lsl #32
    // 0x1277f40: stp             x3, x2, [SP]
    // 0x1277f44: r0 = ==()
    //     0x1277f44: bl              #0x1270fa8  ; [package:flutter/src/material/radio_theme.dart] RadioThemeData::==
    // 0x1277f48: tbnz            w0, #4, #0x1278238
    // 0x1277f4c: ldr             x1, [fp, #0x18]
    // 0x1277f50: ldr             x0, [fp, #0x10]
    // 0x1277f54: r17 = 279
    //     0x1277f54: mov             x17, #0x117
    // 0x1277f58: ldr             w2, [x0, x17]
    // 0x1277f5c: DecompressPointer r2
    //     0x1277f5c: add             x2, x2, HEAP, lsl #32
    // 0x1277f60: r17 = 279
    //     0x1277f60: mov             x17, #0x117
    // 0x1277f64: ldr             w3, [x1, x17]
    // 0x1277f68: DecompressPointer r3
    //     0x1277f68: add             x3, x3, HEAP, lsl #32
    // 0x1277f6c: cmp             w2, w3
    // 0x1277f70: b.eq            #0x1277f98
    // 0x1277f74: r16 = SearchBarThemeData
    //     0x1277f74: add             x16, PP, #0x26, lsl #12  ; [pp+0x26268] Type: SearchBarThemeData
    //     0x1277f78: ldr             x16, [x16, #0x268]
    // 0x1277f7c: r30 = SearchBarThemeData
    //     0x1277f7c: add             lr, PP, #0x26, lsl #12  ; [pp+0x26268] Type: SearchBarThemeData
    //     0x1277f80: ldr             lr, [lr, #0x268]
    // 0x1277f84: stp             lr, x16, [SP]
    // 0x1277f88: r0 = ==()
    //     0x1277f88: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x1277f8c: tbnz            w0, #4, #0x1278238
    // 0x1277f90: ldr             x1, [fp, #0x18]
    // 0x1277f94: ldr             x0, [fp, #0x10]
    // 0x1277f98: r17 = 283
    //     0x1277f98: mov             x17, #0x11b
    // 0x1277f9c: ldr             w2, [x0, x17]
    // 0x1277fa0: DecompressPointer r2
    //     0x1277fa0: add             x2, x2, HEAP, lsl #32
    // 0x1277fa4: r17 = 283
    //     0x1277fa4: mov             x17, #0x11b
    // 0x1277fa8: ldr             w3, [x1, x17]
    // 0x1277fac: DecompressPointer r3
    //     0x1277fac: add             x3, x3, HEAP, lsl #32
    // 0x1277fb0: stp             x3, x2, [SP]
    // 0x1277fb4: r0 = ==()
    //     0x1277fb4: bl              #0x1271954  ; [package:flutter/src/material/search_view_theme.dart] SearchViewThemeData::==
    // 0x1277fb8: tbnz            w0, #4, #0x1278238
    // 0x1277fbc: ldr             x1, [fp, #0x18]
    // 0x1277fc0: ldr             x0, [fp, #0x10]
    // 0x1277fc4: r17 = 287
    //     0x1277fc4: mov             x17, #0x11f
    // 0x1277fc8: ldr             w2, [x0, x17]
    // 0x1277fcc: DecompressPointer r2
    //     0x1277fcc: add             x2, x2, HEAP, lsl #32
    // 0x1277fd0: r17 = 287
    //     0x1277fd0: mov             x17, #0x11f
    // 0x1277fd4: ldr             w3, [x1, x17]
    // 0x1277fd8: DecompressPointer r3
    //     0x1277fd8: add             x3, x3, HEAP, lsl #32
    // 0x1277fdc: stp             x3, x2, [SP]
    // 0x1277fe0: r0 = ==()
    //     0x1277fe0: bl              #0x1271a90  ; [package:flutter/src/material/segmented_button_theme.dart] SegmentedButtonThemeData::==
    // 0x1277fe4: tbnz            w0, #4, #0x1278238
    // 0x1277fe8: ldr             x1, [fp, #0x18]
    // 0x1277fec: ldr             x0, [fp, #0x10]
    // 0x1277ff0: r17 = 291
    //     0x1277ff0: mov             x17, #0x123
    // 0x1277ff4: ldr             w2, [x0, x17]
    // 0x1277ff8: DecompressPointer r2
    //     0x1277ff8: add             x2, x2, HEAP, lsl #32
    // 0x1277ffc: r17 = 291
    //     0x1277ffc: mov             x17, #0x123
    // 0x1278000: ldr             w3, [x1, x17]
    // 0x1278004: DecompressPointer r3
    //     0x1278004: add             x3, x3, HEAP, lsl #32
    // 0x1278008: stp             x3, x2, [SP]
    // 0x127800c: r0 = ==()
    //     0x127800c: bl              #0x1271b94  ; [package:flutter/src/material/slider_theme.dart] SliderThemeData::==
    // 0x1278010: tbnz            w0, #4, #0x1278238
    // 0x1278014: ldr             x1, [fp, #0x18]
    // 0x1278018: ldr             x0, [fp, #0x10]
    // 0x127801c: r17 = 295
    //     0x127801c: mov             x17, #0x127
    // 0x1278020: ldr             w2, [x0, x17]
    // 0x1278024: DecompressPointer r2
    //     0x1278024: add             x2, x2, HEAP, lsl #32
    // 0x1278028: r17 = 295
    //     0x1278028: mov             x17, #0x127
    // 0x127802c: ldr             w3, [x1, x17]
    // 0x1278030: DecompressPointer r3
    //     0x1278030: add             x3, x3, HEAP, lsl #32
    // 0x1278034: stp             x3, x2, [SP]
    // 0x1278038: r0 = ==()
    //     0x1278038: bl              #0x1274308  ; [package:flutter/src/material/snack_bar_theme.dart] SnackBarThemeData::==
    // 0x127803c: tbnz            w0, #4, #0x1278238
    // 0x1278040: ldr             x1, [fp, #0x18]
    // 0x1278044: ldr             x0, [fp, #0x10]
    // 0x1278048: r17 = 299
    //     0x1278048: mov             x17, #0x12b
    // 0x127804c: ldr             w2, [x0, x17]
    // 0x1278050: DecompressPointer r2
    //     0x1278050: add             x2, x2, HEAP, lsl #32
    // 0x1278054: r17 = 299
    //     0x1278054: mov             x17, #0x12b
    // 0x1278058: ldr             w3, [x1, x17]
    // 0x127805c: DecompressPointer r3
    //     0x127805c: add             x3, x3, HEAP, lsl #32
    // 0x1278060: stp             x3, x2, [SP]
    // 0x1278064: r0 = ==()
    //     0x1278064: bl              #0x1275104  ; [package:flutter/src/material/switch_theme.dart] SwitchThemeData::==
    // 0x1278068: tbnz            w0, #4, #0x1278238
    // 0x127806c: ldr             x1, [fp, #0x18]
    // 0x1278070: ldr             x0, [fp, #0x10]
    // 0x1278074: r17 = 303
    //     0x1278074: mov             x17, #0x12f
    // 0x1278078: ldr             w2, [x0, x17]
    // 0x127807c: DecompressPointer r2
    //     0x127807c: add             x2, x2, HEAP, lsl #32
    // 0x1278080: r17 = 303
    //     0x1278080: mov             x17, #0x12f
    // 0x1278084: ldr             w3, [x1, x17]
    // 0x1278088: DecompressPointer r3
    //     0x1278088: add             x3, x3, HEAP, lsl #32
    // 0x127808c: stp             x3, x2, [SP]
    // 0x1278090: r0 = ==()
    //     0x1278090: bl              #0x1275e30  ; [package:flutter/src/material/tab_bar_theme.dart] TabBarThemeData::==
    // 0x1278094: tbnz            w0, #4, #0x1278238
    // 0x1278098: ldr             x1, [fp, #0x18]
    // 0x127809c: ldr             x0, [fp, #0x10]
    // 0x12780a0: r17 = 307
    //     0x12780a0: mov             x17, #0x133
    // 0x12780a4: ldr             w2, [x0, x17]
    // 0x12780a8: DecompressPointer r2
    //     0x12780a8: add             x2, x2, HEAP, lsl #32
    // 0x12780ac: r17 = 307
    //     0x12780ac: mov             x17, #0x133
    // 0x12780b0: ldr             w3, [x1, x17]
    // 0x12780b4: DecompressPointer r3
    //     0x12780b4: add             x3, x3, HEAP, lsl #32
    // 0x12780b8: stp             x3, x2, [SP]
    // 0x12780bc: r0 = ==()
    //     0x12780bc: bl              #0x1276f2c  ; [package:flutter/src/material/text_button_theme.dart] TextButtonThemeData::==
    // 0x12780c0: tbnz            w0, #4, #0x1278238
    // 0x12780c4: ldr             x1, [fp, #0x18]
    // 0x12780c8: ldr             x0, [fp, #0x10]
    // 0x12780cc: r17 = 311
    //     0x12780cc: mov             x17, #0x137
    // 0x12780d0: ldr             w2, [x0, x17]
    // 0x12780d4: DecompressPointer r2
    //     0x12780d4: add             x2, x2, HEAP, lsl #32
    // 0x12780d8: r17 = 311
    //     0x12780d8: mov             x17, #0x137
    // 0x12780dc: ldr             w3, [x1, x17]
    // 0x12780e0: DecompressPointer r3
    //     0x12780e0: add             x3, x3, HEAP, lsl #32
    // 0x12780e4: cmp             w2, w3
    // 0x12780e8: b.eq            #0x1278110
    // 0x12780ec: r16 = TextSelectionThemeData
    //     0x12780ec: add             x16, PP, #0x26, lsl #12  ; [pp+0x260a0] Type: TextSelectionThemeData
    //     0x12780f0: ldr             x16, [x16, #0xa0]
    // 0x12780f4: r30 = TextSelectionThemeData
    //     0x12780f4: add             lr, PP, #0x26, lsl #12  ; [pp+0x260a0] Type: TextSelectionThemeData
    //     0x12780f8: ldr             lr, [lr, #0xa0]
    // 0x12780fc: stp             lr, x16, [SP]
    // 0x1278100: r0 = ==()
    //     0x1278100: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x1278104: tbnz            w0, #4, #0x1278238
    // 0x1278108: ldr             x1, [fp, #0x18]
    // 0x127810c: ldr             x0, [fp, #0x10]
    // 0x1278110: r17 = 315
    //     0x1278110: mov             x17, #0x13b
    // 0x1278114: ldr             w2, [x0, x17]
    // 0x1278118: DecompressPointer r2
    //     0x1278118: add             x2, x2, HEAP, lsl #32
    // 0x127811c: r17 = 315
    //     0x127811c: mov             x17, #0x13b
    // 0x1278120: ldr             w3, [x1, x17]
    // 0x1278124: DecompressPointer r3
    //     0x1278124: add             x3, x3, HEAP, lsl #32
    // 0x1278128: stp             x3, x2, [SP]
    // 0x127812c: r0 = ==()
    //     0x127812c: bl              #0x1278330  ; [package:flutter/src/material/time_picker_theme.dart] TimePickerThemeData::==
    // 0x1278130: tbnz            w0, #4, #0x1278238
    // 0x1278134: ldr             x1, [fp, #0x18]
    // 0x1278138: ldr             x0, [fp, #0x10]
    // 0x127813c: r17 = 319
    //     0x127813c: mov             x17, #0x13f
    // 0x1278140: ldr             w2, [x0, x17]
    // 0x1278144: DecompressPointer r2
    //     0x1278144: add             x2, x2, HEAP, lsl #32
    // 0x1278148: r17 = 319
    //     0x1278148: mov             x17, #0x13f
    // 0x127814c: ldr             w3, [x1, x17]
    // 0x1278150: DecompressPointer r3
    //     0x1278150: add             x3, x3, HEAP, lsl #32
    // 0x1278154: stp             x3, x2, [SP]
    // 0x1278158: r0 = ==()
    //     0x1278158: bl              #0x12784a4  ; [package:flutter/src/material/toggle_buttons_theme.dart] ToggleButtonsThemeData::==
    // 0x127815c: tbnz            w0, #4, #0x1278238
    // 0x1278160: ldr             x1, [fp, #0x18]
    // 0x1278164: ldr             x0, [fp, #0x10]
    // 0x1278168: r17 = 323
    //     0x1278168: mov             x17, #0x143
    // 0x127816c: ldr             w2, [x0, x17]
    // 0x1278170: DecompressPointer r2
    //     0x1278170: add             x2, x2, HEAP, lsl #32
    // 0x1278174: r17 = 323
    //     0x1278174: mov             x17, #0x143
    // 0x1278178: ldr             w3, [x1, x17]
    // 0x127817c: DecompressPointer r3
    //     0x127817c: add             x3, x3, HEAP, lsl #32
    // 0x1278180: stp             x3, x2, [SP]
    // 0x1278184: r0 = ==()
    //     0x1278184: bl              #0x12785a0  ; [package:flutter/src/material/tooltip_theme.dart] TooltipThemeData::==
    // 0x1278188: tbnz            w0, #4, #0x1278238
    // 0x127818c: ldr             x1, [fp, #0x18]
    // 0x1278190: ldr             x0, [fp, #0x10]
    // 0x1278194: r17 = 327
    //     0x1278194: mov             x17, #0x147
    // 0x1278198: ldr             w2, [x0, x17]
    // 0x127819c: DecompressPointer r2
    //     0x127819c: add             x2, x2, HEAP, lsl #32
    // 0x12781a0: r17 = 327
    //     0x12781a0: mov             x17, #0x147
    // 0x12781a4: ldr             w3, [x1, x17]
    // 0x12781a8: DecompressPointer r3
    //     0x12781a8: add             x3, x3, HEAP, lsl #32
    // 0x12781ac: stp             x3, x2, [SP]
    // 0x12781b0: r0 = ==()
    //     0x12781b0: bl              #0x1264cd0  ; [package:flutter/src/material/button_bar_theme.dart] ButtonBarThemeData::==
    // 0x12781b4: tbnz            w0, #4, #0x1278238
    // 0x12781b8: ldr             x2, [fp, #0x18]
    // 0x12781bc: ldr             x1, [fp, #0x10]
    // 0x12781c0: r17 = 331
    //     0x12781c0: mov             x17, #0x14b
    // 0x12781c4: ldr             w0, [x1, x17]
    // 0x12781c8: DecompressPointer r0
    //     0x12781c8: add             x0, x0, HEAP, lsl #32
    // 0x12781cc: r17 = 331
    //     0x12781cc: mov             x17, #0x14b
    // 0x12781d0: ldr             w3, [x2, x17]
    // 0x12781d4: DecompressPointer r3
    //     0x12781d4: add             x3, x3, HEAP, lsl #32
    // 0x12781d8: r4 = LoadClassIdInstr(r0)
    //     0x12781d8: ldur            x4, [x0, #-1]
    //     0x12781dc: ubfx            x4, x4, #0xc, #0x14
    // 0x12781e0: stp             x3, x0, [SP]
    // 0x12781e4: mov             x0, x4
    // 0x12781e8: mov             lr, x0
    // 0x12781ec: ldr             lr, [x21, lr, lsl #3]
    // 0x12781f0: blr             lr
    // 0x12781f4: tbnz            w0, #4, #0x1278238
    // 0x12781f8: ldr             x1, [fp, #0x18]
    // 0x12781fc: ldr             x0, [fp, #0x10]
    // 0x1278200: r17 = 335
    //     0x1278200: mov             x17, #0x14f
    // 0x1278204: ldr             w2, [x0, x17]
    // 0x1278208: DecompressPointer r2
    //     0x1278208: add             x2, x2, HEAP, lsl #32
    // 0x127820c: r17 = 335
    //     0x127820c: mov             x17, #0x14f
    // 0x1278210: ldr             w0, [x1, x17]
    // 0x1278214: DecompressPointer r0
    //     0x1278214: add             x0, x0, HEAP, lsl #32
    // 0x1278218: r1 = LoadClassIdInstr(r2)
    //     0x1278218: ldur            x1, [x2, #-1]
    //     0x127821c: ubfx            x1, x1, #0xc, #0x14
    // 0x1278220: stp             x0, x2, [SP]
    // 0x1278224: mov             x0, x1
    // 0x1278228: mov             lr, x0
    // 0x127822c: ldr             lr, [x21, lr, lsl #3]
    // 0x1278230: blr             lr
    // 0x1278234: b               #0x127823c
    // 0x1278238: r0 = false
    //     0x1278238: add             x0, NULL, #0x30  ; false
    // 0x127823c: LeaveFrame
    //     0x127823c: mov             SP, fp
    //     0x1278240: ldp             fp, lr, [SP], #0x10
    // 0x1278244: ret
    //     0x1278244: ret             
    // 0x1278248: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1278248: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x127824c: b               #0x12774dc
  }
}

// class id: 8255, size: 0x14, field offset: 0x14
enum MaterialTapTargetSize extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aab84, size: 0x64
    // 0x11aab84: EnterFrame
    //     0x11aab84: stp             fp, lr, [SP, #-0x10]!
    //     0x11aab88: mov             fp, SP
    // 0x11aab8c: AllocStack(0x10)
    //     0x11aab8c: sub             SP, SP, #0x10
    // 0x11aab90: SetupParameters(MaterialTapTargetSize this /* r1 => r0, fp-0x8 */)
    //     0x11aab90: mov             x0, x1
    //     0x11aab94: stur            x1, [fp, #-8]
    // 0x11aab98: CheckStackOverflow
    //     0x11aab98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aab9c: cmp             SP, x16
    //     0x11aaba0: b.ls            #0x11aabe0
    // 0x11aaba4: r1 = Null
    //     0x11aaba4: mov             x1, NULL
    // 0x11aaba8: r2 = 4
    //     0x11aaba8: mov             x2, #4
    // 0x11aabac: r0 = AllocateArray()
    //     0x11aabac: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aabb0: r16 = "MaterialTapTargetSize."
    //     0x11aabb0: add             x16, PP, #0x26, lsl #12  ; [pp+0x26b28] "MaterialTapTargetSize."
    //     0x11aabb4: ldr             x16, [x16, #0xb28]
    // 0x11aabb8: StoreField: r0->field_f = r16
    //     0x11aabb8: stur            w16, [x0, #0xf]
    // 0x11aabbc: ldur            x1, [fp, #-8]
    // 0x11aabc0: LoadField: r2 = r1->field_f
    //     0x11aabc0: ldur            w2, [x1, #0xf]
    // 0x11aabc4: DecompressPointer r2
    //     0x11aabc4: add             x2, x2, HEAP, lsl #32
    // 0x11aabc8: StoreField: r0->field_13 = r2
    //     0x11aabc8: stur            w2, [x0, #0x13]
    // 0x11aabcc: str             x0, [SP]
    // 0x11aabd0: r0 = _interpolate()
    //     0x11aabd0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aabd4: LeaveFrame
    //     0x11aabd4: mov             SP, fp
    //     0x11aabd8: ldp             fp, lr, [SP], #0x10
    // 0x11aabdc: ret
    //     0x11aabdc: ret             
    // 0x11aabe0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aabe0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aabe4: b               #0x11aaba4
  }
}
