// lib: , url: package:flutter/src/material/snack_bar.dart

// class id: 1048949, size: 0x8
class :: {
}

// class id: 5067, size: 0x50, field offset: 0x44
class _SnackbarDefaultsM3 extends SnackBarThemeData {

  late final ColorScheme _colors; // offset: 0x4c
  late final ThemeData _theme; // offset: 0x48

  ColorScheme _colors(_SnackbarDefaultsM3) {
    // ** addr: 0xdfe520, size: 0x58
    // 0xdfe520: EnterFrame
    //     0xdfe520: stp             fp, lr, [SP, #-0x10]!
    //     0xdfe524: mov             fp, SP
    // 0xdfe528: CheckStackOverflow
    //     0xdfe528: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfe52c: cmp             SP, x16
    //     0xdfe530: b.ls            #0xdfe570
    // 0xdfe534: ldr             x1, [fp, #0x10]
    // 0xdfe538: LoadField: r0 = r1->field_47
    //     0xdfe538: ldur            w0, [x1, #0x47]
    // 0xdfe53c: DecompressPointer r0
    //     0xdfe53c: add             x0, x0, HEAP, lsl #32
    // 0xdfe540: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfe544: cmp             w0, w16
    // 0xdfe548: b.ne            #0xdfe558
    // 0xdfe54c: r2 = _theme
    //     0xdfe54c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26240] Field <_SnackbarDefaultsM3@773267081._theme@773267081>: late final (offset: 0x48)
    //     0xdfe550: ldr             x2, [x2, #0x240]
    // 0xdfe554: r0 = InitLateFinalInstanceField()
    //     0xdfe554: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfe558: LoadField: r1 = r0->field_3f
    //     0xdfe558: ldur            w1, [x0, #0x3f]
    // 0xdfe55c: DecompressPointer r1
    //     0xdfe55c: add             x1, x1, HEAP, lsl #32
    // 0xdfe560: mov             x0, x1
    // 0xdfe564: LeaveFrame
    //     0xdfe564: mov             SP, fp
    //     0xdfe568: ldp             fp, lr, [SP], #0x10
    // 0xdfe56c: ret
    //     0xdfe56c: ret             
    // 0xdfe570: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfe570: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfe574: b               #0xdfe534
  }
  ThemeData _theme(_SnackbarDefaultsM3) {
    // ** addr: 0xdfe578, size: 0x38
    // 0xdfe578: EnterFrame
    //     0xdfe578: stp             fp, lr, [SP, #-0x10]!
    //     0xdfe57c: mov             fp, SP
    // 0xdfe580: CheckStackOverflow
    //     0xdfe580: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfe584: cmp             SP, x16
    //     0xdfe588: b.ls            #0xdfe5a8
    // 0xdfe58c: ldr             x0, [fp, #0x10]
    // 0xdfe590: LoadField: r1 = r0->field_43
    //     0xdfe590: ldur            w1, [x0, #0x43]
    // 0xdfe594: DecompressPointer r1
    //     0xdfe594: add             x1, x1, HEAP, lsl #32
    // 0xdfe598: r0 = of()
    //     0xdfe598: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdfe59c: LeaveFrame
    //     0xdfe59c: mov             SP, fp
    //     0xdfe5a0: ldp             fp, lr, [SP], #0x10
    // 0xdfe5a4: ret
    //     0xdfe5a4: ret             
    // 0xdfe5a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfe5a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfe5ac: b               #0xdfe58c
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x11376ac, size: 0x2c4
    // 0x11376ac: EnterFrame
    //     0x11376ac: stp             fp, lr, [SP, #-0x10]!
    //     0x11376b0: mov             fp, SP
    // 0x11376b4: AllocStack(0x8)
    //     0x11376b4: sub             SP, SP, #8
    // 0x11376b8: SetupParameters([dynamic _ /* r0 */])
    //     0x11376b8: ldr             x0, [fp, #0x18]
    //     0x11376bc: ldur            w3, [x0, #0x17]
    //     0x11376c0: add             x3, x3, HEAP, lsl #32
    //     0x11376c4: stur            x3, [fp, #-8]
    // 0x11376c8: CheckStackOverflow
    //     0x11376c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11376cc: cmp             SP, x16
    //     0x11376d0: b.ls            #0x1137968
    // 0x11376d4: ldr             x4, [fp, #0x10]
    // 0x11376d8: r0 = LoadClassIdInstr(r4)
    //     0x11376d8: ldur            x0, [x4, #-1]
    //     0x11376dc: ubfx            x0, x0, #0xc, #0x14
    // 0x11376e0: mov             x1, x4
    // 0x11376e4: r2 = Instance_WidgetState
    //     0x11376e4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0x11376e8: ldr             x2, [x2, #0xa70]
    // 0x11376ec: r0 = GDT[cid_x0 + 0x12929]()
    //     0x11376ec: mov             x17, #0x2929
    //     0x11376f0: movk            x17, #1, lsl #16
    //     0x11376f4: add             lr, x0, x17
    //     0x11376f8: ldr             lr, [x21, lr, lsl #3]
    //     0x11376fc: blr             lr
    // 0x1137700: tbnz            w0, #4, #0x1137760
    // 0x1137704: ldur            x3, [fp, #-8]
    // 0x1137708: LoadField: r1 = r3->field_f
    //     0x1137708: ldur            w1, [x3, #0xf]
    // 0x113770c: DecompressPointer r1
    //     0x113770c: add             x1, x1, HEAP, lsl #32
    // 0x1137710: LoadField: r0 = r1->field_4b
    //     0x1137710: ldur            w0, [x1, #0x4b]
    // 0x1137714: DecompressPointer r0
    //     0x1137714: add             x0, x0, HEAP, lsl #32
    // 0x1137718: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x113771c: cmp             w0, w16
    // 0x1137720: b.ne            #0x1137730
    // 0x1137724: r2 = _colors
    //     0x1137724: add             x2, PP, #0x26, lsl #12  ; [pp+0x26200] Field <_SnackbarDefaultsM3@773267081._colors@773267081>: late final (offset: 0x4c)
    //     0x1137728: ldr             x2, [x2, #0x200]
    // 0x113772c: r0 = InitLateFinalInstanceField()
    //     0x113772c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1137730: LoadField: r1 = r0->field_bf
    //     0x1137730: ldur            w1, [x0, #0xbf]
    // 0x1137734: DecompressPointer r1
    //     0x1137734: add             x1, x1, HEAP, lsl #32
    // 0x1137738: cmp             w1, NULL
    // 0x113773c: b.ne            #0x1137750
    // 0x1137740: LoadField: r1 = r0->field_f
    //     0x1137740: ldur            w1, [x0, #0xf]
    // 0x1137744: DecompressPointer r1
    //     0x1137744: add             x1, x1, HEAP, lsl #32
    // 0x1137748: mov             x0, x1
    // 0x113774c: b               #0x1137754
    // 0x1137750: mov             x0, x1
    // 0x1137754: LeaveFrame
    //     0x1137754: mov             SP, fp
    //     0x1137758: ldp             fp, lr, [SP], #0x10
    // 0x113775c: ret
    //     0x113775c: ret             
    // 0x1137760: ldr             x4, [fp, #0x10]
    // 0x1137764: ldur            x3, [fp, #-8]
    // 0x1137768: r0 = LoadClassIdInstr(r4)
    //     0x1137768: ldur            x0, [x4, #-1]
    //     0x113776c: ubfx            x0, x0, #0xc, #0x14
    // 0x1137770: mov             x1, x4
    // 0x1137774: r2 = Instance_WidgetState
    //     0x1137774: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0x1137778: ldr             x2, [x2, #0xa48]
    // 0x113777c: r0 = GDT[cid_x0 + 0x12929]()
    //     0x113777c: mov             x17, #0x2929
    //     0x1137780: movk            x17, #1, lsl #16
    //     0x1137784: add             lr, x0, x17
    //     0x1137788: ldr             lr, [x21, lr, lsl #3]
    //     0x113778c: blr             lr
    // 0x1137790: tbnz            w0, #4, #0x11377f0
    // 0x1137794: ldur            x3, [fp, #-8]
    // 0x1137798: LoadField: r1 = r3->field_f
    //     0x1137798: ldur            w1, [x3, #0xf]
    // 0x113779c: DecompressPointer r1
    //     0x113779c: add             x1, x1, HEAP, lsl #32
    // 0x11377a0: LoadField: r0 = r1->field_4b
    //     0x11377a0: ldur            w0, [x1, #0x4b]
    // 0x11377a4: DecompressPointer r0
    //     0x11377a4: add             x0, x0, HEAP, lsl #32
    // 0x11377a8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11377ac: cmp             w0, w16
    // 0x11377b0: b.ne            #0x11377c0
    // 0x11377b4: r2 = _colors
    //     0x11377b4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26200] Field <_SnackbarDefaultsM3@773267081._colors@773267081>: late final (offset: 0x4c)
    //     0x11377b8: ldr             x2, [x2, #0x200]
    // 0x11377bc: r0 = InitLateFinalInstanceField()
    //     0x11377bc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11377c0: LoadField: r1 = r0->field_bf
    //     0x11377c0: ldur            w1, [x0, #0xbf]
    // 0x11377c4: DecompressPointer r1
    //     0x11377c4: add             x1, x1, HEAP, lsl #32
    // 0x11377c8: cmp             w1, NULL
    // 0x11377cc: b.ne            #0x11377e0
    // 0x11377d0: LoadField: r1 = r0->field_f
    //     0x11377d0: ldur            w1, [x0, #0xf]
    // 0x11377d4: DecompressPointer r1
    //     0x11377d4: add             x1, x1, HEAP, lsl #32
    // 0x11377d8: mov             x0, x1
    // 0x11377dc: b               #0x11377e4
    // 0x11377e0: mov             x0, x1
    // 0x11377e4: LeaveFrame
    //     0x11377e4: mov             SP, fp
    //     0x11377e8: ldp             fp, lr, [SP], #0x10
    // 0x11377ec: ret
    //     0x11377ec: ret             
    // 0x11377f0: ldr             x4, [fp, #0x10]
    // 0x11377f4: ldur            x3, [fp, #-8]
    // 0x11377f8: r0 = LoadClassIdInstr(r4)
    //     0x11377f8: ldur            x0, [x4, #-1]
    //     0x11377fc: ubfx            x0, x0, #0xc, #0x14
    // 0x1137800: mov             x1, x4
    // 0x1137804: r2 = Instance_WidgetState
    //     0x1137804: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0x1137808: ldr             x2, [x2, #0xa50]
    // 0x113780c: r0 = GDT[cid_x0 + 0x12929]()
    //     0x113780c: mov             x17, #0x2929
    //     0x1137810: movk            x17, #1, lsl #16
    //     0x1137814: add             lr, x0, x17
    //     0x1137818: ldr             lr, [x21, lr, lsl #3]
    //     0x113781c: blr             lr
    // 0x1137820: tbnz            w0, #4, #0x1137880
    // 0x1137824: ldur            x3, [fp, #-8]
    // 0x1137828: LoadField: r1 = r3->field_f
    //     0x1137828: ldur            w1, [x3, #0xf]
    // 0x113782c: DecompressPointer r1
    //     0x113782c: add             x1, x1, HEAP, lsl #32
    // 0x1137830: LoadField: r0 = r1->field_4b
    //     0x1137830: ldur            w0, [x1, #0x4b]
    // 0x1137834: DecompressPointer r0
    //     0x1137834: add             x0, x0, HEAP, lsl #32
    // 0x1137838: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x113783c: cmp             w0, w16
    // 0x1137840: b.ne            #0x1137850
    // 0x1137844: r2 = _colors
    //     0x1137844: add             x2, PP, #0x26, lsl #12  ; [pp+0x26200] Field <_SnackbarDefaultsM3@773267081._colors@773267081>: late final (offset: 0x4c)
    //     0x1137848: ldr             x2, [x2, #0x200]
    // 0x113784c: r0 = InitLateFinalInstanceField()
    //     0x113784c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1137850: LoadField: r1 = r0->field_bf
    //     0x1137850: ldur            w1, [x0, #0xbf]
    // 0x1137854: DecompressPointer r1
    //     0x1137854: add             x1, x1, HEAP, lsl #32
    // 0x1137858: cmp             w1, NULL
    // 0x113785c: b.ne            #0x1137870
    // 0x1137860: LoadField: r1 = r0->field_f
    //     0x1137860: ldur            w1, [x0, #0xf]
    // 0x1137864: DecompressPointer r1
    //     0x1137864: add             x1, x1, HEAP, lsl #32
    // 0x1137868: mov             x0, x1
    // 0x113786c: b               #0x1137874
    // 0x1137870: mov             x0, x1
    // 0x1137874: LeaveFrame
    //     0x1137874: mov             SP, fp
    //     0x1137878: ldp             fp, lr, [SP], #0x10
    // 0x113787c: ret
    //     0x113787c: ret             
    // 0x1137880: ldr             x1, [fp, #0x10]
    // 0x1137884: ldur            x3, [fp, #-8]
    // 0x1137888: r0 = LoadClassIdInstr(r1)
    //     0x1137888: ldur            x0, [x1, #-1]
    //     0x113788c: ubfx            x0, x0, #0xc, #0x14
    // 0x1137890: r2 = Instance_WidgetState
    //     0x1137890: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0x1137894: ldr             x2, [x2, #0xa60]
    // 0x1137898: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1137898: mov             x17, #0x2929
    //     0x113789c: movk            x17, #1, lsl #16
    //     0x11378a0: add             lr, x0, x17
    //     0x11378a4: ldr             lr, [x21, lr, lsl #3]
    //     0x11378a8: blr             lr
    // 0x11378ac: tbnz            w0, #4, #0x113790c
    // 0x11378b0: ldur            x0, [fp, #-8]
    // 0x11378b4: LoadField: r1 = r0->field_f
    //     0x11378b4: ldur            w1, [x0, #0xf]
    // 0x11378b8: DecompressPointer r1
    //     0x11378b8: add             x1, x1, HEAP, lsl #32
    // 0x11378bc: LoadField: r0 = r1->field_4b
    //     0x11378bc: ldur            w0, [x1, #0x4b]
    // 0x11378c0: DecompressPointer r0
    //     0x11378c0: add             x0, x0, HEAP, lsl #32
    // 0x11378c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11378c8: cmp             w0, w16
    // 0x11378cc: b.ne            #0x11378dc
    // 0x11378d0: r2 = _colors
    //     0x11378d0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26200] Field <_SnackbarDefaultsM3@773267081._colors@773267081>: late final (offset: 0x4c)
    //     0x11378d4: ldr             x2, [x2, #0x200]
    // 0x11378d8: r0 = InitLateFinalInstanceField()
    //     0x11378d8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11378dc: LoadField: r1 = r0->field_bf
    //     0x11378dc: ldur            w1, [x0, #0xbf]
    // 0x11378e0: DecompressPointer r1
    //     0x11378e0: add             x1, x1, HEAP, lsl #32
    // 0x11378e4: cmp             w1, NULL
    // 0x11378e8: b.ne            #0x11378fc
    // 0x11378ec: LoadField: r1 = r0->field_f
    //     0x11378ec: ldur            w1, [x0, #0xf]
    // 0x11378f0: DecompressPointer r1
    //     0x11378f0: add             x1, x1, HEAP, lsl #32
    // 0x11378f4: mov             x0, x1
    // 0x11378f8: b               #0x1137900
    // 0x11378fc: mov             x0, x1
    // 0x1137900: LeaveFrame
    //     0x1137900: mov             SP, fp
    //     0x1137904: ldp             fp, lr, [SP], #0x10
    // 0x1137908: ret
    //     0x1137908: ret             
    // 0x113790c: ldur            x0, [fp, #-8]
    // 0x1137910: LoadField: r1 = r0->field_f
    //     0x1137910: ldur            w1, [x0, #0xf]
    // 0x1137914: DecompressPointer r1
    //     0x1137914: add             x1, x1, HEAP, lsl #32
    // 0x1137918: LoadField: r0 = r1->field_4b
    //     0x1137918: ldur            w0, [x1, #0x4b]
    // 0x113791c: DecompressPointer r0
    //     0x113791c: add             x0, x0, HEAP, lsl #32
    // 0x1137920: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1137924: cmp             w0, w16
    // 0x1137928: b.ne            #0x1137938
    // 0x113792c: r2 = _colors
    //     0x113792c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26200] Field <_SnackbarDefaultsM3@773267081._colors@773267081>: late final (offset: 0x4c)
    //     0x1137930: ldr             x2, [x2, #0x200]
    // 0x1137934: r0 = InitLateFinalInstanceField()
    //     0x1137934: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1137938: LoadField: r1 = r0->field_bf
    //     0x1137938: ldur            w1, [x0, #0xbf]
    // 0x113793c: DecompressPointer r1
    //     0x113793c: add             x1, x1, HEAP, lsl #32
    // 0x1137940: cmp             w1, NULL
    // 0x1137944: b.ne            #0x1137958
    // 0x1137948: LoadField: r2 = r0->field_f
    //     0x1137948: ldur            w2, [x0, #0xf]
    // 0x113794c: DecompressPointer r2
    //     0x113794c: add             x2, x2, HEAP, lsl #32
    // 0x1137950: mov             x0, x2
    // 0x1137954: b               #0x113795c
    // 0x1137958: mov             x0, x1
    // 0x113795c: LeaveFrame
    //     0x113795c: mov             SP, fp
    //     0x1137960: ldp             fp, lr, [SP], #0x10
    // 0x1137964: ret
    //     0x1137964: ret             
    // 0x1137968: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1137968: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x113796c: b               #0x11376d4
  }
  get _ elevation(/* No info */) {
    // ** addr: 0x1282dc8, size: 0xc
    // 0x1282dc8: r0 = 6.000000
    //     0x1282dc8: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c438] 6
    //     0x1282dcc: ldr             x0, [x0, #0x438]
    // 0x1282dd0: ret
    //     0x1282dd0: ret             
  }
  get _ backgroundColor(/* No info */) {
    // ** addr: 0x12ac328, size: 0x6c
    // 0x12ac328: EnterFrame
    //     0x12ac328: stp             fp, lr, [SP, #-0x10]!
    //     0x12ac32c: mov             fp, SP
    // 0x12ac330: CheckStackOverflow
    //     0x12ac330: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ac334: cmp             SP, x16
    //     0x12ac338: b.ls            #0x12ac38c
    // 0x12ac33c: LoadField: r0 = r1->field_4b
    //     0x12ac33c: ldur            w0, [x1, #0x4b]
    // 0x12ac340: DecompressPointer r0
    //     0x12ac340: add             x0, x0, HEAP, lsl #32
    // 0x12ac344: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12ac348: cmp             w0, w16
    // 0x12ac34c: b.ne            #0x12ac35c
    // 0x12ac350: r2 = _colors
    //     0x12ac350: add             x2, PP, #0x26, lsl #12  ; [pp+0x26200] Field <_SnackbarDefaultsM3@773267081._colors@773267081>: late final (offset: 0x4c)
    //     0x12ac354: ldr             x2, [x2, #0x200]
    // 0x12ac358: r0 = InitLateFinalInstanceField()
    //     0x12ac358: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12ac35c: LoadField: r1 = r0->field_b7
    //     0x12ac35c: ldur            w1, [x0, #0xb7]
    // 0x12ac360: DecompressPointer r1
    //     0x12ac360: add             x1, x1, HEAP, lsl #32
    // 0x12ac364: cmp             w1, NULL
    // 0x12ac368: b.ne            #0x12ac37c
    // 0x12ac36c: LoadField: r2 = r0->field_7f
    //     0x12ac36c: ldur            w2, [x0, #0x7f]
    // 0x12ac370: DecompressPointer r2
    //     0x12ac370: add             x2, x2, HEAP, lsl #32
    // 0x12ac374: mov             x0, x2
    // 0x12ac378: b               #0x12ac380
    // 0x12ac37c: mov             x0, x1
    // 0x12ac380: LeaveFrame
    //     0x12ac380: mov             SP, fp
    //     0x12ac384: ldp             fp, lr, [SP], #0x10
    // 0x12ac388: ret
    //     0x12ac388: ret             
    // 0x12ac38c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ac38c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ac390: b               #0x12ac33c
  }
}

// class id: 5068, size: 0x4c, field offset: 0x44
class _SnackbarDefaultsM2 extends SnackBarThemeData {

  late final ColorScheme _colors; // offset: 0x48
  late final ThemeData _theme; // offset: 0x44

  _ _SnackbarDefaultsM2(/* No info */) {
    // ** addr: 0xdfe220, size: 0xa8
    // 0xdfe220: EnterFrame
    //     0xdfe220: stp             fp, lr, [SP, #-0x10]!
    //     0xdfe224: mov             fp, SP
    // 0xdfe228: AllocStack(0x10)
    //     0xdfe228: sub             SP, SP, #0x10
    // 0xdfe22c: SetupParameters(_SnackbarDefaultsM2 this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xdfe22c: mov             x0, x2
    //     0xdfe230: stur            x2, [fp, #-0x10]
    //     0xdfe234: mov             x2, x1
    //     0xdfe238: stur            x1, [fp, #-8]
    // 0xdfe23c: CheckStackOverflow
    //     0xdfe23c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfe240: cmp             SP, x16
    //     0xdfe244: b.ls            #0xdfe2c0
    // 0xdfe248: mov             x1, x0
    // 0xdfe24c: r0 = of()
    //     0xdfe24c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdfe250: ldur            x2, [fp, #-8]
    // 0xdfe254: StoreField: r2->field_43 = r0
    //     0xdfe254: stur            w0, [x2, #0x43]
    //     0xdfe258: ldurb           w16, [x2, #-1]
    //     0xdfe25c: ldurb           w17, [x0, #-1]
    //     0xdfe260: and             x16, x17, x16, lsr #2
    //     0xdfe264: tst             x16, HEAP, lsr #32
    //     0xdfe268: b.eq            #0xdfe270
    //     0xdfe26c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xdfe270: ldur            x1, [fp, #-0x10]
    // 0xdfe274: r0 = of()
    //     0xdfe274: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdfe278: LoadField: r1 = r0->field_3f
    //     0xdfe278: ldur            w1, [x0, #0x3f]
    // 0xdfe27c: DecompressPointer r1
    //     0xdfe27c: add             x1, x1, HEAP, lsl #32
    // 0xdfe280: mov             x0, x1
    // 0xdfe284: ldur            x1, [fp, #-8]
    // 0xdfe288: StoreField: r1->field_47 = r0
    //     0xdfe288: stur            w0, [x1, #0x47]
    //     0xdfe28c: ldurb           w16, [x1, #-1]
    //     0xdfe290: ldurb           w17, [x0, #-1]
    //     0xdfe294: and             x16, x17, x16, lsr #2
    //     0xdfe298: tst             x16, HEAP, lsr #32
    //     0xdfe29c: b.eq            #0xdfe2a4
    //     0xdfe2a0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdfe2a4: r2 = 6.000000
    //     0xdfe2a4: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1c438] 6
    //     0xdfe2a8: ldr             x2, [x2, #0x438]
    // 0xdfe2ac: ArrayStore: r1[0] = r2  ; List_4
    //     0xdfe2ac: stur            w2, [x1, #0x17]
    // 0xdfe2b0: r0 = Null
    //     0xdfe2b0: mov             x0, NULL
    // 0xdfe2b4: LeaveFrame
    //     0xdfe2b4: mov             SP, fp
    //     0xdfe2b8: ldp             fp, lr, [SP], #0x10
    // 0xdfe2bc: ret
    //     0xdfe2bc: ret             
    // 0xdfe2c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfe2c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfe2c4: b               #0xdfe248
  }
  get _ backgroundColor(/* No info */) {
    // ** addr: 0x12ac220, size: 0x108
    // 0x12ac220: EnterFrame
    //     0x12ac220: stp             fp, lr, [SP, #-0x10]!
    //     0x12ac224: mov             fp, SP
    // 0x12ac228: AllocStack(0x8)
    //     0x12ac228: sub             SP, SP, #8
    // 0x12ac22c: SetupParameters(_SnackbarDefaultsM2 this /* r1 => r2, fp-0x8 */)
    //     0x12ac22c: mov             x2, x1
    //     0x12ac230: stur            x1, [fp, #-8]
    // 0x12ac234: CheckStackOverflow
    //     0x12ac234: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ac238: cmp             SP, x16
    //     0x12ac23c: b.ls            #0x12ac2fc
    // 0x12ac240: LoadField: r0 = r2->field_43
    //     0x12ac240: ldur            w0, [x2, #0x43]
    // 0x12ac244: DecompressPointer r0
    //     0x12ac244: add             x0, x0, HEAP, lsl #32
    // 0x12ac248: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12ac24c: cmp             w0, w16
    // 0x12ac250: b.eq            #0x12ac304
    // 0x12ac254: LoadField: r1 = r0->field_3f
    //     0x12ac254: ldur            w1, [x0, #0x3f]
    // 0x12ac258: DecompressPointer r1
    //     0x12ac258: add             x1, x1, HEAP, lsl #32
    // 0x12ac25c: LoadField: r0 = r1->field_7
    //     0x12ac25c: ldur            w0, [x1, #7]
    // 0x12ac260: DecompressPointer r0
    //     0x12ac260: add             x0, x0, HEAP, lsl #32
    // 0x12ac264: r16 = Instance_Brightness
    //     0x12ac264: ldr             x16, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0x12ac268: cmp             w0, w16
    // 0x12ac26c: b.ne            #0x12ac2cc
    // 0x12ac270: LoadField: r0 = r2->field_47
    //     0x12ac270: ldur            w0, [x2, #0x47]
    // 0x12ac274: DecompressPointer r0
    //     0x12ac274: add             x0, x0, HEAP, lsl #32
    // 0x12ac278: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12ac27c: cmp             w0, w16
    // 0x12ac280: b.eq            #0x12ac310
    // 0x12ac284: LoadField: r1 = r0->field_7f
    //     0x12ac284: ldur            w1, [x0, #0x7f]
    // 0x12ac288: DecompressPointer r1
    //     0x12ac288: add             x1, x1, HEAP, lsl #32
    // 0x12ac28c: r0 = LoadClassIdInstr(r1)
    //     0x12ac28c: ldur            x0, [x1, #-1]
    //     0x12ac290: ubfx            x0, x0, #0xc, #0x14
    // 0x12ac294: d0 = 0.800000
    //     0x12ac294: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a58] IMM: double(0.8) from 0x3fe999999999999a
    //     0x12ac298: ldr             d0, [x17, #0xa58]
    // 0x12ac29c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12ac29c: sub             lr, x0, #1, lsl #12
    //     0x12ac2a0: ldr             lr, [x21, lr, lsl #3]
    //     0x12ac2a4: blr             lr
    // 0x12ac2a8: mov             x1, x0
    // 0x12ac2ac: ldur            x0, [fp, #-8]
    // 0x12ac2b0: LoadField: r2 = r0->field_47
    //     0x12ac2b0: ldur            w2, [x0, #0x47]
    // 0x12ac2b4: DecompressPointer r2
    //     0x12ac2b4: add             x2, x2, HEAP, lsl #32
    // 0x12ac2b8: LoadField: r0 = r2->field_7b
    //     0x12ac2b8: ldur            w0, [x2, #0x7b]
    // 0x12ac2bc: DecompressPointer r0
    //     0x12ac2bc: add             x0, x0, HEAP, lsl #32
    // 0x12ac2c0: mov             x2, x0
    // 0x12ac2c4: r0 = alphaBlend()
    //     0x12ac2c4: bl              #0xb6ea90  ; [dart:ui] Color::alphaBlend
    // 0x12ac2c8: b               #0x12ac2f0
    // 0x12ac2cc: mov             x0, x2
    // 0x12ac2d0: LoadField: r1 = r0->field_47
    //     0x12ac2d0: ldur            w1, [x0, #0x47]
    // 0x12ac2d4: DecompressPointer r1
    //     0x12ac2d4: add             x1, x1, HEAP, lsl #32
    // 0x12ac2d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12ac2dc: cmp             w1, w16
    // 0x12ac2e0: b.eq            #0x12ac31c
    // 0x12ac2e4: LoadField: r2 = r1->field_7f
    //     0x12ac2e4: ldur            w2, [x1, #0x7f]
    // 0x12ac2e8: DecompressPointer r2
    //     0x12ac2e8: add             x2, x2, HEAP, lsl #32
    // 0x12ac2ec: mov             x0, x2
    // 0x12ac2f0: LeaveFrame
    //     0x12ac2f0: mov             SP, fp
    //     0x12ac2f4: ldp             fp, lr, [SP], #0x10
    // 0x12ac2f8: ret
    //     0x12ac2f8: ret             
    // 0x12ac2fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ac2fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ac300: b               #0x12ac240
    // 0x12ac304: r9 = _theme
    //     0x12ac304: add             x9, PP, #0x26, lsl #12  ; [pp+0x26238] Field <_SnackbarDefaultsM2@773267081._theme@773267081>: late final (offset: 0x44)
    //     0x12ac308: ldr             x9, [x9, #0x238]
    // 0x12ac30c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12ac30c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12ac310: r9 = _colors
    //     0x12ac310: add             x9, PP, #0x26, lsl #12  ; [pp+0x26230] Field <_SnackbarDefaultsM2@773267081._colors@773267081>: late final (offset: 0x48)
    //     0x12ac314: ldr             x9, [x9, #0x230]
    // 0x12ac318: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12ac318: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12ac31c: r9 = _colors
    //     0x12ac31c: add             x9, PP, #0x26, lsl #12  ; [pp+0x26230] Field <_SnackbarDefaultsM2@773267081._colors@773267081>: late final (offset: 0x48)
    //     0x12ac320: ldr             x9, [x9, #0x230]
    // 0x12ac324: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12ac324: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 5455, size: 0x2c, field offset: 0x14
class _SnackBarState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xdfd07c, size: 0x1144
    // 0xdfd07c: EnterFrame
    //     0xdfd07c: stp             fp, lr, [SP, #-0x10]!
    //     0xdfd080: mov             fp, SP
    // 0xdfd084: AllocStack(0xd8)
    //     0xdfd084: sub             SP, SP, #0xd8
    // 0xdfd088: SetupParameters(_SnackBarState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xdfd088: mov             x0, x1
    //     0xdfd08c: stur            x1, [fp, #-8]
    //     0xdfd090: mov             x1, x2
    //     0xdfd094: stur            x2, [fp, #-0x10]
    // 0xdfd098: CheckStackOverflow
    //     0xdfd098: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfd09c: cmp             SP, x16
    //     0xdfd0a0: b.ls            #0xdfe150
    // 0xdfd0a4: r1 = 1
    //     0xdfd0a4: mov             x1, #1
    // 0xdfd0a8: r0 = AllocateContext()
    //     0xdfd0a8: bl              #0x13de838  ; AllocateContextStub
    // 0xdfd0ac: ldur            x1, [fp, #-0x10]
    // 0xdfd0b0: stur            x0, [fp, #-0x18]
    // 0xdfd0b4: StoreField: r0->field_f = r1
    //     0xdfd0b4: stur            w1, [x0, #0xf]
    // 0xdfd0b8: r0 = accessibleNavigationOf()
    //     0xdfd0b8: bl              #0xd34edc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::accessibleNavigationOf
    // 0xdfd0bc: ldur            x2, [fp, #-0x18]
    // 0xdfd0c0: stur            x0, [fp, #-0x10]
    // 0xdfd0c4: LoadField: r1 = r2->field_f
    //     0xdfd0c4: ldur            w1, [x2, #0xf]
    // 0xdfd0c8: DecompressPointer r1
    //     0xdfd0c8: add             x1, x1, HEAP, lsl #32
    // 0xdfd0cc: r0 = of()
    //     0xdfd0cc: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdfd0d0: stur            x0, [fp, #-0x28]
    // 0xdfd0d4: LoadField: r2 = r0->field_3f
    //     0xdfd0d4: ldur            w2, [x0, #0x3f]
    // 0xdfd0d8: DecompressPointer r2
    //     0xdfd0d8: add             x2, x2, HEAP, lsl #32
    // 0xdfd0dc: ldur            x3, [fp, #-0x18]
    // 0xdfd0e0: stur            x2, [fp, #-0x20]
    // 0xdfd0e4: LoadField: r1 = r3->field_f
    //     0xdfd0e4: ldur            w1, [x3, #0xf]
    // 0xdfd0e8: DecompressPointer r1
    //     0xdfd0e8: add             x1, x1, HEAP, lsl #32
    // 0xdfd0ec: r0 = of()
    //     0xdfd0ec: bl              #0xd364f4  ; [package:flutter/src/material/snack_bar_theme.dart] SnackBarTheme::of
    // 0xdfd0f0: mov             x1, x0
    // 0xdfd0f4: ldur            x0, [fp, #-0x20]
    // 0xdfd0f8: stur            x1, [fp, #-0x50]
    // 0xdfd0fc: LoadField: r2 = r0->field_7
    //     0xdfd0fc: ldur            w2, [x0, #7]
    // 0xdfd100: DecompressPointer r2
    //     0xdfd100: add             x2, x2, HEAP, lsl #32
    // 0xdfd104: r16 = Instance_Brightness
    //     0xdfd104: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xdfd108: cmp             w2, w16
    // 0xdfd10c: r16 = true
    //     0xdfd10c: add             x16, NULL, #0x20  ; true
    // 0xdfd110: r17 = false
    //     0xdfd110: add             x17, NULL, #0x30  ; false
    // 0xdfd114: csel            x3, x16, x17, eq
    // 0xdfd118: stur            x3, [fp, #-0x48]
    // 0xdfd11c: tbnz            w3, #4, #0xdfd130
    // 0xdfd120: LoadField: r2 = r0->field_b
    //     0xdfd120: ldur            w2, [x0, #0xb]
    // 0xdfd124: DecompressPointer r2
    //     0xdfd124: add             x2, x2, HEAP, lsl #32
    // 0xdfd128: mov             x4, x2
    // 0xdfd12c: b               #0xdfd13c
    // 0xdfd130: LoadField: r2 = r0->field_2b
    //     0xdfd130: ldur            w2, [x0, #0x2b]
    // 0xdfd134: DecompressPointer r2
    //     0xdfd134: add             x2, x2, HEAP, lsl #32
    // 0xdfd138: mov             x4, x2
    // 0xdfd13c: ldur            x2, [fp, #-0x28]
    // 0xdfd140: stur            x4, [fp, #-0x40]
    // 0xdfd144: LoadField: r5 = r2->field_2f
    //     0xdfd144: ldur            w5, [x2, #0x2f]
    // 0xdfd148: DecompressPointer r5
    //     0xdfd148: add             x5, x5, HEAP, lsl #32
    // 0xdfd14c: stur            x5, [fp, #-0x38]
    // 0xdfd150: tbnz            w5, #4, #0xdfd188
    // 0xdfd154: ldur            x6, [fp, #-0x18]
    // 0xdfd158: LoadField: r7 = r6->field_f
    //     0xdfd158: ldur            w7, [x6, #0xf]
    // 0xdfd15c: DecompressPointer r7
    //     0xdfd15c: add             x7, x7, HEAP, lsl #32
    // 0xdfd160: stur            x7, [fp, #-0x30]
    // 0xdfd164: r0 = _SnackbarDefaultsM3()
    //     0xdfd164: bl              #0xdfe2d4  ; Allocate_SnackbarDefaultsM3Stub -> _SnackbarDefaultsM3 (size=0x50)
    // 0xdfd168: mov             x1, x0
    // 0xdfd16c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfd170: StoreField: r1->field_47 = r0
    //     0xdfd170: stur            w0, [x1, #0x47]
    // 0xdfd174: StoreField: r1->field_4b = r0
    //     0xdfd174: stur            w0, [x1, #0x4b]
    // 0xdfd178: ldur            x0, [fp, #-0x30]
    // 0xdfd17c: StoreField: r1->field_43 = r0
    //     0xdfd17c: stur            w0, [x1, #0x43]
    // 0xdfd180: mov             x2, x1
    // 0xdfd184: b               #0xdfd1b0
    // 0xdfd188: ldur            x2, [fp, #-0x18]
    // 0xdfd18c: LoadField: r0 = r2->field_f
    //     0xdfd18c: ldur            w0, [x2, #0xf]
    // 0xdfd190: DecompressPointer r0
    //     0xdfd190: add             x0, x0, HEAP, lsl #32
    // 0xdfd194: stur            x0, [fp, #-0x30]
    // 0xdfd198: r0 = _SnackbarDefaultsM2()
    //     0xdfd198: bl              #0xdfe2c8  ; Allocate_SnackbarDefaultsM2Stub -> _SnackbarDefaultsM2 (size=0x4c)
    // 0xdfd19c: mov             x1, x0
    // 0xdfd1a0: ldur            x2, [fp, #-0x30]
    // 0xdfd1a4: stur            x0, [fp, #-0x30]
    // 0xdfd1a8: r0 = _SnackbarDefaultsM2()
    //     0xdfd1a8: bl              #0xdfe220  ; [package:flutter/src/material/snack_bar.dart] _SnackbarDefaultsM2::_SnackbarDefaultsM2
    // 0xdfd1ac: ldur            x2, [fp, #-0x30]
    // 0xdfd1b0: ldur            x0, [fp, #-0x48]
    // 0xdfd1b4: stur            x2, [fp, #-0x60]
    // 0xdfd1b8: tbnz            w0, #4, #0xdfd1c4
    // 0xdfd1bc: r3 = Instance_Brightness
    //     0xdfd1bc: ldr             x3, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0xdfd1c0: b               #0xdfd1c8
    // 0xdfd1c4: r3 = Instance_Brightness
    //     0xdfd1c4: ldr             x3, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xdfd1c8: ldur            x0, [fp, #-0x38]
    // 0xdfd1cc: stur            x3, [fp, #-0x58]
    // 0xdfd1d0: tbnz            w0, #4, #0xdfd1e0
    // 0xdfd1d4: mov             x0, x2
    // 0xdfd1d8: ldur            x2, [fp, #-0x28]
    // 0xdfd1dc: b               #0xdfd394
    // 0xdfd1e0: ldur            x4, [fp, #-0x20]
    // 0xdfd1e4: LoadField: r5 = r4->field_f
    //     0xdfd1e4: ldur            w5, [x4, #0xf]
    // 0xdfd1e8: DecompressPointer r5
    //     0xdfd1e8: add             x5, x5, HEAP, lsl #32
    // 0xdfd1ec: stur            x5, [fp, #-0x48]
    // 0xdfd1f0: LoadField: r6 = r4->field_7f
    //     0xdfd1f0: ldur            w6, [x4, #0x7f]
    // 0xdfd1f4: DecompressPointer r6
    //     0xdfd1f4: add             x6, x6, HEAP, lsl #32
    // 0xdfd1f8: stur            x6, [fp, #-0x30]
    // 0xdfd1fc: r1 = LoadClassIdInstr(r2)
    //     0xdfd1fc: ldur            x1, [x2, #-1]
    //     0xdfd200: ubfx            x1, x1, #0xc, #0x14
    // 0xdfd204: r17 = 5066
    //     0xdfd204: mov             x17, #0x13ca
    // 0xdfd208: cmp             x1, x17
    // 0xdfd20c: b.ne            #0xdfd230
    // 0xdfd210: LoadField: r1 = r2->field_7
    //     0xdfd210: ldur            w1, [x2, #7]
    // 0xdfd214: DecompressPointer r1
    //     0xdfd214: add             x1, x1, HEAP, lsl #32
    // 0xdfd218: mov             x2, x5
    // 0xdfd21c: mov             x5, x1
    // 0xdfd220: mov             x1, x4
    // 0xdfd224: mov             x0, x3
    // 0xdfd228: mov             x3, x6
    // 0xdfd22c: b               #0xdfd2c8
    // 0xdfd230: r17 = 5067
    //     0xdfd230: mov             x17, #0x13cb
    // 0xdfd234: cmp             x1, x17
    // 0xdfd238: b.ne            #0xdfd29c
    // 0xdfd23c: mov             x1, x2
    // 0xdfd240: LoadField: r0 = r1->field_4b
    //     0xdfd240: ldur            w0, [x1, #0x4b]
    // 0xdfd244: DecompressPointer r0
    //     0xdfd244: add             x0, x0, HEAP, lsl #32
    // 0xdfd248: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfd24c: cmp             w0, w16
    // 0xdfd250: b.ne            #0xdfd260
    // 0xdfd254: r2 = _colors
    //     0xdfd254: add             x2, PP, #0x26, lsl #12  ; [pp+0x26200] Field <_SnackbarDefaultsM3@773267081._colors@773267081>: late final (offset: 0x4c)
    //     0xdfd258: ldr             x2, [x2, #0x200]
    // 0xdfd25c: r0 = InitLateFinalInstanceField()
    //     0xdfd25c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfd260: LoadField: r1 = r0->field_b7
    //     0xdfd260: ldur            w1, [x0, #0xb7]
    // 0xdfd264: DecompressPointer r1
    //     0xdfd264: add             x1, x1, HEAP, lsl #32
    // 0xdfd268: cmp             w1, NULL
    // 0xdfd26c: b.ne            #0xdfd280
    // 0xdfd270: LoadField: r1 = r0->field_7f
    //     0xdfd270: ldur            w1, [x0, #0x7f]
    // 0xdfd274: DecompressPointer r1
    //     0xdfd274: add             x1, x1, HEAP, lsl #32
    // 0xdfd278: mov             x0, x1
    // 0xdfd27c: b               #0xdfd284
    // 0xdfd280: mov             x0, x1
    // 0xdfd284: mov             x5, x0
    // 0xdfd288: ldur            x1, [fp, #-0x20]
    // 0xdfd28c: ldur            x0, [fp, #-0x58]
    // 0xdfd290: ldur            x2, [fp, #-0x48]
    // 0xdfd294: ldur            x3, [fp, #-0x30]
    // 0xdfd298: b               #0xdfd2c8
    // 0xdfd29c: r0 = LoadClassIdInstr(r2)
    //     0xdfd29c: ldur            x0, [x2, #-1]
    //     0xdfd2a0: ubfx            x0, x0, #0xc, #0x14
    // 0xdfd2a4: mov             x1, x2
    // 0xdfd2a8: r0 = GDT[cid_x0 + -0xf44]()
    //     0xdfd2a8: sub             lr, x0, #0xf44
    //     0xdfd2ac: ldr             lr, [x21, lr, lsl #3]
    //     0xdfd2b0: blr             lr
    // 0xdfd2b4: mov             x5, x0
    // 0xdfd2b8: ldur            x1, [fp, #-0x20]
    // 0xdfd2bc: ldur            x0, [fp, #-0x58]
    // 0xdfd2c0: ldur            x2, [fp, #-0x48]
    // 0xdfd2c4: ldur            x3, [fp, #-0x30]
    // 0xdfd2c8: ldur            x4, [fp, #-0x40]
    // 0xdfd2cc: stur            x5, [fp, #-0x98]
    // 0xdfd2d0: LoadField: r6 = r1->field_6f
    //     0xdfd2d0: ldur            w6, [x1, #0x6f]
    // 0xdfd2d4: DecompressPointer r6
    //     0xdfd2d4: add             x6, x6, HEAP, lsl #32
    // 0xdfd2d8: stur            x6, [fp, #-0x90]
    // 0xdfd2dc: LoadField: r7 = r1->field_b
    //     0xdfd2dc: ldur            w7, [x1, #0xb]
    // 0xdfd2e0: DecompressPointer r7
    //     0xdfd2e0: add             x7, x7, HEAP, lsl #32
    // 0xdfd2e4: stur            x7, [fp, #-0x88]
    // 0xdfd2e8: LoadField: r8 = r1->field_2b
    //     0xdfd2e8: ldur            w8, [x1, #0x2b]
    // 0xdfd2ec: DecompressPointer r8
    //     0xdfd2ec: add             x8, x8, HEAP, lsl #32
    // 0xdfd2f0: stur            x8, [fp, #-0x80]
    // 0xdfd2f4: LoadField: r9 = r1->field_7b
    //     0xdfd2f4: ldur            w9, [x1, #0x7b]
    // 0xdfd2f8: DecompressPointer r9
    //     0xdfd2f8: add             x9, x9, HEAP, lsl #32
    // 0xdfd2fc: stur            x9, [fp, #-0x78]
    // 0xdfd300: LoadField: r10 = r1->field_c7
    //     0xdfd300: ldur            w10, [x1, #0xc7]
    // 0xdfd304: DecompressPointer r10
    //     0xdfd304: add             x10, x10, HEAP, lsl #32
    // 0xdfd308: stur            x10, [fp, #-0x70]
    // 0xdfd30c: LoadField: r11 = r1->field_6b
    //     0xdfd30c: ldur            w11, [x1, #0x6b]
    // 0xdfd310: DecompressPointer r11
    //     0xdfd310: add             x11, x11, HEAP, lsl #32
    // 0xdfd314: stur            x11, [fp, #-0x68]
    // 0xdfd318: r0 = ColorScheme()
    //     0xdfd318: bl              #0x8a9004  ; AllocateColorSchemeStub -> ColorScheme (size=0xd0)
    // 0xdfd31c: mov             x1, x0
    // 0xdfd320: ldur            x0, [fp, #-0x58]
    // 0xdfd324: StoreField: r1->field_7 = r0
    //     0xdfd324: stur            w0, [x1, #7]
    // 0xdfd328: ldur            x0, [fp, #-0x48]
    // 0xdfd32c: StoreField: r1->field_b = r0
    //     0xdfd32c: stur            w0, [x1, #0xb]
    // 0xdfd330: ldur            x0, [fp, #-0x88]
    // 0xdfd334: StoreField: r1->field_f = r0
    //     0xdfd334: stur            w0, [x1, #0xf]
    // 0xdfd338: ldur            x0, [fp, #-0x40]
    // 0xdfd33c: StoreField: r1->field_2b = r0
    //     0xdfd33c: stur            w0, [x1, #0x2b]
    // 0xdfd340: ldur            x0, [fp, #-0x80]
    // 0xdfd344: StoreField: r1->field_2f = r0
    //     0xdfd344: stur            w0, [x1, #0x2f]
    // 0xdfd348: ldur            x0, [fp, #-0x90]
    // 0xdfd34c: StoreField: r1->field_6b = r0
    //     0xdfd34c: stur            w0, [x1, #0x6b]
    // 0xdfd350: ldur            x0, [fp, #-0x68]
    // 0xdfd354: StoreField: r1->field_6f = r0
    //     0xdfd354: stur            w0, [x1, #0x6f]
    // 0xdfd358: ldur            x0, [fp, #-0x30]
    // 0xdfd35c: StoreField: r1->field_7b = r0
    //     0xdfd35c: stur            w0, [x1, #0x7b]
    // 0xdfd360: ldur            x0, [fp, #-0x78]
    // 0xdfd364: StoreField: r1->field_7f = r0
    //     0xdfd364: stur            w0, [x1, #0x7f]
    // 0xdfd368: ldur            x0, [fp, #-0x98]
    // 0xdfd36c: StoreField: r1->field_c7 = r0
    //     0xdfd36c: stur            w0, [x1, #0xc7]
    // 0xdfd370: ldur            x0, [fp, #-0x70]
    // 0xdfd374: StoreField: r1->field_cb = r0
    //     0xdfd374: stur            w0, [x1, #0xcb]
    // 0xdfd378: str             x1, [SP]
    // 0xdfd37c: ldur            x1, [fp, #-0x28]
    // 0xdfd380: r4 = const [0, 0x2, 0x1, 0x1, colorScheme, 0x1, null]
    //     0xdfd380: add             x4, PP, #0x12, lsl #12  ; [pp+0x12988] List(7) [0, 0x2, 0x1, 0x1, "colorScheme", 0x1, Null]
    //     0xdfd384: ldr             x4, [x4, #0x988]
    // 0xdfd388: r0 = copyWith()
    //     0xdfd388: bl              #0x8a7b68  ; [package:flutter/src/material/theme_data.dart] ThemeData::copyWith
    // 0xdfd38c: mov             x2, x0
    // 0xdfd390: ldur            x0, [fp, #-0x60]
    // 0xdfd394: stur            x2, [fp, #-0x20]
    // 0xdfd398: r3 = LoadClassIdInstr(r0)
    //     0xdfd398: ldur            x3, [x0, #-1]
    //     0xdfd39c: ubfx            x3, x3, #0xc, #0x14
    // 0xdfd3a0: stur            x3, [fp, #-0xa0]
    // 0xdfd3a4: r17 = 5066
    //     0xdfd3a4: mov             x17, #0x13ca
    // 0xdfd3a8: cmp             x3, x17
    // 0xdfd3ac: b.ne            #0xdfd3bc
    // 0xdfd3b0: LoadField: r1 = r0->field_13
    //     0xdfd3b0: ldur            w1, [x0, #0x13]
    // 0xdfd3b4: DecompressPointer r1
    //     0xdfd3b4: add             x1, x1, HEAP, lsl #32
    // 0xdfd3b8: b               #0xdfd4c0
    // 0xdfd3bc: r17 = 5067
    //     0xdfd3bc: mov             x17, #0x13cb
    // 0xdfd3c0: cmp             x3, x17
    // 0xdfd3c4: b.ne            #0xdfd454
    // 0xdfd3c8: LoadField: r1 = r0->field_43
    //     0xdfd3c8: ldur            w1, [x0, #0x43]
    // 0xdfd3cc: DecompressPointer r1
    //     0xdfd3cc: add             x1, x1, HEAP, lsl #32
    // 0xdfd3d0: r0 = of()
    //     0xdfd3d0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdfd3d4: LoadField: r1 = r0->field_87
    //     0xdfd3d4: ldur            w1, [x0, #0x87]
    // 0xdfd3d8: DecompressPointer r1
    //     0xdfd3d8: add             x1, x1, HEAP, lsl #32
    // 0xdfd3dc: LoadField: r0 = r1->field_2f
    //     0xdfd3dc: ldur            w0, [x1, #0x2f]
    // 0xdfd3e0: DecompressPointer r0
    //     0xdfd3e0: add             x0, x0, HEAP, lsl #32
    // 0xdfd3e4: stur            x0, [fp, #-0x28]
    // 0xdfd3e8: cmp             w0, NULL
    // 0xdfd3ec: b.eq            #0xdfe158
    // 0xdfd3f0: ldur            x1, [fp, #-0x60]
    // 0xdfd3f4: LoadField: r0 = r1->field_4b
    //     0xdfd3f4: ldur            w0, [x1, #0x4b]
    // 0xdfd3f8: DecompressPointer r0
    //     0xdfd3f8: add             x0, x0, HEAP, lsl #32
    // 0xdfd3fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfd400: cmp             w0, w16
    // 0xdfd404: b.ne            #0xdfd414
    // 0xdfd408: r2 = _colors
    //     0xdfd408: add             x2, PP, #0x26, lsl #12  ; [pp+0x26200] Field <_SnackbarDefaultsM3@773267081._colors@773267081>: late final (offset: 0x4c)
    //     0xdfd40c: ldr             x2, [x2, #0x200]
    // 0xdfd410: r0 = InitLateFinalInstanceField()
    //     0xdfd410: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfd414: LoadField: r1 = r0->field_bb
    //     0xdfd414: ldur            w1, [x0, #0xbb]
    // 0xdfd418: DecompressPointer r1
    //     0xdfd418: add             x1, x1, HEAP, lsl #32
    // 0xdfd41c: cmp             w1, NULL
    // 0xdfd420: b.ne            #0xdfd434
    // 0xdfd424: LoadField: r1 = r0->field_7b
    //     0xdfd424: ldur            w1, [x0, #0x7b]
    // 0xdfd428: DecompressPointer r1
    //     0xdfd428: add             x1, x1, HEAP, lsl #32
    // 0xdfd42c: mov             x0, x1
    // 0xdfd430: b               #0xdfd438
    // 0xdfd434: mov             x0, x1
    // 0xdfd438: str             x0, [SP]
    // 0xdfd43c: ldur            x1, [fp, #-0x28]
    // 0xdfd440: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xdfd440: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xdfd444: ldr             x4, [x4, #0x7f0]
    // 0xdfd448: r0 = copyWith()
    //     0xdfd448: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xdfd44c: mov             x1, x0
    // 0xdfd450: b               #0xdfd4c0
    // 0xdfd454: LoadField: r1 = r0->field_43
    //     0xdfd454: ldur            w1, [x0, #0x43]
    // 0xdfd458: DecompressPointer r1
    //     0xdfd458: add             x1, x1, HEAP, lsl #32
    // 0xdfd45c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfd460: cmp             w1, w16
    // 0xdfd464: b.eq            #0xdfe15c
    // 0xdfd468: LoadField: r2 = r1->field_2f
    //     0xdfd468: ldur            w2, [x1, #0x2f]
    // 0xdfd46c: DecompressPointer r2
    //     0xdfd46c: add             x2, x2, HEAP, lsl #32
    // 0xdfd470: LoadField: r3 = r1->field_3f
    //     0xdfd470: ldur            w3, [x1, #0x3f]
    // 0xdfd474: DecompressPointer r3
    //     0xdfd474: add             x3, x3, HEAP, lsl #32
    // 0xdfd478: LoadField: r1 = r3->field_7
    //     0xdfd478: ldur            w1, [x3, #7]
    // 0xdfd47c: DecompressPointer r1
    //     0xdfd47c: add             x1, x1, HEAP, lsl #32
    // 0xdfd480: r16 = Instance_Brightness
    //     0xdfd480: ldr             x16, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0xdfd484: cmp             w1, w16
    // 0xdfd488: b.ne            #0xdfd494
    // 0xdfd48c: r1 = Instance_Brightness
    //     0xdfd48c: ldr             x1, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xdfd490: b               #0xdfd498
    // 0xdfd494: r1 = Instance_Brightness
    //     0xdfd494: ldr             x1, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0xdfd498: stp             x1, x2, [SP]
    // 0xdfd49c: r1 = Null
    //     0xdfd49c: mov             x1, NULL
    // 0xdfd4a0: r4 = const [0, 0x3, 0x2, 0x1, brightness, 0x2, useMaterial3, 0x1, null]
    //     0xdfd4a0: add             x4, PP, #0x26, lsl #12  ; [pp+0x26210] List(9) [0, 0x3, 0x2, 0x1, "brightness", 0x2, "useMaterial3", 0x1, Null]
    //     0xdfd4a4: ldr             x4, [x4, #0x210]
    // 0xdfd4a8: r0 = ThemeData()
    //     0xdfd4a8: bl              #0x8a9c18  ; [package:flutter/src/material/theme_data.dart] ThemeData::ThemeData
    // 0xdfd4ac: LoadField: r1 = r0->field_87
    //     0xdfd4ac: ldur            w1, [x0, #0x87]
    // 0xdfd4b0: DecompressPointer r1
    //     0xdfd4b0: add             x1, x1, HEAP, lsl #32
    // 0xdfd4b4: LoadField: r0 = r1->field_23
    //     0xdfd4b4: ldur            w0, [x1, #0x23]
    // 0xdfd4b8: DecompressPointer r0
    //     0xdfd4b8: add             x0, x0, HEAP, lsl #32
    // 0xdfd4bc: mov             x1, x0
    // 0xdfd4c0: ldur            x0, [fp, #-8]
    // 0xdfd4c4: stur            x1, [fp, #-0x40]
    // 0xdfd4c8: LoadField: r2 = r0->field_b
    //     0xdfd4c8: ldur            w2, [x0, #0xb]
    // 0xdfd4cc: DecompressPointer r2
    //     0xdfd4cc: add             x2, x2, HEAP, lsl #32
    // 0xdfd4d0: cmp             w2, NULL
    // 0xdfd4d4: b.eq            #0xdfe168
    // 0xdfd4d8: LoadField: r3 = r2->field_2b
    //     0xdfd4d8: ldur            w3, [x2, #0x2b]
    // 0xdfd4dc: DecompressPointer r3
    //     0xdfd4dc: add             x3, x3, HEAP, lsl #32
    // 0xdfd4e0: cmp             w3, NULL
    // 0xdfd4e4: b.ne            #0xdfd4f0
    // 0xdfd4e8: r2 = Null
    //     0xdfd4e8: mov             x2, NULL
    // 0xdfd4ec: b               #0xdfd4f4
    // 0xdfd4f0: mov             x2, x3
    // 0xdfd4f4: cmp             w2, NULL
    // 0xdfd4f8: b.ne            #0xdfd508
    // 0xdfd4fc: r3 = Instance_SnackBarBehavior
    //     0xdfd4fc: add             x3, PP, #0x26, lsl #12  ; [pp+0x26220] Obj!SnackBarBehavior@12c4d61
    //     0xdfd500: ldr             x3, [x3, #0x220]
    // 0xdfd504: b               #0xdfd50c
    // 0xdfd508: mov             x3, x2
    // 0xdfd50c: ldur            x2, [fp, #-0x50]
    // 0xdfd510: LoadField: r4 = r2->field_23
    //     0xdfd510: ldur            w4, [x2, #0x23]
    // 0xdfd514: DecompressPointer r4
    //     0xdfd514: add             x4, x4, HEAP, lsl #32
    // 0xdfd518: stur            x4, [fp, #-0x30]
    // 0xdfd51c: r16 = Instance_SnackBarBehavior
    //     0xdfd51c: add             x16, PP, #0x7a, lsl #12  ; [pp+0x7aa48] Obj!SnackBarBehavior@12c4d41
    //     0xdfd520: ldr             x16, [x16, #0xa48]
    // 0xdfd524: cmp             w3, w16
    // 0xdfd528: r16 = true
    //     0xdfd528: add             x16, NULL, #0x20  ; true
    // 0xdfd52c: r17 = false
    //     0xdfd52c: add             x17, NULL, #0x30  ; false
    // 0xdfd530: csel            x5, x16, x17, eq
    // 0xdfd534: stur            x5, [fp, #-0x28]
    // 0xdfd538: tbnz            w5, #4, #0xdfd544
    // 0xdfd53c: d0 = 16.000000
    //     0xdfd53c: fmov            d0, #16.00000000
    // 0xdfd540: b               #0xdfd548
    // 0xdfd544: d0 = 24.000000
    //     0xdfd544: fmov            d0, #24.00000000
    // 0xdfd548: ldur            x3, [fp, #-0x18]
    // 0xdfd54c: stur            d0, [fp, #-0xb0]
    // 0xdfd550: r0 = EdgeInsetsDirectional()
    //     0xdfd550: bl              #0xb50060  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xdfd554: ldur            d0, [fp, #-0xb0]
    // 0xdfd558: stur            x0, [fp, #-0x48]
    // 0xdfd55c: StoreField: r0->field_7 = d0
    //     0xdfd55c: stur            d0, [x0, #7]
    // 0xdfd560: StoreField: r0->field_f = rZR
    //     0xdfd560: stur            xzr, [x0, #0xf]
    // 0xdfd564: ArrayStore: r0[0] = d0  ; List_8
    //     0xdfd564: stur            d0, [x0, #0x17]
    // 0xdfd568: StoreField: r0->field_1f = rZR
    //     0xdfd568: stur            xzr, [x0, #0x1f]
    // 0xdfd56c: ldur            x2, [fp, #-0x18]
    // 0xdfd570: LoadField: r1 = r2->field_f
    //     0xdfd570: ldur            w1, [x2, #0xf]
    // 0xdfd574: DecompressPointer r1
    //     0xdfd574: add             x1, x1, HEAP, lsl #32
    // 0xdfd578: r0 = of()
    //     0xdfd578: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdfd57c: LoadField: r1 = r0->field_87
    //     0xdfd57c: ldur            w1, [x0, #0x87]
    // 0xdfd580: DecompressPointer r1
    //     0xdfd580: add             x1, x1, HEAP, lsl #32
    // 0xdfd584: LoadField: r0 = r1->field_37
    //     0xdfd584: ldur            w0, [x1, #0x37]
    // 0xdfd588: DecompressPointer r0
    //     0xdfd588: add             x0, x0, HEAP, lsl #32
    // 0xdfd58c: stur            x0, [fp, #-0x58]
    // 0xdfd590: r0 = TextSpan()
    //     0xdfd590: bl              #0xb57880  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0xdfd594: mov             x1, x0
    // 0xdfd598: r0 = ""
    //     0xdfd598: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0xdfd59c: stur            x1, [fp, #-0x68]
    // 0xdfd5a0: StoreField: r1->field_b = r0
    //     0xdfd5a0: stur            w0, [x1, #0xb]
    // 0xdfd5a4: r0 = Instance__DeferringMouseCursor
    //     0xdfd5a4: ldr             x0, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0xdfd5a8: ArrayStore: r1[0] = r0  ; List_4
    //     0xdfd5a8: stur            w0, [x1, #0x17]
    // 0xdfd5ac: ldur            x0, [fp, #-0x58]
    // 0xdfd5b0: StoreField: r1->field_7 = r0
    //     0xdfd5b0: stur            w0, [x1, #7]
    // 0xdfd5b4: r0 = TextPainter()
    //     0xdfd5b4: bl              #0xb13a1c  ; AllocateTextPainterStub -> TextPainter (size=0x48)
    // 0xdfd5b8: stur            x0, [fp, #-0x58]
    // 0xdfd5bc: ldur            x16, [fp, #-0x68]
    // 0xdfd5c0: r30 = 2
    //     0xdfd5c0: mov             lr, #2
    // 0xdfd5c4: stp             lr, x16, [SP, #8]
    // 0xdfd5c8: r16 = Instance_TextDirection
    //     0xdfd5c8: ldr             x16, [PP, #0x25b0]  ; [pp+0x25b0] Obj!TextDirection@12c73a1
    // 0xdfd5cc: str             x16, [SP]
    // 0xdfd5d0: mov             x1, x0
    // 0xdfd5d4: r4 = const [0, 0x4, 0x3, 0x1, maxLines, 0x2, text, 0x1, textDirection, 0x3, null]
    //     0xdfd5d4: add             x4, PP, #0x7c, lsl #12  ; [pp+0x7c220] List(11) [0, 0x4, 0x3, 0x1, "maxLines", 0x2, "text", 0x1, "textDirection", 0x3, Null]
    //     0xdfd5d8: ldr             x4, [x4, #0x220]
    // 0xdfd5dc: r0 = TextPainter()
    //     0xdfd5dc: bl              #0xb135d4  ; [package:flutter/src/painting/text_painter.dart] TextPainter::TextPainter
    // 0xdfd5e0: ldur            x1, [fp, #-0x58]
    // 0xdfd5e4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xdfd5e4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xdfd5e8: r0 = layout()
    //     0xdfd5e8: bl              #0x86018c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::layout
    // 0xdfd5ec: ldur            x1, [fp, #-0x58]
    // 0xdfd5f0: r0 = size()
    //     0xdfd5f0: bl              #0x859c64  ; [package:flutter/src/painting/text_painter.dart] TextPainter::size
    // 0xdfd5f4: LoadField: d0 = r0->field_7
    //     0xdfd5f4: ldur            d0, [x0, #7]
    // 0xdfd5f8: ldur            x0, [fp, #-8]
    // 0xdfd5fc: LoadField: r1 = r0->field_b
    //     0xdfd5fc: ldur            w1, [x0, #0xb]
    // 0xdfd600: DecompressPointer r1
    //     0xdfd600: add             x1, x1, HEAP, lsl #32
    // 0xdfd604: cmp             w1, NULL
    // 0xdfd608: b.eq            #0xdfe16c
    // 0xdfd60c: d1 = 0.000000
    //     0xdfd60c: eor             v1.16b, v1.16b, v1.16b
    // 0xdfd610: fadd            d2, d0, d1
    // 0xdfd614: fadd            d0, d2, d1
    // 0xdfd618: ldur            x1, [fp, #-0x58]
    // 0xdfd61c: stur            d0, [fp, #-0xb0]
    // 0xdfd620: r0 = dispose()
    //     0xdfd620: bl              #0xbcb780  ; [package:flutter/src/painting/text_painter.dart] TextPainter::dispose
    // 0xdfd624: ldur            x0, [fp, #-8]
    // 0xdfd628: LoadField: r1 = r0->field_b
    //     0xdfd628: ldur            w1, [x0, #0xb]
    // 0xdfd62c: DecompressPointer r1
    //     0xdfd62c: add             x1, x1, HEAP, lsl #32
    // 0xdfd630: cmp             w1, NULL
    // 0xdfd634: b.eq            #0xdfe170
    // 0xdfd638: ldur            x2, [fp, #-0x18]
    // 0xdfd63c: LoadField: r1 = r2->field_f
    //     0xdfd63c: ldur            w1, [x2, #0xf]
    // 0xdfd640: DecompressPointer r1
    //     0xdfd640: add             x1, x1, HEAP, lsl #32
    // 0xdfd644: r0 = widthOf()
    //     0xdfd644: bl              #0xd6f80c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::widthOf
    // 0xdfd648: mov             v1.16b, v0.16b
    // 0xdfd64c: d0 = 30.000000
    //     0xdfd64c: fmov            d0, #30.00000000
    // 0xdfd650: fsub            d2, d1, d0
    // 0xdfd654: ldur            x0, [fp, #-8]
    // 0xdfd658: stur            d2, [fp, #-0xb8]
    // 0xdfd65c: LoadField: r1 = r0->field_b
    //     0xdfd65c: ldur            w1, [x0, #0xb]
    // 0xdfd660: DecompressPointer r1
    //     0xdfd660: add             x1, x1, HEAP, lsl #32
    // 0xdfd664: cmp             w1, NULL
    // 0xdfd668: b.eq            #0xdfe174
    // 0xdfd66c: ldur            x3, [fp, #-0x50]
    // 0xdfd670: LoadField: r1 = r3->field_33
    //     0xdfd670: ldur            w1, [x3, #0x33]
    // 0xdfd674: DecompressPointer r1
    //     0xdfd674: add             x1, x1, HEAP, lsl #32
    // 0xdfd678: cmp             w1, NULL
    // 0xdfd67c: b.ne            #0xdfd688
    // 0xdfd680: d1 = 0.250000
    //     0xdfd680: fmov            d1, #0.25000000
    // 0xdfd684: b               #0xdfd690
    // 0xdfd688: LoadField: d0 = r1->field_7
    //     0xdfd688: ldur            d0, [x1, #7]
    // 0xdfd68c: mov             v1.16b, v0.16b
    // 0xdfd690: ldur            d0, [fp, #-0xb0]
    // 0xdfd694: ldur            x4, [fp, #-0x40]
    // 0xdfd698: fdiv            d3, d0, d2
    // 0xdfd69c: fcmp            d3, d1
    // 0xdfd6a0: r16 = true
    //     0xdfd6a0: add             x16, NULL, #0x20  ; true
    // 0xdfd6a4: r17 = false
    //     0xdfd6a4: add             x17, NULL, #0x30  ; false
    // 0xdfd6a8: csel            x5, x16, x17, gt
    // 0xdfd6ac: stur            x5, [fp, #-0x58]
    // 0xdfd6b0: r1 = <Widget>
    //     0xdfd6b0: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdfd6b4: r2 = 0
    //     0xdfd6b4: mov             x2, #0
    // 0xdfd6b8: r0 = _GrowableList()
    //     0xdfd6b8: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xdfd6bc: mov             x1, x0
    // 0xdfd6c0: ldur            x0, [fp, #-8]
    // 0xdfd6c4: stur            x1, [fp, #-0x70]
    // 0xdfd6c8: LoadField: r2 = r0->field_b
    //     0xdfd6c8: ldur            w2, [x0, #0xb]
    // 0xdfd6cc: DecompressPointer r2
    //     0xdfd6cc: add             x2, x2, HEAP, lsl #32
    // 0xdfd6d0: cmp             w2, NULL
    // 0xdfd6d4: b.eq            #0xdfe178
    // 0xdfd6d8: LoadField: r3 = r2->field_b
    //     0xdfd6d8: ldur            w3, [x2, #0xb]
    // 0xdfd6dc: DecompressPointer r3
    //     0xdfd6dc: add             x3, x3, HEAP, lsl #32
    // 0xdfd6e0: stur            x3, [fp, #-0x68]
    // 0xdfd6e4: r0 = DefaultTextStyle()
    //     0xdfd6e4: bl              #0xd0b11c  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xdfd6e8: mov             x1, x0
    // 0xdfd6ec: ldur            x0, [fp, #-0x40]
    // 0xdfd6f0: stur            x1, [fp, #-0x78]
    // 0xdfd6f4: StoreField: r1->field_f = r0
    //     0xdfd6f4: stur            w0, [x1, #0xf]
    // 0xdfd6f8: r0 = true
    //     0xdfd6f8: add             x0, NULL, #0x20  ; true
    // 0xdfd6fc: ArrayStore: r1[0] = r0  ; List_4
    //     0xdfd6fc: stur            w0, [x1, #0x17]
    // 0xdfd700: r2 = Instance_TextOverflow
    //     0xdfd700: add             x2, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xdfd704: ldr             x2, [x2, #0x108]
    // 0xdfd708: StoreField: r1->field_1b = r2
    //     0xdfd708: stur            w2, [x1, #0x1b]
    // 0xdfd70c: r2 = Instance_TextWidthBasis
    //     0xdfd70c: add             x2, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xdfd710: ldr             x2, [x2, #0x110]
    // 0xdfd714: StoreField: r1->field_23 = r2
    //     0xdfd714: stur            w2, [x1, #0x23]
    // 0xdfd718: ldur            x2, [fp, #-0x68]
    // 0xdfd71c: StoreField: r1->field_b = r2
    //     0xdfd71c: stur            w2, [x1, #0xb]
    // 0xdfd720: r0 = Padding()
    //     0xdfd720: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xdfd724: mov             x2, x0
    // 0xdfd728: r0 = Instance_EdgeInsets
    //     0xdfd728: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8c860] Obj!EdgeInsets@129d651
    //     0xdfd72c: ldr             x0, [x0, #0x860]
    // 0xdfd730: stur            x2, [fp, #-0x40]
    // 0xdfd734: StoreField: r2->field_f = r0
    //     0xdfd734: stur            w0, [x2, #0xf]
    // 0xdfd738: ldur            x0, [fp, #-0x78]
    // 0xdfd73c: StoreField: r2->field_b = r0
    //     0xdfd73c: stur            w0, [x2, #0xb]
    // 0xdfd740: r1 = <FlexParentData>
    //     0xdfd740: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xdfd744: ldr             x1, [x1, #0x878]
    // 0xdfd748: r0 = Expanded()
    //     0xdfd748: bl              #0x8a5b10  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0xdfd74c: mov             x3, x0
    // 0xdfd750: r0 = 1
    //     0xdfd750: mov             x0, #1
    // 0xdfd754: stur            x3, [fp, #-0x68]
    // 0xdfd758: StoreField: r3->field_13 = r0
    //     0xdfd758: stur            x0, [x3, #0x13]
    // 0xdfd75c: r0 = Instance_FlexFit
    //     0xdfd75c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15880] Obj!FlexFit@12c4641
    //     0xdfd760: ldr             x0, [x0, #0x880]
    // 0xdfd764: StoreField: r3->field_1b = r0
    //     0xdfd764: stur            w0, [x3, #0x1b]
    // 0xdfd768: ldur            x0, [fp, #-0x40]
    // 0xdfd76c: StoreField: r3->field_b = r0
    //     0xdfd76c: stur            w0, [x3, #0xb]
    // 0xdfd770: r1 = Null
    //     0xdfd770: mov             x1, NULL
    // 0xdfd774: r2 = 2
    //     0xdfd774: mov             x2, #2
    // 0xdfd778: r0 = AllocateArray()
    //     0xdfd778: bl              #0x13df928  ; AllocateArrayStub
    // 0xdfd77c: mov             x2, x0
    // 0xdfd780: ldur            x0, [fp, #-0x68]
    // 0xdfd784: stur            x2, [fp, #-0x40]
    // 0xdfd788: StoreField: r2->field_f = r0
    //     0xdfd788: stur            w0, [x2, #0xf]
    // 0xdfd78c: r1 = <Widget>
    //     0xdfd78c: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdfd790: r0 = AllocateGrowableArray()
    //     0xdfd790: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xdfd794: mov             x3, x0
    // 0xdfd798: ldur            x0, [fp, #-0x40]
    // 0xdfd79c: stur            x3, [fp, #-0x68]
    // 0xdfd7a0: StoreField: r3->field_f = r0
    //     0xdfd7a0: stur            w0, [x3, #0xf]
    // 0xdfd7a4: r0 = 2
    //     0xdfd7a4: mov             x0, #2
    // 0xdfd7a8: StoreField: r3->field_b = r0
    //     0xdfd7a8: stur            w0, [x3, #0xb]
    // 0xdfd7ac: ldur            x4, [fp, #-0x58]
    // 0xdfd7b0: tbz             w4, #4, #0xdfd7c0
    // 0xdfd7b4: mov             x1, x3
    // 0xdfd7b8: ldur            x2, [fp, #-0x70]
    // 0xdfd7bc: r0 = addAll()
    //     0xdfd7bc: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0xdfd7c0: ldur            x0, [fp, #-0x58]
    // 0xdfd7c4: tbnz            w0, #4, #0xdfd89c
    // 0xdfd7c8: ldur            d0, [fp, #-0xb8]
    // 0xdfd7cc: ldur            x1, [fp, #-0x68]
    // 0xdfd7d0: d1 = 0.400000
    //     0xdfd7d0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13368] IMM: double(0.4) from 0x3fd999999999999a
    //     0xdfd7d4: ldr             d1, [x17, #0x368]
    // 0xdfd7d8: fmul            d2, d0, d1
    // 0xdfd7dc: r2 = inline_Allocate_Double()
    //     0xdfd7dc: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xdfd7e0: add             x2, x2, #0x10
    //     0xdfd7e4: cmp             x3, x2
    //     0xdfd7e8: b.ls            #0xdfe17c
    //     0xdfd7ec: str             x2, [THR, #0x60]  ; THR::top
    //     0xdfd7f0: sub             x2, x2, #0xf
    //     0xdfd7f4: mov             x3, #0xe19c
    //     0xdfd7f8: movk            x3, #3, lsl #16
    //     0xdfd7fc: stur            x3, [x2, #-1]
    // 0xdfd800: dmb             ishst
    // 0xdfd804: StoreField: r2->field_7 = d2
    //     0xdfd804: stur            d2, [x2, #7]
    // 0xdfd808: stur            x2, [fp, #-0x40]
    // 0xdfd80c: r0 = SizedBox()
    //     0xdfd80c: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xdfd810: mov             x2, x0
    // 0xdfd814: ldur            x0, [fp, #-0x40]
    // 0xdfd818: stur            x2, [fp, #-0x78]
    // 0xdfd81c: StoreField: r2->field_f = r0
    //     0xdfd81c: stur            w0, [x2, #0xf]
    // 0xdfd820: ldur            x0, [fp, #-0x68]
    // 0xdfd824: LoadField: r1 = r0->field_b
    //     0xdfd824: ldur            w1, [x0, #0xb]
    // 0xdfd828: LoadField: r3 = r0->field_f
    //     0xdfd828: ldur            w3, [x0, #0xf]
    // 0xdfd82c: DecompressPointer r3
    //     0xdfd82c: add             x3, x3, HEAP, lsl #32
    // 0xdfd830: LoadField: r4 = r3->field_b
    //     0xdfd830: ldur            w4, [x3, #0xb]
    // 0xdfd834: r3 = LoadInt32Instr(r1)
    //     0xdfd834: sbfx            x3, x1, #1, #0x1f
    // 0xdfd838: stur            x3, [fp, #-0xa8]
    // 0xdfd83c: r1 = LoadInt32Instr(r4)
    //     0xdfd83c: sbfx            x1, x4, #1, #0x1f
    // 0xdfd840: cmp             x3, x1
    // 0xdfd844: b.ne            #0xdfd850
    // 0xdfd848: mov             x1, x0
    // 0xdfd84c: r0 = _growToNextCapacity()
    //     0xdfd84c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdfd850: ldur            x2, [fp, #-0x68]
    // 0xdfd854: ldur            x3, [fp, #-0xa8]
    // 0xdfd858: add             x0, x3, #1
    // 0xdfd85c: lsl             x1, x0, #1
    // 0xdfd860: StoreField: r2->field_b = r1
    //     0xdfd860: stur            w1, [x2, #0xb]
    // 0xdfd864: LoadField: r1 = r2->field_f
    //     0xdfd864: ldur            w1, [x2, #0xf]
    // 0xdfd868: DecompressPointer r1
    //     0xdfd868: add             x1, x1, HEAP, lsl #32
    // 0xdfd86c: ldur            x0, [fp, #-0x78]
    // 0xdfd870: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdfd870: add             x25, x1, x3, lsl #2
    //     0xdfd874: add             x25, x25, #0xf
    //     0xdfd878: str             w0, [x25]
    //     0xdfd87c: tbz             w0, #0, #0xdfd898
    //     0xdfd880: ldurb           w16, [x1, #-1]
    //     0xdfd884: ldurb           w17, [x0, #-1]
    //     0xdfd888: and             x16, x17, x16, lsr #2
    //     0xdfd88c: tst             x16, HEAP, lsr #32
    //     0xdfd890: b.eq            #0xdfd898
    //     0xdfd894: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdfd898: b               #0xdfd8a0
    // 0xdfd89c: ldur            x2, [fp, #-0x68]
    // 0xdfd8a0: ldur            x0, [fp, #-0x58]
    // 0xdfd8a4: r0 = Row()
    //     0xdfd8a4: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xdfd8a8: mov             x3, x0
    // 0xdfd8ac: r0 = Instance_Axis
    //     0xdfd8ac: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xdfd8b0: stur            x3, [fp, #-0x40]
    // 0xdfd8b4: StoreField: r3->field_f = r0
    //     0xdfd8b4: stur            w0, [x3, #0xf]
    // 0xdfd8b8: r1 = Instance_MainAxisAlignment
    //     0xdfd8b8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xdfd8bc: ldr             x1, [x1, #0x820]
    // 0xdfd8c0: StoreField: r3->field_13 = r1
    //     0xdfd8c0: stur            w1, [x3, #0x13]
    // 0xdfd8c4: r4 = Instance_MainAxisSize
    //     0xdfd8c4: add             x4, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xdfd8c8: ldr             x4, [x4, #0x828]
    // 0xdfd8cc: ArrayStore: r3[0] = r4  ; List_4
    //     0xdfd8cc: stur            w4, [x3, #0x17]
    // 0xdfd8d0: r5 = Instance_CrossAxisAlignment
    //     0xdfd8d0: add             x5, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xdfd8d4: ldr             x5, [x5, #0x888]
    // 0xdfd8d8: StoreField: r3->field_1b = r5
    //     0xdfd8d8: stur            w5, [x3, #0x1b]
    // 0xdfd8dc: r6 = Instance_VerticalDirection
    //     0xdfd8dc: add             x6, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xdfd8e0: ldr             x6, [x6, #0x838]
    // 0xdfd8e4: StoreField: r3->field_23 = r6
    //     0xdfd8e4: stur            w6, [x3, #0x23]
    // 0xdfd8e8: r7 = Instance_Clip
    //     0xdfd8e8: add             x7, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdfd8ec: ldr             x7, [x7, #0x840]
    // 0xdfd8f0: StoreField: r3->field_2b = r7
    //     0xdfd8f0: stur            w7, [x3, #0x2b]
    // 0xdfd8f4: StoreField: r3->field_2f = rZR
    //     0xdfd8f4: stur            xzr, [x3, #0x2f]
    // 0xdfd8f8: ldur            x1, [fp, #-0x68]
    // 0xdfd8fc: StoreField: r3->field_b = r1
    //     0xdfd8fc: stur            w1, [x3, #0xb]
    // 0xdfd900: r1 = Null
    //     0xdfd900: mov             x1, NULL
    // 0xdfd904: r2 = 2
    //     0xdfd904: mov             x2, #2
    // 0xdfd908: r0 = AllocateArray()
    //     0xdfd908: bl              #0x13df928  ; AllocateArrayStub
    // 0xdfd90c: mov             x2, x0
    // 0xdfd910: ldur            x0, [fp, #-0x40]
    // 0xdfd914: stur            x2, [fp, #-0x68]
    // 0xdfd918: StoreField: r2->field_f = r0
    //     0xdfd918: stur            w0, [x2, #0xf]
    // 0xdfd91c: r1 = <Widget>
    //     0xdfd91c: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdfd920: r0 = AllocateGrowableArray()
    //     0xdfd920: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xdfd924: mov             x1, x0
    // 0xdfd928: ldur            x0, [fp, #-0x68]
    // 0xdfd92c: stur            x1, [fp, #-0x40]
    // 0xdfd930: StoreField: r1->field_f = r0
    //     0xdfd930: stur            w0, [x1, #0xf]
    // 0xdfd934: r0 = 2
    //     0xdfd934: mov             x0, #2
    // 0xdfd938: StoreField: r1->field_b = r0
    //     0xdfd938: stur            w0, [x1, #0xb]
    // 0xdfd93c: ldur            x0, [fp, #-0x58]
    // 0xdfd940: tbnz            w0, #4, #0xdfda0c
    // 0xdfd944: ldur            x0, [fp, #-0x70]
    // 0xdfd948: r0 = Row()
    //     0xdfd948: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xdfd94c: mov             x1, x0
    // 0xdfd950: r0 = Instance_Axis
    //     0xdfd950: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xdfd954: stur            x1, [fp, #-0x58]
    // 0xdfd958: StoreField: r1->field_f = r0
    //     0xdfd958: stur            w0, [x1, #0xf]
    // 0xdfd95c: r2 = Instance_MainAxisAlignment
    //     0xdfd95c: add             x2, PP, #0x18, lsl #12  ; [pp+0x182b8] Obj!MainAxisAlignment@12c45e1
    //     0xdfd960: ldr             x2, [x2, #0x2b8]
    // 0xdfd964: StoreField: r1->field_13 = r2
    //     0xdfd964: stur            w2, [x1, #0x13]
    // 0xdfd968: r2 = Instance_MainAxisSize
    //     0xdfd968: add             x2, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xdfd96c: ldr             x2, [x2, #0x828]
    // 0xdfd970: ArrayStore: r1[0] = r2  ; List_4
    //     0xdfd970: stur            w2, [x1, #0x17]
    // 0xdfd974: r2 = Instance_CrossAxisAlignment
    //     0xdfd974: add             x2, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xdfd978: ldr             x2, [x2, #0x888]
    // 0xdfd97c: StoreField: r1->field_1b = r2
    //     0xdfd97c: stur            w2, [x1, #0x1b]
    // 0xdfd980: r2 = Instance_VerticalDirection
    //     0xdfd980: add             x2, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xdfd984: ldr             x2, [x2, #0x838]
    // 0xdfd988: StoreField: r1->field_23 = r2
    //     0xdfd988: stur            w2, [x1, #0x23]
    // 0xdfd98c: r3 = Instance_Clip
    //     0xdfd98c: add             x3, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdfd990: ldr             x3, [x3, #0x840]
    // 0xdfd994: StoreField: r1->field_2b = r3
    //     0xdfd994: stur            w3, [x1, #0x2b]
    // 0xdfd998: StoreField: r1->field_2f = rZR
    //     0xdfd998: stur            xzr, [x1, #0x2f]
    // 0xdfd99c: ldur            x4, [fp, #-0x70]
    // 0xdfd9a0: StoreField: r1->field_b = r4
    //     0xdfd9a0: stur            w4, [x1, #0xb]
    // 0xdfd9a4: r0 = Padding()
    //     0xdfd9a4: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xdfd9a8: mov             x2, x0
    // 0xdfd9ac: r0 = Instance_EdgeInsets
    //     0xdfd9ac: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8c868] Obj!EdgeInsets@129d621
    //     0xdfd9b0: ldr             x0, [x0, #0x868]
    // 0xdfd9b4: stur            x2, [fp, #-0x68]
    // 0xdfd9b8: StoreField: r2->field_f = r0
    //     0xdfd9b8: stur            w0, [x2, #0xf]
    // 0xdfd9bc: ldur            x0, [fp, #-0x58]
    // 0xdfd9c0: StoreField: r2->field_b = r0
    //     0xdfd9c0: stur            w0, [x2, #0xb]
    // 0xdfd9c4: ldur            x1, [fp, #-0x40]
    // 0xdfd9c8: r0 = _growToNextCapacity()
    //     0xdfd9c8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdfd9cc: ldur            x2, [fp, #-0x40]
    // 0xdfd9d0: r0 = 4
    //     0xdfd9d0: mov             x0, #4
    // 0xdfd9d4: StoreField: r2->field_b = r0
    //     0xdfd9d4: stur            w0, [x2, #0xb]
    // 0xdfd9d8: LoadField: r1 = r2->field_f
    //     0xdfd9d8: ldur            w1, [x2, #0xf]
    // 0xdfd9dc: DecompressPointer r1
    //     0xdfd9dc: add             x1, x1, HEAP, lsl #32
    // 0xdfd9e0: ldur            x0, [fp, #-0x68]
    // 0xdfd9e4: ArrayStore: r1[1] = r0  ; List_4
    //     0xdfd9e4: add             x25, x1, #0x13
    //     0xdfd9e8: str             w0, [x25]
    //     0xdfd9ec: tbz             w0, #0, #0xdfda08
    //     0xdfd9f0: ldurb           w16, [x1, #-1]
    //     0xdfd9f4: ldurb           w17, [x0, #-1]
    //     0xdfd9f8: and             x16, x17, x16, lsr #2
    //     0xdfd9fc: tst             x16, HEAP, lsr #32
    //     0xdfda00: b.eq            #0xdfda08
    //     0xdfda04: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdfda08: b               #0xdfda10
    // 0xdfda0c: mov             x2, x1
    // 0xdfda10: ldur            x0, [fp, #-0x48]
    // 0xdfda14: ldur            x1, [fp, #-0x28]
    // 0xdfda18: r0 = Wrap()
    //     0xdfda18: bl              #0xdfe214  ; AllocateWrapStub -> Wrap (size=0x3c)
    // 0xdfda1c: mov             x1, x0
    // 0xdfda20: r0 = Instance_Axis
    //     0xdfda20: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xdfda24: stur            x1, [fp, #-0x58]
    // 0xdfda28: StoreField: r1->field_f = r0
    //     0xdfda28: stur            w0, [x1, #0xf]
    // 0xdfda2c: r0 = Instance_WrapAlignment
    //     0xdfda2c: add             x0, PP, #0x18, lsl #12  ; [pp+0x18348] Obj!WrapAlignment@12c40c1
    //     0xdfda30: ldr             x0, [x0, #0x348]
    // 0xdfda34: StoreField: r1->field_13 = r0
    //     0xdfda34: stur            w0, [x1, #0x13]
    // 0xdfda38: ArrayStore: r1[0] = rZR  ; List_8
    //     0xdfda38: stur            xzr, [x1, #0x17]
    // 0xdfda3c: StoreField: r1->field_1f = r0
    //     0xdfda3c: stur            w0, [x1, #0x1f]
    // 0xdfda40: StoreField: r1->field_23 = rZR
    //     0xdfda40: stur            xzr, [x1, #0x23]
    // 0xdfda44: r0 = Instance_WrapCrossAlignment
    //     0xdfda44: add             x0, PP, #0x18, lsl #12  ; [pp+0x18350] Obj!WrapCrossAlignment@12c4001
    //     0xdfda48: ldr             x0, [x0, #0x350]
    // 0xdfda4c: StoreField: r1->field_2b = r0
    //     0xdfda4c: stur            w0, [x1, #0x2b]
    // 0xdfda50: r0 = Instance_VerticalDirection
    //     0xdfda50: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xdfda54: ldr             x0, [x0, #0x838]
    // 0xdfda58: StoreField: r1->field_33 = r0
    //     0xdfda58: stur            w0, [x1, #0x33]
    // 0xdfda5c: r0 = Instance_Clip
    //     0xdfda5c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdfda60: ldr             x0, [x0, #0x840]
    // 0xdfda64: StoreField: r1->field_37 = r0
    //     0xdfda64: stur            w0, [x1, #0x37]
    // 0xdfda68: ldur            x0, [fp, #-0x40]
    // 0xdfda6c: StoreField: r1->field_b = r0
    //     0xdfda6c: stur            w0, [x1, #0xb]
    // 0xdfda70: r0 = Padding()
    //     0xdfda70: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xdfda74: mov             x1, x0
    // 0xdfda78: ldur            x0, [fp, #-0x48]
    // 0xdfda7c: stur            x1, [fp, #-0x40]
    // 0xdfda80: StoreField: r1->field_f = r0
    //     0xdfda80: stur            w0, [x1, #0xf]
    // 0xdfda84: ldur            x0, [fp, #-0x58]
    // 0xdfda88: StoreField: r1->field_b = r0
    //     0xdfda88: stur            w0, [x1, #0xb]
    // 0xdfda8c: ldur            x0, [fp, #-0x28]
    // 0xdfda90: tbz             w0, #4, #0xdfdad0
    // 0xdfda94: r0 = SafeArea()
    //     0xdfda94: bl              #0xd73100  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0xdfda98: mov             x1, x0
    // 0xdfda9c: r0 = true
    //     0xdfda9c: add             x0, NULL, #0x20  ; true
    // 0xdfdaa0: StoreField: r1->field_b = r0
    //     0xdfdaa0: stur            w0, [x1, #0xb]
    // 0xdfdaa4: r2 = false
    //     0xdfdaa4: add             x2, NULL, #0x30  ; false
    // 0xdfdaa8: StoreField: r1->field_f = r2
    //     0xdfdaa8: stur            w2, [x1, #0xf]
    // 0xdfdaac: StoreField: r1->field_13 = r0
    //     0xdfdaac: stur            w0, [x1, #0x13]
    // 0xdfdab0: ArrayStore: r1[0] = r0  ; List_4
    //     0xdfdab0: stur            w0, [x1, #0x17]
    // 0xdfdab4: r3 = Instance_EdgeInsets
    //     0xdfdab4: ldr             x3, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xdfdab8: StoreField: r1->field_1b = r3
    //     0xdfdab8: stur            w3, [x1, #0x1b]
    // 0xdfdabc: StoreField: r1->field_1f = r2
    //     0xdfdabc: stur            w2, [x1, #0x1f]
    // 0xdfdac0: ldur            x4, [fp, #-0x40]
    // 0xdfdac4: StoreField: r1->field_23 = r4
    //     0xdfdac4: stur            w4, [x1, #0x23]
    // 0xdfdac8: mov             x5, x1
    // 0xdfdacc: b               #0xdfdae4
    // 0xdfdad0: mov             x4, x1
    // 0xdfdad4: r0 = true
    //     0xdfdad4: add             x0, NULL, #0x20  ; true
    // 0xdfdad8: r2 = false
    //     0xdfdad8: add             x2, NULL, #0x30  ; false
    // 0xdfdadc: r3 = Instance_EdgeInsets
    //     0xdfdadc: ldr             x3, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xdfdae0: mov             x5, x4
    // 0xdfdae4: ldur            x4, [fp, #-8]
    // 0xdfdae8: ldur            x1, [fp, #-0x50]
    // 0xdfdaec: stur            x5, [fp, #-0x40]
    // 0xdfdaf0: LoadField: r6 = r4->field_b
    //     0xdfdaf0: ldur            w6, [x4, #0xb]
    // 0xdfdaf4: DecompressPointer r6
    //     0xdfdaf4: add             x6, x6, HEAP, lsl #32
    // 0xdfdaf8: cmp             w6, NULL
    // 0xdfdafc: b.eq            #0xdfe198
    // 0xdfdb00: ArrayLoad: r7 = r1[0]  ; List_4
    //     0xdfdb00: ldur            w7, [x1, #0x17]
    // 0xdfdb04: DecompressPointer r7
    //     0xdfdb04: add             x7, x7, HEAP, lsl #32
    // 0xdfdb08: cmp             w7, NULL
    // 0xdfdb0c: b.ne            #0xdfdb58
    // 0xdfdb10: ldur            x1, [fp, #-0xa0]
    // 0xdfdb14: r17 = 5066
    //     0xdfdb14: mov             x17, #0x13ca
    // 0xdfdb18: cmp             x1, x17
    // 0xdfdb1c: b.eq            #0xdfdb3c
    // 0xdfdb20: r17 = 5067
    //     0xdfdb20: mov             x17, #0x13cb
    // 0xdfdb24: cmp             x1, x17
    // 0xdfdb28: b.ne            #0xdfdb3c
    // 0xdfdb2c: ldur            x8, [fp, #-0x60]
    // 0xdfdb30: r7 = 6.000000
    //     0xdfdb30: add             x7, PP, #0x1c, lsl #12  ; [pp+0x1c438] 6
    //     0xdfdb34: ldr             x7, [x7, #0x438]
    // 0xdfdb38: b               #0xdfdb48
    // 0xdfdb3c: ldur            x8, [fp, #-0x60]
    // 0xdfdb40: ArrayLoad: r7 = r8[0]  ; List_4
    //     0xdfdb40: ldur            w7, [x8, #0x17]
    // 0xdfdb44: DecompressPointer r7
    //     0xdfdb44: add             x7, x7, HEAP, lsl #32
    // 0xdfdb48: cmp             w7, NULL
    // 0xdfdb4c: b.eq            #0xdfe19c
    // 0xdfdb50: LoadField: d0 = r7->field_7
    //     0xdfdb50: ldur            d0, [x7, #7]
    // 0xdfdb54: b               #0xdfdb64
    // 0xdfdb58: ldur            x8, [fp, #-0x60]
    // 0xdfdb5c: ldur            x1, [fp, #-0xa0]
    // 0xdfdb60: LoadField: d0 = r7->field_7
    //     0xdfdb60: ldur            d0, [x7, #7]
    // 0xdfdb64: stur            d0, [fp, #-0xb0]
    // 0xdfdb68: LoadField: r7 = r6->field_f
    //     0xdfdb68: ldur            w7, [x6, #0xf]
    // 0xdfdb6c: DecompressPointer r7
    //     0xdfdb6c: add             x7, x7, HEAP, lsl #32
    // 0xdfdb70: cmp             w7, NULL
    // 0xdfdb74: b.ne            #0xdfdb80
    // 0xdfdb78: r6 = Null
    //     0xdfdb78: mov             x6, NULL
    // 0xdfdb7c: b               #0xdfdb84
    // 0xdfdb80: mov             x6, x7
    // 0xdfdb84: cmp             w6, NULL
    // 0xdfdb88: b.ne            #0xdfdc20
    // 0xdfdb8c: r17 = 5066
    //     0xdfdb8c: mov             x17, #0x13ca
    // 0xdfdb90: cmp             x1, x17
    // 0xdfdb94: b.ne            #0xdfdba8
    // 0xdfdb98: LoadField: r1 = r8->field_7
    //     0xdfdb98: ldur            w1, [x8, #7]
    // 0xdfdb9c: DecompressPointer r1
    //     0xdfdb9c: add             x1, x1, HEAP, lsl #32
    // 0xdfdba0: mov             x0, x1
    // 0xdfdba4: b               #0xdfdc18
    // 0xdfdba8: r17 = 5067
    //     0xdfdba8: mov             x17, #0x13cb
    // 0xdfdbac: cmp             x1, x17
    // 0xdfdbb0: b.ne            #0xdfdc00
    // 0xdfdbb4: mov             x1, x8
    // 0xdfdbb8: LoadField: r0 = r1->field_4b
    //     0xdfdbb8: ldur            w0, [x1, #0x4b]
    // 0xdfdbbc: DecompressPointer r0
    //     0xdfdbbc: add             x0, x0, HEAP, lsl #32
    // 0xdfdbc0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfdbc4: cmp             w0, w16
    // 0xdfdbc8: b.ne            #0xdfdbd8
    // 0xdfdbcc: r2 = _colors
    //     0xdfdbcc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26200] Field <_SnackbarDefaultsM3@773267081._colors@773267081>: late final (offset: 0x4c)
    //     0xdfdbd0: ldr             x2, [x2, #0x200]
    // 0xdfdbd4: r0 = InitLateFinalInstanceField()
    //     0xdfdbd4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfdbd8: LoadField: r1 = r0->field_b7
    //     0xdfdbd8: ldur            w1, [x0, #0xb7]
    // 0xdfdbdc: DecompressPointer r1
    //     0xdfdbdc: add             x1, x1, HEAP, lsl #32
    // 0xdfdbe0: cmp             w1, NULL
    // 0xdfdbe4: b.ne            #0xdfdbf8
    // 0xdfdbe8: LoadField: r1 = r0->field_7f
    //     0xdfdbe8: ldur            w1, [x0, #0x7f]
    // 0xdfdbec: DecompressPointer r1
    //     0xdfdbec: add             x1, x1, HEAP, lsl #32
    // 0xdfdbf0: mov             x0, x1
    // 0xdfdbf4: b               #0xdfdc18
    // 0xdfdbf8: mov             x0, x1
    // 0xdfdbfc: b               #0xdfdc18
    // 0xdfdc00: r0 = LoadClassIdInstr(r8)
    //     0xdfdc00: ldur            x0, [x8, #-1]
    //     0xdfdc04: ubfx            x0, x0, #0xc, #0x14
    // 0xdfdc08: mov             x1, x8
    // 0xdfdc0c: r0 = GDT[cid_x0 + -0xf44]()
    //     0xdfdc0c: sub             lr, x0, #0xf44
    //     0xdfdc10: ldr             lr, [x21, lr, lsl #3]
    //     0xdfdc14: blr             lr
    // 0xdfdc18: mov             x2, x0
    // 0xdfdc1c: b               #0xdfdc24
    // 0xdfdc20: mov             x2, x6
    // 0xdfdc24: ldur            x0, [fp, #-8]
    // 0xdfdc28: ldur            x1, [fp, #-0x28]
    // 0xdfdc2c: stur            x2, [fp, #-0x58]
    // 0xdfdc30: LoadField: r3 = r0->field_b
    //     0xdfdc30: ldur            w3, [x0, #0xb]
    // 0xdfdc34: DecompressPointer r3
    //     0xdfdc34: add             x3, x3, HEAP, lsl #32
    // 0xdfdc38: cmp             w3, NULL
    // 0xdfdc3c: b.eq            #0xdfe1a0
    // 0xdfdc40: tbnz            w1, #4, #0xdfdc50
    // 0xdfdc44: r4 = Instance_RoundedRectangleBorder
    //     0xdfdc44: add             x4, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0xdfdc48: ldr             x4, [x4, #0x218]
    // 0xdfdc4c: b               #0xdfdc54
    // 0xdfdc50: r4 = Null
    //     0xdfdc50: mov             x4, NULL
    // 0xdfdc54: ldur            x3, [fp, #-0x10]
    // 0xdfdc58: stur            x4, [fp, #-0x50]
    // 0xdfdc5c: tbnz            w3, #4, #0xdfdc68
    // 0xdfdc60: ldur            x5, [fp, #-0x38]
    // 0xdfdc64: b               #0xdfdc70
    // 0xdfdc68: ldur            x5, [fp, #-0x38]
    // 0xdfdc6c: tbnz            w5, #4, #0xdfdc80
    // 0xdfdc70: ldur            x5, [fp, #-0x40]
    // 0xdfdc74: mov             x3, x4
    // 0xdfdc78: r0 = false
    //     0xdfdc78: add             x0, NULL, #0x30  ; false
    // 0xdfdc7c: b               #0xdfdcc8
    // 0xdfdc80: ldur            x6, [fp, #-0x40]
    // 0xdfdc84: LoadField: r7 = r0->field_1f
    //     0xdfdc84: ldur            w7, [x0, #0x1f]
    // 0xdfdc88: DecompressPointer r7
    //     0xdfdc88: add             x7, x7, HEAP, lsl #32
    // 0xdfdc8c: stur            x7, [fp, #-0x48]
    // 0xdfdc90: cmp             w7, NULL
    // 0xdfdc94: b.eq            #0xdfe1a4
    // 0xdfdc98: r0 = FadeTransition()
    //     0xdfdc98: bl              #0xb28358  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0xdfdc9c: mov             x1, x0
    // 0xdfdca0: ldur            x0, [fp, #-0x48]
    // 0xdfdca4: StoreField: r1->field_f = r0
    //     0xdfdca4: stur            w0, [x1, #0xf]
    // 0xdfdca8: r0 = false
    //     0xdfdca8: add             x0, NULL, #0x30  ; false
    // 0xdfdcac: StoreField: r1->field_13 = r0
    //     0xdfdcac: stur            w0, [x1, #0x13]
    // 0xdfdcb0: ldur            x2, [fp, #-0x40]
    // 0xdfdcb4: StoreField: r1->field_b = r2
    //     0xdfdcb4: stur            w2, [x1, #0xb]
    // 0xdfdcb8: mov             x5, x1
    // 0xdfdcbc: ldur            x2, [fp, #-0x58]
    // 0xdfdcc0: ldur            x3, [fp, #-0x50]
    // 0xdfdcc4: ldur            x1, [fp, #-0x28]
    // 0xdfdcc8: ldur            x4, [fp, #-0x20]
    // 0xdfdccc: ldur            d0, [fp, #-0xb0]
    // 0xdfdcd0: stur            x5, [fp, #-0x40]
    // 0xdfdcd4: r0 = Theme()
    //     0xdfdcd4: bl              #0xd2f05c  ; AllocateThemeStub -> Theme (size=0x14)
    // 0xdfdcd8: mov             x1, x0
    // 0xdfdcdc: ldur            x0, [fp, #-0x20]
    // 0xdfdce0: stur            x1, [fp, #-0x48]
    // 0xdfdce4: StoreField: r1->field_b = r0
    //     0xdfdce4: stur            w0, [x1, #0xb]
    // 0xdfdce8: ldur            x0, [fp, #-0x40]
    // 0xdfdcec: StoreField: r1->field_f = r0
    //     0xdfdcec: stur            w0, [x1, #0xf]
    // 0xdfdcf0: r0 = Material()
    //     0xdfdcf0: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xdfdcf4: mov             x1, x0
    // 0xdfdcf8: r0 = Instance_MaterialType
    //     0xdfdcf8: add             x0, PP, #0x17, lsl #12  ; [pp+0x17210] Obj!MaterialType@12c5341
    //     0xdfdcfc: ldr             x0, [x0, #0x210]
    // 0xdfdd00: stur            x1, [fp, #-0x20]
    // 0xdfdd04: StoreField: r1->field_f = r0
    //     0xdfdd04: stur            w0, [x1, #0xf]
    // 0xdfdd08: ldur            d0, [fp, #-0xb0]
    // 0xdfdd0c: ArrayStore: r1[0] = d0  ; List_8
    //     0xdfdd0c: stur            d0, [x1, #0x17]
    // 0xdfdd10: ldur            x0, [fp, #-0x58]
    // 0xdfdd14: StoreField: r1->field_1f = r0
    //     0xdfdd14: stur            w0, [x1, #0x1f]
    // 0xdfdd18: ldur            x0, [fp, #-0x50]
    // 0xdfdd1c: StoreField: r1->field_2f = r0
    //     0xdfdd1c: stur            w0, [x1, #0x2f]
    // 0xdfdd20: r0 = true
    //     0xdfdd20: add             x0, NULL, #0x20  ; true
    // 0xdfdd24: StoreField: r1->field_33 = r0
    //     0xdfdd24: stur            w0, [x1, #0x33]
    // 0xdfdd28: r2 = Instance_Clip
    //     0xdfdd28: add             x2, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xdfdd2c: ldr             x2, [x2, #0x850]
    // 0xdfdd30: StoreField: r1->field_37 = r2
    //     0xdfdd30: stur            w2, [x1, #0x37]
    // 0xdfdd34: r3 = Instance_Duration
    //     0xdfdd34: add             x3, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xdfdd38: ldr             x3, [x3, #0x318]
    // 0xdfdd3c: StoreField: r1->field_3b = r3
    //     0xdfdd3c: stur            w3, [x1, #0x3b]
    // 0xdfdd40: ldur            x4, [fp, #-0x48]
    // 0xdfdd44: StoreField: r1->field_b = r4
    //     0xdfdd44: stur            w4, [x1, #0xb]
    // 0xdfdd48: r4 = false
    //     0xdfdd48: add             x4, NULL, #0x30  ; false
    // 0xdfdd4c: StoreField: r1->field_13 = r4
    //     0xdfdd4c: stur            w4, [x1, #0x13]
    // 0xdfdd50: ldur            x5, [fp, #-0x28]
    // 0xdfdd54: tbnz            w5, #4, #0xdfde40
    // 0xdfdd58: ldur            x6, [fp, #-0x30]
    // 0xdfdd5c: cmp             w6, NULL
    // 0xdfdd60: b.eq            #0xdfddd8
    // 0xdfdd64: r7 = Instance_EdgeInsets
    //     0xdfdd64: add             x7, PP, #0x26, lsl #12  ; [pp+0x26228] Obj!EdgeInsets@129d681
    //     0xdfdd68: ldr             x7, [x7, #0x228]
    // 0xdfdd6c: LoadField: d0 = r7->field_f
    //     0xdfdd6c: ldur            d0, [x7, #0xf]
    // 0xdfdd70: stur            d0, [fp, #-0xb8]
    // 0xdfdd74: LoadField: d1 = r7->field_1f
    //     0xdfdd74: ldur            d1, [x7, #0x1f]
    // 0xdfdd78: stur            d1, [fp, #-0xb0]
    // 0xdfdd7c: r0 = EdgeInsets()
    //     0xdfdd7c: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xdfdd80: stur            x0, [fp, #-0x40]
    // 0xdfdd84: StoreField: r0->field_7 = rZR
    //     0xdfdd84: stur            xzr, [x0, #7]
    // 0xdfdd88: ldur            d0, [fp, #-0xb8]
    // 0xdfdd8c: StoreField: r0->field_f = d0
    //     0xdfdd8c: stur            d0, [x0, #0xf]
    // 0xdfdd90: ArrayStore: r0[0] = rZR  ; List_8
    //     0xdfdd90: stur            xzr, [x0, #0x17]
    // 0xdfdd94: ldur            d0, [fp, #-0xb0]
    // 0xdfdd98: StoreField: r0->field_1f = d0
    //     0xdfdd98: stur            d0, [x0, #0x1f]
    // 0xdfdd9c: r0 = SizedBox()
    //     0xdfdd9c: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xdfdda0: mov             x1, x0
    // 0xdfdda4: ldur            x0, [fp, #-0x30]
    // 0xdfdda8: stur            x1, [fp, #-0x48]
    // 0xdfddac: StoreField: r1->field_f = r0
    //     0xdfddac: stur            w0, [x1, #0xf]
    // 0xdfddb0: ldur            x0, [fp, #-0x20]
    // 0xdfddb4: StoreField: r1->field_b = r0
    //     0xdfddb4: stur            w0, [x1, #0xb]
    // 0xdfddb8: r0 = Padding()
    //     0xdfddb8: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xdfddbc: mov             x1, x0
    // 0xdfddc0: ldur            x0, [fp, #-0x40]
    // 0xdfddc4: StoreField: r1->field_f = r0
    //     0xdfddc4: stur            w0, [x1, #0xf]
    // 0xdfddc8: ldur            x0, [fp, #-0x48]
    // 0xdfddcc: StoreField: r1->field_b = r0
    //     0xdfddcc: stur            w0, [x1, #0xb]
    // 0xdfddd0: mov             x0, x1
    // 0xdfddd4: b               #0xdfde04
    // 0xdfddd8: mov             x0, x1
    // 0xdfdddc: r7 = Instance_EdgeInsets
    //     0xdfdddc: add             x7, PP, #0x26, lsl #12  ; [pp+0x26228] Obj!EdgeInsets@129d681
    //     0xdfdde0: ldr             x7, [x7, #0x228]
    // 0xdfdde4: r0 = Padding()
    //     0xdfdde4: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xdfdde8: mov             x1, x0
    // 0xdfddec: r0 = Instance_EdgeInsets
    //     0xdfddec: add             x0, PP, #0x26, lsl #12  ; [pp+0x26228] Obj!EdgeInsets@129d681
    //     0xdfddf0: ldr             x0, [x0, #0x228]
    // 0xdfddf4: StoreField: r1->field_f = r0
    //     0xdfddf4: stur            w0, [x1, #0xf]
    // 0xdfddf8: ldur            x0, [fp, #-0x20]
    // 0xdfddfc: StoreField: r1->field_b = r0
    //     0xdfddfc: stur            w0, [x1, #0xb]
    // 0xdfde00: mov             x0, x1
    // 0xdfde04: stur            x0, [fp, #-0x30]
    // 0xdfde08: r0 = SafeArea()
    //     0xdfde08: bl              #0xd73100  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0xdfde0c: r1 = true
    //     0xdfde0c: add             x1, NULL, #0x20  ; true
    // 0xdfde10: StoreField: r0->field_b = r1
    //     0xdfde10: stur            w1, [x0, #0xb]
    // 0xdfde14: r2 = false
    //     0xdfde14: add             x2, NULL, #0x30  ; false
    // 0xdfde18: StoreField: r0->field_f = r2
    //     0xdfde18: stur            w2, [x0, #0xf]
    // 0xdfde1c: StoreField: r0->field_13 = r1
    //     0xdfde1c: stur            w1, [x0, #0x13]
    // 0xdfde20: ArrayStore: r0[0] = r2  ; List_4
    //     0xdfde20: stur            w2, [x0, #0x17]
    // 0xdfde24: r3 = Instance_EdgeInsets
    //     0xdfde24: ldr             x3, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xdfde28: StoreField: r0->field_1b = r3
    //     0xdfde28: stur            w3, [x0, #0x1b]
    // 0xdfde2c: StoreField: r0->field_1f = r2
    //     0xdfde2c: stur            w2, [x0, #0x1f]
    // 0xdfde30: ldur            x3, [fp, #-0x30]
    // 0xdfde34: StoreField: r0->field_23 = r3
    //     0xdfde34: stur            w3, [x0, #0x23]
    // 0xdfde38: mov             x4, x0
    // 0xdfde3c: b               #0xdfde54
    // 0xdfde40: mov             x16, x1
    // 0xdfde44: mov             x1, x0
    // 0xdfde48: mov             x0, x16
    // 0xdfde4c: mov             x2, x4
    // 0xdfde50: mov             x4, x0
    // 0xdfde54: ldur            x0, [fp, #-8]
    // 0xdfde58: ldur            x3, [fp, #-0x10]
    // 0xdfde5c: stur            x4, [fp, #-0x30]
    // 0xdfde60: LoadField: r5 = r0->field_27
    //     0xdfde60: ldur            w5, [x0, #0x27]
    // 0xdfde64: DecompressPointer r5
    //     0xdfde64: add             x5, x5, HEAP, lsl #32
    // 0xdfde68: stur            x5, [fp, #-0x20]
    // 0xdfde6c: r0 = Dismissible()
    //     0xdfde6c: bl              #0x91801c  ; AllocateDismissibleStub -> Dismissible (size=0x44)
    // 0xdfde70: mov             x3, x0
    // 0xdfde74: ldur            x0, [fp, #-0x30]
    // 0xdfde78: stur            x3, [fp, #-0x40]
    // 0xdfde7c: StoreField: r3->field_b = r0
    //     0xdfde7c: stur            w0, [x3, #0xb]
    // 0xdfde80: ldur            x2, [fp, #-0x18]
    // 0xdfde84: r1 = Function '<anonymous closure>':.
    //     0xdfde84: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c870] AnonymousClosure: (0xdfe4c8), in [package:flutter/src/material/snack_bar.dart] _SnackBarState::build (0xdfd07c)
    //     0xdfde88: ldr             x1, [x1, #0x870]
    // 0xdfde8c: r0 = AllocateClosure()
    //     0xdfde8c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfde90: mov             x1, x0
    // 0xdfde94: ldur            x0, [fp, #-0x40]
    // 0xdfde98: StoreField: r0->field_1b = r1
    //     0xdfde98: stur            w1, [x0, #0x1b]
    // 0xdfde9c: r1 = Instance_DismissDirection
    //     0xdfde9c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16e50] Obj!DismissDirection@12c3341
    //     0xdfdea0: ldr             x1, [x1, #0xe50]
    // 0xdfdea4: StoreField: r0->field_1f = r1
    //     0xdfdea4: stur            w1, [x0, #0x1f]
    // 0xdfdea8: r1 = _ConstMap len:0
    //     0xdfdea8: add             x1, PP, #0x16, lsl #12  ; [pp+0x16e68] Map<DismissDirection, double>(0)
    //     0xdfdeac: ldr             x1, [x1, #0xe68]
    // 0xdfdeb0: StoreField: r0->field_27 = r1
    //     0xdfdeb0: stur            w1, [x0, #0x27]
    // 0xdfdeb4: r1 = Instance_Duration
    //     0xdfdeb4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xdfdeb8: ldr             x1, [x1, #0x318]
    // 0xdfdebc: StoreField: r0->field_2b = r1
    //     0xdfdebc: stur            w1, [x0, #0x2b]
    // 0xdfdec0: StoreField: r0->field_2f = rZR
    //     0xdfdec0: stur            xzr, [x0, #0x2f]
    // 0xdfdec4: r1 = Instance_DragStartBehavior
    //     0xdfdec4: ldr             x1, [PP, #0x5360]  ; [pp+0x5360] Obj!DragStartBehavior@12c5c61
    // 0xdfdec8: StoreField: r0->field_37 = r1
    //     0xdfdec8: stur            w1, [x0, #0x37]
    // 0xdfdecc: r1 = Instance_HitTestBehavior
    //     0xdfdecc: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c0] Obj!HitTestBehavior@12c43c1
    //     0xdfded0: ldr             x1, [x1, #0x5c0]
    // 0xdfded4: StoreField: r0->field_3b = r1
    //     0xdfded4: stur            w1, [x0, #0x3b]
    // 0xdfded8: ldur            x1, [fp, #-0x20]
    // 0xdfdedc: StoreField: r0->field_7 = r1
    //     0xdfdedc: stur            w1, [x0, #7]
    // 0xdfdee0: r0 = Semantics()
    //     0xdfdee0: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xdfdee4: ldur            x2, [fp, #-0x18]
    // 0xdfdee8: r1 = Function '<anonymous closure>':.
    //     0xdfdee8: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c878] AnonymousClosure: (0xdfe348), in [package:flutter/src/material/snack_bar.dart] _SnackBarState::build (0xdfd07c)
    //     0xdfdeec: ldr             x1, [x1, #0x878]
    // 0xdfdef0: stur            x0, [fp, #-0x18]
    // 0xdfdef4: r0 = AllocateClosure()
    //     0xdfdef4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfdef8: r16 = true
    //     0xdfdef8: add             x16, NULL, #0x20  ; true
    // 0xdfdefc: r30 = true
    //     0xdfdefc: add             lr, NULL, #0x20  ; true
    // 0xdfdf00: stp             lr, x16, [SP, #0x10]
    // 0xdfdf04: ldur            x16, [fp, #-0x40]
    // 0xdfdf08: stp             x16, x0, [SP]
    // 0xdfdf0c: ldur            x1, [fp, #-0x18]
    // 0xdfdf10: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, container, 0x1, liveRegion, 0x2, onDismiss, 0x3, null]
    //     0xdfdf10: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8c880] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "container", 0x1, "liveRegion", 0x2, "onDismiss", 0x3, Null]
    //     0xdfdf14: ldr             x4, [x4, #0x880]
    // 0xdfdf18: r0 = Semantics()
    //     0xdfdf18: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xdfdf1c: ldur            x0, [fp, #-0x10]
    // 0xdfdf20: tbnz            w0, #4, #0xdfdf2c
    // 0xdfdf24: ldur            x3, [fp, #-0x18]
    // 0xdfdf28: b               #0xdfe094
    // 0xdfdf2c: ldur            x0, [fp, #-0x28]
    // 0xdfdf30: tbnz            w0, #4, #0xdfdf8c
    // 0xdfdf34: ldur            x1, [fp, #-0x38]
    // 0xdfdf38: tbz             w1, #4, #0xdfdf80
    // 0xdfdf3c: ldur            x1, [fp, #-8]
    // 0xdfdf40: ldur            x0, [fp, #-0x18]
    // 0xdfdf44: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xdfdf44: ldur            w2, [x1, #0x17]
    // 0xdfdf48: DecompressPointer r2
    //     0xdfdf48: add             x2, x2, HEAP, lsl #32
    // 0xdfdf4c: stur            x2, [fp, #-0x10]
    // 0xdfdf50: cmp             w2, NULL
    // 0xdfdf54: b.eq            #0xdfe1a8
    // 0xdfdf58: r0 = FadeTransition()
    //     0xdfdf58: bl              #0xb28358  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0xdfdf5c: mov             x1, x0
    // 0xdfdf60: ldur            x0, [fp, #-0x10]
    // 0xdfdf64: StoreField: r1->field_f = r0
    //     0xdfdf64: stur            w0, [x1, #0xf]
    // 0xdfdf68: r2 = false
    //     0xdfdf68: add             x2, NULL, #0x30  ; false
    // 0xdfdf6c: StoreField: r1->field_13 = r2
    //     0xdfdf6c: stur            w2, [x1, #0x13]
    // 0xdfdf70: ldur            x3, [fp, #-0x18]
    // 0xdfdf74: StoreField: r1->field_b = r3
    //     0xdfdf74: stur            w3, [x1, #0xb]
    // 0xdfdf78: mov             x0, x1
    // 0xdfdf7c: b               #0xdfe090
    // 0xdfdf80: ldur            x3, [fp, #-0x18]
    // 0xdfdf84: r2 = false
    //     0xdfdf84: add             x2, NULL, #0x30  ; false
    // 0xdfdf88: b               #0xdfdf98
    // 0xdfdf8c: ldur            x1, [fp, #-0x38]
    // 0xdfdf90: ldur            x3, [fp, #-0x18]
    // 0xdfdf94: r2 = false
    //     0xdfdf94: add             x2, NULL, #0x30  ; false
    // 0xdfdf98: tbnz            w0, #4, #0xdfe038
    // 0xdfdf9c: tbnz            w1, #4, #0xdfe030
    // 0xdfdfa0: ldur            x0, [fp, #-8]
    // 0xdfdfa4: LoadField: r4 = r0->field_1b
    //     0xdfdfa4: ldur            w4, [x0, #0x1b]
    // 0xdfdfa8: DecompressPointer r4
    //     0xdfdfa8: add             x4, x4, HEAP, lsl #32
    // 0xdfdfac: stur            x4, [fp, #-0x20]
    // 0xdfdfb0: cmp             w4, NULL
    // 0xdfdfb4: b.eq            #0xdfe1ac
    // 0xdfdfb8: LoadField: r5 = r0->field_23
    //     0xdfdfb8: ldur            w5, [x0, #0x23]
    // 0xdfdfbc: DecompressPointer r5
    //     0xdfdfbc: add             x5, x5, HEAP, lsl #32
    // 0xdfdfc0: stur            x5, [fp, #-0x10]
    // 0xdfdfc4: cmp             w5, NULL
    // 0xdfdfc8: b.eq            #0xdfe1b0
    // 0xdfdfcc: r1 = <double>
    //     0xdfdfcc: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdfdfd0: r0 = ValueListenableBuilder()
    //     0xdfdfd0: bl              #0xd77dec  ; AllocateValueListenableBuilderStub -> ValueListenableBuilder<X0> (size=0x1c)
    // 0xdfdfd4: mov             x3, x0
    // 0xdfdfd8: ldur            x0, [fp, #-0x10]
    // 0xdfdfdc: stur            x3, [fp, #-0x28]
    // 0xdfdfe0: StoreField: r3->field_f = r0
    //     0xdfdfe0: stur            w0, [x3, #0xf]
    // 0xdfdfe4: r1 = Function '<anonymous closure>':.
    //     0xdfdfe4: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c888] AnonymousClosure: (0xdfe314), in [package:flutter/src/material/snack_bar.dart] _SnackBarState::build (0xdfd07c)
    //     0xdfdfe8: ldr             x1, [x1, #0x888]
    // 0xdfdfec: r2 = Null
    //     0xdfdfec: mov             x2, NULL
    // 0xdfdff0: r0 = AllocateClosure()
    //     0xdfdff0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfdff4: mov             x1, x0
    // 0xdfdff8: ldur            x0, [fp, #-0x28]
    // 0xdfdffc: StoreField: r0->field_13 = r1
    //     0xdfdffc: stur            w1, [x0, #0x13]
    // 0xdfe000: ldur            x2, [fp, #-0x18]
    // 0xdfe004: ArrayStore: r0[0] = r2  ; List_4
    //     0xdfe004: stur            w2, [x0, #0x17]
    // 0xdfe008: r0 = FadeTransition()
    //     0xdfe008: bl              #0xb28358  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0xdfe00c: mov             x1, x0
    // 0xdfe010: ldur            x0, [fp, #-0x20]
    // 0xdfe014: StoreField: r1->field_f = r0
    //     0xdfe014: stur            w0, [x1, #0xf]
    // 0xdfe018: r0 = false
    //     0xdfe018: add             x0, NULL, #0x30  ; false
    // 0xdfe01c: StoreField: r1->field_13 = r0
    //     0xdfe01c: stur            w0, [x1, #0x13]
    // 0xdfe020: ldur            x0, [fp, #-0x28]
    // 0xdfe024: StoreField: r1->field_b = r0
    //     0xdfe024: stur            w0, [x1, #0xb]
    // 0xdfe028: mov             x0, x1
    // 0xdfe02c: b               #0xdfe090
    // 0xdfe030: mov             x2, x3
    // 0xdfe034: b               #0xdfe03c
    // 0xdfe038: mov             x2, x3
    // 0xdfe03c: ldur            x0, [fp, #-8]
    // 0xdfe040: LoadField: r3 = r0->field_13
    //     0xdfe040: ldur            w3, [x0, #0x13]
    // 0xdfe044: DecompressPointer r3
    //     0xdfe044: add             x3, x3, HEAP, lsl #32
    // 0xdfe048: stur            x3, [fp, #-0x10]
    // 0xdfe04c: cmp             w3, NULL
    // 0xdfe050: b.eq            #0xdfe1b4
    // 0xdfe054: r1 = <double>
    //     0xdfe054: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdfe058: r0 = ValueListenableBuilder()
    //     0xdfe058: bl              #0xd77dec  ; AllocateValueListenableBuilderStub -> ValueListenableBuilder<X0> (size=0x1c)
    // 0xdfe05c: mov             x3, x0
    // 0xdfe060: ldur            x0, [fp, #-0x10]
    // 0xdfe064: stur            x3, [fp, #-0x20]
    // 0xdfe068: StoreField: r3->field_f = r0
    //     0xdfe068: stur            w0, [x3, #0xf]
    // 0xdfe06c: r1 = Function '<anonymous closure>':.
    //     0xdfe06c: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c890] AnonymousClosure: (0xdfe2e0), in [package:flutter/src/material/snack_bar.dart] _SnackBarState::build (0xdfd07c)
    //     0xdfe070: ldr             x1, [x1, #0x890]
    // 0xdfe074: r2 = Null
    //     0xdfe074: mov             x2, NULL
    // 0xdfe078: r0 = AllocateClosure()
    //     0xdfe078: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfe07c: mov             x1, x0
    // 0xdfe080: ldur            x0, [fp, #-0x20]
    // 0xdfe084: StoreField: r0->field_13 = r1
    //     0xdfe084: stur            w1, [x0, #0x13]
    // 0xdfe088: ldur            x1, [fp, #-0x18]
    // 0xdfe08c: ArrayStore: r0[0] = r1  ; List_4
    //     0xdfe08c: stur            w1, [x0, #0x17]
    // 0xdfe090: mov             x3, x0
    // 0xdfe094: ldur            x0, [fp, #-8]
    // 0xdfe098: stur            x3, [fp, #-0x10]
    // 0xdfe09c: r1 = Null
    //     0xdfe09c: mov             x1, NULL
    // 0xdfe0a0: r2 = 6
    //     0xdfe0a0: mov             x2, #6
    // 0xdfe0a4: r0 = AllocateArray()
    //     0xdfe0a4: bl              #0x13df928  ; AllocateArrayStub
    // 0xdfe0a8: r16 = "<SnackBar Hero tag - "
    //     0xdfe0a8: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c898] "<SnackBar Hero tag - "
    //     0xdfe0ac: ldr             x16, [x16, #0x898]
    // 0xdfe0b0: StoreField: r0->field_f = r16
    //     0xdfe0b0: stur            w16, [x0, #0xf]
    // 0xdfe0b4: ldur            x1, [fp, #-8]
    // 0xdfe0b8: LoadField: r2 = r1->field_b
    //     0xdfe0b8: ldur            w2, [x1, #0xb]
    // 0xdfe0bc: DecompressPointer r2
    //     0xdfe0bc: add             x2, x2, HEAP, lsl #32
    // 0xdfe0c0: cmp             w2, NULL
    // 0xdfe0c4: b.eq            #0xdfe1b8
    // 0xdfe0c8: LoadField: r3 = r2->field_b
    //     0xdfe0c8: ldur            w3, [x2, #0xb]
    // 0xdfe0cc: DecompressPointer r3
    //     0xdfe0cc: add             x3, x3, HEAP, lsl #32
    // 0xdfe0d0: StoreField: r0->field_13 = r3
    //     0xdfe0d0: stur            w3, [x0, #0x13]
    // 0xdfe0d4: r16 = ">"
    //     0xdfe0d4: ldr             x16, [PP, #0xe50]  ; [pp+0xe50] ">"
    // 0xdfe0d8: ArrayStore: r0[0] = r16  ; List_4
    //     0xdfe0d8: stur            w16, [x0, #0x17]
    // 0xdfe0dc: str             x0, [SP]
    // 0xdfe0e0: r0 = _interpolate()
    //     0xdfe0e0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xdfe0e4: mov             x1, x0
    // 0xdfe0e8: ldur            x0, [fp, #-8]
    // 0xdfe0ec: stur            x1, [fp, #-0x18]
    // 0xdfe0f0: LoadField: r2 = r0->field_b
    //     0xdfe0f0: ldur            w2, [x0, #0xb]
    // 0xdfe0f4: DecompressPointer r2
    //     0xdfe0f4: add             x2, x2, HEAP, lsl #32
    // 0xdfe0f8: cmp             w2, NULL
    // 0xdfe0fc: b.eq            #0xdfe1bc
    // 0xdfe100: r0 = ClipRect()
    //     0xdfe100: bl              #0xd5c118  ; AllocateClipRectStub -> ClipRect (size=0x18)
    // 0xdfe104: mov             x1, x0
    // 0xdfe108: r0 = Instance_Clip
    //     0xdfe108: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xdfe10c: ldr             x0, [x0, #0x850]
    // 0xdfe110: stur            x1, [fp, #-8]
    // 0xdfe114: StoreField: r1->field_13 = r0
    //     0xdfe114: stur            w0, [x1, #0x13]
    // 0xdfe118: ldur            x0, [fp, #-0x10]
    // 0xdfe11c: StoreField: r1->field_b = r0
    //     0xdfe11c: stur            w0, [x1, #0xb]
    // 0xdfe120: r0 = Hero()
    //     0xdfe120: bl              #0xdfe1e4  ; AllocateHeroStub -> Hero (size=0x2c)
    // 0xdfe124: ldur            x1, [fp, #-0x18]
    // 0xdfe128: StoreField: r0->field_b = r1
    //     0xdfe128: stur            w1, [x0, #0xb]
    // 0xdfe12c: r1 = true
    //     0xdfe12c: add             x1, NULL, #0x20  ; true
    // 0xdfe130: StoreField: r0->field_1f = r1
    //     0xdfe130: stur            w1, [x0, #0x1f]
    // 0xdfe134: r1 = Instance_Cubic
    //     0xdfe134: ldr             x1, [PP, #0x5660]  ; [pp+0x5660] Obj!Cubic@129f451
    // 0xdfe138: StoreField: r0->field_23 = r1
    //     0xdfe138: stur            w1, [x0, #0x23]
    // 0xdfe13c: ldur            x1, [fp, #-8]
    // 0xdfe140: StoreField: r0->field_13 = r1
    //     0xdfe140: stur            w1, [x0, #0x13]
    // 0xdfe144: LeaveFrame
    //     0xdfe144: mov             SP, fp
    //     0xdfe148: ldp             fp, lr, [SP], #0x10
    // 0xdfe14c: ret
    //     0xdfe14c: ret             
    // 0xdfe150: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfe150: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfe154: b               #0xdfd0a4
    // 0xdfe158: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfe158: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfe15c: r9 = _theme
    //     0xdfe15c: add             x9, PP, #0x26, lsl #12  ; [pp+0x26238] Field <_SnackbarDefaultsM2@773267081._theme@773267081>: late final (offset: 0x44)
    //     0xdfe160: ldr             x9, [x9, #0x238]
    // 0xdfe164: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdfe164: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdfe168: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfe168: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfe16c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xdfe16c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xdfe170: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfe170: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfe174: r0 = NullCastErrorSharedWithFPURegs()
    //     0xdfe174: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xdfe178: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfe178: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfe17c: SaveReg d2
    //     0xdfe17c: str             q2, [SP, #-0x10]!
    // 0xdfe180: stp             x0, x1, [SP, #-0x10]!
    // 0xdfe184: r0 = AllocateDouble()
    //     0xdfe184: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdfe188: mov             x2, x0
    // 0xdfe18c: ldp             x0, x1, [SP], #0x10
    // 0xdfe190: RestoreReg d2
    //     0xdfe190: ldr             q2, [SP], #0x10
    // 0xdfe194: b               #0xdfd804
    // 0xdfe198: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfe198: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfe19c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfe19c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfe1a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfe1a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfe1a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfe1a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfe1a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfe1a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfe1ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfe1ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfe1b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfe1b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfe1b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfe1b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfe1b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfe1b8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfe1bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfe1bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Align <anonymous closure>(dynamic, BuildContext, double, Widget?) {
    // ** addr: 0xdfe2e0, size: 0x34
    // 0xdfe2e0: EnterFrame
    //     0xdfe2e0: stp             fp, lr, [SP, #-0x10]!
    //     0xdfe2e4: mov             fp, SP
    // 0xdfe2e8: r0 = Align()
    //     0xdfe2e8: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xdfe2ec: r1 = Instance_AlignmentDirectional
    //     0xdfe2ec: add             x1, PP, #0x15, lsl #12  ; [pp+0x158d8] Obj!AlignmentDirectional@129e611
    //     0xdfe2f0: ldr             x1, [x1, #0x8d8]
    // 0xdfe2f4: StoreField: r0->field_f = r1
    //     0xdfe2f4: stur            w1, [x0, #0xf]
    // 0xdfe2f8: ldr             x1, [fp, #0x18]
    // 0xdfe2fc: ArrayStore: r0[0] = r1  ; List_4
    //     0xdfe2fc: stur            w1, [x0, #0x17]
    // 0xdfe300: ldr             x1, [fp, #0x10]
    // 0xdfe304: StoreField: r0->field_b = r1
    //     0xdfe304: stur            w1, [x0, #0xb]
    // 0xdfe308: LeaveFrame
    //     0xdfe308: mov             SP, fp
    //     0xdfe30c: ldp             fp, lr, [SP], #0x10
    // 0xdfe310: ret
    //     0xdfe310: ret             
  }
  [closure] Align <anonymous closure>(dynamic, BuildContext, double, Widget?) {
    // ** addr: 0xdfe314, size: 0x34
    // 0xdfe314: EnterFrame
    //     0xdfe314: stp             fp, lr, [SP, #-0x10]!
    //     0xdfe318: mov             fp, SP
    // 0xdfe31c: r0 = Align()
    //     0xdfe31c: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xdfe320: r1 = Instance_Alignment
    //     0xdfe320: add             x1, PP, #0x16, lsl #12  ; [pp+0x16e00] Obj!Alignment@129e731
    //     0xdfe324: ldr             x1, [x1, #0xe00]
    // 0xdfe328: StoreField: r0->field_f = r1
    //     0xdfe328: stur            w1, [x0, #0xf]
    // 0xdfe32c: ldr             x1, [fp, #0x18]
    // 0xdfe330: ArrayStore: r0[0] = r1  ; List_4
    //     0xdfe330: stur            w1, [x0, #0x17]
    // 0xdfe334: ldr             x1, [fp, #0x10]
    // 0xdfe338: StoreField: r0->field_b = r1
    //     0xdfe338: stur            w1, [x0, #0xb]
    // 0xdfe33c: LeaveFrame
    //     0xdfe33c: mov             SP, fp
    //     0xdfe340: ldp             fp, lr, [SP], #0x10
    // 0xdfe344: ret
    //     0xdfe344: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdfe348, size: 0x58
    // 0xdfe348: EnterFrame
    //     0xdfe348: stp             fp, lr, [SP, #-0x10]!
    //     0xdfe34c: mov             fp, SP
    // 0xdfe350: ldr             x0, [fp, #0x10]
    // 0xdfe354: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdfe354: ldur            w1, [x0, #0x17]
    // 0xdfe358: DecompressPointer r1
    //     0xdfe358: add             x1, x1, HEAP, lsl #32
    // 0xdfe35c: CheckStackOverflow
    //     0xdfe35c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfe360: cmp             SP, x16
    //     0xdfe364: b.ls            #0xdfe398
    // 0xdfe368: LoadField: r0 = r1->field_f
    //     0xdfe368: ldur            w0, [x1, #0xf]
    // 0xdfe36c: DecompressPointer r0
    //     0xdfe36c: add             x0, x0, HEAP, lsl #32
    // 0xdfe370: mov             x1, x0
    // 0xdfe374: r0 = of()
    //     0xdfe374: bl              #0xdfe470  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0xdfe378: mov             x1, x0
    // 0xdfe37c: r2 = Instance_SnackBarClosedReason
    //     0xdfe37c: add             x2, PP, #0x8c, lsl #12  ; [pp+0x8c8a0] Obj!SnackBarClosedReason@12c4dc1
    //     0xdfe380: ldr             x2, [x2, #0x8a0]
    // 0xdfe384: r0 = removeCurrentSnackBar()
    //     0xdfe384: bl              #0xdfe3a0  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::removeCurrentSnackBar
    // 0xdfe388: r0 = Null
    //     0xdfe388: mov             x0, NULL
    // 0xdfe38c: LeaveFrame
    //     0xdfe38c: mov             SP, fp
    //     0xdfe390: ldp             fp, lr, [SP], #0x10
    // 0xdfe394: ret
    //     0xdfe394: ret             
    // 0xdfe398: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfe398: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfe39c: b               #0xdfe368
  }
  [closure] void <anonymous closure>(dynamic, DismissDirection) {
    // ** addr: 0xdfe4c8, size: 0x58
    // 0xdfe4c8: EnterFrame
    //     0xdfe4c8: stp             fp, lr, [SP, #-0x10]!
    //     0xdfe4cc: mov             fp, SP
    // 0xdfe4d0: ldr             x0, [fp, #0x18]
    // 0xdfe4d4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdfe4d4: ldur            w1, [x0, #0x17]
    // 0xdfe4d8: DecompressPointer r1
    //     0xdfe4d8: add             x1, x1, HEAP, lsl #32
    // 0xdfe4dc: CheckStackOverflow
    //     0xdfe4dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfe4e0: cmp             SP, x16
    //     0xdfe4e4: b.ls            #0xdfe518
    // 0xdfe4e8: LoadField: r0 = r1->field_f
    //     0xdfe4e8: ldur            w0, [x1, #0xf]
    // 0xdfe4ec: DecompressPointer r0
    //     0xdfe4ec: add             x0, x0, HEAP, lsl #32
    // 0xdfe4f0: mov             x1, x0
    // 0xdfe4f4: r0 = of()
    //     0xdfe4f4: bl              #0xdfe470  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0xdfe4f8: mov             x1, x0
    // 0xdfe4fc: r2 = Instance_SnackBarClosedReason
    //     0xdfe4fc: add             x2, PP, #0x8c, lsl #12  ; [pp+0x8c8a8] Obj!SnackBarClosedReason@12c4de1
    //     0xdfe500: ldr             x2, [x2, #0x8a8]
    // 0xdfe504: r0 = removeCurrentSnackBar()
    //     0xdfe504: bl              #0xdfe3a0  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::removeCurrentSnackBar
    // 0xdfe508: r0 = Null
    //     0xdfe508: mov             x0, NULL
    // 0xdfe50c: LeaveFrame
    //     0xdfe50c: mov             SP, fp
    //     0xdfe510: ldp             fp, lr, [SP], #0x10
    // 0xdfe514: ret
    //     0xdfe514: ret             
    // 0xdfe518: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfe518: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfe51c: b               #0xdfe4e8
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf6e8c0, size: 0x164
    // 0xf6e8c0: EnterFrame
    //     0xf6e8c0: stp             fp, lr, [SP, #-0x10]!
    //     0xf6e8c4: mov             fp, SP
    // 0xf6e8c8: AllocStack(0x18)
    //     0xf6e8c8: sub             SP, SP, #0x18
    // 0xf6e8cc: SetupParameters(_SnackBarState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf6e8cc: mov             x4, x1
    //     0xf6e8d0: mov             x3, x2
    //     0xf6e8d4: stur            x1, [fp, #-8]
    //     0xf6e8d8: stur            x2, [fp, #-0x10]
    // 0xf6e8dc: CheckStackOverflow
    //     0xf6e8dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6e8e0: cmp             SP, x16
    //     0xf6e8e4: b.ls            #0xf6ea0c
    // 0xf6e8e8: mov             x0, x3
    // 0xf6e8ec: r2 = Null
    //     0xf6e8ec: mov             x2, NULL
    // 0xf6e8f0: r1 = Null
    //     0xf6e8f0: mov             x1, NULL
    // 0xf6e8f4: r4 = 60
    //     0xf6e8f4: mov             x4, #0x3c
    // 0xf6e8f8: branchIfSmi(r0, 0xf6e904)
    //     0xf6e8f8: tbz             w0, #0, #0xf6e904
    // 0xf6e8fc: r4 = LoadClassIdInstr(r0)
    //     0xf6e8fc: ldur            x4, [x0, #-1]
    //     0xf6e900: ubfx            x4, x4, #0xc, #0x14
    // 0xf6e904: r17 = 6432
    //     0xf6e904: mov             x17, #0x1920
    // 0xf6e908: cmp             x4, x17
    // 0xf6e90c: b.eq            #0xf6e924
    // 0xf6e910: r8 = SnackBar
    //     0xf6e910: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8c8d8] Type: SnackBar
    //     0xf6e914: ldr             x8, [x8, #0x8d8]
    // 0xf6e918: r3 = Null
    //     0xf6e918: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c8e0] Null
    //     0xf6e91c: ldr             x3, [x3, #0x8e0]
    // 0xf6e920: r0 = SnackBar()
    //     0xf6e920: bl              #0xdfe1c0  ; IsType_SnackBar_Stub
    // 0xf6e924: ldur            x3, [fp, #-8]
    // 0xf6e928: LoadField: r2 = r3->field_7
    //     0xf6e928: ldur            w2, [x3, #7]
    // 0xf6e92c: DecompressPointer r2
    //     0xf6e92c: add             x2, x2, HEAP, lsl #32
    // 0xf6e930: ldur            x0, [fp, #-0x10]
    // 0xf6e934: r1 = Null
    //     0xf6e934: mov             x1, NULL
    // 0xf6e938: cmp             w2, NULL
    // 0xf6e93c: b.eq            #0xf6e960
    // 0xf6e940: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6e940: ldur            w4, [x2, #0x17]
    // 0xf6e944: DecompressPointer r4
    //     0xf6e944: add             x4, x4, HEAP, lsl #32
    // 0xf6e948: r8 = X0 bound StatefulWidget
    //     0xf6e948: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf6e94c: ldr             x8, [x8, #0x498]
    // 0xf6e950: LoadField: r9 = r4->field_7
    //     0xf6e950: ldur            x9, [x4, #7]
    // 0xf6e954: r3 = Null
    //     0xf6e954: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c8f0] Null
    //     0xf6e958: ldr             x3, [x3, #0x8f0]
    // 0xf6e95c: blr             x9
    // 0xf6e960: ldur            x0, [fp, #-8]
    // 0xf6e964: LoadField: r1 = r0->field_b
    //     0xf6e964: ldur            w1, [x0, #0xb]
    // 0xf6e968: DecompressPointer r1
    //     0xf6e968: add             x1, x1, HEAP, lsl #32
    // 0xf6e96c: cmp             w1, NULL
    // 0xf6e970: b.eq            #0xf6ea14
    // 0xf6e974: LoadField: r2 = r1->field_47
    //     0xf6e974: ldur            w2, [x1, #0x47]
    // 0xf6e978: DecompressPointer r2
    //     0xf6e978: add             x2, x2, HEAP, lsl #32
    // 0xf6e97c: ldur            x1, [fp, #-0x10]
    // 0xf6e980: LoadField: r3 = r1->field_47
    //     0xf6e980: ldur            w3, [x1, #0x47]
    // 0xf6e984: DecompressPointer r3
    //     0xf6e984: add             x3, x3, HEAP, lsl #32
    // 0xf6e988: stur            x3, [fp, #-0x18]
    // 0xf6e98c: cmp             w2, w3
    // 0xf6e990: b.eq            #0xf6e9fc
    // 0xf6e994: cmp             w3, NULL
    // 0xf6e998: b.eq            #0xf6ea18
    // 0xf6e99c: mov             x2, x0
    // 0xf6e9a0: r1 = Function '_onAnimationStatusChanged@773267081':.
    //     0xf6e9a0: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c8d0] AnonymousClosure: (0xf6ed88), in [package:flutter/src/material/snack_bar.dart] _SnackBarState::_onAnimationStatusChanged (0xf6edc4)
    //     0xf6e9a4: ldr             x1, [x1, #0x8d0]
    // 0xf6e9a8: r0 = AllocateClosure()
    //     0xf6e9a8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf6e9ac: ldur            x1, [fp, #-0x18]
    // 0xf6e9b0: mov             x2, x0
    // 0xf6e9b4: stur            x0, [fp, #-0x10]
    // 0xf6e9b8: r0 = removeStatusListener()
    //     0xf6e9b8: bl              #0x12599f4  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::removeStatusListener
    // 0xf6e9bc: ldur            x0, [fp, #-8]
    // 0xf6e9c0: LoadField: r1 = r0->field_b
    //     0xf6e9c0: ldur            w1, [x0, #0xb]
    // 0xf6e9c4: DecompressPointer r1
    //     0xf6e9c4: add             x1, x1, HEAP, lsl #32
    // 0xf6e9c8: cmp             w1, NULL
    // 0xf6e9cc: b.eq            #0xf6ea1c
    // 0xf6e9d0: LoadField: r2 = r1->field_47
    //     0xf6e9d0: ldur            w2, [x1, #0x47]
    // 0xf6e9d4: DecompressPointer r2
    //     0xf6e9d4: add             x2, x2, HEAP, lsl #32
    // 0xf6e9d8: cmp             w2, NULL
    // 0xf6e9dc: b.eq            #0xf6ea20
    // 0xf6e9e0: mov             x1, x2
    // 0xf6e9e4: ldur            x2, [fp, #-0x10]
    // 0xf6e9e8: r0 = addStatusListener()
    //     0xf6e9e8: bl              #0x1254cc0  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0xf6e9ec: ldur            x1, [fp, #-8]
    // 0xf6e9f0: r0 = _disposeAnimations()
    //     0xf6e9f0: bl              #0xf6ecbc  ; [package:flutter/src/material/snack_bar.dart] _SnackBarState::_disposeAnimations
    // 0xf6e9f4: ldur            x1, [fp, #-8]
    // 0xf6e9f8: r0 = _setAnimations()
    //     0xf6e9f8: bl              #0xf6ea24  ; [package:flutter/src/material/snack_bar.dart] _SnackBarState::_setAnimations
    // 0xf6e9fc: r0 = Null
    //     0xf6e9fc: mov             x0, NULL
    // 0xf6ea00: LeaveFrame
    //     0xf6ea00: mov             SP, fp
    //     0xf6ea04: ldp             fp, lr, [SP], #0x10
    // 0xf6ea08: ret
    //     0xf6ea08: ret             
    // 0xf6ea0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6ea0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6ea10: b               #0xf6e8e8
    // 0xf6ea14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6ea14: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6ea18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6ea18: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6ea1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6ea1c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6ea20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6ea20: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _setAnimations(/* No info */) {
    // ** addr: 0xf6ea24, size: 0x298
    // 0xf6ea24: EnterFrame
    //     0xf6ea24: stp             fp, lr, [SP, #-0x10]!
    //     0xf6ea28: mov             fp, SP
    // 0xf6ea2c: AllocStack(0x20)
    //     0xf6ea2c: sub             SP, SP, #0x20
    // 0xf6ea30: SetupParameters(_SnackBarState this /* r1 => r0, fp-0x10 */)
    //     0xf6ea30: mov             x0, x1
    //     0xf6ea34: stur            x1, [fp, #-0x10]
    // 0xf6ea38: CheckStackOverflow
    //     0xf6ea38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6ea3c: cmp             SP, x16
    //     0xf6ea40: b.ls            #0xf6ec8c
    // 0xf6ea44: LoadField: r1 = r0->field_b
    //     0xf6ea44: ldur            w1, [x0, #0xb]
    // 0xf6ea48: DecompressPointer r1
    //     0xf6ea48: add             x1, x1, HEAP, lsl #32
    // 0xf6ea4c: cmp             w1, NULL
    // 0xf6ea50: b.eq            #0xf6ec94
    // 0xf6ea54: LoadField: r3 = r1->field_47
    //     0xf6ea54: ldur            w3, [x1, #0x47]
    // 0xf6ea58: DecompressPointer r3
    //     0xf6ea58: add             x3, x3, HEAP, lsl #32
    // 0xf6ea5c: stur            x3, [fp, #-8]
    // 0xf6ea60: cmp             w3, NULL
    // 0xf6ea64: b.eq            #0xf6ec98
    // 0xf6ea68: r1 = <double>
    //     0xf6ea68: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf6ea6c: r0 = CurvedAnimation()
    //     0xf6ea6c: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xf6ea70: mov             x1, x0
    // 0xf6ea74: ldur            x3, [fp, #-8]
    // 0xf6ea78: r2 = Instance_Cubic
    //     0xf6ea78: ldr             x2, [PP, #0x5660]  ; [pp+0x5660] Obj!Cubic@129f451
    // 0xf6ea7c: stur            x0, [fp, #-8]
    // 0xf6ea80: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xf6ea80: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xf6ea84: r0 = CurvedAnimation()
    //     0xf6ea84: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xf6ea88: ldur            x0, [fp, #-8]
    // 0xf6ea8c: ldur            x2, [fp, #-0x10]
    // 0xf6ea90: StoreField: r2->field_13 = r0
    //     0xf6ea90: stur            w0, [x2, #0x13]
    //     0xf6ea94: ldurb           w16, [x2, #-1]
    //     0xf6ea98: ldurb           w17, [x0, #-1]
    //     0xf6ea9c: and             x16, x17, x16, lsr #2
    //     0xf6eaa0: tst             x16, HEAP, lsr #32
    //     0xf6eaa4: b.eq            #0xf6eaac
    //     0xf6eaa8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf6eaac: LoadField: r0 = r2->field_b
    //     0xf6eaac: ldur            w0, [x2, #0xb]
    // 0xf6eab0: DecompressPointer r0
    //     0xf6eab0: add             x0, x0, HEAP, lsl #32
    // 0xf6eab4: cmp             w0, NULL
    // 0xf6eab8: b.eq            #0xf6ec9c
    // 0xf6eabc: LoadField: r3 = r0->field_47
    //     0xf6eabc: ldur            w3, [x0, #0x47]
    // 0xf6eac0: DecompressPointer r3
    //     0xf6eac0: add             x3, x3, HEAP, lsl #32
    // 0xf6eac4: stur            x3, [fp, #-8]
    // 0xf6eac8: cmp             w3, NULL
    // 0xf6eacc: b.eq            #0xf6eca0
    // 0xf6ead0: r1 = <double>
    //     0xf6ead0: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf6ead4: r0 = CurvedAnimation()
    //     0xf6ead4: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xf6ead8: mov             x1, x0
    // 0xf6eadc: ldur            x3, [fp, #-8]
    // 0xf6eae0: r2 = Instance_Interval
    //     0xf6eae0: add             x2, PP, #0x8c, lsl #12  ; [pp+0x8c900] Obj!Interval@129fb91
    //     0xf6eae4: ldr             x2, [x2, #0x900]
    // 0xf6eae8: stur            x0, [fp, #-8]
    // 0xf6eaec: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xf6eaec: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xf6eaf0: r0 = CurvedAnimation()
    //     0xf6eaf0: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xf6eaf4: ldur            x0, [fp, #-8]
    // 0xf6eaf8: ldur            x2, [fp, #-0x10]
    // 0xf6eafc: ArrayStore: r2[0] = r0  ; List_4
    //     0xf6eafc: stur            w0, [x2, #0x17]
    //     0xf6eb00: ldurb           w16, [x2, #-1]
    //     0xf6eb04: ldurb           w17, [x0, #-1]
    //     0xf6eb08: and             x16, x17, x16, lsr #2
    //     0xf6eb0c: tst             x16, HEAP, lsr #32
    //     0xf6eb10: b.eq            #0xf6eb18
    //     0xf6eb14: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf6eb18: LoadField: r0 = r2->field_b
    //     0xf6eb18: ldur            w0, [x2, #0xb]
    // 0xf6eb1c: DecompressPointer r0
    //     0xf6eb1c: add             x0, x0, HEAP, lsl #32
    // 0xf6eb20: cmp             w0, NULL
    // 0xf6eb24: b.eq            #0xf6eca4
    // 0xf6eb28: LoadField: r3 = r0->field_47
    //     0xf6eb28: ldur            w3, [x0, #0x47]
    // 0xf6eb2c: DecompressPointer r3
    //     0xf6eb2c: add             x3, x3, HEAP, lsl #32
    // 0xf6eb30: stur            x3, [fp, #-8]
    // 0xf6eb34: cmp             w3, NULL
    // 0xf6eb38: b.eq            #0xf6eca8
    // 0xf6eb3c: r1 = <double>
    //     0xf6eb3c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf6eb40: r0 = CurvedAnimation()
    //     0xf6eb40: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xf6eb44: mov             x1, x0
    // 0xf6eb48: ldur            x3, [fp, #-8]
    // 0xf6eb4c: r2 = Instance_Interval
    //     0xf6eb4c: add             x2, PP, #0x8c, lsl #12  ; [pp+0x8c908] Obj!Interval@129fb71
    //     0xf6eb50: ldr             x2, [x2, #0x908]
    // 0xf6eb54: stur            x0, [fp, #-8]
    // 0xf6eb58: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xf6eb58: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xf6eb5c: r0 = CurvedAnimation()
    //     0xf6eb5c: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xf6eb60: ldur            x0, [fp, #-8]
    // 0xf6eb64: ldur            x2, [fp, #-0x10]
    // 0xf6eb68: StoreField: r2->field_1b = r0
    //     0xf6eb68: stur            w0, [x2, #0x1b]
    //     0xf6eb6c: ldurb           w16, [x2, #-1]
    //     0xf6eb70: ldurb           w17, [x0, #-1]
    //     0xf6eb74: and             x16, x17, x16, lsr #2
    //     0xf6eb78: tst             x16, HEAP, lsr #32
    //     0xf6eb7c: b.eq            #0xf6eb84
    //     0xf6eb80: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf6eb84: LoadField: r0 = r2->field_b
    //     0xf6eb84: ldur            w0, [x2, #0xb]
    // 0xf6eb88: DecompressPointer r0
    //     0xf6eb88: add             x0, x0, HEAP, lsl #32
    // 0xf6eb8c: cmp             w0, NULL
    // 0xf6eb90: b.eq            #0xf6ecac
    // 0xf6eb94: LoadField: r3 = r0->field_47
    //     0xf6eb94: ldur            w3, [x0, #0x47]
    // 0xf6eb98: DecompressPointer r3
    //     0xf6eb98: add             x3, x3, HEAP, lsl #32
    // 0xf6eb9c: stur            x3, [fp, #-8]
    // 0xf6eba0: cmp             w3, NULL
    // 0xf6eba4: b.eq            #0xf6ecb0
    // 0xf6eba8: r1 = <double>
    //     0xf6eba8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf6ebac: r0 = CurvedAnimation()
    //     0xf6ebac: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xf6ebb0: stur            x0, [fp, #-0x18]
    // 0xf6ebb4: r16 = Instance_Threshold
    //     0xf6ebb4: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c910] Obj!Threshold@129f8f1
    //     0xf6ebb8: ldr             x16, [x16, #0x910]
    // 0xf6ebbc: str             x16, [SP]
    // 0xf6ebc0: mov             x1, x0
    // 0xf6ebc4: ldur            x3, [fp, #-8]
    // 0xf6ebc8: r2 = Instance_Interval
    //     0xf6ebc8: add             x2, PP, #0x8c, lsl #12  ; [pp+0x8c918] Obj!Interval@129fb51
    //     0xf6ebcc: ldr             x2, [x2, #0x918]
    // 0xf6ebd0: r4 = const [0, 0x4, 0x1, 0x3, reverseCurve, 0x3, null]
    //     0xf6ebd0: add             x4, PP, #0x16, lsl #12  ; [pp+0x16dc0] List(7) [0, 0x4, 0x1, 0x3, "reverseCurve", 0x3, Null]
    //     0xf6ebd4: ldr             x4, [x4, #0xdc0]
    // 0xf6ebd8: r0 = CurvedAnimation()
    //     0xf6ebd8: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xf6ebdc: ldur            x0, [fp, #-0x18]
    // 0xf6ebe0: ldur            x2, [fp, #-0x10]
    // 0xf6ebe4: StoreField: r2->field_1f = r0
    //     0xf6ebe4: stur            w0, [x2, #0x1f]
    //     0xf6ebe8: ldurb           w16, [x2, #-1]
    //     0xf6ebec: ldurb           w17, [x0, #-1]
    //     0xf6ebf0: and             x16, x17, x16, lsr #2
    //     0xf6ebf4: tst             x16, HEAP, lsr #32
    //     0xf6ebf8: b.eq            #0xf6ec00
    //     0xf6ebfc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf6ec00: LoadField: r0 = r2->field_b
    //     0xf6ec00: ldur            w0, [x2, #0xb]
    // 0xf6ec04: DecompressPointer r0
    //     0xf6ec04: add             x0, x0, HEAP, lsl #32
    // 0xf6ec08: cmp             w0, NULL
    // 0xf6ec0c: b.eq            #0xf6ecb4
    // 0xf6ec10: LoadField: r3 = r0->field_47
    //     0xf6ec10: ldur            w3, [x0, #0x47]
    // 0xf6ec14: DecompressPointer r3
    //     0xf6ec14: add             x3, x3, HEAP, lsl #32
    // 0xf6ec18: stur            x3, [fp, #-8]
    // 0xf6ec1c: cmp             w3, NULL
    // 0xf6ec20: b.eq            #0xf6ecb8
    // 0xf6ec24: r1 = <double>
    //     0xf6ec24: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf6ec28: r0 = CurvedAnimation()
    //     0xf6ec28: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xf6ec2c: stur            x0, [fp, #-0x18]
    // 0xf6ec30: r16 = Instance_Threshold
    //     0xf6ec30: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c910] Obj!Threshold@129f8f1
    //     0xf6ec34: ldr             x16, [x16, #0x910]
    // 0xf6ec38: str             x16, [SP]
    // 0xf6ec3c: mov             x1, x0
    // 0xf6ec40: ldur            x3, [fp, #-8]
    // 0xf6ec44: r2 = Instance_Cubic
    //     0xf6ec44: add             x2, PP, #0x8c, lsl #12  ; [pp+0x8c920] Obj!Cubic@129f811
    //     0xf6ec48: ldr             x2, [x2, #0x920]
    // 0xf6ec4c: r4 = const [0, 0x4, 0x1, 0x3, reverseCurve, 0x3, null]
    //     0xf6ec4c: add             x4, PP, #0x16, lsl #12  ; [pp+0x16dc0] List(7) [0, 0x4, 0x1, 0x3, "reverseCurve", 0x3, Null]
    //     0xf6ec50: ldr             x4, [x4, #0xdc0]
    // 0xf6ec54: r0 = CurvedAnimation()
    //     0xf6ec54: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xf6ec58: ldur            x0, [fp, #-0x18]
    // 0xf6ec5c: ldur            x1, [fp, #-0x10]
    // 0xf6ec60: StoreField: r1->field_23 = r0
    //     0xf6ec60: stur            w0, [x1, #0x23]
    //     0xf6ec64: ldurb           w16, [x1, #-1]
    //     0xf6ec68: ldurb           w17, [x0, #-1]
    //     0xf6ec6c: and             x16, x17, x16, lsr #2
    //     0xf6ec70: tst             x16, HEAP, lsr #32
    //     0xf6ec74: b.eq            #0xf6ec7c
    //     0xf6ec78: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf6ec7c: r0 = Null
    //     0xf6ec7c: mov             x0, NULL
    // 0xf6ec80: LeaveFrame
    //     0xf6ec80: mov             SP, fp
    //     0xf6ec84: ldp             fp, lr, [SP], #0x10
    // 0xf6ec88: ret
    //     0xf6ec88: ret             
    // 0xf6ec8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6ec8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6ec90: b               #0xf6ea44
    // 0xf6ec94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6ec94: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6ec98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6ec98: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6ec9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6ec9c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6eca0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6eca0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6eca4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6eca4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6eca8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6eca8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6ecac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6ecac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6ecb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6ecb0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6ecb4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6ecb4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6ecb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6ecb8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _disposeAnimations(/* No info */) {
    // ** addr: 0xf6ecbc, size: 0xcc
    // 0xf6ecbc: EnterFrame
    //     0xf6ecbc: stp             fp, lr, [SP, #-0x10]!
    //     0xf6ecc0: mov             fp, SP
    // 0xf6ecc4: AllocStack(0x8)
    //     0xf6ecc4: sub             SP, SP, #8
    // 0xf6ecc8: SetupParameters(_SnackBarState this /* r1 => r0, fp-0x8 */)
    //     0xf6ecc8: mov             x0, x1
    //     0xf6eccc: stur            x1, [fp, #-8]
    // 0xf6ecd0: CheckStackOverflow
    //     0xf6ecd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6ecd4: cmp             SP, x16
    //     0xf6ecd8: b.ls            #0xf6ed80
    // 0xf6ecdc: LoadField: r1 = r0->field_13
    //     0xf6ecdc: ldur            w1, [x0, #0x13]
    // 0xf6ece0: DecompressPointer r1
    //     0xf6ece0: add             x1, x1, HEAP, lsl #32
    // 0xf6ece4: cmp             w1, NULL
    // 0xf6ece8: b.eq            #0xf6ecf4
    // 0xf6ecec: r0 = dispose()
    //     0xf6ecec: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xf6ecf0: ldur            x0, [fp, #-8]
    // 0xf6ecf4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf6ecf4: ldur            w1, [x0, #0x17]
    // 0xf6ecf8: DecompressPointer r1
    //     0xf6ecf8: add             x1, x1, HEAP, lsl #32
    // 0xf6ecfc: cmp             w1, NULL
    // 0xf6ed00: b.eq            #0xf6ed0c
    // 0xf6ed04: r0 = dispose()
    //     0xf6ed04: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xf6ed08: ldur            x0, [fp, #-8]
    // 0xf6ed0c: LoadField: r1 = r0->field_1b
    //     0xf6ed0c: ldur            w1, [x0, #0x1b]
    // 0xf6ed10: DecompressPointer r1
    //     0xf6ed10: add             x1, x1, HEAP, lsl #32
    // 0xf6ed14: cmp             w1, NULL
    // 0xf6ed18: b.eq            #0xf6ed24
    // 0xf6ed1c: r0 = dispose()
    //     0xf6ed1c: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xf6ed20: ldur            x0, [fp, #-8]
    // 0xf6ed24: LoadField: r1 = r0->field_1f
    //     0xf6ed24: ldur            w1, [x0, #0x1f]
    // 0xf6ed28: DecompressPointer r1
    //     0xf6ed28: add             x1, x1, HEAP, lsl #32
    // 0xf6ed2c: cmp             w1, NULL
    // 0xf6ed30: b.eq            #0xf6ed3c
    // 0xf6ed34: r0 = dispose()
    //     0xf6ed34: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xf6ed38: ldur            x0, [fp, #-8]
    // 0xf6ed3c: LoadField: r1 = r0->field_23
    //     0xf6ed3c: ldur            w1, [x0, #0x23]
    // 0xf6ed40: DecompressPointer r1
    //     0xf6ed40: add             x1, x1, HEAP, lsl #32
    // 0xf6ed44: cmp             w1, NULL
    // 0xf6ed48: b.ne            #0xf6ed54
    // 0xf6ed4c: mov             x1, x0
    // 0xf6ed50: b               #0xf6ed5c
    // 0xf6ed54: r0 = dispose()
    //     0xf6ed54: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xf6ed58: ldur            x1, [fp, #-8]
    // 0xf6ed5c: StoreField: r1->field_13 = rNULL
    //     0xf6ed5c: stur            NULL, [x1, #0x13]
    // 0xf6ed60: ArrayStore: r1[0] = rNULL  ; List_4
    //     0xf6ed60: stur            NULL, [x1, #0x17]
    // 0xf6ed64: StoreField: r1->field_1b = rNULL
    //     0xf6ed64: stur            NULL, [x1, #0x1b]
    // 0xf6ed68: StoreField: r1->field_1f = rNULL
    //     0xf6ed68: stur            NULL, [x1, #0x1f]
    // 0xf6ed6c: StoreField: r1->field_23 = rNULL
    //     0xf6ed6c: stur            NULL, [x1, #0x23]
    // 0xf6ed70: r0 = Null
    //     0xf6ed70: mov             x0, NULL
    // 0xf6ed74: LeaveFrame
    //     0xf6ed74: mov             SP, fp
    //     0xf6ed78: ldp             fp, lr, [SP], #0x10
    // 0xf6ed7c: ret
    //     0xf6ed7c: ret             
    // 0xf6ed80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6ed80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6ed84: b               #0xf6ecdc
  }
  [closure] void _onAnimationStatusChanged(dynamic, AnimationStatus) {
    // ** addr: 0xf6ed88, size: 0x3c
    // 0xf6ed88: EnterFrame
    //     0xf6ed88: stp             fp, lr, [SP, #-0x10]!
    //     0xf6ed8c: mov             fp, SP
    // 0xf6ed90: ldr             x0, [fp, #0x18]
    // 0xf6ed94: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf6ed94: ldur            w1, [x0, #0x17]
    // 0xf6ed98: DecompressPointer r1
    //     0xf6ed98: add             x1, x1, HEAP, lsl #32
    // 0xf6ed9c: CheckStackOverflow
    //     0xf6ed9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6eda0: cmp             SP, x16
    //     0xf6eda4: b.ls            #0xf6edbc
    // 0xf6eda8: ldr             x2, [fp, #0x10]
    // 0xf6edac: r0 = _onAnimationStatusChanged()
    //     0xf6edac: bl              #0xf6edc4  ; [package:flutter/src/material/snack_bar.dart] _SnackBarState::_onAnimationStatusChanged
    // 0xf6edb0: LeaveFrame
    //     0xf6edb0: mov             SP, fp
    //     0xf6edb4: ldp             fp, lr, [SP], #0x10
    // 0xf6edb8: ret
    //     0xf6edb8: ret             
    // 0xf6edbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6edbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6edc0: b               #0xf6eda8
  }
  _ _onAnimationStatusChanged(/* No info */) {
    // ** addr: 0xf6edc4, size: 0x30
    // 0xf6edc4: r16 = Instance_AnimationStatus
    //     0xf6edc4: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0xf6edc8: cmp             w2, w16
    // 0xf6edcc: b.ne            #0xf6ede0
    // 0xf6edd0: LoadField: r2 = r1->field_b
    //     0xf6edd0: ldur            w2, [x1, #0xb]
    // 0xf6edd4: DecompressPointer r2
    //     0xf6edd4: add             x2, x2, HEAP, lsl #32
    // 0xf6edd8: cmp             w2, NULL
    // 0xf6eddc: b.eq            #0xf6ede8
    // 0xf6ede0: r0 = Null
    //     0xf6ede0: mov             x0, NULL
    // 0xf6ede4: ret
    //     0xf6ede4: ret             
    // 0xf6ede8: EnterFrame
    //     0xf6ede8: stp             fp, lr, [SP, #-0x10]!
    //     0xf6edec: mov             fp, SP
    // 0xf6edf0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6edf0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf913a0, size: 0x88
    // 0xf913a0: EnterFrame
    //     0xf913a0: stp             fp, lr, [SP, #-0x10]!
    //     0xf913a4: mov             fp, SP
    // 0xf913a8: AllocStack(0x10)
    //     0xf913a8: sub             SP, SP, #0x10
    // 0xf913ac: SetupParameters(_SnackBarState this /* r1 => r0, fp-0x10 */)
    //     0xf913ac: mov             x0, x1
    //     0xf913b0: stur            x1, [fp, #-0x10]
    // 0xf913b4: CheckStackOverflow
    //     0xf913b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf913b8: cmp             SP, x16
    //     0xf913bc: b.ls            #0xf91418
    // 0xf913c0: LoadField: r1 = r0->field_b
    //     0xf913c0: ldur            w1, [x0, #0xb]
    // 0xf913c4: DecompressPointer r1
    //     0xf913c4: add             x1, x1, HEAP, lsl #32
    // 0xf913c8: cmp             w1, NULL
    // 0xf913cc: b.eq            #0xf91420
    // 0xf913d0: LoadField: r3 = r1->field_47
    //     0xf913d0: ldur            w3, [x1, #0x47]
    // 0xf913d4: DecompressPointer r3
    //     0xf913d4: add             x3, x3, HEAP, lsl #32
    // 0xf913d8: stur            x3, [fp, #-8]
    // 0xf913dc: cmp             w3, NULL
    // 0xf913e0: b.eq            #0xf91424
    // 0xf913e4: mov             x2, x0
    // 0xf913e8: r1 = Function '_onAnimationStatusChanged@773267081':.
    //     0xf913e8: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c8d0] AnonymousClosure: (0xf6ed88), in [package:flutter/src/material/snack_bar.dart] _SnackBarState::_onAnimationStatusChanged (0xf6edc4)
    //     0xf913ec: ldr             x1, [x1, #0x8d0]
    // 0xf913f0: r0 = AllocateClosure()
    //     0xf913f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf913f4: ldur            x1, [fp, #-8]
    // 0xf913f8: mov             x2, x0
    // 0xf913fc: r0 = addStatusListener()
    //     0xf913fc: bl              #0x1254cc0  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0xf91400: ldur            x1, [fp, #-0x10]
    // 0xf91404: r0 = _setAnimations()
    //     0xf91404: bl              #0xf6ea24  ; [package:flutter/src/material/snack_bar.dart] _SnackBarState::_setAnimations
    // 0xf91408: r0 = Null
    //     0xf91408: mov             x0, NULL
    // 0xf9140c: LeaveFrame
    //     0xf9140c: mov             SP, fp
    //     0xf91410: ldp             fp, lr, [SP], #0x10
    // 0xf91414: ret
    //     0xf91414: ret             
    // 0xf91418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf91418: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf9141c: b               #0xf913c0
    // 0xf91420: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf91420: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf91424: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf91424: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e6058, size: 0x88
    // 0x10e6058: EnterFrame
    //     0x10e6058: stp             fp, lr, [SP, #-0x10]!
    //     0x10e605c: mov             fp, SP
    // 0x10e6060: AllocStack(0x10)
    //     0x10e6060: sub             SP, SP, #0x10
    // 0x10e6064: SetupParameters(_SnackBarState this /* r1 => r0, fp-0x10 */)
    //     0x10e6064: mov             x0, x1
    //     0x10e6068: stur            x1, [fp, #-0x10]
    // 0x10e606c: CheckStackOverflow
    //     0x10e606c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e6070: cmp             SP, x16
    //     0x10e6074: b.ls            #0x10e60d0
    // 0x10e6078: LoadField: r1 = r0->field_b
    //     0x10e6078: ldur            w1, [x0, #0xb]
    // 0x10e607c: DecompressPointer r1
    //     0x10e607c: add             x1, x1, HEAP, lsl #32
    // 0x10e6080: cmp             w1, NULL
    // 0x10e6084: b.eq            #0x10e60d8
    // 0x10e6088: LoadField: r3 = r1->field_47
    //     0x10e6088: ldur            w3, [x1, #0x47]
    // 0x10e608c: DecompressPointer r3
    //     0x10e608c: add             x3, x3, HEAP, lsl #32
    // 0x10e6090: stur            x3, [fp, #-8]
    // 0x10e6094: cmp             w3, NULL
    // 0x10e6098: b.eq            #0x10e60dc
    // 0x10e609c: mov             x2, x0
    // 0x10e60a0: r1 = Function '_onAnimationStatusChanged@773267081':.
    //     0x10e60a0: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c8d0] AnonymousClosure: (0xf6ed88), in [package:flutter/src/material/snack_bar.dart] _SnackBarState::_onAnimationStatusChanged (0xf6edc4)
    //     0x10e60a4: ldr             x1, [x1, #0x8d0]
    // 0x10e60a8: r0 = AllocateClosure()
    //     0x10e60a8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e60ac: ldur            x1, [fp, #-8]
    // 0x10e60b0: mov             x2, x0
    // 0x10e60b4: r0 = removeStatusListener()
    //     0x10e60b4: bl              #0x12599f4  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::removeStatusListener
    // 0x10e60b8: ldur            x1, [fp, #-0x10]
    // 0x10e60bc: r0 = _disposeAnimations()
    //     0x10e60bc: bl              #0xf6ecbc  ; [package:flutter/src/material/snack_bar.dart] _SnackBarState::_disposeAnimations
    // 0x10e60c0: r0 = Null
    //     0x10e60c0: mov             x0, NULL
    // 0x10e60c4: LeaveFrame
    //     0x10e60c4: mov             SP, fp
    //     0x10e60c8: ldp             fp, lr, [SP], #0x10
    // 0x10e60cc: ret
    //     0x10e60cc: ret             
    // 0x10e60d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e60d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e60d4: b               #0x10e6078
    // 0x10e60d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e60d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10e60dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e60dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6432, size: 0x58, field offset: 0xc
//   const constructor, 
class SnackBar extends StatefulWidget {

  Text field_c;
  Duration field_40;
  bool field_44;
  Clip field_54;

  _ withAnimation(/* No info */) {
    // ** addr: 0xe62084, size: 0xac
    // 0xe62084: EnterFrame
    //     0xe62084: stp             fp, lr, [SP, #-0x10]!
    //     0xe62088: mov             fp, SP
    // 0xe6208c: AllocStack(0x30)
    //     0xe6208c: sub             SP, SP, #0x30
    // 0xe62090: SetupParameters(dynamic _ /* r2 => r2, fp-0x30 */)
    //     0xe62090: stur            x2, [fp, #-0x30]
    // 0xe62094: LoadField: r0 = r1->field_7
    //     0xe62094: ldur            w0, [x1, #7]
    // 0xe62098: DecompressPointer r0
    //     0xe62098: add             x0, x0, HEAP, lsl #32
    // 0xe6209c: cmp             w0, NULL
    // 0xe620a0: b.ne            #0xe620a8
    // 0xe620a4: mov             x0, x3
    // 0xe620a8: stur            x0, [fp, #-0x28]
    // 0xe620ac: LoadField: r3 = r1->field_b
    //     0xe620ac: ldur            w3, [x1, #0xb]
    // 0xe620b0: DecompressPointer r3
    //     0xe620b0: add             x3, x3, HEAP, lsl #32
    // 0xe620b4: stur            x3, [fp, #-0x20]
    // 0xe620b8: LoadField: r4 = r1->field_f
    //     0xe620b8: ldur            w4, [x1, #0xf]
    // 0xe620bc: DecompressPointer r4
    //     0xe620bc: add             x4, x4, HEAP, lsl #32
    // 0xe620c0: stur            x4, [fp, #-0x18]
    // 0xe620c4: LoadField: r5 = r1->field_2b
    //     0xe620c4: ldur            w5, [x1, #0x2b]
    // 0xe620c8: DecompressPointer r5
    //     0xe620c8: add             x5, x5, HEAP, lsl #32
    // 0xe620cc: stur            x5, [fp, #-0x10]
    // 0xe620d0: LoadField: r6 = r1->field_3f
    //     0xe620d0: ldur            w6, [x1, #0x3f]
    // 0xe620d4: DecompressPointer r6
    //     0xe620d4: add             x6, x6, HEAP, lsl #32
    // 0xe620d8: stur            x6, [fp, #-8]
    // 0xe620dc: r0 = SnackBar()
    //     0xe620dc: bl              #0xe623d4  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0xe620e0: ldur            x1, [fp, #-0x20]
    // 0xe620e4: StoreField: r0->field_b = r1
    //     0xe620e4: stur            w1, [x0, #0xb]
    // 0xe620e8: ldur            x1, [fp, #-0x18]
    // 0xe620ec: StoreField: r0->field_f = r1
    //     0xe620ec: stur            w1, [x0, #0xf]
    // 0xe620f0: ldur            x1, [fp, #-0x10]
    // 0xe620f4: StoreField: r0->field_2b = r1
    //     0xe620f4: stur            w1, [x0, #0x2b]
    // 0xe620f8: ldur            x1, [fp, #-8]
    // 0xe620fc: StoreField: r0->field_3f = r1
    //     0xe620fc: stur            w1, [x0, #0x3f]
    // 0xe62100: ldur            x1, [fp, #-0x30]
    // 0xe62104: StoreField: r0->field_47 = r1
    //     0xe62104: stur            w1, [x0, #0x47]
    // 0xe62108: r1 = Instance_Clip
    //     0xe62108: add             x1, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xe6210c: ldr             x1, [x1, #0x850]
    // 0xe62110: StoreField: r0->field_53 = r1
    //     0xe62110: stur            w1, [x0, #0x53]
    // 0xe62114: r1 = false
    //     0xe62114: add             x1, NULL, #0x30  ; false
    // 0xe62118: StoreField: r0->field_43 = r1
    //     0xe62118: stur            w1, [x0, #0x43]
    // 0xe6211c: ldur            x1, [fp, #-0x28]
    // 0xe62120: StoreField: r0->field_7 = r1
    //     0xe62120: stur            w1, [x0, #7]
    // 0xe62124: LeaveFrame
    //     0xe62124: mov             SP, fp
    //     0xe62128: ldp             fp, lr, [SP], #0x10
    // 0xe6212c: ret
    //     0xe6212c: ret             
  }
  static _ createAnimationController(/* No info */) {
    // ** addr: 0xe62130, size: 0x64
    // 0xe62130: EnterFrame
    //     0xe62130: stp             fp, lr, [SP, #-0x10]!
    //     0xe62134: mov             fp, SP
    // 0xe62138: AllocStack(0x20)
    //     0xe62138: sub             SP, SP, #0x20
    // 0xe6213c: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */)
    //     0xe6213c: mov             x2, x1
    //     0xe62140: stur            x1, [fp, #-8]
    // 0xe62144: CheckStackOverflow
    //     0xe62144: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe62148: cmp             SP, x16
    //     0xe6214c: b.ls            #0xe6218c
    // 0xe62150: r1 = <double>
    //     0xe62150: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xe62154: r0 = AnimationController()
    //     0xe62154: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xe62158: stur            x0, [fp, #-0x10]
    // 0xe6215c: r16 = Instance_Duration
    //     0xe6215c: add             x16, PP, #0xc, lsl #12  ; [pp+0xc920] Obj!Duration@12c89c1
    //     0xe62160: ldr             x16, [x16, #0x920]
    // 0xe62164: stp             NULL, x16, [SP]
    // 0xe62168: mov             x1, x0
    // 0xe6216c: ldur            x2, [fp, #-8]
    // 0xe62170: r4 = const [0, 0x4, 0x2, 0x2, duration, 0x2, reverseDuration, 0x3, null]
    //     0xe62170: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1e860] List(9) [0, 0x4, 0x2, 0x2, "duration", 0x2, "reverseDuration", 0x3, Null]
    //     0xe62174: ldr             x4, [x4, #0x860]
    // 0xe62178: r0 = AnimationController()
    //     0xe62178: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xe6217c: ldur            x0, [fp, #-0x10]
    // 0xe62180: LeaveFrame
    //     0xe62180: mov             SP, fp
    //     0xe62184: ldp             fp, lr, [SP], #0x10
    // 0xe62188: ret
    //     0xe62188: ret             
    // 0xe6218c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe6218c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe62190: b               #0xe62150
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa2fbc, size: 0x3c
    // 0xfa2fbc: EnterFrame
    //     0xfa2fbc: stp             fp, lr, [SP, #-0x10]!
    //     0xfa2fc0: mov             fp, SP
    // 0xfa2fc4: AllocStack(0x8)
    //     0xfa2fc4: sub             SP, SP, #8
    // 0xfa2fc8: SetupParameters(SnackBar this /* r1 => r0 */)
    //     0xfa2fc8: mov             x0, x1
    // 0xfa2fcc: r1 = <SnackBar>
    //     0xfa2fcc: add             x1, PP, #0x80, lsl #12  ; [pp+0x80938] TypeArguments: <SnackBar>
    //     0xfa2fd0: ldr             x1, [x1, #0x938]
    // 0xfa2fd4: r0 = _SnackBarState()
    //     0xfa2fd4: bl              #0xfa2ff8  ; Allocate_SnackBarStateStub -> _SnackBarState (size=0x2c)
    // 0xfa2fd8: stur            x0, [fp, #-8]
    // 0xfa2fdc: r0 = UniqueKey()
    //     0xfa2fdc: bl              #0xb8f328  ; AllocateUniqueKeyStub -> UniqueKey (size=0x8)
    // 0xfa2fe0: mov             x1, x0
    // 0xfa2fe4: ldur            x0, [fp, #-8]
    // 0xfa2fe8: StoreField: r0->field_27 = r1
    //     0xfa2fe8: stur            w1, [x0, #0x27]
    // 0xfa2fec: LeaveFrame
    //     0xfa2fec: mov             SP, fp
    //     0xfa2ff0: ldp             fp, lr, [SP], #0x10
    // 0xfa2ff4: ret
    //     0xfa2ff4: ret             
  }
}

// class id: 8262, size: 0x14, field offset: 0x14
enum SnackBarClosedReason extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa8c8, size: 0x64
    // 0x11aa8c8: EnterFrame
    //     0x11aa8c8: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa8cc: mov             fp, SP
    // 0x11aa8d0: AllocStack(0x10)
    //     0x11aa8d0: sub             SP, SP, #0x10
    // 0x11aa8d4: SetupParameters(SnackBarClosedReason this /* r1 => r0, fp-0x8 */)
    //     0x11aa8d4: mov             x0, x1
    //     0x11aa8d8: stur            x1, [fp, #-8]
    // 0x11aa8dc: CheckStackOverflow
    //     0x11aa8dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa8e0: cmp             SP, x16
    //     0x11aa8e4: b.ls            #0x11aa924
    // 0x11aa8e8: r1 = Null
    //     0x11aa8e8: mov             x1, NULL
    // 0x11aa8ec: r2 = 4
    //     0x11aa8ec: mov             x2, #4
    // 0x11aa8f0: r0 = AllocateArray()
    //     0x11aa8f0: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa8f4: r16 = "SnackBarClosedReason."
    //     0x11aa8f4: add             x16, PP, #0x80, lsl #12  ; [pp+0x80930] "SnackBarClosedReason."
    //     0x11aa8f8: ldr             x16, [x16, #0x930]
    // 0x11aa8fc: StoreField: r0->field_f = r16
    //     0x11aa8fc: stur            w16, [x0, #0xf]
    // 0x11aa900: ldur            x1, [fp, #-8]
    // 0x11aa904: LoadField: r2 = r1->field_f
    //     0x11aa904: ldur            w2, [x1, #0xf]
    // 0x11aa908: DecompressPointer r2
    //     0x11aa908: add             x2, x2, HEAP, lsl #32
    // 0x11aa90c: StoreField: r0->field_13 = r2
    //     0x11aa90c: stur            w2, [x0, #0x13]
    // 0x11aa910: str             x0, [SP]
    // 0x11aa914: r0 = _interpolate()
    //     0x11aa914: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa918: LeaveFrame
    //     0x11aa918: mov             SP, fp
    //     0x11aa91c: ldp             fp, lr, [SP], #0x10
    // 0x11aa920: ret
    //     0x11aa920: ret             
    // 0x11aa924: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa924: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa928: b               #0x11aa8e8
  }
}
