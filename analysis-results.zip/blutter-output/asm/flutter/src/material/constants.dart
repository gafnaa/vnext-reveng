// lib: , url: package:flutter/src/material/constants.dart

// class id: 1048871, size: 0x8
class :: {

  static late final Color kDefaultIconLightColor; // offset: 0xb80
  static late final Color kDefaultIconDarkColor; // offset: 0xb84

  static Color kDefaultIconDarkColor() {
    // ** addr: 0x8ad89c, size: 0x3c
    // 0x8ad89c: EnterFrame
    //     0x8ad89c: stp             fp, lr, [SP, #-0x10]!
    //     0x8ad8a0: mov             fp, SP
    // 0x8ad8a4: r0 = Color()
    //     0x8ad8a4: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8ad8a8: r1 = Instance_ColorSpace
    //     0x8ad8a8: add             x1, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8ad8ac: ldr             x1, [x1, #0x298]
    // 0x8ad8b0: StoreField: r0->field_27 = r1
    //     0x8ad8b0: stur            w1, [x0, #0x27]
    // 0x8ad8b4: d0 = 0.866667
    //     0x8ad8b4: add             x17, PP, #0x12, lsl #12  ; [pp+0x12f08] IMM: double(0.8666666666666667) from 0x3febbbbbbbbbbbbc
    //     0x8ad8b8: ldr             d0, [x17, #0xf08]
    // 0x8ad8bc: StoreField: r0->field_7 = d0
    //     0x8ad8bc: stur            d0, [x0, #7]
    // 0x8ad8c0: StoreField: r0->field_f = rZR
    //     0x8ad8c0: stur            xzr, [x0, #0xf]
    // 0x8ad8c4: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8ad8c4: stur            xzr, [x0, #0x17]
    // 0x8ad8c8: StoreField: r0->field_1f = rZR
    //     0x8ad8c8: stur            xzr, [x0, #0x1f]
    // 0x8ad8cc: LeaveFrame
    //     0x8ad8cc: mov             SP, fp
    //     0x8ad8d0: ldp             fp, lr, [SP], #0x10
    // 0x8ad8d4: ret
    //     0x8ad8d4: ret             
  }
  static Color kDefaultIconLightColor() {
    // ** addr: 0x8ad8e4, size: 0x38
    // 0x8ad8e4: EnterFrame
    //     0x8ad8e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8ad8e8: mov             fp, SP
    // 0x8ad8ec: r0 = Color()
    //     0x8ad8ec: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8ad8f0: r1 = Instance_ColorSpace
    //     0x8ad8f0: add             x1, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8ad8f4: ldr             x1, [x1, #0x298]
    // 0x8ad8f8: StoreField: r0->field_27 = r1
    //     0x8ad8f8: stur            w1, [x0, #0x27]
    // 0x8ad8fc: d0 = 1.000000
    //     0x8ad8fc: fmov            d0, #1.00000000
    // 0x8ad900: StoreField: r0->field_7 = d0
    //     0x8ad900: stur            d0, [x0, #7]
    // 0x8ad904: StoreField: r0->field_f = d0
    //     0x8ad904: stur            d0, [x0, #0xf]
    // 0x8ad908: ArrayStore: r0[0] = d0  ; List_8
    //     0x8ad908: stur            d0, [x0, #0x17]
    // 0x8ad90c: StoreField: r0->field_1f = d0
    //     0x8ad90c: stur            d0, [x0, #0x1f]
    // 0x8ad910: LeaveFrame
    //     0x8ad910: mov             SP, fp
    //     0x8ad914: ldp             fp, lr, [SP], #0x10
    // 0x8ad918: ret
    //     0x8ad918: ret             
  }
}
