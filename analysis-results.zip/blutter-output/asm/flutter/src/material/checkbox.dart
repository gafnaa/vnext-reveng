// lib: , url: package:flutter/src/material/checkbox.dart

// class id: 1048864, size: 0x8
class :: {
}

// class id: 4514, size: 0x78, field offset: 0x60
class _CheckboxPainter extends ToggleablePainter {

  bool? dyn:get:value(_CheckboxPainter) {
    // ** addr: 0xb6914c, size: 0x28
    // 0xb6914c: ldr             x1, [SP]
    // 0xb69150: LoadField: r0 = r1->field_63
    //     0xb69150: ldur            w0, [x1, #0x63]
    // 0xb69154: DecompressPointer r0
    //     0xb69154: add             x0, x0, HEAP, lsl #32
    // 0xb69158: ret
    //     0xb69158: ret             
  }
  void dyn:set:value(_CheckboxPainter, bool?) {
    // ** addr: 0xb69174, size: 0x80
    // 0xb69174: EnterFrame
    //     0xb69174: stp             fp, lr, [SP, #-0x10]!
    //     0xb69178: mov             fp, SP
    // 0xb6917c: CheckStackOverflow
    //     0xb6917c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb69180: cmp             SP, x16
    //     0xb69184: b.ls            #0xb691d4
    // 0xb69188: ldr             x0, [fp, #0x10]
    // 0xb6918c: r2 = Null
    //     0xb6918c: mov             x2, NULL
    // 0xb69190: r1 = Null
    //     0xb69190: mov             x1, NULL
    // 0xb69194: r4 = 60
    //     0xb69194: mov             x4, #0x3c
    // 0xb69198: branchIfSmi(r0, 0xb691a4)
    //     0xb69198: tbz             w0, #0, #0xb691a4
    // 0xb6919c: r4 = LoadClassIdInstr(r0)
    //     0xb6919c: ldur            x4, [x0, #-1]
    //     0xb691a0: ubfx            x4, x4, #0xc, #0x14
    // 0xb691a4: cmp             x4, #0x3f
    // 0xb691a8: b.eq            #0xb691bc
    // 0xb691ac: r8 = bool?
    //     0xb691ac: ldr             x8, [PP, #0x5fd0]  ; [pp+0x5fd0] Type: bool?
    // 0xb691b0: r3 = Null
    //     0xb691b0: add             x3, PP, #0x90, lsl #12  ; [pp+0x903f8] Null
    //     0xb691b4: ldr             x3, [x3, #0x3f8]
    // 0xb691b8: r0 = bool?()
    //     0xb691b8: bl              #0x7ecd2c  ; IsType_bool?_Stub
    // 0xb691bc: ldr             x1, [fp, #0x18]
    // 0xb691c0: ldr             x2, [fp, #0x10]
    // 0xb691c4: r0 = value=()
    //     0xb691c4: bl              #0xb691dc  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::value=
    // 0xb691c8: LeaveFrame
    //     0xb691c8: mov             SP, fp
    //     0xb691cc: ldp             fp, lr, [SP], #0x10
    // 0xb691d0: ret
    //     0xb691d0: ret             
    // 0xb691d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb691d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb691d8: b               #0xb69188
  }
  set void value=(_CheckboxPainter, bool?) {
    // ** addr: 0xb691dc, size: 0x54
    // 0xb691dc: EnterFrame
    //     0xb691dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb691e0: mov             fp, SP
    // 0xb691e4: CheckStackOverflow
    //     0xb691e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb691e8: cmp             SP, x16
    //     0xb691ec: b.ls            #0xb69228
    // 0xb691f0: LoadField: r0 = r1->field_63
    //     0xb691f0: ldur            w0, [x1, #0x63]
    // 0xb691f4: DecompressPointer r0
    //     0xb691f4: add             x0, x0, HEAP, lsl #32
    // 0xb691f8: cmp             w0, w2
    // 0xb691fc: b.ne            #0xb69210
    // 0xb69200: r0 = Null
    //     0xb69200: mov             x0, NULL
    // 0xb69204: LeaveFrame
    //     0xb69204: mov             SP, fp
    //     0xb69208: ldp             fp, lr, [SP], #0x10
    // 0xb6920c: ret
    //     0xb6920c: ret             
    // 0xb69210: StoreField: r1->field_63 = r2
    //     0xb69210: stur            w2, [x1, #0x63]
    // 0xb69214: r0 = notifyListeners()
    //     0xb69214: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xb69218: r0 = Null
    //     0xb69218: mov             x0, NULL
    // 0xb6921c: LeaveFrame
    //     0xb6921c: mov             SP, fp
    //     0xb69220: ldp             fp, lr, [SP], #0x10
    // 0xb69224: ret
    //     0xb69224: ret             
    // 0xb69228: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb69228: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6922c: b               #0xb691f0
  }
  _ paint(/* No info */) {
    // ** addr: 0xb6b304, size: 0x4ac
    // 0xb6b304: EnterFrame
    //     0xb6b304: stp             fp, lr, [SP, #-0x10]!
    //     0xb6b308: mov             fp, SP
    // 0xb6b30c: AllocStack(0x60)
    //     0xb6b30c: sub             SP, SP, #0x60
    // 0xb6b310: SetupParameters(_CheckboxPainter this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0xb6b310: mov             x0, x3
    //     0xb6b314: stur            x3, [fp, #-0x18]
    //     0xb6b318: mov             x3, x1
    //     0xb6b31c: stur            x1, [fp, #-8]
    //     0xb6b320: stur            x2, [fp, #-0x10]
    // 0xb6b324: CheckStackOverflow
    //     0xb6b324: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6b328: cmp             SP, x16
    //     0xb6b32c: b.ls            #0xb6b75c
    // 0xb6b330: mov             x1, x0
    // 0xb6b334: r0 = center()
    //     0xb6b334: bl              #0xaf9a1c  ; [dart:ui] Size::center
    // 0xb6b338: ldur            x1, [fp, #-8]
    // 0xb6b33c: ldur            x2, [fp, #-0x10]
    // 0xb6b340: mov             x3, x0
    // 0xb6b344: r0 = paintRadialReaction()
    //     0xb6b344: bl              #0xb6c1b8  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::paintRadialReaction
    // 0xb6b348: ldur            x1, [fp, #-8]
    // 0xb6b34c: r0 = _createStrokePaint()
    //     0xb6b34c: bl              #0xb6c118  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_createStrokePaint
    // 0xb6b350: ldur            x1, [fp, #-0x18]
    // 0xb6b354: d0 = 2.000000
    //     0xb6b354: fmov            d0, #2.00000000
    // 0xb6b358: stur            x0, [fp, #-0x18]
    // 0xb6b35c: r0 = /()
    //     0xb6b35c: bl              #0x8a6e1c  ; [dart:ui] Size::/
    // 0xb6b360: r1 = Instance_Size
    //     0xb6b360: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4098] Obj!Size@12a7571
    //     0xb6b364: ldr             x1, [x1, #0x98]
    // 0xb6b368: d0 = 2.000000
    //     0xb6b368: fmov            d0, #2.00000000
    // 0xb6b36c: stur            x0, [fp, #-0x20]
    // 0xb6b370: r0 = /()
    //     0xb6b370: bl              #0x8a6e1c  ; [dart:ui] Size::/
    // 0xb6b374: ldur            x1, [fp, #-0x20]
    // 0xb6b378: mov             x2, x0
    // 0xb6b37c: r0 = -()
    //     0xb6b37c: bl              #0x81d2c0  ; [dart:ui] Size::-
    // 0xb6b380: mov             x2, x0
    // 0xb6b384: ldur            x0, [fp, #-8]
    // 0xb6b388: stur            x2, [fp, #-0x20]
    // 0xb6b38c: LoadField: r1 = r0->field_23
    //     0xb6b38c: ldur            w1, [x0, #0x23]
    // 0xb6b390: DecompressPointer r1
    //     0xb6b390: add             x1, x1, HEAP, lsl #32
    // 0xb6b394: cmp             w1, NULL
    // 0xb6b398: b.eq            #0xb6b764
    // 0xb6b39c: r0 = status()
    //     0xb6b39c: bl              #0x1284c0c  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::status
    // 0xb6b3a0: r16 = Instance_AnimationStatus
    //     0xb6b3a0: ldr             x16, [PP, #0x51b8]  ; [pp+0x51b8] Obj!AnimationStatus@12c6181
    // 0xb6b3a4: cmp             w0, w16
    // 0xb6b3a8: b.eq            #0xb6b3b8
    // 0xb6b3ac: r16 = Instance_AnimationStatus
    //     0xb6b3ac: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0xb6b3b0: cmp             w0, w16
    // 0xb6b3b4: b.ne            #0xb6b3dc
    // 0xb6b3b8: ldur            x0, [fp, #-8]
    // 0xb6b3bc: LoadField: r1 = r0->field_23
    //     0xb6b3bc: ldur            w1, [x0, #0x23]
    // 0xb6b3c0: DecompressPointer r1
    //     0xb6b3c0: add             x1, x1, HEAP, lsl #32
    // 0xb6b3c4: cmp             w1, NULL
    // 0xb6b3c8: b.eq            #0xb6b768
    // 0xb6b3cc: r0 = value()
    //     0xb6b3cc: bl              #0xae5f84  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xb6b3d0: mov             x3, x0
    // 0xb6b3d4: d1 = 1.000000
    //     0xb6b3d4: fmov            d1, #1.00000000
    // 0xb6b3d8: b               #0xb6b454
    // 0xb6b3dc: r16 = Instance_AnimationStatus
    //     0xb6b3dc: ldr             x16, [PP, #0x51c0]  ; [pp+0x51c0] Obj!AnimationStatus@12c6161
    // 0xb6b3e0: cmp             w0, w16
    // 0xb6b3e4: b.eq            #0xb6b3f4
    // 0xb6b3e8: r16 = Instance_AnimationStatus
    //     0xb6b3e8: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xb6b3ec: cmp             w0, w16
    // 0xb6b3f0: b.ne            #0xb6b44c
    // 0xb6b3f4: ldur            x0, [fp, #-8]
    // 0xb6b3f8: LoadField: r1 = r0->field_23
    //     0xb6b3f8: ldur            w1, [x0, #0x23]
    // 0xb6b3fc: DecompressPointer r1
    //     0xb6b3fc: add             x1, x1, HEAP, lsl #32
    // 0xb6b400: cmp             w1, NULL
    // 0xb6b404: b.eq            #0xb6b76c
    // 0xb6b408: r0 = value()
    //     0xb6b408: bl              #0xae5f84  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xb6b40c: LoadField: d0 = r0->field_7
    //     0xb6b40c: ldur            d0, [x0, #7]
    // 0xb6b410: d1 = 1.000000
    //     0xb6b410: fmov            d1, #1.00000000
    // 0xb6b414: fsub            d2, d1, d0
    // 0xb6b418: r0 = inline_Allocate_Double()
    //     0xb6b418: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb6b41c: add             x0, x0, #0x10
    //     0xb6b420: cmp             x1, x0
    //     0xb6b424: b.ls            #0xb6b770
    //     0xb6b428: str             x0, [THR, #0x60]  ; THR::top
    //     0xb6b42c: sub             x0, x0, #0xf
    //     0xb6b430: mov             x1, #0xe19c
    //     0xb6b434: movk            x1, #3, lsl #16
    //     0xb6b438: stur            x1, [x0, #-1]
    // 0xb6b43c: dmb             ishst
    // 0xb6b440: StoreField: r0->field_7 = d2
    //     0xb6b440: stur            d2, [x0, #7]
    // 0xb6b444: mov             x3, x0
    // 0xb6b448: b               #0xb6b454
    // 0xb6b44c: d1 = 1.000000
    //     0xb6b44c: fmov            d1, #1.00000000
    // 0xb6b450: r3 = Null
    //     0xb6b450: mov             x3, NULL
    // 0xb6b454: ldur            x0, [fp, #-8]
    // 0xb6b458: stur            x3, [fp, #-0x48]
    // 0xb6b45c: LoadField: r1 = r0->field_67
    //     0xb6b45c: ldur            w1, [x0, #0x67]
    // 0xb6b460: DecompressPointer r1
    //     0xb6b460: add             x1, x1, HEAP, lsl #32
    // 0xb6b464: r16 = false
    //     0xb6b464: add             x16, NULL, #0x30  ; false
    // 0xb6b468: cmp             w1, w16
    // 0xb6b46c: b.eq            #0xb6b484
    // 0xb6b470: LoadField: r1 = r0->field_63
    //     0xb6b470: ldur            w1, [x0, #0x63]
    // 0xb6b474: DecompressPointer r1
    //     0xb6b474: add             x1, x1, HEAP, lsl #32
    // 0xb6b478: r16 = false
    //     0xb6b478: add             x16, NULL, #0x30  ; false
    // 0xb6b47c: cmp             w1, w16
    // 0xb6b480: b.ne            #0xb6b620
    // 0xb6b484: LoadField: r1 = r0->field_63
    //     0xb6b484: ldur            w1, [x0, #0x63]
    // 0xb6b488: DecompressPointer r1
    //     0xb6b488: add             x1, x1, HEAP, lsl #32
    // 0xb6b48c: r16 = false
    //     0xb6b48c: add             x16, NULL, #0x30  ; false
    // 0xb6b490: cmp             w1, w16
    // 0xb6b494: b.ne            #0xb6b4d0
    // 0xb6b498: LoadField: d0 = r3->field_7
    //     0xb6b498: ldur            d0, [x3, #7]
    // 0xb6b49c: fsub            d2, d1, d0
    // 0xb6b4a0: r1 = inline_Allocate_Double()
    //     0xb6b4a0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb6b4a4: add             x1, x1, #0x10
    //     0xb6b4a8: cmp             x2, x1
    //     0xb6b4ac: b.ls            #0xb6b780
    //     0xb6b4b0: str             x1, [THR, #0x60]  ; THR::top
    //     0xb6b4b4: sub             x1, x1, #0xf
    //     0xb6b4b8: mov             x2, #0xe19c
    //     0xb6b4bc: movk            x2, #3, lsl #16
    //     0xb6b4c0: stur            x2, [x1, #-1]
    // 0xb6b4c4: dmb             ishst
    // 0xb6b4c8: StoreField: r1->field_7 = d2
    //     0xb6b4c8: stur            d2, [x1, #7]
    // 0xb6b4cc: mov             x3, x1
    // 0xb6b4d0: stur            x3, [fp, #-0x28]
    // 0xb6b4d4: LoadField: d1 = r3->field_7
    //     0xb6b4d4: ldur            d1, [x3, #7]
    // 0xb6b4d8: mov             x1, x0
    // 0xb6b4dc: ldur            x2, [fp, #-0x20]
    // 0xb6b4e0: mov             v0.16b, v1.16b
    // 0xb6b4e4: stur            d1, [fp, #-0x50]
    // 0xb6b4e8: r0 = _outerRectAt()
    //     0xb6b4e8: bl              #0xb6c064  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_outerRectAt
    // 0xb6b4ec: stur            x0, [fp, #-0x30]
    // 0xb6b4f0: r16 = 136
    //     0xb6b4f0: mov             x16, #0x88
    // 0xb6b4f4: stp             x16, NULL, [SP]
    // 0xb6b4f8: r0 = ByteData()
    //     0xb6b4f8: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb6b4fc: stur            x0, [fp, #-0x38]
    // 0xb6b500: r0 = Paint()
    //     0xb6b500: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb6b504: mov             x2, x0
    // 0xb6b508: ldur            x0, [fp, #-0x38]
    // 0xb6b50c: stur            x2, [fp, #-0x40]
    // 0xb6b510: StoreField: r2->field_7 = r0
    //     0xb6b510: stur            w0, [x2, #7]
    // 0xb6b514: ldur            x1, [fp, #-8]
    // 0xb6b518: ldur            d0, [fp, #-0x50]
    // 0xb6b51c: r0 = _colorAt()
    //     0xb6b51c: bl              #0xb6bf98  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_colorAt
    // 0xb6b520: ldur            x1, [fp, #-0x40]
    // 0xb6b524: mov             x2, x0
    // 0xb6b528: r0 = color=()
    //     0xb6b528: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb6b52c: ldur            x0, [fp, #-0x28]
    // 0xb6b530: cmp             w0, NULL
    // 0xb6b534: b.eq            #0xb6b79c
    // 0xb6b538: ldur            d1, [fp, #-0x50]
    // 0xb6b53c: d0 = 0.500000
    //     0xb6b53c: fmov            d0, #0.50000000
    // 0xb6b540: fcmp            d0, d1
    // 0xb6b544: b.lt            #0xb6b590
    // 0xb6b548: ldur            x0, [fp, #-8]
    // 0xb6b54c: LoadField: r1 = r0->field_73
    //     0xb6b54c: ldur            w1, [x0, #0x73]
    // 0xb6b550: DecompressPointer r1
    //     0xb6b550: add             x1, x1, HEAP, lsl #32
    // 0xb6b554: cmp             w1, NULL
    // 0xb6b558: b.eq            #0xb6b7a0
    // 0xb6b55c: LoadField: r2 = r0->field_6f
    //     0xb6b55c: ldur            w2, [x0, #0x6f]
    // 0xb6b560: DecompressPointer r2
    //     0xb6b560: add             x2, x2, HEAP, lsl #32
    // 0xb6b564: cmp             w2, NULL
    // 0xb6b568: b.eq            #0xb6b7a4
    // 0xb6b56c: mov             v0.16b, v1.16b
    // 0xb6b570: r0 = lerp()
    //     0xb6b570: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0xb6b574: ldur            x1, [fp, #-8]
    // 0xb6b578: ldur            x2, [fp, #-0x10]
    // 0xb6b57c: ldur            x3, [fp, #-0x30]
    // 0xb6b580: ldur            x5, [fp, #-0x40]
    // 0xb6b584: mov             x6, x0
    // 0xb6b588: r0 = _drawBox()
    //     0xb6b588: bl              #0xb6beec  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_drawBox
    // 0xb6b58c: b               #0xb6b74c
    // 0xb6b590: ldur            x0, [fp, #-8]
    // 0xb6b594: LoadField: r6 = r0->field_6f
    //     0xb6b594: ldur            w6, [x0, #0x6f]
    // 0xb6b598: DecompressPointer r6
    //     0xb6b598: add             x6, x6, HEAP, lsl #32
    // 0xb6b59c: cmp             w6, NULL
    // 0xb6b5a0: b.eq            #0xb6b7a8
    // 0xb6b5a4: mov             x1, x0
    // 0xb6b5a8: ldur            x2, [fp, #-0x10]
    // 0xb6b5ac: ldur            x3, [fp, #-0x30]
    // 0xb6b5b0: ldur            x5, [fp, #-0x40]
    // 0xb6b5b4: r0 = _drawBox()
    //     0xb6b5b4: bl              #0xb6beec  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_drawBox
    // 0xb6b5b8: ldur            d0, [fp, #-0x50]
    // 0xb6b5bc: d2 = 0.500000
    //     0xb6b5bc: fmov            d2, #0.50000000
    // 0xb6b5c0: fsub            d1, d0, d2
    // 0xb6b5c4: d3 = 2.000000
    //     0xb6b5c4: fmov            d3, #2.00000000
    // 0xb6b5c8: fmul            d0, d1, d3
    // 0xb6b5cc: ldur            x0, [fp, #-8]
    // 0xb6b5d0: LoadField: r1 = r0->field_67
    //     0xb6b5d0: ldur            w1, [x0, #0x67]
    // 0xb6b5d4: DecompressPointer r1
    //     0xb6b5d4: add             x1, x1, HEAP, lsl #32
    // 0xb6b5d8: cmp             w1, NULL
    // 0xb6b5dc: b.eq            #0xb6b5f0
    // 0xb6b5e0: LoadField: r1 = r0->field_63
    //     0xb6b5e0: ldur            w1, [x0, #0x63]
    // 0xb6b5e4: DecompressPointer r1
    //     0xb6b5e4: add             x1, x1, HEAP, lsl #32
    // 0xb6b5e8: cmp             w1, NULL
    // 0xb6b5ec: b.ne            #0xb6b608
    // 0xb6b5f0: mov             x1, x0
    // 0xb6b5f4: ldur            x2, [fp, #-0x10]
    // 0xb6b5f8: ldur            x3, [fp, #-0x20]
    // 0xb6b5fc: ldur            x5, [fp, #-0x18]
    // 0xb6b600: r0 = _drawDash()
    //     0xb6b600: bl              #0xb6bda0  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_drawDash
    // 0xb6b604: b               #0xb6b74c
    // 0xb6b608: mov             x1, x0
    // 0xb6b60c: ldur            x2, [fp, #-0x10]
    // 0xb6b610: ldur            x3, [fp, #-0x20]
    // 0xb6b614: ldur            x5, [fp, #-0x18]
    // 0xb6b618: r0 = _drawCheck()
    //     0xb6b618: bl              #0xb6b7b0  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_drawCheck
    // 0xb6b61c: b               #0xb6b74c
    // 0xb6b620: d3 = 2.000000
    //     0xb6b620: fmov            d3, #2.00000000
    // 0xb6b624: d2 = 0.500000
    //     0xb6b624: fmov            d2, #0.50000000
    // 0xb6b628: mov             x1, x0
    // 0xb6b62c: ldur            x2, [fp, #-0x20]
    // 0xb6b630: mov             v0.16b, v1.16b
    // 0xb6b634: r0 = _outerRectAt()
    //     0xb6b634: bl              #0xb6c064  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_outerRectAt
    // 0xb6b638: stur            x0, [fp, #-0x28]
    // 0xb6b63c: r16 = 136
    //     0xb6b63c: mov             x16, #0x88
    // 0xb6b640: stp             x16, NULL, [SP]
    // 0xb6b644: r0 = ByteData()
    //     0xb6b644: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb6b648: stur            x0, [fp, #-0x30]
    // 0xb6b64c: r0 = Paint()
    //     0xb6b64c: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb6b650: mov             x2, x0
    // 0xb6b654: ldur            x0, [fp, #-0x30]
    // 0xb6b658: stur            x2, [fp, #-0x38]
    // 0xb6b65c: StoreField: r2->field_7 = r0
    //     0xb6b65c: stur            w0, [x2, #7]
    // 0xb6b660: ldur            x1, [fp, #-8]
    // 0xb6b664: d0 = 1.000000
    //     0xb6b664: fmov            d0, #1.00000000
    // 0xb6b668: r0 = _colorAt()
    //     0xb6b668: bl              #0xb6bf98  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_colorAt
    // 0xb6b66c: ldur            x1, [fp, #-0x38]
    // 0xb6b670: mov             x2, x0
    // 0xb6b674: r0 = color=()
    //     0xb6b674: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb6b678: ldur            x0, [fp, #-8]
    // 0xb6b67c: LoadField: r6 = r0->field_6f
    //     0xb6b67c: ldur            w6, [x0, #0x6f]
    // 0xb6b680: DecompressPointer r6
    //     0xb6b680: add             x6, x6, HEAP, lsl #32
    // 0xb6b684: cmp             w6, NULL
    // 0xb6b688: b.eq            #0xb6b7ac
    // 0xb6b68c: mov             x1, x0
    // 0xb6b690: ldur            x2, [fp, #-0x10]
    // 0xb6b694: ldur            x3, [fp, #-0x28]
    // 0xb6b698: ldur            x5, [fp, #-0x38]
    // 0xb6b69c: r0 = _drawBox()
    //     0xb6b69c: bl              #0xb6beec  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_drawBox
    // 0xb6b6a0: ldur            x0, [fp, #-0x48]
    // 0xb6b6a4: LoadField: d0 = r0->field_7
    //     0xb6b6a4: ldur            d0, [x0, #7]
    // 0xb6b6a8: d1 = 0.500000
    //     0xb6b6a8: fmov            d1, #0.50000000
    // 0xb6b6ac: fcmp            d1, d0
    // 0xb6b6b0: b.lt            #0xb6b704
    // 0xb6b6b4: ldur            x1, [fp, #-8]
    // 0xb6b6b8: d2 = 2.000000
    //     0xb6b6b8: fmov            d2, #2.00000000
    // 0xb6b6bc: d1 = 1.000000
    //     0xb6b6bc: fmov            d1, #1.00000000
    // 0xb6b6c0: fmul            d3, d0, d2
    // 0xb6b6c4: fsub            d0, d1, d3
    // 0xb6b6c8: LoadField: r0 = r1->field_67
    //     0xb6b6c8: ldur            w0, [x1, #0x67]
    // 0xb6b6cc: DecompressPointer r0
    //     0xb6b6cc: add             x0, x0, HEAP, lsl #32
    // 0xb6b6d0: cmp             w0, NULL
    // 0xb6b6d4: b.eq            #0xb6b6f0
    // 0xb6b6d8: tbnz            w0, #4, #0xb6b6f0
    // 0xb6b6dc: ldur            x2, [fp, #-0x10]
    // 0xb6b6e0: ldur            x3, [fp, #-0x20]
    // 0xb6b6e4: ldur            x5, [fp, #-0x18]
    // 0xb6b6e8: r0 = _drawCheck()
    //     0xb6b6e8: bl              #0xb6b7b0  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_drawCheck
    // 0xb6b6ec: b               #0xb6b74c
    // 0xb6b6f0: ldur            x2, [fp, #-0x10]
    // 0xb6b6f4: ldur            x3, [fp, #-0x20]
    // 0xb6b6f8: ldur            x5, [fp, #-0x18]
    // 0xb6b6fc: r0 = _drawDash()
    //     0xb6b6fc: bl              #0xb6bda0  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_drawDash
    // 0xb6b700: b               #0xb6b74c
    // 0xb6b704: ldur            x1, [fp, #-8]
    // 0xb6b708: d2 = 2.000000
    //     0xb6b708: fmov            d2, #2.00000000
    // 0xb6b70c: fsub            d3, d0, d1
    // 0xb6b710: fmul            d0, d3, d2
    // 0xb6b714: LoadField: r0 = r1->field_63
    //     0xb6b714: ldur            w0, [x1, #0x63]
    // 0xb6b718: DecompressPointer r0
    //     0xb6b718: add             x0, x0, HEAP, lsl #32
    // 0xb6b71c: cmp             w0, NULL
    // 0xb6b720: b.eq            #0xb6b73c
    // 0xb6b724: tbnz            w0, #4, #0xb6b73c
    // 0xb6b728: ldur            x2, [fp, #-0x10]
    // 0xb6b72c: ldur            x3, [fp, #-0x20]
    // 0xb6b730: ldur            x5, [fp, #-0x18]
    // 0xb6b734: r0 = _drawCheck()
    //     0xb6b734: bl              #0xb6b7b0  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_drawCheck
    // 0xb6b738: b               #0xb6b74c
    // 0xb6b73c: ldur            x2, [fp, #-0x10]
    // 0xb6b740: ldur            x3, [fp, #-0x20]
    // 0xb6b744: ldur            x5, [fp, #-0x18]
    // 0xb6b748: r0 = _drawDash()
    //     0xb6b748: bl              #0xb6bda0  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_drawDash
    // 0xb6b74c: r0 = Null
    //     0xb6b74c: mov             x0, NULL
    // 0xb6b750: LeaveFrame
    //     0xb6b750: mov             SP, fp
    //     0xb6b754: ldp             fp, lr, [SP], #0x10
    // 0xb6b758: ret
    //     0xb6b758: ret             
    // 0xb6b75c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6b75c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6b760: b               #0xb6b330
    // 0xb6b764: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6b764: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6b768: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6b768: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6b76c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6b76c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6b770: stp             q1, q2, [SP, #-0x20]!
    // 0xb6b774: r0 = AllocateDouble()
    //     0xb6b774: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb6b778: ldp             q1, q2, [SP], #0x20
    // 0xb6b77c: b               #0xb6b440
    // 0xb6b780: SaveReg d2
    //     0xb6b780: str             q2, [SP, #-0x10]!
    // 0xb6b784: SaveReg r0
    //     0xb6b784: str             x0, [SP, #-8]!
    // 0xb6b788: r0 = AllocateDouble()
    //     0xb6b788: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb6b78c: mov             x1, x0
    // 0xb6b790: RestoreReg r0
    //     0xb6b790: ldr             x0, [SP], #8
    // 0xb6b794: RestoreReg d2
    //     0xb6b794: ldr             q2, [SP], #0x10
    // 0xb6b798: b               #0xb6b4c8
    // 0xb6b79c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb6b79c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb6b7a0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6b7a0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6b7a4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6b7a4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6b7a8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6b7a8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6b7ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6b7ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _drawCheck(/* No info */) {
    // ** addr: 0xb6b7b0, size: 0x4d4
    // 0xb6b7b0: EnterFrame
    //     0xb6b7b0: stp             fp, lr, [SP, #-0x10]!
    //     0xb6b7b4: mov             fp, SP
    // 0xb6b7b8: AllocStack(0x60)
    //     0xb6b7b8: sub             SP, SP, #0x60
    // 0xb6b7bc: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x38 */)
    //     0xb6b7bc: stur            x2, [fp, #-8]
    //     0xb6b7c0: stur            x3, [fp, #-0x10]
    //     0xb6b7c4: stur            x5, [fp, #-0x18]
    //     0xb6b7c8: stur            d0, [fp, #-0x38]
    // 0xb6b7cc: CheckStackOverflow
    //     0xb6b7cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6b7d0: cmp             SP, x16
    //     0xb6b7d4: b.ls            #0xb6bc18
    // 0xb6b7d8: r0 = _NativePath()
    //     0xb6b7d8: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xb6b7dc: mov             x1, x0
    // 0xb6b7e0: stur            x0, [fp, #-0x20]
    // 0xb6b7e4: r0 = __constructor$Method$FfiNative()
    //     0xb6b7e4: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xb6b7e8: ldur            d1, [fp, #-0x38]
    // 0xb6b7ec: d0 = 0.500000
    //     0xb6b7ec: fmov            d0, #0.50000000
    // 0xb6b7f0: fcmp            d0, d1
    // 0xb6b7f4: b.le            #0xb6b940
    // 0xb6b7f8: ldur            x4, [fp, #-0x10]
    // 0xb6b7fc: ldur            x0, [fp, #-0x20]
    // 0xb6b800: r5 = Instance_Offset
    //     0xb6b800: add             x5, PP, #0xa4, lsl #12  ; [pp+0xa40a0] Obj!Offset@12a7cf1
    //     0xb6b804: ldr             x5, [x5, #0xa0]
    // 0xb6b808: d2 = 2.000000
    //     0xb6b808: fmov            d2, #2.00000000
    // 0xb6b80c: fmul            d0, d1, d2
    // 0xb6b810: r3 = inline_Allocate_Double()
    //     0xb6b810: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0xb6b814: add             x3, x3, #0x10
    //     0xb6b818: cmp             x1, x3
    //     0xb6b81c: b.ls            #0xb6bc20
    //     0xb6b820: str             x3, [THR, #0x60]  ; THR::top
    //     0xb6b824: sub             x3, x3, #0xf
    //     0xb6b828: mov             x1, #0xe19c
    //     0xb6b82c: movk            x1, #3, lsl #16
    //     0xb6b830: stur            x1, [x3, #-1]
    // 0xb6b834: dmb             ishst
    // 0xb6b838: StoreField: r3->field_7 = d0
    //     0xb6b838: stur            d0, [x3, #7]
    // 0xb6b83c: mov             x1, x5
    // 0xb6b840: r2 = Instance_Offset
    //     0xb6b840: add             x2, PP, #0xa4, lsl #12  ; [pp+0xa40a8] Obj!Offset@12a7cd1
    //     0xb6b844: ldr             x2, [x2, #0xa8]
    // 0xb6b848: r0 = lerp()
    //     0xb6b848: bl              #0xb6bc84  ; [dart:ui] Offset::lerp
    // 0xb6b84c: mov             x2, x0
    // 0xb6b850: ldur            x0, [fp, #-0x10]
    // 0xb6b854: stur            x2, [fp, #-0x30]
    // 0xb6b858: LoadField: d0 = r0->field_7
    //     0xb6b858: ldur            d0, [x0, #7]
    // 0xb6b85c: stur            d0, [fp, #-0x58]
    // 0xb6b860: r4 = Instance_Offset
    //     0xb6b860: add             x4, PP, #0xa4, lsl #12  ; [pp+0xa40a0] Obj!Offset@12a7cf1
    //     0xb6b864: ldr             x4, [x4, #0xa0]
    // 0xb6b868: LoadField: d1 = r4->field_7
    //     0xb6b868: ldur            d1, [x4, #7]
    // 0xb6b86c: fadd            d2, d0, d1
    // 0xb6b870: stur            d2, [fp, #-0x50]
    // 0xb6b874: LoadField: d1 = r0->field_f
    //     0xb6b874: ldur            d1, [x0, #0xf]
    // 0xb6b878: stur            d1, [fp, #-0x48]
    // 0xb6b87c: LoadField: d3 = r4->field_f
    //     0xb6b87c: ldur            d3, [x4, #0xf]
    // 0xb6b880: fadd            d4, d1, d3
    // 0xb6b884: ldur            x0, [fp, #-0x20]
    // 0xb6b888: stur            d4, [fp, #-0x40]
    // 0xb6b88c: LoadField: r1 = r0->field_7
    //     0xb6b88c: ldur            w1, [x0, #7]
    // 0xb6b890: DecompressPointer r1
    //     0xb6b890: add             x1, x1, HEAP, lsl #32
    // 0xb6b894: cmp             w1, NULL
    // 0xb6b898: b.eq            #0xb6bc44
    // 0xb6b89c: LoadField: r3 = r1->field_7
    //     0xb6b89c: ldur            x3, [x1, #7]
    // 0xb6b8a0: ldr             x1, [x3]
    // 0xb6b8a4: cbz             x1, #0xb6bbb8
    // 0xb6b8a8: mov             x3, x1
    // 0xb6b8ac: stur            x3, [fp, #-0x28]
    // 0xb6b8b0: r1 = <Never>
    //     0xb6b8b0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb6b8b4: r0 = Pointer()
    //     0xb6b8b4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb6b8b8: mov             x1, x0
    // 0xb6b8bc: ldur            x0, [fp, #-0x28]
    // 0xb6b8c0: StoreField: r1->field_7 = r0
    //     0xb6b8c0: stur            x0, [x1, #7]
    // 0xb6b8c4: ldur            d0, [fp, #-0x50]
    // 0xb6b8c8: ldur            d1, [fp, #-0x40]
    // 0xb6b8cc: r0 = _moveTo$Method$FfiNative()
    //     0xb6b8cc: bl              #0xb69c74  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0xb6b8d0: ldur            x0, [fp, #-0x30]
    // 0xb6b8d4: LoadField: d0 = r0->field_7
    //     0xb6b8d4: ldur            d0, [x0, #7]
    // 0xb6b8d8: ldur            d1, [fp, #-0x58]
    // 0xb6b8dc: fadd            d2, d1, d0
    // 0xb6b8e0: stur            d2, [fp, #-0x50]
    // 0xb6b8e4: LoadField: d0 = r0->field_f
    //     0xb6b8e4: ldur            d0, [x0, #0xf]
    // 0xb6b8e8: ldur            d1, [fp, #-0x48]
    // 0xb6b8ec: fadd            d3, d1, d0
    // 0xb6b8f0: ldur            x0, [fp, #-0x20]
    // 0xb6b8f4: stur            d3, [fp, #-0x40]
    // 0xb6b8f8: LoadField: r1 = r0->field_7
    //     0xb6b8f8: ldur            w1, [x0, #7]
    // 0xb6b8fc: DecompressPointer r1
    //     0xb6b8fc: add             x1, x1, HEAP, lsl #32
    // 0xb6b900: cmp             w1, NULL
    // 0xb6b904: b.eq            #0xb6bc48
    // 0xb6b908: LoadField: r2 = r1->field_7
    //     0xb6b908: ldur            x2, [x1, #7]
    // 0xb6b90c: ldr             x1, [x2]
    // 0xb6b910: cbz             x1, #0xb6bbc8
    // 0xb6b914: mov             x2, x1
    // 0xb6b918: stur            x2, [fp, #-0x28]
    // 0xb6b91c: r1 = <Never>
    //     0xb6b91c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb6b920: r0 = Pointer()
    //     0xb6b920: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb6b924: mov             x1, x0
    // 0xb6b928: ldur            x0, [fp, #-0x28]
    // 0xb6b92c: StoreField: r1->field_7 = r0
    //     0xb6b92c: stur            x0, [x1, #7]
    // 0xb6b930: ldur            d0, [fp, #-0x50]
    // 0xb6b934: ldur            d1, [fp, #-0x40]
    // 0xb6b938: r0 = _lineTo$Method$FfiNative()
    //     0xb6b938: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0xb6b93c: b               #0xb6bb00
    // 0xb6b940: ldur            x0, [fp, #-0x10]
    // 0xb6b944: ldur            x5, [fp, #-0x20]
    // 0xb6b948: r4 = Instance_Offset
    //     0xb6b948: add             x4, PP, #0xa4, lsl #12  ; [pp+0xa40a0] Obj!Offset@12a7cf1
    //     0xb6b94c: ldr             x4, [x4, #0xa0]
    // 0xb6b950: d2 = 2.000000
    //     0xb6b950: fmov            d2, #2.00000000
    // 0xb6b954: fsub            d3, d1, d0
    // 0xb6b958: fmul            d0, d3, d2
    // 0xb6b95c: r3 = inline_Allocate_Double()
    //     0xb6b95c: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0xb6b960: add             x3, x3, #0x10
    //     0xb6b964: cmp             x1, x3
    //     0xb6b968: b.ls            #0xb6bc4c
    //     0xb6b96c: str             x3, [THR, #0x60]  ; THR::top
    //     0xb6b970: sub             x3, x3, #0xf
    //     0xb6b974: mov             x1, #0xe19c
    //     0xb6b978: movk            x1, #3, lsl #16
    //     0xb6b97c: stur            x1, [x3, #-1]
    // 0xb6b980: dmb             ishst
    // 0xb6b984: StoreField: r3->field_7 = d0
    //     0xb6b984: stur            d0, [x3, #7]
    // 0xb6b988: r1 = Instance_Offset
    //     0xb6b988: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa40a8] Obj!Offset@12a7cd1
    //     0xb6b98c: ldr             x1, [x1, #0xa8]
    // 0xb6b990: r2 = Instance_Offset
    //     0xb6b990: add             x2, PP, #0xa4, lsl #12  ; [pp+0xa40b0] Obj!Offset@12a7cb1
    //     0xb6b994: ldr             x2, [x2, #0xb0]
    // 0xb6b998: r0 = lerp()
    //     0xb6b998: bl              #0xb6bc84  ; [dart:ui] Offset::lerp
    // 0xb6b99c: mov             x2, x0
    // 0xb6b9a0: ldur            x0, [fp, #-0x10]
    // 0xb6b9a4: stur            x2, [fp, #-0x30]
    // 0xb6b9a8: LoadField: d0 = r0->field_7
    //     0xb6b9a8: ldur            d0, [x0, #7]
    // 0xb6b9ac: stur            d0, [fp, #-0x50]
    // 0xb6b9b0: r1 = Instance_Offset
    //     0xb6b9b0: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa40a0] Obj!Offset@12a7cf1
    //     0xb6b9b4: ldr             x1, [x1, #0xa0]
    // 0xb6b9b8: LoadField: d1 = r1->field_7
    //     0xb6b9b8: ldur            d1, [x1, #7]
    // 0xb6b9bc: fadd            d2, d0, d1
    // 0xb6b9c0: stur            d2, [fp, #-0x48]
    // 0xb6b9c4: LoadField: d1 = r0->field_f
    //     0xb6b9c4: ldur            d1, [x0, #0xf]
    // 0xb6b9c8: stur            d1, [fp, #-0x40]
    // 0xb6b9cc: LoadField: d3 = r1->field_f
    //     0xb6b9cc: ldur            d3, [x1, #0xf]
    // 0xb6b9d0: fadd            d4, d1, d3
    // 0xb6b9d4: ldur            x0, [fp, #-0x20]
    // 0xb6b9d8: stur            d4, [fp, #-0x38]
    // 0xb6b9dc: LoadField: r1 = r0->field_7
    //     0xb6b9dc: ldur            w1, [x0, #7]
    // 0xb6b9e0: DecompressPointer r1
    //     0xb6b9e0: add             x1, x1, HEAP, lsl #32
    // 0xb6b9e4: cmp             w1, NULL
    // 0xb6b9e8: b.eq            #0xb6bc70
    // 0xb6b9ec: LoadField: r3 = r1->field_7
    //     0xb6b9ec: ldur            x3, [x1, #7]
    // 0xb6b9f0: ldr             x1, [x3]
    // 0xb6b9f4: cbz             x1, #0xb6bbd8
    // 0xb6b9f8: mov             x3, x1
    // 0xb6b9fc: stur            x3, [fp, #-0x28]
    // 0xb6ba00: r1 = <Never>
    //     0xb6ba00: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb6ba04: r0 = Pointer()
    //     0xb6ba04: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb6ba08: mov             x1, x0
    // 0xb6ba0c: ldur            x0, [fp, #-0x28]
    // 0xb6ba10: StoreField: r1->field_7 = r0
    //     0xb6ba10: stur            x0, [x1, #7]
    // 0xb6ba14: ldur            d0, [fp, #-0x48]
    // 0xb6ba18: ldur            d1, [fp, #-0x38]
    // 0xb6ba1c: r0 = _moveTo$Method$FfiNative()
    //     0xb6ba1c: bl              #0xb69c74  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0xb6ba20: r0 = Instance_Offset
    //     0xb6ba20: add             x0, PP, #0xa4, lsl #12  ; [pp+0xa40a8] Obj!Offset@12a7cd1
    //     0xb6ba24: ldr             x0, [x0, #0xa8]
    // 0xb6ba28: LoadField: d0 = r0->field_7
    //     0xb6ba28: ldur            d0, [x0, #7]
    // 0xb6ba2c: ldur            d1, [fp, #-0x50]
    // 0xb6ba30: fadd            d2, d1, d0
    // 0xb6ba34: stur            d2, [fp, #-0x48]
    // 0xb6ba38: LoadField: d0 = r0->field_f
    //     0xb6ba38: ldur            d0, [x0, #0xf]
    // 0xb6ba3c: ldur            d3, [fp, #-0x40]
    // 0xb6ba40: fadd            d4, d3, d0
    // 0xb6ba44: ldur            x0, [fp, #-0x20]
    // 0xb6ba48: stur            d4, [fp, #-0x38]
    // 0xb6ba4c: LoadField: r1 = r0->field_7
    //     0xb6ba4c: ldur            w1, [x0, #7]
    // 0xb6ba50: DecompressPointer r1
    //     0xb6ba50: add             x1, x1, HEAP, lsl #32
    // 0xb6ba54: cmp             w1, NULL
    // 0xb6ba58: b.eq            #0xb6bc74
    // 0xb6ba5c: LoadField: r2 = r1->field_7
    //     0xb6ba5c: ldur            x2, [x1, #7]
    // 0xb6ba60: ldr             x1, [x2]
    // 0xb6ba64: cbz             x1, #0xb6bbe8
    // 0xb6ba68: ldur            x2, [fp, #-0x30]
    // 0xb6ba6c: mov             x3, x1
    // 0xb6ba70: stur            x3, [fp, #-0x28]
    // 0xb6ba74: r1 = <Never>
    //     0xb6ba74: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb6ba78: r0 = Pointer()
    //     0xb6ba78: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb6ba7c: mov             x1, x0
    // 0xb6ba80: ldur            x0, [fp, #-0x28]
    // 0xb6ba84: StoreField: r1->field_7 = r0
    //     0xb6ba84: stur            x0, [x1, #7]
    // 0xb6ba88: ldur            d0, [fp, #-0x48]
    // 0xb6ba8c: ldur            d1, [fp, #-0x38]
    // 0xb6ba90: r0 = _lineTo$Method$FfiNative()
    //     0xb6ba90: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0xb6ba94: ldur            x0, [fp, #-0x30]
    // 0xb6ba98: LoadField: d0 = r0->field_7
    //     0xb6ba98: ldur            d0, [x0, #7]
    // 0xb6ba9c: ldur            d1, [fp, #-0x50]
    // 0xb6baa0: fadd            d2, d1, d0
    // 0xb6baa4: stur            d2, [fp, #-0x48]
    // 0xb6baa8: LoadField: d0 = r0->field_f
    //     0xb6baa8: ldur            d0, [x0, #0xf]
    // 0xb6baac: ldur            d1, [fp, #-0x40]
    // 0xb6bab0: fadd            d3, d1, d0
    // 0xb6bab4: ldur            x0, [fp, #-0x20]
    // 0xb6bab8: stur            d3, [fp, #-0x38]
    // 0xb6babc: LoadField: r1 = r0->field_7
    //     0xb6babc: ldur            w1, [x0, #7]
    // 0xb6bac0: DecompressPointer r1
    //     0xb6bac0: add             x1, x1, HEAP, lsl #32
    // 0xb6bac4: cmp             w1, NULL
    // 0xb6bac8: b.eq            #0xb6bc78
    // 0xb6bacc: LoadField: r2 = r1->field_7
    //     0xb6bacc: ldur            x2, [x1, #7]
    // 0xb6bad0: ldr             x1, [x2]
    // 0xb6bad4: cbz             x1, #0xb6bbf8
    // 0xb6bad8: mov             x2, x1
    // 0xb6badc: stur            x2, [fp, #-0x28]
    // 0xb6bae0: r1 = <Never>
    //     0xb6bae0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb6bae4: r0 = Pointer()
    //     0xb6bae4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb6bae8: mov             x1, x0
    // 0xb6baec: ldur            x0, [fp, #-0x28]
    // 0xb6baf0: StoreField: r1->field_7 = r0
    //     0xb6baf0: stur            x0, [x1, #7]
    // 0xb6baf4: ldur            d0, [fp, #-0x48]
    // 0xb6baf8: ldur            d1, [fp, #-0x38]
    // 0xb6bafc: r0 = _lineTo$Method$FfiNative()
    //     0xb6bafc: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0xb6bb00: ldur            x2, [fp, #-8]
    // 0xb6bb04: ldur            x0, [fp, #-0x18]
    // 0xb6bb08: LoadField: r3 = r0->field_b
    //     0xb6bb08: ldur            w3, [x0, #0xb]
    // 0xb6bb0c: DecompressPointer r3
    //     0xb6bb0c: add             x3, x3, HEAP, lsl #32
    // 0xb6bb10: stur            x3, [fp, #-0x30]
    // 0xb6bb14: LoadField: r5 = r0->field_7
    //     0xb6bb14: ldur            w5, [x0, #7]
    // 0xb6bb18: DecompressPointer r5
    //     0xb6bb18: add             x5, x5, HEAP, lsl #32
    // 0xb6bb1c: stur            x5, [fp, #-0x10]
    // 0xb6bb20: LoadField: r0 = r2->field_7
    //     0xb6bb20: ldur            w0, [x2, #7]
    // 0xb6bb24: DecompressPointer r0
    //     0xb6bb24: add             x0, x0, HEAP, lsl #32
    // 0xb6bb28: cmp             w0, NULL
    // 0xb6bb2c: b.eq            #0xb6bc7c
    // 0xb6bb30: LoadField: r1 = r0->field_7
    //     0xb6bb30: ldur            x1, [x0, #7]
    // 0xb6bb34: ldr             x0, [x1]
    // 0xb6bb38: cbz             x0, #0xb6bc08
    // 0xb6bb3c: ldur            x4, [fp, #-0x20]
    // 0xb6bb40: stur            x0, [fp, #-0x28]
    // 0xb6bb44: r1 = <Never>
    //     0xb6bb44: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb6bb48: r0 = Pointer()
    //     0xb6bb48: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb6bb4c: mov             x2, x0
    // 0xb6bb50: ldur            x0, [fp, #-0x28]
    // 0xb6bb54: stur            x2, [fp, #-0x18]
    // 0xb6bb58: StoreField: r2->field_7 = r0
    //     0xb6bb58: stur            x0, [x2, #7]
    // 0xb6bb5c: ldur            x0, [fp, #-0x20]
    // 0xb6bb60: LoadField: r1 = r0->field_7
    //     0xb6bb60: ldur            w1, [x0, #7]
    // 0xb6bb64: DecompressPointer r1
    //     0xb6bb64: add             x1, x1, HEAP, lsl #32
    // 0xb6bb68: cmp             w1, NULL
    // 0xb6bb6c: b.eq            #0xb6bc80
    // 0xb6bb70: LoadField: r3 = r1->field_7
    //     0xb6bb70: ldur            x3, [x1, #7]
    // 0xb6bb74: ldr             x1, [x3]
    // 0xb6bb78: mov             x3, x1
    // 0xb6bb7c: stur            x3, [fp, #-0x28]
    // 0xb6bb80: r1 = <Never>
    //     0xb6bb80: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb6bb84: r0 = Pointer()
    //     0xb6bb84: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb6bb88: mov             x1, x0
    // 0xb6bb8c: ldur            x0, [fp, #-0x28]
    // 0xb6bb90: StoreField: r1->field_7 = r0
    //     0xb6bb90: stur            x0, [x1, #7]
    // 0xb6bb94: mov             x2, x1
    // 0xb6bb98: ldur            x1, [fp, #-0x18]
    // 0xb6bb9c: ldur            x3, [fp, #-0x30]
    // 0xb6bba0: ldur            x5, [fp, #-0x10]
    // 0xb6bba4: r0 = __drawPath$Method$FfiNative()
    //     0xb6bba4: bl              #0xb69a00  ; [dart:ui] _NativeCanvas::__drawPath$Method$FfiNative
    // 0xb6bba8: r0 = Null
    //     0xb6bba8: mov             x0, NULL
    // 0xb6bbac: LeaveFrame
    //     0xb6bbac: mov             SP, fp
    //     0xb6bbb0: ldp             fp, lr, [SP], #0x10
    // 0xb6bbb4: ret
    //     0xb6bbb4: ret             
    // 0xb6bbb8: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb6bbb8: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb6bbbc: str             x16, [SP]
    // 0xb6bbc0: r0 = _throwNew()
    //     0xb6bbc0: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb6bbc4: brk             #0
    // 0xb6bbc8: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb6bbc8: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb6bbcc: str             x16, [SP]
    // 0xb6bbd0: r0 = _throwNew()
    //     0xb6bbd0: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb6bbd4: brk             #0
    // 0xb6bbd8: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb6bbd8: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb6bbdc: str             x16, [SP]
    // 0xb6bbe0: r0 = _throwNew()
    //     0xb6bbe0: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb6bbe4: brk             #0
    // 0xb6bbe8: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb6bbe8: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb6bbec: str             x16, [SP]
    // 0xb6bbf0: r0 = _throwNew()
    //     0xb6bbf0: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb6bbf4: brk             #0
    // 0xb6bbf8: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb6bbf8: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb6bbfc: str             x16, [SP]
    // 0xb6bc00: r0 = _throwNew()
    //     0xb6bc00: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb6bc04: brk             #0
    // 0xb6bc08: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb6bc08: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb6bc0c: str             x16, [SP]
    // 0xb6bc10: r0 = _throwNew()
    //     0xb6bc10: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb6bc14: brk             #0
    // 0xb6bc18: r0 = StackOverflowSharedWithFPURegs()
    //     0xb6bc18: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb6bc1c: b               #0xb6b7d8
    // 0xb6bc20: SaveReg d0
    //     0xb6bc20: str             q0, [SP, #-0x10]!
    // 0xb6bc24: stp             x4, x5, [SP, #-0x10]!
    // 0xb6bc28: SaveReg r0
    //     0xb6bc28: str             x0, [SP, #-8]!
    // 0xb6bc2c: r0 = AllocateDouble()
    //     0xb6bc2c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb6bc30: mov             x3, x0
    // 0xb6bc34: RestoreReg r0
    //     0xb6bc34: ldr             x0, [SP], #8
    // 0xb6bc38: ldp             x4, x5, [SP], #0x10
    // 0xb6bc3c: RestoreReg d0
    //     0xb6bc3c: ldr             q0, [SP], #0x10
    // 0xb6bc40: b               #0xb6b838
    // 0xb6bc44: r0 = NullErrorSharedWithFPURegs()
    //     0xb6bc44: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb6bc48: r0 = NullErrorSharedWithFPURegs()
    //     0xb6bc48: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb6bc4c: SaveReg d0
    //     0xb6bc4c: str             q0, [SP, #-0x10]!
    // 0xb6bc50: stp             x4, x5, [SP, #-0x10]!
    // 0xb6bc54: SaveReg r0
    //     0xb6bc54: str             x0, [SP, #-8]!
    // 0xb6bc58: r0 = AllocateDouble()
    //     0xb6bc58: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb6bc5c: mov             x3, x0
    // 0xb6bc60: RestoreReg r0
    //     0xb6bc60: ldr             x0, [SP], #8
    // 0xb6bc64: ldp             x4, x5, [SP], #0x10
    // 0xb6bc68: RestoreReg d0
    //     0xb6bc68: ldr             q0, [SP], #0x10
    // 0xb6bc6c: b               #0xb6b984
    // 0xb6bc70: r0 = NullErrorSharedWithFPURegs()
    //     0xb6bc70: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb6bc74: r0 = NullErrorSharedWithFPURegs()
    //     0xb6bc74: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb6bc78: r0 = NullErrorSharedWithFPURegs()
    //     0xb6bc78: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb6bc7c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb6bc7c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb6bc80: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb6bc80: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _drawDash(/* No info */) {
    // ** addr: 0xb6bda0, size: 0x14c
    // 0xb6bda0: EnterFrame
    //     0xb6bda0: stp             fp, lr, [SP, #-0x10]!
    //     0xb6bda4: mov             fp, SP
    // 0xb6bda8: AllocStack(0x28)
    //     0xb6bda8: sub             SP, SP, #0x28
    // 0xb6bdac: d1 = 1.000000
    //     0xb6bdac: fmov            d1, #1.00000000
    // 0xb6bdb0: mov             x4, x2
    // 0xb6bdb4: mov             x0, x3
    // 0xb6bdb8: stur            x2, [fp, #-8]
    // 0xb6bdbc: stur            x3, [fp, #-0x10]
    // 0xb6bdc0: stur            x5, [fp, #-0x18]
    // 0xb6bdc4: stur            d0, [fp, #-0x28]
    // 0xb6bdc8: CheckStackOverflow
    //     0xb6bdc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6bdcc: cmp             SP, x16
    //     0xb6bdd0: b.ls            #0xb6bea4
    // 0xb6bdd4: fsub            d2, d1, d0
    // 0xb6bdd8: r3 = inline_Allocate_Double()
    //     0xb6bdd8: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0xb6bddc: add             x3, x3, #0x10
    //     0xb6bde0: cmp             x1, x3
    //     0xb6bde4: b.ls            #0xb6beac
    //     0xb6bde8: str             x3, [THR, #0x60]  ; THR::top
    //     0xb6bdec: sub             x3, x3, #0xf
    //     0xb6bdf0: mov             x1, #0xe19c
    //     0xb6bdf4: movk            x1, #3, lsl #16
    //     0xb6bdf8: stur            x1, [x3, #-1]
    // 0xb6bdfc: dmb             ishst
    // 0xb6be00: StoreField: r3->field_7 = d2
    //     0xb6be00: stur            d2, [x3, #7]
    // 0xb6be04: r1 = Instance_Offset
    //     0xb6be04: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa40b8] Obj!Offset@12a7d51
    //     0xb6be08: ldr             x1, [x1, #0xb8]
    // 0xb6be0c: r2 = Instance_Offset
    //     0xb6be0c: add             x2, PP, #0xa4, lsl #12  ; [pp+0xa40c0] Obj!Offset@12a7d31
    //     0xb6be10: ldr             x2, [x2, #0xc0]
    // 0xb6be14: r0 = lerp()
    //     0xb6be14: bl              #0xb6bc84  ; [dart:ui] Offset::lerp
    // 0xb6be18: ldur            d0, [fp, #-0x28]
    // 0xb6be1c: stur            x0, [fp, #-0x20]
    // 0xb6be20: r3 = inline_Allocate_Double()
    //     0xb6be20: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0xb6be24: add             x3, x3, #0x10
    //     0xb6be28: cmp             x1, x3
    //     0xb6be2c: b.ls            #0xb6bed0
    //     0xb6be30: str             x3, [THR, #0x60]  ; THR::top
    //     0xb6be34: sub             x3, x3, #0xf
    //     0xb6be38: mov             x1, #0xe19c
    //     0xb6be3c: movk            x1, #3, lsl #16
    //     0xb6be40: stur            x1, [x3, #-1]
    // 0xb6be44: dmb             ishst
    // 0xb6be48: StoreField: r3->field_7 = d0
    //     0xb6be48: stur            d0, [x3, #7]
    // 0xb6be4c: r1 = Instance_Offset
    //     0xb6be4c: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa40c0] Obj!Offset@12a7d31
    //     0xb6be50: ldr             x1, [x1, #0xc0]
    // 0xb6be54: r2 = Instance_Offset
    //     0xb6be54: add             x2, PP, #0xa4, lsl #12  ; [pp+0xa40c8] Obj!Offset@12a7d11
    //     0xb6be58: ldr             x2, [x2, #0xc8]
    // 0xb6be5c: r0 = lerp()
    //     0xb6be5c: bl              #0xb6bc84  ; [dart:ui] Offset::lerp
    // 0xb6be60: ldur            x1, [fp, #-0x10]
    // 0xb6be64: ldur            x2, [fp, #-0x20]
    // 0xb6be68: stur            x0, [fp, #-0x20]
    // 0xb6be6c: r0 = +()
    //     0xb6be6c: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xb6be70: ldur            x1, [fp, #-0x10]
    // 0xb6be74: ldur            x2, [fp, #-0x20]
    // 0xb6be78: stur            x0, [fp, #-0x10]
    // 0xb6be7c: r0 = +()
    //     0xb6be7c: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xb6be80: ldur            x1, [fp, #-8]
    // 0xb6be84: ldur            x2, [fp, #-0x10]
    // 0xb6be88: mov             x3, x0
    // 0xb6be8c: ldur            x5, [fp, #-0x18]
    // 0xb6be90: r0 = drawLine()
    //     0xb6be90: bl              #0xb6932c  ; [dart:ui] _NativeCanvas::drawLine
    // 0xb6be94: r0 = Null
    //     0xb6be94: mov             x0, NULL
    // 0xb6be98: LeaveFrame
    //     0xb6be98: mov             SP, fp
    //     0xb6be9c: ldp             fp, lr, [SP], #0x10
    // 0xb6bea0: ret
    //     0xb6bea0: ret             
    // 0xb6bea4: r0 = StackOverflowSharedWithFPURegs()
    //     0xb6bea4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb6bea8: b               #0xb6bdd4
    // 0xb6beac: stp             q0, q2, [SP, #-0x20]!
    // 0xb6beb0: stp             x4, x5, [SP, #-0x10]!
    // 0xb6beb4: SaveReg r0
    //     0xb6beb4: str             x0, [SP, #-8]!
    // 0xb6beb8: r0 = AllocateDouble()
    //     0xb6beb8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb6bebc: mov             x3, x0
    // 0xb6bec0: RestoreReg r0
    //     0xb6bec0: ldr             x0, [SP], #8
    // 0xb6bec4: ldp             x4, x5, [SP], #0x10
    // 0xb6bec8: ldp             q0, q2, [SP], #0x20
    // 0xb6becc: b               #0xb6be00
    // 0xb6bed0: SaveReg d0
    //     0xb6bed0: str             q0, [SP, #-0x10]!
    // 0xb6bed4: SaveReg r0
    //     0xb6bed4: str             x0, [SP, #-8]!
    // 0xb6bed8: r0 = AllocateDouble()
    //     0xb6bed8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb6bedc: mov             x3, x0
    // 0xb6bee0: RestoreReg r0
    //     0xb6bee0: ldr             x0, [SP], #8
    // 0xb6bee4: RestoreReg d0
    //     0xb6bee4: ldr             q0, [SP], #0x10
    // 0xb6bee8: b               #0xb6be48
  }
  _ _drawBox(/* No info */) {
    // ** addr: 0xb6beec, size: 0xac
    // 0xb6beec: EnterFrame
    //     0xb6beec: stp             fp, lr, [SP, #-0x10]!
    //     0xb6bef0: mov             fp, SP
    // 0xb6bef4: AllocStack(0x20)
    //     0xb6bef4: sub             SP, SP, #0x20
    // 0xb6bef8: SetupParameters(_CheckboxPainter this /* r1 => r7, fp-0x8 */, dynamic _ /* r2 => r6, fp-0x10 */, dynamic _ /* r3 => r4, fp-0x18 */, dynamic _ /* r6 => r0, fp-0x20 */)
    //     0xb6bef8: mov             x7, x1
    //     0xb6befc: mov             x0, x6
    //     0xb6bf00: stur            x6, [fp, #-0x20]
    //     0xb6bf04: mov             x6, x2
    //     0xb6bf08: mov             x4, x3
    //     0xb6bf0c: stur            x1, [fp, #-8]
    //     0xb6bf10: stur            x2, [fp, #-0x10]
    //     0xb6bf14: stur            x3, [fp, #-0x18]
    // 0xb6bf18: CheckStackOverflow
    //     0xb6bf18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6bf1c: cmp             SP, x16
    //     0xb6bf20: b.ls            #0xb6bf88
    // 0xb6bf24: LoadField: r1 = r7->field_6b
    //     0xb6bf24: ldur            w1, [x7, #0x6b]
    // 0xb6bf28: DecompressPointer r1
    //     0xb6bf28: add             x1, x1, HEAP, lsl #32
    // 0xb6bf2c: cmp             w1, NULL
    // 0xb6bf30: b.eq            #0xb6bf90
    // 0xb6bf34: mov             x2, x6
    // 0xb6bf38: mov             x3, x4
    // 0xb6bf3c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xb6bf3c: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xb6bf40: r0 = paintInterior()
    //     0xb6bf40: bl              #0x12ebae0  ; [package:flutter/src/painting/rounded_rectangle_border.dart] RoundedRectangleBorder::paintInterior
    // 0xb6bf44: ldur            x0, [fp, #-8]
    // 0xb6bf48: LoadField: r1 = r0->field_6b
    //     0xb6bf48: ldur            w1, [x0, #0x6b]
    // 0xb6bf4c: DecompressPointer r1
    //     0xb6bf4c: add             x1, x1, HEAP, lsl #32
    // 0xb6bf50: cmp             w1, NULL
    // 0xb6bf54: b.eq            #0xb6bf94
    // 0xb6bf58: ldur            x2, [fp, #-0x20]
    // 0xb6bf5c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xb6bf5c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xb6bf60: r0 = copyWith()
    //     0xb6bf60: bl              #0x1301674  ; [package:flutter/src/painting/rounded_rectangle_border.dart] RoundedRectangleBorder::copyWith
    // 0xb6bf64: mov             x1, x0
    // 0xb6bf68: ldur            x2, [fp, #-0x10]
    // 0xb6bf6c: ldur            x3, [fp, #-0x18]
    // 0xb6bf70: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xb6bf70: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xb6bf74: r0 = paint()
    //     0xb6bf74: bl              #0x12ecb18  ; [package:flutter/src/painting/rounded_rectangle_border.dart] RoundedRectangleBorder::paint
    // 0xb6bf78: r0 = Null
    //     0xb6bf78: mov             x0, NULL
    // 0xb6bf7c: LeaveFrame
    //     0xb6bf7c: mov             SP, fp
    //     0xb6bf80: ldp             fp, lr, [SP], #0x10
    // 0xb6bf84: ret
    //     0xb6bf84: ret             
    // 0xb6bf88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6bf88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6bf8c: b               #0xb6bf24
    // 0xb6bf90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6bf90: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6bf94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6bf94: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _colorAt(/* No info */) {
    // ** addr: 0xb6bf98, size: 0xcc
    // 0xb6bf98: EnterFrame
    //     0xb6bf98: stp             fp, lr, [SP, #-0x10]!
    //     0xb6bf9c: mov             fp, SP
    // 0xb6bfa0: d1 = 0.250000
    //     0xb6bfa0: fmov            d1, #0.25000000
    // 0xb6bfa4: CheckStackOverflow
    //     0xb6bfa4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6bfa8: cmp             SP, x16
    //     0xb6bfac: b.ls            #0xb6c034
    // 0xb6bfb0: fcmp            d0, d1
    // 0xb6bfb4: b.lt            #0xb6bfcc
    // 0xb6bfb8: LoadField: r0 = r1->field_33
    //     0xb6bfb8: ldur            w0, [x1, #0x33]
    // 0xb6bfbc: DecompressPointer r0
    //     0xb6bfbc: add             x0, x0, HEAP, lsl #32
    // 0xb6bfc0: cmp             w0, NULL
    // 0xb6bfc4: b.eq            #0xb6c03c
    // 0xb6bfc8: b               #0xb6c028
    // 0xb6bfcc: d1 = 4.000000
    //     0xb6bfcc: fmov            d1, #4.00000000
    // 0xb6bfd0: LoadField: r0 = r1->field_37
    //     0xb6bfd0: ldur            w0, [x1, #0x37]
    // 0xb6bfd4: DecompressPointer r0
    //     0xb6bfd4: add             x0, x0, HEAP, lsl #32
    // 0xb6bfd8: cmp             w0, NULL
    // 0xb6bfdc: b.eq            #0xb6c040
    // 0xb6bfe0: LoadField: r2 = r1->field_33
    //     0xb6bfe0: ldur            w2, [x1, #0x33]
    // 0xb6bfe4: DecompressPointer r2
    //     0xb6bfe4: add             x2, x2, HEAP, lsl #32
    // 0xb6bfe8: cmp             w2, NULL
    // 0xb6bfec: b.eq            #0xb6c044
    // 0xb6bff0: fmul            d2, d0, d1
    // 0xb6bff4: r3 = inline_Allocate_Double()
    //     0xb6bff4: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0xb6bff8: add             x3, x3, #0x10
    //     0xb6bffc: cmp             x1, x3
    //     0xb6c000: b.ls            #0xb6c048
    //     0xb6c004: str             x3, [THR, #0x60]  ; THR::top
    //     0xb6c008: sub             x3, x3, #0xf
    //     0xb6c00c: mov             x1, #0xe19c
    //     0xb6c010: movk            x1, #3, lsl #16
    //     0xb6c014: stur            x1, [x3, #-1]
    // 0xb6c018: dmb             ishst
    // 0xb6c01c: StoreField: r3->field_7 = d2
    //     0xb6c01c: stur            d2, [x3, #7]
    // 0xb6c020: mov             x1, x0
    // 0xb6c024: r0 = lerp()
    //     0xb6c024: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0xb6c028: LeaveFrame
    //     0xb6c028: mov             SP, fp
    //     0xb6c02c: ldp             fp, lr, [SP], #0x10
    // 0xb6c030: ret
    //     0xb6c030: ret             
    // 0xb6c034: r0 = StackOverflowSharedWithFPURegs()
    //     0xb6c034: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb6c038: b               #0xb6bfb0
    // 0xb6c03c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6c03c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6c040: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6c040: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6c044: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6c044: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6c048: SaveReg d2
    //     0xb6c048: str             q2, [SP, #-0x10]!
    // 0xb6c04c: stp             x0, x2, [SP, #-0x10]!
    // 0xb6c050: r0 = AllocateDouble()
    //     0xb6c050: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb6c054: mov             x3, x0
    // 0xb6c058: ldp             x0, x2, [SP], #0x10
    // 0xb6c05c: RestoreReg d2
    //     0xb6c05c: ldr             q2, [SP], #0x10
    // 0xb6c060: b               #0xb6c01c
  }
  _ _outerRectAt(/* No info */) {
    // ** addr: 0xb6c064, size: 0xb4
    // 0xb6c064: EnterFrame
    //     0xb6c064: stp             fp, lr, [SP, #-0x10]!
    //     0xb6c068: mov             fp, SP
    // 0xb6c06c: AllocStack(0x20)
    //     0xb6c06c: sub             SP, SP, #0x20
    // 0xb6c070: d2 = 0.500000
    //     0xb6c070: fmov            d2, #0.50000000
    // 0xb6c074: d1 = 0.000000
    //     0xb6c074: eor             v1.16b, v1.16b, v1.16b
    // 0xb6c078: fsub            d3, d0, d2
    // 0xb6c07c: fcmp            d3, d1
    // 0xb6c080: b.ne            #0xb6c08c
    // 0xb6c084: d3 = 0.000000
    //     0xb6c084: eor             v3.16b, v3.16b, v3.16b
    // 0xb6c088: b               #0xb6c0a4
    // 0xb6c08c: fcmp            d1, d3
    // 0xb6c090: b.le            #0xb6c09c
    // 0xb6c094: fneg            d0, d3
    // 0xb6c098: b               #0xb6c0a0
    // 0xb6c09c: mov             v0.16b, v3.16b
    // 0xb6c0a0: mov             v3.16b, v0.16b
    // 0xb6c0a4: d2 = 2.000000
    //     0xb6c0a4: fmov            d2, #2.00000000
    // 0xb6c0a8: d1 = 1.000000
    //     0xb6c0a8: fmov            d1, #1.00000000
    // 0xb6c0ac: d0 = 18.000000
    //     0xb6c0ac: fmov            d0, #18.00000000
    // 0xb6c0b0: fmul            d4, d3, d2
    // 0xb6c0b4: fsub            d3, d1, d4
    // 0xb6c0b8: fmul            d1, d3, d2
    // 0xb6c0bc: fsub            d2, d0, d1
    // 0xb6c0c0: LoadField: d0 = r2->field_7
    //     0xb6c0c0: ldur            d0, [x2, #7]
    // 0xb6c0c4: fadd            d1, d0, d3
    // 0xb6c0c8: stur            d1, [fp, #-0x20]
    // 0xb6c0cc: LoadField: d0 = r2->field_f
    //     0xb6c0cc: ldur            d0, [x2, #0xf]
    // 0xb6c0d0: fadd            d4, d0, d3
    // 0xb6c0d4: stur            d4, [fp, #-0x18]
    // 0xb6c0d8: fadd            d0, d1, d2
    // 0xb6c0dc: stur            d0, [fp, #-0x10]
    // 0xb6c0e0: fadd            d3, d4, d2
    // 0xb6c0e4: stur            d3, [fp, #-8]
    // 0xb6c0e8: r0 = Rect()
    //     0xb6c0e8: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xb6c0ec: ldur            d0, [fp, #-0x20]
    // 0xb6c0f0: StoreField: r0->field_7 = d0
    //     0xb6c0f0: stur            d0, [x0, #7]
    // 0xb6c0f4: ldur            d0, [fp, #-0x18]
    // 0xb6c0f8: StoreField: r0->field_f = d0
    //     0xb6c0f8: stur            d0, [x0, #0xf]
    // 0xb6c0fc: ldur            d0, [fp, #-0x10]
    // 0xb6c100: ArrayStore: r0[0] = d0  ; List_8
    //     0xb6c100: stur            d0, [x0, #0x17]
    // 0xb6c104: ldur            d0, [fp, #-8]
    // 0xb6c108: StoreField: r0->field_1f = d0
    //     0xb6c108: stur            d0, [x0, #0x1f]
    // 0xb6c10c: LeaveFrame
    //     0xb6c10c: mov             SP, fp
    //     0xb6c110: ldp             fp, lr, [SP], #0x10
    // 0xb6c114: ret
    //     0xb6c114: ret             
  }
  _ _createStrokePaint(/* No info */) {
    // ** addr: 0xb6c118, size: 0xa0
    // 0xb6c118: EnterFrame
    //     0xb6c118: stp             fp, lr, [SP, #-0x10]!
    //     0xb6c11c: mov             fp, SP
    // 0xb6c120: AllocStack(0x28)
    //     0xb6c120: sub             SP, SP, #0x28
    // 0xb6c124: SetupParameters(_CheckboxPainter this /* r1 => r1, fp-0x8 */)
    //     0xb6c124: stur            x1, [fp, #-8]
    // 0xb6c128: CheckStackOverflow
    //     0xb6c128: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6c12c: cmp             SP, x16
    //     0xb6c130: b.ls            #0xb6c1ac
    // 0xb6c134: r16 = 136
    //     0xb6c134: mov             x16, #0x88
    // 0xb6c138: stp             x16, NULL, [SP]
    // 0xb6c13c: r0 = ByteData()
    //     0xb6c13c: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb6c140: stur            x0, [fp, #-0x10]
    // 0xb6c144: r0 = Paint()
    //     0xb6c144: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb6c148: mov             x3, x0
    // 0xb6c14c: ldur            x0, [fp, #-0x10]
    // 0xb6c150: stur            x3, [fp, #-0x18]
    // 0xb6c154: StoreField: r3->field_7 = r0
    //     0xb6c154: stur            w0, [x3, #7]
    // 0xb6c158: ldur            x1, [fp, #-8]
    // 0xb6c15c: LoadField: r2 = r1->field_5f
    //     0xb6c15c: ldur            w2, [x1, #0x5f]
    // 0xb6c160: DecompressPointer r2
    //     0xb6c160: add             x2, x2, HEAP, lsl #32
    // 0xb6c164: cmp             w2, NULL
    // 0xb6c168: b.eq            #0xb6c1b4
    // 0xb6c16c: mov             x1, x3
    // 0xb6c170: r0 = color=()
    //     0xb6c170: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb6c174: ldur            x1, [fp, #-0x10]
    // 0xb6c178: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xb6c178: ldur            w2, [x1, #0x17]
    // 0xb6c17c: DecompressPointer r2
    //     0xb6c17c: add             x2, x2, HEAP, lsl #32
    // 0xb6c180: LoadField: r1 = r2->field_7
    //     0xb6c180: ldur            x1, [x2, #7]
    // 0xb6c184: r3 = 1
    //     0xb6c184: mov             x3, #1
    // 0xb6c188: str             w3, [x1, #0x1c]
    // 0xb6c18c: LoadField: r1 = r2->field_7
    //     0xb6c18c: ldur            x1, [x2, #7]
    // 0xb6c190: d0 = 0.000000
    //     0xb6c190: add             x17, PP, #0xa2, lsl #12  ; [pp+0xa2af0] IMM: 0x40000000
    //     0xb6c194: ldr             s0, [x17, #0xaf0]
    // 0xb6c198: str             s0, [x1, #0x20]
    // 0xb6c19c: ldur            x0, [fp, #-0x18]
    // 0xb6c1a0: LeaveFrame
    //     0xb6c1a0: mov             SP, fp
    //     0xb6c1a4: ldp             fp, lr, [SP], #0x10
    // 0xb6c1a8: ret
    //     0xb6c1a8: ret             
    // 0xb6c1ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6c1ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6c1b0: b               #0xb6c134
    // 0xb6c1b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6c1b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ inactiveSide=(/* No info */) {
    // ** addr: 0xd12718, size: 0xa4
    // 0xd12718: EnterFrame
    //     0xd12718: stp             fp, lr, [SP, #-0x10]!
    //     0xd1271c: mov             fp, SP
    // 0xd12720: AllocStack(0x20)
    //     0xd12720: sub             SP, SP, #0x20
    // 0xd12724: SetupParameters(_CheckboxPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd12724: stur            x1, [fp, #-8]
    //     0xd12728: mov             x16, x2
    //     0xd1272c: mov             x2, x1
    //     0xd12730: mov             x1, x16
    //     0xd12734: stur            x1, [fp, #-0x10]
    // 0xd12738: CheckStackOverflow
    //     0xd12738: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1273c: cmp             SP, x16
    //     0xd12740: b.ls            #0xd127b4
    // 0xd12744: LoadField: r0 = r2->field_73
    //     0xd12744: ldur            w0, [x2, #0x73]
    // 0xd12748: DecompressPointer r0
    //     0xd12748: add             x0, x0, HEAP, lsl #32
    // 0xd1274c: r3 = LoadClassIdInstr(r0)
    //     0xd1274c: ldur            x3, [x0, #-1]
    //     0xd12750: ubfx            x3, x3, #0xc, #0x14
    // 0xd12754: stp             x1, x0, [SP]
    // 0xd12758: mov             x0, x3
    // 0xd1275c: mov             lr, x0
    // 0xd12760: ldr             lr, [x21, lr, lsl #3]
    // 0xd12764: blr             lr
    // 0xd12768: tbnz            w0, #4, #0xd1277c
    // 0xd1276c: r0 = Null
    //     0xd1276c: mov             x0, NULL
    // 0xd12770: LeaveFrame
    //     0xd12770: mov             SP, fp
    //     0xd12774: ldp             fp, lr, [SP], #0x10
    // 0xd12778: ret
    //     0xd12778: ret             
    // 0xd1277c: ldur            x1, [fp, #-8]
    // 0xd12780: ldur            x0, [fp, #-0x10]
    // 0xd12784: StoreField: r1->field_73 = r0
    //     0xd12784: stur            w0, [x1, #0x73]
    //     0xd12788: ldurb           w16, [x1, #-1]
    //     0xd1278c: ldurb           w17, [x0, #-1]
    //     0xd12790: and             x16, x17, x16, lsr #2
    //     0xd12794: tst             x16, HEAP, lsr #32
    //     0xd12798: b.eq            #0xd127a0
    //     0xd1279c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd127a0: r0 = notifyListeners()
    //     0xd127a0: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd127a4: r0 = Null
    //     0xd127a4: mov             x0, NULL
    // 0xd127a8: LeaveFrame
    //     0xd127a8: mov             SP, fp
    //     0xd127ac: ldp             fp, lr, [SP], #0x10
    // 0xd127b0: ret
    //     0xd127b0: ret             
    // 0xd127b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd127b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd127b8: b               #0xd12744
  }
  set _ activeSide=(/* No info */) {
    // ** addr: 0xd127bc, size: 0xa4
    // 0xd127bc: EnterFrame
    //     0xd127bc: stp             fp, lr, [SP, #-0x10]!
    //     0xd127c0: mov             fp, SP
    // 0xd127c4: AllocStack(0x20)
    //     0xd127c4: sub             SP, SP, #0x20
    // 0xd127c8: SetupParameters(_CheckboxPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd127c8: stur            x1, [fp, #-8]
    //     0xd127cc: mov             x16, x2
    //     0xd127d0: mov             x2, x1
    //     0xd127d4: mov             x1, x16
    //     0xd127d8: stur            x1, [fp, #-0x10]
    // 0xd127dc: CheckStackOverflow
    //     0xd127dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd127e0: cmp             SP, x16
    //     0xd127e4: b.ls            #0xd12858
    // 0xd127e8: LoadField: r0 = r2->field_6f
    //     0xd127e8: ldur            w0, [x2, #0x6f]
    // 0xd127ec: DecompressPointer r0
    //     0xd127ec: add             x0, x0, HEAP, lsl #32
    // 0xd127f0: r3 = LoadClassIdInstr(r0)
    //     0xd127f0: ldur            x3, [x0, #-1]
    //     0xd127f4: ubfx            x3, x3, #0xc, #0x14
    // 0xd127f8: stp             x1, x0, [SP]
    // 0xd127fc: mov             x0, x3
    // 0xd12800: mov             lr, x0
    // 0xd12804: ldr             lr, [x21, lr, lsl #3]
    // 0xd12808: blr             lr
    // 0xd1280c: tbnz            w0, #4, #0xd12820
    // 0xd12810: r0 = Null
    //     0xd12810: mov             x0, NULL
    // 0xd12814: LeaveFrame
    //     0xd12814: mov             SP, fp
    //     0xd12818: ldp             fp, lr, [SP], #0x10
    // 0xd1281c: ret
    //     0xd1281c: ret             
    // 0xd12820: ldur            x1, [fp, #-8]
    // 0xd12824: ldur            x0, [fp, #-0x10]
    // 0xd12828: StoreField: r1->field_6f = r0
    //     0xd12828: stur            w0, [x1, #0x6f]
    //     0xd1282c: ldurb           w16, [x1, #-1]
    //     0xd12830: ldurb           w17, [x0, #-1]
    //     0xd12834: and             x16, x17, x16, lsr #2
    //     0xd12838: tst             x16, HEAP, lsr #32
    //     0xd1283c: b.eq            #0xd12844
    //     0xd12840: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd12844: r0 = notifyListeners()
    //     0xd12844: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd12848: r0 = Null
    //     0xd12848: mov             x0, NULL
    // 0xd1284c: LeaveFrame
    //     0xd1284c: mov             SP, fp
    //     0xd12850: ldp             fp, lr, [SP], #0x10
    // 0xd12854: ret
    //     0xd12854: ret             
    // 0xd12858: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd12858: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1285c: b               #0xd127e8
  }
  set _ shape=(/* No info */) {
    // ** addr: 0xd12860, size: 0xa4
    // 0xd12860: EnterFrame
    //     0xd12860: stp             fp, lr, [SP, #-0x10]!
    //     0xd12864: mov             fp, SP
    // 0xd12868: AllocStack(0x20)
    //     0xd12868: sub             SP, SP, #0x20
    // 0xd1286c: SetupParameters(_CheckboxPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd1286c: stur            x1, [fp, #-8]
    //     0xd12870: mov             x16, x2
    //     0xd12874: mov             x2, x1
    //     0xd12878: mov             x1, x16
    //     0xd1287c: stur            x1, [fp, #-0x10]
    // 0xd12880: CheckStackOverflow
    //     0xd12880: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd12884: cmp             SP, x16
    //     0xd12888: b.ls            #0xd128fc
    // 0xd1288c: LoadField: r0 = r2->field_6b
    //     0xd1288c: ldur            w0, [x2, #0x6b]
    // 0xd12890: DecompressPointer r0
    //     0xd12890: add             x0, x0, HEAP, lsl #32
    // 0xd12894: r3 = LoadClassIdInstr(r0)
    //     0xd12894: ldur            x3, [x0, #-1]
    //     0xd12898: ubfx            x3, x3, #0xc, #0x14
    // 0xd1289c: stp             x1, x0, [SP]
    // 0xd128a0: mov             x0, x3
    // 0xd128a4: mov             lr, x0
    // 0xd128a8: ldr             lr, [x21, lr, lsl #3]
    // 0xd128ac: blr             lr
    // 0xd128b0: tbnz            w0, #4, #0xd128c4
    // 0xd128b4: r0 = Null
    //     0xd128b4: mov             x0, NULL
    // 0xd128b8: LeaveFrame
    //     0xd128b8: mov             SP, fp
    //     0xd128bc: ldp             fp, lr, [SP], #0x10
    // 0xd128c0: ret
    //     0xd128c0: ret             
    // 0xd128c4: ldur            x1, [fp, #-8]
    // 0xd128c8: ldur            x0, [fp, #-0x10]
    // 0xd128cc: StoreField: r1->field_6b = r0
    //     0xd128cc: stur            w0, [x1, #0x6b]
    //     0xd128d0: ldurb           w16, [x1, #-1]
    //     0xd128d4: ldurb           w17, [x0, #-1]
    //     0xd128d8: and             x16, x17, x16, lsr #2
    //     0xd128dc: tst             x16, HEAP, lsr #32
    //     0xd128e0: b.eq            #0xd128e8
    //     0xd128e4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd128e8: r0 = notifyListeners()
    //     0xd128e8: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd128ec: r0 = Null
    //     0xd128ec: mov             x0, NULL
    // 0xd128f0: LeaveFrame
    //     0xd128f0: mov             SP, fp
    //     0xd128f4: ldp             fp, lr, [SP], #0x10
    // 0xd128f8: ret
    //     0xd128f8: ret             
    // 0xd128fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd128fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd12900: b               #0xd1288c
  }
  set void previousValue=(_CheckboxPainter, bool?) {
    // ** addr: 0xd12904, size: 0x54
    // 0xd12904: EnterFrame
    //     0xd12904: stp             fp, lr, [SP, #-0x10]!
    //     0xd12908: mov             fp, SP
    // 0xd1290c: CheckStackOverflow
    //     0xd1290c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd12910: cmp             SP, x16
    //     0xd12914: b.ls            #0xd12950
    // 0xd12918: LoadField: r0 = r1->field_67
    //     0xd12918: ldur            w0, [x1, #0x67]
    // 0xd1291c: DecompressPointer r0
    //     0xd1291c: add             x0, x0, HEAP, lsl #32
    // 0xd12920: cmp             w0, w2
    // 0xd12924: b.ne            #0xd12938
    // 0xd12928: r0 = Null
    //     0xd12928: mov             x0, NULL
    // 0xd1292c: LeaveFrame
    //     0xd1292c: mov             SP, fp
    //     0xd12930: ldp             fp, lr, [SP], #0x10
    // 0xd12934: ret
    //     0xd12934: ret             
    // 0xd12938: StoreField: r1->field_67 = r2
    //     0xd12938: stur            w2, [x1, #0x67]
    // 0xd1293c: r0 = notifyListeners()
    //     0xd1293c: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd12940: r0 = Null
    //     0xd12940: mov             x0, NULL
    // 0xd12944: LeaveFrame
    //     0xd12944: mov             SP, fp
    //     0xd12948: ldp             fp, lr, [SP], #0x10
    // 0xd1294c: ret
    //     0xd1294c: ret             
    // 0xd12950: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd12950: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd12954: b               #0xd12918
  }
  set _ checkColor=(/* No info */) {
    // ** addr: 0xd12958, size: 0xa4
    // 0xd12958: EnterFrame
    //     0xd12958: stp             fp, lr, [SP, #-0x10]!
    //     0xd1295c: mov             fp, SP
    // 0xd12960: AllocStack(0x20)
    //     0xd12960: sub             SP, SP, #0x20
    // 0xd12964: SetupParameters(_CheckboxPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd12964: stur            x1, [fp, #-8]
    //     0xd12968: mov             x16, x2
    //     0xd1296c: mov             x2, x1
    //     0xd12970: mov             x1, x16
    //     0xd12974: stur            x1, [fp, #-0x10]
    // 0xd12978: CheckStackOverflow
    //     0xd12978: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1297c: cmp             SP, x16
    //     0xd12980: b.ls            #0xd129f4
    // 0xd12984: LoadField: r0 = r2->field_5f
    //     0xd12984: ldur            w0, [x2, #0x5f]
    // 0xd12988: DecompressPointer r0
    //     0xd12988: add             x0, x0, HEAP, lsl #32
    // 0xd1298c: r3 = LoadClassIdInstr(r0)
    //     0xd1298c: ldur            x3, [x0, #-1]
    //     0xd12990: ubfx            x3, x3, #0xc, #0x14
    // 0xd12994: stp             x1, x0, [SP]
    // 0xd12998: mov             x0, x3
    // 0xd1299c: mov             lr, x0
    // 0xd129a0: ldr             lr, [x21, lr, lsl #3]
    // 0xd129a4: blr             lr
    // 0xd129a8: tbnz            w0, #4, #0xd129bc
    // 0xd129ac: r0 = Null
    //     0xd129ac: mov             x0, NULL
    // 0xd129b0: LeaveFrame
    //     0xd129b0: mov             SP, fp
    //     0xd129b4: ldp             fp, lr, [SP], #0x10
    // 0xd129b8: ret
    //     0xd129b8: ret             
    // 0xd129bc: ldur            x1, [fp, #-8]
    // 0xd129c0: ldur            x0, [fp, #-0x10]
    // 0xd129c4: StoreField: r1->field_5f = r0
    //     0xd129c4: stur            w0, [x1, #0x5f]
    //     0xd129c8: ldurb           w16, [x1, #-1]
    //     0xd129cc: ldurb           w17, [x0, #-1]
    //     0xd129d0: and             x16, x17, x16, lsr #2
    //     0xd129d4: tst             x16, HEAP, lsr #32
    //     0xd129d8: b.eq            #0xd129e0
    //     0xd129dc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd129e0: r0 = notifyListeners()
    //     0xd129e0: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd129e4: r0 = Null
    //     0xd129e4: mov             x0, NULL
    // 0xd129e8: LeaveFrame
    //     0xd129e8: mov             SP, fp
    //     0xd129ec: ldp             fp, lr, [SP], #0x10
    // 0xd129f0: ret
    //     0xd129f0: ret             
    // 0xd129f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd129f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd129f8: b               #0xd12984
  }
}

// class id: 5174, size: 0x34, field offset: 0x2c
class _CheckboxDefaultsM3 extends CheckboxThemeData {

  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd13524, size: 0x190
    // 0xd13524: EnterFrame
    //     0xd13524: stp             fp, lr, [SP, #-0x10]!
    //     0xd13528: mov             fp, SP
    // 0xd1352c: AllocStack(0x8)
    //     0xd1352c: sub             SP, SP, #8
    // 0xd13530: SetupParameters([dynamic _ /* r0 */])
    //     0xd13530: ldr             x0, [fp, #0x18]
    //     0xd13534: ldur            w3, [x0, #0x17]
    //     0xd13538: add             x3, x3, HEAP, lsl #32
    //     0xd1353c: stur            x3, [fp, #-8]
    // 0xd13540: CheckStackOverflow
    //     0xd13540: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd13544: cmp             SP, x16
    //     0xd13548: b.ls            #0xd136ac
    // 0xd1354c: ldr             x4, [fp, #0x10]
    // 0xd13550: r0 = LoadClassIdInstr(r4)
    //     0xd13550: ldur            x0, [x4, #-1]
    //     0xd13554: ubfx            x0, x0, #0xc, #0x14
    // 0xd13558: mov             x1, x4
    // 0xd1355c: r2 = Instance_WidgetState
    //     0xd1355c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd13560: ldr             x2, [x2, #0xa70]
    // 0xd13564: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd13564: mov             x17, #0x2929
    //     0xd13568: movk            x17, #1, lsl #16
    //     0xd1356c: add             lr, x0, x17
    //     0xd13570: ldr             lr, [x21, lr, lsl #3]
    //     0xd13574: blr             lr
    // 0xd13578: tbnz            w0, #4, #0xd135e8
    // 0xd1357c: ldr             x3, [fp, #0x10]
    // 0xd13580: r0 = LoadClassIdInstr(r3)
    //     0xd13580: ldur            x0, [x3, #-1]
    //     0xd13584: ubfx            x0, x0, #0xc, #0x14
    // 0xd13588: mov             x1, x3
    // 0xd1358c: r2 = Instance_WidgetState
    //     0xd1358c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd13590: ldr             x2, [x2, #0x100]
    // 0xd13594: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd13594: mov             x17, #0x2929
    //     0xd13598: movk            x17, #1, lsl #16
    //     0xd1359c: add             lr, x0, x17
    //     0xd135a0: ldr             lr, [x21, lr, lsl #3]
    //     0xd135a4: blr             lr
    // 0xd135a8: tbnz            w0, #4, #0xd135d4
    // 0xd135ac: ldur            x4, [fp, #-8]
    // 0xd135b0: LoadField: r0 = r4->field_f
    //     0xd135b0: ldur            w0, [x4, #0xf]
    // 0xd135b4: DecompressPointer r0
    //     0xd135b4: add             x0, x0, HEAP, lsl #32
    // 0xd135b8: LoadField: r1 = r0->field_2f
    //     0xd135b8: ldur            w1, [x0, #0x2f]
    // 0xd135bc: DecompressPointer r1
    //     0xd135bc: add             x1, x1, HEAP, lsl #32
    // 0xd135c0: LoadField: r0 = r1->field_7b
    //     0xd135c0: ldur            w0, [x1, #0x7b]
    // 0xd135c4: DecompressPointer r0
    //     0xd135c4: add             x0, x0, HEAP, lsl #32
    // 0xd135c8: LeaveFrame
    //     0xd135c8: mov             SP, fp
    //     0xd135cc: ldp             fp, lr, [SP], #0x10
    // 0xd135d0: ret
    //     0xd135d0: ret             
    // 0xd135d4: r0 = Instance_Color
    //     0xd135d4: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xd135d8: ldr             x0, [x0, #0x810]
    // 0xd135dc: LeaveFrame
    //     0xd135dc: mov             SP, fp
    //     0xd135e0: ldp             fp, lr, [SP], #0x10
    // 0xd135e4: ret
    //     0xd135e4: ret             
    // 0xd135e8: ldr             x3, [fp, #0x10]
    // 0xd135ec: ldur            x4, [fp, #-8]
    // 0xd135f0: r0 = LoadClassIdInstr(r3)
    //     0xd135f0: ldur            x0, [x3, #-1]
    //     0xd135f4: ubfx            x0, x0, #0xc, #0x14
    // 0xd135f8: mov             x1, x3
    // 0xd135fc: r2 = Instance_WidgetState
    //     0xd135fc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd13600: ldr             x2, [x2, #0x100]
    // 0xd13604: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd13604: mov             x17, #0x2929
    //     0xd13608: movk            x17, #1, lsl #16
    //     0xd1360c: add             lr, x0, x17
    //     0xd13610: ldr             lr, [x21, lr, lsl #3]
    //     0xd13614: blr             lr
    // 0xd13618: tbnz            w0, #4, #0xd13698
    // 0xd1361c: ldr             x1, [fp, #0x10]
    // 0xd13620: r0 = LoadClassIdInstr(r1)
    //     0xd13620: ldur            x0, [x1, #-1]
    //     0xd13624: ubfx            x0, x0, #0xc, #0x14
    // 0xd13628: r2 = Instance_WidgetState
    //     0xd13628: add             x2, PP, #0x26, lsl #12  ; [pp+0x26500] Obj!WidgetState@12c8781
    //     0xd1362c: ldr             x2, [x2, #0x500]
    // 0xd13630: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd13630: mov             x17, #0x2929
    //     0xd13634: movk            x17, #1, lsl #16
    //     0xd13638: add             lr, x0, x17
    //     0xd1363c: ldr             lr, [x21, lr, lsl #3]
    //     0xd13640: blr             lr
    // 0xd13644: tbnz            w0, #4, #0xd13670
    // 0xd13648: ldur            x1, [fp, #-8]
    // 0xd1364c: LoadField: r2 = r1->field_f
    //     0xd1364c: ldur            w2, [x1, #0xf]
    // 0xd13650: DecompressPointer r2
    //     0xd13650: add             x2, x2, HEAP, lsl #32
    // 0xd13654: LoadField: r3 = r2->field_2f
    //     0xd13654: ldur            w3, [x2, #0x2f]
    // 0xd13658: DecompressPointer r3
    //     0xd13658: add             x3, x3, HEAP, lsl #32
    // 0xd1365c: LoadField: r0 = r3->field_6f
    //     0xd1365c: ldur            w0, [x3, #0x6f]
    // 0xd13660: DecompressPointer r0
    //     0xd13660: add             x0, x0, HEAP, lsl #32
    // 0xd13664: LeaveFrame
    //     0xd13664: mov             SP, fp
    //     0xd13668: ldp             fp, lr, [SP], #0x10
    // 0xd1366c: ret
    //     0xd1366c: ret             
    // 0xd13670: ldur            x1, [fp, #-8]
    // 0xd13674: LoadField: r2 = r1->field_f
    //     0xd13674: ldur            w2, [x1, #0xf]
    // 0xd13678: DecompressPointer r2
    //     0xd13678: add             x2, x2, HEAP, lsl #32
    // 0xd1367c: LoadField: r1 = r2->field_2f
    //     0xd1367c: ldur            w1, [x2, #0x2f]
    // 0xd13680: DecompressPointer r1
    //     0xd13680: add             x1, x1, HEAP, lsl #32
    // 0xd13684: LoadField: r0 = r1->field_f
    //     0xd13684: ldur            w0, [x1, #0xf]
    // 0xd13688: DecompressPointer r0
    //     0xd13688: add             x0, x0, HEAP, lsl #32
    // 0xd1368c: LeaveFrame
    //     0xd1368c: mov             SP, fp
    //     0xd13690: ldp             fp, lr, [SP], #0x10
    // 0xd13694: ret
    //     0xd13694: ret             
    // 0xd13698: r0 = Instance_Color
    //     0xd13698: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xd1369c: ldr             x0, [x0, #0x810]
    // 0xd136a0: LeaveFrame
    //     0xd136a0: mov             SP, fp
    //     0xd136a4: ldp             fp, lr, [SP], #0x10
    // 0xd136a8: ret
    //     0xd136a8: ret             
    // 0xd136ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd136ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd136b0: b               #0xd1354c
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd13860, size: 0x508
    // 0xd13860: EnterFrame
    //     0xd13860: stp             fp, lr, [SP, #-0x10]!
    //     0xd13864: mov             fp, SP
    // 0xd13868: AllocStack(0x8)
    //     0xd13868: sub             SP, SP, #8
    // 0xd1386c: SetupParameters([dynamic _ /* r0 */])
    //     0xd1386c: ldr             x0, [fp, #0x18]
    //     0xd13870: ldur            w3, [x0, #0x17]
    //     0xd13874: add             x3, x3, HEAP, lsl #32
    //     0xd13878: stur            x3, [fp, #-8]
    // 0xd1387c: CheckStackOverflow
    //     0xd1387c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd13880: cmp             SP, x16
    //     0xd13884: b.ls            #0xd13d60
    // 0xd13888: ldr             x4, [fp, #0x10]
    // 0xd1388c: r0 = LoadClassIdInstr(r4)
    //     0xd1388c: ldur            x0, [x4, #-1]
    //     0xd13890: ubfx            x0, x0, #0xc, #0x14
    // 0xd13894: mov             x1, x4
    // 0xd13898: r2 = Instance_WidgetState
    //     0xd13898: add             x2, PP, #0x26, lsl #12  ; [pp+0x26500] Obj!WidgetState@12c8781
    //     0xd1389c: ldr             x2, [x2, #0x500]
    // 0xd138a0: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd138a0: mov             x17, #0x2929
    //     0xd138a4: movk            x17, #1, lsl #16
    //     0xd138a8: add             lr, x0, x17
    //     0xd138ac: ldr             lr, [x21, lr, lsl #3]
    //     0xd138b0: blr             lr
    // 0xd138b4: tbnz            w0, #4, #0xd13a48
    // 0xd138b8: ldr             x3, [fp, #0x10]
    // 0xd138bc: r0 = LoadClassIdInstr(r3)
    //     0xd138bc: ldur            x0, [x3, #-1]
    //     0xd138c0: ubfx            x0, x0, #0xc, #0x14
    // 0xd138c4: mov             x1, x3
    // 0xd138c8: r2 = Instance_WidgetState
    //     0xd138c8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd138cc: ldr             x2, [x2, #0xa48]
    // 0xd138d0: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd138d0: mov             x17, #0x2929
    //     0xd138d4: movk            x17, #1, lsl #16
    //     0xd138d8: add             lr, x0, x17
    //     0xd138dc: ldr             lr, [x21, lr, lsl #3]
    //     0xd138e0: blr             lr
    // 0xd138e4: tbnz            w0, #4, #0xd13938
    // 0xd138e8: ldur            x3, [fp, #-8]
    // 0xd138ec: LoadField: r0 = r3->field_f
    //     0xd138ec: ldur            w0, [x3, #0xf]
    // 0xd138f0: DecompressPointer r0
    //     0xd138f0: add             x0, x0, HEAP, lsl #32
    // 0xd138f4: LoadField: r1 = r0->field_2f
    //     0xd138f4: ldur            w1, [x0, #0x2f]
    // 0xd138f8: DecompressPointer r1
    //     0xd138f8: add             x1, x1, HEAP, lsl #32
    // 0xd138fc: LoadField: r0 = r1->field_6b
    //     0xd138fc: ldur            w0, [x1, #0x6b]
    // 0xd13900: DecompressPointer r0
    //     0xd13900: add             x0, x0, HEAP, lsl #32
    // 0xd13904: r1 = LoadClassIdInstr(r0)
    //     0xd13904: ldur            x1, [x0, #-1]
    //     0xd13908: ubfx            x1, x1, #0xc, #0x14
    // 0xd1390c: mov             x16, x0
    // 0xd13910: mov             x0, x1
    // 0xd13914: mov             x1, x16
    // 0xd13918: d0 = 0.100000
    //     0xd13918: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xd1391c: ldr             d0, [x17, #0x1e0]
    // 0xd13920: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd13920: sub             lr, x0, #1, lsl #12
    //     0xd13924: ldr             lr, [x21, lr, lsl #3]
    //     0xd13928: blr             lr
    // 0xd1392c: LeaveFrame
    //     0xd1392c: mov             SP, fp
    //     0xd13930: ldp             fp, lr, [SP], #0x10
    // 0xd13934: ret
    //     0xd13934: ret             
    // 0xd13938: ldr             x4, [fp, #0x10]
    // 0xd1393c: ldur            x3, [fp, #-8]
    // 0xd13940: r0 = LoadClassIdInstr(r4)
    //     0xd13940: ldur            x0, [x4, #-1]
    //     0xd13944: ubfx            x0, x0, #0xc, #0x14
    // 0xd13948: mov             x1, x4
    // 0xd1394c: r2 = Instance_WidgetState
    //     0xd1394c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd13950: ldr             x2, [x2, #0xa50]
    // 0xd13954: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd13954: mov             x17, #0x2929
    //     0xd13958: movk            x17, #1, lsl #16
    //     0xd1395c: add             lr, x0, x17
    //     0xd13960: ldr             lr, [x21, lr, lsl #3]
    //     0xd13964: blr             lr
    // 0xd13968: tbnz            w0, #4, #0xd139bc
    // 0xd1396c: ldur            x3, [fp, #-8]
    // 0xd13970: LoadField: r0 = r3->field_f
    //     0xd13970: ldur            w0, [x3, #0xf]
    // 0xd13974: DecompressPointer r0
    //     0xd13974: add             x0, x0, HEAP, lsl #32
    // 0xd13978: LoadField: r1 = r0->field_2f
    //     0xd13978: ldur            w1, [x0, #0x2f]
    // 0xd1397c: DecompressPointer r1
    //     0xd1397c: add             x1, x1, HEAP, lsl #32
    // 0xd13980: LoadField: r0 = r1->field_6b
    //     0xd13980: ldur            w0, [x1, #0x6b]
    // 0xd13984: DecompressPointer r0
    //     0xd13984: add             x0, x0, HEAP, lsl #32
    // 0xd13988: r1 = LoadClassIdInstr(r0)
    //     0xd13988: ldur            x1, [x0, #-1]
    //     0xd1398c: ubfx            x1, x1, #0xc, #0x14
    // 0xd13990: mov             x16, x0
    // 0xd13994: mov             x0, x1
    // 0xd13998: mov             x1, x16
    // 0xd1399c: d0 = 0.080000
    //     0xd1399c: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xd139a0: ldr             d0, [x17, #0xa58]
    // 0xd139a4: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd139a4: sub             lr, x0, #1, lsl #12
    //     0xd139a8: ldr             lr, [x21, lr, lsl #3]
    //     0xd139ac: blr             lr
    // 0xd139b0: LeaveFrame
    //     0xd139b0: mov             SP, fp
    //     0xd139b4: ldp             fp, lr, [SP], #0x10
    // 0xd139b8: ret
    //     0xd139b8: ret             
    // 0xd139bc: ldr             x4, [fp, #0x10]
    // 0xd139c0: ldur            x3, [fp, #-8]
    // 0xd139c4: r0 = LoadClassIdInstr(r4)
    //     0xd139c4: ldur            x0, [x4, #-1]
    //     0xd139c8: ubfx            x0, x0, #0xc, #0x14
    // 0xd139cc: mov             x1, x4
    // 0xd139d0: r2 = Instance_WidgetState
    //     0xd139d0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd139d4: ldr             x2, [x2, #0xa60]
    // 0xd139d8: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd139d8: mov             x17, #0x2929
    //     0xd139dc: movk            x17, #1, lsl #16
    //     0xd139e0: add             lr, x0, x17
    //     0xd139e4: ldr             lr, [x21, lr, lsl #3]
    //     0xd139e8: blr             lr
    // 0xd139ec: tbnz            w0, #4, #0xd13a40
    // 0xd139f0: ldur            x3, [fp, #-8]
    // 0xd139f4: LoadField: r0 = r3->field_f
    //     0xd139f4: ldur            w0, [x3, #0xf]
    // 0xd139f8: DecompressPointer r0
    //     0xd139f8: add             x0, x0, HEAP, lsl #32
    // 0xd139fc: LoadField: r1 = r0->field_2f
    //     0xd139fc: ldur            w1, [x0, #0x2f]
    // 0xd13a00: DecompressPointer r1
    //     0xd13a00: add             x1, x1, HEAP, lsl #32
    // 0xd13a04: LoadField: r0 = r1->field_6b
    //     0xd13a04: ldur            w0, [x1, #0x6b]
    // 0xd13a08: DecompressPointer r0
    //     0xd13a08: add             x0, x0, HEAP, lsl #32
    // 0xd13a0c: r1 = LoadClassIdInstr(r0)
    //     0xd13a0c: ldur            x1, [x0, #-1]
    //     0xd13a10: ubfx            x1, x1, #0xc, #0x14
    // 0xd13a14: mov             x16, x0
    // 0xd13a18: mov             x0, x1
    // 0xd13a1c: mov             x1, x16
    // 0xd13a20: d0 = 0.100000
    //     0xd13a20: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xd13a24: ldr             d0, [x17, #0x1e0]
    // 0xd13a28: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd13a28: sub             lr, x0, #1, lsl #12
    //     0xd13a2c: ldr             lr, [x21, lr, lsl #3]
    //     0xd13a30: blr             lr
    // 0xd13a34: LeaveFrame
    //     0xd13a34: mov             SP, fp
    //     0xd13a38: ldp             fp, lr, [SP], #0x10
    // 0xd13a3c: ret
    //     0xd13a3c: ret             
    // 0xd13a40: ldur            x3, [fp, #-8]
    // 0xd13a44: b               #0xd13a4c
    // 0xd13a48: ldur            x3, [fp, #-8]
    // 0xd13a4c: ldr             x4, [fp, #0x10]
    // 0xd13a50: r0 = LoadClassIdInstr(r4)
    //     0xd13a50: ldur            x0, [x4, #-1]
    //     0xd13a54: ubfx            x0, x0, #0xc, #0x14
    // 0xd13a58: mov             x1, x4
    // 0xd13a5c: r2 = Instance_WidgetState
    //     0xd13a5c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd13a60: ldr             x2, [x2, #0x100]
    // 0xd13a64: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd13a64: mov             x17, #0x2929
    //     0xd13a68: movk            x17, #1, lsl #16
    //     0xd13a6c: add             lr, x0, x17
    //     0xd13a70: ldr             lr, [x21, lr, lsl #3]
    //     0xd13a74: blr             lr
    // 0xd13a78: tbnz            w0, #4, #0xd13be8
    // 0xd13a7c: ldr             x3, [fp, #0x10]
    // 0xd13a80: r0 = LoadClassIdInstr(r3)
    //     0xd13a80: ldur            x0, [x3, #-1]
    //     0xd13a84: ubfx            x0, x0, #0xc, #0x14
    // 0xd13a88: mov             x1, x3
    // 0xd13a8c: r2 = Instance_WidgetState
    //     0xd13a8c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd13a90: ldr             x2, [x2, #0xa48]
    // 0xd13a94: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd13a94: mov             x17, #0x2929
    //     0xd13a98: movk            x17, #1, lsl #16
    //     0xd13a9c: add             lr, x0, x17
    //     0xd13aa0: ldr             lr, [x21, lr, lsl #3]
    //     0xd13aa4: blr             lr
    // 0xd13aa8: tbnz            w0, #4, #0xd13afc
    // 0xd13aac: ldur            x3, [fp, #-8]
    // 0xd13ab0: LoadField: r0 = r3->field_f
    //     0xd13ab0: ldur            w0, [x3, #0xf]
    // 0xd13ab4: DecompressPointer r0
    //     0xd13ab4: add             x0, x0, HEAP, lsl #32
    // 0xd13ab8: LoadField: r1 = r0->field_2f
    //     0xd13ab8: ldur            w1, [x0, #0x2f]
    // 0xd13abc: DecompressPointer r1
    //     0xd13abc: add             x1, x1, HEAP, lsl #32
    // 0xd13ac0: LoadField: r0 = r1->field_7f
    //     0xd13ac0: ldur            w0, [x1, #0x7f]
    // 0xd13ac4: DecompressPointer r0
    //     0xd13ac4: add             x0, x0, HEAP, lsl #32
    // 0xd13ac8: r1 = LoadClassIdInstr(r0)
    //     0xd13ac8: ldur            x1, [x0, #-1]
    //     0xd13acc: ubfx            x1, x1, #0xc, #0x14
    // 0xd13ad0: mov             x16, x0
    // 0xd13ad4: mov             x0, x1
    // 0xd13ad8: mov             x1, x16
    // 0xd13adc: d0 = 0.100000
    //     0xd13adc: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xd13ae0: ldr             d0, [x17, #0x1e0]
    // 0xd13ae4: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd13ae4: sub             lr, x0, #1, lsl #12
    //     0xd13ae8: ldr             lr, [x21, lr, lsl #3]
    //     0xd13aec: blr             lr
    // 0xd13af0: LeaveFrame
    //     0xd13af0: mov             SP, fp
    //     0xd13af4: ldp             fp, lr, [SP], #0x10
    // 0xd13af8: ret
    //     0xd13af8: ret             
    // 0xd13afc: ldr             x4, [fp, #0x10]
    // 0xd13b00: ldur            x3, [fp, #-8]
    // 0xd13b04: r0 = LoadClassIdInstr(r4)
    //     0xd13b04: ldur            x0, [x4, #-1]
    //     0xd13b08: ubfx            x0, x0, #0xc, #0x14
    // 0xd13b0c: mov             x1, x4
    // 0xd13b10: r2 = Instance_WidgetState
    //     0xd13b10: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd13b14: ldr             x2, [x2, #0xa50]
    // 0xd13b18: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd13b18: mov             x17, #0x2929
    //     0xd13b1c: movk            x17, #1, lsl #16
    //     0xd13b20: add             lr, x0, x17
    //     0xd13b24: ldr             lr, [x21, lr, lsl #3]
    //     0xd13b28: blr             lr
    // 0xd13b2c: tbnz            w0, #4, #0xd13b68
    // 0xd13b30: ldur            x3, [fp, #-8]
    // 0xd13b34: LoadField: r0 = r3->field_f
    //     0xd13b34: ldur            w0, [x3, #0xf]
    // 0xd13b38: DecompressPointer r0
    //     0xd13b38: add             x0, x0, HEAP, lsl #32
    // 0xd13b3c: LoadField: r1 = r0->field_2f
    //     0xd13b3c: ldur            w1, [x0, #0x2f]
    // 0xd13b40: DecompressPointer r1
    //     0xd13b40: add             x1, x1, HEAP, lsl #32
    // 0xd13b44: LoadField: r0 = r1->field_b
    //     0xd13b44: ldur            w0, [x1, #0xb]
    // 0xd13b48: DecompressPointer r0
    //     0xd13b48: add             x0, x0, HEAP, lsl #32
    // 0xd13b4c: mov             x1, x0
    // 0xd13b50: d0 = 0.080000
    //     0xd13b50: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xd13b54: ldr             d0, [x17, #0xa58]
    // 0xd13b58: r0 = withOpacity()
    //     0xd13b58: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd13b5c: LeaveFrame
    //     0xd13b5c: mov             SP, fp
    //     0xd13b60: ldp             fp, lr, [SP], #0x10
    // 0xd13b64: ret
    //     0xd13b64: ret             
    // 0xd13b68: ldr             x4, [fp, #0x10]
    // 0xd13b6c: ldur            x3, [fp, #-8]
    // 0xd13b70: r0 = LoadClassIdInstr(r4)
    //     0xd13b70: ldur            x0, [x4, #-1]
    //     0xd13b74: ubfx            x0, x0, #0xc, #0x14
    // 0xd13b78: mov             x1, x4
    // 0xd13b7c: r2 = Instance_WidgetState
    //     0xd13b7c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd13b80: ldr             x2, [x2, #0xa60]
    // 0xd13b84: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd13b84: mov             x17, #0x2929
    //     0xd13b88: movk            x17, #1, lsl #16
    //     0xd13b8c: add             lr, x0, x17
    //     0xd13b90: ldr             lr, [x21, lr, lsl #3]
    //     0xd13b94: blr             lr
    // 0xd13b98: tbnz            w0, #4, #0xd13bd4
    // 0xd13b9c: ldur            x3, [fp, #-8]
    // 0xd13ba0: LoadField: r0 = r3->field_f
    //     0xd13ba0: ldur            w0, [x3, #0xf]
    // 0xd13ba4: DecompressPointer r0
    //     0xd13ba4: add             x0, x0, HEAP, lsl #32
    // 0xd13ba8: LoadField: r1 = r0->field_2f
    //     0xd13ba8: ldur            w1, [x0, #0x2f]
    // 0xd13bac: DecompressPointer r1
    //     0xd13bac: add             x1, x1, HEAP, lsl #32
    // 0xd13bb0: LoadField: r0 = r1->field_b
    //     0xd13bb0: ldur            w0, [x1, #0xb]
    // 0xd13bb4: DecompressPointer r0
    //     0xd13bb4: add             x0, x0, HEAP, lsl #32
    // 0xd13bb8: mov             x1, x0
    // 0xd13bbc: d0 = 0.100000
    //     0xd13bbc: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xd13bc0: ldr             d0, [x17, #0x1e0]
    // 0xd13bc4: r0 = withOpacity()
    //     0xd13bc4: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd13bc8: LeaveFrame
    //     0xd13bc8: mov             SP, fp
    //     0xd13bcc: ldp             fp, lr, [SP], #0x10
    // 0xd13bd0: ret
    //     0xd13bd0: ret             
    // 0xd13bd4: r0 = Instance_Color
    //     0xd13bd4: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xd13bd8: ldr             x0, [x0, #0x810]
    // 0xd13bdc: LeaveFrame
    //     0xd13bdc: mov             SP, fp
    //     0xd13be0: ldp             fp, lr, [SP], #0x10
    // 0xd13be4: ret
    //     0xd13be4: ret             
    // 0xd13be8: ldr             x4, [fp, #0x10]
    // 0xd13bec: ldur            x3, [fp, #-8]
    // 0xd13bf0: r0 = LoadClassIdInstr(r4)
    //     0xd13bf0: ldur            x0, [x4, #-1]
    //     0xd13bf4: ubfx            x0, x0, #0xc, #0x14
    // 0xd13bf8: mov             x1, x4
    // 0xd13bfc: r2 = Instance_WidgetState
    //     0xd13bfc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd13c00: ldr             x2, [x2, #0xa48]
    // 0xd13c04: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd13c04: mov             x17, #0x2929
    //     0xd13c08: movk            x17, #1, lsl #16
    //     0xd13c0c: add             lr, x0, x17
    //     0xd13c10: ldr             lr, [x21, lr, lsl #3]
    //     0xd13c14: blr             lr
    // 0xd13c18: tbnz            w0, #4, #0xd13c54
    // 0xd13c1c: ldur            x3, [fp, #-8]
    // 0xd13c20: LoadField: r0 = r3->field_f
    //     0xd13c20: ldur            w0, [x3, #0xf]
    // 0xd13c24: DecompressPointer r0
    //     0xd13c24: add             x0, x0, HEAP, lsl #32
    // 0xd13c28: LoadField: r1 = r0->field_2f
    //     0xd13c28: ldur            w1, [x0, #0x2f]
    // 0xd13c2c: DecompressPointer r1
    //     0xd13c2c: add             x1, x1, HEAP, lsl #32
    // 0xd13c30: LoadField: r0 = r1->field_b
    //     0xd13c30: ldur            w0, [x1, #0xb]
    // 0xd13c34: DecompressPointer r0
    //     0xd13c34: add             x0, x0, HEAP, lsl #32
    // 0xd13c38: mov             x1, x0
    // 0xd13c3c: d0 = 0.100000
    //     0xd13c3c: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xd13c40: ldr             d0, [x17, #0x1e0]
    // 0xd13c44: r0 = withOpacity()
    //     0xd13c44: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd13c48: LeaveFrame
    //     0xd13c48: mov             SP, fp
    //     0xd13c4c: ldp             fp, lr, [SP], #0x10
    // 0xd13c50: ret
    //     0xd13c50: ret             
    // 0xd13c54: ldr             x4, [fp, #0x10]
    // 0xd13c58: ldur            x3, [fp, #-8]
    // 0xd13c5c: r0 = LoadClassIdInstr(r4)
    //     0xd13c5c: ldur            x0, [x4, #-1]
    //     0xd13c60: ubfx            x0, x0, #0xc, #0x14
    // 0xd13c64: mov             x1, x4
    // 0xd13c68: r2 = Instance_WidgetState
    //     0xd13c68: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd13c6c: ldr             x2, [x2, #0xa50]
    // 0xd13c70: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd13c70: mov             x17, #0x2929
    //     0xd13c74: movk            x17, #1, lsl #16
    //     0xd13c78: add             lr, x0, x17
    //     0xd13c7c: ldr             lr, [x21, lr, lsl #3]
    //     0xd13c80: blr             lr
    // 0xd13c84: tbnz            w0, #4, #0xd13cd8
    // 0xd13c88: ldur            x3, [fp, #-8]
    // 0xd13c8c: LoadField: r0 = r3->field_f
    //     0xd13c8c: ldur            w0, [x3, #0xf]
    // 0xd13c90: DecompressPointer r0
    //     0xd13c90: add             x0, x0, HEAP, lsl #32
    // 0xd13c94: LoadField: r1 = r0->field_2f
    //     0xd13c94: ldur            w1, [x0, #0x2f]
    // 0xd13c98: DecompressPointer r1
    //     0xd13c98: add             x1, x1, HEAP, lsl #32
    // 0xd13c9c: LoadField: r0 = r1->field_7f
    //     0xd13c9c: ldur            w0, [x1, #0x7f]
    // 0xd13ca0: DecompressPointer r0
    //     0xd13ca0: add             x0, x0, HEAP, lsl #32
    // 0xd13ca4: r1 = LoadClassIdInstr(r0)
    //     0xd13ca4: ldur            x1, [x0, #-1]
    //     0xd13ca8: ubfx            x1, x1, #0xc, #0x14
    // 0xd13cac: mov             x16, x0
    // 0xd13cb0: mov             x0, x1
    // 0xd13cb4: mov             x1, x16
    // 0xd13cb8: d0 = 0.080000
    //     0xd13cb8: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xd13cbc: ldr             d0, [x17, #0xa58]
    // 0xd13cc0: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd13cc0: sub             lr, x0, #1, lsl #12
    //     0xd13cc4: ldr             lr, [x21, lr, lsl #3]
    //     0xd13cc8: blr             lr
    // 0xd13ccc: LeaveFrame
    //     0xd13ccc: mov             SP, fp
    //     0xd13cd0: ldp             fp, lr, [SP], #0x10
    // 0xd13cd4: ret
    //     0xd13cd4: ret             
    // 0xd13cd8: ldr             x1, [fp, #0x10]
    // 0xd13cdc: ldur            x3, [fp, #-8]
    // 0xd13ce0: r0 = LoadClassIdInstr(r1)
    //     0xd13ce0: ldur            x0, [x1, #-1]
    //     0xd13ce4: ubfx            x0, x0, #0xc, #0x14
    // 0xd13ce8: r2 = Instance_WidgetState
    //     0xd13ce8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd13cec: ldr             x2, [x2, #0xa60]
    // 0xd13cf0: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd13cf0: mov             x17, #0x2929
    //     0xd13cf4: movk            x17, #1, lsl #16
    //     0xd13cf8: add             lr, x0, x17
    //     0xd13cfc: ldr             lr, [x21, lr, lsl #3]
    //     0xd13d00: blr             lr
    // 0xd13d04: tbnz            w0, #4, #0xd13d4c
    // 0xd13d08: ldur            x0, [fp, #-8]
    // 0xd13d0c: LoadField: r1 = r0->field_f
    //     0xd13d0c: ldur            w1, [x0, #0xf]
    // 0xd13d10: DecompressPointer r1
    //     0xd13d10: add             x1, x1, HEAP, lsl #32
    // 0xd13d14: LoadField: r0 = r1->field_2f
    //     0xd13d14: ldur            w0, [x1, #0x2f]
    // 0xd13d18: DecompressPointer r0
    //     0xd13d18: add             x0, x0, HEAP, lsl #32
    // 0xd13d1c: LoadField: r1 = r0->field_7f
    //     0xd13d1c: ldur            w1, [x0, #0x7f]
    // 0xd13d20: DecompressPointer r1
    //     0xd13d20: add             x1, x1, HEAP, lsl #32
    // 0xd13d24: r0 = LoadClassIdInstr(r1)
    //     0xd13d24: ldur            x0, [x1, #-1]
    //     0xd13d28: ubfx            x0, x0, #0xc, #0x14
    // 0xd13d2c: d0 = 0.100000
    //     0xd13d2c: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xd13d30: ldr             d0, [x17, #0x1e0]
    // 0xd13d34: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd13d34: sub             lr, x0, #1, lsl #12
    //     0xd13d38: ldr             lr, [x21, lr, lsl #3]
    //     0xd13d3c: blr             lr
    // 0xd13d40: LeaveFrame
    //     0xd13d40: mov             SP, fp
    //     0xd13d44: ldp             fp, lr, [SP], #0x10
    // 0xd13d48: ret
    //     0xd13d48: ret             
    // 0xd13d4c: r0 = Instance_Color
    //     0xd13d4c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xd13d50: ldr             x0, [x0, #0x810]
    // 0xd13d54: LeaveFrame
    //     0xd13d54: mov             SP, fp
    //     0xd13d58: ldp             fp, lr, [SP], #0x10
    // 0xd13d5c: ret
    //     0xd13d5c: ret             
    // 0xd13d60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd13d60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd13d64: b               #0xd13888
  }
  [closure] BorderSide <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd13f0c, size: 0x468
    // 0xd13f0c: EnterFrame
    //     0xd13f0c: stp             fp, lr, [SP, #-0x10]!
    //     0xd13f10: mov             fp, SP
    // 0xd13f14: AllocStack(0x10)
    //     0xd13f14: sub             SP, SP, #0x10
    // 0xd13f18: SetupParameters([dynamic _ /* r0 */])
    //     0xd13f18: ldr             x0, [fp, #0x18]
    //     0xd13f1c: ldur            w3, [x0, #0x17]
    //     0xd13f20: add             x3, x3, HEAP, lsl #32
    //     0xd13f24: stur            x3, [fp, #-8]
    // 0xd13f28: CheckStackOverflow
    //     0xd13f28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd13f2c: cmp             SP, x16
    //     0xd13f30: b.ls            #0xd1436c
    // 0xd13f34: ldr             x4, [fp, #0x10]
    // 0xd13f38: r0 = LoadClassIdInstr(r4)
    //     0xd13f38: ldur            x0, [x4, #-1]
    //     0xd13f3c: ubfx            x0, x0, #0xc, #0x14
    // 0xd13f40: mov             x1, x4
    // 0xd13f44: r2 = Instance_WidgetState
    //     0xd13f44: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd13f48: ldr             x2, [x2, #0xa70]
    // 0xd13f4c: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd13f4c: mov             x17, #0x2929
    //     0xd13f50: movk            x17, #1, lsl #16
    //     0xd13f54: add             lr, x0, x17
    //     0xd13f58: ldr             lr, [x21, lr, lsl #3]
    //     0xd13f5c: blr             lr
    // 0xd13f60: tbnz            w0, #4, #0xd1402c
    // 0xd13f64: ldr             x3, [fp, #0x10]
    // 0xd13f68: r0 = LoadClassIdInstr(r3)
    //     0xd13f68: ldur            x0, [x3, #-1]
    //     0xd13f6c: ubfx            x0, x0, #0xc, #0x14
    // 0xd13f70: mov             x1, x3
    // 0xd13f74: r2 = Instance_WidgetState
    //     0xd13f74: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd13f78: ldr             x2, [x2, #0x100]
    // 0xd13f7c: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd13f7c: mov             x17, #0x2929
    //     0xd13f80: movk            x17, #1, lsl #16
    //     0xd13f84: add             lr, x0, x17
    //     0xd13f88: ldr             lr, [x21, lr, lsl #3]
    //     0xd13f8c: blr             lr
    // 0xd13f90: tbnz            w0, #4, #0xd13fa8
    // 0xd13f94: r0 = Instance_BorderSide
    //     0xd13f94: add             x0, PP, #0x26, lsl #12  ; [pp+0x264f0] Obj!BorderSide@12b1b51
    //     0xd13f98: ldr             x0, [x0, #0x4f0]
    // 0xd13f9c: LeaveFrame
    //     0xd13f9c: mov             SP, fp
    //     0xd13fa0: ldp             fp, lr, [SP], #0x10
    // 0xd13fa4: ret
    //     0xd13fa4: ret             
    // 0xd13fa8: ldur            x4, [fp, #-8]
    // 0xd13fac: LoadField: r0 = r4->field_f
    //     0xd13fac: ldur            w0, [x4, #0xf]
    // 0xd13fb0: DecompressPointer r0
    //     0xd13fb0: add             x0, x0, HEAP, lsl #32
    // 0xd13fb4: LoadField: r1 = r0->field_2f
    //     0xd13fb4: ldur            w1, [x0, #0x2f]
    // 0xd13fb8: DecompressPointer r1
    //     0xd13fb8: add             x1, x1, HEAP, lsl #32
    // 0xd13fbc: LoadField: r0 = r1->field_7f
    //     0xd13fbc: ldur            w0, [x1, #0x7f]
    // 0xd13fc0: DecompressPointer r0
    //     0xd13fc0: add             x0, x0, HEAP, lsl #32
    // 0xd13fc4: r1 = LoadClassIdInstr(r0)
    //     0xd13fc4: ldur            x1, [x0, #-1]
    //     0xd13fc8: ubfx            x1, x1, #0xc, #0x14
    // 0xd13fcc: mov             x16, x0
    // 0xd13fd0: mov             x0, x1
    // 0xd13fd4: mov             x1, x16
    // 0xd13fd8: d0 = 0.380000
    //     0xd13fd8: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xd13fdc: ldr             d0, [x17, #0x1f0]
    // 0xd13fe0: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd13fe0: sub             lr, x0, #1, lsl #12
    //     0xd13fe4: ldr             lr, [x21, lr, lsl #3]
    //     0xd13fe8: blr             lr
    // 0xd13fec: stur            x0, [fp, #-0x10]
    // 0xd13ff0: r0 = BorderSide()
    //     0xd13ff0: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xd13ff4: mov             x1, x0
    // 0xd13ff8: ldur            x0, [fp, #-0x10]
    // 0xd13ffc: StoreField: r1->field_7 = r0
    //     0xd13ffc: stur            w0, [x1, #7]
    // 0xd14000: d0 = 2.000000
    //     0xd14000: fmov            d0, #2.00000000
    // 0xd14004: StoreField: r1->field_b = d0
    //     0xd14004: stur            d0, [x1, #0xb]
    // 0xd14008: r5 = Instance_BorderStyle
    //     0xd14008: add             x5, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd1400c: ldr             x5, [x5, #0xdc8]
    // 0xd14010: StoreField: r1->field_13 = r5
    //     0xd14010: stur            w5, [x1, #0x13]
    // 0xd14014: d1 = -1.000000
    //     0xd14014: fmov            d1, #-1.00000000
    // 0xd14018: ArrayStore: r1[0] = d1  ; List_8
    //     0xd14018: stur            d1, [x1, #0x17]
    // 0xd1401c: mov             x0, x1
    // 0xd14020: LeaveFrame
    //     0xd14020: mov             SP, fp
    //     0xd14024: ldp             fp, lr, [SP], #0x10
    // 0xd14028: ret
    //     0xd14028: ret             
    // 0xd1402c: ldr             x3, [fp, #0x10]
    // 0xd14030: ldur            x4, [fp, #-8]
    // 0xd14034: r5 = Instance_BorderStyle
    //     0xd14034: add             x5, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd14038: ldr             x5, [x5, #0xdc8]
    // 0xd1403c: d0 = 2.000000
    //     0xd1403c: fmov            d0, #2.00000000
    // 0xd14040: d1 = -1.000000
    //     0xd14040: fmov            d1, #-1.00000000
    // 0xd14044: r0 = LoadClassIdInstr(r3)
    //     0xd14044: ldur            x0, [x3, #-1]
    //     0xd14048: ubfx            x0, x0, #0xc, #0x14
    // 0xd1404c: mov             x1, x3
    // 0xd14050: r2 = Instance_WidgetState
    //     0xd14050: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd14054: ldr             x2, [x2, #0x100]
    // 0xd14058: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd14058: mov             x17, #0x2929
    //     0xd1405c: movk            x17, #1, lsl #16
    //     0xd14060: add             lr, x0, x17
    //     0xd14064: ldr             lr, [x21, lr, lsl #3]
    //     0xd14068: blr             lr
    // 0xd1406c: tbnz            w0, #4, #0xd14084
    // 0xd14070: r0 = Instance_BorderSide
    //     0xd14070: add             x0, PP, #0x26, lsl #12  ; [pp+0x264f8] Obj!BorderSide@12b1b71
    //     0xd14074: ldr             x0, [x0, #0x4f8]
    // 0xd14078: LeaveFrame
    //     0xd14078: mov             SP, fp
    //     0xd1407c: ldp             fp, lr, [SP], #0x10
    // 0xd14080: ret
    //     0xd14080: ret             
    // 0xd14084: ldr             x3, [fp, #0x10]
    // 0xd14088: r0 = LoadClassIdInstr(r3)
    //     0xd14088: ldur            x0, [x3, #-1]
    //     0xd1408c: ubfx            x0, x0, #0xc, #0x14
    // 0xd14090: mov             x1, x3
    // 0xd14094: r2 = Instance_WidgetState
    //     0xd14094: add             x2, PP, #0x26, lsl #12  ; [pp+0x26500] Obj!WidgetState@12c8781
    //     0xd14098: ldr             x2, [x2, #0x500]
    // 0xd1409c: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd1409c: mov             x17, #0x2929
    //     0xd140a0: movk            x17, #1, lsl #16
    //     0xd140a4: add             lr, x0, x17
    //     0xd140a8: ldr             lr, [x21, lr, lsl #3]
    //     0xd140ac: blr             lr
    // 0xd140b0: tbnz            w0, #4, #0xd14110
    // 0xd140b4: ldur            x3, [fp, #-8]
    // 0xd140b8: LoadField: r0 = r3->field_f
    //     0xd140b8: ldur            w0, [x3, #0xf]
    // 0xd140bc: DecompressPointer r0
    //     0xd140bc: add             x0, x0, HEAP, lsl #32
    // 0xd140c0: LoadField: r1 = r0->field_2f
    //     0xd140c0: ldur            w1, [x0, #0x2f]
    // 0xd140c4: DecompressPointer r1
    //     0xd140c4: add             x1, x1, HEAP, lsl #32
    // 0xd140c8: LoadField: r0 = r1->field_6b
    //     0xd140c8: ldur            w0, [x1, #0x6b]
    // 0xd140cc: DecompressPointer r0
    //     0xd140cc: add             x0, x0, HEAP, lsl #32
    // 0xd140d0: stur            x0, [fp, #-0x10]
    // 0xd140d4: r0 = BorderSide()
    //     0xd140d4: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xd140d8: mov             x1, x0
    // 0xd140dc: ldur            x0, [fp, #-0x10]
    // 0xd140e0: StoreField: r1->field_7 = r0
    //     0xd140e0: stur            w0, [x1, #7]
    // 0xd140e4: d0 = 2.000000
    //     0xd140e4: fmov            d0, #2.00000000
    // 0xd140e8: StoreField: r1->field_b = d0
    //     0xd140e8: stur            d0, [x1, #0xb]
    // 0xd140ec: r4 = Instance_BorderStyle
    //     0xd140ec: add             x4, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd140f0: ldr             x4, [x4, #0xdc8]
    // 0xd140f4: StoreField: r1->field_13 = r4
    //     0xd140f4: stur            w4, [x1, #0x13]
    // 0xd140f8: d1 = -1.000000
    //     0xd140f8: fmov            d1, #-1.00000000
    // 0xd140fc: ArrayStore: r1[0] = d1  ; List_8
    //     0xd140fc: stur            d1, [x1, #0x17]
    // 0xd14100: mov             x0, x1
    // 0xd14104: LeaveFrame
    //     0xd14104: mov             SP, fp
    //     0xd14108: ldp             fp, lr, [SP], #0x10
    // 0xd1410c: ret
    //     0xd1410c: ret             
    // 0xd14110: ldr             x5, [fp, #0x10]
    // 0xd14114: ldur            x3, [fp, #-8]
    // 0xd14118: r4 = Instance_BorderStyle
    //     0xd14118: add             x4, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd1411c: ldr             x4, [x4, #0xdc8]
    // 0xd14120: d0 = 2.000000
    //     0xd14120: fmov            d0, #2.00000000
    // 0xd14124: d1 = -1.000000
    //     0xd14124: fmov            d1, #-1.00000000
    // 0xd14128: r0 = LoadClassIdInstr(r5)
    //     0xd14128: ldur            x0, [x5, #-1]
    //     0xd1412c: ubfx            x0, x0, #0xc, #0x14
    // 0xd14130: mov             x1, x5
    // 0xd14134: r2 = Instance_WidgetState
    //     0xd14134: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd14138: ldr             x2, [x2, #0xa48]
    // 0xd1413c: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd1413c: mov             x17, #0x2929
    //     0xd14140: movk            x17, #1, lsl #16
    //     0xd14144: add             lr, x0, x17
    //     0xd14148: ldr             lr, [x21, lr, lsl #3]
    //     0xd1414c: blr             lr
    // 0xd14150: tbnz            w0, #4, #0xd141b0
    // 0xd14154: ldur            x3, [fp, #-8]
    // 0xd14158: LoadField: r0 = r3->field_f
    //     0xd14158: ldur            w0, [x3, #0xf]
    // 0xd1415c: DecompressPointer r0
    //     0xd1415c: add             x0, x0, HEAP, lsl #32
    // 0xd14160: LoadField: r1 = r0->field_2f
    //     0xd14160: ldur            w1, [x0, #0x2f]
    // 0xd14164: DecompressPointer r1
    //     0xd14164: add             x1, x1, HEAP, lsl #32
    // 0xd14168: LoadField: r0 = r1->field_7f
    //     0xd14168: ldur            w0, [x1, #0x7f]
    // 0xd1416c: DecompressPointer r0
    //     0xd1416c: add             x0, x0, HEAP, lsl #32
    // 0xd14170: stur            x0, [fp, #-0x10]
    // 0xd14174: r0 = BorderSide()
    //     0xd14174: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xd14178: mov             x1, x0
    // 0xd1417c: ldur            x0, [fp, #-0x10]
    // 0xd14180: StoreField: r1->field_7 = r0
    //     0xd14180: stur            w0, [x1, #7]
    // 0xd14184: d0 = 2.000000
    //     0xd14184: fmov            d0, #2.00000000
    // 0xd14188: StoreField: r1->field_b = d0
    //     0xd14188: stur            d0, [x1, #0xb]
    // 0xd1418c: r4 = Instance_BorderStyle
    //     0xd1418c: add             x4, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd14190: ldr             x4, [x4, #0xdc8]
    // 0xd14194: StoreField: r1->field_13 = r4
    //     0xd14194: stur            w4, [x1, #0x13]
    // 0xd14198: d1 = -1.000000
    //     0xd14198: fmov            d1, #-1.00000000
    // 0xd1419c: ArrayStore: r1[0] = d1  ; List_8
    //     0xd1419c: stur            d1, [x1, #0x17]
    // 0xd141a0: mov             x0, x1
    // 0xd141a4: LeaveFrame
    //     0xd141a4: mov             SP, fp
    //     0xd141a8: ldp             fp, lr, [SP], #0x10
    // 0xd141ac: ret
    //     0xd141ac: ret             
    // 0xd141b0: ldr             x5, [fp, #0x10]
    // 0xd141b4: ldur            x3, [fp, #-8]
    // 0xd141b8: r4 = Instance_BorderStyle
    //     0xd141b8: add             x4, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd141bc: ldr             x4, [x4, #0xdc8]
    // 0xd141c0: d0 = 2.000000
    //     0xd141c0: fmov            d0, #2.00000000
    // 0xd141c4: d1 = -1.000000
    //     0xd141c4: fmov            d1, #-1.00000000
    // 0xd141c8: r0 = LoadClassIdInstr(r5)
    //     0xd141c8: ldur            x0, [x5, #-1]
    //     0xd141cc: ubfx            x0, x0, #0xc, #0x14
    // 0xd141d0: mov             x1, x5
    // 0xd141d4: r2 = Instance_WidgetState
    //     0xd141d4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd141d8: ldr             x2, [x2, #0xa50]
    // 0xd141dc: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd141dc: mov             x17, #0x2929
    //     0xd141e0: movk            x17, #1, lsl #16
    //     0xd141e4: add             lr, x0, x17
    //     0xd141e8: ldr             lr, [x21, lr, lsl #3]
    //     0xd141ec: blr             lr
    // 0xd141f0: tbnz            w0, #4, #0xd14250
    // 0xd141f4: ldur            x3, [fp, #-8]
    // 0xd141f8: LoadField: r0 = r3->field_f
    //     0xd141f8: ldur            w0, [x3, #0xf]
    // 0xd141fc: DecompressPointer r0
    //     0xd141fc: add             x0, x0, HEAP, lsl #32
    // 0xd14200: LoadField: r1 = r0->field_2f
    //     0xd14200: ldur            w1, [x0, #0x2f]
    // 0xd14204: DecompressPointer r1
    //     0xd14204: add             x1, x1, HEAP, lsl #32
    // 0xd14208: LoadField: r0 = r1->field_7f
    //     0xd14208: ldur            w0, [x1, #0x7f]
    // 0xd1420c: DecompressPointer r0
    //     0xd1420c: add             x0, x0, HEAP, lsl #32
    // 0xd14210: stur            x0, [fp, #-0x10]
    // 0xd14214: r0 = BorderSide()
    //     0xd14214: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xd14218: mov             x1, x0
    // 0xd1421c: ldur            x0, [fp, #-0x10]
    // 0xd14220: StoreField: r1->field_7 = r0
    //     0xd14220: stur            w0, [x1, #7]
    // 0xd14224: d0 = 2.000000
    //     0xd14224: fmov            d0, #2.00000000
    // 0xd14228: StoreField: r1->field_b = d0
    //     0xd14228: stur            d0, [x1, #0xb]
    // 0xd1422c: r4 = Instance_BorderStyle
    //     0xd1422c: add             x4, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd14230: ldr             x4, [x4, #0xdc8]
    // 0xd14234: StoreField: r1->field_13 = r4
    //     0xd14234: stur            w4, [x1, #0x13]
    // 0xd14238: d1 = -1.000000
    //     0xd14238: fmov            d1, #-1.00000000
    // 0xd1423c: ArrayStore: r1[0] = d1  ; List_8
    //     0xd1423c: stur            d1, [x1, #0x17]
    // 0xd14240: mov             x0, x1
    // 0xd14244: LeaveFrame
    //     0xd14244: mov             SP, fp
    //     0xd14248: ldp             fp, lr, [SP], #0x10
    // 0xd1424c: ret
    //     0xd1424c: ret             
    // 0xd14250: ldr             x1, [fp, #0x10]
    // 0xd14254: ldur            x3, [fp, #-8]
    // 0xd14258: r4 = Instance_BorderStyle
    //     0xd14258: add             x4, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd1425c: ldr             x4, [x4, #0xdc8]
    // 0xd14260: d0 = 2.000000
    //     0xd14260: fmov            d0, #2.00000000
    // 0xd14264: d1 = -1.000000
    //     0xd14264: fmov            d1, #-1.00000000
    // 0xd14268: r0 = LoadClassIdInstr(r1)
    //     0xd14268: ldur            x0, [x1, #-1]
    //     0xd1426c: ubfx            x0, x0, #0xc, #0x14
    // 0xd14270: r2 = Instance_WidgetState
    //     0xd14270: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd14274: ldr             x2, [x2, #0xa60]
    // 0xd14278: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd14278: mov             x17, #0x2929
    //     0xd1427c: movk            x17, #1, lsl #16
    //     0xd14280: add             lr, x0, x17
    //     0xd14284: ldr             lr, [x21, lr, lsl #3]
    //     0xd14288: blr             lr
    // 0xd1428c: tbnz            w0, #4, #0xd142ec
    // 0xd14290: ldur            x0, [fp, #-8]
    // 0xd14294: LoadField: r1 = r0->field_f
    //     0xd14294: ldur            w1, [x0, #0xf]
    // 0xd14298: DecompressPointer r1
    //     0xd14298: add             x1, x1, HEAP, lsl #32
    // 0xd1429c: LoadField: r0 = r1->field_2f
    //     0xd1429c: ldur            w0, [x1, #0x2f]
    // 0xd142a0: DecompressPointer r0
    //     0xd142a0: add             x0, x0, HEAP, lsl #32
    // 0xd142a4: LoadField: r1 = r0->field_7f
    //     0xd142a4: ldur            w1, [x0, #0x7f]
    // 0xd142a8: DecompressPointer r1
    //     0xd142a8: add             x1, x1, HEAP, lsl #32
    // 0xd142ac: stur            x1, [fp, #-0x10]
    // 0xd142b0: r0 = BorderSide()
    //     0xd142b0: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xd142b4: mov             x1, x0
    // 0xd142b8: ldur            x0, [fp, #-0x10]
    // 0xd142bc: StoreField: r1->field_7 = r0
    //     0xd142bc: stur            w0, [x1, #7]
    // 0xd142c0: d0 = 2.000000
    //     0xd142c0: fmov            d0, #2.00000000
    // 0xd142c4: StoreField: r1->field_b = d0
    //     0xd142c4: stur            d0, [x1, #0xb]
    // 0xd142c8: r2 = Instance_BorderStyle
    //     0xd142c8: add             x2, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd142cc: ldr             x2, [x2, #0xdc8]
    // 0xd142d0: StoreField: r1->field_13 = r2
    //     0xd142d0: stur            w2, [x1, #0x13]
    // 0xd142d4: d1 = -1.000000
    //     0xd142d4: fmov            d1, #-1.00000000
    // 0xd142d8: ArrayStore: r1[0] = d1  ; List_8
    //     0xd142d8: stur            d1, [x1, #0x17]
    // 0xd142dc: mov             x0, x1
    // 0xd142e0: LeaveFrame
    //     0xd142e0: mov             SP, fp
    //     0xd142e4: ldp             fp, lr, [SP], #0x10
    // 0xd142e8: ret
    //     0xd142e8: ret             
    // 0xd142ec: ldur            x0, [fp, #-8]
    // 0xd142f0: r2 = Instance_BorderStyle
    //     0xd142f0: add             x2, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd142f4: ldr             x2, [x2, #0xdc8]
    // 0xd142f8: d0 = 2.000000
    //     0xd142f8: fmov            d0, #2.00000000
    // 0xd142fc: d1 = -1.000000
    //     0xd142fc: fmov            d1, #-1.00000000
    // 0xd14300: LoadField: r1 = r0->field_f
    //     0xd14300: ldur            w1, [x0, #0xf]
    // 0xd14304: DecompressPointer r1
    //     0xd14304: add             x1, x1, HEAP, lsl #32
    // 0xd14308: LoadField: r0 = r1->field_2f
    //     0xd14308: ldur            w0, [x1, #0x2f]
    // 0xd1430c: DecompressPointer r0
    //     0xd1430c: add             x0, x0, HEAP, lsl #32
    // 0xd14310: LoadField: r1 = r0->field_a3
    //     0xd14310: ldur            w1, [x0, #0xa3]
    // 0xd14314: DecompressPointer r1
    //     0xd14314: add             x1, x1, HEAP, lsl #32
    // 0xd14318: cmp             w1, NULL
    // 0xd1431c: b.ne            #0xd14330
    // 0xd14320: LoadField: r1 = r0->field_7f
    //     0xd14320: ldur            w1, [x0, #0x7f]
    // 0xd14324: DecompressPointer r1
    //     0xd14324: add             x1, x1, HEAP, lsl #32
    // 0xd14328: mov             x0, x1
    // 0xd1432c: b               #0xd14334
    // 0xd14330: mov             x0, x1
    // 0xd14334: stur            x0, [fp, #-8]
    // 0xd14338: r0 = BorderSide()
    //     0xd14338: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xd1433c: ldur            x1, [fp, #-8]
    // 0xd14340: StoreField: r0->field_7 = r1
    //     0xd14340: stur            w1, [x0, #7]
    // 0xd14344: d0 = 2.000000
    //     0xd14344: fmov            d0, #2.00000000
    // 0xd14348: StoreField: r0->field_b = d0
    //     0xd14348: stur            d0, [x0, #0xb]
    // 0xd1434c: r1 = Instance_BorderStyle
    //     0xd1434c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd14350: ldr             x1, [x1, #0xdc8]
    // 0xd14354: StoreField: r0->field_13 = r1
    //     0xd14354: stur            w1, [x0, #0x13]
    // 0xd14358: d0 = -1.000000
    //     0xd14358: fmov            d0, #-1.00000000
    // 0xd1435c: ArrayStore: r0[0] = d0  ; List_8
    //     0xd1435c: stur            d0, [x0, #0x17]
    // 0xd14360: LeaveFrame
    //     0xd14360: mov             SP, fp
    //     0xd14364: ldp             fp, lr, [SP], #0x10
    // 0xd14368: ret
    //     0xd14368: ret             
    // 0xd1436c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1436c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd14370: b               #0xd13f34
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd144a8, size: 0x1b8
    // 0xd144a8: EnterFrame
    //     0xd144a8: stp             fp, lr, [SP, #-0x10]!
    //     0xd144ac: mov             fp, SP
    // 0xd144b0: AllocStack(0x8)
    //     0xd144b0: sub             SP, SP, #8
    // 0xd144b4: SetupParameters([dynamic _ /* r0 */])
    //     0xd144b4: ldr             x0, [fp, #0x18]
    //     0xd144b8: ldur            w3, [x0, #0x17]
    //     0xd144bc: add             x3, x3, HEAP, lsl #32
    //     0xd144c0: stur            x3, [fp, #-8]
    // 0xd144c4: CheckStackOverflow
    //     0xd144c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd144c8: cmp             SP, x16
    //     0xd144cc: b.ls            #0xd14658
    // 0xd144d0: ldr             x4, [fp, #0x10]
    // 0xd144d4: r0 = LoadClassIdInstr(r4)
    //     0xd144d4: ldur            x0, [x4, #-1]
    //     0xd144d8: ubfx            x0, x0, #0xc, #0x14
    // 0xd144dc: mov             x1, x4
    // 0xd144e0: r2 = Instance_WidgetState
    //     0xd144e0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd144e4: ldr             x2, [x2, #0xa70]
    // 0xd144e8: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd144e8: mov             x17, #0x2929
    //     0xd144ec: movk            x17, #1, lsl #16
    //     0xd144f0: add             lr, x0, x17
    //     0xd144f4: ldr             lr, [x21, lr, lsl #3]
    //     0xd144f8: blr             lr
    // 0xd144fc: tbnz            w0, #4, #0xd14594
    // 0xd14500: ldr             x3, [fp, #0x10]
    // 0xd14504: r0 = LoadClassIdInstr(r3)
    //     0xd14504: ldur            x0, [x3, #-1]
    //     0xd14508: ubfx            x0, x0, #0xc, #0x14
    // 0xd1450c: mov             x1, x3
    // 0xd14510: r2 = Instance_WidgetState
    //     0xd14510: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd14514: ldr             x2, [x2, #0x100]
    // 0xd14518: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd14518: mov             x17, #0x2929
    //     0xd1451c: movk            x17, #1, lsl #16
    //     0xd14520: add             lr, x0, x17
    //     0xd14524: ldr             lr, [x21, lr, lsl #3]
    //     0xd14528: blr             lr
    // 0xd1452c: tbnz            w0, #4, #0xd14580
    // 0xd14530: ldur            x4, [fp, #-8]
    // 0xd14534: LoadField: r0 = r4->field_f
    //     0xd14534: ldur            w0, [x4, #0xf]
    // 0xd14538: DecompressPointer r0
    //     0xd14538: add             x0, x0, HEAP, lsl #32
    // 0xd1453c: LoadField: r1 = r0->field_2f
    //     0xd1453c: ldur            w1, [x0, #0x2f]
    // 0xd14540: DecompressPointer r1
    //     0xd14540: add             x1, x1, HEAP, lsl #32
    // 0xd14544: LoadField: r0 = r1->field_7f
    //     0xd14544: ldur            w0, [x1, #0x7f]
    // 0xd14548: DecompressPointer r0
    //     0xd14548: add             x0, x0, HEAP, lsl #32
    // 0xd1454c: r1 = LoadClassIdInstr(r0)
    //     0xd1454c: ldur            x1, [x0, #-1]
    //     0xd14550: ubfx            x1, x1, #0xc, #0x14
    // 0xd14554: mov             x16, x0
    // 0xd14558: mov             x0, x1
    // 0xd1455c: mov             x1, x16
    // 0xd14560: d0 = 0.380000
    //     0xd14560: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xd14564: ldr             d0, [x17, #0x1f0]
    // 0xd14568: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd14568: sub             lr, x0, #1, lsl #12
    //     0xd1456c: ldr             lr, [x21, lr, lsl #3]
    //     0xd14570: blr             lr
    // 0xd14574: LeaveFrame
    //     0xd14574: mov             SP, fp
    //     0xd14578: ldp             fp, lr, [SP], #0x10
    // 0xd1457c: ret
    //     0xd1457c: ret             
    // 0xd14580: r0 = Instance_Color
    //     0xd14580: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xd14584: ldr             x0, [x0, #0x810]
    // 0xd14588: LeaveFrame
    //     0xd14588: mov             SP, fp
    //     0xd1458c: ldp             fp, lr, [SP], #0x10
    // 0xd14590: ret
    //     0xd14590: ret             
    // 0xd14594: ldr             x3, [fp, #0x10]
    // 0xd14598: ldur            x4, [fp, #-8]
    // 0xd1459c: r0 = LoadClassIdInstr(r3)
    //     0xd1459c: ldur            x0, [x3, #-1]
    //     0xd145a0: ubfx            x0, x0, #0xc, #0x14
    // 0xd145a4: mov             x1, x3
    // 0xd145a8: r2 = Instance_WidgetState
    //     0xd145a8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd145ac: ldr             x2, [x2, #0x100]
    // 0xd145b0: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd145b0: mov             x17, #0x2929
    //     0xd145b4: movk            x17, #1, lsl #16
    //     0xd145b8: add             lr, x0, x17
    //     0xd145bc: ldr             lr, [x21, lr, lsl #3]
    //     0xd145c0: blr             lr
    // 0xd145c4: tbnz            w0, #4, #0xd14644
    // 0xd145c8: ldr             x1, [fp, #0x10]
    // 0xd145cc: r0 = LoadClassIdInstr(r1)
    //     0xd145cc: ldur            x0, [x1, #-1]
    //     0xd145d0: ubfx            x0, x0, #0xc, #0x14
    // 0xd145d4: r2 = Instance_WidgetState
    //     0xd145d4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26500] Obj!WidgetState@12c8781
    //     0xd145d8: ldr             x2, [x2, #0x500]
    // 0xd145dc: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd145dc: mov             x17, #0x2929
    //     0xd145e0: movk            x17, #1, lsl #16
    //     0xd145e4: add             lr, x0, x17
    //     0xd145e8: ldr             lr, [x21, lr, lsl #3]
    //     0xd145ec: blr             lr
    // 0xd145f0: tbnz            w0, #4, #0xd1461c
    // 0xd145f4: ldur            x1, [fp, #-8]
    // 0xd145f8: LoadField: r2 = r1->field_f
    //     0xd145f8: ldur            w2, [x1, #0xf]
    // 0xd145fc: DecompressPointer r2
    //     0xd145fc: add             x2, x2, HEAP, lsl #32
    // 0xd14600: LoadField: r3 = r2->field_2f
    //     0xd14600: ldur            w3, [x2, #0x2f]
    // 0xd14604: DecompressPointer r3
    //     0xd14604: add             x3, x3, HEAP, lsl #32
    // 0xd14608: LoadField: r0 = r3->field_6b
    //     0xd14608: ldur            w0, [x3, #0x6b]
    // 0xd1460c: DecompressPointer r0
    //     0xd1460c: add             x0, x0, HEAP, lsl #32
    // 0xd14610: LeaveFrame
    //     0xd14610: mov             SP, fp
    //     0xd14614: ldp             fp, lr, [SP], #0x10
    // 0xd14618: ret
    //     0xd14618: ret             
    // 0xd1461c: ldur            x1, [fp, #-8]
    // 0xd14620: LoadField: r2 = r1->field_f
    //     0xd14620: ldur            w2, [x1, #0xf]
    // 0xd14624: DecompressPointer r2
    //     0xd14624: add             x2, x2, HEAP, lsl #32
    // 0xd14628: LoadField: r1 = r2->field_2f
    //     0xd14628: ldur            w1, [x2, #0x2f]
    // 0xd1462c: DecompressPointer r1
    //     0xd1462c: add             x1, x1, HEAP, lsl #32
    // 0xd14630: LoadField: r0 = r1->field_b
    //     0xd14630: ldur            w0, [x1, #0xb]
    // 0xd14634: DecompressPointer r0
    //     0xd14634: add             x0, x0, HEAP, lsl #32
    // 0xd14638: LeaveFrame
    //     0xd14638: mov             SP, fp
    //     0xd1463c: ldp             fp, lr, [SP], #0x10
    // 0xd14640: ret
    //     0xd14640: ret             
    // 0xd14644: r0 = Instance_Color
    //     0xd14644: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xd14648: ldr             x0, [x0, #0x810]
    // 0xd1464c: LeaveFrame
    //     0xd1464c: mov             SP, fp
    //     0xd14650: ldp             fp, lr, [SP], #0x10
    // 0xd14654: ret
    //     0xd14654: ret             
    // 0xd14658: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd14658: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1465c: b               #0xd144d0
  }
}

// class id: 5175, size: 0x34, field offset: 0x2c
class _CheckboxDefaultsM2 extends CheckboxThemeData {

  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd136b4, size: 0x1ac
    // 0xd136b4: EnterFrame
    //     0xd136b4: stp             fp, lr, [SP, #-0x10]!
    //     0xd136b8: mov             fp, SP
    // 0xd136bc: AllocStack(0x20)
    //     0xd136bc: sub             SP, SP, #0x20
    // 0xd136c0: SetupParameters([dynamic _ /* r0 */])
    //     0xd136c0: ldr             x0, [fp, #0x18]
    //     0xd136c4: ldur            w3, [x0, #0x17]
    //     0xd136c8: add             x3, x3, HEAP, lsl #32
    //     0xd136cc: stur            x3, [fp, #-8]
    // 0xd136d0: CheckStackOverflow
    //     0xd136d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd136d4: cmp             SP, x16
    //     0xd136d8: b.ls            #0xd13858
    // 0xd136dc: ldr             x4, [fp, #0x10]
    // 0xd136e0: r0 = LoadClassIdInstr(r4)
    //     0xd136e0: ldur            x0, [x4, #-1]
    //     0xd136e4: ubfx            x0, x0, #0xc, #0x14
    // 0xd136e8: mov             x1, x4
    // 0xd136ec: r2 = Instance_WidgetState
    //     0xd136ec: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd136f0: ldr             x2, [x2, #0xa48]
    // 0xd136f4: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd136f4: mov             x17, #0x2929
    //     0xd136f8: movk            x17, #1, lsl #16
    //     0xd136fc: add             lr, x0, x17
    //     0xd13700: ldr             lr, [x21, lr, lsl #3]
    //     0xd13704: blr             lr
    // 0xd13708: tbnz            w0, #4, #0xd13790
    // 0xd1370c: ldur            x3, [fp, #-8]
    // 0xd13710: LoadField: r0 = r3->field_f
    //     0xd13710: ldur            w0, [x3, #0xf]
    // 0xd13714: DecompressPointer r0
    //     0xd13714: add             x0, x0, HEAP, lsl #32
    // 0xd13718: stur            x0, [fp, #-0x10]
    // 0xd1371c: r1 = 1
    //     0xd1371c: mov             x1, #1
    // 0xd13720: r0 = AllocateContext()
    //     0xd13720: bl              #0x13de838  ; AllocateContextStub
    // 0xd13724: mov             x1, x0
    // 0xd13728: ldur            x0, [fp, #-0x10]
    // 0xd1372c: StoreField: r1->field_f = r0
    //     0xd1372c: stur            w0, [x1, #0xf]
    // 0xd13730: mov             x2, x1
    // 0xd13734: r1 = Function '<anonymous closure>':.
    //     0xd13734: add             x1, PP, #0x26, lsl #12  ; [pp+0x264b0] AnonymousClosure: (0xd14374), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0xd13738: ldr             x1, [x1, #0x4b0]
    // 0xd1373c: r0 = AllocateClosure()
    //     0xd1373c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd13740: r16 = <Color>
    //     0xd13740: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd13744: ldr             x16, [x16, #0xa90]
    // 0xd13748: stp             x0, x16, [SP]
    // 0xd1374c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd1374c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd13750: r0 = resolveWith()
    //     0xd13750: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd13754: mov             x1, x0
    // 0xd13758: ldr             x2, [fp, #0x10]
    // 0xd1375c: r0 = build()
    //     0xd1375c: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd13760: r1 = LoadClassIdInstr(r0)
    //     0xd13760: ldur            x1, [x0, #-1]
    //     0xd13764: ubfx            x1, x1, #0xc, #0x14
    // 0xd13768: mov             x16, x0
    // 0xd1376c: mov             x0, x1
    // 0xd13770: mov             x1, x16
    // 0xd13774: r2 = 31
    //     0xd13774: mov             x2, #0x1f
    // 0xd13778: r0 = GDT[cid_x0 + -0xff4]()
    //     0xd13778: sub             lr, x0, #0xff4
    //     0xd1377c: ldr             lr, [x21, lr, lsl #3]
    //     0xd13780: blr             lr
    // 0xd13784: LeaveFrame
    //     0xd13784: mov             SP, fp
    //     0xd13788: ldp             fp, lr, [SP], #0x10
    // 0xd1378c: ret
    //     0xd1378c: ret             
    // 0xd13790: ldr             x4, [fp, #0x10]
    // 0xd13794: ldur            x3, [fp, #-8]
    // 0xd13798: r0 = LoadClassIdInstr(r4)
    //     0xd13798: ldur            x0, [x4, #-1]
    //     0xd1379c: ubfx            x0, x0, #0xc, #0x14
    // 0xd137a0: mov             x1, x4
    // 0xd137a4: r2 = Instance_WidgetState
    //     0xd137a4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd137a8: ldr             x2, [x2, #0xa50]
    // 0xd137ac: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd137ac: mov             x17, #0x2929
    //     0xd137b0: movk            x17, #1, lsl #16
    //     0xd137b4: add             lr, x0, x17
    //     0xd137b8: ldr             lr, [x21, lr, lsl #3]
    //     0xd137bc: blr             lr
    // 0xd137c0: tbnz            w0, #4, #0xd137ec
    // 0xd137c4: ldur            x3, [fp, #-8]
    // 0xd137c8: LoadField: r0 = r3->field_f
    //     0xd137c8: ldur            w0, [x3, #0xf]
    // 0xd137cc: DecompressPointer r0
    //     0xd137cc: add             x0, x0, HEAP, lsl #32
    // 0xd137d0: LoadField: r1 = r0->field_2b
    //     0xd137d0: ldur            w1, [x0, #0x2b]
    // 0xd137d4: DecompressPointer r1
    //     0xd137d4: add             x1, x1, HEAP, lsl #32
    // 0xd137d8: LoadField: r0 = r1->field_57
    //     0xd137d8: ldur            w0, [x1, #0x57]
    // 0xd137dc: DecompressPointer r0
    //     0xd137dc: add             x0, x0, HEAP, lsl #32
    // 0xd137e0: LeaveFrame
    //     0xd137e0: mov             SP, fp
    //     0xd137e4: ldp             fp, lr, [SP], #0x10
    // 0xd137e8: ret
    //     0xd137e8: ret             
    // 0xd137ec: ldr             x1, [fp, #0x10]
    // 0xd137f0: ldur            x3, [fp, #-8]
    // 0xd137f4: r0 = LoadClassIdInstr(r1)
    //     0xd137f4: ldur            x0, [x1, #-1]
    //     0xd137f8: ubfx            x0, x0, #0xc, #0x14
    // 0xd137fc: r2 = Instance_WidgetState
    //     0xd137fc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd13800: ldr             x2, [x2, #0xa60]
    // 0xd13804: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd13804: mov             x17, #0x2929
    //     0xd13808: movk            x17, #1, lsl #16
    //     0xd1380c: add             lr, x0, x17
    //     0xd13810: ldr             lr, [x21, lr, lsl #3]
    //     0xd13814: blr             lr
    // 0xd13818: tbnz            w0, #4, #0xd13844
    // 0xd1381c: ldur            x1, [fp, #-8]
    // 0xd13820: LoadField: r2 = r1->field_f
    //     0xd13820: ldur            w2, [x1, #0xf]
    // 0xd13824: DecompressPointer r2
    //     0xd13824: add             x2, x2, HEAP, lsl #32
    // 0xd13828: LoadField: r1 = r2->field_2b
    //     0xd13828: ldur            w1, [x2, #0x2b]
    // 0xd1382c: DecompressPointer r1
    //     0xd1382c: add             x1, x1, HEAP, lsl #32
    // 0xd13830: LoadField: r0 = r1->field_4b
    //     0xd13830: ldur            w0, [x1, #0x4b]
    // 0xd13834: DecompressPointer r0
    //     0xd13834: add             x0, x0, HEAP, lsl #32
    // 0xd13838: LeaveFrame
    //     0xd13838: mov             SP, fp
    //     0xd1383c: ldp             fp, lr, [SP], #0x10
    // 0xd13840: ret
    //     0xd13840: ret             
    // 0xd13844: r0 = Instance_Color
    //     0xd13844: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xd13848: ldr             x0, [x0, #0x810]
    // 0xd1384c: LeaveFrame
    //     0xd1384c: mov             SP, fp
    //     0xd13850: ldp             fp, lr, [SP], #0x10
    // 0xd13854: ret
    //     0xd13854: ret             
    // 0xd13858: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd13858: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1385c: b               #0xd136dc
  }
  [closure] BorderSide <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd13d68, size: 0x1a4
    // 0xd13d68: EnterFrame
    //     0xd13d68: stp             fp, lr, [SP, #-0x10]!
    //     0xd13d6c: mov             fp, SP
    // 0xd13d70: AllocStack(0x10)
    //     0xd13d70: sub             SP, SP, #0x10
    // 0xd13d74: SetupParameters([dynamic _ /* r0 */])
    //     0xd13d74: ldr             x0, [fp, #0x18]
    //     0xd13d78: ldur            w3, [x0, #0x17]
    //     0xd13d7c: add             x3, x3, HEAP, lsl #32
    //     0xd13d80: stur            x3, [fp, #-8]
    // 0xd13d84: CheckStackOverflow
    //     0xd13d84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd13d88: cmp             SP, x16
    //     0xd13d8c: b.ls            #0xd13f04
    // 0xd13d90: ldr             x4, [fp, #0x10]
    // 0xd13d94: r0 = LoadClassIdInstr(r4)
    //     0xd13d94: ldur            x0, [x4, #-1]
    //     0xd13d98: ubfx            x0, x0, #0xc, #0x14
    // 0xd13d9c: mov             x1, x4
    // 0xd13da0: r2 = Instance_WidgetState
    //     0xd13da0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd13da4: ldr             x2, [x2, #0xa70]
    // 0xd13da8: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd13da8: mov             x17, #0x2929
    //     0xd13dac: movk            x17, #1, lsl #16
    //     0xd13db0: add             lr, x0, x17
    //     0xd13db4: ldr             lr, [x21, lr, lsl #3]
    //     0xd13db8: blr             lr
    // 0xd13dbc: tbnz            w0, #4, #0xd13e5c
    // 0xd13dc0: ldr             x1, [fp, #0x10]
    // 0xd13dc4: r0 = LoadClassIdInstr(r1)
    //     0xd13dc4: ldur            x0, [x1, #-1]
    //     0xd13dc8: ubfx            x0, x0, #0xc, #0x14
    // 0xd13dcc: r2 = Instance_WidgetState
    //     0xd13dcc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd13dd0: ldr             x2, [x2, #0x100]
    // 0xd13dd4: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd13dd4: mov             x17, #0x2929
    //     0xd13dd8: movk            x17, #1, lsl #16
    //     0xd13ddc: add             lr, x0, x17
    //     0xd13de0: ldr             lr, [x21, lr, lsl #3]
    //     0xd13de4: blr             lr
    // 0xd13de8: tbnz            w0, #4, #0xd13e00
    // 0xd13dec: r0 = Instance_BorderSide
    //     0xd13dec: add             x0, PP, #0x26, lsl #12  ; [pp+0x264f0] Obj!BorderSide@12b1b51
    //     0xd13df0: ldr             x0, [x0, #0x4f0]
    // 0xd13df4: LeaveFrame
    //     0xd13df4: mov             SP, fp
    //     0xd13df8: ldp             fp, lr, [SP], #0x10
    // 0xd13dfc: ret
    //     0xd13dfc: ret             
    // 0xd13e00: ldur            x3, [fp, #-8]
    // 0xd13e04: LoadField: r0 = r3->field_f
    //     0xd13e04: ldur            w0, [x3, #0xf]
    // 0xd13e08: DecompressPointer r0
    //     0xd13e08: add             x0, x0, HEAP, lsl #32
    // 0xd13e0c: LoadField: r1 = r0->field_2b
    //     0xd13e0c: ldur            w1, [x0, #0x2b]
    // 0xd13e10: DecompressPointer r1
    //     0xd13e10: add             x1, x1, HEAP, lsl #32
    // 0xd13e14: LoadField: r0 = r1->field_43
    //     0xd13e14: ldur            w0, [x1, #0x43]
    // 0xd13e18: DecompressPointer r0
    //     0xd13e18: add             x0, x0, HEAP, lsl #32
    // 0xd13e1c: stur            x0, [fp, #-0x10]
    // 0xd13e20: r0 = BorderSide()
    //     0xd13e20: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xd13e24: mov             x1, x0
    // 0xd13e28: ldur            x0, [fp, #-0x10]
    // 0xd13e2c: StoreField: r1->field_7 = r0
    //     0xd13e2c: stur            w0, [x1, #7]
    // 0xd13e30: d0 = 2.000000
    //     0xd13e30: fmov            d0, #2.00000000
    // 0xd13e34: StoreField: r1->field_b = d0
    //     0xd13e34: stur            d0, [x1, #0xb]
    // 0xd13e38: r4 = Instance_BorderStyle
    //     0xd13e38: add             x4, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd13e3c: ldr             x4, [x4, #0xdc8]
    // 0xd13e40: StoreField: r1->field_13 = r4
    //     0xd13e40: stur            w4, [x1, #0x13]
    // 0xd13e44: d1 = -1.000000
    //     0xd13e44: fmov            d1, #-1.00000000
    // 0xd13e48: ArrayStore: r1[0] = d1  ; List_8
    //     0xd13e48: stur            d1, [x1, #0x17]
    // 0xd13e4c: mov             x0, x1
    // 0xd13e50: LeaveFrame
    //     0xd13e50: mov             SP, fp
    //     0xd13e54: ldp             fp, lr, [SP], #0x10
    // 0xd13e58: ret
    //     0xd13e58: ret             
    // 0xd13e5c: ldr             x1, [fp, #0x10]
    // 0xd13e60: ldur            x3, [fp, #-8]
    // 0xd13e64: r4 = Instance_BorderStyle
    //     0xd13e64: add             x4, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd13e68: ldr             x4, [x4, #0xdc8]
    // 0xd13e6c: d0 = 2.000000
    //     0xd13e6c: fmov            d0, #2.00000000
    // 0xd13e70: d1 = -1.000000
    //     0xd13e70: fmov            d1, #-1.00000000
    // 0xd13e74: r0 = LoadClassIdInstr(r1)
    //     0xd13e74: ldur            x0, [x1, #-1]
    //     0xd13e78: ubfx            x0, x0, #0xc, #0x14
    // 0xd13e7c: r2 = Instance_WidgetState
    //     0xd13e7c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd13e80: ldr             x2, [x2, #0x100]
    // 0xd13e84: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd13e84: mov             x17, #0x2929
    //     0xd13e88: movk            x17, #1, lsl #16
    //     0xd13e8c: add             lr, x0, x17
    //     0xd13e90: ldr             lr, [x21, lr, lsl #3]
    //     0xd13e94: blr             lr
    // 0xd13e98: tbnz            w0, #4, #0xd13eb0
    // 0xd13e9c: r0 = Instance_BorderSide
    //     0xd13e9c: add             x0, PP, #0x26, lsl #12  ; [pp+0x264f0] Obj!BorderSide@12b1b51
    //     0xd13ea0: ldr             x0, [x0, #0x4f0]
    // 0xd13ea4: LeaveFrame
    //     0xd13ea4: mov             SP, fp
    //     0xd13ea8: ldp             fp, lr, [SP], #0x10
    // 0xd13eac: ret
    //     0xd13eac: ret             
    // 0xd13eb0: ldur            x0, [fp, #-8]
    // 0xd13eb4: LoadField: r1 = r0->field_f
    //     0xd13eb4: ldur            w1, [x0, #0xf]
    // 0xd13eb8: DecompressPointer r1
    //     0xd13eb8: add             x1, x1, HEAP, lsl #32
    // 0xd13ebc: LoadField: r0 = r1->field_2b
    //     0xd13ebc: ldur            w0, [x1, #0x2b]
    // 0xd13ec0: DecompressPointer r0
    //     0xd13ec0: add             x0, x0, HEAP, lsl #32
    // 0xd13ec4: LoadField: r1 = r0->field_77
    //     0xd13ec4: ldur            w1, [x0, #0x77]
    // 0xd13ec8: DecompressPointer r1
    //     0xd13ec8: add             x1, x1, HEAP, lsl #32
    // 0xd13ecc: stur            x1, [fp, #-8]
    // 0xd13ed0: r0 = BorderSide()
    //     0xd13ed0: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xd13ed4: ldur            x1, [fp, #-8]
    // 0xd13ed8: StoreField: r0->field_7 = r1
    //     0xd13ed8: stur            w1, [x0, #7]
    // 0xd13edc: d0 = 2.000000
    //     0xd13edc: fmov            d0, #2.00000000
    // 0xd13ee0: StoreField: r0->field_b = d0
    //     0xd13ee0: stur            d0, [x0, #0xb]
    // 0xd13ee4: r1 = Instance_BorderStyle
    //     0xd13ee4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd13ee8: ldr             x1, [x1, #0xdc8]
    // 0xd13eec: StoreField: r0->field_13 = r1
    //     0xd13eec: stur            w1, [x0, #0x13]
    // 0xd13ef0: d0 = -1.000000
    //     0xd13ef0: fmov            d0, #-1.00000000
    // 0xd13ef4: ArrayStore: r0[0] = d0  ; List_8
    //     0xd13ef4: stur            d0, [x0, #0x17]
    // 0xd13ef8: LeaveFrame
    //     0xd13ef8: mov             SP, fp
    //     0xd13efc: ldp             fp, lr, [SP], #0x10
    // 0xd13f00: ret
    //     0xd13f00: ret             
    // 0xd13f04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd13f04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd13f08: b               #0xd13d90
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd14374, size: 0x134
    // 0xd14374: EnterFrame
    //     0xd14374: stp             fp, lr, [SP, #-0x10]!
    //     0xd14378: mov             fp, SP
    // 0xd1437c: AllocStack(0x8)
    //     0xd1437c: sub             SP, SP, #8
    // 0xd14380: SetupParameters([dynamic _ /* r0 */])
    //     0xd14380: ldr             x0, [fp, #0x18]
    //     0xd14384: ldur            w3, [x0, #0x17]
    //     0xd14388: add             x3, x3, HEAP, lsl #32
    //     0xd1438c: stur            x3, [fp, #-8]
    // 0xd14390: CheckStackOverflow
    //     0xd14390: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd14394: cmp             SP, x16
    //     0xd14398: b.ls            #0xd144a0
    // 0xd1439c: ldr             x4, [fp, #0x10]
    // 0xd143a0: r0 = LoadClassIdInstr(r4)
    //     0xd143a0: ldur            x0, [x4, #-1]
    //     0xd143a4: ubfx            x0, x0, #0xc, #0x14
    // 0xd143a8: mov             x1, x4
    // 0xd143ac: r2 = Instance_WidgetState
    //     0xd143ac: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd143b0: ldr             x2, [x2, #0xa70]
    // 0xd143b4: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd143b4: mov             x17, #0x2929
    //     0xd143b8: movk            x17, #1, lsl #16
    //     0xd143bc: add             lr, x0, x17
    //     0xd143c0: ldr             lr, [x21, lr, lsl #3]
    //     0xd143c4: blr             lr
    // 0xd143c8: tbnz            w0, #4, #0xd14434
    // 0xd143cc: ldr             x1, [fp, #0x10]
    // 0xd143d0: r0 = LoadClassIdInstr(r1)
    //     0xd143d0: ldur            x0, [x1, #-1]
    //     0xd143d4: ubfx            x0, x0, #0xc, #0x14
    // 0xd143d8: r2 = Instance_WidgetState
    //     0xd143d8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd143dc: ldr             x2, [x2, #0x100]
    // 0xd143e0: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd143e0: mov             x17, #0x2929
    //     0xd143e4: movk            x17, #1, lsl #16
    //     0xd143e8: add             lr, x0, x17
    //     0xd143ec: ldr             lr, [x21, lr, lsl #3]
    //     0xd143f0: blr             lr
    // 0xd143f4: tbnz            w0, #4, #0xd14420
    // 0xd143f8: ldur            x3, [fp, #-8]
    // 0xd143fc: LoadField: r0 = r3->field_f
    //     0xd143fc: ldur            w0, [x3, #0xf]
    // 0xd14400: DecompressPointer r0
    //     0xd14400: add             x0, x0, HEAP, lsl #32
    // 0xd14404: LoadField: r1 = r0->field_2b
    //     0xd14404: ldur            w1, [x0, #0x2b]
    // 0xd14408: DecompressPointer r1
    //     0xd14408: add             x1, x1, HEAP, lsl #32
    // 0xd1440c: LoadField: r0 = r1->field_43
    //     0xd1440c: ldur            w0, [x1, #0x43]
    // 0xd14410: DecompressPointer r0
    //     0xd14410: add             x0, x0, HEAP, lsl #32
    // 0xd14414: LeaveFrame
    //     0xd14414: mov             SP, fp
    //     0xd14418: ldp             fp, lr, [SP], #0x10
    // 0xd1441c: ret
    //     0xd1441c: ret             
    // 0xd14420: r0 = Instance_Color
    //     0xd14420: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xd14424: ldr             x0, [x0, #0x810]
    // 0xd14428: LeaveFrame
    //     0xd14428: mov             SP, fp
    //     0xd1442c: ldp             fp, lr, [SP], #0x10
    // 0xd14430: ret
    //     0xd14430: ret             
    // 0xd14434: ldr             x1, [fp, #0x10]
    // 0xd14438: ldur            x3, [fp, #-8]
    // 0xd1443c: r0 = LoadClassIdInstr(r1)
    //     0xd1443c: ldur            x0, [x1, #-1]
    //     0xd14440: ubfx            x0, x0, #0xc, #0x14
    // 0xd14444: r2 = Instance_WidgetState
    //     0xd14444: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd14448: ldr             x2, [x2, #0x100]
    // 0xd1444c: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd1444c: mov             x17, #0x2929
    //     0xd14450: movk            x17, #1, lsl #16
    //     0xd14454: add             lr, x0, x17
    //     0xd14458: ldr             lr, [x21, lr, lsl #3]
    //     0xd1445c: blr             lr
    // 0xd14460: tbnz            w0, #4, #0xd1448c
    // 0xd14464: ldur            x1, [fp, #-8]
    // 0xd14468: LoadField: r2 = r1->field_f
    //     0xd14468: ldur            w2, [x1, #0xf]
    // 0xd1446c: DecompressPointer r2
    //     0xd1446c: add             x2, x2, HEAP, lsl #32
    // 0xd14470: LoadField: r1 = r2->field_2f
    //     0xd14470: ldur            w1, [x2, #0x2f]
    // 0xd14474: DecompressPointer r1
    //     0xd14474: add             x1, x1, HEAP, lsl #32
    // 0xd14478: LoadField: r0 = r1->field_2b
    //     0xd14478: ldur            w0, [x1, #0x2b]
    // 0xd1447c: DecompressPointer r0
    //     0xd1447c: add             x0, x0, HEAP, lsl #32
    // 0xd14480: LeaveFrame
    //     0xd14480: mov             SP, fp
    //     0xd14484: ldp             fp, lr, [SP], #0x10
    // 0xd14488: ret
    //     0xd14488: ret             
    // 0xd1448c: r0 = Instance_Color
    //     0xd1448c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xd14490: ldr             x0, [x0, #0x810]
    // 0xd14494: LeaveFrame
    //     0xd14494: mov             SP, fp
    //     0xd14498: ldp             fp, lr, [SP], #0x10
    // 0xd1449c: ret
    //     0xd1449c: ret             
    // 0xd144a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd144a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd144a4: b               #0xd1439c
  }
}

// class id: 5771, size: 0x58, field offset: 0x50
class _CheckboxState extends _MixinApplication26&State&TickerProviderStateMixin&ToggleableStateMixin {

  _ build(/* No info */) {
    // ** addr: 0xd10428, size: 0x132c
    // 0xd10428: EnterFrame
    //     0xd10428: stp             fp, lr, [SP, #-0x10]!
    //     0xd1042c: mov             fp, SP
    // 0xd10430: AllocStack(0xb0)
    //     0xd10430: sub             SP, SP, #0xb0
    // 0xd10434: SetupParameters(_CheckboxState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd10434: mov             x0, x1
    //     0xd10438: stur            x1, [fp, #-8]
    //     0xd1043c: mov             x1, x2
    //     0xd10440: stur            x2, [fp, #-0x10]
    // 0xd10444: CheckStackOverflow
    //     0xd10444: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd10448: cmp             SP, x16
    //     0xd1044c: b.ls            #0xd116b8
    // 0xd10450: r1 = 2
    //     0xd10450: mov             x1, #2
    // 0xd10454: r0 = AllocateContext()
    //     0xd10454: bl              #0x13de838  ; AllocateContextStub
    // 0xd10458: mov             x2, x0
    // 0xd1045c: ldur            x0, [fp, #-8]
    // 0xd10460: stur            x2, [fp, #-0x18]
    // 0xd10464: StoreField: r2->field_f = r0
    //     0xd10464: stur            w0, [x2, #0xf]
    // 0xd10468: LoadField: r1 = r0->field_b
    //     0xd10468: ldur            w1, [x0, #0xb]
    // 0xd1046c: DecompressPointer r1
    //     0xd1046c: add             x1, x1, HEAP, lsl #32
    // 0xd10470: cmp             w1, NULL
    // 0xd10474: b.eq            #0xd116c0
    // 0xd10478: LoadField: r3 = r1->field_57
    //     0xd10478: ldur            w3, [x1, #0x57]
    // 0xd1047c: DecompressPointer r3
    //     0xd1047c: add             x3, x3, HEAP, lsl #32
    // 0xd10480: LoadField: r1 = r3->field_7
    //     0xd10480: ldur            x1, [x3, #7]
    // 0xd10484: cmp             x1, #0
    // 0xd10488: b.le            #0xd10574
    // 0xd1048c: ldur            x1, [fp, #-0x10]
    // 0xd10490: r0 = of()
    //     0xd10490: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd10494: LoadField: r1 = r0->field_23
    //     0xd10494: ldur            w1, [x0, #0x23]
    // 0xd10498: DecompressPointer r1
    //     0xd10498: add             x1, x1, HEAP, lsl #32
    // 0xd1049c: LoadField: r0 = r1->field_7
    //     0xd1049c: ldur            x0, [x1, #7]
    // 0xd104a0: cmp             x0, #2
    // 0xd104a4: b.gt            #0xd104b8
    // 0xd104a8: cmp             x0, #1
    // 0xd104ac: b.gt            #0xd104d0
    // 0xd104b0: ldur            x0, [fp, #-8]
    // 0xd104b4: b               #0xd10570
    // 0xd104b8: cmp             x0, #4
    // 0xd104bc: b.gt            #0xd1056c
    // 0xd104c0: cmp             x0, #3
    // 0xd104c4: b.gt            #0xd104d0
    // 0xd104c8: ldur            x0, [fp, #-8]
    // 0xd104cc: b               #0xd10570
    // 0xd104d0: ldur            x0, [fp, #-8]
    // 0xd104d4: LoadField: r1 = r0->field_b
    //     0xd104d4: ldur            w1, [x0, #0xb]
    // 0xd104d8: DecompressPointer r1
    //     0xd104d8: add             x1, x1, HEAP, lsl #32
    // 0xd104dc: cmp             w1, NULL
    // 0xd104e0: b.eq            #0xd116c4
    // 0xd104e4: LoadField: r2 = r1->field_b
    //     0xd104e4: ldur            w2, [x1, #0xb]
    // 0xd104e8: DecompressPointer r2
    //     0xd104e8: add             x2, x2, HEAP, lsl #32
    // 0xd104ec: mov             x1, x0
    // 0xd104f0: stur            x2, [fp, #-0x20]
    // 0xd104f4: r0 = tristate()
    //     0xd104f4: bl              #0x11a19dc  ; [package:flutter/src/cupertino/checkbox.dart] _CupertinoCheckboxState::tristate
    // 0xd104f8: ldur            x1, [fp, #-8]
    // 0xd104fc: stur            x0, [fp, #-0x28]
    // 0xd10500: r0 = radioValue()
    //     0xd10500: bl              #0x12a071c  ; [package:flutter/src/widgets/raw_radio.dart] _RawRadioState::radioValue
    // 0xd10504: mov             x1, x0
    // 0xd10508: ldur            x0, [fp, #-8]
    // 0xd1050c: stur            x1, [fp, #-0x38]
    // 0xd10510: LoadField: r2 = r0->field_b
    //     0xd10510: ldur            w2, [x0, #0xb]
    // 0xd10514: DecompressPointer r2
    //     0xd10514: add             x2, x2, HEAP, lsl #32
    // 0xd10518: cmp             w2, NULL
    // 0xd1051c: b.eq            #0xd116c8
    // 0xd10520: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xd10520: ldur            w0, [x2, #0x17]
    // 0xd10524: DecompressPointer r0
    //     0xd10524: add             x0, x0, HEAP, lsl #32
    // 0xd10528: stur            x0, [fp, #-0x30]
    // 0xd1052c: r0 = CupertinoCheckbox()
    //     0xd1052c: bl              #0xd133b8  ; AllocateCupertinoCheckboxStub -> CupertinoCheckbox (size=0x44)
    // 0xd10530: mov             x1, x0
    // 0xd10534: ldur            x0, [fp, #-0x20]
    // 0xd10538: StoreField: r1->field_b = r0
    //     0xd10538: stur            w0, [x1, #0xb]
    // 0xd1053c: ldur            x0, [fp, #-0x28]
    // 0xd10540: StoreField: r1->field_23 = r0
    //     0xd10540: stur            w0, [x1, #0x23]
    // 0xd10544: ldur            x0, [fp, #-0x38]
    // 0xd10548: StoreField: r1->field_f = r0
    //     0xd10548: stur            w0, [x1, #0xf]
    // 0xd1054c: ldur            x0, [fp, #-0x30]
    // 0xd10550: ArrayStore: r1[0] = r0  ; List_4
    //     0xd10550: stur            w0, [x1, #0x17]
    // 0xd10554: r0 = false
    //     0xd10554: add             x0, NULL, #0x30  ; false
    // 0xd10558: StoreField: r1->field_2f = r0
    //     0xd10558: stur            w0, [x1, #0x2f]
    // 0xd1055c: mov             x0, x1
    // 0xd10560: LeaveFrame
    //     0xd10560: mov             SP, fp
    //     0xd10564: ldp             fp, lr, [SP], #0x10
    // 0xd10568: ret
    //     0xd10568: ret             
    // 0xd1056c: ldur            x0, [fp, #-8]
    // 0xd10570: ldur            x2, [fp, #-0x18]
    // 0xd10574: ldur            x1, [fp, #-0x10]
    // 0xd10578: r0 = of()
    //     0xd10578: bl              #0xd13360  ; [package:flutter/src/material/checkbox_theme.dart] CheckboxTheme::of
    // 0xd1057c: mov             x3, x0
    // 0xd10580: ldur            x2, [fp, #-0x18]
    // 0xd10584: stur            x3, [fp, #-0x20]
    // 0xd10588: StoreField: r2->field_13 = r0
    //     0xd10588: stur            w0, [x2, #0x13]
    //     0xd1058c: ldurb           w16, [x2, #-1]
    //     0xd10590: ldurb           w17, [x0, #-1]
    //     0xd10594: and             x16, x17, x16, lsr #2
    //     0xd10598: tst             x16, HEAP, lsr #32
    //     0xd1059c: b.eq            #0xd105a4
    //     0xd105a0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd105a4: ldur            x1, [fp, #-0x10]
    // 0xd105a8: r0 = of()
    //     0xd105a8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd105ac: LoadField: r1 = r0->field_2f
    //     0xd105ac: ldur            w1, [x0, #0x2f]
    // 0xd105b0: DecompressPointer r1
    //     0xd105b0: add             x1, x1, HEAP, lsl #32
    // 0xd105b4: tbnz            w1, #4, #0xd10614
    // 0xd105b8: ldur            x1, [fp, #-0x10]
    // 0xd105bc: r0 = of()
    //     0xd105bc: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd105c0: stur            x0, [fp, #-0x28]
    // 0xd105c4: r0 = _CheckboxDefaultsM3()
    //     0xd105c4: bl              #0xd13354  ; Allocate_CheckboxDefaultsM3Stub -> _CheckboxDefaultsM3 (size=0x34)
    // 0xd105c8: mov             x2, x0
    // 0xd105cc: ldur            x0, [fp, #-0x28]
    // 0xd105d0: stur            x2, [fp, #-0x30]
    // 0xd105d4: StoreField: r2->field_2b = r0
    //     0xd105d4: stur            w0, [x2, #0x2b]
    // 0xd105d8: ldur            x1, [fp, #-0x10]
    // 0xd105dc: r0 = of()
    //     0xd105dc: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd105e0: LoadField: r1 = r0->field_3f
    //     0xd105e0: ldur            w1, [x0, #0x3f]
    // 0xd105e4: DecompressPointer r1
    //     0xd105e4: add             x1, x1, HEAP, lsl #32
    // 0xd105e8: mov             x0, x1
    // 0xd105ec: ldur            x1, [fp, #-0x30]
    // 0xd105f0: StoreField: r1->field_2f = r0
    //     0xd105f0: stur            w0, [x1, #0x2f]
    //     0xd105f4: ldurb           w16, [x1, #-1]
    //     0xd105f8: ldurb           w17, [x0, #-1]
    //     0xd105fc: and             x16, x17, x16, lsr #2
    //     0xd10600: tst             x16, HEAP, lsr #32
    //     0xd10604: b.eq            #0xd1060c
    //     0xd10608: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd1060c: mov             x2, x1
    // 0xd10610: b               #0xd1066c
    // 0xd10614: ldur            x1, [fp, #-0x10]
    // 0xd10618: r0 = of()
    //     0xd10618: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd1061c: stur            x0, [fp, #-0x28]
    // 0xd10620: r0 = _CheckboxDefaultsM2()
    //     0xd10620: bl              #0xd13348  ; Allocate_CheckboxDefaultsM2Stub -> _CheckboxDefaultsM2 (size=0x34)
    // 0xd10624: mov             x2, x0
    // 0xd10628: ldur            x0, [fp, #-0x28]
    // 0xd1062c: stur            x2, [fp, #-0x30]
    // 0xd10630: StoreField: r2->field_2b = r0
    //     0xd10630: stur            w0, [x2, #0x2b]
    // 0xd10634: ldur            x1, [fp, #-0x10]
    // 0xd10638: r0 = of()
    //     0xd10638: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd1063c: LoadField: r1 = r0->field_3f
    //     0xd1063c: ldur            w1, [x0, #0x3f]
    // 0xd10640: DecompressPointer r1
    //     0xd10640: add             x1, x1, HEAP, lsl #32
    // 0xd10644: mov             x0, x1
    // 0xd10648: ldur            x1, [fp, #-0x30]
    // 0xd1064c: StoreField: r1->field_2f = r0
    //     0xd1064c: stur            w0, [x1, #0x2f]
    //     0xd10650: ldurb           w16, [x1, #-1]
    //     0xd10654: ldurb           w17, [x0, #-1]
    //     0xd10658: and             x16, x17, x16, lsr #2
    //     0xd1065c: tst             x16, HEAP, lsr #32
    //     0xd10660: b.eq            #0xd10668
    //     0xd10664: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd10668: mov             x2, x1
    // 0xd1066c: ldur            x0, [fp, #-8]
    // 0xd10670: stur            x2, [fp, #-0x28]
    // 0xd10674: LoadField: r1 = r0->field_b
    //     0xd10674: ldur            w1, [x0, #0xb]
    // 0xd10678: DecompressPointer r1
    //     0xd10678: add             x1, x1, HEAP, lsl #32
    // 0xd1067c: cmp             w1, NULL
    // 0xd10680: b.eq            #0xd116cc
    // 0xd10684: LoadField: r3 = r1->field_27
    //     0xd10684: ldur            w3, [x1, #0x27]
    // 0xd10688: DecompressPointer r3
    //     0xd10688: add             x3, x3, HEAP, lsl #32
    // 0xd1068c: cmp             w3, NULL
    // 0xd10690: b.ne            #0xd10698
    // 0xd10694: r3 = Null
    //     0xd10694: mov             x3, NULL
    // 0xd10698: cmp             w3, NULL
    // 0xd1069c: b.ne            #0xd106f8
    // 0xd106a0: r3 = LoadClassIdInstr(r2)
    //     0xd106a0: ldur            x3, [x2, #-1]
    //     0xd106a4: ubfx            x3, x3, #0xc, #0x14
    // 0xd106a8: r17 = 5173
    //     0xd106a8: mov             x17, #0x1435
    // 0xd106ac: cmp             x3, x17
    // 0xd106b0: b.ne            #0xd106c0
    // 0xd106b4: LoadField: r3 = r2->field_1b
    //     0xd106b4: ldur            w3, [x2, #0x1b]
    // 0xd106b8: DecompressPointer r3
    //     0xd106b8: add             x3, x3, HEAP, lsl #32
    // 0xd106bc: b               #0xd106f8
    // 0xd106c0: r17 = 5174
    //     0xd106c0: mov             x17, #0x1436
    // 0xd106c4: cmp             x3, x17
    // 0xd106c8: b.ne            #0xd106e4
    // 0xd106cc: LoadField: r3 = r2->field_2b
    //     0xd106cc: ldur            w3, [x2, #0x2b]
    // 0xd106d0: DecompressPointer r3
    //     0xd106d0: add             x3, x3, HEAP, lsl #32
    // 0xd106d4: LoadField: r4 = r3->field_1b
    //     0xd106d4: ldur            w4, [x3, #0x1b]
    // 0xd106d8: DecompressPointer r4
    //     0xd106d8: add             x4, x4, HEAP, lsl #32
    // 0xd106dc: mov             x3, x4
    // 0xd106e0: b               #0xd106f8
    // 0xd106e4: LoadField: r3 = r2->field_2b
    //     0xd106e4: ldur            w3, [x2, #0x2b]
    // 0xd106e8: DecompressPointer r3
    //     0xd106e8: add             x3, x3, HEAP, lsl #32
    // 0xd106ec: LoadField: r4 = r3->field_1b
    //     0xd106ec: ldur            w4, [x3, #0x1b]
    // 0xd106f0: DecompressPointer r4
    //     0xd106f0: add             x4, x4, HEAP, lsl #32
    // 0xd106f4: mov             x3, x4
    // 0xd106f8: LoadField: r4 = r1->field_2b
    //     0xd106f8: ldur            w4, [x1, #0x2b]
    // 0xd106fc: DecompressPointer r4
    //     0xd106fc: add             x4, x4, HEAP, lsl #32
    // 0xd10700: cmp             w4, NULL
    // 0xd10704: b.ne            #0xd10710
    // 0xd10708: r1 = Null
    //     0xd10708: mov             x1, NULL
    // 0xd1070c: b               #0xd10714
    // 0xd10710: mov             x1, x4
    // 0xd10714: cmp             w1, NULL
    // 0xd10718: b.ne            #0xd10768
    // 0xd1071c: r1 = LoadClassIdInstr(r2)
    //     0xd1071c: ldur            x1, [x2, #-1]
    //     0xd10720: ubfx            x1, x1, #0xc, #0x14
    // 0xd10724: r17 = 5173
    //     0xd10724: mov             x17, #0x1435
    // 0xd10728: cmp             x1, x17
    // 0xd1072c: b.ne            #0xd1073c
    // 0xd10730: LoadField: r1 = r2->field_1f
    //     0xd10730: ldur            w1, [x2, #0x1f]
    // 0xd10734: DecompressPointer r1
    //     0xd10734: add             x1, x1, HEAP, lsl #32
    // 0xd10738: b               #0xd10768
    // 0xd1073c: r17 = 5174
    //     0xd1073c: mov             x17, #0x1436
    // 0xd10740: cmp             x1, x17
    // 0xd10744: b.ne            #0xd10754
    // 0xd10748: r1 = Instance_VisualDensity
    //     0xd10748: add             x1, PP, #0x12, lsl #12  ; [pp+0x12ef0] Obj!VisualDensity@12b1d61
    //     0xd1074c: ldr             x1, [x1, #0xef0]
    // 0xd10750: b               #0xd10768
    // 0xd10754: LoadField: r1 = r2->field_2b
    //     0xd10754: ldur            w1, [x2, #0x2b]
    // 0xd10758: DecompressPointer r1
    //     0xd10758: add             x1, x1, HEAP, lsl #32
    // 0xd1075c: LoadField: r4 = r1->field_33
    //     0xd1075c: ldur            w4, [x1, #0x33]
    // 0xd10760: DecompressPointer r4
    //     0xd10760: add             x4, x4, HEAP, lsl #32
    // 0xd10764: mov             x1, x4
    // 0xd10768: LoadField: r4 = r3->field_7
    //     0xd10768: ldur            x4, [x3, #7]
    // 0xd1076c: cmp             x4, #0
    // 0xd10770: b.gt            #0xd10780
    // 0xd10774: r3 = Instance_Size
    //     0xd10774: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c588] Obj!Size@12a75d1
    //     0xd10778: ldr             x3, [x3, #0x588]
    // 0xd1077c: b               #0xd10788
    // 0xd10780: r3 = Instance_Size
    //     0xd10780: add             x3, PP, #0x90, lsl #12  ; [pp+0x90408] Obj!Size@12a75b1
    //     0xd10784: ldr             x3, [x3, #0x408]
    // 0xd10788: stur            x3, [fp, #-0x10]
    // 0xd1078c: r0 = baseSizeAdjustment()
    //     0xd1078c: bl              #0xb2496c  ; [package:flutter/src/material/theme_data.dart] VisualDensity::baseSizeAdjustment
    // 0xd10790: ldur            x1, [fp, #-0x10]
    // 0xd10794: mov             x2, x0
    // 0xd10798: r0 = +()
    //     0xd10798: bl              #0x81d158  ; [dart:ui] Size::+
    // 0xd1079c: ldur            x2, [fp, #-0x18]
    // 0xd107a0: r1 = Function '<anonymous closure>':.
    //     0xd107a0: add             x1, PP, #0x90, lsl #12  ; [pp+0x90410] AnonymousClosure: (0xd134a4), in [package:flutter/src/material/checkbox.dart] _CheckboxState::build (0xd10428)
    //     0xd107a4: ldr             x1, [x1, #0x410]
    // 0xd107a8: stur            x0, [fp, #-0x10]
    // 0xd107ac: r0 = AllocateClosure()
    //     0xd107ac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd107b0: r16 = <MouseCursor>
    //     0xd107b0: ldr             x16, [PP, #0x21a8]  ; [pp+0x21a8] TypeArguments: <MouseCursor>
    // 0xd107b4: stp             x0, x16, [SP]
    // 0xd107b8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd107b8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd107bc: r0 = resolveWith()
    //     0xd107bc: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd107c0: ldur            x1, [fp, #-8]
    // 0xd107c4: stur            x0, [fp, #-0x18]
    // 0xd107c8: r0 = states()
    //     0xd107c8: bl              #0x129f6f4  ; [dart:mixin_deduplication] _MixinApplication387&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0xd107cc: mov             x1, x0
    // 0xd107d0: r2 = Instance_WidgetState
    //     0xd107d0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd107d4: ldr             x2, [x2, #0x100]
    // 0xd107d8: stur            x0, [fp, #-0x30]
    // 0xd107dc: r0 = add()
    //     0xd107dc: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xd107e0: ldur            x1, [fp, #-8]
    // 0xd107e4: r0 = states()
    //     0xd107e4: bl              #0x129f6f4  ; [dart:mixin_deduplication] _MixinApplication387&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0xd107e8: mov             x1, x0
    // 0xd107ec: r2 = Instance_WidgetState
    //     0xd107ec: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd107f0: ldr             x2, [x2, #0x100]
    // 0xd107f4: stur            x0, [fp, #-0x38]
    // 0xd107f8: r0 = remove()
    //     0xd107f8: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0xd107fc: ldur            x1, [fp, #-8]
    // 0xd10800: LoadField: r0 = r1->field_b
    //     0xd10800: ldur            w0, [x1, #0xb]
    // 0xd10804: DecompressPointer r0
    //     0xd10804: add             x0, x0, HEAP, lsl #32
    // 0xd10808: cmp             w0, NULL
    // 0xd1080c: b.eq            #0xd116d0
    // 0xd10810: r1 = 1
    //     0xd10810: mov             x1, #1
    // 0xd10814: r0 = AllocateContext()
    //     0xd10814: bl              #0x13de838  ; AllocateContextStub
    // 0xd10818: mov             x1, x0
    // 0xd1081c: ldur            x0, [fp, #-8]
    // 0xd10820: StoreField: r1->field_f = r0
    //     0xd10820: stur            w0, [x1, #0xf]
    // 0xd10824: mov             x2, x1
    // 0xd10828: r1 = Function '<anonymous closure>':.
    //     0xd10828: add             x1, PP, #0x90, lsl #12  ; [pp+0x90418] AnonymousClosure: (0xd133c4), in [package:flutter/src/material/checkbox.dart] _CheckboxState::_widgetFillColor (0xd132e0)
    //     0xd1082c: ldr             x1, [x1, #0x418]
    // 0xd10830: r0 = AllocateClosure()
    //     0xd10830: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd10834: r16 = <Color?>
    //     0xd10834: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd10838: ldr             x16, [x16, #0xa40]
    // 0xd1083c: stp             x0, x16, [SP]
    // 0xd10840: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd10840: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd10844: r0 = resolveWith()
    //     0xd10844: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd10848: mov             x1, x0
    // 0xd1084c: ldur            x2, [fp, #-0x30]
    // 0xd10850: r0 = build()
    //     0xd10850: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd10854: cmp             w0, NULL
    // 0xd10858: b.ne            #0xd10860
    // 0xd1085c: r0 = Null
    //     0xd1085c: mov             x0, NULL
    // 0xd10860: stur            x0, [fp, #-0x40]
    // 0xd10864: cmp             w0, NULL
    // 0xd10868: b.ne            #0xd10938
    // 0xd1086c: ldur            x1, [fp, #-0x28]
    // 0xd10870: r2 = LoadClassIdInstr(r1)
    //     0xd10870: ldur            x2, [x1, #-1]
    //     0xd10874: ubfx            x2, x2, #0xc, #0x14
    // 0xd10878: r17 = 5173
    //     0xd10878: mov             x17, #0x1435
    // 0xd1087c: cmp             x2, x17
    // 0xd10880: b.ne            #0xd10894
    // 0xd10884: LoadField: r2 = r1->field_b
    //     0xd10884: ldur            w2, [x1, #0xb]
    // 0xd10888: DecompressPointer r2
    //     0xd10888: add             x2, x2, HEAP, lsl #32
    // 0xd1088c: mov             x1, x2
    // 0xd10890: b               #0xd10920
    // 0xd10894: r17 = 5174
    //     0xd10894: mov             x17, #0x1436
    // 0xd10898: cmp             x2, x17
    // 0xd1089c: b.ne            #0xd108e0
    // 0xd108a0: r1 = 1
    //     0xd108a0: mov             x1, #1
    // 0xd108a4: r0 = AllocateContext()
    //     0xd108a4: bl              #0x13de838  ; AllocateContextStub
    // 0xd108a8: mov             x1, x0
    // 0xd108ac: ldur            x0, [fp, #-0x28]
    // 0xd108b0: StoreField: r1->field_f = r0
    //     0xd108b0: stur            w0, [x1, #0xf]
    // 0xd108b4: mov             x2, x1
    // 0xd108b8: r1 = Function '<anonymous closure>':.
    //     0xd108b8: add             x1, PP, #0x26, lsl #12  ; [pp+0x264a8] AnonymousClosure: (0xd144a8), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0xd108bc: ldr             x1, [x1, #0x4a8]
    // 0xd108c0: r0 = AllocateClosure()
    //     0xd108c0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd108c4: r16 = <Color>
    //     0xd108c4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd108c8: ldr             x16, [x16, #0xa90]
    // 0xd108cc: stp             x0, x16, [SP]
    // 0xd108d0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd108d0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd108d4: r0 = resolveWith()
    //     0xd108d4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd108d8: mov             x1, x0
    // 0xd108dc: b               #0xd10920
    // 0xd108e0: mov             x0, x1
    // 0xd108e4: r1 = 1
    //     0xd108e4: mov             x1, #1
    // 0xd108e8: r0 = AllocateContext()
    //     0xd108e8: bl              #0x13de838  ; AllocateContextStub
    // 0xd108ec: mov             x1, x0
    // 0xd108f0: ldur            x0, [fp, #-0x28]
    // 0xd108f4: StoreField: r1->field_f = r0
    //     0xd108f4: stur            w0, [x1, #0xf]
    // 0xd108f8: mov             x2, x1
    // 0xd108fc: r1 = Function '<anonymous closure>':.
    //     0xd108fc: add             x1, PP, #0x26, lsl #12  ; [pp+0x264b0] AnonymousClosure: (0xd14374), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0xd10900: ldr             x1, [x1, #0x4b0]
    // 0xd10904: r0 = AllocateClosure()
    //     0xd10904: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd10908: r16 = <Color>
    //     0xd10908: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd1090c: ldr             x16, [x16, #0xa90]
    // 0xd10910: stp             x0, x16, [SP]
    // 0xd10914: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd10914: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd10918: r0 = resolveWith()
    //     0xd10918: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd1091c: mov             x1, x0
    // 0xd10920: ldur            x2, [fp, #-0x30]
    // 0xd10924: r0 = build()
    //     0xd10924: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd10928: cmp             w0, NULL
    // 0xd1092c: b.eq            #0xd116d4
    // 0xd10930: mov             x2, x0
    // 0xd10934: b               #0xd1093c
    // 0xd10938: ldur            x2, [fp, #-0x40]
    // 0xd1093c: ldur            x0, [fp, #-8]
    // 0xd10940: stur            x2, [fp, #-0x48]
    // 0xd10944: LoadField: r1 = r0->field_b
    //     0xd10944: ldur            w1, [x0, #0xb]
    // 0xd10948: DecompressPointer r1
    //     0xd10948: add             x1, x1, HEAP, lsl #32
    // 0xd1094c: cmp             w1, NULL
    // 0xd10950: b.eq            #0xd116d8
    // 0xd10954: mov             x1, x0
    // 0xd10958: r0 = _widgetFillColor()
    //     0xd10958: bl              #0xd132e0  ; [package:flutter/src/material/checkbox.dart] _CheckboxState::_widgetFillColor
    // 0xd1095c: mov             x1, x0
    // 0xd10960: ldur            x2, [fp, #-0x38]
    // 0xd10964: r0 = build()
    //     0xd10964: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd10968: cmp             w0, NULL
    // 0xd1096c: b.ne            #0xd10974
    // 0xd10970: r0 = Null
    //     0xd10970: mov             x0, NULL
    // 0xd10974: stur            x0, [fp, #-0x50]
    // 0xd10978: cmp             w0, NULL
    // 0xd1097c: b.ne            #0xd10a4c
    // 0xd10980: ldur            x1, [fp, #-0x28]
    // 0xd10984: r2 = LoadClassIdInstr(r1)
    //     0xd10984: ldur            x2, [x1, #-1]
    //     0xd10988: ubfx            x2, x2, #0xc, #0x14
    // 0xd1098c: r17 = 5173
    //     0xd1098c: mov             x17, #0x1435
    // 0xd10990: cmp             x2, x17
    // 0xd10994: b.ne            #0xd109a8
    // 0xd10998: LoadField: r2 = r1->field_b
    //     0xd10998: ldur            w2, [x1, #0xb]
    // 0xd1099c: DecompressPointer r2
    //     0xd1099c: add             x2, x2, HEAP, lsl #32
    // 0xd109a0: mov             x1, x2
    // 0xd109a4: b               #0xd10a34
    // 0xd109a8: r17 = 5174
    //     0xd109a8: mov             x17, #0x1436
    // 0xd109ac: cmp             x2, x17
    // 0xd109b0: b.ne            #0xd109f4
    // 0xd109b4: r1 = 1
    //     0xd109b4: mov             x1, #1
    // 0xd109b8: r0 = AllocateContext()
    //     0xd109b8: bl              #0x13de838  ; AllocateContextStub
    // 0xd109bc: mov             x1, x0
    // 0xd109c0: ldur            x0, [fp, #-0x28]
    // 0xd109c4: StoreField: r1->field_f = r0
    //     0xd109c4: stur            w0, [x1, #0xf]
    // 0xd109c8: mov             x2, x1
    // 0xd109cc: r1 = Function '<anonymous closure>':.
    //     0xd109cc: add             x1, PP, #0x26, lsl #12  ; [pp+0x264a8] AnonymousClosure: (0xd144a8), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0xd109d0: ldr             x1, [x1, #0x4a8]
    // 0xd109d4: r0 = AllocateClosure()
    //     0xd109d4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd109d8: r16 = <Color>
    //     0xd109d8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd109dc: ldr             x16, [x16, #0xa90]
    // 0xd109e0: stp             x0, x16, [SP]
    // 0xd109e4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd109e4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd109e8: r0 = resolveWith()
    //     0xd109e8: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd109ec: mov             x1, x0
    // 0xd109f0: b               #0xd10a34
    // 0xd109f4: mov             x0, x1
    // 0xd109f8: r1 = 1
    //     0xd109f8: mov             x1, #1
    // 0xd109fc: r0 = AllocateContext()
    //     0xd109fc: bl              #0x13de838  ; AllocateContextStub
    // 0xd10a00: mov             x1, x0
    // 0xd10a04: ldur            x0, [fp, #-0x28]
    // 0xd10a08: StoreField: r1->field_f = r0
    //     0xd10a08: stur            w0, [x1, #0xf]
    // 0xd10a0c: mov             x2, x1
    // 0xd10a10: r1 = Function '<anonymous closure>':.
    //     0xd10a10: add             x1, PP, #0x26, lsl #12  ; [pp+0x264b0] AnonymousClosure: (0xd14374), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0xd10a14: ldr             x1, [x1, #0x4b0]
    // 0xd10a18: r0 = AllocateClosure()
    //     0xd10a18: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd10a1c: r16 = <Color>
    //     0xd10a1c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd10a20: ldr             x16, [x16, #0xa90]
    // 0xd10a24: stp             x0, x16, [SP]
    // 0xd10a28: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd10a28: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd10a2c: r0 = resolveWith()
    //     0xd10a2c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd10a30: mov             x1, x0
    // 0xd10a34: ldur            x2, [fp, #-0x38]
    // 0xd10a38: r0 = build()
    //     0xd10a38: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd10a3c: cmp             w0, NULL
    // 0xd10a40: b.eq            #0xd116dc
    // 0xd10a44: mov             x4, x0
    // 0xd10a48: b               #0xd10a50
    // 0xd10a4c: ldur            x4, [fp, #-0x50]
    // 0xd10a50: ldur            x3, [fp, #-8]
    // 0xd10a54: ldur            x0, [fp, #-0x28]
    // 0xd10a58: stur            x4, [fp, #-0x58]
    // 0xd10a5c: LoadField: r1 = r3->field_b
    //     0xd10a5c: ldur            w1, [x3, #0xb]
    // 0xd10a60: DecompressPointer r1
    //     0xd10a60: add             x1, x1, HEAP, lsl #32
    // 0xd10a64: cmp             w1, NULL
    // 0xd10a68: b.eq            #0xd116e0
    // 0xd10a6c: ldur            x1, [fp, #-0x30]
    // 0xd10a70: r2 = Instance_WidgetState
    //     0xd10a70: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd10a74: ldr             x2, [x2, #0x100]
    // 0xd10a78: r0 = contains()
    //     0xd10a78: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xd10a7c: ldur            x1, [fp, #-0x30]
    // 0xd10a80: r2 = Instance_WidgetState
    //     0xd10a80: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd10a84: ldr             x2, [x2, #0x100]
    // 0xd10a88: r0 = contains()
    //     0xd10a88: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xd10a8c: ldur            x0, [fp, #-0x28]
    // 0xd10a90: r1 = LoadClassIdInstr(r0)
    //     0xd10a90: ldur            x1, [x0, #-1]
    //     0xd10a94: ubfx            x1, x1, #0xc, #0x14
    // 0xd10a98: stur            x1, [fp, #-0x60]
    // 0xd10a9c: r17 = 5173
    //     0xd10a9c: mov             x17, #0x1435
    // 0xd10aa0: cmp             x1, x17
    // 0xd10aa4: b.ne            #0xd10ad4
    // 0xd10aa8: LoadField: r2 = r0->field_27
    //     0xd10aa8: ldur            w2, [x0, #0x27]
    // 0xd10aac: DecompressPointer r2
    //     0xd10aac: add             x2, x2, HEAP, lsl #32
    // 0xd10ab0: mov             x4, x2
    // 0xd10ab4: mov             x0, x1
    // 0xd10ab8: r1 = Instance_Color
    //     0xd10ab8: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0xd10abc: ldr             x1, [x1, #0x948]
    // 0xd10ac0: r2 = Instance_BorderStyle
    //     0xd10ac0: add             x2, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd10ac4: ldr             x2, [x2, #0xdc8]
    // 0xd10ac8: d0 = 1.000000
    //     0xd10ac8: fmov            d0, #1.00000000
    // 0xd10acc: d1 = -1.000000
    //     0xd10acc: fmov            d1, #-1.00000000
    // 0xd10ad0: b               #0xd10bd4
    // 0xd10ad4: r17 = 5174
    //     0xd10ad4: mov             x17, #0x1436
    // 0xd10ad8: cmp             x1, x17
    // 0xd10adc: b.ne            #0xd10b50
    // 0xd10ae0: r1 = 1
    //     0xd10ae0: mov             x1, #1
    // 0xd10ae4: r0 = AllocateContext()
    //     0xd10ae4: bl              #0x13de838  ; AllocateContextStub
    // 0xd10ae8: mov             x1, x0
    // 0xd10aec: ldur            x0, [fp, #-0x28]
    // 0xd10af0: stur            x1, [fp, #-0x68]
    // 0xd10af4: StoreField: r1->field_f = r0
    //     0xd10af4: stur            w0, [x1, #0xf]
    // 0xd10af8: r0 = _WidgetStateBorderSide()
    //     0xd10af8: bl              #0xd132d4  ; Allocate_WidgetStateBorderSideStub -> _WidgetStateBorderSide (size=0x24)
    // 0xd10afc: ldur            x2, [fp, #-0x68]
    // 0xd10b00: r1 = Function '<anonymous closure>':.
    //     0xd10b00: add             x1, PP, #0x26, lsl #12  ; [pp+0x264e0] AnonymousClosure: (0xd13f0c), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0xd10b04: ldr             x1, [x1, #0x4e0]
    // 0xd10b08: stur            x0, [fp, #-0x68]
    // 0xd10b0c: r0 = AllocateClosure()
    //     0xd10b0c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd10b10: mov             x1, x0
    // 0xd10b14: ldur            x0, [fp, #-0x68]
    // 0xd10b18: StoreField: r0->field_1f = r1
    //     0xd10b18: stur            w1, [x0, #0x1f]
    // 0xd10b1c: r1 = Instance_Color
    //     0xd10b1c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0xd10b20: ldr             x1, [x1, #0x948]
    // 0xd10b24: StoreField: r0->field_7 = r1
    //     0xd10b24: stur            w1, [x0, #7]
    // 0xd10b28: d0 = 1.000000
    //     0xd10b28: fmov            d0, #1.00000000
    // 0xd10b2c: StoreField: r0->field_b = d0
    //     0xd10b2c: stur            d0, [x0, #0xb]
    // 0xd10b30: r2 = Instance_BorderStyle
    //     0xd10b30: add             x2, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd10b34: ldr             x2, [x2, #0xdc8]
    // 0xd10b38: StoreField: r0->field_13 = r2
    //     0xd10b38: stur            w2, [x0, #0x13]
    // 0xd10b3c: d1 = -1.000000
    //     0xd10b3c: fmov            d1, #-1.00000000
    // 0xd10b40: ArrayStore: r0[0] = d1  ; List_8
    //     0xd10b40: stur            d1, [x0, #0x17]
    // 0xd10b44: mov             x4, x0
    // 0xd10b48: ldur            x0, [fp, #-0x60]
    // 0xd10b4c: b               #0xd10bd4
    // 0xd10b50: r1 = Instance_Color
    //     0xd10b50: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0xd10b54: ldr             x1, [x1, #0x948]
    // 0xd10b58: r2 = Instance_BorderStyle
    //     0xd10b58: add             x2, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd10b5c: ldr             x2, [x2, #0xdc8]
    // 0xd10b60: d0 = 1.000000
    //     0xd10b60: fmov            d0, #1.00000000
    // 0xd10b64: d1 = -1.000000
    //     0xd10b64: fmov            d1, #-1.00000000
    // 0xd10b68: r1 = 1
    //     0xd10b68: mov             x1, #1
    // 0xd10b6c: r0 = AllocateContext()
    //     0xd10b6c: bl              #0x13de838  ; AllocateContextStub
    // 0xd10b70: mov             x1, x0
    // 0xd10b74: ldur            x0, [fp, #-0x28]
    // 0xd10b78: stur            x1, [fp, #-0x68]
    // 0xd10b7c: StoreField: r1->field_f = r0
    //     0xd10b7c: stur            w0, [x1, #0xf]
    // 0xd10b80: r0 = _WidgetStateBorderSide()
    //     0xd10b80: bl              #0xd132d4  ; Allocate_WidgetStateBorderSideStub -> _WidgetStateBorderSide (size=0x24)
    // 0xd10b84: ldur            x2, [fp, #-0x68]
    // 0xd10b88: r1 = Function '<anonymous closure>':.
    //     0xd10b88: add             x1, PP, #0x26, lsl #12  ; [pp+0x264e8] AnonymousClosure: (0xd13d68), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0xd10b8c: ldr             x1, [x1, #0x4e8]
    // 0xd10b90: stur            x0, [fp, #-0x68]
    // 0xd10b94: r0 = AllocateClosure()
    //     0xd10b94: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd10b98: mov             x1, x0
    // 0xd10b9c: ldur            x0, [fp, #-0x68]
    // 0xd10ba0: StoreField: r0->field_1f = r1
    //     0xd10ba0: stur            w1, [x0, #0x1f]
    // 0xd10ba4: r1 = Instance_Color
    //     0xd10ba4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0xd10ba8: ldr             x1, [x1, #0x948]
    // 0xd10bac: StoreField: r0->field_7 = r1
    //     0xd10bac: stur            w1, [x0, #7]
    // 0xd10bb0: d0 = 1.000000
    //     0xd10bb0: fmov            d0, #1.00000000
    // 0xd10bb4: StoreField: r0->field_b = d0
    //     0xd10bb4: stur            d0, [x0, #0xb]
    // 0xd10bb8: r2 = Instance_BorderStyle
    //     0xd10bb8: add             x2, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd10bbc: ldr             x2, [x2, #0xdc8]
    // 0xd10bc0: StoreField: r0->field_13 = r2
    //     0xd10bc0: stur            w2, [x0, #0x13]
    // 0xd10bc4: d1 = -1.000000
    //     0xd10bc4: fmov            d1, #-1.00000000
    // 0xd10bc8: ArrayStore: r0[0] = d1  ; List_8
    //     0xd10bc8: stur            d1, [x0, #0x17]
    // 0xd10bcc: mov             x4, x0
    // 0xd10bd0: ldur            x0, [fp, #-0x60]
    // 0xd10bd4: ldur            x3, [fp, #-8]
    // 0xd10bd8: r16 = <BorderSide?>
    //     0xd10bd8: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d4b0] TypeArguments: <BorderSide?>
    //     0xd10bdc: ldr             x16, [x16, #0x4b0]
    // 0xd10be0: stp             x4, x16, [SP, #8]
    // 0xd10be4: ldur            x16, [fp, #-0x30]
    // 0xd10be8: str             x16, [SP]
    // 0xd10bec: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd10bec: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd10bf0: r0 = resolveAs()
    //     0xd10bf0: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xd10bf4: stur            x0, [fp, #-0x68]
    // 0xd10bf8: cmp             w0, NULL
    // 0xd10bfc: b.eq            #0xd116e4
    // 0xd10c00: ldur            x3, [fp, #-8]
    // 0xd10c04: LoadField: r1 = r3->field_b
    //     0xd10c04: ldur            w1, [x3, #0xb]
    // 0xd10c08: DecompressPointer r1
    //     0xd10c08: add             x1, x1, HEAP, lsl #32
    // 0xd10c0c: cmp             w1, NULL
    // 0xd10c10: b.eq            #0xd116e8
    // 0xd10c14: ldur            x1, [fp, #-0x38]
    // 0xd10c18: r2 = Instance_WidgetState
    //     0xd10c18: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd10c1c: ldr             x2, [x2, #0x100]
    // 0xd10c20: r0 = contains()
    //     0xd10c20: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xd10c24: ldur            x1, [fp, #-0x38]
    // 0xd10c28: r2 = Instance_WidgetState
    //     0xd10c28: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd10c2c: ldr             x2, [x2, #0x100]
    // 0xd10c30: r0 = contains()
    //     0xd10c30: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xd10c34: ldur            x0, [fp, #-0x60]
    // 0xd10c38: r17 = 5173
    //     0xd10c38: mov             x17, #0x1435
    // 0xd10c3c: cmp             x0, x17
    // 0xd10c40: b.ne            #0xd10c54
    // 0xd10c44: ldur            x1, [fp, #-0x28]
    // 0xd10c48: LoadField: r2 = r1->field_27
    //     0xd10c48: ldur            w2, [x1, #0x27]
    // 0xd10c4c: DecompressPointer r2
    //     0xd10c4c: add             x2, x2, HEAP, lsl #32
    // 0xd10c50: b               #0xd10d5c
    // 0xd10c54: ldur            x1, [fp, #-0x28]
    // 0xd10c58: r17 = 5174
    //     0xd10c58: mov             x17, #0x1436
    // 0xd10c5c: cmp             x0, x17
    // 0xd10c60: b.ne            #0xd10cd4
    // 0xd10c64: r1 = 1
    //     0xd10c64: mov             x1, #1
    // 0xd10c68: r0 = AllocateContext()
    //     0xd10c68: bl              #0x13de838  ; AllocateContextStub
    // 0xd10c6c: mov             x1, x0
    // 0xd10c70: ldur            x0, [fp, #-0x28]
    // 0xd10c74: stur            x1, [fp, #-0x70]
    // 0xd10c78: StoreField: r1->field_f = r0
    //     0xd10c78: stur            w0, [x1, #0xf]
    // 0xd10c7c: r0 = _WidgetStateBorderSide()
    //     0xd10c7c: bl              #0xd132d4  ; Allocate_WidgetStateBorderSideStub -> _WidgetStateBorderSide (size=0x24)
    // 0xd10c80: ldur            x2, [fp, #-0x70]
    // 0xd10c84: r1 = Function '<anonymous closure>':.
    //     0xd10c84: add             x1, PP, #0x26, lsl #12  ; [pp+0x264e0] AnonymousClosure: (0xd13f0c), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0xd10c88: ldr             x1, [x1, #0x4e0]
    // 0xd10c8c: stur            x0, [fp, #-0x70]
    // 0xd10c90: r0 = AllocateClosure()
    //     0xd10c90: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd10c94: mov             x1, x0
    // 0xd10c98: ldur            x0, [fp, #-0x70]
    // 0xd10c9c: StoreField: r0->field_1f = r1
    //     0xd10c9c: stur            w1, [x0, #0x1f]
    // 0xd10ca0: r1 = Instance_Color
    //     0xd10ca0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0xd10ca4: ldr             x1, [x1, #0x948]
    // 0xd10ca8: StoreField: r0->field_7 = r1
    //     0xd10ca8: stur            w1, [x0, #7]
    // 0xd10cac: d0 = 1.000000
    //     0xd10cac: fmov            d0, #1.00000000
    // 0xd10cb0: StoreField: r0->field_b = d0
    //     0xd10cb0: stur            d0, [x0, #0xb]
    // 0xd10cb4: r2 = Instance_BorderStyle
    //     0xd10cb4: add             x2, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd10cb8: ldr             x2, [x2, #0xdc8]
    // 0xd10cbc: StoreField: r0->field_13 = r2
    //     0xd10cbc: stur            w2, [x0, #0x13]
    // 0xd10cc0: d1 = -1.000000
    //     0xd10cc0: fmov            d1, #-1.00000000
    // 0xd10cc4: ArrayStore: r0[0] = d1  ; List_8
    //     0xd10cc4: stur            d1, [x0, #0x17]
    // 0xd10cc8: mov             x2, x0
    // 0xd10ccc: ldur            x0, [fp, #-0x60]
    // 0xd10cd0: b               #0xd10d5c
    // 0xd10cd4: mov             x0, x1
    // 0xd10cd8: r1 = Instance_Color
    //     0xd10cd8: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0xd10cdc: ldr             x1, [x1, #0x948]
    // 0xd10ce0: r2 = Instance_BorderStyle
    //     0xd10ce0: add             x2, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd10ce4: ldr             x2, [x2, #0xdc8]
    // 0xd10ce8: d0 = 1.000000
    //     0xd10ce8: fmov            d0, #1.00000000
    // 0xd10cec: d1 = -1.000000
    //     0xd10cec: fmov            d1, #-1.00000000
    // 0xd10cf0: r1 = 1
    //     0xd10cf0: mov             x1, #1
    // 0xd10cf4: r0 = AllocateContext()
    //     0xd10cf4: bl              #0x13de838  ; AllocateContextStub
    // 0xd10cf8: mov             x1, x0
    // 0xd10cfc: ldur            x0, [fp, #-0x28]
    // 0xd10d00: stur            x1, [fp, #-0x70]
    // 0xd10d04: StoreField: r1->field_f = r0
    //     0xd10d04: stur            w0, [x1, #0xf]
    // 0xd10d08: r0 = _WidgetStateBorderSide()
    //     0xd10d08: bl              #0xd132d4  ; Allocate_WidgetStateBorderSideStub -> _WidgetStateBorderSide (size=0x24)
    // 0xd10d0c: ldur            x2, [fp, #-0x70]
    // 0xd10d10: r1 = Function '<anonymous closure>':.
    //     0xd10d10: add             x1, PP, #0x26, lsl #12  ; [pp+0x264e8] AnonymousClosure: (0xd13d68), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0xd10d14: ldr             x1, [x1, #0x4e8]
    // 0xd10d18: stur            x0, [fp, #-0x70]
    // 0xd10d1c: r0 = AllocateClosure()
    //     0xd10d1c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd10d20: mov             x1, x0
    // 0xd10d24: ldur            x0, [fp, #-0x70]
    // 0xd10d28: StoreField: r0->field_1f = r1
    //     0xd10d28: stur            w1, [x0, #0x1f]
    // 0xd10d2c: r1 = Instance_Color
    //     0xd10d2c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0xd10d30: ldr             x1, [x1, #0x948]
    // 0xd10d34: StoreField: r0->field_7 = r1
    //     0xd10d34: stur            w1, [x0, #7]
    // 0xd10d38: d0 = 1.000000
    //     0xd10d38: fmov            d0, #1.00000000
    // 0xd10d3c: StoreField: r0->field_b = d0
    //     0xd10d3c: stur            d0, [x0, #0xb]
    // 0xd10d40: r1 = Instance_BorderStyle
    //     0xd10d40: add             x1, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd10d44: ldr             x1, [x1, #0xdc8]
    // 0xd10d48: StoreField: r0->field_13 = r1
    //     0xd10d48: stur            w1, [x0, #0x13]
    // 0xd10d4c: d0 = -1.000000
    //     0xd10d4c: fmov            d0, #-1.00000000
    // 0xd10d50: ArrayStore: r0[0] = d0  ; List_8
    //     0xd10d50: stur            d0, [x0, #0x17]
    // 0xd10d54: mov             x2, x0
    // 0xd10d58: ldur            x0, [fp, #-0x60]
    // 0xd10d5c: ldur            x1, [fp, #-8]
    // 0xd10d60: r16 = <BorderSide?>
    //     0xd10d60: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d4b0] TypeArguments: <BorderSide?>
    //     0xd10d64: ldr             x16, [x16, #0x4b0]
    // 0xd10d68: stp             x2, x16, [SP, #8]
    // 0xd10d6c: ldur            x16, [fp, #-0x38]
    // 0xd10d70: str             x16, [SP]
    // 0xd10d74: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd10d74: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd10d78: r0 = resolveAs()
    //     0xd10d78: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xd10d7c: stur            x0, [fp, #-0x70]
    // 0xd10d80: cmp             w0, NULL
    // 0xd10d84: b.eq            #0xd116ec
    // 0xd10d88: ldur            x1, [fp, #-8]
    // 0xd10d8c: r0 = states()
    //     0xd10d8c: bl              #0x129f6f4  ; [dart:mixin_deduplication] _MixinApplication387&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0xd10d90: mov             x1, x0
    // 0xd10d94: r2 = Instance_WidgetState
    //     0xd10d94: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd10d98: ldr             x2, [x2, #0xa60]
    // 0xd10d9c: stur            x0, [fp, #-0x78]
    // 0xd10da0: r0 = add()
    //     0xd10da0: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xd10da4: ldur            x1, [fp, #-8]
    // 0xd10da8: LoadField: r0 = r1->field_b
    //     0xd10da8: ldur            w0, [x1, #0xb]
    // 0xd10dac: DecompressPointer r0
    //     0xd10dac: add             x0, x0, HEAP, lsl #32
    // 0xd10db0: cmp             w0, NULL
    // 0xd10db4: b.eq            #0xd116f0
    // 0xd10db8: ldur            x0, [fp, #-0x60]
    // 0xd10dbc: r17 = 5173
    //     0xd10dbc: mov             x17, #0x1435
    // 0xd10dc0: cmp             x0, x17
    // 0xd10dc4: b.ne            #0xd10df0
    // 0xd10dc8: ldur            x2, [fp, #-0x28]
    // 0xd10dcc: LoadField: r3 = r2->field_13
    //     0xd10dcc: ldur            w3, [x2, #0x13]
    // 0xd10dd0: DecompressPointer r3
    //     0xd10dd0: add             x3, x3, HEAP, lsl #32
    // 0xd10dd4: mov             x16, x0
    // 0xd10dd8: mov             x0, x3
    // 0xd10ddc: mov             x3, x16
    // 0xd10de0: mov             x16, x1
    // 0xd10de4: mov             x1, x0
    // 0xd10de8: mov             x0, x16
    // 0xd10dec: b               #0xd10e90
    // 0xd10df0: ldur            x2, [fp, #-0x28]
    // 0xd10df4: r17 = 5174
    //     0xd10df4: mov             x17, #0x1436
    // 0xd10df8: cmp             x0, x17
    // 0xd10dfc: b.ne            #0xd10e48
    // 0xd10e00: r1 = 1
    //     0xd10e00: mov             x1, #1
    // 0xd10e04: r0 = AllocateContext()
    //     0xd10e04: bl              #0x13de838  ; AllocateContextStub
    // 0xd10e08: mov             x1, x0
    // 0xd10e0c: ldur            x0, [fp, #-0x28]
    // 0xd10e10: StoreField: r1->field_f = r0
    //     0xd10e10: stur            w0, [x1, #0xf]
    // 0xd10e14: mov             x2, x1
    // 0xd10e18: r1 = Function '<anonymous closure>':.
    //     0xd10e18: add             x1, PP, #0x26, lsl #12  ; [pp+0x264c0] AnonymousClosure: (0xd13860), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0xd10e1c: ldr             x1, [x1, #0x4c0]
    // 0xd10e20: r0 = AllocateClosure()
    //     0xd10e20: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd10e24: r16 = <Color>
    //     0xd10e24: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd10e28: ldr             x16, [x16, #0xa90]
    // 0xd10e2c: stp             x0, x16, [SP]
    // 0xd10e30: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd10e30: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd10e34: r0 = resolveWith()
    //     0xd10e34: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd10e38: mov             x1, x0
    // 0xd10e3c: ldur            x0, [fp, #-8]
    // 0xd10e40: ldur            x3, [fp, #-0x60]
    // 0xd10e44: b               #0xd10e90
    // 0xd10e48: mov             x0, x2
    // 0xd10e4c: r1 = 1
    //     0xd10e4c: mov             x1, #1
    // 0xd10e50: r0 = AllocateContext()
    //     0xd10e50: bl              #0x13de838  ; AllocateContextStub
    // 0xd10e54: mov             x1, x0
    // 0xd10e58: ldur            x0, [fp, #-0x28]
    // 0xd10e5c: StoreField: r1->field_f = r0
    //     0xd10e5c: stur            w0, [x1, #0xf]
    // 0xd10e60: mov             x2, x1
    // 0xd10e64: r1 = Function '<anonymous closure>':.
    //     0xd10e64: add             x1, PP, #0x26, lsl #12  ; [pp+0x264c8] AnonymousClosure: (0xd136b4), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0xd10e68: ldr             x1, [x1, #0x4c8]
    // 0xd10e6c: r0 = AllocateClosure()
    //     0xd10e6c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd10e70: r16 = <Color?>
    //     0xd10e70: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd10e74: ldr             x16, [x16, #0xa40]
    // 0xd10e78: stp             x0, x16, [SP]
    // 0xd10e7c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd10e7c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd10e80: r0 = resolveWith()
    //     0xd10e80: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd10e84: mov             x1, x0
    // 0xd10e88: ldur            x0, [fp, #-8]
    // 0xd10e8c: ldur            x3, [fp, #-0x60]
    // 0xd10e90: ldur            x2, [fp, #-0x78]
    // 0xd10e94: r0 = build()
    //     0xd10e94: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd10e98: stur            x0, [fp, #-0x78]
    // 0xd10e9c: cmp             w0, NULL
    // 0xd10ea0: b.eq            #0xd116f4
    // 0xd10ea4: ldur            x1, [fp, #-8]
    // 0xd10ea8: r0 = states()
    //     0xd10ea8: bl              #0x129f6f4  ; [dart:mixin_deduplication] _MixinApplication387&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0xd10eac: mov             x1, x0
    // 0xd10eb0: r2 = Instance_WidgetState
    //     0xd10eb0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd10eb4: ldr             x2, [x2, #0xa50]
    // 0xd10eb8: stur            x0, [fp, #-0x80]
    // 0xd10ebc: r0 = add()
    //     0xd10ebc: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xd10ec0: ldur            x1, [fp, #-8]
    // 0xd10ec4: LoadField: r0 = r1->field_b
    //     0xd10ec4: ldur            w0, [x1, #0xb]
    // 0xd10ec8: DecompressPointer r0
    //     0xd10ec8: add             x0, x0, HEAP, lsl #32
    // 0xd10ecc: cmp             w0, NULL
    // 0xd10ed0: b.eq            #0xd116f8
    // 0xd10ed4: ldur            x0, [fp, #-0x60]
    // 0xd10ed8: r17 = 5173
    //     0xd10ed8: mov             x17, #0x1435
    // 0xd10edc: cmp             x0, x17
    // 0xd10ee0: b.ne            #0xd10efc
    // 0xd10ee4: ldur            x2, [fp, #-0x28]
    // 0xd10ee8: LoadField: r3 = r2->field_13
    //     0xd10ee8: ldur            w3, [x2, #0x13]
    // 0xd10eec: DecompressPointer r3
    //     0xd10eec: add             x3, x3, HEAP, lsl #32
    // 0xd10ef0: mov             x0, x1
    // 0xd10ef4: mov             x1, x3
    // 0xd10ef8: b               #0xd10f94
    // 0xd10efc: ldur            x2, [fp, #-0x28]
    // 0xd10f00: r17 = 5174
    //     0xd10f00: mov             x17, #0x1436
    // 0xd10f04: cmp             x0, x17
    // 0xd10f08: b.ne            #0xd10f50
    // 0xd10f0c: r1 = 1
    //     0xd10f0c: mov             x1, #1
    // 0xd10f10: r0 = AllocateContext()
    //     0xd10f10: bl              #0x13de838  ; AllocateContextStub
    // 0xd10f14: mov             x1, x0
    // 0xd10f18: ldur            x0, [fp, #-0x28]
    // 0xd10f1c: StoreField: r1->field_f = r0
    //     0xd10f1c: stur            w0, [x1, #0xf]
    // 0xd10f20: mov             x2, x1
    // 0xd10f24: r1 = Function '<anonymous closure>':.
    //     0xd10f24: add             x1, PP, #0x26, lsl #12  ; [pp+0x264c0] AnonymousClosure: (0xd13860), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0xd10f28: ldr             x1, [x1, #0x4c0]
    // 0xd10f2c: r0 = AllocateClosure()
    //     0xd10f2c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd10f30: r16 = <Color>
    //     0xd10f30: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd10f34: ldr             x16, [x16, #0xa90]
    // 0xd10f38: stp             x0, x16, [SP]
    // 0xd10f3c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd10f3c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd10f40: r0 = resolveWith()
    //     0xd10f40: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd10f44: mov             x1, x0
    // 0xd10f48: ldur            x0, [fp, #-8]
    // 0xd10f4c: b               #0xd10f94
    // 0xd10f50: mov             x0, x2
    // 0xd10f54: r1 = 1
    //     0xd10f54: mov             x1, #1
    // 0xd10f58: r0 = AllocateContext()
    //     0xd10f58: bl              #0x13de838  ; AllocateContextStub
    // 0xd10f5c: mov             x1, x0
    // 0xd10f60: ldur            x0, [fp, #-0x28]
    // 0xd10f64: StoreField: r1->field_f = r0
    //     0xd10f64: stur            w0, [x1, #0xf]
    // 0xd10f68: mov             x2, x1
    // 0xd10f6c: r1 = Function '<anonymous closure>':.
    //     0xd10f6c: add             x1, PP, #0x26, lsl #12  ; [pp+0x264c8] AnonymousClosure: (0xd136b4), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0xd10f70: ldr             x1, [x1, #0x4c8]
    // 0xd10f74: r0 = AllocateClosure()
    //     0xd10f74: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd10f78: r16 = <Color?>
    //     0xd10f78: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd10f7c: ldr             x16, [x16, #0xa40]
    // 0xd10f80: stp             x0, x16, [SP]
    // 0xd10f84: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd10f84: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd10f88: r0 = resolveWith()
    //     0xd10f88: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd10f8c: mov             x1, x0
    // 0xd10f90: ldur            x0, [fp, #-8]
    // 0xd10f94: ldur            x3, [fp, #-0x40]
    // 0xd10f98: ldur            x2, [fp, #-0x80]
    // 0xd10f9c: r0 = build()
    //     0xd10f9c: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd10fa0: stur            x0, [fp, #-0x80]
    // 0xd10fa4: cmp             w0, NULL
    // 0xd10fa8: b.eq            #0xd116fc
    // 0xd10fac: ldur            x1, [fp, #-0x30]
    // 0xd10fb0: r2 = Instance_WidgetState
    //     0xd10fb0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd10fb4: ldr             x2, [x2, #0xa48]
    // 0xd10fb8: r0 = add()
    //     0xd10fb8: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xd10fbc: ldur            x3, [fp, #-8]
    // 0xd10fc0: LoadField: r0 = r3->field_b
    //     0xd10fc0: ldur            w0, [x3, #0xb]
    // 0xd10fc4: DecompressPointer r0
    //     0xd10fc4: add             x0, x0, HEAP, lsl #32
    // 0xd10fc8: cmp             w0, NULL
    // 0xd10fcc: b.eq            #0xd11700
    // 0xd10fd0: ldur            x1, [fp, #-0x40]
    // 0xd10fd4: cmp             w1, NULL
    // 0xd10fd8: b.ne            #0xd10fe4
    // 0xd10fdc: r0 = Null
    //     0xd10fdc: mov             x0, NULL
    // 0xd10fe0: b               #0xd10ffc
    // 0xd10fe4: r0 = LoadClassIdInstr(r1)
    //     0xd10fe4: ldur            x0, [x1, #-1]
    //     0xd10fe8: ubfx            x0, x0, #0xc, #0x14
    // 0xd10fec: r2 = 31
    //     0xd10fec: mov             x2, #0x1f
    // 0xd10ff0: r0 = GDT[cid_x0 + -0xff4]()
    //     0xd10ff0: sub             lr, x0, #0xff4
    //     0xd10ff4: ldr             lr, [x21, lr, lsl #3]
    //     0xd10ff8: blr             lr
    // 0xd10ffc: cmp             w0, NULL
    // 0xd11000: b.ne            #0xd110d0
    // 0xd11004: ldur            x0, [fp, #-0x60]
    // 0xd11008: r17 = 5173
    //     0xd11008: mov             x17, #0x1435
    // 0xd1100c: cmp             x0, x17
    // 0xd11010: b.ne            #0xd11028
    // 0xd11014: ldur            x1, [fp, #-0x28]
    // 0xd11018: LoadField: r2 = r1->field_13
    //     0xd11018: ldur            w2, [x1, #0x13]
    // 0xd1101c: DecompressPointer r2
    //     0xd1101c: add             x2, x2, HEAP, lsl #32
    // 0xd11020: mov             x1, x2
    // 0xd11024: b               #0xd110b8
    // 0xd11028: ldur            x1, [fp, #-0x28]
    // 0xd1102c: r17 = 5174
    //     0xd1102c: mov             x17, #0x1436
    // 0xd11030: cmp             x0, x17
    // 0xd11034: b.ne            #0xd11078
    // 0xd11038: r1 = 1
    //     0xd11038: mov             x1, #1
    // 0xd1103c: r0 = AllocateContext()
    //     0xd1103c: bl              #0x13de838  ; AllocateContextStub
    // 0xd11040: mov             x1, x0
    // 0xd11044: ldur            x0, [fp, #-0x28]
    // 0xd11048: StoreField: r1->field_f = r0
    //     0xd11048: stur            w0, [x1, #0xf]
    // 0xd1104c: mov             x2, x1
    // 0xd11050: r1 = Function '<anonymous closure>':.
    //     0xd11050: add             x1, PP, #0x26, lsl #12  ; [pp+0x264c0] AnonymousClosure: (0xd13860), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0xd11054: ldr             x1, [x1, #0x4c0]
    // 0xd11058: r0 = AllocateClosure()
    //     0xd11058: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd1105c: r16 = <Color>
    //     0xd1105c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd11060: ldr             x16, [x16, #0xa90]
    // 0xd11064: stp             x0, x16, [SP]
    // 0xd11068: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd11068: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd1106c: r0 = resolveWith()
    //     0xd1106c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd11070: mov             x1, x0
    // 0xd11074: b               #0xd110b8
    // 0xd11078: mov             x0, x1
    // 0xd1107c: r1 = 1
    //     0xd1107c: mov             x1, #1
    // 0xd11080: r0 = AllocateContext()
    //     0xd11080: bl              #0x13de838  ; AllocateContextStub
    // 0xd11084: mov             x1, x0
    // 0xd11088: ldur            x0, [fp, #-0x28]
    // 0xd1108c: StoreField: r1->field_f = r0
    //     0xd1108c: stur            w0, [x1, #0xf]
    // 0xd11090: mov             x2, x1
    // 0xd11094: r1 = Function '<anonymous closure>':.
    //     0xd11094: add             x1, PP, #0x26, lsl #12  ; [pp+0x264c8] AnonymousClosure: (0xd136b4), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0xd11098: ldr             x1, [x1, #0x4c8]
    // 0xd1109c: r0 = AllocateClosure()
    //     0xd1109c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd110a0: r16 = <Color?>
    //     0xd110a0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd110a4: ldr             x16, [x16, #0xa40]
    // 0xd110a8: stp             x0, x16, [SP]
    // 0xd110ac: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd110ac: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd110b0: r0 = resolveWith()
    //     0xd110b0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd110b4: mov             x1, x0
    // 0xd110b8: ldur            x2, [fp, #-0x30]
    // 0xd110bc: r0 = build()
    //     0xd110bc: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd110c0: cmp             w0, NULL
    // 0xd110c4: b.eq            #0xd11704
    // 0xd110c8: mov             x4, x0
    // 0xd110cc: b               #0xd110d4
    // 0xd110d0: mov             x4, x0
    // 0xd110d4: ldur            x0, [fp, #-8]
    // 0xd110d8: ldur            x3, [fp, #-0x50]
    // 0xd110dc: ldur            x1, [fp, #-0x38]
    // 0xd110e0: stur            x4, [fp, #-0x30]
    // 0xd110e4: r2 = Instance_WidgetState
    //     0xd110e4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd110e8: ldr             x2, [x2, #0xa48]
    // 0xd110ec: r0 = add()
    //     0xd110ec: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xd110f0: ldur            x3, [fp, #-8]
    // 0xd110f4: LoadField: r0 = r3->field_b
    //     0xd110f4: ldur            w0, [x3, #0xb]
    // 0xd110f8: DecompressPointer r0
    //     0xd110f8: add             x0, x0, HEAP, lsl #32
    // 0xd110fc: cmp             w0, NULL
    // 0xd11100: b.eq            #0xd11708
    // 0xd11104: ldur            x1, [fp, #-0x50]
    // 0xd11108: cmp             w1, NULL
    // 0xd1110c: b.ne            #0xd11118
    // 0xd11110: r0 = Null
    //     0xd11110: mov             x0, NULL
    // 0xd11114: b               #0xd11130
    // 0xd11118: r0 = LoadClassIdInstr(r1)
    //     0xd11118: ldur            x0, [x1, #-1]
    //     0xd1111c: ubfx            x0, x0, #0xc, #0x14
    // 0xd11120: r2 = 31
    //     0xd11120: mov             x2, #0x1f
    // 0xd11124: r0 = GDT[cid_x0 + -0xff4]()
    //     0xd11124: sub             lr, x0, #0xff4
    //     0xd11128: ldr             lr, [x21, lr, lsl #3]
    //     0xd1112c: blr             lr
    // 0xd11130: cmp             w0, NULL
    // 0xd11134: b.ne            #0xd11204
    // 0xd11138: ldur            x0, [fp, #-0x60]
    // 0xd1113c: r17 = 5173
    //     0xd1113c: mov             x17, #0x1435
    // 0xd11140: cmp             x0, x17
    // 0xd11144: b.ne            #0xd1115c
    // 0xd11148: ldur            x1, [fp, #-0x28]
    // 0xd1114c: LoadField: r2 = r1->field_13
    //     0xd1114c: ldur            w2, [x1, #0x13]
    // 0xd11150: DecompressPointer r2
    //     0xd11150: add             x2, x2, HEAP, lsl #32
    // 0xd11154: mov             x1, x2
    // 0xd11158: b               #0xd111ec
    // 0xd1115c: ldur            x1, [fp, #-0x28]
    // 0xd11160: r17 = 5174
    //     0xd11160: mov             x17, #0x1436
    // 0xd11164: cmp             x0, x17
    // 0xd11168: b.ne            #0xd111ac
    // 0xd1116c: r1 = 1
    //     0xd1116c: mov             x1, #1
    // 0xd11170: r0 = AllocateContext()
    //     0xd11170: bl              #0x13de838  ; AllocateContextStub
    // 0xd11174: mov             x1, x0
    // 0xd11178: ldur            x0, [fp, #-0x28]
    // 0xd1117c: StoreField: r1->field_f = r0
    //     0xd1117c: stur            w0, [x1, #0xf]
    // 0xd11180: mov             x2, x1
    // 0xd11184: r1 = Function '<anonymous closure>':.
    //     0xd11184: add             x1, PP, #0x26, lsl #12  ; [pp+0x264c0] AnonymousClosure: (0xd13860), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0xd11188: ldr             x1, [x1, #0x4c0]
    // 0xd1118c: r0 = AllocateClosure()
    //     0xd1118c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd11190: r16 = <Color>
    //     0xd11190: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd11194: ldr             x16, [x16, #0xa90]
    // 0xd11198: stp             x0, x16, [SP]
    // 0xd1119c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd1119c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd111a0: r0 = resolveWith()
    //     0xd111a0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd111a4: mov             x1, x0
    // 0xd111a8: b               #0xd111ec
    // 0xd111ac: mov             x0, x1
    // 0xd111b0: r1 = 1
    //     0xd111b0: mov             x1, #1
    // 0xd111b4: r0 = AllocateContext()
    //     0xd111b4: bl              #0x13de838  ; AllocateContextStub
    // 0xd111b8: mov             x1, x0
    // 0xd111bc: ldur            x0, [fp, #-0x28]
    // 0xd111c0: StoreField: r1->field_f = r0
    //     0xd111c0: stur            w0, [x1, #0xf]
    // 0xd111c4: mov             x2, x1
    // 0xd111c8: r1 = Function '<anonymous closure>':.
    //     0xd111c8: add             x1, PP, #0x26, lsl #12  ; [pp+0x264c8] AnonymousClosure: (0xd136b4), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0xd111cc: ldr             x1, [x1, #0x4c8]
    // 0xd111d0: r0 = AllocateClosure()
    //     0xd111d0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd111d4: r16 = <Color?>
    //     0xd111d4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd111d8: ldr             x16, [x16, #0xa40]
    // 0xd111dc: stp             x0, x16, [SP]
    // 0xd111e0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd111e0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd111e4: r0 = resolveWith()
    //     0xd111e4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd111e8: mov             x1, x0
    // 0xd111ec: ldur            x2, [fp, #-0x38]
    // 0xd111f0: r0 = build()
    //     0xd111f0: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd111f4: cmp             w0, NULL
    // 0xd111f8: b.eq            #0xd1170c
    // 0xd111fc: mov             x2, x0
    // 0xd11200: b               #0xd11208
    // 0xd11204: mov             x2, x0
    // 0xd11208: ldur            x0, [fp, #-8]
    // 0xd1120c: stur            x2, [fp, #-0x38]
    // 0xd11210: LoadField: r1 = r0->field_43
    //     0xd11210: ldur            w1, [x0, #0x43]
    // 0xd11214: DecompressPointer r1
    //     0xd11214: add             x1, x1, HEAP, lsl #32
    // 0xd11218: cmp             w1, NULL
    // 0xd1121c: b.eq            #0xd11280
    // 0xd11220: mov             x1, x0
    // 0xd11224: r0 = states()
    //     0xd11224: bl              #0x129f6f4  ; [dart:mixin_deduplication] _MixinApplication387&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0xd11228: mov             x1, x0
    // 0xd1122c: r2 = Instance_WidgetState
    //     0xd1122c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd11230: ldr             x2, [x2, #0x100]
    // 0xd11234: r0 = contains()
    //     0xd11234: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xd11238: tbnz            w0, #4, #0xd11244
    // 0xd1123c: ldur            x0, [fp, #-0x30]
    // 0xd11240: b               #0xd11248
    // 0xd11244: ldur            x0, [fp, #-0x38]
    // 0xd11248: ldur            x1, [fp, #-8]
    // 0xd1124c: stur            x0, [fp, #-0x40]
    // 0xd11250: r0 = states()
    //     0xd11250: bl              #0x129f6f4  ; [dart:mixin_deduplication] _MixinApplication387&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0xd11254: mov             x1, x0
    // 0xd11258: r2 = Instance_WidgetState
    //     0xd11258: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd1125c: ldr             x2, [x2, #0x100]
    // 0xd11260: r0 = contains()
    //     0xd11260: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xd11264: tbnz            w0, #4, #0xd11270
    // 0xd11268: ldur            x0, [fp, #-0x30]
    // 0xd1126c: b               #0xd11274
    // 0xd11270: ldur            x0, [fp, #-0x38]
    // 0xd11274: mov             x4, x0
    // 0xd11278: ldur            x3, [fp, #-0x40]
    // 0xd1127c: b               #0xd11288
    // 0xd11280: ldur            x4, [fp, #-0x78]
    // 0xd11284: ldur            x3, [fp, #-0x80]
    // 0xd11288: ldur            x0, [fp, #-8]
    // 0xd1128c: ldur            x2, [fp, #-0x60]
    // 0xd11290: stur            x4, [fp, #-0x40]
    // 0xd11294: stur            x3, [fp, #-0x50]
    // 0xd11298: LoadField: r1 = r0->field_b
    //     0xd11298: ldur            w1, [x0, #0xb]
    // 0xd1129c: DecompressPointer r1
    //     0xd1129c: add             x1, x1, HEAP, lsl #32
    // 0xd112a0: cmp             w1, NULL
    // 0xd112a4: b.eq            #0xd11710
    // 0xd112a8: mov             x1, x0
    // 0xd112ac: r0 = states()
    //     0xd112ac: bl              #0x129f6f4  ; [dart:mixin_deduplication] _MixinApplication387&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0xd112b0: ldur            x1, [fp, #-8]
    // 0xd112b4: stur            x0, [fp, #-0x78]
    // 0xd112b8: LoadField: r2 = r1->field_b
    //     0xd112b8: ldur            w2, [x1, #0xb]
    // 0xd112bc: DecompressPointer r2
    //     0xd112bc: add             x2, x2, HEAP, lsl #32
    // 0xd112c0: cmp             w2, NULL
    // 0xd112c4: b.eq            #0xd11714
    // 0xd112c8: ldur            x2, [fp, #-0x60]
    // 0xd112cc: r17 = 5173
    //     0xd112cc: mov             x17, #0x1435
    // 0xd112d0: cmp             x2, x17
    // 0xd112d4: b.ne            #0xd112f0
    // 0xd112d8: ldur            x3, [fp, #-0x28]
    // 0xd112dc: LoadField: r4 = r3->field_f
    //     0xd112dc: ldur            w4, [x3, #0xf]
    // 0xd112e0: DecompressPointer r4
    //     0xd112e0: add             x4, x4, HEAP, lsl #32
    // 0xd112e4: mov             x3, x1
    // 0xd112e8: mov             x1, x4
    // 0xd112ec: b               #0xd11368
    // 0xd112f0: ldur            x3, [fp, #-0x28]
    // 0xd112f4: r17 = 5174
    //     0xd112f4: mov             x17, #0x1436
    // 0xd112f8: cmp             x2, x17
    // 0xd112fc: b.ne            #0xd11344
    // 0xd11300: r1 = 1
    //     0xd11300: mov             x1, #1
    // 0xd11304: r0 = AllocateContext()
    //     0xd11304: bl              #0x13de838  ; AllocateContextStub
    // 0xd11308: mov             x1, x0
    // 0xd1130c: ldur            x0, [fp, #-0x28]
    // 0xd11310: StoreField: r1->field_f = r0
    //     0xd11310: stur            w0, [x1, #0xf]
    // 0xd11314: mov             x2, x1
    // 0xd11318: r1 = Function '<anonymous closure>':.
    //     0xd11318: add             x1, PP, #0x26, lsl #12  ; [pp+0x264b8] AnonymousClosure: (0xd13524), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0xd1131c: ldr             x1, [x1, #0x4b8]
    // 0xd11320: r0 = AllocateClosure()
    //     0xd11320: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd11324: r16 = <Color>
    //     0xd11324: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd11328: ldr             x16, [x16, #0xa90]
    // 0xd1132c: stp             x0, x16, [SP]
    // 0xd11330: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd11330: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd11334: r0 = resolveWith()
    //     0xd11334: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd11338: mov             x1, x0
    // 0xd1133c: ldur            x3, [fp, #-8]
    // 0xd11340: b               #0xd11368
    // 0xd11344: r16 = <Color>
    //     0xd11344: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd11348: ldr             x16, [x16, #0xa90]
    // 0xd1134c: r30 = Instance_Color
    //     0xd1134c: add             lr, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xd11350: ldr             lr, [lr, #0xc38]
    // 0xd11354: stp             lr, x16, [SP]
    // 0xd11358: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd11358: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd1135c: r0 = all()
    //     0xd1135c: bl              #0xd13288  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::all
    // 0xd11360: mov             x1, x0
    // 0xd11364: ldur            x3, [fp, #-8]
    // 0xd11368: ldur            x4, [fp, #-0x20]
    // 0xd1136c: r0 = LoadClassIdInstr(r1)
    //     0xd1136c: ldur            x0, [x1, #-1]
    //     0xd11370: ubfx            x0, x0, #0xc, #0x14
    // 0xd11374: ldur            x2, [fp, #-0x78]
    // 0xd11378: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd11378: mov             x17, #0x7c77
    //     0xd1137c: movk            x17, #1, lsl #16
    //     0xd11380: add             lr, x0, x17
    //     0xd11384: ldr             lr, [x21, lr, lsl #3]
    //     0xd11388: blr             lr
    // 0xd1138c: stur            x0, [fp, #-0x90]
    // 0xd11390: cmp             w0, NULL
    // 0xd11394: b.eq            #0xd11718
    // 0xd11398: ldur            x3, [fp, #-8]
    // 0xd1139c: LoadField: r1 = r3->field_b
    //     0xd1139c: ldur            w1, [x3, #0xb]
    // 0xd113a0: DecompressPointer r1
    //     0xd113a0: add             x1, x1, HEAP, lsl #32
    // 0xd113a4: cmp             w1, NULL
    // 0xd113a8: b.eq            #0xd1171c
    // 0xd113ac: ldur            x2, [fp, #-0x20]
    // 0xd113b0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd113b0: ldur            w4, [x2, #0x17]
    // 0xd113b4: DecompressPointer r4
    //     0xd113b4: add             x4, x4, HEAP, lsl #32
    // 0xd113b8: cmp             w4, NULL
    // 0xd113bc: b.ne            #0xd1140c
    // 0xd113c0: ldur            x5, [fp, #-0x60]
    // 0xd113c4: r17 = 5173
    //     0xd113c4: mov             x17, #0x1435
    // 0xd113c8: cmp             x5, x17
    // 0xd113cc: b.ne            #0xd113e0
    // 0xd113d0: ldur            x6, [fp, #-0x28]
    // 0xd113d4: ArrayLoad: r2 = r6[0]  ; List_4
    //     0xd113d4: ldur            w2, [x6, #0x17]
    // 0xd113d8: DecompressPointer r2
    //     0xd113d8: add             x2, x2, HEAP, lsl #32
    // 0xd113dc: b               #0xd11404
    // 0xd113e0: ldur            x6, [fp, #-0x28]
    // 0xd113e4: r17 = 5174
    //     0xd113e4: mov             x17, #0x1436
    // 0xd113e8: cmp             x5, x17
    // 0xd113ec: b.ne            #0xd113fc
    // 0xd113f0: r2 = 20.000000
    //     0xd113f0: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1ae98] 20
    //     0xd113f4: ldr             x2, [x2, #0xe98]
    // 0xd113f8: b               #0xd11404
    // 0xd113fc: r2 = 20.000000
    //     0xd113fc: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1ae98] 20
    //     0xd11400: ldr             x2, [x2, #0xe98]
    // 0xd11404: mov             x4, x2
    // 0xd11408: b               #0xd11414
    // 0xd1140c: ldur            x6, [fp, #-0x28]
    // 0xd11410: ldur            x5, [fp, #-0x60]
    // 0xd11414: stur            x4, [fp, #-0x88]
    // 0xd11418: LoadField: r2 = r1->field_b
    //     0xd11418: ldur            w2, [x1, #0xb]
    // 0xd1141c: DecompressPointer r2
    //     0xd1141c: add             x2, x2, HEAP, lsl #32
    // 0xd11420: cmp             w2, NULL
    // 0xd11424: b.ne            #0xd11430
    // 0xd11428: r7 = false
    //     0xd11428: add             x7, NULL, #0x30  ; false
    // 0xd1142c: b               #0xd11434
    // 0xd11430: mov             x7, x2
    // 0xd11434: stur            x7, [fp, #-0x80]
    // 0xd11438: LoadField: r8 = r1->field_23
    //     0xd11438: ldur            w8, [x1, #0x23]
    // 0xd1143c: DecompressPointer r8
    //     0xd1143c: add             x8, x8, HEAP, lsl #32
    // 0xd11440: tbnz            w8, #4, #0xd1145c
    // 0xd11444: cmp             w2, NULL
    // 0xd11448: r16 = true
    //     0xd11448: add             x16, NULL, #0x20  ; true
    // 0xd1144c: r17 = false
    //     0xd1144c: add             x17, NULL, #0x30  ; false
    // 0xd11450: csel            x1, x16, x17, eq
    // 0xd11454: mov             x8, x1
    // 0xd11458: b               #0xd11460
    // 0xd1145c: r8 = Null
    //     0xd1145c: mov             x8, NULL
    // 0xd11460: stur            x8, [fp, #-0x78]
    // 0xd11464: LoadField: r10 = r3->field_4f
    //     0xd11464: ldur            w10, [x3, #0x4f]
    // 0xd11468: DecompressPointer r10
    //     0xd11468: add             x10, x10, HEAP, lsl #32
    // 0xd1146c: stur            x10, [fp, #-0x20]
    // 0xd11470: LoadField: r2 = r3->field_1f
    //     0xd11470: ldur            w2, [x3, #0x1f]
    // 0xd11474: DecompressPointer r2
    //     0xd11474: add             x2, x2, HEAP, lsl #32
    // 0xd11478: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd1147c: cmp             w2, w16
    // 0xd11480: b.eq            #0xd11720
    // 0xd11484: mov             x1, x10
    // 0xd11488: r0 = position=()
    //     0xd11488: bl              #0xd131b8  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::position=
    // 0xd1148c: ldur            x0, [fp, #-8]
    // 0xd11490: LoadField: r2 = r0->field_27
    //     0xd11490: ldur            w2, [x0, #0x27]
    // 0xd11494: DecompressPointer r2
    //     0xd11494: add             x2, x2, HEAP, lsl #32
    // 0xd11498: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd1149c: cmp             w2, w16
    // 0xd114a0: b.eq            #0xd1172c
    // 0xd114a4: ldur            x1, [fp, #-0x20]
    // 0xd114a8: r0 = reaction=()
    //     0xd114a8: bl              #0xd130e8  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::reaction=
    // 0xd114ac: ldur            x0, [fp, #-8]
    // 0xd114b0: LoadField: r2 = r0->field_33
    //     0xd114b0: ldur            w2, [x0, #0x33]
    // 0xd114b4: DecompressPointer r2
    //     0xd114b4: add             x2, x2, HEAP, lsl #32
    // 0xd114b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd114bc: cmp             w2, w16
    // 0xd114c0: b.eq            #0xd11738
    // 0xd114c4: ldur            x1, [fp, #-0x20]
    // 0xd114c8: r0 = reactionFocusFade=()
    //     0xd114c8: bl              #0xd13018  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::reactionFocusFade=
    // 0xd114cc: ldur            x0, [fp, #-8]
    // 0xd114d0: LoadField: r2 = r0->field_2b
    //     0xd114d0: ldur            w2, [x0, #0x2b]
    // 0xd114d4: DecompressPointer r2
    //     0xd114d4: add             x2, x2, HEAP, lsl #32
    // 0xd114d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd114dc: cmp             w2, w16
    // 0xd114e0: b.eq            #0xd11744
    // 0xd114e4: ldur            x1, [fp, #-0x20]
    // 0xd114e8: r0 = reactionHoverFade=()
    //     0xd114e8: bl              #0xd12f48  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::reactionHoverFade=
    // 0xd114ec: ldur            x1, [fp, #-0x20]
    // 0xd114f0: ldur            x2, [fp, #-0x38]
    // 0xd114f4: r0 = inactiveReactionColor=()
    //     0xd114f4: bl              #0xd12ea4  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::inactiveReactionColor=
    // 0xd114f8: ldur            x1, [fp, #-0x20]
    // 0xd114fc: ldur            x2, [fp, #-0x30]
    // 0xd11500: r0 = reactionColor=()
    //     0xd11500: bl              #0xd12e00  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::reactionColor=
    // 0xd11504: ldur            x1, [fp, #-0x20]
    // 0xd11508: ldur            x2, [fp, #-0x50]
    // 0xd1150c: r0 = hoverColor=()
    //     0xd1150c: bl              #0xd12d5c  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::hoverColor=
    // 0xd11510: ldur            x1, [fp, #-0x20]
    // 0xd11514: ldur            x2, [fp, #-0x40]
    // 0xd11518: r0 = focusColor=()
    //     0xd11518: bl              #0xd12cb8  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::focusColor=
    // 0xd1151c: ldur            x0, [fp, #-0x88]
    // 0xd11520: LoadField: d0 = r0->field_7
    //     0xd11520: ldur            d0, [x0, #7]
    // 0xd11524: ldur            x1, [fp, #-0x20]
    // 0xd11528: r0 = splashRadius=()
    //     0xd11528: bl              #0xd12bec  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::splashRadius=
    // 0xd1152c: ldur            x0, [fp, #-8]
    // 0xd11530: LoadField: r2 = r0->field_43
    //     0xd11530: ldur            w2, [x0, #0x43]
    // 0xd11534: DecompressPointer r2
    //     0xd11534: add             x2, x2, HEAP, lsl #32
    // 0xd11538: ldur            x1, [fp, #-0x20]
    // 0xd1153c: r0 = downPosition=()
    //     0xd1153c: bl              #0xd12b48  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::downPosition=
    // 0xd11540: ldur            x1, [fp, #-8]
    // 0xd11544: r0 = states()
    //     0xd11544: bl              #0x129f6f4  ; [dart:mixin_deduplication] _MixinApplication387&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0xd11548: mov             x1, x0
    // 0xd1154c: r2 = Instance_WidgetState
    //     0xd1154c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd11550: ldr             x2, [x2, #0xa60]
    // 0xd11554: r0 = contains()
    //     0xd11554: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xd11558: ldur            x1, [fp, #-0x20]
    // 0xd1155c: mov             x2, x0
    // 0xd11560: r0 = isFocused=()
    //     0xd11560: bl              #0xd12af4  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::isFocused=
    // 0xd11564: ldur            x1, [fp, #-8]
    // 0xd11568: r0 = states()
    //     0xd11568: bl              #0x129f6f4  ; [dart:mixin_deduplication] _MixinApplication387&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0xd1156c: mov             x1, x0
    // 0xd11570: r2 = Instance_WidgetState
    //     0xd11570: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd11574: ldr             x2, [x2, #0xa50]
    // 0xd11578: r0 = contains()
    //     0xd11578: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xd1157c: ldur            x1, [fp, #-0x20]
    // 0xd11580: mov             x2, x0
    // 0xd11584: r0 = isHovered=()
    //     0xd11584: bl              #0xd12aa0  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::isHovered=
    // 0xd11588: ldur            x1, [fp, #-0x20]
    // 0xd1158c: ldur            x2, [fp, #-0x48]
    // 0xd11590: r0 = activeColor=()
    //     0xd11590: bl              #0xd129fc  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::activeColor=
    // 0xd11594: ldur            x1, [fp, #-0x20]
    // 0xd11598: ldur            x2, [fp, #-0x58]
    // 0xd1159c: r0 = inactiveColor=()
    //     0xd1159c: bl              #0xcf0d78  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::inactiveColor=
    // 0xd115a0: ldur            x1, [fp, #-0x20]
    // 0xd115a4: ldur            x2, [fp, #-0x90]
    // 0xd115a8: r0 = checkColor=()
    //     0xd115a8: bl              #0xd12958  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::checkColor=
    // 0xd115ac: ldur            x1, [fp, #-8]
    // 0xd115b0: r0 = value()
    //     0xd115b0: bl              #0x11a0f58  ; [package:flutter/src/cupertino/checkbox.dart] _CupertinoCheckboxState::value
    // 0xd115b4: mov             x1, x0
    // 0xd115b8: ldur            x0, [fp, #-0x20]
    // 0xd115bc: LoadField: r2 = r0->field_63
    //     0xd115bc: ldur            w2, [x0, #0x63]
    // 0xd115c0: DecompressPointer r2
    //     0xd115c0: add             x2, x2, HEAP, lsl #32
    // 0xd115c4: cmp             w2, w1
    // 0xd115c8: b.eq            #0xd115d8
    // 0xd115cc: StoreField: r0->field_63 = r1
    //     0xd115cc: stur            w1, [x0, #0x63]
    // 0xd115d0: mov             x1, x0
    // 0xd115d4: r0 = notifyListeners()
    //     0xd115d4: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd115d8: ldur            x0, [fp, #-8]
    // 0xd115dc: ldur            x3, [fp, #-0x60]
    // 0xd115e0: LoadField: r2 = r0->field_53
    //     0xd115e0: ldur            w2, [x0, #0x53]
    // 0xd115e4: DecompressPointer r2
    //     0xd115e4: add             x2, x2, HEAP, lsl #32
    // 0xd115e8: ldur            x1, [fp, #-0x20]
    // 0xd115ec: r0 = previousValue=()
    //     0xd115ec: bl              #0xd12904  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::previousValue=
    // 0xd115f0: ldur            x0, [fp, #-8]
    // 0xd115f4: LoadField: r1 = r0->field_b
    //     0xd115f4: ldur            w1, [x0, #0xb]
    // 0xd115f8: DecompressPointer r1
    //     0xd115f8: add             x1, x1, HEAP, lsl #32
    // 0xd115fc: cmp             w1, NULL
    // 0xd11600: b.eq            #0xd11750
    // 0xd11604: ldur            x1, [fp, #-0x60]
    // 0xd11608: r17 = 5173
    //     0xd11608: mov             x17, #0x1435
    // 0xd1160c: cmp             x1, x17
    // 0xd11610: b.ne            #0xd11624
    // 0xd11614: ldur            x1, [fp, #-0x28]
    // 0xd11618: LoadField: r2 = r1->field_23
    //     0xd11618: ldur            w2, [x1, #0x23]
    // 0xd1161c: DecompressPointer r2
    //     0xd1161c: add             x2, x2, HEAP, lsl #32
    // 0xd11620: b               #0xd11644
    // 0xd11624: r17 = 5174
    //     0xd11624: mov             x17, #0x1436
    // 0xd11628: cmp             x1, x17
    // 0xd1162c: b.ne            #0xd1163c
    // 0xd11630: r2 = Instance_RoundedRectangleBorder
    //     0xd11630: add             x2, PP, #0x26, lsl #12  ; [pp+0x264d0] Obj!RoundedRectangleBorder@129ec61
    //     0xd11634: ldr             x2, [x2, #0x4d0]
    // 0xd11638: b               #0xd11644
    // 0xd1163c: r2 = Instance_RoundedRectangleBorder
    //     0xd1163c: add             x2, PP, #0x26, lsl #12  ; [pp+0x264d8] Obj!RoundedRectangleBorder@129ec51
    //     0xd11640: ldr             x2, [x2, #0x4d8]
    // 0xd11644: ldur            x1, [fp, #-0x20]
    // 0xd11648: r0 = shape=()
    //     0xd11648: bl              #0xd12860  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::shape=
    // 0xd1164c: ldur            x1, [fp, #-0x20]
    // 0xd11650: ldur            x2, [fp, #-0x68]
    // 0xd11654: r0 = activeSide=()
    //     0xd11654: bl              #0xd127bc  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::activeSide=
    // 0xd11658: ldur            x1, [fp, #-0x20]
    // 0xd1165c: ldur            x2, [fp, #-0x70]
    // 0xd11660: r0 = inactiveSide=()
    //     0xd11660: bl              #0xd12718  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::inactiveSide=
    // 0xd11664: ldur            x1, [fp, #-8]
    // 0xd11668: ldur            x2, [fp, #-0x18]
    // 0xd1166c: ldur            x3, [fp, #-0x20]
    // 0xd11670: ldur            x5, [fp, #-0x10]
    // 0xd11674: r0 = buildToggleable()
    //     0xd11674: bl              #0xd11798  ; [dart:mixin_deduplication] _MixinApplication26&State&TickerProviderStateMixin&ToggleableStateMixin::buildToggleable
    // 0xd11678: stur            x0, [fp, #-8]
    // 0xd1167c: r0 = Semantics()
    //     0xd1167c: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xd11680: stur            x0, [fp, #-0x10]
    // 0xd11684: ldur            x16, [fp, #-0x80]
    // 0xd11688: stp             x16, NULL, [SP, #0x10]
    // 0xd1168c: ldur            x16, [fp, #-0x78]
    // 0xd11690: ldur            lr, [fp, #-8]
    // 0xd11694: stp             lr, x16, [SP]
    // 0xd11698: mov             x1, x0
    // 0xd1169c: r4 = const [0, 0x5, 0x4, 0x1, checked, 0x2, child, 0x4, label, 0x1, mixed, 0x3, null]
    //     0xd1169c: add             x4, PP, #0x90, lsl #12  ; [pp+0x90420] List(13) [0, 0x5, 0x4, 0x1, "checked", 0x2, "child", 0x4, "label", 0x1, "mixed", 0x3, Null]
    //     0xd116a0: ldr             x4, [x4, #0x420]
    // 0xd116a4: r0 = Semantics()
    //     0xd116a4: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xd116a8: ldur            x0, [fp, #-0x10]
    // 0xd116ac: LeaveFrame
    //     0xd116ac: mov             SP, fp
    //     0xd116b0: ldp             fp, lr, [SP], #0x10
    // 0xd116b4: ret
    //     0xd116b4: ret             
    // 0xd116b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd116b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd116bc: b               #0xd10450
    // 0xd116c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd116c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd116c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd116c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd116c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd116c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd116cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd116cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd116d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd116d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd116d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd116d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd116d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd116d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd116dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd116dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd116e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd116e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd116e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd116e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd116e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd116e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd116ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd116ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd116f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd116f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd116f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd116f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd116f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd116f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd116fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd116fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd11700: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd11700: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd11704: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd11704: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd11708: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd11708: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1170c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1170c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd11710: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd11710: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd11714: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd11714: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd11718: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd11718: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1171c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1171c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd11720: r9 = _position
    //     0xd11720: add             x9, PP, #0x90, lsl #12  ; [pp+0x90428] Field <_MixinApplication26&State&TickerProviderStateMixin&ToggleableStateMixin@18353248._position@61045596>: late (offset: 0x20)
    //     0xd11724: ldr             x9, [x9, #0x428]
    // 0xd11728: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd11728: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd1172c: r9 = _reaction
    //     0xd1172c: add             x9, PP, #0x90, lsl #12  ; [pp+0x90430] Field <_MixinApplication26&State&TickerProviderStateMixin&ToggleableStateMixin@18353248._reaction@61045596>: late (offset: 0x28)
    //     0xd11730: ldr             x9, [x9, #0x430]
    // 0xd11734: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd11734: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd11738: r9 = _reactionFocusFade
    //     0xd11738: add             x9, PP, #0x90, lsl #12  ; [pp+0x90438] Field <_MixinApplication26&State&TickerProviderStateMixin&ToggleableStateMixin@18353248._reactionFocusFade@61045596>: late (offset: 0x34)
    //     0xd1173c: ldr             x9, [x9, #0x438]
    // 0xd11740: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd11740: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd11744: r9 = _reactionHoverFade
    //     0xd11744: add             x9, PP, #0x90, lsl #12  ; [pp+0x90440] Field <_MixinApplication26&State&TickerProviderStateMixin&ToggleableStateMixin@18353248._reactionHoverFade@61045596>: late (offset: 0x2c)
    //     0xd11748: ldr             x9, [x9, #0x440]
    // 0xd1174c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd1174c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd11750: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd11750: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  bool? dyn:get:value(_CheckboxState) {
    // ** addr: 0xd1176c, size: 0x44
    // 0xd1176c: ldr             x1, [SP]
    // 0xd11770: LoadField: r2 = r1->field_b
    //     0xd11770: ldur            w2, [x1, #0xb]
    // 0xd11774: DecompressPointer r2
    //     0xd11774: add             x2, x2, HEAP, lsl #32
    // 0xd11778: cmp             w2, NULL
    // 0xd1177c: b.eq            #0xd1178c
    // 0xd11780: LoadField: r0 = r2->field_b
    //     0xd11780: ldur            w0, [x2, #0xb]
    // 0xd11784: DecompressPointer r0
    //     0xd11784: add             x0, x0, HEAP, lsl #32
    // 0xd11788: ret
    //     0xd11788: ret             
    // 0xd1178c: EnterFrame
    //     0xd1178c: stp             fp, lr, [SP, #-0x10]!
    //     0xd11790: mov             fp, SP
    // 0xd11794: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd11794: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _widgetFillColor(/* No info */) {
    // ** addr: 0xd132e0, size: 0x68
    // 0xd132e0: EnterFrame
    //     0xd132e0: stp             fp, lr, [SP, #-0x10]!
    //     0xd132e4: mov             fp, SP
    // 0xd132e8: AllocStack(0x18)
    //     0xd132e8: sub             SP, SP, #0x18
    // 0xd132ec: SetupParameters(_CheckboxState this /* r1 => r1, fp-0x8 */)
    //     0xd132ec: stur            x1, [fp, #-8]
    // 0xd132f0: CheckStackOverflow
    //     0xd132f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd132f4: cmp             SP, x16
    //     0xd132f8: b.ls            #0xd13340
    // 0xd132fc: r1 = 1
    //     0xd132fc: mov             x1, #1
    // 0xd13300: r0 = AllocateContext()
    //     0xd13300: bl              #0x13de838  ; AllocateContextStub
    // 0xd13304: mov             x1, x0
    // 0xd13308: ldur            x0, [fp, #-8]
    // 0xd1330c: StoreField: r1->field_f = r0
    //     0xd1330c: stur            w0, [x1, #0xf]
    // 0xd13310: mov             x2, x1
    // 0xd13314: r1 = Function '<anonymous closure>':.
    //     0xd13314: add             x1, PP, #0x90, lsl #12  ; [pp+0x90418] AnonymousClosure: (0xd133c4), in [package:flutter/src/material/checkbox.dart] _CheckboxState::_widgetFillColor (0xd132e0)
    //     0xd13318: ldr             x1, [x1, #0x418]
    // 0xd1331c: r0 = AllocateClosure()
    //     0xd1331c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd13320: r16 = <Color?>
    //     0xd13320: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd13324: ldr             x16, [x16, #0xa40]
    // 0xd13328: stp             x0, x16, [SP]
    // 0xd1332c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd1332c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd13330: r0 = resolveWith()
    //     0xd13330: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd13334: LeaveFrame
    //     0xd13334: mov             SP, fp
    //     0xd13338: ldp             fp, lr, [SP], #0x10
    // 0xd1333c: ret
    //     0xd1333c: ret             
    // 0xd13340: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd13340: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd13344: b               #0xd132fc
  }
  [closure] Color? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd133c4, size: 0xe0
    // 0xd133c4: EnterFrame
    //     0xd133c4: stp             fp, lr, [SP, #-0x10]!
    //     0xd133c8: mov             fp, SP
    // 0xd133cc: AllocStack(0x8)
    //     0xd133cc: sub             SP, SP, #8
    // 0xd133d0: SetupParameters([dynamic _ /* r0 */])
    //     0xd133d0: ldr             x0, [fp, #0x18]
    //     0xd133d4: ldur            w3, [x0, #0x17]
    //     0xd133d8: add             x3, x3, HEAP, lsl #32
    //     0xd133dc: stur            x3, [fp, #-8]
    // 0xd133e0: CheckStackOverflow
    //     0xd133e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd133e4: cmp             SP, x16
    //     0xd133e8: b.ls            #0xd13498
    // 0xd133ec: ldr             x4, [fp, #0x10]
    // 0xd133f0: r0 = LoadClassIdInstr(r4)
    //     0xd133f0: ldur            x0, [x4, #-1]
    //     0xd133f4: ubfx            x0, x0, #0xc, #0x14
    // 0xd133f8: mov             x1, x4
    // 0xd133fc: r2 = Instance_WidgetState
    //     0xd133fc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd13400: ldr             x2, [x2, #0xa70]
    // 0xd13404: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd13404: mov             x17, #0x2929
    //     0xd13408: movk            x17, #1, lsl #16
    //     0xd1340c: add             lr, x0, x17
    //     0xd13410: ldr             lr, [x21, lr, lsl #3]
    //     0xd13414: blr             lr
    // 0xd13418: tbnz            w0, #4, #0xd1342c
    // 0xd1341c: r0 = Null
    //     0xd1341c: mov             x0, NULL
    // 0xd13420: LeaveFrame
    //     0xd13420: mov             SP, fp
    //     0xd13424: ldp             fp, lr, [SP], #0x10
    // 0xd13428: ret
    //     0xd13428: ret             
    // 0xd1342c: ldr             x1, [fp, #0x10]
    // 0xd13430: r0 = LoadClassIdInstr(r1)
    //     0xd13430: ldur            x0, [x1, #-1]
    //     0xd13434: ubfx            x0, x0, #0xc, #0x14
    // 0xd13438: r2 = Instance_WidgetState
    //     0xd13438: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd1343c: ldr             x2, [x2, #0x100]
    // 0xd13440: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd13440: mov             x17, #0x2929
    //     0xd13444: movk            x17, #1, lsl #16
    //     0xd13448: add             lr, x0, x17
    //     0xd1344c: ldr             lr, [x21, lr, lsl #3]
    //     0xd13450: blr             lr
    // 0xd13454: tbnz            w0, #4, #0xd13488
    // 0xd13458: ldur            x1, [fp, #-8]
    // 0xd1345c: LoadField: r2 = r1->field_f
    //     0xd1345c: ldur            w2, [x1, #0xf]
    // 0xd13460: DecompressPointer r2
    //     0xd13460: add             x2, x2, HEAP, lsl #32
    // 0xd13464: LoadField: r1 = r2->field_b
    //     0xd13464: ldur            w1, [x2, #0xb]
    // 0xd13468: DecompressPointer r1
    //     0xd13468: add             x1, x1, HEAP, lsl #32
    // 0xd1346c: cmp             w1, NULL
    // 0xd13470: b.eq            #0xd134a0
    // 0xd13474: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xd13474: ldur            w0, [x1, #0x17]
    // 0xd13478: DecompressPointer r0
    //     0xd13478: add             x0, x0, HEAP, lsl #32
    // 0xd1347c: LeaveFrame
    //     0xd1347c: mov             SP, fp
    //     0xd13480: ldp             fp, lr, [SP], #0x10
    // 0xd13484: ret
    //     0xd13484: ret             
    // 0xd13488: r0 = Null
    //     0xd13488: mov             x0, NULL
    // 0xd1348c: LeaveFrame
    //     0xd1348c: mov             SP, fp
    //     0xd13490: ldp             fp, lr, [SP], #0x10
    // 0xd13494: ret
    //     0xd13494: ret             
    // 0xd13498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd13498: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1349c: b               #0xd133ec
    // 0xd134a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd134a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] MouseCursor <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd134a4, size: 0x80
    // 0xd134a4: EnterFrame
    //     0xd134a4: stp             fp, lr, [SP, #-0x10]!
    //     0xd134a8: mov             fp, SP
    // 0xd134ac: AllocStack(0x18)
    //     0xd134ac: sub             SP, SP, #0x18
    // 0xd134b0: SetupParameters([dynamic _ /* r0 */])
    //     0xd134b0: ldr             x0, [fp, #0x18]
    //     0xd134b4: ldur            w1, [x0, #0x17]
    //     0xd134b8: add             x1, x1, HEAP, lsl #32
    // 0xd134bc: CheckStackOverflow
    //     0xd134bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd134c0: cmp             SP, x16
    //     0xd134c4: b.ls            #0xd13518
    // 0xd134c8: LoadField: r0 = r1->field_f
    //     0xd134c8: ldur            w0, [x1, #0xf]
    // 0xd134cc: DecompressPointer r0
    //     0xd134cc: add             x0, x0, HEAP, lsl #32
    // 0xd134d0: LoadField: r1 = r0->field_b
    //     0xd134d0: ldur            w1, [x0, #0xb]
    // 0xd134d4: DecompressPointer r1
    //     0xd134d4: add             x1, x1, HEAP, lsl #32
    // 0xd134d8: cmp             w1, NULL
    // 0xd134dc: b.eq            #0xd13520
    // 0xd134e0: r16 = <MouseCursor?>
    //     0xd134e0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ab8] TypeArguments: <MouseCursor?>
    //     0xd134e4: ldr             x16, [x16, #0xab8]
    // 0xd134e8: stp             NULL, x16, [SP, #8]
    // 0xd134ec: ldr             x16, [fp, #0x10]
    // 0xd134f0: str             x16, [SP]
    // 0xd134f4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd134f4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd134f8: r0 = resolveAs()
    //     0xd134f8: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xd134fc: ldr             x2, [fp, #0x10]
    // 0xd13500: r1 = Instance__WidgetStateMouseCursor
    //     0xd13500: add             x1, PP, #0x80, lsl #12  ; [pp+0x80c18] Obj!_WidgetStateMouseCursor@12b3251
    //     0xd13504: ldr             x1, [x1, #0xc18]
    // 0xd13508: r0 = resolve()
    //     0xd13508: bl              #0x8de794  ; [package:flutter/src/widgets/widget_state.dart] _WidgetStateMouseCursor::resolve
    // 0xd1350c: LeaveFrame
    //     0xd1350c: mov             SP, fp
    //     0xd13510: ldp             fp, lr, [SP], #0x10
    // 0xd13514: ret
    //     0xd13514: ret             
    // 0xd13518: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd13518: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1351c: b               #0xd134c8
    // 0xd13520: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd13520: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf37bb0, size: 0xf8
    // 0xf37bb0: EnterFrame
    //     0xf37bb0: stp             fp, lr, [SP, #-0x10]!
    //     0xf37bb4: mov             fp, SP
    // 0xf37bb8: AllocStack(0x10)
    //     0xf37bb8: sub             SP, SP, #0x10
    // 0xf37bbc: SetupParameters(_CheckboxState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf37bbc: mov             x4, x1
    //     0xf37bc0: mov             x3, x2
    //     0xf37bc4: stur            x1, [fp, #-8]
    //     0xf37bc8: stur            x2, [fp, #-0x10]
    // 0xf37bcc: CheckStackOverflow
    //     0xf37bcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf37bd0: cmp             SP, x16
    //     0xf37bd4: b.ls            #0xf37c9c
    // 0xf37bd8: mov             x0, x3
    // 0xf37bdc: r2 = Null
    //     0xf37bdc: mov             x2, NULL
    // 0xf37be0: r1 = Null
    //     0xf37be0: mov             x1, NULL
    // 0xf37be4: r4 = 60
    //     0xf37be4: mov             x4, #0x3c
    // 0xf37be8: branchIfSmi(r0, 0xf37bf4)
    //     0xf37be8: tbz             w0, #0, #0xf37bf4
    // 0xf37bec: r4 = LoadClassIdInstr(r0)
    //     0xf37bec: ldur            x4, [x0, #-1]
    //     0xf37bf0: ubfx            x4, x4, #0xc, #0x14
    // 0xf37bf4: r17 = 6487
    //     0xf37bf4: mov             x17, #0x1957
    // 0xf37bf8: cmp             x4, x17
    // 0xf37bfc: b.eq            #0xf37c14
    // 0xf37c00: r8 = Checkbox
    //     0xf37c00: add             x8, PP, #0x90, lsl #12  ; [pp+0x904e8] Type: Checkbox
    //     0xf37c04: ldr             x8, [x8, #0x4e8]
    // 0xf37c08: r3 = Null
    //     0xf37c08: add             x3, PP, #0x90, lsl #12  ; [pp+0x904f0] Null
    //     0xf37c0c: ldr             x3, [x3, #0x4f0]
    // 0xf37c10: r0 = Checkbox()
    //     0xf37c10: bl              #0xacde28  ; IsType_Checkbox_Stub
    // 0xf37c14: ldur            x3, [fp, #-8]
    // 0xf37c18: LoadField: r2 = r3->field_7
    //     0xf37c18: ldur            w2, [x3, #7]
    // 0xf37c1c: DecompressPointer r2
    //     0xf37c1c: add             x2, x2, HEAP, lsl #32
    // 0xf37c20: ldur            x0, [fp, #-0x10]
    // 0xf37c24: r1 = Null
    //     0xf37c24: mov             x1, NULL
    // 0xf37c28: cmp             w2, NULL
    // 0xf37c2c: b.eq            #0xf37c50
    // 0xf37c30: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf37c30: ldur            w4, [x2, #0x17]
    // 0xf37c34: DecompressPointer r4
    //     0xf37c34: add             x4, x4, HEAP, lsl #32
    // 0xf37c38: r8 = X0 bound StatefulWidget
    //     0xf37c38: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf37c3c: ldr             x8, [x8, #0x498]
    // 0xf37c40: LoadField: r9 = r4->field_7
    //     0xf37c40: ldur            x9, [x4, #7]
    // 0xf37c44: r3 = Null
    //     0xf37c44: add             x3, PP, #0x90, lsl #12  ; [pp+0x90500] Null
    //     0xf37c48: ldr             x3, [x3, #0x500]
    // 0xf37c4c: blr             x9
    // 0xf37c50: ldur            x0, [fp, #-0x10]
    // 0xf37c54: LoadField: r1 = r0->field_b
    //     0xf37c54: ldur            w1, [x0, #0xb]
    // 0xf37c58: DecompressPointer r1
    //     0xf37c58: add             x1, x1, HEAP, lsl #32
    // 0xf37c5c: ldur            x0, [fp, #-8]
    // 0xf37c60: LoadField: r2 = r0->field_b
    //     0xf37c60: ldur            w2, [x0, #0xb]
    // 0xf37c64: DecompressPointer r2
    //     0xf37c64: add             x2, x2, HEAP, lsl #32
    // 0xf37c68: cmp             w2, NULL
    // 0xf37c6c: b.eq            #0xf37ca4
    // 0xf37c70: LoadField: r3 = r2->field_b
    //     0xf37c70: ldur            w3, [x2, #0xb]
    // 0xf37c74: DecompressPointer r3
    //     0xf37c74: add             x3, x3, HEAP, lsl #32
    // 0xf37c78: cmp             w1, w3
    // 0xf37c7c: b.eq            #0xf37c8c
    // 0xf37c80: StoreField: r0->field_53 = r1
    //     0xf37c80: stur            w1, [x0, #0x53]
    // 0xf37c84: mov             x1, x0
    // 0xf37c88: r0 = animateToValue()
    //     0xf37c88: bl              #0xf37ca8  ; [dart:mixin_deduplication] _MixinApplication26&State&TickerProviderStateMixin&ToggleableStateMixin::animateToValue
    // 0xf37c8c: r0 = Null
    //     0xf37c8c: mov             x0, NULL
    // 0xf37c90: LeaveFrame
    //     0xf37c90: mov             SP, fp
    //     0xf37c94: ldp             fp, lr, [SP], #0x10
    // 0xf37c98: ret
    //     0xf37c98: ret             
    // 0xf37c9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf37c9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf37ca0: b               #0xf37bd8
    // 0xf37ca4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf37ca4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf79328, size: 0x64
    // 0xf79328: EnterFrame
    //     0xf79328: stp             fp, lr, [SP, #-0x10]!
    //     0xf7932c: mov             fp, SP
    // 0xf79330: AllocStack(0x8)
    //     0xf79330: sub             SP, SP, #8
    // 0xf79334: SetupParameters(_CheckboxState this /* r1 => r0, fp-0x8 */)
    //     0xf79334: mov             x0, x1
    //     0xf79338: stur            x1, [fp, #-8]
    // 0xf7933c: CheckStackOverflow
    //     0xf7933c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf79340: cmp             SP, x16
    //     0xf79344: b.ls            #0xf79380
    // 0xf79348: mov             x1, x0
    // 0xf7934c: r0 = initState()
    //     0xf7934c: bl              #0xf7938c  ; [dart:mixin_deduplication] _MixinApplication26&State&TickerProviderStateMixin&ToggleableStateMixin::initState
    // 0xf79350: ldur            x1, [fp, #-8]
    // 0xf79354: LoadField: r2 = r1->field_b
    //     0xf79354: ldur            w2, [x1, #0xb]
    // 0xf79358: DecompressPointer r2
    //     0xf79358: add             x2, x2, HEAP, lsl #32
    // 0xf7935c: cmp             w2, NULL
    // 0xf79360: b.eq            #0xf79388
    // 0xf79364: LoadField: r3 = r2->field_b
    //     0xf79364: ldur            w3, [x2, #0xb]
    // 0xf79368: DecompressPointer r3
    //     0xf79368: add             x3, x3, HEAP, lsl #32
    // 0xf7936c: StoreField: r1->field_53 = r3
    //     0xf7936c: stur            w3, [x1, #0x53]
    // 0xf79370: r0 = Null
    //     0xf79370: mov             x0, NULL
    // 0xf79374: LeaveFrame
    //     0xf79374: mov             SP, fp
    //     0xf79378: ldp             fp, lr, [SP], #0x10
    // 0xf7937c: ret
    //     0xf7937c: ret             
    // 0xf79380: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf79380: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf79384: b               #0xf79348
    // 0xf79388: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf79388: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _CheckboxState(/* No info */) {
    // ** addr: 0xfa11a0, size: 0x94
    // 0xfa11a0: EnterFrame
    //     0xfa11a0: stp             fp, lr, [SP, #-0x10]!
    //     0xfa11a4: mov             fp, SP
    // 0xfa11a8: AllocStack(0x10)
    //     0xfa11a8: sub             SP, SP, #0x10
    // 0xfa11ac: SetupParameters(_CheckboxState this /* r1 => r1, fp-0x8 */)
    //     0xfa11ac: stur            x1, [fp, #-8]
    // 0xfa11b0: CheckStackOverflow
    //     0xfa11b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa11b4: cmp             SP, x16
    //     0xfa11b8: b.ls            #0xfa122c
    // 0xfa11bc: r0 = _CheckboxPainter()
    //     0xfa11bc: bl              #0xfa1234  ; Allocate_CheckboxPainterStub -> _CheckboxPainter (size=0x78)
    // 0xfa11c0: stur            x0, [fp, #-0x10]
    // 0xfa11c4: StoreField: r0->field_7 = rZR
    //     0xfa11c4: stur            xzr, [x0, #7]
    // 0xfa11c8: StoreField: r0->field_13 = rZR
    //     0xfa11c8: stur            xzr, [x0, #0x13]
    // 0xfa11cc: StoreField: r0->field_1b = rZR
    //     0xfa11cc: stur            xzr, [x0, #0x1b]
    // 0xfa11d0: r0 = LoadStaticField(0x45c)
    //     0xfa11d0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfa11d4: ldr             x0, [x0, #0x8b8]
    // 0xfa11d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa11dc: cmp             w0, w16
    // 0xfa11e0: b.ne            #0xfa11ec
    // 0xfa11e4: r2 = _emptyListeners
    //     0xfa11e4: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xfa11e8: r0 = InitLateFinalStaticField()
    //     0xfa11e8: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xfa11ec: mov             x1, x0
    // 0xfa11f0: ldur            x0, [fp, #-0x10]
    // 0xfa11f4: StoreField: r0->field_f = r1
    //     0xfa11f4: stur            w1, [x0, #0xf]
    // 0xfa11f8: ldur            x1, [fp, #-8]
    // 0xfa11fc: StoreField: r1->field_4f = r0
    //     0xfa11fc: stur            w0, [x1, #0x4f]
    //     0xfa1200: ldurb           w16, [x1, #-1]
    //     0xfa1204: ldurb           w17, [x0, #-1]
    //     0xfa1208: and             x16, x17, x16, lsr #2
    //     0xfa120c: tst             x16, HEAP, lsr #32
    //     0xfa1210: b.eq            #0xfa1218
    //     0xfa1214: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa1218: r0 = _MixinApplication257&State&TickerProviderStateMixin&ToggleableStateMixin()
    //     0xfa1218: bl              #0xfa0328  ; [dart:mixin_deduplication] _MixinApplication257&State&TickerProviderStateMixin&ToggleableStateMixin::_MixinApplication257&State&TickerProviderStateMixin&ToggleableStateMixin
    // 0xfa121c: r0 = Null
    //     0xfa121c: mov             x0, NULL
    // 0xfa1220: LeaveFrame
    //     0xfa1220: mov             SP, fp
    //     0xfa1224: ldp             fp, lr, [SP], #0x10
    // 0xfa1228: ret
    //     0xfa1228: ret             
    // 0xfa122c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa122c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa1230: b               #0xfa11bc
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10dc3fc, size: 0x4c
    // 0x10dc3fc: EnterFrame
    //     0x10dc3fc: stp             fp, lr, [SP, #-0x10]!
    //     0x10dc400: mov             fp, SP
    // 0x10dc404: AllocStack(0x8)
    //     0x10dc404: sub             SP, SP, #8
    // 0x10dc408: SetupParameters(_CheckboxState this /* r1 => r0, fp-0x8 */)
    //     0x10dc408: mov             x0, x1
    //     0x10dc40c: stur            x1, [fp, #-8]
    // 0x10dc410: CheckStackOverflow
    //     0x10dc410: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10dc414: cmp             SP, x16
    //     0x10dc418: b.ls            #0x10dc440
    // 0x10dc41c: LoadField: r1 = r0->field_4f
    //     0x10dc41c: ldur            w1, [x0, #0x4f]
    // 0x10dc420: DecompressPointer r1
    //     0x10dc420: add             x1, x1, HEAP, lsl #32
    // 0x10dc424: r0 = dispose()
    //     0x10dc424: bl              #0x10eef48  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::dispose
    // 0x10dc428: ldur            x1, [fp, #-8]
    // 0x10dc42c: r0 = dispose()
    //     0x10dc42c: bl              #0x10dc448  ; [dart:mixin_deduplication] _MixinApplication26&State&TickerProviderStateMixin&ToggleableStateMixin::dispose
    // 0x10dc430: r0 = Null
    //     0x10dc430: mov             x0, NULL
    // 0x10dc434: LeaveFrame
    //     0x10dc434: mov             SP, fp
    //     0x10dc438: ldp             fp, lr, [SP], #0x10
    // 0x10dc43c: ret
    //     0x10dc43c: ret             
    // 0x10dc440: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dc440: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dc444: b               #0x10dc41c
  }
}

// class id: 6487, size: 0x5c, field offset: 0xc
//   const constructor, 
class Checkbox extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa1158, size: 0x48
    // 0xfa1158: EnterFrame
    //     0xfa1158: stp             fp, lr, [SP, #-0x10]!
    //     0xfa115c: mov             fp, SP
    // 0xfa1160: AllocStack(0x8)
    //     0xfa1160: sub             SP, SP, #8
    // 0xfa1164: CheckStackOverflow
    //     0xfa1164: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa1168: cmp             SP, x16
    //     0xfa116c: b.ls            #0xfa1198
    // 0xfa1170: r1 = <Checkbox>
    //     0xfa1170: add             x1, PP, #0x85, lsl #12  ; [pp+0x851a8] TypeArguments: <Checkbox>
    //     0xfa1174: ldr             x1, [x1, #0x1a8]
    // 0xfa1178: r0 = _CheckboxState()
    //     0xfa1178: bl              #0xfa1240  ; Allocate_CheckboxStateStub -> _CheckboxState (size=0x58)
    // 0xfa117c: mov             x1, x0
    // 0xfa1180: stur            x0, [fp, #-8]
    // 0xfa1184: r0 = _CheckboxState()
    //     0xfa1184: bl              #0xfa11a0  ; [package:flutter/src/material/checkbox.dart] _CheckboxState::_CheckboxState
    // 0xfa1188: ldur            x0, [fp, #-8]
    // 0xfa118c: LeaveFrame
    //     0xfa118c: mov             SP, fp
    //     0xfa1190: ldp             fp, lr, [SP], #0x10
    // 0xfa1194: ret
    //     0xfa1194: ret             
    // 0xfa1198: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa1198: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa119c: b               #0xfa1170
  }
}

// class id: 8294, size: 0x14, field offset: 0x14
enum _CheckboxType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
