// lib: , url: package:flutter/src/material/checkbox_theme.dart

// class id: 1048866, size: 0x8
class :: {
}

// class id: 5173, size: 0x2c, field offset: 0x8
//   const constructor, 
class CheckboxThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x112fc48, size: 0x4c0
    // 0x112fc48: EnterFrame
    //     0x112fc48: stp             fp, lr, [SP, #-0x10]!
    //     0x112fc4c: mov             fp, SP
    // 0x112fc50: AllocStack(0x80)
    //     0x112fc50: sub             SP, SP, #0x80
    // 0x112fc54: CheckStackOverflow
    //     0x112fc54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112fc58: cmp             SP, x16
    //     0x112fc5c: b.ls            #0x1130100
    // 0x112fc60: ldr             x0, [fp, #0x10]
    // 0x112fc64: r1 = LoadClassIdInstr(r0)
    //     0x112fc64: ldur            x1, [x0, #-1]
    //     0x112fc68: ubfx            x1, x1, #0xc, #0x14
    // 0x112fc6c: stur            x1, [fp, #-8]
    // 0x112fc70: r17 = 5173
    //     0x112fc70: mov             x17, #0x1435
    // 0x112fc74: cmp             x1, x17
    // 0x112fc78: b.ne            #0x112fc8c
    // 0x112fc7c: LoadField: r2 = r0->field_b
    //     0x112fc7c: ldur            w2, [x0, #0xb]
    // 0x112fc80: DecompressPointer r2
    //     0x112fc80: add             x2, x2, HEAP, lsl #32
    // 0x112fc84: mov             x0, x1
    // 0x112fc88: b               #0x112fd1c
    // 0x112fc8c: r17 = 5174
    //     0x112fc8c: mov             x17, #0x1436
    // 0x112fc90: cmp             x1, x17
    // 0x112fc94: b.ne            #0x112fcdc
    // 0x112fc98: r1 = 1
    //     0x112fc98: mov             x1, #1
    // 0x112fc9c: r0 = AllocateContext()
    //     0x112fc9c: bl              #0x13de838  ; AllocateContextStub
    // 0x112fca0: mov             x1, x0
    // 0x112fca4: ldr             x0, [fp, #0x10]
    // 0x112fca8: StoreField: r1->field_f = r0
    //     0x112fca8: stur            w0, [x1, #0xf]
    // 0x112fcac: mov             x2, x1
    // 0x112fcb0: r1 = Function '<anonymous closure>':.
    //     0x112fcb0: add             x1, PP, #0x26, lsl #12  ; [pp+0x264a8] AnonymousClosure: (0xd144a8), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0x112fcb4: ldr             x1, [x1, #0x4a8]
    // 0x112fcb8: r0 = AllocateClosure()
    //     0x112fcb8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x112fcbc: r16 = <Color>
    //     0x112fcbc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x112fcc0: ldr             x16, [x16, #0xa90]
    // 0x112fcc4: stp             x0, x16, [SP]
    // 0x112fcc8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x112fcc8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x112fccc: r0 = resolveWith()
    //     0x112fccc: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x112fcd0: mov             x2, x0
    // 0x112fcd4: ldur            x0, [fp, #-8]
    // 0x112fcd8: b               #0x112fd1c
    // 0x112fcdc: r1 = 1
    //     0x112fcdc: mov             x1, #1
    // 0x112fce0: r0 = AllocateContext()
    //     0x112fce0: bl              #0x13de838  ; AllocateContextStub
    // 0x112fce4: mov             x1, x0
    // 0x112fce8: ldr             x0, [fp, #0x10]
    // 0x112fcec: StoreField: r1->field_f = r0
    //     0x112fcec: stur            w0, [x1, #0xf]
    // 0x112fcf0: mov             x2, x1
    // 0x112fcf4: r1 = Function '<anonymous closure>':.
    //     0x112fcf4: add             x1, PP, #0x26, lsl #12  ; [pp+0x264b0] AnonymousClosure: (0xd14374), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0x112fcf8: ldr             x1, [x1, #0x4b0]
    // 0x112fcfc: r0 = AllocateClosure()
    //     0x112fcfc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x112fd00: r16 = <Color>
    //     0x112fd00: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x112fd04: ldr             x16, [x16, #0xa90]
    // 0x112fd08: stp             x0, x16, [SP]
    // 0x112fd0c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x112fd0c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x112fd10: r0 = resolveWith()
    //     0x112fd10: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x112fd14: mov             x2, x0
    // 0x112fd18: ldur            x0, [fp, #-8]
    // 0x112fd1c: stur            x2, [fp, #-0x10]
    // 0x112fd20: r17 = 5173
    //     0x112fd20: mov             x17, #0x1435
    // 0x112fd24: cmp             x0, x17
    // 0x112fd28: b.ne            #0x112fd40
    // 0x112fd2c: ldr             x1, [fp, #0x10]
    // 0x112fd30: LoadField: r3 = r1->field_f
    //     0x112fd30: ldur            w3, [x1, #0xf]
    // 0x112fd34: DecompressPointer r3
    //     0x112fd34: add             x3, x3, HEAP, lsl #32
    // 0x112fd38: mov             x1, x3
    // 0x112fd3c: b               #0x112fdb8
    // 0x112fd40: ldr             x1, [fp, #0x10]
    // 0x112fd44: r17 = 5174
    //     0x112fd44: mov             x17, #0x1436
    // 0x112fd48: cmp             x0, x17
    // 0x112fd4c: b.ne            #0x112fd94
    // 0x112fd50: r1 = 1
    //     0x112fd50: mov             x1, #1
    // 0x112fd54: r0 = AllocateContext()
    //     0x112fd54: bl              #0x13de838  ; AllocateContextStub
    // 0x112fd58: mov             x1, x0
    // 0x112fd5c: ldr             x0, [fp, #0x10]
    // 0x112fd60: StoreField: r1->field_f = r0
    //     0x112fd60: stur            w0, [x1, #0xf]
    // 0x112fd64: mov             x2, x1
    // 0x112fd68: r1 = Function '<anonymous closure>':.
    //     0x112fd68: add             x1, PP, #0x26, lsl #12  ; [pp+0x264b8] AnonymousClosure: (0xd13524), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0x112fd6c: ldr             x1, [x1, #0x4b8]
    // 0x112fd70: r0 = AllocateClosure()
    //     0x112fd70: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x112fd74: r16 = <Color>
    //     0x112fd74: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x112fd78: ldr             x16, [x16, #0xa90]
    // 0x112fd7c: stp             x0, x16, [SP]
    // 0x112fd80: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x112fd80: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x112fd84: r0 = resolveWith()
    //     0x112fd84: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x112fd88: mov             x1, x0
    // 0x112fd8c: ldur            x0, [fp, #-8]
    // 0x112fd90: b               #0x112fdb8
    // 0x112fd94: r16 = <Color>
    //     0x112fd94: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x112fd98: ldr             x16, [x16, #0xa90]
    // 0x112fd9c: r30 = Instance_Color
    //     0x112fd9c: add             lr, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x112fda0: ldr             lr, [lr, #0xc38]
    // 0x112fda4: stp             lr, x16, [SP]
    // 0x112fda8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x112fda8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x112fdac: r0 = all()
    //     0x112fdac: bl              #0xd13288  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::all
    // 0x112fdb0: mov             x1, x0
    // 0x112fdb4: ldur            x0, [fp, #-8]
    // 0x112fdb8: stur            x1, [fp, #-0x18]
    // 0x112fdbc: r17 = 5173
    //     0x112fdbc: mov             x17, #0x1435
    // 0x112fdc0: cmp             x0, x17
    // 0x112fdc4: b.ne            #0x112fddc
    // 0x112fdc8: ldr             x2, [fp, #0x10]
    // 0x112fdcc: LoadField: r3 = r2->field_13
    //     0x112fdcc: ldur            w3, [x2, #0x13]
    // 0x112fdd0: DecompressPointer r3
    //     0x112fdd0: add             x3, x3, HEAP, lsl #32
    // 0x112fdd4: mov             x1, x3
    // 0x112fdd8: b               #0x112fe74
    // 0x112fddc: ldr             x2, [fp, #0x10]
    // 0x112fde0: r17 = 5174
    //     0x112fde0: mov             x17, #0x1436
    // 0x112fde4: cmp             x0, x17
    // 0x112fde8: b.ne            #0x112fe30
    // 0x112fdec: r1 = 1
    //     0x112fdec: mov             x1, #1
    // 0x112fdf0: r0 = AllocateContext()
    //     0x112fdf0: bl              #0x13de838  ; AllocateContextStub
    // 0x112fdf4: mov             x1, x0
    // 0x112fdf8: ldr             x0, [fp, #0x10]
    // 0x112fdfc: StoreField: r1->field_f = r0
    //     0x112fdfc: stur            w0, [x1, #0xf]
    // 0x112fe00: mov             x2, x1
    // 0x112fe04: r1 = Function '<anonymous closure>':.
    //     0x112fe04: add             x1, PP, #0x26, lsl #12  ; [pp+0x264c0] AnonymousClosure: (0xd13860), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0x112fe08: ldr             x1, [x1, #0x4c0]
    // 0x112fe0c: r0 = AllocateClosure()
    //     0x112fe0c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x112fe10: r16 = <Color>
    //     0x112fe10: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x112fe14: ldr             x16, [x16, #0xa90]
    // 0x112fe18: stp             x0, x16, [SP]
    // 0x112fe1c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x112fe1c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x112fe20: r0 = resolveWith()
    //     0x112fe20: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x112fe24: mov             x1, x0
    // 0x112fe28: ldur            x0, [fp, #-8]
    // 0x112fe2c: b               #0x112fe74
    // 0x112fe30: mov             x0, x2
    // 0x112fe34: r1 = 1
    //     0x112fe34: mov             x1, #1
    // 0x112fe38: r0 = AllocateContext()
    //     0x112fe38: bl              #0x13de838  ; AllocateContextStub
    // 0x112fe3c: mov             x1, x0
    // 0x112fe40: ldr             x0, [fp, #0x10]
    // 0x112fe44: StoreField: r1->field_f = r0
    //     0x112fe44: stur            w0, [x1, #0xf]
    // 0x112fe48: mov             x2, x1
    // 0x112fe4c: r1 = Function '<anonymous closure>':.
    //     0x112fe4c: add             x1, PP, #0x26, lsl #12  ; [pp+0x264c8] AnonymousClosure: (0xd136b4), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0x112fe50: ldr             x1, [x1, #0x4c8]
    // 0x112fe54: r0 = AllocateClosure()
    //     0x112fe54: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x112fe58: r16 = <Color?>
    //     0x112fe58: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x112fe5c: ldr             x16, [x16, #0xa40]
    // 0x112fe60: stp             x0, x16, [SP]
    // 0x112fe64: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x112fe64: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x112fe68: r0 = resolveWith()
    //     0x112fe68: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x112fe6c: mov             x1, x0
    // 0x112fe70: ldur            x0, [fp, #-8]
    // 0x112fe74: stur            x1, [fp, #-0x40]
    // 0x112fe78: r17 = 5173
    //     0x112fe78: mov             x17, #0x1435
    // 0x112fe7c: cmp             x0, x17
    // 0x112fe80: b.ne            #0x112fe94
    // 0x112fe84: ldr             x2, [fp, #0x10]
    // 0x112fe88: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x112fe88: ldur            w3, [x2, #0x17]
    // 0x112fe8c: DecompressPointer r3
    //     0x112fe8c: add             x3, x3, HEAP, lsl #32
    // 0x112fe90: b               #0x112feb8
    // 0x112fe94: ldr             x2, [fp, #0x10]
    // 0x112fe98: r17 = 5174
    //     0x112fe98: mov             x17, #0x1436
    // 0x112fe9c: cmp             x0, x17
    // 0x112fea0: b.ne            #0x112feb0
    // 0x112fea4: r3 = 20.000000
    //     0x112fea4: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1ae98] 20
    //     0x112fea8: ldr             x3, [x3, #0xe98]
    // 0x112feac: b               #0x112feb8
    // 0x112feb0: r3 = 20.000000
    //     0x112feb0: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1ae98] 20
    //     0x112feb4: ldr             x3, [x3, #0xe98]
    // 0x112feb8: stur            x3, [fp, #-0x38]
    // 0x112febc: r17 = 5173
    //     0x112febc: mov             x17, #0x1435
    // 0x112fec0: cmp             x0, x17
    // 0x112fec4: b.ne            #0x112fed4
    // 0x112fec8: LoadField: r4 = r2->field_1b
    //     0x112fec8: ldur            w4, [x2, #0x1b]
    // 0x112fecc: DecompressPointer r4
    //     0x112fecc: add             x4, x4, HEAP, lsl #32
    // 0x112fed0: b               #0x112ff0c
    // 0x112fed4: r17 = 5174
    //     0x112fed4: mov             x17, #0x1436
    // 0x112fed8: cmp             x0, x17
    // 0x112fedc: b.ne            #0x112fef8
    // 0x112fee0: LoadField: r4 = r2->field_2b
    //     0x112fee0: ldur            w4, [x2, #0x2b]
    // 0x112fee4: DecompressPointer r4
    //     0x112fee4: add             x4, x4, HEAP, lsl #32
    // 0x112fee8: LoadField: r5 = r4->field_1b
    //     0x112fee8: ldur            w5, [x4, #0x1b]
    // 0x112feec: DecompressPointer r5
    //     0x112feec: add             x5, x5, HEAP, lsl #32
    // 0x112fef0: mov             x4, x5
    // 0x112fef4: b               #0x112ff0c
    // 0x112fef8: LoadField: r4 = r2->field_2b
    //     0x112fef8: ldur            w4, [x2, #0x2b]
    // 0x112fefc: DecompressPointer r4
    //     0x112fefc: add             x4, x4, HEAP, lsl #32
    // 0x112ff00: LoadField: r5 = r4->field_1b
    //     0x112ff00: ldur            w5, [x4, #0x1b]
    // 0x112ff04: DecompressPointer r5
    //     0x112ff04: add             x5, x5, HEAP, lsl #32
    // 0x112ff08: mov             x4, x5
    // 0x112ff0c: stur            x4, [fp, #-0x30]
    // 0x112ff10: r17 = 5173
    //     0x112ff10: mov             x17, #0x1435
    // 0x112ff14: cmp             x0, x17
    // 0x112ff18: b.ne            #0x112ff28
    // 0x112ff1c: LoadField: r5 = r2->field_1f
    //     0x112ff1c: ldur            w5, [x2, #0x1f]
    // 0x112ff20: DecompressPointer r5
    //     0x112ff20: add             x5, x5, HEAP, lsl #32
    // 0x112ff24: b               #0x112ff54
    // 0x112ff28: r17 = 5174
    //     0x112ff28: mov             x17, #0x1436
    // 0x112ff2c: cmp             x0, x17
    // 0x112ff30: b.ne            #0x112ff40
    // 0x112ff34: r5 = Instance_VisualDensity
    //     0x112ff34: add             x5, PP, #0x12, lsl #12  ; [pp+0x12ef0] Obj!VisualDensity@12b1d61
    //     0x112ff38: ldr             x5, [x5, #0xef0]
    // 0x112ff3c: b               #0x112ff54
    // 0x112ff40: LoadField: r5 = r2->field_2b
    //     0x112ff40: ldur            w5, [x2, #0x2b]
    // 0x112ff44: DecompressPointer r5
    //     0x112ff44: add             x5, x5, HEAP, lsl #32
    // 0x112ff48: LoadField: r6 = r5->field_33
    //     0x112ff48: ldur            w6, [x5, #0x33]
    // 0x112ff4c: DecompressPointer r6
    //     0x112ff4c: add             x6, x6, HEAP, lsl #32
    // 0x112ff50: mov             x5, x6
    // 0x112ff54: stur            x5, [fp, #-0x28]
    // 0x112ff58: r17 = 5173
    //     0x112ff58: mov             x17, #0x1435
    // 0x112ff5c: cmp             x0, x17
    // 0x112ff60: b.ne            #0x112ff70
    // 0x112ff64: LoadField: r6 = r2->field_23
    //     0x112ff64: ldur            w6, [x2, #0x23]
    // 0x112ff68: DecompressPointer r6
    //     0x112ff68: add             x6, x6, HEAP, lsl #32
    // 0x112ff6c: b               #0x112ff90
    // 0x112ff70: r17 = 5174
    //     0x112ff70: mov             x17, #0x1436
    // 0x112ff74: cmp             x0, x17
    // 0x112ff78: b.ne            #0x112ff88
    // 0x112ff7c: r6 = Instance_RoundedRectangleBorder
    //     0x112ff7c: add             x6, PP, #0x26, lsl #12  ; [pp+0x264d0] Obj!RoundedRectangleBorder@129ec61
    //     0x112ff80: ldr             x6, [x6, #0x4d0]
    // 0x112ff84: b               #0x112ff90
    // 0x112ff88: r6 = Instance_RoundedRectangleBorder
    //     0x112ff88: add             x6, PP, #0x26, lsl #12  ; [pp+0x264d8] Obj!RoundedRectangleBorder@129ec51
    //     0x112ff8c: ldr             x6, [x6, #0x4d8]
    // 0x112ff90: stur            x6, [fp, #-0x20]
    // 0x112ff94: r17 = 5173
    //     0x112ff94: mov             x17, #0x1435
    // 0x112ff98: cmp             x0, x17
    // 0x112ff9c: b.ne            #0x112ffac
    // 0x112ffa0: LoadField: r0 = r2->field_27
    //     0x112ffa0: ldur            w0, [x2, #0x27]
    // 0x112ffa4: DecompressPointer r0
    //     0x112ffa4: add             x0, x0, HEAP, lsl #32
    // 0x112ffa8: b               #0x11300a0
    // 0x112ffac: r17 = 5174
    //     0x112ffac: mov             x17, #0x1436
    // 0x112ffb0: cmp             x0, x17
    // 0x112ffb4: b.ne            #0x1130020
    // 0x112ffb8: r1 = 1
    //     0x112ffb8: mov             x1, #1
    // 0x112ffbc: r0 = AllocateContext()
    //     0x112ffbc: bl              #0x13de838  ; AllocateContextStub
    // 0x112ffc0: mov             x1, x0
    // 0x112ffc4: ldr             x0, [fp, #0x10]
    // 0x112ffc8: stur            x1, [fp, #-0x48]
    // 0x112ffcc: StoreField: r1->field_f = r0
    //     0x112ffcc: stur            w0, [x1, #0xf]
    // 0x112ffd0: r0 = _WidgetStateBorderSide()
    //     0x112ffd0: bl              #0xd132d4  ; Allocate_WidgetStateBorderSideStub -> _WidgetStateBorderSide (size=0x24)
    // 0x112ffd4: ldur            x2, [fp, #-0x48]
    // 0x112ffd8: r1 = Function '<anonymous closure>':.
    //     0x112ffd8: add             x1, PP, #0x26, lsl #12  ; [pp+0x264e0] AnonymousClosure: (0xd13f0c), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0x112ffdc: ldr             x1, [x1, #0x4e0]
    // 0x112ffe0: stur            x0, [fp, #-0x48]
    // 0x112ffe4: r0 = AllocateClosure()
    //     0x112ffe4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x112ffe8: mov             x1, x0
    // 0x112ffec: ldur            x0, [fp, #-0x48]
    // 0x112fff0: StoreField: r0->field_1f = r1
    //     0x112fff0: stur            w1, [x0, #0x1f]
    // 0x112fff4: r1 = Instance_Color
    //     0x112fff4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x112fff8: ldr             x1, [x1, #0x948]
    // 0x112fffc: StoreField: r0->field_7 = r1
    //     0x112fffc: stur            w1, [x0, #7]
    // 0x1130000: d0 = 1.000000
    //     0x1130000: fmov            d0, #1.00000000
    // 0x1130004: StoreField: r0->field_b = d0
    //     0x1130004: stur            d0, [x0, #0xb]
    // 0x1130008: r2 = Instance_BorderStyle
    //     0x1130008: add             x2, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x113000c: ldr             x2, [x2, #0xdc8]
    // 0x1130010: StoreField: r0->field_13 = r2
    //     0x1130010: stur            w2, [x0, #0x13]
    // 0x1130014: d1 = -1.000000
    //     0x1130014: fmov            d1, #-1.00000000
    // 0x1130018: ArrayStore: r0[0] = d1  ; List_8
    //     0x1130018: stur            d1, [x0, #0x17]
    // 0x113001c: b               #0x11300a0
    // 0x1130020: mov             x0, x2
    // 0x1130024: r1 = Instance_Color
    //     0x1130024: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x1130028: ldr             x1, [x1, #0x948]
    // 0x113002c: r2 = Instance_BorderStyle
    //     0x113002c: add             x2, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x1130030: ldr             x2, [x2, #0xdc8]
    // 0x1130034: d0 = 1.000000
    //     0x1130034: fmov            d0, #1.00000000
    // 0x1130038: d1 = -1.000000
    //     0x1130038: fmov            d1, #-1.00000000
    // 0x113003c: r1 = 1
    //     0x113003c: mov             x1, #1
    // 0x1130040: r0 = AllocateContext()
    //     0x1130040: bl              #0x13de838  ; AllocateContextStub
    // 0x1130044: mov             x1, x0
    // 0x1130048: ldr             x0, [fp, #0x10]
    // 0x113004c: stur            x1, [fp, #-0x48]
    // 0x1130050: StoreField: r1->field_f = r0
    //     0x1130050: stur            w0, [x1, #0xf]
    // 0x1130054: r0 = _WidgetStateBorderSide()
    //     0x1130054: bl              #0xd132d4  ; Allocate_WidgetStateBorderSideStub -> _WidgetStateBorderSide (size=0x24)
    // 0x1130058: ldur            x2, [fp, #-0x48]
    // 0x113005c: r1 = Function '<anonymous closure>':.
    //     0x113005c: add             x1, PP, #0x26, lsl #12  ; [pp+0x264e8] AnonymousClosure: (0xd13d68), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0x1130060: ldr             x1, [x1, #0x4e8]
    // 0x1130064: stur            x0, [fp, #-0x48]
    // 0x1130068: r0 = AllocateClosure()
    //     0x1130068: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x113006c: mov             x1, x0
    // 0x1130070: ldur            x0, [fp, #-0x48]
    // 0x1130074: StoreField: r0->field_1f = r1
    //     0x1130074: stur            w1, [x0, #0x1f]
    // 0x1130078: r1 = Instance_Color
    //     0x1130078: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x113007c: ldr             x1, [x1, #0x948]
    // 0x1130080: StoreField: r0->field_7 = r1
    //     0x1130080: stur            w1, [x0, #7]
    // 0x1130084: d0 = 1.000000
    //     0x1130084: fmov            d0, #1.00000000
    // 0x1130088: StoreField: r0->field_b = d0
    //     0x1130088: stur            d0, [x0, #0xb]
    // 0x113008c: r1 = Instance_BorderStyle
    //     0x113008c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x1130090: ldr             x1, [x1, #0xdc8]
    // 0x1130094: StoreField: r0->field_13 = r1
    //     0x1130094: stur            w1, [x0, #0x13]
    // 0x1130098: d0 = -1.000000
    //     0x1130098: fmov            d0, #-1.00000000
    // 0x113009c: ArrayStore: r0[0] = d0  ; List_8
    //     0x113009c: stur            d0, [x0, #0x17]
    // 0x11300a0: ldur            x16, [fp, #-0x18]
    // 0x11300a4: ldur            lr, [fp, #-0x40]
    // 0x11300a8: stp             lr, x16, [SP, #0x28]
    // 0x11300ac: ldur            x16, [fp, #-0x38]
    // 0x11300b0: ldur            lr, [fp, #-0x30]
    // 0x11300b4: stp             lr, x16, [SP, #0x18]
    // 0x11300b8: ldur            x16, [fp, #-0x28]
    // 0x11300bc: ldur            lr, [fp, #-0x20]
    // 0x11300c0: stp             lr, x16, [SP, #8]
    // 0x11300c4: str             x0, [SP]
    // 0x11300c8: ldur            x2, [fp, #-0x10]
    // 0x11300cc: r1 = Null
    //     0x11300cc: mov             x1, NULL
    // 0x11300d0: r4 = const [0, 0x9, 0x7, 0x9, null]
    //     0x11300d0: add             x4, PP, #0xe, lsl #12  ; [pp+0xe278] List(5) [0, 0x9, 0x7, 0x9, Null]
    //     0x11300d4: ldr             x4, [x4, #0x278]
    // 0x11300d8: r0 = hash()
    //     0x11300d8: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x11300dc: mov             x2, x0
    // 0x11300e0: r0 = BoxInt64Instr(r2)
    //     0x11300e0: sbfiz           x0, x2, #1, #0x1f
    //     0x11300e4: cmp             x2, x0, asr #1
    //     0x11300e8: b.eq            #0x11300f4
    //     0x11300ec: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11300f0: stur            x2, [x0, #7]
    // 0x11300f4: LeaveFrame
    //     0x11300f4: mov             SP, fp
    //     0x11300f8: ldp             fp, lr, [SP], #0x10
    // 0x11300fc: ret
    //     0x11300fc: ret             
    // 0x1130100: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1130100: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1130104: b               #0x112fc60
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x116838c, size: 0xc8
    // 0x116838c: EnterFrame
    //     0x116838c: stp             fp, lr, [SP, #-0x10]!
    //     0x1168390: mov             fp, SP
    // 0x1168394: AllocStack(0x10)
    //     0x1168394: sub             SP, SP, #0x10
    // 0x1168398: SetupParameters(dynamic _ /* r1 => r0 */, dynamic _ /* d0 => d0, fp-0x10 */)
    //     0x1168398: mov             x0, x1
    //     0x116839c: stur            d0, [fp, #-0x10]
    // 0x11683a0: CheckStackOverflow
    //     0x11683a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11683a4: cmp             SP, x16
    //     0x11683a8: b.ls            #0x1168430
    // 0x11683ac: cmp             w0, w2
    // 0x11683b0: b.ne            #0x11683c0
    // 0x11683b4: LeaveFrame
    //     0x11683b4: mov             SP, fp
    //     0x11683b8: ldp             fp, lr, [SP], #0x10
    // 0x11683bc: ret
    //     0x11683bc: ret             
    // 0x11683c0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11683c0: ldur            w1, [x0, #0x17]
    // 0x11683c4: DecompressPointer r1
    //     0x11683c4: add             x1, x1, HEAP, lsl #32
    // 0x11683c8: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x11683c8: ldur            w0, [x2, #0x17]
    // 0x11683cc: DecompressPointer r0
    //     0x11683cc: add             x0, x0, HEAP, lsl #32
    // 0x11683d0: r3 = inline_Allocate_Double()
    //     0x11683d0: ldp             x3, x2, [THR, #0x60]  ; THR::top
    //     0x11683d4: add             x3, x3, #0x10
    //     0x11683d8: cmp             x2, x3
    //     0x11683dc: b.ls            #0x1168438
    //     0x11683e0: str             x3, [THR, #0x60]  ; THR::top
    //     0x11683e4: sub             x3, x3, #0xf
    //     0x11683e8: mov             x2, #0xe19c
    //     0x11683ec: movk            x2, #3, lsl #16
    //     0x11683f0: stur            x2, [x3, #-1]
    // 0x11683f4: dmb             ishst
    // 0x11683f8: StoreField: r3->field_7 = d0
    //     0x11683f8: stur            d0, [x3, #7]
    // 0x11683fc: mov             x2, x0
    // 0x1168400: r0 = lerpDouble()
    //     0x1168400: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1168404: ldur            d0, [fp, #-0x10]
    // 0x1168408: r1 = Null
    //     0x1168408: mov             x1, NULL
    // 0x116840c: r2 = Null
    //     0x116840c: mov             x2, NULL
    // 0x1168410: stur            x0, [fp, #-8]
    // 0x1168414: r0 = lerp()
    //     0x1168414: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x1168418: r0 = CheckboxThemeData()
    //     0x1168418: bl              #0x1168454  ; AllocateCheckboxThemeDataStub -> CheckboxThemeData (size=0x2c)
    // 0x116841c: ldur            x1, [fp, #-8]
    // 0x1168420: ArrayStore: r0[0] = r1  ; List_4
    //     0x1168420: stur            w1, [x0, #0x17]
    // 0x1168424: LeaveFrame
    //     0x1168424: mov             SP, fp
    //     0x1168428: ldp             fp, lr, [SP], #0x10
    // 0x116842c: ret
    //     0x116842c: ret             
    // 0x1168430: r0 = StackOverflowSharedWithFPURegs()
    //     0x1168430: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1168434: b               #0x11683ac
    // 0x1168438: SaveReg d0
    //     0x1168438: str             q0, [SP, #-0x10]!
    // 0x116843c: stp             x0, x1, [SP, #-0x10]!
    // 0x1168440: r0 = AllocateDouble()
    //     0x1168440: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1168444: mov             x3, x0
    // 0x1168448: ldp             x0, x1, [SP], #0x10
    // 0x116844c: RestoreReg d0
    //     0x116844c: ldr             q0, [SP], #0x10
    // 0x1168450: b               #0x11683f8
  }
  _ ==(/* No info */) {
    // ** addr: 0x1265e98, size: 0xa24
    // 0x1265e98: EnterFrame
    //     0x1265e98: stp             fp, lr, [SP, #-0x10]!
    //     0x1265e9c: mov             fp, SP
    // 0x1265ea0: AllocStack(0x30)
    //     0x1265ea0: sub             SP, SP, #0x30
    // 0x1265ea4: CheckStackOverflow
    //     0x1265ea4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1265ea8: cmp             SP, x16
    //     0x1265eac: b.ls            #0x12668b4
    // 0x1265eb0: ldr             x0, [fp, #0x10]
    // 0x1265eb4: cmp             w0, NULL
    // 0x1265eb8: b.ne            #0x1265ecc
    // 0x1265ebc: r0 = false
    //     0x1265ebc: add             x0, NULL, #0x30  ; false
    // 0x1265ec0: LeaveFrame
    //     0x1265ec0: mov             SP, fp
    //     0x1265ec4: ldp             fp, lr, [SP], #0x10
    // 0x1265ec8: ret
    //     0x1265ec8: ret             
    // 0x1265ecc: ldr             x1, [fp, #0x18]
    // 0x1265ed0: cmp             w1, w0
    // 0x1265ed4: b.ne            #0x1265ee8
    // 0x1265ed8: r0 = true
    //     0x1265ed8: add             x0, NULL, #0x20  ; true
    // 0x1265edc: LeaveFrame
    //     0x1265edc: mov             SP, fp
    //     0x1265ee0: ldp             fp, lr, [SP], #0x10
    // 0x1265ee4: ret
    //     0x1265ee4: ret             
    // 0x1265ee8: stp             x1, x0, [SP]
    // 0x1265eec: r0 = _haveSameRuntimeType()
    //     0x1265eec: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x1265ef0: tbz             w0, #4, #0x1265f04
    // 0x1265ef4: r0 = false
    //     0x1265ef4: add             x0, NULL, #0x30  ; false
    // 0x1265ef8: LeaveFrame
    //     0x1265ef8: mov             SP, fp
    //     0x1265efc: ldp             fp, lr, [SP], #0x10
    // 0x1265f00: ret
    //     0x1265f00: ret             
    // 0x1265f04: ldr             x0, [fp, #0x10]
    // 0x1265f08: r1 = 60
    //     0x1265f08: mov             x1, #0x3c
    // 0x1265f0c: branchIfSmi(r0, 0x1265f18)
    //     0x1265f0c: tbz             w0, #0, #0x1265f18
    // 0x1265f10: r1 = LoadClassIdInstr(r0)
    //     0x1265f10: ldur            x1, [x0, #-1]
    //     0x1265f14: ubfx            x1, x1, #0xc, #0x14
    // 0x1265f18: stur            x1, [fp, #-8]
    // 0x1265f1c: r17 = -5173
    //     0x1265f1c: mov             x17, #-0x1435
    // 0x1265f20: add             x16, x1, x17
    // 0x1265f24: cmp             x16, #2
    // 0x1265f28: b.hi            #0x12668a4
    // 0x1265f2c: r17 = 5173
    //     0x1265f2c: mov             x17, #0x1435
    // 0x1265f30: cmp             x1, x17
    // 0x1265f34: b.ne            #0x1265f48
    // 0x1265f38: LoadField: r2 = r0->field_b
    //     0x1265f38: ldur            w2, [x0, #0xb]
    // 0x1265f3c: DecompressPointer r2
    //     0x1265f3c: add             x2, x2, HEAP, lsl #32
    // 0x1265f40: mov             x1, x2
    // 0x1265f44: b               #0x1265fd0
    // 0x1265f48: r17 = 5174
    //     0x1265f48: mov             x17, #0x1436
    // 0x1265f4c: cmp             x1, x17
    // 0x1265f50: b.ne            #0x1265f94
    // 0x1265f54: r1 = 1
    //     0x1265f54: mov             x1, #1
    // 0x1265f58: r0 = AllocateContext()
    //     0x1265f58: bl              #0x13de838  ; AllocateContextStub
    // 0x1265f5c: mov             x1, x0
    // 0x1265f60: ldr             x0, [fp, #0x10]
    // 0x1265f64: StoreField: r1->field_f = r0
    //     0x1265f64: stur            w0, [x1, #0xf]
    // 0x1265f68: mov             x2, x1
    // 0x1265f6c: r1 = Function '<anonymous closure>':.
    //     0x1265f6c: add             x1, PP, #0x26, lsl #12  ; [pp+0x264a8] AnonymousClosure: (0xd144a8), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0x1265f70: ldr             x1, [x1, #0x4a8]
    // 0x1265f74: r0 = AllocateClosure()
    //     0x1265f74: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1265f78: r16 = <Color>
    //     0x1265f78: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1265f7c: ldr             x16, [x16, #0xa90]
    // 0x1265f80: stp             x0, x16, [SP]
    // 0x1265f84: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1265f84: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1265f88: r0 = resolveWith()
    //     0x1265f88: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1265f8c: mov             x1, x0
    // 0x1265f90: b               #0x1265fd0
    // 0x1265f94: r1 = 1
    //     0x1265f94: mov             x1, #1
    // 0x1265f98: r0 = AllocateContext()
    //     0x1265f98: bl              #0x13de838  ; AllocateContextStub
    // 0x1265f9c: mov             x1, x0
    // 0x1265fa0: ldr             x0, [fp, #0x10]
    // 0x1265fa4: StoreField: r1->field_f = r0
    //     0x1265fa4: stur            w0, [x1, #0xf]
    // 0x1265fa8: mov             x2, x1
    // 0x1265fac: r1 = Function '<anonymous closure>':.
    //     0x1265fac: add             x1, PP, #0x26, lsl #12  ; [pp+0x264b0] AnonymousClosure: (0xd14374), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0x1265fb0: ldr             x1, [x1, #0x4b0]
    // 0x1265fb4: r0 = AllocateClosure()
    //     0x1265fb4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1265fb8: r16 = <Color>
    //     0x1265fb8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1265fbc: ldr             x16, [x16, #0xa90]
    // 0x1265fc0: stp             x0, x16, [SP]
    // 0x1265fc4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1265fc4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1265fc8: r0 = resolveWith()
    //     0x1265fc8: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1265fcc: mov             x1, x0
    // 0x1265fd0: ldr             x0, [fp, #0x18]
    // 0x1265fd4: stur            x1, [fp, #-0x18]
    // 0x1265fd8: r2 = LoadClassIdInstr(r0)
    //     0x1265fd8: ldur            x2, [x0, #-1]
    //     0x1265fdc: ubfx            x2, x2, #0xc, #0x14
    // 0x1265fe0: stur            x2, [fp, #-0x10]
    // 0x1265fe4: r17 = 5173
    //     0x1265fe4: mov             x17, #0x1435
    // 0x1265fe8: cmp             x2, x17
    // 0x1265fec: b.ne            #0x1266004
    // 0x1265ff0: LoadField: r3 = r0->field_b
    //     0x1265ff0: ldur            w3, [x0, #0xb]
    // 0x1265ff4: DecompressPointer r3
    //     0x1265ff4: add             x3, x3, HEAP, lsl #32
    // 0x1265ff8: mov             x0, x1
    // 0x1265ffc: mov             x1, x3
    // 0x1266000: b               #0x1266094
    // 0x1266004: r17 = 5174
    //     0x1266004: mov             x17, #0x1436
    // 0x1266008: cmp             x2, x17
    // 0x126600c: b.ne            #0x1266054
    // 0x1266010: r1 = 1
    //     0x1266010: mov             x1, #1
    // 0x1266014: r0 = AllocateContext()
    //     0x1266014: bl              #0x13de838  ; AllocateContextStub
    // 0x1266018: mov             x1, x0
    // 0x126601c: ldr             x0, [fp, #0x18]
    // 0x1266020: StoreField: r1->field_f = r0
    //     0x1266020: stur            w0, [x1, #0xf]
    // 0x1266024: mov             x2, x1
    // 0x1266028: r1 = Function '<anonymous closure>':.
    //     0x1266028: add             x1, PP, #0x26, lsl #12  ; [pp+0x264a8] AnonymousClosure: (0xd144a8), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0x126602c: ldr             x1, [x1, #0x4a8]
    // 0x1266030: r0 = AllocateClosure()
    //     0x1266030: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1266034: r16 = <Color>
    //     0x1266034: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1266038: ldr             x16, [x16, #0xa90]
    // 0x126603c: stp             x0, x16, [SP]
    // 0x1266040: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1266040: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1266044: r0 = resolveWith()
    //     0x1266044: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1266048: mov             x1, x0
    // 0x126604c: ldur            x0, [fp, #-0x18]
    // 0x1266050: b               #0x1266094
    // 0x1266054: r1 = 1
    //     0x1266054: mov             x1, #1
    // 0x1266058: r0 = AllocateContext()
    //     0x1266058: bl              #0x13de838  ; AllocateContextStub
    // 0x126605c: mov             x1, x0
    // 0x1266060: ldr             x0, [fp, #0x18]
    // 0x1266064: StoreField: r1->field_f = r0
    //     0x1266064: stur            w0, [x1, #0xf]
    // 0x1266068: mov             x2, x1
    // 0x126606c: r1 = Function '<anonymous closure>':.
    //     0x126606c: add             x1, PP, #0x26, lsl #12  ; [pp+0x264b0] AnonymousClosure: (0xd14374), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0x1266070: ldr             x1, [x1, #0x4b0]
    // 0x1266074: r0 = AllocateClosure()
    //     0x1266074: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1266078: r16 = <Color>
    //     0x1266078: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x126607c: ldr             x16, [x16, #0xa90]
    // 0x1266080: stp             x0, x16, [SP]
    // 0x1266084: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1266084: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1266088: r0 = resolveWith()
    //     0x1266088: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x126608c: mov             x1, x0
    // 0x1266090: ldur            x0, [fp, #-0x18]
    // 0x1266094: cmp             w0, w1
    // 0x1266098: b.ne            #0x12668a4
    // 0x126609c: ldur            x0, [fp, #-8]
    // 0x12660a0: r17 = 5173
    //     0x12660a0: mov             x17, #0x1435
    // 0x12660a4: cmp             x0, x17
    // 0x12660a8: b.ne            #0x12660c0
    // 0x12660ac: ldr             x1, [fp, #0x10]
    // 0x12660b0: LoadField: r2 = r1->field_f
    //     0x12660b0: ldur            w2, [x1, #0xf]
    // 0x12660b4: DecompressPointer r2
    //     0x12660b4: add             x2, x2, HEAP, lsl #32
    // 0x12660b8: mov             x1, x2
    // 0x12660bc: b               #0x1266130
    // 0x12660c0: ldr             x1, [fp, #0x10]
    // 0x12660c4: r17 = 5174
    //     0x12660c4: mov             x17, #0x1436
    // 0x12660c8: cmp             x0, x17
    // 0x12660cc: b.ne            #0x1266110
    // 0x12660d0: r1 = 1
    //     0x12660d0: mov             x1, #1
    // 0x12660d4: r0 = AllocateContext()
    //     0x12660d4: bl              #0x13de838  ; AllocateContextStub
    // 0x12660d8: mov             x1, x0
    // 0x12660dc: ldr             x0, [fp, #0x10]
    // 0x12660e0: StoreField: r1->field_f = r0
    //     0x12660e0: stur            w0, [x1, #0xf]
    // 0x12660e4: mov             x2, x1
    // 0x12660e8: r1 = Function '<anonymous closure>':.
    //     0x12660e8: add             x1, PP, #0x26, lsl #12  ; [pp+0x264b8] AnonymousClosure: (0xd13524), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0x12660ec: ldr             x1, [x1, #0x4b8]
    // 0x12660f0: r0 = AllocateClosure()
    //     0x12660f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12660f4: r16 = <Color>
    //     0x12660f4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x12660f8: ldr             x16, [x16, #0xa90]
    // 0x12660fc: stp             x0, x16, [SP]
    // 0x1266100: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1266100: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1266104: r0 = resolveWith()
    //     0x1266104: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1266108: mov             x1, x0
    // 0x126610c: b               #0x1266130
    // 0x1266110: r16 = <Color>
    //     0x1266110: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1266114: ldr             x16, [x16, #0xa90]
    // 0x1266118: r30 = Instance_Color
    //     0x1266118: add             lr, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x126611c: ldr             lr, [lr, #0xc38]
    // 0x1266120: stp             lr, x16, [SP]
    // 0x1266124: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1266124: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1266128: r0 = all()
    //     0x1266128: bl              #0xd13288  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::all
    // 0x126612c: mov             x1, x0
    // 0x1266130: ldur            x0, [fp, #-0x10]
    // 0x1266134: stur            x1, [fp, #-0x18]
    // 0x1266138: r17 = 5173
    //     0x1266138: mov             x17, #0x1435
    // 0x126613c: cmp             x0, x17
    // 0x1266140: b.ne            #0x126615c
    // 0x1266144: ldr             x2, [fp, #0x18]
    // 0x1266148: LoadField: r3 = r2->field_f
    //     0x1266148: ldur            w3, [x2, #0xf]
    // 0x126614c: DecompressPointer r3
    //     0x126614c: add             x3, x3, HEAP, lsl #32
    // 0x1266150: mov             x0, x1
    // 0x1266154: mov             x1, x3
    // 0x1266158: b               #0x12661d4
    // 0x126615c: ldr             x2, [fp, #0x18]
    // 0x1266160: r17 = 5174
    //     0x1266160: mov             x17, #0x1436
    // 0x1266164: cmp             x0, x17
    // 0x1266168: b.ne            #0x12661b0
    // 0x126616c: r1 = 1
    //     0x126616c: mov             x1, #1
    // 0x1266170: r0 = AllocateContext()
    //     0x1266170: bl              #0x13de838  ; AllocateContextStub
    // 0x1266174: mov             x1, x0
    // 0x1266178: ldr             x0, [fp, #0x18]
    // 0x126617c: StoreField: r1->field_f = r0
    //     0x126617c: stur            w0, [x1, #0xf]
    // 0x1266180: mov             x2, x1
    // 0x1266184: r1 = Function '<anonymous closure>':.
    //     0x1266184: add             x1, PP, #0x26, lsl #12  ; [pp+0x264b8] AnonymousClosure: (0xd13524), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0x1266188: ldr             x1, [x1, #0x4b8]
    // 0x126618c: r0 = AllocateClosure()
    //     0x126618c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1266190: r16 = <Color>
    //     0x1266190: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1266194: ldr             x16, [x16, #0xa90]
    // 0x1266198: stp             x0, x16, [SP]
    // 0x126619c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x126619c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12661a0: r0 = resolveWith()
    //     0x12661a0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x12661a4: mov             x1, x0
    // 0x12661a8: ldur            x0, [fp, #-0x18]
    // 0x12661ac: b               #0x12661d4
    // 0x12661b0: r16 = <Color>
    //     0x12661b0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x12661b4: ldr             x16, [x16, #0xa90]
    // 0x12661b8: r30 = Instance_Color
    //     0x12661b8: add             lr, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x12661bc: ldr             lr, [lr, #0xc38]
    // 0x12661c0: stp             lr, x16, [SP]
    // 0x12661c4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12661c4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12661c8: r0 = all()
    //     0x12661c8: bl              #0xd13288  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::all
    // 0x12661cc: mov             x1, x0
    // 0x12661d0: ldur            x0, [fp, #-0x18]
    // 0x12661d4: r2 = LoadClassIdInstr(r0)
    //     0x12661d4: ldur            x2, [x0, #-1]
    //     0x12661d8: ubfx            x2, x2, #0xc, #0x14
    // 0x12661dc: stp             x1, x0, [SP]
    // 0x12661e0: mov             x0, x2
    // 0x12661e4: mov             lr, x0
    // 0x12661e8: ldr             lr, [x21, lr, lsl #3]
    // 0x12661ec: blr             lr
    // 0x12661f0: tbnz            w0, #4, #0x12668a4
    // 0x12661f4: ldur            x0, [fp, #-8]
    // 0x12661f8: r17 = 5173
    //     0x12661f8: mov             x17, #0x1435
    // 0x12661fc: cmp             x0, x17
    // 0x1266200: b.ne            #0x1266218
    // 0x1266204: ldr             x1, [fp, #0x10]
    // 0x1266208: LoadField: r2 = r1->field_13
    //     0x1266208: ldur            w2, [x1, #0x13]
    // 0x126620c: DecompressPointer r2
    //     0x126620c: add             x2, x2, HEAP, lsl #32
    // 0x1266210: mov             x1, x2
    // 0x1266214: b               #0x12662a8
    // 0x1266218: ldr             x1, [fp, #0x10]
    // 0x126621c: r17 = 5174
    //     0x126621c: mov             x17, #0x1436
    // 0x1266220: cmp             x0, x17
    // 0x1266224: b.ne            #0x1266268
    // 0x1266228: r1 = 1
    //     0x1266228: mov             x1, #1
    // 0x126622c: r0 = AllocateContext()
    //     0x126622c: bl              #0x13de838  ; AllocateContextStub
    // 0x1266230: mov             x1, x0
    // 0x1266234: ldr             x0, [fp, #0x10]
    // 0x1266238: StoreField: r1->field_f = r0
    //     0x1266238: stur            w0, [x1, #0xf]
    // 0x126623c: mov             x2, x1
    // 0x1266240: r1 = Function '<anonymous closure>':.
    //     0x1266240: add             x1, PP, #0x26, lsl #12  ; [pp+0x264c0] AnonymousClosure: (0xd13860), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0x1266244: ldr             x1, [x1, #0x4c0]
    // 0x1266248: r0 = AllocateClosure()
    //     0x1266248: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x126624c: r16 = <Color>
    //     0x126624c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1266250: ldr             x16, [x16, #0xa90]
    // 0x1266254: stp             x0, x16, [SP]
    // 0x1266258: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1266258: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x126625c: r0 = resolveWith()
    //     0x126625c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1266260: mov             x1, x0
    // 0x1266264: b               #0x12662a8
    // 0x1266268: mov             x0, x1
    // 0x126626c: r1 = 1
    //     0x126626c: mov             x1, #1
    // 0x1266270: r0 = AllocateContext()
    //     0x1266270: bl              #0x13de838  ; AllocateContextStub
    // 0x1266274: mov             x1, x0
    // 0x1266278: ldr             x0, [fp, #0x10]
    // 0x126627c: StoreField: r1->field_f = r0
    //     0x126627c: stur            w0, [x1, #0xf]
    // 0x1266280: mov             x2, x1
    // 0x1266284: r1 = Function '<anonymous closure>':.
    //     0x1266284: add             x1, PP, #0x26, lsl #12  ; [pp+0x264c8] AnonymousClosure: (0xd136b4), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0x1266288: ldr             x1, [x1, #0x4c8]
    // 0x126628c: r0 = AllocateClosure()
    //     0x126628c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1266290: r16 = <Color?>
    //     0x1266290: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1266294: ldr             x16, [x16, #0xa40]
    // 0x1266298: stp             x0, x16, [SP]
    // 0x126629c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x126629c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12662a0: r0 = resolveWith()
    //     0x12662a0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x12662a4: mov             x1, x0
    // 0x12662a8: ldur            x0, [fp, #-0x10]
    // 0x12662ac: stur            x1, [fp, #-0x18]
    // 0x12662b0: r17 = 5173
    //     0x12662b0: mov             x17, #0x1435
    // 0x12662b4: cmp             x0, x17
    // 0x12662b8: b.ne            #0x12662d4
    // 0x12662bc: ldr             x2, [fp, #0x18]
    // 0x12662c0: LoadField: r3 = r2->field_13
    //     0x12662c0: ldur            w3, [x2, #0x13]
    // 0x12662c4: DecompressPointer r3
    //     0x12662c4: add             x3, x3, HEAP, lsl #32
    // 0x12662c8: mov             x0, x1
    // 0x12662cc: mov             x1, x3
    // 0x12662d0: b               #0x126636c
    // 0x12662d4: ldr             x2, [fp, #0x18]
    // 0x12662d8: r17 = 5174
    //     0x12662d8: mov             x17, #0x1436
    // 0x12662dc: cmp             x0, x17
    // 0x12662e0: b.ne            #0x1266328
    // 0x12662e4: r1 = 1
    //     0x12662e4: mov             x1, #1
    // 0x12662e8: r0 = AllocateContext()
    //     0x12662e8: bl              #0x13de838  ; AllocateContextStub
    // 0x12662ec: mov             x1, x0
    // 0x12662f0: ldr             x0, [fp, #0x18]
    // 0x12662f4: StoreField: r1->field_f = r0
    //     0x12662f4: stur            w0, [x1, #0xf]
    // 0x12662f8: mov             x2, x1
    // 0x12662fc: r1 = Function '<anonymous closure>':.
    //     0x12662fc: add             x1, PP, #0x26, lsl #12  ; [pp+0x264c0] AnonymousClosure: (0xd13860), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0x1266300: ldr             x1, [x1, #0x4c0]
    // 0x1266304: r0 = AllocateClosure()
    //     0x1266304: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1266308: r16 = <Color>
    //     0x1266308: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x126630c: ldr             x16, [x16, #0xa90]
    // 0x1266310: stp             x0, x16, [SP]
    // 0x1266314: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1266314: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1266318: r0 = resolveWith()
    //     0x1266318: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x126631c: mov             x1, x0
    // 0x1266320: ldur            x0, [fp, #-0x18]
    // 0x1266324: b               #0x126636c
    // 0x1266328: mov             x0, x2
    // 0x126632c: r1 = 1
    //     0x126632c: mov             x1, #1
    // 0x1266330: r0 = AllocateContext()
    //     0x1266330: bl              #0x13de838  ; AllocateContextStub
    // 0x1266334: mov             x1, x0
    // 0x1266338: ldr             x0, [fp, #0x18]
    // 0x126633c: StoreField: r1->field_f = r0
    //     0x126633c: stur            w0, [x1, #0xf]
    // 0x1266340: mov             x2, x1
    // 0x1266344: r1 = Function '<anonymous closure>':.
    //     0x1266344: add             x1, PP, #0x26, lsl #12  ; [pp+0x264c8] AnonymousClosure: (0xd136b4), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0x1266348: ldr             x1, [x1, #0x4c8]
    // 0x126634c: r0 = AllocateClosure()
    //     0x126634c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1266350: r16 = <Color?>
    //     0x1266350: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1266354: ldr             x16, [x16, #0xa40]
    // 0x1266358: stp             x0, x16, [SP]
    // 0x126635c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x126635c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1266360: r0 = resolveWith()
    //     0x1266360: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1266364: mov             x1, x0
    // 0x1266368: ldur            x0, [fp, #-0x18]
    // 0x126636c: cmp             w0, w1
    // 0x1266370: b.ne            #0x12668a4
    // 0x1266374: ldur            x1, [fp, #-8]
    // 0x1266378: r17 = 5173
    //     0x1266378: mov             x17, #0x1435
    // 0x126637c: cmp             x1, x17
    // 0x1266380: b.ne            #0x1266394
    // 0x1266384: ldr             x2, [fp, #0x10]
    // 0x1266388: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x1266388: ldur            w0, [x2, #0x17]
    // 0x126638c: DecompressPointer r0
    //     0x126638c: add             x0, x0, HEAP, lsl #32
    // 0x1266390: b               #0x12663b8
    // 0x1266394: ldr             x2, [fp, #0x10]
    // 0x1266398: r17 = 5174
    //     0x1266398: mov             x17, #0x1436
    // 0x126639c: cmp             x1, x17
    // 0x12663a0: b.ne            #0x12663b0
    // 0x12663a4: r0 = 20.000000
    //     0x12663a4: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ae98] 20
    //     0x12663a8: ldr             x0, [x0, #0xe98]
    // 0x12663ac: b               #0x12663b8
    // 0x12663b0: r0 = 20.000000
    //     0x12663b0: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ae98] 20
    //     0x12663b4: ldr             x0, [x0, #0xe98]
    // 0x12663b8: ldur            x3, [fp, #-0x10]
    // 0x12663bc: r17 = 5173
    //     0x12663bc: mov             x17, #0x1435
    // 0x12663c0: cmp             x3, x17
    // 0x12663c4: b.ne            #0x12663d8
    // 0x12663c8: ldr             x4, [fp, #0x18]
    // 0x12663cc: ArrayLoad: r5 = r4[0]  ; List_4
    //     0x12663cc: ldur            w5, [x4, #0x17]
    // 0x12663d0: DecompressPointer r5
    //     0x12663d0: add             x5, x5, HEAP, lsl #32
    // 0x12663d4: b               #0x12663fc
    // 0x12663d8: ldr             x4, [fp, #0x18]
    // 0x12663dc: r17 = 5174
    //     0x12663dc: mov             x17, #0x1436
    // 0x12663e0: cmp             x3, x17
    // 0x12663e4: b.ne            #0x12663f4
    // 0x12663e8: r5 = 20.000000
    //     0x12663e8: add             x5, PP, #0x1a, lsl #12  ; [pp+0x1ae98] 20
    //     0x12663ec: ldr             x5, [x5, #0xe98]
    // 0x12663f0: b               #0x12663fc
    // 0x12663f4: r5 = 20.000000
    //     0x12663f4: add             x5, PP, #0x1a, lsl #12  ; [pp+0x1ae98] 20
    //     0x12663f8: ldr             x5, [x5, #0xe98]
    // 0x12663fc: r6 = LoadClassIdInstr(r0)
    //     0x12663fc: ldur            x6, [x0, #-1]
    //     0x1266400: ubfx            x6, x6, #0xc, #0x14
    // 0x1266404: stp             x5, x0, [SP]
    // 0x1266408: mov             x0, x6
    // 0x126640c: mov             lr, x0
    // 0x1266410: ldr             lr, [x21, lr, lsl #3]
    // 0x1266414: blr             lr
    // 0x1266418: tbnz            w0, #4, #0x12668a4
    // 0x126641c: ldur            x1, [fp, #-8]
    // 0x1266420: r17 = 5173
    //     0x1266420: mov             x17, #0x1435
    // 0x1266424: cmp             x1, x17
    // 0x1266428: b.ne            #0x126643c
    // 0x126642c: ldr             x2, [fp, #0x10]
    // 0x1266430: LoadField: r0 = r2->field_1b
    //     0x1266430: ldur            w0, [x2, #0x1b]
    // 0x1266434: DecompressPointer r0
    //     0x1266434: add             x0, x0, HEAP, lsl #32
    // 0x1266438: b               #0x1266478
    // 0x126643c: ldr             x2, [fp, #0x10]
    // 0x1266440: r17 = 5174
    //     0x1266440: mov             x17, #0x1436
    // 0x1266444: cmp             x1, x17
    // 0x1266448: b.ne            #0x1266464
    // 0x126644c: LoadField: r0 = r2->field_2b
    //     0x126644c: ldur            w0, [x2, #0x2b]
    // 0x1266450: DecompressPointer r0
    //     0x1266450: add             x0, x0, HEAP, lsl #32
    // 0x1266454: LoadField: r3 = r0->field_1b
    //     0x1266454: ldur            w3, [x0, #0x1b]
    // 0x1266458: DecompressPointer r3
    //     0x1266458: add             x3, x3, HEAP, lsl #32
    // 0x126645c: mov             x0, x3
    // 0x1266460: b               #0x1266478
    // 0x1266464: LoadField: r0 = r2->field_2b
    //     0x1266464: ldur            w0, [x2, #0x2b]
    // 0x1266468: DecompressPointer r0
    //     0x1266468: add             x0, x0, HEAP, lsl #32
    // 0x126646c: LoadField: r3 = r0->field_1b
    //     0x126646c: ldur            w3, [x0, #0x1b]
    // 0x1266470: DecompressPointer r3
    //     0x1266470: add             x3, x3, HEAP, lsl #32
    // 0x1266474: mov             x0, x3
    // 0x1266478: ldur            x3, [fp, #-0x10]
    // 0x126647c: r17 = 5173
    //     0x126647c: mov             x17, #0x1435
    // 0x1266480: cmp             x3, x17
    // 0x1266484: b.ne            #0x1266498
    // 0x1266488: ldr             x4, [fp, #0x18]
    // 0x126648c: LoadField: r5 = r4->field_1b
    //     0x126648c: ldur            w5, [x4, #0x1b]
    // 0x1266490: DecompressPointer r5
    //     0x1266490: add             x5, x5, HEAP, lsl #32
    // 0x1266494: b               #0x12664d4
    // 0x1266498: ldr             x4, [fp, #0x18]
    // 0x126649c: r17 = 5174
    //     0x126649c: mov             x17, #0x1436
    // 0x12664a0: cmp             x3, x17
    // 0x12664a4: b.ne            #0x12664c0
    // 0x12664a8: LoadField: r5 = r4->field_2b
    //     0x12664a8: ldur            w5, [x4, #0x2b]
    // 0x12664ac: DecompressPointer r5
    //     0x12664ac: add             x5, x5, HEAP, lsl #32
    // 0x12664b0: LoadField: r6 = r5->field_1b
    //     0x12664b0: ldur            w6, [x5, #0x1b]
    // 0x12664b4: DecompressPointer r6
    //     0x12664b4: add             x6, x6, HEAP, lsl #32
    // 0x12664b8: mov             x5, x6
    // 0x12664bc: b               #0x12664d4
    // 0x12664c0: LoadField: r5 = r4->field_2b
    //     0x12664c0: ldur            w5, [x4, #0x2b]
    // 0x12664c4: DecompressPointer r5
    //     0x12664c4: add             x5, x5, HEAP, lsl #32
    // 0x12664c8: LoadField: r6 = r5->field_1b
    //     0x12664c8: ldur            w6, [x5, #0x1b]
    // 0x12664cc: DecompressPointer r6
    //     0x12664cc: add             x6, x6, HEAP, lsl #32
    // 0x12664d0: mov             x5, x6
    // 0x12664d4: cmp             w0, w5
    // 0x12664d8: b.ne            #0x12668a4
    // 0x12664dc: r17 = 5173
    //     0x12664dc: mov             x17, #0x1435
    // 0x12664e0: cmp             x1, x17
    // 0x12664e4: b.ne            #0x12664f4
    // 0x12664e8: LoadField: r0 = r2->field_1f
    //     0x12664e8: ldur            w0, [x2, #0x1f]
    // 0x12664ec: DecompressPointer r0
    //     0x12664ec: add             x0, x0, HEAP, lsl #32
    // 0x12664f0: b               #0x1266520
    // 0x12664f4: r17 = 5174
    //     0x12664f4: mov             x17, #0x1436
    // 0x12664f8: cmp             x1, x17
    // 0x12664fc: b.ne            #0x126650c
    // 0x1266500: r0 = Instance_VisualDensity
    //     0x1266500: add             x0, PP, #0x12, lsl #12  ; [pp+0x12ef0] Obj!VisualDensity@12b1d61
    //     0x1266504: ldr             x0, [x0, #0xef0]
    // 0x1266508: b               #0x1266520
    // 0x126650c: LoadField: r0 = r2->field_2b
    //     0x126650c: ldur            w0, [x2, #0x2b]
    // 0x1266510: DecompressPointer r0
    //     0x1266510: add             x0, x0, HEAP, lsl #32
    // 0x1266514: LoadField: r5 = r0->field_33
    //     0x1266514: ldur            w5, [x0, #0x33]
    // 0x1266518: DecompressPointer r5
    //     0x1266518: add             x5, x5, HEAP, lsl #32
    // 0x126651c: mov             x0, x5
    // 0x1266520: r17 = 5173
    //     0x1266520: mov             x17, #0x1435
    // 0x1266524: cmp             x3, x17
    // 0x1266528: b.ne            #0x1266538
    // 0x126652c: LoadField: r5 = r4->field_1f
    //     0x126652c: ldur            w5, [x4, #0x1f]
    // 0x1266530: DecompressPointer r5
    //     0x1266530: add             x5, x5, HEAP, lsl #32
    // 0x1266534: b               #0x1266564
    // 0x1266538: r17 = 5174
    //     0x1266538: mov             x17, #0x1436
    // 0x126653c: cmp             x3, x17
    // 0x1266540: b.ne            #0x1266550
    // 0x1266544: r5 = Instance_VisualDensity
    //     0x1266544: add             x5, PP, #0x12, lsl #12  ; [pp+0x12ef0] Obj!VisualDensity@12b1d61
    //     0x1266548: ldr             x5, [x5, #0xef0]
    // 0x126654c: b               #0x1266564
    // 0x1266550: LoadField: r5 = r4->field_2b
    //     0x1266550: ldur            w5, [x4, #0x2b]
    // 0x1266554: DecompressPointer r5
    //     0x1266554: add             x5, x5, HEAP, lsl #32
    // 0x1266558: LoadField: r6 = r5->field_33
    //     0x1266558: ldur            w6, [x5, #0x33]
    // 0x126655c: DecompressPointer r6
    //     0x126655c: add             x6, x6, HEAP, lsl #32
    // 0x1266560: mov             x5, x6
    // 0x1266564: r6 = LoadClassIdInstr(r0)
    //     0x1266564: ldur            x6, [x0, #-1]
    //     0x1266568: ubfx            x6, x6, #0xc, #0x14
    // 0x126656c: stp             x5, x0, [SP]
    // 0x1266570: mov             x0, x6
    // 0x1266574: mov             lr, x0
    // 0x1266578: ldr             lr, [x21, lr, lsl #3]
    // 0x126657c: blr             lr
    // 0x1266580: tbnz            w0, #4, #0x12668a4
    // 0x1266584: ldur            x1, [fp, #-8]
    // 0x1266588: r17 = 5173
    //     0x1266588: mov             x17, #0x1435
    // 0x126658c: cmp             x1, x17
    // 0x1266590: b.ne            #0x12665a4
    // 0x1266594: ldr             x2, [fp, #0x10]
    // 0x1266598: LoadField: r0 = r2->field_23
    //     0x1266598: ldur            w0, [x2, #0x23]
    // 0x126659c: DecompressPointer r0
    //     0x126659c: add             x0, x0, HEAP, lsl #32
    // 0x12665a0: b               #0x12665c8
    // 0x12665a4: ldr             x2, [fp, #0x10]
    // 0x12665a8: r17 = 5174
    //     0x12665a8: mov             x17, #0x1436
    // 0x12665ac: cmp             x1, x17
    // 0x12665b0: b.ne            #0x12665c0
    // 0x12665b4: r0 = Instance_RoundedRectangleBorder
    //     0x12665b4: add             x0, PP, #0x26, lsl #12  ; [pp+0x264d0] Obj!RoundedRectangleBorder@129ec61
    //     0x12665b8: ldr             x0, [x0, #0x4d0]
    // 0x12665bc: b               #0x12665c8
    // 0x12665c0: r0 = Instance_RoundedRectangleBorder
    //     0x12665c0: add             x0, PP, #0x26, lsl #12  ; [pp+0x264d8] Obj!RoundedRectangleBorder@129ec51
    //     0x12665c4: ldr             x0, [x0, #0x4d8]
    // 0x12665c8: ldur            x3, [fp, #-0x10]
    // 0x12665cc: r17 = 5173
    //     0x12665cc: mov             x17, #0x1435
    // 0x12665d0: cmp             x3, x17
    // 0x12665d4: b.ne            #0x12665e8
    // 0x12665d8: ldr             x4, [fp, #0x18]
    // 0x12665dc: LoadField: r5 = r4->field_23
    //     0x12665dc: ldur            w5, [x4, #0x23]
    // 0x12665e0: DecompressPointer r5
    //     0x12665e0: add             x5, x5, HEAP, lsl #32
    // 0x12665e4: b               #0x126660c
    // 0x12665e8: ldr             x4, [fp, #0x18]
    // 0x12665ec: r17 = 5174
    //     0x12665ec: mov             x17, #0x1436
    // 0x12665f0: cmp             x3, x17
    // 0x12665f4: b.ne            #0x1266604
    // 0x12665f8: r5 = Instance_RoundedRectangleBorder
    //     0x12665f8: add             x5, PP, #0x26, lsl #12  ; [pp+0x264d0] Obj!RoundedRectangleBorder@129ec61
    //     0x12665fc: ldr             x5, [x5, #0x4d0]
    // 0x1266600: b               #0x126660c
    // 0x1266604: r5 = Instance_RoundedRectangleBorder
    //     0x1266604: add             x5, PP, #0x26, lsl #12  ; [pp+0x264d8] Obj!RoundedRectangleBorder@129ec51
    //     0x1266608: ldr             x5, [x5, #0x4d8]
    // 0x126660c: r6 = LoadClassIdInstr(r0)
    //     0x126660c: ldur            x6, [x0, #-1]
    //     0x1266610: ubfx            x6, x6, #0xc, #0x14
    // 0x1266614: stp             x5, x0, [SP]
    // 0x1266618: mov             x0, x6
    // 0x126661c: mov             lr, x0
    // 0x1266620: ldr             lr, [x21, lr, lsl #3]
    // 0x1266624: blr             lr
    // 0x1266628: tbnz            w0, #4, #0x12668a4
    // 0x126662c: ldur            x0, [fp, #-8]
    // 0x1266630: r17 = 5173
    //     0x1266630: mov             x17, #0x1435
    // 0x1266634: cmp             x0, x17
    // 0x1266638: b.ne            #0x1266668
    // 0x126663c: ldr             x1, [fp, #0x10]
    // 0x1266640: LoadField: r0 = r1->field_27
    //     0x1266640: ldur            w0, [x1, #0x27]
    // 0x1266644: DecompressPointer r0
    //     0x1266644: add             x0, x0, HEAP, lsl #32
    // 0x1266648: mov             x3, x0
    // 0x126664c: r1 = Instance_Color
    //     0x126664c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x1266650: ldr             x1, [x1, #0x948]
    // 0x1266654: r2 = Instance_BorderStyle
    //     0x1266654: add             x2, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x1266658: ldr             x2, [x2, #0xdc8]
    // 0x126665c: d0 = 1.000000
    //     0x126665c: fmov            d0, #1.00000000
    // 0x1266660: d1 = -1.000000
    //     0x1266660: fmov            d1, #-1.00000000
    // 0x1266664: b               #0x1266768
    // 0x1266668: ldr             x1, [fp, #0x10]
    // 0x126666c: r17 = 5174
    //     0x126666c: mov             x17, #0x1436
    // 0x1266670: cmp             x0, x17
    // 0x1266674: b.ne            #0x12666e4
    // 0x1266678: r1 = 1
    //     0x1266678: mov             x1, #1
    // 0x126667c: r0 = AllocateContext()
    //     0x126667c: bl              #0x13de838  ; AllocateContextStub
    // 0x1266680: mov             x1, x0
    // 0x1266684: ldr             x0, [fp, #0x10]
    // 0x1266688: stur            x1, [fp, #-0x18]
    // 0x126668c: StoreField: r1->field_f = r0
    //     0x126668c: stur            w0, [x1, #0xf]
    // 0x1266690: r0 = _WidgetStateBorderSide()
    //     0x1266690: bl              #0xd132d4  ; Allocate_WidgetStateBorderSideStub -> _WidgetStateBorderSide (size=0x24)
    // 0x1266694: ldur            x2, [fp, #-0x18]
    // 0x1266698: r1 = Function '<anonymous closure>':.
    //     0x1266698: add             x1, PP, #0x26, lsl #12  ; [pp+0x264e0] AnonymousClosure: (0xd13f0c), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0x126669c: ldr             x1, [x1, #0x4e0]
    // 0x12666a0: stur            x0, [fp, #-0x18]
    // 0x12666a4: r0 = AllocateClosure()
    //     0x12666a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12666a8: mov             x1, x0
    // 0x12666ac: ldur            x0, [fp, #-0x18]
    // 0x12666b0: StoreField: r0->field_1f = r1
    //     0x12666b0: stur            w1, [x0, #0x1f]
    // 0x12666b4: r1 = Instance_Color
    //     0x12666b4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x12666b8: ldr             x1, [x1, #0x948]
    // 0x12666bc: StoreField: r0->field_7 = r1
    //     0x12666bc: stur            w1, [x0, #7]
    // 0x12666c0: d0 = 1.000000
    //     0x12666c0: fmov            d0, #1.00000000
    // 0x12666c4: StoreField: r0->field_b = d0
    //     0x12666c4: stur            d0, [x0, #0xb]
    // 0x12666c8: r2 = Instance_BorderStyle
    //     0x12666c8: add             x2, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x12666cc: ldr             x2, [x2, #0xdc8]
    // 0x12666d0: StoreField: r0->field_13 = r2
    //     0x12666d0: stur            w2, [x0, #0x13]
    // 0x12666d4: d1 = -1.000000
    //     0x12666d4: fmov            d1, #-1.00000000
    // 0x12666d8: ArrayStore: r0[0] = d1  ; List_8
    //     0x12666d8: stur            d1, [x0, #0x17]
    // 0x12666dc: mov             x3, x0
    // 0x12666e0: b               #0x1266768
    // 0x12666e4: mov             x0, x1
    // 0x12666e8: r1 = Instance_Color
    //     0x12666e8: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x12666ec: ldr             x1, [x1, #0x948]
    // 0x12666f0: r2 = Instance_BorderStyle
    //     0x12666f0: add             x2, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x12666f4: ldr             x2, [x2, #0xdc8]
    // 0x12666f8: d0 = 1.000000
    //     0x12666f8: fmov            d0, #1.00000000
    // 0x12666fc: d1 = -1.000000
    //     0x12666fc: fmov            d1, #-1.00000000
    // 0x1266700: r1 = 1
    //     0x1266700: mov             x1, #1
    // 0x1266704: r0 = AllocateContext()
    //     0x1266704: bl              #0x13de838  ; AllocateContextStub
    // 0x1266708: mov             x1, x0
    // 0x126670c: ldr             x0, [fp, #0x10]
    // 0x1266710: stur            x1, [fp, #-0x18]
    // 0x1266714: StoreField: r1->field_f = r0
    //     0x1266714: stur            w0, [x1, #0xf]
    // 0x1266718: r0 = _WidgetStateBorderSide()
    //     0x1266718: bl              #0xd132d4  ; Allocate_WidgetStateBorderSideStub -> _WidgetStateBorderSide (size=0x24)
    // 0x126671c: ldur            x2, [fp, #-0x18]
    // 0x1266720: r1 = Function '<anonymous closure>':.
    //     0x1266720: add             x1, PP, #0x26, lsl #12  ; [pp+0x264e8] AnonymousClosure: (0xd13d68), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0x1266724: ldr             x1, [x1, #0x4e8]
    // 0x1266728: stur            x0, [fp, #-0x18]
    // 0x126672c: r0 = AllocateClosure()
    //     0x126672c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1266730: mov             x1, x0
    // 0x1266734: ldur            x0, [fp, #-0x18]
    // 0x1266738: StoreField: r0->field_1f = r1
    //     0x1266738: stur            w1, [x0, #0x1f]
    // 0x126673c: r1 = Instance_Color
    //     0x126673c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x1266740: ldr             x1, [x1, #0x948]
    // 0x1266744: StoreField: r0->field_7 = r1
    //     0x1266744: stur            w1, [x0, #7]
    // 0x1266748: d0 = 1.000000
    //     0x1266748: fmov            d0, #1.00000000
    // 0x126674c: StoreField: r0->field_b = d0
    //     0x126674c: stur            d0, [x0, #0xb]
    // 0x1266750: r2 = Instance_BorderStyle
    //     0x1266750: add             x2, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x1266754: ldr             x2, [x2, #0xdc8]
    // 0x1266758: StoreField: r0->field_13 = r2
    //     0x1266758: stur            w2, [x0, #0x13]
    // 0x126675c: d1 = -1.000000
    //     0x126675c: fmov            d1, #-1.00000000
    // 0x1266760: ArrayStore: r0[0] = d1  ; List_8
    //     0x1266760: stur            d1, [x0, #0x17]
    // 0x1266764: mov             x3, x0
    // 0x1266768: ldur            x0, [fp, #-0x10]
    // 0x126676c: stur            x3, [fp, #-0x18]
    // 0x1266770: r17 = 5173
    //     0x1266770: mov             x17, #0x1435
    // 0x1266774: cmp             x0, x17
    // 0x1266778: b.ne            #0x1266794
    // 0x126677c: ldr             x4, [fp, #0x18]
    // 0x1266780: LoadField: r0 = r4->field_27
    //     0x1266780: ldur            w0, [x4, #0x27]
    // 0x1266784: DecompressPointer r0
    //     0x1266784: add             x0, x0, HEAP, lsl #32
    // 0x1266788: mov             x1, x0
    // 0x126678c: mov             x0, x3
    // 0x1266790: b               #0x1266884
    // 0x1266794: ldr             x4, [fp, #0x18]
    // 0x1266798: r17 = 5174
    //     0x1266798: mov             x17, #0x1436
    // 0x126679c: cmp             x0, x17
    // 0x12667a0: b.ne            #0x1266814
    // 0x12667a4: r1 = 1
    //     0x12667a4: mov             x1, #1
    // 0x12667a8: r0 = AllocateContext()
    //     0x12667a8: bl              #0x13de838  ; AllocateContextStub
    // 0x12667ac: mov             x1, x0
    // 0x12667b0: ldr             x0, [fp, #0x18]
    // 0x12667b4: stur            x1, [fp, #-0x20]
    // 0x12667b8: StoreField: r1->field_f = r0
    //     0x12667b8: stur            w0, [x1, #0xf]
    // 0x12667bc: r0 = _WidgetStateBorderSide()
    //     0x12667bc: bl              #0xd132d4  ; Allocate_WidgetStateBorderSideStub -> _WidgetStateBorderSide (size=0x24)
    // 0x12667c0: ldur            x2, [fp, #-0x20]
    // 0x12667c4: r1 = Function '<anonymous closure>':.
    //     0x12667c4: add             x1, PP, #0x26, lsl #12  ; [pp+0x264e0] AnonymousClosure: (0xd13f0c), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0x12667c8: ldr             x1, [x1, #0x4e0]
    // 0x12667cc: stur            x0, [fp, #-0x20]
    // 0x12667d0: r0 = AllocateClosure()
    //     0x12667d0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12667d4: mov             x1, x0
    // 0x12667d8: ldur            x0, [fp, #-0x20]
    // 0x12667dc: StoreField: r0->field_1f = r1
    //     0x12667dc: stur            w1, [x0, #0x1f]
    // 0x12667e0: r1 = Instance_Color
    //     0x12667e0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x12667e4: ldr             x1, [x1, #0x948]
    // 0x12667e8: StoreField: r0->field_7 = r1
    //     0x12667e8: stur            w1, [x0, #7]
    // 0x12667ec: d0 = 1.000000
    //     0x12667ec: fmov            d0, #1.00000000
    // 0x12667f0: StoreField: r0->field_b = d0
    //     0x12667f0: stur            d0, [x0, #0xb]
    // 0x12667f4: r2 = Instance_BorderStyle
    //     0x12667f4: add             x2, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x12667f8: ldr             x2, [x2, #0xdc8]
    // 0x12667fc: StoreField: r0->field_13 = r2
    //     0x12667fc: stur            w2, [x0, #0x13]
    // 0x1266800: d1 = -1.000000
    //     0x1266800: fmov            d1, #-1.00000000
    // 0x1266804: ArrayStore: r0[0] = d1  ; List_8
    //     0x1266804: stur            d1, [x0, #0x17]
    // 0x1266808: mov             x1, x0
    // 0x126680c: ldur            x0, [fp, #-0x18]
    // 0x1266810: b               #0x1266884
    // 0x1266814: mov             x0, x4
    // 0x1266818: r1 = 1
    //     0x1266818: mov             x1, #1
    // 0x126681c: r0 = AllocateContext()
    //     0x126681c: bl              #0x13de838  ; AllocateContextStub
    // 0x1266820: mov             x1, x0
    // 0x1266824: ldr             x0, [fp, #0x18]
    // 0x1266828: stur            x1, [fp, #-0x20]
    // 0x126682c: StoreField: r1->field_f = r0
    //     0x126682c: stur            w0, [x1, #0xf]
    // 0x1266830: r0 = _WidgetStateBorderSide()
    //     0x1266830: bl              #0xd132d4  ; Allocate_WidgetStateBorderSideStub -> _WidgetStateBorderSide (size=0x24)
    // 0x1266834: ldur            x2, [fp, #-0x20]
    // 0x1266838: r1 = Function '<anonymous closure>':.
    //     0x1266838: add             x1, PP, #0x26, lsl #12  ; [pp+0x264e8] AnonymousClosure: (0xd13d68), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0x126683c: ldr             x1, [x1, #0x4e8]
    // 0x1266840: stur            x0, [fp, #-0x20]
    // 0x1266844: r0 = AllocateClosure()
    //     0x1266844: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1266848: mov             x1, x0
    // 0x126684c: ldur            x0, [fp, #-0x20]
    // 0x1266850: StoreField: r0->field_1f = r1
    //     0x1266850: stur            w1, [x0, #0x1f]
    // 0x1266854: r1 = Instance_Color
    //     0x1266854: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x1266858: ldr             x1, [x1, #0x948]
    // 0x126685c: StoreField: r0->field_7 = r1
    //     0x126685c: stur            w1, [x0, #7]
    // 0x1266860: d0 = 1.000000
    //     0x1266860: fmov            d0, #1.00000000
    // 0x1266864: StoreField: r0->field_b = d0
    //     0x1266864: stur            d0, [x0, #0xb]
    // 0x1266868: r1 = Instance_BorderStyle
    //     0x1266868: add             x1, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x126686c: ldr             x1, [x1, #0xdc8]
    // 0x1266870: StoreField: r0->field_13 = r1
    //     0x1266870: stur            w1, [x0, #0x13]
    // 0x1266874: d0 = -1.000000
    //     0x1266874: fmov            d0, #-1.00000000
    // 0x1266878: ArrayStore: r0[0] = d0  ; List_8
    //     0x1266878: stur            d0, [x0, #0x17]
    // 0x126687c: mov             x1, x0
    // 0x1266880: ldur            x0, [fp, #-0x18]
    // 0x1266884: r2 = LoadClassIdInstr(r0)
    //     0x1266884: ldur            x2, [x0, #-1]
    //     0x1266888: ubfx            x2, x2, #0xc, #0x14
    // 0x126688c: stp             x1, x0, [SP]
    // 0x1266890: mov             x0, x2
    // 0x1266894: mov             lr, x0
    // 0x1266898: ldr             lr, [x21, lr, lsl #3]
    // 0x126689c: blr             lr
    // 0x12668a0: b               #0x12668a8
    // 0x12668a4: r0 = false
    //     0x12668a4: add             x0, NULL, #0x30  ; false
    // 0x12668a8: LeaveFrame
    //     0x12668a8: mov             SP, fp
    //     0x12668ac: ldp             fp, lr, [SP], #0x10
    // 0x12668b0: ret
    //     0x12668b0: ret             
    // 0x12668b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12668b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12668b8: b               #0x1265eb0
  }
}

// class id: 6817, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class CheckboxTheme extends InheritedWidget {

  static _ of(/* No info */) {
    // ** addr: 0xd13360, size: 0x58
    // 0xd13360: EnterFrame
    //     0xd13360: stp             fp, lr, [SP, #-0x10]!
    //     0xd13364: mov             fp, SP
    // 0xd13368: AllocStack(0x18)
    //     0xd13368: sub             SP, SP, #0x18
    // 0xd1336c: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xd1336c: stur            x1, [fp, #-8]
    // 0xd13370: CheckStackOverflow
    //     0xd13370: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd13374: cmp             SP, x16
    //     0xd13378: b.ls            #0xd133b0
    // 0xd1337c: r16 = <CheckboxTheme>
    //     0xd1337c: add             x16, PP, #0x90, lsl #12  ; [pp+0x904e0] TypeArguments: <CheckboxTheme>
    //     0xd13380: ldr             x16, [x16, #0x4e0]
    // 0xd13384: stp             x1, x16, [SP]
    // 0xd13388: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd13388: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd1338c: r0 = dependOnInheritedWidgetOfExactType()
    //     0xd1338c: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xd13390: ldur            x1, [fp, #-8]
    // 0xd13394: r0 = of()
    //     0xd13394: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd13398: LoadField: r1 = r0->field_b7
    //     0xd13398: ldur            w1, [x0, #0xb7]
    // 0xd1339c: DecompressPointer r1
    //     0xd1339c: add             x1, x1, HEAP, lsl #32
    // 0xd133a0: mov             x0, x1
    // 0xd133a4: LeaveFrame
    //     0xd133a4: mov             SP, fp
    //     0xd133a8: ldp             fp, lr, [SP], #0x10
    // 0xd133ac: ret
    //     0xd133ac: ret             
    // 0xd133b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd133b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd133b4: b               #0xd1337c
  }
}
