// lib: , url: package:flutter/src/material/floating_action_button.dart

// class id: 1048895, size: 0x8
class :: {
}

// class id: 3102, size: 0x8, field offset: 0x8
//   const constructor, 
class _DefaultHeroTag extends Object {
}

// class id: 4888, size: 0x60, field offset: 0x60
class _RenderChildOverflowBox extends RenderAligningShiftedBox {

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb16cc8, size: 0x24
    // 0xb16cc8: EnterFrame
    //     0xb16cc8: stp             fp, lr, [SP, #-0x10]!
    //     0xb16ccc: mov             fp, SP
    // 0xb16cd0: ldr             x2, [fp, #0x10]
    // 0xb16cd4: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb16cd4: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0ef0] AnonymousClosure: static (0x12ffab4), in [package:material_color_utilities/dynamiccolor/material_dynamic_colors.dart] MaterialDynamicColors::scrim (0x8b98ec)
    //     0xb16cd8: ldr             x1, [x1, #0xef0]
    // 0xb16cdc: r0 = AllocateClosure()
    //     0xb16cdc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb16ce0: LeaveFrame
    //     0xb16ce0: mov             SP, fp
    //     0xb16ce4: ldp             fp, lr, [SP], #0x10
    // 0xb16ce8: ret
    //     0xb16ce8: ret             
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4d1c4, size: 0xe0
    // 0xb4d1c4: EnterFrame
    //     0xb4d1c4: stp             fp, lr, [SP, #-0x10]!
    //     0xb4d1c8: mov             fp, SP
    // 0xb4d1cc: AllocStack(0x18)
    //     0xb4d1cc: sub             SP, SP, #0x18
    // 0xb4d1d0: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xb4d1d0: mov             x0, x2
    //     0xb4d1d4: stur            x2, [fp, #-8]
    // 0xb4d1d8: CheckStackOverflow
    //     0xb4d1d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4d1dc: cmp             SP, x16
    //     0xb4d1e0: b.ls            #0xb4d29c
    // 0xb4d1e4: LoadField: r2 = r1->field_4f
    //     0xb4d1e4: ldur            w2, [x1, #0x4f]
    // 0xb4d1e8: DecompressPointer r2
    //     0xb4d1e8: add             x2, x2, HEAP, lsl #32
    // 0xb4d1ec: cmp             w2, NULL
    // 0xb4d1f0: b.eq            #0xb4d25c
    // 0xb4d1f4: mov             x1, x2
    // 0xb4d1f8: r2 = Instance_BoxConstraints
    //     0xb4d1f8: add             x2, PP, #0x7d, lsl #12  ; [pp+0x7d0f0] Obj!BoxConstraints@129c1d1
    //     0xb4d1fc: ldr             x2, [x2, #0xf0]
    // 0xb4d200: r0 = getDryLayout()
    //     0xb4d200: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb4d204: mov             x1, x0
    // 0xb4d208: ldur            x0, [fp, #-8]
    // 0xb4d20c: LoadField: d0 = r0->field_7
    //     0xb4d20c: ldur            d0, [x0, #7]
    // 0xb4d210: LoadField: d1 = r0->field_f
    //     0xb4d210: ldur            d1, [x0, #0xf]
    // 0xb4d214: LoadField: d2 = r1->field_7
    //     0xb4d214: ldur            d2, [x1, #7]
    // 0xb4d218: fmin            v3.2d, v1.2d, v2.2d
    // 0xb4d21c: fmax            v1.2d, v0.2d, v3.2d
    // 0xb4d220: stur            d1, [fp, #-0x18]
    // 0xb4d224: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xb4d224: ldur            d0, [x0, #0x17]
    // 0xb4d228: LoadField: d2 = r0->field_1f
    //     0xb4d228: ldur            d2, [x0, #0x1f]
    // 0xb4d22c: LoadField: d3 = r1->field_f
    //     0xb4d22c: ldur            d3, [x1, #0xf]
    // 0xb4d230: fmin            v4.2d, v2.2d, v3.2d
    // 0xb4d234: fmax            v2.2d, v0.2d, v4.2d
    // 0xb4d238: stur            d2, [fp, #-0x10]
    // 0xb4d23c: r0 = Size()
    //     0xb4d23c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb4d240: ldur            d0, [fp, #-0x18]
    // 0xb4d244: StoreField: r0->field_7 = d0
    //     0xb4d244: stur            d0, [x0, #7]
    // 0xb4d248: ldur            d0, [fp, #-0x10]
    // 0xb4d24c: StoreField: r0->field_f = d0
    //     0xb4d24c: stur            d0, [x0, #0xf]
    // 0xb4d250: LeaveFrame
    //     0xb4d250: mov             SP, fp
    //     0xb4d254: ldp             fp, lr, [SP], #0x10
    // 0xb4d258: ret
    //     0xb4d258: ret             
    // 0xb4d25c: mov             x1, x0
    // 0xb4d260: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb4d260: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb4d264: r0 = constrainWidth()
    //     0xb4d264: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xb4d268: ldur            x1, [fp, #-8]
    // 0xb4d26c: stur            d0, [fp, #-0x10]
    // 0xb4d270: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb4d270: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb4d274: r0 = constrainHeight()
    //     0xb4d274: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xb4d278: stur            d0, [fp, #-0x18]
    // 0xb4d27c: r0 = Size()
    //     0xb4d27c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb4d280: ldur            d0, [fp, #-0x10]
    // 0xb4d284: StoreField: r0->field_7 = d0
    //     0xb4d284: stur            d0, [x0, #7]
    // 0xb4d288: ldur            d0, [fp, #-0x18]
    // 0xb4d28c: StoreField: r0->field_f = d0
    //     0xb4d28c: stur            d0, [x0, #0xf]
    // 0xb4d290: LeaveFrame
    //     0xb4d290: mov             SP, fp
    //     0xb4d294: ldp             fp, lr, [SP], #0x10
    // 0xb4d298: ret
    //     0xb4d298: ret             
    // 0xb4d29c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4d29c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4d2a0: b               #0xb4d1e4
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbbb010, size: 0x20c
    // 0xbbb010: EnterFrame
    //     0xbbb010: stp             fp, lr, [SP, #-0x10]!
    //     0xbbb014: mov             fp, SP
    // 0xbbb018: AllocStack(0x30)
    //     0xbbb018: sub             SP, SP, #0x30
    // 0xbbb01c: SetupParameters(_RenderChildOverflowBox this /* r1 => r3, fp-0x10 */)
    //     0xbbb01c: mov             x3, x1
    //     0xbbb020: stur            x1, [fp, #-0x10]
    // 0xbbb024: CheckStackOverflow
    //     0xbbb024: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbb028: cmp             SP, x16
    //     0xbbb02c: b.ls            #0xbbb20c
    // 0xbbb030: LoadField: r4 = r3->field_27
    //     0xbbb030: ldur            w4, [x3, #0x27]
    // 0xbbb034: DecompressPointer r4
    //     0xbbb034: add             x4, x4, HEAP, lsl #32
    // 0xbbb038: stur            x4, [fp, #-8]
    // 0xbbb03c: cmp             w4, NULL
    // 0xbbb040: b.eq            #0xbbb1f0
    // 0xbbb044: mov             x0, x4
    // 0xbbb048: r2 = Null
    //     0xbbb048: mov             x2, NULL
    // 0xbbb04c: r1 = Null
    //     0xbbb04c: mov             x1, NULL
    // 0xbbb050: r4 = LoadClassIdInstr(r0)
    //     0xbbb050: ldur            x4, [x0, #-1]
    //     0xbbb054: ubfx            x4, x4, #0xc, #0x14
    // 0xbbb058: sub             x4, x4, #0xb46
    // 0xbbb05c: cmp             x4, #1
    // 0xbbb060: b.ls            #0xbbb074
    // 0xbbb064: r8 = BoxConstraints
    //     0xbbb064: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbb068: r3 = Null
    //     0xbbb068: add             x3, PP, #0x95, lsl #12  ; [pp+0x95c70] Null
    //     0xbbb06c: ldr             x3, [x3, #0xc70]
    // 0xbbb070: r0 = BoxConstraints()
    //     0xbbb070: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbb074: ldur            x3, [fp, #-0x10]
    // 0xbbb078: LoadField: r1 = r3->field_4f
    //     0xbbb078: ldur            w1, [x3, #0x4f]
    // 0xbbb07c: DecompressPointer r1
    //     0xbbb07c: add             x1, x1, HEAP, lsl #32
    // 0xbbb080: cmp             w1, NULL
    // 0xbbb084: b.eq            #0xbbb184
    // 0xbbb088: ldur            x4, [fp, #-8]
    // 0xbbb08c: r0 = LoadClassIdInstr(r1)
    //     0xbbb08c: ldur            x0, [x1, #-1]
    //     0xbbb090: ubfx            x0, x0, #0xc, #0x14
    // 0xbbb094: r16 = true
    //     0xbbb094: add             x16, NULL, #0x20  ; true
    // 0xbbb098: str             x16, [SP]
    // 0xbbb09c: r2 = Instance_BoxConstraints
    //     0xbbb09c: add             x2, PP, #0x7d, lsl #12  ; [pp+0x7d0f0] Obj!BoxConstraints@129c1d1
    //     0xbbb0a0: ldr             x2, [x2, #0xf0]
    // 0xbbb0a4: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbbb0a4: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbbb0a8: ldr             x4, [x4, #0xed0]
    // 0xbbb0ac: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbbb0ac: mov             x17, #0xe6b9
    //     0xbbb0b0: add             lr, x0, x17
    //     0xbbb0b4: ldr             lr, [x21, lr, lsl #3]
    //     0xbbb0b8: blr             lr
    // 0xbbb0bc: ldur            x0, [fp, #-8]
    // 0xbbb0c0: LoadField: d0 = r0->field_7
    //     0xbbb0c0: ldur            d0, [x0, #7]
    // 0xbbb0c4: stur            d0, [fp, #-0x20]
    // 0xbbb0c8: LoadField: d1 = r0->field_f
    //     0xbbb0c8: ldur            d1, [x0, #0xf]
    // 0xbbb0cc: ldur            x2, [fp, #-0x10]
    // 0xbbb0d0: stur            d1, [fp, #-0x18]
    // 0xbbb0d4: LoadField: r1 = r2->field_4f
    //     0xbbb0d4: ldur            w1, [x2, #0x4f]
    // 0xbbb0d8: DecompressPointer r1
    //     0xbbb0d8: add             x1, x1, HEAP, lsl #32
    // 0xbbb0dc: cmp             w1, NULL
    // 0xbbb0e0: b.eq            #0xbbb214
    // 0xbbb0e4: r0 = size()
    //     0xbbb0e4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbb0e8: LoadField: d0 = r0->field_7
    //     0xbbb0e8: ldur            d0, [x0, #7]
    // 0xbbb0ec: ldur            d1, [fp, #-0x18]
    // 0xbbb0f0: fmin            v2.2d, v1.2d, v0.2d
    // 0xbbb0f4: ldur            d0, [fp, #-0x20]
    // 0xbbb0f8: fmax            v1.2d, v0.2d, v2.2d
    // 0xbbb0fc: ldur            x0, [fp, #-8]
    // 0xbbb100: stur            d1, [fp, #-0x28]
    // 0xbbb104: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xbbb104: ldur            d0, [x0, #0x17]
    // 0xbbb108: stur            d0, [fp, #-0x20]
    // 0xbbb10c: LoadField: d2 = r0->field_1f
    //     0xbbb10c: ldur            d2, [x0, #0x1f]
    // 0xbbb110: ldur            x0, [fp, #-0x10]
    // 0xbbb114: stur            d2, [fp, #-0x18]
    // 0xbbb118: LoadField: r1 = r0->field_4f
    //     0xbbb118: ldur            w1, [x0, #0x4f]
    // 0xbbb11c: DecompressPointer r1
    //     0xbbb11c: add             x1, x1, HEAP, lsl #32
    // 0xbbb120: cmp             w1, NULL
    // 0xbbb124: b.eq            #0xbbb218
    // 0xbbb128: r0 = size()
    //     0xbbb128: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbb12c: LoadField: d0 = r0->field_f
    //     0xbbb12c: ldur            d0, [x0, #0xf]
    // 0xbbb130: ldur            d1, [fp, #-0x18]
    // 0xbbb134: fmin            v2.2d, v1.2d, v0.2d
    // 0xbbb138: ldur            d0, [fp, #-0x20]
    // 0xbbb13c: fmax            v1.2d, v0.2d, v2.2d
    // 0xbbb140: stur            d1, [fp, #-0x18]
    // 0xbbb144: r0 = Size()
    //     0xbbb144: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbbb148: ldur            d0, [fp, #-0x28]
    // 0xbbb14c: StoreField: r0->field_7 = d0
    //     0xbbb14c: stur            d0, [x0, #7]
    // 0xbbb150: ldur            d0, [fp, #-0x18]
    // 0xbbb154: StoreField: r0->field_f = d0
    //     0xbbb154: stur            d0, [x0, #0xf]
    // 0xbbb158: ldur            x2, [fp, #-0x10]
    // 0xbbb15c: StoreField: r2->field_4b = r0
    //     0xbbb15c: stur            w0, [x2, #0x4b]
    //     0xbbb160: ldurb           w16, [x2, #-1]
    //     0xbbb164: ldurb           w17, [x0, #-1]
    //     0xbbb168: and             x16, x17, x16, lsr #2
    //     0xbbb16c: tst             x16, HEAP, lsr #32
    //     0xbbb170: b.eq            #0xbbb178
    //     0xbbb174: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbbb178: mov             x1, x2
    // 0xbbb17c: r0 = alignChild()
    //     0xbbb17c: bl              #0xbbad50  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::alignChild
    // 0xbbb180: b               #0xbbb1e0
    // 0xbbb184: mov             x2, x3
    // 0xbbb188: ldur            x0, [fp, #-8]
    // 0xbbb18c: mov             x1, x0
    // 0xbbb190: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xbbb190: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xbbb194: r0 = constrainWidth()
    //     0xbbb194: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xbbb198: ldur            x1, [fp, #-8]
    // 0xbbb19c: stur            d0, [fp, #-0x18]
    // 0xbbb1a0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xbbb1a0: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xbbb1a4: r0 = constrainHeight()
    //     0xbbb1a4: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xbbb1a8: stur            d0, [fp, #-0x20]
    // 0xbbb1ac: r0 = Size()
    //     0xbbb1ac: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbbb1b0: ldur            d0, [fp, #-0x18]
    // 0xbbb1b4: StoreField: r0->field_7 = d0
    //     0xbbb1b4: stur            d0, [x0, #7]
    // 0xbbb1b8: ldur            d0, [fp, #-0x20]
    // 0xbbb1bc: StoreField: r0->field_f = d0
    //     0xbbb1bc: stur            d0, [x0, #0xf]
    // 0xbbb1c0: ldur            x1, [fp, #-0x10]
    // 0xbbb1c4: StoreField: r1->field_4b = r0
    //     0xbbb1c4: stur            w0, [x1, #0x4b]
    //     0xbbb1c8: ldurb           w16, [x1, #-1]
    //     0xbbb1cc: ldurb           w17, [x0, #-1]
    //     0xbbb1d0: and             x16, x17, x16, lsr #2
    //     0xbbb1d4: tst             x16, HEAP, lsr #32
    //     0xbbb1d8: b.eq            #0xbbb1e0
    //     0xbbb1dc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbb1e0: r0 = Null
    //     0xbbb1e0: mov             x0, NULL
    // 0xbbb1e4: LeaveFrame
    //     0xbbb1e4: mov             SP, fp
    //     0xbbb1e8: ldp             fp, lr, [SP], #0x10
    // 0xbbb1ec: ret
    //     0xbbb1ec: ret             
    // 0xbbb1f0: r0 = StateError()
    //     0xbbb1f0: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbb1f4: mov             x1, x0
    // 0xbbb1f8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbb1f8: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbb1fc: StoreField: r1->field_b = r0
    //     0xbbb1fc: stur            w0, [x1, #0xb]
    // 0xbbb200: mov             x0, x1
    // 0xbbb204: r0 = Throw()
    //     0xbbb204: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbb208: brk             #0
    // 0xbbb20c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbb20c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbb210: b               #0xbbb030
    // 0xbbb214: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbbb214: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbbb218: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbbb218: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10efc04, size: 0x24
    // 0x10efc04: EnterFrame
    //     0x10efc04: stp             fp, lr, [SP, #-0x10]!
    //     0x10efc08: mov             fp, SP
    // 0x10efc0c: ldr             x2, [fp, #0x10]
    // 0x10efc10: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10efc10: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0ee8] AnonymousClosure: static (0x12ffab4), in [package:material_color_utilities/dynamiccolor/material_dynamic_colors.dart] MaterialDynamicColors::scrim (0x8b98ec)
    //     0x10efc14: ldr             x1, [x1, #0xee8]
    // 0x10efc18: r0 = AllocateClosure()
    //     0x10efc18: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10efc1c: LeaveFrame
    //     0x10efc1c: mov             SP, fp
    //     0x10efc20: ldp             fp, lr, [SP], #0x10
    // 0x10efc24: ret
    //     0x10efc24: ret             
  }
}

// class id: 5149, size: 0x70, field offset: 0x5c
class _FABDefaultsM3 extends FloatingActionButtonThemeData {

  late final ColorScheme _colors; // offset: 0x68
  late final TextTheme _textTheme; // offset: 0x6c

  _ _FABDefaultsM3(/* No info */) {
    // ** addr: 0xfbb128, size: 0xa8
    // 0xfbb128: ldr             x11, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbb12c: r10 = Instance__FloatingActionButtonType
    //     0xfbb12c: add             x10, PP, #0x19, lsl #12  ; [pp+0x19660] Obj!_FloatingActionButtonType@12c57c1
    //     0xfbb130: ldr             x10, [x10, #0x660]
    // 0xfbb134: r9 = true
    //     0xfbb134: add             x9, NULL, #0x20  ; true
    // 0xfbb138: r8 = 6.000000
    //     0xfbb138: add             x8, PP, #0x1c, lsl #12  ; [pp+0x1c438] 6
    //     0xfbb13c: ldr             x8, [x8, #0x438]
    // 0xfbb140: r7 = 8.000000
    //     0xfbb140: add             x7, PP, #0x19, lsl #12  ; [pp+0x19e08] 8
    //     0xfbb144: ldr             x7, [x7, #0xe08]
    // 0xfbb148: r6 = Instance_BoxConstraints
    //     0xfbb148: add             x6, PP, #0x80, lsl #12  ; [pp+0x80988] Obj!BoxConstraints@129c561
    //     0xfbb14c: ldr             x6, [x6, #0x988]
    // 0xfbb150: r5 = Instance_BoxConstraints
    //     0xfbb150: add             x5, PP, #0x80, lsl #12  ; [pp+0x80978] Obj!BoxConstraints@129c4d1
    //     0xfbb154: ldr             x5, [x5, #0x978]
    // 0xfbb158: r4 = Instance_BoxConstraints
    //     0xfbb158: add             x4, PP, #0x80, lsl #12  ; [pp+0x80968] Obj!BoxConstraints@129c531
    //     0xfbb15c: ldr             x4, [x4, #0x968]
    // 0xfbb160: r3 = Instance_BoxConstraints
    //     0xfbb160: add             x3, PP, #0x80, lsl #12  ; [pp+0x80970] Obj!BoxConstraints@129c501
    //     0xfbb164: ldr             x3, [x3, #0x970]
    // 0xfbb168: mov             x0, x2
    // 0xfbb16c: StoreField: r1->field_67 = r11
    //     0xfbb16c: stur            w11, [x1, #0x67]
    // 0xfbb170: StoreField: r1->field_6b = r11
    //     0xfbb170: stur            w11, [x1, #0x6b]
    // 0xfbb174: StoreField: r1->field_5b = r0
    //     0xfbb174: stur            w0, [x1, #0x5b]
    //     0xfbb178: ldurb           w16, [x1, #-1]
    //     0xfbb17c: ldurb           w17, [x0, #-1]
    //     0xfbb180: and             x16, x17, x16, lsr #2
    //     0xfbb184: tst             x16, HEAP, lsr #32
    //     0xfbb188: b.eq            #0xfbb198
    //     0xfbb18c: str             lr, [SP, #-8]!
    //     0xfbb190: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0xfbb194: ldr             lr, [SP], #8
    // 0xfbb198: StoreField: r1->field_5f = r10
    //     0xfbb198: stur            w10, [x1, #0x5f]
    // 0xfbb19c: StoreField: r1->field_63 = r9
    //     0xfbb19c: stur            w9, [x1, #0x63]
    // 0xfbb1a0: StoreField: r1->field_1b = r8
    //     0xfbb1a0: stur            w8, [x1, #0x1b]
    // 0xfbb1a4: StoreField: r1->field_1f = r8
    //     0xfbb1a4: stur            w8, [x1, #0x1f]
    // 0xfbb1a8: StoreField: r1->field_23 = r7
    //     0xfbb1a8: stur            w7, [x1, #0x23]
    // 0xfbb1ac: StoreField: r1->field_2b = r8
    //     0xfbb1ac: stur            w8, [x1, #0x2b]
    // 0xfbb1b0: StoreField: r1->field_33 = r9
    //     0xfbb1b0: stur            w9, [x1, #0x33]
    // 0xfbb1b4: StoreField: r1->field_3b = r4
    //     0xfbb1b4: stur            w4, [x1, #0x3b]
    // 0xfbb1b8: StoreField: r1->field_3f = r3
    //     0xfbb1b8: stur            w3, [x1, #0x3f]
    // 0xfbb1bc: StoreField: r1->field_43 = r5
    //     0xfbb1bc: stur            w5, [x1, #0x43]
    // 0xfbb1c0: StoreField: r1->field_47 = r6
    //     0xfbb1c0: stur            w6, [x1, #0x47]
    // 0xfbb1c4: StoreField: r1->field_4b = r7
    //     0xfbb1c4: stur            w7, [x1, #0x4b]
    // 0xfbb1c8: r0 = Null
    //     0xfbb1c8: mov             x0, NULL
    // 0xfbb1cc: ret
    //     0xfbb1cc: ret             
  }
  TextTheme _textTheme(_FABDefaultsM3) {
    // ** addr: 0xfbb234, size: 0x44
    // 0xfbb234: EnterFrame
    //     0xfbb234: stp             fp, lr, [SP, #-0x10]!
    //     0xfbb238: mov             fp, SP
    // 0xfbb23c: CheckStackOverflow
    //     0xfbb23c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbb240: cmp             SP, x16
    //     0xfbb244: b.ls            #0xfbb270
    // 0xfbb248: ldr             x0, [fp, #0x10]
    // 0xfbb24c: LoadField: r1 = r0->field_5b
    //     0xfbb24c: ldur            w1, [x0, #0x5b]
    // 0xfbb250: DecompressPointer r1
    //     0xfbb250: add             x1, x1, HEAP, lsl #32
    // 0xfbb254: r0 = of()
    //     0xfbb254: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfbb258: LoadField: r1 = r0->field_87
    //     0xfbb258: ldur            w1, [x0, #0x87]
    // 0xfbb25c: DecompressPointer r1
    //     0xfbb25c: add             x1, x1, HEAP, lsl #32
    // 0xfbb260: mov             x0, x1
    // 0xfbb264: LeaveFrame
    //     0xfbb264: mov             SP, fp
    //     0xfbb268: ldp             fp, lr, [SP], #0x10
    // 0xfbb26c: ret
    //     0xfbb26c: ret             
    // 0xfbb270: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbb270: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbb274: b               #0xfbb248
  }
  ColorScheme _colors(_FABDefaultsM3) {
    // ** addr: 0xfbb278, size: 0x44
    // 0xfbb278: EnterFrame
    //     0xfbb278: stp             fp, lr, [SP, #-0x10]!
    //     0xfbb27c: mov             fp, SP
    // 0xfbb280: CheckStackOverflow
    //     0xfbb280: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbb284: cmp             SP, x16
    //     0xfbb288: b.ls            #0xfbb2b4
    // 0xfbb28c: ldr             x0, [fp, #0x10]
    // 0xfbb290: LoadField: r1 = r0->field_5b
    //     0xfbb290: ldur            w1, [x0, #0x5b]
    // 0xfbb294: DecompressPointer r1
    //     0xfbb294: add             x1, x1, HEAP, lsl #32
    // 0xfbb298: r0 = of()
    //     0xfbb298: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfbb29c: LoadField: r1 = r0->field_3f
    //     0xfbb29c: ldur            w1, [x0, #0x3f]
    // 0xfbb2a0: DecompressPointer r1
    //     0xfbb2a0: add             x1, x1, HEAP, lsl #32
    // 0xfbb2a4: mov             x0, x1
    // 0xfbb2a8: LeaveFrame
    //     0xfbb2a8: mov             SP, fp
    //     0xfbb2ac: ldp             fp, lr, [SP], #0x10
    // 0xfbb2b0: ret
    //     0xfbb2b0: ret             
    // 0xfbb2b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbb2b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbb2b8: b               #0xfbb28c
  }
}

// class id: 5150, size: 0x6c, field offset: 0x5c
class _FABDefaultsM2 extends FloatingActionButtonThemeData {

  _ _FABDefaultsM2(/* No info */) {
    // ** addr: 0xfbb00c, size: 0x110
    // 0xfbb00c: EnterFrame
    //     0xfbb00c: stp             fp, lr, [SP, #-0x10]!
    //     0xfbb010: mov             fp, SP
    // 0xfbb014: AllocStack(0x10)
    //     0xfbb014: sub             SP, SP, #0x10
    // 0xfbb018: r3 = Instance__FloatingActionButtonType
    //     0xfbb018: add             x3, PP, #0x19, lsl #12  ; [pp+0x19660] Obj!_FloatingActionButtonType@12c57c1
    //     0xfbb01c: ldr             x3, [x3, #0x660]
    // 0xfbb020: r0 = true
    //     0xfbb020: add             x0, NULL, #0x20  ; true
    // 0xfbb024: mov             x4, x1
    // 0xfbb028: stur            x1, [fp, #-8]
    // 0xfbb02c: stur            x2, [fp, #-0x10]
    // 0xfbb030: CheckStackOverflow
    //     0xfbb030: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbb034: cmp             SP, x16
    //     0xfbb038: b.ls            #0xfbb114
    // 0xfbb03c: StoreField: r4->field_5b = r3
    //     0xfbb03c: stur            w3, [x4, #0x5b]
    // 0xfbb040: StoreField: r4->field_5f = r0
    //     0xfbb040: stur            w0, [x4, #0x5f]
    // 0xfbb044: mov             x1, x2
    // 0xfbb048: r0 = of()
    //     0xfbb048: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfbb04c: ldur            x2, [fp, #-8]
    // 0xfbb050: StoreField: r2->field_63 = r0
    //     0xfbb050: stur            w0, [x2, #0x63]
    //     0xfbb054: ldurb           w16, [x2, #-1]
    //     0xfbb058: ldurb           w17, [x0, #-1]
    //     0xfbb05c: and             x16, x17, x16, lsr #2
    //     0xfbb060: tst             x16, HEAP, lsr #32
    //     0xfbb064: b.eq            #0xfbb06c
    //     0xfbb068: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfbb06c: ldur            x1, [fp, #-0x10]
    // 0xfbb070: r0 = of()
    //     0xfbb070: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfbb074: LoadField: r1 = r0->field_3f
    //     0xfbb074: ldur            w1, [x0, #0x3f]
    // 0xfbb078: DecompressPointer r1
    //     0xfbb078: add             x1, x1, HEAP, lsl #32
    // 0xfbb07c: mov             x0, x1
    // 0xfbb080: ldur            x1, [fp, #-8]
    // 0xfbb084: StoreField: r1->field_67 = r0
    //     0xfbb084: stur            w0, [x1, #0x67]
    //     0xfbb088: ldurb           w16, [x1, #-1]
    //     0xfbb08c: ldurb           w17, [x0, #-1]
    //     0xfbb090: and             x16, x17, x16, lsr #2
    //     0xfbb094: tst             x16, HEAP, lsr #32
    //     0xfbb098: b.eq            #0xfbb0a0
    //     0xfbb09c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfbb0a0: r2 = 6.000000
    //     0xfbb0a0: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1c438] 6
    //     0xfbb0a4: ldr             x2, [x2, #0x438]
    // 0xfbb0a8: StoreField: r1->field_1b = r2
    //     0xfbb0a8: stur            w2, [x1, #0x1b]
    // 0xfbb0ac: StoreField: r1->field_1f = r2
    //     0xfbb0ac: stur            w2, [x1, #0x1f]
    // 0xfbb0b0: r2 = 8.000000
    //     0xfbb0b0: add             x2, PP, #0x19, lsl #12  ; [pp+0x19e08] 8
    //     0xfbb0b4: ldr             x2, [x2, #0xe08]
    // 0xfbb0b8: StoreField: r1->field_23 = r2
    //     0xfbb0b8: stur            w2, [x1, #0x23]
    // 0xfbb0bc: r3 = 12.000000
    //     0xfbb0bc: add             x3, PP, #0x19, lsl #12  ; [pp+0x19c58] 12
    //     0xfbb0c0: ldr             x3, [x3, #0xc58]
    // 0xfbb0c4: StoreField: r1->field_2b = r3
    //     0xfbb0c4: stur            w3, [x1, #0x2b]
    // 0xfbb0c8: r3 = true
    //     0xfbb0c8: add             x3, NULL, #0x20  ; true
    // 0xfbb0cc: StoreField: r1->field_33 = r3
    //     0xfbb0cc: stur            w3, [x1, #0x33]
    // 0xfbb0d0: r3 = Instance_BoxConstraints
    //     0xfbb0d0: add             x3, PP, #0x80, lsl #12  ; [pp+0x80968] Obj!BoxConstraints@129c531
    //     0xfbb0d4: ldr             x3, [x3, #0x968]
    // 0xfbb0d8: StoreField: r1->field_3b = r3
    //     0xfbb0d8: stur            w3, [x1, #0x3b]
    // 0xfbb0dc: r3 = Instance_BoxConstraints
    //     0xfbb0dc: add             x3, PP, #0x80, lsl #12  ; [pp+0x80970] Obj!BoxConstraints@129c501
    //     0xfbb0e0: ldr             x3, [x3, #0x970]
    // 0xfbb0e4: StoreField: r1->field_3f = r3
    //     0xfbb0e4: stur            w3, [x1, #0x3f]
    // 0xfbb0e8: r3 = Instance_BoxConstraints
    //     0xfbb0e8: add             x3, PP, #0x80, lsl #12  ; [pp+0x80978] Obj!BoxConstraints@129c4d1
    //     0xfbb0ec: ldr             x3, [x3, #0x978]
    // 0xfbb0f0: StoreField: r1->field_43 = r3
    //     0xfbb0f0: stur            w3, [x1, #0x43]
    // 0xfbb0f4: r3 = Instance_BoxConstraints
    //     0xfbb0f4: add             x3, PP, #0x80, lsl #12  ; [pp+0x80980] Obj!BoxConstraints@129c4a1
    //     0xfbb0f8: ldr             x3, [x3, #0x980]
    // 0xfbb0fc: StoreField: r1->field_47 = r3
    //     0xfbb0fc: stur            w3, [x1, #0x47]
    // 0xfbb100: StoreField: r1->field_4b = r2
    //     0xfbb100: stur            w2, [x1, #0x4b]
    // 0xfbb104: r0 = Null
    //     0xfbb104: mov             x0, NULL
    // 0xfbb108: LeaveFrame
    //     0xfbb108: mov             SP, fp
    //     0xfbb10c: ldp             fp, lr, [SP], #0x10
    // 0xfbb110: ret
    //     0xfbb110: ret             
    // 0xfbb114: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbb114: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbb118: b               #0xfbb03c
  }
}

// class id: 5190, size: 0x10, field offset: 0x8
//   const constructor, 
class _EffectiveMouseCursor extends WidgetStateMouseCursor {

  MouseCursor resolve(_EffectiveMouseCursor, Set<WidgetState>) {
    // ** addr: 0xfbafac, size: 0x6c
    // 0xfbafac: EnterFrame
    //     0xfbafac: stp             fp, lr, [SP, #-0x10]!
    //     0xfbafb0: mov             fp, SP
    // 0xfbafb4: CheckStackOverflow
    //     0xfbafb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbafb8: cmp             SP, x16
    //     0xfbafbc: b.ls            #0xfbaff8
    // 0xfbafc0: ldr             x0, [fp, #0x10]
    // 0xfbafc4: r2 = Null
    //     0xfbafc4: mov             x2, NULL
    // 0xfbafc8: r1 = Null
    //     0xfbafc8: mov             x1, NULL
    // 0xfbafcc: r8 = Set<WidgetState>
    //     0xfbafcc: add             x8, PP, #0x85, lsl #12  ; [pp+0x85200] Type: Set<WidgetState>
    //     0xfbafd0: ldr             x8, [x8, #0x200]
    // 0xfbafd4: r3 = Null
    //     0xfbafd4: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c948] Null
    //     0xfbafd8: ldr             x3, [x3, #0x948]
    // 0xfbafdc: r0 = Set<WidgetState>()
    //     0xfbafdc: bl              #0x8de430  ; IsType_Set<WidgetState>_Stub
    // 0xfbafe0: ldr             x1, [fp, #0x18]
    // 0xfbafe4: ldr             x2, [fp, #0x10]
    // 0xfbafe8: r0 = resolve()
    //     0xfbafe8: bl              #0x8de4b8  ; [package:flutter/src/material/popup_menu.dart] _EffectiveMouseCursor::resolve
    // 0xfbafec: LeaveFrame
    //     0xfbafec: mov             SP, fp
    //     0xfbaff0: ldp             fp, lr, [SP], #0x10
    // 0xfbaff4: ret
    //     0xfbaff4: ret             
    // 0xfbaff8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbaff8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbaffc: b               #0xfbafc0
  }
}

// class id: 6155, size: 0x74, field offset: 0xc
//   const constructor, 
class FloatingActionButton extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfba344, size: 0xc44
    // 0xfba344: EnterFrame
    //     0xfba344: stp             fp, lr, [SP, #-0x10]!
    //     0xfba348: mov             fp, SP
    // 0xfba34c: AllocStack(0x98)
    //     0xfba34c: sub             SP, SP, #0x98
    // 0xfba350: SetupParameters(FloatingActionButton this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfba350: mov             x0, x2
    //     0xfba354: stur            x2, [fp, #-0x10]
    //     0xfba358: mov             x2, x1
    //     0xfba35c: stur            x1, [fp, #-8]
    // 0xfba360: CheckStackOverflow
    //     0xfba360: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfba364: cmp             SP, x16
    //     0xfba368: b.ls            #0xfbaf20
    // 0xfba36c: mov             x1, x0
    // 0xfba370: r0 = of()
    //     0xfba370: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfba374: ldur            x1, [fp, #-0x10]
    // 0xfba378: stur            x0, [fp, #-0x18]
    // 0xfba37c: r0 = of()
    //     0xfba37c: bl              #0xfbb1dc  ; [package:flutter/src/material/floating_action_button_theme.dart] FloatingActionButtonTheme::of
    // 0xfba380: mov             x1, x0
    // 0xfba384: ldur            x0, [fp, #-0x18]
    // 0xfba388: stur            x1, [fp, #-0x20]
    // 0xfba38c: LoadField: r2 = r0->field_2f
    //     0xfba38c: ldur            w2, [x0, #0x2f]
    // 0xfba390: DecompressPointer r2
    //     0xfba390: add             x2, x2, HEAP, lsl #32
    // 0xfba394: tbnz            w2, #4, #0xfba3b4
    // 0xfba398: r0 = _FABDefaultsM3()
    //     0xfba398: bl              #0xfbb1d0  ; Allocate_FABDefaultsM3Stub -> _FABDefaultsM3 (size=0x70)
    // 0xfba39c: mov             x1, x0
    // 0xfba3a0: ldur            x2, [fp, #-0x10]
    // 0xfba3a4: stur            x0, [fp, #-0x28]
    // 0xfba3a8: r0 = _FABDefaultsM3()
    //     0xfba3a8: bl              #0xfbb128  ; [package:flutter/src/material/floating_action_button.dart] _FABDefaultsM3::_FABDefaultsM3
    // 0xfba3ac: ldur            x2, [fp, #-0x28]
    // 0xfba3b0: b               #0xfba3cc
    // 0xfba3b4: r0 = _FABDefaultsM2()
    //     0xfba3b4: bl              #0xfbb11c  ; Allocate_FABDefaultsM2Stub -> _FABDefaultsM2 (size=0x6c)
    // 0xfba3b8: mov             x1, x0
    // 0xfba3bc: ldur            x2, [fp, #-0x10]
    // 0xfba3c0: stur            x0, [fp, #-0x10]
    // 0xfba3c4: r0 = _FABDefaultsM2()
    //     0xfba3c4: bl              #0xfbb00c  ; [package:flutter/src/material/floating_action_button.dart] _FABDefaultsM2::_FABDefaultsM2
    // 0xfba3c8: ldur            x2, [fp, #-0x10]
    // 0xfba3cc: ldur            x0, [fp, #-0x20]
    // 0xfba3d0: stur            x2, [fp, #-0x10]
    // 0xfba3d4: LoadField: r1 = r0->field_7
    //     0xfba3d4: ldur            w1, [x0, #7]
    // 0xfba3d8: DecompressPointer r1
    //     0xfba3d8: add             x1, x1, HEAP, lsl #32
    // 0xfba3dc: cmp             w1, NULL
    // 0xfba3e0: b.ne            #0xfba488
    // 0xfba3e4: r1 = LoadClassIdInstr(r2)
    //     0xfba3e4: ldur            x1, [x2, #-1]
    //     0xfba3e8: ubfx            x1, x1, #0xc, #0x14
    // 0xfba3ec: r17 = 5148
    //     0xfba3ec: mov             x17, #0x141c
    // 0xfba3f0: cmp             x1, x17
    // 0xfba3f4: b.ne            #0xfba408
    // 0xfba3f8: LoadField: r1 = r2->field_7
    //     0xfba3f8: ldur            w1, [x2, #7]
    // 0xfba3fc: DecompressPointer r1
    //     0xfba3fc: add             x1, x1, HEAP, lsl #32
    // 0xfba400: mov             x0, x2
    // 0xfba404: b               #0xfba480
    // 0xfba408: r17 = 5149
    //     0xfba408: mov             x17, #0x141d
    // 0xfba40c: cmp             x1, x17
    // 0xfba410: b.ne            #0xfba468
    // 0xfba414: mov             x1, x2
    // 0xfba418: LoadField: r0 = r1->field_67
    //     0xfba418: ldur            w0, [x1, #0x67]
    // 0xfba41c: DecompressPointer r0
    //     0xfba41c: add             x0, x0, HEAP, lsl #32
    // 0xfba420: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfba424: cmp             w0, w16
    // 0xfba428: b.ne            #0xfba438
    // 0xfba42c: r2 = _colors
    //     0xfba42c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26358] Field <_FABDefaultsM3@751192485._colors@751192485>: late final (offset: 0x68)
    //     0xfba430: ldr             x2, [x2, #0x358]
    // 0xfba434: r0 = InitLateFinalInstanceField()
    //     0xfba434: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfba438: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xfba438: ldur            w1, [x0, #0x17]
    // 0xfba43c: DecompressPointer r1
    //     0xfba43c: add             x1, x1, HEAP, lsl #32
    // 0xfba440: cmp             w1, NULL
    // 0xfba444: b.ne            #0xfba458
    // 0xfba448: LoadField: r1 = r0->field_f
    //     0xfba448: ldur            w1, [x0, #0xf]
    // 0xfba44c: DecompressPointer r1
    //     0xfba44c: add             x1, x1, HEAP, lsl #32
    // 0xfba450: mov             x0, x1
    // 0xfba454: b               #0xfba45c
    // 0xfba458: mov             x0, x1
    // 0xfba45c: mov             x1, x0
    // 0xfba460: ldur            x0, [fp, #-0x10]
    // 0xfba464: b               #0xfba480
    // 0xfba468: mov             x0, x2
    // 0xfba46c: LoadField: r1 = r0->field_67
    //     0xfba46c: ldur            w1, [x0, #0x67]
    // 0xfba470: DecompressPointer r1
    //     0xfba470: add             x1, x1, HEAP, lsl #32
    // 0xfba474: LoadField: r2 = r1->field_2f
    //     0xfba474: ldur            w2, [x1, #0x2f]
    // 0xfba478: DecompressPointer r2
    //     0xfba478: add             x2, x2, HEAP, lsl #32
    // 0xfba47c: mov             x1, x2
    // 0xfba480: mov             x3, x1
    // 0xfba484: b               #0xfba490
    // 0xfba488: mov             x0, x2
    // 0xfba48c: mov             x3, x1
    // 0xfba490: ldur            x2, [fp, #-8]
    // 0xfba494: stur            x3, [fp, #-0x28]
    // 0xfba498: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xfba498: ldur            w1, [x2, #0x17]
    // 0xfba49c: DecompressPointer r1
    //     0xfba49c: add             x1, x1, HEAP, lsl #32
    // 0xfba4a0: cmp             w1, NULL
    // 0xfba4a4: b.ne            #0xfba4b8
    // 0xfba4a8: ldur            x4, [fp, #-0x20]
    // 0xfba4ac: LoadField: r1 = r4->field_b
    //     0xfba4ac: ldur            w1, [x4, #0xb]
    // 0xfba4b0: DecompressPointer r1
    //     0xfba4b0: add             x1, x1, HEAP, lsl #32
    // 0xfba4b4: b               #0xfba4bc
    // 0xfba4b8: ldur            x4, [fp, #-0x20]
    // 0xfba4bc: cmp             w1, NULL
    // 0xfba4c0: b.ne            #0xfba560
    // 0xfba4c4: r1 = LoadClassIdInstr(r0)
    //     0xfba4c4: ldur            x1, [x0, #-1]
    //     0xfba4c8: ubfx            x1, x1, #0xc, #0x14
    // 0xfba4cc: r17 = 5148
    //     0xfba4cc: mov             x17, #0x141c
    // 0xfba4d0: cmp             x1, x17
    // 0xfba4d4: b.ne            #0xfba4e4
    // 0xfba4d8: LoadField: r1 = r0->field_b
    //     0xfba4d8: ldur            w1, [x0, #0xb]
    // 0xfba4dc: DecompressPointer r1
    //     0xfba4dc: add             x1, x1, HEAP, lsl #32
    // 0xfba4e0: b               #0xfba558
    // 0xfba4e4: r17 = 5149
    //     0xfba4e4: mov             x17, #0x141d
    // 0xfba4e8: cmp             x1, x17
    // 0xfba4ec: b.ne            #0xfba544
    // 0xfba4f0: mov             x1, x0
    // 0xfba4f4: LoadField: r0 = r1->field_67
    //     0xfba4f4: ldur            w0, [x1, #0x67]
    // 0xfba4f8: DecompressPointer r0
    //     0xfba4f8: add             x0, x0, HEAP, lsl #32
    // 0xfba4fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfba500: cmp             w0, w16
    // 0xfba504: b.ne            #0xfba514
    // 0xfba508: r2 = _colors
    //     0xfba508: add             x2, PP, #0x26, lsl #12  ; [pp+0x26358] Field <_FABDefaultsM3@751192485._colors@751192485>: late final (offset: 0x68)
    //     0xfba50c: ldr             x2, [x2, #0x358]
    // 0xfba510: r0 = InitLateFinalInstanceField()
    //     0xfba510: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfba514: LoadField: r1 = r0->field_13
    //     0xfba514: ldur            w1, [x0, #0x13]
    // 0xfba518: DecompressPointer r1
    //     0xfba518: add             x1, x1, HEAP, lsl #32
    // 0xfba51c: cmp             w1, NULL
    // 0xfba520: b.ne            #0xfba534
    // 0xfba524: LoadField: r1 = r0->field_b
    //     0xfba524: ldur            w1, [x0, #0xb]
    // 0xfba528: DecompressPointer r1
    //     0xfba528: add             x1, x1, HEAP, lsl #32
    // 0xfba52c: mov             x0, x1
    // 0xfba530: b               #0xfba538
    // 0xfba534: mov             x0, x1
    // 0xfba538: mov             x1, x0
    // 0xfba53c: ldur            x0, [fp, #-0x10]
    // 0xfba540: b               #0xfba558
    // 0xfba544: LoadField: r1 = r0->field_67
    //     0xfba544: ldur            w1, [x0, #0x67]
    // 0xfba548: DecompressPointer r1
    //     0xfba548: add             x1, x1, HEAP, lsl #32
    // 0xfba54c: LoadField: r2 = r1->field_2b
    //     0xfba54c: ldur            w2, [x1, #0x2b]
    // 0xfba550: DecompressPointer r2
    //     0xfba550: add             x2, x2, HEAP, lsl #32
    // 0xfba554: mov             x1, x2
    // 0xfba558: mov             x2, x1
    // 0xfba55c: b               #0xfba564
    // 0xfba560: mov             x2, x1
    // 0xfba564: stur            x2, [fp, #-0x38]
    // 0xfba568: r3 = LoadClassIdInstr(r0)
    //     0xfba568: ldur            x3, [x0, #-1]
    //     0xfba56c: ubfx            x3, x3, #0xc, #0x14
    // 0xfba570: stur            x3, [fp, #-0x30]
    // 0xfba574: r17 = 5148
    //     0xfba574: mov             x17, #0x141c
    // 0xfba578: cmp             x3, x17
    // 0xfba57c: b.ne            #0xfba594
    // 0xfba580: LoadField: r1 = r0->field_f
    //     0xfba580: ldur            w1, [x0, #0xf]
    // 0xfba584: DecompressPointer r1
    //     0xfba584: add             x1, x1, HEAP, lsl #32
    // 0xfba588: mov             x2, x3
    // 0xfba58c: mov             x3, x1
    // 0xfba590: b               #0xfba610
    // 0xfba594: r17 = 5149
    //     0xfba594: mov             x17, #0x141d
    // 0xfba598: cmp             x3, x17
    // 0xfba59c: b.ne            #0xfba5f8
    // 0xfba5a0: mov             x1, x0
    // 0xfba5a4: LoadField: r0 = r1->field_67
    //     0xfba5a4: ldur            w0, [x1, #0x67]
    // 0xfba5a8: DecompressPointer r0
    //     0xfba5a8: add             x0, x0, HEAP, lsl #32
    // 0xfba5ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfba5b0: cmp             w0, w16
    // 0xfba5b4: b.ne            #0xfba5c4
    // 0xfba5b8: r2 = _colors
    //     0xfba5b8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26358] Field <_FABDefaultsM3@751192485._colors@751192485>: late final (offset: 0x68)
    //     0xfba5bc: ldr             x2, [x2, #0x358]
    // 0xfba5c0: r0 = InitLateFinalInstanceField()
    //     0xfba5c0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfba5c4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xfba5c4: ldur            w1, [x0, #0x17]
    // 0xfba5c8: DecompressPointer r1
    //     0xfba5c8: add             x1, x1, HEAP, lsl #32
    // 0xfba5cc: cmp             w1, NULL
    // 0xfba5d0: b.ne            #0xfba5dc
    // 0xfba5d4: LoadField: r1 = r0->field_f
    //     0xfba5d4: ldur            w1, [x0, #0xf]
    // 0xfba5d8: DecompressPointer r1
    //     0xfba5d8: add             x1, x1, HEAP, lsl #32
    // 0xfba5dc: d0 = 0.100000
    //     0xfba5dc: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xfba5e0: ldr             d0, [x17, #0x1e0]
    // 0xfba5e4: r0 = withOpacity()
    //     0xfba5e4: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xfba5e8: mov             x3, x0
    // 0xfba5ec: ldur            x0, [fp, #-0x10]
    // 0xfba5f0: ldur            x2, [fp, #-0x30]
    // 0xfba5f4: b               #0xfba610
    // 0xfba5f8: LoadField: r1 = r0->field_63
    //     0xfba5f8: ldur            w1, [x0, #0x63]
    // 0xfba5fc: DecompressPointer r1
    //     0xfba5fc: add             x1, x1, HEAP, lsl #32
    // 0xfba600: LoadField: r2 = r1->field_4b
    //     0xfba600: ldur            w2, [x1, #0x4b]
    // 0xfba604: DecompressPointer r2
    //     0xfba604: add             x2, x2, HEAP, lsl #32
    // 0xfba608: mov             x3, x2
    // 0xfba60c: ldur            x2, [fp, #-0x30]
    // 0xfba610: stur            x3, [fp, #-0x40]
    // 0xfba614: r17 = 5148
    //     0xfba614: mov             x17, #0x141c
    // 0xfba618: cmp             x2, x17
    // 0xfba61c: b.ne            #0xfba630
    // 0xfba620: LoadField: r1 = r0->field_13
    //     0xfba620: ldur            w1, [x0, #0x13]
    // 0xfba624: DecompressPointer r1
    //     0xfba624: add             x1, x1, HEAP, lsl #32
    // 0xfba628: mov             x3, x1
    // 0xfba62c: b               #0xfba6ac
    // 0xfba630: r17 = 5149
    //     0xfba630: mov             x17, #0x141d
    // 0xfba634: cmp             x2, x17
    // 0xfba638: b.ne            #0xfba694
    // 0xfba63c: mov             x1, x0
    // 0xfba640: LoadField: r0 = r1->field_67
    //     0xfba640: ldur            w0, [x1, #0x67]
    // 0xfba644: DecompressPointer r0
    //     0xfba644: add             x0, x0, HEAP, lsl #32
    // 0xfba648: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfba64c: cmp             w0, w16
    // 0xfba650: b.ne            #0xfba660
    // 0xfba654: r2 = _colors
    //     0xfba654: add             x2, PP, #0x26, lsl #12  ; [pp+0x26358] Field <_FABDefaultsM3@751192485._colors@751192485>: late final (offset: 0x68)
    //     0xfba658: ldr             x2, [x2, #0x358]
    // 0xfba65c: r0 = InitLateFinalInstanceField()
    //     0xfba65c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfba660: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xfba660: ldur            w1, [x0, #0x17]
    // 0xfba664: DecompressPointer r1
    //     0xfba664: add             x1, x1, HEAP, lsl #32
    // 0xfba668: cmp             w1, NULL
    // 0xfba66c: b.ne            #0xfba678
    // 0xfba670: LoadField: r1 = r0->field_f
    //     0xfba670: ldur            w1, [x0, #0xf]
    // 0xfba674: DecompressPointer r1
    //     0xfba674: add             x1, x1, HEAP, lsl #32
    // 0xfba678: d0 = 0.080000
    //     0xfba678: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xfba67c: ldr             d0, [x17, #0xa58]
    // 0xfba680: r0 = withOpacity()
    //     0xfba680: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xfba684: mov             x3, x0
    // 0xfba688: ldur            x0, [fp, #-0x10]
    // 0xfba68c: ldur            x2, [fp, #-0x30]
    // 0xfba690: b               #0xfba6ac
    // 0xfba694: LoadField: r1 = r0->field_63
    //     0xfba694: ldur            w1, [x0, #0x63]
    // 0xfba698: DecompressPointer r1
    //     0xfba698: add             x1, x1, HEAP, lsl #32
    // 0xfba69c: LoadField: r2 = r1->field_57
    //     0xfba69c: ldur            w2, [x1, #0x57]
    // 0xfba6a0: DecompressPointer r2
    //     0xfba6a0: add             x2, x2, HEAP, lsl #32
    // 0xfba6a4: mov             x3, x2
    // 0xfba6a8: ldur            x2, [fp, #-0x30]
    // 0xfba6ac: stur            x3, [fp, #-0x48]
    // 0xfba6b0: r17 = 5148
    //     0xfba6b0: mov             x17, #0x141c
    // 0xfba6b4: cmp             x2, x17
    // 0xfba6b8: b.ne            #0xfba6cc
    // 0xfba6bc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xfba6bc: ldur            w1, [x0, #0x17]
    // 0xfba6c0: DecompressPointer r1
    //     0xfba6c0: add             x1, x1, HEAP, lsl #32
    // 0xfba6c4: mov             x3, x1
    // 0xfba6c8: b               #0xfba740
    // 0xfba6cc: r17 = 5149
    //     0xfba6cc: mov             x17, #0x141d
    // 0xfba6d0: cmp             x2, x17
    // 0xfba6d4: b.ne            #0xfba72c
    // 0xfba6d8: mov             x1, x0
    // 0xfba6dc: LoadField: r0 = r1->field_67
    //     0xfba6dc: ldur            w0, [x1, #0x67]
    // 0xfba6e0: DecompressPointer r0
    //     0xfba6e0: add             x0, x0, HEAP, lsl #32
    // 0xfba6e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfba6e8: cmp             w0, w16
    // 0xfba6ec: b.ne            #0xfba6fc
    // 0xfba6f0: r2 = _colors
    //     0xfba6f0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26358] Field <_FABDefaultsM3@751192485._colors@751192485>: late final (offset: 0x68)
    //     0xfba6f4: ldr             x2, [x2, #0x358]
    // 0xfba6f8: r0 = InitLateFinalInstanceField()
    //     0xfba6f8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfba6fc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xfba6fc: ldur            w1, [x0, #0x17]
    // 0xfba700: DecompressPointer r1
    //     0xfba700: add             x1, x1, HEAP, lsl #32
    // 0xfba704: cmp             w1, NULL
    // 0xfba708: b.ne            #0xfba714
    // 0xfba70c: LoadField: r1 = r0->field_f
    //     0xfba70c: ldur            w1, [x0, #0xf]
    // 0xfba710: DecompressPointer r1
    //     0xfba710: add             x1, x1, HEAP, lsl #32
    // 0xfba714: d0 = 0.100000
    //     0xfba714: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xfba718: ldr             d0, [x17, #0x1e0]
    // 0xfba71c: r0 = withOpacity()
    //     0xfba71c: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xfba720: mov             x3, x0
    // 0xfba724: ldur            x0, [fp, #-0x10]
    // 0xfba728: b               #0xfba740
    // 0xfba72c: LoadField: r1 = r0->field_63
    //     0xfba72c: ldur            w1, [x0, #0x63]
    // 0xfba730: DecompressPointer r1
    //     0xfba730: add             x1, x1, HEAP, lsl #32
    // 0xfba734: LoadField: r2 = r1->field_73
    //     0xfba734: ldur            w2, [x1, #0x73]
    // 0xfba738: DecompressPointer r2
    //     0xfba738: add             x2, x2, HEAP, lsl #32
    // 0xfba73c: mov             x3, x2
    // 0xfba740: ldur            x2, [fp, #-8]
    // 0xfba744: stur            x3, [fp, #-0x58]
    // 0xfba748: LoadField: r1 = r2->field_33
    //     0xfba748: ldur            w1, [x2, #0x33]
    // 0xfba74c: DecompressPointer r1
    //     0xfba74c: add             x1, x1, HEAP, lsl #32
    // 0xfba750: cmp             w1, NULL
    // 0xfba754: b.ne            #0xfba768
    // 0xfba758: ldur            x4, [fp, #-0x20]
    // 0xfba75c: LoadField: r1 = r4->field_1b
    //     0xfba75c: ldur            w1, [x4, #0x1b]
    // 0xfba760: DecompressPointer r1
    //     0xfba760: add             x1, x1, HEAP, lsl #32
    // 0xfba764: b               #0xfba76c
    // 0xfba768: ldur            x4, [fp, #-0x20]
    // 0xfba76c: cmp             w1, NULL
    // 0xfba770: b.ne            #0xfba78c
    // 0xfba774: LoadField: r1 = r0->field_1b
    //     0xfba774: ldur            w1, [x0, #0x1b]
    // 0xfba778: DecompressPointer r1
    //     0xfba778: add             x1, x1, HEAP, lsl #32
    // 0xfba77c: cmp             w1, NULL
    // 0xfba780: b.eq            #0xfbaf28
    // 0xfba784: LoadField: d0 = r1->field_7
    //     0xfba784: ldur            d0, [x1, #7]
    // 0xfba788: b               #0xfba790
    // 0xfba78c: LoadField: d0 = r1->field_7
    //     0xfba78c: ldur            d0, [x1, #7]
    // 0xfba790: stur            d0, [fp, #-0x90]
    // 0xfba794: LoadField: r1 = r4->field_1f
    //     0xfba794: ldur            w1, [x4, #0x1f]
    // 0xfba798: DecompressPointer r1
    //     0xfba798: add             x1, x1, HEAP, lsl #32
    // 0xfba79c: cmp             w1, NULL
    // 0xfba7a0: b.ne            #0xfba7bc
    // 0xfba7a4: LoadField: r1 = r0->field_1f
    //     0xfba7a4: ldur            w1, [x0, #0x1f]
    // 0xfba7a8: DecompressPointer r1
    //     0xfba7a8: add             x1, x1, HEAP, lsl #32
    // 0xfba7ac: cmp             w1, NULL
    // 0xfba7b0: b.eq            #0xfbaf2c
    // 0xfba7b4: LoadField: d1 = r1->field_7
    //     0xfba7b4: ldur            d1, [x1, #7]
    // 0xfba7b8: b               #0xfba7c0
    // 0xfba7bc: LoadField: d1 = r1->field_7
    //     0xfba7bc: ldur            d1, [x1, #7]
    // 0xfba7c0: stur            d1, [fp, #-0x88]
    // 0xfba7c4: LoadField: r1 = r4->field_23
    //     0xfba7c4: ldur            w1, [x4, #0x23]
    // 0xfba7c8: DecompressPointer r1
    //     0xfba7c8: add             x1, x1, HEAP, lsl #32
    // 0xfba7cc: cmp             w1, NULL
    // 0xfba7d0: b.ne            #0xfba7ec
    // 0xfba7d4: LoadField: r1 = r0->field_23
    //     0xfba7d4: ldur            w1, [x0, #0x23]
    // 0xfba7d8: DecompressPointer r1
    //     0xfba7d8: add             x1, x1, HEAP, lsl #32
    // 0xfba7dc: cmp             w1, NULL
    // 0xfba7e0: b.eq            #0xfbaf30
    // 0xfba7e4: LoadField: d2 = r1->field_7
    //     0xfba7e4: ldur            d2, [x1, #7]
    // 0xfba7e8: b               #0xfba7f0
    // 0xfba7ec: LoadField: d2 = r1->field_7
    //     0xfba7ec: ldur            d2, [x1, #7]
    // 0xfba7f0: stur            d2, [fp, #-0x80]
    // 0xfba7f4: LoadField: r1 = r4->field_27
    //     0xfba7f4: ldur            w1, [x4, #0x27]
    // 0xfba7f8: DecompressPointer r1
    //     0xfba7f8: add             x1, x1, HEAP, lsl #32
    // 0xfba7fc: cmp             w1, NULL
    // 0xfba800: b.ne            #0xfba80c
    // 0xfba804: LoadField: r1 = r0->field_27
    //     0xfba804: ldur            w1, [x0, #0x27]
    // 0xfba808: DecompressPointer r1
    //     0xfba808: add             x1, x1, HEAP, lsl #32
    // 0xfba80c: cmp             w1, NULL
    // 0xfba810: b.ne            #0xfba81c
    // 0xfba814: mov             v3.16b, v0.16b
    // 0xfba818: b               #0xfba820
    // 0xfba81c: LoadField: d3 = r1->field_7
    //     0xfba81c: ldur            d3, [x1, #7]
    // 0xfba820: stur            d3, [fp, #-0x78]
    // 0xfba824: LoadField: r1 = r4->field_2b
    //     0xfba824: ldur            w1, [x4, #0x2b]
    // 0xfba828: DecompressPointer r1
    //     0xfba828: add             x1, x1, HEAP, lsl #32
    // 0xfba82c: cmp             w1, NULL
    // 0xfba830: b.ne            #0xfba84c
    // 0xfba834: LoadField: r1 = r0->field_2b
    //     0xfba834: ldur            w1, [x0, #0x2b]
    // 0xfba838: DecompressPointer r1
    //     0xfba838: add             x1, x1, HEAP, lsl #32
    // 0xfba83c: cmp             w1, NULL
    // 0xfba840: b.eq            #0xfbaf34
    // 0xfba844: LoadField: d4 = r1->field_7
    //     0xfba844: ldur            d4, [x1, #7]
    // 0xfba848: b               #0xfba850
    // 0xfba84c: LoadField: d4 = r1->field_7
    //     0xfba84c: ldur            d4, [x1, #7]
    // 0xfba850: ldur            x1, [fp, #-0x18]
    // 0xfba854: stur            d4, [fp, #-0x70]
    // 0xfba858: LoadField: r5 = r1->field_1b
    //     0xfba858: ldur            w5, [x1, #0x1b]
    // 0xfba85c: DecompressPointer r5
    //     0xfba85c: add             x5, x5, HEAP, lsl #32
    // 0xfba860: stur            x5, [fp, #-0x50]
    // 0xfba864: LoadField: r1 = r4->field_33
    //     0xfba864: ldur            w1, [x4, #0x33]
    // 0xfba868: DecompressPointer r1
    //     0xfba868: add             x1, x1, HEAP, lsl #32
    // 0xfba86c: cmp             w1, NULL
    // 0xfba870: b.ne            #0xfba884
    // 0xfba874: LoadField: r1 = r0->field_33
    //     0xfba874: ldur            w1, [x0, #0x33]
    // 0xfba878: DecompressPointer r1
    //     0xfba878: add             x1, x1, HEAP, lsl #32
    // 0xfba87c: cmp             w1, NULL
    // 0xfba880: b.eq            #0xfbaf38
    // 0xfba884: LoadField: r1 = r4->field_37
    //     0xfba884: ldur            w1, [x4, #0x37]
    // 0xfba888: DecompressPointer r1
    //     0xfba888: add             x1, x1, HEAP, lsl #32
    // 0xfba88c: cmp             w1, NULL
    // 0xfba890: b.ne            #0xfba940
    // 0xfba894: ldur            x6, [fp, #-0x30]
    // 0xfba898: r17 = 5148
    //     0xfba898: mov             x17, #0x141c
    // 0xfba89c: cmp             x6, x17
    // 0xfba8a0: b.ne            #0xfba8b0
    // 0xfba8a4: LoadField: r1 = r0->field_37
    //     0xfba8a4: ldur            w1, [x0, #0x37]
    // 0xfba8a8: DecompressPointer r1
    //     0xfba8a8: add             x1, x1, HEAP, lsl #32
    // 0xfba8ac: b               #0xfba938
    // 0xfba8b0: r17 = 5149
    //     0xfba8b0: mov             x17, #0x141d
    // 0xfba8b4: cmp             x6, x17
    // 0xfba8b8: b.ne            #0xfba930
    // 0xfba8bc: LoadField: r1 = r0->field_5f
    //     0xfba8bc: ldur            w1, [x0, #0x5f]
    // 0xfba8c0: DecompressPointer r1
    //     0xfba8c0: add             x1, x1, HEAP, lsl #32
    // 0xfba8c4: LoadField: r7 = r1->field_7
    //     0xfba8c4: ldur            x7, [x1, #7]
    // 0xfba8c8: cmp             x7, #1
    // 0xfba8cc: b.gt            #0xfba8e8
    // 0xfba8d0: cmp             x7, #0
    // 0xfba8d4: b.gt            #0xfba8e0
    // 0xfba8d8: d5 = 24.000000
    //     0xfba8d8: fmov            d5, #24.00000000
    // 0xfba8dc: b               #0xfba900
    // 0xfba8e0: d5 = 24.000000
    //     0xfba8e0: fmov            d5, #24.00000000
    // 0xfba8e4: b               #0xfba900
    // 0xfba8e8: cmp             x7, #2
    // 0xfba8ec: b.gt            #0xfba8fc
    // 0xfba8f0: d5 = 36.000000
    //     0xfba8f0: add             x17, PP, #0x12, lsl #12  ; [pp+0x12ca0] IMM: double(36) from 0x4042000000000000
    //     0xfba8f4: ldr             d5, [x17, #0xca0]
    // 0xfba8f8: b               #0xfba900
    // 0xfba8fc: d5 = 24.000000
    //     0xfba8fc: fmov            d5, #24.00000000
    // 0xfba900: r1 = inline_Allocate_Double()
    //     0xfba900: ldp             x1, x7, [THR, #0x60]  ; THR::top
    //     0xfba904: add             x1, x1, #0x10
    //     0xfba908: cmp             x7, x1
    //     0xfba90c: b.ls            #0xfbaf3c
    //     0xfba910: str             x1, [THR, #0x60]  ; THR::top
    //     0xfba914: sub             x1, x1, #0xf
    //     0xfba918: mov             x7, #0xe19c
    //     0xfba91c: movk            x7, #3, lsl #16
    //     0xfba920: stur            x7, [x1, #-1]
    // 0xfba924: dmb             ishst
    // 0xfba928: StoreField: r1->field_7 = d5
    //     0xfba928: stur            d5, [x1, #7]
    // 0xfba92c: b               #0xfba938
    // 0xfba930: r1 = 24.000000
    //     0xfba930: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0xfba934: ldr             x1, [x1, #0x4d0]
    // 0xfba938: mov             x7, x1
    // 0xfba93c: b               #0xfba948
    // 0xfba940: ldur            x6, [fp, #-0x30]
    // 0xfba944: mov             x7, x1
    // 0xfba948: stur            x7, [fp, #-0x18]
    // 0xfba94c: r17 = 5148
    //     0xfba94c: mov             x17, #0x141c
    // 0xfba950: cmp             x6, x17
    // 0xfba954: b.ne            #0xfba968
    // 0xfba958: LoadField: r1 = r0->field_53
    //     0xfba958: ldur            w1, [x0, #0x53]
    // 0xfba95c: DecompressPointer r1
    //     0xfba95c: add             x1, x1, HEAP, lsl #32
    // 0xfba960: mov             x0, x2
    // 0xfba964: b               #0xfba9e0
    // 0xfba968: r17 = 5149
    //     0xfba968: mov             x17, #0x141d
    // 0xfba96c: cmp             x6, x17
    // 0xfba970: b.ne            #0xfba9a8
    // 0xfba974: mov             x1, x0
    // 0xfba978: LoadField: r0 = r1->field_6b
    //     0xfba978: ldur            w0, [x1, #0x6b]
    // 0xfba97c: DecompressPointer r0
    //     0xfba97c: add             x0, x0, HEAP, lsl #32
    // 0xfba980: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfba984: cmp             w0, w16
    // 0xfba988: b.ne            #0xfba998
    // 0xfba98c: r2 = _textTheme
    //     0xfba98c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26378] Field <_FABDefaultsM3@751192485._textTheme@751192485>: late final (offset: 0x6c)
    //     0xfba990: ldr             x2, [x2, #0x378]
    // 0xfba994: r0 = InitLateFinalInstanceField()
    //     0xfba994: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfba998: LoadField: r1 = r0->field_37
    //     0xfba998: ldur            w1, [x0, #0x37]
    // 0xfba99c: DecompressPointer r1
    //     0xfba99c: add             x1, x1, HEAP, lsl #32
    // 0xfba9a0: ldur            x0, [fp, #-8]
    // 0xfba9a4: b               #0xfba9e0
    // 0xfba9a8: LoadField: r1 = r0->field_63
    //     0xfba9a8: ldur            w1, [x0, #0x63]
    // 0xfba9ac: DecompressPointer r1
    //     0xfba9ac: add             x1, x1, HEAP, lsl #32
    // 0xfba9b0: LoadField: r2 = r1->field_87
    //     0xfba9b0: ldur            w2, [x1, #0x87]
    // 0xfba9b4: DecompressPointer r2
    //     0xfba9b4: add             x2, x2, HEAP, lsl #32
    // 0xfba9b8: LoadField: r1 = r2->field_37
    //     0xfba9b8: ldur            w1, [x2, #0x37]
    // 0xfba9bc: DecompressPointer r1
    //     0xfba9bc: add             x1, x1, HEAP, lsl #32
    // 0xfba9c0: r16 = 1.200000
    //     0xfba9c0: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1ac08] 1.2
    //     0xfba9c4: ldr             x16, [x16, #0xc08]
    // 0xfba9c8: str             x16, [SP]
    // 0xfba9cc: r4 = const [0, 0x2, 0x1, 0x1, letterSpacing, 0x1, null]
    //     0xfba9cc: add             x4, PP, #0x26, lsl #12  ; [pp+0x26380] List(7) [0, 0x2, 0x1, 0x1, "letterSpacing", 0x1, Null]
    //     0xfba9d0: ldr             x4, [x4, #0x380]
    // 0xfba9d4: r0 = copyWith()
    //     0xfba9d4: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xfba9d8: mov             x1, x0
    // 0xfba9dc: ldur            x0, [fp, #-8]
    // 0xfba9e0: ldur            x16, [fp, #-0x28]
    // 0xfba9e4: str             x16, [SP]
    // 0xfba9e8: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xfba9e8: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xfba9ec: ldr             x4, [x4, #0x7f0]
    // 0xfba9f0: r0 = copyWith()
    //     0xfba9f0: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xfba9f4: mov             x1, x0
    // 0xfba9f8: ldur            x0, [fp, #-8]
    // 0xfba9fc: stur            x1, [fp, #-0x60]
    // 0xfbaa00: LoadField: r2 = r0->field_47
    //     0xfbaa00: ldur            w2, [x0, #0x47]
    // 0xfbaa04: DecompressPointer r2
    //     0xfbaa04: add             x2, x2, HEAP, lsl #32
    // 0xfbaa08: cmp             w2, NULL
    // 0xfbaa0c: b.ne            #0xfbaa14
    // 0xfbaa10: r2 = Null
    //     0xfbaa10: mov             x2, NULL
    // 0xfbaa14: cmp             w2, NULL
    // 0xfbaa18: b.ne            #0xfbaab0
    // 0xfbaa1c: ldur            x3, [fp, #-0x30]
    // 0xfbaa20: r17 = 5148
    //     0xfbaa20: mov             x17, #0x141c
    // 0xfbaa24: cmp             x3, x17
    // 0xfbaa28: b.ne            #0xfbaa3c
    // 0xfbaa2c: ldur            x4, [fp, #-0x10]
    // 0xfbaa30: LoadField: r2 = r4->field_2f
    //     0xfbaa30: ldur            w2, [x4, #0x2f]
    // 0xfbaa34: DecompressPointer r2
    //     0xfbaa34: add             x2, x2, HEAP, lsl #32
    // 0xfbaa38: b               #0xfbaaa8
    // 0xfbaa3c: ldur            x4, [fp, #-0x10]
    // 0xfbaa40: r17 = 5149
    //     0xfbaa40: mov             x17, #0x141d
    // 0xfbaa44: cmp             x3, x17
    // 0xfbaa48: b.ne            #0xfbaaa0
    // 0xfbaa4c: LoadField: r2 = r4->field_5f
    //     0xfbaa4c: ldur            w2, [x4, #0x5f]
    // 0xfbaa50: DecompressPointer r2
    //     0xfbaa50: add             x2, x2, HEAP, lsl #32
    // 0xfbaa54: LoadField: r5 = r2->field_7
    //     0xfbaa54: ldur            x5, [x2, #7]
    // 0xfbaa58: cmp             x5, #1
    // 0xfbaa5c: b.gt            #0xfbaa80
    // 0xfbaa60: cmp             x5, #0
    // 0xfbaa64: b.gt            #0xfbaa74
    // 0xfbaa68: r2 = Instance_RoundedRectangleBorder
    //     0xfbaa68: add             x2, PP, #0x26, lsl #12  ; [pp+0x26360] Obj!RoundedRectangleBorder@129ec91
    //     0xfbaa6c: ldr             x2, [x2, #0x360]
    // 0xfbaa70: b               #0xfbaaa8
    // 0xfbaa74: r2 = Instance_RoundedRectangleBorder
    //     0xfbaa74: add             x2, PP, #0x26, lsl #12  ; [pp+0x26368] Obj!RoundedRectangleBorder@129ec81
    //     0xfbaa78: ldr             x2, [x2, #0x368]
    // 0xfbaa7c: b               #0xfbaaa8
    // 0xfbaa80: cmp             x5, #2
    // 0xfbaa84: b.gt            #0xfbaa94
    // 0xfbaa88: r2 = Instance_RoundedRectangleBorder
    //     0xfbaa88: add             x2, PP, #0x26, lsl #12  ; [pp+0x26370] Obj!RoundedRectangleBorder@129ec41
    //     0xfbaa8c: ldr             x2, [x2, #0x370]
    // 0xfbaa90: b               #0xfbaaa8
    // 0xfbaa94: r2 = Instance_RoundedRectangleBorder
    //     0xfbaa94: add             x2, PP, #0x26, lsl #12  ; [pp+0x26360] Obj!RoundedRectangleBorder@129ec91
    //     0xfbaa98: ldr             x2, [x2, #0x360]
    // 0xfbaa9c: b               #0xfbaaa8
    // 0xfbaaa0: r2 = Instance_CircleBorder
    //     0xfbaaa0: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1c318] Obj!CircleBorder@129ebf1
    //     0xfbaaa4: ldr             x2, [x2, #0x318]
    // 0xfbaaa8: mov             x5, x2
    // 0xfbaaac: b               #0xfbaabc
    // 0xfbaab0: ldur            x4, [fp, #-0x10]
    // 0xfbaab4: ldur            x3, [fp, #-0x30]
    // 0xfbaab8: mov             x5, x2
    // 0xfbaabc: ldur            x2, [fp, #-0x18]
    // 0xfbaac0: stur            x5, [fp, #-0x28]
    // 0xfbaac4: r0 = IconThemeData()
    //     0xfbaac4: bl              #0x8ac78c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0xfbaac8: mov             x1, x0
    // 0xfbaacc: ldur            x0, [fp, #-0x18]
    // 0xfbaad0: StoreField: r1->field_7 = r0
    //     0xfbaad0: stur            w0, [x1, #7]
    // 0xfbaad4: ldur            x0, [fp, #-8]
    // 0xfbaad8: LoadField: r3 = r0->field_b
    //     0xfbaad8: ldur            w3, [x0, #0xb]
    // 0xfbaadc: DecompressPointer r3
    //     0xfbaadc: add             x3, x3, HEAP, lsl #32
    // 0xfbaae0: mov             x2, x1
    // 0xfbaae4: mov             x1, x3
    // 0xfbaae8: stur            x3, [fp, #-0x18]
    // 0xfbaaec: r0 = merge()
    //     0xfbaaec: bl              #0xd0c588  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::merge
    // 0xfbaaf0: mov             x1, x0
    // 0xfbaaf4: ldur            x0, [fp, #-8]
    // 0xfbaaf8: LoadField: r2 = r0->field_6f
    //     0xfbaaf8: ldur            w2, [x0, #0x6f]
    // 0xfbaafc: DecompressPointer r2
    //     0xfbaafc: add             x2, x2, HEAP, lsl #32
    // 0xfbab00: LoadField: r3 = r2->field_7
    //     0xfbab00: ldur            x3, [x2, #7]
    // 0xfbab04: cmp             x3, #1
    // 0xfbab08: b.gt            #0xfbab8c
    // 0xfbab0c: cmp             x3, #0
    // 0xfbab10: b.gt            #0xfbab50
    // 0xfbab14: ldur            x2, [fp, #-0x20]
    // 0xfbab18: LoadField: r3 = r2->field_3b
    //     0xfbab18: ldur            w3, [x2, #0x3b]
    // 0xfbab1c: DecompressPointer r3
    //     0xfbab1c: add             x3, x3, HEAP, lsl #32
    // 0xfbab20: cmp             w3, NULL
    // 0xfbab24: b.ne            #0xfbab40
    // 0xfbab28: ldur            x4, [fp, #-0x10]
    // 0xfbab2c: LoadField: r2 = r4->field_3b
    //     0xfbab2c: ldur            w2, [x4, #0x3b]
    // 0xfbab30: DecompressPointer r2
    //     0xfbab30: add             x2, x2, HEAP, lsl #32
    // 0xfbab34: cmp             w2, NULL
    // 0xfbab38: b.eq            #0xfbaf78
    // 0xfbab3c: b               #0xfbab44
    // 0xfbab40: mov             x2, x3
    // 0xfbab44: mov             x9, x2
    // 0xfbab48: mov             x8, x1
    // 0xfbab4c: b               #0xfbad84
    // 0xfbab50: ldur            x2, [fp, #-0x20]
    // 0xfbab54: ldur            x4, [fp, #-0x10]
    // 0xfbab58: LoadField: r3 = r2->field_3f
    //     0xfbab58: ldur            w3, [x2, #0x3f]
    // 0xfbab5c: DecompressPointer r3
    //     0xfbab5c: add             x3, x3, HEAP, lsl #32
    // 0xfbab60: cmp             w3, NULL
    // 0xfbab64: b.ne            #0xfbab7c
    // 0xfbab68: LoadField: r2 = r4->field_3f
    //     0xfbab68: ldur            w2, [x4, #0x3f]
    // 0xfbab6c: DecompressPointer r2
    //     0xfbab6c: add             x2, x2, HEAP, lsl #32
    // 0xfbab70: cmp             w2, NULL
    // 0xfbab74: b.eq            #0xfbaf7c
    // 0xfbab78: b               #0xfbab80
    // 0xfbab7c: mov             x2, x3
    // 0xfbab80: mov             x9, x2
    // 0xfbab84: mov             x8, x1
    // 0xfbab88: b               #0xfbad84
    // 0xfbab8c: ldur            x2, [fp, #-0x20]
    // 0xfbab90: ldur            x4, [fp, #-0x10]
    // 0xfbab94: cmp             x3, #2
    // 0xfbab98: b.gt            #0xfbabd0
    // 0xfbab9c: LoadField: r3 = r2->field_43
    //     0xfbab9c: ldur            w3, [x2, #0x43]
    // 0xfbaba0: DecompressPointer r3
    //     0xfbaba0: add             x3, x3, HEAP, lsl #32
    // 0xfbaba4: cmp             w3, NULL
    // 0xfbaba8: b.ne            #0xfbabc0
    // 0xfbabac: LoadField: r2 = r4->field_43
    //     0xfbabac: ldur            w2, [x4, #0x43]
    // 0xfbabb0: DecompressPointer r2
    //     0xfbabb0: add             x2, x2, HEAP, lsl #32
    // 0xfbabb4: cmp             w2, NULL
    // 0xfbabb8: b.eq            #0xfbaf80
    // 0xfbabbc: b               #0xfbabc4
    // 0xfbabc0: mov             x2, x3
    // 0xfbabc4: mov             x9, x2
    // 0xfbabc8: mov             x8, x1
    // 0xfbabcc: b               #0xfbad84
    // 0xfbabd0: LoadField: r1 = r2->field_47
    //     0xfbabd0: ldur            w1, [x2, #0x47]
    // 0xfbabd4: DecompressPointer r1
    //     0xfbabd4: add             x1, x1, HEAP, lsl #32
    // 0xfbabd8: cmp             w1, NULL
    // 0xfbabdc: b.ne            #0xfbabf8
    // 0xfbabe0: LoadField: r1 = r4->field_47
    //     0xfbabe0: ldur            w1, [x4, #0x47]
    // 0xfbabe4: DecompressPointer r1
    //     0xfbabe4: add             x1, x1, HEAP, lsl #32
    // 0xfbabe8: cmp             w1, NULL
    // 0xfbabec: b.eq            #0xfbaf84
    // 0xfbabf0: mov             x2, x1
    // 0xfbabf4: b               #0xfbabfc
    // 0xfbabf8: mov             x2, x1
    // 0xfbabfc: ldur            x1, [fp, #-0x30]
    // 0xfbac00: stur            x2, [fp, #-0x20]
    // 0xfbac04: r17 = 5148
    //     0xfbac04: mov             x17, #0x141c
    // 0xfbac08: cmp             x1, x17
    // 0xfbac0c: b.ne            #0xfbac20
    // 0xfbac10: LoadField: r1 = r4->field_4f
    //     0xfbac10: ldur            w1, [x4, #0x4f]
    // 0xfbac14: DecompressPointer r1
    //     0xfbac14: add             x1, x1, HEAP, lsl #32
    // 0xfbac18: mov             x0, x1
    // 0xfbac1c: b               #0xfbac64
    // 0xfbac20: r17 = 5149
    //     0xfbac20: mov             x17, #0x141d
    // 0xfbac24: cmp             x1, x17
    // 0xfbac28: b.ne            #0xfbac48
    // 0xfbac2c: r0 = EdgeInsetsDirectional()
    //     0xfbac2c: bl              #0xb50060  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xfbac30: d0 = 20.000000
    //     0xfbac30: fmov            d0, #20.00000000
    // 0xfbac34: StoreField: r0->field_7 = d0
    //     0xfbac34: stur            d0, [x0, #7]
    // 0xfbac38: StoreField: r0->field_f = rZR
    //     0xfbac38: stur            xzr, [x0, #0xf]
    // 0xfbac3c: ArrayStore: r0[0] = d0  ; List_8
    //     0xfbac3c: stur            d0, [x0, #0x17]
    // 0xfbac40: StoreField: r0->field_1f = rZR
    //     0xfbac40: stur            xzr, [x0, #0x1f]
    // 0xfbac44: b               #0xfbac64
    // 0xfbac48: d0 = 20.000000
    //     0xfbac48: fmov            d0, #20.00000000
    // 0xfbac4c: r0 = EdgeInsetsDirectional()
    //     0xfbac4c: bl              #0xb50060  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xfbac50: d0 = 20.000000
    //     0xfbac50: fmov            d0, #20.00000000
    // 0xfbac54: StoreField: r0->field_7 = d0
    //     0xfbac54: stur            d0, [x0, #7]
    // 0xfbac58: StoreField: r0->field_f = rZR
    //     0xfbac58: stur            xzr, [x0, #0xf]
    // 0xfbac5c: ArrayStore: r0[0] = d0  ; List_8
    //     0xfbac5c: stur            d0, [x0, #0x17]
    // 0xfbac60: StoreField: r0->field_1f = rZR
    //     0xfbac60: stur            xzr, [x0, #0x1f]
    // 0xfbac64: stur            x0, [fp, #-0x10]
    // 0xfbac68: r1 = <Widget>
    //     0xfbac68: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfbac6c: r2 = 0
    //     0xfbac6c: mov             x2, #0
    // 0xfbac70: r0 = _GrowableList()
    //     0xfbac70: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfbac74: stur            x0, [fp, #-0x68]
    // 0xfbac78: LoadField: r1 = r0->field_b
    //     0xfbac78: ldur            w1, [x0, #0xb]
    // 0xfbac7c: LoadField: r2 = r0->field_f
    //     0xfbac7c: ldur            w2, [x0, #0xf]
    // 0xfbac80: DecompressPointer r2
    //     0xfbac80: add             x2, x2, HEAP, lsl #32
    // 0xfbac84: LoadField: r3 = r2->field_b
    //     0xfbac84: ldur            w3, [x2, #0xb]
    // 0xfbac88: r2 = LoadInt32Instr(r1)
    //     0xfbac88: sbfx            x2, x1, #1, #0x1f
    // 0xfbac8c: stur            x2, [fp, #-0x30]
    // 0xfbac90: r1 = LoadInt32Instr(r3)
    //     0xfbac90: sbfx            x1, x3, #1, #0x1f
    // 0xfbac94: cmp             x2, x1
    // 0xfbac98: b.ne            #0xfbaca4
    // 0xfbac9c: mov             x1, x0
    // 0xfbaca0: r0 = _growToNextCapacity()
    //     0xfbaca0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfbaca4: ldur            x2, [fp, #-0x68]
    // 0xfbaca8: ldur            x4, [fp, #-0x10]
    // 0xfbacac: ldur            x3, [fp, #-0x30]
    // 0xfbacb0: add             x0, x3, #1
    // 0xfbacb4: lsl             x1, x0, #1
    // 0xfbacb8: StoreField: r2->field_b = r1
    //     0xfbacb8: stur            w1, [x2, #0xb]
    // 0xfbacbc: LoadField: r1 = r2->field_f
    //     0xfbacbc: ldur            w1, [x2, #0xf]
    // 0xfbacc0: DecompressPointer r1
    //     0xfbacc0: add             x1, x1, HEAP, lsl #32
    // 0xfbacc4: ldur            x0, [fp, #-0x18]
    // 0xfbacc8: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfbacc8: add             x25, x1, x3, lsl #2
    //     0xfbaccc: add             x25, x25, #0xf
    //     0xfbacd0: str             w0, [x25]
    //     0xfbacd4: tbz             w0, #0, #0xfbacf0
    //     0xfbacd8: ldurb           w16, [x1, #-1]
    //     0xfbacdc: ldurb           w17, [x0, #-1]
    //     0xfbace0: and             x16, x17, x16, lsr #2
    //     0xfbace4: tst             x16, HEAP, lsr #32
    //     0xfbace8: b.eq            #0xfbacf0
    //     0xfbacec: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfbacf0: r0 = Row()
    //     0xfbacf0: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xfbacf4: mov             x1, x0
    // 0xfbacf8: r0 = Instance_Axis
    //     0xfbacf8: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xfbacfc: stur            x1, [fp, #-0x18]
    // 0xfbad00: StoreField: r1->field_f = r0
    //     0xfbad00: stur            w0, [x1, #0xf]
    // 0xfbad04: r0 = Instance_MainAxisAlignment
    //     0xfbad04: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xfbad08: ldr             x0, [x0, #0x820]
    // 0xfbad0c: StoreField: r1->field_13 = r0
    //     0xfbad0c: stur            w0, [x1, #0x13]
    // 0xfbad10: r0 = Instance_MainAxisSize
    //     0xfbad10: add             x0, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xfbad14: ldr             x0, [x0, #0x200]
    // 0xfbad18: ArrayStore: r1[0] = r0  ; List_4
    //     0xfbad18: stur            w0, [x1, #0x17]
    // 0xfbad1c: r0 = Instance_CrossAxisAlignment
    //     0xfbad1c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xfbad20: ldr             x0, [x0, #0x888]
    // 0xfbad24: StoreField: r1->field_1b = r0
    //     0xfbad24: stur            w0, [x1, #0x1b]
    // 0xfbad28: r0 = Instance_VerticalDirection
    //     0xfbad28: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xfbad2c: ldr             x0, [x0, #0x838]
    // 0xfbad30: StoreField: r1->field_23 = r0
    //     0xfbad30: stur            w0, [x1, #0x23]
    // 0xfbad34: r0 = Instance_Clip
    //     0xfbad34: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfbad38: ldr             x0, [x0, #0x840]
    // 0xfbad3c: StoreField: r1->field_2b = r0
    //     0xfbad3c: stur            w0, [x1, #0x2b]
    // 0xfbad40: StoreField: r1->field_2f = rZR
    //     0xfbad40: stur            xzr, [x1, #0x2f]
    // 0xfbad44: ldur            x2, [fp, #-0x68]
    // 0xfbad48: StoreField: r1->field_b = r2
    //     0xfbad48: stur            w2, [x1, #0xb]
    // 0xfbad4c: r0 = Padding()
    //     0xfbad4c: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xfbad50: mov             x1, x0
    // 0xfbad54: ldur            x0, [fp, #-0x10]
    // 0xfbad58: stur            x1, [fp, #-0x68]
    // 0xfbad5c: StoreField: r1->field_f = r0
    //     0xfbad5c: stur            w0, [x1, #0xf]
    // 0xfbad60: ldur            x0, [fp, #-0x18]
    // 0xfbad64: StoreField: r1->field_b = r0
    //     0xfbad64: stur            w0, [x1, #0xb]
    // 0xfbad68: r0 = _ChildOverflowBox()
    //     0xfbad68: bl              #0xfbb000  ; Allocate_ChildOverflowBoxStub -> _ChildOverflowBox (size=0x10)
    // 0xfbad6c: mov             x1, x0
    // 0xfbad70: ldur            x0, [fp, #-0x68]
    // 0xfbad74: StoreField: r1->field_b = r0
    //     0xfbad74: stur            w0, [x1, #0xb]
    // 0xfbad78: ldur            x9, [fp, #-0x20]
    // 0xfbad7c: mov             x8, x1
    // 0xfbad80: ldur            x0, [fp, #-8]
    // 0xfbad84: ldur            x7, [fp, #-0x38]
    // 0xfbad88: ldur            d0, [fp, #-0x90]
    // 0xfbad8c: ldur            d1, [fp, #-0x88]
    // 0xfbad90: ldur            d2, [fp, #-0x80]
    // 0xfbad94: ldur            d3, [fp, #-0x78]
    // 0xfbad98: ldur            d4, [fp, #-0x70]
    // 0xfbad9c: ldur            x4, [fp, #-0x50]
    // 0xfbada0: ldur            x1, [fp, #-0x60]
    // 0xfbada4: ldur            x2, [fp, #-0x28]
    // 0xfbada8: ldur            x6, [fp, #-0x40]
    // 0xfbadac: ldur            x5, [fp, #-0x48]
    // 0xfbadb0: ldur            x3, [fp, #-0x58]
    // 0xfbadb4: stur            x9, [fp, #-0x18]
    // 0xfbadb8: stur            x8, [fp, #-0x20]
    // 0xfbadbc: LoadField: r10 = r0->field_2b
    //     0xfbadbc: ldur            w10, [x0, #0x2b]
    // 0xfbadc0: DecompressPointer r10
    //     0xfbadc0: add             x10, x10, HEAP, lsl #32
    // 0xfbadc4: stur            x10, [fp, #-0x10]
    // 0xfbadc8: r0 = RawMaterialButton()
    //     0xfbadc8: bl              #0xdbf82c  ; AllocateRawMaterialButtonStub -> RawMaterialButton (size=0x88)
    // 0xfbadcc: mov             x1, x0
    // 0xfbadd0: ldur            x0, [fp, #-0x10]
    // 0xfbadd4: stur            x1, [fp, #-0x68]
    // 0xfbadd8: StoreField: r1->field_b = r0
    //     0xfbadd8: stur            w0, [x1, #0xb]
    // 0xfbaddc: r0 = _EffectiveMouseCursor()
    //     0xfbaddc: bl              #0xfbaf88  ; Allocate_EffectiveMouseCursorStub -> _EffectiveMouseCursor (size=0x10)
    // 0xfbade0: mov             x1, x0
    // 0xfbade4: ldur            x0, [fp, #-0x68]
    // 0xfbade8: ArrayStore: r0[0] = r1  ; List_4
    //     0xfbade8: stur            w1, [x0, #0x17]
    // 0xfbadec: ldur            x1, [fp, #-0x60]
    // 0xfbadf0: StoreField: r0->field_1b = r1
    //     0xfbadf0: stur            w1, [x0, #0x1b]
    // 0xfbadf4: ldur            x1, [fp, #-0x38]
    // 0xfbadf8: StoreField: r0->field_1f = r1
    //     0xfbadf8: stur            w1, [x0, #0x1f]
    // 0xfbadfc: ldur            x1, [fp, #-0x40]
    // 0xfbae00: StoreField: r0->field_23 = r1
    //     0xfbae00: stur            w1, [x0, #0x23]
    // 0xfbae04: ldur            x1, [fp, #-0x48]
    // 0xfbae08: StoreField: r0->field_27 = r1
    //     0xfbae08: stur            w1, [x0, #0x27]
    // 0xfbae0c: ldur            x1, [fp, #-0x58]
    // 0xfbae10: StoreField: r0->field_2f = r1
    //     0xfbae10: stur            w1, [x0, #0x2f]
    // 0xfbae14: ldur            d0, [fp, #-0x90]
    // 0xfbae18: StoreField: r0->field_33 = d0
    //     0xfbae18: stur            d0, [x0, #0x33]
    // 0xfbae1c: ldur            d0, [fp, #-0x88]
    // 0xfbae20: StoreField: r0->field_43 = d0
    //     0xfbae20: stur            d0, [x0, #0x43]
    // 0xfbae24: ldur            d0, [fp, #-0x80]
    // 0xfbae28: StoreField: r0->field_3b = d0
    //     0xfbae28: stur            d0, [x0, #0x3b]
    // 0xfbae2c: ldur            d0, [fp, #-0x70]
    // 0xfbae30: StoreField: r0->field_4b = d0
    //     0xfbae30: stur            d0, [x0, #0x4b]
    // 0xfbae34: ldur            d0, [fp, #-0x78]
    // 0xfbae38: StoreField: r0->field_53 = d0
    //     0xfbae38: stur            d0, [x0, #0x53]
    // 0xfbae3c: r1 = Instance_EdgeInsets
    //     0xfbae3c: ldr             x1, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xfbae40: StoreField: r0->field_5b = r1
    //     0xfbae40: stur            w1, [x0, #0x5b]
    // 0xfbae44: r1 = Instance_VisualDensity
    //     0xfbae44: add             x1, PP, #0x12, lsl #12  ; [pp+0x12ef0] Obj!VisualDensity@12b1d61
    //     0xfbae48: ldr             x1, [x1, #0xef0]
    // 0xfbae4c: StoreField: r0->field_5f = r1
    //     0xfbae4c: stur            w1, [x0, #0x5f]
    // 0xfbae50: ldur            x1, [fp, #-0x18]
    // 0xfbae54: StoreField: r0->field_63 = r1
    //     0xfbae54: stur            w1, [x0, #0x63]
    // 0xfbae58: ldur            x1, [fp, #-0x28]
    // 0xfbae5c: StoreField: r0->field_67 = r1
    //     0xfbae5c: stur            w1, [x0, #0x67]
    // 0xfbae60: r1 = Instance_Duration
    //     0xfbae60: add             x1, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xfbae64: ldr             x1, [x1, #0x318]
    // 0xfbae68: StoreField: r0->field_6b = r1
    //     0xfbae68: stur            w1, [x0, #0x6b]
    // 0xfbae6c: r1 = Instance_Clip
    //     0xfbae6c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfbae70: ldr             x1, [x1, #0x840]
    // 0xfbae74: StoreField: r0->field_7f = r1
    //     0xfbae74: stur            w1, [x0, #0x7f]
    // 0xfbae78: r1 = false
    //     0xfbae78: add             x1, NULL, #0x30  ; false
    // 0xfbae7c: StoreField: r0->field_7b = r1
    //     0xfbae7c: stur            w1, [x0, #0x7b]
    // 0xfbae80: ldur            x2, [fp, #-0x20]
    // 0xfbae84: StoreField: r0->field_6f = r2
    //     0xfbae84: stur            w2, [x0, #0x6f]
    // 0xfbae88: r2 = true
    //     0xfbae88: add             x2, NULL, #0x20  ; true
    // 0xfbae8c: StoreField: r0->field_83 = r2
    //     0xfbae8c: stur            w2, [x0, #0x83]
    // 0xfbae90: ldur            x3, [fp, #-0x50]
    // 0xfbae94: StoreField: r0->field_73 = r3
    //     0xfbae94: stur            w3, [x0, #0x73]
    // 0xfbae98: ldur            x3, [fp, #-8]
    // 0xfbae9c: LoadField: r4 = r3->field_f
    //     0xfbae9c: ldur            w4, [x3, #0xf]
    // 0xfbaea0: DecompressPointer r4
    //     0xfbaea0: add             x4, x4, HEAP, lsl #32
    // 0xfbaea4: stur            x4, [fp, #-0x10]
    // 0xfbaea8: cmp             w4, NULL
    // 0xfbaeac: b.eq            #0xfbaed4
    // 0xfbaeb0: r0 = Tooltip()
    //     0xfbaeb0: bl              #0xd0deac  ; AllocateTooltipStub -> Tooltip (size=0x68)
    // 0xfbaeb4: mov             x1, x0
    // 0xfbaeb8: ldur            x0, [fp, #-0x10]
    // 0xfbaebc: StoreField: r1->field_b = r0
    //     0xfbaebc: stur            w0, [x1, #0xb]
    // 0xfbaec0: r0 = true
    //     0xfbaec0: add             x0, NULL, #0x20  ; true
    // 0xfbaec4: StoreField: r1->field_4b = r0
    //     0xfbaec4: stur            w0, [x1, #0x4b]
    // 0xfbaec8: ldur            x0, [fp, #-0x68]
    // 0xfbaecc: StoreField: r1->field_2f = r0
    //     0xfbaecc: stur            w0, [x1, #0x2f]
    // 0xfbaed0: mov             x0, x1
    // 0xfbaed4: stur            x0, [fp, #-8]
    // 0xfbaed8: r0 = Hero()
    //     0xfbaed8: bl              #0xdfe1e4  ; AllocateHeroStub -> Hero (size=0x2c)
    // 0xfbaedc: mov             x1, x0
    // 0xfbaee0: r0 = Instance__DefaultHeroTag
    //     0xfbaee0: add             x0, PP, #0x19, lsl #12  ; [pp+0x19650] Obj!_DefaultHeroTag@129ed01
    //     0xfbaee4: ldr             x0, [x0, #0x650]
    // 0xfbaee8: stur            x1, [fp, #-0x10]
    // 0xfbaeec: StoreField: r1->field_b = r0
    //     0xfbaeec: stur            w0, [x1, #0xb]
    // 0xfbaef0: r0 = false
    //     0xfbaef0: add             x0, NULL, #0x30  ; false
    // 0xfbaef4: StoreField: r1->field_1f = r0
    //     0xfbaef4: stur            w0, [x1, #0x1f]
    // 0xfbaef8: r0 = Instance_Cubic
    //     0xfbaef8: ldr             x0, [PP, #0x5660]  ; [pp+0x5660] Obj!Cubic@129f451
    // 0xfbaefc: StoreField: r1->field_23 = r0
    //     0xfbaefc: stur            w0, [x1, #0x23]
    // 0xfbaf00: ldur            x0, [fp, #-8]
    // 0xfbaf04: StoreField: r1->field_13 = r0
    //     0xfbaf04: stur            w0, [x1, #0x13]
    // 0xfbaf08: r0 = MergeSemantics()
    //     0xfbaf08: bl              #0xd32f80  ; AllocateMergeSemanticsStub -> MergeSemantics (size=0x10)
    // 0xfbaf0c: ldur            x1, [fp, #-0x10]
    // 0xfbaf10: StoreField: r0->field_b = r1
    //     0xfbaf10: stur            w1, [x0, #0xb]
    // 0xfbaf14: LeaveFrame
    //     0xfbaf14: mov             SP, fp
    //     0xfbaf18: ldp             fp, lr, [SP], #0x10
    // 0xfbaf1c: ret
    //     0xfbaf1c: ret             
    // 0xfbaf20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbaf20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbaf24: b               #0xfba36c
    // 0xfbaf28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbaf28: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfbaf2c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xfbaf2c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xfbaf30: r0 = NullCastErrorSharedWithFPURegs()
    //     0xfbaf30: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xfbaf34: r0 = NullCastErrorSharedWithFPURegs()
    //     0xfbaf34: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xfbaf38: r0 = NullCastErrorSharedWithFPURegs()
    //     0xfbaf38: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xfbaf3c: stp             q4, q5, [SP, #-0x20]!
    // 0xfbaf40: stp             q2, q3, [SP, #-0x20]!
    // 0xfbaf44: stp             q0, q1, [SP, #-0x20]!
    // 0xfbaf48: stp             x5, x6, [SP, #-0x10]!
    // 0xfbaf4c: stp             x3, x4, [SP, #-0x10]!
    // 0xfbaf50: stp             x0, x2, [SP, #-0x10]!
    // 0xfbaf54: r0 = AllocateDouble()
    //     0xfbaf54: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfbaf58: mov             x1, x0
    // 0xfbaf5c: ldp             x0, x2, [SP], #0x10
    // 0xfbaf60: ldp             x3, x4, [SP], #0x10
    // 0xfbaf64: ldp             x5, x6, [SP], #0x10
    // 0xfbaf68: ldp             q0, q1, [SP], #0x20
    // 0xfbaf6c: ldp             q2, q3, [SP], #0x20
    // 0xfbaf70: ldp             q4, q5, [SP], #0x20
    // 0xfbaf74: b               #0xfba928
    // 0xfbaf78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbaf78: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfbaf7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbaf7c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfbaf80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbaf80: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfbaf84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbaf84: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6653, size: 0x10, field offset: 0x10
//   const constructor, 
class _ChildOverflowBox extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf4ae0, size: 0xb4
    // 0xcf4ae0: EnterFrame
    //     0xcf4ae0: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4ae4: mov             fp, SP
    // 0xcf4ae8: AllocStack(0x10)
    //     0xcf4ae8: sub             SP, SP, #0x10
    // 0xcf4aec: SetupParameters(dynamic _ /* r2 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf4aec: mov             x4, x2
    //     0xcf4af0: stur            x2, [fp, #-8]
    //     0xcf4af4: stur            x3, [fp, #-0x10]
    // 0xcf4af8: CheckStackOverflow
    //     0xcf4af8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf4afc: cmp             SP, x16
    //     0xcf4b00: b.ls            #0xcf4b8c
    // 0xcf4b04: mov             x0, x3
    // 0xcf4b08: r2 = Null
    //     0xcf4b08: mov             x2, NULL
    // 0xcf4b0c: r1 = Null
    //     0xcf4b0c: mov             x1, NULL
    // 0xcf4b10: r4 = 60
    //     0xcf4b10: mov             x4, #0x3c
    // 0xcf4b14: branchIfSmi(r0, 0xcf4b20)
    //     0xcf4b14: tbz             w0, #0, #0xcf4b20
    // 0xcf4b18: r4 = LoadClassIdInstr(r0)
    //     0xcf4b18: ldur            x4, [x0, #-1]
    //     0xcf4b1c: ubfx            x4, x4, #0xc, #0x14
    // 0xcf4b20: r17 = 4888
    //     0xcf4b20: mov             x17, #0x1318
    // 0xcf4b24: cmp             x4, x17
    // 0xcf4b28: b.eq            #0xcf4b40
    // 0xcf4b2c: r8 = _RenderChildOverflowBox
    //     0xcf4b2c: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8c930] Type: _RenderChildOverflowBox
    //     0xcf4b30: ldr             x8, [x8, #0x930]
    // 0xcf4b34: r3 = Null
    //     0xcf4b34: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c938] Null
    //     0xcf4b38: ldr             x3, [x3, #0x938]
    // 0xcf4b3c: r0 = DefaultTypeTest()
    //     0xcf4b3c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf4b40: ldur            x1, [fp, #-8]
    // 0xcf4b44: r0 = of()
    //     0xcf4b44: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xcf4b48: ldur            x1, [fp, #-0x10]
    // 0xcf4b4c: LoadField: r2 = r1->field_5b
    //     0xcf4b4c: ldur            w2, [x1, #0x5b]
    // 0xcf4b50: DecompressPointer r2
    //     0xcf4b50: add             x2, x2, HEAP, lsl #32
    // 0xcf4b54: cmp             w2, w0
    // 0xcf4b58: b.eq            #0xcf4b7c
    // 0xcf4b5c: StoreField: r1->field_5b = r0
    //     0xcf4b5c: stur            w0, [x1, #0x5b]
    //     0xcf4b60: ldurb           w16, [x1, #-1]
    //     0xcf4b64: ldurb           w17, [x0, #-1]
    //     0xcf4b68: and             x16, x17, x16, lsr #2
    //     0xcf4b6c: tst             x16, HEAP, lsr #32
    //     0xcf4b70: b.eq            #0xcf4b78
    //     0xcf4b74: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf4b78: r0 = _markNeedResolution()
    //     0xcf4b78: bl              #0xcf4640  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::_markNeedResolution
    // 0xcf4b7c: r0 = Null
    //     0xcf4b7c: mov             x0, NULL
    // 0xcf4b80: LeaveFrame
    //     0xcf4b80: mov             SP, fp
    //     0xcf4b84: ldp             fp, lr, [SP], #0x10
    // 0xcf4b88: ret
    //     0xcf4b88: ret             
    // 0xcf4b8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf4b8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf4b90: b               #0xcf4b04
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11cf9f0, size: 0x54
    // 0x11cf9f0: EnterFrame
    //     0x11cf9f0: stp             fp, lr, [SP, #-0x10]!
    //     0x11cf9f4: mov             fp, SP
    // 0x11cf9f8: AllocStack(0x8)
    //     0x11cf9f8: sub             SP, SP, #8
    // 0x11cf9fc: SetupParameters(_ChildOverflowBox this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x11cf9fc: mov             x0, x1
    //     0x11cfa00: mov             x1, x2
    // 0x11cfa04: CheckStackOverflow
    //     0x11cfa04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cfa08: cmp             SP, x16
    //     0x11cfa0c: b.ls            #0x11cfa3c
    // 0x11cfa10: r0 = of()
    //     0x11cfa10: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x11cfa14: stur            x0, [fp, #-8]
    // 0x11cfa18: r0 = _RenderChildOverflowBox()
    //     0x11cfa18: bl              #0x11cfa44  ; Allocate_RenderChildOverflowBoxStub -> _RenderChildOverflowBox (size=0x60)
    // 0x11cfa1c: mov             x1, x0
    // 0x11cfa20: ldur            x2, [fp, #-8]
    // 0x11cfa24: stur            x0, [fp, #-8]
    // 0x11cfa28: r0 = _RenderAppBarTitleBox()
    //     0x11cfa28: bl              #0x11cf6bc  ; [package:flutter/src/material/app_bar.dart] _RenderAppBarTitleBox::_RenderAppBarTitleBox
    // 0x11cfa2c: ldur            x0, [fp, #-8]
    // 0x11cfa30: LeaveFrame
    //     0x11cfa30: mov             SP, fp
    //     0x11cfa34: ldp             fp, lr, [SP], #0x10
    // 0x11cfa38: ret
    //     0x11cfa38: ret             
    // 0x11cfa3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cfa3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cfa40: b               #0x11cfa10
  }
}

// class id: 8288, size: 0x14, field offset: 0x14
enum _FloatingActionButtonType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa094, size: 0x64
    // 0x11aa094: EnterFrame
    //     0x11aa094: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa098: mov             fp, SP
    // 0x11aa09c: AllocStack(0x10)
    //     0x11aa09c: sub             SP, SP, #0x10
    // 0x11aa0a0: SetupParameters(_FloatingActionButtonType this /* r1 => r0, fp-0x8 */)
    //     0x11aa0a0: mov             x0, x1
    //     0x11aa0a4: stur            x1, [fp, #-8]
    // 0x11aa0a8: CheckStackOverflow
    //     0x11aa0a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa0ac: cmp             SP, x16
    //     0x11aa0b0: b.ls            #0x11aa0f0
    // 0x11aa0b4: r1 = Null
    //     0x11aa0b4: mov             x1, NULL
    // 0x11aa0b8: r2 = 4
    //     0x11aa0b8: mov             x2, #4
    // 0x11aa0bc: r0 = AllocateArray()
    //     0x11aa0bc: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa0c0: r16 = "_FloatingActionButtonType."
    //     0x11aa0c0: add             x16, PP, #0x80, lsl #12  ; [pp+0x80940] "_FloatingActionButtonType."
    //     0x11aa0c4: ldr             x16, [x16, #0x940]
    // 0x11aa0c8: StoreField: r0->field_f = r16
    //     0x11aa0c8: stur            w16, [x0, #0xf]
    // 0x11aa0cc: ldur            x1, [fp, #-8]
    // 0x11aa0d0: LoadField: r2 = r1->field_f
    //     0x11aa0d0: ldur            w2, [x1, #0xf]
    // 0x11aa0d4: DecompressPointer r2
    //     0x11aa0d4: add             x2, x2, HEAP, lsl #32
    // 0x11aa0d8: StoreField: r0->field_13 = r2
    //     0x11aa0d8: stur            w2, [x0, #0x13]
    // 0x11aa0dc: str             x0, [SP]
    // 0x11aa0e0: r0 = _interpolate()
    //     0x11aa0e0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa0e4: LeaveFrame
    //     0x11aa0e4: mov             SP, fp
    //     0x11aa0e8: ldp             fp, lr, [SP], #0x10
    // 0x11aa0ec: ret
    //     0x11aa0ec: ret             
    // 0x11aa0f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa0f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa0f4: b               #0x11aa0b4
  }
}
