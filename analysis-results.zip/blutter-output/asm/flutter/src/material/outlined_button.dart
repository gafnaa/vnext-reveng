// lib: , url: package:flutter/src/material/outlined_button.dart

// class id: 1048924, size: 0x8
class :: {
}

// class id: 5194, size: 0x74, field offset: 0x6c
class _OutlinedButtonDefaultsM3 extends ButtonStyle {

  late final ColorScheme _colors; // offset: 0x70

  get _ padding(/* No info */) {
    // ** addr: 0x1141d40, size: 0x54
    // 0x1141d40: EnterFrame
    //     0x1141d40: stp             fp, lr, [SP, #-0x10]!
    //     0x1141d44: mov             fp, SP
    // 0x1141d48: AllocStack(0x8)
    //     0x1141d48: sub             SP, SP, #8
    // 0x1141d4c: CheckStackOverflow
    //     0x1141d4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1141d50: cmp             SP, x16
    //     0x1141d54: b.ls            #0x1141d8c
    // 0x1141d58: LoadField: r0 = r1->field_6b
    //     0x1141d58: ldur            w0, [x1, #0x6b]
    // 0x1141d5c: DecompressPointer r0
    //     0x1141d5c: add             x0, x0, HEAP, lsl #32
    // 0x1141d60: mov             x1, x0
    // 0x1141d64: r0 = _scaledPadding()
    //     0x1141d64: bl              #0x1140b90  ; [package:flutter/src/material/elevated_button.dart] ::_scaledPadding
    // 0x1141d68: r1 = <EdgeInsetsGeometry>
    //     0x1141d68: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a98] TypeArguments: <EdgeInsetsGeometry>
    //     0x1141d6c: ldr             x1, [x1, #0xa98]
    // 0x1141d70: stur            x0, [fp, #-8]
    // 0x1141d74: r0 = WidgetStatePropertyAll()
    //     0x1141d74: bl              #0xd132c8  ; AllocateWidgetStatePropertyAllStub -> WidgetStatePropertyAll<X0> (size=0x10)
    // 0x1141d78: ldur            x1, [fp, #-8]
    // 0x1141d7c: StoreField: r0->field_b = r1
    //     0x1141d7c: stur            w1, [x0, #0xb]
    // 0x1141d80: LeaveFrame
    //     0x1141d80: mov             SP, fp
    //     0x1141d84: ldp             fp, lr, [SP], #0x10
    // 0x1141d88: ret
    //     0x1141d88: ret             
    // 0x1141d8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1141d8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1141d90: b               #0x1141d58
  }
  get _ iconColor(/* No info */) {
    // ** addr: 0x1152078, size: 0x68
    // 0x1152078: EnterFrame
    //     0x1152078: stp             fp, lr, [SP, #-0x10]!
    //     0x115207c: mov             fp, SP
    // 0x1152080: AllocStack(0x18)
    //     0x1152080: sub             SP, SP, #0x18
    // 0x1152084: SetupParameters(_OutlinedButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x1152084: stur            x1, [fp, #-8]
    // 0x1152088: CheckStackOverflow
    //     0x1152088: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115208c: cmp             SP, x16
    //     0x1152090: b.ls            #0x11520d8
    // 0x1152094: r1 = 1
    //     0x1152094: mov             x1, #1
    // 0x1152098: r0 = AllocateContext()
    //     0x1152098: bl              #0x13de838  ; AllocateContextStub
    // 0x115209c: mov             x1, x0
    // 0x11520a0: ldur            x0, [fp, #-8]
    // 0x11520a4: StoreField: r1->field_f = r0
    //     0x11520a4: stur            w0, [x1, #0xf]
    // 0x11520a8: mov             x2, x1
    // 0x11520ac: r1 = Function '<anonymous closure>':.
    //     0x11520ac: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0e08] AnonymousClosure: (0x11520e0), in [package:flutter/src/material/outlined_button.dart] _OutlinedButtonDefaultsM3::iconColor (0x1152078)
    //     0x11520b0: ldr             x1, [x1, #0xe08]
    // 0x11520b4: r0 = AllocateClosure()
    //     0x11520b4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11520b8: r16 = <Color>
    //     0x11520b8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x11520bc: ldr             x16, [x16, #0xa90]
    // 0x11520c0: stp             x0, x16, [SP]
    // 0x11520c4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x11520c4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x11520c8: r0 = resolveWith()
    //     0x11520c8: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x11520cc: LeaveFrame
    //     0x11520cc: mov             SP, fp
    //     0x11520d0: ldp             fp, lr, [SP], #0x10
    // 0x11520d4: ret
    //     0x11520d4: ret             
    // 0x11520d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11520d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11520dc: b               #0x1152094
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x11520e0, size: 0x264
    // 0x11520e0: EnterFrame
    //     0x11520e0: stp             fp, lr, [SP, #-0x10]!
    //     0x11520e4: mov             fp, SP
    // 0x11520e8: AllocStack(0x8)
    //     0x11520e8: sub             SP, SP, #8
    // 0x11520ec: SetupParameters([dynamic _ /* r0 */])
    //     0x11520ec: ldr             x0, [fp, #0x18]
    //     0x11520f0: ldur            w3, [x0, #0x17]
    //     0x11520f4: add             x3, x3, HEAP, lsl #32
    //     0x11520f8: stur            x3, [fp, #-8]
    // 0x11520fc: CheckStackOverflow
    //     0x11520fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1152100: cmp             SP, x16
    //     0x1152104: b.ls            #0x115233c
    // 0x1152108: ldr             x4, [fp, #0x10]
    // 0x115210c: r0 = LoadClassIdInstr(r4)
    //     0x115210c: ldur            x0, [x4, #-1]
    //     0x1152110: ubfx            x0, x0, #0xc, #0x14
    // 0x1152114: mov             x1, x4
    // 0x1152118: r2 = Instance_WidgetState
    //     0x1152118: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0x115211c: ldr             x2, [x2, #0xa70]
    // 0x1152120: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1152120: mov             x17, #0x2929
    //     0x1152124: movk            x17, #1, lsl #16
    //     0x1152128: add             lr, x0, x17
    //     0x115212c: ldr             lr, [x21, lr, lsl #3]
    //     0x1152130: blr             lr
    // 0x1152134: tbnz            w0, #4, #0x1152194
    // 0x1152138: ldur            x3, [fp, #-8]
    // 0x115213c: LoadField: r1 = r3->field_f
    //     0x115213c: ldur            w1, [x3, #0xf]
    // 0x1152140: DecompressPointer r1
    //     0x1152140: add             x1, x1, HEAP, lsl #32
    // 0x1152144: LoadField: r0 = r1->field_6f
    //     0x1152144: ldur            w0, [x1, #0x6f]
    // 0x1152148: DecompressPointer r0
    //     0x1152148: add             x0, x0, HEAP, lsl #32
    // 0x115214c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1152150: cmp             w0, w16
    // 0x1152154: b.ne            #0x1152164
    // 0x1152158: r2 = _colors
    //     0x1152158: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0df8] Field <_OutlinedButtonDefaultsM3@763109675._colors@763109675>: late final (offset: 0x70)
    //     0x115215c: ldr             x2, [x2, #0xdf8]
    // 0x1152160: r0 = InitLateFinalInstanceField()
    //     0x1152160: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1152164: LoadField: r1 = r0->field_7f
    //     0x1152164: ldur            w1, [x0, #0x7f]
    // 0x1152168: DecompressPointer r1
    //     0x1152168: add             x1, x1, HEAP, lsl #32
    // 0x115216c: r0 = LoadClassIdInstr(r1)
    //     0x115216c: ldur            x0, [x1, #-1]
    //     0x1152170: ubfx            x0, x0, #0xc, #0x14
    // 0x1152174: d0 = 0.380000
    //     0x1152174: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1152178: ldr             d0, [x17, #0x1f0]
    // 0x115217c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x115217c: sub             lr, x0, #1, lsl #12
    //     0x1152180: ldr             lr, [x21, lr, lsl #3]
    //     0x1152184: blr             lr
    // 0x1152188: LeaveFrame
    //     0x1152188: mov             SP, fp
    //     0x115218c: ldp             fp, lr, [SP], #0x10
    // 0x1152190: ret
    //     0x1152190: ret             
    // 0x1152194: ldr             x4, [fp, #0x10]
    // 0x1152198: ldur            x3, [fp, #-8]
    // 0x115219c: r0 = LoadClassIdInstr(r4)
    //     0x115219c: ldur            x0, [x4, #-1]
    //     0x11521a0: ubfx            x0, x0, #0xc, #0x14
    // 0x11521a4: mov             x1, x4
    // 0x11521a8: r2 = Instance_WidgetState
    //     0x11521a8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0x11521ac: ldr             x2, [x2, #0xa48]
    // 0x11521b0: r0 = GDT[cid_x0 + 0x12929]()
    //     0x11521b0: mov             x17, #0x2929
    //     0x11521b4: movk            x17, #1, lsl #16
    //     0x11521b8: add             lr, x0, x17
    //     0x11521bc: ldr             lr, [x21, lr, lsl #3]
    //     0x11521c0: blr             lr
    // 0x11521c4: tbnz            w0, #4, #0x115220c
    // 0x11521c8: ldur            x3, [fp, #-8]
    // 0x11521cc: LoadField: r1 = r3->field_f
    //     0x11521cc: ldur            w1, [x3, #0xf]
    // 0x11521d0: DecompressPointer r1
    //     0x11521d0: add             x1, x1, HEAP, lsl #32
    // 0x11521d4: LoadField: r0 = r1->field_6f
    //     0x11521d4: ldur            w0, [x1, #0x6f]
    // 0x11521d8: DecompressPointer r0
    //     0x11521d8: add             x0, x0, HEAP, lsl #32
    // 0x11521dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11521e0: cmp             w0, w16
    // 0x11521e4: b.ne            #0x11521f4
    // 0x11521e8: r2 = _colors
    //     0x11521e8: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0df8] Field <_OutlinedButtonDefaultsM3@763109675._colors@763109675>: late final (offset: 0x70)
    //     0x11521ec: ldr             x2, [x2, #0xdf8]
    // 0x11521f0: r0 = InitLateFinalInstanceField()
    //     0x11521f0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11521f4: LoadField: r1 = r0->field_b
    //     0x11521f4: ldur            w1, [x0, #0xb]
    // 0x11521f8: DecompressPointer r1
    //     0x11521f8: add             x1, x1, HEAP, lsl #32
    // 0x11521fc: mov             x0, x1
    // 0x1152200: LeaveFrame
    //     0x1152200: mov             SP, fp
    //     0x1152204: ldp             fp, lr, [SP], #0x10
    // 0x1152208: ret
    //     0x1152208: ret             
    // 0x115220c: ldr             x4, [fp, #0x10]
    // 0x1152210: ldur            x3, [fp, #-8]
    // 0x1152214: r0 = LoadClassIdInstr(r4)
    //     0x1152214: ldur            x0, [x4, #-1]
    //     0x1152218: ubfx            x0, x0, #0xc, #0x14
    // 0x115221c: mov             x1, x4
    // 0x1152220: r2 = Instance_WidgetState
    //     0x1152220: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0x1152224: ldr             x2, [x2, #0xa50]
    // 0x1152228: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1152228: mov             x17, #0x2929
    //     0x115222c: movk            x17, #1, lsl #16
    //     0x1152230: add             lr, x0, x17
    //     0x1152234: ldr             lr, [x21, lr, lsl #3]
    //     0x1152238: blr             lr
    // 0x115223c: tbnz            w0, #4, #0x1152284
    // 0x1152240: ldur            x3, [fp, #-8]
    // 0x1152244: LoadField: r1 = r3->field_f
    //     0x1152244: ldur            w1, [x3, #0xf]
    // 0x1152248: DecompressPointer r1
    //     0x1152248: add             x1, x1, HEAP, lsl #32
    // 0x115224c: LoadField: r0 = r1->field_6f
    //     0x115224c: ldur            w0, [x1, #0x6f]
    // 0x1152250: DecompressPointer r0
    //     0x1152250: add             x0, x0, HEAP, lsl #32
    // 0x1152254: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1152258: cmp             w0, w16
    // 0x115225c: b.ne            #0x115226c
    // 0x1152260: r2 = _colors
    //     0x1152260: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0df8] Field <_OutlinedButtonDefaultsM3@763109675._colors@763109675>: late final (offset: 0x70)
    //     0x1152264: ldr             x2, [x2, #0xdf8]
    // 0x1152268: r0 = InitLateFinalInstanceField()
    //     0x1152268: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x115226c: LoadField: r1 = r0->field_b
    //     0x115226c: ldur            w1, [x0, #0xb]
    // 0x1152270: DecompressPointer r1
    //     0x1152270: add             x1, x1, HEAP, lsl #32
    // 0x1152274: mov             x0, x1
    // 0x1152278: LeaveFrame
    //     0x1152278: mov             SP, fp
    //     0x115227c: ldp             fp, lr, [SP], #0x10
    // 0x1152280: ret
    //     0x1152280: ret             
    // 0x1152284: ldr             x1, [fp, #0x10]
    // 0x1152288: ldur            x3, [fp, #-8]
    // 0x115228c: r0 = LoadClassIdInstr(r1)
    //     0x115228c: ldur            x0, [x1, #-1]
    //     0x1152290: ubfx            x0, x0, #0xc, #0x14
    // 0x1152294: r2 = Instance_WidgetState
    //     0x1152294: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0x1152298: ldr             x2, [x2, #0xa60]
    // 0x115229c: r0 = GDT[cid_x0 + 0x12929]()
    //     0x115229c: mov             x17, #0x2929
    //     0x11522a0: movk            x17, #1, lsl #16
    //     0x11522a4: add             lr, x0, x17
    //     0x11522a8: ldr             lr, [x21, lr, lsl #3]
    //     0x11522ac: blr             lr
    // 0x11522b0: tbnz            w0, #4, #0x11522f8
    // 0x11522b4: ldur            x0, [fp, #-8]
    // 0x11522b8: LoadField: r1 = r0->field_f
    //     0x11522b8: ldur            w1, [x0, #0xf]
    // 0x11522bc: DecompressPointer r1
    //     0x11522bc: add             x1, x1, HEAP, lsl #32
    // 0x11522c0: LoadField: r0 = r1->field_6f
    //     0x11522c0: ldur            w0, [x1, #0x6f]
    // 0x11522c4: DecompressPointer r0
    //     0x11522c4: add             x0, x0, HEAP, lsl #32
    // 0x11522c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11522cc: cmp             w0, w16
    // 0x11522d0: b.ne            #0x11522e0
    // 0x11522d4: r2 = _colors
    //     0x11522d4: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0df8] Field <_OutlinedButtonDefaultsM3@763109675._colors@763109675>: late final (offset: 0x70)
    //     0x11522d8: ldr             x2, [x2, #0xdf8]
    // 0x11522dc: r0 = InitLateFinalInstanceField()
    //     0x11522dc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11522e0: LoadField: r1 = r0->field_b
    //     0x11522e0: ldur            w1, [x0, #0xb]
    // 0x11522e4: DecompressPointer r1
    //     0x11522e4: add             x1, x1, HEAP, lsl #32
    // 0x11522e8: mov             x0, x1
    // 0x11522ec: LeaveFrame
    //     0x11522ec: mov             SP, fp
    //     0x11522f0: ldp             fp, lr, [SP], #0x10
    // 0x11522f4: ret
    //     0x11522f4: ret             
    // 0x11522f8: ldur            x0, [fp, #-8]
    // 0x11522fc: LoadField: r1 = r0->field_f
    //     0x11522fc: ldur            w1, [x0, #0xf]
    // 0x1152300: DecompressPointer r1
    //     0x1152300: add             x1, x1, HEAP, lsl #32
    // 0x1152304: LoadField: r0 = r1->field_6f
    //     0x1152304: ldur            w0, [x1, #0x6f]
    // 0x1152308: DecompressPointer r0
    //     0x1152308: add             x0, x0, HEAP, lsl #32
    // 0x115230c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1152310: cmp             w0, w16
    // 0x1152314: b.ne            #0x1152324
    // 0x1152318: r2 = _colors
    //     0x1152318: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0df8] Field <_OutlinedButtonDefaultsM3@763109675._colors@763109675>: late final (offset: 0x70)
    //     0x115231c: ldr             x2, [x2, #0xdf8]
    // 0x1152320: r0 = InitLateFinalInstanceField()
    //     0x1152320: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1152324: LoadField: r1 = r0->field_b
    //     0x1152324: ldur            w1, [x0, #0xb]
    // 0x1152328: DecompressPointer r1
    //     0x1152328: add             x1, x1, HEAP, lsl #32
    // 0x115232c: mov             x0, x1
    // 0x1152330: LeaveFrame
    //     0x1152330: mov             SP, fp
    //     0x1152334: ldp             fp, lr, [SP], #0x10
    // 0x1152338: ret
    //     0x1152338: ret             
    // 0x115233c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x115233c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1152340: b               #0x1152108
  }
  get _ side(/* No info */) {
    // ** addr: 0x11819e8, size: 0x68
    // 0x11819e8: EnterFrame
    //     0x11819e8: stp             fp, lr, [SP, #-0x10]!
    //     0x11819ec: mov             fp, SP
    // 0x11819f0: AllocStack(0x18)
    //     0x11819f0: sub             SP, SP, #0x18
    // 0x11819f4: SetupParameters(_OutlinedButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x11819f4: stur            x1, [fp, #-8]
    // 0x11819f8: CheckStackOverflow
    //     0x11819f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11819fc: cmp             SP, x16
    //     0x1181a00: b.ls            #0x1181a48
    // 0x1181a04: r1 = 1
    //     0x1181a04: mov             x1, #1
    // 0x1181a08: r0 = AllocateContext()
    //     0x1181a08: bl              #0x13de838  ; AllocateContextStub
    // 0x1181a0c: mov             x1, x0
    // 0x1181a10: ldur            x0, [fp, #-8]
    // 0x1181a14: StoreField: r1->field_f = r0
    //     0x1181a14: stur            w0, [x1, #0xf]
    // 0x1181a18: mov             x2, x1
    // 0x1181a1c: r1 = Function '<anonymous closure>':.
    //     0x1181a1c: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0df0] AnonymousClosure: (0x1181a50), in [package:flutter/src/material/outlined_button.dart] _OutlinedButtonDefaultsM3::side (0x11819e8)
    //     0x1181a20: ldr             x1, [x1, #0xdf0]
    // 0x1181a24: r0 = AllocateClosure()
    //     0x1181a24: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1181a28: r16 = <BorderSide>
    //     0x1181a28: add             x16, PP, #0x80, lsl #12  ; [pp+0x80c98] TypeArguments: <BorderSide>
    //     0x1181a2c: ldr             x16, [x16, #0xc98]
    // 0x1181a30: stp             x0, x16, [SP]
    // 0x1181a34: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1181a34: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1181a38: r0 = resolveWith()
    //     0x1181a38: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1181a3c: LeaveFrame
    //     0x1181a3c: mov             SP, fp
    //     0x1181a40: ldp             fp, lr, [SP], #0x10
    // 0x1181a44: ret
    //     0x1181a44: ret             
    // 0x1181a48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1181a48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1181a4c: b               #0x1181a04
  }
  [closure] BorderSide <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x1181a50, size: 0x23c
    // 0x1181a50: EnterFrame
    //     0x1181a50: stp             fp, lr, [SP, #-0x10]!
    //     0x1181a54: mov             fp, SP
    // 0x1181a58: AllocStack(0x10)
    //     0x1181a58: sub             SP, SP, #0x10
    // 0x1181a5c: SetupParameters([dynamic _ /* r0 */])
    //     0x1181a5c: ldr             x0, [fp, #0x18]
    //     0x1181a60: ldur            w3, [x0, #0x17]
    //     0x1181a64: add             x3, x3, HEAP, lsl #32
    //     0x1181a68: stur            x3, [fp, #-8]
    // 0x1181a6c: CheckStackOverflow
    //     0x1181a6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1181a70: cmp             SP, x16
    //     0x1181a74: b.ls            #0x1181c84
    // 0x1181a78: ldr             x4, [fp, #0x10]
    // 0x1181a7c: r0 = LoadClassIdInstr(r4)
    //     0x1181a7c: ldur            x0, [x4, #-1]
    //     0x1181a80: ubfx            x0, x0, #0xc, #0x14
    // 0x1181a84: mov             x1, x4
    // 0x1181a88: r2 = Instance_WidgetState
    //     0x1181a88: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0x1181a8c: ldr             x2, [x2, #0xa70]
    // 0x1181a90: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1181a90: mov             x17, #0x2929
    //     0x1181a94: movk            x17, #1, lsl #16
    //     0x1181a98: add             lr, x0, x17
    //     0x1181a9c: ldr             lr, [x21, lr, lsl #3]
    //     0x1181aa0: blr             lr
    // 0x1181aa4: tbnz            w0, #4, #0x1181b38
    // 0x1181aa8: ldur            x3, [fp, #-8]
    // 0x1181aac: LoadField: r1 = r3->field_f
    //     0x1181aac: ldur            w1, [x3, #0xf]
    // 0x1181ab0: DecompressPointer r1
    //     0x1181ab0: add             x1, x1, HEAP, lsl #32
    // 0x1181ab4: LoadField: r0 = r1->field_6f
    //     0x1181ab4: ldur            w0, [x1, #0x6f]
    // 0x1181ab8: DecompressPointer r0
    //     0x1181ab8: add             x0, x0, HEAP, lsl #32
    // 0x1181abc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1181ac0: cmp             w0, w16
    // 0x1181ac4: b.ne            #0x1181ad4
    // 0x1181ac8: r2 = _colors
    //     0x1181ac8: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0df8] Field <_OutlinedButtonDefaultsM3@763109675._colors@763109675>: late final (offset: 0x70)
    //     0x1181acc: ldr             x2, [x2, #0xdf8]
    // 0x1181ad0: r0 = InitLateFinalInstanceField()
    //     0x1181ad0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1181ad4: LoadField: r1 = r0->field_7f
    //     0x1181ad4: ldur            w1, [x0, #0x7f]
    // 0x1181ad8: DecompressPointer r1
    //     0x1181ad8: add             x1, x1, HEAP, lsl #32
    // 0x1181adc: r0 = LoadClassIdInstr(r1)
    //     0x1181adc: ldur            x0, [x1, #-1]
    //     0x1181ae0: ubfx            x0, x0, #0xc, #0x14
    // 0x1181ae4: d0 = 0.120000
    //     0x1181ae4: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x1181ae8: ldr             d0, [x17, #0xc40]
    // 0x1181aec: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1181aec: sub             lr, x0, #1, lsl #12
    //     0x1181af0: ldr             lr, [x21, lr, lsl #3]
    //     0x1181af4: blr             lr
    // 0x1181af8: stur            x0, [fp, #-0x10]
    // 0x1181afc: r0 = BorderSide()
    //     0x1181afc: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x1181b00: mov             x1, x0
    // 0x1181b04: ldur            x0, [fp, #-0x10]
    // 0x1181b08: StoreField: r1->field_7 = r0
    //     0x1181b08: stur            w0, [x1, #7]
    // 0x1181b0c: d0 = 1.000000
    //     0x1181b0c: fmov            d0, #1.00000000
    // 0x1181b10: StoreField: r1->field_b = d0
    //     0x1181b10: stur            d0, [x1, #0xb]
    // 0x1181b14: r4 = Instance_BorderStyle
    //     0x1181b14: add             x4, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x1181b18: ldr             x4, [x4, #0xdc8]
    // 0x1181b1c: StoreField: r1->field_13 = r4
    //     0x1181b1c: stur            w4, [x1, #0x13]
    // 0x1181b20: d1 = -1.000000
    //     0x1181b20: fmov            d1, #-1.00000000
    // 0x1181b24: ArrayStore: r1[0] = d1  ; List_8
    //     0x1181b24: stur            d1, [x1, #0x17]
    // 0x1181b28: mov             x0, x1
    // 0x1181b2c: LeaveFrame
    //     0x1181b2c: mov             SP, fp
    //     0x1181b30: ldp             fp, lr, [SP], #0x10
    // 0x1181b34: ret
    //     0x1181b34: ret             
    // 0x1181b38: ldr             x1, [fp, #0x10]
    // 0x1181b3c: ldur            x3, [fp, #-8]
    // 0x1181b40: r4 = Instance_BorderStyle
    //     0x1181b40: add             x4, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x1181b44: ldr             x4, [x4, #0xdc8]
    // 0x1181b48: d0 = 1.000000
    //     0x1181b48: fmov            d0, #1.00000000
    // 0x1181b4c: d1 = -1.000000
    //     0x1181b4c: fmov            d1, #-1.00000000
    // 0x1181b50: r0 = LoadClassIdInstr(r1)
    //     0x1181b50: ldur            x0, [x1, #-1]
    //     0x1181b54: ubfx            x0, x0, #0xc, #0x14
    // 0x1181b58: r2 = Instance_WidgetState
    //     0x1181b58: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0x1181b5c: ldr             x2, [x2, #0xa60]
    // 0x1181b60: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1181b60: mov             x17, #0x2929
    //     0x1181b64: movk            x17, #1, lsl #16
    //     0x1181b68: add             lr, x0, x17
    //     0x1181b6c: ldr             lr, [x21, lr, lsl #3]
    //     0x1181b70: blr             lr
    // 0x1181b74: tbnz            w0, #4, #0x1181bec
    // 0x1181b78: ldur            x0, [fp, #-8]
    // 0x1181b7c: LoadField: r1 = r0->field_f
    //     0x1181b7c: ldur            w1, [x0, #0xf]
    // 0x1181b80: DecompressPointer r1
    //     0x1181b80: add             x1, x1, HEAP, lsl #32
    // 0x1181b84: LoadField: r0 = r1->field_6f
    //     0x1181b84: ldur            w0, [x1, #0x6f]
    // 0x1181b88: DecompressPointer r0
    //     0x1181b88: add             x0, x0, HEAP, lsl #32
    // 0x1181b8c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1181b90: cmp             w0, w16
    // 0x1181b94: b.ne            #0x1181ba4
    // 0x1181b98: r2 = _colors
    //     0x1181b98: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0df8] Field <_OutlinedButtonDefaultsM3@763109675._colors@763109675>: late final (offset: 0x70)
    //     0x1181b9c: ldr             x2, [x2, #0xdf8]
    // 0x1181ba0: r0 = InitLateFinalInstanceField()
    //     0x1181ba0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1181ba4: LoadField: r1 = r0->field_b
    //     0x1181ba4: ldur            w1, [x0, #0xb]
    // 0x1181ba8: DecompressPointer r1
    //     0x1181ba8: add             x1, x1, HEAP, lsl #32
    // 0x1181bac: stur            x1, [fp, #-0x10]
    // 0x1181bb0: r0 = BorderSide()
    //     0x1181bb0: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x1181bb4: mov             x1, x0
    // 0x1181bb8: ldur            x0, [fp, #-0x10]
    // 0x1181bbc: StoreField: r1->field_7 = r0
    //     0x1181bbc: stur            w0, [x1, #7]
    // 0x1181bc0: d0 = 1.000000
    //     0x1181bc0: fmov            d0, #1.00000000
    // 0x1181bc4: StoreField: r1->field_b = d0
    //     0x1181bc4: stur            d0, [x1, #0xb]
    // 0x1181bc8: r2 = Instance_BorderStyle
    //     0x1181bc8: add             x2, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x1181bcc: ldr             x2, [x2, #0xdc8]
    // 0x1181bd0: StoreField: r1->field_13 = r2
    //     0x1181bd0: stur            w2, [x1, #0x13]
    // 0x1181bd4: d1 = -1.000000
    //     0x1181bd4: fmov            d1, #-1.00000000
    // 0x1181bd8: ArrayStore: r1[0] = d1  ; List_8
    //     0x1181bd8: stur            d1, [x1, #0x17]
    // 0x1181bdc: mov             x0, x1
    // 0x1181be0: LeaveFrame
    //     0x1181be0: mov             SP, fp
    //     0x1181be4: ldp             fp, lr, [SP], #0x10
    // 0x1181be8: ret
    //     0x1181be8: ret             
    // 0x1181bec: ldur            x0, [fp, #-8]
    // 0x1181bf0: r2 = Instance_BorderStyle
    //     0x1181bf0: add             x2, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x1181bf4: ldr             x2, [x2, #0xdc8]
    // 0x1181bf8: d0 = 1.000000
    //     0x1181bf8: fmov            d0, #1.00000000
    // 0x1181bfc: d1 = -1.000000
    //     0x1181bfc: fmov            d1, #-1.00000000
    // 0x1181c00: LoadField: r1 = r0->field_f
    //     0x1181c00: ldur            w1, [x0, #0xf]
    // 0x1181c04: DecompressPointer r1
    //     0x1181c04: add             x1, x1, HEAP, lsl #32
    // 0x1181c08: LoadField: r0 = r1->field_6f
    //     0x1181c08: ldur            w0, [x1, #0x6f]
    // 0x1181c0c: DecompressPointer r0
    //     0x1181c0c: add             x0, x0, HEAP, lsl #32
    // 0x1181c10: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1181c14: cmp             w0, w16
    // 0x1181c18: b.ne            #0x1181c28
    // 0x1181c1c: r2 = _colors
    //     0x1181c1c: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0df8] Field <_OutlinedButtonDefaultsM3@763109675._colors@763109675>: late final (offset: 0x70)
    //     0x1181c20: ldr             x2, [x2, #0xdf8]
    // 0x1181c24: r0 = InitLateFinalInstanceField()
    //     0x1181c24: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1181c28: LoadField: r1 = r0->field_a7
    //     0x1181c28: ldur            w1, [x0, #0xa7]
    // 0x1181c2c: DecompressPointer r1
    //     0x1181c2c: add             x1, x1, HEAP, lsl #32
    // 0x1181c30: cmp             w1, NULL
    // 0x1181c34: b.ne            #0x1181c48
    // 0x1181c38: LoadField: r1 = r0->field_cb
    //     0x1181c38: ldur            w1, [x0, #0xcb]
    // 0x1181c3c: DecompressPointer r1
    //     0x1181c3c: add             x1, x1, HEAP, lsl #32
    // 0x1181c40: mov             x0, x1
    // 0x1181c44: b               #0x1181c4c
    // 0x1181c48: mov             x0, x1
    // 0x1181c4c: stur            x0, [fp, #-8]
    // 0x1181c50: r0 = BorderSide()
    //     0x1181c50: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x1181c54: ldur            x1, [fp, #-8]
    // 0x1181c58: StoreField: r0->field_7 = r1
    //     0x1181c58: stur            w1, [x0, #7]
    // 0x1181c5c: d0 = 1.000000
    //     0x1181c5c: fmov            d0, #1.00000000
    // 0x1181c60: StoreField: r0->field_b = d0
    //     0x1181c60: stur            d0, [x0, #0xb]
    // 0x1181c64: r1 = Instance_BorderStyle
    //     0x1181c64: add             x1, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x1181c68: ldr             x1, [x1, #0xdc8]
    // 0x1181c6c: StoreField: r0->field_13 = r1
    //     0x1181c6c: stur            w1, [x0, #0x13]
    // 0x1181c70: d0 = -1.000000
    //     0x1181c70: fmov            d0, #-1.00000000
    // 0x1181c74: ArrayStore: r0[0] = d0  ; List_8
    //     0x1181c74: stur            d0, [x0, #0x17]
    // 0x1181c78: LeaveFrame
    //     0x1181c78: mov             SP, fp
    //     0x1181c7c: ldp             fp, lr, [SP], #0x10
    // 0x1181c80: ret
    //     0x1181c80: ret             
    // 0x1181c84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1181c84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1181c88: b               #0x1181a78
  }
  get _ overlayColor(/* No info */) {
    // ** addr: 0x12432b4, size: 0x68
    // 0x12432b4: EnterFrame
    //     0x12432b4: stp             fp, lr, [SP, #-0x10]!
    //     0x12432b8: mov             fp, SP
    // 0x12432bc: AllocStack(0x18)
    //     0x12432bc: sub             SP, SP, #0x18
    // 0x12432c0: SetupParameters(_OutlinedButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x12432c0: stur            x1, [fp, #-8]
    // 0x12432c4: CheckStackOverflow
    //     0x12432c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12432c8: cmp             SP, x16
    //     0x12432cc: b.ls            #0x1243314
    // 0x12432d0: r1 = 1
    //     0x12432d0: mov             x1, #1
    // 0x12432d4: r0 = AllocateContext()
    //     0x12432d4: bl              #0x13de838  ; AllocateContextStub
    // 0x12432d8: mov             x1, x0
    // 0x12432dc: ldur            x0, [fp, #-8]
    // 0x12432e0: StoreField: r1->field_f = r0
    //     0x12432e0: stur            w0, [x1, #0xf]
    // 0x12432e4: mov             x2, x1
    // 0x12432e8: r1 = Function '<anonymous closure>':.
    //     0x12432e8: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0e28] AnonymousClosure: (0x124331c), in [package:flutter/src/material/outlined_button.dart] _OutlinedButtonDefaultsM3::overlayColor (0x12432b4)
    //     0x12432ec: ldr             x1, [x1, #0xe28]
    // 0x12432f0: r0 = AllocateClosure()
    //     0x12432f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12432f4: r16 = <Color?>
    //     0x12432f4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x12432f8: ldr             x16, [x16, #0xa40]
    // 0x12432fc: stp             x0, x16, [SP]
    // 0x1243300: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1243300: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1243304: r0 = resolveWith()
    //     0x1243304: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1243308: LeaveFrame
    //     0x1243308: mov             SP, fp
    //     0x124330c: ldp             fp, lr, [SP], #0x10
    // 0x1243310: ret
    //     0x1243310: ret             
    // 0x1243314: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1243314: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1243318: b               #0x12432d0
  }
  [closure] Color? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x124331c, size: 0x1b8
    // 0x124331c: EnterFrame
    //     0x124331c: stp             fp, lr, [SP, #-0x10]!
    //     0x1243320: mov             fp, SP
    // 0x1243324: AllocStack(0x8)
    //     0x1243324: sub             SP, SP, #8
    // 0x1243328: SetupParameters([dynamic _ /* r0 */])
    //     0x1243328: ldr             x0, [fp, #0x18]
    //     0x124332c: ldur            w3, [x0, #0x17]
    //     0x1243330: add             x3, x3, HEAP, lsl #32
    //     0x1243334: stur            x3, [fp, #-8]
    // 0x1243338: CheckStackOverflow
    //     0x1243338: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124333c: cmp             SP, x16
    //     0x1243340: b.ls            #0x12434cc
    // 0x1243344: ldr             x4, [fp, #0x10]
    // 0x1243348: r0 = LoadClassIdInstr(r4)
    //     0x1243348: ldur            x0, [x4, #-1]
    //     0x124334c: ubfx            x0, x0, #0xc, #0x14
    // 0x1243350: mov             x1, x4
    // 0x1243354: r2 = Instance_WidgetState
    //     0x1243354: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0x1243358: ldr             x2, [x2, #0xa48]
    // 0x124335c: r0 = GDT[cid_x0 + 0x12929]()
    //     0x124335c: mov             x17, #0x2929
    //     0x1243360: movk            x17, #1, lsl #16
    //     0x1243364: add             lr, x0, x17
    //     0x1243368: ldr             lr, [x21, lr, lsl #3]
    //     0x124336c: blr             lr
    // 0x1243370: tbnz            w0, #4, #0x12433c0
    // 0x1243374: ldur            x3, [fp, #-8]
    // 0x1243378: LoadField: r1 = r3->field_f
    //     0x1243378: ldur            w1, [x3, #0xf]
    // 0x124337c: DecompressPointer r1
    //     0x124337c: add             x1, x1, HEAP, lsl #32
    // 0x1243380: LoadField: r0 = r1->field_6f
    //     0x1243380: ldur            w0, [x1, #0x6f]
    // 0x1243384: DecompressPointer r0
    //     0x1243384: add             x0, x0, HEAP, lsl #32
    // 0x1243388: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124338c: cmp             w0, w16
    // 0x1243390: b.ne            #0x12433a0
    // 0x1243394: r2 = _colors
    //     0x1243394: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0df8] Field <_OutlinedButtonDefaultsM3@763109675._colors@763109675>: late final (offset: 0x70)
    //     0x1243398: ldr             x2, [x2, #0xdf8]
    // 0x124339c: r0 = InitLateFinalInstanceField()
    //     0x124339c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12433a0: LoadField: r1 = r0->field_b
    //     0x12433a0: ldur            w1, [x0, #0xb]
    // 0x12433a4: DecompressPointer r1
    //     0x12433a4: add             x1, x1, HEAP, lsl #32
    // 0x12433a8: d0 = 0.100000
    //     0x12433a8: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x12433ac: ldr             d0, [x17, #0x1e0]
    // 0x12433b0: r0 = withOpacity()
    //     0x12433b0: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x12433b4: LeaveFrame
    //     0x12433b4: mov             SP, fp
    //     0x12433b8: ldp             fp, lr, [SP], #0x10
    // 0x12433bc: ret
    //     0x12433bc: ret             
    // 0x12433c0: ldr             x4, [fp, #0x10]
    // 0x12433c4: ldur            x3, [fp, #-8]
    // 0x12433c8: r0 = LoadClassIdInstr(r4)
    //     0x12433c8: ldur            x0, [x4, #-1]
    //     0x12433cc: ubfx            x0, x0, #0xc, #0x14
    // 0x12433d0: mov             x1, x4
    // 0x12433d4: r2 = Instance_WidgetState
    //     0x12433d4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0x12433d8: ldr             x2, [x2, #0xa50]
    // 0x12433dc: r0 = GDT[cid_x0 + 0x12929]()
    //     0x12433dc: mov             x17, #0x2929
    //     0x12433e0: movk            x17, #1, lsl #16
    //     0x12433e4: add             lr, x0, x17
    //     0x12433e8: ldr             lr, [x21, lr, lsl #3]
    //     0x12433ec: blr             lr
    // 0x12433f0: tbnz            w0, #4, #0x1243440
    // 0x12433f4: ldur            x3, [fp, #-8]
    // 0x12433f8: LoadField: r1 = r3->field_f
    //     0x12433f8: ldur            w1, [x3, #0xf]
    // 0x12433fc: DecompressPointer r1
    //     0x12433fc: add             x1, x1, HEAP, lsl #32
    // 0x1243400: LoadField: r0 = r1->field_6f
    //     0x1243400: ldur            w0, [x1, #0x6f]
    // 0x1243404: DecompressPointer r0
    //     0x1243404: add             x0, x0, HEAP, lsl #32
    // 0x1243408: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124340c: cmp             w0, w16
    // 0x1243410: b.ne            #0x1243420
    // 0x1243414: r2 = _colors
    //     0x1243414: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0df8] Field <_OutlinedButtonDefaultsM3@763109675._colors@763109675>: late final (offset: 0x70)
    //     0x1243418: ldr             x2, [x2, #0xdf8]
    // 0x124341c: r0 = InitLateFinalInstanceField()
    //     0x124341c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1243420: LoadField: r1 = r0->field_b
    //     0x1243420: ldur            w1, [x0, #0xb]
    // 0x1243424: DecompressPointer r1
    //     0x1243424: add             x1, x1, HEAP, lsl #32
    // 0x1243428: d0 = 0.080000
    //     0x1243428: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x124342c: ldr             d0, [x17, #0xa58]
    // 0x1243430: r0 = withOpacity()
    //     0x1243430: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1243434: LeaveFrame
    //     0x1243434: mov             SP, fp
    //     0x1243438: ldp             fp, lr, [SP], #0x10
    // 0x124343c: ret
    //     0x124343c: ret             
    // 0x1243440: ldr             x1, [fp, #0x10]
    // 0x1243444: ldur            x3, [fp, #-8]
    // 0x1243448: r0 = LoadClassIdInstr(r1)
    //     0x1243448: ldur            x0, [x1, #-1]
    //     0x124344c: ubfx            x0, x0, #0xc, #0x14
    // 0x1243450: r2 = Instance_WidgetState
    //     0x1243450: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0x1243454: ldr             x2, [x2, #0xa60]
    // 0x1243458: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1243458: mov             x17, #0x2929
    //     0x124345c: movk            x17, #1, lsl #16
    //     0x1243460: add             lr, x0, x17
    //     0x1243464: ldr             lr, [x21, lr, lsl #3]
    //     0x1243468: blr             lr
    // 0x124346c: tbnz            w0, #4, #0x12434bc
    // 0x1243470: ldur            x0, [fp, #-8]
    // 0x1243474: LoadField: r1 = r0->field_f
    //     0x1243474: ldur            w1, [x0, #0xf]
    // 0x1243478: DecompressPointer r1
    //     0x1243478: add             x1, x1, HEAP, lsl #32
    // 0x124347c: LoadField: r0 = r1->field_6f
    //     0x124347c: ldur            w0, [x1, #0x6f]
    // 0x1243480: DecompressPointer r0
    //     0x1243480: add             x0, x0, HEAP, lsl #32
    // 0x1243484: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1243488: cmp             w0, w16
    // 0x124348c: b.ne            #0x124349c
    // 0x1243490: r2 = _colors
    //     0x1243490: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0df8] Field <_OutlinedButtonDefaultsM3@763109675._colors@763109675>: late final (offset: 0x70)
    //     0x1243494: ldr             x2, [x2, #0xdf8]
    // 0x1243498: r0 = InitLateFinalInstanceField()
    //     0x1243498: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x124349c: LoadField: r1 = r0->field_b
    //     0x124349c: ldur            w1, [x0, #0xb]
    // 0x12434a0: DecompressPointer r1
    //     0x12434a0: add             x1, x1, HEAP, lsl #32
    // 0x12434a4: d0 = 0.100000
    //     0x12434a4: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x12434a8: ldr             d0, [x17, #0x1e0]
    // 0x12434ac: r0 = withOpacity()
    //     0x12434ac: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x12434b0: LeaveFrame
    //     0x12434b0: mov             SP, fp
    //     0x12434b4: ldp             fp, lr, [SP], #0x10
    // 0x12434b8: ret
    //     0x12434b8: ret             
    // 0x12434bc: r0 = Null
    //     0x12434bc: mov             x0, NULL
    // 0x12434c0: LeaveFrame
    //     0x12434c0: mov             SP, fp
    //     0x12434c4: ldp             fp, lr, [SP], #0x10
    // 0x12434c8: ret
    //     0x12434c8: ret             
    // 0x12434cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12434cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12434d0: b               #0x1243344
  }
  get _ foregroundColor(/* No info */) {
    // ** addr: 0x1249f10, size: 0x68
    // 0x1249f10: EnterFrame
    //     0x1249f10: stp             fp, lr, [SP, #-0x10]!
    //     0x1249f14: mov             fp, SP
    // 0x1249f18: AllocStack(0x18)
    //     0x1249f18: sub             SP, SP, #0x18
    // 0x1249f1c: SetupParameters(_OutlinedButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x1249f1c: stur            x1, [fp, #-8]
    // 0x1249f20: CheckStackOverflow
    //     0x1249f20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1249f24: cmp             SP, x16
    //     0x1249f28: b.ls            #0x1249f70
    // 0x1249f2c: r1 = 1
    //     0x1249f2c: mov             x1, #1
    // 0x1249f30: r0 = AllocateContext()
    //     0x1249f30: bl              #0x13de838  ; AllocateContextStub
    // 0x1249f34: mov             x1, x0
    // 0x1249f38: ldur            x0, [fp, #-8]
    // 0x1249f3c: StoreField: r1->field_f = r0
    //     0x1249f3c: stur            w0, [x1, #0xf]
    // 0x1249f40: mov             x2, x1
    // 0x1249f44: r1 = Function '<anonymous closure>':.
    //     0x1249f44: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0e30] AnonymousClosure: (0x1249f78), in [package:flutter/src/material/outlined_button.dart] _OutlinedButtonDefaultsM3::foregroundColor (0x1249f10)
    //     0x1249f48: ldr             x1, [x1, #0xe30]
    // 0x1249f4c: r0 = AllocateClosure()
    //     0x1249f4c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1249f50: r16 = <Color?>
    //     0x1249f50: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1249f54: ldr             x16, [x16, #0xa40]
    // 0x1249f58: stp             x0, x16, [SP]
    // 0x1249f5c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1249f5c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1249f60: r0 = resolveWith()
    //     0x1249f60: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1249f64: LeaveFrame
    //     0x1249f64: mov             SP, fp
    //     0x1249f68: ldp             fp, lr, [SP], #0x10
    // 0x1249f6c: ret
    //     0x1249f6c: ret             
    // 0x1249f70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1249f70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1249f74: b               #0x1249f2c
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x1249f78, size: 0xfc
    // 0x1249f78: EnterFrame
    //     0x1249f78: stp             fp, lr, [SP, #-0x10]!
    //     0x1249f7c: mov             fp, SP
    // 0x1249f80: AllocStack(0x8)
    //     0x1249f80: sub             SP, SP, #8
    // 0x1249f84: SetupParameters([dynamic _ /* r0 */])
    //     0x1249f84: ldr             x0, [fp, #0x18]
    //     0x1249f88: ldur            w3, [x0, #0x17]
    //     0x1249f8c: add             x3, x3, HEAP, lsl #32
    //     0x1249f90: stur            x3, [fp, #-8]
    // 0x1249f94: CheckStackOverflow
    //     0x1249f94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1249f98: cmp             SP, x16
    //     0x1249f9c: b.ls            #0x124a06c
    // 0x1249fa0: ldr             x1, [fp, #0x10]
    // 0x1249fa4: r0 = LoadClassIdInstr(r1)
    //     0x1249fa4: ldur            x0, [x1, #-1]
    //     0x1249fa8: ubfx            x0, x0, #0xc, #0x14
    // 0x1249fac: r2 = Instance_WidgetState
    //     0x1249fac: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0x1249fb0: ldr             x2, [x2, #0xa70]
    // 0x1249fb4: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1249fb4: mov             x17, #0x2929
    //     0x1249fb8: movk            x17, #1, lsl #16
    //     0x1249fbc: add             lr, x0, x17
    //     0x1249fc0: ldr             lr, [x21, lr, lsl #3]
    //     0x1249fc4: blr             lr
    // 0x1249fc8: tbnz            w0, #4, #0x124a028
    // 0x1249fcc: ldur            x0, [fp, #-8]
    // 0x1249fd0: LoadField: r1 = r0->field_f
    //     0x1249fd0: ldur            w1, [x0, #0xf]
    // 0x1249fd4: DecompressPointer r1
    //     0x1249fd4: add             x1, x1, HEAP, lsl #32
    // 0x1249fd8: LoadField: r0 = r1->field_6f
    //     0x1249fd8: ldur            w0, [x1, #0x6f]
    // 0x1249fdc: DecompressPointer r0
    //     0x1249fdc: add             x0, x0, HEAP, lsl #32
    // 0x1249fe0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1249fe4: cmp             w0, w16
    // 0x1249fe8: b.ne            #0x1249ff8
    // 0x1249fec: r2 = _colors
    //     0x1249fec: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0df8] Field <_OutlinedButtonDefaultsM3@763109675._colors@763109675>: late final (offset: 0x70)
    //     0x1249ff0: ldr             x2, [x2, #0xdf8]
    // 0x1249ff4: r0 = InitLateFinalInstanceField()
    //     0x1249ff4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1249ff8: LoadField: r1 = r0->field_7f
    //     0x1249ff8: ldur            w1, [x0, #0x7f]
    // 0x1249ffc: DecompressPointer r1
    //     0x1249ffc: add             x1, x1, HEAP, lsl #32
    // 0x124a000: r0 = LoadClassIdInstr(r1)
    //     0x124a000: ldur            x0, [x1, #-1]
    //     0x124a004: ubfx            x0, x0, #0xc, #0x14
    // 0x124a008: d0 = 0.380000
    //     0x124a008: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x124a00c: ldr             d0, [x17, #0x1f0]
    // 0x124a010: r0 = GDT[cid_x0 + -0x1000]()
    //     0x124a010: sub             lr, x0, #1, lsl #12
    //     0x124a014: ldr             lr, [x21, lr, lsl #3]
    //     0x124a018: blr             lr
    // 0x124a01c: LeaveFrame
    //     0x124a01c: mov             SP, fp
    //     0x124a020: ldp             fp, lr, [SP], #0x10
    // 0x124a024: ret
    //     0x124a024: ret             
    // 0x124a028: ldur            x0, [fp, #-8]
    // 0x124a02c: LoadField: r1 = r0->field_f
    //     0x124a02c: ldur            w1, [x0, #0xf]
    // 0x124a030: DecompressPointer r1
    //     0x124a030: add             x1, x1, HEAP, lsl #32
    // 0x124a034: LoadField: r0 = r1->field_6f
    //     0x124a034: ldur            w0, [x1, #0x6f]
    // 0x124a038: DecompressPointer r0
    //     0x124a038: add             x0, x0, HEAP, lsl #32
    // 0x124a03c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124a040: cmp             w0, w16
    // 0x124a044: b.ne            #0x124a054
    // 0x124a048: r2 = _colors
    //     0x124a048: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0df8] Field <_OutlinedButtonDefaultsM3@763109675._colors@763109675>: late final (offset: 0x70)
    //     0x124a04c: ldr             x2, [x2, #0xdf8]
    // 0x124a050: r0 = InitLateFinalInstanceField()
    //     0x124a050: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x124a054: LoadField: r1 = r0->field_b
    //     0x124a054: ldur            w1, [x0, #0xb]
    // 0x124a058: DecompressPointer r1
    //     0x124a058: add             x1, x1, HEAP, lsl #32
    // 0x124a05c: mov             x0, x1
    // 0x124a060: LeaveFrame
    //     0x124a060: mov             SP, fp
    //     0x124a064: ldp             fp, lr, [SP], #0x10
    // 0x124a068: ret
    //     0x124a068: ret             
    // 0x124a06c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124a06c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124a070: b               #0x1249fa0
  }
}

// class id: 6150, size: 0x1c, field offset: 0xc
//   const constructor, 
class _OutlinedButtonWithIconChild extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfbcfcc, size: 0x280
    // 0xfbcfcc: EnterFrame
    //     0xfbcfcc: stp             fp, lr, [SP, #-0x10]!
    //     0xfbcfd0: mov             fp, SP
    // 0xfbcfd4: AllocStack(0x28)
    //     0xfbcfd4: sub             SP, SP, #0x28
    // 0xfbcfd8: SetupParameters(_OutlinedButtonWithIconChild this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xfbcfd8: mov             x4, x1
    //     0xfbcfdc: mov             x3, x2
    //     0xfbcfe0: stur            x1, [fp, #-8]
    //     0xfbcfe4: stur            x2, [fp, #-0x10]
    // 0xfbcfe8: CheckStackOverflow
    //     0xfbcfe8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbcfec: cmp             SP, x16
    //     0xfbcff0: b.ls            #0xfbd230
    // 0xfbcff4: LoadField: r0 = r4->field_13
    //     0xfbcff4: ldur            w0, [x4, #0x13]
    // 0xfbcff8: DecompressPointer r0
    //     0xfbcff8: add             x0, x0, HEAP, lsl #32
    // 0xfbcffc: LoadField: r1 = r0->field_7
    //     0xfbcffc: ldur            w1, [x0, #7]
    // 0xfbd000: DecompressPointer r1
    //     0xfbd000: add             x1, x1, HEAP, lsl #32
    // 0xfbd004: cmp             w1, NULL
    // 0xfbd008: b.ne            #0xfbd014
    // 0xfbd00c: r0 = Null
    //     0xfbd00c: mov             x0, NULL
    // 0xfbd010: b               #0xfbd054
    // 0xfbd014: r0 = LoadClassIdInstr(r1)
    //     0xfbd014: ldur            x0, [x1, #-1]
    //     0xfbd018: ubfx            x0, x0, #0xc, #0x14
    // 0xfbd01c: r2 = _ConstSet len:0
    //     0xfbd01c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26248] Set<WidgetState>(0)
    //     0xfbd020: ldr             x2, [x2, #0x248]
    // 0xfbd024: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xfbd024: mov             x17, #0x7c77
    //     0xfbd028: movk            x17, #1, lsl #16
    //     0xfbd02c: add             lr, x0, x17
    //     0xfbd030: ldr             lr, [x21, lr, lsl #3]
    //     0xfbd034: blr             lr
    // 0xfbd038: cmp             w0, NULL
    // 0xfbd03c: b.ne            #0xfbd048
    // 0xfbd040: r0 = Null
    //     0xfbd040: mov             x0, NULL
    // 0xfbd044: b               #0xfbd054
    // 0xfbd048: LoadField: r1 = r0->field_1f
    //     0xfbd048: ldur            w1, [x0, #0x1f]
    // 0xfbd04c: DecompressPointer r1
    //     0xfbd04c: add             x1, x1, HEAP, lsl #32
    // 0xfbd050: mov             x0, x1
    // 0xfbd054: cmp             w0, NULL
    // 0xfbd058: b.ne            #0xfbd064
    // 0xfbd05c: d0 = 14.000000
    //     0xfbd05c: fmov            d0, #14.00000000
    // 0xfbd060: b               #0xfbd068
    // 0xfbd064: LoadField: d0 = r0->field_7
    //     0xfbd064: ldur            d0, [x0, #7]
    // 0xfbd068: ldur            x1, [fp, #-0x10]
    // 0xfbd06c: stur            d0, [fp, #-0x28]
    // 0xfbd070: r0 = textScalerOf()
    //     0xfbd070: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0xfbd074: r1 = LoadClassIdInstr(r0)
    //     0xfbd074: ldur            x1, [x0, #-1]
    //     0xfbd078: ubfx            x1, x1, #0xc, #0x14
    // 0xfbd07c: mov             x16, x0
    // 0xfbd080: mov             x0, x1
    // 0xfbd084: mov             x1, x16
    // 0xfbd088: ldur            d0, [fp, #-0x28]
    // 0xfbd08c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xfbd08c: sub             lr, x0, #1, lsl #12
    //     0xfbd090: ldr             lr, [x21, lr, lsl #3]
    //     0xfbd094: blr             lr
    // 0xfbd098: LoadField: d0 = r0->field_7
    //     0xfbd098: ldur            d0, [x0, #7]
    // 0xfbd09c: d1 = 14.000000
    //     0xfbd09c: fmov            d1, #14.00000000
    // 0xfbd0a0: fdiv            d2, d0, d1
    // 0xfbd0a4: d0 = 1.000000
    //     0xfbd0a4: fmov            d0, #1.00000000
    // 0xfbd0a8: fcmp            d0, d2
    // 0xfbd0ac: b.le            #0xfbd0b8
    // 0xfbd0b0: d1 = 1.000000
    //     0xfbd0b0: fmov            d1, #1.00000000
    // 0xfbd0b4: b               #0xfbd0e0
    // 0xfbd0b8: d1 = 2.000000
    //     0xfbd0b8: fmov            d1, #2.00000000
    // 0xfbd0bc: fcmp            d2, d1
    // 0xfbd0c0: b.le            #0xfbd0cc
    // 0xfbd0c4: d1 = 2.000000
    //     0xfbd0c4: fmov            d1, #2.00000000
    // 0xfbd0c8: b               #0xfbd0e0
    // 0xfbd0cc: fcmp            d2, d2
    // 0xfbd0d0: b.vc            #0xfbd0dc
    // 0xfbd0d4: d1 = 2.000000
    //     0xfbd0d4: fmov            d1, #2.00000000
    // 0xfbd0d8: b               #0xfbd0e0
    // 0xfbd0dc: mov             v1.16b, v2.16b
    // 0xfbd0e0: ldur            x0, [fp, #-8]
    // 0xfbd0e4: fsub            d2, d1, d0
    // 0xfbd0e8: ldur            x1, [fp, #-0x10]
    // 0xfbd0ec: stur            d2, [fp, #-0x28]
    // 0xfbd0f0: r0 = of()
    //     0xfbd0f0: bl              #0xfbd24c  ; [package:flutter/src/material/outlined_button_theme.dart] OutlinedButtonTheme::of
    // 0xfbd0f4: ldur            d0, [fp, #-0x28]
    // 0xfbd0f8: r3 = inline_Allocate_Double()
    //     0xfbd0f8: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xfbd0fc: add             x3, x3, #0x10
    //     0xfbd100: cmp             x0, x3
    //     0xfbd104: b.ls            #0xfbd238
    //     0xfbd108: str             x3, [THR, #0x60]  ; THR::top
    //     0xfbd10c: sub             x3, x3, #0xf
    //     0xfbd110: mov             x0, #0xe19c
    //     0xfbd114: movk            x0, #3, lsl #16
    //     0xfbd118: stur            x0, [x3, #-1]
    // 0xfbd11c: dmb             ishst
    // 0xfbd120: StoreField: r3->field_7 = d0
    //     0xfbd120: stur            d0, [x3, #7]
    // 0xfbd124: r1 = 16
    //     0xfbd124: mov             x1, #0x10
    // 0xfbd128: r2 = 8
    //     0xfbd128: mov             x2, #8
    // 0xfbd12c: r0 = lerpDouble()
    //     0xfbd12c: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xfbd130: mov             x2, x0
    // 0xfbd134: ldur            x0, [fp, #-8]
    // 0xfbd138: stur            x2, [fp, #-0x20]
    // 0xfbd13c: LoadField: r3 = r0->field_f
    //     0xfbd13c: ldur            w3, [x0, #0xf]
    // 0xfbd140: DecompressPointer r3
    //     0xfbd140: add             x3, x3, HEAP, lsl #32
    // 0xfbd144: stur            x3, [fp, #-0x18]
    // 0xfbd148: LoadField: r4 = r0->field_b
    //     0xfbd148: ldur            w4, [x0, #0xb]
    // 0xfbd14c: DecompressPointer r4
    //     0xfbd14c: add             x4, x4, HEAP, lsl #32
    // 0xfbd150: stur            x4, [fp, #-0x10]
    // 0xfbd154: r1 = <FlexParentData>
    //     0xfbd154: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xfbd158: ldr             x1, [x1, #0x878]
    // 0xfbd15c: r0 = Flexible()
    //     0xfbd15c: bl              #0xd0fd68  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0xfbd160: mov             x3, x0
    // 0xfbd164: r0 = 1
    //     0xfbd164: mov             x0, #1
    // 0xfbd168: stur            x3, [fp, #-8]
    // 0xfbd16c: StoreField: r3->field_13 = r0
    //     0xfbd16c: stur            x0, [x3, #0x13]
    // 0xfbd170: r0 = Instance_FlexFit
    //     0xfbd170: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ac30] Obj!FlexFit@12c4661
    //     0xfbd174: ldr             x0, [x0, #0xc30]
    // 0xfbd178: StoreField: r3->field_1b = r0
    //     0xfbd178: stur            w0, [x3, #0x1b]
    // 0xfbd17c: ldur            x0, [fp, #-0x10]
    // 0xfbd180: StoreField: r3->field_b = r0
    //     0xfbd180: stur            w0, [x3, #0xb]
    // 0xfbd184: r1 = Null
    //     0xfbd184: mov             x1, NULL
    // 0xfbd188: r2 = 4
    //     0xfbd188: mov             x2, #4
    // 0xfbd18c: r0 = AllocateArray()
    //     0xfbd18c: bl              #0x13df928  ; AllocateArrayStub
    // 0xfbd190: mov             x2, x0
    // 0xfbd194: ldur            x0, [fp, #-0x18]
    // 0xfbd198: stur            x2, [fp, #-0x10]
    // 0xfbd19c: StoreField: r2->field_f = r0
    //     0xfbd19c: stur            w0, [x2, #0xf]
    // 0xfbd1a0: ldur            x0, [fp, #-8]
    // 0xfbd1a4: StoreField: r2->field_13 = r0
    //     0xfbd1a4: stur            w0, [x2, #0x13]
    // 0xfbd1a8: r1 = <Widget>
    //     0xfbd1a8: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfbd1ac: r0 = AllocateGrowableArray()
    //     0xfbd1ac: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xfbd1b0: mov             x1, x0
    // 0xfbd1b4: ldur            x0, [fp, #-0x10]
    // 0xfbd1b8: stur            x1, [fp, #-8]
    // 0xfbd1bc: StoreField: r1->field_f = r0
    //     0xfbd1bc: stur            w0, [x1, #0xf]
    // 0xfbd1c0: r0 = 4
    //     0xfbd1c0: mov             x0, #4
    // 0xfbd1c4: StoreField: r1->field_b = r0
    //     0xfbd1c4: stur            w0, [x1, #0xb]
    // 0xfbd1c8: r0 = Row()
    //     0xfbd1c8: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xfbd1cc: r1 = Instance_Axis
    //     0xfbd1cc: ldr             x1, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xfbd1d0: StoreField: r0->field_f = r1
    //     0xfbd1d0: stur            w1, [x0, #0xf]
    // 0xfbd1d4: r1 = Instance_MainAxisAlignment
    //     0xfbd1d4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xfbd1d8: ldr             x1, [x1, #0x820]
    // 0xfbd1dc: StoreField: r0->field_13 = r1
    //     0xfbd1dc: stur            w1, [x0, #0x13]
    // 0xfbd1e0: r1 = Instance_MainAxisSize
    //     0xfbd1e0: add             x1, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xfbd1e4: ldr             x1, [x1, #0x200]
    // 0xfbd1e8: ArrayStore: r0[0] = r1  ; List_4
    //     0xfbd1e8: stur            w1, [x0, #0x17]
    // 0xfbd1ec: r1 = Instance_CrossAxisAlignment
    //     0xfbd1ec: add             x1, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xfbd1f0: ldr             x1, [x1, #0x888]
    // 0xfbd1f4: StoreField: r0->field_1b = r1
    //     0xfbd1f4: stur            w1, [x0, #0x1b]
    // 0xfbd1f8: r1 = Instance_VerticalDirection
    //     0xfbd1f8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xfbd1fc: ldr             x1, [x1, #0x838]
    // 0xfbd200: StoreField: r0->field_23 = r1
    //     0xfbd200: stur            w1, [x0, #0x23]
    // 0xfbd204: r1 = Instance_Clip
    //     0xfbd204: add             x1, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfbd208: ldr             x1, [x1, #0x840]
    // 0xfbd20c: StoreField: r0->field_2b = r1
    //     0xfbd20c: stur            w1, [x0, #0x2b]
    // 0xfbd210: ldur            x1, [fp, #-0x20]
    // 0xfbd214: LoadField: d0 = r1->field_7
    //     0xfbd214: ldur            d0, [x1, #7]
    // 0xfbd218: StoreField: r0->field_2f = d0
    //     0xfbd218: stur            d0, [x0, #0x2f]
    // 0xfbd21c: ldur            x1, [fp, #-8]
    // 0xfbd220: StoreField: r0->field_b = r1
    //     0xfbd220: stur            w1, [x0, #0xb]
    // 0xfbd224: LeaveFrame
    //     0xfbd224: mov             SP, fp
    //     0xfbd228: ldp             fp, lr, [SP], #0x10
    // 0xfbd22c: ret
    //     0xfbd22c: ret             
    // 0xfbd230: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbd230: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbd234: b               #0xfbcff4
    // 0xfbd238: SaveReg d0
    //     0xfbd238: str             q0, [SP, #-0x10]!
    // 0xfbd23c: r0 = AllocateDouble()
    //     0xfbd23c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfbd240: mov             x3, x0
    // 0xfbd244: RestoreReg d0
    //     0xfbd244: ldr             q0, [SP], #0x10
    // 0xfbd248: b               #0xfbd120
  }
}

// class id: 6496, size: 0x40, field offset: 0x3c
//   const constructor, 
class OutlinedButton extends ButtonStyleButton {

  _ OutlinedButton.icon(/* No info */) {
    // ** addr: 0x10680ec, size: 0xdc
    // 0x10680ec: EnterFrame
    //     0x10680ec: stp             fp, lr, [SP, #-0x10]!
    //     0x10680f0: mov             fp, SP
    // 0x10680f4: AllocStack(0x28)
    //     0x10680f4: sub             SP, SP, #0x28
    // 0x10680f8: r0 = true
    //     0x10680f8: add             x0, NULL, #0x20  ; true
    // 0x10680fc: mov             x4, x2
    // 0x1068100: stur            x2, [fp, #-0x10]
    // 0x1068104: mov             x2, x5
    // 0x1068108: stur            x5, [fp, #-0x20]
    // 0x106810c: mov             x5, x1
    // 0x1068110: stur            x1, [fp, #-8]
    // 0x1068114: mov             x1, x6
    // 0x1068118: stur            x3, [fp, #-0x18]
    // 0x106811c: stur            x6, [fp, #-0x28]
    // 0x1068120: StoreField: r5->field_3b = r0
    //     0x1068120: stur            w0, [x5, #0x3b]
    // 0x1068124: r0 = _OutlinedButtonWithIconChild()
    //     0x1068124: bl              #0x10681c8  ; Allocate_OutlinedButtonWithIconChildStub -> _OutlinedButtonWithIconChild (size=0x1c)
    // 0x1068128: mov             x2, x0
    // 0x106812c: ldur            x1, [fp, #-0x18]
    // 0x1068130: StoreField: r2->field_b = r1
    //     0x1068130: stur            w1, [x2, #0xb]
    // 0x1068134: ldur            x1, [fp, #-0x10]
    // 0x1068138: StoreField: r2->field_f = r1
    //     0x1068138: stur            w1, [x2, #0xf]
    // 0x106813c: ldur            x1, [fp, #-0x28]
    // 0x1068140: StoreField: r2->field_13 = r1
    //     0x1068140: stur            w1, [x2, #0x13]
    // 0x1068144: ldur            x0, [fp, #-0x20]
    // 0x1068148: ldur            x3, [fp, #-8]
    // 0x106814c: StoreField: r3->field_b = r0
    //     0x106814c: stur            w0, [x3, #0xb]
    //     0x1068150: ldurb           w16, [x3, #-1]
    //     0x1068154: ldurb           w17, [x0, #-1]
    //     0x1068158: and             x16, x17, x16, lsr #2
    //     0x106815c: tst             x16, HEAP, lsr #32
    //     0x1068160: b.eq            #0x1068168
    //     0x1068164: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x1068168: mov             x0, x1
    // 0x106816c: StoreField: r3->field_1b = r0
    //     0x106816c: stur            w0, [x3, #0x1b]
    //     0x1068170: ldurb           w16, [x3, #-1]
    //     0x1068174: ldurb           w17, [x0, #-1]
    //     0x1068178: and             x16, x17, x16, lsr #2
    //     0x106817c: tst             x16, HEAP, lsr #32
    //     0x1068180: b.eq            #0x1068188
    //     0x1068184: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x1068188: r1 = false
    //     0x1068188: add             x1, NULL, #0x30  ; false
    // 0x106818c: StoreField: r3->field_27 = r1
    //     0x106818c: stur            w1, [x3, #0x27]
    // 0x1068190: r1 = true
    //     0x1068190: add             x1, NULL, #0x20  ; true
    // 0x1068194: StoreField: r3->field_2f = r1
    //     0x1068194: stur            w1, [x3, #0x2f]
    // 0x1068198: mov             x0, x2
    // 0x106819c: StoreField: r3->field_37 = r0
    //     0x106819c: stur            w0, [x3, #0x37]
    //     0x10681a0: ldurb           w16, [x3, #-1]
    //     0x10681a4: ldurb           w17, [x0, #-1]
    //     0x10681a8: and             x16, x17, x16, lsr #2
    //     0x10681ac: tst             x16, HEAP, lsr #32
    //     0x10681b0: b.eq            #0x10681b8
    //     0x10681b4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x10681b8: r0 = Null
    //     0x10681b8: mov             x0, NULL
    // 0x10681bc: LeaveFrame
    //     0x10681bc: mov             SP, fp
    //     0x10681c0: ldp             fp, lr, [SP], #0x10
    // 0x10681c4: ret
    //     0x10681c4: ret             
  }
  static _ styleFrom(/* No info */) {
    // ** addr: 0x10681e0, size: 0xb9c
    // 0x10681e0: EnterFrame
    //     0x10681e0: stp             fp, lr, [SP, #-0x10]!
    //     0x10681e4: mov             fp, SP
    // 0x10681e8: AllocStack(0xb8)
    //     0x10681e8: sub             SP, SP, #0xb8
    // 0x10681ec: SetupParameters(dynamic _ /* r1 => fp-0x8 */, dynamic _ /* r2 => fp-0x10 */, {dynamic alignment = Null /* r5, fp-0x98 */, dynamic animationDuration = Null /* r6, fp-0x90 */, dynamic backgroundColor = Null /* r7, fp-0x88 */, dynamic disabledBackgroundColor = Null /* r8 */, dynamic disabledForegroundColor = Null /* r9, fp-0x80 */, dynamic disabledMouseCursor = Null /* r10, fp-0x78 */, dynamic elevation = Null /* r11, fp-0x70 */, dynamic enableFeedback = Null /* r12, fp-0x68 */, dynamic enabledMouseCursor = Null /* r13, fp-0x60 */, dynamic foregroundColor = Null /* r14, fp-0x58 */, dynamic maximumSize = Null /* r19, fp-0x50 */, dynamic minimumSize = Null /* r20, fp-0x48 */, dynamic padding = Null /* r3, fp-0x40 */, dynamic shadowColor = Null /* fp-0x18 */, dynamic splashFactory = Null /* fp-0x20 */, dynamic tapTargetSize = Null /* fp-0x28 */, dynamic textStyle = Null /* r2, fp-0x38 */, dynamic visualDensity = Null /* r0, fp-0x30 */})
    //     0x10681ec: mov             x0, x1
    //     0x10681f0: stur            x1, [fp, #-8]
    //     0x10681f4: stur            x2, [fp, #-0x10]
    //     0x10681f8: ldur            w1, [x4, #0x13]
    //     0x10681fc: ldur            w3, [x4, #0x1f]
    //     0x1068200: add             x3, x3, HEAP, lsl #32
    //     0x1068204: ldr             x16, [PP, #0x5c70]  ; [pp+0x5c70] "alignment"
    //     0x1068208: cmp             w3, w16
    //     0x106820c: b.ne            #0x1068230
    //     0x1068210: ldur            w3, [x4, #0x23]
    //     0x1068214: add             x3, x3, HEAP, lsl #32
    //     0x1068218: sub             w5, w1, w3
    //     0x106821c: add             x3, fp, w5, sxtw #2
    //     0x1068220: ldr             x3, [x3, #8]
    //     0x1068224: mov             x5, x3
    //     0x1068228: mov             x3, #1
    //     0x106822c: b               #0x1068238
    //     0x1068230: mov             x5, NULL
    //     0x1068234: mov             x3, #0
    //     0x1068238: stur            x5, [fp, #-0x98]
    //     0x106823c: lsl             x6, x3, #1
    //     0x1068240: lsl             w7, w6, #1
    //     0x1068244: add             w8, w7, #8
    //     0x1068248: add             x16, x4, w8, sxtw #1
    //     0x106824c: ldur            w9, [x16, #0xf]
    //     0x1068250: add             x9, x9, HEAP, lsl #32
    //     0x1068254: add             x16, PP, #0x15, lsl #12  ; [pp+0x159d0] "animationDuration"
    //     0x1068258: ldr             x16, [x16, #0x9d0]
    //     0x106825c: cmp             w9, w16
    //     0x1068260: b.ne            #0x1068294
    //     0x1068264: add             w3, w7, #0xa
    //     0x1068268: add             x16, x4, w3, sxtw #1
    //     0x106826c: ldur            w7, [x16, #0xf]
    //     0x1068270: add             x7, x7, HEAP, lsl #32
    //     0x1068274: sub             w3, w1, w7
    //     0x1068278: add             x7, fp, w3, sxtw #2
    //     0x106827c: ldr             x7, [x7, #8]
    //     0x1068280: add             w3, w6, #2
    //     0x1068284: sbfx            x6, x3, #1, #0x1f
    //     0x1068288: mov             x3, x6
    //     0x106828c: mov             x6, x7
    //     0x1068290: b               #0x1068298
    //     0x1068294: mov             x6, NULL
    //     0x1068298: stur            x6, [fp, #-0x90]
    //     0x106829c: lsl             x7, x3, #1
    //     0x10682a0: lsl             w8, w7, #1
    //     0x10682a4: add             w9, w8, #8
    //     0x10682a8: add             x16, x4, w9, sxtw #1
    //     0x10682ac: ldur            w10, [x16, #0xf]
    //     0x10682b0: add             x10, x10, HEAP, lsl #32
    //     0x10682b4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12958] "backgroundColor"
    //     0x10682b8: ldr             x16, [x16, #0x958]
    //     0x10682bc: cmp             w10, w16
    //     0x10682c0: b.ne            #0x10682f4
    //     0x10682c4: add             w3, w8, #0xa
    //     0x10682c8: add             x16, x4, w3, sxtw #1
    //     0x10682cc: ldur            w8, [x16, #0xf]
    //     0x10682d0: add             x8, x8, HEAP, lsl #32
    //     0x10682d4: sub             w3, w1, w8
    //     0x10682d8: add             x8, fp, w3, sxtw #2
    //     0x10682dc: ldr             x8, [x8, #8]
    //     0x10682e0: add             w3, w7, #2
    //     0x10682e4: sbfx            x7, x3, #1, #0x1f
    //     0x10682e8: mov             x3, x7
    //     0x10682ec: mov             x7, x8
    //     0x10682f0: b               #0x10682f8
    //     0x10682f4: mov             x7, NULL
    //     0x10682f8: stur            x7, [fp, #-0x88]
    //     0x10682fc: lsl             x8, x3, #1
    //     0x1068300: lsl             w9, w8, #1
    //     0x1068304: add             w10, w9, #8
    //     0x1068308: add             x16, x4, w10, sxtw #1
    //     0x106830c: ldur            w11, [x16, #0xf]
    //     0x1068310: add             x11, x11, HEAP, lsl #32
    //     0x1068314: add             x16, PP, #0x15, lsl #12  ; [pp+0x159d8] "disabledBackgroundColor"
    //     0x1068318: ldr             x16, [x16, #0x9d8]
    //     0x106831c: cmp             w11, w16
    //     0x1068320: b.ne            #0x1068354
    //     0x1068324: add             w3, w9, #0xa
    //     0x1068328: add             x16, x4, w3, sxtw #1
    //     0x106832c: ldur            w9, [x16, #0xf]
    //     0x1068330: add             x9, x9, HEAP, lsl #32
    //     0x1068334: sub             w3, w1, w9
    //     0x1068338: add             x9, fp, w3, sxtw #2
    //     0x106833c: ldr             x9, [x9, #8]
    //     0x1068340: add             w3, w8, #2
    //     0x1068344: sbfx            x8, x3, #1, #0x1f
    //     0x1068348: mov             x3, x8
    //     0x106834c: mov             x8, x9
    //     0x1068350: b               #0x1068358
    //     0x1068354: mov             x8, NULL
    //     0x1068358: lsl             x9, x3, #1
    //     0x106835c: lsl             w10, w9, #1
    //     0x1068360: add             w11, w10, #8
    //     0x1068364: add             x16, x4, w11, sxtw #1
    //     0x1068368: ldur            w12, [x16, #0xf]
    //     0x106836c: add             x12, x12, HEAP, lsl #32
    //     0x1068370: add             x16, PP, #0x15, lsl #12  ; [pp+0x159e0] "disabledForegroundColor"
    //     0x1068374: ldr             x16, [x16, #0x9e0]
    //     0x1068378: cmp             w12, w16
    //     0x106837c: b.ne            #0x10683b0
    //     0x1068380: add             w3, w10, #0xa
    //     0x1068384: add             x16, x4, w3, sxtw #1
    //     0x1068388: ldur            w10, [x16, #0xf]
    //     0x106838c: add             x10, x10, HEAP, lsl #32
    //     0x1068390: sub             w3, w1, w10
    //     0x1068394: add             x10, fp, w3, sxtw #2
    //     0x1068398: ldr             x10, [x10, #8]
    //     0x106839c: add             w3, w9, #2
    //     0x10683a0: sbfx            x9, x3, #1, #0x1f
    //     0x10683a4: mov             x3, x9
    //     0x10683a8: mov             x9, x10
    //     0x10683ac: b               #0x10683b4
    //     0x10683b0: mov             x9, NULL
    //     0x10683b4: stur            x9, [fp, #-0x80]
    //     0x10683b8: lsl             x10, x3, #1
    //     0x10683bc: lsl             w11, w10, #1
    //     0x10683c0: add             w12, w11, #8
    //     0x10683c4: add             x16, x4, w12, sxtw #1
    //     0x10683c8: ldur            w13, [x16, #0xf]
    //     0x10683cc: add             x13, x13, HEAP, lsl #32
    //     0x10683d0: add             x16, PP, #0x15, lsl #12  ; [pp+0x159e8] "disabledMouseCursor"
    //     0x10683d4: ldr             x16, [x16, #0x9e8]
    //     0x10683d8: cmp             w13, w16
    //     0x10683dc: b.ne            #0x1068410
    //     0x10683e0: add             w3, w11, #0xa
    //     0x10683e4: add             x16, x4, w3, sxtw #1
    //     0x10683e8: ldur            w11, [x16, #0xf]
    //     0x10683ec: add             x11, x11, HEAP, lsl #32
    //     0x10683f0: sub             w3, w1, w11
    //     0x10683f4: add             x11, fp, w3, sxtw #2
    //     0x10683f8: ldr             x11, [x11, #8]
    //     0x10683fc: add             w3, w10, #2
    //     0x1068400: sbfx            x10, x3, #1, #0x1f
    //     0x1068404: mov             x3, x10
    //     0x1068408: mov             x10, x11
    //     0x106840c: b               #0x1068414
    //     0x1068410: mov             x10, NULL
    //     0x1068414: stur            x10, [fp, #-0x78]
    //     0x1068418: lsl             x11, x3, #1
    //     0x106841c: lsl             w12, w11, #1
    //     0x1068420: add             w13, w12, #8
    //     0x1068424: add             x16, x4, w13, sxtw #1
    //     0x1068428: ldur            w14, [x16, #0xf]
    //     0x106842c: add             x14, x14, HEAP, lsl #32
    //     0x1068430: add             x16, PP, #0x15, lsl #12  ; [pp+0x159f0] "elevation"
    //     0x1068434: ldr             x16, [x16, #0x9f0]
    //     0x1068438: cmp             w14, w16
    //     0x106843c: b.ne            #0x1068470
    //     0x1068440: add             w3, w12, #0xa
    //     0x1068444: add             x16, x4, w3, sxtw #1
    //     0x1068448: ldur            w12, [x16, #0xf]
    //     0x106844c: add             x12, x12, HEAP, lsl #32
    //     0x1068450: sub             w3, w1, w12
    //     0x1068454: add             x12, fp, w3, sxtw #2
    //     0x1068458: ldr             x12, [x12, #8]
    //     0x106845c: add             w3, w11, #2
    //     0x1068460: sbfx            x11, x3, #1, #0x1f
    //     0x1068464: mov             x3, x11
    //     0x1068468: mov             x11, x12
    //     0x106846c: b               #0x1068474
    //     0x1068470: mov             x11, NULL
    //     0x1068474: stur            x11, [fp, #-0x70]
    //     0x1068478: lsl             x12, x3, #1
    //     0x106847c: lsl             w13, w12, #1
    //     0x1068480: add             w14, w13, #8
    //     0x1068484: add             x16, x4, w14, sxtw #1
    //     0x1068488: ldur            w19, [x16, #0xf]
    //     0x106848c: add             x19, x19, HEAP, lsl #32
    //     0x1068490: add             x16, PP, #0x15, lsl #12  ; [pp+0x159f8] "enableFeedback"
    //     0x1068494: ldr             x16, [x16, #0x9f8]
    //     0x1068498: cmp             w19, w16
    //     0x106849c: b.ne            #0x10684d0
    //     0x10684a0: add             w3, w13, #0xa
    //     0x10684a4: add             x16, x4, w3, sxtw #1
    //     0x10684a8: ldur            w13, [x16, #0xf]
    //     0x10684ac: add             x13, x13, HEAP, lsl #32
    //     0x10684b0: sub             w3, w1, w13
    //     0x10684b4: add             x13, fp, w3, sxtw #2
    //     0x10684b8: ldr             x13, [x13, #8]
    //     0x10684bc: add             w3, w12, #2
    //     0x10684c0: sbfx            x12, x3, #1, #0x1f
    //     0x10684c4: mov             x3, x12
    //     0x10684c8: mov             x12, x13
    //     0x10684cc: b               #0x10684d4
    //     0x10684d0: mov             x12, NULL
    //     0x10684d4: stur            x12, [fp, #-0x68]
    //     0x10684d8: lsl             x13, x3, #1
    //     0x10684dc: lsl             w14, w13, #1
    //     0x10684e0: add             w19, w14, #8
    //     0x10684e4: add             x16, x4, w19, sxtw #1
    //     0x10684e8: ldur            w20, [x16, #0xf]
    //     0x10684ec: add             x20, x20, HEAP, lsl #32
    //     0x10684f0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a00] "enabledMouseCursor"
    //     0x10684f4: ldr             x16, [x16, #0xa00]
    //     0x10684f8: cmp             w20, w16
    //     0x10684fc: b.ne            #0x1068530
    //     0x1068500: add             w3, w14, #0xa
    //     0x1068504: add             x16, x4, w3, sxtw #1
    //     0x1068508: ldur            w14, [x16, #0xf]
    //     0x106850c: add             x14, x14, HEAP, lsl #32
    //     0x1068510: sub             w3, w1, w14
    //     0x1068514: add             x14, fp, w3, sxtw #2
    //     0x1068518: ldr             x14, [x14, #8]
    //     0x106851c: add             w3, w13, #2
    //     0x1068520: sbfx            x13, x3, #1, #0x1f
    //     0x1068524: mov             x3, x13
    //     0x1068528: mov             x13, x14
    //     0x106852c: b               #0x1068534
    //     0x1068530: mov             x13, NULL
    //     0x1068534: stur            x13, [fp, #-0x60]
    //     0x1068538: lsl             x14, x3, #1
    //     0x106853c: lsl             w19, w14, #1
    //     0x1068540: add             w20, w19, #8
    //     0x1068544: add             x16, x4, w20, sxtw #1
    //     0x1068548: ldur            w23, [x16, #0xf]
    //     0x106854c: add             x23, x23, HEAP, lsl #32
    //     0x1068550: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a10] "foregroundColor"
    //     0x1068554: ldr             x16, [x16, #0xa10]
    //     0x1068558: cmp             w23, w16
    //     0x106855c: b.ne            #0x1068590
    //     0x1068560: add             w3, w19, #0xa
    //     0x1068564: add             x16, x4, w3, sxtw #1
    //     0x1068568: ldur            w19, [x16, #0xf]
    //     0x106856c: add             x19, x19, HEAP, lsl #32
    //     0x1068570: sub             w3, w1, w19
    //     0x1068574: add             x19, fp, w3, sxtw #2
    //     0x1068578: ldr             x19, [x19, #8]
    //     0x106857c: add             w3, w14, #2
    //     0x1068580: sbfx            x14, x3, #1, #0x1f
    //     0x1068584: mov             x3, x14
    //     0x1068588: mov             x14, x19
    //     0x106858c: b               #0x1068594
    //     0x1068590: mov             x14, NULL
    //     0x1068594: stur            x14, [fp, #-0x58]
    //     0x1068598: lsl             x19, x3, #1
    //     0x106859c: lsl             w20, w19, #1
    //     0x10685a0: add             w23, w20, #8
    //     0x10685a4: add             x16, x4, w23, sxtw #1
    //     0x10685a8: ldur            w24, [x16, #0xf]
    //     0x10685ac: add             x24, x24, HEAP, lsl #32
    //     0x10685b0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a18] "maximumSize"
    //     0x10685b4: ldr             x16, [x16, #0xa18]
    //     0x10685b8: cmp             w24, w16
    //     0x10685bc: b.ne            #0x10685f0
    //     0x10685c0: add             w3, w20, #0xa
    //     0x10685c4: add             x16, x4, w3, sxtw #1
    //     0x10685c8: ldur            w20, [x16, #0xf]
    //     0x10685cc: add             x20, x20, HEAP, lsl #32
    //     0x10685d0: sub             w3, w1, w20
    //     0x10685d4: add             x20, fp, w3, sxtw #2
    //     0x10685d8: ldr             x20, [x20, #8]
    //     0x10685dc: add             w3, w19, #2
    //     0x10685e0: sbfx            x19, x3, #1, #0x1f
    //     0x10685e4: mov             x3, x19
    //     0x10685e8: mov             x19, x20
    //     0x10685ec: b               #0x10685f4
    //     0x10685f0: mov             x19, NULL
    //     0x10685f4: stur            x19, [fp, #-0x50]
    //     0x10685f8: lsl             x20, x3, #1
    //     0x10685fc: lsl             w23, w20, #1
    //     0x1068600: add             w24, w23, #8
    //     0x1068604: add             x16, x4, w24, sxtw #1
    //     0x1068608: ldur            w25, [x16, #0xf]
    //     0x106860c: add             x25, x25, HEAP, lsl #32
    //     0x1068610: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a20] "minimumSize"
    //     0x1068614: ldr             x16, [x16, #0xa20]
    //     0x1068618: cmp             w25, w16
    //     0x106861c: b.ne            #0x1068650
    //     0x1068620: add             w3, w23, #0xa
    //     0x1068624: add             x16, x4, w3, sxtw #1
    //     0x1068628: ldur            w23, [x16, #0xf]
    //     0x106862c: add             x23, x23, HEAP, lsl #32
    //     0x1068630: sub             w3, w1, w23
    //     0x1068634: add             x23, fp, w3, sxtw #2
    //     0x1068638: ldr             x23, [x23, #8]
    //     0x106863c: add             w3, w20, #2
    //     0x1068640: sbfx            x20, x3, #1, #0x1f
    //     0x1068644: mov             x3, x20
    //     0x1068648: mov             x20, x23
    //     0x106864c: b               #0x1068654
    //     0x1068650: mov             x20, NULL
    //     0x1068654: stur            x20, [fp, #-0x48]
    //     0x1068658: lsl             x23, x3, #1
    //     0x106865c: lsl             w24, w23, #1
    //     0x1068660: add             w25, w24, #8
    //     0x1068664: add             x16, x4, w25, sxtw #1
    //     0x1068668: ldur            w0, [x16, #0xf]
    //     0x106866c: add             x0, x0, HEAP, lsl #32
    //     0x1068670: add             x16, PP, #0x12, lsl #12  ; [pp+0x12838] "padding"
    //     0x1068674: ldr             x16, [x16, #0x838]
    //     0x1068678: cmp             w0, w16
    //     0x106867c: b.ne            #0x10686ac
    //     0x1068680: add             w0, w24, #0xa
    //     0x1068684: add             x16, x4, w0, sxtw #1
    //     0x1068688: ldur            w3, [x16, #0xf]
    //     0x106868c: add             x3, x3, HEAP, lsl #32
    //     0x1068690: sub             w0, w1, w3
    //     0x1068694: add             x3, fp, w0, sxtw #2
    //     0x1068698: ldr             x3, [x3, #8]
    //     0x106869c: add             w0, w23, #2
    //     0x10686a0: sbfx            x23, x0, #1, #0x1f
    //     0x10686a4: mov             x0, x23
    //     0x10686a8: b               #0x10686b4
    //     0x10686ac: mov             x0, x3
    //     0x10686b0: mov             x3, NULL
    //     0x10686b4: stur            x3, [fp, #-0x40]
    //     0x10686b8: lsl             x23, x0, #1
    //     0x10686bc: lsl             w24, w23, #1
    //     0x10686c0: add             w25, w24, #8
    //     0x10686c4: add             x16, x4, w25, sxtw #1
    //     0x10686c8: ldur            w2, [x16, #0xf]
    //     0x10686cc: add             x2, x2, HEAP, lsl #32
    //     0x10686d0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b70] "shadowColor"
    //     0x10686d4: ldr             x16, [x16, #0xb70]
    //     0x10686d8: cmp             w2, w16
    //     0x10686dc: b.ne            #0x106870c
    //     0x10686e0: add             w0, w24, #0xa
    //     0x10686e4: add             x16, x4, w0, sxtw #1
    //     0x10686e8: ldur            w2, [x16, #0xf]
    //     0x10686ec: add             x2, x2, HEAP, lsl #32
    //     0x10686f0: sub             w0, w1, w2
    //     0x10686f4: add             x2, fp, w0, sxtw #2
    //     0x10686f8: ldr             x2, [x2, #8]
    //     0x10686fc: add             w0, w23, #2
    //     0x1068700: sbfx            x23, x0, #1, #0x1f
    //     0x1068704: mov             x0, x23
    //     0x1068708: b               #0x1068710
    //     0x106870c: mov             x2, NULL
    //     0x1068710: stur            x2, [fp, #-0x18]
    //     0x1068714: lsl             x23, x0, #1
    //     0x1068718: lsl             w24, w23, #1
    //     0x106871c: add             w25, w24, #8
    //     0x1068720: add             x16, x4, w25, sxtw #1
    //     0x1068724: ldur            w2, [x16, #0xf]
    //     0x1068728: add             x2, x2, HEAP, lsl #32
    //     0x106872c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b88] "splashFactory"
    //     0x1068730: ldr             x16, [x16, #0xb88]
    //     0x1068734: cmp             w2, w16
    //     0x1068738: b.ne            #0x1068768
    //     0x106873c: add             w0, w24, #0xa
    //     0x1068740: add             x16, x4, w0, sxtw #1
    //     0x1068744: ldur            w2, [x16, #0xf]
    //     0x1068748: add             x2, x2, HEAP, lsl #32
    //     0x106874c: sub             w0, w1, w2
    //     0x1068750: add             x2, fp, w0, sxtw #2
    //     0x1068754: ldr             x2, [x2, #8]
    //     0x1068758: add             w0, w23, #2
    //     0x106875c: sbfx            x23, x0, #1, #0x1f
    //     0x1068760: mov             x0, x23
    //     0x1068764: b               #0x106876c
    //     0x1068768: mov             x2, NULL
    //     0x106876c: stur            x2, [fp, #-0x20]
    //     0x1068770: lsl             x23, x0, #1
    //     0x1068774: lsl             w24, w23, #1
    //     0x1068778: add             w25, w24, #8
    //     0x106877c: add             x16, x4, w25, sxtw #1
    //     0x1068780: ldur            w2, [x16, #0xf]
    //     0x1068784: add             x2, x2, HEAP, lsl #32
    //     0x1068788: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a30] "tapTargetSize"
    //     0x106878c: ldr             x16, [x16, #0xa30]
    //     0x1068790: cmp             w2, w16
    //     0x1068794: b.ne            #0x10687c4
    //     0x1068798: add             w0, w24, #0xa
    //     0x106879c: add             x16, x4, w0, sxtw #1
    //     0x10687a0: ldur            w2, [x16, #0xf]
    //     0x10687a4: add             x2, x2, HEAP, lsl #32
    //     0x10687a8: sub             w0, w1, w2
    //     0x10687ac: add             x2, fp, w0, sxtw #2
    //     0x10687b0: ldr             x2, [x2, #8]
    //     0x10687b4: add             w0, w23, #2
    //     0x10687b8: sbfx            x23, x0, #1, #0x1f
    //     0x10687bc: mov             x0, x23
    //     0x10687c0: b               #0x10687c8
    //     0x10687c4: mov             x2, NULL
    //     0x10687c8: stur            x2, [fp, #-0x28]
    //     0x10687cc: lsl             x23, x0, #1
    //     0x10687d0: lsl             w24, w23, #1
    //     0x10687d4: add             w25, w24, #8
    //     0x10687d8: add             x16, x4, w25, sxtw #1
    //     0x10687dc: ldur            w2, [x16, #0xf]
    //     0x10687e0: add             x2, x2, HEAP, lsl #32
    //     0x10687e4: add             x16, PP, #0x13, lsl #12  ; [pp+0x13e08] "textStyle"
    //     0x10687e8: ldr             x16, [x16, #0xe08]
    //     0x10687ec: cmp             w2, w16
    //     0x10687f0: b.ne            #0x1068820
    //     0x10687f4: add             w0, w24, #0xa
    //     0x10687f8: add             x16, x4, w0, sxtw #1
    //     0x10687fc: ldur            w2, [x16, #0xf]
    //     0x1068800: add             x2, x2, HEAP, lsl #32
    //     0x1068804: sub             w0, w1, w2
    //     0x1068808: add             x2, fp, w0, sxtw #2
    //     0x106880c: ldr             x2, [x2, #8]
    //     0x1068810: add             w0, w23, #2
    //     0x1068814: sbfx            x23, x0, #1, #0x1f
    //     0x1068818: mov             x0, x23
    //     0x106881c: b               #0x1068824
    //     0x1068820: mov             x2, NULL
    //     0x1068824: stur            x2, [fp, #-0x38]
    //     0x1068828: lsl             x23, x0, #1
    //     0x106882c: lsl             w0, w23, #1
    //     0x1068830: add             w23, w0, #8
    //     0x1068834: add             x16, x4, w23, sxtw #1
    //     0x1068838: ldur            w24, [x16, #0xf]
    //     0x106883c: add             x24, x24, HEAP, lsl #32
    //     0x1068840: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a38] "visualDensity"
    //     0x1068844: ldr             x16, [x16, #0xa38]
    //     0x1068848: cmp             w24, w16
    //     0x106884c: b.ne            #0x1068870
    //     0x1068850: add             w23, w0, #0xa
    //     0x1068854: add             x16, x4, w23, sxtw #1
    //     0x1068858: ldur            w0, [x16, #0xf]
    //     0x106885c: add             x0, x0, HEAP, lsl #32
    //     0x1068860: sub             w4, w1, w0
    //     0x1068864: add             x0, fp, w4, sxtw #2
    //     0x1068868: ldr             x0, [x0, #8]
    //     0x106886c: b               #0x1068874
    //     0x1068870: mov             x0, NULL
    //     0x1068874: stur            x0, [fp, #-0x30]
    // 0x1068878: CheckStackOverflow
    //     0x1068878: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x106887c: cmp             SP, x16
    //     0x1068880: b.ls            #0x1068d74
    // 0x1068884: cmp             w7, NULL
    // 0x1068888: b.eq            #0x10688b8
    // 0x106888c: cmp             w8, NULL
    // 0x1068890: b.ne            #0x10688b0
    // 0x1068894: r1 = <Color?>
    //     0x1068894: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1068898: ldr             x1, [x1, #0xa40]
    // 0x106889c: r0 = WidgetStatePropertyAll()
    //     0x106889c: bl              #0xd132c8  ; AllocateWidgetStatePropertyAllStub -> WidgetStatePropertyAll<X0> (size=0x10)
    // 0x10688a0: ldur            x1, [fp, #-0x88]
    // 0x10688a4: StoreField: r0->field_b = r1
    //     0x10688a4: stur            w1, [x0, #0xb]
    // 0x10688a8: mov             x4, x0
    // 0x10688ac: b               #0x10688c8
    // 0x10688b0: mov             x1, x7
    // 0x10688b4: b               #0x10688bc
    // 0x10688b8: mov             x1, x7
    // 0x10688bc: mov             x2, x8
    // 0x10688c0: r0 = defaultColor()
    //     0x10688c0: bl              #0xd171ec  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::defaultColor
    // 0x10688c4: mov             x4, x0
    // 0x10688c8: ldur            x3, [fp, #-0x58]
    // 0x10688cc: stur            x4, [fp, #-0x88]
    // 0x10688d0: cmp             w3, NULL
    // 0x10688d4: b.ne            #0x10688e4
    // 0x10688d8: mov             x0, x4
    // 0x10688dc: r9 = Null
    //     0x10688dc: mov             x9, NULL
    // 0x10688e0: b               #0x1068b60
    // 0x10688e4: r0 = Null
    //     0x10688e4: mov             x0, NULL
    // 0x10688e8: r2 = Null
    //     0x10688e8: mov             x2, NULL
    // 0x10688ec: r1 = Null
    //     0x10688ec: mov             x1, NULL
    // 0x10688f0: cmp             w0, NULL
    // 0x10688f4: b.eq            #0x1068918
    // 0x10688f8: branchIfSmi(r0, 0x1068918)
    //     0x10688f8: tbz             w0, #0, #0x1068918
    // 0x10688fc: r3 = LoadClassIdInstr(r0)
    //     0x10688fc: ldur            x3, [x0, #-1]
    //     0x1068900: ubfx            x3, x3, #0xc, #0x14
    // 0x1068904: sub             x3, x3, #0xecc
    // 0x1068908: cmp             x3, #5
    // 0x106890c: b.ls            #0x1068920
    // 0x1068910: cmp             x3, #0x5ad
    // 0x1068914: b.eq            #0x1068920
    // 0x1068918: r0 = false
    //     0x1068918: add             x0, NULL, #0x30  ; false
    // 0x106891c: b               #0x1068924
    // 0x1068920: r0 = true
    //     0x1068920: add             x0, NULL, #0x20  ; true
    // 0x1068924: tbnz            w0, #4, #0x1068964
    // 0x1068928: r0 = 171
    //     0x1068928: mov             x0, #0xab
    // 0x106892c: r1 = Null
    //     0x106892c: mov             x1, NULL
    // 0x1068930: r0 = GDT[cid_x0 + -0xfe4]()
    //     0x1068930: sub             lr, x0, #0xfe4
    //     0x1068934: ldr             lr, [x21, lr, lsl #3]
    //     0x1068938: blr             lr
    // 0x106893c: mov             v1.16b, v0.16b
    // 0x1068940: d0 = 0.000000
    //     0x1068940: eor             v0.16b, v0.16b, v0.16b
    // 0x1068944: fcmp            d1, d0
    // 0x1068948: b.ne            #0x1068964
    // 0x106894c: r1 = <Color?>
    //     0x106894c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1068950: ldr             x1, [x1, #0xa40]
    // 0x1068954: r0 = WidgetStatePropertyAll()
    //     0x1068954: bl              #0xd132c8  ; AllocateWidgetStatePropertyAllStub -> WidgetStatePropertyAll<X0> (size=0x10)
    // 0x1068958: mov             x9, x0
    // 0x106895c: ldur            x0, [fp, #-0x88]
    // 0x1068960: b               #0x1068b60
    // 0x1068964: r0 = Null
    //     0x1068964: mov             x0, NULL
    // 0x1068968: r2 = Null
    //     0x1068968: mov             x2, NULL
    // 0x106896c: r1 = Null
    //     0x106896c: mov             x1, NULL
    // 0x1068970: cmp             w0, NULL
    // 0x1068974: b.eq            #0x1068998
    // 0x1068978: branchIfSmi(r0, 0x1068998)
    //     0x1068978: tbz             w0, #0, #0x1068998
    // 0x106897c: r3 = LoadClassIdInstr(r0)
    //     0x106897c: ldur            x3, [x0, #-1]
    //     0x1068980: ubfx            x3, x3, #0xc, #0x14
    // 0x1068984: sub             x3, x3, #0xecc
    // 0x1068988: cmp             x3, #5
    // 0x106898c: b.ls            #0x10689a0
    // 0x1068990: cmp             x3, #0x5ad
    // 0x1068994: b.eq            #0x10689a0
    // 0x1068998: r0 = false
    //     0x1068998: add             x0, NULL, #0x30  ; false
    // 0x106899c: b               #0x10689a4
    // 0x10689a0: r0 = true
    //     0x10689a0: add             x0, NULL, #0x20  ; true
    // 0x10689a4: tbnz            w0, #4, #0x10689b0
    // 0x10689a8: r0 = Null
    //     0x10689a8: mov             x0, NULL
    // 0x10689ac: b               #0x10689f8
    // 0x10689b0: ldur            x0, [fp, #-0x58]
    // 0x10689b4: r2 = Null
    //     0x10689b4: mov             x2, NULL
    // 0x10689b8: r1 = Null
    //     0x10689b8: mov             x1, NULL
    // 0x10689bc: cmp             w0, NULL
    // 0x10689c0: b.eq            #0x10689e4
    // 0x10689c4: branchIfSmi(r0, 0x10689e4)
    //     0x10689c4: tbz             w0, #0, #0x10689e4
    // 0x10689c8: r3 = LoadClassIdInstr(r0)
    //     0x10689c8: ldur            x3, [x0, #-1]
    //     0x10689cc: ubfx            x3, x3, #0xc, #0x14
    // 0x10689d0: sub             x3, x3, #0xecc
    // 0x10689d4: cmp             x3, #5
    // 0x10689d8: b.ls            #0x10689ec
    // 0x10689dc: cmp             x3, #0x5ad
    // 0x10689e0: b.eq            #0x10689ec
    // 0x10689e4: r0 = false
    //     0x10689e4: add             x0, NULL, #0x30  ; false
    // 0x10689e8: b               #0x10689f0
    // 0x10689ec: r0 = true
    //     0x10689ec: add             x0, NULL, #0x20  ; true
    // 0x10689f0: tbnz            w0, #4, #0x1068b58
    // 0x10689f4: ldur            x0, [fp, #-0x58]
    // 0x10689f8: stur            x0, [fp, #-0xa0]
    // 0x10689fc: r1 = Null
    //     0x10689fc: mov             x1, NULL
    // 0x1068a00: r2 = 12
    //     0x1068a00: mov             x2, #0xc
    // 0x1068a04: r0 = AllocateArray()
    //     0x1068a04: bl              #0x13df928  ; AllocateArrayStub
    // 0x1068a08: mov             x2, x0
    // 0x1068a0c: stur            x2, [fp, #-0xa8]
    // 0x1068a10: r16 = Instance_WidgetState
    //     0x1068a10: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0x1068a14: ldr             x16, [x16, #0xa48]
    // 0x1068a18: StoreField: r2->field_f = r16
    //     0x1068a18: stur            w16, [x2, #0xf]
    // 0x1068a1c: ldur            x3, [fp, #-0xa0]
    // 0x1068a20: r0 = LoadClassIdInstr(r3)
    //     0x1068a20: ldur            x0, [x3, #-1]
    //     0x1068a24: ubfx            x0, x0, #0xc, #0x14
    // 0x1068a28: mov             x1, x3
    // 0x1068a2c: d0 = 0.100000
    //     0x1068a2c: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x1068a30: ldr             d0, [x17, #0x1e0]
    // 0x1068a34: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1068a34: sub             lr, x0, #1, lsl #12
    //     0x1068a38: ldr             lr, [x21, lr, lsl #3]
    //     0x1068a3c: blr             lr
    // 0x1068a40: ldur            x1, [fp, #-0xa8]
    // 0x1068a44: ArrayStore: r1[1] = r0  ; List_4
    //     0x1068a44: add             x25, x1, #0x13
    //     0x1068a48: str             w0, [x25]
    //     0x1068a4c: tbz             w0, #0, #0x1068a68
    //     0x1068a50: ldurb           w16, [x1, #-1]
    //     0x1068a54: ldurb           w17, [x0, #-1]
    //     0x1068a58: and             x16, x17, x16, lsr #2
    //     0x1068a5c: tst             x16, HEAP, lsr #32
    //     0x1068a60: b.eq            #0x1068a68
    //     0x1068a64: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1068a68: ldur            x2, [fp, #-0xa8]
    // 0x1068a6c: r16 = Instance_WidgetState
    //     0x1068a6c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0x1068a70: ldr             x16, [x16, #0xa50]
    // 0x1068a74: ArrayStore: r2[0] = r16  ; List_4
    //     0x1068a74: stur            w16, [x2, #0x17]
    // 0x1068a78: ldur            x3, [fp, #-0xa0]
    // 0x1068a7c: r0 = LoadClassIdInstr(r3)
    //     0x1068a7c: ldur            x0, [x3, #-1]
    //     0x1068a80: ubfx            x0, x0, #0xc, #0x14
    // 0x1068a84: mov             x1, x3
    // 0x1068a88: d0 = 0.080000
    //     0x1068a88: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x1068a8c: ldr             d0, [x17, #0xa58]
    // 0x1068a90: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1068a90: sub             lr, x0, #1, lsl #12
    //     0x1068a94: ldr             lr, [x21, lr, lsl #3]
    //     0x1068a98: blr             lr
    // 0x1068a9c: ldur            x1, [fp, #-0xa8]
    // 0x1068aa0: ArrayStore: r1[3] = r0  ; List_4
    //     0x1068aa0: add             x25, x1, #0x1b
    //     0x1068aa4: str             w0, [x25]
    //     0x1068aa8: tbz             w0, #0, #0x1068ac4
    //     0x1068aac: ldurb           w16, [x1, #-1]
    //     0x1068ab0: ldurb           w17, [x0, #-1]
    //     0x1068ab4: and             x16, x17, x16, lsr #2
    //     0x1068ab8: tst             x16, HEAP, lsr #32
    //     0x1068abc: b.eq            #0x1068ac4
    //     0x1068ac0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1068ac4: ldur            x2, [fp, #-0xa8]
    // 0x1068ac8: r16 = Instance_WidgetState
    //     0x1068ac8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0x1068acc: ldr             x16, [x16, #0xa60]
    // 0x1068ad0: StoreField: r2->field_1f = r16
    //     0x1068ad0: stur            w16, [x2, #0x1f]
    // 0x1068ad4: ldur            x1, [fp, #-0xa0]
    // 0x1068ad8: r0 = LoadClassIdInstr(r1)
    //     0x1068ad8: ldur            x0, [x1, #-1]
    //     0x1068adc: ubfx            x0, x0, #0xc, #0x14
    // 0x1068ae0: d0 = 0.100000
    //     0x1068ae0: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x1068ae4: ldr             d0, [x17, #0x1e0]
    // 0x1068ae8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1068ae8: sub             lr, x0, #1, lsl #12
    //     0x1068aec: ldr             lr, [x21, lr, lsl #3]
    //     0x1068af0: blr             lr
    // 0x1068af4: ldur            x1, [fp, #-0xa8]
    // 0x1068af8: ArrayStore: r1[5] = r0  ; List_4
    //     0x1068af8: add             x25, x1, #0x23
    //     0x1068afc: str             w0, [x25]
    //     0x1068b00: tbz             w0, #0, #0x1068b1c
    //     0x1068b04: ldurb           w16, [x1, #-1]
    //     0x1068b08: ldurb           w17, [x0, #-1]
    //     0x1068b0c: and             x16, x17, x16, lsr #2
    //     0x1068b10: tst             x16, HEAP, lsr #32
    //     0x1068b14: b.eq            #0x1068b1c
    //     0x1068b18: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1068b1c: r16 = <WidgetState, Color?>
    //     0x1068b1c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a68] TypeArguments: <WidgetState, Color?>
    //     0x1068b20: ldr             x16, [x16, #0xa68]
    // 0x1068b24: ldur            lr, [fp, #-0xa8]
    // 0x1068b28: stp             lr, x16, [SP]
    // 0x1068b2c: r0 = Map._fromLiteral()
    //     0x1068b2c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x1068b30: r1 = <Color?>
    //     0x1068b30: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1068b34: ldr             x1, [x1, #0xa40]
    // 0x1068b38: stur            x0, [fp, #-0xa0]
    // 0x1068b3c: r0 = WidgetStateMapper()
    //     0x1068b3c: bl              #0xd171e0  ; AllocateWidgetStateMapperStub -> WidgetStateMapper<X0> (size=0x10)
    // 0x1068b40: mov             x1, x0
    // 0x1068b44: ldur            x0, [fp, #-0xa0]
    // 0x1068b48: StoreField: r1->field_b = r0
    //     0x1068b48: stur            w0, [x1, #0xb]
    // 0x1068b4c: mov             x9, x1
    // 0x1068b50: ldur            x0, [fp, #-0x88]
    // 0x1068b54: b               #0x1068b60
    // 0x1068b58: ldur            x0, [fp, #-0x88]
    // 0x1068b5c: r9 = Null
    //     0x1068b5c: mov             x9, NULL
    // 0x1068b60: ldur            x1, [fp, #-0x98]
    // 0x1068b64: ldur            x2, [fp, #-0x90]
    // 0x1068b68: ldur            x3, [fp, #-0x78]
    // 0x1068b6c: ldur            x4, [fp, #-0x68]
    // 0x1068b70: ldur            x5, [fp, #-0x60]
    // 0x1068b74: ldur            x6, [fp, #-0x20]
    // 0x1068b78: ldur            x7, [fp, #-0x28]
    // 0x1068b7c: ldur            x8, [fp, #-0x30]
    // 0x1068b80: stur            x9, [fp, #-0xa0]
    // 0x1068b84: r16 = <TextStyle>
    //     0x1068b84: add             x16, PP, #0x18, lsl #12  ; [pp+0x18370] TypeArguments: <TextStyle>
    //     0x1068b88: ldr             x16, [x16, #0x370]
    // 0x1068b8c: ldur            lr, [fp, #-0x38]
    // 0x1068b90: stp             lr, x16, [SP]
    // 0x1068b94: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1068b94: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1068b98: r0 = allOrNull()
    //     0x1068b98: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0x1068b9c: ldur            x1, [fp, #-0x58]
    // 0x1068ba0: ldur            x2, [fp, #-0x80]
    // 0x1068ba4: stur            x0, [fp, #-0x38]
    // 0x1068ba8: r0 = defaultColor()
    //     0x1068ba8: bl              #0xd171ec  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::defaultColor
    // 0x1068bac: stur            x0, [fp, #-0x58]
    // 0x1068bb0: r16 = <Color>
    //     0x1068bb0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1068bb4: ldr             x16, [x16, #0xa90]
    // 0x1068bb8: ldur            lr, [fp, #-0x18]
    // 0x1068bbc: stp             lr, x16, [SP]
    // 0x1068bc0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1068bc0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1068bc4: r0 = allOrNull()
    //     0x1068bc4: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0x1068bc8: stur            x0, [fp, #-0x18]
    // 0x1068bcc: r16 = <double>
    //     0x1068bcc: ldr             x16, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x1068bd0: ldur            lr, [fp, #-0x70]
    // 0x1068bd4: stp             lr, x16, [SP]
    // 0x1068bd8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1068bd8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1068bdc: r0 = allOrNull()
    //     0x1068bdc: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0x1068be0: stur            x0, [fp, #-0x70]
    // 0x1068be4: r16 = <EdgeInsetsGeometry>
    //     0x1068be4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a98] TypeArguments: <EdgeInsetsGeometry>
    //     0x1068be8: ldr             x16, [x16, #0xa98]
    // 0x1068bec: ldur            lr, [fp, #-0x40]
    // 0x1068bf0: stp             lr, x16, [SP]
    // 0x1068bf4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1068bf4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1068bf8: r0 = allOrNull()
    //     0x1068bf8: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0x1068bfc: stur            x0, [fp, #-0x40]
    // 0x1068c00: r16 = <Size>
    //     0x1068c00: add             x16, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0x1068c04: ldr             x16, [x16, #0xaa0]
    // 0x1068c08: ldur            lr, [fp, #-0x48]
    // 0x1068c0c: stp             lr, x16, [SP]
    // 0x1068c10: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1068c10: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1068c14: r0 = allOrNull()
    //     0x1068c14: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0x1068c18: stur            x0, [fp, #-0x48]
    // 0x1068c1c: r16 = <Size>
    //     0x1068c1c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0x1068c20: ldr             x16, [x16, #0xaa0]
    // 0x1068c24: ldur            lr, [fp, #-0x50]
    // 0x1068c28: stp             lr, x16, [SP]
    // 0x1068c2c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1068c2c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1068c30: r0 = allOrNull()
    //     0x1068c30: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0x1068c34: stur            x0, [fp, #-0x50]
    // 0x1068c38: r16 = <BorderSide>
    //     0x1068c38: add             x16, PP, #0x80, lsl #12  ; [pp+0x80c98] TypeArguments: <BorderSide>
    //     0x1068c3c: ldr             x16, [x16, #0xc98]
    // 0x1068c40: ldur            lr, [fp, #-0x10]
    // 0x1068c44: stp             lr, x16, [SP]
    // 0x1068c48: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1068c48: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1068c4c: r0 = allOrNull()
    //     0x1068c4c: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0x1068c50: stur            x0, [fp, #-0x10]
    // 0x1068c54: r16 = <OutlinedBorder>
    //     0x1068c54: add             x16, PP, #0x15, lsl #12  ; [pp+0x15aa8] TypeArguments: <OutlinedBorder>
    //     0x1068c58: ldr             x16, [x16, #0xaa8]
    // 0x1068c5c: ldur            lr, [fp, #-8]
    // 0x1068c60: stp             lr, x16, [SP]
    // 0x1068c64: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1068c64: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1068c68: r0 = allOrNull()
    //     0x1068c68: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0x1068c6c: r1 = Null
    //     0x1068c6c: mov             x1, NULL
    // 0x1068c70: r2 = 8
    //     0x1068c70: mov             x2, #8
    // 0x1068c74: stur            x0, [fp, #-8]
    // 0x1068c78: r0 = AllocateArray()
    //     0x1068c78: bl              #0x13df928  ; AllocateArrayStub
    // 0x1068c7c: r16 = Instance_WidgetState
    //     0x1068c7c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0x1068c80: ldr             x16, [x16, #0xa70]
    // 0x1068c84: StoreField: r0->field_f = r16
    //     0x1068c84: stur            w16, [x0, #0xf]
    // 0x1068c88: ldur            x1, [fp, #-0x78]
    // 0x1068c8c: StoreField: r0->field_13 = r1
    //     0x1068c8c: stur            w1, [x0, #0x13]
    // 0x1068c90: r16 = Instance__AnyWidgetStates
    //     0x1068c90: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a78] Obj!_AnyWidgetStates@12aa401
    //     0x1068c94: ldr             x16, [x16, #0xa78]
    // 0x1068c98: ArrayStore: r0[0] = r16  ; List_4
    //     0x1068c98: stur            w16, [x0, #0x17]
    // 0x1068c9c: ldur            x1, [fp, #-0x60]
    // 0x1068ca0: StoreField: r0->field_1b = r1
    //     0x1068ca0: stur            w1, [x0, #0x1b]
    // 0x1068ca4: r16 = <WidgetStatesConstraint, MouseCursor?>
    //     0x1068ca4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ab0] TypeArguments: <WidgetStatesConstraint, MouseCursor?>
    //     0x1068ca8: ldr             x16, [x16, #0xab0]
    // 0x1068cac: stp             x0, x16, [SP]
    // 0x1068cb0: r0 = Map._fromLiteral()
    //     0x1068cb0: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x1068cb4: r1 = <MouseCursor?>
    //     0x1068cb4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ab8] TypeArguments: <MouseCursor?>
    //     0x1068cb8: ldr             x1, [x1, #0xab8]
    // 0x1068cbc: stur            x0, [fp, #-0x60]
    // 0x1068cc0: r0 = WidgetStateMapper()
    //     0x1068cc0: bl              #0xd171e0  ; AllocateWidgetStateMapperStub -> WidgetStateMapper<X0> (size=0x10)
    // 0x1068cc4: mov             x1, x0
    // 0x1068cc8: ldur            x0, [fp, #-0x60]
    // 0x1068ccc: stur            x1, [fp, #-0x78]
    // 0x1068cd0: StoreField: r1->field_b = r0
    //     0x1068cd0: stur            w0, [x1, #0xb]
    // 0x1068cd4: r0 = ButtonStyle()
    //     0x1068cd4: bl              #0xd17184  ; AllocateButtonStyleStub -> ButtonStyle (size=0x6c)
    // 0x1068cd8: ldur            x1, [fp, #-0x38]
    // 0x1068cdc: StoreField: r0->field_7 = r1
    //     0x1068cdc: stur            w1, [x0, #7]
    // 0x1068ce0: ldur            x1, [fp, #-0x88]
    // 0x1068ce4: StoreField: r0->field_b = r1
    //     0x1068ce4: stur            w1, [x0, #0xb]
    // 0x1068ce8: ldur            x1, [fp, #-0x58]
    // 0x1068cec: StoreField: r0->field_f = r1
    //     0x1068cec: stur            w1, [x0, #0xf]
    // 0x1068cf0: ldur            x1, [fp, #-0xa0]
    // 0x1068cf4: StoreField: r0->field_13 = r1
    //     0x1068cf4: stur            w1, [x0, #0x13]
    // 0x1068cf8: ldur            x1, [fp, #-0x18]
    // 0x1068cfc: ArrayStore: r0[0] = r1  ; List_4
    //     0x1068cfc: stur            w1, [x0, #0x17]
    // 0x1068d00: ldur            x1, [fp, #-0x70]
    // 0x1068d04: StoreField: r0->field_1f = r1
    //     0x1068d04: stur            w1, [x0, #0x1f]
    // 0x1068d08: ldur            x1, [fp, #-0x40]
    // 0x1068d0c: StoreField: r0->field_23 = r1
    //     0x1068d0c: stur            w1, [x0, #0x23]
    // 0x1068d10: ldur            x1, [fp, #-0x48]
    // 0x1068d14: StoreField: r0->field_27 = r1
    //     0x1068d14: stur            w1, [x0, #0x27]
    // 0x1068d18: ldur            x1, [fp, #-0x50]
    // 0x1068d1c: StoreField: r0->field_2f = r1
    //     0x1068d1c: stur            w1, [x0, #0x2f]
    // 0x1068d20: ldur            x1, [fp, #-0x10]
    // 0x1068d24: StoreField: r0->field_3f = r1
    //     0x1068d24: stur            w1, [x0, #0x3f]
    // 0x1068d28: ldur            x1, [fp, #-8]
    // 0x1068d2c: StoreField: r0->field_43 = r1
    //     0x1068d2c: stur            w1, [x0, #0x43]
    // 0x1068d30: ldur            x1, [fp, #-0x78]
    // 0x1068d34: StoreField: r0->field_47 = r1
    //     0x1068d34: stur            w1, [x0, #0x47]
    // 0x1068d38: ldur            x1, [fp, #-0x30]
    // 0x1068d3c: StoreField: r0->field_4b = r1
    //     0x1068d3c: stur            w1, [x0, #0x4b]
    // 0x1068d40: ldur            x1, [fp, #-0x28]
    // 0x1068d44: StoreField: r0->field_4f = r1
    //     0x1068d44: stur            w1, [x0, #0x4f]
    // 0x1068d48: ldur            x1, [fp, #-0x90]
    // 0x1068d4c: StoreField: r0->field_53 = r1
    //     0x1068d4c: stur            w1, [x0, #0x53]
    // 0x1068d50: ldur            x1, [fp, #-0x68]
    // 0x1068d54: StoreField: r0->field_57 = r1
    //     0x1068d54: stur            w1, [x0, #0x57]
    // 0x1068d58: ldur            x1, [fp, #-0x98]
    // 0x1068d5c: StoreField: r0->field_5b = r1
    //     0x1068d5c: stur            w1, [x0, #0x5b]
    // 0x1068d60: ldur            x1, [fp, #-0x20]
    // 0x1068d64: StoreField: r0->field_5f = r1
    //     0x1068d64: stur            w1, [x0, #0x5f]
    // 0x1068d68: LeaveFrame
    //     0x1068d68: mov             SP, fp
    //     0x1068d6c: ldp             fp, lr, [SP], #0x10
    // 0x1068d70: ret
    //     0x1068d70: ret             
    // 0x1068d74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1068d74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1068d78: b               #0x1068884
  }
  _ defaultStyleOf(/* No info */) {
    // ** addr: 0x122a2ec, size: 0x360
    // 0x122a2ec: EnterFrame
    //     0x122a2ec: stp             fp, lr, [SP, #-0x10]!
    //     0x122a2f0: mov             fp, SP
    // 0x122a2f4: AllocStack(0xe8)
    //     0x122a2f4: sub             SP, SP, #0xe8
    // 0x122a2f8: SetupParameters(OutlinedButton this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x122a2f8: mov             x0, x2
    //     0x122a2fc: stur            x2, [fp, #-0x10]
    //     0x122a300: mov             x2, x1
    //     0x122a304: stur            x1, [fp, #-8]
    // 0x122a308: CheckStackOverflow
    //     0x122a308: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x122a30c: cmp             SP, x16
    //     0x122a310: b.ls            #0x122a644
    // 0x122a314: mov             x1, x0
    // 0x122a318: r0 = of()
    //     0x122a318: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x122a31c: mov             x2, x0
    // 0x122a320: stur            x2, [fp, #-0x30]
    // 0x122a324: LoadField: r0 = r2->field_3f
    //     0x122a324: ldur            w0, [x2, #0x3f]
    // 0x122a328: DecompressPointer r0
    //     0x122a328: add             x0, x0, HEAP, lsl #32
    // 0x122a32c: LoadField: r1 = r2->field_2f
    //     0x122a32c: ldur            w1, [x2, #0x2f]
    // 0x122a330: DecompressPointer r1
    //     0x122a330: add             x1, x1, HEAP, lsl #32
    // 0x122a334: stur            x1, [fp, #-0x18]
    // 0x122a338: tbnz            w1, #4, #0x122a380
    // 0x122a33c: ldur            x0, [fp, #-0x10]
    // 0x122a340: r0 = _OutlinedButtonDefaultsM3()
    //     0x122a340: bl              #0x122a64c  ; Allocate_OutlinedButtonDefaultsM3Stub -> _OutlinedButtonDefaultsM3 (size=0x74)
    // 0x122a344: mov             x1, x0
    // 0x122a348: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x122a34c: StoreField: r1->field_6f = r0
    //     0x122a34c: stur            w0, [x1, #0x6f]
    // 0x122a350: ldur            x3, [fp, #-0x10]
    // 0x122a354: StoreField: r1->field_6b = r3
    //     0x122a354: stur            w3, [x1, #0x6b]
    // 0x122a358: r0 = Instance_Duration
    //     0x122a358: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0x122a35c: ldr             x0, [x0, #0x318]
    // 0x122a360: StoreField: r1->field_53 = r0
    //     0x122a360: stur            w0, [x1, #0x53]
    // 0x122a364: r0 = true
    //     0x122a364: add             x0, NULL, #0x20  ; true
    // 0x122a368: StoreField: r1->field_57 = r0
    //     0x122a368: stur            w0, [x1, #0x57]
    // 0x122a36c: r0 = Instance_Alignment
    //     0x122a36c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0x122a370: ldr             x0, [x0, #0xb80]
    // 0x122a374: StoreField: r1->field_5b = r0
    //     0x122a374: stur            w0, [x1, #0x5b]
    // 0x122a378: mov             x2, x1
    // 0x122a37c: b               #0x122a4f8
    // 0x122a380: ldur            x3, [fp, #-0x10]
    // 0x122a384: LoadField: r4 = r0->field_b
    //     0x122a384: ldur            w4, [x0, #0xb]
    // 0x122a388: DecompressPointer r4
    //     0x122a388: add             x4, x4, HEAP, lsl #32
    // 0x122a38c: stur            x4, [fp, #-0x28]
    // 0x122a390: LoadField: r5 = r0->field_7f
    //     0x122a390: ldur            w5, [x0, #0x7f]
    // 0x122a394: DecompressPointer r5
    //     0x122a394: add             x5, x5, HEAP, lsl #32
    // 0x122a398: stur            x5, [fp, #-0x20]
    // 0x122a39c: r0 = LoadClassIdInstr(r5)
    //     0x122a39c: ldur            x0, [x5, #-1]
    //     0x122a3a0: ubfx            x0, x0, #0xc, #0x14
    // 0x122a3a4: mov             x1, x5
    // 0x122a3a8: d0 = 0.380000
    //     0x122a3a8: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x122a3ac: ldr             d0, [x17, #0x1f0]
    // 0x122a3b0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x122a3b0: sub             lr, x0, #1, lsl #12
    //     0x122a3b4: ldr             lr, [x21, lr, lsl #3]
    //     0x122a3b8: blr             lr
    // 0x122a3bc: mov             x2, x0
    // 0x122a3c0: ldur            x0, [fp, #-0x30]
    // 0x122a3c4: stur            x2, [fp, #-0x48]
    // 0x122a3c8: LoadField: r3 = r0->field_6f
    //     0x122a3c8: ldur            w3, [x0, #0x6f]
    // 0x122a3cc: DecompressPointer r3
    //     0x122a3cc: add             x3, x3, HEAP, lsl #32
    // 0x122a3d0: stur            x3, [fp, #-0x40]
    // 0x122a3d4: LoadField: r1 = r0->field_87
    //     0x122a3d4: ldur            w1, [x0, #0x87]
    // 0x122a3d8: DecompressPointer r1
    //     0x122a3d8: add             x1, x1, HEAP, lsl #32
    // 0x122a3dc: LoadField: r4 = r1->field_37
    //     0x122a3dc: ldur            w4, [x1, #0x37]
    // 0x122a3e0: DecompressPointer r4
    //     0x122a3e0: add             x4, x4, HEAP, lsl #32
    // 0x122a3e4: ldur            x1, [fp, #-0x10]
    // 0x122a3e8: stur            x4, [fp, #-0x38]
    // 0x122a3ec: r0 = _scaledPadding()
    //     0x122a3ec: bl              #0x1140b90  ; [package:flutter/src/material/elevated_button.dart] ::_scaledPadding
    // 0x122a3f0: mov             x2, x0
    // 0x122a3f4: ldur            x1, [fp, #-0x20]
    // 0x122a3f8: stur            x2, [fp, #-0x50]
    // 0x122a3fc: r0 = LoadClassIdInstr(r1)
    //     0x122a3fc: ldur            x0, [x1, #-1]
    //     0x122a400: ubfx            x0, x0, #0xc, #0x14
    // 0x122a404: d0 = 0.120000
    //     0x122a404: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x122a408: ldr             d0, [x17, #0xc40]
    // 0x122a40c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x122a40c: sub             lr, x0, #1, lsl #12
    //     0x122a410: ldr             lr, [x21, lr, lsl #3]
    //     0x122a414: blr             lr
    // 0x122a418: stur            x0, [fp, #-0x20]
    // 0x122a41c: r0 = BorderSide()
    //     0x122a41c: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x122a420: mov             x1, x0
    // 0x122a424: ldur            x0, [fp, #-0x20]
    // 0x122a428: StoreField: r1->field_7 = r0
    //     0x122a428: stur            w0, [x1, #7]
    // 0x122a42c: d0 = 1.000000
    //     0x122a42c: fmov            d0, #1.00000000
    // 0x122a430: StoreField: r1->field_b = d0
    //     0x122a430: stur            d0, [x1, #0xb]
    // 0x122a434: r0 = Instance_BorderStyle
    //     0x122a434: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x122a438: ldr             x0, [x0, #0xdc8]
    // 0x122a43c: StoreField: r1->field_13 = r0
    //     0x122a43c: stur            w0, [x1, #0x13]
    // 0x122a440: d0 = -1.000000
    //     0x122a440: fmov            d0, #-1.00000000
    // 0x122a444: ArrayStore: r1[0] = d0  ; List_8
    //     0x122a444: stur            d0, [x1, #0x17]
    // 0x122a448: ldur            x0, [fp, #-0x30]
    // 0x122a44c: LoadField: r2 = r0->field_33
    //     0x122a44c: ldur            w2, [x0, #0x33]
    // 0x122a450: DecompressPointer r2
    //     0x122a450: add             x2, x2, HEAP, lsl #32
    // 0x122a454: LoadField: r3 = r0->field_1b
    //     0x122a454: ldur            w3, [x0, #0x1b]
    // 0x122a458: DecompressPointer r3
    //     0x122a458: add             x3, x3, HEAP, lsl #32
    // 0x122a45c: ldur            x16, [fp, #-0x28]
    // 0x122a460: ldur            lr, [fp, #-0x48]
    // 0x122a464: stp             lr, x16, [SP, #0x80]
    // 0x122a468: r16 = Instance_Color
    //     0x122a468: add             x16, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x122a46c: ldr             x16, [x16, #0x810]
    // 0x122a470: r30 = Instance_Color
    //     0x122a470: add             lr, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x122a474: ldr             lr, [lr, #0x810]
    // 0x122a478: stp             lr, x16, [SP, #0x70]
    // 0x122a47c: ldur            x16, [fp, #-0x40]
    // 0x122a480: r30 = 0.000000
    //     0x122a480: ldr             lr, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x122a484: stp             lr, x16, [SP, #0x60]
    // 0x122a488: ldur            x16, [fp, #-0x38]
    // 0x122a48c: ldur            lr, [fp, #-0x50]
    // 0x122a490: stp             lr, x16, [SP, #0x50]
    // 0x122a494: r16 = Instance_Size
    //     0x122a494: add             x16, PP, #0x95, lsl #12  ; [pp+0x95c20] Obj!Size@12a79f1
    //     0x122a498: ldr             x16, [x16, #0xc20]
    // 0x122a49c: r30 = Instance_Size
    //     0x122a49c: add             lr, PP, #0x95, lsl #12  ; [pp+0x95c28] Obj!Size@12a79b1
    //     0x122a4a0: ldr             lr, [lr, #0xc28]
    // 0x122a4a4: stp             lr, x16, [SP, #0x40]
    // 0x122a4a8: r16 = Instance_SystemMouseCursor
    //     0x122a4a8: ldr             x16, [PP, #0x21b0]  ; [pp+0x21b0] Obj!SystemMouseCursor@12b3201
    // 0x122a4ac: r30 = Instance_SystemMouseCursor
    //     0x122a4ac: ldr             lr, [PP, #0x21b0]  ; [pp+0x21b0] Obj!SystemMouseCursor@12b3201
    // 0x122a4b0: stp             lr, x16, [SP, #0x30]
    // 0x122a4b4: stp             x3, x2, [SP, #0x20]
    // 0x122a4b8: r16 = Instance_Duration
    //     0x122a4b8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0x122a4bc: ldr             x16, [x16, #0x318]
    // 0x122a4c0: r30 = true
    //     0x122a4c0: add             lr, NULL, #0x20  ; true
    // 0x122a4c4: stp             lr, x16, [SP, #0x10]
    // 0x122a4c8: r16 = Instance_Alignment
    //     0x122a4c8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0x122a4cc: ldr             x16, [x16, #0xb80]
    // 0x122a4d0: r30 = Instance__InkRippleFactory
    //     0x122a4d0: add             lr, PP, #0x95, lsl #12  ; [pp+0x95c30] Obj!_InkRippleFactory@129ecd1
    //     0x122a4d4: ldr             lr, [lr, #0xc30]
    // 0x122a4d8: stp             lr, x16, [SP]
    // 0x122a4dc: mov             x2, x1
    // 0x122a4e0: r1 = Instance_RoundedRectangleBorder
    //     0x122a4e0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0x122a4e4: ldr             x1, [x1, #0x218]
    // 0x122a4e8: r4 = const [0, 0x14, 0x12, 0x2, alignment, 0x12, animationDuration, 0x10, backgroundColor, 0x4, disabledBackgroundColor, 0x5, disabledForegroundColor, 0x3, disabledMouseCursor, 0xd, elevation, 0x7, enableFeedback, 0x11, enabledMouseCursor, 0xc, foregroundColor, 0x2, maximumSize, 0xb, minimumSize, 0xa, padding, 0x9, shadowColor, 0x6, splashFactory, 0x13, tapTargetSize, 0xf, textStyle, 0x8, visualDensity, 0xe, null]
    //     0x122a4e8: add             x4, PP, #0x95, lsl #12  ; [pp+0x95c38] List(41) [0, 0x14, 0x12, 0x2, "alignment", 0x12, "animationDuration", 0x10, "backgroundColor", 0x4, "disabledBackgroundColor", 0x5, "disabledForegroundColor", 0x3, "disabledMouseCursor", 0xd, "elevation", 0x7, "enableFeedback", 0x11, "enabledMouseCursor", 0xc, "foregroundColor", 0x2, "maximumSize", 0xb, "minimumSize", 0xa, "padding", 0x9, "shadowColor", 0x6, "splashFactory", 0x13, "tapTargetSize", 0xf, "textStyle", 0x8, "visualDensity", 0xe, Null]
    //     0x122a4ec: ldr             x4, [x4, #0xc38]
    // 0x122a4f0: r0 = styleFrom()
    //     0x122a4f0: bl              #0x10681e0  ; [package:flutter/src/material/outlined_button.dart] OutlinedButton::styleFrom
    // 0x122a4f4: mov             x2, x0
    // 0x122a4f8: ldur            x0, [fp, #-8]
    // 0x122a4fc: stur            x2, [fp, #-0x20]
    // 0x122a500: LoadField: r1 = r0->field_3b
    //     0x122a500: ldur            w1, [x0, #0x3b]
    // 0x122a504: DecompressPointer r1
    //     0x122a504: add             x1, x1, HEAP, lsl #32
    // 0x122a508: tbnz            w1, #4, #0x122a634
    // 0x122a50c: ldur            x0, [fp, #-0x18]
    // 0x122a510: tbnz            w0, #4, #0x122a634
    // 0x122a514: r0 = LoadClassIdInstr(r2)
    //     0x122a514: ldur            x0, [x2, #-1]
    //     0x122a518: ubfx            x0, x0, #0xc, #0x14
    // 0x122a51c: mov             x1, x2
    // 0x122a520: r0 = GDT[cid_x0 + 0xe00]()
    //     0x122a520: add             lr, x0, #0xe00
    //     0x122a524: ldr             lr, [x21, lr, lsl #3]
    //     0x122a528: blr             lr
    // 0x122a52c: cmp             w0, NULL
    // 0x122a530: b.ne            #0x122a53c
    // 0x122a534: r0 = Null
    //     0x122a534: mov             x0, NULL
    // 0x122a538: b               #0x122a588
    // 0x122a53c: r1 = LoadClassIdInstr(r0)
    //     0x122a53c: ldur            x1, [x0, #-1]
    //     0x122a540: ubfx            x1, x1, #0xc, #0x14
    // 0x122a544: mov             x16, x0
    // 0x122a548: mov             x0, x1
    // 0x122a54c: mov             x1, x16
    // 0x122a550: r2 = _ConstSet len:0
    //     0x122a550: add             x2, PP, #0x26, lsl #12  ; [pp+0x26248] Set<WidgetState>(0)
    //     0x122a554: ldr             x2, [x2, #0x248]
    // 0x122a558: r0 = GDT[cid_x0 + 0x17c77]()
    //     0x122a558: mov             x17, #0x7c77
    //     0x122a55c: movk            x17, #1, lsl #16
    //     0x122a560: add             lr, x0, x17
    //     0x122a564: ldr             lr, [x21, lr, lsl #3]
    //     0x122a568: blr             lr
    // 0x122a56c: cmp             w0, NULL
    // 0x122a570: b.ne            #0x122a57c
    // 0x122a574: r0 = Null
    //     0x122a574: mov             x0, NULL
    // 0x122a578: b               #0x122a588
    // 0x122a57c: LoadField: r1 = r0->field_1f
    //     0x122a57c: ldur            w1, [x0, #0x1f]
    // 0x122a580: DecompressPointer r1
    //     0x122a580: add             x1, x1, HEAP, lsl #32
    // 0x122a584: mov             x0, x1
    // 0x122a588: cmp             w0, NULL
    // 0x122a58c: b.ne            #0x122a598
    // 0x122a590: d0 = 14.000000
    //     0x122a590: fmov            d0, #14.00000000
    // 0x122a594: b               #0x122a59c
    // 0x122a598: LoadField: d0 = r0->field_7
    //     0x122a598: ldur            d0, [x0, #7]
    // 0x122a59c: ldur            x1, [fp, #-0x10]
    // 0x122a5a0: stur            d0, [fp, #-0x58]
    // 0x122a5a4: r0 = textScalerOf()
    //     0x122a5a4: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0x122a5a8: r1 = LoadClassIdInstr(r0)
    //     0x122a5a8: ldur            x1, [x0, #-1]
    //     0x122a5ac: ubfx            x1, x1, #0xc, #0x14
    // 0x122a5b0: mov             x16, x0
    // 0x122a5b4: mov             x0, x1
    // 0x122a5b8: mov             x1, x16
    // 0x122a5bc: ldur            d0, [fp, #-0x58]
    // 0x122a5c0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x122a5c0: sub             lr, x0, #1, lsl #12
    //     0x122a5c4: ldr             lr, [x21, lr, lsl #3]
    //     0x122a5c8: blr             lr
    // 0x122a5cc: LoadField: d0 = r0->field_7
    //     0x122a5cc: ldur            d0, [x0, #7]
    // 0x122a5d0: d1 = 14.000000
    //     0x122a5d0: fmov            d1, #14.00000000
    // 0x122a5d4: fdiv            d2, d0, d1
    // 0x122a5d8: mov             v0.16b, v2.16b
    // 0x122a5dc: r1 = Instance_EdgeInsetsDirectional
    //     0x122a5dc: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a00] Obj!EdgeInsetsDirectional@129c841
    //     0x122a5e0: ldr             x1, [x1, #0xa00]
    // 0x122a5e4: r2 = Instance_EdgeInsetsDirectional
    //     0x122a5e4: add             x2, PP, #0x95, lsl #12  ; [pp+0x95c40] Obj!EdgeInsetsDirectional@129cb71
    //     0x122a5e8: ldr             x2, [x2, #0xc40]
    // 0x122a5ec: r3 = Instance_EdgeInsetsDirectional
    //     0x122a5ec: add             x3, PP, #0x95, lsl #12  ; [pp+0x95c48] Obj!EdgeInsetsDirectional@129cb41
    //     0x122a5f0: ldr             x3, [x3, #0xc48]
    // 0x122a5f4: r0 = scaledPadding()
    //     0x122a5f4: bl              #0x1140cd0  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::scaledPadding
    // 0x122a5f8: r1 = <EdgeInsetsGeometry>
    //     0x122a5f8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a98] TypeArguments: <EdgeInsetsGeometry>
    //     0x122a5fc: ldr             x1, [x1, #0xa98]
    // 0x122a600: stur            x0, [fp, #-8]
    // 0x122a604: r0 = WidgetStatePropertyAll()
    //     0x122a604: bl              #0xd132c8  ; AllocateWidgetStatePropertyAllStub -> WidgetStatePropertyAll<X0> (size=0x10)
    // 0x122a608: mov             x1, x0
    // 0x122a60c: ldur            x0, [fp, #-8]
    // 0x122a610: StoreField: r1->field_b = r0
    //     0x122a610: stur            w0, [x1, #0xb]
    // 0x122a614: str             x1, [SP]
    // 0x122a618: ldur            x1, [fp, #-0x20]
    // 0x122a61c: r4 = const [0, 0x2, 0x1, 0x1, padding, 0x1, null]
    //     0x122a61c: add             x4, PP, #0x19, lsl #12  ; [pp+0x19df0] List(7) [0, 0x2, 0x1, 0x1, "padding", 0x1, Null]
    //     0x122a620: ldr             x4, [x4, #0xdf0]
    // 0x122a624: r0 = copyWith()
    //     0x122a624: bl              #0xd2991c  ; [package:flutter/src/material/button_style.dart] ButtonStyle::copyWith
    // 0x122a628: LeaveFrame
    //     0x122a628: mov             SP, fp
    //     0x122a62c: ldp             fp, lr, [SP], #0x10
    // 0x122a630: ret
    //     0x122a630: ret             
    // 0x122a634: ldur            x0, [fp, #-0x20]
    // 0x122a638: LeaveFrame
    //     0x122a638: mov             SP, fp
    //     0x122a63c: ldp             fp, lr, [SP], #0x10
    // 0x122a640: ret
    //     0x122a640: ret             
    // 0x122a644: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x122a644: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x122a648: b               #0x122a314
  }
  _ themeStyleOf(/* No info */) {
    // ** addr: 0x122ab1c, size: 0x40
    // 0x122ab1c: EnterFrame
    //     0x122ab1c: stp             fp, lr, [SP, #-0x10]!
    //     0x122ab20: mov             fp, SP
    // 0x122ab24: mov             x0, x1
    // 0x122ab28: mov             x1, x2
    // 0x122ab2c: CheckStackOverflow
    //     0x122ab2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x122ab30: cmp             SP, x16
    //     0x122ab34: b.ls            #0x122ab54
    // 0x122ab38: r0 = of()
    //     0x122ab38: bl              #0xfbd24c  ; [package:flutter/src/material/outlined_button_theme.dart] OutlinedButtonTheme::of
    // 0x122ab3c: LoadField: r1 = r0->field_7
    //     0x122ab3c: ldur            w1, [x0, #7]
    // 0x122ab40: DecompressPointer r1
    //     0x122ab40: add             x1, x1, HEAP, lsl #32
    // 0x122ab44: mov             x0, x1
    // 0x122ab48: LeaveFrame
    //     0x122ab48: mov             SP, fp
    //     0x122ab4c: ldp             fp, lr, [SP], #0x10
    // 0x122ab50: ret
    //     0x122ab50: ret             
    // 0x122ab54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x122ab54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x122ab58: b               #0x122ab38
  }
}
