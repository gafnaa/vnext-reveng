// lib: , url: package:flutter/src/material/radio_theme.dart

// class id: 1048935, size: 0x8
class :: {
}

// class id: 5119, size: 0x2c, field offset: 0x8
//   const constructor, 
class RadioThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x1135660, size: 0x39c
    // 0x1135660: EnterFrame
    //     0x1135660: stp             fp, lr, [SP, #-0x10]!
    //     0x1135664: mov             fp, SP
    // 0x1135668: AllocStack(0x68)
    //     0x1135668: sub             SP, SP, #0x68
    // 0x113566c: CheckStackOverflow
    //     0x113566c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1135670: cmp             SP, x16
    //     0x1135674: b.ls            #0x11359f4
    // 0x1135678: ldr             x1, [fp, #0x10]
    // 0x113567c: r0 = LoadClassIdInstr(r1)
    //     0x113567c: ldur            x0, [x1, #-1]
    //     0x1135680: ubfx            x0, x0, #0xc, #0x14
    // 0x1135684: stur            x0, [fp, #-8]
    // 0x1135688: r17 = 5119
    //     0x1135688: mov             x17, #0x13ff
    // 0x113568c: cmp             x0, x17
    // 0x1135690: b.ne            #0x11356a0
    // 0x1135694: LoadField: r2 = r1->field_b
    //     0x1135694: ldur            w2, [x1, #0xb]
    // 0x1135698: DecompressPointer r2
    //     0x1135698: add             x2, x2, HEAP, lsl #32
    // 0x113569c: b               #0x1135730
    // 0x11356a0: r17 = 5120
    //     0x11356a0: mov             x17, #0x1400
    // 0x11356a4: cmp             x0, x17
    // 0x11356a8: b.ne            #0x11356f0
    // 0x11356ac: r1 = 1
    //     0x11356ac: mov             x1, #1
    // 0x11356b0: r0 = AllocateContext()
    //     0x11356b0: bl              #0x13de838  ; AllocateContextStub
    // 0x11356b4: mov             x1, x0
    // 0x11356b8: ldr             x0, [fp, #0x10]
    // 0x11356bc: StoreField: r1->field_f = r0
    //     0x11356bc: stur            w0, [x1, #0xf]
    // 0x11356c0: mov             x2, x1
    // 0x11356c4: r1 = Function '<anonymous closure>':.
    //     0x11356c4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26288] AnonymousClosure: (0xdfb620), of [package:flutter/src/material/radio.dart] _RadioDefaultsM3
    //     0x11356c8: ldr             x1, [x1, #0x288]
    // 0x11356cc: r0 = AllocateClosure()
    //     0x11356cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11356d0: r16 = <Color>
    //     0x11356d0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x11356d4: ldr             x16, [x16, #0xa90]
    // 0x11356d8: stp             x0, x16, [SP]
    // 0x11356dc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x11356dc: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x11356e0: r0 = resolveWith()
    //     0x11356e0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x11356e4: mov             x2, x0
    // 0x11356e8: ldur            x0, [fp, #-8]
    // 0x11356ec: b               #0x1135730
    // 0x11356f0: r1 = 1
    //     0x11356f0: mov             x1, #1
    // 0x11356f4: r0 = AllocateContext()
    //     0x11356f4: bl              #0x13de838  ; AllocateContextStub
    // 0x11356f8: mov             x1, x0
    // 0x11356fc: ldr             x0, [fp, #0x10]
    // 0x1135700: StoreField: r1->field_f = r0
    //     0x1135700: stur            w0, [x1, #0xf]
    // 0x1135704: mov             x2, x1
    // 0x1135708: r1 = Function '<anonymous closure>':.
    //     0x1135708: add             x1, PP, #0x26, lsl #12  ; [pp+0x26290] AnonymousClosure: (0xdfb46c), of [package:flutter/src/material/radio.dart] _RadioDefaultsM2
    //     0x113570c: ldr             x1, [x1, #0x290]
    // 0x1135710: r0 = AllocateClosure()
    //     0x1135710: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1135714: r16 = <Color>
    //     0x1135714: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1135718: ldr             x16, [x16, #0xa90]
    // 0x113571c: stp             x0, x16, [SP]
    // 0x1135720: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1135720: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1135724: r0 = resolveWith()
    //     0x1135724: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1135728: mov             x2, x0
    // 0x113572c: ldur            x0, [fp, #-8]
    // 0x1135730: stur            x2, [fp, #-0x10]
    // 0x1135734: r17 = 5119
    //     0x1135734: mov             x17, #0x13ff
    // 0x1135738: cmp             x0, x17
    // 0x113573c: b.ne            #0x1135758
    // 0x1135740: ldr             x1, [fp, #0x10]
    // 0x1135744: LoadField: r3 = r1->field_f
    //     0x1135744: ldur            w3, [x1, #0xf]
    // 0x1135748: DecompressPointer r3
    //     0x1135748: add             x3, x3, HEAP, lsl #32
    // 0x113574c: mov             x2, x0
    // 0x1135750: mov             x0, x1
    // 0x1135754: b               #0x11357f4
    // 0x1135758: ldr             x1, [fp, #0x10]
    // 0x113575c: r17 = 5120
    //     0x113575c: mov             x17, #0x1400
    // 0x1135760: cmp             x0, x17
    // 0x1135764: b.ne            #0x11357b0
    // 0x1135768: r1 = 1
    //     0x1135768: mov             x1, #1
    // 0x113576c: r0 = AllocateContext()
    //     0x113576c: bl              #0x13de838  ; AllocateContextStub
    // 0x1135770: mov             x1, x0
    // 0x1135774: ldr             x0, [fp, #0x10]
    // 0x1135778: StoreField: r1->field_f = r0
    //     0x1135778: stur            w0, [x1, #0xf]
    // 0x113577c: mov             x2, x1
    // 0x1135780: r1 = Function '<anonymous closure>':.
    //     0x1135780: add             x1, PP, #0x26, lsl #12  ; [pp+0x26298] AnonymousClosure: (0xdfb064), of [package:flutter/src/material/radio.dart] _RadioDefaultsM3
    //     0x1135784: ldr             x1, [x1, #0x298]
    // 0x1135788: r0 = AllocateClosure()
    //     0x1135788: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x113578c: r16 = <Color>
    //     0x113578c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1135790: ldr             x16, [x16, #0xa90]
    // 0x1135794: stp             x0, x16, [SP]
    // 0x1135798: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1135798: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x113579c: r0 = resolveWith()
    //     0x113579c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x11357a0: mov             x3, x0
    // 0x11357a4: ldr             x0, [fp, #0x10]
    // 0x11357a8: ldur            x2, [fp, #-8]
    // 0x11357ac: b               #0x11357f4
    // 0x11357b0: r1 = 1
    //     0x11357b0: mov             x1, #1
    // 0x11357b4: r0 = AllocateContext()
    //     0x11357b4: bl              #0x13de838  ; AllocateContextStub
    // 0x11357b8: mov             x1, x0
    // 0x11357bc: ldr             x0, [fp, #0x10]
    // 0x11357c0: StoreField: r1->field_f = r0
    //     0x11357c0: stur            w0, [x1, #0xf]
    // 0x11357c4: mov             x2, x1
    // 0x11357c8: r1 = Function '<anonymous closure>':.
    //     0x11357c8: add             x1, PP, #0x26, lsl #12  ; [pp+0x262a0] AnonymousClosure: (0xdfae80), of [package:flutter/src/material/radio.dart] _RadioDefaultsM2
    //     0x11357cc: ldr             x1, [x1, #0x2a0]
    // 0x11357d0: r0 = AllocateClosure()
    //     0x11357d0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11357d4: r16 = <Color>
    //     0x11357d4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x11357d8: ldr             x16, [x16, #0xa90]
    // 0x11357dc: stp             x0, x16, [SP]
    // 0x11357e0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x11357e0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x11357e4: r0 = resolveWith()
    //     0x11357e4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x11357e8: mov             x3, x0
    // 0x11357ec: ldr             x0, [fp, #0x10]
    // 0x11357f0: ldur            x2, [fp, #-8]
    // 0x11357f4: stur            x3, [fp, #-0x20]
    // 0x11357f8: LoadField: r4 = r0->field_13
    //     0x11357f8: ldur            w4, [x0, #0x13]
    // 0x11357fc: DecompressPointer r4
    //     0x11357fc: add             x4, x4, HEAP, lsl #32
    // 0x1135800: stur            x4, [fp, #-0x18]
    // 0x1135804: r17 = 5119
    //     0x1135804: mov             x17, #0x13ff
    // 0x1135808: cmp             x2, x17
    // 0x113580c: b.ne            #0x1135824
    // 0x1135810: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1135810: ldur            w1, [x0, #0x17]
    // 0x1135814: DecompressPointer r1
    //     0x1135814: add             x1, x1, HEAP, lsl #32
    // 0x1135818: mov             x0, x2
    // 0x113581c: mov             x2, x1
    // 0x1135820: b               #0x113589c
    // 0x1135824: r17 = 5120
    //     0x1135824: mov             x17, #0x1400
    // 0x1135828: cmp             x2, x17
    // 0x113582c: b.ne            #0x1135868
    // 0x1135830: mov             x1, x0
    // 0x1135834: LoadField: r0 = r1->field_2f
    //     0x1135834: ldur            w0, [x1, #0x2f]
    // 0x1135838: DecompressPointer r0
    //     0x1135838: add             x0, x0, HEAP, lsl #32
    // 0x113583c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1135840: cmp             w0, w16
    // 0x1135844: b.ne            #0x1135854
    // 0x1135848: r2 = _theme
    //     0x1135848: add             x2, PP, #0x26, lsl #12  ; [pp+0x262a8] Field <_RadioDefaultsM3@625266229._theme@625266229>: late final (offset: 0x30)
    //     0x113584c: ldr             x2, [x2, #0x2a8]
    // 0x1135850: r0 = InitLateFinalInstanceField()
    //     0x1135850: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1135854: LoadField: r1 = r0->field_1b
    //     0x1135854: ldur            w1, [x0, #0x1b]
    // 0x1135858: DecompressPointer r1
    //     0x1135858: add             x1, x1, HEAP, lsl #32
    // 0x113585c: mov             x2, x1
    // 0x1135860: ldur            x0, [fp, #-8]
    // 0x1135864: b               #0x113589c
    // 0x1135868: ldr             x1, [fp, #0x10]
    // 0x113586c: LoadField: r0 = r1->field_2f
    //     0x113586c: ldur            w0, [x1, #0x2f]
    // 0x1135870: DecompressPointer r0
    //     0x1135870: add             x0, x0, HEAP, lsl #32
    // 0x1135874: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1135878: cmp             w0, w16
    // 0x113587c: b.ne            #0x113588c
    // 0x1135880: r2 = _theme
    //     0x1135880: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b0] Field <_RadioDefaultsM2@625266229._theme@625266229>: late final (offset: 0x30)
    //     0x1135884: ldr             x2, [x2, #0x2b0]
    // 0x1135888: r0 = InitLateFinalInstanceField()
    //     0x1135888: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113588c: LoadField: r1 = r0->field_1b
    //     0x113588c: ldur            w1, [x0, #0x1b]
    // 0x1135890: DecompressPointer r1
    //     0x1135890: add             x1, x1, HEAP, lsl #32
    // 0x1135894: mov             x2, x1
    // 0x1135898: ldur            x0, [fp, #-8]
    // 0x113589c: stur            x2, [fp, #-0x28]
    // 0x11358a0: r17 = 5119
    //     0x11358a0: mov             x17, #0x13ff
    // 0x11358a4: cmp             x0, x17
    // 0x11358a8: b.ne            #0x11358bc
    // 0x11358ac: ldr             x3, [fp, #0x10]
    // 0x11358b0: LoadField: r1 = r3->field_1b
    //     0x11358b0: ldur            w1, [x3, #0x1b]
    // 0x11358b4: DecompressPointer r1
    //     0x11358b4: add             x1, x1, HEAP, lsl #32
    // 0x11358b8: b               #0x1135930
    // 0x11358bc: ldr             x3, [fp, #0x10]
    // 0x11358c0: r17 = 5120
    //     0x11358c0: mov             x17, #0x1400
    // 0x11358c4: cmp             x0, x17
    // 0x11358c8: b.ne            #0x1135900
    // 0x11358cc: mov             x1, x3
    // 0x11358d0: LoadField: r0 = r1->field_2f
    //     0x11358d0: ldur            w0, [x1, #0x2f]
    // 0x11358d4: DecompressPointer r0
    //     0x11358d4: add             x0, x0, HEAP, lsl #32
    // 0x11358d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11358dc: cmp             w0, w16
    // 0x11358e0: b.ne            #0x11358f0
    // 0x11358e4: r2 = _theme
    //     0x11358e4: add             x2, PP, #0x26, lsl #12  ; [pp+0x262a8] Field <_RadioDefaultsM3@625266229._theme@625266229>: late final (offset: 0x30)
    //     0x11358e8: ldr             x2, [x2, #0x2a8]
    // 0x11358ec: r0 = InitLateFinalInstanceField()
    //     0x11358ec: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11358f0: LoadField: r1 = r0->field_33
    //     0x11358f0: ldur            w1, [x0, #0x33]
    // 0x11358f4: DecompressPointer r1
    //     0x11358f4: add             x1, x1, HEAP, lsl #32
    // 0x11358f8: ldur            x0, [fp, #-8]
    // 0x11358fc: b               #0x1135930
    // 0x1135900: ldr             x1, [fp, #0x10]
    // 0x1135904: LoadField: r0 = r1->field_2f
    //     0x1135904: ldur            w0, [x1, #0x2f]
    // 0x1135908: DecompressPointer r0
    //     0x1135908: add             x0, x0, HEAP, lsl #32
    // 0x113590c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1135910: cmp             w0, w16
    // 0x1135914: b.ne            #0x1135924
    // 0x1135918: r2 = _theme
    //     0x1135918: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b0] Field <_RadioDefaultsM2@625266229._theme@625266229>: late final (offset: 0x30)
    //     0x113591c: ldr             x2, [x2, #0x2b0]
    // 0x1135920: r0 = InitLateFinalInstanceField()
    //     0x1135920: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1135924: LoadField: r1 = r0->field_33
    //     0x1135924: ldur            w1, [x0, #0x33]
    // 0x1135928: DecompressPointer r1
    //     0x1135928: add             x1, x1, HEAP, lsl #32
    // 0x113592c: ldur            x0, [fp, #-8]
    // 0x1135930: stur            x1, [fp, #-0x30]
    // 0x1135934: r17 = 5119
    //     0x1135934: mov             x17, #0x13ff
    // 0x1135938: cmp             x0, x17
    // 0x113593c: b.ne            #0x1135954
    // 0x1135940: ldr             x0, [fp, #0x10]
    // 0x1135944: LoadField: r2 = r0->field_1f
    //     0x1135944: ldur            w2, [x0, #0x1f]
    // 0x1135948: DecompressPointer r2
    //     0x1135948: add             x2, x2, HEAP, lsl #32
    // 0x113594c: mov             x0, x2
    // 0x1135950: b               #0x113599c
    // 0x1135954: r17 = 5120
    //     0x1135954: mov             x17, #0x1400
    // 0x1135958: cmp             x0, x17
    // 0x113595c: b.ne            #0x1135980
    // 0x1135960: r16 = <Color>
    //     0x1135960: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1135964: ldr             x16, [x16, #0xa90]
    // 0x1135968: r30 = Instance_Color
    //     0x1135968: add             lr, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x113596c: ldr             lr, [lr, #0x810]
    // 0x1135970: stp             lr, x16, [SP]
    // 0x1135974: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1135974: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1135978: r0 = all()
    //     0x1135978: bl              #0xd13288  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::all
    // 0x113597c: b               #0x113599c
    // 0x1135980: r16 = <Color>
    //     0x1135980: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1135984: ldr             x16, [x16, #0xa90]
    // 0x1135988: r30 = Instance_Color
    //     0x1135988: add             lr, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x113598c: ldr             lr, [lr, #0x810]
    // 0x1135990: stp             lr, x16, [SP]
    // 0x1135994: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1135994: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1135998: r0 = all()
    //     0x1135998: bl              #0xd13288  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::all
    // 0x113599c: ldur            x16, [fp, #-0x20]
    // 0x11359a0: ldur            lr, [fp, #-0x18]
    // 0x11359a4: stp             lr, x16, [SP, #0x28]
    // 0x11359a8: ldur            x16, [fp, #-0x28]
    // 0x11359ac: ldur            lr, [fp, #-0x30]
    // 0x11359b0: stp             lr, x16, [SP, #0x18]
    // 0x11359b4: stp             NULL, x0, [SP, #8]
    // 0x11359b8: str             NULL, [SP]
    // 0x11359bc: ldur            x2, [fp, #-0x10]
    // 0x11359c0: r1 = Null
    //     0x11359c0: mov             x1, NULL
    // 0x11359c4: r4 = const [0, 0x9, 0x7, 0x9, null]
    //     0x11359c4: add             x4, PP, #0xe, lsl #12  ; [pp+0xe278] List(5) [0, 0x9, 0x7, 0x9, Null]
    //     0x11359c8: ldr             x4, [x4, #0x278]
    // 0x11359cc: r0 = hash()
    //     0x11359cc: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x11359d0: mov             x2, x0
    // 0x11359d4: r0 = BoxInt64Instr(r2)
    //     0x11359d4: sbfiz           x0, x2, #1, #0x1f
    //     0x11359d8: cmp             x2, x0, asr #1
    //     0x11359dc: b.eq            #0x11359e8
    //     0x11359e0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11359e4: stur            x2, [x0, #7]
    // 0x11359e8: LeaveFrame
    //     0x11359e8: mov             SP, fp
    //     0x11359ec: ldp             fp, lr, [SP], #0x10
    // 0x11359f0: ret
    //     0x11359f0: ret             
    // 0x11359f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11359f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11359f8: b               #0x1135678
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1165fdc, size: 0xb4
    // 0x1165fdc: EnterFrame
    //     0x1165fdc: stp             fp, lr, [SP, #-0x10]!
    //     0x1165fe0: mov             fp, SP
    // 0x1165fe4: AllocStack(0x8)
    //     0x1165fe4: sub             SP, SP, #8
    // 0x1165fe8: SetupParameters(dynamic _ /* r1 => r0 */)
    //     0x1165fe8: mov             x0, x1
    // 0x1165fec: CheckStackOverflow
    //     0x1165fec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1165ff0: cmp             SP, x16
    //     0x1165ff4: b.ls            #0x116606c
    // 0x1165ff8: cmp             w0, w2
    // 0x1165ffc: b.ne            #0x116600c
    // 0x1166000: LeaveFrame
    //     0x1166000: mov             SP, fp
    //     0x1166004: ldp             fp, lr, [SP], #0x10
    // 0x1166008: ret
    //     0x1166008: ret             
    // 0x116600c: LoadField: r1 = r0->field_13
    //     0x116600c: ldur            w1, [x0, #0x13]
    // 0x1166010: DecompressPointer r1
    //     0x1166010: add             x1, x1, HEAP, lsl #32
    // 0x1166014: LoadField: r0 = r2->field_13
    //     0x1166014: ldur            w0, [x2, #0x13]
    // 0x1166018: DecompressPointer r0
    //     0x1166018: add             x0, x0, HEAP, lsl #32
    // 0x116601c: r3 = inline_Allocate_Double()
    //     0x116601c: ldp             x3, x2, [THR, #0x60]  ; THR::top
    //     0x1166020: add             x3, x3, #0x10
    //     0x1166024: cmp             x2, x3
    //     0x1166028: b.ls            #0x1166074
    //     0x116602c: str             x3, [THR, #0x60]  ; THR::top
    //     0x1166030: sub             x3, x3, #0xf
    //     0x1166034: mov             x2, #0xe19c
    //     0x1166038: movk            x2, #3, lsl #16
    //     0x116603c: stur            x2, [x3, #-1]
    // 0x1166040: dmb             ishst
    // 0x1166044: StoreField: r3->field_7 = d0
    //     0x1166044: stur            d0, [x3, #7]
    // 0x1166048: mov             x2, x0
    // 0x116604c: r0 = lerpDouble()
    //     0x116604c: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1166050: stur            x0, [fp, #-8]
    // 0x1166054: r0 = RadioThemeData()
    //     0x1166054: bl              #0x1166090  ; AllocateRadioThemeDataStub -> RadioThemeData (size=0x2c)
    // 0x1166058: ldur            x1, [fp, #-8]
    // 0x116605c: StoreField: r0->field_13 = r1
    //     0x116605c: stur            w1, [x0, #0x13]
    // 0x1166060: LeaveFrame
    //     0x1166060: mov             SP, fp
    //     0x1166064: ldp             fp, lr, [SP], #0x10
    // 0x1166068: ret
    //     0x1166068: ret             
    // 0x116606c: r0 = StackOverflowSharedWithFPURegs()
    //     0x116606c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1166070: b               #0x1165ff8
    // 0x1166074: SaveReg d0
    //     0x1166074: str             q0, [SP, #-0x10]!
    // 0x1166078: stp             x0, x1, [SP, #-0x10]!
    // 0x116607c: r0 = AllocateDouble()
    //     0x116607c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1166080: mov             x3, x0
    // 0x1166084: ldp             x0, x1, [SP], #0x10
    // 0x1166088: RestoreReg d0
    //     0x1166088: ldr             q0, [SP], #0x10
    // 0x116608c: b               #0x1166044
  }
  _ ==(/* No info */) {
    // ** addr: 0x1270fa8, size: 0x770
    // 0x1270fa8: EnterFrame
    //     0x1270fa8: stp             fp, lr, [SP, #-0x10]!
    //     0x1270fac: mov             fp, SP
    // 0x1270fb0: AllocStack(0x28)
    //     0x1270fb0: sub             SP, SP, #0x28
    // 0x1270fb4: CheckStackOverflow
    //     0x1270fb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1270fb8: cmp             SP, x16
    //     0x1270fbc: b.ls            #0x1271710
    // 0x1270fc0: ldr             x1, [fp, #0x10]
    // 0x1270fc4: cmp             w1, NULL
    // 0x1270fc8: b.ne            #0x1270fdc
    // 0x1270fcc: r0 = false
    //     0x1270fcc: add             x0, NULL, #0x30  ; false
    // 0x1270fd0: LeaveFrame
    //     0x1270fd0: mov             SP, fp
    //     0x1270fd4: ldp             fp, lr, [SP], #0x10
    // 0x1270fd8: ret
    //     0x1270fd8: ret             
    // 0x1270fdc: ldr             x0, [fp, #0x18]
    // 0x1270fe0: cmp             w0, w1
    // 0x1270fe4: b.ne            #0x1270ff8
    // 0x1270fe8: r0 = true
    //     0x1270fe8: add             x0, NULL, #0x20  ; true
    // 0x1270fec: LeaveFrame
    //     0x1270fec: mov             SP, fp
    //     0x1270ff0: ldp             fp, lr, [SP], #0x10
    // 0x1270ff4: ret
    //     0x1270ff4: ret             
    // 0x1270ff8: stp             x0, x1, [SP]
    // 0x1270ffc: r0 = _haveSameRuntimeType()
    //     0x1270ffc: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x1271000: tbz             w0, #4, #0x1271014
    // 0x1271004: r0 = false
    //     0x1271004: add             x0, NULL, #0x30  ; false
    // 0x1271008: LeaveFrame
    //     0x1271008: mov             SP, fp
    //     0x127100c: ldp             fp, lr, [SP], #0x10
    // 0x1271010: ret
    //     0x1271010: ret             
    // 0x1271014: ldr             x1, [fp, #0x10]
    // 0x1271018: r0 = 60
    //     0x1271018: mov             x0, #0x3c
    // 0x127101c: branchIfSmi(r1, 0x1271028)
    //     0x127101c: tbz             w1, #0, #0x1271028
    // 0x1271020: r0 = LoadClassIdInstr(r1)
    //     0x1271020: ldur            x0, [x1, #-1]
    //     0x1271024: ubfx            x0, x0, #0xc, #0x14
    // 0x1271028: stur            x0, [fp, #-8]
    // 0x127102c: r17 = -5119
    //     0x127102c: mov             x17, #-0x13ff
    // 0x1271030: add             x16, x0, x17
    // 0x1271034: cmp             x16, #2
    // 0x1271038: b.hi            #0x1271700
    // 0x127103c: r17 = 5119
    //     0x127103c: mov             x17, #0x13ff
    // 0x1271040: cmp             x0, x17
    // 0x1271044: b.ne            #0x1271058
    // 0x1271048: LoadField: r2 = r1->field_b
    //     0x1271048: ldur            w2, [x1, #0xb]
    // 0x127104c: DecompressPointer r2
    //     0x127104c: add             x2, x2, HEAP, lsl #32
    // 0x1271050: mov             x0, x2
    // 0x1271054: b               #0x12710d8
    // 0x1271058: r17 = 5120
    //     0x1271058: mov             x17, #0x1400
    // 0x127105c: cmp             x0, x17
    // 0x1271060: b.ne            #0x12710a0
    // 0x1271064: r1 = 1
    //     0x1271064: mov             x1, #1
    // 0x1271068: r0 = AllocateContext()
    //     0x1271068: bl              #0x13de838  ; AllocateContextStub
    // 0x127106c: mov             x1, x0
    // 0x1271070: ldr             x0, [fp, #0x10]
    // 0x1271074: StoreField: r1->field_f = r0
    //     0x1271074: stur            w0, [x1, #0xf]
    // 0x1271078: mov             x2, x1
    // 0x127107c: r1 = Function '<anonymous closure>':.
    //     0x127107c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26288] AnonymousClosure: (0xdfb620), of [package:flutter/src/material/radio.dart] _RadioDefaultsM3
    //     0x1271080: ldr             x1, [x1, #0x288]
    // 0x1271084: r0 = AllocateClosure()
    //     0x1271084: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1271088: r16 = <Color>
    //     0x1271088: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x127108c: ldr             x16, [x16, #0xa90]
    // 0x1271090: stp             x0, x16, [SP]
    // 0x1271094: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1271094: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1271098: r0 = resolveWith()
    //     0x1271098: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x127109c: b               #0x12710d8
    // 0x12710a0: r1 = 1
    //     0x12710a0: mov             x1, #1
    // 0x12710a4: r0 = AllocateContext()
    //     0x12710a4: bl              #0x13de838  ; AllocateContextStub
    // 0x12710a8: mov             x1, x0
    // 0x12710ac: ldr             x0, [fp, #0x10]
    // 0x12710b0: StoreField: r1->field_f = r0
    //     0x12710b0: stur            w0, [x1, #0xf]
    // 0x12710b4: mov             x2, x1
    // 0x12710b8: r1 = Function '<anonymous closure>':.
    //     0x12710b8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26290] AnonymousClosure: (0xdfb46c), of [package:flutter/src/material/radio.dart] _RadioDefaultsM2
    //     0x12710bc: ldr             x1, [x1, #0x290]
    // 0x12710c0: r0 = AllocateClosure()
    //     0x12710c0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12710c4: r16 = <Color>
    //     0x12710c4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x12710c8: ldr             x16, [x16, #0xa90]
    // 0x12710cc: stp             x0, x16, [SP]
    // 0x12710d0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12710d0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12710d4: r0 = resolveWith()
    //     0x12710d4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x12710d8: ldr             x1, [fp, #0x18]
    // 0x12710dc: stur            x0, [fp, #-0x18]
    // 0x12710e0: r2 = LoadClassIdInstr(r1)
    //     0x12710e0: ldur            x2, [x1, #-1]
    //     0x12710e4: ubfx            x2, x2, #0xc, #0x14
    // 0x12710e8: stur            x2, [fp, #-0x10]
    // 0x12710ec: r17 = 5119
    //     0x12710ec: mov             x17, #0x13ff
    // 0x12710f0: cmp             x2, x17
    // 0x12710f4: b.ne            #0x1271108
    // 0x12710f8: LoadField: r3 = r1->field_b
    //     0x12710f8: ldur            w3, [x1, #0xb]
    // 0x12710fc: DecompressPointer r3
    //     0x12710fc: add             x3, x3, HEAP, lsl #32
    // 0x1271100: mov             x1, x3
    // 0x1271104: b               #0x1271198
    // 0x1271108: r17 = 5120
    //     0x1271108: mov             x17, #0x1400
    // 0x127110c: cmp             x2, x17
    // 0x1271110: b.ne            #0x1271158
    // 0x1271114: r1 = 1
    //     0x1271114: mov             x1, #1
    // 0x1271118: r0 = AllocateContext()
    //     0x1271118: bl              #0x13de838  ; AllocateContextStub
    // 0x127111c: mov             x1, x0
    // 0x1271120: ldr             x0, [fp, #0x18]
    // 0x1271124: StoreField: r1->field_f = r0
    //     0x1271124: stur            w0, [x1, #0xf]
    // 0x1271128: mov             x2, x1
    // 0x127112c: r1 = Function '<anonymous closure>':.
    //     0x127112c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26288] AnonymousClosure: (0xdfb620), of [package:flutter/src/material/radio.dart] _RadioDefaultsM3
    //     0x1271130: ldr             x1, [x1, #0x288]
    // 0x1271134: r0 = AllocateClosure()
    //     0x1271134: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1271138: r16 = <Color>
    //     0x1271138: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x127113c: ldr             x16, [x16, #0xa90]
    // 0x1271140: stp             x0, x16, [SP]
    // 0x1271144: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1271144: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1271148: r0 = resolveWith()
    //     0x1271148: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x127114c: mov             x1, x0
    // 0x1271150: ldur            x0, [fp, #-0x18]
    // 0x1271154: b               #0x1271198
    // 0x1271158: r1 = 1
    //     0x1271158: mov             x1, #1
    // 0x127115c: r0 = AllocateContext()
    //     0x127115c: bl              #0x13de838  ; AllocateContextStub
    // 0x1271160: mov             x1, x0
    // 0x1271164: ldr             x0, [fp, #0x18]
    // 0x1271168: StoreField: r1->field_f = r0
    //     0x1271168: stur            w0, [x1, #0xf]
    // 0x127116c: mov             x2, x1
    // 0x1271170: r1 = Function '<anonymous closure>':.
    //     0x1271170: add             x1, PP, #0x26, lsl #12  ; [pp+0x26290] AnonymousClosure: (0xdfb46c), of [package:flutter/src/material/radio.dart] _RadioDefaultsM2
    //     0x1271174: ldr             x1, [x1, #0x290]
    // 0x1271178: r0 = AllocateClosure()
    //     0x1271178: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x127117c: r16 = <Color>
    //     0x127117c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1271180: ldr             x16, [x16, #0xa90]
    // 0x1271184: stp             x0, x16, [SP]
    // 0x1271188: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1271188: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x127118c: r0 = resolveWith()
    //     0x127118c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1271190: mov             x1, x0
    // 0x1271194: ldur            x0, [fp, #-0x18]
    // 0x1271198: cmp             w0, w1
    // 0x127119c: b.ne            #0x1271700
    // 0x12711a0: ldur            x0, [fp, #-8]
    // 0x12711a4: r17 = 5119
    //     0x12711a4: mov             x17, #0x13ff
    // 0x12711a8: cmp             x0, x17
    // 0x12711ac: b.ne            #0x12711c4
    // 0x12711b0: ldr             x1, [fp, #0x10]
    // 0x12711b4: LoadField: r2 = r1->field_f
    //     0x12711b4: ldur            w2, [x1, #0xf]
    // 0x12711b8: DecompressPointer r2
    //     0x12711b8: add             x2, x2, HEAP, lsl #32
    // 0x12711bc: mov             x1, x2
    // 0x12711c0: b               #0x1271250
    // 0x12711c4: ldr             x1, [fp, #0x10]
    // 0x12711c8: r17 = 5120
    //     0x12711c8: mov             x17, #0x1400
    // 0x12711cc: cmp             x0, x17
    // 0x12711d0: b.ne            #0x1271214
    // 0x12711d4: r1 = 1
    //     0x12711d4: mov             x1, #1
    // 0x12711d8: r0 = AllocateContext()
    //     0x12711d8: bl              #0x13de838  ; AllocateContextStub
    // 0x12711dc: mov             x1, x0
    // 0x12711e0: ldr             x0, [fp, #0x10]
    // 0x12711e4: StoreField: r1->field_f = r0
    //     0x12711e4: stur            w0, [x1, #0xf]
    // 0x12711e8: mov             x2, x1
    // 0x12711ec: r1 = Function '<anonymous closure>':.
    //     0x12711ec: add             x1, PP, #0x26, lsl #12  ; [pp+0x26298] AnonymousClosure: (0xdfb064), of [package:flutter/src/material/radio.dart] _RadioDefaultsM3
    //     0x12711f0: ldr             x1, [x1, #0x298]
    // 0x12711f4: r0 = AllocateClosure()
    //     0x12711f4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12711f8: r16 = <Color>
    //     0x12711f8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x12711fc: ldr             x16, [x16, #0xa90]
    // 0x1271200: stp             x0, x16, [SP]
    // 0x1271204: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1271204: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1271208: r0 = resolveWith()
    //     0x1271208: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x127120c: mov             x1, x0
    // 0x1271210: b               #0x1271250
    // 0x1271214: r1 = 1
    //     0x1271214: mov             x1, #1
    // 0x1271218: r0 = AllocateContext()
    //     0x1271218: bl              #0x13de838  ; AllocateContextStub
    // 0x127121c: mov             x1, x0
    // 0x1271220: ldr             x0, [fp, #0x10]
    // 0x1271224: StoreField: r1->field_f = r0
    //     0x1271224: stur            w0, [x1, #0xf]
    // 0x1271228: mov             x2, x1
    // 0x127122c: r1 = Function '<anonymous closure>':.
    //     0x127122c: add             x1, PP, #0x26, lsl #12  ; [pp+0x262a0] AnonymousClosure: (0xdfae80), of [package:flutter/src/material/radio.dart] _RadioDefaultsM2
    //     0x1271230: ldr             x1, [x1, #0x2a0]
    // 0x1271234: r0 = AllocateClosure()
    //     0x1271234: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1271238: r16 = <Color>
    //     0x1271238: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x127123c: ldr             x16, [x16, #0xa90]
    // 0x1271240: stp             x0, x16, [SP]
    // 0x1271244: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1271244: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1271248: r0 = resolveWith()
    //     0x1271248: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x127124c: mov             x1, x0
    // 0x1271250: ldur            x0, [fp, #-0x10]
    // 0x1271254: stur            x1, [fp, #-0x18]
    // 0x1271258: r17 = 5119
    //     0x1271258: mov             x17, #0x13ff
    // 0x127125c: cmp             x0, x17
    // 0x1271260: b.ne            #0x127127c
    // 0x1271264: ldr             x2, [fp, #0x18]
    // 0x1271268: LoadField: r3 = r2->field_f
    //     0x1271268: ldur            w3, [x2, #0xf]
    // 0x127126c: DecompressPointer r3
    //     0x127126c: add             x3, x3, HEAP, lsl #32
    // 0x1271270: mov             x0, x1
    // 0x1271274: mov             x1, x3
    // 0x1271278: b               #0x1271314
    // 0x127127c: ldr             x2, [fp, #0x18]
    // 0x1271280: r17 = 5120
    //     0x1271280: mov             x17, #0x1400
    // 0x1271284: cmp             x0, x17
    // 0x1271288: b.ne            #0x12712d0
    // 0x127128c: r1 = 1
    //     0x127128c: mov             x1, #1
    // 0x1271290: r0 = AllocateContext()
    //     0x1271290: bl              #0x13de838  ; AllocateContextStub
    // 0x1271294: mov             x1, x0
    // 0x1271298: ldr             x0, [fp, #0x18]
    // 0x127129c: StoreField: r1->field_f = r0
    //     0x127129c: stur            w0, [x1, #0xf]
    // 0x12712a0: mov             x2, x1
    // 0x12712a4: r1 = Function '<anonymous closure>':.
    //     0x12712a4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26298] AnonymousClosure: (0xdfb064), of [package:flutter/src/material/radio.dart] _RadioDefaultsM3
    //     0x12712a8: ldr             x1, [x1, #0x298]
    // 0x12712ac: r0 = AllocateClosure()
    //     0x12712ac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12712b0: r16 = <Color>
    //     0x12712b0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x12712b4: ldr             x16, [x16, #0xa90]
    // 0x12712b8: stp             x0, x16, [SP]
    // 0x12712bc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12712bc: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12712c0: r0 = resolveWith()
    //     0x12712c0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x12712c4: mov             x1, x0
    // 0x12712c8: ldur            x0, [fp, #-0x18]
    // 0x12712cc: b               #0x1271314
    // 0x12712d0: mov             x1, x2
    // 0x12712d4: r1 = 1
    //     0x12712d4: mov             x1, #1
    // 0x12712d8: r0 = AllocateContext()
    //     0x12712d8: bl              #0x13de838  ; AllocateContextStub
    // 0x12712dc: mov             x1, x0
    // 0x12712e0: ldr             x0, [fp, #0x18]
    // 0x12712e4: StoreField: r1->field_f = r0
    //     0x12712e4: stur            w0, [x1, #0xf]
    // 0x12712e8: mov             x2, x1
    // 0x12712ec: r1 = Function '<anonymous closure>':.
    //     0x12712ec: add             x1, PP, #0x26, lsl #12  ; [pp+0x262a0] AnonymousClosure: (0xdfae80), of [package:flutter/src/material/radio.dart] _RadioDefaultsM2
    //     0x12712f0: ldr             x1, [x1, #0x2a0]
    // 0x12712f4: r0 = AllocateClosure()
    //     0x12712f4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12712f8: r16 = <Color>
    //     0x12712f8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x12712fc: ldr             x16, [x16, #0xa90]
    // 0x1271300: stp             x0, x16, [SP]
    // 0x1271304: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1271304: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1271308: r0 = resolveWith()
    //     0x1271308: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x127130c: mov             x1, x0
    // 0x1271310: ldur            x0, [fp, #-0x18]
    // 0x1271314: cmp             w0, w1
    // 0x1271318: b.ne            #0x1271700
    // 0x127131c: ldr             x1, [fp, #0x18]
    // 0x1271320: ldr             x2, [fp, #0x10]
    // 0x1271324: LoadField: r0 = r2->field_13
    //     0x1271324: ldur            w0, [x2, #0x13]
    // 0x1271328: DecompressPointer r0
    //     0x1271328: add             x0, x0, HEAP, lsl #32
    // 0x127132c: LoadField: r3 = r1->field_13
    //     0x127132c: ldur            w3, [x1, #0x13]
    // 0x1271330: DecompressPointer r3
    //     0x1271330: add             x3, x3, HEAP, lsl #32
    // 0x1271334: r4 = LoadClassIdInstr(r0)
    //     0x1271334: ldur            x4, [x0, #-1]
    //     0x1271338: ubfx            x4, x4, #0xc, #0x14
    // 0x127133c: stp             x3, x0, [SP]
    // 0x1271340: mov             x0, x4
    // 0x1271344: mov             lr, x0
    // 0x1271348: ldr             lr, [x21, lr, lsl #3]
    // 0x127134c: blr             lr
    // 0x1271350: tbnz            w0, #4, #0x1271700
    // 0x1271354: ldur            x0, [fp, #-8]
    // 0x1271358: r17 = 5119
    //     0x1271358: mov             x17, #0x13ff
    // 0x127135c: cmp             x0, x17
    // 0x1271360: b.ne            #0x1271378
    // 0x1271364: ldr             x2, [fp, #0x10]
    // 0x1271368: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x1271368: ldur            w1, [x2, #0x17]
    // 0x127136c: DecompressPointer r1
    //     0x127136c: add             x1, x1, HEAP, lsl #32
    // 0x1271370: mov             x2, x1
    // 0x1271374: b               #0x12713ec
    // 0x1271378: ldr             x2, [fp, #0x10]
    // 0x127137c: r17 = 5120
    //     0x127137c: mov             x17, #0x1400
    // 0x1271380: cmp             x0, x17
    // 0x1271384: b.ne            #0x12713bc
    // 0x1271388: mov             x1, x2
    // 0x127138c: LoadField: r0 = r1->field_2f
    //     0x127138c: ldur            w0, [x1, #0x2f]
    // 0x1271390: DecompressPointer r0
    //     0x1271390: add             x0, x0, HEAP, lsl #32
    // 0x1271394: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1271398: cmp             w0, w16
    // 0x127139c: b.ne            #0x12713ac
    // 0x12713a0: r2 = _theme
    //     0x12713a0: add             x2, PP, #0x26, lsl #12  ; [pp+0x262a8] Field <_RadioDefaultsM3@625266229._theme@625266229>: late final (offset: 0x30)
    //     0x12713a4: ldr             x2, [x2, #0x2a8]
    // 0x12713a8: r0 = InitLateFinalInstanceField()
    //     0x12713a8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12713ac: LoadField: r1 = r0->field_1b
    //     0x12713ac: ldur            w1, [x0, #0x1b]
    // 0x12713b0: DecompressPointer r1
    //     0x12713b0: add             x1, x1, HEAP, lsl #32
    // 0x12713b4: mov             x2, x1
    // 0x12713b8: b               #0x12713ec
    // 0x12713bc: ldr             x1, [fp, #0x10]
    // 0x12713c0: LoadField: r0 = r1->field_2f
    //     0x12713c0: ldur            w0, [x1, #0x2f]
    // 0x12713c4: DecompressPointer r0
    //     0x12713c4: add             x0, x0, HEAP, lsl #32
    // 0x12713c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12713cc: cmp             w0, w16
    // 0x12713d0: b.ne            #0x12713e0
    // 0x12713d4: r2 = _theme
    //     0x12713d4: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b0] Field <_RadioDefaultsM2@625266229._theme@625266229>: late final (offset: 0x30)
    //     0x12713d8: ldr             x2, [x2, #0x2b0]
    // 0x12713dc: r0 = InitLateFinalInstanceField()
    //     0x12713dc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12713e0: LoadField: r1 = r0->field_1b
    //     0x12713e0: ldur            w1, [x0, #0x1b]
    // 0x12713e4: DecompressPointer r1
    //     0x12713e4: add             x1, x1, HEAP, lsl #32
    // 0x12713e8: mov             x2, x1
    // 0x12713ec: ldur            x0, [fp, #-0x10]
    // 0x12713f0: stur            x2, [fp, #-0x18]
    // 0x12713f4: r17 = 5119
    //     0x12713f4: mov             x17, #0x13ff
    // 0x12713f8: cmp             x0, x17
    // 0x12713fc: b.ne            #0x1271414
    // 0x1271400: ldr             x3, [fp, #0x18]
    // 0x1271404: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x1271404: ldur            w1, [x3, #0x17]
    // 0x1271408: DecompressPointer r1
    //     0x1271408: add             x1, x1, HEAP, lsl #32
    // 0x127140c: mov             x0, x2
    // 0x1271410: b               #0x1271488
    // 0x1271414: ldr             x3, [fp, #0x18]
    // 0x1271418: r17 = 5120
    //     0x1271418: mov             x17, #0x1400
    // 0x127141c: cmp             x0, x17
    // 0x1271420: b.ne            #0x1271458
    // 0x1271424: mov             x1, x3
    // 0x1271428: LoadField: r0 = r1->field_2f
    //     0x1271428: ldur            w0, [x1, #0x2f]
    // 0x127142c: DecompressPointer r0
    //     0x127142c: add             x0, x0, HEAP, lsl #32
    // 0x1271430: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1271434: cmp             w0, w16
    // 0x1271438: b.ne            #0x1271448
    // 0x127143c: r2 = _theme
    //     0x127143c: add             x2, PP, #0x26, lsl #12  ; [pp+0x262a8] Field <_RadioDefaultsM3@625266229._theme@625266229>: late final (offset: 0x30)
    //     0x1271440: ldr             x2, [x2, #0x2a8]
    // 0x1271444: r0 = InitLateFinalInstanceField()
    //     0x1271444: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1271448: LoadField: r1 = r0->field_1b
    //     0x1271448: ldur            w1, [x0, #0x1b]
    // 0x127144c: DecompressPointer r1
    //     0x127144c: add             x1, x1, HEAP, lsl #32
    // 0x1271450: ldur            x0, [fp, #-0x18]
    // 0x1271454: b               #0x1271488
    // 0x1271458: ldr             x1, [fp, #0x18]
    // 0x127145c: LoadField: r0 = r1->field_2f
    //     0x127145c: ldur            w0, [x1, #0x2f]
    // 0x1271460: DecompressPointer r0
    //     0x1271460: add             x0, x0, HEAP, lsl #32
    // 0x1271464: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1271468: cmp             w0, w16
    // 0x127146c: b.ne            #0x127147c
    // 0x1271470: r2 = _theme
    //     0x1271470: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b0] Field <_RadioDefaultsM2@625266229._theme@625266229>: late final (offset: 0x30)
    //     0x1271474: ldr             x2, [x2, #0x2b0]
    // 0x1271478: r0 = InitLateFinalInstanceField()
    //     0x1271478: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x127147c: LoadField: r1 = r0->field_1b
    //     0x127147c: ldur            w1, [x0, #0x1b]
    // 0x1271480: DecompressPointer r1
    //     0x1271480: add             x1, x1, HEAP, lsl #32
    // 0x1271484: ldur            x0, [fp, #-0x18]
    // 0x1271488: cmp             w0, w1
    // 0x127148c: b.ne            #0x1271700
    // 0x1271490: ldur            x0, [fp, #-8]
    // 0x1271494: r17 = 5119
    //     0x1271494: mov             x17, #0x13ff
    // 0x1271498: cmp             x0, x17
    // 0x127149c: b.ne            #0x12714b4
    // 0x12714a0: ldr             x2, [fp, #0x10]
    // 0x12714a4: LoadField: r1 = r2->field_1b
    //     0x12714a4: ldur            w1, [x2, #0x1b]
    // 0x12714a8: DecompressPointer r1
    //     0x12714a8: add             x1, x1, HEAP, lsl #32
    // 0x12714ac: mov             x2, x1
    // 0x12714b0: b               #0x1271528
    // 0x12714b4: ldr             x2, [fp, #0x10]
    // 0x12714b8: r17 = 5120
    //     0x12714b8: mov             x17, #0x1400
    // 0x12714bc: cmp             x0, x17
    // 0x12714c0: b.ne            #0x12714f8
    // 0x12714c4: mov             x1, x2
    // 0x12714c8: LoadField: r0 = r1->field_2f
    //     0x12714c8: ldur            w0, [x1, #0x2f]
    // 0x12714cc: DecompressPointer r0
    //     0x12714cc: add             x0, x0, HEAP, lsl #32
    // 0x12714d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12714d4: cmp             w0, w16
    // 0x12714d8: b.ne            #0x12714e8
    // 0x12714dc: r2 = _theme
    //     0x12714dc: add             x2, PP, #0x26, lsl #12  ; [pp+0x262a8] Field <_RadioDefaultsM3@625266229._theme@625266229>: late final (offset: 0x30)
    //     0x12714e0: ldr             x2, [x2, #0x2a8]
    // 0x12714e4: r0 = InitLateFinalInstanceField()
    //     0x12714e4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12714e8: LoadField: r1 = r0->field_33
    //     0x12714e8: ldur            w1, [x0, #0x33]
    // 0x12714ec: DecompressPointer r1
    //     0x12714ec: add             x1, x1, HEAP, lsl #32
    // 0x12714f0: mov             x2, x1
    // 0x12714f4: b               #0x1271528
    // 0x12714f8: ldr             x1, [fp, #0x10]
    // 0x12714fc: LoadField: r0 = r1->field_2f
    //     0x12714fc: ldur            w0, [x1, #0x2f]
    // 0x1271500: DecompressPointer r0
    //     0x1271500: add             x0, x0, HEAP, lsl #32
    // 0x1271504: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1271508: cmp             w0, w16
    // 0x127150c: b.ne            #0x127151c
    // 0x1271510: r2 = _theme
    //     0x1271510: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b0] Field <_RadioDefaultsM2@625266229._theme@625266229>: late final (offset: 0x30)
    //     0x1271514: ldr             x2, [x2, #0x2b0]
    // 0x1271518: r0 = InitLateFinalInstanceField()
    //     0x1271518: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x127151c: LoadField: r1 = r0->field_33
    //     0x127151c: ldur            w1, [x0, #0x33]
    // 0x1271520: DecompressPointer r1
    //     0x1271520: add             x1, x1, HEAP, lsl #32
    // 0x1271524: mov             x2, x1
    // 0x1271528: ldur            x0, [fp, #-0x10]
    // 0x127152c: stur            x2, [fp, #-0x18]
    // 0x1271530: r17 = 5119
    //     0x1271530: mov             x17, #0x13ff
    // 0x1271534: cmp             x0, x17
    // 0x1271538: b.ne            #0x1271550
    // 0x127153c: ldr             x3, [fp, #0x18]
    // 0x1271540: LoadField: r1 = r3->field_1b
    //     0x1271540: ldur            w1, [x3, #0x1b]
    // 0x1271544: DecompressPointer r1
    //     0x1271544: add             x1, x1, HEAP, lsl #32
    // 0x1271548: mov             x0, x2
    // 0x127154c: b               #0x12715c4
    // 0x1271550: ldr             x3, [fp, #0x18]
    // 0x1271554: r17 = 5120
    //     0x1271554: mov             x17, #0x1400
    // 0x1271558: cmp             x0, x17
    // 0x127155c: b.ne            #0x1271594
    // 0x1271560: mov             x1, x3
    // 0x1271564: LoadField: r0 = r1->field_2f
    //     0x1271564: ldur            w0, [x1, #0x2f]
    // 0x1271568: DecompressPointer r0
    //     0x1271568: add             x0, x0, HEAP, lsl #32
    // 0x127156c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1271570: cmp             w0, w16
    // 0x1271574: b.ne            #0x1271584
    // 0x1271578: r2 = _theme
    //     0x1271578: add             x2, PP, #0x26, lsl #12  ; [pp+0x262a8] Field <_RadioDefaultsM3@625266229._theme@625266229>: late final (offset: 0x30)
    //     0x127157c: ldr             x2, [x2, #0x2a8]
    // 0x1271580: r0 = InitLateFinalInstanceField()
    //     0x1271580: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1271584: LoadField: r1 = r0->field_33
    //     0x1271584: ldur            w1, [x0, #0x33]
    // 0x1271588: DecompressPointer r1
    //     0x1271588: add             x1, x1, HEAP, lsl #32
    // 0x127158c: ldur            x0, [fp, #-0x18]
    // 0x1271590: b               #0x12715c4
    // 0x1271594: ldr             x1, [fp, #0x18]
    // 0x1271598: LoadField: r0 = r1->field_2f
    //     0x1271598: ldur            w0, [x1, #0x2f]
    // 0x127159c: DecompressPointer r0
    //     0x127159c: add             x0, x0, HEAP, lsl #32
    // 0x12715a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12715a4: cmp             w0, w16
    // 0x12715a8: b.ne            #0x12715b8
    // 0x12715ac: r2 = _theme
    //     0x12715ac: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b0] Field <_RadioDefaultsM2@625266229._theme@625266229>: late final (offset: 0x30)
    //     0x12715b0: ldr             x2, [x2, #0x2b0]
    // 0x12715b4: r0 = InitLateFinalInstanceField()
    //     0x12715b4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12715b8: LoadField: r1 = r0->field_33
    //     0x12715b8: ldur            w1, [x0, #0x33]
    // 0x12715bc: DecompressPointer r1
    //     0x12715bc: add             x1, x1, HEAP, lsl #32
    // 0x12715c0: ldur            x0, [fp, #-0x18]
    // 0x12715c4: r2 = LoadClassIdInstr(r0)
    //     0x12715c4: ldur            x2, [x0, #-1]
    //     0x12715c8: ubfx            x2, x2, #0xc, #0x14
    // 0x12715cc: stp             x1, x0, [SP]
    // 0x12715d0: mov             x0, x2
    // 0x12715d4: mov             lr, x0
    // 0x12715d8: ldr             lr, [x21, lr, lsl #3]
    // 0x12715dc: blr             lr
    // 0x12715e0: tbnz            w0, #4, #0x1271700
    // 0x12715e4: ldur            x0, [fp, #-8]
    // 0x12715e8: r17 = 5119
    //     0x12715e8: mov             x17, #0x13ff
    // 0x12715ec: cmp             x0, x17
    // 0x12715f0: b.ne            #0x1271604
    // 0x12715f4: ldr             x0, [fp, #0x10]
    // 0x12715f8: LoadField: r1 = r0->field_1f
    //     0x12715f8: ldur            w1, [x0, #0x1f]
    // 0x12715fc: DecompressPointer r1
    //     0x12715fc: add             x1, x1, HEAP, lsl #32
    // 0x1271600: b               #0x1271654
    // 0x1271604: r17 = 5120
    //     0x1271604: mov             x17, #0x1400
    // 0x1271608: cmp             x0, x17
    // 0x127160c: b.ne            #0x1271634
    // 0x1271610: r16 = <Color>
    //     0x1271610: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1271614: ldr             x16, [x16, #0xa90]
    // 0x1271618: r30 = Instance_Color
    //     0x1271618: add             lr, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x127161c: ldr             lr, [lr, #0x810]
    // 0x1271620: stp             lr, x16, [SP]
    // 0x1271624: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1271624: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1271628: r0 = all()
    //     0x1271628: bl              #0xd13288  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::all
    // 0x127162c: mov             x1, x0
    // 0x1271630: b               #0x1271654
    // 0x1271634: r16 = <Color>
    //     0x1271634: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1271638: ldr             x16, [x16, #0xa90]
    // 0x127163c: r30 = Instance_Color
    //     0x127163c: add             lr, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1271640: ldr             lr, [lr, #0x810]
    // 0x1271644: stp             lr, x16, [SP]
    // 0x1271648: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1271648: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x127164c: r0 = all()
    //     0x127164c: bl              #0xd13288  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::all
    // 0x1271650: mov             x1, x0
    // 0x1271654: ldur            x0, [fp, #-0x10]
    // 0x1271658: stur            x1, [fp, #-0x18]
    // 0x127165c: r17 = 5119
    //     0x127165c: mov             x17, #0x13ff
    // 0x1271660: cmp             x0, x17
    // 0x1271664: b.ne            #0x1271680
    // 0x1271668: ldr             x0, [fp, #0x18]
    // 0x127166c: LoadField: r2 = r0->field_1f
    //     0x127166c: ldur            w2, [x0, #0x1f]
    // 0x1271670: DecompressPointer r2
    //     0x1271670: add             x2, x2, HEAP, lsl #32
    // 0x1271674: mov             x0, x1
    // 0x1271678: mov             x1, x2
    // 0x127167c: b               #0x12716d8
    // 0x1271680: r17 = 5120
    //     0x1271680: mov             x17, #0x1400
    // 0x1271684: cmp             x0, x17
    // 0x1271688: b.ne            #0x12716b4
    // 0x127168c: r16 = <Color>
    //     0x127168c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1271690: ldr             x16, [x16, #0xa90]
    // 0x1271694: r30 = Instance_Color
    //     0x1271694: add             lr, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1271698: ldr             lr, [lr, #0x810]
    // 0x127169c: stp             lr, x16, [SP]
    // 0x12716a0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12716a0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12716a4: r0 = all()
    //     0x12716a4: bl              #0xd13288  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::all
    // 0x12716a8: mov             x1, x0
    // 0x12716ac: ldur            x0, [fp, #-0x18]
    // 0x12716b0: b               #0x12716d8
    // 0x12716b4: r16 = <Color>
    //     0x12716b4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x12716b8: ldr             x16, [x16, #0xa90]
    // 0x12716bc: r30 = Instance_Color
    //     0x12716bc: add             lr, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x12716c0: ldr             lr, [lr, #0x810]
    // 0x12716c4: stp             lr, x16, [SP]
    // 0x12716c8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12716c8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12716cc: r0 = all()
    //     0x12716cc: bl              #0xd13288  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::all
    // 0x12716d0: mov             x1, x0
    // 0x12716d4: ldur            x0, [fp, #-0x18]
    // 0x12716d8: r2 = LoadClassIdInstr(r0)
    //     0x12716d8: ldur            x2, [x0, #-1]
    //     0x12716dc: ubfx            x2, x2, #0xc, #0x14
    // 0x12716e0: stp             x1, x0, [SP]
    // 0x12716e4: mov             x0, x2
    // 0x12716e8: mov             lr, x0
    // 0x12716ec: ldr             lr, [x21, lr, lsl #3]
    // 0x12716f0: blr             lr
    // 0x12716f4: tbnz            w0, #4, #0x1271700
    // 0x12716f8: r0 = true
    //     0x12716f8: add             x0, NULL, #0x20  ; true
    // 0x12716fc: b               #0x1271704
    // 0x1271700: r0 = false
    //     0x1271700: add             x0, NULL, #0x30  ; false
    // 0x1271704: LeaveFrame
    //     0x1271704: mov             SP, fp
    //     0x1271708: ldp             fp, lr, [SP], #0x10
    // 0x127170c: ret
    //     0x127170c: ret             
    // 0x1271710: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1271710: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1271714: b               #0x1270fc0
  }
}

// class id: 6811, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class RadioTheme extends InheritedWidget {

  static _ of(/* No info */) {
    // ** addr: 0xd32f98, size: 0x5c
    // 0xd32f98: EnterFrame
    //     0xd32f98: stp             fp, lr, [SP, #-0x10]!
    //     0xd32f9c: mov             fp, SP
    // 0xd32fa0: AllocStack(0x18)
    //     0xd32fa0: sub             SP, SP, #0x18
    // 0xd32fa4: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xd32fa4: stur            x1, [fp, #-8]
    // 0xd32fa8: CheckStackOverflow
    //     0xd32fa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd32fac: cmp             SP, x16
    //     0xd32fb0: b.ls            #0xd32fec
    // 0xd32fb4: r16 = <RadioTheme>
    //     0xd32fb4: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd4808] TypeArguments: <RadioTheme>
    //     0xd32fb8: ldr             x16, [x16, #0x808]
    // 0xd32fbc: stp             x1, x16, [SP]
    // 0xd32fc0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd32fc0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd32fc4: r0 = dependOnInheritedWidgetOfExactType()
    //     0xd32fc4: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xd32fc8: ldur            x1, [fp, #-8]
    // 0xd32fcc: r0 = of()
    //     0xd32fcc: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd32fd0: r17 = 275
    //     0xd32fd0: mov             x17, #0x113
    // 0xd32fd4: ldr             w1, [x0, x17]
    // 0xd32fd8: DecompressPointer r1
    //     0xd32fd8: add             x1, x1, HEAP, lsl #32
    // 0xd32fdc: mov             x0, x1
    // 0xd32fe0: LeaveFrame
    //     0xd32fe0: mov             SP, fp
    //     0xd32fe4: ldp             fp, lr, [SP], #0x10
    // 0xd32fe8: ret
    //     0xd32fe8: ret             
    // 0xd32fec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd32fec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd32ff0: b               #0xd32fb4
  }
}
