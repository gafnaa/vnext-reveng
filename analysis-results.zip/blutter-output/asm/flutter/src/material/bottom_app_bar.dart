// lib: , url: package:flutter/src/material/bottom_app_bar.dart

// class id: 1048849, size: 0x8
class :: {
}

// class id: 4309, size: 0x24, field offset: 0x10
//   const constructor, 
class _BottomAppBarClipper extends CustomClipper<dynamic> {

  _ shouldReclip(/* No info */) {
    // ** addr: 0x119daf0, size: 0xa4
    // 0x119daf0: EnterFrame
    //     0x119daf0: stp             fp, lr, [SP, #-0x10]!
    //     0x119daf4: mov             fp, SP
    // 0x119daf8: AllocStack(0x10)
    //     0x119daf8: sub             SP, SP, #0x10
    // 0x119dafc: SetupParameters(_BottomAppBarClipper this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x119dafc: mov             x0, x2
    //     0x119db00: mov             x4, x1
    //     0x119db04: mov             x3, x2
    //     0x119db08: stur            x1, [fp, #-8]
    //     0x119db0c: stur            x2, [fp, #-0x10]
    // 0x119db10: r2 = Null
    //     0x119db10: mov             x2, NULL
    // 0x119db14: r1 = Null
    //     0x119db14: mov             x1, NULL
    // 0x119db18: r4 = 60
    //     0x119db18: mov             x4, #0x3c
    // 0x119db1c: branchIfSmi(r0, 0x119db28)
    //     0x119db1c: tbz             w0, #0, #0x119db28
    // 0x119db20: r4 = LoadClassIdInstr(r0)
    //     0x119db20: ldur            x4, [x0, #-1]
    //     0x119db24: ubfx            x4, x4, #0xc, #0x14
    // 0x119db28: r17 = 4309
    //     0x119db28: mov             x17, #0x10d5
    // 0x119db2c: cmp             x4, x17
    // 0x119db30: b.eq            #0x119db48
    // 0x119db34: r8 = _BottomAppBarClipper
    //     0x119db34: add             x8, PP, #0xa0, lsl #12  ; [pp+0xa0f40] Type: _BottomAppBarClipper
    //     0x119db38: ldr             x8, [x8, #0xf40]
    // 0x119db3c: r3 = Null
    //     0x119db3c: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0f48] Null
    //     0x119db40: ldr             x3, [x3, #0xf48]
    // 0x119db44: r0 = DefaultTypeTest()
    //     0x119db44: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x119db48: ldur            x1, [fp, #-0x10]
    // 0x119db4c: LoadField: r2 = r1->field_f
    //     0x119db4c: ldur            w2, [x1, #0xf]
    // 0x119db50: DecompressPointer r2
    //     0x119db50: add             x2, x2, HEAP, lsl #32
    // 0x119db54: ldur            x1, [fp, #-8]
    // 0x119db58: LoadField: r3 = r1->field_f
    //     0x119db58: ldur            w3, [x1, #0xf]
    // 0x119db5c: DecompressPointer r3
    //     0x119db5c: add             x3, x3, HEAP, lsl #32
    // 0x119db60: cmp             w2, w3
    // 0x119db64: b.eq            #0x119db70
    // 0x119db68: r0 = true
    //     0x119db68: add             x0, NULL, #0x20  ; true
    // 0x119db6c: b               #0x119db88
    // 0x119db70: d0 = 4.000000
    //     0x119db70: fmov            d0, #4.00000000
    // 0x119db74: fcmp            d0, d0
    // 0x119db78: r16 = true
    //     0x119db78: add             x16, NULL, #0x20  ; true
    // 0x119db7c: r17 = false
    //     0x119db7c: add             x17, NULL, #0x30  ; false
    // 0x119db80: csel            x1, x16, x17, ne
    // 0x119db84: mov             x0, x1
    // 0x119db88: LeaveFrame
    //     0x119db88: mov             SP, fp
    //     0x119db8c: ldp             fp, lr, [SP], #0x10
    // 0x119db90: ret
    //     0x119db90: ret             
  }
  _ getClip(/* No info */) {
    // ** addr: 0x11d612c, size: 0xe4
    // 0x11d612c: EnterFrame
    //     0x11d612c: stp             fp, lr, [SP, #-0x10]!
    //     0x11d6130: mov             fp, SP
    // 0x11d6134: AllocStack(0x18)
    //     0x11d6134: sub             SP, SP, #0x18
    // 0x11d6138: SetupParameters(_BottomAppBarClipper this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x11d6138: mov             x0, x1
    //     0x11d613c: stur            x1, [fp, #-8]
    //     0x11d6140: stur            x2, [fp, #-0x10]
    // 0x11d6144: CheckStackOverflow
    //     0x11d6144: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d6148: cmp             SP, x16
    //     0x11d614c: b.ls            #0x11d6204
    // 0x11d6150: LoadField: r1 = r0->field_f
    //     0x11d6150: ldur            w1, [x0, #0xf]
    // 0x11d6154: DecompressPointer r1
    //     0x11d6154: add             x1, x1, HEAP, lsl #32
    // 0x11d6158: LoadField: r3 = r1->field_27
    //     0x11d6158: ldur            w3, [x1, #0x27]
    // 0x11d615c: DecompressPointer r3
    //     0x11d615c: add             x3, x3, HEAP, lsl #32
    // 0x11d6160: LoadField: r4 = r1->field_23
    //     0x11d6160: ldur            w4, [x1, #0x23]
    // 0x11d6164: DecompressPointer r4
    //     0x11d6164: add             x4, x4, HEAP, lsl #32
    // 0x11d6168: cmp             w4, NULL
    // 0x11d616c: b.eq            #0x11d620c
    // 0x11d6170: LoadField: d0 = r4->field_7
    //     0x11d6170: ldur            d0, [x4, #7]
    // 0x11d6174: mov             x1, x3
    // 0x11d6178: r0 = _scaleFloatingActionButton()
    //     0x11d6178: bl              #0xae07b8  ; [package:flutter/src/material/scaffold.dart] ScaffoldGeometry::_scaleFloatingActionButton
    // 0x11d617c: LoadField: r2 = r0->field_b
    //     0x11d617c: ldur            w2, [x0, #0xb]
    // 0x11d6180: DecompressPointer r2
    //     0x11d6180: add             x2, x2, HEAP, lsl #32
    // 0x11d6184: stur            x2, [fp, #-0x18]
    // 0x11d6188: cmp             w2, NULL
    // 0x11d618c: b.ne            #0x11d6198
    // 0x11d6190: r0 = Null
    //     0x11d6190: mov             x0, NULL
    // 0x11d6194: b               #0x11d61bc
    // 0x11d6198: ldur            x1, [fp, #-8]
    // 0x11d619c: r0 = bottomNavigationBarTop()
    //     0x11d619c: bl              #0x11d6210  ; [package:flutter/src/material/bottom_app_bar.dart] _BottomAppBarClipper::bottomNavigationBarTop
    // 0x11d61a0: mov             v1.16b, v0.16b
    // 0x11d61a4: d0 = -1.000000
    //     0x11d61a4: fmov            d0, #-1.00000000
    // 0x11d61a8: fmul            d2, d1, d0
    // 0x11d61ac: ldur            x1, [fp, #-0x18]
    // 0x11d61b0: mov             v1.16b, v2.16b
    // 0x11d61b4: d0 = 0.000000
    //     0x11d61b4: eor             v0.16b, v0.16b, v0.16b
    // 0x11d61b8: r0 = translate()
    //     0x11d61b8: bl              #0xb6c7ac  ; [dart:ui] Rect::translate
    // 0x11d61bc: ldur            x2, [fp, #-0x10]
    // 0x11d61c0: stur            x0, [fp, #-8]
    // 0x11d61c4: r1 = Instance_Offset
    //     0x11d61c4: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x11d61c8: r0 = &()
    //     0x11d61c8: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x11d61cc: ldur            x1, [fp, #-8]
    // 0x11d61d0: stur            x0, [fp, #-0x10]
    // 0x11d61d4: cmp             w1, NULL
    // 0x11d61d8: b.eq            #0x11d61e4
    // 0x11d61dc: d0 = 4.000000
    //     0x11d61dc: fmov            d0, #4.00000000
    // 0x11d61e0: r0 = inflate()
    //     0x11d61e0: bl              #0x882f50  ; [dart:ui] Rect::inflate
    // 0x11d61e4: ldur            x2, [fp, #-0x10]
    // 0x11d61e8: r1 = Instance_RoundedRectangleBorder
    //     0x11d61e8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26600] Obj!RoundedRectangleBorder@129ec31
    //     0x11d61ec: ldr             x1, [x1, #0x600]
    // 0x11d61f0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x11d61f0: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x11d61f4: r0 = getOuterPath()
    //     0x11d61f4: bl              #0x12ffbb0  ; [package:flutter/src/painting/rounded_rectangle_border.dart] RoundedRectangleBorder::getOuterPath
    // 0x11d61f8: LeaveFrame
    //     0x11d61f8: mov             SP, fp
    //     0x11d61fc: ldp             fp, lr, [SP], #0x10
    // 0x11d6200: ret
    //     0x11d6200: ret             
    // 0x11d6204: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d6204: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d6208: b               #0x11d6150
    // 0x11d620c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11d620c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ bottomNavigationBarTop(/* No info */) {
    // ** addr: 0x11d6210, size: 0x160
    // 0x11d6210: EnterFrame
    //     0x11d6210: stp             fp, lr, [SP, #-0x10]!
    //     0x11d6214: mov             fp, SP
    // 0x11d6218: AllocStack(0x8)
    //     0x11d6218: sub             SP, SP, #8
    // 0x11d621c: SetupParameters(_BottomAppBarClipper this /* r1 => r0, fp-0x8 */)
    //     0x11d621c: mov             x0, x1
    //     0x11d6220: stur            x1, [fp, #-8]
    // 0x11d6224: CheckStackOverflow
    //     0x11d6224: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d6228: cmp             SP, x16
    //     0x11d622c: b.ls            #0x11d6354
    // 0x11d6230: LoadField: r1 = r0->field_f
    //     0x11d6230: ldur            w1, [x0, #0xf]
    // 0x11d6234: DecompressPointer r1
    //     0x11d6234: add             x1, x1, HEAP, lsl #32
    // 0x11d6238: LoadField: r2 = r1->field_27
    //     0x11d6238: ldur            w2, [x1, #0x27]
    // 0x11d623c: DecompressPointer r2
    //     0x11d623c: add             x2, x2, HEAP, lsl #32
    // 0x11d6240: LoadField: r3 = r1->field_23
    //     0x11d6240: ldur            w3, [x1, #0x23]
    // 0x11d6244: DecompressPointer r3
    //     0x11d6244: add             x3, x3, HEAP, lsl #32
    // 0x11d6248: cmp             w3, NULL
    // 0x11d624c: b.eq            #0x11d635c
    // 0x11d6250: LoadField: d0 = r3->field_7
    //     0x11d6250: ldur            d0, [x3, #7]
    // 0x11d6254: mov             x1, x2
    // 0x11d6258: r0 = _scaleFloatingActionButton()
    //     0x11d6258: bl              #0xae07b8  ; [package:flutter/src/material/scaffold.dart] ScaffoldGeometry::_scaleFloatingActionButton
    // 0x11d625c: LoadField: r1 = r0->field_7
    //     0x11d625c: ldur            w1, [x0, #7]
    // 0x11d6260: DecompressPointer r1
    //     0x11d6260: add             x1, x1, HEAP, lsl #32
    // 0x11d6264: cmp             w1, NULL
    // 0x11d6268: b.eq            #0x11d627c
    // 0x11d626c: LoadField: d0 = r1->field_7
    //     0x11d626c: ldur            d0, [x1, #7]
    // 0x11d6270: LeaveFrame
    //     0x11d6270: mov             SP, fp
    //     0x11d6274: ldp             fp, lr, [SP], #0x10
    // 0x11d6278: ret
    //     0x11d6278: ret             
    // 0x11d627c: ldur            x0, [fp, #-8]
    // 0x11d6280: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11d6280: ldur            w1, [x0, #0x17]
    // 0x11d6284: DecompressPointer r1
    //     0x11d6284: add             x1, x1, HEAP, lsl #32
    // 0x11d6288: r0 = _currentElement()
    //     0x11d6288: bl              #0x859318  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0x11d628c: cmp             w0, NULL
    // 0x11d6290: b.ne            #0x11d629c
    // 0x11d6294: r3 = Null
    //     0x11d6294: mov             x3, NULL
    // 0x11d6298: b               #0x11d62a8
    // 0x11d629c: mov             x1, x0
    // 0x11d62a0: r0 = findRenderObject()
    //     0x11d62a0: bl              #0x8418fc  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0x11d62a4: mov             x3, x0
    // 0x11d62a8: mov             x0, x3
    // 0x11d62ac: stur            x3, [fp, #-8]
    // 0x11d62b0: r2 = Null
    //     0x11d62b0: mov             x2, NULL
    // 0x11d62b4: r1 = Null
    //     0x11d62b4: mov             x1, NULL
    // 0x11d62b8: r4 = LoadClassIdInstr(r0)
    //     0x11d62b8: ldur            x4, [x0, #-1]
    //     0x11d62bc: ubfx            x4, x4, #0xc, #0x14
    // 0x11d62c0: r17 = -4710
    //     0x11d62c0: mov             x17, #-0x1266
    // 0x11d62c4: add             x4, x4, x17
    // 0x11d62c8: cmp             x4, #0x109
    // 0x11d62cc: b.ls            #0x11d62e0
    // 0x11d62d0: r8 = RenderBox?
    //     0x11d62d0: ldr             x8, [PP, #0x47c8]  ; [pp+0x47c8] Type: RenderBox?
    // 0x11d62d4: r3 = Null
    //     0x11d62d4: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0f58] Null
    //     0x11d62d8: ldr             x3, [x3, #0xf58]
    // 0x11d62dc: r0 = RenderBox?()
    //     0x11d62dc: bl              #0x870a94  ; IsType_RenderBox?_Stub
    // 0x11d62e0: ldur            x1, [fp, #-8]
    // 0x11d62e4: cmp             w1, NULL
    // 0x11d62e8: b.ne            #0x11d62f4
    // 0x11d62ec: r0 = Null
    //     0x11d62ec: mov             x0, NULL
    // 0x11d62f0: b               #0x11d6330
    // 0x11d62f4: r2 = Instance_Offset
    //     0x11d62f4: ldr             x2, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x11d62f8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x11d62f8: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x11d62fc: r0 = localToGlobal()
    //     0x11d62fc: bl              #0x856eb0  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0x11d6300: LoadField: d1 = r0->field_f
    //     0x11d6300: ldur            d1, [x0, #0xf]
    // 0x11d6304: r0 = inline_Allocate_Double()
    //     0x11d6304: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x11d6308: add             x0, x0, #0x10
    //     0x11d630c: cmp             x1, x0
    //     0x11d6310: b.ls            #0x11d6360
    //     0x11d6314: str             x0, [THR, #0x60]  ; THR::top
    //     0x11d6318: sub             x0, x0, #0xf
    //     0x11d631c: mov             x1, #0xe19c
    //     0x11d6320: movk            x1, #3, lsl #16
    //     0x11d6324: stur            x1, [x0, #-1]
    // 0x11d6328: dmb             ishst
    // 0x11d632c: StoreField: r0->field_7 = d1
    //     0x11d632c: stur            d1, [x0, #7]
    // 0x11d6330: cmp             w0, NULL
    // 0x11d6334: b.ne            #0x11d6340
    // 0x11d6338: d0 = 0.000000
    //     0x11d6338: eor             v0.16b, v0.16b, v0.16b
    // 0x11d633c: b               #0x11d6348
    // 0x11d6340: LoadField: d1 = r0->field_7
    //     0x11d6340: ldur            d1, [x0, #7]
    // 0x11d6344: mov             v0.16b, v1.16b
    // 0x11d6348: LeaveFrame
    //     0x11d6348: mov             SP, fp
    //     0x11d634c: ldp             fp, lr, [SP], #0x10
    // 0x11d6350: ret
    //     0x11d6350: ret             
    // 0x11d6354: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d6354: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d6358: b               #0x11d6230
    // 0x11d635c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11d635c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x11d6360: SaveReg d1
    //     0x11d6360: str             q1, [SP, #-0x10]!
    // 0x11d6364: r0 = AllocateDouble()
    //     0x11d6364: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11d6368: RestoreReg d1
    //     0x11d6368: ldr             q1, [SP], #0x10
    // 0x11d636c: b               #0x11d632c
  }
}

// class id: 5205, size: 0x2c, field offset: 0x24
class _BottomAppBarDefaultsM3 extends BottomAppBarThemeData {

  late final ColorScheme _colors; // offset: 0x28

  ColorScheme _colors(_BottomAppBarDefaultsM3) {
    // ** addr: 0x112ef30, size: 0x44
    // 0x112ef30: EnterFrame
    //     0x112ef30: stp             fp, lr, [SP, #-0x10]!
    //     0x112ef34: mov             fp, SP
    // 0x112ef38: CheckStackOverflow
    //     0x112ef38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112ef3c: cmp             SP, x16
    //     0x112ef40: b.ls            #0x112ef6c
    // 0x112ef44: ldr             x0, [fp, #0x10]
    // 0x112ef48: LoadField: r1 = r0->field_23
    //     0x112ef48: ldur            w1, [x0, #0x23]
    // 0x112ef4c: DecompressPointer r1
    //     0x112ef4c: add             x1, x1, HEAP, lsl #32
    // 0x112ef50: r0 = of()
    //     0x112ef50: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x112ef54: LoadField: r1 = r0->field_3f
    //     0x112ef54: ldur            w1, [x0, #0x3f]
    // 0x112ef58: DecompressPointer r1
    //     0x112ef58: add             x1, x1, HEAP, lsl #32
    // 0x112ef5c: mov             x0, x1
    // 0x112ef60: LeaveFrame
    //     0x112ef60: mov             SP, fp
    //     0x112ef64: ldp             fp, lr, [SP], #0x10
    // 0x112ef68: ret
    //     0x112ef68: ret             
    // 0x112ef6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112ef6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112ef70: b               #0x112ef44
  }
}

// class id: 5206, size: 0x28, field offset: 0x24
//   const constructor, 
class _BottomAppBarDefaultsM2 extends BottomAppBarThemeData {
}

// class id: 5479, size: 0x1c, field offset: 0x14
class _BottomAppBarState extends State<dynamic> {

  late ValueListenable<ScaffoldGeometry> geometryListenable; // offset: 0x14

  _ build(/* No info */) {
    // ** addr: 0xdea998, size: 0x46c
    // 0xdea998: EnterFrame
    //     0xdea998: stp             fp, lr, [SP, #-0x10]!
    //     0xdea99c: mov             fp, SP
    // 0xdea9a0: AllocStack(0x50)
    //     0xdea9a0: sub             SP, SP, #0x50
    // 0xdea9a4: SetupParameters(_BottomAppBarState this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xdea9a4: mov             x0, x2
    //     0xdea9a8: stur            x2, [fp, #-0x10]
    //     0xdea9ac: mov             x2, x1
    //     0xdea9b0: stur            x1, [fp, #-8]
    // 0xdea9b4: CheckStackOverflow
    //     0xdea9b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdea9b8: cmp             SP, x16
    //     0xdea9bc: b.ls            #0xdeade8
    // 0xdea9c0: mov             x1, x0
    // 0xdea9c4: r0 = of()
    //     0xdea9c4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdea9c8: LoadField: r2 = r0->field_2f
    //     0xdea9c8: ldur            w2, [x0, #0x2f]
    // 0xdea9cc: DecompressPointer r2
    //     0xdea9cc: add             x2, x2, HEAP, lsl #32
    // 0xdea9d0: ldur            x1, [fp, #-0x10]
    // 0xdea9d4: stur            x2, [fp, #-0x18]
    // 0xdea9d8: r0 = of()
    //     0xdea9d8: bl              #0xdeae60  ; [package:flutter/src/material/bottom_app_bar_theme.dart] BottomAppBarTheme::of
    // 0xdea9dc: mov             x1, x0
    // 0xdea9e0: ldur            x0, [fp, #-0x18]
    // 0xdea9e4: stur            x1, [fp, #-0x20]
    // 0xdea9e8: tbnz            w0, #4, #0xdeaa38
    // 0xdea9ec: ldur            x2, [fp, #-0x10]
    // 0xdea9f0: r0 = _BottomAppBarDefaultsM3()
    //     0xdea9f0: bl              #0xdeae54  ; Allocate_BottomAppBarDefaultsM3Stub -> _BottomAppBarDefaultsM3 (size=0x2c)
    // 0xdea9f4: mov             x1, x0
    // 0xdea9f8: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xdea9fc: StoreField: r1->field_27 = r0
    //     0xdea9fc: stur            w0, [x1, #0x27]
    // 0xdeaa00: ldur            x0, [fp, #-0x10]
    // 0xdeaa04: StoreField: r1->field_23 = r0
    //     0xdeaa04: stur            w0, [x1, #0x23]
    // 0xdeaa08: r2 = 3.000000
    //     0xdeaa08: add             x2, PP, #0x22, lsl #12  ; [pp+0x223f8] 3
    //     0xdeaa0c: ldr             x2, [x2, #0x3f8]
    // 0xdeaa10: StoreField: r1->field_b = r2
    //     0xdeaa10: stur            w2, [x1, #0xb]
    // 0xdeaa14: r2 = Instance_AutomaticNotchedShape
    //     0xdeaa14: add             x2, PP, #0x95, lsl #12  ; [pp+0x95e70] Obj!AutomaticNotchedShape@129c6a1
    //     0xdeaa18: ldr             x2, [x2, #0xe70]
    // 0xdeaa1c: StoreField: r1->field_f = r2
    //     0xdeaa1c: stur            w2, [x1, #0xf]
    // 0xdeaa20: r3 = 80.000000
    //     0xdeaa20: add             x3, PP, #0x7c, lsl #12  ; [pp+0x7c1b8] 80
    //     0xdeaa24: ldr             x3, [x3, #0x1b8]
    // 0xdeaa28: StoreField: r1->field_13 = r3
    //     0xdeaa28: stur            w3, [x1, #0x13]
    // 0xdeaa2c: mov             x4, x1
    // 0xdeaa30: d0 = 3.000000
    //     0xdeaa30: fmov            d0, #3.00000000
    // 0xdeaa34: b               #0xdeaa68
    // 0xdeaa38: ldur            x0, [fp, #-0x10]
    // 0xdeaa3c: r2 = Instance_AutomaticNotchedShape
    //     0xdeaa3c: add             x2, PP, #0x95, lsl #12  ; [pp+0x95e70] Obj!AutomaticNotchedShape@129c6a1
    //     0xdeaa40: ldr             x2, [x2, #0xe70]
    // 0xdeaa44: r0 = _BottomAppBarDefaultsM2()
    //     0xdeaa44: bl              #0xdeae48  ; Allocate_BottomAppBarDefaultsM2Stub -> _BottomAppBarDefaultsM2 (size=0x28)
    // 0xdeaa48: mov             x1, x0
    // 0xdeaa4c: ldur            x0, [fp, #-0x10]
    // 0xdeaa50: StoreField: r1->field_23 = r0
    //     0xdeaa50: stur            w0, [x1, #0x23]
    // 0xdeaa54: r2 = 8.000000
    //     0xdeaa54: add             x2, PP, #0x19, lsl #12  ; [pp+0x19e08] 8
    //     0xdeaa58: ldr             x2, [x2, #0xe08]
    // 0xdeaa5c: StoreField: r1->field_b = r2
    //     0xdeaa5c: stur            w2, [x1, #0xb]
    // 0xdeaa60: mov             x4, x1
    // 0xdeaa64: d0 = 8.000000
    //     0xdeaa64: fmov            d0, #8.00000000
    // 0xdeaa68: ldur            x3, [fp, #-8]
    // 0xdeaa6c: ldur            x2, [fp, #-0x20]
    // 0xdeaa70: mov             x1, x0
    // 0xdeaa74: stur            x4, [fp, #-0x28]
    // 0xdeaa78: stur            d0, [fp, #-0x50]
    // 0xdeaa7c: r0 = of()
    //     0xdeaa7c: bl              #0xb35cb4  ; [package:flutter/src/material/scaffold.dart] Scaffold::of
    // 0xdeaa80: mov             x1, x0
    // 0xdeaa84: r0 = hasFloatingActionButton()
    //     0xdeaa84: bl              #0xdeae10  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::hasFloatingActionButton
    // 0xdeaa88: mov             x1, x0
    // 0xdeaa8c: ldur            x0, [fp, #-8]
    // 0xdeaa90: LoadField: r2 = r0->field_b
    //     0xdeaa90: ldur            w2, [x0, #0xb]
    // 0xdeaa94: DecompressPointer r2
    //     0xdeaa94: add             x2, x2, HEAP, lsl #32
    // 0xdeaa98: cmp             w2, NULL
    // 0xdeaa9c: b.eq            #0xdeadf0
    // 0xdeaaa0: ldur            x2, [fp, #-0x20]
    // 0xdeaaa4: LoadField: r3 = r2->field_f
    //     0xdeaaa4: ldur            w3, [x2, #0xf]
    // 0xdeaaa8: DecompressPointer r3
    //     0xdeaaa8: add             x3, x3, HEAP, lsl #32
    // 0xdeaaac: cmp             w3, NULL
    // 0xdeaab0: b.ne            #0xdeaacc
    // 0xdeaab4: ldur            x3, [fp, #-0x28]
    // 0xdeaab8: LoadField: r4 = r3->field_f
    //     0xdeaab8: ldur            w4, [x3, #0xf]
    // 0xdeaabc: DecompressPointer r4
    //     0xdeaabc: add             x4, x4, HEAP, lsl #32
    // 0xdeaac0: cmp             w4, NULL
    // 0xdeaac4: b.eq            #0xdeab38
    // 0xdeaac8: b               #0xdeaad0
    // 0xdeaacc: ldur            x3, [fp, #-0x28]
    // 0xdeaad0: tbnz            w1, #4, #0xdeab38
    // 0xdeaad4: LoadField: r4 = r0->field_13
    //     0xdeaad4: ldur            w4, [x0, #0x13]
    // 0xdeaad8: DecompressPointer r4
    //     0xdeaad8: add             x4, x4, HEAP, lsl #32
    // 0xdeaadc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdeaae0: cmp             w4, w16
    // 0xdeaae4: b.eq            #0xdeadf4
    // 0xdeaae8: stur            x4, [fp, #-0x38]
    // 0xdeaaec: ArrayLoad: r5 = r0[0]  ; List_4
    //     0xdeaaec: ldur            w5, [x0, #0x17]
    // 0xdeaaf0: DecompressPointer r5
    //     0xdeaaf0: add             x5, x5, HEAP, lsl #32
    // 0xdeaaf4: stur            x5, [fp, #-0x30]
    // 0xdeaaf8: r1 = <Path>
    //     0xdeaaf8: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a60] TypeArguments: <Path>
    //     0xdeaafc: ldr             x1, [x1, #0xa60]
    // 0xdeab00: r0 = _BottomAppBarClipper()
    //     0xdeab00: bl              #0xdeae04  ; Allocate_BottomAppBarClipperStub -> _BottomAppBarClipper (size=0x24)
    // 0xdeab04: mov             x1, x0
    // 0xdeab08: ldur            x0, [fp, #-0x38]
    // 0xdeab0c: StoreField: r1->field_f = r0
    //     0xdeab0c: stur            w0, [x1, #0xf]
    // 0xdeab10: r2 = Instance_AutomaticNotchedShape
    //     0xdeab10: add             x2, PP, #0x95, lsl #12  ; [pp+0x95e70] Obj!AutomaticNotchedShape@129c6a1
    //     0xdeab14: ldr             x2, [x2, #0xe70]
    // 0xdeab18: StoreField: r1->field_13 = r2
    //     0xdeab18: stur            w2, [x1, #0x13]
    // 0xdeab1c: ldur            x2, [fp, #-0x30]
    // 0xdeab20: ArrayStore: r1[0] = r2  ; List_4
    //     0xdeab20: stur            w2, [x1, #0x17]
    // 0xdeab24: d0 = 4.000000
    //     0xdeab24: fmov            d0, #4.00000000
    // 0xdeab28: StoreField: r1->field_1b = d0
    //     0xdeab28: stur            d0, [x1, #0x1b]
    // 0xdeab2c: StoreField: r1->field_b = r0
    //     0xdeab2c: stur            w0, [x1, #0xb]
    // 0xdeab30: mov             x2, x1
    // 0xdeab34: b               #0xdeab40
    // 0xdeab38: r2 = Instance_ShapeBorderClipper
    //     0xdeab38: add             x2, PP, #0x95, lsl #12  ; [pp+0x95e78] Obj!ShapeBorderClipper@12aa391
    //     0xdeab3c: ldr             x2, [x2, #0xe78]
    // 0xdeab40: ldur            x0, [fp, #-0x20]
    // 0xdeab44: stur            x2, [fp, #-0x30]
    // 0xdeab48: LoadField: r1 = r0->field_b
    //     0xdeab48: ldur            w1, [x0, #0xb]
    // 0xdeab4c: DecompressPointer r1
    //     0xdeab4c: add             x1, x1, HEAP, lsl #32
    // 0xdeab50: cmp             w1, NULL
    // 0xdeab54: b.ne            #0xdeab60
    // 0xdeab58: ldur            d0, [fp, #-0x50]
    // 0xdeab5c: b               #0xdeab64
    // 0xdeab60: LoadField: d0 = r1->field_7
    //     0xdeab60: ldur            d0, [x1, #7]
    // 0xdeab64: stur            d0, [fp, #-0x50]
    // 0xdeab68: LoadField: r1 = r0->field_13
    //     0xdeab68: ldur            w1, [x0, #0x13]
    // 0xdeab6c: DecompressPointer r1
    //     0xdeab6c: add             x1, x1, HEAP, lsl #32
    // 0xdeab70: cmp             w1, NULL
    // 0xdeab74: b.ne            #0xdeab8c
    // 0xdeab78: ldur            x0, [fp, #-0x28]
    // 0xdeab7c: LoadField: r1 = r0->field_13
    //     0xdeab7c: ldur            w1, [x0, #0x13]
    // 0xdeab80: DecompressPointer r1
    //     0xdeab80: add             x1, x1, HEAP, lsl #32
    // 0xdeab84: mov             x3, x1
    // 0xdeab88: b               #0xdeab94
    // 0xdeab8c: ldur            x0, [fp, #-0x28]
    // 0xdeab90: mov             x3, x1
    // 0xdeab94: stur            x3, [fp, #-0x20]
    // 0xdeab98: r4 = LoadClassIdInstr(r0)
    //     0xdeab98: ldur            x4, [x0, #-1]
    //     0xdeab9c: ubfx            x4, x4, #0xc, #0x14
    // 0xdeaba0: stur            x4, [fp, #-0x40]
    // 0xdeaba4: r17 = 5204
    //     0xdeaba4: mov             x17, #0x1454
    // 0xdeaba8: cmp             x4, x17
    // 0xdeabac: b.ne            #0xdeabc0
    // 0xdeabb0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdeabb0: ldur            w1, [x0, #0x17]
    // 0xdeabb4: DecompressPointer r1
    //     0xdeabb4: add             x1, x1, HEAP, lsl #32
    // 0xdeabb8: mov             x2, x1
    // 0xdeabbc: b               #0xdeac08
    // 0xdeabc0: r17 = 5205
    //     0xdeabc0: mov             x17, #0x1455
    // 0xdeabc4: cmp             x4, x17
    // 0xdeabc8: b.ne            #0xdeabd8
    // 0xdeabcc: r2 = Instance_Color
    //     0xdeabcc: add             x2, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdeabd0: ldr             x2, [x2, #0x810]
    // 0xdeabd4: b               #0xdeac08
    // 0xdeabd8: LoadField: r1 = r0->field_23
    //     0xdeabd8: ldur            w1, [x0, #0x23]
    // 0xdeabdc: DecompressPointer r1
    //     0xdeabdc: add             x1, x1, HEAP, lsl #32
    // 0xdeabe0: r0 = of()
    //     0xdeabe0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdeabe4: LoadField: r1 = r0->field_3f
    //     0xdeabe4: ldur            w1, [x0, #0x3f]
    // 0xdeabe8: DecompressPointer r1
    //     0xdeabe8: add             x1, x1, HEAP, lsl #32
    // 0xdeabec: LoadField: r0 = r1->field_c3
    //     0xdeabec: ldur            w0, [x1, #0xc3]
    // 0xdeabf0: DecompressPointer r0
    //     0xdeabf0: add             x0, x0, HEAP, lsl #32
    // 0xdeabf4: cmp             w0, NULL
    // 0xdeabf8: b.ne            #0xdeac04
    // 0xdeabfc: LoadField: r0 = r1->field_b
    //     0xdeabfc: ldur            w0, [x1, #0xb]
    // 0xdeac00: DecompressPointer r0
    //     0xdeac00: add             x0, x0, HEAP, lsl #32
    // 0xdeac04: mov             x2, x0
    // 0xdeac08: ldur            x0, [fp, #-0x18]
    // 0xdeac0c: tbnz            w0, #4, #0xdeac28
    // 0xdeac10: ldur            d0, [fp, #-0x50]
    // 0xdeac14: r1 = Instance_Color
    //     0xdeac14: add             x1, PP, #0x83, lsl #12  ; [pp+0x83790] Obj!Color@12a2eb1
    //     0xdeac18: ldr             x1, [x1, #0x790]
    // 0xdeac1c: r0 = applySurfaceTint()
    //     0xdeac1c: bl              #0xd2e910  ; [package:flutter/src/material/elevation_overlay.dart] ElevationOverlay::applySurfaceTint
    // 0xdeac20: mov             x2, x0
    // 0xdeac24: b               #0xdeac40
    // 0xdeac28: ldur            x1, [fp, #-0x10]
    // 0xdeac2c: ldur            d0, [fp, #-0x50]
    // 0xdeac30: r2 = Instance_Color
    //     0xdeac30: add             x2, PP, #0x83, lsl #12  ; [pp+0x83790] Obj!Color@12a2eb1
    //     0xdeac34: ldr             x2, [x2, #0x790]
    // 0xdeac38: r0 = applyOverlay()
    //     0xdeac38: bl              #0xd2e708  ; [package:flutter/src/material/elevation_overlay.dart] ElevationOverlay::applyOverlay
    // 0xdeac3c: mov             x2, x0
    // 0xdeac40: ldur            x1, [fp, #-8]
    // 0xdeac44: ldur            x0, [fp, #-0x40]
    // 0xdeac48: stur            x2, [fp, #-0x38]
    // 0xdeac4c: LoadField: r3 = r1->field_b
    //     0xdeac4c: ldur            w3, [x1, #0xb]
    // 0xdeac50: DecompressPointer r3
    //     0xdeac50: add             x3, x3, HEAP, lsl #32
    // 0xdeac54: cmp             w3, NULL
    // 0xdeac58: b.eq            #0xdeae00
    // 0xdeac5c: r17 = 5204
    //     0xdeac5c: mov             x17, #0x1454
    // 0xdeac60: cmp             x0, x17
    // 0xdeac64: b.ne            #0xdeac78
    // 0xdeac68: ldur            x0, [fp, #-0x28]
    // 0xdeac6c: LoadField: r4 = r0->field_1b
    //     0xdeac6c: ldur            w4, [x0, #0x1b]
    // 0xdeac70: DecompressPointer r4
    //     0xdeac70: add             x4, x4, HEAP, lsl #32
    // 0xdeac74: b               #0xdeac98
    // 0xdeac78: r17 = 5205
    //     0xdeac78: mov             x17, #0x1455
    // 0xdeac7c: cmp             x0, x17
    // 0xdeac80: b.ne            #0xdeac90
    // 0xdeac84: r4 = Instance_Color
    //     0xdeac84: add             x4, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdeac88: ldr             x4, [x4, #0x810]
    // 0xdeac8c: b               #0xdeac98
    // 0xdeac90: r4 = Instance_Color
    //     0xdeac90: add             x4, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0xdeac94: ldr             x4, [x4, #0x948]
    // 0xdeac98: ldur            x0, [fp, #-0x18]
    // 0xdeac9c: stur            x4, [fp, #-0x28]
    // 0xdeaca0: tbnz            w0, #4, #0xdeacb0
    // 0xdeaca4: r6 = Instance_EdgeInsets
    //     0xdeaca4: add             x6, PP, #0x7d, lsl #12  ; [pp+0x7d1a0] Obj!EdgeInsets@129d561
    //     0xdeaca8: ldr             x6, [x6, #0x1a0]
    // 0xdeacac: b               #0xdeacb4
    // 0xdeacb0: r6 = Instance_EdgeInsets
    //     0xdeacb0: ldr             x6, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xdeacb4: ldur            x0, [fp, #-0x30]
    // 0xdeacb8: ldur            d0, [fp, #-0x50]
    // 0xdeacbc: ldur            x5, [fp, #-0x20]
    // 0xdeacc0: stur            x6, [fp, #-0x18]
    // 0xdeacc4: LoadField: r7 = r3->field_b
    //     0xdeacc4: ldur            w7, [x3, #0xb]
    // 0xdeacc8: DecompressPointer r7
    //     0xdeacc8: add             x7, x7, HEAP, lsl #32
    // 0xdeaccc: stur            x7, [fp, #-0x10]
    // 0xdeacd0: r0 = Padding()
    //     0xdeacd0: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xdeacd4: mov             x1, x0
    // 0xdeacd8: ldur            x0, [fp, #-0x18]
    // 0xdeacdc: stur            x1, [fp, #-0x48]
    // 0xdeace0: StoreField: r1->field_f = r0
    //     0xdeace0: stur            w0, [x1, #0xf]
    // 0xdeace4: ldur            x0, [fp, #-0x10]
    // 0xdeace8: StoreField: r1->field_b = r0
    //     0xdeace8: stur            w0, [x1, #0xb]
    // 0xdeacec: r0 = SizedBox()
    //     0xdeacec: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xdeacf0: mov             x1, x0
    // 0xdeacf4: ldur            x0, [fp, #-0x20]
    // 0xdeacf8: stur            x1, [fp, #-0x18]
    // 0xdeacfc: StoreField: r1->field_13 = r0
    //     0xdeacfc: stur            w0, [x1, #0x13]
    // 0xdead00: ldur            x0, [fp, #-0x48]
    // 0xdead04: StoreField: r1->field_b = r0
    //     0xdead04: stur            w0, [x1, #0xb]
    // 0xdead08: ldur            x0, [fp, #-8]
    // 0xdead0c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xdead0c: ldur            w2, [x0, #0x17]
    // 0xdead10: DecompressPointer r2
    //     0xdead10: add             x2, x2, HEAP, lsl #32
    // 0xdead14: stur            x2, [fp, #-0x10]
    // 0xdead18: r0 = SafeArea()
    //     0xdead18: bl              #0xd73100  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0xdead1c: mov             x1, x0
    // 0xdead20: r0 = true
    //     0xdead20: add             x0, NULL, #0x20  ; true
    // 0xdead24: stur            x1, [fp, #-8]
    // 0xdead28: StoreField: r1->field_b = r0
    //     0xdead28: stur            w0, [x1, #0xb]
    // 0xdead2c: StoreField: r1->field_f = r0
    //     0xdead2c: stur            w0, [x1, #0xf]
    // 0xdead30: StoreField: r1->field_13 = r0
    //     0xdead30: stur            w0, [x1, #0x13]
    // 0xdead34: ArrayStore: r1[0] = r0  ; List_4
    //     0xdead34: stur            w0, [x1, #0x17]
    // 0xdead38: r2 = Instance_EdgeInsets
    //     0xdead38: ldr             x2, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xdead3c: StoreField: r1->field_1b = r2
    //     0xdead3c: stur            w2, [x1, #0x1b]
    // 0xdead40: r2 = false
    //     0xdead40: add             x2, NULL, #0x30  ; false
    // 0xdead44: StoreField: r1->field_1f = r2
    //     0xdead44: stur            w2, [x1, #0x1f]
    // 0xdead48: ldur            x3, [fp, #-0x18]
    // 0xdead4c: StoreField: r1->field_23 = r3
    //     0xdead4c: stur            w3, [x1, #0x23]
    // 0xdead50: r0 = Material()
    //     0xdead50: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xdead54: mov             x1, x0
    // 0xdead58: r0 = Instance_MaterialType
    //     0xdead58: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8c618] Obj!MaterialType@12c5361
    //     0xdead5c: ldr             x0, [x0, #0x618]
    // 0xdead60: stur            x1, [fp, #-0x18]
    // 0xdead64: StoreField: r1->field_f = r0
    //     0xdead64: stur            w0, [x1, #0xf]
    // 0xdead68: ArrayStore: r1[0] = rZR  ; List_8
    //     0xdead68: stur            xzr, [x1, #0x17]
    // 0xdead6c: r0 = true
    //     0xdead6c: add             x0, NULL, #0x20  ; true
    // 0xdead70: StoreField: r1->field_33 = r0
    //     0xdead70: stur            w0, [x1, #0x33]
    // 0xdead74: r0 = Instance_Clip
    //     0xdead74: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdead78: ldr             x0, [x0, #0x840]
    // 0xdead7c: StoreField: r1->field_37 = r0
    //     0xdead7c: stur            w0, [x1, #0x37]
    // 0xdead80: r2 = Instance_Duration
    //     0xdead80: add             x2, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xdead84: ldr             x2, [x2, #0x318]
    // 0xdead88: StoreField: r1->field_3b = r2
    //     0xdead88: stur            w2, [x1, #0x3b]
    // 0xdead8c: ldur            x2, [fp, #-8]
    // 0xdead90: StoreField: r1->field_b = r2
    //     0xdead90: stur            w2, [x1, #0xb]
    // 0xdead94: r2 = false
    //     0xdead94: add             x2, NULL, #0x30  ; false
    // 0xdead98: StoreField: r1->field_13 = r2
    //     0xdead98: stur            w2, [x1, #0x13]
    // 0xdead9c: ldur            x2, [fp, #-0x10]
    // 0xdeada0: StoreField: r1->field_7 = r2
    //     0xdeada0: stur            w2, [x1, #7]
    // 0xdeada4: r0 = PhysicalShape()
    //     0xdeada4: bl              #0xd2ee40  ; AllocatePhysicalShapeStub -> PhysicalShape (size=0x28)
    // 0xdeada8: ldur            x1, [fp, #-0x30]
    // 0xdeadac: StoreField: r0->field_f = r1
    //     0xdeadac: stur            w1, [x0, #0xf]
    // 0xdeadb0: r1 = Instance_Clip
    //     0xdeadb0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdeadb4: ldr             x1, [x1, #0x840]
    // 0xdeadb8: StoreField: r0->field_13 = r1
    //     0xdeadb8: stur            w1, [x0, #0x13]
    // 0xdeadbc: ldur            d0, [fp, #-0x50]
    // 0xdeadc0: ArrayStore: r0[0] = d0  ; List_8
    //     0xdeadc0: stur            d0, [x0, #0x17]
    // 0xdeadc4: ldur            x1, [fp, #-0x38]
    // 0xdeadc8: StoreField: r0->field_1f = r1
    //     0xdeadc8: stur            w1, [x0, #0x1f]
    // 0xdeadcc: ldur            x1, [fp, #-0x28]
    // 0xdeadd0: StoreField: r0->field_23 = r1
    //     0xdeadd0: stur            w1, [x0, #0x23]
    // 0xdeadd4: ldur            x1, [fp, #-0x18]
    // 0xdeadd8: StoreField: r0->field_b = r1
    //     0xdeadd8: stur            w1, [x0, #0xb]
    // 0xdeaddc: LeaveFrame
    //     0xdeaddc: mov             SP, fp
    //     0xdeade0: ldp             fp, lr, [SP], #0x10
    // 0xdeade4: ret
    //     0xdeade4: ret             
    // 0xdeade8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdeade8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdeadec: b               #0xdea9c0
    // 0xdeadf0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeadf0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdeadf4: r9 = geometryListenable
    //     0xdeadf4: add             x9, PP, #0x95, lsl #12  ; [pp+0x95e80] Field <_BottomAppBarState@723408488.geometryListenable>: late (offset: 0x14)
    //     0xdeadf8: ldr             x9, [x9, #0xe80]
    // 0xdeadfc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdeadfc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdeae00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeae00: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xef3ecc, size: 0x70
    // 0xef3ecc: EnterFrame
    //     0xef3ecc: stp             fp, lr, [SP, #-0x10]!
    //     0xef3ed0: mov             fp, SP
    // 0xef3ed4: AllocStack(0x8)
    //     0xef3ed4: sub             SP, SP, #8
    // 0xef3ed8: SetupParameters(_BottomAppBarState this /* r1 => r0, fp-0x8 */)
    //     0xef3ed8: mov             x0, x1
    //     0xef3edc: stur            x1, [fp, #-8]
    // 0xef3ee0: CheckStackOverflow
    //     0xef3ee0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef3ee4: cmp             SP, x16
    //     0xef3ee8: b.ls            #0xef3f30
    // 0xef3eec: LoadField: r1 = r0->field_f
    //     0xef3eec: ldur            w1, [x0, #0xf]
    // 0xef3ef0: DecompressPointer r1
    //     0xef3ef0: add             x1, x1, HEAP, lsl #32
    // 0xef3ef4: cmp             w1, NULL
    // 0xef3ef8: b.eq            #0xef3f38
    // 0xef3efc: r0 = geometryOf()
    //     0xef3efc: bl              #0xef3f3c  ; [package:flutter/src/material/scaffold.dart] Scaffold::geometryOf
    // 0xef3f00: ldur            x1, [fp, #-8]
    // 0xef3f04: StoreField: r1->field_13 = r0
    //     0xef3f04: stur            w0, [x1, #0x13]
    //     0xef3f08: ldurb           w16, [x1, #-1]
    //     0xef3f0c: ldurb           w17, [x0, #-1]
    //     0xef3f10: and             x16, x17, x16, lsr #2
    //     0xef3f14: tst             x16, HEAP, lsr #32
    //     0xef3f18: b.eq            #0xef3f20
    //     0xef3f1c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef3f20: r0 = Null
    //     0xef3f20: mov             x0, NULL
    // 0xef3f24: LeaveFrame
    //     0xef3f24: mov             SP, fp
    //     0xef3f28: ldp             fp, lr, [SP], #0x10
    // 0xef3f2c: ret
    //     0xef3f2c: ret             
    // 0xef3f30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef3f30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef3f34: b               #0xef3eec
    // 0xef3f38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef3f38: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6503, size: 0x38, field offset: 0xc
//   const constructor, 
class BottomAppBar extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa0a90, size: 0x4c
    // 0xfa0a90: EnterFrame
    //     0xfa0a90: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0a94: mov             fp, SP
    // 0xfa0a98: AllocStack(0x8)
    //     0xfa0a98: sub             SP, SP, #8
    // 0xfa0a9c: SetupParameters(BottomAppBar this /* r1 => r0 */)
    //     0xfa0a9c: mov             x0, x1
    // 0xfa0aa0: r1 = <BottomAppBar>
    //     0xfa0aa0: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c9d0] TypeArguments: <BottomAppBar>
    //     0xfa0aa4: ldr             x1, [x1, #0x9d0]
    // 0xfa0aa8: r0 = _BottomAppBarState()
    //     0xfa0aa8: bl              #0xfa0adc  ; Allocate_BottomAppBarStateStub -> _BottomAppBarState (size=0x1c)
    // 0xfa0aac: mov             x2, x0
    // 0xfa0ab0: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa0ab4: stur            x2, [fp, #-8]
    // 0xfa0ab8: StoreField: r2->field_13 = r0
    //     0xfa0ab8: stur            w0, [x2, #0x13]
    // 0xfa0abc: r1 = <State<StatefulWidget>>
    //     0xfa0abc: ldr             x1, [PP, #0x4df8]  ; [pp+0x4df8] TypeArguments: <State<StatefulWidget>>
    // 0xfa0ac0: r0 = LabeledGlobalKey()
    //     0xfa0ac0: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa0ac4: mov             x1, x0
    // 0xfa0ac8: ldur            x0, [fp, #-8]
    // 0xfa0acc: ArrayStore: r0[0] = r1  ; List_4
    //     0xfa0acc: stur            w1, [x0, #0x17]
    // 0xfa0ad0: LeaveFrame
    //     0xfa0ad0: mov             SP, fp
    //     0xfa0ad4: ldp             fp, lr, [SP], #0x10
    // 0xfa0ad8: ret
    //     0xfa0ad8: ret             
  }
}
