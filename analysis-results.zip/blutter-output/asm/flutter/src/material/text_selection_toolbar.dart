// lib: , url: package:flutter/src/material/text_selection_toolbar.dart

// class id: 1048965, size: 0x8
class :: {
}

// class id: 4841, size: 0x74, field offset: 0x60
class _RenderTextSelectionToolbarItemsLayout extends _MixinApplication118&RenderBox&ContainerRenderObjectMixin {

  _ performLayout(/* No info */) {
    // ** addr: 0xbc5388, size: 0x104
    // 0xbc5388: EnterFrame
    //     0xbc5388: stp             fp, lr, [SP, #-0x10]!
    //     0xbc538c: mov             fp, SP
    // 0xbc5390: AllocStack(0x10)
    //     0xbc5390: sub             SP, SP, #0x10
    // 0xbc5394: r0 = -1
    //     0xbc5394: mov             x0, #-1
    // 0xbc5398: mov             x3, x1
    // 0xbc539c: stur            x1, [fp, #-0x10]
    // 0xbc53a0: CheckStackOverflow
    //     0xbc53a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc53a4: cmp             SP, x16
    //     0xbc53a8: b.ls            #0xbc5484
    // 0xbc53ac: StoreField: r3->field_5f = r0
    //     0xbc53ac: stur            x0, [x3, #0x5f]
    // 0xbc53b0: LoadField: r0 = r3->field_57
    //     0xbc53b0: ldur            w0, [x3, #0x57]
    // 0xbc53b4: DecompressPointer r0
    //     0xbc53b4: add             x0, x0, HEAP, lsl #32
    // 0xbc53b8: cmp             w0, NULL
    // 0xbc53bc: b.ne            #0xbc543c
    // 0xbc53c0: LoadField: r4 = r3->field_27
    //     0xbc53c0: ldur            w4, [x3, #0x27]
    // 0xbc53c4: DecompressPointer r4
    //     0xbc53c4: add             x4, x4, HEAP, lsl #32
    // 0xbc53c8: stur            x4, [fp, #-8]
    // 0xbc53cc: cmp             w4, NULL
    // 0xbc53d0: b.eq            #0xbc5468
    // 0xbc53d4: mov             x0, x4
    // 0xbc53d8: r2 = Null
    //     0xbc53d8: mov             x2, NULL
    // 0xbc53dc: r1 = Null
    //     0xbc53dc: mov             x1, NULL
    // 0xbc53e0: r4 = LoadClassIdInstr(r0)
    //     0xbc53e0: ldur            x4, [x0, #-1]
    //     0xbc53e4: ubfx            x4, x4, #0xc, #0x14
    // 0xbc53e8: sub             x4, x4, #0xb46
    // 0xbc53ec: cmp             x4, #1
    // 0xbc53f0: b.ls            #0xbc5404
    // 0xbc53f4: r8 = BoxConstraints
    //     0xbc53f4: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbc53f8: r3 = Null
    //     0xbc53f8: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcce00] Null
    //     0xbc53fc: ldr             x3, [x3, #0xe00]
    // 0xbc5400: r0 = BoxConstraints()
    //     0xbc5400: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbc5404: ldur            x1, [fp, #-8]
    // 0xbc5408: r0 = smallest()
    //     0xbc5408: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xbc540c: ldur            x2, [fp, #-0x10]
    // 0xbc5410: StoreField: r2->field_4b = r0
    //     0xbc5410: stur            w0, [x2, #0x4b]
    //     0xbc5414: ldurb           w16, [x2, #-1]
    //     0xbc5418: ldurb           w17, [x0, #-1]
    //     0xbc541c: and             x16, x17, x16, lsr #2
    //     0xbc5420: tst             x16, HEAP, lsr #32
    //     0xbc5424: b.eq            #0xbc542c
    //     0xbc5428: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbc542c: r0 = Null
    //     0xbc542c: mov             x0, NULL
    // 0xbc5430: LeaveFrame
    //     0xbc5430: mov             SP, fp
    //     0xbc5434: ldp             fp, lr, [SP], #0x10
    // 0xbc5438: ret
    //     0xbc5438: ret             
    // 0xbc543c: mov             x2, x3
    // 0xbc5440: mov             x1, x2
    // 0xbc5444: r0 = _layoutChildren()
    //     0xbc5444: bl              #0xbc6734  ; [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::_layoutChildren
    // 0xbc5448: ldur            x1, [fp, #-0x10]
    // 0xbc544c: r0 = _placeChildren()
    //     0xbc544c: bl              #0xbc576c  ; [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::_placeChildren
    // 0xbc5450: ldur            x1, [fp, #-0x10]
    // 0xbc5454: r0 = _resizeChildrenWhenOverflow()
    //     0xbc5454: bl              #0xbc548c  ; [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::_resizeChildrenWhenOverflow
    // 0xbc5458: r0 = Null
    //     0xbc5458: mov             x0, NULL
    // 0xbc545c: LeaveFrame
    //     0xbc545c: mov             SP, fp
    //     0xbc5460: ldp             fp, lr, [SP], #0x10
    // 0xbc5464: ret
    //     0xbc5464: ret             
    // 0xbc5468: r0 = StateError()
    //     0xbc5468: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc546c: mov             x1, x0
    // 0xbc5470: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbc5470: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbc5474: StoreField: r1->field_b = r0
    //     0xbc5474: stur            w0, [x1, #0xb]
    // 0xbc5478: mov             x0, x1
    // 0xbc547c: r0 = Throw()
    //     0xbc547c: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc5480: brk             #0
    // 0xbc5484: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc5484: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc5488: b               #0xbc53ac
  }
  _ _resizeChildrenWhenOverflow(/* No info */) {
    // ** addr: 0xbc548c, size: 0xa0
    // 0xbc548c: EnterFrame
    //     0xbc548c: stp             fp, lr, [SP, #-0x10]!
    //     0xbc5490: mov             fp, SP
    // 0xbc5494: AllocStack(0x8)
    //     0xbc5494: sub             SP, SP, #8
    // 0xbc5498: SetupParameters(_RenderTextSelectionToolbarItemsLayout this /* r1 => r1, fp-0x8 */)
    //     0xbc5498: stur            x1, [fp, #-8]
    // 0xbc549c: CheckStackOverflow
    //     0xbc549c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc54a0: cmp             SP, x16
    //     0xbc54a4: b.ls            #0xbc5520
    // 0xbc54a8: r1 = 3
    //     0xbc54a8: mov             x1, #3
    // 0xbc54ac: r0 = AllocateContext()
    //     0xbc54ac: bl              #0x13de838  ; AllocateContextStub
    // 0xbc54b0: mov             x1, x0
    // 0xbc54b4: ldur            x0, [fp, #-8]
    // 0xbc54b8: StoreField: r1->field_f = r0
    //     0xbc54b8: stur            w0, [x1, #0xf]
    // 0xbc54bc: LoadField: r2 = r0->field_6b
    //     0xbc54bc: ldur            w2, [x0, #0x6b]
    // 0xbc54c0: DecompressPointer r2
    //     0xbc54c0: add             x2, x2, HEAP, lsl #32
    // 0xbc54c4: tbz             w2, #4, #0xbc54d8
    // 0xbc54c8: r0 = Null
    //     0xbc54c8: mov             x0, NULL
    // 0xbc54cc: LeaveFrame
    //     0xbc54cc: mov             SP, fp
    //     0xbc54d0: ldp             fp, lr, [SP], #0x10
    // 0xbc54d4: ret
    //     0xbc54d4: ret             
    // 0xbc54d8: r2 = -2
    //     0xbc54d8: mov             x2, #-2
    // 0xbc54dc: LoadField: r3 = r0->field_57
    //     0xbc54dc: ldur            w3, [x0, #0x57]
    // 0xbc54e0: DecompressPointer r3
    //     0xbc54e0: add             x3, x3, HEAP, lsl #32
    // 0xbc54e4: cmp             w3, NULL
    // 0xbc54e8: b.eq            #0xbc5528
    // 0xbc54ec: StoreField: r1->field_13 = r3
    //     0xbc54ec: stur            w3, [x1, #0x13]
    // 0xbc54f0: ArrayStore: r1[0] = r2  ; List_4
    //     0xbc54f0: stur            w2, [x1, #0x17]
    // 0xbc54f4: mov             x2, x1
    // 0xbc54f8: r1 = Function '<anonymous closure>':.
    //     0xbc54f8: add             x1, PP, #0xcc, lsl #12  ; [pp+0xcce10] AnonymousClosure: (0xbc552c), in [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::_resizeChildrenWhenOverflow (0xbc548c)
    //     0xbc54fc: ldr             x1, [x1, #0xe10]
    // 0xbc5500: r0 = AllocateClosure()
    //     0xbc5500: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbc5504: ldur            x1, [fp, #-8]
    // 0xbc5508: mov             x2, x0
    // 0xbc550c: r0 = visitChildren()
    //     0xbc550c: bl              #0xbeef74  ; [dart:mixin_deduplication] _MixinApplication118&RenderBox&ContainerRenderObjectMixin::visitChildren
    // 0xbc5510: r0 = Null
    //     0xbc5510: mov             x0, NULL
    // 0xbc5514: LeaveFrame
    //     0xbc5514: mov             SP, fp
    //     0xbc5518: ldp             fp, lr, [SP], #0x10
    // 0xbc551c: ret
    //     0xbc551c: ret             
    // 0xbc5520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc5520: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc5524: b               #0xbc54a8
    // 0xbc5528: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc5528: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0xbc552c, size: 0x1d8
    // 0xbc552c: EnterFrame
    //     0xbc552c: stp             fp, lr, [SP, #-0x10]!
    //     0xbc5530: mov             fp, SP
    // 0xbc5534: AllocStack(0x20)
    //     0xbc5534: sub             SP, SP, #0x20
    // 0xbc5538: SetupParameters([dynamic _ /* r0 */])
    //     0xbc5538: ldr             x0, [fp, #0x18]
    //     0xbc553c: ldur            w3, [x0, #0x17]
    //     0xbc5540: add             x3, x3, HEAP, lsl #32
    //     0xbc5544: stur            x3, [fp, #-8]
    // 0xbc5548: CheckStackOverflow
    //     0xbc5548: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc554c: cmp             SP, x16
    //     0xbc5550: b.ls            #0xbc56f8
    // 0xbc5554: ldr             x0, [fp, #0x10]
    // 0xbc5558: r2 = Null
    //     0xbc5558: mov             x2, NULL
    // 0xbc555c: r1 = Null
    //     0xbc555c: mov             x1, NULL
    // 0xbc5560: r4 = LoadClassIdInstr(r0)
    //     0xbc5560: ldur            x4, [x0, #-1]
    //     0xbc5564: ubfx            x4, x4, #0xc, #0x14
    // 0xbc5568: r17 = -4710
    //     0xbc5568: mov             x17, #-0x1266
    // 0xbc556c: add             x4, x4, x17
    // 0xbc5570: cmp             x4, #0x109
    // 0xbc5574: b.ls            #0xbc5588
    // 0xbc5578: r8 = RenderBox
    //     0xbc5578: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbc557c: r3 = Null
    //     0xbc557c: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcce18] Null
    //     0xbc5580: ldr             x3, [x3, #0xe18]
    // 0xbc5584: r0 = RenderBox()
    //     0xbc5584: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbc5588: ldr             x3, [fp, #0x10]
    // 0xbc558c: LoadField: r4 = r3->field_7
    //     0xbc558c: ldur            w4, [x3, #7]
    // 0xbc5590: DecompressPointer r4
    //     0xbc5590: add             x4, x4, HEAP, lsl #32
    // 0xbc5594: stur            x4, [fp, #-0x10]
    // 0xbc5598: cmp             w4, NULL
    // 0xbc559c: b.eq            #0xbc5700
    // 0xbc55a0: mov             x0, x4
    // 0xbc55a4: r2 = Null
    //     0xbc55a4: mov             x2, NULL
    // 0xbc55a8: r1 = Null
    //     0xbc55a8: mov             x1, NULL
    // 0xbc55ac: r4 = LoadClassIdInstr(r0)
    //     0xbc55ac: ldur            x4, [x0, #-1]
    //     0xbc55b0: ubfx            x4, x4, #0xc, #0x14
    // 0xbc55b4: r17 = 4205
    //     0xbc55b4: mov             x17, #0x106d
    // 0xbc55b8: cmp             x4, x17
    // 0xbc55bc: b.eq            #0xbc55d4
    // 0xbc55c0: r8 = ToolbarItemsParentData
    //     0xbc55c0: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0xbc55c4: ldr             x8, [x8, #0x6c0]
    // 0xbc55c8: r3 = Null
    //     0xbc55c8: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcce28] Null
    //     0xbc55cc: ldr             x3, [x3, #0xe28]
    // 0xbc55d0: r0 = DefaultTypeTest()
    //     0xbc55d0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbc55d4: ldur            x4, [fp, #-8]
    // 0xbc55d8: ArrayLoad: r0 = r4[0]  ; List_4
    //     0xbc55d8: ldur            w0, [x4, #0x17]
    // 0xbc55dc: DecompressPointer r0
    //     0xbc55dc: add             x0, x0, HEAP, lsl #32
    // 0xbc55e0: r1 = LoadInt32Instr(r0)
    //     0xbc55e0: sbfx            x1, x0, #1, #0x1f
    //     0xbc55e4: tbz             w0, #0, #0xbc55ec
    //     0xbc55e8: ldur            x1, [x0, #7]
    // 0xbc55ec: add             x3, x1, #1
    // 0xbc55f0: r0 = BoxInt64Instr(r3)
    //     0xbc55f0: sbfiz           x0, x3, #1, #0x1f
    //     0xbc55f4: cmp             x3, x0, asr #1
    //     0xbc55f8: b.eq            #0xbc5604
    //     0xbc55fc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbc5600: stur            x3, [x0, #7]
    // 0xbc5604: ArrayStore: r4[0] = r0  ; List_4
    //     0xbc5604: stur            w0, [x4, #0x17]
    //     0xbc5608: tbz             w0, #0, #0xbc5624
    //     0xbc560c: ldurb           w16, [x4, #-1]
    //     0xbc5610: ldurb           w17, [x0, #-1]
    //     0xbc5614: and             x16, x17, x16, lsr #2
    //     0xbc5618: tst             x16, HEAP, lsr #32
    //     0xbc561c: b.eq            #0xbc5624
    //     0xbc5620: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xbc5624: LoadField: r0 = r4->field_13
    //     0xbc5624: ldur            w0, [x4, #0x13]
    // 0xbc5628: DecompressPointer r0
    //     0xbc5628: add             x0, x0, HEAP, lsl #32
    // 0xbc562c: ldr             x5, [fp, #0x10]
    // 0xbc5630: cmp             w5, w0
    // 0xbc5634: b.ne            #0xbc5648
    // 0xbc5638: r0 = Null
    //     0xbc5638: mov             x0, NULL
    // 0xbc563c: LeaveFrame
    //     0xbc563c: mov             SP, fp
    //     0xbc5640: ldp             fp, lr, [SP], #0x10
    // 0xbc5644: ret
    //     0xbc5644: ret             
    // 0xbc5648: LoadField: r1 = r4->field_f
    //     0xbc5648: ldur            w1, [x4, #0xf]
    // 0xbc564c: DecompressPointer r1
    //     0xbc564c: add             x1, x1, HEAP, lsl #32
    // 0xbc5650: mov             x2, x5
    // 0xbc5654: r0 = _shouldPaintChild()
    //     0xbc5654: bl              #0xbc5704  ; [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::_shouldPaintChild
    // 0xbc5658: tbz             w0, #4, #0xbc5678
    // 0xbc565c: ldur            x0, [fp, #-0x10]
    // 0xbc5660: r1 = false
    //     0xbc5660: add             x1, NULL, #0x30  ; false
    // 0xbc5664: ArrayStore: r0[0] = r1  ; List_4
    //     0xbc5664: stur            w1, [x0, #0x17]
    // 0xbc5668: r0 = Null
    //     0xbc5668: mov             x0, NULL
    // 0xbc566c: LeaveFrame
    //     0xbc566c: mov             SP, fp
    //     0xbc5670: ldp             fp, lr, [SP], #0x10
    // 0xbc5674: ret
    //     0xbc5674: ret             
    // 0xbc5678: ldr             x2, [fp, #0x10]
    // 0xbc567c: ldur            x0, [fp, #-8]
    // 0xbc5680: LoadField: r1 = r0->field_f
    //     0xbc5680: ldur            w1, [x0, #0xf]
    // 0xbc5684: DecompressPointer r1
    //     0xbc5684: add             x1, x1, HEAP, lsl #32
    // 0xbc5688: r0 = size()
    //     0xbc5688: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc568c: LoadField: d0 = r0->field_7
    //     0xbc568c: ldur            d0, [x0, #7]
    // 0xbc5690: stur            d0, [fp, #-0x18]
    // 0xbc5694: r0 = BoxConstraints()
    //     0xbc5694: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbc5698: ldur            d0, [fp, #-0x18]
    // 0xbc569c: StoreField: r0->field_7 = d0
    //     0xbc569c: stur            d0, [x0, #7]
    // 0xbc56a0: StoreField: r0->field_f = d0
    //     0xbc56a0: stur            d0, [x0, #0xf]
    // 0xbc56a4: ArrayStore: r0[0] = rZR  ; List_8
    //     0xbc56a4: stur            xzr, [x0, #0x17]
    // 0xbc56a8: d0 = inf
    //     0xbc56a8: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xbc56ac: StoreField: r0->field_1f = d0
    //     0xbc56ac: stur            d0, [x0, #0x1f]
    // 0xbc56b0: ldr             x1, [fp, #0x10]
    // 0xbc56b4: r2 = LoadClassIdInstr(r1)
    //     0xbc56b4: ldur            x2, [x1, #-1]
    //     0xbc56b8: ubfx            x2, x2, #0xc, #0x14
    // 0xbc56bc: r16 = true
    //     0xbc56bc: add             x16, NULL, #0x20  ; true
    // 0xbc56c0: str             x16, [SP]
    // 0xbc56c4: mov             x16, x0
    // 0xbc56c8: mov             x0, x2
    // 0xbc56cc: mov             x2, x16
    // 0xbc56d0: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbc56d0: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbc56d4: ldr             x4, [x4, #0xed0]
    // 0xbc56d8: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbc56d8: mov             x17, #0xe6b9
    //     0xbc56dc: add             lr, x0, x17
    //     0xbc56e0: ldr             lr, [x21, lr, lsl #3]
    //     0xbc56e4: blr             lr
    // 0xbc56e8: r0 = Null
    //     0xbc56e8: mov             x0, NULL
    // 0xbc56ec: LeaveFrame
    //     0xbc56ec: mov             SP, fp
    //     0xbc56f0: ldp             fp, lr, [SP], #0x10
    // 0xbc56f4: ret
    //     0xbc56f4: ret             
    // 0xbc56f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc56f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc56fc: b               #0xbc5554
    // 0xbc5700: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc5700: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _shouldPaintChild(/* No info */) {
    // ** addr: 0xbc5704, size: 0x68
    // 0xbc5704: LoadField: r4 = r1->field_57
    //     0xbc5704: ldur            w4, [x1, #0x57]
    // 0xbc5708: DecompressPointer r4
    //     0xbc5708: add             x4, x4, HEAP, lsl #32
    // 0xbc570c: cmp             w2, w4
    // 0xbc5710: b.ne            #0xbc572c
    // 0xbc5714: LoadField: r2 = r1->field_5f
    //     0xbc5714: ldur            x2, [x1, #0x5f]
    // 0xbc5718: cmn             x2, #1
    // 0xbc571c: r16 = true
    //     0xbc571c: add             x16, NULL, #0x20  ; true
    // 0xbc5720: r17 = false
    //     0xbc5720: add             x17, NULL, #0x30  ; false
    // 0xbc5724: csel            x0, x16, x17, ne
    // 0xbc5728: ret
    //     0xbc5728: ret             
    // 0xbc572c: LoadField: r2 = r1->field_5f
    //     0xbc572c: ldur            x2, [x1, #0x5f]
    // 0xbc5730: cmn             x2, #1
    // 0xbc5734: b.ne            #0xbc5740
    // 0xbc5738: r0 = true
    //     0xbc5738: add             x0, NULL, #0x20  ; true
    // 0xbc573c: ret
    //     0xbc573c: ret             
    // 0xbc5740: cmp             x3, x2
    // 0xbc5744: r16 = true
    //     0xbc5744: add             x16, NULL, #0x20  ; true
    // 0xbc5748: r17 = false
    //     0xbc5748: add             x17, NULL, #0x30  ; false
    // 0xbc574c: csel            x4, x16, x17, gt
    // 0xbc5750: LoadField: r2 = r1->field_6b
    //     0xbc5750: ldur            w2, [x1, #0x6b]
    // 0xbc5754: DecompressPointer r2
    //     0xbc5754: add             x2, x2, HEAP, lsl #32
    // 0xbc5758: cmp             w4, w2
    // 0xbc575c: r16 = true
    //     0xbc575c: add             x16, NULL, #0x20  ; true
    // 0xbc5760: r17 = false
    //     0xbc5760: add             x17, NULL, #0x30  ; false
    // 0xbc5764: csel            x0, x16, x17, eq
    // 0xbc5768: ret
    //     0xbc5768: ret             
  }
  _ _placeChildren(/* No info */) {
    // ** addr: 0xbc576c, size: 0x78
    // 0xbc576c: EnterFrame
    //     0xbc576c: stp             fp, lr, [SP, #-0x10]!
    //     0xbc5770: mov             fp, SP
    // 0xbc5774: AllocStack(0x8)
    //     0xbc5774: sub             SP, SP, #8
    // 0xbc5778: SetupParameters(_RenderTextSelectionToolbarItemsLayout this /* r1 => r0, fp-0x8 */)
    //     0xbc5778: mov             x0, x1
    //     0xbc577c: stur            x1, [fp, #-8]
    // 0xbc5780: CheckStackOverflow
    //     0xbc5780: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc5784: cmp             SP, x16
    //     0xbc5788: b.ls            #0xbc57dc
    // 0xbc578c: LoadField: r1 = r0->field_6b
    //     0xbc578c: ldur            w1, [x0, #0x6b]
    // 0xbc5790: DecompressPointer r1
    //     0xbc5790: add             x1, x1, HEAP, lsl #32
    // 0xbc5794: tbnz            w1, #4, #0xbc57a4
    // 0xbc5798: mov             x1, x0
    // 0xbc579c: r0 = _placeChildrenVertically()
    //     0xbc579c: bl              #0xbc60ac  ; [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::_placeChildrenVertically
    // 0xbc57a0: b               #0xbc57ac
    // 0xbc57a4: ldur            x1, [fp, #-8]
    // 0xbc57a8: r0 = _placeChildrenHorizontally()
    //     0xbc57a8: bl              #0xbc57e4  ; [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::_placeChildrenHorizontally
    // 0xbc57ac: ldur            x1, [fp, #-8]
    // 0xbc57b0: StoreField: r1->field_4b = r0
    //     0xbc57b0: stur            w0, [x1, #0x4b]
    //     0xbc57b4: ldurb           w16, [x1, #-1]
    //     0xbc57b8: ldurb           w17, [x0, #-1]
    //     0xbc57bc: and             x16, x17, x16, lsr #2
    //     0xbc57c0: tst             x16, HEAP, lsr #32
    //     0xbc57c4: b.eq            #0xbc57cc
    //     0xbc57c8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc57cc: r0 = Null
    //     0xbc57cc: mov             x0, NULL
    // 0xbc57d0: LeaveFrame
    //     0xbc57d0: mov             SP, fp
    //     0xbc57d4: ldp             fp, lr, [SP], #0x10
    // 0xbc57d8: ret
    //     0xbc57d8: ret             
    // 0xbc57dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc57dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc57e0: b               #0xbc578c
  }
  _ _placeChildrenHorizontally(/* No info */) {
    // ** addr: 0xbc57e4, size: 0x5b0
    // 0xbc57e4: EnterFrame
    //     0xbc57e4: stp             fp, lr, [SP, #-0x10]!
    //     0xbc57e8: mov             fp, SP
    // 0xbc57ec: AllocStack(0x60)
    //     0xbc57ec: sub             SP, SP, #0x60
    // 0xbc57f0: SetupParameters(_RenderTextSelectionToolbarItemsLayout this /* r1 => r1, fp-0x8 */)
    //     0xbc57f0: stur            x1, [fp, #-8]
    // 0xbc57f4: CheckStackOverflow
    //     0xbc57f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc57f8: cmp             SP, x16
    //     0xbc57fc: b.ls            #0xbc5d68
    // 0xbc5800: r1 = 6
    //     0xbc5800: mov             x1, #6
    // 0xbc5804: r0 = AllocateContext()
    //     0xbc5804: bl              #0x13de838  ; AllocateContextStub
    // 0xbc5808: mov             x3, x0
    // 0xbc580c: ldur            x0, [fp, #-8]
    // 0xbc5810: stur            x3, [fp, #-0x20]
    // 0xbc5814: StoreField: r3->field_f = r0
    //     0xbc5814: stur            w0, [x3, #0xf]
    // 0xbc5818: LoadField: r4 = r0->field_57
    //     0xbc5818: ldur            w4, [x0, #0x57]
    // 0xbc581c: DecompressPointer r4
    //     0xbc581c: add             x4, x4, HEAP, lsl #32
    // 0xbc5820: stur            x4, [fp, #-0x18]
    // 0xbc5824: cmp             w4, NULL
    // 0xbc5828: b.eq            #0xbc5d70
    // 0xbc582c: StoreField: r3->field_13 = r4
    //     0xbc582c: stur            w4, [x3, #0x13]
    // 0xbc5830: LoadField: r5 = r0->field_6f
    //     0xbc5830: ldur            w5, [x0, #0x6f]
    // 0xbc5834: DecompressPointer r5
    //     0xbc5834: add             x5, x5, HEAP, lsl #32
    // 0xbc5838: stur            x5, [fp, #-0x10]
    // 0xbc583c: r1 = <RenderBox>
    //     0xbc583c: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c8] TypeArguments: <RenderBox>
    //     0xbc5840: ldr             x1, [x1, #0x5c8]
    // 0xbc5844: r2 = 0
    //     0xbc5844: mov             x2, #0
    // 0xbc5848: r0 = _GrowableList()
    //     0xbc5848: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xbc584c: mov             x4, x0
    // 0xbc5850: ldur            x3, [fp, #-0x20]
    // 0xbc5854: stur            x4, [fp, #-0x28]
    // 0xbc5858: ArrayStore: r3[0] = r0  ; List_4
    //     0xbc5858: stur            w0, [x3, #0x17]
    //     0xbc585c: ldurb           w16, [x3, #-1]
    //     0xbc5860: ldurb           w17, [x0, #-1]
    //     0xbc5864: and             x16, x17, x16, lsr #2
    //     0xbc5868: tst             x16, HEAP, lsr #32
    //     0xbc586c: b.eq            #0xbc5874
    //     0xbc5870: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbc5874: r0 = 0.000000
    //     0xbc5874: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbc5878: StoreField: r3->field_1b = r0
    //     0xbc5878: stur            w0, [x3, #0x1b]
    // 0xbc587c: StoreField: r3->field_1f = r0
    //     0xbc587c: stur            w0, [x3, #0x1f]
    // 0xbc5880: r0 = -2
    //     0xbc5880: mov             x0, #-2
    // 0xbc5884: StoreField: r3->field_23 = r0
    //     0xbc5884: stur            w0, [x3, #0x23]
    // 0xbc5888: mov             x2, x3
    // 0xbc588c: r1 = Function '<anonymous closure>':.
    //     0xbc588c: add             x1, PP, #0xcc, lsl #12  ; [pp+0xcce38] AnonymousClosure: (0xbc5d94), in [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::_placeChildrenHorizontally (0xbc57e4)
    //     0xbc5890: ldr             x1, [x1, #0xe38]
    // 0xbc5894: r0 = AllocateClosure()
    //     0xbc5894: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbc5898: ldur            x1, [fp, #-8]
    // 0xbc589c: mov             x2, x0
    // 0xbc58a0: r0 = visitChildren()
    //     0xbc58a0: bl              #0xbeef74  ; [dart:mixin_deduplication] _MixinApplication118&RenderBox&ContainerRenderObjectMixin::visitChildren
    // 0xbc58a4: ldur            x0, [fp, #-8]
    // 0xbc58a8: LoadField: r1 = r0->field_5f
    //     0xbc58a8: ldur            x1, [x0, #0x5f]
    // 0xbc58ac: tbz             x1, #0x3f, #0xbc58b8
    // 0xbc58b0: r3 = false
    //     0xbc58b0: add             x3, NULL, #0x30  ; false
    // 0xbc58b4: b               #0xbc58bc
    // 0xbc58b8: r3 = true
    //     0xbc58b8: add             x3, NULL, #0x20  ; true
    // 0xbc58bc: ldur            x0, [fp, #-0x10]
    // 0xbc58c0: stur            x3, [fp, #-0x48]
    // 0xbc58c4: r16 = Instance_TextDirection
    //     0xbc58c4: ldr             x16, [PP, #0x2578]  ; [pp+0x2578] Obj!TextDirection@12c7381
    // 0xbc58c8: cmp             w0, w16
    // 0xbc58cc: b.ne            #0xbc5a38
    // 0xbc58d0: tbnz            w3, #4, #0xbc5934
    // 0xbc58d4: ldur            x3, [fp, #-0x18]
    // 0xbc58d8: LoadField: r4 = r3->field_7
    //     0xbc58d8: ldur            w4, [x3, #7]
    // 0xbc58dc: DecompressPointer r4
    //     0xbc58dc: add             x4, x4, HEAP, lsl #32
    // 0xbc58e0: stur            x4, [fp, #-8]
    // 0xbc58e4: cmp             w4, NULL
    // 0xbc58e8: b.eq            #0xbc5d74
    // 0xbc58ec: mov             x0, x4
    // 0xbc58f0: r2 = Null
    //     0xbc58f0: mov             x2, NULL
    // 0xbc58f4: r1 = Null
    //     0xbc58f4: mov             x1, NULL
    // 0xbc58f8: r4 = LoadClassIdInstr(r0)
    //     0xbc58f8: ldur            x4, [x0, #-1]
    //     0xbc58fc: ubfx            x4, x4, #0xc, #0x14
    // 0xbc5900: r17 = 4205
    //     0xbc5900: mov             x17, #0x106d
    // 0xbc5904: cmp             x4, x17
    // 0xbc5908: b.eq            #0xbc5920
    // 0xbc590c: r8 = ToolbarItemsParentData
    //     0xbc590c: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0xbc5910: ldr             x8, [x8, #0x6c0]
    // 0xbc5914: r3 = Null
    //     0xbc5914: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcce40] Null
    //     0xbc5918: ldr             x3, [x3, #0xe40]
    // 0xbc591c: r0 = DefaultTypeTest()
    //     0xbc591c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbc5920: ldur            x1, [fp, #-8]
    // 0xbc5924: r0 = Instance_Offset
    //     0xbc5924: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xbc5928: StoreField: r1->field_7 = r0
    //     0xbc5928: stur            w0, [x1, #7]
    // 0xbc592c: ldur            x1, [fp, #-0x18]
    // 0xbc5930: r0 = size()
    //     0xbc5930: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc5934: ldur            x3, [fp, #-0x20]
    // 0xbc5938: ldur            x0, [fp, #-0x28]
    // 0xbc593c: LoadField: r1 = r3->field_1b
    //     0xbc593c: ldur            w1, [x3, #0x1b]
    // 0xbc5940: DecompressPointer r1
    //     0xbc5940: add             x1, x1, HEAP, lsl #32
    // 0xbc5944: LoadField: r2 = r0->field_b
    //     0xbc5944: ldur            w2, [x0, #0xb]
    // 0xbc5948: r4 = LoadInt32Instr(r2)
    //     0xbc5948: sbfx            x4, x2, #1, #0x1f
    // 0xbc594c: stur            x4, [fp, #-0x38]
    // 0xbc5950: LoadField: d0 = r1->field_7
    //     0xbc5950: ldur            d0, [x1, #7]
    // 0xbc5954: LoadField: r5 = r0->field_f
    //     0xbc5954: ldur            w5, [x0, #0xf]
    // 0xbc5958: DecompressPointer r5
    //     0xbc5958: add             x5, x5, HEAP, lsl #32
    // 0xbc595c: stur            x5, [fp, #-0x10]
    // 0xbc5960: r0 = 0
    //     0xbc5960: mov             x0, #0
    // 0xbc5964: CheckStackOverflow
    //     0xbc5964: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc5968: cmp             SP, x16
    //     0xbc596c: b.ls            #0xbc5d78
    // 0xbc5970: cmp             x0, x4
    // 0xbc5974: b.ge            #0xbc5bbc
    // 0xbc5978: ArrayLoad: r6 = r5[r0]  ; Unknown_4
    //     0xbc5978: add             x16, x5, x0, lsl #2
    //     0xbc597c: ldur            w6, [x16, #0xf]
    // 0xbc5980: DecompressPointer r6
    //     0xbc5980: add             x6, x6, HEAP, lsl #32
    // 0xbc5984: stur            x6, [fp, #-0x50]
    // 0xbc5988: add             x7, x0, #1
    // 0xbc598c: stur            x7, [fp, #-0x30]
    // 0xbc5990: LoadField: r0 = r6->field_4b
    //     0xbc5990: ldur            w0, [x6, #0x4b]
    // 0xbc5994: DecompressPointer r0
    //     0xbc5994: add             x0, x0, HEAP, lsl #32
    // 0xbc5998: cmp             w0, NULL
    // 0xbc599c: b.eq            #0xbc5c00
    // 0xbc59a0: LoadField: d1 = r0->field_7
    //     0xbc59a0: ldur            d1, [x0, #7]
    // 0xbc59a4: fsub            d2, d0, d1
    // 0xbc59a8: stur            d2, [fp, #-0x58]
    // 0xbc59ac: LoadField: r8 = r6->field_7
    //     0xbc59ac: ldur            w8, [x6, #7]
    // 0xbc59b0: DecompressPointer r8
    //     0xbc59b0: add             x8, x8, HEAP, lsl #32
    // 0xbc59b4: stur            x8, [fp, #-8]
    // 0xbc59b8: cmp             w8, NULL
    // 0xbc59bc: b.eq            #0xbc5d80
    // 0xbc59c0: mov             x0, x8
    // 0xbc59c4: r2 = Null
    //     0xbc59c4: mov             x2, NULL
    // 0xbc59c8: r1 = Null
    //     0xbc59c8: mov             x1, NULL
    // 0xbc59cc: r4 = LoadClassIdInstr(r0)
    //     0xbc59cc: ldur            x4, [x0, #-1]
    //     0xbc59d0: ubfx            x4, x4, #0xc, #0x14
    // 0xbc59d4: r17 = 4205
    //     0xbc59d4: mov             x17, #0x106d
    // 0xbc59d8: cmp             x4, x17
    // 0xbc59dc: b.eq            #0xbc59f4
    // 0xbc59e0: r8 = ToolbarItemsParentData
    //     0xbc59e0: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0xbc59e4: ldr             x8, [x8, #0x6c0]
    // 0xbc59e8: r3 = Null
    //     0xbc59e8: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcce50] Null
    //     0xbc59ec: ldr             x3, [x3, #0xe50]
    // 0xbc59f0: r0 = DefaultTypeTest()
    //     0xbc59f0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbc59f4: r0 = Offset()
    //     0xbc59f4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbc59f8: ldur            d0, [fp, #-0x58]
    // 0xbc59fc: StoreField: r0->field_7 = d0
    //     0xbc59fc: stur            d0, [x0, #7]
    // 0xbc5a00: StoreField: r0->field_f = rZR
    //     0xbc5a00: stur            xzr, [x0, #0xf]
    // 0xbc5a04: ldur            x1, [fp, #-8]
    // 0xbc5a08: StoreField: r1->field_7 = r0
    //     0xbc5a08: stur            w0, [x1, #7]
    //     0xbc5a0c: ldurb           w16, [x1, #-1]
    //     0xbc5a10: ldurb           w17, [x0, #-1]
    //     0xbc5a14: and             x16, x17, x16, lsr #2
    //     0xbc5a18: tst             x16, HEAP, lsr #32
    //     0xbc5a1c: b.eq            #0xbc5a24
    //     0xbc5a20: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc5a24: ldur            x0, [fp, #-0x30]
    // 0xbc5a28: ldur            x3, [fp, #-0x20]
    // 0xbc5a2c: ldur            x5, [fp, #-0x10]
    // 0xbc5a30: ldur            x4, [fp, #-0x38]
    // 0xbc5a34: b               #0xbc5964
    // 0xbc5a38: ldur            x0, [fp, #-0x28]
    // 0xbc5a3c: LoadField: r1 = r0->field_b
    //     0xbc5a3c: ldur            w1, [x0, #0xb]
    // 0xbc5a40: r4 = LoadInt32Instr(r1)
    //     0xbc5a40: sbfx            x4, x1, #1, #0x1f
    // 0xbc5a44: stur            x4, [fp, #-0x38]
    // 0xbc5a48: LoadField: r5 = r0->field_f
    //     0xbc5a48: ldur            w5, [x0, #0xf]
    // 0xbc5a4c: DecompressPointer r5
    //     0xbc5a4c: add             x5, x5, HEAP, lsl #32
    // 0xbc5a50: stur            x5, [fp, #-0x40]
    // 0xbc5a54: d0 = 0.000000
    //     0xbc5a54: eor             v0.16b, v0.16b, v0.16b
    // 0xbc5a58: r0 = 0
    //     0xbc5a58: mov             x0, #0
    // 0xbc5a5c: stur            d0, [fp, #-0x58]
    // 0xbc5a60: CheckStackOverflow
    //     0xbc5a60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc5a64: cmp             SP, x16
    //     0xbc5a68: b.ls            #0xbc5d84
    // 0xbc5a6c: cmp             x0, x4
    // 0xbc5a70: b.ge            #0xbc5b38
    // 0xbc5a74: ArrayLoad: r6 = r5[r0]  ; Unknown_4
    //     0xbc5a74: add             x16, x5, x0, lsl #2
    //     0xbc5a78: ldur            w6, [x16, #0xf]
    // 0xbc5a7c: DecompressPointer r6
    //     0xbc5a7c: add             x6, x6, HEAP, lsl #32
    // 0xbc5a80: stur            x6, [fp, #-0x10]
    // 0xbc5a84: add             x7, x0, #1
    // 0xbc5a88: stur            x7, [fp, #-0x30]
    // 0xbc5a8c: LoadField: r8 = r6->field_7
    //     0xbc5a8c: ldur            w8, [x6, #7]
    // 0xbc5a90: DecompressPointer r8
    //     0xbc5a90: add             x8, x8, HEAP, lsl #32
    // 0xbc5a94: stur            x8, [fp, #-8]
    // 0xbc5a98: cmp             w8, NULL
    // 0xbc5a9c: b.eq            #0xbc5d8c
    // 0xbc5aa0: mov             x0, x8
    // 0xbc5aa4: r2 = Null
    //     0xbc5aa4: mov             x2, NULL
    // 0xbc5aa8: r1 = Null
    //     0xbc5aa8: mov             x1, NULL
    // 0xbc5aac: r4 = LoadClassIdInstr(r0)
    //     0xbc5aac: ldur            x4, [x0, #-1]
    //     0xbc5ab0: ubfx            x4, x4, #0xc, #0x14
    // 0xbc5ab4: r17 = 4205
    //     0xbc5ab4: mov             x17, #0x106d
    // 0xbc5ab8: cmp             x4, x17
    // 0xbc5abc: b.eq            #0xbc5ad4
    // 0xbc5ac0: r8 = ToolbarItemsParentData
    //     0xbc5ac0: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0xbc5ac4: ldr             x8, [x8, #0x6c0]
    // 0xbc5ac8: r3 = Null
    //     0xbc5ac8: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcce60] Null
    //     0xbc5acc: ldr             x3, [x3, #0xe60]
    // 0xbc5ad0: r0 = DefaultTypeTest()
    //     0xbc5ad0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbc5ad4: r0 = Offset()
    //     0xbc5ad4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbc5ad8: ldur            d0, [fp, #-0x58]
    // 0xbc5adc: StoreField: r0->field_7 = d0
    //     0xbc5adc: stur            d0, [x0, #7]
    // 0xbc5ae0: StoreField: r0->field_f = rZR
    //     0xbc5ae0: stur            xzr, [x0, #0xf]
    // 0xbc5ae4: ldur            x1, [fp, #-8]
    // 0xbc5ae8: StoreField: r1->field_7 = r0
    //     0xbc5ae8: stur            w0, [x1, #7]
    //     0xbc5aec: ldurb           w16, [x1, #-1]
    //     0xbc5af0: ldurb           w17, [x0, #-1]
    //     0xbc5af4: and             x16, x17, x16, lsr #2
    //     0xbc5af8: tst             x16, HEAP, lsr #32
    //     0xbc5afc: b.eq            #0xbc5b04
    //     0xbc5b00: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc5b04: ldur            x0, [fp, #-0x10]
    // 0xbc5b08: LoadField: r1 = r0->field_4b
    //     0xbc5b08: ldur            w1, [x0, #0x4b]
    // 0xbc5b0c: DecompressPointer r1
    //     0xbc5b0c: add             x1, x1, HEAP, lsl #32
    // 0xbc5b10: cmp             w1, NULL
    // 0xbc5b14: b.eq            #0xbc5cb4
    // 0xbc5b18: LoadField: d1 = r1->field_7
    //     0xbc5b18: ldur            d1, [x1, #7]
    // 0xbc5b1c: fadd            d2, d0, d1
    // 0xbc5b20: mov             v0.16b, v2.16b
    // 0xbc5b24: ldur            x0, [fp, #-0x30]
    // 0xbc5b28: ldur            x3, [fp, #-0x48]
    // 0xbc5b2c: ldur            x5, [fp, #-0x40]
    // 0xbc5b30: ldur            x4, [fp, #-0x38]
    // 0xbc5b34: b               #0xbc5a5c
    // 0xbc5b38: mov             x0, x3
    // 0xbc5b3c: tbnz            w0, #4, #0xbc5bbc
    // 0xbc5b40: ldur            x0, [fp, #-0x18]
    // 0xbc5b44: LoadField: r3 = r0->field_7
    //     0xbc5b44: ldur            w3, [x0, #7]
    // 0xbc5b48: DecompressPointer r3
    //     0xbc5b48: add             x3, x3, HEAP, lsl #32
    // 0xbc5b4c: stur            x3, [fp, #-8]
    // 0xbc5b50: cmp             w3, NULL
    // 0xbc5b54: b.eq            #0xbc5d90
    // 0xbc5b58: mov             x0, x3
    // 0xbc5b5c: r2 = Null
    //     0xbc5b5c: mov             x2, NULL
    // 0xbc5b60: r1 = Null
    //     0xbc5b60: mov             x1, NULL
    // 0xbc5b64: r4 = LoadClassIdInstr(r0)
    //     0xbc5b64: ldur            x4, [x0, #-1]
    //     0xbc5b68: ubfx            x4, x4, #0xc, #0x14
    // 0xbc5b6c: r17 = 4205
    //     0xbc5b6c: mov             x17, #0x106d
    // 0xbc5b70: cmp             x4, x17
    // 0xbc5b74: b.eq            #0xbc5b8c
    // 0xbc5b78: r8 = ToolbarItemsParentData
    //     0xbc5b78: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0xbc5b7c: ldr             x8, [x8, #0x6c0]
    // 0xbc5b80: r3 = Null
    //     0xbc5b80: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcce70] Null
    //     0xbc5b84: ldr             x3, [x3, #0xe70]
    // 0xbc5b88: r0 = DefaultTypeTest()
    //     0xbc5b88: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbc5b8c: r0 = Offset()
    //     0xbc5b8c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbc5b90: ldur            d0, [fp, #-0x58]
    // 0xbc5b94: StoreField: r0->field_7 = d0
    //     0xbc5b94: stur            d0, [x0, #7]
    // 0xbc5b98: StoreField: r0->field_f = rZR
    //     0xbc5b98: stur            xzr, [x0, #0xf]
    // 0xbc5b9c: ldur            x1, [fp, #-8]
    // 0xbc5ba0: StoreField: r1->field_7 = r0
    //     0xbc5ba0: stur            w0, [x1, #7]
    //     0xbc5ba4: ldurb           w16, [x1, #-1]
    //     0xbc5ba8: ldurb           w17, [x0, #-1]
    //     0xbc5bac: and             x16, x17, x16, lsr #2
    //     0xbc5bb0: tst             x16, HEAP, lsr #32
    //     0xbc5bb4: b.eq            #0xbc5bbc
    //     0xbc5bb8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc5bbc: ldur            x0, [fp, #-0x20]
    // 0xbc5bc0: LoadField: r1 = r0->field_1b
    //     0xbc5bc0: ldur            w1, [x0, #0x1b]
    // 0xbc5bc4: DecompressPointer r1
    //     0xbc5bc4: add             x1, x1, HEAP, lsl #32
    // 0xbc5bc8: LoadField: r2 = r0->field_1f
    //     0xbc5bc8: ldur            w2, [x0, #0x1f]
    // 0xbc5bcc: DecompressPointer r2
    //     0xbc5bcc: add             x2, x2, HEAP, lsl #32
    // 0xbc5bd0: stur            x2, [fp, #-8]
    // 0xbc5bd4: LoadField: d0 = r1->field_7
    //     0xbc5bd4: ldur            d0, [x1, #7]
    // 0xbc5bd8: stur            d0, [fp, #-0x58]
    // 0xbc5bdc: r0 = Size()
    //     0xbc5bdc: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbc5be0: ldur            d0, [fp, #-0x58]
    // 0xbc5be4: StoreField: r0->field_7 = d0
    //     0xbc5be4: stur            d0, [x0, #7]
    // 0xbc5be8: ldur            x1, [fp, #-8]
    // 0xbc5bec: LoadField: d0 = r1->field_7
    //     0xbc5bec: ldur            d0, [x1, #7]
    // 0xbc5bf0: StoreField: r0->field_f = d0
    //     0xbc5bf0: stur            d0, [x0, #0xf]
    // 0xbc5bf4: LeaveFrame
    //     0xbc5bf4: mov             SP, fp
    //     0xbc5bf8: ldp             fp, lr, [SP], #0x10
    // 0xbc5bfc: ret
    //     0xbc5bfc: ret             
    // 0xbc5c00: r1 = Null
    //     0xbc5c00: mov             x1, NULL
    // 0xbc5c04: r2 = 8
    //     0xbc5c04: mov             x2, #8
    // 0xbc5c08: r0 = AllocateArray()
    //     0xbc5c08: bl              #0x13df928  ; AllocateArrayStub
    // 0xbc5c0c: stur            x0, [fp, #-8]
    // 0xbc5c10: r16 = "RenderBox was not laid out: "
    //     0xbc5c10: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xbc5c14: StoreField: r0->field_f = r16
    //     0xbc5c14: stur            w16, [x0, #0xf]
    // 0xbc5c18: ldur            x16, [fp, #-0x50]
    // 0xbc5c1c: str             x16, [SP]
    // 0xbc5c20: r0 = runtimeType()
    //     0xbc5c20: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xbc5c24: ldur            x1, [fp, #-8]
    // 0xbc5c28: ArrayStore: r1[1] = r0  ; List_4
    //     0xbc5c28: add             x25, x1, #0x13
    //     0xbc5c2c: str             w0, [x25]
    //     0xbc5c30: tbz             w0, #0, #0xbc5c4c
    //     0xbc5c34: ldurb           w16, [x1, #-1]
    //     0xbc5c38: ldurb           w17, [x0, #-1]
    //     0xbc5c3c: and             x16, x17, x16, lsr #2
    //     0xbc5c40: tst             x16, HEAP, lsr #32
    //     0xbc5c44: b.eq            #0xbc5c4c
    //     0xbc5c48: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbc5c4c: ldur            x0, [fp, #-8]
    // 0xbc5c50: r16 = "#"
    //     0xbc5c50: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xbc5c54: ArrayStore: r0[0] = r16  ; List_4
    //     0xbc5c54: stur            w16, [x0, #0x17]
    // 0xbc5c58: ldur            x1, [fp, #-0x50]
    // 0xbc5c5c: r0 = shortHash()
    //     0xbc5c5c: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xbc5c60: ldur            x1, [fp, #-8]
    // 0xbc5c64: ArrayStore: r1[3] = r0  ; List_4
    //     0xbc5c64: add             x25, x1, #0x1b
    //     0xbc5c68: str             w0, [x25]
    //     0xbc5c6c: tbz             w0, #0, #0xbc5c88
    //     0xbc5c70: ldurb           w16, [x1, #-1]
    //     0xbc5c74: ldurb           w17, [x0, #-1]
    //     0xbc5c78: and             x16, x17, x16, lsr #2
    //     0xbc5c7c: tst             x16, HEAP, lsr #32
    //     0xbc5c80: b.eq            #0xbc5c88
    //     0xbc5c84: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbc5c88: ldur            x16, [fp, #-8]
    // 0xbc5c8c: str             x16, [SP]
    // 0xbc5c90: r0 = _interpolate()
    //     0xbc5c90: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbc5c94: stur            x0, [fp, #-8]
    // 0xbc5c98: r0 = StateError()
    //     0xbc5c98: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc5c9c: mov             x1, x0
    // 0xbc5ca0: ldur            x0, [fp, #-8]
    // 0xbc5ca4: StoreField: r1->field_b = r0
    //     0xbc5ca4: stur            w0, [x1, #0xb]
    // 0xbc5ca8: mov             x0, x1
    // 0xbc5cac: r0 = Throw()
    //     0xbc5cac: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc5cb0: brk             #0
    // 0xbc5cb4: r1 = Null
    //     0xbc5cb4: mov             x1, NULL
    // 0xbc5cb8: r2 = 8
    //     0xbc5cb8: mov             x2, #8
    // 0xbc5cbc: r0 = AllocateArray()
    //     0xbc5cbc: bl              #0x13df928  ; AllocateArrayStub
    // 0xbc5cc0: stur            x0, [fp, #-8]
    // 0xbc5cc4: r16 = "RenderBox was not laid out: "
    //     0xbc5cc4: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xbc5cc8: StoreField: r0->field_f = r16
    //     0xbc5cc8: stur            w16, [x0, #0xf]
    // 0xbc5ccc: ldur            x16, [fp, #-0x10]
    // 0xbc5cd0: str             x16, [SP]
    // 0xbc5cd4: r0 = runtimeType()
    //     0xbc5cd4: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xbc5cd8: ldur            x1, [fp, #-8]
    // 0xbc5cdc: ArrayStore: r1[1] = r0  ; List_4
    //     0xbc5cdc: add             x25, x1, #0x13
    //     0xbc5ce0: str             w0, [x25]
    //     0xbc5ce4: tbz             w0, #0, #0xbc5d00
    //     0xbc5ce8: ldurb           w16, [x1, #-1]
    //     0xbc5cec: ldurb           w17, [x0, #-1]
    //     0xbc5cf0: and             x16, x17, x16, lsr #2
    //     0xbc5cf4: tst             x16, HEAP, lsr #32
    //     0xbc5cf8: b.eq            #0xbc5d00
    //     0xbc5cfc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbc5d00: ldur            x0, [fp, #-8]
    // 0xbc5d04: r16 = "#"
    //     0xbc5d04: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xbc5d08: ArrayStore: r0[0] = r16  ; List_4
    //     0xbc5d08: stur            w16, [x0, #0x17]
    // 0xbc5d0c: ldur            x1, [fp, #-0x10]
    // 0xbc5d10: r0 = shortHash()
    //     0xbc5d10: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xbc5d14: ldur            x1, [fp, #-8]
    // 0xbc5d18: ArrayStore: r1[3] = r0  ; List_4
    //     0xbc5d18: add             x25, x1, #0x1b
    //     0xbc5d1c: str             w0, [x25]
    //     0xbc5d20: tbz             w0, #0, #0xbc5d3c
    //     0xbc5d24: ldurb           w16, [x1, #-1]
    //     0xbc5d28: ldurb           w17, [x0, #-1]
    //     0xbc5d2c: and             x16, x17, x16, lsr #2
    //     0xbc5d30: tst             x16, HEAP, lsr #32
    //     0xbc5d34: b.eq            #0xbc5d3c
    //     0xbc5d38: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbc5d3c: ldur            x16, [fp, #-8]
    // 0xbc5d40: str             x16, [SP]
    // 0xbc5d44: r0 = _interpolate()
    //     0xbc5d44: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbc5d48: stur            x0, [fp, #-8]
    // 0xbc5d4c: r0 = StateError()
    //     0xbc5d4c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc5d50: mov             x1, x0
    // 0xbc5d54: ldur            x0, [fp, #-8]
    // 0xbc5d58: StoreField: r1->field_b = r0
    //     0xbc5d58: stur            w0, [x1, #0xb]
    // 0xbc5d5c: mov             x0, x1
    // 0xbc5d60: r0 = Throw()
    //     0xbc5d60: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc5d64: brk             #0
    // 0xbc5d68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc5d68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc5d6c: b               #0xbc5800
    // 0xbc5d70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc5d70: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc5d74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc5d74: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc5d78: r0 = StackOverflowSharedWithFPURegs()
    //     0xbc5d78: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbc5d7c: b               #0xbc5970
    // 0xbc5d80: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc5d80: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbc5d84: r0 = StackOverflowSharedWithFPURegs()
    //     0xbc5d84: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbc5d88: b               #0xbc5a6c
    // 0xbc5d8c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc5d8c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbc5d90: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc5d90: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0xbc5d94, size: 0x318
    // 0xbc5d94: EnterFrame
    //     0xbc5d94: stp             fp, lr, [SP, #-0x10]!
    //     0xbc5d98: mov             fp, SP
    // 0xbc5d9c: AllocStack(0x18)
    //     0xbc5d9c: sub             SP, SP, #0x18
    // 0xbc5da0: SetupParameters([dynamic _ /* r0 */])
    //     0xbc5da0: ldr             x0, [fp, #0x18]
    //     0xbc5da4: ldur            w3, [x0, #0x17]
    //     0xbc5da8: add             x3, x3, HEAP, lsl #32
    //     0xbc5dac: stur            x3, [fp, #-8]
    // 0xbc5db0: CheckStackOverflow
    //     0xbc5db0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc5db4: cmp             SP, x16
    //     0xbc5db8: b.ls            #0xbc6080
    // 0xbc5dbc: ldr             x0, [fp, #0x10]
    // 0xbc5dc0: r2 = Null
    //     0xbc5dc0: mov             x2, NULL
    // 0xbc5dc4: r1 = Null
    //     0xbc5dc4: mov             x1, NULL
    // 0xbc5dc8: r4 = LoadClassIdInstr(r0)
    //     0xbc5dc8: ldur            x4, [x0, #-1]
    //     0xbc5dcc: ubfx            x4, x4, #0xc, #0x14
    // 0xbc5dd0: r17 = -4710
    //     0xbc5dd0: mov             x17, #-0x1266
    // 0xbc5dd4: add             x4, x4, x17
    // 0xbc5dd8: cmp             x4, #0x109
    // 0xbc5ddc: b.ls            #0xbc5df0
    // 0xbc5de0: r8 = RenderBox
    //     0xbc5de0: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbc5de4: r3 = Null
    //     0xbc5de4: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcce80] Null
    //     0xbc5de8: ldr             x3, [x3, #0xe80]
    // 0xbc5dec: r0 = RenderBox()
    //     0xbc5dec: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbc5df0: ldr             x3, [fp, #0x10]
    // 0xbc5df4: LoadField: r4 = r3->field_7
    //     0xbc5df4: ldur            w4, [x3, #7]
    // 0xbc5df8: DecompressPointer r4
    //     0xbc5df8: add             x4, x4, HEAP, lsl #32
    // 0xbc5dfc: stur            x4, [fp, #-0x10]
    // 0xbc5e00: cmp             w4, NULL
    // 0xbc5e04: b.eq            #0xbc6088
    // 0xbc5e08: mov             x0, x4
    // 0xbc5e0c: r2 = Null
    //     0xbc5e0c: mov             x2, NULL
    // 0xbc5e10: r1 = Null
    //     0xbc5e10: mov             x1, NULL
    // 0xbc5e14: r4 = LoadClassIdInstr(r0)
    //     0xbc5e14: ldur            x4, [x0, #-1]
    //     0xbc5e18: ubfx            x4, x4, #0xc, #0x14
    // 0xbc5e1c: r17 = 4205
    //     0xbc5e1c: mov             x17, #0x106d
    // 0xbc5e20: cmp             x4, x17
    // 0xbc5e24: b.eq            #0xbc5e3c
    // 0xbc5e28: r8 = ToolbarItemsParentData
    //     0xbc5e28: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0xbc5e2c: ldr             x8, [x8, #0x6c0]
    // 0xbc5e30: r3 = Null
    //     0xbc5e30: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcce90] Null
    //     0xbc5e34: ldr             x3, [x3, #0xe90]
    // 0xbc5e38: r0 = DefaultTypeTest()
    //     0xbc5e38: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbc5e3c: ldur            x4, [fp, #-8]
    // 0xbc5e40: LoadField: r0 = r4->field_23
    //     0xbc5e40: ldur            w0, [x4, #0x23]
    // 0xbc5e44: DecompressPointer r0
    //     0xbc5e44: add             x0, x0, HEAP, lsl #32
    // 0xbc5e48: r1 = LoadInt32Instr(r0)
    //     0xbc5e48: sbfx            x1, x0, #1, #0x1f
    //     0xbc5e4c: tbz             w0, #0, #0xbc5e54
    //     0xbc5e50: ldur            x1, [x0, #7]
    // 0xbc5e54: add             x3, x1, #1
    // 0xbc5e58: r0 = BoxInt64Instr(r3)
    //     0xbc5e58: sbfiz           x0, x3, #1, #0x1f
    //     0xbc5e5c: cmp             x3, x0, asr #1
    //     0xbc5e60: b.eq            #0xbc5e6c
    //     0xbc5e64: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbc5e68: stur            x3, [x0, #7]
    // 0xbc5e6c: StoreField: r4->field_23 = r0
    //     0xbc5e6c: stur            w0, [x4, #0x23]
    //     0xbc5e70: tbz             w0, #0, #0xbc5e8c
    //     0xbc5e74: ldurb           w16, [x4, #-1]
    //     0xbc5e78: ldurb           w17, [x0, #-1]
    //     0xbc5e7c: and             x16, x17, x16, lsr #2
    //     0xbc5e80: tst             x16, HEAP, lsr #32
    //     0xbc5e84: b.eq            #0xbc5e8c
    //     0xbc5e88: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xbc5e8c: LoadField: r1 = r4->field_f
    //     0xbc5e8c: ldur            w1, [x4, #0xf]
    // 0xbc5e90: DecompressPointer r1
    //     0xbc5e90: add             x1, x1, HEAP, lsl #32
    // 0xbc5e94: ldr             x2, [fp, #0x10]
    // 0xbc5e98: r0 = _shouldPaintChild()
    //     0xbc5e98: bl              #0xbc5704  ; [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::_shouldPaintChild
    // 0xbc5e9c: tbz             w0, #4, #0xbc5eb0
    // 0xbc5ea0: ldur            x0, [fp, #-0x10]
    // 0xbc5ea4: r1 = false
    //     0xbc5ea4: add             x1, NULL, #0x30  ; false
    // 0xbc5ea8: ArrayStore: r0[0] = r1  ; List_4
    //     0xbc5ea8: stur            w1, [x0, #0x17]
    // 0xbc5eac: b               #0xbc6070
    // 0xbc5eb0: ldr             x3, [fp, #0x10]
    // 0xbc5eb4: ldur            x2, [fp, #-8]
    // 0xbc5eb8: ldur            x0, [fp, #-0x10]
    // 0xbc5ebc: r1 = true
    //     0xbc5ebc: add             x1, NULL, #0x20  ; true
    // 0xbc5ec0: ArrayStore: r0[0] = r1  ; List_4
    //     0xbc5ec0: stur            w1, [x0, #0x17]
    // 0xbc5ec4: LoadField: r0 = r2->field_1b
    //     0xbc5ec4: ldur            w0, [x2, #0x1b]
    // 0xbc5ec8: DecompressPointer r0
    //     0xbc5ec8: add             x0, x0, HEAP, lsl #32
    // 0xbc5ecc: mov             x1, x3
    // 0xbc5ed0: stur            x0, [fp, #-0x10]
    // 0xbc5ed4: r0 = size()
    //     0xbc5ed4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc5ed8: LoadField: d0 = r0->field_7
    //     0xbc5ed8: ldur            d0, [x0, #7]
    // 0xbc5edc: ldur            x0, [fp, #-0x10]
    // 0xbc5ee0: LoadField: d1 = r0->field_7
    //     0xbc5ee0: ldur            d1, [x0, #7]
    // 0xbc5ee4: fadd            d2, d1, d0
    // 0xbc5ee8: r0 = inline_Allocate_Double()
    //     0xbc5ee8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbc5eec: add             x0, x0, #0x10
    //     0xbc5ef0: cmp             x1, x0
    //     0xbc5ef4: b.ls            #0xbc608c
    //     0xbc5ef8: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc5efc: sub             x0, x0, #0xf
    //     0xbc5f00: mov             x1, #0xe19c
    //     0xbc5f04: movk            x1, #3, lsl #16
    //     0xbc5f08: stur            x1, [x0, #-1]
    // 0xbc5f0c: dmb             ishst
    // 0xbc5f10: StoreField: r0->field_7 = d2
    //     0xbc5f10: stur            d2, [x0, #7]
    // 0xbc5f14: ldur            x2, [fp, #-8]
    // 0xbc5f18: StoreField: r2->field_1b = r0
    //     0xbc5f18: stur            w0, [x2, #0x1b]
    //     0xbc5f1c: ldurb           w16, [x2, #-1]
    //     0xbc5f20: ldurb           w17, [x0, #-1]
    //     0xbc5f24: and             x16, x17, x16, lsr #2
    //     0xbc5f28: tst             x16, HEAP, lsr #32
    //     0xbc5f2c: b.eq            #0xbc5f34
    //     0xbc5f30: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbc5f34: LoadField: r0 = r2->field_1f
    //     0xbc5f34: ldur            w0, [x2, #0x1f]
    // 0xbc5f38: DecompressPointer r0
    //     0xbc5f38: add             x0, x0, HEAP, lsl #32
    // 0xbc5f3c: ldr             x1, [fp, #0x10]
    // 0xbc5f40: stur            x0, [fp, #-0x10]
    // 0xbc5f44: r0 = size()
    //     0xbc5f44: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc5f48: LoadField: d0 = r0->field_f
    //     0xbc5f48: ldur            d0, [x0, #0xf]
    // 0xbc5f4c: ldur            x0, [fp, #-0x10]
    // 0xbc5f50: LoadField: d1 = r0->field_7
    //     0xbc5f50: ldur            d1, [x0, #7]
    // 0xbc5f54: fmax            v2.2d, v1.2d, v0.2d
    // 0xbc5f58: r0 = inline_Allocate_Double()
    //     0xbc5f58: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbc5f5c: add             x0, x0, #0x10
    //     0xbc5f60: cmp             x1, x0
    //     0xbc5f64: b.ls            #0xbc609c
    //     0xbc5f68: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc5f6c: sub             x0, x0, #0xf
    //     0xbc5f70: mov             x1, #0xe19c
    //     0xbc5f74: movk            x1, #3, lsl #16
    //     0xbc5f78: stur            x1, [x0, #-1]
    // 0xbc5f7c: dmb             ishst
    // 0xbc5f80: StoreField: r0->field_7 = d2
    //     0xbc5f80: stur            d2, [x0, #7]
    // 0xbc5f84: ldur            x1, [fp, #-8]
    // 0xbc5f88: StoreField: r1->field_1f = r0
    //     0xbc5f88: stur            w0, [x1, #0x1f]
    //     0xbc5f8c: ldurb           w16, [x1, #-1]
    //     0xbc5f90: ldurb           w17, [x0, #-1]
    //     0xbc5f94: and             x16, x17, x16, lsr #2
    //     0xbc5f98: tst             x16, HEAP, lsr #32
    //     0xbc5f9c: b.eq            #0xbc5fa4
    //     0xbc5fa0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc5fa4: LoadField: r0 = r1->field_13
    //     0xbc5fa4: ldur            w0, [x1, #0x13]
    // 0xbc5fa8: DecompressPointer r0
    //     0xbc5fa8: add             x0, x0, HEAP, lsl #32
    // 0xbc5fac: ldr             x3, [fp, #0x10]
    // 0xbc5fb0: cmp             w3, w0
    // 0xbc5fb4: b.eq            #0xbc6070
    // 0xbc5fb8: ArrayLoad: r4 = r1[0]  ; List_4
    //     0xbc5fb8: ldur            w4, [x1, #0x17]
    // 0xbc5fbc: DecompressPointer r4
    //     0xbc5fbc: add             x4, x4, HEAP, lsl #32
    // 0xbc5fc0: stur            x4, [fp, #-0x10]
    // 0xbc5fc4: LoadField: r2 = r4->field_7
    //     0xbc5fc4: ldur            w2, [x4, #7]
    // 0xbc5fc8: DecompressPointer r2
    //     0xbc5fc8: add             x2, x2, HEAP, lsl #32
    // 0xbc5fcc: mov             x0, x3
    // 0xbc5fd0: r1 = Null
    //     0xbc5fd0: mov             x1, NULL
    // 0xbc5fd4: cmp             w2, NULL
    // 0xbc5fd8: b.eq            #0xbc5ff8
    // 0xbc5fdc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xbc5fdc: ldur            w4, [x2, #0x17]
    // 0xbc5fe0: DecompressPointer r4
    //     0xbc5fe0: add             x4, x4, HEAP, lsl #32
    // 0xbc5fe4: r8 = X0
    //     0xbc5fe4: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xbc5fe8: LoadField: r9 = r4->field_7
    //     0xbc5fe8: ldur            x9, [x4, #7]
    // 0xbc5fec: r3 = Null
    //     0xbc5fec: add             x3, PP, #0xcc, lsl #12  ; [pp+0xccea0] Null
    //     0xbc5ff0: ldr             x3, [x3, #0xea0]
    // 0xbc5ff4: blr             x9
    // 0xbc5ff8: ldur            x0, [fp, #-0x10]
    // 0xbc5ffc: LoadField: r1 = r0->field_b
    //     0xbc5ffc: ldur            w1, [x0, #0xb]
    // 0xbc6000: LoadField: r2 = r0->field_f
    //     0xbc6000: ldur            w2, [x0, #0xf]
    // 0xbc6004: DecompressPointer r2
    //     0xbc6004: add             x2, x2, HEAP, lsl #32
    // 0xbc6008: LoadField: r3 = r2->field_b
    //     0xbc6008: ldur            w3, [x2, #0xb]
    // 0xbc600c: r2 = LoadInt32Instr(r1)
    //     0xbc600c: sbfx            x2, x1, #1, #0x1f
    // 0xbc6010: stur            x2, [fp, #-0x18]
    // 0xbc6014: r1 = LoadInt32Instr(r3)
    //     0xbc6014: sbfx            x1, x3, #1, #0x1f
    // 0xbc6018: cmp             x2, x1
    // 0xbc601c: b.ne            #0xbc6028
    // 0xbc6020: mov             x1, x0
    // 0xbc6024: r0 = _growToNextCapacity()
    //     0xbc6024: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xbc6028: ldur            x2, [fp, #-0x10]
    // 0xbc602c: ldur            x3, [fp, #-0x18]
    // 0xbc6030: add             x4, x3, #1
    // 0xbc6034: lsl             x5, x4, #1
    // 0xbc6038: StoreField: r2->field_b = r5
    //     0xbc6038: stur            w5, [x2, #0xb]
    // 0xbc603c: LoadField: r1 = r2->field_f
    //     0xbc603c: ldur            w1, [x2, #0xf]
    // 0xbc6040: DecompressPointer r1
    //     0xbc6040: add             x1, x1, HEAP, lsl #32
    // 0xbc6044: ldr             x0, [fp, #0x10]
    // 0xbc6048: ArrayStore: r1[r3] = r0  ; List_4
    //     0xbc6048: add             x25, x1, x3, lsl #2
    //     0xbc604c: add             x25, x25, #0xf
    //     0xbc6050: str             w0, [x25]
    //     0xbc6054: tbz             w0, #0, #0xbc6070
    //     0xbc6058: ldurb           w16, [x1, #-1]
    //     0xbc605c: ldurb           w17, [x0, #-1]
    //     0xbc6060: and             x16, x17, x16, lsr #2
    //     0xbc6064: tst             x16, HEAP, lsr #32
    //     0xbc6068: b.eq            #0xbc6070
    //     0xbc606c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbc6070: r0 = Null
    //     0xbc6070: mov             x0, NULL
    // 0xbc6074: LeaveFrame
    //     0xbc6074: mov             SP, fp
    //     0xbc6078: ldp             fp, lr, [SP], #0x10
    // 0xbc607c: ret
    //     0xbc607c: ret             
    // 0xbc6080: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc6080: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc6084: b               #0xbc5dbc
    // 0xbc6088: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc6088: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc608c: SaveReg d2
    //     0xbc608c: str             q2, [SP, #-0x10]!
    // 0xbc6090: r0 = AllocateDouble()
    //     0xbc6090: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc6094: RestoreReg d2
    //     0xbc6094: ldr             q2, [SP], #0x10
    // 0xbc6098: b               #0xbc5f10
    // 0xbc609c: SaveReg d2
    //     0xbc609c: str             q2, [SP, #-0x10]!
    // 0xbc60a0: r0 = AllocateDouble()
    //     0xbc60a0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc60a4: RestoreReg d2
    //     0xbc60a4: ldr             q2, [SP], #0x10
    // 0xbc60a8: b               #0xbc5f80
  }
  _ _placeChildrenVertically(/* No info */) {
    // ** addr: 0xbc60ac, size: 0x3dc
    // 0xbc60ac: EnterFrame
    //     0xbc60ac: stp             fp, lr, [SP, #-0x10]!
    //     0xbc60b0: mov             fp, SP
    // 0xbc60b4: AllocStack(0x30)
    //     0xbc60b4: sub             SP, SP, #0x30
    // 0xbc60b8: SetupParameters(_RenderTextSelectionToolbarItemsLayout this /* r1 => r1, fp-0x8 */)
    //     0xbc60b8: stur            x1, [fp, #-8]
    // 0xbc60bc: CheckStackOverflow
    //     0xbc60bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc60c0: cmp             SP, x16
    //     0xbc60c4: b.ls            #0xbc6438
    // 0xbc60c8: r1 = 5
    //     0xbc60c8: mov             x1, #5
    // 0xbc60cc: r0 = AllocateContext()
    //     0xbc60cc: bl              #0x13de838  ; AllocateContextStub
    // 0xbc60d0: mov             x4, x0
    // 0xbc60d4: ldur            x3, [fp, #-8]
    // 0xbc60d8: stur            x4, [fp, #-0x20]
    // 0xbc60dc: StoreField: r4->field_f = r3
    //     0xbc60dc: stur            w3, [x4, #0xf]
    // 0xbc60e0: LoadField: r5 = r3->field_57
    //     0xbc60e0: ldur            w5, [x3, #0x57]
    // 0xbc60e4: DecompressPointer r5
    //     0xbc60e4: add             x5, x5, HEAP, lsl #32
    // 0xbc60e8: stur            x5, [fp, #-0x18]
    // 0xbc60ec: cmp             w5, NULL
    // 0xbc60f0: b.eq            #0xbc6440
    // 0xbc60f4: StoreField: r4->field_13 = r5
    //     0xbc60f4: stur            w5, [x4, #0x13]
    // 0xbc60f8: r0 = 0.000000
    //     0xbc60f8: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbc60fc: ArrayStore: r4[0] = r0  ; List_4
    //     0xbc60fc: stur            w0, [x4, #0x17]
    // 0xbc6100: StoreField: r4->field_1b = r0
    //     0xbc6100: stur            w0, [x4, #0x1b]
    // 0xbc6104: LoadField: r6 = r5->field_7
    //     0xbc6104: ldur            w6, [x5, #7]
    // 0xbc6108: DecompressPointer r6
    //     0xbc6108: add             x6, x6, HEAP, lsl #32
    // 0xbc610c: stur            x6, [fp, #-0x10]
    // 0xbc6110: cmp             w6, NULL
    // 0xbc6114: b.eq            #0xbc6444
    // 0xbc6118: mov             x0, x6
    // 0xbc611c: r2 = Null
    //     0xbc611c: mov             x2, NULL
    // 0xbc6120: r1 = Null
    //     0xbc6120: mov             x1, NULL
    // 0xbc6124: r4 = LoadClassIdInstr(r0)
    //     0xbc6124: ldur            x4, [x0, #-1]
    //     0xbc6128: ubfx            x4, x4, #0xc, #0x14
    // 0xbc612c: r17 = 4205
    //     0xbc612c: mov             x17, #0x106d
    // 0xbc6130: cmp             x4, x17
    // 0xbc6134: b.eq            #0xbc614c
    // 0xbc6138: r8 = ToolbarItemsParentData
    //     0xbc6138: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0xbc613c: ldr             x8, [x8, #0x6c0]
    // 0xbc6140: r3 = Null
    //     0xbc6140: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcceb0] Null
    //     0xbc6144: ldr             x3, [x3, #0xeb0]
    // 0xbc6148: r0 = DefaultTypeTest()
    //     0xbc6148: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbc614c: ldur            x1, [fp, #-8]
    // 0xbc6150: ldur            x2, [fp, #-0x18]
    // 0xbc6154: r3 = 0
    //     0xbc6154: mov             x3, #0
    // 0xbc6158: r0 = _shouldPaintChild()
    //     0xbc6158: bl              #0xbc5704  ; [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::_shouldPaintChild
    // 0xbc615c: tbnz            w0, #4, #0xbc6278
    // 0xbc6160: ldur            x0, [fp, #-8]
    // 0xbc6164: ldur            x2, [fp, #-0x10]
    // 0xbc6168: r1 = true
    //     0xbc6168: add             x1, NULL, #0x20  ; true
    // 0xbc616c: ArrayStore: r2[0] = r1  ; List_4
    //     0xbc616c: stur            w1, [x2, #0x17]
    // 0xbc6170: LoadField: r1 = r0->field_67
    //     0xbc6170: ldur            w1, [x0, #0x67]
    // 0xbc6174: DecompressPointer r1
    //     0xbc6174: add             x1, x1, HEAP, lsl #32
    // 0xbc6178: tbz             w1, #4, #0xbc626c
    // 0xbc617c: ldur            x3, [fp, #-0x20]
    // 0xbc6180: r1 = Instance_Offset
    //     0xbc6180: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xbc6184: StoreField: r2->field_7 = r1
    //     0xbc6184: stur            w1, [x2, #7]
    // 0xbc6188: ArrayLoad: r4 = r3[0]  ; List_4
    //     0xbc6188: ldur            w4, [x3, #0x17]
    // 0xbc618c: DecompressPointer r4
    //     0xbc618c: add             x4, x4, HEAP, lsl #32
    // 0xbc6190: ldur            x1, [fp, #-0x18]
    // 0xbc6194: stur            x4, [fp, #-0x28]
    // 0xbc6198: r0 = size()
    //     0xbc6198: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc619c: LoadField: d0 = r0->field_f
    //     0xbc619c: ldur            d0, [x0, #0xf]
    // 0xbc61a0: ldur            x0, [fp, #-0x28]
    // 0xbc61a4: LoadField: d1 = r0->field_7
    //     0xbc61a4: ldur            d1, [x0, #7]
    // 0xbc61a8: fadd            d2, d1, d0
    // 0xbc61ac: r0 = inline_Allocate_Double()
    //     0xbc61ac: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbc61b0: add             x0, x0, #0x10
    //     0xbc61b4: cmp             x1, x0
    //     0xbc61b8: b.ls            #0xbc6448
    //     0xbc61bc: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc61c0: sub             x0, x0, #0xf
    //     0xbc61c4: mov             x1, #0xe19c
    //     0xbc61c8: movk            x1, #3, lsl #16
    //     0xbc61cc: stur            x1, [x0, #-1]
    // 0xbc61d0: dmb             ishst
    // 0xbc61d4: StoreField: r0->field_7 = d2
    //     0xbc61d4: stur            d2, [x0, #7]
    // 0xbc61d8: ldur            x2, [fp, #-0x20]
    // 0xbc61dc: ArrayStore: r2[0] = r0  ; List_4
    //     0xbc61dc: stur            w0, [x2, #0x17]
    //     0xbc61e0: ldurb           w16, [x2, #-1]
    //     0xbc61e4: ldurb           w17, [x0, #-1]
    //     0xbc61e8: and             x16, x17, x16, lsr #2
    //     0xbc61ec: tst             x16, HEAP, lsr #32
    //     0xbc61f0: b.eq            #0xbc61f8
    //     0xbc61f4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbc61f8: LoadField: r0 = r2->field_1b
    //     0xbc61f8: ldur            w0, [x2, #0x1b]
    // 0xbc61fc: DecompressPointer r0
    //     0xbc61fc: add             x0, x0, HEAP, lsl #32
    // 0xbc6200: ldur            x1, [fp, #-0x18]
    // 0xbc6204: stur            x0, [fp, #-0x28]
    // 0xbc6208: r0 = size()
    //     0xbc6208: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc620c: LoadField: d0 = r0->field_7
    //     0xbc620c: ldur            d0, [x0, #7]
    // 0xbc6210: ldur            x0, [fp, #-0x28]
    // 0xbc6214: LoadField: d1 = r0->field_7
    //     0xbc6214: ldur            d1, [x0, #7]
    // 0xbc6218: fmax            v2.2d, v1.2d, v0.2d
    // 0xbc621c: r0 = inline_Allocate_Double()
    //     0xbc621c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbc6220: add             x0, x0, #0x10
    //     0xbc6224: cmp             x1, x0
    //     0xbc6228: b.ls            #0xbc6458
    //     0xbc622c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc6230: sub             x0, x0, #0xf
    //     0xbc6234: mov             x1, #0xe19c
    //     0xbc6238: movk            x1, #3, lsl #16
    //     0xbc623c: stur            x1, [x0, #-1]
    // 0xbc6240: dmb             ishst
    // 0xbc6244: StoreField: r0->field_7 = d2
    //     0xbc6244: stur            d2, [x0, #7]
    // 0xbc6248: ldur            x3, [fp, #-0x20]
    // 0xbc624c: StoreField: r3->field_1b = r0
    //     0xbc624c: stur            w0, [x3, #0x1b]
    //     0xbc6250: ldurb           w16, [x3, #-1]
    //     0xbc6254: ldurb           w17, [x0, #-1]
    //     0xbc6258: and             x16, x17, x16, lsr #2
    //     0xbc625c: tst             x16, HEAP, lsr #32
    //     0xbc6260: b.eq            #0xbc6268
    //     0xbc6264: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbc6268: b               #0xbc6270
    // 0xbc626c: ldur            x3, [fp, #-0x20]
    // 0xbc6270: ldur            x0, [fp, #-0x10]
    // 0xbc6274: b               #0xbc6288
    // 0xbc6278: ldur            x3, [fp, #-0x20]
    // 0xbc627c: ldur            x0, [fp, #-0x10]
    // 0xbc6280: r1 = false
    //     0xbc6280: add             x1, NULL, #0x30  ; false
    // 0xbc6284: ArrayStore: r0[0] = r1  ; List_4
    //     0xbc6284: stur            w1, [x0, #0x17]
    // 0xbc6288: ldur            x4, [fp, #-8]
    // 0xbc628c: r1 = -2
    //     0xbc628c: mov             x1, #-2
    // 0xbc6290: StoreField: r3->field_1f = r1
    //     0xbc6290: stur            w1, [x3, #0x1f]
    // 0xbc6294: mov             x2, x3
    // 0xbc6298: r1 = Function '<anonymous closure>':.
    //     0xbc6298: add             x1, PP, #0xcc, lsl #12  ; [pp+0xccec0] AnonymousClosure: (0xbc6488), in [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::_placeChildrenVertically (0xbc60ac)
    //     0xbc629c: ldr             x1, [x1, #0xec0]
    // 0xbc62a0: r0 = AllocateClosure()
    //     0xbc62a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbc62a4: ldur            x1, [fp, #-8]
    // 0xbc62a8: mov             x2, x0
    // 0xbc62ac: r0 = visitChildren()
    //     0xbc62ac: bl              #0xbeef74  ; [dart:mixin_deduplication] _MixinApplication118&RenderBox&ContainerRenderObjectMixin::visitChildren
    // 0xbc62b0: ldur            x0, [fp, #-8]
    // 0xbc62b4: LoadField: r1 = r0->field_67
    //     0xbc62b4: ldur            w1, [x0, #0x67]
    // 0xbc62b8: DecompressPointer r1
    //     0xbc62b8: add             x1, x1, HEAP, lsl #32
    // 0xbc62bc: tbnz            w1, #4, #0xbc63f4
    // 0xbc62c0: ldur            x0, [fp, #-0x10]
    // 0xbc62c4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbc62c4: ldur            w1, [x0, #0x17]
    // 0xbc62c8: DecompressPointer r1
    //     0xbc62c8: add             x1, x1, HEAP, lsl #32
    // 0xbc62cc: tbnz            w1, #4, #0xbc63ec
    // 0xbc62d0: ldur            x1, [fp, #-0x20]
    // 0xbc62d4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xbc62d4: ldur            w2, [x1, #0x17]
    // 0xbc62d8: DecompressPointer r2
    //     0xbc62d8: add             x2, x2, HEAP, lsl #32
    // 0xbc62dc: stur            x2, [fp, #-8]
    // 0xbc62e0: r0 = Offset()
    //     0xbc62e0: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbc62e4: StoreField: r0->field_7 = rZR
    //     0xbc62e4: stur            xzr, [x0, #7]
    // 0xbc62e8: ldur            x1, [fp, #-8]
    // 0xbc62ec: LoadField: d0 = r1->field_7
    //     0xbc62ec: ldur            d0, [x1, #7]
    // 0xbc62f0: stur            d0, [fp, #-0x30]
    // 0xbc62f4: StoreField: r0->field_f = d0
    //     0xbc62f4: stur            d0, [x0, #0xf]
    // 0xbc62f8: ldur            x1, [fp, #-0x10]
    // 0xbc62fc: StoreField: r1->field_7 = r0
    //     0xbc62fc: stur            w0, [x1, #7]
    //     0xbc6300: ldurb           w16, [x1, #-1]
    //     0xbc6304: ldurb           w17, [x0, #-1]
    //     0xbc6308: and             x16, x17, x16, lsr #2
    //     0xbc630c: tst             x16, HEAP, lsr #32
    //     0xbc6310: b.eq            #0xbc6318
    //     0xbc6314: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc6318: ldur            x1, [fp, #-0x18]
    // 0xbc631c: r0 = size()
    //     0xbc631c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc6320: LoadField: d0 = r0->field_f
    //     0xbc6320: ldur            d0, [x0, #0xf]
    // 0xbc6324: ldur            d1, [fp, #-0x30]
    // 0xbc6328: fadd            d2, d1, d0
    // 0xbc632c: r0 = inline_Allocate_Double()
    //     0xbc632c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbc6330: add             x0, x0, #0x10
    //     0xbc6334: cmp             x1, x0
    //     0xbc6338: b.ls            #0xbc6468
    //     0xbc633c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc6340: sub             x0, x0, #0xf
    //     0xbc6344: mov             x1, #0xe19c
    //     0xbc6348: movk            x1, #3, lsl #16
    //     0xbc634c: stur            x1, [x0, #-1]
    // 0xbc6350: dmb             ishst
    // 0xbc6354: StoreField: r0->field_7 = d2
    //     0xbc6354: stur            d2, [x0, #7]
    // 0xbc6358: ldur            x2, [fp, #-0x20]
    // 0xbc635c: ArrayStore: r2[0] = r0  ; List_4
    //     0xbc635c: stur            w0, [x2, #0x17]
    //     0xbc6360: ldurb           w16, [x2, #-1]
    //     0xbc6364: ldurb           w17, [x0, #-1]
    //     0xbc6368: and             x16, x17, x16, lsr #2
    //     0xbc636c: tst             x16, HEAP, lsr #32
    //     0xbc6370: b.eq            #0xbc6378
    //     0xbc6374: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbc6378: LoadField: r0 = r2->field_1b
    //     0xbc6378: ldur            w0, [x2, #0x1b]
    // 0xbc637c: DecompressPointer r0
    //     0xbc637c: add             x0, x0, HEAP, lsl #32
    // 0xbc6380: ldur            x1, [fp, #-0x18]
    // 0xbc6384: stur            x0, [fp, #-8]
    // 0xbc6388: r0 = size()
    //     0xbc6388: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc638c: LoadField: d0 = r0->field_7
    //     0xbc638c: ldur            d0, [x0, #7]
    // 0xbc6390: ldur            x0, [fp, #-8]
    // 0xbc6394: LoadField: d1 = r0->field_7
    //     0xbc6394: ldur            d1, [x0, #7]
    // 0xbc6398: fmax            v2.2d, v1.2d, v0.2d
    // 0xbc639c: r0 = inline_Allocate_Double()
    //     0xbc639c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbc63a0: add             x0, x0, #0x10
    //     0xbc63a4: cmp             x1, x0
    //     0xbc63a8: b.ls            #0xbc6478
    //     0xbc63ac: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc63b0: sub             x0, x0, #0xf
    //     0xbc63b4: mov             x1, #0xe19c
    //     0xbc63b8: movk            x1, #3, lsl #16
    //     0xbc63bc: stur            x1, [x0, #-1]
    // 0xbc63c0: dmb             ishst
    // 0xbc63c4: StoreField: r0->field_7 = d2
    //     0xbc63c4: stur            d2, [x0, #7]
    // 0xbc63c8: ldur            x1, [fp, #-0x20]
    // 0xbc63cc: StoreField: r1->field_1b = r0
    //     0xbc63cc: stur            w0, [x1, #0x1b]
    //     0xbc63d0: ldurb           w16, [x1, #-1]
    //     0xbc63d4: ldurb           w17, [x0, #-1]
    //     0xbc63d8: and             x16, x17, x16, lsr #2
    //     0xbc63dc: tst             x16, HEAP, lsr #32
    //     0xbc63e0: b.eq            #0xbc63e8
    //     0xbc63e4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc63e8: b               #0xbc63f8
    // 0xbc63ec: ldur            x1, [fp, #-0x20]
    // 0xbc63f0: b               #0xbc63f8
    // 0xbc63f4: ldur            x1, [fp, #-0x20]
    // 0xbc63f8: LoadField: r0 = r1->field_1b
    //     0xbc63f8: ldur            w0, [x1, #0x1b]
    // 0xbc63fc: DecompressPointer r0
    //     0xbc63fc: add             x0, x0, HEAP, lsl #32
    // 0xbc6400: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xbc6400: ldur            w2, [x1, #0x17]
    // 0xbc6404: DecompressPointer r2
    //     0xbc6404: add             x2, x2, HEAP, lsl #32
    // 0xbc6408: stur            x2, [fp, #-8]
    // 0xbc640c: LoadField: d0 = r0->field_7
    //     0xbc640c: ldur            d0, [x0, #7]
    // 0xbc6410: stur            d0, [fp, #-0x30]
    // 0xbc6414: r0 = Size()
    //     0xbc6414: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbc6418: ldur            d0, [fp, #-0x30]
    // 0xbc641c: StoreField: r0->field_7 = d0
    //     0xbc641c: stur            d0, [x0, #7]
    // 0xbc6420: ldur            x1, [fp, #-8]
    // 0xbc6424: LoadField: d0 = r1->field_7
    //     0xbc6424: ldur            d0, [x1, #7]
    // 0xbc6428: StoreField: r0->field_f = d0
    //     0xbc6428: stur            d0, [x0, #0xf]
    // 0xbc642c: LeaveFrame
    //     0xbc642c: mov             SP, fp
    //     0xbc6430: ldp             fp, lr, [SP], #0x10
    // 0xbc6434: ret
    //     0xbc6434: ret             
    // 0xbc6438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc6438: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc643c: b               #0xbc60c8
    // 0xbc6440: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc6440: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc6444: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc6444: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc6448: SaveReg d2
    //     0xbc6448: str             q2, [SP, #-0x10]!
    // 0xbc644c: r0 = AllocateDouble()
    //     0xbc644c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc6450: RestoreReg d2
    //     0xbc6450: ldr             q2, [SP], #0x10
    // 0xbc6454: b               #0xbc61d4
    // 0xbc6458: SaveReg d2
    //     0xbc6458: str             q2, [SP, #-0x10]!
    // 0xbc645c: r0 = AllocateDouble()
    //     0xbc645c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc6460: RestoreReg d2
    //     0xbc6460: ldr             q2, [SP], #0x10
    // 0xbc6464: b               #0xbc6244
    // 0xbc6468: SaveReg d2
    //     0xbc6468: str             q2, [SP, #-0x10]!
    // 0xbc646c: r0 = AllocateDouble()
    //     0xbc646c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc6470: RestoreReg d2
    //     0xbc6470: ldr             q2, [SP], #0x10
    // 0xbc6474: b               #0xbc6354
    // 0xbc6478: SaveReg d2
    //     0xbc6478: str             q2, [SP, #-0x10]!
    // 0xbc647c: r0 = AllocateDouble()
    //     0xbc647c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc6480: RestoreReg d2
    //     0xbc6480: ldr             q2, [SP], #0x10
    // 0xbc6484: b               #0xbc63c4
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0xbc6488, size: 0x2ac
    // 0xbc6488: EnterFrame
    //     0xbc6488: stp             fp, lr, [SP, #-0x10]!
    //     0xbc648c: mov             fp, SP
    // 0xbc6490: AllocStack(0x20)
    //     0xbc6490: sub             SP, SP, #0x20
    // 0xbc6494: SetupParameters([dynamic _ /* r0 */])
    //     0xbc6494: ldr             x0, [fp, #0x18]
    //     0xbc6498: ldur            w3, [x0, #0x17]
    //     0xbc649c: add             x3, x3, HEAP, lsl #32
    //     0xbc64a0: stur            x3, [fp, #-8]
    // 0xbc64a4: CheckStackOverflow
    //     0xbc64a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc64a8: cmp             SP, x16
    //     0xbc64ac: b.ls            #0xbc6708
    // 0xbc64b0: ldr             x0, [fp, #0x10]
    // 0xbc64b4: r2 = Null
    //     0xbc64b4: mov             x2, NULL
    // 0xbc64b8: r1 = Null
    //     0xbc64b8: mov             x1, NULL
    // 0xbc64bc: r4 = LoadClassIdInstr(r0)
    //     0xbc64bc: ldur            x4, [x0, #-1]
    //     0xbc64c0: ubfx            x4, x4, #0xc, #0x14
    // 0xbc64c4: r17 = -4710
    //     0xbc64c4: mov             x17, #-0x1266
    // 0xbc64c8: add             x4, x4, x17
    // 0xbc64cc: cmp             x4, #0x109
    // 0xbc64d0: b.ls            #0xbc64e4
    // 0xbc64d4: r8 = RenderBox
    //     0xbc64d4: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbc64d8: r3 = Null
    //     0xbc64d8: add             x3, PP, #0xcc, lsl #12  ; [pp+0xccec8] Null
    //     0xbc64dc: ldr             x3, [x3, #0xec8]
    // 0xbc64e0: r0 = RenderBox()
    //     0xbc64e0: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbc64e4: ldr             x3, [fp, #0x10]
    // 0xbc64e8: LoadField: r4 = r3->field_7
    //     0xbc64e8: ldur            w4, [x3, #7]
    // 0xbc64ec: DecompressPointer r4
    //     0xbc64ec: add             x4, x4, HEAP, lsl #32
    // 0xbc64f0: stur            x4, [fp, #-0x10]
    // 0xbc64f4: cmp             w4, NULL
    // 0xbc64f8: b.eq            #0xbc6710
    // 0xbc64fc: mov             x0, x4
    // 0xbc6500: r2 = Null
    //     0xbc6500: mov             x2, NULL
    // 0xbc6504: r1 = Null
    //     0xbc6504: mov             x1, NULL
    // 0xbc6508: r4 = LoadClassIdInstr(r0)
    //     0xbc6508: ldur            x4, [x0, #-1]
    //     0xbc650c: ubfx            x4, x4, #0xc, #0x14
    // 0xbc6510: r17 = 4205
    //     0xbc6510: mov             x17, #0x106d
    // 0xbc6514: cmp             x4, x17
    // 0xbc6518: b.eq            #0xbc6530
    // 0xbc651c: r8 = ToolbarItemsParentData
    //     0xbc651c: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0xbc6520: ldr             x8, [x8, #0x6c0]
    // 0xbc6524: r3 = Null
    //     0xbc6524: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcced8] Null
    //     0xbc6528: ldr             x3, [x3, #0xed8]
    // 0xbc652c: r0 = DefaultTypeTest()
    //     0xbc652c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbc6530: ldur            x4, [fp, #-8]
    // 0xbc6534: LoadField: r0 = r4->field_1f
    //     0xbc6534: ldur            w0, [x4, #0x1f]
    // 0xbc6538: DecompressPointer r0
    //     0xbc6538: add             x0, x0, HEAP, lsl #32
    // 0xbc653c: r1 = LoadInt32Instr(r0)
    //     0xbc653c: sbfx            x1, x0, #1, #0x1f
    //     0xbc6540: tbz             w0, #0, #0xbc6548
    //     0xbc6544: ldur            x1, [x0, #7]
    // 0xbc6548: add             x3, x1, #1
    // 0xbc654c: r0 = BoxInt64Instr(r3)
    //     0xbc654c: sbfiz           x0, x3, #1, #0x1f
    //     0xbc6550: cmp             x3, x0, asr #1
    //     0xbc6554: b.eq            #0xbc6560
    //     0xbc6558: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbc655c: stur            x3, [x0, #7]
    // 0xbc6560: StoreField: r4->field_1f = r0
    //     0xbc6560: stur            w0, [x4, #0x1f]
    //     0xbc6564: tbz             w0, #0, #0xbc6580
    //     0xbc6568: ldurb           w16, [x4, #-1]
    //     0xbc656c: ldurb           w17, [x0, #-1]
    //     0xbc6570: and             x16, x17, x16, lsr #2
    //     0xbc6574: tst             x16, HEAP, lsr #32
    //     0xbc6578: b.eq            #0xbc6580
    //     0xbc657c: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xbc6580: LoadField: r0 = r4->field_13
    //     0xbc6580: ldur            w0, [x4, #0x13]
    // 0xbc6584: DecompressPointer r0
    //     0xbc6584: add             x0, x0, HEAP, lsl #32
    // 0xbc6588: ldr             x5, [fp, #0x10]
    // 0xbc658c: cmp             w5, w0
    // 0xbc6590: b.ne            #0xbc65a4
    // 0xbc6594: r0 = Null
    //     0xbc6594: mov             x0, NULL
    // 0xbc6598: LeaveFrame
    //     0xbc6598: mov             SP, fp
    //     0xbc659c: ldp             fp, lr, [SP], #0x10
    // 0xbc65a0: ret
    //     0xbc65a0: ret             
    // 0xbc65a4: LoadField: r1 = r4->field_f
    //     0xbc65a4: ldur            w1, [x4, #0xf]
    // 0xbc65a8: DecompressPointer r1
    //     0xbc65a8: add             x1, x1, HEAP, lsl #32
    // 0xbc65ac: mov             x2, x5
    // 0xbc65b0: r0 = _shouldPaintChild()
    //     0xbc65b0: bl              #0xbc5704  ; [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::_shouldPaintChild
    // 0xbc65b4: tbz             w0, #4, #0xbc65d4
    // 0xbc65b8: ldur            x0, [fp, #-0x10]
    // 0xbc65bc: r1 = false
    //     0xbc65bc: add             x1, NULL, #0x30  ; false
    // 0xbc65c0: ArrayStore: r0[0] = r1  ; List_4
    //     0xbc65c0: stur            w1, [x0, #0x17]
    // 0xbc65c4: r0 = Null
    //     0xbc65c4: mov             x0, NULL
    // 0xbc65c8: LeaveFrame
    //     0xbc65c8: mov             SP, fp
    //     0xbc65cc: ldp             fp, lr, [SP], #0x10
    // 0xbc65d0: ret
    //     0xbc65d0: ret             
    // 0xbc65d4: ldur            x1, [fp, #-8]
    // 0xbc65d8: ldur            x0, [fp, #-0x10]
    // 0xbc65dc: r2 = true
    //     0xbc65dc: add             x2, NULL, #0x20  ; true
    // 0xbc65e0: ArrayStore: r0[0] = r2  ; List_4
    //     0xbc65e0: stur            w2, [x0, #0x17]
    // 0xbc65e4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xbc65e4: ldur            w2, [x1, #0x17]
    // 0xbc65e8: DecompressPointer r2
    //     0xbc65e8: add             x2, x2, HEAP, lsl #32
    // 0xbc65ec: stur            x2, [fp, #-0x18]
    // 0xbc65f0: r0 = Offset()
    //     0xbc65f0: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbc65f4: StoreField: r0->field_7 = rZR
    //     0xbc65f4: stur            xzr, [x0, #7]
    // 0xbc65f8: ldur            x1, [fp, #-0x18]
    // 0xbc65fc: LoadField: d0 = r1->field_7
    //     0xbc65fc: ldur            d0, [x1, #7]
    // 0xbc6600: stur            d0, [fp, #-0x20]
    // 0xbc6604: StoreField: r0->field_f = d0
    //     0xbc6604: stur            d0, [x0, #0xf]
    // 0xbc6608: ldur            x1, [fp, #-0x10]
    // 0xbc660c: StoreField: r1->field_7 = r0
    //     0xbc660c: stur            w0, [x1, #7]
    //     0xbc6610: ldurb           w16, [x1, #-1]
    //     0xbc6614: ldurb           w17, [x0, #-1]
    //     0xbc6618: and             x16, x17, x16, lsr #2
    //     0xbc661c: tst             x16, HEAP, lsr #32
    //     0xbc6620: b.eq            #0xbc6628
    //     0xbc6624: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc6628: ldr             x1, [fp, #0x10]
    // 0xbc662c: r0 = size()
    //     0xbc662c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc6630: LoadField: d0 = r0->field_f
    //     0xbc6630: ldur            d0, [x0, #0xf]
    // 0xbc6634: ldur            d1, [fp, #-0x20]
    // 0xbc6638: fadd            d2, d1, d0
    // 0xbc663c: r0 = inline_Allocate_Double()
    //     0xbc663c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbc6640: add             x0, x0, #0x10
    //     0xbc6644: cmp             x1, x0
    //     0xbc6648: b.ls            #0xbc6714
    //     0xbc664c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc6650: sub             x0, x0, #0xf
    //     0xbc6654: mov             x1, #0xe19c
    //     0xbc6658: movk            x1, #3, lsl #16
    //     0xbc665c: stur            x1, [x0, #-1]
    // 0xbc6660: dmb             ishst
    // 0xbc6664: StoreField: r0->field_7 = d2
    //     0xbc6664: stur            d2, [x0, #7]
    // 0xbc6668: ldur            x2, [fp, #-8]
    // 0xbc666c: ArrayStore: r2[0] = r0  ; List_4
    //     0xbc666c: stur            w0, [x2, #0x17]
    //     0xbc6670: ldurb           w16, [x2, #-1]
    //     0xbc6674: ldurb           w17, [x0, #-1]
    //     0xbc6678: and             x16, x17, x16, lsr #2
    //     0xbc667c: tst             x16, HEAP, lsr #32
    //     0xbc6680: b.eq            #0xbc6688
    //     0xbc6684: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbc6688: LoadField: r0 = r2->field_1b
    //     0xbc6688: ldur            w0, [x2, #0x1b]
    // 0xbc668c: DecompressPointer r0
    //     0xbc668c: add             x0, x0, HEAP, lsl #32
    // 0xbc6690: ldr             x1, [fp, #0x10]
    // 0xbc6694: stur            x0, [fp, #-0x10]
    // 0xbc6698: r0 = size()
    //     0xbc6698: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc669c: LoadField: d0 = r0->field_7
    //     0xbc669c: ldur            d0, [x0, #7]
    // 0xbc66a0: ldur            x1, [fp, #-0x10]
    // 0xbc66a4: LoadField: d1 = r1->field_7
    //     0xbc66a4: ldur            d1, [x1, #7]
    // 0xbc66a8: fmax            v2.2d, v1.2d, v0.2d
    // 0xbc66ac: r0 = inline_Allocate_Double()
    //     0xbc66ac: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbc66b0: add             x0, x0, #0x10
    //     0xbc66b4: cmp             x1, x0
    //     0xbc66b8: b.ls            #0xbc6724
    //     0xbc66bc: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc66c0: sub             x0, x0, #0xf
    //     0xbc66c4: mov             x1, #0xe19c
    //     0xbc66c8: movk            x1, #3, lsl #16
    //     0xbc66cc: stur            x1, [x0, #-1]
    // 0xbc66d0: dmb             ishst
    // 0xbc66d4: StoreField: r0->field_7 = d2
    //     0xbc66d4: stur            d2, [x0, #7]
    // 0xbc66d8: ldur            x1, [fp, #-8]
    // 0xbc66dc: StoreField: r1->field_1b = r0
    //     0xbc66dc: stur            w0, [x1, #0x1b]
    //     0xbc66e0: ldurb           w16, [x1, #-1]
    //     0xbc66e4: ldurb           w17, [x0, #-1]
    //     0xbc66e8: and             x16, x17, x16, lsr #2
    //     0xbc66ec: tst             x16, HEAP, lsr #32
    //     0xbc66f0: b.eq            #0xbc66f8
    //     0xbc66f4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc66f8: r0 = Null
    //     0xbc66f8: mov             x0, NULL
    // 0xbc66fc: LeaveFrame
    //     0xbc66fc: mov             SP, fp
    //     0xbc6700: ldp             fp, lr, [SP], #0x10
    // 0xbc6704: ret
    //     0xbc6704: ret             
    // 0xbc6708: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc6708: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc670c: b               #0xbc64b0
    // 0xbc6710: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc6710: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc6714: SaveReg d2
    //     0xbc6714: str             q2, [SP, #-0x10]!
    // 0xbc6718: r0 = AllocateDouble()
    //     0xbc6718: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc671c: RestoreReg d2
    //     0xbc671c: ldr             q2, [SP], #0x10
    // 0xbc6720: b               #0xbc6664
    // 0xbc6724: SaveReg d2
    //     0xbc6724: str             q2, [SP, #-0x10]!
    // 0xbc6728: r0 = AllocateDouble()
    //     0xbc6728: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc672c: RestoreReg d2
    //     0xbc672c: ldr             q2, [SP], #0x10
    // 0xbc6730: b               #0xbc66d4
  }
  _ _layoutChildren(/* No info */) {
    // ** addr: 0xbc6734, size: 0x208
    // 0xbc6734: EnterFrame
    //     0xbc6734: stp             fp, lr, [SP, #-0x10]!
    //     0xbc6738: mov             fp, SP
    // 0xbc673c: AllocStack(0x28)
    //     0xbc673c: sub             SP, SP, #0x28
    // 0xbc6740: SetupParameters(_RenderTextSelectionToolbarItemsLayout this /* r1 => r1, fp-0x8 */)
    //     0xbc6740: stur            x1, [fp, #-8]
    // 0xbc6744: CheckStackOverflow
    //     0xbc6744: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc6748: cmp             SP, x16
    //     0xbc674c: b.ls            #0xbc6930
    // 0xbc6750: r1 = 4
    //     0xbc6750: mov             x1, #4
    // 0xbc6754: r0 = AllocateContext()
    //     0xbc6754: bl              #0x13de838  ; AllocateContextStub
    // 0xbc6758: mov             x4, x0
    // 0xbc675c: ldur            x3, [fp, #-8]
    // 0xbc6760: stur            x4, [fp, #-0x18]
    // 0xbc6764: StoreField: r4->field_f = r3
    //     0xbc6764: stur            w3, [x4, #0xf]
    // 0xbc6768: LoadField: r0 = r3->field_6b
    //     0xbc6768: ldur            w0, [x3, #0x6b]
    // 0xbc676c: DecompressPointer r0
    //     0xbc676c: add             x0, x0, HEAP, lsl #32
    // 0xbc6770: tbnz            w0, #4, #0xbc67c0
    // 0xbc6774: LoadField: r5 = r3->field_27
    //     0xbc6774: ldur            w5, [x3, #0x27]
    // 0xbc6778: DecompressPointer r5
    //     0xbc6778: add             x5, x5, HEAP, lsl #32
    // 0xbc677c: stur            x5, [fp, #-0x10]
    // 0xbc6780: cmp             w5, NULL
    // 0xbc6784: b.eq            #0xbc68f4
    // 0xbc6788: mov             x0, x5
    // 0xbc678c: r2 = Null
    //     0xbc678c: mov             x2, NULL
    // 0xbc6790: r1 = Null
    //     0xbc6790: mov             x1, NULL
    // 0xbc6794: r4 = LoadClassIdInstr(r0)
    //     0xbc6794: ldur            x4, [x0, #-1]
    //     0xbc6798: ubfx            x4, x4, #0xc, #0x14
    // 0xbc679c: sub             x4, x4, #0xb46
    // 0xbc67a0: cmp             x4, #1
    // 0xbc67a4: b.ls            #0xbc67b8
    // 0xbc67a8: r8 = BoxConstraints
    //     0xbc67a8: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbc67ac: r3 = Null
    //     0xbc67ac: add             x3, PP, #0xcc, lsl #12  ; [pp+0xccee8] Null
    //     0xbc67b0: ldr             x3, [x3, #0xee8]
    // 0xbc67b4: r0 = BoxConstraints()
    //     0xbc67b4: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbc67b8: ldur            x4, [fp, #-0x10]
    // 0xbc67bc: b               #0xbc6834
    // 0xbc67c0: LoadField: r4 = r3->field_27
    //     0xbc67c0: ldur            w4, [x3, #0x27]
    // 0xbc67c4: DecompressPointer r4
    //     0xbc67c4: add             x4, x4, HEAP, lsl #32
    // 0xbc67c8: stur            x4, [fp, #-0x10]
    // 0xbc67cc: cmp             w4, NULL
    // 0xbc67d0: b.eq            #0xbc6910
    // 0xbc67d4: mov             x0, x4
    // 0xbc67d8: r2 = Null
    //     0xbc67d8: mov             x2, NULL
    // 0xbc67dc: r1 = Null
    //     0xbc67dc: mov             x1, NULL
    // 0xbc67e0: r4 = LoadClassIdInstr(r0)
    //     0xbc67e0: ldur            x4, [x0, #-1]
    //     0xbc67e4: ubfx            x4, x4, #0xc, #0x14
    // 0xbc67e8: sub             x4, x4, #0xb46
    // 0xbc67ec: cmp             x4, #1
    // 0xbc67f0: b.ls            #0xbc6804
    // 0xbc67f4: r8 = BoxConstraints
    //     0xbc67f4: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbc67f8: r3 = Null
    //     0xbc67f8: add             x3, PP, #0xcc, lsl #12  ; [pp+0xccef8] Null
    //     0xbc67fc: ldr             x3, [x3, #0xef8]
    // 0xbc6800: r0 = BoxConstraints()
    //     0xbc6800: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbc6804: ldur            x0, [fp, #-0x10]
    // 0xbc6808: LoadField: d0 = r0->field_f
    //     0xbc6808: ldur            d0, [x0, #0xf]
    // 0xbc680c: stur            d0, [fp, #-0x28]
    // 0xbc6810: r0 = BoxConstraints()
    //     0xbc6810: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbc6814: StoreField: r0->field_7 = rZR
    //     0xbc6814: stur            xzr, [x0, #7]
    // 0xbc6818: ldur            d0, [fp, #-0x28]
    // 0xbc681c: StoreField: r0->field_f = d0
    //     0xbc681c: stur            d0, [x0, #0xf]
    // 0xbc6820: ArrayStore: r0[0] = rZR  ; List_8
    //     0xbc6820: stur            xzr, [x0, #0x17]
    // 0xbc6824: d0 = 44.000000
    //     0xbc6824: add             x17, PP, #0x8f, lsl #12  ; [pp+0x8f600] IMM: double(44) from 0x4046000000000000
    //     0xbc6828: ldr             d0, [x17, #0x600]
    // 0xbc682c: StoreField: r0->field_1f = d0
    //     0xbc682c: stur            d0, [x0, #0x1f]
    // 0xbc6830: mov             x4, x0
    // 0xbc6834: ldur            x0, [fp, #-8]
    // 0xbc6838: ldur            x3, [fp, #-0x18]
    // 0xbc683c: r2 = 0.000000
    //     0xbc683c: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbc6840: r1 = -2
    //     0xbc6840: mov             x1, #-2
    // 0xbc6844: stur            x4, [fp, #-0x10]
    // 0xbc6848: StoreField: r3->field_13 = r4
    //     0xbc6848: stur            w4, [x3, #0x13]
    // 0xbc684c: ArrayStore: r3[0] = r1  ; List_4
    //     0xbc684c: stur            w1, [x3, #0x17]
    // 0xbc6850: StoreField: r3->field_1b = r2
    //     0xbc6850: stur            w2, [x3, #0x1b]
    // 0xbc6854: mov             x2, x3
    // 0xbc6858: r1 = Function '<anonymous closure>':.
    //     0xbc6858: add             x1, PP, #0xcc, lsl #12  ; [pp+0xccf08] AnonymousClosure: (0xbc693c), in [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::_layoutChildren (0xbc6734)
    //     0xbc685c: ldr             x1, [x1, #0xf08]
    // 0xbc6860: r0 = AllocateClosure()
    //     0xbc6860: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbc6864: ldur            x1, [fp, #-8]
    // 0xbc6868: mov             x2, x0
    // 0xbc686c: r0 = visitChildren()
    //     0xbc686c: bl              #0xbeef74  ; [dart:mixin_deduplication] _MixinApplication118&RenderBox&ContainerRenderObjectMixin::visitChildren
    // 0xbc6870: ldur            x0, [fp, #-8]
    // 0xbc6874: LoadField: r1 = r0->field_57
    //     0xbc6874: ldur            w1, [x0, #0x57]
    // 0xbc6878: DecompressPointer r1
    //     0xbc6878: add             x1, x1, HEAP, lsl #32
    // 0xbc687c: cmp             w1, NULL
    // 0xbc6880: b.eq            #0xbc6938
    // 0xbc6884: LoadField: r2 = r0->field_5f
    //     0xbc6884: ldur            x2, [x0, #0x5f]
    // 0xbc6888: cmn             x2, #1
    // 0xbc688c: b.eq            #0xbc68e4
    // 0xbc6890: LoadField: r3 = r0->field_4f
    //     0xbc6890: ldur            x3, [x0, #0x4f]
    // 0xbc6894: sub             x4, x3, #2
    // 0xbc6898: cmp             x2, x4
    // 0xbc689c: b.ne            #0xbc68e4
    // 0xbc68a0: ldur            x2, [fp, #-0x18]
    // 0xbc68a4: ldur            x3, [fp, #-0x10]
    // 0xbc68a8: LoadField: r4 = r2->field_1b
    //     0xbc68a8: ldur            w4, [x2, #0x1b]
    // 0xbc68ac: DecompressPointer r4
    //     0xbc68ac: add             x4, x4, HEAP, lsl #32
    // 0xbc68b0: stur            x4, [fp, #-0x20]
    // 0xbc68b4: r0 = size()
    //     0xbc68b4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc68b8: LoadField: d0 = r0->field_7
    //     0xbc68b8: ldur            d0, [x0, #7]
    // 0xbc68bc: ldur            x0, [fp, #-0x20]
    // 0xbc68c0: LoadField: d1 = r0->field_7
    //     0xbc68c0: ldur            d1, [x0, #7]
    // 0xbc68c4: fsub            d2, d1, d0
    // 0xbc68c8: ldur            x0, [fp, #-0x10]
    // 0xbc68cc: LoadField: d0 = r0->field_f
    //     0xbc68cc: ldur            d0, [x0, #0xf]
    // 0xbc68d0: fcmp            d0, d2
    // 0xbc68d4: b.lt            #0xbc68e4
    // 0xbc68d8: ldur            x0, [fp, #-8]
    // 0xbc68dc: r1 = -1
    //     0xbc68dc: mov             x1, #-1
    // 0xbc68e0: StoreField: r0->field_5f = r1
    //     0xbc68e0: stur            x1, [x0, #0x5f]
    // 0xbc68e4: r0 = Null
    //     0xbc68e4: mov             x0, NULL
    // 0xbc68e8: LeaveFrame
    //     0xbc68e8: mov             SP, fp
    //     0xbc68ec: ldp             fp, lr, [SP], #0x10
    // 0xbc68f0: ret
    //     0xbc68f0: ret             
    // 0xbc68f4: r0 = StateError()
    //     0xbc68f4: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc68f8: mov             x1, x0
    // 0xbc68fc: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbc68fc: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbc6900: StoreField: r1->field_b = r0
    //     0xbc6900: stur            w0, [x1, #0xb]
    // 0xbc6904: mov             x0, x1
    // 0xbc6908: r0 = Throw()
    //     0xbc6908: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc690c: brk             #0
    // 0xbc6910: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbc6910: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbc6914: r0 = StateError()
    //     0xbc6914: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc6918: mov             x1, x0
    // 0xbc691c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbc691c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbc6920: StoreField: r1->field_b = r0
    //     0xbc6920: stur            w0, [x1, #0xb]
    // 0xbc6924: mov             x0, x1
    // 0xbc6928: r0 = Throw()
    //     0xbc6928: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc692c: brk             #0
    // 0xbc6930: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc6930: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc6934: b               #0xbc6750
    // 0xbc6938: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc6938: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0xbc693c, size: 0x208
    // 0xbc693c: EnterFrame
    //     0xbc693c: stp             fp, lr, [SP, #-0x10]!
    //     0xbc6940: mov             fp, SP
    // 0xbc6944: AllocStack(0x20)
    //     0xbc6944: sub             SP, SP, #0x20
    // 0xbc6948: SetupParameters([dynamic _ /* r0 */])
    //     0xbc6948: ldr             x0, [fp, #0x18]
    //     0xbc694c: ldur            w3, [x0, #0x17]
    //     0xbc6950: add             x3, x3, HEAP, lsl #32
    //     0xbc6954: stur            x3, [fp, #-8]
    // 0xbc6958: CheckStackOverflow
    //     0xbc6958: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc695c: cmp             SP, x16
    //     0xbc6960: b.ls            #0xbc6b2c
    // 0xbc6964: ArrayLoad: r0 = r3[0]  ; List_4
    //     0xbc6964: ldur            w0, [x3, #0x17]
    // 0xbc6968: DecompressPointer r0
    //     0xbc6968: add             x0, x0, HEAP, lsl #32
    // 0xbc696c: r1 = LoadInt32Instr(r0)
    //     0xbc696c: sbfx            x1, x0, #1, #0x1f
    //     0xbc6970: tbz             w0, #0, #0xbc6978
    //     0xbc6974: ldur            x1, [x0, #7]
    // 0xbc6978: add             x2, x1, #1
    // 0xbc697c: r0 = BoxInt64Instr(r2)
    //     0xbc697c: sbfiz           x0, x2, #1, #0x1f
    //     0xbc6980: cmp             x2, x0, asr #1
    //     0xbc6984: b.eq            #0xbc6990
    //     0xbc6988: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbc698c: stur            x2, [x0, #7]
    // 0xbc6990: ArrayStore: r3[0] = r0  ; List_4
    //     0xbc6990: stur            w0, [x3, #0x17]
    //     0xbc6994: tbz             w0, #0, #0xbc69b0
    //     0xbc6998: ldurb           w16, [x3, #-1]
    //     0xbc699c: ldurb           w17, [x0, #-1]
    //     0xbc69a0: and             x16, x17, x16, lsr #2
    //     0xbc69a4: tst             x16, HEAP, lsr #32
    //     0xbc69a8: b.eq            #0xbc69b0
    //     0xbc69ac: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbc69b0: LoadField: r0 = r3->field_f
    //     0xbc69b0: ldur            w0, [x3, #0xf]
    // 0xbc69b4: DecompressPointer r0
    //     0xbc69b4: add             x0, x0, HEAP, lsl #32
    // 0xbc69b8: LoadField: r1 = r0->field_5f
    //     0xbc69b8: ldur            x1, [x0, #0x5f]
    // 0xbc69bc: cmn             x1, #1
    // 0xbc69c0: b.eq            #0xbc69e0
    // 0xbc69c4: LoadField: r1 = r0->field_6b
    //     0xbc69c4: ldur            w1, [x0, #0x6b]
    // 0xbc69c8: DecompressPointer r1
    //     0xbc69c8: add             x1, x1, HEAP, lsl #32
    // 0xbc69cc: tbz             w1, #4, #0xbc69e0
    // 0xbc69d0: r0 = Null
    //     0xbc69d0: mov             x0, NULL
    // 0xbc69d4: LeaveFrame
    //     0xbc69d4: mov             SP, fp
    //     0xbc69d8: ldp             fp, lr, [SP], #0x10
    // 0xbc69dc: ret
    //     0xbc69dc: ret             
    // 0xbc69e0: ldr             x4, [fp, #0x10]
    // 0xbc69e4: mov             x0, x4
    // 0xbc69e8: r2 = Null
    //     0xbc69e8: mov             x2, NULL
    // 0xbc69ec: r1 = Null
    //     0xbc69ec: mov             x1, NULL
    // 0xbc69f0: r4 = LoadClassIdInstr(r0)
    //     0xbc69f0: ldur            x4, [x0, #-1]
    //     0xbc69f4: ubfx            x4, x4, #0xc, #0x14
    // 0xbc69f8: r17 = -4710
    //     0xbc69f8: mov             x17, #-0x1266
    // 0xbc69fc: add             x4, x4, x17
    // 0xbc6a00: cmp             x4, #0x109
    // 0xbc6a04: b.ls            #0xbc6a18
    // 0xbc6a08: r8 = RenderBox
    //     0xbc6a08: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbc6a0c: r3 = Null
    //     0xbc6a0c: add             x3, PP, #0xcc, lsl #12  ; [pp+0xccf10] Null
    //     0xbc6a10: ldr             x3, [x3, #0xf10]
    // 0xbc6a14: r0 = RenderBox()
    //     0xbc6a14: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbc6a18: ldur            x0, [fp, #-8]
    // 0xbc6a1c: LoadField: r2 = r0->field_13
    //     0xbc6a1c: ldur            w2, [x0, #0x13]
    // 0xbc6a20: DecompressPointer r2
    //     0xbc6a20: add             x2, x2, HEAP, lsl #32
    // 0xbc6a24: mov             x1, x2
    // 0xbc6a28: stur            x2, [fp, #-0x10]
    // 0xbc6a2c: r0 = loosen()
    //     0xbc6a2c: bl              #0xb4ae38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0xbc6a30: ldr             x3, [fp, #0x10]
    // 0xbc6a34: r1 = LoadClassIdInstr(r3)
    //     0xbc6a34: ldur            x1, [x3, #-1]
    //     0xbc6a38: ubfx            x1, x1, #0xc, #0x14
    // 0xbc6a3c: r16 = true
    //     0xbc6a3c: add             x16, NULL, #0x20  ; true
    // 0xbc6a40: str             x16, [SP]
    // 0xbc6a44: mov             x2, x0
    // 0xbc6a48: mov             x0, x1
    // 0xbc6a4c: mov             x1, x3
    // 0xbc6a50: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbc6a50: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbc6a54: ldr             x4, [x4, #0xed0]
    // 0xbc6a58: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbc6a58: mov             x17, #0xe6b9
    //     0xbc6a5c: add             lr, x0, x17
    //     0xbc6a60: ldr             lr, [x21, lr, lsl #3]
    //     0xbc6a64: blr             lr
    // 0xbc6a68: ldur            x0, [fp, #-8]
    // 0xbc6a6c: LoadField: r2 = r0->field_1b
    //     0xbc6a6c: ldur            w2, [x0, #0x1b]
    // 0xbc6a70: DecompressPointer r2
    //     0xbc6a70: add             x2, x2, HEAP, lsl #32
    // 0xbc6a74: ldr             x1, [fp, #0x10]
    // 0xbc6a78: stur            x2, [fp, #-0x18]
    // 0xbc6a7c: r0 = size()
    //     0xbc6a7c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc6a80: LoadField: d0 = r0->field_7
    //     0xbc6a80: ldur            d0, [x0, #7]
    // 0xbc6a84: ldur            x1, [fp, #-0x18]
    // 0xbc6a88: LoadField: d1 = r1->field_7
    //     0xbc6a88: ldur            d1, [x1, #7]
    // 0xbc6a8c: fadd            d2, d1, d0
    // 0xbc6a90: r0 = inline_Allocate_Double()
    //     0xbc6a90: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbc6a94: add             x0, x0, #0x10
    //     0xbc6a98: cmp             x1, x0
    //     0xbc6a9c: b.ls            #0xbc6b34
    //     0xbc6aa0: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc6aa4: sub             x0, x0, #0xf
    //     0xbc6aa8: mov             x1, #0xe19c
    //     0xbc6aac: movk            x1, #3, lsl #16
    //     0xbc6ab0: stur            x1, [x0, #-1]
    // 0xbc6ab4: dmb             ishst
    // 0xbc6ab8: StoreField: r0->field_7 = d2
    //     0xbc6ab8: stur            d2, [x0, #7]
    // 0xbc6abc: ldur            x1, [fp, #-8]
    // 0xbc6ac0: StoreField: r1->field_1b = r0
    //     0xbc6ac0: stur            w0, [x1, #0x1b]
    //     0xbc6ac4: ldurb           w16, [x1, #-1]
    //     0xbc6ac8: ldurb           w17, [x0, #-1]
    //     0xbc6acc: and             x16, x17, x16, lsr #2
    //     0xbc6ad0: tst             x16, HEAP, lsr #32
    //     0xbc6ad4: b.eq            #0xbc6adc
    //     0xbc6ad8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc6adc: ldur            x2, [fp, #-0x10]
    // 0xbc6ae0: LoadField: d0 = r2->field_f
    //     0xbc6ae0: ldur            d0, [x2, #0xf]
    // 0xbc6ae4: fcmp            d2, d0
    // 0xbc6ae8: b.le            #0xbc6b1c
    // 0xbc6aec: LoadField: r2 = r1->field_f
    //     0xbc6aec: ldur            w2, [x1, #0xf]
    // 0xbc6af0: DecompressPointer r2
    //     0xbc6af0: add             x2, x2, HEAP, lsl #32
    // 0xbc6af4: LoadField: r3 = r2->field_5f
    //     0xbc6af4: ldur            x3, [x2, #0x5f]
    // 0xbc6af8: cmn             x3, #1
    // 0xbc6afc: b.ne            #0xbc6b1c
    // 0xbc6b00: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xbc6b00: ldur            w3, [x1, #0x17]
    // 0xbc6b04: DecompressPointer r3
    //     0xbc6b04: add             x3, x3, HEAP, lsl #32
    // 0xbc6b08: r1 = LoadInt32Instr(r3)
    //     0xbc6b08: sbfx            x1, x3, #1, #0x1f
    //     0xbc6b0c: tbz             w3, #0, #0xbc6b14
    //     0xbc6b10: ldur            x1, [x3, #7]
    // 0xbc6b14: sub             x3, x1, #1
    // 0xbc6b18: StoreField: r2->field_5f = r3
    //     0xbc6b18: stur            x3, [x2, #0x5f]
    // 0xbc6b1c: r0 = Null
    //     0xbc6b1c: mov             x0, NULL
    // 0xbc6b20: LeaveFrame
    //     0xbc6b20: mov             SP, fp
    //     0xbc6b24: ldp             fp, lr, [SP], #0x10
    // 0xbc6b28: ret
    //     0xbc6b28: ret             
    // 0xbc6b2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc6b2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc6b30: b               #0xbc6964
    // 0xbc6b34: SaveReg d2
    //     0xbc6b34: str             q2, [SP, #-0x10]!
    // 0xbc6b38: r0 = AllocateDouble()
    //     0xbc6b38: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc6b3c: RestoreReg d2
    //     0xbc6b3c: ldr             q2, [SP], #0x10
    // 0xbc6b40: b               #0xbc6ab8
  }
  _ visitChildrenForSemantics(/* No info */) {
    // ** addr: 0xbebfa8, size: 0x68
    // 0xbebfa8: EnterFrame
    //     0xbebfa8: stp             fp, lr, [SP, #-0x10]!
    //     0xbebfac: mov             fp, SP
    // 0xbebfb0: AllocStack(0x10)
    //     0xbebfb0: sub             SP, SP, #0x10
    // 0xbebfb4: SetupParameters(_RenderTextSelectionToolbarItemsLayout this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xbebfb4: stur            x1, [fp, #-8]
    //     0xbebfb8: stur            x2, [fp, #-0x10]
    // 0xbebfbc: CheckStackOverflow
    //     0xbebfbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbebfc0: cmp             SP, x16
    //     0xbebfc4: b.ls            #0xbec008
    // 0xbebfc8: r1 = 1
    //     0xbebfc8: mov             x1, #1
    // 0xbebfcc: r0 = AllocateContext()
    //     0xbebfcc: bl              #0x13de838  ; AllocateContextStub
    // 0xbebfd0: mov             x1, x0
    // 0xbebfd4: ldur            x0, [fp, #-0x10]
    // 0xbebfd8: StoreField: r1->field_f = r0
    //     0xbebfd8: stur            w0, [x1, #0xf]
    // 0xbebfdc: mov             x2, x1
    // 0xbebfe0: r1 = Function '<anonymous closure>':.
    //     0xbebfe0: add             x1, PP, #0xcc, lsl #12  ; [pp+0xccd90] AnonymousClosure: (0xbec010), in [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::visitChildrenForSemantics (0xbebfa8)
    //     0xbebfe4: ldr             x1, [x1, #0xd90]
    // 0xbebfe8: r0 = AllocateClosure()
    //     0xbebfe8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbebfec: ldur            x1, [fp, #-8]
    // 0xbebff0: mov             x2, x0
    // 0xbebff4: r0 = visitChildren()
    //     0xbebff4: bl              #0xbeef74  ; [dart:mixin_deduplication] _MixinApplication118&RenderBox&ContainerRenderObjectMixin::visitChildren
    // 0xbebff8: r0 = Null
    //     0xbebff8: mov             x0, NULL
    // 0xbebffc: LeaveFrame
    //     0xbebffc: mov             SP, fp
    //     0xbec000: ldp             fp, lr, [SP], #0x10
    // 0xbec004: ret
    //     0xbec004: ret             
    // 0xbec008: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbec008: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbec00c: b               #0xbebfc8
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0xbec010, size: 0xf8
    // 0xbec010: EnterFrame
    //     0xbec010: stp             fp, lr, [SP, #-0x10]!
    //     0xbec014: mov             fp, SP
    // 0xbec018: AllocStack(0x20)
    //     0xbec018: sub             SP, SP, #0x20
    // 0xbec01c: SetupParameters([dynamic _ /* r0 */])
    //     0xbec01c: ldr             x0, [fp, #0x18]
    //     0xbec020: ldur            w3, [x0, #0x17]
    //     0xbec024: add             x3, x3, HEAP, lsl #32
    //     0xbec028: stur            x3, [fp, #-8]
    // 0xbec02c: CheckStackOverflow
    //     0xbec02c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbec030: cmp             SP, x16
    //     0xbec034: b.ls            #0xbec0fc
    // 0xbec038: ldr             x0, [fp, #0x10]
    // 0xbec03c: r2 = Null
    //     0xbec03c: mov             x2, NULL
    // 0xbec040: r1 = Null
    //     0xbec040: mov             x1, NULL
    // 0xbec044: r4 = LoadClassIdInstr(r0)
    //     0xbec044: ldur            x4, [x0, #-1]
    //     0xbec048: ubfx            x4, x4, #0xc, #0x14
    // 0xbec04c: r17 = -4710
    //     0xbec04c: mov             x17, #-0x1266
    // 0xbec050: add             x4, x4, x17
    // 0xbec054: cmp             x4, #0x109
    // 0xbec058: b.ls            #0xbec06c
    // 0xbec05c: r8 = RenderBox
    //     0xbec05c: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbec060: r3 = Null
    //     0xbec060: add             x3, PP, #0xcc, lsl #12  ; [pp+0xccd98] Null
    //     0xbec064: ldr             x3, [x3, #0xd98]
    // 0xbec068: r0 = RenderBox()
    //     0xbec068: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbec06c: ldr             x3, [fp, #0x10]
    // 0xbec070: LoadField: r4 = r3->field_7
    //     0xbec070: ldur            w4, [x3, #7]
    // 0xbec074: DecompressPointer r4
    //     0xbec074: add             x4, x4, HEAP, lsl #32
    // 0xbec078: stur            x4, [fp, #-0x10]
    // 0xbec07c: cmp             w4, NULL
    // 0xbec080: b.eq            #0xbec104
    // 0xbec084: mov             x0, x4
    // 0xbec088: r2 = Null
    //     0xbec088: mov             x2, NULL
    // 0xbec08c: r1 = Null
    //     0xbec08c: mov             x1, NULL
    // 0xbec090: r4 = LoadClassIdInstr(r0)
    //     0xbec090: ldur            x4, [x0, #-1]
    //     0xbec094: ubfx            x4, x4, #0xc, #0x14
    // 0xbec098: r17 = 4205
    //     0xbec098: mov             x17, #0x106d
    // 0xbec09c: cmp             x4, x17
    // 0xbec0a0: b.eq            #0xbec0b8
    // 0xbec0a4: r8 = ToolbarItemsParentData
    //     0xbec0a4: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0xbec0a8: ldr             x8, [x8, #0x6c0]
    // 0xbec0ac: r3 = Null
    //     0xbec0ac: add             x3, PP, #0xcc, lsl #12  ; [pp+0xccda8] Null
    //     0xbec0b0: ldr             x3, [x3, #0xda8]
    // 0xbec0b4: r0 = DefaultTypeTest()
    //     0xbec0b4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbec0b8: ldur            x0, [fp, #-0x10]
    // 0xbec0bc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbec0bc: ldur            w1, [x0, #0x17]
    // 0xbec0c0: DecompressPointer r1
    //     0xbec0c0: add             x1, x1, HEAP, lsl #32
    // 0xbec0c4: tbnz            w1, #4, #0xbec0ec
    // 0xbec0c8: ldur            x0, [fp, #-8]
    // 0xbec0cc: LoadField: r1 = r0->field_f
    //     0xbec0cc: ldur            w1, [x0, #0xf]
    // 0xbec0d0: DecompressPointer r1
    //     0xbec0d0: add             x1, x1, HEAP, lsl #32
    // 0xbec0d4: ldr             x16, [fp, #0x10]
    // 0xbec0d8: stp             x16, x1, [SP]
    // 0xbec0dc: mov             x0, x1
    // 0xbec0e0: ClosureCall
    //     0xbec0e0: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbec0e4: ldur            x2, [x0, #0x1f]
    //     0xbec0e8: blr             x2
    // 0xbec0ec: r0 = Null
    //     0xbec0ec: mov             x0, NULL
    // 0xbec0f0: LeaveFrame
    //     0xbec0f0: mov             SP, fp
    //     0xbec0f4: ldp             fp, lr, [SP], #0x10
    // 0xbec0f8: ret
    //     0xbec0f8: ret             
    // 0xbec0fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbec0fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbec100: b               #0xbec038
    // 0xbec104: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbec104: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0xc0dc1c, size: 0xc0
    // 0xc0dc1c: EnterFrame
    //     0xc0dc1c: stp             fp, lr, [SP, #-0x10]!
    //     0xc0dc20: mov             fp, SP
    // 0xc0dc24: AllocStack(0x8)
    //     0xc0dc24: sub             SP, SP, #8
    // 0xc0dc28: SetupParameters(_RenderTextSelectionToolbarItemsLayout this /* r1 => r4 */, dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xc0dc28: mov             x0, x2
    //     0xc0dc2c: mov             x4, x1
    //     0xc0dc30: mov             x3, x2
    //     0xc0dc34: stur            x2, [fp, #-8]
    // 0xc0dc38: r2 = Null
    //     0xc0dc38: mov             x2, NULL
    // 0xc0dc3c: r1 = Null
    //     0xc0dc3c: mov             x1, NULL
    // 0xc0dc40: r4 = 60
    //     0xc0dc40: mov             x4, #0x3c
    // 0xc0dc44: branchIfSmi(r0, 0xc0dc50)
    //     0xc0dc44: tbz             w0, #0, #0xc0dc50
    // 0xc0dc48: r4 = LoadClassIdInstr(r0)
    //     0xc0dc48: ldur            x4, [x0, #-1]
    //     0xc0dc4c: ubfx            x4, x4, #0xc, #0x14
    // 0xc0dc50: r17 = -4710
    //     0xc0dc50: mov             x17, #-0x1266
    // 0xc0dc54: add             x4, x4, x17
    // 0xc0dc58: cmp             x4, #0x109
    // 0xc0dc5c: b.ls            #0xc0dc70
    // 0xc0dc60: r8 = RenderBox
    //     0xc0dc60: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xc0dc64: r3 = Null
    //     0xc0dc64: add             x3, PP, #0xcc, lsl #12  ; [pp+0xccdc8] Null
    //     0xc0dc68: ldr             x3, [x3, #0xdc8]
    // 0xc0dc6c: r0 = RenderBox()
    //     0xc0dc6c: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xc0dc70: ldur            x0, [fp, #-8]
    // 0xc0dc74: LoadField: r1 = r0->field_7
    //     0xc0dc74: ldur            w1, [x0, #7]
    // 0xc0dc78: DecompressPointer r1
    //     0xc0dc78: add             x1, x1, HEAP, lsl #32
    // 0xc0dc7c: r2 = LoadClassIdInstr(r1)
    //     0xc0dc7c: ldur            x2, [x1, #-1]
    //     0xc0dc80: ubfx            x2, x2, #0xc, #0x14
    // 0xc0dc84: r17 = 4205
    //     0xc0dc84: mov             x17, #0x106d
    // 0xc0dc88: cmp             x2, x17
    // 0xc0dc8c: b.eq            #0xc0dccc
    // 0xc0dc90: r1 = <RenderBox>
    //     0xc0dc90: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c8] TypeArguments: <RenderBox>
    //     0xc0dc94: ldr             x1, [x1, #0x5c8]
    // 0xc0dc98: r0 = ToolbarItemsParentData()
    //     0xc0dc98: bl              #0xc0d6f8  ; AllocateToolbarItemsParentDataStub -> ToolbarItemsParentData (size=0x1c)
    // 0xc0dc9c: r1 = false
    //     0xc0dc9c: add             x1, NULL, #0x30  ; false
    // 0xc0dca0: ArrayStore: r0[0] = r1  ; List_4
    //     0xc0dca0: stur            w1, [x0, #0x17]
    // 0xc0dca4: r1 = Instance_Offset
    //     0xc0dca4: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc0dca8: StoreField: r0->field_7 = r1
    //     0xc0dca8: stur            w1, [x0, #7]
    // 0xc0dcac: ldur            x1, [fp, #-8]
    // 0xc0dcb0: StoreField: r1->field_7 = r0
    //     0xc0dcb0: stur            w0, [x1, #7]
    //     0xc0dcb4: ldurb           w16, [x1, #-1]
    //     0xc0dcb8: ldurb           w17, [x0, #-1]
    //     0xc0dcbc: and             x16, x17, x16, lsr #2
    //     0xc0dcc0: tst             x16, HEAP, lsr #32
    //     0xc0dcc4: b.eq            #0xc0dccc
    //     0xc0dcc8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc0dccc: r0 = Null
    //     0xc0dccc: mov             x0, NULL
    // 0xc0dcd0: LeaveFrame
    //     0xc0dcd0: mov             SP, fp
    //     0xc0dcd4: ldp             fp, lr, [SP], #0x10
    // 0xc0dcd8: ret
    //     0xc0dcd8: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0xc25858, size: 0x74
    // 0xc25858: EnterFrame
    //     0xc25858: stp             fp, lr, [SP, #-0x10]!
    //     0xc2585c: mov             fp, SP
    // 0xc25860: AllocStack(0x18)
    //     0xc25860: sub             SP, SP, #0x18
    // 0xc25864: SetupParameters(_RenderTextSelectionToolbarItemsLayout this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xc25864: stur            x1, [fp, #-8]
    //     0xc25868: stur            x2, [fp, #-0x10]
    //     0xc2586c: stur            x3, [fp, #-0x18]
    // 0xc25870: CheckStackOverflow
    //     0xc25870: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc25874: cmp             SP, x16
    //     0xc25878: b.ls            #0xc258c4
    // 0xc2587c: r1 = 2
    //     0xc2587c: mov             x1, #2
    // 0xc25880: r0 = AllocateContext()
    //     0xc25880: bl              #0x13de838  ; AllocateContextStub
    // 0xc25884: mov             x1, x0
    // 0xc25888: ldur            x0, [fp, #-0x10]
    // 0xc2588c: StoreField: r1->field_f = r0
    //     0xc2588c: stur            w0, [x1, #0xf]
    // 0xc25890: ldur            x0, [fp, #-0x18]
    // 0xc25894: StoreField: r1->field_13 = r0
    //     0xc25894: stur            w0, [x1, #0x13]
    // 0xc25898: mov             x2, x1
    // 0xc2589c: r1 = Function '<anonymous closure>':.
    //     0xc2589c: add             x1, PP, #0xcc, lsl #12  ; [pp+0xccdd8] AnonymousClosure: (0xc258cc), in [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::paint (0xc25858)
    //     0xc258a0: ldr             x1, [x1, #0xdd8]
    // 0xc258a4: r0 = AllocateClosure()
    //     0xc258a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc258a8: ldur            x1, [fp, #-8]
    // 0xc258ac: mov             x2, x0
    // 0xc258b0: r0 = visitChildren()
    //     0xc258b0: bl              #0xbeef74  ; [dart:mixin_deduplication] _MixinApplication118&RenderBox&ContainerRenderObjectMixin::visitChildren
    // 0xc258b4: r0 = Null
    //     0xc258b4: mov             x0, NULL
    // 0xc258b8: LeaveFrame
    //     0xc258b8: mov             SP, fp
    //     0xc258bc: ldp             fp, lr, [SP], #0x10
    // 0xc258c0: ret
    //     0xc258c0: ret             
    // 0xc258c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc258c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc258c8: b               #0xc2587c
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0xc258cc, size: 0x120
    // 0xc258cc: EnterFrame
    //     0xc258cc: stp             fp, lr, [SP, #-0x10]!
    //     0xc258d0: mov             fp, SP
    // 0xc258d4: AllocStack(0x18)
    //     0xc258d4: sub             SP, SP, #0x18
    // 0xc258d8: SetupParameters([dynamic _ /* r0 */])
    //     0xc258d8: ldr             x0, [fp, #0x18]
    //     0xc258dc: ldur            w3, [x0, #0x17]
    //     0xc258e0: add             x3, x3, HEAP, lsl #32
    //     0xc258e4: stur            x3, [fp, #-8]
    // 0xc258e8: CheckStackOverflow
    //     0xc258e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc258ec: cmp             SP, x16
    //     0xc258f0: b.ls            #0xc259e0
    // 0xc258f4: ldr             x0, [fp, #0x10]
    // 0xc258f8: r2 = Null
    //     0xc258f8: mov             x2, NULL
    // 0xc258fc: r1 = Null
    //     0xc258fc: mov             x1, NULL
    // 0xc25900: r4 = LoadClassIdInstr(r0)
    //     0xc25900: ldur            x4, [x0, #-1]
    //     0xc25904: ubfx            x4, x4, #0xc, #0x14
    // 0xc25908: r17 = -4710
    //     0xc25908: mov             x17, #-0x1266
    // 0xc2590c: add             x4, x4, x17
    // 0xc25910: cmp             x4, #0x109
    // 0xc25914: b.ls            #0xc25928
    // 0xc25918: r8 = RenderBox
    //     0xc25918: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xc2591c: r3 = Null
    //     0xc2591c: add             x3, PP, #0xcc, lsl #12  ; [pp+0xccde0] Null
    //     0xc25920: ldr             x3, [x3, #0xde0]
    // 0xc25924: r0 = RenderBox()
    //     0xc25924: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xc25928: ldr             x3, [fp, #0x10]
    // 0xc2592c: LoadField: r4 = r3->field_7
    //     0xc2592c: ldur            w4, [x3, #7]
    // 0xc25930: DecompressPointer r4
    //     0xc25930: add             x4, x4, HEAP, lsl #32
    // 0xc25934: stur            x4, [fp, #-0x10]
    // 0xc25938: cmp             w4, NULL
    // 0xc2593c: b.eq            #0xc259e8
    // 0xc25940: mov             x0, x4
    // 0xc25944: r2 = Null
    //     0xc25944: mov             x2, NULL
    // 0xc25948: r1 = Null
    //     0xc25948: mov             x1, NULL
    // 0xc2594c: r4 = LoadClassIdInstr(r0)
    //     0xc2594c: ldur            x4, [x0, #-1]
    //     0xc25950: ubfx            x4, x4, #0xc, #0x14
    // 0xc25954: r17 = 4205
    //     0xc25954: mov             x17, #0x106d
    // 0xc25958: cmp             x4, x17
    // 0xc2595c: b.eq            #0xc25974
    // 0xc25960: r8 = ToolbarItemsParentData
    //     0xc25960: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0xc25964: ldr             x8, [x8, #0x6c0]
    // 0xc25968: r3 = Null
    //     0xc25968: add             x3, PP, #0xcc, lsl #12  ; [pp+0xccdf0] Null
    //     0xc2596c: ldr             x3, [x3, #0xdf0]
    // 0xc25970: r0 = DefaultTypeTest()
    //     0xc25970: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc25974: ldur            x0, [fp, #-0x10]
    // 0xc25978: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc25978: ldur            w1, [x0, #0x17]
    // 0xc2597c: DecompressPointer r1
    //     0xc2597c: add             x1, x1, HEAP, lsl #32
    // 0xc25980: tbz             w1, #4, #0xc25994
    // 0xc25984: r0 = Null
    //     0xc25984: mov             x0, NULL
    // 0xc25988: LeaveFrame
    //     0xc25988: mov             SP, fp
    //     0xc2598c: ldp             fp, lr, [SP], #0x10
    // 0xc25990: ret
    //     0xc25990: ret             
    // 0xc25994: ldur            x1, [fp, #-8]
    // 0xc25998: LoadField: r3 = r1->field_f
    //     0xc25998: ldur            w3, [x1, #0xf]
    // 0xc2599c: DecompressPointer r3
    //     0xc2599c: add             x3, x3, HEAP, lsl #32
    // 0xc259a0: stur            x3, [fp, #-0x18]
    // 0xc259a4: LoadField: r2 = r0->field_7
    //     0xc259a4: ldur            w2, [x0, #7]
    // 0xc259a8: DecompressPointer r2
    //     0xc259a8: add             x2, x2, HEAP, lsl #32
    // 0xc259ac: LoadField: r0 = r1->field_13
    //     0xc259ac: ldur            w0, [x1, #0x13]
    // 0xc259b0: DecompressPointer r0
    //     0xc259b0: add             x0, x0, HEAP, lsl #32
    // 0xc259b4: mov             x1, x2
    // 0xc259b8: mov             x2, x0
    // 0xc259bc: r0 = +()
    //     0xc259bc: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc259c0: ldur            x1, [fp, #-0x18]
    // 0xc259c4: ldr             x2, [fp, #0x10]
    // 0xc259c8: mov             x3, x0
    // 0xc259cc: r0 = paintChild()
    //     0xc259cc: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xc259d0: r0 = Null
    //     0xc259d0: mov             x0, NULL
    // 0xc259d4: LeaveFrame
    //     0xc259d4: mov             SP, fp
    //     0xc259d8: ldp             fp, lr, [SP], #0x10
    // 0xc259dc: ret
    //     0xc259dc: ret             
    // 0xc259e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc259e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc259e4: b               #0xc258f4
    // 0xc259e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc259e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ overflowOpen=(/* No info */) {
    // ** addr: 0xceeaac, size: 0x54
    // 0xceeaac: EnterFrame
    //     0xceeaac: stp             fp, lr, [SP, #-0x10]!
    //     0xceeab0: mov             fp, SP
    // 0xceeab4: CheckStackOverflow
    //     0xceeab4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xceeab8: cmp             SP, x16
    //     0xceeabc: b.ls            #0xceeaf8
    // 0xceeac0: LoadField: r0 = r1->field_6b
    //     0xceeac0: ldur            w0, [x1, #0x6b]
    // 0xceeac4: DecompressPointer r0
    //     0xceeac4: add             x0, x0, HEAP, lsl #32
    // 0xceeac8: cmp             w2, w0
    // 0xceeacc: b.ne            #0xceeae0
    // 0xceead0: r0 = Null
    //     0xceead0: mov             x0, NULL
    // 0xceead4: LeaveFrame
    //     0xceead4: mov             SP, fp
    //     0xceead8: ldp             fp, lr, [SP], #0x10
    // 0xceeadc: ret
    //     0xceeadc: ret             
    // 0xceeae0: StoreField: r1->field_6b = r2
    //     0xceeae0: stur            w2, [x1, #0x6b]
    // 0xceeae4: r0 = markNeedsLayout()
    //     0xceeae4: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xceeae8: r0 = Null
    //     0xceeae8: mov             x0, NULL
    // 0xceeaec: LeaveFrame
    //     0xceeaec: mov             SP, fp
    //     0xceeaf0: ldp             fp, lr, [SP], #0x10
    // 0xceeaf4: ret
    //     0xceeaf4: ret             
    // 0xceeaf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xceeaf8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xceeafc: b               #0xceeac0
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0xceeb00, size: 0x70
    // 0xceeb00: EnterFrame
    //     0xceeb00: stp             fp, lr, [SP, #-0x10]!
    //     0xceeb04: mov             fp, SP
    // 0xceeb08: mov             x0, x2
    // 0xceeb0c: CheckStackOverflow
    //     0xceeb0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xceeb10: cmp             SP, x16
    //     0xceeb14: b.ls            #0xceeb68
    // 0xceeb18: LoadField: r2 = r1->field_6f
    //     0xceeb18: ldur            w2, [x1, #0x6f]
    // 0xceeb1c: DecompressPointer r2
    //     0xceeb1c: add             x2, x2, HEAP, lsl #32
    // 0xceeb20: cmp             w0, w2
    // 0xceeb24: b.ne            #0xceeb38
    // 0xceeb28: r0 = Null
    //     0xceeb28: mov             x0, NULL
    // 0xceeb2c: LeaveFrame
    //     0xceeb2c: mov             SP, fp
    //     0xceeb30: ldp             fp, lr, [SP], #0x10
    // 0xceeb34: ret
    //     0xceeb34: ret             
    // 0xceeb38: StoreField: r1->field_6f = r0
    //     0xceeb38: stur            w0, [x1, #0x6f]
    //     0xceeb3c: ldurb           w16, [x1, #-1]
    //     0xceeb40: ldurb           w17, [x0, #-1]
    //     0xceeb44: and             x16, x17, x16, lsr #2
    //     0xceeb48: tst             x16, HEAP, lsr #32
    //     0xceeb4c: b.eq            #0xceeb54
    //     0xceeb50: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xceeb54: r0 = markNeedsLayout()
    //     0xceeb54: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xceeb58: r0 = Null
    //     0xceeb58: mov             x0, NULL
    // 0xceeb5c: LeaveFrame
    //     0xceeb5c: mov             SP, fp
    //     0xceeb60: ldp             fp, lr, [SP], #0x10
    // 0xceeb64: ret
    //     0xceeb64: ret             
    // 0xceeb68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xceeb68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xceeb6c: b               #0xceeb18
  }
  set _ isAbove=(/* No info */) {
    // ** addr: 0xceeb70, size: 0x54
    // 0xceeb70: EnterFrame
    //     0xceeb70: stp             fp, lr, [SP, #-0x10]!
    //     0xceeb74: mov             fp, SP
    // 0xceeb78: CheckStackOverflow
    //     0xceeb78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xceeb7c: cmp             SP, x16
    //     0xceeb80: b.ls            #0xceebbc
    // 0xceeb84: LoadField: r0 = r1->field_67
    //     0xceeb84: ldur            w0, [x1, #0x67]
    // 0xceeb88: DecompressPointer r0
    //     0xceeb88: add             x0, x0, HEAP, lsl #32
    // 0xceeb8c: cmp             w2, w0
    // 0xceeb90: b.ne            #0xceeba4
    // 0xceeb94: r0 = Null
    //     0xceeb94: mov             x0, NULL
    // 0xceeb98: LeaveFrame
    //     0xceeb98: mov             SP, fp
    //     0xceeb9c: ldp             fp, lr, [SP], #0x10
    // 0xceeba0: ret
    //     0xceeba0: ret             
    // 0xceeba4: StoreField: r1->field_67 = r2
    //     0xceeba4: stur            w2, [x1, #0x67]
    // 0xceeba8: r0 = markNeedsLayout()
    //     0xceeba8: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xceebac: r0 = Null
    //     0xceebac: mov             x0, NULL
    // 0xceebb0: LeaveFrame
    //     0xceebb0: mov             SP, fp
    //     0xceebb4: ldp             fp, lr, [SP], #0x10
    // 0xceebb8: ret
    //     0xceebb8: ret             
    // 0xceebbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xceebbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xceebc0: b               #0xceeb84
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x10eafd4, size: 0x170
    // 0x10eafd4: EnterFrame
    //     0x10eafd4: stp             fp, lr, [SP, #-0x10]!
    //     0x10eafd8: mov             fp, SP
    // 0x10eafdc: AllocStack(0x28)
    //     0x10eafdc: sub             SP, SP, #0x28
    // 0x10eafe0: SetupParameters(dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x10eafe0: mov             x4, x2
    //     0x10eafe4: stur            x2, [fp, #-0x18]
    //     0x10eafe8: stur            x3, [fp, #-0x20]
    // 0x10eafec: CheckStackOverflow
    //     0x10eafec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10eaff0: cmp             SP, x16
    //     0x10eaff4: b.ls            #0x10eb130
    // 0x10eaff8: LoadField: r0 = r1->field_5b
    //     0x10eaff8: ldur            w0, [x1, #0x5b]
    // 0x10eaffc: DecompressPointer r0
    //     0x10eaffc: add             x0, x0, HEAP, lsl #32
    // 0x10eb000: mov             x5, x0
    // 0x10eb004: stur            x5, [fp, #-0x10]
    // 0x10eb008: CheckStackOverflow
    //     0x10eb008: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10eb00c: cmp             SP, x16
    //     0x10eb010: b.ls            #0x10eb138
    // 0x10eb014: cmp             w5, NULL
    // 0x10eb018: b.eq            #0x10eb120
    // 0x10eb01c: LoadField: r6 = r5->field_7
    //     0x10eb01c: ldur            w6, [x5, #7]
    // 0x10eb020: DecompressPointer r6
    //     0x10eb020: add             x6, x6, HEAP, lsl #32
    // 0x10eb024: stur            x6, [fp, #-8]
    // 0x10eb028: cmp             w6, NULL
    // 0x10eb02c: b.eq            #0x10eb140
    // 0x10eb030: mov             x0, x6
    // 0x10eb034: r2 = Null
    //     0x10eb034: mov             x2, NULL
    // 0x10eb038: r1 = Null
    //     0x10eb038: mov             x1, NULL
    // 0x10eb03c: r4 = LoadClassIdInstr(r0)
    //     0x10eb03c: ldur            x4, [x0, #-1]
    //     0x10eb040: ubfx            x4, x4, #0xc, #0x14
    // 0x10eb044: r17 = 4205
    //     0x10eb044: mov             x17, #0x106d
    // 0x10eb048: cmp             x4, x17
    // 0x10eb04c: b.eq            #0x10eb064
    // 0x10eb050: r8 = ToolbarItemsParentData
    //     0x10eb050: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0x10eb054: ldr             x8, [x8, #0x6c0]
    // 0x10eb058: r3 = Null
    //     0x10eb058: add             x3, PP, #0xcc, lsl #12  ; [pp+0xccdb8] Null
    //     0x10eb05c: ldr             x3, [x3, #0xdb8]
    // 0x10eb060: r0 = DefaultTypeTest()
    //     0x10eb060: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x10eb064: ldur            x0, [fp, #-8]
    // 0x10eb068: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10eb068: ldur            w1, [x0, #0x17]
    // 0x10eb06c: DecompressPointer r1
    //     0x10eb06c: add             x1, x1, HEAP, lsl #32
    // 0x10eb070: tbz             w1, #4, #0x10eb084
    // 0x10eb074: LoadField: r1 = r0->field_f
    //     0x10eb074: ldur            w1, [x0, #0xf]
    // 0x10eb078: DecompressPointer r1
    //     0x10eb078: add             x1, x1, HEAP, lsl #32
    // 0x10eb07c: mov             x5, x1
    // 0x10eb080: b               #0x10eb104
    // 0x10eb084: ldur            x3, [fp, #-0x10]
    // 0x10eb088: LoadField: r4 = r0->field_7
    //     0x10eb088: ldur            w4, [x0, #7]
    // 0x10eb08c: DecompressPointer r4
    //     0x10eb08c: add             x4, x4, HEAP, lsl #32
    // 0x10eb090: ldur            x1, [fp, #-0x20]
    // 0x10eb094: mov             x2, x4
    // 0x10eb098: stur            x4, [fp, #-0x28]
    // 0x10eb09c: r0 = -()
    //     0x10eb09c: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x10eb0a0: ldur            x1, [fp, #-0x28]
    // 0x10eb0a4: stur            x0, [fp, #-0x28]
    // 0x10eb0a8: r0 = unary-()
    //     0x10eb0a8: bl              #0x856e6c  ; [dart:ui] Offset::unary-
    // 0x10eb0ac: ldur            x1, [fp, #-0x18]
    // 0x10eb0b0: mov             x2, x0
    // 0x10eb0b4: r0 = pushOffset()
    //     0x10eb0b4: bl              #0xaf9e0c  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::pushOffset
    // 0x10eb0b8: ldur            x1, [fp, #-0x10]
    // 0x10eb0bc: r0 = LoadClassIdInstr(r1)
    //     0x10eb0bc: ldur            x0, [x1, #-1]
    //     0x10eb0c0: ubfx            x0, x0, #0xc, #0x14
    // 0x10eb0c4: ldur            x2, [fp, #-0x18]
    // 0x10eb0c8: ldur            x3, [fp, #-0x28]
    // 0x10eb0cc: r0 = GDT[cid_x0 + 0x13d77]()
    //     0x10eb0cc: mov             x17, #0x3d77
    //     0x10eb0d0: movk            x17, #1, lsl #16
    //     0x10eb0d4: add             lr, x0, x17
    //     0x10eb0d8: ldr             lr, [x21, lr, lsl #3]
    //     0x10eb0dc: blr             lr
    // 0x10eb0e0: ldur            x1, [fp, #-0x18]
    // 0x10eb0e4: stur            x0, [fp, #-0x10]
    // 0x10eb0e8: r0 = popTransform()
    //     0x10eb0e8: bl              #0xaf9850  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::popTransform
    // 0x10eb0ec: ldur            x1, [fp, #-0x10]
    // 0x10eb0f0: tbz             w1, #4, #0x10eb110
    // 0x10eb0f4: ldur            x1, [fp, #-8]
    // 0x10eb0f8: LoadField: r2 = r1->field_f
    //     0x10eb0f8: ldur            w2, [x1, #0xf]
    // 0x10eb0fc: DecompressPointer r2
    //     0x10eb0fc: add             x2, x2, HEAP, lsl #32
    // 0x10eb100: mov             x5, x2
    // 0x10eb104: ldur            x4, [fp, #-0x18]
    // 0x10eb108: ldur            x3, [fp, #-0x20]
    // 0x10eb10c: b               #0x10eb004
    // 0x10eb110: r0 = true
    //     0x10eb110: add             x0, NULL, #0x20  ; true
    // 0x10eb114: LeaveFrame
    //     0x10eb114: mov             SP, fp
    //     0x10eb118: ldp             fp, lr, [SP], #0x10
    // 0x10eb11c: ret
    //     0x10eb11c: ret             
    // 0x10eb120: r0 = false
    //     0x10eb120: add             x0, NULL, #0x30  ; false
    // 0x10eb124: LeaveFrame
    //     0x10eb124: mov             SP, fp
    //     0x10eb128: ldp             fp, lr, [SP], #0x10
    // 0x10eb12c: ret
    //     0x10eb12c: ret             
    // 0x10eb130: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10eb130: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10eb134: b               #0x10eaff8
    // 0x10eb138: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10eb138: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10eb13c: b               #0x10eb014
    // 0x10eb140: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10eb140: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _RenderTextSelectionToolbarItemsLayout(/* No info */) {
    // ** addr: 0x11ca3bc, size: 0x98
    // 0x11ca3bc: EnterFrame
    //     0x11ca3bc: stp             fp, lr, [SP, #-0x10]!
    //     0x11ca3c0: mov             fp, SP
    // 0x11ca3c4: AllocStack(0x8)
    //     0x11ca3c4: sub             SP, SP, #8
    // 0x11ca3c8: r0 = -1
    //     0x11ca3c8: mov             x0, #-1
    // 0x11ca3cc: mov             x4, x1
    // 0x11ca3d0: stur            x1, [fp, #-8]
    // 0x11ca3d4: mov             x1, x5
    // 0x11ca3d8: CheckStackOverflow
    //     0x11ca3d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ca3dc: cmp             SP, x16
    //     0x11ca3e0: b.ls            #0x11ca44c
    // 0x11ca3e4: StoreField: r4->field_5f = r0
    //     0x11ca3e4: stur            x0, [x4, #0x5f]
    // 0x11ca3e8: StoreField: r4->field_67 = r2
    //     0x11ca3e8: stur            w2, [x4, #0x67]
    // 0x11ca3ec: StoreField: r4->field_6b = r3
    //     0x11ca3ec: stur            w3, [x4, #0x6b]
    // 0x11ca3f0: mov             x0, x1
    // 0x11ca3f4: StoreField: r4->field_6f = r0
    //     0x11ca3f4: stur            w0, [x4, #0x6f]
    //     0x11ca3f8: ldurb           w16, [x4, #-1]
    //     0x11ca3fc: ldurb           w17, [x0, #-1]
    //     0x11ca400: and             x16, x17, x16, lsr #2
    //     0x11ca404: tst             x16, HEAP, lsr #32
    //     0x11ca408: b.eq            #0x11ca410
    //     0x11ca40c: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x11ca410: StoreField: r4->field_4f = rZR
    //     0x11ca410: stur            xzr, [x4, #0x4f]
    // 0x11ca414: r0 = _LayoutCacheStorage()
    //     0x11ca414: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11ca418: ldur            x1, [fp, #-8]
    // 0x11ca41c: StoreField: r1->field_47 = r0
    //     0x11ca41c: stur            w0, [x1, #0x47]
    //     0x11ca420: ldurb           w16, [x1, #-1]
    //     0x11ca424: ldurb           w17, [x0, #-1]
    //     0x11ca428: and             x16, x17, x16, lsr #2
    //     0x11ca42c: tst             x16, HEAP, lsr #32
    //     0x11ca430: b.eq            #0x11ca438
    //     0x11ca434: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11ca438: r0 = RenderObject()
    //     0x11ca438: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11ca43c: r0 = Null
    //     0x11ca43c: mov             x0, NULL
    // 0x11ca440: LeaveFrame
    //     0x11ca440: mov             SP, fp
    //     0x11ca444: ldp             fp, lr, [SP], #0x10
    // 0x11ca448: ret
    //     0x11ca448: ret             
    // 0x11ca44c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ca44c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ca450: b               #0x11ca3e4
  }
}

// class id: 4957, size: 0x60, field offset: 0x54
class _TextSelectionToolbarTrailingEdgeAlignRenderBox extends RenderProxyBox {

  _ performLayout(/* No info */) {
    // ** addr: 0xbb8d58, size: 0x3d0
    // 0xbb8d58: EnterFrame
    //     0xbb8d58: stp             fp, lr, [SP, #-0x10]!
    //     0xbb8d5c: mov             fp, SP
    // 0xbb8d60: AllocStack(0x30)
    //     0xbb8d60: sub             SP, SP, #0x30
    // 0xbb8d64: SetupParameters(_TextSelectionToolbarTrailingEdgeAlignRenderBox this /* r1 => r3, fp-0x18 */)
    //     0xbb8d64: mov             x3, x1
    //     0xbb8d68: stur            x1, [fp, #-0x18]
    // 0xbb8d6c: CheckStackOverflow
    //     0xbb8d6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb8d70: cmp             SP, x16
    //     0xbb8d74: b.ls            #0xbb90ec
    // 0xbb8d78: LoadField: r4 = r3->field_4f
    //     0xbb8d78: ldur            w4, [x3, #0x4f]
    // 0xbb8d7c: DecompressPointer r4
    //     0xbb8d7c: add             x4, x4, HEAP, lsl #32
    // 0xbb8d80: stur            x4, [fp, #-0x10]
    // 0xbb8d84: cmp             w4, NULL
    // 0xbb8d88: b.eq            #0xbb90f4
    // 0xbb8d8c: LoadField: r5 = r3->field_27
    //     0xbb8d8c: ldur            w5, [x3, #0x27]
    // 0xbb8d90: DecompressPointer r5
    //     0xbb8d90: add             x5, x5, HEAP, lsl #32
    // 0xbb8d94: stur            x5, [fp, #-8]
    // 0xbb8d98: cmp             w5, NULL
    // 0xbb8d9c: b.eq            #0xbb90b0
    // 0xbb8da0: mov             x0, x5
    // 0xbb8da4: r2 = Null
    //     0xbb8da4: mov             x2, NULL
    // 0xbb8da8: r1 = Null
    //     0xbb8da8: mov             x1, NULL
    // 0xbb8dac: r4 = LoadClassIdInstr(r0)
    //     0xbb8dac: ldur            x4, [x0, #-1]
    //     0xbb8db0: ubfx            x4, x4, #0xc, #0x14
    // 0xbb8db4: sub             x4, x4, #0xb46
    // 0xbb8db8: cmp             x4, #1
    // 0xbb8dbc: b.ls            #0xbb8dd0
    // 0xbb8dc0: r8 = BoxConstraints
    //     0xbb8dc0: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbb8dc4: r3 = Null
    //     0xbb8dc4: add             x3, PP, #0xcc, lsl #12  ; [pp+0xccd60] Null
    //     0xbb8dc8: ldr             x3, [x3, #0xd60]
    // 0xbb8dcc: r0 = BoxConstraints()
    //     0xbb8dcc: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbb8dd0: ldur            x1, [fp, #-8]
    // 0xbb8dd4: r0 = loosen()
    //     0xbb8dd4: bl              #0xb4ae38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0xbb8dd8: ldur            x1, [fp, #-0x10]
    // 0xbb8ddc: r2 = LoadClassIdInstr(r1)
    //     0xbb8ddc: ldur            x2, [x1, #-1]
    //     0xbb8de0: ubfx            x2, x2, #0xc, #0x14
    // 0xbb8de4: r16 = true
    //     0xbb8de4: add             x16, NULL, #0x20  ; true
    // 0xbb8de8: str             x16, [SP]
    // 0xbb8dec: mov             x16, x0
    // 0xbb8df0: mov             x0, x2
    // 0xbb8df4: mov             x2, x16
    // 0xbb8df8: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbb8df8: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbb8dfc: ldr             x4, [x4, #0xed0]
    // 0xbb8e00: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbb8e00: mov             x17, #0xe6b9
    //     0xbb8e04: add             lr, x0, x17
    //     0xbb8e08: ldr             lr, [x21, lr, lsl #3]
    //     0xbb8e0c: blr             lr
    // 0xbb8e10: ldur            x0, [fp, #-0x18]
    // 0xbb8e14: LoadField: r1 = r0->field_57
    //     0xbb8e14: ldur            w1, [x0, #0x57]
    // 0xbb8e18: DecompressPointer r1
    //     0xbb8e18: add             x1, x1, HEAP, lsl #32
    // 0xbb8e1c: tbz             w1, #4, #0xbb8ea0
    // 0xbb8e20: LoadField: r1 = r0->field_53
    //     0xbb8e20: ldur            w1, [x0, #0x53]
    // 0xbb8e24: DecompressPointer r1
    //     0xbb8e24: add             x1, x1, HEAP, lsl #32
    // 0xbb8e28: cmp             w1, NULL
    // 0xbb8e2c: b.ne            #0xbb8e98
    // 0xbb8e30: LoadField: r1 = r0->field_4f
    //     0xbb8e30: ldur            w1, [x0, #0x4f]
    // 0xbb8e34: DecompressPointer r1
    //     0xbb8e34: add             x1, x1, HEAP, lsl #32
    // 0xbb8e38: cmp             w1, NULL
    // 0xbb8e3c: b.eq            #0xbb90f8
    // 0xbb8e40: r0 = size()
    //     0xbb8e40: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbb8e44: LoadField: d0 = r0->field_7
    //     0xbb8e44: ldur            d0, [x0, #7]
    // 0xbb8e48: r0 = inline_Allocate_Double()
    //     0xbb8e48: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbb8e4c: add             x0, x0, #0x10
    //     0xbb8e50: cmp             x1, x0
    //     0xbb8e54: b.ls            #0xbb90fc
    //     0xbb8e58: str             x0, [THR, #0x60]  ; THR::top
    //     0xbb8e5c: sub             x0, x0, #0xf
    //     0xbb8e60: mov             x1, #0xe19c
    //     0xbb8e64: movk            x1, #3, lsl #16
    //     0xbb8e68: stur            x1, [x0, #-1]
    // 0xbb8e6c: dmb             ishst
    // 0xbb8e70: StoreField: r0->field_7 = d0
    //     0xbb8e70: stur            d0, [x0, #7]
    // 0xbb8e74: ldur            x3, [fp, #-0x18]
    // 0xbb8e78: StoreField: r3->field_53 = r0
    //     0xbb8e78: stur            w0, [x3, #0x53]
    //     0xbb8e7c: ldurb           w16, [x3, #-1]
    //     0xbb8e80: ldurb           w17, [x0, #-1]
    //     0xbb8e84: and             x16, x17, x16, lsr #2
    //     0xbb8e88: tst             x16, HEAP, lsr #32
    //     0xbb8e8c: b.eq            #0xbb8e94
    //     0xbb8e90: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbb8e94: b               #0xbb8ea4
    // 0xbb8e98: mov             x3, x0
    // 0xbb8e9c: b               #0xbb8ea4
    // 0xbb8ea0: mov             x3, x0
    // 0xbb8ea4: LoadField: r4 = r3->field_27
    //     0xbb8ea4: ldur            w4, [x3, #0x27]
    // 0xbb8ea8: DecompressPointer r4
    //     0xbb8ea8: add             x4, x4, HEAP, lsl #32
    // 0xbb8eac: stur            x4, [fp, #-8]
    // 0xbb8eb0: cmp             w4, NULL
    // 0xbb8eb4: b.eq            #0xbb90cc
    // 0xbb8eb8: mov             x0, x4
    // 0xbb8ebc: r2 = Null
    //     0xbb8ebc: mov             x2, NULL
    // 0xbb8ec0: r1 = Null
    //     0xbb8ec0: mov             x1, NULL
    // 0xbb8ec4: r4 = LoadClassIdInstr(r0)
    //     0xbb8ec4: ldur            x4, [x0, #-1]
    //     0xbb8ec8: ubfx            x4, x4, #0xc, #0x14
    // 0xbb8ecc: sub             x4, x4, #0xb46
    // 0xbb8ed0: cmp             x4, #1
    // 0xbb8ed4: b.ls            #0xbb8ee8
    // 0xbb8ed8: r8 = BoxConstraints
    //     0xbb8ed8: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbb8edc: r3 = Null
    //     0xbb8edc: add             x3, PP, #0xcc, lsl #12  ; [pp+0xccd70] Null
    //     0xbb8ee0: ldr             x3, [x3, #0xd70]
    // 0xbb8ee4: r0 = BoxConstraints()
    //     0xbb8ee4: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbb8ee8: ldur            x0, [fp, #-0x18]
    // 0xbb8eec: LoadField: r1 = r0->field_53
    //     0xbb8eec: ldur            w1, [x0, #0x53]
    // 0xbb8ef0: DecompressPointer r1
    //     0xbb8ef0: add             x1, x1, HEAP, lsl #32
    // 0xbb8ef4: cmp             w1, NULL
    // 0xbb8ef8: b.eq            #0xbb8f34
    // 0xbb8efc: LoadField: r1 = r0->field_4f
    //     0xbb8efc: ldur            w1, [x0, #0x4f]
    // 0xbb8f00: DecompressPointer r1
    //     0xbb8f00: add             x1, x1, HEAP, lsl #32
    // 0xbb8f04: cmp             w1, NULL
    // 0xbb8f08: b.eq            #0xbb910c
    // 0xbb8f0c: r0 = size()
    //     0xbb8f0c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbb8f10: LoadField: d0 = r0->field_7
    //     0xbb8f10: ldur            d0, [x0, #7]
    // 0xbb8f14: ldur            x0, [fp, #-0x18]
    // 0xbb8f18: LoadField: r1 = r0->field_53
    //     0xbb8f18: ldur            w1, [x0, #0x53]
    // 0xbb8f1c: DecompressPointer r1
    //     0xbb8f1c: add             x1, x1, HEAP, lsl #32
    // 0xbb8f20: cmp             w1, NULL
    // 0xbb8f24: b.eq            #0xbb9110
    // 0xbb8f28: LoadField: d1 = r1->field_7
    //     0xbb8f28: ldur            d1, [x1, #7]
    // 0xbb8f2c: fcmp            d0, d1
    // 0xbb8f30: b.le            #0xbb8f50
    // 0xbb8f34: LoadField: r1 = r0->field_4f
    //     0xbb8f34: ldur            w1, [x0, #0x4f]
    // 0xbb8f38: DecompressPointer r1
    //     0xbb8f38: add             x1, x1, HEAP, lsl #32
    // 0xbb8f3c: cmp             w1, NULL
    // 0xbb8f40: b.eq            #0xbb9114
    // 0xbb8f44: r0 = size()
    //     0xbb8f44: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbb8f48: LoadField: d0 = r0->field_7
    //     0xbb8f48: ldur            d0, [x0, #7]
    // 0xbb8f4c: b               #0xbb8f54
    // 0xbb8f50: mov             v0.16b, v1.16b
    // 0xbb8f54: ldur            x0, [fp, #-0x18]
    // 0xbb8f58: stur            d0, [fp, #-0x20]
    // 0xbb8f5c: LoadField: r1 = r0->field_4f
    //     0xbb8f5c: ldur            w1, [x0, #0x4f]
    // 0xbb8f60: DecompressPointer r1
    //     0xbb8f60: add             x1, x1, HEAP, lsl #32
    // 0xbb8f64: cmp             w1, NULL
    // 0xbb8f68: b.eq            #0xbb9118
    // 0xbb8f6c: r0 = size()
    //     0xbb8f6c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbb8f70: LoadField: d0 = r0->field_f
    //     0xbb8f70: ldur            d0, [x0, #0xf]
    // 0xbb8f74: stur            d0, [fp, #-0x28]
    // 0xbb8f78: r0 = Size()
    //     0xbb8f78: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbb8f7c: ldur            d0, [fp, #-0x20]
    // 0xbb8f80: StoreField: r0->field_7 = d0
    //     0xbb8f80: stur            d0, [x0, #7]
    // 0xbb8f84: ldur            d0, [fp, #-0x28]
    // 0xbb8f88: StoreField: r0->field_f = d0
    //     0xbb8f88: stur            d0, [x0, #0xf]
    // 0xbb8f8c: ldur            x1, [fp, #-8]
    // 0xbb8f90: mov             x2, x0
    // 0xbb8f94: r0 = constrain()
    //     0xbb8f94: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbb8f98: ldur            x3, [fp, #-0x18]
    // 0xbb8f9c: StoreField: r3->field_4b = r0
    //     0xbb8f9c: stur            w0, [x3, #0x4b]
    //     0xbb8fa0: ldurb           w16, [x3, #-1]
    //     0xbb8fa4: ldurb           w17, [x0, #-1]
    //     0xbb8fa8: and             x16, x17, x16, lsr #2
    //     0xbb8fac: tst             x16, HEAP, lsr #32
    //     0xbb8fb0: b.eq            #0xbb8fb8
    //     0xbb8fb4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbb8fb8: LoadField: r0 = r3->field_4f
    //     0xbb8fb8: ldur            w0, [x3, #0x4f]
    // 0xbb8fbc: DecompressPointer r0
    //     0xbb8fbc: add             x0, x0, HEAP, lsl #32
    // 0xbb8fc0: cmp             w0, NULL
    // 0xbb8fc4: b.eq            #0xbb911c
    // 0xbb8fc8: LoadField: r4 = r0->field_7
    //     0xbb8fc8: ldur            w4, [x0, #7]
    // 0xbb8fcc: DecompressPointer r4
    //     0xbb8fcc: add             x4, x4, HEAP, lsl #32
    // 0xbb8fd0: stur            x4, [fp, #-8]
    // 0xbb8fd4: cmp             w4, NULL
    // 0xbb8fd8: b.eq            #0xbb9120
    // 0xbb8fdc: mov             x0, x4
    // 0xbb8fe0: r2 = Null
    //     0xbb8fe0: mov             x2, NULL
    // 0xbb8fe4: r1 = Null
    //     0xbb8fe4: mov             x1, NULL
    // 0xbb8fe8: r4 = LoadClassIdInstr(r0)
    //     0xbb8fe8: ldur            x4, [x0, #-1]
    //     0xbb8fec: ubfx            x4, x4, #0xc, #0x14
    // 0xbb8ff0: r17 = 4205
    //     0xbb8ff0: mov             x17, #0x106d
    // 0xbb8ff4: cmp             x4, x17
    // 0xbb8ff8: b.eq            #0xbb9010
    // 0xbb8ffc: r8 = ToolbarItemsParentData
    //     0xbb8ffc: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0xbb9000: ldr             x8, [x8, #0x6c0]
    // 0xbb9004: r3 = Null
    //     0xbb9004: add             x3, PP, #0xcc, lsl #12  ; [pp+0xccd80] Null
    //     0xbb9008: ldr             x3, [x3, #0xd80]
    // 0xbb900c: r0 = DefaultTypeTest()
    //     0xbb900c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbb9010: ldur            x0, [fp, #-0x18]
    // 0xbb9014: LoadField: r1 = r0->field_5b
    //     0xbb9014: ldur            w1, [x0, #0x5b]
    // 0xbb9018: DecompressPointer r1
    //     0xbb9018: add             x1, x1, HEAP, lsl #32
    // 0xbb901c: r16 = Instance_TextDirection
    //     0xbb901c: ldr             x16, [PP, #0x2578]  ; [pp+0x2578] Obj!TextDirection@12c7381
    // 0xbb9020: cmp             w1, w16
    // 0xbb9024: b.ne            #0xbb9030
    // 0xbb9028: d0 = 0.000000
    //     0xbb9028: eor             v0.16b, v0.16b, v0.16b
    // 0xbb902c: b               #0xbb9068
    // 0xbb9030: mov             x1, x0
    // 0xbb9034: r0 = size()
    //     0xbb9034: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbb9038: LoadField: d0 = r0->field_7
    //     0xbb9038: ldur            d0, [x0, #7]
    // 0xbb903c: ldur            x0, [fp, #-0x18]
    // 0xbb9040: stur            d0, [fp, #-0x20]
    // 0xbb9044: LoadField: r1 = r0->field_4f
    //     0xbb9044: ldur            w1, [x0, #0x4f]
    // 0xbb9048: DecompressPointer r1
    //     0xbb9048: add             x1, x1, HEAP, lsl #32
    // 0xbb904c: cmp             w1, NULL
    // 0xbb9050: b.eq            #0xbb9124
    // 0xbb9054: r0 = size()
    //     0xbb9054: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbb9058: LoadField: d0 = r0->field_7
    //     0xbb9058: ldur            d0, [x0, #7]
    // 0xbb905c: ldur            d1, [fp, #-0x20]
    // 0xbb9060: fsub            d2, d1, d0
    // 0xbb9064: mov             v0.16b, v2.16b
    // 0xbb9068: ldur            x0, [fp, #-8]
    // 0xbb906c: stur            d0, [fp, #-0x20]
    // 0xbb9070: r0 = Offset()
    //     0xbb9070: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbb9074: ldur            d0, [fp, #-0x20]
    // 0xbb9078: StoreField: r0->field_7 = d0
    //     0xbb9078: stur            d0, [x0, #7]
    // 0xbb907c: StoreField: r0->field_f = rZR
    //     0xbb907c: stur            xzr, [x0, #0xf]
    // 0xbb9080: ldur            x1, [fp, #-8]
    // 0xbb9084: StoreField: r1->field_7 = r0
    //     0xbb9084: stur            w0, [x1, #7]
    //     0xbb9088: ldurb           w16, [x1, #-1]
    //     0xbb908c: ldurb           w17, [x0, #-1]
    //     0xbb9090: and             x16, x17, x16, lsr #2
    //     0xbb9094: tst             x16, HEAP, lsr #32
    //     0xbb9098: b.eq            #0xbb90a0
    //     0xbb909c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbb90a0: r0 = Null
    //     0xbb90a0: mov             x0, NULL
    // 0xbb90a4: LeaveFrame
    //     0xbb90a4: mov             SP, fp
    //     0xbb90a8: ldp             fp, lr, [SP], #0x10
    // 0xbb90ac: ret
    //     0xbb90ac: ret             
    // 0xbb90b0: r0 = StateError()
    //     0xbb90b0: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbb90b4: mov             x1, x0
    // 0xbb90b8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbb90b8: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbb90bc: StoreField: r1->field_b = r0
    //     0xbb90bc: stur            w0, [x1, #0xb]
    // 0xbb90c0: mov             x0, x1
    // 0xbb90c4: r0 = Throw()
    //     0xbb90c4: bl              #0x13ddb2c  ; ThrowStub
    // 0xbb90c8: brk             #0
    // 0xbb90cc: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbb90cc: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbb90d0: r0 = StateError()
    //     0xbb90d0: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbb90d4: mov             x1, x0
    // 0xbb90d8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbb90d8: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbb90dc: StoreField: r1->field_b = r0
    //     0xbb90dc: stur            w0, [x1, #0xb]
    // 0xbb90e0: mov             x0, x1
    // 0xbb90e4: r0 = Throw()
    //     0xbb90e4: bl              #0x13ddb2c  ; ThrowStub
    // 0xbb90e8: brk             #0
    // 0xbb90ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb90ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb90f0: b               #0xbb8d78
    // 0xbb90f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbb90f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbb90f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbb90f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbb90fc: SaveReg d0
    //     0xbb90fc: str             q0, [SP, #-0x10]!
    // 0xbb9100: r0 = AllocateDouble()
    //     0xbb9100: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbb9104: RestoreReg d0
    //     0xbb9104: ldr             q0, [SP], #0x10
    // 0xbb9108: b               #0xbb8e70
    // 0xbb910c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbb910c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbb9110: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbb9110: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbb9114: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbb9114: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbb9118: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbb9118: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbb911c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbb911c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbb9120: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbb9120: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbb9124: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbb9124: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0xbf0a88, size: 0x9c
    // 0xbf0a88: EnterFrame
    //     0xbf0a88: stp             fp, lr, [SP, #-0x10]!
    //     0xbf0a8c: mov             fp, SP
    // 0xbf0a90: AllocStack(0x10)
    //     0xbf0a90: sub             SP, SP, #0x10
    // 0xbf0a94: SetupParameters(dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xbf0a94: stur            x3, [fp, #-0x10]
    // 0xbf0a98: CheckStackOverflow
    //     0xbf0a98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf0a9c: cmp             SP, x16
    //     0xbf0aa0: b.ls            #0xbf0b18
    // 0xbf0aa4: LoadField: r4 = r2->field_7
    //     0xbf0aa4: ldur            w4, [x2, #7]
    // 0xbf0aa8: DecompressPointer r4
    //     0xbf0aa8: add             x4, x4, HEAP, lsl #32
    // 0xbf0aac: stur            x4, [fp, #-8]
    // 0xbf0ab0: cmp             w4, NULL
    // 0xbf0ab4: b.eq            #0xbf0b20
    // 0xbf0ab8: mov             x0, x4
    // 0xbf0abc: r2 = Null
    //     0xbf0abc: mov             x2, NULL
    // 0xbf0ac0: r1 = Null
    //     0xbf0ac0: mov             x1, NULL
    // 0xbf0ac4: r4 = LoadClassIdInstr(r0)
    //     0xbf0ac4: ldur            x4, [x0, #-1]
    //     0xbf0ac8: ubfx            x4, x4, #0xc, #0x14
    // 0xbf0acc: r17 = 4205
    //     0xbf0acc: mov             x17, #0x106d
    // 0xbf0ad0: cmp             x4, x17
    // 0xbf0ad4: b.eq            #0xbf0aec
    // 0xbf0ad8: r8 = ToolbarItemsParentData
    //     0xbf0ad8: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0xbf0adc: ldr             x8, [x8, #0x6c0]
    // 0xbf0ae0: r3 = Null
    //     0xbf0ae0: add             x3, PP, #0xcc, lsl #12  ; [pp+0xccd18] Null
    //     0xbf0ae4: ldr             x3, [x3, #0xd18]
    // 0xbf0ae8: r0 = DefaultTypeTest()
    //     0xbf0ae8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbf0aec: ldur            x0, [fp, #-8]
    // 0xbf0af0: LoadField: r1 = r0->field_7
    //     0xbf0af0: ldur            w1, [x0, #7]
    // 0xbf0af4: DecompressPointer r1
    //     0xbf0af4: add             x1, x1, HEAP, lsl #32
    // 0xbf0af8: LoadField: d0 = r1->field_7
    //     0xbf0af8: ldur            d0, [x1, #7]
    // 0xbf0afc: LoadField: d1 = r1->field_f
    //     0xbf0afc: ldur            d1, [x1, #0xf]
    // 0xbf0b00: ldur            x1, [fp, #-0x10]
    // 0xbf0b04: r0 = translateByDouble()
    //     0xbf0b04: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0xbf0b08: r0 = Null
    //     0xbf0b08: mov             x0, NULL
    // 0xbf0b0c: LeaveFrame
    //     0xbf0b0c: mov             SP, fp
    //     0xbf0b10: ldp             fp, lr, [SP], #0x10
    // 0xbf0b14: ret
    //     0xbf0b14: ret             
    // 0xbf0b18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf0b18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf0b1c: b               #0xbf0aa4
    // 0xbf0b20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf0b20: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0xc0d638, size: 0xc0
    // 0xc0d638: EnterFrame
    //     0xc0d638: stp             fp, lr, [SP, #-0x10]!
    //     0xc0d63c: mov             fp, SP
    // 0xc0d640: AllocStack(0x8)
    //     0xc0d640: sub             SP, SP, #8
    // 0xc0d644: SetupParameters(_TextSelectionToolbarTrailingEdgeAlignRenderBox this /* r1 => r4 */, dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xc0d644: mov             x0, x2
    //     0xc0d648: mov             x4, x1
    //     0xc0d64c: mov             x3, x2
    //     0xc0d650: stur            x2, [fp, #-8]
    // 0xc0d654: r2 = Null
    //     0xc0d654: mov             x2, NULL
    // 0xc0d658: r1 = Null
    //     0xc0d658: mov             x1, NULL
    // 0xc0d65c: r4 = 60
    //     0xc0d65c: mov             x4, #0x3c
    // 0xc0d660: branchIfSmi(r0, 0xc0d66c)
    //     0xc0d660: tbz             w0, #0, #0xc0d66c
    // 0xc0d664: r4 = LoadClassIdInstr(r0)
    //     0xc0d664: ldur            x4, [x0, #-1]
    //     0xc0d668: ubfx            x4, x4, #0xc, #0x14
    // 0xc0d66c: r17 = -4710
    //     0xc0d66c: mov             x17, #-0x1266
    // 0xc0d670: add             x4, x4, x17
    // 0xc0d674: cmp             x4, #0x109
    // 0xc0d678: b.ls            #0xc0d68c
    // 0xc0d67c: r8 = RenderBox
    //     0xc0d67c: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xc0d680: r3 = Null
    //     0xc0d680: add             x3, PP, #0xcc, lsl #12  ; [pp+0xccd28] Null
    //     0xc0d684: ldr             x3, [x3, #0xd28]
    // 0xc0d688: r0 = RenderBox()
    //     0xc0d688: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xc0d68c: ldur            x0, [fp, #-8]
    // 0xc0d690: LoadField: r1 = r0->field_7
    //     0xc0d690: ldur            w1, [x0, #7]
    // 0xc0d694: DecompressPointer r1
    //     0xc0d694: add             x1, x1, HEAP, lsl #32
    // 0xc0d698: r2 = LoadClassIdInstr(r1)
    //     0xc0d698: ldur            x2, [x1, #-1]
    //     0xc0d69c: ubfx            x2, x2, #0xc, #0x14
    // 0xc0d6a0: r17 = 4205
    //     0xc0d6a0: mov             x17, #0x106d
    // 0xc0d6a4: cmp             x2, x17
    // 0xc0d6a8: b.eq            #0xc0d6e8
    // 0xc0d6ac: r1 = <RenderBox>
    //     0xc0d6ac: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c8] TypeArguments: <RenderBox>
    //     0xc0d6b0: ldr             x1, [x1, #0x5c8]
    // 0xc0d6b4: r0 = ToolbarItemsParentData()
    //     0xc0d6b4: bl              #0xc0d6f8  ; AllocateToolbarItemsParentDataStub -> ToolbarItemsParentData (size=0x1c)
    // 0xc0d6b8: r1 = false
    //     0xc0d6b8: add             x1, NULL, #0x30  ; false
    // 0xc0d6bc: ArrayStore: r0[0] = r1  ; List_4
    //     0xc0d6bc: stur            w1, [x0, #0x17]
    // 0xc0d6c0: r1 = Instance_Offset
    //     0xc0d6c0: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc0d6c4: StoreField: r0->field_7 = r1
    //     0xc0d6c4: stur            w1, [x0, #7]
    // 0xc0d6c8: ldur            x1, [fp, #-8]
    // 0xc0d6cc: StoreField: r1->field_7 = r0
    //     0xc0d6cc: stur            w0, [x1, #7]
    //     0xc0d6d0: ldurb           w16, [x1, #-1]
    //     0xc0d6d4: ldurb           w17, [x0, #-1]
    //     0xc0d6d8: and             x16, x17, x16, lsr #2
    //     0xc0d6dc: tst             x16, HEAP, lsr #32
    //     0xc0d6e0: b.eq            #0xc0d6e8
    //     0xc0d6e4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc0d6e8: r0 = Null
    //     0xc0d6e8: mov             x0, NULL
    // 0xc0d6ec: LeaveFrame
    //     0xc0d6ec: mov             SP, fp
    //     0xc0d6f0: ldp             fp, lr, [SP], #0x10
    // 0xc0d6f4: ret
    //     0xc0d6f4: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0xc180a0, size: 0xc4
    // 0xc180a0: EnterFrame
    //     0xc180a0: stp             fp, lr, [SP, #-0x10]!
    //     0xc180a4: mov             fp, SP
    // 0xc180a8: AllocStack(0x20)
    //     0xc180a8: sub             SP, SP, #0x20
    // 0xc180ac: SetupParameters(dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0xc180ac: mov             x4, x2
    //     0xc180b0: stur            x2, [fp, #-0x18]
    //     0xc180b4: stur            x3, [fp, #-0x20]
    // 0xc180b8: CheckStackOverflow
    //     0xc180b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc180bc: cmp             SP, x16
    //     0xc180c0: b.ls            #0xc18154
    // 0xc180c4: LoadField: r5 = r1->field_4f
    //     0xc180c4: ldur            w5, [x1, #0x4f]
    // 0xc180c8: DecompressPointer r5
    //     0xc180c8: add             x5, x5, HEAP, lsl #32
    // 0xc180cc: stur            x5, [fp, #-0x10]
    // 0xc180d0: cmp             w5, NULL
    // 0xc180d4: b.eq            #0xc1815c
    // 0xc180d8: LoadField: r6 = r5->field_7
    //     0xc180d8: ldur            w6, [x5, #7]
    // 0xc180dc: DecompressPointer r6
    //     0xc180dc: add             x6, x6, HEAP, lsl #32
    // 0xc180e0: stur            x6, [fp, #-8]
    // 0xc180e4: cmp             w6, NULL
    // 0xc180e8: b.eq            #0xc18160
    // 0xc180ec: mov             x0, x6
    // 0xc180f0: r2 = Null
    //     0xc180f0: mov             x2, NULL
    // 0xc180f4: r1 = Null
    //     0xc180f4: mov             x1, NULL
    // 0xc180f8: r4 = LoadClassIdInstr(r0)
    //     0xc180f8: ldur            x4, [x0, #-1]
    //     0xc180fc: ubfx            x4, x4, #0xc, #0x14
    // 0xc18100: r17 = 4205
    //     0xc18100: mov             x17, #0x106d
    // 0xc18104: cmp             x4, x17
    // 0xc18108: b.eq            #0xc18120
    // 0xc1810c: r8 = ToolbarItemsParentData
    //     0xc1810c: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0xc18110: ldr             x8, [x8, #0x6c0]
    // 0xc18114: r3 = Null
    //     0xc18114: add             x3, PP, #0xcc, lsl #12  ; [pp+0xccd50] Null
    //     0xc18118: ldr             x3, [x3, #0xd50]
    // 0xc1811c: r0 = DefaultTypeTest()
    //     0xc1811c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc18120: ldur            x0, [fp, #-8]
    // 0xc18124: LoadField: r1 = r0->field_7
    //     0xc18124: ldur            w1, [x0, #7]
    // 0xc18128: DecompressPointer r1
    //     0xc18128: add             x1, x1, HEAP, lsl #32
    // 0xc1812c: ldur            x2, [fp, #-0x20]
    // 0xc18130: r0 = +()
    //     0xc18130: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc18134: ldur            x1, [fp, #-0x18]
    // 0xc18138: ldur            x2, [fp, #-0x10]
    // 0xc1813c: mov             x3, x0
    // 0xc18140: r0 = paintChild()
    //     0xc18140: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xc18144: r0 = Null
    //     0xc18144: mov             x0, NULL
    // 0xc18148: LeaveFrame
    //     0xc18148: mov             SP, fp
    //     0xc1814c: ldp             fp, lr, [SP], #0x10
    // 0xc18150: ret
    //     0xc18150: ret             
    // 0xc18154: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc18154: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc18158: b               #0xc180c4
    // 0xc1815c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1815c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc18160: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc18160: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0xcf4d68, size: 0x70
    // 0xcf4d68: EnterFrame
    //     0xcf4d68: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4d6c: mov             fp, SP
    // 0xcf4d70: mov             x0, x2
    // 0xcf4d74: CheckStackOverflow
    //     0xcf4d74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf4d78: cmp             SP, x16
    //     0xcf4d7c: b.ls            #0xcf4dd0
    // 0xcf4d80: LoadField: r2 = r1->field_5b
    //     0xcf4d80: ldur            w2, [x1, #0x5b]
    // 0xcf4d84: DecompressPointer r2
    //     0xcf4d84: add             x2, x2, HEAP, lsl #32
    // 0xcf4d88: cmp             w0, w2
    // 0xcf4d8c: b.ne            #0xcf4da0
    // 0xcf4d90: r0 = Null
    //     0xcf4d90: mov             x0, NULL
    // 0xcf4d94: LeaveFrame
    //     0xcf4d94: mov             SP, fp
    //     0xcf4d98: ldp             fp, lr, [SP], #0x10
    // 0xcf4d9c: ret
    //     0xcf4d9c: ret             
    // 0xcf4da0: StoreField: r1->field_5b = r0
    //     0xcf4da0: stur            w0, [x1, #0x5b]
    //     0xcf4da4: ldurb           w16, [x1, #-1]
    //     0xcf4da8: ldurb           w17, [x0, #-1]
    //     0xcf4dac: and             x16, x17, x16, lsr #2
    //     0xcf4db0: tst             x16, HEAP, lsr #32
    //     0xcf4db4: b.eq            #0xcf4dbc
    //     0xcf4db8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf4dbc: r0 = markNeedsLayout()
    //     0xcf4dbc: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf4dc0: r0 = Null
    //     0xcf4dc0: mov             x0, NULL
    // 0xcf4dc4: LeaveFrame
    //     0xcf4dc4: mov             SP, fp
    //     0xcf4dc8: ldp             fp, lr, [SP], #0x10
    // 0xcf4dcc: ret
    //     0xcf4dcc: ret             
    // 0xcf4dd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf4dd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf4dd4: b               #0xcf4d80
  }
  set _ overflowOpen=(/* No info */) {
    // ** addr: 0xcf4dd8, size: 0x54
    // 0xcf4dd8: EnterFrame
    //     0xcf4dd8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4ddc: mov             fp, SP
    // 0xcf4de0: CheckStackOverflow
    //     0xcf4de0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf4de4: cmp             SP, x16
    //     0xcf4de8: b.ls            #0xcf4e24
    // 0xcf4dec: LoadField: r0 = r1->field_57
    //     0xcf4dec: ldur            w0, [x1, #0x57]
    // 0xcf4df0: DecompressPointer r0
    //     0xcf4df0: add             x0, x0, HEAP, lsl #32
    // 0xcf4df4: cmp             w2, w0
    // 0xcf4df8: b.ne            #0xcf4e0c
    // 0xcf4dfc: r0 = Null
    //     0xcf4dfc: mov             x0, NULL
    // 0xcf4e00: LeaveFrame
    //     0xcf4e00: mov             SP, fp
    //     0xcf4e04: ldp             fp, lr, [SP], #0x10
    // 0xcf4e08: ret
    //     0xcf4e08: ret             
    // 0xcf4e0c: StoreField: r1->field_57 = r2
    //     0xcf4e0c: stur            w2, [x1, #0x57]
    // 0xcf4e10: r0 = markNeedsLayout()
    //     0xcf4e10: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf4e14: r0 = Null
    //     0xcf4e14: mov             x0, NULL
    // 0xcf4e18: LeaveFrame
    //     0xcf4e18: mov             SP, fp
    //     0xcf4e1c: ldp             fp, lr, [SP], #0x10
    // 0xcf4e20: ret
    //     0xcf4e20: ret             
    // 0xcf4e24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf4e24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf4e28: b               #0xcf4dec
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x10e8a18, size: 0xf0
    // 0x10e8a18: EnterFrame
    //     0x10e8a18: stp             fp, lr, [SP, #-0x10]!
    //     0x10e8a1c: mov             fp, SP
    // 0x10e8a20: AllocStack(0x28)
    //     0x10e8a20: sub             SP, SP, #0x28
    // 0x10e8a24: SetupParameters(_TextSelectionToolbarTrailingEdgeAlignRenderBox this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r5, fp-0x18 */)
    //     0x10e8a24: mov             x0, x1
    //     0x10e8a28: stur            x1, [fp, #-8]
    //     0x10e8a2c: mov             x1, x2
    //     0x10e8a30: mov             x5, x3
    //     0x10e8a34: stur            x2, [fp, #-0x10]
    //     0x10e8a38: stur            x3, [fp, #-0x18]
    // 0x10e8a3c: CheckStackOverflow
    //     0x10e8a3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e8a40: cmp             SP, x16
    //     0x10e8a44: b.ls            #0x10e8af8
    // 0x10e8a48: r1 = 1
    //     0x10e8a48: mov             x1, #1
    // 0x10e8a4c: r0 = AllocateContext()
    //     0x10e8a4c: bl              #0x13de838  ; AllocateContextStub
    // 0x10e8a50: mov             x3, x0
    // 0x10e8a54: ldur            x0, [fp, #-8]
    // 0x10e8a58: stur            x3, [fp, #-0x20]
    // 0x10e8a5c: StoreField: r3->field_f = r0
    //     0x10e8a5c: stur            w0, [x3, #0xf]
    // 0x10e8a60: LoadField: r1 = r0->field_4f
    //     0x10e8a60: ldur            w1, [x0, #0x4f]
    // 0x10e8a64: DecompressPointer r1
    //     0x10e8a64: add             x1, x1, HEAP, lsl #32
    // 0x10e8a68: cmp             w1, NULL
    // 0x10e8a6c: b.eq            #0x10e8b00
    // 0x10e8a70: LoadField: r4 = r1->field_7
    //     0x10e8a70: ldur            w4, [x1, #7]
    // 0x10e8a74: DecompressPointer r4
    //     0x10e8a74: add             x4, x4, HEAP, lsl #32
    // 0x10e8a78: stur            x4, [fp, #-8]
    // 0x10e8a7c: cmp             w4, NULL
    // 0x10e8a80: b.eq            #0x10e8b04
    // 0x10e8a84: mov             x0, x4
    // 0x10e8a88: r2 = Null
    //     0x10e8a88: mov             x2, NULL
    // 0x10e8a8c: r1 = Null
    //     0x10e8a8c: mov             x1, NULL
    // 0x10e8a90: r4 = LoadClassIdInstr(r0)
    //     0x10e8a90: ldur            x4, [x0, #-1]
    //     0x10e8a94: ubfx            x4, x4, #0xc, #0x14
    // 0x10e8a98: r17 = 4205
    //     0x10e8a98: mov             x17, #0x106d
    // 0x10e8a9c: cmp             x4, x17
    // 0x10e8aa0: b.eq            #0x10e8ab8
    // 0x10e8aa4: r8 = ToolbarItemsParentData
    //     0x10e8aa4: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0x10e8aa8: ldr             x8, [x8, #0x6c0]
    // 0x10e8aac: r3 = Null
    //     0x10e8aac: add             x3, PP, #0xcc, lsl #12  ; [pp+0xccd38] Null
    //     0x10e8ab0: ldr             x3, [x3, #0xd38]
    // 0x10e8ab4: r0 = DefaultTypeTest()
    //     0x10e8ab4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x10e8ab8: ldur            x0, [fp, #-8]
    // 0x10e8abc: LoadField: r3 = r0->field_7
    //     0x10e8abc: ldur            w3, [x0, #7]
    // 0x10e8ac0: DecompressPointer r3
    //     0x10e8ac0: add             x3, x3, HEAP, lsl #32
    // 0x10e8ac4: ldur            x2, [fp, #-0x20]
    // 0x10e8ac8: stur            x3, [fp, #-0x28]
    // 0x10e8acc: r1 = Function '<anonymous closure>':.
    //     0x10e8acc: add             x1, PP, #0xcc, lsl #12  ; [pp+0xccd48] AnonymousClosure: (0x10e8b08), in [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::hitTestChildren (0x10e9c2c)
    //     0x10e8ad0: ldr             x1, [x1, #0xd48]
    // 0x10e8ad4: r0 = AllocateClosure()
    //     0x10e8ad4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e8ad8: ldur            x1, [fp, #-0x10]
    // 0x10e8adc: mov             x2, x0
    // 0x10e8ae0: ldur            x3, [fp, #-0x28]
    // 0x10e8ae4: ldur            x5, [fp, #-0x18]
    // 0x10e8ae8: r0 = addWithPaintOffset()
    //     0x10e8ae8: bl              #0xaf9d3c  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithPaintOffset
    // 0x10e8aec: LeaveFrame
    //     0x10e8aec: mov             SP, fp
    //     0x10e8af0: ldp             fp, lr, [SP], #0x10
    // 0x10e8af4: ret
    //     0x10e8af4: ret             
    // 0x10e8af8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e8af8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e8afc: b               #0x10e8a48
    // 0x10e8b00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e8b00: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10e8b04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e8b04: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _TextSelectionToolbarTrailingEdgeAlignRenderBox(/* No info */) {
    // ** addr: 0x11cfc68, size: 0x90
    // 0x11cfc68: EnterFrame
    //     0x11cfc68: stp             fp, lr, [SP, #-0x10]!
    //     0x11cfc6c: mov             fp, SP
    // 0x11cfc70: AllocStack(0x8)
    //     0x11cfc70: sub             SP, SP, #8
    // 0x11cfc74: SetupParameters(_TextSelectionToolbarTrailingEdgeAlignRenderBox this /* r1 => r1, fp-0x8 */, dynamic _ /* r3 => r0 */)
    //     0x11cfc74: mov             x0, x3
    //     0x11cfc78: stur            x1, [fp, #-8]
    // 0x11cfc7c: CheckStackOverflow
    //     0x11cfc7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cfc80: cmp             SP, x16
    //     0x11cfc84: b.ls            #0x11cfcf0
    // 0x11cfc88: StoreField: r1->field_5b = r0
    //     0x11cfc88: stur            w0, [x1, #0x5b]
    //     0x11cfc8c: ldurb           w16, [x1, #-1]
    //     0x11cfc90: ldurb           w17, [x0, #-1]
    //     0x11cfc94: and             x16, x17, x16, lsr #2
    //     0x11cfc98: tst             x16, HEAP, lsr #32
    //     0x11cfc9c: b.eq            #0x11cfca4
    //     0x11cfca0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cfca4: StoreField: r1->field_57 = r2
    //     0x11cfca4: stur            w2, [x1, #0x57]
    // 0x11cfca8: r0 = _LayoutCacheStorage()
    //     0x11cfca8: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11cfcac: ldur            x2, [fp, #-8]
    // 0x11cfcb0: StoreField: r2->field_47 = r0
    //     0x11cfcb0: stur            w0, [x2, #0x47]
    //     0x11cfcb4: ldurb           w16, [x2, #-1]
    //     0x11cfcb8: ldurb           w17, [x0, #-1]
    //     0x11cfcbc: and             x16, x17, x16, lsr #2
    //     0x11cfcc0: tst             x16, HEAP, lsr #32
    //     0x11cfcc4: b.eq            #0x11cfccc
    //     0x11cfcc8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11cfccc: mov             x1, x2
    // 0x11cfcd0: r0 = RenderObject()
    //     0x11cfcd0: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11cfcd4: ldur            x1, [fp, #-8]
    // 0x11cfcd8: r2 = Null
    //     0x11cfcd8: mov             x2, NULL
    // 0x11cfcdc: r0 = child=()
    //     0x11cfcdc: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11cfce0: r0 = Null
    //     0x11cfce0: mov             x0, NULL
    // 0x11cfce4: LeaveFrame
    //     0x11cfce4: mov             SP, fp
    //     0x11cfce8: ldp             fp, lr, [SP], #0x10
    // 0x11cfcec: ret
    //     0x11cfcec: ret             
    // 0x11cfcf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cfcf0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cfcf4: b               #0x11cfc88
  }
}

// class id: 5693, size: 0x24, field offset: 0x1c
class _TextSelectionToolbarOverflowableState extends _MixinApplication117&State&TickerProviderStateMixin {

  _ build(/* No info */) {
    // ** addr: 0xd4a764, size: 0x2d8
    // 0xd4a764: EnterFrame
    //     0xd4a764: stp             fp, lr, [SP, #-0x10]!
    //     0xd4a768: mov             fp, SP
    // 0xd4a76c: AllocStack(0x58)
    //     0xd4a76c: sub             SP, SP, #0x58
    // 0xd4a770: SetupParameters(_TextSelectionToolbarOverflowableState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd4a770: mov             x0, x1
    //     0xd4a774: stur            x1, [fp, #-8]
    //     0xd4a778: mov             x1, x2
    //     0xd4a77c: stur            x2, [fp, #-0x10]
    // 0xd4a780: CheckStackOverflow
    //     0xd4a780: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4a784: cmp             SP, x16
    //     0xd4a788: b.ls            #0xd4aa2c
    // 0xd4a78c: r1 = 1
    //     0xd4a78c: mov             x1, #1
    // 0xd4a790: r0 = AllocateContext()
    //     0xd4a790: bl              #0x13de838  ; AllocateContextStub
    // 0xd4a794: mov             x2, x0
    // 0xd4a798: ldur            x0, [fp, #-8]
    // 0xd4a79c: stur            x2, [fp, #-0x18]
    // 0xd4a7a0: StoreField: r2->field_f = r0
    //     0xd4a7a0: stur            w0, [x2, #0xf]
    // 0xd4a7a4: ldur            x1, [fp, #-0x10]
    // 0xd4a7a8: r0 = of()
    //     0xd4a7a8: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xd4a7ac: ldur            x1, [fp, #-0x10]
    // 0xd4a7b0: stur            x0, [fp, #-0x20]
    // 0xd4a7b4: r0 = of()
    //     0xd4a7b4: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xd4a7b8: mov             x2, x0
    // 0xd4a7bc: ldur            x0, [fp, #-8]
    // 0xd4a7c0: stur            x2, [fp, #-0x40]
    // 0xd4a7c4: LoadField: r3 = r0->field_1f
    //     0xd4a7c4: ldur            w3, [x0, #0x1f]
    // 0xd4a7c8: DecompressPointer r3
    //     0xd4a7c8: add             x3, x3, HEAP, lsl #32
    // 0xd4a7cc: stur            x3, [fp, #-0x38]
    // 0xd4a7d0: LoadField: r4 = r0->field_1b
    //     0xd4a7d0: ldur            w4, [x0, #0x1b]
    // 0xd4a7d4: DecompressPointer r4
    //     0xd4a7d4: add             x4, x4, HEAP, lsl #32
    // 0xd4a7d8: stur            x4, [fp, #-0x30]
    // 0xd4a7dc: LoadField: r1 = r0->field_b
    //     0xd4a7dc: ldur            w1, [x0, #0xb]
    // 0xd4a7e0: DecompressPointer r1
    //     0xd4a7e0: add             x1, x1, HEAP, lsl #32
    // 0xd4a7e4: cmp             w1, NULL
    // 0xd4a7e8: b.eq            #0xd4aa34
    // 0xd4a7ec: LoadField: r5 = r1->field_f
    //     0xd4a7ec: ldur            w5, [x1, #0xf]
    // 0xd4a7f0: DecompressPointer r5
    //     0xd4a7f0: add             x5, x5, HEAP, lsl #32
    // 0xd4a7f4: stur            x5, [fp, #-0x28]
    // 0xd4a7f8: tbnz            w4, #4, #0xd4a81c
    // 0xd4a7fc: r1 = <StandardComponentType>
    //     0xd4a7fc: add             x1, PP, #0x95, lsl #12  ; [pp+0x95fb0] TypeArguments: <StandardComponentType>
    //     0xd4a800: ldr             x1, [x1, #0xfb0]
    // 0xd4a804: r0 = ValueKey()
    //     0xd4a804: bl              #0x8e283c  ; AllocateValueKeyStub -> ValueKey<X0> (size=0x10)
    // 0xd4a808: mov             x1, x0
    // 0xd4a80c: r0 = Instance_StandardComponentType
    //     0xd4a80c: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa34e0] Obj!StandardComponentType@12c2501
    //     0xd4a810: ldr             x0, [x0, #0x4e0]
    // 0xd4a814: StoreField: r1->field_b = r0
    //     0xd4a814: stur            w0, [x1, #0xb]
    // 0xd4a818: b               #0xd4a838
    // 0xd4a81c: r1 = <StandardComponentType>
    //     0xd4a81c: add             x1, PP, #0x95, lsl #12  ; [pp+0x95fb0] TypeArguments: <StandardComponentType>
    //     0xd4a820: ldr             x1, [x1, #0xfb0]
    // 0xd4a824: r0 = ValueKey()
    //     0xd4a824: bl              #0x8e283c  ; AllocateValueKeyStub -> ValueKey<X0> (size=0x10)
    // 0xd4a828: mov             x1, x0
    // 0xd4a82c: r0 = Instance_StandardComponentType
    //     0xd4a82c: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa34e8] Obj!StandardComponentType@12c24e1
    //     0xd4a830: ldr             x0, [x0, #0x4e8]
    // 0xd4a834: StoreField: r1->field_b = r0
    //     0xd4a834: stur            w0, [x1, #0xb]
    // 0xd4a838: ldur            x0, [fp, #-0x30]
    // 0xd4a83c: stur            x1, [fp, #-0x50]
    // 0xd4a840: tbnz            w0, #4, #0xd4a850
    // 0xd4a844: r2 = Instance_IconData
    //     0xd4a844: add             x2, PP, #0x17, lsl #12  ; [pp+0x176d8] Obj!IconData@128a2d1
    //     0xd4a848: ldr             x2, [x2, #0x6d8]
    // 0xd4a84c: b               #0xd4a858
    // 0xd4a850: r2 = Instance_IconData
    //     0xd4a850: add             x2, PP, #0x21, lsl #12  ; [pp+0x21ec8] Obj!IconData@128a2b1
    //     0xd4a854: ldr             x2, [x2, #0xec8]
    // 0xd4a858: stur            x2, [fp, #-0x48]
    // 0xd4a85c: r0 = Icon()
    //     0xd4a85c: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xd4a860: mov             x2, x0
    // 0xd4a864: ldur            x0, [fp, #-0x48]
    // 0xd4a868: stur            x2, [fp, #-0x58]
    // 0xd4a86c: StoreField: r2->field_b = r0
    //     0xd4a86c: stur            w0, [x2, #0xb]
    // 0xd4a870: ldur            x3, [fp, #-0x30]
    // 0xd4a874: tbnz            w3, #4, #0xd4a8a0
    // 0xd4a878: ldur            x1, [fp, #-0x20]
    // 0xd4a87c: r0 = LoadClassIdInstr(r1)
    //     0xd4a87c: ldur            x0, [x1, #-1]
    //     0xd4a880: ubfx            x0, x0, #0xc, #0x14
    // 0xd4a884: r0 = GDT[cid_x0 + 0x15235]()
    //     0xd4a884: mov             x17, #0x5235
    //     0xd4a888: movk            x17, #1, lsl #16
    //     0xd4a88c: add             lr, x0, x17
    //     0xd4a890: ldr             lr, [x21, lr, lsl #3]
    //     0xd4a894: blr             lr
    // 0xd4a898: mov             x7, x0
    // 0xd4a89c: b               #0xd4a8c4
    // 0xd4a8a0: ldur            x1, [fp, #-0x20]
    // 0xd4a8a4: r0 = LoadClassIdInstr(r1)
    //     0xd4a8a4: ldur            x0, [x1, #-1]
    //     0xd4a8a8: ubfx            x0, x0, #0xc, #0x14
    // 0xd4a8ac: r0 = GDT[cid_x0 + 0x14db6]()
    //     0xd4a8ac: mov             x17, #0x4db6
    //     0xd4a8b0: movk            x17, #1, lsl #16
    //     0xd4a8b4: add             lr, x0, x17
    //     0xd4a8b8: ldr             lr, [x21, lr, lsl #3]
    //     0xd4a8bc: blr             lr
    // 0xd4a8c0: mov             x7, x0
    // 0xd4a8c4: ldur            x3, [fp, #-8]
    // 0xd4a8c8: ldur            x4, [fp, #-0x40]
    // 0xd4a8cc: ldur            x5, [fp, #-0x38]
    // 0xd4a8d0: ldur            x1, [fp, #-0x30]
    // 0xd4a8d4: ldur            x6, [fp, #-0x28]
    // 0xd4a8d8: ldur            x2, [fp, #-0x50]
    // 0xd4a8dc: ldur            x0, [fp, #-0x58]
    // 0xd4a8e0: stur            x7, [fp, #-0x20]
    // 0xd4a8e4: r0 = _TextSelectionToolbarOverflowButton()
    //     0xd4a8e4: bl              #0xd4ab20  ; Allocate_TextSelectionToolbarOverflowButtonStub -> _TextSelectionToolbarOverflowButton (size=0x18)
    // 0xd4a8e8: mov             x3, x0
    // 0xd4a8ec: ldur            x0, [fp, #-0x58]
    // 0xd4a8f0: stur            x3, [fp, #-0x48]
    // 0xd4a8f4: StoreField: r3->field_b = r0
    //     0xd4a8f4: stur            w0, [x3, #0xb]
    // 0xd4a8f8: ldur            x2, [fp, #-0x18]
    // 0xd4a8fc: r1 = Function '<anonymous closure>':.
    //     0xd4a8fc: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa34f0] AnonymousClosure: (0xd4ab2c), in [package:flutter/src/material/text_selection_toolbar.dart] _TextSelectionToolbarOverflowableState::build (0xd4a764)
    //     0xd4a900: ldr             x1, [x1, #0x4f0]
    // 0xd4a904: r0 = AllocateClosure()
    //     0xd4a904: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd4a908: mov             x1, x0
    // 0xd4a90c: ldur            x0, [fp, #-0x48]
    // 0xd4a910: StoreField: r0->field_f = r1
    //     0xd4a910: stur            w1, [x0, #0xf]
    // 0xd4a914: ldur            x1, [fp, #-0x20]
    // 0xd4a918: StoreField: r0->field_13 = r1
    //     0xd4a918: stur            w1, [x0, #0x13]
    // 0xd4a91c: ldur            x1, [fp, #-0x50]
    // 0xd4a920: StoreField: r0->field_7 = r1
    //     0xd4a920: stur            w1, [x0, #7]
    // 0xd4a924: r1 = Null
    //     0xd4a924: mov             x1, NULL
    // 0xd4a928: r2 = 2
    //     0xd4a928: mov             x2, #2
    // 0xd4a92c: r0 = AllocateArray()
    //     0xd4a92c: bl              #0x13df928  ; AllocateArrayStub
    // 0xd4a930: mov             x2, x0
    // 0xd4a934: ldur            x0, [fp, #-0x48]
    // 0xd4a938: stur            x2, [fp, #-0x18]
    // 0xd4a93c: StoreField: r2->field_f = r0
    //     0xd4a93c: stur            w0, [x2, #0xf]
    // 0xd4a940: r1 = <Widget>
    //     0xd4a940: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd4a944: r0 = AllocateGrowableArray()
    //     0xd4a944: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd4a948: mov             x3, x0
    // 0xd4a94c: ldur            x0, [fp, #-0x18]
    // 0xd4a950: stur            x3, [fp, #-0x20]
    // 0xd4a954: StoreField: r3->field_f = r0
    //     0xd4a954: stur            w0, [x3, #0xf]
    // 0xd4a958: r0 = 2
    //     0xd4a958: mov             x0, #2
    // 0xd4a95c: StoreField: r3->field_b = r0
    //     0xd4a95c: stur            w0, [x3, #0xb]
    // 0xd4a960: ldur            x0, [fp, #-8]
    // 0xd4a964: LoadField: r1 = r0->field_b
    //     0xd4a964: ldur            w1, [x0, #0xb]
    // 0xd4a968: DecompressPointer r1
    //     0xd4a968: add             x1, x1, HEAP, lsl #32
    // 0xd4a96c: cmp             w1, NULL
    // 0xd4a970: b.eq            #0xd4aa38
    // 0xd4a974: LoadField: r2 = r1->field_b
    //     0xd4a974: ldur            w2, [x1, #0xb]
    // 0xd4a978: DecompressPointer r2
    //     0xd4a978: add             x2, x2, HEAP, lsl #32
    // 0xd4a97c: mov             x1, x3
    // 0xd4a980: r0 = addAll()
    //     0xd4a980: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0xd4a984: r0 = _TextSelectionToolbarItemsLayout()
    //     0xd4a984: bl              #0xd4ab14  ; Allocate_TextSelectionToolbarItemsLayoutStub -> _TextSelectionToolbarItemsLayout (size=0x1c)
    // 0xd4a988: mov             x1, x0
    // 0xd4a98c: ldur            x0, [fp, #-0x28]
    // 0xd4a990: StoreField: r1->field_f = r0
    //     0xd4a990: stur            w0, [x1, #0xf]
    // 0xd4a994: ldur            x0, [fp, #-0x30]
    // 0xd4a998: StoreField: r1->field_13 = r0
    //     0xd4a998: stur            w0, [x1, #0x13]
    // 0xd4a99c: ldur            x3, [fp, #-0x40]
    // 0xd4a9a0: ArrayStore: r1[0] = r3  ; List_4
    //     0xd4a9a0: stur            w3, [x1, #0x17]
    // 0xd4a9a4: ldur            x2, [fp, #-0x20]
    // 0xd4a9a8: StoreField: r1->field_b = r2
    //     0xd4a9a8: stur            w2, [x1, #0xb]
    // 0xd4a9ac: mov             x2, x1
    // 0xd4a9b0: ldur            x1, [fp, #-0x10]
    // 0xd4a9b4: r0 = _defaultToolbarBuilder()
    //     0xd4a9b4: bl              #0xd4aae0  ; [package:flutter/src/material/text_selection_toolbar.dart] TextSelectionToolbar::_defaultToolbarBuilder
    // 0xd4a9b8: stur            x0, [fp, #-8]
    // 0xd4a9bc: r0 = AnimatedSize()
    //     0xd4a9bc: bl              #0xd4aad4  ; AllocateAnimatedSizeStub -> AnimatedSize (size=0x28)
    // 0xd4a9c0: mov             x1, x0
    // 0xd4a9c4: ldur            x0, [fp, #-8]
    // 0xd4a9c8: stur            x1, [fp, #-0x10]
    // 0xd4a9cc: StoreField: r1->field_b = r0
    //     0xd4a9cc: stur            w0, [x1, #0xb]
    // 0xd4a9d0: r0 = Instance_Alignment
    //     0xd4a9d0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xd4a9d4: ldr             x0, [x0, #0xb80]
    // 0xd4a9d8: StoreField: r1->field_f = r0
    //     0xd4a9d8: stur            w0, [x1, #0xf]
    // 0xd4a9dc: r0 = Instance__Linear
    //     0xd4a9dc: ldr             x0, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xd4a9e0: StoreField: r1->field_13 = r0
    //     0xd4a9e0: stur            w0, [x1, #0x13]
    // 0xd4a9e4: r0 = Instance_Duration
    //     0xd4a9e4: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa34f8] Obj!Duration@12c8ad1
    //     0xd4a9e8: ldr             x0, [x0, #0x4f8]
    // 0xd4a9ec: ArrayStore: r1[0] = r0  ; List_4
    //     0xd4a9ec: stur            w0, [x1, #0x17]
    // 0xd4a9f0: r0 = Instance_Clip
    //     0xd4a9f0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xd4a9f4: ldr             x0, [x0, #0x850]
    // 0xd4a9f8: StoreField: r1->field_1f = r0
    //     0xd4a9f8: stur            w0, [x1, #0x1f]
    // 0xd4a9fc: r0 = _TextSelectionToolbarTrailingEdgeAlign()
    //     0xd4a9fc: bl              #0xd4aac8  ; Allocate_TextSelectionToolbarTrailingEdgeAlignStub -> _TextSelectionToolbarTrailingEdgeAlign (size=0x18)
    // 0xd4aa00: ldur            x1, [fp, #-0x30]
    // 0xd4aa04: StoreField: r0->field_f = r1
    //     0xd4aa04: stur            w1, [x0, #0xf]
    // 0xd4aa08: ldur            x1, [fp, #-0x40]
    // 0xd4aa0c: StoreField: r0->field_13 = r1
    //     0xd4aa0c: stur            w1, [x0, #0x13]
    // 0xd4aa10: ldur            x1, [fp, #-0x10]
    // 0xd4aa14: StoreField: r0->field_b = r1
    //     0xd4aa14: stur            w1, [x0, #0xb]
    // 0xd4aa18: ldur            x1, [fp, #-0x38]
    // 0xd4aa1c: StoreField: r0->field_7 = r1
    //     0xd4aa1c: stur            w1, [x0, #7]
    // 0xd4aa20: LeaveFrame
    //     0xd4aa20: mov             SP, fp
    //     0xd4aa24: ldp             fp, lr, [SP], #0x10
    // 0xd4aa28: ret
    //     0xd4aa28: ret             
    // 0xd4aa2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4aa2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4aa30: b               #0xd4a78c
    // 0xd4aa34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4aa34: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4aa38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4aa38: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd4ab2c, size: 0x60
    // 0xd4ab2c: EnterFrame
    //     0xd4ab2c: stp             fp, lr, [SP, #-0x10]!
    //     0xd4ab30: mov             fp, SP
    // 0xd4ab34: AllocStack(0x8)
    //     0xd4ab34: sub             SP, SP, #8
    // 0xd4ab38: SetupParameters([dynamic _ /* r0 */])
    //     0xd4ab38: ldr             x0, [fp, #0x10]
    //     0xd4ab3c: ldur            w2, [x0, #0x17]
    //     0xd4ab40: add             x2, x2, HEAP, lsl #32
    // 0xd4ab44: CheckStackOverflow
    //     0xd4ab44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4ab48: cmp             SP, x16
    //     0xd4ab4c: b.ls            #0xd4ab84
    // 0xd4ab50: LoadField: r0 = r2->field_f
    //     0xd4ab50: ldur            w0, [x2, #0xf]
    // 0xd4ab54: DecompressPointer r0
    //     0xd4ab54: add             x0, x0, HEAP, lsl #32
    // 0xd4ab58: stur            x0, [fp, #-8]
    // 0xd4ab5c: r1 = Function '<anonymous closure>':.
    //     0xd4ab5c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3500] AnonymousClosure: (0xd4ab8c), in [package:flutter/src/material/text_selection_toolbar.dart] _TextSelectionToolbarOverflowableState::build (0xd4a764)
    //     0xd4ab60: ldr             x1, [x1, #0x500]
    // 0xd4ab64: r0 = AllocateClosure()
    //     0xd4ab64: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd4ab68: ldur            x1, [fp, #-8]
    // 0xd4ab6c: mov             x2, x0
    // 0xd4ab70: r0 = setState()
    //     0xd4ab70: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd4ab74: r0 = Null
    //     0xd4ab74: mov             x0, NULL
    // 0xd4ab78: LeaveFrame
    //     0xd4ab78: mov             SP, fp
    //     0xd4ab7c: ldp             fp, lr, [SP], #0x10
    // 0xd4ab80: ret
    //     0xd4ab80: ret             
    // 0xd4ab84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4ab84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4ab88: b               #0xd4ab50
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd4ab8c, size: 0x2c
    // 0xd4ab8c: ldr             x1, [SP]
    // 0xd4ab90: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xd4ab90: ldur            w2, [x1, #0x17]
    // 0xd4ab94: DecompressPointer r2
    //     0xd4ab94: add             x2, x2, HEAP, lsl #32
    // 0xd4ab98: LoadField: r1 = r2->field_f
    //     0xd4ab98: ldur            w1, [x2, #0xf]
    // 0xd4ab9c: DecompressPointer r1
    //     0xd4ab9c: add             x1, x1, HEAP, lsl #32
    // 0xd4aba0: LoadField: r2 = r1->field_1b
    //     0xd4aba0: ldur            w2, [x1, #0x1b]
    // 0xd4aba4: DecompressPointer r2
    //     0xd4aba4: add             x2, x2, HEAP, lsl #32
    // 0xd4aba8: eor             x3, x2, #0x10
    // 0xd4abac: StoreField: r1->field_1b = r3
    //     0xd4abac: stur            w3, [x1, #0x1b]
    // 0xd4abb0: r0 = Null
    //     0xd4abb0: mov             x0, NULL
    // 0xd4abb4: ret
    //     0xd4abb4: ret             
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf3e82c, size: 0x104
    // 0xf3e82c: EnterFrame
    //     0xf3e82c: stp             fp, lr, [SP, #-0x10]!
    //     0xf3e830: mov             fp, SP
    // 0xf3e834: AllocStack(0x28)
    //     0xf3e834: sub             SP, SP, #0x28
    // 0xf3e838: SetupParameters(_TextSelectionToolbarOverflowableState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf3e838: mov             x4, x1
    //     0xf3e83c: mov             x3, x2
    //     0xf3e840: stur            x1, [fp, #-8]
    //     0xf3e844: stur            x2, [fp, #-0x10]
    // 0xf3e848: CheckStackOverflow
    //     0xf3e848: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3e84c: cmp             SP, x16
    //     0xf3e850: b.ls            #0xf3e924
    // 0xf3e854: mov             x0, x3
    // 0xf3e858: r2 = Null
    //     0xf3e858: mov             x2, NULL
    // 0xf3e85c: r1 = Null
    //     0xf3e85c: mov             x1, NULL
    // 0xf3e860: r4 = 60
    //     0xf3e860: mov             x4, #0x3c
    // 0xf3e864: branchIfSmi(r0, 0xf3e870)
    //     0xf3e864: tbz             w0, #0, #0xf3e870
    // 0xf3e868: r4 = LoadClassIdInstr(r0)
    //     0xf3e868: ldur            x4, [x0, #-1]
    //     0xf3e86c: ubfx            x4, x4, #0xc, #0x14
    // 0xf3e870: r17 = 6413
    //     0xf3e870: mov             x17, #0x190d
    // 0xf3e874: cmp             x4, x17
    // 0xf3e878: b.eq            #0xf3e890
    // 0xf3e87c: r8 = _TextSelectionToolbarOverflowable
    //     0xf3e87c: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3508] Type: _TextSelectionToolbarOverflowable
    //     0xf3e880: ldr             x8, [x8, #0x508]
    // 0xf3e884: r3 = Null
    //     0xf3e884: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3510] Null
    //     0xf3e888: ldr             x3, [x3, #0x510]
    // 0xf3e88c: r0 = _TextSelectionToolbarOverflowable()
    //     0xf3e88c: bl              #0xd05bec  ; IsType__TextSelectionToolbarOverflowable_Stub
    // 0xf3e890: ldur            x3, [fp, #-8]
    // 0xf3e894: LoadField: r2 = r3->field_7
    //     0xf3e894: ldur            w2, [x3, #7]
    // 0xf3e898: DecompressPointer r2
    //     0xf3e898: add             x2, x2, HEAP, lsl #32
    // 0xf3e89c: ldur            x0, [fp, #-0x10]
    // 0xf3e8a0: r1 = Null
    //     0xf3e8a0: mov             x1, NULL
    // 0xf3e8a4: cmp             w2, NULL
    // 0xf3e8a8: b.eq            #0xf3e8cc
    // 0xf3e8ac: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf3e8ac: ldur            w4, [x2, #0x17]
    // 0xf3e8b0: DecompressPointer r4
    //     0xf3e8b0: add             x4, x4, HEAP, lsl #32
    // 0xf3e8b4: r8 = X0 bound StatefulWidget
    //     0xf3e8b4: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf3e8b8: ldr             x8, [x8, #0x498]
    // 0xf3e8bc: LoadField: r9 = r4->field_7
    //     0xf3e8bc: ldur            x9, [x4, #7]
    // 0xf3e8c0: r3 = Null
    //     0xf3e8c0: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3520] Null
    //     0xf3e8c4: ldr             x3, [x3, #0x520]
    // 0xf3e8c8: blr             x9
    // 0xf3e8cc: ldur            x1, [fp, #-8]
    // 0xf3e8d0: LoadField: r0 = r1->field_b
    //     0xf3e8d0: ldur            w0, [x1, #0xb]
    // 0xf3e8d4: DecompressPointer r0
    //     0xf3e8d4: add             x0, x0, HEAP, lsl #32
    // 0xf3e8d8: cmp             w0, NULL
    // 0xf3e8dc: b.eq            #0xf3e92c
    // 0xf3e8e0: LoadField: r2 = r0->field_b
    //     0xf3e8e0: ldur            w2, [x0, #0xb]
    // 0xf3e8e4: DecompressPointer r2
    //     0xf3e8e4: add             x2, x2, HEAP, lsl #32
    // 0xf3e8e8: ldur            x0, [fp, #-0x10]
    // 0xf3e8ec: LoadField: r3 = r0->field_b
    //     0xf3e8ec: ldur            w3, [x0, #0xb]
    // 0xf3e8f0: DecompressPointer r3
    //     0xf3e8f0: add             x3, x3, HEAP, lsl #32
    // 0xf3e8f4: r16 = <Widget>
    //     0xf3e8f4: ldr             x16, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xf3e8f8: stp             x2, x16, [SP, #8]
    // 0xf3e8fc: str             x3, [SP]
    // 0xf3e900: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xf3e900: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xf3e904: r0 = listEquals()
    //     0xf3e904: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0xf3e908: tbz             w0, #4, #0xf3e914
    // 0xf3e90c: ldur            x1, [fp, #-8]
    // 0xf3e910: r0 = _reset()
    //     0xf3e910: bl              #0xf3e930  ; [package:flutter/src/material/text_selection_toolbar.dart] _TextSelectionToolbarOverflowableState::_reset
    // 0xf3e914: r0 = Null
    //     0xf3e914: mov             x0, NULL
    // 0xf3e918: LeaveFrame
    //     0xf3e918: mov             SP, fp
    //     0xf3e91c: ldp             fp, lr, [SP], #0x10
    // 0xf3e920: ret
    //     0xf3e920: ret             
    // 0xf3e924: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3e924: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3e928: b               #0xf3e854
    // 0xf3e92c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3e92c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _reset(/* No info */) {
    // ** addr: 0xf3e930, size: 0x4c
    // 0xf3e930: EnterFrame
    //     0xf3e930: stp             fp, lr, [SP, #-0x10]!
    //     0xf3e934: mov             fp, SP
    // 0xf3e938: AllocStack(0x8)
    //     0xf3e938: sub             SP, SP, #8
    // 0xf3e93c: SetupParameters(_TextSelectionToolbarOverflowableState this /* r1 => r1, fp-0x8 */)
    //     0xf3e93c: stur            x1, [fp, #-8]
    // 0xf3e940: r0 = UniqueKey()
    //     0xf3e940: bl              #0xb8f328  ; AllocateUniqueKeyStub -> UniqueKey (size=0x8)
    // 0xf3e944: ldur            x1, [fp, #-8]
    // 0xf3e948: StoreField: r1->field_1f = r0
    //     0xf3e948: stur            w0, [x1, #0x1f]
    //     0xf3e94c: ldurb           w16, [x1, #-1]
    //     0xf3e950: ldurb           w17, [x0, #-1]
    //     0xf3e954: and             x16, x17, x16, lsr #2
    //     0xf3e958: tst             x16, HEAP, lsr #32
    //     0xf3e95c: b.eq            #0xf3e964
    //     0xf3e960: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf3e964: r2 = false
    //     0xf3e964: add             x2, NULL, #0x30  ; false
    // 0xf3e968: StoreField: r1->field_1b = r2
    //     0xf3e968: stur            w2, [x1, #0x1b]
    // 0xf3e96c: r0 = Null
    //     0xf3e96c: mov             x0, NULL
    // 0xf3e970: LeaveFrame
    //     0xf3e970: mov             SP, fp
    //     0xf3e974: ldp             fp, lr, [SP], #0x10
    // 0xf3e978: ret
    //     0xf3e978: ret             
  }
}

// class id: 5814, size: 0x4c, field offset: 0x4c
class _TextSelectionToolbarItemsLayoutElement extends MultiChildRenderObjectElement {
}

// class id: 6137, size: 0x18, field offset: 0xc
//   const constructor, 
class _TextSelectionToolbarOverflowButton extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfbec64, size: 0xc4
    // 0xfbec64: EnterFrame
    //     0xfbec64: stp             fp, lr, [SP, #-0x10]!
    //     0xfbec68: mov             fp, SP
    // 0xfbec6c: AllocStack(0x20)
    //     0xfbec6c: sub             SP, SP, #0x20
    // 0xfbec70: LoadField: r0 = r1->field_b
    //     0xfbec70: ldur            w0, [x1, #0xb]
    // 0xfbec74: DecompressPointer r0
    //     0xfbec74: add             x0, x0, HEAP, lsl #32
    // 0xfbec78: stur            x0, [fp, #-0x18]
    // 0xfbec7c: LoadField: r2 = r1->field_f
    //     0xfbec7c: ldur            w2, [x1, #0xf]
    // 0xfbec80: DecompressPointer r2
    //     0xfbec80: add             x2, x2, HEAP, lsl #32
    // 0xfbec84: stur            x2, [fp, #-0x10]
    // 0xfbec88: LoadField: r3 = r1->field_13
    //     0xfbec88: ldur            w3, [x1, #0x13]
    // 0xfbec8c: DecompressPointer r3
    //     0xfbec8c: add             x3, x3, HEAP, lsl #32
    // 0xfbec90: stur            x3, [fp, #-8]
    // 0xfbec94: r0 = IconButton()
    //     0xfbec94: bl              #0xd16288  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0xfbec98: mov             x1, x0
    // 0xfbec9c: ldur            x0, [fp, #-0x10]
    // 0xfbeca0: stur            x1, [fp, #-0x20]
    // 0xfbeca4: StoreField: r1->field_3b = r0
    //     0xfbeca4: stur            w0, [x1, #0x3b]
    // 0xfbeca8: r0 = false
    //     0xfbeca8: add             x0, NULL, #0x30  ; false
    // 0xfbecac: StoreField: r1->field_4f = r0
    //     0xfbecac: stur            w0, [x1, #0x4f]
    // 0xfbecb0: ldur            x2, [fp, #-8]
    // 0xfbecb4: StoreField: r1->field_53 = r2
    //     0xfbecb4: stur            w2, [x1, #0x53]
    // 0xfbecb8: ldur            x2, [fp, #-0x18]
    // 0xfbecbc: StoreField: r1->field_1f = r2
    //     0xfbecbc: stur            w2, [x1, #0x1f]
    // 0xfbecc0: r2 = Instance__IconButtonVariant
    //     0xfbecc0: add             x2, PP, #0x17, lsl #12  ; [pp+0x177a8] Obj!_IconButtonVariant@12c57a1
    //     0xfbecc4: ldr             x2, [x2, #0x7a8]
    // 0xfbecc8: StoreField: r1->field_6f = r2
    //     0xfbecc8: stur            w2, [x1, #0x6f]
    // 0xfbeccc: r0 = Material()
    //     0xfbeccc: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xfbecd0: r1 = Instance_MaterialType
    //     0xfbecd0: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c988] Obj!MaterialType@12c53c1
    //     0xfbecd4: ldr             x1, [x1, #0x988]
    // 0xfbecd8: StoreField: r0->field_f = r1
    //     0xfbecd8: stur            w1, [x0, #0xf]
    // 0xfbecdc: ArrayStore: r0[0] = rZR  ; List_8
    //     0xfbecdc: stur            xzr, [x0, #0x17]
    // 0xfbece0: r1 = Instance_Color
    //     0xfbece0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xfbece4: ldr             x1, [x1, #0x810]
    // 0xfbece8: StoreField: r0->field_1f = r1
    //     0xfbece8: stur            w1, [x0, #0x1f]
    // 0xfbecec: r1 = true
    //     0xfbecec: add             x1, NULL, #0x20  ; true
    // 0xfbecf0: StoreField: r0->field_33 = r1
    //     0xfbecf0: stur            w1, [x0, #0x33]
    // 0xfbecf4: r1 = Instance_Clip
    //     0xfbecf4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfbecf8: ldr             x1, [x1, #0x840]
    // 0xfbecfc: StoreField: r0->field_37 = r1
    //     0xfbecfc: stur            w1, [x0, #0x37]
    // 0xfbed00: r1 = Instance_Duration
    //     0xfbed00: add             x1, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xfbed04: ldr             x1, [x1, #0x318]
    // 0xfbed08: StoreField: r0->field_3b = r1
    //     0xfbed08: stur            w1, [x0, #0x3b]
    // 0xfbed0c: ldur            x1, [fp, #-0x20]
    // 0xfbed10: StoreField: r0->field_b = r1
    //     0xfbed10: stur            w1, [x0, #0xb]
    // 0xfbed14: r1 = false
    //     0xfbed14: add             x1, NULL, #0x30  ; false
    // 0xfbed18: StoreField: r0->field_13 = r1
    //     0xfbed18: stur            w1, [x0, #0x13]
    // 0xfbed1c: LeaveFrame
    //     0xfbed1c: mov             SP, fp
    //     0xfbed20: ldp             fp, lr, [SP], #0x10
    // 0xfbed24: ret
    //     0xfbed24: ret             
  }
}

// class id: 6138, size: 0x10, field offset: 0xc
//   const constructor, 
class _TextSelectionToolbarContainer extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfbea70, size: 0xbc
    // 0xfbea70: EnterFrame
    //     0xfbea70: stp             fp, lr, [SP, #-0x10]!
    //     0xfbea74: mov             fp, SP
    // 0xfbea78: AllocStack(0x18)
    //     0xfbea78: sub             SP, SP, #0x18
    // 0xfbea7c: SetupParameters(_TextSelectionToolbarContainer this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xfbea7c: mov             x0, x1
    //     0xfbea80: stur            x1, [fp, #-8]
    //     0xfbea84: mov             x1, x2
    // 0xfbea88: CheckStackOverflow
    //     0xfbea88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbea8c: cmp             SP, x16
    //     0xfbea90: b.ls            #0xfbeb24
    // 0xfbea94: r0 = of()
    //     0xfbea94: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfbea98: LoadField: r1 = r0->field_3f
    //     0xfbea98: ldur            w1, [x0, #0x3f]
    // 0xfbea9c: DecompressPointer r1
    //     0xfbea9c: add             x1, x1, HEAP, lsl #32
    // 0xfbeaa0: r0 = _getColor()
    //     0xfbeaa0: bl              #0xfbeb2c  ; [package:flutter/src/material/text_selection_toolbar.dart] _TextSelectionToolbarContainer::_getColor
    // 0xfbeaa4: mov             x1, x0
    // 0xfbeaa8: ldur            x0, [fp, #-8]
    // 0xfbeaac: stur            x1, [fp, #-0x18]
    // 0xfbeab0: LoadField: r2 = r0->field_b
    //     0xfbeab0: ldur            w2, [x0, #0xb]
    // 0xfbeab4: DecompressPointer r2
    //     0xfbeab4: add             x2, x2, HEAP, lsl #32
    // 0xfbeab8: stur            x2, [fp, #-0x10]
    // 0xfbeabc: r0 = Material()
    //     0xfbeabc: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xfbeac0: r1 = Instance_MaterialType
    //     0xfbeac0: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c988] Obj!MaterialType@12c53c1
    //     0xfbeac4: ldr             x1, [x1, #0x988]
    // 0xfbeac8: StoreField: r0->field_f = r1
    //     0xfbeac8: stur            w1, [x0, #0xf]
    // 0xfbeacc: d0 = 1.000000
    //     0xfbeacc: fmov            d0, #1.00000000
    // 0xfbead0: ArrayStore: r0[0] = d0  ; List_8
    //     0xfbead0: stur            d0, [x0, #0x17]
    // 0xfbead4: ldur            x1, [fp, #-0x18]
    // 0xfbead8: StoreField: r0->field_1f = r1
    //     0xfbead8: stur            w1, [x0, #0x1f]
    // 0xfbeadc: r1 = Instance_BorderRadius
    //     0xfbeadc: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f5e8] Obj!BorderRadius@129e511
    //     0xfbeae0: ldr             x1, [x1, #0x5e8]
    // 0xfbeae4: StoreField: r0->field_3f = r1
    //     0xfbeae4: stur            w1, [x0, #0x3f]
    // 0xfbeae8: r1 = true
    //     0xfbeae8: add             x1, NULL, #0x20  ; true
    // 0xfbeaec: StoreField: r0->field_33 = r1
    //     0xfbeaec: stur            w1, [x0, #0x33]
    // 0xfbeaf0: r1 = Instance_Clip
    //     0xfbeaf0: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e6f0] Obj!Clip@12c8101
    //     0xfbeaf4: ldr             x1, [x1, #0x6f0]
    // 0xfbeaf8: StoreField: r0->field_37 = r1
    //     0xfbeaf8: stur            w1, [x0, #0x37]
    // 0xfbeafc: r1 = Instance_Duration
    //     0xfbeafc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xfbeb00: ldr             x1, [x1, #0x318]
    // 0xfbeb04: StoreField: r0->field_3b = r1
    //     0xfbeb04: stur            w1, [x0, #0x3b]
    // 0xfbeb08: ldur            x1, [fp, #-0x10]
    // 0xfbeb0c: StoreField: r0->field_b = r1
    //     0xfbeb0c: stur            w1, [x0, #0xb]
    // 0xfbeb10: r1 = false
    //     0xfbeb10: add             x1, NULL, #0x30  ; false
    // 0xfbeb14: StoreField: r0->field_13 = r1
    //     0xfbeb14: stur            w1, [x0, #0x13]
    // 0xfbeb18: LeaveFrame
    //     0xfbeb18: mov             SP, fp
    //     0xfbeb1c: ldp             fp, lr, [SP], #0x10
    // 0xfbeb20: ret
    //     0xfbeb20: ret             
    // 0xfbeb24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbeb24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbeb28: b               #0xfbea94
  }
  static _ _getColor(/* No info */) {
    // ** addr: 0xfbeb2c, size: 0xf4
    // 0xfbeb2c: EnterFrame
    //     0xfbeb2c: stp             fp, lr, [SP, #-0x10]!
    //     0xfbeb30: mov             fp, SP
    // 0xfbeb34: AllocStack(0x20)
    //     0xfbeb34: sub             SP, SP, #0x20
    // 0xfbeb38: SetupParameters(dynamic _ /* r1 => r0, fp-0x10 */)
    //     0xfbeb38: mov             x0, x1
    //     0xfbeb3c: stur            x1, [fp, #-0x10]
    // 0xfbeb40: CheckStackOverflow
    //     0xfbeb40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbeb44: cmp             SP, x16
    //     0xfbeb48: b.ls            #0xfbec18
    // 0xfbeb4c: LoadField: r1 = r0->field_7
    //     0xfbeb4c: ldur            w1, [x0, #7]
    // 0xfbeb50: DecompressPointer r1
    //     0xfbeb50: add             x1, x1, HEAP, lsl #32
    // 0xfbeb54: LoadField: r2 = r1->field_7
    //     0xfbeb54: ldur            x2, [x1, #7]
    // 0xfbeb58: stur            x2, [fp, #-8]
    // 0xfbeb5c: cmp             x2, #0
    // 0xfbeb60: b.gt            #0xfbeba8
    // 0xfbeb64: r16 = Instance_Brightness
    //     0xfbeb64: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xfbeb68: stp             NULL, x16, [SP]
    // 0xfbeb6c: r1 = Null
    //     0xfbeb6c: mov             x1, NULL
    // 0xfbeb70: r4 = const [0, 0x3, 0x2, 0x1, brightness, 0x1, useMaterial3, 0x2, null]
    //     0xfbeb70: add             x4, PP, #0x13, lsl #12  ; [pp+0x13a48] List(9) [0, 0x3, 0x2, 0x1, "brightness", 0x1, "useMaterial3", 0x2, Null]
    //     0xfbeb74: ldr             x4, [x4, #0xa48]
    // 0xfbeb78: r0 = ThemeData()
    //     0xfbeb78: bl              #0x8a9c18  ; [package:flutter/src/material/theme_data.dart] ThemeData::ThemeData
    // 0xfbeb7c: LoadField: r1 = r0->field_3f
    //     0xfbeb7c: ldur            w1, [x0, #0x3f]
    // 0xfbeb80: DecompressPointer r1
    //     0xfbeb80: add             x1, x1, HEAP, lsl #32
    // 0xfbeb84: LoadField: r0 = r1->field_7b
    //     0xfbeb84: ldur            w0, [x1, #0x7b]
    // 0xfbeb88: DecompressPointer r0
    //     0xfbeb88: add             x0, x0, HEAP, lsl #32
    // 0xfbeb8c: ldur            x2, [fp, #-0x10]
    // 0xfbeb90: LoadField: r1 = r2->field_7b
    //     0xfbeb90: ldur            w1, [x2, #0x7b]
    // 0xfbeb94: DecompressPointer r1
    //     0xfbeb94: add             x1, x1, HEAP, lsl #32
    // 0xfbeb98: cmp             w0, w1
    // 0xfbeb9c: b.eq            #0xfbebec
    // 0xfbeba0: mov             x0, x1
    // 0xfbeba4: b               #0xfbebe0
    // 0xfbeba8: mov             x2, x0
    // 0xfbebac: r1 = Null
    //     0xfbebac: mov             x1, NULL
    // 0xfbebb0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xfbebb0: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xfbebb4: r0 = ThemeData()
    //     0xfbebb4: bl              #0x8a9c18  ; [package:flutter/src/material/theme_data.dart] ThemeData::ThemeData
    // 0xfbebb8: LoadField: r1 = r0->field_3f
    //     0xfbebb8: ldur            w1, [x0, #0x3f]
    // 0xfbebbc: DecompressPointer r1
    //     0xfbebbc: add             x1, x1, HEAP, lsl #32
    // 0xfbebc0: LoadField: r2 = r1->field_7b
    //     0xfbebc0: ldur            w2, [x1, #0x7b]
    // 0xfbebc4: DecompressPointer r2
    //     0xfbebc4: add             x2, x2, HEAP, lsl #32
    // 0xfbebc8: ldur            x1, [fp, #-0x10]
    // 0xfbebcc: LoadField: r3 = r1->field_7b
    //     0xfbebcc: ldur            w3, [x1, #0x7b]
    // 0xfbebd0: DecompressPointer r3
    //     0xfbebd0: add             x3, x3, HEAP, lsl #32
    // 0xfbebd4: cmp             w2, w3
    // 0xfbebd8: b.eq            #0xfbebec
    // 0xfbebdc: mov             x0, x3
    // 0xfbebe0: LeaveFrame
    //     0xfbebe0: mov             SP, fp
    //     0xfbebe4: ldp             fp, lr, [SP], #0x10
    // 0xfbebe8: ret
    //     0xfbebe8: ret             
    // 0xfbebec: ldur            x1, [fp, #-8]
    // 0xfbebf0: cmp             x1, #0
    // 0xfbebf4: b.gt            #0xfbec04
    // 0xfbebf8: r0 = Instance_Color
    //     0xfbebf8: add             x0, PP, #0x8e, lsl #12  ; [pp+0x8e128] Obj!Color@12a1ce1
    //     0xfbebfc: ldr             x0, [x0, #0x128]
    // 0xfbec00: b               #0xfbec0c
    // 0xfbec04: r0 = Instance_Color
    //     0xfbec04: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xfbec08: ldr             x0, [x0, #0xc38]
    // 0xfbec0c: LeaveFrame
    //     0xfbec0c: mov             SP, fp
    //     0xfbec10: ldp             fp, lr, [SP], #0x10
    // 0xfbec14: ret
    //     0xfbec14: ret             
    // 0xfbec18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbec18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbec1c: b               #0xfbeb4c
  }
}

// class id: 6139, size: 0x1c, field offset: 0xc
//   const constructor, 
class TextSelectionToolbar extends StatelessWidget {

  [closure] static Widget _defaultToolbarBuilder(dynamic, BuildContext, Widget) {
    // ** addr: 0xd4aa3c, size: 0x34
    // 0xd4aa3c: EnterFrame
    //     0xd4aa3c: stp             fp, lr, [SP, #-0x10]!
    //     0xd4aa40: mov             fp, SP
    // 0xd4aa44: CheckStackOverflow
    //     0xd4aa44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4aa48: cmp             SP, x16
    //     0xd4aa4c: b.ls            #0xd4aa68
    // 0xd4aa50: ldr             x1, [fp, #0x18]
    // 0xd4aa54: ldr             x2, [fp, #0x10]
    // 0xd4aa58: r0 = _defaultToolbarBuilder()
    //     0xd4aa58: bl              #0xd4aae0  ; [package:flutter/src/material/text_selection_toolbar.dart] TextSelectionToolbar::_defaultToolbarBuilder
    // 0xd4aa5c: LeaveFrame
    //     0xd4aa5c: mov             SP, fp
    //     0xd4aa60: ldp             fp, lr, [SP], #0x10
    // 0xd4aa64: ret
    //     0xd4aa64: ret             
    // 0xd4aa68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4aa68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4aa6c: b               #0xd4aa50
  }
  static _ _defaultToolbarBuilder(/* No info */) {
    // ** addr: 0xd4aae0, size: 0x28
    // 0xd4aae0: EnterFrame
    //     0xd4aae0: stp             fp, lr, [SP, #-0x10]!
    //     0xd4aae4: mov             fp, SP
    // 0xd4aae8: AllocStack(0x8)
    //     0xd4aae8: sub             SP, SP, #8
    // 0xd4aaec: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0xd4aaec: stur            x2, [fp, #-8]
    // 0xd4aaf0: r0 = _TextSelectionToolbarContainer()
    //     0xd4aaf0: bl              #0xd4ab08  ; Allocate_TextSelectionToolbarContainerStub -> _TextSelectionToolbarContainer (size=0x10)
    // 0xd4aaf4: ldur            x1, [fp, #-8]
    // 0xd4aaf8: StoreField: r0->field_b = r1
    //     0xd4aaf8: stur            w1, [x0, #0xb]
    // 0xd4aafc: LeaveFrame
    //     0xd4aafc: mov             SP, fp
    //     0xd4ab00: ldp             fp, lr, [SP], #0x10
    // 0xd4ab04: ret
    //     0xd4ab04: ret             
  }
  _ build(/* No info */) {
    // ** addr: 0xfbe8c8, size: 0x19c
    // 0xfbe8c8: EnterFrame
    //     0xfbe8c8: stp             fp, lr, [SP, #-0x10]!
    //     0xfbe8cc: mov             fp, SP
    // 0xfbe8d0: AllocStack(0x38)
    //     0xfbe8d0: sub             SP, SP, #0x38
    // 0xfbe8d4: SetupParameters(TextSelectionToolbar this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfbe8d4: mov             x3, x1
    //     0xfbe8d8: mov             x0, x2
    //     0xfbe8dc: stur            x1, [fp, #-8]
    //     0xfbe8e0: stur            x2, [fp, #-0x10]
    // 0xfbe8e4: CheckStackOverflow
    //     0xfbe8e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbe8e8: cmp             SP, x16
    //     0xfbe8ec: b.ls            #0xfbea5c
    // 0xfbe8f0: LoadField: r1 = r3->field_b
    //     0xfbe8f0: ldur            w1, [x3, #0xb]
    // 0xfbe8f4: DecompressPointer r1
    //     0xfbe8f4: add             x1, x1, HEAP, lsl #32
    // 0xfbe8f8: r2 = Instance_Offset
    //     0xfbe8f8: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f5f0] Obj!Offset@12a9ed1
    //     0xfbe8fc: ldr             x2, [x2, #0x5f0]
    // 0xfbe900: r0 = -()
    //     0xfbe900: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xfbe904: mov             x3, x0
    // 0xfbe908: ldur            x0, [fp, #-8]
    // 0xfbe90c: stur            x3, [fp, #-0x18]
    // 0xfbe910: LoadField: r1 = r0->field_f
    //     0xfbe910: ldur            w1, [x0, #0xf]
    // 0xfbe914: DecompressPointer r1
    //     0xfbe914: add             x1, x1, HEAP, lsl #32
    // 0xfbe918: r2 = Instance_Offset
    //     0xfbe918: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f5f8] Obj!Offset@12aa111
    //     0xfbe91c: ldr             x2, [x2, #0x5f8]
    // 0xfbe920: r0 = +()
    //     0xfbe920: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xfbe924: ldur            x1, [fp, #-0x10]
    // 0xfbe928: stur            x0, [fp, #-0x10]
    // 0xfbe92c: r0 = paddingOf()
    //     0xfbe92c: bl              #0xd1a984  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::paddingOf
    // 0xfbe930: LoadField: d0 = r0->field_f
    //     0xfbe930: ldur            d0, [x0, #0xf]
    // 0xfbe934: d1 = 8.000000
    //     0xfbe934: fmov            d1, #8.00000000
    // 0xfbe938: fadd            d2, d0, d1
    // 0xfbe93c: ldur            x1, [fp, #-0x18]
    // 0xfbe940: stur            d2, [fp, #-0x38]
    // 0xfbe944: LoadField: d0 = r1->field_f
    //     0xfbe944: ldur            d0, [x1, #0xf]
    // 0xfbe948: fsub            d3, d0, d1
    // 0xfbe94c: fsub            d0, d3, d2
    // 0xfbe950: d3 = 44.000000
    //     0xfbe950: add             x17, PP, #0x8f, lsl #12  ; [pp+0x8f600] IMM: double(44) from 0x4046000000000000
    //     0xfbe954: ldr             d3, [x17, #0x600]
    // 0xfbe958: fcmp            d0, d3
    // 0xfbe95c: r16 = true
    //     0xfbe95c: add             x16, NULL, #0x20  ; true
    // 0xfbe960: r17 = false
    //     0xfbe960: add             x17, NULL, #0x30  ; false
    // 0xfbe964: csel            x0, x16, x17, ge
    // 0xfbe968: stur            x0, [fp, #-0x20]
    // 0xfbe96c: r0 = Offset()
    //     0xfbe96c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xfbe970: d0 = 8.000000
    //     0xfbe970: fmov            d0, #8.00000000
    // 0xfbe974: stur            x0, [fp, #-0x28]
    // 0xfbe978: StoreField: r0->field_7 = d0
    //     0xfbe978: stur            d0, [x0, #7]
    // 0xfbe97c: ldur            d1, [fp, #-0x38]
    // 0xfbe980: StoreField: r0->field_f = d1
    //     0xfbe980: stur            d1, [x0, #0xf]
    // 0xfbe984: r0 = EdgeInsets()
    //     0xfbe984: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xfbe988: d0 = 8.000000
    //     0xfbe988: fmov            d0, #8.00000000
    // 0xfbe98c: stur            x0, [fp, #-0x30]
    // 0xfbe990: StoreField: r0->field_7 = d0
    //     0xfbe990: stur            d0, [x0, #7]
    // 0xfbe994: ldur            d1, [fp, #-0x38]
    // 0xfbe998: StoreField: r0->field_f = d1
    //     0xfbe998: stur            d1, [x0, #0xf]
    // 0xfbe99c: ArrayStore: r0[0] = d0  ; List_8
    //     0xfbe99c: stur            d0, [x0, #0x17]
    // 0xfbe9a0: StoreField: r0->field_1f = d0
    //     0xfbe9a0: stur            d0, [x0, #0x1f]
    // 0xfbe9a4: ldur            x1, [fp, #-0x18]
    // 0xfbe9a8: ldur            x2, [fp, #-0x28]
    // 0xfbe9ac: r0 = -()
    //     0xfbe9ac: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xfbe9b0: ldur            x1, [fp, #-0x10]
    // 0xfbe9b4: ldur            x2, [fp, #-0x28]
    // 0xfbe9b8: stur            x0, [fp, #-0x10]
    // 0xfbe9bc: r0 = -()
    //     0xfbe9bc: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xfbe9c0: stur            x0, [fp, #-0x18]
    // 0xfbe9c4: r0 = TextSelectionToolbarLayoutDelegate()
    //     0xfbe9c4: bl              #0xfadd1c  ; AllocateTextSelectionToolbarLayoutDelegateStub -> TextSelectionToolbarLayoutDelegate (size=0x18)
    // 0xfbe9c8: mov             x1, x0
    // 0xfbe9cc: ldur            x0, [fp, #-0x10]
    // 0xfbe9d0: stur            x1, [fp, #-0x28]
    // 0xfbe9d4: StoreField: r1->field_b = r0
    //     0xfbe9d4: stur            w0, [x1, #0xb]
    // 0xfbe9d8: ldur            x0, [fp, #-0x18]
    // 0xfbe9dc: StoreField: r1->field_f = r0
    //     0xfbe9dc: stur            w0, [x1, #0xf]
    // 0xfbe9e0: ldur            x0, [fp, #-0x20]
    // 0xfbe9e4: StoreField: r1->field_13 = r0
    //     0xfbe9e4: stur            w0, [x1, #0x13]
    // 0xfbe9e8: ldur            x2, [fp, #-8]
    // 0xfbe9ec: LoadField: r3 = r2->field_13
    //     0xfbe9ec: ldur            w3, [x2, #0x13]
    // 0xfbe9f0: DecompressPointer r3
    //     0xfbe9f0: add             x3, x3, HEAP, lsl #32
    // 0xfbe9f4: stur            x3, [fp, #-0x10]
    // 0xfbe9f8: r0 = _TextSelectionToolbarOverflowable()
    //     0xfbe9f8: bl              #0xfbea64  ; Allocate_TextSelectionToolbarOverflowableStub -> _TextSelectionToolbarOverflowable (size=0x18)
    // 0xfbe9fc: mov             x1, x0
    // 0xfbea00: ldur            x0, [fp, #-0x20]
    // 0xfbea04: stur            x1, [fp, #-8]
    // 0xfbea08: StoreField: r1->field_f = r0
    //     0xfbea08: stur            w0, [x1, #0xf]
    // 0xfbea0c: r0 = Closure: (BuildContext, Widget) => Widget from Function '_defaultToolbarBuilder@132142888': static.
    //     0xfbea0c: add             x0, PP, #0x80, lsl #12  ; [pp+0x809d0] Closure: (BuildContext, Widget) => Widget from Function '_defaultToolbarBuilder@132142888': static. (0x7f2adac31a3c)
    //     0xfbea10: ldr             x0, [x0, #0x9d0]
    // 0xfbea14: StoreField: r1->field_13 = r0
    //     0xfbea14: stur            w0, [x1, #0x13]
    // 0xfbea18: ldur            x0, [fp, #-0x10]
    // 0xfbea1c: StoreField: r1->field_b = r0
    //     0xfbea1c: stur            w0, [x1, #0xb]
    // 0xfbea20: r0 = CustomSingleChildLayout()
    //     0xfbea20: bl              #0xd70b7c  ; AllocateCustomSingleChildLayoutStub -> CustomSingleChildLayout (size=0x14)
    // 0xfbea24: mov             x1, x0
    // 0xfbea28: ldur            x0, [fp, #-0x28]
    // 0xfbea2c: stur            x1, [fp, #-0x10]
    // 0xfbea30: StoreField: r1->field_f = r0
    //     0xfbea30: stur            w0, [x1, #0xf]
    // 0xfbea34: ldur            x0, [fp, #-8]
    // 0xfbea38: StoreField: r1->field_b = r0
    //     0xfbea38: stur            w0, [x1, #0xb]
    // 0xfbea3c: r0 = Padding()
    //     0xfbea3c: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xfbea40: ldur            x1, [fp, #-0x30]
    // 0xfbea44: StoreField: r0->field_f = r1
    //     0xfbea44: stur            w1, [x0, #0xf]
    // 0xfbea48: ldur            x1, [fp, #-0x10]
    // 0xfbea4c: StoreField: r0->field_b = r1
    //     0xfbea4c: stur            w1, [x0, #0xb]
    // 0xfbea50: LeaveFrame
    //     0xfbea50: mov             SP, fp
    //     0xfbea54: ldp             fp, lr, [SP], #0x10
    // 0xfbea58: ret
    //     0xfbea58: ret             
    // 0xfbea5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbea5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbea60: b               #0xfbe8f0
  }
}

// class id: 6413, size: 0x18, field offset: 0xc
//   const constructor, 
class _TextSelectionToolbarOverflowable extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa33a0, size: 0x48
    // 0xfa33a0: EnterFrame
    //     0xfa33a0: stp             fp, lr, [SP, #-0x10]!
    //     0xfa33a4: mov             fp, SP
    // 0xfa33a8: AllocStack(0x8)
    //     0xfa33a8: sub             SP, SP, #8
    // 0xfa33ac: SetupParameters(_TextSelectionToolbarOverflowable this /* r1 => r0 */)
    //     0xfa33ac: mov             x0, x1
    // 0xfa33b0: r1 = <_TextSelectionToolbarOverflowable>
    //     0xfa33b0: add             x1, PP, #0x98, lsl #12  ; [pp+0x98e50] TypeArguments: <_TextSelectionToolbarOverflowable>
    //     0xfa33b4: ldr             x1, [x1, #0xe50]
    // 0xfa33b8: r0 = _TextSelectionToolbarOverflowableState()
    //     0xfa33b8: bl              #0xfa33e8  ; Allocate_TextSelectionToolbarOverflowableStateStub -> _TextSelectionToolbarOverflowableState (size=0x24)
    // 0xfa33bc: mov             x1, x0
    // 0xfa33c0: r0 = false
    //     0xfa33c0: add             x0, NULL, #0x30  ; false
    // 0xfa33c4: stur            x1, [fp, #-8]
    // 0xfa33c8: StoreField: r1->field_1b = r0
    //     0xfa33c8: stur            w0, [x1, #0x1b]
    // 0xfa33cc: r0 = UniqueKey()
    //     0xfa33cc: bl              #0xb8f328  ; AllocateUniqueKeyStub -> UniqueKey (size=0x8)
    // 0xfa33d0: mov             x1, x0
    // 0xfa33d4: ldur            x0, [fp, #-8]
    // 0xfa33d8: StoreField: r0->field_1f = r1
    //     0xfa33d8: stur            w1, [x0, #0x1f]
    // 0xfa33dc: LeaveFrame
    //     0xfa33dc: mov             SP, fp
    //     0xfa33e0: ldp             fp, lr, [SP], #0x10
    // 0xfa33e4: ret
    //     0xfa33e4: ret             
  }
}

// class id: 6650, size: 0x18, field offset: 0x10
//   const constructor, 
class _TextSelectionToolbarTrailingEdgeAlign extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf4cc8, size: 0xa0
    // 0xcf4cc8: EnterFrame
    //     0xcf4cc8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4ccc: mov             fp, SP
    // 0xcf4cd0: AllocStack(0x10)
    //     0xcf4cd0: sub             SP, SP, #0x10
    // 0xcf4cd4: SetupParameters(_TextSelectionToolbarTrailingEdgeAlign this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf4cd4: mov             x4, x1
    //     0xcf4cd8: stur            x1, [fp, #-8]
    //     0xcf4cdc: stur            x3, [fp, #-0x10]
    // 0xcf4ce0: CheckStackOverflow
    //     0xcf4ce0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf4ce4: cmp             SP, x16
    //     0xcf4ce8: b.ls            #0xcf4d60
    // 0xcf4cec: mov             x0, x3
    // 0xcf4cf0: r2 = Null
    //     0xcf4cf0: mov             x2, NULL
    // 0xcf4cf4: r1 = Null
    //     0xcf4cf4: mov             x1, NULL
    // 0xcf4cf8: r4 = 60
    //     0xcf4cf8: mov             x4, #0x3c
    // 0xcf4cfc: branchIfSmi(r0, 0xcf4d08)
    //     0xcf4cfc: tbz             w0, #0, #0xcf4d08
    // 0xcf4d00: r4 = LoadClassIdInstr(r0)
    //     0xcf4d00: ldur            x4, [x0, #-1]
    //     0xcf4d04: ubfx            x4, x4, #0xc, #0x14
    // 0xcf4d08: r17 = 4957
    //     0xcf4d08: mov             x17, #0x135d
    // 0xcf4d0c: cmp             x4, x17
    // 0xcf4d10: b.eq            #0xcf4d28
    // 0xcf4d14: r8 = _TextSelectionToolbarTrailingEdgeAlignRenderBox
    //     0xcf4d14: add             x8, PP, #0xad, lsl #12  ; [pp+0xad6d8] Type: _TextSelectionToolbarTrailingEdgeAlignRenderBox
    //     0xcf4d18: ldr             x8, [x8, #0x6d8]
    // 0xcf4d1c: r3 = Null
    //     0xcf4d1c: add             x3, PP, #0xad, lsl #12  ; [pp+0xad6e0] Null
    //     0xcf4d20: ldr             x3, [x3, #0x6e0]
    // 0xcf4d24: r0 = DefaultTypeTest()
    //     0xcf4d24: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf4d28: ldur            x0, [fp, #-8]
    // 0xcf4d2c: LoadField: r2 = r0->field_f
    //     0xcf4d2c: ldur            w2, [x0, #0xf]
    // 0xcf4d30: DecompressPointer r2
    //     0xcf4d30: add             x2, x2, HEAP, lsl #32
    // 0xcf4d34: ldur            x1, [fp, #-0x10]
    // 0xcf4d38: r0 = overflowOpen=()
    //     0xcf4d38: bl              #0xcf4dd8  ; [package:flutter/src/material/text_selection_toolbar.dart] _TextSelectionToolbarTrailingEdgeAlignRenderBox::overflowOpen=
    // 0xcf4d3c: ldur            x0, [fp, #-8]
    // 0xcf4d40: LoadField: r2 = r0->field_13
    //     0xcf4d40: ldur            w2, [x0, #0x13]
    // 0xcf4d44: DecompressPointer r2
    //     0xcf4d44: add             x2, x2, HEAP, lsl #32
    // 0xcf4d48: ldur            x1, [fp, #-0x10]
    // 0xcf4d4c: r0 = textDirection=()
    //     0xcf4d4c: bl              #0xcf4d68  ; [package:flutter/src/material/text_selection_toolbar.dart] _TextSelectionToolbarTrailingEdgeAlignRenderBox::textDirection=
    // 0xcf4d50: r0 = Null
    //     0xcf4d50: mov             x0, NULL
    // 0xcf4d54: LeaveFrame
    //     0xcf4d54: mov             SP, fp
    //     0xcf4d58: ldp             fp, lr, [SP], #0x10
    // 0xcf4d5c: ret
    //     0xcf4d5c: ret             
    // 0xcf4d60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf4d60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf4d64: b               #0xcf4cec
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11cfc08, size: 0x60
    // 0x11cfc08: EnterFrame
    //     0x11cfc08: stp             fp, lr, [SP, #-0x10]!
    //     0x11cfc0c: mov             fp, SP
    // 0x11cfc10: AllocStack(0x10)
    //     0x11cfc10: sub             SP, SP, #0x10
    // 0x11cfc14: CheckStackOverflow
    //     0x11cfc14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cfc18: cmp             SP, x16
    //     0x11cfc1c: b.ls            #0x11cfc60
    // 0x11cfc20: LoadField: r2 = r1->field_f
    //     0x11cfc20: ldur            w2, [x1, #0xf]
    // 0x11cfc24: DecompressPointer r2
    //     0x11cfc24: add             x2, x2, HEAP, lsl #32
    // 0x11cfc28: stur            x2, [fp, #-0x10]
    // 0x11cfc2c: LoadField: r3 = r1->field_13
    //     0x11cfc2c: ldur            w3, [x1, #0x13]
    // 0x11cfc30: DecompressPointer r3
    //     0x11cfc30: add             x3, x3, HEAP, lsl #32
    // 0x11cfc34: stur            x3, [fp, #-8]
    // 0x11cfc38: r0 = _TextSelectionToolbarTrailingEdgeAlignRenderBox()
    //     0x11cfc38: bl              #0x11cfcf8  ; Allocate_TextSelectionToolbarTrailingEdgeAlignRenderBoxStub -> _TextSelectionToolbarTrailingEdgeAlignRenderBox (size=0x60)
    // 0x11cfc3c: mov             x1, x0
    // 0x11cfc40: ldur            x2, [fp, #-0x10]
    // 0x11cfc44: ldur            x3, [fp, #-8]
    // 0x11cfc48: stur            x0, [fp, #-8]
    // 0x11cfc4c: r0 = _TextSelectionToolbarTrailingEdgeAlignRenderBox()
    //     0x11cfc4c: bl              #0x11cfc68  ; [package:flutter/src/material/text_selection_toolbar.dart] _TextSelectionToolbarTrailingEdgeAlignRenderBox::_TextSelectionToolbarTrailingEdgeAlignRenderBox
    // 0x11cfc50: ldur            x0, [fp, #-8]
    // 0x11cfc54: LeaveFrame
    //     0x11cfc54: mov             SP, fp
    //     0x11cfc58: ldp             fp, lr, [SP], #0x10
    // 0x11cfc5c: ret
    //     0x11cfc5c: ret             
    // 0x11cfc60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cfc60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cfc64: b               #0x11cfc20
  }
}

// class id: 6692, size: 0x1c, field offset: 0x10
//   const constructor, 
class _TextSelectionToolbarItemsLayout extends MultiChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcee9f8, size: 0xb4
    // 0xcee9f8: EnterFrame
    //     0xcee9f8: stp             fp, lr, [SP, #-0x10]!
    //     0xcee9fc: mov             fp, SP
    // 0xceea00: AllocStack(0x10)
    //     0xceea00: sub             SP, SP, #0x10
    // 0xceea04: SetupParameters(_TextSelectionToolbarItemsLayout this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xceea04: mov             x4, x1
    //     0xceea08: stur            x1, [fp, #-8]
    //     0xceea0c: stur            x3, [fp, #-0x10]
    // 0xceea10: CheckStackOverflow
    //     0xceea10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xceea14: cmp             SP, x16
    //     0xceea18: b.ls            #0xceeaa4
    // 0xceea1c: mov             x0, x3
    // 0xceea20: r2 = Null
    //     0xceea20: mov             x2, NULL
    // 0xceea24: r1 = Null
    //     0xceea24: mov             x1, NULL
    // 0xceea28: r4 = 60
    //     0xceea28: mov             x4, #0x3c
    // 0xceea2c: branchIfSmi(r0, 0xceea38)
    //     0xceea2c: tbz             w0, #0, #0xceea38
    // 0xceea30: r4 = LoadClassIdInstr(r0)
    //     0xceea30: ldur            x4, [x0, #-1]
    //     0xceea34: ubfx            x4, x4, #0xc, #0x14
    // 0xceea38: r17 = 4841
    //     0xceea38: mov             x17, #0x12e9
    // 0xceea3c: cmp             x4, x17
    // 0xceea40: b.eq            #0xceea58
    // 0xceea44: r8 = _RenderTextSelectionToolbarItemsLayout
    //     0xceea44: add             x8, PP, #0xad, lsl #12  ; [pp+0xad6c0] Type: _RenderTextSelectionToolbarItemsLayout
    //     0xceea48: ldr             x8, [x8, #0x6c0]
    // 0xceea4c: r3 = Null
    //     0xceea4c: add             x3, PP, #0xad, lsl #12  ; [pp+0xad6c8] Null
    //     0xceea50: ldr             x3, [x3, #0x6c8]
    // 0xceea54: r0 = DefaultTypeTest()
    //     0xceea54: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xceea58: ldur            x0, [fp, #-8]
    // 0xceea5c: LoadField: r2 = r0->field_f
    //     0xceea5c: ldur            w2, [x0, #0xf]
    // 0xceea60: DecompressPointer r2
    //     0xceea60: add             x2, x2, HEAP, lsl #32
    // 0xceea64: ldur            x1, [fp, #-0x10]
    // 0xceea68: r0 = isAbove=()
    //     0xceea68: bl              #0xceeb70  ; [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::isAbove=
    // 0xceea6c: ldur            x0, [fp, #-8]
    // 0xceea70: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xceea70: ldur            w2, [x0, #0x17]
    // 0xceea74: DecompressPointer r2
    //     0xceea74: add             x2, x2, HEAP, lsl #32
    // 0xceea78: ldur            x1, [fp, #-0x10]
    // 0xceea7c: r0 = textDirection=()
    //     0xceea7c: bl              #0xceeb00  ; [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::textDirection=
    // 0xceea80: ldur            x0, [fp, #-8]
    // 0xceea84: LoadField: r2 = r0->field_13
    //     0xceea84: ldur            w2, [x0, #0x13]
    // 0xceea88: DecompressPointer r2
    //     0xceea88: add             x2, x2, HEAP, lsl #32
    // 0xceea8c: ldur            x1, [fp, #-0x10]
    // 0xceea90: r0 = overflowOpen=()
    //     0xceea90: bl              #0xceeaac  ; [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::overflowOpen=
    // 0xceea94: r0 = Null
    //     0xceea94: mov             x0, NULL
    // 0xceea98: LeaveFrame
    //     0xceea98: mov             SP, fp
    //     0xceea9c: ldp             fp, lr, [SP], #0x10
    // 0xceeaa0: ret
    //     0xceeaa0: ret             
    // 0xceeaa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xceeaa4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xceeaa8: b               #0xceea1c
  }
  _ createElement(/* No info */) {
    // ** addr: 0x10f1e80, size: 0x4c
    // 0x10f1e80: EnterFrame
    //     0x10f1e80: stp             fp, lr, [SP, #-0x10]!
    //     0x10f1e84: mov             fp, SP
    // 0x10f1e88: AllocStack(0x8)
    //     0x10f1e88: sub             SP, SP, #8
    // 0x10f1e8c: SetupParameters(_TextSelectionToolbarItemsLayout this /* r1 => r2, fp-0x8 */)
    //     0x10f1e8c: mov             x2, x1
    //     0x10f1e90: stur            x1, [fp, #-8]
    // 0x10f1e94: CheckStackOverflow
    //     0x10f1e94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f1e98: cmp             SP, x16
    //     0x10f1e9c: b.ls            #0x10f1ec4
    // 0x10f1ea0: r0 = _TextSelectionToolbarItemsLayoutElement()
    //     0x10f1ea0: bl              #0x10f201c  ; Allocate_TextSelectionToolbarItemsLayoutElementStub -> _TextSelectionToolbarItemsLayoutElement (size=0x4c)
    // 0x10f1ea4: mov             x1, x0
    // 0x10f1ea8: ldur            x2, [fp, #-8]
    // 0x10f1eac: stur            x0, [fp, #-8]
    // 0x10f1eb0: r0 = MultiChildRenderObjectElement()
    //     0x10f1eb0: bl              #0x10f1ecc  ; [package:flutter/src/widgets/framework.dart] MultiChildRenderObjectElement::MultiChildRenderObjectElement
    // 0x10f1eb4: ldur            x0, [fp, #-8]
    // 0x10f1eb8: LeaveFrame
    //     0x10f1eb8: mov             SP, fp
    //     0x10f1ebc: ldp             fp, lr, [SP], #0x10
    // 0x10f1ec0: ret
    //     0x10f1ec0: ret             
    // 0x10f1ec4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f1ec4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f1ec8: b               #0x10f1ea0
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11ca34c, size: 0x70
    // 0x11ca34c: EnterFrame
    //     0x11ca34c: stp             fp, lr, [SP, #-0x10]!
    //     0x11ca350: mov             fp, SP
    // 0x11ca354: AllocStack(0x18)
    //     0x11ca354: sub             SP, SP, #0x18
    // 0x11ca358: CheckStackOverflow
    //     0x11ca358: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ca35c: cmp             SP, x16
    //     0x11ca360: b.ls            #0x11ca3b4
    // 0x11ca364: LoadField: r2 = r1->field_f
    //     0x11ca364: ldur            w2, [x1, #0xf]
    // 0x11ca368: DecompressPointer r2
    //     0x11ca368: add             x2, x2, HEAP, lsl #32
    // 0x11ca36c: stur            x2, [fp, #-0x18]
    // 0x11ca370: LoadField: r3 = r1->field_13
    //     0x11ca370: ldur            w3, [x1, #0x13]
    // 0x11ca374: DecompressPointer r3
    //     0x11ca374: add             x3, x3, HEAP, lsl #32
    // 0x11ca378: stur            x3, [fp, #-0x10]
    // 0x11ca37c: ArrayLoad: r5 = r1[0]  ; List_4
    //     0x11ca37c: ldur            w5, [x1, #0x17]
    // 0x11ca380: DecompressPointer r5
    //     0x11ca380: add             x5, x5, HEAP, lsl #32
    // 0x11ca384: stur            x5, [fp, #-8]
    // 0x11ca388: r0 = _RenderTextSelectionToolbarItemsLayout()
    //     0x11ca388: bl              #0x11ca454  ; Allocate_RenderTextSelectionToolbarItemsLayoutStub -> _RenderTextSelectionToolbarItemsLayout (size=0x74)
    // 0x11ca38c: mov             x1, x0
    // 0x11ca390: ldur            x2, [fp, #-0x18]
    // 0x11ca394: ldur            x3, [fp, #-0x10]
    // 0x11ca398: ldur            x5, [fp, #-8]
    // 0x11ca39c: stur            x0, [fp, #-8]
    // 0x11ca3a0: r0 = _RenderTextSelectionToolbarItemsLayout()
    //     0x11ca3a0: bl              #0x11ca3bc  ; [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::_RenderTextSelectionToolbarItemsLayout
    // 0x11ca3a4: ldur            x0, [fp, #-8]
    // 0x11ca3a8: LeaveFrame
    //     0x11ca3a8: mov             SP, fp
    //     0x11ca3ac: ldp             fp, lr, [SP], #0x10
    // 0x11ca3b0: ret
    //     0x11ca3b0: ret             
    // 0x11ca3b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ca3b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ca3b8: b               #0x11ca364
  }
}
