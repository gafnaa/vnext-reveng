// lib: , url: package:flutter/src/material/outlined_button_theme.dart

// class id: 1048925, size: 0x8
class :: {
}

// class id: 5133, size: 0xc, field offset: 0x8
//   const constructor, 
class OutlinedButtonThemeData extends _MixinApplication3&Object&Diagnosticable {

  static _ lerp(/* No info */) {
    // ** addr: 0x116644c, size: 0x6c
    // 0x116644c: EnterFrame
    //     0x116644c: stp             fp, lr, [SP, #-0x10]!
    //     0x1166450: mov             fp, SP
    // 0x1166454: AllocStack(0x8)
    //     0x1166454: sub             SP, SP, #8
    // 0x1166458: SetupParameters(dynamic _ /* r1 => r0 */)
    //     0x1166458: mov             x0, x1
    // 0x116645c: CheckStackOverflow
    //     0x116645c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1166460: cmp             SP, x16
    //     0x1166464: b.ls            #0x11664b0
    // 0x1166468: cmp             w0, w2
    // 0x116646c: b.ne            #0x116647c
    // 0x1166470: LeaveFrame
    //     0x1166470: mov             SP, fp
    //     0x1166474: ldp             fp, lr, [SP], #0x10
    // 0x1166478: ret
    //     0x1166478: ret             
    // 0x116647c: LoadField: r1 = r0->field_7
    //     0x116647c: ldur            w1, [x0, #7]
    // 0x1166480: DecompressPointer r1
    //     0x1166480: add             x1, x1, HEAP, lsl #32
    // 0x1166484: LoadField: r0 = r2->field_7
    //     0x1166484: ldur            w0, [x2, #7]
    // 0x1166488: DecompressPointer r0
    //     0x1166488: add             x0, x0, HEAP, lsl #32
    // 0x116648c: mov             x2, x0
    // 0x1166490: r0 = lerp()
    //     0x1166490: bl              #0x1164644  ; [package:flutter/src/material/button_style.dart] ButtonStyle::lerp
    // 0x1166494: stur            x0, [fp, #-8]
    // 0x1166498: r0 = OutlinedButtonThemeData()
    //     0x1166498: bl              #0x11664b8  ; AllocateOutlinedButtonThemeDataStub -> OutlinedButtonThemeData (size=0xc)
    // 0x116649c: ldur            x1, [fp, #-8]
    // 0x11664a0: StoreField: r0->field_7 = r1
    //     0x11664a0: stur            w1, [x0, #7]
    // 0x11664a4: LeaveFrame
    //     0x11664a4: mov             SP, fp
    //     0x11664a8: ldp             fp, lr, [SP], #0x10
    // 0x11664ac: ret
    //     0x11664ac: ret             
    // 0x11664b0: r0 = StackOverflowSharedWithFPURegs()
    //     0x11664b0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11664b4: b               #0x1166468
  }
  _ ==(/* No info */) {
    // ** addr: 0x1270100, size: 0xfc
    // 0x1270100: EnterFrame
    //     0x1270100: stp             fp, lr, [SP, #-0x10]!
    //     0x1270104: mov             fp, SP
    // 0x1270108: AllocStack(0x10)
    //     0x1270108: sub             SP, SP, #0x10
    // 0x127010c: CheckStackOverflow
    //     0x127010c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1270110: cmp             SP, x16
    //     0x1270114: b.ls            #0x12701f4
    // 0x1270118: ldr             x0, [fp, #0x10]
    // 0x127011c: cmp             w0, NULL
    // 0x1270120: b.ne            #0x1270134
    // 0x1270124: r0 = false
    //     0x1270124: add             x0, NULL, #0x30  ; false
    // 0x1270128: LeaveFrame
    //     0x1270128: mov             SP, fp
    //     0x127012c: ldp             fp, lr, [SP], #0x10
    // 0x1270130: ret
    //     0x1270130: ret             
    // 0x1270134: ldr             x1, [fp, #0x18]
    // 0x1270138: cmp             w1, w0
    // 0x127013c: b.ne            #0x1270150
    // 0x1270140: r0 = true
    //     0x1270140: add             x0, NULL, #0x20  ; true
    // 0x1270144: LeaveFrame
    //     0x1270144: mov             SP, fp
    //     0x1270148: ldp             fp, lr, [SP], #0x10
    // 0x127014c: ret
    //     0x127014c: ret             
    // 0x1270150: str             x0, [SP]
    // 0x1270154: r0 = runtimeType()
    //     0x1270154: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1270158: r1 = LoadClassIdInstr(r0)
    //     0x1270158: ldur            x1, [x0, #-1]
    //     0x127015c: ubfx            x1, x1, #0xc, #0x14
    // 0x1270160: r16 = OutlinedButtonThemeData
    //     0x1270160: add             x16, PP, #0x26, lsl #12  ; [pp+0x26308] Type: OutlinedButtonThemeData
    //     0x1270164: ldr             x16, [x16, #0x308]
    // 0x1270168: stp             x16, x0, [SP]
    // 0x127016c: mov             x0, x1
    // 0x1270170: mov             lr, x0
    // 0x1270174: ldr             lr, [x21, lr, lsl #3]
    // 0x1270178: blr             lr
    // 0x127017c: tbz             w0, #4, #0x1270190
    // 0x1270180: r0 = false
    //     0x1270180: add             x0, NULL, #0x30  ; false
    // 0x1270184: LeaveFrame
    //     0x1270184: mov             SP, fp
    //     0x1270188: ldp             fp, lr, [SP], #0x10
    // 0x127018c: ret
    //     0x127018c: ret             
    // 0x1270190: ldr             x0, [fp, #0x10]
    // 0x1270194: r1 = 60
    //     0x1270194: mov             x1, #0x3c
    // 0x1270198: branchIfSmi(r0, 0x12701a4)
    //     0x1270198: tbz             w0, #0, #0x12701a4
    // 0x127019c: r1 = LoadClassIdInstr(r0)
    //     0x127019c: ldur            x1, [x0, #-1]
    //     0x12701a0: ubfx            x1, x1, #0xc, #0x14
    // 0x12701a4: r17 = 5133
    //     0x12701a4: mov             x17, #0x140d
    // 0x12701a8: cmp             x1, x17
    // 0x12701ac: b.ne            #0x12701e4
    // 0x12701b0: ldr             x1, [fp, #0x18]
    // 0x12701b4: LoadField: r2 = r0->field_7
    //     0x12701b4: ldur            w2, [x0, #7]
    // 0x12701b8: DecompressPointer r2
    //     0x12701b8: add             x2, x2, HEAP, lsl #32
    // 0x12701bc: LoadField: r0 = r1->field_7
    //     0x12701bc: ldur            w0, [x1, #7]
    // 0x12701c0: DecompressPointer r0
    //     0x12701c0: add             x0, x0, HEAP, lsl #32
    // 0x12701c4: r1 = LoadClassIdInstr(r2)
    //     0x12701c4: ldur            x1, [x2, #-1]
    //     0x12701c8: ubfx            x1, x1, #0xc, #0x14
    // 0x12701cc: stp             x0, x2, [SP]
    // 0x12701d0: mov             x0, x1
    // 0x12701d4: mov             lr, x0
    // 0x12701d8: ldr             lr, [x21, lr, lsl #3]
    // 0x12701dc: blr             lr
    // 0x12701e0: b               #0x12701e8
    // 0x12701e4: r0 = false
    //     0x12701e4: add             x0, NULL, #0x30  ; false
    // 0x12701e8: LeaveFrame
    //     0x12701e8: mov             SP, fp
    //     0x12701ec: ldp             fp, lr, [SP], #0x10
    // 0x12701f0: ret
    //     0x12701f0: ret             
    // 0x12701f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12701f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12701f8: b               #0x1270118
  }
}

// class id: 6842, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class OutlinedButtonTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xfbd24c, size: 0x5c
    // 0xfbd24c: EnterFrame
    //     0xfbd24c: stp             fp, lr, [SP, #-0x10]!
    //     0xfbd250: mov             fp, SP
    // 0xfbd254: AllocStack(0x18)
    //     0xfbd254: sub             SP, SP, #0x18
    // 0xfbd258: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xfbd258: stur            x1, [fp, #-8]
    // 0xfbd25c: CheckStackOverflow
    //     0xfbd25c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbd260: cmp             SP, x16
    //     0xfbd264: b.ls            #0xfbd2a0
    // 0xfbd268: r16 = <OutlinedButtonTheme>
    //     0xfbd268: add             x16, PP, #0x95, lsl #12  ; [pp+0x95c18] TypeArguments: <OutlinedButtonTheme>
    //     0xfbd26c: ldr             x16, [x16, #0xc18]
    // 0xfbd270: stp             x1, x16, [SP]
    // 0xfbd274: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xfbd274: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xfbd278: r0 = dependOnInheritedWidgetOfExactType()
    //     0xfbd278: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xfbd27c: ldur            x1, [fp, #-8]
    // 0xfbd280: r0 = of()
    //     0xfbd280: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfbd284: r17 = 263
    //     0xfbd284: mov             x17, #0x107
    // 0xfbd288: ldr             w1, [x0, x17]
    // 0xfbd28c: DecompressPointer r1
    //     0xfbd28c: add             x1, x1, HEAP, lsl #32
    // 0xfbd290: mov             x0, x1
    // 0xfbd294: LeaveFrame
    //     0xfbd294: mov             SP, fp
    //     0xfbd298: ldp             fp, lr, [SP], #0x10
    // 0xfbd29c: ret
    //     0xfbd29c: ret             
    // 0xfbd2a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbd2a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbd2a4: b               #0xfbd268
  }
}
