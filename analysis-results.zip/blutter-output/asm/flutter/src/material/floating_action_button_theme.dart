// lib: , url: package:flutter/src/material/floating_action_button_theme.dart

// class id: 1048897, size: 0x8
class :: {
}

// class id: 5148, size: 0x5c, field offset: 0x8
//   const constructor, 
class FloatingActionButtonThemeData extends _MixinApplication3&Object&Diagnosticable {

  Color field_8;
  Color field_c;

  get _ hashCode(/* No info */) {
    // ** addr: 0x11334c0, size: 0x704
    // 0x11334c0: EnterFrame
    //     0x11334c0: stp             fp, lr, [SP, #-0x10]!
    //     0x11334c4: mov             fp, SP
    // 0x11334c8: AllocStack(0x130)
    //     0x11334c8: sub             SP, SP, #0x130
    // 0x11334cc: CheckStackOverflow
    //     0x11334cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11334d0: cmp             SP, x16
    //     0x11334d4: b.ls            #0x1133b80
    // 0x11334d8: ldr             x0, [fp, #0x10]
    // 0x11334dc: r2 = LoadClassIdInstr(r0)
    //     0x11334dc: ldur            x2, [x0, #-1]
    //     0x11334e0: ubfx            x2, x2, #0xc, #0x14
    // 0x11334e4: stur            x2, [fp, #-8]
    // 0x11334e8: r17 = 5148
    //     0x11334e8: mov             x17, #0x141c
    // 0x11334ec: cmp             x2, x17
    // 0x11334f0: b.ne            #0x1133504
    // 0x11334f4: LoadField: r1 = r0->field_7
    //     0x11334f4: ldur            w1, [x0, #7]
    // 0x11334f8: DecompressPointer r1
    //     0x11334f8: add             x1, x1, HEAP, lsl #32
    // 0x11334fc: mov             x3, x1
    // 0x1133500: b               #0x1133580
    // 0x1133504: r17 = 5149
    //     0x1133504: mov             x17, #0x141d
    // 0x1133508: cmp             x2, x17
    // 0x113350c: b.ne            #0x1133568
    // 0x1133510: mov             x1, x0
    // 0x1133514: LoadField: r0 = r1->field_67
    //     0x1133514: ldur            w0, [x1, #0x67]
    // 0x1133518: DecompressPointer r0
    //     0x1133518: add             x0, x0, HEAP, lsl #32
    // 0x113351c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1133520: cmp             w0, w16
    // 0x1133524: b.ne            #0x1133534
    // 0x1133528: r2 = _colors
    //     0x1133528: add             x2, PP, #0x26, lsl #12  ; [pp+0x26358] Field <_FABDefaultsM3@751192485._colors@751192485>: late final (offset: 0x68)
    //     0x113352c: ldr             x2, [x2, #0x358]
    // 0x1133530: r0 = InitLateFinalInstanceField()
    //     0x1133530: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1133534: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1133534: ldur            w1, [x0, #0x17]
    // 0x1133538: DecompressPointer r1
    //     0x1133538: add             x1, x1, HEAP, lsl #32
    // 0x113353c: cmp             w1, NULL
    // 0x1133540: b.ne            #0x1133554
    // 0x1133544: LoadField: r1 = r0->field_f
    //     0x1133544: ldur            w1, [x0, #0xf]
    // 0x1133548: DecompressPointer r1
    //     0x1133548: add             x1, x1, HEAP, lsl #32
    // 0x113354c: mov             x0, x1
    // 0x1133550: b               #0x1133558
    // 0x1133554: mov             x0, x1
    // 0x1133558: mov             x3, x0
    // 0x113355c: ldr             x0, [fp, #0x10]
    // 0x1133560: ldur            x2, [fp, #-8]
    // 0x1133564: b               #0x1133580
    // 0x1133568: LoadField: r1 = r0->field_67
    //     0x1133568: ldur            w1, [x0, #0x67]
    // 0x113356c: DecompressPointer r1
    //     0x113356c: add             x1, x1, HEAP, lsl #32
    // 0x1133570: LoadField: r2 = r1->field_2f
    //     0x1133570: ldur            w2, [x1, #0x2f]
    // 0x1133574: DecompressPointer r2
    //     0x1133574: add             x2, x2, HEAP, lsl #32
    // 0x1133578: mov             x3, x2
    // 0x113357c: ldur            x2, [fp, #-8]
    // 0x1133580: stur            x3, [fp, #-0x10]
    // 0x1133584: r17 = 5148
    //     0x1133584: mov             x17, #0x141c
    // 0x1133588: cmp             x2, x17
    // 0x113358c: b.ne            #0x11335a0
    // 0x1133590: LoadField: r1 = r0->field_b
    //     0x1133590: ldur            w1, [x0, #0xb]
    // 0x1133594: DecompressPointer r1
    //     0x1133594: add             x1, x1, HEAP, lsl #32
    // 0x1133598: mov             x3, x1
    // 0x113359c: b               #0x113361c
    // 0x11335a0: r17 = 5149
    //     0x11335a0: mov             x17, #0x141d
    // 0x11335a4: cmp             x2, x17
    // 0x11335a8: b.ne            #0x1133604
    // 0x11335ac: mov             x1, x0
    // 0x11335b0: LoadField: r0 = r1->field_67
    //     0x11335b0: ldur            w0, [x1, #0x67]
    // 0x11335b4: DecompressPointer r0
    //     0x11335b4: add             x0, x0, HEAP, lsl #32
    // 0x11335b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11335bc: cmp             w0, w16
    // 0x11335c0: b.ne            #0x11335d0
    // 0x11335c4: r2 = _colors
    //     0x11335c4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26358] Field <_FABDefaultsM3@751192485._colors@751192485>: late final (offset: 0x68)
    //     0x11335c8: ldr             x2, [x2, #0x358]
    // 0x11335cc: r0 = InitLateFinalInstanceField()
    //     0x11335cc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11335d0: LoadField: r1 = r0->field_13
    //     0x11335d0: ldur            w1, [x0, #0x13]
    // 0x11335d4: DecompressPointer r1
    //     0x11335d4: add             x1, x1, HEAP, lsl #32
    // 0x11335d8: cmp             w1, NULL
    // 0x11335dc: b.ne            #0x11335f0
    // 0x11335e0: LoadField: r1 = r0->field_b
    //     0x11335e0: ldur            w1, [x0, #0xb]
    // 0x11335e4: DecompressPointer r1
    //     0x11335e4: add             x1, x1, HEAP, lsl #32
    // 0x11335e8: mov             x0, x1
    // 0x11335ec: b               #0x11335f4
    // 0x11335f0: mov             x0, x1
    // 0x11335f4: mov             x3, x0
    // 0x11335f8: ldr             x0, [fp, #0x10]
    // 0x11335fc: ldur            x2, [fp, #-8]
    // 0x1133600: b               #0x113361c
    // 0x1133604: LoadField: r1 = r0->field_67
    //     0x1133604: ldur            w1, [x0, #0x67]
    // 0x1133608: DecompressPointer r1
    //     0x1133608: add             x1, x1, HEAP, lsl #32
    // 0x113360c: LoadField: r2 = r1->field_2b
    //     0x113360c: ldur            w2, [x1, #0x2b]
    // 0x1133610: DecompressPointer r2
    //     0x1133610: add             x2, x2, HEAP, lsl #32
    // 0x1133614: mov             x3, x2
    // 0x1133618: ldur            x2, [fp, #-8]
    // 0x113361c: stur            x3, [fp, #-0x18]
    // 0x1133620: r17 = 5148
    //     0x1133620: mov             x17, #0x141c
    // 0x1133624: cmp             x2, x17
    // 0x1133628: b.ne            #0x113363c
    // 0x113362c: LoadField: r1 = r0->field_f
    //     0x113362c: ldur            w1, [x0, #0xf]
    // 0x1133630: DecompressPointer r1
    //     0x1133630: add             x1, x1, HEAP, lsl #32
    // 0x1133634: mov             x3, x1
    // 0x1133638: b               #0x11336b8
    // 0x113363c: r17 = 5149
    //     0x113363c: mov             x17, #0x141d
    // 0x1133640: cmp             x2, x17
    // 0x1133644: b.ne            #0x11336a0
    // 0x1133648: mov             x1, x0
    // 0x113364c: LoadField: r0 = r1->field_67
    //     0x113364c: ldur            w0, [x1, #0x67]
    // 0x1133650: DecompressPointer r0
    //     0x1133650: add             x0, x0, HEAP, lsl #32
    // 0x1133654: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1133658: cmp             w0, w16
    // 0x113365c: b.ne            #0x113366c
    // 0x1133660: r2 = _colors
    //     0x1133660: add             x2, PP, #0x26, lsl #12  ; [pp+0x26358] Field <_FABDefaultsM3@751192485._colors@751192485>: late final (offset: 0x68)
    //     0x1133664: ldr             x2, [x2, #0x358]
    // 0x1133668: r0 = InitLateFinalInstanceField()
    //     0x1133668: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113366c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x113366c: ldur            w1, [x0, #0x17]
    // 0x1133670: DecompressPointer r1
    //     0x1133670: add             x1, x1, HEAP, lsl #32
    // 0x1133674: cmp             w1, NULL
    // 0x1133678: b.ne            #0x1133684
    // 0x113367c: LoadField: r1 = r0->field_f
    //     0x113367c: ldur            w1, [x0, #0xf]
    // 0x1133680: DecompressPointer r1
    //     0x1133680: add             x1, x1, HEAP, lsl #32
    // 0x1133684: d0 = 0.100000
    //     0x1133684: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x1133688: ldr             d0, [x17, #0x1e0]
    // 0x113368c: r0 = withOpacity()
    //     0x113368c: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1133690: mov             x3, x0
    // 0x1133694: ldr             x0, [fp, #0x10]
    // 0x1133698: ldur            x2, [fp, #-8]
    // 0x113369c: b               #0x11336b8
    // 0x11336a0: LoadField: r1 = r0->field_63
    //     0x11336a0: ldur            w1, [x0, #0x63]
    // 0x11336a4: DecompressPointer r1
    //     0x11336a4: add             x1, x1, HEAP, lsl #32
    // 0x11336a8: LoadField: r2 = r1->field_4b
    //     0x11336a8: ldur            w2, [x1, #0x4b]
    // 0x11336ac: DecompressPointer r2
    //     0x11336ac: add             x2, x2, HEAP, lsl #32
    // 0x11336b0: mov             x3, x2
    // 0x11336b4: ldur            x2, [fp, #-8]
    // 0x11336b8: stur            x3, [fp, #-0x20]
    // 0x11336bc: r17 = 5148
    //     0x11336bc: mov             x17, #0x141c
    // 0x11336c0: cmp             x2, x17
    // 0x11336c4: b.ne            #0x11336d8
    // 0x11336c8: LoadField: r1 = r0->field_13
    //     0x11336c8: ldur            w1, [x0, #0x13]
    // 0x11336cc: DecompressPointer r1
    //     0x11336cc: add             x1, x1, HEAP, lsl #32
    // 0x11336d0: mov             x3, x1
    // 0x11336d4: b               #0x1133754
    // 0x11336d8: r17 = 5149
    //     0x11336d8: mov             x17, #0x141d
    // 0x11336dc: cmp             x2, x17
    // 0x11336e0: b.ne            #0x113373c
    // 0x11336e4: mov             x1, x0
    // 0x11336e8: LoadField: r0 = r1->field_67
    //     0x11336e8: ldur            w0, [x1, #0x67]
    // 0x11336ec: DecompressPointer r0
    //     0x11336ec: add             x0, x0, HEAP, lsl #32
    // 0x11336f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11336f4: cmp             w0, w16
    // 0x11336f8: b.ne            #0x1133708
    // 0x11336fc: r2 = _colors
    //     0x11336fc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26358] Field <_FABDefaultsM3@751192485._colors@751192485>: late final (offset: 0x68)
    //     0x1133700: ldr             x2, [x2, #0x358]
    // 0x1133704: r0 = InitLateFinalInstanceField()
    //     0x1133704: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1133708: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1133708: ldur            w1, [x0, #0x17]
    // 0x113370c: DecompressPointer r1
    //     0x113370c: add             x1, x1, HEAP, lsl #32
    // 0x1133710: cmp             w1, NULL
    // 0x1133714: b.ne            #0x1133720
    // 0x1133718: LoadField: r1 = r0->field_f
    //     0x1133718: ldur            w1, [x0, #0xf]
    // 0x113371c: DecompressPointer r1
    //     0x113371c: add             x1, x1, HEAP, lsl #32
    // 0x1133720: d0 = 0.080000
    //     0x1133720: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x1133724: ldr             d0, [x17, #0xa58]
    // 0x1133728: r0 = withOpacity()
    //     0x1133728: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x113372c: mov             x3, x0
    // 0x1133730: ldr             x0, [fp, #0x10]
    // 0x1133734: ldur            x2, [fp, #-8]
    // 0x1133738: b               #0x1133754
    // 0x113373c: LoadField: r1 = r0->field_63
    //     0x113373c: ldur            w1, [x0, #0x63]
    // 0x1133740: DecompressPointer r1
    //     0x1133740: add             x1, x1, HEAP, lsl #32
    // 0x1133744: LoadField: r2 = r1->field_57
    //     0x1133744: ldur            w2, [x1, #0x57]
    // 0x1133748: DecompressPointer r2
    //     0x1133748: add             x2, x2, HEAP, lsl #32
    // 0x113374c: mov             x3, x2
    // 0x1133750: ldur            x2, [fp, #-8]
    // 0x1133754: stur            x3, [fp, #-0x28]
    // 0x1133758: r17 = 5148
    //     0x1133758: mov             x17, #0x141c
    // 0x113375c: cmp             x2, x17
    // 0x1133760: b.ne            #0x1133788
    // 0x1133764: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1133764: ldur            w1, [x0, #0x17]
    // 0x1133768: DecompressPointer r1
    //     0x1133768: add             x1, x1, HEAP, lsl #32
    // 0x113376c: mov             x16, x0
    // 0x1133770: mov             x0, x1
    // 0x1133774: mov             x1, x16
    // 0x1133778: mov             x16, x2
    // 0x113377c: mov             x2, x0
    // 0x1133780: mov             x0, x16
    // 0x1133784: b               #0x1133804
    // 0x1133788: r17 = 5149
    //     0x1133788: mov             x17, #0x141d
    // 0x113378c: cmp             x2, x17
    // 0x1133790: b.ne            #0x11337ec
    // 0x1133794: mov             x1, x0
    // 0x1133798: LoadField: r0 = r1->field_67
    //     0x1133798: ldur            w0, [x1, #0x67]
    // 0x113379c: DecompressPointer r0
    //     0x113379c: add             x0, x0, HEAP, lsl #32
    // 0x11337a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11337a4: cmp             w0, w16
    // 0x11337a8: b.ne            #0x11337b8
    // 0x11337ac: r2 = _colors
    //     0x11337ac: add             x2, PP, #0x26, lsl #12  ; [pp+0x26358] Field <_FABDefaultsM3@751192485._colors@751192485>: late final (offset: 0x68)
    //     0x11337b0: ldr             x2, [x2, #0x358]
    // 0x11337b4: r0 = InitLateFinalInstanceField()
    //     0x11337b4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11337b8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11337b8: ldur            w1, [x0, #0x17]
    // 0x11337bc: DecompressPointer r1
    //     0x11337bc: add             x1, x1, HEAP, lsl #32
    // 0x11337c0: cmp             w1, NULL
    // 0x11337c4: b.ne            #0x11337d0
    // 0x11337c8: LoadField: r1 = r0->field_f
    //     0x11337c8: ldur            w1, [x0, #0xf]
    // 0x11337cc: DecompressPointer r1
    //     0x11337cc: add             x1, x1, HEAP, lsl #32
    // 0x11337d0: d0 = 0.100000
    //     0x11337d0: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x11337d4: ldr             d0, [x17, #0x1e0]
    // 0x11337d8: r0 = withOpacity()
    //     0x11337d8: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x11337dc: mov             x2, x0
    // 0x11337e0: ldr             x1, [fp, #0x10]
    // 0x11337e4: ldur            x0, [fp, #-8]
    // 0x11337e8: b               #0x1133804
    // 0x11337ec: mov             x1, x0
    // 0x11337f0: LoadField: r0 = r1->field_63
    //     0x11337f0: ldur            w0, [x1, #0x63]
    // 0x11337f4: DecompressPointer r0
    //     0x11337f4: add             x0, x0, HEAP, lsl #32
    // 0x11337f8: LoadField: r2 = r0->field_73
    //     0x11337f8: ldur            w2, [x0, #0x73]
    // 0x11337fc: DecompressPointer r2
    //     0x11337fc: add             x2, x2, HEAP, lsl #32
    // 0x1133800: ldur            x0, [fp, #-8]
    // 0x1133804: stur            x2, [fp, #-0x98]
    // 0x1133808: LoadField: r3 = r1->field_1b
    //     0x1133808: ldur            w3, [x1, #0x1b]
    // 0x113380c: DecompressPointer r3
    //     0x113380c: add             x3, x3, HEAP, lsl #32
    // 0x1133810: stur            x3, [fp, #-0x90]
    // 0x1133814: LoadField: r4 = r1->field_1f
    //     0x1133814: ldur            w4, [x1, #0x1f]
    // 0x1133818: DecompressPointer r4
    //     0x1133818: add             x4, x4, HEAP, lsl #32
    // 0x113381c: stur            x4, [fp, #-0x88]
    // 0x1133820: LoadField: r5 = r1->field_23
    //     0x1133820: ldur            w5, [x1, #0x23]
    // 0x1133824: DecompressPointer r5
    //     0x1133824: add             x5, x5, HEAP, lsl #32
    // 0x1133828: stur            x5, [fp, #-0x80]
    // 0x113382c: LoadField: r6 = r1->field_27
    //     0x113382c: ldur            w6, [x1, #0x27]
    // 0x1133830: DecompressPointer r6
    //     0x1133830: add             x6, x6, HEAP, lsl #32
    // 0x1133834: stur            x6, [fp, #-0x78]
    // 0x1133838: LoadField: r7 = r1->field_2b
    //     0x1133838: ldur            w7, [x1, #0x2b]
    // 0x113383c: DecompressPointer r7
    //     0x113383c: add             x7, x7, HEAP, lsl #32
    // 0x1133840: stur            x7, [fp, #-0x70]
    // 0x1133844: r17 = 5148
    //     0x1133844: mov             x17, #0x141c
    // 0x1133848: cmp             x0, x17
    // 0x113384c: b.ne            #0x113385c
    // 0x1133850: LoadField: r8 = r1->field_2f
    //     0x1133850: ldur            w8, [x1, #0x2f]
    // 0x1133854: DecompressPointer r8
    //     0x1133854: add             x8, x8, HEAP, lsl #32
    // 0x1133858: b               #0x11338c4
    // 0x113385c: r17 = 5149
    //     0x113385c: mov             x17, #0x141d
    // 0x1133860: cmp             x0, x17
    // 0x1133864: b.ne            #0x11338bc
    // 0x1133868: LoadField: r8 = r1->field_5f
    //     0x1133868: ldur            w8, [x1, #0x5f]
    // 0x113386c: DecompressPointer r8
    //     0x113386c: add             x8, x8, HEAP, lsl #32
    // 0x1133870: LoadField: r9 = r8->field_7
    //     0x1133870: ldur            x9, [x8, #7]
    // 0x1133874: cmp             x9, #1
    // 0x1133878: b.gt            #0x113389c
    // 0x113387c: cmp             x9, #0
    // 0x1133880: b.gt            #0x1133890
    // 0x1133884: r8 = Instance_RoundedRectangleBorder
    //     0x1133884: add             x8, PP, #0x26, lsl #12  ; [pp+0x26360] Obj!RoundedRectangleBorder@129ec91
    //     0x1133888: ldr             x8, [x8, #0x360]
    // 0x113388c: b               #0x11338c4
    // 0x1133890: r8 = Instance_RoundedRectangleBorder
    //     0x1133890: add             x8, PP, #0x26, lsl #12  ; [pp+0x26368] Obj!RoundedRectangleBorder@129ec81
    //     0x1133894: ldr             x8, [x8, #0x368]
    // 0x1133898: b               #0x11338c4
    // 0x113389c: cmp             x9, #2
    // 0x11338a0: b.gt            #0x11338b0
    // 0x11338a4: r8 = Instance_RoundedRectangleBorder
    //     0x11338a4: add             x8, PP, #0x26, lsl #12  ; [pp+0x26370] Obj!RoundedRectangleBorder@129ec41
    //     0x11338a8: ldr             x8, [x8, #0x370]
    // 0x11338ac: b               #0x11338c4
    // 0x11338b0: r8 = Instance_RoundedRectangleBorder
    //     0x11338b0: add             x8, PP, #0x26, lsl #12  ; [pp+0x26360] Obj!RoundedRectangleBorder@129ec91
    //     0x11338b4: ldr             x8, [x8, #0x360]
    // 0x11338b8: b               #0x11338c4
    // 0x11338bc: r8 = Instance_CircleBorder
    //     0x11338bc: add             x8, PP, #0x1c, lsl #12  ; [pp+0x1c318] Obj!CircleBorder@129ebf1
    //     0x11338c0: ldr             x8, [x8, #0x318]
    // 0x11338c4: stur            x8, [fp, #-0x68]
    // 0x11338c8: LoadField: r9 = r1->field_33
    //     0x11338c8: ldur            w9, [x1, #0x33]
    // 0x11338cc: DecompressPointer r9
    //     0x11338cc: add             x9, x9, HEAP, lsl #32
    // 0x11338d0: stur            x9, [fp, #-0x60]
    // 0x11338d4: r17 = 5148
    //     0x11338d4: mov             x17, #0x141c
    // 0x11338d8: cmp             x0, x17
    // 0x11338dc: b.ne            #0x11338ec
    // 0x11338e0: LoadField: r10 = r1->field_37
    //     0x11338e0: ldur            w10, [x1, #0x37]
    // 0x11338e4: DecompressPointer r10
    //     0x11338e4: add             x10, x10, HEAP, lsl #32
    // 0x11338e8: b               #0x1133974
    // 0x11338ec: r17 = 5149
    //     0x11338ec: mov             x17, #0x141d
    // 0x11338f0: cmp             x0, x17
    // 0x11338f4: b.ne            #0x113396c
    // 0x11338f8: LoadField: r10 = r1->field_5f
    //     0x11338f8: ldur            w10, [x1, #0x5f]
    // 0x11338fc: DecompressPointer r10
    //     0x11338fc: add             x10, x10, HEAP, lsl #32
    // 0x1133900: LoadField: r11 = r10->field_7
    //     0x1133900: ldur            x11, [x10, #7]
    // 0x1133904: cmp             x11, #1
    // 0x1133908: b.gt            #0x1133924
    // 0x113390c: cmp             x11, #0
    // 0x1133910: b.gt            #0x113391c
    // 0x1133914: d0 = 24.000000
    //     0x1133914: fmov            d0, #24.00000000
    // 0x1133918: b               #0x113393c
    // 0x113391c: d0 = 24.000000
    //     0x113391c: fmov            d0, #24.00000000
    // 0x1133920: b               #0x113393c
    // 0x1133924: cmp             x11, #2
    // 0x1133928: b.gt            #0x1133938
    // 0x113392c: d0 = 36.000000
    //     0x113392c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12ca0] IMM: double(36) from 0x4042000000000000
    //     0x1133930: ldr             d0, [x17, #0xca0]
    // 0x1133934: b               #0x113393c
    // 0x1133938: d0 = 24.000000
    //     0x1133938: fmov            d0, #24.00000000
    // 0x113393c: r10 = inline_Allocate_Double()
    //     0x113393c: ldp             x10, x11, [THR, #0x60]  ; THR::top
    //     0x1133940: add             x10, x10, #0x10
    //     0x1133944: cmp             x11, x10
    //     0x1133948: b.ls            #0x1133b88
    //     0x113394c: str             x10, [THR, #0x60]  ; THR::top
    //     0x1133950: sub             x10, x10, #0xf
    //     0x1133954: mov             x11, #0xe19c
    //     0x1133958: movk            x11, #3, lsl #16
    //     0x113395c: stur            x11, [x10, #-1]
    // 0x1133960: dmb             ishst
    // 0x1133964: StoreField: r10->field_7 = d0
    //     0x1133964: stur            d0, [x10, #7]
    // 0x1133968: b               #0x1133974
    // 0x113396c: r10 = 24.000000
    //     0x113396c: add             x10, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0x1133970: ldr             x10, [x10, #0x4d0]
    // 0x1133974: stur            x10, [fp, #-0x58]
    // 0x1133978: LoadField: r11 = r1->field_3b
    //     0x1133978: ldur            w11, [x1, #0x3b]
    // 0x113397c: DecompressPointer r11
    //     0x113397c: add             x11, x11, HEAP, lsl #32
    // 0x1133980: stur            x11, [fp, #-0x50]
    // 0x1133984: LoadField: r12 = r1->field_3f
    //     0x1133984: ldur            w12, [x1, #0x3f]
    // 0x1133988: DecompressPointer r12
    //     0x1133988: add             x12, x12, HEAP, lsl #32
    // 0x113398c: stur            x12, [fp, #-0x48]
    // 0x1133990: LoadField: r13 = r1->field_43
    //     0x1133990: ldur            w13, [x1, #0x43]
    // 0x1133994: DecompressPointer r13
    //     0x1133994: add             x13, x13, HEAP, lsl #32
    // 0x1133998: stur            x13, [fp, #-0x40]
    // 0x113399c: LoadField: r14 = r1->field_47
    //     0x113399c: ldur            w14, [x1, #0x47]
    // 0x11339a0: DecompressPointer r14
    //     0x11339a0: add             x14, x14, HEAP, lsl #32
    // 0x11339a4: stur            x14, [fp, #-0x38]
    // 0x11339a8: LoadField: r19 = r1->field_4b
    //     0x11339a8: ldur            w19, [x1, #0x4b]
    // 0x11339ac: DecompressPointer r19
    //     0x11339ac: add             x19, x19, HEAP, lsl #32
    // 0x11339b0: stur            x19, [fp, #-0x30]
    // 0x11339b4: r17 = 5148
    //     0x11339b4: mov             x17, #0x141c
    // 0x11339b8: cmp             x0, x17
    // 0x11339bc: b.ne            #0x11339d0
    // 0x11339c0: LoadField: r20 = r1->field_4f
    //     0x11339c0: ldur            w20, [x1, #0x4f]
    // 0x11339c4: DecompressPointer r20
    //     0x11339c4: add             x20, x20, HEAP, lsl #32
    // 0x11339c8: mov             x2, x20
    // 0x11339cc: b               #0x1133a24
    // 0x11339d0: r17 = 5149
    //     0x11339d0: mov             x17, #0x141d
    // 0x11339d4: cmp             x0, x17
    // 0x11339d8: b.ne            #0x1133a00
    // 0x11339dc: r0 = EdgeInsetsDirectional()
    //     0x11339dc: bl              #0xb50060  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0x11339e0: d0 = 20.000000
    //     0x11339e0: fmov            d0, #20.00000000
    // 0x11339e4: StoreField: r0->field_7 = d0
    //     0x11339e4: stur            d0, [x0, #7]
    // 0x11339e8: StoreField: r0->field_f = rZR
    //     0x11339e8: stur            xzr, [x0, #0xf]
    // 0x11339ec: ArrayStore: r0[0] = d0  ; List_8
    //     0x11339ec: stur            d0, [x0, #0x17]
    // 0x11339f0: StoreField: r0->field_1f = rZR
    //     0x11339f0: stur            xzr, [x0, #0x1f]
    // 0x11339f4: mov             x2, x0
    // 0x11339f8: ldur            x0, [fp, #-8]
    // 0x11339fc: b               #0x1133a24
    // 0x1133a00: d0 = 20.000000
    //     0x1133a00: fmov            d0, #20.00000000
    // 0x1133a04: r0 = EdgeInsetsDirectional()
    //     0x1133a04: bl              #0xb50060  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0x1133a08: d0 = 20.000000
    //     0x1133a08: fmov            d0, #20.00000000
    // 0x1133a0c: StoreField: r0->field_7 = d0
    //     0x1133a0c: stur            d0, [x0, #7]
    // 0x1133a10: StoreField: r0->field_f = rZR
    //     0x1133a10: stur            xzr, [x0, #0xf]
    // 0x1133a14: ArrayStore: r0[0] = d0  ; List_8
    //     0x1133a14: stur            d0, [x0, #0x17]
    // 0x1133a18: StoreField: r0->field_1f = rZR
    //     0x1133a18: stur            xzr, [x0, #0x1f]
    // 0x1133a1c: mov             x2, x0
    // 0x1133a20: ldur            x0, [fp, #-8]
    // 0x1133a24: stur            x2, [fp, #-0xa0]
    // 0x1133a28: r17 = 5148
    //     0x1133a28: mov             x17, #0x141c
    // 0x1133a2c: cmp             x0, x17
    // 0x1133a30: b.ne            #0x1133a48
    // 0x1133a34: ldr             x1, [fp, #0x10]
    // 0x1133a38: LoadField: r0 = r1->field_53
    //     0x1133a38: ldur            w0, [x1, #0x53]
    // 0x1133a3c: DecompressPointer r0
    //     0x1133a3c: add             x0, x0, HEAP, lsl #32
    // 0x1133a40: mov             x1, x0
    // 0x1133a44: b               #0x1133abc
    // 0x1133a48: ldr             x1, [fp, #0x10]
    // 0x1133a4c: r17 = 5149
    //     0x1133a4c: mov             x17, #0x141d
    // 0x1133a50: cmp             x0, x17
    // 0x1133a54: b.ne            #0x1133a84
    // 0x1133a58: LoadField: r0 = r1->field_6b
    //     0x1133a58: ldur            w0, [x1, #0x6b]
    // 0x1133a5c: DecompressPointer r0
    //     0x1133a5c: add             x0, x0, HEAP, lsl #32
    // 0x1133a60: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1133a64: cmp             w0, w16
    // 0x1133a68: b.ne            #0x1133a78
    // 0x1133a6c: r2 = _textTheme
    //     0x1133a6c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26378] Field <_FABDefaultsM3@751192485._textTheme@751192485>: late final (offset: 0x6c)
    //     0x1133a70: ldr             x2, [x2, #0x378]
    // 0x1133a74: r0 = InitLateFinalInstanceField()
    //     0x1133a74: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1133a78: LoadField: r1 = r0->field_37
    //     0x1133a78: ldur            w1, [x0, #0x37]
    // 0x1133a7c: DecompressPointer r1
    //     0x1133a7c: add             x1, x1, HEAP, lsl #32
    // 0x1133a80: b               #0x1133abc
    // 0x1133a84: LoadField: r0 = r1->field_63
    //     0x1133a84: ldur            w0, [x1, #0x63]
    // 0x1133a88: DecompressPointer r0
    //     0x1133a88: add             x0, x0, HEAP, lsl #32
    // 0x1133a8c: LoadField: r1 = r0->field_87
    //     0x1133a8c: ldur            w1, [x0, #0x87]
    // 0x1133a90: DecompressPointer r1
    //     0x1133a90: add             x1, x1, HEAP, lsl #32
    // 0x1133a94: LoadField: r0 = r1->field_37
    //     0x1133a94: ldur            w0, [x1, #0x37]
    // 0x1133a98: DecompressPointer r0
    //     0x1133a98: add             x0, x0, HEAP, lsl #32
    // 0x1133a9c: r16 = 1.200000
    //     0x1133a9c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1ac08] 1.2
    //     0x1133aa0: ldr             x16, [x16, #0xc08]
    // 0x1133aa4: str             x16, [SP]
    // 0x1133aa8: mov             x1, x0
    // 0x1133aac: r4 = const [0, 0x2, 0x1, 0x1, letterSpacing, 0x1, null]
    //     0x1133aac: add             x4, PP, #0x26, lsl #12  ; [pp+0x26380] List(7) [0, 0x2, 0x1, 0x1, "letterSpacing", 0x1, Null]
    //     0x1133ab0: ldr             x4, [x4, #0x380]
    // 0x1133ab4: r0 = copyWith()
    //     0x1133ab4: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x1133ab8: mov             x1, x0
    // 0x1133abc: r2 = Null
    //     0x1133abc: mov             x2, NULL
    // 0x1133ac0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x1133ac0: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x1133ac4: r0 = hash()
    //     0x1133ac4: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1133ac8: mov             x2, x0
    // 0x1133acc: r0 = BoxInt64Instr(r2)
    //     0x1133acc: sbfiz           x0, x2, #1, #0x1f
    //     0x1133ad0: cmp             x2, x0, asr #1
    //     0x1133ad4: b.eq            #0x1133ae0
    //     0x1133ad8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1133adc: stur            x2, [x0, #7]
    // 0x1133ae0: ldur            x16, [fp, #-0x20]
    // 0x1133ae4: ldur            lr, [fp, #-0x28]
    // 0x1133ae8: stp             lr, x16, [SP, #0x80]
    // 0x1133aec: ldur            x16, [fp, #-0x98]
    // 0x1133af0: ldur            lr, [fp, #-0x90]
    // 0x1133af4: stp             lr, x16, [SP, #0x70]
    // 0x1133af8: ldur            x16, [fp, #-0x88]
    // 0x1133afc: ldur            lr, [fp, #-0x80]
    // 0x1133b00: stp             lr, x16, [SP, #0x60]
    // 0x1133b04: ldur            x16, [fp, #-0x78]
    // 0x1133b08: ldur            lr, [fp, #-0x70]
    // 0x1133b0c: stp             lr, x16, [SP, #0x50]
    // 0x1133b10: ldur            x16, [fp, #-0x68]
    // 0x1133b14: ldur            lr, [fp, #-0x60]
    // 0x1133b18: stp             lr, x16, [SP, #0x40]
    // 0x1133b1c: ldur            x16, [fp, #-0x58]
    // 0x1133b20: ldur            lr, [fp, #-0x50]
    // 0x1133b24: stp             lr, x16, [SP, #0x30]
    // 0x1133b28: ldur            x16, [fp, #-0x48]
    // 0x1133b2c: ldur            lr, [fp, #-0x40]
    // 0x1133b30: stp             lr, x16, [SP, #0x20]
    // 0x1133b34: ldur            x16, [fp, #-0x38]
    // 0x1133b38: ldur            lr, [fp, #-0x30]
    // 0x1133b3c: stp             lr, x16, [SP, #0x10]
    // 0x1133b40: ldur            x16, [fp, #-0xa0]
    // 0x1133b44: stp             x0, x16, [SP]
    // 0x1133b48: ldur            x1, [fp, #-0x10]
    // 0x1133b4c: ldur            x2, [fp, #-0x18]
    // 0x1133b50: r4 = const [0, 0x14, 0x12, 0x14, null]
    //     0x1133b50: add             x4, PP, #0xd, lsl #12  ; [pp+0xdf20] List(5) [0, 0x14, 0x12, 0x14, Null]
    //     0x1133b54: ldr             x4, [x4, #0xf20]
    // 0x1133b58: r0 = hash()
    //     0x1133b58: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1133b5c: mov             x2, x0
    // 0x1133b60: r0 = BoxInt64Instr(r2)
    //     0x1133b60: sbfiz           x0, x2, #1, #0x1f
    //     0x1133b64: cmp             x2, x0, asr #1
    //     0x1133b68: b.eq            #0x1133b74
    //     0x1133b6c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1133b70: stur            x2, [x0, #7]
    // 0x1133b74: LeaveFrame
    //     0x1133b74: mov             SP, fp
    //     0x1133b78: ldp             fp, lr, [SP], #0x10
    // 0x1133b7c: ret
    //     0x1133b7c: ret             
    // 0x1133b80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1133b80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1133b84: b               #0x11334d8
    // 0x1133b88: SaveReg d0
    //     0x1133b88: str             q0, [SP, #-0x10]!
    // 0x1133b8c: stp             x8, x9, [SP, #-0x10]!
    // 0x1133b90: stp             x6, x7, [SP, #-0x10]!
    // 0x1133b94: stp             x4, x5, [SP, #-0x10]!
    // 0x1133b98: stp             x2, x3, [SP, #-0x10]!
    // 0x1133b9c: stp             x0, x1, [SP, #-0x10]!
    // 0x1133ba0: r0 = AllocateDouble()
    //     0x1133ba0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1133ba4: mov             x10, x0
    // 0x1133ba8: ldp             x0, x1, [SP], #0x10
    // 0x1133bac: ldp             x2, x3, [SP], #0x10
    // 0x1133bb0: ldp             x4, x5, [SP], #0x10
    // 0x1133bb4: ldp             x6, x7, [SP], #0x10
    // 0x1133bb8: ldp             x8, x9, [SP], #0x10
    // 0x1133bbc: RestoreReg d0
    //     0x1133bbc: ldr             q0, [SP], #0x10
    // 0x1133bc0: b               #0x1133964
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1166e58, size: 0x3c8
    // 0x1166e58: EnterFrame
    //     0x1166e58: stp             fp, lr, [SP, #-0x10]!
    //     0x1166e5c: mov             fp, SP
    // 0x1166e60: AllocStack(0x88)
    //     0x1166e60: sub             SP, SP, #0x88
    // 0x1166e64: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x88 */)
    //     0x1166e64: mov             x4, x1
    //     0x1166e68: mov             x0, x2
    //     0x1166e6c: stur            x1, [fp, #-0x10]
    //     0x1166e70: stur            x2, [fp, #-0x18]
    //     0x1166e74: stur            d0, [fp, #-0x88]
    // 0x1166e78: CheckStackOverflow
    //     0x1166e78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1166e7c: cmp             SP, x16
    //     0x1166e80: b.ls            #0x11671f4
    // 0x1166e84: cmp             w4, w0
    // 0x1166e88: b.ne            #0x1166e9c
    // 0x1166e8c: mov             x0, x4
    // 0x1166e90: LeaveFrame
    //     0x1166e90: mov             SP, fp
    //     0x1166e94: ldp             fp, lr, [SP], #0x10
    // 0x1166e98: ret
    //     0x1166e98: ret             
    // 0x1166e9c: LoadField: r1 = r4->field_7
    //     0x1166e9c: ldur            w1, [x4, #7]
    // 0x1166ea0: DecompressPointer r1
    //     0x1166ea0: add             x1, x1, HEAP, lsl #32
    // 0x1166ea4: LoadField: r2 = r0->field_7
    //     0x1166ea4: ldur            w2, [x0, #7]
    // 0x1166ea8: DecompressPointer r2
    //     0x1166ea8: add             x2, x2, HEAP, lsl #32
    // 0x1166eac: r5 = inline_Allocate_Double()
    //     0x1166eac: ldp             x5, x3, [THR, #0x60]  ; THR::top
    //     0x1166eb0: add             x5, x5, #0x10
    //     0x1166eb4: cmp             x3, x5
    //     0x1166eb8: b.ls            #0x11671fc
    //     0x1166ebc: str             x5, [THR, #0x60]  ; THR::top
    //     0x1166ec0: sub             x5, x5, #0xf
    //     0x1166ec4: mov             x3, #0xe19c
    //     0x1166ec8: movk            x3, #3, lsl #16
    //     0x1166ecc: stur            x3, [x5, #-1]
    // 0x1166ed0: dmb             ishst
    // 0x1166ed4: StoreField: r5->field_7 = d0
    //     0x1166ed4: stur            d0, [x5, #7]
    // 0x1166ed8: mov             x3, x5
    // 0x1166edc: stur            x5, [fp, #-8]
    // 0x1166ee0: r0 = lerp()
    //     0x1166ee0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1166ee4: mov             x4, x0
    // 0x1166ee8: ldur            x0, [fp, #-0x10]
    // 0x1166eec: stur            x4, [fp, #-0x20]
    // 0x1166ef0: LoadField: r1 = r0->field_b
    //     0x1166ef0: ldur            w1, [x0, #0xb]
    // 0x1166ef4: DecompressPointer r1
    //     0x1166ef4: add             x1, x1, HEAP, lsl #32
    // 0x1166ef8: ldur            x5, [fp, #-0x18]
    // 0x1166efc: LoadField: r2 = r5->field_b
    //     0x1166efc: ldur            w2, [x5, #0xb]
    // 0x1166f00: DecompressPointer r2
    //     0x1166f00: add             x2, x2, HEAP, lsl #32
    // 0x1166f04: ldur            x3, [fp, #-8]
    // 0x1166f08: r0 = lerp()
    //     0x1166f08: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1166f0c: ldur            x3, [fp, #-8]
    // 0x1166f10: r1 = Null
    //     0x1166f10: mov             x1, NULL
    // 0x1166f14: r2 = Null
    //     0x1166f14: mov             x2, NULL
    // 0x1166f18: stur            x0, [fp, #-0x28]
    // 0x1166f1c: r0 = lerp()
    //     0x1166f1c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1166f20: ldur            x3, [fp, #-8]
    // 0x1166f24: r1 = Null
    //     0x1166f24: mov             x1, NULL
    // 0x1166f28: r2 = Null
    //     0x1166f28: mov             x2, NULL
    // 0x1166f2c: r0 = lerp()
    //     0x1166f2c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1166f30: ldur            x3, [fp, #-8]
    // 0x1166f34: r1 = Null
    //     0x1166f34: mov             x1, NULL
    // 0x1166f38: r2 = Null
    //     0x1166f38: mov             x2, NULL
    // 0x1166f3c: r0 = lerp()
    //     0x1166f3c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1166f40: ldur            x0, [fp, #-0x10]
    // 0x1166f44: LoadField: r1 = r0->field_1b
    //     0x1166f44: ldur            w1, [x0, #0x1b]
    // 0x1166f48: DecompressPointer r1
    //     0x1166f48: add             x1, x1, HEAP, lsl #32
    // 0x1166f4c: ldur            x4, [fp, #-0x18]
    // 0x1166f50: LoadField: r2 = r4->field_1b
    //     0x1166f50: ldur            w2, [x4, #0x1b]
    // 0x1166f54: DecompressPointer r2
    //     0x1166f54: add             x2, x2, HEAP, lsl #32
    // 0x1166f58: ldur            x3, [fp, #-8]
    // 0x1166f5c: r0 = lerpDouble()
    //     0x1166f5c: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1166f60: mov             x4, x0
    // 0x1166f64: ldur            x0, [fp, #-0x10]
    // 0x1166f68: stur            x4, [fp, #-0x30]
    // 0x1166f6c: LoadField: r1 = r0->field_1f
    //     0x1166f6c: ldur            w1, [x0, #0x1f]
    // 0x1166f70: DecompressPointer r1
    //     0x1166f70: add             x1, x1, HEAP, lsl #32
    // 0x1166f74: ldur            x5, [fp, #-0x18]
    // 0x1166f78: LoadField: r2 = r5->field_1f
    //     0x1166f78: ldur            w2, [x5, #0x1f]
    // 0x1166f7c: DecompressPointer r2
    //     0x1166f7c: add             x2, x2, HEAP, lsl #32
    // 0x1166f80: ldur            x3, [fp, #-8]
    // 0x1166f84: r0 = lerpDouble()
    //     0x1166f84: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1166f88: mov             x4, x0
    // 0x1166f8c: ldur            x0, [fp, #-0x10]
    // 0x1166f90: stur            x4, [fp, #-0x38]
    // 0x1166f94: LoadField: r1 = r0->field_23
    //     0x1166f94: ldur            w1, [x0, #0x23]
    // 0x1166f98: DecompressPointer r1
    //     0x1166f98: add             x1, x1, HEAP, lsl #32
    // 0x1166f9c: ldur            x5, [fp, #-0x18]
    // 0x1166fa0: LoadField: r2 = r5->field_23
    //     0x1166fa0: ldur            w2, [x5, #0x23]
    // 0x1166fa4: DecompressPointer r2
    //     0x1166fa4: add             x2, x2, HEAP, lsl #32
    // 0x1166fa8: ldur            x3, [fp, #-8]
    // 0x1166fac: r0 = lerpDouble()
    //     0x1166fac: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1166fb0: mov             x4, x0
    // 0x1166fb4: ldur            x0, [fp, #-0x10]
    // 0x1166fb8: stur            x4, [fp, #-0x40]
    // 0x1166fbc: LoadField: r1 = r0->field_27
    //     0x1166fbc: ldur            w1, [x0, #0x27]
    // 0x1166fc0: DecompressPointer r1
    //     0x1166fc0: add             x1, x1, HEAP, lsl #32
    // 0x1166fc4: ldur            x5, [fp, #-0x18]
    // 0x1166fc8: LoadField: r2 = r5->field_27
    //     0x1166fc8: ldur            w2, [x5, #0x27]
    // 0x1166fcc: DecompressPointer r2
    //     0x1166fcc: add             x2, x2, HEAP, lsl #32
    // 0x1166fd0: ldur            x3, [fp, #-8]
    // 0x1166fd4: r0 = lerpDouble()
    //     0x1166fd4: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1166fd8: mov             x4, x0
    // 0x1166fdc: ldur            x0, [fp, #-0x10]
    // 0x1166fe0: stur            x4, [fp, #-0x48]
    // 0x1166fe4: LoadField: r1 = r0->field_2b
    //     0x1166fe4: ldur            w1, [x0, #0x2b]
    // 0x1166fe8: DecompressPointer r1
    //     0x1166fe8: add             x1, x1, HEAP, lsl #32
    // 0x1166fec: ldur            x5, [fp, #-0x18]
    // 0x1166ff0: LoadField: r2 = r5->field_2b
    //     0x1166ff0: ldur            w2, [x5, #0x2b]
    // 0x1166ff4: DecompressPointer r2
    //     0x1166ff4: add             x2, x2, HEAP, lsl #32
    // 0x1166ff8: ldur            x3, [fp, #-8]
    // 0x1166ffc: r0 = lerpDouble()
    //     0x1166ffc: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1167000: ldur            d0, [fp, #-0x88]
    // 0x1167004: r1 = Null
    //     0x1167004: mov             x1, NULL
    // 0x1167008: r2 = Null
    //     0x1167008: mov             x2, NULL
    // 0x116700c: stur            x0, [fp, #-0x50]
    // 0x1167010: r0 = lerp()
    //     0x1167010: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x1167014: ldur            d0, [fp, #-0x88]
    // 0x1167018: d1 = 0.500000
    //     0x1167018: fmov            d1, #0.50000000
    // 0x116701c: fcmp            d1, d0
    // 0x1167020: b.le            #0x116703c
    // 0x1167024: ldur            x0, [fp, #-0x10]
    // 0x1167028: LoadField: r1 = r0->field_33
    //     0x1167028: ldur            w1, [x0, #0x33]
    // 0x116702c: DecompressPointer r1
    //     0x116702c: add             x1, x1, HEAP, lsl #32
    // 0x1167030: mov             x12, x1
    // 0x1167034: ldur            x4, [fp, #-0x18]
    // 0x1167038: b               #0x1167050
    // 0x116703c: ldur            x0, [fp, #-0x10]
    // 0x1167040: ldur            x4, [fp, #-0x18]
    // 0x1167044: LoadField: r1 = r4->field_33
    //     0x1167044: ldur            w1, [x4, #0x33]
    // 0x1167048: DecompressPointer r1
    //     0x1167048: add             x1, x1, HEAP, lsl #32
    // 0x116704c: mov             x12, x1
    // 0x1167050: ldur            x11, [fp, #-0x20]
    // 0x1167054: ldur            x10, [fp, #-0x28]
    // 0x1167058: ldur            x9, [fp, #-0x30]
    // 0x116705c: ldur            x8, [fp, #-0x38]
    // 0x1167060: ldur            x7, [fp, #-0x40]
    // 0x1167064: ldur            x6, [fp, #-0x48]
    // 0x1167068: ldur            x5, [fp, #-0x50]
    // 0x116706c: stur            x12, [fp, #-0x58]
    // 0x1167070: LoadField: r1 = r0->field_37
    //     0x1167070: ldur            w1, [x0, #0x37]
    // 0x1167074: DecompressPointer r1
    //     0x1167074: add             x1, x1, HEAP, lsl #32
    // 0x1167078: LoadField: r2 = r4->field_37
    //     0x1167078: ldur            w2, [x4, #0x37]
    // 0x116707c: DecompressPointer r2
    //     0x116707c: add             x2, x2, HEAP, lsl #32
    // 0x1167080: ldur            x3, [fp, #-8]
    // 0x1167084: r0 = lerpDouble()
    //     0x1167084: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1167088: mov             x3, x0
    // 0x116708c: ldur            x0, [fp, #-0x10]
    // 0x1167090: stur            x3, [fp, #-0x60]
    // 0x1167094: LoadField: r1 = r0->field_3b
    //     0x1167094: ldur            w1, [x0, #0x3b]
    // 0x1167098: DecompressPointer r1
    //     0x1167098: add             x1, x1, HEAP, lsl #32
    // 0x116709c: ldur            x4, [fp, #-0x18]
    // 0x11670a0: LoadField: r2 = r4->field_3b
    //     0x11670a0: ldur            w2, [x4, #0x3b]
    // 0x11670a4: DecompressPointer r2
    //     0x11670a4: add             x2, x2, HEAP, lsl #32
    // 0x11670a8: ldur            d0, [fp, #-0x88]
    // 0x11670ac: r0 = lerp()
    //     0x11670ac: bl              #0x1163c14  ; [package:flutter/src/rendering/box.dart] BoxConstraints::lerp
    // 0x11670b0: mov             x3, x0
    // 0x11670b4: ldur            x0, [fp, #-0x10]
    // 0x11670b8: stur            x3, [fp, #-0x68]
    // 0x11670bc: LoadField: r1 = r0->field_3f
    //     0x11670bc: ldur            w1, [x0, #0x3f]
    // 0x11670c0: DecompressPointer r1
    //     0x11670c0: add             x1, x1, HEAP, lsl #32
    // 0x11670c4: ldur            x4, [fp, #-0x18]
    // 0x11670c8: LoadField: r2 = r4->field_3f
    //     0x11670c8: ldur            w2, [x4, #0x3f]
    // 0x11670cc: DecompressPointer r2
    //     0x11670cc: add             x2, x2, HEAP, lsl #32
    // 0x11670d0: ldur            d0, [fp, #-0x88]
    // 0x11670d4: r0 = lerp()
    //     0x11670d4: bl              #0x1163c14  ; [package:flutter/src/rendering/box.dart] BoxConstraints::lerp
    // 0x11670d8: mov             x3, x0
    // 0x11670dc: ldur            x0, [fp, #-0x10]
    // 0x11670e0: stur            x3, [fp, #-0x70]
    // 0x11670e4: LoadField: r1 = r0->field_43
    //     0x11670e4: ldur            w1, [x0, #0x43]
    // 0x11670e8: DecompressPointer r1
    //     0x11670e8: add             x1, x1, HEAP, lsl #32
    // 0x11670ec: ldur            x4, [fp, #-0x18]
    // 0x11670f0: LoadField: r2 = r4->field_43
    //     0x11670f0: ldur            w2, [x4, #0x43]
    // 0x11670f4: DecompressPointer r2
    //     0x11670f4: add             x2, x2, HEAP, lsl #32
    // 0x11670f8: ldur            d0, [fp, #-0x88]
    // 0x11670fc: r0 = lerp()
    //     0x11670fc: bl              #0x1163c14  ; [package:flutter/src/rendering/box.dart] BoxConstraints::lerp
    // 0x1167100: mov             x3, x0
    // 0x1167104: ldur            x0, [fp, #-0x10]
    // 0x1167108: stur            x3, [fp, #-0x78]
    // 0x116710c: LoadField: r1 = r0->field_47
    //     0x116710c: ldur            w1, [x0, #0x47]
    // 0x1167110: DecompressPointer r1
    //     0x1167110: add             x1, x1, HEAP, lsl #32
    // 0x1167114: ldur            x4, [fp, #-0x18]
    // 0x1167118: LoadField: r2 = r4->field_47
    //     0x1167118: ldur            w2, [x4, #0x47]
    // 0x116711c: DecompressPointer r2
    //     0x116711c: add             x2, x2, HEAP, lsl #32
    // 0x1167120: ldur            d0, [fp, #-0x88]
    // 0x1167124: r0 = lerp()
    //     0x1167124: bl              #0x1163c14  ; [package:flutter/src/rendering/box.dart] BoxConstraints::lerp
    // 0x1167128: mov             x4, x0
    // 0x116712c: ldur            x0, [fp, #-0x10]
    // 0x1167130: stur            x4, [fp, #-0x80]
    // 0x1167134: LoadField: r1 = r0->field_4b
    //     0x1167134: ldur            w1, [x0, #0x4b]
    // 0x1167138: DecompressPointer r1
    //     0x1167138: add             x1, x1, HEAP, lsl #32
    // 0x116713c: ldur            x0, [fp, #-0x18]
    // 0x1167140: LoadField: r2 = r0->field_4b
    //     0x1167140: ldur            w2, [x0, #0x4b]
    // 0x1167144: DecompressPointer r2
    //     0x1167144: add             x2, x2, HEAP, lsl #32
    // 0x1167148: ldur            x3, [fp, #-8]
    // 0x116714c: r0 = lerpDouble()
    //     0x116714c: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1167150: ldur            x3, [fp, #-8]
    // 0x1167154: r1 = Null
    //     0x1167154: mov             x1, NULL
    // 0x1167158: r2 = Null
    //     0x1167158: mov             x2, NULL
    // 0x116715c: stur            x0, [fp, #-0x10]
    // 0x1167160: r0 = lerp()
    //     0x1167160: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x1167164: ldur            x3, [fp, #-8]
    // 0x1167168: r1 = Null
    //     0x1167168: mov             x1, NULL
    // 0x116716c: r2 = Null
    //     0x116716c: mov             x2, NULL
    // 0x1167170: r0 = lerp()
    //     0x1167170: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1167174: r0 = FloatingActionButtonThemeData()
    //     0x1167174: bl              #0x1167220  ; AllocateFloatingActionButtonThemeDataStub -> FloatingActionButtonThemeData (size=0x5c)
    // 0x1167178: ldur            x1, [fp, #-0x20]
    // 0x116717c: StoreField: r0->field_7 = r1
    //     0x116717c: stur            w1, [x0, #7]
    // 0x1167180: ldur            x1, [fp, #-0x28]
    // 0x1167184: StoreField: r0->field_b = r1
    //     0x1167184: stur            w1, [x0, #0xb]
    // 0x1167188: ldur            x1, [fp, #-0x30]
    // 0x116718c: StoreField: r0->field_1b = r1
    //     0x116718c: stur            w1, [x0, #0x1b]
    // 0x1167190: ldur            x1, [fp, #-0x38]
    // 0x1167194: StoreField: r0->field_1f = r1
    //     0x1167194: stur            w1, [x0, #0x1f]
    // 0x1167198: ldur            x1, [fp, #-0x40]
    // 0x116719c: StoreField: r0->field_23 = r1
    //     0x116719c: stur            w1, [x0, #0x23]
    // 0x11671a0: ldur            x1, [fp, #-0x48]
    // 0x11671a4: StoreField: r0->field_27 = r1
    //     0x11671a4: stur            w1, [x0, #0x27]
    // 0x11671a8: ldur            x1, [fp, #-0x50]
    // 0x11671ac: StoreField: r0->field_2b = r1
    //     0x11671ac: stur            w1, [x0, #0x2b]
    // 0x11671b0: ldur            x1, [fp, #-0x58]
    // 0x11671b4: StoreField: r0->field_33 = r1
    //     0x11671b4: stur            w1, [x0, #0x33]
    // 0x11671b8: ldur            x1, [fp, #-0x60]
    // 0x11671bc: StoreField: r0->field_37 = r1
    //     0x11671bc: stur            w1, [x0, #0x37]
    // 0x11671c0: ldur            x1, [fp, #-0x68]
    // 0x11671c4: StoreField: r0->field_3b = r1
    //     0x11671c4: stur            w1, [x0, #0x3b]
    // 0x11671c8: ldur            x1, [fp, #-0x70]
    // 0x11671cc: StoreField: r0->field_3f = r1
    //     0x11671cc: stur            w1, [x0, #0x3f]
    // 0x11671d0: ldur            x1, [fp, #-0x78]
    // 0x11671d4: StoreField: r0->field_43 = r1
    //     0x11671d4: stur            w1, [x0, #0x43]
    // 0x11671d8: ldur            x1, [fp, #-0x80]
    // 0x11671dc: StoreField: r0->field_47 = r1
    //     0x11671dc: stur            w1, [x0, #0x47]
    // 0x11671e0: ldur            x1, [fp, #-0x10]
    // 0x11671e4: StoreField: r0->field_4b = r1
    //     0x11671e4: stur            w1, [x0, #0x4b]
    // 0x11671e8: LeaveFrame
    //     0x11671e8: mov             SP, fp
    //     0x11671ec: ldp             fp, lr, [SP], #0x10
    // 0x11671f0: ret
    //     0x11671f0: ret             
    // 0x11671f4: r0 = StackOverflowSharedWithFPURegs()
    //     0x11671f4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11671f8: b               #0x1166e84
    // 0x11671fc: SaveReg d0
    //     0x11671fc: str             q0, [SP, #-0x10]!
    // 0x1167200: stp             x2, x4, [SP, #-0x10]!
    // 0x1167204: stp             x0, x1, [SP, #-0x10]!
    // 0x1167208: r0 = AllocateDouble()
    //     0x1167208: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116720c: mov             x5, x0
    // 0x1167210: ldp             x0, x1, [SP], #0x10
    // 0x1167214: ldp             x2, x4, [SP], #0x10
    // 0x1167218: RestoreReg d0
    //     0x1167218: ldr             q0, [SP], #0x10
    // 0x116721c: b               #0x1166ed4
  }
  _ ==(/* No info */) {
    // ** addr: 0x126c838, size: 0xfa4
    // 0x126c838: EnterFrame
    //     0x126c838: stp             fp, lr, [SP, #-0x10]!
    //     0x126c83c: mov             fp, SP
    // 0x126c840: AllocStack(0x28)
    //     0x126c840: sub             SP, SP, #0x28
    // 0x126c844: CheckStackOverflow
    //     0x126c844: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x126c848: cmp             SP, x16
    //     0x126c84c: b.ls            #0x126d788
    // 0x126c850: ldr             x1, [fp, #0x10]
    // 0x126c854: cmp             w1, NULL
    // 0x126c858: b.ne            #0x126c86c
    // 0x126c85c: r0 = false
    //     0x126c85c: add             x0, NULL, #0x30  ; false
    // 0x126c860: LeaveFrame
    //     0x126c860: mov             SP, fp
    //     0x126c864: ldp             fp, lr, [SP], #0x10
    // 0x126c868: ret
    //     0x126c868: ret             
    // 0x126c86c: ldr             x0, [fp, #0x18]
    // 0x126c870: cmp             w0, w1
    // 0x126c874: b.ne            #0x126c888
    // 0x126c878: r0 = true
    //     0x126c878: add             x0, NULL, #0x20  ; true
    // 0x126c87c: LeaveFrame
    //     0x126c87c: mov             SP, fp
    //     0x126c880: ldp             fp, lr, [SP], #0x10
    // 0x126c884: ret
    //     0x126c884: ret             
    // 0x126c888: stp             x0, x1, [SP]
    // 0x126c88c: r0 = _haveSameRuntimeType()
    //     0x126c88c: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x126c890: tbz             w0, #4, #0x126c8a4
    // 0x126c894: r0 = false
    //     0x126c894: add             x0, NULL, #0x30  ; false
    // 0x126c898: LeaveFrame
    //     0x126c898: mov             SP, fp
    //     0x126c89c: ldp             fp, lr, [SP], #0x10
    // 0x126c8a0: ret
    //     0x126c8a0: ret             
    // 0x126c8a4: ldr             x0, [fp, #0x10]
    // 0x126c8a8: r2 = 60
    //     0x126c8a8: mov             x2, #0x3c
    // 0x126c8ac: branchIfSmi(r0, 0x126c8b8)
    //     0x126c8ac: tbz             w0, #0, #0x126c8b8
    // 0x126c8b0: r2 = LoadClassIdInstr(r0)
    //     0x126c8b0: ldur            x2, [x0, #-1]
    //     0x126c8b4: ubfx            x2, x2, #0xc, #0x14
    // 0x126c8b8: stur            x2, [fp, #-8]
    // 0x126c8bc: r17 = -5148
    //     0x126c8bc: mov             x17, #-0x141c
    // 0x126c8c0: add             x16, x2, x17
    // 0x126c8c4: cmp             x16, #2
    // 0x126c8c8: b.hi            #0x126d778
    // 0x126c8cc: r17 = 5148
    //     0x126c8cc: mov             x17, #0x141c
    // 0x126c8d0: cmp             x2, x17
    // 0x126c8d4: b.ne            #0x126c8e8
    // 0x126c8d8: LoadField: r1 = r0->field_7
    //     0x126c8d8: ldur            w1, [x0, #7]
    // 0x126c8dc: DecompressPointer r1
    //     0x126c8dc: add             x1, x1, HEAP, lsl #32
    // 0x126c8e0: mov             x3, x1
    // 0x126c8e4: b               #0x126c95c
    // 0x126c8e8: r17 = 5149
    //     0x126c8e8: mov             x17, #0x141d
    // 0x126c8ec: cmp             x2, x17
    // 0x126c8f0: b.ne            #0x126c948
    // 0x126c8f4: mov             x1, x0
    // 0x126c8f8: LoadField: r0 = r1->field_67
    //     0x126c8f8: ldur            w0, [x1, #0x67]
    // 0x126c8fc: DecompressPointer r0
    //     0x126c8fc: add             x0, x0, HEAP, lsl #32
    // 0x126c900: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126c904: cmp             w0, w16
    // 0x126c908: b.ne            #0x126c918
    // 0x126c90c: r2 = _colors
    //     0x126c90c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26358] Field <_FABDefaultsM3@751192485._colors@751192485>: late final (offset: 0x68)
    //     0x126c910: ldr             x2, [x2, #0x358]
    // 0x126c914: r0 = InitLateFinalInstanceField()
    //     0x126c914: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126c918: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x126c918: ldur            w1, [x0, #0x17]
    // 0x126c91c: DecompressPointer r1
    //     0x126c91c: add             x1, x1, HEAP, lsl #32
    // 0x126c920: cmp             w1, NULL
    // 0x126c924: b.ne            #0x126c938
    // 0x126c928: LoadField: r1 = r0->field_f
    //     0x126c928: ldur            w1, [x0, #0xf]
    // 0x126c92c: DecompressPointer r1
    //     0x126c92c: add             x1, x1, HEAP, lsl #32
    // 0x126c930: mov             x0, x1
    // 0x126c934: b               #0x126c93c
    // 0x126c938: mov             x0, x1
    // 0x126c93c: mov             x3, x0
    // 0x126c940: ldr             x0, [fp, #0x10]
    // 0x126c944: b               #0x126c95c
    // 0x126c948: LoadField: r1 = r0->field_67
    //     0x126c948: ldur            w1, [x0, #0x67]
    // 0x126c94c: DecompressPointer r1
    //     0x126c94c: add             x1, x1, HEAP, lsl #32
    // 0x126c950: LoadField: r2 = r1->field_2f
    //     0x126c950: ldur            w2, [x1, #0x2f]
    // 0x126c954: DecompressPointer r2
    //     0x126c954: add             x2, x2, HEAP, lsl #32
    // 0x126c958: mov             x3, x2
    // 0x126c95c: ldr             x2, [fp, #0x18]
    // 0x126c960: stur            x3, [fp, #-0x18]
    // 0x126c964: r4 = LoadClassIdInstr(r2)
    //     0x126c964: ldur            x4, [x2, #-1]
    //     0x126c968: ubfx            x4, x4, #0xc, #0x14
    // 0x126c96c: stur            x4, [fp, #-0x10]
    // 0x126c970: r17 = 5148
    //     0x126c970: mov             x17, #0x141c
    // 0x126c974: cmp             x4, x17
    // 0x126c978: b.ne            #0x126c998
    // 0x126c97c: LoadField: r1 = r2->field_7
    //     0x126c97c: ldur            w1, [x2, #7]
    // 0x126c980: DecompressPointer r1
    //     0x126c980: add             x1, x1, HEAP, lsl #32
    // 0x126c984: mov             x16, x2
    // 0x126c988: mov             x2, x1
    // 0x126c98c: mov             x1, x16
    // 0x126c990: mov             x0, x3
    // 0x126c994: b               #0x126ca14
    // 0x126c998: r17 = 5149
    //     0x126c998: mov             x17, #0x141d
    // 0x126c99c: cmp             x4, x17
    // 0x126c9a0: b.ne            #0x126c9fc
    // 0x126c9a4: mov             x1, x2
    // 0x126c9a8: LoadField: r0 = r1->field_67
    //     0x126c9a8: ldur            w0, [x1, #0x67]
    // 0x126c9ac: DecompressPointer r0
    //     0x126c9ac: add             x0, x0, HEAP, lsl #32
    // 0x126c9b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126c9b4: cmp             w0, w16
    // 0x126c9b8: b.ne            #0x126c9c8
    // 0x126c9bc: r2 = _colors
    //     0x126c9bc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26358] Field <_FABDefaultsM3@751192485._colors@751192485>: late final (offset: 0x68)
    //     0x126c9c0: ldr             x2, [x2, #0x358]
    // 0x126c9c4: r0 = InitLateFinalInstanceField()
    //     0x126c9c4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126c9c8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x126c9c8: ldur            w1, [x0, #0x17]
    // 0x126c9cc: DecompressPointer r1
    //     0x126c9cc: add             x1, x1, HEAP, lsl #32
    // 0x126c9d0: cmp             w1, NULL
    // 0x126c9d4: b.ne            #0x126c9e8
    // 0x126c9d8: LoadField: r1 = r0->field_f
    //     0x126c9d8: ldur            w1, [x0, #0xf]
    // 0x126c9dc: DecompressPointer r1
    //     0x126c9dc: add             x1, x1, HEAP, lsl #32
    // 0x126c9e0: mov             x0, x1
    // 0x126c9e4: b               #0x126c9ec
    // 0x126c9e8: mov             x0, x1
    // 0x126c9ec: mov             x2, x0
    // 0x126c9f0: ldr             x1, [fp, #0x18]
    // 0x126c9f4: ldur            x0, [fp, #-0x18]
    // 0x126c9f8: b               #0x126ca14
    // 0x126c9fc: mov             x1, x2
    // 0x126ca00: LoadField: r0 = r1->field_67
    //     0x126ca00: ldur            w0, [x1, #0x67]
    // 0x126ca04: DecompressPointer r0
    //     0x126ca04: add             x0, x0, HEAP, lsl #32
    // 0x126ca08: LoadField: r2 = r0->field_2f
    //     0x126ca08: ldur            w2, [x0, #0x2f]
    // 0x126ca0c: DecompressPointer r2
    //     0x126ca0c: add             x2, x2, HEAP, lsl #32
    // 0x126ca10: ldur            x0, [fp, #-0x18]
    // 0x126ca14: r3 = LoadClassIdInstr(r0)
    //     0x126ca14: ldur            x3, [x0, #-1]
    //     0x126ca18: ubfx            x3, x3, #0xc, #0x14
    // 0x126ca1c: stp             x2, x0, [SP]
    // 0x126ca20: mov             x0, x3
    // 0x126ca24: mov             lr, x0
    // 0x126ca28: ldr             lr, [x21, lr, lsl #3]
    // 0x126ca2c: blr             lr
    // 0x126ca30: tbnz            w0, #4, #0x126d778
    // 0x126ca34: ldur            x0, [fp, #-8]
    // 0x126ca38: r17 = 5148
    //     0x126ca38: mov             x17, #0x141c
    // 0x126ca3c: cmp             x0, x17
    // 0x126ca40: b.ne            #0x126ca5c
    // 0x126ca44: ldr             x2, [fp, #0x10]
    // 0x126ca48: LoadField: r1 = r2->field_b
    //     0x126ca48: ldur            w1, [x2, #0xb]
    // 0x126ca4c: DecompressPointer r1
    //     0x126ca4c: add             x1, x1, HEAP, lsl #32
    // 0x126ca50: mov             x3, x1
    // 0x126ca54: mov             x0, x2
    // 0x126ca58: b               #0x126cad8
    // 0x126ca5c: ldr             x2, [fp, #0x10]
    // 0x126ca60: r17 = 5149
    //     0x126ca60: mov             x17, #0x141d
    // 0x126ca64: cmp             x0, x17
    // 0x126ca68: b.ne            #0x126cac0
    // 0x126ca6c: mov             x1, x2
    // 0x126ca70: LoadField: r0 = r1->field_67
    //     0x126ca70: ldur            w0, [x1, #0x67]
    // 0x126ca74: DecompressPointer r0
    //     0x126ca74: add             x0, x0, HEAP, lsl #32
    // 0x126ca78: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126ca7c: cmp             w0, w16
    // 0x126ca80: b.ne            #0x126ca90
    // 0x126ca84: r2 = _colors
    //     0x126ca84: add             x2, PP, #0x26, lsl #12  ; [pp+0x26358] Field <_FABDefaultsM3@751192485._colors@751192485>: late final (offset: 0x68)
    //     0x126ca88: ldr             x2, [x2, #0x358]
    // 0x126ca8c: r0 = InitLateFinalInstanceField()
    //     0x126ca8c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126ca90: LoadField: r1 = r0->field_13
    //     0x126ca90: ldur            w1, [x0, #0x13]
    // 0x126ca94: DecompressPointer r1
    //     0x126ca94: add             x1, x1, HEAP, lsl #32
    // 0x126ca98: cmp             w1, NULL
    // 0x126ca9c: b.ne            #0x126cab0
    // 0x126caa0: LoadField: r1 = r0->field_b
    //     0x126caa0: ldur            w1, [x0, #0xb]
    // 0x126caa4: DecompressPointer r1
    //     0x126caa4: add             x1, x1, HEAP, lsl #32
    // 0x126caa8: mov             x0, x1
    // 0x126caac: b               #0x126cab4
    // 0x126cab0: mov             x0, x1
    // 0x126cab4: mov             x3, x0
    // 0x126cab8: ldr             x0, [fp, #0x10]
    // 0x126cabc: b               #0x126cad8
    // 0x126cac0: mov             x0, x2
    // 0x126cac4: LoadField: r1 = r0->field_67
    //     0x126cac4: ldur            w1, [x0, #0x67]
    // 0x126cac8: DecompressPointer r1
    //     0x126cac8: add             x1, x1, HEAP, lsl #32
    // 0x126cacc: LoadField: r2 = r1->field_2b
    //     0x126cacc: ldur            w2, [x1, #0x2b]
    // 0x126cad0: DecompressPointer r2
    //     0x126cad0: add             x2, x2, HEAP, lsl #32
    // 0x126cad4: mov             x3, x2
    // 0x126cad8: ldur            x2, [fp, #-0x10]
    // 0x126cadc: stur            x3, [fp, #-0x18]
    // 0x126cae0: r17 = 5148
    //     0x126cae0: mov             x17, #0x141c
    // 0x126cae4: cmp             x2, x17
    // 0x126cae8: b.ne            #0x126cb08
    // 0x126caec: ldr             x4, [fp, #0x18]
    // 0x126caf0: LoadField: r1 = r4->field_b
    //     0x126caf0: ldur            w1, [x4, #0xb]
    // 0x126caf4: DecompressPointer r1
    //     0x126caf4: add             x1, x1, HEAP, lsl #32
    // 0x126caf8: mov             x2, x1
    // 0x126cafc: mov             x1, x4
    // 0x126cb00: mov             x0, x3
    // 0x126cb04: b               #0x126cb88
    // 0x126cb08: ldr             x4, [fp, #0x18]
    // 0x126cb0c: r17 = 5149
    //     0x126cb0c: mov             x17, #0x141d
    // 0x126cb10: cmp             x2, x17
    // 0x126cb14: b.ne            #0x126cb70
    // 0x126cb18: mov             x1, x4
    // 0x126cb1c: LoadField: r0 = r1->field_67
    //     0x126cb1c: ldur            w0, [x1, #0x67]
    // 0x126cb20: DecompressPointer r0
    //     0x126cb20: add             x0, x0, HEAP, lsl #32
    // 0x126cb24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126cb28: cmp             w0, w16
    // 0x126cb2c: b.ne            #0x126cb3c
    // 0x126cb30: r2 = _colors
    //     0x126cb30: add             x2, PP, #0x26, lsl #12  ; [pp+0x26358] Field <_FABDefaultsM3@751192485._colors@751192485>: late final (offset: 0x68)
    //     0x126cb34: ldr             x2, [x2, #0x358]
    // 0x126cb38: r0 = InitLateFinalInstanceField()
    //     0x126cb38: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126cb3c: LoadField: r1 = r0->field_13
    //     0x126cb3c: ldur            w1, [x0, #0x13]
    // 0x126cb40: DecompressPointer r1
    //     0x126cb40: add             x1, x1, HEAP, lsl #32
    // 0x126cb44: cmp             w1, NULL
    // 0x126cb48: b.ne            #0x126cb5c
    // 0x126cb4c: LoadField: r1 = r0->field_b
    //     0x126cb4c: ldur            w1, [x0, #0xb]
    // 0x126cb50: DecompressPointer r1
    //     0x126cb50: add             x1, x1, HEAP, lsl #32
    // 0x126cb54: mov             x0, x1
    // 0x126cb58: b               #0x126cb60
    // 0x126cb5c: mov             x0, x1
    // 0x126cb60: mov             x2, x0
    // 0x126cb64: ldr             x1, [fp, #0x18]
    // 0x126cb68: ldur            x0, [fp, #-0x18]
    // 0x126cb6c: b               #0x126cb88
    // 0x126cb70: mov             x1, x4
    // 0x126cb74: LoadField: r0 = r1->field_67
    //     0x126cb74: ldur            w0, [x1, #0x67]
    // 0x126cb78: DecompressPointer r0
    //     0x126cb78: add             x0, x0, HEAP, lsl #32
    // 0x126cb7c: LoadField: r2 = r0->field_2b
    //     0x126cb7c: ldur            w2, [x0, #0x2b]
    // 0x126cb80: DecompressPointer r2
    //     0x126cb80: add             x2, x2, HEAP, lsl #32
    // 0x126cb84: ldur            x0, [fp, #-0x18]
    // 0x126cb88: r3 = LoadClassIdInstr(r0)
    //     0x126cb88: ldur            x3, [x0, #-1]
    //     0x126cb8c: ubfx            x3, x3, #0xc, #0x14
    // 0x126cb90: stp             x2, x0, [SP]
    // 0x126cb94: mov             x0, x3
    // 0x126cb98: mov             lr, x0
    // 0x126cb9c: ldr             lr, [x21, lr, lsl #3]
    // 0x126cba0: blr             lr
    // 0x126cba4: tbnz            w0, #4, #0x126d778
    // 0x126cba8: ldur            x0, [fp, #-8]
    // 0x126cbac: r17 = 5148
    //     0x126cbac: mov             x17, #0x141c
    // 0x126cbb0: cmp             x0, x17
    // 0x126cbb4: b.ne            #0x126cbd0
    // 0x126cbb8: ldr             x2, [fp, #0x10]
    // 0x126cbbc: LoadField: r1 = r2->field_f
    //     0x126cbbc: ldur            w1, [x2, #0xf]
    // 0x126cbc0: DecompressPointer r1
    //     0x126cbc0: add             x1, x1, HEAP, lsl #32
    // 0x126cbc4: mov             x3, x1
    // 0x126cbc8: mov             x0, x2
    // 0x126cbcc: b               #0x126cc4c
    // 0x126cbd0: ldr             x2, [fp, #0x10]
    // 0x126cbd4: r17 = 5149
    //     0x126cbd4: mov             x17, #0x141d
    // 0x126cbd8: cmp             x0, x17
    // 0x126cbdc: b.ne            #0x126cc34
    // 0x126cbe0: mov             x1, x2
    // 0x126cbe4: LoadField: r0 = r1->field_67
    //     0x126cbe4: ldur            w0, [x1, #0x67]
    // 0x126cbe8: DecompressPointer r0
    //     0x126cbe8: add             x0, x0, HEAP, lsl #32
    // 0x126cbec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126cbf0: cmp             w0, w16
    // 0x126cbf4: b.ne            #0x126cc04
    // 0x126cbf8: r2 = _colors
    //     0x126cbf8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26358] Field <_FABDefaultsM3@751192485._colors@751192485>: late final (offset: 0x68)
    //     0x126cbfc: ldr             x2, [x2, #0x358]
    // 0x126cc00: r0 = InitLateFinalInstanceField()
    //     0x126cc00: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126cc04: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x126cc04: ldur            w1, [x0, #0x17]
    // 0x126cc08: DecompressPointer r1
    //     0x126cc08: add             x1, x1, HEAP, lsl #32
    // 0x126cc0c: cmp             w1, NULL
    // 0x126cc10: b.ne            #0x126cc1c
    // 0x126cc14: LoadField: r1 = r0->field_f
    //     0x126cc14: ldur            w1, [x0, #0xf]
    // 0x126cc18: DecompressPointer r1
    //     0x126cc18: add             x1, x1, HEAP, lsl #32
    // 0x126cc1c: d0 = 0.100000
    //     0x126cc1c: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x126cc20: ldr             d0, [x17, #0x1e0]
    // 0x126cc24: r0 = withOpacity()
    //     0x126cc24: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x126cc28: mov             x3, x0
    // 0x126cc2c: ldr             x0, [fp, #0x10]
    // 0x126cc30: b               #0x126cc4c
    // 0x126cc34: mov             x0, x2
    // 0x126cc38: LoadField: r1 = r0->field_63
    //     0x126cc38: ldur            w1, [x0, #0x63]
    // 0x126cc3c: DecompressPointer r1
    //     0x126cc3c: add             x1, x1, HEAP, lsl #32
    // 0x126cc40: LoadField: r2 = r1->field_4b
    //     0x126cc40: ldur            w2, [x1, #0x4b]
    // 0x126cc44: DecompressPointer r2
    //     0x126cc44: add             x2, x2, HEAP, lsl #32
    // 0x126cc48: mov             x3, x2
    // 0x126cc4c: ldur            x2, [fp, #-0x10]
    // 0x126cc50: stur            x3, [fp, #-0x18]
    // 0x126cc54: r17 = 5148
    //     0x126cc54: mov             x17, #0x141c
    // 0x126cc58: cmp             x2, x17
    // 0x126cc5c: b.ne            #0x126cc7c
    // 0x126cc60: ldr             x4, [fp, #0x18]
    // 0x126cc64: LoadField: r1 = r4->field_f
    //     0x126cc64: ldur            w1, [x4, #0xf]
    // 0x126cc68: DecompressPointer r1
    //     0x126cc68: add             x1, x1, HEAP, lsl #32
    // 0x126cc6c: mov             x2, x1
    // 0x126cc70: mov             x1, x4
    // 0x126cc74: mov             x0, x3
    // 0x126cc78: b               #0x126ccfc
    // 0x126cc7c: ldr             x4, [fp, #0x18]
    // 0x126cc80: r17 = 5149
    //     0x126cc80: mov             x17, #0x141d
    // 0x126cc84: cmp             x2, x17
    // 0x126cc88: b.ne            #0x126cce4
    // 0x126cc8c: mov             x1, x4
    // 0x126cc90: LoadField: r0 = r1->field_67
    //     0x126cc90: ldur            w0, [x1, #0x67]
    // 0x126cc94: DecompressPointer r0
    //     0x126cc94: add             x0, x0, HEAP, lsl #32
    // 0x126cc98: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126cc9c: cmp             w0, w16
    // 0x126cca0: b.ne            #0x126ccb0
    // 0x126cca4: r2 = _colors
    //     0x126cca4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26358] Field <_FABDefaultsM3@751192485._colors@751192485>: late final (offset: 0x68)
    //     0x126cca8: ldr             x2, [x2, #0x358]
    // 0x126ccac: r0 = InitLateFinalInstanceField()
    //     0x126ccac: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126ccb0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x126ccb0: ldur            w1, [x0, #0x17]
    // 0x126ccb4: DecompressPointer r1
    //     0x126ccb4: add             x1, x1, HEAP, lsl #32
    // 0x126ccb8: cmp             w1, NULL
    // 0x126ccbc: b.ne            #0x126ccc8
    // 0x126ccc0: LoadField: r1 = r0->field_f
    //     0x126ccc0: ldur            w1, [x0, #0xf]
    // 0x126ccc4: DecompressPointer r1
    //     0x126ccc4: add             x1, x1, HEAP, lsl #32
    // 0x126ccc8: d0 = 0.100000
    //     0x126ccc8: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x126cccc: ldr             d0, [x17, #0x1e0]
    // 0x126ccd0: r0 = withOpacity()
    //     0x126ccd0: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x126ccd4: mov             x2, x0
    // 0x126ccd8: ldr             x1, [fp, #0x18]
    // 0x126ccdc: ldur            x0, [fp, #-0x18]
    // 0x126cce0: b               #0x126ccfc
    // 0x126cce4: mov             x1, x4
    // 0x126cce8: LoadField: r0 = r1->field_63
    //     0x126cce8: ldur            w0, [x1, #0x63]
    // 0x126ccec: DecompressPointer r0
    //     0x126ccec: add             x0, x0, HEAP, lsl #32
    // 0x126ccf0: LoadField: r2 = r0->field_4b
    //     0x126ccf0: ldur            w2, [x0, #0x4b]
    // 0x126ccf4: DecompressPointer r2
    //     0x126ccf4: add             x2, x2, HEAP, lsl #32
    // 0x126ccf8: ldur            x0, [fp, #-0x18]
    // 0x126ccfc: r3 = LoadClassIdInstr(r0)
    //     0x126ccfc: ldur            x3, [x0, #-1]
    //     0x126cd00: ubfx            x3, x3, #0xc, #0x14
    // 0x126cd04: stp             x2, x0, [SP]
    // 0x126cd08: mov             x0, x3
    // 0x126cd0c: mov             lr, x0
    // 0x126cd10: ldr             lr, [x21, lr, lsl #3]
    // 0x126cd14: blr             lr
    // 0x126cd18: tbnz            w0, #4, #0x126d778
    // 0x126cd1c: ldur            x0, [fp, #-8]
    // 0x126cd20: r17 = 5148
    //     0x126cd20: mov             x17, #0x141c
    // 0x126cd24: cmp             x0, x17
    // 0x126cd28: b.ne            #0x126cd44
    // 0x126cd2c: ldr             x2, [fp, #0x10]
    // 0x126cd30: LoadField: r1 = r2->field_13
    //     0x126cd30: ldur            w1, [x2, #0x13]
    // 0x126cd34: DecompressPointer r1
    //     0x126cd34: add             x1, x1, HEAP, lsl #32
    // 0x126cd38: mov             x3, x1
    // 0x126cd3c: mov             x0, x2
    // 0x126cd40: b               #0x126cdc0
    // 0x126cd44: ldr             x2, [fp, #0x10]
    // 0x126cd48: r17 = 5149
    //     0x126cd48: mov             x17, #0x141d
    // 0x126cd4c: cmp             x0, x17
    // 0x126cd50: b.ne            #0x126cda8
    // 0x126cd54: mov             x1, x2
    // 0x126cd58: LoadField: r0 = r1->field_67
    //     0x126cd58: ldur            w0, [x1, #0x67]
    // 0x126cd5c: DecompressPointer r0
    //     0x126cd5c: add             x0, x0, HEAP, lsl #32
    // 0x126cd60: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126cd64: cmp             w0, w16
    // 0x126cd68: b.ne            #0x126cd78
    // 0x126cd6c: r2 = _colors
    //     0x126cd6c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26358] Field <_FABDefaultsM3@751192485._colors@751192485>: late final (offset: 0x68)
    //     0x126cd70: ldr             x2, [x2, #0x358]
    // 0x126cd74: r0 = InitLateFinalInstanceField()
    //     0x126cd74: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126cd78: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x126cd78: ldur            w1, [x0, #0x17]
    // 0x126cd7c: DecompressPointer r1
    //     0x126cd7c: add             x1, x1, HEAP, lsl #32
    // 0x126cd80: cmp             w1, NULL
    // 0x126cd84: b.ne            #0x126cd90
    // 0x126cd88: LoadField: r1 = r0->field_f
    //     0x126cd88: ldur            w1, [x0, #0xf]
    // 0x126cd8c: DecompressPointer r1
    //     0x126cd8c: add             x1, x1, HEAP, lsl #32
    // 0x126cd90: d0 = 0.080000
    //     0x126cd90: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x126cd94: ldr             d0, [x17, #0xa58]
    // 0x126cd98: r0 = withOpacity()
    //     0x126cd98: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x126cd9c: mov             x3, x0
    // 0x126cda0: ldr             x0, [fp, #0x10]
    // 0x126cda4: b               #0x126cdc0
    // 0x126cda8: mov             x0, x2
    // 0x126cdac: LoadField: r1 = r0->field_63
    //     0x126cdac: ldur            w1, [x0, #0x63]
    // 0x126cdb0: DecompressPointer r1
    //     0x126cdb0: add             x1, x1, HEAP, lsl #32
    // 0x126cdb4: LoadField: r2 = r1->field_57
    //     0x126cdb4: ldur            w2, [x1, #0x57]
    // 0x126cdb8: DecompressPointer r2
    //     0x126cdb8: add             x2, x2, HEAP, lsl #32
    // 0x126cdbc: mov             x3, x2
    // 0x126cdc0: ldur            x2, [fp, #-0x10]
    // 0x126cdc4: stur            x3, [fp, #-0x18]
    // 0x126cdc8: r17 = 5148
    //     0x126cdc8: mov             x17, #0x141c
    // 0x126cdcc: cmp             x2, x17
    // 0x126cdd0: b.ne            #0x126cdf0
    // 0x126cdd4: ldr             x4, [fp, #0x18]
    // 0x126cdd8: LoadField: r1 = r4->field_13
    //     0x126cdd8: ldur            w1, [x4, #0x13]
    // 0x126cddc: DecompressPointer r1
    //     0x126cddc: add             x1, x1, HEAP, lsl #32
    // 0x126cde0: mov             x2, x1
    // 0x126cde4: mov             x1, x4
    // 0x126cde8: mov             x0, x3
    // 0x126cdec: b               #0x126ce70
    // 0x126cdf0: ldr             x4, [fp, #0x18]
    // 0x126cdf4: r17 = 5149
    //     0x126cdf4: mov             x17, #0x141d
    // 0x126cdf8: cmp             x2, x17
    // 0x126cdfc: b.ne            #0x126ce58
    // 0x126ce00: mov             x1, x4
    // 0x126ce04: LoadField: r0 = r1->field_67
    //     0x126ce04: ldur            w0, [x1, #0x67]
    // 0x126ce08: DecompressPointer r0
    //     0x126ce08: add             x0, x0, HEAP, lsl #32
    // 0x126ce0c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126ce10: cmp             w0, w16
    // 0x126ce14: b.ne            #0x126ce24
    // 0x126ce18: r2 = _colors
    //     0x126ce18: add             x2, PP, #0x26, lsl #12  ; [pp+0x26358] Field <_FABDefaultsM3@751192485._colors@751192485>: late final (offset: 0x68)
    //     0x126ce1c: ldr             x2, [x2, #0x358]
    // 0x126ce20: r0 = InitLateFinalInstanceField()
    //     0x126ce20: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126ce24: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x126ce24: ldur            w1, [x0, #0x17]
    // 0x126ce28: DecompressPointer r1
    //     0x126ce28: add             x1, x1, HEAP, lsl #32
    // 0x126ce2c: cmp             w1, NULL
    // 0x126ce30: b.ne            #0x126ce3c
    // 0x126ce34: LoadField: r1 = r0->field_f
    //     0x126ce34: ldur            w1, [x0, #0xf]
    // 0x126ce38: DecompressPointer r1
    //     0x126ce38: add             x1, x1, HEAP, lsl #32
    // 0x126ce3c: d0 = 0.080000
    //     0x126ce3c: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x126ce40: ldr             d0, [x17, #0xa58]
    // 0x126ce44: r0 = withOpacity()
    //     0x126ce44: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x126ce48: mov             x2, x0
    // 0x126ce4c: ldr             x1, [fp, #0x18]
    // 0x126ce50: ldur            x0, [fp, #-0x18]
    // 0x126ce54: b               #0x126ce70
    // 0x126ce58: mov             x1, x4
    // 0x126ce5c: LoadField: r0 = r1->field_63
    //     0x126ce5c: ldur            w0, [x1, #0x63]
    // 0x126ce60: DecompressPointer r0
    //     0x126ce60: add             x0, x0, HEAP, lsl #32
    // 0x126ce64: LoadField: r2 = r0->field_57
    //     0x126ce64: ldur            w2, [x0, #0x57]
    // 0x126ce68: DecompressPointer r2
    //     0x126ce68: add             x2, x2, HEAP, lsl #32
    // 0x126ce6c: ldur            x0, [fp, #-0x18]
    // 0x126ce70: r3 = LoadClassIdInstr(r0)
    //     0x126ce70: ldur            x3, [x0, #-1]
    //     0x126ce74: ubfx            x3, x3, #0xc, #0x14
    // 0x126ce78: stp             x2, x0, [SP]
    // 0x126ce7c: mov             x0, x3
    // 0x126ce80: mov             lr, x0
    // 0x126ce84: ldr             lr, [x21, lr, lsl #3]
    // 0x126ce88: blr             lr
    // 0x126ce8c: tbnz            w0, #4, #0x126d778
    // 0x126ce90: ldur            x0, [fp, #-8]
    // 0x126ce94: r17 = 5148
    //     0x126ce94: mov             x17, #0x141c
    // 0x126ce98: cmp             x0, x17
    // 0x126ce9c: b.ne            #0x126ceb8
    // 0x126cea0: ldr             x2, [fp, #0x10]
    // 0x126cea4: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x126cea4: ldur            w1, [x2, #0x17]
    // 0x126cea8: DecompressPointer r1
    //     0x126cea8: add             x1, x1, HEAP, lsl #32
    // 0x126ceac: mov             x3, x1
    // 0x126ceb0: mov             x0, x2
    // 0x126ceb4: b               #0x126cf34
    // 0x126ceb8: ldr             x2, [fp, #0x10]
    // 0x126cebc: r17 = 5149
    //     0x126cebc: mov             x17, #0x141d
    // 0x126cec0: cmp             x0, x17
    // 0x126cec4: b.ne            #0x126cf1c
    // 0x126cec8: mov             x1, x2
    // 0x126cecc: LoadField: r0 = r1->field_67
    //     0x126cecc: ldur            w0, [x1, #0x67]
    // 0x126ced0: DecompressPointer r0
    //     0x126ced0: add             x0, x0, HEAP, lsl #32
    // 0x126ced4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126ced8: cmp             w0, w16
    // 0x126cedc: b.ne            #0x126ceec
    // 0x126cee0: r2 = _colors
    //     0x126cee0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26358] Field <_FABDefaultsM3@751192485._colors@751192485>: late final (offset: 0x68)
    //     0x126cee4: ldr             x2, [x2, #0x358]
    // 0x126cee8: r0 = InitLateFinalInstanceField()
    //     0x126cee8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126ceec: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x126ceec: ldur            w1, [x0, #0x17]
    // 0x126cef0: DecompressPointer r1
    //     0x126cef0: add             x1, x1, HEAP, lsl #32
    // 0x126cef4: cmp             w1, NULL
    // 0x126cef8: b.ne            #0x126cf04
    // 0x126cefc: LoadField: r1 = r0->field_f
    //     0x126cefc: ldur            w1, [x0, #0xf]
    // 0x126cf00: DecompressPointer r1
    //     0x126cf00: add             x1, x1, HEAP, lsl #32
    // 0x126cf04: d0 = 0.100000
    //     0x126cf04: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x126cf08: ldr             d0, [x17, #0x1e0]
    // 0x126cf0c: r0 = withOpacity()
    //     0x126cf0c: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x126cf10: mov             x3, x0
    // 0x126cf14: ldr             x0, [fp, #0x10]
    // 0x126cf18: b               #0x126cf34
    // 0x126cf1c: mov             x0, x2
    // 0x126cf20: LoadField: r1 = r0->field_63
    //     0x126cf20: ldur            w1, [x0, #0x63]
    // 0x126cf24: DecompressPointer r1
    //     0x126cf24: add             x1, x1, HEAP, lsl #32
    // 0x126cf28: LoadField: r2 = r1->field_73
    //     0x126cf28: ldur            w2, [x1, #0x73]
    // 0x126cf2c: DecompressPointer r2
    //     0x126cf2c: add             x2, x2, HEAP, lsl #32
    // 0x126cf30: mov             x3, x2
    // 0x126cf34: ldur            x2, [fp, #-0x10]
    // 0x126cf38: stur            x3, [fp, #-0x18]
    // 0x126cf3c: r17 = 5148
    //     0x126cf3c: mov             x17, #0x141c
    // 0x126cf40: cmp             x2, x17
    // 0x126cf44: b.ne            #0x126cf64
    // 0x126cf48: ldr             x4, [fp, #0x18]
    // 0x126cf4c: ArrayLoad: r1 = r4[0]  ; List_4
    //     0x126cf4c: ldur            w1, [x4, #0x17]
    // 0x126cf50: DecompressPointer r1
    //     0x126cf50: add             x1, x1, HEAP, lsl #32
    // 0x126cf54: mov             x2, x1
    // 0x126cf58: mov             x1, x4
    // 0x126cf5c: mov             x0, x3
    // 0x126cf60: b               #0x126cfe4
    // 0x126cf64: ldr             x4, [fp, #0x18]
    // 0x126cf68: r17 = 5149
    //     0x126cf68: mov             x17, #0x141d
    // 0x126cf6c: cmp             x2, x17
    // 0x126cf70: b.ne            #0x126cfcc
    // 0x126cf74: mov             x1, x4
    // 0x126cf78: LoadField: r0 = r1->field_67
    //     0x126cf78: ldur            w0, [x1, #0x67]
    // 0x126cf7c: DecompressPointer r0
    //     0x126cf7c: add             x0, x0, HEAP, lsl #32
    // 0x126cf80: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126cf84: cmp             w0, w16
    // 0x126cf88: b.ne            #0x126cf98
    // 0x126cf8c: r2 = _colors
    //     0x126cf8c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26358] Field <_FABDefaultsM3@751192485._colors@751192485>: late final (offset: 0x68)
    //     0x126cf90: ldr             x2, [x2, #0x358]
    // 0x126cf94: r0 = InitLateFinalInstanceField()
    //     0x126cf94: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126cf98: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x126cf98: ldur            w1, [x0, #0x17]
    // 0x126cf9c: DecompressPointer r1
    //     0x126cf9c: add             x1, x1, HEAP, lsl #32
    // 0x126cfa0: cmp             w1, NULL
    // 0x126cfa4: b.ne            #0x126cfb0
    // 0x126cfa8: LoadField: r1 = r0->field_f
    //     0x126cfa8: ldur            w1, [x0, #0xf]
    // 0x126cfac: DecompressPointer r1
    //     0x126cfac: add             x1, x1, HEAP, lsl #32
    // 0x126cfb0: d0 = 0.100000
    //     0x126cfb0: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x126cfb4: ldr             d0, [x17, #0x1e0]
    // 0x126cfb8: r0 = withOpacity()
    //     0x126cfb8: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x126cfbc: mov             x2, x0
    // 0x126cfc0: ldr             x1, [fp, #0x18]
    // 0x126cfc4: ldur            x0, [fp, #-0x18]
    // 0x126cfc8: b               #0x126cfe4
    // 0x126cfcc: mov             x1, x4
    // 0x126cfd0: LoadField: r0 = r1->field_63
    //     0x126cfd0: ldur            w0, [x1, #0x63]
    // 0x126cfd4: DecompressPointer r0
    //     0x126cfd4: add             x0, x0, HEAP, lsl #32
    // 0x126cfd8: LoadField: r2 = r0->field_73
    //     0x126cfd8: ldur            w2, [x0, #0x73]
    // 0x126cfdc: DecompressPointer r2
    //     0x126cfdc: add             x2, x2, HEAP, lsl #32
    // 0x126cfe0: ldur            x0, [fp, #-0x18]
    // 0x126cfe4: r3 = LoadClassIdInstr(r0)
    //     0x126cfe4: ldur            x3, [x0, #-1]
    //     0x126cfe8: ubfx            x3, x3, #0xc, #0x14
    // 0x126cfec: stp             x2, x0, [SP]
    // 0x126cff0: mov             x0, x3
    // 0x126cff4: mov             lr, x0
    // 0x126cff8: ldr             lr, [x21, lr, lsl #3]
    // 0x126cffc: blr             lr
    // 0x126d000: tbnz            w0, #4, #0x126d778
    // 0x126d004: ldr             x1, [fp, #0x18]
    // 0x126d008: ldr             x2, [fp, #0x10]
    // 0x126d00c: LoadField: r0 = r2->field_1b
    //     0x126d00c: ldur            w0, [x2, #0x1b]
    // 0x126d010: DecompressPointer r0
    //     0x126d010: add             x0, x0, HEAP, lsl #32
    // 0x126d014: LoadField: r3 = r1->field_1b
    //     0x126d014: ldur            w3, [x1, #0x1b]
    // 0x126d018: DecompressPointer r3
    //     0x126d018: add             x3, x3, HEAP, lsl #32
    // 0x126d01c: r4 = LoadClassIdInstr(r0)
    //     0x126d01c: ldur            x4, [x0, #-1]
    //     0x126d020: ubfx            x4, x4, #0xc, #0x14
    // 0x126d024: stp             x3, x0, [SP]
    // 0x126d028: mov             x0, x4
    // 0x126d02c: mov             lr, x0
    // 0x126d030: ldr             lr, [x21, lr, lsl #3]
    // 0x126d034: blr             lr
    // 0x126d038: tbnz            w0, #4, #0x126d778
    // 0x126d03c: ldr             x1, [fp, #0x18]
    // 0x126d040: ldr             x2, [fp, #0x10]
    // 0x126d044: LoadField: r0 = r2->field_1f
    //     0x126d044: ldur            w0, [x2, #0x1f]
    // 0x126d048: DecompressPointer r0
    //     0x126d048: add             x0, x0, HEAP, lsl #32
    // 0x126d04c: LoadField: r3 = r1->field_1f
    //     0x126d04c: ldur            w3, [x1, #0x1f]
    // 0x126d050: DecompressPointer r3
    //     0x126d050: add             x3, x3, HEAP, lsl #32
    // 0x126d054: r4 = LoadClassIdInstr(r0)
    //     0x126d054: ldur            x4, [x0, #-1]
    //     0x126d058: ubfx            x4, x4, #0xc, #0x14
    // 0x126d05c: stp             x3, x0, [SP]
    // 0x126d060: mov             x0, x4
    // 0x126d064: mov             lr, x0
    // 0x126d068: ldr             lr, [x21, lr, lsl #3]
    // 0x126d06c: blr             lr
    // 0x126d070: tbnz            w0, #4, #0x126d778
    // 0x126d074: ldr             x1, [fp, #0x18]
    // 0x126d078: ldr             x2, [fp, #0x10]
    // 0x126d07c: LoadField: r0 = r2->field_23
    //     0x126d07c: ldur            w0, [x2, #0x23]
    // 0x126d080: DecompressPointer r0
    //     0x126d080: add             x0, x0, HEAP, lsl #32
    // 0x126d084: LoadField: r3 = r1->field_23
    //     0x126d084: ldur            w3, [x1, #0x23]
    // 0x126d088: DecompressPointer r3
    //     0x126d088: add             x3, x3, HEAP, lsl #32
    // 0x126d08c: r4 = LoadClassIdInstr(r0)
    //     0x126d08c: ldur            x4, [x0, #-1]
    //     0x126d090: ubfx            x4, x4, #0xc, #0x14
    // 0x126d094: stp             x3, x0, [SP]
    // 0x126d098: mov             x0, x4
    // 0x126d09c: mov             lr, x0
    // 0x126d0a0: ldr             lr, [x21, lr, lsl #3]
    // 0x126d0a4: blr             lr
    // 0x126d0a8: tbnz            w0, #4, #0x126d778
    // 0x126d0ac: ldr             x1, [fp, #0x18]
    // 0x126d0b0: ldr             x2, [fp, #0x10]
    // 0x126d0b4: LoadField: r0 = r2->field_27
    //     0x126d0b4: ldur            w0, [x2, #0x27]
    // 0x126d0b8: DecompressPointer r0
    //     0x126d0b8: add             x0, x0, HEAP, lsl #32
    // 0x126d0bc: LoadField: r3 = r1->field_27
    //     0x126d0bc: ldur            w3, [x1, #0x27]
    // 0x126d0c0: DecompressPointer r3
    //     0x126d0c0: add             x3, x3, HEAP, lsl #32
    // 0x126d0c4: r4 = LoadClassIdInstr(r0)
    //     0x126d0c4: ldur            x4, [x0, #-1]
    //     0x126d0c8: ubfx            x4, x4, #0xc, #0x14
    // 0x126d0cc: stp             x3, x0, [SP]
    // 0x126d0d0: mov             x0, x4
    // 0x126d0d4: mov             lr, x0
    // 0x126d0d8: ldr             lr, [x21, lr, lsl #3]
    // 0x126d0dc: blr             lr
    // 0x126d0e0: tbnz            w0, #4, #0x126d778
    // 0x126d0e4: ldr             x1, [fp, #0x18]
    // 0x126d0e8: ldr             x2, [fp, #0x10]
    // 0x126d0ec: LoadField: r0 = r2->field_2b
    //     0x126d0ec: ldur            w0, [x2, #0x2b]
    // 0x126d0f0: DecompressPointer r0
    //     0x126d0f0: add             x0, x0, HEAP, lsl #32
    // 0x126d0f4: LoadField: r3 = r1->field_2b
    //     0x126d0f4: ldur            w3, [x1, #0x2b]
    // 0x126d0f8: DecompressPointer r3
    //     0x126d0f8: add             x3, x3, HEAP, lsl #32
    // 0x126d0fc: r4 = LoadClassIdInstr(r0)
    //     0x126d0fc: ldur            x4, [x0, #-1]
    //     0x126d100: ubfx            x4, x4, #0xc, #0x14
    // 0x126d104: stp             x3, x0, [SP]
    // 0x126d108: mov             x0, x4
    // 0x126d10c: mov             lr, x0
    // 0x126d110: ldr             lr, [x21, lr, lsl #3]
    // 0x126d114: blr             lr
    // 0x126d118: tbnz            w0, #4, #0x126d778
    // 0x126d11c: ldur            x1, [fp, #-8]
    // 0x126d120: r17 = 5148
    //     0x126d120: mov             x17, #0x141c
    // 0x126d124: cmp             x1, x17
    // 0x126d128: b.ne            #0x126d13c
    // 0x126d12c: ldr             x2, [fp, #0x10]
    // 0x126d130: LoadField: r0 = r2->field_2f
    //     0x126d130: ldur            w0, [x2, #0x2f]
    // 0x126d134: DecompressPointer r0
    //     0x126d134: add             x0, x0, HEAP, lsl #32
    // 0x126d138: b               #0x126d1a8
    // 0x126d13c: ldr             x2, [fp, #0x10]
    // 0x126d140: r17 = 5149
    //     0x126d140: mov             x17, #0x141d
    // 0x126d144: cmp             x1, x17
    // 0x126d148: b.ne            #0x126d1a0
    // 0x126d14c: LoadField: r0 = r2->field_5f
    //     0x126d14c: ldur            w0, [x2, #0x5f]
    // 0x126d150: DecompressPointer r0
    //     0x126d150: add             x0, x0, HEAP, lsl #32
    // 0x126d154: LoadField: r3 = r0->field_7
    //     0x126d154: ldur            x3, [x0, #7]
    // 0x126d158: cmp             x3, #1
    // 0x126d15c: b.gt            #0x126d180
    // 0x126d160: cmp             x3, #0
    // 0x126d164: b.gt            #0x126d174
    // 0x126d168: r0 = Instance_RoundedRectangleBorder
    //     0x126d168: add             x0, PP, #0x26, lsl #12  ; [pp+0x26360] Obj!RoundedRectangleBorder@129ec91
    //     0x126d16c: ldr             x0, [x0, #0x360]
    // 0x126d170: b               #0x126d1a8
    // 0x126d174: r0 = Instance_RoundedRectangleBorder
    //     0x126d174: add             x0, PP, #0x26, lsl #12  ; [pp+0x26368] Obj!RoundedRectangleBorder@129ec81
    //     0x126d178: ldr             x0, [x0, #0x368]
    // 0x126d17c: b               #0x126d1a8
    // 0x126d180: cmp             x3, #2
    // 0x126d184: b.gt            #0x126d194
    // 0x126d188: r0 = Instance_RoundedRectangleBorder
    //     0x126d188: add             x0, PP, #0x26, lsl #12  ; [pp+0x26370] Obj!RoundedRectangleBorder@129ec41
    //     0x126d18c: ldr             x0, [x0, #0x370]
    // 0x126d190: b               #0x126d1a8
    // 0x126d194: r0 = Instance_RoundedRectangleBorder
    //     0x126d194: add             x0, PP, #0x26, lsl #12  ; [pp+0x26360] Obj!RoundedRectangleBorder@129ec91
    //     0x126d198: ldr             x0, [x0, #0x360]
    // 0x126d19c: b               #0x126d1a8
    // 0x126d1a0: r0 = Instance_CircleBorder
    //     0x126d1a0: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c318] Obj!CircleBorder@129ebf1
    //     0x126d1a4: ldr             x0, [x0, #0x318]
    // 0x126d1a8: ldur            x3, [fp, #-0x10]
    // 0x126d1ac: r17 = 5148
    //     0x126d1ac: mov             x17, #0x141c
    // 0x126d1b0: cmp             x3, x17
    // 0x126d1b4: b.ne            #0x126d1c8
    // 0x126d1b8: ldr             x4, [fp, #0x18]
    // 0x126d1bc: LoadField: r5 = r4->field_2f
    //     0x126d1bc: ldur            w5, [x4, #0x2f]
    // 0x126d1c0: DecompressPointer r5
    //     0x126d1c0: add             x5, x5, HEAP, lsl #32
    // 0x126d1c4: b               #0x126d234
    // 0x126d1c8: ldr             x4, [fp, #0x18]
    // 0x126d1cc: r17 = 5149
    //     0x126d1cc: mov             x17, #0x141d
    // 0x126d1d0: cmp             x3, x17
    // 0x126d1d4: b.ne            #0x126d22c
    // 0x126d1d8: LoadField: r5 = r4->field_5f
    //     0x126d1d8: ldur            w5, [x4, #0x5f]
    // 0x126d1dc: DecompressPointer r5
    //     0x126d1dc: add             x5, x5, HEAP, lsl #32
    // 0x126d1e0: LoadField: r6 = r5->field_7
    //     0x126d1e0: ldur            x6, [x5, #7]
    // 0x126d1e4: cmp             x6, #1
    // 0x126d1e8: b.gt            #0x126d20c
    // 0x126d1ec: cmp             x6, #0
    // 0x126d1f0: b.gt            #0x126d200
    // 0x126d1f4: r5 = Instance_RoundedRectangleBorder
    //     0x126d1f4: add             x5, PP, #0x26, lsl #12  ; [pp+0x26360] Obj!RoundedRectangleBorder@129ec91
    //     0x126d1f8: ldr             x5, [x5, #0x360]
    // 0x126d1fc: b               #0x126d234
    // 0x126d200: r5 = Instance_RoundedRectangleBorder
    //     0x126d200: add             x5, PP, #0x26, lsl #12  ; [pp+0x26368] Obj!RoundedRectangleBorder@129ec81
    //     0x126d204: ldr             x5, [x5, #0x368]
    // 0x126d208: b               #0x126d234
    // 0x126d20c: cmp             x6, #2
    // 0x126d210: b.gt            #0x126d220
    // 0x126d214: r5 = Instance_RoundedRectangleBorder
    //     0x126d214: add             x5, PP, #0x26, lsl #12  ; [pp+0x26370] Obj!RoundedRectangleBorder@129ec41
    //     0x126d218: ldr             x5, [x5, #0x370]
    // 0x126d21c: b               #0x126d234
    // 0x126d220: r5 = Instance_RoundedRectangleBorder
    //     0x126d220: add             x5, PP, #0x26, lsl #12  ; [pp+0x26360] Obj!RoundedRectangleBorder@129ec91
    //     0x126d224: ldr             x5, [x5, #0x360]
    // 0x126d228: b               #0x126d234
    // 0x126d22c: r5 = Instance_CircleBorder
    //     0x126d22c: add             x5, PP, #0x1c, lsl #12  ; [pp+0x1c318] Obj!CircleBorder@129ebf1
    //     0x126d230: ldr             x5, [x5, #0x318]
    // 0x126d234: r6 = LoadClassIdInstr(r0)
    //     0x126d234: ldur            x6, [x0, #-1]
    //     0x126d238: ubfx            x6, x6, #0xc, #0x14
    // 0x126d23c: stp             x5, x0, [SP]
    // 0x126d240: mov             x0, x6
    // 0x126d244: mov             lr, x0
    // 0x126d248: ldr             lr, [x21, lr, lsl #3]
    // 0x126d24c: blr             lr
    // 0x126d250: tbnz            w0, #4, #0x126d778
    // 0x126d254: ldr             x2, [fp, #0x18]
    // 0x126d258: ldr             x1, [fp, #0x10]
    // 0x126d25c: LoadField: r0 = r1->field_33
    //     0x126d25c: ldur            w0, [x1, #0x33]
    // 0x126d260: DecompressPointer r0
    //     0x126d260: add             x0, x0, HEAP, lsl #32
    // 0x126d264: LoadField: r3 = r2->field_33
    //     0x126d264: ldur            w3, [x2, #0x33]
    // 0x126d268: DecompressPointer r3
    //     0x126d268: add             x3, x3, HEAP, lsl #32
    // 0x126d26c: cmp             w0, w3
    // 0x126d270: b.ne            #0x126d778
    // 0x126d274: ldur            x3, [fp, #-8]
    // 0x126d278: r17 = 5148
    //     0x126d278: mov             x17, #0x141c
    // 0x126d27c: cmp             x3, x17
    // 0x126d280: b.ne            #0x126d290
    // 0x126d284: LoadField: r0 = r1->field_37
    //     0x126d284: ldur            w0, [x1, #0x37]
    // 0x126d288: DecompressPointer r0
    //     0x126d288: add             x0, x0, HEAP, lsl #32
    // 0x126d28c: b               #0x126d318
    // 0x126d290: r17 = 5149
    //     0x126d290: mov             x17, #0x141d
    // 0x126d294: cmp             x3, x17
    // 0x126d298: b.ne            #0x126d310
    // 0x126d29c: LoadField: r0 = r1->field_5f
    //     0x126d29c: ldur            w0, [x1, #0x5f]
    // 0x126d2a0: DecompressPointer r0
    //     0x126d2a0: add             x0, x0, HEAP, lsl #32
    // 0x126d2a4: LoadField: r4 = r0->field_7
    //     0x126d2a4: ldur            x4, [x0, #7]
    // 0x126d2a8: cmp             x4, #1
    // 0x126d2ac: b.gt            #0x126d2c8
    // 0x126d2b0: cmp             x4, #0
    // 0x126d2b4: b.gt            #0x126d2c0
    // 0x126d2b8: d0 = 24.000000
    //     0x126d2b8: fmov            d0, #24.00000000
    // 0x126d2bc: b               #0x126d2e0
    // 0x126d2c0: d0 = 24.000000
    //     0x126d2c0: fmov            d0, #24.00000000
    // 0x126d2c4: b               #0x126d2e0
    // 0x126d2c8: cmp             x4, #2
    // 0x126d2cc: b.gt            #0x126d2dc
    // 0x126d2d0: d0 = 36.000000
    //     0x126d2d0: add             x17, PP, #0x12, lsl #12  ; [pp+0x12ca0] IMM: double(36) from 0x4042000000000000
    //     0x126d2d4: ldr             d0, [x17, #0xca0]
    // 0x126d2d8: b               #0x126d2e0
    // 0x126d2dc: d0 = 24.000000
    //     0x126d2dc: fmov            d0, #24.00000000
    // 0x126d2e0: r0 = inline_Allocate_Double()
    //     0x126d2e0: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0x126d2e4: add             x0, x0, #0x10
    //     0x126d2e8: cmp             x4, x0
    //     0x126d2ec: b.ls            #0x126d790
    //     0x126d2f0: str             x0, [THR, #0x60]  ; THR::top
    //     0x126d2f4: sub             x0, x0, #0xf
    //     0x126d2f8: mov             x4, #0xe19c
    //     0x126d2fc: movk            x4, #3, lsl #16
    //     0x126d300: stur            x4, [x0, #-1]
    // 0x126d304: dmb             ishst
    // 0x126d308: StoreField: r0->field_7 = d0
    //     0x126d308: stur            d0, [x0, #7]
    // 0x126d30c: b               #0x126d318
    // 0x126d310: r0 = 24.000000
    //     0x126d310: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0x126d314: ldr             x0, [x0, #0x4d0]
    // 0x126d318: ldur            x4, [fp, #-0x10]
    // 0x126d31c: r17 = 5148
    //     0x126d31c: mov             x17, #0x141c
    // 0x126d320: cmp             x4, x17
    // 0x126d324: b.ne            #0x126d334
    // 0x126d328: LoadField: r5 = r2->field_37
    //     0x126d328: ldur            w5, [x2, #0x37]
    // 0x126d32c: DecompressPointer r5
    //     0x126d32c: add             x5, x5, HEAP, lsl #32
    // 0x126d330: b               #0x126d3bc
    // 0x126d334: r17 = 5149
    //     0x126d334: mov             x17, #0x141d
    // 0x126d338: cmp             x4, x17
    // 0x126d33c: b.ne            #0x126d3b4
    // 0x126d340: LoadField: r5 = r2->field_5f
    //     0x126d340: ldur            w5, [x2, #0x5f]
    // 0x126d344: DecompressPointer r5
    //     0x126d344: add             x5, x5, HEAP, lsl #32
    // 0x126d348: LoadField: r6 = r5->field_7
    //     0x126d348: ldur            x6, [x5, #7]
    // 0x126d34c: cmp             x6, #1
    // 0x126d350: b.gt            #0x126d36c
    // 0x126d354: cmp             x6, #0
    // 0x126d358: b.gt            #0x126d364
    // 0x126d35c: d0 = 24.000000
    //     0x126d35c: fmov            d0, #24.00000000
    // 0x126d360: b               #0x126d384
    // 0x126d364: d0 = 24.000000
    //     0x126d364: fmov            d0, #24.00000000
    // 0x126d368: b               #0x126d384
    // 0x126d36c: cmp             x6, #2
    // 0x126d370: b.gt            #0x126d380
    // 0x126d374: d0 = 36.000000
    //     0x126d374: add             x17, PP, #0x12, lsl #12  ; [pp+0x12ca0] IMM: double(36) from 0x4042000000000000
    //     0x126d378: ldr             d0, [x17, #0xca0]
    // 0x126d37c: b               #0x126d384
    // 0x126d380: d0 = 24.000000
    //     0x126d380: fmov            d0, #24.00000000
    // 0x126d384: r5 = inline_Allocate_Double()
    //     0x126d384: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0x126d388: add             x5, x5, #0x10
    //     0x126d38c: cmp             x6, x5
    //     0x126d390: b.ls            #0x126d7b0
    //     0x126d394: str             x5, [THR, #0x60]  ; THR::top
    //     0x126d398: sub             x5, x5, #0xf
    //     0x126d39c: mov             x6, #0xe19c
    //     0x126d3a0: movk            x6, #3, lsl #16
    //     0x126d3a4: stur            x6, [x5, #-1]
    // 0x126d3a8: dmb             ishst
    // 0x126d3ac: StoreField: r5->field_7 = d0
    //     0x126d3ac: stur            d0, [x5, #7]
    // 0x126d3b0: b               #0x126d3bc
    // 0x126d3b4: r5 = 24.000000
    //     0x126d3b4: add             x5, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0x126d3b8: ldr             x5, [x5, #0x4d0]
    // 0x126d3bc: r6 = LoadClassIdInstr(r0)
    //     0x126d3bc: ldur            x6, [x0, #-1]
    //     0x126d3c0: ubfx            x6, x6, #0xc, #0x14
    // 0x126d3c4: stp             x5, x0, [SP]
    // 0x126d3c8: mov             x0, x6
    // 0x126d3cc: mov             lr, x0
    // 0x126d3d0: ldr             lr, [x21, lr, lsl #3]
    // 0x126d3d4: blr             lr
    // 0x126d3d8: tbnz            w0, #4, #0x126d778
    // 0x126d3dc: ldr             x2, [fp, #0x18]
    // 0x126d3e0: ldr             x1, [fp, #0x10]
    // 0x126d3e4: LoadField: r0 = r1->field_3b
    //     0x126d3e4: ldur            w0, [x1, #0x3b]
    // 0x126d3e8: DecompressPointer r0
    //     0x126d3e8: add             x0, x0, HEAP, lsl #32
    // 0x126d3ec: LoadField: r3 = r2->field_3b
    //     0x126d3ec: ldur            w3, [x2, #0x3b]
    // 0x126d3f0: DecompressPointer r3
    //     0x126d3f0: add             x3, x3, HEAP, lsl #32
    // 0x126d3f4: r4 = LoadClassIdInstr(r0)
    //     0x126d3f4: ldur            x4, [x0, #-1]
    //     0x126d3f8: ubfx            x4, x4, #0xc, #0x14
    // 0x126d3fc: stp             x3, x0, [SP]
    // 0x126d400: mov             x0, x4
    // 0x126d404: mov             lr, x0
    // 0x126d408: ldr             lr, [x21, lr, lsl #3]
    // 0x126d40c: blr             lr
    // 0x126d410: tbnz            w0, #4, #0x126d778
    // 0x126d414: ldr             x2, [fp, #0x18]
    // 0x126d418: ldr             x1, [fp, #0x10]
    // 0x126d41c: LoadField: r0 = r1->field_3f
    //     0x126d41c: ldur            w0, [x1, #0x3f]
    // 0x126d420: DecompressPointer r0
    //     0x126d420: add             x0, x0, HEAP, lsl #32
    // 0x126d424: LoadField: r3 = r2->field_3f
    //     0x126d424: ldur            w3, [x2, #0x3f]
    // 0x126d428: DecompressPointer r3
    //     0x126d428: add             x3, x3, HEAP, lsl #32
    // 0x126d42c: r4 = LoadClassIdInstr(r0)
    //     0x126d42c: ldur            x4, [x0, #-1]
    //     0x126d430: ubfx            x4, x4, #0xc, #0x14
    // 0x126d434: stp             x3, x0, [SP]
    // 0x126d438: mov             x0, x4
    // 0x126d43c: mov             lr, x0
    // 0x126d440: ldr             lr, [x21, lr, lsl #3]
    // 0x126d444: blr             lr
    // 0x126d448: tbnz            w0, #4, #0x126d778
    // 0x126d44c: ldr             x2, [fp, #0x18]
    // 0x126d450: ldr             x1, [fp, #0x10]
    // 0x126d454: LoadField: r0 = r1->field_43
    //     0x126d454: ldur            w0, [x1, #0x43]
    // 0x126d458: DecompressPointer r0
    //     0x126d458: add             x0, x0, HEAP, lsl #32
    // 0x126d45c: LoadField: r3 = r2->field_43
    //     0x126d45c: ldur            w3, [x2, #0x43]
    // 0x126d460: DecompressPointer r3
    //     0x126d460: add             x3, x3, HEAP, lsl #32
    // 0x126d464: r4 = LoadClassIdInstr(r0)
    //     0x126d464: ldur            x4, [x0, #-1]
    //     0x126d468: ubfx            x4, x4, #0xc, #0x14
    // 0x126d46c: stp             x3, x0, [SP]
    // 0x126d470: mov             x0, x4
    // 0x126d474: mov             lr, x0
    // 0x126d478: ldr             lr, [x21, lr, lsl #3]
    // 0x126d47c: blr             lr
    // 0x126d480: tbnz            w0, #4, #0x126d778
    // 0x126d484: ldr             x2, [fp, #0x18]
    // 0x126d488: ldr             x1, [fp, #0x10]
    // 0x126d48c: LoadField: r0 = r1->field_47
    //     0x126d48c: ldur            w0, [x1, #0x47]
    // 0x126d490: DecompressPointer r0
    //     0x126d490: add             x0, x0, HEAP, lsl #32
    // 0x126d494: LoadField: r3 = r2->field_47
    //     0x126d494: ldur            w3, [x2, #0x47]
    // 0x126d498: DecompressPointer r3
    //     0x126d498: add             x3, x3, HEAP, lsl #32
    // 0x126d49c: r4 = LoadClassIdInstr(r0)
    //     0x126d49c: ldur            x4, [x0, #-1]
    //     0x126d4a0: ubfx            x4, x4, #0xc, #0x14
    // 0x126d4a4: stp             x3, x0, [SP]
    // 0x126d4a8: mov             x0, x4
    // 0x126d4ac: mov             lr, x0
    // 0x126d4b0: ldr             lr, [x21, lr, lsl #3]
    // 0x126d4b4: blr             lr
    // 0x126d4b8: tbnz            w0, #4, #0x126d778
    // 0x126d4bc: ldr             x2, [fp, #0x18]
    // 0x126d4c0: ldr             x1, [fp, #0x10]
    // 0x126d4c4: LoadField: r0 = r1->field_4b
    //     0x126d4c4: ldur            w0, [x1, #0x4b]
    // 0x126d4c8: DecompressPointer r0
    //     0x126d4c8: add             x0, x0, HEAP, lsl #32
    // 0x126d4cc: LoadField: r3 = r2->field_4b
    //     0x126d4cc: ldur            w3, [x2, #0x4b]
    // 0x126d4d0: DecompressPointer r3
    //     0x126d4d0: add             x3, x3, HEAP, lsl #32
    // 0x126d4d4: r4 = LoadClassIdInstr(r0)
    //     0x126d4d4: ldur            x4, [x0, #-1]
    //     0x126d4d8: ubfx            x4, x4, #0xc, #0x14
    // 0x126d4dc: stp             x3, x0, [SP]
    // 0x126d4e0: mov             x0, x4
    // 0x126d4e4: mov             lr, x0
    // 0x126d4e8: ldr             lr, [x21, lr, lsl #3]
    // 0x126d4ec: blr             lr
    // 0x126d4f0: tbnz            w0, #4, #0x126d778
    // 0x126d4f4: ldur            x0, [fp, #-8]
    // 0x126d4f8: r17 = 5148
    //     0x126d4f8: mov             x17, #0x141c
    // 0x126d4fc: cmp             x0, x17
    // 0x126d500: b.ne            #0x126d51c
    // 0x126d504: ldr             x1, [fp, #0x10]
    // 0x126d508: LoadField: r2 = r1->field_4f
    //     0x126d508: ldur            w2, [x1, #0x4f]
    // 0x126d50c: DecompressPointer r2
    //     0x126d50c: add             x2, x2, HEAP, lsl #32
    // 0x126d510: mov             x1, x2
    // 0x126d514: d0 = 20.000000
    //     0x126d514: fmov            d0, #20.00000000
    // 0x126d518: b               #0x126d56c
    // 0x126d51c: ldr             x1, [fp, #0x10]
    // 0x126d520: r17 = 5149
    //     0x126d520: mov             x17, #0x141d
    // 0x126d524: cmp             x0, x17
    // 0x126d528: b.ne            #0x126d54c
    // 0x126d52c: r0 = EdgeInsetsDirectional()
    //     0x126d52c: bl              #0xb50060  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0x126d530: d0 = 20.000000
    //     0x126d530: fmov            d0, #20.00000000
    // 0x126d534: StoreField: r0->field_7 = d0
    //     0x126d534: stur            d0, [x0, #7]
    // 0x126d538: StoreField: r0->field_f = rZR
    //     0x126d538: stur            xzr, [x0, #0xf]
    // 0x126d53c: ArrayStore: r0[0] = d0  ; List_8
    //     0x126d53c: stur            d0, [x0, #0x17]
    // 0x126d540: StoreField: r0->field_1f = rZR
    //     0x126d540: stur            xzr, [x0, #0x1f]
    // 0x126d544: mov             x1, x0
    // 0x126d548: b               #0x126d56c
    // 0x126d54c: d0 = 20.000000
    //     0x126d54c: fmov            d0, #20.00000000
    // 0x126d550: r0 = EdgeInsetsDirectional()
    //     0x126d550: bl              #0xb50060  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0x126d554: d0 = 20.000000
    //     0x126d554: fmov            d0, #20.00000000
    // 0x126d558: StoreField: r0->field_7 = d0
    //     0x126d558: stur            d0, [x0, #7]
    // 0x126d55c: StoreField: r0->field_f = rZR
    //     0x126d55c: stur            xzr, [x0, #0xf]
    // 0x126d560: ArrayStore: r0[0] = d0  ; List_8
    //     0x126d560: stur            d0, [x0, #0x17]
    // 0x126d564: StoreField: r0->field_1f = rZR
    //     0x126d564: stur            xzr, [x0, #0x1f]
    // 0x126d568: mov             x1, x0
    // 0x126d56c: ldur            x0, [fp, #-0x10]
    // 0x126d570: stur            x1, [fp, #-0x18]
    // 0x126d574: r17 = 5148
    //     0x126d574: mov             x17, #0x141c
    // 0x126d578: cmp             x0, x17
    // 0x126d57c: b.ne            #0x126d598
    // 0x126d580: ldr             x2, [fp, #0x18]
    // 0x126d584: LoadField: r3 = r2->field_4f
    //     0x126d584: ldur            w3, [x2, #0x4f]
    // 0x126d588: DecompressPointer r3
    //     0x126d588: add             x3, x3, HEAP, lsl #32
    // 0x126d58c: mov             x0, x1
    // 0x126d590: mov             x1, x3
    // 0x126d594: b               #0x126d5ec
    // 0x126d598: ldr             x2, [fp, #0x18]
    // 0x126d59c: r17 = 5149
    //     0x126d59c: mov             x17, #0x141d
    // 0x126d5a0: cmp             x0, x17
    // 0x126d5a4: b.ne            #0x126d5cc
    // 0x126d5a8: r0 = EdgeInsetsDirectional()
    //     0x126d5a8: bl              #0xb50060  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0x126d5ac: d0 = 20.000000
    //     0x126d5ac: fmov            d0, #20.00000000
    // 0x126d5b0: StoreField: r0->field_7 = d0
    //     0x126d5b0: stur            d0, [x0, #7]
    // 0x126d5b4: StoreField: r0->field_f = rZR
    //     0x126d5b4: stur            xzr, [x0, #0xf]
    // 0x126d5b8: ArrayStore: r0[0] = d0  ; List_8
    //     0x126d5b8: stur            d0, [x0, #0x17]
    // 0x126d5bc: StoreField: r0->field_1f = rZR
    //     0x126d5bc: stur            xzr, [x0, #0x1f]
    // 0x126d5c0: mov             x1, x0
    // 0x126d5c4: ldur            x0, [fp, #-0x18]
    // 0x126d5c8: b               #0x126d5ec
    // 0x126d5cc: r0 = EdgeInsetsDirectional()
    //     0x126d5cc: bl              #0xb50060  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0x126d5d0: d0 = 20.000000
    //     0x126d5d0: fmov            d0, #20.00000000
    // 0x126d5d4: StoreField: r0->field_7 = d0
    //     0x126d5d4: stur            d0, [x0, #7]
    // 0x126d5d8: StoreField: r0->field_f = rZR
    //     0x126d5d8: stur            xzr, [x0, #0xf]
    // 0x126d5dc: ArrayStore: r0[0] = d0  ; List_8
    //     0x126d5dc: stur            d0, [x0, #0x17]
    // 0x126d5e0: StoreField: r0->field_1f = rZR
    //     0x126d5e0: stur            xzr, [x0, #0x1f]
    // 0x126d5e4: mov             x1, x0
    // 0x126d5e8: ldur            x0, [fp, #-0x18]
    // 0x126d5ec: r2 = LoadClassIdInstr(r0)
    //     0x126d5ec: ldur            x2, [x0, #-1]
    //     0x126d5f0: ubfx            x2, x2, #0xc, #0x14
    // 0x126d5f4: stp             x1, x0, [SP]
    // 0x126d5f8: mov             x0, x2
    // 0x126d5fc: mov             lr, x0
    // 0x126d600: ldr             lr, [x21, lr, lsl #3]
    // 0x126d604: blr             lr
    // 0x126d608: tbnz            w0, #4, #0x126d778
    // 0x126d60c: ldur            x0, [fp, #-8]
    // 0x126d610: r17 = 5148
    //     0x126d610: mov             x17, #0x141c
    // 0x126d614: cmp             x0, x17
    // 0x126d618: b.ne            #0x126d630
    // 0x126d61c: ldr             x1, [fp, #0x10]
    // 0x126d620: LoadField: r0 = r1->field_53
    //     0x126d620: ldur            w0, [x1, #0x53]
    // 0x126d624: DecompressPointer r0
    //     0x126d624: add             x0, x0, HEAP, lsl #32
    // 0x126d628: mov             x2, x0
    // 0x126d62c: b               #0x126d6a8
    // 0x126d630: ldr             x1, [fp, #0x10]
    // 0x126d634: r17 = 5149
    //     0x126d634: mov             x17, #0x141d
    // 0x126d638: cmp             x0, x17
    // 0x126d63c: b.ne            #0x126d670
    // 0x126d640: LoadField: r0 = r1->field_6b
    //     0x126d640: ldur            w0, [x1, #0x6b]
    // 0x126d644: DecompressPointer r0
    //     0x126d644: add             x0, x0, HEAP, lsl #32
    // 0x126d648: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126d64c: cmp             w0, w16
    // 0x126d650: b.ne            #0x126d660
    // 0x126d654: r2 = _textTheme
    //     0x126d654: add             x2, PP, #0x26, lsl #12  ; [pp+0x26378] Field <_FABDefaultsM3@751192485._textTheme@751192485>: late final (offset: 0x6c)
    //     0x126d658: ldr             x2, [x2, #0x378]
    // 0x126d65c: r0 = InitLateFinalInstanceField()
    //     0x126d65c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126d660: LoadField: r1 = r0->field_37
    //     0x126d660: ldur            w1, [x0, #0x37]
    // 0x126d664: DecompressPointer r1
    //     0x126d664: add             x1, x1, HEAP, lsl #32
    // 0x126d668: mov             x2, x1
    // 0x126d66c: b               #0x126d6a8
    // 0x126d670: LoadField: r0 = r1->field_63
    //     0x126d670: ldur            w0, [x1, #0x63]
    // 0x126d674: DecompressPointer r0
    //     0x126d674: add             x0, x0, HEAP, lsl #32
    // 0x126d678: LoadField: r1 = r0->field_87
    //     0x126d678: ldur            w1, [x0, #0x87]
    // 0x126d67c: DecompressPointer r1
    //     0x126d67c: add             x1, x1, HEAP, lsl #32
    // 0x126d680: LoadField: r0 = r1->field_37
    //     0x126d680: ldur            w0, [x1, #0x37]
    // 0x126d684: DecompressPointer r0
    //     0x126d684: add             x0, x0, HEAP, lsl #32
    // 0x126d688: r16 = 1.200000
    //     0x126d688: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1ac08] 1.2
    //     0x126d68c: ldr             x16, [x16, #0xc08]
    // 0x126d690: str             x16, [SP]
    // 0x126d694: mov             x1, x0
    // 0x126d698: r4 = const [0, 0x2, 0x1, 0x1, letterSpacing, 0x1, null]
    //     0x126d698: add             x4, PP, #0x26, lsl #12  ; [pp+0x26380] List(7) [0, 0x2, 0x1, 0x1, "letterSpacing", 0x1, Null]
    //     0x126d69c: ldr             x4, [x4, #0x380]
    // 0x126d6a0: r0 = copyWith()
    //     0x126d6a0: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x126d6a4: mov             x2, x0
    // 0x126d6a8: ldur            x0, [fp, #-0x10]
    // 0x126d6ac: stur            x2, [fp, #-0x18]
    // 0x126d6b0: r17 = 5148
    //     0x126d6b0: mov             x17, #0x141c
    // 0x126d6b4: cmp             x0, x17
    // 0x126d6b8: b.ne            #0x126d6d4
    // 0x126d6bc: ldr             x1, [fp, #0x18]
    // 0x126d6c0: LoadField: r0 = r1->field_53
    //     0x126d6c0: ldur            w0, [x1, #0x53]
    // 0x126d6c4: DecompressPointer r0
    //     0x126d6c4: add             x0, x0, HEAP, lsl #32
    // 0x126d6c8: mov             x1, x0
    // 0x126d6cc: mov             x0, x2
    // 0x126d6d0: b               #0x126d750
    // 0x126d6d4: ldr             x1, [fp, #0x18]
    // 0x126d6d8: r17 = 5149
    //     0x126d6d8: mov             x17, #0x141d
    // 0x126d6dc: cmp             x0, x17
    // 0x126d6e0: b.ne            #0x126d714
    // 0x126d6e4: LoadField: r0 = r1->field_6b
    //     0x126d6e4: ldur            w0, [x1, #0x6b]
    // 0x126d6e8: DecompressPointer r0
    //     0x126d6e8: add             x0, x0, HEAP, lsl #32
    // 0x126d6ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126d6f0: cmp             w0, w16
    // 0x126d6f4: b.ne            #0x126d704
    // 0x126d6f8: r2 = _textTheme
    //     0x126d6f8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26378] Field <_FABDefaultsM3@751192485._textTheme@751192485>: late final (offset: 0x6c)
    //     0x126d6fc: ldr             x2, [x2, #0x378]
    // 0x126d700: r0 = InitLateFinalInstanceField()
    //     0x126d700: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126d704: LoadField: r1 = r0->field_37
    //     0x126d704: ldur            w1, [x0, #0x37]
    // 0x126d708: DecompressPointer r1
    //     0x126d708: add             x1, x1, HEAP, lsl #32
    // 0x126d70c: ldur            x0, [fp, #-0x18]
    // 0x126d710: b               #0x126d750
    // 0x126d714: LoadField: r0 = r1->field_63
    //     0x126d714: ldur            w0, [x1, #0x63]
    // 0x126d718: DecompressPointer r0
    //     0x126d718: add             x0, x0, HEAP, lsl #32
    // 0x126d71c: LoadField: r1 = r0->field_87
    //     0x126d71c: ldur            w1, [x0, #0x87]
    // 0x126d720: DecompressPointer r1
    //     0x126d720: add             x1, x1, HEAP, lsl #32
    // 0x126d724: LoadField: r0 = r1->field_37
    //     0x126d724: ldur            w0, [x1, #0x37]
    // 0x126d728: DecompressPointer r0
    //     0x126d728: add             x0, x0, HEAP, lsl #32
    // 0x126d72c: r16 = 1.200000
    //     0x126d72c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1ac08] 1.2
    //     0x126d730: ldr             x16, [x16, #0xc08]
    // 0x126d734: str             x16, [SP]
    // 0x126d738: mov             x1, x0
    // 0x126d73c: r4 = const [0, 0x2, 0x1, 0x1, letterSpacing, 0x1, null]
    //     0x126d73c: add             x4, PP, #0x26, lsl #12  ; [pp+0x26380] List(7) [0, 0x2, 0x1, 0x1, "letterSpacing", 0x1, Null]
    //     0x126d740: ldr             x4, [x4, #0x380]
    // 0x126d744: r0 = copyWith()
    //     0x126d744: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x126d748: mov             x1, x0
    // 0x126d74c: ldur            x0, [fp, #-0x18]
    // 0x126d750: r2 = LoadClassIdInstr(r0)
    //     0x126d750: ldur            x2, [x0, #-1]
    //     0x126d754: ubfx            x2, x2, #0xc, #0x14
    // 0x126d758: stp             x1, x0, [SP]
    // 0x126d75c: mov             x0, x2
    // 0x126d760: mov             lr, x0
    // 0x126d764: ldr             lr, [x21, lr, lsl #3]
    // 0x126d768: blr             lr
    // 0x126d76c: tbnz            w0, #4, #0x126d778
    // 0x126d770: r0 = true
    //     0x126d770: add             x0, NULL, #0x20  ; true
    // 0x126d774: b               #0x126d77c
    // 0x126d778: r0 = false
    //     0x126d778: add             x0, NULL, #0x30  ; false
    // 0x126d77c: LeaveFrame
    //     0x126d77c: mov             SP, fp
    //     0x126d780: ldp             fp, lr, [SP], #0x10
    // 0x126d784: ret
    //     0x126d784: ret             
    // 0x126d788: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x126d788: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x126d78c: b               #0x126c850
    // 0x126d790: SaveReg d0
    //     0x126d790: str             q0, [SP, #-0x10]!
    // 0x126d794: stp             x2, x3, [SP, #-0x10]!
    // 0x126d798: SaveReg r1
    //     0x126d798: str             x1, [SP, #-8]!
    // 0x126d79c: r0 = AllocateDouble()
    //     0x126d79c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x126d7a0: RestoreReg r1
    //     0x126d7a0: ldr             x1, [SP], #8
    // 0x126d7a4: ldp             x2, x3, [SP], #0x10
    // 0x126d7a8: RestoreReg d0
    //     0x126d7a8: ldr             q0, [SP], #0x10
    // 0x126d7ac: b               #0x126d308
    // 0x126d7b0: SaveReg d0
    //     0x126d7b0: str             q0, [SP, #-0x10]!
    // 0x126d7b4: stp             x3, x4, [SP, #-0x10]!
    // 0x126d7b8: stp             x1, x2, [SP, #-0x10]!
    // 0x126d7bc: SaveReg r0
    //     0x126d7bc: str             x0, [SP, #-8]!
    // 0x126d7c0: r0 = AllocateDouble()
    //     0x126d7c0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x126d7c4: mov             x5, x0
    // 0x126d7c8: RestoreReg r0
    //     0x126d7c8: ldr             x0, [SP], #8
    // 0x126d7cc: ldp             x1, x2, [SP], #0x10
    // 0x126d7d0: ldp             x3, x4, [SP], #0x10
    // 0x126d7d4: RestoreReg d0
    //     0x126d7d4: ldr             q0, [SP], #0x10
    // 0x126d7d8: b               #0x126d3ac
  }
}

// class id: 6845, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class FloatingActionButtonTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xfbb1dc, size: 0x58
    // 0xfbb1dc: EnterFrame
    //     0xfbb1dc: stp             fp, lr, [SP, #-0x10]!
    //     0xfbb1e0: mov             fp, SP
    // 0xfbb1e4: AllocStack(0x18)
    //     0xfbb1e4: sub             SP, SP, #0x18
    // 0xfbb1e8: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xfbb1e8: stur            x1, [fp, #-8]
    // 0xfbb1ec: CheckStackOverflow
    //     0xfbb1ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbb1f0: cmp             SP, x16
    //     0xfbb1f4: b.ls            #0xfbb22c
    // 0xfbb1f8: r16 = <FloatingActionButtonTheme>
    //     0xfbb1f8: add             x16, PP, #0x80, lsl #12  ; [pp+0x80990] TypeArguments: <FloatingActionButtonTheme>
    //     0xfbb1fc: ldr             x16, [x16, #0x990]
    // 0xfbb200: stp             x1, x16, [SP]
    // 0xfbb204: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xfbb204: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xfbb208: r0 = dependOnInheritedWidgetOfExactType()
    //     0xfbb208: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xfbb20c: ldur            x1, [fp, #-8]
    // 0xfbb210: r0 = of()
    //     0xfbb210: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfbb214: LoadField: r1 = r0->field_e3
    //     0xfbb214: ldur            w1, [x0, #0xe3]
    // 0xfbb218: DecompressPointer r1
    //     0xfbb218: add             x1, x1, HEAP, lsl #32
    // 0xfbb21c: mov             x0, x1
    // 0xfbb220: LeaveFrame
    //     0xfbb220: mov             SP, fp
    //     0xfbb224: ldp             fp, lr, [SP], #0x10
    // 0xfbb228: ret
    //     0xfbb228: ret             
    // 0xfbb22c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbb22c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbb230: b               #0xfbb1f8
  }
}
