// lib: , url: package:flutter/src/material/bottom_sheet_theme.dart

// class id: 1048854, size: 0x8
class :: {
}

// class id: 5201, size: 0x3c, field offset: 0x8
//   const constructor, 
class BottomSheetThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x112effc, size: 0x230
    // 0x112effc: EnterFrame
    //     0x112effc: stp             fp, lr, [SP, #-0x10]!
    //     0x112f000: mov             fp, SP
    // 0x112f004: AllocStack(0x90)
    //     0x112f004: sub             SP, SP, #0x90
    // 0x112f008: CheckStackOverflow
    //     0x112f008: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112f00c: cmp             SP, x16
    //     0x112f010: b.ls            #0x112f224
    // 0x112f014: ldr             x0, [fp, #0x10]
    // 0x112f018: r2 = LoadClassIdInstr(r0)
    //     0x112f018: ldur            x2, [x0, #-1]
    //     0x112f01c: ubfx            x2, x2, #0xc, #0x14
    // 0x112f020: stur            x2, [fp, #-8]
    // 0x112f024: r17 = 5201
    //     0x112f024: mov             x17, #0x1451
    // 0x112f028: cmp             x2, x17
    // 0x112f02c: b.ne            #0x112f044
    // 0x112f030: LoadField: r1 = r0->field_7
    //     0x112f030: ldur            w1, [x0, #7]
    // 0x112f034: DecompressPointer r1
    //     0x112f034: add             x1, x1, HEAP, lsl #32
    // 0x112f038: mov             x0, x2
    // 0x112f03c: mov             x2, x1
    // 0x112f040: b               #0x112f094
    // 0x112f044: mov             x1, x0
    // 0x112f048: LoadField: r0 = r1->field_3f
    //     0x112f048: ldur            w0, [x1, #0x3f]
    // 0x112f04c: DecompressPointer r0
    //     0x112f04c: add             x0, x0, HEAP, lsl #32
    // 0x112f050: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x112f054: cmp             w0, w16
    // 0x112f058: b.ne            #0x112f068
    // 0x112f05c: r2 = _colors
    //     0x112f05c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26550] Field <_BottomSheetDefaultsM3@726001611._colors@726001611>: late final (offset: 0x40)
    //     0x112f060: ldr             x2, [x2, #0x550]
    // 0x112f064: r0 = InitLateFinalInstanceField()
    //     0x112f064: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x112f068: LoadField: r1 = r0->field_93
    //     0x112f068: ldur            w1, [x0, #0x93]
    // 0x112f06c: DecompressPointer r1
    //     0x112f06c: add             x1, x1, HEAP, lsl #32
    // 0x112f070: cmp             w1, NULL
    // 0x112f074: b.ne            #0x112f088
    // 0x112f078: LoadField: r1 = r0->field_7b
    //     0x112f078: ldur            w1, [x0, #0x7b]
    // 0x112f07c: DecompressPointer r1
    //     0x112f07c: add             x1, x1, HEAP, lsl #32
    // 0x112f080: mov             x0, x1
    // 0x112f084: b               #0x112f08c
    // 0x112f088: mov             x0, x1
    // 0x112f08c: mov             x2, x0
    // 0x112f090: ldur            x0, [fp, #-8]
    // 0x112f094: stur            x2, [fp, #-0x38]
    // 0x112f098: r17 = 5201
    //     0x112f098: mov             x17, #0x1451
    // 0x112f09c: cmp             x0, x17
    // 0x112f0a0: b.ne            #0x112f0b8
    // 0x112f0a4: ldr             x3, [fp, #0x10]
    // 0x112f0a8: LoadField: r1 = r3->field_b
    //     0x112f0a8: ldur            w1, [x3, #0xb]
    // 0x112f0ac: DecompressPointer r1
    //     0x112f0ac: add             x1, x1, HEAP, lsl #32
    // 0x112f0b0: mov             x4, x1
    // 0x112f0b4: b               #0x112f0c4
    // 0x112f0b8: ldr             x3, [fp, #0x10]
    // 0x112f0bc: r4 = Instance_Color
    //     0x112f0bc: add             x4, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x112f0c0: ldr             x4, [x4, #0x810]
    // 0x112f0c4: stur            x4, [fp, #-0x30]
    // 0x112f0c8: LoadField: r5 = r3->field_f
    //     0x112f0c8: ldur            w5, [x3, #0xf]
    // 0x112f0cc: DecompressPointer r5
    //     0x112f0cc: add             x5, x5, HEAP, lsl #32
    // 0x112f0d0: stur            x5, [fp, #-0x28]
    // 0x112f0d4: r17 = 5201
    //     0x112f0d4: mov             x17, #0x1451
    // 0x112f0d8: cmp             x0, x17
    // 0x112f0dc: b.ne            #0x112f0f0
    // 0x112f0e0: LoadField: r1 = r3->field_1b
    //     0x112f0e0: ldur            w1, [x3, #0x1b]
    // 0x112f0e4: DecompressPointer r1
    //     0x112f0e4: add             x1, x1, HEAP, lsl #32
    // 0x112f0e8: mov             x6, x1
    // 0x112f0ec: b               #0x112f0f8
    // 0x112f0f0: r6 = Instance_Color
    //     0x112f0f0: add             x6, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x112f0f4: ldr             x6, [x6, #0x810]
    // 0x112f0f8: stur            x6, [fp, #-0x20]
    // 0x112f0fc: LoadField: r7 = r3->field_1f
    //     0x112f0fc: ldur            w7, [x3, #0x1f]
    // 0x112f100: DecompressPointer r7
    //     0x112f100: add             x7, x7, HEAP, lsl #32
    // 0x112f104: stur            x7, [fp, #-0x18]
    // 0x112f108: LoadField: r8 = r3->field_23
    //     0x112f108: ldur            w8, [x3, #0x23]
    // 0x112f10c: DecompressPointer r8
    //     0x112f10c: add             x8, x8, HEAP, lsl #32
    // 0x112f110: stur            x8, [fp, #-0x10]
    // 0x112f114: r17 = 5201
    //     0x112f114: mov             x17, #0x1451
    // 0x112f118: cmp             x0, x17
    // 0x112f11c: b.ne            #0x112f12c
    // 0x112f120: LoadField: r1 = r3->field_2b
    //     0x112f120: ldur            w1, [x3, #0x2b]
    // 0x112f124: DecompressPointer r1
    //     0x112f124: add             x1, x1, HEAP, lsl #32
    // 0x112f128: b               #0x112f17c
    // 0x112f12c: mov             x1, x3
    // 0x112f130: LoadField: r0 = r1->field_3f
    //     0x112f130: ldur            w0, [x1, #0x3f]
    // 0x112f134: DecompressPointer r0
    //     0x112f134: add             x0, x0, HEAP, lsl #32
    // 0x112f138: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x112f13c: cmp             w0, w16
    // 0x112f140: b.ne            #0x112f150
    // 0x112f144: r2 = _colors
    //     0x112f144: add             x2, PP, #0x26, lsl #12  ; [pp+0x26550] Field <_BottomSheetDefaultsM3@726001611._colors@726001611>: late final (offset: 0x40)
    //     0x112f148: ldr             x2, [x2, #0x550]
    // 0x112f14c: r0 = InitLateFinalInstanceField()
    //     0x112f14c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x112f150: LoadField: r1 = r0->field_a3
    //     0x112f150: ldur            w1, [x0, #0xa3]
    // 0x112f154: DecompressPointer r1
    //     0x112f154: add             x1, x1, HEAP, lsl #32
    // 0x112f158: cmp             w1, NULL
    // 0x112f15c: b.ne            #0x112f170
    // 0x112f160: LoadField: r1 = r0->field_7f
    //     0x112f160: ldur            w1, [x0, #0x7f]
    // 0x112f164: DecompressPointer r1
    //     0x112f164: add             x1, x1, HEAP, lsl #32
    // 0x112f168: mov             x0, x1
    // 0x112f16c: b               #0x112f174
    // 0x112f170: mov             x0, x1
    // 0x112f174: mov             x1, x0
    // 0x112f178: ldur            x0, [fp, #-8]
    // 0x112f17c: r17 = 5201
    //     0x112f17c: mov             x17, #0x1451
    // 0x112f180: cmp             x0, x17
    // 0x112f184: b.ne            #0x112f198
    // 0x112f188: ldr             x2, [fp, #0x10]
    // 0x112f18c: LoadField: r3 = r2->field_2f
    //     0x112f18c: ldur            w3, [x2, #0x2f]
    // 0x112f190: DecompressPointer r3
    //     0x112f190: add             x3, x3, HEAP, lsl #32
    // 0x112f194: b               #0x112f1a4
    // 0x112f198: ldr             x2, [fp, #0x10]
    // 0x112f19c: r3 = Instance_Size
    //     0x112f19c: add             x3, PP, #0x26, lsl #12  ; [pp+0x26558] Obj!Size@12a7871
    //     0x112f1a0: ldr             x3, [x3, #0x558]
    // 0x112f1a4: r17 = 5201
    //     0x112f1a4: mov             x17, #0x1451
    // 0x112f1a8: cmp             x0, x17
    // 0x112f1ac: b.ne            #0x112f1bc
    // 0x112f1b0: LoadField: r0 = r2->field_37
    //     0x112f1b0: ldur            w0, [x2, #0x37]
    // 0x112f1b4: DecompressPointer r0
    //     0x112f1b4: add             x0, x0, HEAP, lsl #32
    // 0x112f1b8: b               #0x112f1c4
    // 0x112f1bc: r0 = Instance_BoxConstraints
    //     0x112f1bc: add             x0, PP, #0x26, lsl #12  ; [pp+0x26560] Obj!BoxConstraints@129c321
    //     0x112f1c0: ldr             x0, [x0, #0x560]
    // 0x112f1c4: ldur            x16, [fp, #-0x28]
    // 0x112f1c8: stp             NULL, x16, [SP, #0x48]
    // 0x112f1cc: ldur            x16, [fp, #-0x20]
    // 0x112f1d0: stp             x16, NULL, [SP, #0x38]
    // 0x112f1d4: ldur            x16, [fp, #-0x18]
    // 0x112f1d8: ldur            lr, [fp, #-0x10]
    // 0x112f1dc: stp             lr, x16, [SP, #0x28]
    // 0x112f1e0: stp             x1, NULL, [SP, #0x18]
    // 0x112f1e4: stp             NULL, x3, [SP, #8]
    // 0x112f1e8: str             x0, [SP]
    // 0x112f1ec: ldur            x1, [fp, #-0x38]
    // 0x112f1f0: ldur            x2, [fp, #-0x30]
    // 0x112f1f4: r4 = const [0, 0xd, 0xb, 0xd, null]
    //     0x112f1f4: add             x4, PP, #0x26, lsl #12  ; [pp+0x26260] List(5) [0, 0xd, 0xb, 0xd, Null]
    //     0x112f1f8: ldr             x4, [x4, #0x260]
    // 0x112f1fc: r0 = hash()
    //     0x112f1fc: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x112f200: mov             x2, x0
    // 0x112f204: r0 = BoxInt64Instr(r2)
    //     0x112f204: sbfiz           x0, x2, #1, #0x1f
    //     0x112f208: cmp             x2, x0, asr #1
    //     0x112f20c: b.eq            #0x112f218
    //     0x112f210: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x112f214: stur            x2, [x0, #7]
    // 0x112f218: LeaveFrame
    //     0x112f218: mov             SP, fp
    //     0x112f21c: ldp             fp, lr, [SP], #0x10
    // 0x112f220: ret
    //     0x112f220: ret             
    // 0x112f224: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112f224: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112f228: b               #0x112f014
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x116871c, size: 0x1bc
    // 0x116871c: EnterFrame
    //     0x116871c: stp             fp, lr, [SP, #-0x10]!
    //     0x1168720: mov             fp, SP
    // 0x1168724: AllocStack(0x30)
    //     0x1168724: sub             SP, SP, #0x30
    // 0x1168728: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x30 */)
    //     0x1168728: mov             x4, x1
    //     0x116872c: mov             x0, x2
    //     0x1168730: stur            x1, [fp, #-0x10]
    //     0x1168734: stur            x2, [fp, #-0x18]
    //     0x1168738: stur            d0, [fp, #-0x30]
    // 0x116873c: CheckStackOverflow
    //     0x116873c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1168740: cmp             SP, x16
    //     0x1168744: b.ls            #0x11688b4
    // 0x1168748: cmp             w4, w0
    // 0x116874c: b.ne            #0x1168760
    // 0x1168750: mov             x0, x4
    // 0x1168754: LeaveFrame
    //     0x1168754: mov             SP, fp
    //     0x1168758: ldp             fp, lr, [SP], #0x10
    // 0x116875c: ret
    //     0x116875c: ret             
    // 0x1168760: r5 = inline_Allocate_Double()
    //     0x1168760: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x1168764: add             x5, x5, #0x10
    //     0x1168768: cmp             x1, x5
    //     0x116876c: b.ls            #0x11688bc
    //     0x1168770: str             x5, [THR, #0x60]  ; THR::top
    //     0x1168774: sub             x5, x5, #0xf
    //     0x1168778: mov             x1, #0xe19c
    //     0x116877c: movk            x1, #3, lsl #16
    //     0x1168780: stur            x1, [x5, #-1]
    // 0x1168784: dmb             ishst
    // 0x1168788: StoreField: r5->field_7 = d0
    //     0x1168788: stur            d0, [x5, #7]
    // 0x116878c: mov             x3, x5
    // 0x1168790: stur            x5, [fp, #-8]
    // 0x1168794: r1 = Null
    //     0x1168794: mov             x1, NULL
    // 0x1168798: r2 = Null
    //     0x1168798: mov             x2, NULL
    // 0x116879c: r0 = lerp()
    //     0x116879c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11687a0: ldur            x3, [fp, #-8]
    // 0x11687a4: r1 = Null
    //     0x11687a4: mov             x1, NULL
    // 0x11687a8: r2 = Null
    //     0x11687a8: mov             x2, NULL
    // 0x11687ac: r0 = lerp()
    //     0x11687ac: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11687b0: ldur            x0, [fp, #-0x10]
    // 0x11687b4: LoadField: r1 = r0->field_f
    //     0x11687b4: ldur            w1, [x0, #0xf]
    // 0x11687b8: DecompressPointer r1
    //     0x11687b8: add             x1, x1, HEAP, lsl #32
    // 0x11687bc: ldur            x4, [fp, #-0x18]
    // 0x11687c0: LoadField: r2 = r4->field_f
    //     0x11687c0: ldur            w2, [x4, #0xf]
    // 0x11687c4: DecompressPointer r2
    //     0x11687c4: add             x2, x2, HEAP, lsl #32
    // 0x11687c8: ldur            x3, [fp, #-8]
    // 0x11687cc: r0 = lerpDouble()
    //     0x11687cc: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x11687d0: ldur            x3, [fp, #-8]
    // 0x11687d4: r1 = Null
    //     0x11687d4: mov             x1, NULL
    // 0x11687d8: r2 = Null
    //     0x11687d8: mov             x2, NULL
    // 0x11687dc: stur            x0, [fp, #-0x20]
    // 0x11687e0: r0 = lerp()
    //     0x11687e0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11687e4: ldur            x3, [fp, #-8]
    // 0x11687e8: r1 = Null
    //     0x11687e8: mov             x1, NULL
    // 0x11687ec: r2 = Null
    //     0x11687ec: mov             x2, NULL
    // 0x11687f0: r0 = lerp()
    //     0x11687f0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11687f4: ldur            x3, [fp, #-8]
    // 0x11687f8: r1 = Null
    //     0x11687f8: mov             x1, NULL
    // 0x11687fc: r2 = Null
    //     0x11687fc: mov             x2, NULL
    // 0x1168800: r0 = lerp()
    //     0x1168800: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168804: ldur            x0, [fp, #-0x10]
    // 0x1168808: LoadField: r1 = r0->field_1f
    //     0x1168808: ldur            w1, [x0, #0x1f]
    // 0x116880c: DecompressPointer r1
    //     0x116880c: add             x1, x1, HEAP, lsl #32
    // 0x1168810: ldur            x4, [fp, #-0x18]
    // 0x1168814: LoadField: r2 = r4->field_1f
    //     0x1168814: ldur            w2, [x4, #0x1f]
    // 0x1168818: DecompressPointer r2
    //     0x1168818: add             x2, x2, HEAP, lsl #32
    // 0x116881c: ldur            x3, [fp, #-8]
    // 0x1168820: r0 = lerpDouble()
    //     0x1168820: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1168824: mov             x3, x0
    // 0x1168828: ldur            x0, [fp, #-0x10]
    // 0x116882c: stur            x3, [fp, #-0x28]
    // 0x1168830: LoadField: r1 = r0->field_23
    //     0x1168830: ldur            w1, [x0, #0x23]
    // 0x1168834: DecompressPointer r1
    //     0x1168834: add             x1, x1, HEAP, lsl #32
    // 0x1168838: ldur            x4, [fp, #-0x18]
    // 0x116883c: LoadField: r2 = r4->field_23
    //     0x116883c: ldur            w2, [x4, #0x23]
    // 0x1168840: DecompressPointer r2
    //     0x1168840: add             x2, x2, HEAP, lsl #32
    // 0x1168844: ldur            d0, [fp, #-0x30]
    // 0x1168848: r0 = lerp()
    //     0x1168848: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x116884c: ldur            x3, [fp, #-8]
    // 0x1168850: r1 = Null
    //     0x1168850: mov             x1, NULL
    // 0x1168854: r2 = Null
    //     0x1168854: mov             x2, NULL
    // 0x1168858: stur            x0, [fp, #-8]
    // 0x116885c: r0 = lerp()
    //     0x116885c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168860: ldur            x0, [fp, #-0x10]
    // 0x1168864: LoadField: r1 = r0->field_37
    //     0x1168864: ldur            w1, [x0, #0x37]
    // 0x1168868: DecompressPointer r1
    //     0x1168868: add             x1, x1, HEAP, lsl #32
    // 0x116886c: ldur            x0, [fp, #-0x18]
    // 0x1168870: LoadField: r2 = r0->field_37
    //     0x1168870: ldur            w2, [x0, #0x37]
    // 0x1168874: DecompressPointer r2
    //     0x1168874: add             x2, x2, HEAP, lsl #32
    // 0x1168878: ldur            d0, [fp, #-0x30]
    // 0x116887c: r0 = lerp()
    //     0x116887c: bl              #0x1163c14  ; [package:flutter/src/rendering/box.dart] BoxConstraints::lerp
    // 0x1168880: stur            x0, [fp, #-0x10]
    // 0x1168884: r0 = BottomSheetThemeData()
    //     0x1168884: bl              #0x11688d8  ; AllocateBottomSheetThemeDataStub -> BottomSheetThemeData (size=0x3c)
    // 0x1168888: ldur            x1, [fp, #-0x20]
    // 0x116888c: StoreField: r0->field_f = r1
    //     0x116888c: stur            w1, [x0, #0xf]
    // 0x1168890: ldur            x1, [fp, #-0x28]
    // 0x1168894: StoreField: r0->field_1f = r1
    //     0x1168894: stur            w1, [x0, #0x1f]
    // 0x1168898: ldur            x1, [fp, #-8]
    // 0x116889c: StoreField: r0->field_23 = r1
    //     0x116889c: stur            w1, [x0, #0x23]
    // 0x11688a0: ldur            x1, [fp, #-0x10]
    // 0x11688a4: StoreField: r0->field_37 = r1
    //     0x11688a4: stur            w1, [x0, #0x37]
    // 0x11688a8: LeaveFrame
    //     0x11688a8: mov             SP, fp
    //     0x11688ac: ldp             fp, lr, [SP], #0x10
    // 0x11688b0: ret
    //     0x11688b0: ret             
    // 0x11688b4: r0 = StackOverflowSharedWithFPURegs()
    //     0x11688b4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11688b8: b               #0x1168748
    // 0x11688bc: SaveReg d0
    //     0x11688bc: str             q0, [SP, #-0x10]!
    // 0x11688c0: stp             x0, x4, [SP, #-0x10]!
    // 0x11688c4: r0 = AllocateDouble()
    //     0x11688c4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11688c8: mov             x5, x0
    // 0x11688cc: ldp             x0, x4, [SP], #0x10
    // 0x11688d0: RestoreReg d0
    //     0x11688d0: ldr             q0, [SP], #0x10
    // 0x11688d4: b               #0x1168788
  }
  _ ==(/* No info */) {
    // ** addr: 0x1264788, size: 0x548
    // 0x1264788: EnterFrame
    //     0x1264788: stp             fp, lr, [SP, #-0x10]!
    //     0x126478c: mov             fp, SP
    // 0x1264790: AllocStack(0x28)
    //     0x1264790: sub             SP, SP, #0x28
    // 0x1264794: CheckStackOverflow
    //     0x1264794: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1264798: cmp             SP, x16
    //     0x126479c: b.ls            #0x1264cc8
    // 0x12647a0: ldr             x1, [fp, #0x10]
    // 0x12647a4: cmp             w1, NULL
    // 0x12647a8: b.ne            #0x12647bc
    // 0x12647ac: r0 = false
    //     0x12647ac: add             x0, NULL, #0x30  ; false
    // 0x12647b0: LeaveFrame
    //     0x12647b0: mov             SP, fp
    //     0x12647b4: ldp             fp, lr, [SP], #0x10
    // 0x12647b8: ret
    //     0x12647b8: ret             
    // 0x12647bc: ldr             x0, [fp, #0x18]
    // 0x12647c0: cmp             w0, w1
    // 0x12647c4: b.ne            #0x12647d8
    // 0x12647c8: r0 = true
    //     0x12647c8: add             x0, NULL, #0x20  ; true
    // 0x12647cc: LeaveFrame
    //     0x12647cc: mov             SP, fp
    //     0x12647d0: ldp             fp, lr, [SP], #0x10
    // 0x12647d4: ret
    //     0x12647d4: ret             
    // 0x12647d8: stp             x0, x1, [SP]
    // 0x12647dc: r0 = _haveSameRuntimeType()
    //     0x12647dc: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x12647e0: tbz             w0, #4, #0x12647f4
    // 0x12647e4: r0 = false
    //     0x12647e4: add             x0, NULL, #0x30  ; false
    // 0x12647e8: LeaveFrame
    //     0x12647e8: mov             SP, fp
    //     0x12647ec: ldp             fp, lr, [SP], #0x10
    // 0x12647f0: ret
    //     0x12647f0: ret             
    // 0x12647f4: ldr             x0, [fp, #0x10]
    // 0x12647f8: r2 = 60
    //     0x12647f8: mov             x2, #0x3c
    // 0x12647fc: branchIfSmi(r0, 0x1264808)
    //     0x12647fc: tbz             w0, #0, #0x1264808
    // 0x1264800: r2 = LoadClassIdInstr(r0)
    //     0x1264800: ldur            x2, [x0, #-1]
    //     0x1264804: ubfx            x2, x2, #0xc, #0x14
    // 0x1264808: stur            x2, [fp, #-8]
    // 0x126480c: r17 = -5201
    //     0x126480c: mov             x17, #-0x1451
    // 0x1264810: add             x16, x2, x17
    // 0x1264814: cmp             x16, #1
    // 0x1264818: b.hi            #0x1264cb8
    // 0x126481c: r17 = 5201
    //     0x126481c: mov             x17, #0x1451
    // 0x1264820: cmp             x2, x17
    // 0x1264824: b.ne            #0x1264838
    // 0x1264828: LoadField: r1 = r0->field_7
    //     0x1264828: ldur            w1, [x0, #7]
    // 0x126482c: DecompressPointer r1
    //     0x126482c: add             x1, x1, HEAP, lsl #32
    // 0x1264830: mov             x2, x1
    // 0x1264834: b               #0x1264884
    // 0x1264838: mov             x1, x0
    // 0x126483c: LoadField: r0 = r1->field_3f
    //     0x126483c: ldur            w0, [x1, #0x3f]
    // 0x1264840: DecompressPointer r0
    //     0x1264840: add             x0, x0, HEAP, lsl #32
    // 0x1264844: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1264848: cmp             w0, w16
    // 0x126484c: b.ne            #0x126485c
    // 0x1264850: r2 = _colors
    //     0x1264850: add             x2, PP, #0x26, lsl #12  ; [pp+0x26550] Field <_BottomSheetDefaultsM3@726001611._colors@726001611>: late final (offset: 0x40)
    //     0x1264854: ldr             x2, [x2, #0x550]
    // 0x1264858: r0 = InitLateFinalInstanceField()
    //     0x1264858: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126485c: LoadField: r1 = r0->field_93
    //     0x126485c: ldur            w1, [x0, #0x93]
    // 0x1264860: DecompressPointer r1
    //     0x1264860: add             x1, x1, HEAP, lsl #32
    // 0x1264864: cmp             w1, NULL
    // 0x1264868: b.ne            #0x126487c
    // 0x126486c: LoadField: r1 = r0->field_7b
    //     0x126486c: ldur            w1, [x0, #0x7b]
    // 0x1264870: DecompressPointer r1
    //     0x1264870: add             x1, x1, HEAP, lsl #32
    // 0x1264874: mov             x0, x1
    // 0x1264878: b               #0x1264880
    // 0x126487c: mov             x0, x1
    // 0x1264880: mov             x2, x0
    // 0x1264884: ldr             x0, [fp, #0x18]
    // 0x1264888: stur            x2, [fp, #-0x18]
    // 0x126488c: r3 = LoadClassIdInstr(r0)
    //     0x126488c: ldur            x3, [x0, #-1]
    //     0x1264890: ubfx            x3, x3, #0xc, #0x14
    // 0x1264894: stur            x3, [fp, #-0x10]
    // 0x1264898: r17 = 5201
    //     0x1264898: mov             x17, #0x1451
    // 0x126489c: cmp             x3, x17
    // 0x12648a0: b.ne            #0x12648b4
    // 0x12648a4: LoadField: r1 = r0->field_7
    //     0x12648a4: ldur            w1, [x0, #7]
    // 0x12648a8: DecompressPointer r1
    //     0x12648a8: add             x1, x1, HEAP, lsl #32
    // 0x12648ac: mov             x0, x2
    // 0x12648b0: b               #0x1264904
    // 0x12648b4: mov             x1, x0
    // 0x12648b8: LoadField: r0 = r1->field_3f
    //     0x12648b8: ldur            w0, [x1, #0x3f]
    // 0x12648bc: DecompressPointer r0
    //     0x12648bc: add             x0, x0, HEAP, lsl #32
    // 0x12648c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12648c4: cmp             w0, w16
    // 0x12648c8: b.ne            #0x12648d8
    // 0x12648cc: r2 = _colors
    //     0x12648cc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26550] Field <_BottomSheetDefaultsM3@726001611._colors@726001611>: late final (offset: 0x40)
    //     0x12648d0: ldr             x2, [x2, #0x550]
    // 0x12648d4: r0 = InitLateFinalInstanceField()
    //     0x12648d4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12648d8: LoadField: r1 = r0->field_93
    //     0x12648d8: ldur            w1, [x0, #0x93]
    // 0x12648dc: DecompressPointer r1
    //     0x12648dc: add             x1, x1, HEAP, lsl #32
    // 0x12648e0: cmp             w1, NULL
    // 0x12648e4: b.ne            #0x12648f8
    // 0x12648e8: LoadField: r1 = r0->field_7b
    //     0x12648e8: ldur            w1, [x0, #0x7b]
    // 0x12648ec: DecompressPointer r1
    //     0x12648ec: add             x1, x1, HEAP, lsl #32
    // 0x12648f0: mov             x0, x1
    // 0x12648f4: b               #0x12648fc
    // 0x12648f8: mov             x0, x1
    // 0x12648fc: mov             x1, x0
    // 0x1264900: ldur            x0, [fp, #-0x18]
    // 0x1264904: r2 = LoadClassIdInstr(r0)
    //     0x1264904: ldur            x2, [x0, #-1]
    //     0x1264908: ubfx            x2, x2, #0xc, #0x14
    // 0x126490c: stp             x1, x0, [SP]
    // 0x1264910: mov             x0, x2
    // 0x1264914: mov             lr, x0
    // 0x1264918: ldr             lr, [x21, lr, lsl #3]
    // 0x126491c: blr             lr
    // 0x1264920: tbnz            w0, #4, #0x1264cb8
    // 0x1264924: ldur            x1, [fp, #-8]
    // 0x1264928: r17 = 5201
    //     0x1264928: mov             x17, #0x1451
    // 0x126492c: cmp             x1, x17
    // 0x1264930: b.ne            #0x1264944
    // 0x1264934: ldr             x2, [fp, #0x10]
    // 0x1264938: LoadField: r0 = r2->field_b
    //     0x1264938: ldur            w0, [x2, #0xb]
    // 0x126493c: DecompressPointer r0
    //     0x126493c: add             x0, x0, HEAP, lsl #32
    // 0x1264940: b               #0x1264950
    // 0x1264944: ldr             x2, [fp, #0x10]
    // 0x1264948: r0 = Instance_Color
    //     0x1264948: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x126494c: ldr             x0, [x0, #0x810]
    // 0x1264950: ldur            x3, [fp, #-0x10]
    // 0x1264954: r17 = 5201
    //     0x1264954: mov             x17, #0x1451
    // 0x1264958: cmp             x3, x17
    // 0x126495c: b.ne            #0x1264970
    // 0x1264960: ldr             x4, [fp, #0x18]
    // 0x1264964: LoadField: r5 = r4->field_b
    //     0x1264964: ldur            w5, [x4, #0xb]
    // 0x1264968: DecompressPointer r5
    //     0x1264968: add             x5, x5, HEAP, lsl #32
    // 0x126496c: b               #0x126497c
    // 0x1264970: ldr             x4, [fp, #0x18]
    // 0x1264974: r5 = Instance_Color
    //     0x1264974: add             x5, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1264978: ldr             x5, [x5, #0x810]
    // 0x126497c: r6 = LoadClassIdInstr(r0)
    //     0x126497c: ldur            x6, [x0, #-1]
    //     0x1264980: ubfx            x6, x6, #0xc, #0x14
    // 0x1264984: stp             x5, x0, [SP]
    // 0x1264988: mov             x0, x6
    // 0x126498c: mov             lr, x0
    // 0x1264990: ldr             lr, [x21, lr, lsl #3]
    // 0x1264994: blr             lr
    // 0x1264998: tbnz            w0, #4, #0x1264cb8
    // 0x126499c: ldr             x2, [fp, #0x18]
    // 0x12649a0: ldr             x1, [fp, #0x10]
    // 0x12649a4: LoadField: r0 = r1->field_f
    //     0x12649a4: ldur            w0, [x1, #0xf]
    // 0x12649a8: DecompressPointer r0
    //     0x12649a8: add             x0, x0, HEAP, lsl #32
    // 0x12649ac: LoadField: r3 = r2->field_f
    //     0x12649ac: ldur            w3, [x2, #0xf]
    // 0x12649b0: DecompressPointer r3
    //     0x12649b0: add             x3, x3, HEAP, lsl #32
    // 0x12649b4: r4 = LoadClassIdInstr(r0)
    //     0x12649b4: ldur            x4, [x0, #-1]
    //     0x12649b8: ubfx            x4, x4, #0xc, #0x14
    // 0x12649bc: stp             x3, x0, [SP]
    // 0x12649c0: mov             x0, x4
    // 0x12649c4: mov             lr, x0
    // 0x12649c8: ldr             lr, [x21, lr, lsl #3]
    // 0x12649cc: blr             lr
    // 0x12649d0: tbnz            w0, #4, #0x1264cb8
    // 0x12649d4: ldur            x1, [fp, #-8]
    // 0x12649d8: r17 = 5201
    //     0x12649d8: mov             x17, #0x1451
    // 0x12649dc: cmp             x1, x17
    // 0x12649e0: b.ne            #0x12649f4
    // 0x12649e4: ldr             x2, [fp, #0x10]
    // 0x12649e8: LoadField: r0 = r2->field_1b
    //     0x12649e8: ldur            w0, [x2, #0x1b]
    // 0x12649ec: DecompressPointer r0
    //     0x12649ec: add             x0, x0, HEAP, lsl #32
    // 0x12649f0: b               #0x1264a00
    // 0x12649f4: ldr             x2, [fp, #0x10]
    // 0x12649f8: r0 = Instance_Color
    //     0x12649f8: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x12649fc: ldr             x0, [x0, #0x810]
    // 0x1264a00: ldur            x3, [fp, #-0x10]
    // 0x1264a04: r17 = 5201
    //     0x1264a04: mov             x17, #0x1451
    // 0x1264a08: cmp             x3, x17
    // 0x1264a0c: b.ne            #0x1264a20
    // 0x1264a10: ldr             x4, [fp, #0x18]
    // 0x1264a14: LoadField: r5 = r4->field_1b
    //     0x1264a14: ldur            w5, [x4, #0x1b]
    // 0x1264a18: DecompressPointer r5
    //     0x1264a18: add             x5, x5, HEAP, lsl #32
    // 0x1264a1c: b               #0x1264a2c
    // 0x1264a20: ldr             x4, [fp, #0x18]
    // 0x1264a24: r5 = Instance_Color
    //     0x1264a24: add             x5, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1264a28: ldr             x5, [x5, #0x810]
    // 0x1264a2c: r6 = LoadClassIdInstr(r0)
    //     0x1264a2c: ldur            x6, [x0, #-1]
    //     0x1264a30: ubfx            x6, x6, #0xc, #0x14
    // 0x1264a34: stp             x5, x0, [SP]
    // 0x1264a38: mov             x0, x6
    // 0x1264a3c: mov             lr, x0
    // 0x1264a40: ldr             lr, [x21, lr, lsl #3]
    // 0x1264a44: blr             lr
    // 0x1264a48: tbnz            w0, #4, #0x1264cb8
    // 0x1264a4c: ldr             x2, [fp, #0x18]
    // 0x1264a50: ldr             x1, [fp, #0x10]
    // 0x1264a54: LoadField: r0 = r1->field_1f
    //     0x1264a54: ldur            w0, [x1, #0x1f]
    // 0x1264a58: DecompressPointer r0
    //     0x1264a58: add             x0, x0, HEAP, lsl #32
    // 0x1264a5c: LoadField: r3 = r2->field_1f
    //     0x1264a5c: ldur            w3, [x2, #0x1f]
    // 0x1264a60: DecompressPointer r3
    //     0x1264a60: add             x3, x3, HEAP, lsl #32
    // 0x1264a64: r4 = LoadClassIdInstr(r0)
    //     0x1264a64: ldur            x4, [x0, #-1]
    //     0x1264a68: ubfx            x4, x4, #0xc, #0x14
    // 0x1264a6c: stp             x3, x0, [SP]
    // 0x1264a70: mov             x0, x4
    // 0x1264a74: mov             lr, x0
    // 0x1264a78: ldr             lr, [x21, lr, lsl #3]
    // 0x1264a7c: blr             lr
    // 0x1264a80: tbnz            w0, #4, #0x1264cb8
    // 0x1264a84: ldr             x2, [fp, #0x18]
    // 0x1264a88: ldr             x1, [fp, #0x10]
    // 0x1264a8c: LoadField: r0 = r1->field_23
    //     0x1264a8c: ldur            w0, [x1, #0x23]
    // 0x1264a90: DecompressPointer r0
    //     0x1264a90: add             x0, x0, HEAP, lsl #32
    // 0x1264a94: LoadField: r3 = r2->field_23
    //     0x1264a94: ldur            w3, [x2, #0x23]
    // 0x1264a98: DecompressPointer r3
    //     0x1264a98: add             x3, x3, HEAP, lsl #32
    // 0x1264a9c: r4 = LoadClassIdInstr(r0)
    //     0x1264a9c: ldur            x4, [x0, #-1]
    //     0x1264aa0: ubfx            x4, x4, #0xc, #0x14
    // 0x1264aa4: stp             x3, x0, [SP]
    // 0x1264aa8: mov             x0, x4
    // 0x1264aac: mov             lr, x0
    // 0x1264ab0: ldr             lr, [x21, lr, lsl #3]
    // 0x1264ab4: blr             lr
    // 0x1264ab8: tbnz            w0, #4, #0x1264cb8
    // 0x1264abc: ldur            x0, [fp, #-8]
    // 0x1264ac0: r17 = 5201
    //     0x1264ac0: mov             x17, #0x1451
    // 0x1264ac4: cmp             x0, x17
    // 0x1264ac8: b.ne            #0x1264ae0
    // 0x1264acc: ldr             x2, [fp, #0x10]
    // 0x1264ad0: LoadField: r1 = r2->field_2b
    //     0x1264ad0: ldur            w1, [x2, #0x2b]
    // 0x1264ad4: DecompressPointer r1
    //     0x1264ad4: add             x1, x1, HEAP, lsl #32
    // 0x1264ad8: mov             x2, x1
    // 0x1264adc: b               #0x1264b30
    // 0x1264ae0: ldr             x2, [fp, #0x10]
    // 0x1264ae4: mov             x1, x2
    // 0x1264ae8: LoadField: r0 = r1->field_3f
    //     0x1264ae8: ldur            w0, [x1, #0x3f]
    // 0x1264aec: DecompressPointer r0
    //     0x1264aec: add             x0, x0, HEAP, lsl #32
    // 0x1264af0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1264af4: cmp             w0, w16
    // 0x1264af8: b.ne            #0x1264b08
    // 0x1264afc: r2 = _colors
    //     0x1264afc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26550] Field <_BottomSheetDefaultsM3@726001611._colors@726001611>: late final (offset: 0x40)
    //     0x1264b00: ldr             x2, [x2, #0x550]
    // 0x1264b04: r0 = InitLateFinalInstanceField()
    //     0x1264b04: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1264b08: LoadField: r1 = r0->field_a3
    //     0x1264b08: ldur            w1, [x0, #0xa3]
    // 0x1264b0c: DecompressPointer r1
    //     0x1264b0c: add             x1, x1, HEAP, lsl #32
    // 0x1264b10: cmp             w1, NULL
    // 0x1264b14: b.ne            #0x1264b28
    // 0x1264b18: LoadField: r1 = r0->field_7f
    //     0x1264b18: ldur            w1, [x0, #0x7f]
    // 0x1264b1c: DecompressPointer r1
    //     0x1264b1c: add             x1, x1, HEAP, lsl #32
    // 0x1264b20: mov             x0, x1
    // 0x1264b24: b               #0x1264b2c
    // 0x1264b28: mov             x0, x1
    // 0x1264b2c: mov             x2, x0
    // 0x1264b30: ldur            x0, [fp, #-0x10]
    // 0x1264b34: stur            x2, [fp, #-0x18]
    // 0x1264b38: r17 = 5201
    //     0x1264b38: mov             x17, #0x1451
    // 0x1264b3c: cmp             x0, x17
    // 0x1264b40: b.ne            #0x1264b58
    // 0x1264b44: ldr             x3, [fp, #0x18]
    // 0x1264b48: LoadField: r1 = r3->field_2b
    //     0x1264b48: ldur            w1, [x3, #0x2b]
    // 0x1264b4c: DecompressPointer r1
    //     0x1264b4c: add             x1, x1, HEAP, lsl #32
    // 0x1264b50: mov             x0, x2
    // 0x1264b54: b               #0x1264bac
    // 0x1264b58: ldr             x3, [fp, #0x18]
    // 0x1264b5c: mov             x1, x3
    // 0x1264b60: LoadField: r0 = r1->field_3f
    //     0x1264b60: ldur            w0, [x1, #0x3f]
    // 0x1264b64: DecompressPointer r0
    //     0x1264b64: add             x0, x0, HEAP, lsl #32
    // 0x1264b68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1264b6c: cmp             w0, w16
    // 0x1264b70: b.ne            #0x1264b80
    // 0x1264b74: r2 = _colors
    //     0x1264b74: add             x2, PP, #0x26, lsl #12  ; [pp+0x26550] Field <_BottomSheetDefaultsM3@726001611._colors@726001611>: late final (offset: 0x40)
    //     0x1264b78: ldr             x2, [x2, #0x550]
    // 0x1264b7c: r0 = InitLateFinalInstanceField()
    //     0x1264b7c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1264b80: LoadField: r1 = r0->field_a3
    //     0x1264b80: ldur            w1, [x0, #0xa3]
    // 0x1264b84: DecompressPointer r1
    //     0x1264b84: add             x1, x1, HEAP, lsl #32
    // 0x1264b88: cmp             w1, NULL
    // 0x1264b8c: b.ne            #0x1264ba0
    // 0x1264b90: LoadField: r1 = r0->field_7f
    //     0x1264b90: ldur            w1, [x0, #0x7f]
    // 0x1264b94: DecompressPointer r1
    //     0x1264b94: add             x1, x1, HEAP, lsl #32
    // 0x1264b98: mov             x0, x1
    // 0x1264b9c: b               #0x1264ba4
    // 0x1264ba0: mov             x0, x1
    // 0x1264ba4: mov             x1, x0
    // 0x1264ba8: ldur            x0, [fp, #-0x18]
    // 0x1264bac: r2 = LoadClassIdInstr(r0)
    //     0x1264bac: ldur            x2, [x0, #-1]
    //     0x1264bb0: ubfx            x2, x2, #0xc, #0x14
    // 0x1264bb4: stp             x1, x0, [SP]
    // 0x1264bb8: mov             x0, x2
    // 0x1264bbc: mov             lr, x0
    // 0x1264bc0: ldr             lr, [x21, lr, lsl #3]
    // 0x1264bc4: blr             lr
    // 0x1264bc8: tbnz            w0, #4, #0x1264cb8
    // 0x1264bcc: ldur            x1, [fp, #-8]
    // 0x1264bd0: r17 = 5201
    //     0x1264bd0: mov             x17, #0x1451
    // 0x1264bd4: cmp             x1, x17
    // 0x1264bd8: b.ne            #0x1264bec
    // 0x1264bdc: ldr             x2, [fp, #0x10]
    // 0x1264be0: LoadField: r0 = r2->field_2f
    //     0x1264be0: ldur            w0, [x2, #0x2f]
    // 0x1264be4: DecompressPointer r0
    //     0x1264be4: add             x0, x0, HEAP, lsl #32
    // 0x1264be8: b               #0x1264bf8
    // 0x1264bec: ldr             x2, [fp, #0x10]
    // 0x1264bf0: r0 = Instance_Size
    //     0x1264bf0: add             x0, PP, #0x26, lsl #12  ; [pp+0x26558] Obj!Size@12a7871
    //     0x1264bf4: ldr             x0, [x0, #0x558]
    // 0x1264bf8: ldur            x3, [fp, #-0x10]
    // 0x1264bfc: r17 = 5201
    //     0x1264bfc: mov             x17, #0x1451
    // 0x1264c00: cmp             x3, x17
    // 0x1264c04: b.ne            #0x1264c18
    // 0x1264c08: ldr             x4, [fp, #0x18]
    // 0x1264c0c: LoadField: r5 = r4->field_2f
    //     0x1264c0c: ldur            w5, [x4, #0x2f]
    // 0x1264c10: DecompressPointer r5
    //     0x1264c10: add             x5, x5, HEAP, lsl #32
    // 0x1264c14: b               #0x1264c24
    // 0x1264c18: ldr             x4, [fp, #0x18]
    // 0x1264c1c: r5 = Instance_Size
    //     0x1264c1c: add             x5, PP, #0x26, lsl #12  ; [pp+0x26558] Obj!Size@12a7871
    //     0x1264c20: ldr             x5, [x5, #0x558]
    // 0x1264c24: r6 = LoadClassIdInstr(r0)
    //     0x1264c24: ldur            x6, [x0, #-1]
    //     0x1264c28: ubfx            x6, x6, #0xc, #0x14
    // 0x1264c2c: stp             x5, x0, [SP]
    // 0x1264c30: mov             x0, x6
    // 0x1264c34: mov             lr, x0
    // 0x1264c38: ldr             lr, [x21, lr, lsl #3]
    // 0x1264c3c: blr             lr
    // 0x1264c40: tbnz            w0, #4, #0x1264cb8
    // 0x1264c44: ldur            x0, [fp, #-8]
    // 0x1264c48: r17 = 5201
    //     0x1264c48: mov             x17, #0x1451
    // 0x1264c4c: cmp             x0, x17
    // 0x1264c50: b.ne            #0x1264c64
    // 0x1264c54: ldr             x0, [fp, #0x10]
    // 0x1264c58: LoadField: r1 = r0->field_37
    //     0x1264c58: ldur            w1, [x0, #0x37]
    // 0x1264c5c: DecompressPointer r1
    //     0x1264c5c: add             x1, x1, HEAP, lsl #32
    // 0x1264c60: b               #0x1264c6c
    // 0x1264c64: r1 = Instance_BoxConstraints
    //     0x1264c64: add             x1, PP, #0x26, lsl #12  ; [pp+0x26560] Obj!BoxConstraints@129c321
    //     0x1264c68: ldr             x1, [x1, #0x560]
    // 0x1264c6c: ldur            x0, [fp, #-0x10]
    // 0x1264c70: r17 = 5201
    //     0x1264c70: mov             x17, #0x1451
    // 0x1264c74: cmp             x0, x17
    // 0x1264c78: b.ne            #0x1264c90
    // 0x1264c7c: ldr             x0, [fp, #0x18]
    // 0x1264c80: LoadField: r2 = r0->field_37
    //     0x1264c80: ldur            w2, [x0, #0x37]
    // 0x1264c84: DecompressPointer r2
    //     0x1264c84: add             x2, x2, HEAP, lsl #32
    // 0x1264c88: mov             x0, x2
    // 0x1264c8c: b               #0x1264c98
    // 0x1264c90: r0 = Instance_BoxConstraints
    //     0x1264c90: add             x0, PP, #0x26, lsl #12  ; [pp+0x26560] Obj!BoxConstraints@129c321
    //     0x1264c94: ldr             x0, [x0, #0x560]
    // 0x1264c98: r2 = LoadClassIdInstr(r1)
    //     0x1264c98: ldur            x2, [x1, #-1]
    //     0x1264c9c: ubfx            x2, x2, #0xc, #0x14
    // 0x1264ca0: stp             x0, x1, [SP]
    // 0x1264ca4: mov             x0, x2
    // 0x1264ca8: mov             lr, x0
    // 0x1264cac: ldr             lr, [x21, lr, lsl #3]
    // 0x1264cb0: blr             lr
    // 0x1264cb4: b               #0x1264cbc
    // 0x1264cb8: r0 = false
    //     0x1264cb8: add             x0, NULL, #0x30  ; false
    // 0x1264cbc: LeaveFrame
    //     0x1264cbc: mov             SP, fp
    //     0x1264cc0: ldp             fp, lr, [SP], #0x10
    // 0x1264cc4: ret
    //     0x1264cc4: ret             
    // 0x1264cc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1264cc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1264ccc: b               #0x12647a0
  }
}
