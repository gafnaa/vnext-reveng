// lib: , url: package:flutter/src/material/list_tile_theme.dart

// class id: 1048910, size: 0x8
class :: {
}

// class id: 5141, size: 0x60, field offset: 0x8
//   const constructor, 
class ListTileThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x1134578, size: 0x840
    // 0x1134578: EnterFrame
    //     0x1134578: stp             fp, lr, [SP, #-0x10]!
    //     0x113457c: mov             fp, SP
    // 0x1134580: AllocStack(0x28)
    //     0x1134580: sub             SP, SP, #0x28
    // 0x1134584: CheckStackOverflow
    //     0x1134584: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1134588: cmp             SP, x16
    //     0x113458c: b.ls            #0x1134d9c
    // 0x1134590: ldr             x0, [fp, #0x10]
    // 0x1134594: LoadField: r3 = r0->field_7
    //     0x1134594: ldur            w3, [x0, #7]
    // 0x1134598: DecompressPointer r3
    //     0x1134598: add             x3, x3, HEAP, lsl #32
    // 0x113459c: stur            x3, [fp, #-8]
    // 0x11345a0: r1 = <Object?>
    //     0x11345a0: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x11345a4: r2 = 44
    //     0x11345a4: mov             x2, #0x2c
    // 0x11345a8: r0 = AllocateArray()
    //     0x11345a8: bl              #0x13df928  ; AllocateArrayStub
    // 0x11345ac: mov             x2, x0
    // 0x11345b0: ldur            x0, [fp, #-8]
    // 0x11345b4: stur            x2, [fp, #-0x18]
    // 0x11345b8: StoreField: r2->field_f = r0
    //     0x11345b8: stur            w0, [x2, #0xf]
    // 0x11345bc: ldr             x0, [fp, #0x10]
    // 0x11345c0: LoadField: r1 = r0->field_b
    //     0x11345c0: ldur            w1, [x0, #0xb]
    // 0x11345c4: DecompressPointer r1
    //     0x11345c4: add             x1, x1, HEAP, lsl #32
    // 0x11345c8: StoreField: r2->field_13 = r1
    //     0x11345c8: stur            w1, [x2, #0x13]
    // 0x11345cc: LoadField: r3 = r0->field_f
    //     0x11345cc: ldur            w3, [x0, #0xf]
    // 0x11345d0: DecompressPointer r3
    //     0x11345d0: add             x3, x3, HEAP, lsl #32
    // 0x11345d4: stur            x3, [fp, #-8]
    // 0x11345d8: ArrayStore: r2[0] = r3  ; List_4
    //     0x11345d8: stur            w3, [x2, #0x17]
    // 0x11345dc: r4 = LoadClassIdInstr(r0)
    //     0x11345dc: ldur            x4, [x0, #-1]
    //     0x11345e0: ubfx            x4, x4, #0xc, #0x14
    // 0x11345e4: stur            x4, [fp, #-0x10]
    // 0x11345e8: r17 = 5141
    //     0x11345e8: mov             x17, #0x1415
    // 0x11345ec: cmp             x4, x17
    // 0x11345f0: b.ne            #0x1134608
    // 0x11345f4: LoadField: r1 = r0->field_13
    //     0x11345f4: ldur            w1, [x0, #0x13]
    // 0x11345f8: DecompressPointer r1
    //     0x11345f8: add             x1, x1, HEAP, lsl #32
    // 0x11345fc: mov             x0, x1
    // 0x1134600: mov             x2, x4
    // 0x1134604: b               #0x1134684
    // 0x1134608: r17 = 5142
    //     0x1134608: mov             x17, #0x1416
    // 0x113460c: cmp             x4, x17
    // 0x1134610: b.ne            #0x113464c
    // 0x1134614: mov             x1, x0
    // 0x1134618: LoadField: r0 = r1->field_67
    //     0x1134618: ldur            w0, [x1, #0x67]
    // 0x113461c: DecompressPointer r0
    //     0x113461c: add             x0, x0, HEAP, lsl #32
    // 0x1134620: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1134624: cmp             w0, w16
    // 0x1134628: b.ne            #0x1134638
    // 0x113462c: r2 = _colors
    //     0x113462c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0x1134630: ldr             x2, [x2, #0x320]
    // 0x1134634: r0 = InitLateFinalInstanceField()
    //     0x1134634: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1134638: LoadField: r1 = r0->field_b
    //     0x1134638: ldur            w1, [x0, #0xb]
    // 0x113463c: DecompressPointer r1
    //     0x113463c: add             x1, x1, HEAP, lsl #32
    // 0x1134640: mov             x0, x1
    // 0x1134644: ldur            x2, [fp, #-0x10]
    // 0x1134648: b               #0x1134684
    // 0x113464c: ldr             x1, [fp, #0x10]
    // 0x1134650: LoadField: r0 = r1->field_63
    //     0x1134650: ldur            w0, [x1, #0x63]
    // 0x1134654: DecompressPointer r0
    //     0x1134654: add             x0, x0, HEAP, lsl #32
    // 0x1134658: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x113465c: cmp             w0, w16
    // 0x1134660: b.ne            #0x1134670
    // 0x1134664: r2 = _theme
    //     0x1134664: add             x2, PP, #0x26, lsl #12  ; [pp+0x26328] Field <_LisTileDefaultsM2@97247952._theme@97247952>: late final (offset: 0x64)
    //     0x1134668: ldr             x2, [x2, #0x328]
    // 0x113466c: r0 = InitLateFinalInstanceField()
    //     0x113466c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1134670: LoadField: r1 = r0->field_3f
    //     0x1134670: ldur            w1, [x0, #0x3f]
    // 0x1134674: DecompressPointer r1
    //     0x1134674: add             x1, x1, HEAP, lsl #32
    // 0x1134678: LoadField: r0 = r1->field_b
    //     0x1134678: ldur            w0, [x1, #0xb]
    // 0x113467c: DecompressPointer r0
    //     0x113467c: add             x0, x0, HEAP, lsl #32
    // 0x1134680: ldur            x2, [fp, #-0x10]
    // 0x1134684: ldur            x1, [fp, #-0x18]
    // 0x1134688: ArrayStore: r1[3] = r0  ; List_4
    //     0x1134688: add             x25, x1, #0x1b
    //     0x113468c: str             w0, [x25]
    //     0x1134690: tbz             w0, #0, #0x11346ac
    //     0x1134694: ldurb           w16, [x1, #-1]
    //     0x1134698: ldurb           w17, [x0, #-1]
    //     0x113469c: and             x16, x17, x16, lsr #2
    //     0x11346a0: tst             x16, HEAP, lsr #32
    //     0x11346a4: b.eq            #0x11346ac
    //     0x11346a8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11346ac: r17 = 5141
    //     0x11346ac: mov             x17, #0x1415
    // 0x11346b0: cmp             x2, x17
    // 0x11346b4: b.ne            #0x11346d0
    // 0x11346b8: ldr             x0, [fp, #0x10]
    // 0x11346bc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11346bc: ldur            w1, [x0, #0x17]
    // 0x11346c0: DecompressPointer r1
    //     0x11346c0: add             x1, x1, HEAP, lsl #32
    // 0x11346c4: mov             x3, x0
    // 0x11346c8: mov             x0, x1
    // 0x11346cc: b               #0x113478c
    // 0x11346d0: ldr             x0, [fp, #0x10]
    // 0x11346d4: r17 = 5142
    //     0x11346d4: mov             x17, #0x1416
    // 0x11346d8: cmp             x2, x17
    // 0x11346dc: b.ne            #0x1134734
    // 0x11346e0: mov             x1, x0
    // 0x11346e4: LoadField: r0 = r1->field_67
    //     0x11346e4: ldur            w0, [x1, #0x67]
    // 0x11346e8: DecompressPointer r0
    //     0x11346e8: add             x0, x0, HEAP, lsl #32
    // 0x11346ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11346f0: cmp             w0, w16
    // 0x11346f4: b.ne            #0x1134704
    // 0x11346f8: r2 = _colors
    //     0x11346f8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0x11346fc: ldr             x2, [x2, #0x320]
    // 0x1134700: r0 = InitLateFinalInstanceField()
    //     0x1134700: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1134704: LoadField: r1 = r0->field_a3
    //     0x1134704: ldur            w1, [x0, #0xa3]
    // 0x1134708: DecompressPointer r1
    //     0x1134708: add             x1, x1, HEAP, lsl #32
    // 0x113470c: cmp             w1, NULL
    // 0x1134710: b.ne            #0x1134724
    // 0x1134714: LoadField: r1 = r0->field_7f
    //     0x1134714: ldur            w1, [x0, #0x7f]
    // 0x1134718: DecompressPointer r1
    //     0x1134718: add             x1, x1, HEAP, lsl #32
    // 0x113471c: mov             x0, x1
    // 0x1134720: b               #0x1134728
    // 0x1134724: mov             x0, x1
    // 0x1134728: ldr             x3, [fp, #0x10]
    // 0x113472c: ldur            x2, [fp, #-0x10]
    // 0x1134730: b               #0x113478c
    // 0x1134734: ldr             x1, [fp, #0x10]
    // 0x1134738: LoadField: r0 = r1->field_63
    //     0x1134738: ldur            w0, [x1, #0x63]
    // 0x113473c: DecompressPointer r0
    //     0x113473c: add             x0, x0, HEAP, lsl #32
    // 0x1134740: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1134744: cmp             w0, w16
    // 0x1134748: b.ne            #0x1134758
    // 0x113474c: r2 = _theme
    //     0x113474c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26328] Field <_LisTileDefaultsM2@97247952._theme@97247952>: late final (offset: 0x64)
    //     0x1134750: ldr             x2, [x2, #0x328]
    // 0x1134754: r0 = InitLateFinalInstanceField()
    //     0x1134754: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1134758: LoadField: r1 = r0->field_3f
    //     0x1134758: ldur            w1, [x0, #0x3f]
    // 0x113475c: DecompressPointer r1
    //     0x113475c: add             x1, x1, HEAP, lsl #32
    // 0x1134760: LoadField: r0 = r1->field_7
    //     0x1134760: ldur            w0, [x1, #7]
    // 0x1134764: DecompressPointer r0
    //     0x1134764: add             x0, x0, HEAP, lsl #32
    // 0x1134768: LoadField: r1 = r0->field_7
    //     0x1134768: ldur            x1, [x0, #7]
    // 0x113476c: cmp             x1, #0
    // 0x1134770: b.gt            #0x113477c
    // 0x1134774: r0 = Null
    //     0x1134774: mov             x0, NULL
    // 0x1134778: b               #0x1134784
    // 0x113477c: r0 = Instance_Color
    //     0x113477c: add             x0, PP, #0x26, lsl #12  ; [pp+0x26330] Obj!Color@12a2bb1
    //     0x1134780: ldr             x0, [x0, #0x330]
    // 0x1134784: ldr             x3, [fp, #0x10]
    // 0x1134788: ldur            x2, [fp, #-0x10]
    // 0x113478c: ldur            x1, [fp, #-0x18]
    // 0x1134790: ArrayStore: r1[4] = r0  ; List_4
    //     0x1134790: add             x25, x1, #0x1f
    //     0x1134794: str             w0, [x25]
    //     0x1134798: tbz             w0, #0, #0x11347b4
    //     0x113479c: ldurb           w16, [x1, #-1]
    //     0x11347a0: ldurb           w17, [x0, #-1]
    //     0x11347a4: and             x16, x17, x16, lsr #2
    //     0x11347a8: tst             x16, HEAP, lsr #32
    //     0x11347ac: b.eq            #0x11347b4
    //     0x11347b0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11347b4: LoadField: r0 = r3->field_1b
    //     0x11347b4: ldur            w0, [x3, #0x1b]
    // 0x11347b8: DecompressPointer r0
    //     0x11347b8: add             x0, x0, HEAP, lsl #32
    // 0x11347bc: ldur            x1, [fp, #-0x18]
    // 0x11347c0: ArrayStore: r1[5] = r0  ; List_4
    //     0x11347c0: add             x25, x1, #0x23
    //     0x11347c4: str             w0, [x25]
    //     0x11347c8: tbz             w0, #0, #0x11347e4
    //     0x11347cc: ldurb           w16, [x1, #-1]
    //     0x11347d0: ldurb           w17, [x0, #-1]
    //     0x11347d4: and             x16, x17, x16, lsr #2
    //     0x11347d8: tst             x16, HEAP, lsr #32
    //     0x11347dc: b.eq            #0x11347e4
    //     0x11347e0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11347e4: r17 = 5141
    //     0x11347e4: mov             x17, #0x1415
    // 0x11347e8: cmp             x2, x17
    // 0x11347ec: b.ne            #0x11347fc
    // 0x11347f0: LoadField: r0 = r3->field_1f
    //     0x11347f0: ldur            w0, [x3, #0x1f]
    // 0x11347f4: DecompressPointer r0
    //     0x11347f4: add             x0, x0, HEAP, lsl #32
    // 0x11347f8: b               #0x1134900
    // 0x11347fc: r17 = 5142
    //     0x11347fc: mov             x17, #0x1416
    // 0x1134800: cmp             x2, x17
    // 0x1134804: b.ne            #0x1134880
    // 0x1134808: mov             x1, x3
    // 0x113480c: LoadField: r0 = r1->field_6b
    //     0x113480c: ldur            w0, [x1, #0x6b]
    // 0x1134810: DecompressPointer r0
    //     0x1134810: add             x0, x0, HEAP, lsl #32
    // 0x1134814: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1134818: cmp             w0, w16
    // 0x113481c: b.ne            #0x113482c
    // 0x1134820: r2 = _textTheme
    //     0x1134820: add             x2, PP, #0x26, lsl #12  ; [pp+0x26338] Field <_LisTileDefaultsM3@97247952._textTheme@97247952>: late final (offset: 0x6c)
    //     0x1134824: ldr             x2, [x2, #0x338]
    // 0x1134828: r0 = InitLateFinalInstanceField()
    //     0x1134828: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113482c: LoadField: r2 = r0->field_2b
    //     0x113482c: ldur            w2, [x0, #0x2b]
    // 0x1134830: DecompressPointer r2
    //     0x1134830: add             x2, x2, HEAP, lsl #32
    // 0x1134834: ldr             x1, [fp, #0x10]
    // 0x1134838: stur            x2, [fp, #-0x20]
    // 0x113483c: LoadField: r0 = r1->field_67
    //     0x113483c: ldur            w0, [x1, #0x67]
    // 0x1134840: DecompressPointer r0
    //     0x1134840: add             x0, x0, HEAP, lsl #32
    // 0x1134844: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1134848: cmp             w0, w16
    // 0x113484c: b.ne            #0x113485c
    // 0x1134850: r2 = _colors
    //     0x1134850: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0x1134854: ldr             x2, [x2, #0x320]
    // 0x1134858: r0 = InitLateFinalInstanceField()
    //     0x1134858: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113485c: LoadField: r1 = r0->field_7f
    //     0x113485c: ldur            w1, [x0, #0x7f]
    // 0x1134860: DecompressPointer r1
    //     0x1134860: add             x1, x1, HEAP, lsl #32
    // 0x1134864: str             x1, [SP]
    // 0x1134868: ldur            x1, [fp, #-0x20]
    // 0x113486c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x113486c: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x1134870: ldr             x4, [x4, #0x7f0]
    // 0x1134874: r0 = copyWith()
    //     0x1134874: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x1134878: ldur            x2, [fp, #-0x10]
    // 0x113487c: b               #0x1134900
    // 0x1134880: ldur            x0, [fp, #-8]
    // 0x1134884: cmp             w0, NULL
    // 0x1134888: b.eq            #0x1134da4
    // 0x113488c: LoadField: r1 = r0->field_7
    //     0x113488c: ldur            x1, [x0, #7]
    // 0x1134890: cmp             x1, #0
    // 0x1134894: b.gt            #0x11348cc
    // 0x1134898: ldr             x1, [fp, #0x10]
    // 0x113489c: LoadField: r0 = r1->field_67
    //     0x113489c: ldur            w0, [x1, #0x67]
    // 0x11348a0: DecompressPointer r0
    //     0x11348a0: add             x0, x0, HEAP, lsl #32
    // 0x11348a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11348a8: cmp             w0, w16
    // 0x11348ac: b.ne            #0x11348bc
    // 0x11348b0: r2 = _textTheme
    //     0x11348b0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26340] Field <_LisTileDefaultsM2@97247952._textTheme@97247952>: late final (offset: 0x68)
    //     0x11348b4: ldr             x2, [x2, #0x340]
    // 0x11348b8: r0 = InitLateFinalInstanceField()
    //     0x11348b8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11348bc: LoadField: r1 = r0->field_23
    //     0x11348bc: ldur            w1, [x0, #0x23]
    // 0x11348c0: DecompressPointer r1
    //     0x11348c0: add             x1, x1, HEAP, lsl #32
    // 0x11348c4: mov             x0, x1
    // 0x11348c8: b               #0x11348fc
    // 0x11348cc: ldr             x1, [fp, #0x10]
    // 0x11348d0: LoadField: r0 = r1->field_67
    //     0x11348d0: ldur            w0, [x1, #0x67]
    // 0x11348d4: DecompressPointer r0
    //     0x11348d4: add             x0, x0, HEAP, lsl #32
    // 0x11348d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11348dc: cmp             w0, w16
    // 0x11348e0: b.ne            #0x11348f0
    // 0x11348e4: r2 = _textTheme
    //     0x11348e4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26340] Field <_LisTileDefaultsM2@97247952._textTheme@97247952>: late final (offset: 0x68)
    //     0x11348e8: ldr             x2, [x2, #0x340]
    // 0x11348ec: r0 = InitLateFinalInstanceField()
    //     0x11348ec: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11348f0: LoadField: r1 = r0->field_2b
    //     0x11348f0: ldur            w1, [x0, #0x2b]
    // 0x11348f4: DecompressPointer r1
    //     0x11348f4: add             x1, x1, HEAP, lsl #32
    // 0x11348f8: mov             x0, x1
    // 0x11348fc: ldur            x2, [fp, #-0x10]
    // 0x1134900: ldur            x1, [fp, #-0x18]
    // 0x1134904: ArrayStore: r1[6] = r0  ; List_4
    //     0x1134904: add             x25, x1, #0x27
    //     0x1134908: str             w0, [x25]
    //     0x113490c: tbz             w0, #0, #0x1134928
    //     0x1134910: ldurb           w16, [x1, #-1]
    //     0x1134914: ldurb           w17, [x0, #-1]
    //     0x1134918: and             x16, x17, x16, lsr #2
    //     0x113491c: tst             x16, HEAP, lsr #32
    //     0x1134920: b.eq            #0x1134928
    //     0x1134924: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1134928: r17 = 5141
    //     0x1134928: mov             x17, #0x1415
    // 0x113492c: cmp             x2, x17
    // 0x1134930: b.ne            #0x1134948
    // 0x1134934: ldr             x0, [fp, #0x10]
    // 0x1134938: LoadField: r1 = r0->field_23
    //     0x1134938: ldur            w1, [x0, #0x23]
    // 0x113493c: DecompressPointer r1
    //     0x113493c: add             x1, x1, HEAP, lsl #32
    // 0x1134940: mov             x0, x1
    // 0x1134944: b               #0x1134a54
    // 0x1134948: ldr             x0, [fp, #0x10]
    // 0x113494c: r17 = 5142
    //     0x113494c: mov             x17, #0x1416
    // 0x1134950: cmp             x2, x17
    // 0x1134954: b.ne            #0x11349f4
    // 0x1134958: mov             x1, x0
    // 0x113495c: LoadField: r0 = r1->field_6b
    //     0x113495c: ldur            w0, [x1, #0x6b]
    // 0x1134960: DecompressPointer r0
    //     0x1134960: add             x0, x0, HEAP, lsl #32
    // 0x1134964: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1134968: cmp             w0, w16
    // 0x113496c: b.ne            #0x113497c
    // 0x1134970: r2 = _textTheme
    //     0x1134970: add             x2, PP, #0x26, lsl #12  ; [pp+0x26338] Field <_LisTileDefaultsM3@97247952._textTheme@97247952>: late final (offset: 0x6c)
    //     0x1134974: ldr             x2, [x2, #0x338]
    // 0x1134978: r0 = InitLateFinalInstanceField()
    //     0x1134978: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113497c: LoadField: r2 = r0->field_2f
    //     0x113497c: ldur            w2, [x0, #0x2f]
    // 0x1134980: DecompressPointer r2
    //     0x1134980: add             x2, x2, HEAP, lsl #32
    // 0x1134984: stur            x2, [fp, #-8]
    // 0x1134988: cmp             w2, NULL
    // 0x113498c: b.eq            #0x1134da8
    // 0x1134990: ldr             x1, [fp, #0x10]
    // 0x1134994: LoadField: r0 = r1->field_67
    //     0x1134994: ldur            w0, [x1, #0x67]
    // 0x1134998: DecompressPointer r0
    //     0x1134998: add             x0, x0, HEAP, lsl #32
    // 0x113499c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11349a0: cmp             w0, w16
    // 0x11349a4: b.ne            #0x11349b4
    // 0x11349a8: r2 = _colors
    //     0x11349a8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0x11349ac: ldr             x2, [x2, #0x320]
    // 0x11349b0: r0 = InitLateFinalInstanceField()
    //     0x11349b0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11349b4: LoadField: r1 = r0->field_a3
    //     0x11349b4: ldur            w1, [x0, #0xa3]
    // 0x11349b8: DecompressPointer r1
    //     0x11349b8: add             x1, x1, HEAP, lsl #32
    // 0x11349bc: cmp             w1, NULL
    // 0x11349c0: b.ne            #0x11349d4
    // 0x11349c4: LoadField: r1 = r0->field_7f
    //     0x11349c4: ldur            w1, [x0, #0x7f]
    // 0x11349c8: DecompressPointer r1
    //     0x11349c8: add             x1, x1, HEAP, lsl #32
    // 0x11349cc: mov             x0, x1
    // 0x11349d0: b               #0x11349d8
    // 0x11349d4: mov             x0, x1
    // 0x11349d8: str             x0, [SP]
    // 0x11349dc: ldur            x1, [fp, #-8]
    // 0x11349e0: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x11349e0: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x11349e4: ldr             x4, [x4, #0x7f0]
    // 0x11349e8: r0 = copyWith()
    //     0x11349e8: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x11349ec: ldur            x2, [fp, #-0x10]
    // 0x11349f0: b               #0x1134a54
    // 0x11349f4: ldr             x1, [fp, #0x10]
    // 0x11349f8: LoadField: r0 = r1->field_67
    //     0x11349f8: ldur            w0, [x1, #0x67]
    // 0x11349fc: DecompressPointer r0
    //     0x11349fc: add             x0, x0, HEAP, lsl #32
    // 0x1134a00: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1134a04: cmp             w0, w16
    // 0x1134a08: b.ne            #0x1134a18
    // 0x1134a0c: r2 = _textTheme
    //     0x1134a0c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26340] Field <_LisTileDefaultsM2@97247952._textTheme@97247952>: late final (offset: 0x68)
    //     0x1134a10: ldr             x2, [x2, #0x340]
    // 0x1134a14: r0 = InitLateFinalInstanceField()
    //     0x1134a14: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1134a18: LoadField: r1 = r0->field_2f
    //     0x1134a18: ldur            w1, [x0, #0x2f]
    // 0x1134a1c: DecompressPointer r1
    //     0x1134a1c: add             x1, x1, HEAP, lsl #32
    // 0x1134a20: cmp             w1, NULL
    // 0x1134a24: b.eq            #0x1134dac
    // 0x1134a28: LoadField: r2 = r0->field_33
    //     0x1134a28: ldur            w2, [x0, #0x33]
    // 0x1134a2c: DecompressPointer r2
    //     0x1134a2c: add             x2, x2, HEAP, lsl #32
    // 0x1134a30: cmp             w2, NULL
    // 0x1134a34: b.eq            #0x1134db0
    // 0x1134a38: LoadField: r0 = r2->field_b
    //     0x1134a38: ldur            w0, [x2, #0xb]
    // 0x1134a3c: DecompressPointer r0
    //     0x1134a3c: add             x0, x0, HEAP, lsl #32
    // 0x1134a40: str             x0, [SP]
    // 0x1134a44: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x1134a44: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x1134a48: ldr             x4, [x4, #0x7f0]
    // 0x1134a4c: r0 = copyWith()
    //     0x1134a4c: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x1134a50: ldur            x2, [fp, #-0x10]
    // 0x1134a54: ldur            x1, [fp, #-0x18]
    // 0x1134a58: ArrayStore: r1[7] = r0  ; List_4
    //     0x1134a58: add             x25, x1, #0x2b
    //     0x1134a5c: str             w0, [x25]
    //     0x1134a60: tbz             w0, #0, #0x1134a7c
    //     0x1134a64: ldurb           w16, [x1, #-1]
    //     0x1134a68: ldurb           w17, [x0, #-1]
    //     0x1134a6c: and             x16, x17, x16, lsr #2
    //     0x1134a70: tst             x16, HEAP, lsr #32
    //     0x1134a74: b.eq            #0x1134a7c
    //     0x1134a78: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1134a7c: r17 = 5141
    //     0x1134a7c: mov             x17, #0x1415
    // 0x1134a80: cmp             x2, x17
    // 0x1134a84: b.ne            #0x1134aa0
    // 0x1134a88: ldr             x0, [fp, #0x10]
    // 0x1134a8c: LoadField: r1 = r0->field_27
    //     0x1134a8c: ldur            w1, [x0, #0x27]
    // 0x1134a90: DecompressPointer r1
    //     0x1134a90: add             x1, x1, HEAP, lsl #32
    // 0x1134a94: mov             x3, x0
    // 0x1134a98: mov             x0, x1
    // 0x1134a9c: b               #0x1134b88
    // 0x1134aa0: ldr             x0, [fp, #0x10]
    // 0x1134aa4: r17 = 5142
    //     0x1134aa4: mov             x17, #0x1416
    // 0x1134aa8: cmp             x2, x17
    // 0x1134aac: b.ne            #0x1134b50
    // 0x1134ab0: mov             x1, x0
    // 0x1134ab4: LoadField: r0 = r1->field_6b
    //     0x1134ab4: ldur            w0, [x1, #0x6b]
    // 0x1134ab8: DecompressPointer r0
    //     0x1134ab8: add             x0, x0, HEAP, lsl #32
    // 0x1134abc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1134ac0: cmp             w0, w16
    // 0x1134ac4: b.ne            #0x1134ad4
    // 0x1134ac8: r2 = _textTheme
    //     0x1134ac8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26338] Field <_LisTileDefaultsM3@97247952._textTheme@97247952>: late final (offset: 0x6c)
    //     0x1134acc: ldr             x2, [x2, #0x338]
    // 0x1134ad0: r0 = InitLateFinalInstanceField()
    //     0x1134ad0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1134ad4: LoadField: r2 = r0->field_3f
    //     0x1134ad4: ldur            w2, [x0, #0x3f]
    // 0x1134ad8: DecompressPointer r2
    //     0x1134ad8: add             x2, x2, HEAP, lsl #32
    // 0x1134adc: stur            x2, [fp, #-8]
    // 0x1134ae0: cmp             w2, NULL
    // 0x1134ae4: b.eq            #0x1134db4
    // 0x1134ae8: ldr             x1, [fp, #0x10]
    // 0x1134aec: LoadField: r0 = r1->field_67
    //     0x1134aec: ldur            w0, [x1, #0x67]
    // 0x1134af0: DecompressPointer r0
    //     0x1134af0: add             x0, x0, HEAP, lsl #32
    // 0x1134af4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1134af8: cmp             w0, w16
    // 0x1134afc: b.ne            #0x1134b0c
    // 0x1134b00: r2 = _colors
    //     0x1134b00: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0x1134b04: ldr             x2, [x2, #0x320]
    // 0x1134b08: r0 = InitLateFinalInstanceField()
    //     0x1134b08: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1134b0c: LoadField: r1 = r0->field_a3
    //     0x1134b0c: ldur            w1, [x0, #0xa3]
    // 0x1134b10: DecompressPointer r1
    //     0x1134b10: add             x1, x1, HEAP, lsl #32
    // 0x1134b14: cmp             w1, NULL
    // 0x1134b18: b.ne            #0x1134b2c
    // 0x1134b1c: LoadField: r1 = r0->field_7f
    //     0x1134b1c: ldur            w1, [x0, #0x7f]
    // 0x1134b20: DecompressPointer r1
    //     0x1134b20: add             x1, x1, HEAP, lsl #32
    // 0x1134b24: mov             x0, x1
    // 0x1134b28: b               #0x1134b30
    // 0x1134b2c: mov             x0, x1
    // 0x1134b30: str             x0, [SP]
    // 0x1134b34: ldur            x1, [fp, #-8]
    // 0x1134b38: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x1134b38: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x1134b3c: ldr             x4, [x4, #0x7f0]
    // 0x1134b40: r0 = copyWith()
    //     0x1134b40: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x1134b44: ldr             x3, [fp, #0x10]
    // 0x1134b48: ldur            x2, [fp, #-0x10]
    // 0x1134b4c: b               #0x1134b88
    // 0x1134b50: ldr             x1, [fp, #0x10]
    // 0x1134b54: LoadField: r0 = r1->field_67
    //     0x1134b54: ldur            w0, [x1, #0x67]
    // 0x1134b58: DecompressPointer r0
    //     0x1134b58: add             x0, x0, HEAP, lsl #32
    // 0x1134b5c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1134b60: cmp             w0, w16
    // 0x1134b64: b.ne            #0x1134b74
    // 0x1134b68: r2 = _textTheme
    //     0x1134b68: add             x2, PP, #0x26, lsl #12  ; [pp+0x26340] Field <_LisTileDefaultsM2@97247952._textTheme@97247952>: late final (offset: 0x68)
    //     0x1134b6c: ldr             x2, [x2, #0x340]
    // 0x1134b70: r0 = InitLateFinalInstanceField()
    //     0x1134b70: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1134b74: LoadField: r1 = r0->field_2f
    //     0x1134b74: ldur            w1, [x0, #0x2f]
    // 0x1134b78: DecompressPointer r1
    //     0x1134b78: add             x1, x1, HEAP, lsl #32
    // 0x1134b7c: mov             x0, x1
    // 0x1134b80: ldr             x3, [fp, #0x10]
    // 0x1134b84: ldur            x2, [fp, #-0x10]
    // 0x1134b88: ldur            x1, [fp, #-0x18]
    // 0x1134b8c: ArrayStore: r1[8] = r0  ; List_4
    //     0x1134b8c: add             x25, x1, #0x2f
    //     0x1134b90: str             w0, [x25]
    //     0x1134b94: tbz             w0, #0, #0x1134bb0
    //     0x1134b98: ldurb           w16, [x1, #-1]
    //     0x1134b9c: ldurb           w17, [x0, #-1]
    //     0x1134ba0: and             x16, x17, x16, lsr #2
    //     0x1134ba4: tst             x16, HEAP, lsr #32
    //     0x1134ba8: b.eq            #0x1134bb0
    //     0x1134bac: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1134bb0: LoadField: r0 = r3->field_2b
    //     0x1134bb0: ldur            w0, [x3, #0x2b]
    // 0x1134bb4: DecompressPointer r0
    //     0x1134bb4: add             x0, x0, HEAP, lsl #32
    // 0x1134bb8: ldur            x1, [fp, #-0x18]
    // 0x1134bbc: ArrayStore: r1[9] = r0  ; List_4
    //     0x1134bbc: add             x25, x1, #0x33
    //     0x1134bc0: str             w0, [x25]
    //     0x1134bc4: tbz             w0, #0, #0x1134be0
    //     0x1134bc8: ldurb           w16, [x1, #-1]
    //     0x1134bcc: ldurb           w17, [x0, #-1]
    //     0x1134bd0: and             x16, x17, x16, lsr #2
    //     0x1134bd4: tst             x16, HEAP, lsr #32
    //     0x1134bd8: b.eq            #0x1134be0
    //     0x1134bdc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1134be0: r17 = 5141
    //     0x1134be0: mov             x17, #0x1415
    // 0x1134be4: cmp             x2, x17
    // 0x1134be8: b.ne            #0x1134bf8
    // 0x1134bec: LoadField: r0 = r3->field_2f
    //     0x1134bec: ldur            w0, [x3, #0x2f]
    // 0x1134bf0: DecompressPointer r0
    //     0x1134bf0: add             x0, x0, HEAP, lsl #32
    // 0x1134bf4: b               #0x1134c18
    // 0x1134bf8: r17 = 5142
    //     0x1134bf8: mov             x17, #0x1416
    // 0x1134bfc: cmp             x2, x17
    // 0x1134c00: b.ne            #0x1134c10
    // 0x1134c04: r0 = Instance_Color
    //     0x1134c04: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1134c08: ldr             x0, [x0, #0x810]
    // 0x1134c0c: b               #0x1134c18
    // 0x1134c10: r0 = Instance_Color
    //     0x1134c10: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1134c14: ldr             x0, [x0, #0x810]
    // 0x1134c18: ldur            x2, [fp, #-0x18]
    // 0x1134c1c: mov             x1, x2
    // 0x1134c20: ArrayStore: r1[10] = r0  ; List_4
    //     0x1134c20: add             x25, x1, #0x37
    //     0x1134c24: str             w0, [x25]
    //     0x1134c28: tbz             w0, #0, #0x1134c44
    //     0x1134c2c: ldurb           w16, [x1, #-1]
    //     0x1134c30: ldurb           w17, [x0, #-1]
    //     0x1134c34: and             x16, x17, x16, lsr #2
    //     0x1134c38: tst             x16, HEAP, lsr #32
    //     0x1134c3c: b.eq            #0x1134c44
    //     0x1134c40: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1134c44: LoadField: r0 = r3->field_33
    //     0x1134c44: ldur            w0, [x3, #0x33]
    // 0x1134c48: DecompressPointer r0
    //     0x1134c48: add             x0, x0, HEAP, lsl #32
    // 0x1134c4c: StoreField: r2->field_3b = r0
    //     0x1134c4c: stur            w0, [x2, #0x3b]
    // 0x1134c50: LoadField: r0 = r3->field_37
    //     0x1134c50: ldur            w0, [x3, #0x37]
    // 0x1134c54: DecompressPointer r0
    //     0x1134c54: add             x0, x0, HEAP, lsl #32
    // 0x1134c58: mov             x1, x2
    // 0x1134c5c: ArrayStore: r1[12] = r0  ; List_4
    //     0x1134c5c: add             x25, x1, #0x3f
    //     0x1134c60: str             w0, [x25]
    //     0x1134c64: tbz             w0, #0, #0x1134c80
    //     0x1134c68: ldurb           w16, [x1, #-1]
    //     0x1134c6c: ldurb           w17, [x0, #-1]
    //     0x1134c70: and             x16, x17, x16, lsr #2
    //     0x1134c74: tst             x16, HEAP, lsr #32
    //     0x1134c78: b.eq            #0x1134c80
    //     0x1134c7c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1134c80: LoadField: r0 = r3->field_3b
    //     0x1134c80: ldur            w0, [x3, #0x3b]
    // 0x1134c84: DecompressPointer r0
    //     0x1134c84: add             x0, x0, HEAP, lsl #32
    // 0x1134c88: mov             x1, x2
    // 0x1134c8c: ArrayStore: r1[13] = r0  ; List_4
    //     0x1134c8c: add             x25, x1, #0x43
    //     0x1134c90: str             w0, [x25]
    //     0x1134c94: tbz             w0, #0, #0x1134cb0
    //     0x1134c98: ldurb           w16, [x1, #-1]
    //     0x1134c9c: ldurb           w17, [x0, #-1]
    //     0x1134ca0: and             x16, x17, x16, lsr #2
    //     0x1134ca4: tst             x16, HEAP, lsr #32
    //     0x1134ca8: b.eq            #0x1134cb0
    //     0x1134cac: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1134cb0: LoadField: r0 = r3->field_3f
    //     0x1134cb0: ldur            w0, [x3, #0x3f]
    // 0x1134cb4: DecompressPointer r0
    //     0x1134cb4: add             x0, x0, HEAP, lsl #32
    // 0x1134cb8: mov             x1, x2
    // 0x1134cbc: ArrayStore: r1[14] = r0  ; List_4
    //     0x1134cbc: add             x25, x1, #0x47
    //     0x1134cc0: str             w0, [x25]
    //     0x1134cc4: tbz             w0, #0, #0x1134ce0
    //     0x1134cc8: ldurb           w16, [x1, #-1]
    //     0x1134ccc: ldurb           w17, [x0, #-1]
    //     0x1134cd0: and             x16, x17, x16, lsr #2
    //     0x1134cd4: tst             x16, HEAP, lsr #32
    //     0x1134cd8: b.eq            #0x1134ce0
    //     0x1134cdc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1134ce0: LoadField: r0 = r3->field_43
    //     0x1134ce0: ldur            w0, [x3, #0x43]
    // 0x1134ce4: DecompressPointer r0
    //     0x1134ce4: add             x0, x0, HEAP, lsl #32
    // 0x1134ce8: mov             x1, x2
    // 0x1134cec: ArrayStore: r1[15] = r0  ; List_4
    //     0x1134cec: add             x25, x1, #0x4b
    //     0x1134cf0: str             w0, [x25]
    //     0x1134cf4: tbz             w0, #0, #0x1134d10
    //     0x1134cf8: ldurb           w16, [x1, #-1]
    //     0x1134cfc: ldurb           w17, [x0, #-1]
    //     0x1134d00: and             x16, x17, x16, lsr #2
    //     0x1134d04: tst             x16, HEAP, lsr #32
    //     0x1134d08: b.eq            #0x1134d10
    //     0x1134d0c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1134d10: LoadField: r0 = r3->field_47
    //     0x1134d10: ldur            w0, [x3, #0x47]
    // 0x1134d14: DecompressPointer r0
    //     0x1134d14: add             x0, x0, HEAP, lsl #32
    // 0x1134d18: StoreField: r2->field_4f = r0
    //     0x1134d18: stur            w0, [x2, #0x4f]
    // 0x1134d1c: LoadField: r0 = r3->field_4b
    //     0x1134d1c: ldur            w0, [x3, #0x4b]
    // 0x1134d20: DecompressPointer r0
    //     0x1134d20: add             x0, x0, HEAP, lsl #32
    // 0x1134d24: StoreField: r2->field_53 = r0
    //     0x1134d24: stur            w0, [x2, #0x53]
    // 0x1134d28: LoadField: r0 = r3->field_4f
    //     0x1134d28: ldur            w0, [x3, #0x4f]
    // 0x1134d2c: DecompressPointer r0
    //     0x1134d2c: add             x0, x0, HEAP, lsl #32
    // 0x1134d30: StoreField: r2->field_57 = r0
    //     0x1134d30: stur            w0, [x2, #0x57]
    // 0x1134d34: LoadField: r0 = r3->field_53
    //     0x1134d34: ldur            w0, [x3, #0x53]
    // 0x1134d38: DecompressPointer r0
    //     0x1134d38: add             x0, x0, HEAP, lsl #32
    // 0x1134d3c: StoreField: r2->field_5b = r0
    //     0x1134d3c: stur            w0, [x2, #0x5b]
    // 0x1134d40: LoadField: r0 = r3->field_57
    //     0x1134d40: ldur            w0, [x3, #0x57]
    // 0x1134d44: DecompressPointer r0
    //     0x1134d44: add             x0, x0, HEAP, lsl #32
    // 0x1134d48: StoreField: r2->field_5f = r0
    //     0x1134d48: stur            w0, [x2, #0x5f]
    // 0x1134d4c: LoadField: r0 = r3->field_5b
    //     0x1134d4c: ldur            w0, [x3, #0x5b]
    // 0x1134d50: DecompressPointer r0
    //     0x1134d50: add             x0, x0, HEAP, lsl #32
    // 0x1134d54: StoreField: r2->field_63 = r0
    //     0x1134d54: stur            w0, [x2, #0x63]
    // 0x1134d58: r1 = <Object?>
    //     0x1134d58: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x1134d5c: r0 = AllocateGrowableArray()
    //     0x1134d5c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x1134d60: mov             x1, x0
    // 0x1134d64: ldur            x0, [fp, #-0x18]
    // 0x1134d68: StoreField: r1->field_f = r0
    //     0x1134d68: stur            w0, [x1, #0xf]
    // 0x1134d6c: r0 = 44
    //     0x1134d6c: mov             x0, #0x2c
    // 0x1134d70: StoreField: r1->field_b = r0
    //     0x1134d70: stur            w0, [x1, #0xb]
    // 0x1134d74: r0 = hashAll()
    //     0x1134d74: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x1134d78: mov             x2, x0
    // 0x1134d7c: r0 = BoxInt64Instr(r2)
    //     0x1134d7c: sbfiz           x0, x2, #1, #0x1f
    //     0x1134d80: cmp             x2, x0, asr #1
    //     0x1134d84: b.eq            #0x1134d90
    //     0x1134d88: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1134d8c: stur            x2, [x0, #7]
    // 0x1134d90: LeaveFrame
    //     0x1134d90: mov             SP, fp
    //     0x1134d94: ldp             fp, lr, [SP], #0x10
    // 0x1134d98: ret
    //     0x1134d98: ret             
    // 0x1134d9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1134d9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1134da0: b               #0x1134590
    // 0x1134da4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1134da4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1134da8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1134da8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1134dac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1134dac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1134db0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1134db0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1134db4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1134db4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1166b08, size: 0x2e4
    // 0x1166b08: EnterFrame
    //     0x1166b08: stp             fp, lr, [SP, #-0x10]!
    //     0x1166b0c: mov             fp, SP
    // 0x1166b10: AllocStack(0x68)
    //     0x1166b10: sub             SP, SP, #0x68
    // 0x1166b14: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x68 */)
    //     0x1166b14: mov             x3, x1
    //     0x1166b18: mov             x0, x2
    //     0x1166b1c: mov             v1.16b, v0.16b
    //     0x1166b20: stur            x1, [fp, #-8]
    //     0x1166b24: stur            x2, [fp, #-0x10]
    //     0x1166b28: stur            d0, [fp, #-0x68]
    // 0x1166b2c: CheckStackOverflow
    //     0x1166b2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1166b30: cmp             SP, x16
    //     0x1166b34: b.ls            #0x1166dc0
    // 0x1166b38: cmp             w3, w0
    // 0x1166b3c: b.ne            #0x1166b50
    // 0x1166b40: mov             x0, x3
    // 0x1166b44: LeaveFrame
    //     0x1166b44: mov             SP, fp
    //     0x1166b48: ldp             fp, lr, [SP], #0x10
    // 0x1166b4c: ret
    //     0x1166b4c: ret             
    // 0x1166b50: LoadField: r1 = r3->field_b
    //     0x1166b50: ldur            w1, [x3, #0xb]
    // 0x1166b54: DecompressPointer r1
    //     0x1166b54: add             x1, x1, HEAP, lsl #32
    // 0x1166b58: LoadField: r2 = r0->field_b
    //     0x1166b58: ldur            w2, [x0, #0xb]
    // 0x1166b5c: DecompressPointer r2
    //     0x1166b5c: add             x2, x2, HEAP, lsl #32
    // 0x1166b60: mov             v0.16b, v1.16b
    // 0x1166b64: r0 = lerp()
    //     0x1166b64: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x1166b68: ldur            d0, [fp, #-0x68]
    // 0x1166b6c: d1 = 0.500000
    //     0x1166b6c: fmov            d1, #0.50000000
    // 0x1166b70: stur            x0, [fp, #-0x28]
    // 0x1166b74: fcmp            d1, d0
    // 0x1166b78: b.le            #0x1166b94
    // 0x1166b7c: ldur            x4, [fp, #-8]
    // 0x1166b80: LoadField: r1 = r4->field_f
    //     0x1166b80: ldur            w1, [x4, #0xf]
    // 0x1166b84: DecompressPointer r1
    //     0x1166b84: add             x1, x1, HEAP, lsl #32
    // 0x1166b88: mov             x6, x1
    // 0x1166b8c: ldur            x5, [fp, #-0x10]
    // 0x1166b90: b               #0x1166ba8
    // 0x1166b94: ldur            x4, [fp, #-8]
    // 0x1166b98: ldur            x5, [fp, #-0x10]
    // 0x1166b9c: LoadField: r1 = r5->field_f
    //     0x1166b9c: ldur            w1, [x5, #0xf]
    // 0x1166ba0: DecompressPointer r1
    //     0x1166ba0: add             x1, x1, HEAP, lsl #32
    // 0x1166ba4: mov             x6, x1
    // 0x1166ba8: stur            x6, [fp, #-0x20]
    // 0x1166bac: r7 = inline_Allocate_Double()
    //     0x1166bac: ldp             x7, x1, [THR, #0x60]  ; THR::top
    //     0x1166bb0: add             x7, x7, #0x10
    //     0x1166bb4: cmp             x1, x7
    //     0x1166bb8: b.ls            #0x1166dc8
    //     0x1166bbc: str             x7, [THR, #0x60]  ; THR::top
    //     0x1166bc0: sub             x7, x7, #0xf
    //     0x1166bc4: mov             x1, #0xe19c
    //     0x1166bc8: movk            x1, #3, lsl #16
    //     0x1166bcc: stur            x1, [x7, #-1]
    // 0x1166bd0: dmb             ishst
    // 0x1166bd4: StoreField: r7->field_7 = d0
    //     0x1166bd4: stur            d0, [x7, #7]
    // 0x1166bd8: mov             x3, x7
    // 0x1166bdc: stur            x7, [fp, #-0x18]
    // 0x1166be0: r1 = Null
    //     0x1166be0: mov             x1, NULL
    // 0x1166be4: r2 = Null
    //     0x1166be4: mov             x2, NULL
    // 0x1166be8: r0 = lerp()
    //     0x1166be8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1166bec: ldur            x0, [fp, #-8]
    // 0x1166bf0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1166bf0: ldur            w1, [x0, #0x17]
    // 0x1166bf4: DecompressPointer r1
    //     0x1166bf4: add             x1, x1, HEAP, lsl #32
    // 0x1166bf8: ldur            x4, [fp, #-0x10]
    // 0x1166bfc: ArrayLoad: r2 = r4[0]  ; List_4
    //     0x1166bfc: ldur            w2, [x4, #0x17]
    // 0x1166c00: DecompressPointer r2
    //     0x1166c00: add             x2, x2, HEAP, lsl #32
    // 0x1166c04: ldur            x3, [fp, #-0x18]
    // 0x1166c08: r0 = lerp()
    //     0x1166c08: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1166c0c: mov             x4, x0
    // 0x1166c10: ldur            x0, [fp, #-8]
    // 0x1166c14: stur            x4, [fp, #-0x30]
    // 0x1166c18: LoadField: r1 = r0->field_1b
    //     0x1166c18: ldur            w1, [x0, #0x1b]
    // 0x1166c1c: DecompressPointer r1
    //     0x1166c1c: add             x1, x1, HEAP, lsl #32
    // 0x1166c20: ldur            x5, [fp, #-0x10]
    // 0x1166c24: LoadField: r2 = r5->field_1b
    //     0x1166c24: ldur            w2, [x5, #0x1b]
    // 0x1166c28: DecompressPointer r2
    //     0x1166c28: add             x2, x2, HEAP, lsl #32
    // 0x1166c2c: ldur            x3, [fp, #-0x18]
    // 0x1166c30: r0 = lerp()
    //     0x1166c30: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1166c34: mov             x4, x0
    // 0x1166c38: ldur            x0, [fp, #-8]
    // 0x1166c3c: stur            x4, [fp, #-0x38]
    // 0x1166c40: LoadField: r1 = r0->field_1f
    //     0x1166c40: ldur            w1, [x0, #0x1f]
    // 0x1166c44: DecompressPointer r1
    //     0x1166c44: add             x1, x1, HEAP, lsl #32
    // 0x1166c48: ldur            x5, [fp, #-0x10]
    // 0x1166c4c: LoadField: r2 = r5->field_1f
    //     0x1166c4c: ldur            w2, [x5, #0x1f]
    // 0x1166c50: DecompressPointer r2
    //     0x1166c50: add             x2, x2, HEAP, lsl #32
    // 0x1166c54: ldur            x3, [fp, #-0x18]
    // 0x1166c58: r0 = lerp()
    //     0x1166c58: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1166c5c: ldur            x3, [fp, #-0x18]
    // 0x1166c60: r1 = Null
    //     0x1166c60: mov             x1, NULL
    // 0x1166c64: r2 = Null
    //     0x1166c64: mov             x2, NULL
    // 0x1166c68: stur            x0, [fp, #-0x40]
    // 0x1166c6c: r0 = lerp()
    //     0x1166c6c: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1166c70: ldur            x3, [fp, #-0x18]
    // 0x1166c74: r1 = Null
    //     0x1166c74: mov             x1, NULL
    // 0x1166c78: r2 = Null
    //     0x1166c78: mov             x2, NULL
    // 0x1166c7c: r0 = lerp()
    //     0x1166c7c: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1166c80: ldur            x0, [fp, #-8]
    // 0x1166c84: LoadField: r1 = r0->field_2b
    //     0x1166c84: ldur            w1, [x0, #0x2b]
    // 0x1166c88: DecompressPointer r1
    //     0x1166c88: add             x1, x1, HEAP, lsl #32
    // 0x1166c8c: ldur            x4, [fp, #-0x10]
    // 0x1166c90: LoadField: r2 = r4->field_2b
    //     0x1166c90: ldur            w2, [x4, #0x2b]
    // 0x1166c94: DecompressPointer r2
    //     0x1166c94: add             x2, x2, HEAP, lsl #32
    // 0x1166c98: ldur            x3, [fp, #-0x18]
    // 0x1166c9c: r0 = lerp()
    //     0x1166c9c: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x1166ca0: ldur            x3, [fp, #-0x18]
    // 0x1166ca4: r1 = Null
    //     0x1166ca4: mov             x1, NULL
    // 0x1166ca8: r2 = Null
    //     0x1166ca8: mov             x2, NULL
    // 0x1166cac: stur            x0, [fp, #-0x48]
    // 0x1166cb0: r0 = lerp()
    //     0x1166cb0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1166cb4: ldur            x3, [fp, #-0x18]
    // 0x1166cb8: r1 = Null
    //     0x1166cb8: mov             x1, NULL
    // 0x1166cbc: r2 = Null
    //     0x1166cbc: mov             x2, NULL
    // 0x1166cc0: r0 = lerp()
    //     0x1166cc0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1166cc4: ldur            x0, [fp, #-8]
    // 0x1166cc8: LoadField: r1 = r0->field_37
    //     0x1166cc8: ldur            w1, [x0, #0x37]
    // 0x1166ccc: DecompressPointer r1
    //     0x1166ccc: add             x1, x1, HEAP, lsl #32
    // 0x1166cd0: ldur            x4, [fp, #-0x10]
    // 0x1166cd4: LoadField: r2 = r4->field_37
    //     0x1166cd4: ldur            w2, [x4, #0x37]
    // 0x1166cd8: DecompressPointer r2
    //     0x1166cd8: add             x2, x2, HEAP, lsl #32
    // 0x1166cdc: ldur            x3, [fp, #-0x18]
    // 0x1166ce0: r0 = lerpDouble()
    //     0x1166ce0: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1166ce4: mov             x4, x0
    // 0x1166ce8: ldur            x0, [fp, #-8]
    // 0x1166cec: stur            x4, [fp, #-0x50]
    // 0x1166cf0: LoadField: r1 = r0->field_3b
    //     0x1166cf0: ldur            w1, [x0, #0x3b]
    // 0x1166cf4: DecompressPointer r1
    //     0x1166cf4: add             x1, x1, HEAP, lsl #32
    // 0x1166cf8: ldur            x5, [fp, #-0x10]
    // 0x1166cfc: LoadField: r2 = r5->field_3b
    //     0x1166cfc: ldur            w2, [x5, #0x3b]
    // 0x1166d00: DecompressPointer r2
    //     0x1166d00: add             x2, x2, HEAP, lsl #32
    // 0x1166d04: ldur            x3, [fp, #-0x18]
    // 0x1166d08: r0 = lerpDouble()
    //     0x1166d08: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1166d0c: mov             x4, x0
    // 0x1166d10: ldur            x0, [fp, #-8]
    // 0x1166d14: stur            x4, [fp, #-0x58]
    // 0x1166d18: LoadField: r1 = r0->field_3f
    //     0x1166d18: ldur            w1, [x0, #0x3f]
    // 0x1166d1c: DecompressPointer r1
    //     0x1166d1c: add             x1, x1, HEAP, lsl #32
    // 0x1166d20: ldur            x5, [fp, #-0x10]
    // 0x1166d24: LoadField: r2 = r5->field_3f
    //     0x1166d24: ldur            w2, [x5, #0x3f]
    // 0x1166d28: DecompressPointer r2
    //     0x1166d28: add             x2, x2, HEAP, lsl #32
    // 0x1166d2c: ldur            x3, [fp, #-0x18]
    // 0x1166d30: r0 = lerpDouble()
    //     0x1166d30: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1166d34: mov             x4, x0
    // 0x1166d38: ldur            x0, [fp, #-8]
    // 0x1166d3c: stur            x4, [fp, #-0x60]
    // 0x1166d40: LoadField: r1 = r0->field_43
    //     0x1166d40: ldur            w1, [x0, #0x43]
    // 0x1166d44: DecompressPointer r1
    //     0x1166d44: add             x1, x1, HEAP, lsl #32
    // 0x1166d48: ldur            x0, [fp, #-0x10]
    // 0x1166d4c: LoadField: r2 = r0->field_43
    //     0x1166d4c: ldur            w2, [x0, #0x43]
    // 0x1166d50: DecompressPointer r2
    //     0x1166d50: add             x2, x2, HEAP, lsl #32
    // 0x1166d54: ldur            x3, [fp, #-0x18]
    // 0x1166d58: r0 = lerpDouble()
    //     0x1166d58: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1166d5c: stur            x0, [fp, #-8]
    // 0x1166d60: r0 = ListTileThemeData()
    //     0x1166d60: bl              #0xd1a0d8  ; AllocateListTileThemeDataStub -> ListTileThemeData (size=0x60)
    // 0x1166d64: ldur            x1, [fp, #-0x28]
    // 0x1166d68: StoreField: r0->field_b = r1
    //     0x1166d68: stur            w1, [x0, #0xb]
    // 0x1166d6c: ldur            x1, [fp, #-0x20]
    // 0x1166d70: StoreField: r0->field_f = r1
    //     0x1166d70: stur            w1, [x0, #0xf]
    // 0x1166d74: ldur            x1, [fp, #-0x30]
    // 0x1166d78: ArrayStore: r0[0] = r1  ; List_4
    //     0x1166d78: stur            w1, [x0, #0x17]
    // 0x1166d7c: ldur            x1, [fp, #-0x38]
    // 0x1166d80: StoreField: r0->field_1b = r1
    //     0x1166d80: stur            w1, [x0, #0x1b]
    // 0x1166d84: ldur            x1, [fp, #-0x40]
    // 0x1166d88: StoreField: r0->field_1f = r1
    //     0x1166d88: stur            w1, [x0, #0x1f]
    // 0x1166d8c: ldur            x1, [fp, #-0x48]
    // 0x1166d90: StoreField: r0->field_2b = r1
    //     0x1166d90: stur            w1, [x0, #0x2b]
    // 0x1166d94: ldur            x1, [fp, #-0x50]
    // 0x1166d98: StoreField: r0->field_37 = r1
    //     0x1166d98: stur            w1, [x0, #0x37]
    // 0x1166d9c: ldur            x1, [fp, #-0x58]
    // 0x1166da0: StoreField: r0->field_3b = r1
    //     0x1166da0: stur            w1, [x0, #0x3b]
    // 0x1166da4: ldur            x1, [fp, #-0x60]
    // 0x1166da8: StoreField: r0->field_3f = r1
    //     0x1166da8: stur            w1, [x0, #0x3f]
    // 0x1166dac: ldur            x1, [fp, #-8]
    // 0x1166db0: StoreField: r0->field_43 = r1
    //     0x1166db0: stur            w1, [x0, #0x43]
    // 0x1166db4: LeaveFrame
    //     0x1166db4: mov             SP, fp
    //     0x1166db8: ldp             fp, lr, [SP], #0x10
    // 0x1166dbc: ret
    //     0x1166dbc: ret             
    // 0x1166dc0: r0 = StackOverflowSharedWithFPURegs()
    //     0x1166dc0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1166dc4: b               #0x1166b38
    // 0x1166dc8: SaveReg d0
    //     0x1166dc8: str             q0, [SP, #-0x10]!
    // 0x1166dcc: stp             x5, x6, [SP, #-0x10]!
    // 0x1166dd0: stp             x0, x4, [SP, #-0x10]!
    // 0x1166dd4: r0 = AllocateDouble()
    //     0x1166dd4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1166dd8: mov             x7, x0
    // 0x1166ddc: ldp             x0, x4, [SP], #0x10
    // 0x1166de0: ldp             x5, x6, [SP], #0x10
    // 0x1166de4: RestoreReg d0
    //     0x1166de4: ldr             q0, [SP], #0x10
    // 0x1166de8: b               #0x1166bd4
  }
  _ ==(/* No info */) {
    // ** addr: 0x126ec80, size: 0xdb4
    // 0x126ec80: EnterFrame
    //     0x126ec80: stp             fp, lr, [SP, #-0x10]!
    //     0x126ec84: mov             fp, SP
    // 0x126ec88: AllocStack(0x38)
    //     0x126ec88: sub             SP, SP, #0x38
    // 0x126ec8c: CheckStackOverflow
    //     0x126ec8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x126ec90: cmp             SP, x16
    //     0x126ec94: b.ls            #0x126fa04
    // 0x126ec98: ldr             x1, [fp, #0x10]
    // 0x126ec9c: cmp             w1, NULL
    // 0x126eca0: b.ne            #0x126ecb4
    // 0x126eca4: r0 = false
    //     0x126eca4: add             x0, NULL, #0x30  ; false
    // 0x126eca8: LeaveFrame
    //     0x126eca8: mov             SP, fp
    //     0x126ecac: ldp             fp, lr, [SP], #0x10
    // 0x126ecb0: ret
    //     0x126ecb0: ret             
    // 0x126ecb4: ldr             x0, [fp, #0x18]
    // 0x126ecb8: cmp             w0, w1
    // 0x126ecbc: b.ne            #0x126ecd0
    // 0x126ecc0: r0 = true
    //     0x126ecc0: add             x0, NULL, #0x20  ; true
    // 0x126ecc4: LeaveFrame
    //     0x126ecc4: mov             SP, fp
    //     0x126ecc8: ldp             fp, lr, [SP], #0x10
    // 0x126eccc: ret
    //     0x126eccc: ret             
    // 0x126ecd0: stp             x0, x1, [SP]
    // 0x126ecd4: r0 = _haveSameRuntimeType()
    //     0x126ecd4: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x126ecd8: tbz             w0, #4, #0x126ecec
    // 0x126ecdc: r0 = false
    //     0x126ecdc: add             x0, NULL, #0x30  ; false
    // 0x126ece0: LeaveFrame
    //     0x126ece0: mov             SP, fp
    //     0x126ece4: ldp             fp, lr, [SP], #0x10
    // 0x126ece8: ret
    //     0x126ece8: ret             
    // 0x126ecec: ldr             x1, [fp, #0x10]
    // 0x126ecf0: r2 = 60
    //     0x126ecf0: mov             x2, #0x3c
    // 0x126ecf4: branchIfSmi(r1, 0x126ed00)
    //     0x126ecf4: tbz             w1, #0, #0x126ed00
    // 0x126ecf8: r2 = LoadClassIdInstr(r1)
    //     0x126ecf8: ldur            x2, [x1, #-1]
    //     0x126ecfc: ubfx            x2, x2, #0xc, #0x14
    // 0x126ed00: stur            x2, [fp, #-8]
    // 0x126ed04: r17 = -5141
    //     0x126ed04: mov             x17, #-0x1415
    // 0x126ed08: add             x16, x2, x17
    // 0x126ed0c: cmp             x16, #2
    // 0x126ed10: b.hi            #0x126f9f4
    // 0x126ed14: ldr             x3, [fp, #0x18]
    // 0x126ed18: LoadField: r0 = r1->field_b
    //     0x126ed18: ldur            w0, [x1, #0xb]
    // 0x126ed1c: DecompressPointer r0
    //     0x126ed1c: add             x0, x0, HEAP, lsl #32
    // 0x126ed20: LoadField: r4 = r3->field_b
    //     0x126ed20: ldur            w4, [x3, #0xb]
    // 0x126ed24: DecompressPointer r4
    //     0x126ed24: add             x4, x4, HEAP, lsl #32
    // 0x126ed28: r5 = LoadClassIdInstr(r0)
    //     0x126ed28: ldur            x5, [x0, #-1]
    //     0x126ed2c: ubfx            x5, x5, #0xc, #0x14
    // 0x126ed30: stp             x4, x0, [SP]
    // 0x126ed34: mov             x0, x5
    // 0x126ed38: mov             lr, x0
    // 0x126ed3c: ldr             lr, [x21, lr, lsl #3]
    // 0x126ed40: blr             lr
    // 0x126ed44: tbnz            w0, #4, #0x126f9f4
    // 0x126ed48: ldr             x2, [fp, #0x18]
    // 0x126ed4c: ldr             x0, [fp, #0x10]
    // 0x126ed50: LoadField: r3 = r0->field_f
    //     0x126ed50: ldur            w3, [x0, #0xf]
    // 0x126ed54: DecompressPointer r3
    //     0x126ed54: add             x3, x3, HEAP, lsl #32
    // 0x126ed58: stur            x3, [fp, #-0x18]
    // 0x126ed5c: LoadField: r4 = r2->field_f
    //     0x126ed5c: ldur            w4, [x2, #0xf]
    // 0x126ed60: DecompressPointer r4
    //     0x126ed60: add             x4, x4, HEAP, lsl #32
    // 0x126ed64: stur            x4, [fp, #-0x10]
    // 0x126ed68: cmp             w3, w4
    // 0x126ed6c: b.ne            #0x126f9f4
    // 0x126ed70: ldur            x5, [fp, #-8]
    // 0x126ed74: r17 = 5141
    //     0x126ed74: mov             x17, #0x1415
    // 0x126ed78: cmp             x5, x17
    // 0x126ed7c: b.ne            #0x126ed94
    // 0x126ed80: LoadField: r1 = r0->field_13
    //     0x126ed80: ldur            w1, [x0, #0x13]
    // 0x126ed84: DecompressPointer r1
    //     0x126ed84: add             x1, x1, HEAP, lsl #32
    // 0x126ed88: mov             x0, x2
    // 0x126ed8c: mov             x2, x1
    // 0x126ed90: b               #0x126ee14
    // 0x126ed94: r17 = 5142
    //     0x126ed94: mov             x17, #0x1416
    // 0x126ed98: cmp             x5, x17
    // 0x126ed9c: b.ne            #0x126edd8
    // 0x126eda0: mov             x1, x0
    // 0x126eda4: LoadField: r0 = r1->field_67
    //     0x126eda4: ldur            w0, [x1, #0x67]
    // 0x126eda8: DecompressPointer r0
    //     0x126eda8: add             x0, x0, HEAP, lsl #32
    // 0x126edac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126edb0: cmp             w0, w16
    // 0x126edb4: b.ne            #0x126edc4
    // 0x126edb8: r2 = _colors
    //     0x126edb8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0x126edbc: ldr             x2, [x2, #0x320]
    // 0x126edc0: r0 = InitLateFinalInstanceField()
    //     0x126edc0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126edc4: LoadField: r1 = r0->field_b
    //     0x126edc4: ldur            w1, [x0, #0xb]
    // 0x126edc8: DecompressPointer r1
    //     0x126edc8: add             x1, x1, HEAP, lsl #32
    // 0x126edcc: mov             x2, x1
    // 0x126edd0: ldr             x0, [fp, #0x18]
    // 0x126edd4: b               #0x126ee14
    // 0x126edd8: ldr             x1, [fp, #0x10]
    // 0x126eddc: LoadField: r0 = r1->field_63
    //     0x126eddc: ldur            w0, [x1, #0x63]
    // 0x126ede0: DecompressPointer r0
    //     0x126ede0: add             x0, x0, HEAP, lsl #32
    // 0x126ede4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126ede8: cmp             w0, w16
    // 0x126edec: b.ne            #0x126edfc
    // 0x126edf0: r2 = _theme
    //     0x126edf0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26328] Field <_LisTileDefaultsM2@97247952._theme@97247952>: late final (offset: 0x64)
    //     0x126edf4: ldr             x2, [x2, #0x328]
    // 0x126edf8: r0 = InitLateFinalInstanceField()
    //     0x126edf8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126edfc: LoadField: r1 = r0->field_3f
    //     0x126edfc: ldur            w1, [x0, #0x3f]
    // 0x126ee00: DecompressPointer r1
    //     0x126ee00: add             x1, x1, HEAP, lsl #32
    // 0x126ee04: LoadField: r0 = r1->field_b
    //     0x126ee04: ldur            w0, [x1, #0xb]
    // 0x126ee08: DecompressPointer r0
    //     0x126ee08: add             x0, x0, HEAP, lsl #32
    // 0x126ee0c: mov             x2, x0
    // 0x126ee10: ldr             x0, [fp, #0x18]
    // 0x126ee14: stur            x2, [fp, #-0x28]
    // 0x126ee18: r3 = LoadClassIdInstr(r0)
    //     0x126ee18: ldur            x3, [x0, #-1]
    //     0x126ee1c: ubfx            x3, x3, #0xc, #0x14
    // 0x126ee20: stur            x3, [fp, #-0x20]
    // 0x126ee24: r17 = 5141
    //     0x126ee24: mov             x17, #0x1415
    // 0x126ee28: cmp             x3, x17
    // 0x126ee2c: b.ne            #0x126ee40
    // 0x126ee30: LoadField: r1 = r0->field_13
    //     0x126ee30: ldur            w1, [x0, #0x13]
    // 0x126ee34: DecompressPointer r1
    //     0x126ee34: add             x1, x1, HEAP, lsl #32
    // 0x126ee38: mov             x0, x2
    // 0x126ee3c: b               #0x126eebc
    // 0x126ee40: r17 = 5142
    //     0x126ee40: mov             x17, #0x1416
    // 0x126ee44: cmp             x3, x17
    // 0x126ee48: b.ne            #0x126ee80
    // 0x126ee4c: mov             x1, x0
    // 0x126ee50: LoadField: r0 = r1->field_67
    //     0x126ee50: ldur            w0, [x1, #0x67]
    // 0x126ee54: DecompressPointer r0
    //     0x126ee54: add             x0, x0, HEAP, lsl #32
    // 0x126ee58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126ee5c: cmp             w0, w16
    // 0x126ee60: b.ne            #0x126ee70
    // 0x126ee64: r2 = _colors
    //     0x126ee64: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0x126ee68: ldr             x2, [x2, #0x320]
    // 0x126ee6c: r0 = InitLateFinalInstanceField()
    //     0x126ee6c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126ee70: LoadField: r1 = r0->field_b
    //     0x126ee70: ldur            w1, [x0, #0xb]
    // 0x126ee74: DecompressPointer r1
    //     0x126ee74: add             x1, x1, HEAP, lsl #32
    // 0x126ee78: ldur            x0, [fp, #-0x28]
    // 0x126ee7c: b               #0x126eebc
    // 0x126ee80: ldr             x1, [fp, #0x18]
    // 0x126ee84: LoadField: r0 = r1->field_63
    //     0x126ee84: ldur            w0, [x1, #0x63]
    // 0x126ee88: DecompressPointer r0
    //     0x126ee88: add             x0, x0, HEAP, lsl #32
    // 0x126ee8c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126ee90: cmp             w0, w16
    // 0x126ee94: b.ne            #0x126eea4
    // 0x126ee98: r2 = _theme
    //     0x126ee98: add             x2, PP, #0x26, lsl #12  ; [pp+0x26328] Field <_LisTileDefaultsM2@97247952._theme@97247952>: late final (offset: 0x64)
    //     0x126ee9c: ldr             x2, [x2, #0x328]
    // 0x126eea0: r0 = InitLateFinalInstanceField()
    //     0x126eea0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126eea4: LoadField: r1 = r0->field_3f
    //     0x126eea4: ldur            w1, [x0, #0x3f]
    // 0x126eea8: DecompressPointer r1
    //     0x126eea8: add             x1, x1, HEAP, lsl #32
    // 0x126eeac: LoadField: r0 = r1->field_b
    //     0x126eeac: ldur            w0, [x1, #0xb]
    // 0x126eeb0: DecompressPointer r0
    //     0x126eeb0: add             x0, x0, HEAP, lsl #32
    // 0x126eeb4: mov             x1, x0
    // 0x126eeb8: ldur            x0, [fp, #-0x28]
    // 0x126eebc: r2 = LoadClassIdInstr(r0)
    //     0x126eebc: ldur            x2, [x0, #-1]
    //     0x126eec0: ubfx            x2, x2, #0xc, #0x14
    // 0x126eec4: stp             x1, x0, [SP]
    // 0x126eec8: mov             x0, x2
    // 0x126eecc: mov             lr, x0
    // 0x126eed0: ldr             lr, [x21, lr, lsl #3]
    // 0x126eed4: blr             lr
    // 0x126eed8: tbnz            w0, #4, #0x126f9f4
    // 0x126eedc: ldur            x0, [fp, #-8]
    // 0x126eee0: r17 = 5141
    //     0x126eee0: mov             x17, #0x1415
    // 0x126eee4: cmp             x0, x17
    // 0x126eee8: b.ne            #0x126ef00
    // 0x126eeec: ldr             x2, [fp, #0x10]
    // 0x126eef0: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x126eef0: ldur            w1, [x2, #0x17]
    // 0x126eef4: DecompressPointer r1
    //     0x126eef4: add             x1, x1, HEAP, lsl #32
    // 0x126eef8: mov             x2, x1
    // 0x126eefc: b               #0x126efb4
    // 0x126ef00: ldr             x2, [fp, #0x10]
    // 0x126ef04: r17 = 5142
    //     0x126ef04: mov             x17, #0x1416
    // 0x126ef08: cmp             x0, x17
    // 0x126ef0c: b.ne            #0x126ef60
    // 0x126ef10: mov             x1, x2
    // 0x126ef14: LoadField: r0 = r1->field_67
    //     0x126ef14: ldur            w0, [x1, #0x67]
    // 0x126ef18: DecompressPointer r0
    //     0x126ef18: add             x0, x0, HEAP, lsl #32
    // 0x126ef1c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126ef20: cmp             w0, w16
    // 0x126ef24: b.ne            #0x126ef34
    // 0x126ef28: r2 = _colors
    //     0x126ef28: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0x126ef2c: ldr             x2, [x2, #0x320]
    // 0x126ef30: r0 = InitLateFinalInstanceField()
    //     0x126ef30: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126ef34: LoadField: r1 = r0->field_a3
    //     0x126ef34: ldur            w1, [x0, #0xa3]
    // 0x126ef38: DecompressPointer r1
    //     0x126ef38: add             x1, x1, HEAP, lsl #32
    // 0x126ef3c: cmp             w1, NULL
    // 0x126ef40: b.ne            #0x126ef54
    // 0x126ef44: LoadField: r1 = r0->field_7f
    //     0x126ef44: ldur            w1, [x0, #0x7f]
    // 0x126ef48: DecompressPointer r1
    //     0x126ef48: add             x1, x1, HEAP, lsl #32
    // 0x126ef4c: mov             x0, x1
    // 0x126ef50: b               #0x126ef58
    // 0x126ef54: mov             x0, x1
    // 0x126ef58: mov             x2, x0
    // 0x126ef5c: b               #0x126efb4
    // 0x126ef60: ldr             x1, [fp, #0x10]
    // 0x126ef64: LoadField: r0 = r1->field_63
    //     0x126ef64: ldur            w0, [x1, #0x63]
    // 0x126ef68: DecompressPointer r0
    //     0x126ef68: add             x0, x0, HEAP, lsl #32
    // 0x126ef6c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126ef70: cmp             w0, w16
    // 0x126ef74: b.ne            #0x126ef84
    // 0x126ef78: r2 = _theme
    //     0x126ef78: add             x2, PP, #0x26, lsl #12  ; [pp+0x26328] Field <_LisTileDefaultsM2@97247952._theme@97247952>: late final (offset: 0x64)
    //     0x126ef7c: ldr             x2, [x2, #0x328]
    // 0x126ef80: r0 = InitLateFinalInstanceField()
    //     0x126ef80: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126ef84: LoadField: r1 = r0->field_3f
    //     0x126ef84: ldur            w1, [x0, #0x3f]
    // 0x126ef88: DecompressPointer r1
    //     0x126ef88: add             x1, x1, HEAP, lsl #32
    // 0x126ef8c: LoadField: r0 = r1->field_7
    //     0x126ef8c: ldur            w0, [x1, #7]
    // 0x126ef90: DecompressPointer r0
    //     0x126ef90: add             x0, x0, HEAP, lsl #32
    // 0x126ef94: LoadField: r1 = r0->field_7
    //     0x126ef94: ldur            x1, [x0, #7]
    // 0x126ef98: cmp             x1, #0
    // 0x126ef9c: b.gt            #0x126efa8
    // 0x126efa0: r0 = Null
    //     0x126efa0: mov             x0, NULL
    // 0x126efa4: b               #0x126efb0
    // 0x126efa8: r0 = Instance_Color
    //     0x126efa8: add             x0, PP, #0x26, lsl #12  ; [pp+0x26330] Obj!Color@12a2bb1
    //     0x126efac: ldr             x0, [x0, #0x330]
    // 0x126efb0: mov             x2, x0
    // 0x126efb4: ldur            x0, [fp, #-0x20]
    // 0x126efb8: stur            x2, [fp, #-0x28]
    // 0x126efbc: r17 = 5141
    //     0x126efbc: mov             x17, #0x1415
    // 0x126efc0: cmp             x0, x17
    // 0x126efc4: b.ne            #0x126efdc
    // 0x126efc8: ldr             x3, [fp, #0x18]
    // 0x126efcc: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x126efcc: ldur            w1, [x3, #0x17]
    // 0x126efd0: DecompressPointer r1
    //     0x126efd0: add             x1, x1, HEAP, lsl #32
    // 0x126efd4: mov             x0, x2
    // 0x126efd8: b               #0x126f098
    // 0x126efdc: ldr             x3, [fp, #0x18]
    // 0x126efe0: r17 = 5142
    //     0x126efe0: mov             x17, #0x1416
    // 0x126efe4: cmp             x0, x17
    // 0x126efe8: b.ne            #0x126f040
    // 0x126efec: mov             x1, x3
    // 0x126eff0: LoadField: r0 = r1->field_67
    //     0x126eff0: ldur            w0, [x1, #0x67]
    // 0x126eff4: DecompressPointer r0
    //     0x126eff4: add             x0, x0, HEAP, lsl #32
    // 0x126eff8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126effc: cmp             w0, w16
    // 0x126f000: b.ne            #0x126f010
    // 0x126f004: r2 = _colors
    //     0x126f004: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0x126f008: ldr             x2, [x2, #0x320]
    // 0x126f00c: r0 = InitLateFinalInstanceField()
    //     0x126f00c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f010: LoadField: r1 = r0->field_a3
    //     0x126f010: ldur            w1, [x0, #0xa3]
    // 0x126f014: DecompressPointer r1
    //     0x126f014: add             x1, x1, HEAP, lsl #32
    // 0x126f018: cmp             w1, NULL
    // 0x126f01c: b.ne            #0x126f030
    // 0x126f020: LoadField: r1 = r0->field_7f
    //     0x126f020: ldur            w1, [x0, #0x7f]
    // 0x126f024: DecompressPointer r1
    //     0x126f024: add             x1, x1, HEAP, lsl #32
    // 0x126f028: mov             x0, x1
    // 0x126f02c: b               #0x126f034
    // 0x126f030: mov             x0, x1
    // 0x126f034: mov             x1, x0
    // 0x126f038: ldur            x0, [fp, #-0x28]
    // 0x126f03c: b               #0x126f098
    // 0x126f040: ldr             x1, [fp, #0x18]
    // 0x126f044: LoadField: r0 = r1->field_63
    //     0x126f044: ldur            w0, [x1, #0x63]
    // 0x126f048: DecompressPointer r0
    //     0x126f048: add             x0, x0, HEAP, lsl #32
    // 0x126f04c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126f050: cmp             w0, w16
    // 0x126f054: b.ne            #0x126f064
    // 0x126f058: r2 = _theme
    //     0x126f058: add             x2, PP, #0x26, lsl #12  ; [pp+0x26328] Field <_LisTileDefaultsM2@97247952._theme@97247952>: late final (offset: 0x64)
    //     0x126f05c: ldr             x2, [x2, #0x328]
    // 0x126f060: r0 = InitLateFinalInstanceField()
    //     0x126f060: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f064: LoadField: r1 = r0->field_3f
    //     0x126f064: ldur            w1, [x0, #0x3f]
    // 0x126f068: DecompressPointer r1
    //     0x126f068: add             x1, x1, HEAP, lsl #32
    // 0x126f06c: LoadField: r0 = r1->field_7
    //     0x126f06c: ldur            w0, [x1, #7]
    // 0x126f070: DecompressPointer r0
    //     0x126f070: add             x0, x0, HEAP, lsl #32
    // 0x126f074: LoadField: r1 = r0->field_7
    //     0x126f074: ldur            x1, [x0, #7]
    // 0x126f078: cmp             x1, #0
    // 0x126f07c: b.gt            #0x126f088
    // 0x126f080: r0 = Null
    //     0x126f080: mov             x0, NULL
    // 0x126f084: b               #0x126f090
    // 0x126f088: r0 = Instance_Color
    //     0x126f088: add             x0, PP, #0x26, lsl #12  ; [pp+0x26330] Obj!Color@12a2bb1
    //     0x126f08c: ldr             x0, [x0, #0x330]
    // 0x126f090: mov             x1, x0
    // 0x126f094: ldur            x0, [fp, #-0x28]
    // 0x126f098: r2 = LoadClassIdInstr(r0)
    //     0x126f098: ldur            x2, [x0, #-1]
    //     0x126f09c: ubfx            x2, x2, #0xc, #0x14
    // 0x126f0a0: stp             x1, x0, [SP]
    // 0x126f0a4: mov             x0, x2
    // 0x126f0a8: mov             lr, x0
    // 0x126f0ac: ldr             lr, [x21, lr, lsl #3]
    // 0x126f0b0: blr             lr
    // 0x126f0b4: tbnz            w0, #4, #0x126f9f4
    // 0x126f0b8: ldur            x0, [fp, #-8]
    // 0x126f0bc: r17 = 5141
    //     0x126f0bc: mov             x17, #0x1415
    // 0x126f0c0: cmp             x0, x17
    // 0x126f0c4: b.ne            #0x126f0dc
    // 0x126f0c8: ldr             x2, [fp, #0x10]
    // 0x126f0cc: LoadField: r1 = r2->field_1f
    //     0x126f0cc: ldur            w1, [x2, #0x1f]
    // 0x126f0d0: DecompressPointer r1
    //     0x126f0d0: add             x1, x1, HEAP, lsl #32
    // 0x126f0d4: mov             x2, x1
    // 0x126f0d8: b               #0x126f1e4
    // 0x126f0dc: ldr             x2, [fp, #0x10]
    // 0x126f0e0: r17 = 5142
    //     0x126f0e0: mov             x17, #0x1416
    // 0x126f0e4: cmp             x0, x17
    // 0x126f0e8: b.ne            #0x126f164
    // 0x126f0ec: mov             x1, x2
    // 0x126f0f0: LoadField: r0 = r1->field_6b
    //     0x126f0f0: ldur            w0, [x1, #0x6b]
    // 0x126f0f4: DecompressPointer r0
    //     0x126f0f4: add             x0, x0, HEAP, lsl #32
    // 0x126f0f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126f0fc: cmp             w0, w16
    // 0x126f100: b.ne            #0x126f110
    // 0x126f104: r2 = _textTheme
    //     0x126f104: add             x2, PP, #0x26, lsl #12  ; [pp+0x26338] Field <_LisTileDefaultsM3@97247952._textTheme@97247952>: late final (offset: 0x6c)
    //     0x126f108: ldr             x2, [x2, #0x338]
    // 0x126f10c: r0 = InitLateFinalInstanceField()
    //     0x126f10c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f110: LoadField: r2 = r0->field_2b
    //     0x126f110: ldur            w2, [x0, #0x2b]
    // 0x126f114: DecompressPointer r2
    //     0x126f114: add             x2, x2, HEAP, lsl #32
    // 0x126f118: ldr             x1, [fp, #0x10]
    // 0x126f11c: stur            x2, [fp, #-0x28]
    // 0x126f120: LoadField: r0 = r1->field_67
    //     0x126f120: ldur            w0, [x1, #0x67]
    // 0x126f124: DecompressPointer r0
    //     0x126f124: add             x0, x0, HEAP, lsl #32
    // 0x126f128: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126f12c: cmp             w0, w16
    // 0x126f130: b.ne            #0x126f140
    // 0x126f134: r2 = _colors
    //     0x126f134: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0x126f138: ldr             x2, [x2, #0x320]
    // 0x126f13c: r0 = InitLateFinalInstanceField()
    //     0x126f13c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f140: LoadField: r1 = r0->field_7f
    //     0x126f140: ldur            w1, [x0, #0x7f]
    // 0x126f144: DecompressPointer r1
    //     0x126f144: add             x1, x1, HEAP, lsl #32
    // 0x126f148: str             x1, [SP]
    // 0x126f14c: ldur            x1, [fp, #-0x28]
    // 0x126f150: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x126f150: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x126f154: ldr             x4, [x4, #0x7f0]
    // 0x126f158: r0 = copyWith()
    //     0x126f158: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x126f15c: mov             x2, x0
    // 0x126f160: b               #0x126f1e4
    // 0x126f164: ldur            x0, [fp, #-0x18]
    // 0x126f168: cmp             w0, NULL
    // 0x126f16c: b.eq            #0x126fa0c
    // 0x126f170: LoadField: r1 = r0->field_7
    //     0x126f170: ldur            x1, [x0, #7]
    // 0x126f174: cmp             x1, #0
    // 0x126f178: b.gt            #0x126f1b0
    // 0x126f17c: ldr             x1, [fp, #0x10]
    // 0x126f180: LoadField: r0 = r1->field_67
    //     0x126f180: ldur            w0, [x1, #0x67]
    // 0x126f184: DecompressPointer r0
    //     0x126f184: add             x0, x0, HEAP, lsl #32
    // 0x126f188: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126f18c: cmp             w0, w16
    // 0x126f190: b.ne            #0x126f1a0
    // 0x126f194: r2 = _textTheme
    //     0x126f194: add             x2, PP, #0x26, lsl #12  ; [pp+0x26340] Field <_LisTileDefaultsM2@97247952._textTheme@97247952>: late final (offset: 0x68)
    //     0x126f198: ldr             x2, [x2, #0x340]
    // 0x126f19c: r0 = InitLateFinalInstanceField()
    //     0x126f19c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f1a0: LoadField: r1 = r0->field_23
    //     0x126f1a0: ldur            w1, [x0, #0x23]
    // 0x126f1a4: DecompressPointer r1
    //     0x126f1a4: add             x1, x1, HEAP, lsl #32
    // 0x126f1a8: mov             x0, x1
    // 0x126f1ac: b               #0x126f1e0
    // 0x126f1b0: ldr             x1, [fp, #0x10]
    // 0x126f1b4: LoadField: r0 = r1->field_67
    //     0x126f1b4: ldur            w0, [x1, #0x67]
    // 0x126f1b8: DecompressPointer r0
    //     0x126f1b8: add             x0, x0, HEAP, lsl #32
    // 0x126f1bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126f1c0: cmp             w0, w16
    // 0x126f1c4: b.ne            #0x126f1d4
    // 0x126f1c8: r2 = _textTheme
    //     0x126f1c8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26340] Field <_LisTileDefaultsM2@97247952._textTheme@97247952>: late final (offset: 0x68)
    //     0x126f1cc: ldr             x2, [x2, #0x340]
    // 0x126f1d0: r0 = InitLateFinalInstanceField()
    //     0x126f1d0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f1d4: LoadField: r1 = r0->field_2b
    //     0x126f1d4: ldur            w1, [x0, #0x2b]
    // 0x126f1d8: DecompressPointer r1
    //     0x126f1d8: add             x1, x1, HEAP, lsl #32
    // 0x126f1dc: mov             x0, x1
    // 0x126f1e0: mov             x2, x0
    // 0x126f1e4: ldur            x0, [fp, #-0x20]
    // 0x126f1e8: stur            x2, [fp, #-0x18]
    // 0x126f1ec: r17 = 5141
    //     0x126f1ec: mov             x17, #0x1415
    // 0x126f1f0: cmp             x0, x17
    // 0x126f1f4: b.ne            #0x126f20c
    // 0x126f1f8: ldr             x3, [fp, #0x18]
    // 0x126f1fc: LoadField: r1 = r3->field_1f
    //     0x126f1fc: ldur            w1, [x3, #0x1f]
    // 0x126f200: DecompressPointer r1
    //     0x126f200: add             x1, x1, HEAP, lsl #32
    // 0x126f204: mov             x0, x2
    // 0x126f208: b               #0x126f31c
    // 0x126f20c: ldr             x3, [fp, #0x18]
    // 0x126f210: r17 = 5142
    //     0x126f210: mov             x17, #0x1416
    // 0x126f214: cmp             x0, x17
    // 0x126f218: b.ne            #0x126f298
    // 0x126f21c: mov             x1, x3
    // 0x126f220: LoadField: r0 = r1->field_6b
    //     0x126f220: ldur            w0, [x1, #0x6b]
    // 0x126f224: DecompressPointer r0
    //     0x126f224: add             x0, x0, HEAP, lsl #32
    // 0x126f228: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126f22c: cmp             w0, w16
    // 0x126f230: b.ne            #0x126f240
    // 0x126f234: r2 = _textTheme
    //     0x126f234: add             x2, PP, #0x26, lsl #12  ; [pp+0x26338] Field <_LisTileDefaultsM3@97247952._textTheme@97247952>: late final (offset: 0x6c)
    //     0x126f238: ldr             x2, [x2, #0x338]
    // 0x126f23c: r0 = InitLateFinalInstanceField()
    //     0x126f23c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f240: LoadField: r2 = r0->field_2b
    //     0x126f240: ldur            w2, [x0, #0x2b]
    // 0x126f244: DecompressPointer r2
    //     0x126f244: add             x2, x2, HEAP, lsl #32
    // 0x126f248: ldr             x1, [fp, #0x18]
    // 0x126f24c: stur            x2, [fp, #-0x28]
    // 0x126f250: LoadField: r0 = r1->field_67
    //     0x126f250: ldur            w0, [x1, #0x67]
    // 0x126f254: DecompressPointer r0
    //     0x126f254: add             x0, x0, HEAP, lsl #32
    // 0x126f258: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126f25c: cmp             w0, w16
    // 0x126f260: b.ne            #0x126f270
    // 0x126f264: r2 = _colors
    //     0x126f264: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0x126f268: ldr             x2, [x2, #0x320]
    // 0x126f26c: r0 = InitLateFinalInstanceField()
    //     0x126f26c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f270: LoadField: r1 = r0->field_7f
    //     0x126f270: ldur            w1, [x0, #0x7f]
    // 0x126f274: DecompressPointer r1
    //     0x126f274: add             x1, x1, HEAP, lsl #32
    // 0x126f278: str             x1, [SP]
    // 0x126f27c: ldur            x1, [fp, #-0x28]
    // 0x126f280: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x126f280: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x126f284: ldr             x4, [x4, #0x7f0]
    // 0x126f288: r0 = copyWith()
    //     0x126f288: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x126f28c: mov             x1, x0
    // 0x126f290: ldur            x0, [fp, #-0x18]
    // 0x126f294: b               #0x126f31c
    // 0x126f298: ldur            x0, [fp, #-0x10]
    // 0x126f29c: cmp             w0, NULL
    // 0x126f2a0: b.eq            #0x126fa10
    // 0x126f2a4: LoadField: r1 = r0->field_7
    //     0x126f2a4: ldur            x1, [x0, #7]
    // 0x126f2a8: cmp             x1, #0
    // 0x126f2ac: b.gt            #0x126f2e4
    // 0x126f2b0: ldr             x1, [fp, #0x18]
    // 0x126f2b4: LoadField: r0 = r1->field_67
    //     0x126f2b4: ldur            w0, [x1, #0x67]
    // 0x126f2b8: DecompressPointer r0
    //     0x126f2b8: add             x0, x0, HEAP, lsl #32
    // 0x126f2bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126f2c0: cmp             w0, w16
    // 0x126f2c4: b.ne            #0x126f2d4
    // 0x126f2c8: r2 = _textTheme
    //     0x126f2c8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26340] Field <_LisTileDefaultsM2@97247952._textTheme@97247952>: late final (offset: 0x68)
    //     0x126f2cc: ldr             x2, [x2, #0x340]
    // 0x126f2d0: r0 = InitLateFinalInstanceField()
    //     0x126f2d0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f2d4: LoadField: r1 = r0->field_23
    //     0x126f2d4: ldur            w1, [x0, #0x23]
    // 0x126f2d8: DecompressPointer r1
    //     0x126f2d8: add             x1, x1, HEAP, lsl #32
    // 0x126f2dc: mov             x0, x1
    // 0x126f2e0: b               #0x126f314
    // 0x126f2e4: ldr             x1, [fp, #0x18]
    // 0x126f2e8: LoadField: r0 = r1->field_67
    //     0x126f2e8: ldur            w0, [x1, #0x67]
    // 0x126f2ec: DecompressPointer r0
    //     0x126f2ec: add             x0, x0, HEAP, lsl #32
    // 0x126f2f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126f2f4: cmp             w0, w16
    // 0x126f2f8: b.ne            #0x126f308
    // 0x126f2fc: r2 = _textTheme
    //     0x126f2fc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26340] Field <_LisTileDefaultsM2@97247952._textTheme@97247952>: late final (offset: 0x68)
    //     0x126f300: ldr             x2, [x2, #0x340]
    // 0x126f304: r0 = InitLateFinalInstanceField()
    //     0x126f304: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f308: LoadField: r1 = r0->field_2b
    //     0x126f308: ldur            w1, [x0, #0x2b]
    // 0x126f30c: DecompressPointer r1
    //     0x126f30c: add             x1, x1, HEAP, lsl #32
    // 0x126f310: mov             x0, x1
    // 0x126f314: mov             x1, x0
    // 0x126f318: ldur            x0, [fp, #-0x18]
    // 0x126f31c: r2 = LoadClassIdInstr(r0)
    //     0x126f31c: ldur            x2, [x0, #-1]
    //     0x126f320: ubfx            x2, x2, #0xc, #0x14
    // 0x126f324: stp             x1, x0, [SP]
    // 0x126f328: mov             x0, x2
    // 0x126f32c: mov             lr, x0
    // 0x126f330: ldr             lr, [x21, lr, lsl #3]
    // 0x126f334: blr             lr
    // 0x126f338: tbnz            w0, #4, #0x126f9f4
    // 0x126f33c: ldur            x0, [fp, #-8]
    // 0x126f340: r17 = 5141
    //     0x126f340: mov             x17, #0x1415
    // 0x126f344: cmp             x0, x17
    // 0x126f348: b.ne            #0x126f360
    // 0x126f34c: ldr             x2, [fp, #0x10]
    // 0x126f350: LoadField: r1 = r2->field_23
    //     0x126f350: ldur            w1, [x2, #0x23]
    // 0x126f354: DecompressPointer r1
    //     0x126f354: add             x1, x1, HEAP, lsl #32
    // 0x126f358: mov             x2, x1
    // 0x126f35c: b               #0x126f46c
    // 0x126f360: ldr             x2, [fp, #0x10]
    // 0x126f364: r17 = 5142
    //     0x126f364: mov             x17, #0x1416
    // 0x126f368: cmp             x0, x17
    // 0x126f36c: b.ne            #0x126f40c
    // 0x126f370: mov             x1, x2
    // 0x126f374: LoadField: r0 = r1->field_6b
    //     0x126f374: ldur            w0, [x1, #0x6b]
    // 0x126f378: DecompressPointer r0
    //     0x126f378: add             x0, x0, HEAP, lsl #32
    // 0x126f37c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126f380: cmp             w0, w16
    // 0x126f384: b.ne            #0x126f394
    // 0x126f388: r2 = _textTheme
    //     0x126f388: add             x2, PP, #0x26, lsl #12  ; [pp+0x26338] Field <_LisTileDefaultsM3@97247952._textTheme@97247952>: late final (offset: 0x6c)
    //     0x126f38c: ldr             x2, [x2, #0x338]
    // 0x126f390: r0 = InitLateFinalInstanceField()
    //     0x126f390: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f394: LoadField: r2 = r0->field_2f
    //     0x126f394: ldur            w2, [x0, #0x2f]
    // 0x126f398: DecompressPointer r2
    //     0x126f398: add             x2, x2, HEAP, lsl #32
    // 0x126f39c: stur            x2, [fp, #-0x10]
    // 0x126f3a0: cmp             w2, NULL
    // 0x126f3a4: b.eq            #0x126fa14
    // 0x126f3a8: ldr             x1, [fp, #0x10]
    // 0x126f3ac: LoadField: r0 = r1->field_67
    //     0x126f3ac: ldur            w0, [x1, #0x67]
    // 0x126f3b0: DecompressPointer r0
    //     0x126f3b0: add             x0, x0, HEAP, lsl #32
    // 0x126f3b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126f3b8: cmp             w0, w16
    // 0x126f3bc: b.ne            #0x126f3cc
    // 0x126f3c0: r2 = _colors
    //     0x126f3c0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0x126f3c4: ldr             x2, [x2, #0x320]
    // 0x126f3c8: r0 = InitLateFinalInstanceField()
    //     0x126f3c8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f3cc: LoadField: r1 = r0->field_a3
    //     0x126f3cc: ldur            w1, [x0, #0xa3]
    // 0x126f3d0: DecompressPointer r1
    //     0x126f3d0: add             x1, x1, HEAP, lsl #32
    // 0x126f3d4: cmp             w1, NULL
    // 0x126f3d8: b.ne            #0x126f3ec
    // 0x126f3dc: LoadField: r1 = r0->field_7f
    //     0x126f3dc: ldur            w1, [x0, #0x7f]
    // 0x126f3e0: DecompressPointer r1
    //     0x126f3e0: add             x1, x1, HEAP, lsl #32
    // 0x126f3e4: mov             x0, x1
    // 0x126f3e8: b               #0x126f3f0
    // 0x126f3ec: mov             x0, x1
    // 0x126f3f0: str             x0, [SP]
    // 0x126f3f4: ldur            x1, [fp, #-0x10]
    // 0x126f3f8: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x126f3f8: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x126f3fc: ldr             x4, [x4, #0x7f0]
    // 0x126f400: r0 = copyWith()
    //     0x126f400: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x126f404: mov             x2, x0
    // 0x126f408: b               #0x126f46c
    // 0x126f40c: ldr             x1, [fp, #0x10]
    // 0x126f410: LoadField: r0 = r1->field_67
    //     0x126f410: ldur            w0, [x1, #0x67]
    // 0x126f414: DecompressPointer r0
    //     0x126f414: add             x0, x0, HEAP, lsl #32
    // 0x126f418: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126f41c: cmp             w0, w16
    // 0x126f420: b.ne            #0x126f430
    // 0x126f424: r2 = _textTheme
    //     0x126f424: add             x2, PP, #0x26, lsl #12  ; [pp+0x26340] Field <_LisTileDefaultsM2@97247952._textTheme@97247952>: late final (offset: 0x68)
    //     0x126f428: ldr             x2, [x2, #0x340]
    // 0x126f42c: r0 = InitLateFinalInstanceField()
    //     0x126f42c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f430: LoadField: r1 = r0->field_2f
    //     0x126f430: ldur            w1, [x0, #0x2f]
    // 0x126f434: DecompressPointer r1
    //     0x126f434: add             x1, x1, HEAP, lsl #32
    // 0x126f438: cmp             w1, NULL
    // 0x126f43c: b.eq            #0x126fa18
    // 0x126f440: LoadField: r2 = r0->field_33
    //     0x126f440: ldur            w2, [x0, #0x33]
    // 0x126f444: DecompressPointer r2
    //     0x126f444: add             x2, x2, HEAP, lsl #32
    // 0x126f448: cmp             w2, NULL
    // 0x126f44c: b.eq            #0x126fa1c
    // 0x126f450: LoadField: r0 = r2->field_b
    //     0x126f450: ldur            w0, [x2, #0xb]
    // 0x126f454: DecompressPointer r0
    //     0x126f454: add             x0, x0, HEAP, lsl #32
    // 0x126f458: str             x0, [SP]
    // 0x126f45c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x126f45c: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x126f460: ldr             x4, [x4, #0x7f0]
    // 0x126f464: r0 = copyWith()
    //     0x126f464: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x126f468: mov             x2, x0
    // 0x126f46c: ldur            x0, [fp, #-0x20]
    // 0x126f470: stur            x2, [fp, #-0x10]
    // 0x126f474: r17 = 5141
    //     0x126f474: mov             x17, #0x1415
    // 0x126f478: cmp             x0, x17
    // 0x126f47c: b.ne            #0x126f494
    // 0x126f480: ldr             x3, [fp, #0x18]
    // 0x126f484: LoadField: r1 = r3->field_23
    //     0x126f484: ldur            w1, [x3, #0x23]
    // 0x126f488: DecompressPointer r1
    //     0x126f488: add             x1, x1, HEAP, lsl #32
    // 0x126f48c: mov             x0, x2
    // 0x126f490: b               #0x126f5a8
    // 0x126f494: ldr             x3, [fp, #0x18]
    // 0x126f498: r17 = 5142
    //     0x126f498: mov             x17, #0x1416
    // 0x126f49c: cmp             x0, x17
    // 0x126f4a0: b.ne            #0x126f544
    // 0x126f4a4: mov             x1, x3
    // 0x126f4a8: LoadField: r0 = r1->field_6b
    //     0x126f4a8: ldur            w0, [x1, #0x6b]
    // 0x126f4ac: DecompressPointer r0
    //     0x126f4ac: add             x0, x0, HEAP, lsl #32
    // 0x126f4b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126f4b4: cmp             w0, w16
    // 0x126f4b8: b.ne            #0x126f4c8
    // 0x126f4bc: r2 = _textTheme
    //     0x126f4bc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26338] Field <_LisTileDefaultsM3@97247952._textTheme@97247952>: late final (offset: 0x6c)
    //     0x126f4c0: ldr             x2, [x2, #0x338]
    // 0x126f4c4: r0 = InitLateFinalInstanceField()
    //     0x126f4c4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f4c8: LoadField: r2 = r0->field_2f
    //     0x126f4c8: ldur            w2, [x0, #0x2f]
    // 0x126f4cc: DecompressPointer r2
    //     0x126f4cc: add             x2, x2, HEAP, lsl #32
    // 0x126f4d0: stur            x2, [fp, #-0x18]
    // 0x126f4d4: cmp             w2, NULL
    // 0x126f4d8: b.eq            #0x126fa20
    // 0x126f4dc: ldr             x1, [fp, #0x18]
    // 0x126f4e0: LoadField: r0 = r1->field_67
    //     0x126f4e0: ldur            w0, [x1, #0x67]
    // 0x126f4e4: DecompressPointer r0
    //     0x126f4e4: add             x0, x0, HEAP, lsl #32
    // 0x126f4e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126f4ec: cmp             w0, w16
    // 0x126f4f0: b.ne            #0x126f500
    // 0x126f4f4: r2 = _colors
    //     0x126f4f4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0x126f4f8: ldr             x2, [x2, #0x320]
    // 0x126f4fc: r0 = InitLateFinalInstanceField()
    //     0x126f4fc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f500: LoadField: r1 = r0->field_a3
    //     0x126f500: ldur            w1, [x0, #0xa3]
    // 0x126f504: DecompressPointer r1
    //     0x126f504: add             x1, x1, HEAP, lsl #32
    // 0x126f508: cmp             w1, NULL
    // 0x126f50c: b.ne            #0x126f520
    // 0x126f510: LoadField: r1 = r0->field_7f
    //     0x126f510: ldur            w1, [x0, #0x7f]
    // 0x126f514: DecompressPointer r1
    //     0x126f514: add             x1, x1, HEAP, lsl #32
    // 0x126f518: mov             x0, x1
    // 0x126f51c: b               #0x126f524
    // 0x126f520: mov             x0, x1
    // 0x126f524: str             x0, [SP]
    // 0x126f528: ldur            x1, [fp, #-0x18]
    // 0x126f52c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x126f52c: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x126f530: ldr             x4, [x4, #0x7f0]
    // 0x126f534: r0 = copyWith()
    //     0x126f534: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x126f538: mov             x1, x0
    // 0x126f53c: ldur            x0, [fp, #-0x10]
    // 0x126f540: b               #0x126f5a8
    // 0x126f544: ldr             x1, [fp, #0x18]
    // 0x126f548: LoadField: r0 = r1->field_67
    //     0x126f548: ldur            w0, [x1, #0x67]
    // 0x126f54c: DecompressPointer r0
    //     0x126f54c: add             x0, x0, HEAP, lsl #32
    // 0x126f550: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126f554: cmp             w0, w16
    // 0x126f558: b.ne            #0x126f568
    // 0x126f55c: r2 = _textTheme
    //     0x126f55c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26340] Field <_LisTileDefaultsM2@97247952._textTheme@97247952>: late final (offset: 0x68)
    //     0x126f560: ldr             x2, [x2, #0x340]
    // 0x126f564: r0 = InitLateFinalInstanceField()
    //     0x126f564: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f568: LoadField: r1 = r0->field_2f
    //     0x126f568: ldur            w1, [x0, #0x2f]
    // 0x126f56c: DecompressPointer r1
    //     0x126f56c: add             x1, x1, HEAP, lsl #32
    // 0x126f570: cmp             w1, NULL
    // 0x126f574: b.eq            #0x126fa24
    // 0x126f578: LoadField: r2 = r0->field_33
    //     0x126f578: ldur            w2, [x0, #0x33]
    // 0x126f57c: DecompressPointer r2
    //     0x126f57c: add             x2, x2, HEAP, lsl #32
    // 0x126f580: cmp             w2, NULL
    // 0x126f584: b.eq            #0x126fa28
    // 0x126f588: LoadField: r0 = r2->field_b
    //     0x126f588: ldur            w0, [x2, #0xb]
    // 0x126f58c: DecompressPointer r0
    //     0x126f58c: add             x0, x0, HEAP, lsl #32
    // 0x126f590: str             x0, [SP]
    // 0x126f594: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x126f594: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x126f598: ldr             x4, [x4, #0x7f0]
    // 0x126f59c: r0 = copyWith()
    //     0x126f59c: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x126f5a0: mov             x1, x0
    // 0x126f5a4: ldur            x0, [fp, #-0x10]
    // 0x126f5a8: r2 = LoadClassIdInstr(r0)
    //     0x126f5a8: ldur            x2, [x0, #-1]
    //     0x126f5ac: ubfx            x2, x2, #0xc, #0x14
    // 0x126f5b0: stp             x1, x0, [SP]
    // 0x126f5b4: mov             x0, x2
    // 0x126f5b8: mov             lr, x0
    // 0x126f5bc: ldr             lr, [x21, lr, lsl #3]
    // 0x126f5c0: blr             lr
    // 0x126f5c4: tbnz            w0, #4, #0x126f9f4
    // 0x126f5c8: ldur            x0, [fp, #-8]
    // 0x126f5cc: r17 = 5141
    //     0x126f5cc: mov             x17, #0x1415
    // 0x126f5d0: cmp             x0, x17
    // 0x126f5d4: b.ne            #0x126f5ec
    // 0x126f5d8: ldr             x2, [fp, #0x10]
    // 0x126f5dc: LoadField: r1 = r2->field_27
    //     0x126f5dc: ldur            w1, [x2, #0x27]
    // 0x126f5e0: DecompressPointer r1
    //     0x126f5e0: add             x1, x1, HEAP, lsl #32
    // 0x126f5e4: mov             x2, x1
    // 0x126f5e8: b               #0x126f6c8
    // 0x126f5ec: ldr             x2, [fp, #0x10]
    // 0x126f5f0: r17 = 5142
    //     0x126f5f0: mov             x17, #0x1416
    // 0x126f5f4: cmp             x0, x17
    // 0x126f5f8: b.ne            #0x126f698
    // 0x126f5fc: mov             x1, x2
    // 0x126f600: LoadField: r0 = r1->field_6b
    //     0x126f600: ldur            w0, [x1, #0x6b]
    // 0x126f604: DecompressPointer r0
    //     0x126f604: add             x0, x0, HEAP, lsl #32
    // 0x126f608: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126f60c: cmp             w0, w16
    // 0x126f610: b.ne            #0x126f620
    // 0x126f614: r2 = _textTheme
    //     0x126f614: add             x2, PP, #0x26, lsl #12  ; [pp+0x26338] Field <_LisTileDefaultsM3@97247952._textTheme@97247952>: late final (offset: 0x6c)
    //     0x126f618: ldr             x2, [x2, #0x338]
    // 0x126f61c: r0 = InitLateFinalInstanceField()
    //     0x126f61c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f620: LoadField: r2 = r0->field_3f
    //     0x126f620: ldur            w2, [x0, #0x3f]
    // 0x126f624: DecompressPointer r2
    //     0x126f624: add             x2, x2, HEAP, lsl #32
    // 0x126f628: stur            x2, [fp, #-0x10]
    // 0x126f62c: cmp             w2, NULL
    // 0x126f630: b.eq            #0x126fa2c
    // 0x126f634: ldr             x1, [fp, #0x10]
    // 0x126f638: LoadField: r0 = r1->field_67
    //     0x126f638: ldur            w0, [x1, #0x67]
    // 0x126f63c: DecompressPointer r0
    //     0x126f63c: add             x0, x0, HEAP, lsl #32
    // 0x126f640: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126f644: cmp             w0, w16
    // 0x126f648: b.ne            #0x126f658
    // 0x126f64c: r2 = _colors
    //     0x126f64c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0x126f650: ldr             x2, [x2, #0x320]
    // 0x126f654: r0 = InitLateFinalInstanceField()
    //     0x126f654: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f658: LoadField: r1 = r0->field_a3
    //     0x126f658: ldur            w1, [x0, #0xa3]
    // 0x126f65c: DecompressPointer r1
    //     0x126f65c: add             x1, x1, HEAP, lsl #32
    // 0x126f660: cmp             w1, NULL
    // 0x126f664: b.ne            #0x126f678
    // 0x126f668: LoadField: r1 = r0->field_7f
    //     0x126f668: ldur            w1, [x0, #0x7f]
    // 0x126f66c: DecompressPointer r1
    //     0x126f66c: add             x1, x1, HEAP, lsl #32
    // 0x126f670: mov             x0, x1
    // 0x126f674: b               #0x126f67c
    // 0x126f678: mov             x0, x1
    // 0x126f67c: str             x0, [SP]
    // 0x126f680: ldur            x1, [fp, #-0x10]
    // 0x126f684: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x126f684: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x126f688: ldr             x4, [x4, #0x7f0]
    // 0x126f68c: r0 = copyWith()
    //     0x126f68c: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x126f690: mov             x2, x0
    // 0x126f694: b               #0x126f6c8
    // 0x126f698: ldr             x1, [fp, #0x10]
    // 0x126f69c: LoadField: r0 = r1->field_67
    //     0x126f69c: ldur            w0, [x1, #0x67]
    // 0x126f6a0: DecompressPointer r0
    //     0x126f6a0: add             x0, x0, HEAP, lsl #32
    // 0x126f6a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126f6a8: cmp             w0, w16
    // 0x126f6ac: b.ne            #0x126f6bc
    // 0x126f6b0: r2 = _textTheme
    //     0x126f6b0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26340] Field <_LisTileDefaultsM2@97247952._textTheme@97247952>: late final (offset: 0x68)
    //     0x126f6b4: ldr             x2, [x2, #0x340]
    // 0x126f6b8: r0 = InitLateFinalInstanceField()
    //     0x126f6b8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f6bc: LoadField: r1 = r0->field_2f
    //     0x126f6bc: ldur            w1, [x0, #0x2f]
    // 0x126f6c0: DecompressPointer r1
    //     0x126f6c0: add             x1, x1, HEAP, lsl #32
    // 0x126f6c4: mov             x2, x1
    // 0x126f6c8: ldur            x0, [fp, #-0x20]
    // 0x126f6cc: stur            x2, [fp, #-0x10]
    // 0x126f6d0: r17 = 5141
    //     0x126f6d0: mov             x17, #0x1415
    // 0x126f6d4: cmp             x0, x17
    // 0x126f6d8: b.ne            #0x126f6f0
    // 0x126f6dc: ldr             x3, [fp, #0x18]
    // 0x126f6e0: LoadField: r1 = r3->field_27
    //     0x126f6e0: ldur            w1, [x3, #0x27]
    // 0x126f6e4: DecompressPointer r1
    //     0x126f6e4: add             x1, x1, HEAP, lsl #32
    // 0x126f6e8: mov             x0, x2
    // 0x126f6ec: b               #0x126f7d0
    // 0x126f6f0: ldr             x3, [fp, #0x18]
    // 0x126f6f4: r17 = 5142
    //     0x126f6f4: mov             x17, #0x1416
    // 0x126f6f8: cmp             x0, x17
    // 0x126f6fc: b.ne            #0x126f7a0
    // 0x126f700: mov             x1, x3
    // 0x126f704: LoadField: r0 = r1->field_6b
    //     0x126f704: ldur            w0, [x1, #0x6b]
    // 0x126f708: DecompressPointer r0
    //     0x126f708: add             x0, x0, HEAP, lsl #32
    // 0x126f70c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126f710: cmp             w0, w16
    // 0x126f714: b.ne            #0x126f724
    // 0x126f718: r2 = _textTheme
    //     0x126f718: add             x2, PP, #0x26, lsl #12  ; [pp+0x26338] Field <_LisTileDefaultsM3@97247952._textTheme@97247952>: late final (offset: 0x6c)
    //     0x126f71c: ldr             x2, [x2, #0x338]
    // 0x126f720: r0 = InitLateFinalInstanceField()
    //     0x126f720: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f724: LoadField: r2 = r0->field_3f
    //     0x126f724: ldur            w2, [x0, #0x3f]
    // 0x126f728: DecompressPointer r2
    //     0x126f728: add             x2, x2, HEAP, lsl #32
    // 0x126f72c: stur            x2, [fp, #-0x18]
    // 0x126f730: cmp             w2, NULL
    // 0x126f734: b.eq            #0x126fa30
    // 0x126f738: ldr             x1, [fp, #0x18]
    // 0x126f73c: LoadField: r0 = r1->field_67
    //     0x126f73c: ldur            w0, [x1, #0x67]
    // 0x126f740: DecompressPointer r0
    //     0x126f740: add             x0, x0, HEAP, lsl #32
    // 0x126f744: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126f748: cmp             w0, w16
    // 0x126f74c: b.ne            #0x126f75c
    // 0x126f750: r2 = _colors
    //     0x126f750: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0x126f754: ldr             x2, [x2, #0x320]
    // 0x126f758: r0 = InitLateFinalInstanceField()
    //     0x126f758: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f75c: LoadField: r1 = r0->field_a3
    //     0x126f75c: ldur            w1, [x0, #0xa3]
    // 0x126f760: DecompressPointer r1
    //     0x126f760: add             x1, x1, HEAP, lsl #32
    // 0x126f764: cmp             w1, NULL
    // 0x126f768: b.ne            #0x126f77c
    // 0x126f76c: LoadField: r1 = r0->field_7f
    //     0x126f76c: ldur            w1, [x0, #0x7f]
    // 0x126f770: DecompressPointer r1
    //     0x126f770: add             x1, x1, HEAP, lsl #32
    // 0x126f774: mov             x0, x1
    // 0x126f778: b               #0x126f780
    // 0x126f77c: mov             x0, x1
    // 0x126f780: str             x0, [SP]
    // 0x126f784: ldur            x1, [fp, #-0x18]
    // 0x126f788: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x126f788: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x126f78c: ldr             x4, [x4, #0x7f0]
    // 0x126f790: r0 = copyWith()
    //     0x126f790: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x126f794: mov             x1, x0
    // 0x126f798: ldur            x0, [fp, #-0x10]
    // 0x126f79c: b               #0x126f7d0
    // 0x126f7a0: ldr             x1, [fp, #0x18]
    // 0x126f7a4: LoadField: r0 = r1->field_67
    //     0x126f7a4: ldur            w0, [x1, #0x67]
    // 0x126f7a8: DecompressPointer r0
    //     0x126f7a8: add             x0, x0, HEAP, lsl #32
    // 0x126f7ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126f7b0: cmp             w0, w16
    // 0x126f7b4: b.ne            #0x126f7c4
    // 0x126f7b8: r2 = _textTheme
    //     0x126f7b8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26340] Field <_LisTileDefaultsM2@97247952._textTheme@97247952>: late final (offset: 0x68)
    //     0x126f7bc: ldr             x2, [x2, #0x340]
    // 0x126f7c0: r0 = InitLateFinalInstanceField()
    //     0x126f7c0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126f7c4: LoadField: r1 = r0->field_2f
    //     0x126f7c4: ldur            w1, [x0, #0x2f]
    // 0x126f7c8: DecompressPointer r1
    //     0x126f7c8: add             x1, x1, HEAP, lsl #32
    // 0x126f7cc: ldur            x0, [fp, #-0x10]
    // 0x126f7d0: r2 = LoadClassIdInstr(r0)
    //     0x126f7d0: ldur            x2, [x0, #-1]
    //     0x126f7d4: ubfx            x2, x2, #0xc, #0x14
    // 0x126f7d8: stp             x1, x0, [SP]
    // 0x126f7dc: mov             x0, x2
    // 0x126f7e0: mov             lr, x0
    // 0x126f7e4: ldr             lr, [x21, lr, lsl #3]
    // 0x126f7e8: blr             lr
    // 0x126f7ec: tbnz            w0, #4, #0x126f9f4
    // 0x126f7f0: ldr             x1, [fp, #0x18]
    // 0x126f7f4: ldr             x2, [fp, #0x10]
    // 0x126f7f8: LoadField: r0 = r2->field_1b
    //     0x126f7f8: ldur            w0, [x2, #0x1b]
    // 0x126f7fc: DecompressPointer r0
    //     0x126f7fc: add             x0, x0, HEAP, lsl #32
    // 0x126f800: LoadField: r3 = r1->field_1b
    //     0x126f800: ldur            w3, [x1, #0x1b]
    // 0x126f804: DecompressPointer r3
    //     0x126f804: add             x3, x3, HEAP, lsl #32
    // 0x126f808: r4 = LoadClassIdInstr(r0)
    //     0x126f808: ldur            x4, [x0, #-1]
    //     0x126f80c: ubfx            x4, x4, #0xc, #0x14
    // 0x126f810: stp             x3, x0, [SP]
    // 0x126f814: mov             x0, x4
    // 0x126f818: mov             lr, x0
    // 0x126f81c: ldr             lr, [x21, lr, lsl #3]
    // 0x126f820: blr             lr
    // 0x126f824: tbnz            w0, #4, #0x126f9f4
    // 0x126f828: ldr             x1, [fp, #0x18]
    // 0x126f82c: ldr             x2, [fp, #0x10]
    // 0x126f830: LoadField: r0 = r2->field_2b
    //     0x126f830: ldur            w0, [x2, #0x2b]
    // 0x126f834: DecompressPointer r0
    //     0x126f834: add             x0, x0, HEAP, lsl #32
    // 0x126f838: LoadField: r3 = r1->field_2b
    //     0x126f838: ldur            w3, [x1, #0x2b]
    // 0x126f83c: DecompressPointer r3
    //     0x126f83c: add             x3, x3, HEAP, lsl #32
    // 0x126f840: r4 = LoadClassIdInstr(r0)
    //     0x126f840: ldur            x4, [x0, #-1]
    //     0x126f844: ubfx            x4, x4, #0xc, #0x14
    // 0x126f848: stp             x3, x0, [SP]
    // 0x126f84c: mov             x0, x4
    // 0x126f850: mov             lr, x0
    // 0x126f854: ldr             lr, [x21, lr, lsl #3]
    // 0x126f858: blr             lr
    // 0x126f85c: tbnz            w0, #4, #0x126f9f4
    // 0x126f860: ldur            x0, [fp, #-8]
    // 0x126f864: r17 = 5141
    //     0x126f864: mov             x17, #0x1415
    // 0x126f868: cmp             x0, x17
    // 0x126f86c: b.ne            #0x126f884
    // 0x126f870: ldr             x1, [fp, #0x10]
    // 0x126f874: LoadField: r0 = r1->field_2f
    //     0x126f874: ldur            w0, [x1, #0x2f]
    // 0x126f878: DecompressPointer r0
    //     0x126f878: add             x0, x0, HEAP, lsl #32
    // 0x126f87c: mov             x2, x0
    // 0x126f880: b               #0x126f8a8
    // 0x126f884: ldr             x1, [fp, #0x10]
    // 0x126f888: r17 = 5142
    //     0x126f888: mov             x17, #0x1416
    // 0x126f88c: cmp             x0, x17
    // 0x126f890: b.ne            #0x126f8a0
    // 0x126f894: r2 = Instance_Color
    //     0x126f894: add             x2, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x126f898: ldr             x2, [x2, #0x810]
    // 0x126f89c: b               #0x126f8a8
    // 0x126f8a0: r2 = Instance_Color
    //     0x126f8a0: add             x2, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x126f8a4: ldr             x2, [x2, #0x810]
    // 0x126f8a8: ldur            x0, [fp, #-0x20]
    // 0x126f8ac: r17 = 5141
    //     0x126f8ac: mov             x17, #0x1415
    // 0x126f8b0: cmp             x0, x17
    // 0x126f8b4: b.ne            #0x126f8c8
    // 0x126f8b8: ldr             x3, [fp, #0x18]
    // 0x126f8bc: LoadField: r0 = r3->field_2f
    //     0x126f8bc: ldur            w0, [x3, #0x2f]
    // 0x126f8c0: DecompressPointer r0
    //     0x126f8c0: add             x0, x0, HEAP, lsl #32
    // 0x126f8c4: b               #0x126f8ec
    // 0x126f8c8: ldr             x3, [fp, #0x18]
    // 0x126f8cc: r17 = 5142
    //     0x126f8cc: mov             x17, #0x1416
    // 0x126f8d0: cmp             x0, x17
    // 0x126f8d4: b.ne            #0x126f8e4
    // 0x126f8d8: r0 = Instance_Color
    //     0x126f8d8: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x126f8dc: ldr             x0, [x0, #0x810]
    // 0x126f8e0: b               #0x126f8ec
    // 0x126f8e4: r0 = Instance_Color
    //     0x126f8e4: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x126f8e8: ldr             x0, [x0, #0x810]
    // 0x126f8ec: r4 = LoadClassIdInstr(r2)
    //     0x126f8ec: ldur            x4, [x2, #-1]
    //     0x126f8f0: ubfx            x4, x4, #0xc, #0x14
    // 0x126f8f4: stp             x0, x2, [SP]
    // 0x126f8f8: mov             x0, x4
    // 0x126f8fc: mov             lr, x0
    // 0x126f900: ldr             lr, [x21, lr, lsl #3]
    // 0x126f904: blr             lr
    // 0x126f908: tbnz            w0, #4, #0x126f9f4
    // 0x126f90c: ldr             x2, [fp, #0x18]
    // 0x126f910: ldr             x1, [fp, #0x10]
    // 0x126f914: LoadField: r0 = r1->field_37
    //     0x126f914: ldur            w0, [x1, #0x37]
    // 0x126f918: DecompressPointer r0
    //     0x126f918: add             x0, x0, HEAP, lsl #32
    // 0x126f91c: LoadField: r3 = r2->field_37
    //     0x126f91c: ldur            w3, [x2, #0x37]
    // 0x126f920: DecompressPointer r3
    //     0x126f920: add             x3, x3, HEAP, lsl #32
    // 0x126f924: r4 = LoadClassIdInstr(r0)
    //     0x126f924: ldur            x4, [x0, #-1]
    //     0x126f928: ubfx            x4, x4, #0xc, #0x14
    // 0x126f92c: stp             x3, x0, [SP]
    // 0x126f930: mov             x0, x4
    // 0x126f934: mov             lr, x0
    // 0x126f938: ldr             lr, [x21, lr, lsl #3]
    // 0x126f93c: blr             lr
    // 0x126f940: tbnz            w0, #4, #0x126f9f4
    // 0x126f944: ldr             x2, [fp, #0x18]
    // 0x126f948: ldr             x1, [fp, #0x10]
    // 0x126f94c: LoadField: r0 = r1->field_3b
    //     0x126f94c: ldur            w0, [x1, #0x3b]
    // 0x126f950: DecompressPointer r0
    //     0x126f950: add             x0, x0, HEAP, lsl #32
    // 0x126f954: LoadField: r3 = r2->field_3b
    //     0x126f954: ldur            w3, [x2, #0x3b]
    // 0x126f958: DecompressPointer r3
    //     0x126f958: add             x3, x3, HEAP, lsl #32
    // 0x126f95c: r4 = LoadClassIdInstr(r0)
    //     0x126f95c: ldur            x4, [x0, #-1]
    //     0x126f960: ubfx            x4, x4, #0xc, #0x14
    // 0x126f964: stp             x3, x0, [SP]
    // 0x126f968: mov             x0, x4
    // 0x126f96c: mov             lr, x0
    // 0x126f970: ldr             lr, [x21, lr, lsl #3]
    // 0x126f974: blr             lr
    // 0x126f978: tbnz            w0, #4, #0x126f9f4
    // 0x126f97c: ldr             x2, [fp, #0x18]
    // 0x126f980: ldr             x1, [fp, #0x10]
    // 0x126f984: LoadField: r0 = r1->field_3f
    //     0x126f984: ldur            w0, [x1, #0x3f]
    // 0x126f988: DecompressPointer r0
    //     0x126f988: add             x0, x0, HEAP, lsl #32
    // 0x126f98c: LoadField: r3 = r2->field_3f
    //     0x126f98c: ldur            w3, [x2, #0x3f]
    // 0x126f990: DecompressPointer r3
    //     0x126f990: add             x3, x3, HEAP, lsl #32
    // 0x126f994: r4 = LoadClassIdInstr(r0)
    //     0x126f994: ldur            x4, [x0, #-1]
    //     0x126f998: ubfx            x4, x4, #0xc, #0x14
    // 0x126f99c: stp             x3, x0, [SP]
    // 0x126f9a0: mov             x0, x4
    // 0x126f9a4: mov             lr, x0
    // 0x126f9a8: ldr             lr, [x21, lr, lsl #3]
    // 0x126f9ac: blr             lr
    // 0x126f9b0: tbnz            w0, #4, #0x126f9f4
    // 0x126f9b4: ldr             x1, [fp, #0x18]
    // 0x126f9b8: ldr             x0, [fp, #0x10]
    // 0x126f9bc: LoadField: r2 = r0->field_43
    //     0x126f9bc: ldur            w2, [x0, #0x43]
    // 0x126f9c0: DecompressPointer r2
    //     0x126f9c0: add             x2, x2, HEAP, lsl #32
    // 0x126f9c4: LoadField: r0 = r1->field_43
    //     0x126f9c4: ldur            w0, [x1, #0x43]
    // 0x126f9c8: DecompressPointer r0
    //     0x126f9c8: add             x0, x0, HEAP, lsl #32
    // 0x126f9cc: r1 = LoadClassIdInstr(r2)
    //     0x126f9cc: ldur            x1, [x2, #-1]
    //     0x126f9d0: ubfx            x1, x1, #0xc, #0x14
    // 0x126f9d4: stp             x0, x2, [SP]
    // 0x126f9d8: mov             x0, x1
    // 0x126f9dc: mov             lr, x0
    // 0x126f9e0: ldr             lr, [x21, lr, lsl #3]
    // 0x126f9e4: blr             lr
    // 0x126f9e8: tbnz            w0, #4, #0x126f9f4
    // 0x126f9ec: r0 = true
    //     0x126f9ec: add             x0, NULL, #0x20  ; true
    // 0x126f9f0: b               #0x126f9f8
    // 0x126f9f4: r0 = false
    //     0x126f9f4: add             x0, NULL, #0x30  ; false
    // 0x126f9f8: LeaveFrame
    //     0x126f9f8: mov             SP, fp
    //     0x126f9fc: ldp             fp, lr, [SP], #0x10
    // 0x126fa00: ret
    //     0x126fa00: ret             
    // 0x126fa04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x126fa04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x126fa08: b               #0x126ec98
    // 0x126fa0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x126fa0c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x126fa10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x126fa10: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x126fa14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x126fa14: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x126fa18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x126fa18: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x126fa1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x126fa1c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x126fa20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x126fa20: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x126fa24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x126fa24: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x126fa28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x126fa28: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x126fa2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x126fa2c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x126fa30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x126fa30: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6843, size: 0x14, field offset: 0x10
//   const constructor, 
class ListTileTheme extends InheritedTheme {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xc0053c, size: 0xa0
    // 0xc0053c: EnterFrame
    //     0xc0053c: stp             fp, lr, [SP, #-0x10]!
    //     0xc00540: mov             fp, SP
    // 0xc00544: AllocStack(0x20)
    //     0xc00544: sub             SP, SP, #0x20
    // 0xc00548: SetupParameters(ListTileTheme this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xc00548: mov             x4, x1
    //     0xc0054c: mov             x3, x2
    //     0xc00550: stur            x1, [fp, #-8]
    //     0xc00554: stur            x2, [fp, #-0x10]
    // 0xc00558: CheckStackOverflow
    //     0xc00558: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0055c: cmp             SP, x16
    //     0xc00560: b.ls            #0xc005d4
    // 0xc00564: mov             x0, x3
    // 0xc00568: r2 = Null
    //     0xc00568: mov             x2, NULL
    // 0xc0056c: r1 = Null
    //     0xc0056c: mov             x1, NULL
    // 0xc00570: r4 = 60
    //     0xc00570: mov             x4, #0x3c
    // 0xc00574: branchIfSmi(r0, 0xc00580)
    //     0xc00574: tbz             w0, #0, #0xc00580
    // 0xc00578: r4 = LoadClassIdInstr(r0)
    //     0xc00578: ldur            x4, [x0, #-1]
    //     0xc0057c: ubfx            x4, x4, #0xc, #0x14
    // 0xc00580: r17 = 6843
    //     0xc00580: mov             x17, #0x1abb
    // 0xc00584: cmp             x4, x17
    // 0xc00588: b.eq            #0xc005a0
    // 0xc0058c: r8 = ListTileTheme
    //     0xc0058c: add             x8, PP, #0xa0, lsl #12  ; [pp+0xa0ec8] Type: ListTileTheme
    //     0xc00590: ldr             x8, [x8, #0xec8]
    // 0xc00594: r3 = Null
    //     0xc00594: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0ed0] Null
    //     0xc00598: ldr             x3, [x3, #0xed0]
    // 0xc0059c: r0 = DefaultTypeTest()
    //     0xc0059c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc005a0: ldur            x0, [fp, #-8]
    // 0xc005a4: LoadField: r1 = r0->field_f
    //     0xc005a4: ldur            w1, [x0, #0xf]
    // 0xc005a8: DecompressPointer r1
    //     0xc005a8: add             x1, x1, HEAP, lsl #32
    // 0xc005ac: ldur            x0, [fp, #-0x10]
    // 0xc005b0: LoadField: r2 = r0->field_f
    //     0xc005b0: ldur            w2, [x0, #0xf]
    // 0xc005b4: DecompressPointer r2
    //     0xc005b4: add             x2, x2, HEAP, lsl #32
    // 0xc005b8: stp             x2, x1, [SP]
    // 0xc005bc: r0 = ==()
    //     0xc005bc: bl              #0x126ec80  ; [package:flutter/src/material/list_tile_theme.dart] ListTileThemeData::==
    // 0xc005c0: eor             x1, x0, #0x10
    // 0xc005c4: mov             x0, x1
    // 0xc005c8: LeaveFrame
    //     0xc005c8: mov             SP, fp
    //     0xc005cc: ldp             fp, lr, [SP], #0x10
    // 0xc005d0: ret
    //     0xc005d0: ret             
    // 0xc005d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc005d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc005d8: b               #0xc00564
  }
  static _ merge(/* No info */) {
    // ** addr: 0xd19d10, size: 0x22c
    // 0xd19d10: EnterFrame
    //     0xd19d10: stp             fp, lr, [SP, #-0x10]!
    //     0xd19d14: mov             fp, SP
    // 0xd19d18: AllocStack(0x30)
    //     0xd19d18: sub             SP, SP, #0x30
    // 0xd19d1c: SetupParameters(dynamic _ /* r1 => r1, fp-0x30 */, {dynamic contentPadding = Null /* r2, fp-0x28 */, dynamic iconColor = Null /* r3, fp-0x20 */, dynamic style = Null /* r5, fp-0x18 */, dynamic textColor = Null /* r6, fp-0x10 */, dynamic titleTextStyle = Null /* r0, fp-0x8 */})
    //     0xd19d1c: stur            x1, [fp, #-0x30]
    //     0xd19d20: ldur            w0, [x4, #0x13]
    //     0xd19d24: ldur            w2, [x4, #0x1f]
    //     0xd19d28: add             x2, x2, HEAP, lsl #32
    //     0xd19d2c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a920] "contentPadding"
    //     0xd19d30: ldr             x16, [x16, #0x920]
    //     0xd19d34: cmp             w2, w16
    //     0xd19d38: b.ne            #0xd19d58
    //     0xd19d3c: ldur            w2, [x4, #0x23]
    //     0xd19d40: add             x2, x2, HEAP, lsl #32
    //     0xd19d44: sub             w3, w0, w2
    //     0xd19d48: add             x2, fp, w3, sxtw #2
    //     0xd19d4c: ldr             x2, [x2, #8]
    //     0xd19d50: mov             x3, #1
    //     0xd19d54: b               #0xd19d60
    //     0xd19d58: mov             x3, #0
    //     0xd19d5c: mov             x2, NULL
    //     0xd19d60: stur            x2, [fp, #-0x28]
    //     0xd19d64: lsl             x5, x3, #1
    //     0xd19d68: lsl             w6, w5, #1
    //     0xd19d6c: add             w7, w6, #8
    //     0xd19d70: add             x16, x4, w7, sxtw #1
    //     0xd19d74: ldur            w8, [x16, #0xf]
    //     0xd19d78: add             x8, x8, HEAP, lsl #32
    //     0xd19d7c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a9d0] "iconColor"
    //     0xd19d80: ldr             x16, [x16, #0x9d0]
    //     0xd19d84: cmp             w8, w16
    //     0xd19d88: b.ne            #0xd19db8
    //     0xd19d8c: add             w3, w6, #0xa
    //     0xd19d90: add             x16, x4, w3, sxtw #1
    //     0xd19d94: ldur            w6, [x16, #0xf]
    //     0xd19d98: add             x6, x6, HEAP, lsl #32
    //     0xd19d9c: sub             w3, w0, w6
    //     0xd19da0: add             x6, fp, w3, sxtw #2
    //     0xd19da4: ldr             x6, [x6, #8]
    //     0xd19da8: add             w3, w5, #2
    //     0xd19dac: sbfx            x5, x3, #1, #0x1f
    //     0xd19db0: mov             x3, x6
    //     0xd19db4: b               #0xd19dc0
    //     0xd19db8: mov             x5, x3
    //     0xd19dbc: mov             x3, NULL
    //     0xd19dc0: stur            x3, [fp, #-0x20]
    //     0xd19dc4: lsl             x6, x5, #1
    //     0xd19dc8: lsl             w7, w6, #1
    //     0xd19dcc: add             w8, w7, #8
    //     0xd19dd0: add             x16, x4, w8, sxtw #1
    //     0xd19dd4: ldur            w9, [x16, #0xf]
    //     0xd19dd8: add             x9, x9, HEAP, lsl #32
    //     0xd19ddc: add             x16, PP, #8, lsl #12  ; [pp+0x8400] "style"
    //     0xd19de0: ldr             x16, [x16, #0x400]
    //     0xd19de4: cmp             w9, w16
    //     0xd19de8: b.ne            #0xd19e18
    //     0xd19dec: add             w5, w7, #0xa
    //     0xd19df0: add             x16, x4, w5, sxtw #1
    //     0xd19df4: ldur            w7, [x16, #0xf]
    //     0xd19df8: add             x7, x7, HEAP, lsl #32
    //     0xd19dfc: sub             w5, w0, w7
    //     0xd19e00: add             x7, fp, w5, sxtw #2
    //     0xd19e04: ldr             x7, [x7, #8]
    //     0xd19e08: add             w5, w6, #2
    //     0xd19e0c: sbfx            x6, x5, #1, #0x1f
    //     0xd19e10: mov             x5, x7
    //     0xd19e14: b               #0xd19e20
    //     0xd19e18: mov             x6, x5
    //     0xd19e1c: mov             x5, NULL
    //     0xd19e20: stur            x5, [fp, #-0x18]
    //     0xd19e24: lsl             x7, x6, #1
    //     0xd19e28: lsl             w8, w7, #1
    //     0xd19e2c: add             w9, w8, #8
    //     0xd19e30: add             x16, x4, w9, sxtw #1
    //     0xd19e34: ldur            w10, [x16, #0xf]
    //     0xd19e38: add             x10, x10, HEAP, lsl #32
    //     0xd19e3c: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e2b0] "textColor"
    //     0xd19e40: ldr             x16, [x16, #0x2b0]
    //     0xd19e44: cmp             w10, w16
    //     0xd19e48: b.ne            #0xd19e78
    //     0xd19e4c: add             w6, w8, #0xa
    //     0xd19e50: add             x16, x4, w6, sxtw #1
    //     0xd19e54: ldur            w8, [x16, #0xf]
    //     0xd19e58: add             x8, x8, HEAP, lsl #32
    //     0xd19e5c: sub             w6, w0, w8
    //     0xd19e60: add             x8, fp, w6, sxtw #2
    //     0xd19e64: ldr             x8, [x8, #8]
    //     0xd19e68: add             w6, w7, #2
    //     0xd19e6c: sbfx            x7, x6, #1, #0x1f
    //     0xd19e70: mov             x6, x8
    //     0xd19e74: b               #0xd19e80
    //     0xd19e78: mov             x7, x6
    //     0xd19e7c: mov             x6, NULL
    //     0xd19e80: stur            x6, [fp, #-0x10]
    //     0xd19e84: lsl             x8, x7, #1
    //     0xd19e88: lsl             w7, w8, #1
    //     0xd19e8c: add             w8, w7, #8
    //     0xd19e90: add             x16, x4, w8, sxtw #1
    //     0xd19e94: ldur            w9, [x16, #0xf]
    //     0xd19e98: add             x9, x9, HEAP, lsl #32
    //     0xd19e9c: add             x16, PP, #0x8e, lsl #12  ; [pp+0x8e370] "titleTextStyle"
    //     0xd19ea0: ldr             x16, [x16, #0x370]
    //     0xd19ea4: cmp             w9, w16
    //     0xd19ea8: b.ne            #0xd19ecc
    //     0xd19eac: add             w8, w7, #0xa
    //     0xd19eb0: add             x16, x4, w8, sxtw #1
    //     0xd19eb4: ldur            w7, [x16, #0xf]
    //     0xd19eb8: add             x7, x7, HEAP, lsl #32
    //     0xd19ebc: sub             w4, w0, w7
    //     0xd19ec0: add             x0, fp, w4, sxtw #2
    //     0xd19ec4: ldr             x0, [x0, #8]
    //     0xd19ec8: b               #0xd19ed0
    //     0xd19ecc: mov             x0, NULL
    //     0xd19ed0: stur            x0, [fp, #-8]
    // 0xd19ed4: r1 = 6
    //     0xd19ed4: mov             x1, #6
    // 0xd19ed8: r0 = AllocateContext()
    //     0xd19ed8: bl              #0x13de838  ; AllocateContextStub
    // 0xd19edc: mov             x1, x0
    // 0xd19ee0: ldur            x0, [fp, #-0x30]
    // 0xd19ee4: StoreField: r1->field_f = r0
    //     0xd19ee4: stur            w0, [x1, #0xf]
    // 0xd19ee8: ldur            x0, [fp, #-0x28]
    // 0xd19eec: StoreField: r1->field_13 = r0
    //     0xd19eec: stur            w0, [x1, #0x13]
    // 0xd19ef0: ldur            x0, [fp, #-0x20]
    // 0xd19ef4: ArrayStore: r1[0] = r0  ; List_4
    //     0xd19ef4: stur            w0, [x1, #0x17]
    // 0xd19ef8: ldur            x0, [fp, #-0x18]
    // 0xd19efc: StoreField: r1->field_1b = r0
    //     0xd19efc: stur            w0, [x1, #0x1b]
    // 0xd19f00: ldur            x0, [fp, #-0x10]
    // 0xd19f04: StoreField: r1->field_1f = r0
    //     0xd19f04: stur            w0, [x1, #0x1f]
    // 0xd19f08: ldur            x0, [fp, #-8]
    // 0xd19f0c: StoreField: r1->field_23 = r0
    //     0xd19f0c: stur            w0, [x1, #0x23]
    // 0xd19f10: mov             x2, x1
    // 0xd19f14: r1 = Function '<anonymous closure>': static.
    //     0xd19f14: add             x1, PP, #0x95, lsl #12  ; [pp+0x95d18] AnonymousClosure: static (0xd19f3c), in [package:flutter/src/material/list_tile_theme.dart] ListTileTheme::merge (0xd19d10)
    //     0xd19f18: ldr             x1, [x1, #0xd18]
    // 0xd19f1c: r0 = AllocateClosure()
    //     0xd19f1c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd19f20: stur            x0, [fp, #-8]
    // 0xd19f24: r0 = Builder()
    //     0xd19f24: bl              #0x858774  ; AllocateBuilderStub -> Builder (size=0x10)
    // 0xd19f28: ldur            x1, [fp, #-8]
    // 0xd19f2c: StoreField: r0->field_b = r1
    //     0xd19f2c: stur            w1, [x0, #0xb]
    // 0xd19f30: LeaveFrame
    //     0xd19f30: mov             SP, fp
    //     0xd19f34: ldp             fp, lr, [SP], #0x10
    // 0xd19f38: ret
    //     0xd19f38: ret             
  }
  [closure] static ListTileTheme <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xd19f3c, size: 0x190
    // 0xd19f3c: EnterFrame
    //     0xd19f3c: stp             fp, lr, [SP, #-0x10]!
    //     0xd19f40: mov             fp, SP
    // 0xd19f44: AllocStack(0x60)
    //     0xd19f44: sub             SP, SP, #0x60
    // 0xd19f48: SetupParameters([dynamic _ /* r0 */])
    //     0xd19f48: ldr             x0, [fp, #0x18]
    //     0xd19f4c: ldur            w2, [x0, #0x17]
    //     0xd19f50: add             x2, x2, HEAP, lsl #32
    //     0xd19f54: stur            x2, [fp, #-8]
    // 0xd19f58: CheckStackOverflow
    //     0xd19f58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd19f5c: cmp             SP, x16
    //     0xd19f60: b.ls            #0xd1a0c4
    // 0xd19f64: ldr             x1, [fp, #0x10]
    // 0xd19f68: r0 = of()
    //     0xd19f68: bl              #0xd1a0e4  ; [package:flutter/src/material/list_tile_theme.dart] ListTileTheme::of
    // 0xd19f6c: LoadField: r1 = r0->field_b
    //     0xd19f6c: ldur            w1, [x0, #0xb]
    // 0xd19f70: DecompressPointer r1
    //     0xd19f70: add             x1, x1, HEAP, lsl #32
    // 0xd19f74: ldur            x2, [fp, #-8]
    // 0xd19f78: stur            x1, [fp, #-0x58]
    // 0xd19f7c: LoadField: r3 = r2->field_1b
    //     0xd19f7c: ldur            w3, [x2, #0x1b]
    // 0xd19f80: DecompressPointer r3
    //     0xd19f80: add             x3, x3, HEAP, lsl #32
    // 0xd19f84: cmp             w3, NULL
    // 0xd19f88: b.ne            #0xd19f94
    // 0xd19f8c: LoadField: r3 = r0->field_f
    //     0xd19f8c: ldur            w3, [x0, #0xf]
    // 0xd19f90: DecompressPointer r3
    //     0xd19f90: add             x3, x3, HEAP, lsl #32
    // 0xd19f94: stur            x3, [fp, #-0x50]
    // 0xd19f98: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd19f98: ldur            w4, [x2, #0x17]
    // 0xd19f9c: DecompressPointer r4
    //     0xd19f9c: add             x4, x4, HEAP, lsl #32
    // 0xd19fa0: cmp             w4, NULL
    // 0xd19fa4: b.ne            #0xd19fb0
    // 0xd19fa8: ArrayLoad: r4 = r0[0]  ; List_4
    //     0xd19fa8: ldur            w4, [x0, #0x17]
    // 0xd19fac: DecompressPointer r4
    //     0xd19fac: add             x4, x4, HEAP, lsl #32
    // 0xd19fb0: stur            x4, [fp, #-0x48]
    // 0xd19fb4: LoadField: r5 = r2->field_1f
    //     0xd19fb4: ldur            w5, [x2, #0x1f]
    // 0xd19fb8: DecompressPointer r5
    //     0xd19fb8: add             x5, x5, HEAP, lsl #32
    // 0xd19fbc: cmp             w5, NULL
    // 0xd19fc0: b.ne            #0xd19fcc
    // 0xd19fc4: LoadField: r5 = r0->field_1b
    //     0xd19fc4: ldur            w5, [x0, #0x1b]
    // 0xd19fc8: DecompressPointer r5
    //     0xd19fc8: add             x5, x5, HEAP, lsl #32
    // 0xd19fcc: stur            x5, [fp, #-0x40]
    // 0xd19fd0: LoadField: r6 = r2->field_23
    //     0xd19fd0: ldur            w6, [x2, #0x23]
    // 0xd19fd4: DecompressPointer r6
    //     0xd19fd4: add             x6, x6, HEAP, lsl #32
    // 0xd19fd8: cmp             w6, NULL
    // 0xd19fdc: b.ne            #0xd19fe8
    // 0xd19fe0: LoadField: r6 = r0->field_1f
    //     0xd19fe0: ldur            w6, [x0, #0x1f]
    // 0xd19fe4: DecompressPointer r6
    //     0xd19fe4: add             x6, x6, HEAP, lsl #32
    // 0xd19fe8: stur            x6, [fp, #-0x38]
    // 0xd19fec: LoadField: r7 = r2->field_13
    //     0xd19fec: ldur            w7, [x2, #0x13]
    // 0xd19ff0: DecompressPointer r7
    //     0xd19ff0: add             x7, x7, HEAP, lsl #32
    // 0xd19ff4: cmp             w7, NULL
    // 0xd19ff8: b.ne            #0xd1a004
    // 0xd19ffc: LoadField: r7 = r0->field_2b
    //     0xd19ffc: ldur            w7, [x0, #0x2b]
    // 0xd1a000: DecompressPointer r7
    //     0xd1a000: add             x7, x7, HEAP, lsl #32
    // 0xd1a004: stur            x7, [fp, #-0x30]
    // 0xd1a008: LoadField: r8 = r0->field_37
    //     0xd1a008: ldur            w8, [x0, #0x37]
    // 0xd1a00c: DecompressPointer r8
    //     0xd1a00c: add             x8, x8, HEAP, lsl #32
    // 0xd1a010: stur            x8, [fp, #-0x28]
    // 0xd1a014: LoadField: r9 = r0->field_3b
    //     0xd1a014: ldur            w9, [x0, #0x3b]
    // 0xd1a018: DecompressPointer r9
    //     0xd1a018: add             x9, x9, HEAP, lsl #32
    // 0xd1a01c: stur            x9, [fp, #-0x20]
    // 0xd1a020: LoadField: r10 = r0->field_3f
    //     0xd1a020: ldur            w10, [x0, #0x3f]
    // 0xd1a024: DecompressPointer r10
    //     0xd1a024: add             x10, x10, HEAP, lsl #32
    // 0xd1a028: stur            x10, [fp, #-0x18]
    // 0xd1a02c: LoadField: r11 = r0->field_43
    //     0xd1a02c: ldur            w11, [x0, #0x43]
    // 0xd1a030: DecompressPointer r11
    //     0xd1a030: add             x11, x11, HEAP, lsl #32
    // 0xd1a034: stur            x11, [fp, #-0x10]
    // 0xd1a038: r0 = ListTileThemeData()
    //     0xd1a038: bl              #0xd1a0d8  ; AllocateListTileThemeDataStub -> ListTileThemeData (size=0x60)
    // 0xd1a03c: mov             x1, x0
    // 0xd1a040: ldur            x0, [fp, #-0x58]
    // 0xd1a044: stur            x1, [fp, #-0x60]
    // 0xd1a048: StoreField: r1->field_b = r0
    //     0xd1a048: stur            w0, [x1, #0xb]
    // 0xd1a04c: ldur            x0, [fp, #-0x50]
    // 0xd1a050: StoreField: r1->field_f = r0
    //     0xd1a050: stur            w0, [x1, #0xf]
    // 0xd1a054: ldur            x0, [fp, #-0x48]
    // 0xd1a058: ArrayStore: r1[0] = r0  ; List_4
    //     0xd1a058: stur            w0, [x1, #0x17]
    // 0xd1a05c: ldur            x0, [fp, #-0x40]
    // 0xd1a060: StoreField: r1->field_1b = r0
    //     0xd1a060: stur            w0, [x1, #0x1b]
    // 0xd1a064: ldur            x0, [fp, #-0x38]
    // 0xd1a068: StoreField: r1->field_1f = r0
    //     0xd1a068: stur            w0, [x1, #0x1f]
    // 0xd1a06c: ldur            x0, [fp, #-0x30]
    // 0xd1a070: StoreField: r1->field_2b = r0
    //     0xd1a070: stur            w0, [x1, #0x2b]
    // 0xd1a074: ldur            x0, [fp, #-0x28]
    // 0xd1a078: StoreField: r1->field_37 = r0
    //     0xd1a078: stur            w0, [x1, #0x37]
    // 0xd1a07c: ldur            x0, [fp, #-0x20]
    // 0xd1a080: StoreField: r1->field_3b = r0
    //     0xd1a080: stur            w0, [x1, #0x3b]
    // 0xd1a084: ldur            x0, [fp, #-0x18]
    // 0xd1a088: StoreField: r1->field_3f = r0
    //     0xd1a088: stur            w0, [x1, #0x3f]
    // 0xd1a08c: ldur            x0, [fp, #-0x10]
    // 0xd1a090: StoreField: r1->field_43 = r0
    //     0xd1a090: stur            w0, [x1, #0x43]
    // 0xd1a094: ldur            x0, [fp, #-8]
    // 0xd1a098: LoadField: r2 = r0->field_f
    //     0xd1a098: ldur            w2, [x0, #0xf]
    // 0xd1a09c: DecompressPointer r2
    //     0xd1a09c: add             x2, x2, HEAP, lsl #32
    // 0xd1a0a0: stur            x2, [fp, #-0x10]
    // 0xd1a0a4: r0 = ListTileTheme()
    //     0xd1a0a4: bl              #0xd1a0cc  ; AllocateListTileThemeStub -> ListTileTheme (size=0x14)
    // 0xd1a0a8: ldur            x1, [fp, #-0x60]
    // 0xd1a0ac: StoreField: r0->field_f = r1
    //     0xd1a0ac: stur            w1, [x0, #0xf]
    // 0xd1a0b0: ldur            x1, [fp, #-0x10]
    // 0xd1a0b4: StoreField: r0->field_b = r1
    //     0xd1a0b4: stur            w1, [x0, #0xb]
    // 0xd1a0b8: LeaveFrame
    //     0xd1a0b8: mov             SP, fp
    //     0xd1a0bc: ldp             fp, lr, [SP], #0x10
    // 0xd1a0c0: ret
    //     0xd1a0c0: ret             
    // 0xd1a0c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1a0c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1a0c8: b               #0xd19f64
  }
  static _ of(/* No info */) {
    // ** addr: 0xd1a0e4, size: 0x7c
    // 0xd1a0e4: EnterFrame
    //     0xd1a0e4: stp             fp, lr, [SP, #-0x10]!
    //     0xd1a0e8: mov             fp, SP
    // 0xd1a0ec: AllocStack(0x18)
    //     0xd1a0ec: sub             SP, SP, #0x18
    // 0xd1a0f0: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xd1a0f0: stur            x1, [fp, #-8]
    // 0xd1a0f4: CheckStackOverflow
    //     0xd1a0f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1a0f8: cmp             SP, x16
    //     0xd1a0fc: b.ls            #0xd1a158
    // 0xd1a100: r16 = <ListTileTheme>
    //     0xd1a100: add             x16, PP, #0x84, lsl #12  ; [pp+0x84a68] TypeArguments: <ListTileTheme>
    //     0xd1a104: ldr             x16, [x16, #0xa68]
    // 0xd1a108: stp             x1, x16, [SP]
    // 0xd1a10c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd1a10c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd1a110: r0 = dependOnInheritedWidgetOfExactType()
    //     0xd1a110: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xd1a114: cmp             w0, NULL
    // 0xd1a118: b.ne            #0xd1a124
    // 0xd1a11c: r0 = Null
    //     0xd1a11c: mov             x0, NULL
    // 0xd1a120: b               #0xd1a130
    // 0xd1a124: LoadField: r1 = r0->field_f
    //     0xd1a124: ldur            w1, [x0, #0xf]
    // 0xd1a128: DecompressPointer r1
    //     0xd1a128: add             x1, x1, HEAP, lsl #32
    // 0xd1a12c: mov             x0, x1
    // 0xd1a130: cmp             w0, NULL
    // 0xd1a134: b.ne            #0xd1a14c
    // 0xd1a138: ldur            x1, [fp, #-8]
    // 0xd1a13c: r0 = of()
    //     0xd1a13c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd1a140: LoadField: r1 = r0->field_eb
    //     0xd1a140: ldur            w1, [x0, #0xeb]
    // 0xd1a144: DecompressPointer r1
    //     0xd1a144: add             x1, x1, HEAP, lsl #32
    // 0xd1a148: mov             x0, x1
    // 0xd1a14c: LeaveFrame
    //     0xd1a14c: mov             SP, fp
    //     0xd1a150: ldp             fp, lr, [SP], #0x10
    // 0xd1a154: ret
    //     0xd1a154: ret             
    // 0xd1a158: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1a158: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1a15c: b               #0xd1a100
  }
  _ wrap(/* No info */) {
    // ** addr: 0x1200e00, size: 0xe4
    // 0x1200e00: EnterFrame
    //     0x1200e00: stp             fp, lr, [SP, #-0x10]!
    //     0x1200e04: mov             fp, SP
    // 0x1200e08: AllocStack(0x50)
    //     0x1200e08: sub             SP, SP, #0x50
    // 0x1200e0c: SetupParameters(dynamic _ /* r2 => r2, fp-0x48 */)
    //     0x1200e0c: stur            x2, [fp, #-0x48]
    // 0x1200e10: LoadField: r0 = r1->field_f
    //     0x1200e10: ldur            w0, [x1, #0xf]
    // 0x1200e14: DecompressPointer r0
    //     0x1200e14: add             x0, x0, HEAP, lsl #32
    // 0x1200e18: LoadField: r1 = r0->field_b
    //     0x1200e18: ldur            w1, [x0, #0xb]
    // 0x1200e1c: DecompressPointer r1
    //     0x1200e1c: add             x1, x1, HEAP, lsl #32
    // 0x1200e20: stur            x1, [fp, #-0x40]
    // 0x1200e24: LoadField: r3 = r0->field_f
    //     0x1200e24: ldur            w3, [x0, #0xf]
    // 0x1200e28: DecompressPointer r3
    //     0x1200e28: add             x3, x3, HEAP, lsl #32
    // 0x1200e2c: stur            x3, [fp, #-0x38]
    // 0x1200e30: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x1200e30: ldur            w4, [x0, #0x17]
    // 0x1200e34: DecompressPointer r4
    //     0x1200e34: add             x4, x4, HEAP, lsl #32
    // 0x1200e38: stur            x4, [fp, #-0x30]
    // 0x1200e3c: LoadField: r5 = r0->field_1b
    //     0x1200e3c: ldur            w5, [x0, #0x1b]
    // 0x1200e40: DecompressPointer r5
    //     0x1200e40: add             x5, x5, HEAP, lsl #32
    // 0x1200e44: stur            x5, [fp, #-0x28]
    // 0x1200e48: LoadField: r6 = r0->field_2b
    //     0x1200e48: ldur            w6, [x0, #0x2b]
    // 0x1200e4c: DecompressPointer r6
    //     0x1200e4c: add             x6, x6, HEAP, lsl #32
    // 0x1200e50: stur            x6, [fp, #-0x20]
    // 0x1200e54: LoadField: r7 = r0->field_37
    //     0x1200e54: ldur            w7, [x0, #0x37]
    // 0x1200e58: DecompressPointer r7
    //     0x1200e58: add             x7, x7, HEAP, lsl #32
    // 0x1200e5c: stur            x7, [fp, #-0x18]
    // 0x1200e60: LoadField: r8 = r0->field_3b
    //     0x1200e60: ldur            w8, [x0, #0x3b]
    // 0x1200e64: DecompressPointer r8
    //     0x1200e64: add             x8, x8, HEAP, lsl #32
    // 0x1200e68: stur            x8, [fp, #-0x10]
    // 0x1200e6c: LoadField: r9 = r0->field_3f
    //     0x1200e6c: ldur            w9, [x0, #0x3f]
    // 0x1200e70: DecompressPointer r9
    //     0x1200e70: add             x9, x9, HEAP, lsl #32
    // 0x1200e74: stur            x9, [fp, #-8]
    // 0x1200e78: r0 = ListTileThemeData()
    //     0x1200e78: bl              #0xd1a0d8  ; AllocateListTileThemeDataStub -> ListTileThemeData (size=0x60)
    // 0x1200e7c: mov             x1, x0
    // 0x1200e80: ldur            x0, [fp, #-0x40]
    // 0x1200e84: stur            x1, [fp, #-0x50]
    // 0x1200e88: StoreField: r1->field_b = r0
    //     0x1200e88: stur            w0, [x1, #0xb]
    // 0x1200e8c: ldur            x0, [fp, #-0x38]
    // 0x1200e90: StoreField: r1->field_f = r0
    //     0x1200e90: stur            w0, [x1, #0xf]
    // 0x1200e94: ldur            x0, [fp, #-0x30]
    // 0x1200e98: ArrayStore: r1[0] = r0  ; List_4
    //     0x1200e98: stur            w0, [x1, #0x17]
    // 0x1200e9c: ldur            x0, [fp, #-0x28]
    // 0x1200ea0: StoreField: r1->field_1b = r0
    //     0x1200ea0: stur            w0, [x1, #0x1b]
    // 0x1200ea4: ldur            x0, [fp, #-0x20]
    // 0x1200ea8: StoreField: r1->field_2b = r0
    //     0x1200ea8: stur            w0, [x1, #0x2b]
    // 0x1200eac: ldur            x0, [fp, #-0x18]
    // 0x1200eb0: StoreField: r1->field_37 = r0
    //     0x1200eb0: stur            w0, [x1, #0x37]
    // 0x1200eb4: ldur            x0, [fp, #-0x10]
    // 0x1200eb8: StoreField: r1->field_3b = r0
    //     0x1200eb8: stur            w0, [x1, #0x3b]
    // 0x1200ebc: ldur            x0, [fp, #-8]
    // 0x1200ec0: StoreField: r1->field_3f = r0
    //     0x1200ec0: stur            w0, [x1, #0x3f]
    // 0x1200ec4: r0 = ListTileTheme()
    //     0x1200ec4: bl              #0xd1a0cc  ; AllocateListTileThemeStub -> ListTileTheme (size=0x14)
    // 0x1200ec8: ldur            x1, [fp, #-0x50]
    // 0x1200ecc: StoreField: r0->field_f = r1
    //     0x1200ecc: stur            w1, [x0, #0xf]
    // 0x1200ed0: ldur            x1, [fp, #-0x48]
    // 0x1200ed4: StoreField: r0->field_b = r1
    //     0x1200ed4: stur            w1, [x0, #0xb]
    // 0x1200ed8: LeaveFrame
    //     0x1200ed8: mov             SP, fp
    //     0x1200edc: ldp             fp, lr, [SP], #0x10
    // 0x1200ee0: ret
    //     0x1200ee0: ret             
  }
}
