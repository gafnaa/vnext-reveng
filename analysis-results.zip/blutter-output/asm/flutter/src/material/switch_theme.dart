// lib: , url: package:flutter/src/material/switch_theme.dart

// class id: 1048954, size: 0x8
class :: {
}

// class id: 5062, size: 0x30, field offset: 0x8
//   const constructor, 
class SwitchThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x1137970, size: 0x640
    // 0x1137970: EnterFrame
    //     0x1137970: stp             fp, lr, [SP, #-0x10]!
    //     0x1137974: mov             fp, SP
    // 0x1137978: AllocStack(0x78)
    //     0x1137978: sub             SP, SP, #0x78
    // 0x113797c: CheckStackOverflow
    //     0x113797c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1137980: cmp             SP, x16
    //     0x1137984: b.ls            #0x1137fa8
    // 0x1137988: ldr             x0, [fp, #0x10]
    // 0x113798c: r1 = LoadClassIdInstr(r0)
    //     0x113798c: ldur            x1, [x0, #-1]
    //     0x1137990: ubfx            x1, x1, #0xc, #0x14
    // 0x1137994: stur            x1, [fp, #-8]
    // 0x1137998: r17 = 5062
    //     0x1137998: mov             x17, #0x13c6
    // 0x113799c: cmp             x1, x17
    // 0x11379a0: b.ne            #0x11379b8
    // 0x11379a4: LoadField: r2 = r0->field_7
    //     0x11379a4: ldur            w2, [x0, #7]
    // 0x11379a8: DecompressPointer r2
    //     0x11379a8: add             x2, x2, HEAP, lsl #32
    // 0x11379ac: mov             x0, x1
    // 0x11379b0: mov             x1, x2
    // 0x11379b4: b               #0x1137a9c
    // 0x11379b8: r17 = 5063
    //     0x11379b8: mov             x17, #0x13c7
    // 0x11379bc: cmp             x1, x17
    // 0x11379c0: b.ne            #0x1137a08
    // 0x11379c4: r1 = 1
    //     0x11379c4: mov             x1, #1
    // 0x11379c8: r0 = AllocateContext()
    //     0x11379c8: bl              #0x13de838  ; AllocateContextStub
    // 0x11379cc: mov             x1, x0
    // 0x11379d0: ldr             x0, [fp, #0x10]
    // 0x11379d4: StoreField: r1->field_f = r0
    //     0x11379d4: stur            w0, [x1, #0xf]
    // 0x11379d8: mov             x2, x1
    // 0x11379dc: r1 = Function '<anonymous closure>':.
    //     0x11379dc: add             x1, PP, #0x26, lsl #12  ; [pp+0x26110] AnonymousClosure: (0xd44f24), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0x11379e0: ldr             x1, [x1, #0x110]
    // 0x11379e4: r0 = AllocateClosure()
    //     0x11379e4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11379e8: r16 = <Color>
    //     0x11379e8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x11379ec: ldr             x16, [x16, #0xa90]
    // 0x11379f0: stp             x0, x16, [SP]
    // 0x11379f4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x11379f4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x11379f8: r0 = resolveWith()
    //     0x11379f8: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x11379fc: mov             x1, x0
    // 0x1137a00: ldur            x0, [fp, #-8]
    // 0x1137a04: b               #0x1137a9c
    // 0x1137a08: mov             x0, x1
    // 0x1137a0c: r17 = 5064
    //     0x1137a0c: mov             x17, #0x13c8
    // 0x1137a10: cmp             x0, x17
    // 0x1137a14: b.ne            #0x1137a90
    // 0x1137a18: ldr             x1, [fp, #0x10]
    // 0x1137a1c: r1 = 2
    //     0x1137a1c: mov             x1, #2
    // 0x1137a20: r0 = AllocateContext()
    //     0x1137a20: bl              #0x13de838  ; AllocateContextStub
    // 0x1137a24: mov             x1, x0
    // 0x1137a28: ldr             x0, [fp, #0x10]
    // 0x1137a2c: StoreField: r1->field_f = r0
    //     0x1137a2c: stur            w0, [x1, #0xf]
    // 0x1137a30: LoadField: r2 = r0->field_2f
    //     0x1137a30: ldur            w2, [x0, #0x2f]
    // 0x1137a34: DecompressPointer r2
    //     0x1137a34: add             x2, x2, HEAP, lsl #32
    // 0x1137a38: LoadField: r3 = r2->field_3f
    //     0x1137a38: ldur            w3, [x2, #0x3f]
    // 0x1137a3c: DecompressPointer r3
    //     0x1137a3c: add             x3, x3, HEAP, lsl #32
    // 0x1137a40: LoadField: r2 = r3->field_7
    //     0x1137a40: ldur            w2, [x3, #7]
    // 0x1137a44: DecompressPointer r2
    //     0x1137a44: add             x2, x2, HEAP, lsl #32
    // 0x1137a48: r16 = Instance_Brightness
    //     0x1137a48: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x1137a4c: cmp             w2, w16
    // 0x1137a50: r16 = true
    //     0x1137a50: add             x16, NULL, #0x20  ; true
    // 0x1137a54: r17 = false
    //     0x1137a54: add             x17, NULL, #0x30  ; false
    // 0x1137a58: csel            x3, x16, x17, eq
    // 0x1137a5c: StoreField: r1->field_13 = r3
    //     0x1137a5c: stur            w3, [x1, #0x13]
    // 0x1137a60: mov             x2, x1
    // 0x1137a64: r1 = Function '<anonymous closure>':.
    //     0x1137a64: add             x1, PP, #0x26, lsl #12  ; [pp+0x26118] AnonymousClosure: (0xd44d38), in [package:flutter/src/material/switch.dart] _SwitchDefaultsM2::thumbColor (0x129d570)
    //     0x1137a68: ldr             x1, [x1, #0x118]
    // 0x1137a6c: r0 = AllocateClosure()
    //     0x1137a6c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1137a70: r16 = <Color>
    //     0x1137a70: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1137a74: ldr             x16, [x16, #0xa90]
    // 0x1137a78: stp             x0, x16, [SP]
    // 0x1137a7c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1137a7c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1137a80: r0 = resolveWith()
    //     0x1137a80: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1137a84: mov             x1, x0
    // 0x1137a88: ldur            x0, [fp, #-8]
    // 0x1137a8c: b               #0x1137a9c
    // 0x1137a90: ldur            x0, [fp, #-8]
    // 0x1137a94: r1 = Instance_WidgetStatePropertyAll
    //     0x1137a94: add             x1, PP, #0x26, lsl #12  ; [pp+0x26120] Obj!WidgetStatePropertyAll<Color>@128a081
    //     0x1137a98: ldr             x1, [x1, #0x120]
    // 0x1137a9c: stur            x1, [fp, #-0x10]
    // 0x1137aa0: r17 = 5062
    //     0x1137aa0: mov             x17, #0x13c6
    // 0x1137aa4: cmp             x0, x17
    // 0x1137aa8: b.ne            #0x1137ac0
    // 0x1137aac: ldr             x2, [fp, #0x10]
    // 0x1137ab0: LoadField: r3 = r2->field_b
    //     0x1137ab0: ldur            w3, [x2, #0xb]
    // 0x1137ab4: DecompressPointer r3
    //     0x1137ab4: add             x3, x3, HEAP, lsl #32
    // 0x1137ab8: mov             x2, x3
    // 0x1137abc: b               #0x1137bdc
    // 0x1137ac0: ldr             x2, [fp, #0x10]
    // 0x1137ac4: r17 = 5063
    //     0x1137ac4: mov             x17, #0x13c7
    // 0x1137ac8: cmp             x0, x17
    // 0x1137acc: b.ne            #0x1137b14
    // 0x1137ad0: r1 = 1
    //     0x1137ad0: mov             x1, #1
    // 0x1137ad4: r0 = AllocateContext()
    //     0x1137ad4: bl              #0x13de838  ; AllocateContextStub
    // 0x1137ad8: mov             x1, x0
    // 0x1137adc: ldr             x0, [fp, #0x10]
    // 0x1137ae0: StoreField: r1->field_f = r0
    //     0x1137ae0: stur            w0, [x1, #0xf]
    // 0x1137ae4: mov             x2, x1
    // 0x1137ae8: r1 = Function '<anonymous closure>':.
    //     0x1137ae8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26128] AnonymousClosure: (0xd447fc), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0x1137aec: ldr             x1, [x1, #0x128]
    // 0x1137af0: r0 = AllocateClosure()
    //     0x1137af0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1137af4: r16 = <Color>
    //     0x1137af4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1137af8: ldr             x16, [x16, #0xa90]
    // 0x1137afc: stp             x0, x16, [SP]
    // 0x1137b00: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1137b00: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1137b04: r0 = resolveWith()
    //     0x1137b04: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1137b08: mov             x2, x0
    // 0x1137b0c: ldur            x0, [fp, #-8]
    // 0x1137b10: b               #0x1137bdc
    // 0x1137b14: r17 = 5064
    //     0x1137b14: mov             x17, #0x13c8
    // 0x1137b18: cmp             x0, x17
    // 0x1137b1c: b.ne            #0x1137b98
    // 0x1137b20: ldr             x1, [fp, #0x10]
    // 0x1137b24: r1 = 2
    //     0x1137b24: mov             x1, #2
    // 0x1137b28: r0 = AllocateContext()
    //     0x1137b28: bl              #0x13de838  ; AllocateContextStub
    // 0x1137b2c: mov             x1, x0
    // 0x1137b30: ldr             x0, [fp, #0x10]
    // 0x1137b34: StoreField: r1->field_f = r0
    //     0x1137b34: stur            w0, [x1, #0xf]
    // 0x1137b38: LoadField: r2 = r0->field_2f
    //     0x1137b38: ldur            w2, [x0, #0x2f]
    // 0x1137b3c: DecompressPointer r2
    //     0x1137b3c: add             x2, x2, HEAP, lsl #32
    // 0x1137b40: LoadField: r3 = r2->field_3f
    //     0x1137b40: ldur            w3, [x2, #0x3f]
    // 0x1137b44: DecompressPointer r3
    //     0x1137b44: add             x3, x3, HEAP, lsl #32
    // 0x1137b48: LoadField: r2 = r3->field_7
    //     0x1137b48: ldur            w2, [x3, #7]
    // 0x1137b4c: DecompressPointer r2
    //     0x1137b4c: add             x2, x2, HEAP, lsl #32
    // 0x1137b50: r16 = Instance_Brightness
    //     0x1137b50: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x1137b54: cmp             w2, w16
    // 0x1137b58: r16 = true
    //     0x1137b58: add             x16, NULL, #0x20  ; true
    // 0x1137b5c: r17 = false
    //     0x1137b5c: add             x17, NULL, #0x30  ; false
    // 0x1137b60: csel            x3, x16, x17, eq
    // 0x1137b64: StoreField: r1->field_13 = r3
    //     0x1137b64: stur            w3, [x1, #0x13]
    // 0x1137b68: mov             x2, x1
    // 0x1137b6c: r1 = Function '<anonymous closure>':.
    //     0x1137b6c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26130] AnonymousClosure: (0xd446cc), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM2
    //     0x1137b70: ldr             x1, [x1, #0x130]
    // 0x1137b74: r0 = AllocateClosure()
    //     0x1137b74: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1137b78: r16 = <Color>
    //     0x1137b78: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1137b7c: ldr             x16, [x16, #0xa90]
    // 0x1137b80: stp             x0, x16, [SP]
    // 0x1137b84: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1137b84: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1137b88: r0 = resolveWith()
    //     0x1137b88: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1137b8c: mov             x2, x0
    // 0x1137b90: ldur            x0, [fp, #-8]
    // 0x1137b94: b               #0x1137bdc
    // 0x1137b98: ldr             x0, [fp, #0x10]
    // 0x1137b9c: r1 = 1
    //     0x1137b9c: mov             x1, #1
    // 0x1137ba0: r0 = AllocateContext()
    //     0x1137ba0: bl              #0x13de838  ; AllocateContextStub
    // 0x1137ba4: mov             x1, x0
    // 0x1137ba8: ldr             x0, [fp, #0x10]
    // 0x1137bac: StoreField: r1->field_f = r0
    //     0x1137bac: stur            w0, [x1, #0xf]
    // 0x1137bb0: mov             x2, x1
    // 0x1137bb4: r1 = Function '<anonymous closure>':.
    //     0x1137bb4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26138] AnonymousClosure: (0xd44618), of [package:flutter/src/material/switch.dart] _SwitchDefaultsCupertino
    //     0x1137bb8: ldr             x1, [x1, #0x138]
    // 0x1137bbc: r0 = AllocateClosure()
    //     0x1137bbc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1137bc0: r16 = <Color>
    //     0x1137bc0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1137bc4: ldr             x16, [x16, #0xa90]
    // 0x1137bc8: stp             x0, x16, [SP]
    // 0x1137bcc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1137bcc: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1137bd0: r0 = resolveWith()
    //     0x1137bd0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1137bd4: mov             x2, x0
    // 0x1137bd8: ldur            x0, [fp, #-8]
    // 0x1137bdc: stur            x2, [fp, #-0x18]
    // 0x1137be0: r17 = 5062
    //     0x1137be0: mov             x17, #0x13c6
    // 0x1137be4: cmp             x0, x17
    // 0x1137be8: b.ne            #0x1137bfc
    // 0x1137bec: ldr             x1, [fp, #0x10]
    // 0x1137bf0: LoadField: r3 = r1->field_f
    //     0x1137bf0: ldur            w3, [x1, #0xf]
    // 0x1137bf4: DecompressPointer r3
    //     0x1137bf4: add             x3, x3, HEAP, lsl #32
    // 0x1137bf8: b               #0x1137c70
    // 0x1137bfc: ldr             x1, [fp, #0x10]
    // 0x1137c00: r17 = 5063
    //     0x1137c00: mov             x17, #0x13c7
    // 0x1137c04: cmp             x0, x17
    // 0x1137c08: b.ne            #0x1137c50
    // 0x1137c0c: r1 = 1
    //     0x1137c0c: mov             x1, #1
    // 0x1137c10: r0 = AllocateContext()
    //     0x1137c10: bl              #0x13de838  ; AllocateContextStub
    // 0x1137c14: mov             x1, x0
    // 0x1137c18: ldr             x0, [fp, #0x10]
    // 0x1137c1c: StoreField: r1->field_f = r0
    //     0x1137c1c: stur            w0, [x1, #0xf]
    // 0x1137c20: mov             x2, x1
    // 0x1137c24: r1 = Function '<anonymous closure>':.
    //     0x1137c24: add             x1, PP, #0x26, lsl #12  ; [pp+0x26140] AnonymousClosure: (0xd444c0), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0x1137c28: ldr             x1, [x1, #0x140]
    // 0x1137c2c: r0 = AllocateClosure()
    //     0x1137c2c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1137c30: r16 = <Color?>
    //     0x1137c30: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1137c34: ldr             x16, [x16, #0xa40]
    // 0x1137c38: stp             x0, x16, [SP]
    // 0x1137c3c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1137c3c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1137c40: r0 = resolveWith()
    //     0x1137c40: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1137c44: mov             x3, x0
    // 0x1137c48: ldur            x0, [fp, #-8]
    // 0x1137c4c: b               #0x1137c70
    // 0x1137c50: r17 = 5064
    //     0x1137c50: mov             x17, #0x13c8
    // 0x1137c54: cmp             x0, x17
    // 0x1137c58: b.ne            #0x1137c68
    // 0x1137c5c: r3 = Instance_WidgetStatePropertyAll
    //     0x1137c5c: add             x3, PP, #0x26, lsl #12  ; [pp+0x26148] Obj!WidgetStatePropertyAll<Color>@128a071
    //     0x1137c60: ldr             x3, [x3, #0x148]
    // 0x1137c64: b               #0x1137c70
    // 0x1137c68: r3 = Instance_WidgetStatePropertyAll
    //     0x1137c68: add             x3, PP, #0x26, lsl #12  ; [pp+0x26148] Obj!WidgetStatePropertyAll<Color>@128a071
    //     0x1137c6c: ldr             x3, [x3, #0x148]
    // 0x1137c70: stur            x3, [fp, #-0x30]
    // 0x1137c74: r17 = -5064
    //     0x1137c74: mov             x17, #-0x13c8
    // 0x1137c78: add             x16, x0, x17
    // 0x1137c7c: cmp             x16, #1
    // 0x1137c80: b.ls            #0x1137c90
    // 0x1137c84: r17 = 5062
    //     0x1137c84: mov             x17, #0x13c6
    // 0x1137c88: cmp             x0, x17
    // 0x1137c8c: b.ne            #0x1137ca4
    // 0x1137c90: ldr             x4, [fp, #0x10]
    // 0x1137c94: LoadField: r1 = r4->field_13
    //     0x1137c94: ldur            w1, [x4, #0x13]
    // 0x1137c98: DecompressPointer r1
    //     0x1137c98: add             x1, x1, HEAP, lsl #32
    // 0x1137c9c: mov             x5, x1
    // 0x1137ca0: b               #0x1137cb0
    // 0x1137ca4: ldr             x4, [fp, #0x10]
    // 0x1137ca8: r5 = Instance_WidgetStatePropertyAll
    //     0x1137ca8: add             x5, PP, #0x26, lsl #12  ; [pp+0x26150] Obj!WidgetStatePropertyAll<double>@128a061
    //     0x1137cac: ldr             x5, [x5, #0x150]
    // 0x1137cb0: stur            x5, [fp, #-0x28]
    // 0x1137cb4: r17 = -5062
    //     0x1137cb4: mov             x17, #-0x13c6
    // 0x1137cb8: add             x16, x0, x17
    // 0x1137cbc: cmp             x16, #1
    // 0x1137cc0: b.ls            #0x1137ce8
    // 0x1137cc4: r17 = 5064
    //     0x1137cc4: mov             x17, #0x13c8
    // 0x1137cc8: cmp             x0, x17
    // 0x1137ccc: b.ne            #0x1137ce8
    // 0x1137cd0: LoadField: r1 = r4->field_2f
    //     0x1137cd0: ldur            w1, [x4, #0x2f]
    // 0x1137cd4: DecompressPointer r1
    //     0x1137cd4: add             x1, x1, HEAP, lsl #32
    // 0x1137cd8: LoadField: r2 = r1->field_1b
    //     0x1137cd8: ldur            w2, [x1, #0x1b]
    // 0x1137cdc: DecompressPointer r2
    //     0x1137cdc: add             x2, x2, HEAP, lsl #32
    // 0x1137ce0: mov             x6, x2
    // 0x1137ce4: b               #0x1137cf4
    // 0x1137ce8: ArrayLoad: r1 = r4[0]  ; List_4
    //     0x1137ce8: ldur            w1, [x4, #0x17]
    // 0x1137cec: DecompressPointer r1
    //     0x1137cec: add             x1, x1, HEAP, lsl #32
    // 0x1137cf0: mov             x6, x1
    // 0x1137cf4: stur            x6, [fp, #-0x20]
    // 0x1137cf8: r17 = 5062
    //     0x1137cf8: mov             x17, #0x13c6
    // 0x1137cfc: cmp             x0, x17
    // 0x1137d00: b.ne            #0x1137d10
    // 0x1137d04: LoadField: r1 = r4->field_1b
    //     0x1137d04: ldur            w1, [x4, #0x1b]
    // 0x1137d08: DecompressPointer r1
    //     0x1137d08: add             x1, x1, HEAP, lsl #32
    // 0x1137d0c: b               #0x1137dac
    // 0x1137d10: r17 = 5063
    //     0x1137d10: mov             x17, #0x13c7
    // 0x1137d14: cmp             x0, x17
    // 0x1137d18: b.ne            #0x1137d48
    // 0x1137d1c: r1 = Function '<anonymous closure>':.
    //     0x1137d1c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26158] AnonymousClosure: (0xd42a1c), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0x1137d20: ldr             x1, [x1, #0x158]
    // 0x1137d24: r2 = Null
    //     0x1137d24: mov             x2, NULL
    // 0x1137d28: r0 = AllocateClosure()
    //     0x1137d28: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1137d2c: r16 = <MouseCursor>
    //     0x1137d2c: ldr             x16, [PP, #0x21a8]  ; [pp+0x21a8] TypeArguments: <MouseCursor>
    // 0x1137d30: stp             x0, x16, [SP]
    // 0x1137d34: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1137d34: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1137d38: r0 = resolveWith()
    //     0x1137d38: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1137d3c: mov             x1, x0
    // 0x1137d40: ldur            x0, [fp, #-8]
    // 0x1137d44: b               #0x1137dac
    // 0x1137d48: r17 = 5064
    //     0x1137d48: mov             x17, #0x13c8
    // 0x1137d4c: cmp             x0, x17
    // 0x1137d50: b.ne            #0x1137d80
    // 0x1137d54: r1 = Function '<anonymous closure>':.
    //     0x1137d54: add             x1, PP, #0x26, lsl #12  ; [pp+0x26160] AnonymousClosure: (0xd42a1c), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0x1137d58: ldr             x1, [x1, #0x160]
    // 0x1137d5c: r2 = Null
    //     0x1137d5c: mov             x2, NULL
    // 0x1137d60: r0 = AllocateClosure()
    //     0x1137d60: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1137d64: r16 = <MouseCursor>
    //     0x1137d64: ldr             x16, [PP, #0x21a8]  ; [pp+0x21a8] TypeArguments: <MouseCursor>
    // 0x1137d68: stp             x0, x16, [SP]
    // 0x1137d6c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1137d6c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1137d70: r0 = resolveWith()
    //     0x1137d70: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1137d74: mov             x1, x0
    // 0x1137d78: ldur            x0, [fp, #-8]
    // 0x1137d7c: b               #0x1137dac
    // 0x1137d80: r1 = Function '<anonymous closure>':.
    //     0x1137d80: add             x1, PP, #0x26, lsl #12  ; [pp+0x26168] AnonymousClosure: (0xd429b4), of [package:flutter/src/material/switch.dart] _SwitchDefaultsCupertino
    //     0x1137d84: ldr             x1, [x1, #0x168]
    // 0x1137d88: r2 = Null
    //     0x1137d88: mov             x2, NULL
    // 0x1137d8c: r0 = AllocateClosure()
    //     0x1137d8c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1137d90: r16 = <MouseCursor?>
    //     0x1137d90: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ab8] TypeArguments: <MouseCursor?>
    //     0x1137d94: ldr             x16, [x16, #0xab8]
    // 0x1137d98: stp             x0, x16, [SP]
    // 0x1137d9c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1137d9c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1137da0: r0 = resolveWith()
    //     0x1137da0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1137da4: mov             x1, x0
    // 0x1137da8: ldur            x0, [fp, #-8]
    // 0x1137dac: stur            x1, [fp, #-0x38]
    // 0x1137db0: r17 = 5062
    //     0x1137db0: mov             x17, #0x13c6
    // 0x1137db4: cmp             x0, x17
    // 0x1137db8: b.ne            #0x1137dd0
    // 0x1137dbc: ldr             x2, [fp, #0x10]
    // 0x1137dc0: LoadField: r3 = r2->field_1f
    //     0x1137dc0: ldur            w3, [x2, #0x1f]
    // 0x1137dc4: DecompressPointer r3
    //     0x1137dc4: add             x3, x3, HEAP, lsl #32
    // 0x1137dc8: mov             x1, x3
    // 0x1137dcc: b               #0x1137ebc
    // 0x1137dd0: ldr             x2, [fp, #0x10]
    // 0x1137dd4: r17 = 5063
    //     0x1137dd4: mov             x17, #0x13c7
    // 0x1137dd8: cmp             x0, x17
    // 0x1137ddc: b.ne            #0x1137e24
    // 0x1137de0: r1 = 1
    //     0x1137de0: mov             x1, #1
    // 0x1137de4: r0 = AllocateContext()
    //     0x1137de4: bl              #0x13de838  ; AllocateContextStub
    // 0x1137de8: mov             x1, x0
    // 0x1137dec: ldr             x0, [fp, #0x10]
    // 0x1137df0: StoreField: r1->field_f = r0
    //     0x1137df0: stur            w0, [x1, #0xf]
    // 0x1137df4: mov             x2, x1
    // 0x1137df8: r1 = Function '<anonymous closure>':.
    //     0x1137df8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26170] AnonymousClosure: (0xd440d4), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0x1137dfc: ldr             x1, [x1, #0x170]
    // 0x1137e00: r0 = AllocateClosure()
    //     0x1137e00: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1137e04: r16 = <Color?>
    //     0x1137e04: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1137e08: ldr             x16, [x16, #0xa40]
    // 0x1137e0c: stp             x0, x16, [SP]
    // 0x1137e10: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1137e10: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1137e14: r0 = resolveWith()
    //     0x1137e14: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1137e18: mov             x1, x0
    // 0x1137e1c: ldur            x0, [fp, #-8]
    // 0x1137e20: b               #0x1137ebc
    // 0x1137e24: r17 = 5064
    //     0x1137e24: mov             x17, #0x13c8
    // 0x1137e28: cmp             x0, x17
    // 0x1137e2c: b.ne            #0x1137e78
    // 0x1137e30: ldr             x1, [fp, #0x10]
    // 0x1137e34: r1 = 1
    //     0x1137e34: mov             x1, #1
    // 0x1137e38: r0 = AllocateContext()
    //     0x1137e38: bl              #0x13de838  ; AllocateContextStub
    // 0x1137e3c: mov             x1, x0
    // 0x1137e40: ldr             x0, [fp, #0x10]
    // 0x1137e44: StoreField: r1->field_f = r0
    //     0x1137e44: stur            w0, [x1, #0xf]
    // 0x1137e48: mov             x2, x1
    // 0x1137e4c: r1 = Function '<anonymous closure>':.
    //     0x1137e4c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26178] AnonymousClosure: (0xd43f64), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM2
    //     0x1137e50: ldr             x1, [x1, #0x178]
    // 0x1137e54: r0 = AllocateClosure()
    //     0x1137e54: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1137e58: r16 = <Color?>
    //     0x1137e58: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1137e5c: ldr             x16, [x16, #0xa40]
    // 0x1137e60: stp             x0, x16, [SP]
    // 0x1137e64: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1137e64: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1137e68: r0 = resolveWith()
    //     0x1137e68: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1137e6c: mov             x1, x0
    // 0x1137e70: ldur            x0, [fp, #-8]
    // 0x1137e74: b               #0x1137ebc
    // 0x1137e78: ldr             x0, [fp, #0x10]
    // 0x1137e7c: r1 = 1
    //     0x1137e7c: mov             x1, #1
    // 0x1137e80: r0 = AllocateContext()
    //     0x1137e80: bl              #0x13de838  ; AllocateContextStub
    // 0x1137e84: mov             x1, x0
    // 0x1137e88: ldr             x0, [fp, #0x10]
    // 0x1137e8c: StoreField: r1->field_f = r0
    //     0x1137e8c: stur            w0, [x1, #0xf]
    // 0x1137e90: mov             x2, x1
    // 0x1137e94: r1 = Function '<anonymous closure>':.
    //     0x1137e94: add             x1, PP, #0x26, lsl #12  ; [pp+0x26180] AnonymousClosure: (0xd431a0), of [package:flutter/src/material/switch.dart] _SwitchDefaultsCupertino
    //     0x1137e98: ldr             x1, [x1, #0x180]
    // 0x1137e9c: r0 = AllocateClosure()
    //     0x1137e9c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1137ea0: r16 = <Color?>
    //     0x1137ea0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1137ea4: ldr             x16, [x16, #0xa40]
    // 0x1137ea8: stp             x0, x16, [SP]
    // 0x1137eac: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1137eac: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1137eb0: r0 = resolveWith()
    //     0x1137eb0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1137eb4: mov             x1, x0
    // 0x1137eb8: ldur            x0, [fp, #-8]
    // 0x1137ebc: r17 = 5062
    //     0x1137ebc: mov             x17, #0x13c6
    // 0x1137ec0: cmp             x0, x17
    // 0x1137ec4: b.ne            #0x1137ed8
    // 0x1137ec8: ldr             x2, [fp, #0x10]
    // 0x1137ecc: LoadField: r3 = r2->field_23
    //     0x1137ecc: ldur            w3, [x2, #0x23]
    // 0x1137ed0: DecompressPointer r3
    //     0x1137ed0: add             x3, x3, HEAP, lsl #32
    // 0x1137ed4: b               #0x1137f10
    // 0x1137ed8: ldr             x2, [fp, #0x10]
    // 0x1137edc: r17 = 5063
    //     0x1137edc: mov             x17, #0x13c7
    // 0x1137ee0: cmp             x0, x17
    // 0x1137ee4: b.ne            #0x1137ef4
    // 0x1137ee8: r3 = 20.000000
    //     0x1137ee8: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1ae98] 20
    //     0x1137eec: ldr             x3, [x3, #0xe98]
    // 0x1137ef0: b               #0x1137f10
    // 0x1137ef4: r17 = 5064
    //     0x1137ef4: mov             x17, #0x13c8
    // 0x1137ef8: cmp             x0, x17
    // 0x1137efc: b.ne            #0x1137f0c
    // 0x1137f00: r3 = 20.000000
    //     0x1137f00: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1ae98] 20
    //     0x1137f04: ldr             x3, [x3, #0xe98]
    // 0x1137f08: b               #0x1137f10
    // 0x1137f0c: r3 = 0.000000
    //     0x1137f0c: ldr             x3, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x1137f10: r17 = 5062
    //     0x1137f10: mov             x17, #0x13c6
    // 0x1137f14: cmp             x0, x17
    // 0x1137f18: b.eq            #0x1137f48
    // 0x1137f1c: r17 = 5063
    //     0x1137f1c: mov             x17, #0x13c7
    // 0x1137f20: cmp             x0, x17
    // 0x1137f24: b.ne            #0x1137f34
    // 0x1137f28: r0 = Instance_EdgeInsets
    //     0x1137f28: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c430] Obj!EdgeInsets@129dc51
    //     0x1137f2c: ldr             x0, [x0, #0x430]
    // 0x1137f30: b               #0x1137f50
    // 0x1137f34: r17 = 5064
    //     0x1137f34: mov             x17, #0x13c8
    // 0x1137f38: cmp             x0, x17
    // 0x1137f3c: b.ne            #0x1137f48
    // 0x1137f40: r0 = Instance_EdgeInsets
    //     0x1137f40: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0x1137f44: b               #0x1137f50
    // 0x1137f48: LoadField: r0 = r2->field_2b
    //     0x1137f48: ldur            w0, [x2, #0x2b]
    // 0x1137f4c: DecompressPointer r0
    //     0x1137f4c: add             x0, x0, HEAP, lsl #32
    // 0x1137f50: ldur            x16, [fp, #-0x30]
    // 0x1137f54: ldur            lr, [fp, #-0x28]
    // 0x1137f58: stp             lr, x16, [SP, #0x30]
    // 0x1137f5c: ldur            x16, [fp, #-0x20]
    // 0x1137f60: ldur            lr, [fp, #-0x38]
    // 0x1137f64: stp             lr, x16, [SP, #0x20]
    // 0x1137f68: stp             x3, x1, [SP, #0x10]
    // 0x1137f6c: stp             x0, NULL, [SP]
    // 0x1137f70: ldur            x1, [fp, #-0x10]
    // 0x1137f74: ldur            x2, [fp, #-0x18]
    // 0x1137f78: r4 = const [0, 0xa, 0x8, 0xa, null]
    //     0x1137f78: add             x4, PP, #0x26, lsl #12  ; [pp+0x261f8] List(5) [0, 0xa, 0x8, 0xa, Null]
    //     0x1137f7c: ldr             x4, [x4, #0x1f8]
    // 0x1137f80: r0 = hash()
    //     0x1137f80: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1137f84: mov             x2, x0
    // 0x1137f88: r0 = BoxInt64Instr(r2)
    //     0x1137f88: sbfiz           x0, x2, #1, #0x1f
    //     0x1137f8c: cmp             x2, x0, asr #1
    //     0x1137f90: b.eq            #0x1137f9c
    //     0x1137f94: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1137f98: stur            x2, [x0, #7]
    // 0x1137f9c: LeaveFrame
    //     0x1137f9c: mov             SP, fp
    //     0x1137fa0: ldp             fp, lr, [SP], #0x10
    // 0x1137fa4: ret
    //     0x1137fa4: ret             
    // 0x1137fa8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1137fa8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1137fac: b               #0x1137988
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1165534, size: 0xcc
    // 0x1165534: EnterFrame
    //     0x1165534: stp             fp, lr, [SP, #-0x10]!
    //     0x1165538: mov             fp, SP
    // 0x116553c: AllocStack(0x8)
    //     0x116553c: sub             SP, SP, #8
    // 0x1165540: SetupParameters(dynamic _ /* r1 => r0 */)
    //     0x1165540: mov             x0, x1
    // 0x1165544: CheckStackOverflow
    //     0x1165544: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1165548: cmp             SP, x16
    //     0x116554c: b.ls            #0x11655dc
    // 0x1165550: cmp             w0, w2
    // 0x1165554: b.ne            #0x1165564
    // 0x1165558: LeaveFrame
    //     0x1165558: mov             SP, fp
    //     0x116555c: ldp             fp, lr, [SP], #0x10
    // 0x1165560: ret
    //     0x1165560: ret             
    // 0x1165564: LoadField: r1 = r0->field_23
    //     0x1165564: ldur            w1, [x0, #0x23]
    // 0x1165568: DecompressPointer r1
    //     0x1165568: add             x1, x1, HEAP, lsl #32
    // 0x116556c: LoadField: r0 = r2->field_23
    //     0x116556c: ldur            w0, [x2, #0x23]
    // 0x1165570: DecompressPointer r0
    //     0x1165570: add             x0, x0, HEAP, lsl #32
    // 0x1165574: r4 = inline_Allocate_Double()
    //     0x1165574: ldp             x4, x2, [THR, #0x60]  ; THR::top
    //     0x1165578: add             x4, x4, #0x10
    //     0x116557c: cmp             x2, x4
    //     0x1165580: b.ls            #0x11655e4
    //     0x1165584: str             x4, [THR, #0x60]  ; THR::top
    //     0x1165588: sub             x4, x4, #0xf
    //     0x116558c: mov             x2, #0xe19c
    //     0x1165590: movk            x2, #3, lsl #16
    //     0x1165594: stur            x2, [x4, #-1]
    // 0x1165598: dmb             ishst
    // 0x116559c: StoreField: r4->field_7 = d0
    //     0x116559c: stur            d0, [x4, #7]
    // 0x11655a0: mov             x2, x0
    // 0x11655a4: mov             x3, x4
    // 0x11655a8: stur            x4, [fp, #-8]
    // 0x11655ac: r0 = lerpDouble()
    //     0x11655ac: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x11655b0: ldur            x3, [fp, #-8]
    // 0x11655b4: r1 = Null
    //     0x11655b4: mov             x1, NULL
    // 0x11655b8: r2 = Null
    //     0x11655b8: mov             x2, NULL
    // 0x11655bc: stur            x0, [fp, #-8]
    // 0x11655c0: r0 = lerp()
    //     0x11655c0: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x11655c4: r0 = SwitchThemeData()
    //     0x11655c4: bl              #0x1165600  ; AllocateSwitchThemeDataStub -> SwitchThemeData (size=0x30)
    // 0x11655c8: ldur            x1, [fp, #-8]
    // 0x11655cc: StoreField: r0->field_23 = r1
    //     0x11655cc: stur            w1, [x0, #0x23]
    // 0x11655d0: LeaveFrame
    //     0x11655d0: mov             SP, fp
    //     0x11655d4: ldp             fp, lr, [SP], #0x10
    // 0x11655d8: ret
    //     0x11655d8: ret             
    // 0x11655dc: r0 = StackOverflowSharedWithFPURegs()
    //     0x11655dc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11655e0: b               #0x1165550
    // 0x11655e4: SaveReg d0
    //     0x11655e4: str             q0, [SP, #-0x10]!
    // 0x11655e8: stp             x0, x1, [SP, #-0x10]!
    // 0x11655ec: r0 = AllocateDouble()
    //     0x11655ec: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11655f0: mov             x4, x0
    // 0x11655f4: ldp             x0, x1, [SP], #0x10
    // 0x11655f8: RestoreReg d0
    //     0x11655f8: ldr             q0, [SP], #0x10
    // 0x11655fc: b               #0x116559c
  }
  _ ==(/* No info */) {
    // ** addr: 0x1275104, size: 0xd2c
    // 0x1275104: EnterFrame
    //     0x1275104: stp             fp, lr, [SP, #-0x10]!
    //     0x1275108: mov             fp, SP
    // 0x127510c: AllocStack(0x28)
    //     0x127510c: sub             SP, SP, #0x28
    // 0x1275110: CheckStackOverflow
    //     0x1275110: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1275114: cmp             SP, x16
    //     0x1275118: b.ls            #0x1275e28
    // 0x127511c: ldr             x0, [fp, #0x10]
    // 0x1275120: cmp             w0, NULL
    // 0x1275124: b.ne            #0x1275138
    // 0x1275128: r0 = false
    //     0x1275128: add             x0, NULL, #0x30  ; false
    // 0x127512c: LeaveFrame
    //     0x127512c: mov             SP, fp
    //     0x1275130: ldp             fp, lr, [SP], #0x10
    // 0x1275134: ret
    //     0x1275134: ret             
    // 0x1275138: ldr             x1, [fp, #0x18]
    // 0x127513c: cmp             w1, w0
    // 0x1275140: b.ne            #0x1275154
    // 0x1275144: r0 = true
    //     0x1275144: add             x0, NULL, #0x20  ; true
    // 0x1275148: LeaveFrame
    //     0x1275148: mov             SP, fp
    //     0x127514c: ldp             fp, lr, [SP], #0x10
    // 0x1275150: ret
    //     0x1275150: ret             
    // 0x1275154: stp             x1, x0, [SP]
    // 0x1275158: r0 = _haveSameRuntimeType()
    //     0x1275158: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x127515c: tbz             w0, #4, #0x1275170
    // 0x1275160: r0 = false
    //     0x1275160: add             x0, NULL, #0x30  ; false
    // 0x1275164: LeaveFrame
    //     0x1275164: mov             SP, fp
    //     0x1275168: ldp             fp, lr, [SP], #0x10
    // 0x127516c: ret
    //     0x127516c: ret             
    // 0x1275170: ldr             x0, [fp, #0x10]
    // 0x1275174: r1 = 60
    //     0x1275174: mov             x1, #0x3c
    // 0x1275178: branchIfSmi(r0, 0x1275184)
    //     0x1275178: tbz             w0, #0, #0x1275184
    // 0x127517c: r1 = LoadClassIdInstr(r0)
    //     0x127517c: ldur            x1, [x0, #-1]
    //     0x1275180: ubfx            x1, x1, #0xc, #0x14
    // 0x1275184: stur            x1, [fp, #-8]
    // 0x1275188: r17 = -5062
    //     0x1275188: mov             x17, #-0x13c6
    // 0x127518c: add             x16, x1, x17
    // 0x1275190: cmp             x16, #3
    // 0x1275194: b.hi            #0x1275e18
    // 0x1275198: r17 = 5062
    //     0x1275198: mov             x17, #0x13c6
    // 0x127519c: cmp             x1, x17
    // 0x12751a0: b.ne            #0x12751b4
    // 0x12751a4: LoadField: r2 = r0->field_7
    //     0x12751a4: ldur            w2, [x0, #7]
    // 0x12751a8: DecompressPointer r2
    //     0x12751a8: add             x2, x2, HEAP, lsl #32
    // 0x12751ac: mov             x1, x2
    // 0x12751b0: b               #0x127528c
    // 0x12751b4: r17 = 5063
    //     0x12751b4: mov             x17, #0x13c7
    // 0x12751b8: cmp             x1, x17
    // 0x12751bc: b.ne            #0x1275200
    // 0x12751c0: r1 = 1
    //     0x12751c0: mov             x1, #1
    // 0x12751c4: r0 = AllocateContext()
    //     0x12751c4: bl              #0x13de838  ; AllocateContextStub
    // 0x12751c8: mov             x1, x0
    // 0x12751cc: ldr             x0, [fp, #0x10]
    // 0x12751d0: StoreField: r1->field_f = r0
    //     0x12751d0: stur            w0, [x1, #0xf]
    // 0x12751d4: mov             x2, x1
    // 0x12751d8: r1 = Function '<anonymous closure>':.
    //     0x12751d8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26110] AnonymousClosure: (0xd44f24), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0x12751dc: ldr             x1, [x1, #0x110]
    // 0x12751e0: r0 = AllocateClosure()
    //     0x12751e0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12751e4: r16 = <Color>
    //     0x12751e4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x12751e8: ldr             x16, [x16, #0xa90]
    // 0x12751ec: stp             x0, x16, [SP]
    // 0x12751f0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12751f0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12751f4: r0 = resolveWith()
    //     0x12751f4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x12751f8: mov             x1, x0
    // 0x12751fc: b               #0x127528c
    // 0x1275200: mov             x0, x1
    // 0x1275204: r17 = 5064
    //     0x1275204: mov             x17, #0x13c8
    // 0x1275208: cmp             x0, x17
    // 0x127520c: b.ne            #0x1275284
    // 0x1275210: ldr             x1, [fp, #0x10]
    // 0x1275214: r1 = 2
    //     0x1275214: mov             x1, #2
    // 0x1275218: r0 = AllocateContext()
    //     0x1275218: bl              #0x13de838  ; AllocateContextStub
    // 0x127521c: mov             x1, x0
    // 0x1275220: ldr             x0, [fp, #0x10]
    // 0x1275224: StoreField: r1->field_f = r0
    //     0x1275224: stur            w0, [x1, #0xf]
    // 0x1275228: LoadField: r2 = r0->field_2f
    //     0x1275228: ldur            w2, [x0, #0x2f]
    // 0x127522c: DecompressPointer r2
    //     0x127522c: add             x2, x2, HEAP, lsl #32
    // 0x1275230: LoadField: r3 = r2->field_3f
    //     0x1275230: ldur            w3, [x2, #0x3f]
    // 0x1275234: DecompressPointer r3
    //     0x1275234: add             x3, x3, HEAP, lsl #32
    // 0x1275238: LoadField: r2 = r3->field_7
    //     0x1275238: ldur            w2, [x3, #7]
    // 0x127523c: DecompressPointer r2
    //     0x127523c: add             x2, x2, HEAP, lsl #32
    // 0x1275240: r16 = Instance_Brightness
    //     0x1275240: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x1275244: cmp             w2, w16
    // 0x1275248: r16 = true
    //     0x1275248: add             x16, NULL, #0x20  ; true
    // 0x127524c: r17 = false
    //     0x127524c: add             x17, NULL, #0x30  ; false
    // 0x1275250: csel            x3, x16, x17, eq
    // 0x1275254: StoreField: r1->field_13 = r3
    //     0x1275254: stur            w3, [x1, #0x13]
    // 0x1275258: mov             x2, x1
    // 0x127525c: r1 = Function '<anonymous closure>':.
    //     0x127525c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26118] AnonymousClosure: (0xd44d38), in [package:flutter/src/material/switch.dart] _SwitchDefaultsM2::thumbColor (0x129d570)
    //     0x1275260: ldr             x1, [x1, #0x118]
    // 0x1275264: r0 = AllocateClosure()
    //     0x1275264: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1275268: r16 = <Color>
    //     0x1275268: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x127526c: ldr             x16, [x16, #0xa90]
    // 0x1275270: stp             x0, x16, [SP]
    // 0x1275274: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1275274: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1275278: r0 = resolveWith()
    //     0x1275278: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x127527c: mov             x1, x0
    // 0x1275280: b               #0x127528c
    // 0x1275284: r1 = Instance_WidgetStatePropertyAll
    //     0x1275284: add             x1, PP, #0x26, lsl #12  ; [pp+0x26120] Obj!WidgetStatePropertyAll<Color>@128a081
    //     0x1275288: ldr             x1, [x1, #0x120]
    // 0x127528c: ldr             x0, [fp, #0x18]
    // 0x1275290: stur            x1, [fp, #-0x18]
    // 0x1275294: r2 = LoadClassIdInstr(r0)
    //     0x1275294: ldur            x2, [x0, #-1]
    //     0x1275298: ubfx            x2, x2, #0xc, #0x14
    // 0x127529c: stur            x2, [fp, #-0x10]
    // 0x12752a0: r17 = 5062
    //     0x12752a0: mov             x17, #0x13c6
    // 0x12752a4: cmp             x2, x17
    // 0x12752a8: b.ne            #0x12752c0
    // 0x12752ac: LoadField: r3 = r0->field_7
    //     0x12752ac: ldur            w3, [x0, #7]
    // 0x12752b0: DecompressPointer r3
    //     0x12752b0: add             x3, x3, HEAP, lsl #32
    // 0x12752b4: mov             x0, x1
    // 0x12752b8: mov             x1, x3
    // 0x12752bc: b               #0x12753a4
    // 0x12752c0: r17 = 5063
    //     0x12752c0: mov             x17, #0x13c7
    // 0x12752c4: cmp             x2, x17
    // 0x12752c8: b.ne            #0x1275310
    // 0x12752cc: r1 = 1
    //     0x12752cc: mov             x1, #1
    // 0x12752d0: r0 = AllocateContext()
    //     0x12752d0: bl              #0x13de838  ; AllocateContextStub
    // 0x12752d4: mov             x1, x0
    // 0x12752d8: ldr             x0, [fp, #0x18]
    // 0x12752dc: StoreField: r1->field_f = r0
    //     0x12752dc: stur            w0, [x1, #0xf]
    // 0x12752e0: mov             x2, x1
    // 0x12752e4: r1 = Function '<anonymous closure>':.
    //     0x12752e4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26110] AnonymousClosure: (0xd44f24), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0x12752e8: ldr             x1, [x1, #0x110]
    // 0x12752ec: r0 = AllocateClosure()
    //     0x12752ec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12752f0: r16 = <Color>
    //     0x12752f0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x12752f4: ldr             x16, [x16, #0xa90]
    // 0x12752f8: stp             x0, x16, [SP]
    // 0x12752fc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12752fc: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1275300: r0 = resolveWith()
    //     0x1275300: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1275304: mov             x1, x0
    // 0x1275308: ldur            x0, [fp, #-0x18]
    // 0x127530c: b               #0x12753a4
    // 0x1275310: mov             x0, x2
    // 0x1275314: r17 = 5064
    //     0x1275314: mov             x17, #0x13c8
    // 0x1275318: cmp             x0, x17
    // 0x127531c: b.ne            #0x1275398
    // 0x1275320: ldr             x1, [fp, #0x18]
    // 0x1275324: r1 = 2
    //     0x1275324: mov             x1, #2
    // 0x1275328: r0 = AllocateContext()
    //     0x1275328: bl              #0x13de838  ; AllocateContextStub
    // 0x127532c: mov             x1, x0
    // 0x1275330: ldr             x0, [fp, #0x18]
    // 0x1275334: StoreField: r1->field_f = r0
    //     0x1275334: stur            w0, [x1, #0xf]
    // 0x1275338: LoadField: r2 = r0->field_2f
    //     0x1275338: ldur            w2, [x0, #0x2f]
    // 0x127533c: DecompressPointer r2
    //     0x127533c: add             x2, x2, HEAP, lsl #32
    // 0x1275340: LoadField: r3 = r2->field_3f
    //     0x1275340: ldur            w3, [x2, #0x3f]
    // 0x1275344: DecompressPointer r3
    //     0x1275344: add             x3, x3, HEAP, lsl #32
    // 0x1275348: LoadField: r2 = r3->field_7
    //     0x1275348: ldur            w2, [x3, #7]
    // 0x127534c: DecompressPointer r2
    //     0x127534c: add             x2, x2, HEAP, lsl #32
    // 0x1275350: r16 = Instance_Brightness
    //     0x1275350: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x1275354: cmp             w2, w16
    // 0x1275358: r16 = true
    //     0x1275358: add             x16, NULL, #0x20  ; true
    // 0x127535c: r17 = false
    //     0x127535c: add             x17, NULL, #0x30  ; false
    // 0x1275360: csel            x3, x16, x17, eq
    // 0x1275364: StoreField: r1->field_13 = r3
    //     0x1275364: stur            w3, [x1, #0x13]
    // 0x1275368: mov             x2, x1
    // 0x127536c: r1 = Function '<anonymous closure>':.
    //     0x127536c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26118] AnonymousClosure: (0xd44d38), in [package:flutter/src/material/switch.dart] _SwitchDefaultsM2::thumbColor (0x129d570)
    //     0x1275370: ldr             x1, [x1, #0x118]
    // 0x1275374: r0 = AllocateClosure()
    //     0x1275374: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1275378: r16 = <Color>
    //     0x1275378: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x127537c: ldr             x16, [x16, #0xa90]
    // 0x1275380: stp             x0, x16, [SP]
    // 0x1275384: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1275384: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1275388: r0 = resolveWith()
    //     0x1275388: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x127538c: mov             x1, x0
    // 0x1275390: ldur            x0, [fp, #-0x18]
    // 0x1275394: b               #0x12753a4
    // 0x1275398: ldur            x0, [fp, #-0x18]
    // 0x127539c: r1 = Instance_WidgetStatePropertyAll
    //     0x127539c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26120] Obj!WidgetStatePropertyAll<Color>@128a081
    //     0x12753a0: ldr             x1, [x1, #0x120]
    // 0x12753a4: r2 = LoadClassIdInstr(r0)
    //     0x12753a4: ldur            x2, [x0, #-1]
    //     0x12753a8: ubfx            x2, x2, #0xc, #0x14
    // 0x12753ac: stp             x1, x0, [SP]
    // 0x12753b0: mov             x0, x2
    // 0x12753b4: mov             lr, x0
    // 0x12753b8: ldr             lr, [x21, lr, lsl #3]
    // 0x12753bc: blr             lr
    // 0x12753c0: tbnz            w0, #4, #0x1275e18
    // 0x12753c4: ldur            x0, [fp, #-8]
    // 0x12753c8: r17 = 5062
    //     0x12753c8: mov             x17, #0x13c6
    // 0x12753cc: cmp             x0, x17
    // 0x12753d0: b.ne            #0x12753e8
    // 0x12753d4: ldr             x1, [fp, #0x10]
    // 0x12753d8: LoadField: r2 = r1->field_b
    //     0x12753d8: ldur            w2, [x1, #0xb]
    // 0x12753dc: DecompressPointer r2
    //     0x12753dc: add             x2, x2, HEAP, lsl #32
    // 0x12753e0: mov             x1, x2
    // 0x12753e4: b               #0x12754f8
    // 0x12753e8: ldr             x1, [fp, #0x10]
    // 0x12753ec: r17 = 5063
    //     0x12753ec: mov             x17, #0x13c7
    // 0x12753f0: cmp             x0, x17
    // 0x12753f4: b.ne            #0x1275438
    // 0x12753f8: r1 = 1
    //     0x12753f8: mov             x1, #1
    // 0x12753fc: r0 = AllocateContext()
    //     0x12753fc: bl              #0x13de838  ; AllocateContextStub
    // 0x1275400: mov             x1, x0
    // 0x1275404: ldr             x0, [fp, #0x10]
    // 0x1275408: StoreField: r1->field_f = r0
    //     0x1275408: stur            w0, [x1, #0xf]
    // 0x127540c: mov             x2, x1
    // 0x1275410: r1 = Function '<anonymous closure>':.
    //     0x1275410: add             x1, PP, #0x26, lsl #12  ; [pp+0x26128] AnonymousClosure: (0xd447fc), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0x1275414: ldr             x1, [x1, #0x128]
    // 0x1275418: r0 = AllocateClosure()
    //     0x1275418: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x127541c: r16 = <Color>
    //     0x127541c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1275420: ldr             x16, [x16, #0xa90]
    // 0x1275424: stp             x0, x16, [SP]
    // 0x1275428: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1275428: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x127542c: r0 = resolveWith()
    //     0x127542c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1275430: mov             x1, x0
    // 0x1275434: b               #0x12754f8
    // 0x1275438: r17 = 5064
    //     0x1275438: mov             x17, #0x13c8
    // 0x127543c: cmp             x0, x17
    // 0x1275440: b.ne            #0x12754b8
    // 0x1275444: ldr             x1, [fp, #0x10]
    // 0x1275448: r1 = 2
    //     0x1275448: mov             x1, #2
    // 0x127544c: r0 = AllocateContext()
    //     0x127544c: bl              #0x13de838  ; AllocateContextStub
    // 0x1275450: mov             x1, x0
    // 0x1275454: ldr             x0, [fp, #0x10]
    // 0x1275458: StoreField: r1->field_f = r0
    //     0x1275458: stur            w0, [x1, #0xf]
    // 0x127545c: LoadField: r2 = r0->field_2f
    //     0x127545c: ldur            w2, [x0, #0x2f]
    // 0x1275460: DecompressPointer r2
    //     0x1275460: add             x2, x2, HEAP, lsl #32
    // 0x1275464: LoadField: r3 = r2->field_3f
    //     0x1275464: ldur            w3, [x2, #0x3f]
    // 0x1275468: DecompressPointer r3
    //     0x1275468: add             x3, x3, HEAP, lsl #32
    // 0x127546c: LoadField: r2 = r3->field_7
    //     0x127546c: ldur            w2, [x3, #7]
    // 0x1275470: DecompressPointer r2
    //     0x1275470: add             x2, x2, HEAP, lsl #32
    // 0x1275474: r16 = Instance_Brightness
    //     0x1275474: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x1275478: cmp             w2, w16
    // 0x127547c: r16 = true
    //     0x127547c: add             x16, NULL, #0x20  ; true
    // 0x1275480: r17 = false
    //     0x1275480: add             x17, NULL, #0x30  ; false
    // 0x1275484: csel            x3, x16, x17, eq
    // 0x1275488: StoreField: r1->field_13 = r3
    //     0x1275488: stur            w3, [x1, #0x13]
    // 0x127548c: mov             x2, x1
    // 0x1275490: r1 = Function '<anonymous closure>':.
    //     0x1275490: add             x1, PP, #0x26, lsl #12  ; [pp+0x26130] AnonymousClosure: (0xd446cc), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM2
    //     0x1275494: ldr             x1, [x1, #0x130]
    // 0x1275498: r0 = AllocateClosure()
    //     0x1275498: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x127549c: r16 = <Color>
    //     0x127549c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x12754a0: ldr             x16, [x16, #0xa90]
    // 0x12754a4: stp             x0, x16, [SP]
    // 0x12754a8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12754a8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12754ac: r0 = resolveWith()
    //     0x12754ac: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x12754b0: mov             x1, x0
    // 0x12754b4: b               #0x12754f8
    // 0x12754b8: ldr             x0, [fp, #0x10]
    // 0x12754bc: r1 = 1
    //     0x12754bc: mov             x1, #1
    // 0x12754c0: r0 = AllocateContext()
    //     0x12754c0: bl              #0x13de838  ; AllocateContextStub
    // 0x12754c4: mov             x1, x0
    // 0x12754c8: ldr             x0, [fp, #0x10]
    // 0x12754cc: StoreField: r1->field_f = r0
    //     0x12754cc: stur            w0, [x1, #0xf]
    // 0x12754d0: mov             x2, x1
    // 0x12754d4: r1 = Function '<anonymous closure>':.
    //     0x12754d4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26138] AnonymousClosure: (0xd44618), of [package:flutter/src/material/switch.dart] _SwitchDefaultsCupertino
    //     0x12754d8: ldr             x1, [x1, #0x138]
    // 0x12754dc: r0 = AllocateClosure()
    //     0x12754dc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12754e0: r16 = <Color>
    //     0x12754e0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x12754e4: ldr             x16, [x16, #0xa90]
    // 0x12754e8: stp             x0, x16, [SP]
    // 0x12754ec: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12754ec: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12754f0: r0 = resolveWith()
    //     0x12754f0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x12754f4: mov             x1, x0
    // 0x12754f8: ldur            x0, [fp, #-0x10]
    // 0x12754fc: stur            x1, [fp, #-0x18]
    // 0x1275500: r17 = 5062
    //     0x1275500: mov             x17, #0x13c6
    // 0x1275504: cmp             x0, x17
    // 0x1275508: b.ne            #0x1275524
    // 0x127550c: ldr             x2, [fp, #0x18]
    // 0x1275510: LoadField: r3 = r2->field_b
    //     0x1275510: ldur            w3, [x2, #0xb]
    // 0x1275514: DecompressPointer r3
    //     0x1275514: add             x3, x3, HEAP, lsl #32
    // 0x1275518: mov             x0, x1
    // 0x127551c: mov             x1, x3
    // 0x1275520: b               #0x1275640
    // 0x1275524: ldr             x2, [fp, #0x18]
    // 0x1275528: r17 = 5063
    //     0x1275528: mov             x17, #0x13c7
    // 0x127552c: cmp             x0, x17
    // 0x1275530: b.ne            #0x1275578
    // 0x1275534: r1 = 1
    //     0x1275534: mov             x1, #1
    // 0x1275538: r0 = AllocateContext()
    //     0x1275538: bl              #0x13de838  ; AllocateContextStub
    // 0x127553c: mov             x1, x0
    // 0x1275540: ldr             x0, [fp, #0x18]
    // 0x1275544: StoreField: r1->field_f = r0
    //     0x1275544: stur            w0, [x1, #0xf]
    // 0x1275548: mov             x2, x1
    // 0x127554c: r1 = Function '<anonymous closure>':.
    //     0x127554c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26128] AnonymousClosure: (0xd447fc), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0x1275550: ldr             x1, [x1, #0x128]
    // 0x1275554: r0 = AllocateClosure()
    //     0x1275554: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1275558: r16 = <Color>
    //     0x1275558: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x127555c: ldr             x16, [x16, #0xa90]
    // 0x1275560: stp             x0, x16, [SP]
    // 0x1275564: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1275564: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1275568: r0 = resolveWith()
    //     0x1275568: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x127556c: mov             x1, x0
    // 0x1275570: ldur            x0, [fp, #-0x18]
    // 0x1275574: b               #0x1275640
    // 0x1275578: r17 = 5064
    //     0x1275578: mov             x17, #0x13c8
    // 0x127557c: cmp             x0, x17
    // 0x1275580: b.ne            #0x12755fc
    // 0x1275584: ldr             x1, [fp, #0x18]
    // 0x1275588: r1 = 2
    //     0x1275588: mov             x1, #2
    // 0x127558c: r0 = AllocateContext()
    //     0x127558c: bl              #0x13de838  ; AllocateContextStub
    // 0x1275590: mov             x1, x0
    // 0x1275594: ldr             x0, [fp, #0x18]
    // 0x1275598: StoreField: r1->field_f = r0
    //     0x1275598: stur            w0, [x1, #0xf]
    // 0x127559c: LoadField: r2 = r0->field_2f
    //     0x127559c: ldur            w2, [x0, #0x2f]
    // 0x12755a0: DecompressPointer r2
    //     0x12755a0: add             x2, x2, HEAP, lsl #32
    // 0x12755a4: LoadField: r3 = r2->field_3f
    //     0x12755a4: ldur            w3, [x2, #0x3f]
    // 0x12755a8: DecompressPointer r3
    //     0x12755a8: add             x3, x3, HEAP, lsl #32
    // 0x12755ac: LoadField: r2 = r3->field_7
    //     0x12755ac: ldur            w2, [x3, #7]
    // 0x12755b0: DecompressPointer r2
    //     0x12755b0: add             x2, x2, HEAP, lsl #32
    // 0x12755b4: r16 = Instance_Brightness
    //     0x12755b4: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x12755b8: cmp             w2, w16
    // 0x12755bc: r16 = true
    //     0x12755bc: add             x16, NULL, #0x20  ; true
    // 0x12755c0: r17 = false
    //     0x12755c0: add             x17, NULL, #0x30  ; false
    // 0x12755c4: csel            x3, x16, x17, eq
    // 0x12755c8: StoreField: r1->field_13 = r3
    //     0x12755c8: stur            w3, [x1, #0x13]
    // 0x12755cc: mov             x2, x1
    // 0x12755d0: r1 = Function '<anonymous closure>':.
    //     0x12755d0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26130] AnonymousClosure: (0xd446cc), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM2
    //     0x12755d4: ldr             x1, [x1, #0x130]
    // 0x12755d8: r0 = AllocateClosure()
    //     0x12755d8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12755dc: r16 = <Color>
    //     0x12755dc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x12755e0: ldr             x16, [x16, #0xa90]
    // 0x12755e4: stp             x0, x16, [SP]
    // 0x12755e8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12755e8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12755ec: r0 = resolveWith()
    //     0x12755ec: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x12755f0: mov             x1, x0
    // 0x12755f4: ldur            x0, [fp, #-0x18]
    // 0x12755f8: b               #0x1275640
    // 0x12755fc: ldr             x0, [fp, #0x18]
    // 0x1275600: r1 = 1
    //     0x1275600: mov             x1, #1
    // 0x1275604: r0 = AllocateContext()
    //     0x1275604: bl              #0x13de838  ; AllocateContextStub
    // 0x1275608: mov             x1, x0
    // 0x127560c: ldr             x0, [fp, #0x18]
    // 0x1275610: StoreField: r1->field_f = r0
    //     0x1275610: stur            w0, [x1, #0xf]
    // 0x1275614: mov             x2, x1
    // 0x1275618: r1 = Function '<anonymous closure>':.
    //     0x1275618: add             x1, PP, #0x26, lsl #12  ; [pp+0x26138] AnonymousClosure: (0xd44618), of [package:flutter/src/material/switch.dart] _SwitchDefaultsCupertino
    //     0x127561c: ldr             x1, [x1, #0x138]
    // 0x1275620: r0 = AllocateClosure()
    //     0x1275620: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1275624: r16 = <Color>
    //     0x1275624: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1275628: ldr             x16, [x16, #0xa90]
    // 0x127562c: stp             x0, x16, [SP]
    // 0x1275630: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1275630: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1275634: r0 = resolveWith()
    //     0x1275634: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1275638: mov             x1, x0
    // 0x127563c: ldur            x0, [fp, #-0x18]
    // 0x1275640: cmp             w0, w1
    // 0x1275644: b.ne            #0x1275e18
    // 0x1275648: ldur            x0, [fp, #-8]
    // 0x127564c: r17 = 5062
    //     0x127564c: mov             x17, #0x13c6
    // 0x1275650: cmp             x0, x17
    // 0x1275654: b.ne            #0x1275668
    // 0x1275658: ldr             x1, [fp, #0x10]
    // 0x127565c: LoadField: r2 = r1->field_f
    //     0x127565c: ldur            w2, [x1, #0xf]
    // 0x1275660: DecompressPointer r2
    //     0x1275660: add             x2, x2, HEAP, lsl #32
    // 0x1275664: b               #0x12756dc
    // 0x1275668: ldr             x1, [fp, #0x10]
    // 0x127566c: r17 = 5063
    //     0x127566c: mov             x17, #0x13c7
    // 0x1275670: cmp             x0, x17
    // 0x1275674: b.ne            #0x12756bc
    // 0x1275678: r1 = 1
    //     0x1275678: mov             x1, #1
    // 0x127567c: r0 = AllocateContext()
    //     0x127567c: bl              #0x13de838  ; AllocateContextStub
    // 0x1275680: mov             x1, x0
    // 0x1275684: ldr             x0, [fp, #0x10]
    // 0x1275688: StoreField: r1->field_f = r0
    //     0x1275688: stur            w0, [x1, #0xf]
    // 0x127568c: mov             x2, x1
    // 0x1275690: r1 = Function '<anonymous closure>':.
    //     0x1275690: add             x1, PP, #0x26, lsl #12  ; [pp+0x26140] AnonymousClosure: (0xd444c0), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0x1275694: ldr             x1, [x1, #0x140]
    // 0x1275698: r0 = AllocateClosure()
    //     0x1275698: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x127569c: r16 = <Color?>
    //     0x127569c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x12756a0: ldr             x16, [x16, #0xa40]
    // 0x12756a4: stp             x0, x16, [SP]
    // 0x12756a8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12756a8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12756ac: r0 = resolveWith()
    //     0x12756ac: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x12756b0: mov             x2, x0
    // 0x12756b4: ldur            x0, [fp, #-8]
    // 0x12756b8: b               #0x12756dc
    // 0x12756bc: r17 = 5064
    //     0x12756bc: mov             x17, #0x13c8
    // 0x12756c0: cmp             x0, x17
    // 0x12756c4: b.ne            #0x12756d4
    // 0x12756c8: r2 = Instance_WidgetStatePropertyAll
    //     0x12756c8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26148] Obj!WidgetStatePropertyAll<Color>@128a071
    //     0x12756cc: ldr             x2, [x2, #0x148]
    // 0x12756d0: b               #0x12756dc
    // 0x12756d4: r2 = Instance_WidgetStatePropertyAll
    //     0x12756d4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26148] Obj!WidgetStatePropertyAll<Color>@128a071
    //     0x12756d8: ldr             x2, [x2, #0x148]
    // 0x12756dc: ldur            x1, [fp, #-0x10]
    // 0x12756e0: stur            x2, [fp, #-0x18]
    // 0x12756e4: r17 = 5062
    //     0x12756e4: mov             x17, #0x13c6
    // 0x12756e8: cmp             x1, x17
    // 0x12756ec: b.ne            #0x1275708
    // 0x12756f0: ldr             x3, [fp, #0x18]
    // 0x12756f4: LoadField: r4 = r3->field_f
    //     0x12756f4: ldur            w4, [x3, #0xf]
    // 0x12756f8: DecompressPointer r4
    //     0x12756f8: add             x4, x4, HEAP, lsl #32
    // 0x12756fc: mov             x0, x2
    // 0x1275700: mov             x2, x4
    // 0x1275704: b               #0x1275788
    // 0x1275708: ldr             x3, [fp, #0x18]
    // 0x127570c: r17 = 5063
    //     0x127570c: mov             x17, #0x13c7
    // 0x1275710: cmp             x1, x17
    // 0x1275714: b.ne            #0x1275760
    // 0x1275718: r1 = 1
    //     0x1275718: mov             x1, #1
    // 0x127571c: r0 = AllocateContext()
    //     0x127571c: bl              #0x13de838  ; AllocateContextStub
    // 0x1275720: mov             x1, x0
    // 0x1275724: ldr             x0, [fp, #0x18]
    // 0x1275728: StoreField: r1->field_f = r0
    //     0x1275728: stur            w0, [x1, #0xf]
    // 0x127572c: mov             x2, x1
    // 0x1275730: r1 = Function '<anonymous closure>':.
    //     0x1275730: add             x1, PP, #0x26, lsl #12  ; [pp+0x26140] AnonymousClosure: (0xd444c0), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0x1275734: ldr             x1, [x1, #0x140]
    // 0x1275738: r0 = AllocateClosure()
    //     0x1275738: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x127573c: r16 = <Color?>
    //     0x127573c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1275740: ldr             x16, [x16, #0xa40]
    // 0x1275744: stp             x0, x16, [SP]
    // 0x1275748: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1275748: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x127574c: r0 = resolveWith()
    //     0x127574c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1275750: mov             x2, x0
    // 0x1275754: ldur            x0, [fp, #-0x18]
    // 0x1275758: ldur            x1, [fp, #-0x10]
    // 0x127575c: b               #0x1275788
    // 0x1275760: r17 = 5064
    //     0x1275760: mov             x17, #0x13c8
    // 0x1275764: cmp             x1, x17
    // 0x1275768: b.ne            #0x127577c
    // 0x127576c: ldur            x0, [fp, #-0x18]
    // 0x1275770: r2 = Instance_WidgetStatePropertyAll
    //     0x1275770: add             x2, PP, #0x26, lsl #12  ; [pp+0x26148] Obj!WidgetStatePropertyAll<Color>@128a071
    //     0x1275774: ldr             x2, [x2, #0x148]
    // 0x1275778: b               #0x1275788
    // 0x127577c: ldur            x0, [fp, #-0x18]
    // 0x1275780: r2 = Instance_WidgetStatePropertyAll
    //     0x1275780: add             x2, PP, #0x26, lsl #12  ; [pp+0x26148] Obj!WidgetStatePropertyAll<Color>@128a071
    //     0x1275784: ldr             x2, [x2, #0x148]
    // 0x1275788: r3 = LoadClassIdInstr(r0)
    //     0x1275788: ldur            x3, [x0, #-1]
    //     0x127578c: ubfx            x3, x3, #0xc, #0x14
    // 0x1275790: stp             x2, x0, [SP]
    // 0x1275794: mov             x0, x3
    // 0x1275798: mov             lr, x0
    // 0x127579c: ldr             lr, [x21, lr, lsl #3]
    // 0x12757a0: blr             lr
    // 0x12757a4: tbnz            w0, #4, #0x1275e18
    // 0x12757a8: ldur            x1, [fp, #-8]
    // 0x12757ac: r17 = -5064
    //     0x12757ac: mov             x17, #-0x13c8
    // 0x12757b0: add             x16, x1, x17
    // 0x12757b4: cmp             x16, #1
    // 0x12757b8: b.ls            #0x12757c8
    // 0x12757bc: r17 = 5062
    //     0x12757bc: mov             x17, #0x13c6
    // 0x12757c0: cmp             x1, x17
    // 0x12757c4: b.ne            #0x12757d8
    // 0x12757c8: ldr             x2, [fp, #0x10]
    // 0x12757cc: LoadField: r0 = r2->field_13
    //     0x12757cc: ldur            w0, [x2, #0x13]
    // 0x12757d0: DecompressPointer r0
    //     0x12757d0: add             x0, x0, HEAP, lsl #32
    // 0x12757d4: b               #0x12757e4
    // 0x12757d8: ldr             x2, [fp, #0x10]
    // 0x12757dc: r0 = Instance_WidgetStatePropertyAll
    //     0x12757dc: add             x0, PP, #0x26, lsl #12  ; [pp+0x26150] Obj!WidgetStatePropertyAll<double>@128a061
    //     0x12757e0: ldr             x0, [x0, #0x150]
    // 0x12757e4: ldur            x3, [fp, #-0x10]
    // 0x12757e8: r17 = -5064
    //     0x12757e8: mov             x17, #-0x13c8
    // 0x12757ec: add             x16, x3, x17
    // 0x12757f0: cmp             x16, #1
    // 0x12757f4: b.ls            #0x1275804
    // 0x12757f8: r17 = 5062
    //     0x12757f8: mov             x17, #0x13c6
    // 0x12757fc: cmp             x3, x17
    // 0x1275800: b.ne            #0x1275814
    // 0x1275804: ldr             x4, [fp, #0x18]
    // 0x1275808: LoadField: r5 = r4->field_13
    //     0x1275808: ldur            w5, [x4, #0x13]
    // 0x127580c: DecompressPointer r5
    //     0x127580c: add             x5, x5, HEAP, lsl #32
    // 0x1275810: b               #0x1275820
    // 0x1275814: ldr             x4, [fp, #0x18]
    // 0x1275818: r5 = Instance_WidgetStatePropertyAll
    //     0x1275818: add             x5, PP, #0x26, lsl #12  ; [pp+0x26150] Obj!WidgetStatePropertyAll<double>@128a061
    //     0x127581c: ldr             x5, [x5, #0x150]
    // 0x1275820: r6 = LoadClassIdInstr(r0)
    //     0x1275820: ldur            x6, [x0, #-1]
    //     0x1275824: ubfx            x6, x6, #0xc, #0x14
    // 0x1275828: stp             x5, x0, [SP]
    // 0x127582c: mov             x0, x6
    // 0x1275830: mov             lr, x0
    // 0x1275834: ldr             lr, [x21, lr, lsl #3]
    // 0x1275838: blr             lr
    // 0x127583c: tbnz            w0, #4, #0x1275e18
    // 0x1275840: ldur            x0, [fp, #-8]
    // 0x1275844: r17 = -5062
    //     0x1275844: mov             x17, #-0x13c6
    // 0x1275848: add             x16, x0, x17
    // 0x127584c: cmp             x16, #1
    // 0x1275850: b.hi            #0x127585c
    // 0x1275854: ldr             x3, [fp, #0x10]
    // 0x1275858: b               #0x1275888
    // 0x127585c: r17 = 5064
    //     0x127585c: mov             x17, #0x13c8
    // 0x1275860: cmp             x0, x17
    // 0x1275864: b.ne            #0x1275884
    // 0x1275868: ldr             x3, [fp, #0x10]
    // 0x127586c: LoadField: r1 = r3->field_2f
    //     0x127586c: ldur            w1, [x3, #0x2f]
    // 0x1275870: DecompressPointer r1
    //     0x1275870: add             x1, x1, HEAP, lsl #32
    // 0x1275874: LoadField: r2 = r1->field_1b
    //     0x1275874: ldur            w2, [x1, #0x1b]
    // 0x1275878: DecompressPointer r2
    //     0x1275878: add             x2, x2, HEAP, lsl #32
    // 0x127587c: mov             x1, x2
    // 0x1275880: b               #0x1275890
    // 0x1275884: ldr             x3, [fp, #0x10]
    // 0x1275888: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x1275888: ldur            w1, [x3, #0x17]
    // 0x127588c: DecompressPointer r1
    //     0x127588c: add             x1, x1, HEAP, lsl #32
    // 0x1275890: ldur            x4, [fp, #-0x10]
    // 0x1275894: r17 = -5062
    //     0x1275894: mov             x17, #-0x13c6
    // 0x1275898: add             x16, x4, x17
    // 0x127589c: cmp             x16, #1
    // 0x12758a0: b.hi            #0x12758ac
    // 0x12758a4: ldr             x5, [fp, #0x18]
    // 0x12758a8: b               #0x12758d8
    // 0x12758ac: r17 = 5064
    //     0x12758ac: mov             x17, #0x13c8
    // 0x12758b0: cmp             x4, x17
    // 0x12758b4: b.ne            #0x12758d4
    // 0x12758b8: ldr             x5, [fp, #0x18]
    // 0x12758bc: LoadField: r2 = r5->field_2f
    //     0x12758bc: ldur            w2, [x5, #0x2f]
    // 0x12758c0: DecompressPointer r2
    //     0x12758c0: add             x2, x2, HEAP, lsl #32
    // 0x12758c4: LoadField: r6 = r2->field_1b
    //     0x12758c4: ldur            w6, [x2, #0x1b]
    // 0x12758c8: DecompressPointer r6
    //     0x12758c8: add             x6, x6, HEAP, lsl #32
    // 0x12758cc: mov             x2, x6
    // 0x12758d0: b               #0x12758e0
    // 0x12758d4: ldr             x5, [fp, #0x18]
    // 0x12758d8: ArrayLoad: r2 = r5[0]  ; List_4
    //     0x12758d8: ldur            w2, [x5, #0x17]
    // 0x12758dc: DecompressPointer r2
    //     0x12758dc: add             x2, x2, HEAP, lsl #32
    // 0x12758e0: cmp             w1, w2
    // 0x12758e4: b.ne            #0x1275e18
    // 0x12758e8: r17 = 5062
    //     0x12758e8: mov             x17, #0x13c6
    // 0x12758ec: cmp             x0, x17
    // 0x12758f0: b.ne            #0x1275908
    // 0x12758f4: LoadField: r1 = r3->field_1b
    //     0x12758f4: ldur            w1, [x3, #0x1b]
    // 0x12758f8: DecompressPointer r1
    //     0x12758f8: add             x1, x1, HEAP, lsl #32
    // 0x12758fc: mov             x3, x1
    // 0x1275900: mov             x0, x4
    // 0x1275904: b               #0x12759a4
    // 0x1275908: r17 = 5063
    //     0x1275908: mov             x17, #0x13c7
    // 0x127590c: cmp             x0, x17
    // 0x1275910: b.ne            #0x1275940
    // 0x1275914: r1 = Function '<anonymous closure>':.
    //     0x1275914: add             x1, PP, #0x26, lsl #12  ; [pp+0x26158] AnonymousClosure: (0xd42a1c), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0x1275918: ldr             x1, [x1, #0x158]
    // 0x127591c: r2 = Null
    //     0x127591c: mov             x2, NULL
    // 0x1275920: r0 = AllocateClosure()
    //     0x1275920: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1275924: r16 = <MouseCursor>
    //     0x1275924: ldr             x16, [PP, #0x21a8]  ; [pp+0x21a8] TypeArguments: <MouseCursor>
    // 0x1275928: stp             x0, x16, [SP]
    // 0x127592c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x127592c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1275930: r0 = resolveWith()
    //     0x1275930: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1275934: mov             x3, x0
    // 0x1275938: ldur            x0, [fp, #-0x10]
    // 0x127593c: b               #0x12759a4
    // 0x1275940: r17 = 5064
    //     0x1275940: mov             x17, #0x13c8
    // 0x1275944: cmp             x0, x17
    // 0x1275948: b.ne            #0x1275978
    // 0x127594c: r1 = Function '<anonymous closure>':.
    //     0x127594c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26160] AnonymousClosure: (0xd42a1c), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0x1275950: ldr             x1, [x1, #0x160]
    // 0x1275954: r2 = Null
    //     0x1275954: mov             x2, NULL
    // 0x1275958: r0 = AllocateClosure()
    //     0x1275958: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x127595c: r16 = <MouseCursor>
    //     0x127595c: ldr             x16, [PP, #0x21a8]  ; [pp+0x21a8] TypeArguments: <MouseCursor>
    // 0x1275960: stp             x0, x16, [SP]
    // 0x1275964: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1275964: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1275968: r0 = resolveWith()
    //     0x1275968: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x127596c: mov             x3, x0
    // 0x1275970: ldur            x0, [fp, #-0x10]
    // 0x1275974: b               #0x12759a4
    // 0x1275978: r1 = Function '<anonymous closure>':.
    //     0x1275978: add             x1, PP, #0x26, lsl #12  ; [pp+0x26168] AnonymousClosure: (0xd429b4), of [package:flutter/src/material/switch.dart] _SwitchDefaultsCupertino
    //     0x127597c: ldr             x1, [x1, #0x168]
    // 0x1275980: r2 = Null
    //     0x1275980: mov             x2, NULL
    // 0x1275984: r0 = AllocateClosure()
    //     0x1275984: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1275988: r16 = <MouseCursor?>
    //     0x1275988: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ab8] TypeArguments: <MouseCursor?>
    //     0x127598c: ldr             x16, [x16, #0xab8]
    // 0x1275990: stp             x0, x16, [SP]
    // 0x1275994: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1275994: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1275998: r0 = resolveWith()
    //     0x1275998: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x127599c: mov             x3, x0
    // 0x12759a0: ldur            x0, [fp, #-0x10]
    // 0x12759a4: stur            x3, [fp, #-0x18]
    // 0x12759a8: r17 = 5062
    //     0x12759a8: mov             x17, #0x13c6
    // 0x12759ac: cmp             x0, x17
    // 0x12759b0: b.ne            #0x12759c8
    // 0x12759b4: ldr             x4, [fp, #0x18]
    // 0x12759b8: LoadField: r1 = r4->field_1b
    //     0x12759b8: ldur            w1, [x4, #0x1b]
    // 0x12759bc: DecompressPointer r1
    //     0x12759bc: add             x1, x1, HEAP, lsl #32
    // 0x12759c0: mov             x0, x3
    // 0x12759c4: b               #0x1275a68
    // 0x12759c8: ldr             x4, [fp, #0x18]
    // 0x12759cc: r17 = 5063
    //     0x12759cc: mov             x17, #0x13c7
    // 0x12759d0: cmp             x0, x17
    // 0x12759d4: b.ne            #0x1275a04
    // 0x12759d8: r1 = Function '<anonymous closure>':.
    //     0x12759d8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26158] AnonymousClosure: (0xd42a1c), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0x12759dc: ldr             x1, [x1, #0x158]
    // 0x12759e0: r2 = Null
    //     0x12759e0: mov             x2, NULL
    // 0x12759e4: r0 = AllocateClosure()
    //     0x12759e4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12759e8: r16 = <MouseCursor>
    //     0x12759e8: ldr             x16, [PP, #0x21a8]  ; [pp+0x21a8] TypeArguments: <MouseCursor>
    // 0x12759ec: stp             x0, x16, [SP]
    // 0x12759f0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12759f0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12759f4: r0 = resolveWith()
    //     0x12759f4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x12759f8: mov             x1, x0
    // 0x12759fc: ldur            x0, [fp, #-0x18]
    // 0x1275a00: b               #0x1275a68
    // 0x1275a04: r17 = 5064
    //     0x1275a04: mov             x17, #0x13c8
    // 0x1275a08: cmp             x0, x17
    // 0x1275a0c: b.ne            #0x1275a3c
    // 0x1275a10: r1 = Function '<anonymous closure>':.
    //     0x1275a10: add             x1, PP, #0x26, lsl #12  ; [pp+0x26160] AnonymousClosure: (0xd42a1c), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0x1275a14: ldr             x1, [x1, #0x160]
    // 0x1275a18: r2 = Null
    //     0x1275a18: mov             x2, NULL
    // 0x1275a1c: r0 = AllocateClosure()
    //     0x1275a1c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1275a20: r16 = <MouseCursor>
    //     0x1275a20: ldr             x16, [PP, #0x21a8]  ; [pp+0x21a8] TypeArguments: <MouseCursor>
    // 0x1275a24: stp             x0, x16, [SP]
    // 0x1275a28: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1275a28: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1275a2c: r0 = resolveWith()
    //     0x1275a2c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1275a30: mov             x1, x0
    // 0x1275a34: ldur            x0, [fp, #-0x18]
    // 0x1275a38: b               #0x1275a68
    // 0x1275a3c: r1 = Function '<anonymous closure>':.
    //     0x1275a3c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26168] AnonymousClosure: (0xd429b4), of [package:flutter/src/material/switch.dart] _SwitchDefaultsCupertino
    //     0x1275a40: ldr             x1, [x1, #0x168]
    // 0x1275a44: r2 = Null
    //     0x1275a44: mov             x2, NULL
    // 0x1275a48: r0 = AllocateClosure()
    //     0x1275a48: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1275a4c: r16 = <MouseCursor?>
    //     0x1275a4c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ab8] TypeArguments: <MouseCursor?>
    //     0x1275a50: ldr             x16, [x16, #0xab8]
    // 0x1275a54: stp             x0, x16, [SP]
    // 0x1275a58: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1275a58: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1275a5c: r0 = resolveWith()
    //     0x1275a5c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1275a60: mov             x1, x0
    // 0x1275a64: ldur            x0, [fp, #-0x18]
    // 0x1275a68: cmp             w0, w1
    // 0x1275a6c: b.ne            #0x1275e18
    // 0x1275a70: ldur            x0, [fp, #-8]
    // 0x1275a74: r17 = 5062
    //     0x1275a74: mov             x17, #0x13c6
    // 0x1275a78: cmp             x0, x17
    // 0x1275a7c: b.ne            #0x1275a94
    // 0x1275a80: ldr             x1, [fp, #0x10]
    // 0x1275a84: LoadField: r2 = r1->field_1f
    //     0x1275a84: ldur            w2, [x1, #0x1f]
    // 0x1275a88: DecompressPointer r2
    //     0x1275a88: add             x2, x2, HEAP, lsl #32
    // 0x1275a8c: mov             x1, x2
    // 0x1275a90: b               #0x1275b74
    // 0x1275a94: ldr             x1, [fp, #0x10]
    // 0x1275a98: r17 = 5063
    //     0x1275a98: mov             x17, #0x13c7
    // 0x1275a9c: cmp             x0, x17
    // 0x1275aa0: b.ne            #0x1275ae4
    // 0x1275aa4: r1 = 1
    //     0x1275aa4: mov             x1, #1
    // 0x1275aa8: r0 = AllocateContext()
    //     0x1275aa8: bl              #0x13de838  ; AllocateContextStub
    // 0x1275aac: mov             x1, x0
    // 0x1275ab0: ldr             x0, [fp, #0x10]
    // 0x1275ab4: StoreField: r1->field_f = r0
    //     0x1275ab4: stur            w0, [x1, #0xf]
    // 0x1275ab8: mov             x2, x1
    // 0x1275abc: r1 = Function '<anonymous closure>':.
    //     0x1275abc: add             x1, PP, #0x26, lsl #12  ; [pp+0x26170] AnonymousClosure: (0xd440d4), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0x1275ac0: ldr             x1, [x1, #0x170]
    // 0x1275ac4: r0 = AllocateClosure()
    //     0x1275ac4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1275ac8: r16 = <Color?>
    //     0x1275ac8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1275acc: ldr             x16, [x16, #0xa40]
    // 0x1275ad0: stp             x0, x16, [SP]
    // 0x1275ad4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1275ad4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1275ad8: r0 = resolveWith()
    //     0x1275ad8: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1275adc: mov             x1, x0
    // 0x1275ae0: b               #0x1275b74
    // 0x1275ae4: r17 = 5064
    //     0x1275ae4: mov             x17, #0x13c8
    // 0x1275ae8: cmp             x0, x17
    // 0x1275aec: b.ne            #0x1275b34
    // 0x1275af0: ldr             x1, [fp, #0x10]
    // 0x1275af4: r1 = 1
    //     0x1275af4: mov             x1, #1
    // 0x1275af8: r0 = AllocateContext()
    //     0x1275af8: bl              #0x13de838  ; AllocateContextStub
    // 0x1275afc: mov             x1, x0
    // 0x1275b00: ldr             x0, [fp, #0x10]
    // 0x1275b04: StoreField: r1->field_f = r0
    //     0x1275b04: stur            w0, [x1, #0xf]
    // 0x1275b08: mov             x2, x1
    // 0x1275b0c: r1 = Function '<anonymous closure>':.
    //     0x1275b0c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26178] AnonymousClosure: (0xd43f64), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM2
    //     0x1275b10: ldr             x1, [x1, #0x178]
    // 0x1275b14: r0 = AllocateClosure()
    //     0x1275b14: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1275b18: r16 = <Color?>
    //     0x1275b18: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1275b1c: ldr             x16, [x16, #0xa40]
    // 0x1275b20: stp             x0, x16, [SP]
    // 0x1275b24: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1275b24: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1275b28: r0 = resolveWith()
    //     0x1275b28: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1275b2c: mov             x1, x0
    // 0x1275b30: b               #0x1275b74
    // 0x1275b34: ldr             x0, [fp, #0x10]
    // 0x1275b38: r1 = 1
    //     0x1275b38: mov             x1, #1
    // 0x1275b3c: r0 = AllocateContext()
    //     0x1275b3c: bl              #0x13de838  ; AllocateContextStub
    // 0x1275b40: mov             x1, x0
    // 0x1275b44: ldr             x0, [fp, #0x10]
    // 0x1275b48: StoreField: r1->field_f = r0
    //     0x1275b48: stur            w0, [x1, #0xf]
    // 0x1275b4c: mov             x2, x1
    // 0x1275b50: r1 = Function '<anonymous closure>':.
    //     0x1275b50: add             x1, PP, #0x26, lsl #12  ; [pp+0x26180] AnonymousClosure: (0xd431a0), of [package:flutter/src/material/switch.dart] _SwitchDefaultsCupertino
    //     0x1275b54: ldr             x1, [x1, #0x180]
    // 0x1275b58: r0 = AllocateClosure()
    //     0x1275b58: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1275b5c: r16 = <Color?>
    //     0x1275b5c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1275b60: ldr             x16, [x16, #0xa40]
    // 0x1275b64: stp             x0, x16, [SP]
    // 0x1275b68: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1275b68: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1275b6c: r0 = resolveWith()
    //     0x1275b6c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1275b70: mov             x1, x0
    // 0x1275b74: ldur            x0, [fp, #-0x10]
    // 0x1275b78: stur            x1, [fp, #-0x18]
    // 0x1275b7c: r17 = 5062
    //     0x1275b7c: mov             x17, #0x13c6
    // 0x1275b80: cmp             x0, x17
    // 0x1275b84: b.ne            #0x1275ba0
    // 0x1275b88: ldr             x2, [fp, #0x18]
    // 0x1275b8c: LoadField: r3 = r2->field_1f
    //     0x1275b8c: ldur            w3, [x2, #0x1f]
    // 0x1275b90: DecompressPointer r3
    //     0x1275b90: add             x3, x3, HEAP, lsl #32
    // 0x1275b94: mov             x0, x1
    // 0x1275b98: mov             x1, x3
    // 0x1275b9c: b               #0x1275c8c
    // 0x1275ba0: ldr             x2, [fp, #0x18]
    // 0x1275ba4: r17 = 5063
    //     0x1275ba4: mov             x17, #0x13c7
    // 0x1275ba8: cmp             x0, x17
    // 0x1275bac: b.ne            #0x1275bf4
    // 0x1275bb0: r1 = 1
    //     0x1275bb0: mov             x1, #1
    // 0x1275bb4: r0 = AllocateContext()
    //     0x1275bb4: bl              #0x13de838  ; AllocateContextStub
    // 0x1275bb8: mov             x1, x0
    // 0x1275bbc: ldr             x0, [fp, #0x18]
    // 0x1275bc0: StoreField: r1->field_f = r0
    //     0x1275bc0: stur            w0, [x1, #0xf]
    // 0x1275bc4: mov             x2, x1
    // 0x1275bc8: r1 = Function '<anonymous closure>':.
    //     0x1275bc8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26170] AnonymousClosure: (0xd440d4), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0x1275bcc: ldr             x1, [x1, #0x170]
    // 0x1275bd0: r0 = AllocateClosure()
    //     0x1275bd0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1275bd4: r16 = <Color?>
    //     0x1275bd4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1275bd8: ldr             x16, [x16, #0xa40]
    // 0x1275bdc: stp             x0, x16, [SP]
    // 0x1275be0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1275be0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1275be4: r0 = resolveWith()
    //     0x1275be4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1275be8: mov             x1, x0
    // 0x1275bec: ldur            x0, [fp, #-0x18]
    // 0x1275bf0: b               #0x1275c8c
    // 0x1275bf4: r17 = 5064
    //     0x1275bf4: mov             x17, #0x13c8
    // 0x1275bf8: cmp             x0, x17
    // 0x1275bfc: b.ne            #0x1275c48
    // 0x1275c00: ldr             x1, [fp, #0x18]
    // 0x1275c04: r1 = 1
    //     0x1275c04: mov             x1, #1
    // 0x1275c08: r0 = AllocateContext()
    //     0x1275c08: bl              #0x13de838  ; AllocateContextStub
    // 0x1275c0c: mov             x1, x0
    // 0x1275c10: ldr             x0, [fp, #0x18]
    // 0x1275c14: StoreField: r1->field_f = r0
    //     0x1275c14: stur            w0, [x1, #0xf]
    // 0x1275c18: mov             x2, x1
    // 0x1275c1c: r1 = Function '<anonymous closure>':.
    //     0x1275c1c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26178] AnonymousClosure: (0xd43f64), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM2
    //     0x1275c20: ldr             x1, [x1, #0x178]
    // 0x1275c24: r0 = AllocateClosure()
    //     0x1275c24: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1275c28: r16 = <Color?>
    //     0x1275c28: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1275c2c: ldr             x16, [x16, #0xa40]
    // 0x1275c30: stp             x0, x16, [SP]
    // 0x1275c34: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1275c34: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1275c38: r0 = resolveWith()
    //     0x1275c38: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1275c3c: mov             x1, x0
    // 0x1275c40: ldur            x0, [fp, #-0x18]
    // 0x1275c44: b               #0x1275c8c
    // 0x1275c48: ldr             x0, [fp, #0x18]
    // 0x1275c4c: r1 = 1
    //     0x1275c4c: mov             x1, #1
    // 0x1275c50: r0 = AllocateContext()
    //     0x1275c50: bl              #0x13de838  ; AllocateContextStub
    // 0x1275c54: mov             x1, x0
    // 0x1275c58: ldr             x0, [fp, #0x18]
    // 0x1275c5c: StoreField: r1->field_f = r0
    //     0x1275c5c: stur            w0, [x1, #0xf]
    // 0x1275c60: mov             x2, x1
    // 0x1275c64: r1 = Function '<anonymous closure>':.
    //     0x1275c64: add             x1, PP, #0x26, lsl #12  ; [pp+0x26180] AnonymousClosure: (0xd431a0), of [package:flutter/src/material/switch.dart] _SwitchDefaultsCupertino
    //     0x1275c68: ldr             x1, [x1, #0x180]
    // 0x1275c6c: r0 = AllocateClosure()
    //     0x1275c6c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1275c70: r16 = <Color?>
    //     0x1275c70: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1275c74: ldr             x16, [x16, #0xa40]
    // 0x1275c78: stp             x0, x16, [SP]
    // 0x1275c7c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1275c7c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1275c80: r0 = resolveWith()
    //     0x1275c80: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1275c84: mov             x1, x0
    // 0x1275c88: ldur            x0, [fp, #-0x18]
    // 0x1275c8c: cmp             w0, w1
    // 0x1275c90: b.ne            #0x1275e18
    // 0x1275c94: ldur            x1, [fp, #-8]
    // 0x1275c98: r17 = 5062
    //     0x1275c98: mov             x17, #0x13c6
    // 0x1275c9c: cmp             x1, x17
    // 0x1275ca0: b.ne            #0x1275cb4
    // 0x1275ca4: ldr             x2, [fp, #0x10]
    // 0x1275ca8: LoadField: r0 = r2->field_23
    //     0x1275ca8: ldur            w0, [x2, #0x23]
    // 0x1275cac: DecompressPointer r0
    //     0x1275cac: add             x0, x0, HEAP, lsl #32
    // 0x1275cb0: b               #0x1275cec
    // 0x1275cb4: ldr             x2, [fp, #0x10]
    // 0x1275cb8: r17 = 5063
    //     0x1275cb8: mov             x17, #0x13c7
    // 0x1275cbc: cmp             x1, x17
    // 0x1275cc0: b.ne            #0x1275cd0
    // 0x1275cc4: r0 = 20.000000
    //     0x1275cc4: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ae98] 20
    //     0x1275cc8: ldr             x0, [x0, #0xe98]
    // 0x1275ccc: b               #0x1275cec
    // 0x1275cd0: r17 = 5064
    //     0x1275cd0: mov             x17, #0x13c8
    // 0x1275cd4: cmp             x1, x17
    // 0x1275cd8: b.ne            #0x1275ce8
    // 0x1275cdc: r0 = 20.000000
    //     0x1275cdc: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ae98] 20
    //     0x1275ce0: ldr             x0, [x0, #0xe98]
    // 0x1275ce4: b               #0x1275cec
    // 0x1275ce8: r0 = 0.000000
    //     0x1275ce8: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x1275cec: ldur            x3, [fp, #-0x10]
    // 0x1275cf0: r17 = 5062
    //     0x1275cf0: mov             x17, #0x13c6
    // 0x1275cf4: cmp             x3, x17
    // 0x1275cf8: b.ne            #0x1275d0c
    // 0x1275cfc: ldr             x4, [fp, #0x18]
    // 0x1275d00: LoadField: r5 = r4->field_23
    //     0x1275d00: ldur            w5, [x4, #0x23]
    // 0x1275d04: DecompressPointer r5
    //     0x1275d04: add             x5, x5, HEAP, lsl #32
    // 0x1275d08: b               #0x1275d44
    // 0x1275d0c: ldr             x4, [fp, #0x18]
    // 0x1275d10: r17 = 5063
    //     0x1275d10: mov             x17, #0x13c7
    // 0x1275d14: cmp             x3, x17
    // 0x1275d18: b.ne            #0x1275d28
    // 0x1275d1c: r5 = 20.000000
    //     0x1275d1c: add             x5, PP, #0x1a, lsl #12  ; [pp+0x1ae98] 20
    //     0x1275d20: ldr             x5, [x5, #0xe98]
    // 0x1275d24: b               #0x1275d44
    // 0x1275d28: r17 = 5064
    //     0x1275d28: mov             x17, #0x13c8
    // 0x1275d2c: cmp             x3, x17
    // 0x1275d30: b.ne            #0x1275d40
    // 0x1275d34: r5 = 20.000000
    //     0x1275d34: add             x5, PP, #0x1a, lsl #12  ; [pp+0x1ae98] 20
    //     0x1275d38: ldr             x5, [x5, #0xe98]
    // 0x1275d3c: b               #0x1275d44
    // 0x1275d40: r5 = 0.000000
    //     0x1275d40: ldr             x5, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x1275d44: r6 = LoadClassIdInstr(r0)
    //     0x1275d44: ldur            x6, [x0, #-1]
    //     0x1275d48: ubfx            x6, x6, #0xc, #0x14
    // 0x1275d4c: stp             x5, x0, [SP]
    // 0x1275d50: mov             x0, x6
    // 0x1275d54: mov             lr, x0
    // 0x1275d58: ldr             lr, [x21, lr, lsl #3]
    // 0x1275d5c: blr             lr
    // 0x1275d60: tbnz            w0, #4, #0x1275e18
    // 0x1275d64: ldur            x0, [fp, #-8]
    // 0x1275d68: r17 = 5062
    //     0x1275d68: mov             x17, #0x13c6
    // 0x1275d6c: cmp             x0, x17
    // 0x1275d70: b.eq            #0x1275da0
    // 0x1275d74: r17 = 5063
    //     0x1275d74: mov             x17, #0x13c7
    // 0x1275d78: cmp             x0, x17
    // 0x1275d7c: b.ne            #0x1275d8c
    // 0x1275d80: r1 = Instance_EdgeInsets
    //     0x1275d80: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c430] Obj!EdgeInsets@129dc51
    //     0x1275d84: ldr             x1, [x1, #0x430]
    // 0x1275d88: b               #0x1275dac
    // 0x1275d8c: r17 = 5064
    //     0x1275d8c: mov             x17, #0x13c8
    // 0x1275d90: cmp             x0, x17
    // 0x1275d94: b.ne            #0x1275da0
    // 0x1275d98: r1 = Instance_EdgeInsets
    //     0x1275d98: ldr             x1, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0x1275d9c: b               #0x1275dac
    // 0x1275da0: ldr             x0, [fp, #0x10]
    // 0x1275da4: LoadField: r1 = r0->field_2b
    //     0x1275da4: ldur            w1, [x0, #0x2b]
    // 0x1275da8: DecompressPointer r1
    //     0x1275da8: add             x1, x1, HEAP, lsl #32
    // 0x1275dac: ldur            x0, [fp, #-0x10]
    // 0x1275db0: r17 = 5062
    //     0x1275db0: mov             x17, #0x13c6
    // 0x1275db4: cmp             x0, x17
    // 0x1275db8: b.eq            #0x1275de8
    // 0x1275dbc: r17 = 5063
    //     0x1275dbc: mov             x17, #0x13c7
    // 0x1275dc0: cmp             x0, x17
    // 0x1275dc4: b.ne            #0x1275dd4
    // 0x1275dc8: r0 = Instance_EdgeInsets
    //     0x1275dc8: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c430] Obj!EdgeInsets@129dc51
    //     0x1275dcc: ldr             x0, [x0, #0x430]
    // 0x1275dd0: b               #0x1275df8
    // 0x1275dd4: r17 = 5064
    //     0x1275dd4: mov             x17, #0x13c8
    // 0x1275dd8: cmp             x0, x17
    // 0x1275ddc: b.ne            #0x1275de8
    // 0x1275de0: r0 = Instance_EdgeInsets
    //     0x1275de0: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0x1275de4: b               #0x1275df8
    // 0x1275de8: ldr             x0, [fp, #0x18]
    // 0x1275dec: LoadField: r2 = r0->field_2b
    //     0x1275dec: ldur            w2, [x0, #0x2b]
    // 0x1275df0: DecompressPointer r2
    //     0x1275df0: add             x2, x2, HEAP, lsl #32
    // 0x1275df4: mov             x0, x2
    // 0x1275df8: r2 = LoadClassIdInstr(r1)
    //     0x1275df8: ldur            x2, [x1, #-1]
    //     0x1275dfc: ubfx            x2, x2, #0xc, #0x14
    // 0x1275e00: stp             x0, x1, [SP]
    // 0x1275e04: mov             x0, x2
    // 0x1275e08: mov             lr, x0
    // 0x1275e0c: ldr             lr, [x21, lr, lsl #3]
    // 0x1275e10: blr             lr
    // 0x1275e14: b               #0x1275e1c
    // 0x1275e18: r0 = false
    //     0x1275e18: add             x0, NULL, #0x30  ; false
    // 0x1275e1c: LeaveFrame
    //     0x1275e1c: mov             SP, fp
    //     0x1275e20: ldp             fp, lr, [SP], #0x10
    // 0x1275e24: ret
    //     0x1275e24: ret             
    // 0x1275e28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1275e28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1275e2c: b               #0x127511c
  }
}

// class id: 6808, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class SwitchTheme extends InheritedWidget {

  static _ of(/* No info */) {
    // ** addr: 0xd4237c, size: 0x5c
    // 0xd4237c: EnterFrame
    //     0xd4237c: stp             fp, lr, [SP, #-0x10]!
    //     0xd42380: mov             fp, SP
    // 0xd42384: AllocStack(0x18)
    //     0xd42384: sub             SP, SP, #0x18
    // 0xd42388: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xd42388: stur            x1, [fp, #-8]
    // 0xd4238c: CheckStackOverflow
    //     0xd4238c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd42390: cmp             SP, x16
    //     0xd42394: b.ls            #0xd423d0
    // 0xd42398: r16 = <SwitchTheme>
    //     0xd42398: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8f9c0] TypeArguments: <SwitchTheme>
    //     0xd4239c: ldr             x16, [x16, #0x9c0]
    // 0xd423a0: stp             x1, x16, [SP]
    // 0xd423a4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd423a4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd423a8: r0 = dependOnInheritedWidgetOfExactType()
    //     0xd423a8: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xd423ac: ldur            x1, [fp, #-8]
    // 0xd423b0: r0 = of()
    //     0xd423b0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd423b4: r17 = 299
    //     0xd423b4: mov             x17, #0x12b
    // 0xd423b8: ldr             w1, [x0, x17]
    // 0xd423bc: DecompressPointer r1
    //     0xd423bc: add             x1, x1, HEAP, lsl #32
    // 0xd423c0: mov             x0, x1
    // 0xd423c4: LeaveFrame
    //     0xd423c4: mov             SP, fp
    //     0xd423c8: ldp             fp, lr, [SP], #0x10
    // 0xd423cc: ret
    //     0xd423cc: ret             
    // 0xd423d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd423d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd423d4: b               #0xd42398
  }
}
