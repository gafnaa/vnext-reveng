// lib: , url: package:flutter/src/material/app.dart

// class id: 1048842, size: 0x8
class :: {
}

// class id: 3136, size: 0x8, field offset: 0x8
//   const constructor, 
class MaterialScrollBehavior extends ScrollBehavior {

  _ buildScrollbar(/* No info */) {
    // ** addr: 0x12fd394, size: 0xac
    // 0x12fd394: EnterFrame
    //     0x12fd394: stp             fp, lr, [SP, #-0x10]!
    //     0x12fd398: mov             fp, SP
    // 0x12fd39c: AllocStack(0x8)
    //     0x12fd39c: sub             SP, SP, #8
    // 0x12fd3a0: SetupParameters(MaterialScrollBehavior this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0x12fd3a0: mov             x16, x2
    //     0x12fd3a4: mov             x2, x1
    //     0x12fd3a8: mov             x1, x16
    //     0x12fd3ac: mov             x0, x3
    //     0x12fd3b0: stur            x3, [fp, #-8]
    // 0x12fd3b4: CheckStackOverflow
    //     0x12fd3b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fd3b8: cmp             SP, x16
    //     0x12fd3bc: b.ls            #0x12fd438
    // 0x12fd3c0: LoadField: r2 = r5->field_7
    //     0x12fd3c0: ldur            w2, [x5, #7]
    // 0x12fd3c4: DecompressPointer r2
    //     0x12fd3c4: add             x2, x2, HEAP, lsl #32
    // 0x12fd3c8: r16 = Instance_AxisDirection
    //     0x12fd3c8: ldr             x16, [PP, #0x5ce8]  ; [pp+0x5ce8] Obj!AxisDirection@12c4a01
    // 0x12fd3cc: cmp             w2, w16
    // 0x12fd3d0: b.eq            #0x12fd3e0
    // 0x12fd3d4: r16 = Instance_AxisDirection
    //     0x12fd3d4: ldr             x16, [PP, #0x5cf0]  ; [pp+0x5cf0] Obj!AxisDirection@12c49e1
    // 0x12fd3d8: cmp             w2, w16
    // 0x12fd3dc: b.ne            #0x12fd3e8
    // 0x12fd3e0: r2 = Instance_Axis
    //     0x12fd3e0: ldr             x2, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0x12fd3e4: b               #0x12fd40c
    // 0x12fd3e8: r16 = Instance_AxisDirection
    //     0x12fd3e8: ldr             x16, [PP, #0x5cf8]  ; [pp+0x5cf8] Obj!AxisDirection@12c49c1
    // 0x12fd3ec: cmp             w2, w16
    // 0x12fd3f0: b.eq            #0x12fd400
    // 0x12fd3f4: r16 = Instance_AxisDirection
    //     0x12fd3f4: ldr             x16, [PP, #0x5d00]  ; [pp+0x5d00] Obj!AxisDirection@12c49a1
    // 0x12fd3f8: cmp             w2, w16
    // 0x12fd3fc: b.ne            #0x12fd408
    // 0x12fd400: r2 = Instance_Axis
    //     0x12fd400: ldr             x2, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0x12fd404: b               #0x12fd40c
    // 0x12fd408: r2 = Null
    //     0x12fd408: mov             x2, NULL
    // 0x12fd40c: LoadField: r3 = r2->field_7
    //     0x12fd40c: ldur            x3, [x2, #7]
    // 0x12fd410: cmp             x3, #0
    // 0x12fd414: b.gt            #0x12fd424
    // 0x12fd418: LeaveFrame
    //     0x12fd418: mov             SP, fp
    //     0x12fd41c: ldp             fp, lr, [SP], #0x10
    // 0x12fd420: ret
    //     0x12fd420: ret             
    // 0x12fd424: r0 = of()
    //     0x12fd424: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x12fd428: ldur            x0, [fp, #-8]
    // 0x12fd42c: LeaveFrame
    //     0x12fd42c: mov             SP, fp
    //     0x12fd430: ldp             fp, lr, [SP], #0x10
    // 0x12fd434: ret
    //     0x12fd434: ret             
    // 0x12fd438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fd438: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fd43c: b               #0x12fd3c0
  }
  _ buildOverscrollIndicator(/* No info */) {
    // ** addr: 0x12fd448, size: 0x148
    // 0x12fd448: EnterFrame
    //     0x12fd448: stp             fp, lr, [SP, #-0x10]!
    //     0x12fd44c: mov             fp, SP
    // 0x12fd450: AllocStack(0x28)
    //     0x12fd450: sub             SP, SP, #0x28
    // 0x12fd454: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */)
    //     0x12fd454: mov             x0, x2
    //     0x12fd458: stur            x2, [fp, #-8]
    //     0x12fd45c: stur            x3, [fp, #-0x10]
    //     0x12fd460: stur            x5, [fp, #-0x18]
    // 0x12fd464: CheckStackOverflow
    //     0x12fd464: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fd468: cmp             SP, x16
    //     0x12fd46c: b.ls            #0x12fd588
    // 0x12fd470: mov             x1, x0
    // 0x12fd474: r0 = of()
    //     0x12fd474: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x12fd478: LoadField: r1 = r0->field_2f
    //     0x12fd478: ldur            w1, [x0, #0x2f]
    // 0x12fd47c: DecompressPointer r1
    //     0x12fd47c: add             x1, x1, HEAP, lsl #32
    // 0x12fd480: tbnz            w1, #4, #0x12fd490
    // 0x12fd484: r0 = Instance_AndroidOverscrollIndicator
    //     0x12fd484: add             x0, PP, #0xa0, lsl #12  ; [pp+0xa0fb8] Obj!AndroidOverscrollIndicator@12c2741
    //     0x12fd488: ldr             x0, [x0, #0xfb8]
    // 0x12fd48c: b               #0x12fd498
    // 0x12fd490: r0 = Instance_AndroidOverscrollIndicator
    //     0x12fd490: add             x0, PP, #0xa0, lsl #12  ; [pp+0xa0fc0] Obj!AndroidOverscrollIndicator@12c2721
    //     0x12fd494: ldr             x0, [x0, #0xfc0]
    // 0x12fd498: ldur            x1, [fp, #-8]
    // 0x12fd49c: stur            x0, [fp, #-0x20]
    // 0x12fd4a0: r0 = of()
    //     0x12fd4a0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x12fd4a4: ldur            x0, [fp, #-0x20]
    // 0x12fd4a8: LoadField: r1 = r0->field_7
    //     0x12fd4a8: ldur            x1, [x0, #7]
    // 0x12fd4ac: cmp             x1, #0
    // 0x12fd4b0: b.gt            #0x12fd510
    // 0x12fd4b4: ldur            x1, [fp, #-0x10]
    // 0x12fd4b8: ldur            x0, [fp, #-0x18]
    // 0x12fd4bc: LoadField: r2 = r0->field_7
    //     0x12fd4bc: ldur            w2, [x0, #7]
    // 0x12fd4c0: DecompressPointer r2
    //     0x12fd4c0: add             x2, x2, HEAP, lsl #32
    // 0x12fd4c4: stur            x2, [fp, #-0x28]
    // 0x12fd4c8: LoadField: r3 = r0->field_13
    //     0x12fd4c8: ldur            w3, [x0, #0x13]
    // 0x12fd4cc: DecompressPointer r3
    //     0x12fd4cc: add             x3, x3, HEAP, lsl #32
    // 0x12fd4d0: stur            x3, [fp, #-0x20]
    // 0x12fd4d4: r0 = StretchingOverscrollIndicator()
    //     0x12fd4d4: bl              #0x12fd59c  ; AllocateStretchingOverscrollIndicatorStub -> StretchingOverscrollIndicator (size=0x1c)
    // 0x12fd4d8: mov             x1, x0
    // 0x12fd4dc: ldur            x0, [fp, #-0x28]
    // 0x12fd4e0: StoreField: r1->field_b = r0
    //     0x12fd4e0: stur            w0, [x1, #0xb]
    // 0x12fd4e4: r2 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0x12fd4e4: add             x2, PP, #0x18, lsl #12  ; [pp+0x18158] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x7f2adac1b19c)
    //     0x12fd4e8: ldr             x2, [x2, #0x158]
    // 0x12fd4ec: StoreField: r1->field_f = r2
    //     0x12fd4ec: stur            w2, [x1, #0xf]
    // 0x12fd4f0: ldur            x0, [fp, #-0x20]
    // 0x12fd4f4: StoreField: r1->field_13 = r0
    //     0x12fd4f4: stur            w0, [x1, #0x13]
    // 0x12fd4f8: ldur            x3, [fp, #-0x10]
    // 0x12fd4fc: ArrayStore: r1[0] = r3  ; List_4
    //     0x12fd4fc: stur            w3, [x1, #0x17]
    // 0x12fd500: mov             x0, x1
    // 0x12fd504: LeaveFrame
    //     0x12fd504: mov             SP, fp
    //     0x12fd508: ldp             fp, lr, [SP], #0x10
    // 0x12fd50c: ret
    //     0x12fd50c: ret             
    // 0x12fd510: ldur            x3, [fp, #-0x10]
    // 0x12fd514: ldur            x0, [fp, #-0x18]
    // 0x12fd518: r2 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0x12fd518: add             x2, PP, #0x18, lsl #12  ; [pp+0x18158] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x7f2adac1b19c)
    //     0x12fd51c: ldr             x2, [x2, #0x158]
    // 0x12fd520: LoadField: r4 = r0->field_7
    //     0x12fd520: ldur            w4, [x0, #7]
    // 0x12fd524: DecompressPointer r4
    //     0x12fd524: add             x4, x4, HEAP, lsl #32
    // 0x12fd528: ldur            x1, [fp, #-8]
    // 0x12fd52c: stur            x4, [fp, #-0x20]
    // 0x12fd530: r0 = of()
    //     0x12fd530: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x12fd534: LoadField: r1 = r0->field_3f
    //     0x12fd534: ldur            w1, [x0, #0x3f]
    // 0x12fd538: DecompressPointer r1
    //     0x12fd538: add             x1, x1, HEAP, lsl #32
    // 0x12fd53c: LoadField: r0 = r1->field_2b
    //     0x12fd53c: ldur            w0, [x1, #0x2b]
    // 0x12fd540: DecompressPointer r0
    //     0x12fd540: add             x0, x0, HEAP, lsl #32
    // 0x12fd544: stur            x0, [fp, #-8]
    // 0x12fd548: r0 = GlowingOverscrollIndicator()
    //     0x12fd548: bl              #0x12fd590  ; AllocateGlowingOverscrollIndicatorStub -> GlowingOverscrollIndicator (size=0x24)
    // 0x12fd54c: r1 = true
    //     0x12fd54c: add             x1, NULL, #0x20  ; true
    // 0x12fd550: StoreField: r0->field_b = r1
    //     0x12fd550: stur            w1, [x0, #0xb]
    // 0x12fd554: StoreField: r0->field_f = r1
    //     0x12fd554: stur            w1, [x0, #0xf]
    // 0x12fd558: ldur            x1, [fp, #-0x20]
    // 0x12fd55c: StoreField: r0->field_13 = r1
    //     0x12fd55c: stur            w1, [x0, #0x13]
    // 0x12fd560: ldur            x1, [fp, #-8]
    // 0x12fd564: ArrayStore: r0[0] = r1  ; List_4
    //     0x12fd564: stur            w1, [x0, #0x17]
    // 0x12fd568: r1 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0x12fd568: add             x1, PP, #0x18, lsl #12  ; [pp+0x18158] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x7f2adac1b19c)
    //     0x12fd56c: ldr             x1, [x1, #0x158]
    // 0x12fd570: StoreField: r0->field_1b = r1
    //     0x12fd570: stur            w1, [x0, #0x1b]
    // 0x12fd574: ldur            x1, [fp, #-0x10]
    // 0x12fd578: StoreField: r0->field_1f = r1
    //     0x12fd578: stur            w1, [x0, #0x1f]
    // 0x12fd57c: LeaveFrame
    //     0x12fd57c: mov             SP, fp
    //     0x12fd580: ldp             fp, lr, [SP], #0x10
    // 0x12fd584: ret
    //     0x12fd584: ret             
    // 0x12fd588: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fd588: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fd58c: b               #0x12fd470
  }
  _ getPlatform(/* No info */) {
    // ** addr: 0x12ff32c, size: 0x3c
    // 0x12ff32c: EnterFrame
    //     0x12ff32c: stp             fp, lr, [SP, #-0x10]!
    //     0x12ff330: mov             fp, SP
    // 0x12ff334: mov             x0, x1
    // 0x12ff338: mov             x1, x2
    // 0x12ff33c: CheckStackOverflow
    //     0x12ff33c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ff340: cmp             SP, x16
    //     0x12ff344: b.ls            #0x12ff360
    // 0x12ff348: r0 = of()
    //     0x12ff348: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x12ff34c: r0 = Instance_TargetPlatform
    //     0x12ff34c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12940] Obj!TargetPlatform@12c5e81
    //     0x12ff350: ldr             x0, [x0, #0x940]
    // 0x12ff354: LeaveFrame
    //     0x12ff354: mov             SP, fp
    //     0x12ff358: ldp             fp, lr, [SP], #0x10
    // 0x12ff35c: ret
    //     0x12ff35c: ret             
    // 0x12ff360: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ff360: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ff364: b               #0x12ff348
  }
}

// class id: 5481, size: 0x18, field offset: 0x14
class _MaterialAppState extends State<dynamic> {

  late HeroController _heroController; // offset: 0x14

  [closure] Widget _materialBuilder(dynamic, BuildContext, Widget?) {
    // ** addr: 0xd5e078, size: 0x40
    // 0xd5e078: EnterFrame
    //     0xd5e078: stp             fp, lr, [SP, #-0x10]!
    //     0xd5e07c: mov             fp, SP
    // 0xd5e080: ldr             x0, [fp, #0x20]
    // 0xd5e084: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd5e084: ldur            w1, [x0, #0x17]
    // 0xd5e088: DecompressPointer r1
    //     0xd5e088: add             x1, x1, HEAP, lsl #32
    // 0xd5e08c: CheckStackOverflow
    //     0xd5e08c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5e090: cmp             SP, x16
    //     0xd5e094: b.ls            #0xd5e0b0
    // 0xd5e098: ldr             x2, [fp, #0x18]
    // 0xd5e09c: ldr             x3, [fp, #0x10]
    // 0xd5e0a0: r0 = _materialBuilder()
    //     0xd5e0a0: bl              #0xd5e0dc  ; [package:flutter/src/material/app.dart] _MaterialAppState::_materialBuilder
    // 0xd5e0a4: LeaveFrame
    //     0xd5e0a4: mov             SP, fp
    //     0xd5e0a8: ldp             fp, lr, [SP], #0x10
    // 0xd5e0ac: ret
    //     0xd5e0ac: ret             
    // 0xd5e0b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5e0b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5e0b4: b               #0xd5e098
  }
  _ _materialBuilder(/* No info */) {
    // ** addr: 0xd5e0dc, size: 0x150
    // 0xd5e0dc: EnterFrame
    //     0xd5e0dc: stp             fp, lr, [SP, #-0x10]!
    //     0xd5e0e0: mov             fp, SP
    // 0xd5e0e4: AllocStack(0x30)
    //     0xd5e0e4: sub             SP, SP, #0x30
    // 0xd5e0e8: SetupParameters(_MaterialAppState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xd5e0e8: stur            x1, [fp, #-8]
    //     0xd5e0ec: stur            x2, [fp, #-0x10]
    //     0xd5e0f0: stur            x3, [fp, #-0x18]
    // 0xd5e0f4: CheckStackOverflow
    //     0xd5e0f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5e0f8: cmp             SP, x16
    //     0xd5e0fc: b.ls            #0xd5e220
    // 0xd5e100: r1 = 2
    //     0xd5e100: mov             x1, #2
    // 0xd5e104: r0 = AllocateContext()
    //     0xd5e104: bl              #0x13de838  ; AllocateContextStub
    // 0xd5e108: mov             x3, x0
    // 0xd5e10c: ldur            x0, [fp, #-8]
    // 0xd5e110: stur            x3, [fp, #-0x20]
    // 0xd5e114: StoreField: r3->field_f = r0
    //     0xd5e114: stur            w0, [x3, #0xf]
    // 0xd5e118: ldur            x1, [fp, #-0x18]
    // 0xd5e11c: StoreField: r3->field_13 = r1
    //     0xd5e11c: stur            w1, [x3, #0x13]
    // 0xd5e120: mov             x1, x0
    // 0xd5e124: ldur            x2, [fp, #-0x10]
    // 0xd5e128: r0 = _themeBuilder()
    //     0xd5e128: bl              #0xd5e238  ; [package:flutter/src/material/app.dart] _MaterialAppState::_themeBuilder
    // 0xd5e12c: stur            x0, [fp, #-0x18]
    // 0xd5e130: LoadField: r1 = r0->field_3f
    //     0xd5e130: ldur            w1, [x0, #0x3f]
    // 0xd5e134: DecompressPointer r1
    //     0xd5e134: add             x1, x1, HEAP, lsl #32
    // 0xd5e138: LoadField: r2 = r1->field_b
    //     0xd5e138: ldur            w2, [x1, #0xb]
    // 0xd5e13c: DecompressPointer r2
    //     0xd5e13c: add             x2, x2, HEAP, lsl #32
    // 0xd5e140: mov             x1, x2
    // 0xd5e144: stur            x2, [fp, #-0x10]
    // 0xd5e148: d0 = 0.400000
    //     0xd5e148: add             x17, PP, #0x13, lsl #12  ; [pp+0x13368] IMM: double(0.4) from 0x3fd999999999999a
    //     0xd5e14c: ldr             d0, [x17, #0x368]
    // 0xd5e150: r0 = withOpacity()
    //     0xd5e150: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd5e154: mov             x3, x0
    // 0xd5e158: ldur            x0, [fp, #-8]
    // 0xd5e15c: stur            x3, [fp, #-0x30]
    // 0xd5e160: LoadField: r4 = r0->field_b
    //     0xd5e160: ldur            w4, [x0, #0xb]
    // 0xd5e164: DecompressPointer r4
    //     0xd5e164: add             x4, x4, HEAP, lsl #32
    // 0xd5e168: stur            x4, [fp, #-0x28]
    // 0xd5e16c: cmp             w4, NULL
    // 0xd5e170: b.eq            #0xd5e228
    // 0xd5e174: ldur            x2, [fp, #-0x20]
    // 0xd5e178: r1 = Function '<anonymous closure>':.
    //     0xd5e178: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c9f8] AnonymousClosure: (0xd5e40c), in [package:flutter/src/material/app.dart] _MaterialAppState::_materialBuilder (0xd5e0dc)
    //     0xd5e17c: ldr             x1, [x1, #0x9f8]
    // 0xd5e180: r0 = AllocateClosure()
    //     0xd5e180: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd5e184: stur            x0, [fp, #-8]
    // 0xd5e188: r0 = Builder()
    //     0xd5e188: bl              #0x858774  ; AllocateBuilderStub -> Builder (size=0x10)
    // 0xd5e18c: mov             x1, x0
    // 0xd5e190: ldur            x0, [fp, #-8]
    // 0xd5e194: stur            x1, [fp, #-0x20]
    // 0xd5e198: StoreField: r1->field_b = r0
    //     0xd5e198: stur            w0, [x1, #0xb]
    // 0xd5e19c: ldur            x0, [fp, #-0x28]
    // 0xd5e1a0: LoadField: r2 = r0->field_f
    //     0xd5e1a0: ldur            w2, [x0, #0xf]
    // 0xd5e1a4: DecompressPointer r2
    //     0xd5e1a4: add             x2, x2, HEAP, lsl #32
    // 0xd5e1a8: stur            x2, [fp, #-8]
    // 0xd5e1ac: r0 = DefaultSelectionStyle()
    //     0xd5e1ac: bl              #0xd20960  ; AllocateDefaultSelectionStyleStub -> DefaultSelectionStyle (size=0x1c)
    // 0xd5e1b0: mov             x1, x0
    // 0xd5e1b4: ldur            x0, [fp, #-0x10]
    // 0xd5e1b8: stur            x1, [fp, #-0x28]
    // 0xd5e1bc: StoreField: r1->field_f = r0
    //     0xd5e1bc: stur            w0, [x1, #0xf]
    // 0xd5e1c0: ldur            x0, [fp, #-0x30]
    // 0xd5e1c4: StoreField: r1->field_13 = r0
    //     0xd5e1c4: stur            w0, [x1, #0x13]
    // 0xd5e1c8: ldur            x0, [fp, #-0x20]
    // 0xd5e1cc: StoreField: r1->field_b = r0
    //     0xd5e1cc: stur            w0, [x1, #0xb]
    // 0xd5e1d0: r0 = ScaffoldMessenger()
    //     0xd5e1d0: bl              #0xd5e22c  ; AllocateScaffoldMessengerStub -> ScaffoldMessenger (size=0x10)
    // 0xd5e1d4: mov             x1, x0
    // 0xd5e1d8: ldur            x0, [fp, #-0x28]
    // 0xd5e1dc: stur            x1, [fp, #-0x10]
    // 0xd5e1e0: StoreField: r1->field_b = r0
    //     0xd5e1e0: stur            w0, [x1, #0xb]
    // 0xd5e1e4: ldur            x0, [fp, #-8]
    // 0xd5e1e8: StoreField: r1->field_7 = r0
    //     0xd5e1e8: stur            w0, [x1, #7]
    // 0xd5e1ec: r0 = AnimatedTheme()
    //     0xd5e1ec: bl              #0xd0deb8  ; AllocateAnimatedThemeStub -> AnimatedTheme (size=0x20)
    // 0xd5e1f0: ldur            x1, [fp, #-0x18]
    // 0xd5e1f4: ArrayStore: r0[0] = r1  ; List_4
    //     0xd5e1f4: stur            w1, [x0, #0x17]
    // 0xd5e1f8: ldur            x1, [fp, #-0x10]
    // 0xd5e1fc: StoreField: r0->field_1b = r1
    //     0xd5e1fc: stur            w1, [x0, #0x1b]
    // 0xd5e200: r1 = Instance__Linear
    //     0xd5e200: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xd5e204: StoreField: r0->field_b = r1
    //     0xd5e204: stur            w1, [x0, #0xb]
    // 0xd5e208: r1 = Instance_Duration
    //     0xd5e208: add             x1, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xd5e20c: ldr             x1, [x1, #0x318]
    // 0xd5e210: StoreField: r0->field_f = r1
    //     0xd5e210: stur            w1, [x0, #0xf]
    // 0xd5e214: LeaveFrame
    //     0xd5e214: mov             SP, fp
    //     0xd5e218: ldp             fp, lr, [SP], #0x10
    // 0xd5e21c: ret
    //     0xd5e21c: ret             
    // 0xd5e220: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5e220: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5e224: b               #0xd5e100
    // 0xd5e228: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5e228: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _themeBuilder(/* No info */) {
    // ** addr: 0xd5e238, size: 0x19c
    // 0xd5e238: EnterFrame
    //     0xd5e238: stp             fp, lr, [SP, #-0x10]!
    //     0xd5e23c: mov             fp, SP
    // 0xd5e240: AllocStack(0x18)
    //     0xd5e240: sub             SP, SP, #0x18
    // 0xd5e244: SetupParameters(_MaterialAppState this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xd5e244: mov             x0, x2
    //     0xd5e248: stur            x2, [fp, #-0x18]
    //     0xd5e24c: mov             x2, x1
    //     0xd5e250: stur            x1, [fp, #-0x10]
    // 0xd5e254: CheckStackOverflow
    //     0xd5e254: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5e258: cmp             SP, x16
    //     0xd5e25c: b.ls            #0xd5e3b8
    // 0xd5e260: LoadField: r1 = r2->field_b
    //     0xd5e260: ldur            w1, [x2, #0xb]
    // 0xd5e264: DecompressPointer r1
    //     0xd5e264: add             x1, x1, HEAP, lsl #32
    // 0xd5e268: cmp             w1, NULL
    // 0xd5e26c: b.eq            #0xd5e3c0
    // 0xd5e270: LoadField: r3 = r1->field_57
    //     0xd5e270: ldur            w3, [x1, #0x57]
    // 0xd5e274: DecompressPointer r3
    //     0xd5e274: add             x3, x3, HEAP, lsl #32
    // 0xd5e278: mov             x1, x0
    // 0xd5e27c: stur            x3, [fp, #-8]
    // 0xd5e280: r0 = platformBrightnessOf()
    //     0xd5e280: bl              #0xd1e560  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::platformBrightnessOf
    // 0xd5e284: mov             x1, x0
    // 0xd5e288: ldur            x0, [fp, #-8]
    // 0xd5e28c: r16 = Instance_ThemeMode
    //     0xd5e28c: add             x16, PP, #8, lsl #12  ; [pp+0x8008] Obj!ThemeMode@12c5aa1
    //     0xd5e290: ldr             x16, [x16, #8]
    // 0xd5e294: cmp             w0, w16
    // 0xd5e298: b.ne            #0xd5e2a4
    // 0xd5e29c: r0 = true
    //     0xd5e29c: add             x0, NULL, #0x20  ; true
    // 0xd5e2a0: b               #0xd5e2d0
    // 0xd5e2a4: r16 = Instance_ThemeMode
    //     0xd5e2a4: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8ca00] Obj!ThemeMode@12c5a81
    //     0xd5e2a8: ldr             x16, [x16, #0xa00]
    // 0xd5e2ac: cmp             w0, w16
    // 0xd5e2b0: b.ne            #0xd5e2cc
    // 0xd5e2b4: r16 = Instance_Brightness
    //     0xd5e2b4: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xd5e2b8: cmp             w1, w16
    // 0xd5e2bc: r16 = true
    //     0xd5e2bc: add             x16, NULL, #0x20  ; true
    // 0xd5e2c0: r17 = false
    //     0xd5e2c0: add             x17, NULL, #0x30  ; false
    // 0xd5e2c4: csel            x0, x16, x17, eq
    // 0xd5e2c8: b               #0xd5e2d0
    // 0xd5e2cc: r0 = false
    //     0xd5e2cc: add             x0, NULL, #0x30  ; false
    // 0xd5e2d0: ldur            x1, [fp, #-0x18]
    // 0xd5e2d4: stur            x0, [fp, #-8]
    // 0xd5e2d8: r0 = highContrastOf()
    //     0xd5e2d8: bl              #0xd5e3d4  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::highContrastOf
    // 0xd5e2dc: mov             x1, x0
    // 0xd5e2e0: ldur            x0, [fp, #-8]
    // 0xd5e2e4: tbnz            w0, #4, #0xd5e30c
    // 0xd5e2e8: tbnz            w1, #4, #0xd5e304
    // 0xd5e2ec: ldur            x2, [fp, #-0x10]
    // 0xd5e2f0: LoadField: r3 = r2->field_b
    //     0xd5e2f0: ldur            w3, [x2, #0xb]
    // 0xd5e2f4: DecompressPointer r3
    //     0xd5e2f4: add             x3, x3, HEAP, lsl #32
    // 0xd5e2f8: cmp             w3, NULL
    // 0xd5e2fc: b.eq            #0xd5e3c4
    // 0xd5e300: b               #0xd5e310
    // 0xd5e304: ldur            x2, [fp, #-0x10]
    // 0xd5e308: b               #0xd5e310
    // 0xd5e30c: ldur            x2, [fp, #-0x10]
    // 0xd5e310: tbnz            w0, #4, #0xd5e334
    // 0xd5e314: LoadField: r0 = r2->field_b
    //     0xd5e314: ldur            w0, [x2, #0xb]
    // 0xd5e318: DecompressPointer r0
    //     0xd5e318: add             x0, x0, HEAP, lsl #32
    // 0xd5e31c: cmp             w0, NULL
    // 0xd5e320: b.eq            #0xd5e3c8
    // 0xd5e324: LoadField: r1 = r0->field_4b
    //     0xd5e324: ldur            w1, [x0, #0x4b]
    // 0xd5e328: DecompressPointer r1
    //     0xd5e328: add             x1, x1, HEAP, lsl #32
    // 0xd5e32c: mov             x0, x1
    // 0xd5e330: b               #0xd5e34c
    // 0xd5e334: tbnz            w1, #4, #0xd5e348
    // 0xd5e338: LoadField: r0 = r2->field_b
    //     0xd5e338: ldur            w0, [x2, #0xb]
    // 0xd5e33c: DecompressPointer r0
    //     0xd5e33c: add             x0, x0, HEAP, lsl #32
    // 0xd5e340: cmp             w0, NULL
    // 0xd5e344: b.eq            #0xd5e3cc
    // 0xd5e348: r0 = Null
    //     0xd5e348: mov             x0, NULL
    // 0xd5e34c: cmp             w0, NULL
    // 0xd5e350: b.ne            #0xd5e370
    // 0xd5e354: LoadField: r0 = r2->field_b
    //     0xd5e354: ldur            w0, [x2, #0xb]
    // 0xd5e358: DecompressPointer r0
    //     0xd5e358: add             x0, x0, HEAP, lsl #32
    // 0xd5e35c: cmp             w0, NULL
    // 0xd5e360: b.eq            #0xd5e3d0
    // 0xd5e364: LoadField: r1 = r0->field_47
    //     0xd5e364: ldur            w1, [x0, #0x47]
    // 0xd5e368: DecompressPointer r1
    //     0xd5e368: add             x1, x1, HEAP, lsl #32
    // 0xd5e36c: mov             x0, x1
    // 0xd5e370: stur            x0, [fp, #-8]
    // 0xd5e374: LoadField: r1 = r0->field_3f
    //     0xd5e374: ldur            w1, [x0, #0x3f]
    // 0xd5e378: DecompressPointer r1
    //     0xd5e378: add             x1, x1, HEAP, lsl #32
    // 0xd5e37c: LoadField: r2 = r1->field_7
    //     0xd5e37c: ldur            w2, [x1, #7]
    // 0xd5e380: DecompressPointer r2
    //     0xd5e380: add             x2, x2, HEAP, lsl #32
    // 0xd5e384: r16 = Instance_Brightness
    //     0xd5e384: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xd5e388: cmp             w2, w16
    // 0xd5e38c: b.ne            #0xd5e39c
    // 0xd5e390: r1 = Instance_SystemUiOverlayStyle
    //     0xd5e390: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8ca08] Obj!SystemUiOverlayStyle@12aa591
    //     0xd5e394: ldr             x1, [x1, #0xa08]
    // 0xd5e398: b               #0xd5e3a4
    // 0xd5e39c: r1 = Instance_SystemUiOverlayStyle
    //     0xd5e39c: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8ca10] Obj!SystemUiOverlayStyle@12aa561
    //     0xd5e3a0: ldr             x1, [x1, #0xa10]
    // 0xd5e3a4: r0 = setSystemUIOverlayStyle()
    //     0xd5e3a4: bl              #0x8991e4  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setSystemUIOverlayStyle
    // 0xd5e3a8: ldur            x0, [fp, #-8]
    // 0xd5e3ac: LeaveFrame
    //     0xd5e3ac: mov             SP, fp
    //     0xd5e3b0: ldp             fp, lr, [SP], #0x10
    // 0xd5e3b4: ret
    //     0xd5e3b4: ret             
    // 0xd5e3b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5e3b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5e3bc: b               #0xd5e260
    // 0xd5e3c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5e3c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd5e3c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5e3c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd5e3c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5e3c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd5e3cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5e3cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd5e3d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5e3d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xd5e40c, size: 0x7c
    // 0xd5e40c: EnterFrame
    //     0xd5e40c: stp             fp, lr, [SP, #-0x10]!
    //     0xd5e410: mov             fp, SP
    // 0xd5e414: ldr             x0, [fp, #0x18]
    // 0xd5e418: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd5e418: ldur            w1, [x0, #0x17]
    // 0xd5e41c: DecompressPointer r1
    //     0xd5e41c: add             x1, x1, HEAP, lsl #32
    // 0xd5e420: CheckStackOverflow
    //     0xd5e420: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5e424: cmp             SP, x16
    //     0xd5e428: b.ls            #0xd5e478
    // 0xd5e42c: LoadField: r0 = r1->field_f
    //     0xd5e42c: ldur            w0, [x1, #0xf]
    // 0xd5e430: DecompressPointer r0
    //     0xd5e430: add             x0, x0, HEAP, lsl #32
    // 0xd5e434: LoadField: r2 = r0->field_b
    //     0xd5e434: ldur            w2, [x0, #0xb]
    // 0xd5e438: DecompressPointer r2
    //     0xd5e438: add             x2, x2, HEAP, lsl #32
    // 0xd5e43c: cmp             w2, NULL
    // 0xd5e440: b.eq            #0xd5e480
    // 0xd5e444: LoadField: r0 = r2->field_3b
    //     0xd5e444: ldur            w0, [x2, #0x3b]
    // 0xd5e448: DecompressPointer r0
    //     0xd5e448: add             x0, x0, HEAP, lsl #32
    // 0xd5e44c: LoadField: r3 = r1->field_13
    //     0xd5e44c: ldur            w3, [x1, #0x13]
    // 0xd5e450: DecompressPointer r3
    //     0xd5e450: add             x3, x3, HEAP, lsl #32
    // 0xd5e454: cmp             w0, NULL
    // 0xd5e458: b.eq            #0xd5e484
    // 0xd5e45c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd5e45c: ldur            w1, [x0, #0x17]
    // 0xd5e460: DecompressPointer r1
    //     0xd5e460: add             x1, x1, HEAP, lsl #32
    // 0xd5e464: ldr             x2, [fp, #0x10]
    // 0xd5e468: r0 = defaultBuilder()
    //     0xd5e468: bl              #0xd5e4c8  ; [package:get/get_navigation/src/root/get_material_app.dart] GetMaterialApp::defaultBuilder
    // 0xd5e46c: LeaveFrame
    //     0xd5e46c: mov             SP, fp
    //     0xd5e470: ldp             fp, lr, [SP], #0x10
    // 0xd5e474: ret
    //     0xd5e474: ret             
    // 0xd5e478: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5e478: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5e47c: b               #0xd5e42c
    // 0xd5e480: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd5e480: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd5e484: r0 = NullErrorSharedWithoutFPURegs()
    //     0xd5e484: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0xde7b8c, size: 0xb4
    // 0xde7b8c: EnterFrame
    //     0xde7b8c: stp             fp, lr, [SP, #-0x10]!
    //     0xde7b90: mov             fp, SP
    // 0xde7b94: AllocStack(0x18)
    //     0xde7b94: sub             SP, SP, #0x18
    // 0xde7b98: SetupParameters(_MaterialAppState this /* r1 => r0, fp-0x8 */)
    //     0xde7b98: mov             x0, x1
    //     0xde7b9c: stur            x1, [fp, #-8]
    // 0xde7ba0: CheckStackOverflow
    //     0xde7ba0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde7ba4: cmp             SP, x16
    //     0xde7ba8: b.ls            #0xde7c28
    // 0xde7bac: mov             x1, x0
    // 0xde7bb0: r0 = _buildWidgetApp()
    //     0xde7bb0: bl              #0xde7c40  ; [package:flutter/src/material/app.dart] _MaterialAppState::_buildWidgetApp
    // 0xde7bb4: mov             x1, x0
    // 0xde7bb8: ldur            x0, [fp, #-8]
    // 0xde7bbc: stur            x1, [fp, #-0x18]
    // 0xde7bc0: LoadField: r2 = r0->field_b
    //     0xde7bc0: ldur            w2, [x0, #0xb]
    // 0xde7bc4: DecompressPointer r2
    //     0xde7bc4: add             x2, x2, HEAP, lsl #32
    // 0xde7bc8: cmp             w2, NULL
    // 0xde7bcc: b.eq            #0xde7c30
    // 0xde7bd0: LoadField: r2 = r0->field_13
    //     0xde7bd0: ldur            w2, [x0, #0x13]
    // 0xde7bd4: DecompressPointer r2
    //     0xde7bd4: add             x2, x2, HEAP, lsl #32
    // 0xde7bd8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde7bdc: cmp             w2, w16
    // 0xde7be0: b.eq            #0xde7c34
    // 0xde7be4: stur            x2, [fp, #-0x10]
    // 0xde7be8: r0 = HeroControllerScope()
    //     0xde7be8: bl              #0xd6cd9c  ; AllocateHeroControllerScopeStub -> HeroControllerScope (size=0x14)
    // 0xde7bec: mov             x1, x0
    // 0xde7bf0: ldur            x0, [fp, #-0x10]
    // 0xde7bf4: stur            x1, [fp, #-8]
    // 0xde7bf8: StoreField: r1->field_f = r0
    //     0xde7bf8: stur            w0, [x1, #0xf]
    // 0xde7bfc: ldur            x0, [fp, #-0x18]
    // 0xde7c00: StoreField: r1->field_b = r0
    //     0xde7c00: stur            w0, [x1, #0xb]
    // 0xde7c04: r0 = ScrollConfiguration()
    //     0xde7c04: bl              #0xde3754  ; AllocateScrollConfigurationStub -> ScrollConfiguration (size=0x14)
    // 0xde7c08: r1 = Instance_MaterialScrollBehavior
    //     0xde7c08: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c9d8] Obj!MaterialScrollBehavior@129ef01
    //     0xde7c0c: ldr             x1, [x1, #0x9d8]
    // 0xde7c10: StoreField: r0->field_f = r1
    //     0xde7c10: stur            w1, [x0, #0xf]
    // 0xde7c14: ldur            x1, [fp, #-8]
    // 0xde7c18: StoreField: r0->field_b = r1
    //     0xde7c18: stur            w1, [x0, #0xb]
    // 0xde7c1c: LeaveFrame
    //     0xde7c1c: mov             SP, fp
    //     0xde7c20: ldp             fp, lr, [SP], #0x10
    // 0xde7c24: ret
    //     0xde7c24: ret             
    // 0xde7c28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde7c28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde7c2c: b               #0xde7bac
    // 0xde7c30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde7c30: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde7c34: r9 = _heroController
    //     0xde7c34: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8c9e0] Field <_MaterialAppState@717125171._heroController@717125171>: late (offset: 0x14)
    //     0xde7c38: ldr             x9, [x9, #0x9e0]
    // 0xde7c3c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xde7c3c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildWidgetApp(/* No info */) {
    // ** addr: 0xde7c40, size: 0x174
    // 0xde7c40: EnterFrame
    //     0xde7c40: stp             fp, lr, [SP, #-0x10]!
    //     0xde7c44: mov             fp, SP
    // 0xde7c48: AllocStack(0x90)
    //     0xde7c48: sub             SP, SP, #0x90
    // 0xde7c4c: SetupParameters(_MaterialAppState this /* r1 => r0, fp-0x10 */)
    //     0xde7c4c: mov             x0, x1
    //     0xde7c50: stur            x1, [fp, #-0x10]
    // 0xde7c54: CheckStackOverflow
    //     0xde7c54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde7c58: cmp             SP, x16
    //     0xde7c5c: b.ls            #0xde7da0
    // 0xde7c60: LoadField: r1 = r0->field_b
    //     0xde7c60: ldur            w1, [x0, #0xb]
    // 0xde7c64: DecompressPointer r1
    //     0xde7c64: add             x1, x1, HEAP, lsl #32
    // 0xde7c68: cmp             w1, NULL
    // 0xde7c6c: b.eq            #0xde7da8
    // 0xde7c70: LoadField: r2 = r1->field_47
    //     0xde7c70: ldur            w2, [x1, #0x47]
    // 0xde7c74: DecompressPointer r2
    //     0xde7c74: add             x2, x2, HEAP, lsl #32
    // 0xde7c78: LoadField: r3 = r2->field_5b
    //     0xde7c78: ldur            w3, [x2, #0x5b]
    // 0xde7c7c: DecompressPointer r3
    //     0xde7c7c: add             x3, x3, HEAP, lsl #32
    // 0xde7c80: mov             x1, x0
    // 0xde7c84: stur            x3, [fp, #-8]
    // 0xde7c88: r0 = tristate()
    //     0xde7c88: bl              #0x11a1528  ; [package:flutter/src/widgets/raw_radio.dart] _RawRadioState::tristate
    // 0xde7c8c: r1 = <State<StatefulWidget>>
    //     0xde7c8c: ldr             x1, [PP, #0x4df8]  ; [pp+0x4df8] TypeArguments: <State<StatefulWidget>>
    // 0xde7c90: r0 = GlobalObjectKey()
    //     0xde7c90: bl              #0xde80d4  ; AllocateGlobalObjectKeyStub -> GlobalObjectKey<X0 bound State> (size=0x10)
    // 0xde7c94: mov             x2, x0
    // 0xde7c98: ldur            x0, [fp, #-0x10]
    // 0xde7c9c: stur            x2, [fp, #-0x48]
    // 0xde7ca0: StoreField: r2->field_b = r0
    //     0xde7ca0: stur            w0, [x2, #0xb]
    // 0xde7ca4: LoadField: r1 = r0->field_b
    //     0xde7ca4: ldur            w1, [x0, #0xb]
    // 0xde7ca8: DecompressPointer r1
    //     0xde7ca8: add             x1, x1, HEAP, lsl #32
    // 0xde7cac: cmp             w1, NULL
    // 0xde7cb0: b.eq            #0xde7dac
    // 0xde7cb4: LoadField: r3 = r1->field_b
    //     0xde7cb4: ldur            w3, [x1, #0xb]
    // 0xde7cb8: DecompressPointer r3
    //     0xde7cb8: add             x3, x3, HEAP, lsl #32
    // 0xde7cbc: stur            x3, [fp, #-0x40]
    // 0xde7cc0: LoadField: r4 = r1->field_2f
    //     0xde7cc0: ldur            w4, [x1, #0x2f]
    // 0xde7cc4: DecompressPointer r4
    //     0xde7cc4: add             x4, x4, HEAP, lsl #32
    // 0xde7cc8: stur            x4, [fp, #-0x38]
    // 0xde7ccc: LoadField: r5 = r1->field_1f
    //     0xde7ccc: ldur            w5, [x1, #0x1f]
    // 0xde7cd0: DecompressPointer r5
    //     0xde7cd0: add             x5, x5, HEAP, lsl #32
    // 0xde7cd4: stur            x5, [fp, #-0x30]
    // 0xde7cd8: LoadField: r6 = r1->field_23
    //     0xde7cd8: ldur            w6, [x1, #0x23]
    // 0xde7cdc: DecompressPointer r6
    //     0xde7cdc: add             x6, x6, HEAP, lsl #32
    // 0xde7ce0: stur            x6, [fp, #-0x28]
    // 0xde7ce4: LoadField: r7 = r1->field_3f
    //     0xde7ce4: ldur            w7, [x1, #0x3f]
    // 0xde7ce8: DecompressPointer r7
    //     0xde7ce8: add             x7, x7, HEAP, lsl #32
    // 0xde7cec: stur            x7, [fp, #-0x20]
    // 0xde7cf0: LoadField: r8 = r1->field_67
    //     0xde7cf0: ldur            w8, [x1, #0x67]
    // 0xde7cf4: DecompressPointer r8
    //     0xde7cf4: add             x8, x8, HEAP, lsl #32
    // 0xde7cf8: mov             x1, x0
    // 0xde7cfc: stur            x8, [fp, #-0x18]
    // 0xde7d00: r0 = _localizationsDelegates()
    //     0xde7d00: bl              #0xde7f98  ; [package:flutter/src/material/app.dart] _MaterialAppState::_localizationsDelegates
    // 0xde7d04: mov             x3, x0
    // 0xde7d08: ldur            x0, [fp, #-0x10]
    // 0xde7d0c: stur            x3, [fp, #-0x50]
    // 0xde7d10: LoadField: r1 = r0->field_b
    //     0xde7d10: ldur            w1, [x0, #0xb]
    // 0xde7d14: DecompressPointer r1
    //     0xde7d14: add             x1, x1, HEAP, lsl #32
    // 0xde7d18: cmp             w1, NULL
    // 0xde7d1c: b.eq            #0xde7db0
    // 0xde7d20: r1 = Function '<anonymous closure>':.
    //     0xde7d20: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c9e8] AnonymousClosure: (0xde80e0), in [package:flutter/src/material/app.dart] _MaterialAppState::_buildWidgetApp (0xde7c40)
    //     0xde7d24: ldr             x1, [x1, #0x9e8]
    // 0xde7d28: r2 = Null
    //     0xde7d28: mov             x2, NULL
    // 0xde7d2c: r0 = AllocateClosureGeneric()
    //     0xde7d2c: bl              #0x13deb28  ; AllocateClosureGenericStub
    // 0xde7d30: ldur            x2, [fp, #-0x10]
    // 0xde7d34: r1 = Function '_materialBuilder@717125171':.
    //     0xde7d34: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c9f0] AnonymousClosure: (0xd5e078), in [package:flutter/src/material/app.dart] _MaterialAppState::_materialBuilder (0xd5e0dc)
    //     0xde7d38: ldr             x1, [x1, #0x9f0]
    // 0xde7d3c: stur            x0, [fp, #-0x10]
    // 0xde7d40: r0 = AllocateClosure()
    //     0xde7d40: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde7d44: stur            x0, [fp, #-0x58]
    // 0xde7d48: r0 = WidgetsApp()
    //     0xde7d48: bl              #0xde7f8c  ; AllocateWidgetsAppStub -> WidgetsApp (size=0x78)
    // 0xde7d4c: stur            x0, [fp, #-0x60]
    // 0xde7d50: ldur            x16, [fp, #-0x40]
    // 0xde7d54: ldur            lr, [fp, #-0x38]
    // 0xde7d58: stp             lr, x16, [SP, #0x20]
    // 0xde7d5c: ldur            x16, [fp, #-0x28]
    // 0xde7d60: ldur            lr, [fp, #-0x30]
    // 0xde7d64: stp             lr, x16, [SP, #0x10]
    // 0xde7d68: ldur            x16, [fp, #-0x10]
    // 0xde7d6c: ldur            lr, [fp, #-0x20]
    // 0xde7d70: stp             lr, x16, [SP]
    // 0xde7d74: mov             x1, x0
    // 0xde7d78: ldur            x2, [fp, #-0x58]
    // 0xde7d7c: ldur            x3, [fp, #-8]
    // 0xde7d80: ldur            x5, [fp, #-0x48]
    // 0xde7d84: ldur            x6, [fp, #-0x18]
    // 0xde7d88: ldur            x7, [fp, #-0x50]
    // 0xde7d8c: r0 = WidgetsApp()
    //     0xde7d8c: bl              #0xde7db4  ; [package:flutter/src/widgets/app.dart] WidgetsApp::WidgetsApp
    // 0xde7d90: ldur            x0, [fp, #-0x60]
    // 0xde7d94: LeaveFrame
    //     0xde7d94: mov             SP, fp
    //     0xde7d98: ldp             fp, lr, [SP], #0x10
    // 0xde7d9c: ret
    //     0xde7d9c: ret             
    // 0xde7da0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde7da0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde7da4: b               #0xde7c60
    // 0xde7da8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde7da8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde7dac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde7dac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde7db0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde7db0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _localizationsDelegates(/* No info */) {
    // ** addr: 0xde7f98, size: 0x118
    // 0xde7f98: EnterFrame
    //     0xde7f98: stp             fp, lr, [SP, #-0x10]!
    //     0xde7f9c: mov             fp, SP
    // 0xde7fa0: AllocStack(0x20)
    //     0xde7fa0: sub             SP, SP, #0x20
    // 0xde7fa4: SetupParameters(_MaterialAppState this /* r1 => r0, fp-0x8 */)
    //     0xde7fa4: mov             x0, x1
    //     0xde7fa8: stur            x1, [fp, #-8]
    // 0xde7fac: CheckStackOverflow
    //     0xde7fac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde7fb0: cmp             SP, x16
    //     0xde7fb4: b.ls            #0xde80a4
    // 0xde7fb8: r1 = <LocalizationsDelegate>
    //     0xde7fb8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28518] TypeArguments: <LocalizationsDelegate>
    //     0xde7fbc: ldr             x1, [x1, #0x518]
    // 0xde7fc0: r2 = 0
    //     0xde7fc0: mov             x2, #0
    // 0xde7fc4: r0 = _GrowableList()
    //     0xde7fc4: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xde7fc8: mov             x3, x0
    // 0xde7fcc: ldur            x0, [fp, #-8]
    // 0xde7fd0: stur            x3, [fp, #-0x10]
    // 0xde7fd4: LoadField: r1 = r0->field_b
    //     0xde7fd4: ldur            w1, [x0, #0xb]
    // 0xde7fd8: DecompressPointer r1
    //     0xde7fd8: add             x1, x1, HEAP, lsl #32
    // 0xde7fdc: cmp             w1, NULL
    // 0xde7fe0: b.eq            #0xde80ac
    // 0xde7fe4: mov             x1, x3
    // 0xde7fe8: r2 = const [Instance of '_MaterialLocalizationsDelegate', Instance of '_WidgetsLocalizationsDelegate', Instance of '_GlobalCupertinoLocalizationsDelegate']
    //     0xde7fe8: add             x2, PP, #0x12, lsl #12  ; [pp+0x127e0] List<LocalizationsDelegate>(3)
    //     0xde7fec: ldr             x2, [x2, #0x7e0]
    // 0xde7ff0: r0 = addAll()
    //     0xde7ff0: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0xde7ff4: ldur            x0, [fp, #-0x10]
    // 0xde7ff8: LoadField: r1 = r0->field_b
    //     0xde7ff8: ldur            w1, [x0, #0xb]
    // 0xde7ffc: LoadField: r2 = r0->field_f
    //     0xde7ffc: ldur            w2, [x0, #0xf]
    // 0xde8000: DecompressPointer r2
    //     0xde8000: add             x2, x2, HEAP, lsl #32
    // 0xde8004: LoadField: r3 = r2->field_b
    //     0xde8004: ldur            w3, [x2, #0xb]
    // 0xde8008: r2 = LoadInt32Instr(r1)
    //     0xde8008: sbfx            x2, x1, #1, #0x1f
    // 0xde800c: stur            x2, [fp, #-0x18]
    // 0xde8010: r1 = LoadInt32Instr(r3)
    //     0xde8010: sbfx            x1, x3, #1, #0x1f
    // 0xde8014: cmp             x2, x1
    // 0xde8018: b.ne            #0xde8024
    // 0xde801c: mov             x1, x0
    // 0xde8020: r0 = _growToNextCapacity()
    //     0xde8020: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xde8024: ldur            x0, [fp, #-0x10]
    // 0xde8028: ldur            x1, [fp, #-0x18]
    // 0xde802c: add             x2, x1, #1
    // 0xde8030: stur            x2, [fp, #-0x20]
    // 0xde8034: lsl             x3, x2, #1
    // 0xde8038: StoreField: r0->field_b = r3
    //     0xde8038: stur            w3, [x0, #0xb]
    // 0xde803c: LoadField: r3 = r0->field_f
    //     0xde803c: ldur            w3, [x0, #0xf]
    // 0xde8040: DecompressPointer r3
    //     0xde8040: add             x3, x3, HEAP, lsl #32
    // 0xde8044: add             x4, x3, x1, lsl #2
    // 0xde8048: r16 = Instance__MaterialLocalizationsDelegate
    //     0xde8048: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8ca28] Obj!_MaterialLocalizationsDelegate@129f381
    //     0xde804c: ldr             x16, [x16, #0xa28]
    // 0xde8050: StoreField: r4->field_f = r16
    //     0xde8050: stur            w16, [x4, #0xf]
    // 0xde8054: LoadField: r1 = r3->field_b
    //     0xde8054: ldur            w1, [x3, #0xb]
    // 0xde8058: r3 = LoadInt32Instr(r1)
    //     0xde8058: sbfx            x3, x1, #1, #0x1f
    // 0xde805c: cmp             x2, x3
    // 0xde8060: b.ne            #0xde806c
    // 0xde8064: mov             x1, x0
    // 0xde8068: r0 = _growToNextCapacity()
    //     0xde8068: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xde806c: ldur            x0, [fp, #-0x10]
    // 0xde8070: ldur            x1, [fp, #-0x20]
    // 0xde8074: add             x2, x1, #1
    // 0xde8078: lsl             x3, x2, #1
    // 0xde807c: StoreField: r0->field_b = r3
    //     0xde807c: stur            w3, [x0, #0xb]
    // 0xde8080: LoadField: r2 = r0->field_f
    //     0xde8080: ldur            w2, [x0, #0xf]
    // 0xde8084: DecompressPointer r2
    //     0xde8084: add             x2, x2, HEAP, lsl #32
    // 0xde8088: add             x3, x2, x1, lsl #2
    // 0xde808c: r16 = Instance__CupertinoLocalizationsDelegate
    //     0xde808c: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8ca30] Obj!_CupertinoLocalizationsDelegate@129f391
    //     0xde8090: ldr             x16, [x16, #0xa30]
    // 0xde8094: StoreField: r3->field_f = r16
    //     0xde8094: stur            w16, [x3, #0xf]
    // 0xde8098: LeaveFrame
    //     0xde8098: mov             SP, fp
    //     0xde809c: ldp             fp, lr, [SP], #0x10
    // 0xde80a0: ret
    //     0xde80a0: ret             
    // 0xde80a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde80a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde80a8: b               #0xde7fb8
    // 0xde80ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde80ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] MaterialPageRoute<Y0> <anonymous closure><Y0>(dynamic, RouteSettings, (dynamic, BuildContext) => Widget) {
    // ** addr: 0xde80e0, size: 0x8c
    // 0xde80e0: EnterFrame
    //     0xde80e0: stp             fp, lr, [SP, #-0x10]!
    //     0xde80e4: mov             fp, SP
    // 0xde80e8: AllocStack(0x10)
    //     0xde80e8: sub             SP, SP, #0x10
    // 0xde80ec: SetupParameters([dynamic _ /* r0 */])
    //     0xde80ec: ldur            w0, [x4, #0xf]
    //     0xde80f0: cbnz            w0, #0xde80fc
    //     0xde80f4: mov             x1, NULL
    //     0xde80f8: b               #0xde8108
    //     0xde80fc: ldur            w0, [x4, #0x17]
    //     0xde8100: add             x1, fp, w0, sxtw #2
    //     0xde8104: ldr             x1, [x1, #0x10]
    //     0xde8108: ldr             x0, [fp, #0x20]
    //     0xde810c: ldur            w2, [x0, #0xf]
    //     0xde8110: add             x2, x2, HEAP, lsl #32
    //     0xde8114: ldr             x16, [THR, #0xb0]  ; THR::empty_type_arguments
    //     0xde8118: cmp             w2, w16
    //     0xde811c: b.eq            #0xde8124
    //     0xde8120: mov             x1, x2
    // 0xde8124: CheckStackOverflow
    //     0xde8124: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde8128: cmp             SP, x16
    //     0xde812c: b.ls            #0xde8164
    // 0xde8130: r0 = MaterialPageRoute()
    //     0xde8130: bl              #0xde8270  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0xde8134: stur            x0, [fp, #-8]
    // 0xde8138: ldr             x16, [fp, #0x18]
    // 0xde813c: str             x16, [SP]
    // 0xde8140: mov             x1, x0
    // 0xde8144: ldr             x2, [fp, #0x10]
    // 0xde8148: r4 = const [0, 0x3, 0x1, 0x2, settings, 0x2, null]
    //     0xde8148: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8ca18] List(7) [0, 0x3, 0x1, 0x2, "settings", 0x2, Null]
    //     0xde814c: ldr             x4, [x4, #0xa18]
    // 0xde8150: r0 = MaterialPageRoute()
    //     0xde8150: bl              #0xde816c  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0xde8154: ldur            x0, [fp, #-8]
    // 0xde8158: LeaveFrame
    //     0xde8158: mov             SP, fp
    //     0xde815c: ldp             fp, lr, [SP], #0x10
    // 0xde8160: ret
    //     0xde8160: ret             
    // 0xde8164: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde8164: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde8168: b               #0xde8130
  }
  _ initState(/* No info */) {
    // ** addr: 0xf8f630, size: 0x58
    // 0xf8f630: EnterFrame
    //     0xf8f630: stp             fp, lr, [SP, #-0x10]!
    //     0xf8f634: mov             fp, SP
    // 0xf8f638: AllocStack(0x8)
    //     0xf8f638: sub             SP, SP, #8
    // 0xf8f63c: SetupParameters(_MaterialAppState this /* r1 => r1, fp-0x8 */)
    //     0xf8f63c: stur            x1, [fp, #-8]
    // 0xf8f640: CheckStackOverflow
    //     0xf8f640: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8f644: cmp             SP, x16
    //     0xf8f648: b.ls            #0xf8f680
    // 0xf8f64c: r0 = createMaterialHeroController()
    //     0xf8f64c: bl              #0xf8f688  ; [package:flutter/src/material/app.dart] MaterialApp::createMaterialHeroController
    // 0xf8f650: ldur            x1, [fp, #-8]
    // 0xf8f654: StoreField: r1->field_13 = r0
    //     0xf8f654: stur            w0, [x1, #0x13]
    //     0xf8f658: ldurb           w16, [x1, #-1]
    //     0xf8f65c: ldurb           w17, [x0, #-1]
    //     0xf8f660: and             x16, x17, x16, lsr #2
    //     0xf8f664: tst             x16, HEAP, lsr #32
    //     0xf8f668: b.eq            #0xf8f670
    //     0xf8f66c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf8f670: r0 = Null
    //     0xf8f670: mov             x0, NULL
    // 0xf8f674: LeaveFrame
    //     0xf8f674: mov             SP, fp
    //     0xf8f678: ldp             fp, lr, [SP], #0x10
    // 0xf8f67c: ret
    //     0xf8f67c: ret             
    // 0xf8f680: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8f680: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8f684: b               #0xf8f64c
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e4b78, size: 0x54
    // 0x10e4b78: EnterFrame
    //     0x10e4b78: stp             fp, lr, [SP, #-0x10]!
    //     0x10e4b7c: mov             fp, SP
    // 0x10e4b80: CheckStackOverflow
    //     0x10e4b80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e4b84: cmp             SP, x16
    //     0x10e4b88: b.ls            #0x10e4bb8
    // 0x10e4b8c: LoadField: r0 = r1->field_13
    //     0x10e4b8c: ldur            w0, [x1, #0x13]
    // 0x10e4b90: DecompressPointer r0
    //     0x10e4b90: add             x0, x0, HEAP, lsl #32
    // 0x10e4b94: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10e4b98: cmp             w0, w16
    // 0x10e4b9c: b.eq            #0x10e4bc0
    // 0x10e4ba0: mov             x1, x0
    // 0x10e4ba4: r0 = dispose()
    //     0x10e4ba4: bl              #0x10e4bcc  ; [package:flutter/src/widgets/heroes.dart] HeroController::dispose
    // 0x10e4ba8: r0 = Null
    //     0x10e4ba8: mov             x0, NULL
    // 0x10e4bac: LeaveFrame
    //     0x10e4bac: mov             SP, fp
    //     0x10e4bb0: ldp             fp, lr, [SP], #0x10
    // 0x10e4bb4: ret
    //     0x10e4bb4: ret             
    // 0x10e4bb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e4bb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e4bbc: b               #0x10e4b8c
    // 0x10e4bc0: r9 = _heroController
    //     0x10e4bc0: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8c9e0] Field <_MaterialAppState@717125171._heroController@717125171>: late (offset: 0x14)
    //     0x10e4bc4: ldr             x9, [x9, #0x9e0]
    // 0x10e4bc8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10e4bc8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 6506, size: 0x9c, field offset: 0xc
//   const constructor, 
class MaterialApp extends StatefulWidget {

  static _ createMaterialHeroController(/* No info */) {
    // ** addr: 0xf8f688, size: 0x74
    // 0xf8f688: EnterFrame
    //     0xf8f688: stp             fp, lr, [SP, #-0x10]!
    //     0xf8f68c: mov             fp, SP
    // 0xf8f690: AllocStack(0x20)
    //     0xf8f690: sub             SP, SP, #0x20
    // 0xf8f694: CheckStackOverflow
    //     0xf8f694: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8f698: cmp             SP, x16
    //     0xf8f69c: b.ls            #0xf8f6f4
    // 0xf8f6a0: r16 = <Object, _HeroFlight>
    //     0xf8f6a0: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cac0] TypeArguments: <Object, _HeroFlight>
    //     0xf8f6a4: ldr             x16, [x16, #0xac0]
    // 0xf8f6a8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xf8f6ac: stp             lr, x16, [SP]
    // 0xf8f6b0: r0 = Map._fromLiteral()
    //     0xf8f6b0: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xf8f6b4: stur            x0, [fp, #-8]
    // 0xf8f6b8: r0 = HeroController()
    //     0xf8f6b8: bl              #0xf8f6fc  ; AllocateHeroControllerStub -> HeroController (size=0x10)
    // 0xf8f6bc: mov             x3, x0
    // 0xf8f6c0: ldur            x0, [fp, #-8]
    // 0xf8f6c4: stur            x3, [fp, #-0x10]
    // 0xf8f6c8: StoreField: r3->field_b = r0
    //     0xf8f6c8: stur            w0, [x3, #0xb]
    // 0xf8f6cc: r1 = Function '<anonymous closure>': static.
    //     0xf8f6cc: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cac8] AnonymousClosure: static (0xf8f708), in [package:flutter/src/material/app.dart] MaterialApp::createMaterialHeroController (0xf8f688)
    //     0xf8f6d0: ldr             x1, [x1, #0xac8]
    // 0xf8f6d4: r2 = Null
    //     0xf8f6d4: mov             x2, NULL
    // 0xf8f6d8: r0 = AllocateClosure()
    //     0xf8f6d8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf8f6dc: mov             x1, x0
    // 0xf8f6e0: ldur            x0, [fp, #-0x10]
    // 0xf8f6e4: StoreField: r0->field_7 = r1
    //     0xf8f6e4: stur            w1, [x0, #7]
    // 0xf8f6e8: LeaveFrame
    //     0xf8f6e8: mov             SP, fp
    //     0xf8f6ec: ldp             fp, lr, [SP], #0x10
    // 0xf8f6f0: ret
    //     0xf8f6f0: ret             
    // 0xf8f6f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8f6f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8f6f8: b               #0xf8f6a0
  }
  [closure] static MaterialRectArcTween <anonymous closure>(dynamic, Rect?, Rect?) {
    // ** addr: 0xf8f708, size: 0x40
    // 0xf8f708: EnterFrame
    //     0xf8f708: stp             fp, lr, [SP, #-0x10]!
    //     0xf8f70c: mov             fp, SP
    // 0xf8f710: r1 = <Rect?>
    //     0xf8f710: ldr             x1, [PP, #0x4db8]  ; [pp+0x4db8] TypeArguments: <Rect?>
    // 0xf8f714: r0 = MaterialRectArcTween()
    //     0xf8f714: bl              #0xf8f748  ; AllocateMaterialRectArcTweenStub -> MaterialRectArcTween (size=0x20)
    // 0xf8f718: r1 = true
    //     0xf8f718: add             x1, NULL, #0x20  ; true
    // 0xf8f71c: StoreField: r0->field_13 = r1
    //     0xf8f71c: stur            w1, [x0, #0x13]
    // 0xf8f720: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xf8f724: ArrayStore: r0[0] = r1  ; List_4
    //     0xf8f724: stur            w1, [x0, #0x17]
    // 0xf8f728: StoreField: r0->field_1b = r1
    //     0xf8f728: stur            w1, [x0, #0x1b]
    // 0xf8f72c: ldr             x1, [fp, #0x18]
    // 0xf8f730: StoreField: r0->field_b = r1
    //     0xf8f730: stur            w1, [x0, #0xb]
    // 0xf8f734: ldr             x1, [fp, #0x10]
    // 0xf8f738: StoreField: r0->field_f = r1
    //     0xf8f738: stur            w1, [x0, #0xf]
    // 0xf8f73c: LeaveFrame
    //     0xf8f73c: mov             SP, fp
    //     0xf8f740: ldp             fp, lr, [SP], #0x10
    // 0xf8f744: ret
    //     0xf8f744: ret             
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa0a20, size: 0x2c
    // 0xfa0a20: EnterFrame
    //     0xfa0a20: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0a24: mov             fp, SP
    // 0xfa0a28: mov             x0, x1
    // 0xfa0a2c: r1 = <MaterialApp>
    //     0xfa0a2c: add             x1, PP, #0x80, lsl #12  ; [pp+0x809c8] TypeArguments: <MaterialApp>
    //     0xfa0a30: ldr             x1, [x1, #0x9c8]
    // 0xfa0a34: r0 = _MaterialAppState()
    //     0xfa0a34: bl              #0xfa0a4c  ; Allocate_MaterialAppStateStub -> _MaterialAppState (size=0x18)
    // 0xfa0a38: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa0a3c: StoreField: r0->field_13 = r1
    //     0xfa0a3c: stur            w1, [x0, #0x13]
    // 0xfa0a40: LeaveFrame
    //     0xfa0a40: mov             SP, fp
    //     0xfa0a44: ldp             fp, lr, [SP], #0x10
    // 0xfa0a48: ret
    //     0xfa0a48: ret             
  }
}

// class id: 8303, size: 0x14, field offset: 0x14
enum ThemeMode extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9c48, size: 0x64
    // 0x11a9c48: EnterFrame
    //     0x11a9c48: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9c4c: mov             fp, SP
    // 0x11a9c50: AllocStack(0x10)
    //     0x11a9c50: sub             SP, SP, #0x10
    // 0x11a9c54: SetupParameters(ThemeMode this /* r1 => r0, fp-0x8 */)
    //     0x11a9c54: mov             x0, x1
    //     0x11a9c58: stur            x1, [fp, #-8]
    // 0x11a9c5c: CheckStackOverflow
    //     0x11a9c5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9c60: cmp             SP, x16
    //     0x11a9c64: b.ls            #0x11a9ca4
    // 0x11a9c68: r1 = Null
    //     0x11a9c68: mov             x1, NULL
    // 0x11a9c6c: r2 = 4
    //     0x11a9c6c: mov             x2, #4
    // 0x11a9c70: r0 = AllocateArray()
    //     0x11a9c70: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9c74: r16 = "ThemeMode."
    //     0x11a9c74: add             x16, PP, #0x10, lsl #12  ; [pp+0x10c60] "ThemeMode."
    //     0x11a9c78: ldr             x16, [x16, #0xc60]
    // 0x11a9c7c: StoreField: r0->field_f = r16
    //     0x11a9c7c: stur            w16, [x0, #0xf]
    // 0x11a9c80: ldur            x1, [fp, #-8]
    // 0x11a9c84: LoadField: r2 = r1->field_f
    //     0x11a9c84: ldur            w2, [x1, #0xf]
    // 0x11a9c88: DecompressPointer r2
    //     0x11a9c88: add             x2, x2, HEAP, lsl #32
    // 0x11a9c8c: StoreField: r0->field_13 = r2
    //     0x11a9c8c: stur            w2, [x0, #0x13]
    // 0x11a9c90: str             x0, [SP]
    // 0x11a9c94: r0 = _interpolate()
    //     0x11a9c94: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9c98: LeaveFrame
    //     0x11a9c98: mov             SP, fp
    //     0x11a9c9c: ldp             fp, lr, [SP], #0x10
    // 0x11a9ca0: ret
    //     0x11a9ca0: ret             
    // 0x11a9ca4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9ca4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9ca8: b               #0x11a9c68
  }
}
