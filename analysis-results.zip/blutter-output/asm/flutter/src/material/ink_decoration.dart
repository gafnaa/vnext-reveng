// lib: , url: package:flutter/src/material/ink_decoration.dart

// class id: 1048900, size: 0x8
class :: {
}

// class id: 3042, size: 0x24, field offset: 0x14
class InkDecoration extends InkFeature {

  set _ configuration=(/* No info */) {
    // ** addr: 0xdf7158, size: 0x94
    // 0xdf7158: EnterFrame
    //     0xdf7158: stp             fp, lr, [SP, #-0x10]!
    //     0xdf715c: mov             fp, SP
    // 0xdf7160: AllocStack(0x20)
    //     0xdf7160: sub             SP, SP, #0x20
    // 0xdf7164: SetupParameters(InkDecoration this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xdf7164: mov             x0, x2
    //     0xdf7168: stur            x1, [fp, #-8]
    //     0xdf716c: stur            x2, [fp, #-0x10]
    // 0xdf7170: CheckStackOverflow
    //     0xdf7170: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf7174: cmp             SP, x16
    //     0xdf7178: b.ls            #0xdf71e4
    // 0xdf717c: LoadField: r2 = r1->field_1f
    //     0xdf717c: ldur            w2, [x1, #0x1f]
    // 0xdf7180: DecompressPointer r2
    //     0xdf7180: add             x2, x2, HEAP, lsl #32
    // 0xdf7184: stp             x2, x0, [SP]
    // 0xdf7188: r0 = ==()
    //     0xdf7188: bl              #0x1299204  ; [package:flutter/src/painting/image_provider.dart] ImageConfiguration::==
    // 0xdf718c: tbnz            w0, #4, #0xdf71a0
    // 0xdf7190: r0 = Null
    //     0xdf7190: mov             x0, NULL
    // 0xdf7194: LeaveFrame
    //     0xdf7194: mov             SP, fp
    //     0xdf7198: ldp             fp, lr, [SP], #0x10
    // 0xdf719c: ret
    //     0xdf719c: ret             
    // 0xdf71a0: ldur            x1, [fp, #-8]
    // 0xdf71a4: ldur            x0, [fp, #-0x10]
    // 0xdf71a8: StoreField: r1->field_1f = r0
    //     0xdf71a8: stur            w0, [x1, #0x1f]
    //     0xdf71ac: ldurb           w16, [x1, #-1]
    //     0xdf71b0: ldurb           w17, [x0, #-1]
    //     0xdf71b4: and             x16, x17, x16, lsr #2
    //     0xdf71b8: tst             x16, HEAP, lsr #32
    //     0xdf71bc: b.eq            #0xdf71c4
    //     0xdf71c0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdf71c4: LoadField: r0 = r1->field_7
    //     0xdf71c4: ldur            w0, [x1, #7]
    // 0xdf71c8: DecompressPointer r0
    //     0xdf71c8: add             x0, x0, HEAP, lsl #32
    // 0xdf71cc: mov             x1, x0
    // 0xdf71d0: r0 = markNeedsPaint()
    //     0xdf71d0: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xdf71d4: r0 = Null
    //     0xdf71d4: mov             x0, NULL
    // 0xdf71d8: LeaveFrame
    //     0xdf71d8: mov             SP, fp
    //     0xdf71dc: ldp             fp, lr, [SP], #0x10
    // 0xdf71e0: ret
    //     0xdf71e0: ret             
    // 0xdf71e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf71e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf71e8: b               #0xdf717c
  }
  set _ isVisible=(/* No info */) {
    // ** addr: 0xdf71ec, size: 0x60
    // 0xdf71ec: EnterFrame
    //     0xdf71ec: stp             fp, lr, [SP, #-0x10]!
    //     0xdf71f0: mov             fp, SP
    // 0xdf71f4: CheckStackOverflow
    //     0xdf71f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf71f8: cmp             SP, x16
    //     0xdf71fc: b.ls            #0xdf7244
    // 0xdf7200: LoadField: r0 = r1->field_1b
    //     0xdf7200: ldur            w0, [x1, #0x1b]
    // 0xdf7204: DecompressPointer r0
    //     0xdf7204: add             x0, x0, HEAP, lsl #32
    // 0xdf7208: cmp             w2, w0
    // 0xdf720c: b.ne            #0xdf7220
    // 0xdf7210: r0 = Null
    //     0xdf7210: mov             x0, NULL
    // 0xdf7214: LeaveFrame
    //     0xdf7214: mov             SP, fp
    //     0xdf7218: ldp             fp, lr, [SP], #0x10
    // 0xdf721c: ret
    //     0xdf721c: ret             
    // 0xdf7220: StoreField: r1->field_1b = r2
    //     0xdf7220: stur            w2, [x1, #0x1b]
    // 0xdf7224: LoadField: r0 = r1->field_7
    //     0xdf7224: ldur            w0, [x1, #7]
    // 0xdf7228: DecompressPointer r0
    //     0xdf7228: add             x0, x0, HEAP, lsl #32
    // 0xdf722c: mov             x1, x0
    // 0xdf7230: r0 = markNeedsPaint()
    //     0xdf7230: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xdf7234: r0 = Null
    //     0xdf7234: mov             x0, NULL
    // 0xdf7238: LeaveFrame
    //     0xdf7238: mov             SP, fp
    //     0xdf723c: ldp             fp, lr, [SP], #0x10
    // 0xdf7240: ret
    //     0xdf7240: ret             
    // 0xdf7244: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf7244: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf7248: b               #0xdf7200
  }
  set _ decoration=(/* No info */) {
    // ** addr: 0xdf724c, size: 0x268
    // 0xdf724c: EnterFrame
    //     0xdf724c: stp             fp, lr, [SP, #-0x10]!
    //     0xdf7250: mov             fp, SP
    // 0xdf7254: AllocStack(0x30)
    //     0xdf7254: sub             SP, SP, #0x30
    // 0xdf7258: SetupParameters(InkDecoration this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xdf7258: stur            x1, [fp, #-8]
    //     0xdf725c: mov             x16, x2
    //     0xdf7260: mov             x2, x1
    //     0xdf7264: mov             x1, x16
    //     0xdf7268: stur            x1, [fp, #-0x10]
    // 0xdf726c: CheckStackOverflow
    //     0xdf726c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf7270: cmp             SP, x16
    //     0xdf7274: b.ls            #0xdf74ac
    // 0xdf7278: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xdf7278: ldur            w0, [x2, #0x17]
    // 0xdf727c: DecompressPointer r0
    //     0xdf727c: add             x0, x0, HEAP, lsl #32
    // 0xdf7280: r3 = LoadClassIdInstr(r1)
    //     0xdf7280: ldur            x3, [x1, #-1]
    //     0xdf7284: ubfx            x3, x3, #0xc, #0x14
    // 0xdf7288: stp             x0, x1, [SP]
    // 0xdf728c: mov             x0, x3
    // 0xdf7290: mov             lr, x0
    // 0xdf7294: ldr             lr, [x21, lr, lsl #3]
    // 0xdf7298: blr             lr
    // 0xdf729c: tbnz            w0, #4, #0xdf72b0
    // 0xdf72a0: r0 = Null
    //     0xdf72a0: mov             x0, NULL
    // 0xdf72a4: LeaveFrame
    //     0xdf72a4: mov             SP, fp
    //     0xdf72a8: ldp             fp, lr, [SP], #0x10
    // 0xdf72ac: ret
    //     0xdf72ac: ret             
    // 0xdf72b0: ldur            x2, [fp, #-8]
    // 0xdf72b4: ldur            x0, [fp, #-0x10]
    // 0xdf72b8: ArrayStore: r2[0] = r0  ; List_4
    //     0xdf72b8: stur            w0, [x2, #0x17]
    //     0xdf72bc: ldurb           w16, [x2, #-1]
    //     0xdf72c0: ldurb           w17, [x0, #-1]
    //     0xdf72c4: and             x16, x17, x16, lsr #2
    //     0xdf72c8: tst             x16, HEAP, lsr #32
    //     0xdf72cc: b.eq            #0xdf72d4
    //     0xdf72d0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xdf72d4: LoadField: r0 = r2->field_13
    //     0xdf72d4: ldur            w0, [x2, #0x13]
    // 0xdf72d8: DecompressPointer r0
    //     0xdf72d8: add             x0, x0, HEAP, lsl #32
    // 0xdf72dc: cmp             w0, NULL
    // 0xdf72e0: b.ne            #0xdf72ec
    // 0xdf72e4: mov             x0, x2
    // 0xdf72e8: b               #0xdf7358
    // 0xdf72ec: r1 = LoadClassIdInstr(r0)
    //     0xdf72ec: ldur            x1, [x0, #-1]
    //     0xdf72f0: ubfx            x1, x1, #0xc, #0x14
    // 0xdf72f4: sub             x16, x1, #0xcbb
    // 0xdf72f8: cmp             x16, #1
    // 0xdf72fc: b.ls            #0xdf7354
    // 0xdf7300: cmp             x1, #0xcb9
    // 0xdf7304: b.ne            #0xdf7330
    // 0xdf7308: LoadField: r1 = r0->field_33
    //     0xdf7308: ldur            w1, [x0, #0x33]
    // 0xdf730c: DecompressPointer r1
    //     0xdf730c: add             x1, x1, HEAP, lsl #32
    // 0xdf7310: cmp             w1, NULL
    // 0xdf7314: b.eq            #0xdf7354
    // 0xdf7318: r0 = LoadClassIdInstr(r1)
    //     0xdf7318: ldur            x0, [x1, #-1]
    //     0xdf731c: ubfx            x0, x0, #0xc, #0x14
    // 0xdf7320: r0 = GDT[cid_x0 + -0xfb9]()
    //     0xdf7320: sub             lr, x0, #0xfb9
    //     0xdf7324: ldr             lr, [x21, lr, lsl #3]
    //     0xdf7328: blr             lr
    // 0xdf732c: b               #0xdf7354
    // 0xdf7330: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf7330: ldur            w1, [x0, #0x17]
    // 0xdf7334: DecompressPointer r1
    //     0xdf7334: add             x1, x1, HEAP, lsl #32
    // 0xdf7338: cmp             w1, NULL
    // 0xdf733c: b.eq            #0xdf7354
    // 0xdf7340: r0 = LoadClassIdInstr(r1)
    //     0xdf7340: ldur            x0, [x1, #-1]
    //     0xdf7344: ubfx            x0, x0, #0xc, #0x14
    // 0xdf7348: r0 = GDT[cid_x0 + -0xfb9]()
    //     0xdf7348: sub             lr, x0, #0xfb9
    //     0xdf734c: ldr             lr, [x21, lr, lsl #3]
    //     0xdf7350: blr             lr
    // 0xdf7354: ldur            x0, [fp, #-8]
    // 0xdf7358: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xdf7358: ldur            w3, [x0, #0x17]
    // 0xdf735c: DecompressPointer r3
    //     0xdf735c: add             x3, x3, HEAP, lsl #32
    // 0xdf7360: stur            x3, [fp, #-0x10]
    // 0xdf7364: cmp             w3, NULL
    // 0xdf7368: b.ne            #0xdf7378
    // 0xdf736c: mov             x1, x0
    // 0xdf7370: r0 = Null
    //     0xdf7370: mov             x0, NULL
    // 0xdf7374: b               #0xdf7470
    // 0xdf7378: mov             x2, x0
    // 0xdf737c: r1 = Function '_handleChanged@517412529':.
    //     0xdf737c: add             x1, PP, #0x97, lsl #12  ; [pp+0x97680] AnonymousClosure: (0xdf74b4), in [package:flutter/src/material/ink_decoration.dart] InkDecoration::_handleChanged (0xdf74ec)
    //     0xdf7380: ldr             x1, [x1, #0x680]
    // 0xdf7384: r0 = AllocateClosure()
    //     0xdf7384: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf7388: mov             x1, x0
    // 0xdf738c: ldur            x0, [fp, #-0x10]
    // 0xdf7390: stur            x1, [fp, #-0x18]
    // 0xdf7394: r2 = LoadClassIdInstr(r0)
    //     0xdf7394: ldur            x2, [x0, #-1]
    //     0xdf7398: ubfx            x2, x2, #0xc, #0x14
    // 0xdf739c: r17 = 5237
    //     0xdf739c: mov             x17, #0x1475
    // 0xdf73a0: cmp             x2, x17
    // 0xdf73a4: b.ne            #0xdf73dc
    // 0xdf73a8: r0 = _ShapeDecorationPainter()
    //     0xdf73a8: bl              #0xb7a684  ; Allocate_ShapeDecorationPainterStub -> _ShapeDecorationPainter (size=0x38)
    // 0xdf73ac: mov             x1, x0
    // 0xdf73b0: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf73b4: ArrayStore: r1[0] = r0  ; List_4
    //     0xdf73b4: stur            w0, [x1, #0x17]
    // 0xdf73b8: StoreField: r1->field_27 = r0
    //     0xdf73b8: stur            w0, [x1, #0x27]
    // 0xdf73bc: StoreField: r1->field_2b = r0
    //     0xdf73bc: stur            w0, [x1, #0x2b]
    // 0xdf73c0: StoreField: r1->field_2f = r0
    //     0xdf73c0: stur            w0, [x1, #0x2f]
    // 0xdf73c4: ldur            x0, [fp, #-0x10]
    // 0xdf73c8: StoreField: r1->field_b = r0
    //     0xdf73c8: stur            w0, [x1, #0xb]
    // 0xdf73cc: ldur            x3, [fp, #-0x18]
    // 0xdf73d0: StoreField: r1->field_7 = r3
    //     0xdf73d0: stur            w3, [x1, #7]
    // 0xdf73d4: mov             x0, x1
    // 0xdf73d8: b               #0xdf746c
    // 0xdf73dc: mov             x3, x1
    // 0xdf73e0: r17 = 5238
    //     0xdf73e0: mov             x17, #0x1476
    // 0xdf73e4: cmp             x2, x17
    // 0xdf73e8: b.ne            #0xdf740c
    // 0xdf73ec: r0 = _BoxDecorationPainter()
    //     0xdf73ec: bl              #0xb7a678  ; Allocate_BoxDecorationPainterStub -> _BoxDecorationPainter (size=0x1c)
    // 0xdf73f0: mov             x1, x0
    // 0xdf73f4: ldur            x0, [fp, #-0x10]
    // 0xdf73f8: StoreField: r1->field_b = r0
    //     0xdf73f8: stur            w0, [x1, #0xb]
    // 0xdf73fc: ldur            x3, [fp, #-0x18]
    // 0xdf7400: StoreField: r1->field_7 = r3
    //     0xdf7400: stur            w3, [x1, #7]
    // 0xdf7404: mov             x0, x1
    // 0xdf7408: b               #0xdf746c
    // 0xdf740c: r17 = 5239
    //     0xdf740c: mov             x17, #0x1477
    // 0xdf7410: cmp             x2, x17
    // 0xdf7414: b.ne            #0xdf744c
    // 0xdf7418: LoadField: r1 = r0->field_7
    //     0xdf7418: ldur            w1, [x0, #7]
    // 0xdf741c: DecompressPointer r1
    //     0xdf741c: add             x1, x1, HEAP, lsl #32
    // 0xdf7420: stur            x1, [fp, #-0x20]
    // 0xdf7424: r0 = _UnderlinePainter()
    //     0xdf7424: bl              #0xb7a66c  ; Allocate_UnderlinePainterStub -> _UnderlinePainter (size=0x14)
    // 0xdf7428: mov             x1, x0
    // 0xdf742c: ldur            x0, [fp, #-0x10]
    // 0xdf7430: StoreField: r1->field_b = r0
    //     0xdf7430: stur            w0, [x1, #0xb]
    // 0xdf7434: ldur            x0, [fp, #-0x20]
    // 0xdf7438: StoreField: r1->field_f = r0
    //     0xdf7438: stur            w0, [x1, #0xf]
    // 0xdf743c: ldur            x2, [fp, #-0x18]
    // 0xdf7440: StoreField: r1->field_7 = r2
    //     0xdf7440: stur            w2, [x1, #7]
    // 0xdf7444: mov             x0, x1
    // 0xdf7448: b               #0xdf746c
    // 0xdf744c: mov             x2, x3
    // 0xdf7450: r0 = _CupertinoEdgeShadowPainter()
    //     0xdf7450: bl              #0xb7a660  ; Allocate_CupertinoEdgeShadowPainterStub -> _CupertinoEdgeShadowPainter (size=0x10)
    // 0xdf7454: mov             x1, x0
    // 0xdf7458: ldur            x0, [fp, #-0x10]
    // 0xdf745c: StoreField: r1->field_b = r0
    //     0xdf745c: stur            w0, [x1, #0xb]
    // 0xdf7460: ldur            x0, [fp, #-0x18]
    // 0xdf7464: StoreField: r1->field_7 = r0
    //     0xdf7464: stur            w0, [x1, #7]
    // 0xdf7468: mov             x0, x1
    // 0xdf746c: ldur            x1, [fp, #-8]
    // 0xdf7470: StoreField: r1->field_13 = r0
    //     0xdf7470: stur            w0, [x1, #0x13]
    //     0xdf7474: ldurb           w16, [x1, #-1]
    //     0xdf7478: ldurb           w17, [x0, #-1]
    //     0xdf747c: and             x16, x17, x16, lsr #2
    //     0xdf7480: tst             x16, HEAP, lsr #32
    //     0xdf7484: b.eq            #0xdf748c
    //     0xdf7488: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdf748c: LoadField: r0 = r1->field_7
    //     0xdf748c: ldur            w0, [x1, #7]
    // 0xdf7490: DecompressPointer r0
    //     0xdf7490: add             x0, x0, HEAP, lsl #32
    // 0xdf7494: mov             x1, x0
    // 0xdf7498: r0 = markNeedsPaint()
    //     0xdf7498: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xdf749c: r0 = Null
    //     0xdf749c: mov             x0, NULL
    // 0xdf74a0: LeaveFrame
    //     0xdf74a0: mov             SP, fp
    //     0xdf74a4: ldp             fp, lr, [SP], #0x10
    // 0xdf74a8: ret
    //     0xdf74a8: ret             
    // 0xdf74ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf74ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf74b0: b               #0xdf7278
  }
  [closure] void _handleChanged(dynamic) {
    // ** addr: 0xdf74b4, size: 0x38
    // 0xdf74b4: EnterFrame
    //     0xdf74b4: stp             fp, lr, [SP, #-0x10]!
    //     0xdf74b8: mov             fp, SP
    // 0xdf74bc: ldr             x0, [fp, #0x10]
    // 0xdf74c0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf74c0: ldur            w1, [x0, #0x17]
    // 0xdf74c4: DecompressPointer r1
    //     0xdf74c4: add             x1, x1, HEAP, lsl #32
    // 0xdf74c8: CheckStackOverflow
    //     0xdf74c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf74cc: cmp             SP, x16
    //     0xdf74d0: b.ls            #0xdf74e4
    // 0xdf74d4: r0 = _handleChanged()
    //     0xdf74d4: bl              #0xdf74ec  ; [package:flutter/src/material/ink_decoration.dart] InkDecoration::_handleChanged
    // 0xdf74d8: LeaveFrame
    //     0xdf74d8: mov             SP, fp
    //     0xdf74dc: ldp             fp, lr, [SP], #0x10
    // 0xdf74e0: ret
    //     0xdf74e0: ret             
    // 0xdf74e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf74e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf74e8: b               #0xdf74d4
  }
  _ _handleChanged(/* No info */) {
    // ** addr: 0xdf74ec, size: 0x3c
    // 0xdf74ec: EnterFrame
    //     0xdf74ec: stp             fp, lr, [SP, #-0x10]!
    //     0xdf74f0: mov             fp, SP
    // 0xdf74f4: CheckStackOverflow
    //     0xdf74f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf74f8: cmp             SP, x16
    //     0xdf74fc: b.ls            #0xdf7520
    // 0xdf7500: LoadField: r0 = r1->field_7
    //     0xdf7500: ldur            w0, [x1, #7]
    // 0xdf7504: DecompressPointer r0
    //     0xdf7504: add             x0, x0, HEAP, lsl #32
    // 0xdf7508: mov             x1, x0
    // 0xdf750c: r0 = markNeedsPaint()
    //     0xdf750c: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xdf7510: r0 = Null
    //     0xdf7510: mov             x0, NULL
    // 0xdf7514: LeaveFrame
    //     0xdf7514: mov             SP, fp
    //     0xdf7518: ldp             fp, lr, [SP], #0x10
    // 0xdf751c: ret
    //     0xdf751c: ret             
    // 0xdf7520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf7520: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf7524: b               #0xdf7500
  }
  _ InkDecoration(/* No info */) {
    // ** addr: 0xdf7528, size: 0x10c
    // 0xdf7528: EnterFrame
    //     0xdf7528: stp             fp, lr, [SP, #-0x10]!
    //     0xdf752c: mov             fp, SP
    // 0xdf7530: AllocStack(0x18)
    //     0xdf7530: sub             SP, SP, #0x18
    // 0xdf7534: r0 = true
    //     0xdf7534: add             x0, NULL, #0x20  ; true
    // 0xdf7538: mov             x4, x2
    // 0xdf753c: mov             x2, x5
    // 0xdf7540: mov             x5, x1
    // 0xdf7544: stur            x1, [fp, #-8]
    // 0xdf7548: mov             x1, x7
    // 0xdf754c: stur            x3, [fp, #-0x10]
    // 0xdf7550: stur            x6, [fp, #-0x18]
    // 0xdf7554: CheckStackOverflow
    //     0xdf7554: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf7558: cmp             SP, x16
    //     0xdf755c: b.ls            #0xdf762c
    // 0xdf7560: StoreField: r5->field_1b = r0
    //     0xdf7560: stur            w0, [x5, #0x1b]
    // 0xdf7564: mov             x0, x4
    // 0xdf7568: StoreField: r5->field_1f = r0
    //     0xdf7568: stur            w0, [x5, #0x1f]
    //     0xdf756c: ldurb           w16, [x5, #-1]
    //     0xdf7570: ldurb           w17, [x0, #-1]
    //     0xdf7574: and             x16, x17, x16, lsr #2
    //     0xdf7578: tst             x16, HEAP, lsr #32
    //     0xdf757c: b.eq            #0xdf7584
    //     0xdf7580: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xdf7584: ldr             x0, [fp, #0x10]
    // 0xdf7588: StoreField: r5->field_b = r0
    //     0xdf7588: stur            w0, [x5, #0xb]
    //     0xdf758c: ldurb           w16, [x5, #-1]
    //     0xdf7590: ldurb           w17, [x0, #-1]
    //     0xdf7594: and             x16, x17, x16, lsr #2
    //     0xdf7598: tst             x16, HEAP, lsr #32
    //     0xdf759c: b.eq            #0xdf75a4
    //     0xdf75a0: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xdf75a4: mov             x0, x1
    // 0xdf75a8: StoreField: r5->field_f = r0
    //     0xdf75a8: stur            w0, [x5, #0xf]
    //     0xdf75ac: ldurb           w16, [x5, #-1]
    //     0xdf75b0: ldurb           w17, [x0, #-1]
    //     0xdf75b4: and             x16, x17, x16, lsr #2
    //     0xdf75b8: tst             x16, HEAP, lsr #32
    //     0xdf75bc: b.eq            #0xdf75c4
    //     0xdf75c0: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xdf75c4: mov             x0, x3
    // 0xdf75c8: StoreField: r5->field_7 = r0
    //     0xdf75c8: stur            w0, [x5, #7]
    //     0xdf75cc: ldurb           w16, [x5, #-1]
    //     0xdf75d0: ldurb           w17, [x0, #-1]
    //     0xdf75d4: and             x16, x17, x16, lsr #2
    //     0xdf75d8: tst             x16, HEAP, lsr #32
    //     0xdf75dc: b.eq            #0xdf75e4
    //     0xdf75e0: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xdf75e4: mov             x1, x5
    // 0xdf75e8: r0 = decoration=()
    //     0xdf75e8: bl              #0xdf724c  ; [package:flutter/src/material/ink_decoration.dart] InkDecoration::decoration=
    // 0xdf75ec: ldur            x2, [fp, #-8]
    // 0xdf75f0: LoadField: r0 = r2->field_1b
    //     0xdf75f0: ldur            w0, [x2, #0x1b]
    // 0xdf75f4: DecompressPointer r0
    //     0xdf75f4: add             x0, x0, HEAP, lsl #32
    // 0xdf75f8: ldur            x1, [fp, #-0x18]
    // 0xdf75fc: cmp             w1, w0
    // 0xdf7600: b.eq            #0xdf7610
    // 0xdf7604: StoreField: r2->field_1b = r1
    //     0xdf7604: stur            w1, [x2, #0x1b]
    // 0xdf7608: ldur            x1, [fp, #-0x10]
    // 0xdf760c: r0 = markNeedsPaint()
    //     0xdf760c: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xdf7610: ldur            x1, [fp, #-0x10]
    // 0xdf7614: ldur            x2, [fp, #-8]
    // 0xdf7618: r0 = addInkFeature()
    //     0xdf7618: bl              #0xd21c40  ; [package:flutter/src/material/material.dart] _RenderInkFeatures::addInkFeature
    // 0xdf761c: r0 = Null
    //     0xdf761c: mov             x0, NULL
    // 0xdf7620: LeaveFrame
    //     0xdf7620: mov             SP, fp
    //     0xdf7624: ldp             fp, lr, [SP], #0x10
    // 0xdf7628: ret
    //     0xdf7628: ret             
    // 0xdf762c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf762c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf7630: b               #0xdf7560
  }
  _ dispose(/* No info */) {
    // ** addr: 0x119e6ac, size: 0xb8
    // 0x119e6ac: EnterFrame
    //     0x119e6ac: stp             fp, lr, [SP, #-0x10]!
    //     0x119e6b0: mov             fp, SP
    // 0x119e6b4: AllocStack(0x8)
    //     0x119e6b4: sub             SP, SP, #8
    // 0x119e6b8: SetupParameters(InkDecoration this /* r1 => r2, fp-0x8 */)
    //     0x119e6b8: mov             x2, x1
    //     0x119e6bc: stur            x1, [fp, #-8]
    // 0x119e6c0: CheckStackOverflow
    //     0x119e6c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119e6c4: cmp             SP, x16
    //     0x119e6c8: b.ls            #0x119e75c
    // 0x119e6cc: LoadField: r0 = r2->field_13
    //     0x119e6cc: ldur            w0, [x2, #0x13]
    // 0x119e6d0: DecompressPointer r0
    //     0x119e6d0: add             x0, x0, HEAP, lsl #32
    // 0x119e6d4: cmp             w0, NULL
    // 0x119e6d8: b.eq            #0x119e744
    // 0x119e6dc: r1 = LoadClassIdInstr(r0)
    //     0x119e6dc: ldur            x1, [x0, #-1]
    //     0x119e6e0: ubfx            x1, x1, #0xc, #0x14
    // 0x119e6e4: sub             x16, x1, #0xcbb
    // 0x119e6e8: cmp             x16, #1
    // 0x119e6ec: b.ls            #0x119e744
    // 0x119e6f0: cmp             x1, #0xcb9
    // 0x119e6f4: b.ne            #0x119e720
    // 0x119e6f8: LoadField: r1 = r0->field_33
    //     0x119e6f8: ldur            w1, [x0, #0x33]
    // 0x119e6fc: DecompressPointer r1
    //     0x119e6fc: add             x1, x1, HEAP, lsl #32
    // 0x119e700: cmp             w1, NULL
    // 0x119e704: b.eq            #0x119e744
    // 0x119e708: r0 = LoadClassIdInstr(r1)
    //     0x119e708: ldur            x0, [x1, #-1]
    //     0x119e70c: ubfx            x0, x0, #0xc, #0x14
    // 0x119e710: r0 = GDT[cid_x0 + -0xfb9]()
    //     0x119e710: sub             lr, x0, #0xfb9
    //     0x119e714: ldr             lr, [x21, lr, lsl #3]
    //     0x119e718: blr             lr
    // 0x119e71c: b               #0x119e744
    // 0x119e720: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x119e720: ldur            w1, [x0, #0x17]
    // 0x119e724: DecompressPointer r1
    //     0x119e724: add             x1, x1, HEAP, lsl #32
    // 0x119e728: cmp             w1, NULL
    // 0x119e72c: b.eq            #0x119e744
    // 0x119e730: r0 = LoadClassIdInstr(r1)
    //     0x119e730: ldur            x0, [x1, #-1]
    //     0x119e734: ubfx            x0, x0, #0xc, #0x14
    // 0x119e738: r0 = GDT[cid_x0 + -0xfb9]()
    //     0x119e738: sub             lr, x0, #0xfb9
    //     0x119e73c: ldr             lr, [x21, lr, lsl #3]
    //     0x119e740: blr             lr
    // 0x119e744: ldur            x1, [fp, #-8]
    // 0x119e748: r0 = dispose()
    //     0x119e748: bl              #0xf786a8  ; [package:flutter/src/material/material.dart] InkFeature::dispose
    // 0x119e74c: r0 = Null
    //     0x119e74c: mov             x0, NULL
    // 0x119e750: LeaveFrame
    //     0x119e750: mov             SP, fp
    //     0x119e754: ldp             fp, lr, [SP], #0x10
    // 0x119e758: ret
    //     0x119e758: ret             
    // 0x119e75c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119e75c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119e760: b               #0x119e6cc
  }
  _ paintFeature(/* No info */) {
    // ** addr: 0x12da1a0, size: 0x1e8
    // 0x12da1a0: EnterFrame
    //     0x12da1a0: stp             fp, lr, [SP, #-0x10]!
    //     0x12da1a4: mov             fp, SP
    // 0x12da1a8: AllocStack(0x38)
    //     0x12da1a8: sub             SP, SP, #0x38
    // 0x12da1ac: SetupParameters(InkDecoration this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0x12da1ac: mov             x0, x3
    //     0x12da1b0: stur            x3, [fp, #-0x18]
    //     0x12da1b4: mov             x3, x1
    //     0x12da1b8: stur            x1, [fp, #-8]
    //     0x12da1bc: stur            x2, [fp, #-0x10]
    // 0x12da1c0: CheckStackOverflow
    //     0x12da1c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12da1c4: cmp             SP, x16
    //     0x12da1c8: b.ls            #0x12da370
    // 0x12da1cc: LoadField: r1 = r3->field_13
    //     0x12da1cc: ldur            w1, [x3, #0x13]
    // 0x12da1d0: DecompressPointer r1
    //     0x12da1d0: add             x1, x1, HEAP, lsl #32
    // 0x12da1d4: cmp             w1, NULL
    // 0x12da1d8: b.eq            #0x12da1e8
    // 0x12da1dc: LoadField: r1 = r3->field_1b
    //     0x12da1dc: ldur            w1, [x3, #0x1b]
    // 0x12da1e0: DecompressPointer r1
    //     0x12da1e0: add             x1, x1, HEAP, lsl #32
    // 0x12da1e4: tbz             w1, #4, #0x12da1f8
    // 0x12da1e8: r0 = Null
    //     0x12da1e8: mov             x0, NULL
    // 0x12da1ec: LeaveFrame
    //     0x12da1ec: mov             SP, fp
    //     0x12da1f0: ldp             fp, lr, [SP], #0x10
    // 0x12da1f4: ret
    //     0x12da1f4: ret             
    // 0x12da1f8: mov             x1, x0
    // 0x12da1fc: r0 = getAsTranslation()
    //     0x12da1fc: bl              #0xc155c4  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::getAsTranslation
    // 0x12da200: mov             x2, x0
    // 0x12da204: ldur            x0, [fp, #-8]
    // 0x12da208: stur            x2, [fp, #-0x28]
    // 0x12da20c: LoadField: r3 = r0->field_1f
    //     0x12da20c: ldur            w3, [x0, #0x1f]
    // 0x12da210: DecompressPointer r3
    //     0x12da210: add             x3, x3, HEAP, lsl #32
    // 0x12da214: stur            x3, [fp, #-0x20]
    // 0x12da218: LoadField: r1 = r0->field_b
    //     0x12da218: ldur            w1, [x0, #0xb]
    // 0x12da21c: DecompressPointer r1
    //     0x12da21c: add             x1, x1, HEAP, lsl #32
    // 0x12da220: r0 = size()
    //     0x12da220: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x12da224: ldur            x1, [fp, #-0x20]
    // 0x12da228: mov             x2, x0
    // 0x12da22c: r0 = copyWith()
    //     0x12da22c: bl              #0xb6d728  ; [package:flutter/src/painting/image_provider.dart] ImageConfiguration::copyWith
    // 0x12da230: ldur            x3, [fp, #-0x28]
    // 0x12da234: stur            x0, [fp, #-0x20]
    // 0x12da238: cmp             w3, NULL
    // 0x12da23c: b.ne            #0x12da310
    // 0x12da240: ldur            x2, [fp, #-0x10]
    // 0x12da244: LoadField: r1 = r2->field_7
    //     0x12da244: ldur            w1, [x2, #7]
    // 0x12da248: DecompressPointer r1
    //     0x12da248: add             x1, x1, HEAP, lsl #32
    // 0x12da24c: cmp             w1, NULL
    // 0x12da250: b.eq            #0x12da378
    // 0x12da254: LoadField: r3 = r1->field_7
    //     0x12da254: ldur            x3, [x1, #7]
    // 0x12da258: ldr             x1, [x3]
    // 0x12da25c: cbz             x1, #0x12da350
    // 0x12da260: ldur            x3, [fp, #-8]
    // 0x12da264: ldur            x4, [fp, #-0x18]
    // 0x12da268: mov             x5, x1
    // 0x12da26c: stur            x5, [fp, #-0x30]
    // 0x12da270: r1 = <Never>
    //     0x12da270: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12da274: r0 = Pointer()
    //     0x12da274: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12da278: mov             x1, x0
    // 0x12da27c: ldur            x0, [fp, #-0x30]
    // 0x12da280: StoreField: r1->field_7 = r0
    //     0x12da280: stur            x0, [x1, #7]
    // 0x12da284: r0 = _save$Method$FfiNative()
    //     0x12da284: bl              #0xb74adc  ; [dart:ui] _NativeCanvas::_save$Method$FfiNative
    // 0x12da288: ldur            x0, [fp, #-0x18]
    // 0x12da28c: LoadField: r2 = r0->field_7
    //     0x12da28c: ldur            w2, [x0, #7]
    // 0x12da290: DecompressPointer r2
    //     0x12da290: add             x2, x2, HEAP, lsl #32
    // 0x12da294: ldur            x1, [fp, #-0x10]
    // 0x12da298: r0 = transform()
    //     0x12da298: bl              #0xb755c4  ; [dart:ui] _NativeCanvas::transform
    // 0x12da29c: ldur            x0, [fp, #-8]
    // 0x12da2a0: LoadField: r1 = r0->field_13
    //     0x12da2a0: ldur            w1, [x0, #0x13]
    // 0x12da2a4: DecompressPointer r1
    //     0x12da2a4: add             x1, x1, HEAP, lsl #32
    // 0x12da2a8: cmp             w1, NULL
    // 0x12da2ac: b.eq            #0x12da37c
    // 0x12da2b0: r0 = LoadClassIdInstr(r1)
    //     0x12da2b0: ldur            x0, [x1, #-1]
    //     0x12da2b4: ubfx            x0, x0, #0xc, #0x14
    // 0x12da2b8: ldur            x2, [fp, #-0x10]
    // 0x12da2bc: ldur            x5, [fp, #-0x20]
    // 0x12da2c0: r3 = Instance_Offset
    //     0x12da2c0: ldr             x3, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x12da2c4: r0 = GDT[cid_x0 + -0xffc]()
    //     0x12da2c4: sub             lr, x0, #0xffc
    //     0x12da2c8: ldr             lr, [x21, lr, lsl #3]
    //     0x12da2cc: blr             lr
    // 0x12da2d0: ldur            x2, [fp, #-0x10]
    // 0x12da2d4: LoadField: r0 = r2->field_7
    //     0x12da2d4: ldur            w0, [x2, #7]
    // 0x12da2d8: DecompressPointer r0
    //     0x12da2d8: add             x0, x0, HEAP, lsl #32
    // 0x12da2dc: cmp             w0, NULL
    // 0x12da2e0: b.eq            #0x12da380
    // 0x12da2e4: LoadField: r1 = r0->field_7
    //     0x12da2e4: ldur            x1, [x0, #7]
    // 0x12da2e8: ldr             x0, [x1]
    // 0x12da2ec: cbz             x0, #0x12da360
    // 0x12da2f0: stur            x0, [fp, #-0x30]
    // 0x12da2f4: r1 = <Never>
    //     0x12da2f4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12da2f8: r0 = Pointer()
    //     0x12da2f8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12da2fc: mov             x1, x0
    // 0x12da300: ldur            x0, [fp, #-0x30]
    // 0x12da304: StoreField: r1->field_7 = r0
    //     0x12da304: stur            x0, [x1, #7]
    // 0x12da308: r0 = _restore$Method$FfiNative()
    //     0x12da308: bl              #0xb74908  ; [dart:ui] _NativeCanvas::_restore$Method$FfiNative
    // 0x12da30c: b               #0x12da340
    // 0x12da310: ldur            x0, [fp, #-8]
    // 0x12da314: LoadField: r1 = r0->field_13
    //     0x12da314: ldur            w1, [x0, #0x13]
    // 0x12da318: DecompressPointer r1
    //     0x12da318: add             x1, x1, HEAP, lsl #32
    // 0x12da31c: cmp             w1, NULL
    // 0x12da320: b.eq            #0x12da384
    // 0x12da324: r0 = LoadClassIdInstr(r1)
    //     0x12da324: ldur            x0, [x1, #-1]
    //     0x12da328: ubfx            x0, x0, #0xc, #0x14
    // 0x12da32c: ldur            x2, [fp, #-0x10]
    // 0x12da330: ldur            x5, [fp, #-0x20]
    // 0x12da334: r0 = GDT[cid_x0 + -0xffc]()
    //     0x12da334: sub             lr, x0, #0xffc
    //     0x12da338: ldr             lr, [x21, lr, lsl #3]
    //     0x12da33c: blr             lr
    // 0x12da340: r0 = Null
    //     0x12da340: mov             x0, NULL
    // 0x12da344: LeaveFrame
    //     0x12da344: mov             SP, fp
    //     0x12da348: ldp             fp, lr, [SP], #0x10
    // 0x12da34c: ret
    //     0x12da34c: ret             
    // 0x12da350: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12da350: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12da354: str             x16, [SP]
    // 0x12da358: r0 = _throwNew()
    //     0x12da358: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12da35c: brk             #0
    // 0x12da360: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12da360: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12da364: str             x16, [SP]
    // 0x12da368: r0 = _throwNew()
    //     0x12da368: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12da36c: brk             #0
    // 0x12da370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12da370: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12da374: b               #0x12da1cc
    // 0x12da378: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12da378: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12da37c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12da37c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12da380: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12da380: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12da384: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12da384: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5466, size: 0x1c, field offset: 0x14
class _InkState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xdf6c00, size: 0xb8
    // 0xdf6c00: EnterFrame
    //     0xdf6c00: stp             fp, lr, [SP, #-0x10]!
    //     0xdf6c04: mov             fp, SP
    // 0xdf6c08: AllocStack(0x28)
    //     0xdf6c08: sub             SP, SP, #0x28
    // 0xdf6c0c: SetupParameters(_InkState this /* r1 => r0, fp-0x10 */)
    //     0xdf6c0c: mov             x0, x1
    //     0xdf6c10: stur            x1, [fp, #-0x10]
    // 0xdf6c14: CheckStackOverflow
    //     0xdf6c14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf6c18: cmp             SP, x16
    //     0xdf6c1c: b.ls            #0xdf6ca8
    // 0xdf6c20: LoadField: r2 = r0->field_13
    //     0xdf6c20: ldur            w2, [x0, #0x13]
    // 0xdf6c24: DecompressPointer r2
    //     0xdf6c24: add             x2, x2, HEAP, lsl #32
    // 0xdf6c28: stur            x2, [fp, #-8]
    // 0xdf6c2c: LoadField: r1 = r0->field_b
    //     0xdf6c2c: ldur            w1, [x0, #0xb]
    // 0xdf6c30: DecompressPointer r1
    //     0xdf6c30: add             x1, x1, HEAP, lsl #32
    // 0xdf6c34: cmp             w1, NULL
    // 0xdf6c38: b.eq            #0xdf6cb0
    // 0xdf6c3c: r0 = _paddingIncludingDecoration()
    //     0xdf6c3c: bl              #0xdf6cb8  ; [package:flutter/src/material/ink_decoration.dart] Ink::_paddingIncludingDecoration
    // 0xdf6c40: ldur            x2, [fp, #-0x10]
    // 0xdf6c44: r1 = Function '_build@517412529':.
    //     0xdf6c44: add             x1, PP, #0x97, lsl #12  ; [pp+0x97660] AnonymousClosure: (0xdf6f08), in [package:flutter/src/material/ink_decoration.dart] _InkState::_build (0xdf6f44)
    //     0xdf6c48: ldr             x1, [x1, #0x660]
    // 0xdf6c4c: stur            x0, [fp, #-0x18]
    // 0xdf6c50: r0 = AllocateClosure()
    //     0xdf6c50: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf6c54: stur            x0, [fp, #-0x20]
    // 0xdf6c58: r0 = Builder()
    //     0xdf6c58: bl              #0x858774  ; AllocateBuilderStub -> Builder (size=0x10)
    // 0xdf6c5c: mov             x1, x0
    // 0xdf6c60: ldur            x0, [fp, #-0x20]
    // 0xdf6c64: stur            x1, [fp, #-0x28]
    // 0xdf6c68: StoreField: r1->field_b = r0
    //     0xdf6c68: stur            w0, [x1, #0xb]
    // 0xdf6c6c: r0 = Padding()
    //     0xdf6c6c: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xdf6c70: ldur            x1, [fp, #-0x18]
    // 0xdf6c74: StoreField: r0->field_f = r1
    //     0xdf6c74: stur            w1, [x0, #0xf]
    // 0xdf6c78: ldur            x1, [fp, #-0x28]
    // 0xdf6c7c: StoreField: r0->field_b = r1
    //     0xdf6c7c: stur            w1, [x0, #0xb]
    // 0xdf6c80: ldur            x1, [fp, #-8]
    // 0xdf6c84: StoreField: r0->field_7 = r1
    //     0xdf6c84: stur            w1, [x0, #7]
    // 0xdf6c88: ldur            x1, [fp, #-0x10]
    // 0xdf6c8c: LoadField: r2 = r1->field_b
    //     0xdf6c8c: ldur            w2, [x1, #0xb]
    // 0xdf6c90: DecompressPointer r2
    //     0xdf6c90: add             x2, x2, HEAP, lsl #32
    // 0xdf6c94: cmp             w2, NULL
    // 0xdf6c98: b.eq            #0xdf6cb4
    // 0xdf6c9c: LeaveFrame
    //     0xdf6c9c: mov             SP, fp
    //     0xdf6ca0: ldp             fp, lr, [SP], #0x10
    // 0xdf6ca4: ret
    //     0xdf6ca4: ret             
    // 0xdf6ca8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf6ca8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf6cac: b               #0xdf6c20
    // 0xdf6cb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf6cb0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf6cb4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf6cb4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget _build(dynamic, BuildContext) {
    // ** addr: 0xdf6f08, size: 0x3c
    // 0xdf6f08: EnterFrame
    //     0xdf6f08: stp             fp, lr, [SP, #-0x10]!
    //     0xdf6f0c: mov             fp, SP
    // 0xdf6f10: ldr             x0, [fp, #0x18]
    // 0xdf6f14: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf6f14: ldur            w1, [x0, #0x17]
    // 0xdf6f18: DecompressPointer r1
    //     0xdf6f18: add             x1, x1, HEAP, lsl #32
    // 0xdf6f1c: CheckStackOverflow
    //     0xdf6f1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf6f20: cmp             SP, x16
    //     0xdf6f24: b.ls            #0xdf6f3c
    // 0xdf6f28: ldr             x2, [fp, #0x10]
    // 0xdf6f2c: r0 = _build()
    //     0xdf6f2c: bl              #0xdf6f44  ; [package:flutter/src/material/ink_decoration.dart] _InkState::_build
    // 0xdf6f30: LeaveFrame
    //     0xdf6f30: mov             SP, fp
    //     0xdf6f34: ldp             fp, lr, [SP], #0x10
    // 0xdf6f38: ret
    //     0xdf6f38: ret             
    // 0xdf6f3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf6f3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf6f40: b               #0xdf6f28
  }
  _ _build(/* No info */) {
    // ** addr: 0xdf6f44, size: 0x214
    // 0xdf6f44: EnterFrame
    //     0xdf6f44: stp             fp, lr, [SP, #-0x10]!
    //     0xdf6f48: mov             fp, SP
    // 0xdf6f4c: AllocStack(0x50)
    //     0xdf6f4c: sub             SP, SP, #0x50
    // 0xdf6f50: SetupParameters(_InkState this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xdf6f50: mov             x0, x2
    //     0xdf6f54: stur            x2, [fp, #-0x18]
    //     0xdf6f58: mov             x2, x1
    //     0xdf6f5c: stur            x1, [fp, #-0x10]
    // 0xdf6f60: CheckStackOverflow
    //     0xdf6f60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf6f64: cmp             SP, x16
    //     0xdf6f68: b.ls            #0xdf7134
    // 0xdf6f6c: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xdf6f6c: ldur            w1, [x2, #0x17]
    // 0xdf6f70: DecompressPointer r1
    //     0xdf6f70: add             x1, x1, HEAP, lsl #32
    // 0xdf6f74: cmp             w1, NULL
    // 0xdf6f78: b.ne            #0xdf7090
    // 0xdf6f7c: LoadField: r1 = r2->field_b
    //     0xdf6f7c: ldur            w1, [x2, #0xb]
    // 0xdf6f80: DecompressPointer r1
    //     0xdf6f80: add             x1, x1, HEAP, lsl #32
    // 0xdf6f84: cmp             w1, NULL
    // 0xdf6f88: b.eq            #0xdf713c
    // 0xdf6f8c: LoadField: r5 = r1->field_13
    //     0xdf6f8c: ldur            w5, [x1, #0x13]
    // 0xdf6f90: DecompressPointer r5
    //     0xdf6f90: add             x5, x5, HEAP, lsl #32
    // 0xdf6f94: mov             x1, x0
    // 0xdf6f98: stur            x5, [fp, #-8]
    // 0xdf6f9c: r0 = of()
    //     0xdf6f9c: bl              #0xdf7640  ; [package:flutter/src/widgets/visibility.dart] Visibility::of
    // 0xdf6fa0: ldur            x1, [fp, #-0x18]
    // 0xdf6fa4: stur            x0, [fp, #-0x20]
    // 0xdf6fa8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xdf6fa8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xdf6fac: r0 = createLocalImageConfiguration()
    //     0xdf6fac: bl              #0xcf9e34  ; [package:flutter/src/widgets/image.dart] ::createLocalImageConfiguration
    // 0xdf6fb0: ldur            x1, [fp, #-0x18]
    // 0xdf6fb4: stur            x0, [fp, #-0x28]
    // 0xdf6fb8: r0 = of()
    //     0xdf6fb8: bl              #0xd21e38  ; [package:flutter/src/material/material.dart] Material::of
    // 0xdf6fbc: ldur            x2, [fp, #-0x10]
    // 0xdf6fc0: stur            x0, [fp, #-0x30]
    // 0xdf6fc4: LoadField: r1 = r2->field_13
    //     0xdf6fc4: ldur            w1, [x2, #0x13]
    // 0xdf6fc8: DecompressPointer r1
    //     0xdf6fc8: add             x1, x1, HEAP, lsl #32
    // 0xdf6fcc: r0 = _currentElement()
    //     0xdf6fcc: bl              #0x859318  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0xdf6fd0: cmp             w0, NULL
    // 0xdf6fd4: b.eq            #0xdf7140
    // 0xdf6fd8: mov             x1, x0
    // 0xdf6fdc: r0 = findRenderObject()
    //     0xdf6fdc: bl              #0x8418fc  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0xdf6fe0: mov             x3, x0
    // 0xdf6fe4: stur            x3, [fp, #-0x38]
    // 0xdf6fe8: cmp             w3, NULL
    // 0xdf6fec: b.eq            #0xdf7144
    // 0xdf6ff0: mov             x0, x3
    // 0xdf6ff4: r2 = Null
    //     0xdf6ff4: mov             x2, NULL
    // 0xdf6ff8: r1 = Null
    //     0xdf6ff8: mov             x1, NULL
    // 0xdf6ffc: r4 = LoadClassIdInstr(r0)
    //     0xdf6ffc: ldur            x4, [x0, #-1]
    //     0xdf7000: ubfx            x4, x4, #0xc, #0x14
    // 0xdf7004: r17 = -4710
    //     0xdf7004: mov             x17, #-0x1266
    // 0xdf7008: add             x4, x4, x17
    // 0xdf700c: cmp             x4, #0x109
    // 0xdf7010: b.ls            #0xdf7024
    // 0xdf7014: r8 = RenderBox
    //     0xdf7014: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xdf7018: r3 = Null
    //     0xdf7018: add             x3, PP, #0x97, lsl #12  ; [pp+0x97668] Null
    //     0xdf701c: ldr             x3, [x3, #0x668]
    // 0xdf7020: r0 = RenderBox()
    //     0xdf7020: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xdf7024: ldur            x2, [fp, #-0x10]
    // 0xdf7028: r1 = Function '_handleRemoved@517412529':.
    //     0xdf7028: add             x1, PP, #0x97, lsl #12  ; [pp+0x97678] AnonymousClosure: (0xdf77ac), in [package:flutter/src/rendering/object.dart] RenderObject::detach (0xc09564)
    //     0xdf702c: ldr             x1, [x1, #0x678]
    // 0xdf7030: r0 = AllocateClosure()
    //     0xdf7030: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf7034: stur            x0, [fp, #-0x40]
    // 0xdf7038: r0 = InkDecoration()
    //     0xdf7038: bl              #0xdf7634  ; AllocateInkDecorationStub -> InkDecoration (size=0x24)
    // 0xdf703c: stur            x0, [fp, #-0x48]
    // 0xdf7040: ldur            x16, [fp, #-0x38]
    // 0xdf7044: str             x16, [SP]
    // 0xdf7048: mov             x1, x0
    // 0xdf704c: ldur            x2, [fp, #-0x28]
    // 0xdf7050: ldur            x3, [fp, #-0x30]
    // 0xdf7054: ldur            x5, [fp, #-8]
    // 0xdf7058: ldur            x6, [fp, #-0x20]
    // 0xdf705c: ldur            x7, [fp, #-0x40]
    // 0xdf7060: r0 = InkDecoration()
    //     0xdf7060: bl              #0xdf7528  ; [package:flutter/src/material/ink_decoration.dart] InkDecoration::InkDecoration
    // 0xdf7064: ldur            x0, [fp, #-0x48]
    // 0xdf7068: ldur            x3, [fp, #-0x10]
    // 0xdf706c: ArrayStore: r3[0] = r0  ; List_4
    //     0xdf706c: stur            w0, [x3, #0x17]
    //     0xdf7070: ldurb           w16, [x3, #-1]
    //     0xdf7074: ldurb           w17, [x0, #-1]
    //     0xdf7078: and             x16, x17, x16, lsr #2
    //     0xdf707c: tst             x16, HEAP, lsr #32
    //     0xdf7080: b.eq            #0xdf7088
    //     0xdf7084: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xdf7088: mov             x1, x3
    // 0xdf708c: b               #0xdf7110
    // 0xdf7090: mov             x3, x2
    // 0xdf7094: LoadField: r0 = r3->field_b
    //     0xdf7094: ldur            w0, [x3, #0xb]
    // 0xdf7098: DecompressPointer r0
    //     0xdf7098: add             x0, x0, HEAP, lsl #32
    // 0xdf709c: cmp             w0, NULL
    // 0xdf70a0: b.eq            #0xdf7148
    // 0xdf70a4: LoadField: r2 = r0->field_13
    //     0xdf70a4: ldur            w2, [x0, #0x13]
    // 0xdf70a8: DecompressPointer r2
    //     0xdf70a8: add             x2, x2, HEAP, lsl #32
    // 0xdf70ac: r0 = decoration=()
    //     0xdf70ac: bl              #0xdf724c  ; [package:flutter/src/material/ink_decoration.dart] InkDecoration::decoration=
    // 0xdf70b0: ldur            x0, [fp, #-0x10]
    // 0xdf70b4: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xdf70b4: ldur            w2, [x0, #0x17]
    // 0xdf70b8: DecompressPointer r2
    //     0xdf70b8: add             x2, x2, HEAP, lsl #32
    // 0xdf70bc: stur            x2, [fp, #-8]
    // 0xdf70c0: cmp             w2, NULL
    // 0xdf70c4: b.eq            #0xdf714c
    // 0xdf70c8: ldur            x1, [fp, #-0x18]
    // 0xdf70cc: r0 = of()
    //     0xdf70cc: bl              #0xdf7640  ; [package:flutter/src/widgets/visibility.dart] Visibility::of
    // 0xdf70d0: ldur            x1, [fp, #-8]
    // 0xdf70d4: mov             x2, x0
    // 0xdf70d8: r0 = isVisible=()
    //     0xdf70d8: bl              #0xdf71ec  ; [package:flutter/src/material/ink_decoration.dart] InkDecoration::isVisible=
    // 0xdf70dc: ldur            x0, [fp, #-0x10]
    // 0xdf70e0: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xdf70e0: ldur            w2, [x0, #0x17]
    // 0xdf70e4: DecompressPointer r2
    //     0xdf70e4: add             x2, x2, HEAP, lsl #32
    // 0xdf70e8: stur            x2, [fp, #-8]
    // 0xdf70ec: cmp             w2, NULL
    // 0xdf70f0: b.eq            #0xdf7150
    // 0xdf70f4: ldur            x1, [fp, #-0x18]
    // 0xdf70f8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xdf70f8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xdf70fc: r0 = createLocalImageConfiguration()
    //     0xdf70fc: bl              #0xcf9e34  ; [package:flutter/src/widgets/image.dart] ::createLocalImageConfiguration
    // 0xdf7100: ldur            x1, [fp, #-8]
    // 0xdf7104: mov             x2, x0
    // 0xdf7108: r0 = configuration=()
    //     0xdf7108: bl              #0xdf7158  ; [package:flutter/src/material/ink_decoration.dart] InkDecoration::configuration=
    // 0xdf710c: ldur            x1, [fp, #-0x10]
    // 0xdf7110: LoadField: r2 = r1->field_b
    //     0xdf7110: ldur            w2, [x1, #0xb]
    // 0xdf7114: DecompressPointer r2
    //     0xdf7114: add             x2, x2, HEAP, lsl #32
    // 0xdf7118: cmp             w2, NULL
    // 0xdf711c: b.eq            #0xdf7154
    // 0xdf7120: LoadField: r0 = r2->field_b
    //     0xdf7120: ldur            w0, [x2, #0xb]
    // 0xdf7124: DecompressPointer r0
    //     0xdf7124: add             x0, x0, HEAP, lsl #32
    // 0xdf7128: LeaveFrame
    //     0xdf7128: mov             SP, fp
    //     0xdf712c: ldp             fp, lr, [SP], #0x10
    // 0xdf7130: ret
    //     0xdf7130: ret             
    // 0xdf7134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf7134: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf7138: b               #0xdf6f6c
    // 0xdf713c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf713c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf7140: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf7140: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf7144: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf7144: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf7148: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf7148: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf714c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf714c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf7150: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf7150: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf7154: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf7154: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleRemoved(dynamic) {
    // ** addr: 0xdf77ac, size: 0x38
    // 0xdf77ac: EnterFrame
    //     0xdf77ac: stp             fp, lr, [SP, #-0x10]!
    //     0xdf77b0: mov             fp, SP
    // 0xdf77b4: ldr             x0, [fp, #0x10]
    // 0xdf77b8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf77b8: ldur            w1, [x0, #0x17]
    // 0xdf77bc: DecompressPointer r1
    //     0xdf77bc: add             x1, x1, HEAP, lsl #32
    // 0xdf77c0: CheckStackOverflow
    //     0xdf77c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf77c4: cmp             SP, x16
    //     0xdf77c8: b.ls            #0xdf77dc
    // 0xdf77cc: r0 = detach()
    //     0xdf77cc: bl              #0xc09564  ; [package:flutter/src/rendering/object.dart] RenderObject::detach
    // 0xdf77d0: LeaveFrame
    //     0xdf77d0: mov             SP, fp
    //     0xdf77d4: ldp             fp, lr, [SP], #0x10
    // 0xdf77d8: ret
    //     0xdf77d8: ret             
    // 0xdf77dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf77dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf77e0: b               #0xdf77cc
  }
  _ deactivate(/* No info */) {
    // ** addr: 0xf78ac0, size: 0x44
    // 0xf78ac0: EnterFrame
    //     0xf78ac0: stp             fp, lr, [SP, #-0x10]!
    //     0xf78ac4: mov             fp, SP
    // 0xf78ac8: CheckStackOverflow
    //     0xf78ac8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf78acc: cmp             SP, x16
    //     0xf78ad0: b.ls            #0xf78afc
    // 0xf78ad4: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xf78ad4: ldur            w0, [x1, #0x17]
    // 0xf78ad8: DecompressPointer r0
    //     0xf78ad8: add             x0, x0, HEAP, lsl #32
    // 0xf78adc: cmp             w0, NULL
    // 0xf78ae0: b.eq            #0xf78aec
    // 0xf78ae4: mov             x1, x0
    // 0xf78ae8: r0 = dispose()
    //     0xf78ae8: bl              #0x119e6ac  ; [package:flutter/src/material/ink_decoration.dart] InkDecoration::dispose
    // 0xf78aec: r0 = Null
    //     0xf78aec: mov             x0, NULL
    // 0xf78af0: LeaveFrame
    //     0xf78af0: mov             SP, fp
    //     0xf78af4: ldp             fp, lr, [SP], #0x10
    // 0xf78af8: ret
    //     0xf78af8: ret             
    // 0xf78afc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf78afc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf78b00: b               #0xf78ad4
  }
}

// class id: 6474, size: 0x20, field offset: 0xc
class Ink extends StatefulWidget {

  _ Ink(/* No info */) {
    // ** addr: 0xdf1b7c, size: 0x1b0
    // 0xdf1b7c: EnterFrame
    //     0xdf1b7c: stp             fp, lr, [SP, #-0x10]!
    //     0xdf1b80: mov             fp, SP
    // 0xdf1b84: AllocStack(0x10)
    //     0xdf1b84: sub             SP, SP, #0x10
    // 0xdf1b88: SetupParameters(Ink this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r16 */)
    //     0xdf1b88: stur            x1, [fp, #-0x10]
    //     0xdf1b8c: mov             x16, x2
    //     0xdf1b90: mov             x2, x1
    // 0xdf1b94: mov             x1, x16
    // 0xdf1b98: LoadField: r0 = r4->field_13
    //     0xdf1b98: ldur            w0, [x4, #0x13]
    // 0xdf1b9c: LoadField: r3 = r4->field_1f
    //     0xdf1b9c: ldur            w3, [x4, #0x1f]
    // 0xdf1ba0: DecompressPointer r3
    //     0xdf1ba0: add             x3, x3, HEAP, lsl #32
    // 0xdf1ba4: r16 = "color"
    //     0xdf1ba4: ldr             x16, [PP, #0x4a70]  ; [pp+0x4a70] "color"
    // 0xdf1ba8: cmp             w3, w16
    // 0xdf1bac: b.ne            #0xdf1bd0
    // 0xdf1bb0: LoadField: r3 = r4->field_23
    //     0xdf1bb0: ldur            w3, [x4, #0x23]
    // 0xdf1bb4: DecompressPointer r3
    //     0xdf1bb4: add             x3, x3, HEAP, lsl #32
    // 0xdf1bb8: sub             w5, w0, w3
    // 0xdf1bbc: add             x3, fp, w5, sxtw #2
    // 0xdf1bc0: ldr             x3, [x3, #8]
    // 0xdf1bc4: mov             x5, x3
    // 0xdf1bc8: r3 = 1
    //     0xdf1bc8: mov             x3, #1
    // 0xdf1bcc: b               #0xdf1bd8
    // 0xdf1bd0: r5 = Null
    //     0xdf1bd0: mov             x5, NULL
    // 0xdf1bd4: r3 = 0
    //     0xdf1bd4: mov             x3, #0
    // 0xdf1bd8: stur            x5, [fp, #-8]
    // 0xdf1bdc: lsl             x6, x3, #1
    // 0xdf1be0: lsl             w7, w6, #1
    // 0xdf1be4: add             w8, w7, #8
    // 0xdf1be8: ArrayLoad: r9 = r4[r8]  ; Unknown_4
    //     0xdf1be8: add             x16, x4, w8, sxtw #1
    //     0xdf1bec: ldur            w9, [x16, #0xf]
    // 0xdf1bf0: DecompressPointer r9
    //     0xdf1bf0: add             x9, x9, HEAP, lsl #32
    // 0xdf1bf4: r16 = "decoration"
    //     0xdf1bf4: ldr             x16, [PP, #0x4a78]  ; [pp+0x4a78] "decoration"
    // 0xdf1bf8: cmp             w9, w16
    // 0xdf1bfc: b.ne            #0xdf1c30
    // 0xdf1c00: add             w3, w7, #0xa
    // 0xdf1c04: ArrayLoad: r7 = r4[r3]  ; Unknown_4
    //     0xdf1c04: add             x16, x4, w3, sxtw #1
    //     0xdf1c08: ldur            w7, [x16, #0xf]
    // 0xdf1c0c: DecompressPointer r7
    //     0xdf1c0c: add             x7, x7, HEAP, lsl #32
    // 0xdf1c10: sub             w3, w0, w7
    // 0xdf1c14: add             x7, fp, w3, sxtw #2
    // 0xdf1c18: ldr             x7, [x7, #8]
    // 0xdf1c1c: add             w3, w6, #2
    // 0xdf1c20: r6 = LoadInt32Instr(r3)
    //     0xdf1c20: sbfx            x6, x3, #1, #0x1f
    // 0xdf1c24: mov             x3, x6
    // 0xdf1c28: mov             x6, x7
    // 0xdf1c2c: b               #0xdf1c34
    // 0xdf1c30: r6 = Null
    //     0xdf1c30: mov             x6, NULL
    // 0xdf1c34: lsl             x7, x3, #1
    // 0xdf1c38: lsl             w3, w7, #1
    // 0xdf1c3c: add             w7, w3, #8
    // 0xdf1c40: ArrayLoad: r8 = r4[r7]  ; Unknown_4
    //     0xdf1c40: add             x16, x4, w7, sxtw #1
    //     0xdf1c44: ldur            w8, [x16, #0xf]
    // 0xdf1c48: DecompressPointer r8
    //     0xdf1c48: add             x8, x8, HEAP, lsl #32
    // 0xdf1c4c: r16 = "padding"
    //     0xdf1c4c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12838] "padding"
    //     0xdf1c50: ldr             x16, [x16, #0x838]
    // 0xdf1c54: cmp             w8, w16
    // 0xdf1c58: b.ne            #0xdf1c7c
    // 0xdf1c5c: add             w7, w3, #0xa
    // 0xdf1c60: ArrayLoad: r3 = r4[r7]  ; Unknown_4
    //     0xdf1c60: add             x16, x4, w7, sxtw #1
    //     0xdf1c64: ldur            w3, [x16, #0xf]
    // 0xdf1c68: DecompressPointer r3
    //     0xdf1c68: add             x3, x3, HEAP, lsl #32
    // 0xdf1c6c: sub             w4, w0, w3
    // 0xdf1c70: add             x0, fp, w4, sxtw #2
    // 0xdf1c74: ldr             x0, [x0, #8]
    // 0xdf1c78: b               #0xdf1c80
    // 0xdf1c7c: r0 = Null
    //     0xdf1c7c: mov             x0, NULL
    // 0xdf1c80: StoreField: r2->field_f = r0
    //     0xdf1c80: stur            w0, [x2, #0xf]
    //     0xdf1c84: ldurb           w16, [x2, #-1]
    //     0xdf1c88: ldurb           w17, [x0, #-1]
    //     0xdf1c8c: and             x16, x17, x16, lsr #2
    //     0xdf1c90: tst             x16, HEAP, lsr #32
    //     0xdf1c94: b.eq            #0xdf1c9c
    //     0xdf1c98: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xdf1c9c: mov             x0, x1
    // 0xdf1ca0: StoreField: r2->field_b = r0
    //     0xdf1ca0: stur            w0, [x2, #0xb]
    //     0xdf1ca4: ldurb           w16, [x2, #-1]
    //     0xdf1ca8: ldurb           w17, [x0, #-1]
    //     0xdf1cac: and             x16, x17, x16, lsr #2
    //     0xdf1cb0: tst             x16, HEAP, lsr #32
    //     0xdf1cb4: b.eq            #0xdf1cbc
    //     0xdf1cb8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xdf1cbc: cmp             w6, NULL
    // 0xdf1cc0: b.ne            #0xdf1cf8
    // 0xdf1cc4: cmp             w5, NULL
    // 0xdf1cc8: b.eq            #0xdf1cec
    // 0xdf1ccc: r0 = BoxDecoration()
    //     0xdf1ccc: bl              #0x8a721c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xdf1cd0: ldur            x1, [fp, #-8]
    // 0xdf1cd4: StoreField: r0->field_7 = r1
    //     0xdf1cd4: stur            w1, [x0, #7]
    // 0xdf1cd8: r1 = Instance_BoxShape
    //     0xdf1cd8: add             x1, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xdf1cdc: ldr             x1, [x1, #0x1f8]
    // 0xdf1ce0: StoreField: r0->field_23 = r1
    //     0xdf1ce0: stur            w1, [x0, #0x23]
    // 0xdf1ce4: mov             x1, x0
    // 0xdf1ce8: b               #0xdf1cf0
    // 0xdf1cec: r1 = Null
    //     0xdf1cec: mov             x1, NULL
    // 0xdf1cf0: mov             x0, x1
    // 0xdf1cf4: b               #0xdf1cfc
    // 0xdf1cf8: mov             x0, x6
    // 0xdf1cfc: ldur            x1, [fp, #-0x10]
    // 0xdf1d00: StoreField: r1->field_13 = r0
    //     0xdf1d00: stur            w0, [x1, #0x13]
    //     0xdf1d04: ldurb           w16, [x1, #-1]
    //     0xdf1d08: ldurb           w17, [x0, #-1]
    //     0xdf1d0c: and             x16, x17, x16, lsr #2
    //     0xdf1d10: tst             x16, HEAP, lsr #32
    //     0xdf1d14: b.eq            #0xdf1d1c
    //     0xdf1d18: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdf1d1c: r0 = Null
    //     0xdf1d1c: mov             x0, NULL
    // 0xdf1d20: LeaveFrame
    //     0xdf1d20: mov             SP, fp
    //     0xdf1d24: ldp             fp, lr, [SP], #0x10
    // 0xdf1d28: ret
    //     0xdf1d28: ret             
  }
  get _ _paddingIncludingDecoration(/* No info */) {
    // ** addr: 0xdf6cb8, size: 0x250
    // 0xdf6cb8: EnterFrame
    //     0xdf6cb8: stp             fp, lr, [SP, #-0x10]!
    //     0xdf6cbc: mov             fp, SP
    // 0xdf6cc0: AllocStack(0x10)
    //     0xdf6cc0: sub             SP, SP, #0x10
    // 0xdf6cc4: CheckStackOverflow
    //     0xdf6cc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf6cc8: cmp             SP, x16
    //     0xdf6ccc: b.ls            #0xdf6ef8
    // 0xdf6cd0: LoadField: r2 = r1->field_f
    //     0xdf6cd0: ldur            w2, [x1, #0xf]
    // 0xdf6cd4: DecompressPointer r2
    //     0xdf6cd4: add             x2, x2, HEAP, lsl #32
    // 0xdf6cd8: stur            x2, [fp, #-0x10]
    // 0xdf6cdc: LoadField: r3 = r1->field_13
    //     0xdf6cdc: ldur            w3, [x1, #0x13]
    // 0xdf6ce0: DecompressPointer r3
    //     0xdf6ce0: add             x3, x3, HEAP, lsl #32
    // 0xdf6ce4: stur            x3, [fp, #-8]
    // 0xdf6ce8: cmp             w3, NULL
    // 0xdf6cec: b.ne            #0xdf6cf8
    // 0xdf6cf0: r0 = Null
    //     0xdf6cf0: mov             x0, NULL
    // 0xdf6cf4: b               #0xdf6d74
    // 0xdf6cf8: r0 = LoadClassIdInstr(r3)
    //     0xdf6cf8: ldur            x0, [x3, #-1]
    //     0xdf6cfc: ubfx            x0, x0, #0xc, #0x14
    // 0xdf6d00: r17 = -5239
    //     0xdf6d00: mov             x17, #-0x1477
    // 0xdf6d04: add             x16, x0, x17
    // 0xdf6d08: cmp             x16, #1
    // 0xdf6d0c: b.hi            #0xdf6d18
    // 0xdf6d10: r0 = Instance_EdgeInsets
    //     0xdf6d10: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xdf6d14: b               #0xdf6d70
    // 0xdf6d18: r17 = 5237
    //     0xdf6d18: mov             x17, #0x1475
    // 0xdf6d1c: cmp             x0, x17
    // 0xdf6d20: b.ne            #0xdf6d44
    // 0xdf6d24: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xdf6d24: ldur            w1, [x3, #0x17]
    // 0xdf6d28: DecompressPointer r1
    //     0xdf6d28: add             x1, x1, HEAP, lsl #32
    // 0xdf6d2c: r0 = LoadClassIdInstr(r1)
    //     0xdf6d2c: ldur            x0, [x1, #-1]
    //     0xdf6d30: ubfx            x0, x0, #0xc, #0x14
    // 0xdf6d34: r0 = GDT[cid_x0 + -0xee7]()
    //     0xdf6d34: sub             lr, x0, #0xee7
    //     0xdf6d38: ldr             lr, [x21, lr, lsl #3]
    //     0xdf6d3c: blr             lr
    // 0xdf6d40: b               #0xdf6d70
    // 0xdf6d44: mov             x0, x3
    // 0xdf6d48: LoadField: r1 = r0->field_f
    //     0xdf6d48: ldur            w1, [x0, #0xf]
    // 0xdf6d4c: DecompressPointer r1
    //     0xdf6d4c: add             x1, x1, HEAP, lsl #32
    // 0xdf6d50: cmp             w1, NULL
    // 0xdf6d54: b.ne            #0xdf6d60
    // 0xdf6d58: r0 = Null
    //     0xdf6d58: mov             x0, NULL
    // 0xdf6d5c: b               #0xdf6d64
    // 0xdf6d60: r0 = dimensions()
    //     0xdf6d60: bl              #0x12f56c4  ; [package:flutter/src/painting/box_border.dart] Border::dimensions
    // 0xdf6d64: cmp             w0, NULL
    // 0xdf6d68: b.ne            #0xdf6d70
    // 0xdf6d6c: r0 = Instance_EdgeInsets
    //     0xdf6d6c: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xdf6d70: ldur            x2, [fp, #-0x10]
    // 0xdf6d74: cmp             w2, NULL
    // 0xdf6d78: r16 = true
    //     0xdf6d78: add             x16, NULL, #0x20  ; true
    // 0xdf6d7c: r17 = false
    //     0xdf6d7c: add             x17, NULL, #0x30  ; false
    // 0xdf6d80: csel            x1, x16, x17, eq
    // 0xdf6d84: tbnz            w1, #4, #0xdf6db8
    // 0xdf6d88: cmp             w0, NULL
    // 0xdf6d8c: r16 = true
    //     0xdf6d8c: add             x16, NULL, #0x20  ; true
    // 0xdf6d90: r17 = false
    //     0xdf6d90: add             x17, NULL, #0x30  ; false
    // 0xdf6d94: csel            x3, x16, x17, eq
    // 0xdf6d98: tbnz            w3, #4, #0xdf6da4
    // 0xdf6d9c: r0 = Instance_EdgeInsets
    //     0xdf6d9c: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xdf6da0: b               #0xdf6eec
    // 0xdf6da4: mov             x6, x3
    // 0xdf6da8: mov             x4, x0
    // 0xdf6dac: r5 = true
    //     0xdf6dac: add             x5, NULL, #0x20  ; true
    // 0xdf6db0: r3 = true
    //     0xdf6db0: add             x3, NULL, #0x20  ; true
    // 0xdf6db4: b               #0xdf6dc8
    // 0xdf6db8: r6 = Null
    //     0xdf6db8: mov             x6, NULL
    // 0xdf6dbc: r5 = false
    //     0xdf6dbc: add             x5, NULL, #0x30  ; false
    // 0xdf6dc0: r4 = Null
    //     0xdf6dc0: mov             x4, NULL
    // 0xdf6dc4: r3 = false
    //     0xdf6dc4: add             x3, NULL, #0x30  ; false
    // 0xdf6dc8: tbnz            w1, #4, #0xdf6e0c
    // 0xdf6dcc: tbnz            w3, #4, #0xdf6ddc
    // 0xdf6dd0: mov             x3, x4
    // 0xdf6dd4: mov             x1, x4
    // 0xdf6dd8: b               #0xdf6de4
    // 0xdf6ddc: mov             x3, x0
    // 0xdf6de0: mov             x1, x0
    // 0xdf6de4: r4 = LoadClassIdInstr(r3)
    //     0xdf6de4: ldur            x4, [x3, #-1]
    //     0xdf6de8: ubfx            x4, x4, #0xc, #0x14
    // 0xdf6dec: sub             x16, x4, #0xb7a
    // 0xdf6df0: cmp             x16, #2
    // 0xdf6df4: b.hi            #0xdf6e00
    // 0xdf6df8: mov             x0, x1
    // 0xdf6dfc: b               #0xdf6eec
    // 0xdf6e00: mov             x3, x1
    // 0xdf6e04: r1 = true
    //     0xdf6e04: add             x1, NULL, #0x20  ; true
    // 0xdf6e08: b               #0xdf6e14
    // 0xdf6e0c: mov             x1, x3
    // 0xdf6e10: mov             x3, x4
    // 0xdf6e14: r4 = LoadClassIdInstr(r2)
    //     0xdf6e14: ldur            x4, [x2, #-1]
    //     0xdf6e18: ubfx            x4, x4, #0xc, #0x14
    // 0xdf6e1c: sub             x16, x4, #0xb7a
    // 0xdf6e20: cmp             x16, #2
    // 0xdf6e24: b.hi            #0xdf6e54
    // 0xdf6e28: tbnz            w5, #4, #0xdf6e3c
    // 0xdf6e2c: r16 = true
    //     0xdf6e2c: add             x16, NULL, #0x20  ; true
    // 0xdf6e30: cmp             w6, w16
    // 0xdf6e34: b.ne            #0xdf6e54
    // 0xdf6e38: b               #0xdf6e4c
    // 0xdf6e3c: tbnz            w1, #4, #0xdf6e44
    // 0xdf6e40: mov             x0, x3
    // 0xdf6e44: cmp             w0, NULL
    // 0xdf6e48: b.ne            #0xdf6e54
    // 0xdf6e4c: mov             x0, x2
    // 0xdf6e50: b               #0xdf6eec
    // 0xdf6e54: ldur            x0, [fp, #-8]
    // 0xdf6e58: cmp             w2, NULL
    // 0xdf6e5c: b.eq            #0xdf6f00
    // 0xdf6e60: cmp             w0, NULL
    // 0xdf6e64: b.eq            #0xdf6f04
    // 0xdf6e68: r1 = LoadClassIdInstr(r0)
    //     0xdf6e68: ldur            x1, [x0, #-1]
    //     0xdf6e6c: ubfx            x1, x1, #0xc, #0x14
    // 0xdf6e70: r17 = -5239
    //     0xdf6e70: mov             x17, #-0x1477
    // 0xdf6e74: add             x16, x1, x17
    // 0xdf6e78: cmp             x16, #1
    // 0xdf6e7c: b.hi            #0xdf6e88
    // 0xdf6e80: r2 = Instance_EdgeInsets
    //     0xdf6e80: ldr             x2, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xdf6e84: b               #0xdf6ee4
    // 0xdf6e88: r17 = 5237
    //     0xdf6e88: mov             x17, #0x1475
    // 0xdf6e8c: cmp             x1, x17
    // 0xdf6e90: b.ne            #0xdf6eb8
    // 0xdf6e94: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf6e94: ldur            w1, [x0, #0x17]
    // 0xdf6e98: DecompressPointer r1
    //     0xdf6e98: add             x1, x1, HEAP, lsl #32
    // 0xdf6e9c: r0 = LoadClassIdInstr(r1)
    //     0xdf6e9c: ldur            x0, [x1, #-1]
    //     0xdf6ea0: ubfx            x0, x0, #0xc, #0x14
    // 0xdf6ea4: r0 = GDT[cid_x0 + -0xee7]()
    //     0xdf6ea4: sub             lr, x0, #0xee7
    //     0xdf6ea8: ldr             lr, [x21, lr, lsl #3]
    //     0xdf6eac: blr             lr
    // 0xdf6eb0: mov             x2, x0
    // 0xdf6eb4: b               #0xdf6ee4
    // 0xdf6eb8: LoadField: r1 = r0->field_f
    //     0xdf6eb8: ldur            w1, [x0, #0xf]
    // 0xdf6ebc: DecompressPointer r1
    //     0xdf6ebc: add             x1, x1, HEAP, lsl #32
    // 0xdf6ec0: cmp             w1, NULL
    // 0xdf6ec4: b.ne            #0xdf6ed0
    // 0xdf6ec8: r0 = Null
    //     0xdf6ec8: mov             x0, NULL
    // 0xdf6ecc: b               #0xdf6ed4
    // 0xdf6ed0: r0 = dimensions()
    //     0xdf6ed0: bl              #0x12f56c4  ; [package:flutter/src/painting/box_border.dart] Border::dimensions
    // 0xdf6ed4: cmp             w0, NULL
    // 0xdf6ed8: b.ne            #0xdf6ee0
    // 0xdf6edc: r0 = Instance_EdgeInsets
    //     0xdf6edc: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xdf6ee0: mov             x2, x0
    // 0xdf6ee4: ldur            x1, [fp, #-0x10]
    // 0xdf6ee8: r0 = add()
    //     0xdf6ee8: bl              #0x13013c0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::add
    // 0xdf6eec: LeaveFrame
    //     0xdf6eec: mov             SP, fp
    //     0xdf6ef0: ldp             fp, lr, [SP], #0x10
    // 0xdf6ef4: ret
    //     0xdf6ef4: ret             
    // 0xdf6ef8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf6ef8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf6efc: b               #0xdf6cd0
    // 0xdf6f00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf6f00: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf6f04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf6f04: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa1a04, size: 0x40
    // 0xfa1a04: EnterFrame
    //     0xfa1a04: stp             fp, lr, [SP, #-0x10]!
    //     0xfa1a08: mov             fp, SP
    // 0xfa1a0c: AllocStack(0x8)
    //     0xfa1a0c: sub             SP, SP, #8
    // 0xfa1a10: SetupParameters(Ink this /* r1 => r0 */)
    //     0xfa1a10: mov             x0, x1
    // 0xfa1a14: r1 = <Ink>
    //     0xfa1a14: add             x1, PP, #0x8d, lsl #12  ; [pp+0x8d228] TypeArguments: <Ink>
    //     0xfa1a18: ldr             x1, [x1, #0x228]
    // 0xfa1a1c: r0 = _InkState()
    //     0xfa1a1c: bl              #0xfa1a44  ; Allocate_InkStateStub -> _InkState (size=0x1c)
    // 0xfa1a20: r1 = <State<StatefulWidget>>
    //     0xfa1a20: ldr             x1, [PP, #0x4df8]  ; [pp+0x4df8] TypeArguments: <State<StatefulWidget>>
    // 0xfa1a24: stur            x0, [fp, #-8]
    // 0xfa1a28: r0 = LabeledGlobalKey()
    //     0xfa1a28: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa1a2c: mov             x1, x0
    // 0xfa1a30: ldur            x0, [fp, #-8]
    // 0xfa1a34: StoreField: r0->field_13 = r1
    //     0xfa1a34: stur            w1, [x0, #0x13]
    // 0xfa1a38: LeaveFrame
    //     0xfa1a38: mov             SP, fp
    //     0xfa1a3c: ldp             fp, lr, [SP], #0x10
    // 0xfa1a40: ret
    //     0xfa1a40: ret             
  }
}
