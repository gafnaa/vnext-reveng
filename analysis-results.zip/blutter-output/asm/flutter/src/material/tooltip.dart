// lib: , url: package:flutter/src/material/tooltip.dart

// class id: 1048972, size: 0x8
class :: {
}

// class id: 5691, size: 0x28, field offset: 0x1c
class TooltipState extends _MixinApplication127&State&SingleTickerProviderStateMixin {

  late TooltipThemeData _tooltipTheme; // offset: 0x24
  late bool _visible; // offset: 0x20

  _ build(/* No info */) {
    // ** addr: 0xd4abb8, size: 0x5a8
    // 0xd4abb8: EnterFrame
    //     0xd4abb8: stp             fp, lr, [SP, #-0x10]!
    //     0xd4abbc: mov             fp, SP
    // 0xd4abc0: AllocStack(0x58)
    //     0xd4abc0: sub             SP, SP, #0x58
    // 0xd4abc4: SetupParameters(TooltipState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xd4abc4: mov             x0, x1
    //     0xd4abc8: stur            x1, [fp, #-8]
    //     0xd4abcc: mov             x1, x2
    // 0xd4abd0: CheckStackOverflow
    //     0xd4abd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4abd4: cmp             SP, x16
    //     0xd4abd8: b.ls            #0xd4b0fc
    // 0xd4abdc: LoadField: r2 = r0->field_b
    //     0xd4abdc: ldur            w2, [x0, #0xb]
    // 0xd4abe0: DecompressPointer r2
    //     0xd4abe0: add             x2, x2, HEAP, lsl #32
    // 0xd4abe4: cmp             w2, NULL
    // 0xd4abe8: b.eq            #0xd4b104
    // 0xd4abec: LoadField: r3 = r2->field_b
    //     0xd4abec: ldur            w3, [x2, #0xb]
    // 0xd4abf0: DecompressPointer r3
    //     0xd4abf0: add             x3, x3, HEAP, lsl #32
    // 0xd4abf4: cmp             w3, NULL
    // 0xd4abf8: b.eq            #0xd4b0e4
    // 0xd4abfc: LoadField: r4 = r3->field_7
    //     0xd4abfc: ldur            w4, [x3, #7]
    // 0xd4ac00: cbnz            w4, #0xd4ac18
    // 0xd4ac04: LoadField: r0 = r2->field_2f
    //     0xd4ac04: ldur            w0, [x2, #0x2f]
    // 0xd4ac08: DecompressPointer r0
    //     0xd4ac08: add             x0, x0, HEAP, lsl #32
    // 0xd4ac0c: LeaveFrame
    //     0xd4ac0c: mov             SP, fp
    //     0xd4ac10: ldp             fp, lr, [SP], #0x10
    // 0xd4ac14: ret
    //     0xd4ac14: ret             
    // 0xd4ac18: r0 = of()
    //     0xd4ac18: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd4ac1c: LoadField: r1 = r0->field_3f
    //     0xd4ac1c: ldur            w1, [x0, #0x3f]
    // 0xd4ac20: DecompressPointer r1
    //     0xd4ac20: add             x1, x1, HEAP, lsl #32
    // 0xd4ac24: LoadField: r2 = r1->field_7
    //     0xd4ac24: ldur            w2, [x1, #7]
    // 0xd4ac28: DecompressPointer r2
    //     0xd4ac28: add             x2, x2, HEAP, lsl #32
    // 0xd4ac2c: r16 = Instance_Brightness
    //     0xd4ac2c: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xd4ac30: cmp             w2, w16
    // 0xd4ac34: b.ne            #0xd4acf8
    // 0xd4ac38: LoadField: r1 = r0->field_87
    //     0xd4ac38: ldur            w1, [x0, #0x87]
    // 0xd4ac3c: DecompressPointer r1
    //     0xd4ac3c: add             x1, x1, HEAP, lsl #32
    // 0xd4ac40: LoadField: r0 = r1->field_2f
    //     0xd4ac40: ldur            w0, [x1, #0x2f]
    // 0xd4ac44: DecompressPointer r0
    //     0xd4ac44: add             x0, x0, HEAP, lsl #32
    // 0xd4ac48: stur            x0, [fp, #-0x10]
    // 0xd4ac4c: cmp             w0, NULL
    // 0xd4ac50: b.eq            #0xd4b108
    // 0xd4ac54: r0 = _getDefaultFontSize()
    //     0xd4ac54: bl              #0xd4b268  ; [package:flutter/src/material/tooltip.dart] TooltipState::_getDefaultFontSize
    // 0xd4ac58: r0 = inline_Allocate_Double()
    //     0xd4ac58: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd4ac5c: add             x0, x0, #0x10
    //     0xd4ac60: cmp             x1, x0
    //     0xd4ac64: b.ls            #0xd4b10c
    //     0xd4ac68: str             x0, [THR, #0x60]  ; THR::top
    //     0xd4ac6c: sub             x0, x0, #0xf
    //     0xd4ac70: mov             x1, #0xe19c
    //     0xd4ac74: movk            x1, #3, lsl #16
    //     0xd4ac78: stur            x1, [x0, #-1]
    // 0xd4ac7c: dmb             ishst
    // 0xd4ac80: StoreField: r0->field_7 = d0
    //     0xd4ac80: stur            d0, [x0, #7]
    // 0xd4ac84: r16 = Instance_Color
    //     0xd4ac84: add             x16, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0xd4ac88: ldr             x16, [x16, #0x948]
    // 0xd4ac8c: stp             x0, x16, [SP]
    // 0xd4ac90: ldur            x1, [fp, #-0x10]
    // 0xd4ac94: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, fontSize, 0x2, null]
    //     0xd4ac94: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1aea8] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "fontSize", 0x2, Null]
    //     0xd4ac98: ldr             x4, [x4, #0xea8]
    // 0xd4ac9c: r0 = copyWith()
    //     0xd4ac9c: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xd4aca0: r1 = Instance_Color
    //     0xd4aca0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xd4aca4: ldr             x1, [x1, #0xc38]
    // 0xd4aca8: d0 = 0.900000
    //     0xd4aca8: add             x17, PP, #0x12, lsl #12  ; [pp+0x12818] IMM: double(0.9) from 0x3feccccccccccccd
    //     0xd4acac: ldr             d0, [x17, #0x818]
    // 0xd4acb0: stur            x0, [fp, #-0x10]
    // 0xd4acb4: r0 = withOpacity()
    //     0xd4acb4: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd4acb8: stur            x0, [fp, #-0x18]
    // 0xd4acbc: r0 = BoxDecoration()
    //     0xd4acbc: bl              #0x8a721c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xd4acc0: mov             x1, x0
    // 0xd4acc4: ldur            x0, [fp, #-0x18]
    // 0xd4acc8: StoreField: r1->field_7 = r0
    //     0xd4acc8: stur            w0, [x1, #7]
    // 0xd4accc: r3 = Instance_BorderRadius
    //     0xd4accc: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e328] Obj!BorderRadius@129e2f1
    //     0xd4acd0: ldr             x3, [x3, #0x328]
    // 0xd4acd4: StoreField: r1->field_13 = r3
    //     0xd4acd4: stur            w3, [x1, #0x13]
    // 0xd4acd8: r4 = Instance_BoxShape
    //     0xd4acd8: add             x4, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xd4acdc: ldr             x4, [x4, #0x1f8]
    // 0xd4ace0: StoreField: r1->field_23 = r4
    //     0xd4ace0: stur            w4, [x1, #0x23]
    // 0xd4ace4: ldur            x2, [fp, #-0x10]
    // 0xd4ace8: mov             x3, x1
    // 0xd4acec: r0 = AllocateRecord2()
    //     0xd4acec: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xd4acf0: mov             x1, x0
    // 0xd4acf4: b               #0xd4ae04
    // 0xd4acf8: r3 = Instance_BorderRadius
    //     0xd4acf8: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e328] Obj!BorderRadius@129e2f1
    //     0xd4acfc: ldr             x3, [x3, #0x328]
    // 0xd4ad00: r4 = Instance_BoxShape
    //     0xd4ad00: add             x4, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xd4ad04: ldr             x4, [x4, #0x1f8]
    // 0xd4ad08: r16 = Instance_Brightness
    //     0xd4ad08: ldr             x16, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0xd4ad0c: cmp             w2, w16
    // 0xd4ad10: b.ne            #0xd4ae00
    // 0xd4ad14: LoadField: r1 = r0->field_87
    //     0xd4ad14: ldur            w1, [x0, #0x87]
    // 0xd4ad18: DecompressPointer r1
    //     0xd4ad18: add             x1, x1, HEAP, lsl #32
    // 0xd4ad1c: LoadField: r0 = r1->field_2f
    //     0xd4ad1c: ldur            w0, [x1, #0x2f]
    // 0xd4ad20: DecompressPointer r0
    //     0xd4ad20: add             x0, x0, HEAP, lsl #32
    // 0xd4ad24: stur            x0, [fp, #-0x10]
    // 0xd4ad28: cmp             w0, NULL
    // 0xd4ad2c: b.eq            #0xd4b11c
    // 0xd4ad30: r0 = _getDefaultFontSize()
    //     0xd4ad30: bl              #0xd4b268  ; [package:flutter/src/material/tooltip.dart] TooltipState::_getDefaultFontSize
    // 0xd4ad34: r0 = inline_Allocate_Double()
    //     0xd4ad34: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd4ad38: add             x0, x0, #0x10
    //     0xd4ad3c: cmp             x1, x0
    //     0xd4ad40: b.ls            #0xd4b120
    //     0xd4ad44: str             x0, [THR, #0x60]  ; THR::top
    //     0xd4ad48: sub             x0, x0, #0xf
    //     0xd4ad4c: mov             x1, #0xe19c
    //     0xd4ad50: movk            x1, #3, lsl #16
    //     0xd4ad54: stur            x1, [x0, #-1]
    // 0xd4ad58: dmb             ishst
    // 0xd4ad5c: StoreField: r0->field_7 = d0
    //     0xd4ad5c: stur            d0, [x0, #7]
    // 0xd4ad60: r16 = Instance_Color
    //     0xd4ad60: add             x16, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xd4ad64: ldr             x16, [x16, #0xc38]
    // 0xd4ad68: stp             x0, x16, [SP]
    // 0xd4ad6c: ldur            x1, [fp, #-0x10]
    // 0xd4ad70: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, fontSize, 0x2, null]
    //     0xd4ad70: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1aea8] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "fontSize", 0x2, Null]
    //     0xd4ad74: ldr             x4, [x4, #0xea8]
    // 0xd4ad78: r0 = copyWith()
    //     0xd4ad78: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xd4ad7c: r1 = _ConstMap len:12
    //     0xd4ad7c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c20] Map<int, Color>(12)
    //     0xd4ad80: ldr             x1, [x1, #0xc20]
    // 0xd4ad84: r2 = 1400
    //     0xd4ad84: mov             x2, #0x578
    // 0xd4ad88: stur            x0, [fp, #-0x10]
    // 0xd4ad8c: r0 = []()
    //     0xd4ad8c: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0xd4ad90: cmp             w0, NULL
    // 0xd4ad94: b.eq            #0xd4b130
    // 0xd4ad98: r1 = LoadClassIdInstr(r0)
    //     0xd4ad98: ldur            x1, [x0, #-1]
    //     0xd4ad9c: ubfx            x1, x1, #0xc, #0x14
    // 0xd4ada0: mov             x16, x0
    // 0xd4ada4: mov             x0, x1
    // 0xd4ada8: mov             x1, x16
    // 0xd4adac: d0 = 0.900000
    //     0xd4adac: add             x17, PP, #0x12, lsl #12  ; [pp+0x12818] IMM: double(0.9) from 0x3feccccccccccccd
    //     0xd4adb0: ldr             d0, [x17, #0x818]
    // 0xd4adb4: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd4adb4: sub             lr, x0, #1, lsl #12
    //     0xd4adb8: ldr             lr, [x21, lr, lsl #3]
    //     0xd4adbc: blr             lr
    // 0xd4adc0: stur            x0, [fp, #-0x18]
    // 0xd4adc4: r0 = BoxDecoration()
    //     0xd4adc4: bl              #0x8a721c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xd4adc8: mov             x1, x0
    // 0xd4adcc: ldur            x0, [fp, #-0x18]
    // 0xd4add0: StoreField: r1->field_7 = r0
    //     0xd4add0: stur            w0, [x1, #7]
    // 0xd4add4: r0 = Instance_BorderRadius
    //     0xd4add4: add             x0, PP, #0x8e, lsl #12  ; [pp+0x8e328] Obj!BorderRadius@129e2f1
    //     0xd4add8: ldr             x0, [x0, #0x328]
    // 0xd4addc: StoreField: r1->field_13 = r0
    //     0xd4addc: stur            w0, [x1, #0x13]
    // 0xd4ade0: r0 = Instance_BoxShape
    //     0xd4ade0: add             x0, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xd4ade4: ldr             x0, [x0, #0x1f8]
    // 0xd4ade8: StoreField: r1->field_23 = r0
    //     0xd4ade8: stur            w0, [x1, #0x23]
    // 0xd4adec: ldur            x2, [fp, #-0x10]
    // 0xd4adf0: mov             x3, x1
    // 0xd4adf4: r0 = AllocateRecord2()
    //     0xd4adf4: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xd4adf8: mov             x1, x0
    // 0xd4adfc: b               #0xd4ae04
    // 0xd4ae00: r1 = Null
    //     0xd4ae00: mov             x1, NULL
    // 0xd4ae04: ldur            x0, [fp, #-8]
    // 0xd4ae08: LoadField: r2 = r1->field_f
    //     0xd4ae08: ldur            w2, [x1, #0xf]
    // 0xd4ae0c: DecompressPointer r2
    //     0xd4ae0c: add             x2, x2, HEAP, lsl #32
    // 0xd4ae10: stur            x2, [fp, #-0x18]
    // 0xd4ae14: LoadField: r3 = r1->field_13
    //     0xd4ae14: ldur            w3, [x1, #0x13]
    // 0xd4ae18: DecompressPointer r3
    //     0xd4ae18: add             x3, x3, HEAP, lsl #32
    // 0xd4ae1c: stur            x3, [fp, #-0x10]
    // 0xd4ae20: LoadField: r1 = r0->field_b
    //     0xd4ae20: ldur            w1, [x0, #0xb]
    // 0xd4ae24: DecompressPointer r1
    //     0xd4ae24: add             x1, x1, HEAP, lsl #32
    // 0xd4ae28: cmp             w1, NULL
    // 0xd4ae2c: b.eq            #0xd4b134
    // 0xd4ae30: LoadField: r1 = r0->field_23
    //     0xd4ae30: ldur            w1, [x0, #0x23]
    // 0xd4ae34: DecompressPointer r1
    //     0xd4ae34: add             x1, x1, HEAP, lsl #32
    // 0xd4ae38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd4ae3c: cmp             w1, w16
    // 0xd4ae40: b.eq            #0xd4b138
    // 0xd4ae44: LoadField: r4 = r1->field_7
    //     0xd4ae44: ldur            w4, [x1, #7]
    // 0xd4ae48: DecompressPointer r4
    //     0xd4ae48: add             x4, x4, HEAP, lsl #32
    // 0xd4ae4c: cmp             w4, NULL
    // 0xd4ae50: b.ne            #0xd4ae60
    // 0xd4ae54: mov             x1, x0
    // 0xd4ae58: r0 = _getDefaultTooltipHeight()
    //     0xd4ae58: bl              #0xd4b21c  ; [package:flutter/src/material/tooltip.dart] TooltipState::_getDefaultTooltipHeight
    // 0xd4ae5c: b               #0xd4ae64
    // 0xd4ae60: LoadField: d0 = r4->field_7
    //     0xd4ae60: ldur            d0, [x4, #7]
    // 0xd4ae64: ldur            x1, [fp, #-8]
    // 0xd4ae68: ldur            x0, [fp, #-0x18]
    // 0xd4ae6c: ldur            x2, [fp, #-0x10]
    // 0xd4ae70: stur            d0, [fp, #-0x48]
    // 0xd4ae74: r0 = BoxConstraints()
    //     0xd4ae74: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xd4ae78: stur            x0, [fp, #-0x20]
    // 0xd4ae7c: StoreField: r0->field_7 = rZR
    //     0xd4ae7c: stur            xzr, [x0, #7]
    // 0xd4ae80: d0 = inf
    //     0xd4ae80: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xd4ae84: StoreField: r0->field_f = d0
    //     0xd4ae84: stur            d0, [x0, #0xf]
    // 0xd4ae88: ldur            d1, [fp, #-0x48]
    // 0xd4ae8c: ArrayStore: r0[0] = d1  ; List_8
    //     0xd4ae8c: stur            d1, [x0, #0x17]
    // 0xd4ae90: StoreField: r0->field_1f = d0
    //     0xd4ae90: stur            d0, [x0, #0x1f]
    // 0xd4ae94: ldur            x2, [fp, #-8]
    // 0xd4ae98: LoadField: r1 = r2->field_b
    //     0xd4ae98: ldur            w1, [x2, #0xb]
    // 0xd4ae9c: DecompressPointer r1
    //     0xd4ae9c: add             x1, x1, HEAP, lsl #32
    // 0xd4aea0: cmp             w1, NULL
    // 0xd4aea4: b.eq            #0xd4b144
    // 0xd4aea8: mov             x1, x2
    // 0xd4aeac: r0 = _getDefaultPadding()
    //     0xd4aeac: bl              #0xd4b1d0  ; [package:flutter/src/material/tooltip.dart] TooltipState::_getDefaultPadding
    // 0xd4aeb0: ldur            x1, [fp, #-8]
    // 0xd4aeb4: stur            x0, [fp, #-0x38]
    // 0xd4aeb8: LoadField: r2 = r1->field_b
    //     0xd4aeb8: ldur            w2, [x1, #0xb]
    // 0xd4aebc: DecompressPointer r2
    //     0xd4aebc: add             x2, x2, HEAP, lsl #32
    // 0xd4aec0: stur            x2, [fp, #-0x30]
    // 0xd4aec4: cmp             w2, NULL
    // 0xd4aec8: b.eq            #0xd4b148
    // 0xd4aecc: LoadField: r3 = r2->field_b
    //     0xd4aecc: ldur            w3, [x2, #0xb]
    // 0xd4aed0: DecompressPointer r3
    //     0xd4aed0: add             x3, x3, HEAP, lsl #32
    // 0xd4aed4: stur            x3, [fp, #-0x28]
    // 0xd4aed8: r0 = TextSpan()
    //     0xd4aed8: bl              #0xb57880  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0xd4aedc: mov             x1, x0
    // 0xd4aee0: ldur            x0, [fp, #-0x28]
    // 0xd4aee4: stur            x1, [fp, #-0x40]
    // 0xd4aee8: StoreField: r1->field_b = r0
    //     0xd4aee8: stur            w0, [x1, #0xb]
    // 0xd4aeec: r0 = Instance__DeferringMouseCursor
    //     0xd4aeec: ldr             x0, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0xd4aef0: ArrayStore: r1[0] = r0  ; List_4
    //     0xd4aef0: stur            w0, [x1, #0x17]
    // 0xd4aef4: r0 = _TooltipBox()
    //     0xd4aef4: bl              #0xd4b1c4  ; Allocate_TooltipBoxStub -> _TooltipBox (size=0x28)
    // 0xd4aef8: mov             x1, x0
    // 0xd4aefc: ldur            x0, [fp, #-0x20]
    // 0xd4af00: stur            x1, [fp, #-0x28]
    // 0xd4af04: StoreField: r1->field_b = r0
    //     0xd4af04: stur            w0, [x1, #0xb]
    // 0xd4af08: ldur            x0, [fp, #-0x18]
    // 0xd4af0c: StoreField: r1->field_f = r0
    //     0xd4af0c: stur            w0, [x1, #0xf]
    // 0xd4af10: r0 = Instance_TextAlign
    //     0xd4af10: ldr             x0, [PP, #0x4c78]  ; [pp+0x4c78] Obj!TextAlign@12c7541
    // 0xd4af14: StoreField: r1->field_13 = r0
    //     0xd4af14: stur            w0, [x1, #0x13]
    // 0xd4af18: ldur            x0, [fp, #-0x10]
    // 0xd4af1c: ArrayStore: r1[0] = r0  ; List_4
    //     0xd4af1c: stur            w0, [x1, #0x17]
    // 0xd4af20: ldur            x0, [fp, #-0x38]
    // 0xd4af24: StoreField: r1->field_1b = r0
    //     0xd4af24: stur            w0, [x1, #0x1b]
    // 0xd4af28: r0 = Instance_EdgeInsets
    //     0xd4af28: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xd4af2c: StoreField: r1->field_1f = r0
    //     0xd4af2c: stur            w0, [x1, #0x1f]
    // 0xd4af30: ldur            x0, [fp, #-0x40]
    // 0xd4af34: StoreField: r1->field_23 = r0
    //     0xd4af34: stur            w0, [x1, #0x23]
    // 0xd4af38: r1 = 1
    //     0xd4af38: mov             x1, #1
    // 0xd4af3c: r0 = AllocateContext()
    //     0xd4af3c: bl              #0x13de838  ; AllocateContextStub
    // 0xd4af40: mov             x1, x0
    // 0xd4af44: ldur            x0, [fp, #-0x28]
    // 0xd4af48: stur            x1, [fp, #-0x18]
    // 0xd4af4c: StoreField: r1->field_f = r0
    //     0xd4af4c: stur            w0, [x1, #0xf]
    // 0xd4af50: ldur            x0, [fp, #-0x30]
    // 0xd4af54: LoadField: r2 = r0->field_2f
    //     0xd4af54: ldur            w2, [x0, #0x2f]
    // 0xd4af58: DecompressPointer r2
    //     0xd4af58: add             x2, x2, HEAP, lsl #32
    // 0xd4af5c: stur            x2, [fp, #-0x10]
    // 0xd4af60: r0 = MouseRegion()
    //     0xd4af60: bl              #0xd1c8fc  ; AllocateMouseRegionStub -> MouseRegion (size=0x28)
    // 0xd4af64: mov             x2, x0
    // 0xd4af68: r0 = Instance__DeferringMouseCursor
    //     0xd4af68: ldr             x0, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0xd4af6c: stur            x2, [fp, #-0x20]
    // 0xd4af70: StoreField: r2->field_1b = r0
    //     0xd4af70: stur            w0, [x2, #0x1b]
    // 0xd4af74: r0 = true
    //     0xd4af74: add             x0, NULL, #0x20  ; true
    // 0xd4af78: StoreField: r2->field_1f = r0
    //     0xd4af78: stur            w0, [x2, #0x1f]
    // 0xd4af7c: ldur            x1, [fp, #-0x10]
    // 0xd4af80: StoreField: r2->field_b = r1
    //     0xd4af80: stur            w1, [x2, #0xb]
    // 0xd4af84: ldur            x1, [fp, #-0x30]
    // 0xd4af88: LoadField: r3 = r1->field_2b
    //     0xd4af88: ldur            w3, [x1, #0x2b]
    // 0xd4af8c: DecompressPointer r3
    //     0xd4af8c: add             x3, x3, HEAP, lsl #32
    // 0xd4af90: cmp             w3, NULL
    // 0xd4af94: b.ne            #0xd4afa0
    // 0xd4af98: r1 = Null
    //     0xd4af98: mov             x1, NULL
    // 0xd4af9c: b               #0xd4afa4
    // 0xd4afa0: mov             x1, x3
    // 0xd4afa4: cmp             w1, NULL
    // 0xd4afa8: b.ne            #0xd4afb0
    // 0xd4afac: r1 = false
    //     0xd4afac: add             x1, NULL, #0x30  ; false
    // 0xd4afb0: ldur            x3, [fp, #-8]
    // 0xd4afb4: LoadField: r4 = r3->field_1f
    //     0xd4afb4: ldur            w4, [x3, #0x1f]
    // 0xd4afb8: DecompressPointer r4
    //     0xd4afb8: add             x4, x4, HEAP, lsl #32
    // 0xd4afbc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd4afc0: cmp             w4, w16
    // 0xd4afc4: b.eq            #0xd4b14c
    // 0xd4afc8: LoadField: r4 = r3->field_1b
    //     0xd4afc8: ldur            w4, [x3, #0x1b]
    // 0xd4afcc: DecompressPointer r4
    //     0xd4afcc: add             x4, x4, HEAP, lsl #32
    // 0xd4afd0: stur            x4, [fp, #-0x10]
    // 0xd4afd4: tbnz            w1, #4, #0xd4afec
    // 0xd4afd8: mov             x0, x2
    // 0xd4afdc: mov             x2, x3
    // 0xd4afe0: mov             x1, x4
    // 0xd4afe4: r3 = Null
    //     0xd4afe4: mov             x3, NULL
    // 0xd4afe8: b               #0xd4b004
    // 0xd4afec: mov             x1, x3
    // 0xd4aff0: r0 = _tooltipMessage()
    //     0xd4aff0: bl              #0xd4b16c  ; [package:flutter/src/material/tooltip.dart] TooltipState::_tooltipMessage
    // 0xd4aff4: mov             x3, x0
    // 0xd4aff8: ldur            x2, [fp, #-8]
    // 0xd4affc: ldur            x0, [fp, #-0x20]
    // 0xd4b000: ldur            x1, [fp, #-0x10]
    // 0xd4b004: stur            x3, [fp, #-0x30]
    // 0xd4b008: LoadField: r4 = r2->field_b
    //     0xd4b008: ldur            w4, [x2, #0xb]
    // 0xd4b00c: DecompressPointer r4
    //     0xd4b00c: add             x4, x4, HEAP, lsl #32
    // 0xd4b010: cmp             w4, NULL
    // 0xd4b014: b.eq            #0xd4b158
    // 0xd4b018: LoadField: r5 = r4->field_b
    //     0xd4b018: ldur            w5, [x4, #0xb]
    // 0xd4b01c: DecompressPointer r5
    //     0xd4b01c: add             x5, x5, HEAP, lsl #32
    // 0xd4b020: cmp             w5, NULL
    // 0xd4b024: r16 = true
    //     0xd4b024: add             x16, NULL, #0x20  ; true
    // 0xd4b028: r17 = false
    //     0xd4b028: add             x17, NULL, #0x30  ; false
    // 0xd4b02c: csel            x4, x16, x17, ne
    // 0xd4b030: stur            x4, [fp, #-0x28]
    // 0xd4b034: r0 = RawTooltip()
    //     0xd4b034: bl              #0xd4b160  ; AllocateRawTooltipStub -> RawTooltip (size=0x40)
    // 0xd4b038: mov             x3, x0
    // 0xd4b03c: ldur            x0, [fp, #-0x30]
    // 0xd4b040: stur            x3, [fp, #-0x38]
    // 0xd4b044: StoreField: r3->field_b = r0
    //     0xd4b044: stur            w0, [x3, #0xb]
    // 0xd4b048: ldur            x2, [fp, #-0x18]
    // 0xd4b04c: r1 = Function '<anonymous closure>':.
    //     0xd4b04c: add             x1, PP, #0x98, lsl #12  ; [pp+0x98df8] AnonymousClosure: (0xd4b440), in [package:flutter/src/material/tooltip.dart] TooltipState::build (0xd4abb8)
    //     0xd4b050: ldr             x1, [x1, #0xdf8]
    // 0xd4b054: r0 = AllocateClosure()
    //     0xd4b054: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd4b058: mov             x1, x0
    // 0xd4b05c: ldur            x0, [fp, #-0x38]
    // 0xd4b060: StoreField: r0->field_f = r1
    //     0xd4b060: stur            w1, [x0, #0xf]
    // 0xd4b064: r1 = Instance_Duration
    //     0xd4b064: ldr             x1, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    // 0xd4b068: StoreField: r0->field_13 = r1
    //     0xd4b068: stur            w1, [x0, #0x13]
    // 0xd4b06c: r1 = Instance_Duration
    //     0xd4b06c: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e8f0] Obj!Duration@12c8a61
    //     0xd4b070: ldr             x1, [x1, #0x8f0]
    // 0xd4b074: ArrayStore: r0[0] = r1  ; List_4
    //     0xd4b074: stur            w1, [x0, #0x17]
    // 0xd4b078: r1 = Instance_Duration
    //     0xd4b078: ldr             x1, [PP, #0x5668]  ; [pp+0x5668] Obj!Duration@12c8941
    // 0xd4b07c: StoreField: r0->field_1b = r1
    //     0xd4b07c: stur            w1, [x0, #0x1b]
    // 0xd4b080: r1 = true
    //     0xd4b080: add             x1, NULL, #0x20  ; true
    // 0xd4b084: StoreField: r0->field_1f = r1
    //     0xd4b084: stur            w1, [x0, #0x1f]
    // 0xd4b088: r2 = Instance_TooltipTriggerMode
    //     0xd4b088: add             x2, PP, #0x98, lsl #12  ; [pp+0x98e00] Obj!TooltipTriggerMode@12c27a1
    //     0xd4b08c: ldr             x2, [x2, #0xe00]
    // 0xd4b090: StoreField: r0->field_23 = r2
    //     0xd4b090: stur            w2, [x0, #0x23]
    // 0xd4b094: StoreField: r0->field_27 = r1
    //     0xd4b094: stur            w1, [x0, #0x27]
    // 0xd4b098: r1 = Instance_AnimationStyle
    //     0xd4b098: add             x1, PP, #0x98, lsl #12  ; [pp+0x98e08] Obj!AnimationStyle@12b3f71
    //     0xd4b09c: ldr             x1, [x1, #0xe08]
    // 0xd4b0a0: StoreField: r0->field_2f = r1
    //     0xd4b0a0: stur            w1, [x0, #0x2f]
    // 0xd4b0a4: ldur            x2, [fp, #-8]
    // 0xd4b0a8: r1 = Function '_getDefaultPositionDelegate@135220820':.
    //     0xd4b0a8: add             x1, PP, #0x98, lsl #12  ; [pp+0x98e10] AnonymousClosure: (0xd4b270), in [package:flutter/src/material/tooltip.dart] TooltipState::_getDefaultPositionDelegate (0xd4b2ac)
    //     0xd4b0ac: ldr             x1, [x1, #0xe10]
    // 0xd4b0b0: r0 = AllocateClosure()
    //     0xd4b0b0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd4b0b4: mov             x1, x0
    // 0xd4b0b8: ldur            x0, [fp, #-0x38]
    // 0xd4b0bc: StoreField: r0->field_33 = r1
    //     0xd4b0bc: stur            w1, [x0, #0x33]
    // 0xd4b0c0: ldur            x1, [fp, #-0x28]
    // 0xd4b0c4: StoreField: r0->field_37 = r1
    //     0xd4b0c4: stur            w1, [x0, #0x37]
    // 0xd4b0c8: ldur            x1, [fp, #-0x20]
    // 0xd4b0cc: StoreField: r0->field_3b = r1
    //     0xd4b0cc: stur            w1, [x0, #0x3b]
    // 0xd4b0d0: ldur            x1, [fp, #-0x10]
    // 0xd4b0d4: StoreField: r0->field_7 = r1
    //     0xd4b0d4: stur            w1, [x0, #7]
    // 0xd4b0d8: LeaveFrame
    //     0xd4b0d8: mov             SP, fp
    //     0xd4b0dc: ldp             fp, lr, [SP], #0x10
    // 0xd4b0e0: ret
    //     0xd4b0e0: ret             
    // 0xd4b0e4: r0 = Null
    //     0xd4b0e4: mov             x0, NULL
    // 0xd4b0e8: cmp             w0, NULL
    // 0xd4b0ec: b.eq            #0xd4b15c
    // 0xd4b0f0: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xd4b0f0: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xd4b0f4: r0 = Throw()
    //     0xd4b0f4: bl              #0x13ddb2c  ; ThrowStub
    // 0xd4b0f8: brk             #0
    // 0xd4b0fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4b0fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4b100: b               #0xd4abdc
    // 0xd4b104: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4b104: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4b108: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4b108: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4b10c: SaveReg d0
    //     0xd4b10c: str             q0, [SP, #-0x10]!
    // 0xd4b110: r0 = AllocateDouble()
    //     0xd4b110: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd4b114: RestoreReg d0
    //     0xd4b114: ldr             q0, [SP], #0x10
    // 0xd4b118: b               #0xd4ac80
    // 0xd4b11c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4b11c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4b120: SaveReg d0
    //     0xd4b120: str             q0, [SP, #-0x10]!
    // 0xd4b124: r0 = AllocateDouble()
    //     0xd4b124: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd4b128: RestoreReg d0
    //     0xd4b128: ldr             q0, [SP], #0x10
    // 0xd4b12c: b               #0xd4ad5c
    // 0xd4b130: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4b130: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4b134: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4b134: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4b138: r9 = _tooltipTheme
    //     0xd4b138: add             x9, PP, #0x98, lsl #12  ; [pp+0x98e18] Field <TooltipState._tooltipTheme@135220820>: late (offset: 0x24)
    //     0xd4b13c: ldr             x9, [x9, #0xe18]
    // 0xd4b140: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd4b140: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd4b144: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4b144: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4b148: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4b148: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4b14c: r9 = _visible
    //     0xd4b14c: add             x9, PP, #0x98, lsl #12  ; [pp+0x98e20] Field <TooltipState._visible@135220820>: late (offset: 0x20)
    //     0xd4b150: ldr             x9, [x9, #0xe20]
    // 0xd4b154: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd4b154: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd4b158: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4b158: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4b15c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4b15c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _tooltipMessage(/* No info */) {
    // ** addr: 0xd4b16c, size: 0x58
    // 0xd4b16c: EnterFrame
    //     0xd4b16c: stp             fp, lr, [SP, #-0x10]!
    //     0xd4b170: mov             fp, SP
    // 0xd4b174: LoadField: r0 = r1->field_b
    //     0xd4b174: ldur            w0, [x1, #0xb]
    // 0xd4b178: DecompressPointer r0
    //     0xd4b178: add             x0, x0, HEAP, lsl #32
    // 0xd4b17c: cmp             w0, NULL
    // 0xd4b180: b.eq            #0xd4b1bc
    // 0xd4b184: LoadField: r1 = r0->field_b
    //     0xd4b184: ldur            w1, [x0, #0xb]
    // 0xd4b188: DecompressPointer r1
    //     0xd4b188: add             x1, x1, HEAP, lsl #32
    // 0xd4b18c: cmp             w1, NULL
    // 0xd4b190: b.eq            #0xd4b1a4
    // 0xd4b194: mov             x0, x1
    // 0xd4b198: LeaveFrame
    //     0xd4b198: mov             SP, fp
    //     0xd4b19c: ldp             fp, lr, [SP], #0x10
    // 0xd4b1a0: ret
    //     0xd4b1a0: ret             
    // 0xd4b1a4: r0 = Null
    //     0xd4b1a4: mov             x0, NULL
    // 0xd4b1a8: cmp             w0, NULL
    // 0xd4b1ac: b.eq            #0xd4b1c0
    // 0xd4b1b0: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xd4b1b0: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xd4b1b4: r0 = Throw()
    //     0xd4b1b4: bl              #0x13ddb2c  ; ThrowStub
    // 0xd4b1b8: brk             #0
    // 0xd4b1bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4b1bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4b1c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4b1c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getDefaultPadding(/* No info */) {
    // ** addr: 0xd4b1d0, size: 0x4c
    // 0xd4b1d0: EnterFrame
    //     0xd4b1d0: stp             fp, lr, [SP, #-0x10]!
    //     0xd4b1d4: mov             fp, SP
    // 0xd4b1d8: CheckStackOverflow
    //     0xd4b1d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4b1dc: cmp             SP, x16
    //     0xd4b1e0: b.ls            #0xd4b210
    // 0xd4b1e4: LoadField: r0 = r1->field_f
    //     0xd4b1e4: ldur            w0, [x1, #0xf]
    // 0xd4b1e8: DecompressPointer r0
    //     0xd4b1e8: add             x0, x0, HEAP, lsl #32
    // 0xd4b1ec: cmp             w0, NULL
    // 0xd4b1f0: b.eq            #0xd4b218
    // 0xd4b1f4: mov             x1, x0
    // 0xd4b1f8: r0 = of()
    //     0xd4b1f8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd4b1fc: r0 = Instance_EdgeInsets
    //     0xd4b1fc: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8f560] Obj!EdgeInsets@129ce41
    //     0xd4b200: ldr             x0, [x0, #0x560]
    // 0xd4b204: LeaveFrame
    //     0xd4b204: mov             SP, fp
    //     0xd4b208: ldp             fp, lr, [SP], #0x10
    // 0xd4b20c: ret
    //     0xd4b20c: ret             
    // 0xd4b210: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4b210: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4b214: b               #0xd4b1e4
    // 0xd4b218: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4b218: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getDefaultTooltipHeight(/* No info */) {
    // ** addr: 0xd4b21c, size: 0x4c
    // 0xd4b21c: EnterFrame
    //     0xd4b21c: stp             fp, lr, [SP, #-0x10]!
    //     0xd4b220: mov             fp, SP
    // 0xd4b224: CheckStackOverflow
    //     0xd4b224: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4b228: cmp             SP, x16
    //     0xd4b22c: b.ls            #0xd4b25c
    // 0xd4b230: LoadField: r0 = r1->field_f
    //     0xd4b230: ldur            w0, [x1, #0xf]
    // 0xd4b234: DecompressPointer r0
    //     0xd4b234: add             x0, x0, HEAP, lsl #32
    // 0xd4b238: cmp             w0, NULL
    // 0xd4b23c: b.eq            #0xd4b264
    // 0xd4b240: mov             x1, x0
    // 0xd4b244: r0 = of()
    //     0xd4b244: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd4b248: d0 = 32.000000
    //     0xd4b248: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a60] IMM: double(32) from 0x4040000000000000
    //     0xd4b24c: ldr             d0, [x17, #0xa60]
    // 0xd4b250: LeaveFrame
    //     0xd4b250: mov             SP, fp
    //     0xd4b254: ldp             fp, lr, [SP], #0x10
    // 0xd4b258: ret
    //     0xd4b258: ret             
    // 0xd4b25c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4b25c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4b260: b               #0xd4b230
    // 0xd4b264: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4b264: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static double _getDefaultFontSize() {
    // ** addr: 0xd4b268, size: 0x8
    // 0xd4b268: d0 = 14.000000
    //     0xd4b268: fmov            d0, #14.00000000
    // 0xd4b26c: ret
    //     0xd4b26c: ret             
  }
  [closure] Offset _getDefaultPositionDelegate(dynamic, TooltipPositionContext) {
    // ** addr: 0xd4b270, size: 0x3c
    // 0xd4b270: EnterFrame
    //     0xd4b270: stp             fp, lr, [SP, #-0x10]!
    //     0xd4b274: mov             fp, SP
    // 0xd4b278: ldr             x0, [fp, #0x18]
    // 0xd4b27c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd4b27c: ldur            w1, [x0, #0x17]
    // 0xd4b280: DecompressPointer r1
    //     0xd4b280: add             x1, x1, HEAP, lsl #32
    // 0xd4b284: CheckStackOverflow
    //     0xd4b284: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4b288: cmp             SP, x16
    //     0xd4b28c: b.ls            #0xd4b2a4
    // 0xd4b290: ldr             x2, [fp, #0x10]
    // 0xd4b294: r0 = _getDefaultPositionDelegate()
    //     0xd4b294: bl              #0xd4b2ac  ; [package:flutter/src/material/tooltip.dart] TooltipState::_getDefaultPositionDelegate
    // 0xd4b298: LeaveFrame
    //     0xd4b298: mov             SP, fp
    //     0xd4b29c: ldp             fp, lr, [SP], #0x10
    // 0xd4b2a0: ret
    //     0xd4b2a0: ret             
    // 0xd4b2a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4b2a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4b2a8: b               #0xd4b290
  }
  _ _getDefaultPositionDelegate(/* No info */) {
    // ** addr: 0xd4b2ac, size: 0x98
    // 0xd4b2ac: EnterFrame
    //     0xd4b2ac: stp             fp, lr, [SP, #-0x10]!
    //     0xd4b2b0: mov             fp, SP
    // 0xd4b2b4: CheckStackOverflow
    //     0xd4b2b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4b2b8: cmp             SP, x16
    //     0xd4b2bc: b.ls            #0xd4b32c
    // 0xd4b2c0: LoadField: r0 = r1->field_b
    //     0xd4b2c0: ldur            w0, [x1, #0xb]
    // 0xd4b2c4: DecompressPointer r0
    //     0xd4b2c4: add             x0, x0, HEAP, lsl #32
    // 0xd4b2c8: cmp             w0, NULL
    // 0xd4b2cc: b.eq            #0xd4b334
    // 0xd4b2d0: LoadField: r0 = r1->field_23
    //     0xd4b2d0: ldur            w0, [x1, #0x23]
    // 0xd4b2d4: DecompressPointer r0
    //     0xd4b2d4: add             x0, x0, HEAP, lsl #32
    // 0xd4b2d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd4b2dc: cmp             w0, w16
    // 0xd4b2e0: b.eq            #0xd4b338
    // 0xd4b2e4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd4b2e4: ldur            w1, [x0, #0x17]
    // 0xd4b2e8: DecompressPointer r1
    //     0xd4b2e8: add             x1, x1, HEAP, lsl #32
    // 0xd4b2ec: cmp             w1, NULL
    // 0xd4b2f0: b.ne            #0xd4b2fc
    // 0xd4b2f4: d0 = 24.000000
    //     0xd4b2f4: fmov            d0, #24.00000000
    // 0xd4b2f8: b               #0xd4b300
    // 0xd4b2fc: LoadField: d0 = r1->field_7
    //     0xd4b2fc: ldur            d0, [x1, #7]
    // 0xd4b300: LoadField: r3 = r2->field_7
    //     0xd4b300: ldur            w3, [x2, #7]
    // 0xd4b304: DecompressPointer r3
    //     0xd4b304: add             x3, x3, HEAP, lsl #32
    // 0xd4b308: LoadField: r1 = r2->field_f
    //     0xd4b308: ldur            w1, [x2, #0xf]
    // 0xd4b30c: DecompressPointer r1
    //     0xd4b30c: add             x1, x1, HEAP, lsl #32
    // 0xd4b310: LoadField: r0 = r2->field_1f
    //     0xd4b310: ldur            w0, [x2, #0x1f]
    // 0xd4b314: DecompressPointer r0
    //     0xd4b314: add             x0, x0, HEAP, lsl #32
    // 0xd4b318: mov             x2, x0
    // 0xd4b31c: r0 = positionDependentBox()
    //     0xd4b31c: bl              #0xd4b344  ; [package:flutter/src/painting/geometry.dart] ::positionDependentBox
    // 0xd4b320: LeaveFrame
    //     0xd4b320: mov             SP, fp
    //     0xd4b324: ldp             fp, lr, [SP], #0x10
    // 0xd4b328: ret
    //     0xd4b328: ret             
    // 0xd4b32c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4b32c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4b330: b               #0xd4b2c0
    // 0xd4b334: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4b334: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4b338: r9 = _tooltipTheme
    //     0xd4b338: add             x9, PP, #0x98, lsl #12  ; [pp+0x98e18] Field <TooltipState._tooltipTheme@135220820>: late (offset: 0x24)
    //     0xd4b33c: ldr             x9, [x9, #0xe18]
    // 0xd4b340: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd4b340: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] FadeTransition <anonymous closure>(dynamic, BuildContext, Animation<double>) {
    // ** addr: 0xd4b440, size: 0x4c
    // 0xd4b440: EnterFrame
    //     0xd4b440: stp             fp, lr, [SP, #-0x10]!
    //     0xd4b444: mov             fp, SP
    // 0xd4b448: AllocStack(0x8)
    //     0xd4b448: sub             SP, SP, #8
    // 0xd4b44c: SetupParameters([dynamic _ /* r0 */])
    //     0xd4b44c: ldr             x0, [fp, #0x20]
    //     0xd4b450: ldur            w1, [x0, #0x17]
    //     0xd4b454: add             x1, x1, HEAP, lsl #32
    // 0xd4b458: LoadField: r0 = r1->field_f
    //     0xd4b458: ldur            w0, [x1, #0xf]
    // 0xd4b45c: DecompressPointer r0
    //     0xd4b45c: add             x0, x0, HEAP, lsl #32
    // 0xd4b460: stur            x0, [fp, #-8]
    // 0xd4b464: r0 = FadeTransition()
    //     0xd4b464: bl              #0xb28358  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0xd4b468: ldr             x1, [fp, #0x10]
    // 0xd4b46c: StoreField: r0->field_f = r1
    //     0xd4b46c: stur            w1, [x0, #0xf]
    // 0xd4b470: r1 = false
    //     0xd4b470: add             x1, NULL, #0x30  ; false
    // 0xd4b474: StoreField: r0->field_13 = r1
    //     0xd4b474: stur            w1, [x0, #0x13]
    // 0xd4b478: ldur            x1, [fp, #-8]
    // 0xd4b47c: StoreField: r0->field_b = r1
    //     0xd4b47c: stur            w1, [x0, #0xb]
    // 0xd4b480: LeaveFrame
    //     0xd4b480: mov             SP, fp
    //     0xd4b484: ldp             fp, lr, [SP], #0x10
    // 0xd4b488: ret
    //     0xd4b488: ret             
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xeef08c, size: 0x94
    // 0xeef08c: EnterFrame
    //     0xeef08c: stp             fp, lr, [SP, #-0x10]!
    //     0xeef090: mov             fp, SP
    // 0xeef094: AllocStack(0x8)
    //     0xeef094: sub             SP, SP, #8
    // 0xeef098: SetupParameters(TooltipState this /* r1 => r0, fp-0x8 */)
    //     0xeef098: mov             x0, x1
    //     0xeef09c: stur            x1, [fp, #-8]
    // 0xeef0a0: CheckStackOverflow
    //     0xeef0a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeef0a4: cmp             SP, x16
    //     0xeef0a8: b.ls            #0xeef110
    // 0xeef0ac: LoadField: r1 = r0->field_f
    //     0xeef0ac: ldur            w1, [x0, #0xf]
    // 0xeef0b0: DecompressPointer r1
    //     0xeef0b0: add             x1, x1, HEAP, lsl #32
    // 0xeef0b4: cmp             w1, NULL
    // 0xeef0b8: b.eq            #0xeef118
    // 0xeef0bc: r0 = of()
    //     0xeef0bc: bl              #0xeef17c  ; [package:flutter/src/material/tooltip_visibility.dart] TooltipVisibility::of
    // 0xeef0c0: ldur            x2, [fp, #-8]
    // 0xeef0c4: r0 = true
    //     0xeef0c4: add             x0, NULL, #0x20  ; true
    // 0xeef0c8: StoreField: r2->field_1f = r0
    //     0xeef0c8: stur            w0, [x2, #0x1f]
    // 0xeef0cc: LoadField: r1 = r2->field_f
    //     0xeef0cc: ldur            w1, [x2, #0xf]
    // 0xeef0d0: DecompressPointer r1
    //     0xeef0d0: add             x1, x1, HEAP, lsl #32
    // 0xeef0d4: cmp             w1, NULL
    // 0xeef0d8: b.eq            #0xeef11c
    // 0xeef0dc: r0 = of()
    //     0xeef0dc: bl              #0xeef120  ; [package:flutter/src/material/tooltip_theme.dart] TooltipTheme::of
    // 0xeef0e0: ldur            x1, [fp, #-8]
    // 0xeef0e4: StoreField: r1->field_23 = r0
    //     0xeef0e4: stur            w0, [x1, #0x23]
    //     0xeef0e8: ldurb           w16, [x1, #-1]
    //     0xeef0ec: ldurb           w17, [x0, #-1]
    //     0xeef0f0: and             x16, x17, x16, lsr #2
    //     0xeef0f4: tst             x16, HEAP, lsr #32
    //     0xeef0f8: b.eq            #0xeef100
    //     0xeef0fc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xeef100: r0 = Null
    //     0xeef100: mov             x0, NULL
    // 0xeef104: LeaveFrame
    //     0xeef104: mov             SP, fp
    //     0xeef108: ldp             fp, lr, [SP], #0x10
    // 0xeef10c: ret
    //     0xeef10c: ret             
    // 0xeef110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeef110: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeef114: b               #0xeef0ac
    // 0xeef118: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeef118: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xeef11c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeef11c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6134, size: 0x28, field offset: 0xc
//   const constructor, 
class _TooltipBox extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfbf194, size: 0x140
    // 0xfbf194: EnterFrame
    //     0xfbf194: stp             fp, lr, [SP, #-0x10]!
    //     0xfbf198: mov             fp, SP
    // 0xfbf19c: AllocStack(0x50)
    //     0xfbf19c: sub             SP, SP, #0x50
    // 0xfbf1a0: CheckStackOverflow
    //     0xfbf1a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbf1a4: cmp             SP, x16
    //     0xfbf1a8: b.ls            #0xfbf2cc
    // 0xfbf1ac: LoadField: r0 = r1->field_b
    //     0xfbf1ac: ldur            w0, [x1, #0xb]
    // 0xfbf1b0: DecompressPointer r0
    //     0xfbf1b0: add             x0, x0, HEAP, lsl #32
    // 0xfbf1b4: stur            x0, [fp, #-0x28]
    // 0xfbf1b8: LoadField: r2 = r1->field_f
    //     0xfbf1b8: ldur            w2, [x1, #0xf]
    // 0xfbf1bc: DecompressPointer r2
    //     0xfbf1bc: add             x2, x2, HEAP, lsl #32
    // 0xfbf1c0: stur            x2, [fp, #-0x20]
    // 0xfbf1c4: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xfbf1c4: ldur            w3, [x1, #0x17]
    // 0xfbf1c8: DecompressPointer r3
    //     0xfbf1c8: add             x3, x3, HEAP, lsl #32
    // 0xfbf1cc: stur            x3, [fp, #-0x18]
    // 0xfbf1d0: LoadField: r4 = r1->field_1b
    //     0xfbf1d0: ldur            w4, [x1, #0x1b]
    // 0xfbf1d4: DecompressPointer r4
    //     0xfbf1d4: add             x4, x4, HEAP, lsl #32
    // 0xfbf1d8: stur            x4, [fp, #-0x10]
    // 0xfbf1dc: LoadField: r5 = r1->field_23
    //     0xfbf1dc: ldur            w5, [x1, #0x23]
    // 0xfbf1e0: DecompressPointer r5
    //     0xfbf1e0: add             x5, x5, HEAP, lsl #32
    // 0xfbf1e4: stur            x5, [fp, #-8]
    // 0xfbf1e8: r0 = Text()
    //     0xfbf1e8: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xfbf1ec: mov             x1, x0
    // 0xfbf1f0: ldur            x0, [fp, #-8]
    // 0xfbf1f4: stur            x1, [fp, #-0x30]
    // 0xfbf1f8: StoreField: r1->field_f = r0
    //     0xfbf1f8: stur            w0, [x1, #0xf]
    // 0xfbf1fc: ldur            x0, [fp, #-0x20]
    // 0xfbf200: StoreField: r1->field_13 = r0
    //     0xfbf200: stur            w0, [x1, #0x13]
    // 0xfbf204: r2 = Instance_TextAlign
    //     0xfbf204: ldr             x2, [PP, #0x4c78]  ; [pp+0x4c78] Obj!TextAlign@12c7541
    // 0xfbf208: StoreField: r1->field_1b = r2
    //     0xfbf208: stur            w2, [x1, #0x1b]
    // 0xfbf20c: r0 = Center()
    //     0xfbf20c: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xfbf210: mov             x1, x0
    // 0xfbf214: r0 = Instance_Alignment
    //     0xfbf214: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfbf218: ldr             x0, [x0, #0xb80]
    // 0xfbf21c: stur            x1, [fp, #-8]
    // 0xfbf220: StoreField: r1->field_f = r0
    //     0xfbf220: stur            w0, [x1, #0xf]
    // 0xfbf224: r0 = 1.000000
    //     0xfbf224: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xfbf228: StoreField: r1->field_13 = r0
    //     0xfbf228: stur            w0, [x1, #0x13]
    // 0xfbf22c: ArrayStore: r1[0] = r0  ; List_4
    //     0xfbf22c: stur            w0, [x1, #0x17]
    // 0xfbf230: ldur            x0, [fp, #-0x30]
    // 0xfbf234: StoreField: r1->field_b = r0
    //     0xfbf234: stur            w0, [x1, #0xb]
    // 0xfbf238: r0 = Container()
    //     0xfbf238: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xfbf23c: stur            x0, [fp, #-0x30]
    // 0xfbf240: ldur            x16, [fp, #-0x18]
    // 0xfbf244: ldur            lr, [fp, #-0x10]
    // 0xfbf248: stp             lr, x16, [SP, #0x10]
    // 0xfbf24c: r16 = Instance_EdgeInsets
    //     0xfbf24c: ldr             x16, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xfbf250: ldur            lr, [fp, #-8]
    // 0xfbf254: stp             lr, x16, [SP]
    // 0xfbf258: mov             x1, x0
    // 0xfbf25c: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x1, margin, 0x3, padding, 0x2, null]
    //     0xfbf25c: add             x4, PP, #0xa3, lsl #12  ; [pp+0xa34d8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x1, "margin", 0x3, "padding", 0x2, Null]
    //     0xfbf260: ldr             x4, [x4, #0x4d8]
    // 0xfbf264: r0 = Container()
    //     0xfbf264: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xfbf268: r0 = DefaultTextStyle()
    //     0xfbf268: bl              #0xd0b11c  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xfbf26c: mov             x1, x0
    // 0xfbf270: ldur            x0, [fp, #-0x20]
    // 0xfbf274: stur            x1, [fp, #-8]
    // 0xfbf278: StoreField: r1->field_f = r0
    //     0xfbf278: stur            w0, [x1, #0xf]
    // 0xfbf27c: r0 = Instance_TextAlign
    //     0xfbf27c: ldr             x0, [PP, #0x4c78]  ; [pp+0x4c78] Obj!TextAlign@12c7541
    // 0xfbf280: StoreField: r1->field_13 = r0
    //     0xfbf280: stur            w0, [x1, #0x13]
    // 0xfbf284: r0 = true
    //     0xfbf284: add             x0, NULL, #0x20  ; true
    // 0xfbf288: ArrayStore: r1[0] = r0  ; List_4
    //     0xfbf288: stur            w0, [x1, #0x17]
    // 0xfbf28c: r0 = Instance_TextOverflow
    //     0xfbf28c: add             x0, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xfbf290: ldr             x0, [x0, #0x108]
    // 0xfbf294: StoreField: r1->field_1b = r0
    //     0xfbf294: stur            w0, [x1, #0x1b]
    // 0xfbf298: r0 = Instance_TextWidthBasis
    //     0xfbf298: add             x0, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xfbf29c: ldr             x0, [x0, #0x110]
    // 0xfbf2a0: StoreField: r1->field_23 = r0
    //     0xfbf2a0: stur            w0, [x1, #0x23]
    // 0xfbf2a4: ldur            x0, [fp, #-0x30]
    // 0xfbf2a8: StoreField: r1->field_b = r0
    //     0xfbf2a8: stur            w0, [x1, #0xb]
    // 0xfbf2ac: r0 = ConstrainedBox()
    //     0xfbf2ac: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xfbf2b0: ldur            x1, [fp, #-0x28]
    // 0xfbf2b4: StoreField: r0->field_f = r1
    //     0xfbf2b4: stur            w1, [x0, #0xf]
    // 0xfbf2b8: ldur            x1, [fp, #-8]
    // 0xfbf2bc: StoreField: r0->field_b = r1
    //     0xfbf2bc: stur            w1, [x0, #0xb]
    // 0xfbf2c0: LeaveFrame
    //     0xfbf2c0: mov             SP, fp
    //     0xfbf2c4: ldp             fp, lr, [SP], #0x10
    // 0xfbf2c8: ret
    //     0xfbf2c8: ret             
    // 0xfbf2cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbf2cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbf2d0: b               #0xfbf1ac
  }
}

// class id: 6412, size: 0x68, field offset: 0xc
//   const constructor, 
class Tooltip extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa33f4, size: 0x54
    // 0xfa33f4: EnterFrame
    //     0xfa33f4: stp             fp, lr, [SP, #-0x10]!
    //     0xfa33f8: mov             fp, SP
    // 0xfa33fc: AllocStack(0x8)
    //     0xfa33fc: sub             SP, SP, #8
    // 0xfa3400: SetupParameters(Tooltip this /* r1 => r0 */)
    //     0xfa3400: mov             x0, x1
    // 0xfa3404: r1 = <Tooltip>
    //     0xfa3404: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f5e0] TypeArguments: <Tooltip>
    //     0xfa3408: ldr             x1, [x1, #0x5e0]
    // 0xfa340c: r0 = TooltipState()
    //     0xfa340c: bl              #0xfa3448  ; AllocateTooltipStateStub -> TooltipState (size=0x28)
    // 0xfa3410: mov             x2, x0
    // 0xfa3414: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa3418: stur            x2, [fp, #-8]
    // 0xfa341c: StoreField: r2->field_1f = r0
    //     0xfa341c: stur            w0, [x2, #0x1f]
    // 0xfa3420: StoreField: r2->field_23 = r0
    //     0xfa3420: stur            w0, [x2, #0x23]
    // 0xfa3424: r1 = <RawTooltipState>
    //     0xfa3424: add             x1, PP, #0x84, lsl #12  ; [pp+0x84f58] TypeArguments: <RawTooltipState>
    //     0xfa3428: ldr             x1, [x1, #0xf58]
    // 0xfa342c: r0 = LabeledGlobalKey()
    //     0xfa342c: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa3430: mov             x1, x0
    // 0xfa3434: ldur            x0, [fp, #-8]
    // 0xfa3438: StoreField: r0->field_1b = r1
    //     0xfa3438: stur            w1, [x0, #0x1b]
    // 0xfa343c: LeaveFrame
    //     0xfa343c: mov             SP, fp
    //     0xfa3440: ldp             fp, lr, [SP], #0x10
    // 0xfa3444: ret
    //     0xfa3444: ret             
  }
}
