// lib: , url: package:flutter/src/material/tabs.dart

// class id: 1048958, size: 0x8
class :: {

  static _ _indexChangeProgress(/* No info */) {
    // ** addr: 0xae61fc, size: 0x1b8
    // 0xae61fc: EnterFrame
    //     0xae61fc: stp             fp, lr, [SP, #-0x10]!
    //     0xae6200: mov             fp, SP
    // 0xae6204: AllocStack(0x28)
    //     0xae6204: sub             SP, SP, #0x28
    // 0xae6208: SetupParameters(dynamic _ /* r1 => r2, fp-0x10 */)
    //     0xae6208: mov             x2, x1
    //     0xae620c: stur            x1, [fp, #-0x10]
    // 0xae6210: CheckStackOverflow
    //     0xae6210: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae6214: cmp             SP, x16
    //     0xae6218: b.ls            #0xae63a0
    // 0xae621c: LoadField: r0 = r2->field_23
    //     0xae621c: ldur            w0, [x2, #0x23]
    // 0xae6220: DecompressPointer r0
    //     0xae6220: add             x0, x0, HEAP, lsl #32
    // 0xae6224: cmp             w0, NULL
    // 0xae6228: b.ne            #0xae6230
    // 0xae622c: r0 = Null
    //     0xae622c: mov             x0, NULL
    // 0xae6230: cmp             w0, NULL
    // 0xae6234: b.eq            #0xae63a8
    // 0xae6238: LoadField: r3 = r0->field_37
    //     0xae6238: ldur            w3, [x0, #0x37]
    // 0xae623c: DecompressPointer r3
    //     0xae623c: add             x3, x3, HEAP, lsl #32
    // 0xae6240: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xae6244: cmp             w3, w16
    // 0xae6248: b.eq            #0xae63ac
    // 0xae624c: stur            x3, [fp, #-8]
    // 0xae6250: LoadField: r4 = r2->field_3b
    //     0xae6250: ldur            x4, [x2, #0x3b]
    // 0xae6254: r0 = BoxInt64Instr(r4)
    //     0xae6254: sbfiz           x0, x4, #1, #0x1f
    //     0xae6258: cmp             x4, x0, asr #1
    //     0xae625c: b.eq            #0xae6268
    //     0xae6260: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xae6264: stur            x4, [x0, #7]
    // 0xae6268: stp             x0, NULL, [SP]
    // 0xae626c: r0 = _Double.fromInteger()
    //     0xae626c: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0xae6270: mov             x3, x0
    // 0xae6274: ldur            x2, [fp, #-0x10]
    // 0xae6278: stur            x3, [fp, #-0x18]
    // 0xae627c: LoadField: r4 = r2->field_33
    //     0xae627c: ldur            x4, [x2, #0x33]
    // 0xae6280: r0 = BoxInt64Instr(r4)
    //     0xae6280: sbfiz           x0, x4, #1, #0x1f
    //     0xae6284: cmp             x4, x0, asr #1
    //     0xae6288: b.eq            #0xae6294
    //     0xae628c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xae6290: stur            x4, [x0, #7]
    // 0xae6294: stp             x0, NULL, [SP]
    // 0xae6298: r0 = _Double.fromInteger()
    //     0xae6298: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0xae629c: mov             x1, x0
    // 0xae62a0: ldur            x0, [fp, #-0x10]
    // 0xae62a4: LoadField: r2 = r0->field_43
    //     0xae62a4: ldur            x2, [x0, #0x43]
    // 0xae62a8: cbnz            x2, #0xae6328
    // 0xae62ac: ldur            x0, [fp, #-8]
    // 0xae62b0: d1 = 0.000000
    //     0xae62b0: eor             v1.16b, v1.16b, v1.16b
    // 0xae62b4: LoadField: d2 = r0->field_7
    //     0xae62b4: ldur            d2, [x0, #7]
    // 0xae62b8: LoadField: d3 = r1->field_7
    //     0xae62b8: ldur            d3, [x1, #7]
    // 0xae62bc: fsub            d4, d3, d2
    // 0xae62c0: fcmp            d4, d1
    // 0xae62c4: b.ne            #0xae62d0
    // 0xae62c8: d2 = 0.000000
    //     0xae62c8: eor             v2.16b, v2.16b, v2.16b
    // 0xae62cc: b               #0xae62e4
    // 0xae62d0: fcmp            d1, d4
    // 0xae62d4: b.le            #0xae62e0
    // 0xae62d8: fneg            d2, d4
    // 0xae62dc: b               #0xae62e4
    // 0xae62e0: mov             v2.16b, v4.16b
    // 0xae62e4: fcmp            d1, d2
    // 0xae62e8: b.le            #0xae62f4
    // 0xae62ec: d0 = 0.000000
    //     0xae62ec: eor             v0.16b, v0.16b, v0.16b
    // 0xae62f0: b               #0xae631c
    // 0xae62f4: d3 = 1.000000
    //     0xae62f4: fmov            d3, #1.00000000
    // 0xae62f8: fcmp            d2, d3
    // 0xae62fc: b.le            #0xae6308
    // 0xae6300: d0 = 1.000000
    //     0xae6300: fmov            d0, #1.00000000
    // 0xae6304: b               #0xae631c
    // 0xae6308: fcmp            d2, d2
    // 0xae630c: b.vc            #0xae6318
    // 0xae6310: d0 = 1.000000
    //     0xae6310: fmov            d0, #1.00000000
    // 0xae6314: b               #0xae631c
    // 0xae6318: mov             v0.16b, v2.16b
    // 0xae631c: LeaveFrame
    //     0xae631c: mov             SP, fp
    //     0xae6320: ldp             fp, lr, [SP], #0x10
    // 0xae6324: ret
    //     0xae6324: ret             
    // 0xae6328: ldur            x0, [fp, #-8]
    // 0xae632c: d1 = 0.000000
    //     0xae632c: eor             v1.16b, v1.16b, v1.16b
    // 0xae6330: LoadField: d2 = r0->field_7
    //     0xae6330: ldur            d2, [x0, #7]
    // 0xae6334: LoadField: d3 = r1->field_7
    //     0xae6334: ldur            d3, [x1, #7]
    // 0xae6338: fsub            d4, d2, d3
    // 0xae633c: fcmp            d4, d1
    // 0xae6340: b.ne            #0xae634c
    // 0xae6344: d2 = 0.000000
    //     0xae6344: eor             v2.16b, v2.16b, v2.16b
    // 0xae6348: b               #0xae6360
    // 0xae634c: fcmp            d1, d4
    // 0xae6350: b.le            #0xae635c
    // 0xae6354: fneg            d2, d4
    // 0xae6358: b               #0xae6360
    // 0xae635c: mov             v2.16b, v4.16b
    // 0xae6360: ldur            x0, [fp, #-0x18]
    // 0xae6364: LoadField: d4 = r0->field_7
    //     0xae6364: ldur            d4, [x0, #7]
    // 0xae6368: fsub            d5, d3, d4
    // 0xae636c: fcmp            d5, d1
    // 0xae6370: b.ne            #0xae637c
    // 0xae6374: d1 = 0.000000
    //     0xae6374: eor             v1.16b, v1.16b, v1.16b
    // 0xae6378: b               #0xae6390
    // 0xae637c: fcmp            d1, d5
    // 0xae6380: b.le            #0xae638c
    // 0xae6384: fneg            d1, d5
    // 0xae6388: b               #0xae6390
    // 0xae638c: mov             v1.16b, v5.16b
    // 0xae6390: fdiv            d0, d2, d1
    // 0xae6394: LeaveFrame
    //     0xae6394: mov             SP, fp
    //     0xae6398: ldp             fp, lr, [SP], #0x10
    // 0xae639c: ret
    //     0xae639c: ret             
    // 0xae63a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae63a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae63a4: b               #0xae621c
    // 0xae63a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xae63a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xae63ac: r9 = _value
    //     0xae63ac: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xae63b0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xae63b0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 4331, size: 0x58, field offset: 0xc
class _IndicatorPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0xb78b5c, size: 0x450
    // 0xb78b5c: EnterFrame
    //     0xb78b5c: stp             fp, lr, [SP, #-0x10]!
    //     0xb78b60: mov             fp, SP
    // 0xb78b64: AllocStack(0x58)
    //     0xb78b64: sub             SP, SP, #0x58
    // 0xb78b68: r0 = false
    //     0xb78b68: add             x0, NULL, #0x30  ; false
    // 0xb78b6c: mov             x5, x1
    // 0xb78b70: mov             x4, x2
    // 0xb78b74: stur            x1, [fp, #-0x10]
    // 0xb78b78: stur            x2, [fp, #-0x18]
    // 0xb78b7c: stur            x3, [fp, #-0x20]
    // 0xb78b80: CheckStackOverflow
    //     0xb78b80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb78b84: cmp             SP, x16
    //     0xb78b88: b.ls            #0xb78f64
    // 0xb78b8c: StoreField: r5->field_53 = r0
    //     0xb78b8c: stur            w0, [x5, #0x53]
    // 0xb78b90: LoadField: r0 = r5->field_4f
    //     0xb78b90: ldur            w0, [x5, #0x4f]
    // 0xb78b94: DecompressPointer r0
    //     0xb78b94: add             x0, x0, HEAP, lsl #32
    // 0xb78b98: cmp             w0, NULL
    // 0xb78b9c: b.ne            #0xb78cc4
    // 0xb78ba0: LoadField: r0 = r5->field_f
    //     0xb78ba0: ldur            w0, [x5, #0xf]
    // 0xb78ba4: DecompressPointer r0
    //     0xb78ba4: add             x0, x0, HEAP, lsl #32
    // 0xb78ba8: mov             x2, x5
    // 0xb78bac: stur            x0, [fp, #-8]
    // 0xb78bb0: r1 = Function 'markNeedsPaint':.
    //     0xb78bb0: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0dd8] AnonymousClosure: (0xb7a690), in [package:flutter/src/material/tabs.dart] _IndicatorPainter::markNeedsPaint (0xb7a6c8)
    //     0xb78bb4: ldr             x1, [x1, #0xdd8]
    // 0xb78bb8: r0 = AllocateClosure()
    //     0xb78bb8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb78bbc: mov             x1, x0
    // 0xb78bc0: ldur            x0, [fp, #-8]
    // 0xb78bc4: stur            x1, [fp, #-0x28]
    // 0xb78bc8: r2 = LoadClassIdInstr(r0)
    //     0xb78bc8: ldur            x2, [x0, #-1]
    //     0xb78bcc: ubfx            x2, x2, #0xc, #0x14
    // 0xb78bd0: r17 = 5237
    //     0xb78bd0: mov             x17, #0x1475
    // 0xb78bd4: cmp             x2, x17
    // 0xb78bd8: b.ne            #0xb78c10
    // 0xb78bdc: r0 = _ShapeDecorationPainter()
    //     0xb78bdc: bl              #0xb7a684  ; Allocate_ShapeDecorationPainterStub -> _ShapeDecorationPainter (size=0x38)
    // 0xb78be0: mov             x1, x0
    // 0xb78be4: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xb78be8: ArrayStore: r1[0] = r0  ; List_4
    //     0xb78be8: stur            w0, [x1, #0x17]
    // 0xb78bec: StoreField: r1->field_27 = r0
    //     0xb78bec: stur            w0, [x1, #0x27]
    // 0xb78bf0: StoreField: r1->field_2b = r0
    //     0xb78bf0: stur            w0, [x1, #0x2b]
    // 0xb78bf4: StoreField: r1->field_2f = r0
    //     0xb78bf4: stur            w0, [x1, #0x2f]
    // 0xb78bf8: ldur            x0, [fp, #-8]
    // 0xb78bfc: StoreField: r1->field_b = r0
    //     0xb78bfc: stur            w0, [x1, #0xb]
    // 0xb78c00: ldur            x3, [fp, #-0x28]
    // 0xb78c04: StoreField: r1->field_7 = r3
    //     0xb78c04: stur            w3, [x1, #7]
    // 0xb78c08: mov             x0, x1
    // 0xb78c0c: b               #0xb78ca0
    // 0xb78c10: mov             x3, x1
    // 0xb78c14: r17 = 5238
    //     0xb78c14: mov             x17, #0x1476
    // 0xb78c18: cmp             x2, x17
    // 0xb78c1c: b.ne            #0xb78c40
    // 0xb78c20: r0 = _BoxDecorationPainter()
    //     0xb78c20: bl              #0xb7a678  ; Allocate_BoxDecorationPainterStub -> _BoxDecorationPainter (size=0x1c)
    // 0xb78c24: mov             x1, x0
    // 0xb78c28: ldur            x0, [fp, #-8]
    // 0xb78c2c: StoreField: r1->field_b = r0
    //     0xb78c2c: stur            w0, [x1, #0xb]
    // 0xb78c30: ldur            x3, [fp, #-0x28]
    // 0xb78c34: StoreField: r1->field_7 = r3
    //     0xb78c34: stur            w3, [x1, #7]
    // 0xb78c38: mov             x0, x1
    // 0xb78c3c: b               #0xb78ca0
    // 0xb78c40: r17 = 5239
    //     0xb78c40: mov             x17, #0x1477
    // 0xb78c44: cmp             x2, x17
    // 0xb78c48: b.ne            #0xb78c80
    // 0xb78c4c: LoadField: r1 = r0->field_7
    //     0xb78c4c: ldur            w1, [x0, #7]
    // 0xb78c50: DecompressPointer r1
    //     0xb78c50: add             x1, x1, HEAP, lsl #32
    // 0xb78c54: stur            x1, [fp, #-0x30]
    // 0xb78c58: r0 = _UnderlinePainter()
    //     0xb78c58: bl              #0xb7a66c  ; Allocate_UnderlinePainterStub -> _UnderlinePainter (size=0x14)
    // 0xb78c5c: mov             x1, x0
    // 0xb78c60: ldur            x0, [fp, #-8]
    // 0xb78c64: StoreField: r1->field_b = r0
    //     0xb78c64: stur            w0, [x1, #0xb]
    // 0xb78c68: ldur            x0, [fp, #-0x30]
    // 0xb78c6c: StoreField: r1->field_f = r0
    //     0xb78c6c: stur            w0, [x1, #0xf]
    // 0xb78c70: ldur            x2, [fp, #-0x28]
    // 0xb78c74: StoreField: r1->field_7 = r2
    //     0xb78c74: stur            w2, [x1, #7]
    // 0xb78c78: mov             x0, x1
    // 0xb78c7c: b               #0xb78ca0
    // 0xb78c80: mov             x2, x3
    // 0xb78c84: r0 = _CupertinoEdgeShadowPainter()
    //     0xb78c84: bl              #0xb7a660  ; Allocate_CupertinoEdgeShadowPainterStub -> _CupertinoEdgeShadowPainter (size=0x10)
    // 0xb78c88: mov             x1, x0
    // 0xb78c8c: ldur            x0, [fp, #-8]
    // 0xb78c90: StoreField: r1->field_b = r0
    //     0xb78c90: stur            w0, [x1, #0xb]
    // 0xb78c94: ldur            x0, [fp, #-0x28]
    // 0xb78c98: StoreField: r1->field_7 = r0
    //     0xb78c98: stur            w0, [x1, #7]
    // 0xb78c9c: mov             x0, x1
    // 0xb78ca0: ldur            x3, [fp, #-0x10]
    // 0xb78ca4: StoreField: r3->field_4f = r0
    //     0xb78ca4: stur            w0, [x3, #0x4f]
    //     0xb78ca8: ldurb           w16, [x3, #-1]
    //     0xb78cac: ldurb           w17, [x0, #-1]
    //     0xb78cb0: and             x16, x17, x16, lsr #2
    //     0xb78cb4: tst             x16, HEAP, lsr #32
    //     0xb78cb8: b.eq            #0xb78cc0
    //     0xb78cbc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xb78cc0: b               #0xb78cc8
    // 0xb78cc4: mov             x3, x5
    // 0xb78cc8: LoadField: r0 = r3->field_b
    //     0xb78cc8: ldur            w0, [x3, #0xb]
    // 0xb78ccc: DecompressPointer r0
    //     0xb78ccc: add             x0, x0, HEAP, lsl #32
    // 0xb78cd0: LoadField: r1 = r0->field_23
    //     0xb78cd0: ldur            w1, [x0, #0x23]
    // 0xb78cd4: DecompressPointer r1
    //     0xb78cd4: add             x1, x1, HEAP, lsl #32
    // 0xb78cd8: cmp             w1, NULL
    // 0xb78cdc: b.ne            #0xb78ce8
    // 0xb78ce0: r0 = Null
    //     0xb78ce0: mov             x0, NULL
    // 0xb78ce4: b               #0xb78cec
    // 0xb78ce8: mov             x0, x1
    // 0xb78cec: cmp             w0, NULL
    // 0xb78cf0: b.eq            #0xb78f6c
    // 0xb78cf4: LoadField: r1 = r0->field_37
    //     0xb78cf4: ldur            w1, [x0, #0x37]
    // 0xb78cf8: DecompressPointer r1
    //     0xb78cf8: add             x1, x1, HEAP, lsl #32
    // 0xb78cfc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb78d00: cmp             w1, w16
    // 0xb78d04: b.eq            #0xb78f70
    // 0xb78d08: LoadField: r0 = r3->field_37
    //     0xb78d08: ldur            w0, [x3, #0x37]
    // 0xb78d0c: DecompressPointer r0
    //     0xb78d0c: add             x0, x0, HEAP, lsl #32
    // 0xb78d10: LoadField: r2 = r0->field_7
    //     0xb78d10: ldur            x2, [x0, #7]
    // 0xb78d14: cmp             x2, #0
    // 0xb78d18: b.gt            #0xb78d34
    // 0xb78d1c: LoadField: d0 = r1->field_7
    //     0xb78d1c: ldur            d0, [x1, #7]
    // 0xb78d20: mov             x1, x3
    // 0xb78d24: ldur            x2, [fp, #-0x20]
    // 0xb78d28: r0 = _applyLinearEffect()
    //     0xb78d28: bl              #0xb7a340  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::_applyLinearEffect
    // 0xb78d2c: mov             x1, x0
    // 0xb78d30: b               #0xb78d48
    // 0xb78d34: LoadField: d0 = r1->field_7
    //     0xb78d34: ldur            d0, [x1, #7]
    // 0xb78d38: ldur            x1, [fp, #-0x10]
    // 0xb78d3c: ldur            x2, [fp, #-0x20]
    // 0xb78d40: r0 = _applyElasticEffect()
    //     0xb78d40: bl              #0xb78fac  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::_applyElasticEffect
    // 0xb78d44: mov             x1, x0
    // 0xb78d48: ldur            x2, [fp, #-0x10]
    // 0xb78d4c: mov             x0, x1
    // 0xb78d50: StoreField: r2->field_4b = r0
    //     0xb78d50: stur            w0, [x2, #0x4b]
    //     0xb78d54: ldurb           w16, [x2, #-1]
    //     0xb78d58: ldurb           w17, [x0, #-1]
    //     0xb78d5c: and             x16, x17, x16, lsr #2
    //     0xb78d60: tst             x16, HEAP, lsr #32
    //     0xb78d64: b.eq            #0xb78d6c
    //     0xb78d68: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb78d6c: r0 = size()
    //     0xb78d6c: bl              #0x8632d0  ; [dart:ui] Rect::size
    // 0xb78d70: mov             x1, x0
    // 0xb78d74: ldur            x0, [fp, #-0x10]
    // 0xb78d78: stur            x1, [fp, #-0x30]
    // 0xb78d7c: LoadField: r2 = r0->field_47
    //     0xb78d7c: ldur            w2, [x0, #0x47]
    // 0xb78d80: DecompressPointer r2
    //     0xb78d80: add             x2, x2, HEAP, lsl #32
    // 0xb78d84: stur            x2, [fp, #-0x28]
    // 0xb78d88: LoadField: d0 = r0->field_2f
    //     0xb78d88: ldur            d0, [x0, #0x2f]
    // 0xb78d8c: r3 = inline_Allocate_Double()
    //     0xb78d8c: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xb78d90: add             x3, x3, #0x10
    //     0xb78d94: cmp             x4, x3
    //     0xb78d98: b.ls            #0xb78f78
    //     0xb78d9c: str             x3, [THR, #0x60]  ; THR::top
    //     0xb78da0: sub             x3, x3, #0xf
    //     0xb78da4: mov             x4, #0xe19c
    //     0xb78da8: movk            x4, #3, lsl #16
    //     0xb78dac: stur            x4, [x3, #-1]
    // 0xb78db0: dmb             ishst
    // 0xb78db4: StoreField: r3->field_7 = d0
    //     0xb78db4: stur            d0, [x3, #7]
    // 0xb78db8: stur            x3, [fp, #-8]
    // 0xb78dbc: r0 = ImageConfiguration()
    //     0xb78dbc: bl              #0xb6d7b4  ; AllocateImageConfigurationStub -> ImageConfiguration (size=0x20)
    // 0xb78dc0: mov             x1, x0
    // 0xb78dc4: ldur            x0, [fp, #-8]
    // 0xb78dc8: stur            x1, [fp, #-0x38]
    // 0xb78dcc: StoreField: r1->field_b = r0
    //     0xb78dcc: stur            w0, [x1, #0xb]
    // 0xb78dd0: ldur            x0, [fp, #-0x28]
    // 0xb78dd4: StoreField: r1->field_13 = r0
    //     0xb78dd4: stur            w0, [x1, #0x13]
    // 0xb78dd8: ldur            x0, [fp, #-0x30]
    // 0xb78ddc: ArrayStore: r1[0] = r0  ; List_4
    //     0xb78ddc: stur            w0, [x1, #0x17]
    // 0xb78de0: ldur            x0, [fp, #-0x10]
    // 0xb78de4: LoadField: r2 = r0->field_2b
    //     0xb78de4: ldur            w2, [x0, #0x2b]
    // 0xb78de8: DecompressPointer r2
    //     0xb78de8: add             x2, x2, HEAP, lsl #32
    // 0xb78dec: tbnz            w2, #4, #0xb78ee0
    // 0xb78df0: d0 = 0.000000
    //     0xb78df0: eor             v0.16b, v0.16b, v0.16b
    // 0xb78df4: LoadField: r2 = r0->field_27
    //     0xb78df4: ldur            w2, [x0, #0x27]
    // 0xb78df8: DecompressPointer r2
    //     0xb78df8: add             x2, x2, HEAP, lsl #32
    // 0xb78dfc: cmp             w2, NULL
    // 0xb78e00: b.eq            #0xb78f9c
    // 0xb78e04: LoadField: d1 = r2->field_7
    //     0xb78e04: ldur            d1, [x2, #7]
    // 0xb78e08: stur            d1, [fp, #-0x40]
    // 0xb78e0c: fcmp            d1, d0
    // 0xb78e10: b.le            #0xb78ee0
    // 0xb78e14: ldur            x2, [fp, #-0x20]
    // 0xb78e18: r16 = 136
    //     0xb78e18: mov             x16, #0x88
    // 0xb78e1c: stp             x16, NULL, [SP]
    // 0xb78e20: r0 = ByteData()
    //     0xb78e20: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb78e24: stur            x0, [fp, #-8]
    // 0xb78e28: r0 = Paint()
    //     0xb78e28: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb78e2c: mov             x3, x0
    // 0xb78e30: ldur            x0, [fp, #-8]
    // 0xb78e34: stur            x3, [fp, #-0x28]
    // 0xb78e38: StoreField: r3->field_7 = r0
    //     0xb78e38: stur            w0, [x3, #7]
    // 0xb78e3c: ldur            x4, [fp, #-0x10]
    // 0xb78e40: LoadField: r2 = r4->field_23
    //     0xb78e40: ldur            w2, [x4, #0x23]
    // 0xb78e44: DecompressPointer r2
    //     0xb78e44: add             x2, x2, HEAP, lsl #32
    // 0xb78e48: cmp             w2, NULL
    // 0xb78e4c: b.eq            #0xb78fa0
    // 0xb78e50: mov             x1, x3
    // 0xb78e54: r0 = color=()
    //     0xb78e54: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb78e58: ldur            x0, [fp, #-8]
    // 0xb78e5c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb78e5c: ldur            w1, [x0, #0x17]
    // 0xb78e60: DecompressPointer r1
    //     0xb78e60: add             x1, x1, HEAP, lsl #32
    // 0xb78e64: ldur            d0, [fp, #-0x40]
    // 0xb78e68: fcvt            s1, d0
    // 0xb78e6c: LoadField: r0 = r1->field_7
    //     0xb78e6c: ldur            x0, [x1, #7]
    // 0xb78e70: str             s1, [x0, #0x20]
    // 0xb78e74: ldur            x0, [fp, #-0x20]
    // 0xb78e78: LoadField: d0 = r0->field_f
    //     0xb78e78: ldur            d0, [x0, #0xf]
    // 0xb78e7c: LoadField: r2 = r1->field_7
    //     0xb78e7c: ldur            x2, [x1, #7]
    // 0xb78e80: ldr             s1, [x2, #0x20]
    // 0xb78e84: fcvt            d2, s1
    // 0xb78e88: d1 = 2.000000
    //     0xb78e88: fmov            d1, #2.00000000
    // 0xb78e8c: fdiv            d3, d2, d1
    // 0xb78e90: fsub            d1, d0, d3
    // 0xb78e94: stur            d1, [fp, #-0x40]
    // 0xb78e98: r0 = Offset()
    //     0xb78e98: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb78e9c: stur            x0, [fp, #-8]
    // 0xb78ea0: StoreField: r0->field_7 = rZR
    //     0xb78ea0: stur            xzr, [x0, #7]
    // 0xb78ea4: ldur            d0, [fp, #-0x40]
    // 0xb78ea8: StoreField: r0->field_f = d0
    //     0xb78ea8: stur            d0, [x0, #0xf]
    // 0xb78eac: ldur            x1, [fp, #-0x20]
    // 0xb78eb0: LoadField: d1 = r1->field_7
    //     0xb78eb0: ldur            d1, [x1, #7]
    // 0xb78eb4: stur            d1, [fp, #-0x48]
    // 0xb78eb8: r0 = Offset()
    //     0xb78eb8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb78ebc: ldur            d0, [fp, #-0x48]
    // 0xb78ec0: StoreField: r0->field_7 = d0
    //     0xb78ec0: stur            d0, [x0, #7]
    // 0xb78ec4: ldur            d0, [fp, #-0x40]
    // 0xb78ec8: StoreField: r0->field_f = d0
    //     0xb78ec8: stur            d0, [x0, #0xf]
    // 0xb78ecc: ldur            x1, [fp, #-0x18]
    // 0xb78ed0: ldur            x2, [fp, #-8]
    // 0xb78ed4: mov             x3, x0
    // 0xb78ed8: ldur            x5, [fp, #-0x28]
    // 0xb78edc: r0 = drawLine()
    //     0xb78edc: bl              #0xb6932c  ; [dart:ui] _NativeCanvas::drawLine
    // 0xb78ee0: ldur            x0, [fp, #-0x10]
    // 0xb78ee4: LoadField: r1 = r0->field_4f
    //     0xb78ee4: ldur            w1, [x0, #0x4f]
    // 0xb78ee8: DecompressPointer r1
    //     0xb78ee8: add             x1, x1, HEAP, lsl #32
    // 0xb78eec: stur            x1, [fp, #-8]
    // 0xb78ef0: cmp             w1, NULL
    // 0xb78ef4: b.eq            #0xb78fa4
    // 0xb78ef8: LoadField: r2 = r0->field_4b
    //     0xb78ef8: ldur            w2, [x0, #0x4b]
    // 0xb78efc: DecompressPointer r2
    //     0xb78efc: add             x2, x2, HEAP, lsl #32
    // 0xb78f00: cmp             w2, NULL
    // 0xb78f04: b.eq            #0xb78fa8
    // 0xb78f08: LoadField: d0 = r2->field_7
    //     0xb78f08: ldur            d0, [x2, #7]
    // 0xb78f0c: stur            d0, [fp, #-0x48]
    // 0xb78f10: LoadField: d1 = r2->field_f
    //     0xb78f10: ldur            d1, [x2, #0xf]
    // 0xb78f14: stur            d1, [fp, #-0x40]
    // 0xb78f18: r0 = Offset()
    //     0xb78f18: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb78f1c: ldur            d0, [fp, #-0x48]
    // 0xb78f20: StoreField: r0->field_7 = d0
    //     0xb78f20: stur            d0, [x0, #7]
    // 0xb78f24: ldur            d0, [fp, #-0x40]
    // 0xb78f28: StoreField: r0->field_f = d0
    //     0xb78f28: stur            d0, [x0, #0xf]
    // 0xb78f2c: ldur            x1, [fp, #-8]
    // 0xb78f30: r2 = LoadClassIdInstr(r1)
    //     0xb78f30: ldur            x2, [x1, #-1]
    //     0xb78f34: ubfx            x2, x2, #0xc, #0x14
    // 0xb78f38: mov             x3, x0
    // 0xb78f3c: mov             x0, x2
    // 0xb78f40: ldur            x2, [fp, #-0x18]
    // 0xb78f44: ldur            x5, [fp, #-0x38]
    // 0xb78f48: r0 = GDT[cid_x0 + -0xffc]()
    //     0xb78f48: sub             lr, x0, #0xffc
    //     0xb78f4c: ldr             lr, [x21, lr, lsl #3]
    //     0xb78f50: blr             lr
    // 0xb78f54: r0 = Null
    //     0xb78f54: mov             x0, NULL
    // 0xb78f58: LeaveFrame
    //     0xb78f58: mov             SP, fp
    //     0xb78f5c: ldp             fp, lr, [SP], #0x10
    // 0xb78f60: ret
    //     0xb78f60: ret             
    // 0xb78f64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb78f64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb78f68: b               #0xb78b8c
    // 0xb78f6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb78f6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb78f70: r9 = _value
    //     0xb78f70: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xb78f74: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb78f74: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xb78f78: SaveReg d0
    //     0xb78f78: str             q0, [SP, #-0x10]!
    // 0xb78f7c: stp             x1, x2, [SP, #-0x10]!
    // 0xb78f80: SaveReg r0
    //     0xb78f80: str             x0, [SP, #-8]!
    // 0xb78f84: r0 = AllocateDouble()
    //     0xb78f84: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb78f88: mov             x3, x0
    // 0xb78f8c: RestoreReg r0
    //     0xb78f8c: ldr             x0, [SP], #8
    // 0xb78f90: ldp             x1, x2, [SP], #0x10
    // 0xb78f94: RestoreReg d0
    //     0xb78f94: ldr             q0, [SP], #0x10
    // 0xb78f98: b               #0xb78db4
    // 0xb78f9c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb78f9c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb78fa0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb78fa0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb78fa4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb78fa4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb78fa8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb78fa8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _applyElasticEffect(/* No info */) {
    // ** addr: 0xb78fac, size: 0xd4c
    // 0xb78fac: EnterFrame
    //     0xb78fac: stp             fp, lr, [SP, #-0x10]!
    //     0xb78fb0: mov             fp, SP
    // 0xb78fb4: AllocStack(0x68)
    //     0xb78fb4: sub             SP, SP, #0x68
    // 0xb78fb8: SetupParameters(_IndicatorPainter this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x40 */)
    //     0xb78fb8: mov             x3, x1
    //     0xb78fbc: stur            x1, [fp, #-0x10]
    //     0xb78fc0: stur            x2, [fp, #-0x18]
    //     0xb78fc4: stur            d0, [fp, #-0x40]
    // 0xb78fc8: CheckStackOverflow
    //     0xb78fc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb78fcc: cmp             SP, x16
    //     0xb78fd0: b.ls            #0xb799e8
    // 0xb78fd4: LoadField: r4 = r3->field_b
    //     0xb78fd4: ldur            w4, [x3, #0xb]
    // 0xb78fd8: DecompressPointer r4
    //     0xb78fd8: add             x4, x4, HEAP, lsl #32
    // 0xb78fdc: stur            x4, [fp, #-8]
    // 0xb78fe0: LoadField: r5 = r4->field_33
    //     0xb78fe0: ldur            x5, [x4, #0x33]
    // 0xb78fe4: r0 = BoxInt64Instr(r5)
    //     0xb78fe4: sbfiz           x0, x5, #1, #0x1f
    //     0xb78fe8: cmp             x5, x0, asr #1
    //     0xb78fec: b.eq            #0xb78ff8
    //     0xb78ff0: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0xb78ff4: stur            x5, [x0, #7]
    // 0xb78ff8: stp             x0, NULL, [SP]
    // 0xb78ffc: r0 = _Double.fromInteger()
    //     0xb78ffc: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0xb79000: LoadField: d0 = r0->field_7
    //     0xb79000: ldur            d0, [x0, #7]
    // 0xb79004: ldur            d1, [fp, #-0x40]
    // 0xb79008: stur            d0, [fp, #-0x58]
    // 0xb7900c: fsub            d2, d0, d1
    // 0xb79010: stur            d2, [fp, #-0x50]
    // 0xb79014: d3 = 0.000000
    //     0xb79014: eor             v3.16b, v3.16b, v3.16b
    // 0xb79018: fcmp            d2, d3
    // 0xb7901c: b.ne            #0xb79028
    // 0xb79020: d4 = 0.000000
    //     0xb79020: eor             v4.16b, v4.16b, v4.16b
    // 0xb79024: b               #0xb7903c
    // 0xb79028: fcmp            d3, d2
    // 0xb7902c: b.le            #0xb79038
    // 0xb79030: fneg            d4, d2
    // 0xb79034: b               #0xb7903c
    // 0xb79038: mov             v4.16b, v2.16b
    // 0xb7903c: stur            d4, [fp, #-0x48]
    // 0xb79040: fcmp            d4, d3
    // 0xb79044: b.ne            #0xb79050
    // 0xb79048: ldur            x1, [fp, #-8]
    // 0xb7904c: b               #0xb7905c
    // 0xb79050: ldur            x1, [fp, #-8]
    // 0xb79054: LoadField: r0 = r1->field_43
    //     0xb79054: ldur            x0, [x1, #0x43]
    // 0xb79058: cbnz            x0, #0xb79164
    // 0xb7905c: ldur            x2, [fp, #-0x10]
    // 0xb79060: LoadField: r0 = r2->field_3b
    //     0xb79060: ldur            w0, [x2, #0x3b]
    // 0xb79064: DecompressPointer r0
    //     0xb79064: add             x0, x0, HEAP, lsl #32
    // 0xb79068: LoadField: r3 = r0->field_7
    //     0xb79068: ldur            x3, [x0, #7]
    // 0xb7906c: cmp             x3, #0
    // 0xb79070: b.gt            #0xb790a0
    // 0xb79074: fcmp            d1, d1
    // 0xb79078: b.vs            #0xb799f0
    // 0xb7907c: fcvtms          x0, d1
    // 0xb79080: asr             x16, x0, #0x1e
    // 0xb79084: cmp             x16, x0, asr #63
    // 0xb79088: b.ne            #0xb799f0
    // 0xb7908c: lsl             x0, x0, #1
    // 0xb79090: r3 = LoadInt32Instr(r0)
    //     0xb79090: sbfx            x3, x0, #1, #0x1f
    //     0xb79094: tbz             w0, #0, #0xb7909c
    //     0xb79098: ldur            x3, [x0, #7]
    // 0xb7909c: b               #0xb790c8
    // 0xb790a0: fcmp            d1, d1
    // 0xb790a4: b.vs            #0xb79a28
    // 0xb790a8: fcvtps          x0, d1
    // 0xb790ac: asr             x16, x0, #0x1e
    // 0xb790b0: cmp             x16, x0, asr #63
    // 0xb790b4: b.ne            #0xb79a28
    // 0xb790b8: lsl             x0, x0, #1
    // 0xb790bc: r3 = LoadInt32Instr(r0)
    //     0xb790bc: sbfx            x3, x0, #1, #0x1f
    //     0xb790c0: tbz             w0, #0, #0xb790c8
    //     0xb790c4: ldur            x3, [x0, #7]
    // 0xb790c8: stur            x3, [fp, #-0x20]
    // 0xb790cc: LoadField: r0 = r2->field_43
    //     0xb790cc: ldur            w0, [x2, #0x43]
    // 0xb790d0: DecompressPointer r0
    //     0xb790d0: add             x0, x0, HEAP, lsl #32
    // 0xb790d4: cmp             w0, NULL
    // 0xb790d8: b.eq            #0xb79a60
    // 0xb790dc: r4 = LoadClassIdInstr(r0)
    //     0xb790dc: ldur            x4, [x0, #-1]
    //     0xb790e0: ubfx            x4, x4, #0xc, #0x14
    // 0xb790e4: str             x0, [SP]
    // 0xb790e8: mov             x0, x4
    // 0xb790ec: r0 = GDT[cid_x0 + 0xf078]()
    //     0xb790ec: mov             x17, #0xf078
    //     0xb790f0: add             lr, x0, x17
    //     0xb790f4: ldr             lr, [x21, lr, lsl #3]
    //     0xb790f8: blr             lr
    // 0xb790fc: r1 = LoadInt32Instr(r0)
    //     0xb790fc: sbfx            x1, x0, #1, #0x1f
    //     0xb79100: tbz             w0, #0, #0xb79108
    //     0xb79104: ldur            x1, [x0, #7]
    // 0xb79108: sub             x2, x1, #2
    // 0xb7910c: ldur            x3, [fp, #-0x20]
    // 0xb79110: r0 = BoxInt64Instr(r3)
    //     0xb79110: sbfiz           x0, x3, #1, #0x1f
    //     0xb79114: cmp             x3, x0, asr #1
    //     0xb79118: b.eq            #0xb79124
    //     0xb7911c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb79120: stur            x3, [x0, #7]
    // 0xb79124: mov             x3, x0
    // 0xb79128: r0 = BoxInt64Instr(r2)
    //     0xb79128: sbfiz           x0, x2, #1, #0x1f
    //     0xb7912c: cmp             x2, x0, asr #1
    //     0xb79130: b.eq            #0xb7913c
    //     0xb79134: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb79138: stur            x2, [x0, #7]
    // 0xb7913c: mov             x1, x3
    // 0xb79140: mov             x3, x0
    // 0xb79144: r2 = 0
    //     0xb79144: mov             x2, #0
    // 0xb79148: r0 = clamp()
    //     0xb79148: bl              #0x13db4a0  ; [dart:core] _IntegerImplementation::clamp
    // 0xb7914c: r1 = LoadInt32Instr(r0)
    //     0xb7914c: sbfx            x1, x0, #1, #0x1f
    //     0xb79150: tbz             w0, #0, #0xb79158
    //     0xb79154: ldur            x1, [x0, #7]
    // 0xb79158: mov             x3, x1
    // 0xb7915c: ldur            x0, [fp, #-8]
    // 0xb79160: b               #0xb79170
    // 0xb79164: mov             x0, x1
    // 0xb79168: LoadField: r1 = r0->field_33
    //     0xb79168: ldur            x1, [x0, #0x33]
    // 0xb7916c: mov             x3, x1
    // 0xb79170: ldur            d1, [fp, #-0x48]
    // 0xb79174: d0 = 0.000000
    //     0xb79174: eor             v0.16b, v0.16b, v0.16b
    // 0xb79178: stur            x3, [fp, #-0x28]
    // 0xb7917c: fcmp            d1, d0
    // 0xb79180: b.eq            #0xb7918c
    // 0xb79184: LoadField: r1 = r0->field_43
    //     0xb79184: ldur            x1, [x0, #0x43]
    // 0xb79188: cbnz            x1, #0xb79220
    // 0xb7918c: ldur            x2, [fp, #-0x10]
    // 0xb79190: LoadField: r1 = r2->field_3b
    //     0xb79190: ldur            w1, [x2, #0x3b]
    // 0xb79194: DecompressPointer r1
    //     0xb79194: add             x1, x1, HEAP, lsl #32
    // 0xb79198: LoadField: r4 = r1->field_7
    //     0xb79198: ldur            x4, [x1, #7]
    // 0xb7919c: cmp             x4, #0
    // 0xb791a0: b.gt            #0xb791b0
    // 0xb791a4: add             x1, x3, #1
    // 0xb791a8: mov             x4, x1
    // 0xb791ac: b               #0xb791b8
    // 0xb791b0: sub             x1, x3, #1
    // 0xb791b4: mov             x4, x1
    // 0xb791b8: mov             x1, x2
    // 0xb791bc: stur            x4, [fp, #-0x20]
    // 0xb791c0: r0 = maxTabIndex()
    //     0xb791c0: bl              #0xb7a2d0  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::maxTabIndex
    // 0xb791c4: mov             x3, x0
    // 0xb791c8: ldur            x2, [fp, #-0x20]
    // 0xb791cc: r0 = BoxInt64Instr(r2)
    //     0xb791cc: sbfiz           x0, x2, #1, #0x1f
    //     0xb791d0: cmp             x2, x0, asr #1
    //     0xb791d4: b.eq            #0xb791e0
    //     0xb791d8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb791dc: stur            x2, [x0, #7]
    // 0xb791e0: mov             x2, x0
    // 0xb791e4: r0 = BoxInt64Instr(r3)
    //     0xb791e4: sbfiz           x0, x3, #1, #0x1f
    //     0xb791e8: cmp             x3, x0, asr #1
    //     0xb791ec: b.eq            #0xb791f8
    //     0xb791f0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb791f4: stur            x3, [x0, #7]
    // 0xb791f8: mov             x1, x2
    // 0xb791fc: mov             x3, x0
    // 0xb79200: r2 = 0
    //     0xb79200: mov             x2, #0
    // 0xb79204: r0 = clamp()
    //     0xb79204: bl              #0x13db4a0  ; [dart:core] _IntegerImplementation::clamp
    // 0xb79208: r1 = LoadInt32Instr(r0)
    //     0xb79208: sbfx            x1, x0, #1, #0x1f
    //     0xb7920c: tbz             w0, #0, #0xb79214
    //     0xb79210: ldur            x1, [x0, #7]
    // 0xb79214: mov             x4, x1
    // 0xb79218: ldur            x0, [fp, #-8]
    // 0xb7921c: b               #0xb79228
    // 0xb79220: LoadField: r1 = r0->field_3b
    //     0xb79220: ldur            x1, [x0, #0x3b]
    // 0xb79224: mov             x4, x1
    // 0xb79228: ldur            d0, [fp, #-0x40]
    // 0xb7922c: ldur            x1, [fp, #-0x10]
    // 0xb79230: ldur            x2, [fp, #-0x18]
    // 0xb79234: ldur            x3, [fp, #-0x28]
    // 0xb79238: stur            x4, [fp, #-0x20]
    // 0xb7923c: r0 = indicatorRect()
    //     0xb7923c: bl              #0xb79cf8  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::indicatorRect
    // 0xb79240: ldur            x1, [fp, #-0x10]
    // 0xb79244: ldur            x2, [fp, #-0x18]
    // 0xb79248: ldur            x3, [fp, #-0x20]
    // 0xb7924c: stur            x0, [fp, #-0x18]
    // 0xb79250: r0 = indicatorRect()
    //     0xb79250: bl              #0xb79cf8  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::indicatorRect
    // 0xb79254: mov             x3, x0
    // 0xb79258: ldur            x0, [fp, #-0x20]
    // 0xb7925c: stur            x3, [fp, #-0x30]
    // 0xb79260: scvtf           d0, x0
    // 0xb79264: ldur            d1, [fp, #-0x40]
    // 0xb79268: fsub            d2, d1, d0
    // 0xb7926c: d3 = 0.000000
    //     0xb7926c: eor             v3.16b, v3.16b, v3.16b
    // 0xb79270: fcmp            d2, d3
    // 0xb79274: b.ne            #0xb79280
    // 0xb79278: d0 = 0.000000
    //     0xb79278: eor             v0.16b, v0.16b, v0.16b
    // 0xb7927c: b               #0xb79294
    // 0xb79280: fcmp            d3, d2
    // 0xb79284: b.le            #0xb79290
    // 0xb79288: fneg            d0, d2
    // 0xb7928c: b               #0xb79294
    // 0xb79290: mov             v0.16b, v2.16b
    // 0xb79294: ldur            x0, [fp, #-8]
    // 0xb79298: mov             x1, x3
    // 0xb7929c: ldur            x2, [fp, #-0x18]
    // 0xb792a0: r0 = lerp()
    //     0xb792a0: bl              #0xae0924  ; [dart:ui] Rect::lerp
    // 0xb792a4: mov             x19, x0
    // 0xb792a8: ldur            x0, [fp, #-8]
    // 0xb792ac: stur            x19, [fp, #-0x38]
    // 0xb792b0: LoadField: r1 = r0->field_23
    //     0xb792b0: ldur            w1, [x0, #0x23]
    // 0xb792b4: DecompressPointer r1
    //     0xb792b4: add             x1, x1, HEAP, lsl #32
    // 0xb792b8: cmp             w1, NULL
    // 0xb792bc: b.ne            #0xb792c4
    // 0xb792c0: r1 = Null
    //     0xb792c0: mov             x1, NULL
    // 0xb792c4: cmp             w1, NULL
    // 0xb792c8: b.eq            #0xb79a64
    // 0xb792cc: LoadField: r2 = r1->field_43
    //     0xb792cc: ldur            w2, [x1, #0x43]
    // 0xb792d0: DecompressPointer r2
    //     0xb792d0: add             x2, x2, HEAP, lsl #32
    // 0xb792d4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb792d8: cmp             w2, w16
    // 0xb792dc: b.eq            #0xb79a68
    // 0xb792e0: r16 = Instance_AnimationStatus
    //     0xb792e0: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0xb792e4: cmp             w2, w16
    // 0xb792e8: b.ne            #0xb792fc
    // 0xb792ec: mov             x0, x19
    // 0xb792f0: LeaveFrame
    //     0xb792f0: mov             SP, fp
    //     0xb792f4: ldp             fp, lr, [SP], #0x10
    // 0xb792f8: ret
    //     0xb792f8: ret             
    // 0xb792fc: LoadField: r20 = r0->field_43
    //     0xb792fc: ldur            x20, [x0, #0x43]
    // 0xb79300: cbz             x20, #0xb79388
    // 0xb79304: LoadField: r1 = r0->field_33
    //     0xb79304: ldur            x1, [x0, #0x33]
    // 0xb79308: LoadField: r2 = r0->field_3b
    //     0xb79308: ldur            x2, [x0, #0x3b]
    // 0xb7930c: sub             x0, x1, x2
    // 0xb79310: tbz             x0, #0x3f, #0xb7931c
    // 0xb79314: neg             x1, x0
    // 0xb79318: mov             x0, x1
    // 0xb7931c: cbz             x0, #0xb79334
    // 0xb79320: ldur            d0, [fp, #-0x48]
    // 0xb79324: scvtf           d1, x0
    // 0xb79328: fdiv            d2, d0, d1
    // 0xb7932c: mov             v1.16b, v2.16b
    // 0xb79330: b               #0xb7933c
    // 0xb79334: ldur            d0, [fp, #-0x48]
    // 0xb79338: mov             v1.16b, v0.16b
    // 0xb7933c: d0 = 0.000000
    //     0xb7933c: eor             v0.16b, v0.16b, v0.16b
    // 0xb79340: fcmp            d0, d1
    // 0xb79344: b.le            #0xb79354
    // 0xb79348: d0 = 0.000000
    //     0xb79348: eor             v0.16b, v0.16b, v0.16b
    // 0xb7934c: d2 = 1.000000
    //     0xb7934c: fmov            d2, #1.00000000
    // 0xb79350: b               #0xb7937c
    // 0xb79354: d2 = 1.000000
    //     0xb79354: fmov            d2, #1.00000000
    // 0xb79358: fcmp            d1, d2
    // 0xb7935c: b.le            #0xb79368
    // 0xb79360: d0 = 1.000000
    //     0xb79360: fmov            d0, #1.00000000
    // 0xb79364: b               #0xb7937c
    // 0xb79368: fcmp            d1, d1
    // 0xb7936c: b.vc            #0xb79378
    // 0xb79370: d0 = 1.000000
    //     0xb79370: fmov            d0, #1.00000000
    // 0xb79374: b               #0xb7937c
    // 0xb79378: mov             v0.16b, v1.16b
    // 0xb7937c: fsub            d1, d2, d0
    // 0xb79380: mov             v0.16b, v1.16b
    // 0xb79384: b               #0xb793b8
    // 0xb79388: ldur            d1, [fp, #-0x50]
    // 0xb7938c: d2 = 1.000000
    //     0xb7938c: fmov            d2, #1.00000000
    // 0xb79390: d0 = 0.000000
    //     0xb79390: eor             v0.16b, v0.16b, v0.16b
    // 0xb79394: fcmp            d1, d0
    // 0xb79398: b.ne            #0xb793a4
    // 0xb7939c: d0 = 0.000000
    //     0xb7939c: eor             v0.16b, v0.16b, v0.16b
    // 0xb793a0: b               #0xb793b8
    // 0xb793a4: fcmp            d0, d1
    // 0xb793a8: b.le            #0xb793b4
    // 0xb793ac: fneg            d0, d1
    // 0xb793b0: b               #0xb793b8
    // 0xb793b4: mov             v0.16b, v1.16b
    // 0xb793b8: fcmp            d0, d2
    // 0xb793bc: b.ne            #0xb793d0
    // 0xb793c0: mov             x0, x19
    // 0xb793c4: LeaveFrame
    //     0xb793c4: mov             SP, fp
    //     0xb793c8: ldp             fp, lr, [SP], #0x10
    // 0xb793cc: ret
    //     0xb793cc: ret             
    // 0xb793d0: ldur            x0, [fp, #-0x10]
    // 0xb793d4: LoadField: r1 = r0->field_3b
    //     0xb793d4: ldur            w1, [x0, #0x3b]
    // 0xb793d8: DecompressPointer r1
    //     0xb793d8: add             x1, x1, HEAP, lsl #32
    // 0xb793dc: LoadField: r0 = r1->field_7
    //     0xb793dc: ldur            x0, [x1, #7]
    // 0xb793e0: cmp             x0, #0
    // 0xb793e4: b.gt            #0xb79428
    // 0xb793e8: cbz             x20, #0xb79408
    // 0xb793ec: ldur            d1, [fp, #-0x40]
    // 0xb793f0: ldur            d3, [fp, #-0x58]
    // 0xb793f4: fcmp            d1, d3
    // 0xb793f8: r16 = true
    //     0xb793f8: add             x16, NULL, #0x20  ; true
    // 0xb793fc: r17 = false
    //     0xb793fc: add             x17, NULL, #0x30  ; false
    // 0xb79400: csel            x0, x16, x17, gt
    // 0xb79404: b               #0xb79420
    // 0xb79408: ldur            d1, [fp, #-0x40]
    // 0xb7940c: ldur            d3, [fp, #-0x58]
    // 0xb79410: fcmp            d3, d1
    // 0xb79414: r16 = true
    //     0xb79414: add             x16, NULL, #0x20  ; true
    // 0xb79418: r17 = false
    //     0xb79418: add             x17, NULL, #0x30  ; false
    // 0xb7941c: csel            x0, x16, x17, gt
    // 0xb79420: mov             x23, x0
    // 0xb79424: b               #0xb7945c
    // 0xb79428: ldur            d1, [fp, #-0x40]
    // 0xb7942c: ldur            d3, [fp, #-0x58]
    // 0xb79430: cbz             x20, #0xb79448
    // 0xb79434: fcmp            d3, d1
    // 0xb79438: r16 = true
    //     0xb79438: add             x16, NULL, #0x20  ; true
    // 0xb7943c: r17 = false
    //     0xb7943c: add             x17, NULL, #0x30  ; false
    // 0xb79440: csel            x0, x16, x17, gt
    // 0xb79444: b               #0xb79458
    // 0xb79448: fcmp            d1, d3
    // 0xb7944c: r16 = true
    //     0xb7944c: add             x16, NULL, #0x20  ; true
    // 0xb79450: r17 = false
    //     0xb79450: add             x17, NULL, #0x30  ; false
    // 0xb79454: csel            x0, x16, x17, gt
    // 0xb79458: mov             x23, x0
    // 0xb7945c: stur            x23, [fp, #-0x10]
    // 0xb79460: tbnz            w23, #4, #0xb79500
    // 0xb79464: d3 = 3.141593
    //     0xb79464: add             x17, PP, #0x13, lsl #12  ; [pp+0x13178] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0xb79468: ldr             d3, [x17, #0x178]
    // 0xb7946c: d1 = 2.000000
    //     0xb7946c: fmov            d1, #2.00000000
    // 0xb79470: fmul            d4, d0, d3
    // 0xb79474: fdiv            d3, d4, d1
    // 0xb79478: mov             v0.16b, v3.16b
    // 0xb7947c: stur            d3, [fp, #-0x40]
    // 0xb79480: stp             fp, lr, [SP, #-0x10]!
    // 0xb79484: mov             fp, SP
    // 0xb79488: CallRuntime_LibcCos(double) -> double
    //     0xb79488: and             SP, SP, #0xfffffffffffffff0
    //     0xb7948c: mov             sp, SP
    //     0xb79490: ldr             x16, [THR, #0x778]  ; THR::LibcCos
    //     0xb79494: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb79498: blr             x16
    //     0xb7949c: mov             x16, #8
    //     0xb794a0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb794a4: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xb794a8: sub             sp, x16, #1, lsl #12
    //     0xb794ac: mov             SP, fp
    //     0xb794b0: ldp             fp, lr, [SP], #0x10
    // 0xb794b4: d2 = 1.000000
    //     0xb794b4: fmov            d2, #1.00000000
    // 0xb794b8: fsub            d1, d2, d0
    // 0xb794bc: ldur            d0, [fp, #-0x40]
    // 0xb794c0: stur            d1, [fp, #-0x48]
    // 0xb794c4: stp             fp, lr, [SP, #-0x10]!
    // 0xb794c8: mov             fp, SP
    // 0xb794cc: CallRuntime_LibcSin(double) -> double
    //     0xb794cc: and             SP, SP, #0xfffffffffffffff0
    //     0xb794d0: mov             sp, SP
    //     0xb794d4: ldr             x16, [THR, #0x780]  ; THR::LibcSin
    //     0xb794d8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb794dc: blr             x16
    //     0xb794e0: mov             x16, #8
    //     0xb794e4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb794e8: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xb794ec: sub             sp, x16, #1, lsl #12
    //     0xb794f0: mov             SP, fp
    //     0xb794f4: ldp             fp, lr, [SP], #0x10
    // 0xb794f8: ldur            d1, [fp, #-0x48]
    // 0xb794fc: b               #0xb795a4
    // 0xb79500: d3 = 3.141593
    //     0xb79500: add             x17, PP, #0x13, lsl #12  ; [pp+0x13178] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0xb79504: ldr             d3, [x17, #0x178]
    // 0xb79508: d1 = 2.000000
    //     0xb79508: fmov            d1, #2.00000000
    // 0xb7950c: fmul            d4, d0, d3
    // 0xb79510: fdiv            d3, d4, d1
    // 0xb79514: mov             v0.16b, v3.16b
    // 0xb79518: stur            d3, [fp, #-0x40]
    // 0xb7951c: stp             fp, lr, [SP, #-0x10]!
    // 0xb79520: mov             fp, SP
    // 0xb79524: CallRuntime_LibcSin(double) -> double
    //     0xb79524: and             SP, SP, #0xfffffffffffffff0
    //     0xb79528: mov             sp, SP
    //     0xb7952c: ldr             x16, [THR, #0x780]  ; THR::LibcSin
    //     0xb79530: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb79534: blr             x16
    //     0xb79538: mov             x16, #8
    //     0xb7953c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb79540: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xb79544: sub             sp, x16, #1, lsl #12
    //     0xb79548: mov             SP, fp
    //     0xb7954c: ldp             fp, lr, [SP], #0x10
    // 0xb79550: mov             v1.16b, v0.16b
    // 0xb79554: ldur            d0, [fp, #-0x40]
    // 0xb79558: stur            d1, [fp, #-0x40]
    // 0xb7955c: stp             fp, lr, [SP, #-0x10]!
    // 0xb79560: mov             fp, SP
    // 0xb79564: CallRuntime_LibcCos(double) -> double
    //     0xb79564: and             SP, SP, #0xfffffffffffffff0
    //     0xb79568: mov             sp, SP
    //     0xb7956c: ldr             x16, [THR, #0x778]  ; THR::LibcCos
    //     0xb79570: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb79574: blr             x16
    //     0xb79578: mov             x16, #8
    //     0xb7957c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb79580: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xb79584: sub             sp, x16, #1, lsl #12
    //     0xb79588: mov             SP, fp
    //     0xb7958c: ldp             fp, lr, [SP], #0x10
    // 0xb79590: mov             v1.16b, v0.16b
    // 0xb79594: d0 = 1.000000
    //     0xb79594: fmov            d0, #1.00000000
    // 0xb79598: fsub            d2, d0, d1
    // 0xb7959c: ldur            d1, [fp, #-0x40]
    // 0xb795a0: mov             v0.16b, v2.16b
    // 0xb795a4: stur            d0, [fp, #-0x40]
    // 0xb795a8: cbz             x20, #0xb79708
    // 0xb795ac: ldur            x4, [fp, #-0x18]
    // 0xb795b0: ldur            x0, [fp, #-0x30]
    // 0xb795b4: LoadField: d2 = r0->field_7
    //     0xb795b4: ldur            d2, [x0, #7]
    // 0xb795b8: LoadField: d3 = r4->field_7
    //     0xb795b8: ldur            d3, [x4, #7]
    // 0xb795bc: r3 = inline_Allocate_Double()
    //     0xb795bc: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0xb795c0: add             x3, x3, #0x10
    //     0xb795c4: cmp             x1, x3
    //     0xb795c8: b.ls            #0xb79a70
    //     0xb795cc: str             x3, [THR, #0x60]  ; THR::top
    //     0xb795d0: sub             x3, x3, #0xf
    //     0xb795d4: mov             x1, #0xe19c
    //     0xb795d8: movk            x1, #3, lsl #16
    //     0xb795dc: stur            x1, [x3, #-1]
    // 0xb795e0: dmb             ishst
    // 0xb795e4: StoreField: r3->field_7 = d1
    //     0xb795e4: stur            d1, [x3, #7]
    // 0xb795e8: r1 = inline_Allocate_Double()
    //     0xb795e8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb795ec: add             x1, x1, #0x10
    //     0xb795f0: cmp             x2, x1
    //     0xb795f4: b.ls            #0xb79a9c
    //     0xb795f8: str             x1, [THR, #0x60]  ; THR::top
    //     0xb795fc: sub             x1, x1, #0xf
    //     0xb79600: mov             x2, #0xe19c
    //     0xb79604: movk            x2, #3, lsl #16
    //     0xb79608: stur            x2, [x1, #-1]
    // 0xb7960c: dmb             ishst
    // 0xb79610: StoreField: r1->field_7 = d2
    //     0xb79610: stur            d2, [x1, #7]
    // 0xb79614: r2 = inline_Allocate_Double()
    //     0xb79614: ldp             x2, x5, [THR, #0x60]  ; THR::top
    //     0xb79618: add             x2, x2, #0x10
    //     0xb7961c: cmp             x5, x2
    //     0xb79620: b.ls            #0xb79ac8
    //     0xb79624: str             x2, [THR, #0x60]  ; THR::top
    //     0xb79628: sub             x2, x2, #0xf
    //     0xb7962c: mov             x5, #0xe19c
    //     0xb79630: movk            x5, #3, lsl #16
    //     0xb79634: stur            x5, [x2, #-1]
    // 0xb79638: dmb             ishst
    // 0xb7963c: StoreField: r2->field_7 = d3
    //     0xb7963c: stur            d3, [x2, #7]
    // 0xb79640: r0 = lerpDouble()
    //     0xb79640: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xb79644: mov             x4, x0
    // 0xb79648: ldur            x0, [fp, #-0x30]
    // 0xb7964c: stur            x4, [fp, #-8]
    // 0xb79650: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xb79650: ldur            d0, [x0, #0x17]
    // 0xb79654: ldur            x5, [fp, #-0x18]
    // 0xb79658: ArrayLoad: d1 = r5[0]  ; List_8
    //     0xb79658: ldur            d1, [x5, #0x17]
    // 0xb7965c: ldur            d2, [fp, #-0x40]
    // 0xb79660: r3 = inline_Allocate_Double()
    //     0xb79660: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xb79664: add             x3, x3, #0x10
    //     0xb79668: cmp             x0, x3
    //     0xb7966c: b.ls            #0xb79af4
    //     0xb79670: str             x3, [THR, #0x60]  ; THR::top
    //     0xb79674: sub             x3, x3, #0xf
    //     0xb79678: mov             x0, #0xe19c
    //     0xb7967c: movk            x0, #3, lsl #16
    //     0xb79680: stur            x0, [x3, #-1]
    // 0xb79684: dmb             ishst
    // 0xb79688: StoreField: r3->field_7 = d2
    //     0xb79688: stur            d2, [x3, #7]
    // 0xb7968c: r1 = inline_Allocate_Double()
    //     0xb7968c: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0xb79690: add             x1, x1, #0x10
    //     0xb79694: cmp             x0, x1
    //     0xb79698: b.ls            #0xb79b18
    //     0xb7969c: str             x1, [THR, #0x60]  ; THR::top
    //     0xb796a0: sub             x1, x1, #0xf
    //     0xb796a4: mov             x0, #0xe19c
    //     0xb796a8: movk            x0, #3, lsl #16
    //     0xb796ac: stur            x0, [x1, #-1]
    // 0xb796b0: dmb             ishst
    // 0xb796b4: StoreField: r1->field_7 = d0
    //     0xb796b4: stur            d0, [x1, #7]
    // 0xb796b8: r2 = inline_Allocate_Double()
    //     0xb796b8: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xb796bc: add             x2, x2, #0x10
    //     0xb796c0: cmp             x0, x2
    //     0xb796c4: b.ls            #0xb79b34
    //     0xb796c8: str             x2, [THR, #0x60]  ; THR::top
    //     0xb796cc: sub             x2, x2, #0xf
    //     0xb796d0: mov             x0, #0xe19c
    //     0xb796d4: movk            x0, #3, lsl #16
    //     0xb796d8: stur            x0, [x2, #-1]
    // 0xb796dc: dmb             ishst
    // 0xb796e0: StoreField: r2->field_7 = d1
    //     0xb796e0: stur            d1, [x2, #7]
    // 0xb796e4: r0 = lerpDouble()
    //     0xb796e4: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xb796e8: mov             x1, x0
    // 0xb796ec: ldur            x0, [fp, #-8]
    // 0xb796f0: LoadField: d0 = r0->field_7
    //     0xb796f0: ldur            d0, [x0, #7]
    // 0xb796f4: LoadField: d1 = r1->field_7
    //     0xb796f4: ldur            d1, [x1, #7]
    // 0xb796f8: mov             v31.16b, v1.16b
    // 0xb796fc: mov             v1.16b, v0.16b
    // 0xb79700: mov             v0.16b, v31.16b
    // 0xb79704: b               #0xb7999c
    // 0xb79708: ldur            x5, [fp, #-0x18]
    // 0xb7970c: ldur            x0, [fp, #-0x30]
    // 0xb79710: mov             v2.16b, v0.16b
    // 0xb79714: tbnz            w23, #4, #0xb797b0
    // 0xb79718: LoadField: d0 = r0->field_7
    //     0xb79718: ldur            d0, [x0, #7]
    // 0xb7971c: LoadField: d3 = r5->field_7
    //     0xb7971c: ldur            d3, [x5, #7]
    // 0xb79720: r3 = inline_Allocate_Double()
    //     0xb79720: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0xb79724: add             x3, x3, #0x10
    //     0xb79728: cmp             x1, x3
    //     0xb7972c: b.ls            #0xb79b58
    //     0xb79730: str             x3, [THR, #0x60]  ; THR::top
    //     0xb79734: sub             x3, x3, #0xf
    //     0xb79738: mov             x1, #0xe19c
    //     0xb7973c: movk            x1, #3, lsl #16
    //     0xb79740: stur            x1, [x3, #-1]
    // 0xb79744: dmb             ishst
    // 0xb79748: StoreField: r3->field_7 = d1
    //     0xb79748: stur            d1, [x3, #7]
    // 0xb7974c: r1 = inline_Allocate_Double()
    //     0xb7974c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb79750: add             x1, x1, #0x10
    //     0xb79754: cmp             x2, x1
    //     0xb79758: b.ls            #0xb79b84
    //     0xb7975c: str             x1, [THR, #0x60]  ; THR::top
    //     0xb79760: sub             x1, x1, #0xf
    //     0xb79764: mov             x2, #0xe19c
    //     0xb79768: movk            x2, #3, lsl #16
    //     0xb7976c: stur            x2, [x1, #-1]
    // 0xb79770: dmb             ishst
    // 0xb79774: StoreField: r1->field_7 = d0
    //     0xb79774: stur            d0, [x1, #7]
    // 0xb79778: r2 = inline_Allocate_Double()
    //     0xb79778: ldp             x2, x4, [THR, #0x60]  ; THR::top
    //     0xb7977c: add             x2, x2, #0x10
    //     0xb79780: cmp             x4, x2
    //     0xb79784: b.ls            #0xb79bb0
    //     0xb79788: str             x2, [THR, #0x60]  ; THR::top
    //     0xb7978c: sub             x2, x2, #0xf
    //     0xb79790: mov             x4, #0xe19c
    //     0xb79794: movk            x4, #3, lsl #16
    //     0xb79798: stur            x4, [x2, #-1]
    // 0xb7979c: dmb             ishst
    // 0xb797a0: StoreField: r2->field_7 = d3
    //     0xb797a0: stur            d3, [x2, #7]
    // 0xb797a4: r0 = lerpDouble()
    //     0xb797a4: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xb797a8: LoadField: d0 = r0->field_7
    //     0xb797a8: ldur            d0, [x0, #7]
    // 0xb797ac: b               #0xb79848
    // 0xb797b0: mov             x4, x5
    // 0xb797b4: LoadField: d0 = r4->field_7
    //     0xb797b4: ldur            d0, [x4, #7]
    // 0xb797b8: LoadField: d2 = r0->field_7
    //     0xb797b8: ldur            d2, [x0, #7]
    // 0xb797bc: r3 = inline_Allocate_Double()
    //     0xb797bc: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0xb797c0: add             x3, x3, #0x10
    //     0xb797c4: cmp             x1, x3
    //     0xb797c8: b.ls            #0xb79bdc
    //     0xb797cc: str             x3, [THR, #0x60]  ; THR::top
    //     0xb797d0: sub             x3, x3, #0xf
    //     0xb797d4: mov             x1, #0xe19c
    //     0xb797d8: movk            x1, #3, lsl #16
    //     0xb797dc: stur            x1, [x3, #-1]
    // 0xb797e0: dmb             ishst
    // 0xb797e4: StoreField: r3->field_7 = d1
    //     0xb797e4: stur            d1, [x3, #7]
    // 0xb797e8: r1 = inline_Allocate_Double()
    //     0xb797e8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb797ec: add             x1, x1, #0x10
    //     0xb797f0: cmp             x2, x1
    //     0xb797f4: b.ls            #0xb79c00
    //     0xb797f8: str             x1, [THR, #0x60]  ; THR::top
    //     0xb797fc: sub             x1, x1, #0xf
    //     0xb79800: mov             x2, #0xe19c
    //     0xb79804: movk            x2, #3, lsl #16
    //     0xb79808: stur            x2, [x1, #-1]
    // 0xb7980c: dmb             ishst
    // 0xb79810: StoreField: r1->field_7 = d0
    //     0xb79810: stur            d0, [x1, #7]
    // 0xb79814: r2 = inline_Allocate_Double()
    //     0xb79814: ldp             x2, x5, [THR, #0x60]  ; THR::top
    //     0xb79818: add             x2, x2, #0x10
    //     0xb7981c: cmp             x5, x2
    //     0xb79820: b.ls            #0xb79c24
    //     0xb79824: str             x2, [THR, #0x60]  ; THR::top
    //     0xb79828: sub             x2, x2, #0xf
    //     0xb7982c: mov             x5, #0xe19c
    //     0xb79830: movk            x5, #3, lsl #16
    //     0xb79834: stur            x5, [x2, #-1]
    // 0xb79838: dmb             ishst
    // 0xb7983c: StoreField: r2->field_7 = d2
    //     0xb7983c: stur            d2, [x2, #7]
    // 0xb79840: r0 = lerpDouble()
    //     0xb79840: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xb79844: LoadField: d0 = r0->field_7
    //     0xb79844: ldur            d0, [x0, #7]
    // 0xb79848: ldur            x0, [fp, #-0x10]
    // 0xb7984c: stur            d0, [fp, #-0x48]
    // 0xb79850: tbnz            w0, #4, #0xb798f8
    // 0xb79854: ldur            x1, [fp, #-0x18]
    // 0xb79858: ldur            x0, [fp, #-0x30]
    // 0xb7985c: ldur            d1, [fp, #-0x40]
    // 0xb79860: ArrayLoad: d2 = r0[0]  ; List_8
    //     0xb79860: ldur            d2, [x0, #0x17]
    // 0xb79864: ArrayLoad: d3 = r1[0]  ; List_8
    //     0xb79864: ldur            d3, [x1, #0x17]
    // 0xb79868: r3 = inline_Allocate_Double()
    //     0xb79868: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xb7986c: add             x3, x3, #0x10
    //     0xb79870: cmp             x0, x3
    //     0xb79874: b.ls            #0xb79c48
    //     0xb79878: str             x3, [THR, #0x60]  ; THR::top
    //     0xb7987c: sub             x3, x3, #0xf
    //     0xb79880: mov             x0, #0xe19c
    //     0xb79884: movk            x0, #3, lsl #16
    //     0xb79888: stur            x0, [x3, #-1]
    // 0xb7988c: dmb             ishst
    // 0xb79890: StoreField: r3->field_7 = d1
    //     0xb79890: stur            d1, [x3, #7]
    // 0xb79894: r1 = inline_Allocate_Double()
    //     0xb79894: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0xb79898: add             x1, x1, #0x10
    //     0xb7989c: cmp             x0, x1
    //     0xb798a0: b.ls            #0xb79c64
    //     0xb798a4: str             x1, [THR, #0x60]  ; THR::top
    //     0xb798a8: sub             x1, x1, #0xf
    //     0xb798ac: mov             x0, #0xe19c
    //     0xb798b0: movk            x0, #3, lsl #16
    //     0xb798b4: stur            x0, [x1, #-1]
    // 0xb798b8: dmb             ishst
    // 0xb798bc: StoreField: r1->field_7 = d2
    //     0xb798bc: stur            d2, [x1, #7]
    // 0xb798c0: r2 = inline_Allocate_Double()
    //     0xb798c0: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xb798c4: add             x2, x2, #0x10
    //     0xb798c8: cmp             x0, x2
    //     0xb798cc: b.ls            #0xb79c88
    //     0xb798d0: str             x2, [THR, #0x60]  ; THR::top
    //     0xb798d4: sub             x2, x2, #0xf
    //     0xb798d8: mov             x0, #0xe19c
    //     0xb798dc: movk            x0, #3, lsl #16
    //     0xb798e0: stur            x0, [x2, #-1]
    // 0xb798e4: dmb             ishst
    // 0xb798e8: StoreField: r2->field_7 = d3
    //     0xb798e8: stur            d3, [x2, #7]
    // 0xb798ec: r0 = lerpDouble()
    //     0xb798ec: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xb798f0: LoadField: d0 = r0->field_7
    //     0xb798f0: ldur            d0, [x0, #7]
    // 0xb798f4: b               #0xb79998
    // 0xb798f8: ldur            x1, [fp, #-0x18]
    // 0xb798fc: ldur            x0, [fp, #-0x30]
    // 0xb79900: ldur            d1, [fp, #-0x40]
    // 0xb79904: ArrayLoad: d0 = r1[0]  ; List_8
    //     0xb79904: ldur            d0, [x1, #0x17]
    // 0xb79908: ArrayLoad: d2 = r0[0]  ; List_8
    //     0xb79908: ldur            d2, [x0, #0x17]
    // 0xb7990c: r3 = inline_Allocate_Double()
    //     0xb7990c: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xb79910: add             x3, x3, #0x10
    //     0xb79914: cmp             x0, x3
    //     0xb79918: b.ls            #0xb79ca4
    //     0xb7991c: str             x3, [THR, #0x60]  ; THR::top
    //     0xb79920: sub             x3, x3, #0xf
    //     0xb79924: mov             x0, #0xe19c
    //     0xb79928: movk            x0, #3, lsl #16
    //     0xb7992c: stur            x0, [x3, #-1]
    // 0xb79930: dmb             ishst
    // 0xb79934: StoreField: r3->field_7 = d1
    //     0xb79934: stur            d1, [x3, #7]
    // 0xb79938: r1 = inline_Allocate_Double()
    //     0xb79938: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0xb7993c: add             x1, x1, #0x10
    //     0xb79940: cmp             x0, x1
    //     0xb79944: b.ls            #0xb79cc0
    //     0xb79948: str             x1, [THR, #0x60]  ; THR::top
    //     0xb7994c: sub             x1, x1, #0xf
    //     0xb79950: mov             x0, #0xe19c
    //     0xb79954: movk            x0, #3, lsl #16
    //     0xb79958: stur            x0, [x1, #-1]
    // 0xb7995c: dmb             ishst
    // 0xb79960: StoreField: r1->field_7 = d0
    //     0xb79960: stur            d0, [x1, #7]
    // 0xb79964: r2 = inline_Allocate_Double()
    //     0xb79964: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xb79968: add             x2, x2, #0x10
    //     0xb7996c: cmp             x0, x2
    //     0xb79970: b.ls            #0xb79cdc
    //     0xb79974: str             x2, [THR, #0x60]  ; THR::top
    //     0xb79978: sub             x2, x2, #0xf
    //     0xb7997c: mov             x0, #0xe19c
    //     0xb79980: movk            x0, #3, lsl #16
    //     0xb79984: stur            x0, [x2, #-1]
    // 0xb79988: dmb             ishst
    // 0xb7998c: StoreField: r2->field_7 = d2
    //     0xb7998c: stur            d2, [x2, #7]
    // 0xb79990: r0 = lerpDouble()
    //     0xb79990: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xb79994: LoadField: d0 = r0->field_7
    //     0xb79994: ldur            d0, [x0, #7]
    // 0xb79998: ldur            d1, [fp, #-0x48]
    // 0xb7999c: ldur            x0, [fp, #-0x38]
    // 0xb799a0: stur            d1, [fp, #-0x50]
    // 0xb799a4: stur            d0, [fp, #-0x58]
    // 0xb799a8: LoadField: d2 = r0->field_f
    //     0xb799a8: ldur            d2, [x0, #0xf]
    // 0xb799ac: stur            d2, [fp, #-0x48]
    // 0xb799b0: LoadField: d3 = r0->field_1f
    //     0xb799b0: ldur            d3, [x0, #0x1f]
    // 0xb799b4: stur            d3, [fp, #-0x40]
    // 0xb799b8: r0 = Rect()
    //     0xb799b8: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xb799bc: ldur            d0, [fp, #-0x50]
    // 0xb799c0: StoreField: r0->field_7 = d0
    //     0xb799c0: stur            d0, [x0, #7]
    // 0xb799c4: ldur            d0, [fp, #-0x48]
    // 0xb799c8: StoreField: r0->field_f = d0
    //     0xb799c8: stur            d0, [x0, #0xf]
    // 0xb799cc: ldur            d0, [fp, #-0x58]
    // 0xb799d0: ArrayStore: r0[0] = d0  ; List_8
    //     0xb799d0: stur            d0, [x0, #0x17]
    // 0xb799d4: ldur            d0, [fp, #-0x40]
    // 0xb799d8: StoreField: r0->field_1f = d0
    //     0xb799d8: stur            d0, [x0, #0x1f]
    // 0xb799dc: LeaveFrame
    //     0xb799dc: mov             SP, fp
    //     0xb799e0: ldp             fp, lr, [SP], #0x10
    // 0xb799e4: ret
    //     0xb799e4: ret             
    // 0xb799e8: r0 = StackOverflowSharedWithFPURegs()
    //     0xb799e8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb799ec: b               #0xb78fd4
    // 0xb799f0: stp             q3, q4, [SP, #-0x20]!
    // 0xb799f4: stp             q1, q2, [SP, #-0x20]!
    // 0xb799f8: SaveReg d0
    //     0xb799f8: str             q0, [SP, #-0x10]!
    // 0xb799fc: stp             x1, x2, [SP, #-0x10]!
    // 0xb79a00: d0 = 0.000000
    //     0xb79a00: fmov            d0, d1
    // 0xb79a04: r0 = 70
    //     0xb79a04: mov             x0, #0x46
    // 0xb79a08: r30 = DoubleToIntegerStub
    //     0xb79a08: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xb79a0c: LoadField: r30 = r30->field_7
    //     0xb79a0c: ldur            lr, [lr, #7]
    // 0xb79a10: blr             lr
    // 0xb79a14: ldp             x1, x2, [SP], #0x10
    // 0xb79a18: RestoreReg d0
    //     0xb79a18: ldr             q0, [SP], #0x10
    // 0xb79a1c: ldp             q1, q2, [SP], #0x20
    // 0xb79a20: ldp             q3, q4, [SP], #0x20
    // 0xb79a24: b               #0xb79090
    // 0xb79a28: stp             q3, q4, [SP, #-0x20]!
    // 0xb79a2c: stp             q1, q2, [SP, #-0x20]!
    // 0xb79a30: SaveReg d0
    //     0xb79a30: str             q0, [SP, #-0x10]!
    // 0xb79a34: stp             x1, x2, [SP, #-0x10]!
    // 0xb79a38: d0 = 0.000000
    //     0xb79a38: fmov            d0, d1
    // 0xb79a3c: r0 = 66
    //     0xb79a3c: mov             x0, #0x42
    // 0xb79a40: r30 = DoubleToIntegerStub
    //     0xb79a40: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xb79a44: LoadField: r30 = r30->field_7
    //     0xb79a44: ldur            lr, [lr, #7]
    // 0xb79a48: blr             lr
    // 0xb79a4c: ldp             x1, x2, [SP], #0x10
    // 0xb79a50: RestoreReg d0
    //     0xb79a50: ldr             q0, [SP], #0x10
    // 0xb79a54: ldp             q1, q2, [SP], #0x20
    // 0xb79a58: ldp             q3, q4, [SP], #0x20
    // 0xb79a5c: b               #0xb790bc
    // 0xb79a60: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb79a60: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb79a64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb79a64: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb79a68: r9 = _status
    //     0xb79a68: ldr             x9, [PP, #0x51e8]  ; [pp+0x51e8] Field <AnimationController._status@62066280>: late (offset: 0x44)
    // 0xb79a6c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb79a6c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xb79a70: stp             q2, q3, [SP, #-0x20]!
    // 0xb79a74: stp             q0, q1, [SP, #-0x20]!
    // 0xb79a78: stp             x4, x19, [SP, #-0x10]!
    // 0xb79a7c: SaveReg r0
    //     0xb79a7c: str             x0, [SP, #-8]!
    // 0xb79a80: r0 = AllocateDouble()
    //     0xb79a80: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb79a84: mov             x3, x0
    // 0xb79a88: RestoreReg r0
    //     0xb79a88: ldr             x0, [SP], #8
    // 0xb79a8c: ldp             x4, x19, [SP], #0x10
    // 0xb79a90: ldp             q0, q1, [SP], #0x20
    // 0xb79a94: ldp             q2, q3, [SP], #0x20
    // 0xb79a98: b               #0xb795e4
    // 0xb79a9c: stp             q2, q3, [SP, #-0x20]!
    // 0xb79aa0: SaveReg d0
    //     0xb79aa0: str             q0, [SP, #-0x10]!
    // 0xb79aa4: stp             x4, x19, [SP, #-0x10]!
    // 0xb79aa8: stp             x0, x3, [SP, #-0x10]!
    // 0xb79aac: r0 = AllocateDouble()
    //     0xb79aac: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb79ab0: mov             x1, x0
    // 0xb79ab4: ldp             x0, x3, [SP], #0x10
    // 0xb79ab8: ldp             x4, x19, [SP], #0x10
    // 0xb79abc: RestoreReg d0
    //     0xb79abc: ldr             q0, [SP], #0x10
    // 0xb79ac0: ldp             q2, q3, [SP], #0x20
    // 0xb79ac4: b               #0xb79610
    // 0xb79ac8: stp             q0, q3, [SP, #-0x20]!
    // 0xb79acc: stp             x4, x19, [SP, #-0x10]!
    // 0xb79ad0: stp             x1, x3, [SP, #-0x10]!
    // 0xb79ad4: SaveReg r0
    //     0xb79ad4: str             x0, [SP, #-8]!
    // 0xb79ad8: r0 = AllocateDouble()
    //     0xb79ad8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb79adc: mov             x2, x0
    // 0xb79ae0: RestoreReg r0
    //     0xb79ae0: ldr             x0, [SP], #8
    // 0xb79ae4: ldp             x1, x3, [SP], #0x10
    // 0xb79ae8: ldp             x4, x19, [SP], #0x10
    // 0xb79aec: ldp             q0, q3, [SP], #0x20
    // 0xb79af0: b               #0xb7963c
    // 0xb79af4: stp             q1, q2, [SP, #-0x20]!
    // 0xb79af8: SaveReg d0
    //     0xb79af8: str             q0, [SP, #-0x10]!
    // 0xb79afc: SaveReg r4
    //     0xb79afc: str             x4, [SP, #-8]!
    // 0xb79b00: r0 = AllocateDouble()
    //     0xb79b00: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb79b04: mov             x3, x0
    // 0xb79b08: RestoreReg r4
    //     0xb79b08: ldr             x4, [SP], #8
    // 0xb79b0c: RestoreReg d0
    //     0xb79b0c: ldr             q0, [SP], #0x10
    // 0xb79b10: ldp             q1, q2, [SP], #0x20
    // 0xb79b14: b               #0xb79688
    // 0xb79b18: stp             q0, q1, [SP, #-0x20]!
    // 0xb79b1c: stp             x3, x4, [SP, #-0x10]!
    // 0xb79b20: r0 = AllocateDouble()
    //     0xb79b20: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb79b24: mov             x1, x0
    // 0xb79b28: ldp             x3, x4, [SP], #0x10
    // 0xb79b2c: ldp             q0, q1, [SP], #0x20
    // 0xb79b30: b               #0xb796b4
    // 0xb79b34: SaveReg d1
    //     0xb79b34: str             q1, [SP, #-0x10]!
    // 0xb79b38: stp             x3, x4, [SP, #-0x10]!
    // 0xb79b3c: SaveReg r1
    //     0xb79b3c: str             x1, [SP, #-8]!
    // 0xb79b40: r0 = AllocateDouble()
    //     0xb79b40: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb79b44: mov             x2, x0
    // 0xb79b48: RestoreReg r1
    //     0xb79b48: ldr             x1, [SP], #8
    // 0xb79b4c: ldp             x3, x4, [SP], #0x10
    // 0xb79b50: RestoreReg d1
    //     0xb79b50: ldr             q1, [SP], #0x10
    // 0xb79b54: b               #0xb796e0
    // 0xb79b58: stp             q2, q3, [SP, #-0x20]!
    // 0xb79b5c: stp             q0, q1, [SP, #-0x20]!
    // 0xb79b60: stp             x5, x23, [SP, #-0x10]!
    // 0xb79b64: SaveReg r0
    //     0xb79b64: str             x0, [SP, #-8]!
    // 0xb79b68: r0 = AllocateDouble()
    //     0xb79b68: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb79b6c: mov             x3, x0
    // 0xb79b70: RestoreReg r0
    //     0xb79b70: ldr             x0, [SP], #8
    // 0xb79b74: ldp             x5, x23, [SP], #0x10
    // 0xb79b78: ldp             q0, q1, [SP], #0x20
    // 0xb79b7c: ldp             q2, q3, [SP], #0x20
    // 0xb79b80: b               #0xb79748
    // 0xb79b84: stp             q2, q3, [SP, #-0x20]!
    // 0xb79b88: SaveReg d0
    //     0xb79b88: str             q0, [SP, #-0x10]!
    // 0xb79b8c: stp             x5, x23, [SP, #-0x10]!
    // 0xb79b90: stp             x0, x3, [SP, #-0x10]!
    // 0xb79b94: r0 = AllocateDouble()
    //     0xb79b94: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb79b98: mov             x1, x0
    // 0xb79b9c: ldp             x0, x3, [SP], #0x10
    // 0xb79ba0: ldp             x5, x23, [SP], #0x10
    // 0xb79ba4: RestoreReg d0
    //     0xb79ba4: ldr             q0, [SP], #0x10
    // 0xb79ba8: ldp             q2, q3, [SP], #0x20
    // 0xb79bac: b               #0xb79774
    // 0xb79bb0: stp             q2, q3, [SP, #-0x20]!
    // 0xb79bb4: stp             x5, x23, [SP, #-0x10]!
    // 0xb79bb8: stp             x1, x3, [SP, #-0x10]!
    // 0xb79bbc: SaveReg r0
    //     0xb79bbc: str             x0, [SP, #-8]!
    // 0xb79bc0: r0 = AllocateDouble()
    //     0xb79bc0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb79bc4: mov             x2, x0
    // 0xb79bc8: RestoreReg r0
    //     0xb79bc8: ldr             x0, [SP], #8
    // 0xb79bcc: ldp             x1, x3, [SP], #0x10
    // 0xb79bd0: ldp             x5, x23, [SP], #0x10
    // 0xb79bd4: ldp             q2, q3, [SP], #0x20
    // 0xb79bd8: b               #0xb797a0
    // 0xb79bdc: stp             q1, q2, [SP, #-0x20]!
    // 0xb79be0: SaveReg d0
    //     0xb79be0: str             q0, [SP, #-0x10]!
    // 0xb79be4: stp             x0, x4, [SP, #-0x10]!
    // 0xb79be8: r0 = AllocateDouble()
    //     0xb79be8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb79bec: mov             x3, x0
    // 0xb79bf0: ldp             x0, x4, [SP], #0x10
    // 0xb79bf4: RestoreReg d0
    //     0xb79bf4: ldr             q0, [SP], #0x10
    // 0xb79bf8: ldp             q1, q2, [SP], #0x20
    // 0xb79bfc: b               #0xb797e4
    // 0xb79c00: stp             q0, q2, [SP, #-0x20]!
    // 0xb79c04: stp             x3, x4, [SP, #-0x10]!
    // 0xb79c08: SaveReg r0
    //     0xb79c08: str             x0, [SP, #-8]!
    // 0xb79c0c: r0 = AllocateDouble()
    //     0xb79c0c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb79c10: mov             x1, x0
    // 0xb79c14: RestoreReg r0
    //     0xb79c14: ldr             x0, [SP], #8
    // 0xb79c18: ldp             x3, x4, [SP], #0x10
    // 0xb79c1c: ldp             q0, q2, [SP], #0x20
    // 0xb79c20: b               #0xb79810
    // 0xb79c24: SaveReg d2
    //     0xb79c24: str             q2, [SP, #-0x10]!
    // 0xb79c28: stp             x3, x4, [SP, #-0x10]!
    // 0xb79c2c: stp             x0, x1, [SP, #-0x10]!
    // 0xb79c30: r0 = AllocateDouble()
    //     0xb79c30: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb79c34: mov             x2, x0
    // 0xb79c38: ldp             x0, x1, [SP], #0x10
    // 0xb79c3c: ldp             x3, x4, [SP], #0x10
    // 0xb79c40: RestoreReg d2
    //     0xb79c40: ldr             q2, [SP], #0x10
    // 0xb79c44: b               #0xb7983c
    // 0xb79c48: stp             q2, q3, [SP, #-0x20]!
    // 0xb79c4c: stp             q0, q1, [SP, #-0x20]!
    // 0xb79c50: r0 = AllocateDouble()
    //     0xb79c50: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb79c54: mov             x3, x0
    // 0xb79c58: ldp             q0, q1, [SP], #0x20
    // 0xb79c5c: ldp             q2, q3, [SP], #0x20
    // 0xb79c60: b               #0xb79890
    // 0xb79c64: stp             q2, q3, [SP, #-0x20]!
    // 0xb79c68: SaveReg d0
    //     0xb79c68: str             q0, [SP, #-0x10]!
    // 0xb79c6c: SaveReg r3
    //     0xb79c6c: str             x3, [SP, #-8]!
    // 0xb79c70: r0 = AllocateDouble()
    //     0xb79c70: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb79c74: mov             x1, x0
    // 0xb79c78: RestoreReg r3
    //     0xb79c78: ldr             x3, [SP], #8
    // 0xb79c7c: RestoreReg d0
    //     0xb79c7c: ldr             q0, [SP], #0x10
    // 0xb79c80: ldp             q2, q3, [SP], #0x20
    // 0xb79c84: b               #0xb798bc
    // 0xb79c88: stp             q0, q3, [SP, #-0x20]!
    // 0xb79c8c: stp             x1, x3, [SP, #-0x10]!
    // 0xb79c90: r0 = AllocateDouble()
    //     0xb79c90: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb79c94: mov             x2, x0
    // 0xb79c98: ldp             x1, x3, [SP], #0x10
    // 0xb79c9c: ldp             q0, q3, [SP], #0x20
    // 0xb79ca0: b               #0xb798e8
    // 0xb79ca4: stp             q1, q2, [SP, #-0x20]!
    // 0xb79ca8: SaveReg d0
    //     0xb79ca8: str             q0, [SP, #-0x10]!
    // 0xb79cac: r0 = AllocateDouble()
    //     0xb79cac: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb79cb0: mov             x3, x0
    // 0xb79cb4: RestoreReg d0
    //     0xb79cb4: ldr             q0, [SP], #0x10
    // 0xb79cb8: ldp             q1, q2, [SP], #0x20
    // 0xb79cbc: b               #0xb79934
    // 0xb79cc0: stp             q0, q2, [SP, #-0x20]!
    // 0xb79cc4: SaveReg r3
    //     0xb79cc4: str             x3, [SP, #-8]!
    // 0xb79cc8: r0 = AllocateDouble()
    //     0xb79cc8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb79ccc: mov             x1, x0
    // 0xb79cd0: RestoreReg r3
    //     0xb79cd0: ldr             x3, [SP], #8
    // 0xb79cd4: ldp             q0, q2, [SP], #0x20
    // 0xb79cd8: b               #0xb79960
    // 0xb79cdc: SaveReg d2
    //     0xb79cdc: str             q2, [SP, #-0x10]!
    // 0xb79ce0: stp             x1, x3, [SP, #-0x10]!
    // 0xb79ce4: r0 = AllocateDouble()
    //     0xb79ce4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb79ce8: mov             x2, x0
    // 0xb79cec: ldp             x1, x3, [SP], #0x10
    // 0xb79cf0: RestoreReg d2
    //     0xb79cf0: ldr             q2, [SP], #0x10
    // 0xb79cf4: b               #0xb7998c
  }
  _ indicatorRect(/* No info */) {
    // ** addr: 0xb79cf8, size: 0x4a0
    // 0xb79cf8: EnterFrame
    //     0xb79cf8: stp             fp, lr, [SP, #-0x10]!
    //     0xb79cfc: mov             fp, SP
    // 0xb79d00: AllocStack(0x50)
    //     0xb79d00: sub             SP, SP, #0x50
    // 0xb79d04: SetupParameters(_IndicatorPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xb79d04: mov             x4, x1
    //     0xb79d08: stur            x2, [fp, #-0x10]
    //     0xb79d0c: mov             x16, x3
    //     0xb79d10: mov             x3, x2
    //     0xb79d14: mov             x2, x16
    //     0xb79d18: stur            x1, [fp, #-8]
    //     0xb79d1c: stur            x2, [fp, #-0x18]
    // 0xb79d20: CheckStackOverflow
    //     0xb79d20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb79d24: cmp             SP, x16
    //     0xb79d28: b.ls            #0xb7a16c
    // 0xb79d2c: LoadField: r0 = r4->field_47
    //     0xb79d2c: ldur            w0, [x4, #0x47]
    // 0xb79d30: DecompressPointer r0
    //     0xb79d30: add             x0, x0, HEAP, lsl #32
    // 0xb79d34: cmp             w0, NULL
    // 0xb79d38: b.eq            #0xb7a174
    // 0xb79d3c: LoadField: r1 = r0->field_7
    //     0xb79d3c: ldur            x1, [x0, #7]
    // 0xb79d40: cmp             x1, #0
    // 0xb79d44: b.gt            #0xb79dec
    // 0xb79d48: LoadField: r5 = r4->field_43
    //     0xb79d48: ldur            w5, [x4, #0x43]
    // 0xb79d4c: DecompressPointer r5
    //     0xb79d4c: add             x5, x5, HEAP, lsl #32
    // 0xb79d50: cmp             w5, NULL
    // 0xb79d54: b.eq            #0xb7a178
    // 0xb79d58: add             x6, x2, #1
    // 0xb79d5c: r0 = BoxInt64Instr(r6)
    //     0xb79d5c: sbfiz           x0, x6, #1, #0x1f
    //     0xb79d60: cmp             x6, x0, asr #1
    //     0xb79d64: b.eq            #0xb79d70
    //     0xb79d68: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb79d6c: stur            x6, [x0, #7]
    // 0xb79d70: r1 = LoadClassIdInstr(r5)
    //     0xb79d70: ldur            x1, [x5, #-1]
    //     0xb79d74: ubfx            x1, x1, #0xc, #0x14
    // 0xb79d78: stp             x0, x5, [SP]
    // 0xb79d7c: mov             x0, x1
    // 0xb79d80: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb79d80: sub             lr, x0, #0xdfd
    //     0xb79d84: ldr             lr, [x21, lr, lsl #3]
    //     0xb79d88: blr             lr
    // 0xb79d8c: mov             x3, x0
    // 0xb79d90: ldur            x2, [fp, #-8]
    // 0xb79d94: stur            x3, [fp, #-0x20]
    // 0xb79d98: LoadField: r4 = r2->field_43
    //     0xb79d98: ldur            w4, [x2, #0x43]
    // 0xb79d9c: DecompressPointer r4
    //     0xb79d9c: add             x4, x4, HEAP, lsl #32
    // 0xb79da0: cmp             w4, NULL
    // 0xb79da4: b.eq            #0xb7a17c
    // 0xb79da8: ldur            x5, [fp, #-0x18]
    // 0xb79dac: r0 = BoxInt64Instr(r5)
    //     0xb79dac: sbfiz           x0, x5, #1, #0x1f
    //     0xb79db0: cmp             x5, x0, asr #1
    //     0xb79db4: b.eq            #0xb79dc0
    //     0xb79db8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb79dbc: stur            x5, [x0, #7]
    // 0xb79dc0: r1 = LoadClassIdInstr(r4)
    //     0xb79dc0: ldur            x1, [x4, #-1]
    //     0xb79dc4: ubfx            x1, x1, #0xc, #0x14
    // 0xb79dc8: stp             x0, x4, [SP]
    // 0xb79dcc: mov             x0, x1
    // 0xb79dd0: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb79dd0: sub             lr, x0, #0xdfd
    //     0xb79dd4: ldr             lr, [x21, lr, lsl #3]
    //     0xb79dd8: blr             lr
    // 0xb79ddc: ldur            x2, [fp, #-0x20]
    // 0xb79de0: mov             x3, x0
    // 0xb79de4: r0 = AllocateRecord2()
    //     0xb79de4: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb79de8: b               #0xb79e94
    // 0xb79dec: mov             x3, x2
    // 0xb79df0: mov             x2, x4
    // 0xb79df4: LoadField: r4 = r2->field_43
    //     0xb79df4: ldur            w4, [x2, #0x43]
    // 0xb79df8: DecompressPointer r4
    //     0xb79df8: add             x4, x4, HEAP, lsl #32
    // 0xb79dfc: cmp             w4, NULL
    // 0xb79e00: b.eq            #0xb7a180
    // 0xb79e04: r0 = BoxInt64Instr(r3)
    //     0xb79e04: sbfiz           x0, x3, #1, #0x1f
    //     0xb79e08: cmp             x3, x0, asr #1
    //     0xb79e0c: b.eq            #0xb79e18
    //     0xb79e10: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb79e14: stur            x3, [x0, #7]
    // 0xb79e18: r1 = LoadClassIdInstr(r4)
    //     0xb79e18: ldur            x1, [x4, #-1]
    //     0xb79e1c: ubfx            x1, x1, #0xc, #0x14
    // 0xb79e20: stp             x0, x4, [SP]
    // 0xb79e24: mov             x0, x1
    // 0xb79e28: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb79e28: sub             lr, x0, #0xdfd
    //     0xb79e2c: ldr             lr, [x21, lr, lsl #3]
    //     0xb79e30: blr             lr
    // 0xb79e34: mov             x3, x0
    // 0xb79e38: ldur            x2, [fp, #-8]
    // 0xb79e3c: stur            x3, [fp, #-0x20]
    // 0xb79e40: LoadField: r4 = r2->field_43
    //     0xb79e40: ldur            w4, [x2, #0x43]
    // 0xb79e44: DecompressPointer r4
    //     0xb79e44: add             x4, x4, HEAP, lsl #32
    // 0xb79e48: cmp             w4, NULL
    // 0xb79e4c: b.eq            #0xb7a184
    // 0xb79e50: ldur            x5, [fp, #-0x18]
    // 0xb79e54: add             x6, x5, #1
    // 0xb79e58: r0 = BoxInt64Instr(r6)
    //     0xb79e58: sbfiz           x0, x6, #1, #0x1f
    //     0xb79e5c: cmp             x6, x0, asr #1
    //     0xb79e60: b.eq            #0xb79e6c
    //     0xb79e64: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb79e68: stur            x6, [x0, #7]
    // 0xb79e6c: r1 = LoadClassIdInstr(r4)
    //     0xb79e6c: ldur            x1, [x4, #-1]
    //     0xb79e70: ubfx            x1, x1, #0xc, #0x14
    // 0xb79e74: stp             x0, x4, [SP]
    // 0xb79e78: mov             x0, x1
    // 0xb79e7c: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb79e7c: sub             lr, x0, #0xdfd
    //     0xb79e80: ldr             lr, [x21, lr, lsl #3]
    //     0xb79e84: blr             lr
    // 0xb79e88: ldur            x2, [fp, #-0x20]
    // 0xb79e8c: mov             x3, x0
    // 0xb79e90: r0 = AllocateRecord2()
    //     0xb79e90: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb79e94: ldur            x2, [fp, #-8]
    // 0xb79e98: LoadField: r3 = r0->field_f
    //     0xb79e98: ldur            w3, [x0, #0xf]
    // 0xb79e9c: DecompressPointer r3
    //     0xb79e9c: add             x3, x3, HEAP, lsl #32
    // 0xb79ea0: stur            x3, [fp, #-0x28]
    // 0xb79ea4: LoadField: r4 = r0->field_13
    //     0xb79ea4: ldur            w4, [x0, #0x13]
    // 0xb79ea8: DecompressPointer r4
    //     0xb79ea8: add             x4, x4, HEAP, lsl #32
    // 0xb79eac: stur            x4, [fp, #-0x20]
    // 0xb79eb0: LoadField: r0 = r2->field_13
    //     0xb79eb0: ldur            w0, [x2, #0x13]
    // 0xb79eb4: DecompressPointer r0
    //     0xb79eb4: add             x0, x0, HEAP, lsl #32
    // 0xb79eb8: r16 = Instance_TabBarIndicatorSize
    //     0xb79eb8: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c670] Obj!TabBarIndicatorSize@12c4ce1
    //     0xb79ebc: ldr             x16, [x16, #0x670]
    // 0xb79ec0: cmp             w0, w16
    // 0xb79ec4: b.ne            #0xb7a030
    // 0xb79ec8: ldur            x5, [fp, #-0x18]
    // 0xb79ecc: LoadField: r6 = r2->field_1b
    //     0xb79ecc: ldur            w6, [x2, #0x1b]
    // 0xb79ed0: DecompressPointer r6
    //     0xb79ed0: add             x6, x6, HEAP, lsl #32
    // 0xb79ed4: LoadField: r0 = r6->field_b
    //     0xb79ed4: ldur            w0, [x6, #0xb]
    // 0xb79ed8: r1 = LoadInt32Instr(r0)
    //     0xb79ed8: sbfx            x1, x0, #1, #0x1f
    // 0xb79edc: mov             x0, x1
    // 0xb79ee0: mov             x1, x5
    // 0xb79ee4: cmp             x1, x0
    // 0xb79ee8: b.hs            #0xb7a188
    // 0xb79eec: LoadField: r0 = r6->field_f
    //     0xb79eec: ldur            w0, [x6, #0xf]
    // 0xb79ef0: DecompressPointer r0
    //     0xb79ef0: add             x0, x0, HEAP, lsl #32
    // 0xb79ef4: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0xb79ef4: add             x16, x0, x5, lsl #2
    //     0xb79ef8: ldur            w1, [x16, #0xf]
    // 0xb79efc: DecompressPointer r1
    //     0xb79efc: add             x1, x1, HEAP, lsl #32
    // 0xb79f00: r0 = _currentElement()
    //     0xb79f00: bl              #0x859318  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0xb79f04: cmp             w0, NULL
    // 0xb79f08: b.eq            #0xb7a18c
    // 0xb79f0c: mov             x1, x0
    // 0xb79f10: r0 = findRenderObject()
    //     0xb79f10: bl              #0x8418fc  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0xb79f14: r1 = LoadClassIdInstr(r0)
    //     0xb79f14: ldur            x1, [x0, #-1]
    //     0xb79f18: ubfx            x1, x1, #0xc, #0x14
    // 0xb79f1c: r17 = -4710
    //     0xb79f1c: mov             x17, #-0x1266
    // 0xb79f20: add             x16, x1, x17
    // 0xb79f24: cmp             x16, #0x109
    // 0xb79f28: b.hi            #0xb79f38
    // 0xb79f2c: mov             x1, x0
    // 0xb79f30: r0 = size()
    //     0xb79f30: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xb79f34: b               #0xb79f3c
    // 0xb79f38: r0 = Null
    //     0xb79f38: mov             x0, NULL
    // 0xb79f3c: ldur            x2, [fp, #-8]
    // 0xb79f40: ldur            x3, [fp, #-0x18]
    // 0xb79f44: cmp             w0, NULL
    // 0xb79f48: b.eq            #0xb7a190
    // 0xb79f4c: LoadField: d0 = r0->field_7
    //     0xb79f4c: ldur            d0, [x0, #7]
    // 0xb79f50: stur            d0, [fp, #-0x30]
    // 0xb79f54: LoadField: r4 = r2->field_1f
    //     0xb79f54: ldur            w4, [x2, #0x1f]
    // 0xb79f58: DecompressPointer r4
    //     0xb79f58: add             x4, x4, HEAP, lsl #32
    // 0xb79f5c: LoadField: r0 = r4->field_b
    //     0xb79f5c: ldur            w0, [x4, #0xb]
    // 0xb79f60: r1 = LoadInt32Instr(r0)
    //     0xb79f60: sbfx            x1, x0, #1, #0x1f
    // 0xb79f64: mov             x0, x1
    // 0xb79f68: mov             x1, x3
    // 0xb79f6c: cmp             x1, x0
    // 0xb79f70: b.hs            #0xb7a194
    // 0xb79f74: LoadField: r0 = r4->field_f
    //     0xb79f74: ldur            w0, [x4, #0xf]
    // 0xb79f78: DecompressPointer r0
    //     0xb79f78: add             x0, x0, HEAP, lsl #32
    // 0xb79f7c: ArrayLoad: r1 = r0[r3]  ; Unknown_4
    //     0xb79f7c: add             x16, x0, x3, lsl #2
    //     0xb79f80: ldur            w1, [x16, #0xf]
    // 0xb79f84: DecompressPointer r1
    //     0xb79f84: add             x1, x1, HEAP, lsl #32
    // 0xb79f88: LoadField: r0 = r2->field_47
    //     0xb79f88: ldur            w0, [x2, #0x47]
    // 0xb79f8c: DecompressPointer r0
    //     0xb79f8c: add             x0, x0, HEAP, lsl #32
    // 0xb79f90: r2 = LoadClassIdInstr(r1)
    //     0xb79f90: ldur            x2, [x1, #-1]
    //     0xb79f94: ubfx            x2, x2, #0xc, #0x14
    // 0xb79f98: cmp             x2, #0xb7c
    // 0xb79f9c: b.ne            #0xb79fa8
    // 0xb79fa0: mov             x2, x1
    // 0xb79fa4: b               #0xb79fd0
    // 0xb79fa8: r2 = LoadClassIdInstr(r1)
    //     0xb79fa8: ldur            x2, [x1, #-1]
    //     0xb79fac: ubfx            x2, x2, #0xc, #0x14
    // 0xb79fb0: mov             x16, x0
    // 0xb79fb4: mov             x0, x2
    // 0xb79fb8: mov             x2, x16
    // 0xb79fbc: r0 = GDT[cid_x0 + -0xfea]()
    //     0xb79fbc: sub             lr, x0, #0xfea
    //     0xb79fc0: ldr             lr, [x21, lr, lsl #3]
    //     0xb79fc4: blr             lr
    // 0xb79fc8: mov             x2, x0
    // 0xb79fcc: ldur            d0, [fp, #-0x30]
    // 0xb79fd0: ldur            x0, [fp, #-0x28]
    // 0xb79fd4: ldur            x1, [fp, #-0x20]
    // 0xb79fd8: stur            x2, [fp, #-8]
    // 0xb79fdc: LoadField: d1 = r0->field_7
    //     0xb79fdc: ldur            d1, [x0, #7]
    // 0xb79fe0: stur            d1, [fp, #-0x40]
    // 0xb79fe4: LoadField: d2 = r1->field_7
    //     0xb79fe4: ldur            d2, [x1, #7]
    // 0xb79fe8: fsub            d3, d2, d1
    // 0xb79fec: mov             x1, x2
    // 0xb79ff0: stur            d3, [fp, #-0x38]
    // 0xb79ff4: r0 = horizontal()
    //     0xb79ff4: bl              #0xb17264  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::horizontal
    // 0xb79ff8: mov             v1.16b, v0.16b
    // 0xb79ffc: ldur            d0, [fp, #-0x30]
    // 0xb7a000: fadd            d2, d0, d1
    // 0xb7a004: ldur            d1, [fp, #-0x38]
    // 0xb7a008: fsub            d3, d1, d2
    // 0xb7a00c: d1 = 2.000000
    //     0xb7a00c: fmov            d1, #2.00000000
    // 0xb7a010: fdiv            d2, d3, d1
    // 0xb7a014: ldur            x0, [fp, #-8]
    // 0xb7a018: LoadField: d1 = r0->field_7
    //     0xb7a018: ldur            d1, [x0, #7]
    // 0xb7a01c: fadd            d3, d2, d1
    // 0xb7a020: ldur            d1, [fp, #-0x40]
    // 0xb7a024: fadd            d2, d1, d3
    // 0xb7a028: fadd            d1, d2, d0
    // 0xb7a02c: b               #0xb7a044
    // 0xb7a030: mov             x0, x3
    // 0xb7a034: mov             x1, x4
    // 0xb7a038: LoadField: d0 = r0->field_7
    //     0xb7a038: ldur            d0, [x0, #7]
    // 0xb7a03c: LoadField: d1 = r1->field_7
    //     0xb7a03c: ldur            d1, [x1, #7]
    // 0xb7a040: mov             v2.16b, v0.16b
    // 0xb7a044: ldur            x0, [fp, #-0x10]
    // 0xb7a048: d0 = 0.000000
    //     0xb7a048: eor             v0.16b, v0.16b, v0.16b
    // 0xb7a04c: stur            d2, [fp, #-0x40]
    // 0xb7a050: fsub            d3, d1, d2
    // 0xb7a054: LoadField: d1 = r0->field_f
    //     0xb7a054: ldur            d1, [x0, #0xf]
    // 0xb7a058: fadd            d4, d2, d3
    // 0xb7a05c: stur            d4, [fp, #-0x38]
    // 0xb7a060: fadd            d3, d1, d0
    // 0xb7a064: stur            d3, [fp, #-0x30]
    // 0xb7a068: r0 = Rect()
    //     0xb7a068: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xb7a06c: ldur            d0, [fp, #-0x40]
    // 0xb7a070: stur            x0, [fp, #-8]
    // 0xb7a074: StoreField: r0->field_7 = d0
    //     0xb7a074: stur            d0, [x0, #7]
    // 0xb7a078: StoreField: r0->field_f = rZR
    //     0xb7a078: stur            xzr, [x0, #0xf]
    // 0xb7a07c: ldur            d0, [fp, #-0x38]
    // 0xb7a080: ArrayStore: r0[0] = d0  ; List_8
    //     0xb7a080: stur            d0, [x0, #0x17]
    // 0xb7a084: ldur            d0, [fp, #-0x30]
    // 0xb7a088: StoreField: r0->field_1f = d0
    //     0xb7a088: stur            d0, [x0, #0x1f]
    // 0xb7a08c: mov             x1, x0
    // 0xb7a090: r0 = size()
    //     0xb7a090: bl              #0x8632d0  ; [dart:ui] Rect::size
    // 0xb7a094: r1 = Instance_EdgeInsets
    //     0xb7a094: ldr             x1, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xb7a098: stur            x0, [fp, #-0x10]
    // 0xb7a09c: r0 = collapsedSize()
    //     0xb7a09c: bl              #0xb7a270  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::collapsedSize
    // 0xb7a0a0: mov             x1, x0
    // 0xb7a0a4: ldur            x0, [fp, #-0x10]
    // 0xb7a0a8: LoadField: d0 = r0->field_7
    //     0xb7a0a8: ldur            d0, [x0, #7]
    // 0xb7a0ac: LoadField: d1 = r1->field_7
    //     0xb7a0ac: ldur            d1, [x1, #7]
    // 0xb7a0b0: fcmp            d0, d1
    // 0xb7a0b4: b.lt            #0xb7a0ec
    // 0xb7a0b8: LoadField: d0 = r0->field_f
    //     0xb7a0b8: ldur            d0, [x0, #0xf]
    // 0xb7a0bc: LoadField: d1 = r1->field_f
    //     0xb7a0bc: ldur            d1, [x1, #0xf]
    // 0xb7a0c0: fcmp            d0, d1
    // 0xb7a0c4: r16 = true
    //     0xb7a0c4: add             x16, NULL, #0x20  ; true
    // 0xb7a0c8: r17 = false
    //     0xb7a0c8: add             x17, NULL, #0x30  ; false
    // 0xb7a0cc: csel            x0, x16, x17, ge
    // 0xb7a0d0: tbnz            w0, #4, #0xb7a0ec
    // 0xb7a0d4: ldur            x2, [fp, #-8]
    // 0xb7a0d8: r1 = Instance_EdgeInsets
    //     0xb7a0d8: ldr             x1, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xb7a0dc: r0 = deflateRect()
    //     0xb7a0dc: bl              #0xb7a1f4  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::deflateRect
    // 0xb7a0e0: LeaveFrame
    //     0xb7a0e0: mov             SP, fp
    //     0xb7a0e4: ldp             fp, lr, [SP], #0x10
    // 0xb7a0e8: ret
    //     0xb7a0e8: ret             
    // 0xb7a0ec: r1 = Null
    //     0xb7a0ec: mov             x1, NULL
    // 0xb7a0f0: r2 = 8
    //     0xb7a0f0: mov             x2, #8
    // 0xb7a0f4: r0 = AllocateArray()
    //     0xb7a0f4: bl              #0x13df928  ; AllocateArrayStub
    // 0xb7a0f8: stur            x0, [fp, #-0x10]
    // 0xb7a0fc: r16 = "indicatorPadding insets should be less than Tab Size\nRect Size : "
    //     0xb7a0fc: add             x16, PP, #0xa0, lsl #12  ; [pp+0xa0de0] "indicatorPadding insets should be less than Tab Size\nRect Size : "
    //     0xb7a100: ldr             x16, [x16, #0xde0]
    // 0xb7a104: StoreField: r0->field_f = r16
    //     0xb7a104: stur            w16, [x0, #0xf]
    // 0xb7a108: ldur            x1, [fp, #-8]
    // 0xb7a10c: r0 = size()
    //     0xb7a10c: bl              #0x8632d0  ; [dart:ui] Rect::size
    // 0xb7a110: ldur            x1, [fp, #-0x10]
    // 0xb7a114: ArrayStore: r1[1] = r0  ; List_4
    //     0xb7a114: add             x25, x1, #0x13
    //     0xb7a118: str             w0, [x25]
    //     0xb7a11c: tbz             w0, #0, #0xb7a138
    //     0xb7a120: ldurb           w16, [x1, #-1]
    //     0xb7a124: ldurb           w17, [x0, #-1]
    //     0xb7a128: and             x16, x17, x16, lsr #2
    //     0xb7a12c: tst             x16, HEAP, lsr #32
    //     0xb7a130: b.eq            #0xb7a138
    //     0xb7a134: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xb7a138: ldur            x0, [fp, #-0x10]
    // 0xb7a13c: r16 = ", Insets: "
    //     0xb7a13c: add             x16, PP, #0xa0, lsl #12  ; [pp+0xa0de8] ", Insets: "
    //     0xb7a140: ldr             x16, [x16, #0xde8]
    // 0xb7a144: ArrayStore: r0[0] = r16  ; List_4
    //     0xb7a144: stur            w16, [x0, #0x17]
    // 0xb7a148: r16 = Instance_EdgeInsets
    //     0xb7a148: ldr             x16, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xb7a14c: StoreField: r0->field_1b = r16
    //     0xb7a14c: stur            w16, [x0, #0x1b]
    // 0xb7a150: str             x0, [SP]
    // 0xb7a154: r0 = _interpolate()
    //     0xb7a154: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xb7a158: mov             x2, x0
    // 0xb7a15c: r1 = Null
    //     0xb7a15c: mov             x1, NULL
    // 0xb7a160: r0 = FlutterError()
    //     0xb7a160: bl              #0x84eb60  ; [package:flutter/src/foundation/assertions.dart] FlutterError::FlutterError
    // 0xb7a164: r0 = Throw()
    //     0xb7a164: bl              #0x13ddb2c  ; ThrowStub
    // 0xb7a168: brk             #0
    // 0xb7a16c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7a16c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7a170: b               #0xb79d2c
    // 0xb7a174: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb7a174: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb7a178: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb7a178: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb7a17c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb7a17c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb7a180: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb7a180: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb7a184: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb7a184: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb7a188: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb7a188: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb7a18c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb7a18c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb7a190: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb7a190: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb7a194: r0 = RangeErrorSharedWithFPURegs()
    //     0xb7a194: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
  get _ maxTabIndex(/* No info */) {
    // ** addr: 0xb7a2d0, size: 0x70
    // 0xb7a2d0: EnterFrame
    //     0xb7a2d0: stp             fp, lr, [SP, #-0x10]!
    //     0xb7a2d4: mov             fp, SP
    // 0xb7a2d8: AllocStack(0x8)
    //     0xb7a2d8: sub             SP, SP, #8
    // 0xb7a2dc: CheckStackOverflow
    //     0xb7a2dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb7a2e0: cmp             SP, x16
    //     0xb7a2e4: b.ls            #0xb7a334
    // 0xb7a2e8: LoadField: r0 = r1->field_43
    //     0xb7a2e8: ldur            w0, [x1, #0x43]
    // 0xb7a2ec: DecompressPointer r0
    //     0xb7a2ec: add             x0, x0, HEAP, lsl #32
    // 0xb7a2f0: cmp             w0, NULL
    // 0xb7a2f4: b.eq            #0xb7a33c
    // 0xb7a2f8: r1 = LoadClassIdInstr(r0)
    //     0xb7a2f8: ldur            x1, [x0, #-1]
    //     0xb7a2fc: ubfx            x1, x1, #0xc, #0x14
    // 0xb7a300: str             x0, [SP]
    // 0xb7a304: mov             x0, x1
    // 0xb7a308: r0 = GDT[cid_x0 + 0xf078]()
    //     0xb7a308: mov             x17, #0xf078
    //     0xb7a30c: add             lr, x0, x17
    //     0xb7a310: ldr             lr, [x21, lr, lsl #3]
    //     0xb7a314: blr             lr
    // 0xb7a318: r1 = LoadInt32Instr(r0)
    //     0xb7a318: sbfx            x1, x0, #1, #0x1f
    //     0xb7a31c: tbz             w0, #0, #0xb7a324
    //     0xb7a320: ldur            x1, [x0, #7]
    // 0xb7a324: sub             x0, x1, #2
    // 0xb7a328: LeaveFrame
    //     0xb7a328: mov             SP, fp
    //     0xb7a32c: ldp             fp, lr, [SP], #0x10
    // 0xb7a330: ret
    //     0xb7a330: ret             
    // 0xb7a334: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7a334: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7a338: b               #0xb7a2e8
    // 0xb7a33c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb7a33c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _applyLinearEffect(/* No info */) {
    // ** addr: 0xb7a340, size: 0x320
    // 0xb7a340: EnterFrame
    //     0xb7a340: stp             fp, lr, [SP, #-0x10]!
    //     0xb7a344: mov             fp, SP
    // 0xb7a348: AllocStack(0x40)
    //     0xb7a348: sub             SP, SP, #0x40
    // 0xb7a34c: SetupParameters(_IndicatorPainter this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x30 */)
    //     0xb7a34c: mov             x3, x1
    //     0xb7a350: stur            x1, [fp, #-8]
    //     0xb7a354: stur            x2, [fp, #-0x10]
    //     0xb7a358: stur            d0, [fp, #-0x30]
    // 0xb7a35c: CheckStackOverflow
    //     0xb7a35c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb7a360: cmp             SP, x16
    //     0xb7a364: b.ls            #0xb7a600
    // 0xb7a368: LoadField: r0 = r3->field_b
    //     0xb7a368: ldur            w0, [x3, #0xb]
    // 0xb7a36c: DecompressPointer r0
    //     0xb7a36c: add             x0, x0, HEAP, lsl #32
    // 0xb7a370: LoadField: r4 = r0->field_33
    //     0xb7a370: ldur            x4, [x0, #0x33]
    // 0xb7a374: r0 = BoxInt64Instr(r4)
    //     0xb7a374: sbfiz           x0, x4, #1, #0x1f
    //     0xb7a378: cmp             x4, x0, asr #1
    //     0xb7a37c: b.eq            #0xb7a388
    //     0xb7a380: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0xb7a384: stur            x4, [x0, #7]
    // 0xb7a388: stp             x0, NULL, [SP]
    // 0xb7a38c: r0 = _Double.fromInteger()
    //     0xb7a38c: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0xb7a390: LoadField: d0 = r0->field_7
    //     0xb7a390: ldur            d0, [x0, #7]
    // 0xb7a394: ldur            d1, [fp, #-0x30]
    // 0xb7a398: fcmp            d0, d1
    // 0xb7a39c: r16 = true
    //     0xb7a39c: add             x16, NULL, #0x20  ; true
    // 0xb7a3a0: r17 = false
    //     0xb7a3a0: add             x17, NULL, #0x30  ; false
    // 0xb7a3a4: csel            x1, x16, x17, gt
    // 0xb7a3a8: stur            x1, [fp, #-0x20]
    // 0xb7a3ac: tbnz            w1, #4, #0xb7a3e0
    // 0xb7a3b0: fcmp            d1, d1
    // 0xb7a3b4: b.vs            #0xb7a608
    // 0xb7a3b8: fcvtms          x0, d1
    // 0xb7a3bc: asr             x16, x0, #0x1e
    // 0xb7a3c0: cmp             x16, x0, asr #63
    // 0xb7a3c4: b.ne            #0xb7a608
    // 0xb7a3c8: lsl             x0, x0, #1
    // 0xb7a3cc: r2 = LoadInt32Instr(r0)
    //     0xb7a3cc: sbfx            x2, x0, #1, #0x1f
    //     0xb7a3d0: tbz             w0, #0, #0xb7a3d8
    //     0xb7a3d4: ldur            x2, [x0, #7]
    // 0xb7a3d8: mov             x3, x2
    // 0xb7a3dc: b               #0xb7a40c
    // 0xb7a3e0: fcmp            d1, d1
    // 0xb7a3e4: b.vs            #0xb7a630
    // 0xb7a3e8: fcvtps          x0, d1
    // 0xb7a3ec: asr             x16, x0, #0x1e
    // 0xb7a3f0: cmp             x16, x0, asr #63
    // 0xb7a3f4: b.ne            #0xb7a630
    // 0xb7a3f8: lsl             x0, x0, #1
    // 0xb7a3fc: r2 = LoadInt32Instr(r0)
    //     0xb7a3fc: sbfx            x2, x0, #1, #0x1f
    //     0xb7a400: tbz             w0, #0, #0xb7a408
    //     0xb7a404: ldur            x2, [x0, #7]
    // 0xb7a408: mov             x3, x2
    // 0xb7a40c: ldur            x2, [fp, #-8]
    // 0xb7a410: stur            x3, [fp, #-0x18]
    // 0xb7a414: LoadField: r0 = r2->field_43
    //     0xb7a414: ldur            w0, [x2, #0x43]
    // 0xb7a418: DecompressPointer r0
    //     0xb7a418: add             x0, x0, HEAP, lsl #32
    // 0xb7a41c: cmp             w0, NULL
    // 0xb7a420: b.eq            #0xb7a658
    // 0xb7a424: r4 = LoadClassIdInstr(r0)
    //     0xb7a424: ldur            x4, [x0, #-1]
    //     0xb7a428: ubfx            x4, x4, #0xc, #0x14
    // 0xb7a42c: str             x0, [SP]
    // 0xb7a430: mov             x0, x4
    // 0xb7a434: r0 = GDT[cid_x0 + 0xf078]()
    //     0xb7a434: mov             x17, #0xf078
    //     0xb7a438: add             lr, x0, x17
    //     0xb7a43c: ldr             lr, [x21, lr, lsl #3]
    //     0xb7a440: blr             lr
    // 0xb7a444: r1 = LoadInt32Instr(r0)
    //     0xb7a444: sbfx            x1, x0, #1, #0x1f
    //     0xb7a448: tbz             w0, #0, #0xb7a450
    //     0xb7a44c: ldur            x1, [x0, #7]
    // 0xb7a450: sub             x2, x1, #2
    // 0xb7a454: ldur            x3, [fp, #-0x18]
    // 0xb7a458: r0 = BoxInt64Instr(r3)
    //     0xb7a458: sbfiz           x0, x3, #1, #0x1f
    //     0xb7a45c: cmp             x3, x0, asr #1
    //     0xb7a460: b.eq            #0xb7a46c
    //     0xb7a464: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb7a468: stur            x3, [x0, #7]
    // 0xb7a46c: mov             x3, x0
    // 0xb7a470: r0 = BoxInt64Instr(r2)
    //     0xb7a470: sbfiz           x0, x2, #1, #0x1f
    //     0xb7a474: cmp             x2, x0, asr #1
    //     0xb7a478: b.eq            #0xb7a484
    //     0xb7a47c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb7a480: stur            x2, [x0, #7]
    // 0xb7a484: mov             x1, x3
    // 0xb7a488: mov             x3, x0
    // 0xb7a48c: r2 = 0
    //     0xb7a48c: mov             x2, #0
    // 0xb7a490: r0 = clamp()
    //     0xb7a490: bl              #0x13db4a0  ; [dart:core] _IntegerImplementation::clamp
    // 0xb7a494: mov             x1, x0
    // 0xb7a498: ldur            x0, [fp, #-0x20]
    // 0xb7a49c: stur            x1, [fp, #-0x28]
    // 0xb7a4a0: tbnz            w0, #4, #0xb7a4bc
    // 0xb7a4a4: r0 = LoadInt32Instr(r1)
    //     0xb7a4a4: sbfx            x0, x1, #1, #0x1f
    //     0xb7a4a8: tbz             w1, #0, #0xb7a4b0
    //     0xb7a4ac: ldur            x0, [x1, #7]
    // 0xb7a4b0: add             x2, x0, #1
    // 0xb7a4b4: mov             x3, x2
    // 0xb7a4b8: b               #0xb7a4d0
    // 0xb7a4bc: r0 = LoadInt32Instr(r1)
    //     0xb7a4bc: sbfx            x0, x1, #1, #0x1f
    //     0xb7a4c0: tbz             w1, #0, #0xb7a4c8
    //     0xb7a4c4: ldur            x0, [x1, #7]
    // 0xb7a4c8: sub             x2, x0, #1
    // 0xb7a4cc: mov             x3, x2
    // 0xb7a4d0: ldur            x2, [fp, #-8]
    // 0xb7a4d4: ldur            d0, [fp, #-0x30]
    // 0xb7a4d8: stur            x3, [fp, #-0x18]
    // 0xb7a4dc: LoadField: r0 = r2->field_43
    //     0xb7a4dc: ldur            w0, [x2, #0x43]
    // 0xb7a4e0: DecompressPointer r0
    //     0xb7a4e0: add             x0, x0, HEAP, lsl #32
    // 0xb7a4e4: cmp             w0, NULL
    // 0xb7a4e8: b.eq            #0xb7a65c
    // 0xb7a4ec: r4 = LoadClassIdInstr(r0)
    //     0xb7a4ec: ldur            x4, [x0, #-1]
    //     0xb7a4f0: ubfx            x4, x4, #0xc, #0x14
    // 0xb7a4f4: str             x0, [SP]
    // 0xb7a4f8: mov             x0, x4
    // 0xb7a4fc: r0 = GDT[cid_x0 + 0xf078]()
    //     0xb7a4fc: mov             x17, #0xf078
    //     0xb7a500: add             lr, x0, x17
    //     0xb7a504: ldr             lr, [x21, lr, lsl #3]
    //     0xb7a508: blr             lr
    // 0xb7a50c: r1 = LoadInt32Instr(r0)
    //     0xb7a50c: sbfx            x1, x0, #1, #0x1f
    //     0xb7a510: tbz             w0, #0, #0xb7a518
    //     0xb7a514: ldur            x1, [x0, #7]
    // 0xb7a518: sub             x2, x1, #2
    // 0xb7a51c: ldur            x3, [fp, #-0x18]
    // 0xb7a520: r0 = BoxInt64Instr(r3)
    //     0xb7a520: sbfiz           x0, x3, #1, #0x1f
    //     0xb7a524: cmp             x3, x0, asr #1
    //     0xb7a528: b.eq            #0xb7a534
    //     0xb7a52c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb7a530: stur            x3, [x0, #7]
    // 0xb7a534: mov             x3, x0
    // 0xb7a538: r0 = BoxInt64Instr(r2)
    //     0xb7a538: sbfiz           x0, x2, #1, #0x1f
    //     0xb7a53c: cmp             x2, x0, asr #1
    //     0xb7a540: b.eq            #0xb7a54c
    //     0xb7a544: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb7a548: stur            x2, [x0, #7]
    // 0xb7a54c: mov             x1, x3
    // 0xb7a550: mov             x3, x0
    // 0xb7a554: r2 = 0
    //     0xb7a554: mov             x2, #0
    // 0xb7a558: r0 = clamp()
    //     0xb7a558: bl              #0x13db4a0  ; [dart:core] _IntegerImplementation::clamp
    // 0xb7a55c: mov             x4, x0
    // 0xb7a560: ldur            x0, [fp, #-0x28]
    // 0xb7a564: stur            x4, [fp, #-0x20]
    // 0xb7a568: r5 = LoadInt32Instr(r0)
    //     0xb7a568: sbfx            x5, x0, #1, #0x1f
    //     0xb7a56c: tbz             w0, #0, #0xb7a574
    //     0xb7a570: ldur            x5, [x0, #7]
    // 0xb7a574: ldur            x1, [fp, #-8]
    // 0xb7a578: ldur            x2, [fp, #-0x10]
    // 0xb7a57c: mov             x3, x5
    // 0xb7a580: stur            x5, [fp, #-0x18]
    // 0xb7a584: r0 = indicatorRect()
    //     0xb7a584: bl              #0xb79cf8  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::indicatorRect
    // 0xb7a588: mov             x4, x0
    // 0xb7a58c: ldur            x0, [fp, #-0x20]
    // 0xb7a590: stur            x4, [fp, #-0x28]
    // 0xb7a594: r3 = LoadInt32Instr(r0)
    //     0xb7a594: sbfx            x3, x0, #1, #0x1f
    //     0xb7a598: tbz             w0, #0, #0xb7a5a0
    //     0xb7a59c: ldur            x3, [x0, #7]
    // 0xb7a5a0: ldur            x1, [fp, #-8]
    // 0xb7a5a4: ldur            x2, [fp, #-0x10]
    // 0xb7a5a8: r0 = indicatorRect()
    //     0xb7a5a8: bl              #0xb79cf8  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::indicatorRect
    // 0xb7a5ac: mov             x1, x0
    // 0xb7a5b0: ldur            x0, [fp, #-0x18]
    // 0xb7a5b4: scvtf           d0, x0
    // 0xb7a5b8: ldur            d1, [fp, #-0x30]
    // 0xb7a5bc: fsub            d2, d1, d0
    // 0xb7a5c0: d0 = 0.000000
    //     0xb7a5c0: eor             v0.16b, v0.16b, v0.16b
    // 0xb7a5c4: fcmp            d2, d0
    // 0xb7a5c8: b.ne            #0xb7a5d4
    // 0xb7a5cc: d0 = 0.000000
    //     0xb7a5cc: eor             v0.16b, v0.16b, v0.16b
    // 0xb7a5d0: b               #0xb7a5e8
    // 0xb7a5d4: fcmp            d0, d2
    // 0xb7a5d8: b.le            #0xb7a5e4
    // 0xb7a5dc: fneg            d0, d2
    // 0xb7a5e0: b               #0xb7a5e8
    // 0xb7a5e4: mov             v0.16b, v2.16b
    // 0xb7a5e8: mov             x2, x1
    // 0xb7a5ec: ldur            x1, [fp, #-0x28]
    // 0xb7a5f0: r0 = lerp()
    //     0xb7a5f0: bl              #0xae0924  ; [dart:ui] Rect::lerp
    // 0xb7a5f4: LeaveFrame
    //     0xb7a5f4: mov             SP, fp
    //     0xb7a5f8: ldp             fp, lr, [SP], #0x10
    // 0xb7a5fc: ret
    //     0xb7a5fc: ret             
    // 0xb7a600: r0 = StackOverflowSharedWithFPURegs()
    //     0xb7a600: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb7a604: b               #0xb7a368
    // 0xb7a608: SaveReg d1
    //     0xb7a608: str             q1, [SP, #-0x10]!
    // 0xb7a60c: SaveReg r1
    //     0xb7a60c: str             x1, [SP, #-8]!
    // 0xb7a610: d0 = 0.000000
    //     0xb7a610: fmov            d0, d1
    // 0xb7a614: r0 = 70
    //     0xb7a614: mov             x0, #0x46
    // 0xb7a618: r30 = DoubleToIntegerStub
    //     0xb7a618: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xb7a61c: LoadField: r30 = r30->field_7
    //     0xb7a61c: ldur            lr, [lr, #7]
    // 0xb7a620: blr             lr
    // 0xb7a624: RestoreReg r1
    //     0xb7a624: ldr             x1, [SP], #8
    // 0xb7a628: RestoreReg d1
    //     0xb7a628: ldr             q1, [SP], #0x10
    // 0xb7a62c: b               #0xb7a3cc
    // 0xb7a630: SaveReg d1
    //     0xb7a630: str             q1, [SP, #-0x10]!
    // 0xb7a634: SaveReg r1
    //     0xb7a634: str             x1, [SP, #-8]!
    // 0xb7a638: d0 = 0.000000
    //     0xb7a638: fmov            d0, d1
    // 0xb7a63c: r0 = 66
    //     0xb7a63c: mov             x0, #0x42
    // 0xb7a640: r30 = DoubleToIntegerStub
    //     0xb7a640: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xb7a644: LoadField: r30 = r30->field_7
    //     0xb7a644: ldur            lr, [lr, #7]
    // 0xb7a648: blr             lr
    // 0xb7a64c: RestoreReg r1
    //     0xb7a64c: ldr             x1, [SP], #8
    // 0xb7a650: RestoreReg d1
    //     0xb7a650: ldr             q1, [SP], #0x10
    // 0xb7a654: b               #0xb7a3fc
    // 0xb7a658: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb7a658: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb7a65c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb7a65c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] void markNeedsPaint(dynamic) {
    // ** addr: 0xb7a690, size: 0x38
    // 0xb7a690: EnterFrame
    //     0xb7a690: stp             fp, lr, [SP, #-0x10]!
    //     0xb7a694: mov             fp, SP
    // 0xb7a698: ldr             x0, [fp, #0x10]
    // 0xb7a69c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb7a69c: ldur            w1, [x0, #0x17]
    // 0xb7a6a0: DecompressPointer r1
    //     0xb7a6a0: add             x1, x1, HEAP, lsl #32
    // 0xb7a6a4: CheckStackOverflow
    //     0xb7a6a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb7a6a8: cmp             SP, x16
    //     0xb7a6ac: b.ls            #0xb7a6c0
    // 0xb7a6b0: r0 = markNeedsPaint()
    //     0xb7a6b0: bl              #0xb7a6c8  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::markNeedsPaint
    // 0xb7a6b4: LeaveFrame
    //     0xb7a6b4: mov             SP, fp
    //     0xb7a6b8: ldp             fp, lr, [SP], #0x10
    // 0xb7a6bc: ret
    //     0xb7a6bc: ret             
    // 0xb7a6c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7a6c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7a6c4: b               #0xb7a6b0
  }
  _ markNeedsPaint(/* No info */) {
    // ** addr: 0xb7a6c8, size: 0x44
    // 0xb7a6c8: EnterFrame
    //     0xb7a6c8: stp             fp, lr, [SP, #-0x10]!
    //     0xb7a6cc: mov             fp, SP
    // 0xb7a6d0: r0 = true
    //     0xb7a6d0: add             x0, NULL, #0x20  ; true
    // 0xb7a6d4: CheckStackOverflow
    //     0xb7a6d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb7a6d8: cmp             SP, x16
    //     0xb7a6dc: b.ls            #0xb7a704
    // 0xb7a6e0: StoreField: r1->field_53 = r0
    //     0xb7a6e0: stur            w0, [x1, #0x53]
    // 0xb7a6e4: LoadField: r0 = r1->field_3f
    //     0xb7a6e4: ldur            w0, [x1, #0x3f]
    // 0xb7a6e8: DecompressPointer r0
    //     0xb7a6e8: add             x0, x0, HEAP, lsl #32
    // 0xb7a6ec: mov             x1, x0
    // 0xb7a6f0: r0 = notifyListeners()
    //     0xb7a6f0: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xb7a6f4: r0 = Null
    //     0xb7a6f4: mov             x0, NULL
    // 0xb7a6f8: LeaveFrame
    //     0xb7a6f8: mov             SP, fp
    //     0xb7a6fc: ldp             fp, lr, [SP], #0x10
    // 0xb7a700: ret
    //     0xb7a700: ret             
    // 0xb7a704: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7a704: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7a708: b               #0xb7a6e0
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xb93b34, size: 0x21c
    // 0xb93b34: EnterFrame
    //     0xb93b34: stp             fp, lr, [SP, #-0x10]!
    //     0xb93b38: mov             fp, SP
    // 0xb93b3c: AllocStack(0x38)
    //     0xb93b3c: sub             SP, SP, #0x38
    // 0xb93b40: SetupParameters(_IndicatorPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xb93b40: mov             x4, x1
    //     0xb93b44: mov             x3, x2
    //     0xb93b48: stur            x1, [fp, #-8]
    //     0xb93b4c: stur            x2, [fp, #-0x10]
    // 0xb93b50: CheckStackOverflow
    //     0xb93b50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb93b54: cmp             SP, x16
    //     0xb93b58: b.ls            #0xb93d48
    // 0xb93b5c: mov             x0, x3
    // 0xb93b60: r2 = Null
    //     0xb93b60: mov             x2, NULL
    // 0xb93b64: r1 = Null
    //     0xb93b64: mov             x1, NULL
    // 0xb93b68: r4 = 60
    //     0xb93b68: mov             x4, #0x3c
    // 0xb93b6c: branchIfSmi(r0, 0xb93b78)
    //     0xb93b6c: tbz             w0, #0, #0xb93b78
    // 0xb93b70: r4 = LoadClassIdInstr(r0)
    //     0xb93b70: ldur            x4, [x0, #-1]
    //     0xb93b74: ubfx            x4, x4, #0xc, #0x14
    // 0xb93b78: r17 = 4331
    //     0xb93b78: mov             x17, #0x10eb
    // 0xb93b7c: cmp             x4, x17
    // 0xb93b80: b.eq            #0xb93b98
    // 0xb93b84: r8 = _IndicatorPainter
    //     0xb93b84: add             x8, PP, #0x95, lsl #12  ; [pp+0x95af0] Type: _IndicatorPainter
    //     0xb93b88: ldr             x8, [x8, #0xaf0]
    // 0xb93b8c: r3 = Null
    //     0xb93b8c: add             x3, PP, #0x95, lsl #12  ; [pp+0x95af8] Null
    //     0xb93b90: ldr             x3, [x3, #0xaf8]
    // 0xb93b94: r0 = DefaultTypeTest()
    //     0xb93b94: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb93b98: ldur            x0, [fp, #-8]
    // 0xb93b9c: LoadField: r1 = r0->field_53
    //     0xb93b9c: ldur            w1, [x0, #0x53]
    // 0xb93ba0: DecompressPointer r1
    //     0xb93ba0: add             x1, x1, HEAP, lsl #32
    // 0xb93ba4: tbz             w1, #4, #0xb93d08
    // 0xb93ba8: ldur            x1, [fp, #-0x10]
    // 0xb93bac: LoadField: r2 = r0->field_b
    //     0xb93bac: ldur            w2, [x0, #0xb]
    // 0xb93bb0: DecompressPointer r2
    //     0xb93bb0: add             x2, x2, HEAP, lsl #32
    // 0xb93bb4: LoadField: r3 = r1->field_b
    //     0xb93bb4: ldur            w3, [x1, #0xb]
    // 0xb93bb8: DecompressPointer r3
    //     0xb93bb8: add             x3, x3, HEAP, lsl #32
    // 0xb93bbc: cmp             w2, w3
    // 0xb93bc0: b.ne            #0xb93d08
    // 0xb93bc4: LoadField: r2 = r0->field_f
    //     0xb93bc4: ldur            w2, [x0, #0xf]
    // 0xb93bc8: DecompressPointer r2
    //     0xb93bc8: add             x2, x2, HEAP, lsl #32
    // 0xb93bcc: stur            x2, [fp, #-0x20]
    // 0xb93bd0: LoadField: r3 = r1->field_f
    //     0xb93bd0: ldur            w3, [x1, #0xf]
    // 0xb93bd4: DecompressPointer r3
    //     0xb93bd4: add             x3, x3, HEAP, lsl #32
    // 0xb93bd8: stur            x3, [fp, #-0x18]
    // 0xb93bdc: r4 = LoadClassIdInstr(r2)
    //     0xb93bdc: ldur            x4, [x2, #-1]
    //     0xb93be0: ubfx            x4, x4, #0xc, #0x14
    // 0xb93be4: r17 = 5239
    //     0xb93be4: mov             x17, #0x1477
    // 0xb93be8: cmp             x4, x17
    // 0xb93bec: b.ne            #0xb93bfc
    // 0xb93bf0: cmp             w2, w3
    // 0xb93bf4: b.eq            #0xb93cc0
    // 0xb93bf8: b               #0xb93d08
    // 0xb93bfc: r17 = 5240
    //     0xb93bfc: mov             x17, #0x1478
    // 0xb93c00: cmp             x4, x17
    // 0xb93c04: b.ne            #0xb93c90
    // 0xb93c08: str             x3, [SP]
    // 0xb93c0c: r0 = runtimeType()
    //     0xb93c0c: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xb93c10: r1 = LoadClassIdInstr(r0)
    //     0xb93c10: ldur            x1, [x0, #-1]
    //     0xb93c14: ubfx            x1, x1, #0xc, #0x14
    // 0xb93c18: r16 = _CupertinoEdgeShadowDecoration
    //     0xb93c18: add             x16, PP, #0x8d, lsl #12  ; [pp+0x8d188] Type: _CupertinoEdgeShadowDecoration
    //     0xb93c1c: ldr             x16, [x16, #0x188]
    // 0xb93c20: stp             x16, x0, [SP]
    // 0xb93c24: mov             x0, x1
    // 0xb93c28: mov             lr, x0
    // 0xb93c2c: ldr             lr, [x21, lr, lsl #3]
    // 0xb93c30: blr             lr
    // 0xb93c34: tbnz            w0, #4, #0xb93d08
    // 0xb93c38: ldur            x0, [fp, #-0x18]
    // 0xb93c3c: r1 = LoadClassIdInstr(r0)
    //     0xb93c3c: ldur            x1, [x0, #-1]
    //     0xb93c40: ubfx            x1, x1, #0xc, #0x14
    // 0xb93c44: r17 = 5240
    //     0xb93c44: mov             x17, #0x1478
    // 0xb93c48: cmp             x1, x17
    // 0xb93c4c: b.ne            #0xb93d08
    // 0xb93c50: ldur            x1, [fp, #-0x20]
    // 0xb93c54: LoadField: r2 = r0->field_7
    //     0xb93c54: ldur            w2, [x0, #7]
    // 0xb93c58: DecompressPointer r2
    //     0xb93c58: add             x2, x2, HEAP, lsl #32
    // 0xb93c5c: LoadField: r0 = r1->field_7
    //     0xb93c5c: ldur            w0, [x1, #7]
    // 0xb93c60: DecompressPointer r0
    //     0xb93c60: add             x0, x0, HEAP, lsl #32
    // 0xb93c64: r1 = LoadClassIdInstr(r2)
    //     0xb93c64: ldur            x1, [x2, #-1]
    //     0xb93c68: ubfx            x1, x1, #0xc, #0x14
    // 0xb93c6c: stp             x0, x2, [SP]
    // 0xb93c70: mov             x0, x1
    // 0xb93c74: mov             lr, x0
    // 0xb93c78: ldr             lr, [x21, lr, lsl #3]
    // 0xb93c7c: blr             lr
    // 0xb93c80: tbnz            w0, #4, #0xb93d08
    // 0xb93c84: ldur            x0, [fp, #-8]
    // 0xb93c88: ldur            x1, [fp, #-0x10]
    // 0xb93c8c: b               #0xb93cc0
    // 0xb93c90: mov             x1, x2
    // 0xb93c94: mov             x0, x3
    // 0xb93c98: r2 = LoadClassIdInstr(r1)
    //     0xb93c98: ldur            x2, [x1, #-1]
    //     0xb93c9c: ubfx            x2, x2, #0xc, #0x14
    // 0xb93ca0: stp             x0, x1, [SP]
    // 0xb93ca4: mov             x0, x2
    // 0xb93ca8: mov             lr, x0
    // 0xb93cac: ldr             lr, [x21, lr, lsl #3]
    // 0xb93cb0: blr             lr
    // 0xb93cb4: tbnz            w0, #4, #0xb93d08
    // 0xb93cb8: ldur            x0, [fp, #-8]
    // 0xb93cbc: ldur            x1, [fp, #-0x10]
    // 0xb93cc0: LoadField: r2 = r0->field_1b
    //     0xb93cc0: ldur            w2, [x0, #0x1b]
    // 0xb93cc4: DecompressPointer r2
    //     0xb93cc4: add             x2, x2, HEAP, lsl #32
    // 0xb93cc8: LoadField: r3 = r2->field_b
    //     0xb93cc8: ldur            w3, [x2, #0xb]
    // 0xb93ccc: LoadField: r2 = r1->field_1b
    //     0xb93ccc: ldur            w2, [x1, #0x1b]
    // 0xb93cd0: DecompressPointer r2
    //     0xb93cd0: add             x2, x2, HEAP, lsl #32
    // 0xb93cd4: LoadField: r4 = r2->field_b
    //     0xb93cd4: ldur            w4, [x2, #0xb]
    // 0xb93cd8: cmp             w3, w4
    // 0xb93cdc: b.ne            #0xb93d08
    // 0xb93ce0: LoadField: r2 = r0->field_43
    //     0xb93ce0: ldur            w2, [x0, #0x43]
    // 0xb93ce4: DecompressPointer r2
    //     0xb93ce4: add             x2, x2, HEAP, lsl #32
    // 0xb93ce8: LoadField: r3 = r1->field_43
    //     0xb93ce8: ldur            w3, [x1, #0x43]
    // 0xb93cec: DecompressPointer r3
    //     0xb93cec: add             x3, x3, HEAP, lsl #32
    // 0xb93cf0: r16 = <double>
    //     0xb93cf0: ldr             x16, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xb93cf4: stp             x2, x16, [SP, #8]
    // 0xb93cf8: str             x3, [SP]
    // 0xb93cfc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb93cfc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb93d00: r0 = listEquals()
    //     0xb93d00: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0xb93d04: tbz             w0, #4, #0xb93d10
    // 0xb93d08: r0 = true
    //     0xb93d08: add             x0, NULL, #0x20  ; true
    // 0xb93d0c: b               #0xb93d3c
    // 0xb93d10: ldur            x1, [fp, #-8]
    // 0xb93d14: ldur            x2, [fp, #-0x10]
    // 0xb93d18: LoadField: r3 = r1->field_47
    //     0xb93d18: ldur            w3, [x1, #0x47]
    // 0xb93d1c: DecompressPointer r3
    //     0xb93d1c: add             x3, x3, HEAP, lsl #32
    // 0xb93d20: LoadField: r1 = r2->field_47
    //     0xb93d20: ldur            w1, [x2, #0x47]
    // 0xb93d24: DecompressPointer r1
    //     0xb93d24: add             x1, x1, HEAP, lsl #32
    // 0xb93d28: cmp             w3, w1
    // 0xb93d2c: r16 = true
    //     0xb93d2c: add             x16, NULL, #0x20  ; true
    // 0xb93d30: r17 = false
    //     0xb93d30: add             x17, NULL, #0x30  ; false
    // 0xb93d34: csel            x2, x16, x17, ne
    // 0xb93d38: mov             x0, x2
    // 0xb93d3c: LeaveFrame
    //     0xb93d3c: mov             SP, fp
    //     0xb93d40: ldp             fp, lr, [SP], #0x10
    // 0xb93d44: ret
    //     0xb93d44: ret             
    // 0xb93d48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb93d48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb93d4c: b               #0xb93b5c
  }
  _ saveTabOffsets(/* No info */) {
    // ** addr: 0xbbf4e4, size: 0x64
    // 0xbbf4e4: EnterFrame
    //     0xbbf4e4: stp             fp, lr, [SP, #-0x10]!
    //     0xbbf4e8: mov             fp, SP
    // 0xbbf4ec: mov             x0, x2
    // 0xbbf4f0: mov             x16, x3
    // 0xbbf4f4: mov             x3, x1
    // 0xbbf4f8: mov             x1, x16
    // 0xbbf4fc: StoreField: r3->field_43 = r0
    //     0xbbf4fc: stur            w0, [x3, #0x43]
    //     0xbbf500: ldurb           w16, [x3, #-1]
    //     0xbbf504: ldurb           w17, [x0, #-1]
    //     0xbbf508: and             x16, x17, x16, lsr #2
    //     0xbbf50c: tst             x16, HEAP, lsr #32
    //     0xbbf510: b.eq            #0xbbf518
    //     0xbbf514: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbbf518: mov             x0, x1
    // 0xbbf51c: StoreField: r3->field_47 = r0
    //     0xbbf51c: stur            w0, [x3, #0x47]
    //     0xbbf520: ldurb           w16, [x3, #-1]
    //     0xbbf524: ldurb           w17, [x0, #-1]
    //     0xbbf528: and             x16, x17, x16, lsr #2
    //     0xbbf52c: tst             x16, HEAP, lsr #32
    //     0xbbf530: b.eq            #0xbbf538
    //     0xbbf534: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbbf538: r0 = Null
    //     0xbbf538: mov             x0, NULL
    // 0xbbf53c: LeaveFrame
    //     0xbbf53c: mov             SP, fp
    //     0xbbf540: ldp             fp, lr, [SP], #0x10
    // 0xbbf544: ret
    //     0xbbf544: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0xef5e38, size: 0xc8
    // 0xef5e38: EnterFrame
    //     0xef5e38: stp             fp, lr, [SP, #-0x10]!
    //     0xef5e3c: mov             fp, SP
    // 0xef5e40: AllocStack(0x8)
    //     0xef5e40: sub             SP, SP, #8
    // 0xef5e44: SetupParameters(_IndicatorPainter this /* r1 => r2, fp-0x8 */)
    //     0xef5e44: mov             x2, x1
    //     0xef5e48: stur            x1, [fp, #-8]
    // 0xef5e4c: CheckStackOverflow
    //     0xef5e4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef5e50: cmp             SP, x16
    //     0xef5e54: b.ls            #0xef5ef8
    // 0xef5e58: LoadField: r0 = r2->field_4f
    //     0xef5e58: ldur            w0, [x2, #0x4f]
    // 0xef5e5c: DecompressPointer r0
    //     0xef5e5c: add             x0, x0, HEAP, lsl #32
    // 0xef5e60: cmp             w0, NULL
    // 0xef5e64: b.ne            #0xef5e70
    // 0xef5e68: mov             x0, x2
    // 0xef5e6c: b               #0xef5edc
    // 0xef5e70: r1 = LoadClassIdInstr(r0)
    //     0xef5e70: ldur            x1, [x0, #-1]
    //     0xef5e74: ubfx            x1, x1, #0xc, #0x14
    // 0xef5e78: sub             x16, x1, #0xcbb
    // 0xef5e7c: cmp             x16, #1
    // 0xef5e80: b.ls            #0xef5ed8
    // 0xef5e84: cmp             x1, #0xcb9
    // 0xef5e88: b.ne            #0xef5eb4
    // 0xef5e8c: LoadField: r1 = r0->field_33
    //     0xef5e8c: ldur            w1, [x0, #0x33]
    // 0xef5e90: DecompressPointer r1
    //     0xef5e90: add             x1, x1, HEAP, lsl #32
    // 0xef5e94: cmp             w1, NULL
    // 0xef5e98: b.eq            #0xef5ed8
    // 0xef5e9c: r0 = LoadClassIdInstr(r1)
    //     0xef5e9c: ldur            x0, [x1, #-1]
    //     0xef5ea0: ubfx            x0, x0, #0xc, #0x14
    // 0xef5ea4: r0 = GDT[cid_x0 + -0xfb9]()
    //     0xef5ea4: sub             lr, x0, #0xfb9
    //     0xef5ea8: ldr             lr, [x21, lr, lsl #3]
    //     0xef5eac: blr             lr
    // 0xef5eb0: b               #0xef5ed8
    // 0xef5eb4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xef5eb4: ldur            w1, [x0, #0x17]
    // 0xef5eb8: DecompressPointer r1
    //     0xef5eb8: add             x1, x1, HEAP, lsl #32
    // 0xef5ebc: cmp             w1, NULL
    // 0xef5ec0: b.eq            #0xef5ed8
    // 0xef5ec4: r0 = LoadClassIdInstr(r1)
    //     0xef5ec4: ldur            x0, [x1, #-1]
    //     0xef5ec8: ubfx            x0, x0, #0xc, #0x14
    // 0xef5ecc: r0 = GDT[cid_x0 + -0xfb9]()
    //     0xef5ecc: sub             lr, x0, #0xfb9
    //     0xef5ed0: ldr             lr, [x21, lr, lsl #3]
    //     0xef5ed4: blr             lr
    // 0xef5ed8: ldur            x0, [fp, #-8]
    // 0xef5edc: LoadField: r1 = r0->field_3f
    //     0xef5edc: ldur            w1, [x0, #0x3f]
    // 0xef5ee0: DecompressPointer r1
    //     0xef5ee0: add             x1, x1, HEAP, lsl #32
    // 0xef5ee4: r0 = dispose()
    //     0xef5ee4: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0xef5ee8: r0 = Null
    //     0xef5ee8: mov             x0, NULL
    // 0xef5eec: LeaveFrame
    //     0xef5eec: mov             SP, fp
    //     0xef5ef0: ldp             fp, lr, [SP], #0x10
    // 0xef5ef4: ret
    //     0xef5ef4: ret             
    // 0xef5ef8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef5ef8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef5efc: b               #0xef5e58
  }
  factory _ _IndicatorPainter(/* No info */) {
    // ** addr: 0xef5f00, size: 0xd8
    // 0xef5f00: EnterFrame
    //     0xef5f00: stp             fp, lr, [SP, #-0x10]!
    //     0xef5f04: mov             fp, SP
    // 0xef5f08: AllocStack(0x78)
    //     0xef5f08: sub             SP, SP, #0x78
    // 0xef5f0c: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */, dynamic _ /* r6 => r6, fp-0x20 */, dynamic _ /* r7 => r7, fp-0x28 */, dynamic _ /* d0 => d0, fp-0x40 */)
    //     0xef5f0c: stur            x2, [fp, #-8]
    //     0xef5f10: stur            x3, [fp, #-0x10]
    //     0xef5f14: stur            x5, [fp, #-0x18]
    //     0xef5f18: stur            x6, [fp, #-0x20]
    //     0xef5f1c: stur            x7, [fp, #-0x28]
    //     0xef5f20: stur            d0, [fp, #-0x40]
    // 0xef5f24: CheckStackOverflow
    //     0xef5f24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef5f28: cmp             SP, x16
    //     0xef5f2c: b.ls            #0xef5fd0
    // 0xef5f30: r0 = _IndicatorPainterNotifier()
    //     0xef5f30: bl              #0xef6260  ; Allocate_IndicatorPainterNotifierStub -> _IndicatorPainterNotifier (size=0x24)
    // 0xef5f34: stur            x0, [fp, #-0x30]
    // 0xef5f38: StoreField: r0->field_7 = rZR
    //     0xef5f38: stur            xzr, [x0, #7]
    // 0xef5f3c: StoreField: r0->field_13 = rZR
    //     0xef5f3c: stur            xzr, [x0, #0x13]
    // 0xef5f40: StoreField: r0->field_1b = rZR
    //     0xef5f40: stur            xzr, [x0, #0x1b]
    // 0xef5f44: r0 = LoadStaticField(0x45c)
    //     0xef5f44: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xef5f48: ldr             x0, [x0, #0x8b8]
    // 0xef5f4c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef5f50: cmp             w0, w16
    // 0xef5f54: b.ne            #0xef5f60
    // 0xef5f58: r2 = _emptyListeners
    //     0xef5f58: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xef5f5c: r0 = InitLateFinalStaticField()
    //     0xef5f5c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xef5f60: mov             x1, x0
    // 0xef5f64: ldur            x0, [fp, #-0x30]
    // 0xef5f68: StoreField: r0->field_f = r1
    //     0xef5f68: stur            w1, [x0, #0xf]
    // 0xef5f6c: r0 = _IndicatorPainter()
    //     0xef5f6c: bl              #0xef6254  ; Allocate_IndicatorPainterStub -> _IndicatorPainter (size=0x58)
    // 0xef5f70: stur            x0, [fp, #-0x38]
    // 0xef5f74: ldr             x16, [fp, #0x38]
    // 0xef5f78: ldr             lr, [fp, #0x30]
    // 0xef5f7c: stp             lr, x16, [SP, #0x28]
    // 0xef5f80: ldr             x16, [fp, #0x28]
    // 0xef5f84: ldur            lr, [fp, #-0x30]
    // 0xef5f88: stp             lr, x16, [SP, #0x18]
    // 0xef5f8c: ldr             x16, [fp, #0x20]
    // 0xef5f90: ldr             lr, [fp, #0x18]
    // 0xef5f94: stp             lr, x16, [SP, #8]
    // 0xef5f98: ldr             x16, [fp, #0x10]
    // 0xef5f9c: str             x16, [SP]
    // 0xef5fa0: mov             x1, x0
    // 0xef5fa4: ldur            x2, [fp, #-8]
    // 0xef5fa8: ldur            d0, [fp, #-0x40]
    // 0xef5fac: ldur            x3, [fp, #-0x10]
    // 0xef5fb0: ldur            x5, [fp, #-0x18]
    // 0xef5fb4: ldur            x6, [fp, #-0x20]
    // 0xef5fb8: ldur            x7, [fp, #-0x28]
    // 0xef5fbc: r0 = _IndicatorPainter._()
    //     0xef5fbc: bl              #0xef5fd8  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::_IndicatorPainter._
    // 0xef5fc0: ldur            x0, [fp, #-0x38]
    // 0xef5fc4: LeaveFrame
    //     0xef5fc4: mov             SP, fp
    //     0xef5fc8: ldp             fp, lr, [SP], #0x10
    // 0xef5fcc: ret
    //     0xef5fcc: ret             
    // 0xef5fd0: r0 = StackOverflowSharedWithFPURegs()
    //     0xef5fd0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xef5fd4: b               #0xef5f30
  }
  _ _IndicatorPainter._(/* No info */) {
    // ** addr: 0xef5fd8, size: 0x27c
    // 0xef5fd8: EnterFrame
    //     0xef5fd8: stp             fp, lr, [SP, #-0x10]!
    //     0xef5fdc: mov             fp, SP
    // 0xef5fe0: AllocStack(0x18)
    //     0xef5fe0: sub             SP, SP, #0x18
    // 0xef5fe4: r0 = false
    //     0xef5fe4: add             x0, NULL, #0x30  ; false
    // 0xef5fe8: r4 = Instance_EdgeInsets
    //     0xef5fe8: ldr             x4, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xef5fec: stur            x1, [fp, #-0x10]
    // 0xef5ff0: mov             x16, x7
    // 0xef5ff4: mov             x7, x1
    // 0xef5ff8: mov             x1, x16
    // 0xef5ffc: mov             x16, x6
    // 0xef6000: mov             x6, x2
    // 0xef6004: mov             x2, x16
    // 0xef6008: mov             x16, x5
    // 0xef600c: mov             x5, x3
    // 0xef6010: mov             x3, x16
    // 0xef6014: CheckStackOverflow
    //     0xef6014: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef6018: cmp             SP, x16
    //     0xef601c: b.ls            #0xef624c
    // 0xef6020: StoreField: r7->field_53 = r0
    //     0xef6020: stur            w0, [x7, #0x53]
    // 0xef6024: mov             x0, x6
    // 0xef6028: StoreField: r7->field_b = r0
    //     0xef6028: stur            w0, [x7, #0xb]
    //     0xef602c: ldurb           w16, [x7, #-1]
    //     0xef6030: ldurb           w17, [x0, #-1]
    //     0xef6034: and             x16, x17, x16, lsr #2
    //     0xef6038: tst             x16, HEAP, lsr #32
    //     0xef603c: b.eq            #0xef6044
    //     0xef6040: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xef6044: mov             x0, x2
    // 0xef6048: StoreField: r7->field_f = r0
    //     0xef6048: stur            w0, [x7, #0xf]
    //     0xef604c: ldurb           w16, [x7, #-1]
    //     0xef6050: ldurb           w17, [x0, #-1]
    //     0xef6054: and             x16, x17, x16, lsr #2
    //     0xef6058: tst             x16, HEAP, lsr #32
    //     0xef605c: b.eq            #0xef6064
    //     0xef6060: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xef6064: ldr             x0, [fp, #0x40]
    // 0xef6068: StoreField: r7->field_13 = r0
    //     0xef6068: stur            w0, [x7, #0x13]
    //     0xef606c: ldurb           w16, [x7, #-1]
    //     0xef6070: ldurb           w17, [x0, #-1]
    //     0xef6074: and             x16, x17, x16, lsr #2
    //     0xef6078: tst             x16, HEAP, lsr #32
    //     0xef607c: b.eq            #0xef6084
    //     0xef6080: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xef6084: ldr             x0, [fp, #0x18]
    // 0xef6088: StoreField: r7->field_1b = r0
    //     0xef6088: stur            w0, [x7, #0x1b]
    //     0xef608c: ldurb           w16, [x7, #-1]
    //     0xef6090: ldurb           w17, [x0, #-1]
    //     0xef6094: and             x16, x17, x16, lsr #2
    //     0xef6098: tst             x16, HEAP, lsr #32
    //     0xef609c: b.eq            #0xef60a4
    //     0xef60a0: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xef60a4: ArrayStore: r7[0] = r4  ; List_4
    //     0xef60a4: stur            w4, [x7, #0x17]
    // 0xef60a8: ldr             x0, [fp, #0x38]
    // 0xef60ac: StoreField: r7->field_1f = r0
    //     0xef60ac: stur            w0, [x7, #0x1f]
    //     0xef60b0: ldurb           w16, [x7, #-1]
    //     0xef60b4: ldurb           w17, [x0, #-1]
    //     0xef60b8: and             x16, x17, x16, lsr #2
    //     0xef60bc: tst             x16, HEAP, lsr #32
    //     0xef60c0: b.eq            #0xef60c8
    //     0xef60c4: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xef60c8: mov             x0, x5
    // 0xef60cc: StoreField: r7->field_23 = r0
    //     0xef60cc: stur            w0, [x7, #0x23]
    //     0xef60d0: ldurb           w16, [x7, #-1]
    //     0xef60d4: ldurb           w17, [x0, #-1]
    //     0xef60d8: and             x16, x17, x16, lsr #2
    //     0xef60dc: tst             x16, HEAP, lsr #32
    //     0xef60e0: b.eq            #0xef60e8
    //     0xef60e4: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xef60e8: mov             x0, x3
    // 0xef60ec: StoreField: r7->field_27 = r0
    //     0xef60ec: stur            w0, [x7, #0x27]
    //     0xef60f0: ldurb           w16, [x7, #-1]
    //     0xef60f4: ldurb           w17, [x0, #-1]
    //     0xef60f8: and             x16, x17, x16, lsr #2
    //     0xef60fc: tst             x16, HEAP, lsr #32
    //     0xef6100: b.eq            #0xef6108
    //     0xef6104: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xef6108: ldr             x0, [fp, #0x20]
    // 0xef610c: StoreField: r7->field_2b = r0
    //     0xef610c: stur            w0, [x7, #0x2b]
    // 0xef6110: StoreField: r7->field_2f = d0
    //     0xef6110: stur            d0, [x7, #0x2f]
    // 0xef6114: mov             x0, x1
    // 0xef6118: StoreField: r7->field_37 = r0
    //     0xef6118: stur            w0, [x7, #0x37]
    //     0xef611c: ldurb           w16, [x7, #-1]
    //     0xef6120: ldurb           w17, [x0, #-1]
    //     0xef6124: and             x16, x17, x16, lsr #2
    //     0xef6128: tst             x16, HEAP, lsr #32
    //     0xef612c: b.eq            #0xef6134
    //     0xef6130: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xef6134: ldr             x0, [fp, #0x10]
    // 0xef6138: StoreField: r7->field_3b = r0
    //     0xef6138: stur            w0, [x7, #0x3b]
    //     0xef613c: ldurb           w16, [x7, #-1]
    //     0xef6140: ldurb           w17, [x0, #-1]
    //     0xef6144: and             x16, x17, x16, lsr #2
    //     0xef6148: tst             x16, HEAP, lsr #32
    //     0xef614c: b.eq            #0xef6154
    //     0xef6150: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xef6154: ldr             x0, [fp, #0x28]
    // 0xef6158: StoreField: r7->field_3f = r0
    //     0xef6158: stur            w0, [x7, #0x3f]
    //     0xef615c: ldurb           w16, [x7, #-1]
    //     0xef6160: ldurb           w17, [x0, #-1]
    //     0xef6164: and             x16, x17, x16, lsr #2
    //     0xef6168: tst             x16, HEAP, lsr #32
    //     0xef616c: b.eq            #0xef6174
    //     0xef6170: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xef6174: LoadField: r0 = r6->field_23
    //     0xef6174: ldur            w0, [x6, #0x23]
    // 0xef6178: DecompressPointer r0
    //     0xef6178: add             x0, x0, HEAP, lsl #32
    // 0xef617c: cmp             w0, NULL
    // 0xef6180: b.ne            #0xef618c
    // 0xef6184: r5 = Null
    //     0xef6184: mov             x5, NULL
    // 0xef6188: b               #0xef6190
    // 0xef618c: mov             x5, x0
    // 0xef6190: ldr             x4, [fp, #0x30]
    // 0xef6194: ldr             x3, [fp, #0x28]
    // 0xef6198: r0 = 4
    //     0xef6198: mov             x0, #4
    // 0xef619c: mov             x2, x0
    // 0xef61a0: stur            x5, [fp, #-8]
    // 0xef61a4: r1 = Null
    //     0xef61a4: mov             x1, NULL
    // 0xef61a8: r0 = AllocateArray()
    //     0xef61a8: bl              #0x13df928  ; AllocateArrayStub
    // 0xef61ac: mov             x2, x0
    // 0xef61b0: ldur            x0, [fp, #-8]
    // 0xef61b4: stur            x2, [fp, #-0x18]
    // 0xef61b8: StoreField: r2->field_f = r0
    //     0xef61b8: stur            w0, [x2, #0xf]
    // 0xef61bc: ldr             x0, [fp, #0x28]
    // 0xef61c0: StoreField: r2->field_13 = r0
    //     0xef61c0: stur            w0, [x2, #0x13]
    // 0xef61c4: r1 = <Listenable?>
    //     0xef61c4: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c6d0] TypeArguments: <Listenable?>
    //     0xef61c8: ldr             x1, [x1, #0x6d0]
    // 0xef61cc: r0 = AllocateGrowableArray()
    //     0xef61cc: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xef61d0: mov             x1, x0
    // 0xef61d4: ldur            x0, [fp, #-0x18]
    // 0xef61d8: stur            x1, [fp, #-8]
    // 0xef61dc: StoreField: r1->field_f = r0
    //     0xef61dc: stur            w0, [x1, #0xf]
    // 0xef61e0: r0 = 4
    //     0xef61e0: mov             x0, #4
    // 0xef61e4: StoreField: r1->field_b = r0
    //     0xef61e4: stur            w0, [x1, #0xb]
    // 0xef61e8: r0 = _MergingListenable()
    //     0xef61e8: bl              #0xd26450  ; Allocate_MergingListenableStub -> _MergingListenable (size=0xc)
    // 0xef61ec: mov             x1, x0
    // 0xef61f0: ldur            x0, [fp, #-8]
    // 0xef61f4: StoreField: r1->field_7 = r0
    //     0xef61f4: stur            w0, [x1, #7]
    // 0xef61f8: mov             x0, x1
    // 0xef61fc: ldur            x1, [fp, #-0x10]
    // 0xef6200: StoreField: r1->field_7 = r0
    //     0xef6200: stur            w0, [x1, #7]
    //     0xef6204: ldurb           w16, [x1, #-1]
    //     0xef6208: ldurb           w17, [x0, #-1]
    //     0xef620c: and             x16, x17, x16, lsr #2
    //     0xef6210: tst             x16, HEAP, lsr #32
    //     0xef6214: b.eq            #0xef621c
    //     0xef6218: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef621c: ldr             x0, [fp, #0x30]
    // 0xef6220: cmp             w0, NULL
    // 0xef6224: b.eq            #0xef623c
    // 0xef6228: LoadField: r2 = r0->field_43
    //     0xef6228: ldur            w2, [x0, #0x43]
    // 0xef622c: DecompressPointer r2
    //     0xef622c: add             x2, x2, HEAP, lsl #32
    // 0xef6230: LoadField: r3 = r0->field_47
    //     0xef6230: ldur            w3, [x0, #0x47]
    // 0xef6234: DecompressPointer r3
    //     0xef6234: add             x3, x3, HEAP, lsl #32
    // 0xef6238: r0 = saveTabOffsets()
    //     0xef6238: bl              #0xbbf4e4  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::saveTabOffsets
    // 0xef623c: r0 = Null
    //     0xef623c: mov             x0, NULL
    // 0xef6240: LeaveFrame
    //     0xef6240: mov             SP, fp
    //     0xef6244: ldp             fp, lr, [SP], #0x10
    // 0xef6248: ret
    //     0xef6248: ret             
    // 0xef624c: r0 = StackOverflowSharedWithFPURegs()
    //     0xef624c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xef6250: b               #0xef6020
  }
}

// class id: 4371, size: 0x18, field offset: 0xc
class _DragAnimation extends _MixinApplication113&Animation&AnimationWithParentMixin {

  double value(_DragAnimation) {
    // ** addr: 0xae63fc, size: 0x1b8
    // 0xae63fc: EnterFrame
    //     0xae63fc: stp             fp, lr, [SP, #-0x10]!
    //     0xae6400: mov             fp, SP
    // 0xae6404: AllocStack(0x28)
    //     0xae6404: sub             SP, SP, #0x28
    // 0xae6408: SetupParameters(_DragAnimation this /* r1 => r2, fp-0x10 */)
    //     0xae6408: mov             x2, x1
    //     0xae640c: stur            x1, [fp, #-0x10]
    // 0xae6410: CheckStackOverflow
    //     0xae6410: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae6414: cmp             SP, x16
    //     0xae6418: b.ls            #0xae6590
    // 0xae641c: LoadField: r3 = r2->field_b
    //     0xae641c: ldur            w3, [x2, #0xb]
    // 0xae6420: DecompressPointer r3
    //     0xae6420: add             x3, x3, HEAP, lsl #32
    // 0xae6424: stur            x3, [fp, #-8]
    // 0xae6428: LoadField: r0 = r3->field_2b
    //     0xae6428: ldur            x0, [x3, #0x2b]
    // 0xae642c: sub             x4, x0, #1
    // 0xae6430: r0 = BoxInt64Instr(r4)
    //     0xae6430: sbfiz           x0, x4, #1, #0x1f
    //     0xae6434: cmp             x4, x0, asr #1
    //     0xae6438: b.eq            #0xae6444
    //     0xae643c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xae6440: stur            x4, [x0, #7]
    // 0xae6444: stp             x0, NULL, [SP]
    // 0xae6448: r0 = _Double.fromInteger()
    //     0xae6448: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0xae644c: mov             x1, x0
    // 0xae6450: ldur            x0, [fp, #-8]
    // 0xae6454: LoadField: r2 = r0->field_23
    //     0xae6454: ldur            w2, [x0, #0x23]
    // 0xae6458: DecompressPointer r2
    //     0xae6458: add             x2, x2, HEAP, lsl #32
    // 0xae645c: cmp             w2, NULL
    // 0xae6460: b.ne            #0xae646c
    // 0xae6464: r0 = Null
    //     0xae6464: mov             x0, NULL
    // 0xae6468: b               #0xae6470
    // 0xae646c: mov             x0, x2
    // 0xae6470: d0 = 0.000000
    //     0xae6470: eor             v0.16b, v0.16b, v0.16b
    // 0xae6474: cmp             w0, NULL
    // 0xae6478: b.eq            #0xae6598
    // 0xae647c: LoadField: r2 = r0->field_37
    //     0xae647c: ldur            w2, [x0, #0x37]
    // 0xae6480: DecompressPointer r2
    //     0xae6480: add             x2, x2, HEAP, lsl #32
    // 0xae6484: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xae6488: cmp             w2, w16
    // 0xae648c: b.eq            #0xae659c
    // 0xae6490: LoadField: d1 = r2->field_7
    //     0xae6490: ldur            d1, [x2, #7]
    // 0xae6494: fcmp            d0, d1
    // 0xae6498: b.le            #0xae64a4
    // 0xae649c: d1 = 0.000000
    //     0xae649c: eor             v1.16b, v1.16b, v1.16b
    // 0xae64a0: b               #0xae64c4
    // 0xae64a4: LoadField: d2 = r1->field_7
    //     0xae64a4: ldur            d2, [x1, #7]
    // 0xae64a8: fcmp            d1, d2
    // 0xae64ac: b.le            #0xae64b8
    // 0xae64b0: mov             v1.16b, v2.16b
    // 0xae64b4: b               #0xae64c4
    // 0xae64b8: fcmp            d1, d1
    // 0xae64bc: b.vc            #0xae64c4
    // 0xae64c0: mov             v1.16b, v2.16b
    // 0xae64c4: ldur            x0, [fp, #-0x10]
    // 0xae64c8: stur            d1, [fp, #-0x18]
    // 0xae64cc: LoadField: r2 = r0->field_f
    //     0xae64cc: ldur            x2, [x0, #0xf]
    // 0xae64d0: r0 = BoxInt64Instr(r2)
    //     0xae64d0: sbfiz           x0, x2, #1, #0x1f
    //     0xae64d4: cmp             x2, x0, asr #1
    //     0xae64d8: b.eq            #0xae64e4
    //     0xae64dc: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0xae64e0: stur            x2, [x0, #7]
    // 0xae64e4: stp             x0, NULL, [SP]
    // 0xae64e8: r0 = _Double.fromInteger()
    //     0xae64e8: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0xae64ec: LoadField: d0 = r0->field_7
    //     0xae64ec: ldur            d0, [x0, #7]
    // 0xae64f0: ldur            d1, [fp, #-0x18]
    // 0xae64f4: fsub            d2, d1, d0
    // 0xae64f8: d0 = 0.000000
    //     0xae64f8: eor             v0.16b, v0.16b, v0.16b
    // 0xae64fc: fcmp            d2, d0
    // 0xae6500: b.ne            #0xae650c
    // 0xae6504: d1 = 0.000000
    //     0xae6504: eor             v1.16b, v1.16b, v1.16b
    // 0xae6508: b               #0xae6520
    // 0xae650c: fcmp            d0, d2
    // 0xae6510: b.le            #0xae651c
    // 0xae6514: fneg            d1, d2
    // 0xae6518: b               #0xae6520
    // 0xae651c: mov             v1.16b, v2.16b
    // 0xae6520: fcmp            d0, d1
    // 0xae6524: b.le            #0xae6530
    // 0xae6528: d0 = 0.000000
    //     0xae6528: eor             v0.16b, v0.16b, v0.16b
    // 0xae652c: b               #0xae6558
    // 0xae6530: d0 = 1.000000
    //     0xae6530: fmov            d0, #1.00000000
    // 0xae6534: fcmp            d1, d0
    // 0xae6538: b.le            #0xae6544
    // 0xae653c: d0 = 1.000000
    //     0xae653c: fmov            d0, #1.00000000
    // 0xae6540: b               #0xae6558
    // 0xae6544: fcmp            d1, d1
    // 0xae6548: b.vc            #0xae6554
    // 0xae654c: d0 = 1.000000
    //     0xae654c: fmov            d0, #1.00000000
    // 0xae6550: b               #0xae6558
    // 0xae6554: mov             v0.16b, v1.16b
    // 0xae6558: r0 = inline_Allocate_Double()
    //     0xae6558: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xae655c: add             x0, x0, #0x10
    //     0xae6560: cmp             x1, x0
    //     0xae6564: b.ls            #0xae65a4
    //     0xae6568: str             x0, [THR, #0x60]  ; THR::top
    //     0xae656c: sub             x0, x0, #0xf
    //     0xae6570: mov             x1, #0xe19c
    //     0xae6574: movk            x1, #3, lsl #16
    //     0xae6578: stur            x1, [x0, #-1]
    // 0xae657c: dmb             ishst
    // 0xae6580: StoreField: r0->field_7 = d0
    //     0xae6580: stur            d0, [x0, #7]
    // 0xae6584: LeaveFrame
    //     0xae6584: mov             SP, fp
    //     0xae6588: ldp             fp, lr, [SP], #0x10
    // 0xae658c: ret
    //     0xae658c: ret             
    // 0xae6590: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae6590: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae6594: b               #0xae641c
    // 0xae6598: r0 = NullCastErrorSharedWithFPURegs()
    //     0xae6598: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xae659c: r9 = _value
    //     0xae659c: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xae65a0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xae65a0: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xae65a4: SaveReg d0
    //     0xae65a4: str             q0, [SP, #-0x10]!
    // 0xae65a8: r0 = AllocateDouble()
    //     0xae65a8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xae65ac: RestoreReg d0
    //     0xae65ac: ldr             q0, [SP], #0x10
    // 0xae65b0: b               #0xae6580
  }
  double dyn:get:value(_DragAnimation) {
    // ** addr: 0xae65cc, size: 0x48
    // 0xae65cc: EnterFrame
    //     0xae65cc: stp             fp, lr, [SP, #-0x10]!
    //     0xae65d0: mov             fp, SP
    // 0xae65d4: CheckStackOverflow
    //     0xae65d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae65d8: cmp             SP, x16
    //     0xae65dc: b.ls            #0xae65f4
    // 0xae65e0: ldr             x1, [fp, #0x10]
    // 0xae65e4: r0 = value()
    //     0xae65e4: bl              #0xae63fc  ; [package:flutter/src/material/tabs.dart] _DragAnimation::value
    // 0xae65e8: LeaveFrame
    //     0xae65e8: mov             SP, fp
    //     0xae65ec: ldp             fp, lr, [SP], #0x10
    // 0xae65f0: ret
    //     0xae65f0: ret             
    // 0xae65f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae65f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae65f8: b               #0xae65e0
  }
  _ removeListener(/* No info */) {
    // ** addr: 0xd00c2c, size: 0x48
    // 0xd00c2c: EnterFrame
    //     0xd00c2c: stp             fp, lr, [SP, #-0x10]!
    //     0xd00c30: mov             fp, SP
    // 0xd00c34: CheckStackOverflow
    //     0xd00c34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd00c38: cmp             SP, x16
    //     0xd00c3c: b.ls            #0xd00c6c
    // 0xd00c40: LoadField: r0 = r1->field_b
    //     0xd00c40: ldur            w0, [x1, #0xb]
    // 0xd00c44: DecompressPointer r0
    //     0xd00c44: add             x0, x0, HEAP, lsl #32
    // 0xd00c48: LoadField: r3 = r0->field_23
    //     0xd00c48: ldur            w3, [x0, #0x23]
    // 0xd00c4c: DecompressPointer r3
    //     0xd00c4c: add             x3, x3, HEAP, lsl #32
    // 0xd00c50: cmp             w3, NULL
    // 0xd00c54: b.eq            #0xd00c5c
    // 0xd00c58: r0 = removeListener()
    //     0xd00c58: bl              #0xd00b50  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::removeListener
    // 0xd00c5c: r0 = Null
    //     0xd00c5c: mov             x0, NULL
    // 0xd00c60: LeaveFrame
    //     0xd00c60: mov             SP, fp
    //     0xd00c64: ldp             fp, lr, [SP], #0x10
    // 0xd00c68: ret
    //     0xd00c68: ret             
    // 0xd00c6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd00c6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd00c70: b               #0xd00c40
  }
  _ removeStatusListener(/* No info */) {
    // ** addr: 0x12599ac, size: 0x48
    // 0x12599ac: EnterFrame
    //     0x12599ac: stp             fp, lr, [SP, #-0x10]!
    //     0x12599b0: mov             fp, SP
    // 0x12599b4: CheckStackOverflow
    //     0x12599b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12599b8: cmp             SP, x16
    //     0x12599bc: b.ls            #0x12599ec
    // 0x12599c0: LoadField: r0 = r1->field_b
    //     0x12599c0: ldur            w0, [x1, #0xb]
    // 0x12599c4: DecompressPointer r0
    //     0x12599c4: add             x0, x0, HEAP, lsl #32
    // 0x12599c8: LoadField: r3 = r0->field_23
    //     0x12599c8: ldur            w3, [x0, #0x23]
    // 0x12599cc: DecompressPointer r3
    //     0x12599cc: add             x3, x3, HEAP, lsl #32
    // 0x12599d0: cmp             w3, NULL
    // 0x12599d4: b.eq            #0x12599dc
    // 0x12599d8: r0 = removeStatusListener()
    //     0x12599d8: bl              #0x12598d4  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::removeStatusListener
    // 0x12599dc: r0 = Null
    //     0x12599dc: mov             x0, NULL
    // 0x12599e0: LeaveFrame
    //     0x12599e0: mov             SP, fp
    //     0x12599e4: ldp             fp, lr, [SP], #0x10
    // 0x12599e8: ret
    //     0x12599e8: ret             
    // 0x12599ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12599ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12599f0: b               #0x12599c0
  }
}

// class id: 4372, size: 0x10, field offset: 0xc
class _ChangeAnimation extends _MixinApplication113&Animation&AnimationWithParentMixin {

  double value(_ChangeAnimation) {
    // ** addr: 0xae6140, size: 0x74
    // 0xae6140: EnterFrame
    //     0xae6140: stp             fp, lr, [SP, #-0x10]!
    //     0xae6144: mov             fp, SP
    // 0xae6148: CheckStackOverflow
    //     0xae6148: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae614c: cmp             SP, x16
    //     0xae6150: b.ls            #0xae619c
    // 0xae6154: LoadField: r0 = r1->field_b
    //     0xae6154: ldur            w0, [x1, #0xb]
    // 0xae6158: DecompressPointer r0
    //     0xae6158: add             x0, x0, HEAP, lsl #32
    // 0xae615c: mov             x1, x0
    // 0xae6160: r0 = _indexChangeProgress()
    //     0xae6160: bl              #0xae61fc  ; [package:flutter/src/material/tabs.dart] ::_indexChangeProgress
    // 0xae6164: r0 = inline_Allocate_Double()
    //     0xae6164: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xae6168: add             x0, x0, #0x10
    //     0xae616c: cmp             x1, x0
    //     0xae6170: b.ls            #0xae61a4
    //     0xae6174: str             x0, [THR, #0x60]  ; THR::top
    //     0xae6178: sub             x0, x0, #0xf
    //     0xae617c: mov             x1, #0xe19c
    //     0xae6180: movk            x1, #3, lsl #16
    //     0xae6184: stur            x1, [x0, #-1]
    // 0xae6188: dmb             ishst
    // 0xae618c: StoreField: r0->field_7 = d0
    //     0xae618c: stur            d0, [x0, #7]
    // 0xae6190: LeaveFrame
    //     0xae6190: mov             SP, fp
    //     0xae6194: ldp             fp, lr, [SP], #0x10
    // 0xae6198: ret
    //     0xae6198: ret             
    // 0xae619c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae619c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae61a0: b               #0xae6154
    // 0xae61a4: SaveReg d0
    //     0xae61a4: str             q0, [SP, #-0x10]!
    // 0xae61a8: r0 = AllocateDouble()
    //     0xae61a8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xae61ac: RestoreReg d0
    //     0xae61ac: ldr             q0, [SP], #0x10
    // 0xae61b0: b               #0xae618c
  }
  double dyn:get:value(_ChangeAnimation) {
    // ** addr: 0xae61cc, size: 0x48
    // 0xae61cc: EnterFrame
    //     0xae61cc: stp             fp, lr, [SP, #-0x10]!
    //     0xae61d0: mov             fp, SP
    // 0xae61d4: CheckStackOverflow
    //     0xae61d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae61d8: cmp             SP, x16
    //     0xae61dc: b.ls            #0xae61f4
    // 0xae61e0: ldr             x1, [fp, #0x10]
    // 0xae61e4: r0 = value()
    //     0xae61e4: bl              #0xae6140  ; [package:flutter/src/material/tabs.dart] _ChangeAnimation::value
    // 0xae61e8: LeaveFrame
    //     0xae61e8: mov             SP, fp
    //     0xae61ec: ldp             fp, lr, [SP], #0x10
    // 0xae61f0: ret
    //     0xae61f0: ret             
    // 0xae61f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae61f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae61f8: b               #0xae61e0
  }
}

// class id: 4487, size: 0x44, field offset: 0x40
class TabBarScrollController extends ScrollController {

  _ dispose(/* No info */) {
    // ** addr: 0x10ef50c, size: 0x34
    // 0x10ef50c: EnterFrame
    //     0x10ef50c: stp             fp, lr, [SP, #-0x10]!
    //     0x10ef510: mov             fp, SP
    // 0x10ef514: CheckStackOverflow
    //     0x10ef514: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ef518: cmp             SP, x16
    //     0x10ef51c: b.ls            #0x10ef538
    // 0x10ef520: StoreField: r1->field_3f = rNULL
    //     0x10ef520: stur            NULL, [x1, #0x3f]
    // 0x10ef524: r0 = dispose()
    //     0x10ef524: bl              #0x10ef540  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0x10ef528: r0 = Null
    //     0x10ef528: mov             x0, NULL
    // 0x10ef52c: LeaveFrame
    //     0x10ef52c: mov             SP, fp
    //     0x10ef530: ldp             fp, lr, [SP], #0x10
    // 0x10ef534: ret
    //     0x10ef534: ret             
    // 0x10ef538: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ef538: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ef53c: b               #0x10ef520
  }
}

// class id: 4488, size: 0x24, field offset: 0x24
class _IndicatorPainterNotifier extends ChangeNotifier {
}

// class id: 4543, size: 0x88, field offset: 0x7c
class _TabBarScrollPosition extends ScrollPositionWithSingleContext {

  _ _TabBarScrollPosition(/* No info */) {
    // ** addr: 0xef15ec, size: 0x80
    // 0xef15ec: EnterFrame
    //     0xef15ec: stp             fp, lr, [SP, #-0x10]!
    //     0xef15f0: mov             fp, SP
    // 0xef15f4: AllocStack(0x8)
    //     0xef15f4: sub             SP, SP, #8
    // 0xef15f8: r4 = false
    //     0xef15f8: add             x4, NULL, #0x30  ; false
    // 0xef15fc: r0 = true
    //     0xef15fc: add             x0, NULL, #0x20  ; true
    // 0xef1600: mov             x16, x6
    // 0xef1604: mov             x6, x1
    // 0xef1608: mov             x1, x16
    // 0xef160c: CheckStackOverflow
    //     0xef160c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef1610: cmp             SP, x16
    //     0xef1614: b.ls            #0xef1664
    // 0xef1618: StoreField: r6->field_7f = r4
    //     0xef1618: stur            w4, [x6, #0x7f]
    // 0xef161c: StoreField: r6->field_83 = r0
    //     0xef161c: stur            w0, [x6, #0x83]
    // 0xef1620: mov             x0, x1
    // 0xef1624: StoreField: r6->field_7b = r0
    //     0xef1624: stur            w0, [x6, #0x7b]
    //     0xef1628: ldurb           w16, [x6, #-1]
    //     0xef162c: ldurb           w17, [x0, #-1]
    //     0xef1630: and             x16, x17, x16, lsr #2
    //     0xef1634: tst             x16, HEAP, lsr #32
    //     0xef1638: b.eq            #0xef1640
    //     0xef163c: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xef1640: str             NULL, [SP]
    // 0xef1644: mov             x1, x6
    // 0xef1648: r4 = const [0, 0x5, 0x1, 0x4, initialPixels, 0x4, null]
    //     0xef1648: add             x4, PP, #0x98, lsl #12  ; [pp+0x98c98] List(7) [0, 0x5, 0x1, 0x4, "initialPixels", 0x4, Null]
    //     0xef164c: ldr             x4, [x4, #0xc98]
    // 0xef1650: r0 = ScrollPositionWithSingleContext()
    //     0xef1650: bl              #0xef1808  ; [package:flutter/src/widgets/scroll_position_with_single_context.dart] ScrollPositionWithSingleContext::ScrollPositionWithSingleContext
    // 0xef1654: r0 = Null
    //     0xef1654: mov             x0, NULL
    // 0xef1658: LeaveFrame
    //     0xef1658: mov             SP, fp
    //     0xef165c: ldp             fp, lr, [SP], #0x10
    // 0xef1660: ret
    //     0xef1660: ret             
    // 0xef1664: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef1664: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef1668: b               #0xef1618
  }
  _ markNeedsPixelsCorrection(/* No info */) {
    // ** addr: 0xf6f2a8, size: 0x10
    // 0xf6f2a8: r2 = true
    //     0xf6f2a8: add             x2, NULL, #0x20  ; true
    // 0xf6f2ac: StoreField: r1->field_83 = r2
    //     0xf6f2ac: stur            w2, [x1, #0x83]
    // 0xf6f2b0: r0 = Null
    //     0xf6f2b0: mov             x0, NULL
    // 0xf6f2b4: ret
    //     0xf6f2b4: ret             
  }
  _ applyContentDimensions(/* No info */) {
    // ** addr: 0x1285864, size: 0xec
    // 0x1285864: EnterFrame
    //     0x1285864: stp             fp, lr, [SP, #-0x10]!
    //     0x1285868: mov             fp, SP
    // 0x128586c: AllocStack(0x20)
    //     0x128586c: sub             SP, SP, #0x20
    // 0x1285870: SetupParameters(_TabBarScrollPosition this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x18 */, dynamic _ /* d1 => d1, fp-0x20 */)
    //     0x1285870: mov             x0, x1
    //     0x1285874: stur            x1, [fp, #-8]
    //     0x1285878: stur            d0, [fp, #-0x18]
    //     0x128587c: stur            d1, [fp, #-0x20]
    // 0x1285880: CheckStackOverflow
    //     0x1285880: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1285884: cmp             SP, x16
    //     0x1285888: b.ls            #0x1285940
    // 0x128588c: LoadField: r1 = r0->field_7f
    //     0x128588c: ldur            w1, [x0, #0x7f]
    // 0x1285890: DecompressPointer r1
    //     0x1285890: add             x1, x1, HEAP, lsl #32
    // 0x1285894: tbz             w1, #4, #0x12858c4
    // 0x1285898: d2 = 0.000000
    //     0x1285898: eor             v2.16b, v2.16b, v2.16b
    // 0x128589c: LoadField: r1 = r0->field_43
    //     0x128589c: ldur            w1, [x0, #0x43]
    // 0x12858a0: DecompressPointer r1
    //     0x12858a0: add             x1, x1, HEAP, lsl #32
    // 0x12858a4: cmp             w1, NULL
    // 0x12858a8: b.eq            #0x1285948
    // 0x12858ac: LoadField: d3 = r1->field_7
    //     0x12858ac: ldur            d3, [x1, #7]
    // 0x12858b0: fcmp            d3, d2
    // 0x12858b4: r16 = true
    //     0x12858b4: add             x16, NULL, #0x20  ; true
    // 0x12858b8: r17 = false
    //     0x12858b8: add             x17, NULL, #0x30  ; false
    // 0x12858bc: csel            x1, x16, x17, ne
    // 0x12858c0: StoreField: r0->field_7f = r1
    //     0x12858c0: stur            w1, [x0, #0x7f]
    // 0x12858c4: tbnz            w1, #4, #0x12858d4
    // 0x12858c8: LoadField: r1 = r0->field_83
    //     0x12858c8: ldur            w1, [x0, #0x83]
    // 0x12858cc: DecompressPointer r1
    //     0x12858cc: add             x1, x1, HEAP, lsl #32
    // 0x12858d0: tbnz            w1, #4, #0x128590c
    // 0x12858d4: r1 = false
    //     0x12858d4: add             x1, NULL, #0x30  ; false
    // 0x12858d8: StoreField: r0->field_83 = r1
    //     0x12858d8: stur            w1, [x0, #0x83]
    // 0x12858dc: LoadField: r1 = r0->field_7b
    //     0x12858dc: ldur            w1, [x0, #0x7b]
    // 0x12858e0: DecompressPointer r1
    //     0x12858e0: add             x1, x1, HEAP, lsl #32
    // 0x12858e4: LoadField: r2 = r0->field_43
    //     0x12858e4: ldur            w2, [x0, #0x43]
    // 0x12858e8: DecompressPointer r2
    //     0x12858e8: add             x2, x2, HEAP, lsl #32
    // 0x12858ec: cmp             w2, NULL
    // 0x12858f0: b.eq            #0x128594c
    // 0x12858f4: r0 = _initialScrollOffset()
    //     0x12858f4: bl              #0x1285950  ; [package:flutter/src/material/tabs.dart] _TabBarState::_initialScrollOffset
    // 0x12858f8: ldur            x1, [fp, #-8]
    // 0x12858fc: r0 = 0.000000
    //     0x12858fc: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x1285900: StoreField: r1->field_3f = r0
    //     0x1285900: stur            w0, [x1, #0x3f]
    // 0x1285904: r0 = false
    //     0x1285904: add             x0, NULL, #0x30  ; false
    // 0x1285908: b               #0x1285914
    // 0x128590c: mov             x1, x0
    // 0x1285910: r0 = true
    //     0x1285910: add             x0, NULL, #0x20  ; true
    // 0x1285914: ldur            d0, [fp, #-0x18]
    // 0x1285918: ldur            d1, [fp, #-0x20]
    // 0x128591c: stur            x0, [fp, #-0x10]
    // 0x1285920: r0 = applyContentDimensions()
    //     0x1285920: bl              #0x12859f8  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::applyContentDimensions
    // 0x1285924: tbnz            w0, #4, #0x1285930
    // 0x1285928: ldur            x0, [fp, #-0x10]
    // 0x128592c: b               #0x1285934
    // 0x1285930: r0 = false
    //     0x1285930: add             x0, NULL, #0x30  ; false
    // 0x1285934: LeaveFrame
    //     0x1285934: mov             SP, fp
    //     0x1285938: ldp             fp, lr, [SP], #0x10
    // 0x128593c: ret
    //     0x128593c: ret             
    // 0x1285940: r0 = StackOverflowSharedWithFPURegs()
    //     0x1285940: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1285944: b               #0x128588c
    // 0x1285948: r0 = NullCastErrorSharedWithFPURegs()
    //     0x1285948: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x128594c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x128594c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
}

// class id: 4862, size: 0x9c, field offset: 0x98
class _TabLabelBarRenderer extends RenderFlex {

  _ performLayout(/* No info */) {
    // ** addr: 0xbbf0b4, size: 0x3a8
    // 0xbbf0b4: EnterFrame
    //     0xbbf0b4: stp             fp, lr, [SP, #-0x10]!
    //     0xbbf0b8: mov             fp, SP
    // 0xbbf0bc: AllocStack(0x28)
    //     0xbbf0bc: sub             SP, SP, #0x28
    // 0xbbf0c0: SetupParameters(_TabLabelBarRenderer this /* r1 => r0, fp-0x8 */)
    //     0xbbf0c0: mov             x0, x1
    //     0xbbf0c4: stur            x1, [fp, #-8]
    // 0xbbf0c8: CheckStackOverflow
    //     0xbbf0c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbf0cc: cmp             SP, x16
    //     0xbbf0d0: b.ls            #0xbbf3d0
    // 0xbbf0d4: mov             x1, x0
    // 0xbbf0d8: r0 = performLayout()
    //     0xbbf0d8: bl              #0xbbf548  ; [package:flutter/src/rendering/flex.dart] RenderFlex::performLayout
    // 0xbbf0dc: ldur            x0, [fp, #-8]
    // 0xbbf0e0: LoadField: r3 = r0->field_57
    //     0xbbf0e0: ldur            w3, [x0, #0x57]
    // 0xbbf0e4: DecompressPointer r3
    //     0xbbf0e4: add             x3, x3, HEAP, lsl #32
    // 0xbbf0e8: stur            x3, [fp, #-0x10]
    // 0xbbf0ec: r1 = <double>
    //     0xbbf0ec: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xbbf0f0: r2 = 0
    //     0xbbf0f0: mov             x2, #0
    // 0xbbf0f4: r0 = _GrowableList()
    //     0xbbf0f4: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xbbf0f8: mov             x3, x0
    // 0xbbf0fc: stur            x3, [fp, #-0x18]
    // 0xbbf100: ldur            x0, [fp, #-0x10]
    // 0xbbf104: CheckStackOverflow
    //     0xbbf104: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbf108: cmp             SP, x16
    //     0xbbf10c: b.ls            #0xbbf3d8
    // 0xbbf110: cmp             w0, NULL
    // 0xbbf114: b.eq            #0xbbf228
    // 0xbbf118: LoadField: r4 = r0->field_7
    //     0xbbf118: ldur            w4, [x0, #7]
    // 0xbbf11c: DecompressPointer r4
    //     0xbbf11c: add             x4, x4, HEAP, lsl #32
    // 0xbbf120: stur            x4, [fp, #-0x10]
    // 0xbbf124: cmp             w4, NULL
    // 0xbbf128: b.eq            #0xbbf3e0
    // 0xbbf12c: mov             x0, x4
    // 0xbbf130: r2 = Null
    //     0xbbf130: mov             x2, NULL
    // 0xbbf134: r1 = Null
    //     0xbbf134: mov             x1, NULL
    // 0xbbf138: r4 = LoadClassIdInstr(r0)
    //     0xbbf138: ldur            x4, [x0, #-1]
    //     0xbbf13c: ubfx            x4, x4, #0xc, #0x14
    // 0xbbf140: r17 = 4212
    //     0xbbf140: mov             x17, #0x1074
    // 0xbbf144: cmp             x4, x17
    // 0xbbf148: b.eq            #0xbbf160
    // 0xbbf14c: r8 = FlexParentData
    //     0xbbf14c: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0xbbf150: ldr             x8, [x8, #0x10]
    // 0xbbf154: r3 = Null
    //     0xbbf154: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0dc8] Null
    //     0xbbf158: ldr             x3, [x3, #0xdc8]
    // 0xbbf15c: r0 = DefaultTypeTest()
    //     0xbbf15c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbbf160: ldur            x0, [fp, #-0x10]
    // 0xbbf164: LoadField: r1 = r0->field_7
    //     0xbbf164: ldur            w1, [x0, #7]
    // 0xbbf168: DecompressPointer r1
    //     0xbbf168: add             x1, x1, HEAP, lsl #32
    // 0xbbf16c: LoadField: d0 = r1->field_7
    //     0xbbf16c: ldur            d0, [x1, #7]
    // 0xbbf170: ldur            x2, [fp, #-0x18]
    // 0xbbf174: stur            d0, [fp, #-0x28]
    // 0xbbf178: LoadField: r1 = r2->field_b
    //     0xbbf178: ldur            w1, [x2, #0xb]
    // 0xbbf17c: LoadField: r3 = r2->field_f
    //     0xbbf17c: ldur            w3, [x2, #0xf]
    // 0xbbf180: DecompressPointer r3
    //     0xbbf180: add             x3, x3, HEAP, lsl #32
    // 0xbbf184: LoadField: r4 = r3->field_b
    //     0xbbf184: ldur            w4, [x3, #0xb]
    // 0xbbf188: r3 = LoadInt32Instr(r1)
    //     0xbbf188: sbfx            x3, x1, #1, #0x1f
    // 0xbbf18c: stur            x3, [fp, #-0x20]
    // 0xbbf190: r1 = LoadInt32Instr(r4)
    //     0xbbf190: sbfx            x1, x4, #1, #0x1f
    // 0xbbf194: cmp             x3, x1
    // 0xbbf198: b.ne            #0xbbf1a4
    // 0xbbf19c: mov             x1, x2
    // 0xbbf1a0: r0 = _growToNextCapacity()
    //     0xbbf1a0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xbbf1a4: ldur            x3, [fp, #-0x18]
    // 0xbbf1a8: ldur            x2, [fp, #-0x10]
    // 0xbbf1ac: ldur            d0, [fp, #-0x28]
    // 0xbbf1b0: ldur            x4, [fp, #-0x20]
    // 0xbbf1b4: add             x0, x4, #1
    // 0xbbf1b8: lsl             x1, x0, #1
    // 0xbbf1bc: StoreField: r3->field_b = r1
    //     0xbbf1bc: stur            w1, [x3, #0xb]
    // 0xbbf1c0: LoadField: r1 = r3->field_f
    //     0xbbf1c0: ldur            w1, [x3, #0xf]
    // 0xbbf1c4: DecompressPointer r1
    //     0xbbf1c4: add             x1, x1, HEAP, lsl #32
    // 0xbbf1c8: r0 = inline_Allocate_Double()
    //     0xbbf1c8: ldp             x0, x5, [THR, #0x60]  ; THR::top
    //     0xbbf1cc: add             x0, x0, #0x10
    //     0xbbf1d0: cmp             x5, x0
    //     0xbbf1d4: b.ls            #0xbbf3e4
    //     0xbbf1d8: str             x0, [THR, #0x60]  ; THR::top
    //     0xbbf1dc: sub             x0, x0, #0xf
    //     0xbbf1e0: mov             x5, #0xe19c
    //     0xbbf1e4: movk            x5, #3, lsl #16
    //     0xbbf1e8: stur            x5, [x0, #-1]
    // 0xbbf1ec: dmb             ishst
    // 0xbbf1f0: StoreField: r0->field_7 = d0
    //     0xbbf1f0: stur            d0, [x0, #7]
    // 0xbbf1f4: ArrayStore: r1[r4] = r0  ; List_4
    //     0xbbf1f4: add             x25, x1, x4, lsl #2
    //     0xbbf1f8: add             x25, x25, #0xf
    //     0xbbf1fc: str             w0, [x25]
    //     0xbbf200: tbz             w0, #0, #0xbbf21c
    //     0xbbf204: ldurb           w16, [x1, #-1]
    //     0xbbf208: ldurb           w17, [x0, #-1]
    //     0xbbf20c: and             x16, x17, x16, lsr #2
    //     0xbbf210: tst             x16, HEAP, lsr #32
    //     0xbbf214: b.eq            #0xbbf21c
    //     0xbbf218: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbbf21c: LoadField: r0 = r2->field_13
    //     0xbbf21c: ldur            w0, [x2, #0x13]
    // 0xbbf220: DecompressPointer r0
    //     0xbbf220: add             x0, x0, HEAP, lsl #32
    // 0xbbf224: b               #0xbbf104
    // 0xbbf228: ldur            x0, [fp, #-8]
    // 0xbbf22c: LoadField: r1 = r0->field_73
    //     0xbbf22c: ldur            w1, [x0, #0x73]
    // 0xbbf230: DecompressPointer r1
    //     0xbbf230: add             x1, x1, HEAP, lsl #32
    // 0xbbf234: cmp             w1, NULL
    // 0xbbf238: b.eq            #0xbbf404
    // 0xbbf23c: LoadField: r2 = r1->field_7
    //     0xbbf23c: ldur            x2, [x1, #7]
    // 0xbbf240: cmp             x2, #0
    // 0xbbf244: b.gt            #0xbbf294
    // 0xbbf248: mov             x1, x0
    // 0xbbf24c: r0 = size()
    //     0xbbf24c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbf250: LoadField: d0 = r0->field_7
    //     0xbbf250: ldur            d0, [x0, #7]
    // 0xbbf254: r3 = inline_Allocate_Double()
    //     0xbbf254: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xbbf258: add             x3, x3, #0x10
    //     0xbbf25c: cmp             x0, x3
    //     0xbbf260: b.ls            #0xbbf408
    //     0xbbf264: str             x3, [THR, #0x60]  ; THR::top
    //     0xbbf268: sub             x3, x3, #0xf
    //     0xbbf26c: mov             x0, #0xe19c
    //     0xbbf270: movk            x0, #3, lsl #16
    //     0xbbf274: stur            x0, [x3, #-1]
    // 0xbbf278: dmb             ishst
    // 0xbbf27c: StoreField: r3->field_7 = d0
    //     0xbbf27c: stur            d0, [x3, #7]
    // 0xbbf280: ldur            x1, [fp, #-0x18]
    // 0xbbf284: r2 = 0
    //     0xbbf284: mov             x2, #0
    // 0xbbf288: r0 = insert()
    //     0xbbf288: bl              #0xa0d864  ; [dart:core] _GrowableList::insert
    // 0xbbf28c: ldur            x2, [fp, #-0x18]
    // 0xbbf290: b               #0xbbf34c
    // 0xbbf294: mov             x0, x3
    // 0xbbf298: ldur            x1, [fp, #-8]
    // 0xbbf29c: r0 = size()
    //     0xbbf29c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbf2a0: LoadField: d0 = r0->field_7
    //     0xbbf2a0: ldur            d0, [x0, #7]
    // 0xbbf2a4: ldur            x0, [fp, #-0x18]
    // 0xbbf2a8: stur            d0, [fp, #-0x28]
    // 0xbbf2ac: LoadField: r1 = r0->field_b
    //     0xbbf2ac: ldur            w1, [x0, #0xb]
    // 0xbbf2b0: LoadField: r2 = r0->field_f
    //     0xbbf2b0: ldur            w2, [x0, #0xf]
    // 0xbbf2b4: DecompressPointer r2
    //     0xbbf2b4: add             x2, x2, HEAP, lsl #32
    // 0xbbf2b8: LoadField: r3 = r2->field_b
    //     0xbbf2b8: ldur            w3, [x2, #0xb]
    // 0xbbf2bc: r2 = LoadInt32Instr(r1)
    //     0xbbf2bc: sbfx            x2, x1, #1, #0x1f
    // 0xbbf2c0: stur            x2, [fp, #-0x20]
    // 0xbbf2c4: r1 = LoadInt32Instr(r3)
    //     0xbbf2c4: sbfx            x1, x3, #1, #0x1f
    // 0xbbf2c8: cmp             x2, x1
    // 0xbbf2cc: b.ne            #0xbbf2d8
    // 0xbbf2d0: mov             x1, x0
    // 0xbbf2d4: r0 = _growToNextCapacity()
    //     0xbbf2d4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xbbf2d8: ldur            x2, [fp, #-0x18]
    // 0xbbf2dc: ldur            d0, [fp, #-0x28]
    // 0xbbf2e0: ldur            x3, [fp, #-0x20]
    // 0xbbf2e4: add             x0, x3, #1
    // 0xbbf2e8: lsl             x1, x0, #1
    // 0xbbf2ec: StoreField: r2->field_b = r1
    //     0xbbf2ec: stur            w1, [x2, #0xb]
    // 0xbbf2f0: LoadField: r1 = r2->field_f
    //     0xbbf2f0: ldur            w1, [x2, #0xf]
    // 0xbbf2f4: DecompressPointer r1
    //     0xbbf2f4: add             x1, x1, HEAP, lsl #32
    // 0xbbf2f8: r0 = inline_Allocate_Double()
    //     0xbbf2f8: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0xbbf2fc: add             x0, x0, #0x10
    //     0xbbf300: cmp             x4, x0
    //     0xbbf304: b.ls            #0xbbf41c
    //     0xbbf308: str             x0, [THR, #0x60]  ; THR::top
    //     0xbbf30c: sub             x0, x0, #0xf
    //     0xbbf310: mov             x4, #0xe19c
    //     0xbbf314: movk            x4, #3, lsl #16
    //     0xbbf318: stur            x4, [x0, #-1]
    // 0xbbf31c: dmb             ishst
    // 0xbbf320: StoreField: r0->field_7 = d0
    //     0xbbf320: stur            d0, [x0, #7]
    // 0xbbf324: ArrayStore: r1[r3] = r0  ; List_4
    //     0xbbf324: add             x25, x1, x3, lsl #2
    //     0xbbf328: add             x25, x25, #0xf
    //     0xbbf32c: str             w0, [x25]
    //     0xbbf330: tbz             w0, #0, #0xbbf34c
    //     0xbbf334: ldurb           w16, [x1, #-1]
    //     0xbbf338: ldurb           w17, [x0, #-1]
    //     0xbbf33c: and             x16, x17, x16, lsr #2
    //     0xbbf340: tst             x16, HEAP, lsr #32
    //     0xbbf344: b.eq            #0xbbf34c
    //     0xbbf348: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbbf34c: ldur            x0, [fp, #-8]
    // 0xbbf350: LoadField: r3 = r0->field_73
    //     0xbbf350: ldur            w3, [x0, #0x73]
    // 0xbbf354: DecompressPointer r3
    //     0xbbf354: add             x3, x3, HEAP, lsl #32
    // 0xbbf358: stur            x3, [fp, #-0x10]
    // 0xbbf35c: cmp             w3, NULL
    // 0xbbf360: b.eq            #0xbbf43c
    // 0xbbf364: mov             x1, x0
    // 0xbbf368: r0 = size()
    //     0xbbf368: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbf36c: LoadField: d0 = r0->field_7
    //     0xbbf36c: ldur            d0, [x0, #7]
    // 0xbbf370: ldur            x0, [fp, #-8]
    // 0xbbf374: LoadField: r1 = r0->field_97
    //     0xbbf374: ldur            w1, [x0, #0x97]
    // 0xbbf378: DecompressPointer r1
    //     0xbbf378: add             x1, x1, HEAP, lsl #32
    // 0xbbf37c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xbbf37c: ldur            w0, [x1, #0x17]
    // 0xbbf380: DecompressPointer r0
    //     0xbbf380: add             x0, x0, HEAP, lsl #32
    // 0xbbf384: r5 = inline_Allocate_Double()
    //     0xbbf384: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0xbbf388: add             x5, x5, #0x10
    //     0xbbf38c: cmp             x1, x5
    //     0xbbf390: b.ls            #0xbbf440
    //     0xbbf394: str             x5, [THR, #0x60]  ; THR::top
    //     0xbbf398: sub             x5, x5, #0xf
    //     0xbbf39c: mov             x1, #0xe19c
    //     0xbbf3a0: movk            x1, #3, lsl #16
    //     0xbbf3a4: stur            x1, [x5, #-1]
    // 0xbbf3a8: dmb             ishst
    // 0xbbf3ac: StoreField: r5->field_7 = d0
    //     0xbbf3ac: stur            d0, [x5, #7]
    // 0xbbf3b0: mov             x1, x0
    // 0xbbf3b4: ldur            x2, [fp, #-0x18]
    // 0xbbf3b8: ldur            x3, [fp, #-0x10]
    // 0xbbf3bc: r0 = _saveTabOffsets()
    //     0xbbf3bc: bl              #0xbbf4a0  ; [package:flutter/src/material/tabs.dart] _TabBarState::_saveTabOffsets
    // 0xbbf3c0: r0 = Null
    //     0xbbf3c0: mov             x0, NULL
    // 0xbbf3c4: LeaveFrame
    //     0xbbf3c4: mov             SP, fp
    //     0xbbf3c8: ldp             fp, lr, [SP], #0x10
    // 0xbbf3cc: ret
    //     0xbbf3cc: ret             
    // 0xbbf3d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbf3d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbf3d4: b               #0xbbf0d4
    // 0xbbf3d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbf3d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbf3dc: b               #0xbbf110
    // 0xbbf3e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbf3e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbf3e4: SaveReg d0
    //     0xbbf3e4: str             q0, [SP, #-0x10]!
    // 0xbbf3e8: stp             x3, x4, [SP, #-0x10]!
    // 0xbbf3ec: stp             x1, x2, [SP, #-0x10]!
    // 0xbbf3f0: r0 = AllocateDouble()
    //     0xbbf3f0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbbf3f4: ldp             x1, x2, [SP], #0x10
    // 0xbbf3f8: ldp             x3, x4, [SP], #0x10
    // 0xbbf3fc: RestoreReg d0
    //     0xbbf3fc: ldr             q0, [SP], #0x10
    // 0xbbf400: b               #0xbbf1f0
    // 0xbbf404: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbf404: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbf408: SaveReg d0
    //     0xbbf408: str             q0, [SP, #-0x10]!
    // 0xbbf40c: r0 = AllocateDouble()
    //     0xbbf40c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbbf410: mov             x3, x0
    // 0xbbf414: RestoreReg d0
    //     0xbbf414: ldr             q0, [SP], #0x10
    // 0xbbf418: b               #0xbbf27c
    // 0xbbf41c: SaveReg d0
    //     0xbbf41c: str             q0, [SP, #-0x10]!
    // 0xbbf420: stp             x2, x3, [SP, #-0x10]!
    // 0xbbf424: SaveReg r1
    //     0xbbf424: str             x1, [SP, #-8]!
    // 0xbbf428: r0 = AllocateDouble()
    //     0xbbf428: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbbf42c: RestoreReg r1
    //     0xbbf42c: ldr             x1, [SP], #8
    // 0xbbf430: ldp             x2, x3, [SP], #0x10
    // 0xbbf434: RestoreReg d0
    //     0xbbf434: ldr             q0, [SP], #0x10
    // 0xbbf438: b               #0xbbf320
    // 0xbbf43c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbf43c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbf440: SaveReg d0
    //     0xbbf440: str             q0, [SP, #-0x10]!
    // 0xbbf444: SaveReg r0
    //     0xbbf444: str             x0, [SP, #-8]!
    // 0xbbf448: r0 = AllocateDouble()
    //     0xbbf448: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbbf44c: mov             x5, x0
    // 0xbbf450: RestoreReg r0
    //     0xbbf450: ldr             x0, [SP], #8
    // 0xbbf454: RestoreReg d0
    //     0xbbf454: ldr             q0, [SP], #0x10
    // 0xbbf458: b               #0xbbf3ac
  }
}

// class id: 5059, size: 0x5c, field offset: 0x4c
class _TabsSecondaryDefaultsM3 extends TabBarThemeData {

  late final ColorScheme _colors; // offset: 0x50
  late final TextTheme _textTheme; // offset: 0x54

  [closure] Color? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xe005e0, size: 0x2ec
    // 0xe005e0: EnterFrame
    //     0xe005e0: stp             fp, lr, [SP, #-0x10]!
    //     0xe005e4: mov             fp, SP
    // 0xe005e8: AllocStack(0x8)
    //     0xe005e8: sub             SP, SP, #8
    // 0xe005ec: SetupParameters([dynamic _ /* r0 */])
    //     0xe005ec: ldr             x0, [fp, #0x18]
    //     0xe005f0: ldur            w3, [x0, #0x17]
    //     0xe005f4: add             x3, x3, HEAP, lsl #32
    //     0xe005f8: stur            x3, [fp, #-8]
    // 0xe005fc: CheckStackOverflow
    //     0xe005fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe00600: cmp             SP, x16
    //     0xe00604: b.ls            #0xe008c4
    // 0xe00608: ldr             x4, [fp, #0x10]
    // 0xe0060c: r0 = LoadClassIdInstr(r4)
    //     0xe0060c: ldur            x0, [x4, #-1]
    //     0xe00610: ubfx            x0, x0, #0xc, #0x14
    // 0xe00614: mov             x1, x4
    // 0xe00618: r2 = Instance_WidgetState
    //     0xe00618: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xe0061c: ldr             x2, [x2, #0x100]
    // 0xe00620: r0 = GDT[cid_x0 + 0x12929]()
    //     0xe00620: mov             x17, #0x2929
    //     0xe00624: movk            x17, #1, lsl #16
    //     0xe00628: add             lr, x0, x17
    //     0xe0062c: ldr             lr, [x21, lr, lsl #3]
    //     0xe00630: blr             lr
    // 0xe00634: tbnz            w0, #4, #0xe006d8
    // 0xe00638: ldr             x3, [fp, #0x10]
    // 0xe0063c: r0 = LoadClassIdInstr(r3)
    //     0xe0063c: ldur            x0, [x3, #-1]
    //     0xe00640: ubfx            x0, x0, #0xc, #0x14
    // 0xe00644: mov             x1, x3
    // 0xe00648: r2 = Instance_WidgetState
    //     0xe00648: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xe0064c: ldr             x2, [x2, #0xa48]
    // 0xe00650: r0 = GDT[cid_x0 + 0x12929]()
    //     0xe00650: mov             x17, #0x2929
    //     0xe00654: movk            x17, #1, lsl #16
    //     0xe00658: add             lr, x0, x17
    //     0xe0065c: ldr             lr, [x21, lr, lsl #3]
    //     0xe00660: blr             lr
    // 0xe00664: tbz             w0, #4, #0xe00774
    // 0xe00668: ldr             x3, [fp, #0x10]
    // 0xe0066c: r0 = LoadClassIdInstr(r3)
    //     0xe0066c: ldur            x0, [x3, #-1]
    //     0xe00670: ubfx            x0, x0, #0xc, #0x14
    // 0xe00674: mov             x1, x3
    // 0xe00678: r2 = Instance_WidgetState
    //     0xe00678: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xe0067c: ldr             x2, [x2, #0xa50]
    // 0xe00680: r0 = GDT[cid_x0 + 0x12929]()
    //     0xe00680: mov             x17, #0x2929
    //     0xe00684: movk            x17, #1, lsl #16
    //     0xe00688: add             lr, x0, x17
    //     0xe0068c: ldr             lr, [x21, lr, lsl #3]
    //     0xe00690: blr             lr
    // 0xe00694: tbz             w0, #4, #0xe007ac
    // 0xe00698: ldr             x3, [fp, #0x10]
    // 0xe0069c: r0 = LoadClassIdInstr(r3)
    //     0xe0069c: ldur            x0, [x3, #-1]
    //     0xe006a0: ubfx            x0, x0, #0xc, #0x14
    // 0xe006a4: mov             x1, x3
    // 0xe006a8: r2 = Instance_WidgetState
    //     0xe006a8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xe006ac: ldr             x2, [x2, #0xa60]
    // 0xe006b0: r0 = GDT[cid_x0 + 0x12929]()
    //     0xe006b0: mov             x17, #0x2929
    //     0xe006b4: movk            x17, #1, lsl #16
    //     0xe006b8: add             lr, x0, x17
    //     0xe006bc: ldr             lr, [x21, lr, lsl #3]
    //     0xe006c0: blr             lr
    // 0xe006c4: tbz             w0, #4, #0xe007e4
    // 0xe006c8: r0 = Null
    //     0xe006c8: mov             x0, NULL
    // 0xe006cc: LeaveFrame
    //     0xe006cc: mov             SP, fp
    //     0xe006d0: ldp             fp, lr, [SP], #0x10
    // 0xe006d4: ret
    //     0xe006d4: ret             
    // 0xe006d8: ldr             x3, [fp, #0x10]
    // 0xe006dc: r0 = LoadClassIdInstr(r3)
    //     0xe006dc: ldur            x0, [x3, #-1]
    //     0xe006e0: ubfx            x0, x0, #0xc, #0x14
    // 0xe006e4: mov             x1, x3
    // 0xe006e8: r2 = Instance_WidgetState
    //     0xe006e8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xe006ec: ldr             x2, [x2, #0xa48]
    // 0xe006f0: r0 = GDT[cid_x0 + 0x12929]()
    //     0xe006f0: mov             x17, #0x2929
    //     0xe006f4: movk            x17, #1, lsl #16
    //     0xe006f8: add             lr, x0, x17
    //     0xe006fc: ldr             lr, [x21, lr, lsl #3]
    //     0xe00700: blr             lr
    // 0xe00704: tbz             w0, #4, #0xe0081c
    // 0xe00708: ldr             x3, [fp, #0x10]
    // 0xe0070c: r0 = LoadClassIdInstr(r3)
    //     0xe0070c: ldur            x0, [x3, #-1]
    //     0xe00710: ubfx            x0, x0, #0xc, #0x14
    // 0xe00714: mov             x1, x3
    // 0xe00718: r2 = Instance_WidgetState
    //     0xe00718: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xe0071c: ldr             x2, [x2, #0xa50]
    // 0xe00720: r0 = GDT[cid_x0 + 0x12929]()
    //     0xe00720: mov             x17, #0x2929
    //     0xe00724: movk            x17, #1, lsl #16
    //     0xe00728: add             lr, x0, x17
    //     0xe0072c: ldr             lr, [x21, lr, lsl #3]
    //     0xe00730: blr             lr
    // 0xe00734: tbz             w0, #4, #0xe00854
    // 0xe00738: ldr             x1, [fp, #0x10]
    // 0xe0073c: r0 = LoadClassIdInstr(r1)
    //     0xe0073c: ldur            x0, [x1, #-1]
    //     0xe00740: ubfx            x0, x0, #0xc, #0x14
    // 0xe00744: r2 = Instance_WidgetState
    //     0xe00744: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xe00748: ldr             x2, [x2, #0xa60]
    // 0xe0074c: r0 = GDT[cid_x0 + 0x12929]()
    //     0xe0074c: mov             x17, #0x2929
    //     0xe00750: movk            x17, #1, lsl #16
    //     0xe00754: add             lr, x0, x17
    //     0xe00758: ldr             lr, [x21, lr, lsl #3]
    //     0xe0075c: blr             lr
    // 0xe00760: tbz             w0, #4, #0xe0088c
    // 0xe00764: r0 = Null
    //     0xe00764: mov             x0, NULL
    // 0xe00768: LeaveFrame
    //     0xe00768: mov             SP, fp
    //     0xe0076c: ldp             fp, lr, [SP], #0x10
    // 0xe00770: ret
    //     0xe00770: ret             
    // 0xe00774: ldur            x0, [fp, #-8]
    // 0xe00778: LoadField: r1 = r0->field_f
    //     0xe00778: ldur            w1, [x0, #0xf]
    // 0xe0077c: DecompressPointer r1
    //     0xe0077c: add             x1, x1, HEAP, lsl #32
    // 0xe00780: LoadField: r0 = r1->field_4f
    //     0xe00780: ldur            w0, [x1, #0x4f]
    // 0xe00784: DecompressPointer r0
    //     0xe00784: add             x0, x0, HEAP, lsl #32
    // 0xe00788: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe0078c: cmp             w0, w16
    // 0xe00790: b.ne            #0xe007a0
    // 0xe00794: r2 = _colors
    //     0xe00794: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0xe00798: ldr             x2, [x2, #0xf0]
    // 0xe0079c: r0 = InitLateFinalInstanceField()
    //     0xe0079c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xe007a0: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xe007a0: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xe007a4: r0 = Throw()
    //     0xe007a4: bl              #0x13ddb2c  ; ThrowStub
    // 0xe007a8: brk             #0
    // 0xe007ac: ldur            x0, [fp, #-8]
    // 0xe007b0: LoadField: r1 = r0->field_f
    //     0xe007b0: ldur            w1, [x0, #0xf]
    // 0xe007b4: DecompressPointer r1
    //     0xe007b4: add             x1, x1, HEAP, lsl #32
    // 0xe007b8: LoadField: r0 = r1->field_4f
    //     0xe007b8: ldur            w0, [x1, #0x4f]
    // 0xe007bc: DecompressPointer r0
    //     0xe007bc: add             x0, x0, HEAP, lsl #32
    // 0xe007c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe007c4: cmp             w0, w16
    // 0xe007c8: b.ne            #0xe007d8
    // 0xe007cc: r2 = _colors
    //     0xe007cc: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0xe007d0: ldr             x2, [x2, #0xf0]
    // 0xe007d4: r0 = InitLateFinalInstanceField()
    //     0xe007d4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xe007d8: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xe007d8: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xe007dc: r0 = Throw()
    //     0xe007dc: bl              #0x13ddb2c  ; ThrowStub
    // 0xe007e0: brk             #0
    // 0xe007e4: ldur            x0, [fp, #-8]
    // 0xe007e8: LoadField: r1 = r0->field_f
    //     0xe007e8: ldur            w1, [x0, #0xf]
    // 0xe007ec: DecompressPointer r1
    //     0xe007ec: add             x1, x1, HEAP, lsl #32
    // 0xe007f0: LoadField: r0 = r1->field_4f
    //     0xe007f0: ldur            w0, [x1, #0x4f]
    // 0xe007f4: DecompressPointer r0
    //     0xe007f4: add             x0, x0, HEAP, lsl #32
    // 0xe007f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe007fc: cmp             w0, w16
    // 0xe00800: b.ne            #0xe00810
    // 0xe00804: r2 = _colors
    //     0xe00804: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0xe00808: ldr             x2, [x2, #0xf0]
    // 0xe0080c: r0 = InitLateFinalInstanceField()
    //     0xe0080c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xe00810: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xe00810: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xe00814: r0 = Throw()
    //     0xe00814: bl              #0x13ddb2c  ; ThrowStub
    // 0xe00818: brk             #0
    // 0xe0081c: ldur            x0, [fp, #-8]
    // 0xe00820: LoadField: r1 = r0->field_f
    //     0xe00820: ldur            w1, [x0, #0xf]
    // 0xe00824: DecompressPointer r1
    //     0xe00824: add             x1, x1, HEAP, lsl #32
    // 0xe00828: LoadField: r0 = r1->field_4f
    //     0xe00828: ldur            w0, [x1, #0x4f]
    // 0xe0082c: DecompressPointer r0
    //     0xe0082c: add             x0, x0, HEAP, lsl #32
    // 0xe00830: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe00834: cmp             w0, w16
    // 0xe00838: b.ne            #0xe00848
    // 0xe0083c: r2 = _colors
    //     0xe0083c: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0xe00840: ldr             x2, [x2, #0xf0]
    // 0xe00844: r0 = InitLateFinalInstanceField()
    //     0xe00844: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xe00848: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xe00848: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xe0084c: r0 = Throw()
    //     0xe0084c: bl              #0x13ddb2c  ; ThrowStub
    // 0xe00850: brk             #0
    // 0xe00854: ldur            x0, [fp, #-8]
    // 0xe00858: LoadField: r1 = r0->field_f
    //     0xe00858: ldur            w1, [x0, #0xf]
    // 0xe0085c: DecompressPointer r1
    //     0xe0085c: add             x1, x1, HEAP, lsl #32
    // 0xe00860: LoadField: r0 = r1->field_4f
    //     0xe00860: ldur            w0, [x1, #0x4f]
    // 0xe00864: DecompressPointer r0
    //     0xe00864: add             x0, x0, HEAP, lsl #32
    // 0xe00868: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe0086c: cmp             w0, w16
    // 0xe00870: b.ne            #0xe00880
    // 0xe00874: r2 = _colors
    //     0xe00874: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0xe00878: ldr             x2, [x2, #0xf0]
    // 0xe0087c: r0 = InitLateFinalInstanceField()
    //     0xe0087c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xe00880: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xe00880: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xe00884: r0 = Throw()
    //     0xe00884: bl              #0x13ddb2c  ; ThrowStub
    // 0xe00888: brk             #0
    // 0xe0088c: ldur            x0, [fp, #-8]
    // 0xe00890: LoadField: r1 = r0->field_f
    //     0xe00890: ldur            w1, [x0, #0xf]
    // 0xe00894: DecompressPointer r1
    //     0xe00894: add             x1, x1, HEAP, lsl #32
    // 0xe00898: LoadField: r0 = r1->field_4f
    //     0xe00898: ldur            w0, [x1, #0x4f]
    // 0xe0089c: DecompressPointer r0
    //     0xe0089c: add             x0, x0, HEAP, lsl #32
    // 0xe008a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe008a4: cmp             w0, w16
    // 0xe008a8: b.ne            #0xe008b8
    // 0xe008ac: r2 = _colors
    //     0xe008ac: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0xe008b0: ldr             x2, [x2, #0xf0]
    // 0xe008b4: r0 = InitLateFinalInstanceField()
    //     0xe008b4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xe008b8: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xe008b8: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xe008bc: r0 = Throw()
    //     0xe008bc: bl              #0x13ddb2c  ; ThrowStub
    // 0xe008c0: brk             #0
    // 0xe008c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe008c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe008c8: b               #0xe00608
  }
}

// class id: 5060, size: 0x5c, field offset: 0x4c
class _TabsPrimaryDefaultsM3 extends TabBarThemeData {

  late final ColorScheme _colors; // offset: 0x50
  late final TextTheme _textTheme; // offset: 0x54

  [closure] Color? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xe00204, size: 0x398
    // 0xe00204: EnterFrame
    //     0xe00204: stp             fp, lr, [SP, #-0x10]!
    //     0xe00208: mov             fp, SP
    // 0xe0020c: AllocStack(0x8)
    //     0xe0020c: sub             SP, SP, #8
    // 0xe00210: SetupParameters([dynamic _ /* r0 */])
    //     0xe00210: ldr             x0, [fp, #0x18]
    //     0xe00214: ldur            w3, [x0, #0x17]
    //     0xe00218: add             x3, x3, HEAP, lsl #32
    //     0xe0021c: stur            x3, [fp, #-8]
    // 0xe00220: CheckStackOverflow
    //     0xe00220: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe00224: cmp             SP, x16
    //     0xe00228: b.ls            #0xe00594
    // 0xe0022c: ldr             x4, [fp, #0x10]
    // 0xe00230: r0 = LoadClassIdInstr(r4)
    //     0xe00230: ldur            x0, [x4, #-1]
    //     0xe00234: ubfx            x0, x0, #0xc, #0x14
    // 0xe00238: mov             x1, x4
    // 0xe0023c: r2 = Instance_WidgetState
    //     0xe0023c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xe00240: ldr             x2, [x2, #0x100]
    // 0xe00244: r0 = GDT[cid_x0 + 0x12929]()
    //     0xe00244: mov             x17, #0x2929
    //     0xe00248: movk            x17, #1, lsl #16
    //     0xe0024c: add             lr, x0, x17
    //     0xe00250: ldr             lr, [x21, lr, lsl #3]
    //     0xe00254: blr             lr
    // 0xe00258: tbnz            w0, #4, #0xe003e8
    // 0xe0025c: ldr             x3, [fp, #0x10]
    // 0xe00260: r0 = LoadClassIdInstr(r3)
    //     0xe00260: ldur            x0, [x3, #-1]
    //     0xe00264: ubfx            x0, x0, #0xc, #0x14
    // 0xe00268: mov             x1, x3
    // 0xe0026c: r2 = Instance_WidgetState
    //     0xe0026c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xe00270: ldr             x2, [x2, #0xa48]
    // 0xe00274: r0 = GDT[cid_x0 + 0x12929]()
    //     0xe00274: mov             x17, #0x2929
    //     0xe00278: movk            x17, #1, lsl #16
    //     0xe0027c: add             lr, x0, x17
    //     0xe00280: ldr             lr, [x21, lr, lsl #3]
    //     0xe00284: blr             lr
    // 0xe00288: tbnz            w0, #4, #0xe002d8
    // 0xe0028c: ldur            x3, [fp, #-8]
    // 0xe00290: LoadField: r1 = r3->field_f
    //     0xe00290: ldur            w1, [x3, #0xf]
    // 0xe00294: DecompressPointer r1
    //     0xe00294: add             x1, x1, HEAP, lsl #32
    // 0xe00298: LoadField: r0 = r1->field_4f
    //     0xe00298: ldur            w0, [x1, #0x4f]
    // 0xe0029c: DecompressPointer r0
    //     0xe0029c: add             x0, x0, HEAP, lsl #32
    // 0xe002a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe002a4: cmp             w0, w16
    // 0xe002a8: b.ne            #0xe002b8
    // 0xe002ac: r2 = _colors
    //     0xe002ac: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0xe002b0: ldr             x2, [x2, #0xb0]
    // 0xe002b4: r0 = InitLateFinalInstanceField()
    //     0xe002b4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xe002b8: LoadField: r1 = r0->field_b
    //     0xe002b8: ldur            w1, [x0, #0xb]
    // 0xe002bc: DecompressPointer r1
    //     0xe002bc: add             x1, x1, HEAP, lsl #32
    // 0xe002c0: d0 = 0.100000
    //     0xe002c0: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xe002c4: ldr             d0, [x17, #0x1e0]
    // 0xe002c8: r0 = withOpacity()
    //     0xe002c8: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xe002cc: LeaveFrame
    //     0xe002cc: mov             SP, fp
    //     0xe002d0: ldp             fp, lr, [SP], #0x10
    // 0xe002d4: ret
    //     0xe002d4: ret             
    // 0xe002d8: ldr             x4, [fp, #0x10]
    // 0xe002dc: ldur            x3, [fp, #-8]
    // 0xe002e0: r0 = LoadClassIdInstr(r4)
    //     0xe002e0: ldur            x0, [x4, #-1]
    //     0xe002e4: ubfx            x0, x0, #0xc, #0x14
    // 0xe002e8: mov             x1, x4
    // 0xe002ec: r2 = Instance_WidgetState
    //     0xe002ec: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xe002f0: ldr             x2, [x2, #0xa50]
    // 0xe002f4: r0 = GDT[cid_x0 + 0x12929]()
    //     0xe002f4: mov             x17, #0x2929
    //     0xe002f8: movk            x17, #1, lsl #16
    //     0xe002fc: add             lr, x0, x17
    //     0xe00300: ldr             lr, [x21, lr, lsl #3]
    //     0xe00304: blr             lr
    // 0xe00308: tbnz            w0, #4, #0xe00358
    // 0xe0030c: ldur            x3, [fp, #-8]
    // 0xe00310: LoadField: r1 = r3->field_f
    //     0xe00310: ldur            w1, [x3, #0xf]
    // 0xe00314: DecompressPointer r1
    //     0xe00314: add             x1, x1, HEAP, lsl #32
    // 0xe00318: LoadField: r0 = r1->field_4f
    //     0xe00318: ldur            w0, [x1, #0x4f]
    // 0xe0031c: DecompressPointer r0
    //     0xe0031c: add             x0, x0, HEAP, lsl #32
    // 0xe00320: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe00324: cmp             w0, w16
    // 0xe00328: b.ne            #0xe00338
    // 0xe0032c: r2 = _colors
    //     0xe0032c: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0xe00330: ldr             x2, [x2, #0xb0]
    // 0xe00334: r0 = InitLateFinalInstanceField()
    //     0xe00334: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xe00338: LoadField: r1 = r0->field_b
    //     0xe00338: ldur            w1, [x0, #0xb]
    // 0xe0033c: DecompressPointer r1
    //     0xe0033c: add             x1, x1, HEAP, lsl #32
    // 0xe00340: d0 = 0.080000
    //     0xe00340: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xe00344: ldr             d0, [x17, #0xa58]
    // 0xe00348: r0 = withOpacity()
    //     0xe00348: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xe0034c: LeaveFrame
    //     0xe0034c: mov             SP, fp
    //     0xe00350: ldp             fp, lr, [SP], #0x10
    // 0xe00354: ret
    //     0xe00354: ret             
    // 0xe00358: ldr             x4, [fp, #0x10]
    // 0xe0035c: ldur            x3, [fp, #-8]
    // 0xe00360: r0 = LoadClassIdInstr(r4)
    //     0xe00360: ldur            x0, [x4, #-1]
    //     0xe00364: ubfx            x0, x0, #0xc, #0x14
    // 0xe00368: mov             x1, x4
    // 0xe0036c: r2 = Instance_WidgetState
    //     0xe0036c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xe00370: ldr             x2, [x2, #0xa60]
    // 0xe00374: r0 = GDT[cid_x0 + 0x12929]()
    //     0xe00374: mov             x17, #0x2929
    //     0xe00378: movk            x17, #1, lsl #16
    //     0xe0037c: add             lr, x0, x17
    //     0xe00380: ldr             lr, [x21, lr, lsl #3]
    //     0xe00384: blr             lr
    // 0xe00388: tbnz            w0, #4, #0xe003d8
    // 0xe0038c: ldur            x3, [fp, #-8]
    // 0xe00390: LoadField: r1 = r3->field_f
    //     0xe00390: ldur            w1, [x3, #0xf]
    // 0xe00394: DecompressPointer r1
    //     0xe00394: add             x1, x1, HEAP, lsl #32
    // 0xe00398: LoadField: r0 = r1->field_4f
    //     0xe00398: ldur            w0, [x1, #0x4f]
    // 0xe0039c: DecompressPointer r0
    //     0xe0039c: add             x0, x0, HEAP, lsl #32
    // 0xe003a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe003a4: cmp             w0, w16
    // 0xe003a8: b.ne            #0xe003b8
    // 0xe003ac: r2 = _colors
    //     0xe003ac: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0xe003b0: ldr             x2, [x2, #0xb0]
    // 0xe003b4: r0 = InitLateFinalInstanceField()
    //     0xe003b4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xe003b8: LoadField: r1 = r0->field_b
    //     0xe003b8: ldur            w1, [x0, #0xb]
    // 0xe003bc: DecompressPointer r1
    //     0xe003bc: add             x1, x1, HEAP, lsl #32
    // 0xe003c0: d0 = 0.100000
    //     0xe003c0: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xe003c4: ldr             d0, [x17, #0x1e0]
    // 0xe003c8: r0 = withOpacity()
    //     0xe003c8: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xe003cc: LeaveFrame
    //     0xe003cc: mov             SP, fp
    //     0xe003d0: ldp             fp, lr, [SP], #0x10
    // 0xe003d4: ret
    //     0xe003d4: ret             
    // 0xe003d8: r0 = Null
    //     0xe003d8: mov             x0, NULL
    // 0xe003dc: LeaveFrame
    //     0xe003dc: mov             SP, fp
    //     0xe003e0: ldp             fp, lr, [SP], #0x10
    // 0xe003e4: ret
    //     0xe003e4: ret             
    // 0xe003e8: ldr             x4, [fp, #0x10]
    // 0xe003ec: ldur            x3, [fp, #-8]
    // 0xe003f0: r0 = LoadClassIdInstr(r4)
    //     0xe003f0: ldur            x0, [x4, #-1]
    //     0xe003f4: ubfx            x0, x0, #0xc, #0x14
    // 0xe003f8: mov             x1, x4
    // 0xe003fc: r2 = Instance_WidgetState
    //     0xe003fc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xe00400: ldr             x2, [x2, #0xa48]
    // 0xe00404: r0 = GDT[cid_x0 + 0x12929]()
    //     0xe00404: mov             x17, #0x2929
    //     0xe00408: movk            x17, #1, lsl #16
    //     0xe0040c: add             lr, x0, x17
    //     0xe00410: ldr             lr, [x21, lr, lsl #3]
    //     0xe00414: blr             lr
    // 0xe00418: tbnz            w0, #4, #0xe00468
    // 0xe0041c: ldur            x3, [fp, #-8]
    // 0xe00420: LoadField: r1 = r3->field_f
    //     0xe00420: ldur            w1, [x3, #0xf]
    // 0xe00424: DecompressPointer r1
    //     0xe00424: add             x1, x1, HEAP, lsl #32
    // 0xe00428: LoadField: r0 = r1->field_4f
    //     0xe00428: ldur            w0, [x1, #0x4f]
    // 0xe0042c: DecompressPointer r0
    //     0xe0042c: add             x0, x0, HEAP, lsl #32
    // 0xe00430: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe00434: cmp             w0, w16
    // 0xe00438: b.ne            #0xe00448
    // 0xe0043c: r2 = _colors
    //     0xe0043c: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0xe00440: ldr             x2, [x2, #0xb0]
    // 0xe00444: r0 = InitLateFinalInstanceField()
    //     0xe00444: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xe00448: LoadField: r1 = r0->field_b
    //     0xe00448: ldur            w1, [x0, #0xb]
    // 0xe0044c: DecompressPointer r1
    //     0xe0044c: add             x1, x1, HEAP, lsl #32
    // 0xe00450: d0 = 0.100000
    //     0xe00450: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xe00454: ldr             d0, [x17, #0x1e0]
    // 0xe00458: r0 = withOpacity()
    //     0xe00458: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xe0045c: LeaveFrame
    //     0xe0045c: mov             SP, fp
    //     0xe00460: ldp             fp, lr, [SP], #0x10
    // 0xe00464: ret
    //     0xe00464: ret             
    // 0xe00468: ldr             x4, [fp, #0x10]
    // 0xe0046c: ldur            x3, [fp, #-8]
    // 0xe00470: r0 = LoadClassIdInstr(r4)
    //     0xe00470: ldur            x0, [x4, #-1]
    //     0xe00474: ubfx            x0, x0, #0xc, #0x14
    // 0xe00478: mov             x1, x4
    // 0xe0047c: r2 = Instance_WidgetState
    //     0xe0047c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xe00480: ldr             x2, [x2, #0xa50]
    // 0xe00484: r0 = GDT[cid_x0 + 0x12929]()
    //     0xe00484: mov             x17, #0x2929
    //     0xe00488: movk            x17, #1, lsl #16
    //     0xe0048c: add             lr, x0, x17
    //     0xe00490: ldr             lr, [x21, lr, lsl #3]
    //     0xe00494: blr             lr
    // 0xe00498: tbnz            w0, #4, #0xe004f8
    // 0xe0049c: ldur            x3, [fp, #-8]
    // 0xe004a0: LoadField: r1 = r3->field_f
    //     0xe004a0: ldur            w1, [x3, #0xf]
    // 0xe004a4: DecompressPointer r1
    //     0xe004a4: add             x1, x1, HEAP, lsl #32
    // 0xe004a8: LoadField: r0 = r1->field_4f
    //     0xe004a8: ldur            w0, [x1, #0x4f]
    // 0xe004ac: DecompressPointer r0
    //     0xe004ac: add             x0, x0, HEAP, lsl #32
    // 0xe004b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe004b4: cmp             w0, w16
    // 0xe004b8: b.ne            #0xe004c8
    // 0xe004bc: r2 = _colors
    //     0xe004bc: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0xe004c0: ldr             x2, [x2, #0xb0]
    // 0xe004c4: r0 = InitLateFinalInstanceField()
    //     0xe004c4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xe004c8: LoadField: r1 = r0->field_7f
    //     0xe004c8: ldur            w1, [x0, #0x7f]
    // 0xe004cc: DecompressPointer r1
    //     0xe004cc: add             x1, x1, HEAP, lsl #32
    // 0xe004d0: r0 = LoadClassIdInstr(r1)
    //     0xe004d0: ldur            x0, [x1, #-1]
    //     0xe004d4: ubfx            x0, x0, #0xc, #0x14
    // 0xe004d8: d0 = 0.080000
    //     0xe004d8: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xe004dc: ldr             d0, [x17, #0xa58]
    // 0xe004e0: r0 = GDT[cid_x0 + -0x1000]()
    //     0xe004e0: sub             lr, x0, #1, lsl #12
    //     0xe004e4: ldr             lr, [x21, lr, lsl #3]
    //     0xe004e8: blr             lr
    // 0xe004ec: LeaveFrame
    //     0xe004ec: mov             SP, fp
    //     0xe004f0: ldp             fp, lr, [SP], #0x10
    // 0xe004f4: ret
    //     0xe004f4: ret             
    // 0xe004f8: ldr             x1, [fp, #0x10]
    // 0xe004fc: ldur            x3, [fp, #-8]
    // 0xe00500: r0 = LoadClassIdInstr(r1)
    //     0xe00500: ldur            x0, [x1, #-1]
    //     0xe00504: ubfx            x0, x0, #0xc, #0x14
    // 0xe00508: r2 = Instance_WidgetState
    //     0xe00508: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xe0050c: ldr             x2, [x2, #0xa60]
    // 0xe00510: r0 = GDT[cid_x0 + 0x12929]()
    //     0xe00510: mov             x17, #0x2929
    //     0xe00514: movk            x17, #1, lsl #16
    //     0xe00518: add             lr, x0, x17
    //     0xe0051c: ldr             lr, [x21, lr, lsl #3]
    //     0xe00520: blr             lr
    // 0xe00524: tbnz            w0, #4, #0xe00584
    // 0xe00528: ldur            x0, [fp, #-8]
    // 0xe0052c: LoadField: r1 = r0->field_f
    //     0xe0052c: ldur            w1, [x0, #0xf]
    // 0xe00530: DecompressPointer r1
    //     0xe00530: add             x1, x1, HEAP, lsl #32
    // 0xe00534: LoadField: r0 = r1->field_4f
    //     0xe00534: ldur            w0, [x1, #0x4f]
    // 0xe00538: DecompressPointer r0
    //     0xe00538: add             x0, x0, HEAP, lsl #32
    // 0xe0053c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe00540: cmp             w0, w16
    // 0xe00544: b.ne            #0xe00554
    // 0xe00548: r2 = _colors
    //     0xe00548: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0xe0054c: ldr             x2, [x2, #0xb0]
    // 0xe00550: r0 = InitLateFinalInstanceField()
    //     0xe00550: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xe00554: LoadField: r1 = r0->field_7f
    //     0xe00554: ldur            w1, [x0, #0x7f]
    // 0xe00558: DecompressPointer r1
    //     0xe00558: add             x1, x1, HEAP, lsl #32
    // 0xe0055c: r0 = LoadClassIdInstr(r1)
    //     0xe0055c: ldur            x0, [x1, #-1]
    //     0xe00560: ubfx            x0, x0, #0xc, #0x14
    // 0xe00564: d0 = 0.100000
    //     0xe00564: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xe00568: ldr             d0, [x17, #0x1e0]
    // 0xe0056c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xe0056c: sub             lr, x0, #1, lsl #12
    //     0xe00570: ldr             lr, [x21, lr, lsl #3]
    //     0xe00574: blr             lr
    // 0xe00578: LeaveFrame
    //     0xe00578: mov             SP, fp
    //     0xe0057c: ldp             fp, lr, [SP], #0x10
    // 0xe00580: ret
    //     0xe00580: ret             
    // 0xe00584: r0 = Null
    //     0xe00584: mov             x0, NULL
    // 0xe00588: LeaveFrame
    //     0xe00588: mov             SP, fp
    //     0xe0058c: ldp             fp, lr, [SP], #0x10
    // 0xe00590: ret
    //     0xe00590: ret             
    // 0xe00594: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe00594: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe00598: b               #0xe0022c
  }
  ColorScheme _colors(_TabsPrimaryDefaultsM3) {
    // ** addr: 0xe0059c, size: 0x44
    // 0xe0059c: EnterFrame
    //     0xe0059c: stp             fp, lr, [SP, #-0x10]!
    //     0xe005a0: mov             fp, SP
    // 0xe005a4: CheckStackOverflow
    //     0xe005a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe005a8: cmp             SP, x16
    //     0xe005ac: b.ls            #0xe005d8
    // 0xe005b0: ldr             x0, [fp, #0x10]
    // 0xe005b4: LoadField: r1 = r0->field_4b
    //     0xe005b4: ldur            w1, [x0, #0x4b]
    // 0xe005b8: DecompressPointer r1
    //     0xe005b8: add             x1, x1, HEAP, lsl #32
    // 0xe005bc: r0 = of()
    //     0xe005bc: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xe005c0: LoadField: r1 = r0->field_3f
    //     0xe005c0: ldur            w1, [x0, #0x3f]
    // 0xe005c4: DecompressPointer r1
    //     0xe005c4: add             x1, x1, HEAP, lsl #32
    // 0xe005c8: mov             x0, x1
    // 0xe005cc: LeaveFrame
    //     0xe005cc: mov             SP, fp
    //     0xe005d0: ldp             fp, lr, [SP], #0x10
    // 0xe005d4: ret
    //     0xe005d4: ret             
    // 0xe005d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe005d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe005dc: b               #0xe005b0
  }
  TextTheme _textTheme(_TabsPrimaryDefaultsM3) {
    // ** addr: 0x10f9428, size: 0x44
    // 0x10f9428: EnterFrame
    //     0x10f9428: stp             fp, lr, [SP, #-0x10]!
    //     0x10f942c: mov             fp, SP
    // 0x10f9430: CheckStackOverflow
    //     0x10f9430: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f9434: cmp             SP, x16
    //     0x10f9438: b.ls            #0x10f9464
    // 0x10f943c: ldr             x0, [fp, #0x10]
    // 0x10f9440: LoadField: r1 = r0->field_4b
    //     0x10f9440: ldur            w1, [x0, #0x4b]
    // 0x10f9444: DecompressPointer r1
    //     0x10f9444: add             x1, x1, HEAP, lsl #32
    // 0x10f9448: r0 = of()
    //     0x10f9448: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x10f944c: LoadField: r1 = r0->field_87
    //     0x10f944c: ldur            w1, [x0, #0x87]
    // 0x10f9450: DecompressPointer r1
    //     0x10f9450: add             x1, x1, HEAP, lsl #32
    // 0x10f9454: mov             x0, x1
    // 0x10f9458: LeaveFrame
    //     0x10f9458: mov             SP, fp
    //     0x10f945c: ldp             fp, lr, [SP], #0x10
    // 0x10f9460: ret
    //     0x10f9460: ret             
    // 0x10f9464: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f9464: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f9468: b               #0x10f943c
  }
}

// class id: 5061, size: 0x60, field offset: 0x4c
class _TabsDefaultsM2 extends TabBarThemeData {

  late final ColorScheme _colors; // offset: 0x50
  late final Color primaryColor; // offset: 0x58
  late final bool isDark; // offset: 0x54

  Color primaryColor(_TabsDefaultsM2) {
    // ** addr: 0xef6738, size: 0x78
    // 0xef6738: EnterFrame
    //     0xef6738: stp             fp, lr, [SP, #-0x10]!
    //     0xef673c: mov             fp, SP
    // 0xef6740: CheckStackOverflow
    //     0xef6740: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef6744: cmp             SP, x16
    //     0xef6748: b.ls            #0xef67a4
    // 0xef674c: ldr             x1, [fp, #0x10]
    // 0xef6750: LoadField: r0 = r1->field_53
    //     0xef6750: ldur            w0, [x1, #0x53]
    // 0xef6754: DecompressPointer r0
    //     0xef6754: add             x0, x0, HEAP, lsl #32
    // 0xef6758: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef675c: cmp             w0, w16
    // 0xef6760: b.ne            #0xef6770
    // 0xef6764: r2 = isDark
    //     0xef6764: add             x2, PP, #0x26, lsl #12  ; [pp+0x26108] Field <_TabsDefaultsM2@780014024.isDark>: late final (offset: 0x54)
    //     0xef6768: ldr             x2, [x2, #0x108]
    // 0xef676c: r0 = InitLateFinalInstanceField()
    //     0xef676c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xef6770: tbnz            w0, #4, #0xef6790
    // 0xef6774: r1 = _ConstMap len:12
    //     0xef6774: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c20] Map<int, Color>(12)
    //     0xef6778: ldr             x1, [x1, #0xc20]
    // 0xef677c: r2 = 1800
    //     0xef677c: mov             x2, #0x708
    // 0xef6780: r0 = []()
    //     0xef6780: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0xef6784: cmp             w0, NULL
    // 0xef6788: b.eq            #0xef67ac
    // 0xef678c: b               #0xef6798
    // 0xef6790: r0 = Instance_MaterialColor
    //     0xef6790: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c28] Obj!MaterialColor@12a6e31
    //     0xef6794: ldr             x0, [x0, #0xc28]
    // 0xef6798: LeaveFrame
    //     0xef6798: mov             SP, fp
    //     0xef679c: ldp             fp, lr, [SP], #0x10
    // 0xef67a0: ret
    //     0xef67a0: ret             
    // 0xef67a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef67a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef67a8: b               #0xef674c
    // 0xef67ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef67ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  bool isDark(_TabsDefaultsM2) {
    // ** addr: 0xef67b0, size: 0x50
    // 0xef67b0: EnterFrame
    //     0xef67b0: stp             fp, lr, [SP, #-0x10]!
    //     0xef67b4: mov             fp, SP
    // 0xef67b8: CheckStackOverflow
    //     0xef67b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef67bc: cmp             SP, x16
    //     0xef67c0: b.ls            #0xef67f8
    // 0xef67c4: ldr             x0, [fp, #0x10]
    // 0xef67c8: LoadField: r1 = r0->field_4b
    //     0xef67c8: ldur            w1, [x0, #0x4b]
    // 0xef67cc: DecompressPointer r1
    //     0xef67cc: add             x1, x1, HEAP, lsl #32
    // 0xef67d0: r0 = brightnessOf()
    //     0xef67d0: bl              #0xd1e4dc  ; [package:flutter/src/material/theme.dart] Theme::brightnessOf
    // 0xef67d4: r16 = Instance_Brightness
    //     0xef67d4: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xef67d8: cmp             w0, w16
    // 0xef67dc: r16 = true
    //     0xef67dc: add             x16, NULL, #0x20  ; true
    // 0xef67e0: r17 = false
    //     0xef67e0: add             x17, NULL, #0x30  ; false
    // 0xef67e4: csel            x1, x16, x17, eq
    // 0xef67e8: mov             x0, x1
    // 0xef67ec: LeaveFrame
    //     0xef67ec: mov             SP, fp
    //     0xef67f0: ldp             fp, lr, [SP], #0x10
    // 0xef67f4: ret
    //     0xef67f4: ret             
    // 0xef67f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef67f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef67fc: b               #0xef67c4
  }
}

// class id: 5453, size: 0x34, field offset: 0x14
class _TabBarViewState extends State<dynamic> {

  late List<Widget> _childrenWithKey; // offset: 0x1c

  _ build(/* No info */) {
    // ** addr: 0xe00dcc, size: 0x10c
    // 0xe00dcc: EnterFrame
    //     0xe00dcc: stp             fp, lr, [SP, #-0x10]!
    //     0xe00dd0: mov             fp, SP
    // 0xe00dd4: AllocStack(0x30)
    //     0xe00dd4: sub             SP, SP, #0x30
    // 0xe00dd8: SetupParameters(_TabBarViewState this /* r1 => r0, fp-0x10 */)
    //     0xe00dd8: mov             x0, x1
    //     0xe00ddc: stur            x1, [fp, #-0x10]
    // 0xe00de0: CheckStackOverflow
    //     0xe00de0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe00de4: cmp             SP, x16
    //     0xe00de8: b.ls            #0xe00ec0
    // 0xe00dec: LoadField: r1 = r0->field_b
    //     0xe00dec: ldur            w1, [x0, #0xb]
    // 0xe00df0: DecompressPointer r1
    //     0xe00df0: add             x1, x1, HEAP, lsl #32
    // 0xe00df4: cmp             w1, NULL
    // 0xe00df8: b.eq            #0xe00ec8
    // 0xe00dfc: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xe00dfc: ldur            w3, [x0, #0x17]
    // 0xe00e00: DecompressPointer r3
    //     0xe00e00: add             x3, x3, HEAP, lsl #32
    // 0xe00e04: stur            x3, [fp, #-8]
    // 0xe00e08: LoadField: r2 = r1->field_13
    //     0xe00e08: ldur            w2, [x1, #0x13]
    // 0xe00e0c: DecompressPointer r2
    //     0xe00e0c: add             x2, x2, HEAP, lsl #32
    // 0xe00e10: cmp             w2, NULL
    // 0xe00e14: b.ne            #0xe00e30
    // 0xe00e18: r1 = Instance_PageScrollPhysics
    //     0xe00e18: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c750] Obj!PageScrollPhysics@129b5d1
    //     0xe00e1c: ldr             x1, [x1, #0x750]
    // 0xe00e20: r2 = Instance_ClampingScrollPhysics
    //     0xe00e20: add             x2, PP, #0x8c, lsl #12  ; [pp+0x8c758] Obj!ClampingScrollPhysics@129b591
    //     0xe00e24: ldr             x2, [x2, #0x758]
    // 0xe00e28: r0 = applyTo()
    //     0xe00e28: bl              #0x12f4660  ; [package:flutter/src/widgets/page_view.dart] PageScrollPhysics::applyTo
    // 0xe00e2c: b               #0xe00e3c
    // 0xe00e30: r1 = Instance_PageScrollPhysics
    //     0xe00e30: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c750] Obj!PageScrollPhysics@129b5d1
    //     0xe00e34: ldr             x1, [x1, #0x750]
    // 0xe00e38: r0 = applyTo()
    //     0xe00e38: bl              #0x12f4660  ; [package:flutter/src/widgets/page_view.dart] PageScrollPhysics::applyTo
    // 0xe00e3c: ldur            x2, [fp, #-0x10]
    // 0xe00e40: stur            x0, [fp, #-0x20]
    // 0xe00e44: LoadField: r1 = r2->field_1b
    //     0xe00e44: ldur            w1, [x2, #0x1b]
    // 0xe00e48: DecompressPointer r1
    //     0xe00e48: add             x1, x1, HEAP, lsl #32
    // 0xe00e4c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe00e50: cmp             w1, w16
    // 0xe00e54: b.eq            #0xe00ecc
    // 0xe00e58: stur            x1, [fp, #-0x18]
    // 0xe00e5c: r0 = PageView()
    //     0xe00e5c: bl              #0xdeef3c  ; AllocatePageViewStub -> PageView (size=0x48)
    // 0xe00e60: stur            x0, [fp, #-0x28]
    // 0xe00e64: ldur            x16, [fp, #-0x20]
    // 0xe00e68: str             x16, [SP]
    // 0xe00e6c: mov             x1, x0
    // 0xe00e70: ldur            x2, [fp, #-0x18]
    // 0xe00e74: ldur            x3, [fp, #-8]
    // 0xe00e78: r4 = const [0, 0x4, 0x1, 0x3, physics, 0x3, null]
    //     0xe00e78: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8c760] List(7) [0, 0x4, 0x1, 0x3, "physics", 0x3, Null]
    //     0xe00e7c: ldr             x4, [x4, #0x760]
    // 0xe00e80: r0 = PageView()
    //     0xe00e80: bl              #0xe00efc  ; [package:flutter/src/widgets/page_view.dart] PageView::PageView
    // 0xe00e84: ldur            x2, [fp, #-0x10]
    // 0xe00e88: r1 = Function '_handleScrollNotification@780014024':.
    //     0xe00e88: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c768] AnonymousClosure: (0xe011a0), in [package:flutter/src/material/tabs.dart] _TabBarViewState::_handleScrollNotification (0xe011dc)
    //     0xe00e8c: ldr             x1, [x1, #0x768]
    // 0xe00e90: r0 = AllocateClosure()
    //     0xe00e90: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe00e94: r1 = <ScrollNotification>
    //     0xe00e94: add             x1, PP, #0x88, lsl #12  ; [pp+0x88ad0] TypeArguments: <ScrollNotification>
    //     0xe00e98: ldr             x1, [x1, #0xad0]
    // 0xe00e9c: stur            x0, [fp, #-8]
    // 0xe00ea0: r0 = NotificationListener()
    //     0xe00ea0: bl              #0xd2ea9c  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0xe00ea4: ldur            x1, [fp, #-8]
    // 0xe00ea8: StoreField: r0->field_13 = r1
    //     0xe00ea8: stur            w1, [x0, #0x13]
    // 0xe00eac: ldur            x1, [fp, #-0x28]
    // 0xe00eb0: StoreField: r0->field_b = r1
    //     0xe00eb0: stur            w1, [x0, #0xb]
    // 0xe00eb4: LeaveFrame
    //     0xe00eb4: mov             SP, fp
    //     0xe00eb8: ldp             fp, lr, [SP], #0x10
    // 0xe00ebc: ret
    //     0xe00ebc: ret             
    // 0xe00ec0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe00ec0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe00ec4: b               #0xe00dec
    // 0xe00ec8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe00ec8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe00ecc: r9 = _childrenWithKey
    //     0xe00ecc: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8c770] Field <_TabBarViewState@780014024._childrenWithKey@780014024>: late (offset: 0x1c)
    //     0xe00ed0: ldr             x9, [x9, #0x770]
    // 0xe00ed4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xe00ed4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] bool _handleScrollNotification(dynamic, ScrollNotification) {
    // ** addr: 0xe011a0, size: 0x3c
    // 0xe011a0: EnterFrame
    //     0xe011a0: stp             fp, lr, [SP, #-0x10]!
    //     0xe011a4: mov             fp, SP
    // 0xe011a8: ldr             x0, [fp, #0x18]
    // 0xe011ac: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xe011ac: ldur            w1, [x0, #0x17]
    // 0xe011b0: DecompressPointer r1
    //     0xe011b0: add             x1, x1, HEAP, lsl #32
    // 0xe011b4: CheckStackOverflow
    //     0xe011b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe011b8: cmp             SP, x16
    //     0xe011bc: b.ls            #0xe011d4
    // 0xe011c0: ldr             x2, [fp, #0x10]
    // 0xe011c4: r0 = _handleScrollNotification()
    //     0xe011c4: bl              #0xe011dc  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_handleScrollNotification
    // 0xe011c8: LeaveFrame
    //     0xe011c8: mov             SP, fp
    //     0xe011cc: ldp             fp, lr, [SP], #0x10
    // 0xe011d0: ret
    //     0xe011d0: ret             
    // 0xe011d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe011d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe011d8: b               #0xe011c0
  }
  _ _handleScrollNotification(/* No info */) {
    // ** addr: 0xe011dc, size: 0x378
    // 0xe011dc: EnterFrame
    //     0xe011dc: stp             fp, lr, [SP, #-0x10]!
    //     0xe011e0: mov             fp, SP
    // 0xe011e4: AllocStack(0x10)
    //     0xe011e4: sub             SP, SP, #0x10
    // 0xe011e8: SetupParameters(_TabBarViewState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xe011e8: mov             x0, x1
    //     0xe011ec: stur            x1, [fp, #-8]
    //     0xe011f0: stur            x2, [fp, #-0x10]
    // 0xe011f4: CheckStackOverflow
    //     0xe011f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe011f8: cmp             SP, x16
    //     0xe011fc: b.ls            #0xe014ec
    // 0xe01200: LoadField: r1 = r0->field_23
    //     0xe01200: ldur            x1, [x0, #0x23]
    // 0xe01204: cmp             x1, #0
    // 0xe01208: b.gt            #0xe01218
    // 0xe0120c: LoadField: r1 = r0->field_2b
    //     0xe0120c: ldur            x1, [x0, #0x2b]
    // 0xe01210: cmp             x1, #0
    // 0xe01214: b.le            #0xe01228
    // 0xe01218: r0 = false
    //     0xe01218: add             x0, NULL, #0x30  ; false
    // 0xe0121c: LeaveFrame
    //     0xe0121c: mov             SP, fp
    //     0xe01220: ldp             fp, lr, [SP], #0x10
    // 0xe01224: ret
    //     0xe01224: ret             
    // 0xe01228: LoadField: r1 = r2->field_7
    //     0xe01228: ldur            x1, [x2, #7]
    // 0xe0122c: cbz             x1, #0xe01240
    // 0xe01230: r0 = false
    //     0xe01230: add             x0, NULL, #0x30  ; false
    // 0xe01234: LeaveFrame
    //     0xe01234: mov             SP, fp
    //     0xe01238: ldp             fp, lr, [SP], #0x10
    // 0xe0123c: ret
    //     0xe0123c: ret             
    // 0xe01240: mov             x1, x0
    // 0xe01244: r0 = _controllerIsValid()
    //     0xe01244: bl              #0xe01810  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_controllerIsValid
    // 0xe01248: tbz             w0, #4, #0xe0125c
    // 0xe0124c: r0 = false
    //     0xe0124c: add             x0, NULL, #0x30  ; false
    // 0xe01250: LeaveFrame
    //     0xe01250: mov             SP, fp
    //     0xe01254: ldp             fp, lr, [SP], #0x10
    // 0xe01258: ret
    //     0xe01258: ret             
    // 0xe0125c: ldur            x2, [fp, #-8]
    // 0xe01260: ldur            x0, [fp, #-0x10]
    // 0xe01264: LoadField: r1 = r2->field_2b
    //     0xe01264: ldur            x1, [x2, #0x2b]
    // 0xe01268: add             x3, x1, #1
    // 0xe0126c: StoreField: r2->field_2b = r3
    //     0xe0126c: stur            x3, [x2, #0x2b]
    // 0xe01270: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xe01270: ldur            w1, [x2, #0x17]
    // 0xe01274: DecompressPointer r1
    //     0xe01274: add             x1, x1, HEAP, lsl #32
    // 0xe01278: cmp             w1, NULL
    // 0xe0127c: b.eq            #0xe014f4
    // 0xe01280: r0 = page()
    //     0xe01280: bl              #0xcec058  ; [package:flutter/src/widgets/page_view.dart] PageController::page
    // 0xe01284: cmp             w0, NULL
    // 0xe01288: b.eq            #0xe014f8
    // 0xe0128c: ldur            x1, [fp, #-0x10]
    // 0xe01290: r2 = LoadClassIdInstr(r1)
    //     0xe01290: ldur            x2, [x1, #-1]
    //     0xe01294: ubfx            x2, x2, #0xc, #0x14
    // 0xe01298: r17 = 4556
    //     0xe01298: mov             x17, #0x11cc
    // 0xe0129c: cmp             x2, x17
    // 0xe012a0: b.ne            #0xe013e4
    // 0xe012a4: ldur            x19, [fp, #-8]
    // 0xe012a8: LoadField: r20 = r19->field_13
    //     0xe012a8: ldur            w20, [x19, #0x13]
    // 0xe012ac: DecompressPointer r20
    //     0xe012ac: add             x20, x20, HEAP, lsl #32
    // 0xe012b0: cmp             w20, NULL
    // 0xe012b4: b.eq            #0xe014fc
    // 0xe012b8: LoadField: r1 = r20->field_43
    //     0xe012b8: ldur            x1, [x20, #0x43]
    // 0xe012bc: cbnz            x1, #0xe013e4
    // 0xe012c0: d0 = 0.000000
    //     0xe012c0: eor             v0.16b, v0.16b, v0.16b
    // 0xe012c4: LoadField: r1 = r20->field_33
    //     0xe012c4: ldur            x1, [x20, #0x33]
    // 0xe012c8: scvtf           d1, x1
    // 0xe012cc: LoadField: d2 = r0->field_7
    //     0xe012cc: ldur            d2, [x0, #7]
    // 0xe012d0: fsub            d3, d2, d1
    // 0xe012d4: fcmp            d3, d0
    // 0xe012d8: b.ne            #0xe012f0
    // 0xe012dc: d1 = 1.000000
    //     0xe012dc: fmov            d1, #1.00000000
    // 0xe012e0: fcmp            d0, d1
    // 0xe012e4: b.gt            #0xe01318
    // 0xe012e8: mov             x2, x19
    // 0xe012ec: b               #0xe013d8
    // 0xe012f0: d1 = 1.000000
    //     0xe012f0: fmov            d1, #1.00000000
    // 0xe012f4: fcmp            d0, d3
    // 0xe012f8: b.le            #0xe01310
    // 0xe012fc: fneg            d0, d3
    // 0xe01300: fcmp            d0, d1
    // 0xe01304: b.gt            #0xe01318
    // 0xe01308: mov             x2, x19
    // 0xe0130c: b               #0xe013d8
    // 0xe01310: fcmp            d3, d1
    // 0xe01314: b.le            #0xe013d4
    // 0xe01318: mov             v0.16b, v2.16b
    // 0xe0131c: stp             fp, lr, [SP, #-0x10]!
    // 0xe01320: mov             fp, SP
    // 0xe01324: CallRuntime_LibcRound(double) -> double
    //     0xe01324: and             SP, SP, #0xfffffffffffffff0
    //     0xe01328: mov             sp, SP
    //     0xe0132c: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0xe01330: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xe01334: blr             x16
    //     0xe01338: mov             x16, #8
    //     0xe0133c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xe01340: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xe01344: sub             sp, x16, #1, lsl #12
    //     0xe01348: mov             SP, fp
    //     0xe0134c: ldp             fp, lr, [SP], #0x10
    // 0xe01350: fcmp            d0, d0
    // 0xe01354: b.vs            #0xe01500
    // 0xe01358: fcvtzs          x0, d0
    // 0xe0135c: asr             x16, x0, #0x1e
    // 0xe01360: cmp             x16, x0, asr #63
    // 0xe01364: b.ne            #0xe01500
    // 0xe01368: lsl             x0, x0, #1
    // 0xe0136c: r2 = LoadInt32Instr(r0)
    //     0xe0136c: sbfx            x2, x0, #1, #0x1f
    //     0xe01370: tbz             w0, #0, #0xe01378
    //     0xe01374: ldur            x2, [x0, #7]
    // 0xe01378: mov             x1, x20
    // 0xe0137c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xe0137c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xe01380: r0 = _changeIndex()
    //     0xe01380: bl              #0xdffe34  ; [package:flutter/src/material/tab_controller.dart] TabController::_changeIndex
    // 0xe01384: ldur            x2, [fp, #-8]
    // 0xe01388: LoadField: r0 = r2->field_13
    //     0xe01388: ldur            w0, [x2, #0x13]
    // 0xe0138c: DecompressPointer r0
    //     0xe0138c: add             x0, x0, HEAP, lsl #32
    // 0xe01390: cmp             w0, NULL
    // 0xe01394: b.eq            #0xe01524
    // 0xe01398: LoadField: r3 = r0->field_33
    //     0xe01398: ldur            x3, [x0, #0x33]
    // 0xe0139c: r0 = BoxInt64Instr(r3)
    //     0xe0139c: sbfiz           x0, x3, #1, #0x1f
    //     0xe013a0: cmp             x3, x0, asr #1
    //     0xe013a4: b.eq            #0xe013b0
    //     0xe013a8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xe013ac: stur            x3, [x0, #7]
    // 0xe013b0: StoreField: r2->field_1f = r0
    //     0xe013b0: stur            w0, [x2, #0x1f]
    //     0xe013b4: tbz             w0, #0, #0xe013d0
    //     0xe013b8: ldurb           w16, [x2, #-1]
    //     0xe013bc: ldurb           w17, [x0, #-1]
    //     0xe013c0: and             x16, x17, x16, lsr #2
    //     0xe013c4: tst             x16, HEAP, lsr #32
    //     0xe013c8: b.eq            #0xe013d0
    //     0xe013cc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xe013d0: b               #0xe013d8
    // 0xe013d4: mov             x2, x19
    // 0xe013d8: mov             x1, x2
    // 0xe013dc: r0 = _syncControllerOffset()
    //     0xe013dc: bl              #0xe01554  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_syncControllerOffset
    // 0xe013e0: b               #0xe014cc
    // 0xe013e4: r17 = 4554
    //     0xe013e4: mov             x17, #0x11ca
    // 0xe013e8: cmp             x2, x17
    // 0xe013ec: b.ne            #0xe014cc
    // 0xe013f0: ldur            x19, [fp, #-8]
    // 0xe013f4: LoadField: r20 = r19->field_13
    //     0xe013f4: ldur            w20, [x19, #0x13]
    // 0xe013f8: DecompressPointer r20
    //     0xe013f8: add             x20, x20, HEAP, lsl #32
    // 0xe013fc: cmp             w20, NULL
    // 0xe01400: b.eq            #0xe01528
    // 0xe01404: LoadField: d0 = r0->field_7
    //     0xe01404: ldur            d0, [x0, #7]
    // 0xe01408: stp             fp, lr, [SP, #-0x10]!
    // 0xe0140c: mov             fp, SP
    // 0xe01410: CallRuntime_LibcRound(double) -> double
    //     0xe01410: and             SP, SP, #0xfffffffffffffff0
    //     0xe01414: mov             sp, SP
    //     0xe01418: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0xe0141c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xe01420: blr             x16
    //     0xe01424: mov             x16, #8
    //     0xe01428: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xe0142c: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xe01430: sub             sp, x16, #1, lsl #12
    //     0xe01434: mov             SP, fp
    //     0xe01438: ldp             fp, lr, [SP], #0x10
    // 0xe0143c: fcmp            d0, d0
    // 0xe01440: b.vs            #0xe0152c
    // 0xe01444: fcvtzs          x0, d0
    // 0xe01448: asr             x16, x0, #0x1e
    // 0xe0144c: cmp             x16, x0, asr #63
    // 0xe01450: b.ne            #0xe0152c
    // 0xe01454: lsl             x0, x0, #1
    // 0xe01458: r2 = LoadInt32Instr(r0)
    //     0xe01458: sbfx            x2, x0, #1, #0x1f
    //     0xe0145c: tbz             w0, #0, #0xe01464
    //     0xe01460: ldur            x2, [x0, #7]
    // 0xe01464: mov             x1, x20
    // 0xe01468: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xe01468: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xe0146c: r0 = _changeIndex()
    //     0xe0146c: bl              #0xdffe34  ; [package:flutter/src/material/tab_controller.dart] TabController::_changeIndex
    // 0xe01470: ldur            x2, [fp, #-8]
    // 0xe01474: LoadField: r3 = r2->field_13
    //     0xe01474: ldur            w3, [x2, #0x13]
    // 0xe01478: DecompressPointer r3
    //     0xe01478: add             x3, x3, HEAP, lsl #32
    // 0xe0147c: cmp             w3, NULL
    // 0xe01480: b.eq            #0xe01550
    // 0xe01484: LoadField: r4 = r3->field_33
    //     0xe01484: ldur            x4, [x3, #0x33]
    // 0xe01488: r0 = BoxInt64Instr(r4)
    //     0xe01488: sbfiz           x0, x4, #1, #0x1f
    //     0xe0148c: cmp             x4, x0, asr #1
    //     0xe01490: b.eq            #0xe0149c
    //     0xe01494: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xe01498: stur            x4, [x0, #7]
    // 0xe0149c: StoreField: r2->field_1f = r0
    //     0xe0149c: stur            w0, [x2, #0x1f]
    //     0xe014a0: tbz             w0, #0, #0xe014bc
    //     0xe014a4: ldurb           w16, [x2, #-1]
    //     0xe014a8: ldurb           w17, [x0, #-1]
    //     0xe014ac: and             x16, x17, x16, lsr #2
    //     0xe014b0: tst             x16, HEAP, lsr #32
    //     0xe014b4: b.eq            #0xe014bc
    //     0xe014b8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xe014bc: LoadField: r0 = r3->field_43
    //     0xe014bc: ldur            x0, [x3, #0x43]
    // 0xe014c0: cbnz            x0, #0xe014cc
    // 0xe014c4: mov             x1, x2
    // 0xe014c8: r0 = _syncControllerOffset()
    //     0xe014c8: bl              #0xe01554  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_syncControllerOffset
    // 0xe014cc: ldur            x1, [fp, #-8]
    // 0xe014d0: LoadField: r2 = r1->field_2b
    //     0xe014d0: ldur            x2, [x1, #0x2b]
    // 0xe014d4: sub             x3, x2, #1
    // 0xe014d8: StoreField: r1->field_2b = r3
    //     0xe014d8: stur            x3, [x1, #0x2b]
    // 0xe014dc: r0 = false
    //     0xe014dc: add             x0, NULL, #0x30  ; false
    // 0xe014e0: LeaveFrame
    //     0xe014e0: mov             SP, fp
    //     0xe014e4: ldp             fp, lr, [SP], #0x10
    // 0xe014e8: ret
    //     0xe014e8: ret             
    // 0xe014ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe014ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe014f0: b               #0xe01200
    // 0xe014f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe014f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe014f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe014f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe014fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe014fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe01500: SaveReg d0
    //     0xe01500: str             q0, [SP, #-0x10]!
    // 0xe01504: stp             x19, x20, [SP, #-0x10]!
    // 0xe01508: r0 = 76
    //     0xe01508: mov             x0, #0x4c
    // 0xe0150c: r30 = DoubleToIntegerStub
    //     0xe0150c: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xe01510: LoadField: r30 = r30->field_7
    //     0xe01510: ldur            lr, [lr, #7]
    // 0xe01514: blr             lr
    // 0xe01518: ldp             x19, x20, [SP], #0x10
    // 0xe0151c: RestoreReg d0
    //     0xe0151c: ldr             q0, [SP], #0x10
    // 0xe01520: b               #0xe0136c
    // 0xe01524: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe01524: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe01528: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe01528: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe0152c: SaveReg d0
    //     0xe0152c: str             q0, [SP, #-0x10]!
    // 0xe01530: stp             x19, x20, [SP, #-0x10]!
    // 0xe01534: r0 = 76
    //     0xe01534: mov             x0, #0x4c
    // 0xe01538: r30 = DoubleToIntegerStub
    //     0xe01538: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xe0153c: LoadField: r30 = r30->field_7
    //     0xe0153c: ldur            lr, [lr, #7]
    // 0xe01540: blr             lr
    // 0xe01544: ldp             x19, x20, [SP], #0x10
    // 0xe01548: RestoreReg d0
    //     0xe01548: ldr             q0, [SP], #0x10
    // 0xe0154c: b               #0xe01458
    // 0xe01550: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe01550: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _syncControllerOffset(/* No info */) {
    // ** addr: 0xe01554, size: 0x134
    // 0xe01554: EnterFrame
    //     0xe01554: stp             fp, lr, [SP, #-0x10]!
    //     0xe01558: mov             fp, SP
    // 0xe0155c: AllocStack(0x18)
    //     0xe0155c: sub             SP, SP, #0x18
    // 0xe01560: SetupParameters(_TabBarViewState this /* r1 => r0, fp-0x10 */)
    //     0xe01560: mov             x0, x1
    //     0xe01564: stur            x1, [fp, #-0x10]
    // 0xe01568: CheckStackOverflow
    //     0xe01568: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe0156c: cmp             SP, x16
    //     0xe01570: b.ls            #0xe01670
    // 0xe01574: LoadField: r2 = r0->field_13
    //     0xe01574: ldur            w2, [x0, #0x13]
    // 0xe01578: DecompressPointer r2
    //     0xe01578: add             x2, x2, HEAP, lsl #32
    // 0xe0157c: stur            x2, [fp, #-8]
    // 0xe01580: cmp             w2, NULL
    // 0xe01584: b.eq            #0xe01678
    // 0xe01588: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xe01588: ldur            w1, [x0, #0x17]
    // 0xe0158c: DecompressPointer r1
    //     0xe0158c: add             x1, x1, HEAP, lsl #32
    // 0xe01590: cmp             w1, NULL
    // 0xe01594: b.eq            #0xe0167c
    // 0xe01598: LoadField: r3 = r1->field_3b
    //     0xe01598: ldur            w3, [x1, #0x3b]
    // 0xe0159c: DecompressPointer r3
    //     0xe0159c: add             x3, x3, HEAP, lsl #32
    // 0xe015a0: mov             x1, x3
    // 0xe015a4: r0 = single()
    //     0xe015a4: bl              #0xb3aa28  ; [dart:core] _GrowableList::single
    // 0xe015a8: mov             x3, x0
    // 0xe015ac: r2 = Null
    //     0xe015ac: mov             x2, NULL
    // 0xe015b0: r1 = Null
    //     0xe015b0: mov             x1, NULL
    // 0xe015b4: stur            x3, [fp, #-0x18]
    // 0xe015b8: r4 = 60
    //     0xe015b8: mov             x4, #0x3c
    // 0xe015bc: branchIfSmi(r0, 0xe015c8)
    //     0xe015bc: tbz             w0, #0, #0xe015c8
    // 0xe015c0: r4 = LoadClassIdInstr(r0)
    //     0xe015c0: ldur            x4, [x0, #-1]
    //     0xe015c4: ubfx            x4, x4, #0xc, #0x14
    // 0xe015c8: r17 = 4541
    //     0xe015c8: mov             x17, #0x11bd
    // 0xe015cc: cmp             x4, x17
    // 0xe015d0: b.eq            #0xe015e8
    // 0xe015d4: r8 = _PagePosition
    //     0xe015d4: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8c778] Type: _PagePosition
    //     0xe015d8: ldr             x8, [x8, #0x778]
    // 0xe015dc: r3 = Null
    //     0xe015dc: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c780] Null
    //     0xe015e0: ldr             x3, [x3, #0x780]
    // 0xe015e4: r0 = DefaultTypeTest()
    //     0xe015e4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xe015e8: ldur            x1, [fp, #-0x18]
    // 0xe015ec: r0 = page()
    //     0xe015ec: bl              #0xcec310  ; [package:flutter/src/widgets/page_view.dart] _PagePosition::page
    // 0xe015f0: cmp             w0, NULL
    // 0xe015f4: b.eq            #0xe01680
    // 0xe015f8: ldur            x1, [fp, #-0x10]
    // 0xe015fc: LoadField: r2 = r1->field_13
    //     0xe015fc: ldur            w2, [x1, #0x13]
    // 0xe01600: DecompressPointer r2
    //     0xe01600: add             x2, x2, HEAP, lsl #32
    // 0xe01604: cmp             w2, NULL
    // 0xe01608: b.eq            #0xe01684
    // 0xe0160c: LoadField: r1 = r2->field_33
    //     0xe0160c: ldur            x1, [x2, #0x33]
    // 0xe01610: scvtf           d0, x1
    // 0xe01614: LoadField: d1 = r0->field_7
    //     0xe01614: ldur            d1, [x0, #7]
    // 0xe01618: fsub            d2, d1, d0
    // 0xe0161c: d0 = -1.000000
    //     0xe0161c: fmov            d0, #-1.00000000
    // 0xe01620: fcmp            d0, d2
    // 0xe01624: b.le            #0xe01630
    // 0xe01628: d0 = -1.000000
    //     0xe01628: fmov            d0, #-1.00000000
    // 0xe0162c: b               #0xe01658
    // 0xe01630: d0 = 1.000000
    //     0xe01630: fmov            d0, #1.00000000
    // 0xe01634: fcmp            d2, d0
    // 0xe01638: b.le            #0xe01644
    // 0xe0163c: d0 = 1.000000
    //     0xe0163c: fmov            d0, #1.00000000
    // 0xe01640: b               #0xe01658
    // 0xe01644: fcmp            d2, d2
    // 0xe01648: b.vc            #0xe01654
    // 0xe0164c: d0 = 1.000000
    //     0xe0164c: fmov            d0, #1.00000000
    // 0xe01650: b               #0xe01658
    // 0xe01654: mov             v0.16b, v2.16b
    // 0xe01658: ldur            x1, [fp, #-8]
    // 0xe0165c: r0 = offset=()
    //     0xe0165c: bl              #0xe01688  ; [package:flutter/src/material/tab_controller.dart] TabController::offset=
    // 0xe01660: r0 = Null
    //     0xe01660: mov             x0, NULL
    // 0xe01664: LeaveFrame
    //     0xe01664: mov             SP, fp
    //     0xe01668: ldp             fp, lr, [SP], #0x10
    // 0xe0166c: ret
    //     0xe0166c: ret             
    // 0xe01670: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe01670: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe01674: b               #0xe01574
    // 0xe01678: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe01678: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe0167c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe0167c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe01680: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe01680: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe01684: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe01684: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _controllerIsValid(/* No info */) {
    // ** addr: 0xe01810, size: 0x40
    // 0xe01810: LoadField: r2 = r1->field_13
    //     0xe01810: ldur            w2, [x1, #0x13]
    // 0xe01814: DecompressPointer r2
    //     0xe01814: add             x2, x2, HEAP, lsl #32
    // 0xe01818: cmp             w2, NULL
    // 0xe0181c: b.ne            #0xe01828
    // 0xe01820: r1 = Null
    //     0xe01820: mov             x1, NULL
    // 0xe01824: b               #0xe0183c
    // 0xe01828: LoadField: r1 = r2->field_23
    //     0xe01828: ldur            w1, [x2, #0x23]
    // 0xe0182c: DecompressPointer r1
    //     0xe0182c: add             x1, x1, HEAP, lsl #32
    // 0xe01830: cmp             w1, NULL
    // 0xe01834: b.ne            #0xe0183c
    // 0xe01838: r1 = Null
    //     0xe01838: mov             x1, NULL
    // 0xe0183c: cmp             w1, NULL
    // 0xe01840: r16 = true
    //     0xe01840: add             x16, NULL, #0x20  ; true
    // 0xe01844: r17 = false
    //     0xe01844: add             x17, NULL, #0x30  ; false
    // 0xe01848: csel            x0, x16, x17, ne
    // 0xe0184c: ret
    //     0xe0184c: ret             
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xef6d58, size: 0x114
    // 0xef6d58: EnterFrame
    //     0xef6d58: stp             fp, lr, [SP, #-0x10]!
    //     0xef6d5c: mov             fp, SP
    // 0xef6d60: AllocStack(0x18)
    //     0xef6d60: sub             SP, SP, #0x18
    // 0xef6d64: SetupParameters(_TabBarViewState this /* r1 => r0, fp-0x8 */)
    //     0xef6d64: mov             x0, x1
    //     0xef6d68: stur            x1, [fp, #-8]
    // 0xef6d6c: CheckStackOverflow
    //     0xef6d6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef6d70: cmp             SP, x16
    //     0xef6d74: b.ls            #0xef6e5c
    // 0xef6d78: mov             x1, x0
    // 0xef6d7c: r0 = _updateTabController()
    //     0xef6d7c: bl              #0xef6fdc  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_updateTabController
    // 0xef6d80: ldur            x2, [fp, #-8]
    // 0xef6d84: LoadField: r0 = r2->field_13
    //     0xef6d84: ldur            w0, [x2, #0x13]
    // 0xef6d88: DecompressPointer r0
    //     0xef6d88: add             x0, x0, HEAP, lsl #32
    // 0xef6d8c: cmp             w0, NULL
    // 0xef6d90: b.eq            #0xef6e64
    // 0xef6d94: LoadField: r3 = r0->field_33
    //     0xef6d94: ldur            x3, [x0, #0x33]
    // 0xef6d98: stur            x3, [fp, #-0x10]
    // 0xef6d9c: r0 = BoxInt64Instr(r3)
    //     0xef6d9c: sbfiz           x0, x3, #1, #0x1f
    //     0xef6da0: cmp             x3, x0, asr #1
    //     0xef6da4: b.eq            #0xef6db0
    //     0xef6da8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xef6dac: stur            x3, [x0, #7]
    // 0xef6db0: StoreField: r2->field_1f = r0
    //     0xef6db0: stur            w0, [x2, #0x1f]
    //     0xef6db4: tbz             w0, #0, #0xef6dd0
    //     0xef6db8: ldurb           w16, [x2, #-1]
    //     0xef6dbc: ldurb           w17, [x0, #-1]
    //     0xef6dc0: and             x16, x17, x16, lsr #2
    //     0xef6dc4: tst             x16, HEAP, lsr #32
    //     0xef6dc8: b.eq            #0xef6dd0
    //     0xef6dcc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xef6dd0: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xef6dd0: ldur            w1, [x2, #0x17]
    // 0xef6dd4: DecompressPointer r1
    //     0xef6dd4: add             x1, x1, HEAP, lsl #32
    // 0xef6dd8: cmp             w1, NULL
    // 0xef6ddc: b.ne            #0xef6e44
    // 0xef6de0: LoadField: r0 = r2->field_b
    //     0xef6de0: ldur            w0, [x2, #0xb]
    // 0xef6de4: DecompressPointer r0
    //     0xef6de4: add             x0, x0, HEAP, lsl #32
    // 0xef6de8: cmp             w0, NULL
    // 0xef6dec: b.eq            #0xef6e68
    // 0xef6df0: r0 = PageController()
    //     0xef6df0: bl              #0xef6fd0  ; AllocatePageControllerStub -> PageController (size=0x54)
    // 0xef6df4: ldur            x2, [fp, #-0x10]
    // 0xef6df8: stur            x0, [fp, #-0x18]
    // 0xef6dfc: StoreField: r0->field_3f = r2
    //     0xef6dfc: stur            x2, [x0, #0x3f]
    // 0xef6e00: r1 = true
    //     0xef6e00: add             x1, NULL, #0x20  ; true
    // 0xef6e04: StoreField: r0->field_47 = r1
    //     0xef6e04: stur            w1, [x0, #0x47]
    // 0xef6e08: d0 = 1.000000
    //     0xef6e08: fmov            d0, #1.00000000
    // 0xef6e0c: StoreField: r0->field_4b = d0
    //     0xef6e0c: stur            d0, [x0, #0x4b]
    // 0xef6e10: mov             x1, x0
    // 0xef6e14: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xef6e14: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xef6e18: r0 = ScrollController()
    //     0xef6e18: bl              #0x86d884  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0xef6e1c: ldur            x0, [fp, #-0x18]
    // 0xef6e20: ldur            x1, [fp, #-8]
    // 0xef6e24: ArrayStore: r1[0] = r0  ; List_4
    //     0xef6e24: stur            w0, [x1, #0x17]
    //     0xef6e28: ldurb           w16, [x1, #-1]
    //     0xef6e2c: ldurb           w17, [x0, #-1]
    //     0xef6e30: and             x16, x17, x16, lsr #2
    //     0xef6e34: tst             x16, HEAP, lsr #32
    //     0xef6e38: b.eq            #0xef6e40
    //     0xef6e3c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef6e40: b               #0xef6e4c
    // 0xef6e44: mov             x2, x3
    // 0xef6e48: r0 = jumpToPage()
    //     0xef6e48: bl              #0xef6e6c  ; [package:flutter/src/widgets/page_view.dart] PageController::jumpToPage
    // 0xef6e4c: r0 = Null
    //     0xef6e4c: mov             x0, NULL
    // 0xef6e50: LeaveFrame
    //     0xef6e50: mov             SP, fp
    //     0xef6e54: ldp             fp, lr, [SP], #0x10
    // 0xef6e58: ret
    //     0xef6e58: ret             
    // 0xef6e5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef6e5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef6e60: b               #0xef6d78
    // 0xef6e64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef6e64: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef6e68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef6e68: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTabController(/* No info */) {
    // ** addr: 0xef6fdc, size: 0x178
    // 0xef6fdc: EnterFrame
    //     0xef6fdc: stp             fp, lr, [SP, #-0x10]!
    //     0xef6fe0: mov             fp, SP
    // 0xef6fe4: AllocStack(0x18)
    //     0xef6fe4: sub             SP, SP, #0x18
    // 0xef6fe8: SetupParameters(_TabBarViewState this /* r1 => r0, fp-0x8 */)
    //     0xef6fe8: mov             x0, x1
    //     0xef6fec: stur            x1, [fp, #-8]
    // 0xef6ff0: CheckStackOverflow
    //     0xef6ff0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef6ff4: cmp             SP, x16
    //     0xef6ff8: b.ls            #0xef7138
    // 0xef6ffc: LoadField: r1 = r0->field_b
    //     0xef6ffc: ldur            w1, [x0, #0xb]
    // 0xef7000: DecompressPointer r1
    //     0xef7000: add             x1, x1, HEAP, lsl #32
    // 0xef7004: cmp             w1, NULL
    // 0xef7008: b.eq            #0xef7140
    // 0xef700c: LoadField: r2 = r1->field_b
    //     0xef700c: ldur            w2, [x1, #0xb]
    // 0xef7010: DecompressPointer r2
    //     0xef7010: add             x2, x2, HEAP, lsl #32
    // 0xef7014: cmp             w2, NULL
    // 0xef7018: b.ne            #0xef7034
    // 0xef701c: LoadField: r1 = r0->field_f
    //     0xef701c: ldur            w1, [x0, #0xf]
    // 0xef7020: DecompressPointer r1
    //     0xef7020: add             x1, x1, HEAP, lsl #32
    // 0xef7024: cmp             w1, NULL
    // 0xef7028: b.eq            #0xef7144
    // 0xef702c: r0 = maybeOf()
    //     0xef702c: bl              #0xef6a7c  ; [package:flutter/src/material/tab_controller.dart] DefaultTabController::maybeOf
    // 0xef7030: mov             x2, x0
    // 0xef7034: ldur            x0, [fp, #-8]
    // 0xef7038: stur            x2, [fp, #-0x10]
    // 0xef703c: LoadField: r1 = r0->field_13
    //     0xef703c: ldur            w1, [x0, #0x13]
    // 0xef7040: DecompressPointer r1
    //     0xef7040: add             x1, x1, HEAP, lsl #32
    // 0xef7044: cmp             w2, w1
    // 0xef7048: b.ne            #0xef705c
    // 0xef704c: r0 = Null
    //     0xef704c: mov             x0, NULL
    // 0xef7050: LeaveFrame
    //     0xef7050: mov             SP, fp
    //     0xef7054: ldp             fp, lr, [SP], #0x10
    // 0xef7058: ret
    //     0xef7058: ret             
    // 0xef705c: mov             x1, x0
    // 0xef7060: r0 = _controllerIsValid()
    //     0xef7060: bl              #0xe01810  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_controllerIsValid
    // 0xef7064: tbnz            w0, #4, #0xef70c0
    // 0xef7068: ldur            x0, [fp, #-8]
    // 0xef706c: LoadField: r1 = r0->field_13
    //     0xef706c: ldur            w1, [x0, #0x13]
    // 0xef7070: DecompressPointer r1
    //     0xef7070: add             x1, x1, HEAP, lsl #32
    // 0xef7074: cmp             w1, NULL
    // 0xef7078: b.eq            #0xef7148
    // 0xef707c: LoadField: r2 = r1->field_23
    //     0xef707c: ldur            w2, [x1, #0x23]
    // 0xef7080: DecompressPointer r2
    //     0xef7080: add             x2, x2, HEAP, lsl #32
    // 0xef7084: cmp             w2, NULL
    // 0xef7088: b.ne            #0xef7094
    // 0xef708c: r3 = Null
    //     0xef708c: mov             x3, NULL
    // 0xef7090: b               #0xef7098
    // 0xef7094: mov             x3, x2
    // 0xef7098: stur            x3, [fp, #-0x18]
    // 0xef709c: cmp             w3, NULL
    // 0xef70a0: b.eq            #0xef714c
    // 0xef70a4: mov             x2, x0
    // 0xef70a8: r1 = Function '_handleTabControllerAnimationTick@780014024':.
    //     0xef70a8: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c7a8] AnonymousClosure: (0xef7154), in [package:flutter/src/material/tabs.dart] _TabBarViewState::_handleTabControllerAnimationTick (0xef718c)
    //     0xef70ac: ldr             x1, [x1, #0x7a8]
    // 0xef70b0: r0 = AllocateClosure()
    //     0xef70b0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef70b4: ldur            x1, [fp, #-0x18]
    // 0xef70b8: mov             x2, x0
    // 0xef70bc: r0 = removeListener()
    //     0xef70bc: bl              #0xd00c74  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::removeListener
    // 0xef70c0: ldur            x2, [fp, #-8]
    // 0xef70c4: ldur            x1, [fp, #-0x10]
    // 0xef70c8: mov             x0, x1
    // 0xef70cc: StoreField: r2->field_13 = r0
    //     0xef70cc: stur            w0, [x2, #0x13]
    //     0xef70d0: ldurb           w16, [x2, #-1]
    //     0xef70d4: ldurb           w17, [x0, #-1]
    //     0xef70d8: and             x16, x17, x16, lsr #2
    //     0xef70dc: tst             x16, HEAP, lsr #32
    //     0xef70e0: b.eq            #0xef70e8
    //     0xef70e4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xef70e8: cmp             w1, NULL
    // 0xef70ec: b.eq            #0xef7128
    // 0xef70f0: LoadField: r0 = r1->field_23
    //     0xef70f0: ldur            w0, [x1, #0x23]
    // 0xef70f4: DecompressPointer r0
    //     0xef70f4: add             x0, x0, HEAP, lsl #32
    // 0xef70f8: cmp             w0, NULL
    // 0xef70fc: b.ne            #0xef7104
    // 0xef7100: r0 = Null
    //     0xef7100: mov             x0, NULL
    // 0xef7104: stur            x0, [fp, #-0x10]
    // 0xef7108: cmp             w0, NULL
    // 0xef710c: b.eq            #0xef7150
    // 0xef7110: r1 = Function '_handleTabControllerAnimationTick@780014024':.
    //     0xef7110: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c7a8] AnonymousClosure: (0xef7154), in [package:flutter/src/material/tabs.dart] _TabBarViewState::_handleTabControllerAnimationTick (0xef718c)
    //     0xef7114: ldr             x1, [x1, #0x7a8]
    // 0xef7118: r0 = AllocateClosure()
    //     0xef7118: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef711c: ldur            x1, [fp, #-0x10]
    // 0xef7120: mov             x2, x0
    // 0xef7124: r0 = addListener()
    //     0xef7124: bl              #0xd0440c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::addListener
    // 0xef7128: r0 = Null
    //     0xef7128: mov             x0, NULL
    // 0xef712c: LeaveFrame
    //     0xef712c: mov             SP, fp
    //     0xef7130: ldp             fp, lr, [SP], #0x10
    // 0xef7134: ret
    //     0xef7134: ret             
    // 0xef7138: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef7138: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef713c: b               #0xef6ffc
    // 0xef7140: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef7140: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef7144: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef7144: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef7148: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef7148: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef714c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef714c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef7150: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef7150: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleTabControllerAnimationTick(dynamic) {
    // ** addr: 0xef7154, size: 0x38
    // 0xef7154: EnterFrame
    //     0xef7154: stp             fp, lr, [SP, #-0x10]!
    //     0xef7158: mov             fp, SP
    // 0xef715c: ldr             x0, [fp, #0x10]
    // 0xef7160: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xef7160: ldur            w1, [x0, #0x17]
    // 0xef7164: DecompressPointer r1
    //     0xef7164: add             x1, x1, HEAP, lsl #32
    // 0xef7168: CheckStackOverflow
    //     0xef7168: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef716c: cmp             SP, x16
    //     0xef7170: b.ls            #0xef7184
    // 0xef7174: r0 = _handleTabControllerAnimationTick()
    //     0xef7174: bl              #0xef718c  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_handleTabControllerAnimationTick
    // 0xef7178: LeaveFrame
    //     0xef7178: mov             SP, fp
    //     0xef717c: ldp             fp, lr, [SP], #0x10
    // 0xef7180: ret
    //     0xef7180: ret             
    // 0xef7184: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef7184: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef7188: b               #0xef7174
  }
  _ _handleTabControllerAnimationTick(/* No info */) {
    // ** addr: 0xef718c, size: 0xf0
    // 0xef718c: EnterFrame
    //     0xef718c: stp             fp, lr, [SP, #-0x10]!
    //     0xef7190: mov             fp, SP
    // 0xef7194: mov             x2, x1
    // 0xef7198: CheckStackOverflow
    //     0xef7198: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef719c: cmp             SP, x16
    //     0xef71a0: b.ls            #0xef7270
    // 0xef71a4: LoadField: r0 = r2->field_2b
    //     0xef71a4: ldur            x0, [x2, #0x2b]
    // 0xef71a8: cmp             x0, #0
    // 0xef71ac: b.gt            #0xef71c8
    // 0xef71b0: LoadField: r0 = r2->field_13
    //     0xef71b0: ldur            w0, [x2, #0x13]
    // 0xef71b4: DecompressPointer r0
    //     0xef71b4: add             x0, x0, HEAP, lsl #32
    // 0xef71b8: cmp             w0, NULL
    // 0xef71bc: b.eq            #0xef7278
    // 0xef71c0: LoadField: r1 = r0->field_43
    //     0xef71c0: ldur            x1, [x0, #0x43]
    // 0xef71c4: cbnz            x1, #0xef71d8
    // 0xef71c8: r0 = Null
    //     0xef71c8: mov             x0, NULL
    // 0xef71cc: LeaveFrame
    //     0xef71cc: mov             SP, fp
    //     0xef71d0: ldp             fp, lr, [SP], #0x10
    // 0xef71d4: ret
    //     0xef71d4: ret             
    // 0xef71d8: LoadField: r3 = r0->field_33
    //     0xef71d8: ldur            x3, [x0, #0x33]
    // 0xef71dc: LoadField: r4 = r2->field_1f
    //     0xef71dc: ldur            w4, [x2, #0x1f]
    // 0xef71e0: DecompressPointer r4
    //     0xef71e0: add             x4, x4, HEAP, lsl #32
    // 0xef71e4: r0 = BoxInt64Instr(r3)
    //     0xef71e4: sbfiz           x0, x3, #1, #0x1f
    //     0xef71e8: cmp             x3, x0, asr #1
    //     0xef71ec: b.eq            #0xef71f8
    //     0xef71f0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xef71f4: stur            x3, [x0, #7]
    // 0xef71f8: cmp             w0, w4
    // 0xef71fc: b.eq            #0xef7260
    // 0xef7200: and             w16, w0, w4
    // 0xef7204: branchIfSmi(r16, 0xef7238)
    //     0xef7204: tbz             w16, #0, #0xef7238
    // 0xef7208: r16 = LoadClassIdInstr(r0)
    //     0xef7208: ldur            x16, [x0, #-1]
    //     0xef720c: ubfx            x16, x16, #0xc, #0x14
    // 0xef7210: cmp             x16, #0x3d
    // 0xef7214: b.ne            #0xef7238
    // 0xef7218: r16 = LoadClassIdInstr(r4)
    //     0xef7218: ldur            x16, [x4, #-1]
    //     0xef721c: ubfx            x16, x16, #0xc, #0x14
    // 0xef7220: cmp             x16, #0x3d
    // 0xef7224: b.ne            #0xef7238
    // 0xef7228: LoadField: r16 = r0->field_7
    //     0xef7228: ldur            x16, [x0, #7]
    // 0xef722c: LoadField: r17 = r4->field_7
    //     0xef722c: ldur            x17, [x4, #7]
    // 0xef7230: cmp             x16, x17
    // 0xef7234: b.eq            #0xef7260
    // 0xef7238: StoreField: r2->field_1f = r0
    //     0xef7238: stur            w0, [x2, #0x1f]
    //     0xef723c: tbz             w0, #0, #0xef7258
    //     0xef7240: ldurb           w16, [x2, #-1]
    //     0xef7244: ldurb           w17, [x0, #-1]
    //     0xef7248: and             x16, x17, x16, lsr #2
    //     0xef724c: tst             x16, HEAP, lsr #32
    //     0xef7250: b.eq            #0xef7258
    //     0xef7254: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xef7258: mov             x1, x2
    // 0xef725c: r0 = _warpToCurrentIndex()
    //     0xef725c: bl              #0xef727c  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_warpToCurrentIndex
    // 0xef7260: r0 = Null
    //     0xef7260: mov             x0, NULL
    // 0xef7264: LeaveFrame
    //     0xef7264: mov             SP, fp
    //     0xef7268: ldp             fp, lr, [SP], #0x10
    // 0xef726c: ret
    //     0xef726c: ret             
    // 0xef7270: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef7270: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef7274: b               #0xef71a4
    // 0xef7278: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef7278: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _warpToCurrentIndex(/* No info */) {
    // ** addr: 0xef727c, size: 0x178
    // 0xef727c: EnterFrame
    //     0xef727c: stp             fp, lr, [SP, #-0x10]!
    //     0xef7280: mov             fp, SP
    // 0xef7284: AllocStack(0x20)
    //     0xef7284: sub             SP, SP, #0x20
    // 0xef7288: SetupParameters(_TabBarViewState this /* r1 => r0, fp-0x8 */)
    //     0xef7288: mov             x0, x1
    //     0xef728c: stur            x1, [fp, #-8]
    // 0xef7290: CheckStackOverflow
    //     0xef7290: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef7294: cmp             SP, x16
    //     0xef7298: b.ls            #0xef73dc
    // 0xef729c: LoadField: r1 = r0->field_f
    //     0xef729c: ldur            w1, [x0, #0xf]
    // 0xef72a0: DecompressPointer r1
    //     0xef72a0: add             x1, x1, HEAP, lsl #32
    // 0xef72a4: cmp             w1, NULL
    // 0xef72a8: b.eq            #0xef735c
    // 0xef72ac: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xef72ac: ldur            w1, [x0, #0x17]
    // 0xef72b0: DecompressPointer r1
    //     0xef72b0: add             x1, x1, HEAP, lsl #32
    // 0xef72b4: cmp             w1, NULL
    // 0xef72b8: b.eq            #0xef73e4
    // 0xef72bc: LoadField: r2 = r1->field_3b
    //     0xef72bc: ldur            w2, [x1, #0x3b]
    // 0xef72c0: DecompressPointer r2
    //     0xef72c0: add             x2, x2, HEAP, lsl #32
    // 0xef72c4: mov             x1, x2
    // 0xef72c8: r0 = single()
    //     0xef72c8: bl              #0xb3aa28  ; [dart:core] _GrowableList::single
    // 0xef72cc: mov             x3, x0
    // 0xef72d0: r2 = Null
    //     0xef72d0: mov             x2, NULL
    // 0xef72d4: r1 = Null
    //     0xef72d4: mov             x1, NULL
    // 0xef72d8: stur            x3, [fp, #-0x10]
    // 0xef72dc: r4 = 60
    //     0xef72dc: mov             x4, #0x3c
    // 0xef72e0: branchIfSmi(r0, 0xef72ec)
    //     0xef72e0: tbz             w0, #0, #0xef72ec
    // 0xef72e4: r4 = LoadClassIdInstr(r0)
    //     0xef72e4: ldur            x4, [x0, #-1]
    //     0xef72e8: ubfx            x4, x4, #0xc, #0x14
    // 0xef72ec: r17 = 4541
    //     0xef72ec: mov             x17, #0x11bd
    // 0xef72f0: cmp             x4, x17
    // 0xef72f4: b.eq            #0xef730c
    // 0xef72f8: r8 = _PagePosition
    //     0xef72f8: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8c778] Type: _PagePosition
    //     0xef72fc: ldr             x8, [x8, #0x778]
    // 0xef7300: r3 = Null
    //     0xef7300: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c7b0] Null
    //     0xef7304: ldr             x3, [x3, #0x7b0]
    // 0xef7308: r0 = DefaultTypeTest()
    //     0xef7308: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xef730c: ldur            x1, [fp, #-0x10]
    // 0xef7310: r0 = page()
    //     0xef7310: bl              #0xcec310  ; [package:flutter/src/widgets/page_view.dart] _PagePosition::page
    // 0xef7314: ldur            x1, [fp, #-8]
    // 0xef7318: stur            x0, [fp, #-0x10]
    // 0xef731c: LoadField: r2 = r1->field_1f
    //     0xef731c: ldur            w2, [x1, #0x1f]
    // 0xef7320: DecompressPointer r2
    //     0xef7320: add             x2, x2, HEAP, lsl #32
    // 0xef7324: cmp             w2, NULL
    // 0xef7328: b.eq            #0xef73e8
    // 0xef732c: stp             x2, NULL, [SP]
    // 0xef7330: r0 = _Double.fromInteger()
    //     0xef7330: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0xef7334: mov             x1, x0
    // 0xef7338: ldur            x0, [fp, #-0x10]
    // 0xef733c: r2 = LoadClassIdInstr(r0)
    //     0xef733c: ldur            x2, [x0, #-1]
    //     0xef7340: ubfx            x2, x2, #0xc, #0x14
    // 0xef7344: stp             x1, x0, [SP]
    // 0xef7348: mov             x0, x2
    // 0xef734c: mov             lr, x0
    // 0xef7350: ldr             lr, [x21, lr, lsl #3]
    // 0xef7354: blr             lr
    // 0xef7358: tbnz            w0, #4, #0xef736c
    // 0xef735c: r0 = Null
    //     0xef735c: mov             x0, NULL
    // 0xef7360: LeaveFrame
    //     0xef7360: mov             SP, fp
    //     0xef7364: ldp             fp, lr, [SP], #0x10
    // 0xef7368: ret
    //     0xef7368: ret             
    // 0xef736c: ldur            x1, [fp, #-8]
    // 0xef7370: LoadField: r0 = r1->field_1f
    //     0xef7370: ldur            w0, [x1, #0x1f]
    // 0xef7374: DecompressPointer r0
    //     0xef7374: add             x0, x0, HEAP, lsl #32
    // 0xef7378: cmp             w0, NULL
    // 0xef737c: b.eq            #0xef73ec
    // 0xef7380: LoadField: r2 = r1->field_13
    //     0xef7380: ldur            w2, [x1, #0x13]
    // 0xef7384: DecompressPointer r2
    //     0xef7384: add             x2, x2, HEAP, lsl #32
    // 0xef7388: cmp             w2, NULL
    // 0xef738c: b.eq            #0xef73f0
    // 0xef7390: LoadField: r3 = r2->field_3b
    //     0xef7390: ldur            x3, [x2, #0x3b]
    // 0xef7394: r2 = LoadInt32Instr(r0)
    //     0xef7394: sbfx            x2, x0, #1, #0x1f
    //     0xef7398: tbz             w0, #0, #0xef73a0
    //     0xef739c: ldur            x2, [x0, #7]
    // 0xef73a0: sub             x0, x2, x3
    // 0xef73a4: tbz             x0, #0x3f, #0xef73b8
    // 0xef73a8: neg             x2, x0
    // 0xef73ac: cmp             x2, #1
    // 0xef73b0: b.ne            #0xef73c8
    // 0xef73b4: b               #0xef73c0
    // 0xef73b8: cmp             x0, #1
    // 0xef73bc: b.ne            #0xef73c8
    // 0xef73c0: r0 = _warpToAdjacentTab()
    //     0xef73c0: bl              #0xef7dc0  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_warpToAdjacentTab
    // 0xef73c4: b               #0xef73cc
    // 0xef73c8: r0 = _warpToNonAdjacentTab()
    //     0xef73c8: bl              #0xef73f4  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_warpToNonAdjacentTab
    // 0xef73cc: r0 = Null
    //     0xef73cc: mov             x0, NULL
    // 0xef73d0: LeaveFrame
    //     0xef73d0: mov             SP, fp
    //     0xef73d4: ldp             fp, lr, [SP], #0x10
    // 0xef73d8: ret
    //     0xef73d8: ret             
    // 0xef73dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef73dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef73e0: b               #0xef729c
    // 0xef73e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef73e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef73e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef73e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef73ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef73ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef73f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef73f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _warpToNonAdjacentTab(/* No info */) async {
    // ** addr: 0xef73f4, size: 0x1a8
    // 0xef73f4: EnterFrame
    //     0xef73f4: stp             fp, lr, [SP, #-0x10]!
    //     0xef73f8: mov             fp, SP
    // 0xef73fc: AllocStack(0x28)
    //     0xef73fc: sub             SP, SP, #0x28
    // 0xef7400: SetupParameters(_TabBarViewState this /* r1 => r1, fp-0x10 */)
    //     0xef7400: stur            NULL, [fp, #-8]
    //     0xef7404: stur            x1, [fp, #-0x10]
    // 0xef7408: CheckStackOverflow
    //     0xef7408: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef740c: cmp             SP, x16
    //     0xef7410: b.ls            #0xef7588
    // 0xef7414: r1 = 3
    //     0xef7414: mov             x1, #3
    // 0xef7418: r0 = AllocateContext()
    //     0xef7418: bl              #0x13de838  ; AllocateContextStub
    // 0xef741c: mov             x2, x0
    // 0xef7420: ldur            x1, [fp, #-0x10]
    // 0xef7424: stur            x2, [fp, #-0x18]
    // 0xef7428: StoreField: r2->field_f = r1
    //     0xef7428: stur            w1, [x2, #0xf]
    // 0xef742c: InitAsync() -> Future<void?>
    //     0xef742c: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xef7430: bl              #0x7f5e44  ; InitAsyncStub
    // 0xef7434: ldur            x3, [fp, #-0x10]
    // 0xef7438: LoadField: r0 = r3->field_13
    //     0xef7438: ldur            w0, [x3, #0x13]
    // 0xef743c: DecompressPointer r0
    //     0xef743c: add             x0, x0, HEAP, lsl #32
    // 0xef7440: cmp             w0, NULL
    // 0xef7444: b.eq            #0xef7590
    // 0xef7448: LoadField: r2 = r0->field_3b
    //     0xef7448: ldur            x2, [x0, #0x3b]
    // 0xef744c: r0 = BoxInt64Instr(r2)
    //     0xef744c: sbfiz           x0, x2, #1, #0x1f
    //     0xef7450: cmp             x2, x0, asr #1
    //     0xef7454: b.eq            #0xef7460
    //     0xef7458: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xef745c: stur            x2, [x0, #7]
    // 0xef7460: ldur            x4, [fp, #-0x18]
    // 0xef7464: StoreField: r4->field_13 = r0
    //     0xef7464: stur            w0, [x4, #0x13]
    //     0xef7468: tbz             w0, #0, #0xef7484
    //     0xef746c: ldurb           w16, [x4, #-1]
    //     0xef7470: ldurb           w17, [x0, #-1]
    //     0xef7474: and             x16, x17, x16, lsr #2
    //     0xef7478: tst             x16, HEAP, lsr #32
    //     0xef747c: b.eq            #0xef7484
    //     0xef7480: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xef7484: LoadField: r0 = r3->field_1f
    //     0xef7484: ldur            w0, [x3, #0x1f]
    // 0xef7488: DecompressPointer r0
    //     0xef7488: add             x0, x0, HEAP, lsl #32
    // 0xef748c: cmp             w0, NULL
    // 0xef7490: b.eq            #0xef7594
    // 0xef7494: r1 = LoadInt32Instr(r0)
    //     0xef7494: sbfx            x1, x0, #1, #0x1f
    //     0xef7498: tbz             w0, #0, #0xef74a0
    //     0xef749c: ldur            x1, [x0, #7]
    // 0xef74a0: cmp             x1, x2
    // 0xef74a4: b.le            #0xef74b4
    // 0xef74a8: sub             x0, x1, #1
    // 0xef74ac: mov             x5, x0
    // 0xef74b0: b               #0xef74bc
    // 0xef74b4: add             x0, x1, #1
    // 0xef74b8: mov             x5, x0
    // 0xef74bc: stur            x5, [fp, #-0x20]
    // 0xef74c0: r0 = BoxInt64Instr(r5)
    //     0xef74c0: sbfiz           x0, x5, #1, #0x1f
    //     0xef74c4: cmp             x5, x0, asr #1
    //     0xef74c8: b.eq            #0xef74d4
    //     0xef74cc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xef74d0: stur            x5, [x0, #7]
    // 0xef74d4: ArrayStore: r4[0] = r0  ; List_4
    //     0xef74d4: stur            w0, [x4, #0x17]
    //     0xef74d8: tbz             w0, #0, #0xef74f4
    //     0xef74dc: ldurb           w16, [x4, #-1]
    //     0xef74e0: ldurb           w17, [x0, #-1]
    //     0xef74e4: and             x16, x17, x16, lsr #2
    //     0xef74e8: tst             x16, HEAP, lsr #32
    //     0xef74ec: b.eq            #0xef74f4
    //     0xef74f0: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xef74f4: mov             x2, x4
    // 0xef74f8: r1 = Function '<anonymous closure>':.
    //     0xef74f8: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c7c0] AnonymousClosure: (0xef7bf0), in [package:flutter/src/material/tabs.dart] _TabBarViewState::_warpToNonAdjacentTab (0xef73f4)
    //     0xef74fc: ldr             x1, [x1, #0x7c0]
    // 0xef7500: r0 = AllocateClosure()
    //     0xef7500: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef7504: ldur            x1, [fp, #-0x10]
    // 0xef7508: mov             x2, x0
    // 0xef750c: r0 = setState()
    //     0xef750c: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xef7510: ldur            x1, [fp, #-0x10]
    // 0xef7514: ldur            x2, [fp, #-0x20]
    // 0xef7518: r0 = _jumpToPage()
    //     0xef7518: bl              #0xef7624  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_jumpToPage
    // 0xef751c: ldur            x0, [fp, #-0x10]
    // 0xef7520: LoadField: r1 = r0->field_1f
    //     0xef7520: ldur            w1, [x0, #0x1f]
    // 0xef7524: DecompressPointer r1
    //     0xef7524: add             x1, x1, HEAP, lsl #32
    // 0xef7528: cmp             w1, NULL
    // 0xef752c: b.eq            #0xef7598
    // 0xef7530: r2 = LoadInt32Instr(r1)
    //     0xef7530: sbfx            x2, x1, #1, #0x1f
    //     0xef7534: tbz             w1, #0, #0xef753c
    //     0xef7538: ldur            x2, [x1, #7]
    // 0xef753c: mov             x1, x0
    // 0xef7540: r0 = _animateToPage()
    //     0xef7540: bl              #0xef759c  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_animateToPage
    // 0xef7544: mov             x1, x0
    // 0xef7548: stur            x1, [fp, #-0x28]
    // 0xef754c: r0 = Await()
    //     0xef754c: bl              #0x7f5c00  ; AwaitStub
    // 0xef7550: ldur            x0, [fp, #-0x10]
    // 0xef7554: LoadField: r1 = r0->field_f
    //     0xef7554: ldur            w1, [x0, #0xf]
    // 0xef7558: DecompressPointer r1
    //     0xef7558: add             x1, x1, HEAP, lsl #32
    // 0xef755c: cmp             w1, NULL
    // 0xef7560: b.eq            #0xef7580
    // 0xef7564: ldur            x2, [fp, #-0x18]
    // 0xef7568: r1 = Function '<anonymous closure>':.
    //     0xef7568: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c7c8] AnonymousClosure: (0xef7690), in [package:flutter/src/material/tabs.dart] _TabBarViewState::_warpToNonAdjacentTab (0xef73f4)
    //     0xef756c: ldr             x1, [x1, #0x7c8]
    // 0xef7570: r0 = AllocateClosure()
    //     0xef7570: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef7574: ldur            x1, [fp, #-0x10]
    // 0xef7578: mov             x2, x0
    // 0xef757c: r0 = setState()
    //     0xef757c: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xef7580: r0 = Null
    //     0xef7580: mov             x0, NULL
    // 0xef7584: r0 = ReturnAsyncNotFuture()
    //     0xef7584: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xef7588: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef7588: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef758c: b               #0xef7414
    // 0xef7590: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef7590: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef7594: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef7594: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef7598: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef7598: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _animateToPage(/* No info */) async {
    // ** addr: 0xef759c, size: 0x88
    // 0xef759c: EnterFrame
    //     0xef759c: stp             fp, lr, [SP, #-0x10]!
    //     0xef75a0: mov             fp, SP
    // 0xef75a4: AllocStack(0x20)
    //     0xef75a4: sub             SP, SP, #0x20
    // 0xef75a8: SetupParameters(_TabBarViewState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xef75a8: stur            NULL, [fp, #-8]
    //     0xef75ac: stur            x1, [fp, #-0x10]
    //     0xef75b0: stur            x2, [fp, #-0x18]
    // 0xef75b4: CheckStackOverflow
    //     0xef75b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef75b8: cmp             SP, x16
    //     0xef75bc: b.ls            #0xef7618
    // 0xef75c0: InitAsync() -> Future<void?>
    //     0xef75c0: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xef75c4: bl              #0x7f5e44  ; InitAsyncStub
    // 0xef75c8: ldur            x0, [fp, #-0x10]
    // 0xef75cc: LoadField: r1 = r0->field_23
    //     0xef75cc: ldur            x1, [x0, #0x23]
    // 0xef75d0: add             x2, x1, #1
    // 0xef75d4: StoreField: r0->field_23 = r2
    //     0xef75d4: stur            x2, [x0, #0x23]
    // 0xef75d8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xef75d8: ldur            w1, [x0, #0x17]
    // 0xef75dc: DecompressPointer r1
    //     0xef75dc: add             x1, x1, HEAP, lsl #32
    // 0xef75e0: cmp             w1, NULL
    // 0xef75e4: b.eq            #0xef7620
    // 0xef75e8: ldur            x2, [fp, #-0x18]
    // 0xef75ec: r3 = Instance_Duration
    //     0xef75ec: ldr             x3, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xef75f0: r0 = animateToPage()
    //     0xef75f0: bl              #0xcec0dc  ; [package:flutter/src/widgets/page_view.dart] PageController::animateToPage
    // 0xef75f4: mov             x1, x0
    // 0xef75f8: stur            x1, [fp, #-0x20]
    // 0xef75fc: r0 = Await()
    //     0xef75fc: bl              #0x7f5c00  ; AwaitStub
    // 0xef7600: ldur            x1, [fp, #-0x10]
    // 0xef7604: LoadField: r2 = r1->field_23
    //     0xef7604: ldur            x2, [x1, #0x23]
    // 0xef7608: sub             x3, x2, #1
    // 0xef760c: StoreField: r1->field_23 = r3
    //     0xef760c: stur            x3, [x1, #0x23]
    // 0xef7610: r0 = Null
    //     0xef7610: mov             x0, NULL
    // 0xef7614: r0 = ReturnAsyncNotFuture()
    //     0xef7614: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xef7618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef7618: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef761c: b               #0xef75c0
    // 0xef7620: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef7620: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _jumpToPage(/* No info */) {
    // ** addr: 0xef7624, size: 0x6c
    // 0xef7624: EnterFrame
    //     0xef7624: stp             fp, lr, [SP, #-0x10]!
    //     0xef7628: mov             fp, SP
    // 0xef762c: AllocStack(0x8)
    //     0xef762c: sub             SP, SP, #8
    // 0xef7630: SetupParameters(_TabBarViewState this /* r1 => r0, fp-0x8 */)
    //     0xef7630: mov             x0, x1
    //     0xef7634: stur            x1, [fp, #-8]
    // 0xef7638: CheckStackOverflow
    //     0xef7638: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef763c: cmp             SP, x16
    //     0xef7640: b.ls            #0xef7684
    // 0xef7644: LoadField: r1 = r0->field_23
    //     0xef7644: ldur            x1, [x0, #0x23]
    // 0xef7648: add             x3, x1, #1
    // 0xef764c: StoreField: r0->field_23 = r3
    //     0xef764c: stur            x3, [x0, #0x23]
    // 0xef7650: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xef7650: ldur            w1, [x0, #0x17]
    // 0xef7654: DecompressPointer r1
    //     0xef7654: add             x1, x1, HEAP, lsl #32
    // 0xef7658: cmp             w1, NULL
    // 0xef765c: b.eq            #0xef768c
    // 0xef7660: r0 = jumpToPage()
    //     0xef7660: bl              #0xef6e6c  ; [package:flutter/src/widgets/page_view.dart] PageController::jumpToPage
    // 0xef7664: ldur            x1, [fp, #-8]
    // 0xef7668: LoadField: r2 = r1->field_23
    //     0xef7668: ldur            x2, [x1, #0x23]
    // 0xef766c: sub             x3, x2, #1
    // 0xef7670: StoreField: r1->field_23 = r3
    //     0xef7670: stur            x3, [x1, #0x23]
    // 0xef7674: r0 = Null
    //     0xef7674: mov             x0, NULL
    // 0xef7678: LeaveFrame
    //     0xef7678: mov             SP, fp
    //     0xef767c: ldp             fp, lr, [SP], #0x10
    // 0xef7680: ret
    //     0xef7680: ret             
    // 0xef7684: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef7684: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef7688: b               #0xef7644
    // 0xef768c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef768c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xef7690, size: 0x48
    // 0xef7690: EnterFrame
    //     0xef7690: stp             fp, lr, [SP, #-0x10]!
    //     0xef7694: mov             fp, SP
    // 0xef7698: ldr             x0, [fp, #0x10]
    // 0xef769c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xef769c: ldur            w1, [x0, #0x17]
    // 0xef76a0: DecompressPointer r1
    //     0xef76a0: add             x1, x1, HEAP, lsl #32
    // 0xef76a4: CheckStackOverflow
    //     0xef76a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef76a8: cmp             SP, x16
    //     0xef76ac: b.ls            #0xef76d0
    // 0xef76b0: LoadField: r0 = r1->field_f
    //     0xef76b0: ldur            w0, [x1, #0xf]
    // 0xef76b4: DecompressPointer r0
    //     0xef76b4: add             x0, x0, HEAP, lsl #32
    // 0xef76b8: mov             x1, x0
    // 0xef76bc: r0 = _updateChildren()
    //     0xef76bc: bl              #0xef76d8  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_updateChildren
    // 0xef76c0: r0 = Null
    //     0xef76c0: mov             x0, NULL
    // 0xef76c4: LeaveFrame
    //     0xef76c4: mov             SP, fp
    //     0xef76c8: ldp             fp, lr, [SP], #0x10
    // 0xef76cc: ret
    //     0xef76cc: ret             
    // 0xef76d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef76d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef76d4: b               #0xef76b0
  }
  _ _updateChildren(/* No info */) {
    // ** addr: 0xef76d8, size: 0x198
    // 0xef76d8: EnterFrame
    //     0xef76d8: stp             fp, lr, [SP, #-0x10]!
    //     0xef76dc: mov             fp, SP
    // 0xef76e0: AllocStack(0x30)
    //     0xef76e0: sub             SP, SP, #0x30
    // 0xef76e4: SetupParameters(_TabBarViewState this /* r1 => r0, fp-0x10 */)
    //     0xef76e4: mov             x0, x1
    //     0xef76e8: stur            x1, [fp, #-0x10]
    // 0xef76ec: CheckStackOverflow
    //     0xef76ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef76f0: cmp             SP, x16
    //     0xef76f4: b.ls            #0xef7864
    // 0xef76f8: LoadField: r1 = r0->field_b
    //     0xef76f8: ldur            w1, [x0, #0xb]
    // 0xef76fc: DecompressPointer r1
    //     0xef76fc: add             x1, x1, HEAP, lsl #32
    // 0xef7700: cmp             w1, NULL
    // 0xef7704: b.eq            #0xef786c
    // 0xef7708: LoadField: r3 = r1->field_f
    //     0xef7708: ldur            w3, [x1, #0xf]
    // 0xef770c: DecompressPointer r3
    //     0xef770c: add             x3, x3, HEAP, lsl #32
    // 0xef7710: stur            x3, [fp, #-8]
    // 0xef7714: r1 = Function '<anonymous closure>':.
    //     0xef7714: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c7d0] AnonymousClosure: (0xef7b98), in [package:flutter/src/material/tabs.dart] _TabBarViewState::_updateChildren (0xef76d8)
    //     0xef7718: ldr             x1, [x1, #0x7d0]
    // 0xef771c: r2 = Null
    //     0xef771c: mov             x2, NULL
    // 0xef7720: r0 = AllocateClosure()
    //     0xef7720: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef7724: r16 = <Widget>
    //     0xef7724: ldr             x16, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xef7728: ldur            lr, [fp, #-8]
    // 0xef772c: stp             lr, x16, [SP, #8]
    // 0xef7730: str             x0, [SP]
    // 0xef7734: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xef7734: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xef7738: r0 = map()
    //     0xef7738: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0xef773c: mov             x3, x0
    // 0xef7740: stur            x3, [fp, #-0x18]
    // 0xef7744: LoadField: r4 = r3->field_7
    //     0xef7744: ldur            w4, [x3, #7]
    // 0xef7748: DecompressPointer r4
    //     0xef7748: add             x4, x4, HEAP, lsl #32
    // 0xef774c: mov             x0, x3
    // 0xef7750: stur            x4, [fp, #-8]
    // 0xef7754: r2 = Null
    //     0xef7754: mov             x2, NULL
    // 0xef7758: r1 = Null
    //     0xef7758: mov             x1, NULL
    // 0xef775c: cmp             w0, NULL
    // 0xef7760: b.eq            #0xef77f8
    // 0xef7764: branchIfSmi(r0, 0xef77f8)
    //     0xef7764: tbz             w0, #0, #0xef77f8
    // 0xef7768: r3 = LoadClassIdInstr(r0)
    //     0xef7768: ldur            x3, [x0, #-1]
    //     0xef776c: ubfx            x3, x3, #0xc, #0x14
    // 0xef7770: r17 = 7724
    //     0xef7770: mov             x17, #0x1e2c
    // 0xef7774: cmp             x3, x17
    // 0xef7778: b.eq            #0xef7800
    // 0xef777c: r4 = LoadClassIdInstr(r0)
    //     0xef777c: ldur            x4, [x0, #-1]
    //     0xef7780: ubfx            x4, x4, #0xc, #0x14
    // 0xef7784: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0xef7788: ldr             x3, [x3, #0x18]
    // 0xef778c: ldr             x3, [x3, x4, lsl #3]
    // 0xef7790: LoadField: r3 = r3->field_2b
    //     0xef7790: ldur            w3, [x3, #0x2b]
    // 0xef7794: DecompressPointer r3
    //     0xef7794: add             x3, x3, HEAP, lsl #32
    // 0xef7798: cmp             w3, NULL
    // 0xef779c: b.eq            #0xef77f8
    // 0xef77a0: LoadField: r3 = r3->field_f
    //     0xef77a0: ldur            w3, [x3, #0xf]
    // 0xef77a4: lsr             x3, x3, #3
    // 0xef77a8: r17 = 7724
    //     0xef77a8: mov             x17, #0x1e2c
    // 0xef77ac: cmp             x3, x17
    // 0xef77b0: b.eq            #0xef7800
    // 0xef77b4: r3 = SubtypeTestCache
    //     0xef77b4: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c7d8] SubtypeTestCache
    //     0xef77b8: ldr             x3, [x3, #0x7d8]
    // 0xef77bc: r30 = Subtype1TestCacheStub
    //     0xef77bc: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0xef77c0: LoadField: r30 = r30->field_7
    //     0xef77c0: ldur            lr, [lr, #7]
    // 0xef77c4: blr             lr
    // 0xef77c8: cmp             w7, NULL
    // 0xef77cc: b.eq            #0xef77d8
    // 0xef77d0: tbnz            w7, #4, #0xef77f8
    // 0xef77d4: b               #0xef7800
    // 0xef77d8: r8 = EfficientLengthIterable
    //     0xef77d8: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8c7e0] Type: EfficientLengthIterable
    //     0xef77dc: ldr             x8, [x8, #0x7e0]
    // 0xef77e0: r3 = SubtypeTestCache
    //     0xef77e0: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c7e8] SubtypeTestCache
    //     0xef77e4: ldr             x3, [x3, #0x7e8]
    // 0xef77e8: r30 = InstanceOfStub
    //     0xef77e8: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xef77ec: LoadField: r30 = r30->field_7
    //     0xef77ec: ldur            lr, [lr, #7]
    // 0xef77f0: blr             lr
    // 0xef77f4: b               #0xef7804
    // 0xef77f8: r0 = false
    //     0xef77f8: add             x0, NULL, #0x30  ; false
    // 0xef77fc: b               #0xef7804
    // 0xef7800: r0 = true
    //     0xef7800: add             x0, NULL, #0x20  ; true
    // 0xef7804: tbnz            w0, #4, #0xef781c
    // 0xef7808: ldur            x1, [fp, #-8]
    // 0xef780c: ldur            x2, [fp, #-0x18]
    // 0xef7810: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0xef7810: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0xef7814: mov             x1, x0
    // 0xef7818: b               #0xef782c
    // 0xef781c: ldur            x1, [fp, #-8]
    // 0xef7820: ldur            x2, [fp, #-0x18]
    // 0xef7824: r0 = _GrowableList._ofOther()
    //     0xef7824: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0xef7828: mov             x1, x0
    // 0xef782c: ldur            x0, [fp, #-0x10]
    // 0xef7830: r0 = ensureUniqueKeysForList()
    //     0xef7830: bl              #0xef7870  ; [package:flutter/src/widgets/basic.dart] KeyedSubtree::ensureUniqueKeysForList
    // 0xef7834: ldur            x1, [fp, #-0x10]
    // 0xef7838: StoreField: r1->field_1b = r0
    //     0xef7838: stur            w0, [x1, #0x1b]
    //     0xef783c: ldurb           w16, [x1, #-1]
    //     0xef7840: ldurb           w17, [x0, #-1]
    //     0xef7844: and             x16, x17, x16, lsr #2
    //     0xef7848: tst             x16, HEAP, lsr #32
    //     0xef784c: b.eq            #0xef7854
    //     0xef7850: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef7854: r0 = Null
    //     0xef7854: mov             x0, NULL
    // 0xef7858: LeaveFrame
    //     0xef7858: mov             SP, fp
    //     0xef785c: ldp             fp, lr, [SP], #0x10
    // 0xef7860: ret
    //     0xef7860: ret             
    // 0xef7864: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef7864: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef7868: b               #0xef76f8
    // 0xef786c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef786c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Semantics <anonymous closure>(dynamic, Widget) {
    // ** addr: 0xef7b98, size: 0x58
    // 0xef7b98: EnterFrame
    //     0xef7b98: stp             fp, lr, [SP, #-0x10]!
    //     0xef7b9c: mov             fp, SP
    // 0xef7ba0: AllocStack(0x18)
    //     0xef7ba0: sub             SP, SP, #0x18
    // 0xef7ba4: CheckStackOverflow
    //     0xef7ba4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef7ba8: cmp             SP, x16
    //     0xef7bac: b.ls            #0xef7be8
    // 0xef7bb0: r0 = Semantics()
    //     0xef7bb0: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xef7bb4: stur            x0, [fp, #-8]
    // 0xef7bb8: r16 = Instance_SemanticsRole
    //     0xef7bb8: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c7f0] Obj!SemanticsRole@12c7a01
    //     0xef7bbc: ldr             x16, [x16, #0x7f0]
    // 0xef7bc0: ldr             lr, [fp, #0x10]
    // 0xef7bc4: stp             lr, x16, [SP]
    // 0xef7bc8: mov             x1, x0
    // 0xef7bcc: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, role, 0x1, null]
    //     0xef7bcc: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8c7f8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "role", 0x1, Null]
    //     0xef7bd0: ldr             x4, [x4, #0x7f8]
    // 0xef7bd4: r0 = Semantics()
    //     0xef7bd4: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xef7bd8: ldur            x0, [fp, #-8]
    // 0xef7bdc: LeaveFrame
    //     0xef7bdc: mov             SP, fp
    //     0xef7be0: ldp             fp, lr, [SP], #0x10
    // 0xef7be4: ret
    //     0xef7be4: ret             
    // 0xef7be8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef7be8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef7bec: b               #0xef7bb0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xef7bf0, size: 0x1d0
    // 0xef7bf0: EnterFrame
    //     0xef7bf0: stp             fp, lr, [SP, #-0x10]!
    //     0xef7bf4: mov             fp, SP
    // 0xef7bf8: AllocStack(0x40)
    //     0xef7bf8: sub             SP, SP, #0x40
    // 0xef7bfc: SetupParameters([dynamic _ /* r0 */])
    //     0xef7bfc: ldr             x0, [fp, #0x10]
    //     0xef7c00: ldur            w3, [x0, #0x17]
    //     0xef7c04: add             x3, x3, HEAP, lsl #32
    //     0xef7c08: stur            x3, [fp, #-0x10]
    // 0xef7c0c: CheckStackOverflow
    //     0xef7c0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef7c10: cmp             SP, x16
    //     0xef7c14: b.ls            #0xef7d88
    // 0xef7c18: LoadField: r0 = r3->field_f
    //     0xef7c18: ldur            w0, [x3, #0xf]
    // 0xef7c1c: DecompressPointer r0
    //     0xef7c1c: add             x0, x0, HEAP, lsl #32
    // 0xef7c20: stur            x0, [fp, #-8]
    // 0xef7c24: LoadField: r2 = r0->field_1b
    //     0xef7c24: ldur            w2, [x0, #0x1b]
    // 0xef7c28: DecompressPointer r2
    //     0xef7c28: add             x2, x2, HEAP, lsl #32
    // 0xef7c2c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef7c30: cmp             w2, w16
    // 0xef7c34: b.eq            #0xef7d90
    // 0xef7c38: r1 = <Widget>
    //     0xef7c38: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xef7c3c: r0 = _List.of()
    //     0xef7c3c: bl              #0x7d8e04  ; [dart:core] _List::_List.of
    // 0xef7c40: ldur            x1, [fp, #-8]
    // 0xef7c44: StoreField: r1->field_1b = r0
    //     0xef7c44: stur            w0, [x1, #0x1b]
    //     0xef7c48: ldurb           w16, [x1, #-1]
    //     0xef7c4c: ldurb           w17, [x0, #-1]
    //     0xef7c50: and             x16, x17, x16, lsr #2
    //     0xef7c54: tst             x16, HEAP, lsr #32
    //     0xef7c58: b.eq            #0xef7c60
    //     0xef7c5c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef7c60: ldur            x1, [fp, #-0x10]
    // 0xef7c64: LoadField: r0 = r1->field_f
    //     0xef7c64: ldur            w0, [x1, #0xf]
    // 0xef7c68: DecompressPointer r0
    //     0xef7c68: add             x0, x0, HEAP, lsl #32
    // 0xef7c6c: LoadField: r2 = r0->field_1b
    //     0xef7c6c: ldur            w2, [x0, #0x1b]
    // 0xef7c70: DecompressPointer r2
    //     0xef7c70: add             x2, x2, HEAP, lsl #32
    // 0xef7c74: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef7c78: cmp             w2, w16
    // 0xef7c7c: b.eq            #0xef7d9c
    // 0xef7c80: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xef7c80: ldur            w3, [x1, #0x17]
    // 0xef7c84: DecompressPointer r3
    //     0xef7c84: add             x3, x3, HEAP, lsl #32
    // 0xef7c88: stur            x3, [fp, #-8]
    // 0xef7c8c: r0 = LoadClassIdInstr(r2)
    //     0xef7c8c: ldur            x0, [x2, #-1]
    //     0xef7c90: ubfx            x0, x0, #0xc, #0x14
    // 0xef7c94: stp             x3, x2, [SP]
    // 0xef7c98: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xef7c98: sub             lr, x0, #0xdfd
    //     0xef7c9c: ldr             lr, [x21, lr, lsl #3]
    //     0xef7ca0: blr             lr
    // 0xef7ca4: mov             x2, x0
    // 0xef7ca8: ldur            x1, [fp, #-0x10]
    // 0xef7cac: stur            x2, [fp, #-0x28]
    // 0xef7cb0: LoadField: r0 = r1->field_f
    //     0xef7cb0: ldur            w0, [x1, #0xf]
    // 0xef7cb4: DecompressPointer r0
    //     0xef7cb4: add             x0, x0, HEAP, lsl #32
    // 0xef7cb8: LoadField: r3 = r0->field_1b
    //     0xef7cb8: ldur            w3, [x0, #0x1b]
    // 0xef7cbc: DecompressPointer r3
    //     0xef7cbc: add             x3, x3, HEAP, lsl #32
    // 0xef7cc0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef7cc4: cmp             w3, w16
    // 0xef7cc8: b.eq            #0xef7da8
    // 0xef7ccc: stur            x3, [fp, #-0x20]
    // 0xef7cd0: LoadField: r4 = r1->field_13
    //     0xef7cd0: ldur            w4, [x1, #0x13]
    // 0xef7cd4: DecompressPointer r4
    //     0xef7cd4: add             x4, x4, HEAP, lsl #32
    // 0xef7cd8: stur            x4, [fp, #-0x18]
    // 0xef7cdc: r0 = LoadClassIdInstr(r3)
    //     0xef7cdc: ldur            x0, [x3, #-1]
    //     0xef7ce0: ubfx            x0, x0, #0xc, #0x14
    // 0xef7ce4: stp             x4, x3, [SP]
    // 0xef7ce8: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xef7ce8: sub             lr, x0, #0xdfd
    //     0xef7cec: ldr             lr, [x21, lr, lsl #3]
    //     0xef7cf0: blr             lr
    // 0xef7cf4: mov             x1, x0
    // 0xef7cf8: ldur            x0, [fp, #-0x20]
    // 0xef7cfc: r2 = LoadClassIdInstr(r0)
    //     0xef7cfc: ldur            x2, [x0, #-1]
    //     0xef7d00: ubfx            x2, x2, #0xc, #0x14
    // 0xef7d04: ldur            x16, [fp, #-8]
    // 0xef7d08: stp             x16, x0, [SP, #8]
    // 0xef7d0c: str             x1, [SP]
    // 0xef7d10: mov             x0, x2
    // 0xef7d14: r0 = GDT[cid_x0 + 0x18dc8]()
    //     0xef7d14: mov             x17, #0x8dc8
    //     0xef7d18: movk            x17, #1, lsl #16
    //     0xef7d1c: add             lr, x0, x17
    //     0xef7d20: ldr             lr, [x21, lr, lsl #3]
    //     0xef7d24: blr             lr
    // 0xef7d28: ldur            x0, [fp, #-0x10]
    // 0xef7d2c: LoadField: r1 = r0->field_f
    //     0xef7d2c: ldur            w1, [x0, #0xf]
    // 0xef7d30: DecompressPointer r1
    //     0xef7d30: add             x1, x1, HEAP, lsl #32
    // 0xef7d34: LoadField: r0 = r1->field_1b
    //     0xef7d34: ldur            w0, [x1, #0x1b]
    // 0xef7d38: DecompressPointer r0
    //     0xef7d38: add             x0, x0, HEAP, lsl #32
    // 0xef7d3c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef7d40: cmp             w0, w16
    // 0xef7d44: b.eq            #0xef7db4
    // 0xef7d48: r1 = LoadClassIdInstr(r0)
    //     0xef7d48: ldur            x1, [x0, #-1]
    //     0xef7d4c: ubfx            x1, x1, #0xc, #0x14
    // 0xef7d50: ldur            x16, [fp, #-0x18]
    // 0xef7d54: stp             x16, x0, [SP, #8]
    // 0xef7d58: ldur            x16, [fp, #-0x28]
    // 0xef7d5c: str             x16, [SP]
    // 0xef7d60: mov             x0, x1
    // 0xef7d64: r0 = GDT[cid_x0 + 0x18dc8]()
    //     0xef7d64: mov             x17, #0x8dc8
    //     0xef7d68: movk            x17, #1, lsl #16
    //     0xef7d6c: add             lr, x0, x17
    //     0xef7d70: ldr             lr, [x21, lr, lsl #3]
    //     0xef7d74: blr             lr
    // 0xef7d78: r0 = Null
    //     0xef7d78: mov             x0, NULL
    // 0xef7d7c: LeaveFrame
    //     0xef7d7c: mov             SP, fp
    //     0xef7d80: ldp             fp, lr, [SP], #0x10
    // 0xef7d84: ret
    //     0xef7d84: ret             
    // 0xef7d88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef7d88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef7d8c: b               #0xef7c18
    // 0xef7d90: r9 = _childrenWithKey
    //     0xef7d90: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8c770] Field <_TabBarViewState@780014024._childrenWithKey@780014024>: late (offset: 0x1c)
    //     0xef7d94: ldr             x9, [x9, #0x770]
    // 0xef7d98: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef7d98: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xef7d9c: r9 = _childrenWithKey
    //     0xef7d9c: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8c770] Field <_TabBarViewState@780014024._childrenWithKey@780014024>: late (offset: 0x1c)
    //     0xef7da0: ldr             x9, [x9, #0x770]
    // 0xef7da4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef7da4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xef7da8: r9 = _childrenWithKey
    //     0xef7da8: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8c770] Field <_TabBarViewState@780014024._childrenWithKey@780014024>: late (offset: 0x1c)
    //     0xef7dac: ldr             x9, [x9, #0x770]
    // 0xef7db0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef7db0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xef7db4: r9 = _childrenWithKey
    //     0xef7db4: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8c770] Field <_TabBarViewState@780014024._childrenWithKey@780014024>: late (offset: 0x1c)
    //     0xef7db8: ldr             x9, [x9, #0x770]
    // 0xef7dbc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef7dbc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _warpToAdjacentTab(/* No info */) async {
    // ** addr: 0xef7dc0, size: 0xfc
    // 0xef7dc0: EnterFrame
    //     0xef7dc0: stp             fp, lr, [SP, #-0x10]!
    //     0xef7dc4: mov             fp, SP
    // 0xef7dc8: AllocStack(0x20)
    //     0xef7dc8: sub             SP, SP, #0x20
    // 0xef7dcc: SetupParameters(_TabBarViewState this /* r1 => r1, fp-0x10 */)
    //     0xef7dcc: stur            NULL, [fp, #-8]
    //     0xef7dd0: stur            x1, [fp, #-0x10]
    // 0xef7dd4: CheckStackOverflow
    //     0xef7dd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef7dd8: cmp             SP, x16
    //     0xef7ddc: b.ls            #0xef7eb0
    // 0xef7de0: r1 = 1
    //     0xef7de0: mov             x1, #1
    // 0xef7de4: r0 = AllocateContext()
    //     0xef7de4: bl              #0x13de838  ; AllocateContextStub
    // 0xef7de8: mov             x2, x0
    // 0xef7dec: ldur            x1, [fp, #-0x10]
    // 0xef7df0: stur            x2, [fp, #-0x18]
    // 0xef7df4: StoreField: r2->field_f = r1
    //     0xef7df4: stur            w1, [x2, #0xf]
    // 0xef7df8: InitAsync() -> Future<void?>
    //     0xef7df8: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xef7dfc: bl              #0x7f5e44  ; InitAsyncStub
    // 0xef7e00: ldur            x0, [fp, #-0x10]
    // 0xef7e04: LoadField: r1 = r0->field_1f
    //     0xef7e04: ldur            w1, [x0, #0x1f]
    // 0xef7e08: DecompressPointer r1
    //     0xef7e08: add             x1, x1, HEAP, lsl #32
    // 0xef7e0c: cmp             w1, NULL
    // 0xef7e10: b.eq            #0xef7eb8
    // 0xef7e14: r2 = LoadInt32Instr(r1)
    //     0xef7e14: sbfx            x2, x1, #1, #0x1f
    //     0xef7e18: tbz             w1, #0, #0xef7e20
    //     0xef7e1c: ldur            x2, [x1, #7]
    // 0xef7e20: mov             x1, x0
    // 0xef7e24: r0 = _animateToPage()
    //     0xef7e24: bl              #0xef759c  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_animateToPage
    // 0xef7e28: mov             x1, x0
    // 0xef7e2c: stur            x1, [fp, #-0x20]
    // 0xef7e30: r0 = Await()
    //     0xef7e30: bl              #0x7f5c00  ; AwaitStub
    // 0xef7e34: ldur            x0, [fp, #-0x10]
    // 0xef7e38: LoadField: r1 = r0->field_f
    //     0xef7e38: ldur            w1, [x0, #0xf]
    // 0xef7e3c: DecompressPointer r1
    //     0xef7e3c: add             x1, x1, HEAP, lsl #32
    // 0xef7e40: cmp             w1, NULL
    // 0xef7e44: b.eq            #0xef7e64
    // 0xef7e48: ldur            x2, [fp, #-0x18]
    // 0xef7e4c: r1 = Function '<anonymous closure>':.
    //     0xef7e4c: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c830] AnonymousClosure: (0xef7690), in [package:flutter/src/material/tabs.dart] _TabBarViewState::_warpToNonAdjacentTab (0xef73f4)
    //     0xef7e50: ldr             x1, [x1, #0x830]
    // 0xef7e54: r0 = AllocateClosure()
    //     0xef7e54: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef7e58: ldur            x1, [fp, #-0x10]
    // 0xef7e5c: mov             x2, x0
    // 0xef7e60: r0 = setState()
    //     0xef7e60: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xef7e64: r1 = <void?>
    //     0xef7e64: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xef7e68: r0 = _Future()
    //     0xef7e68: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xef7e6c: stur            x0, [fp, #-0x10]
    // 0xef7e70: StoreField: r0->field_b = rZR
    //     0xef7e70: stur            xzr, [x0, #0xb]
    // 0xef7e74: r0 = LoadStaticField(0x364)
    //     0xef7e74: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xef7e78: ldr             x0, [x0, #0x6c8]
    // 0xef7e7c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef7e80: cmp             w0, w16
    // 0xef7e84: b.ne            #0xef7e90
    // 0xef7e88: r2 = _current
    //     0xef7e88: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0xef7e8c: r0 = InitLateStaticField()
    //     0xef7e8c: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xef7e90: mov             x1, x0
    // 0xef7e94: ldur            x0, [fp, #-0x10]
    // 0xef7e98: StoreField: r0->field_13 = r1
    //     0xef7e98: stur            w1, [x0, #0x13]
    // 0xef7e9c: mov             x1, x0
    // 0xef7ea0: r2 = Null
    //     0xef7ea0: mov             x2, NULL
    // 0xef7ea4: r0 = _asyncComplete()
    //     0xef7ea4: bl              #0x7eee44  ; [dart:async] _Future::_asyncComplete
    // 0xef7ea8: ldur            x0, [fp, #-0x10]
    // 0xef7eac: r0 = ReturnAsync()
    //     0xef7eac: b               #0x82fdf0  ; ReturnAsyncStub
    // 0xef7eb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef7eb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef7eb4: b               #0xef7de0
    // 0xef7eb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef7eb8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf6f348, size: 0x260
    // 0xf6f348: EnterFrame
    //     0xf6f348: stp             fp, lr, [SP, #-0x10]!
    //     0xf6f34c: mov             fp, SP
    // 0xf6f350: AllocStack(0x20)
    //     0xf6f350: sub             SP, SP, #0x20
    // 0xf6f354: SetupParameters(_TabBarViewState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf6f354: mov             x4, x1
    //     0xf6f358: mov             x3, x2
    //     0xf6f35c: stur            x1, [fp, #-8]
    //     0xf6f360: stur            x2, [fp, #-0x10]
    // 0xf6f364: CheckStackOverflow
    //     0xf6f364: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6f368: cmp             SP, x16
    //     0xf6f36c: b.ls            #0xf6f588
    // 0xf6f370: mov             x0, x3
    // 0xf6f374: r2 = Null
    //     0xf6f374: mov             x2, NULL
    // 0xf6f378: r1 = Null
    //     0xf6f378: mov             x1, NULL
    // 0xf6f37c: r4 = 60
    //     0xf6f37c: mov             x4, #0x3c
    // 0xf6f380: branchIfSmi(r0, 0xf6f38c)
    //     0xf6f380: tbz             w0, #0, #0xf6f38c
    // 0xf6f384: r4 = LoadClassIdInstr(r0)
    //     0xf6f384: ldur            x4, [x0, #-1]
    //     0xf6f388: ubfx            x4, x4, #0xc, #0x14
    // 0xf6f38c: r17 = 6415
    //     0xf6f38c: mov             x17, #0x190f
    // 0xf6f390: cmp             x4, x17
    // 0xf6f394: b.eq            #0xf6f3ac
    // 0xf6f398: r8 = TabBarView
    //     0xf6f398: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8c838] Type: TabBarView
    //     0xf6f39c: ldr             x8, [x8, #0x838]
    // 0xf6f3a0: r3 = Null
    //     0xf6f3a0: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c840] Null
    //     0xf6f3a4: ldr             x3, [x3, #0x840]
    // 0xf6f3a8: r0 = TabBarView()
    //     0xf6f3a8: bl              #0xe00ed8  ; IsType_TabBarView_Stub
    // 0xf6f3ac: ldur            x3, [fp, #-8]
    // 0xf6f3b0: LoadField: r2 = r3->field_7
    //     0xf6f3b0: ldur            w2, [x3, #7]
    // 0xf6f3b4: DecompressPointer r2
    //     0xf6f3b4: add             x2, x2, HEAP, lsl #32
    // 0xf6f3b8: ldur            x0, [fp, #-0x10]
    // 0xf6f3bc: r1 = Null
    //     0xf6f3bc: mov             x1, NULL
    // 0xf6f3c0: cmp             w2, NULL
    // 0xf6f3c4: b.eq            #0xf6f3e8
    // 0xf6f3c8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6f3c8: ldur            w4, [x2, #0x17]
    // 0xf6f3cc: DecompressPointer r4
    //     0xf6f3cc: add             x4, x4, HEAP, lsl #32
    // 0xf6f3d0: r8 = X0 bound StatefulWidget
    //     0xf6f3d0: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf6f3d4: ldr             x8, [x8, #0x498]
    // 0xf6f3d8: LoadField: r9 = r4->field_7
    //     0xf6f3d8: ldur            x9, [x4, #7]
    // 0xf6f3dc: r3 = Null
    //     0xf6f3dc: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c850] Null
    //     0xf6f3e0: ldr             x3, [x3, #0x850]
    // 0xf6f3e4: blr             x9
    // 0xf6f3e8: ldur            x0, [fp, #-8]
    // 0xf6f3ec: LoadField: r1 = r0->field_b
    //     0xf6f3ec: ldur            w1, [x0, #0xb]
    // 0xf6f3f0: DecompressPointer r1
    //     0xf6f3f0: add             x1, x1, HEAP, lsl #32
    // 0xf6f3f4: cmp             w1, NULL
    // 0xf6f3f8: b.eq            #0xf6f590
    // 0xf6f3fc: LoadField: r2 = r1->field_b
    //     0xf6f3fc: ldur            w2, [x1, #0xb]
    // 0xf6f400: DecompressPointer r2
    //     0xf6f400: add             x2, x2, HEAP, lsl #32
    // 0xf6f404: ldur            x3, [fp, #-0x10]
    // 0xf6f408: LoadField: r1 = r3->field_b
    //     0xf6f408: ldur            w1, [x3, #0xb]
    // 0xf6f40c: DecompressPointer r1
    //     0xf6f40c: add             x1, x1, HEAP, lsl #32
    // 0xf6f410: cmp             w2, w1
    // 0xf6f414: b.eq            #0xf6f474
    // 0xf6f418: mov             x1, x0
    // 0xf6f41c: r0 = _updateTabController()
    //     0xf6f41c: bl              #0xef6fdc  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_updateTabController
    // 0xf6f420: ldur            x3, [fp, #-8]
    // 0xf6f424: LoadField: r0 = r3->field_13
    //     0xf6f424: ldur            w0, [x3, #0x13]
    // 0xf6f428: DecompressPointer r0
    //     0xf6f428: add             x0, x0, HEAP, lsl #32
    // 0xf6f42c: cmp             w0, NULL
    // 0xf6f430: b.eq            #0xf6f594
    // 0xf6f434: LoadField: r2 = r0->field_33
    //     0xf6f434: ldur            x2, [x0, #0x33]
    // 0xf6f438: r0 = BoxInt64Instr(r2)
    //     0xf6f438: sbfiz           x0, x2, #1, #0x1f
    //     0xf6f43c: cmp             x2, x0, asr #1
    //     0xf6f440: b.eq            #0xf6f44c
    //     0xf6f444: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xf6f448: stur            x2, [x0, #7]
    // 0xf6f44c: StoreField: r3->field_1f = r0
    //     0xf6f44c: stur            w0, [x3, #0x1f]
    //     0xf6f450: tbz             w0, #0, #0xf6f46c
    //     0xf6f454: ldurb           w16, [x3, #-1]
    //     0xf6f458: ldurb           w17, [x0, #-1]
    //     0xf6f45c: and             x16, x17, x16, lsr #2
    //     0xf6f460: tst             x16, HEAP, lsr #32
    //     0xf6f464: b.eq            #0xf6f46c
    //     0xf6f468: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf6f46c: mov             x1, x3
    // 0xf6f470: r0 = _jumpToPage()
    //     0xf6f470: bl              #0xef7624  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_jumpToPage
    // 0xf6f474: ldur            x0, [fp, #-8]
    // 0xf6f478: d0 = 1.000000
    //     0xf6f478: fmov            d0, #1.00000000
    // 0xf6f47c: LoadField: r1 = r0->field_b
    //     0xf6f47c: ldur            w1, [x0, #0xb]
    // 0xf6f480: DecompressPointer r1
    //     0xf6f480: add             x1, x1, HEAP, lsl #32
    // 0xf6f484: cmp             w1, NULL
    // 0xf6f488: b.eq            #0xf6f598
    // 0xf6f48c: fcmp            d0, d0
    // 0xf6f490: b.eq            #0xf6f53c
    // 0xf6f494: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf6f494: ldur            w1, [x0, #0x17]
    // 0xf6f498: DecompressPointer r1
    //     0xf6f498: add             x1, x1, HEAP, lsl #32
    // 0xf6f49c: cmp             w1, NULL
    // 0xf6f4a0: b.ne            #0xf6f4ac
    // 0xf6f4a4: mov             x1, x0
    // 0xf6f4a8: b               #0xf6f4b4
    // 0xf6f4ac: r0 = dispose()
    //     0xf6f4ac: bl              #0x10ef540  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0xf6f4b0: ldur            x1, [fp, #-8]
    // 0xf6f4b4: LoadField: r0 = r1->field_1f
    //     0xf6f4b4: ldur            w0, [x1, #0x1f]
    // 0xf6f4b8: DecompressPointer r0
    //     0xf6f4b8: add             x0, x0, HEAP, lsl #32
    // 0xf6f4bc: cmp             w0, NULL
    // 0xf6f4c0: b.eq            #0xf6f59c
    // 0xf6f4c4: LoadField: r2 = r1->field_b
    //     0xf6f4c4: ldur            w2, [x1, #0xb]
    // 0xf6f4c8: DecompressPointer r2
    //     0xf6f4c8: add             x2, x2, HEAP, lsl #32
    // 0xf6f4cc: cmp             w2, NULL
    // 0xf6f4d0: b.eq            #0xf6f5a0
    // 0xf6f4d4: r2 = LoadInt32Instr(r0)
    //     0xf6f4d4: sbfx            x2, x0, #1, #0x1f
    //     0xf6f4d8: tbz             w0, #0, #0xf6f4e0
    //     0xf6f4dc: ldur            x2, [x0, #7]
    // 0xf6f4e0: stur            x2, [fp, #-0x18]
    // 0xf6f4e4: r0 = PageController()
    //     0xf6f4e4: bl              #0xef6fd0  ; AllocatePageControllerStub -> PageController (size=0x54)
    // 0xf6f4e8: mov             x2, x0
    // 0xf6f4ec: ldur            x0, [fp, #-0x18]
    // 0xf6f4f0: stur            x2, [fp, #-0x20]
    // 0xf6f4f4: StoreField: r2->field_3f = r0
    //     0xf6f4f4: stur            x0, [x2, #0x3f]
    // 0xf6f4f8: r0 = true
    //     0xf6f4f8: add             x0, NULL, #0x20  ; true
    // 0xf6f4fc: StoreField: r2->field_47 = r0
    //     0xf6f4fc: stur            w0, [x2, #0x47]
    // 0xf6f500: d0 = 1.000000
    //     0xf6f500: fmov            d0, #1.00000000
    // 0xf6f504: StoreField: r2->field_4b = d0
    //     0xf6f504: stur            d0, [x2, #0x4b]
    // 0xf6f508: mov             x1, x2
    // 0xf6f50c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf6f50c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf6f510: r0 = ScrollController()
    //     0xf6f510: bl              #0x86d884  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0xf6f514: ldur            x0, [fp, #-0x20]
    // 0xf6f518: ldur            x1, [fp, #-8]
    // 0xf6f51c: ArrayStore: r1[0] = r0  ; List_4
    //     0xf6f51c: stur            w0, [x1, #0x17]
    //     0xf6f520: ldurb           w16, [x1, #-1]
    //     0xf6f524: ldurb           w17, [x0, #-1]
    //     0xf6f528: and             x16, x17, x16, lsr #2
    //     0xf6f52c: tst             x16, HEAP, lsr #32
    //     0xf6f530: b.eq            #0xf6f538
    //     0xf6f534: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf6f538: b               #0xf6f540
    // 0xf6f53c: mov             x1, x0
    // 0xf6f540: ldur            x0, [fp, #-0x10]
    // 0xf6f544: LoadField: r2 = r1->field_b
    //     0xf6f544: ldur            w2, [x1, #0xb]
    // 0xf6f548: DecompressPointer r2
    //     0xf6f548: add             x2, x2, HEAP, lsl #32
    // 0xf6f54c: cmp             w2, NULL
    // 0xf6f550: b.eq            #0xf6f5a4
    // 0xf6f554: LoadField: r3 = r2->field_f
    //     0xf6f554: ldur            w3, [x2, #0xf]
    // 0xf6f558: DecompressPointer r3
    //     0xf6f558: add             x3, x3, HEAP, lsl #32
    // 0xf6f55c: LoadField: r2 = r0->field_f
    //     0xf6f55c: ldur            w2, [x0, #0xf]
    // 0xf6f560: DecompressPointer r2
    //     0xf6f560: add             x2, x2, HEAP, lsl #32
    // 0xf6f564: cmp             w3, w2
    // 0xf6f568: b.eq            #0xf6f578
    // 0xf6f56c: LoadField: r0 = r1->field_23
    //     0xf6f56c: ldur            x0, [x1, #0x23]
    // 0xf6f570: cbnz            x0, #0xf6f578
    // 0xf6f574: r0 = _updateChildren()
    //     0xf6f574: bl              #0xef76d8  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_updateChildren
    // 0xf6f578: r0 = Null
    //     0xf6f578: mov             x0, NULL
    // 0xf6f57c: LeaveFrame
    //     0xf6f57c: mov             SP, fp
    //     0xf6f580: ldp             fp, lr, [SP], #0x10
    // 0xf6f584: ret
    //     0xf6f584: ret             
    // 0xf6f588: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6f588: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6f58c: b               #0xf6f370
    // 0xf6f590: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6f590: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6f594: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6f594: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6f598: r0 = NullCastErrorSharedWithFPURegs()
    //     0xf6f598: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xf6f59c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6f59c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6f5a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6f5a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6f5a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6f5a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf91608, size: 0x30
    // 0xf91608: EnterFrame
    //     0xf91608: stp             fp, lr, [SP, #-0x10]!
    //     0xf9160c: mov             fp, SP
    // 0xf91610: CheckStackOverflow
    //     0xf91610: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf91614: cmp             SP, x16
    //     0xf91618: b.ls            #0xf91630
    // 0xf9161c: r0 = _updateChildren()
    //     0xf9161c: bl              #0xef76d8  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_updateChildren
    // 0xf91620: r0 = Null
    //     0xf91620: mov             x0, NULL
    // 0xf91624: LeaveFrame
    //     0xf91624: mov             SP, fp
    //     0xf91628: ldp             fp, lr, [SP], #0x10
    // 0xf9162c: ret
    //     0xf9162c: ret             
    // 0xf91630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf91630: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf91634: b               #0xf9161c
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e6210, size: 0xc0
    // 0x10e6210: EnterFrame
    //     0x10e6210: stp             fp, lr, [SP, #-0x10]!
    //     0x10e6214: mov             fp, SP
    // 0x10e6218: AllocStack(0x10)
    //     0x10e6218: sub             SP, SP, #0x10
    // 0x10e621c: SetupParameters(_TabBarViewState this /* r1 => r0, fp-0x8 */)
    //     0x10e621c: mov             x0, x1
    //     0x10e6220: stur            x1, [fp, #-8]
    // 0x10e6224: CheckStackOverflow
    //     0x10e6224: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e6228: cmp             SP, x16
    //     0x10e622c: b.ls            #0x10e62c0
    // 0x10e6230: mov             x1, x0
    // 0x10e6234: r0 = _controllerIsValid()
    //     0x10e6234: bl              #0xe01810  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_controllerIsValid
    // 0x10e6238: tbnz            w0, #4, #0x10e6294
    // 0x10e623c: ldur            x0, [fp, #-8]
    // 0x10e6240: LoadField: r1 = r0->field_13
    //     0x10e6240: ldur            w1, [x0, #0x13]
    // 0x10e6244: DecompressPointer r1
    //     0x10e6244: add             x1, x1, HEAP, lsl #32
    // 0x10e6248: cmp             w1, NULL
    // 0x10e624c: b.eq            #0x10e62c8
    // 0x10e6250: LoadField: r2 = r1->field_23
    //     0x10e6250: ldur            w2, [x1, #0x23]
    // 0x10e6254: DecompressPointer r2
    //     0x10e6254: add             x2, x2, HEAP, lsl #32
    // 0x10e6258: cmp             w2, NULL
    // 0x10e625c: b.ne            #0x10e6268
    // 0x10e6260: r3 = Null
    //     0x10e6260: mov             x3, NULL
    // 0x10e6264: b               #0x10e626c
    // 0x10e6268: mov             x3, x2
    // 0x10e626c: stur            x3, [fp, #-0x10]
    // 0x10e6270: cmp             w3, NULL
    // 0x10e6274: b.eq            #0x10e62cc
    // 0x10e6278: mov             x2, x0
    // 0x10e627c: r1 = Function '_handleTabControllerAnimationTick@780014024':.
    //     0x10e627c: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c7a8] AnonymousClosure: (0xef7154), in [package:flutter/src/material/tabs.dart] _TabBarViewState::_handleTabControllerAnimationTick (0xef718c)
    //     0x10e6280: ldr             x1, [x1, #0x7a8]
    // 0x10e6284: r0 = AllocateClosure()
    //     0x10e6284: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e6288: ldur            x1, [fp, #-0x10]
    // 0x10e628c: mov             x2, x0
    // 0x10e6290: r0 = removeListener()
    //     0x10e6290: bl              #0xd00c74  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::removeListener
    // 0x10e6294: ldur            x0, [fp, #-8]
    // 0x10e6298: StoreField: r0->field_13 = rNULL
    //     0x10e6298: stur            NULL, [x0, #0x13]
    // 0x10e629c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10e629c: ldur            w1, [x0, #0x17]
    // 0x10e62a0: DecompressPointer r1
    //     0x10e62a0: add             x1, x1, HEAP, lsl #32
    // 0x10e62a4: cmp             w1, NULL
    // 0x10e62a8: b.eq            #0x10e62b0
    // 0x10e62ac: r0 = dispose()
    //     0x10e62ac: bl              #0x10ef540  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0x10e62b0: r0 = Null
    //     0x10e62b0: mov             x0, NULL
    // 0x10e62b4: LeaveFrame
    //     0x10e62b4: mov             SP, fp
    //     0x10e62b8: ldp             fp, lr, [SP], #0x10
    // 0x10e62bc: ret
    //     0x10e62bc: ret             
    // 0x10e62c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e62c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e62c4: b               #0x10e6230
    // 0x10e62c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e62c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10e62cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e62cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5454, size: 0x2c, field offset: 0x14
class _TabBarState extends State<dynamic> {

  late List<EdgeInsetsGeometry> _labelPaddings; // offset: 0x28
  late List<GlobalKey<State<StatefulWidget>>> _tabKeys; // offset: 0x24

  [closure] GlobalKey<State<StatefulWidget>> <anonymous closure>(dynamic, Widget) {
    // ** addr: 0x8d1604, size: 0x1c
    // 0x8d1604: EnterFrame
    //     0x8d1604: stp             fp, lr, [SP, #-0x10]!
    //     0x8d1608: mov             fp, SP
    // 0x8d160c: r1 = <State<StatefulWidget>>
    //     0x8d160c: ldr             x1, [PP, #0x4df8]  ; [pp+0x4df8] TypeArguments: <State<StatefulWidget>>
    // 0x8d1610: r0 = LabeledGlobalKey()
    //     0x8d1610: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0x8d1614: LeaveFrame
    //     0x8d1614: mov             SP, fp
    //     0x8d1618: ldp             fp, lr, [SP], #0x10
    // 0x8d161c: ret
    //     0x8d161c: ret             
  }
  [closure] void _saveTabOffsets(dynamic, List<double>, TextDirection, double) {
    // ** addr: 0xbbf45c, size: 0x44
    // 0xbbf45c: EnterFrame
    //     0xbbf45c: stp             fp, lr, [SP, #-0x10]!
    //     0xbbf460: mov             fp, SP
    // 0xbbf464: ldr             x0, [fp, #0x28]
    // 0xbbf468: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbbf468: ldur            w1, [x0, #0x17]
    // 0xbbf46c: DecompressPointer r1
    //     0xbbf46c: add             x1, x1, HEAP, lsl #32
    // 0xbbf470: CheckStackOverflow
    //     0xbbf470: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbf474: cmp             SP, x16
    //     0xbbf478: b.ls            #0xbbf498
    // 0xbbf47c: ldr             x2, [fp, #0x20]
    // 0xbbf480: ldr             x3, [fp, #0x18]
    // 0xbbf484: ldr             x5, [fp, #0x10]
    // 0xbbf488: r0 = _saveTabOffsets()
    //     0xbbf488: bl              #0xbbf4a0  ; [package:flutter/src/material/tabs.dart] _TabBarState::_saveTabOffsets
    // 0xbbf48c: LeaveFrame
    //     0xbbf48c: mov             SP, fp
    //     0xbbf490: ldp             fp, lr, [SP], #0x10
    // 0xbbf494: ret
    //     0xbbf494: ret             
    // 0xbbf498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbf498: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbf49c: b               #0xbbf47c
  }
  _ _saveTabOffsets(/* No info */) {
    // ** addr: 0xbbf4a0, size: 0x44
    // 0xbbf4a0: EnterFrame
    //     0xbbf4a0: stp             fp, lr, [SP, #-0x10]!
    //     0xbbf4a4: mov             fp, SP
    // 0xbbf4a8: CheckStackOverflow
    //     0xbbf4a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbf4ac: cmp             SP, x16
    //     0xbbf4b0: b.ls            #0xbbf4dc
    // 0xbbf4b4: LoadField: r0 = r1->field_1b
    //     0xbbf4b4: ldur            w0, [x1, #0x1b]
    // 0xbbf4b8: DecompressPointer r0
    //     0xbbf4b8: add             x0, x0, HEAP, lsl #32
    // 0xbbf4bc: cmp             w0, NULL
    // 0xbbf4c0: b.eq            #0xbbf4cc
    // 0xbbf4c4: mov             x1, x0
    // 0xbbf4c8: r0 = saveTabOffsets()
    //     0xbbf4c8: bl              #0xbbf4e4  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::saveTabOffsets
    // 0xbbf4cc: r0 = Null
    //     0xbbf4cc: mov             x0, NULL
    // 0xbbf4d0: LeaveFrame
    //     0xbbf4d0: mov             SP, fp
    //     0xbbf4d4: ldp             fp, lr, [SP], #0x10
    // 0xbbf4d8: ret
    //     0xbbf4d8: ret             
    // 0xbbf4dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbf4dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbf4e0: b               #0xbbf4b4
  }
  _ build(/* No info */) {
    // ** addr: 0xdfe5b0, size: 0x145c
    // 0xdfe5b0: EnterFrame
    //     0xdfe5b0: stp             fp, lr, [SP, #-0x10]!
    //     0xdfe5b4: mov             fp, SP
    // 0xdfe5b8: AllocStack(0x1e0)
    //     0xdfe5b8: sub             SP, SP, #0x1e0
    // 0xdfe5bc: SetupParameters(_TabBarState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xdfe5bc: mov             x0, x1
    //     0xdfe5c0: stur            x1, [fp, #-8]
    //     0xdfe5c4: mov             x1, x2
    //     0xdfe5c8: stur            x2, [fp, #-0x10]
    // 0xdfe5cc: CheckStackOverflow
    //     0xdfe5cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfe5d0: cmp             SP, x16
    //     0xdfe5d4: b.ls            #0xdff970
    // 0xdfe5d8: r1 = 2
    //     0xdfe5d8: mov             x1, #2
    // 0xdfe5dc: r0 = AllocateContext()
    //     0xdfe5dc: bl              #0x13de838  ; AllocateContextStub
    // 0xdfe5e0: mov             x2, x0
    // 0xdfe5e4: ldur            x0, [fp, #-8]
    // 0xdfe5e8: stur            x2, [fp, #-0x18]
    // 0xdfe5ec: StoreField: r2->field_f = r0
    //     0xdfe5ec: stur            w0, [x2, #0xf]
    // 0xdfe5f0: ldur            x1, [fp, #-0x10]
    // 0xdfe5f4: r0 = of()
    //     0xdfe5f4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdfe5f8: ldur            x1, [fp, #-0x10]
    // 0xdfe5fc: r0 = of()
    //     0xdfe5fc: bl              #0xdffc38  ; [package:flutter/src/material/tab_bar_theme.dart] TabBarTheme::of
    // 0xdfe600: ldur            x2, [fp, #-0x18]
    // 0xdfe604: StoreField: r2->field_13 = r0
    //     0xdfe604: stur            w0, [x2, #0x13]
    //     0xdfe608: ldurb           w16, [x2, #-1]
    //     0xdfe60c: ldurb           w17, [x0, #-1]
    //     0xdfe610: and             x16, x17, x16, lsr #2
    //     0xdfe614: tst             x16, HEAP, lsr #32
    //     0xdfe618: b.eq            #0xdfe620
    //     0xdfe61c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xdfe620: ldur            x0, [fp, #-8]
    // 0xdfe624: LoadField: r1 = r0->field_b
    //     0xdfe624: ldur            w1, [x0, #0xb]
    // 0xdfe628: DecompressPointer r1
    //     0xdfe628: add             x1, x1, HEAP, lsl #32
    // 0xdfe62c: cmp             w1, NULL
    // 0xdfe630: b.eq            #0xdff978
    // 0xdfe634: LoadField: r3 = r1->field_77
    //     0xdfe634: ldur            w3, [x1, #0x77]
    // 0xdfe638: DecompressPointer r3
    //     0xdfe638: add             x3, x3, HEAP, lsl #32
    // 0xdfe63c: cmp             w3, NULL
    // 0xdfe640: b.ne            #0xdfe64c
    // 0xdfe644: r1 = Null
    //     0xdfe644: mov             x1, NULL
    // 0xdfe648: b               #0xdfe650
    // 0xdfe64c: mov             x1, x3
    // 0xdfe650: cmp             w1, NULL
    // 0xdfe654: b.ne            #0xdfe68c
    // 0xdfe658: mov             x1, x0
    // 0xdfe65c: r0 = _defaults()
    //     0xdfe65c: bl              #0xdffaf8  ; [package:flutter/src/material/tabs.dart] _TabBarState::_defaults
    // 0xdfe660: r1 = LoadClassIdInstr(r0)
    //     0xdfe660: ldur            x1, [x0, #-1]
    //     0xdfe664: ubfx            x1, x1, #0xc, #0x14
    // 0xdfe668: r17 = 5058
    //     0xdfe668: mov             x17, #0x13c2
    // 0xdfe66c: cmp             x1, x17
    // 0xdfe670: b.eq            #0xdfe680
    // 0xdfe674: r17 = 5059
    //     0xdfe674: mov             x17, #0x13c3
    // 0xdfe678: cmp             x1, x17
    // 0xdfe67c: b.eq            #0xdfe680
    // 0xdfe680: r2 = Instance_TabAlignment
    //     0xdfe680: add             x2, PP, #0x26, lsl #12  ; [pp+0x260e8] Obj!TabAlignment@12c4c81
    //     0xdfe684: ldr             x2, [x2, #0xe8]
    // 0xdfe688: b               #0xdfe690
    // 0xdfe68c: mov             x2, x1
    // 0xdfe690: ldur            x0, [fp, #-8]
    // 0xdfe694: ldur            x1, [fp, #-0x10]
    // 0xdfe698: stur            x2, [fp, #-0x20]
    // 0xdfe69c: r0 = of()
    //     0xdfe69c: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xdfe6a0: mov             x3, x0
    // 0xdfe6a4: ldur            x0, [fp, #-8]
    // 0xdfe6a8: stur            x3, [fp, #-0x30]
    // 0xdfe6ac: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdfe6ac: ldur            w1, [x0, #0x17]
    // 0xdfe6b0: DecompressPointer r1
    //     0xdfe6b0: add             x1, x1, HEAP, lsl #32
    // 0xdfe6b4: cmp             w1, NULL
    // 0xdfe6b8: b.eq            #0xdff97c
    // 0xdfe6bc: LoadField: r2 = r1->field_2b
    //     0xdfe6bc: ldur            x2, [x1, #0x2b]
    // 0xdfe6c0: cbnz            x2, #0xdfe71c
    // 0xdfe6c4: LoadField: r1 = r0->field_b
    //     0xdfe6c4: ldur            w1, [x0, #0xb]
    // 0xdfe6c8: DecompressPointer r1
    //     0xdfe6c8: add             x1, x1, HEAP, lsl #32
    // 0xdfe6cc: cmp             w1, NULL
    // 0xdfe6d0: b.eq            #0xdff980
    // 0xdfe6d4: r0 = SizedBox()
    //     0xdfe6d4: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xdfe6d8: mov             x1, x0
    // 0xdfe6dc: r0 = inf
    //     0xdfe6dc: add             x0, PP, #0x15, lsl #12  ; [pp+0x158a8] inf
    //     0xdfe6e0: ldr             x0, [x0, #0x8a8]
    // 0xdfe6e4: stur            x1, [fp, #-0x28]
    // 0xdfe6e8: StoreField: r1->field_f = r0
    //     0xdfe6e8: stur            w0, [x1, #0xf]
    // 0xdfe6ec: r0 = 48.000000
    //     0xdfe6ec: add             x0, PP, #0x15, lsl #12  ; [pp+0x158d0] 48
    //     0xdfe6f0: ldr             x0, [x0, #0x8d0]
    // 0xdfe6f4: StoreField: r1->field_13 = r0
    //     0xdfe6f4: stur            w0, [x1, #0x13]
    // 0xdfe6f8: r0 = LimitedBox()
    //     0xdfe6f8: bl              #0xd1a978  ; AllocateLimitedBoxStub -> LimitedBox (size=0x20)
    // 0xdfe6fc: StoreField: r0->field_f = rZR
    //     0xdfe6fc: stur            xzr, [x0, #0xf]
    // 0xdfe700: d0 = inf
    //     0xdfe700: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xdfe704: ArrayStore: r0[0] = d0  ; List_8
    //     0xdfe704: stur            d0, [x0, #0x17]
    // 0xdfe708: ldur            x1, [fp, #-0x28]
    // 0xdfe70c: StoreField: r0->field_b = r1
    //     0xdfe70c: stur            w1, [x0, #0xb]
    // 0xdfe710: LeaveFrame
    //     0xdfe710: mov             SP, fp
    //     0xdfe714: ldp             fp, lr, [SP], #0x10
    // 0xdfe718: ret
    //     0xdfe718: ret             
    // 0xdfe71c: LoadField: r1 = r0->field_b
    //     0xdfe71c: ldur            w1, [x0, #0xb]
    // 0xdfe720: DecompressPointer r1
    //     0xdfe720: add             x1, x1, HEAP, lsl #32
    // 0xdfe724: cmp             w1, NULL
    // 0xdfe728: b.eq            #0xdff984
    // 0xdfe72c: LoadField: r2 = r1->field_b
    //     0xdfe72c: ldur            w2, [x1, #0xb]
    // 0xdfe730: DecompressPointer r2
    //     0xdfe730: add             x2, x2, HEAP, lsl #32
    // 0xdfe734: LoadField: r4 = r2->field_b
    //     0xdfe734: ldur            w4, [x2, #0xb]
    // 0xdfe738: ldur            x2, [fp, #-0x18]
    // 0xdfe73c: stur            x4, [fp, #-0x28]
    // 0xdfe740: r1 = Function '<anonymous closure>':.
    //     0xdfe740: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c5a8] AnonymousClosure: (0xe008cc), in [package:flutter/src/material/tabs.dart] _TabBarState::build (0xdfe5b0)
    //     0xdfe744: ldr             x1, [x1, #0x5a8]
    // 0xdfe748: r0 = AllocateClosure()
    //     0xdfe748: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfe74c: mov             x3, x0
    // 0xdfe750: ldur            x0, [fp, #-0x28]
    // 0xdfe754: stur            x3, [fp, #-0x38]
    // 0xdfe758: r2 = LoadInt32Instr(r0)
    //     0xdfe758: sbfx            x2, x0, #1, #0x1f
    // 0xdfe75c: r1 = <Widget>
    //     0xdfe75c: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdfe760: r0 = _GrowableList()
    //     0xdfe760: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xdfe764: mov             x1, x0
    // 0xdfe768: stur            x1, [fp, #-0x28]
    // 0xdfe76c: r2 = 0
    //     0xdfe76c: mov             x2, #0
    // 0xdfe770: stur            x2, [fp, #-0x40]
    // 0xdfe774: CheckStackOverflow
    //     0xdfe774: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfe778: cmp             SP, x16
    //     0xdfe77c: b.ls            #0xdff988
    // 0xdfe780: LoadField: r0 = r1->field_b
    //     0xdfe780: ldur            w0, [x1, #0xb]
    // 0xdfe784: r3 = LoadInt32Instr(r0)
    //     0xdfe784: sbfx            x3, x0, #1, #0x1f
    // 0xdfe788: stur            x3, [fp, #-0x50]
    // 0xdfe78c: cmp             x2, x3
    // 0xdfe790: b.ge            #0xdfe858
    // 0xdfe794: lsl             x0, x2, #1
    // 0xdfe798: ldur            x16, [fp, #-0x38]
    // 0xdfe79c: stp             x0, x16, [SP]
    // 0xdfe7a0: ldur            x0, [fp, #-0x38]
    // 0xdfe7a4: ClosureCall
    //     0xdfe7a4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xdfe7a8: ldur            x2, [x0, #0x1f]
    //     0xdfe7ac: blr             x2
    // 0xdfe7b0: mov             x3, x0
    // 0xdfe7b4: r2 = Null
    //     0xdfe7b4: mov             x2, NULL
    // 0xdfe7b8: r1 = Null
    //     0xdfe7b8: mov             x1, NULL
    // 0xdfe7bc: stur            x3, [fp, #-0x48]
    // 0xdfe7c0: r4 = 60
    //     0xdfe7c0: mov             x4, #0x3c
    // 0xdfe7c4: branchIfSmi(r0, 0xdfe7d0)
    //     0xdfe7c4: tbz             w0, #0, #0xdfe7d0
    // 0xdfe7c8: r4 = LoadClassIdInstr(r0)
    //     0xdfe7c8: ldur            x4, [x0, #-1]
    //     0xdfe7cc: ubfx            x4, x4, #0xc, #0x14
    // 0xdfe7d0: r17 = -5846
    //     0xdfe7d0: mov             x17, #-0x16d6
    // 0xdfe7d4: add             x4, x4, x17
    // 0xdfe7d8: cmp             x4, #0x3f6
    // 0xdfe7dc: b.ls            #0xdfe7f4
    // 0xdfe7e0: r8 = Widget
    //     0xdfe7e0: add             x8, PP, #0x1e, lsl #12  ; [pp+0x1e5f0] Type: Widget
    //     0xdfe7e4: ldr             x8, [x8, #0x5f0]
    // 0xdfe7e8: r3 = Null
    //     0xdfe7e8: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c5b0] Null
    //     0xdfe7ec: ldr             x3, [x3, #0x5b0]
    // 0xdfe7f0: r0 = Widget()
    //     0xdfe7f0: bl              #0x829290  ; IsType_Widget_Stub
    // 0xdfe7f4: ldur            x4, [fp, #-0x28]
    // 0xdfe7f8: LoadField: r0 = r4->field_b
    //     0xdfe7f8: ldur            w0, [x4, #0xb]
    // 0xdfe7fc: r1 = LoadInt32Instr(r0)
    //     0xdfe7fc: sbfx            x1, x0, #1, #0x1f
    // 0xdfe800: mov             x0, x1
    // 0xdfe804: ldur            x1, [fp, #-0x40]
    // 0xdfe808: cmp             x1, x0
    // 0xdfe80c: b.hs            #0xdff990
    // 0xdfe810: LoadField: r1 = r4->field_f
    //     0xdfe810: ldur            w1, [x4, #0xf]
    // 0xdfe814: DecompressPointer r1
    //     0xdfe814: add             x1, x1, HEAP, lsl #32
    // 0xdfe818: ldur            x0, [fp, #-0x48]
    // 0xdfe81c: ldur            x2, [fp, #-0x40]
    // 0xdfe820: ArrayStore: r1[r2] = r0  ; List_4
    //     0xdfe820: add             x25, x1, x2, lsl #2
    //     0xdfe824: add             x25, x25, #0xf
    //     0xdfe828: str             w0, [x25]
    //     0xdfe82c: tbz             w0, #0, #0xdfe848
    //     0xdfe830: ldurb           w16, [x1, #-1]
    //     0xdfe834: ldurb           w17, [x0, #-1]
    //     0xdfe838: and             x16, x17, x16, lsr #2
    //     0xdfe83c: tst             x16, HEAP, lsr #32
    //     0xdfe840: b.eq            #0xdfe848
    //     0xdfe844: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdfe848: add             x0, x2, #1
    // 0xdfe84c: mov             x2, x0
    // 0xdfe850: mov             x1, x4
    // 0xdfe854: b               #0xdfe770
    // 0xdfe858: ldur            x0, [fp, #-8]
    // 0xdfe85c: mov             x4, x1
    // 0xdfe860: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xdfe860: ldur            w2, [x0, #0x17]
    // 0xdfe864: DecompressPointer r2
    //     0xdfe864: add             x2, x2, HEAP, lsl #32
    // 0xdfe868: stur            x2, [fp, #-0x38]
    // 0xdfe86c: cmp             w2, NULL
    // 0xdfe870: b.eq            #0xdfee5c
    // 0xdfe874: LoadField: r5 = r2->field_3b
    //     0xdfe874: ldur            x5, [x2, #0x3b]
    // 0xdfe878: stur            x5, [fp, #-0x40]
    // 0xdfe87c: LoadField: r1 = r2->field_43
    //     0xdfe87c: ldur            x1, [x2, #0x43]
    // 0xdfe880: cbz             x1, #0xdfea08
    // 0xdfe884: r1 = <double>
    //     0xdfe884: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdfe888: r0 = _ChangeAnimation()
    //     0xdfe888: bl              #0xdffaec  ; Allocate_ChangeAnimationStub -> _ChangeAnimation (size=0x10)
    // 0xdfe88c: mov             x2, x0
    // 0xdfe890: ldur            x0, [fp, #-0x38]
    // 0xdfe894: stur            x2, [fp, #-0x60]
    // 0xdfe898: StoreField: r2->field_b = r0
    //     0xdfe898: stur            w0, [x2, #0xb]
    // 0xdfe89c: ldur            x3, [fp, #-8]
    // 0xdfe8a0: LoadField: r0 = r3->field_1f
    //     0xdfe8a0: ldur            w0, [x3, #0x1f]
    // 0xdfe8a4: DecompressPointer r0
    //     0xdfe8a4: add             x0, x0, HEAP, lsl #32
    // 0xdfe8a8: cmp             w0, NULL
    // 0xdfe8ac: b.eq            #0xdff994
    // 0xdfe8b0: r4 = LoadInt32Instr(r0)
    //     0xdfe8b0: sbfx            x4, x0, #1, #0x1f
    //     0xdfe8b4: tbz             w0, #0, #0xdfe8bc
    //     0xdfe8b8: ldur            x4, [x0, #7]
    // 0xdfe8bc: ldur            x0, [fp, #-0x50]
    // 0xdfe8c0: mov             x1, x4
    // 0xdfe8c4: stur            x4, [fp, #-0x58]
    // 0xdfe8c8: cmp             x1, x0
    // 0xdfe8cc: b.hs            #0xdff998
    // 0xdfe8d0: ldur            x0, [fp, #-0x28]
    // 0xdfe8d4: LoadField: r1 = r0->field_f
    //     0xdfe8d4: ldur            w1, [x0, #0xf]
    // 0xdfe8d8: DecompressPointer r1
    //     0xdfe8d8: add             x1, x1, HEAP, lsl #32
    // 0xdfe8dc: ArrayLoad: r5 = r1[r4]  ; Unknown_4
    //     0xdfe8dc: add             x16, x1, x4, lsl #2
    //     0xdfe8e0: ldur            w5, [x16, #0xf]
    // 0xdfe8e4: DecompressPointer r5
    //     0xdfe8e4: add             x5, x5, HEAP, lsl #32
    // 0xdfe8e8: mov             x1, x3
    // 0xdfe8ec: stur            x5, [fp, #-0x48]
    // 0xdfe8f0: r0 = _defaults()
    //     0xdfe8f0: bl              #0xdffaf8  ; [package:flutter/src/material/tabs.dart] _TabBarState::_defaults
    // 0xdfe8f4: ldur            x1, [fp, #-8]
    // 0xdfe8f8: ldur            x2, [fp, #-0x48]
    // 0xdfe8fc: ldur            x5, [fp, #-0x60]
    // 0xdfe900: mov             x6, x0
    // 0xdfe904: r3 = true
    //     0xdfe904: add             x3, NULL, #0x20  ; true
    // 0xdfe908: r0 = _buildStyledTab()
    //     0xdfe908: bl              #0xdffa3c  ; [package:flutter/src/material/tabs.dart] _TabBarState::_buildStyledTab
    // 0xdfe90c: mov             x3, x0
    // 0xdfe910: ldur            x2, [fp, #-0x28]
    // 0xdfe914: LoadField: r0 = r2->field_b
    //     0xdfe914: ldur            w0, [x2, #0xb]
    // 0xdfe918: r4 = LoadInt32Instr(r0)
    //     0xdfe918: sbfx            x4, x0, #1, #0x1f
    // 0xdfe91c: mov             x0, x4
    // 0xdfe920: ldur            x1, [fp, #-0x58]
    // 0xdfe924: cmp             x1, x0
    // 0xdfe928: b.hs            #0xdff99c
    // 0xdfe92c: LoadField: r5 = r2->field_f
    //     0xdfe92c: ldur            w5, [x2, #0xf]
    // 0xdfe930: DecompressPointer r5
    //     0xdfe930: add             x5, x5, HEAP, lsl #32
    // 0xdfe934: mov             x1, x5
    // 0xdfe938: mov             x0, x3
    // 0xdfe93c: ldur            x3, [fp, #-0x58]
    // 0xdfe940: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdfe940: add             x25, x1, x3, lsl #2
    //     0xdfe944: add             x25, x25, #0xf
    //     0xdfe948: str             w0, [x25]
    //     0xdfe94c: tbz             w0, #0, #0xdfe968
    //     0xdfe950: ldurb           w16, [x1, #-1]
    //     0xdfe954: ldurb           w17, [x0, #-1]
    //     0xdfe958: and             x16, x17, x16, lsr #2
    //     0xdfe95c: tst             x16, HEAP, lsr #32
    //     0xdfe960: b.eq            #0xdfe968
    //     0xdfe964: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdfe968: mov             x0, x4
    // 0xdfe96c: ldur            x1, [fp, #-0x40]
    // 0xdfe970: cmp             x1, x0
    // 0xdfe974: b.hs            #0xdff9a0
    // 0xdfe978: ldur            x0, [fp, #-0x40]
    // 0xdfe97c: ArrayLoad: r3 = r5[r0]  ; Unknown_4
    //     0xdfe97c: add             x16, x5, x0, lsl #2
    //     0xdfe980: ldur            w3, [x16, #0xf]
    // 0xdfe984: DecompressPointer r3
    //     0xdfe984: add             x3, x3, HEAP, lsl #32
    // 0xdfe988: ldur            x1, [fp, #-8]
    // 0xdfe98c: stur            x3, [fp, #-0x48]
    // 0xdfe990: r0 = _defaults()
    //     0xdfe990: bl              #0xdffaf8  ; [package:flutter/src/material/tabs.dart] _TabBarState::_defaults
    // 0xdfe994: ldur            x1, [fp, #-8]
    // 0xdfe998: ldur            x2, [fp, #-0x48]
    // 0xdfe99c: ldur            x5, [fp, #-0x60]
    // 0xdfe9a0: mov             x6, x0
    // 0xdfe9a4: r3 = false
    //     0xdfe9a4: add             x3, NULL, #0x30  ; false
    // 0xdfe9a8: r0 = _buildStyledTab()
    //     0xdfe9a8: bl              #0xdffa3c  ; [package:flutter/src/material/tabs.dart] _TabBarState::_buildStyledTab
    // 0xdfe9ac: mov             x3, x0
    // 0xdfe9b0: ldur            x2, [fp, #-0x28]
    // 0xdfe9b4: LoadField: r0 = r2->field_b
    //     0xdfe9b4: ldur            w0, [x2, #0xb]
    // 0xdfe9b8: r1 = LoadInt32Instr(r0)
    //     0xdfe9b8: sbfx            x1, x0, #1, #0x1f
    // 0xdfe9bc: mov             x0, x1
    // 0xdfe9c0: ldur            x1, [fp, #-0x40]
    // 0xdfe9c4: cmp             x1, x0
    // 0xdfe9c8: b.hs            #0xdff9a4
    // 0xdfe9cc: LoadField: r1 = r2->field_f
    //     0xdfe9cc: ldur            w1, [x2, #0xf]
    // 0xdfe9d0: DecompressPointer r1
    //     0xdfe9d0: add             x1, x1, HEAP, lsl #32
    // 0xdfe9d4: mov             x0, x3
    // 0xdfe9d8: ldur            x3, [fp, #-0x40]
    // 0xdfe9dc: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdfe9dc: add             x25, x1, x3, lsl #2
    //     0xdfe9e0: add             x25, x25, #0xf
    //     0xdfe9e4: str             w0, [x25]
    //     0xdfe9e8: tbz             w0, #0, #0xdfea04
    //     0xdfe9ec: ldurb           w16, [x1, #-1]
    //     0xdfe9f0: ldurb           w17, [x0, #-1]
    //     0xdfe9f4: and             x16, x17, x16, lsr #2
    //     0xdfe9f8: tst             x16, HEAP, lsr #32
    //     0xdfe9fc: b.eq            #0xdfea04
    //     0xdfea00: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdfea04: b               #0xdfee60
    // 0xdfea08: mov             x3, x0
    // 0xdfea0c: mov             x0, x2
    // 0xdfea10: mov             x2, x4
    // 0xdfea14: LoadField: r4 = r3->field_1f
    //     0xdfea14: ldur            w4, [x3, #0x1f]
    // 0xdfea18: DecompressPointer r4
    //     0xdfea18: add             x4, x4, HEAP, lsl #32
    // 0xdfea1c: stur            x4, [fp, #-0x48]
    // 0xdfea20: cmp             w4, NULL
    // 0xdfea24: b.eq            #0xdff9a8
    // 0xdfea28: r1 = <double>
    //     0xdfea28: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdfea2c: r0 = _DragAnimation()
    //     0xdfea2c: bl              #0xdffa30  ; Allocate_DragAnimationStub -> _DragAnimation (size=0x18)
    // 0xdfea30: mov             x2, x0
    // 0xdfea34: ldur            x0, [fp, #-0x38]
    // 0xdfea38: stur            x2, [fp, #-0x60]
    // 0xdfea3c: StoreField: r2->field_b = r0
    //     0xdfea3c: stur            w0, [x2, #0xb]
    // 0xdfea40: ldur            x0, [fp, #-0x48]
    // 0xdfea44: r3 = LoadInt32Instr(r0)
    //     0xdfea44: sbfx            x3, x0, #1, #0x1f
    //     0xdfea48: tbz             w0, #0, #0xdfea50
    //     0xdfea4c: ldur            x3, [x0, #7]
    // 0xdfea50: stur            x3, [fp, #-0x40]
    // 0xdfea54: StoreField: r2->field_f = r3
    //     0xdfea54: stur            x3, [x2, #0xf]
    // 0xdfea58: ldur            x0, [fp, #-0x50]
    // 0xdfea5c: mov             x1, x3
    // 0xdfea60: cmp             x1, x0
    // 0xdfea64: b.hs            #0xdff9ac
    // 0xdfea68: ldur            x0, [fp, #-0x28]
    // 0xdfea6c: LoadField: r1 = r0->field_f
    //     0xdfea6c: ldur            w1, [x0, #0xf]
    // 0xdfea70: DecompressPointer r1
    //     0xdfea70: add             x1, x1, HEAP, lsl #32
    // 0xdfea74: ArrayLoad: r4 = r1[r3]  ; Unknown_4
    //     0xdfea74: add             x16, x1, x3, lsl #2
    //     0xdfea78: ldur            w4, [x16, #0xf]
    // 0xdfea7c: DecompressPointer r4
    //     0xdfea7c: add             x4, x4, HEAP, lsl #32
    // 0xdfea80: ldur            x1, [fp, #-8]
    // 0xdfea84: stur            x4, [fp, #-0x38]
    // 0xdfea88: r0 = _defaults()
    //     0xdfea88: bl              #0xdffaf8  ; [package:flutter/src/material/tabs.dart] _TabBarState::_defaults
    // 0xdfea8c: ldur            x1, [fp, #-8]
    // 0xdfea90: ldur            x2, [fp, #-0x38]
    // 0xdfea94: ldur            x5, [fp, #-0x60]
    // 0xdfea98: mov             x6, x0
    // 0xdfea9c: r3 = true
    //     0xdfea9c: add             x3, NULL, #0x20  ; true
    // 0xdfeaa0: r0 = _buildStyledTab()
    //     0xdfeaa0: bl              #0xdffa3c  ; [package:flutter/src/material/tabs.dart] _TabBarState::_buildStyledTab
    // 0xdfeaa4: mov             x3, x0
    // 0xdfeaa8: ldur            x2, [fp, #-0x28]
    // 0xdfeaac: LoadField: r0 = r2->field_b
    //     0xdfeaac: ldur            w0, [x2, #0xb]
    // 0xdfeab0: r1 = LoadInt32Instr(r0)
    //     0xdfeab0: sbfx            x1, x0, #1, #0x1f
    // 0xdfeab4: mov             x0, x1
    // 0xdfeab8: ldur            x1, [fp, #-0x40]
    // 0xdfeabc: cmp             x1, x0
    // 0xdfeac0: b.hs            #0xdff9b0
    // 0xdfeac4: LoadField: r1 = r2->field_f
    //     0xdfeac4: ldur            w1, [x2, #0xf]
    // 0xdfeac8: DecompressPointer r1
    //     0xdfeac8: add             x1, x1, HEAP, lsl #32
    // 0xdfeacc: mov             x0, x3
    // 0xdfead0: ldur            x3, [fp, #-0x40]
    // 0xdfead4: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdfead4: add             x25, x1, x3, lsl #2
    //     0xdfead8: add             x25, x25, #0xf
    //     0xdfeadc: str             w0, [x25]
    //     0xdfeae0: tbz             w0, #0, #0xdfeafc
    //     0xdfeae4: ldurb           w16, [x1, #-1]
    //     0xdfeae8: ldurb           w17, [x0, #-1]
    //     0xdfeaec: and             x16, x17, x16, lsr #2
    //     0xdfeaf0: tst             x16, HEAP, lsr #32
    //     0xdfeaf4: b.eq            #0xdfeafc
    //     0xdfeaf8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdfeafc: ldur            x0, [fp, #-8]
    // 0xdfeb00: LoadField: r1 = r0->field_1f
    //     0xdfeb00: ldur            w1, [x0, #0x1f]
    // 0xdfeb04: DecompressPointer r1
    //     0xdfeb04: add             x1, x1, HEAP, lsl #32
    // 0xdfeb08: cmp             w1, NULL
    // 0xdfeb0c: b.eq            #0xdff9b4
    // 0xdfeb10: r3 = LoadInt32Instr(r1)
    //     0xdfeb10: sbfx            x3, x1, #1, #0x1f
    //     0xdfeb14: tbz             w1, #0, #0xdfeb1c
    //     0xdfeb18: ldur            x3, [x1, #7]
    // 0xdfeb1c: cmp             x3, #0
    // 0xdfeb20: b.le            #0xdfec98
    // 0xdfeb24: sub             x4, x3, #1
    // 0xdfeb28: stur            x4, [fp, #-0x40]
    // 0xdfeb2c: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xdfeb2c: ldur            w3, [x0, #0x17]
    // 0xdfeb30: DecompressPointer r3
    //     0xdfeb30: add             x3, x3, HEAP, lsl #32
    // 0xdfeb34: stur            x3, [fp, #-0x38]
    // 0xdfeb38: cmp             w3, NULL
    // 0xdfeb3c: b.eq            #0xdff9b8
    // 0xdfeb40: r1 = <double>
    //     0xdfeb40: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdfeb44: r0 = _DragAnimation()
    //     0xdfeb44: bl              #0xdffa30  ; Allocate_DragAnimationStub -> _DragAnimation (size=0x18)
    // 0xdfeb48: mov             x2, x0
    // 0xdfeb4c: ldur            x0, [fp, #-0x38]
    // 0xdfeb50: stur            x2, [fp, #-0x48]
    // 0xdfeb54: StoreField: r2->field_b = r0
    //     0xdfeb54: stur            w0, [x2, #0xb]
    // 0xdfeb58: ldur            x0, [fp, #-0x40]
    // 0xdfeb5c: StoreField: r2->field_f = r0
    //     0xdfeb5c: stur            x0, [x2, #0xf]
    // 0xdfeb60: r1 = <double>
    //     0xdfeb60: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdfeb64: r0 = ReverseAnimation()
    //     0xdfeb64: bl              #0xdffa24  ; AllocateReverseAnimationStub -> ReverseAnimation (size=0x1c)
    // 0xdfeb68: mov             x2, x0
    // 0xdfeb6c: ldur            x0, [fp, #-0x48]
    // 0xdfeb70: stur            x2, [fp, #-0x38]
    // 0xdfeb74: ArrayStore: r2[0] = r0  ; List_4
    //     0xdfeb74: stur            w0, [x2, #0x17]
    // 0xdfeb78: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xdfeb78: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xdfeb7c: r0 = ObserverList()
    //     0xdfeb7c: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xdfeb80: r3 = false
    //     0xdfeb80: add             x3, NULL, #0x30  ; false
    // 0xdfeb84: stur            x0, [fp, #-0x48]
    // 0xdfeb88: StoreField: r0->field_f = r3
    //     0xdfeb88: stur            w3, [x0, #0xf]
    // 0xdfeb8c: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfeb90: StoreField: r0->field_13 = r4
    //     0xdfeb90: stur            w4, [x0, #0x13]
    // 0xdfeb94: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xdfeb94: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xdfeb98: r2 = 0
    //     0xdfeb98: mov             x2, #0
    // 0xdfeb9c: r0 = _GrowableList()
    //     0xdfeb9c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xdfeba0: ldur            x1, [fp, #-0x48]
    // 0xdfeba4: StoreField: r1->field_b = r0
    //     0xdfeba4: stur            w0, [x1, #0xb]
    //     0xdfeba8: ldurb           w16, [x1, #-1]
    //     0xdfebac: ldurb           w17, [x0, #-1]
    //     0xdfebb0: and             x16, x17, x16, lsr #2
    //     0xdfebb4: tst             x16, HEAP, lsr #32
    //     0xdfebb8: b.eq            #0xdfebc0
    //     0xdfebbc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdfebc0: mov             x0, x1
    // 0xdfebc4: ldur            x5, [fp, #-0x38]
    // 0xdfebc8: StoreField: r5->field_13 = r0
    //     0xdfebc8: stur            w0, [x5, #0x13]
    //     0xdfebcc: ldurb           w16, [x5, #-1]
    //     0xdfebd0: ldurb           w17, [x0, #-1]
    //     0xdfebd4: and             x16, x17, x16, lsr #2
    //     0xdfebd8: tst             x16, HEAP, lsr #32
    //     0xdfebdc: b.eq            #0xdfebe4
    //     0xdfebe0: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xdfebe4: StoreField: r5->field_b = rZR
    //     0xdfebe4: stur            xzr, [x5, #0xb]
    // 0xdfebe8: ldur            x2, [fp, #-0x28]
    // 0xdfebec: LoadField: r0 = r2->field_b
    //     0xdfebec: ldur            w0, [x2, #0xb]
    // 0xdfebf0: r1 = LoadInt32Instr(r0)
    //     0xdfebf0: sbfx            x1, x0, #1, #0x1f
    // 0xdfebf4: mov             x0, x1
    // 0xdfebf8: ldur            x1, [fp, #-0x40]
    // 0xdfebfc: cmp             x1, x0
    // 0xdfec00: b.hs            #0xdff9bc
    // 0xdfec04: LoadField: r0 = r2->field_f
    //     0xdfec04: ldur            w0, [x2, #0xf]
    // 0xdfec08: DecompressPointer r0
    //     0xdfec08: add             x0, x0, HEAP, lsl #32
    // 0xdfec0c: ldur            x3, [fp, #-0x40]
    // 0xdfec10: ArrayLoad: r4 = r0[r3]  ; Unknown_4
    //     0xdfec10: add             x16, x0, x3, lsl #2
    //     0xdfec14: ldur            w4, [x16, #0xf]
    // 0xdfec18: DecompressPointer r4
    //     0xdfec18: add             x4, x4, HEAP, lsl #32
    // 0xdfec1c: ldur            x1, [fp, #-8]
    // 0xdfec20: stur            x4, [fp, #-0x48]
    // 0xdfec24: r0 = _defaults()
    //     0xdfec24: bl              #0xdffaf8  ; [package:flutter/src/material/tabs.dart] _TabBarState::_defaults
    // 0xdfec28: ldur            x1, [fp, #-8]
    // 0xdfec2c: ldur            x2, [fp, #-0x48]
    // 0xdfec30: ldur            x5, [fp, #-0x38]
    // 0xdfec34: mov             x6, x0
    // 0xdfec38: r3 = false
    //     0xdfec38: add             x3, NULL, #0x30  ; false
    // 0xdfec3c: r0 = _buildStyledTab()
    //     0xdfec3c: bl              #0xdffa3c  ; [package:flutter/src/material/tabs.dart] _TabBarState::_buildStyledTab
    // 0xdfec40: mov             x3, x0
    // 0xdfec44: ldur            x2, [fp, #-0x28]
    // 0xdfec48: LoadField: r0 = r2->field_b
    //     0xdfec48: ldur            w0, [x2, #0xb]
    // 0xdfec4c: r1 = LoadInt32Instr(r0)
    //     0xdfec4c: sbfx            x1, x0, #1, #0x1f
    // 0xdfec50: mov             x0, x1
    // 0xdfec54: ldur            x1, [fp, #-0x40]
    // 0xdfec58: cmp             x1, x0
    // 0xdfec5c: b.hs            #0xdff9c0
    // 0xdfec60: LoadField: r1 = r2->field_f
    //     0xdfec60: ldur            w1, [x2, #0xf]
    // 0xdfec64: DecompressPointer r1
    //     0xdfec64: add             x1, x1, HEAP, lsl #32
    // 0xdfec68: mov             x0, x3
    // 0xdfec6c: ldur            x3, [fp, #-0x40]
    // 0xdfec70: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdfec70: add             x25, x1, x3, lsl #2
    //     0xdfec74: add             x25, x25, #0xf
    //     0xdfec78: str             w0, [x25]
    //     0xdfec7c: tbz             w0, #0, #0xdfec98
    //     0xdfec80: ldurb           w16, [x1, #-1]
    //     0xdfec84: ldurb           w17, [x0, #-1]
    //     0xdfec88: and             x16, x17, x16, lsr #2
    //     0xdfec8c: tst             x16, HEAP, lsr #32
    //     0xdfec90: b.eq            #0xdfec98
    //     0xdfec94: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdfec98: ldur            x0, [fp, #-8]
    // 0xdfec9c: LoadField: r1 = r0->field_1f
    //     0xdfec9c: ldur            w1, [x0, #0x1f]
    // 0xdfeca0: DecompressPointer r1
    //     0xdfeca0: add             x1, x1, HEAP, lsl #32
    // 0xdfeca4: cmp             w1, NULL
    // 0xdfeca8: b.eq            #0xdff9c4
    // 0xdfecac: LoadField: r3 = r0->field_b
    //     0xdfecac: ldur            w3, [x0, #0xb]
    // 0xdfecb0: DecompressPointer r3
    //     0xdfecb0: add             x3, x3, HEAP, lsl #32
    // 0xdfecb4: cmp             w3, NULL
    // 0xdfecb8: b.eq            #0xdff9c8
    // 0xdfecbc: LoadField: r4 = r3->field_b
    //     0xdfecbc: ldur            w4, [x3, #0xb]
    // 0xdfecc0: DecompressPointer r4
    //     0xdfecc0: add             x4, x4, HEAP, lsl #32
    // 0xdfecc4: LoadField: r3 = r4->field_b
    //     0xdfecc4: ldur            w3, [x4, #0xb]
    // 0xdfecc8: r4 = LoadInt32Instr(r3)
    //     0xdfecc8: sbfx            x4, x3, #1, #0x1f
    // 0xdfeccc: sub             x3, x4, #1
    // 0xdfecd0: r4 = LoadInt32Instr(r1)
    //     0xdfecd0: sbfx            x4, x1, #1, #0x1f
    //     0xdfecd4: tbz             w1, #0, #0xdfecdc
    //     0xdfecd8: ldur            x4, [x1, #7]
    // 0xdfecdc: cmp             x4, x3
    // 0xdfece0: b.ge            #0xdfee60
    // 0xdfece4: add             x3, x4, #1
    // 0xdfece8: stur            x3, [fp, #-0x40]
    // 0xdfecec: ArrayLoad: r4 = r0[0]  ; List_4
    //     0xdfecec: ldur            w4, [x0, #0x17]
    // 0xdfecf0: DecompressPointer r4
    //     0xdfecf0: add             x4, x4, HEAP, lsl #32
    // 0xdfecf4: stur            x4, [fp, #-0x38]
    // 0xdfecf8: cmp             w4, NULL
    // 0xdfecfc: b.eq            #0xdff9cc
    // 0xdfed00: r1 = <double>
    //     0xdfed00: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdfed04: r0 = _DragAnimation()
    //     0xdfed04: bl              #0xdffa30  ; Allocate_DragAnimationStub -> _DragAnimation (size=0x18)
    // 0xdfed08: mov             x2, x0
    // 0xdfed0c: ldur            x0, [fp, #-0x38]
    // 0xdfed10: stur            x2, [fp, #-0x48]
    // 0xdfed14: StoreField: r2->field_b = r0
    //     0xdfed14: stur            w0, [x2, #0xb]
    // 0xdfed18: ldur            x0, [fp, #-0x40]
    // 0xdfed1c: StoreField: r2->field_f = r0
    //     0xdfed1c: stur            x0, [x2, #0xf]
    // 0xdfed20: r1 = <double>
    //     0xdfed20: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdfed24: r0 = ReverseAnimation()
    //     0xdfed24: bl              #0xdffa24  ; AllocateReverseAnimationStub -> ReverseAnimation (size=0x1c)
    // 0xdfed28: mov             x2, x0
    // 0xdfed2c: ldur            x0, [fp, #-0x48]
    // 0xdfed30: stur            x2, [fp, #-0x38]
    // 0xdfed34: ArrayStore: r2[0] = r0  ; List_4
    //     0xdfed34: stur            w0, [x2, #0x17]
    // 0xdfed38: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xdfed38: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xdfed3c: r0 = ObserverList()
    //     0xdfed3c: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xdfed40: r3 = false
    //     0xdfed40: add             x3, NULL, #0x30  ; false
    // 0xdfed44: stur            x0, [fp, #-0x48]
    // 0xdfed48: StoreField: r0->field_f = r3
    //     0xdfed48: stur            w3, [x0, #0xf]
    // 0xdfed4c: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfed50: StoreField: r0->field_13 = r1
    //     0xdfed50: stur            w1, [x0, #0x13]
    // 0xdfed54: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xdfed54: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xdfed58: r2 = 0
    //     0xdfed58: mov             x2, #0
    // 0xdfed5c: r0 = _GrowableList()
    //     0xdfed5c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xdfed60: ldur            x1, [fp, #-0x48]
    // 0xdfed64: StoreField: r1->field_b = r0
    //     0xdfed64: stur            w0, [x1, #0xb]
    //     0xdfed68: ldurb           w16, [x1, #-1]
    //     0xdfed6c: ldurb           w17, [x0, #-1]
    //     0xdfed70: and             x16, x17, x16, lsr #2
    //     0xdfed74: tst             x16, HEAP, lsr #32
    //     0xdfed78: b.eq            #0xdfed80
    //     0xdfed7c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdfed80: mov             x0, x1
    // 0xdfed84: ldur            x5, [fp, #-0x38]
    // 0xdfed88: StoreField: r5->field_13 = r0
    //     0xdfed88: stur            w0, [x5, #0x13]
    //     0xdfed8c: ldurb           w16, [x5, #-1]
    //     0xdfed90: ldurb           w17, [x0, #-1]
    //     0xdfed94: and             x16, x17, x16, lsr #2
    //     0xdfed98: tst             x16, HEAP, lsr #32
    //     0xdfed9c: b.eq            #0xdfeda4
    //     0xdfeda0: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xdfeda4: StoreField: r5->field_b = rZR
    //     0xdfeda4: stur            xzr, [x5, #0xb]
    // 0xdfeda8: ldur            x2, [fp, #-0x28]
    // 0xdfedac: LoadField: r0 = r2->field_b
    //     0xdfedac: ldur            w0, [x2, #0xb]
    // 0xdfedb0: r1 = LoadInt32Instr(r0)
    //     0xdfedb0: sbfx            x1, x0, #1, #0x1f
    // 0xdfedb4: mov             x0, x1
    // 0xdfedb8: ldur            x1, [fp, #-0x40]
    // 0xdfedbc: cmp             x1, x0
    // 0xdfedc0: b.hs            #0xdff9d0
    // 0xdfedc4: LoadField: r0 = r2->field_f
    //     0xdfedc4: ldur            w0, [x2, #0xf]
    // 0xdfedc8: DecompressPointer r0
    //     0xdfedc8: add             x0, x0, HEAP, lsl #32
    // 0xdfedcc: ldur            x3, [fp, #-0x40]
    // 0xdfedd0: ArrayLoad: r4 = r0[r3]  ; Unknown_4
    //     0xdfedd0: add             x16, x0, x3, lsl #2
    //     0xdfedd4: ldur            w4, [x16, #0xf]
    // 0xdfedd8: DecompressPointer r4
    //     0xdfedd8: add             x4, x4, HEAP, lsl #32
    // 0xdfeddc: ldur            x1, [fp, #-8]
    // 0xdfede0: stur            x4, [fp, #-0x48]
    // 0xdfede4: r0 = _defaults()
    //     0xdfede4: bl              #0xdffaf8  ; [package:flutter/src/material/tabs.dart] _TabBarState::_defaults
    // 0xdfede8: ldur            x1, [fp, #-8]
    // 0xdfedec: ldur            x2, [fp, #-0x48]
    // 0xdfedf0: ldur            x5, [fp, #-0x38]
    // 0xdfedf4: mov             x6, x0
    // 0xdfedf8: r3 = false
    //     0xdfedf8: add             x3, NULL, #0x30  ; false
    // 0xdfedfc: r0 = _buildStyledTab()
    //     0xdfedfc: bl              #0xdffa3c  ; [package:flutter/src/material/tabs.dart] _TabBarState::_buildStyledTab
    // 0xdfee00: mov             x3, x0
    // 0xdfee04: ldur            x2, [fp, #-0x28]
    // 0xdfee08: LoadField: r0 = r2->field_b
    //     0xdfee08: ldur            w0, [x2, #0xb]
    // 0xdfee0c: r1 = LoadInt32Instr(r0)
    //     0xdfee0c: sbfx            x1, x0, #1, #0x1f
    // 0xdfee10: mov             x0, x1
    // 0xdfee14: ldur            x1, [fp, #-0x40]
    // 0xdfee18: cmp             x1, x0
    // 0xdfee1c: b.hs            #0xdff9d4
    // 0xdfee20: LoadField: r1 = r2->field_f
    //     0xdfee20: ldur            w1, [x2, #0xf]
    // 0xdfee24: DecompressPointer r1
    //     0xdfee24: add             x1, x1, HEAP, lsl #32
    // 0xdfee28: mov             x0, x3
    // 0xdfee2c: ldur            x3, [fp, #-0x40]
    // 0xdfee30: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdfee30: add             x25, x1, x3, lsl #2
    //     0xdfee34: add             x25, x25, #0xf
    //     0xdfee38: str             w0, [x25]
    //     0xdfee3c: tbz             w0, #0, #0xdfee58
    //     0xdfee40: ldurb           w16, [x1, #-1]
    //     0xdfee44: ldurb           w17, [x0, #-1]
    //     0xdfee48: and             x16, x17, x16, lsr #2
    //     0xdfee4c: tst             x16, HEAP, lsr #32
    //     0xdfee50: b.eq            #0xdfee58
    //     0xdfee54: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdfee58: b               #0xdfee60
    // 0xdfee5c: mov             x2, x4
    // 0xdfee60: ldur            x1, [fp, #-8]
    // 0xdfee64: ldur            x0, [fp, #-0x18]
    // 0xdfee68: LoadField: r3 = r1->field_b
    //     0xdfee68: ldur            w3, [x1, #0xb]
    // 0xdfee6c: DecompressPointer r3
    //     0xdfee6c: add             x3, x3, HEAP, lsl #32
    // 0xdfee70: stur            x3, [fp, #-0x48]
    // 0xdfee74: cmp             w3, NULL
    // 0xdfee78: b.eq            #0xdff9d8
    // 0xdfee7c: LoadField: r4 = r3->field_b
    //     0xdfee7c: ldur            w4, [x3, #0xb]
    // 0xdfee80: DecompressPointer r4
    //     0xdfee80: add             x4, x4, HEAP, lsl #32
    // 0xdfee84: LoadField: r5 = r4->field_b
    //     0xdfee84: ldur            w5, [x4, #0xb]
    // 0xdfee88: stur            x5, [fp, #-0x38]
    // 0xdfee8c: r1 = 2
    //     0xdfee8c: mov             x1, #2
    // 0xdfee90: r0 = AllocateContext()
    //     0xdfee90: bl              #0x13de838  ; AllocateContextStub
    // 0xdfee94: mov             x1, x0
    // 0xdfee98: ldur            x0, [fp, #-0x18]
    // 0xdfee9c: StoreField: r1->field_b = r0
    //     0xdfee9c: stur            w0, [x1, #0xb]
    // 0xdfeea0: StoreField: r1->field_f = rZR
    //     0xdfeea0: stur            wzr, [x1, #0xf]
    // 0xdfeea4: ldur            x0, [fp, #-0x38]
    // 0xdfeea8: r2 = LoadInt32Instr(r0)
    //     0xdfeea8: sbfx            x2, x0, #1, #0x1f
    // 0xdfeeac: stur            x2, [fp, #-0x50]
    // 0xdfeeb0: mov             x7, x1
    // 0xdfeeb4: ldur            x1, [fp, #-0x48]
    // 0xdfeeb8: r6 = 0
    //     0xdfeeb8: mov             x6, #0
    // 0xdfeebc: ldur            x3, [fp, #-8]
    // 0xdfeec0: ldur            x5, [fp, #-0x20]
    // 0xdfeec4: ldur            x4, [fp, #-0x30]
    // 0xdfeec8: ldur            x0, [fp, #-0x28]
    // 0xdfeecc: stur            x7, [fp, #-0x18]
    // 0xdfeed0: stur            x6, [fp, #-0x40]
    // 0xdfeed4: CheckStackOverflow
    //     0xdfeed4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfeed8: cmp             SP, x16
    //     0xdfeedc: b.ls            #0xdff9dc
    // 0xdfeee0: cmp             x6, x2
    // 0xdfeee4: b.ge            #0xdff6d8
    // 0xdfeee8: r1 = <WidgetState>
    //     0xdfeee8: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a10] TypeArguments: <WidgetState>
    //     0xdfeeec: ldr             x1, [x1, #0xa10]
    // 0xdfeef0: r0 = _Set()
    //     0xdfeef0: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xdfeef4: mov             x3, x0
    // 0xdfeef8: r2 = _Uint32List
    //     0xdfeef8: ldr             x2, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0xdfeefc: stur            x3, [fp, #-0x38]
    // 0xdfef00: StoreField: r3->field_1b = r2
    //     0xdfef00: stur            w2, [x3, #0x1b]
    // 0xdfef04: StoreField: r3->field_b = rZR
    //     0xdfef04: stur            wzr, [x3, #0xb]
    // 0xdfef08: r4 = const []
    //     0xdfef08: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0xdfef0c: StoreField: r3->field_f = r4
    //     0xdfef0c: stur            w4, [x3, #0xf]
    // 0xdfef10: StoreField: r3->field_13 = rZR
    //     0xdfef10: stur            wzr, [x3, #0x13]
    // 0xdfef14: ArrayStore: r3[0] = rZR  ; List_4
    //     0xdfef14: stur            wzr, [x3, #0x17]
    // 0xdfef18: ldur            x5, [fp, #-8]
    // 0xdfef1c: LoadField: r6 = r5->field_1f
    //     0xdfef1c: ldur            w6, [x5, #0x1f]
    // 0xdfef20: DecompressPointer r6
    //     0xdfef20: add             x6, x6, HEAP, lsl #32
    // 0xdfef24: ldur            x7, [fp, #-0x40]
    // 0xdfef28: r0 = BoxInt64Instr(r7)
    //     0xdfef28: sbfiz           x0, x7, #1, #0x1f
    //     0xdfef2c: cmp             x7, x0, asr #1
    //     0xdfef30: b.eq            #0xdfef3c
    //     0xdfef34: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xdfef38: stur            x7, [x0, #7]
    // 0xdfef3c: cmp             w0, w6
    // 0xdfef40: b.eq            #0xdfef7c
    // 0xdfef44: and             w16, w0, w6
    // 0xdfef48: branchIfSmi(r16, 0xdfefa0)
    //     0xdfef48: tbz             w16, #0, #0xdfefa0
    // 0xdfef4c: r16 = LoadClassIdInstr(r0)
    //     0xdfef4c: ldur            x16, [x0, #-1]
    //     0xdfef50: ubfx            x16, x16, #0xc, #0x14
    // 0xdfef54: cmp             x16, #0x3d
    // 0xdfef58: b.ne            #0xdfefa0
    // 0xdfef5c: r16 = LoadClassIdInstr(r6)
    //     0xdfef5c: ldur            x16, [x6, #-1]
    //     0xdfef60: ubfx            x16, x16, #0xc, #0x14
    // 0xdfef64: cmp             x16, #0x3d
    // 0xdfef68: b.ne            #0xdfefa0
    // 0xdfef6c: LoadField: r16 = r0->field_7
    //     0xdfef6c: ldur            x16, [x0, #7]
    // 0xdfef70: LoadField: r17 = r6->field_7
    //     0xdfef70: ldur            x17, [x6, #7]
    // 0xdfef74: cmp             x16, x17
    // 0xdfef78: b.ne            #0xdfefa0
    // 0xdfef7c: r16 = Instance_WidgetState
    //     0xdfef7c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xdfef80: ldr             x16, [x16, #0x100]
    // 0xdfef84: str             x16, [SP]
    // 0xdfef88: r0 = _getHash()
    //     0xdfef88: bl              #0x84c644  ; [dart:core] ::_getHash
    // 0xdfef8c: r3 = LoadInt32Instr(r0)
    //     0xdfef8c: sbfx            x3, x0, #1, #0x1f
    // 0xdfef90: ldur            x1, [fp, #-0x38]
    // 0xdfef94: r2 = Instance_WidgetState
    //     0xdfef94: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xdfef98: ldr             x2, [x2, #0x100]
    // 0xdfef9c: r0 = _add()
    //     0xdfef9c: bl              #0x84ba3c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_add
    // 0xdfefa0: ldur            x3, [fp, #-8]
    // 0xdfefa4: ldur            x4, [fp, #-0x18]
    // 0xdfefa8: ldur            x0, [fp, #-0x38]
    // 0xdfefac: StoreField: r4->field_13 = r0
    //     0xdfefac: stur            w0, [x4, #0x13]
    //     0xdfefb0: ldurb           w16, [x4, #-1]
    //     0xdfefb4: ldurb           w17, [x0, #-1]
    //     0xdfefb8: and             x16, x17, x16, lsr #2
    //     0xdfefbc: tst             x16, HEAP, lsr #32
    //     0xdfefc0: b.eq            #0xdfefc8
    //     0xdfefc4: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xdfefc8: LoadField: r0 = r3->field_b
    //     0xdfefc8: ldur            w0, [x3, #0xb]
    // 0xdfefcc: DecompressPointer r0
    //     0xdfefcc: add             x0, x0, HEAP, lsl #32
    // 0xdfefd0: cmp             w0, NULL
    // 0xdfefd4: b.eq            #0xdff9e4
    // 0xdfefd8: r0 = Null
    //     0xdfefd8: mov             x0, NULL
    // 0xdfefdc: r2 = Null
    //     0xdfefdc: mov             x2, NULL
    // 0xdfefe0: r1 = <MouseCursor?>
    //     0xdfefe0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ab8] TypeArguments: <MouseCursor?>
    //     0xdfefe4: ldr             x1, [x1, #0xab8]
    // 0xdfefe8: cmp             w0, NULL
    // 0xdfefec: b.eq            #0xdff038
    // 0xdfeff0: branchIfSmi(r0, 0xdff038)
    //     0xdfeff0: tbz             w0, #0, #0xdff038
    // 0xdfeff4: r3 = SubtypeTestCache
    //     0xdfeff4: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c5c0] SubtypeTestCache
    //     0xdfeff8: ldr             x3, [x3, #0x5c0]
    // 0xdfeffc: r30 = Subtype4TestCacheStub
    //     0xdfeffc: ldr             lr, [PP, #0x20]  ; [pp+0x20] Stub: Subtype4TestCache (0x7d2a64)
    // 0xdff000: LoadField: r30 = r30->field_7
    //     0xdff000: ldur            lr, [lr, #7]
    // 0xdff004: blr             lr
    // 0xdff008: cmp             w7, NULL
    // 0xdff00c: b.eq            #0xdff018
    // 0xdff010: tbnz            w7, #4, #0xdff038
    // 0xdff014: b               #0xdff040
    // 0xdff018: r8 = WidgetStateProperty<Y0>
    //     0xdff018: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8c5c8] Type: WidgetStateProperty<Y0>
    //     0xdff01c: ldr             x8, [x8, #0x5c8]
    // 0xdff020: r3 = SubtypeTestCache
    //     0xdff020: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c5d0] SubtypeTestCache
    //     0xdff024: ldr             x3, [x3, #0x5d0]
    // 0xdff028: r30 = InstanceOfStub
    //     0xdff028: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xdff02c: LoadField: r30 = r30->field_7
    //     0xdff02c: ldur            lr, [lr, #7]
    // 0xdff030: blr             lr
    // 0xdff034: b               #0xdff044
    // 0xdff038: r0 = false
    //     0xdff038: add             x0, NULL, #0x30  ; false
    // 0xdff03c: b               #0xdff044
    // 0xdff040: r0 = true
    //     0xdff040: add             x0, NULL, #0x20  ; true
    // 0xdff044: tbnz            w0, #4, #0xdff068
    // 0xdff048: ldur            x2, [fp, #-0x38]
    // 0xdff04c: r0 = 171
    //     0xdff04c: mov             x0, #0xab
    // 0xdff050: r1 = Null
    //     0xdff050: mov             x1, NULL
    // 0xdff054: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xdff054: mov             x17, #0x7c77
    //     0xdff058: movk            x17, #1, lsl #16
    //     0xdff05c: add             lr, x0, x17
    //     0xdff060: ldr             lr, [x21, lr, lsl #3]
    //     0xdff064: blr             lr
    // 0xdff068: ldur            x0, [fp, #-8]
    // 0xdff06c: ldur            x2, [fp, #-0x18]
    // 0xdff070: ldur            x1, [fp, #-0x38]
    // 0xdff074: r0 = _clickable()
    //     0xdff074: bl              #0xd0bac0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateMouseCursor::_clickable
    // 0xdff078: ldur            x2, [fp, #-0x18]
    // 0xdff07c: r1 = Function '<anonymous closure>':.
    //     0xdff07c: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c5d8] AnonymousClosure: (0xe000c0), in [package:flutter/src/material/tabs.dart] _TabBarState::build (0xdfe5b0)
    //     0xdff080: ldr             x1, [x1, #0x5d8]
    // 0xdff084: stur            x0, [fp, #-0x38]
    // 0xdff088: r0 = AllocateClosure()
    //     0xdff088: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdff08c: r1 = <Color?>
    //     0xdff08c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdff090: ldr             x1, [x1, #0xa40]
    // 0xdff094: stur            x0, [fp, #-0x48]
    // 0xdff098: r0 = _WidgetStatePropertyWith()
    //     0xdff098: bl              #0xd0df80  ; Allocate_WidgetStatePropertyWithStub -> _WidgetStatePropertyWith<X0> (size=0x10)
    // 0xdff09c: mov             x2, x0
    // 0xdff0a0: ldur            x0, [fp, #-0x48]
    // 0xdff0a4: stur            x2, [fp, #-0x60]
    // 0xdff0a8: StoreField: r2->field_b = r0
    //     0xdff0a8: stur            w0, [x2, #0xb]
    // 0xdff0ac: ldur            x0, [fp, #-0x18]
    // 0xdff0b0: LoadField: r3 = r0->field_f
    //     0xdff0b0: ldur            w3, [x0, #0xf]
    // 0xdff0b4: DecompressPointer r3
    //     0xdff0b4: add             x3, x3, HEAP, lsl #32
    // 0xdff0b8: ldur            x4, [fp, #-8]
    // 0xdff0bc: stur            x3, [fp, #-0x48]
    // 0xdff0c0: LoadField: r1 = r4->field_b
    //     0xdff0c0: ldur            w1, [x4, #0xb]
    // 0xdff0c4: DecompressPointer r1
    //     0xdff0c4: add             x1, x1, HEAP, lsl #32
    // 0xdff0c8: cmp             w1, NULL
    // 0xdff0cc: b.eq            #0xdff9e8
    // 0xdff0d0: mov             x1, x4
    // 0xdff0d4: r0 = _defaults()
    //     0xdff0d4: bl              #0xdffaf8  ; [package:flutter/src/material/tabs.dart] _TabBarState::_defaults
    // 0xdff0d8: r1 = LoadClassIdInstr(r0)
    //     0xdff0d8: ldur            x1, [x0, #-1]
    //     0xdff0dc: ubfx            x1, x1, #0xc, #0x14
    // 0xdff0e0: r17 = 5058
    //     0xdff0e0: mov             x17, #0x13c2
    // 0xdff0e4: cmp             x1, x17
    // 0xdff0e8: b.ne            #0xdff0fc
    // 0xdff0ec: LoadField: r2 = r0->field_33
    //     0xdff0ec: ldur            w2, [x0, #0x33]
    // 0xdff0f0: DecompressPointer r2
    //     0xdff0f0: add             x2, x2, HEAP, lsl #32
    // 0xdff0f4: mov             x9, x2
    // 0xdff0f8: b               #0xdff148
    // 0xdff0fc: r17 = 5059
    //     0xdff0fc: mov             x17, #0x13c3
    // 0xdff100: cmp             x1, x17
    // 0xdff104: b.eq            #0xdff964
    // 0xdff108: r17 = 5060
    //     0xdff108: mov             x17, #0x13c4
    // 0xdff10c: cmp             x1, x17
    // 0xdff110: b.ne            #0xdff130
    // 0xdff114: LoadField: r1 = r0->field_4b
    //     0xdff114: ldur            w1, [x0, #0x4b]
    // 0xdff118: DecompressPointer r1
    //     0xdff118: add             x1, x1, HEAP, lsl #32
    // 0xdff11c: r0 = of()
    //     0xdff11c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdff120: LoadField: r2 = r0->field_2b
    //     0xdff120: ldur            w2, [x0, #0x2b]
    // 0xdff124: DecompressPointer r2
    //     0xdff124: add             x2, x2, HEAP, lsl #32
    // 0xdff128: mov             x9, x2
    // 0xdff12c: b               #0xdff148
    // 0xdff130: LoadField: r1 = r0->field_4b
    //     0xdff130: ldur            w1, [x0, #0x4b]
    // 0xdff134: DecompressPointer r1
    //     0xdff134: add             x1, x1, HEAP, lsl #32
    // 0xdff138: r0 = of()
    //     0xdff138: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdff13c: LoadField: r2 = r0->field_2b
    //     0xdff13c: ldur            w2, [x0, #0x2b]
    // 0xdff140: DecompressPointer r2
    //     0xdff140: add             x2, x2, HEAP, lsl #32
    // 0xdff144: mov             x9, x2
    // 0xdff148: ldur            x4, [fp, #-8]
    // 0xdff14c: ldur            x8, [fp, #-0x20]
    // 0xdff150: ldur            x7, [fp, #-0x30]
    // 0xdff154: ldur            x2, [fp, #-0x18]
    // 0xdff158: ldur            x3, [fp, #-0x48]
    // 0xdff15c: ldur            x0, [fp, #-0x60]
    // 0xdff160: ldur            x6, [fp, #-0x28]
    // 0xdff164: ldur            x5, [fp, #-0x38]
    // 0xdff168: stur            x9, [fp, #-0x68]
    // 0xdff16c: LoadField: r1 = r4->field_b
    //     0xdff16c: ldur            w1, [x4, #0xb]
    // 0xdff170: DecompressPointer r1
    //     0xdff170: add             x1, x1, HEAP, lsl #32
    // 0xdff174: cmp             w1, NULL
    // 0xdff178: b.eq            #0xdff9ec
    // 0xdff17c: mov             x1, x4
    // 0xdff180: r0 = _defaults()
    //     0xdff180: bl              #0xdffaf8  ; [package:flutter/src/material/tabs.dart] _TabBarState::_defaults
    // 0xdff184: ldur            x1, [fp, #-8]
    // 0xdff188: LoadField: r0 = r1->field_b
    //     0xdff188: ldur            w0, [x1, #0xb]
    // 0xdff18c: DecompressPointer r0
    //     0xdff18c: add             x0, x0, HEAP, lsl #32
    // 0xdff190: cmp             w0, NULL
    // 0xdff194: b.eq            #0xdff9f0
    // 0xdff198: r0 = EdgeInsets()
    //     0xdff198: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xdff19c: mov             x4, x0
    // 0xdff1a0: stur            x4, [fp, #-0x80]
    // 0xdff1a4: StoreField: r4->field_7 = rZR
    //     0xdff1a4: stur            xzr, [x4, #7]
    // 0xdff1a8: StoreField: r4->field_f = rZR
    //     0xdff1a8: stur            xzr, [x4, #0xf]
    // 0xdff1ac: ArrayStore: r4[0] = rZR  ; List_8
    //     0xdff1ac: stur            xzr, [x4, #0x17]
    // 0xdff1b0: d0 = 2.000000
    //     0xdff1b0: fmov            d0, #2.00000000
    // 0xdff1b4: StoreField: r4->field_1f = d0
    //     0xdff1b4: stur            d0, [x4, #0x1f]
    // 0xdff1b8: ldur            x5, [fp, #-0x18]
    // 0xdff1bc: LoadField: r2 = r5->field_f
    //     0xdff1bc: ldur            w2, [x5, #0xf]
    // 0xdff1c0: DecompressPointer r2
    //     0xdff1c0: add             x2, x2, HEAP, lsl #32
    // 0xdff1c4: ldur            x6, [fp, #-0x28]
    // 0xdff1c8: LoadField: r0 = r6->field_b
    //     0xdff1c8: ldur            w0, [x6, #0xb]
    // 0xdff1cc: r3 = LoadInt32Instr(r2)
    //     0xdff1cc: sbfx            x3, x2, #1, #0x1f
    //     0xdff1d0: tbz             w2, #0, #0xdff1d8
    //     0xdff1d4: ldur            x3, [x2, #7]
    // 0xdff1d8: r1 = LoadInt32Instr(r0)
    //     0xdff1d8: sbfx            x1, x0, #1, #0x1f
    // 0xdff1dc: mov             x0, x1
    // 0xdff1e0: mov             x1, x3
    // 0xdff1e4: cmp             x1, x0
    // 0xdff1e8: b.hs            #0xdff9f4
    // 0xdff1ec: LoadField: r0 = r6->field_f
    //     0xdff1ec: ldur            w0, [x6, #0xf]
    // 0xdff1f0: DecompressPointer r0
    //     0xdff1f0: add             x0, x0, HEAP, lsl #32
    // 0xdff1f4: ArrayLoad: r7 = r0[r3]  ; Unknown_4
    //     0xdff1f4: add             x16, x0, x3, lsl #2
    //     0xdff1f8: ldur            w7, [x16, #0xf]
    // 0xdff1fc: DecompressPointer r7
    //     0xdff1fc: add             x7, x7, HEAP, lsl #32
    // 0xdff200: ldur            x8, [fp, #-8]
    // 0xdff204: stur            x7, [fp, #-0x78]
    // 0xdff208: LoadField: r0 = r8->field_1f
    //     0xdff208: ldur            w0, [x8, #0x1f]
    // 0xdff20c: DecompressPointer r0
    //     0xdff20c: add             x0, x0, HEAP, lsl #32
    // 0xdff210: cmp             w2, w0
    // 0xdff214: b.eq            #0xdff258
    // 0xdff218: and             w16, w2, w0
    // 0xdff21c: branchIfSmi(r16, 0xdff250)
    //     0xdff21c: tbz             w16, #0, #0xdff250
    // 0xdff220: r16 = LoadClassIdInstr(r2)
    //     0xdff220: ldur            x16, [x2, #-1]
    //     0xdff224: ubfx            x16, x16, #0xc, #0x14
    // 0xdff228: cmp             x16, #0x3d
    // 0xdff22c: b.ne            #0xdff250
    // 0xdff230: r16 = LoadClassIdInstr(r0)
    //     0xdff230: ldur            x16, [x0, #-1]
    //     0xdff234: ubfx            x16, x16, #0xc, #0x14
    // 0xdff238: cmp             x16, #0x3d
    // 0xdff23c: b.ne            #0xdff250
    // 0xdff240: LoadField: r16 = r2->field_7
    //     0xdff240: ldur            x16, [x2, #7]
    // 0xdff244: LoadField: r17 = r0->field_7
    //     0xdff244: ldur            x17, [x0, #7]
    // 0xdff248: cmp             x16, x17
    // 0xdff24c: b.eq            #0xdff258
    // 0xdff250: r9 = false
    //     0xdff250: add             x9, NULL, #0x30  ; false
    // 0xdff254: b               #0xdff25c
    // 0xdff258: r9 = true
    //     0xdff258: add             x9, NULL, #0x20  ; true
    // 0xdff25c: stur            x9, [fp, #-0x70]
    // 0xdff260: add             x0, x3, #1
    // 0xdff264: ldur            x10, [fp, #-0x30]
    // 0xdff268: r1 = LoadClassIdInstr(r10)
    //     0xdff268: ldur            x1, [x10, #-1]
    //     0xdff26c: ubfx            x1, x1, #0xc, #0x14
    // 0xdff270: mov             x3, x0
    // 0xdff274: mov             x0, x1
    // 0xdff278: mov             x1, x10
    // 0xdff27c: ldur            x2, [fp, #-0x50]
    // 0xdff280: r0 = GDT[cid_x0 + 0x15fa0]()
    //     0xdff280: mov             x17, #0x5fa0
    //     0xdff284: movk            x17, #1, lsl #16
    //     0xdff288: add             lr, x0, x17
    //     0xdff28c: ldr             lr, [x21, lr, lsl #3]
    //     0xdff290: blr             lr
    // 0xdff294: stur            x0, [fp, #-0x88]
    // 0xdff298: r0 = Semantics()
    //     0xdff298: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xdff29c: stur            x0, [fp, #-0x90]
    // 0xdff2a0: stp             NULL, NULL, [SP, #0x140]
    // 0xdff2a4: r16 = false
    //     0xdff2a4: add             x16, NULL, #0x30  ; false
    // 0xdff2a8: stp             NULL, x16, [SP, #0x130]
    // 0xdff2ac: r16 = false
    //     0xdff2ac: add             x16, NULL, #0x30  ; false
    // 0xdff2b0: stp             NULL, x16, [SP, #0x120]
    // 0xdff2b4: stp             NULL, NULL, [SP, #0x110]
    // 0xdff2b8: stp             NULL, NULL, [SP, #0x100]
    // 0xdff2bc: stp             NULL, NULL, [SP, #0xf0]
    // 0xdff2c0: ldur            x16, [fp, #-0x88]
    // 0xdff2c4: stp             x16, NULL, [SP, #0xe0]
    // 0xdff2c8: stp             NULL, NULL, [SP, #0xd0]
    // 0xdff2cc: stp             NULL, NULL, [SP, #0xc0]
    // 0xdff2d0: stp             NULL, NULL, [SP, #0xb0]
    // 0xdff2d4: stp             NULL, NULL, [SP, #0xa0]
    // 0xdff2d8: stp             NULL, NULL, [SP, #0x90]
    // 0xdff2dc: stp             NULL, NULL, [SP, #0x80]
    // 0xdff2e0: stp             NULL, NULL, [SP, #0x70]
    // 0xdff2e4: stp             NULL, NULL, [SP, #0x60]
    // 0xdff2e8: stp             NULL, NULL, [SP, #0x50]
    // 0xdff2ec: ldur            x16, [fp, #-0x70]
    // 0xdff2f0: stp             x16, NULL, [SP, #0x40]
    // 0xdff2f4: stp             NULL, NULL, [SP, #0x30]
    // 0xdff2f8: stp             NULL, NULL, [SP, #0x20]
    // 0xdff2fc: stp             NULL, NULL, [SP, #0x10]
    // 0xdff300: r16 = Instance_SemanticsValidationResult
    //     0xdff300: ldr             x16, [PP, #0x26f0]  ; [pp+0x26f0] Obj!SemanticsValidationResult@12c75e1
    // 0xdff304: stp             NULL, x16, [SP]
    // 0xdff308: mov             x1, x0
    // 0xdff30c: r2 = Null
    //     0xdff30c: mov             x2, NULL
    // 0xdff310: r3 = Null
    //     0xdff310: mov             x3, NULL
    // 0xdff314: r5 = Null
    //     0xdff314: mov             x5, NULL
    // 0xdff318: r6 = Null
    //     0xdff318: mov             x6, NULL
    // 0xdff31c: r7 = false
    //     0xdff31c: add             x7, NULL, #0x30  ; false
    // 0xdff320: r0 = _SemanticsBase()
    //     0xdff320: bl              #0x917b7c  ; [package:flutter/src/widgets/basic.dart] _SemanticsBase::_SemanticsBase
    // 0xdff324: r1 = Null
    //     0xdff324: mov             x1, NULL
    // 0xdff328: r2 = 4
    //     0xdff328: mov             x2, #4
    // 0xdff32c: r0 = AllocateArray()
    //     0xdff32c: bl              #0x13df928  ; AllocateArrayStub
    // 0xdff330: mov             x2, x0
    // 0xdff334: ldur            x0, [fp, #-0x78]
    // 0xdff338: stur            x2, [fp, #-0x70]
    // 0xdff33c: StoreField: r2->field_f = r0
    //     0xdff33c: stur            w0, [x2, #0xf]
    // 0xdff340: ldur            x0, [fp, #-0x90]
    // 0xdff344: StoreField: r2->field_13 = r0
    //     0xdff344: stur            w0, [x2, #0x13]
    // 0xdff348: r1 = <Widget>
    //     0xdff348: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdff34c: r0 = AllocateGrowableArray()
    //     0xdff34c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xdff350: mov             x1, x0
    // 0xdff354: ldur            x0, [fp, #-0x70]
    // 0xdff358: stur            x1, [fp, #-0x78]
    // 0xdff35c: StoreField: r1->field_f = r0
    //     0xdff35c: stur            w0, [x1, #0xf]
    // 0xdff360: r0 = 4
    //     0xdff360: mov             x0, #4
    // 0xdff364: StoreField: r1->field_b = r0
    //     0xdff364: stur            w0, [x1, #0xb]
    // 0xdff368: r0 = Stack()
    //     0xdff368: bl              #0xd1a854  ; AllocateStackStub -> Stack (size=0x20)
    // 0xdff36c: mov             x1, x0
    // 0xdff370: r0 = Instance_AlignmentDirectional
    //     0xdff370: add             x0, PP, #0x15, lsl #12  ; [pp+0x158d8] Obj!AlignmentDirectional@129e611
    //     0xdff374: ldr             x0, [x0, #0x8d8]
    // 0xdff378: stur            x1, [fp, #-0x70]
    // 0xdff37c: StoreField: r1->field_f = r0
    //     0xdff37c: stur            w0, [x1, #0xf]
    // 0xdff380: r2 = Instance_StackFit
    //     0xdff380: add             x2, PP, #0x15, lsl #12  ; [pp+0x158e0] Obj!StackFit@12c4221
    //     0xdff384: ldr             x2, [x2, #0x8e0]
    // 0xdff388: ArrayStore: r1[0] = r2  ; List_4
    //     0xdff388: stur            w2, [x1, #0x17]
    // 0xdff38c: r3 = Instance_Clip
    //     0xdff38c: add             x3, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xdff390: ldr             x3, [x3, #0x850]
    // 0xdff394: StoreField: r1->field_1b = r3
    //     0xdff394: stur            w3, [x1, #0x1b]
    // 0xdff398: ldur            x4, [fp, #-0x78]
    // 0xdff39c: StoreField: r1->field_b = r4
    //     0xdff39c: stur            w4, [x1, #0xb]
    // 0xdff3a0: r0 = Semantics()
    //     0xdff3a0: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xdff3a4: stur            x0, [fp, #-0x78]
    // 0xdff3a8: stp             NULL, NULL, [SP, #0x140]
    // 0xdff3ac: r16 = false
    //     0xdff3ac: add             x16, NULL, #0x30  ; false
    // 0xdff3b0: stp             NULL, x16, [SP, #0x130]
    // 0xdff3b4: r16 = false
    //     0xdff3b4: add             x16, NULL, #0x30  ; false
    // 0xdff3b8: stp             NULL, x16, [SP, #0x120]
    // 0xdff3bc: stp             NULL, NULL, [SP, #0x110]
    // 0xdff3c0: stp             NULL, NULL, [SP, #0x100]
    // 0xdff3c4: stp             NULL, NULL, [SP, #0xf0]
    // 0xdff3c8: stp             NULL, NULL, [SP, #0xe0]
    // 0xdff3cc: stp             NULL, NULL, [SP, #0xd0]
    // 0xdff3d0: stp             NULL, NULL, [SP, #0xc0]
    // 0xdff3d4: stp             NULL, NULL, [SP, #0xb0]
    // 0xdff3d8: stp             NULL, NULL, [SP, #0xa0]
    // 0xdff3dc: stp             NULL, NULL, [SP, #0x90]
    // 0xdff3e0: stp             NULL, NULL, [SP, #0x80]
    // 0xdff3e4: stp             NULL, NULL, [SP, #0x70]
    // 0xdff3e8: stp             NULL, NULL, [SP, #0x60]
    // 0xdff3ec: r16 = Instance_SemanticsRole
    //     0xdff3ec: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c5e0] Obj!SemanticsRole@12c79a1
    //     0xdff3f0: ldr             x16, [x16, #0x5e0]
    // 0xdff3f4: stp             x16, NULL, [SP, #0x50]
    // 0xdff3f8: stp             NULL, NULL, [SP, #0x40]
    // 0xdff3fc: stp             NULL, NULL, [SP, #0x30]
    // 0xdff400: stp             NULL, NULL, [SP, #0x20]
    // 0xdff404: stp             NULL, NULL, [SP, #0x10]
    // 0xdff408: r16 = Instance_SemanticsValidationResult
    //     0xdff408: ldr             x16, [PP, #0x26f0]  ; [pp+0x26f0] Obj!SemanticsValidationResult@12c75e1
    // 0xdff40c: stp             NULL, x16, [SP]
    // 0xdff410: mov             x1, x0
    // 0xdff414: ldur            x6, [fp, #-0x70]
    // 0xdff418: r2 = Null
    //     0xdff418: mov             x2, NULL
    // 0xdff41c: r3 = Null
    //     0xdff41c: mov             x3, NULL
    // 0xdff420: r5 = Null
    //     0xdff420: mov             x5, NULL
    // 0xdff424: r7 = false
    //     0xdff424: add             x7, NULL, #0x30  ; false
    // 0xdff428: r0 = _SemanticsBase()
    //     0xdff428: bl              #0x917b7c  ; [package:flutter/src/widgets/basic.dart] _SemanticsBase::_SemanticsBase
    // 0xdff42c: r0 = Padding()
    //     0xdff42c: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xdff430: mov             x1, x0
    // 0xdff434: ldur            x0, [fp, #-0x80]
    // 0xdff438: stur            x1, [fp, #-0x70]
    // 0xdff43c: StoreField: r1->field_f = r0
    //     0xdff43c: stur            w0, [x1, #0xf]
    // 0xdff440: ldur            x0, [fp, #-0x78]
    // 0xdff444: StoreField: r1->field_b = r0
    //     0xdff444: stur            w0, [x1, #0xb]
    // 0xdff448: r0 = InkWell()
    //     0xdff448: bl              #0xd0c57c  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0xdff44c: mov             x3, x0
    // 0xdff450: ldur            x0, [fp, #-0x70]
    // 0xdff454: stur            x3, [fp, #-0x78]
    // 0xdff458: StoreField: r3->field_b = r0
    //     0xdff458: stur            w0, [x3, #0xb]
    // 0xdff45c: ldur            x2, [fp, #-0x18]
    // 0xdff460: r1 = Function '<anonymous closure>':.
    //     0xdff460: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c5e8] AnonymousClosure: (0xdffcd4), in [package:flutter/src/material/tabs.dart] _TabBarState::build (0xdfe5b0)
    //     0xdff464: ldr             x1, [x1, #0x5e8]
    // 0xdff468: r0 = AllocateClosure()
    //     0xdff468: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdff46c: mov             x1, x0
    // 0xdff470: ldur            x0, [fp, #-0x78]
    // 0xdff474: StoreField: r0->field_f = r1
    //     0xdff474: stur            w1, [x0, #0xf]
    // 0xdff478: ldur            x2, [fp, #-0x18]
    // 0xdff47c: r1 = Function '<anonymous closure>':.
    //     0xdff47c: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c5f0] AnonymousClosure: (0xdffc94), in [package:flutter/src/material/tabs.dart] _TabBarState::build (0xdfe5b0)
    //     0xdff480: ldr             x1, [x1, #0x5f0]
    // 0xdff484: r0 = AllocateClosure()
    //     0xdff484: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdff488: mov             x1, x0
    // 0xdff48c: ldur            x0, [fp, #-0x78]
    // 0xdff490: StoreField: r0->field_3f = r1
    //     0xdff490: stur            w1, [x0, #0x3f]
    // 0xdff494: ldur            x1, [fp, #-0x38]
    // 0xdff498: StoreField: r0->field_43 = r1
    //     0xdff498: stur            w1, [x0, #0x43]
    // 0xdff49c: r3 = true
    //     0xdff49c: add             x3, NULL, #0x20  ; true
    // 0xdff4a0: StoreField: r0->field_47 = r3
    //     0xdff4a0: stur            w3, [x0, #0x47]
    // 0xdff4a4: r4 = Instance_BoxShape
    //     0xdff4a4: add             x4, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xdff4a8: ldr             x4, [x4, #0x1f8]
    // 0xdff4ac: StoreField: r0->field_4b = r4
    //     0xdff4ac: stur            w4, [x0, #0x4b]
    // 0xdff4b0: ldur            x1, [fp, #-0x60]
    // 0xdff4b4: StoreField: r0->field_67 = r1
    //     0xdff4b4: stur            w1, [x0, #0x67]
    // 0xdff4b8: ldur            x1, [fp, #-0x68]
    // 0xdff4bc: StoreField: r0->field_6f = r1
    //     0xdff4bc: stur            w1, [x0, #0x6f]
    // 0xdff4c0: StoreField: r0->field_73 = r3
    //     0xdff4c0: stur            w3, [x0, #0x73]
    // 0xdff4c4: r5 = false
    //     0xdff4c4: add             x5, NULL, #0x30  ; false
    // 0xdff4c8: StoreField: r0->field_77 = r5
    //     0xdff4c8: stur            w5, [x0, #0x77]
    // 0xdff4cc: StoreField: r0->field_87 = r3
    //     0xdff4cc: stur            w3, [x0, #0x87]
    // 0xdff4d0: ldur            x2, [fp, #-0x18]
    // 0xdff4d4: r1 = Function '<anonymous closure>':.
    //     0xdff4d4: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c5f8] AnonymousClosure: (0xdffc94), in [package:flutter/src/material/tabs.dart] _TabBarState::build (0xdfe5b0)
    //     0xdff4d8: ldr             x1, [x1, #0x5f8]
    // 0xdff4dc: r0 = AllocateClosure()
    //     0xdff4dc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdff4e0: ldur            x2, [fp, #-0x78]
    // 0xdff4e4: StoreField: r2->field_7b = r0
    //     0xdff4e4: stur            w0, [x2, #0x7b]
    // 0xdff4e8: r3 = false
    //     0xdff4e8: add             x3, NULL, #0x30  ; false
    // 0xdff4ec: StoreField: r2->field_7f = r3
    //     0xdff4ec: stur            w3, [x2, #0x7f]
    // 0xdff4f0: ldur            x4, [fp, #-0x28]
    // 0xdff4f4: LoadField: r0 = r4->field_b
    //     0xdff4f4: ldur            w0, [x4, #0xb]
    // 0xdff4f8: ldur            x1, [fp, #-0x48]
    // 0xdff4fc: r5 = LoadInt32Instr(r1)
    //     0xdff4fc: sbfx            x5, x1, #1, #0x1f
    //     0xdff500: tbz             w1, #0, #0xdff508
    //     0xdff504: ldur            x5, [x1, #7]
    // 0xdff508: r6 = LoadInt32Instr(r0)
    //     0xdff508: sbfx            x6, x0, #1, #0x1f
    // 0xdff50c: mov             x0, x6
    // 0xdff510: mov             x1, x5
    // 0xdff514: cmp             x1, x0
    // 0xdff518: b.hs            #0xdff9f8
    // 0xdff51c: LoadField: r7 = r4->field_f
    //     0xdff51c: ldur            w7, [x4, #0xf]
    // 0xdff520: DecompressPointer r7
    //     0xdff520: add             x7, x7, HEAP, lsl #32
    // 0xdff524: mov             x1, x7
    // 0xdff528: mov             x0, x2
    // 0xdff52c: stur            x7, [fp, #-0x48]
    // 0xdff530: ArrayStore: r1[r5] = r0  ; List_4
    //     0xdff530: add             x25, x1, x5, lsl #2
    //     0xdff534: add             x25, x25, #0xf
    //     0xdff538: str             w0, [x25]
    //     0xdff53c: tbz             w0, #0, #0xdff558
    //     0xdff540: ldurb           w16, [x1, #-1]
    //     0xdff544: ldurb           w17, [x0, #-1]
    //     0xdff548: and             x16, x17, x16, lsr #2
    //     0xdff54c: tst             x16, HEAP, lsr #32
    //     0xdff550: b.eq            #0xdff558
    //     0xdff554: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdff558: ldur            x5, [fp, #-0x18]
    // 0xdff55c: LoadField: r0 = r5->field_f
    //     0xdff55c: ldur            w0, [x5, #0xf]
    // 0xdff560: DecompressPointer r0
    //     0xdff560: add             x0, x0, HEAP, lsl #32
    // 0xdff564: r2 = LoadInt32Instr(r0)
    //     0xdff564: sbfx            x2, x0, #1, #0x1f
    //     0xdff568: tbz             w0, #0, #0xdff570
    //     0xdff56c: ldur            x2, [x0, #7]
    // 0xdff570: mov             x0, x6
    // 0xdff574: mov             x1, x2
    // 0xdff578: stur            x2, [fp, #-0x40]
    // 0xdff57c: cmp             x1, x0
    // 0xdff580: b.hs            #0xdff9fc
    // 0xdff584: ArrayLoad: r0 = r7[r2]  ; Unknown_4
    //     0xdff584: add             x16, x7, x2, lsl #2
    //     0xdff588: ldur            w0, [x16, #0xf]
    // 0xdff58c: DecompressPointer r0
    //     0xdff58c: add             x0, x0, HEAP, lsl #32
    // 0xdff590: stur            x0, [fp, #-0x38]
    // 0xdff594: r0 = MergeSemantics()
    //     0xdff594: bl              #0xd32f80  ; AllocateMergeSemanticsStub -> MergeSemantics (size=0x10)
    // 0xdff598: mov             x2, x0
    // 0xdff59c: ldur            x0, [fp, #-0x38]
    // 0xdff5a0: stur            x2, [fp, #-0x60]
    // 0xdff5a4: StoreField: r2->field_b = r0
    //     0xdff5a4: stur            w0, [x2, #0xb]
    // 0xdff5a8: ldur            x1, [fp, #-0x48]
    // 0xdff5ac: mov             x0, x2
    // 0xdff5b0: ldur            x3, [fp, #-0x40]
    // 0xdff5b4: ArrayStore: r1[r3] = r0  ; List_4
    //     0xdff5b4: add             x25, x1, x3, lsl #2
    //     0xdff5b8: add             x25, x25, #0xf
    //     0xdff5bc: str             w0, [x25]
    //     0xdff5c0: tbz             w0, #0, #0xdff5dc
    //     0xdff5c4: ldurb           w16, [x1, #-1]
    //     0xdff5c8: ldurb           w17, [x0, #-1]
    //     0xdff5cc: and             x16, x17, x16, lsr #2
    //     0xdff5d0: tst             x16, HEAP, lsr #32
    //     0xdff5d4: b.eq            #0xdff5dc
    //     0xdff5d8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdff5dc: ldur            x0, [fp, #-8]
    // 0xdff5e0: LoadField: r4 = r0->field_b
    //     0xdff5e0: ldur            w4, [x0, #0xb]
    // 0xdff5e4: DecompressPointer r4
    //     0xdff5e4: add             x4, x4, HEAP, lsl #32
    // 0xdff5e8: stur            x4, [fp, #-0x38]
    // 0xdff5ec: cmp             w4, NULL
    // 0xdff5f0: b.eq            #0xdffa00
    // 0xdff5f4: ldur            x5, [fp, #-0x20]
    // 0xdff5f8: r16 = Instance_TabAlignment
    //     0xdff5f8: add             x16, PP, #0x26, lsl #12  ; [pp+0x260e8] Obj!TabAlignment@12c4c81
    //     0xdff5fc: ldr             x16, [x16, #0xe8]
    // 0xdff600: cmp             w5, w16
    // 0xdff604: b.ne            #0xdff664
    // 0xdff608: r1 = <FlexParentData>
    //     0xdff608: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xdff60c: ldr             x1, [x1, #0x878]
    // 0xdff610: r0 = Expanded()
    //     0xdff610: bl              #0x8a5b10  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0xdff614: r2 = 1
    //     0xdff614: mov             x2, #1
    // 0xdff618: StoreField: r0->field_13 = r2
    //     0xdff618: stur            x2, [x0, #0x13]
    // 0xdff61c: r3 = Instance_FlexFit
    //     0xdff61c: add             x3, PP, #0x15, lsl #12  ; [pp+0x15880] Obj!FlexFit@12c4641
    //     0xdff620: ldr             x3, [x3, #0x880]
    // 0xdff624: StoreField: r0->field_1b = r3
    //     0xdff624: stur            w3, [x0, #0x1b]
    // 0xdff628: ldur            x1, [fp, #-0x60]
    // 0xdff62c: StoreField: r0->field_b = r1
    //     0xdff62c: stur            w1, [x0, #0xb]
    // 0xdff630: ldur            x1, [fp, #-0x48]
    // 0xdff634: ldur            x4, [fp, #-0x40]
    // 0xdff638: ArrayStore: r1[r4] = r0  ; List_4
    //     0xdff638: add             x25, x1, x4, lsl #2
    //     0xdff63c: add             x25, x25, #0xf
    //     0xdff640: str             w0, [x25]
    //     0xdff644: tbz             w0, #0, #0xdff660
    //     0xdff648: ldurb           w16, [x1, #-1]
    //     0xdff64c: ldurb           w17, [x0, #-1]
    //     0xdff650: and             x16, x17, x16, lsr #2
    //     0xdff654: tst             x16, HEAP, lsr #32
    //     0xdff658: b.eq            #0xdff660
    //     0xdff65c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdff660: b               #0xdff670
    // 0xdff664: r3 = Instance_FlexFit
    //     0xdff664: add             x3, PP, #0x15, lsl #12  ; [pp+0x15880] Obj!FlexFit@12c4641
    //     0xdff668: ldr             x3, [x3, #0x880]
    // 0xdff66c: r2 = 1
    //     0xdff66c: mov             x2, #1
    // 0xdff670: ldur            x5, [fp, #-0x18]
    // 0xdff674: r0 = CloneContext()
    //     0xdff674: bl              #0x13de1f4  ; CloneContextStub
    // 0xdff678: mov             x2, x0
    // 0xdff67c: LoadField: r0 = r2->field_f
    //     0xdff67c: ldur            w0, [x2, #0xf]
    // 0xdff680: DecompressPointer r0
    //     0xdff680: add             x0, x0, HEAP, lsl #32
    // 0xdff684: r1 = LoadInt32Instr(r0)
    //     0xdff684: sbfx            x1, x0, #1, #0x1f
    //     0xdff688: tbz             w0, #0, #0xdff690
    //     0xdff68c: ldur            x1, [x0, #7]
    // 0xdff690: add             x6, x1, #1
    // 0xdff694: r0 = BoxInt64Instr(r6)
    //     0xdff694: sbfiz           x0, x6, #1, #0x1f
    //     0xdff698: cmp             x6, x0, asr #1
    //     0xdff69c: b.eq            #0xdff6a8
    //     0xdff6a0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xdff6a4: stur            x6, [x0, #7]
    // 0xdff6a8: StoreField: r2->field_f = r0
    //     0xdff6a8: stur            w0, [x2, #0xf]
    //     0xdff6ac: tbz             w0, #0, #0xdff6c8
    //     0xdff6b0: ldurb           w16, [x2, #-1]
    //     0xdff6b4: ldurb           w17, [x0, #-1]
    //     0xdff6b8: and             x16, x17, x16, lsr #2
    //     0xdff6bc: tst             x16, HEAP, lsr #32
    //     0xdff6c0: b.eq            #0xdff6c8
    //     0xdff6c4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xdff6c8: mov             x7, x2
    // 0xdff6cc: ldur            x1, [fp, #-0x38]
    // 0xdff6d0: ldur            x2, [fp, #-0x50]
    // 0xdff6d4: b               #0xdfeebc
    // 0xdff6d8: mov             x0, x3
    // 0xdff6dc: mov             x2, x5
    // 0xdff6e0: LoadField: r3 = r0->field_1b
    //     0xdff6e0: ldur            w3, [x0, #0x1b]
    // 0xdff6e4: DecompressPointer r3
    //     0xdff6e4: add             x3, x3, HEAP, lsl #32
    // 0xdff6e8: stur            x3, [fp, #-0x60]
    // 0xdff6ec: LoadField: r4 = r1->field_43
    //     0xdff6ec: ldur            w4, [x1, #0x43]
    // 0xdff6f0: DecompressPointer r4
    //     0xdff6f0: add             x4, x4, HEAP, lsl #32
    // 0xdff6f4: stur            x4, [fp, #-0x48]
    // 0xdff6f8: LoadField: r5 = r1->field_47
    //     0xdff6f8: ldur            w5, [x1, #0x47]
    // 0xdff6fc: DecompressPointer r5
    //     0xdff6fc: add             x5, x5, HEAP, lsl #32
    // 0xdff700: stur            x5, [fp, #-0x38]
    // 0xdff704: LoadField: r6 = r1->field_4b
    //     0xdff704: ldur            w6, [x1, #0x4b]
    // 0xdff708: DecompressPointer r6
    //     0xdff708: add             x6, x6, HEAP, lsl #32
    // 0xdff70c: stur            x6, [fp, #-0x30]
    // 0xdff710: LoadField: r7 = r1->field_4f
    //     0xdff710: ldur            w7, [x1, #0x4f]
    // 0xdff714: DecompressPointer r7
    //     0xdff714: add             x7, x7, HEAP, lsl #32
    // 0xdff718: mov             x1, x0
    // 0xdff71c: stur            x7, [fp, #-0x18]
    // 0xdff720: r0 = _defaults()
    //     0xdff720: bl              #0xdffaf8  ; [package:flutter/src/material/tabs.dart] _TabBarState::_defaults
    // 0xdff724: mov             x3, x0
    // 0xdff728: ldur            x0, [fp, #-0x20]
    // 0xdff72c: stur            x3, [fp, #-0x68]
    // 0xdff730: r16 = Instance_TabAlignment
    //     0xdff730: add             x16, PP, #0x26, lsl #12  ; [pp+0x260e8] Obj!TabAlignment@12c4c81
    //     0xdff734: ldr             x16, [x16, #0xe8]
    // 0xdff738: cmp             w0, w16
    // 0xdff73c: b.ne            #0xdff74c
    // 0xdff740: r10 = Instance_MainAxisSize
    //     0xdff740: add             x10, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xdff744: ldr             x10, [x10, #0x828]
    // 0xdff748: b               #0xdff754
    // 0xdff74c: r10 = Instance_MainAxisSize
    //     0xdff74c: add             x10, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xdff750: ldr             x10, [x10, #0x200]
    // 0xdff754: ldur            x0, [fp, #-8]
    // 0xdff758: ldur            x4, [fp, #-0x60]
    // 0xdff75c: ldur            x5, [fp, #-0x48]
    // 0xdff760: ldur            x6, [fp, #-0x38]
    // 0xdff764: ldur            x7, [fp, #-0x30]
    // 0xdff768: ldur            x8, [fp, #-0x18]
    // 0xdff76c: ldur            x9, [fp, #-0x28]
    // 0xdff770: mov             x2, x0
    // 0xdff774: stur            x10, [fp, #-0x20]
    // 0xdff778: r1 = Function '_saveTabOffsets@780014024':.
    //     0xdff778: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c600] AnonymousClosure: (0xbbf45c), in [package:flutter/src/material/tabs.dart] _TabBarState::_saveTabOffsets (0xbbf4a0)
    //     0xdff77c: ldr             x1, [x1, #0x600]
    // 0xdff780: r0 = AllocateClosure()
    //     0xdff780: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdff784: stur            x0, [fp, #-0x70]
    // 0xdff788: r0 = _TabLabelBar()
    //     0xdff788: bl              #0xdffa18  ; Allocate_TabLabelBarStub -> _TabLabelBar (size=0x3c)
    // 0xdff78c: mov             x1, x0
    // 0xdff790: ldur            x0, [fp, #-0x70]
    // 0xdff794: stur            x1, [fp, #-0x78]
    // 0xdff798: StoreField: r1->field_37 = r0
    //     0xdff798: stur            w0, [x1, #0x37]
    // 0xdff79c: r0 = Instance_Axis
    //     0xdff79c: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xdff7a0: StoreField: r1->field_f = r0
    //     0xdff7a0: stur            w0, [x1, #0xf]
    // 0xdff7a4: r0 = Instance_MainAxisAlignment
    //     0xdff7a4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xdff7a8: ldr             x0, [x0, #0x820]
    // 0xdff7ac: StoreField: r1->field_13 = r0
    //     0xdff7ac: stur            w0, [x1, #0x13]
    // 0xdff7b0: ldur            x0, [fp, #-0x20]
    // 0xdff7b4: ArrayStore: r1[0] = r0  ; List_4
    //     0xdff7b4: stur            w0, [x1, #0x17]
    // 0xdff7b8: r0 = Instance_CrossAxisAlignment
    //     0xdff7b8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xdff7bc: ldr             x0, [x0, #0x888]
    // 0xdff7c0: StoreField: r1->field_1b = r0
    //     0xdff7c0: stur            w0, [x1, #0x1b]
    // 0xdff7c4: r0 = Instance_VerticalDirection
    //     0xdff7c4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xdff7c8: ldr             x0, [x0, #0x838]
    // 0xdff7cc: StoreField: r1->field_23 = r0
    //     0xdff7cc: stur            w0, [x1, #0x23]
    // 0xdff7d0: r0 = Instance_Clip
    //     0xdff7d0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdff7d4: ldr             x0, [x0, #0x840]
    // 0xdff7d8: StoreField: r1->field_2b = r0
    //     0xdff7d8: stur            w0, [x1, #0x2b]
    // 0xdff7dc: StoreField: r1->field_2f = rZR
    //     0xdff7dc: stur            xzr, [x1, #0x2f]
    // 0xdff7e0: ldur            x2, [fp, #-0x28]
    // 0xdff7e4: StoreField: r1->field_b = r2
    //     0xdff7e4: stur            w2, [x1, #0xb]
    // 0xdff7e8: r0 = _TabStyle()
    //     0xdff7e8: bl              #0xdffa0c  ; Allocate_TabStyleStub -> _TabStyle (size=0x2c)
    // 0xdff7ec: mov             x1, x0
    // 0xdff7f0: r0 = false
    //     0xdff7f0: add             x0, NULL, #0x30  ; false
    // 0xdff7f4: stur            x1, [fp, #-0x20]
    // 0xdff7f8: ArrayStore: r1[0] = r0  ; List_4
    //     0xdff7f8: stur            w0, [x1, #0x17]
    // 0xdff7fc: ldur            x2, [fp, #-0x48]
    // 0xdff800: StoreField: r1->field_1b = r2
    //     0xdff800: stur            w2, [x1, #0x1b]
    // 0xdff804: ldur            x2, [fp, #-0x38]
    // 0xdff808: StoreField: r1->field_1f = r2
    //     0xdff808: stur            w2, [x1, #0x1f]
    // 0xdff80c: ldur            x2, [fp, #-0x30]
    // 0xdff810: StoreField: r1->field_f = r2
    //     0xdff810: stur            w2, [x1, #0xf]
    // 0xdff814: ldur            x2, [fp, #-0x18]
    // 0xdff818: StoreField: r1->field_13 = r2
    //     0xdff818: stur            w2, [x1, #0x13]
    // 0xdff81c: ldur            x2, [fp, #-0x68]
    // 0xdff820: StoreField: r1->field_23 = r2
    //     0xdff820: stur            w2, [x1, #0x23]
    // 0xdff824: ldur            x2, [fp, #-0x78]
    // 0xdff828: StoreField: r1->field_27 = r2
    //     0xdff828: stur            w2, [x1, #0x27]
    // 0xdff82c: r2 = Instance__AlwaysDismissedAnimation
    //     0xdff82c: add             x2, PP, #0x14, lsl #12  ; [pp+0x14e60] Obj!_AlwaysDismissedAnimation@12aa3e1
    //     0xdff830: ldr             x2, [x2, #0xe60]
    // 0xdff834: StoreField: r1->field_b = r2
    //     0xdff834: stur            w2, [x1, #0xb]
    // 0xdff838: r0 = CustomPaint()
    //     0xdff838: bl              #0xd0a594  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0xdff83c: mov             x1, x0
    // 0xdff840: ldur            x0, [fp, #-0x60]
    // 0xdff844: stur            x1, [fp, #-0x18]
    // 0xdff848: StoreField: r1->field_f = r0
    //     0xdff848: stur            w0, [x1, #0xf]
    // 0xdff84c: r0 = Instance_Size
    //     0xdff84c: ldr             x0, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xdff850: ArrayStore: r1[0] = r0  ; List_4
    //     0xdff850: stur            w0, [x1, #0x17]
    // 0xdff854: r0 = false
    //     0xdff854: add             x0, NULL, #0x30  ; false
    // 0xdff858: StoreField: r1->field_1b = r0
    //     0xdff858: stur            w0, [x1, #0x1b]
    // 0xdff85c: StoreField: r1->field_1f = r0
    //     0xdff85c: stur            w0, [x1, #0x1f]
    // 0xdff860: ldur            x2, [fp, #-0x20]
    // 0xdff864: StoreField: r1->field_b = r2
    //     0xdff864: stur            w2, [x1, #0xb]
    // 0xdff868: r0 = Semantics()
    //     0xdff868: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xdff86c: stur            x0, [fp, #-0x20]
    // 0xdff870: r16 = Instance_SemanticsRole
    //     0xdff870: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c608] Obj!SemanticsRole@12c7981
    //     0xdff874: ldr             x16, [x16, #0x608]
    // 0xdff878: r30 = true
    //     0xdff878: add             lr, NULL, #0x20  ; true
    // 0xdff87c: stp             lr, x16, [SP, #0x10]
    // 0xdff880: r16 = true
    //     0xdff880: add             x16, NULL, #0x20  ; true
    // 0xdff884: ldur            lr, [fp, #-0x18]
    // 0xdff888: stp             lr, x16, [SP]
    // 0xdff88c: mov             x1, x0
    // 0xdff890: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, container, 0x2, explicitChildNodes, 0x3, role, 0x1, null]
    //     0xdff890: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8c610] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "container", 0x2, "explicitChildNodes", 0x3, "role", 0x1, Null]
    //     0xdff894: ldr             x4, [x4, #0x610]
    // 0xdff898: r0 = Semantics()
    //     0xdff898: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xdff89c: ldur            x0, [fp, #-8]
    // 0xdff8a0: LoadField: r1 = r0->field_b
    //     0xdff8a0: ldur            w1, [x0, #0xb]
    // 0xdff8a4: DecompressPointer r1
    //     0xdff8a4: add             x1, x1, HEAP, lsl #32
    // 0xdff8a8: cmp             w1, NULL
    // 0xdff8ac: b.eq            #0xdffa04
    // 0xdff8b0: ldur            x1, [fp, #-0x10]
    // 0xdff8b4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xdff8b4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xdff8b8: r0 = _of()
    //     0xdff8b8: bl              #0x8651cc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0xdff8bc: mov             x1, x0
    // 0xdff8c0: ldur            x0, [fp, #-8]
    // 0xdff8c4: LoadField: r2 = r0->field_b
    //     0xdff8c4: ldur            w2, [x0, #0xb]
    // 0xdff8c8: DecompressPointer r2
    //     0xdff8c8: add             x2, x2, HEAP, lsl #32
    // 0xdff8cc: cmp             w2, NULL
    // 0xdff8d0: b.eq            #0xdffa08
    // 0xdff8d4: str             NULL, [SP]
    // 0xdff8d8: r4 = const [0, 0x2, 0x1, 0x1, textScaler, 0x1, null]
    //     0xdff8d8: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1e490] List(7) [0, 0x2, 0x1, 0x1, "textScaler", 0x1, Null]
    //     0xdff8dc: ldr             x4, [x4, #0x490]
    // 0xdff8e0: r0 = copyWith()
    //     0xdff8e0: bl              #0xd0aa98  ; [package:flutter/src/widgets/media_query.dart] MediaQueryData::copyWith
    // 0xdff8e4: r1 = <_MediaQueryAspect>
    //     0xdff8e4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12828] TypeArguments: <_MediaQueryAspect>
    //     0xdff8e8: ldr             x1, [x1, #0x828]
    // 0xdff8ec: stur            x0, [fp, #-8]
    // 0xdff8f0: r0 = MediaQuery()
    //     0xdff8f0: bl              #0xd0af24  ; AllocateMediaQueryStub -> MediaQuery (size=0x18)
    // 0xdff8f4: mov             x1, x0
    // 0xdff8f8: ldur            x0, [fp, #-8]
    // 0xdff8fc: stur            x1, [fp, #-0x10]
    // 0xdff900: StoreField: r1->field_13 = r0
    //     0xdff900: stur            w0, [x1, #0x13]
    // 0xdff904: ldur            x0, [fp, #-0x20]
    // 0xdff908: StoreField: r1->field_b = r0
    //     0xdff908: stur            w0, [x1, #0xb]
    // 0xdff90c: r0 = Material()
    //     0xdff90c: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xdff910: mov             x1, x0
    // 0xdff914: r0 = Instance_MaterialType
    //     0xdff914: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8c618] Obj!MaterialType@12c5361
    //     0xdff918: ldr             x0, [x0, #0x618]
    // 0xdff91c: StoreField: r1->field_f = r0
    //     0xdff91c: stur            w0, [x1, #0xf]
    // 0xdff920: ArrayStore: r1[0] = rZR  ; List_8
    //     0xdff920: stur            xzr, [x1, #0x17]
    // 0xdff924: r0 = true
    //     0xdff924: add             x0, NULL, #0x20  ; true
    // 0xdff928: StoreField: r1->field_33 = r0
    //     0xdff928: stur            w0, [x1, #0x33]
    // 0xdff92c: r0 = Instance_Clip
    //     0xdff92c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdff930: ldr             x0, [x0, #0x840]
    // 0xdff934: StoreField: r1->field_37 = r0
    //     0xdff934: stur            w0, [x1, #0x37]
    // 0xdff938: r0 = Instance_Duration
    //     0xdff938: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xdff93c: ldr             x0, [x0, #0x318]
    // 0xdff940: StoreField: r1->field_3b = r0
    //     0xdff940: stur            w0, [x1, #0x3b]
    // 0xdff944: ldur            x0, [fp, #-0x10]
    // 0xdff948: StoreField: r1->field_b = r0
    //     0xdff948: stur            w0, [x1, #0xb]
    // 0xdff94c: r0 = false
    //     0xdff94c: add             x0, NULL, #0x30  ; false
    // 0xdff950: StoreField: r1->field_13 = r0
    //     0xdff950: stur            w0, [x1, #0x13]
    // 0xdff954: mov             x0, x1
    // 0xdff958: LeaveFrame
    //     0xdff958: mov             SP, fp
    //     0xdff95c: ldp             fp, lr, [SP], #0x10
    // 0xdff960: ret
    //     0xdff960: ret             
    // 0xdff964: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xdff964: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xdff968: r0 = Throw()
    //     0xdff968: bl              #0x13ddb2c  ; ThrowStub
    // 0xdff96c: brk             #0
    // 0xdff970: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdff970: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdff974: b               #0xdfe5d8
    // 0xdff978: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdff978: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdff97c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdff97c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdff980: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdff980: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdff984: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdff984: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdff988: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdff988: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdff98c: b               #0xdfe780
    // 0xdff990: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdff990: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdff994: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdff994: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdff998: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdff998: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdff99c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdff99c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdff9a0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdff9a0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdff9a4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdff9a4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdff9a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdff9a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdff9ac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdff9ac: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdff9b0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdff9b0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdff9b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdff9b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdff9b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdff9b8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdff9bc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdff9bc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdff9c0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdff9c0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdff9c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdff9c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdff9c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdff9c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdff9cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdff9cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdff9d0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdff9d0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdff9d4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdff9d4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdff9d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdff9d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdff9dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdff9dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdff9e0: b               #0xdfeee0
    // 0xdff9e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdff9e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdff9e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdff9e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdff9ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdff9ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdff9f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdff9f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdff9f4: r0 = RangeErrorSharedWithFPURegs()
    //     0xdff9f4: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xdff9f8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdff9f8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdff9fc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdff9fc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdffa00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdffa00: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdffa04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdffa04: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdffa08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdffa08: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildStyledTab(/* No info */) {
    // ** addr: 0xdffa3c, size: 0xb0
    // 0xdffa3c: EnterFrame
    //     0xdffa3c: stp             fp, lr, [SP, #-0x10]!
    //     0xdffa40: mov             fp, SP
    // 0xdffa44: AllocStack(0x40)
    //     0xdffa44: sub             SP, SP, #0x40
    // 0xdffa48: SetupParameters(dynamic _ /* r2 => r2, fp-0x28 */, dynamic _ /* r3 => r3, fp-0x30 */, dynamic _ /* r5 => r5, fp-0x38 */, dynamic _ /* r6 => r6, fp-0x40 */)
    //     0xdffa48: stur            x2, [fp, #-0x28]
    //     0xdffa4c: stur            x3, [fp, #-0x30]
    //     0xdffa50: stur            x5, [fp, #-0x38]
    //     0xdffa54: stur            x6, [fp, #-0x40]
    // 0xdffa58: LoadField: r0 = r1->field_b
    //     0xdffa58: ldur            w0, [x1, #0xb]
    // 0xdffa5c: DecompressPointer r0
    //     0xdffa5c: add             x0, x0, HEAP, lsl #32
    // 0xdffa60: cmp             w0, NULL
    // 0xdffa64: b.eq            #0xdffae8
    // 0xdffa68: LoadField: r1 = r0->field_43
    //     0xdffa68: ldur            w1, [x0, #0x43]
    // 0xdffa6c: DecompressPointer r1
    //     0xdffa6c: add             x1, x1, HEAP, lsl #32
    // 0xdffa70: stur            x1, [fp, #-0x20]
    // 0xdffa74: LoadField: r4 = r0->field_47
    //     0xdffa74: ldur            w4, [x0, #0x47]
    // 0xdffa78: DecompressPointer r4
    //     0xdffa78: add             x4, x4, HEAP, lsl #32
    // 0xdffa7c: stur            x4, [fp, #-0x18]
    // 0xdffa80: LoadField: r7 = r0->field_4b
    //     0xdffa80: ldur            w7, [x0, #0x4b]
    // 0xdffa84: DecompressPointer r7
    //     0xdffa84: add             x7, x7, HEAP, lsl #32
    // 0xdffa88: stur            x7, [fp, #-0x10]
    // 0xdffa8c: LoadField: r8 = r0->field_4f
    //     0xdffa8c: ldur            w8, [x0, #0x4f]
    // 0xdffa90: DecompressPointer r8
    //     0xdffa90: add             x8, x8, HEAP, lsl #32
    // 0xdffa94: stur            x8, [fp, #-8]
    // 0xdffa98: r0 = _TabStyle()
    //     0xdffa98: bl              #0xdffa0c  ; Allocate_TabStyleStub -> _TabStyle (size=0x2c)
    // 0xdffa9c: ldur            x1, [fp, #-0x30]
    // 0xdffaa0: ArrayStore: r0[0] = r1  ; List_4
    //     0xdffaa0: stur            w1, [x0, #0x17]
    // 0xdffaa4: ldur            x1, [fp, #-0x20]
    // 0xdffaa8: StoreField: r0->field_1b = r1
    //     0xdffaa8: stur            w1, [x0, #0x1b]
    // 0xdffaac: ldur            x1, [fp, #-0x18]
    // 0xdffab0: StoreField: r0->field_1f = r1
    //     0xdffab0: stur            w1, [x0, #0x1f]
    // 0xdffab4: ldur            x1, [fp, #-0x10]
    // 0xdffab8: StoreField: r0->field_f = r1
    //     0xdffab8: stur            w1, [x0, #0xf]
    // 0xdffabc: ldur            x1, [fp, #-8]
    // 0xdffac0: StoreField: r0->field_13 = r1
    //     0xdffac0: stur            w1, [x0, #0x13]
    // 0xdffac4: ldur            x1, [fp, #-0x40]
    // 0xdffac8: StoreField: r0->field_23 = r1
    //     0xdffac8: stur            w1, [x0, #0x23]
    // 0xdffacc: ldur            x1, [fp, #-0x28]
    // 0xdffad0: StoreField: r0->field_27 = r1
    //     0xdffad0: stur            w1, [x0, #0x27]
    // 0xdffad4: ldur            x1, [fp, #-0x38]
    // 0xdffad8: StoreField: r0->field_b = r1
    //     0xdffad8: stur            w1, [x0, #0xb]
    // 0xdffadc: LeaveFrame
    //     0xdffadc: mov             SP, fp
    //     0xdffae0: ldp             fp, lr, [SP], #0x10
    // 0xdffae4: ret
    //     0xdffae4: ret             
    // 0xdffae8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdffae8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _defaults(/* No info */) {
    // ** addr: 0xdffaf8, size: 0x128
    // 0xdffaf8: EnterFrame
    //     0xdffaf8: stp             fp, lr, [SP, #-0x10]!
    //     0xdffafc: mov             fp, SP
    // 0xdffb00: AllocStack(0x10)
    //     0xdffb00: sub             SP, SP, #0x10
    // 0xdffb04: SetupParameters(_TabBarState this /* r1 => r0, fp-0x8 */)
    //     0xdffb04: mov             x0, x1
    //     0xdffb08: stur            x1, [fp, #-8]
    // 0xdffb0c: CheckStackOverflow
    //     0xdffb0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdffb10: cmp             SP, x16
    //     0xdffb14: b.ls            #0xdffc04
    // 0xdffb18: LoadField: r1 = r0->field_f
    //     0xdffb18: ldur            w1, [x0, #0xf]
    // 0xdffb1c: DecompressPointer r1
    //     0xdffb1c: add             x1, x1, HEAP, lsl #32
    // 0xdffb20: cmp             w1, NULL
    // 0xdffb24: b.eq            #0xdffc0c
    // 0xdffb28: r0 = of()
    //     0xdffb28: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdffb2c: LoadField: r1 = r0->field_2f
    //     0xdffb2c: ldur            w1, [x0, #0x2f]
    // 0xdffb30: DecompressPointer r1
    //     0xdffb30: add             x1, x1, HEAP, lsl #32
    // 0xdffb34: tbnz            w1, #4, #0xdffb98
    // 0xdffb38: ldur            x0, [fp, #-8]
    // 0xdffb3c: LoadField: r1 = r0->field_b
    //     0xdffb3c: ldur            w1, [x0, #0xb]
    // 0xdffb40: DecompressPointer r1
    //     0xdffb40: add             x1, x1, HEAP, lsl #32
    // 0xdffb44: cmp             w1, NULL
    // 0xdffb48: b.eq            #0xdffc10
    // 0xdffb4c: LoadField: r1 = r0->field_f
    //     0xdffb4c: ldur            w1, [x0, #0xf]
    // 0xdffb50: DecompressPointer r1
    //     0xdffb50: add             x1, x1, HEAP, lsl #32
    // 0xdffb54: stur            x1, [fp, #-0x10]
    // 0xdffb58: cmp             w1, NULL
    // 0xdffb5c: b.eq            #0xdffc14
    // 0xdffb60: r0 = _TabsPrimaryDefaultsM3()
    //     0xdffb60: bl              #0xdffc2c  ; Allocate_TabsPrimaryDefaultsM3Stub -> _TabsPrimaryDefaultsM3 (size=0x5c)
    // 0xdffb64: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xdffb68: StoreField: r0->field_4f = r1
    //     0xdffb68: stur            w1, [x0, #0x4f]
    // 0xdffb6c: StoreField: r0->field_53 = r1
    //     0xdffb6c: stur            w1, [x0, #0x53]
    // 0xdffb70: ldur            x1, [fp, #-0x10]
    // 0xdffb74: StoreField: r0->field_4b = r1
    //     0xdffb74: stur            w1, [x0, #0x4b]
    // 0xdffb78: r2 = false
    //     0xdffb78: add             x2, NULL, #0x30  ; false
    // 0xdffb7c: StoreField: r0->field_57 = r2
    //     0xdffb7c: stur            w2, [x0, #0x57]
    // 0xdffb80: r1 = Instance_TabBarIndicatorSize
    //     0xdffb80: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c670] Obj!TabBarIndicatorSize@12c4ce1
    //     0xdffb84: ldr             x1, [x1, #0x670]
    // 0xdffb88: StoreField: r0->field_f = r1
    //     0xdffb88: stur            w1, [x0, #0xf]
    // 0xdffb8c: LeaveFrame
    //     0xdffb8c: mov             SP, fp
    //     0xdffb90: ldp             fp, lr, [SP], #0x10
    // 0xdffb94: ret
    //     0xdffb94: ret             
    // 0xdffb98: ldur            x0, [fp, #-8]
    // 0xdffb9c: r2 = false
    //     0xdffb9c: add             x2, NULL, #0x30  ; false
    // 0xdffba0: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xdffba4: LoadField: r3 = r0->field_f
    //     0xdffba4: ldur            w3, [x0, #0xf]
    // 0xdffba8: DecompressPointer r3
    //     0xdffba8: add             x3, x3, HEAP, lsl #32
    // 0xdffbac: stur            x3, [fp, #-0x10]
    // 0xdffbb0: cmp             w3, NULL
    // 0xdffbb4: b.eq            #0xdffc18
    // 0xdffbb8: LoadField: r4 = r0->field_b
    //     0xdffbb8: ldur            w4, [x0, #0xb]
    // 0xdffbbc: DecompressPointer r4
    //     0xdffbbc: add             x4, x4, HEAP, lsl #32
    // 0xdffbc0: cmp             w4, NULL
    // 0xdffbc4: b.eq            #0xdffc1c
    // 0xdffbc8: r0 = _TabsDefaultsM2()
    //     0xdffbc8: bl              #0xdffc20  ; Allocate_TabsDefaultsM2Stub -> _TabsDefaultsM2 (size=0x60)
    // 0xdffbcc: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xdffbd0: StoreField: r0->field_4f = r1
    //     0xdffbd0: stur            w1, [x0, #0x4f]
    // 0xdffbd4: StoreField: r0->field_53 = r1
    //     0xdffbd4: stur            w1, [x0, #0x53]
    // 0xdffbd8: StoreField: r0->field_57 = r1
    //     0xdffbd8: stur            w1, [x0, #0x57]
    // 0xdffbdc: ldur            x1, [fp, #-0x10]
    // 0xdffbe0: StoreField: r0->field_4b = r1
    //     0xdffbe0: stur            w1, [x0, #0x4b]
    // 0xdffbe4: r1 = false
    //     0xdffbe4: add             x1, NULL, #0x30  ; false
    // 0xdffbe8: StoreField: r0->field_5b = r1
    //     0xdffbe8: stur            w1, [x0, #0x5b]
    // 0xdffbec: r1 = Instance_TabBarIndicatorSize
    //     0xdffbec: add             x1, PP, #0x1b, lsl #12  ; [pp+0x1bda8] Obj!TabBarIndicatorSize@12c4d01
    //     0xdffbf0: ldr             x1, [x1, #0xda8]
    // 0xdffbf4: StoreField: r0->field_f = r1
    //     0xdffbf4: stur            w1, [x0, #0xf]
    // 0xdffbf8: LeaveFrame
    //     0xdffbf8: mov             SP, fp
    //     0xdffbfc: ldp             fp, lr, [SP], #0x10
    // 0xdffc00: ret
    //     0xdffc00: ret             
    // 0xdffc04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdffc04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdffc08: b               #0xdffb18
    // 0xdffc0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdffc0c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdffc10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdffc10: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdffc14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdffc14: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdffc18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdffc18: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdffc1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdffc1c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, bool) {
    // ** addr: 0xdffc94, size: 0x40
    // 0xdffc94: ldr             x1, [SP, #8]
    // 0xdffc98: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xdffc98: ldur            w2, [x1, #0x17]
    // 0xdffc9c: DecompressPointer r2
    //     0xdffc9c: add             x2, x2, HEAP, lsl #32
    // 0xdffca0: LoadField: r1 = r2->field_b
    //     0xdffca0: ldur            w1, [x2, #0xb]
    // 0xdffca4: DecompressPointer r1
    //     0xdffca4: add             x1, x1, HEAP, lsl #32
    // 0xdffca8: LoadField: r2 = r1->field_f
    //     0xdffca8: ldur            w2, [x1, #0xf]
    // 0xdffcac: DecompressPointer r2
    //     0xdffcac: add             x2, x2, HEAP, lsl #32
    // 0xdffcb0: LoadField: r1 = r2->field_b
    //     0xdffcb0: ldur            w1, [x2, #0xb]
    // 0xdffcb4: DecompressPointer r1
    //     0xdffcb4: add             x1, x1, HEAP, lsl #32
    // 0xdffcb8: cmp             w1, NULL
    // 0xdffcbc: b.eq            #0xdffcc8
    // 0xdffcc0: r0 = Null
    //     0xdffcc0: mov             x0, NULL
    // 0xdffcc4: ret
    //     0xdffcc4: ret             
    // 0xdffcc8: EnterFrame
    //     0xdffcc8: stp             fp, lr, [SP, #-0x10]!
    //     0xdffccc: mov             fp, SP
    // 0xdffcd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdffcd0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdffcd4, size: 0x6c
    // 0xdffcd4: EnterFrame
    //     0xdffcd4: stp             fp, lr, [SP, #-0x10]!
    //     0xdffcd8: mov             fp, SP
    // 0xdffcdc: ldr             x0, [fp, #0x10]
    // 0xdffce0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdffce0: ldur            w1, [x0, #0x17]
    // 0xdffce4: DecompressPointer r1
    //     0xdffce4: add             x1, x1, HEAP, lsl #32
    // 0xdffce8: CheckStackOverflow
    //     0xdffce8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdffcec: cmp             SP, x16
    //     0xdffcf0: b.ls            #0xdffd38
    // 0xdffcf4: LoadField: r0 = r1->field_b
    //     0xdffcf4: ldur            w0, [x1, #0xb]
    // 0xdffcf8: DecompressPointer r0
    //     0xdffcf8: add             x0, x0, HEAP, lsl #32
    // 0xdffcfc: LoadField: r2 = r0->field_f
    //     0xdffcfc: ldur            w2, [x0, #0xf]
    // 0xdffd00: DecompressPointer r2
    //     0xdffd00: add             x2, x2, HEAP, lsl #32
    // 0xdffd04: LoadField: r0 = r1->field_f
    //     0xdffd04: ldur            w0, [x1, #0xf]
    // 0xdffd08: DecompressPointer r0
    //     0xdffd08: add             x0, x0, HEAP, lsl #32
    // 0xdffd0c: r1 = LoadInt32Instr(r0)
    //     0xdffd0c: sbfx            x1, x0, #1, #0x1f
    //     0xdffd10: tbz             w0, #0, #0xdffd18
    //     0xdffd14: ldur            x1, [x0, #7]
    // 0xdffd18: mov             x16, x1
    // 0xdffd1c: mov             x1, x2
    // 0xdffd20: mov             x2, x16
    // 0xdffd24: r0 = _handleTap()
    //     0xdffd24: bl              #0xdffd40  ; [package:flutter/src/material/tabs.dart] _TabBarState::_handleTap
    // 0xdffd28: r0 = Null
    //     0xdffd28: mov             x0, NULL
    // 0xdffd2c: LeaveFrame
    //     0xdffd2c: mov             SP, fp
    //     0xdffd30: ldp             fp, lr, [SP], #0x10
    // 0xdffd34: ret
    //     0xdffd34: ret             
    // 0xdffd38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdffd38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdffd3c: b               #0xdffcf4
  }
  _ _handleTap(/* No info */) {
    // ** addr: 0xdffd40, size: 0xb0
    // 0xdffd40: EnterFrame
    //     0xdffd40: stp             fp, lr, [SP, #-0x10]!
    //     0xdffd44: mov             fp, SP
    // 0xdffd48: AllocStack(0x20)
    //     0xdffd48: sub             SP, SP, #0x20
    // 0xdffd4c: SetupParameters(_TabBarState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xdffd4c: mov             x3, x1
    //     0xdffd50: mov             x0, x2
    //     0xdffd54: stur            x1, [fp, #-8]
    //     0xdffd58: stur            x2, [fp, #-0x10]
    // 0xdffd5c: CheckStackOverflow
    //     0xdffd5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdffd60: cmp             SP, x16
    //     0xdffd64: b.ls            #0xdffde0
    // 0xdffd68: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xdffd68: ldur            w1, [x3, #0x17]
    // 0xdffd6c: DecompressPointer r1
    //     0xdffd6c: add             x1, x1, HEAP, lsl #32
    // 0xdffd70: cmp             w1, NULL
    // 0xdffd74: b.eq            #0xdffde8
    // 0xdffd78: mov             x2, x0
    // 0xdffd7c: r0 = animateTo()
    //     0xdffd7c: bl              #0xdffdf0  ; [package:flutter/src/material/tab_controller.dart] TabController::animateTo
    // 0xdffd80: ldur            x0, [fp, #-8]
    // 0xdffd84: LoadField: r1 = r0->field_b
    //     0xdffd84: ldur            w1, [x0, #0xb]
    // 0xdffd88: DecompressPointer r1
    //     0xdffd88: add             x1, x1, HEAP, lsl #32
    // 0xdffd8c: cmp             w1, NULL
    // 0xdffd90: b.eq            #0xdffdec
    // 0xdffd94: LoadField: r2 = r1->field_63
    //     0xdffd94: ldur            w2, [x1, #0x63]
    // 0xdffd98: DecompressPointer r2
    //     0xdffd98: add             x2, x2, HEAP, lsl #32
    // 0xdffd9c: cmp             w2, NULL
    // 0xdffda0: b.eq            #0xdffdd0
    // 0xdffda4: ldur            x3, [fp, #-0x10]
    // 0xdffda8: r0 = BoxInt64Instr(r3)
    //     0xdffda8: sbfiz           x0, x3, #1, #0x1f
    //     0xdffdac: cmp             x3, x0, asr #1
    //     0xdffdb0: b.eq            #0xdffdbc
    //     0xdffdb4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xdffdb8: stur            x3, [x0, #7]
    // 0xdffdbc: stp             x0, x2, [SP]
    // 0xdffdc0: mov             x0, x2
    // 0xdffdc4: ClosureCall
    //     0xdffdc4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xdffdc8: ldur            x2, [x0, #0x1f]
    //     0xdffdcc: blr             x2
    // 0xdffdd0: r0 = Null
    //     0xdffdd0: mov             x0, NULL
    // 0xdffdd4: LeaveFrame
    //     0xdffdd4: mov             SP, fp
    //     0xdffdd8: ldp             fp, lr, [SP], #0x10
    // 0xdffddc: ret
    //     0xdffddc: ret             
    // 0xdffde0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdffde0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdffde4: b               #0xdffd68
    // 0xdffde8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdffde8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdffdec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdffdec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Color? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xe000c0, size: 0x144
    // 0xe000c0: EnterFrame
    //     0xe000c0: stp             fp, lr, [SP, #-0x10]!
    //     0xe000c4: mov             fp, SP
    // 0xe000c8: AllocStack(0x20)
    //     0xe000c8: sub             SP, SP, #0x20
    // 0xe000cc: SetupParameters([dynamic _ /* r0 */])
    //     0xe000cc: ldr             x0, [fp, #0x18]
    //     0xe000d0: ldur            w2, [x0, #0x17]
    //     0xe000d4: add             x2, x2, HEAP, lsl #32
    //     0xe000d8: stur            x2, [fp, #-8]
    // 0xe000dc: CheckStackOverflow
    //     0xe000dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe000e0: cmp             SP, x16
    //     0xe000e4: b.ls            #0xe001fc
    // 0xe000e8: LoadField: r1 = r2->field_13
    //     0xe000e8: ldur            w1, [x2, #0x13]
    // 0xe000ec: DecompressPointer r1
    //     0xe000ec: add             x1, x1, HEAP, lsl #32
    // 0xe000f0: r0 = toSet()
    //     0xe000f0: bl              #0xba6270  ; [dart:_compact_hash] _Set::toSet
    // 0xe000f4: mov             x1, x0
    // 0xe000f8: ldr             x2, [fp, #0x10]
    // 0xe000fc: stur            x0, [fp, #-0x10]
    // 0xe00100: r0 = addAll()
    //     0xe00100: bl              #0x11850e8  ; [dart:_compact_hash] _Set::addAll
    // 0xe00104: ldur            x0, [fp, #-8]
    // 0xe00108: LoadField: r1 = r0->field_b
    //     0xe00108: ldur            w1, [x0, #0xb]
    // 0xe0010c: DecompressPointer r1
    //     0xe0010c: add             x1, x1, HEAP, lsl #32
    // 0xe00110: LoadField: r0 = r1->field_f
    //     0xe00110: ldur            w0, [x1, #0xf]
    // 0xe00114: DecompressPointer r0
    //     0xe00114: add             x0, x0, HEAP, lsl #32
    // 0xe00118: mov             x1, x0
    // 0xe0011c: r0 = _defaults()
    //     0xe0011c: bl              #0xdffaf8  ; [package:flutter/src/material/tabs.dart] _TabBarState::_defaults
    // 0xe00120: stur            x0, [fp, #-8]
    // 0xe00124: r1 = LoadClassIdInstr(r0)
    //     0xe00124: ldur            x1, [x0, #-1]
    //     0xe00128: ubfx            x1, x1, #0xc, #0x14
    // 0xe0012c: r17 = 5058
    //     0xe0012c: mov             x17, #0x13c2
    // 0xe00130: cmp             x1, x17
    // 0xe00134: b.eq            #0xe001d0
    // 0xe00138: r17 = 5059
    //     0xe00138: mov             x17, #0x13c3
    // 0xe0013c: cmp             x1, x17
    // 0xe00140: b.ne            #0xe00184
    // 0xe00144: r1 = 1
    //     0xe00144: mov             x1, #1
    // 0xe00148: r0 = AllocateContext()
    //     0xe00148: bl              #0x13de838  ; AllocateContextStub
    // 0xe0014c: mov             x1, x0
    // 0xe00150: ldur            x0, [fp, #-8]
    // 0xe00154: StoreField: r1->field_f = r0
    //     0xe00154: stur            w0, [x1, #0xf]
    // 0xe00158: mov             x2, x1
    // 0xe0015c: r1 = Function '<anonymous closure>':.
    //     0xe0015c: add             x1, PP, #0x26, lsl #12  ; [pp+0x260d0] AnonymousClosure: (0xe005e0), of [package:flutter/src/material/tabs.dart] _TabsSecondaryDefaultsM3
    //     0xe00160: ldr             x1, [x1, #0xd0]
    // 0xe00164: r0 = AllocateClosure()
    //     0xe00164: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe00168: r16 = <Color?>
    //     0xe00168: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xe0016c: ldr             x16, [x16, #0xa40]
    // 0xe00170: stp             x0, x16, [SP]
    // 0xe00174: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xe00174: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xe00178: r0 = resolveWith()
    //     0xe00178: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xe0017c: mov             x1, x0
    // 0xe00180: b               #0xe001d8
    // 0xe00184: r17 = 5060
    //     0xe00184: mov             x17, #0x13c4
    // 0xe00188: cmp             x1, x17
    // 0xe0018c: b.ne            #0xe001d0
    // 0xe00190: r1 = 1
    //     0xe00190: mov             x1, #1
    // 0xe00194: r0 = AllocateContext()
    //     0xe00194: bl              #0x13de838  ; AllocateContextStub
    // 0xe00198: mov             x1, x0
    // 0xe0019c: ldur            x0, [fp, #-8]
    // 0xe001a0: StoreField: r1->field_f = r0
    //     0xe001a0: stur            w0, [x1, #0xf]
    // 0xe001a4: mov             x2, x1
    // 0xe001a8: r1 = Function '<anonymous closure>':.
    //     0xe001a8: add             x1, PP, #0x26, lsl #12  ; [pp+0x260d8] AnonymousClosure: (0xe00204), of [package:flutter/src/material/tabs.dart] _TabsPrimaryDefaultsM3
    //     0xe001ac: ldr             x1, [x1, #0xd8]
    // 0xe001b0: r0 = AllocateClosure()
    //     0xe001b0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe001b4: r16 = <Color?>
    //     0xe001b4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xe001b8: ldr             x16, [x16, #0xa40]
    // 0xe001bc: stp             x0, x16, [SP]
    // 0xe001c0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xe001c0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xe001c4: r0 = resolveWith()
    //     0xe001c4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xe001c8: mov             x1, x0
    // 0xe001cc: b               #0xe001d8
    // 0xe001d0: LoadField: r1 = r0->field_2f
    //     0xe001d0: ldur            w1, [x0, #0x2f]
    // 0xe001d4: DecompressPointer r1
    //     0xe001d4: add             x1, x1, HEAP, lsl #32
    // 0xe001d8: cmp             w1, NULL
    // 0xe001dc: b.ne            #0xe001e8
    // 0xe001e0: r0 = Null
    //     0xe001e0: mov             x0, NULL
    // 0xe001e4: b               #0xe001f0
    // 0xe001e8: ldur            x2, [fp, #-0x10]
    // 0xe001ec: r0 = build()
    //     0xe001ec: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xe001f0: LeaveFrame
    //     0xe001f0: mov             SP, fp
    //     0xe001f4: ldp             fp, lr, [SP], #0x10
    // 0xe001f8: ret
    //     0xe001f8: ret             
    // 0xe001fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe001fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe00200: b               #0xe000e8
  }
  [closure] Center <anonymous closure>(dynamic, int) {
    // ** addr: 0xe008cc, size: 0x34c
    // 0xe008cc: EnterFrame
    //     0xe008cc: stp             fp, lr, [SP, #-0x10]!
    //     0xe008d0: mov             fp, SP
    // 0xe008d4: AllocStack(0x28)
    //     0xe008d4: sub             SP, SP, #0x28
    // 0xe008d8: SetupParameters([dynamic _ /* r0 */])
    //     0xe008d8: ldr             x0, [fp, #0x18]
    //     0xe008dc: ldur            w3, [x0, #0x17]
    //     0xe008e0: add             x3, x3, HEAP, lsl #32
    //     0xe008e4: stur            x3, [fp, #-0x18]
    // 0xe008e8: CheckStackOverflow
    //     0xe008e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe008ec: cmp             SP, x16
    //     0xe008f0: b.ls            #0xe00bdc
    // 0xe008f4: LoadField: r0 = r3->field_f
    //     0xe008f4: ldur            w0, [x3, #0xf]
    // 0xe008f8: DecompressPointer r0
    //     0xe008f8: add             x0, x0, HEAP, lsl #32
    // 0xe008fc: LoadField: r1 = r0->field_b
    //     0xe008fc: ldur            w1, [x0, #0xb]
    // 0xe00900: DecompressPointer r1
    //     0xe00900: add             x1, x1, HEAP, lsl #32
    // 0xe00904: cmp             w1, NULL
    // 0xe00908: b.eq            #0xe00be4
    // 0xe0090c: LoadField: r2 = r1->field_b
    //     0xe0090c: ldur            w2, [x1, #0xb]
    // 0xe00910: DecompressPointer r2
    //     0xe00910: add             x2, x2, HEAP, lsl #32
    // 0xe00914: LoadField: r0 = r2->field_b
    //     0xe00914: ldur            w0, [x2, #0xb]
    // 0xe00918: ldr             x1, [fp, #0x10]
    // 0xe0091c: r4 = LoadInt32Instr(r1)
    //     0xe0091c: sbfx            x4, x1, #1, #0x1f
    //     0xe00920: tbz             w1, #0, #0xe00928
    //     0xe00924: ldur            x4, [x1, #7]
    // 0xe00928: stur            x4, [fp, #-0x10]
    // 0xe0092c: r1 = LoadInt32Instr(r0)
    //     0xe0092c: sbfx            x1, x0, #1, #0x1f
    // 0xe00930: mov             x0, x1
    // 0xe00934: mov             x1, x4
    // 0xe00938: cmp             x1, x0
    // 0xe0093c: b.hs            #0xe00be8
    // 0xe00940: LoadField: r0 = r2->field_f
    //     0xe00940: ldur            w0, [x2, #0xf]
    // 0xe00944: DecompressPointer r0
    //     0xe00944: add             x0, x0, HEAP, lsl #32
    // 0xe00948: ArrayLoad: r5 = r0[r4]  ; Unknown_4
    //     0xe00948: add             x16, x0, x4, lsl #2
    //     0xe0094c: ldur            w5, [x16, #0xf]
    // 0xe00950: DecompressPointer r5
    //     0xe00950: add             x5, x5, HEAP, lsl #32
    // 0xe00954: mov             x0, x5
    // 0xe00958: stur            x5, [fp, #-8]
    // 0xe0095c: r2 = Null
    //     0xe0095c: mov             x2, NULL
    // 0xe00960: r1 = Null
    //     0xe00960: mov             x1, NULL
    // 0xe00964: cmp             w0, NULL
    // 0xe00968: b.eq            #0xe009f0
    // 0xe0096c: branchIfSmi(r0, 0xe009f0)
    //     0xe0096c: tbz             w0, #0, #0xe009f0
    // 0xe00970: r3 = LoadClassIdInstr(r0)
    //     0xe00970: ldur            x3, [x0, #-1]
    //     0xe00974: ubfx            x3, x3, #0xc, #0x14
    // 0xe00978: r4 = LoadClassIdInstr(r0)
    //     0xe00978: ldur            x4, [x0, #-1]
    //     0xe0097c: ubfx            x4, x4, #0xc, #0x14
    // 0xe00980: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0xe00984: ldr             x3, [x3, #0x18]
    // 0xe00988: ldr             x3, [x3, x4, lsl #3]
    // 0xe0098c: LoadField: r3 = r3->field_2b
    //     0xe0098c: ldur            w3, [x3, #0x2b]
    // 0xe00990: DecompressPointer r3
    //     0xe00990: add             x3, x3, HEAP, lsl #32
    // 0xe00994: cmp             w3, NULL
    // 0xe00998: b.eq            #0xe009f0
    // 0xe0099c: LoadField: r3 = r3->field_f
    //     0xe0099c: ldur            w3, [x3, #0xf]
    // 0xe009a0: lsr             x3, x3, #3
    // 0xe009a4: cmp             x3, #0xc35
    // 0xe009a8: b.eq            #0xe009f8
    // 0xe009ac: r3 = SubtypeTestCache
    //     0xe009ac: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c628] SubtypeTestCache
    //     0xe009b0: ldr             x3, [x3, #0x628]
    // 0xe009b4: r30 = Subtype1TestCacheStub
    //     0xe009b4: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0xe009b8: LoadField: r30 = r30->field_7
    //     0xe009b8: ldur            lr, [lr, #7]
    // 0xe009bc: blr             lr
    // 0xe009c0: cmp             w7, NULL
    // 0xe009c4: b.eq            #0xe009d0
    // 0xe009c8: tbnz            w7, #4, #0xe009f0
    // 0xe009cc: b               #0xe009f8
    // 0xe009d0: r8 = PreferredSizeWidget
    //     0xe009d0: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8c630] Type: PreferredSizeWidget
    //     0xe009d4: ldr             x8, [x8, #0x630]
    // 0xe009d8: r3 = SubtypeTestCache
    //     0xe009d8: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c638] SubtypeTestCache
    //     0xe009dc: ldr             x3, [x3, #0x638]
    // 0xe009e0: r30 = InstanceOfStub
    //     0xe009e0: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xe009e4: LoadField: r30 = r30->field_7
    //     0xe009e4: ldur            lr, [lr, #7]
    // 0xe009e8: blr             lr
    // 0xe009ec: b               #0xe009fc
    // 0xe009f0: r0 = false
    //     0xe009f0: add             x0, NULL, #0x30  ; false
    // 0xe009f4: b               #0xe009fc
    // 0xe009f8: r0 = true
    //     0xe009f8: add             x0, NULL, #0x20  ; true
    // 0xe009fc: tbnz            w0, #4, #0xe00a70
    // 0xe00a00: ldur            x1, [fp, #-8]
    // 0xe00a04: r0 = LoadClassIdInstr(r1)
    //     0xe00a04: ldur            x0, [x1, #-1]
    //     0xe00a08: ubfx            x0, x0, #0xc, #0x14
    // 0xe00a0c: r0 = GDT[cid_x0 + 0xade]()
    //     0xe00a0c: add             lr, x0, #0xade
    //     0xe00a10: ldr             lr, [x21, lr, lsl #3]
    //     0xe00a14: blr             lr
    // 0xe00a18: LoadField: d0 = r0->field_f
    //     0xe00a18: ldur            d0, [x0, #0xf]
    // 0xe00a1c: d1 = 46.000000
    //     0xe00a1c: add             x17, PP, #0x80, lsl #12  ; [pp+0x80908] IMM: double(46) from 0x4047000000000000
    //     0xe00a20: ldr             d1, [x17, #0x908]
    // 0xe00a24: fcmp            d0, d1
    // 0xe00a28: b.ne            #0xe00a70
    // 0xe00a2c: ldur            x0, [fp, #-0x18]
    // 0xe00a30: LoadField: r1 = r0->field_f
    //     0xe00a30: ldur            w1, [x0, #0xf]
    // 0xe00a34: DecompressPointer r1
    //     0xe00a34: add             x1, x1, HEAP, lsl #32
    // 0xe00a38: LoadField: r2 = r1->field_b
    //     0xe00a38: ldur            w2, [x1, #0xb]
    // 0xe00a3c: DecompressPointer r2
    //     0xe00a3c: add             x2, x2, HEAP, lsl #32
    // 0xe00a40: cmp             w2, NULL
    // 0xe00a44: b.eq            #0xe00bec
    // 0xe00a48: mov             x1, x2
    // 0xe00a4c: r0 = tabHasTextAndIcon()
    //     0xe00a4c: bl              #0xe00c18  ; [package:flutter/src/material/tabs.dart] TabBar::tabHasTextAndIcon
    // 0xe00a50: tbnz            w0, #4, #0xe00a70
    // 0xe00a54: r1 = Instance_EdgeInsets
    //     0xe00a54: add             x1, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0xe00a58: ldr             x1, [x1, #0x510]
    // 0xe00a5c: r2 = Instance_EdgeInsets
    //     0xe00a5c: add             x2, PP, #0x8c, lsl #12  ; [pp+0x8c640] Obj!EdgeInsets@129d6b1
    //     0xe00a60: ldr             x2, [x2, #0x640]
    // 0xe00a64: r0 = +()
    //     0xe00a64: bl              #0x8584ec  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::+
    // 0xe00a68: mov             x3, x0
    // 0xe00a6c: b               #0xe00a78
    // 0xe00a70: r3 = Instance_EdgeInsets
    //     0xe00a70: add             x3, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0xe00a74: ldr             x3, [x3, #0x510]
    // 0xe00a78: ldur            x0, [fp, #-0x18]
    // 0xe00a7c: ldur            x2, [fp, #-0x10]
    // 0xe00a80: stur            x3, [fp, #-0x20]
    // 0xe00a84: LoadField: r4 = r0->field_f
    //     0xe00a84: ldur            w4, [x0, #0xf]
    // 0xe00a88: DecompressPointer r4
    //     0xe00a88: add             x4, x4, HEAP, lsl #32
    // 0xe00a8c: LoadField: r5 = r4->field_27
    //     0xe00a8c: ldur            w5, [x4, #0x27]
    // 0xe00a90: DecompressPointer r5
    //     0xe00a90: add             x5, x5, HEAP, lsl #32
    // 0xe00a94: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe00a98: cmp             w5, w16
    // 0xe00a9c: b.eq            #0xe00bf0
    // 0xe00aa0: LoadField: r0 = r5->field_b
    //     0xe00aa0: ldur            w0, [x5, #0xb]
    // 0xe00aa4: r1 = LoadInt32Instr(r0)
    //     0xe00aa4: sbfx            x1, x0, #1, #0x1f
    // 0xe00aa8: mov             x0, x1
    // 0xe00aac: mov             x1, x2
    // 0xe00ab0: cmp             x1, x0
    // 0xe00ab4: b.hs            #0xe00bfc
    // 0xe00ab8: LoadField: r1 = r5->field_f
    //     0xe00ab8: ldur            w1, [x5, #0xf]
    // 0xe00abc: DecompressPointer r1
    //     0xe00abc: add             x1, x1, HEAP, lsl #32
    // 0xe00ac0: mov             x0, x3
    // 0xe00ac4: ArrayStore: r1[r2] = r0  ; List_4
    //     0xe00ac4: add             x25, x1, x2, lsl #2
    //     0xe00ac8: add             x25, x25, #0xf
    //     0xe00acc: str             w0, [x25]
    //     0xe00ad0: tbz             w0, #0, #0xe00aec
    //     0xe00ad4: ldurb           w16, [x1, #-1]
    //     0xe00ad8: ldurb           w17, [x0, #-1]
    //     0xe00adc: and             x16, x17, x16, lsr #2
    //     0xe00ae0: tst             x16, HEAP, lsr #32
    //     0xe00ae4: b.eq            #0xe00aec
    //     0xe00ae8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xe00aec: LoadField: r5 = r4->field_23
    //     0xe00aec: ldur            w5, [x4, #0x23]
    // 0xe00af0: DecompressPointer r5
    //     0xe00af0: add             x5, x5, HEAP, lsl #32
    // 0xe00af4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe00af8: cmp             w5, w16
    // 0xe00afc: b.eq            #0xe00c00
    // 0xe00b00: LoadField: r0 = r5->field_b
    //     0xe00b00: ldur            w0, [x5, #0xb]
    // 0xe00b04: r1 = LoadInt32Instr(r0)
    //     0xe00b04: sbfx            x1, x0, #1, #0x1f
    // 0xe00b08: mov             x0, x1
    // 0xe00b0c: mov             x1, x2
    // 0xe00b10: cmp             x1, x0
    // 0xe00b14: b.hs            #0xe00c0c
    // 0xe00b18: LoadField: r0 = r5->field_f
    //     0xe00b18: ldur            w0, [x5, #0xf]
    // 0xe00b1c: DecompressPointer r0
    //     0xe00b1c: add             x0, x0, HEAP, lsl #32
    // 0xe00b20: ArrayLoad: r5 = r0[r2]  ; Unknown_4
    //     0xe00b20: add             x16, x0, x2, lsl #2
    //     0xe00b24: ldur            w5, [x16, #0xf]
    // 0xe00b28: DecompressPointer r5
    //     0xe00b28: add             x5, x5, HEAP, lsl #32
    // 0xe00b2c: stur            x5, [fp, #-0x18]
    // 0xe00b30: LoadField: r0 = r4->field_b
    //     0xe00b30: ldur            w0, [x4, #0xb]
    // 0xe00b34: DecompressPointer r0
    //     0xe00b34: add             x0, x0, HEAP, lsl #32
    // 0xe00b38: cmp             w0, NULL
    // 0xe00b3c: b.eq            #0xe00c10
    // 0xe00b40: LoadField: r4 = r0->field_b
    //     0xe00b40: ldur            w4, [x0, #0xb]
    // 0xe00b44: DecompressPointer r4
    //     0xe00b44: add             x4, x4, HEAP, lsl #32
    // 0xe00b48: LoadField: r0 = r4->field_b
    //     0xe00b48: ldur            w0, [x4, #0xb]
    // 0xe00b4c: r1 = LoadInt32Instr(r0)
    //     0xe00b4c: sbfx            x1, x0, #1, #0x1f
    // 0xe00b50: mov             x0, x1
    // 0xe00b54: mov             x1, x2
    // 0xe00b58: cmp             x1, x0
    // 0xe00b5c: b.hs            #0xe00c14
    // 0xe00b60: LoadField: r0 = r4->field_f
    //     0xe00b60: ldur            w0, [x4, #0xf]
    // 0xe00b64: DecompressPointer r0
    //     0xe00b64: add             x0, x0, HEAP, lsl #32
    // 0xe00b68: ArrayLoad: r1 = r0[r2]  ; Unknown_4
    //     0xe00b68: add             x16, x0, x2, lsl #2
    //     0xe00b6c: ldur            w1, [x16, #0xf]
    // 0xe00b70: DecompressPointer r1
    //     0xe00b70: add             x1, x1, HEAP, lsl #32
    // 0xe00b74: stur            x1, [fp, #-8]
    // 0xe00b78: r0 = KeyedSubtree()
    //     0xe00b78: bl              #0xd36f98  ; AllocateKeyedSubtreeStub -> KeyedSubtree (size=0x10)
    // 0xe00b7c: mov             x1, x0
    // 0xe00b80: ldur            x0, [fp, #-8]
    // 0xe00b84: stur            x1, [fp, #-0x28]
    // 0xe00b88: StoreField: r1->field_b = r0
    //     0xe00b88: stur            w0, [x1, #0xb]
    // 0xe00b8c: ldur            x0, [fp, #-0x18]
    // 0xe00b90: StoreField: r1->field_7 = r0
    //     0xe00b90: stur            w0, [x1, #7]
    // 0xe00b94: r0 = Padding()
    //     0xe00b94: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xe00b98: mov             x1, x0
    // 0xe00b9c: ldur            x0, [fp, #-0x20]
    // 0xe00ba0: stur            x1, [fp, #-8]
    // 0xe00ba4: StoreField: r1->field_f = r0
    //     0xe00ba4: stur            w0, [x1, #0xf]
    // 0xe00ba8: ldur            x0, [fp, #-0x28]
    // 0xe00bac: StoreField: r1->field_b = r0
    //     0xe00bac: stur            w0, [x1, #0xb]
    // 0xe00bb0: r0 = Center()
    //     0xe00bb0: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xe00bb4: r1 = Instance_Alignment
    //     0xe00bb4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xe00bb8: ldr             x1, [x1, #0xb80]
    // 0xe00bbc: StoreField: r0->field_f = r1
    //     0xe00bbc: stur            w1, [x0, #0xf]
    // 0xe00bc0: r1 = 1.000000
    //     0xe00bc0: ldr             x1, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xe00bc4: ArrayStore: r0[0] = r1  ; List_4
    //     0xe00bc4: stur            w1, [x0, #0x17]
    // 0xe00bc8: ldur            x1, [fp, #-8]
    // 0xe00bcc: StoreField: r0->field_b = r1
    //     0xe00bcc: stur            w1, [x0, #0xb]
    // 0xe00bd0: LeaveFrame
    //     0xe00bd0: mov             SP, fp
    //     0xe00bd4: ldp             fp, lr, [SP], #0x10
    // 0xe00bd8: ret
    //     0xe00bd8: ret             
    // 0xe00bdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe00bdc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe00be0: b               #0xe008f4
    // 0xe00be4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe00be4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe00be8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xe00be8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xe00bec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe00bec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe00bf0: r9 = _labelPaddings
    //     0xe00bf0: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8c648] Field <_TabBarState@780014024._labelPaddings@780014024>: late (offset: 0x28)
    //     0xe00bf4: ldr             x9, [x9, #0x648]
    // 0xe00bf8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xe00bf8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xe00bfc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xe00bfc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xe00c00: r9 = _tabKeys
    //     0xe00c00: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8c650] Field <_TabBarState@780014024._tabKeys@780014024>: late (offset: 0x24)
    //     0xe00c04: ldr             x9, [x9, #0x650]
    // 0xe00c08: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xe00c08: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xe00c0c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xe00c0c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xe00c10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe00c10: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe00c14: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xe00c14: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xef59d0, size: 0x50
    // 0xef59d0: EnterFrame
    //     0xef59d0: stp             fp, lr, [SP, #-0x10]!
    //     0xef59d4: mov             fp, SP
    // 0xef59d8: AllocStack(0x8)
    //     0xef59d8: sub             SP, SP, #8
    // 0xef59dc: SetupParameters(_TabBarState this /* r1 => r0, fp-0x8 */)
    //     0xef59dc: mov             x0, x1
    //     0xef59e0: stur            x1, [fp, #-8]
    // 0xef59e4: CheckStackOverflow
    //     0xef59e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef59e8: cmp             SP, x16
    //     0xef59ec: b.ls            #0xef5a18
    // 0xef59f0: mov             x1, x0
    // 0xef59f4: r0 = _updateScrollController()
    //     0xef59f4: bl              #0xef6c8c  ; [package:flutter/src/material/tabs.dart] _TabBarState::_updateScrollController
    // 0xef59f8: ldur            x1, [fp, #-8]
    // 0xef59fc: r0 = _updateTabController()
    //     0xef59fc: bl              #0xef6840  ; [package:flutter/src/material/tabs.dart] _TabBarState::_updateTabController
    // 0xef5a00: ldur            x1, [fp, #-8]
    // 0xef5a04: r0 = _initIndicatorPainter()
    //     0xef5a04: bl              #0xef5a20  ; [package:flutter/src/material/tabs.dart] _TabBarState::_initIndicatorPainter
    // 0xef5a08: r0 = Null
    //     0xef5a08: mov             x0, NULL
    // 0xef5a0c: LeaveFrame
    //     0xef5a0c: mov             SP, fp
    //     0xef5a10: ldp             fp, lr, [SP], #0x10
    // 0xef5a14: ret
    //     0xef5a14: ret             
    // 0xef5a18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef5a18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef5a1c: b               #0xef59f0
  }
  _ _initIndicatorPainter(/* No info */) {
    // ** addr: 0xef5a20, size: 0x418
    // 0xef5a20: EnterFrame
    //     0xef5a20: stp             fp, lr, [SP, #-0x10]!
    //     0xef5a24: mov             fp, SP
    // 0xef5a28: AllocStack(0x90)
    //     0xef5a28: sub             SP, SP, #0x90
    // 0xef5a2c: SetupParameters(_TabBarState this /* r1 => r0, fp-0x8 */)
    //     0xef5a2c: mov             x0, x1
    //     0xef5a30: stur            x1, [fp, #-8]
    // 0xef5a34: CheckStackOverflow
    //     0xef5a34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef5a38: cmp             SP, x16
    //     0xef5a3c: b.ls            #0xef5dec
    // 0xef5a40: LoadField: r1 = r0->field_f
    //     0xef5a40: ldur            w1, [x0, #0xf]
    // 0xef5a44: DecompressPointer r1
    //     0xef5a44: add             x1, x1, HEAP, lsl #32
    // 0xef5a48: cmp             w1, NULL
    // 0xef5a4c: b.eq            #0xef5df4
    // 0xef5a50: r0 = of()
    //     0xef5a50: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xef5a54: mov             x2, x0
    // 0xef5a58: ldur            x0, [fp, #-8]
    // 0xef5a5c: stur            x2, [fp, #-0x10]
    // 0xef5a60: LoadField: r1 = r0->field_f
    //     0xef5a60: ldur            w1, [x0, #0xf]
    // 0xef5a64: DecompressPointer r1
    //     0xef5a64: add             x1, x1, HEAP, lsl #32
    // 0xef5a68: cmp             w1, NULL
    // 0xef5a6c: b.eq            #0xef5df8
    // 0xef5a70: r0 = of()
    //     0xef5a70: bl              #0xdffc38  ; [package:flutter/src/material/tab_bar_theme.dart] TabBarTheme::of
    // 0xef5a74: mov             x1, x0
    // 0xef5a78: ldur            x0, [fp, #-8]
    // 0xef5a7c: LoadField: r2 = r0->field_b
    //     0xef5a7c: ldur            w2, [x0, #0xb]
    // 0xef5a80: DecompressPointer r2
    //     0xef5a80: add             x2, x2, HEAP, lsl #32
    // 0xef5a84: cmp             w2, NULL
    // 0xef5a88: b.eq            #0xef5dfc
    // 0xef5a8c: LoadField: r3 = r2->field_37
    //     0xef5a8c: ldur            w3, [x2, #0x37]
    // 0xef5a90: DecompressPointer r3
    //     0xef5a90: add             x3, x3, HEAP, lsl #32
    // 0xef5a94: cmp             w3, NULL
    // 0xef5a98: b.ne            #0xef5aac
    // 0xef5a9c: LoadField: r2 = r1->field_f
    //     0xef5a9c: ldur            w2, [x1, #0xf]
    // 0xef5aa0: DecompressPointer r2
    //     0xef5aa0: add             x2, x2, HEAP, lsl #32
    // 0xef5aa4: mov             x1, x2
    // 0xef5aa8: b               #0xef5ab0
    // 0xef5aac: mov             x1, x3
    // 0xef5ab0: cmp             w1, NULL
    // 0xef5ab4: b.ne            #0xef5ad8
    // 0xef5ab8: mov             x1, x0
    // 0xef5abc: r0 = _defaults()
    //     0xef5abc: bl              #0xdffaf8  ; [package:flutter/src/material/tabs.dart] _TabBarState::_defaults
    // 0xef5ac0: LoadField: r1 = r0->field_f
    //     0xef5ac0: ldur            w1, [x0, #0xf]
    // 0xef5ac4: DecompressPointer r1
    //     0xef5ac4: add             x1, x1, HEAP, lsl #32
    // 0xef5ac8: cmp             w1, NULL
    // 0xef5acc: b.eq            #0xef5e00
    // 0xef5ad0: mov             x2, x1
    // 0xef5ad4: b               #0xef5adc
    // 0xef5ad8: mov             x2, x1
    // 0xef5adc: ldur            x0, [fp, #-8]
    // 0xef5ae0: stur            x2, [fp, #-0x28]
    // 0xef5ae4: LoadField: r3 = r0->field_1b
    //     0xef5ae4: ldur            w3, [x0, #0x1b]
    // 0xef5ae8: DecompressPointer r3
    //     0xef5ae8: add             x3, x3, HEAP, lsl #32
    // 0xef5aec: stur            x3, [fp, #-0x20]
    // 0xef5af0: LoadField: r1 = r2->field_7
    //     0xef5af0: ldur            x1, [x2, #7]
    // 0xef5af4: cmp             x1, #0
    // 0xef5af8: b.gt            #0xef5b08
    // 0xef5afc: r7 = Instance_TabIndicatorAnimation
    //     0xef5afc: add             x7, PP, #0x8c, lsl #12  ; [pp+0x8c6c0] Obj!TabIndicatorAnimation@12c4c61
    //     0xef5b00: ldr             x7, [x7, #0x6c0]
    // 0xef5b04: b               #0xef5b10
    // 0xef5b08: r7 = Instance_TabIndicatorAnimation
    //     0xef5b08: add             x7, PP, #0x8c, lsl #12  ; [pp+0x8c6c8] Obj!TabIndicatorAnimation@12c4c41
    //     0xef5b0c: ldr             x7, [x7, #0x6c8]
    // 0xef5b10: mov             x1, x0
    // 0xef5b14: stur            x7, [fp, #-0x18]
    // 0xef5b18: r0 = _controllerIsValid()
    //     0xef5b18: bl              #0xef6800  ; [package:flutter/src/material/tabs.dart] _TabBarState::_controllerIsValid
    // 0xef5b1c: tbz             w0, #4, #0xef5b28
    // 0xef5b20: r0 = Null
    //     0xef5b20: mov             x0, NULL
    // 0xef5b24: b               #0xef5d78
    // 0xef5b28: ldur            x0, [fp, #-8]
    // 0xef5b2c: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xef5b2c: ldur            w3, [x0, #0x17]
    // 0xef5b30: DecompressPointer r3
    //     0xef5b30: add             x3, x3, HEAP, lsl #32
    // 0xef5b34: stur            x3, [fp, #-0x30]
    // 0xef5b38: cmp             w3, NULL
    // 0xef5b3c: b.eq            #0xef5e04
    // 0xef5b40: mov             x1, x0
    // 0xef5b44: ldur            x2, [fp, #-0x28]
    // 0xef5b48: r0 = _getIndicator()
    //     0xef5b48: bl              #0xef626c  ; [package:flutter/src/material/tabs.dart] _TabBarState::_getIndicator
    // 0xef5b4c: mov             x2, x0
    // 0xef5b50: ldur            x0, [fp, #-8]
    // 0xef5b54: stur            x2, [fp, #-0x48]
    // 0xef5b58: LoadField: r1 = r0->field_b
    //     0xef5b58: ldur            w1, [x0, #0xb]
    // 0xef5b5c: DecompressPointer r1
    //     0xef5b5c: add             x1, x1, HEAP, lsl #32
    // 0xef5b60: cmp             w1, NULL
    // 0xef5b64: b.eq            #0xef5e08
    // 0xef5b68: LoadField: r3 = r0->field_23
    //     0xef5b68: ldur            w3, [x0, #0x23]
    // 0xef5b6c: DecompressPointer r3
    //     0xef5b6c: add             x3, x3, HEAP, lsl #32
    // 0xef5b70: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef5b74: cmp             w3, w16
    // 0xef5b78: b.eq            #0xef5e0c
    // 0xef5b7c: stur            x3, [fp, #-0x40]
    // 0xef5b80: LoadField: r4 = r0->field_27
    //     0xef5b80: ldur            w4, [x0, #0x27]
    // 0xef5b84: DecompressPointer r4
    //     0xef5b84: add             x4, x4, HEAP, lsl #32
    // 0xef5b88: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef5b8c: cmp             w4, w16
    // 0xef5b90: b.eq            #0xef5e18
    // 0xef5b94: stur            x4, [fp, #-0x38]
    // 0xef5b98: LoadField: r5 = r1->field_3b
    //     0xef5b98: ldur            w5, [x1, #0x3b]
    // 0xef5b9c: DecompressPointer r5
    //     0xef5b9c: add             x5, x5, HEAP, lsl #32
    // 0xef5ba0: cmp             w5, NULL
    // 0xef5ba4: b.ne            #0xef5bb0
    // 0xef5ba8: r1 = Null
    //     0xef5ba8: mov             x1, NULL
    // 0xef5bac: b               #0xef5bb4
    // 0xef5bb0: mov             x1, x5
    // 0xef5bb4: cmp             w1, NULL
    // 0xef5bb8: b.ne            #0xef5c50
    // 0xef5bbc: mov             x1, x0
    // 0xef5bc0: r0 = _defaults()
    //     0xef5bc0: bl              #0xdffaf8  ; [package:flutter/src/material/tabs.dart] _TabBarState::_defaults
    // 0xef5bc4: r1 = LoadClassIdInstr(r0)
    //     0xef5bc4: ldur            x1, [x0, #-1]
    //     0xef5bc8: ubfx            x1, x1, #0xc, #0x14
    // 0xef5bcc: r17 = 5058
    //     0xef5bcc: mov             x17, #0x13c2
    // 0xef5bd0: cmp             x1, x17
    // 0xef5bd4: b.eq            #0xef5c3c
    // 0xef5bd8: r17 = 5059
    //     0xef5bd8: mov             x17, #0x13c3
    // 0xef5bdc: cmp             x1, x17
    // 0xef5be0: b.eq            #0xef5dbc
    // 0xef5be4: r17 = 5060
    //     0xef5be4: mov             x17, #0x13c4
    // 0xef5be8: cmp             x1, x17
    // 0xef5bec: b.ne            #0xef5c3c
    // 0xef5bf0: mov             x1, x0
    // 0xef5bf4: LoadField: r0 = r1->field_4f
    //     0xef5bf4: ldur            w0, [x1, #0x4f]
    // 0xef5bf8: DecompressPointer r0
    //     0xef5bf8: add             x0, x0, HEAP, lsl #32
    // 0xef5bfc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef5c00: cmp             w0, w16
    // 0xef5c04: b.ne            #0xef5c14
    // 0xef5c08: r2 = _colors
    //     0xef5c08: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0xef5c0c: ldr             x2, [x2, #0xb0]
    // 0xef5c10: r0 = InitLateFinalInstanceField()
    //     0xef5c10: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xef5c14: LoadField: r1 = r0->field_ab
    //     0xef5c14: ldur            w1, [x0, #0xab]
    // 0xef5c18: DecompressPointer r1
    //     0xef5c18: add             x1, x1, HEAP, lsl #32
    // 0xef5c1c: cmp             w1, NULL
    // 0xef5c20: b.ne            #0xef5c34
    // 0xef5c24: LoadField: r1 = r0->field_cb
    //     0xef5c24: ldur            w1, [x0, #0xcb]
    // 0xef5c28: DecompressPointer r1
    //     0xef5c28: add             x1, x1, HEAP, lsl #32
    // 0xef5c2c: mov             x0, x1
    // 0xef5c30: b               #0xef5c48
    // 0xef5c34: mov             x0, x1
    // 0xef5c38: b               #0xef5c48
    // 0xef5c3c: LoadField: r1 = r0->field_13
    //     0xef5c3c: ldur            w1, [x0, #0x13]
    // 0xef5c40: DecompressPointer r1
    //     0xef5c40: add             x1, x1, HEAP, lsl #32
    // 0xef5c44: mov             x0, x1
    // 0xef5c48: mov             x3, x0
    // 0xef5c4c: b               #0xef5c54
    // 0xef5c50: mov             x3, x1
    // 0xef5c54: ldur            x0, [fp, #-8]
    // 0xef5c58: stur            x3, [fp, #-0x50]
    // 0xef5c5c: LoadField: r1 = r0->field_b
    //     0xef5c5c: ldur            w1, [x0, #0xb]
    // 0xef5c60: DecompressPointer r1
    //     0xef5c60: add             x1, x1, HEAP, lsl #32
    // 0xef5c64: cmp             w1, NULL
    // 0xef5c68: b.eq            #0xef5e24
    // 0xef5c6c: mov             x1, x0
    // 0xef5c70: r0 = _defaults()
    //     0xef5c70: bl              #0xdffaf8  ; [package:flutter/src/material/tabs.dart] _TabBarState::_defaults
    // 0xef5c74: r1 = LoadClassIdInstr(r0)
    //     0xef5c74: ldur            x1, [x0, #-1]
    //     0xef5c78: ubfx            x1, x1, #0xc, #0x14
    // 0xef5c7c: r17 = 5058
    //     0xef5c7c: mov             x17, #0x13c2
    // 0xef5c80: cmp             x1, x17
    // 0xef5c84: b.eq            #0xef5cb0
    // 0xef5c88: r17 = 5059
    //     0xef5c88: mov             x17, #0x13c3
    // 0xef5c8c: cmp             x1, x17
    // 0xef5c90: b.ne            #0xef5c9c
    // 0xef5c94: r5 = 1.000000
    //     0xef5c94: ldr             x5, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xef5c98: b               #0xef5cbc
    // 0xef5c9c: r17 = 5060
    //     0xef5c9c: mov             x17, #0x13c4
    // 0xef5ca0: cmp             x1, x17
    // 0xef5ca4: b.ne            #0xef5cb0
    // 0xef5ca8: r5 = 1.000000
    //     0xef5ca8: ldr             x5, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xef5cac: b               #0xef5cbc
    // 0xef5cb0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xef5cb0: ldur            w1, [x0, #0x17]
    // 0xef5cb4: DecompressPointer r1
    //     0xef5cb4: add             x1, x1, HEAP, lsl #32
    // 0xef5cb8: mov             x5, x1
    // 0xef5cbc: ldur            x0, [fp, #-0x10]
    // 0xef5cc0: stur            x5, [fp, #-0x58]
    // 0xef5cc4: LoadField: r1 = r0->field_2f
    //     0xef5cc4: ldur            w1, [x0, #0x2f]
    // 0xef5cc8: DecompressPointer r1
    //     0xef5cc8: add             x1, x1, HEAP, lsl #32
    // 0xef5ccc: tbnz            w1, #4, #0xef5cec
    // 0xef5cd0: ldur            x0, [fp, #-8]
    // 0xef5cd4: LoadField: r1 = r0->field_b
    //     0xef5cd4: ldur            w1, [x0, #0xb]
    // 0xef5cd8: DecompressPointer r1
    //     0xef5cd8: add             x1, x1, HEAP, lsl #32
    // 0xef5cdc: cmp             w1, NULL
    // 0xef5ce0: b.eq            #0xef5e28
    // 0xef5ce4: r2 = true
    //     0xef5ce4: add             x2, NULL, #0x20  ; true
    // 0xef5ce8: b               #0xef5cf4
    // 0xef5cec: ldur            x0, [fp, #-8]
    // 0xef5cf0: r2 = false
    //     0xef5cf0: add             x2, NULL, #0x30  ; false
    // 0xef5cf4: stur            x2, [fp, #-0x10]
    // 0xef5cf8: LoadField: r1 = r0->field_f
    //     0xef5cf8: ldur            w1, [x0, #0xf]
    // 0xef5cfc: DecompressPointer r1
    //     0xef5cfc: add             x1, x1, HEAP, lsl #32
    // 0xef5d00: cmp             w1, NULL
    // 0xef5d04: b.eq            #0xef5e2c
    // 0xef5d08: r0 = devicePixelRatioOf()
    //     0xef5d08: bl              #0xcfce5c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::devicePixelRatioOf
    // 0xef5d0c: ldur            x0, [fp, #-8]
    // 0xef5d10: stur            d0, [fp, #-0x60]
    // 0xef5d14: LoadField: r1 = r0->field_b
    //     0xef5d14: ldur            w1, [x0, #0xb]
    // 0xef5d18: DecompressPointer r1
    //     0xef5d18: add             x1, x1, HEAP, lsl #32
    // 0xef5d1c: cmp             w1, NULL
    // 0xef5d20: b.eq            #0xef5e30
    // 0xef5d24: LoadField: r1 = r0->field_f
    //     0xef5d24: ldur            w1, [x0, #0xf]
    // 0xef5d28: DecompressPointer r1
    //     0xef5d28: add             x1, x1, HEAP, lsl #32
    // 0xef5d2c: cmp             w1, NULL
    // 0xef5d30: b.eq            #0xef5e34
    // 0xef5d34: r0 = of()
    //     0xef5d34: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xef5d38: ldur            x16, [fp, #-0x28]
    // 0xef5d3c: ldur            lr, [fp, #-0x38]
    // 0xef5d40: stp             lr, x16, [SP, #0x20]
    // 0xef5d44: ldur            x16, [fp, #-0x20]
    // 0xef5d48: ldur            lr, [fp, #-0x10]
    // 0xef5d4c: stp             lr, x16, [SP, #0x10]
    // 0xef5d50: ldur            x16, [fp, #-0x40]
    // 0xef5d54: stp             x0, x16, [SP]
    // 0xef5d58: ldur            x2, [fp, #-0x30]
    // 0xef5d5c: ldur            d0, [fp, #-0x60]
    // 0xef5d60: ldur            x3, [fp, #-0x50]
    // 0xef5d64: ldur            x5, [fp, #-0x58]
    // 0xef5d68: ldur            x6, [fp, #-0x48]
    // 0xef5d6c: ldur            x7, [fp, #-0x18]
    // 0xef5d70: r1 = Null
    //     0xef5d70: mov             x1, NULL
    // 0xef5d74: r0 = _IndicatorPainter()
    //     0xef5d74: bl              #0xef5f00  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::_IndicatorPainter
    // 0xef5d78: ldur            x1, [fp, #-8]
    // 0xef5d7c: ldur            x2, [fp, #-0x20]
    // 0xef5d80: StoreField: r1->field_1b = r0
    //     0xef5d80: stur            w0, [x1, #0x1b]
    //     0xef5d84: ldurb           w16, [x1, #-1]
    //     0xef5d88: ldurb           w17, [x0, #-1]
    //     0xef5d8c: and             x16, x17, x16, lsr #2
    //     0xef5d90: tst             x16, HEAP, lsr #32
    //     0xef5d94: b.eq            #0xef5d9c
    //     0xef5d98: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef5d9c: cmp             w2, NULL
    // 0xef5da0: b.eq            #0xef5dac
    // 0xef5da4: mov             x1, x2
    // 0xef5da8: r0 = dispose()
    //     0xef5da8: bl              #0xef5e38  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::dispose
    // 0xef5dac: r0 = Null
    //     0xef5dac: mov             x0, NULL
    // 0xef5db0: LeaveFrame
    //     0xef5db0: mov             SP, fp
    //     0xef5db4: ldp             fp, lr, [SP], #0x10
    // 0xef5db8: ret
    //     0xef5db8: ret             
    // 0xef5dbc: mov             x1, x0
    // 0xef5dc0: LoadField: r0 = r1->field_4f
    //     0xef5dc0: ldur            w0, [x1, #0x4f]
    // 0xef5dc4: DecompressPointer r0
    //     0xef5dc4: add             x0, x0, HEAP, lsl #32
    // 0xef5dc8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef5dcc: cmp             w0, w16
    // 0xef5dd0: b.ne            #0xef5de0
    // 0xef5dd4: r2 = _colors
    //     0xef5dd4: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0xef5dd8: ldr             x2, [x2, #0xf0]
    // 0xef5ddc: r0 = InitLateFinalInstanceField()
    //     0xef5ddc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xef5de0: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xef5de0: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xef5de4: r0 = Throw()
    //     0xef5de4: bl              #0x13ddb2c  ; ThrowStub
    // 0xef5de8: brk             #0
    // 0xef5dec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef5dec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef5df0: b               #0xef5a40
    // 0xef5df4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef5df4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef5df8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef5df8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef5dfc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef5dfc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef5e00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef5e00: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef5e04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef5e04: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef5e08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef5e08: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef5e0c: r9 = _tabKeys
    //     0xef5e0c: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8c650] Field <_TabBarState@780014024._tabKeys@780014024>: late (offset: 0x24)
    //     0xef5e10: ldr             x9, [x9, #0x650]
    // 0xef5e14: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef5e14: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xef5e18: r9 = _labelPaddings
    //     0xef5e18: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8c648] Field <_TabBarState@780014024._labelPaddings@780014024>: late (offset: 0x28)
    //     0xef5e1c: ldr             x9, [x9, #0x648]
    // 0xef5e20: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef5e20: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xef5e24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef5e24: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef5e28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef5e28: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef5e2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef5e2c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef5e30: r0 = NullCastErrorSharedWithFPURegs()
    //     0xef5e30: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xef5e34: r0 = NullCastErrorSharedWithFPURegs()
    //     0xef5e34: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _getIndicator(/* No info */) {
    // ** addr: 0xef626c, size: 0x4cc
    // 0xef626c: EnterFrame
    //     0xef626c: stp             fp, lr, [SP, #-0x10]!
    //     0xef6270: mov             fp, SP
    // 0xef6274: AllocStack(0x48)
    //     0xef6274: sub             SP, SP, #0x48
    // 0xef6278: SetupParameters(_TabBarState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xef6278: mov             x0, x1
    //     0xef627c: stur            x1, [fp, #-8]
    //     0xef6280: stur            x2, [fp, #-0x10]
    // 0xef6284: CheckStackOverflow
    //     0xef6284: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef6288: cmp             SP, x16
    //     0xef628c: b.ls            #0xef6714
    // 0xef6290: LoadField: r1 = r0->field_f
    //     0xef6290: ldur            w1, [x0, #0xf]
    // 0xef6294: DecompressPointer r1
    //     0xef6294: add             x1, x1, HEAP, lsl #32
    // 0xef6298: cmp             w1, NULL
    // 0xef629c: b.eq            #0xef671c
    // 0xef62a0: r0 = of()
    //     0xef62a0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xef62a4: mov             x2, x0
    // 0xef62a8: ldur            x0, [fp, #-8]
    // 0xef62ac: stur            x2, [fp, #-0x18]
    // 0xef62b0: LoadField: r1 = r0->field_f
    //     0xef62b0: ldur            w1, [x0, #0xf]
    // 0xef62b4: DecompressPointer r1
    //     0xef62b4: add             x1, x1, HEAP, lsl #32
    // 0xef62b8: cmp             w1, NULL
    // 0xef62bc: b.eq            #0xef6720
    // 0xef62c0: r0 = of()
    //     0xef62c0: bl              #0xdffc38  ; [package:flutter/src/material/tab_bar_theme.dart] TabBarTheme::of
    // 0xef62c4: mov             x1, x0
    // 0xef62c8: ldur            x0, [fp, #-8]
    // 0xef62cc: LoadField: r2 = r0->field_b
    //     0xef62cc: ldur            w2, [x0, #0xb]
    // 0xef62d0: DecompressPointer r2
    //     0xef62d0: add             x2, x2, HEAP, lsl #32
    // 0xef62d4: cmp             w2, NULL
    // 0xef62d8: b.eq            #0xef6724
    // 0xef62dc: LoadField: r3 = r2->field_2f
    //     0xef62dc: ldur            w3, [x2, #0x2f]
    // 0xef62e0: DecompressPointer r3
    //     0xef62e0: add             x3, x3, HEAP, lsl #32
    // 0xef62e4: cmp             w3, NULL
    // 0xef62e8: b.eq            #0xef62fc
    // 0xef62ec: mov             x0, x3
    // 0xef62f0: LeaveFrame
    //     0xef62f0: mov             SP, fp
    //     0xef62f4: ldp             fp, lr, [SP], #0x10
    // 0xef62f8: ret
    //     0xef62f8: ret             
    // 0xef62fc: LoadField: r3 = r1->field_7
    //     0xef62fc: ldur            w3, [x1, #7]
    // 0xef6300: DecompressPointer r3
    //     0xef6300: add             x3, x3, HEAP, lsl #32
    // 0xef6304: cmp             w3, NULL
    // 0xef6308: b.eq            #0xef631c
    // 0xef630c: mov             x0, x3
    // 0xef6310: LeaveFrame
    //     0xef6310: mov             SP, fp
    //     0xef6314: ldp             fp, lr, [SP], #0x10
    // 0xef6318: ret
    //     0xef6318: ret             
    // 0xef631c: LoadField: r1 = r2->field_1f
    //     0xef631c: ldur            w1, [x2, #0x1f]
    // 0xef6320: DecompressPointer r1
    //     0xef6320: add             x1, x1, HEAP, lsl #32
    // 0xef6324: cmp             w1, NULL
    // 0xef6328: b.ne            #0xef6330
    // 0xef632c: r1 = Null
    //     0xef632c: mov             x1, NULL
    // 0xef6330: cmp             w1, NULL
    // 0xef6334: b.ne            #0xef645c
    // 0xef6338: mov             x1, x0
    // 0xef633c: r0 = _defaults()
    //     0xef633c: bl              #0xdffaf8  ; [package:flutter/src/material/tabs.dart] _TabBarState::_defaults
    // 0xef6340: stur            x0, [fp, #-0x20]
    // 0xef6344: r1 = LoadClassIdInstr(r0)
    //     0xef6344: ldur            x1, [x0, #-1]
    //     0xef6348: ubfx            x1, x1, #0xc, #0x14
    // 0xef634c: r17 = 5058
    //     0xef634c: mov             x17, #0x13c2
    // 0xef6350: cmp             x1, x17
    // 0xef6354: b.ne            #0xef6368
    // 0xef6358: LoadField: r1 = r0->field_b
    //     0xef6358: ldur            w1, [x0, #0xb]
    // 0xef635c: DecompressPointer r1
    //     0xef635c: add             x1, x1, HEAP, lsl #32
    // 0xef6360: mov             x0, x1
    // 0xef6364: b               #0xef6454
    // 0xef6368: r17 = 5059
    //     0xef6368: mov             x17, #0x13c3
    // 0xef636c: cmp             x1, x17
    // 0xef6370: b.eq            #0xef66e4
    // 0xef6374: r17 = 5060
    //     0xef6374: mov             x17, #0x13c4
    // 0xef6378: cmp             x1, x17
    // 0xef637c: b.ne            #0xef63b4
    // 0xef6380: mov             x1, x0
    // 0xef6384: LoadField: r0 = r1->field_4f
    //     0xef6384: ldur            w0, [x1, #0x4f]
    // 0xef6388: DecompressPointer r0
    //     0xef6388: add             x0, x0, HEAP, lsl #32
    // 0xef638c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef6390: cmp             w0, w16
    // 0xef6394: b.ne            #0xef63a4
    // 0xef6398: r2 = _colors
    //     0xef6398: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0xef639c: ldr             x2, [x2, #0xb0]
    // 0xef63a0: r0 = InitLateFinalInstanceField()
    //     0xef63a0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xef63a4: LoadField: r1 = r0->field_b
    //     0xef63a4: ldur            w1, [x0, #0xb]
    // 0xef63a8: DecompressPointer r1
    //     0xef63a8: add             x1, x1, HEAP, lsl #32
    // 0xef63ac: mov             x0, x1
    // 0xef63b0: b               #0xef6454
    // 0xef63b4: mov             x1, x0
    // 0xef63b8: LoadField: r0 = r1->field_4f
    //     0xef63b8: ldur            w0, [x1, #0x4f]
    // 0xef63bc: DecompressPointer r0
    //     0xef63bc: add             x0, x0, HEAP, lsl #32
    // 0xef63c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef63c4: cmp             w0, w16
    // 0xef63c8: b.ne            #0xef63d8
    // 0xef63cc: r2 = _colors
    //     0xef63cc: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b8] Field <_TabsDefaultsM2@780014024._colors@780014024>: late final (offset: 0x50)
    //     0xef63d0: ldr             x2, [x2, #0xb8]
    // 0xef63d4: r0 = InitLateFinalInstanceField()
    //     0xef63d4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xef63d8: LoadField: r2 = r0->field_2b
    //     0xef63d8: ldur            w2, [x0, #0x2b]
    // 0xef63dc: DecompressPointer r2
    //     0xef63dc: add             x2, x2, HEAP, lsl #32
    // 0xef63e0: ldur            x1, [fp, #-0x20]
    // 0xef63e4: stur            x2, [fp, #-0x28]
    // 0xef63e8: LoadField: r0 = r1->field_57
    //     0xef63e8: ldur            w0, [x1, #0x57]
    // 0xef63ec: DecompressPointer r0
    //     0xef63ec: add             x0, x0, HEAP, lsl #32
    // 0xef63f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef63f4: cmp             w0, w16
    // 0xef63f8: b.ne            #0xef6408
    // 0xef63fc: r2 = primaryColor
    //     0xef63fc: add             x2, PP, #0x26, lsl #12  ; [pp+0x260c0] Field <_TabsDefaultsM2@780014024.primaryColor>: late final (offset: 0x58)
    //     0xef6400: ldr             x2, [x2, #0xc0]
    // 0xef6404: r0 = InitLateFinalInstanceField()
    //     0xef6404: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xef6408: mov             x1, x0
    // 0xef640c: ldur            x0, [fp, #-0x28]
    // 0xef6410: r2 = LoadClassIdInstr(r0)
    //     0xef6410: ldur            x2, [x0, #-1]
    //     0xef6414: ubfx            x2, x2, #0xc, #0x14
    // 0xef6418: stp             x1, x0, [SP]
    // 0xef641c: mov             x0, x2
    // 0xef6420: mov             lr, x0
    // 0xef6424: ldr             lr, [x21, lr, lsl #3]
    // 0xef6428: blr             lr
    // 0xef642c: tbnz            w0, #4, #0xef643c
    // 0xef6430: r0 = Instance_Color
    //     0xef6430: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xef6434: ldr             x0, [x0, #0xc38]
    // 0xef6438: b               #0xef6454
    // 0xef643c: ldur            x1, [fp, #-0x20]
    // 0xef6440: LoadField: r0 = r1->field_4f
    //     0xef6440: ldur            w0, [x1, #0x4f]
    // 0xef6444: DecompressPointer r0
    //     0xef6444: add             x0, x0, HEAP, lsl #32
    // 0xef6448: LoadField: r1 = r0->field_2b
    //     0xef6448: ldur            w1, [x0, #0x2b]
    // 0xef644c: DecompressPointer r1
    //     0xef644c: add             x1, x1, HEAP, lsl #32
    // 0xef6450: mov             x0, x1
    // 0xef6454: mov             x3, x0
    // 0xef6458: b               #0xef6460
    // 0xef645c: mov             x3, x1
    // 0xef6460: ldur            x2, [fp, #-8]
    // 0xef6464: stur            x3, [fp, #-0x28]
    // 0xef6468: LoadField: r0 = r2->field_b
    //     0xef6468: ldur            w0, [x2, #0xb]
    // 0xef646c: DecompressPointer r0
    //     0xef646c: add             x0, x0, HEAP, lsl #32
    // 0xef6470: cmp             w0, NULL
    // 0xef6474: b.eq            #0xef6728
    // 0xef6478: r0 = LoadClassIdInstr(r3)
    //     0xef6478: ldur            x0, [x3, #-1]
    //     0xef647c: ubfx            x0, x0, #0xc, #0x14
    // 0xef6480: mov             x1, x3
    // 0xef6484: r0 = GDT[cid_x0 + -0xfb8]()
    //     0xef6484: sub             lr, x0, #0xfb8
    //     0xef6488: ldr             lr, [x21, lr, lsl #3]
    //     0xef648c: blr             lr
    // 0xef6490: mov             x2, x0
    // 0xef6494: ldur            x0, [fp, #-8]
    // 0xef6498: stur            x2, [fp, #-0x30]
    // 0xef649c: LoadField: r1 = r0->field_f
    //     0xef649c: ldur            w1, [x0, #0xf]
    // 0xef64a0: DecompressPointer r1
    //     0xef64a0: add             x1, x1, HEAP, lsl #32
    // 0xef64a4: cmp             w1, NULL
    // 0xef64a8: b.eq            #0xef672c
    // 0xef64ac: r0 = maybeOf()
    //     0xef64ac: bl              #0xd21e70  ; [package:flutter/src/material/material.dart] Material::maybeOf
    // 0xef64b0: cmp             w0, NULL
    // 0xef64b4: b.ne            #0xef64c0
    // 0xef64b8: r3 = Null
    //     0xef64b8: mov             x3, NULL
    // 0xef64bc: b               #0xef6508
    // 0xef64c0: LoadField: r1 = r0->field_57
    //     0xef64c0: ldur            w1, [x0, #0x57]
    // 0xef64c4: DecompressPointer r1
    //     0xef64c4: add             x1, x1, HEAP, lsl #32
    // 0xef64c8: cmp             w1, NULL
    // 0xef64cc: b.ne            #0xef64d8
    // 0xef64d0: r0 = Null
    //     0xef64d0: mov             x0, NULL
    // 0xef64d4: b               #0xef6504
    // 0xef64d8: r0 = LoadClassIdInstr(r1)
    //     0xef64d8: ldur            x0, [x1, #-1]
    //     0xef64dc: ubfx            x0, x0, #0xc, #0x14
    // 0xef64e0: r0 = GDT[cid_x0 + -0xfb8]()
    //     0xef64e0: sub             lr, x0, #0xfb8
    //     0xef64e4: ldr             lr, [x21, lr, lsl #3]
    //     0xef64e8: blr             lr
    // 0xef64ec: mov             x2, x0
    // 0xef64f0: r0 = BoxInt64Instr(r2)
    //     0xef64f0: sbfiz           x0, x2, #1, #0x1f
    //     0xef64f4: cmp             x2, x0, asr #1
    //     0xef64f8: b.eq            #0xef6504
    //     0xef64fc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xef6500: stur            x2, [x0, #7]
    // 0xef6504: mov             x3, x0
    // 0xef6508: ldur            x2, [fp, #-0x30]
    // 0xef650c: r0 = BoxInt64Instr(r2)
    //     0xef650c: sbfiz           x0, x2, #1, #0x1f
    //     0xef6510: cmp             x2, x0, asr #1
    //     0xef6514: b.eq            #0xef6520
    //     0xef6518: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xef651c: stur            x2, [x0, #7]
    // 0xef6520: cmp             w0, w3
    // 0xef6524: b.eq            #0xef6560
    // 0xef6528: and             w16, w0, w3
    // 0xef652c: branchIfSmi(r16, 0xef656c)
    //     0xef652c: tbz             w16, #0, #0xef656c
    // 0xef6530: r16 = LoadClassIdInstr(r0)
    //     0xef6530: ldur            x16, [x0, #-1]
    //     0xef6534: ubfx            x16, x16, #0xc, #0x14
    // 0xef6538: cmp             x16, #0x3d
    // 0xef653c: b.ne            #0xef656c
    // 0xef6540: r16 = LoadClassIdInstr(r3)
    //     0xef6540: ldur            x16, [x3, #-1]
    //     0xef6544: ubfx            x16, x16, #0xc, #0x14
    // 0xef6548: cmp             x16, #0x3d
    // 0xef654c: b.ne            #0xef656c
    // 0xef6550: LoadField: r16 = r0->field_7
    //     0xef6550: ldur            x16, [x0, #7]
    // 0xef6554: LoadField: r17 = r3->field_7
    //     0xef6554: ldur            x17, [x3, #7]
    // 0xef6558: cmp             x16, x17
    // 0xef655c: b.ne            #0xef656c
    // 0xef6560: r1 = Instance_Color
    //     0xef6560: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xef6564: ldr             x1, [x1, #0xc38]
    // 0xef6568: b               #0xef6570
    // 0xef656c: ldur            x1, [fp, #-0x28]
    // 0xef6570: ldur            x0, [fp, #-0x18]
    // 0xef6574: stur            x1, [fp, #-0x28]
    // 0xef6578: LoadField: r2 = r0->field_2f
    //     0xef6578: ldur            w2, [x0, #0x2f]
    // 0xef657c: DecompressPointer r2
    //     0xef657c: add             x2, x2, HEAP, lsl #32
    // 0xef6580: tbnz            w2, #4, #0xef65e0
    // 0xef6584: ldur            x0, [fp, #-8]
    // 0xef6588: LoadField: r3 = r0->field_b
    //     0xef6588: ldur            w3, [x0, #0xb]
    // 0xef658c: DecompressPointer r3
    //     0xef658c: add             x3, x3, HEAP, lsl #32
    // 0xef6590: cmp             w3, NULL
    // 0xef6594: b.eq            #0xef6730
    // 0xef6598: LoadField: r0 = r3->field_83
    //     0xef6598: ldur            w0, [x3, #0x83]
    // 0xef659c: DecompressPointer r0
    //     0xef659c: add             x0, x0, HEAP, lsl #32
    // 0xef65a0: tbnz            w0, #4, #0xef65c8
    // 0xef65a4: ldur            x3, [fp, #-0x10]
    // 0xef65a8: LoadField: r0 = r3->field_7
    //     0xef65a8: ldur            x0, [x3, #7]
    // 0xef65ac: cmp             x0, #0
    // 0xef65b0: b.gt            #0xef65bc
    // 0xef65b4: d0 = 2.000000
    //     0xef65b4: fmov            d0, #2.00000000
    // 0xef65b8: b               #0xef65c0
    // 0xef65bc: d0 = 3.000000
    //     0xef65bc: fmov            d0, #3.00000000
    // 0xef65c0: mov             v1.16b, v0.16b
    // 0xef65c4: b               #0xef65d0
    // 0xef65c8: ldur            x3, [fp, #-0x10]
    // 0xef65cc: d1 = 2.000000
    //     0xef65cc: fmov            d1, #2.00000000
    // 0xef65d0: d0 = 2.000000
    //     0xef65d0: fmov            d0, #2.00000000
    // 0xef65d4: fmax            v2.2d, v0.2d, v1.2d
    // 0xef65d8: mov             v0.16b, v2.16b
    // 0xef65dc: b               #0xef65fc
    // 0xef65e0: ldur            x0, [fp, #-8]
    // 0xef65e4: ldur            x3, [fp, #-0x10]
    // 0xef65e8: LoadField: r4 = r0->field_b
    //     0xef65e8: ldur            w4, [x0, #0xb]
    // 0xef65ec: DecompressPointer r4
    //     0xef65ec: add             x4, x4, HEAP, lsl #32
    // 0xef65f0: cmp             w4, NULL
    // 0xef65f4: b.eq            #0xef6734
    // 0xef65f8: d0 = 2.000000
    //     0xef65f8: fmov            d0, #2.00000000
    // 0xef65fc: stur            d0, [fp, #-0x38]
    // 0xef6600: LoadField: r0 = r3->field_7
    //     0xef6600: ldur            x0, [x3, #7]
    // 0xef6604: cmp             x0, #0
    // 0xef6608: b.gt            #0xef6614
    // 0xef660c: r0 = false
    //     0xef660c: add             x0, NULL, #0x30  ; false
    // 0xef6610: b               #0xef6618
    // 0xef6614: r0 = true
    //     0xef6614: add             x0, NULL, #0x20  ; true
    // 0xef6618: tbnz            w2, #4, #0xef6674
    // 0xef661c: tbnz            w0, #4, #0xef6674
    // 0xef6620: r0 = Radius()
    //     0xef6620: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xef6624: ldur            d0, [fp, #-0x38]
    // 0xef6628: stur            x0, [fp, #-8]
    // 0xef662c: StoreField: r0->field_7 = d0
    //     0xef662c: stur            d0, [x0, #7]
    // 0xef6630: StoreField: r0->field_f = d0
    //     0xef6630: stur            d0, [x0, #0xf]
    // 0xef6634: r0 = Radius()
    //     0xef6634: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xef6638: ldur            d0, [fp, #-0x38]
    // 0xef663c: stur            x0, [fp, #-0x10]
    // 0xef6640: StoreField: r0->field_7 = d0
    //     0xef6640: stur            d0, [x0, #7]
    // 0xef6644: StoreField: r0->field_f = d0
    //     0xef6644: stur            d0, [x0, #0xf]
    // 0xef6648: r0 = BorderRadius()
    //     0xef6648: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xef664c: mov             x1, x0
    // 0xef6650: ldur            x0, [fp, #-8]
    // 0xef6654: StoreField: r1->field_7 = r0
    //     0xef6654: stur            w0, [x1, #7]
    // 0xef6658: ldur            x0, [fp, #-0x10]
    // 0xef665c: StoreField: r1->field_b = r0
    //     0xef665c: stur            w0, [x1, #0xb]
    // 0xef6660: r0 = Instance_Radius
    //     0xef6660: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1a0] Obj!Radius@12a71a1
    //     0xef6664: ldr             x0, [x0, #0x1a0]
    // 0xef6668: StoreField: r1->field_f = r0
    //     0xef6668: stur            w0, [x1, #0xf]
    // 0xef666c: StoreField: r1->field_13 = r0
    //     0xef666c: stur            w0, [x1, #0x13]
    // 0xef6670: b               #0xef6678
    // 0xef6674: r1 = Null
    //     0xef6674: mov             x1, NULL
    // 0xef6678: ldur            x0, [fp, #-0x28]
    // 0xef667c: ldur            d0, [fp, #-0x38]
    // 0xef6680: stur            x1, [fp, #-8]
    // 0xef6684: r0 = BorderSide()
    //     0xef6684: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xef6688: mov             x1, x0
    // 0xef668c: ldur            x0, [fp, #-0x28]
    // 0xef6690: stur            x1, [fp, #-0x10]
    // 0xef6694: StoreField: r1->field_7 = r0
    //     0xef6694: stur            w0, [x1, #7]
    // 0xef6698: ldur            d0, [fp, #-0x38]
    // 0xef669c: StoreField: r1->field_b = d0
    //     0xef669c: stur            d0, [x1, #0xb]
    // 0xef66a0: r0 = Instance_BorderStyle
    //     0xef66a0: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xef66a4: ldr             x0, [x0, #0xdc8]
    // 0xef66a8: StoreField: r1->field_13 = r0
    //     0xef66a8: stur            w0, [x1, #0x13]
    // 0xef66ac: d0 = -1.000000
    //     0xef66ac: fmov            d0, #-1.00000000
    // 0xef66b0: ArrayStore: r1[0] = d0  ; List_8
    //     0xef66b0: stur            d0, [x1, #0x17]
    // 0xef66b4: r0 = UnderlineTabIndicator()
    //     0xef66b4: bl              #0xeb4770  ; AllocateUnderlineTabIndicatorStub -> UnderlineTabIndicator (size=0x14)
    // 0xef66b8: mov             x1, x0
    // 0xef66bc: ldur            x0, [fp, #-8]
    // 0xef66c0: StoreField: r1->field_7 = r0
    //     0xef66c0: stur            w0, [x1, #7]
    // 0xef66c4: ldur            x0, [fp, #-0x10]
    // 0xef66c8: StoreField: r1->field_b = r0
    //     0xef66c8: stur            w0, [x1, #0xb]
    // 0xef66cc: r0 = Instance_EdgeInsets
    //     0xef66cc: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xef66d0: StoreField: r1->field_f = r0
    //     0xef66d0: stur            w0, [x1, #0xf]
    // 0xef66d4: mov             x0, x1
    // 0xef66d8: LeaveFrame
    //     0xef66d8: mov             SP, fp
    //     0xef66dc: ldp             fp, lr, [SP], #0x10
    // 0xef66e0: ret
    //     0xef66e0: ret             
    // 0xef66e4: mov             x1, x0
    // 0xef66e8: LoadField: r0 = r1->field_4f
    //     0xef66e8: ldur            w0, [x1, #0x4f]
    // 0xef66ec: DecompressPointer r0
    //     0xef66ec: add             x0, x0, HEAP, lsl #32
    // 0xef66f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef66f4: cmp             w0, w16
    // 0xef66f8: b.ne            #0xef6708
    // 0xef66fc: r2 = _colors
    //     0xef66fc: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0xef6700: ldr             x2, [x2, #0xf0]
    // 0xef6704: r0 = InitLateFinalInstanceField()
    //     0xef6704: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xef6708: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xef6708: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xef670c: r0 = Throw()
    //     0xef670c: bl              #0x13ddb2c  ; ThrowStub
    // 0xef6710: brk             #0
    // 0xef6714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef6714: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef6718: b               #0xef6290
    // 0xef671c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef671c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef6720: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef6720: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef6724: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef6724: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef6728: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef6728: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef672c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef672c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef6730: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef6730: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef6734: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef6734: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _controllerIsValid(/* No info */) {
    // ** addr: 0xef6800, size: 0x40
    // 0xef6800: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xef6800: ldur            w2, [x1, #0x17]
    // 0xef6804: DecompressPointer r2
    //     0xef6804: add             x2, x2, HEAP, lsl #32
    // 0xef6808: cmp             w2, NULL
    // 0xef680c: b.ne            #0xef6818
    // 0xef6810: r1 = Null
    //     0xef6810: mov             x1, NULL
    // 0xef6814: b               #0xef682c
    // 0xef6818: LoadField: r1 = r2->field_23
    //     0xef6818: ldur            w1, [x2, #0x23]
    // 0xef681c: DecompressPointer r1
    //     0xef681c: add             x1, x1, HEAP, lsl #32
    // 0xef6820: cmp             w1, NULL
    // 0xef6824: b.ne            #0xef682c
    // 0xef6828: r1 = Null
    //     0xef6828: mov             x1, NULL
    // 0xef682c: cmp             w1, NULL
    // 0xef6830: r16 = true
    //     0xef6830: add             x16, NULL, #0x20  ; true
    // 0xef6834: r17 = false
    //     0xef6834: add             x17, NULL, #0x30  ; false
    // 0xef6838: csel            x0, x16, x17, ne
    // 0xef683c: ret
    //     0xef683c: ret             
  }
  _ _updateTabController(/* No info */) {
    // ** addr: 0xef6840, size: 0x23c
    // 0xef6840: EnterFrame
    //     0xef6840: stp             fp, lr, [SP, #-0x10]!
    //     0xef6844: mov             fp, SP
    // 0xef6848: AllocStack(0x18)
    //     0xef6848: sub             SP, SP, #0x18
    // 0xef684c: SetupParameters(_TabBarState this /* r1 => r0, fp-0x8 */)
    //     0xef684c: mov             x0, x1
    //     0xef6850: stur            x1, [fp, #-8]
    // 0xef6854: CheckStackOverflow
    //     0xef6854: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef6858: cmp             SP, x16
    //     0xef685c: b.ls            #0xef6a54
    // 0xef6860: LoadField: r1 = r0->field_b
    //     0xef6860: ldur            w1, [x0, #0xb]
    // 0xef6864: DecompressPointer r1
    //     0xef6864: add             x1, x1, HEAP, lsl #32
    // 0xef6868: cmp             w1, NULL
    // 0xef686c: b.eq            #0xef6a5c
    // 0xef6870: LoadField: r2 = r1->field_f
    //     0xef6870: ldur            w2, [x1, #0xf]
    // 0xef6874: DecompressPointer r2
    //     0xef6874: add             x2, x2, HEAP, lsl #32
    // 0xef6878: cmp             w2, NULL
    // 0xef687c: b.ne            #0xef6898
    // 0xef6880: LoadField: r1 = r0->field_f
    //     0xef6880: ldur            w1, [x0, #0xf]
    // 0xef6884: DecompressPointer r1
    //     0xef6884: add             x1, x1, HEAP, lsl #32
    // 0xef6888: cmp             w1, NULL
    // 0xef688c: b.eq            #0xef6a60
    // 0xef6890: r0 = maybeOf()
    //     0xef6890: bl              #0xef6a7c  ; [package:flutter/src/material/tab_controller.dart] DefaultTabController::maybeOf
    // 0xef6894: mov             x2, x0
    // 0xef6898: ldur            x0, [fp, #-8]
    // 0xef689c: stur            x2, [fp, #-0x10]
    // 0xef68a0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xef68a0: ldur            w1, [x0, #0x17]
    // 0xef68a4: DecompressPointer r1
    //     0xef68a4: add             x1, x1, HEAP, lsl #32
    // 0xef68a8: cmp             w2, w1
    // 0xef68ac: b.ne            #0xef68c0
    // 0xef68b0: r0 = Null
    //     0xef68b0: mov             x0, NULL
    // 0xef68b4: LeaveFrame
    //     0xef68b4: mov             SP, fp
    //     0xef68b8: ldp             fp, lr, [SP], #0x10
    // 0xef68bc: ret
    //     0xef68bc: ret             
    // 0xef68c0: mov             x1, x0
    // 0xef68c4: r0 = _controllerIsValid()
    //     0xef68c4: bl              #0xef6800  ; [package:flutter/src/material/tabs.dart] _TabBarState::_controllerIsValid
    // 0xef68c8: tbnz            w0, #4, #0xef6958
    // 0xef68cc: ldur            x0, [fp, #-8]
    // 0xef68d0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xef68d0: ldur            w1, [x0, #0x17]
    // 0xef68d4: DecompressPointer r1
    //     0xef68d4: add             x1, x1, HEAP, lsl #32
    // 0xef68d8: cmp             w1, NULL
    // 0xef68dc: b.eq            #0xef6a64
    // 0xef68e0: LoadField: r2 = r1->field_23
    //     0xef68e0: ldur            w2, [x1, #0x23]
    // 0xef68e4: DecompressPointer r2
    //     0xef68e4: add             x2, x2, HEAP, lsl #32
    // 0xef68e8: cmp             w2, NULL
    // 0xef68ec: b.ne            #0xef68f8
    // 0xef68f0: r3 = Null
    //     0xef68f0: mov             x3, NULL
    // 0xef68f4: b               #0xef68fc
    // 0xef68f8: mov             x3, x2
    // 0xef68fc: stur            x3, [fp, #-0x18]
    // 0xef6900: cmp             w3, NULL
    // 0xef6904: b.eq            #0xef6a68
    // 0xef6908: mov             x2, x0
    // 0xef690c: r1 = Function '_handleTabControllerAnimationTick@780014024':.
    //     0xef690c: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c680] AnonymousClosure: (0xef6c0c), in [package:flutter/src/material/tabs.dart] _TabBarState::_handleTabControllerAnimationTick (0xef6c44)
    //     0xef6910: ldr             x1, [x1, #0x680]
    // 0xef6914: r0 = AllocateClosure()
    //     0xef6914: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef6918: ldur            x1, [fp, #-0x18]
    // 0xef691c: mov             x2, x0
    // 0xef6920: r0 = removeListener()
    //     0xef6920: bl              #0xd00c74  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::removeListener
    // 0xef6924: ldur            x0, [fp, #-8]
    // 0xef6928: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xef6928: ldur            w3, [x0, #0x17]
    // 0xef692c: DecompressPointer r3
    //     0xef692c: add             x3, x3, HEAP, lsl #32
    // 0xef6930: stur            x3, [fp, #-0x18]
    // 0xef6934: cmp             w3, NULL
    // 0xef6938: b.eq            #0xef6a6c
    // 0xef693c: mov             x2, x0
    // 0xef6940: r1 = Function '_handleTabControllerTick@780014024':.
    //     0xef6940: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c688] AnonymousClosure: (0xef6ad8), in [package:flutter/src/material/tabs.dart] _TabBarState::_handleTabControllerTick (0xef6b10)
    //     0xef6944: ldr             x1, [x1, #0x688]
    // 0xef6948: r0 = AllocateClosure()
    //     0xef6948: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef694c: ldur            x1, [fp, #-0x18]
    // 0xef6950: mov             x2, x0
    // 0xef6954: r0 = removeListener()
    //     0xef6954: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xef6958: ldur            x3, [fp, #-8]
    // 0xef695c: ldur            x1, [fp, #-0x10]
    // 0xef6960: mov             x0, x1
    // 0xef6964: ArrayStore: r3[0] = r0  ; List_4
    //     0xef6964: stur            w0, [x3, #0x17]
    //     0xef6968: ldurb           w16, [x3, #-1]
    //     0xef696c: ldurb           w17, [x0, #-1]
    //     0xef6970: and             x16, x17, x16, lsr #2
    //     0xef6974: tst             x16, HEAP, lsr #32
    //     0xef6978: b.eq            #0xef6980
    //     0xef697c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xef6980: cmp             w1, NULL
    // 0xef6984: b.eq            #0xef6a44
    // 0xef6988: LoadField: r0 = r1->field_23
    //     0xef6988: ldur            w0, [x1, #0x23]
    // 0xef698c: DecompressPointer r0
    //     0xef698c: add             x0, x0, HEAP, lsl #32
    // 0xef6990: cmp             w0, NULL
    // 0xef6994: b.ne            #0xef699c
    // 0xef6998: r0 = Null
    //     0xef6998: mov             x0, NULL
    // 0xef699c: stur            x0, [fp, #-0x10]
    // 0xef69a0: cmp             w0, NULL
    // 0xef69a4: b.eq            #0xef6a70
    // 0xef69a8: mov             x2, x3
    // 0xef69ac: r1 = Function '_handleTabControllerAnimationTick@780014024':.
    //     0xef69ac: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c680] AnonymousClosure: (0xef6c0c), in [package:flutter/src/material/tabs.dart] _TabBarState::_handleTabControllerAnimationTick (0xef6c44)
    //     0xef69b0: ldr             x1, [x1, #0x680]
    // 0xef69b4: r0 = AllocateClosure()
    //     0xef69b4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef69b8: ldur            x1, [fp, #-0x10]
    // 0xef69bc: mov             x2, x0
    // 0xef69c0: r0 = addListener()
    //     0xef69c0: bl              #0xd0440c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::addListener
    // 0xef69c4: ldur            x0, [fp, #-8]
    // 0xef69c8: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xef69c8: ldur            w3, [x0, #0x17]
    // 0xef69cc: DecompressPointer r3
    //     0xef69cc: add             x3, x3, HEAP, lsl #32
    // 0xef69d0: stur            x3, [fp, #-0x10]
    // 0xef69d4: cmp             w3, NULL
    // 0xef69d8: b.eq            #0xef6a74
    // 0xef69dc: mov             x2, x0
    // 0xef69e0: r1 = Function '_handleTabControllerTick@780014024':.
    //     0xef69e0: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c688] AnonymousClosure: (0xef6ad8), in [package:flutter/src/material/tabs.dart] _TabBarState::_handleTabControllerTick (0xef6b10)
    //     0xef69e4: ldr             x1, [x1, #0x688]
    // 0xef69e8: r0 = AllocateClosure()
    //     0xef69e8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef69ec: ldur            x1, [fp, #-0x10]
    // 0xef69f0: mov             x2, x0
    // 0xef69f4: r0 = addListener()
    //     0xef69f4: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xef69f8: ldur            x2, [fp, #-8]
    // 0xef69fc: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xef69fc: ldur            w3, [x2, #0x17]
    // 0xef6a00: DecompressPointer r3
    //     0xef6a00: add             x3, x3, HEAP, lsl #32
    // 0xef6a04: cmp             w3, NULL
    // 0xef6a08: b.eq            #0xef6a78
    // 0xef6a0c: LoadField: r4 = r3->field_33
    //     0xef6a0c: ldur            x4, [x3, #0x33]
    // 0xef6a10: r0 = BoxInt64Instr(r4)
    //     0xef6a10: sbfiz           x0, x4, #1, #0x1f
    //     0xef6a14: cmp             x4, x0, asr #1
    //     0xef6a18: b.eq            #0xef6a24
    //     0xef6a1c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xef6a20: stur            x4, [x0, #7]
    // 0xef6a24: StoreField: r2->field_1f = r0
    //     0xef6a24: stur            w0, [x2, #0x1f]
    //     0xef6a28: tbz             w0, #0, #0xef6a44
    //     0xef6a2c: ldurb           w16, [x2, #-1]
    //     0xef6a30: ldurb           w17, [x0, #-1]
    //     0xef6a34: and             x16, x17, x16, lsr #2
    //     0xef6a38: tst             x16, HEAP, lsr #32
    //     0xef6a3c: b.eq            #0xef6a44
    //     0xef6a40: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xef6a44: r0 = Null
    //     0xef6a44: mov             x0, NULL
    // 0xef6a48: LeaveFrame
    //     0xef6a48: mov             SP, fp
    //     0xef6a4c: ldp             fp, lr, [SP], #0x10
    // 0xef6a50: ret
    //     0xef6a50: ret             
    // 0xef6a54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef6a54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef6a58: b               #0xef6860
    // 0xef6a5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef6a5c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef6a60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef6a60: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef6a64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef6a64: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef6a68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef6a68: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef6a6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef6a6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef6a70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef6a70: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef6a74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef6a74: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef6a78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef6a78: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleTabControllerTick(dynamic) {
    // ** addr: 0xef6ad8, size: 0x38
    // 0xef6ad8: EnterFrame
    //     0xef6ad8: stp             fp, lr, [SP, #-0x10]!
    //     0xef6adc: mov             fp, SP
    // 0xef6ae0: ldr             x0, [fp, #0x10]
    // 0xef6ae4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xef6ae4: ldur            w1, [x0, #0x17]
    // 0xef6ae8: DecompressPointer r1
    //     0xef6ae8: add             x1, x1, HEAP, lsl #32
    // 0xef6aec: CheckStackOverflow
    //     0xef6aec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef6af0: cmp             SP, x16
    //     0xef6af4: b.ls            #0xef6b08
    // 0xef6af8: r0 = _handleTabControllerTick()
    //     0xef6af8: bl              #0xef6b10  ; [package:flutter/src/material/tabs.dart] _TabBarState::_handleTabControllerTick
    // 0xef6afc: LeaveFrame
    //     0xef6afc: mov             SP, fp
    //     0xef6b00: ldp             fp, lr, [SP], #0x10
    // 0xef6b04: ret
    //     0xef6b04: ret             
    // 0xef6b08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef6b08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef6b0c: b               #0xef6af8
  }
  _ _handleTabControllerTick(/* No info */) {
    // ** addr: 0xef6b10, size: 0xfc
    // 0xef6b10: EnterFrame
    //     0xef6b10: stp             fp, lr, [SP, #-0x10]!
    //     0xef6b14: mov             fp, SP
    // 0xef6b18: AllocStack(0x8)
    //     0xef6b18: sub             SP, SP, #8
    // 0xef6b1c: SetupParameters(_TabBarState this /* r1 => r3, fp-0x8 */)
    //     0xef6b1c: mov             x3, x1
    //     0xef6b20: stur            x1, [fp, #-8]
    // 0xef6b24: CheckStackOverflow
    //     0xef6b24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef6b28: cmp             SP, x16
    //     0xef6b2c: b.ls            #0xef6bfc
    // 0xef6b30: ArrayLoad: r0 = r3[0]  ; List_4
    //     0xef6b30: ldur            w0, [x3, #0x17]
    // 0xef6b34: DecompressPointer r0
    //     0xef6b34: add             x0, x0, HEAP, lsl #32
    // 0xef6b38: cmp             w0, NULL
    // 0xef6b3c: b.eq            #0xef6c04
    // 0xef6b40: LoadField: r2 = r0->field_33
    //     0xef6b40: ldur            x2, [x0, #0x33]
    // 0xef6b44: LoadField: r4 = r3->field_1f
    //     0xef6b44: ldur            w4, [x3, #0x1f]
    // 0xef6b48: DecompressPointer r4
    //     0xef6b48: add             x4, x4, HEAP, lsl #32
    // 0xef6b4c: r0 = BoxInt64Instr(r2)
    //     0xef6b4c: sbfiz           x0, x2, #1, #0x1f
    //     0xef6b50: cmp             x2, x0, asr #1
    //     0xef6b54: b.eq            #0xef6b60
    //     0xef6b58: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xef6b5c: stur            x2, [x0, #7]
    // 0xef6b60: cmp             w0, w4
    // 0xef6b64: b.eq            #0xef6bd0
    // 0xef6b68: and             w16, w0, w4
    // 0xef6b6c: branchIfSmi(r16, 0xef6ba0)
    //     0xef6b6c: tbz             w16, #0, #0xef6ba0
    // 0xef6b70: r16 = LoadClassIdInstr(r0)
    //     0xef6b70: ldur            x16, [x0, #-1]
    //     0xef6b74: ubfx            x16, x16, #0xc, #0x14
    // 0xef6b78: cmp             x16, #0x3d
    // 0xef6b7c: b.ne            #0xef6ba0
    // 0xef6b80: r16 = LoadClassIdInstr(r4)
    //     0xef6b80: ldur            x16, [x4, #-1]
    //     0xef6b84: ubfx            x16, x16, #0xc, #0x14
    // 0xef6b88: cmp             x16, #0x3d
    // 0xef6b8c: b.ne            #0xef6ba0
    // 0xef6b90: LoadField: r16 = r0->field_7
    //     0xef6b90: ldur            x16, [x0, #7]
    // 0xef6b94: LoadField: r17 = r4->field_7
    //     0xef6b94: ldur            x17, [x4, #7]
    // 0xef6b98: cmp             x16, x17
    // 0xef6b9c: b.eq            #0xef6bd0
    // 0xef6ba0: StoreField: r3->field_1f = r0
    //     0xef6ba0: stur            w0, [x3, #0x1f]
    //     0xef6ba4: tbz             w0, #0, #0xef6bc0
    //     0xef6ba8: ldurb           w16, [x3, #-1]
    //     0xef6bac: ldurb           w17, [x0, #-1]
    //     0xef6bb0: and             x16, x17, x16, lsr #2
    //     0xef6bb4: tst             x16, HEAP, lsr #32
    //     0xef6bb8: b.eq            #0xef6bc0
    //     0xef6bbc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xef6bc0: LoadField: r0 = r3->field_b
    //     0xef6bc0: ldur            w0, [x3, #0xb]
    // 0xef6bc4: DecompressPointer r0
    //     0xef6bc4: add             x0, x0, HEAP, lsl #32
    // 0xef6bc8: cmp             w0, NULL
    // 0xef6bcc: b.eq            #0xef6c08
    // 0xef6bd0: r1 = Function '<anonymous closure>':.
    //     0xef6bd0: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c690] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xef6bd4: ldr             x1, [x1, #0x690]
    // 0xef6bd8: r2 = Null
    //     0xef6bd8: mov             x2, NULL
    // 0xef6bdc: r0 = AllocateClosure()
    //     0xef6bdc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef6be0: ldur            x1, [fp, #-8]
    // 0xef6be4: mov             x2, x0
    // 0xef6be8: r0 = setState()
    //     0xef6be8: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xef6bec: r0 = Null
    //     0xef6bec: mov             x0, NULL
    // 0xef6bf0: LeaveFrame
    //     0xef6bf0: mov             SP, fp
    //     0xef6bf4: ldp             fp, lr, [SP], #0x10
    // 0xef6bf8: ret
    //     0xef6bf8: ret             
    // 0xef6bfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef6bfc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef6c00: b               #0xef6b30
    // 0xef6c04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef6c04: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef6c08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef6c08: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleTabControllerAnimationTick(dynamic) {
    // ** addr: 0xef6c0c, size: 0x38
    // 0xef6c0c: EnterFrame
    //     0xef6c0c: stp             fp, lr, [SP, #-0x10]!
    //     0xef6c10: mov             fp, SP
    // 0xef6c14: ldr             x0, [fp, #0x10]
    // 0xef6c18: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xef6c18: ldur            w1, [x0, #0x17]
    // 0xef6c1c: DecompressPointer r1
    //     0xef6c1c: add             x1, x1, HEAP, lsl #32
    // 0xef6c20: CheckStackOverflow
    //     0xef6c20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef6c24: cmp             SP, x16
    //     0xef6c28: b.ls            #0xef6c3c
    // 0xef6c2c: r0 = _handleTabControllerAnimationTick()
    //     0xef6c2c: bl              #0xef6c44  ; [package:flutter/src/material/tabs.dart] _TabBarState::_handleTabControllerAnimationTick
    // 0xef6c30: LeaveFrame
    //     0xef6c30: mov             SP, fp
    //     0xef6c34: ldp             fp, lr, [SP], #0x10
    // 0xef6c38: ret
    //     0xef6c38: ret             
    // 0xef6c3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef6c3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef6c40: b               #0xef6c2c
  }
  _ _handleTabControllerAnimationTick(/* No info */) {
    // ** addr: 0xef6c44, size: 0x48
    // 0xef6c44: EnterFrame
    //     0xef6c44: stp             fp, lr, [SP, #-0x10]!
    //     0xef6c48: mov             fp, SP
    // 0xef6c4c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xef6c4c: ldur            w2, [x1, #0x17]
    // 0xef6c50: DecompressPointer r2
    //     0xef6c50: add             x2, x2, HEAP, lsl #32
    // 0xef6c54: cmp             w2, NULL
    // 0xef6c58: b.eq            #0xef6c84
    // 0xef6c5c: LoadField: r3 = r2->field_43
    //     0xef6c5c: ldur            x3, [x2, #0x43]
    // 0xef6c60: cbnz            x3, #0xef6c74
    // 0xef6c64: LoadField: r2 = r1->field_b
    //     0xef6c64: ldur            w2, [x1, #0xb]
    // 0xef6c68: DecompressPointer r2
    //     0xef6c68: add             x2, x2, HEAP, lsl #32
    // 0xef6c6c: cmp             w2, NULL
    // 0xef6c70: b.eq            #0xef6c88
    // 0xef6c74: r0 = Null
    //     0xef6c74: mov             x0, NULL
    // 0xef6c78: LeaveFrame
    //     0xef6c78: mov             SP, fp
    //     0xef6c7c: ldp             fp, lr, [SP], #0x10
    // 0xef6c80: ret
    //     0xef6c80: ret             
    // 0xef6c84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef6c84: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef6c88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef6c88: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateScrollController(/* No info */) {
    // ** addr: 0xef6c8c, size: 0xc0
    // 0xef6c8c: EnterFrame
    //     0xef6c8c: stp             fp, lr, [SP, #-0x10]!
    //     0xef6c90: mov             fp, SP
    // 0xef6c94: AllocStack(0x10)
    //     0xef6c94: sub             SP, SP, #0x10
    // 0xef6c98: SetupParameters(_TabBarState this /* r1 => r0, fp-0x8 */)
    //     0xef6c98: mov             x0, x1
    //     0xef6c9c: stur            x1, [fp, #-8]
    // 0xef6ca0: CheckStackOverflow
    //     0xef6ca0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef6ca4: cmp             SP, x16
    //     0xef6ca8: b.ls            #0xef6d40
    // 0xef6cac: LoadField: r1 = r0->field_b
    //     0xef6cac: ldur            w1, [x0, #0xb]
    // 0xef6cb0: DecompressPointer r1
    //     0xef6cb0: add             x1, x1, HEAP, lsl #32
    // 0xef6cb4: cmp             w1, NULL
    // 0xef6cb8: b.eq            #0xef6d48
    // 0xef6cbc: LoadField: r1 = r0->field_13
    //     0xef6cbc: ldur            w1, [x0, #0x13]
    // 0xef6cc0: DecompressPointer r1
    //     0xef6cc0: add             x1, x1, HEAP, lsl #32
    // 0xef6cc4: cmp             w1, NULL
    // 0xef6cc8: b.ne            #0xef6d0c
    // 0xef6ccc: r0 = TabBarScrollController()
    //     0xef6ccc: bl              #0xef6d4c  ; AllocateTabBarScrollControllerStub -> TabBarScrollController (size=0x44)
    // 0xef6cd0: mov             x1, x0
    // 0xef6cd4: stur            x0, [fp, #-0x10]
    // 0xef6cd8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xef6cd8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xef6cdc: r0 = ScrollController()
    //     0xef6cdc: bl              #0x86d884  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0xef6ce0: ldur            x0, [fp, #-0x10]
    // 0xef6ce4: ldur            x2, [fp, #-8]
    // 0xef6ce8: StoreField: r2->field_13 = r0
    //     0xef6ce8: stur            w0, [x2, #0x13]
    //     0xef6cec: ldurb           w16, [x2, #-1]
    //     0xef6cf0: ldurb           w17, [x0, #-1]
    //     0xef6cf4: and             x16, x17, x16, lsr #2
    //     0xef6cf8: tst             x16, HEAP, lsr #32
    //     0xef6cfc: b.eq            #0xef6d04
    //     0xef6d00: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xef6d04: ldur            x1, [fp, #-0x10]
    // 0xef6d08: b               #0xef6d10
    // 0xef6d0c: mov             x2, x0
    // 0xef6d10: mov             x0, x2
    // 0xef6d14: StoreField: r1->field_3f = r0
    //     0xef6d14: stur            w0, [x1, #0x3f]
    //     0xef6d18: ldurb           w16, [x1, #-1]
    //     0xef6d1c: ldurb           w17, [x0, #-1]
    //     0xef6d20: and             x16, x17, x16, lsr #2
    //     0xef6d24: tst             x16, HEAP, lsr #32
    //     0xef6d28: b.eq            #0xef6d30
    //     0xef6d2c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef6d30: r0 = Null
    //     0xef6d30: mov             x0, NULL
    // 0xef6d34: LeaveFrame
    //     0xef6d34: mov             SP, fp
    //     0xef6d38: ldp             fp, lr, [SP], #0x10
    // 0xef6d3c: ret
    //     0xef6d3c: ret             
    // 0xef6d40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef6d40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef6d44: b               #0xef6cac
    // 0xef6d48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef6d48: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf6edf4, size: 0x4b4
    // 0xf6edf4: EnterFrame
    //     0xf6edf4: stp             fp, lr, [SP, #-0x10]!
    //     0xf6edf8: mov             fp, SP
    // 0xf6edfc: AllocStack(0x48)
    //     0xf6edfc: sub             SP, SP, #0x48
    // 0xf6ee00: SetupParameters(_TabBarState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf6ee00: mov             x4, x1
    //     0xf6ee04: mov             x3, x2
    //     0xf6ee08: stur            x1, [fp, #-8]
    //     0xf6ee0c: stur            x2, [fp, #-0x10]
    // 0xf6ee10: CheckStackOverflow
    //     0xf6ee10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6ee14: cmp             SP, x16
    //     0xf6ee18: b.ls            #0xf6f250
    // 0xf6ee1c: mov             x0, x3
    // 0xf6ee20: r2 = Null
    //     0xf6ee20: mov             x2, NULL
    // 0xf6ee24: r1 = Null
    //     0xf6ee24: mov             x1, NULL
    // 0xf6ee28: r4 = 60
    //     0xf6ee28: mov             x4, #0x3c
    // 0xf6ee2c: branchIfSmi(r0, 0xf6ee38)
    //     0xf6ee2c: tbz             w0, #0, #0xf6ee38
    // 0xf6ee30: r4 = LoadClassIdInstr(r0)
    //     0xf6ee30: ldur            x4, [x0, #-1]
    //     0xf6ee34: ubfx            x4, x4, #0xc, #0x14
    // 0xf6ee38: r17 = 6416
    //     0xf6ee38: mov             x17, #0x1910
    // 0xf6ee3c: cmp             x4, x17
    // 0xf6ee40: b.eq            #0xf6ee58
    // 0xf6ee44: r8 = TabBar
    //     0xf6ee44: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8c698] Type: TabBar
    //     0xf6ee48: ldr             x8, [x8, #0x698]
    // 0xf6ee4c: r3 = Null
    //     0xf6ee4c: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c6a0] Null
    //     0xf6ee50: ldr             x3, [x3, #0x6a0]
    // 0xf6ee54: r0 = TabBar()
    //     0xf6ee54: bl              #0x8d1620  ; IsType_TabBar_Stub
    // 0xf6ee58: ldur            x3, [fp, #-8]
    // 0xf6ee5c: LoadField: r2 = r3->field_7
    //     0xf6ee5c: ldur            w2, [x3, #7]
    // 0xf6ee60: DecompressPointer r2
    //     0xf6ee60: add             x2, x2, HEAP, lsl #32
    // 0xf6ee64: ldur            x0, [fp, #-0x10]
    // 0xf6ee68: r1 = Null
    //     0xf6ee68: mov             x1, NULL
    // 0xf6ee6c: cmp             w2, NULL
    // 0xf6ee70: b.eq            #0xf6ee94
    // 0xf6ee74: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6ee74: ldur            w4, [x2, #0x17]
    // 0xf6ee78: DecompressPointer r4
    //     0xf6ee78: add             x4, x4, HEAP, lsl #32
    // 0xf6ee7c: r8 = X0 bound StatefulWidget
    //     0xf6ee7c: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf6ee80: ldr             x8, [x8, #0x498]
    // 0xf6ee84: LoadField: r9 = r4->field_7
    //     0xf6ee84: ldur            x9, [x4, #7]
    // 0xf6ee88: r3 = Null
    //     0xf6ee88: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c6b0] Null
    //     0xf6ee8c: ldr             x3, [x3, #0x6b0]
    // 0xf6ee90: blr             x9
    // 0xf6ee94: ldur            x0, [fp, #-8]
    // 0xf6ee98: LoadField: r1 = r0->field_b
    //     0xf6ee98: ldur            w1, [x0, #0xb]
    // 0xf6ee9c: DecompressPointer r1
    //     0xf6ee9c: add             x1, x1, HEAP, lsl #32
    // 0xf6eea0: cmp             w1, NULL
    // 0xf6eea4: b.eq            #0xf6f258
    // 0xf6eea8: LoadField: r2 = r1->field_f
    //     0xf6eea8: ldur            w2, [x1, #0xf]
    // 0xf6eeac: DecompressPointer r2
    //     0xf6eeac: add             x2, x2, HEAP, lsl #32
    // 0xf6eeb0: ldur            x3, [fp, #-0x10]
    // 0xf6eeb4: LoadField: r4 = r3->field_f
    //     0xf6eeb4: ldur            w4, [x3, #0xf]
    // 0xf6eeb8: DecompressPointer r4
    //     0xf6eeb8: add             x4, x4, HEAP, lsl #32
    // 0xf6eebc: cmp             w2, w4
    // 0xf6eec0: b.eq            #0xf6ef34
    // 0xf6eec4: mov             x1, x0
    // 0xf6eec8: r0 = _updateScrollController()
    //     0xf6eec8: bl              #0xef6c8c  ; [package:flutter/src/material/tabs.dart] _TabBarState::_updateScrollController
    // 0xf6eecc: ldur            x1, [fp, #-8]
    // 0xf6eed0: r0 = _updateTabController()
    //     0xf6eed0: bl              #0xef6840  ; [package:flutter/src/material/tabs.dart] _TabBarState::_updateTabController
    // 0xf6eed4: ldur            x1, [fp, #-8]
    // 0xf6eed8: r0 = _initIndicatorPainter()
    //     0xf6eed8: bl              #0xef5a20  ; [package:flutter/src/material/tabs.dart] _TabBarState::_initIndicatorPainter
    // 0xf6eedc: ldur            x1, [fp, #-8]
    // 0xf6eee0: r0 = _effectiveScrollController()
    //     0xf6eee0: bl              #0xf6f2b8  ; [package:flutter/src/material/tabs.dart] _TabBarState::_effectiveScrollController
    // 0xf6eee4: LoadField: r1 = r0->field_3b
    //     0xf6eee4: ldur            w1, [x0, #0x3b]
    // 0xf6eee8: DecompressPointer r1
    //     0xf6eee8: add             x1, x1, HEAP, lsl #32
    // 0xf6eeec: LoadField: r0 = r1->field_b
    //     0xf6eeec: ldur            w0, [x1, #0xb]
    // 0xf6eef0: cbz             w0, #0xf6ef2c
    // 0xf6eef4: ldur            x1, [fp, #-8]
    // 0xf6eef8: r0 = _effectiveScrollController()
    //     0xf6eef8: bl              #0xf6f2b8  ; [package:flutter/src/material/tabs.dart] _TabBarState::_effectiveScrollController
    // 0xf6eefc: LoadField: r1 = r0->field_3b
    //     0xf6eefc: ldur            w1, [x0, #0x3b]
    // 0xf6ef00: DecompressPointer r1
    //     0xf6ef00: add             x1, x1, HEAP, lsl #32
    // 0xf6ef04: r0 = single()
    //     0xf6ef04: bl              #0xb3aa28  ; [dart:core] _GrowableList::single
    // 0xf6ef08: r1 = 60
    //     0xf6ef08: mov             x1, #0x3c
    // 0xf6ef0c: branchIfSmi(r0, 0xf6ef18)
    //     0xf6ef0c: tbz             w0, #0, #0xf6ef18
    // 0xf6ef10: r1 = LoadClassIdInstr(r0)
    //     0xf6ef10: ldur            x1, [x0, #-1]
    //     0xf6ef14: ubfx            x1, x1, #0xc, #0x14
    // 0xf6ef18: r17 = 4543
    //     0xf6ef18: mov             x17, #0x11bf
    // 0xf6ef1c: cmp             x1, x17
    // 0xf6ef20: b.ne            #0xf6ef2c
    // 0xf6ef24: mov             x1, x0
    // 0xf6ef28: r0 = markNeedsPixelsCorrection()
    //     0xf6ef28: bl              #0xf6f2a8  ; [package:flutter/src/material/tabs.dart] _TabBarScrollPosition::markNeedsPixelsCorrection
    // 0xf6ef2c: ldur            x0, [fp, #-8]
    // 0xf6ef30: b               #0xf6f064
    // 0xf6ef34: LoadField: r0 = r1->field_1f
    //     0xf6ef34: ldur            w0, [x1, #0x1f]
    // 0xf6ef38: DecompressPointer r0
    //     0xf6ef38: add             x0, x0, HEAP, lsl #32
    // 0xf6ef3c: LoadField: r1 = r3->field_1f
    //     0xf6ef3c: ldur            w1, [x3, #0x1f]
    // 0xf6ef40: DecompressPointer r1
    //     0xf6ef40: add             x1, x1, HEAP, lsl #32
    // 0xf6ef44: r2 = LoadClassIdInstr(r0)
    //     0xf6ef44: ldur            x2, [x0, #-1]
    //     0xf6ef48: ubfx            x2, x2, #0xc, #0x14
    // 0xf6ef4c: stp             x1, x0, [SP]
    // 0xf6ef50: mov             x0, x2
    // 0xf6ef54: mov             lr, x0
    // 0xf6ef58: ldr             lr, [x21, lr, lsl #3]
    // 0xf6ef5c: blr             lr
    // 0xf6ef60: tbnz            w0, #4, #0xf6f040
    // 0xf6ef64: ldur            x1, [fp, #-8]
    // 0xf6ef68: d0 = 2.000000
    //     0xf6ef68: fmov            d0, #2.00000000
    // 0xf6ef6c: LoadField: r0 = r1->field_b
    //     0xf6ef6c: ldur            w0, [x1, #0xb]
    // 0xf6ef70: DecompressPointer r0
    //     0xf6ef70: add             x0, x0, HEAP, lsl #32
    // 0xf6ef74: cmp             w0, NULL
    // 0xf6ef78: b.eq            #0xf6f25c
    // 0xf6ef7c: fcmp            d0, d0
    // 0xf6ef80: b.ne            #0xf6f040
    // 0xf6ef84: ldur            x2, [fp, #-0x10]
    // 0xf6ef88: LoadField: r3 = r0->field_37
    //     0xf6ef88: ldur            w3, [x0, #0x37]
    // 0xf6ef8c: DecompressPointer r3
    //     0xf6ef8c: add             x3, x3, HEAP, lsl #32
    // 0xf6ef90: LoadField: r0 = r2->field_37
    //     0xf6ef90: ldur            w0, [x2, #0x37]
    // 0xf6ef94: DecompressPointer r0
    //     0xf6ef94: add             x0, x0, HEAP, lsl #32
    // 0xf6ef98: cmp             w3, w0
    // 0xf6ef9c: b.ne            #0xf6f040
    // 0xf6efa0: r16 = Instance_EdgeInsets
    //     0xf6efa0: ldr             x16, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xf6efa4: r30 = Instance_EdgeInsets
    //     0xf6efa4: ldr             lr, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xf6efa8: stp             lr, x16, [SP]
    // 0xf6efac: r0 = ==()
    //     0xf6efac: bl              #0x1298c8c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::==
    // 0xf6efb0: tbnz            w0, #4, #0xf6f040
    // 0xf6efb4: ldur            x1, [fp, #-8]
    // 0xf6efb8: ldur            x2, [fp, #-0x10]
    // 0xf6efbc: LoadField: r0 = r1->field_b
    //     0xf6efbc: ldur            w0, [x1, #0xb]
    // 0xf6efc0: DecompressPointer r0
    //     0xf6efc0: add             x0, x0, HEAP, lsl #32
    // 0xf6efc4: cmp             w0, NULL
    // 0xf6efc8: b.eq            #0xf6f260
    // 0xf6efcc: LoadField: r3 = r0->field_2f
    //     0xf6efcc: ldur            w3, [x0, #0x2f]
    // 0xf6efd0: DecompressPointer r3
    //     0xf6efd0: add             x3, x3, HEAP, lsl #32
    // 0xf6efd4: LoadField: r0 = r2->field_2f
    //     0xf6efd4: ldur            w0, [x2, #0x2f]
    // 0xf6efd8: DecompressPointer r0
    //     0xf6efd8: add             x0, x0, HEAP, lsl #32
    // 0xf6efdc: r4 = LoadClassIdInstr(r3)
    //     0xf6efdc: ldur            x4, [x3, #-1]
    //     0xf6efe0: ubfx            x4, x4, #0xc, #0x14
    // 0xf6efe4: stp             x0, x3, [SP]
    // 0xf6efe8: mov             x0, x4
    // 0xf6efec: mov             lr, x0
    // 0xf6eff0: ldr             lr, [x21, lr, lsl #3]
    // 0xf6eff4: blr             lr
    // 0xf6eff8: tbnz            w0, #4, #0xf6f040
    // 0xf6effc: ldur            x1, [fp, #-8]
    // 0xf6f000: ldur            x0, [fp, #-0x10]
    // 0xf6f004: LoadField: r2 = r1->field_b
    //     0xf6f004: ldur            w2, [x1, #0xb]
    // 0xf6f008: DecompressPointer r2
    //     0xf6f008: add             x2, x2, HEAP, lsl #32
    // 0xf6f00c: cmp             w2, NULL
    // 0xf6f010: b.eq            #0xf6f264
    // 0xf6f014: LoadField: r3 = r2->field_3b
    //     0xf6f014: ldur            w3, [x2, #0x3b]
    // 0xf6f018: DecompressPointer r3
    //     0xf6f018: add             x3, x3, HEAP, lsl #32
    // 0xf6f01c: LoadField: r2 = r0->field_3b
    //     0xf6f01c: ldur            w2, [x0, #0x3b]
    // 0xf6f020: DecompressPointer r2
    //     0xf6f020: add             x2, x2, HEAP, lsl #32
    // 0xf6f024: r0 = LoadClassIdInstr(r3)
    //     0xf6f024: ldur            x0, [x3, #-1]
    //     0xf6f028: ubfx            x0, x0, #0xc, #0x14
    // 0xf6f02c: stp             x2, x3, [SP]
    // 0xf6f030: mov             lr, x0
    // 0xf6f034: ldr             lr, [x21, lr, lsl #3]
    // 0xf6f038: blr             lr
    // 0xf6f03c: tbz             w0, #4, #0xf6f050
    // 0xf6f040: ldur            x1, [fp, #-8]
    // 0xf6f044: r0 = _initIndicatorPainter()
    //     0xf6f044: bl              #0xef5a20  ; [package:flutter/src/material/tabs.dart] _TabBarState::_initIndicatorPainter
    // 0xf6f048: ldur            x0, [fp, #-8]
    // 0xf6f04c: b               #0xf6f064
    // 0xf6f050: ldur            x0, [fp, #-8]
    // 0xf6f054: LoadField: r1 = r0->field_b
    //     0xf6f054: ldur            w1, [x0, #0xb]
    // 0xf6f058: DecompressPointer r1
    //     0xf6f058: add             x1, x1, HEAP, lsl #32
    // 0xf6f05c: cmp             w1, NULL
    // 0xf6f060: b.eq            #0xf6f268
    // 0xf6f064: LoadField: r1 = r0->field_b
    //     0xf6f064: ldur            w1, [x0, #0xb]
    // 0xf6f068: DecompressPointer r1
    //     0xf6f068: add             x1, x1, HEAP, lsl #32
    // 0xf6f06c: cmp             w1, NULL
    // 0xf6f070: b.eq            #0xf6f26c
    // 0xf6f074: LoadField: r2 = r1->field_b
    //     0xf6f074: ldur            w2, [x1, #0xb]
    // 0xf6f078: DecompressPointer r2
    //     0xf6f078: add             x2, x2, HEAP, lsl #32
    // 0xf6f07c: LoadField: r1 = r2->field_b
    //     0xf6f07c: ldur            w1, [x2, #0xb]
    // 0xf6f080: LoadField: r3 = r0->field_23
    //     0xf6f080: ldur            w3, [x0, #0x23]
    // 0xf6f084: DecompressPointer r3
    //     0xf6f084: add             x3, x3, HEAP, lsl #32
    // 0xf6f088: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf6f08c: cmp             w3, w16
    // 0xf6f090: b.eq            #0xf6f270
    // 0xf6f094: stur            x3, [fp, #-0x10]
    // 0xf6f098: LoadField: r2 = r3->field_b
    //     0xf6f098: ldur            w2, [x3, #0xb]
    // 0xf6f09c: r4 = LoadInt32Instr(r1)
    //     0xf6f09c: sbfx            x4, x1, #1, #0x1f
    // 0xf6f0a0: r1 = LoadInt32Instr(r2)
    //     0xf6f0a0: sbfx            x1, x2, #1, #0x1f
    // 0xf6f0a4: cmp             x4, x1
    // 0xf6f0a8: b.le            #0xf6f1d0
    // 0xf6f0ac: sub             x5, x4, x1
    // 0xf6f0b0: mov             x2, x5
    // 0xf6f0b4: stur            x5, [fp, #-0x18]
    // 0xf6f0b8: r1 = <GlobalKey<State<StatefulWidget>>>
    //     0xf6f0b8: add             x1, PP, #0x8a, lsl #12  ; [pp+0x8ad68] TypeArguments: <GlobalKey<State<StatefulWidget>>>
    //     0xf6f0bc: ldr             x1, [x1, #0xd68]
    // 0xf6f0c0: r0 = _GrowableList()
    //     0xf6f0c0: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xf6f0c4: stur            x0, [fp, #-0x38]
    // 0xf6f0c8: LoadField: r1 = r0->field_b
    //     0xf6f0c8: ldur            w1, [x0, #0xb]
    // 0xf6f0cc: r2 = LoadInt32Instr(r1)
    //     0xf6f0cc: sbfx            x2, x1, #1, #0x1f
    // 0xf6f0d0: stur            x2, [fp, #-0x30]
    // 0xf6f0d4: LoadField: r3 = r0->field_f
    //     0xf6f0d4: ldur            w3, [x0, #0xf]
    // 0xf6f0d8: DecompressPointer r3
    //     0xf6f0d8: add             x3, x3, HEAP, lsl #32
    // 0xf6f0dc: stur            x3, [fp, #-0x28]
    // 0xf6f0e0: r4 = 0
    //     0xf6f0e0: mov             x4, #0
    // 0xf6f0e4: stur            x4, [fp, #-0x20]
    // 0xf6f0e8: CheckStackOverflow
    //     0xf6f0e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6f0ec: cmp             SP, x16
    //     0xf6f0f0: b.ls            #0xf6f27c
    // 0xf6f0f4: cmp             x4, x2
    // 0xf6f0f8: b.ge            #0xf6f148
    // 0xf6f0fc: r1 = <State<StatefulWidget>>
    //     0xf6f0fc: ldr             x1, [PP, #0x4df8]  ; [pp+0x4df8] TypeArguments: <State<StatefulWidget>>
    // 0xf6f100: r0 = LabeledGlobalKey()
    //     0xf6f100: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xf6f104: ldur            x1, [fp, #-0x28]
    // 0xf6f108: ldur            x2, [fp, #-0x20]
    // 0xf6f10c: ArrayStore: r1[r2] = r0  ; List_4
    //     0xf6f10c: add             x25, x1, x2, lsl #2
    //     0xf6f110: add             x25, x25, #0xf
    //     0xf6f114: str             w0, [x25]
    //     0xf6f118: tbz             w0, #0, #0xf6f134
    //     0xf6f11c: ldurb           w16, [x1, #-1]
    //     0xf6f120: ldurb           w17, [x0, #-1]
    //     0xf6f124: and             x16, x17, x16, lsr #2
    //     0xf6f128: tst             x16, HEAP, lsr #32
    //     0xf6f12c: b.eq            #0xf6f134
    //     0xf6f130: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf6f134: add             x4, x2, #1
    // 0xf6f138: ldur            x0, [fp, #-0x38]
    // 0xf6f13c: ldur            x3, [fp, #-0x28]
    // 0xf6f140: ldur            x2, [fp, #-0x30]
    // 0xf6f144: b               #0xf6f0e4
    // 0xf6f148: ldur            x0, [fp, #-8]
    // 0xf6f14c: ldur            x3, [fp, #-0x18]
    // 0xf6f150: ldur            x1, [fp, #-0x10]
    // 0xf6f154: ldur            x2, [fp, #-0x38]
    // 0xf6f158: r0 = addAll()
    //     0xf6f158: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0xf6f15c: ldur            x0, [fp, #-8]
    // 0xf6f160: LoadField: r3 = r0->field_27
    //     0xf6f160: ldur            w3, [x0, #0x27]
    // 0xf6f164: DecompressPointer r3
    //     0xf6f164: add             x3, x3, HEAP, lsl #32
    // 0xf6f168: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf6f16c: cmp             w3, w16
    // 0xf6f170: b.eq            #0xf6f284
    // 0xf6f174: ldur            x0, [fp, #-0x18]
    // 0xf6f178: stur            x3, [fp, #-0x28]
    // 0xf6f17c: lsl             x2, x0, #1
    // 0xf6f180: r1 = <EdgeInsetsGeometry>
    //     0xf6f180: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a98] TypeArguments: <EdgeInsetsGeometry>
    //     0xf6f184: ldr             x1, [x1, #0xa98]
    // 0xf6f188: r0 = AllocateArray()
    //     0xf6f188: bl              #0x13df928  ; AllocateArrayStub
    // 0xf6f18c: ldur            x1, [fp, #-0x18]
    // 0xf6f190: r2 = 0
    //     0xf6f190: mov             x2, #0
    // 0xf6f194: CheckStackOverflow
    //     0xf6f194: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6f198: cmp             SP, x16
    //     0xf6f19c: b.ls            #0xf6f290
    // 0xf6f1a0: cmp             x2, x1
    // 0xf6f1a4: b.ge            #0xf6f1c0
    // 0xf6f1a8: add             x3, x0, x2, lsl #2
    // 0xf6f1ac: r16 = Instance_EdgeInsets
    //     0xf6f1ac: ldr             x16, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xf6f1b0: StoreField: r3->field_f = r16
    //     0xf6f1b0: stur            w16, [x3, #0xf]
    // 0xf6f1b4: add             x3, x2, #1
    // 0xf6f1b8: mov             x2, x3
    // 0xf6f1bc: b               #0xf6f194
    // 0xf6f1c0: ldur            x1, [fp, #-0x28]
    // 0xf6f1c4: mov             x2, x0
    // 0xf6f1c8: r0 = addAll()
    //     0xf6f1c8: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0xf6f1cc: b               #0xf6f240
    // 0xf6f1d0: cmp             x4, x1
    // 0xf6f1d4: b.ge            #0xf6f240
    // 0xf6f1d8: mov             x3, x1
    // 0xf6f1dc: ldur            x1, [fp, #-0x10]
    // 0xf6f1e0: mov             x2, x4
    // 0xf6f1e4: r0 = removeRange()
    //     0xf6f1e4: bl              #0x9f1f4c  ; [dart:core] _GrowableList::removeRange
    // 0xf6f1e8: ldur            x0, [fp, #-8]
    // 0xf6f1ec: LoadField: r1 = r0->field_27
    //     0xf6f1ec: ldur            w1, [x0, #0x27]
    // 0xf6f1f0: DecompressPointer r1
    //     0xf6f1f0: add             x1, x1, HEAP, lsl #32
    // 0xf6f1f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf6f1f8: cmp             w1, w16
    // 0xf6f1fc: b.eq            #0xf6f298
    // 0xf6f200: LoadField: r2 = r0->field_b
    //     0xf6f200: ldur            w2, [x0, #0xb]
    // 0xf6f204: DecompressPointer r2
    //     0xf6f204: add             x2, x2, HEAP, lsl #32
    // 0xf6f208: cmp             w2, NULL
    // 0xf6f20c: b.eq            #0xf6f2a4
    // 0xf6f210: LoadField: r3 = r2->field_b
    //     0xf6f210: ldur            w3, [x2, #0xb]
    // 0xf6f214: DecompressPointer r3
    //     0xf6f214: add             x3, x3, HEAP, lsl #32
    // 0xf6f218: LoadField: r2 = r3->field_b
    //     0xf6f218: ldur            w2, [x3, #0xb]
    // 0xf6f21c: LoadField: r3 = r0->field_23
    //     0xf6f21c: ldur            w3, [x0, #0x23]
    // 0xf6f220: DecompressPointer r3
    //     0xf6f220: add             x3, x3, HEAP, lsl #32
    // 0xf6f224: LoadField: r0 = r3->field_b
    //     0xf6f224: ldur            w0, [x3, #0xb]
    // 0xf6f228: r3 = LoadInt32Instr(r2)
    //     0xf6f228: sbfx            x3, x2, #1, #0x1f
    // 0xf6f22c: r2 = LoadInt32Instr(r0)
    //     0xf6f22c: sbfx            x2, x0, #1, #0x1f
    // 0xf6f230: mov             x16, x2
    // 0xf6f234: mov             x2, x3
    // 0xf6f238: mov             x3, x16
    // 0xf6f23c: r0 = removeRange()
    //     0xf6f23c: bl              #0x9f1f4c  ; [dart:core] _GrowableList::removeRange
    // 0xf6f240: r0 = Null
    //     0xf6f240: mov             x0, NULL
    // 0xf6f244: LeaveFrame
    //     0xf6f244: mov             SP, fp
    //     0xf6f248: ldp             fp, lr, [SP], #0x10
    // 0xf6f24c: ret
    //     0xf6f24c: ret             
    // 0xf6f250: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6f250: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6f254: b               #0xf6ee1c
    // 0xf6f258: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6f258: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6f25c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xf6f25c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xf6f260: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6f260: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6f264: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6f264: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6f268: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6f268: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6f26c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6f26c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6f270: r9 = _tabKeys
    //     0xf6f270: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8c650] Field <_TabBarState@780014024._tabKeys@780014024>: late (offset: 0x24)
    //     0xf6f274: ldr             x9, [x9, #0x650]
    // 0xf6f278: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf6f278: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf6f27c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6f27c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6f280: b               #0xf6f0f4
    // 0xf6f284: r9 = _labelPaddings
    //     0xf6f284: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8c648] Field <_TabBarState@780014024._labelPaddings@780014024>: late (offset: 0x28)
    //     0xf6f288: ldr             x9, [x9, #0x648]
    // 0xf6f28c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf6f28c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf6f290: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6f290: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6f294: b               #0xf6f1a0
    // 0xf6f298: r9 = _labelPaddings
    //     0xf6f298: add             x9, PP, #0x8c, lsl #12  ; [pp+0x8c648] Field <_TabBarState@780014024._labelPaddings@780014024>: late (offset: 0x28)
    //     0xf6f29c: ldr             x9, [x9, #0x648]
    // 0xf6f2a0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf6f2a0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf6f2a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6f2a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _effectiveScrollController(/* No info */) {
    // ** addr: 0xf6f2b8, size: 0x90
    // 0xf6f2b8: EnterFrame
    //     0xf6f2b8: stp             fp, lr, [SP, #-0x10]!
    //     0xf6f2bc: mov             fp, SP
    // 0xf6f2c0: AllocStack(0x10)
    //     0xf6f2c0: sub             SP, SP, #0x10
    // 0xf6f2c4: SetupParameters(_TabBarState this /* r1 => r1, fp-0x8 */)
    //     0xf6f2c4: stur            x1, [fp, #-8]
    // 0xf6f2c8: CheckStackOverflow
    //     0xf6f2c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6f2cc: cmp             SP, x16
    //     0xf6f2d0: b.ls            #0xf6f33c
    // 0xf6f2d4: LoadField: r0 = r1->field_b
    //     0xf6f2d4: ldur            w0, [x1, #0xb]
    // 0xf6f2d8: DecompressPointer r0
    //     0xf6f2d8: add             x0, x0, HEAP, lsl #32
    // 0xf6f2dc: cmp             w0, NULL
    // 0xf6f2e0: b.eq            #0xf6f344
    // 0xf6f2e4: LoadField: r0 = r1->field_13
    //     0xf6f2e4: ldur            w0, [x1, #0x13]
    // 0xf6f2e8: DecompressPointer r0
    //     0xf6f2e8: add             x0, x0, HEAP, lsl #32
    // 0xf6f2ec: cmp             w0, NULL
    // 0xf6f2f0: b.ne            #0xf6f330
    // 0xf6f2f4: r0 = TabBarScrollController()
    //     0xf6f2f4: bl              #0xef6d4c  ; AllocateTabBarScrollControllerStub -> TabBarScrollController (size=0x44)
    // 0xf6f2f8: mov             x1, x0
    // 0xf6f2fc: stur            x0, [fp, #-0x10]
    // 0xf6f300: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf6f300: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf6f304: r0 = ScrollController()
    //     0xf6f304: bl              #0x86d884  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0xf6f308: ldur            x0, [fp, #-0x10]
    // 0xf6f30c: ldur            x1, [fp, #-8]
    // 0xf6f310: StoreField: r1->field_13 = r0
    //     0xf6f310: stur            w0, [x1, #0x13]
    //     0xf6f314: ldurb           w16, [x1, #-1]
    //     0xf6f318: ldurb           w17, [x0, #-1]
    //     0xf6f31c: and             x16, x17, x16, lsr #2
    //     0xf6f320: tst             x16, HEAP, lsr #32
    //     0xf6f324: b.eq            #0xf6f32c
    //     0xf6f328: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf6f32c: ldur            x0, [fp, #-0x10]
    // 0xf6f330: LeaveFrame
    //     0xf6f330: mov             SP, fp
    //     0xf6f334: ldp             fp, lr, [SP], #0x10
    // 0xf6f338: ret
    //     0xf6f338: ret             
    // 0xf6f33c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6f33c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6f340: b               #0xf6f2d4
    // 0xf6f344: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6f344: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf91428, size: 0x1e0
    // 0xf91428: EnterFrame
    //     0xf91428: stp             fp, lr, [SP, #-0x10]!
    //     0xf9142c: mov             fp, SP
    // 0xf91430: AllocStack(0x30)
    //     0xf91430: sub             SP, SP, #0x30
    // 0xf91434: SetupParameters(_TabBarState this /* r1 => r0, fp-0x10 */)
    //     0xf91434: mov             x0, x1
    //     0xf91438: stur            x1, [fp, #-0x10]
    // 0xf9143c: CheckStackOverflow
    //     0xf9143c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf91440: cmp             SP, x16
    //     0xf91444: b.ls            #0xf915f8
    // 0xf91448: LoadField: r1 = r0->field_b
    //     0xf91448: ldur            w1, [x0, #0xb]
    // 0xf9144c: DecompressPointer r1
    //     0xf9144c: add             x1, x1, HEAP, lsl #32
    // 0xf91450: cmp             w1, NULL
    // 0xf91454: b.eq            #0xf91600
    // 0xf91458: LoadField: r3 = r1->field_b
    //     0xf91458: ldur            w3, [x1, #0xb]
    // 0xf9145c: DecompressPointer r3
    //     0xf9145c: add             x3, x3, HEAP, lsl #32
    // 0xf91460: stur            x3, [fp, #-8]
    // 0xf91464: r1 = Function '<anonymous closure>':.
    //     0xf91464: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c730] AnonymousClosure: (0x8d1604), in [package:flutter/src/material/tabs.dart] _TabBarState::initState (0xf91428)
    //     0xf91468: ldr             x1, [x1, #0x730]
    // 0xf9146c: r2 = Null
    //     0xf9146c: mov             x2, NULL
    // 0xf91470: r0 = AllocateClosure()
    //     0xf91470: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf91474: r16 = <GlobalKey<State<StatefulWidget>>>
    //     0xf91474: add             x16, PP, #0x8a, lsl #12  ; [pp+0x8ad68] TypeArguments: <GlobalKey<State<StatefulWidget>>>
    //     0xf91478: ldr             x16, [x16, #0xd68]
    // 0xf9147c: ldur            lr, [fp, #-8]
    // 0xf91480: stp             lr, x16, [SP, #8]
    // 0xf91484: str             x0, [SP]
    // 0xf91488: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xf91488: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xf9148c: r0 = map()
    //     0xf9148c: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0xf91490: mov             x3, x0
    // 0xf91494: stur            x3, [fp, #-0x18]
    // 0xf91498: LoadField: r4 = r3->field_7
    //     0xf91498: ldur            w4, [x3, #7]
    // 0xf9149c: DecompressPointer r4
    //     0xf9149c: add             x4, x4, HEAP, lsl #32
    // 0xf914a0: mov             x0, x3
    // 0xf914a4: stur            x4, [fp, #-8]
    // 0xf914a8: r2 = Null
    //     0xf914a8: mov             x2, NULL
    // 0xf914ac: r1 = Null
    //     0xf914ac: mov             x1, NULL
    // 0xf914b0: cmp             w0, NULL
    // 0xf914b4: b.eq            #0xf9154c
    // 0xf914b8: branchIfSmi(r0, 0xf9154c)
    //     0xf914b8: tbz             w0, #0, #0xf9154c
    // 0xf914bc: r3 = LoadClassIdInstr(r0)
    //     0xf914bc: ldur            x3, [x0, #-1]
    //     0xf914c0: ubfx            x3, x3, #0xc, #0x14
    // 0xf914c4: r17 = 7724
    //     0xf914c4: mov             x17, #0x1e2c
    // 0xf914c8: cmp             x3, x17
    // 0xf914cc: b.eq            #0xf91554
    // 0xf914d0: r4 = LoadClassIdInstr(r0)
    //     0xf914d0: ldur            x4, [x0, #-1]
    //     0xf914d4: ubfx            x4, x4, #0xc, #0x14
    // 0xf914d8: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0xf914dc: ldr             x3, [x3, #0x18]
    // 0xf914e0: ldr             x3, [x3, x4, lsl #3]
    // 0xf914e4: LoadField: r3 = r3->field_2b
    //     0xf914e4: ldur            w3, [x3, #0x2b]
    // 0xf914e8: DecompressPointer r3
    //     0xf914e8: add             x3, x3, HEAP, lsl #32
    // 0xf914ec: cmp             w3, NULL
    // 0xf914f0: b.eq            #0xf9154c
    // 0xf914f4: LoadField: r3 = r3->field_f
    //     0xf914f4: ldur            w3, [x3, #0xf]
    // 0xf914f8: lsr             x3, x3, #3
    // 0xf914fc: r17 = 7724
    //     0xf914fc: mov             x17, #0x1e2c
    // 0xf91500: cmp             x3, x17
    // 0xf91504: b.eq            #0xf91554
    // 0xf91508: r3 = SubtypeTestCache
    //     0xf91508: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c738] SubtypeTestCache
    //     0xf9150c: ldr             x3, [x3, #0x738]
    // 0xf91510: r30 = Subtype1TestCacheStub
    //     0xf91510: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0xf91514: LoadField: r30 = r30->field_7
    //     0xf91514: ldur            lr, [lr, #7]
    // 0xf91518: blr             lr
    // 0xf9151c: cmp             w7, NULL
    // 0xf91520: b.eq            #0xf9152c
    // 0xf91524: tbnz            w7, #4, #0xf9154c
    // 0xf91528: b               #0xf91554
    // 0xf9152c: r8 = EfficientLengthIterable
    //     0xf9152c: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8c740] Type: EfficientLengthIterable
    //     0xf91530: ldr             x8, [x8, #0x740]
    // 0xf91534: r3 = SubtypeTestCache
    //     0xf91534: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c748] SubtypeTestCache
    //     0xf91538: ldr             x3, [x3, #0x748]
    // 0xf9153c: r30 = InstanceOfStub
    //     0xf9153c: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xf91540: LoadField: r30 = r30->field_7
    //     0xf91540: ldur            lr, [lr, #7]
    // 0xf91544: blr             lr
    // 0xf91548: b               #0xf91558
    // 0xf9154c: r0 = false
    //     0xf9154c: add             x0, NULL, #0x30  ; false
    // 0xf91550: b               #0xf91558
    // 0xf91554: r0 = true
    //     0xf91554: add             x0, NULL, #0x20  ; true
    // 0xf91558: tbnz            w0, #4, #0xf9156c
    // 0xf9155c: ldur            x1, [fp, #-8]
    // 0xf91560: ldur            x2, [fp, #-0x18]
    // 0xf91564: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0xf91564: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0xf91568: b               #0xf91578
    // 0xf9156c: ldur            x1, [fp, #-8]
    // 0xf91570: ldur            x2, [fp, #-0x18]
    // 0xf91574: r0 = _GrowableList._ofOther()
    //     0xf91574: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0xf91578: ldur            x4, [fp, #-0x10]
    // 0xf9157c: StoreField: r4->field_23 = r0
    //     0xf9157c: stur            w0, [x4, #0x23]
    //     0xf91580: ldurb           w16, [x4, #-1]
    //     0xf91584: ldurb           w17, [x0, #-1]
    //     0xf91588: and             x16, x17, x16, lsr #2
    //     0xf9158c: tst             x16, HEAP, lsr #32
    //     0xf91590: b.eq            #0xf91598
    //     0xf91594: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xf91598: LoadField: r0 = r4->field_b
    //     0xf91598: ldur            w0, [x4, #0xb]
    // 0xf9159c: DecompressPointer r0
    //     0xf9159c: add             x0, x0, HEAP, lsl #32
    // 0xf915a0: cmp             w0, NULL
    // 0xf915a4: b.eq            #0xf91604
    // 0xf915a8: LoadField: r1 = r0->field_b
    //     0xf915a8: ldur            w1, [x0, #0xb]
    // 0xf915ac: DecompressPointer r1
    //     0xf915ac: add             x1, x1, HEAP, lsl #32
    // 0xf915b0: LoadField: r0 = r1->field_b
    //     0xf915b0: ldur            w0, [x1, #0xb]
    // 0xf915b4: r2 = LoadInt32Instr(r0)
    //     0xf915b4: sbfx            x2, x0, #1, #0x1f
    // 0xf915b8: r1 = <EdgeInsetsGeometry>
    //     0xf915b8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a98] TypeArguments: <EdgeInsetsGeometry>
    //     0xf915bc: ldr             x1, [x1, #0xa98]
    // 0xf915c0: r3 = Instance_EdgeInsets
    //     0xf915c0: ldr             x3, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xf915c4: r0 = _GrowableList.filled()
    //     0xf915c4: bl              #0xa23338  ; [dart:core] _GrowableList::_GrowableList.filled
    // 0xf915c8: ldur            x1, [fp, #-0x10]
    // 0xf915cc: StoreField: r1->field_27 = r0
    //     0xf915cc: stur            w0, [x1, #0x27]
    //     0xf915d0: ldurb           w16, [x1, #-1]
    //     0xf915d4: ldurb           w17, [x0, #-1]
    //     0xf915d8: and             x16, x17, x16, lsr #2
    //     0xf915dc: tst             x16, HEAP, lsr #32
    //     0xf915e0: b.eq            #0xf915e8
    //     0xf915e4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf915e8: r0 = Null
    //     0xf915e8: mov             x0, NULL
    // 0xf915ec: LeaveFrame
    //     0xf915ec: mov             SP, fp
    //     0xf915f0: ldp             fp, lr, [SP], #0x10
    // 0xf915f4: ret
    //     0xf915f4: ret             
    // 0xf915f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf915f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf915fc: b               #0xf91448
    // 0xf91600: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf91600: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf91604: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf91604: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e60e0, size: 0x130
    // 0x10e60e0: EnterFrame
    //     0x10e60e0: stp             fp, lr, [SP, #-0x10]!
    //     0x10e60e4: mov             fp, SP
    // 0x10e60e8: AllocStack(0x10)
    //     0x10e60e8: sub             SP, SP, #0x10
    // 0x10e60ec: SetupParameters(_TabBarState this /* r1 => r0, fp-0x8 */)
    //     0x10e60ec: mov             x0, x1
    //     0x10e60f0: stur            x1, [fp, #-8]
    // 0x10e60f4: CheckStackOverflow
    //     0x10e60f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e60f8: cmp             SP, x16
    //     0x10e60fc: b.ls            #0x10e61f4
    // 0x10e6100: LoadField: r1 = r0->field_1b
    //     0x10e6100: ldur            w1, [x0, #0x1b]
    // 0x10e6104: DecompressPointer r1
    //     0x10e6104: add             x1, x1, HEAP, lsl #32
    // 0x10e6108: cmp             w1, NULL
    // 0x10e610c: b.eq            #0x10e61fc
    // 0x10e6110: r0 = dispose()
    //     0x10e6110: bl              #0xef5e38  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::dispose
    // 0x10e6114: ldur            x1, [fp, #-8]
    // 0x10e6118: r0 = _controllerIsValid()
    //     0x10e6118: bl              #0xef6800  ; [package:flutter/src/material/tabs.dart] _TabBarState::_controllerIsValid
    // 0x10e611c: tbnz            w0, #4, #0x10e61ac
    // 0x10e6120: ldur            x0, [fp, #-8]
    // 0x10e6124: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10e6124: ldur            w1, [x0, #0x17]
    // 0x10e6128: DecompressPointer r1
    //     0x10e6128: add             x1, x1, HEAP, lsl #32
    // 0x10e612c: cmp             w1, NULL
    // 0x10e6130: b.eq            #0x10e6200
    // 0x10e6134: LoadField: r2 = r1->field_23
    //     0x10e6134: ldur            w2, [x1, #0x23]
    // 0x10e6138: DecompressPointer r2
    //     0x10e6138: add             x2, x2, HEAP, lsl #32
    // 0x10e613c: cmp             w2, NULL
    // 0x10e6140: b.ne            #0x10e614c
    // 0x10e6144: r3 = Null
    //     0x10e6144: mov             x3, NULL
    // 0x10e6148: b               #0x10e6150
    // 0x10e614c: mov             x3, x2
    // 0x10e6150: stur            x3, [fp, #-0x10]
    // 0x10e6154: cmp             w3, NULL
    // 0x10e6158: b.eq            #0x10e6204
    // 0x10e615c: mov             x2, x0
    // 0x10e6160: r1 = Function '_handleTabControllerAnimationTick@780014024':.
    //     0x10e6160: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c680] AnonymousClosure: (0xef6c0c), in [package:flutter/src/material/tabs.dart] _TabBarState::_handleTabControllerAnimationTick (0xef6c44)
    //     0x10e6164: ldr             x1, [x1, #0x680]
    // 0x10e6168: r0 = AllocateClosure()
    //     0x10e6168: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e616c: ldur            x1, [fp, #-0x10]
    // 0x10e6170: mov             x2, x0
    // 0x10e6174: r0 = removeListener()
    //     0x10e6174: bl              #0xd00c74  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::removeListener
    // 0x10e6178: ldur            x0, [fp, #-8]
    // 0x10e617c: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x10e617c: ldur            w3, [x0, #0x17]
    // 0x10e6180: DecompressPointer r3
    //     0x10e6180: add             x3, x3, HEAP, lsl #32
    // 0x10e6184: stur            x3, [fp, #-0x10]
    // 0x10e6188: cmp             w3, NULL
    // 0x10e618c: b.eq            #0x10e6208
    // 0x10e6190: mov             x2, x0
    // 0x10e6194: r1 = Function '_handleTabControllerTick@780014024':.
    //     0x10e6194: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c688] AnonymousClosure: (0xef6ad8), in [package:flutter/src/material/tabs.dart] _TabBarState::_handleTabControllerTick (0xef6b10)
    //     0x10e6198: ldr             x1, [x1, #0x688]
    // 0x10e619c: r0 = AllocateClosure()
    //     0x10e619c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e61a0: ldur            x1, [fp, #-0x10]
    // 0x10e61a4: mov             x2, x0
    // 0x10e61a8: r0 = removeListener()
    //     0x10e61a8: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x10e61ac: ldur            x0, [fp, #-8]
    // 0x10e61b0: ArrayStore: r0[0] = rNULL  ; List_4
    //     0x10e61b0: stur            NULL, [x0, #0x17]
    // 0x10e61b4: LoadField: r1 = r0->field_13
    //     0x10e61b4: ldur            w1, [x0, #0x13]
    // 0x10e61b8: DecompressPointer r1
    //     0x10e61b8: add             x1, x1, HEAP, lsl #32
    // 0x10e61bc: cmp             w1, NULL
    // 0x10e61c0: b.ne            #0x10e61cc
    // 0x10e61c4: mov             x1, x0
    // 0x10e61c8: b               #0x10e61d4
    // 0x10e61cc: r0 = dispose()
    //     0x10e61cc: bl              #0x10ef50c  ; [package:flutter/src/material/tabs.dart] TabBarScrollController::dispose
    // 0x10e61d0: ldur            x1, [fp, #-8]
    // 0x10e61d4: LoadField: r2 = r1->field_b
    //     0x10e61d4: ldur            w2, [x1, #0xb]
    // 0x10e61d8: DecompressPointer r2
    //     0x10e61d8: add             x2, x2, HEAP, lsl #32
    // 0x10e61dc: cmp             w2, NULL
    // 0x10e61e0: b.eq            #0x10e620c
    // 0x10e61e4: r0 = Null
    //     0x10e61e4: mov             x0, NULL
    // 0x10e61e8: LeaveFrame
    //     0x10e61e8: mov             SP, fp
    //     0x10e61ec: ldp             fp, lr, [SP], #0x10
    // 0x10e61f0: ret
    //     0x10e61f0: ret             
    // 0x10e61f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e61f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e61f8: b               #0x10e6100
    // 0x10e61fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e61fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10e6200: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e6200: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10e6204: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e6204: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10e6208: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e6208: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10e620c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e620c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _initialScrollOffset(/* No info */) {
    // ** addr: 0x1285950, size: 0x40
    // 0x1285950: EnterFrame
    //     0x1285950: stp             fp, lr, [SP, #-0x10]!
    //     0x1285954: mov             fp, SP
    // 0x1285958: LoadField: r0 = r1->field_1f
    //     0x1285958: ldur            w0, [x1, #0x1f]
    // 0x128595c: DecompressPointer r0
    //     0x128595c: add             x0, x0, HEAP, lsl #32
    // 0x1285960: cmp             w0, NULL
    // 0x1285964: b.eq            #0x1285988
    // 0x1285968: LoadField: r0 = r1->field_b
    //     0x1285968: ldur            w0, [x1, #0xb]
    // 0x128596c: DecompressPointer r0
    //     0x128596c: add             x0, x0, HEAP, lsl #32
    // 0x1285970: cmp             w0, NULL
    // 0x1285974: b.eq            #0x128598c
    // 0x1285978: d0 = 0.000000
    //     0x1285978: eor             v0.16b, v0.16b, v0.16b
    // 0x128597c: LeaveFrame
    //     0x128597c: mov             SP, fp
    //     0x1285980: ldp             fp, lr, [SP], #0x10
    // 0x1285984: ret
    //     0x1285984: ret             
    // 0x1285988: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1285988: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x128598c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x128598c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6141, size: 0x1c, field offset: 0xc
//   const constructor, 
class Tab extends StatelessWidget
    implements PreferredSizeWidget {

  _ build(/* No info */) {
    // ** addr: 0xfbe4f4, size: 0x74
    // 0xfbe4f4: EnterFrame
    //     0xfbe4f4: stp             fp, lr, [SP, #-0x10]!
    //     0xfbe4f8: mov             fp, SP
    // 0xfbe4fc: AllocStack(0x10)
    //     0xfbe4fc: sub             SP, SP, #0x10
    // 0xfbe500: CheckStackOverflow
    //     0xfbe500: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbe504: cmp             SP, x16
    //     0xfbe508: b.ls            #0xfbe560
    // 0xfbe50c: r0 = _buildLabelText()
    //     0xfbe50c: bl              #0xfbe58c  ; [package:flutter/src/material/tabs.dart] Tab::_buildLabelText
    // 0xfbe510: stur            x0, [fp, #-8]
    // 0xfbe514: r0 = Center()
    //     0xfbe514: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xfbe518: mov             x1, x0
    // 0xfbe51c: r0 = Instance_Alignment
    //     0xfbe51c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfbe520: ldr             x0, [x0, #0xb80]
    // 0xfbe524: stur            x1, [fp, #-0x10]
    // 0xfbe528: StoreField: r1->field_f = r0
    //     0xfbe528: stur            w0, [x1, #0xf]
    // 0xfbe52c: r0 = 1.000000
    //     0xfbe52c: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xfbe530: StoreField: r1->field_13 = r0
    //     0xfbe530: stur            w0, [x1, #0x13]
    // 0xfbe534: ldur            x0, [fp, #-8]
    // 0xfbe538: StoreField: r1->field_b = r0
    //     0xfbe538: stur            w0, [x1, #0xb]
    // 0xfbe53c: r0 = SizedBox()
    //     0xfbe53c: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xfbe540: r1 = 46.000000
    //     0xfbe540: add             x1, PP, #0x80, lsl #12  ; [pp+0x808f0] 46
    //     0xfbe544: ldr             x1, [x1, #0x8f0]
    // 0xfbe548: StoreField: r0->field_13 = r1
    //     0xfbe548: stur            w1, [x0, #0x13]
    // 0xfbe54c: ldur            x1, [fp, #-0x10]
    // 0xfbe550: StoreField: r0->field_b = r1
    //     0xfbe550: stur            w1, [x0, #0xb]
    // 0xfbe554: LeaveFrame
    //     0xfbe554: mov             SP, fp
    //     0xfbe558: ldp             fp, lr, [SP], #0x10
    // 0xfbe55c: ret
    //     0xfbe55c: ret             
    // 0xfbe560: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbe560: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbe564: b               #0xfbe50c
  }
  _ _buildLabelText(/* No info */) {
    // ** addr: 0xfbe58c, size: 0x60
    // 0xfbe58c: EnterFrame
    //     0xfbe58c: stp             fp, lr, [SP, #-0x10]!
    //     0xfbe590: mov             fp, SP
    // 0xfbe594: AllocStack(0x8)
    //     0xfbe594: sub             SP, SP, #8
    // 0xfbe598: LoadField: r0 = r1->field_f
    //     0xfbe598: ldur            w0, [x1, #0xf]
    // 0xfbe59c: DecompressPointer r0
    //     0xfbe59c: add             x0, x0, HEAP, lsl #32
    // 0xfbe5a0: cmp             w0, NULL
    // 0xfbe5a4: b.ne            #0xfbe5dc
    // 0xfbe5a8: LoadField: r0 = r1->field_b
    //     0xfbe5a8: ldur            w0, [x1, #0xb]
    // 0xfbe5ac: DecompressPointer r0
    //     0xfbe5ac: add             x0, x0, HEAP, lsl #32
    // 0xfbe5b0: stur            x0, [fp, #-8]
    // 0xfbe5b4: cmp             w0, NULL
    // 0xfbe5b8: b.eq            #0xfbe5e8
    // 0xfbe5bc: r0 = Text()
    //     0xfbe5bc: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xfbe5c0: ldur            x1, [fp, #-8]
    // 0xfbe5c4: StoreField: r0->field_b = r1
    //     0xfbe5c4: stur            w1, [x0, #0xb]
    // 0xfbe5c8: r1 = false
    //     0xfbe5c8: add             x1, NULL, #0x30  ; false
    // 0xfbe5cc: StoreField: r0->field_27 = r1
    //     0xfbe5cc: stur            w1, [x0, #0x27]
    // 0xfbe5d0: r1 = Instance_TextOverflow
    //     0xfbe5d0: add             x1, PP, #0x80, lsl #12  ; [pp+0x808f8] Obj!TextOverflow@12c47e1
    //     0xfbe5d4: ldr             x1, [x1, #0x8f8]
    // 0xfbe5d8: StoreField: r0->field_2b = r1
    //     0xfbe5d8: stur            w1, [x0, #0x2b]
    // 0xfbe5dc: LeaveFrame
    //     0xfbe5dc: mov             SP, fp
    //     0xfbe5e0: ldp             fp, lr, [SP], #0x10
    // 0xfbe5e4: ret
    //     0xfbe5e4: ret             
    // 0xfbe5e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbe5e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ preferredSize(/* No info */) {
    // ** addr: 0x1249310, size: 0x2c
    // 0x1249310: LoadField: r2 = r1->field_b
    //     0x1249310: ldur            w2, [x1, #0xb]
    // 0x1249314: DecompressPointer r2
    //     0x1249314: add             x2, x2, HEAP, lsl #32
    // 0x1249318: cmp             w2, NULL
    // 0x124931c: b.ne            #0x1249330
    // 0x1249320: LoadField: r2 = r1->field_f
    //     0x1249320: ldur            w2, [x1, #0xf]
    // 0x1249324: DecompressPointer r2
    //     0x1249324: add             x2, x2, HEAP, lsl #32
    // 0x1249328: cmp             w2, NULL
    // 0x124932c: b.ne            #0x1249330
    // 0x1249330: r0 = Instance_Size
    //     0x1249330: add             x0, PP, #0x80, lsl #12  ; [pp+0x808e8] Obj!Size@12a7a11
    //     0x1249334: ldr             x0, [x0, #0x8e8]
    // 0x1249338: ret
    //     0x1249338: ret             
  }
}

// class id: 6415, size: 0x28, field offset: 0xc
//   const constructor, 
class TabBarView extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa3254, size: 0x34
    // 0xfa3254: EnterFrame
    //     0xfa3254: stp             fp, lr, [SP, #-0x10]!
    //     0xfa3258: mov             fp, SP
    // 0xfa325c: mov             x0, x1
    // 0xfa3260: r1 = <TabBarView>
    //     0xfa3260: add             x1, PP, #0x80, lsl #12  ; [pp+0x808d0] TypeArguments: <TabBarView>
    //     0xfa3264: ldr             x1, [x1, #0x8d0]
    // 0xfa3268: r0 = _TabBarViewState()
    //     0xfa3268: bl              #0xfa3288  ; Allocate_TabBarViewStateStub -> _TabBarViewState (size=0x34)
    // 0xfa326c: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa3270: StoreField: r0->field_1b = r1
    //     0xfa3270: stur            w1, [x0, #0x1b]
    // 0xfa3274: StoreField: r0->field_23 = rZR
    //     0xfa3274: stur            xzr, [x0, #0x23]
    // 0xfa3278: StoreField: r0->field_2b = rZR
    //     0xfa3278: stur            xzr, [x0, #0x2b]
    // 0xfa327c: LeaveFrame
    //     0xfa327c: mov             SP, fp
    //     0xfa3280: ldp             fp, lr, [SP], #0x10
    // 0xfa3284: ret
    //     0xfa3284: ret             
  }
}

// class id: 6416, size: 0x88, field offset: 0xc
//   const constructor, 
class TabBar extends StatefulWidget
    implements PreferredSizeWidget {

  get _ tabHasTextAndIcon(/* No info */) {
    // ** addr: 0xe00c18, size: 0x1b4
    // 0xe00c18: EnterFrame
    //     0xe00c18: stp             fp, lr, [SP, #-0x10]!
    //     0xe00c1c: mov             fp, SP
    // 0xe00c20: AllocStack(0x20)
    //     0xe00c20: sub             SP, SP, #0x20
    // 0xe00c24: CheckStackOverflow
    //     0xe00c24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe00c28: cmp             SP, x16
    //     0xe00c2c: b.ls            #0xe00dbc
    // 0xe00c30: LoadField: r3 = r1->field_b
    //     0xe00c30: ldur            w3, [x1, #0xb]
    // 0xe00c34: DecompressPointer r3
    //     0xe00c34: add             x3, x3, HEAP, lsl #32
    // 0xe00c38: stur            x3, [fp, #-0x20]
    // 0xe00c3c: LoadField: r0 = r3->field_b
    //     0xe00c3c: ldur            w0, [x3, #0xb]
    // 0xe00c40: r4 = LoadInt32Instr(r0)
    //     0xe00c40: sbfx            x4, x0, #1, #0x1f
    // 0xe00c44: stur            x4, [fp, #-0x18]
    // 0xe00c48: r0 = 0
    //     0xe00c48: mov             x0, #0
    // 0xe00c4c: CheckStackOverflow
    //     0xe00c4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe00c50: cmp             SP, x16
    //     0xe00c54: b.ls            #0xe00dc4
    // 0xe00c58: LoadField: r1 = r3->field_b
    //     0xe00c58: ldur            w1, [x3, #0xb]
    // 0xe00c5c: r2 = LoadInt32Instr(r1)
    //     0xe00c5c: sbfx            x2, x1, #1, #0x1f
    // 0xe00c60: cmp             x4, x2
    // 0xe00c64: b.ne            #0xe00d9c
    // 0xe00c68: cmp             x0, x2
    // 0xe00c6c: b.ge            #0xe00d8c
    // 0xe00c70: LoadField: r1 = r3->field_f
    //     0xe00c70: ldur            w1, [x3, #0xf]
    // 0xe00c74: DecompressPointer r1
    //     0xe00c74: add             x1, x1, HEAP, lsl #32
    // 0xe00c78: ArrayLoad: r5 = r1[r0]  ; Unknown_4
    //     0xe00c78: add             x16, x1, x0, lsl #2
    //     0xe00c7c: ldur            w5, [x16, #0xf]
    // 0xe00c80: DecompressPointer r5
    //     0xe00c80: add             x5, x5, HEAP, lsl #32
    // 0xe00c84: stur            x5, [fp, #-0x10]
    // 0xe00c88: add             x6, x0, #1
    // 0xe00c8c: mov             x0, x5
    // 0xe00c90: stur            x6, [fp, #-8]
    // 0xe00c94: r2 = Null
    //     0xe00c94: mov             x2, NULL
    // 0xe00c98: r1 = Null
    //     0xe00c98: mov             x1, NULL
    // 0xe00c9c: cmp             w0, NULL
    // 0xe00ca0: b.eq            #0xe00d28
    // 0xe00ca4: branchIfSmi(r0, 0xe00d28)
    //     0xe00ca4: tbz             w0, #0, #0xe00d28
    // 0xe00ca8: r3 = LoadClassIdInstr(r0)
    //     0xe00ca8: ldur            x3, [x0, #-1]
    //     0xe00cac: ubfx            x3, x3, #0xc, #0x14
    // 0xe00cb0: r4 = LoadClassIdInstr(r0)
    //     0xe00cb0: ldur            x4, [x0, #-1]
    //     0xe00cb4: ubfx            x4, x4, #0xc, #0x14
    // 0xe00cb8: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0xe00cbc: ldr             x3, [x3, #0x18]
    // 0xe00cc0: ldr             x3, [x3, x4, lsl #3]
    // 0xe00cc4: LoadField: r3 = r3->field_2b
    //     0xe00cc4: ldur            w3, [x3, #0x2b]
    // 0xe00cc8: DecompressPointer r3
    //     0xe00cc8: add             x3, x3, HEAP, lsl #32
    // 0xe00ccc: cmp             w3, NULL
    // 0xe00cd0: b.eq            #0xe00d28
    // 0xe00cd4: LoadField: r3 = r3->field_f
    //     0xe00cd4: ldur            w3, [x3, #0xf]
    // 0xe00cd8: lsr             x3, x3, #3
    // 0xe00cdc: cmp             x3, #0xc35
    // 0xe00ce0: b.eq            #0xe00d30
    // 0xe00ce4: r3 = SubtypeTestCache
    //     0xe00ce4: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c658] SubtypeTestCache
    //     0xe00ce8: ldr             x3, [x3, #0x658]
    // 0xe00cec: r30 = Subtype1TestCacheStub
    //     0xe00cec: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0xe00cf0: LoadField: r30 = r30->field_7
    //     0xe00cf0: ldur            lr, [lr, #7]
    // 0xe00cf4: blr             lr
    // 0xe00cf8: cmp             w7, NULL
    // 0xe00cfc: b.eq            #0xe00d08
    // 0xe00d00: tbnz            w7, #4, #0xe00d28
    // 0xe00d04: b               #0xe00d30
    // 0xe00d08: r8 = PreferredSizeWidget
    //     0xe00d08: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8c660] Type: PreferredSizeWidget
    //     0xe00d0c: ldr             x8, [x8, #0x660]
    // 0xe00d10: r3 = SubtypeTestCache
    //     0xe00d10: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c668] SubtypeTestCache
    //     0xe00d14: ldr             x3, [x3, #0x668]
    // 0xe00d18: r30 = InstanceOfStub
    //     0xe00d18: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xe00d1c: LoadField: r30 = r30->field_7
    //     0xe00d1c: ldur            lr, [lr, #7]
    // 0xe00d20: blr             lr
    // 0xe00d24: b               #0xe00d34
    // 0xe00d28: r0 = false
    //     0xe00d28: add             x0, NULL, #0x30  ; false
    // 0xe00d2c: b               #0xe00d34
    // 0xe00d30: r0 = true
    //     0xe00d30: add             x0, NULL, #0x20  ; true
    // 0xe00d34: tbnz            w0, #4, #0xe00d74
    // 0xe00d38: ldur            x1, [fp, #-0x10]
    // 0xe00d3c: r0 = LoadClassIdInstr(r1)
    //     0xe00d3c: ldur            x0, [x1, #-1]
    //     0xe00d40: ubfx            x0, x0, #0xc, #0x14
    // 0xe00d44: r0 = GDT[cid_x0 + 0xade]()
    //     0xe00d44: add             lr, x0, #0xade
    //     0xe00d48: ldr             lr, [x21, lr, lsl #3]
    //     0xe00d4c: blr             lr
    // 0xe00d50: LoadField: d0 = r0->field_f
    //     0xe00d50: ldur            d0, [x0, #0xf]
    // 0xe00d54: d1 = 72.000000
    //     0xe00d54: add             x17, PP, #0x89, lsl #12  ; [pp+0x89030] IMM: double(72) from 0x4052000000000000
    //     0xe00d58: ldr             d1, [x17, #0x30]
    // 0xe00d5c: fcmp            d0, d1
    // 0xe00d60: b.ne            #0xe00d7c
    // 0xe00d64: r0 = true
    //     0xe00d64: add             x0, NULL, #0x20  ; true
    // 0xe00d68: LeaveFrame
    //     0xe00d68: mov             SP, fp
    //     0xe00d6c: ldp             fp, lr, [SP], #0x10
    // 0xe00d70: ret
    //     0xe00d70: ret             
    // 0xe00d74: d1 = 72.000000
    //     0xe00d74: add             x17, PP, #0x89, lsl #12  ; [pp+0x89030] IMM: double(72) from 0x4052000000000000
    //     0xe00d78: ldr             d1, [x17, #0x30]
    // 0xe00d7c: ldur            x0, [fp, #-8]
    // 0xe00d80: ldur            x3, [fp, #-0x20]
    // 0xe00d84: ldur            x4, [fp, #-0x18]
    // 0xe00d88: b               #0xe00c4c
    // 0xe00d8c: r0 = false
    //     0xe00d8c: add             x0, NULL, #0x30  ; false
    // 0xe00d90: LeaveFrame
    //     0xe00d90: mov             SP, fp
    //     0xe00d94: ldp             fp, lr, [SP], #0x10
    // 0xe00d98: ret
    //     0xe00d98: ret             
    // 0xe00d9c: mov             x0, x3
    // 0xe00da0: r0 = ConcurrentModificationError()
    //     0xe00da0: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xe00da4: mov             x1, x0
    // 0xe00da8: ldur            x0, [fp, #-0x20]
    // 0xe00dac: StoreField: r1->field_b = r0
    //     0xe00dac: stur            w0, [x1, #0xb]
    // 0xe00db0: mov             x0, x1
    // 0xe00db4: r0 = Throw()
    //     0xe00db4: bl              #0x13ddb2c  ; ThrowStub
    // 0xe00db8: brk             #0
    // 0xe00dbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe00dbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe00dc0: b               #0xe00c30
    // 0xe00dc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe00dc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe00dc8: b               #0xe00c58
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa3218, size: 0x30
    // 0xfa3218: EnterFrame
    //     0xfa3218: stp             fp, lr, [SP, #-0x10]!
    //     0xfa321c: mov             fp, SP
    // 0xfa3220: mov             x0, x1
    // 0xfa3224: r1 = <TabBar>
    //     0xfa3224: add             x1, PP, #0x80, lsl #12  ; [pp+0x80900] TypeArguments: <TabBar>
    //     0xfa3228: ldr             x1, [x1, #0x900]
    // 0xfa322c: r0 = _TabBarState()
    //     0xfa322c: bl              #0xfa3248  ; Allocate_TabBarStateStub -> _TabBarState (size=0x2c)
    // 0xfa3230: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa3234: StoreField: r0->field_23 = r1
    //     0xfa3234: stur            w1, [x0, #0x23]
    // 0xfa3238: StoreField: r0->field_27 = r1
    //     0xfa3238: stur            w1, [x0, #0x27]
    // 0xfa323c: LeaveFrame
    //     0xfa323c: mov             SP, fp
    //     0xfa3240: ldp             fp, lr, [SP], #0x10
    // 0xfa3244: ret
    //     0xfa3244: ret             
  }
  get _ preferredSize(/* No info */) {
    // ** addr: 0x123f978, size: 0x1d4
    // 0x123f978: EnterFrame
    //     0x123f978: stp             fp, lr, [SP, #-0x10]!
    //     0x123f97c: mov             fp, SP
    // 0x123f980: AllocStack(0x30)
    //     0x123f980: sub             SP, SP, #0x30
    // 0x123f984: CheckStackOverflow
    //     0x123f984: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x123f988: cmp             SP, x16
    //     0x123f98c: b.ls            #0x123fb3c
    // 0x123f990: LoadField: r3 = r1->field_b
    //     0x123f990: ldur            w3, [x1, #0xb]
    // 0x123f994: DecompressPointer r3
    //     0x123f994: add             x3, x3, HEAP, lsl #32
    // 0x123f998: stur            x3, [fp, #-0x20]
    // 0x123f99c: LoadField: r0 = r3->field_b
    //     0x123f99c: ldur            w0, [x3, #0xb]
    // 0x123f9a0: r4 = LoadInt32Instr(r0)
    //     0x123f9a0: sbfx            x4, x0, #1, #0x1f
    // 0x123f9a4: stur            x4, [fp, #-0x18]
    // 0x123f9a8: d0 = 46.000000
    //     0x123f9a8: add             x17, PP, #0x80, lsl #12  ; [pp+0x80908] IMM: double(46) from 0x4047000000000000
    //     0x123f9ac: ldr             d0, [x17, #0x908]
    // 0x123f9b0: r0 = 0
    //     0x123f9b0: mov             x0, #0
    // 0x123f9b4: stur            d0, [fp, #-0x28]
    // 0x123f9b8: CheckStackOverflow
    //     0x123f9b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x123f9bc: cmp             SP, x16
    //     0x123f9c0: b.ls            #0x123fb44
    // 0x123f9c4: LoadField: r1 = r3->field_b
    //     0x123f9c4: ldur            w1, [x3, #0xb]
    // 0x123f9c8: r2 = LoadInt32Instr(r1)
    //     0x123f9c8: sbfx            x2, x1, #1, #0x1f
    // 0x123f9cc: cmp             x4, x2
    // 0x123f9d0: b.ne            #0x123fb1c
    // 0x123f9d4: cmp             x0, x2
    // 0x123f9d8: b.ge            #0x123faec
    // 0x123f9dc: LoadField: r1 = r3->field_f
    //     0x123f9dc: ldur            w1, [x3, #0xf]
    // 0x123f9e0: DecompressPointer r1
    //     0x123f9e0: add             x1, x1, HEAP, lsl #32
    // 0x123f9e4: ArrayLoad: r5 = r1[r0]  ; Unknown_4
    //     0x123f9e4: add             x16, x1, x0, lsl #2
    //     0x123f9e8: ldur            w5, [x16, #0xf]
    // 0x123f9ec: DecompressPointer r5
    //     0x123f9ec: add             x5, x5, HEAP, lsl #32
    // 0x123f9f0: stur            x5, [fp, #-0x10]
    // 0x123f9f4: add             x6, x0, #1
    // 0x123f9f8: mov             x0, x5
    // 0x123f9fc: stur            x6, [fp, #-8]
    // 0x123fa00: r2 = Null
    //     0x123fa00: mov             x2, NULL
    // 0x123fa04: r1 = Null
    //     0x123fa04: mov             x1, NULL
    // 0x123fa08: cmp             w0, NULL
    // 0x123fa0c: b.eq            #0x123fa94
    // 0x123fa10: branchIfSmi(r0, 0x123fa94)
    //     0x123fa10: tbz             w0, #0, #0x123fa94
    // 0x123fa14: r3 = LoadClassIdInstr(r0)
    //     0x123fa14: ldur            x3, [x0, #-1]
    //     0x123fa18: ubfx            x3, x3, #0xc, #0x14
    // 0x123fa1c: r4 = LoadClassIdInstr(r0)
    //     0x123fa1c: ldur            x4, [x0, #-1]
    //     0x123fa20: ubfx            x4, x4, #0xc, #0x14
    // 0x123fa24: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x123fa28: ldr             x3, [x3, #0x18]
    // 0x123fa2c: ldr             x3, [x3, x4, lsl #3]
    // 0x123fa30: LoadField: r3 = r3->field_2b
    //     0x123fa30: ldur            w3, [x3, #0x2b]
    // 0x123fa34: DecompressPointer r3
    //     0x123fa34: add             x3, x3, HEAP, lsl #32
    // 0x123fa38: cmp             w3, NULL
    // 0x123fa3c: b.eq            #0x123fa94
    // 0x123fa40: LoadField: r3 = r3->field_f
    //     0x123fa40: ldur            w3, [x3, #0xf]
    // 0x123fa44: lsr             x3, x3, #3
    // 0x123fa48: cmp             x3, #0xc35
    // 0x123fa4c: b.eq            #0x123fa9c
    // 0x123fa50: r3 = SubtypeTestCache
    //     0x123fa50: add             x3, PP, #0x80, lsl #12  ; [pp+0x80910] SubtypeTestCache
    //     0x123fa54: ldr             x3, [x3, #0x910]
    // 0x123fa58: r30 = Subtype1TestCacheStub
    //     0x123fa58: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x123fa5c: LoadField: r30 = r30->field_7
    //     0x123fa5c: ldur            lr, [lr, #7]
    // 0x123fa60: blr             lr
    // 0x123fa64: cmp             w7, NULL
    // 0x123fa68: b.eq            #0x123fa74
    // 0x123fa6c: tbnz            w7, #4, #0x123fa94
    // 0x123fa70: b               #0x123fa9c
    // 0x123fa74: r8 = PreferredSizeWidget
    //     0x123fa74: add             x8, PP, #0x80, lsl #12  ; [pp+0x80918] Type: PreferredSizeWidget
    //     0x123fa78: ldr             x8, [x8, #0x918]
    // 0x123fa7c: r3 = SubtypeTestCache
    //     0x123fa7c: add             x3, PP, #0x80, lsl #12  ; [pp+0x80920] SubtypeTestCache
    //     0x123fa80: ldr             x3, [x3, #0x920]
    // 0x123fa84: r30 = InstanceOfStub
    //     0x123fa84: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x123fa88: LoadField: r30 = r30->field_7
    //     0x123fa88: ldur            lr, [lr, #7]
    // 0x123fa8c: blr             lr
    // 0x123fa90: b               #0x123faa0
    // 0x123fa94: r0 = false
    //     0x123fa94: add             x0, NULL, #0x30  ; false
    // 0x123fa98: b               #0x123faa0
    // 0x123fa9c: r0 = true
    //     0x123fa9c: add             x0, NULL, #0x20  ; true
    // 0x123faa0: tbnz            w0, #4, #0x123fad4
    // 0x123faa4: ldur            d0, [fp, #-0x28]
    // 0x123faa8: ldur            x1, [fp, #-0x10]
    // 0x123faac: r0 = LoadClassIdInstr(r1)
    //     0x123faac: ldur            x0, [x1, #-1]
    //     0x123fab0: ubfx            x0, x0, #0xc, #0x14
    // 0x123fab4: r0 = GDT[cid_x0 + 0xade]()
    //     0x123fab4: add             lr, x0, #0xade
    //     0x123fab8: ldr             lr, [x21, lr, lsl #3]
    //     0x123fabc: blr             lr
    // 0x123fac0: LoadField: d0 = r0->field_f
    //     0x123fac0: ldur            d0, [x0, #0xf]
    // 0x123fac4: ldur            d1, [fp, #-0x28]
    // 0x123fac8: fmax            v2.2d, v0.2d, v1.2d
    // 0x123facc: mov             v0.16b, v2.16b
    // 0x123fad0: b               #0x123fadc
    // 0x123fad4: ldur            d1, [fp, #-0x28]
    // 0x123fad8: mov             v0.16b, v1.16b
    // 0x123fadc: ldur            x0, [fp, #-8]
    // 0x123fae0: ldur            x3, [fp, #-0x20]
    // 0x123fae4: ldur            x4, [fp, #-0x18]
    // 0x123fae8: b               #0x123f9b4
    // 0x123faec: mov             v1.16b, v0.16b
    // 0x123faf0: d0 = 2.000000
    //     0x123faf0: fmov            d0, #2.00000000
    // 0x123faf4: fadd            d2, d1, d0
    // 0x123faf8: stur            d2, [fp, #-0x30]
    // 0x123fafc: r0 = Size()
    //     0x123fafc: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x123fb00: d0 = inf
    //     0x123fb00: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0x123fb04: StoreField: r0->field_7 = d0
    //     0x123fb04: stur            d0, [x0, #7]
    // 0x123fb08: ldur            d0, [fp, #-0x30]
    // 0x123fb0c: StoreField: r0->field_f = d0
    //     0x123fb0c: stur            d0, [x0, #0xf]
    // 0x123fb10: LeaveFrame
    //     0x123fb10: mov             SP, fp
    //     0x123fb14: ldp             fp, lr, [SP], #0x10
    // 0x123fb18: ret
    //     0x123fb18: ret             
    // 0x123fb1c: mov             x0, x3
    // 0x123fb20: r0 = ConcurrentModificationError()
    //     0x123fb20: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x123fb24: mov             x1, x0
    // 0x123fb28: ldur            x0, [fp, #-0x20]
    // 0x123fb2c: StoreField: r1->field_b = r0
    //     0x123fb2c: stur            w0, [x1, #0xb]
    // 0x123fb30: mov             x0, x1
    // 0x123fb34: r0 = Throw()
    //     0x123fb34: bl              #0x13ddb2c  ; ThrowStub
    // 0x123fb38: brk             #0
    // 0x123fb3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x123fb3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x123fb40: b               #0x123f990
    // 0x123fb44: r0 = StackOverflowSharedWithFPURegs()
    //     0x123fb44: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x123fb48: b               #0x123f9c4
  }
}

// class id: 6429, size: 0x2c, field offset: 0x10
//   const constructor, 
class _TabStyle extends AnimatedWidget {

  _ build(/* No info */) {
    // ** addr: 0x10f8938, size: 0x578
    // 0x10f8938: EnterFrame
    //     0x10f8938: stp             fp, lr, [SP, #-0x10]!
    //     0x10f893c: mov             fp, SP
    // 0x10f8940: AllocStack(0x60)
    //     0x10f8940: sub             SP, SP, #0x60
    // 0x10f8944: SetupParameters(_TabStyle this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x10f8944: mov             x0, x2
    //     0x10f8948: stur            x2, [fp, #-0x10]
    //     0x10f894c: mov             x2, x1
    //     0x10f8950: stur            x1, [fp, #-8]
    // 0x10f8954: CheckStackOverflow
    //     0x10f8954: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f8958: cmp             SP, x16
    //     0x10f895c: b.ls            #0x10f8e7c
    // 0x10f8960: mov             x1, x0
    // 0x10f8964: r0 = of()
    //     0x10f8964: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x10f8968: ldur            x1, [fp, #-0x10]
    // 0x10f896c: stur            x0, [fp, #-0x18]
    // 0x10f8970: r0 = of()
    //     0x10f8970: bl              #0xdffc38  ; [package:flutter/src/material/tab_bar_theme.dart] TabBarTheme::of
    // 0x10f8974: ldur            x3, [fp, #-8]
    // 0x10f8978: LoadField: r4 = r3->field_b
    //     0x10f8978: ldur            w4, [x3, #0xb]
    // 0x10f897c: DecompressPointer r4
    //     0x10f897c: add             x4, x4, HEAP, lsl #32
    // 0x10f8980: mov             x0, x4
    // 0x10f8984: stur            x4, [fp, #-0x20]
    // 0x10f8988: r2 = Null
    //     0x10f8988: mov             x2, NULL
    // 0x10f898c: r1 = Null
    //     0x10f898c: mov             x1, NULL
    // 0x10f8990: r8 = Animation<double>
    //     0x10f8990: add             x8, PP, #0x80, lsl #12  ; [pp+0x809a8] Type: Animation<double>
    //     0x10f8994: ldr             x8, [x8, #0x9a8]
    // 0x10f8998: r3 = Null
    //     0x10f8998: add             x3, PP, #0x95, lsl #12  ; [pp+0x95b08] Null
    //     0x10f899c: ldr             x3, [x3, #0xb08]
    // 0x10f89a0: r0 = Animation<double>()
    //     0x10f89a0: bl              #0x829684  ; IsType_Animation<double>_Stub
    // 0x10f89a4: ldur            x0, [fp, #-8]
    // 0x10f89a8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x10f89a8: ldur            w2, [x0, #0x17]
    // 0x10f89ac: DecompressPointer r2
    //     0x10f89ac: add             x2, x2, HEAP, lsl #32
    // 0x10f89b0: stur            x2, [fp, #-0x40]
    // 0x10f89b4: tbnz            w2, #4, #0x10f89c4
    // 0x10f89b8: r3 = _ConstSet len:1
    //     0x10f89b8: add             x3, PP, #0x95, lsl #12  ; [pp+0x95b18] Set<WidgetState>(1)
    //     0x10f89bc: ldr             x3, [x3, #0xb18]
    // 0x10f89c0: b               #0x10f89cc
    // 0x10f89c4: r3 = _ConstSet len:0
    //     0x10f89c4: add             x3, PP, #0x26, lsl #12  ; [pp+0x26248] Set<WidgetState>(0)
    //     0x10f89c8: ldr             x3, [x3, #0x248]
    // 0x10f89cc: stur            x3, [fp, #-0x38]
    // 0x10f89d0: LoadField: r4 = r0->field_23
    //     0x10f89d0: ldur            w4, [x0, #0x23]
    // 0x10f89d4: DecompressPointer r4
    //     0x10f89d4: add             x4, x4, HEAP, lsl #32
    // 0x10f89d8: stur            x4, [fp, #-0x30]
    // 0x10f89dc: r5 = LoadClassIdInstr(r4)
    //     0x10f89dc: ldur            x5, [x4, #-1]
    //     0x10f89e0: ubfx            x5, x5, #0xc, #0x14
    // 0x10f89e4: stur            x5, [fp, #-0x28]
    // 0x10f89e8: r17 = 5058
    //     0x10f89e8: mov             x17, #0x13c2
    // 0x10f89ec: cmp             x5, x17
    // 0x10f89f0: b.ne            #0x10f8a00
    // 0x10f89f4: LoadField: r1 = r4->field_23
    //     0x10f89f4: ldur            w1, [x4, #0x23]
    // 0x10f89f8: DecompressPointer r1
    //     0x10f89f8: add             x1, x1, HEAP, lsl #32
    // 0x10f89fc: b               #0x10f8a74
    // 0x10f8a00: r17 = 5059
    //     0x10f8a00: mov             x17, #0x13c3
    // 0x10f8a04: cmp             x5, x17
    // 0x10f8a08: b.eq            #0x10f8e20
    // 0x10f8a0c: r17 = 5060
    //     0x10f8a0c: mov             x17, #0x13c4
    // 0x10f8a10: cmp             x5, x17
    // 0x10f8a14: b.ne            #0x10f8a4c
    // 0x10f8a18: mov             x1, x4
    // 0x10f8a1c: LoadField: r0 = r1->field_53
    //     0x10f8a1c: ldur            w0, [x1, #0x53]
    // 0x10f8a20: DecompressPointer r0
    //     0x10f8a20: add             x0, x0, HEAP, lsl #32
    // 0x10f8a24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10f8a28: cmp             w0, w16
    // 0x10f8a2c: b.ne            #0x10f8a3c
    // 0x10f8a30: r2 = _textTheme
    //     0x10f8a30: add             x2, PP, #0x26, lsl #12  ; [pp+0x260c8] Field <_TabsPrimaryDefaultsM3@780014024._textTheme@780014024>: late final (offset: 0x54)
    //     0x10f8a34: ldr             x2, [x2, #0xc8]
    // 0x10f8a38: r0 = InitLateFinalInstanceField()
    //     0x10f8a38: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x10f8a3c: LoadField: r1 = r0->field_27
    //     0x10f8a3c: ldur            w1, [x0, #0x27]
    // 0x10f8a40: DecompressPointer r1
    //     0x10f8a40: add             x1, x1, HEAP, lsl #32
    // 0x10f8a44: ldur            x0, [fp, #-8]
    // 0x10f8a48: b               #0x10f8a74
    // 0x10f8a4c: mov             x0, x4
    // 0x10f8a50: LoadField: r1 = r0->field_4b
    //     0x10f8a50: ldur            w1, [x0, #0x4b]
    // 0x10f8a54: DecompressPointer r1
    //     0x10f8a54: add             x1, x1, HEAP, lsl #32
    // 0x10f8a58: r0 = of()
    //     0x10f8a58: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x10f8a5c: LoadField: r1 = r0->field_83
    //     0x10f8a5c: ldur            w1, [x0, #0x83]
    // 0x10f8a60: DecompressPointer r1
    //     0x10f8a60: add             x1, x1, HEAP, lsl #32
    // 0x10f8a64: LoadField: r0 = r1->field_2b
    //     0x10f8a64: ldur            w0, [x1, #0x2b]
    // 0x10f8a68: DecompressPointer r0
    //     0x10f8a68: add             x0, x0, HEAP, lsl #32
    // 0x10f8a6c: mov             x1, x0
    // 0x10f8a70: ldur            x0, [fp, #-8]
    // 0x10f8a74: cmp             w1, NULL
    // 0x10f8a78: b.eq            #0x10f8e84
    // 0x10f8a7c: LoadField: r3 = r0->field_f
    //     0x10f8a7c: ldur            w3, [x0, #0xf]
    // 0x10f8a80: DecompressPointer r3
    //     0x10f8a80: add             x3, x3, HEAP, lsl #32
    // 0x10f8a84: stur            x3, [fp, #-0x48]
    // 0x10f8a88: cmp             w3, NULL
    // 0x10f8a8c: b.ne            #0x10f8a98
    // 0x10f8a90: r2 = Null
    //     0x10f8a90: mov             x2, NULL
    // 0x10f8a94: b               #0x10f8a9c
    // 0x10f8a98: mov             x2, x3
    // 0x10f8a9c: ldur            x4, [fp, #-0x28]
    // 0x10f8aa0: r0 = merge()
    //     0x10f8aa0: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x10f8aa4: r16 = true
    //     0x10f8aa4: add             x16, NULL, #0x20  ; true
    // 0x10f8aa8: str             x16, [SP]
    // 0x10f8aac: mov             x1, x0
    // 0x10f8ab0: r4 = const [0, 0x2, 0x1, 0x1, inherit, 0x1, null]
    //     0x10f8ab0: add             x4, PP, #0x95, lsl #12  ; [pp+0x95b20] List(7) [0, 0x2, 0x1, 0x1, "inherit", 0x1, Null]
    //     0x10f8ab4: ldr             x4, [x4, #0xb20]
    // 0x10f8ab8: r0 = copyWith()
    //     0x10f8ab8: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x10f8abc: mov             x2, x0
    // 0x10f8ac0: ldur            x0, [fp, #-0x28]
    // 0x10f8ac4: stur            x2, [fp, #-0x50]
    // 0x10f8ac8: r17 = 5058
    //     0x10f8ac8: mov             x17, #0x13c2
    // 0x10f8acc: cmp             x0, x17
    // 0x10f8ad0: b.ne            #0x10f8ae8
    // 0x10f8ad4: ldur            x1, [fp, #-0x30]
    // 0x10f8ad8: LoadField: r0 = r1->field_2b
    //     0x10f8ad8: ldur            w0, [x1, #0x2b]
    // 0x10f8adc: DecompressPointer r0
    //     0x10f8adc: add             x0, x0, HEAP, lsl #32
    // 0x10f8ae0: mov             x1, x0
    // 0x10f8ae4: b               #0x10f8b54
    // 0x10f8ae8: ldur            x1, [fp, #-0x30]
    // 0x10f8aec: r17 = 5059
    //     0x10f8aec: mov             x17, #0x13c3
    // 0x10f8af0: cmp             x0, x17
    // 0x10f8af4: b.eq            #0x10f8e50
    // 0x10f8af8: r17 = 5060
    //     0x10f8af8: mov             x17, #0x13c4
    // 0x10f8afc: cmp             x0, x17
    // 0x10f8b00: b.ne            #0x10f8b30
    // 0x10f8b04: LoadField: r0 = r1->field_53
    //     0x10f8b04: ldur            w0, [x1, #0x53]
    // 0x10f8b08: DecompressPointer r0
    //     0x10f8b08: add             x0, x0, HEAP, lsl #32
    // 0x10f8b0c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10f8b10: cmp             w0, w16
    // 0x10f8b14: b.ne            #0x10f8b24
    // 0x10f8b18: r2 = _textTheme
    //     0x10f8b18: add             x2, PP, #0x26, lsl #12  ; [pp+0x260c8] Field <_TabsPrimaryDefaultsM3@780014024._textTheme@780014024>: late final (offset: 0x54)
    //     0x10f8b1c: ldr             x2, [x2, #0xc8]
    // 0x10f8b20: r0 = InitLateFinalInstanceField()
    //     0x10f8b20: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x10f8b24: LoadField: r1 = r0->field_27
    //     0x10f8b24: ldur            w1, [x0, #0x27]
    // 0x10f8b28: DecompressPointer r1
    //     0x10f8b28: add             x1, x1, HEAP, lsl #32
    // 0x10f8b2c: b               #0x10f8b54
    // 0x10f8b30: LoadField: r0 = r1->field_4b
    //     0x10f8b30: ldur            w0, [x1, #0x4b]
    // 0x10f8b34: DecompressPointer r0
    //     0x10f8b34: add             x0, x0, HEAP, lsl #32
    // 0x10f8b38: mov             x1, x0
    // 0x10f8b3c: r0 = of()
    //     0x10f8b3c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x10f8b40: LoadField: r1 = r0->field_83
    //     0x10f8b40: ldur            w1, [x0, #0x83]
    // 0x10f8b44: DecompressPointer r1
    //     0x10f8b44: add             x1, x1, HEAP, lsl #32
    // 0x10f8b48: LoadField: r0 = r1->field_2b
    //     0x10f8b48: ldur            w0, [x1, #0x2b]
    // 0x10f8b4c: DecompressPointer r0
    //     0x10f8b4c: add             x0, x0, HEAP, lsl #32
    // 0x10f8b50: mov             x1, x0
    // 0x10f8b54: ldur            x0, [fp, #-8]
    // 0x10f8b58: cmp             w1, NULL
    // 0x10f8b5c: b.eq            #0x10f8e88
    // 0x10f8b60: LoadField: r2 = r0->field_13
    //     0x10f8b60: ldur            w2, [x0, #0x13]
    // 0x10f8b64: DecompressPointer r2
    //     0x10f8b64: add             x2, x2, HEAP, lsl #32
    // 0x10f8b68: cmp             w2, NULL
    // 0x10f8b6c: b.ne            #0x10f8b74
    // 0x10f8b70: r2 = Null
    //     0x10f8b70: mov             x2, NULL
    // 0x10f8b74: cmp             w2, NULL
    // 0x10f8b78: b.ne            #0x10f8b80
    // 0x10f8b7c: ldur            x2, [fp, #-0x48]
    // 0x10f8b80: ldur            x3, [fp, #-0x40]
    // 0x10f8b84: r0 = merge()
    //     0x10f8b84: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x10f8b88: r16 = true
    //     0x10f8b88: add             x16, NULL, #0x20  ; true
    // 0x10f8b8c: str             x16, [SP]
    // 0x10f8b90: mov             x1, x0
    // 0x10f8b94: r4 = const [0, 0x2, 0x1, 0x1, inherit, 0x1, null]
    //     0x10f8b94: add             x4, PP, #0x95, lsl #12  ; [pp+0x95b20] List(7) [0, 0x2, 0x1, 0x1, "inherit", 0x1, Null]
    //     0x10f8b98: ldr             x4, [x4, #0xb20]
    // 0x10f8b9c: r0 = copyWith()
    //     0x10f8b9c: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x10f8ba0: mov             x2, x0
    // 0x10f8ba4: ldur            x0, [fp, #-0x40]
    // 0x10f8ba8: stur            x2, [fp, #-0x48]
    // 0x10f8bac: tbnz            w0, #4, #0x10f8be8
    // 0x10f8bb0: ldur            x1, [fp, #-0x20]
    // 0x10f8bb4: r0 = LoadClassIdInstr(r1)
    //     0x10f8bb4: ldur            x0, [x1, #-1]
    //     0x10f8bb8: ubfx            x0, x0, #0xc, #0x14
    // 0x10f8bbc: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x10f8bbc: mov             x17, #0x4e2e
    //     0x10f8bc0: movk            x17, #1, lsl #16
    //     0x10f8bc4: add             lr, x0, x17
    //     0x10f8bc8: ldr             lr, [x21, lr, lsl #3]
    //     0x10f8bcc: blr             lr
    // 0x10f8bd0: ldur            x1, [fp, #-0x50]
    // 0x10f8bd4: ldur            x2, [fp, #-0x48]
    // 0x10f8bd8: mov             x3, x0
    // 0x10f8bdc: r0 = lerp()
    //     0x10f8bdc: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x10f8be0: mov             x1, x0
    // 0x10f8be4: b               #0x10f8c1c
    // 0x10f8be8: ldur            x1, [fp, #-0x20]
    // 0x10f8bec: r0 = LoadClassIdInstr(r1)
    //     0x10f8bec: ldur            x0, [x1, #-1]
    //     0x10f8bf0: ubfx            x0, x0, #0xc, #0x14
    // 0x10f8bf4: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x10f8bf4: mov             x17, #0x4e2e
    //     0x10f8bf8: movk            x17, #1, lsl #16
    //     0x10f8bfc: add             lr, x0, x17
    //     0x10f8c00: ldr             lr, [x21, lr, lsl #3]
    //     0x10f8c04: blr             lr
    // 0x10f8c08: ldur            x1, [fp, #-0x48]
    // 0x10f8c0c: ldur            x2, [fp, #-0x50]
    // 0x10f8c10: mov             x3, x0
    // 0x10f8c14: r0 = lerp()
    //     0x10f8c14: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x10f8c18: mov             x1, x0
    // 0x10f8c1c: ldur            x0, [fp, #-0x18]
    // 0x10f8c20: stur            x1, [fp, #-0x20]
    // 0x10f8c24: LoadField: r2 = r0->field_3f
    //     0x10f8c24: ldur            w2, [x0, #0x3f]
    // 0x10f8c28: DecompressPointer r2
    //     0x10f8c28: add             x2, x2, HEAP, lsl #32
    // 0x10f8c2c: LoadField: r0 = r2->field_7
    //     0x10f8c2c: ldur            w0, [x2, #7]
    // 0x10f8c30: DecompressPointer r0
    //     0x10f8c30: add             x0, x0, HEAP, lsl #32
    // 0x10f8c34: LoadField: r2 = r0->field_7
    //     0x10f8c34: ldur            x2, [x0, #7]
    // 0x10f8c38: cmp             x2, #0
    // 0x10f8c3c: b.gt            #0x10f8c64
    // 0x10f8c40: r0 = LoadStaticField(0xb80)
    //     0x10f8c40: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x10f8c44: ldr             x0, [x0, #0x1700]
    // 0x10f8c48: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10f8c4c: cmp             w0, w16
    // 0x10f8c50: b.ne            #0x10f8c60
    // 0x10f8c54: r2 = kDefaultIconLightColor
    //     0x10f8c54: add             x2, PP, #0x12, lsl #12  ; [pp+0x12ce0] Field <::.kDefaultIconLightColor>: static late final (offset: 0xb80)
    //     0x10f8c58: ldr             x2, [x2, #0xce0]
    // 0x10f8c5c: r0 = InitLateFinalStaticField()
    //     0x10f8c5c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x10f8c60: b               #0x10f8c84
    // 0x10f8c64: r0 = LoadStaticField(0xb84)
    //     0x10f8c64: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x10f8c68: ldr             x0, [x0, #0x1708]
    // 0x10f8c6c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10f8c70: cmp             w0, w16
    // 0x10f8c74: b.ne            #0x10f8c84
    // 0x10f8c78: r2 = kDefaultIconDarkColor
    //     0x10f8c78: add             x2, PP, #0x12, lsl #12  ; [pp+0x12ce8] Field <::.kDefaultIconDarkColor>: static late final (offset: 0xb84)
    //     0x10f8c7c: ldr             x2, [x2, #0xce8]
    // 0x10f8c80: r0 = InitLateFinalStaticField()
    //     0x10f8c80: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x10f8c84: ldur            x1, [fp, #-0x10]
    // 0x10f8c88: stur            x0, [fp, #-0x18]
    // 0x10f8c8c: r0 = of()
    //     0x10f8c8c: bl              #0xd0e004  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::of
    // 0x10f8c90: mov             x1, x0
    // 0x10f8c94: stur            x1, [fp, #-0x40]
    // 0x10f8c98: LoadField: r0 = r1->field_1b
    //     0x10f8c98: ldur            w0, [x1, #0x1b]
    // 0x10f8c9c: DecompressPointer r0
    //     0x10f8c9c: add             x0, x0, HEAP, lsl #32
    // 0x10f8ca0: r2 = LoadClassIdInstr(r0)
    //     0x10f8ca0: ldur            x2, [x0, #-1]
    //     0x10f8ca4: ubfx            x2, x2, #0xc, #0x14
    // 0x10f8ca8: ldur            x16, [fp, #-0x18]
    // 0x10f8cac: stp             x16, x0, [SP]
    // 0x10f8cb0: mov             x0, x2
    // 0x10f8cb4: mov             lr, x0
    // 0x10f8cb8: ldr             lr, [x21, lr, lsl #3]
    // 0x10f8cbc: blr             lr
    // 0x10f8cc0: tbz             w0, #4, #0x10f8ccc
    // 0x10f8cc4: ldur            x0, [fp, #-0x40]
    // 0x10f8cc8: b               #0x10f8cd0
    // 0x10f8ccc: r0 = Null
    //     0x10f8ccc: mov             x0, NULL
    // 0x10f8cd0: stur            x0, [fp, #-0x18]
    // 0x10f8cd4: str             x0, [SP]
    // 0x10f8cd8: ldur            x1, [fp, #-8]
    // 0x10f8cdc: ldur            x2, [fp, #-0x10]
    // 0x10f8ce0: r4 = const [0, 0x3, 0x1, 0x2, iconTheme, 0x2, null]
    //     0x10f8ce0: add             x4, PP, #0x95, lsl #12  ; [pp+0x95b28] List(7) [0, 0x3, 0x1, 0x2, "iconTheme", 0x2, Null]
    //     0x10f8ce4: ldr             x4, [x4, #0xb28]
    // 0x10f8ce8: r0 = _resolveWithLabelColor()
    //     0x10f8ce8: bl              #0x10f8eb0  ; [package:flutter/src/material/tabs.dart] _TabStyle::_resolveWithLabelColor
    // 0x10f8cec: mov             x1, x0
    // 0x10f8cf0: ldur            x2, [fp, #-0x38]
    // 0x10f8cf4: r0 = resolve()
    //     0x10f8cf4: bl              #0x9fb584  ; [package:flutter/src/widgets/widget_state.dart] _WidgetStateColor::resolve
    // 0x10f8cf8: ldur            x1, [fp, #-8]
    // 0x10f8cfc: ldur            x2, [fp, #-0x10]
    // 0x10f8d00: stur            x0, [fp, #-0x10]
    // 0x10f8d04: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x10f8d04: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x10f8d08: r0 = _resolveWithLabelColor()
    //     0x10f8d08: bl              #0x10f8eb0  ; [package:flutter/src/material/tabs.dart] _TabStyle::_resolveWithLabelColor
    // 0x10f8d0c: mov             x1, x0
    // 0x10f8d10: ldur            x2, [fp, #-0x38]
    // 0x10f8d14: r0 = resolve()
    //     0x10f8d14: bl              #0x9fb584  ; [package:flutter/src/widgets/widget_state.dart] _WidgetStateColor::resolve
    // 0x10f8d18: str             x0, [SP]
    // 0x10f8d1c: ldur            x1, [fp, #-0x20]
    // 0x10f8d20: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x10f8d20: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x10f8d24: ldr             x4, [x4, #0x7f0]
    // 0x10f8d28: r0 = copyWith()
    //     0x10f8d28: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x10f8d2c: mov             x1, x0
    // 0x10f8d30: ldur            x0, [fp, #-0x18]
    // 0x10f8d34: stur            x1, [fp, #-0x20]
    // 0x10f8d38: cmp             w0, NULL
    // 0x10f8d3c: b.ne            #0x10f8d48
    // 0x10f8d40: r0 = Null
    //     0x10f8d40: mov             x0, NULL
    // 0x10f8d44: b               #0x10f8d54
    // 0x10f8d48: LoadField: r2 = r0->field_7
    //     0x10f8d48: ldur            w2, [x0, #7]
    // 0x10f8d4c: DecompressPointer r2
    //     0x10f8d4c: add             x2, x2, HEAP, lsl #32
    // 0x10f8d50: mov             x0, x2
    // 0x10f8d54: cmp             w0, NULL
    // 0x10f8d58: b.ne            #0x10f8d64
    // 0x10f8d5c: d0 = 24.000000
    //     0x10f8d5c: fmov            d0, #24.00000000
    // 0x10f8d60: b               #0x10f8d68
    // 0x10f8d64: LoadField: d0 = r0->field_7
    //     0x10f8d64: ldur            d0, [x0, #7]
    // 0x10f8d68: ldur            x2, [fp, #-8]
    // 0x10f8d6c: ldur            x0, [fp, #-0x10]
    // 0x10f8d70: r3 = inline_Allocate_Double()
    //     0x10f8d70: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x10f8d74: add             x3, x3, #0x10
    //     0x10f8d78: cmp             x4, x3
    //     0x10f8d7c: b.ls            #0x10f8e8c
    //     0x10f8d80: str             x3, [THR, #0x60]  ; THR::top
    //     0x10f8d84: sub             x3, x3, #0xf
    //     0x10f8d88: mov             x4, #0xe19c
    //     0x10f8d8c: movk            x4, #3, lsl #16
    //     0x10f8d90: stur            x4, [x3, #-1]
    // 0x10f8d94: dmb             ishst
    // 0x10f8d98: StoreField: r3->field_7 = d0
    //     0x10f8d98: stur            d0, [x3, #7]
    // 0x10f8d9c: stur            x3, [fp, #-0x18]
    // 0x10f8da0: r0 = IconThemeData()
    //     0x10f8da0: bl              #0x8ac78c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0x10f8da4: mov             x1, x0
    // 0x10f8da8: ldur            x0, [fp, #-0x18]
    // 0x10f8dac: StoreField: r1->field_7 = r0
    //     0x10f8dac: stur            w0, [x1, #7]
    // 0x10f8db0: ldur            x0, [fp, #-0x10]
    // 0x10f8db4: StoreField: r1->field_1b = r0
    //     0x10f8db4: stur            w0, [x1, #0x1b]
    // 0x10f8db8: ldur            x0, [fp, #-8]
    // 0x10f8dbc: LoadField: r2 = r0->field_27
    //     0x10f8dbc: ldur            w2, [x0, #0x27]
    // 0x10f8dc0: DecompressPointer r2
    //     0x10f8dc0: add             x2, x2, HEAP, lsl #32
    // 0x10f8dc4: mov             x16, x1
    // 0x10f8dc8: mov             x1, x2
    // 0x10f8dcc: mov             x2, x16
    // 0x10f8dd0: r0 = merge()
    //     0x10f8dd0: bl              #0xd0c588  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::merge
    // 0x10f8dd4: stur            x0, [fp, #-8]
    // 0x10f8dd8: r0 = DefaultTextStyle()
    //     0x10f8dd8: bl              #0xd0b11c  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0x10f8ddc: mov             x1, x0
    // 0x10f8de0: ldur            x0, [fp, #-0x20]
    // 0x10f8de4: StoreField: r1->field_f = r0
    //     0x10f8de4: stur            w0, [x1, #0xf]
    // 0x10f8de8: r0 = true
    //     0x10f8de8: add             x0, NULL, #0x20  ; true
    // 0x10f8dec: ArrayStore: r1[0] = r0  ; List_4
    //     0x10f8dec: stur            w0, [x1, #0x17]
    // 0x10f8df0: r0 = Instance_TextOverflow
    //     0x10f8df0: add             x0, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0x10f8df4: ldr             x0, [x0, #0x108]
    // 0x10f8df8: StoreField: r1->field_1b = r0
    //     0x10f8df8: stur            w0, [x1, #0x1b]
    // 0x10f8dfc: r0 = Instance_TextWidthBasis
    //     0x10f8dfc: add             x0, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0x10f8e00: ldr             x0, [x0, #0x110]
    // 0x10f8e04: StoreField: r1->field_23 = r0
    //     0x10f8e04: stur            w0, [x1, #0x23]
    // 0x10f8e08: ldur            x0, [fp, #-8]
    // 0x10f8e0c: StoreField: r1->field_b = r0
    //     0x10f8e0c: stur            w0, [x1, #0xb]
    // 0x10f8e10: mov             x0, x1
    // 0x10f8e14: LeaveFrame
    //     0x10f8e14: mov             SP, fp
    //     0x10f8e18: ldp             fp, lr, [SP], #0x10
    // 0x10f8e1c: ret
    //     0x10f8e1c: ret             
    // 0x10f8e20: mov             x1, x4
    // 0x10f8e24: LoadField: r0 = r1->field_53
    //     0x10f8e24: ldur            w0, [x1, #0x53]
    // 0x10f8e28: DecompressPointer r0
    //     0x10f8e28: add             x0, x0, HEAP, lsl #32
    // 0x10f8e2c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10f8e30: cmp             w0, w16
    // 0x10f8e34: b.ne            #0x10f8e44
    // 0x10f8e38: r2 = _textTheme
    //     0x10f8e38: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f8] Field <_TabsSecondaryDefaultsM3@780014024._textTheme@780014024>: late final (offset: 0x54)
    //     0x10f8e3c: ldr             x2, [x2, #0xf8]
    // 0x10f8e40: r0 = InitLateFinalInstanceField()
    //     0x10f8e40: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x10f8e44: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x10f8e44: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x10f8e48: r0 = Throw()
    //     0x10f8e48: bl              #0x13ddb2c  ; ThrowStub
    // 0x10f8e4c: brk             #0
    // 0x10f8e50: LoadField: r0 = r1->field_53
    //     0x10f8e50: ldur            w0, [x1, #0x53]
    // 0x10f8e54: DecompressPointer r0
    //     0x10f8e54: add             x0, x0, HEAP, lsl #32
    // 0x10f8e58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10f8e5c: cmp             w0, w16
    // 0x10f8e60: b.ne            #0x10f8e70
    // 0x10f8e64: r2 = _textTheme
    //     0x10f8e64: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f8] Field <_TabsSecondaryDefaultsM3@780014024._textTheme@780014024>: late final (offset: 0x54)
    //     0x10f8e68: ldr             x2, [x2, #0xf8]
    // 0x10f8e6c: r0 = InitLateFinalInstanceField()
    //     0x10f8e6c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x10f8e70: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x10f8e70: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x10f8e74: r0 = Throw()
    //     0x10f8e74: bl              #0x13ddb2c  ; ThrowStub
    // 0x10f8e78: brk             #0
    // 0x10f8e7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f8e7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f8e80: b               #0x10f8960
    // 0x10f8e84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10f8e84: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10f8e88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10f8e88: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10f8e8c: SaveReg d0
    //     0x10f8e8c: str             q0, [SP, #-0x10]!
    // 0x10f8e90: stp             x1, x2, [SP, #-0x10]!
    // 0x10f8e94: SaveReg r0
    //     0x10f8e94: str             x0, [SP, #-8]!
    // 0x10f8e98: r0 = AllocateDouble()
    //     0x10f8e98: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10f8e9c: mov             x3, x0
    // 0x10f8ea0: RestoreReg r0
    //     0x10f8ea0: ldr             x0, [SP], #8
    // 0x10f8ea4: ldp             x1, x2, [SP], #0x10
    // 0x10f8ea8: RestoreReg d0
    //     0x10f8ea8: ldr             q0, [SP], #0x10
    // 0x10f8eac: b               #0x10f8d98
  }
  _ _resolveWithLabelColor(/* No info */) {
    // ** addr: 0x10f8eb0, size: 0x464
    // 0x10f8eb0: EnterFrame
    //     0x10f8eb0: stp             fp, lr, [SP, #-0x10]!
    //     0x10f8eb4: mov             fp, SP
    // 0x10f8eb8: AllocStack(0x28)
    //     0x10f8eb8: sub             SP, SP, #0x28
    // 0x10f8ebc: SetupParameters(_TabStyle this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, {dynamic iconTheme = Null /* r3, fp-0x8 */})
    //     0x10f8ebc: mov             x0, x2
    //     0x10f8ec0: stur            x2, [fp, #-0x18]
    //     0x10f8ec4: mov             x2, x1
    //     0x10f8ec8: stur            x1, [fp, #-0x10]
    //     0x10f8ecc: ldur            w1, [x4, #0x13]
    //     0x10f8ed0: ldur            w3, [x4, #0x1f]
    //     0x10f8ed4: add             x3, x3, HEAP, lsl #32
    //     0x10f8ed8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12918] "iconTheme"
    //     0x10f8edc: ldr             x16, [x16, #0x918]
    //     0x10f8ee0: cmp             w3, w16
    //     0x10f8ee4: b.ne            #0x10f8f04
    //     0x10f8ee8: ldur            w3, [x4, #0x23]
    //     0x10f8eec: add             x3, x3, HEAP, lsl #32
    //     0x10f8ef0: sub             w4, w1, w3
    //     0x10f8ef4: add             x1, fp, w4, sxtw #2
    //     0x10f8ef8: ldr             x1, [x1, #8]
    //     0x10f8efc: mov             x3, x1
    //     0x10f8f00: b               #0x10f8f08
    //     0x10f8f04: mov             x3, NULL
    //     0x10f8f08: stur            x3, [fp, #-8]
    // 0x10f8f0c: CheckStackOverflow
    //     0x10f8f0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f8f10: cmp             SP, x16
    //     0x10f8f14: b.ls            #0x10f9304
    // 0x10f8f18: mov             x1, x0
    // 0x10f8f1c: r0 = of()
    //     0x10f8f1c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x10f8f20: ldur            x1, [fp, #-0x18]
    // 0x10f8f24: stur            x0, [fp, #-0x18]
    // 0x10f8f28: r0 = of()
    //     0x10f8f28: bl              #0xdffc38  ; [package:flutter/src/material/tab_bar_theme.dart] TabBarTheme::of
    // 0x10f8f2c: ldur            x3, [fp, #-0x10]
    // 0x10f8f30: LoadField: r4 = r3->field_b
    //     0x10f8f30: ldur            w4, [x3, #0xb]
    // 0x10f8f34: DecompressPointer r4
    //     0x10f8f34: add             x4, x4, HEAP, lsl #32
    // 0x10f8f38: mov             x0, x4
    // 0x10f8f3c: stur            x4, [fp, #-0x20]
    // 0x10f8f40: r2 = Null
    //     0x10f8f40: mov             x2, NULL
    // 0x10f8f44: r1 = Null
    //     0x10f8f44: mov             x1, NULL
    // 0x10f8f48: r8 = Animation<double>
    //     0x10f8f48: add             x8, PP, #0x80, lsl #12  ; [pp+0x809a8] Type: Animation<double>
    //     0x10f8f4c: ldr             x8, [x8, #0x9a8]
    // 0x10f8f50: r3 = Null
    //     0x10f8f50: add             x3, PP, #0x95, lsl #12  ; [pp+0x95b30] Null
    //     0x10f8f54: ldr             x3, [x3, #0xb30]
    // 0x10f8f58: r0 = Animation<double>()
    //     0x10f8f58: bl              #0x829684  ; IsType_Animation<double>_Stub
    // 0x10f8f5c: r1 = 3
    //     0x10f8f5c: mov             x1, #3
    // 0x10f8f60: r0 = AllocateContext()
    //     0x10f8f60: bl              #0x13de838  ; AllocateContextStub
    // 0x10f8f64: mov             x2, x0
    // 0x10f8f68: ldur            x0, [fp, #-0x20]
    // 0x10f8f6c: stur            x2, [fp, #-0x28]
    // 0x10f8f70: StoreField: r2->field_f = r0
    //     0x10f8f70: stur            w0, [x2, #0xf]
    // 0x10f8f74: ldur            x0, [fp, #-0x10]
    // 0x10f8f78: LoadField: r1 = r0->field_1b
    //     0x10f8f78: ldur            w1, [x0, #0x1b]
    // 0x10f8f7c: DecompressPointer r1
    //     0x10f8f7c: add             x1, x1, HEAP, lsl #32
    // 0x10f8f80: cmp             w1, NULL
    // 0x10f8f84: b.ne            #0x10f8f8c
    // 0x10f8f88: r1 = Null
    //     0x10f8f88: mov             x1, NULL
    // 0x10f8f8c: cmp             w1, NULL
    // 0x10f8f90: b.ne            #0x10f8fb8
    // 0x10f8f94: LoadField: r1 = r0->field_f
    //     0x10f8f94: ldur            w1, [x0, #0xf]
    // 0x10f8f98: DecompressPointer r1
    //     0x10f8f98: add             x1, x1, HEAP, lsl #32
    // 0x10f8f9c: cmp             w1, NULL
    // 0x10f8fa0: b.ne            #0x10f8fac
    // 0x10f8fa4: r1 = Null
    //     0x10f8fa4: mov             x1, NULL
    // 0x10f8fa8: b               #0x10f8fb8
    // 0x10f8fac: LoadField: r3 = r1->field_b
    //     0x10f8fac: ldur            w3, [x1, #0xb]
    // 0x10f8fb0: DecompressPointer r3
    //     0x10f8fb0: add             x3, x3, HEAP, lsl #32
    // 0x10f8fb4: mov             x1, x3
    // 0x10f8fb8: cmp             w1, NULL
    // 0x10f8fbc: b.ne            #0x10f8fc4
    // 0x10f8fc0: r1 = Null
    //     0x10f8fc0: mov             x1, NULL
    // 0x10f8fc4: cmp             w1, NULL
    // 0x10f8fc8: b.ne            #0x10f9078
    // 0x10f8fcc: LoadField: r1 = r0->field_23
    //     0x10f8fcc: ldur            w1, [x0, #0x23]
    // 0x10f8fd0: DecompressPointer r1
    //     0x10f8fd0: add             x1, x1, HEAP, lsl #32
    // 0x10f8fd4: r3 = LoadClassIdInstr(r1)
    //     0x10f8fd4: ldur            x3, [x1, #-1]
    //     0x10f8fd8: ubfx            x3, x3, #0xc, #0x14
    // 0x10f8fdc: r17 = 5058
    //     0x10f8fdc: mov             x17, #0x13c2
    // 0x10f8fe0: cmp             x3, x17
    // 0x10f8fe4: b.ne            #0x10f8ff8
    // 0x10f8fe8: LoadField: r3 = r1->field_1b
    //     0x10f8fe8: ldur            w3, [x1, #0x1b]
    // 0x10f8fec: DecompressPointer r3
    //     0x10f8fec: add             x3, x3, HEAP, lsl #32
    // 0x10f8ff0: mov             x0, x3
    // 0x10f8ff4: b               #0x10f9074
    // 0x10f8ff8: r17 = 5059
    //     0x10f8ff8: mov             x17, #0x13c3
    // 0x10f8ffc: cmp             x3, x17
    // 0x10f9000: b.eq            #0x10f92ac
    // 0x10f9004: r17 = 5060
    //     0x10f9004: mov             x17, #0x13c4
    // 0x10f9008: cmp             x3, x17
    // 0x10f900c: b.ne            #0x10f9040
    // 0x10f9010: LoadField: r0 = r1->field_4f
    //     0x10f9010: ldur            w0, [x1, #0x4f]
    // 0x10f9014: DecompressPointer r0
    //     0x10f9014: add             x0, x0, HEAP, lsl #32
    // 0x10f9018: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10f901c: cmp             w0, w16
    // 0x10f9020: b.ne            #0x10f9030
    // 0x10f9024: r2 = _colors
    //     0x10f9024: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x10f9028: ldr             x2, [x2, #0xb0]
    // 0x10f902c: r0 = InitLateFinalInstanceField()
    //     0x10f902c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x10f9030: LoadField: r1 = r0->field_b
    //     0x10f9030: ldur            w1, [x0, #0xb]
    // 0x10f9034: DecompressPointer r1
    //     0x10f9034: add             x1, x1, HEAP, lsl #32
    // 0x10f9038: mov             x0, x1
    // 0x10f903c: b               #0x10f9074
    // 0x10f9040: LoadField: r0 = r1->field_4b
    //     0x10f9040: ldur            w0, [x1, #0x4b]
    // 0x10f9044: DecompressPointer r0
    //     0x10f9044: add             x0, x0, HEAP, lsl #32
    // 0x10f9048: mov             x1, x0
    // 0x10f904c: r0 = of()
    //     0x10f904c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x10f9050: LoadField: r1 = r0->field_83
    //     0x10f9050: ldur            w1, [x0, #0x83]
    // 0x10f9054: DecompressPointer r1
    //     0x10f9054: add             x1, x1, HEAP, lsl #32
    // 0x10f9058: LoadField: r0 = r1->field_2b
    //     0x10f9058: ldur            w0, [x1, #0x2b]
    // 0x10f905c: DecompressPointer r0
    //     0x10f905c: add             x0, x0, HEAP, lsl #32
    // 0x10f9060: LoadField: r1 = r0->field_b
    //     0x10f9060: ldur            w1, [x0, #0xb]
    // 0x10f9064: DecompressPointer r1
    //     0x10f9064: add             x1, x1, HEAP, lsl #32
    // 0x10f9068: cmp             w1, NULL
    // 0x10f906c: b.eq            #0x10f930c
    // 0x10f9070: mov             x0, x1
    // 0x10f9074: mov             x1, x0
    // 0x10f9078: ldur            x3, [fp, #-0x28]
    // 0x10f907c: mov             x0, x1
    // 0x10f9080: StoreField: r3->field_13 = r0
    //     0x10f9080: stur            w0, [x3, #0x13]
    //     0x10f9084: ldurb           w16, [x3, #-1]
    //     0x10f9088: ldurb           w17, [x0, #-1]
    //     0x10f908c: and             x16, x17, x16, lsr #2
    //     0x10f9090: tst             x16, HEAP, lsr #32
    //     0x10f9094: b.eq            #0x10f909c
    //     0x10f9098: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x10f909c: ArrayStore: r3[0] = rNULL  ; List_4
    //     0x10f909c: stur            NULL, [x3, #0x17]
    // 0x10f90a0: r0 = LoadClassIdInstr(r1)
    //     0x10f90a0: ldur            x0, [x1, #-1]
    //     0x10f90a4: ubfx            x0, x0, #0xc, #0x14
    // 0x10f90a8: cmp             x0, #0xece
    // 0x10f90ac: b.ne            #0x10f9114
    // 0x10f90b0: r2 = _ConstSet len:0
    //     0x10f90b0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26248] Set<WidgetState>(0)
    //     0x10f90b4: ldr             x2, [x2, #0x248]
    // 0x10f90b8: r0 = resolve()
    //     0x10f90b8: bl              #0x9fb584  ; [package:flutter/src/widgets/widget_state.dart] _WidgetStateColor::resolve
    // 0x10f90bc: ldur            x3, [fp, #-0x28]
    // 0x10f90c0: ArrayStore: r3[0] = r0  ; List_4
    //     0x10f90c0: stur            w0, [x3, #0x17]
    //     0x10f90c4: ldurb           w16, [x3, #-1]
    //     0x10f90c8: ldurb           w17, [x0, #-1]
    //     0x10f90cc: and             x16, x17, x16, lsr #2
    //     0x10f90d0: tst             x16, HEAP, lsr #32
    //     0x10f90d4: b.eq            #0x10f90dc
    //     0x10f90d8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x10f90dc: LoadField: r1 = r3->field_13
    //     0x10f90dc: ldur            w1, [x3, #0x13]
    // 0x10f90e0: DecompressPointer r1
    //     0x10f90e0: add             x1, x1, HEAP, lsl #32
    // 0x10f90e4: r2 = _ConstSet len:1
    //     0x10f90e4: add             x2, PP, #0x95, lsl #12  ; [pp+0x95b18] Set<WidgetState>(1)
    //     0x10f90e8: ldr             x2, [x2, #0xb18]
    // 0x10f90ec: r0 = resolve()
    //     0x10f90ec: bl              #0x9fb584  ; [package:flutter/src/widgets/widget_state.dart] _WidgetStateColor::resolve
    // 0x10f90f0: ldur            x2, [fp, #-0x28]
    // 0x10f90f4: StoreField: r2->field_13 = r0
    //     0x10f90f4: stur            w0, [x2, #0x13]
    //     0x10f90f8: ldurb           w16, [x2, #-1]
    //     0x10f90fc: ldurb           w17, [x0, #-1]
    //     0x10f9100: and             x16, x17, x16, lsr #2
    //     0x10f9104: tst             x16, HEAP, lsr #32
    //     0x10f9108: b.eq            #0x10f9110
    //     0x10f910c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x10f9110: b               #0x10f9278
    // 0x10f9114: ldur            x0, [fp, #-0x10]
    // 0x10f9118: mov             x2, x3
    // 0x10f911c: LoadField: r3 = r0->field_1f
    //     0x10f911c: ldur            w3, [x0, #0x1f]
    // 0x10f9120: DecompressPointer r3
    //     0x10f9120: add             x3, x3, HEAP, lsl #32
    // 0x10f9124: cmp             w3, NULL
    // 0x10f9128: b.ne            #0x10f9130
    // 0x10f912c: r3 = Null
    //     0x10f912c: mov             x3, NULL
    // 0x10f9130: cmp             w3, NULL
    // 0x10f9134: b.ne            #0x10f915c
    // 0x10f9138: LoadField: r3 = r0->field_13
    //     0x10f9138: ldur            w3, [x0, #0x13]
    // 0x10f913c: DecompressPointer r3
    //     0x10f913c: add             x3, x3, HEAP, lsl #32
    // 0x10f9140: cmp             w3, NULL
    // 0x10f9144: b.ne            #0x10f9150
    // 0x10f9148: r3 = Null
    //     0x10f9148: mov             x3, NULL
    // 0x10f914c: b               #0x10f915c
    // 0x10f9150: LoadField: r4 = r3->field_b
    //     0x10f9150: ldur            w4, [x3, #0xb]
    // 0x10f9154: DecompressPointer r4
    //     0x10f9154: add             x4, x4, HEAP, lsl #32
    // 0x10f9158: mov             x3, x4
    // 0x10f915c: cmp             w3, NULL
    // 0x10f9160: b.ne            #0x10f9168
    // 0x10f9164: r3 = Null
    //     0x10f9164: mov             x3, NULL
    // 0x10f9168: cmp             w3, NULL
    // 0x10f916c: b.ne            #0x10f9190
    // 0x10f9170: ldur            x3, [fp, #-8]
    // 0x10f9174: cmp             w3, NULL
    // 0x10f9178: b.ne            #0x10f9184
    // 0x10f917c: r3 = Null
    //     0x10f917c: mov             x3, NULL
    // 0x10f9180: b               #0x10f9190
    // 0x10f9184: LoadField: r4 = r3->field_1b
    //     0x10f9184: ldur            w4, [x3, #0x1b]
    // 0x10f9188: DecompressPointer r4
    //     0x10f9188: add             x4, x4, HEAP, lsl #32
    // 0x10f918c: mov             x3, x4
    // 0x10f9190: cmp             w3, NULL
    // 0x10f9194: b.ne            #0x10f9254
    // 0x10f9198: ldur            x3, [fp, #-0x18]
    // 0x10f919c: LoadField: r4 = r3->field_2f
    //     0x10f919c: ldur            w4, [x3, #0x2f]
    // 0x10f91a0: DecompressPointer r4
    //     0x10f91a0: add             x4, x4, HEAP, lsl #32
    // 0x10f91a4: tbnz            w4, #4, #0x10f9238
    // 0x10f91a8: LoadField: r1 = r0->field_23
    //     0x10f91a8: ldur            w1, [x0, #0x23]
    // 0x10f91ac: DecompressPointer r1
    //     0x10f91ac: add             x1, x1, HEAP, lsl #32
    // 0x10f91b0: r0 = LoadClassIdInstr(r1)
    //     0x10f91b0: ldur            x0, [x1, #-1]
    //     0x10f91b4: ubfx            x0, x0, #0xc, #0x14
    // 0x10f91b8: r17 = 5058
    //     0x10f91b8: mov             x17, #0x13c2
    // 0x10f91bc: cmp             x0, x17
    // 0x10f91c0: b.eq            #0x10f9224
    // 0x10f91c4: r17 = 5059
    //     0x10f91c4: mov             x17, #0x13c3
    // 0x10f91c8: cmp             x0, x17
    // 0x10f91cc: b.eq            #0x10f92d8
    // 0x10f91d0: r17 = 5060
    //     0x10f91d0: mov             x17, #0x13c4
    // 0x10f91d4: cmp             x0, x17
    // 0x10f91d8: b.ne            #0x10f9224
    // 0x10f91dc: LoadField: r0 = r1->field_4f
    //     0x10f91dc: ldur            w0, [x1, #0x4f]
    // 0x10f91e0: DecompressPointer r0
    //     0x10f91e0: add             x0, x0, HEAP, lsl #32
    // 0x10f91e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10f91e8: cmp             w0, w16
    // 0x10f91ec: b.ne            #0x10f91fc
    // 0x10f91f0: r2 = _colors
    //     0x10f91f0: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x10f91f4: ldr             x2, [x2, #0xb0]
    // 0x10f91f8: r0 = InitLateFinalInstanceField()
    //     0x10f91f8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x10f91fc: LoadField: r1 = r0->field_a3
    //     0x10f91fc: ldur            w1, [x0, #0xa3]
    // 0x10f9200: DecompressPointer r1
    //     0x10f9200: add             x1, x1, HEAP, lsl #32
    // 0x10f9204: cmp             w1, NULL
    // 0x10f9208: b.ne            #0x10f921c
    // 0x10f920c: LoadField: r1 = r0->field_7f
    //     0x10f920c: ldur            w1, [x0, #0x7f]
    // 0x10f9210: DecompressPointer r1
    //     0x10f9210: add             x1, x1, HEAP, lsl #32
    // 0x10f9214: mov             x0, x1
    // 0x10f9218: b               #0x10f922c
    // 0x10f921c: mov             x0, x1
    // 0x10f9220: b               #0x10f922c
    // 0x10f9224: LoadField: r0 = r1->field_27
    //     0x10f9224: ldur            w0, [x1, #0x27]
    // 0x10f9228: DecompressPointer r0
    //     0x10f9228: add             x0, x0, HEAP, lsl #32
    // 0x10f922c: cmp             w0, NULL
    // 0x10f9230: b.eq            #0x10f9310
    // 0x10f9234: b               #0x10f9258
    // 0x10f9238: r0 = LoadClassIdInstr(r1)
    //     0x10f9238: ldur            x0, [x1, #-1]
    //     0x10f923c: ubfx            x0, x0, #0xc, #0x14
    // 0x10f9240: r2 = 178
    //     0x10f9240: mov             x2, #0xb2
    // 0x10f9244: r0 = GDT[cid_x0 + -0xff4]()
    //     0x10f9244: sub             lr, x0, #0xff4
    //     0x10f9248: ldr             lr, [x21, lr, lsl #3]
    //     0x10f924c: blr             lr
    // 0x10f9250: b               #0x10f9258
    // 0x10f9254: mov             x0, x3
    // 0x10f9258: ldur            x2, [fp, #-0x28]
    // 0x10f925c: ArrayStore: r2[0] = r0  ; List_4
    //     0x10f925c: stur            w0, [x2, #0x17]
    //     0x10f9260: ldurb           w16, [x2, #-1]
    //     0x10f9264: ldurb           w17, [x0, #-1]
    //     0x10f9268: and             x16, x17, x16, lsr #2
    //     0x10f926c: tst             x16, HEAP, lsr #32
    //     0x10f9270: b.eq            #0x10f9278
    //     0x10f9274: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x10f9278: r0 = _WidgetStateColor()
    //     0x10f9278: bl              #0xd29244  ; Allocate_WidgetStateColorStub -> _WidgetStateColor (size=0x30)
    // 0x10f927c: ldur            x2, [fp, #-0x28]
    // 0x10f9280: r1 = Function '<anonymous closure>':.
    //     0x10f9280: add             x1, PP, #0x95, lsl #12  ; [pp+0x95b40] AnonymousClosure: (0x10f9314), in [package:flutter/src/material/tabs.dart] _TabStyle::_resolveWithLabelColor (0x10f8eb0)
    //     0x10f9284: ldr             x1, [x1, #0xb40]
    // 0x10f9288: stur            x0, [fp, #-8]
    // 0x10f928c: r0 = AllocateClosure()
    //     0x10f928c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10f9290: ldur            x1, [fp, #-8]
    // 0x10f9294: mov             x2, x0
    // 0x10f9298: r0 = _WidgetStateColor()
    //     0x10f9298: bl              #0xd29128  ; [package:flutter/src/widgets/widget_state.dart] _WidgetStateColor::_WidgetStateColor
    // 0x10f929c: ldur            x0, [fp, #-8]
    // 0x10f92a0: LeaveFrame
    //     0x10f92a0: mov             SP, fp
    //     0x10f92a4: ldp             fp, lr, [SP], #0x10
    // 0x10f92a8: ret
    //     0x10f92a8: ret             
    // 0x10f92ac: LoadField: r0 = r1->field_4f
    //     0x10f92ac: ldur            w0, [x1, #0x4f]
    // 0x10f92b0: DecompressPointer r0
    //     0x10f92b0: add             x0, x0, HEAP, lsl #32
    // 0x10f92b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10f92b8: cmp             w0, w16
    // 0x10f92bc: b.ne            #0x10f92cc
    // 0x10f92c0: r2 = _colors
    //     0x10f92c0: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x10f92c4: ldr             x2, [x2, #0xf0]
    // 0x10f92c8: r0 = InitLateFinalInstanceField()
    //     0x10f92c8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x10f92cc: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x10f92cc: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x10f92d0: r0 = Throw()
    //     0x10f92d0: bl              #0x13ddb2c  ; ThrowStub
    // 0x10f92d4: brk             #0
    // 0x10f92d8: LoadField: r0 = r1->field_4f
    //     0x10f92d8: ldur            w0, [x1, #0x4f]
    // 0x10f92dc: DecompressPointer r0
    //     0x10f92dc: add             x0, x0, HEAP, lsl #32
    // 0x10f92e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10f92e4: cmp             w0, w16
    // 0x10f92e8: b.ne            #0x10f92f8
    // 0x10f92ec: r2 = _colors
    //     0x10f92ec: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x10f92f0: ldr             x2, [x2, #0xf0]
    // 0x10f92f4: r0 = InitLateFinalInstanceField()
    //     0x10f92f4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x10f92f8: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x10f92f8: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x10f92fc: r0 = Throw()
    //     0x10f92fc: bl              #0x13ddb2c  ; ThrowStub
    // 0x10f9300: brk             #0
    // 0x10f9304: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f9304: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f9308: b               #0x10f8f18
    // 0x10f930c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10f930c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10f9310: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10f9310: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x10f9314, size: 0x114
    // 0x10f9314: EnterFrame
    //     0x10f9314: stp             fp, lr, [SP, #-0x10]!
    //     0x10f9318: mov             fp, SP
    // 0x10f931c: AllocStack(0x18)
    //     0x10f931c: sub             SP, SP, #0x18
    // 0x10f9320: SetupParameters([dynamic _ /* r0 */])
    //     0x10f9320: ldr             x0, [fp, #0x18]
    //     0x10f9324: ldur            w3, [x0, #0x17]
    //     0x10f9328: add             x3, x3, HEAP, lsl #32
    //     0x10f932c: stur            x3, [fp, #-8]
    // 0x10f9330: CheckStackOverflow
    //     0x10f9330: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f9334: cmp             SP, x16
    //     0x10f9338: b.ls            #0x10f9420
    // 0x10f933c: ldr             x1, [fp, #0x10]
    // 0x10f9340: r0 = LoadClassIdInstr(r1)
    //     0x10f9340: ldur            x0, [x1, #-1]
    //     0x10f9344: ubfx            x0, x0, #0xc, #0x14
    // 0x10f9348: r2 = Instance_WidgetState
    //     0x10f9348: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0x10f934c: ldr             x2, [x2, #0x100]
    // 0x10f9350: r0 = GDT[cid_x0 + 0x12929]()
    //     0x10f9350: mov             x17, #0x2929
    //     0x10f9354: movk            x17, #1, lsl #16
    //     0x10f9358: add             lr, x0, x17
    //     0x10f935c: ldr             lr, [x21, lr, lsl #3]
    //     0x10f9360: blr             lr
    // 0x10f9364: tbnz            w0, #4, #0x10f93c4
    // 0x10f9368: ldur            x0, [fp, #-8]
    // 0x10f936c: LoadField: r2 = r0->field_13
    //     0x10f936c: ldur            w2, [x0, #0x13]
    // 0x10f9370: DecompressPointer r2
    //     0x10f9370: add             x2, x2, HEAP, lsl #32
    // 0x10f9374: stur            x2, [fp, #-0x18]
    // 0x10f9378: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x10f9378: ldur            w3, [x0, #0x17]
    // 0x10f937c: DecompressPointer r3
    //     0x10f937c: add             x3, x3, HEAP, lsl #32
    // 0x10f9380: stur            x3, [fp, #-0x10]
    // 0x10f9384: LoadField: r1 = r0->field_f
    //     0x10f9384: ldur            w1, [x0, #0xf]
    // 0x10f9388: DecompressPointer r1
    //     0x10f9388: add             x1, x1, HEAP, lsl #32
    // 0x10f938c: r0 = LoadClassIdInstr(r1)
    //     0x10f938c: ldur            x0, [x1, #-1]
    //     0x10f9390: ubfx            x0, x0, #0xc, #0x14
    // 0x10f9394: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x10f9394: mov             x17, #0x4e2e
    //     0x10f9398: movk            x17, #1, lsl #16
    //     0x10f939c: add             lr, x0, x17
    //     0x10f93a0: ldr             lr, [x21, lr, lsl #3]
    //     0x10f93a4: blr             lr
    // 0x10f93a8: ldur            x1, [fp, #-0x18]
    // 0x10f93ac: ldur            x2, [fp, #-0x10]
    // 0x10f93b0: mov             x3, x0
    // 0x10f93b4: r0 = lerp()
    //     0x10f93b4: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x10f93b8: LeaveFrame
    //     0x10f93b8: mov             SP, fp
    //     0x10f93bc: ldp             fp, lr, [SP], #0x10
    // 0x10f93c0: ret
    //     0x10f93c0: ret             
    // 0x10f93c4: ldur            x0, [fp, #-8]
    // 0x10f93c8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x10f93c8: ldur            w2, [x0, #0x17]
    // 0x10f93cc: DecompressPointer r2
    //     0x10f93cc: add             x2, x2, HEAP, lsl #32
    // 0x10f93d0: stur            x2, [fp, #-0x18]
    // 0x10f93d4: LoadField: r3 = r0->field_13
    //     0x10f93d4: ldur            w3, [x0, #0x13]
    // 0x10f93d8: DecompressPointer r3
    //     0x10f93d8: add             x3, x3, HEAP, lsl #32
    // 0x10f93dc: stur            x3, [fp, #-0x10]
    // 0x10f93e0: LoadField: r1 = r0->field_f
    //     0x10f93e0: ldur            w1, [x0, #0xf]
    // 0x10f93e4: DecompressPointer r1
    //     0x10f93e4: add             x1, x1, HEAP, lsl #32
    // 0x10f93e8: r0 = LoadClassIdInstr(r1)
    //     0x10f93e8: ldur            x0, [x1, #-1]
    //     0x10f93ec: ubfx            x0, x0, #0xc, #0x14
    // 0x10f93f0: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x10f93f0: mov             x17, #0x4e2e
    //     0x10f93f4: movk            x17, #1, lsl #16
    //     0x10f93f8: add             lr, x0, x17
    //     0x10f93fc: ldr             lr, [x21, lr, lsl #3]
    //     0x10f9400: blr             lr
    // 0x10f9404: ldur            x1, [fp, #-0x18]
    // 0x10f9408: ldur            x2, [fp, #-0x10]
    // 0x10f940c: mov             x3, x0
    // 0x10f9410: r0 = lerp()
    //     0x10f9410: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x10f9414: LeaveFrame
    //     0x10f9414: mov             SP, fp
    //     0x10f9418: ldp             fp, lr, [SP], #0x10
    // 0x10f941c: ret
    //     0x10f941c: ret             
    // 0x10f9420: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f9420: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f9424: b               #0x10f933c
  }
}

// class id: 6696, size: 0x3c, field offset: 0x38
//   const constructor, 
class _TabLabelBar extends Flex {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcee488, size: 0xbc
    // 0xcee488: EnterFrame
    //     0xcee488: stp             fp, lr, [SP, #-0x10]!
    //     0xcee48c: mov             fp, SP
    // 0xcee490: AllocStack(0x18)
    //     0xcee490: sub             SP, SP, #0x18
    // 0xcee494: SetupParameters(_TabLabelBar this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xcee494: mov             x5, x1
    //     0xcee498: mov             x4, x2
    //     0xcee49c: stur            x1, [fp, #-8]
    //     0xcee4a0: stur            x2, [fp, #-0x10]
    //     0xcee4a4: stur            x3, [fp, #-0x18]
    // 0xcee4a8: CheckStackOverflow
    //     0xcee4a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcee4ac: cmp             SP, x16
    //     0xcee4b0: b.ls            #0xcee53c
    // 0xcee4b4: mov             x0, x3
    // 0xcee4b8: r2 = Null
    //     0xcee4b8: mov             x2, NULL
    // 0xcee4bc: r1 = Null
    //     0xcee4bc: mov             x1, NULL
    // 0xcee4c0: r4 = 60
    //     0xcee4c0: mov             x4, #0x3c
    // 0xcee4c4: branchIfSmi(r0, 0xcee4d0)
    //     0xcee4c4: tbz             w0, #0, #0xcee4d0
    // 0xcee4c8: r4 = LoadClassIdInstr(r0)
    //     0xcee4c8: ldur            x4, [x0, #-1]
    //     0xcee4cc: ubfx            x4, x4, #0xc, #0x14
    // 0xcee4d0: r17 = 4862
    //     0xcee4d0: mov             x17, #0x12fe
    // 0xcee4d4: cmp             x4, x17
    // 0xcee4d8: b.eq            #0xcee4f0
    // 0xcee4dc: r8 = _TabLabelBarRenderer
    //     0xcee4dc: add             x8, PP, #0x95, lsl #12  ; [pp+0x95ac8] Type: _TabLabelBarRenderer
    //     0xcee4e0: ldr             x8, [x8, #0xac8]
    // 0xcee4e4: r3 = Null
    //     0xcee4e4: add             x3, PP, #0x95, lsl #12  ; [pp+0x95ad0] Null
    //     0xcee4e8: ldr             x3, [x3, #0xad0]
    // 0xcee4ec: r0 = DefaultTypeTest()
    //     0xcee4ec: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcee4f0: ldur            x1, [fp, #-8]
    // 0xcee4f4: ldur            x2, [fp, #-0x10]
    // 0xcee4f8: ldur            x3, [fp, #-0x18]
    // 0xcee4fc: r0 = updateRenderObject()
    //     0xcee4fc: bl              #0xcee544  ; [package:flutter/src/widgets/basic.dart] Flex::updateRenderObject
    // 0xcee500: ldur            x1, [fp, #-8]
    // 0xcee504: LoadField: r0 = r1->field_37
    //     0xcee504: ldur            w0, [x1, #0x37]
    // 0xcee508: DecompressPointer r0
    //     0xcee508: add             x0, x0, HEAP, lsl #32
    // 0xcee50c: ldur            x1, [fp, #-0x18]
    // 0xcee510: StoreField: r1->field_97 = r0
    //     0xcee510: stur            w0, [x1, #0x97]
    //     0xcee514: ldurb           w16, [x1, #-1]
    //     0xcee518: ldurb           w17, [x0, #-1]
    //     0xcee51c: and             x16, x17, x16, lsr #2
    //     0xcee520: tst             x16, HEAP, lsr #32
    //     0xcee524: b.eq            #0xcee52c
    //     0xcee528: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcee52c: r0 = Null
    //     0xcee52c: mov             x0, NULL
    // 0xcee530: LeaveFrame
    //     0xcee530: mov             SP, fp
    //     0xcee534: ldp             fp, lr, [SP], #0x10
    // 0xcee538: ret
    //     0xcee538: ret             
    // 0xcee53c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee53c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee540: b               #0xcee4b4
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11ca128, size: 0xe0
    // 0x11ca128: EnterFrame
    //     0x11ca128: stp             fp, lr, [SP, #-0x10]!
    //     0x11ca12c: mov             fp, SP
    // 0x11ca130: AllocStack(0x58)
    //     0x11ca130: sub             SP, SP, #0x58
    // 0x11ca134: SetupParameters(_TabLabelBar this /* r1 => r0, fp-0x28 */)
    //     0x11ca134: mov             x0, x1
    //     0x11ca138: stur            x1, [fp, #-0x28]
    // 0x11ca13c: CheckStackOverflow
    //     0x11ca13c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ca140: cmp             SP, x16
    //     0x11ca144: b.ls            #0x11ca1fc
    // 0x11ca148: LoadField: r3 = r0->field_f
    //     0x11ca148: ldur            w3, [x0, #0xf]
    // 0x11ca14c: DecompressPointer r3
    //     0x11ca14c: add             x3, x3, HEAP, lsl #32
    // 0x11ca150: stur            x3, [fp, #-0x20]
    // 0x11ca154: LoadField: r4 = r0->field_13
    //     0x11ca154: ldur            w4, [x0, #0x13]
    // 0x11ca158: DecompressPointer r4
    //     0x11ca158: add             x4, x4, HEAP, lsl #32
    // 0x11ca15c: stur            x4, [fp, #-0x18]
    // 0x11ca160: ArrayLoad: r5 = r0[0]  ; List_4
    //     0x11ca160: ldur            w5, [x0, #0x17]
    // 0x11ca164: DecompressPointer r5
    //     0x11ca164: add             x5, x5, HEAP, lsl #32
    // 0x11ca168: stur            x5, [fp, #-0x10]
    // 0x11ca16c: LoadField: r6 = r0->field_1b
    //     0x11ca16c: ldur            w6, [x0, #0x1b]
    // 0x11ca170: DecompressPointer r6
    //     0x11ca170: add             x6, x6, HEAP, lsl #32
    // 0x11ca174: mov             x1, x0
    // 0x11ca178: stur            x6, [fp, #-8]
    // 0x11ca17c: r0 = getEffectiveTextDirection()
    //     0x11ca17c: bl              #0xcee788  ; [package:flutter/src/widgets/basic.dart] Flex::getEffectiveTextDirection
    // 0x11ca180: stur            x0, [fp, #-0x40]
    // 0x11ca184: cmp             w0, NULL
    // 0x11ca188: b.eq            #0x11ca204
    // 0x11ca18c: ldur            x1, [fp, #-0x28]
    // 0x11ca190: LoadField: r2 = r1->field_23
    //     0x11ca190: ldur            w2, [x1, #0x23]
    // 0x11ca194: DecompressPointer r2
    //     0x11ca194: add             x2, x2, HEAP, lsl #32
    // 0x11ca198: stur            x2, [fp, #-0x38]
    // 0x11ca19c: LoadField: r3 = r1->field_37
    //     0x11ca19c: ldur            w3, [x1, #0x37]
    // 0x11ca1a0: DecompressPointer r3
    //     0x11ca1a0: add             x3, x3, HEAP, lsl #32
    // 0x11ca1a4: stur            x3, [fp, #-0x30]
    // 0x11ca1a8: r0 = _TabLabelBarRenderer()
    //     0x11ca1a8: bl              #0x11ca208  ; Allocate_TabLabelBarRendererStub -> _TabLabelBarRenderer (size=0x9c)
    // 0x11ca1ac: mov             x4, x0
    // 0x11ca1b0: ldur            x0, [fp, #-0x30]
    // 0x11ca1b4: stur            x4, [fp, #-0x28]
    // 0x11ca1b8: StoreField: r4->field_97 = r0
    //     0x11ca1b8: stur            w0, [x4, #0x97]
    // 0x11ca1bc: ldur            x16, [fp, #-0x18]
    // 0x11ca1c0: ldur            lr, [fp, #-0x40]
    // 0x11ca1c4: stp             lr, x16, [SP, #8]
    // 0x11ca1c8: ldur            x16, [fp, #-0x38]
    // 0x11ca1cc: str             x16, [SP]
    // 0x11ca1d0: mov             x1, x4
    // 0x11ca1d4: ldur            x2, [fp, #-8]
    // 0x11ca1d8: ldur            x3, [fp, #-0x20]
    // 0x11ca1dc: ldur            x5, [fp, #-0x10]
    // 0x11ca1e0: r4 = const [0, 0x7, 0x3, 0x4, mainAxisAlignment, 0x4, textDirection, 0x5, verticalDirection, 0x6, null]
    //     0x11ca1e0: add             x4, PP, #0x95, lsl #12  ; [pp+0x95ae0] List(11) [0, 0x7, 0x3, 0x4, "mainAxisAlignment", 0x4, "textDirection", 0x5, "verticalDirection", 0x6, Null]
    //     0x11ca1e4: ldr             x4, [x4, #0xae0]
    // 0x11ca1e8: r0 = RenderFlex()
    //     0x11ca1e8: bl              #0x11c9c4c  ; [package:flutter/src/rendering/flex.dart] RenderFlex::RenderFlex
    // 0x11ca1ec: ldur            x0, [fp, #-0x28]
    // 0x11ca1f0: LeaveFrame
    //     0x11ca1f0: mov             SP, fp
    //     0x11ca1f4: ldp             fp, lr, [SP], #0x10
    // 0x11ca1f8: ret
    //     0x11ca1f8: ret             
    // 0x11ca1fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ca1fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ca200: b               #0x11ca148
    // 0x11ca204: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11ca204: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 8257, size: 0x14, field offset: 0x14
enum TabIndicatorAnimation extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aaabc, size: 0x64
    // 0x11aaabc: EnterFrame
    //     0x11aaabc: stp             fp, lr, [SP, #-0x10]!
    //     0x11aaac0: mov             fp, SP
    // 0x11aaac4: AllocStack(0x10)
    //     0x11aaac4: sub             SP, SP, #0x10
    // 0x11aaac8: SetupParameters(TabIndicatorAnimation this /* r1 => r0, fp-0x8 */)
    //     0x11aaac8: mov             x0, x1
    //     0x11aaacc: stur            x1, [fp, #-8]
    // 0x11aaad0: CheckStackOverflow
    //     0x11aaad0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aaad4: cmp             SP, x16
    //     0x11aaad8: b.ls            #0x11aab18
    // 0x11aaadc: r1 = Null
    //     0x11aaadc: mov             x1, NULL
    // 0x11aaae0: r2 = 4
    //     0x11aaae0: mov             x2, #4
    // 0x11aaae4: r0 = AllocateArray()
    //     0x11aaae4: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aaae8: r16 = "TabIndicatorAnimation."
    //     0x11aaae8: add             x16, PP, #0x95, lsl #12  ; [pp+0x95ae8] "TabIndicatorAnimation."
    //     0x11aaaec: ldr             x16, [x16, #0xae8]
    // 0x11aaaf0: StoreField: r0->field_f = r16
    //     0x11aaaf0: stur            w16, [x0, #0xf]
    // 0x11aaaf4: ldur            x1, [fp, #-8]
    // 0x11aaaf8: LoadField: r2 = r1->field_f
    //     0x11aaaf8: ldur            w2, [x1, #0xf]
    // 0x11aaafc: DecompressPointer r2
    //     0x11aaafc: add             x2, x2, HEAP, lsl #32
    // 0x11aab00: StoreField: r0->field_13 = r2
    //     0x11aab00: stur            w2, [x0, #0x13]
    // 0x11aab04: str             x0, [SP]
    // 0x11aab08: r0 = _interpolate()
    //     0x11aab08: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aab0c: LeaveFrame
    //     0x11aab0c: mov             SP, fp
    //     0x11aab10: ldp             fp, lr, [SP], #0x10
    // 0x11aab14: ret
    //     0x11aab14: ret             
    // 0x11aab18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aab18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aab1c: b               #0x11aaadc
  }
}

// class id: 8258, size: 0x14, field offset: 0x14
enum TabAlignment extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aaa58, size: 0x64
    // 0x11aaa58: EnterFrame
    //     0x11aaa58: stp             fp, lr, [SP, #-0x10]!
    //     0x11aaa5c: mov             fp, SP
    // 0x11aaa60: AllocStack(0x10)
    //     0x11aaa60: sub             SP, SP, #0x10
    // 0x11aaa64: SetupParameters(TabAlignment this /* r1 => r0, fp-0x8 */)
    //     0x11aaa64: mov             x0, x1
    //     0x11aaa68: stur            x1, [fp, #-8]
    // 0x11aaa6c: CheckStackOverflow
    //     0x11aaa6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aaa70: cmp             SP, x16
    //     0x11aaa74: b.ls            #0x11aaab4
    // 0x11aaa78: r1 = Null
    //     0x11aaa78: mov             x1, NULL
    // 0x11aaa7c: r2 = 4
    //     0x11aaa7c: mov             x2, #4
    // 0x11aaa80: r0 = AllocateArray()
    //     0x11aaa80: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aaa84: r16 = "TabAlignment."
    //     0x11aaa84: add             x16, PP, #0x80, lsl #12  ; [pp+0x808e0] "TabAlignment."
    //     0x11aaa88: ldr             x16, [x16, #0x8e0]
    // 0x11aaa8c: StoreField: r0->field_f = r16
    //     0x11aaa8c: stur            w16, [x0, #0xf]
    // 0x11aaa90: ldur            x1, [fp, #-8]
    // 0x11aaa94: LoadField: r2 = r1->field_f
    //     0x11aaa94: ldur            w2, [x1, #0xf]
    // 0x11aaa98: DecompressPointer r2
    //     0x11aaa98: add             x2, x2, HEAP, lsl #32
    // 0x11aaa9c: StoreField: r0->field_13 = r2
    //     0x11aaa9c: stur            w2, [x0, #0x13]
    // 0x11aaaa0: str             x0, [SP]
    // 0x11aaaa4: r0 = _interpolate()
    //     0x11aaaa4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aaaa8: LeaveFrame
    //     0x11aaaa8: mov             SP, fp
    //     0x11aaaac: ldp             fp, lr, [SP], #0x10
    // 0x11aaab0: ret
    //     0x11aaab0: ret             
    // 0x11aaab4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aaab4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aaab8: b               #0x11aaa78
  }
}

// class id: 8259, size: 0x14, field offset: 0x14
enum TabBarIndicatorSize extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa9f4, size: 0x64
    // 0x11aa9f4: EnterFrame
    //     0x11aa9f4: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa9f8: mov             fp, SP
    // 0x11aa9fc: AllocStack(0x10)
    //     0x11aa9fc: sub             SP, SP, #0x10
    // 0x11aaa00: SetupParameters(TabBarIndicatorSize this /* r1 => r0, fp-0x8 */)
    //     0x11aaa00: mov             x0, x1
    //     0x11aaa04: stur            x1, [fp, #-8]
    // 0x11aaa08: CheckStackOverflow
    //     0x11aaa08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aaa0c: cmp             SP, x16
    //     0x11aaa10: b.ls            #0x11aaa50
    // 0x11aaa14: r1 = Null
    //     0x11aaa14: mov             x1, NULL
    // 0x11aaa18: r2 = 4
    //     0x11aaa18: mov             x2, #4
    // 0x11aaa1c: r0 = AllocateArray()
    //     0x11aaa1c: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aaa20: r16 = "TabBarIndicatorSize."
    //     0x11aaa20: add             x16, PP, #0x80, lsl #12  ; [pp+0x808d8] "TabBarIndicatorSize."
    //     0x11aaa24: ldr             x16, [x16, #0x8d8]
    // 0x11aaa28: StoreField: r0->field_f = r16
    //     0x11aaa28: stur            w16, [x0, #0xf]
    // 0x11aaa2c: ldur            x1, [fp, #-8]
    // 0x11aaa30: LoadField: r2 = r1->field_f
    //     0x11aaa30: ldur            w2, [x1, #0xf]
    // 0x11aaa34: DecompressPointer r2
    //     0x11aaa34: add             x2, x2, HEAP, lsl #32
    // 0x11aaa38: StoreField: r0->field_13 = r2
    //     0x11aaa38: stur            w2, [x0, #0x13]
    // 0x11aaa3c: str             x0, [SP]
    // 0x11aaa40: r0 = _interpolate()
    //     0x11aaa40: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aaa44: LeaveFrame
    //     0x11aaa44: mov             SP, fp
    //     0x11aaa48: ldp             fp, lr, [SP], #0x10
    // 0x11aaa4c: ret
    //     0x11aaa4c: ret             
    // 0x11aaa50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aaa50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aaa54: b               #0x11aaa14
  }
}
