// lib: , url: package:flutter/src/material/popup_menu_theme.dart

// class id: 1048929, size: 0x8
class :: {
}

// class id: 5129, size: 0x3c, field offset: 0x8
//   const constructor, 
class PopupMenuThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x1135108, size: 0x314
    // 0x1135108: EnterFrame
    //     0x1135108: stp             fp, lr, [SP, #-0x10]!
    //     0x113510c: mov             fp, SP
    // 0x1135110: AllocStack(0x98)
    //     0x1135110: sub             SP, SP, #0x98
    // 0x1135114: CheckStackOverflow
    //     0x1135114: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1135118: cmp             SP, x16
    //     0x113511c: b.ls            #0x1135414
    // 0x1135120: ldr             x0, [fp, #0x10]
    // 0x1135124: r2 = LoadClassIdInstr(r0)
    //     0x1135124: ldur            x2, [x0, #-1]
    //     0x1135128: ubfx            x2, x2, #0xc, #0x14
    // 0x113512c: stur            x2, [fp, #-8]
    // 0x1135130: r17 = 5129
    //     0x1135130: mov             x17, #0x1409
    // 0x1135134: cmp             x2, x17
    // 0x1135138: b.eq            #0x11351a0
    // 0x113513c: r17 = 5130
    //     0x113513c: mov             x17, #0x140a
    // 0x1135140: cmp             x2, x17
    // 0x1135144: b.ne            #0x113519c
    // 0x1135148: mov             x1, x0
    // 0x113514c: LoadField: r0 = r1->field_43
    //     0x113514c: ldur            w0, [x1, #0x43]
    // 0x1135150: DecompressPointer r0
    //     0x1135150: add             x0, x0, HEAP, lsl #32
    // 0x1135154: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1135158: cmp             w0, w16
    // 0x113515c: b.ne            #0x113516c
    // 0x1135160: r2 = _colors
    //     0x1135160: add             x2, PP, #0x26, lsl #12  ; [pp+0x262d0] Field <_PopupMenuDefaultsM3@113182389._colors@113182389>: late final (offset: 0x44)
    //     0x1135164: ldr             x2, [x2, #0x2d0]
    // 0x1135168: r0 = InitLateFinalInstanceField()
    //     0x1135168: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113516c: LoadField: r1 = r0->field_97
    //     0x113516c: ldur            w1, [x0, #0x97]
    // 0x1135170: DecompressPointer r1
    //     0x1135170: add             x1, x1, HEAP, lsl #32
    // 0x1135174: cmp             w1, NULL
    // 0x1135178: b.ne            #0x113518c
    // 0x113517c: LoadField: r1 = r0->field_7b
    //     0x113517c: ldur            w1, [x0, #0x7b]
    // 0x1135180: DecompressPointer r1
    //     0x1135180: add             x1, x1, HEAP, lsl #32
    // 0x1135184: mov             x0, x1
    // 0x1135188: b               #0x1135190
    // 0x113518c: mov             x0, x1
    // 0x1135190: mov             x3, x0
    // 0x1135194: ldr             x0, [fp, #0x10]
    // 0x1135198: b               #0x11351ac
    // 0x113519c: ldr             x0, [fp, #0x10]
    // 0x11351a0: LoadField: r1 = r0->field_7
    //     0x11351a0: ldur            w1, [x0, #7]
    // 0x11351a4: DecompressPointer r1
    //     0x11351a4: add             x1, x1, HEAP, lsl #32
    // 0x11351a8: mov             x3, x1
    // 0x11351ac: ldur            x2, [fp, #-8]
    // 0x11351b0: stur            x3, [fp, #-0x28]
    // 0x11351b4: r17 = 5129
    //     0x11351b4: mov             x17, #0x1409
    // 0x11351b8: cmp             x2, x17
    // 0x11351bc: b.eq            #0x11351d8
    // 0x11351c0: r17 = 5130
    //     0x11351c0: mov             x17, #0x140a
    // 0x11351c4: cmp             x2, x17
    // 0x11351c8: b.ne            #0x11351d8
    // 0x11351cc: r4 = Instance_RoundedRectangleBorder
    //     0x11351cc: add             x4, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0x11351d0: ldr             x4, [x4, #0x218]
    // 0x11351d4: b               #0x11351e4
    // 0x11351d8: LoadField: r1 = r0->field_b
    //     0x11351d8: ldur            w1, [x0, #0xb]
    // 0x11351dc: DecompressPointer r1
    //     0x11351dc: add             x1, x1, HEAP, lsl #32
    // 0x11351e0: mov             x4, x1
    // 0x11351e4: stur            x4, [fp, #-0x20]
    // 0x11351e8: r17 = 5129
    //     0x11351e8: mov             x17, #0x1409
    // 0x11351ec: cmp             x2, x17
    // 0x11351f0: b.ne            #0x1135204
    // 0x11351f4: LoadField: r1 = r0->field_f
    //     0x11351f4: ldur            w1, [x0, #0xf]
    // 0x11351f8: DecompressPointer r1
    //     0x11351f8: add             x1, x1, HEAP, lsl #32
    // 0x11351fc: mov             x5, x1
    // 0x1135200: b               #0x1135224
    // 0x1135204: r17 = 5130
    //     0x1135204: mov             x17, #0x140a
    // 0x1135208: cmp             x2, x17
    // 0x113520c: b.ne            #0x113521c
    // 0x1135210: r5 = Instance_EdgeInsets
    //     0x1135210: add             x5, PP, #0x26, lsl #12  ; [pp+0x262d8] Obj!EdgeInsets@129d5f1
    //     0x1135214: ldr             x5, [x5, #0x2d8]
    // 0x1135218: b               #0x1135224
    // 0x113521c: r5 = Instance_EdgeInsets
    //     0x113521c: add             x5, PP, #0x26, lsl #12  ; [pp+0x262d8] Obj!EdgeInsets@129d5f1
    //     0x1135220: ldr             x5, [x5, #0x2d8]
    // 0x1135224: stur            x5, [fp, #-0x18]
    // 0x1135228: LoadField: r6 = r0->field_13
    //     0x1135228: ldur            w6, [x0, #0x13]
    // 0x113522c: DecompressPointer r6
    //     0x113522c: add             x6, x6, HEAP, lsl #32
    // 0x1135230: stur            x6, [fp, #-0x10]
    // 0x1135234: r17 = 5129
    //     0x1135234: mov             x17, #0x1409
    // 0x1135238: cmp             x2, x17
    // 0x113523c: b.eq            #0x11352a0
    // 0x1135240: r17 = 5130
    //     0x1135240: mov             x17, #0x140a
    // 0x1135244: cmp             x2, x17
    // 0x1135248: b.ne            #0x113529c
    // 0x113524c: mov             x1, x0
    // 0x1135250: LoadField: r0 = r1->field_43
    //     0x1135250: ldur            w0, [x1, #0x43]
    // 0x1135254: DecompressPointer r0
    //     0x1135254: add             x0, x0, HEAP, lsl #32
    // 0x1135258: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x113525c: cmp             w0, w16
    // 0x1135260: b.ne            #0x1135270
    // 0x1135264: r2 = _colors
    //     0x1135264: add             x2, PP, #0x26, lsl #12  ; [pp+0x262d0] Field <_PopupMenuDefaultsM3@113182389._colors@113182389>: late final (offset: 0x44)
    //     0x1135268: ldr             x2, [x2, #0x2d0]
    // 0x113526c: r0 = InitLateFinalInstanceField()
    //     0x113526c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1135270: LoadField: r1 = r0->field_af
    //     0x1135270: ldur            w1, [x0, #0xaf]
    // 0x1135274: DecompressPointer r1
    //     0x1135274: add             x1, x1, HEAP, lsl #32
    // 0x1135278: cmp             w1, NULL
    // 0x113527c: b.ne            #0x113528c
    // 0x1135280: r0 = Instance_Color
    //     0x1135280: add             x0, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x1135284: ldr             x0, [x0, #0x948]
    // 0x1135288: b               #0x1135290
    // 0x113528c: mov             x0, x1
    // 0x1135290: mov             x3, x0
    // 0x1135294: ldr             x0, [fp, #0x10]
    // 0x1135298: b               #0x11352ac
    // 0x113529c: ldr             x0, [fp, #0x10]
    // 0x11352a0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11352a0: ldur            w1, [x0, #0x17]
    // 0x11352a4: DecompressPointer r1
    //     0x11352a4: add             x1, x1, HEAP, lsl #32
    // 0x11352a8: mov             x3, x1
    // 0x11352ac: ldur            x2, [fp, #-8]
    // 0x11352b0: stur            x3, [fp, #-0x38]
    // 0x11352b4: r17 = 5129
    //     0x11352b4: mov             x17, #0x1409
    // 0x11352b8: cmp             x2, x17
    // 0x11352bc: b.eq            #0x11352d8
    // 0x11352c0: r17 = 5130
    //     0x11352c0: mov             x17, #0x140a
    // 0x11352c4: cmp             x2, x17
    // 0x11352c8: b.ne            #0x11352d8
    // 0x11352cc: r4 = Instance_Color
    //     0x11352cc: add             x4, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x11352d0: ldr             x4, [x4, #0x810]
    // 0x11352d4: b               #0x11352e4
    // 0x11352d8: LoadField: r1 = r0->field_1b
    //     0x11352d8: ldur            w1, [x0, #0x1b]
    // 0x11352dc: DecompressPointer r1
    //     0x11352dc: add             x1, x1, HEAP, lsl #32
    // 0x11352e0: mov             x4, x1
    // 0x11352e4: stur            x4, [fp, #-0x30]
    // 0x11352e8: r17 = -5129
    //     0x11352e8: mov             x17, #-0x1409
    // 0x11352ec: add             x16, x2, x17
    // 0x11352f0: cmp             x16, #1
    // 0x11352f4: b.hi            #0x1135308
    // 0x11352f8: LoadField: r1 = r0->field_1f
    //     0x11352f8: ldur            w1, [x0, #0x1f]
    // 0x11352fc: DecompressPointer r1
    //     0x11352fc: add             x1, x1, HEAP, lsl #32
    // 0x1135300: mov             x0, x2
    // 0x1135304: b               #0x1135338
    // 0x1135308: mov             x1, x0
    // 0x113530c: LoadField: r0 = r1->field_43
    //     0x113530c: ldur            w0, [x1, #0x43]
    // 0x1135310: DecompressPointer r0
    //     0x1135310: add             x0, x0, HEAP, lsl #32
    // 0x1135314: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1135318: cmp             w0, w16
    // 0x113531c: b.ne            #0x113532c
    // 0x1135320: r2 = _textTheme
    //     0x1135320: add             x2, PP, #0x26, lsl #12  ; [pp+0x262e0] Field <_PopupMenuDefaultsM2@113182389._textTheme@113182389>: late final (offset: 0x44)
    //     0x1135324: ldr             x2, [x2, #0x2e0]
    // 0x1135328: r0 = InitLateFinalInstanceField()
    //     0x1135328: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113532c: LoadField: r1 = r0->field_23
    //     0x113532c: ldur            w1, [x0, #0x23]
    // 0x1135330: DecompressPointer r1
    //     0x1135330: add             x1, x1, HEAP, lsl #32
    // 0x1135334: ldur            x0, [fp, #-8]
    // 0x1135338: stur            x1, [fp, #-0x40]
    // 0x113533c: r17 = 5129
    //     0x113533c: mov             x17, #0x1409
    // 0x1135340: cmp             x0, x17
    // 0x1135344: b.eq            #0x113539c
    // 0x1135348: r17 = 5130
    //     0x1135348: mov             x17, #0x140a
    // 0x113534c: cmp             x0, x17
    // 0x1135350: b.ne            #0x113539c
    // 0x1135354: ldr             x0, [fp, #0x10]
    // 0x1135358: r1 = 1
    //     0x1135358: mov             x1, #1
    // 0x113535c: r0 = AllocateContext()
    //     0x113535c: bl              #0x13de838  ; AllocateContextStub
    // 0x1135360: mov             x1, x0
    // 0x1135364: ldr             x0, [fp, #0x10]
    // 0x1135368: StoreField: r1->field_f = r0
    //     0x1135368: stur            w0, [x1, #0xf]
    // 0x113536c: mov             x2, x1
    // 0x1135370: r1 = Function '<anonymous closure>':.
    //     0x1135370: add             x1, PP, #0x26, lsl #12  ; [pp+0x262e8] AnonymousClosure: (0xdf87d8), of [package:flutter/src/material/popup_menu.dart] _PopupMenuDefaultsM3
    //     0x1135374: ldr             x1, [x1, #0x2e8]
    // 0x1135378: r0 = AllocateClosure()
    //     0x1135378: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x113537c: r16 = <TextStyle?>
    //     0x113537c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a88] TypeArguments: <TextStyle?>
    //     0x1135380: ldr             x16, [x16, #0xa88]
    // 0x1135384: stp             x0, x16, [SP]
    // 0x1135388: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1135388: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x113538c: r0 = resolveWith()
    //     0x113538c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1135390: mov             x1, x0
    // 0x1135394: ldr             x0, [fp, #0x10]
    // 0x1135398: b               #0x11353a8
    // 0x113539c: ldr             x0, [fp, #0x10]
    // 0x11353a0: LoadField: r1 = r0->field_23
    //     0x11353a0: ldur            w1, [x0, #0x23]
    // 0x11353a4: DecompressPointer r1
    //     0x11353a4: add             x1, x1, HEAP, lsl #32
    // 0x11353a8: LoadField: r2 = r0->field_37
    //     0x11353a8: ldur            w2, [x0, #0x37]
    // 0x11353ac: DecompressPointer r2
    //     0x11353ac: add             x2, x2, HEAP, lsl #32
    // 0x11353b0: ldur            x16, [fp, #-0x18]
    // 0x11353b4: ldur            lr, [fp, #-0x10]
    // 0x11353b8: stp             lr, x16, [SP, #0x48]
    // 0x11353bc: ldur            x16, [fp, #-0x38]
    // 0x11353c0: ldur            lr, [fp, #-0x30]
    // 0x11353c4: stp             lr, x16, [SP, #0x38]
    // 0x11353c8: ldur            x16, [fp, #-0x40]
    // 0x11353cc: stp             x1, x16, [SP, #0x28]
    // 0x11353d0: stp             NULL, NULL, [SP, #0x18]
    // 0x11353d4: stp             NULL, NULL, [SP, #8]
    // 0x11353d8: str             x2, [SP]
    // 0x11353dc: ldur            x1, [fp, #-0x28]
    // 0x11353e0: ldur            x2, [fp, #-0x20]
    // 0x11353e4: r4 = const [0, 0xd, 0xb, 0xd, null]
    //     0x11353e4: add             x4, PP, #0x26, lsl #12  ; [pp+0x26260] List(5) [0, 0xd, 0xb, 0xd, Null]
    //     0x11353e8: ldr             x4, [x4, #0x260]
    // 0x11353ec: r0 = hash()
    //     0x11353ec: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x11353f0: mov             x2, x0
    // 0x11353f4: r0 = BoxInt64Instr(r2)
    //     0x11353f4: sbfiz           x0, x2, #1, #0x1f
    //     0x11353f8: cmp             x2, x0, asr #1
    //     0x11353fc: b.eq            #0x1135408
    //     0x1135400: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1135404: stur            x2, [x0, #7]
    // 0x1135408: LeaveFrame
    //     0x1135408: mov             SP, fp
    //     0x113540c: ldp             fp, lr, [SP], #0x10
    // 0x1135410: ret
    //     0x1135410: ret             
    // 0x1135414: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1135414: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1135418: b               #0x1135120
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x11662d0, size: 0x170
    // 0x11662d0: EnterFrame
    //     0x11662d0: stp             fp, lr, [SP, #-0x10]!
    //     0x11662d4: mov             fp, SP
    // 0x11662d8: AllocStack(0x28)
    //     0x11662d8: sub             SP, SP, #0x28
    // 0x11662dc: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x28 */)
    //     0x11662dc: mov             x4, x1
    //     0x11662e0: mov             x0, x2
    //     0x11662e4: stur            x1, [fp, #-0x10]
    //     0x11662e8: stur            x2, [fp, #-0x18]
    //     0x11662ec: stur            d0, [fp, #-0x28]
    // 0x11662f0: CheckStackOverflow
    //     0x11662f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11662f4: cmp             SP, x16
    //     0x11662f8: b.ls            #0x116641c
    // 0x11662fc: cmp             w4, w0
    // 0x1166300: b.ne            #0x1166314
    // 0x1166304: mov             x0, x4
    // 0x1166308: LeaveFrame
    //     0x1166308: mov             SP, fp
    //     0x116630c: ldp             fp, lr, [SP], #0x10
    // 0x1166310: ret
    //     0x1166310: ret             
    // 0x1166314: r5 = inline_Allocate_Double()
    //     0x1166314: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x1166318: add             x5, x5, #0x10
    //     0x116631c: cmp             x1, x5
    //     0x1166320: b.ls            #0x1166424
    //     0x1166324: str             x5, [THR, #0x60]  ; THR::top
    //     0x1166328: sub             x5, x5, #0xf
    //     0x116632c: mov             x1, #0xe19c
    //     0x1166330: movk            x1, #3, lsl #16
    //     0x1166334: stur            x1, [x5, #-1]
    // 0x1166338: dmb             ishst
    // 0x116633c: StoreField: r5->field_7 = d0
    //     0x116633c: stur            d0, [x5, #7]
    // 0x1166340: mov             x3, x5
    // 0x1166344: stur            x5, [fp, #-8]
    // 0x1166348: r1 = Null
    //     0x1166348: mov             x1, NULL
    // 0x116634c: r2 = Null
    //     0x116634c: mov             x2, NULL
    // 0x1166350: r0 = lerp()
    //     0x1166350: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1166354: ldur            d0, [fp, #-0x28]
    // 0x1166358: r1 = Null
    //     0x1166358: mov             x1, NULL
    // 0x116635c: r2 = Null
    //     0x116635c: mov             x2, NULL
    // 0x1166360: r0 = lerp()
    //     0x1166360: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x1166364: ldur            x3, [fp, #-8]
    // 0x1166368: r1 = Null
    //     0x1166368: mov             x1, NULL
    // 0x116636c: r2 = Null
    //     0x116636c: mov             x2, NULL
    // 0x1166370: r0 = lerp()
    //     0x1166370: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x1166374: ldur            x0, [fp, #-0x10]
    // 0x1166378: LoadField: r1 = r0->field_13
    //     0x1166378: ldur            w1, [x0, #0x13]
    // 0x116637c: DecompressPointer r1
    //     0x116637c: add             x1, x1, HEAP, lsl #32
    // 0x1166380: ldur            x4, [fp, #-0x18]
    // 0x1166384: LoadField: r2 = r4->field_13
    //     0x1166384: ldur            w2, [x4, #0x13]
    // 0x1166388: DecompressPointer r2
    //     0x1166388: add             x2, x2, HEAP, lsl #32
    // 0x116638c: ldur            x3, [fp, #-8]
    // 0x1166390: r0 = lerpDouble()
    //     0x1166390: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1166394: ldur            x3, [fp, #-8]
    // 0x1166398: r1 = Null
    //     0x1166398: mov             x1, NULL
    // 0x116639c: r2 = Null
    //     0x116639c: mov             x2, NULL
    // 0x11663a0: stur            x0, [fp, #-0x20]
    // 0x11663a4: r0 = lerp()
    //     0x11663a4: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11663a8: ldur            x3, [fp, #-8]
    // 0x11663ac: r1 = Null
    //     0x11663ac: mov             x1, NULL
    // 0x11663b0: r2 = Null
    //     0x11663b0: mov             x2, NULL
    // 0x11663b4: r0 = lerp()
    //     0x11663b4: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11663b8: ldur            x3, [fp, #-8]
    // 0x11663bc: r1 = Null
    //     0x11663bc: mov             x1, NULL
    // 0x11663c0: r2 = Null
    //     0x11663c0: mov             x2, NULL
    // 0x11663c4: r0 = lerp()
    //     0x11663c4: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x11663c8: ldur            x3, [fp, #-8]
    // 0x11663cc: r1 = Null
    //     0x11663cc: mov             x1, NULL
    // 0x11663d0: r2 = Null
    //     0x11663d0: mov             x2, NULL
    // 0x11663d4: r0 = lerp()
    //     0x11663d4: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11663d8: ldur            x0, [fp, #-0x10]
    // 0x11663dc: LoadField: r1 = r0->field_37
    //     0x11663dc: ldur            w1, [x0, #0x37]
    // 0x11663e0: DecompressPointer r1
    //     0x11663e0: add             x1, x1, HEAP, lsl #32
    // 0x11663e4: ldur            x0, [fp, #-0x18]
    // 0x11663e8: LoadField: r2 = r0->field_37
    //     0x11663e8: ldur            w2, [x0, #0x37]
    // 0x11663ec: DecompressPointer r2
    //     0x11663ec: add             x2, x2, HEAP, lsl #32
    // 0x11663f0: ldur            x3, [fp, #-8]
    // 0x11663f4: r0 = lerpDouble()
    //     0x11663f4: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x11663f8: stur            x0, [fp, #-8]
    // 0x11663fc: r0 = PopupMenuThemeData()
    //     0x11663fc: bl              #0x1166440  ; AllocatePopupMenuThemeDataStub -> PopupMenuThemeData (size=0x3c)
    // 0x1166400: ldur            x1, [fp, #-0x20]
    // 0x1166404: StoreField: r0->field_13 = r1
    //     0x1166404: stur            w1, [x0, #0x13]
    // 0x1166408: ldur            x1, [fp, #-8]
    // 0x116640c: StoreField: r0->field_37 = r1
    //     0x116640c: stur            w1, [x0, #0x37]
    // 0x1166410: LeaveFrame
    //     0x1166410: mov             SP, fp
    //     0x1166414: ldp             fp, lr, [SP], #0x10
    // 0x1166418: ret
    //     0x1166418: ret             
    // 0x116641c: r0 = StackOverflowSharedWithFPURegs()
    //     0x116641c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1166420: b               #0x11662fc
    // 0x1166424: SaveReg d0
    //     0x1166424: str             q0, [SP, #-0x10]!
    // 0x1166428: stp             x0, x4, [SP, #-0x10]!
    // 0x116642c: r0 = AllocateDouble()
    //     0x116642c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1166430: mov             x5, x0
    // 0x1166434: ldp             x0, x4, [SP], #0x10
    // 0x1166438: RestoreReg d0
    //     0x1166438: ldr             q0, [SP], #0x10
    // 0x116643c: b               #0x116633c
  }
  _ ==(/* No info */) {
    // ** addr: 0x1270314, size: 0x708
    // 0x1270314: EnterFrame
    //     0x1270314: stp             fp, lr, [SP, #-0x10]!
    //     0x1270318: mov             fp, SP
    // 0x127031c: AllocStack(0x28)
    //     0x127031c: sub             SP, SP, #0x28
    // 0x1270320: CheckStackOverflow
    //     0x1270320: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1270324: cmp             SP, x16
    //     0x1270328: b.ls            #0x1270a14
    // 0x127032c: ldr             x1, [fp, #0x10]
    // 0x1270330: cmp             w1, NULL
    // 0x1270334: b.ne            #0x1270348
    // 0x1270338: r0 = false
    //     0x1270338: add             x0, NULL, #0x30  ; false
    // 0x127033c: LeaveFrame
    //     0x127033c: mov             SP, fp
    //     0x1270340: ldp             fp, lr, [SP], #0x10
    // 0x1270344: ret
    //     0x1270344: ret             
    // 0x1270348: ldr             x0, [fp, #0x18]
    // 0x127034c: cmp             w0, w1
    // 0x1270350: b.ne            #0x1270364
    // 0x1270354: r0 = true
    //     0x1270354: add             x0, NULL, #0x20  ; true
    // 0x1270358: LeaveFrame
    //     0x1270358: mov             SP, fp
    //     0x127035c: ldp             fp, lr, [SP], #0x10
    // 0x1270360: ret
    //     0x1270360: ret             
    // 0x1270364: stp             x0, x1, [SP]
    // 0x1270368: r0 = _haveSameRuntimeType()
    //     0x1270368: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x127036c: tbz             w0, #4, #0x1270380
    // 0x1270370: r0 = false
    //     0x1270370: add             x0, NULL, #0x30  ; false
    // 0x1270374: LeaveFrame
    //     0x1270374: mov             SP, fp
    //     0x1270378: ldp             fp, lr, [SP], #0x10
    // 0x127037c: ret
    //     0x127037c: ret             
    // 0x1270380: ldr             x0, [fp, #0x10]
    // 0x1270384: r2 = 60
    //     0x1270384: mov             x2, #0x3c
    // 0x1270388: branchIfSmi(r0, 0x1270394)
    //     0x1270388: tbz             w0, #0, #0x1270394
    // 0x127038c: r2 = LoadClassIdInstr(r0)
    //     0x127038c: ldur            x2, [x0, #-1]
    //     0x1270390: ubfx            x2, x2, #0xc, #0x14
    // 0x1270394: stur            x2, [fp, #-8]
    // 0x1270398: r17 = -5129
    //     0x1270398: mov             x17, #-0x1409
    // 0x127039c: add             x16, x2, x17
    // 0x12703a0: cmp             x16, #2
    // 0x12703a4: b.hi            #0x1270a04
    // 0x12703a8: r17 = 5129
    //     0x12703a8: mov             x17, #0x1409
    // 0x12703ac: cmp             x2, x17
    // 0x12703b0: b.eq            #0x1270418
    // 0x12703b4: r17 = 5130
    //     0x12703b4: mov             x17, #0x140a
    // 0x12703b8: cmp             x2, x17
    // 0x12703bc: b.ne            #0x1270414
    // 0x12703c0: mov             x1, x0
    // 0x12703c4: LoadField: r0 = r1->field_43
    //     0x12703c4: ldur            w0, [x1, #0x43]
    // 0x12703c8: DecompressPointer r0
    //     0x12703c8: add             x0, x0, HEAP, lsl #32
    // 0x12703cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12703d0: cmp             w0, w16
    // 0x12703d4: b.ne            #0x12703e4
    // 0x12703d8: r2 = _colors
    //     0x12703d8: add             x2, PP, #0x26, lsl #12  ; [pp+0x262d0] Field <_PopupMenuDefaultsM3@113182389._colors@113182389>: late final (offset: 0x44)
    //     0x12703dc: ldr             x2, [x2, #0x2d0]
    // 0x12703e0: r0 = InitLateFinalInstanceField()
    //     0x12703e0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12703e4: LoadField: r1 = r0->field_97
    //     0x12703e4: ldur            w1, [x0, #0x97]
    // 0x12703e8: DecompressPointer r1
    //     0x12703e8: add             x1, x1, HEAP, lsl #32
    // 0x12703ec: cmp             w1, NULL
    // 0x12703f0: b.ne            #0x1270404
    // 0x12703f4: LoadField: r1 = r0->field_7b
    //     0x12703f4: ldur            w1, [x0, #0x7b]
    // 0x12703f8: DecompressPointer r1
    //     0x12703f8: add             x1, x1, HEAP, lsl #32
    // 0x12703fc: mov             x0, x1
    // 0x1270400: b               #0x1270408
    // 0x1270404: mov             x0, x1
    // 0x1270408: mov             x3, x0
    // 0x127040c: ldr             x0, [fp, #0x10]
    // 0x1270410: b               #0x1270424
    // 0x1270414: ldr             x0, [fp, #0x10]
    // 0x1270418: LoadField: r1 = r0->field_7
    //     0x1270418: ldur            w1, [x0, #7]
    // 0x127041c: DecompressPointer r1
    //     0x127041c: add             x1, x1, HEAP, lsl #32
    // 0x1270420: mov             x3, x1
    // 0x1270424: ldr             x2, [fp, #0x18]
    // 0x1270428: stur            x3, [fp, #-0x18]
    // 0x127042c: r4 = LoadClassIdInstr(r2)
    //     0x127042c: ldur            x4, [x2, #-1]
    //     0x1270430: ubfx            x4, x4, #0xc, #0x14
    // 0x1270434: stur            x4, [fp, #-0x10]
    // 0x1270438: r17 = 5129
    //     0x1270438: mov             x17, #0x1409
    // 0x127043c: cmp             x4, x17
    // 0x1270440: b.ne            #0x127044c
    // 0x1270444: mov             x1, x2
    // 0x1270448: b               #0x12704b0
    // 0x127044c: r17 = 5130
    //     0x127044c: mov             x17, #0x140a
    // 0x1270450: cmp             x4, x17
    // 0x1270454: b.ne            #0x12704ac
    // 0x1270458: mov             x1, x2
    // 0x127045c: LoadField: r0 = r1->field_43
    //     0x127045c: ldur            w0, [x1, #0x43]
    // 0x1270460: DecompressPointer r0
    //     0x1270460: add             x0, x0, HEAP, lsl #32
    // 0x1270464: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1270468: cmp             w0, w16
    // 0x127046c: b.ne            #0x127047c
    // 0x1270470: r2 = _colors
    //     0x1270470: add             x2, PP, #0x26, lsl #12  ; [pp+0x262d0] Field <_PopupMenuDefaultsM3@113182389._colors@113182389>: late final (offset: 0x44)
    //     0x1270474: ldr             x2, [x2, #0x2d0]
    // 0x1270478: r0 = InitLateFinalInstanceField()
    //     0x1270478: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x127047c: LoadField: r1 = r0->field_97
    //     0x127047c: ldur            w1, [x0, #0x97]
    // 0x1270480: DecompressPointer r1
    //     0x1270480: add             x1, x1, HEAP, lsl #32
    // 0x1270484: cmp             w1, NULL
    // 0x1270488: b.ne            #0x127049c
    // 0x127048c: LoadField: r1 = r0->field_7b
    //     0x127048c: ldur            w1, [x0, #0x7b]
    // 0x1270490: DecompressPointer r1
    //     0x1270490: add             x1, x1, HEAP, lsl #32
    // 0x1270494: mov             x0, x1
    // 0x1270498: b               #0x12704a0
    // 0x127049c: mov             x0, x1
    // 0x12704a0: mov             x2, x0
    // 0x12704a4: ldr             x1, [fp, #0x18]
    // 0x12704a8: b               #0x12704bc
    // 0x12704ac: ldr             x1, [fp, #0x18]
    // 0x12704b0: LoadField: r0 = r1->field_7
    //     0x12704b0: ldur            w0, [x1, #7]
    // 0x12704b4: DecompressPointer r0
    //     0x12704b4: add             x0, x0, HEAP, lsl #32
    // 0x12704b8: mov             x2, x0
    // 0x12704bc: ldur            x0, [fp, #-0x18]
    // 0x12704c0: r3 = LoadClassIdInstr(r0)
    //     0x12704c0: ldur            x3, [x0, #-1]
    //     0x12704c4: ubfx            x3, x3, #0xc, #0x14
    // 0x12704c8: stp             x2, x0, [SP]
    // 0x12704cc: mov             x0, x3
    // 0x12704d0: mov             lr, x0
    // 0x12704d4: ldr             lr, [x21, lr, lsl #3]
    // 0x12704d8: blr             lr
    // 0x12704dc: tbnz            w0, #4, #0x1270a04
    // 0x12704e0: ldur            x1, [fp, #-8]
    // 0x12704e4: r17 = 5129
    //     0x12704e4: mov             x17, #0x1409
    // 0x12704e8: cmp             x1, x17
    // 0x12704ec: b.eq            #0x127050c
    // 0x12704f0: r17 = 5130
    //     0x12704f0: mov             x17, #0x140a
    // 0x12704f4: cmp             x1, x17
    // 0x12704f8: b.ne            #0x127050c
    // 0x12704fc: ldr             x2, [fp, #0x10]
    // 0x1270500: r0 = Instance_RoundedRectangleBorder
    //     0x1270500: add             x0, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0x1270504: ldr             x0, [x0, #0x218]
    // 0x1270508: b               #0x1270518
    // 0x127050c: ldr             x2, [fp, #0x10]
    // 0x1270510: LoadField: r0 = r2->field_b
    //     0x1270510: ldur            w0, [x2, #0xb]
    // 0x1270514: DecompressPointer r0
    //     0x1270514: add             x0, x0, HEAP, lsl #32
    // 0x1270518: ldur            x3, [fp, #-0x10]
    // 0x127051c: r17 = 5129
    //     0x127051c: mov             x17, #0x1409
    // 0x1270520: cmp             x3, x17
    // 0x1270524: b.eq            #0x1270544
    // 0x1270528: r17 = 5130
    //     0x1270528: mov             x17, #0x140a
    // 0x127052c: cmp             x3, x17
    // 0x1270530: b.ne            #0x1270544
    // 0x1270534: ldr             x4, [fp, #0x18]
    // 0x1270538: r5 = Instance_RoundedRectangleBorder
    //     0x1270538: add             x5, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0x127053c: ldr             x5, [x5, #0x218]
    // 0x1270540: b               #0x1270550
    // 0x1270544: ldr             x4, [fp, #0x18]
    // 0x1270548: LoadField: r5 = r4->field_b
    //     0x1270548: ldur            w5, [x4, #0xb]
    // 0x127054c: DecompressPointer r5
    //     0x127054c: add             x5, x5, HEAP, lsl #32
    // 0x1270550: r6 = LoadClassIdInstr(r0)
    //     0x1270550: ldur            x6, [x0, #-1]
    //     0x1270554: ubfx            x6, x6, #0xc, #0x14
    // 0x1270558: stp             x5, x0, [SP]
    // 0x127055c: mov             x0, x6
    // 0x1270560: mov             lr, x0
    // 0x1270564: ldr             lr, [x21, lr, lsl #3]
    // 0x1270568: blr             lr
    // 0x127056c: tbnz            w0, #4, #0x1270a04
    // 0x1270570: ldur            x1, [fp, #-8]
    // 0x1270574: r17 = 5129
    //     0x1270574: mov             x17, #0x1409
    // 0x1270578: cmp             x1, x17
    // 0x127057c: b.ne            #0x1270590
    // 0x1270580: ldr             x2, [fp, #0x10]
    // 0x1270584: LoadField: r0 = r2->field_f
    //     0x1270584: ldur            w0, [x2, #0xf]
    // 0x1270588: DecompressPointer r0
    //     0x1270588: add             x0, x0, HEAP, lsl #32
    // 0x127058c: b               #0x12705b4
    // 0x1270590: ldr             x2, [fp, #0x10]
    // 0x1270594: r17 = 5130
    //     0x1270594: mov             x17, #0x140a
    // 0x1270598: cmp             x1, x17
    // 0x127059c: b.ne            #0x12705ac
    // 0x12705a0: r0 = Instance_EdgeInsets
    //     0x12705a0: add             x0, PP, #0x26, lsl #12  ; [pp+0x262d8] Obj!EdgeInsets@129d5f1
    //     0x12705a4: ldr             x0, [x0, #0x2d8]
    // 0x12705a8: b               #0x12705b4
    // 0x12705ac: r0 = Instance_EdgeInsets
    //     0x12705ac: add             x0, PP, #0x26, lsl #12  ; [pp+0x262d8] Obj!EdgeInsets@129d5f1
    //     0x12705b0: ldr             x0, [x0, #0x2d8]
    // 0x12705b4: ldur            x3, [fp, #-0x10]
    // 0x12705b8: r17 = 5129
    //     0x12705b8: mov             x17, #0x1409
    // 0x12705bc: cmp             x3, x17
    // 0x12705c0: b.ne            #0x12705d4
    // 0x12705c4: ldr             x4, [fp, #0x18]
    // 0x12705c8: LoadField: r5 = r4->field_f
    //     0x12705c8: ldur            w5, [x4, #0xf]
    // 0x12705cc: DecompressPointer r5
    //     0x12705cc: add             x5, x5, HEAP, lsl #32
    // 0x12705d0: b               #0x12705f8
    // 0x12705d4: ldr             x4, [fp, #0x18]
    // 0x12705d8: r17 = 5130
    //     0x12705d8: mov             x17, #0x140a
    // 0x12705dc: cmp             x3, x17
    // 0x12705e0: b.ne            #0x12705f0
    // 0x12705e4: r5 = Instance_EdgeInsets
    //     0x12705e4: add             x5, PP, #0x26, lsl #12  ; [pp+0x262d8] Obj!EdgeInsets@129d5f1
    //     0x12705e8: ldr             x5, [x5, #0x2d8]
    // 0x12705ec: b               #0x12705f8
    // 0x12705f0: r5 = Instance_EdgeInsets
    //     0x12705f0: add             x5, PP, #0x26, lsl #12  ; [pp+0x262d8] Obj!EdgeInsets@129d5f1
    //     0x12705f4: ldr             x5, [x5, #0x2d8]
    // 0x12705f8: r6 = LoadClassIdInstr(r0)
    //     0x12705f8: ldur            x6, [x0, #-1]
    //     0x12705fc: ubfx            x6, x6, #0xc, #0x14
    // 0x1270600: stp             x5, x0, [SP]
    // 0x1270604: mov             x0, x6
    // 0x1270608: mov             lr, x0
    // 0x127060c: ldr             lr, [x21, lr, lsl #3]
    // 0x1270610: blr             lr
    // 0x1270614: tbnz            w0, #4, #0x1270a04
    // 0x1270618: ldr             x2, [fp, #0x18]
    // 0x127061c: ldr             x1, [fp, #0x10]
    // 0x1270620: LoadField: r0 = r1->field_13
    //     0x1270620: ldur            w0, [x1, #0x13]
    // 0x1270624: DecompressPointer r0
    //     0x1270624: add             x0, x0, HEAP, lsl #32
    // 0x1270628: LoadField: r3 = r2->field_13
    //     0x1270628: ldur            w3, [x2, #0x13]
    // 0x127062c: DecompressPointer r3
    //     0x127062c: add             x3, x3, HEAP, lsl #32
    // 0x1270630: r4 = LoadClassIdInstr(r0)
    //     0x1270630: ldur            x4, [x0, #-1]
    //     0x1270634: ubfx            x4, x4, #0xc, #0x14
    // 0x1270638: stp             x3, x0, [SP]
    // 0x127063c: mov             x0, x4
    // 0x1270640: mov             lr, x0
    // 0x1270644: ldr             lr, [x21, lr, lsl #3]
    // 0x1270648: blr             lr
    // 0x127064c: tbnz            w0, #4, #0x1270a04
    // 0x1270650: ldur            x0, [fp, #-8]
    // 0x1270654: r17 = 5129
    //     0x1270654: mov             x17, #0x1409
    // 0x1270658: cmp             x0, x17
    // 0x127065c: b.eq            #0x12706bc
    // 0x1270660: r17 = 5130
    //     0x1270660: mov             x17, #0x140a
    // 0x1270664: cmp             x0, x17
    // 0x1270668: b.ne            #0x12706bc
    // 0x127066c: ldr             x1, [fp, #0x10]
    // 0x1270670: LoadField: r0 = r1->field_43
    //     0x1270670: ldur            w0, [x1, #0x43]
    // 0x1270674: DecompressPointer r0
    //     0x1270674: add             x0, x0, HEAP, lsl #32
    // 0x1270678: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x127067c: cmp             w0, w16
    // 0x1270680: b.ne            #0x1270690
    // 0x1270684: r2 = _colors
    //     0x1270684: add             x2, PP, #0x26, lsl #12  ; [pp+0x262d0] Field <_PopupMenuDefaultsM3@113182389._colors@113182389>: late final (offset: 0x44)
    //     0x1270688: ldr             x2, [x2, #0x2d0]
    // 0x127068c: r0 = InitLateFinalInstanceField()
    //     0x127068c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1270690: LoadField: r1 = r0->field_af
    //     0x1270690: ldur            w1, [x0, #0xaf]
    // 0x1270694: DecompressPointer r1
    //     0x1270694: add             x1, x1, HEAP, lsl #32
    // 0x1270698: cmp             w1, NULL
    // 0x127069c: b.ne            #0x12706ac
    // 0x12706a0: r0 = Instance_Color
    //     0x12706a0: add             x0, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x12706a4: ldr             x0, [x0, #0x948]
    // 0x12706a8: b               #0x12706b0
    // 0x12706ac: mov             x0, x1
    // 0x12706b0: mov             x3, x0
    // 0x12706b4: ldr             x0, [fp, #0x10]
    // 0x12706b8: b               #0x12706cc
    // 0x12706bc: ldr             x0, [fp, #0x10]
    // 0x12706c0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x12706c0: ldur            w1, [x0, #0x17]
    // 0x12706c4: DecompressPointer r1
    //     0x12706c4: add             x1, x1, HEAP, lsl #32
    // 0x12706c8: mov             x3, x1
    // 0x12706cc: ldur            x2, [fp, #-0x10]
    // 0x12706d0: stur            x3, [fp, #-0x18]
    // 0x12706d4: r17 = 5129
    //     0x12706d4: mov             x17, #0x1409
    // 0x12706d8: cmp             x2, x17
    // 0x12706dc: b.eq            #0x127073c
    // 0x12706e0: r17 = 5130
    //     0x12706e0: mov             x17, #0x140a
    // 0x12706e4: cmp             x2, x17
    // 0x12706e8: b.ne            #0x127073c
    // 0x12706ec: ldr             x1, [fp, #0x18]
    // 0x12706f0: LoadField: r0 = r1->field_43
    //     0x12706f0: ldur            w0, [x1, #0x43]
    // 0x12706f4: DecompressPointer r0
    //     0x12706f4: add             x0, x0, HEAP, lsl #32
    // 0x12706f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12706fc: cmp             w0, w16
    // 0x1270700: b.ne            #0x1270710
    // 0x1270704: r2 = _colors
    //     0x1270704: add             x2, PP, #0x26, lsl #12  ; [pp+0x262d0] Field <_PopupMenuDefaultsM3@113182389._colors@113182389>: late final (offset: 0x44)
    //     0x1270708: ldr             x2, [x2, #0x2d0]
    // 0x127070c: r0 = InitLateFinalInstanceField()
    //     0x127070c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1270710: LoadField: r1 = r0->field_af
    //     0x1270710: ldur            w1, [x0, #0xaf]
    // 0x1270714: DecompressPointer r1
    //     0x1270714: add             x1, x1, HEAP, lsl #32
    // 0x1270718: cmp             w1, NULL
    // 0x127071c: b.ne            #0x127072c
    // 0x1270720: r0 = Instance_Color
    //     0x1270720: add             x0, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x1270724: ldr             x0, [x0, #0x948]
    // 0x1270728: b               #0x1270730
    // 0x127072c: mov             x0, x1
    // 0x1270730: mov             x2, x0
    // 0x1270734: ldr             x1, [fp, #0x18]
    // 0x1270738: b               #0x127074c
    // 0x127073c: ldr             x1, [fp, #0x18]
    // 0x1270740: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x1270740: ldur            w0, [x1, #0x17]
    // 0x1270744: DecompressPointer r0
    //     0x1270744: add             x0, x0, HEAP, lsl #32
    // 0x1270748: mov             x2, x0
    // 0x127074c: ldur            x0, [fp, #-0x18]
    // 0x1270750: r3 = LoadClassIdInstr(r0)
    //     0x1270750: ldur            x3, [x0, #-1]
    //     0x1270754: ubfx            x3, x3, #0xc, #0x14
    // 0x1270758: stp             x2, x0, [SP]
    // 0x127075c: mov             x0, x3
    // 0x1270760: mov             lr, x0
    // 0x1270764: ldr             lr, [x21, lr, lsl #3]
    // 0x1270768: blr             lr
    // 0x127076c: tbnz            w0, #4, #0x1270a04
    // 0x1270770: ldur            x1, [fp, #-8]
    // 0x1270774: r17 = 5129
    //     0x1270774: mov             x17, #0x1409
    // 0x1270778: cmp             x1, x17
    // 0x127077c: b.eq            #0x127079c
    // 0x1270780: r17 = 5130
    //     0x1270780: mov             x17, #0x140a
    // 0x1270784: cmp             x1, x17
    // 0x1270788: b.ne            #0x127079c
    // 0x127078c: ldr             x2, [fp, #0x10]
    // 0x1270790: r0 = Instance_Color
    //     0x1270790: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1270794: ldr             x0, [x0, #0x810]
    // 0x1270798: b               #0x12707a8
    // 0x127079c: ldr             x2, [fp, #0x10]
    // 0x12707a0: LoadField: r0 = r2->field_1b
    //     0x12707a0: ldur            w0, [x2, #0x1b]
    // 0x12707a4: DecompressPointer r0
    //     0x12707a4: add             x0, x0, HEAP, lsl #32
    // 0x12707a8: ldur            x3, [fp, #-0x10]
    // 0x12707ac: r17 = 5129
    //     0x12707ac: mov             x17, #0x1409
    // 0x12707b0: cmp             x3, x17
    // 0x12707b4: b.eq            #0x12707d4
    // 0x12707b8: r17 = 5130
    //     0x12707b8: mov             x17, #0x140a
    // 0x12707bc: cmp             x3, x17
    // 0x12707c0: b.ne            #0x12707d4
    // 0x12707c4: ldr             x4, [fp, #0x18]
    // 0x12707c8: r5 = Instance_Color
    //     0x12707c8: add             x5, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x12707cc: ldr             x5, [x5, #0x810]
    // 0x12707d0: b               #0x12707e0
    // 0x12707d4: ldr             x4, [fp, #0x18]
    // 0x12707d8: LoadField: r5 = r4->field_1b
    //     0x12707d8: ldur            w5, [x4, #0x1b]
    // 0x12707dc: DecompressPointer r5
    //     0x12707dc: add             x5, x5, HEAP, lsl #32
    // 0x12707e0: r6 = LoadClassIdInstr(r0)
    //     0x12707e0: ldur            x6, [x0, #-1]
    //     0x12707e4: ubfx            x6, x6, #0xc, #0x14
    // 0x12707e8: stp             x5, x0, [SP]
    // 0x12707ec: mov             x0, x6
    // 0x12707f0: mov             lr, x0
    // 0x12707f4: ldr             lr, [x21, lr, lsl #3]
    // 0x12707f8: blr             lr
    // 0x12707fc: tbnz            w0, #4, #0x1270a04
    // 0x1270800: ldur            x0, [fp, #-8]
    // 0x1270804: r17 = -5129
    //     0x1270804: mov             x17, #-0x1409
    // 0x1270808: add             x16, x0, x17
    // 0x127080c: cmp             x16, #1
    // 0x1270810: b.hi            #0x1270828
    // 0x1270814: ldr             x2, [fp, #0x10]
    // 0x1270818: LoadField: r1 = r2->field_1f
    //     0x1270818: ldur            w1, [x2, #0x1f]
    // 0x127081c: DecompressPointer r1
    //     0x127081c: add             x1, x1, HEAP, lsl #32
    // 0x1270820: mov             x2, x1
    // 0x1270824: b               #0x127085c
    // 0x1270828: ldr             x2, [fp, #0x10]
    // 0x127082c: mov             x1, x2
    // 0x1270830: LoadField: r0 = r1->field_43
    //     0x1270830: ldur            w0, [x1, #0x43]
    // 0x1270834: DecompressPointer r0
    //     0x1270834: add             x0, x0, HEAP, lsl #32
    // 0x1270838: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x127083c: cmp             w0, w16
    // 0x1270840: b.ne            #0x1270850
    // 0x1270844: r2 = _textTheme
    //     0x1270844: add             x2, PP, #0x26, lsl #12  ; [pp+0x262e0] Field <_PopupMenuDefaultsM2@113182389._textTheme@113182389>: late final (offset: 0x44)
    //     0x1270848: ldr             x2, [x2, #0x2e0]
    // 0x127084c: r0 = InitLateFinalInstanceField()
    //     0x127084c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1270850: LoadField: r1 = r0->field_23
    //     0x1270850: ldur            w1, [x0, #0x23]
    // 0x1270854: DecompressPointer r1
    //     0x1270854: add             x1, x1, HEAP, lsl #32
    // 0x1270858: mov             x2, x1
    // 0x127085c: ldur            x0, [fp, #-0x10]
    // 0x1270860: stur            x2, [fp, #-0x18]
    // 0x1270864: r17 = -5129
    //     0x1270864: mov             x17, #-0x1409
    // 0x1270868: add             x16, x0, x17
    // 0x127086c: cmp             x16, #1
    // 0x1270870: b.hi            #0x1270888
    // 0x1270874: ldr             x3, [fp, #0x18]
    // 0x1270878: LoadField: r1 = r3->field_1f
    //     0x1270878: ldur            w1, [x3, #0x1f]
    // 0x127087c: DecompressPointer r1
    //     0x127087c: add             x1, x1, HEAP, lsl #32
    // 0x1270880: mov             x0, x2
    // 0x1270884: b               #0x12708bc
    // 0x1270888: ldr             x3, [fp, #0x18]
    // 0x127088c: mov             x1, x3
    // 0x1270890: LoadField: r0 = r1->field_43
    //     0x1270890: ldur            w0, [x1, #0x43]
    // 0x1270894: DecompressPointer r0
    //     0x1270894: add             x0, x0, HEAP, lsl #32
    // 0x1270898: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x127089c: cmp             w0, w16
    // 0x12708a0: b.ne            #0x12708b0
    // 0x12708a4: r2 = _textTheme
    //     0x12708a4: add             x2, PP, #0x26, lsl #12  ; [pp+0x262e0] Field <_PopupMenuDefaultsM2@113182389._textTheme@113182389>: late final (offset: 0x44)
    //     0x12708a8: ldr             x2, [x2, #0x2e0]
    // 0x12708ac: r0 = InitLateFinalInstanceField()
    //     0x12708ac: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12708b0: LoadField: r1 = r0->field_23
    //     0x12708b0: ldur            w1, [x0, #0x23]
    // 0x12708b4: DecompressPointer r1
    //     0x12708b4: add             x1, x1, HEAP, lsl #32
    // 0x12708b8: ldur            x0, [fp, #-0x18]
    // 0x12708bc: r2 = LoadClassIdInstr(r0)
    //     0x12708bc: ldur            x2, [x0, #-1]
    //     0x12708c0: ubfx            x2, x2, #0xc, #0x14
    // 0x12708c4: stp             x1, x0, [SP]
    // 0x12708c8: mov             x0, x2
    // 0x12708cc: mov             lr, x0
    // 0x12708d0: ldr             lr, [x21, lr, lsl #3]
    // 0x12708d4: blr             lr
    // 0x12708d8: tbnz            w0, #4, #0x1270a04
    // 0x12708dc: ldur            x0, [fp, #-8]
    // 0x12708e0: r17 = 5129
    //     0x12708e0: mov             x17, #0x1409
    // 0x12708e4: cmp             x0, x17
    // 0x12708e8: b.eq            #0x1270940
    // 0x12708ec: r17 = 5130
    //     0x12708ec: mov             x17, #0x140a
    // 0x12708f0: cmp             x0, x17
    // 0x12708f4: b.ne            #0x1270940
    // 0x12708f8: ldr             x0, [fp, #0x10]
    // 0x12708fc: r1 = 1
    //     0x12708fc: mov             x1, #1
    // 0x1270900: r0 = AllocateContext()
    //     0x1270900: bl              #0x13de838  ; AllocateContextStub
    // 0x1270904: mov             x1, x0
    // 0x1270908: ldr             x0, [fp, #0x10]
    // 0x127090c: StoreField: r1->field_f = r0
    //     0x127090c: stur            w0, [x1, #0xf]
    // 0x1270910: mov             x2, x1
    // 0x1270914: r1 = Function '<anonymous closure>':.
    //     0x1270914: add             x1, PP, #0x26, lsl #12  ; [pp+0x262e8] AnonymousClosure: (0xdf87d8), of [package:flutter/src/material/popup_menu.dart] _PopupMenuDefaultsM3
    //     0x1270918: ldr             x1, [x1, #0x2e8]
    // 0x127091c: r0 = AllocateClosure()
    //     0x127091c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1270920: r16 = <TextStyle?>
    //     0x1270920: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a88] TypeArguments: <TextStyle?>
    //     0x1270924: ldr             x16, [x16, #0xa88]
    // 0x1270928: stp             x0, x16, [SP]
    // 0x127092c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x127092c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1270930: r0 = resolveWith()
    //     0x1270930: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1270934: mov             x2, x0
    // 0x1270938: ldr             x0, [fp, #0x10]
    // 0x127093c: b               #0x1270950
    // 0x1270940: ldr             x0, [fp, #0x10]
    // 0x1270944: LoadField: r1 = r0->field_23
    //     0x1270944: ldur            w1, [x0, #0x23]
    // 0x1270948: DecompressPointer r1
    //     0x1270948: add             x1, x1, HEAP, lsl #32
    // 0x127094c: mov             x2, x1
    // 0x1270950: ldur            x1, [fp, #-0x10]
    // 0x1270954: stur            x2, [fp, #-0x18]
    // 0x1270958: r17 = 5129
    //     0x1270958: mov             x17, #0x1409
    // 0x127095c: cmp             x1, x17
    // 0x1270960: b.eq            #0x12709b8
    // 0x1270964: r17 = 5130
    //     0x1270964: mov             x17, #0x140a
    // 0x1270968: cmp             x1, x17
    // 0x127096c: b.ne            #0x12709b8
    // 0x1270970: ldr             x1, [fp, #0x18]
    // 0x1270974: r1 = 1
    //     0x1270974: mov             x1, #1
    // 0x1270978: r0 = AllocateContext()
    //     0x1270978: bl              #0x13de838  ; AllocateContextStub
    // 0x127097c: mov             x1, x0
    // 0x1270980: ldr             x0, [fp, #0x18]
    // 0x1270984: StoreField: r1->field_f = r0
    //     0x1270984: stur            w0, [x1, #0xf]
    // 0x1270988: mov             x2, x1
    // 0x127098c: r1 = Function '<anonymous closure>':.
    //     0x127098c: add             x1, PP, #0x26, lsl #12  ; [pp+0x262e8] AnonymousClosure: (0xdf87d8), of [package:flutter/src/material/popup_menu.dart] _PopupMenuDefaultsM3
    //     0x1270990: ldr             x1, [x1, #0x2e8]
    // 0x1270994: r0 = AllocateClosure()
    //     0x1270994: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1270998: r16 = <TextStyle?>
    //     0x1270998: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a88] TypeArguments: <TextStyle?>
    //     0x127099c: ldr             x16, [x16, #0xa88]
    // 0x12709a0: stp             x0, x16, [SP]
    // 0x12709a4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12709a4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12709a8: r0 = resolveWith()
    //     0x12709a8: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x12709ac: mov             x2, x0
    // 0x12709b0: ldr             x0, [fp, #0x18]
    // 0x12709b4: b               #0x12709c8
    // 0x12709b8: ldr             x0, [fp, #0x18]
    // 0x12709bc: LoadField: r1 = r0->field_23
    //     0x12709bc: ldur            w1, [x0, #0x23]
    // 0x12709c0: DecompressPointer r1
    //     0x12709c0: add             x1, x1, HEAP, lsl #32
    // 0x12709c4: mov             x2, x1
    // 0x12709c8: ldur            x1, [fp, #-0x18]
    // 0x12709cc: cmp             w1, w2
    // 0x12709d0: b.ne            #0x1270a04
    // 0x12709d4: ldr             x1, [fp, #0x10]
    // 0x12709d8: LoadField: r2 = r1->field_37
    //     0x12709d8: ldur            w2, [x1, #0x37]
    // 0x12709dc: DecompressPointer r2
    //     0x12709dc: add             x2, x2, HEAP, lsl #32
    // 0x12709e0: LoadField: r1 = r0->field_37
    //     0x12709e0: ldur            w1, [x0, #0x37]
    // 0x12709e4: DecompressPointer r1
    //     0x12709e4: add             x1, x1, HEAP, lsl #32
    // 0x12709e8: r0 = LoadClassIdInstr(r2)
    //     0x12709e8: ldur            x0, [x2, #-1]
    //     0x12709ec: ubfx            x0, x0, #0xc, #0x14
    // 0x12709f0: stp             x1, x2, [SP]
    // 0x12709f4: mov             lr, x0
    // 0x12709f8: ldr             lr, [x21, lr, lsl #3]
    // 0x12709fc: blr             lr
    // 0x1270a00: b               #0x1270a08
    // 0x1270a04: r0 = false
    //     0x1270a04: add             x0, NULL, #0x30  ; false
    // 0x1270a08: LeaveFrame
    //     0x1270a08: mov             SP, fp
    //     0x1270a0c: ldp             fp, lr, [SP], #0x10
    // 0x1270a10: ret
    //     0x1270a10: ret             
    // 0x1270a14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1270a14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1270a18: b               #0x127032c
  }
}

// class id: 6841, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class PopupMenuTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xdf85e0, size: 0x5c
    // 0xdf85e0: EnterFrame
    //     0xdf85e0: stp             fp, lr, [SP, #-0x10]!
    //     0xdf85e4: mov             fp, SP
    // 0xdf85e8: AllocStack(0x18)
    //     0xdf85e8: sub             SP, SP, #0x18
    // 0xdf85ec: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xdf85ec: stur            x1, [fp, #-8]
    // 0xdf85f0: CheckStackOverflow
    //     0xdf85f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf85f4: cmp             SP, x16
    //     0xdf85f8: b.ls            #0xdf8634
    // 0xdf85fc: r16 = <PopupMenuTheme>
    //     0xdf85fc: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd48a0] TypeArguments: <PopupMenuTheme>
    //     0xdf8600: ldr             x16, [x16, #0x8a0]
    // 0xdf8604: stp             x1, x16, [SP]
    // 0xdf8608: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf8608: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf860c: r0 = dependOnInheritedWidgetOfExactType()
    //     0xdf860c: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xdf8610: ldur            x1, [fp, #-8]
    // 0xdf8614: r0 = of()
    //     0xdf8614: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdf8618: r17 = 267
    //     0xdf8618: mov             x17, #0x10b
    // 0xdf861c: ldr             w1, [x0, x17]
    // 0xdf8620: DecompressPointer r1
    //     0xdf8620: add             x1, x1, HEAP, lsl #32
    // 0xdf8624: mov             x0, x1
    // 0xdf8628: LeaveFrame
    //     0xdf8628: mov             SP, fp
    //     0xdf862c: ldp             fp, lr, [SP], #0x10
    // 0xdf8630: ret
    //     0xdf8630: ret             
    // 0xdf8634: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf8634: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf8638: b               #0xdf85fc
  }
}
