// lib: , url: package:flutter/src/material/slider_theme.dart

// class id: 1048947, size: 0x8
class :: {
}

// class id: 5069, size: 0x98, field offset: 0x8
//   const constructor, 
class SliderThemeData extends _MixinApplication3&Object&Diagnosticable {

  _ copyWith(/* No info */) {
    // ** addr: 0xc24850, size: 0xb24
    // 0xc24850: EnterFrame
    //     0xc24850: stp             fp, lr, [SP, #-0x10]!
    //     0xc24854: mov             fp, SP
    // 0xc24858: AllocStack(0xc0)
    //     0xc24858: sub             SP, SP, #0xc0
    // 0xc2485c: SetupParameters(dynamic _ /* r2 => fp-0x8 */, {dynamic activeTickMarkColor = Null /* r5 */, dynamic activeTrackColor = Null /* r6 */, dynamic disabledActiveTickMarkColor = Null /* r7 */, dynamic disabledActiveTrackColor = Null /* r8 */, dynamic disabledInactiveTickMarkColor = Null /* r9 */, dynamic disabledInactiveTrackColor = Null /* r10 */, dynamic disabledSecondaryActiveTrackColor = Null /* r11 */, dynamic disabledThumbColor = Null /* fp-0x38 */, dynamic inactiveTickMarkColor = Null /* r13 */, dynamic inactiveTrackColor = Null /* r14 */, dynamic overlayColor = Null /* fp-0x20 */, dynamic overlayShape = Null /* fp-0x10 */, dynamic secondaryActiveTrackColor = Null /* r3 */, dynamic showValueIndicator = Null /* fp-0x18 */, dynamic thumbColor = Null /* r20 */, dynamic thumbShape = Null /* fp-0x28 */, dynamic tickMarkShape = Null /* fp-0x30 */, dynamic trackHeight = Null /* r19 */, dynamic trackShape = Null /* fp-0x40 */, dynamic valueIndicatorColor = Null /* fp-0x48 */, dynamic valueIndicatorShape = Null /* r12 */, dynamic valueIndicatorTextStyle = Null /* r0 */})
    //     0xc2485c: stur            x2, [fp, #-8]
    //     0xc24860: ldur            w0, [x4, #0x13]
    //     0xc24864: ldur            w3, [x4, #0x1f]
    //     0xc24868: add             x3, x3, HEAP, lsl #32
    //     0xc2486c: add             x16, PP, #0x98, lsl #12  ; [pp+0x98f58] "activeTickMarkColor"
    //     0xc24870: ldr             x16, [x16, #0xf58]
    //     0xc24874: cmp             w3, w16
    //     0xc24878: b.ne            #0xc2489c
    //     0xc2487c: ldur            w3, [x4, #0x23]
    //     0xc24880: add             x3, x3, HEAP, lsl #32
    //     0xc24884: sub             w5, w0, w3
    //     0xc24888: add             x3, fp, w5, sxtw #2
    //     0xc2488c: ldr             x3, [x3, #8]
    //     0xc24890: mov             x5, x3
    //     0xc24894: mov             x3, #1
    //     0xc24898: b               #0xc248a4
    //     0xc2489c: mov             x5, NULL
    //     0xc248a0: mov             x3, #0
    //     0xc248a4: lsl             x6, x3, #1
    //     0xc248a8: lsl             w7, w6, #1
    //     0xc248ac: add             w8, w7, #8
    //     0xc248b0: add             x16, x4, w8, sxtw #1
    //     0xc248b4: ldur            w9, [x16, #0xf]
    //     0xc248b8: add             x9, x9, HEAP, lsl #32
    //     0xc248bc: add             x16, PP, #0x98, lsl #12  ; [pp+0x98f60] "activeTrackColor"
    //     0xc248c0: ldr             x16, [x16, #0xf60]
    //     0xc248c4: cmp             w9, w16
    //     0xc248c8: b.ne            #0xc248fc
    //     0xc248cc: add             w3, w7, #0xa
    //     0xc248d0: add             x16, x4, w3, sxtw #1
    //     0xc248d4: ldur            w7, [x16, #0xf]
    //     0xc248d8: add             x7, x7, HEAP, lsl #32
    //     0xc248dc: sub             w3, w0, w7
    //     0xc248e0: add             x7, fp, w3, sxtw #2
    //     0xc248e4: ldr             x7, [x7, #8]
    //     0xc248e8: add             w3, w6, #2
    //     0xc248ec: sbfx            x6, x3, #1, #0x1f
    //     0xc248f0: mov             x3, x6
    //     0xc248f4: mov             x6, x7
    //     0xc248f8: b               #0xc24900
    //     0xc248fc: mov             x6, NULL
    //     0xc24900: lsl             x7, x3, #1
    //     0xc24904: lsl             w8, w7, #1
    //     0xc24908: add             w9, w8, #8
    //     0xc2490c: add             x16, x4, w9, sxtw #1
    //     0xc24910: ldur            w10, [x16, #0xf]
    //     0xc24914: add             x10, x10, HEAP, lsl #32
    //     0xc24918: add             x16, PP, #0x98, lsl #12  ; [pp+0x98f68] "disabledActiveTickMarkColor"
    //     0xc2491c: ldr             x16, [x16, #0xf68]
    //     0xc24920: cmp             w10, w16
    //     0xc24924: b.ne            #0xc24958
    //     0xc24928: add             w3, w8, #0xa
    //     0xc2492c: add             x16, x4, w3, sxtw #1
    //     0xc24930: ldur            w8, [x16, #0xf]
    //     0xc24934: add             x8, x8, HEAP, lsl #32
    //     0xc24938: sub             w3, w0, w8
    //     0xc2493c: add             x8, fp, w3, sxtw #2
    //     0xc24940: ldr             x8, [x8, #8]
    //     0xc24944: add             w3, w7, #2
    //     0xc24948: sbfx            x7, x3, #1, #0x1f
    //     0xc2494c: mov             x3, x7
    //     0xc24950: mov             x7, x8
    //     0xc24954: b               #0xc2495c
    //     0xc24958: mov             x7, NULL
    //     0xc2495c: lsl             x8, x3, #1
    //     0xc24960: lsl             w9, w8, #1
    //     0xc24964: add             w10, w9, #8
    //     0xc24968: add             x16, x4, w10, sxtw #1
    //     0xc2496c: ldur            w11, [x16, #0xf]
    //     0xc24970: add             x11, x11, HEAP, lsl #32
    //     0xc24974: add             x16, PP, #0x98, lsl #12  ; [pp+0x98f70] "disabledActiveTrackColor"
    //     0xc24978: ldr             x16, [x16, #0xf70]
    //     0xc2497c: cmp             w11, w16
    //     0xc24980: b.ne            #0xc249b4
    //     0xc24984: add             w3, w9, #0xa
    //     0xc24988: add             x16, x4, w3, sxtw #1
    //     0xc2498c: ldur            w9, [x16, #0xf]
    //     0xc24990: add             x9, x9, HEAP, lsl #32
    //     0xc24994: sub             w3, w0, w9
    //     0xc24998: add             x9, fp, w3, sxtw #2
    //     0xc2499c: ldr             x9, [x9, #8]
    //     0xc249a0: add             w3, w8, #2
    //     0xc249a4: sbfx            x8, x3, #1, #0x1f
    //     0xc249a8: mov             x3, x8
    //     0xc249ac: mov             x8, x9
    //     0xc249b0: b               #0xc249b8
    //     0xc249b4: mov             x8, NULL
    //     0xc249b8: lsl             x9, x3, #1
    //     0xc249bc: lsl             w10, w9, #1
    //     0xc249c0: add             w11, w10, #8
    //     0xc249c4: add             x16, x4, w11, sxtw #1
    //     0xc249c8: ldur            w12, [x16, #0xf]
    //     0xc249cc: add             x12, x12, HEAP, lsl #32
    //     0xc249d0: add             x16, PP, #0x98, lsl #12  ; [pp+0x98f78] "disabledInactiveTickMarkColor"
    //     0xc249d4: ldr             x16, [x16, #0xf78]
    //     0xc249d8: cmp             w12, w16
    //     0xc249dc: b.ne            #0xc24a10
    //     0xc249e0: add             w3, w10, #0xa
    //     0xc249e4: add             x16, x4, w3, sxtw #1
    //     0xc249e8: ldur            w10, [x16, #0xf]
    //     0xc249ec: add             x10, x10, HEAP, lsl #32
    //     0xc249f0: sub             w3, w0, w10
    //     0xc249f4: add             x10, fp, w3, sxtw #2
    //     0xc249f8: ldr             x10, [x10, #8]
    //     0xc249fc: add             w3, w9, #2
    //     0xc24a00: sbfx            x9, x3, #1, #0x1f
    //     0xc24a04: mov             x3, x9
    //     0xc24a08: mov             x9, x10
    //     0xc24a0c: b               #0xc24a14
    //     0xc24a10: mov             x9, NULL
    //     0xc24a14: lsl             x10, x3, #1
    //     0xc24a18: lsl             w11, w10, #1
    //     0xc24a1c: add             w12, w11, #8
    //     0xc24a20: add             x16, x4, w12, sxtw #1
    //     0xc24a24: ldur            w13, [x16, #0xf]
    //     0xc24a28: add             x13, x13, HEAP, lsl #32
    //     0xc24a2c: add             x16, PP, #0x98, lsl #12  ; [pp+0x98f80] "disabledInactiveTrackColor"
    //     0xc24a30: ldr             x16, [x16, #0xf80]
    //     0xc24a34: cmp             w13, w16
    //     0xc24a38: b.ne            #0xc24a6c
    //     0xc24a3c: add             w3, w11, #0xa
    //     0xc24a40: add             x16, x4, w3, sxtw #1
    //     0xc24a44: ldur            w11, [x16, #0xf]
    //     0xc24a48: add             x11, x11, HEAP, lsl #32
    //     0xc24a4c: sub             w3, w0, w11
    //     0xc24a50: add             x11, fp, w3, sxtw #2
    //     0xc24a54: ldr             x11, [x11, #8]
    //     0xc24a58: add             w3, w10, #2
    //     0xc24a5c: sbfx            x10, x3, #1, #0x1f
    //     0xc24a60: mov             x3, x10
    //     0xc24a64: mov             x10, x11
    //     0xc24a68: b               #0xc24a70
    //     0xc24a6c: mov             x10, NULL
    //     0xc24a70: lsl             x11, x3, #1
    //     0xc24a74: lsl             w12, w11, #1
    //     0xc24a78: add             w13, w12, #8
    //     0xc24a7c: add             x16, x4, w13, sxtw #1
    //     0xc24a80: ldur            w14, [x16, #0xf]
    //     0xc24a84: add             x14, x14, HEAP, lsl #32
    //     0xc24a88: add             x16, PP, #0x98, lsl #12  ; [pp+0x98f88] "disabledSecondaryActiveTrackColor"
    //     0xc24a8c: ldr             x16, [x16, #0xf88]
    //     0xc24a90: cmp             w14, w16
    //     0xc24a94: b.ne            #0xc24ac8
    //     0xc24a98: add             w3, w12, #0xa
    //     0xc24a9c: add             x16, x4, w3, sxtw #1
    //     0xc24aa0: ldur            w12, [x16, #0xf]
    //     0xc24aa4: add             x12, x12, HEAP, lsl #32
    //     0xc24aa8: sub             w3, w0, w12
    //     0xc24aac: add             x12, fp, w3, sxtw #2
    //     0xc24ab0: ldr             x12, [x12, #8]
    //     0xc24ab4: add             w3, w11, #2
    //     0xc24ab8: sbfx            x11, x3, #1, #0x1f
    //     0xc24abc: mov             x3, x11
    //     0xc24ac0: mov             x11, x12
    //     0xc24ac4: b               #0xc24acc
    //     0xc24ac8: mov             x11, NULL
    //     0xc24acc: lsl             x12, x3, #1
    //     0xc24ad0: lsl             w13, w12, #1
    //     0xc24ad4: add             w14, w13, #8
    //     0xc24ad8: add             x16, x4, w14, sxtw #1
    //     0xc24adc: ldur            w19, [x16, #0xf]
    //     0xc24ae0: add             x19, x19, HEAP, lsl #32
    //     0xc24ae4: add             x16, PP, #0x98, lsl #12  ; [pp+0x98f90] "disabledThumbColor"
    //     0xc24ae8: ldr             x16, [x16, #0xf90]
    //     0xc24aec: cmp             w19, w16
    //     0xc24af0: b.ne            #0xc24b24
    //     0xc24af4: add             w3, w13, #0xa
    //     0xc24af8: add             x16, x4, w3, sxtw #1
    //     0xc24afc: ldur            w13, [x16, #0xf]
    //     0xc24b00: add             x13, x13, HEAP, lsl #32
    //     0xc24b04: sub             w3, w0, w13
    //     0xc24b08: add             x13, fp, w3, sxtw #2
    //     0xc24b0c: ldr             x13, [x13, #8]
    //     0xc24b10: add             w3, w12, #2
    //     0xc24b14: sbfx            x12, x3, #1, #0x1f
    //     0xc24b18: mov             x3, x12
    //     0xc24b1c: mov             x12, x13
    //     0xc24b20: b               #0xc24b28
    //     0xc24b24: mov             x12, NULL
    //     0xc24b28: stur            x12, [fp, #-0x38]
    //     0xc24b2c: lsl             x13, x3, #1
    //     0xc24b30: lsl             w14, w13, #1
    //     0xc24b34: add             w19, w14, #8
    //     0xc24b38: add             x16, x4, w19, sxtw #1
    //     0xc24b3c: ldur            w20, [x16, #0xf]
    //     0xc24b40: add             x20, x20, HEAP, lsl #32
    //     0xc24b44: add             x16, PP, #0x98, lsl #12  ; [pp+0x98f98] "inactiveTickMarkColor"
    //     0xc24b48: ldr             x16, [x16, #0xf98]
    //     0xc24b4c: cmp             w20, w16
    //     0xc24b50: b.ne            #0xc24b84
    //     0xc24b54: add             w3, w14, #0xa
    //     0xc24b58: add             x16, x4, w3, sxtw #1
    //     0xc24b5c: ldur            w14, [x16, #0xf]
    //     0xc24b60: add             x14, x14, HEAP, lsl #32
    //     0xc24b64: sub             w3, w0, w14
    //     0xc24b68: add             x14, fp, w3, sxtw #2
    //     0xc24b6c: ldr             x14, [x14, #8]
    //     0xc24b70: add             w3, w13, #2
    //     0xc24b74: sbfx            x13, x3, #1, #0x1f
    //     0xc24b78: mov             x3, x13
    //     0xc24b7c: mov             x13, x14
    //     0xc24b80: b               #0xc24b88
    //     0xc24b84: mov             x13, NULL
    //     0xc24b88: lsl             x14, x3, #1
    //     0xc24b8c: lsl             w19, w14, #1
    //     0xc24b90: add             w20, w19, #8
    //     0xc24b94: add             x16, x4, w20, sxtw #1
    //     0xc24b98: ldur            w23, [x16, #0xf]
    //     0xc24b9c: add             x23, x23, HEAP, lsl #32
    //     0xc24ba0: add             x16, PP, #0x98, lsl #12  ; [pp+0x98fa0] "inactiveTrackColor"
    //     0xc24ba4: ldr             x16, [x16, #0xfa0]
    //     0xc24ba8: cmp             w23, w16
    //     0xc24bac: b.ne            #0xc24be0
    //     0xc24bb0: add             w3, w19, #0xa
    //     0xc24bb4: add             x16, x4, w3, sxtw #1
    //     0xc24bb8: ldur            w19, [x16, #0xf]
    //     0xc24bbc: add             x19, x19, HEAP, lsl #32
    //     0xc24bc0: sub             w3, w0, w19
    //     0xc24bc4: add             x19, fp, w3, sxtw #2
    //     0xc24bc8: ldr             x19, [x19, #8]
    //     0xc24bcc: add             w3, w14, #2
    //     0xc24bd0: sbfx            x14, x3, #1, #0x1f
    //     0xc24bd4: mov             x3, x14
    //     0xc24bd8: mov             x14, x19
    //     0xc24bdc: b               #0xc24be4
    //     0xc24be0: mov             x14, NULL
    //     0xc24be4: lsl             x19, x3, #1
    //     0xc24be8: lsl             w20, w19, #1
    //     0xc24bec: add             w23, w20, #8
    //     0xc24bf0: add             x16, x4, w23, sxtw #1
    //     0xc24bf4: ldur            w24, [x16, #0xf]
    //     0xc24bf8: add             x24, x24, HEAP, lsl #32
    //     0xc24bfc: add             x16, PP, #0x80, lsl #12  ; [pp+0x80c80] "overlayColor"
    //     0xc24c00: ldr             x16, [x16, #0xc80]
    //     0xc24c04: cmp             w24, w16
    //     0xc24c08: b.ne            #0xc24c3c
    //     0xc24c0c: add             w3, w20, #0xa
    //     0xc24c10: add             x16, x4, w3, sxtw #1
    //     0xc24c14: ldur            w20, [x16, #0xf]
    //     0xc24c18: add             x20, x20, HEAP, lsl #32
    //     0xc24c1c: sub             w3, w0, w20
    //     0xc24c20: add             x20, fp, w3, sxtw #2
    //     0xc24c24: ldr             x20, [x20, #8]
    //     0xc24c28: add             w3, w19, #2
    //     0xc24c2c: sbfx            x19, x3, #1, #0x1f
    //     0xc24c30: mov             x3, x19
    //     0xc24c34: mov             x19, x20
    //     0xc24c38: b               #0xc24c40
    //     0xc24c3c: mov             x19, NULL
    //     0xc24c40: stur            x19, [fp, #-0x20]
    //     0xc24c44: lsl             x20, x3, #1
    //     0xc24c48: lsl             w23, w20, #1
    //     0xc24c4c: add             w24, w23, #8
    //     0xc24c50: add             x16, x4, w24, sxtw #1
    //     0xc24c54: ldur            w25, [x16, #0xf]
    //     0xc24c58: add             x25, x25, HEAP, lsl #32
    //     0xc24c5c: add             x16, PP, #0x98, lsl #12  ; [pp+0x98fa8] "overlayShape"
    //     0xc24c60: ldr             x16, [x16, #0xfa8]
    //     0xc24c64: cmp             w25, w16
    //     0xc24c68: b.ne            #0xc24c9c
    //     0xc24c6c: add             w3, w23, #0xa
    //     0xc24c70: add             x16, x4, w3, sxtw #1
    //     0xc24c74: ldur            w23, [x16, #0xf]
    //     0xc24c78: add             x23, x23, HEAP, lsl #32
    //     0xc24c7c: sub             w3, w0, w23
    //     0xc24c80: add             x23, fp, w3, sxtw #2
    //     0xc24c84: ldr             x23, [x23, #8]
    //     0xc24c88: add             w3, w20, #2
    //     0xc24c8c: sbfx            x20, x3, #1, #0x1f
    //     0xc24c90: mov             x3, x20
    //     0xc24c94: mov             x20, x23
    //     0xc24c98: b               #0xc24ca0
    //     0xc24c9c: mov             x20, NULL
    //     0xc24ca0: stur            x20, [fp, #-0x10]
    //     0xc24ca4: lsl             x23, x3, #1
    //     0xc24ca8: lsl             w24, w23, #1
    //     0xc24cac: add             w25, w24, #8
    //     0xc24cb0: add             x16, x4, w25, sxtw #1
    //     0xc24cb4: ldur            w2, [x16, #0xf]
    //     0xc24cb8: add             x2, x2, HEAP, lsl #32
    //     0xc24cbc: add             x16, PP, #0x98, lsl #12  ; [pp+0x98fb0] "secondaryActiveTrackColor"
    //     0xc24cc0: ldr             x16, [x16, #0xfb0]
    //     0xc24cc4: cmp             w2, w16
    //     0xc24cc8: b.ne            #0xc24cf8
    //     0xc24ccc: add             w2, w24, #0xa
    //     0xc24cd0: add             x16, x4, w2, sxtw #1
    //     0xc24cd4: ldur            w3, [x16, #0xf]
    //     0xc24cd8: add             x3, x3, HEAP, lsl #32
    //     0xc24cdc: sub             w2, w0, w3
    //     0xc24ce0: add             x3, fp, w2, sxtw #2
    //     0xc24ce4: ldr             x3, [x3, #8]
    //     0xc24ce8: add             w2, w23, #2
    //     0xc24cec: sbfx            x23, x2, #1, #0x1f
    //     0xc24cf0: mov             x2, x23
    //     0xc24cf4: b               #0xc24d00
    //     0xc24cf8: mov             x2, x3
    //     0xc24cfc: mov             x3, NULL
    //     0xc24d00: lsl             x23, x2, #1
    //     0xc24d04: lsl             w24, w23, #1
    //     0xc24d08: add             w25, w24, #8
    //     0xc24d0c: add             x16, x4, w25, sxtw #1
    //     0xc24d10: ldur            w20, [x16, #0xf]
    //     0xc24d14: add             x20, x20, HEAP, lsl #32
    //     0xc24d18: add             x16, PP, #0x98, lsl #12  ; [pp+0x98fb8] "showValueIndicator"
    //     0xc24d1c: ldr             x16, [x16, #0xfb8]
    //     0xc24d20: cmp             w20, w16
    //     0xc24d24: b.ne            #0xc24d54
    //     0xc24d28: add             w2, w24, #0xa
    //     0xc24d2c: add             x16, x4, w2, sxtw #1
    //     0xc24d30: ldur            w20, [x16, #0xf]
    //     0xc24d34: add             x20, x20, HEAP, lsl #32
    //     0xc24d38: sub             w2, w0, w20
    //     0xc24d3c: add             x20, fp, w2, sxtw #2
    //     0xc24d40: ldr             x20, [x20, #8]
    //     0xc24d44: add             w2, w23, #2
    //     0xc24d48: sbfx            x23, x2, #1, #0x1f
    //     0xc24d4c: mov             x2, x23
    //     0xc24d50: b               #0xc24d58
    //     0xc24d54: mov             x20, NULL
    //     0xc24d58: stur            x20, [fp, #-0x18]
    //     0xc24d5c: lsl             x23, x2, #1
    //     0xc24d60: lsl             w24, w23, #1
    //     0xc24d64: add             w25, w24, #8
    //     0xc24d68: add             x16, x4, w25, sxtw #1
    //     0xc24d6c: ldur            w20, [x16, #0xf]
    //     0xc24d70: add             x20, x20, HEAP, lsl #32
    //     0xc24d74: add             x16, PP, #0x98, lsl #12  ; [pp+0x98fc0] "thumbColor"
    //     0xc24d78: ldr             x16, [x16, #0xfc0]
    //     0xc24d7c: cmp             w20, w16
    //     0xc24d80: b.ne            #0xc24db0
    //     0xc24d84: add             w2, w24, #0xa
    //     0xc24d88: add             x16, x4, w2, sxtw #1
    //     0xc24d8c: ldur            w20, [x16, #0xf]
    //     0xc24d90: add             x20, x20, HEAP, lsl #32
    //     0xc24d94: sub             w2, w0, w20
    //     0xc24d98: add             x20, fp, w2, sxtw #2
    //     0xc24d9c: ldr             x20, [x20, #8]
    //     0xc24da0: add             w2, w23, #2
    //     0xc24da4: sbfx            x23, x2, #1, #0x1f
    //     0xc24da8: mov             x2, x23
    //     0xc24dac: b               #0xc24db4
    //     0xc24db0: mov             x20, NULL
    //     0xc24db4: lsl             x23, x2, #1
    //     0xc24db8: lsl             w24, w23, #1
    //     0xc24dbc: add             w25, w24, #8
    //     0xc24dc0: add             x16, x4, w25, sxtw #1
    //     0xc24dc4: ldur            w19, [x16, #0xf]
    //     0xc24dc8: add             x19, x19, HEAP, lsl #32
    //     0xc24dcc: add             x16, PP, #0x98, lsl #12  ; [pp+0x98fc8] "thumbShape"
    //     0xc24dd0: ldr             x16, [x16, #0xfc8]
    //     0xc24dd4: cmp             w19, w16
    //     0xc24dd8: b.ne            #0xc24e08
    //     0xc24ddc: add             w2, w24, #0xa
    //     0xc24de0: add             x16, x4, w2, sxtw #1
    //     0xc24de4: ldur            w19, [x16, #0xf]
    //     0xc24de8: add             x19, x19, HEAP, lsl #32
    //     0xc24dec: sub             w2, w0, w19
    //     0xc24df0: add             x19, fp, w2, sxtw #2
    //     0xc24df4: ldr             x19, [x19, #8]
    //     0xc24df8: add             w2, w23, #2
    //     0xc24dfc: sbfx            x23, x2, #1, #0x1f
    //     0xc24e00: mov             x2, x23
    //     0xc24e04: b               #0xc24e0c
    //     0xc24e08: mov             x19, NULL
    //     0xc24e0c: stur            x19, [fp, #-0x28]
    //     0xc24e10: lsl             x23, x2, #1
    //     0xc24e14: lsl             w24, w23, #1
    //     0xc24e18: add             w25, w24, #8
    //     0xc24e1c: add             x16, x4, w25, sxtw #1
    //     0xc24e20: ldur            w19, [x16, #0xf]
    //     0xc24e24: add             x19, x19, HEAP, lsl #32
    //     0xc24e28: add             x16, PP, #0x98, lsl #12  ; [pp+0x98fd0] "tickMarkShape"
    //     0xc24e2c: ldr             x16, [x16, #0xfd0]
    //     0xc24e30: cmp             w19, w16
    //     0xc24e34: b.ne            #0xc24e64
    //     0xc24e38: add             w2, w24, #0xa
    //     0xc24e3c: add             x16, x4, w2, sxtw #1
    //     0xc24e40: ldur            w19, [x16, #0xf]
    //     0xc24e44: add             x19, x19, HEAP, lsl #32
    //     0xc24e48: sub             w2, w0, w19
    //     0xc24e4c: add             x19, fp, w2, sxtw #2
    //     0xc24e50: ldr             x19, [x19, #8]
    //     0xc24e54: add             w2, w23, #2
    //     0xc24e58: sbfx            x23, x2, #1, #0x1f
    //     0xc24e5c: mov             x2, x23
    //     0xc24e60: b               #0xc24e68
    //     0xc24e64: mov             x19, NULL
    //     0xc24e68: stur            x19, [fp, #-0x30]
    //     0xc24e6c: lsl             x23, x2, #1
    //     0xc24e70: lsl             w24, w23, #1
    //     0xc24e74: add             w25, w24, #8
    //     0xc24e78: add             x16, x4, w25, sxtw #1
    //     0xc24e7c: ldur            w19, [x16, #0xf]
    //     0xc24e80: add             x19, x19, HEAP, lsl #32
    //     0xc24e84: add             x16, PP, #0x98, lsl #12  ; [pp+0x98fd8] "trackHeight"
    //     0xc24e88: ldr             x16, [x16, #0xfd8]
    //     0xc24e8c: cmp             w19, w16
    //     0xc24e90: b.ne            #0xc24ec0
    //     0xc24e94: add             w2, w24, #0xa
    //     0xc24e98: add             x16, x4, w2, sxtw #1
    //     0xc24e9c: ldur            w19, [x16, #0xf]
    //     0xc24ea0: add             x19, x19, HEAP, lsl #32
    //     0xc24ea4: sub             w2, w0, w19
    //     0xc24ea8: add             x19, fp, w2, sxtw #2
    //     0xc24eac: ldr             x19, [x19, #8]
    //     0xc24eb0: add             w2, w23, #2
    //     0xc24eb4: sbfx            x23, x2, #1, #0x1f
    //     0xc24eb8: mov             x2, x23
    //     0xc24ebc: b               #0xc24ec4
    //     0xc24ec0: mov             x19, NULL
    //     0xc24ec4: lsl             x23, x2, #1
    //     0xc24ec8: lsl             w24, w23, #1
    //     0xc24ecc: add             w25, w24, #8
    //     0xc24ed0: add             x16, x4, w25, sxtw #1
    //     0xc24ed4: ldur            w12, [x16, #0xf]
    //     0xc24ed8: add             x12, x12, HEAP, lsl #32
    //     0xc24edc: add             x16, PP, #0x98, lsl #12  ; [pp+0x98fe0] "trackShape"
    //     0xc24ee0: ldr             x16, [x16, #0xfe0]
    //     0xc24ee4: cmp             w12, w16
    //     0xc24ee8: b.ne            #0xc24f18
    //     0xc24eec: add             w2, w24, #0xa
    //     0xc24ef0: add             x16, x4, w2, sxtw #1
    //     0xc24ef4: ldur            w12, [x16, #0xf]
    //     0xc24ef8: add             x12, x12, HEAP, lsl #32
    //     0xc24efc: sub             w2, w0, w12
    //     0xc24f00: add             x12, fp, w2, sxtw #2
    //     0xc24f04: ldr             x12, [x12, #8]
    //     0xc24f08: add             w2, w23, #2
    //     0xc24f0c: sbfx            x23, x2, #1, #0x1f
    //     0xc24f10: mov             x2, x23
    //     0xc24f14: b               #0xc24f1c
    //     0xc24f18: mov             x12, NULL
    //     0xc24f1c: stur            x12, [fp, #-0x40]
    //     0xc24f20: lsl             x23, x2, #1
    //     0xc24f24: lsl             w24, w23, #1
    //     0xc24f28: add             w25, w24, #8
    //     0xc24f2c: add             x16, x4, w25, sxtw #1
    //     0xc24f30: ldur            w12, [x16, #0xf]
    //     0xc24f34: add             x12, x12, HEAP, lsl #32
    //     0xc24f38: add             x16, PP, #0x98, lsl #12  ; [pp+0x98fe8] "valueIndicatorColor"
    //     0xc24f3c: ldr             x16, [x16, #0xfe8]
    //     0xc24f40: cmp             w12, w16
    //     0xc24f44: b.ne            #0xc24f74
    //     0xc24f48: add             w2, w24, #0xa
    //     0xc24f4c: add             x16, x4, w2, sxtw #1
    //     0xc24f50: ldur            w12, [x16, #0xf]
    //     0xc24f54: add             x12, x12, HEAP, lsl #32
    //     0xc24f58: sub             w2, w0, w12
    //     0xc24f5c: add             x12, fp, w2, sxtw #2
    //     0xc24f60: ldr             x12, [x12, #8]
    //     0xc24f64: add             w2, w23, #2
    //     0xc24f68: sbfx            x23, x2, #1, #0x1f
    //     0xc24f6c: mov             x2, x23
    //     0xc24f70: b               #0xc24f78
    //     0xc24f74: mov             x12, NULL
    //     0xc24f78: stur            x12, [fp, #-0x48]
    //     0xc24f7c: lsl             x23, x2, #1
    //     0xc24f80: lsl             w24, w23, #1
    //     0xc24f84: add             w25, w24, #8
    //     0xc24f88: add             x16, x4, w25, sxtw #1
    //     0xc24f8c: ldur            w12, [x16, #0xf]
    //     0xc24f90: add             x12, x12, HEAP, lsl #32
    //     0xc24f94: add             x16, PP, #0x98, lsl #12  ; [pp+0x98ff0] "valueIndicatorShape"
    //     0xc24f98: ldr             x16, [x16, #0xff0]
    //     0xc24f9c: cmp             w12, w16
    //     0xc24fa0: b.ne            #0xc24fd0
    //     0xc24fa4: add             w2, w24, #0xa
    //     0xc24fa8: add             x16, x4, w2, sxtw #1
    //     0xc24fac: ldur            w12, [x16, #0xf]
    //     0xc24fb0: add             x12, x12, HEAP, lsl #32
    //     0xc24fb4: sub             w2, w0, w12
    //     0xc24fb8: add             x12, fp, w2, sxtw #2
    //     0xc24fbc: ldr             x12, [x12, #8]
    //     0xc24fc0: add             w2, w23, #2
    //     0xc24fc4: sbfx            x23, x2, #1, #0x1f
    //     0xc24fc8: mov             x2, x23
    //     0xc24fcc: b               #0xc24fd4
    //     0xc24fd0: mov             x12, NULL
    //     0xc24fd4: lsl             x23, x2, #1
    //     0xc24fd8: lsl             w2, w23, #1
    //     0xc24fdc: add             w23, w2, #8
    //     0xc24fe0: add             x16, x4, w23, sxtw #1
    //     0xc24fe4: ldur            w24, [x16, #0xf]
    //     0xc24fe8: add             x24, x24, HEAP, lsl #32
    //     0xc24fec: add             x16, PP, #0x98, lsl #12  ; [pp+0x98ff8] "valueIndicatorTextStyle"
    //     0xc24ff0: ldr             x16, [x16, #0xff8]
    //     0xc24ff4: cmp             w24, w16
    //     0xc24ff8: b.ne            #0xc2501c
    //     0xc24ffc: add             w23, w2, #0xa
    //     0xc25000: add             x16, x4, w23, sxtw #1
    //     0xc25004: ldur            w2, [x16, #0xf]
    //     0xc25008: add             x2, x2, HEAP, lsl #32
    //     0xc2500c: sub             w4, w0, w2
    //     0xc25010: add             x0, fp, w4, sxtw #2
    //     0xc25014: ldr             x0, [x0, #8]
    //     0xc25018: b               #0xc25020
    //     0xc2501c: mov             x0, NULL
    // 0xc25020: cmp             w19, NULL
    // 0xc25024: b.ne            #0xc25034
    // 0xc25028: LoadField: r2 = r1->field_7
    //     0xc25028: ldur            w2, [x1, #7]
    // 0xc2502c: DecompressPointer r2
    //     0xc2502c: add             x2, x2, HEAP, lsl #32
    // 0xc25030: b               #0xc25038
    // 0xc25034: mov             x2, x19
    // 0xc25038: stur            x2, [fp, #-0x50]
    // 0xc2503c: cmp             w6, NULL
    // 0xc25040: b.ne            #0xc25050
    // 0xc25044: LoadField: r4 = r1->field_b
    //     0xc25044: ldur            w4, [x1, #0xb]
    // 0xc25048: DecompressPointer r4
    //     0xc25048: add             x4, x4, HEAP, lsl #32
    // 0xc2504c: b               #0xc25054
    // 0xc25050: mov             x4, x6
    // 0xc25054: stur            x4, [fp, #-0xc0]
    // 0xc25058: cmp             w14, NULL
    // 0xc2505c: b.ne            #0xc2506c
    // 0xc25060: LoadField: r6 = r1->field_f
    //     0xc25060: ldur            w6, [x1, #0xf]
    // 0xc25064: DecompressPointer r6
    //     0xc25064: add             x6, x6, HEAP, lsl #32
    // 0xc25068: b               #0xc25070
    // 0xc2506c: mov             x6, x14
    // 0xc25070: stur            x6, [fp, #-0xb8]
    // 0xc25074: cmp             w3, NULL
    // 0xc25078: b.ne            #0xc25084
    // 0xc2507c: LoadField: r3 = r1->field_13
    //     0xc2507c: ldur            w3, [x1, #0x13]
    // 0xc25080: DecompressPointer r3
    //     0xc25080: add             x3, x3, HEAP, lsl #32
    // 0xc25084: stur            x3, [fp, #-0xb0]
    // 0xc25088: cmp             w8, NULL
    // 0xc2508c: b.ne            #0xc25098
    // 0xc25090: ArrayLoad: r8 = r1[0]  ; List_4
    //     0xc25090: ldur            w8, [x1, #0x17]
    // 0xc25094: DecompressPointer r8
    //     0xc25094: add             x8, x8, HEAP, lsl #32
    // 0xc25098: stur            x8, [fp, #-0xa8]
    // 0xc2509c: cmp             w10, NULL
    // 0xc250a0: b.ne            #0xc250ac
    // 0xc250a4: LoadField: r10 = r1->field_1f
    //     0xc250a4: ldur            w10, [x1, #0x1f]
    // 0xc250a8: DecompressPointer r10
    //     0xc250a8: add             x10, x10, HEAP, lsl #32
    // 0xc250ac: stur            x10, [fp, #-0xa0]
    // 0xc250b0: cmp             w11, NULL
    // 0xc250b4: b.ne            #0xc250c0
    // 0xc250b8: LoadField: r11 = r1->field_1b
    //     0xc250b8: ldur            w11, [x1, #0x1b]
    // 0xc250bc: DecompressPointer r11
    //     0xc250bc: add             x11, x11, HEAP, lsl #32
    // 0xc250c0: stur            x11, [fp, #-0x98]
    // 0xc250c4: cmp             w5, NULL
    // 0xc250c8: b.ne            #0xc250d4
    // 0xc250cc: LoadField: r5 = r1->field_23
    //     0xc250cc: ldur            w5, [x1, #0x23]
    // 0xc250d0: DecompressPointer r5
    //     0xc250d0: add             x5, x5, HEAP, lsl #32
    // 0xc250d4: stur            x5, [fp, #-0x90]
    // 0xc250d8: cmp             w13, NULL
    // 0xc250dc: b.ne            #0xc250e8
    // 0xc250e0: LoadField: r13 = r1->field_27
    //     0xc250e0: ldur            w13, [x1, #0x27]
    // 0xc250e4: DecompressPointer r13
    //     0xc250e4: add             x13, x13, HEAP, lsl #32
    // 0xc250e8: stur            x13, [fp, #-0x88]
    // 0xc250ec: cmp             w7, NULL
    // 0xc250f0: b.ne            #0xc250fc
    // 0xc250f4: LoadField: r7 = r1->field_2b
    //     0xc250f4: ldur            w7, [x1, #0x2b]
    // 0xc250f8: DecompressPointer r7
    //     0xc250f8: add             x7, x7, HEAP, lsl #32
    // 0xc250fc: stur            x7, [fp, #-0x80]
    // 0xc25100: cmp             w9, NULL
    // 0xc25104: b.ne            #0xc25110
    // 0xc25108: LoadField: r9 = r1->field_2f
    //     0xc25108: ldur            w9, [x1, #0x2f]
    // 0xc2510c: DecompressPointer r9
    //     0xc2510c: add             x9, x9, HEAP, lsl #32
    // 0xc25110: stur            x9, [fp, #-0x78]
    // 0xc25114: cmp             w20, NULL
    // 0xc25118: b.ne            #0xc2512c
    // 0xc2511c: LoadField: r14 = r1->field_33
    //     0xc2511c: ldur            w14, [x1, #0x33]
    // 0xc25120: DecompressPointer r14
    //     0xc25120: add             x14, x14, HEAP, lsl #32
    // 0xc25124: mov             x19, x14
    // 0xc25128: b               #0xc25130
    // 0xc2512c: mov             x19, x20
    // 0xc25130: ldur            x14, [fp, #-0x38]
    // 0xc25134: stur            x19, [fp, #-0x70]
    // 0xc25138: cmp             w14, NULL
    // 0xc2513c: b.ne            #0xc25150
    // 0xc25140: LoadField: r14 = r1->field_3b
    //     0xc25140: ldur            w14, [x1, #0x3b]
    // 0xc25144: DecompressPointer r14
    //     0xc25144: add             x14, x14, HEAP, lsl #32
    // 0xc25148: mov             x20, x14
    // 0xc2514c: b               #0xc25154
    // 0xc25150: mov             x20, x14
    // 0xc25154: ldur            x14, [fp, #-0x20]
    // 0xc25158: stur            x20, [fp, #-0x68]
    // 0xc2515c: cmp             w14, NULL
    // 0xc25160: b.ne            #0xc25174
    // 0xc25164: LoadField: r14 = r1->field_3f
    //     0xc25164: ldur            w14, [x1, #0x3f]
    // 0xc25168: DecompressPointer r14
    //     0xc25168: add             x14, x14, HEAP, lsl #32
    // 0xc2516c: mov             x23, x14
    // 0xc25170: b               #0xc25178
    // 0xc25174: mov             x23, x14
    // 0xc25178: ldur            x14, [fp, #-0x48]
    // 0xc2517c: stur            x23, [fp, #-0x60]
    // 0xc25180: cmp             w14, NULL
    // 0xc25184: b.ne            #0xc25198
    // 0xc25188: LoadField: r14 = r1->field_43
    //     0xc25188: ldur            w14, [x1, #0x43]
    // 0xc2518c: DecompressPointer r14
    //     0xc2518c: add             x14, x14, HEAP, lsl #32
    // 0xc25190: mov             x24, x14
    // 0xc25194: b               #0xc2519c
    // 0xc25198: mov             x24, x14
    // 0xc2519c: ldur            x14, [fp, #-0x10]
    // 0xc251a0: stur            x24, [fp, #-0x58]
    // 0xc251a4: cmp             w14, NULL
    // 0xc251a8: b.ne            #0xc251bc
    // 0xc251ac: LoadField: r14 = r1->field_4b
    //     0xc251ac: ldur            w14, [x1, #0x4b]
    // 0xc251b0: DecompressPointer r14
    //     0xc251b0: add             x14, x14, HEAP, lsl #32
    // 0xc251b4: mov             x25, x14
    // 0xc251b8: b               #0xc251c0
    // 0xc251bc: mov             x25, x14
    // 0xc251c0: ldur            x14, [fp, #-0x30]
    // 0xc251c4: stur            x25, [fp, #-0x48]
    // 0xc251c8: cmp             w14, NULL
    // 0xc251cc: b.ne            #0xc251e0
    // 0xc251d0: LoadField: r14 = r1->field_4f
    //     0xc251d0: ldur            w14, [x1, #0x4f]
    // 0xc251d4: DecompressPointer r14
    //     0xc251d4: add             x14, x14, HEAP, lsl #32
    // 0xc251d8: stur            x14, [fp, #-0x10]
    // 0xc251dc: b               #0xc251e4
    // 0xc251e0: stur            x14, [fp, #-0x10]
    // 0xc251e4: ldur            x14, [fp, #-0x28]
    // 0xc251e8: cmp             w14, NULL
    // 0xc251ec: b.ne            #0xc25200
    // 0xc251f0: LoadField: r14 = r1->field_53
    //     0xc251f0: ldur            w14, [x1, #0x53]
    // 0xc251f4: DecompressPointer r14
    //     0xc251f4: add             x14, x14, HEAP, lsl #32
    // 0xc251f8: stur            x14, [fp, #-0x20]
    // 0xc251fc: b               #0xc25204
    // 0xc25200: stur            x14, [fp, #-0x20]
    // 0xc25204: ldur            x14, [fp, #-0x40]
    // 0xc25208: cmp             w14, NULL
    // 0xc2520c: b.ne            #0xc25218
    // 0xc25210: LoadField: r14 = r1->field_57
    //     0xc25210: ldur            w14, [x1, #0x57]
    // 0xc25214: DecompressPointer r14
    //     0xc25214: add             x14, x14, HEAP, lsl #32
    // 0xc25218: stur            x14, [fp, #-0x40]
    // 0xc2521c: cmp             w12, NULL
    // 0xc25220: b.ne            #0xc25234
    // 0xc25224: LoadField: r12 = r1->field_5b
    //     0xc25224: ldur            w12, [x1, #0x5b]
    // 0xc25228: DecompressPointer r12
    //     0xc25228: add             x12, x12, HEAP, lsl #32
    // 0xc2522c: stur            x12, [fp, #-0x28]
    // 0xc25230: b               #0xc25238
    // 0xc25234: stur            x12, [fp, #-0x28]
    // 0xc25238: ldur            x12, [fp, #-0x18]
    // 0xc2523c: cmp             w12, NULL
    // 0xc25240: b.ne            #0xc2524c
    // 0xc25244: LoadField: r12 = r1->field_6f
    //     0xc25244: ldur            w12, [x1, #0x6f]
    // 0xc25248: DecompressPointer r12
    //     0xc25248: add             x12, x12, HEAP, lsl #32
    // 0xc2524c: stur            x12, [fp, #-0x38]
    // 0xc25250: cmp             w0, NULL
    // 0xc25254: b.ne            #0xc25268
    // 0xc25258: LoadField: r0 = r1->field_73
    //     0xc25258: ldur            w0, [x1, #0x73]
    // 0xc2525c: DecompressPointer r0
    //     0xc2525c: add             x0, x0, HEAP, lsl #32
    // 0xc25260: stur            x0, [fp, #-0x18]
    // 0xc25264: b               #0xc2526c
    // 0xc25268: stur            x0, [fp, #-0x18]
    // 0xc2526c: ldur            x0, [fp, #-8]
    // 0xc25270: LoadField: r2 = r1->field_77
    //     0xc25270: ldur            w2, [x1, #0x77]
    // 0xc25274: DecompressPointer r2
    //     0xc25274: add             x2, x2, HEAP, lsl #32
    // 0xc25278: stur            x2, [fp, #-0x30]
    // 0xc2527c: cmp             w0, NULL
    // 0xc25280: b.ne            #0xc25294
    // 0xc25284: LoadField: r0 = r1->field_8f
    //     0xc25284: ldur            w0, [x1, #0x8f]
    // 0xc25288: DecompressPointer r0
    //     0xc25288: add             x0, x0, HEAP, lsl #32
    // 0xc2528c: stur            x0, [fp, #-8]
    // 0xc25290: b               #0xc25298
    // 0xc25294: stur            x0, [fp, #-8]
    // 0xc25298: mov             x0, x2
    // 0xc2529c: ldur            x2, [fp, #-0x28]
    // 0xc252a0: ldur            x1, [fp, #-0x18]
    // 0xc252a4: r0 = SliderThemeData()
    //     0xc252a4: bl              #0xc25374  ; AllocateSliderThemeDataStub -> SliderThemeData (size=0x98)
    // 0xc252a8: ldur            x1, [fp, #-0x50]
    // 0xc252ac: StoreField: r0->field_7 = r1
    //     0xc252ac: stur            w1, [x0, #7]
    // 0xc252b0: ldur            x1, [fp, #-0xc0]
    // 0xc252b4: StoreField: r0->field_b = r1
    //     0xc252b4: stur            w1, [x0, #0xb]
    // 0xc252b8: ldur            x1, [fp, #-0xb8]
    // 0xc252bc: StoreField: r0->field_f = r1
    //     0xc252bc: stur            w1, [x0, #0xf]
    // 0xc252c0: ldur            x1, [fp, #-0xb0]
    // 0xc252c4: StoreField: r0->field_13 = r1
    //     0xc252c4: stur            w1, [x0, #0x13]
    // 0xc252c8: ldur            x1, [fp, #-0xa8]
    // 0xc252cc: ArrayStore: r0[0] = r1  ; List_4
    //     0xc252cc: stur            w1, [x0, #0x17]
    // 0xc252d0: ldur            x1, [fp, #-0xa0]
    // 0xc252d4: StoreField: r0->field_1f = r1
    //     0xc252d4: stur            w1, [x0, #0x1f]
    // 0xc252d8: ldur            x1, [fp, #-0x98]
    // 0xc252dc: StoreField: r0->field_1b = r1
    //     0xc252dc: stur            w1, [x0, #0x1b]
    // 0xc252e0: ldur            x1, [fp, #-0x90]
    // 0xc252e4: StoreField: r0->field_23 = r1
    //     0xc252e4: stur            w1, [x0, #0x23]
    // 0xc252e8: ldur            x1, [fp, #-0x88]
    // 0xc252ec: StoreField: r0->field_27 = r1
    //     0xc252ec: stur            w1, [x0, #0x27]
    // 0xc252f0: ldur            x1, [fp, #-0x80]
    // 0xc252f4: StoreField: r0->field_2b = r1
    //     0xc252f4: stur            w1, [x0, #0x2b]
    // 0xc252f8: ldur            x1, [fp, #-0x78]
    // 0xc252fc: StoreField: r0->field_2f = r1
    //     0xc252fc: stur            w1, [x0, #0x2f]
    // 0xc25300: ldur            x1, [fp, #-0x70]
    // 0xc25304: StoreField: r0->field_33 = r1
    //     0xc25304: stur            w1, [x0, #0x33]
    // 0xc25308: ldur            x1, [fp, #-0x68]
    // 0xc2530c: StoreField: r0->field_3b = r1
    //     0xc2530c: stur            w1, [x0, #0x3b]
    // 0xc25310: ldur            x1, [fp, #-0x60]
    // 0xc25314: StoreField: r0->field_3f = r1
    //     0xc25314: stur            w1, [x0, #0x3f]
    // 0xc25318: ldur            x1, [fp, #-0x58]
    // 0xc2531c: StoreField: r0->field_43 = r1
    //     0xc2531c: stur            w1, [x0, #0x43]
    // 0xc25320: ldur            x1, [fp, #-0x48]
    // 0xc25324: StoreField: r0->field_4b = r1
    //     0xc25324: stur            w1, [x0, #0x4b]
    // 0xc25328: ldur            x1, [fp, #-0x10]
    // 0xc2532c: StoreField: r0->field_4f = r1
    //     0xc2532c: stur            w1, [x0, #0x4f]
    // 0xc25330: ldur            x1, [fp, #-0x20]
    // 0xc25334: StoreField: r0->field_53 = r1
    //     0xc25334: stur            w1, [x0, #0x53]
    // 0xc25338: ldur            x1, [fp, #-0x40]
    // 0xc2533c: StoreField: r0->field_57 = r1
    //     0xc2533c: stur            w1, [x0, #0x57]
    // 0xc25340: ldur            x1, [fp, #-0x28]
    // 0xc25344: StoreField: r0->field_5b = r1
    //     0xc25344: stur            w1, [x0, #0x5b]
    // 0xc25348: ldur            x1, [fp, #-0x38]
    // 0xc2534c: StoreField: r0->field_6f = r1
    //     0xc2534c: stur            w1, [x0, #0x6f]
    // 0xc25350: ldur            x1, [fp, #-0x18]
    // 0xc25354: StoreField: r0->field_73 = r1
    //     0xc25354: stur            w1, [x0, #0x73]
    // 0xc25358: ldur            x1, [fp, #-0x30]
    // 0xc2535c: StoreField: r0->field_77 = r1
    //     0xc2535c: stur            w1, [x0, #0x77]
    // 0xc25360: ldur            x1, [fp, #-8]
    // 0xc25364: StoreField: r0->field_8f = r1
    //     0xc25364: stur            w1, [x0, #0x8f]
    // 0xc25368: LeaveFrame
    //     0xc25368: mov             SP, fp
    //     0xc2536c: ldp             fp, lr, [SP], #0x10
    // 0xc25370: ret
    //     0xc25370: ret             
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x1135b70, size: 0x1368
    // 0x1135b70: EnterFrame
    //     0x1135b70: stp             fp, lr, [SP, #-0x10]!
    //     0x1135b74: mov             fp, SP
    // 0x1135b78: AllocStack(0x150)
    //     0x1135b78: sub             SP, SP, #0x150
    // 0x1135b7c: CheckStackOverflow
    //     0x1135b7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1135b80: cmp             SP, x16
    //     0x1135b84: b.ls            #0x1136ecc
    // 0x1135b88: ldr             x0, [fp, #0x10]
    // 0x1135b8c: LoadField: r2 = r0->field_7
    //     0x1135b8c: ldur            w2, [x0, #7]
    // 0x1135b90: DecompressPointer r2
    //     0x1135b90: add             x2, x2, HEAP, lsl #32
    // 0x1135b94: stur            x2, [fp, #-0x10]
    // 0x1135b98: r3 = LoadClassIdInstr(r0)
    //     0x1135b98: ldur            x3, [x0, #-1]
    //     0x1135b9c: ubfx            x3, x3, #0xc, #0x14
    // 0x1135ba0: stur            x3, [fp, #-8]
    // 0x1135ba4: r17 = 5069
    //     0x1135ba4: mov             x17, #0x13cd
    // 0x1135ba8: cmp             x3, x17
    // 0x1135bac: b.ne            #0x1135bc4
    // 0x1135bb0: LoadField: r1 = r0->field_b
    //     0x1135bb0: ldur            w1, [x0, #0xb]
    // 0x1135bb4: DecompressPointer r1
    //     0x1135bb4: add             x1, x1, HEAP, lsl #32
    // 0x1135bb8: mov             x2, x1
    // 0x1135bbc: mov             x0, x3
    // 0x1135bc0: b               #0x1135c48
    // 0x1135bc4: r17 = 5070
    //     0x1135bc4: mov             x17, #0x13ce
    // 0x1135bc8: cmp             x3, x17
    // 0x1135bcc: b.eq            #0x1136c20
    // 0x1135bd0: r17 = 5071
    //     0x1135bd0: mov             x17, #0x13cf
    // 0x1135bd4: cmp             x3, x17
    // 0x1135bd8: b.ne            #0x1135c14
    // 0x1135bdc: mov             x1, x0
    // 0x1135be0: LoadField: r0 = r1->field_9b
    //     0x1135be0: ldur            w0, [x1, #0x9b]
    // 0x1135be4: DecompressPointer r0
    //     0x1135be4: add             x0, x0, HEAP, lsl #32
    // 0x1135be8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1135bec: cmp             w0, w16
    // 0x1135bf0: b.ne            #0x1135c00
    // 0x1135bf4: r2 = _colors
    //     0x1135bf4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1135bf8: ldr             x2, [x2, #0xa10]
    // 0x1135bfc: r0 = InitLateFinalInstanceField()
    //     0x1135bfc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1135c00: LoadField: r1 = r0->field_b
    //     0x1135c00: ldur            w1, [x0, #0xb]
    // 0x1135c04: DecompressPointer r1
    //     0x1135c04: add             x1, x1, HEAP, lsl #32
    // 0x1135c08: mov             x2, x1
    // 0x1135c0c: ldur            x0, [fp, #-8]
    // 0x1135c10: b               #0x1135c48
    // 0x1135c14: ldr             x1, [fp, #0x10]
    // 0x1135c18: LoadField: r0 = r1->field_9b
    //     0x1135c18: ldur            w0, [x1, #0x9b]
    // 0x1135c1c: DecompressPointer r0
    //     0x1135c1c: add             x0, x0, HEAP, lsl #32
    // 0x1135c20: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1135c24: cmp             w0, w16
    // 0x1135c28: b.ne            #0x1135c38
    // 0x1135c2c: r2 = _colors
    //     0x1135c2c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1135c30: ldr             x2, [x2, #0xa18]
    // 0x1135c34: r0 = InitLateFinalInstanceField()
    //     0x1135c34: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1135c38: LoadField: r1 = r0->field_b
    //     0x1135c38: ldur            w1, [x0, #0xb]
    // 0x1135c3c: DecompressPointer r1
    //     0x1135c3c: add             x1, x1, HEAP, lsl #32
    // 0x1135c40: mov             x2, x1
    // 0x1135c44: ldur            x0, [fp, #-8]
    // 0x1135c48: stur            x2, [fp, #-0x18]
    // 0x1135c4c: r17 = 5069
    //     0x1135c4c: mov             x17, #0x13cd
    // 0x1135c50: cmp             x0, x17
    // 0x1135c54: b.ne            #0x1135c6c
    // 0x1135c58: ldr             x3, [fp, #0x10]
    // 0x1135c5c: LoadField: r1 = r3->field_f
    //     0x1135c5c: ldur            w1, [x3, #0xf]
    // 0x1135c60: DecompressPointer r1
    //     0x1135c60: add             x1, x1, HEAP, lsl #32
    // 0x1135c64: mov             x2, x1
    // 0x1135c68: b               #0x1135d1c
    // 0x1135c6c: ldr             x3, [fp, #0x10]
    // 0x1135c70: r17 = 5070
    //     0x1135c70: mov             x17, #0x13ce
    // 0x1135c74: cmp             x0, x17
    // 0x1135c78: b.eq            #0x1136c50
    // 0x1135c7c: r17 = 5071
    //     0x1135c7c: mov             x17, #0x13cf
    // 0x1135c80: cmp             x0, x17
    // 0x1135c84: b.ne            #0x1135cdc
    // 0x1135c88: mov             x1, x3
    // 0x1135c8c: LoadField: r0 = r1->field_9b
    //     0x1135c8c: ldur            w0, [x1, #0x9b]
    // 0x1135c90: DecompressPointer r0
    //     0x1135c90: add             x0, x0, HEAP, lsl #32
    // 0x1135c94: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1135c98: cmp             w0, w16
    // 0x1135c9c: b.ne            #0x1135cac
    // 0x1135ca0: r2 = _colors
    //     0x1135ca0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1135ca4: ldr             x2, [x2, #0xa10]
    // 0x1135ca8: r0 = InitLateFinalInstanceField()
    //     0x1135ca8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1135cac: LoadField: r1 = r0->field_9f
    //     0x1135cac: ldur            w1, [x0, #0x9f]
    // 0x1135cb0: DecompressPointer r1
    //     0x1135cb0: add             x1, x1, HEAP, lsl #32
    // 0x1135cb4: cmp             w1, NULL
    // 0x1135cb8: b.ne            #0x1135ccc
    // 0x1135cbc: LoadField: r1 = r0->field_7b
    //     0x1135cbc: ldur            w1, [x0, #0x7b]
    // 0x1135cc0: DecompressPointer r1
    //     0x1135cc0: add             x1, x1, HEAP, lsl #32
    // 0x1135cc4: mov             x0, x1
    // 0x1135cc8: b               #0x1135cd0
    // 0x1135ccc: mov             x0, x1
    // 0x1135cd0: mov             x2, x0
    // 0x1135cd4: ldur            x0, [fp, #-8]
    // 0x1135cd8: b               #0x1135d1c
    // 0x1135cdc: ldr             x1, [fp, #0x10]
    // 0x1135ce0: LoadField: r0 = r1->field_9b
    //     0x1135ce0: ldur            w0, [x1, #0x9b]
    // 0x1135ce4: DecompressPointer r0
    //     0x1135ce4: add             x0, x0, HEAP, lsl #32
    // 0x1135ce8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1135cec: cmp             w0, w16
    // 0x1135cf0: b.ne            #0x1135d00
    // 0x1135cf4: r2 = _colors
    //     0x1135cf4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1135cf8: ldr             x2, [x2, #0xa18]
    // 0x1135cfc: r0 = InitLateFinalInstanceField()
    //     0x1135cfc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1135d00: LoadField: r1 = r0->field_b
    //     0x1135d00: ldur            w1, [x0, #0xb]
    // 0x1135d04: DecompressPointer r1
    //     0x1135d04: add             x1, x1, HEAP, lsl #32
    // 0x1135d08: d0 = 0.240000
    //     0x1135d08: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a20] IMM: double(0.24) from 0x3fceb851eb851eb8
    //     0x1135d0c: ldr             d0, [x17, #0xa20]
    // 0x1135d10: r0 = withOpacity()
    //     0x1135d10: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1135d14: mov             x2, x0
    // 0x1135d18: ldur            x0, [fp, #-8]
    // 0x1135d1c: stur            x2, [fp, #-0x20]
    // 0x1135d20: r17 = 5069
    //     0x1135d20: mov             x17, #0x13cd
    // 0x1135d24: cmp             x0, x17
    // 0x1135d28: b.ne            #0x1135d40
    // 0x1135d2c: ldr             x3, [fp, #0x10]
    // 0x1135d30: LoadField: r1 = r3->field_13
    //     0x1135d30: ldur            w1, [x3, #0x13]
    // 0x1135d34: DecompressPointer r1
    //     0x1135d34: add             x1, x1, HEAP, lsl #32
    // 0x1135d38: mov             x2, x1
    // 0x1135d3c: b               #0x1135de0
    // 0x1135d40: ldr             x3, [fp, #0x10]
    // 0x1135d44: r17 = 5070
    //     0x1135d44: mov             x17, #0x13ce
    // 0x1135d48: cmp             x0, x17
    // 0x1135d4c: b.eq            #0x1136c84
    // 0x1135d50: r17 = 5071
    //     0x1135d50: mov             x17, #0x13cf
    // 0x1135d54: cmp             x0, x17
    // 0x1135d58: b.ne            #0x1135da0
    // 0x1135d5c: mov             x1, x3
    // 0x1135d60: LoadField: r0 = r1->field_9b
    //     0x1135d60: ldur            w0, [x1, #0x9b]
    // 0x1135d64: DecompressPointer r0
    //     0x1135d64: add             x0, x0, HEAP, lsl #32
    // 0x1135d68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1135d6c: cmp             w0, w16
    // 0x1135d70: b.ne            #0x1135d80
    // 0x1135d74: r2 = _colors
    //     0x1135d74: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1135d78: ldr             x2, [x2, #0xa10]
    // 0x1135d7c: r0 = InitLateFinalInstanceField()
    //     0x1135d7c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1135d80: LoadField: r1 = r0->field_b
    //     0x1135d80: ldur            w1, [x0, #0xb]
    // 0x1135d84: DecompressPointer r1
    //     0x1135d84: add             x1, x1, HEAP, lsl #32
    // 0x1135d88: d0 = 0.540000
    //     0x1135d88: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a28] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0x1135d8c: ldr             d0, [x17, #0xa28]
    // 0x1135d90: r0 = withOpacity()
    //     0x1135d90: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1135d94: mov             x2, x0
    // 0x1135d98: ldur            x0, [fp, #-8]
    // 0x1135d9c: b               #0x1135de0
    // 0x1135da0: ldr             x1, [fp, #0x10]
    // 0x1135da4: LoadField: r0 = r1->field_9b
    //     0x1135da4: ldur            w0, [x1, #0x9b]
    // 0x1135da8: DecompressPointer r0
    //     0x1135da8: add             x0, x0, HEAP, lsl #32
    // 0x1135dac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1135db0: cmp             w0, w16
    // 0x1135db4: b.ne            #0x1135dc4
    // 0x1135db8: r2 = _colors
    //     0x1135db8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1135dbc: ldr             x2, [x2, #0xa18]
    // 0x1135dc0: r0 = InitLateFinalInstanceField()
    //     0x1135dc0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1135dc4: LoadField: r1 = r0->field_b
    //     0x1135dc4: ldur            w1, [x0, #0xb]
    // 0x1135dc8: DecompressPointer r1
    //     0x1135dc8: add             x1, x1, HEAP, lsl #32
    // 0x1135dcc: d0 = 0.540000
    //     0x1135dcc: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a28] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0x1135dd0: ldr             d0, [x17, #0xa28]
    // 0x1135dd4: r0 = withOpacity()
    //     0x1135dd4: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1135dd8: mov             x2, x0
    // 0x1135ddc: ldur            x0, [fp, #-8]
    // 0x1135de0: stur            x2, [fp, #-0x28]
    // 0x1135de4: r17 = 5069
    //     0x1135de4: mov             x17, #0x13cd
    // 0x1135de8: cmp             x0, x17
    // 0x1135dec: b.ne            #0x1135e04
    // 0x1135df0: ldr             x3, [fp, #0x10]
    // 0x1135df4: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x1135df4: ldur            w1, [x3, #0x17]
    // 0x1135df8: DecompressPointer r1
    //     0x1135df8: add             x1, x1, HEAP, lsl #32
    // 0x1135dfc: mov             x2, x1
    // 0x1135e00: b               #0x1135ec4
    // 0x1135e04: ldr             x3, [fp, #0x10]
    // 0x1135e08: r17 = 5070
    //     0x1135e08: mov             x17, #0x13ce
    // 0x1135e0c: cmp             x0, x17
    // 0x1135e10: b.eq            #0x1136cb8
    // 0x1135e14: r17 = 5071
    //     0x1135e14: mov             x17, #0x13cf
    // 0x1135e18: cmp             x0, x17
    // 0x1135e1c: b.ne            #0x1135e74
    // 0x1135e20: mov             x1, x3
    // 0x1135e24: LoadField: r0 = r1->field_9b
    //     0x1135e24: ldur            w0, [x1, #0x9b]
    // 0x1135e28: DecompressPointer r0
    //     0x1135e28: add             x0, x0, HEAP, lsl #32
    // 0x1135e2c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1135e30: cmp             w0, w16
    // 0x1135e34: b.ne            #0x1135e44
    // 0x1135e38: r2 = _colors
    //     0x1135e38: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1135e3c: ldr             x2, [x2, #0xa10]
    // 0x1135e40: r0 = InitLateFinalInstanceField()
    //     0x1135e40: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1135e44: LoadField: r1 = r0->field_7f
    //     0x1135e44: ldur            w1, [x0, #0x7f]
    // 0x1135e48: DecompressPointer r1
    //     0x1135e48: add             x1, x1, HEAP, lsl #32
    // 0x1135e4c: r0 = LoadClassIdInstr(r1)
    //     0x1135e4c: ldur            x0, [x1, #-1]
    //     0x1135e50: ubfx            x0, x0, #0xc, #0x14
    // 0x1135e54: d0 = 0.380000
    //     0x1135e54: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1135e58: ldr             d0, [x17, #0x1f0]
    // 0x1135e5c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1135e5c: sub             lr, x0, #1, lsl #12
    //     0x1135e60: ldr             lr, [x21, lr, lsl #3]
    //     0x1135e64: blr             lr
    // 0x1135e68: mov             x2, x0
    // 0x1135e6c: ldur            x0, [fp, #-8]
    // 0x1135e70: b               #0x1135ec4
    // 0x1135e74: ldr             x1, [fp, #0x10]
    // 0x1135e78: LoadField: r0 = r1->field_9b
    //     0x1135e78: ldur            w0, [x1, #0x9b]
    // 0x1135e7c: DecompressPointer r0
    //     0x1135e7c: add             x0, x0, HEAP, lsl #32
    // 0x1135e80: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1135e84: cmp             w0, w16
    // 0x1135e88: b.ne            #0x1135e98
    // 0x1135e8c: r2 = _colors
    //     0x1135e8c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1135e90: ldr             x2, [x2, #0xa18]
    // 0x1135e94: r0 = InitLateFinalInstanceField()
    //     0x1135e94: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1135e98: LoadField: r1 = r0->field_7f
    //     0x1135e98: ldur            w1, [x0, #0x7f]
    // 0x1135e9c: DecompressPointer r1
    //     0x1135e9c: add             x1, x1, HEAP, lsl #32
    // 0x1135ea0: r0 = LoadClassIdInstr(r1)
    //     0x1135ea0: ldur            x0, [x1, #-1]
    //     0x1135ea4: ubfx            x0, x0, #0xc, #0x14
    // 0x1135ea8: d0 = 0.320000
    //     0x1135ea8: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a30] IMM: double(0.32) from 0x3fd47ae147ae147b
    //     0x1135eac: ldr             d0, [x17, #0xa30]
    // 0x1135eb0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1135eb0: sub             lr, x0, #1, lsl #12
    //     0x1135eb4: ldr             lr, [x21, lr, lsl #3]
    //     0x1135eb8: blr             lr
    // 0x1135ebc: mov             x2, x0
    // 0x1135ec0: ldur            x0, [fp, #-8]
    // 0x1135ec4: stur            x2, [fp, #-0x30]
    // 0x1135ec8: r17 = 5069
    //     0x1135ec8: mov             x17, #0x13cd
    // 0x1135ecc: cmp             x0, x17
    // 0x1135ed0: b.ne            #0x1135ee8
    // 0x1135ed4: ldr             x3, [fp, #0x10]
    // 0x1135ed8: LoadField: r1 = r3->field_1f
    //     0x1135ed8: ldur            w1, [x3, #0x1f]
    // 0x1135edc: DecompressPointer r1
    //     0x1135edc: add             x1, x1, HEAP, lsl #32
    // 0x1135ee0: mov             x2, x1
    // 0x1135ee4: b               #0x1135fa8
    // 0x1135ee8: ldr             x3, [fp, #0x10]
    // 0x1135eec: r17 = 5070
    //     0x1135eec: mov             x17, #0x13ce
    // 0x1135ef0: cmp             x0, x17
    // 0x1135ef4: b.eq            #0x1136cec
    // 0x1135ef8: r17 = 5071
    //     0x1135ef8: mov             x17, #0x13cf
    // 0x1135efc: cmp             x0, x17
    // 0x1135f00: b.ne            #0x1135f58
    // 0x1135f04: mov             x1, x3
    // 0x1135f08: LoadField: r0 = r1->field_9b
    //     0x1135f08: ldur            w0, [x1, #0x9b]
    // 0x1135f0c: DecompressPointer r0
    //     0x1135f0c: add             x0, x0, HEAP, lsl #32
    // 0x1135f10: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1135f14: cmp             w0, w16
    // 0x1135f18: b.ne            #0x1135f28
    // 0x1135f1c: r2 = _colors
    //     0x1135f1c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1135f20: ldr             x2, [x2, #0xa10]
    // 0x1135f24: r0 = InitLateFinalInstanceField()
    //     0x1135f24: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1135f28: LoadField: r1 = r0->field_7f
    //     0x1135f28: ldur            w1, [x0, #0x7f]
    // 0x1135f2c: DecompressPointer r1
    //     0x1135f2c: add             x1, x1, HEAP, lsl #32
    // 0x1135f30: r0 = LoadClassIdInstr(r1)
    //     0x1135f30: ldur            x0, [x1, #-1]
    //     0x1135f34: ubfx            x0, x0, #0xc, #0x14
    // 0x1135f38: d0 = 0.120000
    //     0x1135f38: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x1135f3c: ldr             d0, [x17, #0xc40]
    // 0x1135f40: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1135f40: sub             lr, x0, #1, lsl #12
    //     0x1135f44: ldr             lr, [x21, lr, lsl #3]
    //     0x1135f48: blr             lr
    // 0x1135f4c: mov             x2, x0
    // 0x1135f50: ldur            x0, [fp, #-8]
    // 0x1135f54: b               #0x1135fa8
    // 0x1135f58: ldr             x1, [fp, #0x10]
    // 0x1135f5c: LoadField: r0 = r1->field_9b
    //     0x1135f5c: ldur            w0, [x1, #0x9b]
    // 0x1135f60: DecompressPointer r0
    //     0x1135f60: add             x0, x0, HEAP, lsl #32
    // 0x1135f64: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1135f68: cmp             w0, w16
    // 0x1135f6c: b.ne            #0x1135f7c
    // 0x1135f70: r2 = _colors
    //     0x1135f70: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1135f74: ldr             x2, [x2, #0xa18]
    // 0x1135f78: r0 = InitLateFinalInstanceField()
    //     0x1135f78: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1135f7c: LoadField: r1 = r0->field_7f
    //     0x1135f7c: ldur            w1, [x0, #0x7f]
    // 0x1135f80: DecompressPointer r1
    //     0x1135f80: add             x1, x1, HEAP, lsl #32
    // 0x1135f84: r0 = LoadClassIdInstr(r1)
    //     0x1135f84: ldur            x0, [x1, #-1]
    //     0x1135f88: ubfx            x0, x0, #0xc, #0x14
    // 0x1135f8c: d0 = 0.120000
    //     0x1135f8c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x1135f90: ldr             d0, [x17, #0xc40]
    // 0x1135f94: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1135f94: sub             lr, x0, #1, lsl #12
    //     0x1135f98: ldr             lr, [x21, lr, lsl #3]
    //     0x1135f9c: blr             lr
    // 0x1135fa0: mov             x2, x0
    // 0x1135fa4: ldur            x0, [fp, #-8]
    // 0x1135fa8: stur            x2, [fp, #-0x38]
    // 0x1135fac: r17 = 5069
    //     0x1135fac: mov             x17, #0x13cd
    // 0x1135fb0: cmp             x0, x17
    // 0x1135fb4: b.ne            #0x1135fcc
    // 0x1135fb8: ldr             x3, [fp, #0x10]
    // 0x1135fbc: LoadField: r1 = r3->field_1b
    //     0x1135fbc: ldur            w1, [x3, #0x1b]
    // 0x1135fc0: DecompressPointer r1
    //     0x1135fc0: add             x1, x1, HEAP, lsl #32
    // 0x1135fc4: mov             x2, x1
    // 0x1135fc8: b               #0x113608c
    // 0x1135fcc: ldr             x3, [fp, #0x10]
    // 0x1135fd0: r17 = 5070
    //     0x1135fd0: mov             x17, #0x13ce
    // 0x1135fd4: cmp             x0, x17
    // 0x1135fd8: b.eq            #0x1136d20
    // 0x1135fdc: r17 = 5071
    //     0x1135fdc: mov             x17, #0x13cf
    // 0x1135fe0: cmp             x0, x17
    // 0x1135fe4: b.ne            #0x113603c
    // 0x1135fe8: mov             x1, x3
    // 0x1135fec: LoadField: r0 = r1->field_9b
    //     0x1135fec: ldur            w0, [x1, #0x9b]
    // 0x1135ff0: DecompressPointer r0
    //     0x1135ff0: add             x0, x0, HEAP, lsl #32
    // 0x1135ff4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1135ff8: cmp             w0, w16
    // 0x1135ffc: b.ne            #0x113600c
    // 0x1136000: r2 = _colors
    //     0x1136000: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136004: ldr             x2, [x2, #0xa10]
    // 0x1136008: r0 = InitLateFinalInstanceField()
    //     0x1136008: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113600c: LoadField: r1 = r0->field_7f
    //     0x113600c: ldur            w1, [x0, #0x7f]
    // 0x1136010: DecompressPointer r1
    //     0x1136010: add             x1, x1, HEAP, lsl #32
    // 0x1136014: r0 = LoadClassIdInstr(r1)
    //     0x1136014: ldur            x0, [x1, #-1]
    //     0x1136018: ubfx            x0, x0, #0xc, #0x14
    // 0x113601c: d0 = 0.120000
    //     0x113601c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x1136020: ldr             d0, [x17, #0xc40]
    // 0x1136024: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1136024: sub             lr, x0, #1, lsl #12
    //     0x1136028: ldr             lr, [x21, lr, lsl #3]
    //     0x113602c: blr             lr
    // 0x1136030: mov             x2, x0
    // 0x1136034: ldur            x0, [fp, #-8]
    // 0x1136038: b               #0x113608c
    // 0x113603c: ldr             x1, [fp, #0x10]
    // 0x1136040: LoadField: r0 = r1->field_9b
    //     0x1136040: ldur            w0, [x1, #0x9b]
    // 0x1136044: DecompressPointer r0
    //     0x1136044: add             x0, x0, HEAP, lsl #32
    // 0x1136048: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x113604c: cmp             w0, w16
    // 0x1136050: b.ne            #0x1136060
    // 0x1136054: r2 = _colors
    //     0x1136054: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136058: ldr             x2, [x2, #0xa18]
    // 0x113605c: r0 = InitLateFinalInstanceField()
    //     0x113605c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136060: LoadField: r1 = r0->field_7f
    //     0x1136060: ldur            w1, [x0, #0x7f]
    // 0x1136064: DecompressPointer r1
    //     0x1136064: add             x1, x1, HEAP, lsl #32
    // 0x1136068: r0 = LoadClassIdInstr(r1)
    //     0x1136068: ldur            x0, [x1, #-1]
    //     0x113606c: ubfx            x0, x0, #0xc, #0x14
    // 0x1136070: d0 = 0.120000
    //     0x1136070: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x1136074: ldr             d0, [x17, #0xc40]
    // 0x1136078: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1136078: sub             lr, x0, #1, lsl #12
    //     0x113607c: ldr             lr, [x21, lr, lsl #3]
    //     0x1136080: blr             lr
    // 0x1136084: mov             x2, x0
    // 0x1136088: ldur            x0, [fp, #-8]
    // 0x113608c: stur            x2, [fp, #-0x40]
    // 0x1136090: r17 = 5069
    //     0x1136090: mov             x17, #0x13cd
    // 0x1136094: cmp             x0, x17
    // 0x1136098: b.ne            #0x11360b0
    // 0x113609c: ldr             x3, [fp, #0x10]
    // 0x11360a0: LoadField: r1 = r3->field_23
    //     0x11360a0: ldur            w1, [x3, #0x23]
    // 0x11360a4: DecompressPointer r1
    //     0x11360a4: add             x1, x1, HEAP, lsl #32
    // 0x11360a8: mov             x2, x1
    // 0x11360ac: b               #0x1136150
    // 0x11360b0: ldr             x3, [fp, #0x10]
    // 0x11360b4: r17 = 5070
    //     0x11360b4: mov             x17, #0x13ce
    // 0x11360b8: cmp             x0, x17
    // 0x11360bc: b.eq            #0x1136d54
    // 0x11360c0: r17 = 5071
    //     0x11360c0: mov             x17, #0x13cf
    // 0x11360c4: cmp             x0, x17
    // 0x11360c8: b.ne            #0x1136110
    // 0x11360cc: mov             x1, x3
    // 0x11360d0: LoadField: r0 = r1->field_9b
    //     0x11360d0: ldur            w0, [x1, #0x9b]
    // 0x11360d4: DecompressPointer r0
    //     0x11360d4: add             x0, x0, HEAP, lsl #32
    // 0x11360d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11360dc: cmp             w0, w16
    // 0x11360e0: b.ne            #0x11360f0
    // 0x11360e4: r2 = _colors
    //     0x11360e4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x11360e8: ldr             x2, [x2, #0xa10]
    // 0x11360ec: r0 = InitLateFinalInstanceField()
    //     0x11360ec: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11360f0: LoadField: r1 = r0->field_f
    //     0x11360f0: ldur            w1, [x0, #0xf]
    // 0x11360f4: DecompressPointer r1
    //     0x11360f4: add             x1, x1, HEAP, lsl #32
    // 0x11360f8: d0 = 0.380000
    //     0x11360f8: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x11360fc: ldr             d0, [x17, #0x1f0]
    // 0x1136100: r0 = withOpacity()
    //     0x1136100: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1136104: mov             x2, x0
    // 0x1136108: ldur            x0, [fp, #-8]
    // 0x113610c: b               #0x1136150
    // 0x1136110: ldr             x1, [fp, #0x10]
    // 0x1136114: LoadField: r0 = r1->field_9b
    //     0x1136114: ldur            w0, [x1, #0x9b]
    // 0x1136118: DecompressPointer r0
    //     0x1136118: add             x0, x0, HEAP, lsl #32
    // 0x113611c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136120: cmp             w0, w16
    // 0x1136124: b.ne            #0x1136134
    // 0x1136128: r2 = _colors
    //     0x1136128: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x113612c: ldr             x2, [x2, #0xa18]
    // 0x1136130: r0 = InitLateFinalInstanceField()
    //     0x1136130: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136134: LoadField: r1 = r0->field_f
    //     0x1136134: ldur            w1, [x0, #0xf]
    // 0x1136138: DecompressPointer r1
    //     0x1136138: add             x1, x1, HEAP, lsl #32
    // 0x113613c: d0 = 0.540000
    //     0x113613c: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a28] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0x1136140: ldr             d0, [x17, #0xa28]
    // 0x1136144: r0 = withOpacity()
    //     0x1136144: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1136148: mov             x2, x0
    // 0x113614c: ldur            x0, [fp, #-8]
    // 0x1136150: stur            x2, [fp, #-0x48]
    // 0x1136154: r17 = 5069
    //     0x1136154: mov             x17, #0x13cd
    // 0x1136158: cmp             x0, x17
    // 0x113615c: b.ne            #0x1136174
    // 0x1136160: ldr             x3, [fp, #0x10]
    // 0x1136164: LoadField: r1 = r3->field_27
    //     0x1136164: ldur            w1, [x3, #0x27]
    // 0x1136168: DecompressPointer r1
    //     0x1136168: add             x1, x1, HEAP, lsl #32
    // 0x113616c: mov             x2, x1
    // 0x1136170: b               #0x1136234
    // 0x1136174: ldr             x3, [fp, #0x10]
    // 0x1136178: r17 = 5070
    //     0x1136178: mov             x17, #0x13ce
    // 0x113617c: cmp             x0, x17
    // 0x1136180: b.eq            #0x1136d88
    // 0x1136184: r17 = 5071
    //     0x1136184: mov             x17, #0x13cf
    // 0x1136188: cmp             x0, x17
    // 0x113618c: b.ne            #0x11361f4
    // 0x1136190: mov             x1, x3
    // 0x1136194: LoadField: r0 = r1->field_9b
    //     0x1136194: ldur            w0, [x1, #0x9b]
    // 0x1136198: DecompressPointer r0
    //     0x1136198: add             x0, x0, HEAP, lsl #32
    // 0x113619c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11361a0: cmp             w0, w16
    // 0x11361a4: b.ne            #0x11361b4
    // 0x11361a8: r2 = _colors
    //     0x11361a8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x11361ac: ldr             x2, [x2, #0xa10]
    // 0x11361b0: r0 = InitLateFinalInstanceField()
    //     0x11361b0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11361b4: LoadField: r1 = r0->field_a3
    //     0x11361b4: ldur            w1, [x0, #0xa3]
    // 0x11361b8: DecompressPointer r1
    //     0x11361b8: add             x1, x1, HEAP, lsl #32
    // 0x11361bc: cmp             w1, NULL
    // 0x11361c0: b.ne            #0x11361cc
    // 0x11361c4: LoadField: r1 = r0->field_7f
    //     0x11361c4: ldur            w1, [x0, #0x7f]
    // 0x11361c8: DecompressPointer r1
    //     0x11361c8: add             x1, x1, HEAP, lsl #32
    // 0x11361cc: r0 = LoadClassIdInstr(r1)
    //     0x11361cc: ldur            x0, [x1, #-1]
    //     0x11361d0: ubfx            x0, x0, #0xc, #0x14
    // 0x11361d4: d0 = 0.380000
    //     0x11361d4: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x11361d8: ldr             d0, [x17, #0x1f0]
    // 0x11361dc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x11361dc: sub             lr, x0, #1, lsl #12
    //     0x11361e0: ldr             lr, [x21, lr, lsl #3]
    //     0x11361e4: blr             lr
    // 0x11361e8: mov             x2, x0
    // 0x11361ec: ldur            x0, [fp, #-8]
    // 0x11361f0: b               #0x1136234
    // 0x11361f4: ldr             x1, [fp, #0x10]
    // 0x11361f8: LoadField: r0 = r1->field_9b
    //     0x11361f8: ldur            w0, [x1, #0x9b]
    // 0x11361fc: DecompressPointer r0
    //     0x11361fc: add             x0, x0, HEAP, lsl #32
    // 0x1136200: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136204: cmp             w0, w16
    // 0x1136208: b.ne            #0x1136218
    // 0x113620c: r2 = _colors
    //     0x113620c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136210: ldr             x2, [x2, #0xa18]
    // 0x1136214: r0 = InitLateFinalInstanceField()
    //     0x1136214: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136218: LoadField: r1 = r0->field_b
    //     0x1136218: ldur            w1, [x0, #0xb]
    // 0x113621c: DecompressPointer r1
    //     0x113621c: add             x1, x1, HEAP, lsl #32
    // 0x1136220: d0 = 0.540000
    //     0x1136220: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a28] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0x1136224: ldr             d0, [x17, #0xa28]
    // 0x1136228: r0 = withOpacity()
    //     0x1136228: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x113622c: mov             x2, x0
    // 0x1136230: ldur            x0, [fp, #-8]
    // 0x1136234: stur            x2, [fp, #-0x50]
    // 0x1136238: r17 = 5069
    //     0x1136238: mov             x17, #0x13cd
    // 0x113623c: cmp             x0, x17
    // 0x1136240: b.ne            #0x1136258
    // 0x1136244: ldr             x3, [fp, #0x10]
    // 0x1136248: LoadField: r1 = r3->field_2b
    //     0x1136248: ldur            w1, [x3, #0x2b]
    // 0x113624c: DecompressPointer r1
    //     0x113624c: add             x1, x1, HEAP, lsl #32
    // 0x1136250: mov             x2, x1
    // 0x1136254: b               #0x1136308
    // 0x1136258: ldr             x3, [fp, #0x10]
    // 0x113625c: r17 = 5070
    //     0x113625c: mov             x17, #0x13ce
    // 0x1136260: cmp             x0, x17
    // 0x1136264: b.eq            #0x1136dbc
    // 0x1136268: r17 = 5071
    //     0x1136268: mov             x17, #0x13cf
    // 0x113626c: cmp             x0, x17
    // 0x1136270: b.ne            #0x11362c8
    // 0x1136274: mov             x1, x3
    // 0x1136278: LoadField: r0 = r1->field_9b
    //     0x1136278: ldur            w0, [x1, #0x9b]
    // 0x113627c: DecompressPointer r0
    //     0x113627c: add             x0, x0, HEAP, lsl #32
    // 0x1136280: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136284: cmp             w0, w16
    // 0x1136288: b.ne            #0x1136298
    // 0x113628c: r2 = _colors
    //     0x113628c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136290: ldr             x2, [x2, #0xa10]
    // 0x1136294: r0 = InitLateFinalInstanceField()
    //     0x1136294: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136298: LoadField: r1 = r0->field_7f
    //     0x1136298: ldur            w1, [x0, #0x7f]
    // 0x113629c: DecompressPointer r1
    //     0x113629c: add             x1, x1, HEAP, lsl #32
    // 0x11362a0: r0 = LoadClassIdInstr(r1)
    //     0x11362a0: ldur            x0, [x1, #-1]
    //     0x11362a4: ubfx            x0, x0, #0xc, #0x14
    // 0x11362a8: d0 = 0.380000
    //     0x11362a8: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x11362ac: ldr             d0, [x17, #0x1f0]
    // 0x11362b0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x11362b0: sub             lr, x0, #1, lsl #12
    //     0x11362b4: ldr             lr, [x21, lr, lsl #3]
    //     0x11362b8: blr             lr
    // 0x11362bc: mov             x2, x0
    // 0x11362c0: ldur            x0, [fp, #-8]
    // 0x11362c4: b               #0x1136308
    // 0x11362c8: ldr             x1, [fp, #0x10]
    // 0x11362cc: LoadField: r0 = r1->field_9b
    //     0x11362cc: ldur            w0, [x1, #0x9b]
    // 0x11362d0: DecompressPointer r0
    //     0x11362d0: add             x0, x0, HEAP, lsl #32
    // 0x11362d4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11362d8: cmp             w0, w16
    // 0x11362dc: b.ne            #0x11362ec
    // 0x11362e0: r2 = _colors
    //     0x11362e0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x11362e4: ldr             x2, [x2, #0xa18]
    // 0x11362e8: r0 = InitLateFinalInstanceField()
    //     0x11362e8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11362ec: LoadField: r1 = r0->field_f
    //     0x11362ec: ldur            w1, [x0, #0xf]
    // 0x11362f0: DecompressPointer r1
    //     0x11362f0: add             x1, x1, HEAP, lsl #32
    // 0x11362f4: d0 = 0.120000
    //     0x11362f4: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x11362f8: ldr             d0, [x17, #0xc40]
    // 0x11362fc: r0 = withOpacity()
    //     0x11362fc: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1136300: mov             x2, x0
    // 0x1136304: ldur            x0, [fp, #-8]
    // 0x1136308: stur            x2, [fp, #-0x58]
    // 0x113630c: r17 = 5069
    //     0x113630c: mov             x17, #0x13cd
    // 0x1136310: cmp             x0, x17
    // 0x1136314: b.ne            #0x113632c
    // 0x1136318: ldr             x3, [fp, #0x10]
    // 0x113631c: LoadField: r1 = r3->field_2f
    //     0x113631c: ldur            w1, [x3, #0x2f]
    // 0x1136320: DecompressPointer r1
    //     0x1136320: add             x1, x1, HEAP, lsl #32
    // 0x1136324: mov             x2, x1
    // 0x1136328: b               #0x11363ec
    // 0x113632c: ldr             x3, [fp, #0x10]
    // 0x1136330: r17 = 5070
    //     0x1136330: mov             x17, #0x13ce
    // 0x1136334: cmp             x0, x17
    // 0x1136338: b.eq            #0x1136df0
    // 0x113633c: r17 = 5071
    //     0x113633c: mov             x17, #0x13cf
    // 0x1136340: cmp             x0, x17
    // 0x1136344: b.ne            #0x113639c
    // 0x1136348: mov             x1, x3
    // 0x113634c: LoadField: r0 = r1->field_9b
    //     0x113634c: ldur            w0, [x1, #0x9b]
    // 0x1136350: DecompressPointer r0
    //     0x1136350: add             x0, x0, HEAP, lsl #32
    // 0x1136354: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136358: cmp             w0, w16
    // 0x113635c: b.ne            #0x113636c
    // 0x1136360: r2 = _colors
    //     0x1136360: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136364: ldr             x2, [x2, #0xa10]
    // 0x1136368: r0 = InitLateFinalInstanceField()
    //     0x1136368: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113636c: LoadField: r1 = r0->field_7f
    //     0x113636c: ldur            w1, [x0, #0x7f]
    // 0x1136370: DecompressPointer r1
    //     0x1136370: add             x1, x1, HEAP, lsl #32
    // 0x1136374: r0 = LoadClassIdInstr(r1)
    //     0x1136374: ldur            x0, [x1, #-1]
    //     0x1136378: ubfx            x0, x0, #0xc, #0x14
    // 0x113637c: d0 = 0.380000
    //     0x113637c: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1136380: ldr             d0, [x17, #0x1f0]
    // 0x1136384: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1136384: sub             lr, x0, #1, lsl #12
    //     0x1136388: ldr             lr, [x21, lr, lsl #3]
    //     0x113638c: blr             lr
    // 0x1136390: mov             x2, x0
    // 0x1136394: ldur            x0, [fp, #-8]
    // 0x1136398: b               #0x11363ec
    // 0x113639c: ldr             x1, [fp, #0x10]
    // 0x11363a0: LoadField: r0 = r1->field_9b
    //     0x11363a0: ldur            w0, [x1, #0x9b]
    // 0x11363a4: DecompressPointer r0
    //     0x11363a4: add             x0, x0, HEAP, lsl #32
    // 0x11363a8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11363ac: cmp             w0, w16
    // 0x11363b0: b.ne            #0x11363c0
    // 0x11363b4: r2 = _colors
    //     0x11363b4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x11363b8: ldr             x2, [x2, #0xa18]
    // 0x11363bc: r0 = InitLateFinalInstanceField()
    //     0x11363bc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11363c0: LoadField: r1 = r0->field_7f
    //     0x11363c0: ldur            w1, [x0, #0x7f]
    // 0x11363c4: DecompressPointer r1
    //     0x11363c4: add             x1, x1, HEAP, lsl #32
    // 0x11363c8: r0 = LoadClassIdInstr(r1)
    //     0x11363c8: ldur            x0, [x1, #-1]
    //     0x11363cc: ubfx            x0, x0, #0xc, #0x14
    // 0x11363d0: d0 = 0.120000
    //     0x11363d0: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x11363d4: ldr             d0, [x17, #0xc40]
    // 0x11363d8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x11363d8: sub             lr, x0, #1, lsl #12
    //     0x11363dc: ldr             lr, [x21, lr, lsl #3]
    //     0x11363e0: blr             lr
    // 0x11363e4: mov             x2, x0
    // 0x11363e8: ldur            x0, [fp, #-8]
    // 0x11363ec: stur            x2, [fp, #-0x60]
    // 0x11363f0: r17 = 5069
    //     0x11363f0: mov             x17, #0x13cd
    // 0x11363f4: cmp             x0, x17
    // 0x11363f8: b.ne            #0x1136410
    // 0x11363fc: ldr             x3, [fp, #0x10]
    // 0x1136400: LoadField: r1 = r3->field_33
    //     0x1136400: ldur            w1, [x3, #0x33]
    // 0x1136404: DecompressPointer r1
    //     0x1136404: add             x1, x1, HEAP, lsl #32
    // 0x1136408: mov             x2, x1
    // 0x113640c: b               #0x1136498
    // 0x1136410: ldr             x3, [fp, #0x10]
    // 0x1136414: r17 = 5070
    //     0x1136414: mov             x17, #0x13ce
    // 0x1136418: cmp             x0, x17
    // 0x113641c: b.eq            #0x1136e24
    // 0x1136420: r17 = 5071
    //     0x1136420: mov             x17, #0x13cf
    // 0x1136424: cmp             x0, x17
    // 0x1136428: b.ne            #0x1136464
    // 0x113642c: mov             x1, x3
    // 0x1136430: LoadField: r0 = r1->field_9b
    //     0x1136430: ldur            w0, [x1, #0x9b]
    // 0x1136434: DecompressPointer r0
    //     0x1136434: add             x0, x0, HEAP, lsl #32
    // 0x1136438: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x113643c: cmp             w0, w16
    // 0x1136440: b.ne            #0x1136450
    // 0x1136444: r2 = _colors
    //     0x1136444: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136448: ldr             x2, [x2, #0xa10]
    // 0x113644c: r0 = InitLateFinalInstanceField()
    //     0x113644c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136450: LoadField: r1 = r0->field_b
    //     0x1136450: ldur            w1, [x0, #0xb]
    // 0x1136454: DecompressPointer r1
    //     0x1136454: add             x1, x1, HEAP, lsl #32
    // 0x1136458: mov             x2, x1
    // 0x113645c: ldur            x0, [fp, #-8]
    // 0x1136460: b               #0x1136498
    // 0x1136464: ldr             x1, [fp, #0x10]
    // 0x1136468: LoadField: r0 = r1->field_9b
    //     0x1136468: ldur            w0, [x1, #0x9b]
    // 0x113646c: DecompressPointer r0
    //     0x113646c: add             x0, x0, HEAP, lsl #32
    // 0x1136470: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136474: cmp             w0, w16
    // 0x1136478: b.ne            #0x1136488
    // 0x113647c: r2 = _colors
    //     0x113647c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136480: ldr             x2, [x2, #0xa18]
    // 0x1136484: r0 = InitLateFinalInstanceField()
    //     0x1136484: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136488: LoadField: r1 = r0->field_b
    //     0x1136488: ldur            w1, [x0, #0xb]
    // 0x113648c: DecompressPointer r1
    //     0x113648c: add             x1, x1, HEAP, lsl #32
    // 0x1136490: mov             x2, x1
    // 0x1136494: ldur            x0, [fp, #-8]
    // 0x1136498: stur            x2, [fp, #-0x68]
    // 0x113649c: r17 = 5069
    //     0x113649c: mov             x17, #0x13cd
    // 0x11364a0: cmp             x0, x17
    // 0x11364a4: b.ne            #0x11364b8
    // 0x11364a8: ldr             x3, [fp, #0x10]
    // 0x11364ac: LoadField: r1 = r3->field_3b
    //     0x11364ac: ldur            w1, [x3, #0x3b]
    // 0x11364b0: DecompressPointer r1
    //     0x11364b0: add             x1, x1, HEAP, lsl #32
    // 0x11364b4: b               #0x11365bc
    // 0x11364b8: ldr             x3, [fp, #0x10]
    // 0x11364bc: r17 = 5070
    //     0x11364bc: mov             x17, #0x13ce
    // 0x11364c0: cmp             x0, x17
    // 0x11364c4: b.eq            #0x1136e58
    // 0x11364c8: r17 = 5071
    //     0x11364c8: mov             x17, #0x13cf
    // 0x11364cc: cmp             x0, x17
    // 0x11364d0: b.ne            #0x1136548
    // 0x11364d4: mov             x1, x3
    // 0x11364d8: LoadField: r0 = r1->field_9b
    //     0x11364d8: ldur            w0, [x1, #0x9b]
    // 0x11364dc: DecompressPointer r0
    //     0x11364dc: add             x0, x0, HEAP, lsl #32
    // 0x11364e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11364e4: cmp             w0, w16
    // 0x11364e8: b.ne            #0x11364f8
    // 0x11364ec: r2 = _colors
    //     0x11364ec: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x11364f0: ldr             x2, [x2, #0xa10]
    // 0x11364f4: r0 = InitLateFinalInstanceField()
    //     0x11364f4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11364f8: LoadField: r1 = r0->field_7f
    //     0x11364f8: ldur            w1, [x0, #0x7f]
    // 0x11364fc: DecompressPointer r1
    //     0x11364fc: add             x1, x1, HEAP, lsl #32
    // 0x1136500: r0 = LoadClassIdInstr(r1)
    //     0x1136500: ldur            x0, [x1, #-1]
    //     0x1136504: ubfx            x0, x0, #0xc, #0x14
    // 0x1136508: d0 = 0.380000
    //     0x1136508: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x113650c: ldr             d0, [x17, #0x1f0]
    // 0x1136510: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1136510: sub             lr, x0, #1, lsl #12
    //     0x1136514: ldr             lr, [x21, lr, lsl #3]
    //     0x1136518: blr             lr
    // 0x113651c: mov             x1, x0
    // 0x1136520: ldr             x0, [fp, #0x10]
    // 0x1136524: LoadField: r2 = r0->field_9b
    //     0x1136524: ldur            w2, [x0, #0x9b]
    // 0x1136528: DecompressPointer r2
    //     0x1136528: add             x2, x2, HEAP, lsl #32
    // 0x113652c: LoadField: r3 = r2->field_7b
    //     0x113652c: ldur            w3, [x2, #0x7b]
    // 0x1136530: DecompressPointer r3
    //     0x1136530: add             x3, x3, HEAP, lsl #32
    // 0x1136534: mov             x2, x3
    // 0x1136538: r0 = alphaBlend()
    //     0x1136538: bl              #0xb6ea90  ; [dart:ui] Color::alphaBlend
    // 0x113653c: mov             x1, x0
    // 0x1136540: ldur            x0, [fp, #-8]
    // 0x1136544: b               #0x11365bc
    // 0x1136548: mov             x0, x3
    // 0x113654c: mov             x1, x0
    // 0x1136550: LoadField: r0 = r1->field_9b
    //     0x1136550: ldur            w0, [x1, #0x9b]
    // 0x1136554: DecompressPointer r0
    //     0x1136554: add             x0, x0, HEAP, lsl #32
    // 0x1136558: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x113655c: cmp             w0, w16
    // 0x1136560: b.ne            #0x1136570
    // 0x1136564: r2 = _colors
    //     0x1136564: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136568: ldr             x2, [x2, #0xa18]
    // 0x113656c: r0 = InitLateFinalInstanceField()
    //     0x113656c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136570: LoadField: r1 = r0->field_7f
    //     0x1136570: ldur            w1, [x0, #0x7f]
    // 0x1136574: DecompressPointer r1
    //     0x1136574: add             x1, x1, HEAP, lsl #32
    // 0x1136578: r0 = LoadClassIdInstr(r1)
    //     0x1136578: ldur            x0, [x1, #-1]
    //     0x113657c: ubfx            x0, x0, #0xc, #0x14
    // 0x1136580: d0 = 0.380000
    //     0x1136580: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1136584: ldr             d0, [x17, #0x1f0]
    // 0x1136588: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1136588: sub             lr, x0, #1, lsl #12
    //     0x113658c: ldr             lr, [x21, lr, lsl #3]
    //     0x1136590: blr             lr
    // 0x1136594: mov             x1, x0
    // 0x1136598: ldr             x0, [fp, #0x10]
    // 0x113659c: LoadField: r2 = r0->field_9b
    //     0x113659c: ldur            w2, [x0, #0x9b]
    // 0x11365a0: DecompressPointer r2
    //     0x11365a0: add             x2, x2, HEAP, lsl #32
    // 0x11365a4: LoadField: r3 = r2->field_7b
    //     0x11365a4: ldur            w3, [x2, #0x7b]
    // 0x11365a8: DecompressPointer r3
    //     0x11365a8: add             x3, x3, HEAP, lsl #32
    // 0x11365ac: mov             x2, x3
    // 0x11365b0: r0 = alphaBlend()
    //     0x11365b0: bl              #0xb6ea90  ; [dart:ui] Color::alphaBlend
    // 0x11365b4: mov             x1, x0
    // 0x11365b8: ldur            x0, [fp, #-8]
    // 0x11365bc: stur            x1, [fp, #-0x70]
    // 0x11365c0: r17 = 5069
    //     0x11365c0: mov             x17, #0x13cd
    // 0x11365c4: cmp             x0, x17
    // 0x11365c8: b.ne            #0x11365e0
    // 0x11365cc: ldr             x2, [fp, #0x10]
    // 0x11365d0: LoadField: r3 = r2->field_3f
    //     0x11365d0: ldur            w3, [x2, #0x3f]
    // 0x11365d4: DecompressPointer r3
    //     0x11365d4: add             x3, x3, HEAP, lsl #32
    // 0x11365d8: mov             x2, x3
    // 0x11365dc: b               #0x11366c8
    // 0x11365e0: ldr             x2, [fp, #0x10]
    // 0x11365e4: r17 = 5070
    //     0x11365e4: mov             x17, #0x13ce
    // 0x11365e8: cmp             x0, x17
    // 0x11365ec: b.ne            #0x1136634
    // 0x11365f0: r1 = 1
    //     0x11365f0: mov             x1, #1
    // 0x11365f4: r0 = AllocateContext()
    //     0x11365f4: bl              #0x13de838  ; AllocateContextStub
    // 0x11365f8: ldr             x1, [fp, #0x10]
    // 0x11365fc: stur            x0, [fp, #-0x78]
    // 0x1136600: StoreField: r0->field_f = r1
    //     0x1136600: stur            w1, [x0, #0xf]
    // 0x1136604: r0 = _WidgetStateColor()
    //     0x1136604: bl              #0xd29244  ; Allocate_WidgetStateColorStub -> _WidgetStateColor (size=0x30)
    // 0x1136608: ldur            x2, [fp, #-0x78]
    // 0x113660c: r1 = Function '<anonymous closure>':.
    //     0x113660c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26a38] AnonymousClosure: (0xd3df80), of [package:flutter/src/material/slider.dart] _SliderDefaultsM3
    //     0x1136610: ldr             x1, [x1, #0xa38]
    // 0x1136614: stur            x0, [fp, #-0x78]
    // 0x1136618: r0 = AllocateClosure()
    //     0x1136618: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x113661c: ldur            x1, [fp, #-0x78]
    // 0x1136620: mov             x2, x0
    // 0x1136624: r0 = _WidgetStateColor()
    //     0x1136624: bl              #0xd29128  ; [package:flutter/src/widgets/widget_state.dart] _WidgetStateColor::_WidgetStateColor
    // 0x1136628: ldur            x2, [fp, #-0x78]
    // 0x113662c: ldur            x0, [fp, #-8]
    // 0x1136630: b               #0x11366c8
    // 0x1136634: r17 = 5071
    //     0x1136634: mov             x17, #0x13cf
    // 0x1136638: cmp             x0, x17
    // 0x113663c: b.ne            #0x1136688
    // 0x1136640: ldr             x1, [fp, #0x10]
    // 0x1136644: r1 = 1
    //     0x1136644: mov             x1, #1
    // 0x1136648: r0 = AllocateContext()
    //     0x1136648: bl              #0x13de838  ; AllocateContextStub
    // 0x113664c: ldr             x1, [fp, #0x10]
    // 0x1136650: stur            x0, [fp, #-0x78]
    // 0x1136654: StoreField: r0->field_f = r1
    //     0x1136654: stur            w1, [x0, #0xf]
    // 0x1136658: r0 = _WidgetStateColor()
    //     0x1136658: bl              #0xd29244  ; Allocate_WidgetStateColorStub -> _WidgetStateColor (size=0x30)
    // 0x113665c: ldur            x2, [fp, #-0x78]
    // 0x1136660: r1 = Function '<anonymous closure>':.
    //     0x1136660: add             x1, PP, #0x26, lsl #12  ; [pp+0x26a40] AnonymousClosure: (0xd3ddc4), of [package:flutter/src/material/slider.dart] _SliderDefaultsM3Year2023
    //     0x1136664: ldr             x1, [x1, #0xa40]
    // 0x1136668: stur            x0, [fp, #-0x78]
    // 0x113666c: r0 = AllocateClosure()
    //     0x113666c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1136670: ldur            x1, [fp, #-0x78]
    // 0x1136674: mov             x2, x0
    // 0x1136678: r0 = _WidgetStateColor()
    //     0x1136678: bl              #0xd29128  ; [package:flutter/src/widgets/widget_state.dart] _WidgetStateColor::_WidgetStateColor
    // 0x113667c: ldur            x2, [fp, #-0x78]
    // 0x1136680: ldur            x0, [fp, #-8]
    // 0x1136684: b               #0x11366c8
    // 0x1136688: ldr             x1, [fp, #0x10]
    // 0x113668c: LoadField: r0 = r1->field_9b
    //     0x113668c: ldur            w0, [x1, #0x9b]
    // 0x1136690: DecompressPointer r0
    //     0x1136690: add             x0, x0, HEAP, lsl #32
    // 0x1136694: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136698: cmp             w0, w16
    // 0x113669c: b.ne            #0x11366ac
    // 0x11366a0: r2 = _colors
    //     0x11366a0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x11366a4: ldr             x2, [x2, #0xa18]
    // 0x11366a8: r0 = InitLateFinalInstanceField()
    //     0x11366a8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11366ac: LoadField: r1 = r0->field_b
    //     0x11366ac: ldur            w1, [x0, #0xb]
    // 0x11366b0: DecompressPointer r1
    //     0x11366b0: add             x1, x1, HEAP, lsl #32
    // 0x11366b4: d0 = 0.120000
    //     0x11366b4: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x11366b8: ldr             d0, [x17, #0xc40]
    // 0x11366bc: r0 = withOpacity()
    //     0x11366bc: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x11366c0: mov             x2, x0
    // 0x11366c4: ldur            x0, [fp, #-8]
    // 0x11366c8: stur            x2, [fp, #-0x78]
    // 0x11366cc: r17 = 5069
    //     0x11366cc: mov             x17, #0x13cd
    // 0x11366d0: cmp             x0, x17
    // 0x11366d4: b.ne            #0x11366ec
    // 0x11366d8: ldr             x3, [fp, #0x10]
    // 0x11366dc: LoadField: r1 = r3->field_43
    //     0x11366dc: ldur            w1, [x3, #0x43]
    // 0x11366e0: DecompressPointer r1
    //     0x11366e0: add             x1, x1, HEAP, lsl #32
    // 0x11366e4: mov             x2, x1
    // 0x11366e8: b               #0x1136798
    // 0x11366ec: ldr             x3, [fp, #0x10]
    // 0x11366f0: r17 = 5070
    //     0x11366f0: mov             x17, #0x13ce
    // 0x11366f4: cmp             x0, x17
    // 0x11366f8: b.eq            #0x1136e8c
    // 0x11366fc: r17 = 5071
    //     0x11366fc: mov             x17, #0x13cf
    // 0x1136700: cmp             x0, x17
    // 0x1136704: b.ne            #0x1136740
    // 0x1136708: mov             x1, x3
    // 0x113670c: LoadField: r0 = r1->field_9b
    //     0x113670c: ldur            w0, [x1, #0x9b]
    // 0x1136710: DecompressPointer r0
    //     0x1136710: add             x0, x0, HEAP, lsl #32
    // 0x1136714: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136718: cmp             w0, w16
    // 0x113671c: b.ne            #0x113672c
    // 0x1136720: r2 = _colors
    //     0x1136720: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136724: ldr             x2, [x2, #0xa10]
    // 0x1136728: r0 = InitLateFinalInstanceField()
    //     0x1136728: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113672c: LoadField: r1 = r0->field_b
    //     0x113672c: ldur            w1, [x0, #0xb]
    // 0x1136730: DecompressPointer r1
    //     0x1136730: add             x1, x1, HEAP, lsl #32
    // 0x1136734: mov             x2, x1
    // 0x1136738: ldur            x0, [fp, #-8]
    // 0x113673c: b               #0x1136798
    // 0x1136740: ldr             x1, [fp, #0x10]
    // 0x1136744: LoadField: r0 = r1->field_9f
    //     0x1136744: ldur            w0, [x1, #0x9f]
    // 0x1136748: DecompressPointer r0
    //     0x1136748: add             x0, x0, HEAP, lsl #32
    // 0x113674c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136750: cmp             w0, w16
    // 0x1136754: b.ne            #0x1136764
    // 0x1136758: r2 = sliderTheme
    //     0x1136758: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a48] Field <_SliderDefaultsM2@125231897.sliderTheme>: late final (offset: 0xa0)
    //     0x113675c: ldr             x2, [x2, #0xa48]
    // 0x1136760: r0 = InitLateFinalInstanceField()
    //     0x1136760: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136764: ldr             x1, [fp, #0x10]
    // 0x1136768: LoadField: r0 = r1->field_9b
    //     0x1136768: ldur            w0, [x1, #0x9b]
    // 0x113676c: DecompressPointer r0
    //     0x113676c: add             x0, x0, HEAP, lsl #32
    // 0x1136770: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136774: cmp             w0, w16
    // 0x1136778: b.ne            #0x1136788
    // 0x113677c: r2 = _colors
    //     0x113677c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136780: ldr             x2, [x2, #0xa18]
    // 0x1136784: r0 = InitLateFinalInstanceField()
    //     0x1136784: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136788: LoadField: r1 = r0->field_b
    //     0x1136788: ldur            w1, [x0, #0xb]
    // 0x113678c: DecompressPointer r1
    //     0x113678c: add             x1, x1, HEAP, lsl #32
    // 0x1136790: mov             x2, x1
    // 0x1136794: ldur            x0, [fp, #-8]
    // 0x1136798: stur            x2, [fp, #-0xb0]
    // 0x113679c: r17 = 5069
    //     0x113679c: mov             x17, #0x13cd
    // 0x11367a0: cmp             x0, x17
    // 0x11367a4: b.ne            #0x11367bc
    // 0x11367a8: ldr             x3, [fp, #0x10]
    // 0x11367ac: LoadField: r1 = r3->field_4b
    //     0x11367ac: ldur            w1, [x3, #0x4b]
    // 0x11367b0: DecompressPointer r1
    //     0x11367b0: add             x1, x1, HEAP, lsl #32
    // 0x11367b4: mov             x4, x1
    // 0x11367b8: b               #0x11367f8
    // 0x11367bc: ldr             x3, [fp, #0x10]
    // 0x11367c0: r17 = 5070
    //     0x11367c0: mov             x17, #0x13ce
    // 0x11367c4: cmp             x0, x17
    // 0x11367c8: b.ne            #0x11367d8
    // 0x11367cc: r4 = Instance_RoundSliderOverlayShape
    //     0x11367cc: add             x4, PP, #0x26, lsl #12  ; [pp+0x26a50] Obj!RoundSliderOverlayShape@129e8a1
    //     0x11367d0: ldr             x4, [x4, #0xa50]
    // 0x11367d4: b               #0x11367f8
    // 0x11367d8: r17 = 5071
    //     0x11367d8: mov             x17, #0x13cf
    // 0x11367dc: cmp             x0, x17
    // 0x11367e0: b.ne            #0x11367f0
    // 0x11367e4: r4 = Instance_RoundSliderOverlayShape
    //     0x11367e4: add             x4, PP, #0x26, lsl #12  ; [pp+0x26a50] Obj!RoundSliderOverlayShape@129e8a1
    //     0x11367e8: ldr             x4, [x4, #0xa50]
    // 0x11367ec: b               #0x11367f8
    // 0x11367f0: r4 = Instance_RoundSliderOverlayShape
    //     0x11367f0: add             x4, PP, #0x26, lsl #12  ; [pp+0x26a50] Obj!RoundSliderOverlayShape@129e8a1
    //     0x11367f4: ldr             x4, [x4, #0xa50]
    // 0x11367f8: stur            x4, [fp, #-0xa8]
    // 0x11367fc: r17 = 5069
    //     0x11367fc: mov             x17, #0x13cd
    // 0x1136800: cmp             x0, x17
    // 0x1136804: b.ne            #0x1136818
    // 0x1136808: LoadField: r1 = r3->field_4f
    //     0x1136808: ldur            w1, [x3, #0x4f]
    // 0x113680c: DecompressPointer r1
    //     0x113680c: add             x1, x1, HEAP, lsl #32
    // 0x1136810: mov             x5, x1
    // 0x1136814: b               #0x1136850
    // 0x1136818: r17 = 5070
    //     0x1136818: mov             x17, #0x13ce
    // 0x113681c: cmp             x0, x17
    // 0x1136820: b.ne            #0x1136830
    // 0x1136824: r5 = Instance_RoundSliderTickMarkShape
    //     0x1136824: add             x5, PP, #0x26, lsl #12  ; [pp+0x26a58] Obj!RoundSliderTickMarkShape@129e921
    //     0x1136828: ldr             x5, [x5, #0xa58]
    // 0x113682c: b               #0x1136850
    // 0x1136830: r17 = 5071
    //     0x1136830: mov             x17, #0x13cf
    // 0x1136834: cmp             x0, x17
    // 0x1136838: b.ne            #0x1136848
    // 0x113683c: r5 = Instance_RoundSliderTickMarkShape
    //     0x113683c: add             x5, PP, #0x26, lsl #12  ; [pp+0x26a60] Obj!RoundSliderTickMarkShape@129e911
    //     0x1136840: ldr             x5, [x5, #0xa60]
    // 0x1136844: b               #0x1136850
    // 0x1136848: r5 = Instance_RoundSliderTickMarkShape
    //     0x1136848: add             x5, PP, #0x26, lsl #12  ; [pp+0x26a60] Obj!RoundSliderTickMarkShape@129e911
    //     0x113684c: ldr             x5, [x5, #0xa60]
    // 0x1136850: stur            x5, [fp, #-0xa0]
    // 0x1136854: r17 = 5069
    //     0x1136854: mov             x17, #0x13cd
    // 0x1136858: cmp             x0, x17
    // 0x113685c: b.ne            #0x1136870
    // 0x1136860: LoadField: r1 = r3->field_53
    //     0x1136860: ldur            w1, [x3, #0x53]
    // 0x1136864: DecompressPointer r1
    //     0x1136864: add             x1, x1, HEAP, lsl #32
    // 0x1136868: mov             x6, x1
    // 0x113686c: b               #0x11368a8
    // 0x1136870: r17 = 5070
    //     0x1136870: mov             x17, #0x13ce
    // 0x1136874: cmp             x0, x17
    // 0x1136878: b.ne            #0x1136888
    // 0x113687c: r6 = Instance_HandleThumbShape
    //     0x113687c: add             x6, PP, #0x26, lsl #12  ; [pp+0x26a68] Obj!HandleThumbShape@129e8c1
    //     0x1136880: ldr             x6, [x6, #0xa68]
    // 0x1136884: b               #0x11368a8
    // 0x1136888: r17 = 5071
    //     0x1136888: mov             x17, #0x13cf
    // 0x113688c: cmp             x0, x17
    // 0x1136890: b.ne            #0x11368a0
    // 0x1136894: r6 = Instance_RoundSliderThumbShape
    //     0x1136894: add             x6, PP, #0x26, lsl #12  ; [pp+0x26a70] Obj!RoundSliderThumbShape@129e8e1
    //     0x1136898: ldr             x6, [x6, #0xa70]
    // 0x113689c: b               #0x11368a8
    // 0x11368a0: r6 = Instance_RoundSliderThumbShape
    //     0x11368a0: add             x6, PP, #0x26, lsl #12  ; [pp+0x26a70] Obj!RoundSliderThumbShape@129e8e1
    //     0x11368a4: ldr             x6, [x6, #0xa70]
    // 0x11368a8: stur            x6, [fp, #-0x98]
    // 0x11368ac: r17 = 5069
    //     0x11368ac: mov             x17, #0x13cd
    // 0x11368b0: cmp             x0, x17
    // 0x11368b4: b.ne            #0x11368c8
    // 0x11368b8: LoadField: r1 = r3->field_57
    //     0x11368b8: ldur            w1, [x3, #0x57]
    // 0x11368bc: DecompressPointer r1
    //     0x11368bc: add             x1, x1, HEAP, lsl #32
    // 0x11368c0: mov             x7, x1
    // 0x11368c4: b               #0x1136900
    // 0x11368c8: r17 = 5070
    //     0x11368c8: mov             x17, #0x13ce
    // 0x11368cc: cmp             x0, x17
    // 0x11368d0: b.ne            #0x11368e0
    // 0x11368d4: r7 = Instance_GappedSliderTrackShape
    //     0x11368d4: add             x7, PP, #0x26, lsl #12  ; [pp+0x26a78] Obj!GappedSliderTrackShape@12aa531
    //     0x11368d8: ldr             x7, [x7, #0xa78]
    // 0x11368dc: b               #0x1136900
    // 0x11368e0: r17 = 5071
    //     0x11368e0: mov             x17, #0x13cf
    // 0x11368e4: cmp             x0, x17
    // 0x11368e8: b.ne            #0x11368f8
    // 0x11368ec: r7 = Instance_RoundedRectSliderTrackShape
    //     0x11368ec: add             x7, PP, #0x26, lsl #12  ; [pp+0x26a80] Obj!RoundedRectSliderTrackShape@12aa541
    //     0x11368f0: ldr             x7, [x7, #0xa80]
    // 0x11368f4: b               #0x1136900
    // 0x11368f8: r7 = Instance_RoundedRectSliderTrackShape
    //     0x11368f8: add             x7, PP, #0x26, lsl #12  ; [pp+0x26a80] Obj!RoundedRectSliderTrackShape@12aa541
    //     0x11368fc: ldr             x7, [x7, #0xa80]
    // 0x1136900: stur            x7, [fp, #-0x90]
    // 0x1136904: r17 = 5069
    //     0x1136904: mov             x17, #0x13cd
    // 0x1136908: cmp             x0, x17
    // 0x113690c: b.ne            #0x1136920
    // 0x1136910: LoadField: r1 = r3->field_5b
    //     0x1136910: ldur            w1, [x3, #0x5b]
    // 0x1136914: DecompressPointer r1
    //     0x1136914: add             x1, x1, HEAP, lsl #32
    // 0x1136918: mov             x8, x1
    // 0x113691c: b               #0x1136958
    // 0x1136920: r17 = 5070
    //     0x1136920: mov             x17, #0x13ce
    // 0x1136924: cmp             x0, x17
    // 0x1136928: b.ne            #0x1136938
    // 0x113692c: r8 = Instance_RoundedRectSliderValueIndicatorShape
    //     0x113692c: add             x8, PP, #0x26, lsl #12  ; [pp+0x26a88] Obj!RoundedRectSliderValueIndicatorShape@129e8b1
    //     0x1136930: ldr             x8, [x8, #0xa88]
    // 0x1136934: b               #0x1136958
    // 0x1136938: r17 = 5071
    //     0x1136938: mov             x17, #0x13cf
    // 0x113693c: cmp             x0, x17
    // 0x1136940: b.ne            #0x1136950
    // 0x1136944: r8 = Instance_DropSliderValueIndicatorShape
    //     0x1136944: add             x8, PP, #0x26, lsl #12  ; [pp+0x26a90] Obj!DropSliderValueIndicatorShape@129e8d1
    //     0x1136948: ldr             x8, [x8, #0xa90]
    // 0x113694c: b               #0x1136958
    // 0x1136950: r8 = Instance_RectangularSliderValueIndicatorShape
    //     0x1136950: add             x8, PP, #0x26, lsl #12  ; [pp+0x26a98] Obj!RectangularSliderValueIndicatorShape@129e891
    //     0x1136954: ldr             x8, [x8, #0xa98]
    // 0x1136958: stur            x8, [fp, #-0x88]
    // 0x113695c: LoadField: r9 = r3->field_6f
    //     0x113695c: ldur            w9, [x3, #0x6f]
    // 0x1136960: DecompressPointer r9
    //     0x1136960: add             x9, x9, HEAP, lsl #32
    // 0x1136964: stur            x9, [fp, #-0x80]
    // 0x1136968: r17 = 5069
    //     0x1136968: mov             x17, #0x13cd
    // 0x113696c: cmp             x0, x17
    // 0x1136970: b.ne            #0x1136990
    // 0x1136974: LoadField: r1 = r3->field_73
    //     0x1136974: ldur            w1, [x3, #0x73]
    // 0x1136978: DecompressPointer r1
    //     0x1136978: add             x1, x1, HEAP, lsl #32
    // 0x113697c: mov             x4, x1
    // 0x1136980: mov             x16, x0
    // 0x1136984: mov             x0, x3
    // 0x1136988: mov             x3, x16
    // 0x113698c: b               #0x1136a90
    // 0x1136990: r17 = 5070
    //     0x1136990: mov             x17, #0x13ce
    // 0x1136994: cmp             x0, x17
    // 0x1136998: b.eq            #0x1136ec0
    // 0x113699c: r17 = 5071
    //     0x113699c: mov             x17, #0x13cf
    // 0x11369a0: cmp             x0, x17
    // 0x11369a4: b.ne            #0x1136a20
    // 0x11369a8: LoadField: r1 = r3->field_97
    //     0x11369a8: ldur            w1, [x3, #0x97]
    // 0x11369ac: DecompressPointer r1
    //     0x11369ac: add             x1, x1, HEAP, lsl #32
    // 0x11369b0: r0 = of()
    //     0x11369b0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x11369b4: LoadField: r1 = r0->field_87
    //     0x11369b4: ldur            w1, [x0, #0x87]
    // 0x11369b8: DecompressPointer r1
    //     0x11369b8: add             x1, x1, HEAP, lsl #32
    // 0x11369bc: LoadField: r0 = r1->field_3b
    //     0x11369bc: ldur            w0, [x1, #0x3b]
    // 0x11369c0: DecompressPointer r0
    //     0x11369c0: add             x0, x0, HEAP, lsl #32
    // 0x11369c4: stur            x0, [fp, #-0xb8]
    // 0x11369c8: cmp             w0, NULL
    // 0x11369cc: b.eq            #0x1136ed4
    // 0x11369d0: ldr             x1, [fp, #0x10]
    // 0x11369d4: LoadField: r0 = r1->field_9b
    //     0x11369d4: ldur            w0, [x1, #0x9b]
    // 0x11369d8: DecompressPointer r0
    //     0x11369d8: add             x0, x0, HEAP, lsl #32
    // 0x11369dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11369e0: cmp             w0, w16
    // 0x11369e4: b.ne            #0x11369f4
    // 0x11369e8: r2 = _colors
    //     0x11369e8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x11369ec: ldr             x2, [x2, #0xa10]
    // 0x11369f0: r0 = InitLateFinalInstanceField()
    //     0x11369f0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11369f4: LoadField: r1 = r0->field_f
    //     0x11369f4: ldur            w1, [x0, #0xf]
    // 0x11369f8: DecompressPointer r1
    //     0x11369f8: add             x1, x1, HEAP, lsl #32
    // 0x11369fc: str             x1, [SP]
    // 0x1136a00: ldur            x1, [fp, #-0xb8]
    // 0x1136a04: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x1136a04: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x1136a08: ldr             x4, [x4, #0x7f0]
    // 0x1136a0c: r0 = copyWith()
    //     0x1136a0c: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x1136a10: mov             x4, x0
    // 0x1136a14: ldr             x0, [fp, #0x10]
    // 0x1136a18: ldur            x3, [fp, #-8]
    // 0x1136a1c: b               #0x1136a90
    // 0x1136a20: mov             x0, x3
    // 0x1136a24: LoadField: r1 = r0->field_97
    //     0x1136a24: ldur            w1, [x0, #0x97]
    // 0x1136a28: DecompressPointer r1
    //     0x1136a28: add             x1, x1, HEAP, lsl #32
    // 0x1136a2c: r0 = of()
    //     0x1136a2c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1136a30: LoadField: r1 = r0->field_87
    //     0x1136a30: ldur            w1, [x0, #0x87]
    // 0x1136a34: DecompressPointer r1
    //     0x1136a34: add             x1, x1, HEAP, lsl #32
    // 0x1136a38: LoadField: r0 = r1->field_2b
    //     0x1136a38: ldur            w0, [x1, #0x2b]
    // 0x1136a3c: DecompressPointer r0
    //     0x1136a3c: add             x0, x0, HEAP, lsl #32
    // 0x1136a40: ldr             x1, [fp, #0x10]
    // 0x1136a44: stur            x0, [fp, #-0xb8]
    // 0x1136a48: LoadField: r0 = r1->field_9b
    //     0x1136a48: ldur            w0, [x1, #0x9b]
    // 0x1136a4c: DecompressPointer r0
    //     0x1136a4c: add             x0, x0, HEAP, lsl #32
    // 0x1136a50: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136a54: cmp             w0, w16
    // 0x1136a58: b.ne            #0x1136a68
    // 0x1136a5c: r2 = _colors
    //     0x1136a5c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136a60: ldr             x2, [x2, #0xa18]
    // 0x1136a64: r0 = InitLateFinalInstanceField()
    //     0x1136a64: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136a68: LoadField: r1 = r0->field_f
    //     0x1136a68: ldur            w1, [x0, #0xf]
    // 0x1136a6c: DecompressPointer r1
    //     0x1136a6c: add             x1, x1, HEAP, lsl #32
    // 0x1136a70: str             x1, [SP]
    // 0x1136a74: ldur            x1, [fp, #-0xb8]
    // 0x1136a78: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x1136a78: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x1136a7c: ldr             x4, [x4, #0x7f0]
    // 0x1136a80: r0 = copyWith()
    //     0x1136a80: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x1136a84: mov             x4, x0
    // 0x1136a88: ldr             x0, [fp, #0x10]
    // 0x1136a8c: ldur            x3, [fp, #-8]
    // 0x1136a90: stur            x4, [fp, #-0xc0]
    // 0x1136a94: LoadField: r5 = r0->field_77
    //     0x1136a94: ldur            w5, [x0, #0x77]
    // 0x1136a98: DecompressPointer r5
    //     0x1136a98: add             x5, x5, HEAP, lsl #32
    // 0x1136a9c: stur            x5, [fp, #-0xb8]
    // 0x1136aa0: r17 = -5071
    //     0x1136aa0: mov             x17, #-0x13cf
    // 0x1136aa4: add             x16, x3, x17
    // 0x1136aa8: cmp             x16, #1
    // 0x1136aac: b.ls            #0x1136abc
    // 0x1136ab0: r17 = 5069
    //     0x1136ab0: mov             x17, #0x13cd
    // 0x1136ab4: cmp             x3, x17
    // 0x1136ab8: b.ne            #0x1136acc
    // 0x1136abc: LoadField: r1 = r0->field_8b
    //     0x1136abc: ldur            w1, [x0, #0x8b]
    // 0x1136ac0: DecompressPointer r1
    //     0x1136ac0: add             x1, x1, HEAP, lsl #32
    // 0x1136ac4: mov             x0, x3
    // 0x1136ac8: b               #0x1136af8
    // 0x1136acc: r1 = Function '<anonymous closure>':.
    //     0x1136acc: add             x1, PP, #0x26, lsl #12  ; [pp+0x26aa0] AnonymousClosure: (0x1136ed8), of [package:flutter/src/material/slider.dart] _SliderDefaultsM3
    //     0x1136ad0: ldr             x1, [x1, #0xaa0]
    // 0x1136ad4: r2 = Null
    //     0x1136ad4: mov             x2, NULL
    // 0x1136ad8: r0 = AllocateClosure()
    //     0x1136ad8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1136adc: r16 = <Size?>
    //     0x1136adc: add             x16, PP, #0x26, lsl #12  ; [pp+0x26aa8] TypeArguments: <Size?>
    //     0x1136ae0: ldr             x16, [x16, #0xaa8]
    // 0x1136ae4: stp             x0, x16, [SP]
    // 0x1136ae8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1136ae8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1136aec: r0 = resolveWith()
    //     0x1136aec: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1136af0: mov             x1, x0
    // 0x1136af4: ldur            x0, [fp, #-8]
    // 0x1136af8: r17 = -5071
    //     0x1136af8: mov             x17, #-0x13cf
    // 0x1136afc: add             x16, x0, x17
    // 0x1136b00: cmp             x16, #1
    // 0x1136b04: b.ls            #0x1136b14
    // 0x1136b08: r17 = 5069
    //     0x1136b08: mov             x17, #0x13cd
    // 0x1136b0c: cmp             x0, x17
    // 0x1136b10: b.ne            #0x1136b28
    // 0x1136b14: ldr             x0, [fp, #0x10]
    // 0x1136b18: LoadField: r2 = r0->field_8f
    //     0x1136b18: ldur            w2, [x0, #0x8f]
    // 0x1136b1c: DecompressPointer r2
    //     0x1136b1c: add             x2, x2, HEAP, lsl #32
    // 0x1136b20: mov             x0, x2
    // 0x1136b24: b               #0x1136b30
    // 0x1136b28: r0 = 6.000000
    //     0x1136b28: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c438] 6
    //     0x1136b2c: ldr             x0, [x0, #0x438]
    // 0x1136b30: stp             NULL, NULL, [SP, #0x60]
    // 0x1136b34: stp             NULL, NULL, [SP, #0x50]
    // 0x1136b38: ldur            x16, [fp, #-0x80]
    // 0x1136b3c: ldur            lr, [fp, #-0xc0]
    // 0x1136b40: stp             lr, x16, [SP, #0x40]
    // 0x1136b44: ldur            x16, [fp, #-0xb8]
    // 0x1136b48: stp             NULL, x16, [SP, #0x30]
    // 0x1136b4c: stp             NULL, NULL, [SP, #0x20]
    // 0x1136b50: stp             x1, NULL, [SP, #0x10]
    // 0x1136b54: stp             NULL, x0, [SP]
    // 0x1136b58: ldur            x1, [fp, #-0x90]
    // 0x1136b5c: ldur            x2, [fp, #-0x88]
    // 0x1136b60: r4 = const [0, 0x10, 0xe, 0x10, null]
    //     0x1136b60: add             x4, PP, #0x26, lsl #12  ; [pp+0x262c8] List(5) [0, 0x10, 0xe, 0x10, Null]
    //     0x1136b64: ldr             x4, [x4, #0x2c8]
    // 0x1136b68: r0 = hash()
    //     0x1136b68: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1136b6c: mov             x2, x0
    // 0x1136b70: r0 = BoxInt64Instr(r2)
    //     0x1136b70: sbfiz           x0, x2, #1, #0x1f
    //     0x1136b74: cmp             x2, x0, asr #1
    //     0x1136b78: b.eq            #0x1136b84
    //     0x1136b7c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1136b80: stur            x2, [x0, #7]
    // 0x1136b84: ldur            x16, [fp, #-0x20]
    // 0x1136b88: ldur            lr, [fp, #-0x28]
    // 0x1136b8c: stp             lr, x16, [SP, #0x80]
    // 0x1136b90: ldur            x16, [fp, #-0x30]
    // 0x1136b94: ldur            lr, [fp, #-0x38]
    // 0x1136b98: stp             lr, x16, [SP, #0x70]
    // 0x1136b9c: ldur            x16, [fp, #-0x40]
    // 0x1136ba0: ldur            lr, [fp, #-0x48]
    // 0x1136ba4: stp             lr, x16, [SP, #0x60]
    // 0x1136ba8: ldur            x16, [fp, #-0x50]
    // 0x1136bac: ldur            lr, [fp, #-0x58]
    // 0x1136bb0: stp             lr, x16, [SP, #0x50]
    // 0x1136bb4: ldur            x16, [fp, #-0x60]
    // 0x1136bb8: ldur            lr, [fp, #-0x68]
    // 0x1136bbc: stp             lr, x16, [SP, #0x40]
    // 0x1136bc0: ldur            x16, [fp, #-0x70]
    // 0x1136bc4: stp             x16, NULL, [SP, #0x30]
    // 0x1136bc8: ldur            x16, [fp, #-0x78]
    // 0x1136bcc: ldur            lr, [fp, #-0xb0]
    // 0x1136bd0: stp             lr, x16, [SP, #0x20]
    // 0x1136bd4: ldur            x16, [fp, #-0xa8]
    // 0x1136bd8: ldur            lr, [fp, #-0xa0]
    // 0x1136bdc: stp             lr, x16, [SP, #0x10]
    // 0x1136be0: ldur            x16, [fp, #-0x98]
    // 0x1136be4: stp             x0, x16, [SP]
    // 0x1136be8: ldur            x1, [fp, #-0x10]
    // 0x1136bec: ldur            x2, [fp, #-0x18]
    // 0x1136bf0: r4 = const [0, 0x14, 0x12, 0x14, null]
    //     0x1136bf0: add             x4, PP, #0xd, lsl #12  ; [pp+0xdf20] List(5) [0, 0x14, 0x12, 0x14, Null]
    //     0x1136bf4: ldr             x4, [x4, #0xf20]
    // 0x1136bf8: r0 = hash()
    //     0x1136bf8: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1136bfc: mov             x2, x0
    // 0x1136c00: r0 = BoxInt64Instr(r2)
    //     0x1136c00: sbfiz           x0, x2, #1, #0x1f
    //     0x1136c04: cmp             x2, x0, asr #1
    //     0x1136c08: b.eq            #0x1136c14
    //     0x1136c0c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1136c10: stur            x2, [x0, #7]
    // 0x1136c14: LeaveFrame
    //     0x1136c14: mov             SP, fp
    //     0x1136c18: ldp             fp, lr, [SP], #0x10
    // 0x1136c1c: ret
    //     0x1136c1c: ret             
    // 0x1136c20: mov             x1, x0
    // 0x1136c24: LoadField: r0 = r1->field_9b
    //     0x1136c24: ldur            w0, [x1, #0x9b]
    // 0x1136c28: DecompressPointer r0
    //     0x1136c28: add             x0, x0, HEAP, lsl #32
    // 0x1136c2c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136c30: cmp             w0, w16
    // 0x1136c34: b.ne            #0x1136c44
    // 0x1136c38: r2 = _colors
    //     0x1136c38: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136c3c: ldr             x2, [x2, #0xab0]
    // 0x1136c40: r0 = InitLateFinalInstanceField()
    //     0x1136c40: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136c44: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1136c44: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1136c48: r0 = Throw()
    //     0x1136c48: bl              #0x13ddb2c  ; ThrowStub
    // 0x1136c4c: brk             #0
    // 0x1136c50: mov             x0, x3
    // 0x1136c54: mov             x1, x0
    // 0x1136c58: LoadField: r0 = r1->field_9b
    //     0x1136c58: ldur            w0, [x1, #0x9b]
    // 0x1136c5c: DecompressPointer r0
    //     0x1136c5c: add             x0, x0, HEAP, lsl #32
    // 0x1136c60: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136c64: cmp             w0, w16
    // 0x1136c68: b.ne            #0x1136c78
    // 0x1136c6c: r2 = _colors
    //     0x1136c6c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136c70: ldr             x2, [x2, #0xab0]
    // 0x1136c74: r0 = InitLateFinalInstanceField()
    //     0x1136c74: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136c78: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1136c78: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1136c7c: r0 = Throw()
    //     0x1136c7c: bl              #0x13ddb2c  ; ThrowStub
    // 0x1136c80: brk             #0
    // 0x1136c84: mov             x0, x3
    // 0x1136c88: mov             x1, x0
    // 0x1136c8c: LoadField: r0 = r1->field_9b
    //     0x1136c8c: ldur            w0, [x1, #0x9b]
    // 0x1136c90: DecompressPointer r0
    //     0x1136c90: add             x0, x0, HEAP, lsl #32
    // 0x1136c94: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136c98: cmp             w0, w16
    // 0x1136c9c: b.ne            #0x1136cac
    // 0x1136ca0: r2 = _colors
    //     0x1136ca0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136ca4: ldr             x2, [x2, #0xab0]
    // 0x1136ca8: r0 = InitLateFinalInstanceField()
    //     0x1136ca8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136cac: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1136cac: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1136cb0: r0 = Throw()
    //     0x1136cb0: bl              #0x13ddb2c  ; ThrowStub
    // 0x1136cb4: brk             #0
    // 0x1136cb8: mov             x0, x3
    // 0x1136cbc: mov             x1, x0
    // 0x1136cc0: LoadField: r0 = r1->field_9b
    //     0x1136cc0: ldur            w0, [x1, #0x9b]
    // 0x1136cc4: DecompressPointer r0
    //     0x1136cc4: add             x0, x0, HEAP, lsl #32
    // 0x1136cc8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136ccc: cmp             w0, w16
    // 0x1136cd0: b.ne            #0x1136ce0
    // 0x1136cd4: r2 = _colors
    //     0x1136cd4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136cd8: ldr             x2, [x2, #0xab0]
    // 0x1136cdc: r0 = InitLateFinalInstanceField()
    //     0x1136cdc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136ce0: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1136ce0: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1136ce4: r0 = Throw()
    //     0x1136ce4: bl              #0x13ddb2c  ; ThrowStub
    // 0x1136ce8: brk             #0
    // 0x1136cec: mov             x0, x3
    // 0x1136cf0: mov             x1, x0
    // 0x1136cf4: LoadField: r0 = r1->field_9b
    //     0x1136cf4: ldur            w0, [x1, #0x9b]
    // 0x1136cf8: DecompressPointer r0
    //     0x1136cf8: add             x0, x0, HEAP, lsl #32
    // 0x1136cfc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136d00: cmp             w0, w16
    // 0x1136d04: b.ne            #0x1136d14
    // 0x1136d08: r2 = _colors
    //     0x1136d08: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136d0c: ldr             x2, [x2, #0xab0]
    // 0x1136d10: r0 = InitLateFinalInstanceField()
    //     0x1136d10: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136d14: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1136d14: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1136d18: r0 = Throw()
    //     0x1136d18: bl              #0x13ddb2c  ; ThrowStub
    // 0x1136d1c: brk             #0
    // 0x1136d20: mov             x0, x3
    // 0x1136d24: mov             x1, x0
    // 0x1136d28: LoadField: r0 = r1->field_9b
    //     0x1136d28: ldur            w0, [x1, #0x9b]
    // 0x1136d2c: DecompressPointer r0
    //     0x1136d2c: add             x0, x0, HEAP, lsl #32
    // 0x1136d30: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136d34: cmp             w0, w16
    // 0x1136d38: b.ne            #0x1136d48
    // 0x1136d3c: r2 = _colors
    //     0x1136d3c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136d40: ldr             x2, [x2, #0xab0]
    // 0x1136d44: r0 = InitLateFinalInstanceField()
    //     0x1136d44: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136d48: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1136d48: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1136d4c: r0 = Throw()
    //     0x1136d4c: bl              #0x13ddb2c  ; ThrowStub
    // 0x1136d50: brk             #0
    // 0x1136d54: mov             x0, x3
    // 0x1136d58: mov             x1, x0
    // 0x1136d5c: LoadField: r0 = r1->field_9b
    //     0x1136d5c: ldur            w0, [x1, #0x9b]
    // 0x1136d60: DecompressPointer r0
    //     0x1136d60: add             x0, x0, HEAP, lsl #32
    // 0x1136d64: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136d68: cmp             w0, w16
    // 0x1136d6c: b.ne            #0x1136d7c
    // 0x1136d70: r2 = _colors
    //     0x1136d70: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136d74: ldr             x2, [x2, #0xab0]
    // 0x1136d78: r0 = InitLateFinalInstanceField()
    //     0x1136d78: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136d7c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1136d7c: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1136d80: r0 = Throw()
    //     0x1136d80: bl              #0x13ddb2c  ; ThrowStub
    // 0x1136d84: brk             #0
    // 0x1136d88: mov             x0, x3
    // 0x1136d8c: mov             x1, x0
    // 0x1136d90: LoadField: r0 = r1->field_9b
    //     0x1136d90: ldur            w0, [x1, #0x9b]
    // 0x1136d94: DecompressPointer r0
    //     0x1136d94: add             x0, x0, HEAP, lsl #32
    // 0x1136d98: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136d9c: cmp             w0, w16
    // 0x1136da0: b.ne            #0x1136db0
    // 0x1136da4: r2 = _colors
    //     0x1136da4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136da8: ldr             x2, [x2, #0xab0]
    // 0x1136dac: r0 = InitLateFinalInstanceField()
    //     0x1136dac: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136db0: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1136db0: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1136db4: r0 = Throw()
    //     0x1136db4: bl              #0x13ddb2c  ; ThrowStub
    // 0x1136db8: brk             #0
    // 0x1136dbc: mov             x0, x3
    // 0x1136dc0: mov             x1, x0
    // 0x1136dc4: LoadField: r0 = r1->field_9b
    //     0x1136dc4: ldur            w0, [x1, #0x9b]
    // 0x1136dc8: DecompressPointer r0
    //     0x1136dc8: add             x0, x0, HEAP, lsl #32
    // 0x1136dcc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136dd0: cmp             w0, w16
    // 0x1136dd4: b.ne            #0x1136de4
    // 0x1136dd8: r2 = _colors
    //     0x1136dd8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136ddc: ldr             x2, [x2, #0xab0]
    // 0x1136de0: r0 = InitLateFinalInstanceField()
    //     0x1136de0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136de4: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1136de4: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1136de8: r0 = Throw()
    //     0x1136de8: bl              #0x13ddb2c  ; ThrowStub
    // 0x1136dec: brk             #0
    // 0x1136df0: mov             x0, x3
    // 0x1136df4: mov             x1, x0
    // 0x1136df8: LoadField: r0 = r1->field_9b
    //     0x1136df8: ldur            w0, [x1, #0x9b]
    // 0x1136dfc: DecompressPointer r0
    //     0x1136dfc: add             x0, x0, HEAP, lsl #32
    // 0x1136e00: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136e04: cmp             w0, w16
    // 0x1136e08: b.ne            #0x1136e18
    // 0x1136e0c: r2 = _colors
    //     0x1136e0c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136e10: ldr             x2, [x2, #0xab0]
    // 0x1136e14: r0 = InitLateFinalInstanceField()
    //     0x1136e14: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136e18: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1136e18: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1136e1c: r0 = Throw()
    //     0x1136e1c: bl              #0x13ddb2c  ; ThrowStub
    // 0x1136e20: brk             #0
    // 0x1136e24: mov             x0, x3
    // 0x1136e28: mov             x1, x0
    // 0x1136e2c: LoadField: r0 = r1->field_9b
    //     0x1136e2c: ldur            w0, [x1, #0x9b]
    // 0x1136e30: DecompressPointer r0
    //     0x1136e30: add             x0, x0, HEAP, lsl #32
    // 0x1136e34: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136e38: cmp             w0, w16
    // 0x1136e3c: b.ne            #0x1136e4c
    // 0x1136e40: r2 = _colors
    //     0x1136e40: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136e44: ldr             x2, [x2, #0xab0]
    // 0x1136e48: r0 = InitLateFinalInstanceField()
    //     0x1136e48: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136e4c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1136e4c: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1136e50: r0 = Throw()
    //     0x1136e50: bl              #0x13ddb2c  ; ThrowStub
    // 0x1136e54: brk             #0
    // 0x1136e58: mov             x0, x3
    // 0x1136e5c: mov             x1, x0
    // 0x1136e60: LoadField: r0 = r1->field_9b
    //     0x1136e60: ldur            w0, [x1, #0x9b]
    // 0x1136e64: DecompressPointer r0
    //     0x1136e64: add             x0, x0, HEAP, lsl #32
    // 0x1136e68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136e6c: cmp             w0, w16
    // 0x1136e70: b.ne            #0x1136e80
    // 0x1136e74: r2 = _colors
    //     0x1136e74: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136e78: ldr             x2, [x2, #0xab0]
    // 0x1136e7c: r0 = InitLateFinalInstanceField()
    //     0x1136e7c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136e80: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1136e80: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1136e84: r0 = Throw()
    //     0x1136e84: bl              #0x13ddb2c  ; ThrowStub
    // 0x1136e88: brk             #0
    // 0x1136e8c: mov             x0, x3
    // 0x1136e90: mov             x1, x0
    // 0x1136e94: LoadField: r0 = r1->field_9b
    //     0x1136e94: ldur            w0, [x1, #0x9b]
    // 0x1136e98: DecompressPointer r0
    //     0x1136e98: add             x0, x0, HEAP, lsl #32
    // 0x1136e9c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1136ea0: cmp             w0, w16
    // 0x1136ea4: b.ne            #0x1136eb4
    // 0x1136ea8: r2 = _colors
    //     0x1136ea8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1136eac: ldr             x2, [x2, #0xab0]
    // 0x1136eb0: r0 = InitLateFinalInstanceField()
    //     0x1136eb0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1136eb4: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1136eb4: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1136eb8: r0 = Throw()
    //     0x1136eb8: bl              #0x13ddb2c  ; ThrowStub
    // 0x1136ebc: brk             #0
    // 0x1136ec0: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1136ec0: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1136ec4: r0 = Throw()
    //     0x1136ec4: bl              #0x13ddb2c  ; ThrowStub
    // 0x1136ec8: brk             #0
    // 0x1136ecc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1136ecc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1136ed0: b               #0x1135b88
    // 0x1136ed4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1136ed4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x11657d4, size: 0x598
    // 0x11657d4: EnterFrame
    //     0x11657d4: stp             fp, lr, [SP, #-0x10]!
    //     0x11657d8: mov             fp, SP
    // 0x11657dc: AllocStack(0xd8)
    //     0x11657dc: sub             SP, SP, #0xd8
    // 0x11657e0: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0xd8 */)
    //     0x11657e0: mov             x4, x1
    //     0x11657e4: mov             x0, x2
    //     0x11657e8: stur            x1, [fp, #-0x10]
    //     0x11657ec: stur            x2, [fp, #-0x18]
    //     0x11657f0: stur            d0, [fp, #-0xd8]
    // 0x11657f4: CheckStackOverflow
    //     0x11657f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11657f8: cmp             SP, x16
    //     0x11657fc: b.ls            #0x1165d40
    // 0x1165800: cmp             w4, w0
    // 0x1165804: b.ne            #0x1165818
    // 0x1165808: mov             x0, x4
    // 0x116580c: LeaveFrame
    //     0x116580c: mov             SP, fp
    //     0x1165810: ldp             fp, lr, [SP], #0x10
    // 0x1165814: ret
    //     0x1165814: ret             
    // 0x1165818: LoadField: r1 = r4->field_7
    //     0x1165818: ldur            w1, [x4, #7]
    // 0x116581c: DecompressPointer r1
    //     0x116581c: add             x1, x1, HEAP, lsl #32
    // 0x1165820: LoadField: r2 = r0->field_7
    //     0x1165820: ldur            w2, [x0, #7]
    // 0x1165824: DecompressPointer r2
    //     0x1165824: add             x2, x2, HEAP, lsl #32
    // 0x1165828: r5 = inline_Allocate_Double()
    //     0x1165828: ldp             x5, x3, [THR, #0x60]  ; THR::top
    //     0x116582c: add             x5, x5, #0x10
    //     0x1165830: cmp             x3, x5
    //     0x1165834: b.ls            #0x1165d48
    //     0x1165838: str             x5, [THR, #0x60]  ; THR::top
    //     0x116583c: sub             x5, x5, #0xf
    //     0x1165840: mov             x3, #0xe19c
    //     0x1165844: movk            x3, #3, lsl #16
    //     0x1165848: stur            x3, [x5, #-1]
    // 0x116584c: dmb             ishst
    // 0x1165850: StoreField: r5->field_7 = d0
    //     0x1165850: stur            d0, [x5, #7]
    // 0x1165854: mov             x3, x5
    // 0x1165858: stur            x5, [fp, #-8]
    // 0x116585c: r0 = lerpDouble()
    //     0x116585c: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1165860: mov             x4, x0
    // 0x1165864: ldur            x0, [fp, #-0x10]
    // 0x1165868: stur            x4, [fp, #-0x20]
    // 0x116586c: LoadField: r1 = r0->field_b
    //     0x116586c: ldur            w1, [x0, #0xb]
    // 0x1165870: DecompressPointer r1
    //     0x1165870: add             x1, x1, HEAP, lsl #32
    // 0x1165874: ldur            x5, [fp, #-0x18]
    // 0x1165878: LoadField: r2 = r5->field_b
    //     0x1165878: ldur            w2, [x5, #0xb]
    // 0x116587c: DecompressPointer r2
    //     0x116587c: add             x2, x2, HEAP, lsl #32
    // 0x1165880: ldur            x3, [fp, #-8]
    // 0x1165884: r0 = lerp()
    //     0x1165884: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1165888: mov             x4, x0
    // 0x116588c: ldur            x0, [fp, #-0x10]
    // 0x1165890: stur            x4, [fp, #-0x28]
    // 0x1165894: LoadField: r1 = r0->field_f
    //     0x1165894: ldur            w1, [x0, #0xf]
    // 0x1165898: DecompressPointer r1
    //     0x1165898: add             x1, x1, HEAP, lsl #32
    // 0x116589c: ldur            x5, [fp, #-0x18]
    // 0x11658a0: LoadField: r2 = r5->field_f
    //     0x11658a0: ldur            w2, [x5, #0xf]
    // 0x11658a4: DecompressPointer r2
    //     0x11658a4: add             x2, x2, HEAP, lsl #32
    // 0x11658a8: ldur            x3, [fp, #-8]
    // 0x11658ac: r0 = lerp()
    //     0x11658ac: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11658b0: mov             x4, x0
    // 0x11658b4: ldur            x0, [fp, #-0x10]
    // 0x11658b8: stur            x4, [fp, #-0x30]
    // 0x11658bc: LoadField: r1 = r0->field_13
    //     0x11658bc: ldur            w1, [x0, #0x13]
    // 0x11658c0: DecompressPointer r1
    //     0x11658c0: add             x1, x1, HEAP, lsl #32
    // 0x11658c4: ldur            x5, [fp, #-0x18]
    // 0x11658c8: LoadField: r2 = r5->field_13
    //     0x11658c8: ldur            w2, [x5, #0x13]
    // 0x11658cc: DecompressPointer r2
    //     0x11658cc: add             x2, x2, HEAP, lsl #32
    // 0x11658d0: ldur            x3, [fp, #-8]
    // 0x11658d4: r0 = lerp()
    //     0x11658d4: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11658d8: mov             x4, x0
    // 0x11658dc: ldur            x0, [fp, #-0x10]
    // 0x11658e0: stur            x4, [fp, #-0x38]
    // 0x11658e4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11658e4: ldur            w1, [x0, #0x17]
    // 0x11658e8: DecompressPointer r1
    //     0x11658e8: add             x1, x1, HEAP, lsl #32
    // 0x11658ec: ldur            x5, [fp, #-0x18]
    // 0x11658f0: ArrayLoad: r2 = r5[0]  ; List_4
    //     0x11658f0: ldur            w2, [x5, #0x17]
    // 0x11658f4: DecompressPointer r2
    //     0x11658f4: add             x2, x2, HEAP, lsl #32
    // 0x11658f8: ldur            x3, [fp, #-8]
    // 0x11658fc: r0 = lerp()
    //     0x11658fc: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1165900: mov             x4, x0
    // 0x1165904: ldur            x0, [fp, #-0x10]
    // 0x1165908: stur            x4, [fp, #-0x40]
    // 0x116590c: LoadField: r1 = r0->field_1f
    //     0x116590c: ldur            w1, [x0, #0x1f]
    // 0x1165910: DecompressPointer r1
    //     0x1165910: add             x1, x1, HEAP, lsl #32
    // 0x1165914: ldur            x5, [fp, #-0x18]
    // 0x1165918: LoadField: r2 = r5->field_1f
    //     0x1165918: ldur            w2, [x5, #0x1f]
    // 0x116591c: DecompressPointer r2
    //     0x116591c: add             x2, x2, HEAP, lsl #32
    // 0x1165920: ldur            x3, [fp, #-8]
    // 0x1165924: r0 = lerp()
    //     0x1165924: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1165928: mov             x4, x0
    // 0x116592c: ldur            x0, [fp, #-0x10]
    // 0x1165930: stur            x4, [fp, #-0x48]
    // 0x1165934: LoadField: r1 = r0->field_1b
    //     0x1165934: ldur            w1, [x0, #0x1b]
    // 0x1165938: DecompressPointer r1
    //     0x1165938: add             x1, x1, HEAP, lsl #32
    // 0x116593c: ldur            x5, [fp, #-0x18]
    // 0x1165940: LoadField: r2 = r5->field_1b
    //     0x1165940: ldur            w2, [x5, #0x1b]
    // 0x1165944: DecompressPointer r2
    //     0x1165944: add             x2, x2, HEAP, lsl #32
    // 0x1165948: ldur            x3, [fp, #-8]
    // 0x116594c: r0 = lerp()
    //     0x116594c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1165950: mov             x4, x0
    // 0x1165954: ldur            x0, [fp, #-0x10]
    // 0x1165958: stur            x4, [fp, #-0x50]
    // 0x116595c: LoadField: r1 = r0->field_23
    //     0x116595c: ldur            w1, [x0, #0x23]
    // 0x1165960: DecompressPointer r1
    //     0x1165960: add             x1, x1, HEAP, lsl #32
    // 0x1165964: ldur            x5, [fp, #-0x18]
    // 0x1165968: LoadField: r2 = r5->field_23
    //     0x1165968: ldur            w2, [x5, #0x23]
    // 0x116596c: DecompressPointer r2
    //     0x116596c: add             x2, x2, HEAP, lsl #32
    // 0x1165970: ldur            x3, [fp, #-8]
    // 0x1165974: r0 = lerp()
    //     0x1165974: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1165978: mov             x4, x0
    // 0x116597c: ldur            x0, [fp, #-0x10]
    // 0x1165980: stur            x4, [fp, #-0x58]
    // 0x1165984: LoadField: r1 = r0->field_27
    //     0x1165984: ldur            w1, [x0, #0x27]
    // 0x1165988: DecompressPointer r1
    //     0x1165988: add             x1, x1, HEAP, lsl #32
    // 0x116598c: ldur            x5, [fp, #-0x18]
    // 0x1165990: LoadField: r2 = r5->field_27
    //     0x1165990: ldur            w2, [x5, #0x27]
    // 0x1165994: DecompressPointer r2
    //     0x1165994: add             x2, x2, HEAP, lsl #32
    // 0x1165998: ldur            x3, [fp, #-8]
    // 0x116599c: r0 = lerp()
    //     0x116599c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11659a0: mov             x4, x0
    // 0x11659a4: ldur            x0, [fp, #-0x10]
    // 0x11659a8: stur            x4, [fp, #-0x60]
    // 0x11659ac: LoadField: r1 = r0->field_2b
    //     0x11659ac: ldur            w1, [x0, #0x2b]
    // 0x11659b0: DecompressPointer r1
    //     0x11659b0: add             x1, x1, HEAP, lsl #32
    // 0x11659b4: ldur            x5, [fp, #-0x18]
    // 0x11659b8: LoadField: r2 = r5->field_2b
    //     0x11659b8: ldur            w2, [x5, #0x2b]
    // 0x11659bc: DecompressPointer r2
    //     0x11659bc: add             x2, x2, HEAP, lsl #32
    // 0x11659c0: ldur            x3, [fp, #-8]
    // 0x11659c4: r0 = lerp()
    //     0x11659c4: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11659c8: mov             x4, x0
    // 0x11659cc: ldur            x0, [fp, #-0x10]
    // 0x11659d0: stur            x4, [fp, #-0x68]
    // 0x11659d4: LoadField: r1 = r0->field_2f
    //     0x11659d4: ldur            w1, [x0, #0x2f]
    // 0x11659d8: DecompressPointer r1
    //     0x11659d8: add             x1, x1, HEAP, lsl #32
    // 0x11659dc: ldur            x5, [fp, #-0x18]
    // 0x11659e0: LoadField: r2 = r5->field_2f
    //     0x11659e0: ldur            w2, [x5, #0x2f]
    // 0x11659e4: DecompressPointer r2
    //     0x11659e4: add             x2, x2, HEAP, lsl #32
    // 0x11659e8: ldur            x3, [fp, #-8]
    // 0x11659ec: r0 = lerp()
    //     0x11659ec: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11659f0: mov             x4, x0
    // 0x11659f4: ldur            x0, [fp, #-0x10]
    // 0x11659f8: stur            x4, [fp, #-0x70]
    // 0x11659fc: LoadField: r1 = r0->field_33
    //     0x11659fc: ldur            w1, [x0, #0x33]
    // 0x1165a00: DecompressPointer r1
    //     0x1165a00: add             x1, x1, HEAP, lsl #32
    // 0x1165a04: ldur            x5, [fp, #-0x18]
    // 0x1165a08: LoadField: r2 = r5->field_33
    //     0x1165a08: ldur            w2, [x5, #0x33]
    // 0x1165a0c: DecompressPointer r2
    //     0x1165a0c: add             x2, x2, HEAP, lsl #32
    // 0x1165a10: ldur            x3, [fp, #-8]
    // 0x1165a14: r0 = lerp()
    //     0x1165a14: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1165a18: ldur            x3, [fp, #-8]
    // 0x1165a1c: r1 = Null
    //     0x1165a1c: mov             x1, NULL
    // 0x1165a20: r2 = Null
    //     0x1165a20: mov             x2, NULL
    // 0x1165a24: stur            x0, [fp, #-0x78]
    // 0x1165a28: r0 = lerp()
    //     0x1165a28: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1165a2c: ldur            x0, [fp, #-0x10]
    // 0x1165a30: LoadField: r1 = r0->field_3b
    //     0x1165a30: ldur            w1, [x0, #0x3b]
    // 0x1165a34: DecompressPointer r1
    //     0x1165a34: add             x1, x1, HEAP, lsl #32
    // 0x1165a38: ldur            x4, [fp, #-0x18]
    // 0x1165a3c: LoadField: r2 = r4->field_3b
    //     0x1165a3c: ldur            w2, [x4, #0x3b]
    // 0x1165a40: DecompressPointer r2
    //     0x1165a40: add             x2, x2, HEAP, lsl #32
    // 0x1165a44: ldur            x3, [fp, #-8]
    // 0x1165a48: r0 = lerp()
    //     0x1165a48: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1165a4c: mov             x4, x0
    // 0x1165a50: ldur            x0, [fp, #-0x10]
    // 0x1165a54: stur            x4, [fp, #-0x80]
    // 0x1165a58: LoadField: r1 = r0->field_3f
    //     0x1165a58: ldur            w1, [x0, #0x3f]
    // 0x1165a5c: DecompressPointer r1
    //     0x1165a5c: add             x1, x1, HEAP, lsl #32
    // 0x1165a60: ldur            x5, [fp, #-0x18]
    // 0x1165a64: LoadField: r2 = r5->field_3f
    //     0x1165a64: ldur            w2, [x5, #0x3f]
    // 0x1165a68: DecompressPointer r2
    //     0x1165a68: add             x2, x2, HEAP, lsl #32
    // 0x1165a6c: ldur            x3, [fp, #-8]
    // 0x1165a70: r0 = lerp()
    //     0x1165a70: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1165a74: mov             x4, x0
    // 0x1165a78: ldur            x0, [fp, #-0x10]
    // 0x1165a7c: stur            x4, [fp, #-0x88]
    // 0x1165a80: LoadField: r1 = r0->field_43
    //     0x1165a80: ldur            w1, [x0, #0x43]
    // 0x1165a84: DecompressPointer r1
    //     0x1165a84: add             x1, x1, HEAP, lsl #32
    // 0x1165a88: ldur            x5, [fp, #-0x18]
    // 0x1165a8c: LoadField: r2 = r5->field_43
    //     0x1165a8c: ldur            w2, [x5, #0x43]
    // 0x1165a90: DecompressPointer r2
    //     0x1165a90: add             x2, x2, HEAP, lsl #32
    // 0x1165a94: ldur            x3, [fp, #-8]
    // 0x1165a98: r0 = lerp()
    //     0x1165a98: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1165a9c: ldur            x3, [fp, #-8]
    // 0x1165aa0: r1 = Null
    //     0x1165aa0: mov             x1, NULL
    // 0x1165aa4: r2 = Null
    //     0x1165aa4: mov             x2, NULL
    // 0x1165aa8: stur            x0, [fp, #-0x90]
    // 0x1165aac: r0 = lerp()
    //     0x1165aac: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1165ab0: ldur            d0, [fp, #-0xd8]
    // 0x1165ab4: d1 = 0.500000
    //     0x1165ab4: fmov            d1, #0.50000000
    // 0x1165ab8: fcmp            d1, d0
    // 0x1165abc: b.le            #0x1165ad8
    // 0x1165ac0: ldur            x0, [fp, #-0x10]
    // 0x1165ac4: LoadField: r1 = r0->field_4b
    //     0x1165ac4: ldur            w1, [x0, #0x4b]
    // 0x1165ac8: DecompressPointer r1
    //     0x1165ac8: add             x1, x1, HEAP, lsl #32
    // 0x1165acc: mov             x5, x1
    // 0x1165ad0: ldur            x4, [fp, #-0x18]
    // 0x1165ad4: b               #0x1165aec
    // 0x1165ad8: ldur            x0, [fp, #-0x10]
    // 0x1165adc: ldur            x4, [fp, #-0x18]
    // 0x1165ae0: LoadField: r1 = r4->field_4b
    //     0x1165ae0: ldur            w1, [x4, #0x4b]
    // 0x1165ae4: DecompressPointer r1
    //     0x1165ae4: add             x1, x1, HEAP, lsl #32
    // 0x1165ae8: mov             x5, x1
    // 0x1165aec: stur            x5, [fp, #-0xa0]
    // 0x1165af0: fcmp            d1, d0
    // 0x1165af4: b.le            #0x1165b08
    // 0x1165af8: LoadField: r1 = r0->field_4f
    //     0x1165af8: ldur            w1, [x0, #0x4f]
    // 0x1165afc: DecompressPointer r1
    //     0x1165afc: add             x1, x1, HEAP, lsl #32
    // 0x1165b00: mov             x6, x1
    // 0x1165b04: b               #0x1165b14
    // 0x1165b08: LoadField: r1 = r4->field_4f
    //     0x1165b08: ldur            w1, [x4, #0x4f]
    // 0x1165b0c: DecompressPointer r1
    //     0x1165b0c: add             x1, x1, HEAP, lsl #32
    // 0x1165b10: mov             x6, x1
    // 0x1165b14: stur            x6, [fp, #-0xc0]
    // 0x1165b18: fcmp            d1, d0
    // 0x1165b1c: b.le            #0x1165b30
    // 0x1165b20: LoadField: r1 = r0->field_53
    //     0x1165b20: ldur            w1, [x0, #0x53]
    // 0x1165b24: DecompressPointer r1
    //     0x1165b24: add             x1, x1, HEAP, lsl #32
    // 0x1165b28: mov             x7, x1
    // 0x1165b2c: b               #0x1165b3c
    // 0x1165b30: LoadField: r1 = r4->field_53
    //     0x1165b30: ldur            w1, [x4, #0x53]
    // 0x1165b34: DecompressPointer r1
    //     0x1165b34: add             x1, x1, HEAP, lsl #32
    // 0x1165b38: mov             x7, x1
    // 0x1165b3c: stur            x7, [fp, #-0xb8]
    // 0x1165b40: fcmp            d1, d0
    // 0x1165b44: b.le            #0x1165b58
    // 0x1165b48: LoadField: r1 = r0->field_57
    //     0x1165b48: ldur            w1, [x0, #0x57]
    // 0x1165b4c: DecompressPointer r1
    //     0x1165b4c: add             x1, x1, HEAP, lsl #32
    // 0x1165b50: mov             x8, x1
    // 0x1165b54: b               #0x1165b64
    // 0x1165b58: LoadField: r1 = r4->field_57
    //     0x1165b58: ldur            w1, [x4, #0x57]
    // 0x1165b5c: DecompressPointer r1
    //     0x1165b5c: add             x1, x1, HEAP, lsl #32
    // 0x1165b60: mov             x8, x1
    // 0x1165b64: stur            x8, [fp, #-0xb0]
    // 0x1165b68: fcmp            d1, d0
    // 0x1165b6c: b.le            #0x1165b80
    // 0x1165b70: LoadField: r1 = r0->field_5b
    //     0x1165b70: ldur            w1, [x0, #0x5b]
    // 0x1165b74: DecompressPointer r1
    //     0x1165b74: add             x1, x1, HEAP, lsl #32
    // 0x1165b78: mov             x9, x1
    // 0x1165b7c: b               #0x1165b8c
    // 0x1165b80: LoadField: r1 = r4->field_5b
    //     0x1165b80: ldur            w1, [x4, #0x5b]
    // 0x1165b84: DecompressPointer r1
    //     0x1165b84: add             x1, x1, HEAP, lsl #32
    // 0x1165b88: mov             x9, x1
    // 0x1165b8c: stur            x9, [fp, #-0xa8]
    // 0x1165b90: fcmp            d1, d0
    // 0x1165b94: b.le            #0x1165ba8
    // 0x1165b98: LoadField: r1 = r0->field_6f
    //     0x1165b98: ldur            w1, [x0, #0x6f]
    // 0x1165b9c: DecompressPointer r1
    //     0x1165b9c: add             x1, x1, HEAP, lsl #32
    // 0x1165ba0: stur            x1, [fp, #-0x98]
    // 0x1165ba4: b               #0x1165bb4
    // 0x1165ba8: LoadField: r1 = r4->field_6f
    //     0x1165ba8: ldur            w1, [x4, #0x6f]
    // 0x1165bac: DecompressPointer r1
    //     0x1165bac: add             x1, x1, HEAP, lsl #32
    // 0x1165bb0: stur            x1, [fp, #-0x98]
    // 0x1165bb4: ldur            x3, [fp, #-0x30]
    // 0x1165bb8: ldur            x2, [fp, #-0x38]
    // 0x1165bbc: ldur            x1, [fp, #-0x40]
    // 0x1165bc0: ldur            x25, [fp, #-0x48]
    // 0x1165bc4: ldur            x24, [fp, #-0x50]
    // 0x1165bc8: ldur            x23, [fp, #-0x58]
    // 0x1165bcc: ldur            x20, [fp, #-0x60]
    // 0x1165bd0: ldur            x19, [fp, #-0x68]
    // 0x1165bd4: ldur            x14, [fp, #-0x70]
    // 0x1165bd8: ldur            x13, [fp, #-0x78]
    // 0x1165bdc: ldur            x12, [fp, #-0x80]
    // 0x1165be0: ldur            x11, [fp, #-0x88]
    // 0x1165be4: ldur            x10, [fp, #-0x90]
    // 0x1165be8: LoadField: r5 = r0->field_73
    //     0x1165be8: ldur            w5, [x0, #0x73]
    // 0x1165bec: DecompressPointer r5
    //     0x1165bec: add             x5, x5, HEAP, lsl #32
    // 0x1165bf0: LoadField: r0 = r4->field_73
    //     0x1165bf0: ldur            w0, [x4, #0x73]
    // 0x1165bf4: DecompressPointer r0
    //     0x1165bf4: add             x0, x0, HEAP, lsl #32
    // 0x1165bf8: mov             x1, x5
    // 0x1165bfc: mov             x5, x2
    // 0x1165c00: mov             x2, x0
    // 0x1165c04: mov             x0, x3
    // 0x1165c08: ldur            x3, [fp, #-8]
    // 0x1165c0c: r0 = lerp()
    //     0x1165c0c: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1165c10: mov             x4, x0
    // 0x1165c14: ldur            x0, [fp, #-0x10]
    // 0x1165c18: stur            x4, [fp, #-0xc8]
    // 0x1165c1c: LoadField: r1 = r0->field_77
    //     0x1165c1c: ldur            w1, [x0, #0x77]
    // 0x1165c20: DecompressPointer r1
    //     0x1165c20: add             x1, x1, HEAP, lsl #32
    // 0x1165c24: ldur            x5, [fp, #-0x18]
    // 0x1165c28: LoadField: r2 = r5->field_77
    //     0x1165c28: ldur            w2, [x5, #0x77]
    // 0x1165c2c: DecompressPointer r2
    //     0x1165c2c: add             x2, x2, HEAP, lsl #32
    // 0x1165c30: ldur            x3, [fp, #-8]
    // 0x1165c34: r0 = lerpDouble()
    //     0x1165c34: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1165c38: ldur            x3, [fp, #-8]
    // 0x1165c3c: r1 = Null
    //     0x1165c3c: mov             x1, NULL
    // 0x1165c40: r2 = Null
    //     0x1165c40: mov             x2, NULL
    // 0x1165c44: stur            x0, [fp, #-0xd0]
    // 0x1165c48: r0 = lerp()
    //     0x1165c48: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x1165c4c: ldur            x0, [fp, #-0x10]
    // 0x1165c50: LoadField: r1 = r0->field_8f
    //     0x1165c50: ldur            w1, [x0, #0x8f]
    // 0x1165c54: DecompressPointer r1
    //     0x1165c54: add             x1, x1, HEAP, lsl #32
    // 0x1165c58: ldur            x0, [fp, #-0x18]
    // 0x1165c5c: LoadField: r2 = r0->field_8f
    //     0x1165c5c: ldur            w2, [x0, #0x8f]
    // 0x1165c60: DecompressPointer r2
    //     0x1165c60: add             x2, x2, HEAP, lsl #32
    // 0x1165c64: ldur            x3, [fp, #-8]
    // 0x1165c68: r0 = lerpDouble()
    //     0x1165c68: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1165c6c: stur            x0, [fp, #-8]
    // 0x1165c70: r0 = SliderThemeData()
    //     0x1165c70: bl              #0xc25374  ; AllocateSliderThemeDataStub -> SliderThemeData (size=0x98)
    // 0x1165c74: ldur            x1, [fp, #-0x20]
    // 0x1165c78: StoreField: r0->field_7 = r1
    //     0x1165c78: stur            w1, [x0, #7]
    // 0x1165c7c: ldur            x1, [fp, #-0x28]
    // 0x1165c80: StoreField: r0->field_b = r1
    //     0x1165c80: stur            w1, [x0, #0xb]
    // 0x1165c84: ldur            x1, [fp, #-0x30]
    // 0x1165c88: StoreField: r0->field_f = r1
    //     0x1165c88: stur            w1, [x0, #0xf]
    // 0x1165c8c: ldur            x1, [fp, #-0x38]
    // 0x1165c90: StoreField: r0->field_13 = r1
    //     0x1165c90: stur            w1, [x0, #0x13]
    // 0x1165c94: ldur            x1, [fp, #-0x40]
    // 0x1165c98: ArrayStore: r0[0] = r1  ; List_4
    //     0x1165c98: stur            w1, [x0, #0x17]
    // 0x1165c9c: ldur            x1, [fp, #-0x48]
    // 0x1165ca0: StoreField: r0->field_1f = r1
    //     0x1165ca0: stur            w1, [x0, #0x1f]
    // 0x1165ca4: ldur            x1, [fp, #-0x50]
    // 0x1165ca8: StoreField: r0->field_1b = r1
    //     0x1165ca8: stur            w1, [x0, #0x1b]
    // 0x1165cac: ldur            x1, [fp, #-0x58]
    // 0x1165cb0: StoreField: r0->field_23 = r1
    //     0x1165cb0: stur            w1, [x0, #0x23]
    // 0x1165cb4: ldur            x1, [fp, #-0x60]
    // 0x1165cb8: StoreField: r0->field_27 = r1
    //     0x1165cb8: stur            w1, [x0, #0x27]
    // 0x1165cbc: ldur            x1, [fp, #-0x68]
    // 0x1165cc0: StoreField: r0->field_2b = r1
    //     0x1165cc0: stur            w1, [x0, #0x2b]
    // 0x1165cc4: ldur            x1, [fp, #-0x70]
    // 0x1165cc8: StoreField: r0->field_2f = r1
    //     0x1165cc8: stur            w1, [x0, #0x2f]
    // 0x1165ccc: ldur            x1, [fp, #-0x78]
    // 0x1165cd0: StoreField: r0->field_33 = r1
    //     0x1165cd0: stur            w1, [x0, #0x33]
    // 0x1165cd4: ldur            x1, [fp, #-0x80]
    // 0x1165cd8: StoreField: r0->field_3b = r1
    //     0x1165cd8: stur            w1, [x0, #0x3b]
    // 0x1165cdc: ldur            x1, [fp, #-0x88]
    // 0x1165ce0: StoreField: r0->field_3f = r1
    //     0x1165ce0: stur            w1, [x0, #0x3f]
    // 0x1165ce4: ldur            x1, [fp, #-0x90]
    // 0x1165ce8: StoreField: r0->field_43 = r1
    //     0x1165ce8: stur            w1, [x0, #0x43]
    // 0x1165cec: ldur            x1, [fp, #-0xa0]
    // 0x1165cf0: StoreField: r0->field_4b = r1
    //     0x1165cf0: stur            w1, [x0, #0x4b]
    // 0x1165cf4: ldur            x1, [fp, #-0xc0]
    // 0x1165cf8: StoreField: r0->field_4f = r1
    //     0x1165cf8: stur            w1, [x0, #0x4f]
    // 0x1165cfc: ldur            x1, [fp, #-0xb8]
    // 0x1165d00: StoreField: r0->field_53 = r1
    //     0x1165d00: stur            w1, [x0, #0x53]
    // 0x1165d04: ldur            x1, [fp, #-0xb0]
    // 0x1165d08: StoreField: r0->field_57 = r1
    //     0x1165d08: stur            w1, [x0, #0x57]
    // 0x1165d0c: ldur            x1, [fp, #-0xa8]
    // 0x1165d10: StoreField: r0->field_5b = r1
    //     0x1165d10: stur            w1, [x0, #0x5b]
    // 0x1165d14: ldur            x1, [fp, #-0x98]
    // 0x1165d18: StoreField: r0->field_6f = r1
    //     0x1165d18: stur            w1, [x0, #0x6f]
    // 0x1165d1c: ldur            x1, [fp, #-0xc8]
    // 0x1165d20: StoreField: r0->field_73 = r1
    //     0x1165d20: stur            w1, [x0, #0x73]
    // 0x1165d24: ldur            x1, [fp, #-0xd0]
    // 0x1165d28: StoreField: r0->field_77 = r1
    //     0x1165d28: stur            w1, [x0, #0x77]
    // 0x1165d2c: ldur            x1, [fp, #-8]
    // 0x1165d30: StoreField: r0->field_8f = r1
    //     0x1165d30: stur            w1, [x0, #0x8f]
    // 0x1165d34: LeaveFrame
    //     0x1165d34: mov             SP, fp
    //     0x1165d38: ldp             fp, lr, [SP], #0x10
    // 0x1165d3c: ret
    //     0x1165d3c: ret             
    // 0x1165d40: r0 = StackOverflowSharedWithFPURegs()
    //     0x1165d40: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1165d44: b               #0x1165800
    // 0x1165d48: SaveReg d0
    //     0x1165d48: str             q0, [SP, #-0x10]!
    // 0x1165d4c: stp             x2, x4, [SP, #-0x10]!
    // 0x1165d50: stp             x0, x1, [SP, #-0x10]!
    // 0x1165d54: r0 = AllocateDouble()
    //     0x1165d54: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1165d58: mov             x5, x0
    // 0x1165d5c: ldp             x0, x1, [SP], #0x10
    // 0x1165d60: ldp             x2, x4, [SP], #0x10
    // 0x1165d64: RestoreReg d0
    //     0x1165d64: ldr             q0, [SP], #0x10
    // 0x1165d68: b               #0x1165850
  }
  _ ==(/* No info */) {
    // ** addr: 0x1271b94, size: 0x2774
    // 0x1271b94: EnterFrame
    //     0x1271b94: stp             fp, lr, [SP, #-0x10]!
    //     0x1271b98: mov             fp, SP
    // 0x1271b9c: AllocStack(0x30)
    //     0x1271b9c: sub             SP, SP, #0x30
    // 0x1271ba0: CheckStackOverflow
    //     0x1271ba0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1271ba4: cmp             SP, x16
    //     0x1271ba8: b.ls            #0x12742f8
    // 0x1271bac: ldr             x1, [fp, #0x10]
    // 0x1271bb0: cmp             w1, NULL
    // 0x1271bb4: b.ne            #0x1271bc8
    // 0x1271bb8: r0 = false
    //     0x1271bb8: add             x0, NULL, #0x30  ; false
    // 0x1271bbc: LeaveFrame
    //     0x1271bbc: mov             SP, fp
    //     0x1271bc0: ldp             fp, lr, [SP], #0x10
    // 0x1271bc4: ret
    //     0x1271bc4: ret             
    // 0x1271bc8: ldr             x0, [fp, #0x18]
    // 0x1271bcc: cmp             w0, w1
    // 0x1271bd0: b.ne            #0x1271be4
    // 0x1271bd4: r0 = true
    //     0x1271bd4: add             x0, NULL, #0x20  ; true
    // 0x1271bd8: LeaveFrame
    //     0x1271bd8: mov             SP, fp
    //     0x1271bdc: ldp             fp, lr, [SP], #0x10
    // 0x1271be0: ret
    //     0x1271be0: ret             
    // 0x1271be4: stp             x0, x1, [SP]
    // 0x1271be8: r0 = _haveSameRuntimeType()
    //     0x1271be8: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x1271bec: tbz             w0, #4, #0x1271c00
    // 0x1271bf0: r0 = false
    //     0x1271bf0: add             x0, NULL, #0x30  ; false
    // 0x1271bf4: LeaveFrame
    //     0x1271bf4: mov             SP, fp
    //     0x1271bf8: ldp             fp, lr, [SP], #0x10
    // 0x1271bfc: ret
    //     0x1271bfc: ret             
    // 0x1271c00: ldr             x1, [fp, #0x10]
    // 0x1271c04: r2 = 60
    //     0x1271c04: mov             x2, #0x3c
    // 0x1271c08: branchIfSmi(r1, 0x1271c14)
    //     0x1271c08: tbz             w1, #0, #0x1271c14
    // 0x1271c0c: r2 = LoadClassIdInstr(r1)
    //     0x1271c0c: ldur            x2, [x1, #-1]
    //     0x1271c10: ubfx            x2, x2, #0xc, #0x14
    // 0x1271c14: stur            x2, [fp, #-8]
    // 0x1271c18: r17 = -5069
    //     0x1271c18: mov             x17, #-0x13cd
    // 0x1271c1c: add             x16, x2, x17
    // 0x1271c20: cmp             x16, #3
    // 0x1271c24: b.hi            #0x1273dc0
    // 0x1271c28: ldr             x3, [fp, #0x18]
    // 0x1271c2c: LoadField: r0 = r1->field_7
    //     0x1271c2c: ldur            w0, [x1, #7]
    // 0x1271c30: DecompressPointer r0
    //     0x1271c30: add             x0, x0, HEAP, lsl #32
    // 0x1271c34: LoadField: r4 = r3->field_7
    //     0x1271c34: ldur            w4, [x3, #7]
    // 0x1271c38: DecompressPointer r4
    //     0x1271c38: add             x4, x4, HEAP, lsl #32
    // 0x1271c3c: r5 = LoadClassIdInstr(r0)
    //     0x1271c3c: ldur            x5, [x0, #-1]
    //     0x1271c40: ubfx            x5, x5, #0xc, #0x14
    // 0x1271c44: stp             x4, x0, [SP]
    // 0x1271c48: mov             x0, x5
    // 0x1271c4c: mov             lr, x0
    // 0x1271c50: ldr             lr, [x21, lr, lsl #3]
    // 0x1271c54: blr             lr
    // 0x1271c58: tbnz            w0, #4, #0x1273dc0
    // 0x1271c5c: ldur            x0, [fp, #-8]
    // 0x1271c60: r17 = 5069
    //     0x1271c60: mov             x17, #0x13cd
    // 0x1271c64: cmp             x0, x17
    // 0x1271c68: b.ne            #0x1271c80
    // 0x1271c6c: ldr             x2, [fp, #0x10]
    // 0x1271c70: LoadField: r1 = r2->field_b
    //     0x1271c70: ldur            w1, [x2, #0xb]
    // 0x1271c74: DecompressPointer r1
    //     0x1271c74: add             x1, x1, HEAP, lsl #32
    // 0x1271c78: mov             x2, x1
    // 0x1271c7c: b               #0x1271d00
    // 0x1271c80: ldr             x2, [fp, #0x10]
    // 0x1271c84: r17 = 5070
    //     0x1271c84: mov             x17, #0x13ce
    // 0x1271c88: cmp             x0, x17
    // 0x1271c8c: b.eq            #0x1273dd0
    // 0x1271c90: r17 = 5071
    //     0x1271c90: mov             x17, #0x13cf
    // 0x1271c94: cmp             x0, x17
    // 0x1271c98: b.ne            #0x1271cd0
    // 0x1271c9c: mov             x1, x2
    // 0x1271ca0: LoadField: r0 = r1->field_9b
    //     0x1271ca0: ldur            w0, [x1, #0x9b]
    // 0x1271ca4: DecompressPointer r0
    //     0x1271ca4: add             x0, x0, HEAP, lsl #32
    // 0x1271ca8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1271cac: cmp             w0, w16
    // 0x1271cb0: b.ne            #0x1271cc0
    // 0x1271cb4: r2 = _colors
    //     0x1271cb4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1271cb8: ldr             x2, [x2, #0xa10]
    // 0x1271cbc: r0 = InitLateFinalInstanceField()
    //     0x1271cbc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1271cc0: LoadField: r1 = r0->field_b
    //     0x1271cc0: ldur            w1, [x0, #0xb]
    // 0x1271cc4: DecompressPointer r1
    //     0x1271cc4: add             x1, x1, HEAP, lsl #32
    // 0x1271cc8: mov             x2, x1
    // 0x1271ccc: b               #0x1271d00
    // 0x1271cd0: ldr             x1, [fp, #0x10]
    // 0x1271cd4: LoadField: r0 = r1->field_9b
    //     0x1271cd4: ldur            w0, [x1, #0x9b]
    // 0x1271cd8: DecompressPointer r0
    //     0x1271cd8: add             x0, x0, HEAP, lsl #32
    // 0x1271cdc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1271ce0: cmp             w0, w16
    // 0x1271ce4: b.ne            #0x1271cf4
    // 0x1271ce8: r2 = _colors
    //     0x1271ce8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1271cec: ldr             x2, [x2, #0xa18]
    // 0x1271cf0: r0 = InitLateFinalInstanceField()
    //     0x1271cf0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1271cf4: LoadField: r1 = r0->field_b
    //     0x1271cf4: ldur            w1, [x0, #0xb]
    // 0x1271cf8: DecompressPointer r1
    //     0x1271cf8: add             x1, x1, HEAP, lsl #32
    // 0x1271cfc: mov             x2, x1
    // 0x1271d00: ldr             x0, [fp, #0x18]
    // 0x1271d04: stur            x2, [fp, #-0x18]
    // 0x1271d08: r3 = LoadClassIdInstr(r0)
    //     0x1271d08: ldur            x3, [x0, #-1]
    //     0x1271d0c: ubfx            x3, x3, #0xc, #0x14
    // 0x1271d10: stur            x3, [fp, #-0x10]
    // 0x1271d14: r17 = 5069
    //     0x1271d14: mov             x17, #0x13cd
    // 0x1271d18: cmp             x3, x17
    // 0x1271d1c: b.ne            #0x1271d30
    // 0x1271d20: LoadField: r1 = r0->field_b
    //     0x1271d20: ldur            w1, [x0, #0xb]
    // 0x1271d24: DecompressPointer r1
    //     0x1271d24: add             x1, x1, HEAP, lsl #32
    // 0x1271d28: mov             x0, x2
    // 0x1271d2c: b               #0x1271dac
    // 0x1271d30: r17 = 5070
    //     0x1271d30: mov             x17, #0x13ce
    // 0x1271d34: cmp             x3, x17
    // 0x1271d38: b.eq            #0x1273e00
    // 0x1271d3c: r17 = 5071
    //     0x1271d3c: mov             x17, #0x13cf
    // 0x1271d40: cmp             x3, x17
    // 0x1271d44: b.ne            #0x1271d7c
    // 0x1271d48: mov             x1, x0
    // 0x1271d4c: LoadField: r0 = r1->field_9b
    //     0x1271d4c: ldur            w0, [x1, #0x9b]
    // 0x1271d50: DecompressPointer r0
    //     0x1271d50: add             x0, x0, HEAP, lsl #32
    // 0x1271d54: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1271d58: cmp             w0, w16
    // 0x1271d5c: b.ne            #0x1271d6c
    // 0x1271d60: r2 = _colors
    //     0x1271d60: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1271d64: ldr             x2, [x2, #0xa10]
    // 0x1271d68: r0 = InitLateFinalInstanceField()
    //     0x1271d68: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1271d6c: LoadField: r1 = r0->field_b
    //     0x1271d6c: ldur            w1, [x0, #0xb]
    // 0x1271d70: DecompressPointer r1
    //     0x1271d70: add             x1, x1, HEAP, lsl #32
    // 0x1271d74: ldur            x0, [fp, #-0x18]
    // 0x1271d78: b               #0x1271dac
    // 0x1271d7c: ldr             x1, [fp, #0x18]
    // 0x1271d80: LoadField: r0 = r1->field_9b
    //     0x1271d80: ldur            w0, [x1, #0x9b]
    // 0x1271d84: DecompressPointer r0
    //     0x1271d84: add             x0, x0, HEAP, lsl #32
    // 0x1271d88: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1271d8c: cmp             w0, w16
    // 0x1271d90: b.ne            #0x1271da0
    // 0x1271d94: r2 = _colors
    //     0x1271d94: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1271d98: ldr             x2, [x2, #0xa18]
    // 0x1271d9c: r0 = InitLateFinalInstanceField()
    //     0x1271d9c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1271da0: LoadField: r1 = r0->field_b
    //     0x1271da0: ldur            w1, [x0, #0xb]
    // 0x1271da4: DecompressPointer r1
    //     0x1271da4: add             x1, x1, HEAP, lsl #32
    // 0x1271da8: ldur            x0, [fp, #-0x18]
    // 0x1271dac: r2 = LoadClassIdInstr(r0)
    //     0x1271dac: ldur            x2, [x0, #-1]
    //     0x1271db0: ubfx            x2, x2, #0xc, #0x14
    // 0x1271db4: stp             x1, x0, [SP]
    // 0x1271db8: mov             x0, x2
    // 0x1271dbc: mov             lr, x0
    // 0x1271dc0: ldr             lr, [x21, lr, lsl #3]
    // 0x1271dc4: blr             lr
    // 0x1271dc8: tbnz            w0, #4, #0x1273dc0
    // 0x1271dcc: ldur            x0, [fp, #-8]
    // 0x1271dd0: r17 = 5069
    //     0x1271dd0: mov             x17, #0x13cd
    // 0x1271dd4: cmp             x0, x17
    // 0x1271dd8: b.ne            #0x1271df0
    // 0x1271ddc: ldr             x2, [fp, #0x10]
    // 0x1271de0: LoadField: r1 = r2->field_f
    //     0x1271de0: ldur            w1, [x2, #0xf]
    // 0x1271de4: DecompressPointer r1
    //     0x1271de4: add             x1, x1, HEAP, lsl #32
    // 0x1271de8: mov             x2, x1
    // 0x1271dec: b               #0x1271e98
    // 0x1271df0: ldr             x2, [fp, #0x10]
    // 0x1271df4: r17 = 5070
    //     0x1271df4: mov             x17, #0x13ce
    // 0x1271df8: cmp             x0, x17
    // 0x1271dfc: b.eq            #0x1273e30
    // 0x1271e00: r17 = 5071
    //     0x1271e00: mov             x17, #0x13cf
    // 0x1271e04: cmp             x0, x17
    // 0x1271e08: b.ne            #0x1271e5c
    // 0x1271e0c: mov             x1, x2
    // 0x1271e10: LoadField: r0 = r1->field_9b
    //     0x1271e10: ldur            w0, [x1, #0x9b]
    // 0x1271e14: DecompressPointer r0
    //     0x1271e14: add             x0, x0, HEAP, lsl #32
    // 0x1271e18: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1271e1c: cmp             w0, w16
    // 0x1271e20: b.ne            #0x1271e30
    // 0x1271e24: r2 = _colors
    //     0x1271e24: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1271e28: ldr             x2, [x2, #0xa10]
    // 0x1271e2c: r0 = InitLateFinalInstanceField()
    //     0x1271e2c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1271e30: LoadField: r1 = r0->field_9f
    //     0x1271e30: ldur            w1, [x0, #0x9f]
    // 0x1271e34: DecompressPointer r1
    //     0x1271e34: add             x1, x1, HEAP, lsl #32
    // 0x1271e38: cmp             w1, NULL
    // 0x1271e3c: b.ne            #0x1271e50
    // 0x1271e40: LoadField: r1 = r0->field_7b
    //     0x1271e40: ldur            w1, [x0, #0x7b]
    // 0x1271e44: DecompressPointer r1
    //     0x1271e44: add             x1, x1, HEAP, lsl #32
    // 0x1271e48: mov             x0, x1
    // 0x1271e4c: b               #0x1271e54
    // 0x1271e50: mov             x0, x1
    // 0x1271e54: mov             x2, x0
    // 0x1271e58: b               #0x1271e98
    // 0x1271e5c: ldr             x1, [fp, #0x10]
    // 0x1271e60: LoadField: r0 = r1->field_9b
    //     0x1271e60: ldur            w0, [x1, #0x9b]
    // 0x1271e64: DecompressPointer r0
    //     0x1271e64: add             x0, x0, HEAP, lsl #32
    // 0x1271e68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1271e6c: cmp             w0, w16
    // 0x1271e70: b.ne            #0x1271e80
    // 0x1271e74: r2 = _colors
    //     0x1271e74: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1271e78: ldr             x2, [x2, #0xa18]
    // 0x1271e7c: r0 = InitLateFinalInstanceField()
    //     0x1271e7c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1271e80: LoadField: r1 = r0->field_b
    //     0x1271e80: ldur            w1, [x0, #0xb]
    // 0x1271e84: DecompressPointer r1
    //     0x1271e84: add             x1, x1, HEAP, lsl #32
    // 0x1271e88: d0 = 0.240000
    //     0x1271e88: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a20] IMM: double(0.24) from 0x3fceb851eb851eb8
    //     0x1271e8c: ldr             d0, [x17, #0xa20]
    // 0x1271e90: r0 = withOpacity()
    //     0x1271e90: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1271e94: mov             x2, x0
    // 0x1271e98: ldur            x0, [fp, #-0x10]
    // 0x1271e9c: stur            x2, [fp, #-0x18]
    // 0x1271ea0: r17 = 5069
    //     0x1271ea0: mov             x17, #0x13cd
    // 0x1271ea4: cmp             x0, x17
    // 0x1271ea8: b.ne            #0x1271ec0
    // 0x1271eac: ldr             x3, [fp, #0x18]
    // 0x1271eb0: LoadField: r1 = r3->field_f
    //     0x1271eb0: ldur            w1, [x3, #0xf]
    // 0x1271eb4: DecompressPointer r1
    //     0x1271eb4: add             x1, x1, HEAP, lsl #32
    // 0x1271eb8: mov             x0, x2
    // 0x1271ebc: b               #0x1271f70
    // 0x1271ec0: ldr             x3, [fp, #0x18]
    // 0x1271ec4: r17 = 5070
    //     0x1271ec4: mov             x17, #0x13ce
    // 0x1271ec8: cmp             x0, x17
    // 0x1271ecc: b.eq            #0x1273e60
    // 0x1271ed0: r17 = 5071
    //     0x1271ed0: mov             x17, #0x13cf
    // 0x1271ed4: cmp             x0, x17
    // 0x1271ed8: b.ne            #0x1271f30
    // 0x1271edc: mov             x1, x3
    // 0x1271ee0: LoadField: r0 = r1->field_9b
    //     0x1271ee0: ldur            w0, [x1, #0x9b]
    // 0x1271ee4: DecompressPointer r0
    //     0x1271ee4: add             x0, x0, HEAP, lsl #32
    // 0x1271ee8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1271eec: cmp             w0, w16
    // 0x1271ef0: b.ne            #0x1271f00
    // 0x1271ef4: r2 = _colors
    //     0x1271ef4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1271ef8: ldr             x2, [x2, #0xa10]
    // 0x1271efc: r0 = InitLateFinalInstanceField()
    //     0x1271efc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1271f00: LoadField: r1 = r0->field_9f
    //     0x1271f00: ldur            w1, [x0, #0x9f]
    // 0x1271f04: DecompressPointer r1
    //     0x1271f04: add             x1, x1, HEAP, lsl #32
    // 0x1271f08: cmp             w1, NULL
    // 0x1271f0c: b.ne            #0x1271f20
    // 0x1271f10: LoadField: r1 = r0->field_7b
    //     0x1271f10: ldur            w1, [x0, #0x7b]
    // 0x1271f14: DecompressPointer r1
    //     0x1271f14: add             x1, x1, HEAP, lsl #32
    // 0x1271f18: mov             x0, x1
    // 0x1271f1c: b               #0x1271f24
    // 0x1271f20: mov             x0, x1
    // 0x1271f24: mov             x1, x0
    // 0x1271f28: ldur            x0, [fp, #-0x18]
    // 0x1271f2c: b               #0x1271f70
    // 0x1271f30: ldr             x1, [fp, #0x18]
    // 0x1271f34: LoadField: r0 = r1->field_9b
    //     0x1271f34: ldur            w0, [x1, #0x9b]
    // 0x1271f38: DecompressPointer r0
    //     0x1271f38: add             x0, x0, HEAP, lsl #32
    // 0x1271f3c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1271f40: cmp             w0, w16
    // 0x1271f44: b.ne            #0x1271f54
    // 0x1271f48: r2 = _colors
    //     0x1271f48: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1271f4c: ldr             x2, [x2, #0xa18]
    // 0x1271f50: r0 = InitLateFinalInstanceField()
    //     0x1271f50: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1271f54: LoadField: r1 = r0->field_b
    //     0x1271f54: ldur            w1, [x0, #0xb]
    // 0x1271f58: DecompressPointer r1
    //     0x1271f58: add             x1, x1, HEAP, lsl #32
    // 0x1271f5c: d0 = 0.240000
    //     0x1271f5c: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a20] IMM: double(0.24) from 0x3fceb851eb851eb8
    //     0x1271f60: ldr             d0, [x17, #0xa20]
    // 0x1271f64: r0 = withOpacity()
    //     0x1271f64: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1271f68: mov             x1, x0
    // 0x1271f6c: ldur            x0, [fp, #-0x18]
    // 0x1271f70: r2 = LoadClassIdInstr(r0)
    //     0x1271f70: ldur            x2, [x0, #-1]
    //     0x1271f74: ubfx            x2, x2, #0xc, #0x14
    // 0x1271f78: stp             x1, x0, [SP]
    // 0x1271f7c: mov             x0, x2
    // 0x1271f80: mov             lr, x0
    // 0x1271f84: ldr             lr, [x21, lr, lsl #3]
    // 0x1271f88: blr             lr
    // 0x1271f8c: tbnz            w0, #4, #0x1273dc0
    // 0x1271f90: ldur            x0, [fp, #-8]
    // 0x1271f94: r17 = 5069
    //     0x1271f94: mov             x17, #0x13cd
    // 0x1271f98: cmp             x0, x17
    // 0x1271f9c: b.ne            #0x1271fb4
    // 0x1271fa0: ldr             x2, [fp, #0x10]
    // 0x1271fa4: LoadField: r1 = r2->field_13
    //     0x1271fa4: ldur            w1, [x2, #0x13]
    // 0x1271fa8: DecompressPointer r1
    //     0x1271fa8: add             x1, x1, HEAP, lsl #32
    // 0x1271fac: mov             x2, x1
    // 0x1271fb0: b               #0x127204c
    // 0x1271fb4: ldr             x2, [fp, #0x10]
    // 0x1271fb8: r17 = 5070
    //     0x1271fb8: mov             x17, #0x13ce
    // 0x1271fbc: cmp             x0, x17
    // 0x1271fc0: b.eq            #0x1273e94
    // 0x1271fc4: r17 = 5071
    //     0x1271fc4: mov             x17, #0x13cf
    // 0x1271fc8: cmp             x0, x17
    // 0x1271fcc: b.ne            #0x1272010
    // 0x1271fd0: mov             x1, x2
    // 0x1271fd4: LoadField: r0 = r1->field_9b
    //     0x1271fd4: ldur            w0, [x1, #0x9b]
    // 0x1271fd8: DecompressPointer r0
    //     0x1271fd8: add             x0, x0, HEAP, lsl #32
    // 0x1271fdc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1271fe0: cmp             w0, w16
    // 0x1271fe4: b.ne            #0x1271ff4
    // 0x1271fe8: r2 = _colors
    //     0x1271fe8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1271fec: ldr             x2, [x2, #0xa10]
    // 0x1271ff0: r0 = InitLateFinalInstanceField()
    //     0x1271ff0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1271ff4: LoadField: r1 = r0->field_b
    //     0x1271ff4: ldur            w1, [x0, #0xb]
    // 0x1271ff8: DecompressPointer r1
    //     0x1271ff8: add             x1, x1, HEAP, lsl #32
    // 0x1271ffc: d0 = 0.540000
    //     0x1271ffc: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a28] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0x1272000: ldr             d0, [x17, #0xa28]
    // 0x1272004: r0 = withOpacity()
    //     0x1272004: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1272008: mov             x2, x0
    // 0x127200c: b               #0x127204c
    // 0x1272010: ldr             x1, [fp, #0x10]
    // 0x1272014: LoadField: r0 = r1->field_9b
    //     0x1272014: ldur            w0, [x1, #0x9b]
    // 0x1272018: DecompressPointer r0
    //     0x1272018: add             x0, x0, HEAP, lsl #32
    // 0x127201c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272020: cmp             w0, w16
    // 0x1272024: b.ne            #0x1272034
    // 0x1272028: r2 = _colors
    //     0x1272028: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x127202c: ldr             x2, [x2, #0xa18]
    // 0x1272030: r0 = InitLateFinalInstanceField()
    //     0x1272030: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272034: LoadField: r1 = r0->field_b
    //     0x1272034: ldur            w1, [x0, #0xb]
    // 0x1272038: DecompressPointer r1
    //     0x1272038: add             x1, x1, HEAP, lsl #32
    // 0x127203c: d0 = 0.540000
    //     0x127203c: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a28] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0x1272040: ldr             d0, [x17, #0xa28]
    // 0x1272044: r0 = withOpacity()
    //     0x1272044: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1272048: mov             x2, x0
    // 0x127204c: ldur            x0, [fp, #-0x10]
    // 0x1272050: stur            x2, [fp, #-0x18]
    // 0x1272054: r17 = 5069
    //     0x1272054: mov             x17, #0x13cd
    // 0x1272058: cmp             x0, x17
    // 0x127205c: b.ne            #0x1272074
    // 0x1272060: ldr             x3, [fp, #0x18]
    // 0x1272064: LoadField: r1 = r3->field_13
    //     0x1272064: ldur            w1, [x3, #0x13]
    // 0x1272068: DecompressPointer r1
    //     0x1272068: add             x1, x1, HEAP, lsl #32
    // 0x127206c: mov             x0, x2
    // 0x1272070: b               #0x1272114
    // 0x1272074: ldr             x3, [fp, #0x18]
    // 0x1272078: r17 = 5070
    //     0x1272078: mov             x17, #0x13ce
    // 0x127207c: cmp             x0, x17
    // 0x1272080: b.eq            #0x1273ec4
    // 0x1272084: r17 = 5071
    //     0x1272084: mov             x17, #0x13cf
    // 0x1272088: cmp             x0, x17
    // 0x127208c: b.ne            #0x12720d4
    // 0x1272090: mov             x1, x3
    // 0x1272094: LoadField: r0 = r1->field_9b
    //     0x1272094: ldur            w0, [x1, #0x9b]
    // 0x1272098: DecompressPointer r0
    //     0x1272098: add             x0, x0, HEAP, lsl #32
    // 0x127209c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12720a0: cmp             w0, w16
    // 0x12720a4: b.ne            #0x12720b4
    // 0x12720a8: r2 = _colors
    //     0x12720a8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x12720ac: ldr             x2, [x2, #0xa10]
    // 0x12720b0: r0 = InitLateFinalInstanceField()
    //     0x12720b0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12720b4: LoadField: r1 = r0->field_b
    //     0x12720b4: ldur            w1, [x0, #0xb]
    // 0x12720b8: DecompressPointer r1
    //     0x12720b8: add             x1, x1, HEAP, lsl #32
    // 0x12720bc: d0 = 0.540000
    //     0x12720bc: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a28] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0x12720c0: ldr             d0, [x17, #0xa28]
    // 0x12720c4: r0 = withOpacity()
    //     0x12720c4: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x12720c8: mov             x1, x0
    // 0x12720cc: ldur            x0, [fp, #-0x18]
    // 0x12720d0: b               #0x1272114
    // 0x12720d4: ldr             x1, [fp, #0x18]
    // 0x12720d8: LoadField: r0 = r1->field_9b
    //     0x12720d8: ldur            w0, [x1, #0x9b]
    // 0x12720dc: DecompressPointer r0
    //     0x12720dc: add             x0, x0, HEAP, lsl #32
    // 0x12720e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12720e4: cmp             w0, w16
    // 0x12720e8: b.ne            #0x12720f8
    // 0x12720ec: r2 = _colors
    //     0x12720ec: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x12720f0: ldr             x2, [x2, #0xa18]
    // 0x12720f4: r0 = InitLateFinalInstanceField()
    //     0x12720f4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12720f8: LoadField: r1 = r0->field_b
    //     0x12720f8: ldur            w1, [x0, #0xb]
    // 0x12720fc: DecompressPointer r1
    //     0x12720fc: add             x1, x1, HEAP, lsl #32
    // 0x1272100: d0 = 0.540000
    //     0x1272100: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a28] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0x1272104: ldr             d0, [x17, #0xa28]
    // 0x1272108: r0 = withOpacity()
    //     0x1272108: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x127210c: mov             x1, x0
    // 0x1272110: ldur            x0, [fp, #-0x18]
    // 0x1272114: r2 = LoadClassIdInstr(r0)
    //     0x1272114: ldur            x2, [x0, #-1]
    //     0x1272118: ubfx            x2, x2, #0xc, #0x14
    // 0x127211c: stp             x1, x0, [SP]
    // 0x1272120: mov             x0, x2
    // 0x1272124: mov             lr, x0
    // 0x1272128: ldr             lr, [x21, lr, lsl #3]
    // 0x127212c: blr             lr
    // 0x1272130: tbnz            w0, #4, #0x1273dc0
    // 0x1272134: ldur            x0, [fp, #-8]
    // 0x1272138: r17 = 5069
    //     0x1272138: mov             x17, #0x13cd
    // 0x127213c: cmp             x0, x17
    // 0x1272140: b.ne            #0x1272158
    // 0x1272144: ldr             x2, [fp, #0x10]
    // 0x1272148: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x1272148: ldur            w1, [x2, #0x17]
    // 0x127214c: DecompressPointer r1
    //     0x127214c: add             x1, x1, HEAP, lsl #32
    // 0x1272150: mov             x2, x1
    // 0x1272154: b               #0x1272210
    // 0x1272158: ldr             x2, [fp, #0x10]
    // 0x127215c: r17 = 5070
    //     0x127215c: mov             x17, #0x13ce
    // 0x1272160: cmp             x0, x17
    // 0x1272164: b.eq            #0x1273ef8
    // 0x1272168: r17 = 5071
    //     0x1272168: mov             x17, #0x13cf
    // 0x127216c: cmp             x0, x17
    // 0x1272170: b.ne            #0x12721c4
    // 0x1272174: mov             x1, x2
    // 0x1272178: LoadField: r0 = r1->field_9b
    //     0x1272178: ldur            w0, [x1, #0x9b]
    // 0x127217c: DecompressPointer r0
    //     0x127217c: add             x0, x0, HEAP, lsl #32
    // 0x1272180: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272184: cmp             w0, w16
    // 0x1272188: b.ne            #0x1272198
    // 0x127218c: r2 = _colors
    //     0x127218c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272190: ldr             x2, [x2, #0xa10]
    // 0x1272194: r0 = InitLateFinalInstanceField()
    //     0x1272194: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272198: LoadField: r1 = r0->field_7f
    //     0x1272198: ldur            w1, [x0, #0x7f]
    // 0x127219c: DecompressPointer r1
    //     0x127219c: add             x1, x1, HEAP, lsl #32
    // 0x12721a0: r0 = LoadClassIdInstr(r1)
    //     0x12721a0: ldur            x0, [x1, #-1]
    //     0x12721a4: ubfx            x0, x0, #0xc, #0x14
    // 0x12721a8: d0 = 0.380000
    //     0x12721a8: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x12721ac: ldr             d0, [x17, #0x1f0]
    // 0x12721b0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12721b0: sub             lr, x0, #1, lsl #12
    //     0x12721b4: ldr             lr, [x21, lr, lsl #3]
    //     0x12721b8: blr             lr
    // 0x12721bc: mov             x2, x0
    // 0x12721c0: b               #0x1272210
    // 0x12721c4: ldr             x1, [fp, #0x10]
    // 0x12721c8: LoadField: r0 = r1->field_9b
    //     0x12721c8: ldur            w0, [x1, #0x9b]
    // 0x12721cc: DecompressPointer r0
    //     0x12721cc: add             x0, x0, HEAP, lsl #32
    // 0x12721d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12721d4: cmp             w0, w16
    // 0x12721d8: b.ne            #0x12721e8
    // 0x12721dc: r2 = _colors
    //     0x12721dc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x12721e0: ldr             x2, [x2, #0xa18]
    // 0x12721e4: r0 = InitLateFinalInstanceField()
    //     0x12721e4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12721e8: LoadField: r1 = r0->field_7f
    //     0x12721e8: ldur            w1, [x0, #0x7f]
    // 0x12721ec: DecompressPointer r1
    //     0x12721ec: add             x1, x1, HEAP, lsl #32
    // 0x12721f0: r0 = LoadClassIdInstr(r1)
    //     0x12721f0: ldur            x0, [x1, #-1]
    //     0x12721f4: ubfx            x0, x0, #0xc, #0x14
    // 0x12721f8: d0 = 0.320000
    //     0x12721f8: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a30] IMM: double(0.32) from 0x3fd47ae147ae147b
    //     0x12721fc: ldr             d0, [x17, #0xa30]
    // 0x1272200: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1272200: sub             lr, x0, #1, lsl #12
    //     0x1272204: ldr             lr, [x21, lr, lsl #3]
    //     0x1272208: blr             lr
    // 0x127220c: mov             x2, x0
    // 0x1272210: ldur            x0, [fp, #-0x10]
    // 0x1272214: stur            x2, [fp, #-0x18]
    // 0x1272218: r17 = 5069
    //     0x1272218: mov             x17, #0x13cd
    // 0x127221c: cmp             x0, x17
    // 0x1272220: b.ne            #0x1272238
    // 0x1272224: ldr             x3, [fp, #0x18]
    // 0x1272228: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x1272228: ldur            w1, [x3, #0x17]
    // 0x127222c: DecompressPointer r1
    //     0x127222c: add             x1, x1, HEAP, lsl #32
    // 0x1272230: mov             x0, x2
    // 0x1272234: b               #0x12722f8
    // 0x1272238: ldr             x3, [fp, #0x18]
    // 0x127223c: r17 = 5070
    //     0x127223c: mov             x17, #0x13ce
    // 0x1272240: cmp             x0, x17
    // 0x1272244: b.eq            #0x1273f28
    // 0x1272248: r17 = 5071
    //     0x1272248: mov             x17, #0x13cf
    // 0x127224c: cmp             x0, x17
    // 0x1272250: b.ne            #0x12722a8
    // 0x1272254: mov             x1, x3
    // 0x1272258: LoadField: r0 = r1->field_9b
    //     0x1272258: ldur            w0, [x1, #0x9b]
    // 0x127225c: DecompressPointer r0
    //     0x127225c: add             x0, x0, HEAP, lsl #32
    // 0x1272260: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272264: cmp             w0, w16
    // 0x1272268: b.ne            #0x1272278
    // 0x127226c: r2 = _colors
    //     0x127226c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272270: ldr             x2, [x2, #0xa10]
    // 0x1272274: r0 = InitLateFinalInstanceField()
    //     0x1272274: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272278: LoadField: r1 = r0->field_7f
    //     0x1272278: ldur            w1, [x0, #0x7f]
    // 0x127227c: DecompressPointer r1
    //     0x127227c: add             x1, x1, HEAP, lsl #32
    // 0x1272280: r0 = LoadClassIdInstr(r1)
    //     0x1272280: ldur            x0, [x1, #-1]
    //     0x1272284: ubfx            x0, x0, #0xc, #0x14
    // 0x1272288: d0 = 0.380000
    //     0x1272288: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x127228c: ldr             d0, [x17, #0x1f0]
    // 0x1272290: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1272290: sub             lr, x0, #1, lsl #12
    //     0x1272294: ldr             lr, [x21, lr, lsl #3]
    //     0x1272298: blr             lr
    // 0x127229c: mov             x1, x0
    // 0x12722a0: ldur            x0, [fp, #-0x18]
    // 0x12722a4: b               #0x12722f8
    // 0x12722a8: ldr             x1, [fp, #0x18]
    // 0x12722ac: LoadField: r0 = r1->field_9b
    //     0x12722ac: ldur            w0, [x1, #0x9b]
    // 0x12722b0: DecompressPointer r0
    //     0x12722b0: add             x0, x0, HEAP, lsl #32
    // 0x12722b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12722b8: cmp             w0, w16
    // 0x12722bc: b.ne            #0x12722cc
    // 0x12722c0: r2 = _colors
    //     0x12722c0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x12722c4: ldr             x2, [x2, #0xa18]
    // 0x12722c8: r0 = InitLateFinalInstanceField()
    //     0x12722c8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12722cc: LoadField: r1 = r0->field_7f
    //     0x12722cc: ldur            w1, [x0, #0x7f]
    // 0x12722d0: DecompressPointer r1
    //     0x12722d0: add             x1, x1, HEAP, lsl #32
    // 0x12722d4: r0 = LoadClassIdInstr(r1)
    //     0x12722d4: ldur            x0, [x1, #-1]
    //     0x12722d8: ubfx            x0, x0, #0xc, #0x14
    // 0x12722dc: d0 = 0.320000
    //     0x12722dc: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a30] IMM: double(0.32) from 0x3fd47ae147ae147b
    //     0x12722e0: ldr             d0, [x17, #0xa30]
    // 0x12722e4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12722e4: sub             lr, x0, #1, lsl #12
    //     0x12722e8: ldr             lr, [x21, lr, lsl #3]
    //     0x12722ec: blr             lr
    // 0x12722f0: mov             x1, x0
    // 0x12722f4: ldur            x0, [fp, #-0x18]
    // 0x12722f8: r2 = LoadClassIdInstr(r0)
    //     0x12722f8: ldur            x2, [x0, #-1]
    //     0x12722fc: ubfx            x2, x2, #0xc, #0x14
    // 0x1272300: stp             x1, x0, [SP]
    // 0x1272304: mov             x0, x2
    // 0x1272308: mov             lr, x0
    // 0x127230c: ldr             lr, [x21, lr, lsl #3]
    // 0x1272310: blr             lr
    // 0x1272314: tbnz            w0, #4, #0x1273dc0
    // 0x1272318: ldur            x0, [fp, #-8]
    // 0x127231c: r17 = 5069
    //     0x127231c: mov             x17, #0x13cd
    // 0x1272320: cmp             x0, x17
    // 0x1272324: b.ne            #0x127233c
    // 0x1272328: ldr             x2, [fp, #0x10]
    // 0x127232c: LoadField: r1 = r2->field_1f
    //     0x127232c: ldur            w1, [x2, #0x1f]
    // 0x1272330: DecompressPointer r1
    //     0x1272330: add             x1, x1, HEAP, lsl #32
    // 0x1272334: mov             x2, x1
    // 0x1272338: b               #0x12723f4
    // 0x127233c: ldr             x2, [fp, #0x10]
    // 0x1272340: r17 = 5070
    //     0x1272340: mov             x17, #0x13ce
    // 0x1272344: cmp             x0, x17
    // 0x1272348: b.eq            #0x1273f5c
    // 0x127234c: r17 = 5071
    //     0x127234c: mov             x17, #0x13cf
    // 0x1272350: cmp             x0, x17
    // 0x1272354: b.ne            #0x12723a8
    // 0x1272358: mov             x1, x2
    // 0x127235c: LoadField: r0 = r1->field_9b
    //     0x127235c: ldur            w0, [x1, #0x9b]
    // 0x1272360: DecompressPointer r0
    //     0x1272360: add             x0, x0, HEAP, lsl #32
    // 0x1272364: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272368: cmp             w0, w16
    // 0x127236c: b.ne            #0x127237c
    // 0x1272370: r2 = _colors
    //     0x1272370: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272374: ldr             x2, [x2, #0xa10]
    // 0x1272378: r0 = InitLateFinalInstanceField()
    //     0x1272378: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x127237c: LoadField: r1 = r0->field_7f
    //     0x127237c: ldur            w1, [x0, #0x7f]
    // 0x1272380: DecompressPointer r1
    //     0x1272380: add             x1, x1, HEAP, lsl #32
    // 0x1272384: r0 = LoadClassIdInstr(r1)
    //     0x1272384: ldur            x0, [x1, #-1]
    //     0x1272388: ubfx            x0, x0, #0xc, #0x14
    // 0x127238c: d0 = 0.120000
    //     0x127238c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x1272390: ldr             d0, [x17, #0xc40]
    // 0x1272394: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1272394: sub             lr, x0, #1, lsl #12
    //     0x1272398: ldr             lr, [x21, lr, lsl #3]
    //     0x127239c: blr             lr
    // 0x12723a0: mov             x2, x0
    // 0x12723a4: b               #0x12723f4
    // 0x12723a8: ldr             x1, [fp, #0x10]
    // 0x12723ac: LoadField: r0 = r1->field_9b
    //     0x12723ac: ldur            w0, [x1, #0x9b]
    // 0x12723b0: DecompressPointer r0
    //     0x12723b0: add             x0, x0, HEAP, lsl #32
    // 0x12723b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12723b8: cmp             w0, w16
    // 0x12723bc: b.ne            #0x12723cc
    // 0x12723c0: r2 = _colors
    //     0x12723c0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x12723c4: ldr             x2, [x2, #0xa18]
    // 0x12723c8: r0 = InitLateFinalInstanceField()
    //     0x12723c8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12723cc: LoadField: r1 = r0->field_7f
    //     0x12723cc: ldur            w1, [x0, #0x7f]
    // 0x12723d0: DecompressPointer r1
    //     0x12723d0: add             x1, x1, HEAP, lsl #32
    // 0x12723d4: r0 = LoadClassIdInstr(r1)
    //     0x12723d4: ldur            x0, [x1, #-1]
    //     0x12723d8: ubfx            x0, x0, #0xc, #0x14
    // 0x12723dc: d0 = 0.120000
    //     0x12723dc: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x12723e0: ldr             d0, [x17, #0xc40]
    // 0x12723e4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12723e4: sub             lr, x0, #1, lsl #12
    //     0x12723e8: ldr             lr, [x21, lr, lsl #3]
    //     0x12723ec: blr             lr
    // 0x12723f0: mov             x2, x0
    // 0x12723f4: ldur            x0, [fp, #-0x10]
    // 0x12723f8: stur            x2, [fp, #-0x18]
    // 0x12723fc: r17 = 5069
    //     0x12723fc: mov             x17, #0x13cd
    // 0x1272400: cmp             x0, x17
    // 0x1272404: b.ne            #0x127241c
    // 0x1272408: ldr             x3, [fp, #0x18]
    // 0x127240c: LoadField: r1 = r3->field_1f
    //     0x127240c: ldur            w1, [x3, #0x1f]
    // 0x1272410: DecompressPointer r1
    //     0x1272410: add             x1, x1, HEAP, lsl #32
    // 0x1272414: mov             x0, x2
    // 0x1272418: b               #0x12724dc
    // 0x127241c: ldr             x3, [fp, #0x18]
    // 0x1272420: r17 = 5070
    //     0x1272420: mov             x17, #0x13ce
    // 0x1272424: cmp             x0, x17
    // 0x1272428: b.eq            #0x1273f8c
    // 0x127242c: r17 = 5071
    //     0x127242c: mov             x17, #0x13cf
    // 0x1272430: cmp             x0, x17
    // 0x1272434: b.ne            #0x127248c
    // 0x1272438: mov             x1, x3
    // 0x127243c: LoadField: r0 = r1->field_9b
    //     0x127243c: ldur            w0, [x1, #0x9b]
    // 0x1272440: DecompressPointer r0
    //     0x1272440: add             x0, x0, HEAP, lsl #32
    // 0x1272444: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272448: cmp             w0, w16
    // 0x127244c: b.ne            #0x127245c
    // 0x1272450: r2 = _colors
    //     0x1272450: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272454: ldr             x2, [x2, #0xa10]
    // 0x1272458: r0 = InitLateFinalInstanceField()
    //     0x1272458: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x127245c: LoadField: r1 = r0->field_7f
    //     0x127245c: ldur            w1, [x0, #0x7f]
    // 0x1272460: DecompressPointer r1
    //     0x1272460: add             x1, x1, HEAP, lsl #32
    // 0x1272464: r0 = LoadClassIdInstr(r1)
    //     0x1272464: ldur            x0, [x1, #-1]
    //     0x1272468: ubfx            x0, x0, #0xc, #0x14
    // 0x127246c: d0 = 0.120000
    //     0x127246c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x1272470: ldr             d0, [x17, #0xc40]
    // 0x1272474: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1272474: sub             lr, x0, #1, lsl #12
    //     0x1272478: ldr             lr, [x21, lr, lsl #3]
    //     0x127247c: blr             lr
    // 0x1272480: mov             x1, x0
    // 0x1272484: ldur            x0, [fp, #-0x18]
    // 0x1272488: b               #0x12724dc
    // 0x127248c: ldr             x1, [fp, #0x18]
    // 0x1272490: LoadField: r0 = r1->field_9b
    //     0x1272490: ldur            w0, [x1, #0x9b]
    // 0x1272494: DecompressPointer r0
    //     0x1272494: add             x0, x0, HEAP, lsl #32
    // 0x1272498: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x127249c: cmp             w0, w16
    // 0x12724a0: b.ne            #0x12724b0
    // 0x12724a4: r2 = _colors
    //     0x12724a4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x12724a8: ldr             x2, [x2, #0xa18]
    // 0x12724ac: r0 = InitLateFinalInstanceField()
    //     0x12724ac: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12724b0: LoadField: r1 = r0->field_7f
    //     0x12724b0: ldur            w1, [x0, #0x7f]
    // 0x12724b4: DecompressPointer r1
    //     0x12724b4: add             x1, x1, HEAP, lsl #32
    // 0x12724b8: r0 = LoadClassIdInstr(r1)
    //     0x12724b8: ldur            x0, [x1, #-1]
    //     0x12724bc: ubfx            x0, x0, #0xc, #0x14
    // 0x12724c0: d0 = 0.120000
    //     0x12724c0: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x12724c4: ldr             d0, [x17, #0xc40]
    // 0x12724c8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12724c8: sub             lr, x0, #1, lsl #12
    //     0x12724cc: ldr             lr, [x21, lr, lsl #3]
    //     0x12724d0: blr             lr
    // 0x12724d4: mov             x1, x0
    // 0x12724d8: ldur            x0, [fp, #-0x18]
    // 0x12724dc: r2 = LoadClassIdInstr(r0)
    //     0x12724dc: ldur            x2, [x0, #-1]
    //     0x12724e0: ubfx            x2, x2, #0xc, #0x14
    // 0x12724e4: stp             x1, x0, [SP]
    // 0x12724e8: mov             x0, x2
    // 0x12724ec: mov             lr, x0
    // 0x12724f0: ldr             lr, [x21, lr, lsl #3]
    // 0x12724f4: blr             lr
    // 0x12724f8: tbnz            w0, #4, #0x1273dc0
    // 0x12724fc: ldur            x0, [fp, #-8]
    // 0x1272500: r17 = 5069
    //     0x1272500: mov             x17, #0x13cd
    // 0x1272504: cmp             x0, x17
    // 0x1272508: b.ne            #0x1272520
    // 0x127250c: ldr             x2, [fp, #0x10]
    // 0x1272510: LoadField: r1 = r2->field_1b
    //     0x1272510: ldur            w1, [x2, #0x1b]
    // 0x1272514: DecompressPointer r1
    //     0x1272514: add             x1, x1, HEAP, lsl #32
    // 0x1272518: mov             x2, x1
    // 0x127251c: b               #0x12725d8
    // 0x1272520: ldr             x2, [fp, #0x10]
    // 0x1272524: r17 = 5070
    //     0x1272524: mov             x17, #0x13ce
    // 0x1272528: cmp             x0, x17
    // 0x127252c: b.eq            #0x1273fc0
    // 0x1272530: r17 = 5071
    //     0x1272530: mov             x17, #0x13cf
    // 0x1272534: cmp             x0, x17
    // 0x1272538: b.ne            #0x127258c
    // 0x127253c: mov             x1, x2
    // 0x1272540: LoadField: r0 = r1->field_9b
    //     0x1272540: ldur            w0, [x1, #0x9b]
    // 0x1272544: DecompressPointer r0
    //     0x1272544: add             x0, x0, HEAP, lsl #32
    // 0x1272548: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x127254c: cmp             w0, w16
    // 0x1272550: b.ne            #0x1272560
    // 0x1272554: r2 = _colors
    //     0x1272554: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272558: ldr             x2, [x2, #0xa10]
    // 0x127255c: r0 = InitLateFinalInstanceField()
    //     0x127255c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272560: LoadField: r1 = r0->field_7f
    //     0x1272560: ldur            w1, [x0, #0x7f]
    // 0x1272564: DecompressPointer r1
    //     0x1272564: add             x1, x1, HEAP, lsl #32
    // 0x1272568: r0 = LoadClassIdInstr(r1)
    //     0x1272568: ldur            x0, [x1, #-1]
    //     0x127256c: ubfx            x0, x0, #0xc, #0x14
    // 0x1272570: d0 = 0.120000
    //     0x1272570: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x1272574: ldr             d0, [x17, #0xc40]
    // 0x1272578: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1272578: sub             lr, x0, #1, lsl #12
    //     0x127257c: ldr             lr, [x21, lr, lsl #3]
    //     0x1272580: blr             lr
    // 0x1272584: mov             x2, x0
    // 0x1272588: b               #0x12725d8
    // 0x127258c: ldr             x1, [fp, #0x10]
    // 0x1272590: LoadField: r0 = r1->field_9b
    //     0x1272590: ldur            w0, [x1, #0x9b]
    // 0x1272594: DecompressPointer r0
    //     0x1272594: add             x0, x0, HEAP, lsl #32
    // 0x1272598: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x127259c: cmp             w0, w16
    // 0x12725a0: b.ne            #0x12725b0
    // 0x12725a4: r2 = _colors
    //     0x12725a4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x12725a8: ldr             x2, [x2, #0xa18]
    // 0x12725ac: r0 = InitLateFinalInstanceField()
    //     0x12725ac: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12725b0: LoadField: r1 = r0->field_7f
    //     0x12725b0: ldur            w1, [x0, #0x7f]
    // 0x12725b4: DecompressPointer r1
    //     0x12725b4: add             x1, x1, HEAP, lsl #32
    // 0x12725b8: r0 = LoadClassIdInstr(r1)
    //     0x12725b8: ldur            x0, [x1, #-1]
    //     0x12725bc: ubfx            x0, x0, #0xc, #0x14
    // 0x12725c0: d0 = 0.120000
    //     0x12725c0: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x12725c4: ldr             d0, [x17, #0xc40]
    // 0x12725c8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12725c8: sub             lr, x0, #1, lsl #12
    //     0x12725cc: ldr             lr, [x21, lr, lsl #3]
    //     0x12725d0: blr             lr
    // 0x12725d4: mov             x2, x0
    // 0x12725d8: ldur            x0, [fp, #-0x10]
    // 0x12725dc: stur            x2, [fp, #-0x18]
    // 0x12725e0: r17 = 5069
    //     0x12725e0: mov             x17, #0x13cd
    // 0x12725e4: cmp             x0, x17
    // 0x12725e8: b.ne            #0x1272600
    // 0x12725ec: ldr             x3, [fp, #0x18]
    // 0x12725f0: LoadField: r1 = r3->field_1b
    //     0x12725f0: ldur            w1, [x3, #0x1b]
    // 0x12725f4: DecompressPointer r1
    //     0x12725f4: add             x1, x1, HEAP, lsl #32
    // 0x12725f8: mov             x0, x2
    // 0x12725fc: b               #0x12726c0
    // 0x1272600: ldr             x3, [fp, #0x18]
    // 0x1272604: r17 = 5070
    //     0x1272604: mov             x17, #0x13ce
    // 0x1272608: cmp             x0, x17
    // 0x127260c: b.eq            #0x1273ff0
    // 0x1272610: r17 = 5071
    //     0x1272610: mov             x17, #0x13cf
    // 0x1272614: cmp             x0, x17
    // 0x1272618: b.ne            #0x1272670
    // 0x127261c: mov             x1, x3
    // 0x1272620: LoadField: r0 = r1->field_9b
    //     0x1272620: ldur            w0, [x1, #0x9b]
    // 0x1272624: DecompressPointer r0
    //     0x1272624: add             x0, x0, HEAP, lsl #32
    // 0x1272628: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x127262c: cmp             w0, w16
    // 0x1272630: b.ne            #0x1272640
    // 0x1272634: r2 = _colors
    //     0x1272634: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272638: ldr             x2, [x2, #0xa10]
    // 0x127263c: r0 = InitLateFinalInstanceField()
    //     0x127263c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272640: LoadField: r1 = r0->field_7f
    //     0x1272640: ldur            w1, [x0, #0x7f]
    // 0x1272644: DecompressPointer r1
    //     0x1272644: add             x1, x1, HEAP, lsl #32
    // 0x1272648: r0 = LoadClassIdInstr(r1)
    //     0x1272648: ldur            x0, [x1, #-1]
    //     0x127264c: ubfx            x0, x0, #0xc, #0x14
    // 0x1272650: d0 = 0.120000
    //     0x1272650: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x1272654: ldr             d0, [x17, #0xc40]
    // 0x1272658: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1272658: sub             lr, x0, #1, lsl #12
    //     0x127265c: ldr             lr, [x21, lr, lsl #3]
    //     0x1272660: blr             lr
    // 0x1272664: mov             x1, x0
    // 0x1272668: ldur            x0, [fp, #-0x18]
    // 0x127266c: b               #0x12726c0
    // 0x1272670: ldr             x1, [fp, #0x18]
    // 0x1272674: LoadField: r0 = r1->field_9b
    //     0x1272674: ldur            w0, [x1, #0x9b]
    // 0x1272678: DecompressPointer r0
    //     0x1272678: add             x0, x0, HEAP, lsl #32
    // 0x127267c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272680: cmp             w0, w16
    // 0x1272684: b.ne            #0x1272694
    // 0x1272688: r2 = _colors
    //     0x1272688: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x127268c: ldr             x2, [x2, #0xa18]
    // 0x1272690: r0 = InitLateFinalInstanceField()
    //     0x1272690: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272694: LoadField: r1 = r0->field_7f
    //     0x1272694: ldur            w1, [x0, #0x7f]
    // 0x1272698: DecompressPointer r1
    //     0x1272698: add             x1, x1, HEAP, lsl #32
    // 0x127269c: r0 = LoadClassIdInstr(r1)
    //     0x127269c: ldur            x0, [x1, #-1]
    //     0x12726a0: ubfx            x0, x0, #0xc, #0x14
    // 0x12726a4: d0 = 0.120000
    //     0x12726a4: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x12726a8: ldr             d0, [x17, #0xc40]
    // 0x12726ac: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12726ac: sub             lr, x0, #1, lsl #12
    //     0x12726b0: ldr             lr, [x21, lr, lsl #3]
    //     0x12726b4: blr             lr
    // 0x12726b8: mov             x1, x0
    // 0x12726bc: ldur            x0, [fp, #-0x18]
    // 0x12726c0: r2 = LoadClassIdInstr(r0)
    //     0x12726c0: ldur            x2, [x0, #-1]
    //     0x12726c4: ubfx            x2, x2, #0xc, #0x14
    // 0x12726c8: stp             x1, x0, [SP]
    // 0x12726cc: mov             x0, x2
    // 0x12726d0: mov             lr, x0
    // 0x12726d4: ldr             lr, [x21, lr, lsl #3]
    // 0x12726d8: blr             lr
    // 0x12726dc: tbnz            w0, #4, #0x1273dc0
    // 0x12726e0: ldur            x0, [fp, #-8]
    // 0x12726e4: r17 = 5069
    //     0x12726e4: mov             x17, #0x13cd
    // 0x12726e8: cmp             x0, x17
    // 0x12726ec: b.ne            #0x1272704
    // 0x12726f0: ldr             x2, [fp, #0x10]
    // 0x12726f4: LoadField: r1 = r2->field_23
    //     0x12726f4: ldur            w1, [x2, #0x23]
    // 0x12726f8: DecompressPointer r1
    //     0x12726f8: add             x1, x1, HEAP, lsl #32
    // 0x12726fc: mov             x2, x1
    // 0x1272700: b               #0x127279c
    // 0x1272704: ldr             x2, [fp, #0x10]
    // 0x1272708: r17 = 5070
    //     0x1272708: mov             x17, #0x13ce
    // 0x127270c: cmp             x0, x17
    // 0x1272710: b.eq            #0x1274024
    // 0x1272714: r17 = 5071
    //     0x1272714: mov             x17, #0x13cf
    // 0x1272718: cmp             x0, x17
    // 0x127271c: b.ne            #0x1272760
    // 0x1272720: mov             x1, x2
    // 0x1272724: LoadField: r0 = r1->field_9b
    //     0x1272724: ldur            w0, [x1, #0x9b]
    // 0x1272728: DecompressPointer r0
    //     0x1272728: add             x0, x0, HEAP, lsl #32
    // 0x127272c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272730: cmp             w0, w16
    // 0x1272734: b.ne            #0x1272744
    // 0x1272738: r2 = _colors
    //     0x1272738: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x127273c: ldr             x2, [x2, #0xa10]
    // 0x1272740: r0 = InitLateFinalInstanceField()
    //     0x1272740: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272744: LoadField: r1 = r0->field_f
    //     0x1272744: ldur            w1, [x0, #0xf]
    // 0x1272748: DecompressPointer r1
    //     0x1272748: add             x1, x1, HEAP, lsl #32
    // 0x127274c: d0 = 0.380000
    //     0x127274c: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1272750: ldr             d0, [x17, #0x1f0]
    // 0x1272754: r0 = withOpacity()
    //     0x1272754: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1272758: mov             x2, x0
    // 0x127275c: b               #0x127279c
    // 0x1272760: ldr             x1, [fp, #0x10]
    // 0x1272764: LoadField: r0 = r1->field_9b
    //     0x1272764: ldur            w0, [x1, #0x9b]
    // 0x1272768: DecompressPointer r0
    //     0x1272768: add             x0, x0, HEAP, lsl #32
    // 0x127276c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272770: cmp             w0, w16
    // 0x1272774: b.ne            #0x1272784
    // 0x1272778: r2 = _colors
    //     0x1272778: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x127277c: ldr             x2, [x2, #0xa18]
    // 0x1272780: r0 = InitLateFinalInstanceField()
    //     0x1272780: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272784: LoadField: r1 = r0->field_f
    //     0x1272784: ldur            w1, [x0, #0xf]
    // 0x1272788: DecompressPointer r1
    //     0x1272788: add             x1, x1, HEAP, lsl #32
    // 0x127278c: d0 = 0.540000
    //     0x127278c: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a28] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0x1272790: ldr             d0, [x17, #0xa28]
    // 0x1272794: r0 = withOpacity()
    //     0x1272794: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1272798: mov             x2, x0
    // 0x127279c: ldur            x0, [fp, #-0x10]
    // 0x12727a0: stur            x2, [fp, #-0x18]
    // 0x12727a4: r17 = 5069
    //     0x12727a4: mov             x17, #0x13cd
    // 0x12727a8: cmp             x0, x17
    // 0x12727ac: b.ne            #0x12727c4
    // 0x12727b0: ldr             x3, [fp, #0x18]
    // 0x12727b4: LoadField: r1 = r3->field_23
    //     0x12727b4: ldur            w1, [x3, #0x23]
    // 0x12727b8: DecompressPointer r1
    //     0x12727b8: add             x1, x1, HEAP, lsl #32
    // 0x12727bc: mov             x0, x2
    // 0x12727c0: b               #0x1272864
    // 0x12727c4: ldr             x3, [fp, #0x18]
    // 0x12727c8: r17 = 5070
    //     0x12727c8: mov             x17, #0x13ce
    // 0x12727cc: cmp             x0, x17
    // 0x12727d0: b.eq            #0x1274054
    // 0x12727d4: r17 = 5071
    //     0x12727d4: mov             x17, #0x13cf
    // 0x12727d8: cmp             x0, x17
    // 0x12727dc: b.ne            #0x1272824
    // 0x12727e0: mov             x1, x3
    // 0x12727e4: LoadField: r0 = r1->field_9b
    //     0x12727e4: ldur            w0, [x1, #0x9b]
    // 0x12727e8: DecompressPointer r0
    //     0x12727e8: add             x0, x0, HEAP, lsl #32
    // 0x12727ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12727f0: cmp             w0, w16
    // 0x12727f4: b.ne            #0x1272804
    // 0x12727f8: r2 = _colors
    //     0x12727f8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x12727fc: ldr             x2, [x2, #0xa10]
    // 0x1272800: r0 = InitLateFinalInstanceField()
    //     0x1272800: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272804: LoadField: r1 = r0->field_f
    //     0x1272804: ldur            w1, [x0, #0xf]
    // 0x1272808: DecompressPointer r1
    //     0x1272808: add             x1, x1, HEAP, lsl #32
    // 0x127280c: d0 = 0.380000
    //     0x127280c: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1272810: ldr             d0, [x17, #0x1f0]
    // 0x1272814: r0 = withOpacity()
    //     0x1272814: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1272818: mov             x1, x0
    // 0x127281c: ldur            x0, [fp, #-0x18]
    // 0x1272820: b               #0x1272864
    // 0x1272824: ldr             x1, [fp, #0x18]
    // 0x1272828: LoadField: r0 = r1->field_9b
    //     0x1272828: ldur            w0, [x1, #0x9b]
    // 0x127282c: DecompressPointer r0
    //     0x127282c: add             x0, x0, HEAP, lsl #32
    // 0x1272830: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272834: cmp             w0, w16
    // 0x1272838: b.ne            #0x1272848
    // 0x127283c: r2 = _colors
    //     0x127283c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272840: ldr             x2, [x2, #0xa18]
    // 0x1272844: r0 = InitLateFinalInstanceField()
    //     0x1272844: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272848: LoadField: r1 = r0->field_f
    //     0x1272848: ldur            w1, [x0, #0xf]
    // 0x127284c: DecompressPointer r1
    //     0x127284c: add             x1, x1, HEAP, lsl #32
    // 0x1272850: d0 = 0.540000
    //     0x1272850: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a28] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0x1272854: ldr             d0, [x17, #0xa28]
    // 0x1272858: r0 = withOpacity()
    //     0x1272858: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x127285c: mov             x1, x0
    // 0x1272860: ldur            x0, [fp, #-0x18]
    // 0x1272864: r2 = LoadClassIdInstr(r0)
    //     0x1272864: ldur            x2, [x0, #-1]
    //     0x1272868: ubfx            x2, x2, #0xc, #0x14
    // 0x127286c: stp             x1, x0, [SP]
    // 0x1272870: mov             x0, x2
    // 0x1272874: mov             lr, x0
    // 0x1272878: ldr             lr, [x21, lr, lsl #3]
    // 0x127287c: blr             lr
    // 0x1272880: tbnz            w0, #4, #0x1273dc0
    // 0x1272884: ldur            x0, [fp, #-8]
    // 0x1272888: r17 = 5069
    //     0x1272888: mov             x17, #0x13cd
    // 0x127288c: cmp             x0, x17
    // 0x1272890: b.ne            #0x12728a8
    // 0x1272894: ldr             x2, [fp, #0x10]
    // 0x1272898: LoadField: r1 = r2->field_27
    //     0x1272898: ldur            w1, [x2, #0x27]
    // 0x127289c: DecompressPointer r1
    //     0x127289c: add             x1, x1, HEAP, lsl #32
    // 0x12728a0: mov             x2, x1
    // 0x12728a4: b               #0x1272960
    // 0x12728a8: ldr             x2, [fp, #0x10]
    // 0x12728ac: r17 = 5070
    //     0x12728ac: mov             x17, #0x13ce
    // 0x12728b0: cmp             x0, x17
    // 0x12728b4: b.eq            #0x1274088
    // 0x12728b8: r17 = 5071
    //     0x12728b8: mov             x17, #0x13cf
    // 0x12728bc: cmp             x0, x17
    // 0x12728c0: b.ne            #0x1272924
    // 0x12728c4: mov             x1, x2
    // 0x12728c8: LoadField: r0 = r1->field_9b
    //     0x12728c8: ldur            w0, [x1, #0x9b]
    // 0x12728cc: DecompressPointer r0
    //     0x12728cc: add             x0, x0, HEAP, lsl #32
    // 0x12728d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12728d4: cmp             w0, w16
    // 0x12728d8: b.ne            #0x12728e8
    // 0x12728dc: r2 = _colors
    //     0x12728dc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x12728e0: ldr             x2, [x2, #0xa10]
    // 0x12728e4: r0 = InitLateFinalInstanceField()
    //     0x12728e4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12728e8: LoadField: r1 = r0->field_a3
    //     0x12728e8: ldur            w1, [x0, #0xa3]
    // 0x12728ec: DecompressPointer r1
    //     0x12728ec: add             x1, x1, HEAP, lsl #32
    // 0x12728f0: cmp             w1, NULL
    // 0x12728f4: b.ne            #0x1272900
    // 0x12728f8: LoadField: r1 = r0->field_7f
    //     0x12728f8: ldur            w1, [x0, #0x7f]
    // 0x12728fc: DecompressPointer r1
    //     0x12728fc: add             x1, x1, HEAP, lsl #32
    // 0x1272900: r0 = LoadClassIdInstr(r1)
    //     0x1272900: ldur            x0, [x1, #-1]
    //     0x1272904: ubfx            x0, x0, #0xc, #0x14
    // 0x1272908: d0 = 0.380000
    //     0x1272908: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x127290c: ldr             d0, [x17, #0x1f0]
    // 0x1272910: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1272910: sub             lr, x0, #1, lsl #12
    //     0x1272914: ldr             lr, [x21, lr, lsl #3]
    //     0x1272918: blr             lr
    // 0x127291c: mov             x2, x0
    // 0x1272920: b               #0x1272960
    // 0x1272924: ldr             x1, [fp, #0x10]
    // 0x1272928: LoadField: r0 = r1->field_9b
    //     0x1272928: ldur            w0, [x1, #0x9b]
    // 0x127292c: DecompressPointer r0
    //     0x127292c: add             x0, x0, HEAP, lsl #32
    // 0x1272930: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272934: cmp             w0, w16
    // 0x1272938: b.ne            #0x1272948
    // 0x127293c: r2 = _colors
    //     0x127293c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272940: ldr             x2, [x2, #0xa18]
    // 0x1272944: r0 = InitLateFinalInstanceField()
    //     0x1272944: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272948: LoadField: r1 = r0->field_b
    //     0x1272948: ldur            w1, [x0, #0xb]
    // 0x127294c: DecompressPointer r1
    //     0x127294c: add             x1, x1, HEAP, lsl #32
    // 0x1272950: d0 = 0.540000
    //     0x1272950: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a28] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0x1272954: ldr             d0, [x17, #0xa28]
    // 0x1272958: r0 = withOpacity()
    //     0x1272958: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x127295c: mov             x2, x0
    // 0x1272960: ldur            x0, [fp, #-0x10]
    // 0x1272964: stur            x2, [fp, #-0x18]
    // 0x1272968: r17 = 5069
    //     0x1272968: mov             x17, #0x13cd
    // 0x127296c: cmp             x0, x17
    // 0x1272970: b.ne            #0x1272988
    // 0x1272974: ldr             x3, [fp, #0x18]
    // 0x1272978: LoadField: r1 = r3->field_27
    //     0x1272978: ldur            w1, [x3, #0x27]
    // 0x127297c: DecompressPointer r1
    //     0x127297c: add             x1, x1, HEAP, lsl #32
    // 0x1272980: mov             x0, x2
    // 0x1272984: b               #0x1272a48
    // 0x1272988: ldr             x3, [fp, #0x18]
    // 0x127298c: r17 = 5070
    //     0x127298c: mov             x17, #0x13ce
    // 0x1272990: cmp             x0, x17
    // 0x1272994: b.eq            #0x12740b8
    // 0x1272998: r17 = 5071
    //     0x1272998: mov             x17, #0x13cf
    // 0x127299c: cmp             x0, x17
    // 0x12729a0: b.ne            #0x1272a08
    // 0x12729a4: mov             x1, x3
    // 0x12729a8: LoadField: r0 = r1->field_9b
    //     0x12729a8: ldur            w0, [x1, #0x9b]
    // 0x12729ac: DecompressPointer r0
    //     0x12729ac: add             x0, x0, HEAP, lsl #32
    // 0x12729b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12729b4: cmp             w0, w16
    // 0x12729b8: b.ne            #0x12729c8
    // 0x12729bc: r2 = _colors
    //     0x12729bc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x12729c0: ldr             x2, [x2, #0xa10]
    // 0x12729c4: r0 = InitLateFinalInstanceField()
    //     0x12729c4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12729c8: LoadField: r1 = r0->field_a3
    //     0x12729c8: ldur            w1, [x0, #0xa3]
    // 0x12729cc: DecompressPointer r1
    //     0x12729cc: add             x1, x1, HEAP, lsl #32
    // 0x12729d0: cmp             w1, NULL
    // 0x12729d4: b.ne            #0x12729e0
    // 0x12729d8: LoadField: r1 = r0->field_7f
    //     0x12729d8: ldur            w1, [x0, #0x7f]
    // 0x12729dc: DecompressPointer r1
    //     0x12729dc: add             x1, x1, HEAP, lsl #32
    // 0x12729e0: r0 = LoadClassIdInstr(r1)
    //     0x12729e0: ldur            x0, [x1, #-1]
    //     0x12729e4: ubfx            x0, x0, #0xc, #0x14
    // 0x12729e8: d0 = 0.380000
    //     0x12729e8: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x12729ec: ldr             d0, [x17, #0x1f0]
    // 0x12729f0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12729f0: sub             lr, x0, #1, lsl #12
    //     0x12729f4: ldr             lr, [x21, lr, lsl #3]
    //     0x12729f8: blr             lr
    // 0x12729fc: mov             x1, x0
    // 0x1272a00: ldur            x0, [fp, #-0x18]
    // 0x1272a04: b               #0x1272a48
    // 0x1272a08: ldr             x1, [fp, #0x18]
    // 0x1272a0c: LoadField: r0 = r1->field_9b
    //     0x1272a0c: ldur            w0, [x1, #0x9b]
    // 0x1272a10: DecompressPointer r0
    //     0x1272a10: add             x0, x0, HEAP, lsl #32
    // 0x1272a14: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272a18: cmp             w0, w16
    // 0x1272a1c: b.ne            #0x1272a2c
    // 0x1272a20: r2 = _colors
    //     0x1272a20: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272a24: ldr             x2, [x2, #0xa18]
    // 0x1272a28: r0 = InitLateFinalInstanceField()
    //     0x1272a28: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272a2c: LoadField: r1 = r0->field_b
    //     0x1272a2c: ldur            w1, [x0, #0xb]
    // 0x1272a30: DecompressPointer r1
    //     0x1272a30: add             x1, x1, HEAP, lsl #32
    // 0x1272a34: d0 = 0.540000
    //     0x1272a34: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a28] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0x1272a38: ldr             d0, [x17, #0xa28]
    // 0x1272a3c: r0 = withOpacity()
    //     0x1272a3c: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1272a40: mov             x1, x0
    // 0x1272a44: ldur            x0, [fp, #-0x18]
    // 0x1272a48: r2 = LoadClassIdInstr(r0)
    //     0x1272a48: ldur            x2, [x0, #-1]
    //     0x1272a4c: ubfx            x2, x2, #0xc, #0x14
    // 0x1272a50: stp             x1, x0, [SP]
    // 0x1272a54: mov             x0, x2
    // 0x1272a58: mov             lr, x0
    // 0x1272a5c: ldr             lr, [x21, lr, lsl #3]
    // 0x1272a60: blr             lr
    // 0x1272a64: tbnz            w0, #4, #0x1273dc0
    // 0x1272a68: ldur            x0, [fp, #-8]
    // 0x1272a6c: r17 = 5069
    //     0x1272a6c: mov             x17, #0x13cd
    // 0x1272a70: cmp             x0, x17
    // 0x1272a74: b.ne            #0x1272a8c
    // 0x1272a78: ldr             x2, [fp, #0x10]
    // 0x1272a7c: LoadField: r1 = r2->field_2b
    //     0x1272a7c: ldur            w1, [x2, #0x2b]
    // 0x1272a80: DecompressPointer r1
    //     0x1272a80: add             x1, x1, HEAP, lsl #32
    // 0x1272a84: mov             x2, x1
    // 0x1272a88: b               #0x1272b34
    // 0x1272a8c: ldr             x2, [fp, #0x10]
    // 0x1272a90: r17 = 5070
    //     0x1272a90: mov             x17, #0x13ce
    // 0x1272a94: cmp             x0, x17
    // 0x1272a98: b.eq            #0x12740ec
    // 0x1272a9c: r17 = 5071
    //     0x1272a9c: mov             x17, #0x13cf
    // 0x1272aa0: cmp             x0, x17
    // 0x1272aa4: b.ne            #0x1272af8
    // 0x1272aa8: mov             x1, x2
    // 0x1272aac: LoadField: r0 = r1->field_9b
    //     0x1272aac: ldur            w0, [x1, #0x9b]
    // 0x1272ab0: DecompressPointer r0
    //     0x1272ab0: add             x0, x0, HEAP, lsl #32
    // 0x1272ab4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272ab8: cmp             w0, w16
    // 0x1272abc: b.ne            #0x1272acc
    // 0x1272ac0: r2 = _colors
    //     0x1272ac0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272ac4: ldr             x2, [x2, #0xa10]
    // 0x1272ac8: r0 = InitLateFinalInstanceField()
    //     0x1272ac8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272acc: LoadField: r1 = r0->field_7f
    //     0x1272acc: ldur            w1, [x0, #0x7f]
    // 0x1272ad0: DecompressPointer r1
    //     0x1272ad0: add             x1, x1, HEAP, lsl #32
    // 0x1272ad4: r0 = LoadClassIdInstr(r1)
    //     0x1272ad4: ldur            x0, [x1, #-1]
    //     0x1272ad8: ubfx            x0, x0, #0xc, #0x14
    // 0x1272adc: d0 = 0.380000
    //     0x1272adc: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1272ae0: ldr             d0, [x17, #0x1f0]
    // 0x1272ae4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1272ae4: sub             lr, x0, #1, lsl #12
    //     0x1272ae8: ldr             lr, [x21, lr, lsl #3]
    //     0x1272aec: blr             lr
    // 0x1272af0: mov             x2, x0
    // 0x1272af4: b               #0x1272b34
    // 0x1272af8: ldr             x1, [fp, #0x10]
    // 0x1272afc: LoadField: r0 = r1->field_9b
    //     0x1272afc: ldur            w0, [x1, #0x9b]
    // 0x1272b00: DecompressPointer r0
    //     0x1272b00: add             x0, x0, HEAP, lsl #32
    // 0x1272b04: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272b08: cmp             w0, w16
    // 0x1272b0c: b.ne            #0x1272b1c
    // 0x1272b10: r2 = _colors
    //     0x1272b10: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272b14: ldr             x2, [x2, #0xa18]
    // 0x1272b18: r0 = InitLateFinalInstanceField()
    //     0x1272b18: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272b1c: LoadField: r1 = r0->field_f
    //     0x1272b1c: ldur            w1, [x0, #0xf]
    // 0x1272b20: DecompressPointer r1
    //     0x1272b20: add             x1, x1, HEAP, lsl #32
    // 0x1272b24: d0 = 0.120000
    //     0x1272b24: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x1272b28: ldr             d0, [x17, #0xc40]
    // 0x1272b2c: r0 = withOpacity()
    //     0x1272b2c: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1272b30: mov             x2, x0
    // 0x1272b34: ldur            x0, [fp, #-0x10]
    // 0x1272b38: stur            x2, [fp, #-0x18]
    // 0x1272b3c: r17 = 5069
    //     0x1272b3c: mov             x17, #0x13cd
    // 0x1272b40: cmp             x0, x17
    // 0x1272b44: b.ne            #0x1272b5c
    // 0x1272b48: ldr             x3, [fp, #0x18]
    // 0x1272b4c: LoadField: r1 = r3->field_2b
    //     0x1272b4c: ldur            w1, [x3, #0x2b]
    // 0x1272b50: DecompressPointer r1
    //     0x1272b50: add             x1, x1, HEAP, lsl #32
    // 0x1272b54: mov             x0, x2
    // 0x1272b58: b               #0x1272c0c
    // 0x1272b5c: ldr             x3, [fp, #0x18]
    // 0x1272b60: r17 = 5070
    //     0x1272b60: mov             x17, #0x13ce
    // 0x1272b64: cmp             x0, x17
    // 0x1272b68: b.eq            #0x127411c
    // 0x1272b6c: r17 = 5071
    //     0x1272b6c: mov             x17, #0x13cf
    // 0x1272b70: cmp             x0, x17
    // 0x1272b74: b.ne            #0x1272bcc
    // 0x1272b78: mov             x1, x3
    // 0x1272b7c: LoadField: r0 = r1->field_9b
    //     0x1272b7c: ldur            w0, [x1, #0x9b]
    // 0x1272b80: DecompressPointer r0
    //     0x1272b80: add             x0, x0, HEAP, lsl #32
    // 0x1272b84: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272b88: cmp             w0, w16
    // 0x1272b8c: b.ne            #0x1272b9c
    // 0x1272b90: r2 = _colors
    //     0x1272b90: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272b94: ldr             x2, [x2, #0xa10]
    // 0x1272b98: r0 = InitLateFinalInstanceField()
    //     0x1272b98: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272b9c: LoadField: r1 = r0->field_7f
    //     0x1272b9c: ldur            w1, [x0, #0x7f]
    // 0x1272ba0: DecompressPointer r1
    //     0x1272ba0: add             x1, x1, HEAP, lsl #32
    // 0x1272ba4: r0 = LoadClassIdInstr(r1)
    //     0x1272ba4: ldur            x0, [x1, #-1]
    //     0x1272ba8: ubfx            x0, x0, #0xc, #0x14
    // 0x1272bac: d0 = 0.380000
    //     0x1272bac: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1272bb0: ldr             d0, [x17, #0x1f0]
    // 0x1272bb4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1272bb4: sub             lr, x0, #1, lsl #12
    //     0x1272bb8: ldr             lr, [x21, lr, lsl #3]
    //     0x1272bbc: blr             lr
    // 0x1272bc0: mov             x1, x0
    // 0x1272bc4: ldur            x0, [fp, #-0x18]
    // 0x1272bc8: b               #0x1272c0c
    // 0x1272bcc: ldr             x1, [fp, #0x18]
    // 0x1272bd0: LoadField: r0 = r1->field_9b
    //     0x1272bd0: ldur            w0, [x1, #0x9b]
    // 0x1272bd4: DecompressPointer r0
    //     0x1272bd4: add             x0, x0, HEAP, lsl #32
    // 0x1272bd8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272bdc: cmp             w0, w16
    // 0x1272be0: b.ne            #0x1272bf0
    // 0x1272be4: r2 = _colors
    //     0x1272be4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272be8: ldr             x2, [x2, #0xa18]
    // 0x1272bec: r0 = InitLateFinalInstanceField()
    //     0x1272bec: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272bf0: LoadField: r1 = r0->field_f
    //     0x1272bf0: ldur            w1, [x0, #0xf]
    // 0x1272bf4: DecompressPointer r1
    //     0x1272bf4: add             x1, x1, HEAP, lsl #32
    // 0x1272bf8: d0 = 0.120000
    //     0x1272bf8: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x1272bfc: ldr             d0, [x17, #0xc40]
    // 0x1272c00: r0 = withOpacity()
    //     0x1272c00: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1272c04: mov             x1, x0
    // 0x1272c08: ldur            x0, [fp, #-0x18]
    // 0x1272c0c: r2 = LoadClassIdInstr(r0)
    //     0x1272c0c: ldur            x2, [x0, #-1]
    //     0x1272c10: ubfx            x2, x2, #0xc, #0x14
    // 0x1272c14: stp             x1, x0, [SP]
    // 0x1272c18: mov             x0, x2
    // 0x1272c1c: mov             lr, x0
    // 0x1272c20: ldr             lr, [x21, lr, lsl #3]
    // 0x1272c24: blr             lr
    // 0x1272c28: tbnz            w0, #4, #0x1273dc0
    // 0x1272c2c: ldur            x0, [fp, #-8]
    // 0x1272c30: r17 = 5069
    //     0x1272c30: mov             x17, #0x13cd
    // 0x1272c34: cmp             x0, x17
    // 0x1272c38: b.ne            #0x1272c50
    // 0x1272c3c: ldr             x2, [fp, #0x10]
    // 0x1272c40: LoadField: r1 = r2->field_2f
    //     0x1272c40: ldur            w1, [x2, #0x2f]
    // 0x1272c44: DecompressPointer r1
    //     0x1272c44: add             x1, x1, HEAP, lsl #32
    // 0x1272c48: mov             x2, x1
    // 0x1272c4c: b               #0x1272d08
    // 0x1272c50: ldr             x2, [fp, #0x10]
    // 0x1272c54: r17 = 5070
    //     0x1272c54: mov             x17, #0x13ce
    // 0x1272c58: cmp             x0, x17
    // 0x1272c5c: b.eq            #0x1274150
    // 0x1272c60: r17 = 5071
    //     0x1272c60: mov             x17, #0x13cf
    // 0x1272c64: cmp             x0, x17
    // 0x1272c68: b.ne            #0x1272cbc
    // 0x1272c6c: mov             x1, x2
    // 0x1272c70: LoadField: r0 = r1->field_9b
    //     0x1272c70: ldur            w0, [x1, #0x9b]
    // 0x1272c74: DecompressPointer r0
    //     0x1272c74: add             x0, x0, HEAP, lsl #32
    // 0x1272c78: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272c7c: cmp             w0, w16
    // 0x1272c80: b.ne            #0x1272c90
    // 0x1272c84: r2 = _colors
    //     0x1272c84: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272c88: ldr             x2, [x2, #0xa10]
    // 0x1272c8c: r0 = InitLateFinalInstanceField()
    //     0x1272c8c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272c90: LoadField: r1 = r0->field_7f
    //     0x1272c90: ldur            w1, [x0, #0x7f]
    // 0x1272c94: DecompressPointer r1
    //     0x1272c94: add             x1, x1, HEAP, lsl #32
    // 0x1272c98: r0 = LoadClassIdInstr(r1)
    //     0x1272c98: ldur            x0, [x1, #-1]
    //     0x1272c9c: ubfx            x0, x0, #0xc, #0x14
    // 0x1272ca0: d0 = 0.380000
    //     0x1272ca0: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1272ca4: ldr             d0, [x17, #0x1f0]
    // 0x1272ca8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1272ca8: sub             lr, x0, #1, lsl #12
    //     0x1272cac: ldr             lr, [x21, lr, lsl #3]
    //     0x1272cb0: blr             lr
    // 0x1272cb4: mov             x2, x0
    // 0x1272cb8: b               #0x1272d08
    // 0x1272cbc: ldr             x1, [fp, #0x10]
    // 0x1272cc0: LoadField: r0 = r1->field_9b
    //     0x1272cc0: ldur            w0, [x1, #0x9b]
    // 0x1272cc4: DecompressPointer r0
    //     0x1272cc4: add             x0, x0, HEAP, lsl #32
    // 0x1272cc8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272ccc: cmp             w0, w16
    // 0x1272cd0: b.ne            #0x1272ce0
    // 0x1272cd4: r2 = _colors
    //     0x1272cd4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272cd8: ldr             x2, [x2, #0xa18]
    // 0x1272cdc: r0 = InitLateFinalInstanceField()
    //     0x1272cdc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272ce0: LoadField: r1 = r0->field_7f
    //     0x1272ce0: ldur            w1, [x0, #0x7f]
    // 0x1272ce4: DecompressPointer r1
    //     0x1272ce4: add             x1, x1, HEAP, lsl #32
    // 0x1272ce8: r0 = LoadClassIdInstr(r1)
    //     0x1272ce8: ldur            x0, [x1, #-1]
    //     0x1272cec: ubfx            x0, x0, #0xc, #0x14
    // 0x1272cf0: d0 = 0.120000
    //     0x1272cf0: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x1272cf4: ldr             d0, [x17, #0xc40]
    // 0x1272cf8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1272cf8: sub             lr, x0, #1, lsl #12
    //     0x1272cfc: ldr             lr, [x21, lr, lsl #3]
    //     0x1272d00: blr             lr
    // 0x1272d04: mov             x2, x0
    // 0x1272d08: ldur            x0, [fp, #-0x10]
    // 0x1272d0c: stur            x2, [fp, #-0x18]
    // 0x1272d10: r17 = 5069
    //     0x1272d10: mov             x17, #0x13cd
    // 0x1272d14: cmp             x0, x17
    // 0x1272d18: b.ne            #0x1272d30
    // 0x1272d1c: ldr             x3, [fp, #0x18]
    // 0x1272d20: LoadField: r1 = r3->field_2f
    //     0x1272d20: ldur            w1, [x3, #0x2f]
    // 0x1272d24: DecompressPointer r1
    //     0x1272d24: add             x1, x1, HEAP, lsl #32
    // 0x1272d28: mov             x0, x2
    // 0x1272d2c: b               #0x1272df0
    // 0x1272d30: ldr             x3, [fp, #0x18]
    // 0x1272d34: r17 = 5070
    //     0x1272d34: mov             x17, #0x13ce
    // 0x1272d38: cmp             x0, x17
    // 0x1272d3c: b.eq            #0x1274180
    // 0x1272d40: r17 = 5071
    //     0x1272d40: mov             x17, #0x13cf
    // 0x1272d44: cmp             x0, x17
    // 0x1272d48: b.ne            #0x1272da0
    // 0x1272d4c: mov             x1, x3
    // 0x1272d50: LoadField: r0 = r1->field_9b
    //     0x1272d50: ldur            w0, [x1, #0x9b]
    // 0x1272d54: DecompressPointer r0
    //     0x1272d54: add             x0, x0, HEAP, lsl #32
    // 0x1272d58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272d5c: cmp             w0, w16
    // 0x1272d60: b.ne            #0x1272d70
    // 0x1272d64: r2 = _colors
    //     0x1272d64: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272d68: ldr             x2, [x2, #0xa10]
    // 0x1272d6c: r0 = InitLateFinalInstanceField()
    //     0x1272d6c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272d70: LoadField: r1 = r0->field_7f
    //     0x1272d70: ldur            w1, [x0, #0x7f]
    // 0x1272d74: DecompressPointer r1
    //     0x1272d74: add             x1, x1, HEAP, lsl #32
    // 0x1272d78: r0 = LoadClassIdInstr(r1)
    //     0x1272d78: ldur            x0, [x1, #-1]
    //     0x1272d7c: ubfx            x0, x0, #0xc, #0x14
    // 0x1272d80: d0 = 0.380000
    //     0x1272d80: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1272d84: ldr             d0, [x17, #0x1f0]
    // 0x1272d88: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1272d88: sub             lr, x0, #1, lsl #12
    //     0x1272d8c: ldr             lr, [x21, lr, lsl #3]
    //     0x1272d90: blr             lr
    // 0x1272d94: mov             x1, x0
    // 0x1272d98: ldur            x0, [fp, #-0x18]
    // 0x1272d9c: b               #0x1272df0
    // 0x1272da0: ldr             x1, [fp, #0x18]
    // 0x1272da4: LoadField: r0 = r1->field_9b
    //     0x1272da4: ldur            w0, [x1, #0x9b]
    // 0x1272da8: DecompressPointer r0
    //     0x1272da8: add             x0, x0, HEAP, lsl #32
    // 0x1272dac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272db0: cmp             w0, w16
    // 0x1272db4: b.ne            #0x1272dc4
    // 0x1272db8: r2 = _colors
    //     0x1272db8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272dbc: ldr             x2, [x2, #0xa18]
    // 0x1272dc0: r0 = InitLateFinalInstanceField()
    //     0x1272dc0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272dc4: LoadField: r1 = r0->field_7f
    //     0x1272dc4: ldur            w1, [x0, #0x7f]
    // 0x1272dc8: DecompressPointer r1
    //     0x1272dc8: add             x1, x1, HEAP, lsl #32
    // 0x1272dcc: r0 = LoadClassIdInstr(r1)
    //     0x1272dcc: ldur            x0, [x1, #-1]
    //     0x1272dd0: ubfx            x0, x0, #0xc, #0x14
    // 0x1272dd4: d0 = 0.120000
    //     0x1272dd4: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x1272dd8: ldr             d0, [x17, #0xc40]
    // 0x1272ddc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1272ddc: sub             lr, x0, #1, lsl #12
    //     0x1272de0: ldr             lr, [x21, lr, lsl #3]
    //     0x1272de4: blr             lr
    // 0x1272de8: mov             x1, x0
    // 0x1272dec: ldur            x0, [fp, #-0x18]
    // 0x1272df0: r2 = LoadClassIdInstr(r0)
    //     0x1272df0: ldur            x2, [x0, #-1]
    //     0x1272df4: ubfx            x2, x2, #0xc, #0x14
    // 0x1272df8: stp             x1, x0, [SP]
    // 0x1272dfc: mov             x0, x2
    // 0x1272e00: mov             lr, x0
    // 0x1272e04: ldr             lr, [x21, lr, lsl #3]
    // 0x1272e08: blr             lr
    // 0x1272e0c: tbnz            w0, #4, #0x1273dc0
    // 0x1272e10: ldur            x0, [fp, #-8]
    // 0x1272e14: r17 = 5069
    //     0x1272e14: mov             x17, #0x13cd
    // 0x1272e18: cmp             x0, x17
    // 0x1272e1c: b.ne            #0x1272e34
    // 0x1272e20: ldr             x2, [fp, #0x10]
    // 0x1272e24: LoadField: r1 = r2->field_33
    //     0x1272e24: ldur            w1, [x2, #0x33]
    // 0x1272e28: DecompressPointer r1
    //     0x1272e28: add             x1, x1, HEAP, lsl #32
    // 0x1272e2c: mov             x2, x1
    // 0x1272e30: b               #0x1272eb4
    // 0x1272e34: ldr             x2, [fp, #0x10]
    // 0x1272e38: r17 = 5070
    //     0x1272e38: mov             x17, #0x13ce
    // 0x1272e3c: cmp             x0, x17
    // 0x1272e40: b.eq            #0x12741b4
    // 0x1272e44: r17 = 5071
    //     0x1272e44: mov             x17, #0x13cf
    // 0x1272e48: cmp             x0, x17
    // 0x1272e4c: b.ne            #0x1272e84
    // 0x1272e50: mov             x1, x2
    // 0x1272e54: LoadField: r0 = r1->field_9b
    //     0x1272e54: ldur            w0, [x1, #0x9b]
    // 0x1272e58: DecompressPointer r0
    //     0x1272e58: add             x0, x0, HEAP, lsl #32
    // 0x1272e5c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272e60: cmp             w0, w16
    // 0x1272e64: b.ne            #0x1272e74
    // 0x1272e68: r2 = _colors
    //     0x1272e68: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272e6c: ldr             x2, [x2, #0xa10]
    // 0x1272e70: r0 = InitLateFinalInstanceField()
    //     0x1272e70: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272e74: LoadField: r1 = r0->field_b
    //     0x1272e74: ldur            w1, [x0, #0xb]
    // 0x1272e78: DecompressPointer r1
    //     0x1272e78: add             x1, x1, HEAP, lsl #32
    // 0x1272e7c: mov             x2, x1
    // 0x1272e80: b               #0x1272eb4
    // 0x1272e84: ldr             x1, [fp, #0x10]
    // 0x1272e88: LoadField: r0 = r1->field_9b
    //     0x1272e88: ldur            w0, [x1, #0x9b]
    // 0x1272e8c: DecompressPointer r0
    //     0x1272e8c: add             x0, x0, HEAP, lsl #32
    // 0x1272e90: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272e94: cmp             w0, w16
    // 0x1272e98: b.ne            #0x1272ea8
    // 0x1272e9c: r2 = _colors
    //     0x1272e9c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272ea0: ldr             x2, [x2, #0xa18]
    // 0x1272ea4: r0 = InitLateFinalInstanceField()
    //     0x1272ea4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272ea8: LoadField: r1 = r0->field_b
    //     0x1272ea8: ldur            w1, [x0, #0xb]
    // 0x1272eac: DecompressPointer r1
    //     0x1272eac: add             x1, x1, HEAP, lsl #32
    // 0x1272eb0: mov             x2, x1
    // 0x1272eb4: ldur            x0, [fp, #-0x10]
    // 0x1272eb8: stur            x2, [fp, #-0x18]
    // 0x1272ebc: r17 = 5069
    //     0x1272ebc: mov             x17, #0x13cd
    // 0x1272ec0: cmp             x0, x17
    // 0x1272ec4: b.ne            #0x1272edc
    // 0x1272ec8: ldr             x3, [fp, #0x18]
    // 0x1272ecc: LoadField: r1 = r3->field_33
    //     0x1272ecc: ldur            w1, [x3, #0x33]
    // 0x1272ed0: DecompressPointer r1
    //     0x1272ed0: add             x1, x1, HEAP, lsl #32
    // 0x1272ed4: mov             x0, x2
    // 0x1272ed8: b               #0x1272f5c
    // 0x1272edc: ldr             x3, [fp, #0x18]
    // 0x1272ee0: r17 = 5070
    //     0x1272ee0: mov             x17, #0x13ce
    // 0x1272ee4: cmp             x0, x17
    // 0x1272ee8: b.eq            #0x12741e4
    // 0x1272eec: r17 = 5071
    //     0x1272eec: mov             x17, #0x13cf
    // 0x1272ef0: cmp             x0, x17
    // 0x1272ef4: b.ne            #0x1272f2c
    // 0x1272ef8: mov             x1, x3
    // 0x1272efc: LoadField: r0 = r1->field_9b
    //     0x1272efc: ldur            w0, [x1, #0x9b]
    // 0x1272f00: DecompressPointer r0
    //     0x1272f00: add             x0, x0, HEAP, lsl #32
    // 0x1272f04: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272f08: cmp             w0, w16
    // 0x1272f0c: b.ne            #0x1272f1c
    // 0x1272f10: r2 = _colors
    //     0x1272f10: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272f14: ldr             x2, [x2, #0xa10]
    // 0x1272f18: r0 = InitLateFinalInstanceField()
    //     0x1272f18: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272f1c: LoadField: r1 = r0->field_b
    //     0x1272f1c: ldur            w1, [x0, #0xb]
    // 0x1272f20: DecompressPointer r1
    //     0x1272f20: add             x1, x1, HEAP, lsl #32
    // 0x1272f24: ldur            x0, [fp, #-0x18]
    // 0x1272f28: b               #0x1272f5c
    // 0x1272f2c: ldr             x1, [fp, #0x18]
    // 0x1272f30: LoadField: r0 = r1->field_9b
    //     0x1272f30: ldur            w0, [x1, #0x9b]
    // 0x1272f34: DecompressPointer r0
    //     0x1272f34: add             x0, x0, HEAP, lsl #32
    // 0x1272f38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272f3c: cmp             w0, w16
    // 0x1272f40: b.ne            #0x1272f50
    // 0x1272f44: r2 = _colors
    //     0x1272f44: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272f48: ldr             x2, [x2, #0xa18]
    // 0x1272f4c: r0 = InitLateFinalInstanceField()
    //     0x1272f4c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272f50: LoadField: r1 = r0->field_b
    //     0x1272f50: ldur            w1, [x0, #0xb]
    // 0x1272f54: DecompressPointer r1
    //     0x1272f54: add             x1, x1, HEAP, lsl #32
    // 0x1272f58: ldur            x0, [fp, #-0x18]
    // 0x1272f5c: r2 = LoadClassIdInstr(r0)
    //     0x1272f5c: ldur            x2, [x0, #-1]
    //     0x1272f60: ubfx            x2, x2, #0xc, #0x14
    // 0x1272f64: stp             x1, x0, [SP]
    // 0x1272f68: mov             x0, x2
    // 0x1272f6c: mov             lr, x0
    // 0x1272f70: ldr             lr, [x21, lr, lsl #3]
    // 0x1272f74: blr             lr
    // 0x1272f78: tbnz            w0, #4, #0x1273dc0
    // 0x1272f7c: ldur            x0, [fp, #-8]
    // 0x1272f80: r17 = 5069
    //     0x1272f80: mov             x17, #0x13cd
    // 0x1272f84: cmp             x0, x17
    // 0x1272f88: b.ne            #0x1272fa0
    // 0x1272f8c: ldr             x2, [fp, #0x10]
    // 0x1272f90: LoadField: r1 = r2->field_3b
    //     0x1272f90: ldur            w1, [x2, #0x3b]
    // 0x1272f94: DecompressPointer r1
    //     0x1272f94: add             x1, x1, HEAP, lsl #32
    // 0x1272f98: mov             x2, x1
    // 0x1272f9c: b               #0x127309c
    // 0x1272fa0: ldr             x2, [fp, #0x10]
    // 0x1272fa4: r17 = 5070
    //     0x1272fa4: mov             x17, #0x13ce
    // 0x1272fa8: cmp             x0, x17
    // 0x1272fac: b.eq            #0x1274218
    // 0x1272fb0: r17 = 5071
    //     0x1272fb0: mov             x17, #0x13cf
    // 0x1272fb4: cmp             x0, x17
    // 0x1272fb8: b.ne            #0x127302c
    // 0x1272fbc: mov             x1, x2
    // 0x1272fc0: LoadField: r0 = r1->field_9b
    //     0x1272fc0: ldur            w0, [x1, #0x9b]
    // 0x1272fc4: DecompressPointer r0
    //     0x1272fc4: add             x0, x0, HEAP, lsl #32
    // 0x1272fc8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1272fcc: cmp             w0, w16
    // 0x1272fd0: b.ne            #0x1272fe0
    // 0x1272fd4: r2 = _colors
    //     0x1272fd4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1272fd8: ldr             x2, [x2, #0xa10]
    // 0x1272fdc: r0 = InitLateFinalInstanceField()
    //     0x1272fdc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1272fe0: LoadField: r1 = r0->field_7f
    //     0x1272fe0: ldur            w1, [x0, #0x7f]
    // 0x1272fe4: DecompressPointer r1
    //     0x1272fe4: add             x1, x1, HEAP, lsl #32
    // 0x1272fe8: r0 = LoadClassIdInstr(r1)
    //     0x1272fe8: ldur            x0, [x1, #-1]
    //     0x1272fec: ubfx            x0, x0, #0xc, #0x14
    // 0x1272ff0: d0 = 0.380000
    //     0x1272ff0: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1272ff4: ldr             d0, [x17, #0x1f0]
    // 0x1272ff8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1272ff8: sub             lr, x0, #1, lsl #12
    //     0x1272ffc: ldr             lr, [x21, lr, lsl #3]
    //     0x1273000: blr             lr
    // 0x1273004: mov             x1, x0
    // 0x1273008: ldr             x0, [fp, #0x10]
    // 0x127300c: LoadField: r2 = r0->field_9b
    //     0x127300c: ldur            w2, [x0, #0x9b]
    // 0x1273010: DecompressPointer r2
    //     0x1273010: add             x2, x2, HEAP, lsl #32
    // 0x1273014: LoadField: r3 = r2->field_7b
    //     0x1273014: ldur            w3, [x2, #0x7b]
    // 0x1273018: DecompressPointer r3
    //     0x1273018: add             x3, x3, HEAP, lsl #32
    // 0x127301c: mov             x2, x3
    // 0x1273020: r0 = alphaBlend()
    //     0x1273020: bl              #0xb6ea90  ; [dart:ui] Color::alphaBlend
    // 0x1273024: mov             x2, x0
    // 0x1273028: b               #0x127309c
    // 0x127302c: mov             x0, x2
    // 0x1273030: mov             x1, x0
    // 0x1273034: LoadField: r0 = r1->field_9b
    //     0x1273034: ldur            w0, [x1, #0x9b]
    // 0x1273038: DecompressPointer r0
    //     0x1273038: add             x0, x0, HEAP, lsl #32
    // 0x127303c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1273040: cmp             w0, w16
    // 0x1273044: b.ne            #0x1273054
    // 0x1273048: r2 = _colors
    //     0x1273048: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x127304c: ldr             x2, [x2, #0xa18]
    // 0x1273050: r0 = InitLateFinalInstanceField()
    //     0x1273050: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1273054: LoadField: r1 = r0->field_7f
    //     0x1273054: ldur            w1, [x0, #0x7f]
    // 0x1273058: DecompressPointer r1
    //     0x1273058: add             x1, x1, HEAP, lsl #32
    // 0x127305c: r0 = LoadClassIdInstr(r1)
    //     0x127305c: ldur            x0, [x1, #-1]
    //     0x1273060: ubfx            x0, x0, #0xc, #0x14
    // 0x1273064: d0 = 0.380000
    //     0x1273064: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1273068: ldr             d0, [x17, #0x1f0]
    // 0x127306c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x127306c: sub             lr, x0, #1, lsl #12
    //     0x1273070: ldr             lr, [x21, lr, lsl #3]
    //     0x1273074: blr             lr
    // 0x1273078: mov             x1, x0
    // 0x127307c: ldr             x0, [fp, #0x10]
    // 0x1273080: LoadField: r2 = r0->field_9b
    //     0x1273080: ldur            w2, [x0, #0x9b]
    // 0x1273084: DecompressPointer r2
    //     0x1273084: add             x2, x2, HEAP, lsl #32
    // 0x1273088: LoadField: r3 = r2->field_7b
    //     0x1273088: ldur            w3, [x2, #0x7b]
    // 0x127308c: DecompressPointer r3
    //     0x127308c: add             x3, x3, HEAP, lsl #32
    // 0x1273090: mov             x2, x3
    // 0x1273094: r0 = alphaBlend()
    //     0x1273094: bl              #0xb6ea90  ; [dart:ui] Color::alphaBlend
    // 0x1273098: mov             x2, x0
    // 0x127309c: ldur            x0, [fp, #-0x10]
    // 0x12730a0: stur            x2, [fp, #-0x18]
    // 0x12730a4: r17 = 5069
    //     0x12730a4: mov             x17, #0x13cd
    // 0x12730a8: cmp             x0, x17
    // 0x12730ac: b.ne            #0x12730c4
    // 0x12730b0: ldr             x3, [fp, #0x18]
    // 0x12730b4: LoadField: r1 = r3->field_3b
    //     0x12730b4: ldur            w1, [x3, #0x3b]
    // 0x12730b8: DecompressPointer r1
    //     0x12730b8: add             x1, x1, HEAP, lsl #32
    // 0x12730bc: mov             x0, x2
    // 0x12730c0: b               #0x12731c8
    // 0x12730c4: ldr             x3, [fp, #0x18]
    // 0x12730c8: r17 = 5070
    //     0x12730c8: mov             x17, #0x13ce
    // 0x12730cc: cmp             x0, x17
    // 0x12730d0: b.eq            #0x1274248
    // 0x12730d4: r17 = 5071
    //     0x12730d4: mov             x17, #0x13cf
    // 0x12730d8: cmp             x0, x17
    // 0x12730dc: b.ne            #0x1273154
    // 0x12730e0: mov             x1, x3
    // 0x12730e4: LoadField: r0 = r1->field_9b
    //     0x12730e4: ldur            w0, [x1, #0x9b]
    // 0x12730e8: DecompressPointer r0
    //     0x12730e8: add             x0, x0, HEAP, lsl #32
    // 0x12730ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12730f0: cmp             w0, w16
    // 0x12730f4: b.ne            #0x1273104
    // 0x12730f8: r2 = _colors
    //     0x12730f8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x12730fc: ldr             x2, [x2, #0xa10]
    // 0x1273100: r0 = InitLateFinalInstanceField()
    //     0x1273100: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1273104: LoadField: r1 = r0->field_7f
    //     0x1273104: ldur            w1, [x0, #0x7f]
    // 0x1273108: DecompressPointer r1
    //     0x1273108: add             x1, x1, HEAP, lsl #32
    // 0x127310c: r0 = LoadClassIdInstr(r1)
    //     0x127310c: ldur            x0, [x1, #-1]
    //     0x1273110: ubfx            x0, x0, #0xc, #0x14
    // 0x1273114: d0 = 0.380000
    //     0x1273114: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1273118: ldr             d0, [x17, #0x1f0]
    // 0x127311c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x127311c: sub             lr, x0, #1, lsl #12
    //     0x1273120: ldr             lr, [x21, lr, lsl #3]
    //     0x1273124: blr             lr
    // 0x1273128: mov             x1, x0
    // 0x127312c: ldr             x0, [fp, #0x18]
    // 0x1273130: LoadField: r2 = r0->field_9b
    //     0x1273130: ldur            w2, [x0, #0x9b]
    // 0x1273134: DecompressPointer r2
    //     0x1273134: add             x2, x2, HEAP, lsl #32
    // 0x1273138: LoadField: r3 = r2->field_7b
    //     0x1273138: ldur            w3, [x2, #0x7b]
    // 0x127313c: DecompressPointer r3
    //     0x127313c: add             x3, x3, HEAP, lsl #32
    // 0x1273140: mov             x2, x3
    // 0x1273144: r0 = alphaBlend()
    //     0x1273144: bl              #0xb6ea90  ; [dart:ui] Color::alphaBlend
    // 0x1273148: mov             x1, x0
    // 0x127314c: ldur            x0, [fp, #-0x18]
    // 0x1273150: b               #0x12731c8
    // 0x1273154: mov             x0, x3
    // 0x1273158: mov             x1, x0
    // 0x127315c: LoadField: r0 = r1->field_9b
    //     0x127315c: ldur            w0, [x1, #0x9b]
    // 0x1273160: DecompressPointer r0
    //     0x1273160: add             x0, x0, HEAP, lsl #32
    // 0x1273164: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1273168: cmp             w0, w16
    // 0x127316c: b.ne            #0x127317c
    // 0x1273170: r2 = _colors
    //     0x1273170: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1273174: ldr             x2, [x2, #0xa18]
    // 0x1273178: r0 = InitLateFinalInstanceField()
    //     0x1273178: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x127317c: LoadField: r1 = r0->field_7f
    //     0x127317c: ldur            w1, [x0, #0x7f]
    // 0x1273180: DecompressPointer r1
    //     0x1273180: add             x1, x1, HEAP, lsl #32
    // 0x1273184: r0 = LoadClassIdInstr(r1)
    //     0x1273184: ldur            x0, [x1, #-1]
    //     0x1273188: ubfx            x0, x0, #0xc, #0x14
    // 0x127318c: d0 = 0.380000
    //     0x127318c: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1273190: ldr             d0, [x17, #0x1f0]
    // 0x1273194: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1273194: sub             lr, x0, #1, lsl #12
    //     0x1273198: ldr             lr, [x21, lr, lsl #3]
    //     0x127319c: blr             lr
    // 0x12731a0: mov             x1, x0
    // 0x12731a4: ldr             x0, [fp, #0x18]
    // 0x12731a8: LoadField: r2 = r0->field_9b
    //     0x12731a8: ldur            w2, [x0, #0x9b]
    // 0x12731ac: DecompressPointer r2
    //     0x12731ac: add             x2, x2, HEAP, lsl #32
    // 0x12731b0: LoadField: r3 = r2->field_7b
    //     0x12731b0: ldur            w3, [x2, #0x7b]
    // 0x12731b4: DecompressPointer r3
    //     0x12731b4: add             x3, x3, HEAP, lsl #32
    // 0x12731b8: mov             x2, x3
    // 0x12731bc: r0 = alphaBlend()
    //     0x12731bc: bl              #0xb6ea90  ; [dart:ui] Color::alphaBlend
    // 0x12731c0: mov             x1, x0
    // 0x12731c4: ldur            x0, [fp, #-0x18]
    // 0x12731c8: r2 = LoadClassIdInstr(r0)
    //     0x12731c8: ldur            x2, [x0, #-1]
    //     0x12731cc: ubfx            x2, x2, #0xc, #0x14
    // 0x12731d0: stp             x1, x0, [SP]
    // 0x12731d4: mov             x0, x2
    // 0x12731d8: mov             lr, x0
    // 0x12731dc: ldr             lr, [x21, lr, lsl #3]
    // 0x12731e0: blr             lr
    // 0x12731e4: tbnz            w0, #4, #0x1273dc0
    // 0x12731e8: ldur            x0, [fp, #-8]
    // 0x12731ec: r17 = 5069
    //     0x12731ec: mov             x17, #0x13cd
    // 0x12731f0: cmp             x0, x17
    // 0x12731f4: b.ne            #0x127320c
    // 0x12731f8: ldr             x1, [fp, #0x10]
    // 0x12731fc: LoadField: r2 = r1->field_3f
    //     0x12731fc: ldur            w2, [x1, #0x3f]
    // 0x1273200: DecompressPointer r2
    //     0x1273200: add             x2, x2, HEAP, lsl #32
    // 0x1273204: mov             x1, x2
    // 0x1273208: b               #0x12732e8
    // 0x127320c: ldr             x1, [fp, #0x10]
    // 0x1273210: r17 = 5070
    //     0x1273210: mov             x17, #0x13ce
    // 0x1273214: cmp             x0, x17
    // 0x1273218: b.ne            #0x127325c
    // 0x127321c: r1 = 1
    //     0x127321c: mov             x1, #1
    // 0x1273220: r0 = AllocateContext()
    //     0x1273220: bl              #0x13de838  ; AllocateContextStub
    // 0x1273224: ldr             x1, [fp, #0x10]
    // 0x1273228: stur            x0, [fp, #-0x18]
    // 0x127322c: StoreField: r0->field_f = r1
    //     0x127322c: stur            w1, [x0, #0xf]
    // 0x1273230: r0 = _WidgetStateColor()
    //     0x1273230: bl              #0xd29244  ; Allocate_WidgetStateColorStub -> _WidgetStateColor (size=0x30)
    // 0x1273234: ldur            x2, [fp, #-0x18]
    // 0x1273238: r1 = Function '<anonymous closure>':.
    //     0x1273238: add             x1, PP, #0x26, lsl #12  ; [pp+0x26a38] AnonymousClosure: (0xd3df80), of [package:flutter/src/material/slider.dart] _SliderDefaultsM3
    //     0x127323c: ldr             x1, [x1, #0xa38]
    // 0x1273240: stur            x0, [fp, #-0x18]
    // 0x1273244: r0 = AllocateClosure()
    //     0x1273244: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1273248: ldur            x1, [fp, #-0x18]
    // 0x127324c: mov             x2, x0
    // 0x1273250: r0 = _WidgetStateColor()
    //     0x1273250: bl              #0xd29128  ; [package:flutter/src/widgets/widget_state.dart] _WidgetStateColor::_WidgetStateColor
    // 0x1273254: ldur            x1, [fp, #-0x18]
    // 0x1273258: b               #0x12732e8
    // 0x127325c: r17 = 5071
    //     0x127325c: mov             x17, #0x13cf
    // 0x1273260: cmp             x0, x17
    // 0x1273264: b.ne            #0x12732ac
    // 0x1273268: ldr             x1, [fp, #0x10]
    // 0x127326c: r1 = 1
    //     0x127326c: mov             x1, #1
    // 0x1273270: r0 = AllocateContext()
    //     0x1273270: bl              #0x13de838  ; AllocateContextStub
    // 0x1273274: ldr             x1, [fp, #0x10]
    // 0x1273278: stur            x0, [fp, #-0x18]
    // 0x127327c: StoreField: r0->field_f = r1
    //     0x127327c: stur            w1, [x0, #0xf]
    // 0x1273280: r0 = _WidgetStateColor()
    //     0x1273280: bl              #0xd29244  ; Allocate_WidgetStateColorStub -> _WidgetStateColor (size=0x30)
    // 0x1273284: ldur            x2, [fp, #-0x18]
    // 0x1273288: r1 = Function '<anonymous closure>':.
    //     0x1273288: add             x1, PP, #0x26, lsl #12  ; [pp+0x26a40] AnonymousClosure: (0xd3ddc4), of [package:flutter/src/material/slider.dart] _SliderDefaultsM3Year2023
    //     0x127328c: ldr             x1, [x1, #0xa40]
    // 0x1273290: stur            x0, [fp, #-0x18]
    // 0x1273294: r0 = AllocateClosure()
    //     0x1273294: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1273298: ldur            x1, [fp, #-0x18]
    // 0x127329c: mov             x2, x0
    // 0x12732a0: r0 = _WidgetStateColor()
    //     0x12732a0: bl              #0xd29128  ; [package:flutter/src/widgets/widget_state.dart] _WidgetStateColor::_WidgetStateColor
    // 0x12732a4: ldur            x1, [fp, #-0x18]
    // 0x12732a8: b               #0x12732e8
    // 0x12732ac: ldr             x1, [fp, #0x10]
    // 0x12732b0: LoadField: r0 = r1->field_9b
    //     0x12732b0: ldur            w0, [x1, #0x9b]
    // 0x12732b4: DecompressPointer r0
    //     0x12732b4: add             x0, x0, HEAP, lsl #32
    // 0x12732b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12732bc: cmp             w0, w16
    // 0x12732c0: b.ne            #0x12732d0
    // 0x12732c4: r2 = _colors
    //     0x12732c4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x12732c8: ldr             x2, [x2, #0xa18]
    // 0x12732cc: r0 = InitLateFinalInstanceField()
    //     0x12732cc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12732d0: LoadField: r1 = r0->field_b
    //     0x12732d0: ldur            w1, [x0, #0xb]
    // 0x12732d4: DecompressPointer r1
    //     0x12732d4: add             x1, x1, HEAP, lsl #32
    // 0x12732d8: d0 = 0.120000
    //     0x12732d8: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x12732dc: ldr             d0, [x17, #0xc40]
    // 0x12732e0: r0 = withOpacity()
    //     0x12732e0: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x12732e4: mov             x1, x0
    // 0x12732e8: ldur            x0, [fp, #-0x10]
    // 0x12732ec: stur            x1, [fp, #-0x18]
    // 0x12732f0: r17 = 5069
    //     0x12732f0: mov             x17, #0x13cd
    // 0x12732f4: cmp             x0, x17
    // 0x12732f8: b.ne            #0x1273314
    // 0x12732fc: ldr             x2, [fp, #0x18]
    // 0x1273300: LoadField: r3 = r2->field_3f
    //     0x1273300: ldur            w3, [x2, #0x3f]
    // 0x1273304: DecompressPointer r3
    //     0x1273304: add             x3, x3, HEAP, lsl #32
    // 0x1273308: mov             x0, x1
    // 0x127330c: mov             x1, x3
    // 0x1273310: b               #0x12733fc
    // 0x1273314: ldr             x2, [fp, #0x18]
    // 0x1273318: r17 = 5070
    //     0x1273318: mov             x17, #0x13ce
    // 0x127331c: cmp             x0, x17
    // 0x1273320: b.ne            #0x1273368
    // 0x1273324: r1 = 1
    //     0x1273324: mov             x1, #1
    // 0x1273328: r0 = AllocateContext()
    //     0x1273328: bl              #0x13de838  ; AllocateContextStub
    // 0x127332c: ldr             x1, [fp, #0x18]
    // 0x1273330: stur            x0, [fp, #-0x20]
    // 0x1273334: StoreField: r0->field_f = r1
    //     0x1273334: stur            w1, [x0, #0xf]
    // 0x1273338: r0 = _WidgetStateColor()
    //     0x1273338: bl              #0xd29244  ; Allocate_WidgetStateColorStub -> _WidgetStateColor (size=0x30)
    // 0x127333c: ldur            x2, [fp, #-0x20]
    // 0x1273340: r1 = Function '<anonymous closure>':.
    //     0x1273340: add             x1, PP, #0x26, lsl #12  ; [pp+0x26a38] AnonymousClosure: (0xd3df80), of [package:flutter/src/material/slider.dart] _SliderDefaultsM3
    //     0x1273344: ldr             x1, [x1, #0xa38]
    // 0x1273348: stur            x0, [fp, #-0x20]
    // 0x127334c: r0 = AllocateClosure()
    //     0x127334c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1273350: ldur            x1, [fp, #-0x20]
    // 0x1273354: mov             x2, x0
    // 0x1273358: r0 = _WidgetStateColor()
    //     0x1273358: bl              #0xd29128  ; [package:flutter/src/widgets/widget_state.dart] _WidgetStateColor::_WidgetStateColor
    // 0x127335c: ldur            x1, [fp, #-0x20]
    // 0x1273360: ldur            x0, [fp, #-0x18]
    // 0x1273364: b               #0x12733fc
    // 0x1273368: r17 = 5071
    //     0x1273368: mov             x17, #0x13cf
    // 0x127336c: cmp             x0, x17
    // 0x1273370: b.ne            #0x12733bc
    // 0x1273374: ldr             x1, [fp, #0x18]
    // 0x1273378: r1 = 1
    //     0x1273378: mov             x1, #1
    // 0x127337c: r0 = AllocateContext()
    //     0x127337c: bl              #0x13de838  ; AllocateContextStub
    // 0x1273380: ldr             x1, [fp, #0x18]
    // 0x1273384: stur            x0, [fp, #-0x20]
    // 0x1273388: StoreField: r0->field_f = r1
    //     0x1273388: stur            w1, [x0, #0xf]
    // 0x127338c: r0 = _WidgetStateColor()
    //     0x127338c: bl              #0xd29244  ; Allocate_WidgetStateColorStub -> _WidgetStateColor (size=0x30)
    // 0x1273390: ldur            x2, [fp, #-0x20]
    // 0x1273394: r1 = Function '<anonymous closure>':.
    //     0x1273394: add             x1, PP, #0x26, lsl #12  ; [pp+0x26a40] AnonymousClosure: (0xd3ddc4), of [package:flutter/src/material/slider.dart] _SliderDefaultsM3Year2023
    //     0x1273398: ldr             x1, [x1, #0xa40]
    // 0x127339c: stur            x0, [fp, #-0x20]
    // 0x12733a0: r0 = AllocateClosure()
    //     0x12733a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12733a4: ldur            x1, [fp, #-0x20]
    // 0x12733a8: mov             x2, x0
    // 0x12733ac: r0 = _WidgetStateColor()
    //     0x12733ac: bl              #0xd29128  ; [package:flutter/src/widgets/widget_state.dart] _WidgetStateColor::_WidgetStateColor
    // 0x12733b0: ldur            x1, [fp, #-0x20]
    // 0x12733b4: ldur            x0, [fp, #-0x18]
    // 0x12733b8: b               #0x12733fc
    // 0x12733bc: ldr             x1, [fp, #0x18]
    // 0x12733c0: LoadField: r0 = r1->field_9b
    //     0x12733c0: ldur            w0, [x1, #0x9b]
    // 0x12733c4: DecompressPointer r0
    //     0x12733c4: add             x0, x0, HEAP, lsl #32
    // 0x12733c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12733cc: cmp             w0, w16
    // 0x12733d0: b.ne            #0x12733e0
    // 0x12733d4: r2 = _colors
    //     0x12733d4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x12733d8: ldr             x2, [x2, #0xa18]
    // 0x12733dc: r0 = InitLateFinalInstanceField()
    //     0x12733dc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12733e0: LoadField: r1 = r0->field_b
    //     0x12733e0: ldur            w1, [x0, #0xb]
    // 0x12733e4: DecompressPointer r1
    //     0x12733e4: add             x1, x1, HEAP, lsl #32
    // 0x12733e8: d0 = 0.120000
    //     0x12733e8: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x12733ec: ldr             d0, [x17, #0xc40]
    // 0x12733f0: r0 = withOpacity()
    //     0x12733f0: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x12733f4: mov             x1, x0
    // 0x12733f8: ldur            x0, [fp, #-0x18]
    // 0x12733fc: r2 = LoadClassIdInstr(r0)
    //     0x12733fc: ldur            x2, [x0, #-1]
    //     0x1273400: ubfx            x2, x2, #0xc, #0x14
    // 0x1273404: stp             x1, x0, [SP]
    // 0x1273408: mov             x0, x2
    // 0x127340c: mov             lr, x0
    // 0x1273410: ldr             lr, [x21, lr, lsl #3]
    // 0x1273414: blr             lr
    // 0x1273418: tbnz            w0, #4, #0x1273dc0
    // 0x127341c: ldur            x0, [fp, #-8]
    // 0x1273420: r17 = 5069
    //     0x1273420: mov             x17, #0x13cd
    // 0x1273424: cmp             x0, x17
    // 0x1273428: b.ne            #0x1273440
    // 0x127342c: ldr             x2, [fp, #0x10]
    // 0x1273430: LoadField: r1 = r2->field_43
    //     0x1273430: ldur            w1, [x2, #0x43]
    // 0x1273434: DecompressPointer r1
    //     0x1273434: add             x1, x1, HEAP, lsl #32
    // 0x1273438: mov             x2, x1
    // 0x127343c: b               #0x12734e4
    // 0x1273440: ldr             x2, [fp, #0x10]
    // 0x1273444: r17 = 5070
    //     0x1273444: mov             x17, #0x13ce
    // 0x1273448: cmp             x0, x17
    // 0x127344c: b.eq            #0x127427c
    // 0x1273450: r17 = 5071
    //     0x1273450: mov             x17, #0x13cf
    // 0x1273454: cmp             x0, x17
    // 0x1273458: b.ne            #0x1273490
    // 0x127345c: mov             x1, x2
    // 0x1273460: LoadField: r0 = r1->field_9b
    //     0x1273460: ldur            w0, [x1, #0x9b]
    // 0x1273464: DecompressPointer r0
    //     0x1273464: add             x0, x0, HEAP, lsl #32
    // 0x1273468: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x127346c: cmp             w0, w16
    // 0x1273470: b.ne            #0x1273480
    // 0x1273474: r2 = _colors
    //     0x1273474: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1273478: ldr             x2, [x2, #0xa10]
    // 0x127347c: r0 = InitLateFinalInstanceField()
    //     0x127347c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1273480: LoadField: r1 = r0->field_b
    //     0x1273480: ldur            w1, [x0, #0xb]
    // 0x1273484: DecompressPointer r1
    //     0x1273484: add             x1, x1, HEAP, lsl #32
    // 0x1273488: mov             x2, x1
    // 0x127348c: b               #0x12734e4
    // 0x1273490: ldr             x1, [fp, #0x10]
    // 0x1273494: LoadField: r0 = r1->field_9f
    //     0x1273494: ldur            w0, [x1, #0x9f]
    // 0x1273498: DecompressPointer r0
    //     0x1273498: add             x0, x0, HEAP, lsl #32
    // 0x127349c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12734a0: cmp             w0, w16
    // 0x12734a4: b.ne            #0x12734b4
    // 0x12734a8: r2 = sliderTheme
    //     0x12734a8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a48] Field <_SliderDefaultsM2@125231897.sliderTheme>: late final (offset: 0xa0)
    //     0x12734ac: ldr             x2, [x2, #0xa48]
    // 0x12734b0: r0 = InitLateFinalInstanceField()
    //     0x12734b0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12734b4: ldr             x1, [fp, #0x10]
    // 0x12734b8: LoadField: r0 = r1->field_9b
    //     0x12734b8: ldur            w0, [x1, #0x9b]
    // 0x12734bc: DecompressPointer r0
    //     0x12734bc: add             x0, x0, HEAP, lsl #32
    // 0x12734c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12734c4: cmp             w0, w16
    // 0x12734c8: b.ne            #0x12734d8
    // 0x12734cc: r2 = _colors
    //     0x12734cc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x12734d0: ldr             x2, [x2, #0xa18]
    // 0x12734d4: r0 = InitLateFinalInstanceField()
    //     0x12734d4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12734d8: LoadField: r1 = r0->field_b
    //     0x12734d8: ldur            w1, [x0, #0xb]
    // 0x12734dc: DecompressPointer r1
    //     0x12734dc: add             x1, x1, HEAP, lsl #32
    // 0x12734e0: mov             x2, x1
    // 0x12734e4: ldur            x0, [fp, #-0x10]
    // 0x12734e8: stur            x2, [fp, #-0x18]
    // 0x12734ec: r17 = 5069
    //     0x12734ec: mov             x17, #0x13cd
    // 0x12734f0: cmp             x0, x17
    // 0x12734f4: b.ne            #0x127350c
    // 0x12734f8: ldr             x3, [fp, #0x18]
    // 0x12734fc: LoadField: r1 = r3->field_43
    //     0x12734fc: ldur            w1, [x3, #0x43]
    // 0x1273500: DecompressPointer r1
    //     0x1273500: add             x1, x1, HEAP, lsl #32
    // 0x1273504: mov             x0, x2
    // 0x1273508: b               #0x12735b0
    // 0x127350c: ldr             x3, [fp, #0x18]
    // 0x1273510: r17 = 5070
    //     0x1273510: mov             x17, #0x13ce
    // 0x1273514: cmp             x0, x17
    // 0x1273518: b.eq            #0x12742ac
    // 0x127351c: r17 = 5071
    //     0x127351c: mov             x17, #0x13cf
    // 0x1273520: cmp             x0, x17
    // 0x1273524: b.ne            #0x127355c
    // 0x1273528: mov             x1, x3
    // 0x127352c: LoadField: r0 = r1->field_9b
    //     0x127352c: ldur            w0, [x1, #0x9b]
    // 0x1273530: DecompressPointer r0
    //     0x1273530: add             x0, x0, HEAP, lsl #32
    // 0x1273534: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1273538: cmp             w0, w16
    // 0x127353c: b.ne            #0x127354c
    // 0x1273540: r2 = _colors
    //     0x1273540: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1273544: ldr             x2, [x2, #0xa10]
    // 0x1273548: r0 = InitLateFinalInstanceField()
    //     0x1273548: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x127354c: LoadField: r1 = r0->field_b
    //     0x127354c: ldur            w1, [x0, #0xb]
    // 0x1273550: DecompressPointer r1
    //     0x1273550: add             x1, x1, HEAP, lsl #32
    // 0x1273554: ldur            x0, [fp, #-0x18]
    // 0x1273558: b               #0x12735b0
    // 0x127355c: ldr             x1, [fp, #0x18]
    // 0x1273560: LoadField: r0 = r1->field_9f
    //     0x1273560: ldur            w0, [x1, #0x9f]
    // 0x1273564: DecompressPointer r0
    //     0x1273564: add             x0, x0, HEAP, lsl #32
    // 0x1273568: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x127356c: cmp             w0, w16
    // 0x1273570: b.ne            #0x1273580
    // 0x1273574: r2 = sliderTheme
    //     0x1273574: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a48] Field <_SliderDefaultsM2@125231897.sliderTheme>: late final (offset: 0xa0)
    //     0x1273578: ldr             x2, [x2, #0xa48]
    // 0x127357c: r0 = InitLateFinalInstanceField()
    //     0x127357c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1273580: ldr             x1, [fp, #0x18]
    // 0x1273584: LoadField: r0 = r1->field_9b
    //     0x1273584: ldur            w0, [x1, #0x9b]
    // 0x1273588: DecompressPointer r0
    //     0x1273588: add             x0, x0, HEAP, lsl #32
    // 0x127358c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1273590: cmp             w0, w16
    // 0x1273594: b.ne            #0x12735a4
    // 0x1273598: r2 = _colors
    //     0x1273598: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x127359c: ldr             x2, [x2, #0xa18]
    // 0x12735a0: r0 = InitLateFinalInstanceField()
    //     0x12735a0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12735a4: LoadField: r1 = r0->field_b
    //     0x12735a4: ldur            w1, [x0, #0xb]
    // 0x12735a8: DecompressPointer r1
    //     0x12735a8: add             x1, x1, HEAP, lsl #32
    // 0x12735ac: ldur            x0, [fp, #-0x18]
    // 0x12735b0: r2 = LoadClassIdInstr(r0)
    //     0x12735b0: ldur            x2, [x0, #-1]
    //     0x12735b4: ubfx            x2, x2, #0xc, #0x14
    // 0x12735b8: stp             x1, x0, [SP]
    // 0x12735bc: mov             x0, x2
    // 0x12735c0: mov             lr, x0
    // 0x12735c4: ldr             lr, [x21, lr, lsl #3]
    // 0x12735c8: blr             lr
    // 0x12735cc: tbnz            w0, #4, #0x1273dc0
    // 0x12735d0: ldur            x1, [fp, #-8]
    // 0x12735d4: r17 = 5069
    //     0x12735d4: mov             x17, #0x13cd
    // 0x12735d8: cmp             x1, x17
    // 0x12735dc: b.ne            #0x12735f0
    // 0x12735e0: ldr             x2, [fp, #0x10]
    // 0x12735e4: LoadField: r0 = r2->field_4b
    //     0x12735e4: ldur            w0, [x2, #0x4b]
    // 0x12735e8: DecompressPointer r0
    //     0x12735e8: add             x0, x0, HEAP, lsl #32
    // 0x12735ec: b               #0x127362c
    // 0x12735f0: ldr             x2, [fp, #0x10]
    // 0x12735f4: r17 = 5070
    //     0x12735f4: mov             x17, #0x13ce
    // 0x12735f8: cmp             x1, x17
    // 0x12735fc: b.ne            #0x127360c
    // 0x1273600: r0 = Instance_RoundSliderOverlayShape
    //     0x1273600: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a50] Obj!RoundSliderOverlayShape@129e8a1
    //     0x1273604: ldr             x0, [x0, #0xa50]
    // 0x1273608: b               #0x127362c
    // 0x127360c: r17 = 5071
    //     0x127360c: mov             x17, #0x13cf
    // 0x1273610: cmp             x1, x17
    // 0x1273614: b.ne            #0x1273624
    // 0x1273618: r0 = Instance_RoundSliderOverlayShape
    //     0x1273618: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a50] Obj!RoundSliderOverlayShape@129e8a1
    //     0x127361c: ldr             x0, [x0, #0xa50]
    // 0x1273620: b               #0x127362c
    // 0x1273624: r0 = Instance_RoundSliderOverlayShape
    //     0x1273624: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a50] Obj!RoundSliderOverlayShape@129e8a1
    //     0x1273628: ldr             x0, [x0, #0xa50]
    // 0x127362c: ldur            x3, [fp, #-0x10]
    // 0x1273630: r17 = 5069
    //     0x1273630: mov             x17, #0x13cd
    // 0x1273634: cmp             x3, x17
    // 0x1273638: b.ne            #0x127364c
    // 0x127363c: ldr             x4, [fp, #0x18]
    // 0x1273640: LoadField: r5 = r4->field_4b
    //     0x1273640: ldur            w5, [x4, #0x4b]
    // 0x1273644: DecompressPointer r5
    //     0x1273644: add             x5, x5, HEAP, lsl #32
    // 0x1273648: b               #0x1273688
    // 0x127364c: ldr             x4, [fp, #0x18]
    // 0x1273650: r17 = 5070
    //     0x1273650: mov             x17, #0x13ce
    // 0x1273654: cmp             x3, x17
    // 0x1273658: b.ne            #0x1273668
    // 0x127365c: r5 = Instance_RoundSliderOverlayShape
    //     0x127365c: add             x5, PP, #0x26, lsl #12  ; [pp+0x26a50] Obj!RoundSliderOverlayShape@129e8a1
    //     0x1273660: ldr             x5, [x5, #0xa50]
    // 0x1273664: b               #0x1273688
    // 0x1273668: r17 = 5071
    //     0x1273668: mov             x17, #0x13cf
    // 0x127366c: cmp             x3, x17
    // 0x1273670: b.ne            #0x1273680
    // 0x1273674: r5 = Instance_RoundSliderOverlayShape
    //     0x1273674: add             x5, PP, #0x26, lsl #12  ; [pp+0x26a50] Obj!RoundSliderOverlayShape@129e8a1
    //     0x1273678: ldr             x5, [x5, #0xa50]
    // 0x127367c: b               #0x1273688
    // 0x1273680: r5 = Instance_RoundSliderOverlayShape
    //     0x1273680: add             x5, PP, #0x26, lsl #12  ; [pp+0x26a50] Obj!RoundSliderOverlayShape@129e8a1
    //     0x1273684: ldr             x5, [x5, #0xa50]
    // 0x1273688: cmp             w0, w5
    // 0x127368c: b.ne            #0x1273dc0
    // 0x1273690: r17 = 5069
    //     0x1273690: mov             x17, #0x13cd
    // 0x1273694: cmp             x1, x17
    // 0x1273698: b.ne            #0x12736a8
    // 0x127369c: LoadField: r0 = r2->field_4f
    //     0x127369c: ldur            w0, [x2, #0x4f]
    // 0x12736a0: DecompressPointer r0
    //     0x12736a0: add             x0, x0, HEAP, lsl #32
    // 0x12736a4: b               #0x12736e0
    // 0x12736a8: r17 = 5070
    //     0x12736a8: mov             x17, #0x13ce
    // 0x12736ac: cmp             x1, x17
    // 0x12736b0: b.ne            #0x12736c0
    // 0x12736b4: r0 = Instance_RoundSliderTickMarkShape
    //     0x12736b4: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a58] Obj!RoundSliderTickMarkShape@129e921
    //     0x12736b8: ldr             x0, [x0, #0xa58]
    // 0x12736bc: b               #0x12736e0
    // 0x12736c0: r17 = 5071
    //     0x12736c0: mov             x17, #0x13cf
    // 0x12736c4: cmp             x1, x17
    // 0x12736c8: b.ne            #0x12736d8
    // 0x12736cc: r0 = Instance_RoundSliderTickMarkShape
    //     0x12736cc: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a60] Obj!RoundSliderTickMarkShape@129e911
    //     0x12736d0: ldr             x0, [x0, #0xa60]
    // 0x12736d4: b               #0x12736e0
    // 0x12736d8: r0 = Instance_RoundSliderTickMarkShape
    //     0x12736d8: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a60] Obj!RoundSliderTickMarkShape@129e911
    //     0x12736dc: ldr             x0, [x0, #0xa60]
    // 0x12736e0: r17 = 5069
    //     0x12736e0: mov             x17, #0x13cd
    // 0x12736e4: cmp             x3, x17
    // 0x12736e8: b.ne            #0x12736f8
    // 0x12736ec: LoadField: r5 = r4->field_4f
    //     0x12736ec: ldur            w5, [x4, #0x4f]
    // 0x12736f0: DecompressPointer r5
    //     0x12736f0: add             x5, x5, HEAP, lsl #32
    // 0x12736f4: b               #0x1273730
    // 0x12736f8: r17 = 5070
    //     0x12736f8: mov             x17, #0x13ce
    // 0x12736fc: cmp             x3, x17
    // 0x1273700: b.ne            #0x1273710
    // 0x1273704: r5 = Instance_RoundSliderTickMarkShape
    //     0x1273704: add             x5, PP, #0x26, lsl #12  ; [pp+0x26a58] Obj!RoundSliderTickMarkShape@129e921
    //     0x1273708: ldr             x5, [x5, #0xa58]
    // 0x127370c: b               #0x1273730
    // 0x1273710: r17 = 5071
    //     0x1273710: mov             x17, #0x13cf
    // 0x1273714: cmp             x3, x17
    // 0x1273718: b.ne            #0x1273728
    // 0x127371c: r5 = Instance_RoundSliderTickMarkShape
    //     0x127371c: add             x5, PP, #0x26, lsl #12  ; [pp+0x26a60] Obj!RoundSliderTickMarkShape@129e911
    //     0x1273720: ldr             x5, [x5, #0xa60]
    // 0x1273724: b               #0x1273730
    // 0x1273728: r5 = Instance_RoundSliderTickMarkShape
    //     0x1273728: add             x5, PP, #0x26, lsl #12  ; [pp+0x26a60] Obj!RoundSliderTickMarkShape@129e911
    //     0x127372c: ldr             x5, [x5, #0xa60]
    // 0x1273730: cmp             w0, w5
    // 0x1273734: b.ne            #0x1273dc0
    // 0x1273738: r17 = 5069
    //     0x1273738: mov             x17, #0x13cd
    // 0x127373c: cmp             x1, x17
    // 0x1273740: b.ne            #0x1273750
    // 0x1273744: LoadField: r0 = r2->field_53
    //     0x1273744: ldur            w0, [x2, #0x53]
    // 0x1273748: DecompressPointer r0
    //     0x1273748: add             x0, x0, HEAP, lsl #32
    // 0x127374c: b               #0x1273788
    // 0x1273750: r17 = 5070
    //     0x1273750: mov             x17, #0x13ce
    // 0x1273754: cmp             x1, x17
    // 0x1273758: b.ne            #0x1273768
    // 0x127375c: r0 = Instance_HandleThumbShape
    //     0x127375c: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a68] Obj!HandleThumbShape@129e8c1
    //     0x1273760: ldr             x0, [x0, #0xa68]
    // 0x1273764: b               #0x1273788
    // 0x1273768: r17 = 5071
    //     0x1273768: mov             x17, #0x13cf
    // 0x127376c: cmp             x1, x17
    // 0x1273770: b.ne            #0x1273780
    // 0x1273774: r0 = Instance_RoundSliderThumbShape
    //     0x1273774: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a70] Obj!RoundSliderThumbShape@129e8e1
    //     0x1273778: ldr             x0, [x0, #0xa70]
    // 0x127377c: b               #0x1273788
    // 0x1273780: r0 = Instance_RoundSliderThumbShape
    //     0x1273780: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a70] Obj!RoundSliderThumbShape@129e8e1
    //     0x1273784: ldr             x0, [x0, #0xa70]
    // 0x1273788: r17 = 5069
    //     0x1273788: mov             x17, #0x13cd
    // 0x127378c: cmp             x3, x17
    // 0x1273790: b.ne            #0x12737a0
    // 0x1273794: LoadField: r5 = r4->field_53
    //     0x1273794: ldur            w5, [x4, #0x53]
    // 0x1273798: DecompressPointer r5
    //     0x1273798: add             x5, x5, HEAP, lsl #32
    // 0x127379c: b               #0x12737d8
    // 0x12737a0: r17 = 5070
    //     0x12737a0: mov             x17, #0x13ce
    // 0x12737a4: cmp             x3, x17
    // 0x12737a8: b.ne            #0x12737b8
    // 0x12737ac: r5 = Instance_HandleThumbShape
    //     0x12737ac: add             x5, PP, #0x26, lsl #12  ; [pp+0x26a68] Obj!HandleThumbShape@129e8c1
    //     0x12737b0: ldr             x5, [x5, #0xa68]
    // 0x12737b4: b               #0x12737d8
    // 0x12737b8: r17 = 5071
    //     0x12737b8: mov             x17, #0x13cf
    // 0x12737bc: cmp             x3, x17
    // 0x12737c0: b.ne            #0x12737d0
    // 0x12737c4: r5 = Instance_RoundSliderThumbShape
    //     0x12737c4: add             x5, PP, #0x26, lsl #12  ; [pp+0x26a70] Obj!RoundSliderThumbShape@129e8e1
    //     0x12737c8: ldr             x5, [x5, #0xa70]
    // 0x12737cc: b               #0x12737d8
    // 0x12737d0: r5 = Instance_RoundSliderThumbShape
    //     0x12737d0: add             x5, PP, #0x26, lsl #12  ; [pp+0x26a70] Obj!RoundSliderThumbShape@129e8e1
    //     0x12737d4: ldr             x5, [x5, #0xa70]
    // 0x12737d8: r6 = LoadClassIdInstr(r0)
    //     0x12737d8: ldur            x6, [x0, #-1]
    //     0x12737dc: ubfx            x6, x6, #0xc, #0x14
    // 0x12737e0: stp             x5, x0, [SP]
    // 0x12737e4: mov             x0, x6
    // 0x12737e8: mov             lr, x0
    // 0x12737ec: ldr             lr, [x21, lr, lsl #3]
    // 0x12737f0: blr             lr
    // 0x12737f4: tbnz            w0, #4, #0x1273dc0
    // 0x12737f8: ldur            x1, [fp, #-8]
    // 0x12737fc: r17 = 5069
    //     0x12737fc: mov             x17, #0x13cd
    // 0x1273800: cmp             x1, x17
    // 0x1273804: b.ne            #0x1273818
    // 0x1273808: ldr             x2, [fp, #0x10]
    // 0x127380c: LoadField: r0 = r2->field_57
    //     0x127380c: ldur            w0, [x2, #0x57]
    // 0x1273810: DecompressPointer r0
    //     0x1273810: add             x0, x0, HEAP, lsl #32
    // 0x1273814: b               #0x1273854
    // 0x1273818: ldr             x2, [fp, #0x10]
    // 0x127381c: r17 = 5070
    //     0x127381c: mov             x17, #0x13ce
    // 0x1273820: cmp             x1, x17
    // 0x1273824: b.ne            #0x1273834
    // 0x1273828: r0 = Instance_GappedSliderTrackShape
    //     0x1273828: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a78] Obj!GappedSliderTrackShape@12aa531
    //     0x127382c: ldr             x0, [x0, #0xa78]
    // 0x1273830: b               #0x1273854
    // 0x1273834: r17 = 5071
    //     0x1273834: mov             x17, #0x13cf
    // 0x1273838: cmp             x1, x17
    // 0x127383c: b.ne            #0x127384c
    // 0x1273840: r0 = Instance_RoundedRectSliderTrackShape
    //     0x1273840: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a80] Obj!RoundedRectSliderTrackShape@12aa541
    //     0x1273844: ldr             x0, [x0, #0xa80]
    // 0x1273848: b               #0x1273854
    // 0x127384c: r0 = Instance_RoundedRectSliderTrackShape
    //     0x127384c: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a80] Obj!RoundedRectSliderTrackShape@12aa541
    //     0x1273850: ldr             x0, [x0, #0xa80]
    // 0x1273854: ldur            x3, [fp, #-0x10]
    // 0x1273858: r17 = 5069
    //     0x1273858: mov             x17, #0x13cd
    // 0x127385c: cmp             x3, x17
    // 0x1273860: b.ne            #0x1273874
    // 0x1273864: ldr             x4, [fp, #0x18]
    // 0x1273868: LoadField: r5 = r4->field_57
    //     0x1273868: ldur            w5, [x4, #0x57]
    // 0x127386c: DecompressPointer r5
    //     0x127386c: add             x5, x5, HEAP, lsl #32
    // 0x1273870: b               #0x12738b0
    // 0x1273874: ldr             x4, [fp, #0x18]
    // 0x1273878: r17 = 5070
    //     0x1273878: mov             x17, #0x13ce
    // 0x127387c: cmp             x3, x17
    // 0x1273880: b.ne            #0x1273890
    // 0x1273884: r5 = Instance_GappedSliderTrackShape
    //     0x1273884: add             x5, PP, #0x26, lsl #12  ; [pp+0x26a78] Obj!GappedSliderTrackShape@12aa531
    //     0x1273888: ldr             x5, [x5, #0xa78]
    // 0x127388c: b               #0x12738b0
    // 0x1273890: r17 = 5071
    //     0x1273890: mov             x17, #0x13cf
    // 0x1273894: cmp             x3, x17
    // 0x1273898: b.ne            #0x12738a8
    // 0x127389c: r5 = Instance_RoundedRectSliderTrackShape
    //     0x127389c: add             x5, PP, #0x26, lsl #12  ; [pp+0x26a80] Obj!RoundedRectSliderTrackShape@12aa541
    //     0x12738a0: ldr             x5, [x5, #0xa80]
    // 0x12738a4: b               #0x12738b0
    // 0x12738a8: r5 = Instance_RoundedRectSliderTrackShape
    //     0x12738a8: add             x5, PP, #0x26, lsl #12  ; [pp+0x26a80] Obj!RoundedRectSliderTrackShape@12aa541
    //     0x12738ac: ldr             x5, [x5, #0xa80]
    // 0x12738b0: r6 = LoadClassIdInstr(r0)
    //     0x12738b0: ldur            x6, [x0, #-1]
    //     0x12738b4: ubfx            x6, x6, #0xc, #0x14
    // 0x12738b8: stp             x5, x0, [SP]
    // 0x12738bc: mov             x0, x6
    // 0x12738c0: mov             lr, x0
    // 0x12738c4: ldr             lr, [x21, lr, lsl #3]
    // 0x12738c8: blr             lr
    // 0x12738cc: tbnz            w0, #4, #0x1273dc0
    // 0x12738d0: ldur            x1, [fp, #-8]
    // 0x12738d4: r17 = 5069
    //     0x12738d4: mov             x17, #0x13cd
    // 0x12738d8: cmp             x1, x17
    // 0x12738dc: b.ne            #0x12738f0
    // 0x12738e0: ldr             x2, [fp, #0x10]
    // 0x12738e4: LoadField: r0 = r2->field_5b
    //     0x12738e4: ldur            w0, [x2, #0x5b]
    // 0x12738e8: DecompressPointer r0
    //     0x12738e8: add             x0, x0, HEAP, lsl #32
    // 0x12738ec: b               #0x127392c
    // 0x12738f0: ldr             x2, [fp, #0x10]
    // 0x12738f4: r17 = 5070
    //     0x12738f4: mov             x17, #0x13ce
    // 0x12738f8: cmp             x1, x17
    // 0x12738fc: b.ne            #0x127390c
    // 0x1273900: r0 = Instance_RoundedRectSliderValueIndicatorShape
    //     0x1273900: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a88] Obj!RoundedRectSliderValueIndicatorShape@129e8b1
    //     0x1273904: ldr             x0, [x0, #0xa88]
    // 0x1273908: b               #0x127392c
    // 0x127390c: r17 = 5071
    //     0x127390c: mov             x17, #0x13cf
    // 0x1273910: cmp             x1, x17
    // 0x1273914: b.ne            #0x1273924
    // 0x1273918: r0 = Instance_DropSliderValueIndicatorShape
    //     0x1273918: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a90] Obj!DropSliderValueIndicatorShape@129e8d1
    //     0x127391c: ldr             x0, [x0, #0xa90]
    // 0x1273920: b               #0x127392c
    // 0x1273924: r0 = Instance_RectangularSliderValueIndicatorShape
    //     0x1273924: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a98] Obj!RectangularSliderValueIndicatorShape@129e891
    //     0x1273928: ldr             x0, [x0, #0xa98]
    // 0x127392c: ldur            x3, [fp, #-0x10]
    // 0x1273930: r17 = 5069
    //     0x1273930: mov             x17, #0x13cd
    // 0x1273934: cmp             x3, x17
    // 0x1273938: b.ne            #0x127394c
    // 0x127393c: ldr             x4, [fp, #0x18]
    // 0x1273940: LoadField: r5 = r4->field_5b
    //     0x1273940: ldur            w5, [x4, #0x5b]
    // 0x1273944: DecompressPointer r5
    //     0x1273944: add             x5, x5, HEAP, lsl #32
    // 0x1273948: b               #0x1273988
    // 0x127394c: ldr             x4, [fp, #0x18]
    // 0x1273950: r17 = 5070
    //     0x1273950: mov             x17, #0x13ce
    // 0x1273954: cmp             x3, x17
    // 0x1273958: b.ne            #0x1273968
    // 0x127395c: r5 = Instance_RoundedRectSliderValueIndicatorShape
    //     0x127395c: add             x5, PP, #0x26, lsl #12  ; [pp+0x26a88] Obj!RoundedRectSliderValueIndicatorShape@129e8b1
    //     0x1273960: ldr             x5, [x5, #0xa88]
    // 0x1273964: b               #0x1273988
    // 0x1273968: r17 = 5071
    //     0x1273968: mov             x17, #0x13cf
    // 0x127396c: cmp             x3, x17
    // 0x1273970: b.ne            #0x1273980
    // 0x1273974: r5 = Instance_DropSliderValueIndicatorShape
    //     0x1273974: add             x5, PP, #0x26, lsl #12  ; [pp+0x26a90] Obj!DropSliderValueIndicatorShape@129e8d1
    //     0x1273978: ldr             x5, [x5, #0xa90]
    // 0x127397c: b               #0x1273988
    // 0x1273980: r5 = Instance_RectangularSliderValueIndicatorShape
    //     0x1273980: add             x5, PP, #0x26, lsl #12  ; [pp+0x26a98] Obj!RectangularSliderValueIndicatorShape@129e891
    //     0x1273984: ldr             x5, [x5, #0xa98]
    // 0x1273988: r6 = LoadClassIdInstr(r0)
    //     0x1273988: ldur            x6, [x0, #-1]
    //     0x127398c: ubfx            x6, x6, #0xc, #0x14
    // 0x1273990: stp             x5, x0, [SP]
    // 0x1273994: mov             x0, x6
    // 0x1273998: mov             lr, x0
    // 0x127399c: ldr             lr, [x21, lr, lsl #3]
    // 0x12739a0: blr             lr
    // 0x12739a4: tbnz            w0, #4, #0x1273dc0
    // 0x12739a8: ldr             x2, [fp, #0x18]
    // 0x12739ac: ldr             x0, [fp, #0x10]
    // 0x12739b0: LoadField: r1 = r0->field_6f
    //     0x12739b0: ldur            w1, [x0, #0x6f]
    // 0x12739b4: DecompressPointer r1
    //     0x12739b4: add             x1, x1, HEAP, lsl #32
    // 0x12739b8: LoadField: r3 = r2->field_6f
    //     0x12739b8: ldur            w3, [x2, #0x6f]
    // 0x12739bc: DecompressPointer r3
    //     0x12739bc: add             x3, x3, HEAP, lsl #32
    // 0x12739c0: cmp             w1, w3
    // 0x12739c4: b.ne            #0x1273dc0
    // 0x12739c8: ldur            x3, [fp, #-8]
    // 0x12739cc: r17 = 5069
    //     0x12739cc: mov             x17, #0x13cd
    // 0x12739d0: cmp             x3, x17
    // 0x12739d4: b.ne            #0x12739e8
    // 0x12739d8: LoadField: r1 = r0->field_73
    //     0x12739d8: ldur            w1, [x0, #0x73]
    // 0x12739dc: DecompressPointer r1
    //     0x12739dc: add             x1, x1, HEAP, lsl #32
    // 0x12739e0: mov             x2, x1
    // 0x12739e4: b               #0x1273ad4
    // 0x12739e8: r17 = 5070
    //     0x12739e8: mov             x17, #0x13ce
    // 0x12739ec: cmp             x3, x17
    // 0x12739f0: b.eq            #0x12742e0
    // 0x12739f4: r17 = 5071
    //     0x12739f4: mov             x17, #0x13cf
    // 0x12739f8: cmp             x3, x17
    // 0x12739fc: b.ne            #0x1273a70
    // 0x1273a00: LoadField: r1 = r0->field_97
    //     0x1273a00: ldur            w1, [x0, #0x97]
    // 0x1273a04: DecompressPointer r1
    //     0x1273a04: add             x1, x1, HEAP, lsl #32
    // 0x1273a08: r0 = of()
    //     0x1273a08: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1273a0c: LoadField: r1 = r0->field_87
    //     0x1273a0c: ldur            w1, [x0, #0x87]
    // 0x1273a10: DecompressPointer r1
    //     0x1273a10: add             x1, x1, HEAP, lsl #32
    // 0x1273a14: LoadField: r0 = r1->field_3b
    //     0x1273a14: ldur            w0, [x1, #0x3b]
    // 0x1273a18: DecompressPointer r0
    //     0x1273a18: add             x0, x0, HEAP, lsl #32
    // 0x1273a1c: stur            x0, [fp, #-0x18]
    // 0x1273a20: cmp             w0, NULL
    // 0x1273a24: b.eq            #0x1274300
    // 0x1273a28: ldr             x1, [fp, #0x10]
    // 0x1273a2c: LoadField: r0 = r1->field_9b
    //     0x1273a2c: ldur            w0, [x1, #0x9b]
    // 0x1273a30: DecompressPointer r0
    //     0x1273a30: add             x0, x0, HEAP, lsl #32
    // 0x1273a34: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1273a38: cmp             w0, w16
    // 0x1273a3c: b.ne            #0x1273a4c
    // 0x1273a40: r2 = _colors
    //     0x1273a40: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1273a44: ldr             x2, [x2, #0xa10]
    // 0x1273a48: r0 = InitLateFinalInstanceField()
    //     0x1273a48: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1273a4c: LoadField: r1 = r0->field_f
    //     0x1273a4c: ldur            w1, [x0, #0xf]
    // 0x1273a50: DecompressPointer r1
    //     0x1273a50: add             x1, x1, HEAP, lsl #32
    // 0x1273a54: str             x1, [SP]
    // 0x1273a58: ldur            x1, [fp, #-0x18]
    // 0x1273a5c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x1273a5c: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x1273a60: ldr             x4, [x4, #0x7f0]
    // 0x1273a64: r0 = copyWith()
    //     0x1273a64: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x1273a68: mov             x2, x0
    // 0x1273a6c: b               #0x1273ad4
    // 0x1273a70: LoadField: r1 = r0->field_97
    //     0x1273a70: ldur            w1, [x0, #0x97]
    // 0x1273a74: DecompressPointer r1
    //     0x1273a74: add             x1, x1, HEAP, lsl #32
    // 0x1273a78: r0 = of()
    //     0x1273a78: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1273a7c: LoadField: r1 = r0->field_87
    //     0x1273a7c: ldur            w1, [x0, #0x87]
    // 0x1273a80: DecompressPointer r1
    //     0x1273a80: add             x1, x1, HEAP, lsl #32
    // 0x1273a84: LoadField: r0 = r1->field_2b
    //     0x1273a84: ldur            w0, [x1, #0x2b]
    // 0x1273a88: DecompressPointer r0
    //     0x1273a88: add             x0, x0, HEAP, lsl #32
    // 0x1273a8c: ldr             x1, [fp, #0x10]
    // 0x1273a90: stur            x0, [fp, #-0x18]
    // 0x1273a94: LoadField: r0 = r1->field_9b
    //     0x1273a94: ldur            w0, [x1, #0x9b]
    // 0x1273a98: DecompressPointer r0
    //     0x1273a98: add             x0, x0, HEAP, lsl #32
    // 0x1273a9c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1273aa0: cmp             w0, w16
    // 0x1273aa4: b.ne            #0x1273ab4
    // 0x1273aa8: r2 = _colors
    //     0x1273aa8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1273aac: ldr             x2, [x2, #0xa18]
    // 0x1273ab0: r0 = InitLateFinalInstanceField()
    //     0x1273ab0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1273ab4: LoadField: r1 = r0->field_f
    //     0x1273ab4: ldur            w1, [x0, #0xf]
    // 0x1273ab8: DecompressPointer r1
    //     0x1273ab8: add             x1, x1, HEAP, lsl #32
    // 0x1273abc: str             x1, [SP]
    // 0x1273ac0: ldur            x1, [fp, #-0x18]
    // 0x1273ac4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x1273ac4: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x1273ac8: ldr             x4, [x4, #0x7f0]
    // 0x1273acc: r0 = copyWith()
    //     0x1273acc: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x1273ad0: mov             x2, x0
    // 0x1273ad4: ldur            x0, [fp, #-0x10]
    // 0x1273ad8: stur            x2, [fp, #-0x18]
    // 0x1273adc: r17 = 5069
    //     0x1273adc: mov             x17, #0x13cd
    // 0x1273ae0: cmp             x0, x17
    // 0x1273ae4: b.ne            #0x1273afc
    // 0x1273ae8: ldr             x3, [fp, #0x18]
    // 0x1273aec: LoadField: r1 = r3->field_73
    //     0x1273aec: ldur            w1, [x3, #0x73]
    // 0x1273af0: DecompressPointer r1
    //     0x1273af0: add             x1, x1, HEAP, lsl #32
    // 0x1273af4: mov             x0, x2
    // 0x1273af8: b               #0x1273bf8
    // 0x1273afc: ldr             x3, [fp, #0x18]
    // 0x1273b00: r17 = 5070
    //     0x1273b00: mov             x17, #0x13ce
    // 0x1273b04: cmp             x0, x17
    // 0x1273b08: b.eq            #0x12742ec
    // 0x1273b0c: r17 = 5071
    //     0x1273b0c: mov             x17, #0x13cf
    // 0x1273b10: cmp             x0, x17
    // 0x1273b14: b.ne            #0x1273b8c
    // 0x1273b18: LoadField: r1 = r3->field_97
    //     0x1273b18: ldur            w1, [x3, #0x97]
    // 0x1273b1c: DecompressPointer r1
    //     0x1273b1c: add             x1, x1, HEAP, lsl #32
    // 0x1273b20: r0 = of()
    //     0x1273b20: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1273b24: LoadField: r1 = r0->field_87
    //     0x1273b24: ldur            w1, [x0, #0x87]
    // 0x1273b28: DecompressPointer r1
    //     0x1273b28: add             x1, x1, HEAP, lsl #32
    // 0x1273b2c: LoadField: r0 = r1->field_3b
    //     0x1273b2c: ldur            w0, [x1, #0x3b]
    // 0x1273b30: DecompressPointer r0
    //     0x1273b30: add             x0, x0, HEAP, lsl #32
    // 0x1273b34: stur            x0, [fp, #-0x20]
    // 0x1273b38: cmp             w0, NULL
    // 0x1273b3c: b.eq            #0x1274304
    // 0x1273b40: ldr             x1, [fp, #0x18]
    // 0x1273b44: LoadField: r0 = r1->field_9b
    //     0x1273b44: ldur            w0, [x1, #0x9b]
    // 0x1273b48: DecompressPointer r0
    //     0x1273b48: add             x0, x0, HEAP, lsl #32
    // 0x1273b4c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1273b50: cmp             w0, w16
    // 0x1273b54: b.ne            #0x1273b64
    // 0x1273b58: r2 = _colors
    //     0x1273b58: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1273b5c: ldr             x2, [x2, #0xa10]
    // 0x1273b60: r0 = InitLateFinalInstanceField()
    //     0x1273b60: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1273b64: LoadField: r1 = r0->field_f
    //     0x1273b64: ldur            w1, [x0, #0xf]
    // 0x1273b68: DecompressPointer r1
    //     0x1273b68: add             x1, x1, HEAP, lsl #32
    // 0x1273b6c: str             x1, [SP]
    // 0x1273b70: ldur            x1, [fp, #-0x20]
    // 0x1273b74: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x1273b74: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x1273b78: ldr             x4, [x4, #0x7f0]
    // 0x1273b7c: r0 = copyWith()
    //     0x1273b7c: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x1273b80: mov             x1, x0
    // 0x1273b84: ldur            x0, [fp, #-0x18]
    // 0x1273b88: b               #0x1273bf8
    // 0x1273b8c: mov             x0, x3
    // 0x1273b90: LoadField: r1 = r0->field_97
    //     0x1273b90: ldur            w1, [x0, #0x97]
    // 0x1273b94: DecompressPointer r1
    //     0x1273b94: add             x1, x1, HEAP, lsl #32
    // 0x1273b98: r0 = of()
    //     0x1273b98: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1273b9c: LoadField: r1 = r0->field_87
    //     0x1273b9c: ldur            w1, [x0, #0x87]
    // 0x1273ba0: DecompressPointer r1
    //     0x1273ba0: add             x1, x1, HEAP, lsl #32
    // 0x1273ba4: LoadField: r0 = r1->field_2b
    //     0x1273ba4: ldur            w0, [x1, #0x2b]
    // 0x1273ba8: DecompressPointer r0
    //     0x1273ba8: add             x0, x0, HEAP, lsl #32
    // 0x1273bac: ldr             x1, [fp, #0x18]
    // 0x1273bb0: stur            x0, [fp, #-0x20]
    // 0x1273bb4: LoadField: r0 = r1->field_9b
    //     0x1273bb4: ldur            w0, [x1, #0x9b]
    // 0x1273bb8: DecompressPointer r0
    //     0x1273bb8: add             x0, x0, HEAP, lsl #32
    // 0x1273bbc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1273bc0: cmp             w0, w16
    // 0x1273bc4: b.ne            #0x1273bd4
    // 0x1273bc8: r2 = _colors
    //     0x1273bc8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1273bcc: ldr             x2, [x2, #0xa18]
    // 0x1273bd0: r0 = InitLateFinalInstanceField()
    //     0x1273bd0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1273bd4: LoadField: r1 = r0->field_f
    //     0x1273bd4: ldur            w1, [x0, #0xf]
    // 0x1273bd8: DecompressPointer r1
    //     0x1273bd8: add             x1, x1, HEAP, lsl #32
    // 0x1273bdc: str             x1, [SP]
    // 0x1273be0: ldur            x1, [fp, #-0x20]
    // 0x1273be4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x1273be4: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x1273be8: ldr             x4, [x4, #0x7f0]
    // 0x1273bec: r0 = copyWith()
    //     0x1273bec: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x1273bf0: mov             x1, x0
    // 0x1273bf4: ldur            x0, [fp, #-0x18]
    // 0x1273bf8: r2 = LoadClassIdInstr(r0)
    //     0x1273bf8: ldur            x2, [x0, #-1]
    //     0x1273bfc: ubfx            x2, x2, #0xc, #0x14
    // 0x1273c00: stp             x1, x0, [SP]
    // 0x1273c04: mov             x0, x2
    // 0x1273c08: mov             lr, x0
    // 0x1273c0c: ldr             lr, [x21, lr, lsl #3]
    // 0x1273c10: blr             lr
    // 0x1273c14: tbnz            w0, #4, #0x1273dc0
    // 0x1273c18: ldr             x1, [fp, #0x18]
    // 0x1273c1c: ldr             x2, [fp, #0x10]
    // 0x1273c20: LoadField: r0 = r2->field_77
    //     0x1273c20: ldur            w0, [x2, #0x77]
    // 0x1273c24: DecompressPointer r0
    //     0x1273c24: add             x0, x0, HEAP, lsl #32
    // 0x1273c28: LoadField: r3 = r1->field_77
    //     0x1273c28: ldur            w3, [x1, #0x77]
    // 0x1273c2c: DecompressPointer r3
    //     0x1273c2c: add             x3, x3, HEAP, lsl #32
    // 0x1273c30: r4 = LoadClassIdInstr(r0)
    //     0x1273c30: ldur            x4, [x0, #-1]
    //     0x1273c34: ubfx            x4, x4, #0xc, #0x14
    // 0x1273c38: stp             x3, x0, [SP]
    // 0x1273c3c: mov             x0, x4
    // 0x1273c40: mov             lr, x0
    // 0x1273c44: ldr             lr, [x21, lr, lsl #3]
    // 0x1273c48: blr             lr
    // 0x1273c4c: tbnz            w0, #4, #0x1273dc0
    // 0x1273c50: ldur            x0, [fp, #-8]
    // 0x1273c54: r17 = -5071
    //     0x1273c54: mov             x17, #-0x13cf
    // 0x1273c58: add             x16, x0, x17
    // 0x1273c5c: cmp             x16, #1
    // 0x1273c60: b.ls            #0x1273c70
    // 0x1273c64: r17 = 5069
    //     0x1273c64: mov             x17, #0x13cd
    // 0x1273c68: cmp             x0, x17
    // 0x1273c6c: b.ne            #0x1273c84
    // 0x1273c70: ldr             x3, [fp, #0x10]
    // 0x1273c74: LoadField: r1 = r3->field_8b
    //     0x1273c74: ldur            w1, [x3, #0x8b]
    // 0x1273c78: DecompressPointer r1
    //     0x1273c78: add             x1, x1, HEAP, lsl #32
    // 0x1273c7c: mov             x3, x1
    // 0x1273c80: b               #0x1273cb0
    // 0x1273c84: ldr             x3, [fp, #0x10]
    // 0x1273c88: r1 = Function '<anonymous closure>':.
    //     0x1273c88: add             x1, PP, #0x26, lsl #12  ; [pp+0x26aa0] AnonymousClosure: (0x1136ed8), of [package:flutter/src/material/slider.dart] _SliderDefaultsM3
    //     0x1273c8c: ldr             x1, [x1, #0xaa0]
    // 0x1273c90: r2 = Null
    //     0x1273c90: mov             x2, NULL
    // 0x1273c94: r0 = AllocateClosure()
    //     0x1273c94: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1273c98: r16 = <Size?>
    //     0x1273c98: add             x16, PP, #0x26, lsl #12  ; [pp+0x26aa8] TypeArguments: <Size?>
    //     0x1273c9c: ldr             x16, [x16, #0xaa8]
    // 0x1273ca0: stp             x0, x16, [SP]
    // 0x1273ca4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1273ca4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1273ca8: r0 = resolveWith()
    //     0x1273ca8: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1273cac: mov             x3, x0
    // 0x1273cb0: ldur            x0, [fp, #-0x10]
    // 0x1273cb4: stur            x3, [fp, #-0x18]
    // 0x1273cb8: r17 = -5071
    //     0x1273cb8: mov             x17, #-0x13cf
    // 0x1273cbc: add             x16, x0, x17
    // 0x1273cc0: cmp             x16, #1
    // 0x1273cc4: b.ls            #0x1273cd4
    // 0x1273cc8: r17 = 5069
    //     0x1273cc8: mov             x17, #0x13cd
    // 0x1273ccc: cmp             x0, x17
    // 0x1273cd0: b.ne            #0x1273ce8
    // 0x1273cd4: ldr             x4, [fp, #0x18]
    // 0x1273cd8: LoadField: r1 = r4->field_8b
    //     0x1273cd8: ldur            w1, [x4, #0x8b]
    // 0x1273cdc: DecompressPointer r1
    //     0x1273cdc: add             x1, x1, HEAP, lsl #32
    // 0x1273ce0: mov             x0, x3
    // 0x1273ce4: b               #0x1273d18
    // 0x1273ce8: ldr             x4, [fp, #0x18]
    // 0x1273cec: r1 = Function '<anonymous closure>':.
    //     0x1273cec: add             x1, PP, #0x26, lsl #12  ; [pp+0x26aa0] AnonymousClosure: (0x1136ed8), of [package:flutter/src/material/slider.dart] _SliderDefaultsM3
    //     0x1273cf0: ldr             x1, [x1, #0xaa0]
    // 0x1273cf4: r2 = Null
    //     0x1273cf4: mov             x2, NULL
    // 0x1273cf8: r0 = AllocateClosure()
    //     0x1273cf8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1273cfc: r16 = <Size?>
    //     0x1273cfc: add             x16, PP, #0x26, lsl #12  ; [pp+0x26aa8] TypeArguments: <Size?>
    //     0x1273d00: ldr             x16, [x16, #0xaa8]
    // 0x1273d04: stp             x0, x16, [SP]
    // 0x1273d08: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1273d08: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1273d0c: r0 = resolveWith()
    //     0x1273d0c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1273d10: mov             x1, x0
    // 0x1273d14: ldur            x0, [fp, #-0x18]
    // 0x1273d18: cmp             w0, w1
    // 0x1273d1c: b.ne            #0x1273dc0
    // 0x1273d20: ldur            x0, [fp, #-8]
    // 0x1273d24: r17 = -5071
    //     0x1273d24: mov             x17, #-0x13cf
    // 0x1273d28: add             x16, x0, x17
    // 0x1273d2c: cmp             x16, #1
    // 0x1273d30: b.ls            #0x1273d40
    // 0x1273d34: r17 = 5069
    //     0x1273d34: mov             x17, #0x13cd
    // 0x1273d38: cmp             x0, x17
    // 0x1273d3c: b.ne            #0x1273d54
    // 0x1273d40: ldr             x1, [fp, #0x10]
    // 0x1273d44: LoadField: r0 = r1->field_8f
    //     0x1273d44: ldur            w0, [x1, #0x8f]
    // 0x1273d48: DecompressPointer r0
    //     0x1273d48: add             x0, x0, HEAP, lsl #32
    // 0x1273d4c: mov             x1, x0
    // 0x1273d50: b               #0x1273d5c
    // 0x1273d54: r1 = 6.000000
    //     0x1273d54: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c438] 6
    //     0x1273d58: ldr             x1, [x1, #0x438]
    // 0x1273d5c: ldur            x0, [fp, #-0x10]
    // 0x1273d60: r17 = -5071
    //     0x1273d60: mov             x17, #-0x13cf
    // 0x1273d64: add             x16, x0, x17
    // 0x1273d68: cmp             x16, #1
    // 0x1273d6c: b.ls            #0x1273d7c
    // 0x1273d70: r17 = 5069
    //     0x1273d70: mov             x17, #0x13cd
    // 0x1273d74: cmp             x0, x17
    // 0x1273d78: b.ne            #0x1273d90
    // 0x1273d7c: ldr             x0, [fp, #0x18]
    // 0x1273d80: LoadField: r2 = r0->field_8f
    //     0x1273d80: ldur            w2, [x0, #0x8f]
    // 0x1273d84: DecompressPointer r2
    //     0x1273d84: add             x2, x2, HEAP, lsl #32
    // 0x1273d88: mov             x0, x2
    // 0x1273d8c: b               #0x1273d98
    // 0x1273d90: r0 = 6.000000
    //     0x1273d90: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c438] 6
    //     0x1273d94: ldr             x0, [x0, #0x438]
    // 0x1273d98: r2 = LoadClassIdInstr(r1)
    //     0x1273d98: ldur            x2, [x1, #-1]
    //     0x1273d9c: ubfx            x2, x2, #0xc, #0x14
    // 0x1273da0: stp             x0, x1, [SP]
    // 0x1273da4: mov             x0, x2
    // 0x1273da8: mov             lr, x0
    // 0x1273dac: ldr             lr, [x21, lr, lsl #3]
    // 0x1273db0: blr             lr
    // 0x1273db4: tbnz            w0, #4, #0x1273dc0
    // 0x1273db8: r0 = true
    //     0x1273db8: add             x0, NULL, #0x20  ; true
    // 0x1273dbc: b               #0x1273dc4
    // 0x1273dc0: r0 = false
    //     0x1273dc0: add             x0, NULL, #0x30  ; false
    // 0x1273dc4: LeaveFrame
    //     0x1273dc4: mov             SP, fp
    //     0x1273dc8: ldp             fp, lr, [SP], #0x10
    // 0x1273dcc: ret
    //     0x1273dcc: ret             
    // 0x1273dd0: mov             x1, x2
    // 0x1273dd4: LoadField: r0 = r1->field_9b
    //     0x1273dd4: ldur            w0, [x1, #0x9b]
    // 0x1273dd8: DecompressPointer r0
    //     0x1273dd8: add             x0, x0, HEAP, lsl #32
    // 0x1273ddc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1273de0: cmp             w0, w16
    // 0x1273de4: b.ne            #0x1273df4
    // 0x1273de8: r2 = _colors
    //     0x1273de8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1273dec: ldr             x2, [x2, #0xab0]
    // 0x1273df0: r0 = InitLateFinalInstanceField()
    //     0x1273df0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1273df4: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1273df4: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1273df8: r0 = Throw()
    //     0x1273df8: bl              #0x13ddb2c  ; ThrowStub
    // 0x1273dfc: brk             #0
    // 0x1273e00: mov             x1, x0
    // 0x1273e04: LoadField: r0 = r1->field_9b
    //     0x1273e04: ldur            w0, [x1, #0x9b]
    // 0x1273e08: DecompressPointer r0
    //     0x1273e08: add             x0, x0, HEAP, lsl #32
    // 0x1273e0c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1273e10: cmp             w0, w16
    // 0x1273e14: b.ne            #0x1273e24
    // 0x1273e18: r2 = _colors
    //     0x1273e18: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1273e1c: ldr             x2, [x2, #0xab0]
    // 0x1273e20: r0 = InitLateFinalInstanceField()
    //     0x1273e20: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1273e24: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1273e24: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1273e28: r0 = Throw()
    //     0x1273e28: bl              #0x13ddb2c  ; ThrowStub
    // 0x1273e2c: brk             #0
    // 0x1273e30: mov             x1, x2
    // 0x1273e34: LoadField: r0 = r1->field_9b
    //     0x1273e34: ldur            w0, [x1, #0x9b]
    // 0x1273e38: DecompressPointer r0
    //     0x1273e38: add             x0, x0, HEAP, lsl #32
    // 0x1273e3c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1273e40: cmp             w0, w16
    // 0x1273e44: b.ne            #0x1273e54
    // 0x1273e48: r2 = _colors
    //     0x1273e48: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1273e4c: ldr             x2, [x2, #0xab0]
    // 0x1273e50: r0 = InitLateFinalInstanceField()
    //     0x1273e50: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1273e54: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1273e54: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1273e58: r0 = Throw()
    //     0x1273e58: bl              #0x13ddb2c  ; ThrowStub
    // 0x1273e5c: brk             #0
    // 0x1273e60: mov             x0, x3
    // 0x1273e64: mov             x1, x0
    // 0x1273e68: LoadField: r0 = r1->field_9b
    //     0x1273e68: ldur            w0, [x1, #0x9b]
    // 0x1273e6c: DecompressPointer r0
    //     0x1273e6c: add             x0, x0, HEAP, lsl #32
    // 0x1273e70: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1273e74: cmp             w0, w16
    // 0x1273e78: b.ne            #0x1273e88
    // 0x1273e7c: r2 = _colors
    //     0x1273e7c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1273e80: ldr             x2, [x2, #0xab0]
    // 0x1273e84: r0 = InitLateFinalInstanceField()
    //     0x1273e84: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1273e88: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1273e88: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1273e8c: r0 = Throw()
    //     0x1273e8c: bl              #0x13ddb2c  ; ThrowStub
    // 0x1273e90: brk             #0
    // 0x1273e94: mov             x1, x2
    // 0x1273e98: LoadField: r0 = r1->field_9b
    //     0x1273e98: ldur            w0, [x1, #0x9b]
    // 0x1273e9c: DecompressPointer r0
    //     0x1273e9c: add             x0, x0, HEAP, lsl #32
    // 0x1273ea0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1273ea4: cmp             w0, w16
    // 0x1273ea8: b.ne            #0x1273eb8
    // 0x1273eac: r2 = _colors
    //     0x1273eac: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1273eb0: ldr             x2, [x2, #0xab0]
    // 0x1273eb4: r0 = InitLateFinalInstanceField()
    //     0x1273eb4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1273eb8: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1273eb8: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1273ebc: r0 = Throw()
    //     0x1273ebc: bl              #0x13ddb2c  ; ThrowStub
    // 0x1273ec0: brk             #0
    // 0x1273ec4: mov             x0, x3
    // 0x1273ec8: mov             x1, x0
    // 0x1273ecc: LoadField: r0 = r1->field_9b
    //     0x1273ecc: ldur            w0, [x1, #0x9b]
    // 0x1273ed0: DecompressPointer r0
    //     0x1273ed0: add             x0, x0, HEAP, lsl #32
    // 0x1273ed4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1273ed8: cmp             w0, w16
    // 0x1273edc: b.ne            #0x1273eec
    // 0x1273ee0: r2 = _colors
    //     0x1273ee0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1273ee4: ldr             x2, [x2, #0xab0]
    // 0x1273ee8: r0 = InitLateFinalInstanceField()
    //     0x1273ee8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1273eec: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1273eec: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1273ef0: r0 = Throw()
    //     0x1273ef0: bl              #0x13ddb2c  ; ThrowStub
    // 0x1273ef4: brk             #0
    // 0x1273ef8: mov             x1, x2
    // 0x1273efc: LoadField: r0 = r1->field_9b
    //     0x1273efc: ldur            w0, [x1, #0x9b]
    // 0x1273f00: DecompressPointer r0
    //     0x1273f00: add             x0, x0, HEAP, lsl #32
    // 0x1273f04: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1273f08: cmp             w0, w16
    // 0x1273f0c: b.ne            #0x1273f1c
    // 0x1273f10: r2 = _colors
    //     0x1273f10: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1273f14: ldr             x2, [x2, #0xab0]
    // 0x1273f18: r0 = InitLateFinalInstanceField()
    //     0x1273f18: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1273f1c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1273f1c: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1273f20: r0 = Throw()
    //     0x1273f20: bl              #0x13ddb2c  ; ThrowStub
    // 0x1273f24: brk             #0
    // 0x1273f28: mov             x0, x3
    // 0x1273f2c: mov             x1, x0
    // 0x1273f30: LoadField: r0 = r1->field_9b
    //     0x1273f30: ldur            w0, [x1, #0x9b]
    // 0x1273f34: DecompressPointer r0
    //     0x1273f34: add             x0, x0, HEAP, lsl #32
    // 0x1273f38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1273f3c: cmp             w0, w16
    // 0x1273f40: b.ne            #0x1273f50
    // 0x1273f44: r2 = _colors
    //     0x1273f44: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1273f48: ldr             x2, [x2, #0xab0]
    // 0x1273f4c: r0 = InitLateFinalInstanceField()
    //     0x1273f4c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1273f50: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1273f50: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1273f54: r0 = Throw()
    //     0x1273f54: bl              #0x13ddb2c  ; ThrowStub
    // 0x1273f58: brk             #0
    // 0x1273f5c: mov             x1, x2
    // 0x1273f60: LoadField: r0 = r1->field_9b
    //     0x1273f60: ldur            w0, [x1, #0x9b]
    // 0x1273f64: DecompressPointer r0
    //     0x1273f64: add             x0, x0, HEAP, lsl #32
    // 0x1273f68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1273f6c: cmp             w0, w16
    // 0x1273f70: b.ne            #0x1273f80
    // 0x1273f74: r2 = _colors
    //     0x1273f74: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1273f78: ldr             x2, [x2, #0xab0]
    // 0x1273f7c: r0 = InitLateFinalInstanceField()
    //     0x1273f7c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1273f80: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1273f80: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1273f84: r0 = Throw()
    //     0x1273f84: bl              #0x13ddb2c  ; ThrowStub
    // 0x1273f88: brk             #0
    // 0x1273f8c: mov             x0, x3
    // 0x1273f90: mov             x1, x0
    // 0x1273f94: LoadField: r0 = r1->field_9b
    //     0x1273f94: ldur            w0, [x1, #0x9b]
    // 0x1273f98: DecompressPointer r0
    //     0x1273f98: add             x0, x0, HEAP, lsl #32
    // 0x1273f9c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1273fa0: cmp             w0, w16
    // 0x1273fa4: b.ne            #0x1273fb4
    // 0x1273fa8: r2 = _colors
    //     0x1273fa8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1273fac: ldr             x2, [x2, #0xab0]
    // 0x1273fb0: r0 = InitLateFinalInstanceField()
    //     0x1273fb0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1273fb4: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1273fb4: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1273fb8: r0 = Throw()
    //     0x1273fb8: bl              #0x13ddb2c  ; ThrowStub
    // 0x1273fbc: brk             #0
    // 0x1273fc0: mov             x1, x2
    // 0x1273fc4: LoadField: r0 = r1->field_9b
    //     0x1273fc4: ldur            w0, [x1, #0x9b]
    // 0x1273fc8: DecompressPointer r0
    //     0x1273fc8: add             x0, x0, HEAP, lsl #32
    // 0x1273fcc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1273fd0: cmp             w0, w16
    // 0x1273fd4: b.ne            #0x1273fe4
    // 0x1273fd8: r2 = _colors
    //     0x1273fd8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1273fdc: ldr             x2, [x2, #0xab0]
    // 0x1273fe0: r0 = InitLateFinalInstanceField()
    //     0x1273fe0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1273fe4: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1273fe4: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1273fe8: r0 = Throw()
    //     0x1273fe8: bl              #0x13ddb2c  ; ThrowStub
    // 0x1273fec: brk             #0
    // 0x1273ff0: mov             x0, x3
    // 0x1273ff4: mov             x1, x0
    // 0x1273ff8: LoadField: r0 = r1->field_9b
    //     0x1273ff8: ldur            w0, [x1, #0x9b]
    // 0x1273ffc: DecompressPointer r0
    //     0x1273ffc: add             x0, x0, HEAP, lsl #32
    // 0x1274000: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1274004: cmp             w0, w16
    // 0x1274008: b.ne            #0x1274018
    // 0x127400c: r2 = _colors
    //     0x127400c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1274010: ldr             x2, [x2, #0xab0]
    // 0x1274014: r0 = InitLateFinalInstanceField()
    //     0x1274014: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1274018: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1274018: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x127401c: r0 = Throw()
    //     0x127401c: bl              #0x13ddb2c  ; ThrowStub
    // 0x1274020: brk             #0
    // 0x1274024: mov             x1, x2
    // 0x1274028: LoadField: r0 = r1->field_9b
    //     0x1274028: ldur            w0, [x1, #0x9b]
    // 0x127402c: DecompressPointer r0
    //     0x127402c: add             x0, x0, HEAP, lsl #32
    // 0x1274030: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1274034: cmp             w0, w16
    // 0x1274038: b.ne            #0x1274048
    // 0x127403c: r2 = _colors
    //     0x127403c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1274040: ldr             x2, [x2, #0xab0]
    // 0x1274044: r0 = InitLateFinalInstanceField()
    //     0x1274044: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1274048: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1274048: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x127404c: r0 = Throw()
    //     0x127404c: bl              #0x13ddb2c  ; ThrowStub
    // 0x1274050: brk             #0
    // 0x1274054: mov             x0, x3
    // 0x1274058: mov             x1, x0
    // 0x127405c: LoadField: r0 = r1->field_9b
    //     0x127405c: ldur            w0, [x1, #0x9b]
    // 0x1274060: DecompressPointer r0
    //     0x1274060: add             x0, x0, HEAP, lsl #32
    // 0x1274064: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1274068: cmp             w0, w16
    // 0x127406c: b.ne            #0x127407c
    // 0x1274070: r2 = _colors
    //     0x1274070: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1274074: ldr             x2, [x2, #0xab0]
    // 0x1274078: r0 = InitLateFinalInstanceField()
    //     0x1274078: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x127407c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x127407c: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1274080: r0 = Throw()
    //     0x1274080: bl              #0x13ddb2c  ; ThrowStub
    // 0x1274084: brk             #0
    // 0x1274088: mov             x1, x2
    // 0x127408c: LoadField: r0 = r1->field_9b
    //     0x127408c: ldur            w0, [x1, #0x9b]
    // 0x1274090: DecompressPointer r0
    //     0x1274090: add             x0, x0, HEAP, lsl #32
    // 0x1274094: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1274098: cmp             w0, w16
    // 0x127409c: b.ne            #0x12740ac
    // 0x12740a0: r2 = _colors
    //     0x12740a0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x12740a4: ldr             x2, [x2, #0xab0]
    // 0x12740a8: r0 = InitLateFinalInstanceField()
    //     0x12740a8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12740ac: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x12740ac: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x12740b0: r0 = Throw()
    //     0x12740b0: bl              #0x13ddb2c  ; ThrowStub
    // 0x12740b4: brk             #0
    // 0x12740b8: mov             x0, x3
    // 0x12740bc: mov             x1, x0
    // 0x12740c0: LoadField: r0 = r1->field_9b
    //     0x12740c0: ldur            w0, [x1, #0x9b]
    // 0x12740c4: DecompressPointer r0
    //     0x12740c4: add             x0, x0, HEAP, lsl #32
    // 0x12740c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12740cc: cmp             w0, w16
    // 0x12740d0: b.ne            #0x12740e0
    // 0x12740d4: r2 = _colors
    //     0x12740d4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x12740d8: ldr             x2, [x2, #0xab0]
    // 0x12740dc: r0 = InitLateFinalInstanceField()
    //     0x12740dc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12740e0: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x12740e0: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x12740e4: r0 = Throw()
    //     0x12740e4: bl              #0x13ddb2c  ; ThrowStub
    // 0x12740e8: brk             #0
    // 0x12740ec: mov             x1, x2
    // 0x12740f0: LoadField: r0 = r1->field_9b
    //     0x12740f0: ldur            w0, [x1, #0x9b]
    // 0x12740f4: DecompressPointer r0
    //     0x12740f4: add             x0, x0, HEAP, lsl #32
    // 0x12740f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12740fc: cmp             w0, w16
    // 0x1274100: b.ne            #0x1274110
    // 0x1274104: r2 = _colors
    //     0x1274104: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1274108: ldr             x2, [x2, #0xab0]
    // 0x127410c: r0 = InitLateFinalInstanceField()
    //     0x127410c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1274110: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1274110: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1274114: r0 = Throw()
    //     0x1274114: bl              #0x13ddb2c  ; ThrowStub
    // 0x1274118: brk             #0
    // 0x127411c: mov             x0, x3
    // 0x1274120: mov             x1, x0
    // 0x1274124: LoadField: r0 = r1->field_9b
    //     0x1274124: ldur            w0, [x1, #0x9b]
    // 0x1274128: DecompressPointer r0
    //     0x1274128: add             x0, x0, HEAP, lsl #32
    // 0x127412c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1274130: cmp             w0, w16
    // 0x1274134: b.ne            #0x1274144
    // 0x1274138: r2 = _colors
    //     0x1274138: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x127413c: ldr             x2, [x2, #0xab0]
    // 0x1274140: r0 = InitLateFinalInstanceField()
    //     0x1274140: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1274144: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1274144: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1274148: r0 = Throw()
    //     0x1274148: bl              #0x13ddb2c  ; ThrowStub
    // 0x127414c: brk             #0
    // 0x1274150: mov             x1, x2
    // 0x1274154: LoadField: r0 = r1->field_9b
    //     0x1274154: ldur            w0, [x1, #0x9b]
    // 0x1274158: DecompressPointer r0
    //     0x1274158: add             x0, x0, HEAP, lsl #32
    // 0x127415c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1274160: cmp             w0, w16
    // 0x1274164: b.ne            #0x1274174
    // 0x1274168: r2 = _colors
    //     0x1274168: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x127416c: ldr             x2, [x2, #0xab0]
    // 0x1274170: r0 = InitLateFinalInstanceField()
    //     0x1274170: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1274174: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1274174: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1274178: r0 = Throw()
    //     0x1274178: bl              #0x13ddb2c  ; ThrowStub
    // 0x127417c: brk             #0
    // 0x1274180: mov             x0, x3
    // 0x1274184: mov             x1, x0
    // 0x1274188: LoadField: r0 = r1->field_9b
    //     0x1274188: ldur            w0, [x1, #0x9b]
    // 0x127418c: DecompressPointer r0
    //     0x127418c: add             x0, x0, HEAP, lsl #32
    // 0x1274190: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1274194: cmp             w0, w16
    // 0x1274198: b.ne            #0x12741a8
    // 0x127419c: r2 = _colors
    //     0x127419c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x12741a0: ldr             x2, [x2, #0xab0]
    // 0x12741a4: r0 = InitLateFinalInstanceField()
    //     0x12741a4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12741a8: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x12741a8: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x12741ac: r0 = Throw()
    //     0x12741ac: bl              #0x13ddb2c  ; ThrowStub
    // 0x12741b0: brk             #0
    // 0x12741b4: mov             x1, x2
    // 0x12741b8: LoadField: r0 = r1->field_9b
    //     0x12741b8: ldur            w0, [x1, #0x9b]
    // 0x12741bc: DecompressPointer r0
    //     0x12741bc: add             x0, x0, HEAP, lsl #32
    // 0x12741c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12741c4: cmp             w0, w16
    // 0x12741c8: b.ne            #0x12741d8
    // 0x12741cc: r2 = _colors
    //     0x12741cc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x12741d0: ldr             x2, [x2, #0xab0]
    // 0x12741d4: r0 = InitLateFinalInstanceField()
    //     0x12741d4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12741d8: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x12741d8: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x12741dc: r0 = Throw()
    //     0x12741dc: bl              #0x13ddb2c  ; ThrowStub
    // 0x12741e0: brk             #0
    // 0x12741e4: mov             x0, x3
    // 0x12741e8: mov             x1, x0
    // 0x12741ec: LoadField: r0 = r1->field_9b
    //     0x12741ec: ldur            w0, [x1, #0x9b]
    // 0x12741f0: DecompressPointer r0
    //     0x12741f0: add             x0, x0, HEAP, lsl #32
    // 0x12741f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12741f8: cmp             w0, w16
    // 0x12741fc: b.ne            #0x127420c
    // 0x1274200: r2 = _colors
    //     0x1274200: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1274204: ldr             x2, [x2, #0xab0]
    // 0x1274208: r0 = InitLateFinalInstanceField()
    //     0x1274208: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x127420c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x127420c: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1274210: r0 = Throw()
    //     0x1274210: bl              #0x13ddb2c  ; ThrowStub
    // 0x1274214: brk             #0
    // 0x1274218: mov             x1, x2
    // 0x127421c: LoadField: r0 = r1->field_9b
    //     0x127421c: ldur            w0, [x1, #0x9b]
    // 0x1274220: DecompressPointer r0
    //     0x1274220: add             x0, x0, HEAP, lsl #32
    // 0x1274224: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1274228: cmp             w0, w16
    // 0x127422c: b.ne            #0x127423c
    // 0x1274230: r2 = _colors
    //     0x1274230: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1274234: ldr             x2, [x2, #0xab0]
    // 0x1274238: r0 = InitLateFinalInstanceField()
    //     0x1274238: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x127423c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x127423c: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1274240: r0 = Throw()
    //     0x1274240: bl              #0x13ddb2c  ; ThrowStub
    // 0x1274244: brk             #0
    // 0x1274248: mov             x0, x3
    // 0x127424c: mov             x1, x0
    // 0x1274250: LoadField: r0 = r1->field_9b
    //     0x1274250: ldur            w0, [x1, #0x9b]
    // 0x1274254: DecompressPointer r0
    //     0x1274254: add             x0, x0, HEAP, lsl #32
    // 0x1274258: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x127425c: cmp             w0, w16
    // 0x1274260: b.ne            #0x1274270
    // 0x1274264: r2 = _colors
    //     0x1274264: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1274268: ldr             x2, [x2, #0xab0]
    // 0x127426c: r0 = InitLateFinalInstanceField()
    //     0x127426c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1274270: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1274270: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1274274: r0 = Throw()
    //     0x1274274: bl              #0x13ddb2c  ; ThrowStub
    // 0x1274278: brk             #0
    // 0x127427c: mov             x1, x2
    // 0x1274280: LoadField: r0 = r1->field_9b
    //     0x1274280: ldur            w0, [x1, #0x9b]
    // 0x1274284: DecompressPointer r0
    //     0x1274284: add             x0, x0, HEAP, lsl #32
    // 0x1274288: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x127428c: cmp             w0, w16
    // 0x1274290: b.ne            #0x12742a0
    // 0x1274294: r2 = _colors
    //     0x1274294: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x1274298: ldr             x2, [x2, #0xab0]
    // 0x127429c: r0 = InitLateFinalInstanceField()
    //     0x127429c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12742a0: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x12742a0: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x12742a4: r0 = Throw()
    //     0x12742a4: bl              #0x13ddb2c  ; ThrowStub
    // 0x12742a8: brk             #0
    // 0x12742ac: mov             x0, x3
    // 0x12742b0: mov             x1, x0
    // 0x12742b4: LoadField: r0 = r1->field_9b
    //     0x12742b4: ldur            w0, [x1, #0x9b]
    // 0x12742b8: DecompressPointer r0
    //     0x12742b8: add             x0, x0, HEAP, lsl #32
    // 0x12742bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12742c0: cmp             w0, w16
    // 0x12742c4: b.ne            #0x12742d4
    // 0x12742c8: r2 = _colors
    //     0x12742c8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0x12742cc: ldr             x2, [x2, #0xab0]
    // 0x12742d0: r0 = InitLateFinalInstanceField()
    //     0x12742d0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12742d4: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x12742d4: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x12742d8: r0 = Throw()
    //     0x12742d8: bl              #0x13ddb2c  ; ThrowStub
    // 0x12742dc: brk             #0
    // 0x12742e0: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x12742e0: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x12742e4: r0 = Throw()
    //     0x12742e4: bl              #0x13ddb2c  ; ThrowStub
    // 0x12742e8: brk             #0
    // 0x12742ec: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x12742ec: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x12742f0: r0 = Throw()
    //     0x12742f0: bl              #0x13ddb2c  ; ThrowStub
    // 0x12742f4: brk             #0
    // 0x12742f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12742f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12742fc: b               #0x1271bac
    // 0x1274300: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1274300: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1274304: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1274304: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6838, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class SliderTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xd3d7b8, size: 0x5c
    // 0xd3d7b8: EnterFrame
    //     0xd3d7b8: stp             fp, lr, [SP, #-0x10]!
    //     0xd3d7bc: mov             fp, SP
    // 0xd3d7c0: AllocStack(0x18)
    //     0xd3d7c0: sub             SP, SP, #0x18
    // 0xd3d7c4: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xd3d7c4: stur            x1, [fp, #-8]
    // 0xd3d7c8: CheckStackOverflow
    //     0xd3d7c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3d7cc: cmp             SP, x16
    //     0xd3d7d0: b.ls            #0xd3d80c
    // 0xd3d7d4: r16 = <SliderTheme>
    //     0xd3d7d4: add             x16, PP, #0x26, lsl #12  ; [pp+0x26ac8] TypeArguments: <SliderTheme>
    //     0xd3d7d8: ldr             x16, [x16, #0xac8]
    // 0xd3d7dc: stp             x1, x16, [SP]
    // 0xd3d7e0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3d7e0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3d7e4: r0 = dependOnInheritedWidgetOfExactType()
    //     0xd3d7e4: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xd3d7e8: ldur            x1, [fp, #-8]
    // 0xd3d7ec: r0 = of()
    //     0xd3d7ec: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd3d7f0: r17 = 291
    //     0xd3d7f0: mov             x17, #0x123
    // 0xd3d7f4: ldr             w1, [x0, x17]
    // 0xd3d7f8: DecompressPointer r1
    //     0xd3d7f8: add             x1, x1, HEAP, lsl #32
    // 0xd3d7fc: mov             x0, x1
    // 0xd3d800: LeaveFrame
    //     0xd3d800: mov             SP, fp
    //     0xd3d804: ldp             fp, lr, [SP], #0x10
    // 0xd3d808: ret
    //     0xd3d808: ret             
    // 0xd3d80c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd3d80c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd3d810: b               #0xd3d7d4
  }
}

// class id: 8264, size: 0x14, field offset: 0x14
enum ShowValueIndicator extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa864, size: 0x64
    // 0x11aa864: EnterFrame
    //     0x11aa864: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa868: mov             fp, SP
    // 0x11aa86c: AllocStack(0x10)
    //     0x11aa86c: sub             SP, SP, #0x10
    // 0x11aa870: SetupParameters(ShowValueIndicator this /* r1 => r0, fp-0x8 */)
    //     0x11aa870: mov             x0, x1
    //     0x11aa874: stur            x1, [fp, #-8]
    // 0x11aa878: CheckStackOverflow
    //     0x11aa878: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa87c: cmp             SP, x16
    //     0x11aa880: b.ls            #0x11aa8c0
    // 0x11aa884: r1 = Null
    //     0x11aa884: mov             x1, NULL
    // 0x11aa888: r2 = 4
    //     0x11aa888: mov             x2, #4
    // 0x11aa88c: r0 = AllocateArray()
    //     0x11aa88c: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa890: r16 = "ShowValueIndicator."
    //     0x11aa890: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa37b8] "ShowValueIndicator."
    //     0x11aa894: ldr             x16, [x16, #0x7b8]
    // 0x11aa898: StoreField: r0->field_f = r16
    //     0x11aa898: stur            w16, [x0, #0xf]
    // 0x11aa89c: ldur            x1, [fp, #-8]
    // 0x11aa8a0: LoadField: r2 = r1->field_f
    //     0x11aa8a0: ldur            w2, [x1, #0xf]
    // 0x11aa8a4: DecompressPointer r2
    //     0x11aa8a4: add             x2, x2, HEAP, lsl #32
    // 0x11aa8a8: StoreField: r0->field_13 = r2
    //     0x11aa8a8: stur            w2, [x0, #0x13]
    // 0x11aa8ac: str             x0, [SP]
    // 0x11aa8b0: r0 = _interpolate()
    //     0x11aa8b0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa8b4: LeaveFrame
    //     0x11aa8b4: mov             SP, fp
    //     0x11aa8b8: ldp             fp, lr, [SP], #0x10
    // 0x11aa8bc: ret
    //     0x11aa8bc: ret             
    // 0x11aa8c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa8c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa8c4: b               #0x11aa884
  }
}
