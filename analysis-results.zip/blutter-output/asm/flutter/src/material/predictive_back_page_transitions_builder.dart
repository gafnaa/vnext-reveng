// lib: , url: package:flutter/src/material/predictive_back_page_transitions_builder.dart

// class id: 1048930, size: 0x8
class :: {
}

// class id: 3252, size: 0xc, field offset: 0x8
//   const constructor, 
class PredictiveBackPageTransitionsBuilder extends PageTransitionsBuilder {

  _ buildTransitions(/* No info */) {
    // ** addr: 0x119fb50, size: 0xb8
    // 0x119fb50: EnterFrame
    //     0x119fb50: stp             fp, lr, [SP, #-0x10]!
    //     0x119fb54: mov             fp, SP
    // 0x119fb58: AllocStack(0x10)
    //     0x119fb58: sub             SP, SP, #0x10
    // 0x119fb5c: SetupParameters()
    //     0x119fb5c: ldur            w0, [x4, #0xf]
    //     0x119fb60: cbnz            w0, #0x119fb6c
    //     0x119fb64: mov             x5, NULL
    //     0x119fb68: b               #0x119fb7c
    //     0x119fb6c: ldur            w0, [x4, #0x17]
    //     0x119fb70: add             x1, fp, w0, sxtw #2
    //     0x119fb74: ldr             x1, [x1, #0x10]
    //     0x119fb78: mov             x5, x1
    // 0x119fb7c: ldr             x4, [fp, #0x30]
    // 0x119fb80: ldr             x3, [fp, #0x28]
    // 0x119fb84: ldr             x2, [fp, #0x20]
    // 0x119fb88: ldr             x1, [fp, #0x18]
    // 0x119fb8c: ldr             x0, [fp, #0x10]
    // 0x119fb90: stur            x5, [fp, #-8]
    // 0x119fb94: r1 = 5
    //     0x119fb94: mov             x1, #5
    // 0x119fb98: r0 = AllocateContext()
    //     0x119fb98: bl              #0x13de838  ; AllocateContextStub
    // 0x119fb9c: mov             x1, x0
    // 0x119fba0: ldr             x0, [fp, #0x30]
    // 0x119fba4: StoreField: r1->field_f = r0
    //     0x119fba4: stur            w0, [x1, #0xf]
    // 0x119fba8: ldr             x0, [fp, #0x28]
    // 0x119fbac: StoreField: r1->field_13 = r0
    //     0x119fbac: stur            w0, [x1, #0x13]
    // 0x119fbb0: ldr             x2, [fp, #0x20]
    // 0x119fbb4: ArrayStore: r1[0] = r2  ; List_4
    //     0x119fbb4: stur            w2, [x1, #0x17]
    // 0x119fbb8: ldr             x2, [fp, #0x18]
    // 0x119fbbc: StoreField: r1->field_1b = r2
    //     0x119fbbc: stur            w2, [x1, #0x1b]
    // 0x119fbc0: ldr             x2, [fp, #0x10]
    // 0x119fbc4: StoreField: r1->field_1f = r2
    //     0x119fbc4: stur            w2, [x1, #0x1f]
    // 0x119fbc8: mov             x2, x1
    // 0x119fbcc: r1 = Function '<anonymous closure>':.
    //     0x119fbcc: add             x1, PP, #0xcc, lsl #12  ; [pp+0xccfd8] AnonymousClosure: (0x119fc14), in [package:flutter/src/material/predictive_back_page_transitions_builder.dart] PredictiveBackPageTransitionsBuilder::buildTransitions (0x119fb50)
    //     0x119fbd0: ldr             x1, [x1, #0xfd8]
    // 0x119fbd4: r0 = AllocateClosure()
    //     0x119fbd4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x119fbd8: mov             x1, x0
    // 0x119fbdc: ldur            x0, [fp, #-8]
    // 0x119fbe0: stur            x1, [fp, #-0x10]
    // 0x119fbe4: StoreField: r1->field_b = r0
    //     0x119fbe4: stur            w0, [x1, #0xb]
    // 0x119fbe8: r0 = _PredictiveBackGestureDetector()
    //     0x119fbe8: bl              #0x119fc08  ; Allocate_PredictiveBackGestureDetectorStub -> _PredictiveBackGestureDetector (size=0x14)
    // 0x119fbec: ldr             x1, [fp, #0x28]
    // 0x119fbf0: StoreField: r0->field_f = r1
    //     0x119fbf0: stur            w1, [x0, #0xf]
    // 0x119fbf4: ldur            x1, [fp, #-0x10]
    // 0x119fbf8: StoreField: r0->field_b = r1
    //     0x119fbf8: stur            w1, [x0, #0xb]
    // 0x119fbfc: LeaveFrame
    //     0x119fbfc: mov             SP, fp
    //     0x119fc00: ldp             fp, lr, [SP], #0x10
    // 0x119fc04: ret
    //     0x119fc04: ret             
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, _PredictiveBackPhase, PredictiveBackEvent?, PredictiveBackEvent?) {
    // ** addr: 0x119fc14, size: 0x108
    // 0x119fc14: EnterFrame
    //     0x119fc14: stp             fp, lr, [SP, #-0x10]!
    //     0x119fc18: mov             fp, SP
    // 0x119fc1c: AllocStack(0x20)
    //     0x119fc1c: sub             SP, SP, #0x20
    // 0x119fc20: SetupParameters([dynamic _ /* r0 */])
    //     0x119fc20: ldr             x0, [fp, #0x30]
    //     0x119fc24: ldur            w2, [x0, #0x17]
    //     0x119fc28: add             x2, x2, HEAP, lsl #32
    //     0x119fc2c: stur            x2, [fp, #-8]
    // 0x119fc30: CheckStackOverflow
    //     0x119fc30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119fc34: cmp             SP, x16
    //     0x119fc38: b.ls            #0x119fd14
    // 0x119fc3c: LoadField: r1 = r2->field_13
    //     0x119fc3c: ldur            w1, [x2, #0x13]
    // 0x119fc40: DecompressPointer r1
    //     0x119fc40: add             x1, x1, HEAP, lsl #32
    // 0x119fc44: r0 = LoadClassIdInstr(r1)
    //     0x119fc44: ldur            x0, [x1, #-1]
    //     0x119fc48: ubfx            x0, x0, #0xc, #0x14
    // 0x119fc4c: r0 = GDT[cid_x0 + -0xd25]()
    //     0x119fc4c: sub             lr, x0, #0xd25
    //     0x119fc50: ldr             lr, [x21, lr, lsl #3]
    //     0x119fc54: blr             lr
    // 0x119fc58: tbnz            w0, #4, #0x119fcc4
    // 0x119fc5c: ldr             x3, [fp, #0x20]
    // 0x119fc60: ldr             x2, [fp, #0x18]
    // 0x119fc64: ldr             x1, [fp, #0x10]
    // 0x119fc68: ldur            x0, [fp, #-8]
    // 0x119fc6c: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x119fc6c: ldur            w4, [x0, #0x17]
    // 0x119fc70: DecompressPointer r4
    //     0x119fc70: add             x4, x4, HEAP, lsl #32
    // 0x119fc74: stur            x4, [fp, #-0x18]
    // 0x119fc78: LoadField: r5 = r0->field_1f
    //     0x119fc78: ldur            w5, [x0, #0x1f]
    // 0x119fc7c: DecompressPointer r5
    //     0x119fc7c: add             x5, x5, HEAP, lsl #32
    // 0x119fc80: stur            x5, [fp, #-0x10]
    // 0x119fc84: r0 = _PredictiveBackSharedElementPageTransition()
    //     0x119fc84: bl              #0x119fd28  ; Allocate_PredictiveBackSharedElementPageTransitionStub -> _PredictiveBackSharedElementPageTransition (size=0x20)
    // 0x119fc88: mov             x1, x0
    // 0x119fc8c: ldur            x0, [fp, #-0x18]
    // 0x119fc90: StoreField: r1->field_b = r0
    //     0x119fc90: stur            w0, [x1, #0xb]
    // 0x119fc94: ldr             x0, [fp, #0x20]
    // 0x119fc98: StoreField: r1->field_f = r0
    //     0x119fc98: stur            w0, [x1, #0xf]
    // 0x119fc9c: ldr             x0, [fp, #0x18]
    // 0x119fca0: StoreField: r1->field_13 = r0
    //     0x119fca0: stur            w0, [x1, #0x13]
    // 0x119fca4: ldr             x0, [fp, #0x10]
    // 0x119fca8: ArrayStore: r1[0] = r0  ; List_4
    //     0x119fca8: stur            w0, [x1, #0x17]
    // 0x119fcac: ldur            x0, [fp, #-0x10]
    // 0x119fcb0: StoreField: r1->field_1b = r0
    //     0x119fcb0: stur            w0, [x1, #0x1b]
    // 0x119fcb4: mov             x0, x1
    // 0x119fcb8: LeaveFrame
    //     0x119fcb8: mov             SP, fp
    //     0x119fcbc: ldp             fp, lr, [SP], #0x10
    // 0x119fcc0: ret
    //     0x119fcc0: ret             
    // 0x119fcc4: ldur            x0, [fp, #-8]
    // 0x119fcc8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x119fcc8: ldur            w1, [x0, #0x17]
    // 0x119fccc: DecompressPointer r1
    //     0x119fccc: add             x1, x1, HEAP, lsl #32
    // 0x119fcd0: stur            x1, [fp, #-0x20]
    // 0x119fcd4: LoadField: r2 = r0->field_1b
    //     0x119fcd4: ldur            w2, [x0, #0x1b]
    // 0x119fcd8: DecompressPointer r2
    //     0x119fcd8: add             x2, x2, HEAP, lsl #32
    // 0x119fcdc: stur            x2, [fp, #-0x18]
    // 0x119fce0: LoadField: r3 = r0->field_1f
    //     0x119fce0: ldur            w3, [x0, #0x1f]
    // 0x119fce4: DecompressPointer r3
    //     0x119fce4: add             x3, x3, HEAP, lsl #32
    // 0x119fce8: stur            x3, [fp, #-0x10]
    // 0x119fcec: r0 = _FadeForwardsPageTransition()
    //     0x119fcec: bl              #0x119fd1c  ; Allocate_FadeForwardsPageTransitionStub -> _FadeForwardsPageTransition (size=0x1c)
    // 0x119fcf0: ldur            x1, [fp, #-0x20]
    // 0x119fcf4: StoreField: r0->field_b = r1
    //     0x119fcf4: stur            w1, [x0, #0xb]
    // 0x119fcf8: ldur            x1, [fp, #-0x18]
    // 0x119fcfc: StoreField: r0->field_f = r1
    //     0x119fcfc: stur            w1, [x0, #0xf]
    // 0x119fd00: ldur            x1, [fp, #-0x10]
    // 0x119fd04: ArrayStore: r0[0] = r1  ; List_4
    //     0x119fd04: stur            w1, [x0, #0x17]
    // 0x119fd08: LeaveFrame
    //     0x119fd08: mov             SP, fp
    //     0x119fd0c: ldp             fp, lr, [SP], #0x10
    // 0x119fd10: ret
    //     0x119fd10: ret             
    // 0x119fd14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119fd14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119fd18: b               #0x119fc3c
  }
  get _ transitionDuration(/* No info */) {
    // ** addr: 0x12f96f8, size: 0xc
    // 0x12f96f8: r0 = Instance_Duration
    //     0x12f96f8: add             x0, PP, #0x99, lsl #12  ; [pp+0x99080] Obj!Duration@12c8c71
    //     0x12f96fc: ldr             x0, [x0, #0x80]
    // 0x12f9700: ret
    //     0x12f9700: ret             
  }
}

// class id: 5725, size: 0x4c, field offset: 0x1c
class _PredictiveBackSharedElementPageTransitionState extends _MixinApplication90&State&SingleTickerProviderStateMixin {

  late Animation<Offset> _positionAnimation; // offset: 0x44

  _ build(/* No info */) {
    // ** addr: 0xd2fc00, size: 0x8c
    // 0xd2fc00: EnterFrame
    //     0xd2fc00: stp             fp, lr, [SP, #-0x10]!
    //     0xd2fc04: mov             fp, SP
    // 0xd2fc08: AllocStack(0x18)
    //     0xd2fc08: sub             SP, SP, #0x18
    // 0xd2fc0c: SetupParameters(_PredictiveBackSharedElementPageTransitionState this /* r1 => r1, fp-0x8 */)
    //     0xd2fc0c: stur            x1, [fp, #-8]
    // 0xd2fc10: r1 = 1
    //     0xd2fc10: mov             x1, #1
    // 0xd2fc14: r0 = AllocateContext()
    //     0xd2fc14: bl              #0x13de838  ; AllocateContextStub
    // 0xd2fc18: mov             x1, x0
    // 0xd2fc1c: ldur            x0, [fp, #-8]
    // 0xd2fc20: StoreField: r1->field_f = r0
    //     0xd2fc20: stur            w0, [x1, #0xf]
    // 0xd2fc24: LoadField: r2 = r0->field_b
    //     0xd2fc24: ldur            w2, [x0, #0xb]
    // 0xd2fc28: DecompressPointer r2
    //     0xd2fc28: add             x2, x2, HEAP, lsl #32
    // 0xd2fc2c: cmp             w2, NULL
    // 0xd2fc30: b.eq            #0xd2fc88
    // 0xd2fc34: LoadField: r0 = r2->field_b
    //     0xd2fc34: ldur            w0, [x2, #0xb]
    // 0xd2fc38: DecompressPointer r0
    //     0xd2fc38: add             x0, x0, HEAP, lsl #32
    // 0xd2fc3c: stur            x0, [fp, #-0x10]
    // 0xd2fc40: LoadField: r3 = r2->field_1b
    //     0xd2fc40: ldur            w3, [x2, #0x1b]
    // 0xd2fc44: DecompressPointer r3
    //     0xd2fc44: add             x3, x3, HEAP, lsl #32
    // 0xd2fc48: mov             x2, x1
    // 0xd2fc4c: stur            x3, [fp, #-8]
    // 0xd2fc50: r1 = Function '<anonymous closure>':.
    //     0xd2fc50: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1d18] AnonymousClosure: (0xd2fc8c), in [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackSharedElementPageTransitionState::build (0xd2fc00)
    //     0xd2fc54: ldr             x1, [x1, #0xd18]
    // 0xd2fc58: r0 = AllocateClosure()
    //     0xd2fc58: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd2fc5c: stur            x0, [fp, #-0x18]
    // 0xd2fc60: r0 = AnimatedBuilder()
    //     0xd2fc60: bl              #0x918e2c  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0xd2fc64: ldur            x1, [fp, #-0x18]
    // 0xd2fc68: StoreField: r0->field_f = r1
    //     0xd2fc68: stur            w1, [x0, #0xf]
    // 0xd2fc6c: ldur            x1, [fp, #-8]
    // 0xd2fc70: StoreField: r0->field_13 = r1
    //     0xd2fc70: stur            w1, [x0, #0x13]
    // 0xd2fc74: ldur            x1, [fp, #-0x10]
    // 0xd2fc78: StoreField: r0->field_b = r1
    //     0xd2fc78: stur            w1, [x0, #0xb]
    // 0xd2fc7c: LeaveFrame
    //     0xd2fc7c: mov             SP, fp
    //     0xd2fc80: ldp             fp, lr, [SP], #0x10
    // 0xd2fc84: ret
    //     0xd2fc84: ret             
    // 0xd2fc88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2fc88: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Transform <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0xd2fc8c, size: 0x320
    // 0xd2fc8c: EnterFrame
    //     0xd2fc8c: stp             fp, lr, [SP, #-0x10]!
    //     0xd2fc90: mov             fp, SP
    // 0xd2fc94: AllocStack(0x38)
    //     0xd2fc94: sub             SP, SP, #0x38
    // 0xd2fc98: SetupParameters([dynamic _ /* r0 */])
    //     0xd2fc98: ldr             x0, [fp, #0x20]
    //     0xd2fc9c: ldur            w2, [x0, #0x17]
    //     0xd2fca0: add             x2, x2, HEAP, lsl #32
    //     0xd2fca4: stur            x2, [fp, #-0x10]
    // 0xd2fca8: CheckStackOverflow
    //     0xd2fca8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd2fcac: cmp             SP, x16
    //     0xd2fcb0: b.ls            #0xd2ff88
    // 0xd2fcb4: LoadField: r0 = r2->field_f
    //     0xd2fcb4: ldur            w0, [x2, #0xf]
    // 0xd2fcb8: DecompressPointer r0
    //     0xd2fcb8: add             x0, x0, HEAP, lsl #32
    // 0xd2fcbc: stur            x0, [fp, #-8]
    // 0xd2fcc0: LoadField: r1 = r0->field_2b
    //     0xd2fcc0: ldur            w1, [x0, #0x2b]
    // 0xd2fcc4: DecompressPointer r1
    //     0xd2fcc4: add             x1, x1, HEAP, lsl #32
    // 0xd2fcc8: r0 = value()
    //     0xd2fcc8: bl              #0xae66fc  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::value
    // 0xd2fccc: LoadField: d0 = r0->field_7
    //     0xd2fccc: ldur            d0, [x0, #7]
    // 0xd2fcd0: ldur            x0, [fp, #-8]
    // 0xd2fcd4: StoreField: r0->field_2f = d0
    //     0xd2fcd4: stur            d0, [x0, #0x2f]
    // 0xd2fcd8: ldur            x0, [fp, #-0x10]
    // 0xd2fcdc: LoadField: r1 = r0->field_f
    //     0xd2fcdc: ldur            w1, [x0, #0xf]
    // 0xd2fce0: DecompressPointer r1
    //     0xd2fce0: add             x1, x1, HEAP, lsl #32
    // 0xd2fce4: LoadField: r2 = r1->field_23
    //     0xd2fce4: ldur            w2, [x1, #0x23]
    // 0xd2fce8: DecompressPointer r2
    //     0xd2fce8: add             x2, x2, HEAP, lsl #32
    // 0xd2fcec: LoadField: r3 = r1->field_2b
    //     0xd2fcec: ldur            w3, [x1, #0x2b]
    // 0xd2fcf0: DecompressPointer r3
    //     0xd2fcf0: add             x3, x3, HEAP, lsl #32
    // 0xd2fcf4: mov             x1, x2
    // 0xd2fcf8: mov             x2, x3
    // 0xd2fcfc: r0 = evaluate()
    //     0xd2fcfc: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xd2fd00: mov             x4, x0
    // 0xd2fd04: ldur            x3, [fp, #-0x10]
    // 0xd2fd08: stur            x4, [fp, #-8]
    // 0xd2fd0c: LoadField: r5 = r3->field_f
    //     0xd2fd0c: ldur            w5, [x3, #0xf]
    // 0xd2fd10: DecompressPointer r5
    //     0xd2fd10: add             x5, x5, HEAP, lsl #32
    // 0xd2fd14: stur            x5, [fp, #-0x18]
    // 0xd2fd18: LoadField: r0 = r5->field_b
    //     0xd2fd18: ldur            w0, [x5, #0xb]
    // 0xd2fd1c: DecompressPointer r0
    //     0xd2fd1c: add             x0, x0, HEAP, lsl #32
    // 0xd2fd20: cmp             w0, NULL
    // 0xd2fd24: b.eq            #0xd2ff90
    // 0xd2fd28: LoadField: r1 = r0->field_f
    //     0xd2fd28: ldur            w1, [x0, #0xf]
    // 0xd2fd2c: DecompressPointer r1
    //     0xd2fd2c: add             x1, x1, HEAP, lsl #32
    // 0xd2fd30: r16 = Instance__PredictiveBackPhase
    //     0xd2fd30: add             x16, PP, #0xd1, lsl #12  ; [pp+0xd1cd8] Obj!_PredictiveBackPhase@12c52e1
    //     0xd2fd34: ldr             x16, [x16, #0xcd8]
    // 0xd2fd38: cmp             w1, w16
    // 0xd2fd3c: b.ne            #0xd2fd84
    // 0xd2fd40: LoadField: r0 = r5->field_43
    //     0xd2fd40: ldur            w0, [x5, #0x43]
    // 0xd2fd44: DecompressPointer r0
    //     0xd2fd44: add             x0, x0, HEAP, lsl #32
    // 0xd2fd48: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd2fd4c: cmp             w0, w16
    // 0xd2fd50: b.eq            #0xd2ff94
    // 0xd2fd54: LoadField: r1 = r0->field_f
    //     0xd2fd54: ldur            w1, [x0, #0xf]
    // 0xd2fd58: DecompressPointer r1
    //     0xd2fd58: add             x1, x1, HEAP, lsl #32
    // 0xd2fd5c: LoadField: r2 = r0->field_b
    //     0xd2fd5c: ldur            w2, [x0, #0xb]
    // 0xd2fd60: DecompressPointer r2
    //     0xd2fd60: add             x2, x2, HEAP, lsl #32
    // 0xd2fd64: r0 = LoadClassIdInstr(r1)
    //     0xd2fd64: ldur            x0, [x1, #-1]
    //     0xd2fd68: ubfx            x0, x0, #0xc, #0x14
    // 0xd2fd6c: r0 = GDT[cid_x0 + 0x80ed]()
    //     0xd2fd6c: mov             x17, #0x80ed
    //     0xd2fd70: add             lr, x0, x17
    //     0xd2fd74: ldr             lr, [x21, lr, lsl #3]
    //     0xd2fd78: blr             lr
    // 0xd2fd7c: mov             x3, x0
    // 0xd2fd80: b               #0xd2fe2c
    // 0xd2fd84: LoadField: r0 = r5->field_43
    //     0xd2fd84: ldur            w0, [x5, #0x43]
    // 0xd2fd88: DecompressPointer r0
    //     0xd2fd88: add             x0, x0, HEAP, lsl #32
    // 0xd2fd8c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd2fd90: cmp             w0, w16
    // 0xd2fd94: b.eq            #0xd2ffa0
    // 0xd2fd98: LoadField: r1 = r0->field_f
    //     0xd2fd98: ldur            w1, [x0, #0xf]
    // 0xd2fd9c: DecompressPointer r1
    //     0xd2fd9c: add             x1, x1, HEAP, lsl #32
    // 0xd2fda0: LoadField: r2 = r0->field_b
    //     0xd2fda0: ldur            w2, [x0, #0xb]
    // 0xd2fda4: DecompressPointer r2
    //     0xd2fda4: add             x2, x2, HEAP, lsl #32
    // 0xd2fda8: r0 = LoadClassIdInstr(r1)
    //     0xd2fda8: ldur            x0, [x1, #-1]
    //     0xd2fdac: ubfx            x0, x0, #0xc, #0x14
    // 0xd2fdb0: r0 = GDT[cid_x0 + 0x80ed]()
    //     0xd2fdb0: mov             x17, #0x80ed
    //     0xd2fdb4: add             lr, x0, x17
    //     0xd2fdb8: ldr             lr, [x21, lr, lsl #3]
    //     0xd2fdbc: blr             lr
    // 0xd2fdc0: LoadField: d0 = r0->field_7
    //     0xd2fdc0: ldur            d0, [x0, #7]
    // 0xd2fdc4: ldur            x0, [fp, #-0x10]
    // 0xd2fdc8: stur            d0, [fp, #-0x30]
    // 0xd2fdcc: LoadField: r2 = r0->field_f
    //     0xd2fdcc: ldur            w2, [x0, #0xf]
    // 0xd2fdd0: DecompressPointer r2
    //     0xd2fdd0: add             x2, x2, HEAP, lsl #32
    // 0xd2fdd4: ldr             x1, [fp, #0x18]
    // 0xd2fdd8: stur            x2, [fp, #-0x20]
    // 0xd2fddc: r0 = heightOf()
    //     0xd2fddc: bl              #0xd30414  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::heightOf
    // 0xd2fde0: ldur            x1, [fp, #-0x20]
    // 0xd2fde4: r0 = _getYShiftPosition()
    //     0xd2fde4: bl              #0xd301c0  ; [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackSharedElementPageTransitionState::_getYShiftPosition
    // 0xd2fde8: stur            d0, [fp, #-0x38]
    // 0xd2fdec: r0 = Offset()
    //     0xd2fdec: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xd2fdf0: mov             x1, x0
    // 0xd2fdf4: ldur            d0, [fp, #-0x30]
    // 0xd2fdf8: StoreField: r1->field_7 = d0
    //     0xd2fdf8: stur            d0, [x1, #7]
    // 0xd2fdfc: ldur            d0, [fp, #-0x38]
    // 0xd2fe00: StoreField: r1->field_f = d0
    //     0xd2fe00: stur            d0, [x1, #0xf]
    // 0xd2fe04: mov             x0, x1
    // 0xd2fe08: ldur            x2, [fp, #-0x18]
    // 0xd2fe0c: StoreField: r2->field_47 = r0
    //     0xd2fe0c: stur            w0, [x2, #0x47]
    //     0xd2fe10: ldurb           w16, [x2, #-1]
    //     0xd2fe14: ldurb           w17, [x0, #-1]
    //     0xd2fe18: and             x16, x17, x16, lsr #2
    //     0xd2fe1c: tst             x16, HEAP, lsr #32
    //     0xd2fe20: b.eq            #0xd2fe28
    //     0xd2fe24: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd2fe28: mov             x3, x1
    // 0xd2fe2c: ldur            x0, [fp, #-0x10]
    // 0xd2fe30: stur            x3, [fp, #-0x18]
    // 0xd2fe34: LoadField: r1 = r0->field_f
    //     0xd2fe34: ldur            w1, [x0, #0xf]
    // 0xd2fe38: DecompressPointer r1
    //     0xd2fe38: add             x1, x1, HEAP, lsl #32
    // 0xd2fe3c: LoadField: r2 = r1->field_1f
    //     0xd2fe3c: ldur            w2, [x1, #0x1f]
    // 0xd2fe40: DecompressPointer r2
    //     0xd2fe40: add             x2, x2, HEAP, lsl #32
    // 0xd2fe44: LoadField: r4 = r1->field_27
    //     0xd2fe44: ldur            w4, [x1, #0x27]
    // 0xd2fe48: DecompressPointer r4
    //     0xd2fe48: add             x4, x4, HEAP, lsl #32
    // 0xd2fe4c: mov             x1, x2
    // 0xd2fe50: mov             x2, x4
    // 0xd2fe54: r0 = evaluate()
    //     0xd2fe54: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xd2fe58: ldr             x1, [fp, #0x18]
    // 0xd2fe5c: stur            x0, [fp, #-0x20]
    // 0xd2fe60: r0 = displayCornerRadiiOf()
    //     0xd2fe60: bl              #0xd30174  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::displayCornerRadiiOf
    // 0xd2fe64: cmp             w0, NULL
    // 0xd2fe68: b.ne            #0xd2fed0
    // 0xd2fe6c: ldur            x0, [fp, #-0x10]
    // 0xd2fe70: LoadField: r1 = r0->field_f
    //     0xd2fe70: ldur            w1, [x0, #0xf]
    // 0xd2fe74: DecompressPointer r1
    //     0xd2fe74: add             x1, x1, HEAP, lsl #32
    // 0xd2fe78: LoadField: r0 = r1->field_1b
    //     0xd2fe78: ldur            w0, [x1, #0x1b]
    // 0xd2fe7c: DecompressPointer r0
    //     0xd2fe7c: add             x0, x0, HEAP, lsl #32
    // 0xd2fe80: LoadField: r2 = r1->field_2b
    //     0xd2fe80: ldur            w2, [x1, #0x2b]
    // 0xd2fe84: DecompressPointer r2
    //     0xd2fe84: add             x2, x2, HEAP, lsl #32
    // 0xd2fe88: mov             x1, x0
    // 0xd2fe8c: r0 = evaluate()
    //     0xd2fe8c: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xd2fe90: LoadField: d0 = r0->field_7
    //     0xd2fe90: ldur            d0, [x0, #7]
    // 0xd2fe94: stur            d0, [fp, #-0x30]
    // 0xd2fe98: r0 = Radius()
    //     0xd2fe98: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xd2fe9c: ldur            d0, [fp, #-0x30]
    // 0xd2fea0: stur            x0, [fp, #-0x10]
    // 0xd2fea4: StoreField: r0->field_7 = d0
    //     0xd2fea4: stur            d0, [x0, #7]
    // 0xd2fea8: StoreField: r0->field_f = d0
    //     0xd2fea8: stur            d0, [x0, #0xf]
    // 0xd2feac: r0 = BorderRadius()
    //     0xd2feac: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xd2feb0: mov             x1, x0
    // 0xd2feb4: ldur            x0, [fp, #-0x10]
    // 0xd2feb8: StoreField: r1->field_7 = r0
    //     0xd2feb8: stur            w0, [x1, #7]
    // 0xd2febc: StoreField: r1->field_b = r0
    //     0xd2febc: stur            w0, [x1, #0xb]
    // 0xd2fec0: StoreField: r1->field_f = r0
    //     0xd2fec0: stur            w0, [x1, #0xf]
    // 0xd2fec4: StoreField: r1->field_13 = r0
    //     0xd2fec4: stur            w0, [x1, #0x13]
    // 0xd2fec8: mov             x3, x1
    // 0xd2fecc: b               #0xd2fed4
    // 0xd2fed0: mov             x3, x0
    // 0xd2fed4: ldr             x2, [fp, #0x10]
    // 0xd2fed8: ldur            x1, [fp, #-8]
    // 0xd2fedc: ldur            x0, [fp, #-0x20]
    // 0xd2fee0: stur            x3, [fp, #-0x10]
    // 0xd2fee4: r0 = ClipRRect()
    //     0xd2fee4: bl              #0xd30168  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0xd2fee8: mov             x1, x0
    // 0xd2feec: ldur            x0, [fp, #-0x10]
    // 0xd2fef0: stur            x1, [fp, #-0x28]
    // 0xd2fef4: StoreField: r1->field_f = r0
    //     0xd2fef4: stur            w0, [x1, #0xf]
    // 0xd2fef8: r0 = Instance_Clip
    //     0xd2fef8: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e6f0] Obj!Clip@12c8101
    //     0xd2fefc: ldr             x0, [x0, #0x6f0]
    // 0xd2ff00: ArrayStore: r1[0] = r0  ; List_4
    //     0xd2ff00: stur            w0, [x1, #0x17]
    // 0xd2ff04: ldr             x0, [fp, #0x10]
    // 0xd2ff08: StoreField: r1->field_b = r0
    //     0xd2ff08: stur            w0, [x1, #0xb]
    // 0xd2ff0c: ldur            x0, [fp, #-0x20]
    // 0xd2ff10: LoadField: d0 = r0->field_7
    //     0xd2ff10: ldur            d0, [x0, #7]
    // 0xd2ff14: stur            d0, [fp, #-0x30]
    // 0xd2ff18: r0 = Opacity()
    //     0xd2ff18: bl              #0xd3015c  ; AllocateOpacityStub -> Opacity (size=0x1c)
    // 0xd2ff1c: ldur            d0, [fp, #-0x30]
    // 0xd2ff20: stur            x0, [fp, #-0x10]
    // 0xd2ff24: StoreField: r0->field_f = d0
    //     0xd2ff24: stur            d0, [x0, #0xf]
    // 0xd2ff28: r1 = false
    //     0xd2ff28: add             x1, NULL, #0x30  ; false
    // 0xd2ff2c: ArrayStore: r0[0] = r1  ; List_4
    //     0xd2ff2c: stur            w1, [x0, #0x17]
    // 0xd2ff30: ldur            x1, [fp, #-0x28]
    // 0xd2ff34: StoreField: r0->field_b = r1
    //     0xd2ff34: stur            w1, [x0, #0xb]
    // 0xd2ff38: r0 = Transform()
    //     0xd2ff38: bl              #0xd30150  ; AllocateTransformStub -> Transform (size=0x24)
    // 0xd2ff3c: mov             x1, x0
    // 0xd2ff40: ldur            x2, [fp, #-0x10]
    // 0xd2ff44: ldur            x3, [fp, #-0x18]
    // 0xd2ff48: stur            x0, [fp, #-0x10]
    // 0xd2ff4c: r0 = Transform.translate()
    //     0xd2ff4c: bl              #0xd300bc  ; [package:flutter/src/widgets/basic.dart] Transform::Transform.translate
    // 0xd2ff50: ldur            x0, [fp, #-8]
    // 0xd2ff54: LoadField: d0 = r0->field_7
    //     0xd2ff54: ldur            d0, [x0, #7]
    // 0xd2ff58: stur            d0, [fp, #-0x30]
    // 0xd2ff5c: r0 = Transform()
    //     0xd2ff5c: bl              #0xd30150  ; AllocateTransformStub -> Transform (size=0x24)
    // 0xd2ff60: mov             x1, x0
    // 0xd2ff64: ldur            x2, [fp, #-0x10]
    // 0xd2ff68: ldur            d0, [fp, #-0x30]
    // 0xd2ff6c: stur            x0, [fp, #-8]
    // 0xd2ff70: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xd2ff70: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xd2ff74: r0 = Transform.scale()
    //     0xd2ff74: bl              #0xd2ffac  ; [package:flutter/src/widgets/basic.dart] Transform::Transform.scale
    // 0xd2ff78: ldur            x0, [fp, #-8]
    // 0xd2ff7c: LeaveFrame
    //     0xd2ff7c: mov             SP, fp
    //     0xd2ff80: ldp             fp, lr, [SP], #0x10
    // 0xd2ff84: ret
    //     0xd2ff84: ret             
    // 0xd2ff88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd2ff88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd2ff8c: b               #0xd2fcb4
    // 0xd2ff90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2ff90: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2ff94: r9 = _positionAnimation
    //     0xd2ff94: add             x9, PP, #0xd1, lsl #12  ; [pp+0xd1d20] Field <_PredictiveBackSharedElementPageTransitionState@114428833._positionAnimation@114428833>: late (offset: 0x44)
    //     0xd2ff98: ldr             x9, [x9, #0xd20]
    // 0xd2ff9c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd2ff9c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd2ffa0: r9 = _positionAnimation
    //     0xd2ffa0: add             x9, PP, #0xd1, lsl #12  ; [pp+0xd1d20] Field <_PredictiveBackSharedElementPageTransitionState@114428833._positionAnimation@114428833>: late (offset: 0x44)
    //     0xd2ffa4: ldr             x9, [x9, #0xd20]
    // 0xd2ffa8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd2ffa8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _getYShiftPosition(/* No info */) {
    // ** addr: 0xd301c0, size: 0x254
    // 0xd301c0: EnterFrame
    //     0xd301c0: stp             fp, lr, [SP, #-0x10]!
    //     0xd301c4: mov             fp, SP
    // 0xd301c8: AllocStack(0x10)
    //     0xd301c8: sub             SP, SP, #0x10
    // 0xd301cc: CheckStackOverflow
    //     0xd301cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd301d0: cmp             SP, x16
    //     0xd301d4: b.ls            #0xd303d4
    // 0xd301d8: LoadField: r0 = r1->field_b
    //     0xd301d8: ldur            w0, [x1, #0xb]
    // 0xd301dc: DecompressPointer r0
    //     0xd301dc: add             x0, x0, HEAP, lsl #32
    // 0xd301e0: cmp             w0, NULL
    // 0xd301e4: b.eq            #0xd303dc
    // 0xd301e8: LoadField: r1 = r0->field_13
    //     0xd301e8: ldur            w1, [x0, #0x13]
    // 0xd301ec: DecompressPointer r1
    //     0xd301ec: add             x1, x1, HEAP, lsl #32
    // 0xd301f0: cmp             w1, NULL
    // 0xd301f4: b.ne            #0xd30200
    // 0xd301f8: r1 = Null
    //     0xd301f8: mov             x1, NULL
    // 0xd301fc: b               #0xd30248
    // 0xd30200: LoadField: r2 = r1->field_7
    //     0xd30200: ldur            w2, [x1, #7]
    // 0xd30204: DecompressPointer r2
    //     0xd30204: add             x2, x2, HEAP, lsl #32
    // 0xd30208: cmp             w2, NULL
    // 0xd3020c: b.ne            #0xd30218
    // 0xd30210: r1 = Null
    //     0xd30210: mov             x1, NULL
    // 0xd30214: b               #0xd30248
    // 0xd30218: LoadField: d1 = r2->field_f
    //     0xd30218: ldur            d1, [x2, #0xf]
    // 0xd3021c: r1 = inline_Allocate_Double()
    //     0xd3021c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xd30220: add             x1, x1, #0x10
    //     0xd30224: cmp             x2, x1
    //     0xd30228: b.ls            #0xd303e0
    //     0xd3022c: str             x1, [THR, #0x60]  ; THR::top
    //     0xd30230: sub             x1, x1, #0xf
    //     0xd30234: mov             x2, #0xe19c
    //     0xd30238: movk            x2, #3, lsl #16
    //     0xd3023c: stur            x2, [x1, #-1]
    // 0xd30240: dmb             ishst
    // 0xd30244: StoreField: r1->field_7 = d1
    //     0xd30244: stur            d1, [x1, #7]
    // 0xd30248: cmp             w1, NULL
    // 0xd3024c: b.ne            #0xd30258
    // 0xd30250: d1 = 0.000000
    //     0xd30250: eor             v1.16b, v1.16b, v1.16b
    // 0xd30254: b               #0xd3025c
    // 0xd30258: LoadField: d1 = r1->field_7
    //     0xd30258: ldur            d1, [x1, #7]
    // 0xd3025c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd3025c: ldur            w1, [x0, #0x17]
    // 0xd30260: DecompressPointer r1
    //     0xd30260: add             x1, x1, HEAP, lsl #32
    // 0xd30264: cmp             w1, NULL
    // 0xd30268: b.ne            #0xd30274
    // 0xd3026c: r0 = Null
    //     0xd3026c: mov             x0, NULL
    // 0xd30270: b               #0xd302bc
    // 0xd30274: LoadField: r0 = r1->field_7
    //     0xd30274: ldur            w0, [x1, #7]
    // 0xd30278: DecompressPointer r0
    //     0xd30278: add             x0, x0, HEAP, lsl #32
    // 0xd3027c: cmp             w0, NULL
    // 0xd30280: b.ne            #0xd3028c
    // 0xd30284: r0 = Null
    //     0xd30284: mov             x0, NULL
    // 0xd30288: b               #0xd302bc
    // 0xd3028c: LoadField: d2 = r0->field_f
    //     0xd3028c: ldur            d2, [x0, #0xf]
    // 0xd30290: r0 = inline_Allocate_Double()
    //     0xd30290: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd30294: add             x0, x0, #0x10
    //     0xd30298: cmp             x1, x0
    //     0xd3029c: b.ls            #0xd303fc
    //     0xd302a0: str             x0, [THR, #0x60]  ; THR::top
    //     0xd302a4: sub             x0, x0, #0xf
    //     0xd302a8: mov             x1, #0xe19c
    //     0xd302ac: movk            x1, #3, lsl #16
    //     0xd302b0: stur            x1, [x0, #-1]
    // 0xd302b4: dmb             ishst
    // 0xd302b8: StoreField: r0->field_7 = d2
    //     0xd302b8: stur            d2, [x0, #7]
    // 0xd302bc: cmp             w0, NULL
    // 0xd302c0: b.ne            #0xd302cc
    // 0xd302c4: d5 = 0.000000
    //     0xd302c4: eor             v5.16b, v5.16b, v5.16b
    // 0xd302c8: b               #0xd302d4
    // 0xd302cc: LoadField: d2 = r0->field_7
    //     0xd302cc: ldur            d2, [x0, #7]
    // 0xd302d0: mov             v5.16b, v2.16b
    // 0xd302d4: d4 = 0.000000
    //     0xd302d4: eor             v4.16b, v4.16b, v4.16b
    // 0xd302d8: d3 = 20.000000
    //     0xd302d8: fmov            d3, #20.00000000
    // 0xd302dc: d2 = 8.000000
    //     0xd302dc: fmov            d2, #8.00000000
    // 0xd302e0: fdiv            d6, d0, d3
    // 0xd302e4: fsub            d3, d6, d2
    // 0xd302e8: stur            d3, [fp, #-0x10]
    // 0xd302ec: fsub            d2, d5, d1
    // 0xd302f0: stur            d2, [fp, #-8]
    // 0xd302f4: fcmp            d2, d4
    // 0xd302f8: b.ne            #0xd30304
    // 0xd302fc: d1 = 0.000000
    //     0xd302fc: eor             v1.16b, v1.16b, v1.16b
    // 0xd30300: b               #0xd30318
    // 0xd30304: fcmp            d4, d2
    // 0xd30308: b.le            #0xd30314
    // 0xd3030c: fneg            d1, d2
    // 0xd30310: b               #0xd30318
    // 0xd30314: mov             v1.16b, v2.16b
    // 0xd30318: fdiv            d5, d1, d0
    // 0xd3031c: fcmp            d4, d5
    // 0xd30320: b.le            #0xd3032c
    // 0xd30324: d0 = 0.000000
    //     0xd30324: eor             v0.16b, v0.16b, v0.16b
    // 0xd30328: b               #0xd30354
    // 0xd3032c: d0 = 1.000000
    //     0xd3032c: fmov            d0, #1.00000000
    // 0xd30330: fcmp            d5, d0
    // 0xd30334: b.le            #0xd30340
    // 0xd30338: d0 = 1.000000
    //     0xd30338: fmov            d0, #1.00000000
    // 0xd3033c: b               #0xd30354
    // 0xd30340: fcmp            d5, d5
    // 0xd30344: b.vc            #0xd30350
    // 0xd30348: d0 = 1.000000
    //     0xd30348: fmov            d0, #1.00000000
    // 0xd3034c: b               #0xd30354
    // 0xd30350: mov             v0.16b, v5.16b
    // 0xd30354: r1 = Instance_Cubic
    //     0xd30354: add             x1, PP, #0x15, lsl #12  ; [pp+0x158f0] Obj!Cubic@129f571
    //     0xd30358: ldr             x1, [x1, #0x8f0]
    // 0xd3035c: r0 = transform()
    //     0xd3035c: bl              #0x12f4dac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0xd30360: ldur            d2, [fp, #-8]
    // 0xd30364: d1 = 0.000000
    //     0xd30364: eor             v1.16b, v1.16b, v1.16b
    // 0xd30368: fcmp            d2, d1
    // 0xd3036c: b.le            #0xd30378
    // 0xd30370: d2 = 1.000000
    //     0xd30370: fmov            d2, #1.00000000
    // 0xd30374: b               #0xd30384
    // 0xd30378: fcmp            d1, d2
    // 0xd3037c: b.le            #0xd30384
    // 0xd30380: d2 = -1.000000
    //     0xd30380: fmov            d2, #-1.00000000
    // 0xd30384: ldur            d1, [fp, #-0x10]
    // 0xd30388: fmul            d3, d0, d2
    // 0xd3038c: fmul            d2, d3, d1
    // 0xd30390: fneg            d3, d1
    // 0xd30394: fcmp            d3, d2
    // 0xd30398: b.le            #0xd303a4
    // 0xd3039c: mov             v0.16b, v3.16b
    // 0xd303a0: b               #0xd303c8
    // 0xd303a4: fcmp            d2, d1
    // 0xd303a8: b.le            #0xd303b4
    // 0xd303ac: mov             v0.16b, v1.16b
    // 0xd303b0: b               #0xd303c8
    // 0xd303b4: fcmp            d2, d2
    // 0xd303b8: b.vc            #0xd303c4
    // 0xd303bc: mov             v0.16b, v1.16b
    // 0xd303c0: b               #0xd303c8
    // 0xd303c4: mov             v0.16b, v2.16b
    // 0xd303c8: LeaveFrame
    //     0xd303c8: mov             SP, fp
    //     0xd303cc: ldp             fp, lr, [SP], #0x10
    // 0xd303d0: ret
    //     0xd303d0: ret             
    // 0xd303d4: r0 = StackOverflowSharedWithFPURegs()
    //     0xd303d4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd303d8: b               #0xd301d8
    // 0xd303dc: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd303dc: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd303e0: stp             q0, q1, [SP, #-0x20]!
    // 0xd303e4: SaveReg r0
    //     0xd303e4: str             x0, [SP, #-8]!
    // 0xd303e8: r0 = AllocateDouble()
    //     0xd303e8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd303ec: mov             x1, x0
    // 0xd303f0: RestoreReg r0
    //     0xd303f0: ldr             x0, [SP], #8
    // 0xd303f4: ldp             q0, q1, [SP], #0x20
    // 0xd303f8: b               #0xd30244
    // 0xd303fc: stp             q1, q2, [SP, #-0x20]!
    // 0xd30400: SaveReg d0
    //     0xd30400: str             q0, [SP, #-0x10]!
    // 0xd30404: r0 = AllocateDouble()
    //     0xd30404: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd30408: RestoreReg d0
    //     0xd30408: ldr             q0, [SP], #0x10
    // 0xd3040c: ldp             q1, q2, [SP], #0x20
    // 0xd30410: b               #0xd302b8
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xeeccc8, size: 0x68
    // 0xeeccc8: EnterFrame
    //     0xeeccc8: stp             fp, lr, [SP, #-0x10]!
    //     0xeecccc: mov             fp, SP
    // 0xeeccd0: AllocStack(0x8)
    //     0xeeccd0: sub             SP, SP, #8
    // 0xeeccd4: SetupParameters(_PredictiveBackSharedElementPageTransitionState this /* r1 => r0, fp-0x8 */)
    //     0xeeccd4: mov             x0, x1
    //     0xeeccd8: stur            x1, [fp, #-8]
    // 0xeeccdc: CheckStackOverflow
    //     0xeeccdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeecce0: cmp             SP, x16
    //     0xeecce4: b.ls            #0xeecd24
    // 0xeecce8: mov             x1, x0
    // 0xeeccec: r0 = _updateCurvedAnimations()
    //     0xeeccec: bl              #0xeed14c  ; [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackSharedElementPageTransitionState::_updateCurvedAnimations
    // 0xeeccf0: ldur            x0, [fp, #-8]
    // 0xeeccf4: LoadField: r1 = r0->field_f
    //     0xeeccf4: ldur            w1, [x0, #0xf]
    // 0xeeccf8: DecompressPointer r1
    //     0xeeccf8: add             x1, x1, HEAP, lsl #32
    // 0xeeccfc: cmp             w1, NULL
    // 0xeecd00: b.eq            #0xeecd2c
    // 0xeecd04: r0 = sizeOf()
    //     0xeecd04: bl              #0x865078  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::sizeOf
    // 0xeecd08: ldur            x1, [fp, #-8]
    // 0xeecd0c: mov             x2, x0
    // 0xeecd10: r0 = _updateAnimations()
    //     0xeecd10: bl              #0xeecd30  ; [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackSharedElementPageTransitionState::_updateAnimations
    // 0xeecd14: r0 = Null
    //     0xeecd14: mov             x0, NULL
    // 0xeecd18: LeaveFrame
    //     0xeecd18: mov             SP, fp
    //     0xeecd1c: ldp             fp, lr, [SP], #0x10
    // 0xeecd20: ret
    //     0xeecd20: ret             
    // 0xeecd24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeecd24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeecd28: b               #0xeecce8
    // 0xeecd2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeecd2c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateAnimations(/* No info */) {
    // ** addr: 0xeecd30, size: 0x41c
    // 0xeecd30: EnterFrame
    //     0xeecd30: stp             fp, lr, [SP, #-0x10]!
    //     0xeecd34: mov             fp, SP
    // 0xeecd38: AllocStack(0x48)
    //     0xeecd38: sub             SP, SP, #0x48
    // 0xeecd3c: SetupParameters(_PredictiveBackSharedElementPageTransitionState this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xeecd3c: mov             x3, x1
    //     0xeecd40: mov             x0, x2
    //     0xeecd44: stur            x1, [fp, #-0x10]
    //     0xeecd48: stur            x2, [fp, #-0x18]
    // 0xeecd4c: CheckStackOverflow
    //     0xeecd4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeecd50: cmp             SP, x16
    //     0xeecd54: b.ls            #0xeed118
    // 0xeecd58: LoadField: r4 = r3->field_37
    //     0xeecd58: ldur            w4, [x3, #0x37]
    // 0xeecd5c: DecompressPointer r4
    //     0xeecd5c: add             x4, x4, HEAP, lsl #32
    // 0xeecd60: stur            x4, [fp, #-8]
    // 0xeecd64: LoadField: r1 = r3->field_b
    //     0xeecd64: ldur            w1, [x3, #0xb]
    // 0xeecd68: DecompressPointer r1
    //     0xeecd68: add             x1, x1, HEAP, lsl #32
    // 0xeecd6c: cmp             w1, NULL
    // 0xeecd70: b.eq            #0xeed120
    // 0xeecd74: LoadField: r2 = r1->field_f
    //     0xeecd74: ldur            w2, [x1, #0xf]
    // 0xeecd78: DecompressPointer r2
    //     0xeecd78: add             x2, x2, HEAP, lsl #32
    // 0xeecd7c: r16 = Instance__PredictiveBackPhase
    //     0xeecd7c: add             x16, PP, #0xd1, lsl #12  ; [pp+0xd1cd8] Obj!_PredictiveBackPhase@12c52e1
    //     0xeecd80: ldr             x16, [x16, #0xcd8]
    // 0xeecd84: cmp             w2, w16
    // 0xeecd88: b.ne            #0xeecd9c
    // 0xeecd8c: LoadField: r1 = r3->field_3f
    //     0xeecd8c: ldur            w1, [x3, #0x3f]
    // 0xeecd90: DecompressPointer r1
    //     0xeecd90: add             x1, x1, HEAP, lsl #32
    // 0xeecd94: mov             x2, x1
    // 0xeecd98: b               #0xeecda4
    // 0xeecd9c: LoadField: r2 = r1->field_b
    //     0xeecd9c: ldur            w2, [x1, #0xb]
    // 0xeecda0: DecompressPointer r2
    //     0xeecda0: add             x2, x2, HEAP, lsl #32
    // 0xeecda4: mov             x1, x4
    // 0xeecda8: r0 = parent=()
    //     0xeecda8: bl              #0xb72d4c  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::parent=
    // 0xeecdac: ldur            x0, [fp, #-0x10]
    // 0xeecdb0: LoadField: r2 = r0->field_2b
    //     0xeecdb0: ldur            w2, [x0, #0x2b]
    // 0xeecdb4: DecompressPointer r2
    //     0xeecdb4: add             x2, x2, HEAP, lsl #32
    // 0xeecdb8: stur            x2, [fp, #-0x20]
    // 0xeecdbc: LoadField: r1 = r0->field_b
    //     0xeecdbc: ldur            w1, [x0, #0xb]
    // 0xeecdc0: DecompressPointer r1
    //     0xeecdc0: add             x1, x1, HEAP, lsl #32
    // 0xeecdc4: cmp             w1, NULL
    // 0xeecdc8: b.eq            #0xeed124
    // 0xeecdcc: LoadField: r3 = r1->field_f
    //     0xeecdcc: ldur            w3, [x1, #0xf]
    // 0xeecdd0: DecompressPointer r3
    //     0xeecdd0: add             x3, x3, HEAP, lsl #32
    // 0xeecdd4: r16 = Instance__PredictiveBackPhase
    //     0xeecdd4: add             x16, PP, #0xd1, lsl #12  ; [pp+0xd1cd8] Obj!_PredictiveBackPhase@12c52e1
    //     0xeecdd8: ldr             x16, [x16, #0xcd8]
    // 0xeecddc: cmp             w3, w16
    // 0xeecde0: b.ne            #0xeece54
    // 0xeecde4: LoadField: d0 = r0->field_2f
    //     0xeecde4: ldur            d0, [x0, #0x2f]
    // 0xeecde8: stur            d0, [fp, #-0x38]
    // 0xeecdec: r1 = <double>
    //     0xeecdec: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xeecdf0: r0 = Tween()
    //     0xeecdf0: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xeecdf4: mov             x1, x0
    // 0xeecdf8: r0 = 0.000000
    //     0xeecdf8: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xeecdfc: StoreField: r1->field_b = r0
    //     0xeecdfc: stur            w0, [x1, #0xb]
    // 0xeece00: ldur            d0, [fp, #-0x38]
    // 0xeece04: r0 = inline_Allocate_Double()
    //     0xeece04: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xeece08: add             x0, x0, #0x10
    //     0xeece0c: cmp             x2, x0
    //     0xeece10: b.ls            #0xeed128
    //     0xeece14: str             x0, [THR, #0x60]  ; THR::top
    //     0xeece18: sub             x0, x0, #0xf
    //     0xeece1c: mov             x2, #0xe19c
    //     0xeece20: movk            x2, #3, lsl #16
    //     0xeece24: stur            x2, [x0, #-1]
    // 0xeece28: dmb             ishst
    // 0xeece2c: StoreField: r0->field_7 = d0
    //     0xeece2c: stur            d0, [x0, #7]
    // 0xeece30: StoreField: r1->field_f = r0
    //     0xeece30: stur            w0, [x1, #0xf]
    // 0xeece34: ldur            x0, [fp, #-0x10]
    // 0xeece38: LoadField: r2 = r0->field_3b
    //     0xeece38: ldur            w2, [x0, #0x3b]
    // 0xeece3c: DecompressPointer r2
    //     0xeece3c: add             x2, x2, HEAP, lsl #32
    // 0xeece40: cmp             w2, NULL
    // 0xeece44: b.eq            #0xeed140
    // 0xeece48: r0 = animate()
    //     0xeece48: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xeece4c: mov             x2, x0
    // 0xeece50: b               #0xeecef0
    // 0xeece54: LoadField: r0 = r1->field_b
    //     0xeece54: ldur            w0, [x1, #0xb]
    // 0xeece58: DecompressPointer r0
    //     0xeece58: add             x0, x0, HEAP, lsl #32
    // 0xeece5c: stur            x0, [fp, #-0x28]
    // 0xeece60: r1 = <double>
    //     0xeece60: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xeece64: r0 = ReverseAnimation()
    //     0xeece64: bl              #0xdffa24  ; AllocateReverseAnimationStub -> ReverseAnimation (size=0x1c)
    // 0xeece68: mov             x2, x0
    // 0xeece6c: ldur            x0, [fp, #-0x28]
    // 0xeece70: stur            x2, [fp, #-0x30]
    // 0xeece74: ArrayStore: r2[0] = r0  ; List_4
    //     0xeece74: stur            w0, [x2, #0x17]
    // 0xeece78: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xeece78: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xeece7c: r0 = ObserverList()
    //     0xeece7c: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xeece80: mov             x3, x0
    // 0xeece84: r0 = false
    //     0xeece84: add             x0, NULL, #0x30  ; false
    // 0xeece88: stur            x3, [fp, #-0x28]
    // 0xeece8c: StoreField: r3->field_f = r0
    //     0xeece8c: stur            w0, [x3, #0xf]
    // 0xeece90: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xeece94: StoreField: r3->field_13 = r0
    //     0xeece94: stur            w0, [x3, #0x13]
    // 0xeece98: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xeece98: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xeece9c: r2 = 0
    //     0xeece9c: mov             x2, #0
    // 0xeecea0: r0 = _GrowableList()
    //     0xeecea0: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xeecea4: ldur            x1, [fp, #-0x28]
    // 0xeecea8: StoreField: r1->field_b = r0
    //     0xeecea8: stur            w0, [x1, #0xb]
    //     0xeeceac: ldurb           w16, [x1, #-1]
    //     0xeeceb0: ldurb           w17, [x0, #-1]
    //     0xeeceb4: and             x16, x17, x16, lsr #2
    //     0xeeceb8: tst             x16, HEAP, lsr #32
    //     0xeecebc: b.eq            #0xeecec4
    //     0xeecec0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xeecec4: mov             x0, x1
    // 0xeecec8: ldur            x1, [fp, #-0x30]
    // 0xeececc: StoreField: r1->field_13 = r0
    //     0xeececc: stur            w0, [x1, #0x13]
    //     0xeeced0: ldurb           w16, [x1, #-1]
    //     0xeeced4: ldurb           w17, [x0, #-1]
    //     0xeeced8: and             x16, x17, x16, lsr #2
    //     0xeecedc: tst             x16, HEAP, lsr #32
    //     0xeecee0: b.eq            #0xeecee8
    //     0xeecee4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xeecee8: StoreField: r1->field_b = rZR
    //     0xeecee8: stur            xzr, [x1, #0xb]
    // 0xeeceec: mov             x2, x1
    // 0xeecef0: ldur            x0, [fp, #-0x10]
    // 0xeecef4: ldur            x1, [fp, #-0x20]
    // 0xeecef8: r0 = parent=()
    //     0xeecef8: bl              #0xb72d4c  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::parent=
    // 0xeecefc: ldur            x0, [fp, #-0x10]
    // 0xeecf00: LoadField: r1 = r0->field_27
    //     0xeecf00: ldur            w1, [x0, #0x27]
    // 0xeecf04: DecompressPointer r1
    //     0xeecf04: add             x1, x1, HEAP, lsl #32
    // 0xeecf08: LoadField: r2 = r0->field_b
    //     0xeecf08: ldur            w2, [x0, #0xb]
    // 0xeecf0c: DecompressPointer r2
    //     0xeecf0c: add             x2, x2, HEAP, lsl #32
    // 0xeecf10: cmp             w2, NULL
    // 0xeecf14: b.eq            #0xeed144
    // 0xeecf18: LoadField: r3 = r2->field_f
    //     0xeecf18: ldur            w3, [x2, #0xf]
    // 0xeecf1c: DecompressPointer r3
    //     0xeecf1c: add             x3, x3, HEAP, lsl #32
    // 0xeecf20: r16 = Instance__PredictiveBackPhase
    //     0xeecf20: add             x16, PP, #0xd1, lsl #12  ; [pp+0xd1cd8] Obj!_PredictiveBackPhase@12c52e1
    //     0xeecf24: ldr             x16, [x16, #0xcd8]
    // 0xeecf28: cmp             w3, w16
    // 0xeecf2c: b.ne            #0xeecf38
    // 0xeecf30: ldur            x2, [fp, #-8]
    // 0xeecf34: b               #0xeecf40
    // 0xeecf38: r2 = Instance__AlwaysDismissedAnimation
    //     0xeecf38: add             x2, PP, #0x14, lsl #12  ; [pp+0x14e60] Obj!_AlwaysDismissedAnimation@12aa3e1
    //     0xeecf3c: ldr             x2, [x2, #0xe60]
    // 0xeecf40: ldur            x3, [fp, #-0x18]
    // 0xeecf44: r0 = parent=()
    //     0xeecf44: bl              #0xb72d4c  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::parent=
    // 0xeecf48: ldur            x0, [fp, #-0x18]
    // 0xeecf4c: LoadField: d0 = r0->field_7
    //     0xeecf4c: ldur            d0, [x0, #7]
    // 0xeecf50: d1 = 20.000000
    //     0xeecf50: fmov            d1, #20.00000000
    // 0xeecf54: fdiv            d2, d0, d1
    // 0xeecf58: d0 = 8.000000
    //     0xeecf58: fmov            d0, #8.00000000
    // 0xeecf5c: fsub            d1, d2, d0
    // 0xeecf60: ldur            x1, [fp, #-0x10]
    // 0xeecf64: stur            d1, [fp, #-0x40]
    // 0xeecf68: LoadField: r2 = r1->field_b
    //     0xeecf68: ldur            w2, [x1, #0xb]
    // 0xeecf6c: DecompressPointer r2
    //     0xeecf6c: add             x2, x2, HEAP, lsl #32
    // 0xeecf70: cmp             w2, NULL
    // 0xeecf74: b.eq            #0xeed148
    // 0xeecf78: LoadField: r3 = r2->field_f
    //     0xeecf78: ldur            w3, [x2, #0xf]
    // 0xeecf7c: DecompressPointer r3
    //     0xeecf7c: add             x3, x3, HEAP, lsl #32
    // 0xeecf80: r16 = Instance__PredictiveBackPhase
    //     0xeecf80: add             x16, PP, #0xd1, lsl #12  ; [pp+0xd1cd8] Obj!_PredictiveBackPhase@12c52e1
    //     0xeecf84: ldr             x16, [x16, #0xcd8]
    // 0xeecf88: cmp             w3, w16
    // 0xeecf8c: b.ne            #0xeecfe8
    // 0xeecf90: d0 = 0.100000
    //     0xeecf90: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xeecf94: ldr             d0, [x17, #0x1e0]
    // 0xeecf98: LoadField: r2 = r1->field_47
    //     0xeecf98: ldur            w2, [x1, #0x47]
    // 0xeecf9c: DecompressPointer r2
    //     0xeecf9c: add             x2, x2, HEAP, lsl #32
    // 0xeecfa0: stur            x2, [fp, #-0x20]
    // 0xeecfa4: LoadField: d1 = r0->field_f
    //     0xeecfa4: ldur            d1, [x0, #0xf]
    // 0xeecfa8: fmul            d2, d1, d0
    // 0xeecfac: stur            d2, [fp, #-0x38]
    // 0xeecfb0: r0 = Offset()
    //     0xeecfb0: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xeecfb4: ldur            d0, [fp, #-0x38]
    // 0xeecfb8: stur            x0, [fp, #-0x28]
    // 0xeecfbc: StoreField: r0->field_7 = d0
    //     0xeecfbc: stur            d0, [x0, #7]
    // 0xeecfc0: StoreField: r0->field_f = rZR
    //     0xeecfc0: stur            xzr, [x0, #0xf]
    // 0xeecfc4: r1 = <Offset>
    //     0xeecfc4: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a48] TypeArguments: <Offset>
    //     0xeecfc8: ldr             x1, [x1, #0xa48]
    // 0xeecfcc: r0 = Tween()
    //     0xeecfcc: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xeecfd0: mov             x1, x0
    // 0xeecfd4: ldur            x0, [fp, #-0x20]
    // 0xeecfd8: StoreField: r1->field_b = r0
    //     0xeecfd8: stur            w0, [x1, #0xb]
    // 0xeecfdc: ldur            x0, [fp, #-0x28]
    // 0xeecfe0: StoreField: r1->field_f = r0
    //     0xeecfe0: stur            w0, [x1, #0xf]
    // 0xeecfe4: b               #0xeed0dc
    // 0xeecfe8: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xeecfe8: ldur            w1, [x2, #0x17]
    // 0xeecfec: DecompressPointer r1
    //     0xeecfec: add             x1, x1, HEAP, lsl #32
    // 0xeecff0: cmp             w1, NULL
    // 0xeecff4: b.ne            #0xeed000
    // 0xeecff8: r1 = Null
    //     0xeecff8: mov             x1, NULL
    // 0xeecffc: b               #0xeed00c
    // 0xeed000: LoadField: r2 = r1->field_13
    //     0xeed000: ldur            w2, [x1, #0x13]
    // 0xeed004: DecompressPointer r2
    //     0xeed004: add             x2, x2, HEAP, lsl #32
    // 0xeed008: mov             x1, x2
    // 0xeed00c: r16 = Instance_SwipeEdge
    //     0xeed00c: add             x16, PP, #0xd1, lsl #12  ; [pp+0xd1d30] Obj!SwipeEdge@12c3d41
    //     0xeed010: ldr             x16, [x16, #0xd30]
    // 0xeed014: cmp             w1, w16
    // 0xeed018: b.ne            #0xeed044
    // 0xeed01c: LoadField: d0 = r0->field_f
    //     0xeed01c: ldur            d0, [x0, #0xf]
    // 0xeed020: ldur            x1, [fp, #-0x10]
    // 0xeed024: r0 = _getYShiftPosition()
    //     0xeed024: bl              #0xd301c0  ; [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackSharedElementPageTransitionState::_getYShiftPosition
    // 0xeed028: stur            d0, [fp, #-0x38]
    // 0xeed02c: r0 = Offset()
    //     0xeed02c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xeed030: ldur            d1, [fp, #-0x40]
    // 0xeed034: StoreField: r0->field_7 = d1
    //     0xeed034: stur            d1, [x0, #7]
    // 0xeed038: ldur            d0, [fp, #-0x38]
    // 0xeed03c: StoreField: r0->field_f = d0
    //     0xeed03c: stur            d0, [x0, #0xf]
    // 0xeed040: b               #0xeed0b8
    // 0xeed044: r16 = Instance_SwipeEdge
    //     0xeed044: add             x16, PP, #0xd1, lsl #12  ; [pp+0xd1d38] Obj!SwipeEdge@12c3d21
    //     0xeed048: ldr             x16, [x16, #0xd38]
    // 0xeed04c: cmp             w1, w16
    // 0xeed050: b.ne            #0xeed084
    // 0xeed054: fneg            d2, d1
    // 0xeed058: stur            d2, [fp, #-0x38]
    // 0xeed05c: LoadField: d0 = r0->field_f
    //     0xeed05c: ldur            d0, [x0, #0xf]
    // 0xeed060: ldur            x1, [fp, #-0x10]
    // 0xeed064: r0 = _getYShiftPosition()
    //     0xeed064: bl              #0xd301c0  ; [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackSharedElementPageTransitionState::_getYShiftPosition
    // 0xeed068: stur            d0, [fp, #-0x48]
    // 0xeed06c: r0 = Offset()
    //     0xeed06c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xeed070: ldur            d0, [fp, #-0x38]
    // 0xeed074: StoreField: r0->field_7 = d0
    //     0xeed074: stur            d0, [x0, #7]
    // 0xeed078: ldur            d0, [fp, #-0x48]
    // 0xeed07c: StoreField: r0->field_f = d0
    //     0xeed07c: stur            d0, [x0, #0xf]
    // 0xeed080: b               #0xeed0b8
    // 0xeed084: cmp             w1, NULL
    // 0xeed088: b.ne            #0xeed0b4
    // 0xeed08c: LoadField: d0 = r0->field_f
    //     0xeed08c: ldur            d0, [x0, #0xf]
    // 0xeed090: ldur            x1, [fp, #-0x10]
    // 0xeed094: r0 = _getYShiftPosition()
    //     0xeed094: bl              #0xd301c0  ; [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackSharedElementPageTransitionState::_getYShiftPosition
    // 0xeed098: stur            d0, [fp, #-0x38]
    // 0xeed09c: r0 = Offset()
    //     0xeed09c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xeed0a0: ldur            d0, [fp, #-0x40]
    // 0xeed0a4: StoreField: r0->field_7 = d0
    //     0xeed0a4: stur            d0, [x0, #7]
    // 0xeed0a8: ldur            d0, [fp, #-0x38]
    // 0xeed0ac: StoreField: r0->field_f = d0
    //     0xeed0ac: stur            d0, [x0, #0xf]
    // 0xeed0b0: b               #0xeed0b8
    // 0xeed0b4: r0 = Null
    //     0xeed0b4: mov             x0, NULL
    // 0xeed0b8: stur            x0, [fp, #-0x18]
    // 0xeed0bc: r1 = <Offset>
    //     0xeed0bc: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a48] TypeArguments: <Offset>
    //     0xeed0c0: ldr             x1, [x1, #0xa48]
    // 0xeed0c4: r0 = Tween()
    //     0xeed0c4: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xeed0c8: mov             x1, x0
    // 0xeed0cc: ldur            x0, [fp, #-0x18]
    // 0xeed0d0: StoreField: r1->field_b = r0
    //     0xeed0d0: stur            w0, [x1, #0xb]
    // 0xeed0d4: r0 = Instance_Offset
    //     0xeed0d4: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xeed0d8: StoreField: r1->field_f = r0
    //     0xeed0d8: stur            w0, [x1, #0xf]
    // 0xeed0dc: ldur            x0, [fp, #-0x10]
    // 0xeed0e0: ldur            x2, [fp, #-8]
    // 0xeed0e4: r0 = animate()
    //     0xeed0e4: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xeed0e8: ldur            x1, [fp, #-0x10]
    // 0xeed0ec: StoreField: r1->field_43 = r0
    //     0xeed0ec: stur            w0, [x1, #0x43]
    //     0xeed0f0: ldurb           w16, [x1, #-1]
    //     0xeed0f4: ldurb           w17, [x0, #-1]
    //     0xeed0f8: and             x16, x17, x16, lsr #2
    //     0xeed0fc: tst             x16, HEAP, lsr #32
    //     0xeed100: b.eq            #0xeed108
    //     0xeed104: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xeed108: r0 = Null
    //     0xeed108: mov             x0, NULL
    // 0xeed10c: LeaveFrame
    //     0xeed10c: mov             SP, fp
    //     0xeed110: ldp             fp, lr, [SP], #0x10
    // 0xeed114: ret
    //     0xeed114: ret             
    // 0xeed118: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeed118: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeed11c: b               #0xeecd58
    // 0xeed120: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeed120: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xeed124: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeed124: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xeed128: SaveReg d0
    //     0xeed128: str             q0, [SP, #-0x10]!
    // 0xeed12c: SaveReg r1
    //     0xeed12c: str             x1, [SP, #-8]!
    // 0xeed130: r0 = AllocateDouble()
    //     0xeed130: bl              #0x13df878  ; AllocateDoubleStub
    // 0xeed134: RestoreReg r1
    //     0xeed134: ldr             x1, [SP], #8
    // 0xeed138: RestoreReg d0
    //     0xeed138: ldr             q0, [SP], #0x10
    // 0xeed13c: b               #0xeece2c
    // 0xeed140: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeed140: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xeed144: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeed144: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xeed148: r0 = NullCastErrorSharedWithFPURegs()
    //     0xeed148: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _updateCurvedAnimations(/* No info */) {
    // ** addr: 0xeed14c, size: 0x1c4
    // 0xeed14c: EnterFrame
    //     0xeed14c: stp             fp, lr, [SP, #-0x10]!
    //     0xeed150: mov             fp, SP
    // 0xeed154: AllocStack(0x18)
    //     0xeed154: sub             SP, SP, #0x18
    // 0xeed158: SetupParameters(_PredictiveBackSharedElementPageTransitionState this /* r1 => r0, fp-0x8 */)
    //     0xeed158: mov             x0, x1
    //     0xeed15c: stur            x1, [fp, #-8]
    // 0xeed160: CheckStackOverflow
    //     0xeed160: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeed164: cmp             SP, x16
    //     0xeed168: b.ls            #0xeed300
    // 0xeed16c: LoadField: r1 = r0->field_3b
    //     0xeed16c: ldur            w1, [x0, #0x3b]
    // 0xeed170: DecompressPointer r1
    //     0xeed170: add             x1, x1, HEAP, lsl #32
    // 0xeed174: cmp             w1, NULL
    // 0xeed178: b.eq            #0xeed184
    // 0xeed17c: r0 = dispose()
    //     0xeed17c: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xeed180: ldur            x0, [fp, #-8]
    // 0xeed184: LoadField: r1 = r0->field_3f
    //     0xeed184: ldur            w1, [x0, #0x3f]
    // 0xeed188: DecompressPointer r1
    //     0xeed188: add             x1, x1, HEAP, lsl #32
    // 0xeed18c: cmp             w1, NULL
    // 0xeed190: b.eq            #0xeed19c
    // 0xeed194: r0 = dispose()
    //     0xeed194: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xeed198: ldur            x0, [fp, #-8]
    // 0xeed19c: LoadField: r1 = r0->field_b
    //     0xeed19c: ldur            w1, [x0, #0xb]
    // 0xeed1a0: DecompressPointer r1
    //     0xeed1a0: add             x1, x1, HEAP, lsl #32
    // 0xeed1a4: cmp             w1, NULL
    // 0xeed1a8: b.eq            #0xeed308
    // 0xeed1ac: LoadField: r3 = r1->field_b
    //     0xeed1ac: ldur            w3, [x1, #0xb]
    // 0xeed1b0: DecompressPointer r3
    //     0xeed1b0: add             x3, x3, HEAP, lsl #32
    // 0xeed1b4: stur            x3, [fp, #-0x10]
    // 0xeed1b8: r1 = <double>
    //     0xeed1b8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xeed1bc: r0 = CurvedAnimation()
    //     0xeed1bc: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xeed1c0: mov             x1, x0
    // 0xeed1c4: ldur            x3, [fp, #-0x10]
    // 0xeed1c8: r2 = Instance_Interval
    //     0xeed1c8: add             x2, PP, #0xd1, lsl #12  ; [pp+0xd1d40] Obj!Interval@129fab1
    //     0xeed1cc: ldr             x2, [x2, #0xd40]
    // 0xeed1d0: stur            x0, [fp, #-0x10]
    // 0xeed1d4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xeed1d4: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xeed1d8: r0 = CurvedAnimation()
    //     0xeed1d8: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xeed1dc: ldur            x0, [fp, #-0x10]
    // 0xeed1e0: ldur            x2, [fp, #-8]
    // 0xeed1e4: StoreField: r2->field_3b = r0
    //     0xeed1e4: stur            w0, [x2, #0x3b]
    //     0xeed1e8: ldurb           w16, [x2, #-1]
    //     0xeed1ec: ldurb           w17, [x0, #-1]
    //     0xeed1f0: and             x16, x17, x16, lsr #2
    //     0xeed1f4: tst             x16, HEAP, lsr #32
    //     0xeed1f8: b.eq            #0xeed200
    //     0xeed1fc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xeed200: LoadField: r0 = r2->field_b
    //     0xeed200: ldur            w0, [x2, #0xb]
    // 0xeed204: DecompressPointer r0
    //     0xeed204: add             x0, x0, HEAP, lsl #32
    // 0xeed208: cmp             w0, NULL
    // 0xeed20c: b.eq            #0xeed30c
    // 0xeed210: LoadField: r3 = r0->field_b
    //     0xeed210: ldur            w3, [x0, #0xb]
    // 0xeed214: DecompressPointer r3
    //     0xeed214: add             x3, x3, HEAP, lsl #32
    // 0xeed218: stur            x3, [fp, #-0x10]
    // 0xeed21c: r1 = <double>
    //     0xeed21c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xeed220: r0 = ReverseAnimation()
    //     0xeed220: bl              #0xdffa24  ; AllocateReverseAnimationStub -> ReverseAnimation (size=0x1c)
    // 0xeed224: mov             x2, x0
    // 0xeed228: ldur            x0, [fp, #-0x10]
    // 0xeed22c: stur            x2, [fp, #-0x18]
    // 0xeed230: ArrayStore: r2[0] = r0  ; List_4
    //     0xeed230: stur            w0, [x2, #0x17]
    // 0xeed234: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xeed234: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xeed238: r0 = ObserverList()
    //     0xeed238: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xeed23c: mov             x3, x0
    // 0xeed240: r0 = false
    //     0xeed240: add             x0, NULL, #0x30  ; false
    // 0xeed244: stur            x3, [fp, #-0x10]
    // 0xeed248: StoreField: r3->field_f = r0
    //     0xeed248: stur            w0, [x3, #0xf]
    // 0xeed24c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xeed250: StoreField: r3->field_13 = r0
    //     0xeed250: stur            w0, [x3, #0x13]
    // 0xeed254: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xeed254: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xeed258: r2 = 0
    //     0xeed258: mov             x2, #0
    // 0xeed25c: r0 = _GrowableList()
    //     0xeed25c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xeed260: ldur            x1, [fp, #-0x10]
    // 0xeed264: StoreField: r1->field_b = r0
    //     0xeed264: stur            w0, [x1, #0xb]
    //     0xeed268: ldurb           w16, [x1, #-1]
    //     0xeed26c: ldurb           w17, [x0, #-1]
    //     0xeed270: and             x16, x17, x16, lsr #2
    //     0xeed274: tst             x16, HEAP, lsr #32
    //     0xeed278: b.eq            #0xeed280
    //     0xeed27c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xeed280: mov             x0, x1
    // 0xeed284: ldur            x3, [fp, #-0x18]
    // 0xeed288: StoreField: r3->field_13 = r0
    //     0xeed288: stur            w0, [x3, #0x13]
    //     0xeed28c: ldurb           w16, [x3, #-1]
    //     0xeed290: ldurb           w17, [x0, #-1]
    //     0xeed294: and             x16, x17, x16, lsr #2
    //     0xeed298: tst             x16, HEAP, lsr #32
    //     0xeed29c: b.eq            #0xeed2a4
    //     0xeed2a0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xeed2a4: StoreField: r3->field_b = rZR
    //     0xeed2a4: stur            xzr, [x3, #0xb]
    // 0xeed2a8: r1 = <double>
    //     0xeed2a8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xeed2ac: r0 = CurvedAnimation()
    //     0xeed2ac: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xeed2b0: mov             x1, x0
    // 0xeed2b4: ldur            x3, [fp, #-0x18]
    // 0xeed2b8: r2 = Instance_Interval
    //     0xeed2b8: add             x2, PP, #0xd1, lsl #12  ; [pp+0xd1d40] Obj!Interval@129fab1
    //     0xeed2bc: ldr             x2, [x2, #0xd40]
    // 0xeed2c0: stur            x0, [fp, #-0x10]
    // 0xeed2c4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xeed2c4: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xeed2c8: r0 = CurvedAnimation()
    //     0xeed2c8: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xeed2cc: ldur            x0, [fp, #-0x10]
    // 0xeed2d0: ldur            x1, [fp, #-8]
    // 0xeed2d4: StoreField: r1->field_3f = r0
    //     0xeed2d4: stur            w0, [x1, #0x3f]
    //     0xeed2d8: ldurb           w16, [x1, #-1]
    //     0xeed2dc: ldurb           w17, [x0, #-1]
    //     0xeed2e0: and             x16, x17, x16, lsr #2
    //     0xeed2e4: tst             x16, HEAP, lsr #32
    //     0xeed2e8: b.eq            #0xeed2f0
    //     0xeed2ec: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xeed2f0: r0 = Null
    //     0xeed2f0: mov             x0, NULL
    // 0xeed2f4: LeaveFrame
    //     0xeed2f4: mov             SP, fp
    //     0xeed2f8: ldp             fp, lr, [SP], #0x10
    // 0xeed2fc: ret
    //     0xeed2fc: ret             
    // 0xeed300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeed300: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeed304: b               #0xeed16c
    // 0xeed308: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeed308: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xeed30c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeed30c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf3ba54, size: 0x15c
    // 0xf3ba54: EnterFrame
    //     0xf3ba54: stp             fp, lr, [SP, #-0x10]!
    //     0xf3ba58: mov             fp, SP
    // 0xf3ba5c: AllocStack(0x10)
    //     0xf3ba5c: sub             SP, SP, #0x10
    // 0xf3ba60: SetupParameters(_PredictiveBackSharedElementPageTransitionState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf3ba60: mov             x4, x1
    //     0xf3ba64: mov             x3, x2
    //     0xf3ba68: stur            x1, [fp, #-8]
    //     0xf3ba6c: stur            x2, [fp, #-0x10]
    // 0xf3ba70: CheckStackOverflow
    //     0xf3ba70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3ba74: cmp             SP, x16
    //     0xf3ba78: b.ls            #0xf3bb9c
    // 0xf3ba7c: mov             x0, x3
    // 0xf3ba80: r2 = Null
    //     0xf3ba80: mov             x2, NULL
    // 0xf3ba84: r1 = Null
    //     0xf3ba84: mov             x1, NULL
    // 0xf3ba88: r4 = 60
    //     0xf3ba88: mov             x4, #0x3c
    // 0xf3ba8c: branchIfSmi(r0, 0xf3ba98)
    //     0xf3ba8c: tbz             w0, #0, #0xf3ba98
    // 0xf3ba90: r4 = LoadClassIdInstr(r0)
    //     0xf3ba90: ldur            x4, [x0, #-1]
    //     0xf3ba94: ubfx            x4, x4, #0xc, #0x14
    // 0xf3ba98: r17 = 6448
    //     0xf3ba98: mov             x17, #0x1930
    // 0xf3ba9c: cmp             x4, x17
    // 0xf3baa0: b.eq            #0xf3bab8
    // 0xf3baa4: r8 = _PredictiveBackSharedElementPageTransition
    //     0xf3baa4: add             x8, PP, #0xd1, lsl #12  ; [pp+0xd1d48] Type: _PredictiveBackSharedElementPageTransition
    //     0xf3baa8: ldr             x8, [x8, #0xd48]
    // 0xf3baac: r3 = Null
    //     0xf3baac: add             x3, PP, #0xd1, lsl #12  ; [pp+0xd1d50] Null
    //     0xf3bab0: ldr             x3, [x3, #0xd50]
    // 0xf3bab4: r0 = _PredictiveBackSharedElementPageTransition()
    //     0xf3bab4: bl              #0xd055bc  ; IsType__PredictiveBackSharedElementPageTransition_Stub
    // 0xf3bab8: ldur            x3, [fp, #-8]
    // 0xf3babc: LoadField: r2 = r3->field_7
    //     0xf3babc: ldur            w2, [x3, #7]
    // 0xf3bac0: DecompressPointer r2
    //     0xf3bac0: add             x2, x2, HEAP, lsl #32
    // 0xf3bac4: ldur            x0, [fp, #-0x10]
    // 0xf3bac8: r1 = Null
    //     0xf3bac8: mov             x1, NULL
    // 0xf3bacc: cmp             w2, NULL
    // 0xf3bad0: b.eq            #0xf3baf4
    // 0xf3bad4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf3bad4: ldur            w4, [x2, #0x17]
    // 0xf3bad8: DecompressPointer r4
    //     0xf3bad8: add             x4, x4, HEAP, lsl #32
    // 0xf3badc: r8 = X0 bound StatefulWidget
    //     0xf3badc: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf3bae0: ldr             x8, [x8, #0x498]
    // 0xf3bae4: LoadField: r9 = r4->field_7
    //     0xf3bae4: ldur            x9, [x4, #7]
    // 0xf3bae8: r3 = Null
    //     0xf3bae8: add             x3, PP, #0xd1, lsl #12  ; [pp+0xd1d60] Null
    //     0xf3baec: ldr             x3, [x3, #0xd60]
    // 0xf3baf0: blr             x9
    // 0xf3baf4: ldur            x0, [fp, #-8]
    // 0xf3baf8: LoadField: r1 = r0->field_b
    //     0xf3baf8: ldur            w1, [x0, #0xb]
    // 0xf3bafc: DecompressPointer r1
    //     0xf3bafc: add             x1, x1, HEAP, lsl #32
    // 0xf3bb00: cmp             w1, NULL
    // 0xf3bb04: b.eq            #0xf3bba4
    // 0xf3bb08: LoadField: r2 = r1->field_b
    //     0xf3bb08: ldur            w2, [x1, #0xb]
    // 0xf3bb0c: DecompressPointer r2
    //     0xf3bb0c: add             x2, x2, HEAP, lsl #32
    // 0xf3bb10: ldur            x3, [fp, #-0x10]
    // 0xf3bb14: LoadField: r1 = r3->field_b
    //     0xf3bb14: ldur            w1, [x3, #0xb]
    // 0xf3bb18: DecompressPointer r1
    //     0xf3bb18: add             x1, x1, HEAP, lsl #32
    // 0xf3bb1c: cmp             w2, w1
    // 0xf3bb20: b.eq            #0xf3bb2c
    // 0xf3bb24: mov             x1, x0
    // 0xf3bb28: r0 = _updateCurvedAnimations()
    //     0xf3bb28: bl              #0xeed14c  ; [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackSharedElementPageTransitionState::_updateCurvedAnimations
    // 0xf3bb2c: ldur            x0, [fp, #-8]
    // 0xf3bb30: ldur            x1, [fp, #-0x10]
    // 0xf3bb34: LoadField: r2 = r0->field_b
    //     0xf3bb34: ldur            w2, [x0, #0xb]
    // 0xf3bb38: DecompressPointer r2
    //     0xf3bb38: add             x2, x2, HEAP, lsl #32
    // 0xf3bb3c: cmp             w2, NULL
    // 0xf3bb40: b.eq            #0xf3bba8
    // 0xf3bb44: LoadField: r3 = r2->field_f
    //     0xf3bb44: ldur            w3, [x2, #0xf]
    // 0xf3bb48: DecompressPointer r3
    //     0xf3bb48: add             x3, x3, HEAP, lsl #32
    // 0xf3bb4c: LoadField: r2 = r1->field_f
    //     0xf3bb4c: ldur            w2, [x1, #0xf]
    // 0xf3bb50: DecompressPointer r2
    //     0xf3bb50: add             x2, x2, HEAP, lsl #32
    // 0xf3bb54: cmp             w3, w2
    // 0xf3bb58: b.eq            #0xf3bb8c
    // 0xf3bb5c: r16 = Instance__PredictiveBackPhase
    //     0xf3bb5c: add             x16, PP, #0xd1, lsl #12  ; [pp+0xd1cd8] Obj!_PredictiveBackPhase@12c52e1
    //     0xf3bb60: ldr             x16, [x16, #0xcd8]
    // 0xf3bb64: cmp             w3, w16
    // 0xf3bb68: b.ne            #0xf3bb8c
    // 0xf3bb6c: LoadField: r1 = r0->field_f
    //     0xf3bb6c: ldur            w1, [x0, #0xf]
    // 0xf3bb70: DecompressPointer r1
    //     0xf3bb70: add             x1, x1, HEAP, lsl #32
    // 0xf3bb74: cmp             w1, NULL
    // 0xf3bb78: b.eq            #0xf3bbac
    // 0xf3bb7c: r0 = sizeOf()
    //     0xf3bb7c: bl              #0x865078  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::sizeOf
    // 0xf3bb80: ldur            x1, [fp, #-8]
    // 0xf3bb84: mov             x2, x0
    // 0xf3bb88: r0 = _updateAnimations()
    //     0xf3bb88: bl              #0xeecd30  ; [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackSharedElementPageTransitionState::_updateAnimations
    // 0xf3bb8c: r0 = Null
    //     0xf3bb8c: mov             x0, NULL
    // 0xf3bb90: LeaveFrame
    //     0xf3bb90: mov             SP, fp
    //     0xf3bb94: ldp             fp, lr, [SP], #0x10
    // 0xf3bb98: ret
    //     0xf3bb98: ret             
    // 0xf3bb9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3bb9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3bba0: b               #0xf3ba7c
    // 0xf3bba4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3bba4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3bba8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3bba8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3bbac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3bbac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _PredictiveBackSharedElementPageTransitionState(/* No info */) {
    // ** addr: 0xfa2434, size: 0x1b8
    // 0xfa2434: EnterFrame
    //     0xfa2434: stp             fp, lr, [SP, #-0x10]!
    //     0xfa2438: mov             fp, SP
    // 0xfa243c: AllocStack(0x10)
    //     0xfa243c: sub             SP, SP, #0x10
    // 0xfa2440: ldr             x2, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa2444: r0 = Instance_Offset
    //     0xfa2444: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xfa2448: mov             x3, x1
    // 0xfa244c: stur            x1, [fp, #-8]
    // 0xfa2450: CheckStackOverflow
    //     0xfa2450: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa2454: cmp             SP, x16
    //     0xfa2458: b.ls            #0xfa25e4
    // 0xfa245c: StoreField: r3->field_2f = rZR
    //     0xfa245c: stur            xzr, [x3, #0x2f]
    // 0xfa2460: StoreField: r3->field_43 = r2
    //     0xfa2460: stur            w2, [x3, #0x43]
    // 0xfa2464: StoreField: r3->field_47 = r0
    //     0xfa2464: stur            w0, [x3, #0x47]
    // 0xfa2468: r1 = <double>
    //     0xfa2468: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfa246c: r0 = Tween()
    //     0xfa246c: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xfa2470: r2 = 0.000000
    //     0xfa2470: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfa2474: StoreField: r0->field_b = r2
    //     0xfa2474: stur            w2, [x0, #0xb]
    // 0xfa2478: r1 = 32.000000
    //     0xfa2478: add             x1, PP, #0x7b, lsl #12  ; [pp+0x7b0a0] 32
    //     0xfa247c: ldr             x1, [x1, #0xa0]
    // 0xfa2480: StoreField: r0->field_f = r1
    //     0xfa2480: stur            w1, [x0, #0xf]
    // 0xfa2484: ldur            x3, [fp, #-8]
    // 0xfa2488: StoreField: r3->field_1b = r0
    //     0xfa2488: stur            w0, [x3, #0x1b]
    //     0xfa248c: ldurb           w16, [x3, #-1]
    //     0xfa2490: ldurb           w17, [x0, #-1]
    //     0xfa2494: and             x16, x17, x16, lsr #2
    //     0xfa2498: tst             x16, HEAP, lsr #32
    //     0xfa249c: b.eq            #0xfa24a4
    //     0xfa24a0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xfa24a4: r1 = <double>
    //     0xfa24a4: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfa24a8: r0 = Tween()
    //     0xfa24a8: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xfa24ac: r2 = 1.000000
    //     0xfa24ac: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xfa24b0: StoreField: r0->field_b = r2
    //     0xfa24b0: stur            w2, [x0, #0xb]
    // 0xfa24b4: r1 = 0.000000
    //     0xfa24b4: ldr             x1, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfa24b8: StoreField: r0->field_f = r1
    //     0xfa24b8: stur            w1, [x0, #0xf]
    // 0xfa24bc: ldur            x3, [fp, #-8]
    // 0xfa24c0: StoreField: r3->field_1f = r0
    //     0xfa24c0: stur            w0, [x3, #0x1f]
    //     0xfa24c4: ldurb           w16, [x3, #-1]
    //     0xfa24c8: ldurb           w17, [x0, #-1]
    //     0xfa24cc: and             x16, x17, x16, lsr #2
    //     0xfa24d0: tst             x16, HEAP, lsr #32
    //     0xfa24d4: b.eq            #0xfa24dc
    //     0xfa24d8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xfa24dc: r1 = <double>
    //     0xfa24dc: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfa24e0: r0 = Tween()
    //     0xfa24e0: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xfa24e4: mov             x1, x0
    // 0xfa24e8: r0 = 1.000000
    //     0xfa24e8: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xfa24ec: StoreField: r1->field_b = r0
    //     0xfa24ec: stur            w0, [x1, #0xb]
    // 0xfa24f0: r0 = 0.900000
    //     0xfa24f0: add             x0, PP, #0xac, lsl #12  ; [pp+0xac188] 0.9
    //     0xfa24f4: ldr             x0, [x0, #0x188]
    // 0xfa24f8: StoreField: r1->field_f = r0
    //     0xfa24f8: stur            w0, [x1, #0xf]
    // 0xfa24fc: mov             x0, x1
    // 0xfa2500: ldur            x2, [fp, #-8]
    // 0xfa2504: StoreField: r2->field_23 = r0
    //     0xfa2504: stur            w0, [x2, #0x23]
    //     0xfa2508: ldurb           w16, [x2, #-1]
    //     0xfa250c: ldurb           w17, [x0, #-1]
    //     0xfa2510: and             x16, x17, x16, lsr #2
    //     0xfa2514: tst             x16, HEAP, lsr #32
    //     0xfa2518: b.eq            #0xfa2520
    //     0xfa251c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfa2520: r1 = <double>
    //     0xfa2520: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfa2524: r0 = ProxyAnimation()
    //     0xfa2524: bl              #0x8e0ba8  ; AllocateProxyAnimationStub -> ProxyAnimation (size=0x28)
    // 0xfa2528: mov             x1, x0
    // 0xfa252c: stur            x0, [fp, #-0x10]
    // 0xfa2530: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xfa2530: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xfa2534: r0 = ProxyAnimation()
    //     0xfa2534: bl              #0x8e09cc  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::ProxyAnimation
    // 0xfa2538: ldur            x0, [fp, #-0x10]
    // 0xfa253c: ldur            x2, [fp, #-8]
    // 0xfa2540: StoreField: r2->field_27 = r0
    //     0xfa2540: stur            w0, [x2, #0x27]
    //     0xfa2544: ldurb           w16, [x2, #-1]
    //     0xfa2548: ldurb           w17, [x0, #-1]
    //     0xfa254c: and             x16, x17, x16, lsr #2
    //     0xfa2550: tst             x16, HEAP, lsr #32
    //     0xfa2554: b.eq            #0xfa255c
    //     0xfa2558: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfa255c: r1 = <double>
    //     0xfa255c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfa2560: r0 = ProxyAnimation()
    //     0xfa2560: bl              #0x8e0ba8  ; AllocateProxyAnimationStub -> ProxyAnimation (size=0x28)
    // 0xfa2564: mov             x1, x0
    // 0xfa2568: stur            x0, [fp, #-0x10]
    // 0xfa256c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xfa256c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xfa2570: r0 = ProxyAnimation()
    //     0xfa2570: bl              #0x8e09cc  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::ProxyAnimation
    // 0xfa2574: ldur            x0, [fp, #-0x10]
    // 0xfa2578: ldur            x2, [fp, #-8]
    // 0xfa257c: StoreField: r2->field_2b = r0
    //     0xfa257c: stur            w0, [x2, #0x2b]
    //     0xfa2580: ldurb           w16, [x2, #-1]
    //     0xfa2584: ldurb           w17, [x0, #-1]
    //     0xfa2588: and             x16, x17, x16, lsr #2
    //     0xfa258c: tst             x16, HEAP, lsr #32
    //     0xfa2590: b.eq            #0xfa2598
    //     0xfa2594: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfa2598: r1 = <double>
    //     0xfa2598: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfa259c: r0 = ProxyAnimation()
    //     0xfa259c: bl              #0x8e0ba8  ; AllocateProxyAnimationStub -> ProxyAnimation (size=0x28)
    // 0xfa25a0: mov             x1, x0
    // 0xfa25a4: stur            x0, [fp, #-0x10]
    // 0xfa25a8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xfa25a8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xfa25ac: r0 = ProxyAnimation()
    //     0xfa25ac: bl              #0x8e09cc  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::ProxyAnimation
    // 0xfa25b0: ldur            x0, [fp, #-0x10]
    // 0xfa25b4: ldur            x1, [fp, #-8]
    // 0xfa25b8: StoreField: r1->field_37 = r0
    //     0xfa25b8: stur            w0, [x1, #0x37]
    //     0xfa25bc: ldurb           w16, [x1, #-1]
    //     0xfa25c0: ldurb           w17, [x0, #-1]
    //     0xfa25c4: and             x16, x17, x16, lsr #2
    //     0xfa25c8: tst             x16, HEAP, lsr #32
    //     0xfa25cc: b.eq            #0xfa25d4
    //     0xfa25d0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa25d4: r0 = Null
    //     0xfa25d4: mov             x0, NULL
    // 0xfa25d8: LeaveFrame
    //     0xfa25d8: mov             SP, fp
    //     0xfa25dc: ldp             fp, lr, [SP], #0x10
    // 0xfa25e0: ret
    //     0xfa25e0: ret             
    // 0xfa25e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa25e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa25e8: b               #0xfa245c
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10dd598, size: 0x74
    // 0x10dd598: EnterFrame
    //     0x10dd598: stp             fp, lr, [SP, #-0x10]!
    //     0x10dd59c: mov             fp, SP
    // 0x10dd5a0: AllocStack(0x8)
    //     0x10dd5a0: sub             SP, SP, #8
    // 0x10dd5a4: SetupParameters(_PredictiveBackSharedElementPageTransitionState this /* r1 => r0, fp-0x8 */)
    //     0x10dd5a4: mov             x0, x1
    //     0x10dd5a8: stur            x1, [fp, #-8]
    // 0x10dd5ac: CheckStackOverflow
    //     0x10dd5ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10dd5b0: cmp             SP, x16
    //     0x10dd5b4: b.ls            #0x10dd5fc
    // 0x10dd5b8: LoadField: r1 = r0->field_3b
    //     0x10dd5b8: ldur            w1, [x0, #0x3b]
    // 0x10dd5bc: DecompressPointer r1
    //     0x10dd5bc: add             x1, x1, HEAP, lsl #32
    // 0x10dd5c0: cmp             w1, NULL
    // 0x10dd5c4: b.eq            #0x10dd604
    // 0x10dd5c8: r0 = dispose()
    //     0x10dd5c8: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0x10dd5cc: ldur            x0, [fp, #-8]
    // 0x10dd5d0: LoadField: r1 = r0->field_3f
    //     0x10dd5d0: ldur            w1, [x0, #0x3f]
    // 0x10dd5d4: DecompressPointer r1
    //     0x10dd5d4: add             x1, x1, HEAP, lsl #32
    // 0x10dd5d8: cmp             w1, NULL
    // 0x10dd5dc: b.eq            #0x10dd608
    // 0x10dd5e0: r0 = dispose()
    //     0x10dd5e0: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0x10dd5e4: ldur            x1, [fp, #-8]
    // 0x10dd5e8: r0 = dispose()
    //     0x10dd5e8: bl              #0x10dd60c  ; [dart:mixin_deduplication] _MixinApplication90&State&SingleTickerProviderStateMixin::dispose
    // 0x10dd5ec: r0 = Null
    //     0x10dd5ec: mov             x0, NULL
    // 0x10dd5f0: LeaveFrame
    //     0x10dd5f0: mov             SP, fp
    //     0x10dd5f4: ldp             fp, lr, [SP], #0x10
    // 0x10dd5f8: ret
    //     0x10dd5f8: ret             
    // 0x10dd5fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dd5fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dd600: b               #0x10dd5b8
    // 0x10dd604: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10dd604: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10dd608: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10dd608: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5727, size: 0x20, field offset: 0x14
class _PredictiveBackGestureDetectorState extends _MixinApplication89&State&WidgetsBindingObserver {

  _ handleUpdateBackGestureProgress(/* No info */) {
    // ** addr: 0x8291f8, size: 0x98
    // 0x8291f8: EnterFrame
    //     0x8291f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8291fc: mov             fp, SP
    // 0x829200: AllocStack(0x10)
    //     0x829200: sub             SP, SP, #0x10
    // 0x829204: SetupParameters(_PredictiveBackGestureDetectorState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x829204: mov             x3, x1
    //     0x829208: mov             x0, x2
    //     0x82920c: stur            x1, [fp, #-8]
    //     0x829210: stur            x2, [fp, #-0x10]
    // 0x829214: CheckStackOverflow
    //     0x829214: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x829218: cmp             SP, x16
    //     0x82921c: b.ls            #0x829284
    // 0x829220: mov             x1, x3
    // 0x829224: r2 = Instance__PredictiveBackPhase
    //     0x829224: add             x2, PP, #0xd1, lsl #12  ; [pp+0xd1d08] Obj!_PredictiveBackPhase@12c52a1
    //     0x829228: ldr             x2, [x2, #0xd08]
    // 0x82922c: r0 = phase=()
    //     0x82922c: bl              #0x82eff8  ; [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackGestureDetectorState::phase=
    // 0x829230: ldur            x0, [fp, #-8]
    // 0x829234: LoadField: r1 = r0->field_b
    //     0x829234: ldur            w1, [x0, #0xb]
    // 0x829238: DecompressPointer r1
    //     0x829238: add             x1, x1, HEAP, lsl #32
    // 0x82923c: cmp             w1, NULL
    // 0x829240: b.eq            #0x82928c
    // 0x829244: LoadField: r2 = r1->field_f
    //     0x829244: ldur            w2, [x1, #0xf]
    // 0x829248: DecompressPointer r2
    //     0x829248: add             x2, x2, HEAP, lsl #32
    // 0x82924c: ldur            x3, [fp, #-0x10]
    // 0x829250: LoadField: d0 = r3->field_b
    //     0x829250: ldur            d0, [x3, #0xb]
    // 0x829254: d1 = 1.000000
    //     0x829254: fmov            d1, #1.00000000
    // 0x829258: fsub            d2, d1, d0
    // 0x82925c: mov             x1, x2
    // 0x829260: mov             v0.16b, v2.16b
    // 0x829264: r0 = handleUpdateBackGestureProgress()
    //     0x829264: bl              #0x829478  ; [package:flutter/src/widgets/routes.dart] TransitionRoute::handleUpdateBackGestureProgress
    // 0x829268: ldur            x1, [fp, #-8]
    // 0x82926c: ldur            x2, [fp, #-0x10]
    // 0x829270: r0 = currentBackEvent=()
    //     0x829270: bl              #0x8292dc  ; [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackGestureDetectorState::currentBackEvent=
    // 0x829274: r0 = Null
    //     0x829274: mov             x0, NULL
    // 0x829278: LeaveFrame
    //     0x829278: mov             SP, fp
    //     0x82927c: ldp             fp, lr, [SP], #0x10
    // 0x829280: ret
    //     0x829280: ret             
    // 0x829284: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x829284: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x829288: b               #0x829220
    // 0x82928c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82928c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ currentBackEvent=(/* No info */) {
    // ** addr: 0x8292dc, size: 0xb0
    // 0x8292dc: EnterFrame
    //     0x8292dc: stp             fp, lr, [SP, #-0x10]!
    //     0x8292e0: mov             fp, SP
    // 0x8292e4: AllocStack(0x28)
    //     0x8292e4: sub             SP, SP, #0x28
    // 0x8292e8: SetupParameters(_PredictiveBackGestureDetectorState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8292e8: stur            x1, [fp, #-8]
    //     0x8292ec: stur            x2, [fp, #-0x10]
    // 0x8292f0: CheckStackOverflow
    //     0x8292f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8292f4: cmp             SP, x16
    //     0x8292f8: b.ls            #0x829384
    // 0x8292fc: r1 = 2
    //     0x8292fc: mov             x1, #2
    // 0x829300: r0 = AllocateContext()
    //     0x829300: bl              #0x13de838  ; AllocateContextStub
    // 0x829304: mov             x2, x0
    // 0x829308: ldur            x1, [fp, #-8]
    // 0x82930c: stur            x2, [fp, #-0x18]
    // 0x829310: StoreField: r2->field_f = r1
    //     0x829310: stur            w1, [x2, #0xf]
    // 0x829314: ldur            x0, [fp, #-0x10]
    // 0x829318: StoreField: r2->field_13 = r0
    //     0x829318: stur            w0, [x2, #0x13]
    // 0x82931c: LoadField: r3 = r1->field_1b
    //     0x82931c: ldur            w3, [x1, #0x1b]
    // 0x829320: DecompressPointer r3
    //     0x829320: add             x3, x3, HEAP, lsl #32
    // 0x829324: r4 = LoadClassIdInstr(r3)
    //     0x829324: ldur            x4, [x3, #-1]
    //     0x829328: ubfx            x4, x4, #0xc, #0x14
    // 0x82932c: stp             x0, x3, [SP]
    // 0x829330: mov             x0, x4
    // 0x829334: mov             lr, x0
    // 0x829338: ldr             lr, [x21, lr, lsl #3]
    // 0x82933c: blr             lr
    // 0x829340: tbz             w0, #4, #0x829374
    // 0x829344: ldur            x0, [fp, #-8]
    // 0x829348: LoadField: r1 = r0->field_f
    //     0x829348: ldur            w1, [x0, #0xf]
    // 0x82934c: DecompressPointer r1
    //     0x82934c: add             x1, x1, HEAP, lsl #32
    // 0x829350: cmp             w1, NULL
    // 0x829354: b.eq            #0x829374
    // 0x829358: ldur            x2, [fp, #-0x18]
    // 0x82935c: r1 = Function '<anonymous closure>':.
    //     0x82935c: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1ce8] AnonymousClosure: (0x82942c), in [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackGestureDetectorState::currentBackEvent= (0x8292dc)
    //     0x829360: ldr             x1, [x1, #0xce8]
    // 0x829364: r0 = AllocateClosure()
    //     0x829364: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x829368: ldur            x1, [fp, #-8]
    // 0x82936c: mov             x2, x0
    // 0x829370: r0 = setState()
    //     0x829370: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x829374: r0 = Null
    //     0x829374: mov             x0, NULL
    // 0x829378: LeaveFrame
    //     0x829378: mov             SP, fp
    //     0x82937c: ldp             fp, lr, [SP], #0x10
    // 0x829380: ret
    //     0x829380: ret             
    // 0x829384: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x829384: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x829388: b               #0x8292fc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x82942c, size: 0x4c
    // 0x82942c: ldr             x1, [SP]
    // 0x829430: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x829430: ldur            w2, [x1, #0x17]
    // 0x829434: DecompressPointer r2
    //     0x829434: add             x2, x2, HEAP, lsl #32
    // 0x829438: LoadField: r1 = r2->field_f
    //     0x829438: ldur            w1, [x2, #0xf]
    // 0x82943c: DecompressPointer r1
    //     0x82943c: add             x1, x1, HEAP, lsl #32
    // 0x829440: LoadField: r3 = r2->field_13
    //     0x829440: ldur            w3, [x2, #0x13]
    // 0x829444: DecompressPointer r3
    //     0x829444: add             x3, x3, HEAP, lsl #32
    // 0x829448: mov             x0, x3
    // 0x82944c: StoreField: r1->field_1b = r0
    //     0x82944c: stur            w0, [x1, #0x1b]
    //     0x829450: ldurb           w16, [x1, #-1]
    //     0x829454: ldurb           w17, [x0, #-1]
    //     0x829458: and             x16, x17, x16, lsr #2
    //     0x82945c: tst             x16, HEAP, lsr #32
    //     0x829460: b.eq            #0x829470
    //     0x829464: str             lr, [SP, #-8]!
    //     0x829468: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0x82946c: ldr             lr, [SP], #8
    // 0x829470: mov             x0, x3
    // 0x829474: ret
    //     0x829474: ret             
  }
  set _ phase=(/* No info */) {
    // ** addr: 0x82eff8, size: 0x90
    // 0x82eff8: EnterFrame
    //     0x82eff8: stp             fp, lr, [SP, #-0x10]!
    //     0x82effc: mov             fp, SP
    // 0x82f000: AllocStack(0x10)
    //     0x82f000: sub             SP, SP, #0x10
    // 0x82f004: SetupParameters(_PredictiveBackGestureDetectorState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x82f004: stur            x1, [fp, #-8]
    //     0x82f008: stur            x2, [fp, #-0x10]
    // 0x82f00c: CheckStackOverflow
    //     0x82f00c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82f010: cmp             SP, x16
    //     0x82f014: b.ls            #0x82f080
    // 0x82f018: r1 = 2
    //     0x82f018: mov             x1, #2
    // 0x82f01c: r0 = AllocateContext()
    //     0x82f01c: bl              #0x13de838  ; AllocateContextStub
    // 0x82f020: mov             x1, x0
    // 0x82f024: ldur            x0, [fp, #-8]
    // 0x82f028: StoreField: r1->field_f = r0
    //     0x82f028: stur            w0, [x1, #0xf]
    // 0x82f02c: ldur            x2, [fp, #-0x10]
    // 0x82f030: StoreField: r1->field_13 = r2
    //     0x82f030: stur            w2, [x1, #0x13]
    // 0x82f034: LoadField: r3 = r0->field_13
    //     0x82f034: ldur            w3, [x0, #0x13]
    // 0x82f038: DecompressPointer r3
    //     0x82f038: add             x3, x3, HEAP, lsl #32
    // 0x82f03c: cmp             w3, w2
    // 0x82f040: b.eq            #0x82f070
    // 0x82f044: LoadField: r2 = r0->field_f
    //     0x82f044: ldur            w2, [x0, #0xf]
    // 0x82f048: DecompressPointer r2
    //     0x82f048: add             x2, x2, HEAP, lsl #32
    // 0x82f04c: cmp             w2, NULL
    // 0x82f050: b.eq            #0x82f070
    // 0x82f054: mov             x2, x1
    // 0x82f058: r1 = Function '<anonymous closure>':.
    //     0x82f058: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1cf8] AnonymousClosure: (0x82f088), in [package:simaster_ugm/app/modules/profile/views/profile_view.dart] _AvatarWithStoryState::_sync (0x82f0d4)
    //     0x82f05c: ldr             x1, [x1, #0xcf8]
    // 0x82f060: r0 = AllocateClosure()
    //     0x82f060: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x82f064: ldur            x1, [fp, #-8]
    // 0x82f068: mov             x2, x0
    // 0x82f06c: r0 = setState()
    //     0x82f06c: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82f070: r0 = Null
    //     0x82f070: mov             x0, NULL
    // 0x82f074: LeaveFrame
    //     0x82f074: mov             SP, fp
    //     0x82f078: ldp             fp, lr, [SP], #0x10
    // 0x82f07c: ret
    //     0x82f07c: ret             
    // 0x82f080: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82f080: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82f084: b               #0x82f018
  }
  _ handleCancelBackGesture(/* No info */) {
    // ** addr: 0x8c80c4, size: 0x88
    // 0x8c80c4: EnterFrame
    //     0x8c80c4: stp             fp, lr, [SP, #-0x10]!
    //     0x8c80c8: mov             fp, SP
    // 0x8c80cc: AllocStack(0x8)
    //     0x8c80cc: sub             SP, SP, #8
    // 0x8c80d0: SetupParameters(_PredictiveBackGestureDetectorState this /* r1 => r0, fp-0x8 */)
    //     0x8c80d0: mov             x0, x1
    //     0x8c80d4: stur            x1, [fp, #-8]
    // 0x8c80d8: CheckStackOverflow
    //     0x8c80d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c80dc: cmp             SP, x16
    //     0x8c80e0: b.ls            #0x8c8140
    // 0x8c80e4: mov             x1, x0
    // 0x8c80e8: r2 = Instance__PredictiveBackPhase
    //     0x8c80e8: add             x2, PP, #0xd1, lsl #12  ; [pp+0xd1d00] Obj!_PredictiveBackPhase@12c52c1
    //     0x8c80ec: ldr             x2, [x2, #0xd00]
    // 0x8c80f0: r0 = phase=()
    //     0x8c80f0: bl              #0x82eff8  ; [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackGestureDetectorState::phase=
    // 0x8c80f4: ldur            x0, [fp, #-8]
    // 0x8c80f8: LoadField: r1 = r0->field_b
    //     0x8c80f8: ldur            w1, [x0, #0xb]
    // 0x8c80fc: DecompressPointer r1
    //     0x8c80fc: add             x1, x1, HEAP, lsl #32
    // 0x8c8100: cmp             w1, NULL
    // 0x8c8104: b.eq            #0x8c8148
    // 0x8c8108: LoadField: r2 = r1->field_f
    //     0x8c8108: ldur            w2, [x1, #0xf]
    // 0x8c810c: DecompressPointer r2
    //     0x8c810c: add             x2, x2, HEAP, lsl #32
    // 0x8c8110: mov             x1, x2
    // 0x8c8114: r0 = handleCancelBackGesture()
    //     0x8c8114: bl              #0x8c8248  ; [package:flutter/src/widgets/routes.dart] TransitionRoute::handleCancelBackGesture
    // 0x8c8118: ldur            x1, [fp, #-8]
    // 0x8c811c: r2 = Null
    //     0x8c811c: mov             x2, NULL
    // 0x8c8120: r0 = currentBackEvent=()
    //     0x8c8120: bl              #0x8292dc  ; [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackGestureDetectorState::currentBackEvent=
    // 0x8c8124: ldur            x1, [fp, #-8]
    // 0x8c8128: r2 = Null
    //     0x8c8128: mov             x2, NULL
    // 0x8c812c: r0 = startBackEvent=()
    //     0x8c812c: bl              #0x8c814c  ; [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackGestureDetectorState::startBackEvent=
    // 0x8c8130: r0 = Null
    //     0x8c8130: mov             x0, NULL
    // 0x8c8134: LeaveFrame
    //     0x8c8134: mov             SP, fp
    //     0x8c8138: ldp             fp, lr, [SP], #0x10
    // 0x8c813c: ret
    //     0x8c813c: ret             
    // 0x8c8140: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c8140: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c8144: b               #0x8c80e4
    // 0x8c8148: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8c8148: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ startBackEvent=(/* No info */) {
    // ** addr: 0x8c814c, size: 0xb0
    // 0x8c814c: EnterFrame
    //     0x8c814c: stp             fp, lr, [SP, #-0x10]!
    //     0x8c8150: mov             fp, SP
    // 0x8c8154: AllocStack(0x28)
    //     0x8c8154: sub             SP, SP, #0x28
    // 0x8c8158: SetupParameters(_PredictiveBackGestureDetectorState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8c8158: stur            x1, [fp, #-8]
    //     0x8c815c: stur            x2, [fp, #-0x10]
    // 0x8c8160: CheckStackOverflow
    //     0x8c8160: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c8164: cmp             SP, x16
    //     0x8c8168: b.ls            #0x8c81f4
    // 0x8c816c: r1 = 2
    //     0x8c816c: mov             x1, #2
    // 0x8c8170: r0 = AllocateContext()
    //     0x8c8170: bl              #0x13de838  ; AllocateContextStub
    // 0x8c8174: mov             x2, x0
    // 0x8c8178: ldur            x1, [fp, #-8]
    // 0x8c817c: stur            x2, [fp, #-0x18]
    // 0x8c8180: StoreField: r2->field_f = r1
    //     0x8c8180: stur            w1, [x2, #0xf]
    // 0x8c8184: ldur            x0, [fp, #-0x10]
    // 0x8c8188: StoreField: r2->field_13 = r0
    //     0x8c8188: stur            w0, [x2, #0x13]
    // 0x8c818c: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x8c818c: ldur            w3, [x1, #0x17]
    // 0x8c8190: DecompressPointer r3
    //     0x8c8190: add             x3, x3, HEAP, lsl #32
    // 0x8c8194: r4 = LoadClassIdInstr(r3)
    //     0x8c8194: ldur            x4, [x3, #-1]
    //     0x8c8198: ubfx            x4, x4, #0xc, #0x14
    // 0x8c819c: stp             x0, x3, [SP]
    // 0x8c81a0: mov             x0, x4
    // 0x8c81a4: mov             lr, x0
    // 0x8c81a8: ldr             lr, [x21, lr, lsl #3]
    // 0x8c81ac: blr             lr
    // 0x8c81b0: tbz             w0, #4, #0x8c81e4
    // 0x8c81b4: ldur            x0, [fp, #-8]
    // 0x8c81b8: LoadField: r1 = r0->field_f
    //     0x8c81b8: ldur            w1, [x0, #0xf]
    // 0x8c81bc: DecompressPointer r1
    //     0x8c81bc: add             x1, x1, HEAP, lsl #32
    // 0x8c81c0: cmp             w1, NULL
    // 0x8c81c4: b.eq            #0x8c81e4
    // 0x8c81c8: ldur            x2, [fp, #-0x18]
    // 0x8c81cc: r1 = Function '<anonymous closure>':.
    //     0x8c81cc: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1ce0] AnonymousClosure: (0x8c81fc), in [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackGestureDetectorState::startBackEvent= (0x8c814c)
    //     0x8c81d0: ldr             x1, [x1, #0xce0]
    // 0x8c81d4: r0 = AllocateClosure()
    //     0x8c81d4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8c81d8: ldur            x1, [fp, #-8]
    // 0x8c81dc: mov             x2, x0
    // 0x8c81e0: r0 = setState()
    //     0x8c81e0: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8c81e4: r0 = Null
    //     0x8c81e4: mov             x0, NULL
    // 0x8c81e8: LeaveFrame
    //     0x8c81e8: mov             SP, fp
    //     0x8c81ec: ldp             fp, lr, [SP], #0x10
    // 0x8c81f0: ret
    //     0x8c81f0: ret             
    // 0x8c81f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c81f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c81f8: b               #0x8c816c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8c81fc, size: 0x4c
    // 0x8c81fc: ldr             x1, [SP]
    // 0x8c8200: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8c8200: ldur            w2, [x1, #0x17]
    // 0x8c8204: DecompressPointer r2
    //     0x8c8204: add             x2, x2, HEAP, lsl #32
    // 0x8c8208: LoadField: r1 = r2->field_f
    //     0x8c8208: ldur            w1, [x2, #0xf]
    // 0x8c820c: DecompressPointer r1
    //     0x8c820c: add             x1, x1, HEAP, lsl #32
    // 0x8c8210: LoadField: r3 = r2->field_13
    //     0x8c8210: ldur            w3, [x2, #0x13]
    // 0x8c8214: DecompressPointer r3
    //     0x8c8214: add             x3, x3, HEAP, lsl #32
    // 0x8c8218: mov             x0, x3
    // 0x8c821c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c821c: stur            w0, [x1, #0x17]
    //     0x8c8220: ldurb           w16, [x1, #-1]
    //     0x8c8224: ldurb           w17, [x0, #-1]
    //     0x8c8228: and             x16, x17, x16, lsr #2
    //     0x8c822c: tst             x16, HEAP, lsr #32
    //     0x8c8230: b.eq            #0x8c8240
    //     0x8c8234: str             lr, [SP, #-8]!
    //     0x8c8238: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0x8c823c: ldr             lr, [SP], #8
    // 0x8c8240: mov             x0, x3
    // 0x8c8244: ret
    //     0x8c8244: ret             
  }
  _ handleCommitBackGesture(/* No info */) {
    // ** addr: 0x8cd98c, size: 0x88
    // 0x8cd98c: EnterFrame
    //     0x8cd98c: stp             fp, lr, [SP, #-0x10]!
    //     0x8cd990: mov             fp, SP
    // 0x8cd994: AllocStack(0x8)
    //     0x8cd994: sub             SP, SP, #8
    // 0x8cd998: SetupParameters(_PredictiveBackGestureDetectorState this /* r1 => r0, fp-0x8 */)
    //     0x8cd998: mov             x0, x1
    //     0x8cd99c: stur            x1, [fp, #-8]
    // 0x8cd9a0: CheckStackOverflow
    //     0x8cd9a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cd9a4: cmp             SP, x16
    //     0x8cd9a8: b.ls            #0x8cda08
    // 0x8cd9ac: mov             x1, x0
    // 0x8cd9b0: r2 = Instance__PredictiveBackPhase
    //     0x8cd9b0: add             x2, PP, #0xd1, lsl #12  ; [pp+0xd1cd8] Obj!_PredictiveBackPhase@12c52e1
    //     0x8cd9b4: ldr             x2, [x2, #0xcd8]
    // 0x8cd9b8: r0 = phase=()
    //     0x8cd9b8: bl              #0x82eff8  ; [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackGestureDetectorState::phase=
    // 0x8cd9bc: ldur            x0, [fp, #-8]
    // 0x8cd9c0: LoadField: r1 = r0->field_b
    //     0x8cd9c0: ldur            w1, [x0, #0xb]
    // 0x8cd9c4: DecompressPointer r1
    //     0x8cd9c4: add             x1, x1, HEAP, lsl #32
    // 0x8cd9c8: cmp             w1, NULL
    // 0x8cd9cc: b.eq            #0x8cda10
    // 0x8cd9d0: LoadField: r2 = r1->field_f
    //     0x8cd9d0: ldur            w2, [x1, #0xf]
    // 0x8cd9d4: DecompressPointer r2
    //     0x8cd9d4: add             x2, x2, HEAP, lsl #32
    // 0x8cd9d8: mov             x1, x2
    // 0x8cd9dc: r0 = handleCommitBackGesture()
    //     0x8cd9dc: bl              #0x8cda14  ; [package:flutter/src/widgets/routes.dart] TransitionRoute::handleCommitBackGesture
    // 0x8cd9e0: ldur            x1, [fp, #-8]
    // 0x8cd9e4: r2 = Null
    //     0x8cd9e4: mov             x2, NULL
    // 0x8cd9e8: r0 = currentBackEvent=()
    //     0x8cd9e8: bl              #0x8292dc  ; [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackGestureDetectorState::currentBackEvent=
    // 0x8cd9ec: ldur            x1, [fp, #-8]
    // 0x8cd9f0: r2 = Null
    //     0x8cd9f0: mov             x2, NULL
    // 0x8cd9f4: r0 = startBackEvent=()
    //     0x8cd9f4: bl              #0x8c814c  ; [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackGestureDetectorState::startBackEvent=
    // 0x8cd9f8: r0 = Null
    //     0x8cd9f8: mov             x0, NULL
    // 0x8cd9fc: LeaveFrame
    //     0x8cd9fc: mov             SP, fp
    //     0x8cda00: ldp             fp, lr, [SP], #0x10
    // 0x8cda04: ret
    //     0x8cda04: ret             
    // 0x8cda08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cda08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cda0c: b               #0x8cd9ac
    // 0x8cda10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cda10: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ handleStartBackGesture(/* No info */) {
    // ** addr: 0x8cf8d8, size: 0xcc
    // 0x8cf8d8: EnterFrame
    //     0x8cf8d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8cf8dc: mov             fp, SP
    // 0x8cf8e0: AllocStack(0x10)
    //     0x8cf8e0: sub             SP, SP, #0x10
    // 0x8cf8e4: SetupParameters(_PredictiveBackGestureDetectorState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x8cf8e4: mov             x3, x1
    //     0x8cf8e8: mov             x0, x2
    //     0x8cf8ec: stur            x1, [fp, #-8]
    //     0x8cf8f0: stur            x2, [fp, #-0x10]
    // 0x8cf8f4: CheckStackOverflow
    //     0x8cf8f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cf8f8: cmp             SP, x16
    //     0x8cf8fc: b.ls            #0x8cf998
    // 0x8cf900: mov             x1, x3
    // 0x8cf904: r2 = Instance__PredictiveBackPhase
    //     0x8cf904: add             x2, PP, #0xd1, lsl #12  ; [pp+0xd1d10] Obj!_PredictiveBackPhase@12c5301
    //     0x8cf908: ldr             x2, [x2, #0xd10]
    // 0x8cf90c: r0 = phase=()
    //     0x8cf90c: bl              #0x82eff8  ; [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackGestureDetectorState::phase=
    // 0x8cf910: ldur            x1, [fp, #-0x10]
    // 0x8cf914: r0 = isButtonEvent()
    //     0x8cf914: bl              #0x8cfd10  ; [package:flutter/src/services/predictive_back_event.dart] PredictiveBackEvent::isButtonEvent
    // 0x8cf918: tbz             w0, #4, #0x8cf988
    // 0x8cf91c: ldur            x1, [fp, #-8]
    // 0x8cf920: r0 = _isEnabled()
    //     0x8cf920: bl              #0x8cfc64  ; [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackGestureDetectorState::_isEnabled
    // 0x8cf924: tbnz            w0, #4, #0x8cf988
    // 0x8cf928: ldur            x0, [fp, #-8]
    // 0x8cf92c: ldur            x2, [fp, #-0x10]
    // 0x8cf930: d0 = 1.000000
    //     0x8cf930: fmov            d0, #1.00000000
    // 0x8cf934: LoadField: r1 = r0->field_b
    //     0x8cf934: ldur            w1, [x0, #0xb]
    // 0x8cf938: DecompressPointer r1
    //     0x8cf938: add             x1, x1, HEAP, lsl #32
    // 0x8cf93c: cmp             w1, NULL
    // 0x8cf940: b.eq            #0x8cf9a0
    // 0x8cf944: LoadField: r3 = r1->field_f
    //     0x8cf944: ldur            w3, [x1, #0xf]
    // 0x8cf948: DecompressPointer r3
    //     0x8cf948: add             x3, x3, HEAP, lsl #32
    // 0x8cf94c: LoadField: d1 = r2->field_b
    //     0x8cf94c: ldur            d1, [x2, #0xb]
    // 0x8cf950: fsub            d2, d0, d1
    // 0x8cf954: mov             x1, x3
    // 0x8cf958: mov             v0.16b, v2.16b
    // 0x8cf95c: r0 = handleStartBackGesture()
    //     0x8cf95c: bl              #0x8cf9a4  ; [package:flutter/src/widgets/routes.dart] TransitionRoute::handleStartBackGesture
    // 0x8cf960: ldur            x1, [fp, #-8]
    // 0x8cf964: ldur            x2, [fp, #-0x10]
    // 0x8cf968: r0 = currentBackEvent=()
    //     0x8cf968: bl              #0x8292dc  ; [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackGestureDetectorState::currentBackEvent=
    // 0x8cf96c: ldur            x1, [fp, #-8]
    // 0x8cf970: ldur            x2, [fp, #-0x10]
    // 0x8cf974: r0 = startBackEvent=()
    //     0x8cf974: bl              #0x8c814c  ; [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackGestureDetectorState::startBackEvent=
    // 0x8cf978: r0 = true
    //     0x8cf978: add             x0, NULL, #0x20  ; true
    // 0x8cf97c: LeaveFrame
    //     0x8cf97c: mov             SP, fp
    //     0x8cf980: ldp             fp, lr, [SP], #0x10
    // 0x8cf984: ret
    //     0x8cf984: ret             
    // 0x8cf988: r0 = false
    //     0x8cf988: add             x0, NULL, #0x30  ; false
    // 0x8cf98c: LeaveFrame
    //     0x8cf98c: mov             SP, fp
    //     0x8cf990: ldp             fp, lr, [SP], #0x10
    // 0x8cf994: ret
    //     0x8cf994: ret             
    // 0x8cf998: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cf998: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cf99c: b               #0x8cf900
    // 0x8cf9a0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x8cf9a0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  get _ _isEnabled(/* No info */) {
    // ** addr: 0x8cfc64, size: 0xac
    // 0x8cfc64: EnterFrame
    //     0x8cfc64: stp             fp, lr, [SP, #-0x10]!
    //     0x8cfc68: mov             fp, SP
    // 0x8cfc6c: AllocStack(0x8)
    //     0x8cfc6c: sub             SP, SP, #8
    // 0x8cfc70: SetupParameters(_PredictiveBackGestureDetectorState this /* r1 => r0, fp-0x8 */)
    //     0x8cfc70: mov             x0, x1
    //     0x8cfc74: stur            x1, [fp, #-8]
    // 0x8cfc78: CheckStackOverflow
    //     0x8cfc78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cfc7c: cmp             SP, x16
    //     0x8cfc80: b.ls            #0x8cfd00
    // 0x8cfc84: LoadField: r1 = r0->field_b
    //     0x8cfc84: ldur            w1, [x0, #0xb]
    // 0x8cfc88: DecompressPointer r1
    //     0x8cfc88: add             x1, x1, HEAP, lsl #32
    // 0x8cfc8c: cmp             w1, NULL
    // 0x8cfc90: b.eq            #0x8cfd08
    // 0x8cfc94: LoadField: r2 = r1->field_f
    //     0x8cfc94: ldur            w2, [x1, #0xf]
    // 0x8cfc98: DecompressPointer r2
    //     0x8cfc98: add             x2, x2, HEAP, lsl #32
    // 0x8cfc9c: mov             x1, x2
    // 0x8cfca0: r0 = isCurrent()
    //     0x8cfca0: bl              #0x82eeb4  ; [package:flutter/src/widgets/navigator.dart] Route::isCurrent
    // 0x8cfca4: tbnz            w0, #4, #0x8cfcf0
    // 0x8cfca8: ldur            x0, [fp, #-8]
    // 0x8cfcac: LoadField: r1 = r0->field_b
    //     0x8cfcac: ldur            w1, [x0, #0xb]
    // 0x8cfcb0: DecompressPointer r1
    //     0x8cfcb0: add             x1, x1, HEAP, lsl #32
    // 0x8cfcb4: cmp             w1, NULL
    // 0x8cfcb8: b.eq            #0x8cfd0c
    // 0x8cfcbc: LoadField: r0 = r1->field_f
    //     0x8cfcbc: ldur            w0, [x1, #0xf]
    // 0x8cfcc0: DecompressPointer r0
    //     0x8cfcc0: add             x0, x0, HEAP, lsl #32
    // 0x8cfcc4: r1 = LoadClassIdInstr(r0)
    //     0x8cfcc4: ldur            x1, [x0, #-1]
    //     0x8cfcc8: ubfx            x1, x1, #0xc, #0x14
    // 0x8cfccc: mov             x16, x0
    // 0x8cfcd0: mov             x0, x1
    // 0x8cfcd4: mov             x1, x16
    // 0x8cfcd8: r0 = GDT[cid_x0 + 0x12db6]()
    //     0x8cfcd8: mov             x17, #0x2db6
    //     0x8cfcdc: movk            x17, #1, lsl #16
    //     0x8cfce0: add             lr, x0, x17
    //     0x8cfce4: ldr             lr, [x21, lr, lsl #3]
    //     0x8cfce8: blr             lr
    // 0x8cfcec: b               #0x8cfcf4
    // 0x8cfcf0: r0 = false
    //     0x8cfcf0: add             x0, NULL, #0x30  ; false
    // 0x8cfcf4: LeaveFrame
    //     0x8cfcf4: mov             SP, fp
    //     0x8cfcf8: ldp             fp, lr, [SP], #0x10
    // 0x8cfcfc: ret
    //     0x8cfcfc: ret             
    // 0x8cfd00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cfd00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cfd04: b               #0x8cfc84
    // 0x8cfd08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cfd08: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8cfd0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cfd0c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0xd2fb30, size: 0xd0
    // 0xd2fb30: EnterFrame
    //     0xd2fb30: stp             fp, lr, [SP, #-0x10]!
    //     0xd2fb34: mov             fp, SP
    // 0xd2fb38: AllocStack(0x38)
    //     0xd2fb38: sub             SP, SP, #0x38
    // 0xd2fb3c: SetupParameters(_PredictiveBackGestureDetectorState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd2fb3c: mov             x3, x1
    //     0xd2fb40: stur            x1, [fp, #-8]
    //     0xd2fb44: stur            x2, [fp, #-0x10]
    // 0xd2fb48: CheckStackOverflow
    //     0xd2fb48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd2fb4c: cmp             SP, x16
    //     0xd2fb50: b.ls            #0xd2fbf0
    // 0xd2fb54: LoadField: r0 = r3->field_b
    //     0xd2fb54: ldur            w0, [x3, #0xb]
    // 0xd2fb58: DecompressPointer r0
    //     0xd2fb58: add             x0, x0, HEAP, lsl #32
    // 0xd2fb5c: cmp             w0, NULL
    // 0xd2fb60: b.eq            #0xd2fbf8
    // 0xd2fb64: LoadField: r1 = r0->field_f
    //     0xd2fb64: ldur            w1, [x0, #0xf]
    // 0xd2fb68: DecompressPointer r1
    //     0xd2fb68: add             x1, x1, HEAP, lsl #32
    // 0xd2fb6c: r0 = LoadClassIdInstr(r1)
    //     0xd2fb6c: ldur            x0, [x1, #-1]
    //     0xd2fb70: ubfx            x0, x0, #0xc, #0x14
    // 0xd2fb74: r0 = GDT[cid_x0 + -0xd25]()
    //     0xd2fb74: sub             lr, x0, #0xd25
    //     0xd2fb78: ldr             lr, [x21, lr, lsl #3]
    //     0xd2fb7c: blr             lr
    // 0xd2fb80: tbnz            w0, #4, #0xd2fb94
    // 0xd2fb84: ldur            x0, [fp, #-8]
    // 0xd2fb88: LoadField: r1 = r0->field_13
    //     0xd2fb88: ldur            w1, [x0, #0x13]
    // 0xd2fb8c: DecompressPointer r1
    //     0xd2fb8c: add             x1, x1, HEAP, lsl #32
    // 0xd2fb90: b               #0xd2fba0
    // 0xd2fb94: ldur            x0, [fp, #-8]
    // 0xd2fb98: r1 = Instance__PredictiveBackPhase
    //     0xd2fb98: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd04a8] Obj!_PredictiveBackPhase@12c5321
    //     0xd2fb9c: ldr             x1, [x1, #0x4a8]
    // 0xd2fba0: LoadField: r2 = r0->field_b
    //     0xd2fba0: ldur            w2, [x0, #0xb]
    // 0xd2fba4: DecompressPointer r2
    //     0xd2fba4: add             x2, x2, HEAP, lsl #32
    // 0xd2fba8: cmp             w2, NULL
    // 0xd2fbac: b.eq            #0xd2fbfc
    // 0xd2fbb0: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xd2fbb0: ldur            w3, [x0, #0x17]
    // 0xd2fbb4: DecompressPointer r3
    //     0xd2fbb4: add             x3, x3, HEAP, lsl #32
    // 0xd2fbb8: LoadField: r4 = r0->field_1b
    //     0xd2fbb8: ldur            w4, [x0, #0x1b]
    // 0xd2fbbc: DecompressPointer r4
    //     0xd2fbbc: add             x4, x4, HEAP, lsl #32
    // 0xd2fbc0: LoadField: r0 = r2->field_b
    //     0xd2fbc0: ldur            w0, [x2, #0xb]
    // 0xd2fbc4: DecompressPointer r0
    //     0xd2fbc4: add             x0, x0, HEAP, lsl #32
    // 0xd2fbc8: ldur            x16, [fp, #-0x10]
    // 0xd2fbcc: stp             x16, x0, [SP, #0x18]
    // 0xd2fbd0: stp             x3, x1, [SP, #8]
    // 0xd2fbd4: str             x4, [SP]
    // 0xd2fbd8: ClosureCall
    //     0xd2fbd8: ldr             x4, [PP, #0x1488]  ; [pp+0x1488] List(5) [0, 0x5, 0x5, 0x5, Null]
    //     0xd2fbdc: ldur            x2, [x0, #0x1f]
    //     0xd2fbe0: blr             x2
    // 0xd2fbe4: LeaveFrame
    //     0xd2fbe4: mov             SP, fp
    //     0xd2fbe8: ldp             fp, lr, [SP], #0x10
    // 0xd2fbec: ret
    //     0xd2fbec: ret             
    // 0xd2fbf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd2fbf0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd2fbf4: b               #0xd2fb54
    // 0xd2fbf8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2fbf8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2fbfc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2fbfc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6448, size: 0x20, field offset: 0xc
//   const constructor, 
class _PredictiveBackSharedElementPageTransition extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa23ec, size: 0x48
    // 0xfa23ec: EnterFrame
    //     0xfa23ec: stp             fp, lr, [SP, #-0x10]!
    //     0xfa23f0: mov             fp, SP
    // 0xfa23f4: AllocStack(0x8)
    //     0xfa23f4: sub             SP, SP, #8
    // 0xfa23f8: CheckStackOverflow
    //     0xfa23f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa23fc: cmp             SP, x16
    //     0xfa2400: b.ls            #0xfa242c
    // 0xfa2404: r1 = <_PredictiveBackSharedElementPageTransition>
    //     0xfa2404: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0498] TypeArguments: <_PredictiveBackSharedElementPageTransition>
    //     0xfa2408: ldr             x1, [x1, #0x498]
    // 0xfa240c: r0 = _PredictiveBackSharedElementPageTransitionState()
    //     0xfa240c: bl              #0xfa25ec  ; Allocate_PredictiveBackSharedElementPageTransitionStateStub -> _PredictiveBackSharedElementPageTransitionState (size=0x4c)
    // 0xfa2410: mov             x1, x0
    // 0xfa2414: stur            x0, [fp, #-8]
    // 0xfa2418: r0 = _PredictiveBackSharedElementPageTransitionState()
    //     0xfa2418: bl              #0xfa2434  ; [package:flutter/src/material/predictive_back_page_transitions_builder.dart] _PredictiveBackSharedElementPageTransitionState::_PredictiveBackSharedElementPageTransitionState
    // 0xfa241c: ldur            x0, [fp, #-8]
    // 0xfa2420: LeaveFrame
    //     0xfa2420: mov             SP, fp
    //     0xfa2424: ldp             fp, lr, [SP], #0x10
    // 0xfa2428: ret
    //     0xfa2428: ret             
    // 0xfa242c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa242c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa2430: b               #0xfa2404
  }
}

// class id: 6449, size: 0x14, field offset: 0xc
//   const constructor, 
class _PredictiveBackGestureDetector extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa23b0, size: 0x30
    // 0xfa23b0: EnterFrame
    //     0xfa23b0: stp             fp, lr, [SP, #-0x10]!
    //     0xfa23b4: mov             fp, SP
    // 0xfa23b8: mov             x0, x1
    // 0xfa23bc: r1 = <_PredictiveBackGestureDetector>
    //     0xfa23bc: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd04a0] TypeArguments: <_PredictiveBackGestureDetector>
    //     0xfa23c0: ldr             x1, [x1, #0x4a0]
    // 0xfa23c4: r0 = _PredictiveBackGestureDetectorState()
    //     0xfa23c4: bl              #0xfa23e0  ; Allocate_PredictiveBackGestureDetectorStateStub -> _PredictiveBackGestureDetectorState (size=0x20)
    // 0xfa23c8: r1 = Instance__PredictiveBackPhase
    //     0xfa23c8: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd04a8] Obj!_PredictiveBackPhase@12c5321
    //     0xfa23cc: ldr             x1, [x1, #0x4a8]
    // 0xfa23d0: StoreField: r0->field_13 = r1
    //     0xfa23d0: stur            w1, [x0, #0x13]
    // 0xfa23d4: LeaveFrame
    //     0xfa23d4: mov             SP, fp
    //     0xfa23d8: ldp             fp, lr, [SP], #0x10
    // 0xfa23dc: ret
    //     0xfa23dc: ret             
  }
}

// class id: 8275, size: 0x14, field offset: 0x14
enum _PredictiveBackPhase extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa47c, size: 0x64
    // 0x11aa47c: EnterFrame
    //     0x11aa47c: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa480: mov             fp, SP
    // 0x11aa484: AllocStack(0x10)
    //     0x11aa484: sub             SP, SP, #0x10
    // 0x11aa488: SetupParameters(_PredictiveBackPhase this /* r1 => r0, fp-0x8 */)
    //     0x11aa488: mov             x0, x1
    //     0x11aa48c: stur            x1, [fp, #-8]
    // 0x11aa490: CheckStackOverflow
    //     0x11aa490: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa494: cmp             SP, x16
    //     0x11aa498: b.ls            #0x11aa4d8
    // 0x11aa49c: r1 = Null
    //     0x11aa49c: mov             x1, NULL
    // 0x11aa4a0: r2 = 4
    //     0x11aa4a0: mov             x2, #4
    // 0x11aa4a4: r0 = AllocateArray()
    //     0x11aa4a4: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa4a8: r16 = "_PredictiveBackPhase."
    //     0x11aa4a8: add             x16, PP, #0xd1, lsl #12  ; [pp+0xd1cd0] "_PredictiveBackPhase."
    //     0x11aa4ac: ldr             x16, [x16, #0xcd0]
    // 0x11aa4b0: StoreField: r0->field_f = r16
    //     0x11aa4b0: stur            w16, [x0, #0xf]
    // 0x11aa4b4: ldur            x1, [fp, #-8]
    // 0x11aa4b8: LoadField: r2 = r1->field_f
    //     0x11aa4b8: ldur            w2, [x1, #0xf]
    // 0x11aa4bc: DecompressPointer r2
    //     0x11aa4bc: add             x2, x2, HEAP, lsl #32
    // 0x11aa4c0: StoreField: r0->field_13 = r2
    //     0x11aa4c0: stur            w2, [x0, #0x13]
    // 0x11aa4c4: str             x0, [SP]
    // 0x11aa4c8: r0 = _interpolate()
    //     0x11aa4c8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa4cc: LeaveFrame
    //     0x11aa4cc: mov             SP, fp
    //     0x11aa4d0: ldp             fp, lr, [SP], #0x10
    // 0x11aa4d4: ret
    //     0x11aa4d4: ret             
    // 0x11aa4d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa4d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa4dc: b               #0x11aa49c
  }
}
