// lib: , url: package:flutter/src/material/navigation_rail_theme.dart

// class id: 1048923, size: 0x8
class :: {
}

// class id: 5134, size: 0x3c, field offset: 0x8
//   const constructor, 
class NavigationRailThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x1134eac, size: 0x90
    // 0x1134eac: EnterFrame
    //     0x1134eac: stp             fp, lr, [SP, #-0x10]!
    //     0x1134eb0: mov             fp, SP
    // 0x1134eb4: AllocStack(0x58)
    //     0x1134eb4: sub             SP, SP, #0x58
    // 0x1134eb8: CheckStackOverflow
    //     0x1134eb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1134ebc: cmp             SP, x16
    //     0x1134ec0: b.ls            #0x1134f34
    // 0x1134ec4: ldr             x0, [fp, #0x10]
    // 0x1134ec8: LoadField: r2 = r0->field_b
    //     0x1134ec8: ldur            w2, [x0, #0xb]
    // 0x1134ecc: DecompressPointer r2
    //     0x1134ecc: add             x2, x2, HEAP, lsl #32
    // 0x1134ed0: LoadField: r1 = r0->field_1f
    //     0x1134ed0: ldur            w1, [x0, #0x1f]
    // 0x1134ed4: DecompressPointer r1
    //     0x1134ed4: add             x1, x1, HEAP, lsl #32
    // 0x1134ed8: LoadField: r3 = r0->field_33
    //     0x1134ed8: ldur            w3, [x0, #0x33]
    // 0x1134edc: DecompressPointer r3
    //     0x1134edc: add             x3, x3, HEAP, lsl #32
    // 0x1134ee0: LoadField: r4 = r0->field_37
    //     0x1134ee0: ldur            w4, [x0, #0x37]
    // 0x1134ee4: DecompressPointer r4
    //     0x1134ee4: add             x4, x4, HEAP, lsl #32
    // 0x1134ee8: stp             NULL, NULL, [SP, #0x48]
    // 0x1134eec: stp             NULL, NULL, [SP, #0x38]
    // 0x1134ef0: stp             NULL, x1, [SP, #0x28]
    // 0x1134ef4: stp             NULL, NULL, [SP, #0x18]
    // 0x1134ef8: stp             x3, NULL, [SP, #8]
    // 0x1134efc: str             x4, [SP]
    // 0x1134f00: r1 = Null
    //     0x1134f00: mov             x1, NULL
    // 0x1134f04: r4 = const [0, 0xd, 0xb, 0xd, null]
    //     0x1134f04: add             x4, PP, #0x26, lsl #12  ; [pp+0x26260] List(5) [0, 0xd, 0xb, 0xd, Null]
    //     0x1134f08: ldr             x4, [x4, #0x260]
    // 0x1134f0c: r0 = hash()
    //     0x1134f0c: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1134f10: mov             x2, x0
    // 0x1134f14: r0 = BoxInt64Instr(r2)
    //     0x1134f14: sbfiz           x0, x2, #1, #0x1f
    //     0x1134f18: cmp             x2, x0, asr #1
    //     0x1134f1c: b.eq            #0x1134f28
    //     0x1134f20: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1134f24: stur            x2, [x0, #7]
    // 0x1134f28: LeaveFrame
    //     0x1134f28: mov             SP, fp
    //     0x1134f2c: ldp             fp, lr, [SP], #0x10
    // 0x1134f30: ret
    //     0x1134f30: ret             
    // 0x1134f34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1134f34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1134f38: b               #0x1134ec4
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x11664c4, size: 0x1ac
    // 0x11664c4: EnterFrame
    //     0x11664c4: stp             fp, lr, [SP, #-0x10]!
    //     0x11664c8: mov             fp, SP
    // 0x11664cc: AllocStack(0x38)
    //     0x11664cc: sub             SP, SP, #0x38
    // 0x11664d0: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x38 */)
    //     0x11664d0: mov             x4, x1
    //     0x11664d4: mov             x0, x2
    //     0x11664d8: stur            x1, [fp, #-0x10]
    //     0x11664dc: stur            x2, [fp, #-0x18]
    //     0x11664e0: stur            d0, [fp, #-0x38]
    // 0x11664e4: CheckStackOverflow
    //     0x11664e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11664e8: cmp             SP, x16
    //     0x11664ec: b.ls            #0x116664c
    // 0x11664f0: cmp             w4, w0
    // 0x11664f4: b.ne            #0x1166508
    // 0x11664f8: mov             x0, x4
    // 0x11664fc: LeaveFrame
    //     0x11664fc: mov             SP, fp
    //     0x1166500: ldp             fp, lr, [SP], #0x10
    // 0x1166504: ret
    //     0x1166504: ret             
    // 0x1166508: r5 = inline_Allocate_Double()
    //     0x1166508: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x116650c: add             x5, x5, #0x10
    //     0x1166510: cmp             x1, x5
    //     0x1166514: b.ls            #0x1166654
    //     0x1166518: str             x5, [THR, #0x60]  ; THR::top
    //     0x116651c: sub             x5, x5, #0xf
    //     0x1166520: mov             x1, #0xe19c
    //     0x1166524: movk            x1, #3, lsl #16
    //     0x1166528: stur            x1, [x5, #-1]
    // 0x116652c: dmb             ishst
    // 0x1166530: StoreField: r5->field_7 = d0
    //     0x1166530: stur            d0, [x5, #7]
    // 0x1166534: mov             x3, x5
    // 0x1166538: stur            x5, [fp, #-8]
    // 0x116653c: r1 = Null
    //     0x116653c: mov             x1, NULL
    // 0x1166540: r2 = Null
    //     0x1166540: mov             x2, NULL
    // 0x1166544: r0 = lerp()
    //     0x1166544: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1166548: ldur            x0, [fp, #-0x10]
    // 0x116654c: LoadField: r1 = r0->field_b
    //     0x116654c: ldur            w1, [x0, #0xb]
    // 0x1166550: DecompressPointer r1
    //     0x1166550: add             x1, x1, HEAP, lsl #32
    // 0x1166554: ldur            x4, [fp, #-0x18]
    // 0x1166558: LoadField: r2 = r4->field_b
    //     0x1166558: ldur            w2, [x4, #0xb]
    // 0x116655c: DecompressPointer r2
    //     0x116655c: add             x2, x2, HEAP, lsl #32
    // 0x1166560: ldur            x3, [fp, #-8]
    // 0x1166564: r0 = lerpDouble()
    //     0x1166564: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1166568: ldur            x3, [fp, #-8]
    // 0x116656c: r1 = Null
    //     0x116656c: mov             x1, NULL
    // 0x1166570: r2 = Null
    //     0x1166570: mov             x2, NULL
    // 0x1166574: stur            x0, [fp, #-0x20]
    // 0x1166578: r0 = lerp()
    //     0x1166578: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x116657c: ldur            x3, [fp, #-8]
    // 0x1166580: r1 = Null
    //     0x1166580: mov             x1, NULL
    // 0x1166584: r2 = Null
    //     0x1166584: mov             x2, NULL
    // 0x1166588: r0 = lerp()
    //     0x1166588: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x116658c: ldur            x0, [fp, #-0x10]
    // 0x1166590: LoadField: r1 = r0->field_1f
    //     0x1166590: ldur            w1, [x0, #0x1f]
    // 0x1166594: DecompressPointer r1
    //     0x1166594: add             x1, x1, HEAP, lsl #32
    // 0x1166598: ldur            x4, [fp, #-0x18]
    // 0x116659c: LoadField: r2 = r4->field_1f
    //     0x116659c: ldur            w2, [x4, #0x1f]
    // 0x11665a0: DecompressPointer r2
    //     0x11665a0: add             x2, x2, HEAP, lsl #32
    // 0x11665a4: ldur            x3, [fp, #-8]
    // 0x11665a8: r0 = lerpDouble()
    //     0x11665a8: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x11665ac: ldur            x3, [fp, #-8]
    // 0x11665b0: r1 = Null
    //     0x11665b0: mov             x1, NULL
    // 0x11665b4: r2 = Null
    //     0x11665b4: mov             x2, NULL
    // 0x11665b8: stur            x0, [fp, #-0x28]
    // 0x11665bc: r0 = lerp()
    //     0x11665bc: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11665c0: ldur            d0, [fp, #-0x38]
    // 0x11665c4: r1 = Null
    //     0x11665c4: mov             x1, NULL
    // 0x11665c8: r2 = Null
    //     0x11665c8: mov             x2, NULL
    // 0x11665cc: r0 = lerp()
    //     0x11665cc: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x11665d0: ldur            x0, [fp, #-0x10]
    // 0x11665d4: LoadField: r1 = r0->field_33
    //     0x11665d4: ldur            w1, [x0, #0x33]
    // 0x11665d8: DecompressPointer r1
    //     0x11665d8: add             x1, x1, HEAP, lsl #32
    // 0x11665dc: ldur            x4, [fp, #-0x18]
    // 0x11665e0: LoadField: r2 = r4->field_33
    //     0x11665e0: ldur            w2, [x4, #0x33]
    // 0x11665e4: DecompressPointer r2
    //     0x11665e4: add             x2, x2, HEAP, lsl #32
    // 0x11665e8: ldur            x3, [fp, #-8]
    // 0x11665ec: r0 = lerpDouble()
    //     0x11665ec: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x11665f0: mov             x4, x0
    // 0x11665f4: ldur            x0, [fp, #-0x10]
    // 0x11665f8: stur            x4, [fp, #-0x30]
    // 0x11665fc: LoadField: r1 = r0->field_37
    //     0x11665fc: ldur            w1, [x0, #0x37]
    // 0x1166600: DecompressPointer r1
    //     0x1166600: add             x1, x1, HEAP, lsl #32
    // 0x1166604: ldur            x0, [fp, #-0x18]
    // 0x1166608: LoadField: r2 = r0->field_37
    //     0x1166608: ldur            w2, [x0, #0x37]
    // 0x116660c: DecompressPointer r2
    //     0x116660c: add             x2, x2, HEAP, lsl #32
    // 0x1166610: ldur            x3, [fp, #-8]
    // 0x1166614: r0 = lerpDouble()
    //     0x1166614: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1166618: stur            x0, [fp, #-8]
    // 0x116661c: r0 = NavigationRailThemeData()
    //     0x116661c: bl              #0x1166670  ; AllocateNavigationRailThemeDataStub -> NavigationRailThemeData (size=0x3c)
    // 0x1166620: ldur            x1, [fp, #-0x20]
    // 0x1166624: StoreField: r0->field_b = r1
    //     0x1166624: stur            w1, [x0, #0xb]
    // 0x1166628: ldur            x1, [fp, #-0x28]
    // 0x116662c: StoreField: r0->field_1f = r1
    //     0x116662c: stur            w1, [x0, #0x1f]
    // 0x1166630: ldur            x1, [fp, #-0x30]
    // 0x1166634: StoreField: r0->field_33 = r1
    //     0x1166634: stur            w1, [x0, #0x33]
    // 0x1166638: ldur            x1, [fp, #-8]
    // 0x116663c: StoreField: r0->field_37 = r1
    //     0x116663c: stur            w1, [x0, #0x37]
    // 0x1166640: LeaveFrame
    //     0x1166640: mov             SP, fp
    //     0x1166644: ldp             fp, lr, [SP], #0x10
    // 0x1166648: ret
    //     0x1166648: ret             
    // 0x116664c: r0 = StackOverflowSharedWithFPURegs()
    //     0x116664c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1166650: b               #0x11664f0
    // 0x1166654: SaveReg d0
    //     0x1166654: str             q0, [SP, #-0x10]!
    // 0x1166658: stp             x0, x4, [SP, #-0x10]!
    // 0x116665c: r0 = AllocateDouble()
    //     0x116665c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1166660: mov             x5, x0
    // 0x1166664: ldp             x0, x4, [SP], #0x10
    // 0x1166668: RestoreReg d0
    //     0x1166668: ldr             q0, [SP], #0x10
    // 0x116666c: b               #0x1166530
  }
  _ ==(/* No info */) {
    // ** addr: 0x126ff5c, size: 0x1a4
    // 0x126ff5c: EnterFrame
    //     0x126ff5c: stp             fp, lr, [SP, #-0x10]!
    //     0x126ff60: mov             fp, SP
    // 0x126ff64: AllocStack(0x10)
    //     0x126ff64: sub             SP, SP, #0x10
    // 0x126ff68: CheckStackOverflow
    //     0x126ff68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x126ff6c: cmp             SP, x16
    //     0x126ff70: b.ls            #0x12700f8
    // 0x126ff74: ldr             x0, [fp, #0x10]
    // 0x126ff78: cmp             w0, NULL
    // 0x126ff7c: b.ne            #0x126ff90
    // 0x126ff80: r0 = false
    //     0x126ff80: add             x0, NULL, #0x30  ; false
    // 0x126ff84: LeaveFrame
    //     0x126ff84: mov             SP, fp
    //     0x126ff88: ldp             fp, lr, [SP], #0x10
    // 0x126ff8c: ret
    //     0x126ff8c: ret             
    // 0x126ff90: ldr             x1, [fp, #0x18]
    // 0x126ff94: cmp             w1, w0
    // 0x126ff98: b.ne            #0x126ffac
    // 0x126ff9c: r0 = true
    //     0x126ff9c: add             x0, NULL, #0x20  ; true
    // 0x126ffa0: LeaveFrame
    //     0x126ffa0: mov             SP, fp
    //     0x126ffa4: ldp             fp, lr, [SP], #0x10
    // 0x126ffa8: ret
    //     0x126ffa8: ret             
    // 0x126ffac: str             x0, [SP]
    // 0x126ffb0: r0 = runtimeType()
    //     0x126ffb0: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x126ffb4: r1 = LoadClassIdInstr(r0)
    //     0x126ffb4: ldur            x1, [x0, #-1]
    //     0x126ffb8: ubfx            x1, x1, #0xc, #0x14
    // 0x126ffbc: r16 = NavigationRailThemeData
    //     0x126ffbc: add             x16, PP, #0x26, lsl #12  ; [pp+0x26310] Type: NavigationRailThemeData
    //     0x126ffc0: ldr             x16, [x16, #0x310]
    // 0x126ffc4: stp             x16, x0, [SP]
    // 0x126ffc8: mov             x0, x1
    // 0x126ffcc: mov             lr, x0
    // 0x126ffd0: ldr             lr, [x21, lr, lsl #3]
    // 0x126ffd4: blr             lr
    // 0x126ffd8: tbz             w0, #4, #0x126ffec
    // 0x126ffdc: r0 = false
    //     0x126ffdc: add             x0, NULL, #0x30  ; false
    // 0x126ffe0: LeaveFrame
    //     0x126ffe0: mov             SP, fp
    //     0x126ffe4: ldp             fp, lr, [SP], #0x10
    // 0x126ffe8: ret
    //     0x126ffe8: ret             
    // 0x126ffec: ldr             x1, [fp, #0x10]
    // 0x126fff0: r0 = 60
    //     0x126fff0: mov             x0, #0x3c
    // 0x126fff4: branchIfSmi(r1, 0x1270000)
    //     0x126fff4: tbz             w1, #0, #0x1270000
    // 0x126fff8: r0 = LoadClassIdInstr(r1)
    //     0x126fff8: ldur            x0, [x1, #-1]
    //     0x126fffc: ubfx            x0, x0, #0xc, #0x14
    // 0x1270000: r17 = 5134
    //     0x1270000: mov             x17, #0x140e
    // 0x1270004: cmp             x0, x17
    // 0x1270008: b.ne            #0x12700e8
    // 0x127000c: ldr             x2, [fp, #0x18]
    // 0x1270010: LoadField: r0 = r1->field_b
    //     0x1270010: ldur            w0, [x1, #0xb]
    // 0x1270014: DecompressPointer r0
    //     0x1270014: add             x0, x0, HEAP, lsl #32
    // 0x1270018: LoadField: r3 = r2->field_b
    //     0x1270018: ldur            w3, [x2, #0xb]
    // 0x127001c: DecompressPointer r3
    //     0x127001c: add             x3, x3, HEAP, lsl #32
    // 0x1270020: r4 = LoadClassIdInstr(r0)
    //     0x1270020: ldur            x4, [x0, #-1]
    //     0x1270024: ubfx            x4, x4, #0xc, #0x14
    // 0x1270028: stp             x3, x0, [SP]
    // 0x127002c: mov             x0, x4
    // 0x1270030: mov             lr, x0
    // 0x1270034: ldr             lr, [x21, lr, lsl #3]
    // 0x1270038: blr             lr
    // 0x127003c: tbnz            w0, #4, #0x12700e8
    // 0x1270040: ldr             x2, [fp, #0x18]
    // 0x1270044: ldr             x1, [fp, #0x10]
    // 0x1270048: LoadField: r0 = r1->field_1f
    //     0x1270048: ldur            w0, [x1, #0x1f]
    // 0x127004c: DecompressPointer r0
    //     0x127004c: add             x0, x0, HEAP, lsl #32
    // 0x1270050: LoadField: r3 = r2->field_1f
    //     0x1270050: ldur            w3, [x2, #0x1f]
    // 0x1270054: DecompressPointer r3
    //     0x1270054: add             x3, x3, HEAP, lsl #32
    // 0x1270058: r4 = LoadClassIdInstr(r0)
    //     0x1270058: ldur            x4, [x0, #-1]
    //     0x127005c: ubfx            x4, x4, #0xc, #0x14
    // 0x1270060: stp             x3, x0, [SP]
    // 0x1270064: mov             x0, x4
    // 0x1270068: mov             lr, x0
    // 0x127006c: ldr             lr, [x21, lr, lsl #3]
    // 0x1270070: blr             lr
    // 0x1270074: tbnz            w0, #4, #0x12700e8
    // 0x1270078: ldr             x2, [fp, #0x18]
    // 0x127007c: ldr             x1, [fp, #0x10]
    // 0x1270080: LoadField: r0 = r1->field_33
    //     0x1270080: ldur            w0, [x1, #0x33]
    // 0x1270084: DecompressPointer r0
    //     0x1270084: add             x0, x0, HEAP, lsl #32
    // 0x1270088: LoadField: r3 = r2->field_33
    //     0x1270088: ldur            w3, [x2, #0x33]
    // 0x127008c: DecompressPointer r3
    //     0x127008c: add             x3, x3, HEAP, lsl #32
    // 0x1270090: r4 = LoadClassIdInstr(r0)
    //     0x1270090: ldur            x4, [x0, #-1]
    //     0x1270094: ubfx            x4, x4, #0xc, #0x14
    // 0x1270098: stp             x3, x0, [SP]
    // 0x127009c: mov             x0, x4
    // 0x12700a0: mov             lr, x0
    // 0x12700a4: ldr             lr, [x21, lr, lsl #3]
    // 0x12700a8: blr             lr
    // 0x12700ac: tbnz            w0, #4, #0x12700e8
    // 0x12700b0: ldr             x1, [fp, #0x18]
    // 0x12700b4: ldr             x0, [fp, #0x10]
    // 0x12700b8: LoadField: r2 = r0->field_37
    //     0x12700b8: ldur            w2, [x0, #0x37]
    // 0x12700bc: DecompressPointer r2
    //     0x12700bc: add             x2, x2, HEAP, lsl #32
    // 0x12700c0: LoadField: r0 = r1->field_37
    //     0x12700c0: ldur            w0, [x1, #0x37]
    // 0x12700c4: DecompressPointer r0
    //     0x12700c4: add             x0, x0, HEAP, lsl #32
    // 0x12700c8: r1 = LoadClassIdInstr(r2)
    //     0x12700c8: ldur            x1, [x2, #-1]
    //     0x12700cc: ubfx            x1, x1, #0xc, #0x14
    // 0x12700d0: stp             x0, x2, [SP]
    // 0x12700d4: mov             x0, x1
    // 0x12700d8: mov             lr, x0
    // 0x12700dc: ldr             lr, [x21, lr, lsl #3]
    // 0x12700e0: blr             lr
    // 0x12700e4: b               #0x12700ec
    // 0x12700e8: r0 = false
    //     0x12700e8: add             x0, NULL, #0x30  ; false
    // 0x12700ec: LeaveFrame
    //     0x12700ec: mov             SP, fp
    //     0x12700f0: ldp             fp, lr, [SP], #0x10
    // 0x12700f4: ret
    //     0x12700f4: ret             
    // 0x12700f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12700f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12700fc: b               #0x126ff74
  }
}
