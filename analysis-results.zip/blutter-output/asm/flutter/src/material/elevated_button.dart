// lib: , url: package:flutter/src/material/elevated_button.dart

// class id: 1048888, size: 0x8
class :: {

  static _ _scaledPadding(/* No info */) {
    // ** addr: 0x1140b90, size: 0x140
    // 0x1140b90: EnterFrame
    //     0x1140b90: stp             fp, lr, [SP, #-0x10]!
    //     0x1140b94: mov             fp, SP
    // 0x1140b98: AllocStack(0x28)
    //     0x1140b98: sub             SP, SP, #0x28
    // 0x1140b9c: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x1140b9c: mov             x0, x1
    //     0x1140ba0: stur            x1, [fp, #-8]
    // 0x1140ba4: CheckStackOverflow
    //     0x1140ba4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1140ba8: cmp             SP, x16
    //     0x1140bac: b.ls            #0x1140cc8
    // 0x1140bb0: mov             x1, x0
    // 0x1140bb4: r0 = of()
    //     0x1140bb4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1140bb8: LoadField: r1 = r0->field_2f
    //     0x1140bb8: ldur            w1, [x0, #0x2f]
    // 0x1140bbc: DecompressPointer r1
    //     0x1140bbc: add             x1, x1, HEAP, lsl #32
    // 0x1140bc0: tbnz            w1, #4, #0x1140bcc
    // 0x1140bc4: d0 = 24.000000
    //     0x1140bc4: fmov            d0, #24.00000000
    // 0x1140bc8: b               #0x1140bd0
    // 0x1140bcc: d0 = 16.000000
    //     0x1140bcc: fmov            d0, #16.00000000
    // 0x1140bd0: stur            d0, [fp, #-0x20]
    // 0x1140bd4: LoadField: r1 = r0->field_87
    //     0x1140bd4: ldur            w1, [x0, #0x87]
    // 0x1140bd8: DecompressPointer r1
    //     0x1140bd8: add             x1, x1, HEAP, lsl #32
    // 0x1140bdc: LoadField: r0 = r1->field_37
    //     0x1140bdc: ldur            w0, [x1, #0x37]
    // 0x1140be0: DecompressPointer r0
    //     0x1140be0: add             x0, x0, HEAP, lsl #32
    // 0x1140be4: LoadField: r1 = r0->field_1f
    //     0x1140be4: ldur            w1, [x0, #0x1f]
    // 0x1140be8: DecompressPointer r1
    //     0x1140be8: add             x1, x1, HEAP, lsl #32
    // 0x1140bec: cmp             w1, NULL
    // 0x1140bf0: b.ne            #0x1140bfc
    // 0x1140bf4: d1 = 14.000000
    //     0x1140bf4: fmov            d1, #14.00000000
    // 0x1140bf8: b               #0x1140c00
    // 0x1140bfc: LoadField: d1 = r1->field_7
    //     0x1140bfc: ldur            d1, [x1, #7]
    // 0x1140c00: ldur            x1, [fp, #-8]
    // 0x1140c04: stur            d1, [fp, #-0x18]
    // 0x1140c08: r0 = textScalerOf()
    //     0x1140c08: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0x1140c0c: r1 = LoadClassIdInstr(r0)
    //     0x1140c0c: ldur            x1, [x0, #-1]
    //     0x1140c10: ubfx            x1, x1, #0xc, #0x14
    // 0x1140c14: mov             x16, x0
    // 0x1140c18: mov             x0, x1
    // 0x1140c1c: mov             x1, x16
    // 0x1140c20: ldur            d0, [fp, #-0x18]
    // 0x1140c24: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1140c24: sub             lr, x0, #1, lsl #12
    //     0x1140c28: ldr             lr, [x21, lr, lsl #3]
    //     0x1140c2c: blr             lr
    // 0x1140c30: LoadField: d0 = r0->field_7
    //     0x1140c30: ldur            d0, [x0, #7]
    // 0x1140c34: d1 = 14.000000
    //     0x1140c34: fmov            d1, #14.00000000
    // 0x1140c38: fdiv            d2, d0, d1
    // 0x1140c3c: stur            d2, [fp, #-0x18]
    // 0x1140c40: r0 = EdgeInsets()
    //     0x1140c40: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x1140c44: ldur            d0, [fp, #-0x20]
    // 0x1140c48: stur            x0, [fp, #-8]
    // 0x1140c4c: StoreField: r0->field_7 = d0
    //     0x1140c4c: stur            d0, [x0, #7]
    // 0x1140c50: StoreField: r0->field_f = rZR
    //     0x1140c50: stur            xzr, [x0, #0xf]
    // 0x1140c54: ArrayStore: r0[0] = d0  ; List_8
    //     0x1140c54: stur            d0, [x0, #0x17]
    // 0x1140c58: StoreField: r0->field_1f = rZR
    //     0x1140c58: stur            xzr, [x0, #0x1f]
    // 0x1140c5c: d1 = 2.000000
    //     0x1140c5c: fmov            d1, #2.00000000
    // 0x1140c60: fdiv            d2, d0, d1
    // 0x1140c64: stur            d2, [fp, #-0x28]
    // 0x1140c68: r0 = EdgeInsets()
    //     0x1140c68: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x1140c6c: ldur            d0, [fp, #-0x28]
    // 0x1140c70: stur            x0, [fp, #-0x10]
    // 0x1140c74: StoreField: r0->field_7 = d0
    //     0x1140c74: stur            d0, [x0, #7]
    // 0x1140c78: StoreField: r0->field_f = rZR
    //     0x1140c78: stur            xzr, [x0, #0xf]
    // 0x1140c7c: ArrayStore: r0[0] = d0  ; List_8
    //     0x1140c7c: stur            d0, [x0, #0x17]
    // 0x1140c80: StoreField: r0->field_1f = rZR
    //     0x1140c80: stur            xzr, [x0, #0x1f]
    // 0x1140c84: d1 = 2.000000
    //     0x1140c84: fmov            d1, #2.00000000
    // 0x1140c88: fdiv            d2, d0, d1
    // 0x1140c8c: stur            d2, [fp, #-0x20]
    // 0x1140c90: r0 = EdgeInsets()
    //     0x1140c90: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x1140c94: ldur            d0, [fp, #-0x20]
    // 0x1140c98: StoreField: r0->field_7 = d0
    //     0x1140c98: stur            d0, [x0, #7]
    // 0x1140c9c: StoreField: r0->field_f = rZR
    //     0x1140c9c: stur            xzr, [x0, #0xf]
    // 0x1140ca0: ArrayStore: r0[0] = d0  ; List_8
    //     0x1140ca0: stur            d0, [x0, #0x17]
    // 0x1140ca4: StoreField: r0->field_1f = rZR
    //     0x1140ca4: stur            xzr, [x0, #0x1f]
    // 0x1140ca8: ldur            x1, [fp, #-8]
    // 0x1140cac: ldur            x2, [fp, #-0x10]
    // 0x1140cb0: mov             x3, x0
    // 0x1140cb4: ldur            d0, [fp, #-0x18]
    // 0x1140cb8: r0 = scaledPadding()
    //     0x1140cb8: bl              #0x1140cd0  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::scaledPadding
    // 0x1140cbc: LeaveFrame
    //     0x1140cbc: mov             SP, fp
    //     0x1140cc0: ldp             fp, lr, [SP], #0x10
    // 0x1140cc4: ret
    //     0x1140cc4: ret             
    // 0x1140cc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1140cc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1140ccc: b               #0x1140bb0
  }
}

// class id: 5199, size: 0x74, field offset: 0x6c
class _ElevatedButtonDefaultsM3 extends ButtonStyle {

  late final ColorScheme _colors; // offset: 0x70

  get _ padding(/* No info */) {
    // ** addr: 0x1140b3c, size: 0x54
    // 0x1140b3c: EnterFrame
    //     0x1140b3c: stp             fp, lr, [SP, #-0x10]!
    //     0x1140b40: mov             fp, SP
    // 0x1140b44: AllocStack(0x8)
    //     0x1140b44: sub             SP, SP, #8
    // 0x1140b48: CheckStackOverflow
    //     0x1140b48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1140b4c: cmp             SP, x16
    //     0x1140b50: b.ls            #0x1140b88
    // 0x1140b54: LoadField: r0 = r1->field_6b
    //     0x1140b54: ldur            w0, [x1, #0x6b]
    // 0x1140b58: DecompressPointer r0
    //     0x1140b58: add             x0, x0, HEAP, lsl #32
    // 0x1140b5c: mov             x1, x0
    // 0x1140b60: r0 = _scaledPadding()
    //     0x1140b60: bl              #0x1140b90  ; [package:flutter/src/material/elevated_button.dart] ::_scaledPadding
    // 0x1140b64: r1 = <EdgeInsetsGeometry>
    //     0x1140b64: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a98] TypeArguments: <EdgeInsetsGeometry>
    //     0x1140b68: ldr             x1, [x1, #0xa98]
    // 0x1140b6c: stur            x0, [fp, #-8]
    // 0x1140b70: r0 = WidgetStatePropertyAll()
    //     0x1140b70: bl              #0xd132c8  ; AllocateWidgetStatePropertyAllStub -> WidgetStatePropertyAll<X0> (size=0x10)
    // 0x1140b74: ldur            x1, [fp, #-8]
    // 0x1140b78: StoreField: r0->field_b = r1
    //     0x1140b78: stur            w1, [x0, #0xb]
    // 0x1140b7c: LeaveFrame
    //     0x1140b7c: mov             SP, fp
    //     0x1140b80: ldp             fp, lr, [SP], #0x10
    // 0x1140b84: ret
    //     0x1140b84: ret             
    // 0x1140b88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1140b88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1140b8c: b               #0x1140b54
  }
  get _ iconColor(/* No info */) {
    // ** addr: 0x1151d68, size: 0x68
    // 0x1151d68: EnterFrame
    //     0x1151d68: stp             fp, lr, [SP, #-0x10]!
    //     0x1151d6c: mov             fp, SP
    // 0x1151d70: AllocStack(0x18)
    //     0x1151d70: sub             SP, SP, #0x18
    // 0x1151d74: SetupParameters(_ElevatedButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x1151d74: stur            x1, [fp, #-8]
    // 0x1151d78: CheckStackOverflow
    //     0x1151d78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1151d7c: cmp             SP, x16
    //     0x1151d80: b.ls            #0x1151dc8
    // 0x1151d84: r1 = 1
    //     0x1151d84: mov             x1, #1
    // 0x1151d88: r0 = AllocateContext()
    //     0x1151d88: bl              #0x13de838  ; AllocateContextStub
    // 0x1151d8c: mov             x1, x0
    // 0x1151d90: ldur            x0, [fp, #-8]
    // 0x1151d94: StoreField: r1->field_f = r0
    //     0x1151d94: stur            w0, [x1, #0xf]
    // 0x1151d98: mov             x2, x1
    // 0x1151d9c: r1 = Function '<anonymous closure>':.
    //     0x1151d9c: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0ef8] AnonymousClosure: (0x1151dd0), in [package:flutter/src/material/elevated_button.dart] _ElevatedButtonDefaultsM3::iconColor (0x1151d68)
    //     0x1151da0: ldr             x1, [x1, #0xef8]
    // 0x1151da4: r0 = AllocateClosure()
    //     0x1151da4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1151da8: r16 = <Color>
    //     0x1151da8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1151dac: ldr             x16, [x16, #0xa90]
    // 0x1151db0: stp             x0, x16, [SP]
    // 0x1151db4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1151db4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1151db8: r0 = resolveWith()
    //     0x1151db8: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1151dbc: LeaveFrame
    //     0x1151dbc: mov             SP, fp
    //     0x1151dc0: ldp             fp, lr, [SP], #0x10
    // 0x1151dc4: ret
    //     0x1151dc4: ret             
    // 0x1151dc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1151dc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1151dcc: b               #0x1151d84
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x1151dd0, size: 0x264
    // 0x1151dd0: EnterFrame
    //     0x1151dd0: stp             fp, lr, [SP, #-0x10]!
    //     0x1151dd4: mov             fp, SP
    // 0x1151dd8: AllocStack(0x8)
    //     0x1151dd8: sub             SP, SP, #8
    // 0x1151ddc: SetupParameters([dynamic _ /* r0 */])
    //     0x1151ddc: ldr             x0, [fp, #0x18]
    //     0x1151de0: ldur            w3, [x0, #0x17]
    //     0x1151de4: add             x3, x3, HEAP, lsl #32
    //     0x1151de8: stur            x3, [fp, #-8]
    // 0x1151dec: CheckStackOverflow
    //     0x1151dec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1151df0: cmp             SP, x16
    //     0x1151df4: b.ls            #0x115202c
    // 0x1151df8: ldr             x4, [fp, #0x10]
    // 0x1151dfc: r0 = LoadClassIdInstr(r4)
    //     0x1151dfc: ldur            x0, [x4, #-1]
    //     0x1151e00: ubfx            x0, x0, #0xc, #0x14
    // 0x1151e04: mov             x1, x4
    // 0x1151e08: r2 = Instance_WidgetState
    //     0x1151e08: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0x1151e0c: ldr             x2, [x2, #0xa70]
    // 0x1151e10: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1151e10: mov             x17, #0x2929
    //     0x1151e14: movk            x17, #1, lsl #16
    //     0x1151e18: add             lr, x0, x17
    //     0x1151e1c: ldr             lr, [x21, lr, lsl #3]
    //     0x1151e20: blr             lr
    // 0x1151e24: tbnz            w0, #4, #0x1151e84
    // 0x1151e28: ldur            x3, [fp, #-8]
    // 0x1151e2c: LoadField: r1 = r3->field_f
    //     0x1151e2c: ldur            w1, [x3, #0xf]
    // 0x1151e30: DecompressPointer r1
    //     0x1151e30: add             x1, x1, HEAP, lsl #32
    // 0x1151e34: LoadField: r0 = r1->field_6f
    //     0x1151e34: ldur            w0, [x1, #0x6f]
    // 0x1151e38: DecompressPointer r0
    //     0x1151e38: add             x0, x0, HEAP, lsl #32
    // 0x1151e3c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1151e40: cmp             w0, w16
    // 0x1151e44: b.ne            #0x1151e54
    // 0x1151e48: r2 = _colors
    //     0x1151e48: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0f00] Field <_ElevatedButtonDefaultsM3@744256481._colors@744256481>: late final (offset: 0x70)
    //     0x1151e4c: ldr             x2, [x2, #0xf00]
    // 0x1151e50: r0 = InitLateFinalInstanceField()
    //     0x1151e50: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1151e54: LoadField: r1 = r0->field_7f
    //     0x1151e54: ldur            w1, [x0, #0x7f]
    // 0x1151e58: DecompressPointer r1
    //     0x1151e58: add             x1, x1, HEAP, lsl #32
    // 0x1151e5c: r0 = LoadClassIdInstr(r1)
    //     0x1151e5c: ldur            x0, [x1, #-1]
    //     0x1151e60: ubfx            x0, x0, #0xc, #0x14
    // 0x1151e64: d0 = 0.380000
    //     0x1151e64: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1151e68: ldr             d0, [x17, #0x1f0]
    // 0x1151e6c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1151e6c: sub             lr, x0, #1, lsl #12
    //     0x1151e70: ldr             lr, [x21, lr, lsl #3]
    //     0x1151e74: blr             lr
    // 0x1151e78: LeaveFrame
    //     0x1151e78: mov             SP, fp
    //     0x1151e7c: ldp             fp, lr, [SP], #0x10
    // 0x1151e80: ret
    //     0x1151e80: ret             
    // 0x1151e84: ldr             x4, [fp, #0x10]
    // 0x1151e88: ldur            x3, [fp, #-8]
    // 0x1151e8c: r0 = LoadClassIdInstr(r4)
    //     0x1151e8c: ldur            x0, [x4, #-1]
    //     0x1151e90: ubfx            x0, x0, #0xc, #0x14
    // 0x1151e94: mov             x1, x4
    // 0x1151e98: r2 = Instance_WidgetState
    //     0x1151e98: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0x1151e9c: ldr             x2, [x2, #0xa48]
    // 0x1151ea0: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1151ea0: mov             x17, #0x2929
    //     0x1151ea4: movk            x17, #1, lsl #16
    //     0x1151ea8: add             lr, x0, x17
    //     0x1151eac: ldr             lr, [x21, lr, lsl #3]
    //     0x1151eb0: blr             lr
    // 0x1151eb4: tbnz            w0, #4, #0x1151efc
    // 0x1151eb8: ldur            x3, [fp, #-8]
    // 0x1151ebc: LoadField: r1 = r3->field_f
    //     0x1151ebc: ldur            w1, [x3, #0xf]
    // 0x1151ec0: DecompressPointer r1
    //     0x1151ec0: add             x1, x1, HEAP, lsl #32
    // 0x1151ec4: LoadField: r0 = r1->field_6f
    //     0x1151ec4: ldur            w0, [x1, #0x6f]
    // 0x1151ec8: DecompressPointer r0
    //     0x1151ec8: add             x0, x0, HEAP, lsl #32
    // 0x1151ecc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1151ed0: cmp             w0, w16
    // 0x1151ed4: b.ne            #0x1151ee4
    // 0x1151ed8: r2 = _colors
    //     0x1151ed8: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0f00] Field <_ElevatedButtonDefaultsM3@744256481._colors@744256481>: late final (offset: 0x70)
    //     0x1151edc: ldr             x2, [x2, #0xf00]
    // 0x1151ee0: r0 = InitLateFinalInstanceField()
    //     0x1151ee0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1151ee4: LoadField: r1 = r0->field_b
    //     0x1151ee4: ldur            w1, [x0, #0xb]
    // 0x1151ee8: DecompressPointer r1
    //     0x1151ee8: add             x1, x1, HEAP, lsl #32
    // 0x1151eec: mov             x0, x1
    // 0x1151ef0: LeaveFrame
    //     0x1151ef0: mov             SP, fp
    //     0x1151ef4: ldp             fp, lr, [SP], #0x10
    // 0x1151ef8: ret
    //     0x1151ef8: ret             
    // 0x1151efc: ldr             x4, [fp, #0x10]
    // 0x1151f00: ldur            x3, [fp, #-8]
    // 0x1151f04: r0 = LoadClassIdInstr(r4)
    //     0x1151f04: ldur            x0, [x4, #-1]
    //     0x1151f08: ubfx            x0, x0, #0xc, #0x14
    // 0x1151f0c: mov             x1, x4
    // 0x1151f10: r2 = Instance_WidgetState
    //     0x1151f10: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0x1151f14: ldr             x2, [x2, #0xa50]
    // 0x1151f18: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1151f18: mov             x17, #0x2929
    //     0x1151f1c: movk            x17, #1, lsl #16
    //     0x1151f20: add             lr, x0, x17
    //     0x1151f24: ldr             lr, [x21, lr, lsl #3]
    //     0x1151f28: blr             lr
    // 0x1151f2c: tbnz            w0, #4, #0x1151f74
    // 0x1151f30: ldur            x3, [fp, #-8]
    // 0x1151f34: LoadField: r1 = r3->field_f
    //     0x1151f34: ldur            w1, [x3, #0xf]
    // 0x1151f38: DecompressPointer r1
    //     0x1151f38: add             x1, x1, HEAP, lsl #32
    // 0x1151f3c: LoadField: r0 = r1->field_6f
    //     0x1151f3c: ldur            w0, [x1, #0x6f]
    // 0x1151f40: DecompressPointer r0
    //     0x1151f40: add             x0, x0, HEAP, lsl #32
    // 0x1151f44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1151f48: cmp             w0, w16
    // 0x1151f4c: b.ne            #0x1151f5c
    // 0x1151f50: r2 = _colors
    //     0x1151f50: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0f00] Field <_ElevatedButtonDefaultsM3@744256481._colors@744256481>: late final (offset: 0x70)
    //     0x1151f54: ldr             x2, [x2, #0xf00]
    // 0x1151f58: r0 = InitLateFinalInstanceField()
    //     0x1151f58: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1151f5c: LoadField: r1 = r0->field_b
    //     0x1151f5c: ldur            w1, [x0, #0xb]
    // 0x1151f60: DecompressPointer r1
    //     0x1151f60: add             x1, x1, HEAP, lsl #32
    // 0x1151f64: mov             x0, x1
    // 0x1151f68: LeaveFrame
    //     0x1151f68: mov             SP, fp
    //     0x1151f6c: ldp             fp, lr, [SP], #0x10
    // 0x1151f70: ret
    //     0x1151f70: ret             
    // 0x1151f74: ldr             x1, [fp, #0x10]
    // 0x1151f78: ldur            x3, [fp, #-8]
    // 0x1151f7c: r0 = LoadClassIdInstr(r1)
    //     0x1151f7c: ldur            x0, [x1, #-1]
    //     0x1151f80: ubfx            x0, x0, #0xc, #0x14
    // 0x1151f84: r2 = Instance_WidgetState
    //     0x1151f84: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0x1151f88: ldr             x2, [x2, #0xa60]
    // 0x1151f8c: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1151f8c: mov             x17, #0x2929
    //     0x1151f90: movk            x17, #1, lsl #16
    //     0x1151f94: add             lr, x0, x17
    //     0x1151f98: ldr             lr, [x21, lr, lsl #3]
    //     0x1151f9c: blr             lr
    // 0x1151fa0: tbnz            w0, #4, #0x1151fe8
    // 0x1151fa4: ldur            x0, [fp, #-8]
    // 0x1151fa8: LoadField: r1 = r0->field_f
    //     0x1151fa8: ldur            w1, [x0, #0xf]
    // 0x1151fac: DecompressPointer r1
    //     0x1151fac: add             x1, x1, HEAP, lsl #32
    // 0x1151fb0: LoadField: r0 = r1->field_6f
    //     0x1151fb0: ldur            w0, [x1, #0x6f]
    // 0x1151fb4: DecompressPointer r0
    //     0x1151fb4: add             x0, x0, HEAP, lsl #32
    // 0x1151fb8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1151fbc: cmp             w0, w16
    // 0x1151fc0: b.ne            #0x1151fd0
    // 0x1151fc4: r2 = _colors
    //     0x1151fc4: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0f00] Field <_ElevatedButtonDefaultsM3@744256481._colors@744256481>: late final (offset: 0x70)
    //     0x1151fc8: ldr             x2, [x2, #0xf00]
    // 0x1151fcc: r0 = InitLateFinalInstanceField()
    //     0x1151fcc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1151fd0: LoadField: r1 = r0->field_b
    //     0x1151fd0: ldur            w1, [x0, #0xb]
    // 0x1151fd4: DecompressPointer r1
    //     0x1151fd4: add             x1, x1, HEAP, lsl #32
    // 0x1151fd8: mov             x0, x1
    // 0x1151fdc: LeaveFrame
    //     0x1151fdc: mov             SP, fp
    //     0x1151fe0: ldp             fp, lr, [SP], #0x10
    // 0x1151fe4: ret
    //     0x1151fe4: ret             
    // 0x1151fe8: ldur            x0, [fp, #-8]
    // 0x1151fec: LoadField: r1 = r0->field_f
    //     0x1151fec: ldur            w1, [x0, #0xf]
    // 0x1151ff0: DecompressPointer r1
    //     0x1151ff0: add             x1, x1, HEAP, lsl #32
    // 0x1151ff4: LoadField: r0 = r1->field_6f
    //     0x1151ff4: ldur            w0, [x1, #0x6f]
    // 0x1151ff8: DecompressPointer r0
    //     0x1151ff8: add             x0, x0, HEAP, lsl #32
    // 0x1151ffc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1152000: cmp             w0, w16
    // 0x1152004: b.ne            #0x1152014
    // 0x1152008: r2 = _colors
    //     0x1152008: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0f00] Field <_ElevatedButtonDefaultsM3@744256481._colors@744256481>: late final (offset: 0x70)
    //     0x115200c: ldr             x2, [x2, #0xf00]
    // 0x1152010: r0 = InitLateFinalInstanceField()
    //     0x1152010: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1152014: LoadField: r1 = r0->field_b
    //     0x1152014: ldur            w1, [x0, #0xb]
    // 0x1152018: DecompressPointer r1
    //     0x1152018: add             x1, x1, HEAP, lsl #32
    // 0x115201c: mov             x0, x1
    // 0x1152020: LeaveFrame
    //     0x1152020: mov             SP, fp
    //     0x1152024: ldp             fp, lr, [SP], #0x10
    // 0x1152028: ret
    //     0x1152028: ret             
    // 0x115202c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x115202c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1152030: b               #0x1151df8
  }
  get _ backgroundColor(/* No info */) {
    // ** addr: 0x1240850, size: 0x68
    // 0x1240850: EnterFrame
    //     0x1240850: stp             fp, lr, [SP, #-0x10]!
    //     0x1240854: mov             fp, SP
    // 0x1240858: AllocStack(0x18)
    //     0x1240858: sub             SP, SP, #0x18
    // 0x124085c: SetupParameters(_ElevatedButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x124085c: stur            x1, [fp, #-8]
    // 0x1240860: CheckStackOverflow
    //     0x1240860: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1240864: cmp             SP, x16
    //     0x1240868: b.ls            #0x12408b0
    // 0x124086c: r1 = 1
    //     0x124086c: mov             x1, #1
    // 0x1240870: r0 = AllocateContext()
    //     0x1240870: bl              #0x13de838  ; AllocateContextStub
    // 0x1240874: mov             x1, x0
    // 0x1240878: ldur            x0, [fp, #-8]
    // 0x124087c: StoreField: r1->field_f = r0
    //     0x124087c: stur            w0, [x1, #0xf]
    // 0x1240880: mov             x2, x1
    // 0x1240884: r1 = Function '<anonymous closure>':.
    //     0x1240884: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0f20] AnonymousClosure: (0x12408b8), in [package:flutter/src/material/elevated_button.dart] _ElevatedButtonDefaultsM3::backgroundColor (0x1240850)
    //     0x1240888: ldr             x1, [x1, #0xf20]
    // 0x124088c: r0 = AllocateClosure()
    //     0x124088c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1240890: r16 = <Color?>
    //     0x1240890: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1240894: ldr             x16, [x16, #0xa40]
    // 0x1240898: stp             x0, x16, [SP]
    // 0x124089c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x124089c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12408a0: r0 = resolveWith()
    //     0x12408a0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x12408a4: LeaveFrame
    //     0x12408a4: mov             SP, fp
    //     0x12408a8: ldp             fp, lr, [SP], #0x10
    // 0x12408ac: ret
    //     0x12408ac: ret             
    // 0x12408b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12408b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12408b4: b               #0x124086c
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x12408b8, size: 0x114
    // 0x12408b8: EnterFrame
    //     0x12408b8: stp             fp, lr, [SP, #-0x10]!
    //     0x12408bc: mov             fp, SP
    // 0x12408c0: AllocStack(0x8)
    //     0x12408c0: sub             SP, SP, #8
    // 0x12408c4: SetupParameters([dynamic _ /* r0 */])
    //     0x12408c4: ldr             x0, [fp, #0x18]
    //     0x12408c8: ldur            w3, [x0, #0x17]
    //     0x12408cc: add             x3, x3, HEAP, lsl #32
    //     0x12408d0: stur            x3, [fp, #-8]
    // 0x12408d4: CheckStackOverflow
    //     0x12408d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12408d8: cmp             SP, x16
    //     0x12408dc: b.ls            #0x12409c4
    // 0x12408e0: ldr             x1, [fp, #0x10]
    // 0x12408e4: r0 = LoadClassIdInstr(r1)
    //     0x12408e4: ldur            x0, [x1, #-1]
    //     0x12408e8: ubfx            x0, x0, #0xc, #0x14
    // 0x12408ec: r2 = Instance_WidgetState
    //     0x12408ec: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0x12408f0: ldr             x2, [x2, #0xa70]
    // 0x12408f4: r0 = GDT[cid_x0 + 0x12929]()
    //     0x12408f4: mov             x17, #0x2929
    //     0x12408f8: movk            x17, #1, lsl #16
    //     0x12408fc: add             lr, x0, x17
    //     0x1240900: ldr             lr, [x21, lr, lsl #3]
    //     0x1240904: blr             lr
    // 0x1240908: tbnz            w0, #4, #0x1240968
    // 0x124090c: ldur            x0, [fp, #-8]
    // 0x1240910: LoadField: r1 = r0->field_f
    //     0x1240910: ldur            w1, [x0, #0xf]
    // 0x1240914: DecompressPointer r1
    //     0x1240914: add             x1, x1, HEAP, lsl #32
    // 0x1240918: LoadField: r0 = r1->field_6f
    //     0x1240918: ldur            w0, [x1, #0x6f]
    // 0x124091c: DecompressPointer r0
    //     0x124091c: add             x0, x0, HEAP, lsl #32
    // 0x1240920: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1240924: cmp             w0, w16
    // 0x1240928: b.ne            #0x1240938
    // 0x124092c: r2 = _colors
    //     0x124092c: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0f00] Field <_ElevatedButtonDefaultsM3@744256481._colors@744256481>: late final (offset: 0x70)
    //     0x1240930: ldr             x2, [x2, #0xf00]
    // 0x1240934: r0 = InitLateFinalInstanceField()
    //     0x1240934: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1240938: LoadField: r1 = r0->field_7f
    //     0x1240938: ldur            w1, [x0, #0x7f]
    // 0x124093c: DecompressPointer r1
    //     0x124093c: add             x1, x1, HEAP, lsl #32
    // 0x1240940: r0 = LoadClassIdInstr(r1)
    //     0x1240940: ldur            x0, [x1, #-1]
    //     0x1240944: ubfx            x0, x0, #0xc, #0x14
    // 0x1240948: d0 = 0.120000
    //     0x1240948: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x124094c: ldr             d0, [x17, #0xc40]
    // 0x1240950: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1240950: sub             lr, x0, #1, lsl #12
    //     0x1240954: ldr             lr, [x21, lr, lsl #3]
    //     0x1240958: blr             lr
    // 0x124095c: LeaveFrame
    //     0x124095c: mov             SP, fp
    //     0x1240960: ldp             fp, lr, [SP], #0x10
    // 0x1240964: ret
    //     0x1240964: ret             
    // 0x1240968: ldur            x0, [fp, #-8]
    // 0x124096c: LoadField: r1 = r0->field_f
    //     0x124096c: ldur            w1, [x0, #0xf]
    // 0x1240970: DecompressPointer r1
    //     0x1240970: add             x1, x1, HEAP, lsl #32
    // 0x1240974: LoadField: r0 = r1->field_6f
    //     0x1240974: ldur            w0, [x1, #0x6f]
    // 0x1240978: DecompressPointer r0
    //     0x1240978: add             x0, x0, HEAP, lsl #32
    // 0x124097c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1240980: cmp             w0, w16
    // 0x1240984: b.ne            #0x1240994
    // 0x1240988: r2 = _colors
    //     0x1240988: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0f00] Field <_ElevatedButtonDefaultsM3@744256481._colors@744256481>: late final (offset: 0x70)
    //     0x124098c: ldr             x2, [x2, #0xf00]
    // 0x1240990: r0 = InitLateFinalInstanceField()
    //     0x1240990: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1240994: LoadField: r1 = r0->field_93
    //     0x1240994: ldur            w1, [x0, #0x93]
    // 0x1240998: DecompressPointer r1
    //     0x1240998: add             x1, x1, HEAP, lsl #32
    // 0x124099c: cmp             w1, NULL
    // 0x12409a0: b.ne            #0x12409b4
    // 0x12409a4: LoadField: r2 = r0->field_7b
    //     0x12409a4: ldur            w2, [x0, #0x7b]
    // 0x12409a8: DecompressPointer r2
    //     0x12409a8: add             x2, x2, HEAP, lsl #32
    // 0x12409ac: mov             x0, x2
    // 0x12409b0: b               #0x12409b8
    // 0x12409b4: mov             x0, x1
    // 0x12409b8: LeaveFrame
    //     0x12409b8: mov             SP, fp
    //     0x12409bc: ldp             fp, lr, [SP], #0x10
    // 0x12409c0: ret
    //     0x12409c0: ret             
    // 0x12409c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12409c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12409c8: b               #0x12408e0
  }
  get _ overlayColor(/* No info */) {
    // ** addr: 0x1241f54, size: 0x68
    // 0x1241f54: EnterFrame
    //     0x1241f54: stp             fp, lr, [SP, #-0x10]!
    //     0x1241f58: mov             fp, SP
    // 0x1241f5c: AllocStack(0x18)
    //     0x1241f5c: sub             SP, SP, #0x18
    // 0x1241f60: SetupParameters(_ElevatedButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x1241f60: stur            x1, [fp, #-8]
    // 0x1241f64: CheckStackOverflow
    //     0x1241f64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1241f68: cmp             SP, x16
    //     0x1241f6c: b.ls            #0x1241fb4
    // 0x1241f70: r1 = 1
    //     0x1241f70: mov             x1, #1
    // 0x1241f74: r0 = AllocateContext()
    //     0x1241f74: bl              #0x13de838  ; AllocateContextStub
    // 0x1241f78: mov             x1, x0
    // 0x1241f7c: ldur            x0, [fp, #-8]
    // 0x1241f80: StoreField: r1->field_f = r0
    //     0x1241f80: stur            w0, [x1, #0xf]
    // 0x1241f84: mov             x2, x1
    // 0x1241f88: r1 = Function '<anonymous closure>':.
    //     0x1241f88: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0f10] AnonymousClosure: (0x1241fbc), in [package:flutter/src/material/elevated_button.dart] _ElevatedButtonDefaultsM3::overlayColor (0x1241f54)
    //     0x1241f8c: ldr             x1, [x1, #0xf10]
    // 0x1241f90: r0 = AllocateClosure()
    //     0x1241f90: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1241f94: r16 = <Color?>
    //     0x1241f94: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1241f98: ldr             x16, [x16, #0xa40]
    // 0x1241f9c: stp             x0, x16, [SP]
    // 0x1241fa0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1241fa0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1241fa4: r0 = resolveWith()
    //     0x1241fa4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1241fa8: LeaveFrame
    //     0x1241fa8: mov             SP, fp
    //     0x1241fac: ldp             fp, lr, [SP], #0x10
    // 0x1241fb0: ret
    //     0x1241fb0: ret             
    // 0x1241fb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1241fb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1241fb8: b               #0x1241f70
  }
  [closure] Color? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x1241fbc, size: 0x1b8
    // 0x1241fbc: EnterFrame
    //     0x1241fbc: stp             fp, lr, [SP, #-0x10]!
    //     0x1241fc0: mov             fp, SP
    // 0x1241fc4: AllocStack(0x8)
    //     0x1241fc4: sub             SP, SP, #8
    // 0x1241fc8: SetupParameters([dynamic _ /* r0 */])
    //     0x1241fc8: ldr             x0, [fp, #0x18]
    //     0x1241fcc: ldur            w3, [x0, #0x17]
    //     0x1241fd0: add             x3, x3, HEAP, lsl #32
    //     0x1241fd4: stur            x3, [fp, #-8]
    // 0x1241fd8: CheckStackOverflow
    //     0x1241fd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1241fdc: cmp             SP, x16
    //     0x1241fe0: b.ls            #0x124216c
    // 0x1241fe4: ldr             x4, [fp, #0x10]
    // 0x1241fe8: r0 = LoadClassIdInstr(r4)
    //     0x1241fe8: ldur            x0, [x4, #-1]
    //     0x1241fec: ubfx            x0, x0, #0xc, #0x14
    // 0x1241ff0: mov             x1, x4
    // 0x1241ff4: r2 = Instance_WidgetState
    //     0x1241ff4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0x1241ff8: ldr             x2, [x2, #0xa48]
    // 0x1241ffc: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1241ffc: mov             x17, #0x2929
    //     0x1242000: movk            x17, #1, lsl #16
    //     0x1242004: add             lr, x0, x17
    //     0x1242008: ldr             lr, [x21, lr, lsl #3]
    //     0x124200c: blr             lr
    // 0x1242010: tbnz            w0, #4, #0x1242060
    // 0x1242014: ldur            x3, [fp, #-8]
    // 0x1242018: LoadField: r1 = r3->field_f
    //     0x1242018: ldur            w1, [x3, #0xf]
    // 0x124201c: DecompressPointer r1
    //     0x124201c: add             x1, x1, HEAP, lsl #32
    // 0x1242020: LoadField: r0 = r1->field_6f
    //     0x1242020: ldur            w0, [x1, #0x6f]
    // 0x1242024: DecompressPointer r0
    //     0x1242024: add             x0, x0, HEAP, lsl #32
    // 0x1242028: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124202c: cmp             w0, w16
    // 0x1242030: b.ne            #0x1242040
    // 0x1242034: r2 = _colors
    //     0x1242034: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0f00] Field <_ElevatedButtonDefaultsM3@744256481._colors@744256481>: late final (offset: 0x70)
    //     0x1242038: ldr             x2, [x2, #0xf00]
    // 0x124203c: r0 = InitLateFinalInstanceField()
    //     0x124203c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1242040: LoadField: r1 = r0->field_b
    //     0x1242040: ldur            w1, [x0, #0xb]
    // 0x1242044: DecompressPointer r1
    //     0x1242044: add             x1, x1, HEAP, lsl #32
    // 0x1242048: d0 = 0.100000
    //     0x1242048: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x124204c: ldr             d0, [x17, #0x1e0]
    // 0x1242050: r0 = withOpacity()
    //     0x1242050: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1242054: LeaveFrame
    //     0x1242054: mov             SP, fp
    //     0x1242058: ldp             fp, lr, [SP], #0x10
    // 0x124205c: ret
    //     0x124205c: ret             
    // 0x1242060: ldr             x4, [fp, #0x10]
    // 0x1242064: ldur            x3, [fp, #-8]
    // 0x1242068: r0 = LoadClassIdInstr(r4)
    //     0x1242068: ldur            x0, [x4, #-1]
    //     0x124206c: ubfx            x0, x0, #0xc, #0x14
    // 0x1242070: mov             x1, x4
    // 0x1242074: r2 = Instance_WidgetState
    //     0x1242074: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0x1242078: ldr             x2, [x2, #0xa50]
    // 0x124207c: r0 = GDT[cid_x0 + 0x12929]()
    //     0x124207c: mov             x17, #0x2929
    //     0x1242080: movk            x17, #1, lsl #16
    //     0x1242084: add             lr, x0, x17
    //     0x1242088: ldr             lr, [x21, lr, lsl #3]
    //     0x124208c: blr             lr
    // 0x1242090: tbnz            w0, #4, #0x12420e0
    // 0x1242094: ldur            x3, [fp, #-8]
    // 0x1242098: LoadField: r1 = r3->field_f
    //     0x1242098: ldur            w1, [x3, #0xf]
    // 0x124209c: DecompressPointer r1
    //     0x124209c: add             x1, x1, HEAP, lsl #32
    // 0x12420a0: LoadField: r0 = r1->field_6f
    //     0x12420a0: ldur            w0, [x1, #0x6f]
    // 0x12420a4: DecompressPointer r0
    //     0x12420a4: add             x0, x0, HEAP, lsl #32
    // 0x12420a8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12420ac: cmp             w0, w16
    // 0x12420b0: b.ne            #0x12420c0
    // 0x12420b4: r2 = _colors
    //     0x12420b4: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0f00] Field <_ElevatedButtonDefaultsM3@744256481._colors@744256481>: late final (offset: 0x70)
    //     0x12420b8: ldr             x2, [x2, #0xf00]
    // 0x12420bc: r0 = InitLateFinalInstanceField()
    //     0x12420bc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12420c0: LoadField: r1 = r0->field_b
    //     0x12420c0: ldur            w1, [x0, #0xb]
    // 0x12420c4: DecompressPointer r1
    //     0x12420c4: add             x1, x1, HEAP, lsl #32
    // 0x12420c8: d0 = 0.080000
    //     0x12420c8: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x12420cc: ldr             d0, [x17, #0xa58]
    // 0x12420d0: r0 = withOpacity()
    //     0x12420d0: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x12420d4: LeaveFrame
    //     0x12420d4: mov             SP, fp
    //     0x12420d8: ldp             fp, lr, [SP], #0x10
    // 0x12420dc: ret
    //     0x12420dc: ret             
    // 0x12420e0: ldr             x1, [fp, #0x10]
    // 0x12420e4: ldur            x3, [fp, #-8]
    // 0x12420e8: r0 = LoadClassIdInstr(r1)
    //     0x12420e8: ldur            x0, [x1, #-1]
    //     0x12420ec: ubfx            x0, x0, #0xc, #0x14
    // 0x12420f0: r2 = Instance_WidgetState
    //     0x12420f0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0x12420f4: ldr             x2, [x2, #0xa60]
    // 0x12420f8: r0 = GDT[cid_x0 + 0x12929]()
    //     0x12420f8: mov             x17, #0x2929
    //     0x12420fc: movk            x17, #1, lsl #16
    //     0x1242100: add             lr, x0, x17
    //     0x1242104: ldr             lr, [x21, lr, lsl #3]
    //     0x1242108: blr             lr
    // 0x124210c: tbnz            w0, #4, #0x124215c
    // 0x1242110: ldur            x0, [fp, #-8]
    // 0x1242114: LoadField: r1 = r0->field_f
    //     0x1242114: ldur            w1, [x0, #0xf]
    // 0x1242118: DecompressPointer r1
    //     0x1242118: add             x1, x1, HEAP, lsl #32
    // 0x124211c: LoadField: r0 = r1->field_6f
    //     0x124211c: ldur            w0, [x1, #0x6f]
    // 0x1242120: DecompressPointer r0
    //     0x1242120: add             x0, x0, HEAP, lsl #32
    // 0x1242124: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1242128: cmp             w0, w16
    // 0x124212c: b.ne            #0x124213c
    // 0x1242130: r2 = _colors
    //     0x1242130: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0f00] Field <_ElevatedButtonDefaultsM3@744256481._colors@744256481>: late final (offset: 0x70)
    //     0x1242134: ldr             x2, [x2, #0xf00]
    // 0x1242138: r0 = InitLateFinalInstanceField()
    //     0x1242138: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x124213c: LoadField: r1 = r0->field_b
    //     0x124213c: ldur            w1, [x0, #0xb]
    // 0x1242140: DecompressPointer r1
    //     0x1242140: add             x1, x1, HEAP, lsl #32
    // 0x1242144: d0 = 0.100000
    //     0x1242144: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x1242148: ldr             d0, [x17, #0x1e0]
    // 0x124214c: r0 = withOpacity()
    //     0x124214c: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1242150: LeaveFrame
    //     0x1242150: mov             SP, fp
    //     0x1242154: ldp             fp, lr, [SP], #0x10
    // 0x1242158: ret
    //     0x1242158: ret             
    // 0x124215c: r0 = Null
    //     0x124215c: mov             x0, NULL
    // 0x1242160: LeaveFrame
    //     0x1242160: mov             SP, fp
    //     0x1242164: ldp             fp, lr, [SP], #0x10
    // 0x1242168: ret
    //     0x1242168: ret             
    // 0x124216c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124216c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1242170: b               #0x1241fe4
  }
  get _ shadowColor(/* No info */) {
    // ** addr: 0x1243838, size: 0x84
    // 0x1243838: EnterFrame
    //     0x1243838: stp             fp, lr, [SP, #-0x10]!
    //     0x124383c: mov             fp, SP
    // 0x1243840: AllocStack(0x8)
    //     0x1243840: sub             SP, SP, #8
    // 0x1243844: CheckStackOverflow
    //     0x1243844: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1243848: cmp             SP, x16
    //     0x124384c: b.ls            #0x12438b4
    // 0x1243850: LoadField: r0 = r1->field_6f
    //     0x1243850: ldur            w0, [x1, #0x6f]
    // 0x1243854: DecompressPointer r0
    //     0x1243854: add             x0, x0, HEAP, lsl #32
    // 0x1243858: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124385c: cmp             w0, w16
    // 0x1243860: b.ne            #0x1243870
    // 0x1243864: r2 = _colors
    //     0x1243864: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0f00] Field <_ElevatedButtonDefaultsM3@744256481._colors@744256481>: late final (offset: 0x70)
    //     0x1243868: ldr             x2, [x2, #0xf00]
    // 0x124386c: r0 = InitLateFinalInstanceField()
    //     0x124386c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1243870: LoadField: r1 = r0->field_af
    //     0x1243870: ldur            w1, [x0, #0xaf]
    // 0x1243874: DecompressPointer r1
    //     0x1243874: add             x1, x1, HEAP, lsl #32
    // 0x1243878: cmp             w1, NULL
    // 0x124387c: b.ne            #0x124388c
    // 0x1243880: r0 = Instance_Color
    //     0x1243880: add             x0, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x1243884: ldr             x0, [x0, #0x948]
    // 0x1243888: b               #0x1243890
    // 0x124388c: mov             x0, x1
    // 0x1243890: stur            x0, [fp, #-8]
    // 0x1243894: r1 = <Color>
    //     0x1243894: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1243898: ldr             x1, [x1, #0xa90]
    // 0x124389c: r0 = WidgetStatePropertyAll()
    //     0x124389c: bl              #0xd132c8  ; AllocateWidgetStatePropertyAllStub -> WidgetStatePropertyAll<X0> (size=0x10)
    // 0x12438a0: ldur            x1, [fp, #-8]
    // 0x12438a4: StoreField: r0->field_b = r1
    //     0x12438a4: stur            w1, [x0, #0xb]
    // 0x12438a8: LeaveFrame
    //     0x12438a8: mov             SP, fp
    //     0x12438ac: ldp             fp, lr, [SP], #0x10
    // 0x12438b0: ret
    //     0x12438b0: ret             
    // 0x12438b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12438b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12438b8: b               #0x1243850
  }
  get _ elevation(/* No info */) {
    // ** addr: 0x124911c, size: 0x4c
    // 0x124911c: EnterFrame
    //     0x124911c: stp             fp, lr, [SP, #-0x10]!
    //     0x1249120: mov             fp, SP
    // 0x1249124: AllocStack(0x10)
    //     0x1249124: sub             SP, SP, #0x10
    // 0x1249128: CheckStackOverflow
    //     0x1249128: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124912c: cmp             SP, x16
    //     0x1249130: b.ls            #0x1249160
    // 0x1249134: r1 = Function '<anonymous closure>':.
    //     0x1249134: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0f08] AnonymousClosure: (0x1249168), in [package:flutter/src/material/elevated_button.dart] _ElevatedButtonDefaultsM3::elevation (0x124911c)
    //     0x1249138: ldr             x1, [x1, #0xf08]
    // 0x124913c: r2 = Null
    //     0x124913c: mov             x2, NULL
    // 0x1249140: r0 = AllocateClosure()
    //     0x1249140: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1249144: r16 = <double>
    //     0x1249144: ldr             x16, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x1249148: stp             x0, x16, [SP]
    // 0x124914c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x124914c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1249150: r0 = resolveWith()
    //     0x1249150: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1249154: LeaveFrame
    //     0x1249154: mov             SP, fp
    //     0x1249158: ldp             fp, lr, [SP], #0x10
    // 0x124915c: ret
    //     0x124915c: ret             
    // 0x1249160: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1249160: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1249164: b               #0x1249134
  }
  [closure] double <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x1249168, size: 0x12c
    // 0x1249168: EnterFrame
    //     0x1249168: stp             fp, lr, [SP, #-0x10]!
    //     0x124916c: mov             fp, SP
    // 0x1249170: CheckStackOverflow
    //     0x1249170: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1249174: cmp             SP, x16
    //     0x1249178: b.ls            #0x124928c
    // 0x124917c: ldr             x3, [fp, #0x10]
    // 0x1249180: r0 = LoadClassIdInstr(r3)
    //     0x1249180: ldur            x0, [x3, #-1]
    //     0x1249184: ubfx            x0, x0, #0xc, #0x14
    // 0x1249188: mov             x1, x3
    // 0x124918c: r2 = Instance_WidgetState
    //     0x124918c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0x1249190: ldr             x2, [x2, #0xa70]
    // 0x1249194: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1249194: mov             x17, #0x2929
    //     0x1249198: movk            x17, #1, lsl #16
    //     0x124919c: add             lr, x0, x17
    //     0x12491a0: ldr             lr, [x21, lr, lsl #3]
    //     0x12491a4: blr             lr
    // 0x12491a8: tbnz            w0, #4, #0x12491bc
    // 0x12491ac: r0 = 0.000000
    //     0x12491ac: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x12491b0: LeaveFrame
    //     0x12491b0: mov             SP, fp
    //     0x12491b4: ldp             fp, lr, [SP], #0x10
    // 0x12491b8: ret
    //     0x12491b8: ret             
    // 0x12491bc: ldr             x3, [fp, #0x10]
    // 0x12491c0: r0 = LoadClassIdInstr(r3)
    //     0x12491c0: ldur            x0, [x3, #-1]
    //     0x12491c4: ubfx            x0, x0, #0xc, #0x14
    // 0x12491c8: mov             x1, x3
    // 0x12491cc: r2 = Instance_WidgetState
    //     0x12491cc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0x12491d0: ldr             x2, [x2, #0xa48]
    // 0x12491d4: r0 = GDT[cid_x0 + 0x12929]()
    //     0x12491d4: mov             x17, #0x2929
    //     0x12491d8: movk            x17, #1, lsl #16
    //     0x12491dc: add             lr, x0, x17
    //     0x12491e0: ldr             lr, [x21, lr, lsl #3]
    //     0x12491e4: blr             lr
    // 0x12491e8: tbnz            w0, #4, #0x12491fc
    // 0x12491ec: r0 = 1.000000
    //     0x12491ec: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x12491f0: LeaveFrame
    //     0x12491f0: mov             SP, fp
    //     0x12491f4: ldp             fp, lr, [SP], #0x10
    // 0x12491f8: ret
    //     0x12491f8: ret             
    // 0x12491fc: ldr             x3, [fp, #0x10]
    // 0x1249200: r0 = LoadClassIdInstr(r3)
    //     0x1249200: ldur            x0, [x3, #-1]
    //     0x1249204: ubfx            x0, x0, #0xc, #0x14
    // 0x1249208: mov             x1, x3
    // 0x124920c: r2 = Instance_WidgetState
    //     0x124920c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0x1249210: ldr             x2, [x2, #0xa50]
    // 0x1249214: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1249214: mov             x17, #0x2929
    //     0x1249218: movk            x17, #1, lsl #16
    //     0x124921c: add             lr, x0, x17
    //     0x1249220: ldr             lr, [x21, lr, lsl #3]
    //     0x1249224: blr             lr
    // 0x1249228: tbnz            w0, #4, #0x1249240
    // 0x124922c: r0 = 3.000000
    //     0x124922c: add             x0, PP, #0x22, lsl #12  ; [pp+0x223f8] 3
    //     0x1249230: ldr             x0, [x0, #0x3f8]
    // 0x1249234: LeaveFrame
    //     0x1249234: mov             SP, fp
    //     0x1249238: ldp             fp, lr, [SP], #0x10
    // 0x124923c: ret
    //     0x124923c: ret             
    // 0x1249240: ldr             x1, [fp, #0x10]
    // 0x1249244: r0 = LoadClassIdInstr(r1)
    //     0x1249244: ldur            x0, [x1, #-1]
    //     0x1249248: ubfx            x0, x0, #0xc, #0x14
    // 0x124924c: r2 = Instance_WidgetState
    //     0x124924c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0x1249250: ldr             x2, [x2, #0xa60]
    // 0x1249254: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1249254: mov             x17, #0x2929
    //     0x1249258: movk            x17, #1, lsl #16
    //     0x124925c: add             lr, x0, x17
    //     0x1249260: ldr             lr, [x21, lr, lsl #3]
    //     0x1249264: blr             lr
    // 0x1249268: tbnz            w0, #4, #0x124927c
    // 0x124926c: r0 = 1.000000
    //     0x124926c: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x1249270: LeaveFrame
    //     0x1249270: mov             SP, fp
    //     0x1249274: ldp             fp, lr, [SP], #0x10
    // 0x1249278: ret
    //     0x1249278: ret             
    // 0x124927c: r0 = 1.000000
    //     0x124927c: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x1249280: LeaveFrame
    //     0x1249280: mov             SP, fp
    //     0x1249284: ldp             fp, lr, [SP], #0x10
    // 0x1249288: ret
    //     0x1249288: ret             
    // 0x124928c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124928c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1249290: b               #0x124917c
  }
  get _ foregroundColor(/* No info */) {
    // ** addr: 0x12495c4, size: 0x68
    // 0x12495c4: EnterFrame
    //     0x12495c4: stp             fp, lr, [SP, #-0x10]!
    //     0x12495c8: mov             fp, SP
    // 0x12495cc: AllocStack(0x18)
    //     0x12495cc: sub             SP, SP, #0x18
    // 0x12495d0: SetupParameters(_ElevatedButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x12495d0: stur            x1, [fp, #-8]
    // 0x12495d4: CheckStackOverflow
    //     0x12495d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12495d8: cmp             SP, x16
    //     0x12495dc: b.ls            #0x1249624
    // 0x12495e0: r1 = 1
    //     0x12495e0: mov             x1, #1
    // 0x12495e4: r0 = AllocateContext()
    //     0x12495e4: bl              #0x13de838  ; AllocateContextStub
    // 0x12495e8: mov             x1, x0
    // 0x12495ec: ldur            x0, [fp, #-8]
    // 0x12495f0: StoreField: r1->field_f = r0
    //     0x12495f0: stur            w0, [x1, #0xf]
    // 0x12495f4: mov             x2, x1
    // 0x12495f8: r1 = Function '<anonymous closure>':.
    //     0x12495f8: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0f18] AnonymousClosure: (0x124962c), in [package:flutter/src/material/elevated_button.dart] _ElevatedButtonDefaultsM3::foregroundColor (0x12495c4)
    //     0x12495fc: ldr             x1, [x1, #0xf18]
    // 0x1249600: r0 = AllocateClosure()
    //     0x1249600: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1249604: r16 = <Color?>
    //     0x1249604: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1249608: ldr             x16, [x16, #0xa40]
    // 0x124960c: stp             x0, x16, [SP]
    // 0x1249610: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1249610: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1249614: r0 = resolveWith()
    //     0x1249614: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1249618: LeaveFrame
    //     0x1249618: mov             SP, fp
    //     0x124961c: ldp             fp, lr, [SP], #0x10
    // 0x1249620: ret
    //     0x1249620: ret             
    // 0x1249624: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1249624: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1249628: b               #0x12495e0
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x124962c, size: 0xfc
    // 0x124962c: EnterFrame
    //     0x124962c: stp             fp, lr, [SP, #-0x10]!
    //     0x1249630: mov             fp, SP
    // 0x1249634: AllocStack(0x8)
    //     0x1249634: sub             SP, SP, #8
    // 0x1249638: SetupParameters([dynamic _ /* r0 */])
    //     0x1249638: ldr             x0, [fp, #0x18]
    //     0x124963c: ldur            w3, [x0, #0x17]
    //     0x1249640: add             x3, x3, HEAP, lsl #32
    //     0x1249644: stur            x3, [fp, #-8]
    // 0x1249648: CheckStackOverflow
    //     0x1249648: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124964c: cmp             SP, x16
    //     0x1249650: b.ls            #0x1249720
    // 0x1249654: ldr             x1, [fp, #0x10]
    // 0x1249658: r0 = LoadClassIdInstr(r1)
    //     0x1249658: ldur            x0, [x1, #-1]
    //     0x124965c: ubfx            x0, x0, #0xc, #0x14
    // 0x1249660: r2 = Instance_WidgetState
    //     0x1249660: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0x1249664: ldr             x2, [x2, #0xa70]
    // 0x1249668: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1249668: mov             x17, #0x2929
    //     0x124966c: movk            x17, #1, lsl #16
    //     0x1249670: add             lr, x0, x17
    //     0x1249674: ldr             lr, [x21, lr, lsl #3]
    //     0x1249678: blr             lr
    // 0x124967c: tbnz            w0, #4, #0x12496dc
    // 0x1249680: ldur            x0, [fp, #-8]
    // 0x1249684: LoadField: r1 = r0->field_f
    //     0x1249684: ldur            w1, [x0, #0xf]
    // 0x1249688: DecompressPointer r1
    //     0x1249688: add             x1, x1, HEAP, lsl #32
    // 0x124968c: LoadField: r0 = r1->field_6f
    //     0x124968c: ldur            w0, [x1, #0x6f]
    // 0x1249690: DecompressPointer r0
    //     0x1249690: add             x0, x0, HEAP, lsl #32
    // 0x1249694: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1249698: cmp             w0, w16
    // 0x124969c: b.ne            #0x12496ac
    // 0x12496a0: r2 = _colors
    //     0x12496a0: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0f00] Field <_ElevatedButtonDefaultsM3@744256481._colors@744256481>: late final (offset: 0x70)
    //     0x12496a4: ldr             x2, [x2, #0xf00]
    // 0x12496a8: r0 = InitLateFinalInstanceField()
    //     0x12496a8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12496ac: LoadField: r1 = r0->field_7f
    //     0x12496ac: ldur            w1, [x0, #0x7f]
    // 0x12496b0: DecompressPointer r1
    //     0x12496b0: add             x1, x1, HEAP, lsl #32
    // 0x12496b4: r0 = LoadClassIdInstr(r1)
    //     0x12496b4: ldur            x0, [x1, #-1]
    //     0x12496b8: ubfx            x0, x0, #0xc, #0x14
    // 0x12496bc: d0 = 0.380000
    //     0x12496bc: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x12496c0: ldr             d0, [x17, #0x1f0]
    // 0x12496c4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12496c4: sub             lr, x0, #1, lsl #12
    //     0x12496c8: ldr             lr, [x21, lr, lsl #3]
    //     0x12496cc: blr             lr
    // 0x12496d0: LeaveFrame
    //     0x12496d0: mov             SP, fp
    //     0x12496d4: ldp             fp, lr, [SP], #0x10
    // 0x12496d8: ret
    //     0x12496d8: ret             
    // 0x12496dc: ldur            x0, [fp, #-8]
    // 0x12496e0: LoadField: r1 = r0->field_f
    //     0x12496e0: ldur            w1, [x0, #0xf]
    // 0x12496e4: DecompressPointer r1
    //     0x12496e4: add             x1, x1, HEAP, lsl #32
    // 0x12496e8: LoadField: r0 = r1->field_6f
    //     0x12496e8: ldur            w0, [x1, #0x6f]
    // 0x12496ec: DecompressPointer r0
    //     0x12496ec: add             x0, x0, HEAP, lsl #32
    // 0x12496f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12496f4: cmp             w0, w16
    // 0x12496f8: b.ne            #0x1249708
    // 0x12496fc: r2 = _colors
    //     0x12496fc: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0f00] Field <_ElevatedButtonDefaultsM3@744256481._colors@744256481>: late final (offset: 0x70)
    //     0x1249700: ldr             x2, [x2, #0xf00]
    // 0x1249704: r0 = InitLateFinalInstanceField()
    //     0x1249704: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1249708: LoadField: r1 = r0->field_b
    //     0x1249708: ldur            w1, [x0, #0xb]
    // 0x124970c: DecompressPointer r1
    //     0x124970c: add             x1, x1, HEAP, lsl #32
    // 0x1249710: mov             x0, x1
    // 0x1249714: LeaveFrame
    //     0x1249714: mov             SP, fp
    //     0x1249718: ldp             fp, lr, [SP], #0x10
    // 0x124971c: ret
    //     0x124971c: ret             
    // 0x1249720: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1249720: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1249724: b               #0x1249654
  }
}

// class id: 6156, size: 0x1c, field offset: 0xc
//   const constructor, 
class _ElevatedButtonWithIconChild extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfba06c, size: 0x280
    // 0xfba06c: EnterFrame
    //     0xfba06c: stp             fp, lr, [SP, #-0x10]!
    //     0xfba070: mov             fp, SP
    // 0xfba074: AllocStack(0x28)
    //     0xfba074: sub             SP, SP, #0x28
    // 0xfba078: SetupParameters(_ElevatedButtonWithIconChild this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xfba078: mov             x4, x1
    //     0xfba07c: mov             x3, x2
    //     0xfba080: stur            x1, [fp, #-8]
    //     0xfba084: stur            x2, [fp, #-0x10]
    // 0xfba088: CheckStackOverflow
    //     0xfba088: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfba08c: cmp             SP, x16
    //     0xfba090: b.ls            #0xfba2d0
    // 0xfba094: LoadField: r0 = r4->field_13
    //     0xfba094: ldur            w0, [x4, #0x13]
    // 0xfba098: DecompressPointer r0
    //     0xfba098: add             x0, x0, HEAP, lsl #32
    // 0xfba09c: LoadField: r1 = r0->field_7
    //     0xfba09c: ldur            w1, [x0, #7]
    // 0xfba0a0: DecompressPointer r1
    //     0xfba0a0: add             x1, x1, HEAP, lsl #32
    // 0xfba0a4: cmp             w1, NULL
    // 0xfba0a8: b.ne            #0xfba0b4
    // 0xfba0ac: r0 = Null
    //     0xfba0ac: mov             x0, NULL
    // 0xfba0b0: b               #0xfba0f4
    // 0xfba0b4: r0 = LoadClassIdInstr(r1)
    //     0xfba0b4: ldur            x0, [x1, #-1]
    //     0xfba0b8: ubfx            x0, x0, #0xc, #0x14
    // 0xfba0bc: r2 = _ConstSet len:0
    //     0xfba0bc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26248] Set<WidgetState>(0)
    //     0xfba0c0: ldr             x2, [x2, #0x248]
    // 0xfba0c4: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xfba0c4: mov             x17, #0x7c77
    //     0xfba0c8: movk            x17, #1, lsl #16
    //     0xfba0cc: add             lr, x0, x17
    //     0xfba0d0: ldr             lr, [x21, lr, lsl #3]
    //     0xfba0d4: blr             lr
    // 0xfba0d8: cmp             w0, NULL
    // 0xfba0dc: b.ne            #0xfba0e8
    // 0xfba0e0: r0 = Null
    //     0xfba0e0: mov             x0, NULL
    // 0xfba0e4: b               #0xfba0f4
    // 0xfba0e8: LoadField: r1 = r0->field_1f
    //     0xfba0e8: ldur            w1, [x0, #0x1f]
    // 0xfba0ec: DecompressPointer r1
    //     0xfba0ec: add             x1, x1, HEAP, lsl #32
    // 0xfba0f0: mov             x0, x1
    // 0xfba0f4: cmp             w0, NULL
    // 0xfba0f8: b.ne            #0xfba104
    // 0xfba0fc: d0 = 14.000000
    //     0xfba0fc: fmov            d0, #14.00000000
    // 0xfba100: b               #0xfba108
    // 0xfba104: LoadField: d0 = r0->field_7
    //     0xfba104: ldur            d0, [x0, #7]
    // 0xfba108: ldur            x1, [fp, #-0x10]
    // 0xfba10c: stur            d0, [fp, #-0x28]
    // 0xfba110: r0 = textScalerOf()
    //     0xfba110: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0xfba114: r1 = LoadClassIdInstr(r0)
    //     0xfba114: ldur            x1, [x0, #-1]
    //     0xfba118: ubfx            x1, x1, #0xc, #0x14
    // 0xfba11c: mov             x16, x0
    // 0xfba120: mov             x0, x1
    // 0xfba124: mov             x1, x16
    // 0xfba128: ldur            d0, [fp, #-0x28]
    // 0xfba12c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xfba12c: sub             lr, x0, #1, lsl #12
    //     0xfba130: ldr             lr, [x21, lr, lsl #3]
    //     0xfba134: blr             lr
    // 0xfba138: LoadField: d0 = r0->field_7
    //     0xfba138: ldur            d0, [x0, #7]
    // 0xfba13c: d1 = 14.000000
    //     0xfba13c: fmov            d1, #14.00000000
    // 0xfba140: fdiv            d2, d0, d1
    // 0xfba144: d0 = 1.000000
    //     0xfba144: fmov            d0, #1.00000000
    // 0xfba148: fcmp            d0, d2
    // 0xfba14c: b.le            #0xfba158
    // 0xfba150: d1 = 1.000000
    //     0xfba150: fmov            d1, #1.00000000
    // 0xfba154: b               #0xfba180
    // 0xfba158: d1 = 2.000000
    //     0xfba158: fmov            d1, #2.00000000
    // 0xfba15c: fcmp            d2, d1
    // 0xfba160: b.le            #0xfba16c
    // 0xfba164: d1 = 2.000000
    //     0xfba164: fmov            d1, #2.00000000
    // 0xfba168: b               #0xfba180
    // 0xfba16c: fcmp            d2, d2
    // 0xfba170: b.vc            #0xfba17c
    // 0xfba174: d1 = 2.000000
    //     0xfba174: fmov            d1, #2.00000000
    // 0xfba178: b               #0xfba180
    // 0xfba17c: mov             v1.16b, v2.16b
    // 0xfba180: ldur            x0, [fp, #-8]
    // 0xfba184: fsub            d2, d1, d0
    // 0xfba188: ldur            x1, [fp, #-0x10]
    // 0xfba18c: stur            d2, [fp, #-0x28]
    // 0xfba190: r0 = of()
    //     0xfba190: bl              #0xfba2ec  ; [package:flutter/src/material/elevated_button_theme.dart] ElevatedButtonTheme::of
    // 0xfba194: ldur            d0, [fp, #-0x28]
    // 0xfba198: r3 = inline_Allocate_Double()
    //     0xfba198: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xfba19c: add             x3, x3, #0x10
    //     0xfba1a0: cmp             x0, x3
    //     0xfba1a4: b.ls            #0xfba2d8
    //     0xfba1a8: str             x3, [THR, #0x60]  ; THR::top
    //     0xfba1ac: sub             x3, x3, #0xf
    //     0xfba1b0: mov             x0, #0xe19c
    //     0xfba1b4: movk            x0, #3, lsl #16
    //     0xfba1b8: stur            x0, [x3, #-1]
    // 0xfba1bc: dmb             ishst
    // 0xfba1c0: StoreField: r3->field_7 = d0
    //     0xfba1c0: stur            d0, [x3, #7]
    // 0xfba1c4: r1 = 16
    //     0xfba1c4: mov             x1, #0x10
    // 0xfba1c8: r2 = 8
    //     0xfba1c8: mov             x2, #8
    // 0xfba1cc: r0 = lerpDouble()
    //     0xfba1cc: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xfba1d0: mov             x2, x0
    // 0xfba1d4: ldur            x0, [fp, #-8]
    // 0xfba1d8: stur            x2, [fp, #-0x20]
    // 0xfba1dc: LoadField: r3 = r0->field_f
    //     0xfba1dc: ldur            w3, [x0, #0xf]
    // 0xfba1e0: DecompressPointer r3
    //     0xfba1e0: add             x3, x3, HEAP, lsl #32
    // 0xfba1e4: stur            x3, [fp, #-0x18]
    // 0xfba1e8: LoadField: r4 = r0->field_b
    //     0xfba1e8: ldur            w4, [x0, #0xb]
    // 0xfba1ec: DecompressPointer r4
    //     0xfba1ec: add             x4, x4, HEAP, lsl #32
    // 0xfba1f0: stur            x4, [fp, #-0x10]
    // 0xfba1f4: r1 = <FlexParentData>
    //     0xfba1f4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xfba1f8: ldr             x1, [x1, #0x878]
    // 0xfba1fc: r0 = Flexible()
    //     0xfba1fc: bl              #0xd0fd68  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0xfba200: mov             x3, x0
    // 0xfba204: r0 = 1
    //     0xfba204: mov             x0, #1
    // 0xfba208: stur            x3, [fp, #-8]
    // 0xfba20c: StoreField: r3->field_13 = r0
    //     0xfba20c: stur            x0, [x3, #0x13]
    // 0xfba210: r0 = Instance_FlexFit
    //     0xfba210: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ac30] Obj!FlexFit@12c4661
    //     0xfba214: ldr             x0, [x0, #0xc30]
    // 0xfba218: StoreField: r3->field_1b = r0
    //     0xfba218: stur            w0, [x3, #0x1b]
    // 0xfba21c: ldur            x0, [fp, #-0x10]
    // 0xfba220: StoreField: r3->field_b = r0
    //     0xfba220: stur            w0, [x3, #0xb]
    // 0xfba224: r1 = Null
    //     0xfba224: mov             x1, NULL
    // 0xfba228: r2 = 4
    //     0xfba228: mov             x2, #4
    // 0xfba22c: r0 = AllocateArray()
    //     0xfba22c: bl              #0x13df928  ; AllocateArrayStub
    // 0xfba230: mov             x2, x0
    // 0xfba234: ldur            x0, [fp, #-0x18]
    // 0xfba238: stur            x2, [fp, #-0x10]
    // 0xfba23c: StoreField: r2->field_f = r0
    //     0xfba23c: stur            w0, [x2, #0xf]
    // 0xfba240: ldur            x0, [fp, #-8]
    // 0xfba244: StoreField: r2->field_13 = r0
    //     0xfba244: stur            w0, [x2, #0x13]
    // 0xfba248: r1 = <Widget>
    //     0xfba248: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfba24c: r0 = AllocateGrowableArray()
    //     0xfba24c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xfba250: mov             x1, x0
    // 0xfba254: ldur            x0, [fp, #-0x10]
    // 0xfba258: stur            x1, [fp, #-8]
    // 0xfba25c: StoreField: r1->field_f = r0
    //     0xfba25c: stur            w0, [x1, #0xf]
    // 0xfba260: r0 = 4
    //     0xfba260: mov             x0, #4
    // 0xfba264: StoreField: r1->field_b = r0
    //     0xfba264: stur            w0, [x1, #0xb]
    // 0xfba268: r0 = Row()
    //     0xfba268: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xfba26c: r1 = Instance_Axis
    //     0xfba26c: ldr             x1, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xfba270: StoreField: r0->field_f = r1
    //     0xfba270: stur            w1, [x0, #0xf]
    // 0xfba274: r1 = Instance_MainAxisAlignment
    //     0xfba274: add             x1, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xfba278: ldr             x1, [x1, #0x820]
    // 0xfba27c: StoreField: r0->field_13 = r1
    //     0xfba27c: stur            w1, [x0, #0x13]
    // 0xfba280: r1 = Instance_MainAxisSize
    //     0xfba280: add             x1, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xfba284: ldr             x1, [x1, #0x200]
    // 0xfba288: ArrayStore: r0[0] = r1  ; List_4
    //     0xfba288: stur            w1, [x0, #0x17]
    // 0xfba28c: r1 = Instance_CrossAxisAlignment
    //     0xfba28c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xfba290: ldr             x1, [x1, #0x888]
    // 0xfba294: StoreField: r0->field_1b = r1
    //     0xfba294: stur            w1, [x0, #0x1b]
    // 0xfba298: r1 = Instance_VerticalDirection
    //     0xfba298: add             x1, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xfba29c: ldr             x1, [x1, #0x838]
    // 0xfba2a0: StoreField: r0->field_23 = r1
    //     0xfba2a0: stur            w1, [x0, #0x23]
    // 0xfba2a4: r1 = Instance_Clip
    //     0xfba2a4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfba2a8: ldr             x1, [x1, #0x840]
    // 0xfba2ac: StoreField: r0->field_2b = r1
    //     0xfba2ac: stur            w1, [x0, #0x2b]
    // 0xfba2b0: ldur            x1, [fp, #-0x20]
    // 0xfba2b4: LoadField: d0 = r1->field_7
    //     0xfba2b4: ldur            d0, [x1, #7]
    // 0xfba2b8: StoreField: r0->field_2f = d0
    //     0xfba2b8: stur            d0, [x0, #0x2f]
    // 0xfba2bc: ldur            x1, [fp, #-8]
    // 0xfba2c0: StoreField: r0->field_b = r1
    //     0xfba2c0: stur            w1, [x0, #0xb]
    // 0xfba2c4: LeaveFrame
    //     0xfba2c4: mov             SP, fp
    //     0xfba2c8: ldp             fp, lr, [SP], #0x10
    // 0xfba2cc: ret
    //     0xfba2cc: ret             
    // 0xfba2d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfba2d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfba2d4: b               #0xfba094
    // 0xfba2d8: SaveReg d0
    //     0xfba2d8: str             q0, [SP, #-0x10]!
    // 0xfba2dc: r0 = AllocateDouble()
    //     0xfba2dc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfba2e0: mov             x3, x0
    // 0xfba2e4: RestoreReg d0
    //     0xfba2e4: ldr             q0, [SP], #0x10
    // 0xfba2e8: b               #0xfba1c0
  }
}

// class id: 6498, size: 0x40, field offset: 0x3c
//   const constructor, 
class ElevatedButton extends ButtonStyleButton {

  _ ElevatedButton.icon(/* No info */) {
    // ** addr: 0xd5a328, size: 0xe8
    // 0xd5a328: EnterFrame
    //     0xd5a328: stp             fp, lr, [SP, #-0x10]!
    //     0xd5a32c: mov             fp, SP
    // 0xd5a330: AllocStack(0x28)
    //     0xd5a330: sub             SP, SP, #0x28
    // 0xd5a334: r0 = true
    //     0xd5a334: add             x0, NULL, #0x20  ; true
    // 0xd5a338: mov             x4, x2
    // 0xd5a33c: stur            x2, [fp, #-0x10]
    // 0xd5a340: mov             x2, x5
    // 0xd5a344: stur            x5, [fp, #-0x20]
    // 0xd5a348: mov             x5, x1
    // 0xd5a34c: stur            x1, [fp, #-8]
    // 0xd5a350: mov             x1, x6
    // 0xd5a354: stur            x3, [fp, #-0x18]
    // 0xd5a358: stur            x6, [fp, #-0x28]
    // 0xd5a35c: StoreField: r5->field_3b = r0
    //     0xd5a35c: stur            w0, [x5, #0x3b]
    // 0xd5a360: r0 = _ElevatedButtonWithIconChild()
    //     0xd5a360: bl              #0xd5a410  ; Allocate_ElevatedButtonWithIconChildStub -> _ElevatedButtonWithIconChild (size=0x1c)
    // 0xd5a364: mov             x2, x0
    // 0xd5a368: ldur            x1, [fp, #-0x18]
    // 0xd5a36c: StoreField: r2->field_b = r1
    //     0xd5a36c: stur            w1, [x2, #0xb]
    // 0xd5a370: ldur            x1, [fp, #-0x10]
    // 0xd5a374: StoreField: r2->field_f = r1
    //     0xd5a374: stur            w1, [x2, #0xf]
    // 0xd5a378: ldur            x1, [fp, #-0x28]
    // 0xd5a37c: StoreField: r2->field_13 = r1
    //     0xd5a37c: stur            w1, [x2, #0x13]
    // 0xd5a380: ldur            x0, [fp, #-0x20]
    // 0xd5a384: ldur            x3, [fp, #-8]
    // 0xd5a388: StoreField: r3->field_b = r0
    //     0xd5a388: stur            w0, [x3, #0xb]
    //     0xd5a38c: ldurb           w16, [x3, #-1]
    //     0xd5a390: ldurb           w17, [x0, #-1]
    //     0xd5a394: and             x16, x17, x16, lsr #2
    //     0xd5a398: tst             x16, HEAP, lsr #32
    //     0xd5a39c: b.eq            #0xd5a3a4
    //     0xd5a3a0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd5a3a4: mov             x0, x1
    // 0xd5a3a8: StoreField: r3->field_1b = r0
    //     0xd5a3a8: stur            w0, [x3, #0x1b]
    //     0xd5a3ac: ldurb           w16, [x3, #-1]
    //     0xd5a3b0: ldurb           w17, [x0, #-1]
    //     0xd5a3b4: and             x16, x17, x16, lsr #2
    //     0xd5a3b8: tst             x16, HEAP, lsr #32
    //     0xd5a3bc: b.eq            #0xd5a3c4
    //     0xd5a3c0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd5a3c4: r1 = false
    //     0xd5a3c4: add             x1, NULL, #0x30  ; false
    // 0xd5a3c8: StoreField: r3->field_27 = r1
    //     0xd5a3c8: stur            w1, [x3, #0x27]
    // 0xd5a3cc: r1 = Instance_Clip
    //     0xd5a3cc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xd5a3d0: ldr             x1, [x1, #0x840]
    // 0xd5a3d4: StoreField: r3->field_1f = r1
    //     0xd5a3d4: stur            w1, [x3, #0x1f]
    // 0xd5a3d8: r1 = true
    //     0xd5a3d8: add             x1, NULL, #0x20  ; true
    // 0xd5a3dc: StoreField: r3->field_2f = r1
    //     0xd5a3dc: stur            w1, [x3, #0x2f]
    // 0xd5a3e0: mov             x0, x2
    // 0xd5a3e4: StoreField: r3->field_37 = r0
    //     0xd5a3e4: stur            w0, [x3, #0x37]
    //     0xd5a3e8: ldurb           w16, [x3, #-1]
    //     0xd5a3ec: ldurb           w17, [x0, #-1]
    //     0xd5a3f0: and             x16, x17, x16, lsr #2
    //     0xd5a3f4: tst             x16, HEAP, lsr #32
    //     0xd5a3f8: b.eq            #0xd5a400
    //     0xd5a3fc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd5a400: r0 = Null
    //     0xd5a400: mov             x0, NULL
    // 0xd5a404: LeaveFrame
    //     0xd5a404: mov             SP, fp
    //     0xd5a408: ldp             fp, lr, [SP], #0x10
    // 0xd5a40c: ret
    //     0xd5a40c: ret             
  }
  static _ styleFrom(/* No info */) {
    // ** addr: 0xd5a428, size: 0xdb8
    // 0xd5a428: EnterFrame
    //     0xd5a428: stp             fp, lr, [SP, #-0x10]!
    //     0xd5a42c: mov             fp, SP
    // 0xd5a430: AllocStack(0xc0)
    //     0xd5a430: sub             SP, SP, #0xc0
    // 0xd5a434: SetupParameters({dynamic alignment = Null /* fp-0x8 */, dynamic animationDuration = Null /* r5, fp-0xa0 */, dynamic backgroundColor = Null /* r6, fp-0x98 */, dynamic disabledBackgroundColor = Null /* r7, fp-0x90 */, dynamic disabledForegroundColor = Null /* r8, fp-0x88 */, dynamic disabledMouseCursor = Null /* r9, fp-0x80 */, dynamic elevation = Null /* r10, fp-0x78 */, dynamic enableFeedback = Null /* r11, fp-0x70 */, dynamic enabledMouseCursor = Null /* r12, fp-0x68 */, dynamic fixedSize = Null /* r13, fp-0x60 */, dynamic foregroundColor = Null /* r14, fp-0x58 */, dynamic maximumSize = Null /* r19, fp-0x50 */, dynamic minimumSize = Null /* r20, fp-0x48 */, dynamic padding = Null /* r23, fp-0x40 */, dynamic shadowColor = Null /* fp-0x10 */, dynamic shape = Null /* fp-0x18 */, dynamic splashFactory = Null /* fp-0x20 */, dynamic tapTargetSize = Null /* fp-0x28 */, dynamic textStyle = Null /* r3, fp-0x38 */, dynamic visualDensity = Null /* r4, fp-0x30 */})
    //     0xd5a434: ldur            w0, [x4, #0x13]
    //     0xd5a438: ldur            w1, [x4, #0x1f]
    //     0xd5a43c: add             x1, x1, HEAP, lsl #32
    //     0xd5a440: ldr             x16, [PP, #0x5c70]  ; [pp+0x5c70] "alignment"
    //     0xd5a444: cmp             w1, w16
    //     0xd5a448: b.ne            #0xd5a46c
    //     0xd5a44c: ldur            w1, [x4, #0x23]
    //     0xd5a450: add             x1, x1, HEAP, lsl #32
    //     0xd5a454: sub             w2, w0, w1
    //     0xd5a458: add             x1, fp, w2, sxtw #2
    //     0xd5a45c: ldr             x1, [x1, #8]
    //     0xd5a460: mov             x3, x1
    //     0xd5a464: mov             x1, #1
    //     0xd5a468: b               #0xd5a474
    //     0xd5a46c: mov             x3, NULL
    //     0xd5a470: mov             x1, #0
    //     0xd5a474: stur            x3, [fp, #-8]
    //     0xd5a478: lsl             x2, x1, #1
    //     0xd5a47c: lsl             w5, w2, #1
    //     0xd5a480: add             w6, w5, #8
    //     0xd5a484: add             x16, x4, w6, sxtw #1
    //     0xd5a488: ldur            w7, [x16, #0xf]
    //     0xd5a48c: add             x7, x7, HEAP, lsl #32
    //     0xd5a490: add             x16, PP, #0x15, lsl #12  ; [pp+0x159d0] "animationDuration"
    //     0xd5a494: ldr             x16, [x16, #0x9d0]
    //     0xd5a498: cmp             w7, w16
    //     0xd5a49c: b.ne            #0xd5a4cc
    //     0xd5a4a0: add             w1, w5, #0xa
    //     0xd5a4a4: add             x16, x4, w1, sxtw #1
    //     0xd5a4a8: ldur            w5, [x16, #0xf]
    //     0xd5a4ac: add             x5, x5, HEAP, lsl #32
    //     0xd5a4b0: sub             w1, w0, w5
    //     0xd5a4b4: add             x5, fp, w1, sxtw #2
    //     0xd5a4b8: ldr             x5, [x5, #8]
    //     0xd5a4bc: add             w1, w2, #2
    //     0xd5a4c0: sbfx            x2, x1, #1, #0x1f
    //     0xd5a4c4: mov             x1, x2
    //     0xd5a4c8: b               #0xd5a4d0
    //     0xd5a4cc: mov             x5, NULL
    //     0xd5a4d0: stur            x5, [fp, #-0xa0]
    //     0xd5a4d4: lsl             x2, x1, #1
    //     0xd5a4d8: lsl             w6, w2, #1
    //     0xd5a4dc: add             w7, w6, #8
    //     0xd5a4e0: add             x16, x4, w7, sxtw #1
    //     0xd5a4e4: ldur            w8, [x16, #0xf]
    //     0xd5a4e8: add             x8, x8, HEAP, lsl #32
    //     0xd5a4ec: add             x16, PP, #0x12, lsl #12  ; [pp+0x12958] "backgroundColor"
    //     0xd5a4f0: ldr             x16, [x16, #0x958]
    //     0xd5a4f4: cmp             w8, w16
    //     0xd5a4f8: b.ne            #0xd5a528
    //     0xd5a4fc: add             w1, w6, #0xa
    //     0xd5a500: add             x16, x4, w1, sxtw #1
    //     0xd5a504: ldur            w6, [x16, #0xf]
    //     0xd5a508: add             x6, x6, HEAP, lsl #32
    //     0xd5a50c: sub             w1, w0, w6
    //     0xd5a510: add             x6, fp, w1, sxtw #2
    //     0xd5a514: ldr             x6, [x6, #8]
    //     0xd5a518: add             w1, w2, #2
    //     0xd5a51c: sbfx            x2, x1, #1, #0x1f
    //     0xd5a520: mov             x1, x2
    //     0xd5a524: b               #0xd5a52c
    //     0xd5a528: mov             x6, NULL
    //     0xd5a52c: stur            x6, [fp, #-0x98]
    //     0xd5a530: lsl             x2, x1, #1
    //     0xd5a534: lsl             w7, w2, #1
    //     0xd5a538: add             w8, w7, #8
    //     0xd5a53c: add             x16, x4, w8, sxtw #1
    //     0xd5a540: ldur            w9, [x16, #0xf]
    //     0xd5a544: add             x9, x9, HEAP, lsl #32
    //     0xd5a548: add             x16, PP, #0x15, lsl #12  ; [pp+0x159d8] "disabledBackgroundColor"
    //     0xd5a54c: ldr             x16, [x16, #0x9d8]
    //     0xd5a550: cmp             w9, w16
    //     0xd5a554: b.ne            #0xd5a584
    //     0xd5a558: add             w1, w7, #0xa
    //     0xd5a55c: add             x16, x4, w1, sxtw #1
    //     0xd5a560: ldur            w7, [x16, #0xf]
    //     0xd5a564: add             x7, x7, HEAP, lsl #32
    //     0xd5a568: sub             w1, w0, w7
    //     0xd5a56c: add             x7, fp, w1, sxtw #2
    //     0xd5a570: ldr             x7, [x7, #8]
    //     0xd5a574: add             w1, w2, #2
    //     0xd5a578: sbfx            x2, x1, #1, #0x1f
    //     0xd5a57c: mov             x1, x2
    //     0xd5a580: b               #0xd5a588
    //     0xd5a584: mov             x7, NULL
    //     0xd5a588: stur            x7, [fp, #-0x90]
    //     0xd5a58c: lsl             x2, x1, #1
    //     0xd5a590: lsl             w8, w2, #1
    //     0xd5a594: add             w9, w8, #8
    //     0xd5a598: add             x16, x4, w9, sxtw #1
    //     0xd5a59c: ldur            w10, [x16, #0xf]
    //     0xd5a5a0: add             x10, x10, HEAP, lsl #32
    //     0xd5a5a4: add             x16, PP, #0x15, lsl #12  ; [pp+0x159e0] "disabledForegroundColor"
    //     0xd5a5a8: ldr             x16, [x16, #0x9e0]
    //     0xd5a5ac: cmp             w10, w16
    //     0xd5a5b0: b.ne            #0xd5a5e0
    //     0xd5a5b4: add             w1, w8, #0xa
    //     0xd5a5b8: add             x16, x4, w1, sxtw #1
    //     0xd5a5bc: ldur            w8, [x16, #0xf]
    //     0xd5a5c0: add             x8, x8, HEAP, lsl #32
    //     0xd5a5c4: sub             w1, w0, w8
    //     0xd5a5c8: add             x8, fp, w1, sxtw #2
    //     0xd5a5cc: ldr             x8, [x8, #8]
    //     0xd5a5d0: add             w1, w2, #2
    //     0xd5a5d4: sbfx            x2, x1, #1, #0x1f
    //     0xd5a5d8: mov             x1, x2
    //     0xd5a5dc: b               #0xd5a5e4
    //     0xd5a5e0: mov             x8, NULL
    //     0xd5a5e4: stur            x8, [fp, #-0x88]
    //     0xd5a5e8: lsl             x2, x1, #1
    //     0xd5a5ec: lsl             w9, w2, #1
    //     0xd5a5f0: add             w10, w9, #8
    //     0xd5a5f4: add             x16, x4, w10, sxtw #1
    //     0xd5a5f8: ldur            w11, [x16, #0xf]
    //     0xd5a5fc: add             x11, x11, HEAP, lsl #32
    //     0xd5a600: add             x16, PP, #0x15, lsl #12  ; [pp+0x159e8] "disabledMouseCursor"
    //     0xd5a604: ldr             x16, [x16, #0x9e8]
    //     0xd5a608: cmp             w11, w16
    //     0xd5a60c: b.ne            #0xd5a63c
    //     0xd5a610: add             w1, w9, #0xa
    //     0xd5a614: add             x16, x4, w1, sxtw #1
    //     0xd5a618: ldur            w9, [x16, #0xf]
    //     0xd5a61c: add             x9, x9, HEAP, lsl #32
    //     0xd5a620: sub             w1, w0, w9
    //     0xd5a624: add             x9, fp, w1, sxtw #2
    //     0xd5a628: ldr             x9, [x9, #8]
    //     0xd5a62c: add             w1, w2, #2
    //     0xd5a630: sbfx            x2, x1, #1, #0x1f
    //     0xd5a634: mov             x1, x2
    //     0xd5a638: b               #0xd5a640
    //     0xd5a63c: mov             x9, NULL
    //     0xd5a640: stur            x9, [fp, #-0x80]
    //     0xd5a644: lsl             x2, x1, #1
    //     0xd5a648: lsl             w10, w2, #1
    //     0xd5a64c: add             w11, w10, #8
    //     0xd5a650: add             x16, x4, w11, sxtw #1
    //     0xd5a654: ldur            w12, [x16, #0xf]
    //     0xd5a658: add             x12, x12, HEAP, lsl #32
    //     0xd5a65c: add             x16, PP, #0x15, lsl #12  ; [pp+0x159f0] "elevation"
    //     0xd5a660: ldr             x16, [x16, #0x9f0]
    //     0xd5a664: cmp             w12, w16
    //     0xd5a668: b.ne            #0xd5a698
    //     0xd5a66c: add             w1, w10, #0xa
    //     0xd5a670: add             x16, x4, w1, sxtw #1
    //     0xd5a674: ldur            w10, [x16, #0xf]
    //     0xd5a678: add             x10, x10, HEAP, lsl #32
    //     0xd5a67c: sub             w1, w0, w10
    //     0xd5a680: add             x10, fp, w1, sxtw #2
    //     0xd5a684: ldr             x10, [x10, #8]
    //     0xd5a688: add             w1, w2, #2
    //     0xd5a68c: sbfx            x2, x1, #1, #0x1f
    //     0xd5a690: mov             x1, x2
    //     0xd5a694: b               #0xd5a69c
    //     0xd5a698: mov             x10, NULL
    //     0xd5a69c: stur            x10, [fp, #-0x78]
    //     0xd5a6a0: lsl             x2, x1, #1
    //     0xd5a6a4: lsl             w11, w2, #1
    //     0xd5a6a8: add             w12, w11, #8
    //     0xd5a6ac: add             x16, x4, w12, sxtw #1
    //     0xd5a6b0: ldur            w13, [x16, #0xf]
    //     0xd5a6b4: add             x13, x13, HEAP, lsl #32
    //     0xd5a6b8: add             x16, PP, #0x15, lsl #12  ; [pp+0x159f8] "enableFeedback"
    //     0xd5a6bc: ldr             x16, [x16, #0x9f8]
    //     0xd5a6c0: cmp             w13, w16
    //     0xd5a6c4: b.ne            #0xd5a6f4
    //     0xd5a6c8: add             w1, w11, #0xa
    //     0xd5a6cc: add             x16, x4, w1, sxtw #1
    //     0xd5a6d0: ldur            w11, [x16, #0xf]
    //     0xd5a6d4: add             x11, x11, HEAP, lsl #32
    //     0xd5a6d8: sub             w1, w0, w11
    //     0xd5a6dc: add             x11, fp, w1, sxtw #2
    //     0xd5a6e0: ldr             x11, [x11, #8]
    //     0xd5a6e4: add             w1, w2, #2
    //     0xd5a6e8: sbfx            x2, x1, #1, #0x1f
    //     0xd5a6ec: mov             x1, x2
    //     0xd5a6f0: b               #0xd5a6f8
    //     0xd5a6f4: mov             x11, NULL
    //     0xd5a6f8: stur            x11, [fp, #-0x70]
    //     0xd5a6fc: lsl             x2, x1, #1
    //     0xd5a700: lsl             w12, w2, #1
    //     0xd5a704: add             w13, w12, #8
    //     0xd5a708: add             x16, x4, w13, sxtw #1
    //     0xd5a70c: ldur            w14, [x16, #0xf]
    //     0xd5a710: add             x14, x14, HEAP, lsl #32
    //     0xd5a714: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a00] "enabledMouseCursor"
    //     0xd5a718: ldr             x16, [x16, #0xa00]
    //     0xd5a71c: cmp             w14, w16
    //     0xd5a720: b.ne            #0xd5a750
    //     0xd5a724: add             w1, w12, #0xa
    //     0xd5a728: add             x16, x4, w1, sxtw #1
    //     0xd5a72c: ldur            w12, [x16, #0xf]
    //     0xd5a730: add             x12, x12, HEAP, lsl #32
    //     0xd5a734: sub             w1, w0, w12
    //     0xd5a738: add             x12, fp, w1, sxtw #2
    //     0xd5a73c: ldr             x12, [x12, #8]
    //     0xd5a740: add             w1, w2, #2
    //     0xd5a744: sbfx            x2, x1, #1, #0x1f
    //     0xd5a748: mov             x1, x2
    //     0xd5a74c: b               #0xd5a754
    //     0xd5a750: mov             x12, NULL
    //     0xd5a754: stur            x12, [fp, #-0x68]
    //     0xd5a758: lsl             x2, x1, #1
    //     0xd5a75c: lsl             w13, w2, #1
    //     0xd5a760: add             w14, w13, #8
    //     0xd5a764: add             x16, x4, w14, sxtw #1
    //     0xd5a768: ldur            w19, [x16, #0xf]
    //     0xd5a76c: add             x19, x19, HEAP, lsl #32
    //     0xd5a770: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a08] "fixedSize"
    //     0xd5a774: ldr             x16, [x16, #0xa08]
    //     0xd5a778: cmp             w19, w16
    //     0xd5a77c: b.ne            #0xd5a7ac
    //     0xd5a780: add             w1, w13, #0xa
    //     0xd5a784: add             x16, x4, w1, sxtw #1
    //     0xd5a788: ldur            w13, [x16, #0xf]
    //     0xd5a78c: add             x13, x13, HEAP, lsl #32
    //     0xd5a790: sub             w1, w0, w13
    //     0xd5a794: add             x13, fp, w1, sxtw #2
    //     0xd5a798: ldr             x13, [x13, #8]
    //     0xd5a79c: add             w1, w2, #2
    //     0xd5a7a0: sbfx            x2, x1, #1, #0x1f
    //     0xd5a7a4: mov             x1, x2
    //     0xd5a7a8: b               #0xd5a7b0
    //     0xd5a7ac: mov             x13, NULL
    //     0xd5a7b0: stur            x13, [fp, #-0x60]
    //     0xd5a7b4: lsl             x2, x1, #1
    //     0xd5a7b8: lsl             w14, w2, #1
    //     0xd5a7bc: add             w19, w14, #8
    //     0xd5a7c0: add             x16, x4, w19, sxtw #1
    //     0xd5a7c4: ldur            w20, [x16, #0xf]
    //     0xd5a7c8: add             x20, x20, HEAP, lsl #32
    //     0xd5a7cc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a10] "foregroundColor"
    //     0xd5a7d0: ldr             x16, [x16, #0xa10]
    //     0xd5a7d4: cmp             w20, w16
    //     0xd5a7d8: b.ne            #0xd5a808
    //     0xd5a7dc: add             w1, w14, #0xa
    //     0xd5a7e0: add             x16, x4, w1, sxtw #1
    //     0xd5a7e4: ldur            w14, [x16, #0xf]
    //     0xd5a7e8: add             x14, x14, HEAP, lsl #32
    //     0xd5a7ec: sub             w1, w0, w14
    //     0xd5a7f0: add             x14, fp, w1, sxtw #2
    //     0xd5a7f4: ldr             x14, [x14, #8]
    //     0xd5a7f8: add             w1, w2, #2
    //     0xd5a7fc: sbfx            x2, x1, #1, #0x1f
    //     0xd5a800: mov             x1, x2
    //     0xd5a804: b               #0xd5a80c
    //     0xd5a808: mov             x14, NULL
    //     0xd5a80c: stur            x14, [fp, #-0x58]
    //     0xd5a810: lsl             x2, x1, #1
    //     0xd5a814: lsl             w19, w2, #1
    //     0xd5a818: add             w20, w19, #8
    //     0xd5a81c: add             x16, x4, w20, sxtw #1
    //     0xd5a820: ldur            w23, [x16, #0xf]
    //     0xd5a824: add             x23, x23, HEAP, lsl #32
    //     0xd5a828: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a18] "maximumSize"
    //     0xd5a82c: ldr             x16, [x16, #0xa18]
    //     0xd5a830: cmp             w23, w16
    //     0xd5a834: b.ne            #0xd5a864
    //     0xd5a838: add             w1, w19, #0xa
    //     0xd5a83c: add             x16, x4, w1, sxtw #1
    //     0xd5a840: ldur            w19, [x16, #0xf]
    //     0xd5a844: add             x19, x19, HEAP, lsl #32
    //     0xd5a848: sub             w1, w0, w19
    //     0xd5a84c: add             x19, fp, w1, sxtw #2
    //     0xd5a850: ldr             x19, [x19, #8]
    //     0xd5a854: add             w1, w2, #2
    //     0xd5a858: sbfx            x2, x1, #1, #0x1f
    //     0xd5a85c: mov             x1, x2
    //     0xd5a860: b               #0xd5a868
    //     0xd5a864: mov             x19, NULL
    //     0xd5a868: stur            x19, [fp, #-0x50]
    //     0xd5a86c: lsl             x2, x1, #1
    //     0xd5a870: lsl             w20, w2, #1
    //     0xd5a874: add             w23, w20, #8
    //     0xd5a878: add             x16, x4, w23, sxtw #1
    //     0xd5a87c: ldur            w24, [x16, #0xf]
    //     0xd5a880: add             x24, x24, HEAP, lsl #32
    //     0xd5a884: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a20] "minimumSize"
    //     0xd5a888: ldr             x16, [x16, #0xa20]
    //     0xd5a88c: cmp             w24, w16
    //     0xd5a890: b.ne            #0xd5a8c0
    //     0xd5a894: add             w1, w20, #0xa
    //     0xd5a898: add             x16, x4, w1, sxtw #1
    //     0xd5a89c: ldur            w20, [x16, #0xf]
    //     0xd5a8a0: add             x20, x20, HEAP, lsl #32
    //     0xd5a8a4: sub             w1, w0, w20
    //     0xd5a8a8: add             x20, fp, w1, sxtw #2
    //     0xd5a8ac: ldr             x20, [x20, #8]
    //     0xd5a8b0: add             w1, w2, #2
    //     0xd5a8b4: sbfx            x2, x1, #1, #0x1f
    //     0xd5a8b8: mov             x1, x2
    //     0xd5a8bc: b               #0xd5a8c4
    //     0xd5a8c0: mov             x20, NULL
    //     0xd5a8c4: stur            x20, [fp, #-0x48]
    //     0xd5a8c8: lsl             x2, x1, #1
    //     0xd5a8cc: lsl             w23, w2, #1
    //     0xd5a8d0: add             w24, w23, #8
    //     0xd5a8d4: add             x16, x4, w24, sxtw #1
    //     0xd5a8d8: ldur            w25, [x16, #0xf]
    //     0xd5a8dc: add             x25, x25, HEAP, lsl #32
    //     0xd5a8e0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12838] "padding"
    //     0xd5a8e4: ldr             x16, [x16, #0x838]
    //     0xd5a8e8: cmp             w25, w16
    //     0xd5a8ec: b.ne            #0xd5a91c
    //     0xd5a8f0: add             w1, w23, #0xa
    //     0xd5a8f4: add             x16, x4, w1, sxtw #1
    //     0xd5a8f8: ldur            w23, [x16, #0xf]
    //     0xd5a8fc: add             x23, x23, HEAP, lsl #32
    //     0xd5a900: sub             w1, w0, w23
    //     0xd5a904: add             x23, fp, w1, sxtw #2
    //     0xd5a908: ldr             x23, [x23, #8]
    //     0xd5a90c: add             w1, w2, #2
    //     0xd5a910: sbfx            x2, x1, #1, #0x1f
    //     0xd5a914: mov             x1, x2
    //     0xd5a918: b               #0xd5a920
    //     0xd5a91c: mov             x23, NULL
    //     0xd5a920: stur            x23, [fp, #-0x40]
    //     0xd5a924: lsl             x2, x1, #1
    //     0xd5a928: lsl             w24, w2, #1
    //     0xd5a92c: add             w25, w24, #8
    //     0xd5a930: add             x16, x4, w25, sxtw #1
    //     0xd5a934: ldur            w3, [x16, #0xf]
    //     0xd5a938: add             x3, x3, HEAP, lsl #32
    //     0xd5a93c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b70] "shadowColor"
    //     0xd5a940: ldr             x16, [x16, #0xb70]
    //     0xd5a944: cmp             w3, w16
    //     0xd5a948: b.ne            #0xd5a978
    //     0xd5a94c: add             w1, w24, #0xa
    //     0xd5a950: add             x16, x4, w1, sxtw #1
    //     0xd5a954: ldur            w3, [x16, #0xf]
    //     0xd5a958: add             x3, x3, HEAP, lsl #32
    //     0xd5a95c: sub             w1, w0, w3
    //     0xd5a960: add             x3, fp, w1, sxtw #2
    //     0xd5a964: ldr             x3, [x3, #8]
    //     0xd5a968: add             w1, w2, #2
    //     0xd5a96c: sbfx            x2, x1, #1, #0x1f
    //     0xd5a970: mov             x1, x2
    //     0xd5a974: b               #0xd5a97c
    //     0xd5a978: mov             x3, NULL
    //     0xd5a97c: stur            x3, [fp, #-0x10]
    //     0xd5a980: lsl             x2, x1, #1
    //     0xd5a984: lsl             w24, w2, #1
    //     0xd5a988: add             w25, w24, #8
    //     0xd5a98c: add             x16, x4, w25, sxtw #1
    //     0xd5a990: ldur            w3, [x16, #0xf]
    //     0xd5a994: add             x3, x3, HEAP, lsl #32
    //     0xd5a998: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a28] "shape"
    //     0xd5a99c: ldr             x16, [x16, #0xa28]
    //     0xd5a9a0: cmp             w3, w16
    //     0xd5a9a4: b.ne            #0xd5a9d4
    //     0xd5a9a8: add             w1, w24, #0xa
    //     0xd5a9ac: add             x16, x4, w1, sxtw #1
    //     0xd5a9b0: ldur            w3, [x16, #0xf]
    //     0xd5a9b4: add             x3, x3, HEAP, lsl #32
    //     0xd5a9b8: sub             w1, w0, w3
    //     0xd5a9bc: add             x3, fp, w1, sxtw #2
    //     0xd5a9c0: ldr             x3, [x3, #8]
    //     0xd5a9c4: add             w1, w2, #2
    //     0xd5a9c8: sbfx            x2, x1, #1, #0x1f
    //     0xd5a9cc: mov             x1, x2
    //     0xd5a9d0: b               #0xd5a9d8
    //     0xd5a9d4: mov             x3, NULL
    //     0xd5a9d8: stur            x3, [fp, #-0x18]
    //     0xd5a9dc: lsl             x2, x1, #1
    //     0xd5a9e0: lsl             w24, w2, #1
    //     0xd5a9e4: add             w25, w24, #8
    //     0xd5a9e8: add             x16, x4, w25, sxtw #1
    //     0xd5a9ec: ldur            w3, [x16, #0xf]
    //     0xd5a9f0: add             x3, x3, HEAP, lsl #32
    //     0xd5a9f4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b88] "splashFactory"
    //     0xd5a9f8: ldr             x16, [x16, #0xb88]
    //     0xd5a9fc: cmp             w3, w16
    //     0xd5aa00: b.ne            #0xd5aa30
    //     0xd5aa04: add             w1, w24, #0xa
    //     0xd5aa08: add             x16, x4, w1, sxtw #1
    //     0xd5aa0c: ldur            w3, [x16, #0xf]
    //     0xd5aa10: add             x3, x3, HEAP, lsl #32
    //     0xd5aa14: sub             w1, w0, w3
    //     0xd5aa18: add             x3, fp, w1, sxtw #2
    //     0xd5aa1c: ldr             x3, [x3, #8]
    //     0xd5aa20: add             w1, w2, #2
    //     0xd5aa24: sbfx            x2, x1, #1, #0x1f
    //     0xd5aa28: mov             x1, x2
    //     0xd5aa2c: b               #0xd5aa34
    //     0xd5aa30: mov             x3, NULL
    //     0xd5aa34: stur            x3, [fp, #-0x20]
    //     0xd5aa38: lsl             x2, x1, #1
    //     0xd5aa3c: lsl             w24, w2, #1
    //     0xd5aa40: add             w25, w24, #8
    //     0xd5aa44: add             x16, x4, w25, sxtw #1
    //     0xd5aa48: ldur            w3, [x16, #0xf]
    //     0xd5aa4c: add             x3, x3, HEAP, lsl #32
    //     0xd5aa50: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a30] "tapTargetSize"
    //     0xd5aa54: ldr             x16, [x16, #0xa30]
    //     0xd5aa58: cmp             w3, w16
    //     0xd5aa5c: b.ne            #0xd5aa8c
    //     0xd5aa60: add             w1, w24, #0xa
    //     0xd5aa64: add             x16, x4, w1, sxtw #1
    //     0xd5aa68: ldur            w3, [x16, #0xf]
    //     0xd5aa6c: add             x3, x3, HEAP, lsl #32
    //     0xd5aa70: sub             w1, w0, w3
    //     0xd5aa74: add             x3, fp, w1, sxtw #2
    //     0xd5aa78: ldr             x3, [x3, #8]
    //     0xd5aa7c: add             w1, w2, #2
    //     0xd5aa80: sbfx            x2, x1, #1, #0x1f
    //     0xd5aa84: mov             x1, x2
    //     0xd5aa88: b               #0xd5aa90
    //     0xd5aa8c: mov             x3, NULL
    //     0xd5aa90: stur            x3, [fp, #-0x28]
    //     0xd5aa94: lsl             x2, x1, #1
    //     0xd5aa98: lsl             w24, w2, #1
    //     0xd5aa9c: add             w25, w24, #8
    //     0xd5aaa0: add             x16, x4, w25, sxtw #1
    //     0xd5aaa4: ldur            w3, [x16, #0xf]
    //     0xd5aaa8: add             x3, x3, HEAP, lsl #32
    //     0xd5aaac: add             x16, PP, #0x13, lsl #12  ; [pp+0x13e08] "textStyle"
    //     0xd5aab0: ldr             x16, [x16, #0xe08]
    //     0xd5aab4: cmp             w3, w16
    //     0xd5aab8: b.ne            #0xd5aae8
    //     0xd5aabc: add             w1, w24, #0xa
    //     0xd5aac0: add             x16, x4, w1, sxtw #1
    //     0xd5aac4: ldur            w3, [x16, #0xf]
    //     0xd5aac8: add             x3, x3, HEAP, lsl #32
    //     0xd5aacc: sub             w1, w0, w3
    //     0xd5aad0: add             x3, fp, w1, sxtw #2
    //     0xd5aad4: ldr             x3, [x3, #8]
    //     0xd5aad8: add             w1, w2, #2
    //     0xd5aadc: sbfx            x2, x1, #1, #0x1f
    //     0xd5aae0: mov             x1, x2
    //     0xd5aae4: b               #0xd5aaec
    //     0xd5aae8: mov             x3, NULL
    //     0xd5aaec: stur            x3, [fp, #-0x38]
    //     0xd5aaf0: lsl             x2, x1, #1
    //     0xd5aaf4: lsl             w1, w2, #1
    //     0xd5aaf8: add             w2, w1, #8
    //     0xd5aafc: add             x16, x4, w2, sxtw #1
    //     0xd5ab00: ldur            w24, [x16, #0xf]
    //     0xd5ab04: add             x24, x24, HEAP, lsl #32
    //     0xd5ab08: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a38] "visualDensity"
    //     0xd5ab0c: ldr             x16, [x16, #0xa38]
    //     0xd5ab10: cmp             w24, w16
    //     0xd5ab14: b.ne            #0xd5ab3c
    //     0xd5ab18: add             w2, w1, #0xa
    //     0xd5ab1c: add             x16, x4, w2, sxtw #1
    //     0xd5ab20: ldur            w1, [x16, #0xf]
    //     0xd5ab24: add             x1, x1, HEAP, lsl #32
    //     0xd5ab28: sub             w2, w0, w1
    //     0xd5ab2c: add             x0, fp, w2, sxtw #2
    //     0xd5ab30: ldr             x0, [x0, #8]
    //     0xd5ab34: mov             x4, x0
    //     0xd5ab38: b               #0xd5ab40
    //     0xd5ab3c: mov             x4, NULL
    //     0xd5ab40: stur            x4, [fp, #-0x30]
    // 0xd5ab44: CheckStackOverflow
    //     0xd5ab44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5ab48: cmp             SP, x16
    //     0xd5ab4c: b.ls            #0xd5b1a4
    // 0xd5ab50: cmp             w14, NULL
    // 0xd5ab54: b.ne            #0xd5ab64
    // 0xd5ab58: mov             x0, x10
    // 0xd5ab5c: r3 = Null
    //     0xd5ab5c: mov             x3, NULL
    // 0xd5ab60: b               #0xd5ade0
    // 0xd5ab64: r0 = Null
    //     0xd5ab64: mov             x0, NULL
    // 0xd5ab68: r2 = Null
    //     0xd5ab68: mov             x2, NULL
    // 0xd5ab6c: r1 = Null
    //     0xd5ab6c: mov             x1, NULL
    // 0xd5ab70: cmp             w0, NULL
    // 0xd5ab74: b.eq            #0xd5ab98
    // 0xd5ab78: branchIfSmi(r0, 0xd5ab98)
    //     0xd5ab78: tbz             w0, #0, #0xd5ab98
    // 0xd5ab7c: r3 = LoadClassIdInstr(r0)
    //     0xd5ab7c: ldur            x3, [x0, #-1]
    //     0xd5ab80: ubfx            x3, x3, #0xc, #0x14
    // 0xd5ab84: sub             x3, x3, #0xecc
    // 0xd5ab88: cmp             x3, #5
    // 0xd5ab8c: b.ls            #0xd5aba0
    // 0xd5ab90: cmp             x3, #0x5ad
    // 0xd5ab94: b.eq            #0xd5aba0
    // 0xd5ab98: r0 = false
    //     0xd5ab98: add             x0, NULL, #0x30  ; false
    // 0xd5ab9c: b               #0xd5aba4
    // 0xd5aba0: r0 = true
    //     0xd5aba0: add             x0, NULL, #0x20  ; true
    // 0xd5aba4: tbnz            w0, #4, #0xd5abe4
    // 0xd5aba8: r0 = 171
    //     0xd5aba8: mov             x0, #0xab
    // 0xd5abac: r1 = Null
    //     0xd5abac: mov             x1, NULL
    // 0xd5abb0: r0 = GDT[cid_x0 + -0xfe4]()
    //     0xd5abb0: sub             lr, x0, #0xfe4
    //     0xd5abb4: ldr             lr, [x21, lr, lsl #3]
    //     0xd5abb8: blr             lr
    // 0xd5abbc: mov             v1.16b, v0.16b
    // 0xd5abc0: d0 = 0.000000
    //     0xd5abc0: eor             v0.16b, v0.16b, v0.16b
    // 0xd5abc4: fcmp            d1, d0
    // 0xd5abc8: b.ne            #0xd5abe4
    // 0xd5abcc: r1 = <Color?>
    //     0xd5abcc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd5abd0: ldr             x1, [x1, #0xa40]
    // 0xd5abd4: r0 = WidgetStatePropertyAll()
    //     0xd5abd4: bl              #0xd132c8  ; AllocateWidgetStatePropertyAllStub -> WidgetStatePropertyAll<X0> (size=0x10)
    // 0xd5abd8: mov             x3, x0
    // 0xd5abdc: ldur            x0, [fp, #-0x78]
    // 0xd5abe0: b               #0xd5ade0
    // 0xd5abe4: r0 = Null
    //     0xd5abe4: mov             x0, NULL
    // 0xd5abe8: r2 = Null
    //     0xd5abe8: mov             x2, NULL
    // 0xd5abec: r1 = Null
    //     0xd5abec: mov             x1, NULL
    // 0xd5abf0: cmp             w0, NULL
    // 0xd5abf4: b.eq            #0xd5ac18
    // 0xd5abf8: branchIfSmi(r0, 0xd5ac18)
    //     0xd5abf8: tbz             w0, #0, #0xd5ac18
    // 0xd5abfc: r3 = LoadClassIdInstr(r0)
    //     0xd5abfc: ldur            x3, [x0, #-1]
    //     0xd5ac00: ubfx            x3, x3, #0xc, #0x14
    // 0xd5ac04: sub             x3, x3, #0xecc
    // 0xd5ac08: cmp             x3, #5
    // 0xd5ac0c: b.ls            #0xd5ac20
    // 0xd5ac10: cmp             x3, #0x5ad
    // 0xd5ac14: b.eq            #0xd5ac20
    // 0xd5ac18: r0 = false
    //     0xd5ac18: add             x0, NULL, #0x30  ; false
    // 0xd5ac1c: b               #0xd5ac24
    // 0xd5ac20: r0 = true
    //     0xd5ac20: add             x0, NULL, #0x20  ; true
    // 0xd5ac24: tbnz            w0, #4, #0xd5ac30
    // 0xd5ac28: r0 = Null
    //     0xd5ac28: mov             x0, NULL
    // 0xd5ac2c: b               #0xd5ac78
    // 0xd5ac30: ldur            x0, [fp, #-0x58]
    // 0xd5ac34: r2 = Null
    //     0xd5ac34: mov             x2, NULL
    // 0xd5ac38: r1 = Null
    //     0xd5ac38: mov             x1, NULL
    // 0xd5ac3c: cmp             w0, NULL
    // 0xd5ac40: b.eq            #0xd5ac64
    // 0xd5ac44: branchIfSmi(r0, 0xd5ac64)
    //     0xd5ac44: tbz             w0, #0, #0xd5ac64
    // 0xd5ac48: r3 = LoadClassIdInstr(r0)
    //     0xd5ac48: ldur            x3, [x0, #-1]
    //     0xd5ac4c: ubfx            x3, x3, #0xc, #0x14
    // 0xd5ac50: sub             x3, x3, #0xecc
    // 0xd5ac54: cmp             x3, #5
    // 0xd5ac58: b.ls            #0xd5ac6c
    // 0xd5ac5c: cmp             x3, #0x5ad
    // 0xd5ac60: b.eq            #0xd5ac6c
    // 0xd5ac64: r0 = false
    //     0xd5ac64: add             x0, NULL, #0x30  ; false
    // 0xd5ac68: b               #0xd5ac70
    // 0xd5ac6c: r0 = true
    //     0xd5ac6c: add             x0, NULL, #0x20  ; true
    // 0xd5ac70: tbnz            w0, #4, #0xd5add8
    // 0xd5ac74: ldur            x0, [fp, #-0x58]
    // 0xd5ac78: stur            x0, [fp, #-0xa8]
    // 0xd5ac7c: r1 = Null
    //     0xd5ac7c: mov             x1, NULL
    // 0xd5ac80: r2 = 12
    //     0xd5ac80: mov             x2, #0xc
    // 0xd5ac84: r0 = AllocateArray()
    //     0xd5ac84: bl              #0x13df928  ; AllocateArrayStub
    // 0xd5ac88: mov             x2, x0
    // 0xd5ac8c: stur            x2, [fp, #-0xb0]
    // 0xd5ac90: r16 = Instance_WidgetState
    //     0xd5ac90: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd5ac94: ldr             x16, [x16, #0xa48]
    // 0xd5ac98: StoreField: r2->field_f = r16
    //     0xd5ac98: stur            w16, [x2, #0xf]
    // 0xd5ac9c: ldur            x3, [fp, #-0xa8]
    // 0xd5aca0: r0 = LoadClassIdInstr(r3)
    //     0xd5aca0: ldur            x0, [x3, #-1]
    //     0xd5aca4: ubfx            x0, x0, #0xc, #0x14
    // 0xd5aca8: mov             x1, x3
    // 0xd5acac: d0 = 0.100000
    //     0xd5acac: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xd5acb0: ldr             d0, [x17, #0x1e0]
    // 0xd5acb4: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd5acb4: sub             lr, x0, #1, lsl #12
    //     0xd5acb8: ldr             lr, [x21, lr, lsl #3]
    //     0xd5acbc: blr             lr
    // 0xd5acc0: ldur            x1, [fp, #-0xb0]
    // 0xd5acc4: ArrayStore: r1[1] = r0  ; List_4
    //     0xd5acc4: add             x25, x1, #0x13
    //     0xd5acc8: str             w0, [x25]
    //     0xd5accc: tbz             w0, #0, #0xd5ace8
    //     0xd5acd0: ldurb           w16, [x1, #-1]
    //     0xd5acd4: ldurb           w17, [x0, #-1]
    //     0xd5acd8: and             x16, x17, x16, lsr #2
    //     0xd5acdc: tst             x16, HEAP, lsr #32
    //     0xd5ace0: b.eq            #0xd5ace8
    //     0xd5ace4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd5ace8: ldur            x2, [fp, #-0xb0]
    // 0xd5acec: r16 = Instance_WidgetState
    //     0xd5acec: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd5acf0: ldr             x16, [x16, #0xa50]
    // 0xd5acf4: ArrayStore: r2[0] = r16  ; List_4
    //     0xd5acf4: stur            w16, [x2, #0x17]
    // 0xd5acf8: ldur            x3, [fp, #-0xa8]
    // 0xd5acfc: r0 = LoadClassIdInstr(r3)
    //     0xd5acfc: ldur            x0, [x3, #-1]
    //     0xd5ad00: ubfx            x0, x0, #0xc, #0x14
    // 0xd5ad04: mov             x1, x3
    // 0xd5ad08: d0 = 0.080000
    //     0xd5ad08: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xd5ad0c: ldr             d0, [x17, #0xa58]
    // 0xd5ad10: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd5ad10: sub             lr, x0, #1, lsl #12
    //     0xd5ad14: ldr             lr, [x21, lr, lsl #3]
    //     0xd5ad18: blr             lr
    // 0xd5ad1c: ldur            x1, [fp, #-0xb0]
    // 0xd5ad20: ArrayStore: r1[3] = r0  ; List_4
    //     0xd5ad20: add             x25, x1, #0x1b
    //     0xd5ad24: str             w0, [x25]
    //     0xd5ad28: tbz             w0, #0, #0xd5ad44
    //     0xd5ad2c: ldurb           w16, [x1, #-1]
    //     0xd5ad30: ldurb           w17, [x0, #-1]
    //     0xd5ad34: and             x16, x17, x16, lsr #2
    //     0xd5ad38: tst             x16, HEAP, lsr #32
    //     0xd5ad3c: b.eq            #0xd5ad44
    //     0xd5ad40: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd5ad44: ldur            x2, [fp, #-0xb0]
    // 0xd5ad48: r16 = Instance_WidgetState
    //     0xd5ad48: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd5ad4c: ldr             x16, [x16, #0xa60]
    // 0xd5ad50: StoreField: r2->field_1f = r16
    //     0xd5ad50: stur            w16, [x2, #0x1f]
    // 0xd5ad54: ldur            x1, [fp, #-0xa8]
    // 0xd5ad58: r0 = LoadClassIdInstr(r1)
    //     0xd5ad58: ldur            x0, [x1, #-1]
    //     0xd5ad5c: ubfx            x0, x0, #0xc, #0x14
    // 0xd5ad60: d0 = 0.100000
    //     0xd5ad60: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xd5ad64: ldr             d0, [x17, #0x1e0]
    // 0xd5ad68: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd5ad68: sub             lr, x0, #1, lsl #12
    //     0xd5ad6c: ldr             lr, [x21, lr, lsl #3]
    //     0xd5ad70: blr             lr
    // 0xd5ad74: ldur            x1, [fp, #-0xb0]
    // 0xd5ad78: ArrayStore: r1[5] = r0  ; List_4
    //     0xd5ad78: add             x25, x1, #0x23
    //     0xd5ad7c: str             w0, [x25]
    //     0xd5ad80: tbz             w0, #0, #0xd5ad9c
    //     0xd5ad84: ldurb           w16, [x1, #-1]
    //     0xd5ad88: ldurb           w17, [x0, #-1]
    //     0xd5ad8c: and             x16, x17, x16, lsr #2
    //     0xd5ad90: tst             x16, HEAP, lsr #32
    //     0xd5ad94: b.eq            #0xd5ad9c
    //     0xd5ad98: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd5ad9c: r16 = <WidgetState, Color?>
    //     0xd5ad9c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a68] TypeArguments: <WidgetState, Color?>
    //     0xd5ada0: ldr             x16, [x16, #0xa68]
    // 0xd5ada4: ldur            lr, [fp, #-0xb0]
    // 0xd5ada8: stp             lr, x16, [SP]
    // 0xd5adac: r0 = Map._fromLiteral()
    //     0xd5adac: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xd5adb0: r1 = <Color?>
    //     0xd5adb0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd5adb4: ldr             x1, [x1, #0xa40]
    // 0xd5adb8: stur            x0, [fp, #-0xa8]
    // 0xd5adbc: r0 = WidgetStateMapper()
    //     0xd5adbc: bl              #0xd171e0  ; AllocateWidgetStateMapperStub -> WidgetStateMapper<X0> (size=0x10)
    // 0xd5adc0: mov             x1, x0
    // 0xd5adc4: ldur            x0, [fp, #-0xa8]
    // 0xd5adc8: StoreField: r1->field_b = r0
    //     0xd5adc8: stur            w0, [x1, #0xb]
    // 0xd5adcc: mov             x3, x1
    // 0xd5add0: ldur            x0, [fp, #-0x78]
    // 0xd5add4: b               #0xd5ade0
    // 0xd5add8: ldur            x0, [fp, #-0x78]
    // 0xd5addc: r3 = Null
    //     0xd5addc: mov             x3, NULL
    // 0xd5ade0: stur            x3, [fp, #-0xa8]
    // 0xd5ade4: cmp             w0, NULL
    // 0xd5ade8: b.eq            #0xd5af8c
    // 0xd5adec: r1 = Null
    //     0xd5adec: mov             x1, NULL
    // 0xd5adf0: r2 = 20
    //     0xd5adf0: mov             x2, #0x14
    // 0xd5adf4: r0 = AllocateArray()
    //     0xd5adf4: bl              #0x13df928  ; AllocateArrayStub
    // 0xd5adf8: mov             x2, x0
    // 0xd5adfc: r16 = Instance_WidgetState
    //     0xd5adfc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd5ae00: ldr             x16, [x16, #0xa70]
    // 0xd5ae04: StoreField: r2->field_f = r16
    //     0xd5ae04: stur            w16, [x2, #0xf]
    // 0xd5ae08: r16 = 0.000000
    //     0xd5ae08: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd5ae0c: StoreField: r2->field_13 = r16
    //     0xd5ae0c: stur            w16, [x2, #0x13]
    // 0xd5ae10: r16 = Instance_WidgetState
    //     0xd5ae10: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd5ae14: ldr             x16, [x16, #0xa48]
    // 0xd5ae18: ArrayStore: r2[0] = r16  ; List_4
    //     0xd5ae18: stur            w16, [x2, #0x17]
    // 0xd5ae1c: ldur            x3, [fp, #-0x78]
    // 0xd5ae20: LoadField: d0 = r3->field_7
    //     0xd5ae20: ldur            d0, [x3, #7]
    // 0xd5ae24: d1 = 6.000000
    //     0xd5ae24: fmov            d1, #6.00000000
    // 0xd5ae28: fadd            d2, d0, d1
    // 0xd5ae2c: r0 = inline_Allocate_Double()
    //     0xd5ae2c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd5ae30: add             x0, x0, #0x10
    //     0xd5ae34: cmp             x1, x0
    //     0xd5ae38: b.ls            #0xd5b1ac
    //     0xd5ae3c: str             x0, [THR, #0x60]  ; THR::top
    //     0xd5ae40: sub             x0, x0, #0xf
    //     0xd5ae44: mov             x1, #0xe19c
    //     0xd5ae48: movk            x1, #3, lsl #16
    //     0xd5ae4c: stur            x1, [x0, #-1]
    // 0xd5ae50: dmb             ishst
    // 0xd5ae54: StoreField: r0->field_7 = d2
    //     0xd5ae54: stur            d2, [x0, #7]
    // 0xd5ae58: mov             x1, x2
    // 0xd5ae5c: ArrayStore: r1[3] = r0  ; List_4
    //     0xd5ae5c: add             x25, x1, #0x1b
    //     0xd5ae60: str             w0, [x25]
    //     0xd5ae64: tbz             w0, #0, #0xd5ae80
    //     0xd5ae68: ldurb           w16, [x1, #-1]
    //     0xd5ae6c: ldurb           w17, [x0, #-1]
    //     0xd5ae70: and             x16, x17, x16, lsr #2
    //     0xd5ae74: tst             x16, HEAP, lsr #32
    //     0xd5ae78: b.eq            #0xd5ae80
    //     0xd5ae7c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd5ae80: r16 = Instance_WidgetState
    //     0xd5ae80: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd5ae84: ldr             x16, [x16, #0xa50]
    // 0xd5ae88: StoreField: r2->field_1f = r16
    //     0xd5ae88: stur            w16, [x2, #0x1f]
    // 0xd5ae8c: d1 = 2.000000
    //     0xd5ae8c: fmov            d1, #2.00000000
    // 0xd5ae90: fadd            d2, d0, d1
    // 0xd5ae94: r4 = inline_Allocate_Double()
    //     0xd5ae94: ldp             x4, x0, [THR, #0x60]  ; THR::top
    //     0xd5ae98: add             x4, x4, #0x10
    //     0xd5ae9c: cmp             x0, x4
    //     0xd5aea0: b.ls            #0xd5b1c4
    //     0xd5aea4: str             x4, [THR, #0x60]  ; THR::top
    //     0xd5aea8: sub             x4, x4, #0xf
    //     0xd5aeac: mov             x0, #0xe19c
    //     0xd5aeb0: movk            x0, #3, lsl #16
    //     0xd5aeb4: stur            x0, [x4, #-1]
    // 0xd5aeb8: dmb             ishst
    // 0xd5aebc: StoreField: r4->field_7 = d2
    //     0xd5aebc: stur            d2, [x4, #7]
    // 0xd5aec0: mov             x1, x2
    // 0xd5aec4: mov             x0, x4
    // 0xd5aec8: ArrayStore: r1[5] = r0  ; List_4
    //     0xd5aec8: add             x25, x1, #0x23
    //     0xd5aecc: str             w0, [x25]
    //     0xd5aed0: tbz             w0, #0, #0xd5aeec
    //     0xd5aed4: ldurb           w16, [x1, #-1]
    //     0xd5aed8: ldurb           w17, [x0, #-1]
    //     0xd5aedc: and             x16, x17, x16, lsr #2
    //     0xd5aee0: tst             x16, HEAP, lsr #32
    //     0xd5aee4: b.eq            #0xd5aeec
    //     0xd5aee8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd5aeec: r16 = Instance_WidgetState
    //     0xd5aeec: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd5aef0: ldr             x16, [x16, #0xa60]
    // 0xd5aef4: StoreField: r2->field_27 = r16
    //     0xd5aef4: stur            w16, [x2, #0x27]
    // 0xd5aef8: mov             x1, x2
    // 0xd5aefc: mov             x0, x4
    // 0xd5af00: ArrayStore: r1[7] = r0  ; List_4
    //     0xd5af00: add             x25, x1, #0x2b
    //     0xd5af04: str             w0, [x25]
    //     0xd5af08: tbz             w0, #0, #0xd5af24
    //     0xd5af0c: ldurb           w16, [x1, #-1]
    //     0xd5af10: ldurb           w17, [x0, #-1]
    //     0xd5af14: and             x16, x17, x16, lsr #2
    //     0xd5af18: tst             x16, HEAP, lsr #32
    //     0xd5af1c: b.eq            #0xd5af24
    //     0xd5af20: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd5af24: r16 = Instance__AnyWidgetStates
    //     0xd5af24: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a78] Obj!_AnyWidgetStates@12aa401
    //     0xd5af28: ldr             x16, [x16, #0xa78]
    // 0xd5af2c: StoreField: r2->field_2f = r16
    //     0xd5af2c: stur            w16, [x2, #0x2f]
    // 0xd5af30: mov             x1, x2
    // 0xd5af34: mov             x0, x3
    // 0xd5af38: ArrayStore: r1[9] = r0  ; List_4
    //     0xd5af38: add             x25, x1, #0x33
    //     0xd5af3c: str             w0, [x25]
    //     0xd5af40: tbz             w0, #0, #0xd5af5c
    //     0xd5af44: ldurb           w16, [x1, #-1]
    //     0xd5af48: ldurb           w17, [x0, #-1]
    //     0xd5af4c: and             x16, x17, x16, lsr #2
    //     0xd5af50: tst             x16, HEAP, lsr #32
    //     0xd5af54: b.eq            #0xd5af5c
    //     0xd5af58: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd5af5c: r16 = <WidgetStatesConstraint, double>
    //     0xd5af5c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a80] TypeArguments: <WidgetStatesConstraint, double>
    //     0xd5af60: ldr             x16, [x16, #0xa80]
    // 0xd5af64: stp             x2, x16, [SP]
    // 0xd5af68: r0 = Map._fromLiteral()
    //     0xd5af68: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xd5af6c: r1 = <double>
    //     0xd5af6c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd5af70: stur            x0, [fp, #-0x78]
    // 0xd5af74: r0 = WidgetStateMapper()
    //     0xd5af74: bl              #0xd171e0  ; AllocateWidgetStateMapperStub -> WidgetStateMapper<X0> (size=0x10)
    // 0xd5af78: mov             x1, x0
    // 0xd5af7c: ldur            x0, [fp, #-0x78]
    // 0xd5af80: StoreField: r1->field_b = r0
    //     0xd5af80: stur            w0, [x1, #0xb]
    // 0xd5af84: mov             x11, x1
    // 0xd5af88: b               #0xd5af90
    // 0xd5af8c: r11 = Null
    //     0xd5af8c: mov             x11, NULL
    // 0xd5af90: ldur            x2, [fp, #-8]
    // 0xd5af94: ldur            x3, [fp, #-0xa0]
    // 0xd5af98: ldur            x4, [fp, #-0x80]
    // 0xd5af9c: ldur            x5, [fp, #-0x70]
    // 0xd5afa0: ldur            x6, [fp, #-0x68]
    // 0xd5afa4: ldur            x7, [fp, #-0x20]
    // 0xd5afa8: ldur            x8, [fp, #-0x28]
    // 0xd5afac: ldur            x9, [fp, #-0x38]
    // 0xd5afb0: ldur            x10, [fp, #-0x30]
    // 0xd5afb4: ldur            x0, [fp, #-0xa8]
    // 0xd5afb8: stur            x11, [fp, #-0x78]
    // 0xd5afbc: r1 = <TextStyle?>
    //     0xd5afbc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a88] TypeArguments: <TextStyle?>
    //     0xd5afc0: ldr             x1, [x1, #0xa88]
    // 0xd5afc4: r0 = WidgetStatePropertyAll()
    //     0xd5afc4: bl              #0xd132c8  ; AllocateWidgetStatePropertyAllStub -> WidgetStatePropertyAll<X0> (size=0x10)
    // 0xd5afc8: mov             x3, x0
    // 0xd5afcc: ldur            x0, [fp, #-0x38]
    // 0xd5afd0: stur            x3, [fp, #-0xb0]
    // 0xd5afd4: StoreField: r3->field_b = r0
    //     0xd5afd4: stur            w0, [x3, #0xb]
    // 0xd5afd8: ldur            x1, [fp, #-0x98]
    // 0xd5afdc: ldur            x2, [fp, #-0x90]
    // 0xd5afe0: r0 = defaultColor()
    //     0xd5afe0: bl              #0xd171ec  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::defaultColor
    // 0xd5afe4: ldur            x1, [fp, #-0x58]
    // 0xd5afe8: ldur            x2, [fp, #-0x88]
    // 0xd5afec: stur            x0, [fp, #-0x38]
    // 0xd5aff0: r0 = defaultColor()
    //     0xd5aff0: bl              #0xd171ec  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::defaultColor
    // 0xd5aff4: stur            x0, [fp, #-0x58]
    // 0xd5aff8: r16 = <Color>
    //     0xd5aff8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd5affc: ldr             x16, [x16, #0xa90]
    // 0xd5b000: ldur            lr, [fp, #-0x10]
    // 0xd5b004: stp             lr, x16, [SP]
    // 0xd5b008: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd5b008: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd5b00c: r0 = allOrNull()
    //     0xd5b00c: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xd5b010: stur            x0, [fp, #-0x10]
    // 0xd5b014: r16 = <EdgeInsetsGeometry>
    //     0xd5b014: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a98] TypeArguments: <EdgeInsetsGeometry>
    //     0xd5b018: ldr             x16, [x16, #0xa98]
    // 0xd5b01c: ldur            lr, [fp, #-0x40]
    // 0xd5b020: stp             lr, x16, [SP]
    // 0xd5b024: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd5b024: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd5b028: r0 = allOrNull()
    //     0xd5b028: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xd5b02c: stur            x0, [fp, #-0x40]
    // 0xd5b030: r16 = <Size>
    //     0xd5b030: add             x16, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xd5b034: ldr             x16, [x16, #0xaa0]
    // 0xd5b038: ldur            lr, [fp, #-0x48]
    // 0xd5b03c: stp             lr, x16, [SP]
    // 0xd5b040: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd5b040: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd5b044: r0 = allOrNull()
    //     0xd5b044: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xd5b048: stur            x0, [fp, #-0x48]
    // 0xd5b04c: r16 = <Size>
    //     0xd5b04c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xd5b050: ldr             x16, [x16, #0xaa0]
    // 0xd5b054: ldur            lr, [fp, #-0x60]
    // 0xd5b058: stp             lr, x16, [SP]
    // 0xd5b05c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd5b05c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd5b060: r0 = allOrNull()
    //     0xd5b060: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xd5b064: stur            x0, [fp, #-0x60]
    // 0xd5b068: r16 = <Size>
    //     0xd5b068: add             x16, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xd5b06c: ldr             x16, [x16, #0xaa0]
    // 0xd5b070: ldur            lr, [fp, #-0x50]
    // 0xd5b074: stp             lr, x16, [SP]
    // 0xd5b078: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd5b078: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd5b07c: r0 = allOrNull()
    //     0xd5b07c: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xd5b080: stur            x0, [fp, #-0x50]
    // 0xd5b084: r16 = <OutlinedBorder>
    //     0xd5b084: add             x16, PP, #0x15, lsl #12  ; [pp+0x15aa8] TypeArguments: <OutlinedBorder>
    //     0xd5b088: ldr             x16, [x16, #0xaa8]
    // 0xd5b08c: ldur            lr, [fp, #-0x18]
    // 0xd5b090: stp             lr, x16, [SP]
    // 0xd5b094: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd5b094: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd5b098: r0 = allOrNull()
    //     0xd5b098: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xd5b09c: r1 = Null
    //     0xd5b09c: mov             x1, NULL
    // 0xd5b0a0: r2 = 8
    //     0xd5b0a0: mov             x2, #8
    // 0xd5b0a4: stur            x0, [fp, #-0x18]
    // 0xd5b0a8: r0 = AllocateArray()
    //     0xd5b0a8: bl              #0x13df928  ; AllocateArrayStub
    // 0xd5b0ac: r16 = Instance_WidgetState
    //     0xd5b0ac: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd5b0b0: ldr             x16, [x16, #0xa70]
    // 0xd5b0b4: StoreField: r0->field_f = r16
    //     0xd5b0b4: stur            w16, [x0, #0xf]
    // 0xd5b0b8: ldur            x1, [fp, #-0x80]
    // 0xd5b0bc: StoreField: r0->field_13 = r1
    //     0xd5b0bc: stur            w1, [x0, #0x13]
    // 0xd5b0c0: r16 = Instance__AnyWidgetStates
    //     0xd5b0c0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a78] Obj!_AnyWidgetStates@12aa401
    //     0xd5b0c4: ldr             x16, [x16, #0xa78]
    // 0xd5b0c8: ArrayStore: r0[0] = r16  ; List_4
    //     0xd5b0c8: stur            w16, [x0, #0x17]
    // 0xd5b0cc: ldur            x1, [fp, #-0x68]
    // 0xd5b0d0: StoreField: r0->field_1b = r1
    //     0xd5b0d0: stur            w1, [x0, #0x1b]
    // 0xd5b0d4: r16 = <WidgetStatesConstraint, MouseCursor?>
    //     0xd5b0d4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ab0] TypeArguments: <WidgetStatesConstraint, MouseCursor?>
    //     0xd5b0d8: ldr             x16, [x16, #0xab0]
    // 0xd5b0dc: stp             x0, x16, [SP]
    // 0xd5b0e0: r0 = Map._fromLiteral()
    //     0xd5b0e0: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xd5b0e4: r1 = <MouseCursor?>
    //     0xd5b0e4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ab8] TypeArguments: <MouseCursor?>
    //     0xd5b0e8: ldr             x1, [x1, #0xab8]
    // 0xd5b0ec: stur            x0, [fp, #-0x68]
    // 0xd5b0f0: r0 = WidgetStateMapper()
    //     0xd5b0f0: bl              #0xd171e0  ; AllocateWidgetStateMapperStub -> WidgetStateMapper<X0> (size=0x10)
    // 0xd5b0f4: mov             x1, x0
    // 0xd5b0f8: ldur            x0, [fp, #-0x68]
    // 0xd5b0fc: stur            x1, [fp, #-0x80]
    // 0xd5b100: StoreField: r1->field_b = r0
    //     0xd5b100: stur            w0, [x1, #0xb]
    // 0xd5b104: r0 = ButtonStyle()
    //     0xd5b104: bl              #0xd17184  ; AllocateButtonStyleStub -> ButtonStyle (size=0x6c)
    // 0xd5b108: ldur            x1, [fp, #-0xb0]
    // 0xd5b10c: StoreField: r0->field_7 = r1
    //     0xd5b10c: stur            w1, [x0, #7]
    // 0xd5b110: ldur            x1, [fp, #-0x38]
    // 0xd5b114: StoreField: r0->field_b = r1
    //     0xd5b114: stur            w1, [x0, #0xb]
    // 0xd5b118: ldur            x1, [fp, #-0x58]
    // 0xd5b11c: StoreField: r0->field_f = r1
    //     0xd5b11c: stur            w1, [x0, #0xf]
    // 0xd5b120: ldur            x1, [fp, #-0xa8]
    // 0xd5b124: StoreField: r0->field_13 = r1
    //     0xd5b124: stur            w1, [x0, #0x13]
    // 0xd5b128: ldur            x1, [fp, #-0x10]
    // 0xd5b12c: ArrayStore: r0[0] = r1  ; List_4
    //     0xd5b12c: stur            w1, [x0, #0x17]
    // 0xd5b130: ldur            x1, [fp, #-0x78]
    // 0xd5b134: StoreField: r0->field_1f = r1
    //     0xd5b134: stur            w1, [x0, #0x1f]
    // 0xd5b138: ldur            x1, [fp, #-0x40]
    // 0xd5b13c: StoreField: r0->field_23 = r1
    //     0xd5b13c: stur            w1, [x0, #0x23]
    // 0xd5b140: ldur            x1, [fp, #-0x48]
    // 0xd5b144: StoreField: r0->field_27 = r1
    //     0xd5b144: stur            w1, [x0, #0x27]
    // 0xd5b148: ldur            x1, [fp, #-0x60]
    // 0xd5b14c: StoreField: r0->field_2b = r1
    //     0xd5b14c: stur            w1, [x0, #0x2b]
    // 0xd5b150: ldur            x1, [fp, #-0x50]
    // 0xd5b154: StoreField: r0->field_2f = r1
    //     0xd5b154: stur            w1, [x0, #0x2f]
    // 0xd5b158: ldur            x1, [fp, #-0x18]
    // 0xd5b15c: StoreField: r0->field_43 = r1
    //     0xd5b15c: stur            w1, [x0, #0x43]
    // 0xd5b160: ldur            x1, [fp, #-0x80]
    // 0xd5b164: StoreField: r0->field_47 = r1
    //     0xd5b164: stur            w1, [x0, #0x47]
    // 0xd5b168: ldur            x1, [fp, #-0x30]
    // 0xd5b16c: StoreField: r0->field_4b = r1
    //     0xd5b16c: stur            w1, [x0, #0x4b]
    // 0xd5b170: ldur            x1, [fp, #-0x28]
    // 0xd5b174: StoreField: r0->field_4f = r1
    //     0xd5b174: stur            w1, [x0, #0x4f]
    // 0xd5b178: ldur            x1, [fp, #-0xa0]
    // 0xd5b17c: StoreField: r0->field_53 = r1
    //     0xd5b17c: stur            w1, [x0, #0x53]
    // 0xd5b180: ldur            x1, [fp, #-0x70]
    // 0xd5b184: StoreField: r0->field_57 = r1
    //     0xd5b184: stur            w1, [x0, #0x57]
    // 0xd5b188: ldur            x1, [fp, #-8]
    // 0xd5b18c: StoreField: r0->field_5b = r1
    //     0xd5b18c: stur            w1, [x0, #0x5b]
    // 0xd5b190: ldur            x1, [fp, #-0x20]
    // 0xd5b194: StoreField: r0->field_5f = r1
    //     0xd5b194: stur            w1, [x0, #0x5f]
    // 0xd5b198: LeaveFrame
    //     0xd5b198: mov             SP, fp
    //     0xd5b19c: ldp             fp, lr, [SP], #0x10
    // 0xd5b1a0: ret
    //     0xd5b1a0: ret             
    // 0xd5b1a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5b1a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5b1a8: b               #0xd5ab50
    // 0xd5b1ac: stp             q0, q2, [SP, #-0x20]!
    // 0xd5b1b0: stp             x2, x3, [SP, #-0x10]!
    // 0xd5b1b4: r0 = AllocateDouble()
    //     0xd5b1b4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd5b1b8: ldp             x2, x3, [SP], #0x10
    // 0xd5b1bc: ldp             q0, q2, [SP], #0x20
    // 0xd5b1c0: b               #0xd5ae54
    // 0xd5b1c4: SaveReg d2
    //     0xd5b1c4: str             q2, [SP, #-0x10]!
    // 0xd5b1c8: stp             x2, x3, [SP, #-0x10]!
    // 0xd5b1cc: r0 = AllocateDouble()
    //     0xd5b1cc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd5b1d0: mov             x4, x0
    // 0xd5b1d4: ldp             x2, x3, [SP], #0x10
    // 0xd5b1d8: RestoreReg d2
    //     0xd5b1d8: ldr             q2, [SP], #0x10
    // 0xd5b1dc: b               #0xd5aebc
  }
  _ defaultStyleOf(/* No info */) {
    // ** addr: 0x1229dcc, size: 0x360
    // 0x1229dcc: EnterFrame
    //     0x1229dcc: stp             fp, lr, [SP, #-0x10]!
    //     0x1229dd0: mov             fp, SP
    // 0x1229dd4: AllocStack(0xf0)
    //     0x1229dd4: sub             SP, SP, #0xf0
    // 0x1229dd8: SetupParameters(ElevatedButton this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x1229dd8: mov             x0, x2
    //     0x1229ddc: stur            x2, [fp, #-0x10]
    //     0x1229de0: mov             x2, x1
    //     0x1229de4: stur            x1, [fp, #-8]
    // 0x1229de8: CheckStackOverflow
    //     0x1229de8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1229dec: cmp             SP, x16
    //     0x1229df0: b.ls            #0x122a124
    // 0x1229df4: mov             x1, x0
    // 0x1229df8: r0 = of()
    //     0x1229df8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1229dfc: mov             x2, x0
    // 0x1229e00: stur            x2, [fp, #-0x38]
    // 0x1229e04: LoadField: r0 = r2->field_3f
    //     0x1229e04: ldur            w0, [x2, #0x3f]
    // 0x1229e08: DecompressPointer r0
    //     0x1229e08: add             x0, x0, HEAP, lsl #32
    // 0x1229e0c: LoadField: r1 = r2->field_2f
    //     0x1229e0c: ldur            w1, [x2, #0x2f]
    // 0x1229e10: DecompressPointer r1
    //     0x1229e10: add             x1, x1, HEAP, lsl #32
    // 0x1229e14: stur            x1, [fp, #-0x18]
    // 0x1229e18: tbnz            w1, #4, #0x1229e60
    // 0x1229e1c: ldur            x0, [fp, #-0x10]
    // 0x1229e20: r0 = _ElevatedButtonDefaultsM3()
    //     0x1229e20: bl              #0x122a12c  ; Allocate_ElevatedButtonDefaultsM3Stub -> _ElevatedButtonDefaultsM3 (size=0x74)
    // 0x1229e24: mov             x1, x0
    // 0x1229e28: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x1229e2c: StoreField: r1->field_6f = r0
    //     0x1229e2c: stur            w0, [x1, #0x6f]
    // 0x1229e30: ldur            x3, [fp, #-0x10]
    // 0x1229e34: StoreField: r1->field_6b = r3
    //     0x1229e34: stur            w3, [x1, #0x6b]
    // 0x1229e38: r0 = Instance_Duration
    //     0x1229e38: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0x1229e3c: ldr             x0, [x0, #0x318]
    // 0x1229e40: StoreField: r1->field_53 = r0
    //     0x1229e40: stur            w0, [x1, #0x53]
    // 0x1229e44: r0 = true
    //     0x1229e44: add             x0, NULL, #0x20  ; true
    // 0x1229e48: StoreField: r1->field_57 = r0
    //     0x1229e48: stur            w0, [x1, #0x57]
    // 0x1229e4c: r0 = Instance_Alignment
    //     0x1229e4c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0x1229e50: ldr             x0, [x0, #0xb80]
    // 0x1229e54: StoreField: r1->field_5b = r0
    //     0x1229e54: stur            w0, [x1, #0x5b]
    // 0x1229e58: mov             x2, x1
    // 0x1229e5c: b               #0x1229fb0
    // 0x1229e60: ldur            x3, [fp, #-0x10]
    // 0x1229e64: LoadField: r4 = r0->field_b
    //     0x1229e64: ldur            w4, [x0, #0xb]
    // 0x1229e68: DecompressPointer r4
    //     0x1229e68: add             x4, x4, HEAP, lsl #32
    // 0x1229e6c: stur            x4, [fp, #-0x30]
    // 0x1229e70: LoadField: r5 = r0->field_f
    //     0x1229e70: ldur            w5, [x0, #0xf]
    // 0x1229e74: DecompressPointer r5
    //     0x1229e74: add             x5, x5, HEAP, lsl #32
    // 0x1229e78: stur            x5, [fp, #-0x28]
    // 0x1229e7c: LoadField: r6 = r0->field_7f
    //     0x1229e7c: ldur            w6, [x0, #0x7f]
    // 0x1229e80: DecompressPointer r6
    //     0x1229e80: add             x6, x6, HEAP, lsl #32
    // 0x1229e84: stur            x6, [fp, #-0x20]
    // 0x1229e88: r0 = LoadClassIdInstr(r6)
    //     0x1229e88: ldur            x0, [x6, #-1]
    //     0x1229e8c: ubfx            x0, x0, #0xc, #0x14
    // 0x1229e90: mov             x1, x6
    // 0x1229e94: d0 = 0.120000
    //     0x1229e94: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x1229e98: ldr             d0, [x17, #0xc40]
    // 0x1229e9c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1229e9c: sub             lr, x0, #1, lsl #12
    //     0x1229ea0: ldr             lr, [x21, lr, lsl #3]
    //     0x1229ea4: blr             lr
    // 0x1229ea8: mov             x2, x0
    // 0x1229eac: ldur            x1, [fp, #-0x20]
    // 0x1229eb0: stur            x2, [fp, #-0x40]
    // 0x1229eb4: r0 = LoadClassIdInstr(r1)
    //     0x1229eb4: ldur            x0, [x1, #-1]
    //     0x1229eb8: ubfx            x0, x0, #0xc, #0x14
    // 0x1229ebc: d0 = 0.380000
    //     0x1229ebc: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1229ec0: ldr             d0, [x17, #0x1f0]
    // 0x1229ec4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1229ec4: sub             lr, x0, #1, lsl #12
    //     0x1229ec8: ldr             lr, [x21, lr, lsl #3]
    //     0x1229ecc: blr             lr
    // 0x1229ed0: mov             x2, x0
    // 0x1229ed4: ldur            x0, [fp, #-0x38]
    // 0x1229ed8: stur            x2, [fp, #-0x50]
    // 0x1229edc: LoadField: r3 = r0->field_6f
    //     0x1229edc: ldur            w3, [x0, #0x6f]
    // 0x1229ee0: DecompressPointer r3
    //     0x1229ee0: add             x3, x3, HEAP, lsl #32
    // 0x1229ee4: stur            x3, [fp, #-0x48]
    // 0x1229ee8: LoadField: r1 = r0->field_87
    //     0x1229ee8: ldur            w1, [x0, #0x87]
    // 0x1229eec: DecompressPointer r1
    //     0x1229eec: add             x1, x1, HEAP, lsl #32
    // 0x1229ef0: LoadField: r4 = r1->field_37
    //     0x1229ef0: ldur            w4, [x1, #0x37]
    // 0x1229ef4: DecompressPointer r4
    //     0x1229ef4: add             x4, x4, HEAP, lsl #32
    // 0x1229ef8: ldur            x1, [fp, #-0x10]
    // 0x1229efc: stur            x4, [fp, #-0x20]
    // 0x1229f00: r0 = _scaledPadding()
    //     0x1229f00: bl              #0x1140b90  ; [package:flutter/src/material/elevated_button.dart] ::_scaledPadding
    // 0x1229f04: mov             x1, x0
    // 0x1229f08: ldur            x0, [fp, #-0x38]
    // 0x1229f0c: LoadField: r2 = r0->field_33
    //     0x1229f0c: ldur            w2, [x0, #0x33]
    // 0x1229f10: DecompressPointer r2
    //     0x1229f10: add             x2, x2, HEAP, lsl #32
    // 0x1229f14: LoadField: r3 = r0->field_1b
    //     0x1229f14: ldur            w3, [x0, #0x1b]
    // 0x1229f18: DecompressPointer r3
    //     0x1229f18: add             x3, x3, HEAP, lsl #32
    // 0x1229f1c: ldur            x16, [fp, #-0x30]
    // 0x1229f20: ldur            lr, [fp, #-0x28]
    // 0x1229f24: stp             lr, x16, [SP, #0x88]
    // 0x1229f28: ldur            x16, [fp, #-0x40]
    // 0x1229f2c: ldur            lr, [fp, #-0x50]
    // 0x1229f30: stp             lr, x16, [SP, #0x78]
    // 0x1229f34: ldur            x16, [fp, #-0x48]
    // 0x1229f38: r30 = 2.000000
    //     0x1229f38: add             lr, PP, #0x1b, lsl #12  ; [pp+0x1b1e0] 2
    //     0x1229f3c: ldr             lr, [lr, #0x1e0]
    // 0x1229f40: stp             lr, x16, [SP, #0x68]
    // 0x1229f44: ldur            x16, [fp, #-0x20]
    // 0x1229f48: stp             x1, x16, [SP, #0x58]
    // 0x1229f4c: r16 = Instance_Size
    //     0x1229f4c: add             x16, PP, #0x95, lsl #12  ; [pp+0x95c20] Obj!Size@12a79f1
    //     0x1229f50: ldr             x16, [x16, #0xc20]
    // 0x1229f54: r30 = Instance_Size
    //     0x1229f54: add             lr, PP, #0x95, lsl #12  ; [pp+0x95c28] Obj!Size@12a79b1
    //     0x1229f58: ldr             lr, [lr, #0xc28]
    // 0x1229f5c: stp             lr, x16, [SP, #0x48]
    // 0x1229f60: r16 = Instance_RoundedRectangleBorder
    //     0x1229f60: add             x16, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0x1229f64: ldr             x16, [x16, #0x218]
    // 0x1229f68: r30 = Instance_SystemMouseCursor
    //     0x1229f68: ldr             lr, [PP, #0x21b0]  ; [pp+0x21b0] Obj!SystemMouseCursor@12b3201
    // 0x1229f6c: stp             lr, x16, [SP, #0x38]
    // 0x1229f70: r16 = Instance_SystemMouseCursor
    //     0x1229f70: ldr             x16, [PP, #0x21b0]  ; [pp+0x21b0] Obj!SystemMouseCursor@12b3201
    // 0x1229f74: stp             x2, x16, [SP, #0x28]
    // 0x1229f78: r16 = Instance_Duration
    //     0x1229f78: add             x16, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0x1229f7c: ldr             x16, [x16, #0x318]
    // 0x1229f80: stp             x16, x3, [SP, #0x18]
    // 0x1229f84: r16 = true
    //     0x1229f84: add             x16, NULL, #0x20  ; true
    // 0x1229f88: r30 = Instance_Alignment
    //     0x1229f88: add             lr, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0x1229f8c: ldr             lr, [lr, #0xb80]
    // 0x1229f90: stp             lr, x16, [SP, #8]
    // 0x1229f94: r16 = Instance__InkRippleFactory
    //     0x1229f94: add             x16, PP, #0x95, lsl #12  ; [pp+0x95c30] Obj!_InkRippleFactory@129ecd1
    //     0x1229f98: ldr             x16, [x16, #0xc30]
    // 0x1229f9c: str             x16, [SP]
    // 0x1229fa0: r4 = const [0, 0x13, 0x13, 0, alignment, 0x11, animationDuration, 0xf, backgroundColor, 0, disabledBackgroundColor, 0x2, disabledForegroundColor, 0x3, disabledMouseCursor, 0xc, elevation, 0x5, enableFeedback, 0x10, enabledMouseCursor, 0xb, foregroundColor, 0x1, maximumSize, 0x9, minimumSize, 0x8, padding, 0x7, shadowColor, 0x4, shape, 0xa, splashFactory, 0x12, tapTargetSize, 0xe, textStyle, 0x6, visualDensity, 0xd, null]
    //     0x1229fa0: add             x4, PP, #0x95, lsl #12  ; [pp+0x95e00] List(43) [0, 0x13, 0x13, 0, "alignment", 0x11, "animationDuration", 0xf, "backgroundColor", 0, "disabledBackgroundColor", 0x2, "disabledForegroundColor", 0x3, "disabledMouseCursor", 0xc, "elevation", 0x5, "enableFeedback", 0x10, "enabledMouseCursor", 0xb, "foregroundColor", 0x1, "maximumSize", 0x9, "minimumSize", 0x8, "padding", 0x7, "shadowColor", 0x4, "shape", 0xa, "splashFactory", 0x12, "tapTargetSize", 0xe, "textStyle", 0x6, "visualDensity", 0xd, Null]
    //     0x1229fa4: ldr             x4, [x4, #0xe00]
    // 0x1229fa8: r0 = styleFrom()
    //     0x1229fa8: bl              #0xd5a428  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x1229fac: mov             x2, x0
    // 0x1229fb0: ldur            x0, [fp, #-8]
    // 0x1229fb4: stur            x2, [fp, #-0x20]
    // 0x1229fb8: LoadField: r1 = r0->field_3b
    //     0x1229fb8: ldur            w1, [x0, #0x3b]
    // 0x1229fbc: DecompressPointer r1
    //     0x1229fbc: add             x1, x1, HEAP, lsl #32
    // 0x1229fc0: tbnz            w1, #4, #0x122a114
    // 0x1229fc4: r0 = LoadClassIdInstr(r2)
    //     0x1229fc4: ldur            x0, [x2, #-1]
    //     0x1229fc8: ubfx            x0, x0, #0xc, #0x14
    // 0x1229fcc: mov             x1, x2
    // 0x1229fd0: r0 = GDT[cid_x0 + 0xe00]()
    //     0x1229fd0: add             lr, x0, #0xe00
    //     0x1229fd4: ldr             lr, [x21, lr, lsl #3]
    //     0x1229fd8: blr             lr
    // 0x1229fdc: cmp             w0, NULL
    // 0x1229fe0: b.ne            #0x1229fec
    // 0x1229fe4: r0 = Null
    //     0x1229fe4: mov             x0, NULL
    // 0x1229fe8: b               #0x122a038
    // 0x1229fec: r1 = LoadClassIdInstr(r0)
    //     0x1229fec: ldur            x1, [x0, #-1]
    //     0x1229ff0: ubfx            x1, x1, #0xc, #0x14
    // 0x1229ff4: mov             x16, x0
    // 0x1229ff8: mov             x0, x1
    // 0x1229ffc: mov             x1, x16
    // 0x122a000: r2 = _ConstSet len:0
    //     0x122a000: add             x2, PP, #0x26, lsl #12  ; [pp+0x26248] Set<WidgetState>(0)
    //     0x122a004: ldr             x2, [x2, #0x248]
    // 0x122a008: r0 = GDT[cid_x0 + 0x17c77]()
    //     0x122a008: mov             x17, #0x7c77
    //     0x122a00c: movk            x17, #1, lsl #16
    //     0x122a010: add             lr, x0, x17
    //     0x122a014: ldr             lr, [x21, lr, lsl #3]
    //     0x122a018: blr             lr
    // 0x122a01c: cmp             w0, NULL
    // 0x122a020: b.ne            #0x122a02c
    // 0x122a024: r0 = Null
    //     0x122a024: mov             x0, NULL
    // 0x122a028: b               #0x122a038
    // 0x122a02c: LoadField: r1 = r0->field_1f
    //     0x122a02c: ldur            w1, [x0, #0x1f]
    // 0x122a030: DecompressPointer r1
    //     0x122a030: add             x1, x1, HEAP, lsl #32
    // 0x122a034: mov             x0, x1
    // 0x122a038: cmp             w0, NULL
    // 0x122a03c: b.ne            #0x122a048
    // 0x122a040: d0 = 14.000000
    //     0x122a040: fmov            d0, #14.00000000
    // 0x122a044: b               #0x122a04c
    // 0x122a048: LoadField: d0 = r0->field_7
    //     0x122a048: ldur            d0, [x0, #7]
    // 0x122a04c: ldur            x0, [fp, #-0x18]
    // 0x122a050: ldur            x1, [fp, #-0x10]
    // 0x122a054: stur            d0, [fp, #-0x58]
    // 0x122a058: r0 = textScalerOf()
    //     0x122a058: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0x122a05c: r1 = LoadClassIdInstr(r0)
    //     0x122a05c: ldur            x1, [x0, #-1]
    //     0x122a060: ubfx            x1, x1, #0xc, #0x14
    // 0x122a064: mov             x16, x0
    // 0x122a068: mov             x0, x1
    // 0x122a06c: mov             x1, x16
    // 0x122a070: ldur            d0, [fp, #-0x58]
    // 0x122a074: r0 = GDT[cid_x0 + -0x1000]()
    //     0x122a074: sub             lr, x0, #1, lsl #12
    //     0x122a078: ldr             lr, [x21, lr, lsl #3]
    //     0x122a07c: blr             lr
    // 0x122a080: LoadField: d0 = r0->field_7
    //     0x122a080: ldur            d0, [x0, #7]
    // 0x122a084: d1 = 14.000000
    //     0x122a084: fmov            d1, #14.00000000
    // 0x122a088: fdiv            d2, d0, d1
    // 0x122a08c: ldur            x0, [fp, #-0x18]
    // 0x122a090: tbnz            w0, #4, #0x122a0b8
    // 0x122a094: mov             v0.16b, v2.16b
    // 0x122a098: r1 = Instance_EdgeInsetsDirectional
    //     0x122a098: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a00] Obj!EdgeInsetsDirectional@129c841
    //     0x122a09c: ldr             x1, [x1, #0xa00]
    // 0x122a0a0: r2 = Instance_EdgeInsetsDirectional
    //     0x122a0a0: add             x2, PP, #0x95, lsl #12  ; [pp+0x95c40] Obj!EdgeInsetsDirectional@129cb71
    //     0x122a0a4: ldr             x2, [x2, #0xc40]
    // 0x122a0a8: r3 = Instance_EdgeInsetsDirectional
    //     0x122a0a8: add             x3, PP, #0x95, lsl #12  ; [pp+0x95c48] Obj!EdgeInsetsDirectional@129cb41
    //     0x122a0ac: ldr             x3, [x3, #0xc48]
    // 0x122a0b0: r0 = scaledPadding()
    //     0x122a0b0: bl              #0x1140cd0  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::scaledPadding
    // 0x122a0b4: b               #0x122a0d8
    // 0x122a0b8: mov             v0.16b, v2.16b
    // 0x122a0bc: r1 = Instance_EdgeInsetsDirectional
    //     0x122a0bc: add             x1, PP, #0x95, lsl #12  ; [pp+0x95e08] Obj!EdgeInsetsDirectional@129cb11
    //     0x122a0c0: ldr             x1, [x1, #0xe08]
    // 0x122a0c4: r2 = Instance_EdgeInsets
    //     0x122a0c4: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7abf0] Obj!EdgeInsets@129cd21
    //     0x122a0c8: ldr             x2, [x2, #0xbf0]
    // 0x122a0cc: r3 = Instance_EdgeInsetsDirectional
    //     0x122a0cc: add             x3, PP, #0x95, lsl #12  ; [pp+0x95e10] Obj!EdgeInsetsDirectional@129cae1
    //     0x122a0d0: ldr             x3, [x3, #0xe10]
    // 0x122a0d4: r0 = scaledPadding()
    //     0x122a0d4: bl              #0x1140cd0  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::scaledPadding
    // 0x122a0d8: stur            x0, [fp, #-8]
    // 0x122a0dc: r1 = <EdgeInsetsGeometry>
    //     0x122a0dc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a98] TypeArguments: <EdgeInsetsGeometry>
    //     0x122a0e0: ldr             x1, [x1, #0xa98]
    // 0x122a0e4: r0 = WidgetStatePropertyAll()
    //     0x122a0e4: bl              #0xd132c8  ; AllocateWidgetStatePropertyAllStub -> WidgetStatePropertyAll<X0> (size=0x10)
    // 0x122a0e8: mov             x1, x0
    // 0x122a0ec: ldur            x0, [fp, #-8]
    // 0x122a0f0: StoreField: r1->field_b = r0
    //     0x122a0f0: stur            w0, [x1, #0xb]
    // 0x122a0f4: str             x1, [SP]
    // 0x122a0f8: ldur            x1, [fp, #-0x20]
    // 0x122a0fc: r4 = const [0, 0x2, 0x1, 0x1, padding, 0x1, null]
    //     0x122a0fc: add             x4, PP, #0x19, lsl #12  ; [pp+0x19df0] List(7) [0, 0x2, 0x1, 0x1, "padding", 0x1, Null]
    //     0x122a100: ldr             x4, [x4, #0xdf0]
    // 0x122a104: r0 = copyWith()
    //     0x122a104: bl              #0xd2991c  ; [package:flutter/src/material/button_style.dart] ButtonStyle::copyWith
    // 0x122a108: LeaveFrame
    //     0x122a108: mov             SP, fp
    //     0x122a10c: ldp             fp, lr, [SP], #0x10
    // 0x122a110: ret
    //     0x122a110: ret             
    // 0x122a114: ldur            x0, [fp, #-0x20]
    // 0x122a118: LeaveFrame
    //     0x122a118: mov             SP, fp
    //     0x122a11c: ldp             fp, lr, [SP], #0x10
    // 0x122a120: ret
    //     0x122a120: ret             
    // 0x122a124: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x122a124: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x122a128: b               #0x1229df4
  }
  _ themeStyleOf(/* No info */) {
    // ** addr: 0x122a974, size: 0x40
    // 0x122a974: EnterFrame
    //     0x122a974: stp             fp, lr, [SP, #-0x10]!
    //     0x122a978: mov             fp, SP
    // 0x122a97c: mov             x0, x1
    // 0x122a980: mov             x1, x2
    // 0x122a984: CheckStackOverflow
    //     0x122a984: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x122a988: cmp             SP, x16
    //     0x122a98c: b.ls            #0x122a9ac
    // 0x122a990: r0 = of()
    //     0x122a990: bl              #0xfba2ec  ; [package:flutter/src/material/elevated_button_theme.dart] ElevatedButtonTheme::of
    // 0x122a994: LoadField: r1 = r0->field_7
    //     0x122a994: ldur            w1, [x0, #7]
    // 0x122a998: DecompressPointer r1
    //     0x122a998: add             x1, x1, HEAP, lsl #32
    // 0x122a99c: mov             x0, x1
    // 0x122a9a0: LeaveFrame
    //     0x122a9a0: mov             SP, fp
    //     0x122a9a4: ldp             fp, lr, [SP], #0x10
    // 0x122a9a8: ret
    //     0x122a9a8: ret             
    // 0x122a9ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x122a9ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x122a9b0: b               #0x122a990
  }
}
