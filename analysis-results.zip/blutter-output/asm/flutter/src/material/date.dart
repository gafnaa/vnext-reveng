// lib: , url: package:flutter/src/material/date.dart

// class id: 1048874, size: 0x8
class :: {
}

// class id: 3108, size: 0x8, field offset: 0x8
abstract class DateUtils extends Object {

  static _ dateOnly(/* No info */) {
    // ** addr: 0xd18a20, size: 0x10c
    // 0xd18a20: EnterFrame
    //     0xd18a20: stp             fp, lr, [SP, #-0x10]!
    //     0xd18a24: mov             fp, SP
    // 0xd18a28: AllocStack(0x30)
    //     0xd18a28: sub             SP, SP, #0x30
    // 0xd18a2c: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0xd18a2c: mov             x0, x1
    //     0xd18a30: stur            x1, [fp, #-8]
    // 0xd18a34: CheckStackOverflow
    //     0xd18a34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd18a38: cmp             SP, x16
    //     0xd18a3c: b.ls            #0xd18b18
    // 0xd18a40: mov             x1, x0
    // 0xd18a44: r0 = _parts()
    //     0xd18a44: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xd18a48: mov             x2, x0
    // 0xd18a4c: LoadField: r0 = r2->field_b
    //     0xd18a4c: ldur            w0, [x2, #0xb]
    // 0xd18a50: r1 = LoadInt32Instr(r0)
    //     0xd18a50: sbfx            x1, x0, #1, #0x1f
    // 0xd18a54: mov             x0, x1
    // 0xd18a58: r1 = 8
    //     0xd18a58: mov             x1, #8
    // 0xd18a5c: cmp             x1, x0
    // 0xd18a60: b.hs            #0xd18b20
    // 0xd18a64: LoadField: r0 = r2->field_2f
    //     0xd18a64: ldur            w0, [x2, #0x2f]
    // 0xd18a68: DecompressPointer r0
    //     0xd18a68: add             x0, x0, HEAP, lsl #32
    // 0xd18a6c: ldur            x1, [fp, #-8]
    // 0xd18a70: stur            x0, [fp, #-0x10]
    // 0xd18a74: r0 = _parts()
    //     0xd18a74: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xd18a78: mov             x2, x0
    // 0xd18a7c: LoadField: r0 = r2->field_b
    //     0xd18a7c: ldur            w0, [x2, #0xb]
    // 0xd18a80: r1 = LoadInt32Instr(r0)
    //     0xd18a80: sbfx            x1, x0, #1, #0x1f
    // 0xd18a84: mov             x0, x1
    // 0xd18a88: r1 = 7
    //     0xd18a88: mov             x1, #7
    // 0xd18a8c: cmp             x1, x0
    // 0xd18a90: b.hs            #0xd18b24
    // 0xd18a94: LoadField: r0 = r2->field_2b
    //     0xd18a94: ldur            w0, [x2, #0x2b]
    // 0xd18a98: DecompressPointer r0
    //     0xd18a98: add             x0, x0, HEAP, lsl #32
    // 0xd18a9c: ldur            x1, [fp, #-8]
    // 0xd18aa0: stur            x0, [fp, #-0x18]
    // 0xd18aa4: r0 = _parts()
    //     0xd18aa4: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xd18aa8: mov             x2, x0
    // 0xd18aac: LoadField: r0 = r2->field_b
    //     0xd18aac: ldur            w0, [x2, #0xb]
    // 0xd18ab0: r1 = LoadInt32Instr(r0)
    //     0xd18ab0: sbfx            x1, x0, #1, #0x1f
    // 0xd18ab4: mov             x0, x1
    // 0xd18ab8: r1 = 5
    //     0xd18ab8: mov             x1, #5
    // 0xd18abc: cmp             x1, x0
    // 0xd18ac0: b.hs            #0xd18b28
    // 0xd18ac4: LoadField: r0 = r2->field_23
    //     0xd18ac4: ldur            w0, [x2, #0x23]
    // 0xd18ac8: DecompressPointer r0
    //     0xd18ac8: add             x0, x0, HEAP, lsl #32
    // 0xd18acc: ldur            x1, [fp, #-0x10]
    // 0xd18ad0: stur            x0, [fp, #-8]
    // 0xd18ad4: r2 = LoadInt32Instr(r1)
    //     0xd18ad4: sbfx            x2, x1, #1, #0x1f
    //     0xd18ad8: tbz             w1, #0, #0xd18ae0
    //     0xd18adc: ldur            x2, [x1, #7]
    // 0xd18ae0: stur            x2, [fp, #-0x20]
    // 0xd18ae4: r0 = DateTime()
    //     0xd18ae4: bl              #0x8174b8  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0xd18ae8: stur            x0, [fp, #-0x10]
    // 0xd18aec: ldur            x16, [fp, #-0x18]
    // 0xd18af0: ldur            lr, [fp, #-8]
    // 0xd18af4: stp             lr, x16, [SP]
    // 0xd18af8: mov             x1, x0
    // 0xd18afc: ldur            x2, [fp, #-0x20]
    // 0xd18b00: r4 = const [0, 0x4, 0x2, 0x4, null]
    //     0xd18b00: ldr             x4, [PP, #0x1388]  ; [pp+0x1388] List(5) [0, 0x4, 0x2, 0x4, Null]
    // 0xd18b04: r0 = DateTime()
    //     0xd18b04: bl              #0xaf09e4  ; [dart:core] DateTime::DateTime
    // 0xd18b08: ldur            x0, [fp, #-0x10]
    // 0xd18b0c: LeaveFrame
    //     0xd18b0c: mov             SP, fp
    //     0xd18b10: ldp             fp, lr, [SP], #0x10
    // 0xd18b14: ret
    //     0xd18b14: ret             
    // 0xd18b18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd18b18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd18b1c: b               #0xd18a40
    // 0xd18b20: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd18b20: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd18b24: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd18b24: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd18b28: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd18b28: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ monthDelta(/* No info */) {
    // ** addr: 0xdeef48, size: 0x154
    // 0xdeef48: EnterFrame
    //     0xdeef48: stp             fp, lr, [SP, #-0x10]!
    //     0xdeef4c: mov             fp, SP
    // 0xdeef50: AllocStack(0x28)
    //     0xdeef50: sub             SP, SP, #0x28
    // 0xdeef54: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xdeef54: mov             x0, x2
    //     0xdeef58: stur            x2, [fp, #-0x10]
    //     0xdeef5c: mov             x2, x1
    //     0xdeef60: stur            x1, [fp, #-8]
    // 0xdeef64: CheckStackOverflow
    //     0xdeef64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdeef68: cmp             SP, x16
    //     0xdeef6c: b.ls            #0xdef084
    // 0xdeef70: mov             x1, x0
    // 0xdeef74: r0 = _parts()
    //     0xdeef74: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdeef78: mov             x2, x0
    // 0xdeef7c: LoadField: r0 = r2->field_b
    //     0xdeef7c: ldur            w0, [x2, #0xb]
    // 0xdeef80: r1 = LoadInt32Instr(r0)
    //     0xdeef80: sbfx            x1, x0, #1, #0x1f
    // 0xdeef84: mov             x0, x1
    // 0xdeef88: r1 = 8
    //     0xdeef88: mov             x1, #8
    // 0xdeef8c: cmp             x1, x0
    // 0xdeef90: b.hs            #0xdef08c
    // 0xdeef94: LoadField: r0 = r2->field_2f
    //     0xdeef94: ldur            w0, [x2, #0x2f]
    // 0xdeef98: DecompressPointer r0
    //     0xdeef98: add             x0, x0, HEAP, lsl #32
    // 0xdeef9c: ldur            x1, [fp, #-8]
    // 0xdeefa0: stur            x0, [fp, #-0x18]
    // 0xdeefa4: r0 = _parts()
    //     0xdeefa4: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdeefa8: mov             x2, x0
    // 0xdeefac: LoadField: r0 = r2->field_b
    //     0xdeefac: ldur            w0, [x2, #0xb]
    // 0xdeefb0: r1 = LoadInt32Instr(r0)
    //     0xdeefb0: sbfx            x1, x0, #1, #0x1f
    // 0xdeefb4: mov             x0, x1
    // 0xdeefb8: r1 = 8
    //     0xdeefb8: mov             x1, #8
    // 0xdeefbc: cmp             x1, x0
    // 0xdeefc0: b.hs            #0xdef090
    // 0xdeefc4: LoadField: r0 = r2->field_2f
    //     0xdeefc4: ldur            w0, [x2, #0x2f]
    // 0xdeefc8: DecompressPointer r0
    //     0xdeefc8: add             x0, x0, HEAP, lsl #32
    // 0xdeefcc: ldur            x1, [fp, #-0x18]
    // 0xdeefd0: r2 = LoadInt32Instr(r1)
    //     0xdeefd0: sbfx            x2, x1, #1, #0x1f
    //     0xdeefd4: tbz             w1, #0, #0xdeefdc
    //     0xdeefd8: ldur            x2, [x1, #7]
    // 0xdeefdc: r1 = LoadInt32Instr(r0)
    //     0xdeefdc: sbfx            x1, x0, #1, #0x1f
    //     0xdeefe0: tbz             w0, #0, #0xdeefe8
    //     0xdeefe4: ldur            x1, [x0, #7]
    // 0xdeefe8: sub             x0, x2, x1
    // 0xdeefec: r16 = 12
    //     0xdeefec: mov             x16, #0xc
    // 0xdeeff0: mul             x2, x0, x16
    // 0xdeeff4: ldur            x1, [fp, #-0x10]
    // 0xdeeff8: stur            x2, [fp, #-0x20]
    // 0xdeeffc: r0 = _parts()
    //     0xdeeffc: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdef000: mov             x2, x0
    // 0xdef004: LoadField: r0 = r2->field_b
    //     0xdef004: ldur            w0, [x2, #0xb]
    // 0xdef008: r1 = LoadInt32Instr(r0)
    //     0xdef008: sbfx            x1, x0, #1, #0x1f
    // 0xdef00c: mov             x0, x1
    // 0xdef010: r1 = 7
    //     0xdef010: mov             x1, #7
    // 0xdef014: cmp             x1, x0
    // 0xdef018: b.hs            #0xdef094
    // 0xdef01c: LoadField: r0 = r2->field_2b
    //     0xdef01c: ldur            w0, [x2, #0x2b]
    // 0xdef020: DecompressPointer r0
    //     0xdef020: add             x0, x0, HEAP, lsl #32
    // 0xdef024: r1 = LoadInt32Instr(r0)
    //     0xdef024: sbfx            x1, x0, #1, #0x1f
    //     0xdef028: tbz             w0, #0, #0xdef030
    //     0xdef02c: ldur            x1, [x0, #7]
    // 0xdef030: ldur            x0, [fp, #-0x20]
    // 0xdef034: add             x2, x0, x1
    // 0xdef038: ldur            x1, [fp, #-8]
    // 0xdef03c: stur            x2, [fp, #-0x28]
    // 0xdef040: r0 = _parts()
    //     0xdef040: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdef044: mov             x2, x0
    // 0xdef048: LoadField: r3 = r2->field_b
    //     0xdef048: ldur            w3, [x2, #0xb]
    // 0xdef04c: r0 = LoadInt32Instr(r3)
    //     0xdef04c: sbfx            x0, x3, #1, #0x1f
    // 0xdef050: r1 = 7
    //     0xdef050: mov             x1, #7
    // 0xdef054: cmp             x1, x0
    // 0xdef058: b.hs            #0xdef098
    // 0xdef05c: LoadField: r1 = r2->field_2b
    //     0xdef05c: ldur            w1, [x2, #0x2b]
    // 0xdef060: DecompressPointer r1
    //     0xdef060: add             x1, x1, HEAP, lsl #32
    // 0xdef064: r2 = LoadInt32Instr(r1)
    //     0xdef064: sbfx            x2, x1, #1, #0x1f
    //     0xdef068: tbz             w1, #0, #0xdef070
    //     0xdef06c: ldur            x2, [x1, #7]
    // 0xdef070: ldur            x1, [fp, #-0x28]
    // 0xdef074: sub             x0, x1, x2
    // 0xdef078: LeaveFrame
    //     0xdef078: mov             SP, fp
    //     0xdef07c: ldp             fp, lr, [SP], #0x10
    // 0xdef080: ret
    //     0xdef080: ret             
    // 0xdef084: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdef084: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdef088: b               #0xdeef70
    // 0xdef08c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdef08c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdef090: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdef090: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdef094: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdef094: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdef098: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdef098: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ addMonthsToMonthDate(/* No info */) {
    // ** addr: 0xdeffd8, size: 0x100
    // 0xdeffd8: EnterFrame
    //     0xdeffd8: stp             fp, lr, [SP, #-0x10]!
    //     0xdeffdc: mov             fp, SP
    // 0xdeffe0: AllocStack(0x20)
    //     0xdeffe0: sub             SP, SP, #0x20
    // 0xdeffe4: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdeffe4: mov             x0, x1
    //     0xdeffe8: stur            x1, [fp, #-8]
    //     0xdeffec: stur            x2, [fp, #-0x10]
    // 0xdefff0: CheckStackOverflow
    //     0xdefff0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdefff4: cmp             SP, x16
    //     0xdefff8: b.ls            #0xdf00c8
    // 0xdefffc: mov             x1, x0
    // 0xdf0000: r0 = _parts()
    //     0xdf0000: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdf0004: mov             x2, x0
    // 0xdf0008: LoadField: r0 = r2->field_b
    //     0xdf0008: ldur            w0, [x2, #0xb]
    // 0xdf000c: r1 = LoadInt32Instr(r0)
    //     0xdf000c: sbfx            x1, x0, #1, #0x1f
    // 0xdf0010: mov             x0, x1
    // 0xdf0014: r1 = 8
    //     0xdf0014: mov             x1, #8
    // 0xdf0018: cmp             x1, x0
    // 0xdf001c: b.hs            #0xdf00d0
    // 0xdf0020: LoadField: r0 = r2->field_2f
    //     0xdf0020: ldur            w0, [x2, #0x2f]
    // 0xdf0024: DecompressPointer r0
    //     0xdf0024: add             x0, x0, HEAP, lsl #32
    // 0xdf0028: ldur            x1, [fp, #-8]
    // 0xdf002c: stur            x0, [fp, #-0x18]
    // 0xdf0030: r0 = _parts()
    //     0xdf0030: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdf0034: mov             x2, x0
    // 0xdf0038: LoadField: r0 = r2->field_b
    //     0xdf0038: ldur            w0, [x2, #0xb]
    // 0xdf003c: r1 = LoadInt32Instr(r0)
    //     0xdf003c: sbfx            x1, x0, #1, #0x1f
    // 0xdf0040: mov             x0, x1
    // 0xdf0044: r1 = 7
    //     0xdf0044: mov             x1, #7
    // 0xdf0048: cmp             x1, x0
    // 0xdf004c: b.hs            #0xdf00d4
    // 0xdf0050: LoadField: r0 = r2->field_2b
    //     0xdf0050: ldur            w0, [x2, #0x2b]
    // 0xdf0054: DecompressPointer r0
    //     0xdf0054: add             x0, x0, HEAP, lsl #32
    // 0xdf0058: r1 = LoadInt32Instr(r0)
    //     0xdf0058: sbfx            x1, x0, #1, #0x1f
    //     0xdf005c: tbz             w0, #0, #0xdf0064
    //     0xdf0060: ldur            x1, [x0, #7]
    // 0xdf0064: ldur            x0, [fp, #-0x10]
    // 0xdf0068: add             x2, x1, x0
    // 0xdf006c: ldur            x0, [fp, #-0x18]
    // 0xdf0070: r3 = LoadInt32Instr(r0)
    //     0xdf0070: sbfx            x3, x0, #1, #0x1f
    //     0xdf0074: tbz             w0, #0, #0xdf007c
    //     0xdf0078: ldur            x3, [x0, #7]
    // 0xdf007c: stur            x3, [fp, #-0x10]
    // 0xdf0080: r0 = BoxInt64Instr(r2)
    //     0xdf0080: sbfiz           x0, x2, #1, #0x1f
    //     0xdf0084: cmp             x2, x0, asr #1
    //     0xdf0088: b.eq            #0xdf0094
    //     0xdf008c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xdf0090: stur            x2, [x0, #7]
    // 0xdf0094: stur            x0, [fp, #-8]
    // 0xdf0098: r0 = DateTime()
    //     0xdf0098: bl              #0x8174b8  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0xdf009c: stur            x0, [fp, #-0x18]
    // 0xdf00a0: ldur            x16, [fp, #-8]
    // 0xdf00a4: str             x16, [SP]
    // 0xdf00a8: mov             x1, x0
    // 0xdf00ac: ldur            x2, [fp, #-0x10]
    // 0xdf00b0: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0xdf00b0: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0xdf00b4: r0 = DateTime()
    //     0xdf00b4: bl              #0xaf09e4  ; [dart:core] DateTime::DateTime
    // 0xdf00b8: ldur            x0, [fp, #-0x18]
    // 0xdf00bc: LeaveFrame
    //     0xdf00bc: mov             SP, fp
    //     0xdf00c0: ldp             fp, lr, [SP], #0x10
    // 0xdf00c4: ret
    //     0xdf00c4: ret             
    // 0xdf00c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf00c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf00cc: b               #0xdefffc
    // 0xdf00d0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf00d0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf00d4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf00d4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ firstDayOffset(/* No info */) {
    // ** addr: 0xdf10a4, size: 0x120
    // 0xdf10a4: EnterFrame
    //     0xdf10a4: stp             fp, lr, [SP, #-0x10]!
    //     0xdf10a8: mov             fp, SP
    // 0xdf10ac: AllocStack(0x28)
    //     0xdf10ac: sub             SP, SP, #0x28
    // 0xdf10b0: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xdf10b0: mov             x4, x1
    //     0xdf10b4: mov             x16, x3
    //     0xdf10b8: mov             x3, x2
    //     0xdf10bc: mov             x2, x16
    //     0xdf10c0: stur            x1, [fp, #-0x10]
    //     0xdf10c4: stur            x2, [fp, #-0x18]
    // 0xdf10c8: CheckStackOverflow
    //     0xdf10c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf10cc: cmp             SP, x16
    //     0xdf10d0: b.ls            #0xdf11a8
    // 0xdf10d4: r0 = BoxInt64Instr(r3)
    //     0xdf10d4: sbfiz           x0, x3, #1, #0x1f
    //     0xdf10d8: cmp             x3, x0, asr #1
    //     0xdf10dc: b.eq            #0xdf10e8
    //     0xdf10e0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xdf10e4: stur            x3, [x0, #7]
    // 0xdf10e8: stur            x0, [fp, #-8]
    // 0xdf10ec: r0 = DateTime()
    //     0xdf10ec: bl              #0x8174b8  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0xdf10f0: stur            x0, [fp, #-0x20]
    // 0xdf10f4: ldur            x16, [fp, #-8]
    // 0xdf10f8: str             x16, [SP]
    // 0xdf10fc: mov             x1, x0
    // 0xdf1100: ldur            x2, [fp, #-0x10]
    // 0xdf1104: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0xdf1104: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0xdf1108: r0 = DateTime()
    //     0xdf1108: bl              #0xaf09e4  ; [dart:core] DateTime::DateTime
    // 0xdf110c: ldur            x1, [fp, #-0x20]
    // 0xdf1110: r0 = _parts()
    //     0xdf1110: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdf1114: mov             x2, x0
    // 0xdf1118: LoadField: r0 = r2->field_b
    //     0xdf1118: ldur            w0, [x2, #0xb]
    // 0xdf111c: r1 = LoadInt32Instr(r0)
    //     0xdf111c: sbfx            x1, x0, #1, #0x1f
    // 0xdf1120: mov             x0, x1
    // 0xdf1124: r1 = 6
    //     0xdf1124: mov             x1, #6
    // 0xdf1128: cmp             x1, x0
    // 0xdf112c: b.hs            #0xdf11b0
    // 0xdf1130: LoadField: r0 = r2->field_27
    //     0xdf1130: ldur            w0, [x2, #0x27]
    // 0xdf1134: DecompressPointer r0
    //     0xdf1134: add             x0, x0, HEAP, lsl #32
    // 0xdf1138: r1 = LoadInt32Instr(r0)
    //     0xdf1138: sbfx            x1, x0, #1, #0x1f
    //     0xdf113c: tbz             w0, #0, #0xdf1144
    //     0xdf1140: ldur            x1, [x0, #7]
    // 0xdf1144: sub             x2, x1, #1
    // 0xdf1148: ldur            x1, [fp, #-0x18]
    // 0xdf114c: stur            x2, [fp, #-0x10]
    // 0xdf1150: r0 = LoadClassIdInstr(r1)
    //     0xdf1150: ldur            x0, [x1, #-1]
    //     0xdf1154: ubfx            x0, x0, #0xc, #0x14
    // 0xdf1158: r0 = GDT[cid_x0 + 0x15e3b]()
    //     0xdf1158: mov             x17, #0x5e3b
    //     0xdf115c: movk            x17, #1, lsl #16
    //     0xdf1160: add             lr, x0, x17
    //     0xdf1164: ldr             lr, [x21, lr, lsl #3]
    //     0xdf1168: blr             lr
    // 0xdf116c: sub             x1, x0, #1
    // 0xdf1170: r2 = 7
    //     0xdf1170: mov             x2, #7
    // 0xdf1174: sdiv            x4, x1, x2
    // 0xdf1178: msub            x3, x4, x2, x1
    // 0xdf117c: cmp             x3, xzr
    // 0xdf1180: b.lt            #0xdf11b4
    // 0xdf1184: ldur            x1, [fp, #-0x10]
    // 0xdf1188: sub             x4, x1, x3
    // 0xdf118c: sdiv            x1, x4, x2
    // 0xdf1190: msub            x0, x1, x2, x4
    // 0xdf1194: cmp             x0, xzr
    // 0xdf1198: b.lt            #0xdf11bc
    // 0xdf119c: LeaveFrame
    //     0xdf119c: mov             SP, fp
    //     0xdf11a0: ldp             fp, lr, [SP], #0x10
    // 0xdf11a4: ret
    //     0xdf11a4: ret             
    // 0xdf11a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf11a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf11ac: b               #0xdf10d4
    // 0xdf11b0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf11b0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf11b4: add             x3, x3, x2
    // 0xdf11b8: b               #0xdf1184
    // 0xdf11bc: add             x0, x0, x2
    // 0xdf11c0: b               #0xdf119c
  }
  static _ addDaysToDate(/* No info */) {
    // ** addr: 0xf90208, size: 0x138
    // 0xf90208: EnterFrame
    //     0xf90208: stp             fp, lr, [SP, #-0x10]!
    //     0xf9020c: mov             fp, SP
    // 0xf90210: AllocStack(0x30)
    //     0xf90210: sub             SP, SP, #0x30
    // 0xf90214: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xf90214: mov             x0, x1
    //     0xf90218: stur            x1, [fp, #-8]
    //     0xf9021c: stur            x2, [fp, #-0x10]
    // 0xf90220: CheckStackOverflow
    //     0xf90220: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf90224: cmp             SP, x16
    //     0xf90228: b.ls            #0xf9032c
    // 0xf9022c: mov             x1, x0
    // 0xf90230: r0 = _parts()
    //     0xf90230: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xf90234: mov             x2, x0
    // 0xf90238: LoadField: r0 = r2->field_b
    //     0xf90238: ldur            w0, [x2, #0xb]
    // 0xf9023c: r1 = LoadInt32Instr(r0)
    //     0xf9023c: sbfx            x1, x0, #1, #0x1f
    // 0xf90240: mov             x0, x1
    // 0xf90244: r1 = 8
    //     0xf90244: mov             x1, #8
    // 0xf90248: cmp             x1, x0
    // 0xf9024c: b.hs            #0xf90334
    // 0xf90250: LoadField: r0 = r2->field_2f
    //     0xf90250: ldur            w0, [x2, #0x2f]
    // 0xf90254: DecompressPointer r0
    //     0xf90254: add             x0, x0, HEAP, lsl #32
    // 0xf90258: ldur            x1, [fp, #-8]
    // 0xf9025c: stur            x0, [fp, #-0x18]
    // 0xf90260: r0 = _parts()
    //     0xf90260: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xf90264: mov             x2, x0
    // 0xf90268: LoadField: r0 = r2->field_b
    //     0xf90268: ldur            w0, [x2, #0xb]
    // 0xf9026c: r1 = LoadInt32Instr(r0)
    //     0xf9026c: sbfx            x1, x0, #1, #0x1f
    // 0xf90270: mov             x0, x1
    // 0xf90274: r1 = 7
    //     0xf90274: mov             x1, #7
    // 0xf90278: cmp             x1, x0
    // 0xf9027c: b.hs            #0xf90338
    // 0xf90280: LoadField: r0 = r2->field_2b
    //     0xf90280: ldur            w0, [x2, #0x2b]
    // 0xf90284: DecompressPointer r0
    //     0xf90284: add             x0, x0, HEAP, lsl #32
    // 0xf90288: ldur            x1, [fp, #-8]
    // 0xf9028c: stur            x0, [fp, #-0x20]
    // 0xf90290: r0 = _parts()
    //     0xf90290: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xf90294: mov             x2, x0
    // 0xf90298: LoadField: r0 = r2->field_b
    //     0xf90298: ldur            w0, [x2, #0xb]
    // 0xf9029c: r1 = LoadInt32Instr(r0)
    //     0xf9029c: sbfx            x1, x0, #1, #0x1f
    // 0xf902a0: mov             x0, x1
    // 0xf902a4: r1 = 5
    //     0xf902a4: mov             x1, #5
    // 0xf902a8: cmp             x1, x0
    // 0xf902ac: b.hs            #0xf9033c
    // 0xf902b0: LoadField: r0 = r2->field_23
    //     0xf902b0: ldur            w0, [x2, #0x23]
    // 0xf902b4: DecompressPointer r0
    //     0xf902b4: add             x0, x0, HEAP, lsl #32
    // 0xf902b8: r1 = LoadInt32Instr(r0)
    //     0xf902b8: sbfx            x1, x0, #1, #0x1f
    //     0xf902bc: tbz             w0, #0, #0xf902c4
    //     0xf902c0: ldur            x1, [x0, #7]
    // 0xf902c4: ldur            x0, [fp, #-0x10]
    // 0xf902c8: add             x2, x1, x0
    // 0xf902cc: ldur            x0, [fp, #-0x18]
    // 0xf902d0: r3 = LoadInt32Instr(r0)
    //     0xf902d0: sbfx            x3, x0, #1, #0x1f
    //     0xf902d4: tbz             w0, #0, #0xf902dc
    //     0xf902d8: ldur            x3, [x0, #7]
    // 0xf902dc: stur            x3, [fp, #-0x10]
    // 0xf902e0: r0 = BoxInt64Instr(r2)
    //     0xf902e0: sbfiz           x0, x2, #1, #0x1f
    //     0xf902e4: cmp             x2, x0, asr #1
    //     0xf902e8: b.eq            #0xf902f4
    //     0xf902ec: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xf902f0: stur            x2, [x0, #7]
    // 0xf902f4: stur            x0, [fp, #-8]
    // 0xf902f8: r0 = DateTime()
    //     0xf902f8: bl              #0x8174b8  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0xf902fc: stur            x0, [fp, #-0x18]
    // 0xf90300: ldur            x16, [fp, #-0x20]
    // 0xf90304: ldur            lr, [fp, #-8]
    // 0xf90308: stp             lr, x16, [SP]
    // 0xf9030c: mov             x1, x0
    // 0xf90310: ldur            x2, [fp, #-0x10]
    // 0xf90314: r4 = const [0, 0x4, 0x2, 0x4, null]
    //     0xf90314: ldr             x4, [PP, #0x1388]  ; [pp+0x1388] List(5) [0, 0x4, 0x2, 0x4, Null]
    // 0xf90318: r0 = DateTime()
    //     0xf90318: bl              #0xaf09e4  ; [dart:core] DateTime::DateTime
    // 0xf9031c: ldur            x0, [fp, #-0x18]
    // 0xf90320: LeaveFrame
    //     0xf90320: mov             SP, fp
    //     0xf90324: ldp             fp, lr, [SP], #0x10
    // 0xf90328: ret
    //     0xf90328: ret             
    // 0xf9032c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf9032c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf90330: b               #0xf9022c
    // 0xf90334: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf90334: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xf90338: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf90338: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xf9033c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf9033c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 3109, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class CalendarDelegate<X0 bound DateTime> extends Object {

  _ isSameDay(/* No info */) {
    // ** addr: 0xc00af4, size: 0x358
    // 0xc00af4: EnterFrame
    //     0xc00af4: stp             fp, lr, [SP, #-0x10]!
    //     0xc00af8: mov             fp, SP
    // 0xc00afc: AllocStack(0x18)
    //     0xc00afc: sub             SP, SP, #0x18
    // 0xc00b00: SetupParameters(dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xc00b00: mov             x4, x2
    //     0xc00b04: stur            x2, [fp, #-0x10]
    //     0xc00b08: stur            x3, [fp, #-0x18]
    // 0xc00b0c: CheckStackOverflow
    //     0xc00b0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc00b10: cmp             SP, x16
    //     0xc00b14: b.ls            #0xc00e2c
    // 0xc00b18: LoadField: r5 = r1->field_7
    //     0xc00b18: ldur            w5, [x1, #7]
    // 0xc00b1c: DecompressPointer r5
    //     0xc00b1c: add             x5, x5, HEAP, lsl #32
    // 0xc00b20: mov             x0, x4
    // 0xc00b24: mov             x2, x5
    // 0xc00b28: stur            x5, [fp, #-8]
    // 0xc00b2c: r1 = Null
    //     0xc00b2c: mov             x1, NULL
    // 0xc00b30: cmp             w0, NULL
    // 0xc00b34: b.eq            #0xc00b60
    // 0xc00b38: cmp             w2, NULL
    // 0xc00b3c: b.eq            #0xc00b60
    // 0xc00b40: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xc00b40: ldur            w4, [x2, #0x17]
    // 0xc00b44: DecompressPointer r4
    //     0xc00b44: add             x4, x4, HEAP, lsl #32
    // 0xc00b48: r8 = X0? bound DateTime
    //     0xc00b48: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3fb8] TypeParameter: X0? bound DateTime
    //     0xc00b4c: ldr             x8, [x8, #0xfb8]
    // 0xc00b50: LoadField: r9 = r4->field_7
    //     0xc00b50: ldur            x9, [x4, #7]
    // 0xc00b54: r3 = Null
    //     0xc00b54: add             x3, PP, #0xad, lsl #12  ; [pp+0xadfb0] Null
    //     0xc00b58: ldr             x3, [x3, #0xfb0]
    // 0xc00b5c: blr             x9
    // 0xc00b60: ldur            x0, [fp, #-0x18]
    // 0xc00b64: ldur            x2, [fp, #-8]
    // 0xc00b68: r1 = Null
    //     0xc00b68: mov             x1, NULL
    // 0xc00b6c: cmp             w0, NULL
    // 0xc00b70: b.eq            #0xc00b9c
    // 0xc00b74: cmp             w2, NULL
    // 0xc00b78: b.eq            #0xc00b9c
    // 0xc00b7c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xc00b7c: ldur            w4, [x2, #0x17]
    // 0xc00b80: DecompressPointer r4
    //     0xc00b80: add             x4, x4, HEAP, lsl #32
    // 0xc00b84: r8 = X0? bound DateTime
    //     0xc00b84: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3fb8] TypeParameter: X0? bound DateTime
    //     0xc00b88: ldr             x8, [x8, #0xfb8]
    // 0xc00b8c: LoadField: r9 = r4->field_7
    //     0xc00b8c: ldur            x9, [x4, #7]
    // 0xc00b90: r3 = Null
    //     0xc00b90: add             x3, PP, #0xad, lsl #12  ; [pp+0xadfc0] Null
    //     0xc00b94: ldr             x3, [x3, #0xfc0]
    // 0xc00b98: blr             x9
    // 0xc00b9c: ldur            x0, [fp, #-0x10]
    // 0xc00ba0: cmp             w0, NULL
    // 0xc00ba4: b.ne            #0xc00bb0
    // 0xc00ba8: r2 = Null
    //     0xc00ba8: mov             x2, NULL
    // 0xc00bac: b               #0xc00be0
    // 0xc00bb0: mov             x1, x0
    // 0xc00bb4: r0 = _parts()
    //     0xc00bb4: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xc00bb8: mov             x2, x0
    // 0xc00bbc: LoadField: r0 = r2->field_b
    //     0xc00bbc: ldur            w0, [x2, #0xb]
    // 0xc00bc0: r1 = LoadInt32Instr(r0)
    //     0xc00bc0: sbfx            x1, x0, #1, #0x1f
    // 0xc00bc4: mov             x0, x1
    // 0xc00bc8: r1 = 8
    //     0xc00bc8: mov             x1, #8
    // 0xc00bcc: cmp             x1, x0
    // 0xc00bd0: b.hs            #0xc00e34
    // 0xc00bd4: LoadField: r0 = r2->field_2f
    //     0xc00bd4: ldur            w0, [x2, #0x2f]
    // 0xc00bd8: DecompressPointer r0
    //     0xc00bd8: add             x0, x0, HEAP, lsl #32
    // 0xc00bdc: mov             x2, x0
    // 0xc00be0: ldur            x0, [fp, #-0x18]
    // 0xc00be4: stur            x2, [fp, #-8]
    // 0xc00be8: cmp             w0, NULL
    // 0xc00bec: b.ne            #0xc00bfc
    // 0xc00bf0: mov             x0, x2
    // 0xc00bf4: r1 = Null
    //     0xc00bf4: mov             x1, NULL
    // 0xc00bf8: b               #0xc00c30
    // 0xc00bfc: mov             x1, x0
    // 0xc00c00: r0 = _parts()
    //     0xc00c00: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xc00c04: mov             x2, x0
    // 0xc00c08: LoadField: r0 = r2->field_b
    //     0xc00c08: ldur            w0, [x2, #0xb]
    // 0xc00c0c: r1 = LoadInt32Instr(r0)
    //     0xc00c0c: sbfx            x1, x0, #1, #0x1f
    // 0xc00c10: mov             x0, x1
    // 0xc00c14: r1 = 8
    //     0xc00c14: mov             x1, #8
    // 0xc00c18: cmp             x1, x0
    // 0xc00c1c: b.hs            #0xc00e38
    // 0xc00c20: LoadField: r0 = r2->field_2f
    //     0xc00c20: ldur            w0, [x2, #0x2f]
    // 0xc00c24: DecompressPointer r0
    //     0xc00c24: add             x0, x0, HEAP, lsl #32
    // 0xc00c28: mov             x1, x0
    // 0xc00c2c: ldur            x0, [fp, #-8]
    // 0xc00c30: cmp             w0, w1
    // 0xc00c34: b.eq            #0xc00c70
    // 0xc00c38: and             w16, w0, w1
    // 0xc00c3c: branchIfSmi(r16, 0xc00e1c)
    //     0xc00c3c: tbz             w16, #0, #0xc00e1c
    // 0xc00c40: r16 = LoadClassIdInstr(r0)
    //     0xc00c40: ldur            x16, [x0, #-1]
    //     0xc00c44: ubfx            x16, x16, #0xc, #0x14
    // 0xc00c48: cmp             x16, #0x3d
    // 0xc00c4c: b.ne            #0xc00e1c
    // 0xc00c50: r16 = LoadClassIdInstr(r1)
    //     0xc00c50: ldur            x16, [x1, #-1]
    //     0xc00c54: ubfx            x16, x16, #0xc, #0x14
    // 0xc00c58: cmp             x16, #0x3d
    // 0xc00c5c: b.ne            #0xc00e1c
    // 0xc00c60: LoadField: r16 = r0->field_7
    //     0xc00c60: ldur            x16, [x0, #7]
    // 0xc00c64: LoadField: r17 = r1->field_7
    //     0xc00c64: ldur            x17, [x1, #7]
    // 0xc00c68: cmp             x16, x17
    // 0xc00c6c: b.ne            #0xc00e1c
    // 0xc00c70: ldur            x0, [fp, #-0x10]
    // 0xc00c74: cmp             w0, NULL
    // 0xc00c78: b.ne            #0xc00c84
    // 0xc00c7c: r2 = Null
    //     0xc00c7c: mov             x2, NULL
    // 0xc00c80: b               #0xc00cb4
    // 0xc00c84: mov             x1, x0
    // 0xc00c88: r0 = _parts()
    //     0xc00c88: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xc00c8c: mov             x2, x0
    // 0xc00c90: LoadField: r0 = r2->field_b
    //     0xc00c90: ldur            w0, [x2, #0xb]
    // 0xc00c94: r1 = LoadInt32Instr(r0)
    //     0xc00c94: sbfx            x1, x0, #1, #0x1f
    // 0xc00c98: mov             x0, x1
    // 0xc00c9c: r1 = 7
    //     0xc00c9c: mov             x1, #7
    // 0xc00ca0: cmp             x1, x0
    // 0xc00ca4: b.hs            #0xc00e3c
    // 0xc00ca8: LoadField: r0 = r2->field_2b
    //     0xc00ca8: ldur            w0, [x2, #0x2b]
    // 0xc00cac: DecompressPointer r0
    //     0xc00cac: add             x0, x0, HEAP, lsl #32
    // 0xc00cb0: mov             x2, x0
    // 0xc00cb4: ldur            x0, [fp, #-0x18]
    // 0xc00cb8: stur            x2, [fp, #-8]
    // 0xc00cbc: cmp             w0, NULL
    // 0xc00cc0: b.ne            #0xc00cd0
    // 0xc00cc4: mov             x0, x2
    // 0xc00cc8: r1 = Null
    //     0xc00cc8: mov             x1, NULL
    // 0xc00ccc: b               #0xc00d04
    // 0xc00cd0: mov             x1, x0
    // 0xc00cd4: r0 = _parts()
    //     0xc00cd4: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xc00cd8: mov             x2, x0
    // 0xc00cdc: LoadField: r0 = r2->field_b
    //     0xc00cdc: ldur            w0, [x2, #0xb]
    // 0xc00ce0: r1 = LoadInt32Instr(r0)
    //     0xc00ce0: sbfx            x1, x0, #1, #0x1f
    // 0xc00ce4: mov             x0, x1
    // 0xc00ce8: r1 = 7
    //     0xc00ce8: mov             x1, #7
    // 0xc00cec: cmp             x1, x0
    // 0xc00cf0: b.hs            #0xc00e40
    // 0xc00cf4: LoadField: r0 = r2->field_2b
    //     0xc00cf4: ldur            w0, [x2, #0x2b]
    // 0xc00cf8: DecompressPointer r0
    //     0xc00cf8: add             x0, x0, HEAP, lsl #32
    // 0xc00cfc: mov             x1, x0
    // 0xc00d00: ldur            x0, [fp, #-8]
    // 0xc00d04: cmp             w0, w1
    // 0xc00d08: b.eq            #0xc00d44
    // 0xc00d0c: and             w16, w0, w1
    // 0xc00d10: branchIfSmi(r16, 0xc00e1c)
    //     0xc00d10: tbz             w16, #0, #0xc00e1c
    // 0xc00d14: r16 = LoadClassIdInstr(r0)
    //     0xc00d14: ldur            x16, [x0, #-1]
    //     0xc00d18: ubfx            x16, x16, #0xc, #0x14
    // 0xc00d1c: cmp             x16, #0x3d
    // 0xc00d20: b.ne            #0xc00e1c
    // 0xc00d24: r16 = LoadClassIdInstr(r1)
    //     0xc00d24: ldur            x16, [x1, #-1]
    //     0xc00d28: ubfx            x16, x16, #0xc, #0x14
    // 0xc00d2c: cmp             x16, #0x3d
    // 0xc00d30: b.ne            #0xc00e1c
    // 0xc00d34: LoadField: r16 = r0->field_7
    //     0xc00d34: ldur            x16, [x0, #7]
    // 0xc00d38: LoadField: r17 = r1->field_7
    //     0xc00d38: ldur            x17, [x1, #7]
    // 0xc00d3c: cmp             x16, x17
    // 0xc00d40: b.ne            #0xc00e1c
    // 0xc00d44: ldur            x1, [fp, #-0x10]
    // 0xc00d48: cmp             w1, NULL
    // 0xc00d4c: b.ne            #0xc00d58
    // 0xc00d50: r0 = Null
    //     0xc00d50: mov             x0, NULL
    // 0xc00d54: b               #0xc00d80
    // 0xc00d58: r0 = _parts()
    //     0xc00d58: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xc00d5c: mov             x2, x0
    // 0xc00d60: LoadField: r0 = r2->field_b
    //     0xc00d60: ldur            w0, [x2, #0xb]
    // 0xc00d64: r1 = LoadInt32Instr(r0)
    //     0xc00d64: sbfx            x1, x0, #1, #0x1f
    // 0xc00d68: mov             x0, x1
    // 0xc00d6c: r1 = 5
    //     0xc00d6c: mov             x1, #5
    // 0xc00d70: cmp             x1, x0
    // 0xc00d74: b.hs            #0xc00e44
    // 0xc00d78: LoadField: r0 = r2->field_23
    //     0xc00d78: ldur            w0, [x2, #0x23]
    // 0xc00d7c: DecompressPointer r0
    //     0xc00d7c: add             x0, x0, HEAP, lsl #32
    // 0xc00d80: ldur            x1, [fp, #-0x18]
    // 0xc00d84: stur            x0, [fp, #-8]
    // 0xc00d88: cmp             w1, NULL
    // 0xc00d8c: b.ne            #0xc00d9c
    // 0xc00d90: mov             x1, x0
    // 0xc00d94: r2 = Null
    //     0xc00d94: mov             x2, NULL
    // 0xc00d98: b               #0xc00dc8
    // 0xc00d9c: r0 = _parts()
    //     0xc00d9c: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xc00da0: mov             x2, x0
    // 0xc00da4: LoadField: r3 = r2->field_b
    //     0xc00da4: ldur            w3, [x2, #0xb]
    // 0xc00da8: r0 = LoadInt32Instr(r3)
    //     0xc00da8: sbfx            x0, x3, #1, #0x1f
    // 0xc00dac: r1 = 5
    //     0xc00dac: mov             x1, #5
    // 0xc00db0: cmp             x1, x0
    // 0xc00db4: b.hs            #0xc00e48
    // 0xc00db8: LoadField: r1 = r2->field_23
    //     0xc00db8: ldur            w1, [x2, #0x23]
    // 0xc00dbc: DecompressPointer r1
    //     0xc00dbc: add             x1, x1, HEAP, lsl #32
    // 0xc00dc0: mov             x2, x1
    // 0xc00dc4: ldur            x1, [fp, #-8]
    // 0xc00dc8: cmp             w1, w2
    // 0xc00dcc: b.eq            #0xc00e10
    // 0xc00dd0: and             w16, w1, w2
    // 0xc00dd4: branchIfSmi(r16, 0xc00e08)
    //     0xc00dd4: tbz             w16, #0, #0xc00e08
    // 0xc00dd8: r16 = LoadClassIdInstr(r1)
    //     0xc00dd8: ldur            x16, [x1, #-1]
    //     0xc00ddc: ubfx            x16, x16, #0xc, #0x14
    // 0xc00de0: cmp             x16, #0x3d
    // 0xc00de4: b.ne            #0xc00e08
    // 0xc00de8: r16 = LoadClassIdInstr(r2)
    //     0xc00de8: ldur            x16, [x2, #-1]
    //     0xc00dec: ubfx            x16, x16, #0xc, #0x14
    // 0xc00df0: cmp             x16, #0x3d
    // 0xc00df4: b.ne            #0xc00e08
    // 0xc00df8: LoadField: r16 = r1->field_7
    //     0xc00df8: ldur            x16, [x1, #7]
    // 0xc00dfc: LoadField: r17 = r2->field_7
    //     0xc00dfc: ldur            x17, [x2, #7]
    // 0xc00e00: cmp             x16, x17
    // 0xc00e04: b.eq            #0xc00e10
    // 0xc00e08: r3 = false
    //     0xc00e08: add             x3, NULL, #0x30  ; false
    // 0xc00e0c: b               #0xc00e14
    // 0xc00e10: r3 = true
    //     0xc00e10: add             x3, NULL, #0x20  ; true
    // 0xc00e14: mov             x0, x3
    // 0xc00e18: b               #0xc00e20
    // 0xc00e1c: r0 = false
    //     0xc00e1c: add             x0, NULL, #0x30  ; false
    // 0xc00e20: LeaveFrame
    //     0xc00e20: mov             SP, fp
    //     0xc00e24: ldp             fp, lr, [SP], #0x10
    // 0xc00e28: ret
    //     0xc00e28: ret             
    // 0xc00e2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc00e2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc00e30: b               #0xc00b18
    // 0xc00e34: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc00e34: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xc00e38: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc00e38: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xc00e3c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc00e3c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xc00e40: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc00e40: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xc00e44: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc00e44: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xc00e48: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc00e48: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ formatYear(/* No info */) {
    // ** addr: 0xdee440, size: 0x78
    // 0xdee440: EnterFrame
    //     0xdee440: stp             fp, lr, [SP, #-0x10]!
    //     0xdee444: mov             fp, SP
    // 0xdee448: AllocStack(0x18)
    //     0xdee448: sub             SP, SP, #0x18
    // 0xdee44c: SetupParameters(CalendarDelegate<X0 bound DateTime> this /* r1 => r0 */, dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r1, fp-0x10 */)
    //     0xdee44c: mov             x0, x1
    //     0xdee450: mov             x1, x3
    //     0xdee454: stur            x2, [fp, #-8]
    //     0xdee458: stur            x3, [fp, #-0x10]
    // 0xdee45c: CheckStackOverflow
    //     0xdee45c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdee460: cmp             SP, x16
    //     0xdee464: b.ls            #0xdee4b0
    // 0xdee468: r0 = DateTime()
    //     0xdee468: bl              #0x8174b8  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0xdee46c: mov             x1, x0
    // 0xdee470: ldur            x2, [fp, #-8]
    // 0xdee474: stur            x0, [fp, #-0x18]
    // 0xdee478: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xdee478: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xdee47c: r0 = DateTime()
    //     0xdee47c: bl              #0xaf09e4  ; [dart:core] DateTime::DateTime
    // 0xdee480: ldur            x1, [fp, #-0x10]
    // 0xdee484: r0 = LoadClassIdInstr(r1)
    //     0xdee484: ldur            x0, [x1, #-1]
    //     0xdee488: ubfx            x0, x0, #0xc, #0x14
    // 0xdee48c: ldur            x2, [fp, #-0x18]
    // 0xdee490: r0 = GDT[cid_x0 + 0x16d1d]()
    //     0xdee490: mov             x17, #0x6d1d
    //     0xdee494: movk            x17, #1, lsl #16
    //     0xdee498: add             lr, x0, x17
    //     0xdee49c: ldr             lr, [x21, lr, lsl #3]
    //     0xdee4a0: blr             lr
    // 0xdee4a4: LeaveFrame
    //     0xdee4a4: mov             SP, fp
    //     0xdee4a8: ldp             fp, lr, [SP], #0x10
    // 0xdee4ac: ret
    //     0xdee4ac: ret             
    // 0xdee4b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdee4b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdee4b4: b               #0xdee468
  }
  _ isSameMonth(/* No info */) {
    // ** addr: 0xdef958, size: 0x244
    // 0xdef958: EnterFrame
    //     0xdef958: stp             fp, lr, [SP, #-0x10]!
    //     0xdef95c: mov             fp, SP
    // 0xdef960: AllocStack(0x18)
    //     0xdef960: sub             SP, SP, #0x18
    // 0xdef964: SetupParameters(dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xdef964: mov             x4, x2
    //     0xdef968: stur            x2, [fp, #-0x10]
    //     0xdef96c: stur            x3, [fp, #-0x18]
    // 0xdef970: CheckStackOverflow
    //     0xdef970: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdef974: cmp             SP, x16
    //     0xdef978: b.ls            #0xdefb84
    // 0xdef97c: LoadField: r5 = r1->field_7
    //     0xdef97c: ldur            w5, [x1, #7]
    // 0xdef980: DecompressPointer r5
    //     0xdef980: add             x5, x5, HEAP, lsl #32
    // 0xdef984: mov             x0, x4
    // 0xdef988: mov             x2, x5
    // 0xdef98c: stur            x5, [fp, #-8]
    // 0xdef990: r1 = Null
    //     0xdef990: mov             x1, NULL
    // 0xdef994: cmp             w0, NULL
    // 0xdef998: b.eq            #0xdef9c4
    // 0xdef99c: cmp             w2, NULL
    // 0xdef9a0: b.eq            #0xdef9c4
    // 0xdef9a4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xdef9a4: ldur            w4, [x2, #0x17]
    // 0xdef9a8: DecompressPointer r4
    //     0xdef9a8: add             x4, x4, HEAP, lsl #32
    // 0xdef9ac: r8 = X0? bound DateTime
    //     0xdef9ac: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3fb8] TypeParameter: X0? bound DateTime
    //     0xdef9b0: ldr             x8, [x8, #0xfb8]
    // 0xdef9b4: LoadField: r9 = r4->field_7
    //     0xdef9b4: ldur            x9, [x4, #7]
    // 0xdef9b8: r3 = Null
    //     0xdef9b8: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3fc0] Null
    //     0xdef9bc: ldr             x3, [x3, #0xfc0]
    // 0xdef9c0: blr             x9
    // 0xdef9c4: ldur            x0, [fp, #-0x18]
    // 0xdef9c8: ldur            x2, [fp, #-8]
    // 0xdef9cc: r1 = Null
    //     0xdef9cc: mov             x1, NULL
    // 0xdef9d0: cmp             w0, NULL
    // 0xdef9d4: b.eq            #0xdefa00
    // 0xdef9d8: cmp             w2, NULL
    // 0xdef9dc: b.eq            #0xdefa00
    // 0xdef9e0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xdef9e0: ldur            w4, [x2, #0x17]
    // 0xdef9e4: DecompressPointer r4
    //     0xdef9e4: add             x4, x4, HEAP, lsl #32
    // 0xdef9e8: r8 = X0? bound DateTime
    //     0xdef9e8: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3fb8] TypeParameter: X0? bound DateTime
    //     0xdef9ec: ldr             x8, [x8, #0xfb8]
    // 0xdef9f0: LoadField: r9 = r4->field_7
    //     0xdef9f0: ldur            x9, [x4, #7]
    // 0xdef9f4: r3 = Null
    //     0xdef9f4: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3fd0] Null
    //     0xdef9f8: ldr             x3, [x3, #0xfd0]
    // 0xdef9fc: blr             x9
    // 0xdefa00: ldur            x0, [fp, #-0x10]
    // 0xdefa04: cmp             w0, NULL
    // 0xdefa08: b.ne            #0xdefa14
    // 0xdefa0c: r0 = Null
    //     0xdefa0c: mov             x0, NULL
    // 0xdefa10: b               #0xdefa40
    // 0xdefa14: mov             x1, x0
    // 0xdefa18: r0 = _parts()
    //     0xdefa18: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdefa1c: mov             x2, x0
    // 0xdefa20: LoadField: r0 = r2->field_b
    //     0xdefa20: ldur            w0, [x2, #0xb]
    // 0xdefa24: r1 = LoadInt32Instr(r0)
    //     0xdefa24: sbfx            x1, x0, #1, #0x1f
    // 0xdefa28: mov             x0, x1
    // 0xdefa2c: r1 = 8
    //     0xdefa2c: mov             x1, #8
    // 0xdefa30: cmp             x1, x0
    // 0xdefa34: b.hs            #0xdefb8c
    // 0xdefa38: LoadField: r0 = r2->field_2f
    //     0xdefa38: ldur            w0, [x2, #0x2f]
    // 0xdefa3c: DecompressPointer r0
    //     0xdefa3c: add             x0, x0, HEAP, lsl #32
    // 0xdefa40: ldur            x1, [fp, #-0x18]
    // 0xdefa44: stur            x0, [fp, #-8]
    // 0xdefa48: r0 = _parts()
    //     0xdefa48: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdefa4c: mov             x2, x0
    // 0xdefa50: LoadField: r0 = r2->field_b
    //     0xdefa50: ldur            w0, [x2, #0xb]
    // 0xdefa54: r1 = LoadInt32Instr(r0)
    //     0xdefa54: sbfx            x1, x0, #1, #0x1f
    // 0xdefa58: mov             x0, x1
    // 0xdefa5c: r1 = 8
    //     0xdefa5c: mov             x1, #8
    // 0xdefa60: cmp             x1, x0
    // 0xdefa64: b.hs            #0xdefb90
    // 0xdefa68: LoadField: r0 = r2->field_2f
    //     0xdefa68: ldur            w0, [x2, #0x2f]
    // 0xdefa6c: DecompressPointer r0
    //     0xdefa6c: add             x0, x0, HEAP, lsl #32
    // 0xdefa70: ldur            x1, [fp, #-8]
    // 0xdefa74: cmp             w1, w0
    // 0xdefa78: b.eq            #0xdefab4
    // 0xdefa7c: and             w16, w1, w0
    // 0xdefa80: branchIfSmi(r16, 0xdefb74)
    //     0xdefa80: tbz             w16, #0, #0xdefb74
    // 0xdefa84: r16 = LoadClassIdInstr(r1)
    //     0xdefa84: ldur            x16, [x1, #-1]
    //     0xdefa88: ubfx            x16, x16, #0xc, #0x14
    // 0xdefa8c: cmp             x16, #0x3d
    // 0xdefa90: b.ne            #0xdefb74
    // 0xdefa94: r16 = LoadClassIdInstr(r0)
    //     0xdefa94: ldur            x16, [x0, #-1]
    //     0xdefa98: ubfx            x16, x16, #0xc, #0x14
    // 0xdefa9c: cmp             x16, #0x3d
    // 0xdefaa0: b.ne            #0xdefb74
    // 0xdefaa4: LoadField: r16 = r1->field_7
    //     0xdefaa4: ldur            x16, [x1, #7]
    // 0xdefaa8: LoadField: r17 = r0->field_7
    //     0xdefaa8: ldur            x17, [x0, #7]
    // 0xdefaac: cmp             x16, x17
    // 0xdefab0: b.ne            #0xdefb74
    // 0xdefab4: ldur            x1, [fp, #-0x10]
    // 0xdefab8: cmp             w1, NULL
    // 0xdefabc: b.ne            #0xdefac8
    // 0xdefac0: r0 = Null
    //     0xdefac0: mov             x0, NULL
    // 0xdefac4: b               #0xdefaf0
    // 0xdefac8: r0 = _parts()
    //     0xdefac8: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdefacc: mov             x2, x0
    // 0xdefad0: LoadField: r0 = r2->field_b
    //     0xdefad0: ldur            w0, [x2, #0xb]
    // 0xdefad4: r1 = LoadInt32Instr(r0)
    //     0xdefad4: sbfx            x1, x0, #1, #0x1f
    // 0xdefad8: mov             x0, x1
    // 0xdefadc: r1 = 7
    //     0xdefadc: mov             x1, #7
    // 0xdefae0: cmp             x1, x0
    // 0xdefae4: b.hs            #0xdefb94
    // 0xdefae8: LoadField: r0 = r2->field_2b
    //     0xdefae8: ldur            w0, [x2, #0x2b]
    // 0xdefaec: DecompressPointer r0
    //     0xdefaec: add             x0, x0, HEAP, lsl #32
    // 0xdefaf0: ldur            x1, [fp, #-0x18]
    // 0xdefaf4: stur            x0, [fp, #-8]
    // 0xdefaf8: r0 = _parts()
    //     0xdefaf8: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xdefafc: mov             x2, x0
    // 0xdefb00: LoadField: r3 = r2->field_b
    //     0xdefb00: ldur            w3, [x2, #0xb]
    // 0xdefb04: r0 = LoadInt32Instr(r3)
    //     0xdefb04: sbfx            x0, x3, #1, #0x1f
    // 0xdefb08: r1 = 7
    //     0xdefb08: mov             x1, #7
    // 0xdefb0c: cmp             x1, x0
    // 0xdefb10: b.hs            #0xdefb98
    // 0xdefb14: LoadField: r1 = r2->field_2b
    //     0xdefb14: ldur            w1, [x2, #0x2b]
    // 0xdefb18: DecompressPointer r1
    //     0xdefb18: add             x1, x1, HEAP, lsl #32
    // 0xdefb1c: ldur            x2, [fp, #-8]
    // 0xdefb20: cmp             w2, w1
    // 0xdefb24: b.eq            #0xdefb68
    // 0xdefb28: and             w16, w2, w1
    // 0xdefb2c: branchIfSmi(r16, 0xdefb60)
    //     0xdefb2c: tbz             w16, #0, #0xdefb60
    // 0xdefb30: r16 = LoadClassIdInstr(r2)
    //     0xdefb30: ldur            x16, [x2, #-1]
    //     0xdefb34: ubfx            x16, x16, #0xc, #0x14
    // 0xdefb38: cmp             x16, #0x3d
    // 0xdefb3c: b.ne            #0xdefb60
    // 0xdefb40: r16 = LoadClassIdInstr(r1)
    //     0xdefb40: ldur            x16, [x1, #-1]
    //     0xdefb44: ubfx            x16, x16, #0xc, #0x14
    // 0xdefb48: cmp             x16, #0x3d
    // 0xdefb4c: b.ne            #0xdefb60
    // 0xdefb50: LoadField: r16 = r2->field_7
    //     0xdefb50: ldur            x16, [x2, #7]
    // 0xdefb54: LoadField: r17 = r1->field_7
    //     0xdefb54: ldur            x17, [x1, #7]
    // 0xdefb58: cmp             x16, x17
    // 0xdefb5c: b.eq            #0xdefb68
    // 0xdefb60: r3 = false
    //     0xdefb60: add             x3, NULL, #0x30  ; false
    // 0xdefb64: b               #0xdefb6c
    // 0xdefb68: r3 = true
    //     0xdefb68: add             x3, NULL, #0x20  ; true
    // 0xdefb6c: mov             x0, x3
    // 0xdefb70: b               #0xdefb78
    // 0xdefb74: r0 = false
    //     0xdefb74: add             x0, NULL, #0x30  ; false
    // 0xdefb78: LeaveFrame
    //     0xdefb78: mov             SP, fp
    //     0xdefb7c: ldp             fp, lr, [SP], #0x10
    // 0xdefb80: ret
    //     0xdefb80: ret             
    // 0xdefb84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdefb84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdefb88: b               #0xdef97c
    // 0xdefb8c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdefb8c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdefb90: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdefb90: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdefb94: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdefb94: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdefb98: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdefb98: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 3110, size: 0xc, field offset: 0xc
//   const constructor, 
class GregorianCalendarDelegate extends CalendarDelegate<dynamic> {

  _ now(/* No info */) {
    // ** addr: 0xaf3004, size: 0x58
    // 0xaf3004: EnterFrame
    //     0xaf3004: stp             fp, lr, [SP, #-0x10]!
    //     0xaf3008: mov             fp, SP
    // 0xaf300c: AllocStack(0x8)
    //     0xaf300c: sub             SP, SP, #8
    // 0xaf3010: CheckStackOverflow
    //     0xaf3010: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf3014: cmp             SP, x16
    //     0xaf3018: b.ls            #0xaf3054
    // 0xaf301c: r0 = DateTime()
    //     0xaf301c: bl              #0x8174b8  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0xaf3020: mov             x1, x0
    // 0xaf3024: r0 = false
    //     0xaf3024: add             x0, NULL, #0x30  ; false
    // 0xaf3028: stur            x1, [fp, #-8]
    // 0xaf302c: StoreField: r1->field_7 = r0
    //     0xaf302c: stur            w0, [x1, #7]
    // 0xaf3030: r0 = _getCurrentMicros()
    //     0xaf3030: bl              #0x89fe10  ; [dart:core] DateTime::_getCurrentMicros
    // 0xaf3034: r1 = LoadInt32Instr(r0)
    //     0xaf3034: sbfx            x1, x0, #1, #0x1f
    //     0xaf3038: tbz             w0, #0, #0xaf3040
    //     0xaf303c: ldur            x1, [x0, #7]
    // 0xaf3040: ldur            x0, [fp, #-8]
    // 0xaf3044: StoreField: r0->field_b = r1
    //     0xaf3044: stur            x1, [x0, #0xb]
    // 0xaf3048: LeaveFrame
    //     0xaf3048: mov             SP, fp
    //     0xaf304c: ldp             fp, lr, [SP], #0x10
    // 0xaf3050: ret
    //     0xaf3050: ret             
    // 0xaf3054: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf3054: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf3058: b               #0xaf301c
  }
  _ formatMediumDate(/* No info */) {
    // ** addr: 0xd1623c, size: 0x4c
    // 0xd1623c: EnterFrame
    //     0xd1623c: stp             fp, lr, [SP, #-0x10]!
    //     0xd16240: mov             fp, SP
    // 0xd16244: mov             x0, x1
    // 0xd16248: mov             x1, x3
    // 0xd1624c: CheckStackOverflow
    //     0xd1624c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd16250: cmp             SP, x16
    //     0xd16254: b.ls            #0xd16280
    // 0xd16258: r0 = LoadClassIdInstr(r1)
    //     0xd16258: ldur            x0, [x1, #-1]
    //     0xd1625c: ubfx            x0, x0, #0xc, #0x14
    // 0xd16260: r0 = GDT[cid_x0 + 0x1492d]()
    //     0xd16260: mov             x17, #0x492d
    //     0xd16264: movk            x17, #1, lsl #16
    //     0xd16268: add             lr, x0, x17
    //     0xd1626c: ldr             lr, [x21, lr, lsl #3]
    //     0xd16270: blr             lr
    // 0xd16274: LeaveFrame
    //     0xd16274: mov             SP, fp
    //     0xd16278: ldp             fp, lr, [SP], #0x10
    // 0xd1627c: ret
    //     0xd1627c: ret             
    // 0xd16280: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd16280: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd16284: b               #0xd16258
  }
  _ parseCompactDate(/* No info */) {
    // ** addr: 0xd1848c, size: 0x4c
    // 0xd1848c: EnterFrame
    //     0xd1848c: stp             fp, lr, [SP, #-0x10]!
    //     0xd18490: mov             fp, SP
    // 0xd18494: mov             x0, x1
    // 0xd18498: mov             x1, x3
    // 0xd1849c: CheckStackOverflow
    //     0xd1849c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd184a0: cmp             SP, x16
    //     0xd184a4: b.ls            #0xd184d0
    // 0xd184a8: r0 = LoadClassIdInstr(r1)
    //     0xd184a8: ldur            x0, [x1, #-1]
    //     0xd184ac: ubfx            x0, x0, #0xc, #0x14
    // 0xd184b0: r0 = GDT[cid_x0 + 0x14a25]()
    //     0xd184b0: mov             x17, #0x4a25
    //     0xd184b4: movk            x17, #1, lsl #16
    //     0xd184b8: add             lr, x0, x17
    //     0xd184bc: ldr             lr, [x21, lr, lsl #3]
    //     0xd184c0: blr             lr
    // 0xd184c4: LeaveFrame
    //     0xd184c4: mov             SP, fp
    //     0xd184c8: ldp             fp, lr, [SP], #0x10
    // 0xd184cc: ret
    //     0xd184cc: ret             
    // 0xd184d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd184d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd184d4: b               #0xd184a8
  }
  _ formatMonthYear(/* No info */) {
    // ** addr: 0xdecc7c, size: 0x4c
    // 0xdecc7c: EnterFrame
    //     0xdecc7c: stp             fp, lr, [SP, #-0x10]!
    //     0xdecc80: mov             fp, SP
    // 0xdecc84: mov             x0, x1
    // 0xdecc88: mov             x1, x3
    // 0xdecc8c: CheckStackOverflow
    //     0xdecc8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdecc90: cmp             SP, x16
    //     0xdecc94: b.ls            #0xdeccc0
    // 0xdecc98: r0 = LoadClassIdInstr(r1)
    //     0xdecc98: ldur            x0, [x1, #-1]
    //     0xdecc9c: ubfx            x0, x0, #0xc, #0x14
    // 0xdecca0: r0 = GDT[cid_x0 + 0x149a4]()
    //     0xdecca0: mov             x17, #0x49a4
    //     0xdecca4: movk            x17, #1, lsl #16
    //     0xdecca8: add             lr, x0, x17
    //     0xdeccac: ldr             lr, [x21, lr, lsl #3]
    //     0xdeccb0: blr             lr
    // 0xdeccb4: LeaveFrame
    //     0xdeccb4: mov             SP, fp
    //     0xdeccb8: ldp             fp, lr, [SP], #0x10
    // 0xdeccbc: ret
    //     0xdeccbc: ret             
    // 0xdeccc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdeccc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdeccc4: b               #0xdecc98
  }
  _ getDay(/* No info */) {
    // ** addr: 0xded5e4, size: 0x8c
    // 0xded5e4: EnterFrame
    //     0xded5e4: stp             fp, lr, [SP, #-0x10]!
    //     0xded5e8: mov             fp, SP
    // 0xded5ec: AllocStack(0x30)
    //     0xded5ec: sub             SP, SP, #0x30
    // 0xded5f0: SetupParameters(dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xded5f0: stur            x2, [fp, #-0x18]
    // 0xded5f4: CheckStackOverflow
    //     0xded5f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xded5f8: cmp             SP, x16
    //     0xded5fc: b.ls            #0xded668
    // 0xded600: r0 = BoxInt64Instr(r3)
    //     0xded600: sbfiz           x0, x3, #1, #0x1f
    //     0xded604: cmp             x3, x0, asr #1
    //     0xded608: b.eq            #0xded614
    //     0xded60c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xded610: stur            x3, [x0, #7]
    // 0xded614: mov             x3, x0
    // 0xded618: stur            x3, [fp, #-0x10]
    // 0xded61c: r0 = BoxInt64Instr(r5)
    //     0xded61c: sbfiz           x0, x5, #1, #0x1f
    //     0xded620: cmp             x5, x0, asr #1
    //     0xded624: b.eq            #0xded630
    //     0xded628: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xded62c: stur            x5, [x0, #7]
    // 0xded630: stur            x0, [fp, #-8]
    // 0xded634: r0 = DateTime()
    //     0xded634: bl              #0x8174b8  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0xded638: stur            x0, [fp, #-0x20]
    // 0xded63c: ldur            x16, [fp, #-0x10]
    // 0xded640: ldur            lr, [fp, #-8]
    // 0xded644: stp             lr, x16, [SP]
    // 0xded648: mov             x1, x0
    // 0xded64c: ldur            x2, [fp, #-0x18]
    // 0xded650: r4 = const [0, 0x4, 0x2, 0x4, null]
    //     0xded650: ldr             x4, [PP, #0x1388]  ; [pp+0x1388] List(5) [0, 0x4, 0x2, 0x4, Null]
    // 0xded654: r0 = DateTime()
    //     0xded654: bl              #0xaf09e4  ; [dart:core] DateTime::DateTime
    // 0xded658: ldur            x0, [fp, #-0x20]
    // 0xded65c: LeaveFrame
    //     0xded65c: mov             SP, fp
    //     0xded660: ldp             fp, lr, [SP], #0x10
    // 0xded664: ret
    //     0xded664: ret             
    // 0xded668: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xded668: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xded66c: b               #0xded600
  }
  _ getMonth(/* No info */) {
    // ** addr: 0xdedac8, size: 0x6c
    // 0xdedac8: EnterFrame
    //     0xdedac8: stp             fp, lr, [SP, #-0x10]!
    //     0xdedacc: mov             fp, SP
    // 0xdedad0: AllocStack(0x20)
    //     0xdedad0: sub             SP, SP, #0x20
    // 0xdedad4: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdedad4: stur            x2, [fp, #-0x10]
    // 0xdedad8: CheckStackOverflow
    //     0xdedad8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdedadc: cmp             SP, x16
    //     0xdedae0: b.ls            #0xdedb2c
    // 0xdedae4: r0 = BoxInt64Instr(r3)
    //     0xdedae4: sbfiz           x0, x3, #1, #0x1f
    //     0xdedae8: cmp             x3, x0, asr #1
    //     0xdedaec: b.eq            #0xdedaf8
    //     0xdedaf0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xdedaf4: stur            x3, [x0, #7]
    // 0xdedaf8: stur            x0, [fp, #-8]
    // 0xdedafc: r0 = DateTime()
    //     0xdedafc: bl              #0x8174b8  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0xdedb00: stur            x0, [fp, #-0x18]
    // 0xdedb04: ldur            x16, [fp, #-8]
    // 0xdedb08: str             x16, [SP]
    // 0xdedb0c: mov             x1, x0
    // 0xdedb10: ldur            x2, [fp, #-0x10]
    // 0xdedb14: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0xdedb14: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0xdedb18: r0 = DateTime()
    //     0xdedb18: bl              #0xaf09e4  ; [dart:core] DateTime::DateTime
    // 0xdedb1c: ldur            x0, [fp, #-0x18]
    // 0xdedb20: LeaveFrame
    //     0xdedb20: mov             SP, fp
    //     0xdedb24: ldp             fp, lr, [SP], #0x10
    // 0xdedb28: ret
    //     0xdedb28: ret             
    // 0xdedb2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdedb2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdedb30: b               #0xdedae4
  }
  _ formatFullDate(/* No info */) {
    // ** addr: 0xdedfac, size: 0x4c
    // 0xdedfac: EnterFrame
    //     0xdedfac: stp             fp, lr, [SP, #-0x10]!
    //     0xdedfb0: mov             fp, SP
    // 0xdedfb4: mov             x0, x1
    // 0xdedfb8: mov             x1, x3
    // 0xdedfbc: CheckStackOverflow
    //     0xdedfbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdedfc0: cmp             SP, x16
    //     0xdedfc4: b.ls            #0xdedff0
    // 0xdedfc8: r0 = LoadClassIdInstr(r1)
    //     0xdedfc8: ldur            x0, [x1, #-1]
    //     0xdedfcc: ubfx            x0, x0, #0xc, #0x14
    // 0xdedfd0: r0 = GDT[cid_x0 + 0x15945]()
    //     0xdedfd0: mov             x17, #0x5945
    //     0xdedfd4: movk            x17, #1, lsl #16
    //     0xdedfd8: add             lr, x0, x17
    //     0xdedfdc: ldr             lr, [x21, lr, lsl #3]
    //     0xdedfe0: blr             lr
    // 0xdedfe4: LeaveFrame
    //     0xdedfe4: mov             SP, fp
    //     0xdedfe8: ldp             fp, lr, [SP], #0x10
    // 0xdedfec: ret
    //     0xdedfec: ret             
    // 0xdedff0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdedff0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdedff4: b               #0xdedfc8
  }
  _ dateHelpText(/* No info */) {
    // ** addr: 0xdf7aac, size: 0x4c
    // 0xdf7aac: EnterFrame
    //     0xdf7aac: stp             fp, lr, [SP, #-0x10]!
    //     0xdf7ab0: mov             fp, SP
    // 0xdf7ab4: mov             x0, x1
    // 0xdf7ab8: mov             x1, x2
    // 0xdf7abc: CheckStackOverflow
    //     0xdf7abc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf7ac0: cmp             SP, x16
    //     0xdf7ac4: b.ls            #0xdf7af0
    // 0xdf7ac8: r0 = LoadClassIdInstr(r1)
    //     0xdf7ac8: ldur            x0, [x1, #-1]
    //     0xdf7acc: ubfx            x0, x0, #0xc, #0x14
    // 0xdf7ad0: r0 = GDT[cid_x0 + 0x14cbe]()
    //     0xdf7ad0: mov             x17, #0x4cbe
    //     0xdf7ad4: movk            x17, #1, lsl #16
    //     0xdf7ad8: add             lr, x0, x17
    //     0xdf7adc: ldr             lr, [x21, lr, lsl #3]
    //     0xdf7ae0: blr             lr
    // 0xdf7ae4: LeaveFrame
    //     0xdf7ae4: mov             SP, fp
    //     0xdf7ae8: ldp             fp, lr, [SP], #0x10
    // 0xdf7aec: ret
    //     0xdf7aec: ret             
    // 0xdf7af0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf7af0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf7af4: b               #0xdf7ac8
  }
  _ formatCompactDate(/* No info */) {
    // ** addr: 0xef5340, size: 0x4c
    // 0xef5340: EnterFrame
    //     0xef5340: stp             fp, lr, [SP, #-0x10]!
    //     0xef5344: mov             fp, SP
    // 0xef5348: mov             x0, x1
    // 0xef534c: mov             x1, x3
    // 0xef5350: CheckStackOverflow
    //     0xef5350: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef5354: cmp             SP, x16
    //     0xef5358: b.ls            #0xef5384
    // 0xef535c: r0 = LoadClassIdInstr(r1)
    //     0xef535c: ldur            x0, [x1, #-1]
    //     0xef5360: ubfx            x0, x0, #0xc, #0x14
    // 0xef5364: r0 = GDT[cid_x0 + 0x17203]()
    //     0xef5364: mov             x17, #0x7203
    //     0xef5368: movk            x17, #1, lsl #16
    //     0xef536c: add             lr, x0, x17
    //     0xef5370: ldr             lr, [x21, lr, lsl #3]
    //     0xef5374: blr             lr
    // 0xef5378: LeaveFrame
    //     0xef5378: mov             SP, fp
    //     0xef537c: ldp             fp, lr, [SP], #0x10
    // 0xef5380: ret
    //     0xef5380: ret             
    // 0xef5384: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef5384: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef5388: b               #0xef535c
  }
}

// class id: 8290, size: 0x14, field offset: 0x14
enum DatePickerMode extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9fcc, size: 0x64
    // 0x11a9fcc: EnterFrame
    //     0x11a9fcc: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9fd0: mov             fp, SP
    // 0x11a9fd4: AllocStack(0x10)
    //     0x11a9fd4: sub             SP, SP, #0x10
    // 0x11a9fd8: SetupParameters(DatePickerMode this /* r1 => r0, fp-0x8 */)
    //     0x11a9fd8: mov             x0, x1
    //     0x11a9fdc: stur            x1, [fp, #-8]
    // 0x11a9fe0: CheckStackOverflow
    //     0x11a9fe0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9fe4: cmp             SP, x16
    //     0x11a9fe8: b.ls            #0x11aa028
    // 0x11a9fec: r1 = Null
    //     0x11a9fec: mov             x1, NULL
    // 0x11a9ff0: r2 = 4
    //     0x11a9ff0: mov             x2, #4
    // 0x11a9ff4: r0 = AllocateArray()
    //     0x11a9ff4: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9ff8: r16 = "DatePickerMode."
    //     0x11a9ff8: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c9a0] "DatePickerMode."
    //     0x11a9ffc: ldr             x16, [x16, #0x9a0]
    // 0x11aa000: StoreField: r0->field_f = r16
    //     0x11aa000: stur            w16, [x0, #0xf]
    // 0x11aa004: ldur            x1, [fp, #-8]
    // 0x11aa008: LoadField: r2 = r1->field_f
    //     0x11aa008: ldur            w2, [x1, #0xf]
    // 0x11aa00c: DecompressPointer r2
    //     0x11aa00c: add             x2, x2, HEAP, lsl #32
    // 0x11aa010: StoreField: r0->field_13 = r2
    //     0x11aa010: stur            w2, [x0, #0x13]
    // 0x11aa014: str             x0, [SP]
    // 0x11aa018: r0 = _interpolate()
    //     0x11aa018: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa01c: LeaveFrame
    //     0x11aa01c: mov             SP, fp
    //     0x11aa020: ldp             fp, lr, [SP], #0x10
    // 0x11aa024: ret
    //     0x11aa024: ret             
    // 0x11aa028: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa028: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa02c: b               #0x11a9fec
  }
}

// class id: 8291, size: 0x14, field offset: 0x14
enum DatePickerEntryMode extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9f68, size: 0x64
    // 0x11a9f68: EnterFrame
    //     0x11a9f68: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9f6c: mov             fp, SP
    // 0x11a9f70: AllocStack(0x10)
    //     0x11a9f70: sub             SP, SP, #0x10
    // 0x11a9f74: SetupParameters(DatePickerEntryMode this /* r1 => r0, fp-0x8 */)
    //     0x11a9f74: mov             x0, x1
    //     0x11a9f78: stur            x1, [fp, #-8]
    // 0x11a9f7c: CheckStackOverflow
    //     0x11a9f7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9f80: cmp             SP, x16
    //     0x11a9f84: b.ls            #0x11a9fc4
    // 0x11a9f88: r1 = Null
    //     0x11a9f88: mov             x1, NULL
    // 0x11a9f8c: r2 = 4
    //     0x11a9f8c: mov             x2, #4
    // 0x11a9f90: r0 = AllocateArray()
    //     0x11a9f90: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9f94: r16 = "DatePickerEntryMode."
    //     0x11a9f94: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c9a8] "DatePickerEntryMode."
    //     0x11a9f98: ldr             x16, [x16, #0x9a8]
    // 0x11a9f9c: StoreField: r0->field_f = r16
    //     0x11a9f9c: stur            w16, [x0, #0xf]
    // 0x11a9fa0: ldur            x1, [fp, #-8]
    // 0x11a9fa4: LoadField: r2 = r1->field_f
    //     0x11a9fa4: ldur            w2, [x1, #0xf]
    // 0x11a9fa8: DecompressPointer r2
    //     0x11a9fa8: add             x2, x2, HEAP, lsl #32
    // 0x11a9fac: StoreField: r0->field_13 = r2
    //     0x11a9fac: stur            w2, [x0, #0x13]
    // 0x11a9fb0: str             x0, [SP]
    // 0x11a9fb4: r0 = _interpolate()
    //     0x11a9fb4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9fb8: LeaveFrame
    //     0x11a9fb8: mov             SP, fp
    //     0x11a9fbc: ldp             fp, lr, [SP], #0x10
    // 0x11a9fc0: ret
    //     0x11a9fc0: ret             
    // 0x11a9fc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9fc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9fc8: b               #0x11a9f88
  }
}
