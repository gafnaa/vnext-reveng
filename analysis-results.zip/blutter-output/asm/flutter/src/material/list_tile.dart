// lib: , url: package:flutter/src/material/list_tile.dart

// class id: 1048909, size: 0x8
class :: {
}

// class id: 3005, size: 0x1c, field offset: 0xc
class _IndividualOverrides extends WidgetStateProperty<dynamic> {

  Color? resolve(_IndividualOverrides, Set<WidgetState>) {
    // ** addr: 0xa061ec, size: 0x110
    // 0xa061ec: EnterFrame
    //     0xa061ec: stp             fp, lr, [SP, #-0x10]!
    //     0xa061f0: mov             fp, SP
    // 0xa061f4: AllocStack(0x28)
    //     0xa061f4: sub             SP, SP, #0x28
    // 0xa061f8: SetupParameters(_IndividualOverrides this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xa061f8: mov             x4, x1
    //     0xa061fc: mov             x3, x2
    //     0xa06200: stur            x1, [fp, #-8]
    //     0xa06204: stur            x2, [fp, #-0x10]
    // 0xa06208: CheckStackOverflow
    //     0xa06208: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa0620c: cmp             SP, x16
    //     0xa06210: b.ls            #0xa062f4
    // 0xa06214: LoadField: r0 = r4->field_b
    //     0xa06214: ldur            w0, [x4, #0xb]
    // 0xa06218: DecompressPointer r0
    //     0xa06218: add             x0, x0, HEAP, lsl #32
    // 0xa0621c: r1 = LoadClassIdInstr(r0)
    //     0xa0621c: ldur            x1, [x0, #-1]
    //     0xa06220: ubfx            x1, x1, #0xc, #0x14
    // 0xa06224: cmp             x1, #0xece
    // 0xa06228: b.ne            #0xa06250
    // 0xa0622c: r16 = <Color?>
    //     0xa0622c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xa06230: ldr             x16, [x16, #0xa40]
    // 0xa06234: stp             x0, x16, [SP, #8]
    // 0xa06238: str             x3, [SP]
    // 0xa0623c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa0623c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa06240: r0 = resolveAs()
    //     0xa06240: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xa06244: LeaveFrame
    //     0xa06244: mov             SP, fp
    //     0xa06248: ldp             fp, lr, [SP], #0x10
    // 0xa0624c: ret
    //     0xa0624c: ret             
    // 0xa06250: r0 = LoadClassIdInstr(r3)
    //     0xa06250: ldur            x0, [x3, #-1]
    //     0xa06254: ubfx            x0, x0, #0xc, #0x14
    // 0xa06258: mov             x1, x3
    // 0xa0625c: r2 = Instance_WidgetState
    //     0xa0625c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xa06260: ldr             x2, [x2, #0xa70]
    // 0xa06264: r0 = GDT[cid_x0 + 0x12929]()
    //     0xa06264: mov             x17, #0x2929
    //     0xa06268: movk            x17, #1, lsl #16
    //     0xa0626c: add             lr, x0, x17
    //     0xa06270: ldr             lr, [x21, lr, lsl #3]
    //     0xa06274: blr             lr
    // 0xa06278: tbnz            w0, #4, #0xa06294
    // 0xa0627c: ldur            x3, [fp, #-8]
    // 0xa06280: ArrayLoad: r0 = r3[0]  ; List_4
    //     0xa06280: ldur            w0, [x3, #0x17]
    // 0xa06284: DecompressPointer r0
    //     0xa06284: add             x0, x0, HEAP, lsl #32
    // 0xa06288: LeaveFrame
    //     0xa06288: mov             SP, fp
    //     0xa0628c: ldp             fp, lr, [SP], #0x10
    // 0xa06290: ret
    //     0xa06290: ret             
    // 0xa06294: ldur            x3, [fp, #-8]
    // 0xa06298: ldur            x1, [fp, #-0x10]
    // 0xa0629c: r0 = LoadClassIdInstr(r1)
    //     0xa0629c: ldur            x0, [x1, #-1]
    //     0xa062a0: ubfx            x0, x0, #0xc, #0x14
    // 0xa062a4: r2 = Instance_WidgetState
    //     0xa062a4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xa062a8: ldr             x2, [x2, #0x100]
    // 0xa062ac: r0 = GDT[cid_x0 + 0x12929]()
    //     0xa062ac: mov             x17, #0x2929
    //     0xa062b0: movk            x17, #1, lsl #16
    //     0xa062b4: add             lr, x0, x17
    //     0xa062b8: ldr             lr, [x21, lr, lsl #3]
    //     0xa062bc: blr             lr
    // 0xa062c0: tbnz            w0, #4, #0xa062dc
    // 0xa062c4: ldur            x1, [fp, #-8]
    // 0xa062c8: LoadField: r0 = r1->field_13
    //     0xa062c8: ldur            w0, [x1, #0x13]
    // 0xa062cc: DecompressPointer r0
    //     0xa062cc: add             x0, x0, HEAP, lsl #32
    // 0xa062d0: LeaveFrame
    //     0xa062d0: mov             SP, fp
    //     0xa062d4: ldp             fp, lr, [SP], #0x10
    // 0xa062d8: ret
    //     0xa062d8: ret             
    // 0xa062dc: ldur            x1, [fp, #-8]
    // 0xa062e0: LoadField: r0 = r1->field_f
    //     0xa062e0: ldur            w0, [x1, #0xf]
    // 0xa062e4: DecompressPointer r0
    //     0xa062e4: add             x0, x0, HEAP, lsl #32
    // 0xa062e8: LeaveFrame
    //     0xa062e8: mov             SP, fp
    //     0xa062ec: ldp             fp, lr, [SP], #0x10
    // 0xa062f0: ret
    //     0xa062f0: ret             
    // 0xa062f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa062f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa062f8: b               #0xa06214
  }
  Color? resolve(_IndividualOverrides, Set<WidgetState>) {
    // ** addr: 0xa06314, size: 0x6c
    // 0xa06314: EnterFrame
    //     0xa06314: stp             fp, lr, [SP, #-0x10]!
    //     0xa06318: mov             fp, SP
    // 0xa0631c: CheckStackOverflow
    //     0xa0631c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa06320: cmp             SP, x16
    //     0xa06324: b.ls            #0xa06360
    // 0xa06328: ldr             x0, [fp, #0x10]
    // 0xa0632c: r2 = Null
    //     0xa0632c: mov             x2, NULL
    // 0xa06330: r1 = Null
    //     0xa06330: mov             x1, NULL
    // 0xa06334: r8 = Set<WidgetState>
    //     0xa06334: add             x8, PP, #0x85, lsl #12  ; [pp+0x85200] Type: Set<WidgetState>
    //     0xa06338: ldr             x8, [x8, #0x200]
    // 0xa0633c: r3 = Null
    //     0xa0633c: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8fd10] Null
    //     0xa06340: ldr             x3, [x3, #0xd10]
    // 0xa06344: r0 = Set<WidgetState>()
    //     0xa06344: bl              #0x8de430  ; IsType_Set<WidgetState>_Stub
    // 0xa06348: ldr             x1, [fp, #0x18]
    // 0xa0634c: ldr             x2, [fp, #0x10]
    // 0xa06350: r0 = resolve()
    //     0xa06350: bl              #0xa061ec  ; [package:flutter/src/material/list_tile.dart] _IndividualOverrides::resolve
    // 0xa06354: LeaveFrame
    //     0xa06354: mov             SP, fp
    //     0xa06358: ldp             fp, lr, [SP], #0x10
    // 0xa0635c: ret
    //     0xa0635c: ret             
    // 0xa06360: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa06360: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa06364: b               #0xa06328
  }
}

// class id: 4854, size: 0x8c, field offset: 0x54
class _RenderListTile extends _MixinApplication75&RenderBox&SlottedContainerRenderObjectMixin {

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb1b9cc, size: 0x24
    // 0xb1b9cc: EnterFrame
    //     0xb1b9cc: stp             fp, lr, [SP, #-0x10]!
    //     0xb1b9d0: mov             fp, SP
    // 0xb1b9d4: ldr             x2, [fp, #0x10]
    // 0xb1b9d8: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb1b9d8: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3b60] AnonymousClosure: (0xb1ba14), in [package:flutter/src/material/list_tile.dart] _RenderListTile::computeMinIntrinsicWidth (0xb1ba8c)
    //     0xb1b9dc: ldr             x1, [x1, #0xb60]
    // 0xb1b9e0: r0 = AllocateClosure()
    //     0xb1b9e0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb1b9e4: LeaveFrame
    //     0xb1b9e4: mov             SP, fp
    //     0xb1b9e8: ldp             fp, lr, [SP], #0x10
    // 0xb1b9ec: ret
    //     0xb1b9ec: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb1ba14, size: 0x78
    // 0xb1ba14: EnterFrame
    //     0xb1ba14: stp             fp, lr, [SP, #-0x10]!
    //     0xb1ba18: mov             fp, SP
    // 0xb1ba1c: ldr             x0, [fp, #0x18]
    // 0xb1ba20: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb1ba20: ldur            w1, [x0, #0x17]
    // 0xb1ba24: DecompressPointer r1
    //     0xb1ba24: add             x1, x1, HEAP, lsl #32
    // 0xb1ba28: CheckStackOverflow
    //     0xb1ba28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1ba2c: cmp             SP, x16
    //     0xb1ba30: b.ls            #0xb1ba74
    // 0xb1ba34: ldr             x2, [fp, #0x10]
    // 0xb1ba38: r0 = computeMinIntrinsicWidth()
    //     0xb1ba38: bl              #0xb1ba8c  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::computeMinIntrinsicWidth
    // 0xb1ba3c: r0 = inline_Allocate_Double()
    //     0xb1ba3c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb1ba40: add             x0, x0, #0x10
    //     0xb1ba44: cmp             x1, x0
    //     0xb1ba48: b.ls            #0xb1ba7c
    //     0xb1ba4c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb1ba50: sub             x0, x0, #0xf
    //     0xb1ba54: mov             x1, #0xe19c
    //     0xb1ba58: movk            x1, #3, lsl #16
    //     0xb1ba5c: stur            x1, [x0, #-1]
    // 0xb1ba60: dmb             ishst
    // 0xb1ba64: StoreField: r0->field_7 = d0
    //     0xb1ba64: stur            d0, [x0, #7]
    // 0xb1ba68: LeaveFrame
    //     0xb1ba68: mov             SP, fp
    //     0xb1ba6c: ldp             fp, lr, [SP], #0x10
    // 0xb1ba70: ret
    //     0xb1ba70: ret             
    // 0xb1ba74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1ba74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1ba78: b               #0xb1ba34
    // 0xb1ba7c: SaveReg d0
    //     0xb1ba7c: str             q0, [SP, #-0x10]!
    // 0xb1ba80: r0 = AllocateDouble()
    //     0xb1ba80: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb1ba84: RestoreReg d0
    //     0xb1ba84: ldr             q0, [SP], #0x10
    // 0xb1ba88: b               #0xb1ba64
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0xb1ba8c, size: 0x15c
    // 0xb1ba8c: EnterFrame
    //     0xb1ba8c: stp             fp, lr, [SP, #-0x10]!
    //     0xb1ba90: mov             fp, SP
    // 0xb1ba94: AllocStack(0x28)
    //     0xb1ba94: sub             SP, SP, #0x28
    // 0xb1ba98: SetupParameters(_RenderListTile this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb1ba98: mov             x3, x1
    //     0xb1ba9c: mov             x0, x2
    //     0xb1baa0: stur            x1, [fp, #-8]
    //     0xb1baa4: stur            x2, [fp, #-0x10]
    // 0xb1baa8: CheckStackOverflow
    //     0xb1baa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1baac: cmp             SP, x16
    //     0xb1bab0: b.ls            #0xb1bbd8
    // 0xb1bab4: mov             x1, x3
    // 0xb1bab8: r2 = Instance__ListTileSlot
    //     0xb1bab8: add             x2, PP, #0x99, lsl #12  ; [pp+0x99360] Obj!_ListTileSlot@12c5441
    //     0xb1babc: ldr             x2, [x2, #0x360]
    // 0xb1bac0: r0 = childForSlot()
    //     0xb1bac0: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb1bac4: cmp             w0, NULL
    // 0xb1bac8: b.eq            #0xb1bb2c
    // 0xb1bacc: ldur            x3, [fp, #-8]
    // 0xb1bad0: ldur            x0, [fp, #-0x10]
    // 0xb1bad4: mov             x1, x3
    // 0xb1bad8: r2 = Instance__ListTileSlot
    //     0xb1bad8: add             x2, PP, #0x99, lsl #12  ; [pp+0x99360] Obj!_ListTileSlot@12c5441
    //     0xb1badc: ldr             x2, [x2, #0x360]
    // 0xb1bae0: r0 = childForSlot()
    //     0xb1bae0: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb1bae4: cmp             w0, NULL
    // 0xb1bae8: b.eq            #0xb1bbe0
    // 0xb1baec: ldur            x2, [fp, #-0x10]
    // 0xb1baf0: LoadField: d0 = r2->field_7
    //     0xb1baf0: ldur            d0, [x2, #7]
    // 0xb1baf4: mov             x1, x0
    // 0xb1baf8: r0 = getMinIntrinsicWidth()
    //     0xb1baf8: bl              #0xb1628c  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0xb1bafc: ldur            x0, [fp, #-8]
    // 0xb1bb00: LoadField: d1 = r0->field_7b
    //     0xb1bb00: ldur            d1, [x0, #0x7b]
    // 0xb1bb04: fmax            v2.2d, v0.2d, v1.2d
    // 0xb1bb08: LoadField: d0 = r0->field_6b
    //     0xb1bb08: ldur            d0, [x0, #0x6b]
    // 0xb1bb0c: LoadField: r1 = r0->field_57
    //     0xb1bb0c: ldur            w1, [x0, #0x57]
    // 0xb1bb10: DecompressPointer r1
    //     0xb1bb10: add             x1, x1, HEAP, lsl #32
    // 0xb1bb14: LoadField: d1 = r1->field_7
    //     0xb1bb14: ldur            d1, [x1, #7]
    // 0xb1bb18: d3 = 2.000000
    //     0xb1bb18: fmov            d3, #2.00000000
    // 0xb1bb1c: fmul            d4, d1, d3
    // 0xb1bb20: fadd            d1, d0, d4
    // 0xb1bb24: fadd            d0, d2, d1
    // 0xb1bb28: b               #0xb1bb34
    // 0xb1bb2c: ldur            x0, [fp, #-8]
    // 0xb1bb30: d0 = 0.000000
    //     0xb1bb30: eor             v0.16b, v0.16b, v0.16b
    // 0xb1bb34: ldur            x3, [fp, #-0x10]
    // 0xb1bb38: mov             x1, x0
    // 0xb1bb3c: stur            d0, [fp, #-0x18]
    // 0xb1bb40: r2 = Instance__ListTileSlot
    //     0xb1bb40: add             x2, PP, #0x99, lsl #12  ; [pp+0x99358] Obj!_ListTileSlot@12c5421
    //     0xb1bb44: ldr             x2, [x2, #0x358]
    // 0xb1bb48: r0 = childForSlot()
    //     0xb1bb48: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb1bb4c: cmp             w0, NULL
    // 0xb1bb50: b.eq            #0xb1bbe4
    // 0xb1bb54: ldur            x1, [fp, #-0x10]
    // 0xb1bb58: LoadField: d1 = r1->field_7
    //     0xb1bb58: ldur            d1, [x1, #7]
    // 0xb1bb5c: mov             x1, x0
    // 0xb1bb60: mov             v0.16b, v1.16b
    // 0xb1bb64: stur            d1, [fp, #-0x20]
    // 0xb1bb68: r0 = getMinIntrinsicWidth()
    //     0xb1bb68: bl              #0xb1628c  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0xb1bb6c: ldur            x1, [fp, #-8]
    // 0xb1bb70: r2 = Instance__ListTileSlot
    //     0xb1bb70: add             x2, PP, #0x99, lsl #12  ; [pp+0x99350] Obj!_ListTileSlot@12c5401
    //     0xb1bb74: ldr             x2, [x2, #0x350]
    // 0xb1bb78: stur            d0, [fp, #-0x28]
    // 0xb1bb7c: r0 = childForSlot()
    //     0xb1bb7c: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb1bb80: mov             x1, x0
    // 0xb1bb84: ldur            d0, [fp, #-0x20]
    // 0xb1bb88: r0 = _minWidth()
    //     0xb1bb88: bl              #0xb1bd00  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_minWidth
    // 0xb1bb8c: mov             v1.16b, v0.16b
    // 0xb1bb90: ldur            d0, [fp, #-0x28]
    // 0xb1bb94: fmax            v2.2d, v0.2d, v1.2d
    // 0xb1bb98: ldur            d0, [fp, #-0x18]
    // 0xb1bb9c: fadd            d1, d0, d2
    // 0xb1bba0: ldur            x1, [fp, #-8]
    // 0xb1bba4: stur            d1, [fp, #-0x28]
    // 0xb1bba8: r2 = Instance__ListTileSlot
    //     0xb1bba8: add             x2, PP, #0x99, lsl #12  ; [pp+0x99348] Obj!_ListTileSlot@12c53e1
    //     0xb1bbac: ldr             x2, [x2, #0x348]
    // 0xb1bbb0: r0 = childForSlot()
    //     0xb1bbb0: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb1bbb4: mov             x1, x0
    // 0xb1bbb8: ldur            d0, [fp, #-0x20]
    // 0xb1bbbc: r0 = _maxWidth()
    //     0xb1bbbc: bl              #0xb1bcc4  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_maxWidth
    // 0xb1bbc0: ldur            d1, [fp, #-0x28]
    // 0xb1bbc4: fadd            d2, d1, d0
    // 0xb1bbc8: mov             v0.16b, v2.16b
    // 0xb1bbcc: LeaveFrame
    //     0xb1bbcc: mov             SP, fp
    //     0xb1bbd0: ldp             fp, lr, [SP], #0x10
    // 0xb1bbd4: ret
    //     0xb1bbd4: ret             
    // 0xb1bbd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1bbd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1bbdc: b               #0xb1bab4
    // 0xb1bbe0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1bbe0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb1bbe4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1bbe4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ trailing(/* No info */) {
    // ** addr: 0xb1bbe8, size: 0x34
    // 0xb1bbe8: EnterFrame
    //     0xb1bbe8: stp             fp, lr, [SP, #-0x10]!
    //     0xb1bbec: mov             fp, SP
    // 0xb1bbf0: CheckStackOverflow
    //     0xb1bbf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1bbf4: cmp             SP, x16
    //     0xb1bbf8: b.ls            #0xb1bc14
    // 0xb1bbfc: r2 = Instance__ListTileSlot
    //     0xb1bbfc: add             x2, PP, #0x99, lsl #12  ; [pp+0x99348] Obj!_ListTileSlot@12c53e1
    //     0xb1bc00: ldr             x2, [x2, #0x348]
    // 0xb1bc04: r0 = childForSlot()
    //     0xb1bc04: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb1bc08: LeaveFrame
    //     0xb1bc08: mov             SP, fp
    //     0xb1bc0c: ldp             fp, lr, [SP], #0x10
    // 0xb1bc10: ret
    //     0xb1bc10: ret             
    // 0xb1bc14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1bc14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1bc18: b               #0xb1bbfc
  }
  get _ subtitle(/* No info */) {
    // ** addr: 0xb1bc1c, size: 0x34
    // 0xb1bc1c: EnterFrame
    //     0xb1bc1c: stp             fp, lr, [SP, #-0x10]!
    //     0xb1bc20: mov             fp, SP
    // 0xb1bc24: CheckStackOverflow
    //     0xb1bc24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1bc28: cmp             SP, x16
    //     0xb1bc2c: b.ls            #0xb1bc48
    // 0xb1bc30: r2 = Instance__ListTileSlot
    //     0xb1bc30: add             x2, PP, #0x99, lsl #12  ; [pp+0x99350] Obj!_ListTileSlot@12c5401
    //     0xb1bc34: ldr             x2, [x2, #0x350]
    // 0xb1bc38: r0 = childForSlot()
    //     0xb1bc38: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb1bc3c: LeaveFrame
    //     0xb1bc3c: mov             SP, fp
    //     0xb1bc40: ldp             fp, lr, [SP], #0x10
    // 0xb1bc44: ret
    //     0xb1bc44: ret             
    // 0xb1bc48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1bc48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1bc4c: b               #0xb1bc30
  }
  get _ title(/* No info */) {
    // ** addr: 0xb1bc50, size: 0x40
    // 0xb1bc50: EnterFrame
    //     0xb1bc50: stp             fp, lr, [SP, #-0x10]!
    //     0xb1bc54: mov             fp, SP
    // 0xb1bc58: CheckStackOverflow
    //     0xb1bc58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1bc5c: cmp             SP, x16
    //     0xb1bc60: b.ls            #0xb1bc84
    // 0xb1bc64: r2 = Instance__ListTileSlot
    //     0xb1bc64: add             x2, PP, #0x99, lsl #12  ; [pp+0x99358] Obj!_ListTileSlot@12c5421
    //     0xb1bc68: ldr             x2, [x2, #0x358]
    // 0xb1bc6c: r0 = childForSlot()
    //     0xb1bc6c: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb1bc70: cmp             w0, NULL
    // 0xb1bc74: b.eq            #0xb1bc8c
    // 0xb1bc78: LeaveFrame
    //     0xb1bc78: mov             SP, fp
    //     0xb1bc7c: ldp             fp, lr, [SP], #0x10
    // 0xb1bc80: ret
    //     0xb1bc80: ret             
    // 0xb1bc84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1bc84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1bc88: b               #0xb1bc64
    // 0xb1bc8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1bc8c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ leading(/* No info */) {
    // ** addr: 0xb1bc90, size: 0x34
    // 0xb1bc90: EnterFrame
    //     0xb1bc90: stp             fp, lr, [SP, #-0x10]!
    //     0xb1bc94: mov             fp, SP
    // 0xb1bc98: CheckStackOverflow
    //     0xb1bc98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1bc9c: cmp             SP, x16
    //     0xb1bca0: b.ls            #0xb1bcbc
    // 0xb1bca4: r2 = Instance__ListTileSlot
    //     0xb1bca4: add             x2, PP, #0x99, lsl #12  ; [pp+0x99360] Obj!_ListTileSlot@12c5441
    //     0xb1bca8: ldr             x2, [x2, #0x360]
    // 0xb1bcac: r0 = childForSlot()
    //     0xb1bcac: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb1bcb0: LeaveFrame
    //     0xb1bcb0: mov             SP, fp
    //     0xb1bcb4: ldp             fp, lr, [SP], #0x10
    // 0xb1bcb8: ret
    //     0xb1bcb8: ret             
    // 0xb1bcbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1bcbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1bcc0: b               #0xb1bca4
  }
  static _ _maxWidth(/* No info */) {
    // ** addr: 0xb1bcc4, size: 0x3c
    // 0xb1bcc4: EnterFrame
    //     0xb1bcc4: stp             fp, lr, [SP, #-0x10]!
    //     0xb1bcc8: mov             fp, SP
    // 0xb1bccc: CheckStackOverflow
    //     0xb1bccc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1bcd0: cmp             SP, x16
    //     0xb1bcd4: b.ls            #0xb1bcf8
    // 0xb1bcd8: cmp             w1, NULL
    // 0xb1bcdc: b.ne            #0xb1bce8
    // 0xb1bce0: d0 = 0.000000
    //     0xb1bce0: eor             v0.16b, v0.16b, v0.16b
    // 0xb1bce4: b               #0xb1bcec
    // 0xb1bce8: r0 = getMaxIntrinsicWidth()
    //     0xb1bce8: bl              #0xb16750  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0xb1bcec: LeaveFrame
    //     0xb1bcec: mov             SP, fp
    //     0xb1bcf0: ldp             fp, lr, [SP], #0x10
    // 0xb1bcf4: ret
    //     0xb1bcf4: ret             
    // 0xb1bcf8: r0 = StackOverflowSharedWithFPURegs()
    //     0xb1bcf8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb1bcfc: b               #0xb1bcd8
  }
  static _ _minWidth(/* No info */) {
    // ** addr: 0xb1bd00, size: 0x3c
    // 0xb1bd00: EnterFrame
    //     0xb1bd00: stp             fp, lr, [SP, #-0x10]!
    //     0xb1bd04: mov             fp, SP
    // 0xb1bd08: CheckStackOverflow
    //     0xb1bd08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1bd0c: cmp             SP, x16
    //     0xb1bd10: b.ls            #0xb1bd34
    // 0xb1bd14: cmp             w1, NULL
    // 0xb1bd18: b.ne            #0xb1bd24
    // 0xb1bd1c: d0 = 0.000000
    //     0xb1bd1c: eor             v0.16b, v0.16b, v0.16b
    // 0xb1bd20: b               #0xb1bd28
    // 0xb1bd24: r0 = getMinIntrinsicWidth()
    //     0xb1bd24: bl              #0xb1628c  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0xb1bd28: LeaveFrame
    //     0xb1bd28: mov             SP, fp
    //     0xb1bd2c: ldp             fp, lr, [SP], #0x10
    // 0xb1bd30: ret
    //     0xb1bd30: ret             
    // 0xb1bd34: r0 = StackOverflowSharedWithFPURegs()
    //     0xb1bd34: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb1bd38: b               #0xb1bd14
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb24ba4, size: 0x140
    // 0xb24ba4: EnterFrame
    //     0xb24ba4: stp             fp, lr, [SP, #-0x10]!
    //     0xb24ba8: mov             fp, SP
    // 0xb24bac: AllocStack(0x20)
    //     0xb24bac: sub             SP, SP, #0x20
    // 0xb24bb0: SetupParameters(_RenderListTile this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb24bb0: mov             x3, x1
    //     0xb24bb4: mov             x0, x2
    //     0xb24bb8: stur            x1, [fp, #-8]
    //     0xb24bbc: stur            x2, [fp, #-0x10]
    // 0xb24bc0: CheckStackOverflow
    //     0xb24bc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb24bc4: cmp             SP, x16
    //     0xb24bc8: b.ls            #0xb24cc8
    // 0xb24bcc: mov             x1, x3
    // 0xb24bd0: r2 = Instance__ListTileSlot
    //     0xb24bd0: add             x2, PP, #0x99, lsl #12  ; [pp+0x99358] Obj!_ListTileSlot@12c5421
    //     0xb24bd4: ldr             x2, [x2, #0x358]
    // 0xb24bd8: r0 = childForSlot()
    //     0xb24bd8: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb24bdc: cmp             w0, NULL
    // 0xb24be0: b.eq            #0xb24cd0
    // 0xb24be4: ldur            x1, [fp, #-0x10]
    // 0xb24be8: LoadField: d1 = r1->field_7
    //     0xb24be8: ldur            d1, [x1, #7]
    // 0xb24bec: mov             x1, x0
    // 0xb24bf0: mov             v0.16b, v1.16b
    // 0xb24bf4: stur            d1, [fp, #-0x18]
    // 0xb24bf8: r0 = getMinIntrinsicHeight()
    //     0xb24bf8: bl              #0xb177d8  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0xb24bfc: ldur            x1, [fp, #-8]
    // 0xb24c00: r2 = Instance__ListTileSlot
    //     0xb24c00: add             x2, PP, #0x99, lsl #12  ; [pp+0x99350] Obj!_ListTileSlot@12c5401
    //     0xb24c04: ldr             x2, [x2, #0x350]
    // 0xb24c08: stur            d0, [fp, #-0x20]
    // 0xb24c0c: r0 = childForSlot()
    //     0xb24c0c: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb24c10: cmp             w0, NULL
    // 0xb24c14: b.ne            #0xb24c20
    // 0xb24c18: r0 = Null
    //     0xb24c18: mov             x0, NULL
    // 0xb24c1c: b               #0xb24c58
    // 0xb24c20: mov             x1, x0
    // 0xb24c24: ldur            d0, [fp, #-0x18]
    // 0xb24c28: r0 = getMinIntrinsicHeight()
    //     0xb24c28: bl              #0xb177d8  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0xb24c2c: r0 = inline_Allocate_Double()
    //     0xb24c2c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb24c30: add             x0, x0, #0x10
    //     0xb24c34: cmp             x1, x0
    //     0xb24c38: b.ls            #0xb24cd4
    //     0xb24c3c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb24c40: sub             x0, x0, #0xf
    //     0xb24c44: mov             x1, #0xe19c
    //     0xb24c48: movk            x1, #3, lsl #16
    //     0xb24c4c: stur            x1, [x0, #-1]
    // 0xb24c50: dmb             ishst
    // 0xb24c54: StoreField: r0->field_7 = d0
    //     0xb24c54: stur            d0, [x0, #7]
    // 0xb24c58: cmp             w0, NULL
    // 0xb24c5c: b.ne            #0xb24c68
    // 0xb24c60: d2 = 0.000000
    //     0xb24c60: eor             v2.16b, v2.16b, v2.16b
    // 0xb24c64: b               #0xb24c70
    // 0xb24c68: LoadField: d0 = r0->field_7
    //     0xb24c68: ldur            d0, [x0, #7]
    // 0xb24c6c: mov             v2.16b, v0.16b
    // 0xb24c70: ldur            x1, [fp, #-8]
    // 0xb24c74: ldur            d0, [fp, #-0x20]
    // 0xb24c78: d1 = 2.000000
    //     0xb24c78: fmov            d1, #2.00000000
    // 0xb24c7c: fadd            d3, d0, d2
    // 0xb24c80: LoadField: d0 = r1->field_73
    //     0xb24c80: ldur            d0, [x1, #0x73]
    // 0xb24c84: fmul            d2, d0, d1
    // 0xb24c88: fadd            d0, d3, d2
    // 0xb24c8c: stur            d0, [fp, #-0x18]
    // 0xb24c90: LoadField: r0 = r1->field_83
    //     0xb24c90: ldur            w0, [x1, #0x83]
    // 0xb24c94: DecompressPointer r0
    //     0xb24c94: add             x0, x0, HEAP, lsl #32
    // 0xb24c98: cmp             w0, NULL
    // 0xb24c9c: b.ne            #0xb24cac
    // 0xb24ca0: r0 = _defaultTileHeight()
    //     0xb24ca0: bl              #0xb24da4  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_defaultTileHeight
    // 0xb24ca4: mov             v2.16b, v0.16b
    // 0xb24ca8: b               #0xb24cb4
    // 0xb24cac: LoadField: d1 = r0->field_7
    //     0xb24cac: ldur            d1, [x0, #7]
    // 0xb24cb0: mov             v2.16b, v1.16b
    // 0xb24cb4: ldur            d1, [fp, #-0x18]
    // 0xb24cb8: fmax            v0.2d, v2.2d, v1.2d
    // 0xb24cbc: LeaveFrame
    //     0xb24cbc: mov             SP, fp
    //     0xb24cc0: ldp             fp, lr, [SP], #0x10
    // 0xb24cc4: ret
    //     0xb24cc4: ret             
    // 0xb24cc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb24cc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb24ccc: b               #0xb24bcc
    // 0xb24cd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb24cd0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb24cd4: SaveReg d0
    //     0xb24cd4: str             q0, [SP, #-0x10]!
    // 0xb24cd8: r0 = AllocateDouble()
    //     0xb24cd8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb24cdc: RestoreReg d0
    //     0xb24cdc: ldr             q0, [SP], #0x10
    // 0xb24ce0: b               #0xb24c54
  }
  get _ _targetTileHeight(/* No info */) {
    // ** addr: 0xb24ce4, size: 0x48
    // 0xb24ce4: EnterFrame
    //     0xb24ce4: stp             fp, lr, [SP, #-0x10]!
    //     0xb24ce8: mov             fp, SP
    // 0xb24cec: CheckStackOverflow
    //     0xb24cec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb24cf0: cmp             SP, x16
    //     0xb24cf4: b.ls            #0xb24d24
    // 0xb24cf8: LoadField: r0 = r1->field_83
    //     0xb24cf8: ldur            w0, [x1, #0x83]
    // 0xb24cfc: DecompressPointer r0
    //     0xb24cfc: add             x0, x0, HEAP, lsl #32
    // 0xb24d00: cmp             w0, NULL
    // 0xb24d04: b.ne            #0xb24d10
    // 0xb24d08: r0 = _defaultTileHeight()
    //     0xb24d08: bl              #0xb24da4  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_defaultTileHeight
    // 0xb24d0c: b               #0xb24d18
    // 0xb24d10: LoadField: d1 = r0->field_7
    //     0xb24d10: ldur            d1, [x0, #7]
    // 0xb24d14: mov             v0.16b, v1.16b
    // 0xb24d18: LeaveFrame
    //     0xb24d18: mov             SP, fp
    //     0xb24d1c: ldp             fp, lr, [SP], #0x10
    // 0xb24d20: ret
    //     0xb24d20: ret             
    // 0xb24d24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb24d24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb24d28: b               #0xb24cf8
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb24d2c, size: 0x78
    // 0xb24d2c: EnterFrame
    //     0xb24d2c: stp             fp, lr, [SP, #-0x10]!
    //     0xb24d30: mov             fp, SP
    // 0xb24d34: ldr             x0, [fp, #0x18]
    // 0xb24d38: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb24d38: ldur            w1, [x0, #0x17]
    // 0xb24d3c: DecompressPointer r1
    //     0xb24d3c: add             x1, x1, HEAP, lsl #32
    // 0xb24d40: CheckStackOverflow
    //     0xb24d40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb24d44: cmp             SP, x16
    //     0xb24d48: b.ls            #0xb24d8c
    // 0xb24d4c: ldr             x2, [fp, #0x10]
    // 0xb24d50: r0 = computeMinIntrinsicHeight()
    //     0xb24d50: bl              #0xb24ba4  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::computeMinIntrinsicHeight
    // 0xb24d54: r0 = inline_Allocate_Double()
    //     0xb24d54: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb24d58: add             x0, x0, #0x10
    //     0xb24d5c: cmp             x1, x0
    //     0xb24d60: b.ls            #0xb24d94
    //     0xb24d64: str             x0, [THR, #0x60]  ; THR::top
    //     0xb24d68: sub             x0, x0, #0xf
    //     0xb24d6c: mov             x1, #0xe19c
    //     0xb24d70: movk            x1, #3, lsl #16
    //     0xb24d74: stur            x1, [x0, #-1]
    // 0xb24d78: dmb             ishst
    // 0xb24d7c: StoreField: r0->field_7 = d0
    //     0xb24d7c: stur            d0, [x0, #7]
    // 0xb24d80: LeaveFrame
    //     0xb24d80: mov             SP, fp
    //     0xb24d84: ldp             fp, lr, [SP], #0x10
    // 0xb24d88: ret
    //     0xb24d88: ret             
    // 0xb24d8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb24d8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb24d90: b               #0xb24d4c
    // 0xb24d94: SaveReg d0
    //     0xb24d94: str             q0, [SP, #-0x10]!
    // 0xb24d98: r0 = AllocateDouble()
    //     0xb24d98: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb24d9c: RestoreReg d0
    //     0xb24d9c: ldr             q0, [SP], #0x10
    // 0xb24da0: b               #0xb24d7c
  }
  get _ _defaultTileHeight(/* No info */) {
    // ** addr: 0xb24da4, size: 0xb8
    // 0xb24da4: EnterFrame
    //     0xb24da4: stp             fp, lr, [SP, #-0x10]!
    //     0xb24da8: mov             fp, SP
    // 0xb24dac: AllocStack(0x10)
    //     0xb24dac: sub             SP, SP, #0x10
    // 0xb24db0: SetupParameters(_RenderListTile this /* r1 => r0, fp-0x8 */)
    //     0xb24db0: mov             x0, x1
    //     0xb24db4: stur            x1, [fp, #-8]
    // 0xb24db8: CheckStackOverflow
    //     0xb24db8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb24dbc: cmp             SP, x16
    //     0xb24dc0: b.ls            #0xb24e54
    // 0xb24dc4: LoadField: r1 = r0->field_57
    //     0xb24dc4: ldur            w1, [x0, #0x57]
    // 0xb24dc8: DecompressPointer r1
    //     0xb24dc8: add             x1, x1, HEAP, lsl #32
    // 0xb24dcc: r0 = baseSizeAdjustment()
    //     0xb24dcc: bl              #0xb2496c  ; [package:flutter/src/material/theme_data.dart] VisualDensity::baseSizeAdjustment
    // 0xb24dd0: LoadField: d0 = r0->field_f
    //     0xb24dd0: ldur            d0, [x0, #0xf]
    // 0xb24dd4: ldur            x1, [fp, #-8]
    // 0xb24dd8: stur            d0, [fp, #-0x10]
    // 0xb24ddc: r2 = Instance__ListTileSlot
    //     0xb24ddc: add             x2, PP, #0x99, lsl #12  ; [pp+0x99350] Obj!_ListTileSlot@12c5401
    //     0xb24de0: ldr             x2, [x2, #0x350]
    // 0xb24de4: r0 = childForSlot()
    //     0xb24de4: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb24de8: cmp             w0, NULL
    // 0xb24dec: b.eq            #0xb24e1c
    // 0xb24df0: ldur            x0, [fp, #-8]
    // 0xb24df4: LoadField: r1 = r0->field_53
    //     0xb24df4: ldur            w1, [x0, #0x53]
    // 0xb24df8: DecompressPointer r1
    //     0xb24df8: add             x1, x1, HEAP, lsl #32
    // 0xb24dfc: tbnz            w1, #4, #0xb24e0c
    // 0xb24e00: d1 = 64.000000
    //     0xb24e00: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a68] IMM: double(64) from 0x4050000000000000
    //     0xb24e04: ldr             d1, [x17, #0xa68]
    // 0xb24e08: b               #0xb24e14
    // 0xb24e0c: d1 = 72.000000
    //     0xb24e0c: add             x17, PP, #0x89, lsl #12  ; [pp+0x89030] IMM: double(72) from 0x4052000000000000
    //     0xb24e10: ldr             d1, [x17, #0x30]
    // 0xb24e14: mov             v2.16b, v1.16b
    // 0xb24e18: b               #0xb24e40
    // 0xb24e1c: ldur            x0, [fp, #-8]
    // 0xb24e20: LoadField: r1 = r0->field_53
    //     0xb24e20: ldur            w1, [x0, #0x53]
    // 0xb24e24: DecompressPointer r1
    //     0xb24e24: add             x1, x1, HEAP, lsl #32
    // 0xb24e28: tbnz            w1, #4, #0xb24e34
    // 0xb24e2c: d1 = 48.000000
    //     0xb24e2c: ldr             d1, [PP, #0x5650]  ; [pp+0x5650] IMM: double(48) from 0x4048000000000000
    // 0xb24e30: b               #0xb24e3c
    // 0xb24e34: d1 = 56.000000
    //     0xb24e34: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a70] IMM: double(56) from 0x404c000000000000
    //     0xb24e38: ldr             d1, [x17, #0xa70]
    // 0xb24e3c: mov             v2.16b, v1.16b
    // 0xb24e40: ldur            d1, [fp, #-0x10]
    // 0xb24e44: fadd            d0, d1, d2
    // 0xb24e48: LeaveFrame
    //     0xb24e48: mov             SP, fp
    //     0xb24e4c: ldp             fp, lr, [SP], #0x10
    // 0xb24e50: ret
    //     0xb24e50: ret             
    // 0xb24e54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb24e54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb24e58: b               #0xb24dc4
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb2c660, size: 0x7c
    // 0xb2c660: EnterFrame
    //     0xb2c660: stp             fp, lr, [SP, #-0x10]!
    //     0xb2c664: mov             fp, SP
    // 0xb2c668: ldr             x0, [fp, #0x18]
    // 0xb2c66c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2c66c: ldur            w1, [x0, #0x17]
    // 0xb2c670: DecompressPointer r1
    //     0xb2c670: add             x1, x1, HEAP, lsl #32
    // 0xb2c674: CheckStackOverflow
    //     0xb2c674: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2c678: cmp             SP, x16
    //     0xb2c67c: b.ls            #0xb2c6c4
    // 0xb2c680: ldr             x0, [fp, #0x10]
    // 0xb2c684: LoadField: d0 = r0->field_7
    //     0xb2c684: ldur            d0, [x0, #7]
    // 0xb2c688: r0 = getMinIntrinsicHeight()
    //     0xb2c688: bl              #0xb177d8  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0xb2c68c: r0 = inline_Allocate_Double()
    //     0xb2c68c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2c690: add             x0, x0, #0x10
    //     0xb2c694: cmp             x1, x0
    //     0xb2c698: b.ls            #0xb2c6cc
    //     0xb2c69c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2c6a0: sub             x0, x0, #0xf
    //     0xb2c6a4: mov             x1, #0xe19c
    //     0xb2c6a8: movk            x1, #3, lsl #16
    //     0xb2c6ac: stur            x1, [x0, #-1]
    // 0xb2c6b0: dmb             ishst
    // 0xb2c6b4: StoreField: r0->field_7 = d0
    //     0xb2c6b4: stur            d0, [x0, #7]
    // 0xb2c6b8: LeaveFrame
    //     0xb2c6b8: mov             SP, fp
    //     0xb2c6bc: ldp             fp, lr, [SP], #0x10
    // 0xb2c6c0: ret
    //     0xb2c6c0: ret             
    // 0xb2c6c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2c6c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2c6c8: b               #0xb2c680
    // 0xb2c6cc: SaveReg d0
    //     0xb2c6cc: str             q0, [SP, #-0x10]!
    // 0xb2c6d0: r0 = AllocateDouble()
    //     0xb2c6d0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2c6d4: RestoreReg d0
    //     0xb2c6d4: ldr             q0, [SP], #0x10
    // 0xb2c6d8: b               #0xb2c6b4
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2e088, size: 0x15c
    // 0xb2e088: EnterFrame
    //     0xb2e088: stp             fp, lr, [SP, #-0x10]!
    //     0xb2e08c: mov             fp, SP
    // 0xb2e090: AllocStack(0x28)
    //     0xb2e090: sub             SP, SP, #0x28
    // 0xb2e094: SetupParameters(_RenderListTile this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb2e094: mov             x3, x1
    //     0xb2e098: mov             x0, x2
    //     0xb2e09c: stur            x1, [fp, #-8]
    //     0xb2e0a0: stur            x2, [fp, #-0x10]
    // 0xb2e0a4: CheckStackOverflow
    //     0xb2e0a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2e0a8: cmp             SP, x16
    //     0xb2e0ac: b.ls            #0xb2e1d4
    // 0xb2e0b0: mov             x1, x3
    // 0xb2e0b4: r2 = Instance__ListTileSlot
    //     0xb2e0b4: add             x2, PP, #0x99, lsl #12  ; [pp+0x99360] Obj!_ListTileSlot@12c5441
    //     0xb2e0b8: ldr             x2, [x2, #0x360]
    // 0xb2e0bc: r0 = childForSlot()
    //     0xb2e0bc: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb2e0c0: cmp             w0, NULL
    // 0xb2e0c4: b.eq            #0xb2e128
    // 0xb2e0c8: ldur            x3, [fp, #-8]
    // 0xb2e0cc: ldur            x0, [fp, #-0x10]
    // 0xb2e0d0: mov             x1, x3
    // 0xb2e0d4: r2 = Instance__ListTileSlot
    //     0xb2e0d4: add             x2, PP, #0x99, lsl #12  ; [pp+0x99360] Obj!_ListTileSlot@12c5441
    //     0xb2e0d8: ldr             x2, [x2, #0x360]
    // 0xb2e0dc: r0 = childForSlot()
    //     0xb2e0dc: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb2e0e0: cmp             w0, NULL
    // 0xb2e0e4: b.eq            #0xb2e1dc
    // 0xb2e0e8: ldur            x2, [fp, #-0x10]
    // 0xb2e0ec: LoadField: d0 = r2->field_7
    //     0xb2e0ec: ldur            d0, [x2, #7]
    // 0xb2e0f0: mov             x1, x0
    // 0xb2e0f4: r0 = getMaxIntrinsicWidth()
    //     0xb2e0f4: bl              #0xb16750  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0xb2e0f8: ldur            x0, [fp, #-8]
    // 0xb2e0fc: LoadField: d1 = r0->field_7b
    //     0xb2e0fc: ldur            d1, [x0, #0x7b]
    // 0xb2e100: fmax            v2.2d, v0.2d, v1.2d
    // 0xb2e104: LoadField: d0 = r0->field_6b
    //     0xb2e104: ldur            d0, [x0, #0x6b]
    // 0xb2e108: LoadField: r1 = r0->field_57
    //     0xb2e108: ldur            w1, [x0, #0x57]
    // 0xb2e10c: DecompressPointer r1
    //     0xb2e10c: add             x1, x1, HEAP, lsl #32
    // 0xb2e110: LoadField: d1 = r1->field_7
    //     0xb2e110: ldur            d1, [x1, #7]
    // 0xb2e114: d3 = 2.000000
    //     0xb2e114: fmov            d3, #2.00000000
    // 0xb2e118: fmul            d4, d1, d3
    // 0xb2e11c: fadd            d1, d0, d4
    // 0xb2e120: fadd            d0, d2, d1
    // 0xb2e124: b               #0xb2e130
    // 0xb2e128: ldur            x0, [fp, #-8]
    // 0xb2e12c: d0 = 0.000000
    //     0xb2e12c: eor             v0.16b, v0.16b, v0.16b
    // 0xb2e130: ldur            x3, [fp, #-0x10]
    // 0xb2e134: mov             x1, x0
    // 0xb2e138: stur            d0, [fp, #-0x18]
    // 0xb2e13c: r2 = Instance__ListTileSlot
    //     0xb2e13c: add             x2, PP, #0x99, lsl #12  ; [pp+0x99358] Obj!_ListTileSlot@12c5421
    //     0xb2e140: ldr             x2, [x2, #0x358]
    // 0xb2e144: r0 = childForSlot()
    //     0xb2e144: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb2e148: cmp             w0, NULL
    // 0xb2e14c: b.eq            #0xb2e1e0
    // 0xb2e150: ldur            x1, [fp, #-0x10]
    // 0xb2e154: LoadField: d1 = r1->field_7
    //     0xb2e154: ldur            d1, [x1, #7]
    // 0xb2e158: mov             x1, x0
    // 0xb2e15c: mov             v0.16b, v1.16b
    // 0xb2e160: stur            d1, [fp, #-0x20]
    // 0xb2e164: r0 = getMaxIntrinsicWidth()
    //     0xb2e164: bl              #0xb16750  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0xb2e168: ldur            x1, [fp, #-8]
    // 0xb2e16c: r2 = Instance__ListTileSlot
    //     0xb2e16c: add             x2, PP, #0x99, lsl #12  ; [pp+0x99350] Obj!_ListTileSlot@12c5401
    //     0xb2e170: ldr             x2, [x2, #0x350]
    // 0xb2e174: stur            d0, [fp, #-0x28]
    // 0xb2e178: r0 = childForSlot()
    //     0xb2e178: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb2e17c: mov             x1, x0
    // 0xb2e180: ldur            d0, [fp, #-0x20]
    // 0xb2e184: r0 = _maxWidth()
    //     0xb2e184: bl              #0xb1bcc4  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_maxWidth
    // 0xb2e188: mov             v1.16b, v0.16b
    // 0xb2e18c: ldur            d0, [fp, #-0x28]
    // 0xb2e190: fmax            v2.2d, v0.2d, v1.2d
    // 0xb2e194: ldur            d0, [fp, #-0x18]
    // 0xb2e198: fadd            d1, d0, d2
    // 0xb2e19c: ldur            x1, [fp, #-8]
    // 0xb2e1a0: stur            d1, [fp, #-0x28]
    // 0xb2e1a4: r2 = Instance__ListTileSlot
    //     0xb2e1a4: add             x2, PP, #0x99, lsl #12  ; [pp+0x99348] Obj!_ListTileSlot@12c53e1
    //     0xb2e1a8: ldr             x2, [x2, #0x348]
    // 0xb2e1ac: r0 = childForSlot()
    //     0xb2e1ac: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb2e1b0: mov             x1, x0
    // 0xb2e1b4: ldur            d0, [fp, #-0x20]
    // 0xb2e1b8: r0 = _maxWidth()
    //     0xb2e1b8: bl              #0xb1bcc4  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_maxWidth
    // 0xb2e1bc: ldur            d1, [fp, #-0x28]
    // 0xb2e1c0: fadd            d2, d1, d0
    // 0xb2e1c4: mov             v0.16b, v2.16b
    // 0xb2e1c8: LeaveFrame
    //     0xb2e1c8: mov             SP, fp
    //     0xb2e1cc: ldp             fp, lr, [SP], #0x10
    // 0xb2e1d0: ret
    //     0xb2e1d0: ret             
    // 0xb2e1d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2e1d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2e1d8: b               #0xb2e0b0
    // 0xb2e1dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb2e1dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb2e1e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb2e1e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2e1e4, size: 0x78
    // 0xb2e1e4: EnterFrame
    //     0xb2e1e4: stp             fp, lr, [SP, #-0x10]!
    //     0xb2e1e8: mov             fp, SP
    // 0xb2e1ec: ldr             x0, [fp, #0x18]
    // 0xb2e1f0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2e1f0: ldur            w1, [x0, #0x17]
    // 0xb2e1f4: DecompressPointer r1
    //     0xb2e1f4: add             x1, x1, HEAP, lsl #32
    // 0xb2e1f8: CheckStackOverflow
    //     0xb2e1f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2e1fc: cmp             SP, x16
    //     0xb2e200: b.ls            #0xb2e244
    // 0xb2e204: ldr             x2, [fp, #0x10]
    // 0xb2e208: r0 = computeMaxIntrinsicWidth()
    //     0xb2e208: bl              #0xb2e088  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::computeMaxIntrinsicWidth
    // 0xb2e20c: r0 = inline_Allocate_Double()
    //     0xb2e20c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2e210: add             x0, x0, #0x10
    //     0xb2e214: cmp             x1, x0
    //     0xb2e218: b.ls            #0xb2e24c
    //     0xb2e21c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2e220: sub             x0, x0, #0xf
    //     0xb2e224: mov             x1, #0xe19c
    //     0xb2e228: movk            x1, #3, lsl #16
    //     0xb2e22c: stur            x1, [x0, #-1]
    // 0xb2e230: dmb             ishst
    // 0xb2e234: StoreField: r0->field_7 = d0
    //     0xb2e234: stur            d0, [x0, #7]
    // 0xb2e238: LeaveFrame
    //     0xb2e238: mov             SP, fp
    //     0xb2e23c: ldp             fp, lr, [SP], #0x10
    // 0xb2e240: ret
    //     0xb2e240: ret             
    // 0xb2e244: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2e244: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2e248: b               #0xb2e204
    // 0xb2e24c: SaveReg d0
    //     0xb2e24c: str             q0, [SP, #-0x10]!
    // 0xb2e250: r0 = AllocateDouble()
    //     0xb2e250: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2e254: RestoreReg d0
    //     0xb2e254: ldr             q0, [SP], #0x10
    // 0xb2e258: b               #0xb2e234
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb5042c, size: 0x60
    // 0xb5042c: EnterFrame
    //     0xb5042c: stp             fp, lr, [SP, #-0x10]!
    //     0xb50430: mov             fp, SP
    // 0xb50434: AllocStack(0x8)
    //     0xb50434: sub             SP, SP, #8
    // 0xb50438: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xb50438: mov             x0, x2
    //     0xb5043c: stur            x2, [fp, #-8]
    // 0xb50440: CheckStackOverflow
    //     0xb50440: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb50444: cmp             SP, x16
    //     0xb50448: b.ls            #0xb50484
    // 0xb5044c: mov             x5, x0
    // 0xb50450: r2 = Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static.
    //     0xb50450: add             x2, PP, #0x90, lsl #12  ; [pp+0x90860] Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static. (0x7f2adaa00640)
    //     0xb50454: ldr             x2, [x2, #0x860]
    // 0xb50458: r3 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xb50458: add             x3, PP, #0x90, lsl #12  ; [pp+0x90700] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7f2adaa12214)
    //     0xb5045c: ldr             x3, [x3, #0x700]
    // 0xb50460: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xb50460: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xb50464: r0 = _computeSizes()
    //     0xb50464: bl              #0xb5048c  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_computeSizes
    // 0xb50468: LoadField: r2 = r0->field_13
    //     0xb50468: ldur            w2, [x0, #0x13]
    // 0xb5046c: DecompressPointer r2
    //     0xb5046c: add             x2, x2, HEAP, lsl #32
    // 0xb50470: ldur            x1, [fp, #-8]
    // 0xb50474: r0 = constrain()
    //     0xb50474: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb50478: LeaveFrame
    //     0xb50478: mov             SP, fp
    //     0xb5047c: ldp             fp, lr, [SP], #0x10
    // 0xb50480: ret
    //     0xb50480: ret             
    // 0xb50484: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb50484: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb50488: b               #0xb5044c
  }
  _ _computeSizes(/* No info */) {
    // ** addr: 0xb5048c, size: 0xa34
    // 0xb5048c: EnterFrame
    //     0xb5048c: stp             fp, lr, [SP, #-0x10]!
    //     0xb50490: mov             fp, SP
    // 0xb50494: AllocStack(0xc0)
    //     0xb50494: sub             SP, SP, #0xc0
    // 0xb50498: SetupParameters(_RenderListTile this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r0, fp-0x20 */, dynamic _ /* r5 => r1 */, {dynamic positionChild = Null /* r4, fp-0x8 */})
    //     0xb50498: mov             x0, x3
    //     0xb5049c: stur            x3, [fp, #-0x20]
    //     0xb504a0: mov             x3, x1
    //     0xb504a4: stur            x1, [fp, #-0x10]
    //     0xb504a8: mov             x1, x5
    //     0xb504ac: stur            x2, [fp, #-0x18]
    //     0xb504b0: ldur            w5, [x4, #0x13]
    //     0xb504b4: ldur            w6, [x4, #0x1f]
    //     0xb504b8: add             x6, x6, HEAP, lsl #32
    //     0xb504bc: add             x16, PP, #0x99, lsl #12  ; [pp+0x993a8] "positionChild"
    //     0xb504c0: ldr             x16, [x16, #0x3a8]
    //     0xb504c4: cmp             w6, w16
    //     0xb504c8: b.ne            #0xb504e8
    //     0xb504cc: ldur            w6, [x4, #0x23]
    //     0xb504d0: add             x6, x6, HEAP, lsl #32
    //     0xb504d4: sub             w4, w5, w6
    //     0xb504d8: add             x5, fp, w4, sxtw #2
    //     0xb504dc: ldr             x5, [x5, #8]
    //     0xb504e0: mov             x4, x5
    //     0xb504e4: b               #0xb504ec
    //     0xb504e8: mov             x4, NULL
    //     0xb504ec: stur            x4, [fp, #-8]
    // 0xb504f0: CheckStackOverflow
    //     0xb504f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb504f4: cmp             SP, x16
    //     0xb504f8: b.ls            #0xb50ddc
    // 0xb504fc: r0 = loosen()
    //     0xb504fc: bl              #0xb4ae38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0xb50500: stur            x0, [fp, #-0x28]
    // 0xb50504: LoadField: d0 = r0->field_f
    //     0xb50504: ldur            d0, [x0, #0xf]
    // 0xb50508: ldur            x1, [fp, #-0x10]
    // 0xb5050c: stur            d0, [fp, #-0x60]
    // 0xb50510: r0 = maxIconHeightConstraint()
    //     0xb50510: bl              #0xb511f0  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::maxIconHeightConstraint
    // 0xb50514: ldur            x1, [fp, #-0x28]
    // 0xb50518: mov             x2, x0
    // 0xb5051c: r0 = enforce()
    //     0xb5051c: bl              #0xb2154c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::enforce
    // 0xb50520: ldur            x1, [fp, #-0x10]
    // 0xb50524: r2 = Instance__ListTileSlot
    //     0xb50524: add             x2, PP, #0x99, lsl #12  ; [pp+0x99360] Obj!_ListTileSlot@12c5441
    //     0xb50528: ldr             x2, [x2, #0x360]
    // 0xb5052c: stur            x0, [fp, #-0x30]
    // 0xb50530: r0 = childForSlot()
    //     0xb50530: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb50534: ldur            x1, [fp, #-0x10]
    // 0xb50538: r2 = Instance__ListTileSlot
    //     0xb50538: add             x2, PP, #0x99, lsl #12  ; [pp+0x99348] Obj!_ListTileSlot@12c53e1
    //     0xb5053c: ldr             x2, [x2, #0x348]
    // 0xb50540: stur            x0, [fp, #-0x38]
    // 0xb50544: r0 = childForSlot()
    //     0xb50544: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb50548: mov             x2, x0
    // 0xb5054c: ldur            x1, [fp, #-0x38]
    // 0xb50550: stur            x2, [fp, #-0x40]
    // 0xb50554: cmp             w1, NULL
    // 0xb50558: b.ne            #0xb50568
    // 0xb5055c: mov             x1, x2
    // 0xb50560: r2 = Null
    //     0xb50560: mov             x2, NULL
    // 0xb50564: b               #0xb50590
    // 0xb50568: ldur            x16, [fp, #-0x20]
    // 0xb5056c: stp             x1, x16, [SP, #8]
    // 0xb50570: ldur            x16, [fp, #-0x30]
    // 0xb50574: str             x16, [SP]
    // 0xb50578: ldur            x0, [fp, #-0x20]
    // 0xb5057c: ClosureCall
    //     0xb5057c: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb50580: ldur            x2, [x0, #0x1f]
    //     0xb50584: blr             x2
    // 0xb50588: mov             x2, x0
    // 0xb5058c: ldur            x1, [fp, #-0x40]
    // 0xb50590: stur            x2, [fp, #-0x48]
    // 0xb50594: cmp             w1, NULL
    // 0xb50598: b.ne            #0xb505a8
    // 0xb5059c: mov             x0, x2
    // 0xb505a0: r2 = Null
    //     0xb505a0: mov             x2, NULL
    // 0xb505a4: b               #0xb505d0
    // 0xb505a8: ldur            x16, [fp, #-0x20]
    // 0xb505ac: stp             x1, x16, [SP, #8]
    // 0xb505b0: ldur            x16, [fp, #-0x30]
    // 0xb505b4: str             x16, [SP]
    // 0xb505b8: ldur            x0, [fp, #-0x20]
    // 0xb505bc: ClosureCall
    //     0xb505bc: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb505c0: ldur            x2, [x0, #0x1f]
    //     0xb505c4: blr             x2
    // 0xb505c8: mov             x2, x0
    // 0xb505cc: ldur            x0, [fp, #-0x48]
    // 0xb505d0: stur            x2, [fp, #-0x30]
    // 0xb505d4: cmp             w0, NULL
    // 0xb505d8: b.ne            #0xb505ec
    // 0xb505dc: ldur            x3, [fp, #-0x10]
    // 0xb505e0: d1 = 0.000000
    //     0xb505e0: eor             v1.16b, v1.16b, v1.16b
    // 0xb505e4: d0 = 2.000000
    //     0xb505e4: fmov            d0, #2.00000000
    // 0xb505e8: b               #0xb5061c
    // 0xb505ec: ldur            x3, [fp, #-0x10]
    // 0xb505f0: d0 = 2.000000
    //     0xb505f0: fmov            d0, #2.00000000
    // 0xb505f4: LoadField: d1 = r3->field_7b
    //     0xb505f4: ldur            d1, [x3, #0x7b]
    // 0xb505f8: LoadField: d2 = r0->field_7
    //     0xb505f8: ldur            d2, [x0, #7]
    // 0xb505fc: fmax            v3.2d, v1.2d, v2.2d
    // 0xb50600: LoadField: d1 = r3->field_6b
    //     0xb50600: ldur            d1, [x3, #0x6b]
    // 0xb50604: LoadField: r1 = r3->field_57
    //     0xb50604: ldur            w1, [x3, #0x57]
    // 0xb50608: DecompressPointer r1
    //     0xb50608: add             x1, x1, HEAP, lsl #32
    // 0xb5060c: LoadField: d2 = r1->field_7
    //     0xb5060c: ldur            d2, [x1, #7]
    // 0xb50610: fmul            d4, d2, d0
    // 0xb50614: fadd            d2, d1, d4
    // 0xb50618: fadd            d1, d3, d2
    // 0xb5061c: stur            d1, [fp, #-0x70]
    // 0xb50620: cmp             w2, NULL
    // 0xb50624: b.ne            #0xb50638
    // 0xb50628: mov             x0, x3
    // 0xb5062c: mov             v0.16b, v1.16b
    // 0xb50630: d2 = 0.000000
    //     0xb50630: eor             v2.16b, v2.16b, v2.16b
    // 0xb50634: b               #0xb5066c
    // 0xb50638: LoadField: d2 = r2->field_7
    //     0xb50638: ldur            d2, [x2, #7]
    // 0xb5063c: mov             x1, x3
    // 0xb50640: stur            d2, [fp, #-0x68]
    // 0xb50644: r0 = _effectiveHorizontalTitleGap()
    //     0xb50644: bl              #0xb511d0  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_effectiveHorizontalTitleGap
    // 0xb50648: mov             v1.16b, v0.16b
    // 0xb5064c: ldur            d0, [fp, #-0x68]
    // 0xb50650: fadd            d2, d0, d1
    // 0xb50654: d0 = 32.000000
    //     0xb50654: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a60] IMM: double(32) from 0x4040000000000000
    //     0xb50658: ldr             d0, [x17, #0xa60]
    // 0xb5065c: fmax            v1.2d, v2.2d, v0.2d
    // 0xb50660: mov             v2.16b, v1.16b
    // 0xb50664: ldur            x0, [fp, #-0x10]
    // 0xb50668: ldur            d0, [fp, #-0x70]
    // 0xb5066c: ldur            d1, [fp, #-0x60]
    // 0xb50670: stur            d2, [fp, #-0x68]
    // 0xb50674: fsub            d3, d1, d0
    // 0xb50678: fsub            d4, d3, d2
    // 0xb5067c: r1 = inline_Allocate_Double()
    //     0xb5067c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb50680: add             x1, x1, #0x10
    //     0xb50684: cmp             x2, x1
    //     0xb50688: b.ls            #0xb50de4
    //     0xb5068c: str             x1, [THR, #0x60]  ; THR::top
    //     0xb50690: sub             x1, x1, #0xf
    //     0xb50694: mov             x2, #0xe19c
    //     0xb50698: movk            x2, #3, lsl #16
    //     0xb5069c: stur            x2, [x1, #-1]
    // 0xb506a0: dmb             ishst
    // 0xb506a4: StoreField: r1->field_7 = d4
    //     0xb506a4: stur            d4, [x1, #7]
    // 0xb506a8: str             x1, [SP]
    // 0xb506ac: ldur            x1, [fp, #-0x28]
    // 0xb506b0: r4 = const [0, 0x2, 0x1, 0x1, width, 0x1, null]
    //     0xb506b0: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f198] List(7) [0, 0x2, 0x1, 0x1, "width", 0x1, Null]
    //     0xb506b4: ldr             x4, [x4, #0x198]
    // 0xb506b8: r0 = tighten()
    //     0xb506b8: bl              #0xb4aa24  ; [package:flutter/src/rendering/box.dart] BoxConstraints::tighten
    // 0xb506bc: ldur            x1, [fp, #-0x10]
    // 0xb506c0: r2 = Instance__ListTileSlot
    //     0xb506c0: add             x2, PP, #0x99, lsl #12  ; [pp+0x99350] Obj!_ListTileSlot@12c5401
    //     0xb506c4: ldr             x2, [x2, #0x350]
    // 0xb506c8: stur            x0, [fp, #-0x28]
    // 0xb506cc: r0 = childForSlot()
    //     0xb506cc: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb506d0: ldur            x1, [fp, #-0x10]
    // 0xb506d4: r2 = Instance__ListTileSlot
    //     0xb506d4: add             x2, PP, #0x99, lsl #12  ; [pp+0x99358] Obj!_ListTileSlot@12c5421
    //     0xb506d8: ldr             x2, [x2, #0x358]
    // 0xb506dc: stur            x0, [fp, #-0x50]
    // 0xb506e0: r0 = childForSlot()
    //     0xb506e0: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb506e4: cmp             w0, NULL
    // 0xb506e8: b.eq            #0xb50e08
    // 0xb506ec: ldur            x16, [fp, #-0x20]
    // 0xb506f0: stp             x0, x16, [SP, #8]
    // 0xb506f4: ldur            x16, [fp, #-0x28]
    // 0xb506f8: str             x16, [SP]
    // 0xb506fc: ldur            x0, [fp, #-0x20]
    // 0xb50700: ClosureCall
    //     0xb50700: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb50704: ldur            x2, [x0, #0x1f]
    //     0xb50708: blr             x2
    // 0xb5070c: LoadField: d0 = r0->field_f
    //     0xb5070c: ldur            d0, [x0, #0xf]
    // 0xb50710: ldur            x0, [fp, #-0x10]
    // 0xb50714: stur            d0, [fp, #-0x78]
    // 0xb50718: LoadField: r1 = r0->field_5f
    //     0xb50718: ldur            w1, [x0, #0x5f]
    // 0xb5071c: DecompressPointer r1
    //     0xb5071c: add             x1, x1, HEAP, lsl #32
    // 0xb50720: LoadField: r2 = r1->field_7
    //     0xb50720: ldur            x2, [x1, #7]
    // 0xb50724: cmp             x2, #0
    // 0xb50728: b.gt            #0xb50734
    // 0xb5072c: r2 = false
    //     0xb5072c: add             x2, NULL, #0x30  ; false
    // 0xb50730: b               #0xb50738
    // 0xb50734: r2 = true
    //     0xb50734: add             x2, NULL, #0x20  ; true
    // 0xb50738: ldur            x1, [fp, #-0x50]
    // 0xb5073c: stur            x2, [fp, #-0x58]
    // 0xb50740: cmp             w1, NULL
    // 0xb50744: b.ne            #0xb507a0
    // 0xb50748: LoadField: r1 = r0->field_83
    //     0xb50748: ldur            w1, [x0, #0x83]
    // 0xb5074c: DecompressPointer r1
    //     0xb5074c: add             x1, x1, HEAP, lsl #32
    // 0xb50750: cmp             w1, NULL
    // 0xb50754: b.ne            #0xb50768
    // 0xb50758: mov             x1, x0
    // 0xb5075c: r0 = _defaultTileHeight()
    //     0xb5075c: bl              #0xb24da4  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_defaultTileHeight
    // 0xb50760: mov             v2.16b, v0.16b
    // 0xb50764: b               #0xb50770
    // 0xb50768: LoadField: d0 = r1->field_7
    //     0xb50768: ldur            d0, [x1, #7]
    // 0xb5076c: mov             v2.16b, v0.16b
    // 0xb50770: ldur            x2, [fp, #-0x10]
    // 0xb50774: ldur            d0, [fp, #-0x78]
    // 0xb50778: d1 = 2.000000
    //     0xb50778: fmov            d1, #2.00000000
    // 0xb5077c: LoadField: d3 = r2->field_73
    //     0xb5077c: ldur            d3, [x2, #0x73]
    // 0xb50780: fmul            d4, d3, d1
    // 0xb50784: fadd            d3, d0, d4
    // 0xb50788: fmax            v4.2d, v2.2d, v3.2d
    // 0xb5078c: fsub            d2, d4, d0
    // 0xb50790: fdiv            d0, d2, d1
    // 0xb50794: mov             v1.16b, v4.16b
    // 0xb50798: mov             x0, x2
    // 0xb5079c: b               #0xb50bec
    // 0xb507a0: mov             x2, x0
    // 0xb507a4: d1 = 2.000000
    //     0xb507a4: fmov            d1, #2.00000000
    // 0xb507a8: ldur            x16, [fp, #-0x20]
    // 0xb507ac: stp             x1, x16, [SP, #8]
    // 0xb507b0: ldur            x16, [fp, #-0x28]
    // 0xb507b4: str             x16, [SP]
    // 0xb507b8: ldur            x0, [fp, #-0x20]
    // 0xb507bc: ClosureCall
    //     0xb507bc: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb507c0: ldur            x2, [x0, #0x1f]
    //     0xb507c4: blr             x2
    // 0xb507c8: LoadField: d0 = r0->field_f
    //     0xb507c8: ldur            d0, [x0, #0xf]
    // 0xb507cc: ldur            x1, [fp, #-0x10]
    // 0xb507d0: stur            d0, [fp, #-0x80]
    // 0xb507d4: r2 = Instance__ListTileSlot
    //     0xb507d4: add             x2, PP, #0x99, lsl #12  ; [pp+0x99358] Obj!_ListTileSlot@12c5421
    //     0xb507d8: ldr             x2, [x2, #0x358]
    // 0xb507dc: r0 = childForSlot()
    //     0xb507dc: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb507e0: cmp             w0, NULL
    // 0xb507e4: b.eq            #0xb50e0c
    // 0xb507e8: ldur            x1, [fp, #-0x10]
    // 0xb507ec: LoadField: r2 = r1->field_63
    //     0xb507ec: ldur            w2, [x1, #0x63]
    // 0xb507f0: DecompressPointer r2
    //     0xb507f0: add             x2, x2, HEAP, lsl #32
    // 0xb507f4: ldur            x16, [fp, #-0x18]
    // 0xb507f8: stp             x0, x16, [SP, #0x10]
    // 0xb507fc: ldur            x16, [fp, #-0x28]
    // 0xb50800: stp             x2, x16, [SP]
    // 0xb50804: ldur            x0, [fp, #-0x18]
    // 0xb50808: ClosureCall
    //     0xb50808: ldr             x4, [PP, #0x9d0]  ; [pp+0x9d0] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0xb5080c: ldur            x2, [x0, #0x1f]
    //     0xb50810: blr             x2
    // 0xb50814: cmp             w0, NULL
    // 0xb50818: b.ne            #0xb50854
    // 0xb5081c: ldur            d0, [fp, #-0x78]
    // 0xb50820: r0 = inline_Allocate_Double()
    //     0xb50820: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb50824: add             x0, x0, #0x10
    //     0xb50828: cmp             x1, x0
    //     0xb5082c: b.ls            #0xb50e10
    //     0xb50830: str             x0, [THR, #0x60]  ; THR::top
    //     0xb50834: sub             x0, x0, #0xf
    //     0xb50838: mov             x1, #0xe19c
    //     0xb5083c: movk            x1, #3, lsl #16
    //     0xb50840: stur            x1, [x0, #-1]
    // 0xb50844: dmb             ishst
    // 0xb50848: StoreField: r0->field_7 = d0
    //     0xb50848: stur            d0, [x0, #7]
    // 0xb5084c: mov             x2, x0
    // 0xb50850: b               #0xb5085c
    // 0xb50854: ldur            d0, [fp, #-0x78]
    // 0xb50858: mov             x2, x0
    // 0xb5085c: ldur            x1, [fp, #-0x10]
    // 0xb50860: stur            x2, [fp, #-0x20]
    // 0xb50864: LoadField: r0 = r1->field_67
    //     0xb50864: ldur            w0, [x1, #0x67]
    // 0xb50868: DecompressPointer r0
    //     0xb50868: add             x0, x0, HEAP, lsl #32
    // 0xb5086c: ldur            x16, [fp, #-0x18]
    // 0xb50870: ldur            lr, [fp, #-0x50]
    // 0xb50874: stp             lr, x16, [SP, #0x10]
    // 0xb50878: ldur            x16, [fp, #-0x28]
    // 0xb5087c: stp             x0, x16, [SP]
    // 0xb50880: ldur            x0, [fp, #-0x18]
    // 0xb50884: ClosureCall
    //     0xb50884: ldr             x4, [PP, #0x9d0]  ; [pp+0x9d0] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0xb50888: ldur            x2, [x0, #0x1f]
    //     0xb5088c: blr             x2
    // 0xb50890: cmp             w0, NULL
    // 0xb50894: b.ne            #0xb508cc
    // 0xb50898: ldur            d0, [fp, #-0x80]
    // 0xb5089c: r0 = inline_Allocate_Double()
    //     0xb5089c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb508a0: add             x0, x0, #0x10
    //     0xb508a4: cmp             x1, x0
    //     0xb508a8: b.ls            #0xb50e20
    //     0xb508ac: str             x0, [THR, #0x60]  ; THR::top
    //     0xb508b0: sub             x0, x0, #0xf
    //     0xb508b4: mov             x1, #0xe19c
    //     0xb508b8: movk            x1, #3, lsl #16
    //     0xb508bc: stur            x1, [x0, #-1]
    // 0xb508c0: dmb             ishst
    // 0xb508c4: StoreField: r0->field_7 = d0
    //     0xb508c4: stur            d0, [x0, #7]
    // 0xb508c8: b               #0xb508d0
    // 0xb508cc: ldur            d0, [fp, #-0x80]
    // 0xb508d0: ldur            x1, [fp, #-0x10]
    // 0xb508d4: stur            x0, [fp, #-0x18]
    // 0xb508d8: LoadField: r2 = r1->field_53
    //     0xb508d8: ldur            w2, [x1, #0x53]
    // 0xb508dc: DecompressPointer r2
    //     0xb508dc: add             x2, x2, HEAP, lsl #32
    // 0xb508e0: tbnz            w2, #4, #0xb508ec
    // 0xb508e4: d1 = 28.000000
    //     0xb508e4: fmov            d1, #28.00000000
    // 0xb508e8: b               #0xb508f4
    // 0xb508ec: d1 = 32.000000
    //     0xb508ec: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a60] IMM: double(32) from 0x4040000000000000
    //     0xb508f0: ldr             d1, [x17, #0xa60]
    // 0xb508f4: r2 = inline_Allocate_Double()
    //     0xb508f4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xb508f8: add             x2, x2, #0x10
    //     0xb508fc: cmp             x3, x2
    //     0xb50900: b.ls            #0xb50e30
    //     0xb50904: str             x2, [THR, #0x60]  ; THR::top
    //     0xb50908: sub             x2, x2, #0xf
    //     0xb5090c: mov             x3, #0xe19c
    //     0xb50910: movk            x3, #3, lsl #16
    //     0xb50914: stur            x3, [x2, #-1]
    // 0xb50918: dmb             ishst
    // 0xb5091c: StoreField: r2->field_7 = d1
    //     0xb5091c: stur            d1, [x2, #7]
    // 0xb50920: ldur            x16, [fp, #-0x20]
    // 0xb50924: stp             x16, x2, [SP]
    // 0xb50928: r0 = -()
    //     0xb50928: bl              #0x13dd180  ; [dart:core] _Double::-
    // 0xb5092c: ldur            x1, [fp, #-0x10]
    // 0xb50930: stur            x0, [fp, #-0x20]
    // 0xb50934: LoadField: r2 = r1->field_53
    //     0xb50934: ldur            w2, [x1, #0x53]
    // 0xb50938: DecompressPointer r2
    //     0xb50938: add             x2, x2, HEAP, lsl #32
    // 0xb5093c: tbnz            w2, #4, #0xb50948
    // 0xb50940: d2 = 48.000000
    //     0xb50940: ldr             d2, [PP, #0x5650]  ; [pp+0x5650] IMM: double(48) from 0x4048000000000000
    // 0xb50944: b               #0xb50950
    // 0xb50948: d2 = 52.000000
    //     0xb50948: add             x17, PP, #0x22, lsl #12  ; [pp+0x22108] IMM: double(52) from 0x404a000000000000
    //     0xb5094c: ldr             d2, [x17, #0x108]
    // 0xb50950: ldur            d0, [fp, #-0x78]
    // 0xb50954: d1 = 2.000000
    //     0xb50954: fmov            d1, #2.00000000
    // 0xb50958: LoadField: r2 = r1->field_57
    //     0xb50958: ldur            w2, [x1, #0x57]
    // 0xb5095c: DecompressPointer r2
    //     0xb5095c: add             x2, x2, HEAP, lsl #32
    // 0xb50960: LoadField: d3 = r2->field_f
    //     0xb50960: ldur            d3, [x2, #0xf]
    // 0xb50964: fmul            d4, d3, d1
    // 0xb50968: fadd            d3, d2, d4
    // 0xb5096c: r2 = inline_Allocate_Double()
    //     0xb5096c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xb50970: add             x2, x2, #0x10
    //     0xb50974: cmp             x3, x2
    //     0xb50978: b.ls            #0xb50e4c
    //     0xb5097c: str             x2, [THR, #0x60]  ; THR::top
    //     0xb50980: sub             x2, x2, #0xf
    //     0xb50984: mov             x3, #0xe19c
    //     0xb50988: movk            x3, #3, lsl #16
    //     0xb5098c: stur            x3, [x2, #-1]
    // 0xb50990: dmb             ishst
    // 0xb50994: StoreField: r2->field_7 = d3
    //     0xb50994: stur            d3, [x2, #7]
    // 0xb50998: ldur            x16, [fp, #-0x18]
    // 0xb5099c: stp             x16, x2, [SP]
    // 0xb509a0: r0 = -()
    //     0xb509a0: bl              #0x13dd180  ; [dart:core] _Double::-
    // 0xb509a4: mov             x1, x0
    // 0xb509a8: ldur            x0, [fp, #-0x20]
    // 0xb509ac: LoadField: d0 = r0->field_7
    //     0xb509ac: ldur            d0, [x0, #7]
    // 0xb509b0: ldur            d1, [fp, #-0x78]
    // 0xb509b4: stur            d0, [fp, #-0x90]
    // 0xb509b8: fadd            d2, d0, d1
    // 0xb509bc: LoadField: d3 = r1->field_7
    //     0xb509bc: ldur            d3, [x1, #7]
    // 0xb509c0: stur            d3, [fp, #-0x88]
    // 0xb509c4: fsub            d4, d2, d3
    // 0xb509c8: d2 = 0.000000
    //     0xb509c8: eor             v2.16b, v2.16b, v2.16b
    // 0xb509cc: fcmp            d4, d2
    // 0xb509d0: b.le            #0xb50a04
    // 0xb509d4: r0 = inline_Allocate_Double()
    //     0xb509d4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb509d8: add             x0, x0, #0x10
    //     0xb509dc: cmp             x1, x0
    //     0xb509e0: b.ls            #0xb50e70
    //     0xb509e4: str             x0, [THR, #0x60]  ; THR::top
    //     0xb509e8: sub             x0, x0, #0xf
    //     0xb509ec: mov             x1, #0xe19c
    //     0xb509f0: movk            x1, #3, lsl #16
    //     0xb509f4: stur            x1, [x0, #-1]
    // 0xb509f8: dmb             ishst
    // 0xb509fc: StoreField: r0->field_7 = d4
    //     0xb509fc: stur            d4, [x0, #7]
    // 0xb50a00: b               #0xb50a60
    // 0xb50a04: fcmp            d2, d4
    // 0xb50a08: b.le            #0xb50a14
    // 0xb50a0c: r0 = 0
    //     0xb50a0c: mov             x0, #0
    // 0xb50a10: b               #0xb50a60
    // 0xb50a14: fcmp            d4, #0.0
    // 0xb50a18: b.vs            #0xb50a34
    // 0xb50a1c: b.ne            #0xb50a28
    // 0xb50a20: r0 = 0.000000
    //     0xb50a20: fmov            x0, d4
    // 0xb50a24: cmp             x0, #0
    // 0xb50a28: b.ge            #0xb50a34
    // 0xb50a2c: r0 = 0
    //     0xb50a2c: mov             x0, #0
    // 0xb50a30: b               #0xb50a60
    // 0xb50a34: r0 = inline_Allocate_Double()
    //     0xb50a34: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb50a38: add             x0, x0, #0x10
    //     0xb50a3c: cmp             x1, x0
    //     0xb50a40: b.ls            #0xb50e88
    //     0xb50a44: str             x0, [THR, #0x60]  ; THR::top
    //     0xb50a48: sub             x0, x0, #0xf
    //     0xb50a4c: mov             x1, #0xe19c
    //     0xb50a50: movk            x1, #3, lsl #16
    //     0xb50a54: stur            x1, [x0, #-1]
    // 0xb50a58: dmb             ishst
    // 0xb50a5c: StoreField: r0->field_7 = d4
    //     0xb50a5c: stur            d4, [x0, #7]
    // 0xb50a60: ldur            x1, [fp, #-0x10]
    // 0xb50a64: r2 = 60
    //     0xb50a64: mov             x2, #0x3c
    // 0xb50a68: branchIfSmi(r0, 0xb50a74)
    //     0xb50a68: tbz             w0, #0, #0xb50a74
    // 0xb50a6c: r2 = LoadClassIdInstr(r0)
    //     0xb50a6c: ldur            x2, [x0, #-1]
    //     0xb50a70: ubfx            x2, x2, #0xc, #0x14
    // 0xb50a74: r16 = 4
    //     0xb50a74: mov             x16, #4
    // 0xb50a78: stp             x16, x0, [SP]
    // 0xb50a7c: mov             x0, x2
    // 0xb50a80: r0 = GDT[cid_x0 + -0xff4]()
    //     0xb50a80: sub             lr, x0, #0xff4
    //     0xb50a84: ldr             lr, [x21, lr, lsl #3]
    //     0xb50a88: blr             lr
    // 0xb50a8c: LoadField: d0 = r0->field_7
    //     0xb50a8c: ldur            d0, [x0, #7]
    // 0xb50a90: ldur            d1, [fp, #-0x90]
    // 0xb50a94: fsub            d2, d1, d0
    // 0xb50a98: ldur            d1, [fp, #-0x88]
    // 0xb50a9c: stur            d2, [fp, #-0x98]
    // 0xb50aa0: fadd            d3, d1, d0
    // 0xb50aa4: ldur            x0, [fp, #-0x10]
    // 0xb50aa8: stur            d3, [fp, #-0x90]
    // 0xb50aac: LoadField: d0 = r0->field_73
    //     0xb50aac: ldur            d0, [x0, #0x73]
    // 0xb50ab0: fcmp            d0, d2
    // 0xb50ab4: b.le            #0xb50ac0
    // 0xb50ab8: r1 = true
    //     0xb50ab8: add             x1, NULL, #0x20  ; true
    // 0xb50abc: b               #0xb50b10
    // 0xb50ac0: ldur            d1, [fp, #-0x80]
    // 0xb50ac4: fadd            d4, d3, d1
    // 0xb50ac8: fadd            d5, d4, d0
    // 0xb50acc: stur            d5, [fp, #-0x88]
    // 0xb50ad0: LoadField: r1 = r0->field_83
    //     0xb50ad0: ldur            w1, [x0, #0x83]
    // 0xb50ad4: DecompressPointer r1
    //     0xb50ad4: add             x1, x1, HEAP, lsl #32
    // 0xb50ad8: cmp             w1, NULL
    // 0xb50adc: b.ne            #0xb50af0
    // 0xb50ae0: mov             x1, x0
    // 0xb50ae4: r0 = _defaultTileHeight()
    //     0xb50ae4: bl              #0xb24da4  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_defaultTileHeight
    // 0xb50ae8: mov             v1.16b, v0.16b
    // 0xb50aec: b               #0xb50af8
    // 0xb50af0: LoadField: d0 = r1->field_7
    //     0xb50af0: ldur            d0, [x1, #7]
    // 0xb50af4: mov             v1.16b, v0.16b
    // 0xb50af8: ldur            d0, [fp, #-0x88]
    // 0xb50afc: fcmp            d0, d1
    // 0xb50b00: r16 = true
    //     0xb50b00: add             x16, NULL, #0x20  ; true
    // 0xb50b04: r17 = false
    //     0xb50b04: add             x17, NULL, #0x30  ; false
    // 0xb50b08: csel            x0, x16, x17, gt
    // 0xb50b0c: mov             x1, x0
    // 0xb50b10: ldur            x0, [fp, #-8]
    // 0xb50b14: stur            x1, [fp, #-0x18]
    // 0xb50b18: cmp             w0, NULL
    // 0xb50b1c: b.ne            #0xb50b28
    // 0xb50b20: mov             x0, x1
    // 0xb50b24: b               #0xb50b90
    // 0xb50b28: ldur            x2, [fp, #-0x58]
    // 0xb50b2c: tbnz            w2, #4, #0xb50b38
    // 0xb50b30: ldur            d0, [fp, #-0x70]
    // 0xb50b34: b               #0xb50b3c
    // 0xb50b38: ldur            d0, [fp, #-0x68]
    // 0xb50b3c: stur            d0, [fp, #-0xa0]
    // 0xb50b40: tbnz            w1, #4, #0xb50b5c
    // 0xb50b44: ldur            x3, [fp, #-0x10]
    // 0xb50b48: ldur            d1, [fp, #-0x78]
    // 0xb50b4c: LoadField: d2 = r3->field_73
    //     0xb50b4c: ldur            d2, [x3, #0x73]
    // 0xb50b50: fadd            d3, d2, d1
    // 0xb50b54: mov             v2.16b, v3.16b
    // 0xb50b58: b               #0xb50b68
    // 0xb50b5c: ldur            x3, [fp, #-0x10]
    // 0xb50b60: ldur            d1, [fp, #-0x78]
    // 0xb50b64: ldur            d2, [fp, #-0x90]
    // 0xb50b68: stur            d2, [fp, #-0x88]
    // 0xb50b6c: r0 = Offset()
    //     0xb50b6c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb50b70: ldur            d0, [fp, #-0xa0]
    // 0xb50b74: StoreField: r0->field_7 = d0
    //     0xb50b74: stur            d0, [x0, #7]
    // 0xb50b78: ldur            d0, [fp, #-0x88]
    // 0xb50b7c: StoreField: r0->field_f = d0
    //     0xb50b7c: stur            d0, [x0, #0xf]
    // 0xb50b80: ldur            x1, [fp, #-0x50]
    // 0xb50b84: mov             x2, x0
    // 0xb50b88: r0 = _positionBox()
    //     0xb50b88: bl              #0xb51138  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_positionBox
    // 0xb50b8c: ldur            x0, [fp, #-0x18]
    // 0xb50b90: tbnz            w0, #4, #0xb50bb8
    // 0xb50b94: ldur            x2, [fp, #-0x10]
    // 0xb50b98: ldur            d1, [fp, #-0x80]
    // 0xb50b9c: ldur            d0, [fp, #-0x78]
    // 0xb50ba0: d2 = 2.000000
    //     0xb50ba0: fmov            d2, #2.00000000
    // 0xb50ba4: LoadField: d3 = r2->field_73
    //     0xb50ba4: ldur            d3, [x2, #0x73]
    // 0xb50ba8: fmul            d4, d3, d2
    // 0xb50bac: fadd            d2, d4, d0
    // 0xb50bb0: fadd            d0, d2, d1
    // 0xb50bb4: b               #0xb50bc8
    // 0xb50bb8: ldur            x2, [fp, #-0x10]
    // 0xb50bbc: mov             x1, x2
    // 0xb50bc0: r0 = _targetTileHeight()
    //     0xb50bc0: bl              #0xb24ce4  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_targetTileHeight
    // 0xb50bc4: ldur            x0, [fp, #-0x18]
    // 0xb50bc8: tbnz            w0, #4, #0xb50bd8
    // 0xb50bcc: ldur            x0, [fp, #-0x10]
    // 0xb50bd0: LoadField: d1 = r0->field_73
    //     0xb50bd0: ldur            d1, [x0, #0x73]
    // 0xb50bd4: b               #0xb50be0
    // 0xb50bd8: ldur            x0, [fp, #-0x10]
    // 0xb50bdc: ldur            d1, [fp, #-0x98]
    // 0xb50be0: mov             v31.16b, v0.16b
    // 0xb50be4: mov             v0.16b, v1.16b
    // 0xb50be8: mov             v1.16b, v31.16b
    // 0xb50bec: ldur            x1, [fp, #-8]
    // 0xb50bf0: stur            d0, [fp, #-0x78]
    // 0xb50bf4: stur            d1, [fp, #-0x80]
    // 0xb50bf8: cmp             w1, NULL
    // 0xb50bfc: b.eq            #0xb50d6c
    // 0xb50c00: ldur            x3, [fp, #-0x58]
    // 0xb50c04: mov             x1, x0
    // 0xb50c08: r2 = Instance__ListTileSlot
    //     0xb50c08: add             x2, PP, #0x99, lsl #12  ; [pp+0x99358] Obj!_ListTileSlot@12c5421
    //     0xb50c0c: ldr             x2, [x2, #0x358]
    // 0xb50c10: r0 = childForSlot()
    //     0xb50c10: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb50c14: stur            x0, [fp, #-8]
    // 0xb50c18: cmp             w0, NULL
    // 0xb50c1c: b.eq            #0xb50ea0
    // 0xb50c20: ldur            x1, [fp, #-0x58]
    // 0xb50c24: tbnz            w1, #4, #0xb50c30
    // 0xb50c28: ldur            d1, [fp, #-0x70]
    // 0xb50c2c: b               #0xb50c34
    // 0xb50c30: ldur            d1, [fp, #-0x68]
    // 0xb50c34: ldur            d0, [fp, #-0x78]
    // 0xb50c38: ldur            x2, [fp, #-0x38]
    // 0xb50c3c: stur            d1, [fp, #-0x68]
    // 0xb50c40: r0 = Offset()
    //     0xb50c40: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb50c44: ldur            d0, [fp, #-0x68]
    // 0xb50c48: StoreField: r0->field_7 = d0
    //     0xb50c48: stur            d0, [x0, #7]
    // 0xb50c4c: ldur            d0, [fp, #-0x78]
    // 0xb50c50: StoreField: r0->field_f = d0
    //     0xb50c50: stur            d0, [x0, #0xf]
    // 0xb50c54: ldur            x1, [fp, #-8]
    // 0xb50c58: mov             x2, x0
    // 0xb50c5c: r0 = _positionBox()
    //     0xb50c5c: bl              #0xb51138  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_positionBox
    // 0xb50c60: ldur            x0, [fp, #-0x38]
    // 0xb50c64: cmp             w0, NULL
    // 0xb50c68: b.eq            #0xb50ce8
    // 0xb50c6c: ldur            x1, [fp, #-0x48]
    // 0xb50c70: cmp             w1, NULL
    // 0xb50c74: b.eq            #0xb50ce8
    // 0xb50c78: ldur            x4, [fp, #-0x58]
    // 0xb50c7c: tbnz            w4, #4, #0xb50c8c
    // 0xb50c80: ldur            d2, [fp, #-0x60]
    // 0xb50c84: d3 = 0.000000
    //     0xb50c84: eor             v3.16b, v3.16b, v3.16b
    // 0xb50c88: b               #0xb50c9c
    // 0xb50c8c: ldur            d2, [fp, #-0x60]
    // 0xb50c90: LoadField: d0 = r1->field_7
    //     0xb50c90: ldur            d0, [x1, #7]
    // 0xb50c94: fsub            d1, d2, d0
    // 0xb50c98: mov             v3.16b, v1.16b
    // 0xb50c9c: ldur            x5, [fp, #-0x10]
    // 0xb50ca0: stur            d3, [fp, #-0x68]
    // 0xb50ca4: LoadField: r2 = r5->field_87
    //     0xb50ca4: ldur            w2, [x5, #0x87]
    // 0xb50ca8: DecompressPointer r2
    //     0xb50ca8: add             x2, x2, HEAP, lsl #32
    // 0xb50cac: LoadField: d0 = r1->field_f
    //     0xb50cac: ldur            d0, [x1, #0xf]
    // 0xb50cb0: mov             x1, x2
    // 0xb50cb4: ldur            d1, [fp, #-0x80]
    // 0xb50cb8: mov             x2, x5
    // 0xb50cbc: r3 = true
    //     0xb50cbc: add             x3, NULL, #0x20  ; true
    // 0xb50cc0: r0 = _yOffsetFor()
    //     0xb50cc0: bl              #0xb50ef4  ; [package:flutter/src/material/list_tile.dart] ListTileTitleAlignment::_yOffsetFor
    // 0xb50cc4: stur            d0, [fp, #-0x70]
    // 0xb50cc8: r0 = Offset()
    //     0xb50cc8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb50ccc: ldur            d0, [fp, #-0x68]
    // 0xb50cd0: StoreField: r0->field_7 = d0
    //     0xb50cd0: stur            d0, [x0, #7]
    // 0xb50cd4: ldur            d0, [fp, #-0x70]
    // 0xb50cd8: StoreField: r0->field_f = d0
    //     0xb50cd8: stur            d0, [x0, #0xf]
    // 0xb50cdc: ldur            x1, [fp, #-0x38]
    // 0xb50ce0: mov             x2, x0
    // 0xb50ce4: r0 = _positionBox()
    //     0xb50ce4: bl              #0xb51138  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_positionBox
    // 0xb50ce8: ldur            x0, [fp, #-0x40]
    // 0xb50cec: cmp             w0, NULL
    // 0xb50cf0: b.eq            #0xb50d6c
    // 0xb50cf4: ldur            x1, [fp, #-0x30]
    // 0xb50cf8: cmp             w1, NULL
    // 0xb50cfc: b.eq            #0xb50d6c
    // 0xb50d00: ldur            x2, [fp, #-0x58]
    // 0xb50d04: tbnz            w2, #4, #0xb50d1c
    // 0xb50d08: ldur            d2, [fp, #-0x60]
    // 0xb50d0c: LoadField: d0 = r1->field_7
    //     0xb50d0c: ldur            d0, [x1, #7]
    // 0xb50d10: fsub            d1, d2, d0
    // 0xb50d14: mov             v3.16b, v1.16b
    // 0xb50d18: b               #0xb50d24
    // 0xb50d1c: ldur            d2, [fp, #-0x60]
    // 0xb50d20: d3 = 0.000000
    //     0xb50d20: eor             v3.16b, v3.16b, v3.16b
    // 0xb50d24: ldur            x2, [fp, #-0x10]
    // 0xb50d28: stur            d3, [fp, #-0x68]
    // 0xb50d2c: LoadField: r3 = r2->field_87
    //     0xb50d2c: ldur            w3, [x2, #0x87]
    // 0xb50d30: DecompressPointer r3
    //     0xb50d30: add             x3, x3, HEAP, lsl #32
    // 0xb50d34: LoadField: d0 = r1->field_f
    //     0xb50d34: ldur            d0, [x1, #0xf]
    // 0xb50d38: mov             x1, x3
    // 0xb50d3c: ldur            d1, [fp, #-0x80]
    // 0xb50d40: r3 = false
    //     0xb50d40: add             x3, NULL, #0x30  ; false
    // 0xb50d44: r0 = _yOffsetFor()
    //     0xb50d44: bl              #0xb50ef4  ; [package:flutter/src/material/list_tile.dart] ListTileTitleAlignment::_yOffsetFor
    // 0xb50d48: stur            d0, [fp, #-0x70]
    // 0xb50d4c: r0 = Offset()
    //     0xb50d4c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb50d50: ldur            d0, [fp, #-0x68]
    // 0xb50d54: StoreField: r0->field_7 = d0
    //     0xb50d54: stur            d0, [x0, #7]
    // 0xb50d58: ldur            d0, [fp, #-0x70]
    // 0xb50d5c: StoreField: r0->field_f = d0
    //     0xb50d5c: stur            d0, [x0, #0xf]
    // 0xb50d60: ldur            x1, [fp, #-0x40]
    // 0xb50d64: mov             x2, x0
    // 0xb50d68: r0 = _positionBox()
    //     0xb50d68: bl              #0xb51138  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_positionBox
    // 0xb50d6c: ldur            d0, [fp, #-0x60]
    // 0xb50d70: ldur            d1, [fp, #-0x78]
    // 0xb50d74: ldur            d2, [fp, #-0x80]
    // 0xb50d78: r0 = Size()
    //     0xb50d78: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb50d7c: ldur            d0, [fp, #-0x60]
    // 0xb50d80: StoreField: r0->field_7 = d0
    //     0xb50d80: stur            d0, [x0, #7]
    // 0xb50d84: ldur            d0, [fp, #-0x80]
    // 0xb50d88: StoreField: r0->field_f = d0
    //     0xb50d88: stur            d0, [x0, #0xf]
    // 0xb50d8c: ldur            d0, [fp, #-0x78]
    // 0xb50d90: r4 = inline_Allocate_Double()
    //     0xb50d90: ldp             x4, x1, [THR, #0x60]  ; THR::top
    //     0xb50d94: add             x4, x4, #0x10
    //     0xb50d98: cmp             x1, x4
    //     0xb50d9c: b.ls            #0xb50ea4
    //     0xb50da0: str             x4, [THR, #0x60]  ; THR::top
    //     0xb50da4: sub             x4, x4, #0xf
    //     0xb50da8: mov             x1, #0xe19c
    //     0xb50dac: movk            x1, #3, lsl #16
    //     0xb50db0: stur            x1, [x4, #-1]
    // 0xb50db4: dmb             ishst
    // 0xb50db8: StoreField: r4->field_7 = d0
    //     0xb50db8: stur            d0, [x4, #7]
    // 0xb50dbc: ldur            x2, [fp, #-0x28]
    // 0xb50dc0: mov             x3, x0
    // 0xb50dc4: r1 = 524294
    //     0xb50dc4: mov             x1, #6
    //     0xb50dc8: movk            x1, #8, lsl #16
    // 0xb50dcc: r0 = AllocateRecord3Named()
    //     0xb50dcc: bl              #0x13de334  ; AllocateRecord3NamedStub
    // 0xb50dd0: LeaveFrame
    //     0xb50dd0: mov             SP, fp
    //     0xb50dd4: ldp             fp, lr, [SP], #0x10
    // 0xb50dd8: ret
    //     0xb50dd8: ret             
    // 0xb50ddc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb50ddc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb50de0: b               #0xb504fc
    // 0xb50de4: stp             q2, q4, [SP, #-0x20]!
    // 0xb50de8: stp             q0, q1, [SP, #-0x20]!
    // 0xb50dec: SaveReg r0
    //     0xb50dec: str             x0, [SP, #-8]!
    // 0xb50df0: r0 = AllocateDouble()
    //     0xb50df0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb50df4: mov             x1, x0
    // 0xb50df8: RestoreReg r0
    //     0xb50df8: ldr             x0, [SP], #8
    // 0xb50dfc: ldp             q0, q1, [SP], #0x20
    // 0xb50e00: ldp             q2, q4, [SP], #0x20
    // 0xb50e04: b               #0xb506a4
    // 0xb50e08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb50e08: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb50e0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb50e0c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb50e10: SaveReg d0
    //     0xb50e10: str             q0, [SP, #-0x10]!
    // 0xb50e14: r0 = AllocateDouble()
    //     0xb50e14: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb50e18: RestoreReg d0
    //     0xb50e18: ldr             q0, [SP], #0x10
    // 0xb50e1c: b               #0xb50848
    // 0xb50e20: SaveReg d0
    //     0xb50e20: str             q0, [SP, #-0x10]!
    // 0xb50e24: r0 = AllocateDouble()
    //     0xb50e24: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb50e28: RestoreReg d0
    //     0xb50e28: ldr             q0, [SP], #0x10
    // 0xb50e2c: b               #0xb508c4
    // 0xb50e30: stp             q0, q1, [SP, #-0x20]!
    // 0xb50e34: stp             x0, x1, [SP, #-0x10]!
    // 0xb50e38: r0 = AllocateDouble()
    //     0xb50e38: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb50e3c: mov             x2, x0
    // 0xb50e40: ldp             x0, x1, [SP], #0x10
    // 0xb50e44: ldp             q0, q1, [SP], #0x20
    // 0xb50e48: b               #0xb5091c
    // 0xb50e4c: stp             q1, q3, [SP, #-0x20]!
    // 0xb50e50: SaveReg d0
    //     0xb50e50: str             q0, [SP, #-0x10]!
    // 0xb50e54: stp             x0, x1, [SP, #-0x10]!
    // 0xb50e58: r0 = AllocateDouble()
    //     0xb50e58: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb50e5c: mov             x2, x0
    // 0xb50e60: ldp             x0, x1, [SP], #0x10
    // 0xb50e64: RestoreReg d0
    //     0xb50e64: ldr             q0, [SP], #0x10
    // 0xb50e68: ldp             q1, q3, [SP], #0x20
    // 0xb50e6c: b               #0xb50994
    // 0xb50e70: stp             q3, q4, [SP, #-0x20]!
    // 0xb50e74: stp             q0, q1, [SP, #-0x20]!
    // 0xb50e78: r0 = AllocateDouble()
    //     0xb50e78: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb50e7c: ldp             q0, q1, [SP], #0x20
    // 0xb50e80: ldp             q3, q4, [SP], #0x20
    // 0xb50e84: b               #0xb509fc
    // 0xb50e88: stp             q3, q4, [SP, #-0x20]!
    // 0xb50e8c: stp             q0, q1, [SP, #-0x20]!
    // 0xb50e90: r0 = AllocateDouble()
    //     0xb50e90: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb50e94: ldp             q0, q1, [SP], #0x20
    // 0xb50e98: ldp             q3, q4, [SP], #0x20
    // 0xb50e9c: b               #0xb50a5c
    // 0xb50ea0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb50ea0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb50ea4: SaveReg d0
    //     0xb50ea4: str             q0, [SP, #-0x10]!
    // 0xb50ea8: SaveReg r0
    //     0xb50ea8: str             x0, [SP, #-8]!
    // 0xb50eac: r0 = AllocateDouble()
    //     0xb50eac: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb50eb0: mov             x4, x0
    // 0xb50eb4: RestoreReg r0
    //     0xb50eb4: ldr             x0, [SP], #8
    // 0xb50eb8: RestoreReg d0
    //     0xb50eb8: ldr             q0, [SP], #0x10
    // 0xb50ebc: b               #0xb50db8
  }
  [closure] static void _positionBox(dynamic, RenderBox, Offset) {
    // ** addr: 0xb50ec0, size: 0x34
    // 0xb50ec0: EnterFrame
    //     0xb50ec0: stp             fp, lr, [SP, #-0x10]!
    //     0xb50ec4: mov             fp, SP
    // 0xb50ec8: CheckStackOverflow
    //     0xb50ec8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb50ecc: cmp             SP, x16
    //     0xb50ed0: b.ls            #0xb50eec
    // 0xb50ed4: ldr             x1, [fp, #0x18]
    // 0xb50ed8: ldr             x2, [fp, #0x10]
    // 0xb50edc: r0 = _positionBox()
    //     0xb50edc: bl              #0xb51138  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_positionBox
    // 0xb50ee0: LeaveFrame
    //     0xb50ee0: mov             SP, fp
    //     0xb50ee4: ldp             fp, lr, [SP], #0x10
    // 0xb50ee8: ret
    //     0xb50ee8: ret             
    // 0xb50eec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb50eec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb50ef0: b               #0xb50ed4
  }
  static _ _positionBox(/* No info */) {
    // ** addr: 0xb51138, size: 0x98
    // 0xb51138: EnterFrame
    //     0xb51138: stp             fp, lr, [SP, #-0x10]!
    //     0xb5113c: mov             fp, SP
    // 0xb51140: AllocStack(0x10)
    //     0xb51140: sub             SP, SP, #0x10
    // 0xb51144: SetupParameters(dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xb51144: mov             x3, x2
    //     0xb51148: stur            x2, [fp, #-0x10]
    // 0xb5114c: LoadField: r4 = r1->field_7
    //     0xb5114c: ldur            w4, [x1, #7]
    // 0xb51150: DecompressPointer r4
    //     0xb51150: add             x4, x4, HEAP, lsl #32
    // 0xb51154: stur            x4, [fp, #-8]
    // 0xb51158: cmp             w4, NULL
    // 0xb5115c: b.eq            #0xb511cc
    // 0xb51160: mov             x0, x4
    // 0xb51164: r2 = Null
    //     0xb51164: mov             x2, NULL
    // 0xb51168: r1 = Null
    //     0xb51168: mov             x1, NULL
    // 0xb5116c: r4 = LoadClassIdInstr(r0)
    //     0xb5116c: ldur            x4, [x0, #-1]
    //     0xb51170: ubfx            x4, x4, #0xc, #0x14
    // 0xb51174: r17 = -4190
    //     0xb51174: mov             x17, #-0x105e
    // 0xb51178: add             x4, x4, x17
    // 0xb5117c: cmp             x4, #0x17
    // 0xb51180: b.ls            #0xb51198
    // 0xb51184: r8 = BoxParentData
    //     0xb51184: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0xb51188: ldr             x8, [x8, #0x5e8]
    // 0xb5118c: r3 = Null
    //     0xb5118c: add             x3, PP, #0x99, lsl #12  ; [pp+0x99398] Null
    //     0xb51190: ldr             x3, [x3, #0x398]
    // 0xb51194: r0 = DefaultTypeTest()
    //     0xb51194: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb51198: ldur            x0, [fp, #-0x10]
    // 0xb5119c: ldur            x1, [fp, #-8]
    // 0xb511a0: StoreField: r1->field_7 = r0
    //     0xb511a0: stur            w0, [x1, #7]
    //     0xb511a4: ldurb           w16, [x1, #-1]
    //     0xb511a8: ldurb           w17, [x0, #-1]
    //     0xb511ac: and             x16, x17, x16, lsr #2
    //     0xb511b0: tst             x16, HEAP, lsr #32
    //     0xb511b4: b.eq            #0xb511bc
    //     0xb511b8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb511bc: r0 = Null
    //     0xb511bc: mov             x0, NULL
    // 0xb511c0: LeaveFrame
    //     0xb511c0: mov             SP, fp
    //     0xb511c4: ldp             fp, lr, [SP], #0x10
    // 0xb511c8: ret
    //     0xb511c8: ret             
    // 0xb511cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb511cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _effectiveHorizontalTitleGap(/* No info */) {
    // ** addr: 0xb511d0, size: 0x20
    // 0xb511d0: d1 = 2.000000
    //     0xb511d0: fmov            d1, #2.00000000
    // 0xb511d4: LoadField: d2 = r1->field_6b
    //     0xb511d4: ldur            d2, [x1, #0x6b]
    // 0xb511d8: LoadField: r0 = r1->field_57
    //     0xb511d8: ldur            w0, [x1, #0x57]
    // 0xb511dc: DecompressPointer r0
    //     0xb511dc: add             x0, x0, HEAP, lsl #32
    // 0xb511e0: LoadField: d3 = r0->field_7
    //     0xb511e0: ldur            d3, [x0, #7]
    // 0xb511e4: fmul            d4, d3, d1
    // 0xb511e8: fadd            d0, d2, d4
    // 0xb511ec: ret
    //     0xb511ec: ret             
  }
  get _ maxIconHeightConstraint(/* No info */) {
    // ** addr: 0xb511f0, size: 0x88
    // 0xb511f0: EnterFrame
    //     0xb511f0: stp             fp, lr, [SP, #-0x10]!
    //     0xb511f4: mov             fp, SP
    // 0xb511f8: AllocStack(0x10)
    //     0xb511f8: sub             SP, SP, #0x10
    // 0xb511fc: CheckStackOverflow
    //     0xb511fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb51200: cmp             SP, x16
    //     0xb51204: b.ls            #0xb51270
    // 0xb51208: LoadField: r0 = r1->field_53
    //     0xb51208: ldur            w0, [x1, #0x53]
    // 0xb5120c: DecompressPointer r0
    //     0xb5120c: add             x0, x0, HEAP, lsl #32
    // 0xb51210: tbnz            w0, #4, #0xb5121c
    // 0xb51214: d0 = 48.000000
    //     0xb51214: ldr             d0, [PP, #0x5650]  ; [pp+0x5650] IMM: double(48) from 0x4048000000000000
    // 0xb51218: b               #0xb51224
    // 0xb5121c: d0 = 56.000000
    //     0xb5121c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a70] IMM: double(56) from 0x404c000000000000
    //     0xb51220: ldr             d0, [x17, #0xa70]
    // 0xb51224: stur            d0, [fp, #-8]
    // 0xb51228: LoadField: r0 = r1->field_57
    //     0xb51228: ldur            w0, [x1, #0x57]
    // 0xb5122c: DecompressPointer r0
    //     0xb5122c: add             x0, x0, HEAP, lsl #32
    // 0xb51230: mov             x1, x0
    // 0xb51234: r0 = baseSizeAdjustment()
    //     0xb51234: bl              #0xb2496c  ; [package:flutter/src/material/theme_data.dart] VisualDensity::baseSizeAdjustment
    // 0xb51238: LoadField: d0 = r0->field_f
    //     0xb51238: ldur            d0, [x0, #0xf]
    // 0xb5123c: ldur            d1, [fp, #-8]
    // 0xb51240: fadd            d2, d1, d0
    // 0xb51244: stur            d2, [fp, #-0x10]
    // 0xb51248: r0 = BoxConstraints()
    //     0xb51248: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb5124c: StoreField: r0->field_7 = rZR
    //     0xb5124c: stur            xzr, [x0, #7]
    // 0xb51250: d0 = inf
    //     0xb51250: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb51254: StoreField: r0->field_f = d0
    //     0xb51254: stur            d0, [x0, #0xf]
    // 0xb51258: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb51258: stur            xzr, [x0, #0x17]
    // 0xb5125c: ldur            d0, [fp, #-0x10]
    // 0xb51260: StoreField: r0->field_1f = d0
    //     0xb51260: stur            d0, [x0, #0x1f]
    // 0xb51264: LeaveFrame
    //     0xb51264: mov             SP, fp
    //     0xb51268: ldp             fp, lr, [SP], #0x10
    // 0xb5126c: ret
    //     0xb5126c: ret             
    // 0xb51270: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb51270: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb51274: b               #0xb51208
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb585c4, size: 0x24
    // 0xb585c4: EnterFrame
    //     0xb585c4: stp             fp, lr, [SP, #-0x10]!
    //     0xb585c8: mov             fp, SP
    // 0xb585cc: ldr             x2, [fp, #0x10]
    // 0xb585d0: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb585d0: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3b58] AnonymousClosure: (0xb2e1e4), in [package:flutter/src/material/list_tile.dart] _RenderListTile::computeMaxIntrinsicWidth (0xb2e088)
    //     0xb585d4: ldr             x1, [x1, #0xb58]
    // 0xb585d8: r0 = AllocateClosure()
    //     0xb585d8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb585dc: LeaveFrame
    //     0xb585dc: mov             SP, fp
    //     0xb585e0: ldp             fp, lr, [SP], #0x10
    // 0xb585e4: ret
    //     0xb585e4: ret             
  }
  _ computeDistanceToActualBaseline(/* No info */) {
    // ** addr: 0xb5af5c, size: 0xe8
    // 0xb5af5c: EnterFrame
    //     0xb5af5c: stp             fp, lr, [SP, #-0x10]!
    //     0xb5af60: mov             fp, SP
    // 0xb5af64: AllocStack(0x18)
    //     0xb5af64: sub             SP, SP, #0x18
    // 0xb5af68: SetupParameters(_RenderListTile this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb5af68: mov             x3, x1
    //     0xb5af6c: mov             x0, x2
    //     0xb5af70: stur            x1, [fp, #-8]
    //     0xb5af74: stur            x2, [fp, #-0x10]
    // 0xb5af78: CheckStackOverflow
    //     0xb5af78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5af7c: cmp             SP, x16
    //     0xb5af80: b.ls            #0xb5b030
    // 0xb5af84: mov             x1, x3
    // 0xb5af88: r2 = Instance__ListTileSlot
    //     0xb5af88: add             x2, PP, #0x99, lsl #12  ; [pp+0x99358] Obj!_ListTileSlot@12c5421
    //     0xb5af8c: ldr             x2, [x2, #0x358]
    // 0xb5af90: r0 = childForSlot()
    //     0xb5af90: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb5af94: cmp             w0, NULL
    // 0xb5af98: b.eq            #0xb5b038
    // 0xb5af9c: LoadField: r3 = r0->field_7
    //     0xb5af9c: ldur            w3, [x0, #7]
    // 0xb5afa0: DecompressPointer r3
    //     0xb5afa0: add             x3, x3, HEAP, lsl #32
    // 0xb5afa4: stur            x3, [fp, #-0x18]
    // 0xb5afa8: cmp             w3, NULL
    // 0xb5afac: b.eq            #0xb5b03c
    // 0xb5afb0: mov             x0, x3
    // 0xb5afb4: r2 = Null
    //     0xb5afb4: mov             x2, NULL
    // 0xb5afb8: r1 = Null
    //     0xb5afb8: mov             x1, NULL
    // 0xb5afbc: r4 = LoadClassIdInstr(r0)
    //     0xb5afbc: ldur            x4, [x0, #-1]
    //     0xb5afc0: ubfx            x4, x4, #0xc, #0x14
    // 0xb5afc4: r17 = -4190
    //     0xb5afc4: mov             x17, #-0x105e
    // 0xb5afc8: add             x4, x4, x17
    // 0xb5afcc: cmp             x4, #0x17
    // 0xb5afd0: b.ls            #0xb5afe8
    // 0xb5afd4: r8 = BoxParentData
    //     0xb5afd4: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0xb5afd8: ldr             x8, [x8, #0x5e8]
    // 0xb5afdc: r3 = Null
    //     0xb5afdc: add             x3, PP, #0x99, lsl #12  ; [pp+0x993d8] Null
    //     0xb5afe0: ldr             x3, [x3, #0x3d8]
    // 0xb5afe4: r0 = DefaultTypeTest()
    //     0xb5afe4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb5afe8: ldur            x1, [fp, #-8]
    // 0xb5afec: r2 = Instance__ListTileSlot
    //     0xb5afec: add             x2, PP, #0x99, lsl #12  ; [pp+0x99358] Obj!_ListTileSlot@12c5421
    //     0xb5aff0: ldr             x2, [x2, #0x358]
    // 0xb5aff4: r0 = childForSlot()
    //     0xb5aff4: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb5aff8: cmp             w0, NULL
    // 0xb5affc: b.eq            #0xb5b040
    // 0xb5b000: mov             x1, x0
    // 0xb5b004: ldur            x2, [fp, #-0x10]
    // 0xb5b008: r0 = getDistanceToActualBaseline()
    //     0xb5b008: bl              #0xb53d74  ; [package:flutter/src/rendering/box.dart] RenderBox::getDistanceToActualBaseline
    // 0xb5b00c: mov             x1, x0
    // 0xb5b010: ldur            x0, [fp, #-0x18]
    // 0xb5b014: LoadField: r2 = r0->field_7
    //     0xb5b014: ldur            w2, [x0, #7]
    // 0xb5b018: DecompressPointer r2
    //     0xb5b018: add             x2, x2, HEAP, lsl #32
    // 0xb5b01c: LoadField: d0 = r2->field_f
    //     0xb5b01c: ldur            d0, [x2, #0xf]
    // 0xb5b020: r0 = BaselineOffset.+()
    //     0xb5b020: bl              #0xb5b044  ; [package:flutter/src/rendering/box.dart] ::BaselineOffset.+
    // 0xb5b024: LeaveFrame
    //     0xb5b024: mov             SP, fp
    //     0xb5b028: ldp             fp, lr, [SP], #0x10
    // 0xb5b02c: ret
    //     0xb5b02c: ret             
    // 0xb5b030: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5b030: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5b034: b               #0xb5af84
    // 0xb5b038: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb5b038: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb5b03c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb5b03c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb5b040: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb5b040: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e770, size: 0x24
    // 0xb5e770: EnterFrame
    //     0xb5e770: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e774: mov             fp, SP
    // 0xb5e778: ldr             x2, [fp, #0x10]
    // 0xb5e77c: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e77c: add             x1, PP, #0x99, lsl #12  ; [pp+0x992e8] AnonymousClosure: (0xb2c660), in [package:flutter/src/rendering/table.dart] RenderTable::computeMaxIntrinsicHeight (0xb2c630)
    //     0xb5e780: ldr             x1, [x1, #0x2e8]
    // 0xb5e784: r0 = AllocateClosure()
    //     0xb5e784: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e788: LeaveFrame
    //     0xb5e788: mov             SP, fp
    //     0xb5e78c: ldp             fp, lr, [SP], #0x10
    // 0xb5e790: ret
    //     0xb5e790: ret             
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb63900, size: 0xe8
    // 0xb63900: EnterFrame
    //     0xb63900: stp             fp, lr, [SP, #-0x10]!
    //     0xb63904: mov             fp, SP
    // 0xb63908: AllocStack(0x18)
    //     0xb63908: sub             SP, SP, #0x18
    // 0xb6390c: SetupParameters(_RenderListTile this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb6390c: mov             x5, x1
    //     0xb63910: mov             x4, x2
    //     0xb63914: stur            x1, [fp, #-8]
    //     0xb63918: stur            x2, [fp, #-0x10]
    //     0xb6391c: stur            x3, [fp, #-0x18]
    // 0xb63920: CheckStackOverflow
    //     0xb63920: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb63924: cmp             SP, x16
    //     0xb63928: b.ls            #0xb639dc
    // 0xb6392c: mov             x0, x4
    // 0xb63930: r2 = Null
    //     0xb63930: mov             x2, NULL
    // 0xb63934: r1 = Null
    //     0xb63934: mov             x1, NULL
    // 0xb63938: r4 = 60
    //     0xb63938: mov             x4, #0x3c
    // 0xb6393c: branchIfSmi(r0, 0xb63948)
    //     0xb6393c: tbz             w0, #0, #0xb63948
    // 0xb63940: r4 = LoadClassIdInstr(r0)
    //     0xb63940: ldur            x4, [x0, #-1]
    //     0xb63944: ubfx            x4, x4, #0xc, #0x14
    // 0xb63948: sub             x4, x4, #0xb46
    // 0xb6394c: cmp             x4, #1
    // 0xb63950: b.ls            #0xb63964
    // 0xb63954: r8 = BoxConstraints
    //     0xb63954: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb63958: r3 = Null
    //     0xb63958: add             x3, PP, #0x99, lsl #12  ; [pp+0x993c8] Null
    //     0xb6395c: ldr             x3, [x3, #0x3c8]
    // 0xb63960: r0 = BoxConstraints()
    //     0xb63960: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb63964: ldur            x1, [fp, #-8]
    // 0xb63968: ldur            x5, [fp, #-0x10]
    // 0xb6396c: r2 = Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static.
    //     0xb6396c: add             x2, PP, #0x90, lsl #12  ; [pp+0x90860] Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static. (0x7f2adaa00640)
    //     0xb63970: ldr             x2, [x2, #0x860]
    // 0xb63974: r3 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xb63974: add             x3, PP, #0x90, lsl #12  ; [pp+0x90700] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7f2adaa12214)
    //     0xb63978: ldr             x3, [x3, #0x700]
    // 0xb6397c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xb6397c: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xb63980: r0 = _computeSizes()
    //     0xb63980: bl              #0xb5048c  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_computeSizes
    // 0xb63984: ldur            x1, [fp, #-8]
    // 0xb63988: r2 = Instance__ListTileSlot
    //     0xb63988: add             x2, PP, #0x99, lsl #12  ; [pp+0x99358] Obj!_ListTileSlot@12c5421
    //     0xb6398c: ldr             x2, [x2, #0x358]
    // 0xb63990: stur            x0, [fp, #-8]
    // 0xb63994: r0 = childForSlot()
    //     0xb63994: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0xb63998: cmp             w0, NULL
    // 0xb6399c: b.eq            #0xb639e4
    // 0xb639a0: ldur            x4, [fp, #-8]
    // 0xb639a4: LoadField: r2 = r4->field_f
    //     0xb639a4: ldur            w2, [x4, #0xf]
    // 0xb639a8: DecompressPointer r2
    //     0xb639a8: add             x2, x2, HEAP, lsl #32
    // 0xb639ac: mov             x1, x0
    // 0xb639b0: ldur            x3, [fp, #-0x18]
    // 0xb639b4: r0 = getDryBaseline()
    //     0xb639b4: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb639b8: mov             x1, x0
    // 0xb639bc: ldur            x0, [fp, #-8]
    // 0xb639c0: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xb639c0: ldur            w2, [x0, #0x17]
    // 0xb639c4: DecompressPointer r2
    //     0xb639c4: add             x2, x2, HEAP, lsl #32
    // 0xb639c8: LoadField: d0 = r2->field_7
    //     0xb639c8: ldur            d0, [x2, #7]
    // 0xb639cc: r0 = BaselineOffset.+()
    //     0xb639cc: bl              #0xb5b044  ; [package:flutter/src/rendering/box.dart] ::BaselineOffset.+
    // 0xb639d0: LeaveFrame
    //     0xb639d0: mov             SP, fp
    //     0xb639d4: ldp             fp, lr, [SP], #0x10
    // 0xb639d8: ret
    //     0xb639d8: ret             
    // 0xb639dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb639dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb639e0: b               #0xb6392c
    // 0xb639e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb639e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbc26fc, size: 0x168
    // 0xbc26fc: EnterFrame
    //     0xbc26fc: stp             fp, lr, [SP, #-0x10]!
    //     0xbc2700: mov             fp, SP
    // 0xbc2704: AllocStack(0x20)
    //     0xbc2704: sub             SP, SP, #0x20
    // 0xbc2708: SetupParameters(_RenderListTile this /* r1 => r3, fp-0x10 */)
    //     0xbc2708: mov             x3, x1
    //     0xbc270c: stur            x1, [fp, #-0x10]
    // 0xbc2710: CheckStackOverflow
    //     0xbc2710: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc2714: cmp             SP, x16
    //     0xbc2718: b.ls            #0xbc285c
    // 0xbc271c: LoadField: r4 = r3->field_27
    //     0xbc271c: ldur            w4, [x3, #0x27]
    // 0xbc2720: DecompressPointer r4
    //     0xbc2720: add             x4, x4, HEAP, lsl #32
    // 0xbc2724: stur            x4, [fp, #-8]
    // 0xbc2728: cmp             w4, NULL
    // 0xbc272c: b.eq            #0xbc2820
    // 0xbc2730: mov             x0, x4
    // 0xbc2734: r2 = Null
    //     0xbc2734: mov             x2, NULL
    // 0xbc2738: r1 = Null
    //     0xbc2738: mov             x1, NULL
    // 0xbc273c: r4 = LoadClassIdInstr(r0)
    //     0xbc273c: ldur            x4, [x0, #-1]
    //     0xbc2740: ubfx            x4, x4, #0xc, #0x14
    // 0xbc2744: sub             x4, x4, #0xb46
    // 0xbc2748: cmp             x4, #1
    // 0xbc274c: b.ls            #0xbc2760
    // 0xbc2750: r8 = BoxConstraints
    //     0xbc2750: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbc2754: r3 = Null
    //     0xbc2754: add             x3, PP, #0x99, lsl #12  ; [pp+0x99368] Null
    //     0xbc2758: ldr             x3, [x3, #0x368]
    // 0xbc275c: r0 = BoxConstraints()
    //     0xbc275c: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbc2760: r16 = Closure: (RenderBox, Offset) => void from Function '_positionBox@97247952': static.
    //     0xbc2760: add             x16, PP, #0x99, lsl #12  ; [pp+0x99378] Closure: (RenderBox, Offset) => void from Function '_positionBox@97247952': static. (0x7f2adaa37ec0)
    //     0xbc2764: ldr             x16, [x16, #0x378]
    // 0xbc2768: str             x16, [SP]
    // 0xbc276c: ldur            x1, [fp, #-0x10]
    // 0xbc2770: ldur            x5, [fp, #-8]
    // 0xbc2774: r2 = Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getBaseline': static.
    //     0xbc2774: add             x2, PP, #0x90, lsl #12  ; [pp+0x90750] Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getBaseline': static. (0x7f2adaaa6ca0)
    //     0xbc2778: ldr             x2, [x2, #0x750]
    // 0xbc277c: r3 = Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static.
    //     0xbc277c: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e4f8] Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static. (0x7f2adaa34e18)
    //     0xbc2780: ldr             x3, [x3, #0x4f8]
    // 0xbc2784: r4 = const [0, 0x5, 0x1, 0x4, positionChild, 0x4, null]
    //     0xbc2784: add             x4, PP, #0x99, lsl #12  ; [pp+0x99380] List(7) [0, 0x5, 0x1, 0x4, "positionChild", 0x4, Null]
    //     0xbc2788: ldr             x4, [x4, #0x380]
    // 0xbc278c: r0 = _computeSizes()
    //     0xbc278c: bl              #0xb5048c  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_computeSizes
    // 0xbc2790: LoadField: r3 = r0->field_13
    //     0xbc2790: ldur            w3, [x0, #0x13]
    // 0xbc2794: DecompressPointer r3
    //     0xbc2794: add             x3, x3, HEAP, lsl #32
    // 0xbc2798: ldur            x4, [fp, #-0x10]
    // 0xbc279c: stur            x3, [fp, #-0x18]
    // 0xbc27a0: LoadField: r5 = r4->field_27
    //     0xbc27a0: ldur            w5, [x4, #0x27]
    // 0xbc27a4: DecompressPointer r5
    //     0xbc27a4: add             x5, x5, HEAP, lsl #32
    // 0xbc27a8: stur            x5, [fp, #-8]
    // 0xbc27ac: cmp             w5, NULL
    // 0xbc27b0: b.eq            #0xbc283c
    // 0xbc27b4: mov             x0, x5
    // 0xbc27b8: r2 = Null
    //     0xbc27b8: mov             x2, NULL
    // 0xbc27bc: r1 = Null
    //     0xbc27bc: mov             x1, NULL
    // 0xbc27c0: r4 = LoadClassIdInstr(r0)
    //     0xbc27c0: ldur            x4, [x0, #-1]
    //     0xbc27c4: ubfx            x4, x4, #0xc, #0x14
    // 0xbc27c8: sub             x4, x4, #0xb46
    // 0xbc27cc: cmp             x4, #1
    // 0xbc27d0: b.ls            #0xbc27e4
    // 0xbc27d4: r8 = BoxConstraints
    //     0xbc27d4: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbc27d8: r3 = Null
    //     0xbc27d8: add             x3, PP, #0x99, lsl #12  ; [pp+0x99388] Null
    //     0xbc27dc: ldr             x3, [x3, #0x388]
    // 0xbc27e0: r0 = BoxConstraints()
    //     0xbc27e0: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbc27e4: ldur            x1, [fp, #-8]
    // 0xbc27e8: ldur            x2, [fp, #-0x18]
    // 0xbc27ec: r0 = constrain()
    //     0xbc27ec: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbc27f0: ldur            x1, [fp, #-0x10]
    // 0xbc27f4: StoreField: r1->field_4b = r0
    //     0xbc27f4: stur            w0, [x1, #0x4b]
    //     0xbc27f8: ldurb           w16, [x1, #-1]
    //     0xbc27fc: ldurb           w17, [x0, #-1]
    //     0xbc2800: and             x16, x17, x16, lsr #2
    //     0xbc2804: tst             x16, HEAP, lsr #32
    //     0xbc2808: b.eq            #0xbc2810
    //     0xbc280c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc2810: r0 = Null
    //     0xbc2810: mov             x0, NULL
    // 0xbc2814: LeaveFrame
    //     0xbc2814: mov             SP, fp
    //     0xbc2818: ldp             fp, lr, [SP], #0x10
    // 0xbc281c: ret
    //     0xbc281c: ret             
    // 0xbc2820: r0 = StateError()
    //     0xbc2820: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc2824: mov             x1, x0
    // 0xbc2828: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbc2828: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbc282c: StoreField: r1->field_b = r0
    //     0xbc282c: stur            w0, [x1, #0xb]
    // 0xbc2830: mov             x0, x1
    // 0xbc2834: r0 = Throw()
    //     0xbc2834: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc2838: brk             #0
    // 0xbc283c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbc283c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbc2840: r0 = StateError()
    //     0xbc2840: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc2844: mov             x1, x0
    // 0xbc2848: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbc2848: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbc284c: StoreField: r1->field_b = r0
    //     0xbc284c: stur            w0, [x1, #0xb]
    // 0xbc2850: mov             x0, x1
    // 0xbc2854: r0 = Throw()
    //     0xbc2854: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc2858: brk             #0
    // 0xbc285c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc285c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc2860: b               #0xbc271c
  }
  _ paint(/* No info */) {
    // ** addr: 0xc2242c, size: 0x270
    // 0xc2242c: EnterFrame
    //     0xc2242c: stp             fp, lr, [SP, #-0x10]!
    //     0xc22430: mov             fp, SP
    // 0xc22434: AllocStack(0x28)
    //     0xc22434: sub             SP, SP, #0x28
    // 0xc22438: SetupParameters(_RenderListTile this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xc22438: mov             x0, x2
    //     0xc2243c: stur            x2, [fp, #-0x10]
    //     0xc22440: mov             x2, x3
    //     0xc22444: stur            x3, [fp, #-0x18]
    //     0xc22448: mov             x3, x1
    //     0xc2244c: stur            x1, [fp, #-8]
    // 0xc22450: CheckStackOverflow
    //     0xc22450: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc22454: cmp             SP, x16
    //     0xc22458: b.ls            #0xc22684
    // 0xc2245c: mov             x1, x3
    // 0xc22460: r0 = leading()
    //     0xc22460: bl              #0xb1bc90  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::leading
    // 0xc22464: mov             x3, x0
    // 0xc22468: stur            x3, [fp, #-0x28]
    // 0xc2246c: cmp             w3, NULL
    // 0xc22470: b.eq            #0xc224e4
    // 0xc22474: LoadField: r4 = r3->field_7
    //     0xc22474: ldur            w4, [x3, #7]
    // 0xc22478: DecompressPointer r4
    //     0xc22478: add             x4, x4, HEAP, lsl #32
    // 0xc2247c: stur            x4, [fp, #-0x20]
    // 0xc22480: cmp             w4, NULL
    // 0xc22484: b.eq            #0xc2268c
    // 0xc22488: mov             x0, x4
    // 0xc2248c: r2 = Null
    //     0xc2248c: mov             x2, NULL
    // 0xc22490: r1 = Null
    //     0xc22490: mov             x1, NULL
    // 0xc22494: r4 = LoadClassIdInstr(r0)
    //     0xc22494: ldur            x4, [x0, #-1]
    //     0xc22498: ubfx            x4, x4, #0xc, #0x14
    // 0xc2249c: r17 = -4190
    //     0xc2249c: mov             x17, #-0x105e
    // 0xc224a0: add             x4, x4, x17
    // 0xc224a4: cmp             x4, #0x17
    // 0xc224a8: b.ls            #0xc224c0
    // 0xc224ac: r8 = BoxParentData
    //     0xc224ac: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0xc224b0: ldr             x8, [x8, #0x5e8]
    // 0xc224b4: r3 = Null
    //     0xc224b4: add             x3, PP, #0x99, lsl #12  ; [pp+0x99308] Null
    //     0xc224b8: ldr             x3, [x3, #0x308]
    // 0xc224bc: r0 = DefaultTypeTest()
    //     0xc224bc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc224c0: ldur            x0, [fp, #-0x20]
    // 0xc224c4: LoadField: r1 = r0->field_7
    //     0xc224c4: ldur            w1, [x0, #7]
    // 0xc224c8: DecompressPointer r1
    //     0xc224c8: add             x1, x1, HEAP, lsl #32
    // 0xc224cc: ldur            x2, [fp, #-0x18]
    // 0xc224d0: r0 = +()
    //     0xc224d0: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc224d4: ldur            x1, [fp, #-0x10]
    // 0xc224d8: ldur            x2, [fp, #-0x28]
    // 0xc224dc: mov             x3, x0
    // 0xc224e0: r0 = paintChild()
    //     0xc224e0: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xc224e4: ldur            x1, [fp, #-8]
    // 0xc224e8: r0 = title()
    //     0xc224e8: bl              #0xb1bc50  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::title
    // 0xc224ec: mov             x3, x0
    // 0xc224f0: stur            x3, [fp, #-0x28]
    // 0xc224f4: LoadField: r4 = r3->field_7
    //     0xc224f4: ldur            w4, [x3, #7]
    // 0xc224f8: DecompressPointer r4
    //     0xc224f8: add             x4, x4, HEAP, lsl #32
    // 0xc224fc: stur            x4, [fp, #-0x20]
    // 0xc22500: cmp             w4, NULL
    // 0xc22504: b.eq            #0xc22690
    // 0xc22508: mov             x0, x4
    // 0xc2250c: r2 = Null
    //     0xc2250c: mov             x2, NULL
    // 0xc22510: r1 = Null
    //     0xc22510: mov             x1, NULL
    // 0xc22514: r4 = LoadClassIdInstr(r0)
    //     0xc22514: ldur            x4, [x0, #-1]
    //     0xc22518: ubfx            x4, x4, #0xc, #0x14
    // 0xc2251c: r17 = -4190
    //     0xc2251c: mov             x17, #-0x105e
    // 0xc22520: add             x4, x4, x17
    // 0xc22524: cmp             x4, #0x17
    // 0xc22528: b.ls            #0xc22540
    // 0xc2252c: r8 = BoxParentData
    //     0xc2252c: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0xc22530: ldr             x8, [x8, #0x5e8]
    // 0xc22534: r3 = Null
    //     0xc22534: add             x3, PP, #0x99, lsl #12  ; [pp+0x99318] Null
    //     0xc22538: ldr             x3, [x3, #0x318]
    // 0xc2253c: r0 = DefaultTypeTest()
    //     0xc2253c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc22540: ldur            x0, [fp, #-0x20]
    // 0xc22544: LoadField: r1 = r0->field_7
    //     0xc22544: ldur            w1, [x0, #7]
    // 0xc22548: DecompressPointer r1
    //     0xc22548: add             x1, x1, HEAP, lsl #32
    // 0xc2254c: ldur            x2, [fp, #-0x18]
    // 0xc22550: r0 = +()
    //     0xc22550: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc22554: ldur            x1, [fp, #-0x10]
    // 0xc22558: ldur            x2, [fp, #-0x28]
    // 0xc2255c: mov             x3, x0
    // 0xc22560: r0 = paintChild()
    //     0xc22560: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xc22564: ldur            x1, [fp, #-8]
    // 0xc22568: r0 = subtitle()
    //     0xc22568: bl              #0xb1bc1c  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::subtitle
    // 0xc2256c: mov             x3, x0
    // 0xc22570: stur            x3, [fp, #-0x28]
    // 0xc22574: cmp             w3, NULL
    // 0xc22578: b.eq            #0xc225ec
    // 0xc2257c: LoadField: r4 = r3->field_7
    //     0xc2257c: ldur            w4, [x3, #7]
    // 0xc22580: DecompressPointer r4
    //     0xc22580: add             x4, x4, HEAP, lsl #32
    // 0xc22584: stur            x4, [fp, #-0x20]
    // 0xc22588: cmp             w4, NULL
    // 0xc2258c: b.eq            #0xc22694
    // 0xc22590: mov             x0, x4
    // 0xc22594: r2 = Null
    //     0xc22594: mov             x2, NULL
    // 0xc22598: r1 = Null
    //     0xc22598: mov             x1, NULL
    // 0xc2259c: r4 = LoadClassIdInstr(r0)
    //     0xc2259c: ldur            x4, [x0, #-1]
    //     0xc225a0: ubfx            x4, x4, #0xc, #0x14
    // 0xc225a4: r17 = -4190
    //     0xc225a4: mov             x17, #-0x105e
    // 0xc225a8: add             x4, x4, x17
    // 0xc225ac: cmp             x4, #0x17
    // 0xc225b0: b.ls            #0xc225c8
    // 0xc225b4: r8 = BoxParentData
    //     0xc225b4: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0xc225b8: ldr             x8, [x8, #0x5e8]
    // 0xc225bc: r3 = Null
    //     0xc225bc: add             x3, PP, #0x99, lsl #12  ; [pp+0x99328] Null
    //     0xc225c0: ldr             x3, [x3, #0x328]
    // 0xc225c4: r0 = DefaultTypeTest()
    //     0xc225c4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc225c8: ldur            x0, [fp, #-0x20]
    // 0xc225cc: LoadField: r1 = r0->field_7
    //     0xc225cc: ldur            w1, [x0, #7]
    // 0xc225d0: DecompressPointer r1
    //     0xc225d0: add             x1, x1, HEAP, lsl #32
    // 0xc225d4: ldur            x2, [fp, #-0x18]
    // 0xc225d8: r0 = +()
    //     0xc225d8: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc225dc: ldur            x1, [fp, #-0x10]
    // 0xc225e0: ldur            x2, [fp, #-0x28]
    // 0xc225e4: mov             x3, x0
    // 0xc225e8: r0 = paintChild()
    //     0xc225e8: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xc225ec: ldur            x1, [fp, #-8]
    // 0xc225f0: r0 = trailing()
    //     0xc225f0: bl              #0xb1bbe8  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::trailing
    // 0xc225f4: mov             x3, x0
    // 0xc225f8: stur            x3, [fp, #-0x20]
    // 0xc225fc: cmp             w3, NULL
    // 0xc22600: b.eq            #0xc22674
    // 0xc22604: LoadField: r4 = r3->field_7
    //     0xc22604: ldur            w4, [x3, #7]
    // 0xc22608: DecompressPointer r4
    //     0xc22608: add             x4, x4, HEAP, lsl #32
    // 0xc2260c: stur            x4, [fp, #-8]
    // 0xc22610: cmp             w4, NULL
    // 0xc22614: b.eq            #0xc22698
    // 0xc22618: mov             x0, x4
    // 0xc2261c: r2 = Null
    //     0xc2261c: mov             x2, NULL
    // 0xc22620: r1 = Null
    //     0xc22620: mov             x1, NULL
    // 0xc22624: r4 = LoadClassIdInstr(r0)
    //     0xc22624: ldur            x4, [x0, #-1]
    //     0xc22628: ubfx            x4, x4, #0xc, #0x14
    // 0xc2262c: r17 = -4190
    //     0xc2262c: mov             x17, #-0x105e
    // 0xc22630: add             x4, x4, x17
    // 0xc22634: cmp             x4, #0x17
    // 0xc22638: b.ls            #0xc22650
    // 0xc2263c: r8 = BoxParentData
    //     0xc2263c: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0xc22640: ldr             x8, [x8, #0x5e8]
    // 0xc22644: r3 = Null
    //     0xc22644: add             x3, PP, #0x99, lsl #12  ; [pp+0x99338] Null
    //     0xc22648: ldr             x3, [x3, #0x338]
    // 0xc2264c: r0 = DefaultTypeTest()
    //     0xc2264c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc22650: ldur            x0, [fp, #-8]
    // 0xc22654: LoadField: r1 = r0->field_7
    //     0xc22654: ldur            w1, [x0, #7]
    // 0xc22658: DecompressPointer r1
    //     0xc22658: add             x1, x1, HEAP, lsl #32
    // 0xc2265c: ldur            x2, [fp, #-0x18]
    // 0xc22660: r0 = +()
    //     0xc22660: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc22664: ldur            x1, [fp, #-0x10]
    // 0xc22668: ldur            x2, [fp, #-0x20]
    // 0xc2266c: mov             x3, x0
    // 0xc22670: r0 = paintChild()
    //     0xc22670: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xc22674: r0 = Null
    //     0xc22674: mov             x0, NULL
    // 0xc22678: LeaveFrame
    //     0xc22678: mov             SP, fp
    //     0xc2267c: ldp             fp, lr, [SP], #0x10
    // 0xc22680: ret
    //     0xc22680: ret             
    // 0xc22684: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc22684: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc22688: b               #0xc2245c
    // 0xc2268c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc2268c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc22690: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc22690: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc22694: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc22694: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc22698: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc22698: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ titleAlignment=(/* No info */) {
    // ** addr: 0xcde174, size: 0x70
    // 0xcde174: EnterFrame
    //     0xcde174: stp             fp, lr, [SP, #-0x10]!
    //     0xcde178: mov             fp, SP
    // 0xcde17c: mov             x0, x2
    // 0xcde180: CheckStackOverflow
    //     0xcde180: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcde184: cmp             SP, x16
    //     0xcde188: b.ls            #0xcde1dc
    // 0xcde18c: LoadField: r2 = r1->field_87
    //     0xcde18c: ldur            w2, [x1, #0x87]
    // 0xcde190: DecompressPointer r2
    //     0xcde190: add             x2, x2, HEAP, lsl #32
    // 0xcde194: cmp             w2, w0
    // 0xcde198: b.ne            #0xcde1ac
    // 0xcde19c: r0 = Null
    //     0xcde19c: mov             x0, NULL
    // 0xcde1a0: LeaveFrame
    //     0xcde1a0: mov             SP, fp
    //     0xcde1a4: ldp             fp, lr, [SP], #0x10
    // 0xcde1a8: ret
    //     0xcde1a8: ret             
    // 0xcde1ac: StoreField: r1->field_87 = r0
    //     0xcde1ac: stur            w0, [x1, #0x87]
    //     0xcde1b0: ldurb           w16, [x1, #-1]
    //     0xcde1b4: ldurb           w17, [x0, #-1]
    //     0xcde1b8: and             x16, x17, x16, lsr #2
    //     0xcde1bc: tst             x16, HEAP, lsr #32
    //     0xcde1c0: b.eq            #0xcde1c8
    //     0xcde1c4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcde1c8: r0 = markNeedsLayout()
    //     0xcde1c8: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcde1cc: r0 = Null
    //     0xcde1cc: mov             x0, NULL
    // 0xcde1d0: LeaveFrame
    //     0xcde1d0: mov             SP, fp
    //     0xcde1d4: ldp             fp, lr, [SP], #0x10
    // 0xcde1d8: ret
    //     0xcde1d8: ret             
    // 0xcde1dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcde1dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcde1e0: b               #0xcde18c
  }
  set _ minVerticalPadding=(/* No info */) {
    // ** addr: 0xcde1e4, size: 0x50
    // 0xcde1e4: EnterFrame
    //     0xcde1e4: stp             fp, lr, [SP, #-0x10]!
    //     0xcde1e8: mov             fp, SP
    // 0xcde1ec: CheckStackOverflow
    //     0xcde1ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcde1f0: cmp             SP, x16
    //     0xcde1f4: b.ls            #0xcde22c
    // 0xcde1f8: LoadField: d1 = r1->field_73
    //     0xcde1f8: ldur            d1, [x1, #0x73]
    // 0xcde1fc: fcmp            d1, d0
    // 0xcde200: b.ne            #0xcde214
    // 0xcde204: r0 = Null
    //     0xcde204: mov             x0, NULL
    // 0xcde208: LeaveFrame
    //     0xcde208: mov             SP, fp
    //     0xcde20c: ldp             fp, lr, [SP], #0x10
    // 0xcde210: ret
    //     0xcde210: ret             
    // 0xcde214: StoreField: r1->field_73 = d0
    //     0xcde214: stur            d0, [x1, #0x73]
    // 0xcde218: r0 = markNeedsLayout()
    //     0xcde218: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcde21c: r0 = Null
    //     0xcde21c: mov             x0, NULL
    // 0xcde220: LeaveFrame
    //     0xcde220: mov             SP, fp
    //     0xcde224: ldp             fp, lr, [SP], #0x10
    // 0xcde228: ret
    //     0xcde228: ret             
    // 0xcde22c: r0 = StackOverflowSharedWithFPURegs()
    //     0xcde22c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xcde230: b               #0xcde1f8
  }
  set _ minTileHeight=(/* No info */) {
    // ** addr: 0xcde234, size: 0xa4
    // 0xcde234: EnterFrame
    //     0xcde234: stp             fp, lr, [SP, #-0x10]!
    //     0xcde238: mov             fp, SP
    // 0xcde23c: AllocStack(0x20)
    //     0xcde23c: sub             SP, SP, #0x20
    // 0xcde240: SetupParameters(_RenderListTile this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xcde240: stur            x1, [fp, #-8]
    //     0xcde244: mov             x16, x2
    //     0xcde248: mov             x2, x1
    //     0xcde24c: mov             x1, x16
    //     0xcde250: stur            x1, [fp, #-0x10]
    // 0xcde254: CheckStackOverflow
    //     0xcde254: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcde258: cmp             SP, x16
    //     0xcde25c: b.ls            #0xcde2d0
    // 0xcde260: LoadField: r0 = r2->field_83
    //     0xcde260: ldur            w0, [x2, #0x83]
    // 0xcde264: DecompressPointer r0
    //     0xcde264: add             x0, x0, HEAP, lsl #32
    // 0xcde268: r3 = LoadClassIdInstr(r0)
    //     0xcde268: ldur            x3, [x0, #-1]
    //     0xcde26c: ubfx            x3, x3, #0xc, #0x14
    // 0xcde270: stp             x1, x0, [SP]
    // 0xcde274: mov             x0, x3
    // 0xcde278: mov             lr, x0
    // 0xcde27c: ldr             lr, [x21, lr, lsl #3]
    // 0xcde280: blr             lr
    // 0xcde284: tbnz            w0, #4, #0xcde298
    // 0xcde288: r0 = Null
    //     0xcde288: mov             x0, NULL
    // 0xcde28c: LeaveFrame
    //     0xcde28c: mov             SP, fp
    //     0xcde290: ldp             fp, lr, [SP], #0x10
    // 0xcde294: ret
    //     0xcde294: ret             
    // 0xcde298: ldur            x1, [fp, #-8]
    // 0xcde29c: ldur            x0, [fp, #-0x10]
    // 0xcde2a0: StoreField: r1->field_83 = r0
    //     0xcde2a0: stur            w0, [x1, #0x83]
    //     0xcde2a4: ldurb           w16, [x1, #-1]
    //     0xcde2a8: ldurb           w17, [x0, #-1]
    //     0xcde2ac: and             x16, x17, x16, lsr #2
    //     0xcde2b0: tst             x16, HEAP, lsr #32
    //     0xcde2b4: b.eq            #0xcde2bc
    //     0xcde2b8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcde2bc: r0 = markNeedsLayout()
    //     0xcde2bc: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcde2c0: r0 = Null
    //     0xcde2c0: mov             x0, NULL
    // 0xcde2c4: LeaveFrame
    //     0xcde2c4: mov             SP, fp
    //     0xcde2c8: ldp             fp, lr, [SP], #0x10
    // 0xcde2cc: ret
    //     0xcde2cc: ret             
    // 0xcde2d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcde2d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcde2d4: b               #0xcde260
  }
  set _ minLeadingWidth=(/* No info */) {
    // ** addr: 0xcde2d8, size: 0x50
    // 0xcde2d8: EnterFrame
    //     0xcde2d8: stp             fp, lr, [SP, #-0x10]!
    //     0xcde2dc: mov             fp, SP
    // 0xcde2e0: CheckStackOverflow
    //     0xcde2e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcde2e4: cmp             SP, x16
    //     0xcde2e8: b.ls            #0xcde320
    // 0xcde2ec: LoadField: d1 = r1->field_7b
    //     0xcde2ec: ldur            d1, [x1, #0x7b]
    // 0xcde2f0: fcmp            d1, d0
    // 0xcde2f4: b.ne            #0xcde308
    // 0xcde2f8: r0 = Null
    //     0xcde2f8: mov             x0, NULL
    // 0xcde2fc: LeaveFrame
    //     0xcde2fc: mov             SP, fp
    //     0xcde300: ldp             fp, lr, [SP], #0x10
    // 0xcde304: ret
    //     0xcde304: ret             
    // 0xcde308: StoreField: r1->field_7b = d0
    //     0xcde308: stur            d0, [x1, #0x7b]
    // 0xcde30c: r0 = markNeedsLayout()
    //     0xcde30c: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcde310: r0 = Null
    //     0xcde310: mov             x0, NULL
    // 0xcde314: LeaveFrame
    //     0xcde314: mov             SP, fp
    //     0xcde318: ldp             fp, lr, [SP], #0x10
    // 0xcde31c: ret
    //     0xcde31c: ret             
    // 0xcde320: r0 = StackOverflowSharedWithFPURegs()
    //     0xcde320: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xcde324: b               #0xcde2ec
  }
  set _ horizontalTitleGap=(/* No info */) {
    // ** addr: 0xcde328, size: 0x50
    // 0xcde328: EnterFrame
    //     0xcde328: stp             fp, lr, [SP, #-0x10]!
    //     0xcde32c: mov             fp, SP
    // 0xcde330: CheckStackOverflow
    //     0xcde330: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcde334: cmp             SP, x16
    //     0xcde338: b.ls            #0xcde370
    // 0xcde33c: LoadField: d1 = r1->field_6b
    //     0xcde33c: ldur            d1, [x1, #0x6b]
    // 0xcde340: fcmp            d1, d0
    // 0xcde344: b.ne            #0xcde358
    // 0xcde348: r0 = Null
    //     0xcde348: mov             x0, NULL
    // 0xcde34c: LeaveFrame
    //     0xcde34c: mov             SP, fp
    //     0xcde350: ldp             fp, lr, [SP], #0x10
    // 0xcde354: ret
    //     0xcde354: ret             
    // 0xcde358: StoreField: r1->field_6b = d0
    //     0xcde358: stur            d0, [x1, #0x6b]
    // 0xcde35c: r0 = markNeedsLayout()
    //     0xcde35c: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcde360: r0 = Null
    //     0xcde360: mov             x0, NULL
    // 0xcde364: LeaveFrame
    //     0xcde364: mov             SP, fp
    //     0xcde368: ldp             fp, lr, [SP], #0x10
    // 0xcde36c: ret
    //     0xcde36c: ret             
    // 0xcde370: r0 = StackOverflowSharedWithFPURegs()
    //     0xcde370: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xcde374: b               #0xcde33c
  }
  set _ subtitleBaselineType=(/* No info */) {
    // ** addr: 0xcde378, size: 0x70
    // 0xcde378: EnterFrame
    //     0xcde378: stp             fp, lr, [SP, #-0x10]!
    //     0xcde37c: mov             fp, SP
    // 0xcde380: mov             x0, x2
    // 0xcde384: CheckStackOverflow
    //     0xcde384: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcde388: cmp             SP, x16
    //     0xcde38c: b.ls            #0xcde3e0
    // 0xcde390: LoadField: r2 = r1->field_67
    //     0xcde390: ldur            w2, [x1, #0x67]
    // 0xcde394: DecompressPointer r2
    //     0xcde394: add             x2, x2, HEAP, lsl #32
    // 0xcde398: cmp             w2, w0
    // 0xcde39c: b.ne            #0xcde3b0
    // 0xcde3a0: r0 = Null
    //     0xcde3a0: mov             x0, NULL
    // 0xcde3a4: LeaveFrame
    //     0xcde3a4: mov             SP, fp
    //     0xcde3a8: ldp             fp, lr, [SP], #0x10
    // 0xcde3ac: ret
    //     0xcde3ac: ret             
    // 0xcde3b0: StoreField: r1->field_67 = r0
    //     0xcde3b0: stur            w0, [x1, #0x67]
    //     0xcde3b4: ldurb           w16, [x1, #-1]
    //     0xcde3b8: ldurb           w17, [x0, #-1]
    //     0xcde3bc: and             x16, x17, x16, lsr #2
    //     0xcde3c0: tst             x16, HEAP, lsr #32
    //     0xcde3c4: b.eq            #0xcde3cc
    //     0xcde3c8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcde3cc: r0 = markNeedsLayout()
    //     0xcde3cc: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcde3d0: r0 = Null
    //     0xcde3d0: mov             x0, NULL
    // 0xcde3d4: LeaveFrame
    //     0xcde3d4: mov             SP, fp
    //     0xcde3d8: ldp             fp, lr, [SP], #0x10
    // 0xcde3dc: ret
    //     0xcde3dc: ret             
    // 0xcde3e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcde3e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcde3e4: b               #0xcde390
  }
  set _ titleBaselineType=(/* No info */) {
    // ** addr: 0xcde3e8, size: 0x70
    // 0xcde3e8: EnterFrame
    //     0xcde3e8: stp             fp, lr, [SP, #-0x10]!
    //     0xcde3ec: mov             fp, SP
    // 0xcde3f0: mov             x0, x2
    // 0xcde3f4: CheckStackOverflow
    //     0xcde3f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcde3f8: cmp             SP, x16
    //     0xcde3fc: b.ls            #0xcde450
    // 0xcde400: LoadField: r2 = r1->field_63
    //     0xcde400: ldur            w2, [x1, #0x63]
    // 0xcde404: DecompressPointer r2
    //     0xcde404: add             x2, x2, HEAP, lsl #32
    // 0xcde408: cmp             w2, w0
    // 0xcde40c: b.ne            #0xcde420
    // 0xcde410: r0 = Null
    //     0xcde410: mov             x0, NULL
    // 0xcde414: LeaveFrame
    //     0xcde414: mov             SP, fp
    //     0xcde418: ldp             fp, lr, [SP], #0x10
    // 0xcde41c: ret
    //     0xcde41c: ret             
    // 0xcde420: StoreField: r1->field_63 = r0
    //     0xcde420: stur            w0, [x1, #0x63]
    //     0xcde424: ldurb           w16, [x1, #-1]
    //     0xcde428: ldurb           w17, [x0, #-1]
    //     0xcde42c: and             x16, x17, x16, lsr #2
    //     0xcde430: tst             x16, HEAP, lsr #32
    //     0xcde434: b.eq            #0xcde43c
    //     0xcde438: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcde43c: r0 = markNeedsLayout()
    //     0xcde43c: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcde440: r0 = Null
    //     0xcde440: mov             x0, NULL
    // 0xcde444: LeaveFrame
    //     0xcde444: mov             SP, fp
    //     0xcde448: ldp             fp, lr, [SP], #0x10
    // 0xcde44c: ret
    //     0xcde44c: ret             
    // 0xcde450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcde450: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcde454: b               #0xcde400
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0xcde458, size: 0x70
    // 0xcde458: EnterFrame
    //     0xcde458: stp             fp, lr, [SP, #-0x10]!
    //     0xcde45c: mov             fp, SP
    // 0xcde460: mov             x0, x2
    // 0xcde464: CheckStackOverflow
    //     0xcde464: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcde468: cmp             SP, x16
    //     0xcde46c: b.ls            #0xcde4c0
    // 0xcde470: LoadField: r2 = r1->field_5f
    //     0xcde470: ldur            w2, [x1, #0x5f]
    // 0xcde474: DecompressPointer r2
    //     0xcde474: add             x2, x2, HEAP, lsl #32
    // 0xcde478: cmp             w2, w0
    // 0xcde47c: b.ne            #0xcde490
    // 0xcde480: r0 = Null
    //     0xcde480: mov             x0, NULL
    // 0xcde484: LeaveFrame
    //     0xcde484: mov             SP, fp
    //     0xcde488: ldp             fp, lr, [SP], #0x10
    // 0xcde48c: ret
    //     0xcde48c: ret             
    // 0xcde490: StoreField: r1->field_5f = r0
    //     0xcde490: stur            w0, [x1, #0x5f]
    //     0xcde494: ldurb           w16, [x1, #-1]
    //     0xcde498: ldurb           w17, [x0, #-1]
    //     0xcde49c: and             x16, x17, x16, lsr #2
    //     0xcde4a0: tst             x16, HEAP, lsr #32
    //     0xcde4a4: b.eq            #0xcde4ac
    //     0xcde4a8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcde4ac: r0 = markNeedsLayout()
    //     0xcde4ac: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcde4b0: r0 = Null
    //     0xcde4b0: mov             x0, NULL
    // 0xcde4b4: LeaveFrame
    //     0xcde4b4: mov             SP, fp
    //     0xcde4b8: ldp             fp, lr, [SP], #0x10
    // 0xcde4bc: ret
    //     0xcde4bc: ret             
    // 0xcde4c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcde4c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcde4c4: b               #0xcde470
  }
  set _ visualDensity=(/* No info */) {
    // ** addr: 0xcde4c8, size: 0xc8
    // 0xcde4c8: EnterFrame
    //     0xcde4c8: stp             fp, lr, [SP, #-0x10]!
    //     0xcde4cc: mov             fp, SP
    // 0xcde4d0: AllocStack(0x28)
    //     0xcde4d0: sub             SP, SP, #0x28
    // 0xcde4d4: SetupParameters(_RenderListTile this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xcde4d4: mov             x0, x2
    //     0xcde4d8: stur            x1, [fp, #-0x10]
    //     0xcde4dc: stur            x2, [fp, #-0x18]
    // 0xcde4e0: CheckStackOverflow
    //     0xcde4e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcde4e4: cmp             SP, x16
    //     0xcde4e8: b.ls            #0xcde588
    // 0xcde4ec: LoadField: r2 = r1->field_57
    //     0xcde4ec: ldur            w2, [x1, #0x57]
    // 0xcde4f0: DecompressPointer r2
    //     0xcde4f0: add             x2, x2, HEAP, lsl #32
    // 0xcde4f4: stur            x2, [fp, #-8]
    // 0xcde4f8: r16 = VisualDensity
    //     0xcde4f8: add             x16, PP, #0x26, lsl #12  ; [pp+0x26b20] Type: VisualDensity
    //     0xcde4fc: ldr             x16, [x16, #0xb20]
    // 0xcde500: r30 = VisualDensity
    //     0xcde500: add             lr, PP, #0x26, lsl #12  ; [pp+0x26b20] Type: VisualDensity
    //     0xcde504: ldr             lr, [lr, #0xb20]
    // 0xcde508: stp             lr, x16, [SP]
    // 0xcde50c: r0 = ==()
    //     0xcde50c: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0xcde510: tbz             w0, #4, #0xcde51c
    // 0xcde514: ldur            x0, [fp, #-0x18]
    // 0xcde518: b               #0xcde554
    // 0xcde51c: ldur            x0, [fp, #-0x18]
    // 0xcde520: ldur            x1, [fp, #-8]
    // 0xcde524: LoadField: d0 = r0->field_7
    //     0xcde524: ldur            d0, [x0, #7]
    // 0xcde528: LoadField: d1 = r1->field_7
    //     0xcde528: ldur            d1, [x1, #7]
    // 0xcde52c: fcmp            d0, d1
    // 0xcde530: b.ne            #0xcde554
    // 0xcde534: LoadField: d0 = r0->field_f
    //     0xcde534: ldur            d0, [x0, #0xf]
    // 0xcde538: LoadField: d1 = r1->field_f
    //     0xcde538: ldur            d1, [x1, #0xf]
    // 0xcde53c: fcmp            d0, d1
    // 0xcde540: b.ne            #0xcde554
    // 0xcde544: r0 = Null
    //     0xcde544: mov             x0, NULL
    // 0xcde548: LeaveFrame
    //     0xcde548: mov             SP, fp
    //     0xcde54c: ldp             fp, lr, [SP], #0x10
    // 0xcde550: ret
    //     0xcde550: ret             
    // 0xcde554: ldur            x1, [fp, #-0x10]
    // 0xcde558: StoreField: r1->field_57 = r0
    //     0xcde558: stur            w0, [x1, #0x57]
    //     0xcde55c: ldurb           w16, [x1, #-1]
    //     0xcde560: ldurb           w17, [x0, #-1]
    //     0xcde564: and             x16, x17, x16, lsr #2
    //     0xcde568: tst             x16, HEAP, lsr #32
    //     0xcde56c: b.eq            #0xcde574
    //     0xcde570: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcde574: r0 = markNeedsLayout()
    //     0xcde574: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcde578: r0 = Null
    //     0xcde578: mov             x0, NULL
    // 0xcde57c: LeaveFrame
    //     0xcde57c: mov             SP, fp
    //     0xcde580: ldp             fp, lr, [SP], #0x10
    // 0xcde584: ret
    //     0xcde584: ret             
    // 0xcde588: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcde588: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcde58c: b               #0xcde4ec
  }
  set _ isDense=(/* No info */) {
    // ** addr: 0xcde590, size: 0x54
    // 0xcde590: EnterFrame
    //     0xcde590: stp             fp, lr, [SP, #-0x10]!
    //     0xcde594: mov             fp, SP
    // 0xcde598: CheckStackOverflow
    //     0xcde598: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcde59c: cmp             SP, x16
    //     0xcde5a0: b.ls            #0xcde5dc
    // 0xcde5a4: LoadField: r0 = r1->field_53
    //     0xcde5a4: ldur            w0, [x1, #0x53]
    // 0xcde5a8: DecompressPointer r0
    //     0xcde5a8: add             x0, x0, HEAP, lsl #32
    // 0xcde5ac: cmp             w0, w2
    // 0xcde5b0: b.ne            #0xcde5c4
    // 0xcde5b4: r0 = Null
    //     0xcde5b4: mov             x0, NULL
    // 0xcde5b8: LeaveFrame
    //     0xcde5b8: mov             SP, fp
    //     0xcde5bc: ldp             fp, lr, [SP], #0x10
    // 0xcde5c0: ret
    //     0xcde5c0: ret             
    // 0xcde5c4: StoreField: r1->field_53 = r2
    //     0xcde5c4: stur            w2, [x1, #0x53]
    // 0xcde5c8: r0 = markNeedsLayout()
    //     0xcde5c8: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcde5cc: r0 = Null
    //     0xcde5cc: mov             x0, NULL
    // 0xcde5d0: LeaveFrame
    //     0xcde5d0: mov             SP, fp
    //     0xcde5d4: ldp             fp, lr, [SP], #0x10
    // 0xcde5d8: ret
    //     0xcde5d8: ret             
    // 0xcde5dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcde5dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcde5e0: b               #0xcde5a4
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x10ea174, size: 0x1a4
    // 0x10ea174: EnterFrame
    //     0x10ea174: stp             fp, lr, [SP, #-0x10]!
    //     0x10ea178: mov             fp, SP
    // 0x10ea17c: AllocStack(0x40)
    //     0x10ea17c: sub             SP, SP, #0x40
    // 0x10ea180: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r0, fp-0x10 */)
    //     0x10ea180: mov             x0, x3
    //     0x10ea184: stur            x2, [fp, #-8]
    //     0x10ea188: stur            x3, [fp, #-0x10]
    // 0x10ea18c: CheckStackOverflow
    //     0x10ea18c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ea190: cmp             SP, x16
    //     0x10ea194: b.ls            #0x10ea304
    // 0x10ea198: r0 = children()
    //     0x10ea198: bl              #0x125b264  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::children
    // 0x10ea19c: mov             x3, x0
    // 0x10ea1a0: stur            x3, [fp, #-0x38]
    // 0x10ea1a4: LoadField: r0 = r3->field_b
    //     0x10ea1a4: ldur            w0, [x3, #0xb]
    // 0x10ea1a8: r4 = LoadInt32Instr(r0)
    //     0x10ea1a8: sbfx            x4, x0, #1, #0x1f
    // 0x10ea1ac: stur            x4, [fp, #-0x30]
    // 0x10ea1b0: r0 = 0
    //     0x10ea1b0: mov             x0, #0
    // 0x10ea1b4: CheckStackOverflow
    //     0x10ea1b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ea1b8: cmp             SP, x16
    //     0x10ea1bc: b.ls            #0x10ea30c
    // 0x10ea1c0: LoadField: r1 = r3->field_b
    //     0x10ea1c0: ldur            w1, [x3, #0xb]
    // 0x10ea1c4: r2 = LoadInt32Instr(r1)
    //     0x10ea1c4: sbfx            x2, x1, #1, #0x1f
    // 0x10ea1c8: cmp             x4, x2
    // 0x10ea1cc: b.ne            #0x10ea2e4
    // 0x10ea1d0: cmp             x0, x2
    // 0x10ea1d4: b.ge            #0x10ea2d4
    // 0x10ea1d8: LoadField: r1 = r3->field_f
    //     0x10ea1d8: ldur            w1, [x3, #0xf]
    // 0x10ea1dc: DecompressPointer r1
    //     0x10ea1dc: add             x1, x1, HEAP, lsl #32
    // 0x10ea1e0: ArrayLoad: r5 = r1[r0]  ; Unknown_4
    //     0x10ea1e0: add             x16, x1, x0, lsl #2
    //     0x10ea1e4: ldur            w5, [x16, #0xf]
    // 0x10ea1e8: DecompressPointer r5
    //     0x10ea1e8: add             x5, x5, HEAP, lsl #32
    // 0x10ea1ec: stur            x5, [fp, #-0x28]
    // 0x10ea1f0: add             x6, x0, #1
    // 0x10ea1f4: stur            x6, [fp, #-0x20]
    // 0x10ea1f8: LoadField: r7 = r5->field_7
    //     0x10ea1f8: ldur            w7, [x5, #7]
    // 0x10ea1fc: DecompressPointer r7
    //     0x10ea1fc: add             x7, x7, HEAP, lsl #32
    // 0x10ea200: stur            x7, [fp, #-0x18]
    // 0x10ea204: cmp             w7, NULL
    // 0x10ea208: b.eq            #0x10ea314
    // 0x10ea20c: mov             x0, x7
    // 0x10ea210: r2 = Null
    //     0x10ea210: mov             x2, NULL
    // 0x10ea214: r1 = Null
    //     0x10ea214: mov             x1, NULL
    // 0x10ea218: r4 = LoadClassIdInstr(r0)
    //     0x10ea218: ldur            x4, [x0, #-1]
    //     0x10ea21c: ubfx            x4, x4, #0xc, #0x14
    // 0x10ea220: r17 = -4190
    //     0x10ea220: mov             x17, #-0x105e
    // 0x10ea224: add             x4, x4, x17
    // 0x10ea228: cmp             x4, #0x17
    // 0x10ea22c: b.ls            #0x10ea244
    // 0x10ea230: r8 = BoxParentData
    //     0x10ea230: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0x10ea234: ldr             x8, [x8, #0x5e8]
    // 0x10ea238: r3 = Null
    //     0x10ea238: add             x3, PP, #0x99, lsl #12  ; [pp+0x992f8] Null
    //     0x10ea23c: ldr             x3, [x3, #0x2f8]
    // 0x10ea240: r0 = DefaultTypeTest()
    //     0x10ea240: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x10ea244: ldur            x0, [fp, #-0x18]
    // 0x10ea248: LoadField: r3 = r0->field_7
    //     0x10ea248: ldur            w3, [x0, #7]
    // 0x10ea24c: DecompressPointer r3
    //     0x10ea24c: add             x3, x3, HEAP, lsl #32
    // 0x10ea250: ldur            x1, [fp, #-0x10]
    // 0x10ea254: mov             x2, x3
    // 0x10ea258: stur            x3, [fp, #-0x40]
    // 0x10ea25c: r0 = -()
    //     0x10ea25c: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x10ea260: ldur            x1, [fp, #-0x40]
    // 0x10ea264: stur            x0, [fp, #-0x18]
    // 0x10ea268: r0 = unary-()
    //     0x10ea268: bl              #0x856e6c  ; [dart:ui] Offset::unary-
    // 0x10ea26c: ldur            x1, [fp, #-8]
    // 0x10ea270: mov             x2, x0
    // 0x10ea274: r0 = pushOffset()
    //     0x10ea274: bl              #0xaf9e0c  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::pushOffset
    // 0x10ea278: ldur            x1, [fp, #-0x28]
    // 0x10ea27c: r0 = LoadClassIdInstr(r1)
    //     0x10ea27c: ldur            x0, [x1, #-1]
    //     0x10ea280: ubfx            x0, x0, #0xc, #0x14
    // 0x10ea284: ldur            x2, [fp, #-8]
    // 0x10ea288: ldur            x3, [fp, #-0x18]
    // 0x10ea28c: r0 = GDT[cid_x0 + 0x13d77]()
    //     0x10ea28c: mov             x17, #0x3d77
    //     0x10ea290: movk            x17, #1, lsl #16
    //     0x10ea294: add             lr, x0, x17
    //     0x10ea298: ldr             lr, [x21, lr, lsl #3]
    //     0x10ea29c: blr             lr
    // 0x10ea2a0: ldur            x1, [fp, #-8]
    // 0x10ea2a4: stur            x0, [fp, #-0x18]
    // 0x10ea2a8: r0 = popTransform()
    //     0x10ea2a8: bl              #0xaf9850  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::popTransform
    // 0x10ea2ac: ldur            x0, [fp, #-0x18]
    // 0x10ea2b0: tbz             w0, #4, #0x10ea2c4
    // 0x10ea2b4: ldur            x0, [fp, #-0x20]
    // 0x10ea2b8: ldur            x3, [fp, #-0x38]
    // 0x10ea2bc: ldur            x4, [fp, #-0x30]
    // 0x10ea2c0: b               #0x10ea1b4
    // 0x10ea2c4: r0 = true
    //     0x10ea2c4: add             x0, NULL, #0x20  ; true
    // 0x10ea2c8: LeaveFrame
    //     0x10ea2c8: mov             SP, fp
    //     0x10ea2cc: ldp             fp, lr, [SP], #0x10
    // 0x10ea2d0: ret
    //     0x10ea2d0: ret             
    // 0x10ea2d4: r0 = false
    //     0x10ea2d4: add             x0, NULL, #0x30  ; false
    // 0x10ea2d8: LeaveFrame
    //     0x10ea2d8: mov             SP, fp
    //     0x10ea2dc: ldp             fp, lr, [SP], #0x10
    // 0x10ea2e0: ret
    //     0x10ea2e0: ret             
    // 0x10ea2e4: mov             x0, x3
    // 0x10ea2e8: r0 = ConcurrentModificationError()
    //     0x10ea2e8: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x10ea2ec: mov             x1, x0
    // 0x10ea2f0: ldur            x0, [fp, #-0x38]
    // 0x10ea2f4: StoreField: r1->field_b = r0
    //     0x10ea2f4: stur            w0, [x1, #0xb]
    // 0x10ea2f8: mov             x0, x1
    // 0x10ea2fc: r0 = Throw()
    //     0x10ea2fc: bl              #0x13ddb2c  ; ThrowStub
    // 0x10ea300: brk             #0
    // 0x10ea304: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ea304: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ea308: b               #0x10ea198
    // 0x10ea30c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ea30c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ea310: b               #0x10ea1c0
    // 0x10ea314: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10ea314: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10efff4, size: 0x24
    // 0x10efff4: EnterFrame
    //     0x10efff4: stp             fp, lr, [SP, #-0x10]!
    //     0x10efff8: mov             fp, SP
    // 0x10efffc: ldr             x2, [fp, #0x10]
    // 0x10f0000: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10f0000: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3b50] AnonymousClosure: (0xb24d2c), in [package:flutter/src/material/list_tile.dart] _RenderListTile::computeMinIntrinsicHeight (0xb24ba4)
    //     0x10f0004: ldr             x1, [x1, #0xb50]
    // 0x10f0008: r0 = AllocateClosure()
    //     0x10f0008: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10f000c: LeaveFrame
    //     0x10f000c: mov             SP, fp
    //     0x10f0010: ldp             fp, lr, [SP], #0x10
    // 0x10f0014: ret
    //     0x10f0014: ret             
  }
  _ _RenderListTile(/* No info */) {
    // ** addr: 0x11bcec0, size: 0x128
    // 0x11bcec0: EnterFrame
    //     0x11bcec0: stp             fp, lr, [SP, #-0x10]!
    //     0x11bcec4: mov             fp, SP
    // 0x11bcec8: r4 = false
    //     0x11bcec8: add             x4, NULL, #0x30  ; false
    // 0x11bcecc: mov             x0, x2
    // 0x11bced0: mov             x2, x6
    // 0x11bced4: mov             x6, x1
    // 0x11bced8: mov             x16, x5
    // 0x11bcedc: mov             x5, x3
    // 0x11bcee0: mov             x3, x16
    // 0x11bcee4: mov             x1, x7
    // 0x11bcee8: CheckStackOverflow
    //     0x11bcee8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11bceec: cmp             SP, x16
    //     0x11bcef0: b.ls            #0x11bcfe0
    // 0x11bcef4: StoreField: r6->field_53 = r0
    //     0x11bcef4: stur            w0, [x6, #0x53]
    // 0x11bcef8: ldr             x0, [fp, #0x10]
    // 0x11bcefc: StoreField: r6->field_57 = r0
    //     0x11bcefc: stur            w0, [x6, #0x57]
    //     0x11bcf00: ldurb           w16, [x6, #-1]
    //     0x11bcf04: ldurb           w17, [x0, #-1]
    //     0x11bcf08: and             x16, x17, x16, lsr #2
    //     0x11bcf0c: tst             x16, HEAP, lsr #32
    //     0x11bcf10: b.eq            #0x11bcf18
    //     0x11bcf14: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x11bcf18: StoreField: r6->field_5b = r4
    //     0x11bcf18: stur            w4, [x6, #0x5b]
    // 0x11bcf1c: mov             x0, x2
    // 0x11bcf20: StoreField: r6->field_5f = r0
    //     0x11bcf20: stur            w0, [x6, #0x5f]
    //     0x11bcf24: ldurb           w16, [x6, #-1]
    //     0x11bcf28: ldurb           w17, [x0, #-1]
    //     0x11bcf2c: and             x16, x17, x16, lsr #2
    //     0x11bcf30: tst             x16, HEAP, lsr #32
    //     0x11bcf34: b.eq            #0x11bcf3c
    //     0x11bcf38: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x11bcf3c: ldr             x0, [fp, #0x18]
    // 0x11bcf40: StoreField: r6->field_63 = r0
    //     0x11bcf40: stur            w0, [x6, #0x63]
    //     0x11bcf44: ldurb           w16, [x6, #-1]
    //     0x11bcf48: ldurb           w17, [x0, #-1]
    //     0x11bcf4c: and             x16, x17, x16, lsr #2
    //     0x11bcf50: tst             x16, HEAP, lsr #32
    //     0x11bcf54: b.eq            #0x11bcf5c
    //     0x11bcf58: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x11bcf5c: mov             x0, x3
    // 0x11bcf60: StoreField: r6->field_67 = r0
    //     0x11bcf60: stur            w0, [x6, #0x67]
    //     0x11bcf64: ldurb           w16, [x6, #-1]
    //     0x11bcf68: ldurb           w17, [x0, #-1]
    //     0x11bcf6c: and             x16, x17, x16, lsr #2
    //     0x11bcf70: tst             x16, HEAP, lsr #32
    //     0x11bcf74: b.eq            #0x11bcf7c
    //     0x11bcf78: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x11bcf7c: StoreField: r6->field_6b = d0
    //     0x11bcf7c: stur            d0, [x6, #0x6b]
    // 0x11bcf80: StoreField: r6->field_73 = d2
    //     0x11bcf80: stur            d2, [x6, #0x73]
    // 0x11bcf84: StoreField: r6->field_7b = d1
    //     0x11bcf84: stur            d1, [x6, #0x7b]
    // 0x11bcf88: mov             x0, x5
    // 0x11bcf8c: StoreField: r6->field_83 = r0
    //     0x11bcf8c: stur            w0, [x6, #0x83]
    //     0x11bcf90: ldurb           w16, [x6, #-1]
    //     0x11bcf94: ldurb           w17, [x0, #-1]
    //     0x11bcf98: and             x16, x17, x16, lsr #2
    //     0x11bcf9c: tst             x16, HEAP, lsr #32
    //     0x11bcfa0: b.eq            #0x11bcfa8
    //     0x11bcfa4: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x11bcfa8: mov             x0, x1
    // 0x11bcfac: StoreField: r6->field_87 = r0
    //     0x11bcfac: stur            w0, [x6, #0x87]
    //     0x11bcfb0: ldurb           w16, [x6, #-1]
    //     0x11bcfb4: ldurb           w17, [x0, #-1]
    //     0x11bcfb8: and             x16, x17, x16, lsr #2
    //     0x11bcfbc: tst             x16, HEAP, lsr #32
    //     0x11bcfc0: b.eq            #0x11bcfc8
    //     0x11bcfc4: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x11bcfc8: mov             x1, x6
    // 0x11bcfcc: r0 = _MixinApplication75&RenderBox&SlottedContainerRenderObjectMixin()
    //     0x11bcfcc: bl              #0x11bcfe8  ; [dart:mixin_deduplication] _MixinApplication75&RenderBox&SlottedContainerRenderObjectMixin::_MixinApplication75&RenderBox&SlottedContainerRenderObjectMixin
    // 0x11bcfd0: r0 = Null
    //     0x11bcfd0: mov             x0, NULL
    // 0x11bcfd4: LeaveFrame
    //     0x11bcfd4: mov             SP, fp
    //     0x11bcfd8: ldp             fp, lr, [SP], #0x10
    // 0x11bcfdc: ret
    //     0x11bcfdc: ret             
    // 0x11bcfe0: r0 = StackOverflowSharedWithFPURegs()
    //     0x11bcfe0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11bcfe4: b               #0x11bcef4
  }
  get _ children(/* No info */) {
    // ** addr: 0x125b264, size: 0x2bc
    // 0x125b264: EnterFrame
    //     0x125b264: stp             fp, lr, [SP, #-0x10]!
    //     0x125b268: mov             fp, SP
    // 0x125b26c: AllocStack(0x28)
    //     0x125b26c: sub             SP, SP, #0x28
    // 0x125b270: SetupParameters(_RenderListTile this /* r1 => r0, fp-0x8 */)
    //     0x125b270: mov             x0, x1
    //     0x125b274: stur            x1, [fp, #-8]
    // 0x125b278: CheckStackOverflow
    //     0x125b278: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x125b27c: cmp             SP, x16
    //     0x125b280: b.ls            #0x125b518
    // 0x125b284: mov             x1, x0
    // 0x125b288: r2 = Instance__ListTileSlot
    //     0x125b288: add             x2, PP, #0x99, lsl #12  ; [pp+0x99358] Obj!_ListTileSlot@12c5421
    //     0x125b28c: ldr             x2, [x2, #0x358]
    // 0x125b290: r0 = childForSlot()
    //     0x125b290: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x125b294: r1 = <RenderBox>
    //     0x125b294: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c8] TypeArguments: <RenderBox>
    //     0x125b298: ldr             x1, [x1, #0x5c8]
    // 0x125b29c: r2 = 0
    //     0x125b29c: mov             x2, #0
    // 0x125b2a0: stur            x0, [fp, #-0x10]
    // 0x125b2a4: r0 = _GrowableList()
    //     0x125b2a4: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x125b2a8: ldur            x1, [fp, #-8]
    // 0x125b2ac: r2 = Instance__ListTileSlot
    //     0x125b2ac: add             x2, PP, #0x99, lsl #12  ; [pp+0x99360] Obj!_ListTileSlot@12c5441
    //     0x125b2b0: ldr             x2, [x2, #0x360]
    // 0x125b2b4: stur            x0, [fp, #-0x18]
    // 0x125b2b8: r0 = childForSlot()
    //     0x125b2b8: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x125b2bc: stur            x0, [fp, #-0x28]
    // 0x125b2c0: cmp             w0, NULL
    // 0x125b2c4: b.eq            #0x125b344
    // 0x125b2c8: ldur            x2, [fp, #-0x18]
    // 0x125b2cc: LoadField: r1 = r2->field_b
    //     0x125b2cc: ldur            w1, [x2, #0xb]
    // 0x125b2d0: LoadField: r3 = r2->field_f
    //     0x125b2d0: ldur            w3, [x2, #0xf]
    // 0x125b2d4: DecompressPointer r3
    //     0x125b2d4: add             x3, x3, HEAP, lsl #32
    // 0x125b2d8: LoadField: r4 = r3->field_b
    //     0x125b2d8: ldur            w4, [x3, #0xb]
    // 0x125b2dc: r3 = LoadInt32Instr(r1)
    //     0x125b2dc: sbfx            x3, x1, #1, #0x1f
    // 0x125b2e0: stur            x3, [fp, #-0x20]
    // 0x125b2e4: r1 = LoadInt32Instr(r4)
    //     0x125b2e4: sbfx            x1, x4, #1, #0x1f
    // 0x125b2e8: cmp             x3, x1
    // 0x125b2ec: b.ne            #0x125b2f8
    // 0x125b2f0: mov             x1, x2
    // 0x125b2f4: r0 = _growToNextCapacity()
    //     0x125b2f4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x125b2f8: ldur            x2, [fp, #-0x18]
    // 0x125b2fc: ldur            x3, [fp, #-0x20]
    // 0x125b300: add             x0, x3, #1
    // 0x125b304: lsl             x1, x0, #1
    // 0x125b308: StoreField: r2->field_b = r1
    //     0x125b308: stur            w1, [x2, #0xb]
    // 0x125b30c: LoadField: r1 = r2->field_f
    //     0x125b30c: ldur            w1, [x2, #0xf]
    // 0x125b310: DecompressPointer r1
    //     0x125b310: add             x1, x1, HEAP, lsl #32
    // 0x125b314: ldur            x0, [fp, #-0x28]
    // 0x125b318: ArrayStore: r1[r3] = r0  ; List_4
    //     0x125b318: add             x25, x1, x3, lsl #2
    //     0x125b31c: add             x25, x25, #0xf
    //     0x125b320: str             w0, [x25]
    //     0x125b324: tbz             w0, #0, #0x125b340
    //     0x125b328: ldurb           w16, [x1, #-1]
    //     0x125b32c: ldurb           w17, [x0, #-1]
    //     0x125b330: and             x16, x17, x16, lsr #2
    //     0x125b334: tst             x16, HEAP, lsr #32
    //     0x125b338: b.eq            #0x125b340
    //     0x125b33c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x125b340: b               #0x125b348
    // 0x125b344: ldur            x2, [fp, #-0x18]
    // 0x125b348: ldur            x0, [fp, #-0x10]
    // 0x125b34c: cmp             w0, NULL
    // 0x125b350: b.eq            #0x125b3cc
    // 0x125b354: LoadField: r1 = r2->field_b
    //     0x125b354: ldur            w1, [x2, #0xb]
    // 0x125b358: LoadField: r3 = r2->field_f
    //     0x125b358: ldur            w3, [x2, #0xf]
    // 0x125b35c: DecompressPointer r3
    //     0x125b35c: add             x3, x3, HEAP, lsl #32
    // 0x125b360: LoadField: r4 = r3->field_b
    //     0x125b360: ldur            w4, [x3, #0xb]
    // 0x125b364: r3 = LoadInt32Instr(r1)
    //     0x125b364: sbfx            x3, x1, #1, #0x1f
    // 0x125b368: stur            x3, [fp, #-0x20]
    // 0x125b36c: r1 = LoadInt32Instr(r4)
    //     0x125b36c: sbfx            x1, x4, #1, #0x1f
    // 0x125b370: cmp             x3, x1
    // 0x125b374: b.ne            #0x125b380
    // 0x125b378: mov             x1, x2
    // 0x125b37c: r0 = _growToNextCapacity()
    //     0x125b37c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x125b380: ldur            x3, [fp, #-0x18]
    // 0x125b384: ldur            x2, [fp, #-0x20]
    // 0x125b388: add             x0, x2, #1
    // 0x125b38c: lsl             x1, x0, #1
    // 0x125b390: StoreField: r3->field_b = r1
    //     0x125b390: stur            w1, [x3, #0xb]
    // 0x125b394: LoadField: r1 = r3->field_f
    //     0x125b394: ldur            w1, [x3, #0xf]
    // 0x125b398: DecompressPointer r1
    //     0x125b398: add             x1, x1, HEAP, lsl #32
    // 0x125b39c: ldur            x0, [fp, #-0x10]
    // 0x125b3a0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x125b3a0: add             x25, x1, x2, lsl #2
    //     0x125b3a4: add             x25, x25, #0xf
    //     0x125b3a8: str             w0, [x25]
    //     0x125b3ac: tbz             w0, #0, #0x125b3c8
    //     0x125b3b0: ldurb           w16, [x1, #-1]
    //     0x125b3b4: ldurb           w17, [x0, #-1]
    //     0x125b3b8: and             x16, x17, x16, lsr #2
    //     0x125b3bc: tst             x16, HEAP, lsr #32
    //     0x125b3c0: b.eq            #0x125b3c8
    //     0x125b3c4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x125b3c8: b               #0x125b3d0
    // 0x125b3cc: mov             x3, x2
    // 0x125b3d0: ldur            x1, [fp, #-8]
    // 0x125b3d4: r2 = Instance__ListTileSlot
    //     0x125b3d4: add             x2, PP, #0x99, lsl #12  ; [pp+0x99350] Obj!_ListTileSlot@12c5401
    //     0x125b3d8: ldr             x2, [x2, #0x350]
    // 0x125b3dc: r0 = childForSlot()
    //     0x125b3dc: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x125b3e0: stur            x0, [fp, #-0x10]
    // 0x125b3e4: cmp             w0, NULL
    // 0x125b3e8: b.eq            #0x125b468
    // 0x125b3ec: ldur            x2, [fp, #-0x18]
    // 0x125b3f0: LoadField: r1 = r2->field_b
    //     0x125b3f0: ldur            w1, [x2, #0xb]
    // 0x125b3f4: LoadField: r3 = r2->field_f
    //     0x125b3f4: ldur            w3, [x2, #0xf]
    // 0x125b3f8: DecompressPointer r3
    //     0x125b3f8: add             x3, x3, HEAP, lsl #32
    // 0x125b3fc: LoadField: r4 = r3->field_b
    //     0x125b3fc: ldur            w4, [x3, #0xb]
    // 0x125b400: r3 = LoadInt32Instr(r1)
    //     0x125b400: sbfx            x3, x1, #1, #0x1f
    // 0x125b404: stur            x3, [fp, #-0x20]
    // 0x125b408: r1 = LoadInt32Instr(r4)
    //     0x125b408: sbfx            x1, x4, #1, #0x1f
    // 0x125b40c: cmp             x3, x1
    // 0x125b410: b.ne            #0x125b41c
    // 0x125b414: mov             x1, x2
    // 0x125b418: r0 = _growToNextCapacity()
    //     0x125b418: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x125b41c: ldur            x3, [fp, #-0x18]
    // 0x125b420: ldur            x2, [fp, #-0x20]
    // 0x125b424: add             x0, x2, #1
    // 0x125b428: lsl             x1, x0, #1
    // 0x125b42c: StoreField: r3->field_b = r1
    //     0x125b42c: stur            w1, [x3, #0xb]
    // 0x125b430: LoadField: r1 = r3->field_f
    //     0x125b430: ldur            w1, [x3, #0xf]
    // 0x125b434: DecompressPointer r1
    //     0x125b434: add             x1, x1, HEAP, lsl #32
    // 0x125b438: ldur            x0, [fp, #-0x10]
    // 0x125b43c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x125b43c: add             x25, x1, x2, lsl #2
    //     0x125b440: add             x25, x25, #0xf
    //     0x125b444: str             w0, [x25]
    //     0x125b448: tbz             w0, #0, #0x125b464
    //     0x125b44c: ldurb           w16, [x1, #-1]
    //     0x125b450: ldurb           w17, [x0, #-1]
    //     0x125b454: and             x16, x17, x16, lsr #2
    //     0x125b458: tst             x16, HEAP, lsr #32
    //     0x125b45c: b.eq            #0x125b464
    //     0x125b460: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x125b464: b               #0x125b46c
    // 0x125b468: ldur            x3, [fp, #-0x18]
    // 0x125b46c: ldur            x1, [fp, #-8]
    // 0x125b470: r2 = Instance__ListTileSlot
    //     0x125b470: add             x2, PP, #0x99, lsl #12  ; [pp+0x99348] Obj!_ListTileSlot@12c53e1
    //     0x125b474: ldr             x2, [x2, #0x348]
    // 0x125b478: r0 = childForSlot()
    //     0x125b478: bl              #0xaf7fbc  ; [dart:mixin_deduplication] _MixinApplication73&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x125b47c: stur            x0, [fp, #-8]
    // 0x125b480: cmp             w0, NULL
    // 0x125b484: b.eq            #0x125b504
    // 0x125b488: ldur            x2, [fp, #-0x18]
    // 0x125b48c: LoadField: r1 = r2->field_b
    //     0x125b48c: ldur            w1, [x2, #0xb]
    // 0x125b490: LoadField: r3 = r2->field_f
    //     0x125b490: ldur            w3, [x2, #0xf]
    // 0x125b494: DecompressPointer r3
    //     0x125b494: add             x3, x3, HEAP, lsl #32
    // 0x125b498: LoadField: r4 = r3->field_b
    //     0x125b498: ldur            w4, [x3, #0xb]
    // 0x125b49c: r3 = LoadInt32Instr(r1)
    //     0x125b49c: sbfx            x3, x1, #1, #0x1f
    // 0x125b4a0: stur            x3, [fp, #-0x20]
    // 0x125b4a4: r1 = LoadInt32Instr(r4)
    //     0x125b4a4: sbfx            x1, x4, #1, #0x1f
    // 0x125b4a8: cmp             x3, x1
    // 0x125b4ac: b.ne            #0x125b4b8
    // 0x125b4b0: mov             x1, x2
    // 0x125b4b4: r0 = _growToNextCapacity()
    //     0x125b4b4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x125b4b8: ldur            x2, [fp, #-0x18]
    // 0x125b4bc: ldur            x3, [fp, #-0x20]
    // 0x125b4c0: add             x4, x3, #1
    // 0x125b4c4: lsl             x5, x4, #1
    // 0x125b4c8: StoreField: r2->field_b = r5
    //     0x125b4c8: stur            w5, [x2, #0xb]
    // 0x125b4cc: LoadField: r1 = r2->field_f
    //     0x125b4cc: ldur            w1, [x2, #0xf]
    // 0x125b4d0: DecompressPointer r1
    //     0x125b4d0: add             x1, x1, HEAP, lsl #32
    // 0x125b4d4: ldur            x0, [fp, #-8]
    // 0x125b4d8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x125b4d8: add             x25, x1, x3, lsl #2
    //     0x125b4dc: add             x25, x25, #0xf
    //     0x125b4e0: str             w0, [x25]
    //     0x125b4e4: tbz             w0, #0, #0x125b500
    //     0x125b4e8: ldurb           w16, [x1, #-1]
    //     0x125b4ec: ldurb           w17, [x0, #-1]
    //     0x125b4f0: and             x16, x17, x16, lsr #2
    //     0x125b4f4: tst             x16, HEAP, lsr #32
    //     0x125b4f8: b.eq            #0x125b500
    //     0x125b4fc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x125b500: b               #0x125b508
    // 0x125b504: ldur            x2, [fp, #-0x18]
    // 0x125b508: mov             x0, x2
    // 0x125b50c: LeaveFrame
    //     0x125b50c: mov             SP, fp
    //     0x125b510: ldp             fp, lr, [SP], #0x10
    // 0x125b514: ret
    //     0x125b514: ret             
    // 0x125b518: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x125b518: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x125b51c: b               #0x125b284
  }
}

// class id: 5142, size: 0x70, field offset: 0x60
class _LisTileDefaultsM3 extends ListTileThemeData {

  late final ColorScheme _colors; // offset: 0x68
  late final TextTheme _textTheme; // offset: 0x6c
  late final ThemeData _theme; // offset: 0x64

  TextTheme _textTheme(_LisTileDefaultsM3) {
    // ** addr: 0xfbcc98, size: 0x58
    // 0xfbcc98: EnterFrame
    //     0xfbcc98: stp             fp, lr, [SP, #-0x10]!
    //     0xfbcc9c: mov             fp, SP
    // 0xfbcca0: CheckStackOverflow
    //     0xfbcca0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbcca4: cmp             SP, x16
    //     0xfbcca8: b.ls            #0xfbcce8
    // 0xfbccac: ldr             x1, [fp, #0x10]
    // 0xfbccb0: LoadField: r0 = r1->field_63
    //     0xfbccb0: ldur            w0, [x1, #0x63]
    // 0xfbccb4: DecompressPointer r0
    //     0xfbccb4: add             x0, x0, HEAP, lsl #32
    // 0xfbccb8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbccbc: cmp             w0, w16
    // 0xfbccc0: b.ne            #0xfbccd0
    // 0xfbccc4: r2 = _theme
    //     0xfbccc4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26348] Field <_LisTileDefaultsM3@97247952._theme@97247952>: late final (offset: 0x64)
    //     0xfbccc8: ldr             x2, [x2, #0x348]
    // 0xfbcccc: r0 = InitLateFinalInstanceField()
    //     0xfbcccc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbccd0: LoadField: r1 = r0->field_87
    //     0xfbccd0: ldur            w1, [x0, #0x87]
    // 0xfbccd4: DecompressPointer r1
    //     0xfbccd4: add             x1, x1, HEAP, lsl #32
    // 0xfbccd8: mov             x0, x1
    // 0xfbccdc: LeaveFrame
    //     0xfbccdc: mov             SP, fp
    //     0xfbcce0: ldp             fp, lr, [SP], #0x10
    // 0xfbcce4: ret
    //     0xfbcce4: ret             
    // 0xfbcce8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbcce8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbccec: b               #0xfbccac
  }
  ColorScheme _colors(_LisTileDefaultsM3) {
    // ** addr: 0xfbcd28, size: 0x58
    // 0xfbcd28: EnterFrame
    //     0xfbcd28: stp             fp, lr, [SP, #-0x10]!
    //     0xfbcd2c: mov             fp, SP
    // 0xfbcd30: CheckStackOverflow
    //     0xfbcd30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbcd34: cmp             SP, x16
    //     0xfbcd38: b.ls            #0xfbcd78
    // 0xfbcd3c: ldr             x1, [fp, #0x10]
    // 0xfbcd40: LoadField: r0 = r1->field_63
    //     0xfbcd40: ldur            w0, [x1, #0x63]
    // 0xfbcd44: DecompressPointer r0
    //     0xfbcd44: add             x0, x0, HEAP, lsl #32
    // 0xfbcd48: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbcd4c: cmp             w0, w16
    // 0xfbcd50: b.ne            #0xfbcd60
    // 0xfbcd54: r2 = _theme
    //     0xfbcd54: add             x2, PP, #0x26, lsl #12  ; [pp+0x26348] Field <_LisTileDefaultsM3@97247952._theme@97247952>: late final (offset: 0x64)
    //     0xfbcd58: ldr             x2, [x2, #0x348]
    // 0xfbcd5c: r0 = InitLateFinalInstanceField()
    //     0xfbcd5c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbcd60: LoadField: r1 = r0->field_3f
    //     0xfbcd60: ldur            w1, [x0, #0x3f]
    // 0xfbcd64: DecompressPointer r1
    //     0xfbcd64: add             x1, x1, HEAP, lsl #32
    // 0xfbcd68: mov             x0, x1
    // 0xfbcd6c: LeaveFrame
    //     0xfbcd6c: mov             SP, fp
    //     0xfbcd70: ldp             fp, lr, [SP], #0x10
    // 0xfbcd74: ret
    //     0xfbcd74: ret             
    // 0xfbcd78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbcd78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbcd7c: b               #0xfbcd3c
  }
}

// class id: 5143, size: 0x6c, field offset: 0x60
class _LisTileDefaultsM2 extends ListTileThemeData {

  late final ThemeData _theme; // offset: 0x64
  late final TextTheme _textTheme; // offset: 0x68

  TextTheme _textTheme(_LisTileDefaultsM2) {
    // ** addr: 0xfbcc40, size: 0x58
    // 0xfbcc40: EnterFrame
    //     0xfbcc40: stp             fp, lr, [SP, #-0x10]!
    //     0xfbcc44: mov             fp, SP
    // 0xfbcc48: CheckStackOverflow
    //     0xfbcc48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbcc4c: cmp             SP, x16
    //     0xfbcc50: b.ls            #0xfbcc90
    // 0xfbcc54: ldr             x1, [fp, #0x10]
    // 0xfbcc58: LoadField: r0 = r1->field_63
    //     0xfbcc58: ldur            w0, [x1, #0x63]
    // 0xfbcc5c: DecompressPointer r0
    //     0xfbcc5c: add             x0, x0, HEAP, lsl #32
    // 0xfbcc60: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbcc64: cmp             w0, w16
    // 0xfbcc68: b.ne            #0xfbcc78
    // 0xfbcc6c: r2 = _theme
    //     0xfbcc6c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26328] Field <_LisTileDefaultsM2@97247952._theme@97247952>: late final (offset: 0x64)
    //     0xfbcc70: ldr             x2, [x2, #0x328]
    // 0xfbcc74: r0 = InitLateFinalInstanceField()
    //     0xfbcc74: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbcc78: LoadField: r1 = r0->field_87
    //     0xfbcc78: ldur            w1, [x0, #0x87]
    // 0xfbcc7c: DecompressPointer r1
    //     0xfbcc7c: add             x1, x1, HEAP, lsl #32
    // 0xfbcc80: mov             x0, x1
    // 0xfbcc84: LeaveFrame
    //     0xfbcc84: mov             SP, fp
    //     0xfbcc88: ldp             fp, lr, [SP], #0x10
    // 0xfbcc8c: ret
    //     0xfbcc8c: ret             
    // 0xfbcc90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbcc90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbcc94: b               #0xfbcc54
  }
  ThemeData _theme(_LisTileDefaultsM2) {
    // ** addr: 0xfbccf0, size: 0x38
    // 0xfbccf0: EnterFrame
    //     0xfbccf0: stp             fp, lr, [SP, #-0x10]!
    //     0xfbccf4: mov             fp, SP
    // 0xfbccf8: CheckStackOverflow
    //     0xfbccf8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbccfc: cmp             SP, x16
    //     0xfbcd00: b.ls            #0xfbcd20
    // 0xfbcd04: ldr             x0, [fp, #0x10]
    // 0xfbcd08: LoadField: r1 = r0->field_5f
    //     0xfbcd08: ldur            w1, [x0, #0x5f]
    // 0xfbcd0c: DecompressPointer r1
    //     0xfbcd0c: add             x1, x1, HEAP, lsl #32
    // 0xfbcd10: r0 = of()
    //     0xfbcd10: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfbcd14: LeaveFrame
    //     0xfbcd14: mov             SP, fp
    //     0xfbcd18: ldp             fp, lr, [SP], #0x10
    // 0xfbcd1c: ret
    //     0xfbcd1c: ret             
    // 0xfbcd20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbcd20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbcd24: b               #0xfbcd04
  }
}

// class id: 6153, size: 0xa0, field offset: 0xc
//   const constructor, 
class ListTile extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfbb41c, size: 0x17f4
    // 0xfbb41c: EnterFrame
    //     0xfbb41c: stp             fp, lr, [SP, #-0x10]!
    //     0xfbb420: mov             fp, SP
    // 0xfbb424: AllocStack(0x118)
    //     0xfbb424: sub             SP, SP, #0x118
    // 0xfbb428: SetupParameters(ListTile this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfbb428: mov             x0, x2
    //     0xfbb42c: stur            x2, [fp, #-0x10]
    //     0xfbb430: mov             x2, x1
    //     0xfbb434: stur            x1, [fp, #-8]
    // 0xfbb438: CheckStackOverflow
    //     0xfbb438: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbb43c: cmp             SP, x16
    //     0xfbb440: b.ls            #0xfbcbc8
    // 0xfbb444: mov             x1, x0
    // 0xfbb448: r0 = of()
    //     0xfbb448: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfbb44c: ldur            x1, [fp, #-0x10]
    // 0xfbb450: stur            x0, [fp, #-0x18]
    // 0xfbb454: r0 = of()
    //     0xfbb454: bl              #0xd2d638  ; [package:flutter/src/material/icon_button_theme.dart] IconButtonTheme::of
    // 0xfbb458: ldur            x1, [fp, #-0x10]
    // 0xfbb45c: stur            x0, [fp, #-0x20]
    // 0xfbb460: r0 = of()
    //     0xfbb460: bl              #0xd1a0e4  ; [package:flutter/src/material/list_tile_theme.dart] ListTileTheme::of
    // 0xfbb464: stur            x0, [fp, #-0x30]
    // 0xfbb468: LoadField: r1 = r0->field_f
    //     0xfbb468: ldur            w1, [x0, #0xf]
    // 0xfbb46c: DecompressPointer r1
    //     0xfbb46c: add             x1, x1, HEAP, lsl #32
    // 0xfbb470: cmp             w1, NULL
    // 0xfbb474: b.ne            #0xfbb494
    // 0xfbb478: ldur            x2, [fp, #-0x18]
    // 0xfbb47c: LoadField: r1 = r2->field_eb
    //     0xfbb47c: ldur            w1, [x2, #0xeb]
    // 0xfbb480: DecompressPointer r1
    //     0xfbb480: add             x1, x1, HEAP, lsl #32
    // 0xfbb484: LoadField: r3 = r1->field_f
    //     0xfbb484: ldur            w3, [x1, #0xf]
    // 0xfbb488: DecompressPointer r3
    //     0xfbb488: add             x3, x3, HEAP, lsl #32
    // 0xfbb48c: mov             x1, x3
    // 0xfbb490: b               #0xfbb498
    // 0xfbb494: ldur            x2, [fp, #-0x18]
    // 0xfbb498: cmp             w1, NULL
    // 0xfbb49c: b.ne            #0xfbb4a8
    // 0xfbb4a0: r1 = Instance_ListTileStyle
    //     0xfbb4a0: add             x1, PP, #0x84, lsl #12  ; [pp+0x849f8] Obj!ListTileStyle@12c5561
    //     0xfbb4a4: ldr             x1, [x1, #0x9f8]
    // 0xfbb4a8: stur            x1, [fp, #-0x38]
    // 0xfbb4ac: LoadField: r3 = r2->field_2f
    //     0xfbb4ac: ldur            w3, [x2, #0x2f]
    // 0xfbb4b0: DecompressPointer r3
    //     0xfbb4b0: add             x3, x3, HEAP, lsl #32
    // 0xfbb4b4: stur            x3, [fp, #-0x28]
    // 0xfbb4b8: tbnz            w3, #4, #0xfbb52c
    // 0xfbb4bc: ldur            x1, [fp, #-0x10]
    // 0xfbb4c0: r0 = _LisTileDefaultsM3()
    //     0xfbb4c0: bl              #0xfbcc34  ; Allocate_LisTileDefaultsM3Stub -> _LisTileDefaultsM3 (size=0x70)
    // 0xfbb4c4: mov             x1, x0
    // 0xfbb4c8: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbb4cc: StoreField: r1->field_63 = r0
    //     0xfbb4cc: stur            w0, [x1, #0x63]
    // 0xfbb4d0: StoreField: r1->field_67 = r0
    //     0xfbb4d0: stur            w0, [x1, #0x67]
    // 0xfbb4d4: StoreField: r1->field_6b = r0
    //     0xfbb4d4: stur            w0, [x1, #0x6b]
    // 0xfbb4d8: ldur            x2, [fp, #-0x10]
    // 0xfbb4dc: StoreField: r1->field_5f = r2
    //     0xfbb4dc: stur            w2, [x1, #0x5f]
    // 0xfbb4e0: r0 = Instance_RoundedRectangleBorder
    //     0xfbb4e0: add             x0, PP, #0x26, lsl #12  ; [pp+0x26600] Obj!RoundedRectangleBorder@129ec31
    //     0xfbb4e4: ldr             x0, [x0, #0x600]
    // 0xfbb4e8: StoreField: r1->field_b = r0
    //     0xfbb4e8: stur            w0, [x1, #0xb]
    // 0xfbb4ec: r0 = Instance_EdgeInsetsDirectional
    //     0xfbb4ec: add             x0, PP, #0x84, lsl #12  ; [pp+0x84a00] Obj!EdgeInsetsDirectional@129c841
    //     0xfbb4f0: ldr             x0, [x0, #0xa00]
    // 0xfbb4f4: StoreField: r1->field_2b = r0
    //     0xfbb4f4: stur            w0, [x1, #0x2b]
    // 0xfbb4f8: r0 = 8.000000
    //     0xfbb4f8: add             x0, PP, #0x19, lsl #12  ; [pp+0x19e08] 8
    //     0xfbb4fc: ldr             x0, [x0, #0xe08]
    // 0xfbb500: StoreField: r1->field_3b = r0
    //     0xfbb500: stur            w0, [x1, #0x3b]
    // 0xfbb504: r0 = 24.000000
    //     0xfbb504: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0xfbb508: ldr             x0, [x0, #0x4d0]
    // 0xfbb50c: StoreField: r1->field_3f = r0
    //     0xfbb50c: stur            w0, [x1, #0x3f]
    // 0xfbb510: mov             x4, x1
    // 0xfbb514: mov             x0, x2
    // 0xfbb518: r3 = Instance_EdgeInsetsDirectional
    //     0xfbb518: add             x3, PP, #0x84, lsl #12  ; [pp+0x84a00] Obj!EdgeInsetsDirectional@129c841
    //     0xfbb51c: ldr             x3, [x3, #0xa00]
    // 0xfbb520: d1 = 8.000000
    //     0xfbb520: fmov            d1, #8.00000000
    // 0xfbb524: d0 = 24.000000
    //     0xfbb524: fmov            d0, #24.00000000
    // 0xfbb528: b               #0xfbb5a0
    // 0xfbb52c: ldur            x2, [fp, #-0x10]
    // 0xfbb530: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbb534: r0 = _LisTileDefaultsM2()
    //     0xfbb534: bl              #0xfbcc28  ; Allocate_LisTileDefaultsM2Stub -> _LisTileDefaultsM2 (size=0x6c)
    // 0xfbb538: mov             x1, x0
    // 0xfbb53c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbb540: StoreField: r1->field_63 = r0
    //     0xfbb540: stur            w0, [x1, #0x63]
    // 0xfbb544: StoreField: r1->field_67 = r0
    //     0xfbb544: stur            w0, [x1, #0x67]
    // 0xfbb548: ldur            x0, [fp, #-0x10]
    // 0xfbb54c: StoreField: r1->field_5f = r0
    //     0xfbb54c: stur            w0, [x1, #0x5f]
    // 0xfbb550: r2 = Instance_Border
    //     0xfbb550: add             x2, PP, #0x84, lsl #12  ; [pp+0x84a08] Obj!Border@129eb81
    //     0xfbb554: ldr             x2, [x2, #0xa08]
    // 0xfbb558: StoreField: r1->field_b = r2
    //     0xfbb558: stur            w2, [x1, #0xb]
    // 0xfbb55c: ldur            x2, [fp, #-0x38]
    // 0xfbb560: StoreField: r1->field_f = r2
    //     0xfbb560: stur            w2, [x1, #0xf]
    // 0xfbb564: r2 = Instance_EdgeInsets
    //     0xfbb564: add             x2, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0xfbb568: ldr             x2, [x2, #0x510]
    // 0xfbb56c: StoreField: r1->field_2b = r2
    //     0xfbb56c: stur            w2, [x1, #0x2b]
    // 0xfbb570: r2 = 4.000000
    //     0xfbb570: add             x2, PP, #0x19, lsl #12  ; [pp+0x19e28] 4
    //     0xfbb574: ldr             x2, [x2, #0xe28]
    // 0xfbb578: StoreField: r1->field_3b = r2
    //     0xfbb578: stur            w2, [x1, #0x3b]
    // 0xfbb57c: r2 = 40.000000
    //     0xfbb57c: add             x2, PP, #0x27, lsl #12  ; [pp+0x274a8] 40
    //     0xfbb580: ldr             x2, [x2, #0x4a8]
    // 0xfbb584: StoreField: r1->field_3f = r2
    //     0xfbb584: stur            w2, [x1, #0x3f]
    // 0xfbb588: mov             x4, x1
    // 0xfbb58c: r3 = Instance_EdgeInsets
    //     0xfbb58c: add             x3, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0xfbb590: ldr             x3, [x3, #0x510]
    // 0xfbb594: d1 = 4.000000
    //     0xfbb594: fmov            d1, #4.00000000
    // 0xfbb598: d0 = 40.000000
    //     0xfbb598: add             x17, PP, #0x13, lsl #12  ; [pp+0x13168] IMM: double(40) from 0x4044000000000000
    //     0xfbb59c: ldr             d0, [x17, #0x168]
    // 0xfbb5a0: ldur            x2, [fp, #-8]
    // 0xfbb5a4: stur            x4, [fp, #-0x48]
    // 0xfbb5a8: stur            x3, [fp, #-0x50]
    // 0xfbb5ac: stur            d1, [fp, #-0xe0]
    // 0xfbb5b0: stur            d0, [fp, #-0xe8]
    // 0xfbb5b4: r5 = LoadClassIdInstr(r4)
    //     0xfbb5b4: ldur            x5, [x4, #-1]
    //     0xfbb5b8: ubfx            x5, x5, #0xc, #0x14
    // 0xfbb5bc: stur            x5, [fp, #-0x40]
    // 0xfbb5c0: LoadField: r6 = r2->field_5f
    //     0xfbb5c0: ldur            w6, [x2, #0x5f]
    // 0xfbb5c4: DecompressPointer r6
    //     0xfbb5c4: add             x6, x6, HEAP, lsl #32
    // 0xfbb5c8: stur            x6, [fp, #-0x38]
    // 0xfbb5cc: r1 = Instance_Color
    //     0xfbb5cc: add             x1, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xfbb5d0: ldr             x1, [x1, #0x810]
    // 0xfbb5d4: r0 = toARGB32()
    //     0xfbb5d4: bl              #0x119defc  ; [dart:ui] Color::toARGB32
    // 0xfbb5d8: ubfx            x0, x0, #0, #0x20
    // 0xfbb5dc: and             w1, w0, #0xff000000
    // 0xfbb5e0: ubfx            x1, x1, #0, #0x20
    // 0xfbb5e4: asr             x0, x1, #0x18
    // 0xfbb5e8: cmp             x0, #0
    // 0xfbb5ec: b.le            #0xfbb5f8
    // 0xfbb5f0: r1 = true
    //     0xfbb5f0: add             x1, NULL, #0x20  ; true
    // 0xfbb5f4: b               #0xfbb624
    // 0xfbb5f8: r1 = Instance_Color
    //     0xfbb5f8: add             x1, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xfbb5fc: ldr             x1, [x1, #0x810]
    // 0xfbb600: r0 = toARGB32()
    //     0xfbb600: bl              #0x119defc  ; [dart:ui] Color::toARGB32
    // 0xfbb604: ubfx            x0, x0, #0, #0x20
    // 0xfbb608: and             w1, w0, #0xff000000
    // 0xfbb60c: ubfx            x1, x1, #0, #0x20
    // 0xfbb610: asr             x0, x1, #0x18
    // 0xfbb614: cmp             x0, #0
    // 0xfbb618: r16 = true
    //     0xfbb618: add             x16, NULL, #0x20  ; true
    // 0xfbb61c: r17 = false
    //     0xfbb61c: add             x17, NULL, #0x30  ; false
    // 0xfbb620: csel            x1, x16, x17, gt
    // 0xfbb624: ldur            x0, [fp, #-8]
    // 0xfbb628: LoadField: r2 = r0->field_4f
    //     0xfbb628: ldur            w2, [x0, #0x4f]
    // 0xfbb62c: DecompressPointer r2
    //     0xfbb62c: add             x2, x2, HEAP, lsl #32
    // 0xfbb630: stur            x2, [fp, #-0x58]
    // 0xfbb634: cmp             w2, NULL
    // 0xfbb638: b.ne            #0xfbb640
    // 0xfbb63c: tbz             w1, #4, #0xfbb640
    // 0xfbb640: r1 = <WidgetState>
    //     0xfbb640: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a10] TypeArguments: <WidgetState>
    //     0xfbb644: ldr             x1, [x1, #0xa10]
    // 0xfbb648: r0 = _Set()
    //     0xfbb648: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xfbb64c: mov             x3, x0
    // 0xfbb650: r0 = _Uint32List
    //     0xfbb650: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0xfbb654: stur            x3, [fp, #-0x68]
    // 0xfbb658: StoreField: r3->field_1b = r0
    //     0xfbb658: stur            w0, [x3, #0x1b]
    // 0xfbb65c: StoreField: r3->field_b = rZR
    //     0xfbb65c: stur            wzr, [x3, #0xb]
    // 0xfbb660: r4 = const []
    //     0xfbb660: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0xfbb664: StoreField: r3->field_f = r4
    //     0xfbb664: stur            w4, [x3, #0xf]
    // 0xfbb668: StoreField: r3->field_13 = rZR
    //     0xfbb668: stur            wzr, [x3, #0x13]
    // 0xfbb66c: ArrayStore: r3[0] = rZR  ; List_4
    //     0xfbb66c: stur            wzr, [x3, #0x17]
    // 0xfbb670: ldur            x5, [fp, #-8]
    // 0xfbb674: LoadField: r6 = r5->field_4b
    //     0xfbb674: ldur            w6, [x5, #0x4b]
    // 0xfbb678: DecompressPointer r6
    //     0xfbb678: add             x6, x6, HEAP, lsl #32
    // 0xfbb67c: stur            x6, [fp, #-0x60]
    // 0xfbb680: tbz             w6, #4, #0xfbb694
    // 0xfbb684: mov             x1, x3
    // 0xfbb688: r2 = Instance_WidgetState
    //     0xfbb688: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xfbb68c: ldr             x2, [x2, #0xa70]
    // 0xfbb690: r0 = add()
    //     0xfbb690: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xfbb694: ldur            x0, [fp, #-0x38]
    // 0xfbb698: tbnz            w0, #4, #0xfbb6ac
    // 0xfbb69c: ldur            x1, [fp, #-0x68]
    // 0xfbb6a0: r2 = Instance_WidgetState
    //     0xfbb6a0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xfbb6a4: ldr             x2, [x2, #0x100]
    // 0xfbb6a8: r0 = add()
    //     0xfbb6a8: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xfbb6ac: ldur            x0, [fp, #-8]
    // 0xfbb6b0: LoadField: r2 = r0->field_2b
    //     0xfbb6b0: ldur            w2, [x0, #0x2b]
    // 0xfbb6b4: DecompressPointer r2
    //     0xfbb6b4: add             x2, x2, HEAP, lsl #32
    // 0xfbb6b8: stur            x2, [fp, #-0x70]
    // 0xfbb6bc: r1 = <Color?>
    //     0xfbb6bc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xfbb6c0: ldr             x1, [x1, #0xa40]
    // 0xfbb6c4: r0 = _IndividualOverrides()
    //     0xfbb6c4: bl              #0xfbcc1c  ; Allocate_IndividualOverridesStub -> _IndividualOverrides (size=0x1c)
    // 0xfbb6c8: mov             x1, x0
    // 0xfbb6cc: ldur            x0, [fp, #-0x70]
    // 0xfbb6d0: StoreField: r1->field_13 = r0
    //     0xfbb6d0: stur            w0, [x1, #0x13]
    // 0xfbb6d4: ldur            x2, [fp, #-0x68]
    // 0xfbb6d8: r0 = resolve()
    //     0xfbb6d8: bl              #0xa061ec  ; [package:flutter/src/material/list_tile.dart] _IndividualOverrides::resolve
    // 0xfbb6dc: cmp             w0, NULL
    // 0xfbb6e0: b.ne            #0xfbb718
    // 0xfbb6e4: ldur            x0, [fp, #-0x30]
    // 0xfbb6e8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xfbb6e8: ldur            w2, [x0, #0x17]
    // 0xfbb6ec: DecompressPointer r2
    //     0xfbb6ec: add             x2, x2, HEAP, lsl #32
    // 0xfbb6f0: stur            x2, [fp, #-0x78]
    // 0xfbb6f4: r1 = <Color?>
    //     0xfbb6f4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xfbb6f8: ldr             x1, [x1, #0xa40]
    // 0xfbb6fc: r0 = _IndividualOverrides()
    //     0xfbb6fc: bl              #0xfbcc1c  ; Allocate_IndividualOverridesStub -> _IndividualOverrides (size=0x1c)
    // 0xfbb700: mov             x1, x0
    // 0xfbb704: ldur            x0, [fp, #-0x78]
    // 0xfbb708: StoreField: r1->field_b = r0
    //     0xfbb708: stur            w0, [x1, #0xb]
    // 0xfbb70c: StoreField: r1->field_f = r0
    //     0xfbb70c: stur            w0, [x1, #0xf]
    // 0xfbb710: ldur            x2, [fp, #-0x68]
    // 0xfbb714: r0 = resolve()
    //     0xfbb714: bl              #0xa061ec  ; [package:flutter/src/material/list_tile.dart] _IndividualOverrides::resolve
    // 0xfbb718: cmp             w0, NULL
    // 0xfbb71c: b.ne            #0xfbb764
    // 0xfbb720: ldur            x0, [fp, #-0x18]
    // 0xfbb724: LoadField: r1 = r0->field_eb
    //     0xfbb724: ldur            w1, [x0, #0xeb]
    // 0xfbb728: DecompressPointer r1
    //     0xfbb728: add             x1, x1, HEAP, lsl #32
    // 0xfbb72c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xfbb72c: ldur            w2, [x1, #0x17]
    // 0xfbb730: DecompressPointer r2
    //     0xfbb730: add             x2, x2, HEAP, lsl #32
    // 0xfbb734: stur            x2, [fp, #-0x78]
    // 0xfbb738: r1 = <Color?>
    //     0xfbb738: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xfbb73c: ldr             x1, [x1, #0xa40]
    // 0xfbb740: r0 = _IndividualOverrides()
    //     0xfbb740: bl              #0xfbcc1c  ; Allocate_IndividualOverridesStub -> _IndividualOverrides (size=0x1c)
    // 0xfbb744: mov             x1, x0
    // 0xfbb748: ldur            x0, [fp, #-0x78]
    // 0xfbb74c: StoreField: r1->field_b = r0
    //     0xfbb74c: stur            w0, [x1, #0xb]
    // 0xfbb750: StoreField: r1->field_f = r0
    //     0xfbb750: stur            w0, [x1, #0xf]
    // 0xfbb754: ldur            x2, [fp, #-0x68]
    // 0xfbb758: r0 = resolve()
    //     0xfbb758: bl              #0xa061ec  ; [package:flutter/src/material/list_tile.dart] _IndividualOverrides::resolve
    // 0xfbb75c: mov             x2, x0
    // 0xfbb760: b               #0xfbb768
    // 0xfbb764: mov             x2, x0
    // 0xfbb768: ldur            x0, [fp, #-0x40]
    // 0xfbb76c: stur            x2, [fp, #-0x78]
    // 0xfbb770: r17 = 5141
    //     0xfbb770: mov             x17, #0x1415
    // 0xfbb774: cmp             x0, x17
    // 0xfbb778: b.ne            #0xfbb790
    // 0xfbb77c: ldur            x3, [fp, #-0x48]
    // 0xfbb780: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xfbb780: ldur            w1, [x3, #0x17]
    // 0xfbb784: DecompressPointer r1
    //     0xfbb784: add             x1, x1, HEAP, lsl #32
    // 0xfbb788: mov             x2, x1
    // 0xfbb78c: b               #0xfbb84c
    // 0xfbb790: ldur            x3, [fp, #-0x48]
    // 0xfbb794: r17 = 5142
    //     0xfbb794: mov             x17, #0x1416
    // 0xfbb798: cmp             x0, x17
    // 0xfbb79c: b.ne            #0xfbb7f4
    // 0xfbb7a0: mov             x1, x3
    // 0xfbb7a4: LoadField: r0 = r1->field_67
    //     0xfbb7a4: ldur            w0, [x1, #0x67]
    // 0xfbb7a8: DecompressPointer r0
    //     0xfbb7a8: add             x0, x0, HEAP, lsl #32
    // 0xfbb7ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbb7b0: cmp             w0, w16
    // 0xfbb7b4: b.ne            #0xfbb7c4
    // 0xfbb7b8: r2 = _colors
    //     0xfbb7b8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0xfbb7bc: ldr             x2, [x2, #0x320]
    // 0xfbb7c0: r0 = InitLateFinalInstanceField()
    //     0xfbb7c0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbb7c4: LoadField: r1 = r0->field_a3
    //     0xfbb7c4: ldur            w1, [x0, #0xa3]
    // 0xfbb7c8: DecompressPointer r1
    //     0xfbb7c8: add             x1, x1, HEAP, lsl #32
    // 0xfbb7cc: cmp             w1, NULL
    // 0xfbb7d0: b.ne            #0xfbb7e4
    // 0xfbb7d4: LoadField: r1 = r0->field_7f
    //     0xfbb7d4: ldur            w1, [x0, #0x7f]
    // 0xfbb7d8: DecompressPointer r1
    //     0xfbb7d8: add             x1, x1, HEAP, lsl #32
    // 0xfbb7dc: mov             x0, x1
    // 0xfbb7e0: b               #0xfbb7e8
    // 0xfbb7e4: mov             x0, x1
    // 0xfbb7e8: mov             x2, x0
    // 0xfbb7ec: ldur            x0, [fp, #-0x40]
    // 0xfbb7f0: b               #0xfbb84c
    // 0xfbb7f4: ldur            x1, [fp, #-0x48]
    // 0xfbb7f8: LoadField: r0 = r1->field_63
    //     0xfbb7f8: ldur            w0, [x1, #0x63]
    // 0xfbb7fc: DecompressPointer r0
    //     0xfbb7fc: add             x0, x0, HEAP, lsl #32
    // 0xfbb800: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbb804: cmp             w0, w16
    // 0xfbb808: b.ne            #0xfbb818
    // 0xfbb80c: r2 = _theme
    //     0xfbb80c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26328] Field <_LisTileDefaultsM2@97247952._theme@97247952>: late final (offset: 0x64)
    //     0xfbb810: ldr             x2, [x2, #0x328]
    // 0xfbb814: r0 = InitLateFinalInstanceField()
    //     0xfbb814: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbb818: LoadField: r1 = r0->field_3f
    //     0xfbb818: ldur            w1, [x0, #0x3f]
    // 0xfbb81c: DecompressPointer r1
    //     0xfbb81c: add             x1, x1, HEAP, lsl #32
    // 0xfbb820: LoadField: r0 = r1->field_7
    //     0xfbb820: ldur            w0, [x1, #7]
    // 0xfbb824: DecompressPointer r0
    //     0xfbb824: add             x0, x0, HEAP, lsl #32
    // 0xfbb828: LoadField: r1 = r0->field_7
    //     0xfbb828: ldur            x1, [x0, #7]
    // 0xfbb82c: cmp             x1, #0
    // 0xfbb830: b.gt            #0xfbb83c
    // 0xfbb834: r0 = Null
    //     0xfbb834: mov             x0, NULL
    // 0xfbb838: b               #0xfbb844
    // 0xfbb83c: r0 = Instance_Color
    //     0xfbb83c: add             x0, PP, #0x26, lsl #12  ; [pp+0x26330] Obj!Color@12a2bb1
    //     0xfbb840: ldr             x0, [x0, #0x330]
    // 0xfbb844: mov             x2, x0
    // 0xfbb848: ldur            x0, [fp, #-0x40]
    // 0xfbb84c: stur            x2, [fp, #-0x80]
    // 0xfbb850: r17 = 5141
    //     0xfbb850: mov             x17, #0x1415
    // 0xfbb854: cmp             x0, x17
    // 0xfbb858: b.ne            #0xfbb870
    // 0xfbb85c: ldur            x3, [fp, #-0x48]
    // 0xfbb860: LoadField: r1 = r3->field_13
    //     0xfbb860: ldur            w1, [x3, #0x13]
    // 0xfbb864: DecompressPointer r1
    //     0xfbb864: add             x1, x1, HEAP, lsl #32
    // 0xfbb868: mov             x2, x1
    // 0xfbb86c: b               #0xfbb8f4
    // 0xfbb870: ldur            x3, [fp, #-0x48]
    // 0xfbb874: r17 = 5142
    //     0xfbb874: mov             x17, #0x1416
    // 0xfbb878: cmp             x0, x17
    // 0xfbb87c: b.ne            #0xfbb8b8
    // 0xfbb880: mov             x1, x3
    // 0xfbb884: LoadField: r0 = r1->field_67
    //     0xfbb884: ldur            w0, [x1, #0x67]
    // 0xfbb888: DecompressPointer r0
    //     0xfbb888: add             x0, x0, HEAP, lsl #32
    // 0xfbb88c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbb890: cmp             w0, w16
    // 0xfbb894: b.ne            #0xfbb8a4
    // 0xfbb898: r2 = _colors
    //     0xfbb898: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0xfbb89c: ldr             x2, [x2, #0x320]
    // 0xfbb8a0: r0 = InitLateFinalInstanceField()
    //     0xfbb8a0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbb8a4: LoadField: r1 = r0->field_b
    //     0xfbb8a4: ldur            w1, [x0, #0xb]
    // 0xfbb8a8: DecompressPointer r1
    //     0xfbb8a8: add             x1, x1, HEAP, lsl #32
    // 0xfbb8ac: mov             x2, x1
    // 0xfbb8b0: ldur            x0, [fp, #-0x40]
    // 0xfbb8b4: b               #0xfbb8f4
    // 0xfbb8b8: ldur            x1, [fp, #-0x48]
    // 0xfbb8bc: LoadField: r0 = r1->field_63
    //     0xfbb8bc: ldur            w0, [x1, #0x63]
    // 0xfbb8c0: DecompressPointer r0
    //     0xfbb8c0: add             x0, x0, HEAP, lsl #32
    // 0xfbb8c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbb8c8: cmp             w0, w16
    // 0xfbb8cc: b.ne            #0xfbb8dc
    // 0xfbb8d0: r2 = _theme
    //     0xfbb8d0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26328] Field <_LisTileDefaultsM2@97247952._theme@97247952>: late final (offset: 0x64)
    //     0xfbb8d4: ldr             x2, [x2, #0x328]
    // 0xfbb8d8: r0 = InitLateFinalInstanceField()
    //     0xfbb8d8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbb8dc: LoadField: r1 = r0->field_3f
    //     0xfbb8dc: ldur            w1, [x0, #0x3f]
    // 0xfbb8e0: DecompressPointer r1
    //     0xfbb8e0: add             x1, x1, HEAP, lsl #32
    // 0xfbb8e4: LoadField: r0 = r1->field_b
    //     0xfbb8e4: ldur            w0, [x1, #0xb]
    // 0xfbb8e8: DecompressPointer r0
    //     0xfbb8e8: add             x0, x0, HEAP, lsl #32
    // 0xfbb8ec: mov             x2, x0
    // 0xfbb8f0: ldur            x0, [fp, #-0x40]
    // 0xfbb8f4: stur            x2, [fp, #-0x88]
    // 0xfbb8f8: r17 = 5141
    //     0xfbb8f8: mov             x17, #0x1415
    // 0xfbb8fc: cmp             x0, x17
    // 0xfbb900: b.ne            #0xfbb91c
    // 0xfbb904: ldur            x3, [fp, #-0x48]
    // 0xfbb908: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xfbb908: ldur            w1, [x3, #0x17]
    // 0xfbb90c: DecompressPointer r1
    //     0xfbb90c: add             x1, x1, HEAP, lsl #32
    // 0xfbb910: mov             x5, x1
    // 0xfbb914: mov             x0, x2
    // 0xfbb918: b               #0xfbb9d8
    // 0xfbb91c: ldur            x3, [fp, #-0x48]
    // 0xfbb920: r17 = 5142
    //     0xfbb920: mov             x17, #0x1416
    // 0xfbb924: cmp             x0, x17
    // 0xfbb928: b.ne            #0xfbb980
    // 0xfbb92c: mov             x1, x3
    // 0xfbb930: LoadField: r0 = r1->field_67
    //     0xfbb930: ldur            w0, [x1, #0x67]
    // 0xfbb934: DecompressPointer r0
    //     0xfbb934: add             x0, x0, HEAP, lsl #32
    // 0xfbb938: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbb93c: cmp             w0, w16
    // 0xfbb940: b.ne            #0xfbb950
    // 0xfbb944: r2 = _colors
    //     0xfbb944: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0xfbb948: ldr             x2, [x2, #0x320]
    // 0xfbb94c: r0 = InitLateFinalInstanceField()
    //     0xfbb94c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbb950: LoadField: r1 = r0->field_a3
    //     0xfbb950: ldur            w1, [x0, #0xa3]
    // 0xfbb954: DecompressPointer r1
    //     0xfbb954: add             x1, x1, HEAP, lsl #32
    // 0xfbb958: cmp             w1, NULL
    // 0xfbb95c: b.ne            #0xfbb970
    // 0xfbb960: LoadField: r1 = r0->field_7f
    //     0xfbb960: ldur            w1, [x0, #0x7f]
    // 0xfbb964: DecompressPointer r1
    //     0xfbb964: add             x1, x1, HEAP, lsl #32
    // 0xfbb968: mov             x0, x1
    // 0xfbb96c: b               #0xfbb974
    // 0xfbb970: mov             x0, x1
    // 0xfbb974: mov             x5, x0
    // 0xfbb978: ldur            x0, [fp, #-0x88]
    // 0xfbb97c: b               #0xfbb9d8
    // 0xfbb980: ldur            x1, [fp, #-0x48]
    // 0xfbb984: LoadField: r0 = r1->field_63
    //     0xfbb984: ldur            w0, [x1, #0x63]
    // 0xfbb988: DecompressPointer r0
    //     0xfbb988: add             x0, x0, HEAP, lsl #32
    // 0xfbb98c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbb990: cmp             w0, w16
    // 0xfbb994: b.ne            #0xfbb9a4
    // 0xfbb998: r2 = _theme
    //     0xfbb998: add             x2, PP, #0x26, lsl #12  ; [pp+0x26328] Field <_LisTileDefaultsM2@97247952._theme@97247952>: late final (offset: 0x64)
    //     0xfbb99c: ldr             x2, [x2, #0x328]
    // 0xfbb9a0: r0 = InitLateFinalInstanceField()
    //     0xfbb9a0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbb9a4: LoadField: r1 = r0->field_3f
    //     0xfbb9a4: ldur            w1, [x0, #0x3f]
    // 0xfbb9a8: DecompressPointer r1
    //     0xfbb9a8: add             x1, x1, HEAP, lsl #32
    // 0xfbb9ac: LoadField: r0 = r1->field_7
    //     0xfbb9ac: ldur            w0, [x1, #7]
    // 0xfbb9b0: DecompressPointer r0
    //     0xfbb9b0: add             x0, x0, HEAP, lsl #32
    // 0xfbb9b4: LoadField: r1 = r0->field_7
    //     0xfbb9b4: ldur            x1, [x0, #7]
    // 0xfbb9b8: cmp             x1, #0
    // 0xfbb9bc: b.gt            #0xfbb9c8
    // 0xfbb9c0: r0 = Null
    //     0xfbb9c0: mov             x0, NULL
    // 0xfbb9c4: b               #0xfbb9d0
    // 0xfbb9c8: r0 = Instance_Color
    //     0xfbb9c8: add             x0, PP, #0x26, lsl #12  ; [pp+0x26330] Obj!Color@12a2bb1
    //     0xfbb9cc: ldr             x0, [x0, #0x330]
    // 0xfbb9d0: mov             x5, x0
    // 0xfbb9d4: ldur            x0, [fp, #-0x88]
    // 0xfbb9d8: ldur            x4, [fp, #-0x18]
    // 0xfbb9dc: ldur            x3, [fp, #-0x78]
    // 0xfbb9e0: ldur            x2, [fp, #-0x80]
    // 0xfbb9e4: stur            x5, [fp, #-0x98]
    // 0xfbb9e8: LoadField: r6 = r4->field_43
    //     0xfbb9e8: ldur            w6, [x4, #0x43]
    // 0xfbb9ec: DecompressPointer r6
    //     0xfbb9ec: add             x6, x6, HEAP, lsl #32
    // 0xfbb9f0: stur            x6, [fp, #-0x90]
    // 0xfbb9f4: r1 = <Color?>
    //     0xfbb9f4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xfbb9f8: ldr             x1, [x1, #0xa40]
    // 0xfbb9fc: r0 = _IndividualOverrides()
    //     0xfbb9fc: bl              #0xfbcc1c  ; Allocate_IndividualOverridesStub -> _IndividualOverrides (size=0x1c)
    // 0xfbba00: mov             x1, x0
    // 0xfbba04: ldur            x0, [fp, #-0x80]
    // 0xfbba08: StoreField: r1->field_b = r0
    //     0xfbba08: stur            w0, [x1, #0xb]
    // 0xfbba0c: ldur            x0, [fp, #-0x98]
    // 0xfbba10: StoreField: r1->field_f = r0
    //     0xfbba10: stur            w0, [x1, #0xf]
    // 0xfbba14: ldur            x0, [fp, #-0x88]
    // 0xfbba18: StoreField: r1->field_13 = r0
    //     0xfbba18: stur            w0, [x1, #0x13]
    // 0xfbba1c: ldur            x0, [fp, #-0x90]
    // 0xfbba20: ArrayStore: r1[0] = r0  ; List_4
    //     0xfbba20: stur            w0, [x1, #0x17]
    // 0xfbba24: ldur            x2, [fp, #-0x68]
    // 0xfbba28: r0 = resolve()
    //     0xfbba28: bl              #0xa061ec  ; [package:flutter/src/material/list_tile.dart] _IndividualOverrides::resolve
    // 0xfbba2c: mov             x4, x0
    // 0xfbba30: ldur            x3, [fp, #-0x78]
    // 0xfbba34: stur            x4, [fp, #-0x80]
    // 0xfbba38: cmp             w3, NULL
    // 0xfbba3c: b.ne            #0xfbbaa4
    // 0xfbba40: ldur            x0, [fp, #-0x20]
    // 0xfbba44: LoadField: r1 = r0->field_7
    //     0xfbba44: ldur            w1, [x0, #7]
    // 0xfbba48: DecompressPointer r1
    //     0xfbba48: add             x1, x1, HEAP, lsl #32
    // 0xfbba4c: cmp             w1, NULL
    // 0xfbba50: b.ne            #0xfbba5c
    // 0xfbba54: r0 = Null
    //     0xfbba54: mov             x0, NULL
    // 0xfbba58: b               #0xfbbaa8
    // 0xfbba5c: LoadField: r0 = r1->field_f
    //     0xfbba5c: ldur            w0, [x1, #0xf]
    // 0xfbba60: DecompressPointer r0
    //     0xfbba60: add             x0, x0, HEAP, lsl #32
    // 0xfbba64: cmp             w0, NULL
    // 0xfbba68: b.ne            #0xfbba74
    // 0xfbba6c: r0 = Null
    //     0xfbba6c: mov             x0, NULL
    // 0xfbba70: b               #0xfbbaa8
    // 0xfbba74: r1 = LoadClassIdInstr(r0)
    //     0xfbba74: ldur            x1, [x0, #-1]
    //     0xfbba78: ubfx            x1, x1, #0xc, #0x14
    // 0xfbba7c: mov             x16, x0
    // 0xfbba80: mov             x0, x1
    // 0xfbba84: mov             x1, x16
    // 0xfbba88: ldur            x2, [fp, #-0x68]
    // 0xfbba8c: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xfbba8c: mov             x17, #0x7c77
    //     0xfbba90: movk            x17, #1, lsl #16
    //     0xfbba94: add             lr, x0, x17
    //     0xfbba98: ldr             lr, [x21, lr, lsl #3]
    //     0xfbba9c: blr             lr
    // 0xfbbaa0: b               #0xfbbaa8
    // 0xfbbaa4: ldur            x0, [fp, #-0x78]
    // 0xfbbaa8: cmp             w0, NULL
    // 0xfbbaac: b.ne            #0xfbbab8
    // 0xfbbab0: ldur            x2, [fp, #-0x80]
    // 0xfbbab4: b               #0xfbbabc
    // 0xfbbab8: mov             x2, x0
    // 0xfbbabc: ldur            x0, [fp, #-0x78]
    // 0xfbbac0: stur            x2, [fp, #-0x88]
    // 0xfbbac4: cmp             w0, NULL
    // 0xfbbac8: b.ne            #0xfbbad4
    // 0xfbbacc: ldur            x3, [fp, #-0x80]
    // 0xfbbad0: b               #0xfbbad8
    // 0xfbbad4: mov             x3, x0
    // 0xfbbad8: ldur            x0, [fp, #-0x70]
    // 0xfbbadc: stur            x3, [fp, #-0x20]
    // 0xfbbae0: r1 = <Color?>
    //     0xfbbae0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xfbbae4: ldr             x1, [x1, #0xa40]
    // 0xfbbae8: r0 = _IndividualOverrides()
    //     0xfbbae8: bl              #0xfbcc1c  ; Allocate_IndividualOverridesStub -> _IndividualOverrides (size=0x1c)
    // 0xfbbaec: mov             x1, x0
    // 0xfbbaf0: ldur            x0, [fp, #-0x70]
    // 0xfbbaf4: StoreField: r1->field_13 = r0
    //     0xfbbaf4: stur            w0, [x1, #0x13]
    // 0xfbbaf8: ldur            x2, [fp, #-0x68]
    // 0xfbbafc: r0 = resolve()
    //     0xfbbafc: bl              #0xa061ec  ; [package:flutter/src/material/list_tile.dart] _IndividualOverrides::resolve
    // 0xfbbb00: cmp             w0, NULL
    // 0xfbbb04: b.ne            #0xfbbb3c
    // 0xfbbb08: ldur            x0, [fp, #-0x30]
    // 0xfbbb0c: LoadField: r2 = r0->field_1b
    //     0xfbbb0c: ldur            w2, [x0, #0x1b]
    // 0xfbbb10: DecompressPointer r2
    //     0xfbbb10: add             x2, x2, HEAP, lsl #32
    // 0xfbbb14: stur            x2, [fp, #-0x70]
    // 0xfbbb18: r1 = <Color?>
    //     0xfbbb18: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xfbbb1c: ldr             x1, [x1, #0xa40]
    // 0xfbbb20: r0 = _IndividualOverrides()
    //     0xfbbb20: bl              #0xfbcc1c  ; Allocate_IndividualOverridesStub -> _IndividualOverrides (size=0x1c)
    // 0xfbbb24: mov             x1, x0
    // 0xfbbb28: ldur            x0, [fp, #-0x70]
    // 0xfbbb2c: StoreField: r1->field_b = r0
    //     0xfbbb2c: stur            w0, [x1, #0xb]
    // 0xfbbb30: StoreField: r1->field_f = r0
    //     0xfbbb30: stur            w0, [x1, #0xf]
    // 0xfbbb34: ldur            x2, [fp, #-0x68]
    // 0xfbbb38: r0 = resolve()
    //     0xfbbb38: bl              #0xa061ec  ; [package:flutter/src/material/list_tile.dart] _IndividualOverrides::resolve
    // 0xfbbb3c: cmp             w0, NULL
    // 0xfbbb40: b.ne            #0xfbbb80
    // 0xfbbb44: ldur            x0, [fp, #-0x18]
    // 0xfbbb48: LoadField: r1 = r0->field_eb
    //     0xfbbb48: ldur            w1, [x0, #0xeb]
    // 0xfbbb4c: DecompressPointer r1
    //     0xfbbb4c: add             x1, x1, HEAP, lsl #32
    // 0xfbbb50: LoadField: r2 = r1->field_1b
    //     0xfbbb50: ldur            w2, [x1, #0x1b]
    // 0xfbbb54: DecompressPointer r2
    //     0xfbbb54: add             x2, x2, HEAP, lsl #32
    // 0xfbbb58: stur            x2, [fp, #-0x70]
    // 0xfbbb5c: r1 = <Color?>
    //     0xfbbb5c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xfbbb60: ldr             x1, [x1, #0xa40]
    // 0xfbbb64: r0 = _IndividualOverrides()
    //     0xfbbb64: bl              #0xfbcc1c  ; Allocate_IndividualOverridesStub -> _IndividualOverrides (size=0x1c)
    // 0xfbbb68: mov             x1, x0
    // 0xfbbb6c: ldur            x0, [fp, #-0x70]
    // 0xfbbb70: StoreField: r1->field_b = r0
    //     0xfbbb70: stur            w0, [x1, #0xb]
    // 0xfbbb74: StoreField: r1->field_f = r0
    //     0xfbbb74: stur            w0, [x1, #0xf]
    // 0xfbbb78: ldur            x2, [fp, #-0x68]
    // 0xfbbb7c: r0 = resolve()
    //     0xfbbb7c: bl              #0xa061ec  ; [package:flutter/src/material/list_tile.dart] _IndividualOverrides::resolve
    // 0xfbbb80: cmp             w0, NULL
    // 0xfbbb84: b.ne            #0xfbbc80
    // 0xfbbb88: ldur            x2, [fp, #-0x48]
    // 0xfbbb8c: ldur            x0, [fp, #-0x40]
    // 0xfbbb90: LoadField: r3 = r2->field_1b
    //     0xfbbb90: ldur            w3, [x2, #0x1b]
    // 0xfbbb94: DecompressPointer r3
    //     0xfbbb94: add             x3, x3, HEAP, lsl #32
    // 0xfbbb98: stur            x3, [fp, #-0x70]
    // 0xfbbb9c: r17 = 5141
    //     0xfbbb9c: mov             x17, #0x1415
    // 0xfbbba0: cmp             x0, x17
    // 0xfbbba4: b.ne            #0xfbbbbc
    // 0xfbbba8: LoadField: r1 = r2->field_13
    //     0xfbbba8: ldur            w1, [x2, #0x13]
    // 0xfbbbac: DecompressPointer r1
    //     0xfbbbac: add             x1, x1, HEAP, lsl #32
    // 0xfbbbb0: mov             x0, x3
    // 0xfbbbb4: mov             x3, x1
    // 0xfbbbb8: b               #0xfbbc3c
    // 0xfbbbbc: r17 = 5142
    //     0xfbbbbc: mov             x17, #0x1416
    // 0xfbbbc0: cmp             x0, x17
    // 0xfbbbc4: b.ne            #0xfbbc00
    // 0xfbbbc8: mov             x1, x2
    // 0xfbbbcc: LoadField: r0 = r1->field_67
    //     0xfbbbcc: ldur            w0, [x1, #0x67]
    // 0xfbbbd0: DecompressPointer r0
    //     0xfbbbd0: add             x0, x0, HEAP, lsl #32
    // 0xfbbbd4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbbbd8: cmp             w0, w16
    // 0xfbbbdc: b.ne            #0xfbbbec
    // 0xfbbbe0: r2 = _colors
    //     0xfbbbe0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0xfbbbe4: ldr             x2, [x2, #0x320]
    // 0xfbbbe8: r0 = InitLateFinalInstanceField()
    //     0xfbbbe8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbbbec: LoadField: r1 = r0->field_b
    //     0xfbbbec: ldur            w1, [x0, #0xb]
    // 0xfbbbf0: DecompressPointer r1
    //     0xfbbbf0: add             x1, x1, HEAP, lsl #32
    // 0xfbbbf4: mov             x3, x1
    // 0xfbbbf8: ldur            x0, [fp, #-0x70]
    // 0xfbbbfc: b               #0xfbbc3c
    // 0xfbbc00: ldur            x1, [fp, #-0x48]
    // 0xfbbc04: LoadField: r0 = r1->field_63
    //     0xfbbc04: ldur            w0, [x1, #0x63]
    // 0xfbbc08: DecompressPointer r0
    //     0xfbbc08: add             x0, x0, HEAP, lsl #32
    // 0xfbbc0c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbbc10: cmp             w0, w16
    // 0xfbbc14: b.ne            #0xfbbc24
    // 0xfbbc18: r2 = _theme
    //     0xfbbc18: add             x2, PP, #0x26, lsl #12  ; [pp+0x26328] Field <_LisTileDefaultsM2@97247952._theme@97247952>: late final (offset: 0x64)
    //     0xfbbc1c: ldr             x2, [x2, #0x328]
    // 0xfbbc20: r0 = InitLateFinalInstanceField()
    //     0xfbbc20: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbbc24: LoadField: r1 = r0->field_3f
    //     0xfbbc24: ldur            w1, [x0, #0x3f]
    // 0xfbbc28: DecompressPointer r1
    //     0xfbbc28: add             x1, x1, HEAP, lsl #32
    // 0xfbbc2c: LoadField: r0 = r1->field_b
    //     0xfbbc2c: ldur            w0, [x1, #0xb]
    // 0xfbbc30: DecompressPointer r0
    //     0xfbbc30: add             x0, x0, HEAP, lsl #32
    // 0xfbbc34: mov             x3, x0
    // 0xfbbc38: ldur            x0, [fp, #-0x70]
    // 0xfbbc3c: ldur            x2, [fp, #-0x90]
    // 0xfbbc40: stur            x3, [fp, #-0x78]
    // 0xfbbc44: r1 = <Color?>
    //     0xfbbc44: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xfbbc48: ldr             x1, [x1, #0xa40]
    // 0xfbbc4c: r0 = _IndividualOverrides()
    //     0xfbbc4c: bl              #0xfbcc1c  ; Allocate_IndividualOverridesStub -> _IndividualOverrides (size=0x1c)
    // 0xfbbc50: mov             x1, x0
    // 0xfbbc54: ldur            x0, [fp, #-0x70]
    // 0xfbbc58: StoreField: r1->field_b = r0
    //     0xfbbc58: stur            w0, [x1, #0xb]
    // 0xfbbc5c: StoreField: r1->field_f = r0
    //     0xfbbc5c: stur            w0, [x1, #0xf]
    // 0xfbbc60: ldur            x0, [fp, #-0x78]
    // 0xfbbc64: StoreField: r1->field_13 = r0
    //     0xfbbc64: stur            w0, [x1, #0x13]
    // 0xfbbc68: ldur            x0, [fp, #-0x90]
    // 0xfbbc6c: ArrayStore: r1[0] = r0  ; List_4
    //     0xfbbc6c: stur            w0, [x1, #0x17]
    // 0xfbbc70: ldur            x2, [fp, #-0x68]
    // 0xfbbc74: r0 = resolve()
    //     0xfbbc74: bl              #0xa061ec  ; [package:flutter/src/material/list_tile.dart] _IndividualOverrides::resolve
    // 0xfbbc78: mov             x1, x0
    // 0xfbbc7c: b               #0xfbbc84
    // 0xfbbc80: mov             x1, x0
    // 0xfbbc84: ldur            x0, [fp, #-0x20]
    // 0xfbbc88: stur            x1, [fp, #-0x68]
    // 0xfbbc8c: r0 = IconThemeData()
    //     0xfbbc8c: bl              #0x8ac78c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0xfbbc90: mov             x2, x0
    // 0xfbbc94: ldur            x0, [fp, #-0x20]
    // 0xfbbc98: stur            x2, [fp, #-0x70]
    // 0xfbbc9c: StoreField: r2->field_1b = r0
    //     0xfbbc9c: stur            w0, [x2, #0x1b]
    // 0xfbbca0: ldur            x1, [fp, #-0x10]
    // 0xfbbca4: r0 = of()
    //     0xfbbca4: bl              #0xd2d638  ; [package:flutter/src/material/icon_button_theme.dart] IconButtonTheme::of
    // 0xfbbca8: LoadField: r2 = r0->field_7
    //     0xfbbca8: ldur            w2, [x0, #7]
    // 0xfbbcac: DecompressPointer r2
    //     0xfbbcac: add             x2, x2, HEAP, lsl #32
    // 0xfbbcb0: stur            x2, [fp, #-0x20]
    // 0xfbbcb4: cmp             w2, NULL
    // 0xfbbcb8: b.ne            #0xfbbcc4
    // 0xfbbcbc: r0 = Null
    //     0xfbbcbc: mov             x0, NULL
    // 0xfbbcc0: b               #0xfbbcf4
    // 0xfbbcc4: ldur            x0, [fp, #-0x88]
    // 0xfbbcc8: r1 = <Color?>
    //     0xfbbcc8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xfbbccc: ldr             x1, [x1, #0xa40]
    // 0xfbbcd0: r0 = WidgetStatePropertyAll()
    //     0xfbbcd0: bl              #0xd132c8  ; AllocateWidgetStatePropertyAllStub -> WidgetStatePropertyAll<X0> (size=0x10)
    // 0xfbbcd4: mov             x1, x0
    // 0xfbbcd8: ldur            x0, [fp, #-0x88]
    // 0xfbbcdc: StoreField: r1->field_b = r0
    //     0xfbbcdc: stur            w0, [x1, #0xb]
    // 0xfbbce0: str             x1, [SP]
    // 0xfbbce4: ldur            x1, [fp, #-0x20]
    // 0xfbbce8: r4 = const [0, 0x2, 0x1, 0x1, foregroundColor, 0x1, null]
    //     0xfbbce8: add             x4, PP, #0x84, lsl #12  ; [pp+0x84a18] List(7) [0, 0x2, 0x1, 0x1, "foregroundColor", 0x1, Null]
    //     0xfbbcec: ldr             x4, [x4, #0xa18]
    // 0xfbbcf0: r0 = copyWith()
    //     0xfbbcf0: bl              #0xd2991c  ; [package:flutter/src/material/button_style.dart] ButtonStyle::copyWith
    // 0xfbbcf4: cmp             w0, NULL
    // 0xfbbcf8: b.ne            #0xfbbd18
    // 0xfbbcfc: ldur            x16, [fp, #-0x88]
    // 0xfbbd00: str             x16, [SP]
    // 0xfbbd04: r4 = const [0, 0x1, 0x1, 0, foregroundColor, 0, null]
    //     0xfbbd04: add             x4, PP, #0x84, lsl #12  ; [pp+0x84a20] List(7) [0, 0x1, 0x1, 0, "foregroundColor", 0, Null]
    //     0xfbbd08: ldr             x4, [x4, #0xa20]
    // 0xfbbd0c: r0 = styleFrom()
    //     0xfbbd0c: bl              #0xdea068  ; [package:flutter/src/material/icon_button.dart] IconButton::styleFrom
    // 0xfbbd10: mov             x1, x0
    // 0xfbbd14: b               #0xfbbd1c
    // 0xfbbd18: mov             x1, x0
    // 0xfbbd1c: ldur            x0, [fp, #-8]
    // 0xfbbd20: stur            x1, [fp, #-0x20]
    // 0xfbbd24: r0 = IconButtonThemeData()
    //     0xfbbd24: bl              #0xd29654  ; AllocateIconButtonThemeDataStub -> IconButtonThemeData (size=0xc)
    // 0xfbbd28: mov             x2, x0
    // 0xfbbd2c: ldur            x0, [fp, #-0x20]
    // 0xfbbd30: stur            x2, [fp, #-0x78]
    // 0xfbbd34: StoreField: r2->field_7 = r0
    //     0xfbbd34: stur            w0, [x2, #7]
    // 0xfbbd38: ldur            x0, [fp, #-8]
    // 0xfbbd3c: LoadField: r3 = r0->field_b
    //     0xfbbd3c: ldur            w3, [x0, #0xb]
    // 0xfbbd40: DecompressPointer r3
    //     0xfbbd40: add             x3, x3, HEAP, lsl #32
    // 0xfbbd44: stur            x3, [fp, #-0x20]
    // 0xfbbd48: cmp             w3, NULL
    // 0xfbbd4c: b.ne            #0xfbbd60
    // 0xfbbd50: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xfbbd50: ldur            w1, [x0, #0x17]
    // 0xfbbd54: DecompressPointer r1
    //     0xfbbd54: add             x1, x1, HEAP, lsl #32
    // 0xfbbd58: cmp             w1, NULL
    // 0xfbbd5c: b.eq            #0xfbbe7c
    // 0xfbbd60: ldur            x4, [fp, #-0x40]
    // 0xfbbd64: r17 = 5141
    //     0xfbbd64: mov             x17, #0x1415
    // 0xfbbd68: cmp             x4, x17
    // 0xfbbd6c: b.ne            #0xfbbd80
    // 0xfbbd70: ldur            x5, [fp, #-0x48]
    // 0xfbbd74: LoadField: r1 = r5->field_27
    //     0xfbbd74: ldur            w1, [x5, #0x27]
    // 0xfbbd78: DecompressPointer r1
    //     0xfbbd78: add             x1, x1, HEAP, lsl #32
    // 0xfbbd7c: b               #0xfbbe58
    // 0xfbbd80: ldur            x5, [fp, #-0x48]
    // 0xfbbd84: r17 = 5142
    //     0xfbbd84: mov             x17, #0x1416
    // 0xfbbd88: cmp             x4, x17
    // 0xfbbd8c: b.ne            #0xfbbe2c
    // 0xfbbd90: mov             x1, x5
    // 0xfbbd94: LoadField: r0 = r1->field_6b
    //     0xfbbd94: ldur            w0, [x1, #0x6b]
    // 0xfbbd98: DecompressPointer r0
    //     0xfbbd98: add             x0, x0, HEAP, lsl #32
    // 0xfbbd9c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbbda0: cmp             w0, w16
    // 0xfbbda4: b.ne            #0xfbbdb4
    // 0xfbbda8: r2 = _textTheme
    //     0xfbbda8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26338] Field <_LisTileDefaultsM3@97247952._textTheme@97247952>: late final (offset: 0x6c)
    //     0xfbbdac: ldr             x2, [x2, #0x338]
    // 0xfbbdb0: r0 = InitLateFinalInstanceField()
    //     0xfbbdb0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbbdb4: LoadField: r2 = r0->field_3f
    //     0xfbbdb4: ldur            w2, [x0, #0x3f]
    // 0xfbbdb8: DecompressPointer r2
    //     0xfbbdb8: add             x2, x2, HEAP, lsl #32
    // 0xfbbdbc: stur            x2, [fp, #-0x80]
    // 0xfbbdc0: cmp             w2, NULL
    // 0xfbbdc4: b.eq            #0xfbcbd0
    // 0xfbbdc8: ldur            x1, [fp, #-0x48]
    // 0xfbbdcc: LoadField: r0 = r1->field_67
    //     0xfbbdcc: ldur            w0, [x1, #0x67]
    // 0xfbbdd0: DecompressPointer r0
    //     0xfbbdd0: add             x0, x0, HEAP, lsl #32
    // 0xfbbdd4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbbdd8: cmp             w0, w16
    // 0xfbbddc: b.ne            #0xfbbdec
    // 0xfbbde0: r2 = _colors
    //     0xfbbde0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0xfbbde4: ldr             x2, [x2, #0x320]
    // 0xfbbde8: r0 = InitLateFinalInstanceField()
    //     0xfbbde8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbbdec: LoadField: r1 = r0->field_a3
    //     0xfbbdec: ldur            w1, [x0, #0xa3]
    // 0xfbbdf0: DecompressPointer r1
    //     0xfbbdf0: add             x1, x1, HEAP, lsl #32
    // 0xfbbdf4: cmp             w1, NULL
    // 0xfbbdf8: b.ne            #0xfbbe0c
    // 0xfbbdfc: LoadField: r1 = r0->field_7f
    //     0xfbbdfc: ldur            w1, [x0, #0x7f]
    // 0xfbbe00: DecompressPointer r1
    //     0xfbbe00: add             x1, x1, HEAP, lsl #32
    // 0xfbbe04: mov             x0, x1
    // 0xfbbe08: b               #0xfbbe10
    // 0xfbbe0c: mov             x0, x1
    // 0xfbbe10: str             x0, [SP]
    // 0xfbbe14: ldur            x1, [fp, #-0x80]
    // 0xfbbe18: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xfbbe18: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xfbbe1c: ldr             x4, [x4, #0x7f0]
    // 0xfbbe20: r0 = copyWith()
    //     0xfbbe20: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xfbbe24: mov             x1, x0
    // 0xfbbe28: b               #0xfbbe58
    // 0xfbbe2c: ldur            x1, [fp, #-0x48]
    // 0xfbbe30: LoadField: r0 = r1->field_67
    //     0xfbbe30: ldur            w0, [x1, #0x67]
    // 0xfbbe34: DecompressPointer r0
    //     0xfbbe34: add             x0, x0, HEAP, lsl #32
    // 0xfbbe38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbbe3c: cmp             w0, w16
    // 0xfbbe40: b.ne            #0xfbbe50
    // 0xfbbe44: r2 = _textTheme
    //     0xfbbe44: add             x2, PP, #0x26, lsl #12  ; [pp+0x26340] Field <_LisTileDefaultsM2@97247952._textTheme@97247952>: late final (offset: 0x68)
    //     0xfbbe48: ldr             x2, [x2, #0x340]
    // 0xfbbe4c: r0 = InitLateFinalInstanceField()
    //     0xfbbe4c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbbe50: LoadField: r1 = r0->field_2f
    //     0xfbbe50: ldur            w1, [x0, #0x2f]
    // 0xfbbe54: DecompressPointer r1
    //     0xfbbe54: add             x1, x1, HEAP, lsl #32
    // 0xfbbe58: cmp             w1, NULL
    // 0xfbbe5c: b.eq            #0xfbcbd4
    // 0xfbbe60: ldur            x16, [fp, #-0x68]
    // 0xfbbe64: str             x16, [SP]
    // 0xfbbe68: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xfbbe68: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xfbbe6c: ldr             x4, [x4, #0x7f0]
    // 0xfbbe70: r0 = copyWith()
    //     0xfbbe70: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xfbbe74: mov             x1, x0
    // 0xfbbe78: b               #0xfbbe80
    // 0xfbbe7c: r1 = Null
    //     0xfbbe7c: mov             x1, NULL
    // 0xfbbe80: ldur            x0, [fp, #-0x20]
    // 0xfbbe84: stur            x1, [fp, #-0x80]
    // 0xfbbe88: cmp             w0, NULL
    // 0xfbbe8c: b.eq            #0xfbbeec
    // 0xfbbe90: cmp             w1, NULL
    // 0xfbbe94: b.eq            #0xfbcbd8
    // 0xfbbe98: r0 = AnimatedDefaultTextStyle()
    //     0xfbbe98: bl              #0xd2ad90  ; AllocateAnimatedDefaultTextStyleStub -> AnimatedDefaultTextStyle (size=0x38)
    // 0xfbbe9c: mov             x1, x0
    // 0xfbbea0: ldur            x0, [fp, #-0x20]
    // 0xfbbea4: ArrayStore: r1[0] = r0  ; List_4
    //     0xfbbea4: stur            w0, [x1, #0x17]
    // 0xfbbea8: ldur            x0, [fp, #-0x80]
    // 0xfbbeac: StoreField: r1->field_1b = r0
    //     0xfbbeac: stur            w0, [x1, #0x1b]
    // 0xfbbeb0: r2 = true
    //     0xfbbeb0: add             x2, NULL, #0x20  ; true
    // 0xfbbeb4: StoreField: r1->field_23 = r2
    //     0xfbbeb4: stur            w2, [x1, #0x23]
    // 0xfbbeb8: r3 = Instance_TextOverflow
    //     0xfbbeb8: add             x3, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xfbbebc: ldr             x3, [x3, #0x108]
    // 0xfbbec0: StoreField: r1->field_27 = r3
    //     0xfbbec0: stur            w3, [x1, #0x27]
    // 0xfbbec4: r4 = Instance_TextWidthBasis
    //     0xfbbec4: add             x4, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xfbbec8: ldr             x4, [x4, #0x110]
    // 0xfbbecc: StoreField: r1->field_2f = r4
    //     0xfbbecc: stur            w4, [x1, #0x2f]
    // 0xfbbed0: r5 = Instance__Linear
    //     0xfbbed0: ldr             x5, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xfbbed4: StoreField: r1->field_b = r5
    //     0xfbbed4: stur            w5, [x1, #0xb]
    // 0xfbbed8: r6 = Instance_Duration
    //     0xfbbed8: add             x6, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xfbbedc: ldr             x6, [x6, #0x318]
    // 0xfbbee0: StoreField: r1->field_f = r6
    //     0xfbbee0: stur            w6, [x1, #0xf]
    // 0xfbbee4: mov             x8, x1
    // 0xfbbee8: b               #0xfbbf14
    // 0xfbbeec: mov             x0, x1
    // 0xfbbef0: r2 = true
    //     0xfbbef0: add             x2, NULL, #0x20  ; true
    // 0xfbbef4: r6 = Instance_Duration
    //     0xfbbef4: add             x6, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xfbbef8: ldr             x6, [x6, #0x318]
    // 0xfbbefc: r5 = Instance__Linear
    //     0xfbbefc: ldr             x5, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xfbbf00: r3 = Instance_TextOverflow
    //     0xfbbf00: add             x3, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xfbbf04: ldr             x3, [x3, #0x108]
    // 0xfbbf08: r4 = Instance_TextWidthBasis
    //     0xfbbf08: add             x4, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xfbbf0c: ldr             x4, [x4, #0x110]
    // 0xfbbf10: r8 = Null
    //     0xfbbf10: mov             x8, NULL
    // 0xfbbf14: ldur            x7, [fp, #-0x30]
    // 0xfbbf18: stur            x8, [fp, #-0x20]
    // 0xfbbf1c: LoadField: r1 = r7->field_1f
    //     0xfbbf1c: ldur            w1, [x7, #0x1f]
    // 0xfbbf20: DecompressPointer r1
    //     0xfbbf20: add             x1, x1, HEAP, lsl #32
    // 0xfbbf24: cmp             w1, NULL
    // 0xfbbf28: b.ne            #0xfbc064
    // 0xfbbf2c: ldur            x9, [fp, #-0x40]
    // 0xfbbf30: r17 = 5141
    //     0xfbbf30: mov             x17, #0x1415
    // 0xfbbf34: cmp             x9, x17
    // 0xfbbf38: b.ne            #0xfbbf50
    // 0xfbbf3c: ldur            x10, [fp, #-0x48]
    // 0xfbbf40: LoadField: r1 = r10->field_1f
    //     0xfbbf40: ldur            w1, [x10, #0x1f]
    // 0xfbbf44: DecompressPointer r1
    //     0xfbbf44: add             x1, x1, HEAP, lsl #32
    // 0xfbbf48: mov             x0, x1
    // 0xfbbf4c: b               #0xfbc058
    // 0xfbbf50: ldur            x10, [fp, #-0x48]
    // 0xfbbf54: r17 = 5142
    //     0xfbbf54: mov             x17, #0x1416
    // 0xfbbf58: cmp             x9, x17
    // 0xfbbf5c: b.ne            #0xfbbfd4
    // 0xfbbf60: mov             x1, x10
    // 0xfbbf64: LoadField: r0 = r1->field_6b
    //     0xfbbf64: ldur            w0, [x1, #0x6b]
    // 0xfbbf68: DecompressPointer r0
    //     0xfbbf68: add             x0, x0, HEAP, lsl #32
    // 0xfbbf6c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbbf70: cmp             w0, w16
    // 0xfbbf74: b.ne            #0xfbbf84
    // 0xfbbf78: r2 = _textTheme
    //     0xfbbf78: add             x2, PP, #0x26, lsl #12  ; [pp+0x26338] Field <_LisTileDefaultsM3@97247952._textTheme@97247952>: late final (offset: 0x6c)
    //     0xfbbf7c: ldr             x2, [x2, #0x338]
    // 0xfbbf80: r0 = InitLateFinalInstanceField()
    //     0xfbbf80: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbbf84: LoadField: r2 = r0->field_2b
    //     0xfbbf84: ldur            w2, [x0, #0x2b]
    // 0xfbbf88: DecompressPointer r2
    //     0xfbbf88: add             x2, x2, HEAP, lsl #32
    // 0xfbbf8c: ldur            x1, [fp, #-0x48]
    // 0xfbbf90: stur            x2, [fp, #-0x88]
    // 0xfbbf94: LoadField: r0 = r1->field_67
    //     0xfbbf94: ldur            w0, [x1, #0x67]
    // 0xfbbf98: DecompressPointer r0
    //     0xfbbf98: add             x0, x0, HEAP, lsl #32
    // 0xfbbf9c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbbfa0: cmp             w0, w16
    // 0xfbbfa4: b.ne            #0xfbbfb4
    // 0xfbbfa8: r2 = _colors
    //     0xfbbfa8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0xfbbfac: ldr             x2, [x2, #0x320]
    // 0xfbbfb0: r0 = InitLateFinalInstanceField()
    //     0xfbbfb0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbbfb4: LoadField: r1 = r0->field_7f
    //     0xfbbfb4: ldur            w1, [x0, #0x7f]
    // 0xfbbfb8: DecompressPointer r1
    //     0xfbbfb8: add             x1, x1, HEAP, lsl #32
    // 0xfbbfbc: str             x1, [SP]
    // 0xfbbfc0: ldur            x1, [fp, #-0x88]
    // 0xfbbfc4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xfbbfc4: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xfbbfc8: ldr             x4, [x4, #0x7f0]
    // 0xfbbfcc: r0 = copyWith()
    //     0xfbbfcc: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xfbbfd0: b               #0xfbc058
    // 0xfbbfd4: mov             x0, x10
    // 0xfbbfd8: LoadField: r1 = r0->field_f
    //     0xfbbfd8: ldur            w1, [x0, #0xf]
    // 0xfbbfdc: DecompressPointer r1
    //     0xfbbfdc: add             x1, x1, HEAP, lsl #32
    // 0xfbbfe0: cmp             w1, NULL
    // 0xfbbfe4: b.eq            #0xfbcbdc
    // 0xfbbfe8: LoadField: r2 = r1->field_7
    //     0xfbbfe8: ldur            x2, [x1, #7]
    // 0xfbbfec: cmp             x2, #0
    // 0xfbbff0: b.gt            #0xfbc028
    // 0xfbbff4: mov             x1, x0
    // 0xfbbff8: LoadField: r0 = r1->field_67
    //     0xfbbff8: ldur            w0, [x1, #0x67]
    // 0xfbbffc: DecompressPointer r0
    //     0xfbbffc: add             x0, x0, HEAP, lsl #32
    // 0xfbc000: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbc004: cmp             w0, w16
    // 0xfbc008: b.ne            #0xfbc018
    // 0xfbc00c: r2 = _textTheme
    //     0xfbc00c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26340] Field <_LisTileDefaultsM2@97247952._textTheme@97247952>: late final (offset: 0x68)
    //     0xfbc010: ldr             x2, [x2, #0x340]
    // 0xfbc014: r0 = InitLateFinalInstanceField()
    //     0xfbc014: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbc018: LoadField: r1 = r0->field_23
    //     0xfbc018: ldur            w1, [x0, #0x23]
    // 0xfbc01c: DecompressPointer r1
    //     0xfbc01c: add             x1, x1, HEAP, lsl #32
    // 0xfbc020: mov             x0, x1
    // 0xfbc024: b               #0xfbc058
    // 0xfbc028: ldur            x1, [fp, #-0x48]
    // 0xfbc02c: LoadField: r0 = r1->field_67
    //     0xfbc02c: ldur            w0, [x1, #0x67]
    // 0xfbc030: DecompressPointer r0
    //     0xfbc030: add             x0, x0, HEAP, lsl #32
    // 0xfbc034: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbc038: cmp             w0, w16
    // 0xfbc03c: b.ne            #0xfbc04c
    // 0xfbc040: r2 = _textTheme
    //     0xfbc040: add             x2, PP, #0x26, lsl #12  ; [pp+0x26340] Field <_LisTileDefaultsM2@97247952._textTheme@97247952>: late final (offset: 0x68)
    //     0xfbc044: ldr             x2, [x2, #0x340]
    // 0xfbc048: r0 = InitLateFinalInstanceField()
    //     0xfbc048: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbc04c: LoadField: r1 = r0->field_2b
    //     0xfbc04c: ldur            w1, [x0, #0x2b]
    // 0xfbc050: DecompressPointer r1
    //     0xfbc050: add             x1, x1, HEAP, lsl #32
    // 0xfbc054: mov             x0, x1
    // 0xfbc058: cmp             w0, NULL
    // 0xfbc05c: b.eq            #0xfbcbe0
    // 0xfbc060: mov             x1, x0
    // 0xfbc064: ldur            x0, [fp, #-8]
    // 0xfbc068: LoadField: r2 = r0->field_1f
    //     0xfbc068: ldur            w2, [x0, #0x1f]
    // 0xfbc06c: DecompressPointer r2
    //     0xfbc06c: add             x2, x2, HEAP, lsl #32
    // 0xfbc070: stur            x2, [fp, #-0x88]
    // 0xfbc074: cmp             w2, NULL
    // 0xfbc078: b.ne            #0xfbc084
    // 0xfbc07c: r3 = Null
    //     0xfbc07c: mov             x3, NULL
    // 0xfbc080: b               #0xfbc088
    // 0xfbc084: mov             x3, x2
    // 0xfbc088: cmp             w3, NULL
    // 0xfbc08c: b.ne            #0xfbc094
    // 0xfbc090: r3 = Null
    //     0xfbc090: mov             x3, NULL
    // 0xfbc094: cmp             w3, NULL
    // 0xfbc098: b.eq            #0xfbc0ac
    // 0xfbc09c: tbnz            w3, #4, #0xfbc0ac
    // 0xfbc0a0: r3 = 13.000000
    //     0xfbc0a0: add             x3, PP, #0x19, lsl #12  ; [pp+0x19d68] 13
    //     0xfbc0a4: ldr             x3, [x3, #0xd68]
    // 0xfbc0a8: b               #0xfbc0b0
    // 0xfbc0ac: r3 = Null
    //     0xfbc0ac: mov             x3, NULL
    // 0xfbc0b0: ldur            x16, [fp, #-0x68]
    // 0xfbc0b4: stp             x3, x16, [SP]
    // 0xfbc0b8: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, fontSize, 0x2, null]
    //     0xfbc0b8: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1aea8] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "fontSize", 0x2, Null]
    //     0xfbc0bc: ldr             x4, [x4, #0xea8]
    // 0xfbc0c0: r0 = copyWith()
    //     0xfbc0c0: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xfbc0c4: mov             x1, x0
    // 0xfbc0c8: ldur            x0, [fp, #-8]
    // 0xfbc0cc: stur            x1, [fp, #-0x98]
    // 0xfbc0d0: LoadField: r2 = r0->field_f
    //     0xfbc0d0: ldur            w2, [x0, #0xf]
    // 0xfbc0d4: DecompressPointer r2
    //     0xfbc0d4: add             x2, x2, HEAP, lsl #32
    // 0xfbc0d8: stur            x2, [fp, #-0x90]
    // 0xfbc0dc: r0 = AnimatedDefaultTextStyle()
    //     0xfbc0dc: bl              #0xd2ad90  ; AllocateAnimatedDefaultTextStyleStub -> AnimatedDefaultTextStyle (size=0x38)
    // 0xfbc0e0: mov             x2, x0
    // 0xfbc0e4: ldur            x0, [fp, #-0x90]
    // 0xfbc0e8: stur            x2, [fp, #-0xa0]
    // 0xfbc0ec: ArrayStore: r2[0] = r0  ; List_4
    //     0xfbc0ec: stur            w0, [x2, #0x17]
    // 0xfbc0f0: ldur            x0, [fp, #-0x98]
    // 0xfbc0f4: StoreField: r2->field_1b = r0
    //     0xfbc0f4: stur            w0, [x2, #0x1b]
    // 0xfbc0f8: r3 = true
    //     0xfbc0f8: add             x3, NULL, #0x20  ; true
    // 0xfbc0fc: StoreField: r2->field_23 = r3
    //     0xfbc0fc: stur            w3, [x2, #0x23]
    // 0xfbc100: r4 = Instance_TextOverflow
    //     0xfbc100: add             x4, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xfbc104: ldr             x4, [x4, #0x108]
    // 0xfbc108: StoreField: r2->field_27 = r4
    //     0xfbc108: stur            w4, [x2, #0x27]
    // 0xfbc10c: r5 = Instance_TextWidthBasis
    //     0xfbc10c: add             x5, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xfbc110: ldr             x5, [x5, #0x110]
    // 0xfbc114: StoreField: r2->field_2f = r5
    //     0xfbc114: stur            w5, [x2, #0x2f]
    // 0xfbc118: r6 = Instance__Linear
    //     0xfbc118: ldr             x6, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xfbc11c: StoreField: r2->field_b = r6
    //     0xfbc11c: stur            w6, [x2, #0xb]
    // 0xfbc120: r7 = Instance_Duration
    //     0xfbc120: add             x7, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xfbc124: ldr             x7, [x7, #0x318]
    // 0xfbc128: StoreField: r2->field_f = r7
    //     0xfbc128: stur            w7, [x2, #0xf]
    // 0xfbc12c: ldur            x8, [fp, #-8]
    // 0xfbc130: LoadField: r9 = r8->field_13
    //     0xfbc130: ldur            w9, [x8, #0x13]
    // 0xfbc134: DecompressPointer r9
    //     0xfbc134: add             x9, x9, HEAP, lsl #32
    // 0xfbc138: stur            x9, [fp, #-0x90]
    // 0xfbc13c: cmp             w9, NULL
    // 0xfbc140: b.eq            #0xfbc324
    // 0xfbc144: ldur            x10, [fp, #-0x40]
    // 0xfbc148: r17 = 5141
    //     0xfbc148: mov             x17, #0x1415
    // 0xfbc14c: cmp             x10, x17
    // 0xfbc150: b.ne            #0xfbc164
    // 0xfbc154: ldur            x11, [fp, #-0x48]
    // 0xfbc158: LoadField: r1 = r11->field_23
    //     0xfbc158: ldur            w1, [x11, #0x23]
    // 0xfbc15c: DecompressPointer r1
    //     0xfbc15c: add             x1, x1, HEAP, lsl #32
    // 0xfbc160: b               #0xfbc270
    // 0xfbc164: ldur            x11, [fp, #-0x48]
    // 0xfbc168: r17 = 5142
    //     0xfbc168: mov             x17, #0x1416
    // 0xfbc16c: cmp             x10, x17
    // 0xfbc170: b.ne            #0xfbc210
    // 0xfbc174: mov             x1, x11
    // 0xfbc178: LoadField: r0 = r1->field_6b
    //     0xfbc178: ldur            w0, [x1, #0x6b]
    // 0xfbc17c: DecompressPointer r0
    //     0xfbc17c: add             x0, x0, HEAP, lsl #32
    // 0xfbc180: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbc184: cmp             w0, w16
    // 0xfbc188: b.ne            #0xfbc198
    // 0xfbc18c: r2 = _textTheme
    //     0xfbc18c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26338] Field <_LisTileDefaultsM3@97247952._textTheme@97247952>: late final (offset: 0x6c)
    //     0xfbc190: ldr             x2, [x2, #0x338]
    // 0xfbc194: r0 = InitLateFinalInstanceField()
    //     0xfbc194: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbc198: LoadField: r2 = r0->field_2f
    //     0xfbc198: ldur            w2, [x0, #0x2f]
    // 0xfbc19c: DecompressPointer r2
    //     0xfbc19c: add             x2, x2, HEAP, lsl #32
    // 0xfbc1a0: stur            x2, [fp, #-0xa8]
    // 0xfbc1a4: cmp             w2, NULL
    // 0xfbc1a8: b.eq            #0xfbcbe4
    // 0xfbc1ac: ldur            x1, [fp, #-0x48]
    // 0xfbc1b0: LoadField: r0 = r1->field_67
    //     0xfbc1b0: ldur            w0, [x1, #0x67]
    // 0xfbc1b4: DecompressPointer r0
    //     0xfbc1b4: add             x0, x0, HEAP, lsl #32
    // 0xfbc1b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbc1bc: cmp             w0, w16
    // 0xfbc1c0: b.ne            #0xfbc1d0
    // 0xfbc1c4: r2 = _colors
    //     0xfbc1c4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0xfbc1c8: ldr             x2, [x2, #0x320]
    // 0xfbc1cc: r0 = InitLateFinalInstanceField()
    //     0xfbc1cc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbc1d0: LoadField: r1 = r0->field_a3
    //     0xfbc1d0: ldur            w1, [x0, #0xa3]
    // 0xfbc1d4: DecompressPointer r1
    //     0xfbc1d4: add             x1, x1, HEAP, lsl #32
    // 0xfbc1d8: cmp             w1, NULL
    // 0xfbc1dc: b.ne            #0xfbc1f0
    // 0xfbc1e0: LoadField: r1 = r0->field_7f
    //     0xfbc1e0: ldur            w1, [x0, #0x7f]
    // 0xfbc1e4: DecompressPointer r1
    //     0xfbc1e4: add             x1, x1, HEAP, lsl #32
    // 0xfbc1e8: mov             x0, x1
    // 0xfbc1ec: b               #0xfbc1f4
    // 0xfbc1f0: mov             x0, x1
    // 0xfbc1f4: str             x0, [SP]
    // 0xfbc1f8: ldur            x1, [fp, #-0xa8]
    // 0xfbc1fc: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xfbc1fc: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xfbc200: ldr             x4, [x4, #0x7f0]
    // 0xfbc204: r0 = copyWith()
    //     0xfbc204: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xfbc208: mov             x1, x0
    // 0xfbc20c: b               #0xfbc270
    // 0xfbc210: ldur            x1, [fp, #-0x48]
    // 0xfbc214: LoadField: r0 = r1->field_67
    //     0xfbc214: ldur            w0, [x1, #0x67]
    // 0xfbc218: DecompressPointer r0
    //     0xfbc218: add             x0, x0, HEAP, lsl #32
    // 0xfbc21c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbc220: cmp             w0, w16
    // 0xfbc224: b.ne            #0xfbc234
    // 0xfbc228: r2 = _textTheme
    //     0xfbc228: add             x2, PP, #0x26, lsl #12  ; [pp+0x26340] Field <_LisTileDefaultsM2@97247952._textTheme@97247952>: late final (offset: 0x68)
    //     0xfbc22c: ldr             x2, [x2, #0x340]
    // 0xfbc230: r0 = InitLateFinalInstanceField()
    //     0xfbc230: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbc234: LoadField: r1 = r0->field_2f
    //     0xfbc234: ldur            w1, [x0, #0x2f]
    // 0xfbc238: DecompressPointer r1
    //     0xfbc238: add             x1, x1, HEAP, lsl #32
    // 0xfbc23c: cmp             w1, NULL
    // 0xfbc240: b.eq            #0xfbcbe8
    // 0xfbc244: LoadField: r2 = r0->field_33
    //     0xfbc244: ldur            w2, [x0, #0x33]
    // 0xfbc248: DecompressPointer r2
    //     0xfbc248: add             x2, x2, HEAP, lsl #32
    // 0xfbc24c: cmp             w2, NULL
    // 0xfbc250: b.eq            #0xfbcbec
    // 0xfbc254: LoadField: r0 = r2->field_b
    //     0xfbc254: ldur            w0, [x2, #0xb]
    // 0xfbc258: DecompressPointer r0
    //     0xfbc258: add             x0, x0, HEAP, lsl #32
    // 0xfbc25c: str             x0, [SP]
    // 0xfbc260: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xfbc260: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xfbc264: ldr             x4, [x4, #0x7f0]
    // 0xfbc268: r0 = copyWith()
    //     0xfbc268: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xfbc26c: mov             x1, x0
    // 0xfbc270: ldur            x0, [fp, #-0x88]
    // 0xfbc274: cmp             w0, NULL
    // 0xfbc278: b.ne            #0xfbc284
    // 0xfbc27c: r2 = Null
    //     0xfbc27c: mov             x2, NULL
    // 0xfbc280: b               #0xfbc288
    // 0xfbc284: mov             x2, x0
    // 0xfbc288: cmp             w2, NULL
    // 0xfbc28c: b.ne            #0xfbc294
    // 0xfbc290: r2 = Null
    //     0xfbc290: mov             x2, NULL
    // 0xfbc294: cmp             w2, NULL
    // 0xfbc298: b.eq            #0xfbc2ac
    // 0xfbc29c: tbnz            w2, #4, #0xfbc2ac
    // 0xfbc2a0: r3 = 12.000000
    //     0xfbc2a0: add             x3, PP, #0x19, lsl #12  ; [pp+0x19c58] 12
    //     0xfbc2a4: ldr             x3, [x3, #0xc58]
    // 0xfbc2a8: b               #0xfbc2b0
    // 0xfbc2ac: r3 = Null
    //     0xfbc2ac: mov             x3, NULL
    // 0xfbc2b0: ldur            x2, [fp, #-0x90]
    // 0xfbc2b4: ldur            x16, [fp, #-0x68]
    // 0xfbc2b8: stp             x3, x16, [SP]
    // 0xfbc2bc: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, fontSize, 0x2, null]
    //     0xfbc2bc: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1aea8] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "fontSize", 0x2, Null]
    //     0xfbc2c0: ldr             x4, [x4, #0xea8]
    // 0xfbc2c4: r0 = copyWith()
    //     0xfbc2c4: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xfbc2c8: stur            x0, [fp, #-0x68]
    // 0xfbc2cc: r0 = AnimatedDefaultTextStyle()
    //     0xfbc2cc: bl              #0xd2ad90  ; AllocateAnimatedDefaultTextStyleStub -> AnimatedDefaultTextStyle (size=0x38)
    // 0xfbc2d0: mov             x1, x0
    // 0xfbc2d4: ldur            x0, [fp, #-0x90]
    // 0xfbc2d8: ArrayStore: r1[0] = r0  ; List_4
    //     0xfbc2d8: stur            w0, [x1, #0x17]
    // 0xfbc2dc: ldur            x0, [fp, #-0x68]
    // 0xfbc2e0: StoreField: r1->field_1b = r0
    //     0xfbc2e0: stur            w0, [x1, #0x1b]
    // 0xfbc2e4: r2 = true
    //     0xfbc2e4: add             x2, NULL, #0x20  ; true
    // 0xfbc2e8: StoreField: r1->field_23 = r2
    //     0xfbc2e8: stur            w2, [x1, #0x23]
    // 0xfbc2ec: r3 = Instance_TextOverflow
    //     0xfbc2ec: add             x3, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xfbc2f0: ldr             x3, [x3, #0x108]
    // 0xfbc2f4: StoreField: r1->field_27 = r3
    //     0xfbc2f4: stur            w3, [x1, #0x27]
    // 0xfbc2f8: r4 = Instance_TextWidthBasis
    //     0xfbc2f8: add             x4, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xfbc2fc: ldr             x4, [x4, #0x110]
    // 0xfbc300: StoreField: r1->field_2f = r4
    //     0xfbc300: stur            w4, [x1, #0x2f]
    // 0xfbc304: r5 = Instance__Linear
    //     0xfbc304: ldr             x5, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xfbc308: StoreField: r1->field_b = r5
    //     0xfbc308: stur            w5, [x1, #0xb]
    // 0xfbc30c: r6 = Instance_Duration
    //     0xfbc30c: add             x6, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xfbc310: ldr             x6, [x6, #0x318]
    // 0xfbc314: StoreField: r1->field_f = r6
    //     0xfbc314: stur            w6, [x1, #0xf]
    // 0xfbc318: mov             x7, x1
    // 0xfbc31c: mov             x1, x0
    // 0xfbc320: b               #0xfbc340
    // 0xfbc324: mov             x2, x3
    // 0xfbc328: mov             x3, x4
    // 0xfbc32c: mov             x4, x5
    // 0xfbc330: mov             x5, x6
    // 0xfbc334: mov             x6, x7
    // 0xfbc338: r7 = Null
    //     0xfbc338: mov             x7, NULL
    // 0xfbc33c: r1 = Null
    //     0xfbc33c: mov             x1, NULL
    // 0xfbc340: ldur            x0, [fp, #-8]
    // 0xfbc344: stur            x7, [fp, #-0x90]
    // 0xfbc348: stur            x1, [fp, #-0xa8]
    // 0xfbc34c: ArrayLoad: r8 = r0[0]  ; List_4
    //     0xfbc34c: ldur            w8, [x0, #0x17]
    // 0xfbc350: DecompressPointer r8
    //     0xfbc350: add             x8, x8, HEAP, lsl #32
    // 0xfbc354: stur            x8, [fp, #-0x68]
    // 0xfbc358: cmp             w8, NULL
    // 0xfbc35c: b.eq            #0xfbc3c0
    // 0xfbc360: ldur            x9, [fp, #-0x80]
    // 0xfbc364: cmp             w9, NULL
    // 0xfbc368: b.eq            #0xfbcbf0
    // 0xfbc36c: r0 = AnimatedDefaultTextStyle()
    //     0xfbc36c: bl              #0xd2ad90  ; AllocateAnimatedDefaultTextStyleStub -> AnimatedDefaultTextStyle (size=0x38)
    // 0xfbc370: mov             x1, x0
    // 0xfbc374: ldur            x0, [fp, #-0x68]
    // 0xfbc378: ArrayStore: r1[0] = r0  ; List_4
    //     0xfbc378: stur            w0, [x1, #0x17]
    // 0xfbc37c: ldur            x0, [fp, #-0x80]
    // 0xfbc380: StoreField: r1->field_1b = r0
    //     0xfbc380: stur            w0, [x1, #0x1b]
    // 0xfbc384: r0 = true
    //     0xfbc384: add             x0, NULL, #0x20  ; true
    // 0xfbc388: StoreField: r1->field_23 = r0
    //     0xfbc388: stur            w0, [x1, #0x23]
    // 0xfbc38c: r2 = Instance_TextOverflow
    //     0xfbc38c: add             x2, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xfbc390: ldr             x2, [x2, #0x108]
    // 0xfbc394: StoreField: r1->field_27 = r2
    //     0xfbc394: stur            w2, [x1, #0x27]
    // 0xfbc398: r2 = Instance_TextWidthBasis
    //     0xfbc398: add             x2, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xfbc39c: ldr             x2, [x2, #0x110]
    // 0xfbc3a0: StoreField: r1->field_2f = r2
    //     0xfbc3a0: stur            w2, [x1, #0x2f]
    // 0xfbc3a4: r2 = Instance__Linear
    //     0xfbc3a4: ldr             x2, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xfbc3a8: StoreField: r1->field_b = r2
    //     0xfbc3a8: stur            w2, [x1, #0xb]
    // 0xfbc3ac: r2 = Instance_Duration
    //     0xfbc3ac: add             x2, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xfbc3b0: ldr             x2, [x2, #0x318]
    // 0xfbc3b4: StoreField: r1->field_f = r2
    //     0xfbc3b4: stur            w2, [x1, #0xf]
    // 0xfbc3b8: mov             x3, x1
    // 0xfbc3bc: b               #0xfbc3c8
    // 0xfbc3c0: mov             x0, x2
    // 0xfbc3c4: r3 = Null
    //     0xfbc3c4: mov             x3, NULL
    // 0xfbc3c8: ldur            x2, [fp, #-8]
    // 0xfbc3cc: ldur            x1, [fp, #-0x10]
    // 0xfbc3d0: stur            x3, [fp, #-0x68]
    // 0xfbc3d4: r0 = of()
    //     0xfbc3d4: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xfbc3d8: mov             x4, x0
    // 0xfbc3dc: ldur            x3, [fp, #-8]
    // 0xfbc3e0: stur            x4, [fp, #-0x10]
    // 0xfbc3e4: LoadField: r0 = r3->field_47
    //     0xfbc3e4: ldur            w0, [x3, #0x47]
    // 0xfbc3e8: DecompressPointer r0
    //     0xfbc3e8: add             x0, x0, HEAP, lsl #32
    // 0xfbc3ec: cmp             w0, NULL
    // 0xfbc3f0: b.ne            #0xfbc3f8
    // 0xfbc3f4: r0 = Null
    //     0xfbc3f4: mov             x0, NULL
    // 0xfbc3f8: cmp             w0, NULL
    // 0xfbc3fc: b.ne            #0xfbc450
    // 0xfbc400: ldur            x5, [fp, #-0x30]
    // 0xfbc404: LoadField: r0 = r5->field_2b
    //     0xfbc404: ldur            w0, [x5, #0x2b]
    // 0xfbc408: DecompressPointer r0
    //     0xfbc408: add             x0, x0, HEAP, lsl #32
    // 0xfbc40c: cmp             w0, NULL
    // 0xfbc410: b.ne            #0xfbc41c
    // 0xfbc414: r0 = Null
    //     0xfbc414: mov             x0, NULL
    // 0xfbc418: b               #0xfbc450
    // 0xfbc41c: r1 = LoadClassIdInstr(r0)
    //     0xfbc41c: ldur            x1, [x0, #-1]
    //     0xfbc420: ubfx            x1, x1, #0xc, #0x14
    // 0xfbc424: cmp             x1, #0xb7c
    // 0xfbc428: b.eq            #0xfbc450
    // 0xfbc42c: r1 = LoadClassIdInstr(r0)
    //     0xfbc42c: ldur            x1, [x0, #-1]
    //     0xfbc430: ubfx            x1, x1, #0xc, #0x14
    // 0xfbc434: mov             x16, x0
    // 0xfbc438: mov             x0, x1
    // 0xfbc43c: mov             x1, x16
    // 0xfbc440: mov             x2, x4
    // 0xfbc444: r0 = GDT[cid_x0 + -0xfea]()
    //     0xfbc444: sub             lr, x0, #0xfea
    //     0xfbc448: ldr             lr, [x21, lr, lsl #3]
    //     0xfbc44c: blr             lr
    // 0xfbc450: cmp             w0, NULL
    // 0xfbc454: b.ne            #0xfbc498
    // 0xfbc458: ldur            x0, [fp, #-0x50]
    // 0xfbc45c: r1 = LoadClassIdInstr(r0)
    //     0xfbc45c: ldur            x1, [x0, #-1]
    //     0xfbc460: ubfx            x1, x1, #0xc, #0x14
    // 0xfbc464: cmp             x1, #0xb7c
    // 0xfbc468: b.eq            #0xfbc490
    // 0xfbc46c: r1 = LoadClassIdInstr(r0)
    //     0xfbc46c: ldur            x1, [x0, #-1]
    //     0xfbc470: ubfx            x1, x1, #0xc, #0x14
    // 0xfbc474: mov             x16, x0
    // 0xfbc478: mov             x0, x1
    // 0xfbc47c: mov             x1, x16
    // 0xfbc480: ldur            x2, [fp, #-0x10]
    // 0xfbc484: r0 = GDT[cid_x0 + -0xfea]()
    //     0xfbc484: sub             lr, x0, #0xfea
    //     0xfbc488: ldr             lr, [x21, lr, lsl #3]
    //     0xfbc48c: blr             lr
    // 0xfbc490: mov             x2, x0
    // 0xfbc494: b               #0xfbc49c
    // 0xfbc498: mov             x2, x0
    // 0xfbc49c: ldur            x0, [fp, #-0x60]
    // 0xfbc4a0: stur            x2, [fp, #-0x50]
    // 0xfbc4a4: r1 = <WidgetState>
    //     0xfbc4a4: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a10] TypeArguments: <WidgetState>
    //     0xfbc4a8: ldr             x1, [x1, #0xa10]
    // 0xfbc4ac: r0 = _Set()
    //     0xfbc4ac: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xfbc4b0: mov             x3, x0
    // 0xfbc4b4: r0 = _Uint32List
    //     0xfbc4b4: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0xfbc4b8: stur            x3, [fp, #-0x80]
    // 0xfbc4bc: StoreField: r3->field_1b = r0
    //     0xfbc4bc: stur            w0, [x3, #0x1b]
    // 0xfbc4c0: StoreField: r3->field_b = rZR
    //     0xfbc4c0: stur            wzr, [x3, #0xb]
    // 0xfbc4c4: r0 = const []
    //     0xfbc4c4: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0xfbc4c8: StoreField: r3->field_f = r0
    //     0xfbc4c8: stur            w0, [x3, #0xf]
    // 0xfbc4cc: StoreField: r3->field_13 = rZR
    //     0xfbc4cc: stur            wzr, [x3, #0x13]
    // 0xfbc4d0: ArrayStore: r3[0] = rZR  ; List_4
    //     0xfbc4d0: stur            wzr, [x3, #0x17]
    // 0xfbc4d4: ldur            x0, [fp, #-0x60]
    // 0xfbc4d8: tbz             w0, #4, #0xfbc4e4
    // 0xfbc4dc: ldur            x4, [fp, #-0x58]
    // 0xfbc4e0: b               #0xfbc4f0
    // 0xfbc4e4: ldur            x4, [fp, #-0x58]
    // 0xfbc4e8: cmp             w4, NULL
    // 0xfbc4ec: b.ne            #0xfbc500
    // 0xfbc4f0: mov             x1, x3
    // 0xfbc4f4: r2 = Instance_WidgetState
    //     0xfbc4f4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xfbc4f8: ldr             x2, [x2, #0xa70]
    // 0xfbc4fc: r0 = add()
    //     0xfbc4fc: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xfbc500: ldur            x0, [fp, #-0x28]
    // 0xfbc504: r16 = <MouseCursor?>
    //     0xfbc504: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ab8] TypeArguments: <MouseCursor?>
    //     0xfbc508: ldr             x16, [x16, #0xab8]
    // 0xfbc50c: stp             NULL, x16, [SP, #8]
    // 0xfbc510: ldur            x16, [fp, #-0x80]
    // 0xfbc514: str             x16, [SP]
    // 0xfbc518: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xfbc518: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xfbc51c: r0 = resolveAs()
    //     0xfbc51c: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xfbc520: ldur            x2, [fp, #-0x80]
    // 0xfbc524: r1 = Instance__WidgetStateMouseCursor
    //     0xfbc524: add             x1, PP, #0x26, lsl #12  ; [pp+0x261c0] Obj!_WidgetStateMouseCursor@12b3261
    //     0xfbc528: ldr             x1, [x1, #0x1c0]
    // 0xfbc52c: r0 = resolve()
    //     0xfbc52c: bl              #0x8de794  ; [package:flutter/src/widgets/widget_state.dart] _WidgetStateMouseCursor::resolve
    // 0xfbc530: mov             x1, x0
    // 0xfbc534: ldur            x0, [fp, #-0x28]
    // 0xfbc538: stur            x1, [fp, #-0xd0]
    // 0xfbc53c: tbnz            w0, #4, #0xfbc54c
    // 0xfbc540: r2 = Instance_ListTileTitleAlignment
    //     0xfbc540: add             x2, PP, #0x84, lsl #12  ; [pp+0x84a28] Obj!ListTileTitleAlignment@12c54e1
    //     0xfbc544: ldr             x2, [x2, #0xa28]
    // 0xfbc548: b               #0xfbc554
    // 0xfbc54c: r2 = Instance_ListTileTitleAlignment
    //     0xfbc54c: add             x2, PP, #0x84, lsl #12  ; [pp+0x84a30] Obj!ListTileTitleAlignment@12c54c1
    //     0xfbc550: ldr             x2, [x2, #0xa30]
    // 0xfbc554: ldur            x0, [fp, #-8]
    // 0xfbc558: stur            x2, [fp, #-0xc8]
    // 0xfbc55c: LoadField: r3 = r0->field_27
    //     0xfbc55c: ldur            w3, [x0, #0x27]
    // 0xfbc560: DecompressPointer r3
    //     0xfbc560: add             x3, x3, HEAP, lsl #32
    // 0xfbc564: cmp             w3, NULL
    // 0xfbc568: b.ne            #0xfbc580
    // 0xfbc56c: ldur            x4, [fp, #-0x30]
    // 0xfbc570: LoadField: r5 = r4->field_b
    //     0xfbc570: ldur            w5, [x4, #0xb]
    // 0xfbc574: DecompressPointer r5
    //     0xfbc574: add             x5, x5, HEAP, lsl #32
    // 0xfbc578: mov             x6, x5
    // 0xfbc57c: b               #0xfbc588
    // 0xfbc580: ldur            x4, [fp, #-0x30]
    // 0xfbc584: mov             x6, x3
    // 0xfbc588: ldur            x5, [fp, #-0x60]
    // 0xfbc58c: stur            x6, [fp, #-0xc0]
    // 0xfbc590: tbnz            w5, #4, #0xfbc59c
    // 0xfbc594: ldur            x7, [fp, #-0x58]
    // 0xfbc598: b               #0xfbc5a0
    // 0xfbc59c: r7 = Null
    //     0xfbc59c: mov             x7, NULL
    // 0xfbc5a0: stur            x7, [fp, #-0xb8]
    // 0xfbc5a4: LoadField: r8 = r0->field_6f
    //     0xfbc5a4: ldur            w8, [x0, #0x6f]
    // 0xfbc5a8: DecompressPointer r8
    //     0xfbc5a8: add             x8, x8, HEAP, lsl #32
    // 0xfbc5ac: stur            x8, [fp, #-0xb0]
    // 0xfbc5b0: LoadField: r9 = r0->field_7f
    //     0xfbc5b0: ldur            w9, [x0, #0x7f]
    // 0xfbc5b4: DecompressPointer r9
    //     0xfbc5b4: add             x9, x9, HEAP, lsl #32
    // 0xfbc5b8: cmp             w9, NULL
    // 0xfbc5bc: b.ne            #0xfbc5c4
    // 0xfbc5c0: r9 = Null
    //     0xfbc5c0: mov             x9, NULL
    // 0xfbc5c4: cmp             w9, NULL
    // 0xfbc5c8: b.ne            #0xfbc5d0
    // 0xfbc5cc: r9 = true
    //     0xfbc5cc: add             x9, NULL, #0x20  ; true
    // 0xfbc5d0: stur            x9, [fp, #-0x80]
    // 0xfbc5d4: LoadField: r10 = r0->field_97
    //     0xfbc5d4: ldur            w10, [x0, #0x97]
    // 0xfbc5d8: DecompressPointer r10
    //     0xfbc5d8: add             x10, x10, HEAP, lsl #32
    // 0xfbc5dc: tbnz            w10, #4, #0xfbc5fc
    // 0xfbc5e0: ldur            x0, [fp, #-0x58]
    // 0xfbc5e4: cmp             w0, NULL
    // 0xfbc5e8: b.eq            #0xfbc5f4
    // 0xfbc5ec: r0 = true
    //     0xfbc5ec: add             x0, NULL, #0x20  ; true
    // 0xfbc5f0: b               #0xfbc600
    // 0xfbc5f4: r0 = false
    //     0xfbc5f4: add             x0, NULL, #0x30  ; false
    // 0xfbc5f8: b               #0xfbc600
    // 0xfbc5fc: r0 = false
    //     0xfbc5fc: add             x0, NULL, #0x30  ; false
    // 0xfbc600: stur            x0, [fp, #-0x28]
    // 0xfbc604: cmp             w3, NULL
    // 0xfbc608: b.ne            #0xfbc614
    // 0xfbc60c: LoadField: r3 = r4->field_b
    //     0xfbc60c: ldur            w3, [x4, #0xb]
    // 0xfbc610: DecompressPointer r3
    //     0xfbc610: add             x3, x3, HEAP, lsl #32
    // 0xfbc614: cmp             w3, NULL
    // 0xfbc618: b.ne            #0xfbc628
    // 0xfbc61c: r10 = Instance_Border
    //     0xfbc61c: add             x10, PP, #0x84, lsl #12  ; [pp+0x84a08] Obj!Border@129eb81
    //     0xfbc620: ldr             x10, [x10, #0xa08]
    // 0xfbc624: b               #0xfbc62c
    // 0xfbc628: mov             x10, x3
    // 0xfbc62c: ldur            x3, [fp, #-0x88]
    // 0xfbc630: stur            x10, [fp, #-8]
    // 0xfbc634: r0 = ShapeDecoration()
    //     0xfbc634: bl              #0xb6e288  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0xfbc638: mov             x2, x0
    // 0xfbc63c: r0 = Instance_Color
    //     0xfbc63c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xfbc640: ldr             x0, [x0, #0x810]
    // 0xfbc644: stur            x2, [fp, #-0xd8]
    // 0xfbc648: StoreField: r2->field_7 = r0
    //     0xfbc648: stur            w0, [x2, #7]
    // 0xfbc64c: ldur            x0, [fp, #-8]
    // 0xfbc650: ArrayStore: r2[0] = r0  ; List_4
    //     0xfbc650: stur            w0, [x2, #0x17]
    // 0xfbc654: ldur            x0, [fp, #-0x88]
    // 0xfbc658: cmp             w0, NULL
    // 0xfbc65c: b.ne            #0xfbc664
    // 0xfbc660: r0 = Null
    //     0xfbc660: mov             x0, NULL
    // 0xfbc664: cmp             w0, NULL
    // 0xfbc668: b.ne            #0xfbc670
    // 0xfbc66c: r0 = Null
    //     0xfbc66c: mov             x0, NULL
    // 0xfbc670: cmp             w0, NULL
    // 0xfbc674: b.ne            #0xfbc680
    // 0xfbc678: r3 = false
    //     0xfbc678: add             x3, NULL, #0x30  ; false
    // 0xfbc67c: b               #0xfbc684
    // 0xfbc680: mov             x3, x0
    // 0xfbc684: ldur            x1, [fp, #-0x18]
    // 0xfbc688: ldur            x0, [fp, #-0x98]
    // 0xfbc68c: stur            x3, [fp, #-0x58]
    // 0xfbc690: LoadField: r4 = r1->field_33
    //     0xfbc690: ldur            w4, [x1, #0x33]
    // 0xfbc694: DecompressPointer r4
    //     0xfbc694: add             x4, x4, HEAP, lsl #32
    // 0xfbc698: stur            x4, [fp, #-8]
    // 0xfbc69c: LoadField: r1 = r0->field_33
    //     0xfbc69c: ldur            w1, [x0, #0x33]
    // 0xfbc6a0: DecompressPointer r1
    //     0xfbc6a0: add             x1, x1, HEAP, lsl #32
    // 0xfbc6a4: cmp             w1, NULL
    // 0xfbc6a8: b.ne            #0xfbc7f8
    // 0xfbc6ac: ldur            x0, [fp, #-0x40]
    // 0xfbc6b0: r17 = 5141
    //     0xfbc6b0: mov             x17, #0x1415
    // 0xfbc6b4: cmp             x0, x17
    // 0xfbc6b8: b.ne            #0xfbc6d0
    // 0xfbc6bc: ldur            x5, [fp, #-0x48]
    // 0xfbc6c0: LoadField: r1 = r5->field_1f
    //     0xfbc6c0: ldur            w1, [x5, #0x1f]
    // 0xfbc6c4: DecompressPointer r1
    //     0xfbc6c4: add             x1, x1, HEAP, lsl #32
    // 0xfbc6c8: mov             x0, x1
    // 0xfbc6cc: b               #0xfbc7d8
    // 0xfbc6d0: ldur            x5, [fp, #-0x48]
    // 0xfbc6d4: r17 = 5142
    //     0xfbc6d4: mov             x17, #0x1416
    // 0xfbc6d8: cmp             x0, x17
    // 0xfbc6dc: b.ne            #0xfbc754
    // 0xfbc6e0: mov             x1, x5
    // 0xfbc6e4: LoadField: r0 = r1->field_6b
    //     0xfbc6e4: ldur            w0, [x1, #0x6b]
    // 0xfbc6e8: DecompressPointer r0
    //     0xfbc6e8: add             x0, x0, HEAP, lsl #32
    // 0xfbc6ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbc6f0: cmp             w0, w16
    // 0xfbc6f4: b.ne            #0xfbc704
    // 0xfbc6f8: r2 = _textTheme
    //     0xfbc6f8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26338] Field <_LisTileDefaultsM3@97247952._textTheme@97247952>: late final (offset: 0x6c)
    //     0xfbc6fc: ldr             x2, [x2, #0x338]
    // 0xfbc700: r0 = InitLateFinalInstanceField()
    //     0xfbc700: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbc704: LoadField: r2 = r0->field_2b
    //     0xfbc704: ldur            w2, [x0, #0x2b]
    // 0xfbc708: DecompressPointer r2
    //     0xfbc708: add             x2, x2, HEAP, lsl #32
    // 0xfbc70c: ldur            x1, [fp, #-0x48]
    // 0xfbc710: stur            x2, [fp, #-0x18]
    // 0xfbc714: LoadField: r0 = r1->field_67
    //     0xfbc714: ldur            w0, [x1, #0x67]
    // 0xfbc718: DecompressPointer r0
    //     0xfbc718: add             x0, x0, HEAP, lsl #32
    // 0xfbc71c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbc720: cmp             w0, w16
    // 0xfbc724: b.ne            #0xfbc734
    // 0xfbc728: r2 = _colors
    //     0xfbc728: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0xfbc72c: ldr             x2, [x2, #0x320]
    // 0xfbc730: r0 = InitLateFinalInstanceField()
    //     0xfbc730: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbc734: LoadField: r1 = r0->field_7f
    //     0xfbc734: ldur            w1, [x0, #0x7f]
    // 0xfbc738: DecompressPointer r1
    //     0xfbc738: add             x1, x1, HEAP, lsl #32
    // 0xfbc73c: str             x1, [SP]
    // 0xfbc740: ldur            x1, [fp, #-0x18]
    // 0xfbc744: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xfbc744: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xfbc748: ldr             x4, [x4, #0x7f0]
    // 0xfbc74c: r0 = copyWith()
    //     0xfbc74c: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xfbc750: b               #0xfbc7d8
    // 0xfbc754: mov             x0, x5
    // 0xfbc758: LoadField: r1 = r0->field_f
    //     0xfbc758: ldur            w1, [x0, #0xf]
    // 0xfbc75c: DecompressPointer r1
    //     0xfbc75c: add             x1, x1, HEAP, lsl #32
    // 0xfbc760: cmp             w1, NULL
    // 0xfbc764: b.eq            #0xfbcbf4
    // 0xfbc768: LoadField: r2 = r1->field_7
    //     0xfbc768: ldur            x2, [x1, #7]
    // 0xfbc76c: cmp             x2, #0
    // 0xfbc770: b.gt            #0xfbc7a8
    // 0xfbc774: mov             x1, x0
    // 0xfbc778: LoadField: r0 = r1->field_67
    //     0xfbc778: ldur            w0, [x1, #0x67]
    // 0xfbc77c: DecompressPointer r0
    //     0xfbc77c: add             x0, x0, HEAP, lsl #32
    // 0xfbc780: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbc784: cmp             w0, w16
    // 0xfbc788: b.ne            #0xfbc798
    // 0xfbc78c: r2 = _textTheme
    //     0xfbc78c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26340] Field <_LisTileDefaultsM2@97247952._textTheme@97247952>: late final (offset: 0x68)
    //     0xfbc790: ldr             x2, [x2, #0x340]
    // 0xfbc794: r0 = InitLateFinalInstanceField()
    //     0xfbc794: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbc798: LoadField: r1 = r0->field_23
    //     0xfbc798: ldur            w1, [x0, #0x23]
    // 0xfbc79c: DecompressPointer r1
    //     0xfbc79c: add             x1, x1, HEAP, lsl #32
    // 0xfbc7a0: mov             x0, x1
    // 0xfbc7a4: b               #0xfbc7d8
    // 0xfbc7a8: ldur            x1, [fp, #-0x48]
    // 0xfbc7ac: LoadField: r0 = r1->field_67
    //     0xfbc7ac: ldur            w0, [x1, #0x67]
    // 0xfbc7b0: DecompressPointer r0
    //     0xfbc7b0: add             x0, x0, HEAP, lsl #32
    // 0xfbc7b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbc7b8: cmp             w0, w16
    // 0xfbc7bc: b.ne            #0xfbc7cc
    // 0xfbc7c0: r2 = _textTheme
    //     0xfbc7c0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26340] Field <_LisTileDefaultsM2@97247952._textTheme@97247952>: late final (offset: 0x68)
    //     0xfbc7c4: ldr             x2, [x2, #0x340]
    // 0xfbc7c8: r0 = InitLateFinalInstanceField()
    //     0xfbc7c8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbc7cc: LoadField: r1 = r0->field_2b
    //     0xfbc7cc: ldur            w1, [x0, #0x2b]
    // 0xfbc7d0: DecompressPointer r1
    //     0xfbc7d0: add             x1, x1, HEAP, lsl #32
    // 0xfbc7d4: mov             x0, x1
    // 0xfbc7d8: cmp             w0, NULL
    // 0xfbc7dc: b.eq            #0xfbcbf8
    // 0xfbc7e0: LoadField: r1 = r0->field_33
    //     0xfbc7e0: ldur            w1, [x0, #0x33]
    // 0xfbc7e4: DecompressPointer r1
    //     0xfbc7e4: add             x1, x1, HEAP, lsl #32
    // 0xfbc7e8: cmp             w1, NULL
    // 0xfbc7ec: b.eq            #0xfbcbfc
    // 0xfbc7f0: mov             x2, x1
    // 0xfbc7f4: b               #0xfbc7fc
    // 0xfbc7f8: mov             x2, x1
    // 0xfbc7fc: ldur            x0, [fp, #-0xa8]
    // 0xfbc800: stur            x2, [fp, #-0x18]
    // 0xfbc804: cmp             w0, NULL
    // 0xfbc808: b.ne            #0xfbc814
    // 0xfbc80c: r0 = Null
    //     0xfbc80c: mov             x0, NULL
    // 0xfbc810: b               #0xfbc820
    // 0xfbc814: LoadField: r1 = r0->field_33
    //     0xfbc814: ldur            w1, [x0, #0x33]
    // 0xfbc818: DecompressPointer r1
    //     0xfbc818: add             x1, x1, HEAP, lsl #32
    // 0xfbc81c: mov             x0, x1
    // 0xfbc820: cmp             w0, NULL
    // 0xfbc824: b.ne            #0xfbc964
    // 0xfbc828: ldur            x0, [fp, #-0x40]
    // 0xfbc82c: r17 = 5141
    //     0xfbc82c: mov             x17, #0x1415
    // 0xfbc830: cmp             x0, x17
    // 0xfbc834: b.ne            #0xfbc848
    // 0xfbc838: ldur            x3, [fp, #-0x48]
    // 0xfbc83c: LoadField: r0 = r3->field_23
    //     0xfbc83c: ldur            w0, [x3, #0x23]
    // 0xfbc840: DecompressPointer r0
    //     0xfbc840: add             x0, x0, HEAP, lsl #32
    // 0xfbc844: b               #0xfbc94c
    // 0xfbc848: ldur            x3, [fp, #-0x48]
    // 0xfbc84c: r17 = 5142
    //     0xfbc84c: mov             x17, #0x1416
    // 0xfbc850: cmp             x0, x17
    // 0xfbc854: b.ne            #0xfbc8f0
    // 0xfbc858: mov             x1, x3
    // 0xfbc85c: LoadField: r0 = r1->field_6b
    //     0xfbc85c: ldur            w0, [x1, #0x6b]
    // 0xfbc860: DecompressPointer r0
    //     0xfbc860: add             x0, x0, HEAP, lsl #32
    // 0xfbc864: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbc868: cmp             w0, w16
    // 0xfbc86c: b.ne            #0xfbc87c
    // 0xfbc870: r2 = _textTheme
    //     0xfbc870: add             x2, PP, #0x26, lsl #12  ; [pp+0x26338] Field <_LisTileDefaultsM3@97247952._textTheme@97247952>: late final (offset: 0x6c)
    //     0xfbc874: ldr             x2, [x2, #0x338]
    // 0xfbc878: r0 = InitLateFinalInstanceField()
    //     0xfbc878: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbc87c: LoadField: r2 = r0->field_2f
    //     0xfbc87c: ldur            w2, [x0, #0x2f]
    // 0xfbc880: DecompressPointer r2
    //     0xfbc880: add             x2, x2, HEAP, lsl #32
    // 0xfbc884: stur            x2, [fp, #-0x88]
    // 0xfbc888: cmp             w2, NULL
    // 0xfbc88c: b.eq            #0xfbcc00
    // 0xfbc890: ldur            x1, [fp, #-0x48]
    // 0xfbc894: LoadField: r0 = r1->field_67
    //     0xfbc894: ldur            w0, [x1, #0x67]
    // 0xfbc898: DecompressPointer r0
    //     0xfbc898: add             x0, x0, HEAP, lsl #32
    // 0xfbc89c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbc8a0: cmp             w0, w16
    // 0xfbc8a4: b.ne            #0xfbc8b4
    // 0xfbc8a8: r2 = _colors
    //     0xfbc8a8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26320] Field <_LisTileDefaultsM3@97247952._colors@97247952>: late final (offset: 0x68)
    //     0xfbc8ac: ldr             x2, [x2, #0x320]
    // 0xfbc8b0: r0 = InitLateFinalInstanceField()
    //     0xfbc8b0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbc8b4: LoadField: r1 = r0->field_a3
    //     0xfbc8b4: ldur            w1, [x0, #0xa3]
    // 0xfbc8b8: DecompressPointer r1
    //     0xfbc8b8: add             x1, x1, HEAP, lsl #32
    // 0xfbc8bc: cmp             w1, NULL
    // 0xfbc8c0: b.ne            #0xfbc8d4
    // 0xfbc8c4: LoadField: r1 = r0->field_7f
    //     0xfbc8c4: ldur            w1, [x0, #0x7f]
    // 0xfbc8c8: DecompressPointer r1
    //     0xfbc8c8: add             x1, x1, HEAP, lsl #32
    // 0xfbc8cc: mov             x0, x1
    // 0xfbc8d0: b               #0xfbc8d8
    // 0xfbc8d4: mov             x0, x1
    // 0xfbc8d8: str             x0, [SP]
    // 0xfbc8dc: ldur            x1, [fp, #-0x88]
    // 0xfbc8e0: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xfbc8e0: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xfbc8e4: ldr             x4, [x4, #0x7f0]
    // 0xfbc8e8: r0 = copyWith()
    //     0xfbc8e8: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xfbc8ec: b               #0xfbc94c
    // 0xfbc8f0: ldur            x1, [fp, #-0x48]
    // 0xfbc8f4: LoadField: r0 = r1->field_67
    //     0xfbc8f4: ldur            w0, [x1, #0x67]
    // 0xfbc8f8: DecompressPointer r0
    //     0xfbc8f8: add             x0, x0, HEAP, lsl #32
    // 0xfbc8fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbc900: cmp             w0, w16
    // 0xfbc904: b.ne            #0xfbc914
    // 0xfbc908: r2 = _textTheme
    //     0xfbc908: add             x2, PP, #0x26, lsl #12  ; [pp+0x26340] Field <_LisTileDefaultsM2@97247952._textTheme@97247952>: late final (offset: 0x68)
    //     0xfbc90c: ldr             x2, [x2, #0x340]
    // 0xfbc910: r0 = InitLateFinalInstanceField()
    //     0xfbc910: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfbc914: LoadField: r1 = r0->field_2f
    //     0xfbc914: ldur            w1, [x0, #0x2f]
    // 0xfbc918: DecompressPointer r1
    //     0xfbc918: add             x1, x1, HEAP, lsl #32
    // 0xfbc91c: cmp             w1, NULL
    // 0xfbc920: b.eq            #0xfbcc04
    // 0xfbc924: LoadField: r2 = r0->field_33
    //     0xfbc924: ldur            w2, [x0, #0x33]
    // 0xfbc928: DecompressPointer r2
    //     0xfbc928: add             x2, x2, HEAP, lsl #32
    // 0xfbc92c: cmp             w2, NULL
    // 0xfbc930: b.eq            #0xfbcc08
    // 0xfbc934: LoadField: r0 = r2->field_b
    //     0xfbc934: ldur            w0, [x2, #0xb]
    // 0xfbc938: DecompressPointer r0
    //     0xfbc938: add             x0, x0, HEAP, lsl #32
    // 0xfbc93c: str             x0, [SP]
    // 0xfbc940: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xfbc940: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xfbc944: ldr             x4, [x4, #0x7f0]
    // 0xfbc948: r0 = copyWith()
    //     0xfbc948: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xfbc94c: LoadField: r1 = r0->field_33
    //     0xfbc94c: ldur            w1, [x0, #0x33]
    // 0xfbc950: DecompressPointer r1
    //     0xfbc950: add             x1, x1, HEAP, lsl #32
    // 0xfbc954: cmp             w1, NULL
    // 0xfbc958: b.eq            #0xfbcc0c
    // 0xfbc95c: mov             x2, x1
    // 0xfbc960: b               #0xfbc968
    // 0xfbc964: mov             x2, x0
    // 0xfbc968: ldur            x0, [fp, #-0x30]
    // 0xfbc96c: stur            x2, [fp, #-0x88]
    // 0xfbc970: LoadField: r1 = r0->field_37
    //     0xfbc970: ldur            w1, [x0, #0x37]
    // 0xfbc974: DecompressPointer r1
    //     0xfbc974: add             x1, x1, HEAP, lsl #32
    // 0xfbc978: cmp             w1, NULL
    // 0xfbc97c: b.ne            #0xfbc988
    // 0xfbc980: d0 = 16.000000
    //     0xfbc980: fmov            d0, #16.00000000
    // 0xfbc984: b               #0xfbc98c
    // 0xfbc988: LoadField: d0 = r1->field_7
    //     0xfbc988: ldur            d0, [x1, #7]
    // 0xfbc98c: stur            d0, [fp, #-0xf8]
    // 0xfbc990: LoadField: r1 = r0->field_3b
    //     0xfbc990: ldur            w1, [x0, #0x3b]
    // 0xfbc994: DecompressPointer r1
    //     0xfbc994: add             x1, x1, HEAP, lsl #32
    // 0xfbc998: cmp             w1, NULL
    // 0xfbc99c: b.ne            #0xfbc9a8
    // 0xfbc9a0: ldur            d1, [fp, #-0xe0]
    // 0xfbc9a4: b               #0xfbc9ac
    // 0xfbc9a8: LoadField: d1 = r1->field_7
    //     0xfbc9a8: ldur            d1, [x1, #7]
    // 0xfbc9ac: stur            d1, [fp, #-0xf0]
    // 0xfbc9b0: LoadField: r1 = r0->field_3f
    //     0xfbc9b0: ldur            w1, [x0, #0x3f]
    // 0xfbc9b4: DecompressPointer r1
    //     0xfbc9b4: add             x1, x1, HEAP, lsl #32
    // 0xfbc9b8: cmp             w1, NULL
    // 0xfbc9bc: b.ne            #0xfbc9c8
    // 0xfbc9c0: ldur            d2, [fp, #-0xe8]
    // 0xfbc9c4: b               #0xfbc9cc
    // 0xfbc9c8: LoadField: d2 = r1->field_7
    //     0xfbc9c8: ldur            d2, [x1, #7]
    // 0xfbc9cc: ldur            x8, [fp, #-0x60]
    // 0xfbc9d0: ldur            x25, [fp, #-0x78]
    // 0xfbc9d4: ldur            x24, [fp, #-0x20]
    // 0xfbc9d8: ldur            x23, [fp, #-0xa0]
    // 0xfbc9dc: ldur            x20, [fp, #-0x90]
    // 0xfbc9e0: ldur            x19, [fp, #-0x68]
    // 0xfbc9e4: ldur            x14, [fp, #-0x10]
    // 0xfbc9e8: ldur            x13, [fp, #-0x50]
    // 0xfbc9ec: ldur            x6, [fp, #-0xd0]
    // 0xfbc9f0: ldur            x7, [fp, #-0xc8]
    // 0xfbc9f4: ldur            x9, [fp, #-0xc0]
    // 0xfbc9f8: ldur            x10, [fp, #-0xb8]
    // 0xfbc9fc: ldur            x11, [fp, #-0xb0]
    // 0xfbca00: ldur            x12, [fp, #-0x80]
    // 0xfbca04: ldur            x5, [fp, #-8]
    // 0xfbca08: ldur            x3, [fp, #-0x18]
    // 0xfbca0c: ldur            x4, [fp, #-0x58]
    // 0xfbca10: stur            d2, [fp, #-0xe0]
    // 0xfbca14: LoadField: r1 = r0->field_43
    //     0xfbca14: ldur            w1, [x0, #0x43]
    // 0xfbca18: DecompressPointer r1
    //     0xfbca18: add             x1, x1, HEAP, lsl #32
    // 0xfbca1c: mov             x0, x1
    // 0xfbca20: stur            x1, [fp, #-0x48]
    // 0xfbca24: r1 = <_ListTileSlot, RenderBox>
    //     0xfbca24: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a38] TypeArguments: <_ListTileSlot, RenderBox>
    //     0xfbca28: ldr             x1, [x1, #0xa38]
    // 0xfbca2c: r0 = _ListTile()
    //     0xfbca2c: bl              #0xfbcc10  ; Allocate_ListTileStub -> _ListTile (size=0x58)
    // 0xfbca30: mov             x1, x0
    // 0xfbca34: ldur            x0, [fp, #-0x20]
    // 0xfbca38: stur            x1, [fp, #-0x30]
    // 0xfbca3c: StoreField: r1->field_f = r0
    //     0xfbca3c: stur            w0, [x1, #0xf]
    // 0xfbca40: ldur            x0, [fp, #-0xa0]
    // 0xfbca44: StoreField: r1->field_13 = r0
    //     0xfbca44: stur            w0, [x1, #0x13]
    // 0xfbca48: ldur            x0, [fp, #-0x90]
    // 0xfbca4c: ArrayStore: r1[0] = r0  ; List_4
    //     0xfbca4c: stur            w0, [x1, #0x17]
    // 0xfbca50: ldur            x0, [fp, #-0x68]
    // 0xfbca54: StoreField: r1->field_1b = r0
    //     0xfbca54: stur            w0, [x1, #0x1b]
    // 0xfbca58: r0 = false
    //     0xfbca58: add             x0, NULL, #0x30  ; false
    // 0xfbca5c: StoreField: r1->field_1f = r0
    //     0xfbca5c: stur            w0, [x1, #0x1f]
    // 0xfbca60: ldur            x2, [fp, #-0x58]
    // 0xfbca64: StoreField: r1->field_23 = r2
    //     0xfbca64: stur            w2, [x1, #0x23]
    // 0xfbca68: ldur            x2, [fp, #-8]
    // 0xfbca6c: StoreField: r1->field_27 = r2
    //     0xfbca6c: stur            w2, [x1, #0x27]
    // 0xfbca70: ldur            x2, [fp, #-0x10]
    // 0xfbca74: StoreField: r1->field_2b = r2
    //     0xfbca74: stur            w2, [x1, #0x2b]
    // 0xfbca78: ldur            x2, [fp, #-0x18]
    // 0xfbca7c: StoreField: r1->field_2f = r2
    //     0xfbca7c: stur            w2, [x1, #0x2f]
    // 0xfbca80: ldur            d0, [fp, #-0xf8]
    // 0xfbca84: StoreField: r1->field_37 = d0
    //     0xfbca84: stur            d0, [x1, #0x37]
    // 0xfbca88: ldur            d0, [fp, #-0xf0]
    // 0xfbca8c: StoreField: r1->field_3f = d0
    //     0xfbca8c: stur            d0, [x1, #0x3f]
    // 0xfbca90: ldur            d0, [fp, #-0xe0]
    // 0xfbca94: StoreField: r1->field_47 = d0
    //     0xfbca94: stur            d0, [x1, #0x47]
    // 0xfbca98: ldur            x2, [fp, #-0x48]
    // 0xfbca9c: StoreField: r1->field_4f = r2
    //     0xfbca9c: stur            w2, [x1, #0x4f]
    // 0xfbcaa0: ldur            x2, [fp, #-0x88]
    // 0xfbcaa4: StoreField: r1->field_33 = r2
    //     0xfbcaa4: stur            w2, [x1, #0x33]
    // 0xfbcaa8: ldur            x2, [fp, #-0xc8]
    // 0xfbcaac: StoreField: r1->field_53 = r2
    //     0xfbcaac: stur            w2, [x1, #0x53]
    // 0xfbcab0: r0 = IconButtonTheme()
    //     0xfbcab0: bl              #0xd29648  ; AllocateIconButtonThemeStub -> IconButtonTheme (size=0x14)
    // 0xfbcab4: mov             x1, x0
    // 0xfbcab8: ldur            x0, [fp, #-0x78]
    // 0xfbcabc: StoreField: r1->field_f = r0
    //     0xfbcabc: stur            w0, [x1, #0xf]
    // 0xfbcac0: ldur            x0, [fp, #-0x30]
    // 0xfbcac4: StoreField: r1->field_b = r0
    //     0xfbcac4: stur            w0, [x1, #0xb]
    // 0xfbcac8: ldur            x2, [fp, #-0x70]
    // 0xfbcacc: r0 = merge()
    //     0xfbcacc: bl              #0xd0c588  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::merge
    // 0xfbcad0: stur            x0, [fp, #-8]
    // 0xfbcad4: r0 = SafeArea()
    //     0xfbcad4: bl              #0xd73100  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0xfbcad8: mov             x1, x0
    // 0xfbcadc: r0 = true
    //     0xfbcadc: add             x0, NULL, #0x20  ; true
    // 0xfbcae0: stur            x1, [fp, #-0x10]
    // 0xfbcae4: StoreField: r1->field_b = r0
    //     0xfbcae4: stur            w0, [x1, #0xb]
    // 0xfbcae8: r2 = false
    //     0xfbcae8: add             x2, NULL, #0x30  ; false
    // 0xfbcaec: StoreField: r1->field_f = r2
    //     0xfbcaec: stur            w2, [x1, #0xf]
    // 0xfbcaf0: StoreField: r1->field_13 = r0
    //     0xfbcaf0: stur            w0, [x1, #0x13]
    // 0xfbcaf4: ArrayStore: r1[0] = r2  ; List_4
    //     0xfbcaf4: stur            w2, [x1, #0x17]
    // 0xfbcaf8: ldur            x3, [fp, #-0x50]
    // 0xfbcafc: StoreField: r1->field_1b = r3
    //     0xfbcafc: stur            w3, [x1, #0x1b]
    // 0xfbcb00: StoreField: r1->field_1f = r2
    //     0xfbcb00: stur            w2, [x1, #0x1f]
    // 0xfbcb04: ldur            x3, [fp, #-8]
    // 0xfbcb08: StoreField: r1->field_23 = r3
    //     0xfbcb08: stur            w3, [x1, #0x23]
    // 0xfbcb0c: r0 = Ink()
    //     0xfbcb0c: bl              #0xdf1d50  ; AllocateInkStub -> Ink (size=0x20)
    // 0xfbcb10: stur            x0, [fp, #-8]
    // 0xfbcb14: ldur            x16, [fp, #-0xd8]
    // 0xfbcb18: str             x16, [SP]
    // 0xfbcb1c: mov             x1, x0
    // 0xfbcb20: ldur            x2, [fp, #-0x10]
    // 0xfbcb24: r4 = const [0, 0x3, 0x1, 0x2, decoration, 0x2, null]
    //     0xfbcb24: add             x4, PP, #0x84, lsl #12  ; [pp+0x84a40] List(7) [0, 0x3, 0x1, 0x2, "decoration", 0x2, Null]
    //     0xfbcb28: ldr             x4, [x4, #0xa40]
    // 0xfbcb2c: r0 = Ink()
    //     0xfbcb2c: bl              #0xdf1b7c  ; [package:flutter/src/material/ink_decoration.dart] Ink::Ink
    // 0xfbcb30: r0 = Semantics()
    //     0xfbcb30: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xfbcb34: stur            x0, [fp, #-0x10]
    // 0xfbcb38: ldur            x16, [fp, #-0x28]
    // 0xfbcb3c: ldur            lr, [fp, #-0x38]
    // 0xfbcb40: stp             lr, x16, [SP, #0x10]
    // 0xfbcb44: ldur            x16, [fp, #-0x60]
    // 0xfbcb48: ldur            lr, [fp, #-8]
    // 0xfbcb4c: stp             lr, x16, [SP]
    // 0xfbcb50: mov             x1, x0
    // 0xfbcb54: r4 = const [0, 0x5, 0x4, 0x1, button, 0x1, child, 0x4, enabled, 0x3, selected, 0x2, null]
    //     0xfbcb54: add             x4, PP, #0x84, lsl #12  ; [pp+0x84a48] List(13) [0, 0x5, 0x4, 0x1, "button", 0x1, "child", 0x4, "enabled", 0x3, "selected", 0x2, Null]
    //     0xfbcb58: ldr             x4, [x4, #0xa48]
    // 0xfbcb5c: r0 = Semantics()
    //     0xfbcb5c: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xfbcb60: r0 = InkWell()
    //     0xfbcb60: bl              #0xd0c57c  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0xfbcb64: ldur            x1, [fp, #-0x10]
    // 0xfbcb68: StoreField: r0->field_b = r1
    //     0xfbcb68: stur            w1, [x0, #0xb]
    // 0xfbcb6c: ldur            x1, [fp, #-0xb8]
    // 0xfbcb70: StoreField: r0->field_f = r1
    //     0xfbcb70: stur            w1, [x0, #0xf]
    // 0xfbcb74: ldur            x1, [fp, #-0xd0]
    // 0xfbcb78: StoreField: r0->field_43 = r1
    //     0xfbcb78: stur            w1, [x0, #0x43]
    // 0xfbcb7c: r1 = true
    //     0xfbcb7c: add             x1, NULL, #0x20  ; true
    // 0xfbcb80: StoreField: r0->field_47 = r1
    //     0xfbcb80: stur            w1, [x0, #0x47]
    // 0xfbcb84: r1 = Instance_BoxShape
    //     0xfbcb84: add             x1, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xfbcb88: ldr             x1, [x1, #0x1f8]
    // 0xfbcb8c: StoreField: r0->field_4b = r1
    //     0xfbcb8c: stur            w1, [x0, #0x4b]
    // 0xfbcb90: ldur            x1, [fp, #-0xc0]
    // 0xfbcb94: StoreField: r0->field_57 = r1
    //     0xfbcb94: stur            w1, [x0, #0x57]
    // 0xfbcb98: ldur            x1, [fp, #-0x80]
    // 0xfbcb9c: StoreField: r0->field_73 = r1
    //     0xfbcb9c: stur            w1, [x0, #0x73]
    // 0xfbcba0: r1 = false
    //     0xfbcba0: add             x1, NULL, #0x30  ; false
    // 0xfbcba4: StoreField: r0->field_77 = r1
    //     0xfbcba4: stur            w1, [x0, #0x77]
    // 0xfbcba8: ldur            x2, [fp, #-0xb0]
    // 0xfbcbac: StoreField: r0->field_83 = r2
    //     0xfbcbac: stur            w2, [x0, #0x83]
    // 0xfbcbb0: ldur            x2, [fp, #-0x60]
    // 0xfbcbb4: StoreField: r0->field_87 = r2
    //     0xfbcbb4: stur            w2, [x0, #0x87]
    // 0xfbcbb8: StoreField: r0->field_7f = r1
    //     0xfbcbb8: stur            w1, [x0, #0x7f]
    // 0xfbcbbc: LeaveFrame
    //     0xfbcbbc: mov             SP, fp
    //     0xfbcbc0: ldp             fp, lr, [SP], #0x10
    // 0xfbcbc4: ret
    //     0xfbcbc4: ret             
    // 0xfbcbc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbcbc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbcbcc: b               #0xfbb444
    // 0xfbcbd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbcbd0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfbcbd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbcbd4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfbcbd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbcbd8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfbcbdc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbcbdc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfbcbe0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbcbe0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfbcbe4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbcbe4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfbcbe8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbcbe8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfbcbec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbcbec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfbcbf0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbcbf0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfbcbf4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbcbf4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfbcbf8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbcbf8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfbcbfc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbcbfc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfbcc00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbcc00: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfbcc04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbcc04: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfbcc08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbcc08: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfbcc0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfbcc0c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6745, size: 0x58, field offset: 0x10
//   const constructor, 
class _ListTile extends SlottedMultiChildRenderObjectWidget<dynamic, dynamic> {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcde034, size: 0x140
    // 0xcde034: EnterFrame
    //     0xcde034: stp             fp, lr, [SP, #-0x10]!
    //     0xcde038: mov             fp, SP
    // 0xcde03c: AllocStack(0x10)
    //     0xcde03c: sub             SP, SP, #0x10
    // 0xcde040: SetupParameters(_ListTile this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcde040: mov             x4, x1
    //     0xcde044: stur            x1, [fp, #-8]
    //     0xcde048: stur            x3, [fp, #-0x10]
    // 0xcde04c: CheckStackOverflow
    //     0xcde04c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcde050: cmp             SP, x16
    //     0xcde054: b.ls            #0xcde16c
    // 0xcde058: mov             x0, x3
    // 0xcde05c: r2 = Null
    //     0xcde05c: mov             x2, NULL
    // 0xcde060: r1 = Null
    //     0xcde060: mov             x1, NULL
    // 0xcde064: r4 = 60
    //     0xcde064: mov             x4, #0x3c
    // 0xcde068: branchIfSmi(r0, 0xcde074)
    //     0xcde068: tbz             w0, #0, #0xcde074
    // 0xcde06c: r4 = LoadClassIdInstr(r0)
    //     0xcde06c: ldur            x4, [x0, #-1]
    //     0xcde070: ubfx            x4, x4, #0xc, #0x14
    // 0xcde074: r17 = 4854
    //     0xcde074: mov             x17, #0x12f6
    // 0xcde078: cmp             x4, x17
    // 0xcde07c: b.eq            #0xcde094
    // 0xcde080: r8 = _RenderListTile
    //     0xcde080: add             x8, PP, #0x8f, lsl #12  ; [pp+0x8fcf8] Type: _RenderListTile
    //     0xcde084: ldr             x8, [x8, #0xcf8]
    // 0xcde088: r3 = Null
    //     0xcde088: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8fd00] Null
    //     0xcde08c: ldr             x3, [x3, #0xd00]
    // 0xcde090: r0 = DefaultTypeTest()
    //     0xcde090: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcde094: ldur            x1, [fp, #-0x10]
    // 0xcde098: r2 = false
    //     0xcde098: add             x2, NULL, #0x30  ; false
    // 0xcde09c: r0 = Shader._()
    //     0xcde09c: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xcde0a0: ldur            x0, [fp, #-8]
    // 0xcde0a4: LoadField: r2 = r0->field_23
    //     0xcde0a4: ldur            w2, [x0, #0x23]
    // 0xcde0a8: DecompressPointer r2
    //     0xcde0a8: add             x2, x2, HEAP, lsl #32
    // 0xcde0ac: ldur            x1, [fp, #-0x10]
    // 0xcde0b0: r0 = isDense=()
    //     0xcde0b0: bl              #0xcde590  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::isDense=
    // 0xcde0b4: ldur            x0, [fp, #-8]
    // 0xcde0b8: LoadField: r2 = r0->field_27
    //     0xcde0b8: ldur            w2, [x0, #0x27]
    // 0xcde0bc: DecompressPointer r2
    //     0xcde0bc: add             x2, x2, HEAP, lsl #32
    // 0xcde0c0: ldur            x1, [fp, #-0x10]
    // 0xcde0c4: r0 = visualDensity=()
    //     0xcde0c4: bl              #0xcde4c8  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::visualDensity=
    // 0xcde0c8: ldur            x0, [fp, #-8]
    // 0xcde0cc: LoadField: r2 = r0->field_2b
    //     0xcde0cc: ldur            w2, [x0, #0x2b]
    // 0xcde0d0: DecompressPointer r2
    //     0xcde0d0: add             x2, x2, HEAP, lsl #32
    // 0xcde0d4: ldur            x1, [fp, #-0x10]
    // 0xcde0d8: r0 = textDirection=()
    //     0xcde0d8: bl              #0xcde458  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::textDirection=
    // 0xcde0dc: ldur            x0, [fp, #-8]
    // 0xcde0e0: LoadField: r2 = r0->field_2f
    //     0xcde0e0: ldur            w2, [x0, #0x2f]
    // 0xcde0e4: DecompressPointer r2
    //     0xcde0e4: add             x2, x2, HEAP, lsl #32
    // 0xcde0e8: ldur            x1, [fp, #-0x10]
    // 0xcde0ec: r0 = titleBaselineType=()
    //     0xcde0ec: bl              #0xcde3e8  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::titleBaselineType=
    // 0xcde0f0: ldur            x0, [fp, #-8]
    // 0xcde0f4: LoadField: r2 = r0->field_33
    //     0xcde0f4: ldur            w2, [x0, #0x33]
    // 0xcde0f8: DecompressPointer r2
    //     0xcde0f8: add             x2, x2, HEAP, lsl #32
    // 0xcde0fc: ldur            x1, [fp, #-0x10]
    // 0xcde100: r0 = subtitleBaselineType=()
    //     0xcde100: bl              #0xcde378  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::subtitleBaselineType=
    // 0xcde104: ldur            x0, [fp, #-8]
    // 0xcde108: LoadField: d0 = r0->field_37
    //     0xcde108: ldur            d0, [x0, #0x37]
    // 0xcde10c: ldur            x1, [fp, #-0x10]
    // 0xcde110: r0 = horizontalTitleGap=()
    //     0xcde110: bl              #0xcde328  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::horizontalTitleGap=
    // 0xcde114: ldur            x0, [fp, #-8]
    // 0xcde118: LoadField: d0 = r0->field_47
    //     0xcde118: ldur            d0, [x0, #0x47]
    // 0xcde11c: ldur            x1, [fp, #-0x10]
    // 0xcde120: r0 = minLeadingWidth=()
    //     0xcde120: bl              #0xcde2d8  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::minLeadingWidth=
    // 0xcde124: ldur            x0, [fp, #-8]
    // 0xcde128: LoadField: r2 = r0->field_4f
    //     0xcde128: ldur            w2, [x0, #0x4f]
    // 0xcde12c: DecompressPointer r2
    //     0xcde12c: add             x2, x2, HEAP, lsl #32
    // 0xcde130: ldur            x1, [fp, #-0x10]
    // 0xcde134: r0 = minTileHeight=()
    //     0xcde134: bl              #0xcde234  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::minTileHeight=
    // 0xcde138: ldur            x0, [fp, #-8]
    // 0xcde13c: LoadField: d0 = r0->field_3f
    //     0xcde13c: ldur            d0, [x0, #0x3f]
    // 0xcde140: ldur            x1, [fp, #-0x10]
    // 0xcde144: r0 = minVerticalPadding=()
    //     0xcde144: bl              #0xcde1e4  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::minVerticalPadding=
    // 0xcde148: ldur            x0, [fp, #-8]
    // 0xcde14c: LoadField: r2 = r0->field_53
    //     0xcde14c: ldur            w2, [x0, #0x53]
    // 0xcde150: DecompressPointer r2
    //     0xcde150: add             x2, x2, HEAP, lsl #32
    // 0xcde154: ldur            x1, [fp, #-0x10]
    // 0xcde158: r0 = titleAlignment=()
    //     0xcde158: bl              #0xcde174  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::titleAlignment=
    // 0xcde15c: r0 = Null
    //     0xcde15c: mov             x0, NULL
    // 0xcde160: LeaveFrame
    //     0xcde160: mov             SP, fp
    //     0xcde164: ldp             fp, lr, [SP], #0x10
    // 0xcde168: ret
    //     0xcde168: ret             
    // 0xcde16c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcde16c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcde170: b               #0xcde058
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11bcde8, size: 0xd8
    // 0x11bcde8: EnterFrame
    //     0x11bcde8: stp             fp, lr, [SP, #-0x10]!
    //     0x11bcdec: mov             fp, SP
    // 0x11bcdf0: AllocStack(0x68)
    //     0x11bcdf0: sub             SP, SP, #0x68
    // 0x11bcdf4: CheckStackOverflow
    //     0x11bcdf4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11bcdf8: cmp             SP, x16
    //     0x11bcdfc: b.ls            #0x11bceb8
    // 0x11bce00: LoadField: r2 = r1->field_23
    //     0x11bce00: ldur            w2, [x1, #0x23]
    // 0x11bce04: DecompressPointer r2
    //     0x11bce04: add             x2, x2, HEAP, lsl #32
    // 0x11bce08: stur            x2, [fp, #-0x38]
    // 0x11bce0c: LoadField: r0 = r1->field_27
    //     0x11bce0c: ldur            w0, [x1, #0x27]
    // 0x11bce10: DecompressPointer r0
    //     0x11bce10: add             x0, x0, HEAP, lsl #32
    // 0x11bce14: stur            x0, [fp, #-0x30]
    // 0x11bce18: LoadField: r6 = r1->field_2b
    //     0x11bce18: ldur            w6, [x1, #0x2b]
    // 0x11bce1c: DecompressPointer r6
    //     0x11bce1c: add             x6, x6, HEAP, lsl #32
    // 0x11bce20: stur            x6, [fp, #-0x28]
    // 0x11bce24: LoadField: r3 = r1->field_2f
    //     0x11bce24: ldur            w3, [x1, #0x2f]
    // 0x11bce28: DecompressPointer r3
    //     0x11bce28: add             x3, x3, HEAP, lsl #32
    // 0x11bce2c: stur            x3, [fp, #-0x20]
    // 0x11bce30: LoadField: r5 = r1->field_33
    //     0x11bce30: ldur            w5, [x1, #0x33]
    // 0x11bce34: DecompressPointer r5
    //     0x11bce34: add             x5, x5, HEAP, lsl #32
    // 0x11bce38: stur            x5, [fp, #-0x18]
    // 0x11bce3c: LoadField: d0 = r1->field_37
    //     0x11bce3c: ldur            d0, [x1, #0x37]
    // 0x11bce40: stur            d0, [fp, #-0x58]
    // 0x11bce44: LoadField: d2 = r1->field_3f
    //     0x11bce44: ldur            d2, [x1, #0x3f]
    // 0x11bce48: stur            d2, [fp, #-0x50]
    // 0x11bce4c: LoadField: d1 = r1->field_47
    //     0x11bce4c: ldur            d1, [x1, #0x47]
    // 0x11bce50: stur            d1, [fp, #-0x48]
    // 0x11bce54: LoadField: r4 = r1->field_4f
    //     0x11bce54: ldur            w4, [x1, #0x4f]
    // 0x11bce58: DecompressPointer r4
    //     0x11bce58: add             x4, x4, HEAP, lsl #32
    // 0x11bce5c: stur            x4, [fp, #-0x10]
    // 0x11bce60: LoadField: r7 = r1->field_53
    //     0x11bce60: ldur            w7, [x1, #0x53]
    // 0x11bce64: DecompressPointer r7
    //     0x11bce64: add             x7, x7, HEAP, lsl #32
    // 0x11bce68: stur            x7, [fp, #-8]
    // 0x11bce6c: r0 = _RenderListTile()
    //     0x11bce6c: bl              #0x11bd078  ; Allocate_RenderListTileStub -> _RenderListTile (size=0x8c)
    // 0x11bce70: stur            x0, [fp, #-0x40]
    // 0x11bce74: ldur            x16, [fp, #-0x20]
    // 0x11bce78: ldur            lr, [fp, #-0x30]
    // 0x11bce7c: stp             lr, x16, [SP]
    // 0x11bce80: mov             x1, x0
    // 0x11bce84: ldur            d0, [fp, #-0x58]
    // 0x11bce88: ldur            x2, [fp, #-0x38]
    // 0x11bce8c: ldur            d1, [fp, #-0x48]
    // 0x11bce90: ldur            x3, [fp, #-0x10]
    // 0x11bce94: ldur            d2, [fp, #-0x50]
    // 0x11bce98: ldur            x5, [fp, #-0x18]
    // 0x11bce9c: ldur            x6, [fp, #-0x28]
    // 0x11bcea0: ldur            x7, [fp, #-8]
    // 0x11bcea4: r0 = _RenderListTile()
    //     0x11bcea4: bl              #0x11bcec0  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_RenderListTile
    // 0x11bcea8: ldur            x0, [fp, #-0x40]
    // 0x11bceac: LeaveFrame
    //     0x11bceac: mov             SP, fp
    //     0x11bceb0: ldp             fp, lr, [SP], #0x10
    // 0x11bceb4: ret
    //     0x11bceb4: ret             
    // 0x11bceb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11bceb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11bcebc: b               #0x11bce00
  }
  get _ slots(/* No info */) {
    // ** addr: 0x1226e14, size: 0xc
    // 0x1226e14: r0 = const [Instance of '_ListTileSlot', Instance of '_ListTileSlot', Instance of '_ListTileSlot', Instance of '_ListTileSlot']
    //     0x1226e14: add             x0, PP, #0x99, lsl #12  ; [pp+0x992e0] List<_ListTileSlot>(4)
    //     0x1226e18: ldr             x0, [x0, #0x2e0]
    // 0x1226e1c: ret
    //     0x1226e1c: ret             
  }
  _ childForSlot(/* No info */) {
    // ** addr: 0x12270a0, size: 0xcc
    // 0x12270a0: EnterFrame
    //     0x12270a0: stp             fp, lr, [SP, #-0x10]!
    //     0x12270a4: mov             fp, SP
    // 0x12270a8: AllocStack(0x10)
    //     0x12270a8: sub             SP, SP, #0x10
    // 0x12270ac: SetupParameters(_ListTile this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x12270ac: mov             x0, x2
    //     0x12270b0: mov             x4, x1
    //     0x12270b4: mov             x3, x2
    //     0x12270b8: stur            x1, [fp, #-8]
    //     0x12270bc: stur            x2, [fp, #-0x10]
    // 0x12270c0: r2 = Null
    //     0x12270c0: mov             x2, NULL
    // 0x12270c4: r1 = Null
    //     0x12270c4: mov             x1, NULL
    // 0x12270c8: r4 = 60
    //     0x12270c8: mov             x4, #0x3c
    // 0x12270cc: branchIfSmi(r0, 0x12270d8)
    //     0x12270cc: tbz             w0, #0, #0x12270d8
    // 0x12270d0: r4 = LoadClassIdInstr(r0)
    //     0x12270d0: ldur            x4, [x0, #-1]
    //     0x12270d4: ubfx            x4, x4, #0xc, #0x14
    // 0x12270d8: r17 = 8280
    //     0x12270d8: mov             x17, #0x2058
    // 0x12270dc: cmp             x4, x17
    // 0x12270e0: b.eq            #0x12270f8
    // 0x12270e4: r8 = _ListTileSlot
    //     0x12270e4: add             x8, PP, #0x99, lsl #12  ; [pp+0x992c8] Type: _ListTileSlot
    //     0x12270e8: ldr             x8, [x8, #0x2c8]
    // 0x12270ec: r3 = Null
    //     0x12270ec: add             x3, PP, #0x99, lsl #12  ; [pp+0x992d0] Null
    //     0x12270f0: ldr             x3, [x3, #0x2d0]
    // 0x12270f4: r0 = _ListTileSlot()
    //     0x12270f4: bl              #0xb1b9f0  ; IsType__ListTileSlot_Stub
    // 0x12270f8: ldur            x1, [fp, #-0x10]
    // 0x12270fc: LoadField: r2 = r1->field_7
    //     0x12270fc: ldur            x2, [x1, #7]
    // 0x1227100: cmp             x2, #1
    // 0x1227104: b.gt            #0x1227138
    // 0x1227108: cmp             x2, #0
    // 0x122710c: b.gt            #0x1227124
    // 0x1227110: ldur            x1, [fp, #-8]
    // 0x1227114: LoadField: r3 = r1->field_f
    //     0x1227114: ldur            w3, [x1, #0xf]
    // 0x1227118: DecompressPointer r3
    //     0x1227118: add             x3, x3, HEAP, lsl #32
    // 0x122711c: mov             x0, x3
    // 0x1227120: b               #0x1227160
    // 0x1227124: ldur            x1, [fp, #-8]
    // 0x1227128: LoadField: r3 = r1->field_13
    //     0x1227128: ldur            w3, [x1, #0x13]
    // 0x122712c: DecompressPointer r3
    //     0x122712c: add             x3, x3, HEAP, lsl #32
    // 0x1227130: mov             x0, x3
    // 0x1227134: b               #0x1227160
    // 0x1227138: ldur            x1, [fp, #-8]
    // 0x122713c: cmp             x2, #2
    // 0x1227140: b.gt            #0x1227154
    // 0x1227144: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x1227144: ldur            w2, [x1, #0x17]
    // 0x1227148: DecompressPointer r2
    //     0x1227148: add             x2, x2, HEAP, lsl #32
    // 0x122714c: mov             x0, x2
    // 0x1227150: b               #0x1227160
    // 0x1227154: LoadField: r2 = r1->field_1b
    //     0x1227154: ldur            w2, [x1, #0x1b]
    // 0x1227158: DecompressPointer r2
    //     0x1227158: add             x2, x2, HEAP, lsl #32
    // 0x122715c: mov             x0, x2
    // 0x1227160: LeaveFrame
    //     0x1227160: mov             SP, fp
    //     0x1227164: ldp             fp, lr, [SP], #0x10
    // 0x1227168: ret
    //     0x1227168: ret             
  }
}

// class id: 8280, size: 0x14, field offset: 0x14
enum _ListTileSlot extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa3b4, size: 0x64
    // 0x11aa3b4: EnterFrame
    //     0x11aa3b4: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa3b8: mov             fp, SP
    // 0x11aa3bc: AllocStack(0x10)
    //     0x11aa3bc: sub             SP, SP, #0x10
    // 0x11aa3c0: SetupParameters(_ListTileSlot this /* r1 => r0, fp-0x8 */)
    //     0x11aa3c0: mov             x0, x1
    //     0x11aa3c4: stur            x1, [fp, #-8]
    // 0x11aa3c8: CheckStackOverflow
    //     0x11aa3c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa3cc: cmp             SP, x16
    //     0x11aa3d0: b.ls            #0x11aa410
    // 0x11aa3d4: r1 = Null
    //     0x11aa3d4: mov             x1, NULL
    // 0x11aa3d8: r2 = 4
    //     0x11aa3d8: mov             x2, #4
    // 0x11aa3dc: r0 = AllocateArray()
    //     0x11aa3dc: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa3e0: r16 = "_ListTileSlot."
    //     0x11aa3e0: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3b48] "_ListTileSlot."
    //     0x11aa3e4: ldr             x16, [x16, #0xb48]
    // 0x11aa3e8: StoreField: r0->field_f = r16
    //     0x11aa3e8: stur            w16, [x0, #0xf]
    // 0x11aa3ec: ldur            x1, [fp, #-8]
    // 0x11aa3f0: LoadField: r2 = r1->field_f
    //     0x11aa3f0: ldur            w2, [x1, #0xf]
    // 0x11aa3f4: DecompressPointer r2
    //     0x11aa3f4: add             x2, x2, HEAP, lsl #32
    // 0x11aa3f8: StoreField: r0->field_13 = r2
    //     0x11aa3f8: stur            w2, [x0, #0x13]
    // 0x11aa3fc: str             x0, [SP]
    // 0x11aa400: r0 = _interpolate()
    //     0x11aa400: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa404: LeaveFrame
    //     0x11aa404: mov             SP, fp
    //     0x11aa408: ldp             fp, lr, [SP], #0x10
    // 0x11aa40c: ret
    //     0x11aa40c: ret             
    // 0x11aa410: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa410: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa414: b               #0x11aa3d4
  }
}

// class id: 8281, size: 0x14, field offset: 0x14
enum ListTileTitleAlignment extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _yOffsetFor(/* No info */) {
    // ** addr: 0xb50ef4, size: 0x244
    // 0xb50ef4: EnterFrame
    //     0xb50ef4: stp             fp, lr, [SP, #-0x10]!
    //     0xb50ef8: mov             fp, SP
    // 0xb50efc: CheckStackOverflow
    //     0xb50efc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb50f00: cmp             SP, x16
    //     0xb50f04: b.ls            #0xb510e0
    // 0xb50f08: r16 = Instance_ListTileTitleAlignment
    //     0xb50f08: add             x16, PP, #0x84, lsl #12  ; [pp+0x84a28] Obj!ListTileTitleAlignment@12c54e1
    //     0xb50f0c: ldr             x16, [x16, #0xa28]
    // 0xb50f10: cmp             w1, w16
    // 0xb50f14: b.ne            #0xb50f54
    // 0xb50f18: r1 = Instance_ListTileTitleAlignment
    //     0xb50f18: add             x1, PP, #0x99, lsl #12  ; [pp+0x993b0] Obj!ListTileTitleAlignment@12c54a1
    //     0xb50f1c: ldr             x1, [x1, #0x3b0]
    // 0xb50f20: r0 = _yOffsetFor()
    //     0xb50f20: bl              #0xb50ef4  ; [package:flutter/src/material/list_tile.dart] ListTileTitleAlignment::_yOffsetFor
    // 0xb50f24: r0 = inline_Allocate_Double()
    //     0xb50f24: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0xb50f28: add             x0, x0, #0x10
    //     0xb50f2c: cmp             x4, x0
    //     0xb50f30: b.ls            #0xb510e8
    //     0xb50f34: str             x0, [THR, #0x60]  ; THR::top
    //     0xb50f38: sub             x0, x0, #0xf
    //     0xb50f3c: mov             x4, #0xe19c
    //     0xb50f40: movk            x4, #3, lsl #16
    //     0xb50f44: stur            x4, [x0, #-1]
    // 0xb50f48: dmb             ishst
    // 0xb50f4c: StoreField: r0->field_7 = d0
    //     0xb50f4c: stur            d0, [x0, #7]
    // 0xb50f50: b               #0xb510d0
    // 0xb50f54: r16 = Instance_ListTileTitleAlignment
    //     0xb50f54: add             x16, PP, #0x84, lsl #12  ; [pp+0x84a30] Obj!ListTileTitleAlignment@12c54c1
    //     0xb50f58: ldr             x16, [x16, #0xa30]
    // 0xb50f5c: cmp             w1, w16
    // 0xb50f60: r16 = true
    //     0xb50f60: add             x16, NULL, #0x20  ; true
    // 0xb50f64: r17 = false
    //     0xb50f64: add             x17, NULL, #0x30  ; false
    // 0xb50f68: csel            x0, x16, x17, eq
    // 0xb50f6c: tbnz            w0, #4, #0xb50f8c
    // 0xb50f70: d2 = 72.000000
    //     0xb50f70: add             x17, PP, #0x89, lsl #12  ; [pp+0x89030] IMM: double(72) from 0x4052000000000000
    //     0xb50f74: ldr             d2, [x17, #0x30]
    // 0xb50f78: fcmp            d1, d2
    // 0xb50f7c: b.le            #0xb50f8c
    // 0xb50f80: r0 = 16.000000
    //     0xb50f80: add             x0, PP, #0x13, lsl #12  ; [pp+0x13df8] 16
    //     0xb50f84: ldr             x0, [x0, #0xdf8]
    // 0xb50f88: b               #0xb510d0
    // 0xb50f8c: tbnz            w0, #4, #0xb50ff0
    // 0xb50f90: tbnz            w3, #4, #0xb50fb0
    // 0xb50f94: d3 = 2.000000
    //     0xb50f94: fmov            d3, #2.00000000
    // 0xb50f98: d2 = 16.000000
    //     0xb50f98: fmov            d2, #16.00000000
    // 0xb50f9c: fsub            d4, d1, d0
    // 0xb50fa0: fdiv            d5, d4, d3
    // 0xb50fa4: fmin            v4.2d, v5.2d, v2.2d
    // 0xb50fa8: mov             v2.16b, v4.16b
    // 0xb50fac: b               #0xb50fc0
    // 0xb50fb0: d3 = 2.000000
    //     0xb50fb0: fmov            d3, #2.00000000
    // 0xb50fb4: fsub            d2, d1, d0
    // 0xb50fb8: fdiv            d4, d2, d3
    // 0xb50fbc: mov             v2.16b, v4.16b
    // 0xb50fc0: r0 = inline_Allocate_Double()
    //     0xb50fc0: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xb50fc4: add             x0, x0, #0x10
    //     0xb50fc8: cmp             x3, x0
    //     0xb50fcc: b.ls            #0xb510f8
    //     0xb50fd0: str             x0, [THR, #0x60]  ; THR::top
    //     0xb50fd4: sub             x0, x0, #0xf
    //     0xb50fd8: mov             x3, #0xe19c
    //     0xb50fdc: movk            x3, #3, lsl #16
    //     0xb50fe0: stur            x3, [x0, #-1]
    // 0xb50fe4: dmb             ishst
    // 0xb50fe8: StoreField: r0->field_7 = d2
    //     0xb50fe8: stur            d2, [x0, #7]
    // 0xb50fec: b               #0xb510d0
    // 0xb50ff0: d3 = 2.000000
    //     0xb50ff0: fmov            d3, #2.00000000
    // 0xb50ff4: r16 = Instance_ListTileTitleAlignment
    //     0xb50ff4: add             x16, PP, #0x99, lsl #12  ; [pp+0x993b8] Obj!ListTileTitleAlignment@12c5481
    //     0xb50ff8: ldr             x16, [x16, #0x3b8]
    // 0xb50ffc: cmp             w1, w16
    // 0xb51000: b.ne            #0xb51038
    // 0xb51004: LoadField: d2 = r2->field_73
    //     0xb51004: ldur            d2, [x2, #0x73]
    // 0xb51008: r0 = inline_Allocate_Double()
    //     0xb51008: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xb5100c: add             x0, x0, #0x10
    //     0xb51010: cmp             x3, x0
    //     0xb51014: b.ls            #0xb51108
    //     0xb51018: str             x0, [THR, #0x60]  ; THR::top
    //     0xb5101c: sub             x0, x0, #0xf
    //     0xb51020: mov             x3, #0xe19c
    //     0xb51024: movk            x3, #3, lsl #16
    //     0xb51028: stur            x3, [x0, #-1]
    // 0xb5102c: dmb             ishst
    // 0xb51030: StoreField: r0->field_7 = d2
    //     0xb51030: stur            d2, [x0, #7]
    // 0xb51034: b               #0xb510d0
    // 0xb51038: r16 = Instance_ListTileTitleAlignment
    //     0xb51038: add             x16, PP, #0x99, lsl #12  ; [pp+0x993b0] Obj!ListTileTitleAlignment@12c54a1
    //     0xb5103c: ldr             x16, [x16, #0x3b0]
    // 0xb51040: cmp             w1, w16
    // 0xb51044: b.ne            #0xb51080
    // 0xb51048: fsub            d2, d1, d0
    // 0xb5104c: fdiv            d4, d2, d3
    // 0xb51050: r0 = inline_Allocate_Double()
    //     0xb51050: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xb51054: add             x0, x0, #0x10
    //     0xb51058: cmp             x3, x0
    //     0xb5105c: b.ls            #0xb51118
    //     0xb51060: str             x0, [THR, #0x60]  ; THR::top
    //     0xb51064: sub             x0, x0, #0xf
    //     0xb51068: mov             x3, #0xe19c
    //     0xb5106c: movk            x3, #3, lsl #16
    //     0xb51070: stur            x3, [x0, #-1]
    // 0xb51074: dmb             ishst
    // 0xb51078: StoreField: r0->field_7 = d4
    //     0xb51078: stur            d4, [x0, #7]
    // 0xb5107c: b               #0xb510d0
    // 0xb51080: r16 = Instance_ListTileTitleAlignment
    //     0xb51080: add             x16, PP, #0x99, lsl #12  ; [pp+0x993c0] Obj!ListTileTitleAlignment@12c5461
    //     0xb51084: ldr             x16, [x16, #0x3c0]
    // 0xb51088: cmp             w1, w16
    // 0xb5108c: b.ne            #0xb510cc
    // 0xb51090: fsub            d2, d1, d0
    // 0xb51094: LoadField: d1 = r2->field_73
    //     0xb51094: ldur            d1, [x2, #0x73]
    // 0xb51098: fsub            d3, d2, d1
    // 0xb5109c: r0 = inline_Allocate_Double()
    //     0xb5109c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb510a0: add             x0, x0, #0x10
    //     0xb510a4: cmp             x1, x0
    //     0xb510a8: b.ls            #0xb51128
    //     0xb510ac: str             x0, [THR, #0x60]  ; THR::top
    //     0xb510b0: sub             x0, x0, #0xf
    //     0xb510b4: mov             x1, #0xe19c
    //     0xb510b8: movk            x1, #3, lsl #16
    //     0xb510bc: stur            x1, [x0, #-1]
    // 0xb510c0: dmb             ishst
    // 0xb510c4: StoreField: r0->field_7 = d3
    //     0xb510c4: stur            d3, [x0, #7]
    // 0xb510c8: b               #0xb510d0
    // 0xb510cc: r0 = Null
    //     0xb510cc: mov             x0, NULL
    // 0xb510d0: LoadField: d0 = r0->field_7
    //     0xb510d0: ldur            d0, [x0, #7]
    // 0xb510d4: LeaveFrame
    //     0xb510d4: mov             SP, fp
    //     0xb510d8: ldp             fp, lr, [SP], #0x10
    // 0xb510dc: ret
    //     0xb510dc: ret             
    // 0xb510e0: r0 = StackOverflowSharedWithFPURegs()
    //     0xb510e0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb510e4: b               #0xb50f08
    // 0xb510e8: SaveReg d0
    //     0xb510e8: str             q0, [SP, #-0x10]!
    // 0xb510ec: r0 = AllocateDouble()
    //     0xb510ec: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb510f0: RestoreReg d0
    //     0xb510f0: ldr             q0, [SP], #0x10
    // 0xb510f4: b               #0xb50f4c
    // 0xb510f8: SaveReg d2
    //     0xb510f8: str             q2, [SP, #-0x10]!
    // 0xb510fc: r0 = AllocateDouble()
    //     0xb510fc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb51100: RestoreReg d2
    //     0xb51100: ldr             q2, [SP], #0x10
    // 0xb51104: b               #0xb50fe8
    // 0xb51108: SaveReg d2
    //     0xb51108: str             q2, [SP, #-0x10]!
    // 0xb5110c: r0 = AllocateDouble()
    //     0xb5110c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb51110: RestoreReg d2
    //     0xb51110: ldr             q2, [SP], #0x10
    // 0xb51114: b               #0xb51030
    // 0xb51118: SaveReg d4
    //     0xb51118: str             q4, [SP, #-0x10]!
    // 0xb5111c: r0 = AllocateDouble()
    //     0xb5111c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb51120: RestoreReg d4
    //     0xb51120: ldr             q4, [SP], #0x10
    // 0xb51124: b               #0xb51078
    // 0xb51128: SaveReg d3
    //     0xb51128: str             q3, [SP, #-0x10]!
    // 0xb5112c: r0 = AllocateDouble()
    //     0xb5112c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb51130: RestoreReg d3
    //     0xb51130: ldr             q3, [SP], #0x10
    // 0xb51134: b               #0xb510c4
  }
  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa350, size: 0x64
    // 0x11aa350: EnterFrame
    //     0x11aa350: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa354: mov             fp, SP
    // 0x11aa358: AllocStack(0x10)
    //     0x11aa358: sub             SP, SP, #0x10
    // 0x11aa35c: SetupParameters(ListTileTitleAlignment this /* r1 => r0, fp-0x8 */)
    //     0x11aa35c: mov             x0, x1
    //     0x11aa360: stur            x1, [fp, #-8]
    // 0x11aa364: CheckStackOverflow
    //     0x11aa364: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa368: cmp             SP, x16
    //     0x11aa36c: b.ls            #0x11aa3ac
    // 0x11aa370: r1 = Null
    //     0x11aa370: mov             x1, NULL
    // 0x11aa374: r2 = 4
    //     0x11aa374: mov             x2, #4
    // 0x11aa378: r0 = AllocateArray()
    //     0x11aa378: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa37c: r16 = "ListTileTitleAlignment."
    //     0x11aa37c: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fd20] "ListTileTitleAlignment."
    //     0x11aa380: ldr             x16, [x16, #0xd20]
    // 0x11aa384: StoreField: r0->field_f = r16
    //     0x11aa384: stur            w16, [x0, #0xf]
    // 0x11aa388: ldur            x1, [fp, #-8]
    // 0x11aa38c: LoadField: r2 = r1->field_f
    //     0x11aa38c: ldur            w2, [x1, #0xf]
    // 0x11aa390: DecompressPointer r2
    //     0x11aa390: add             x2, x2, HEAP, lsl #32
    // 0x11aa394: StoreField: r0->field_13 = r2
    //     0x11aa394: stur            w2, [x0, #0x13]
    // 0x11aa398: str             x0, [SP]
    // 0x11aa39c: r0 = _interpolate()
    //     0x11aa39c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa3a0: LeaveFrame
    //     0x11aa3a0: mov             SP, fp
    //     0x11aa3a4: ldp             fp, lr, [SP], #0x10
    // 0x11aa3a8: ret
    //     0x11aa3a8: ret             
    // 0x11aa3ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa3ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa3b0: b               #0x11aa370
  }
}

// class id: 8282, size: 0x14, field offset: 0x14
enum ListTileControlAffinity extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa2ec, size: 0x64
    // 0x11aa2ec: EnterFrame
    //     0x11aa2ec: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa2f0: mov             fp, SP
    // 0x11aa2f4: AllocStack(0x10)
    //     0x11aa2f4: sub             SP, SP, #0x10
    // 0x11aa2f8: SetupParameters(ListTileControlAffinity this /* r1 => r0, fp-0x8 */)
    //     0x11aa2f8: mov             x0, x1
    //     0x11aa2fc: stur            x1, [fp, #-8]
    // 0x11aa300: CheckStackOverflow
    //     0x11aa300: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa304: cmp             SP, x16
    //     0x11aa308: b.ls            #0x11aa348
    // 0x11aa30c: r1 = Null
    //     0x11aa30c: mov             x1, NULL
    // 0x11aa310: r2 = 4
    //     0x11aa310: mov             x2, #4
    // 0x11aa314: r0 = AllocateArray()
    //     0x11aa314: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa318: r16 = "ListTileControlAffinity."
    //     0x11aa318: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3b40] "ListTileControlAffinity."
    //     0x11aa31c: ldr             x16, [x16, #0xb40]
    // 0x11aa320: StoreField: r0->field_f = r16
    //     0x11aa320: stur            w16, [x0, #0xf]
    // 0x11aa324: ldur            x1, [fp, #-8]
    // 0x11aa328: LoadField: r2 = r1->field_f
    //     0x11aa328: ldur            w2, [x1, #0xf]
    // 0x11aa32c: DecompressPointer r2
    //     0x11aa32c: add             x2, x2, HEAP, lsl #32
    // 0x11aa330: StoreField: r0->field_13 = r2
    //     0x11aa330: stur            w2, [x0, #0x13]
    // 0x11aa334: str             x0, [SP]
    // 0x11aa338: r0 = _interpolate()
    //     0x11aa338: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa33c: LeaveFrame
    //     0x11aa33c: mov             SP, fp
    //     0x11aa340: ldp             fp, lr, [SP], #0x10
    // 0x11aa344: ret
    //     0x11aa344: ret             
    // 0x11aa348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa348: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa34c: b               #0x11aa30c
  }
}

// class id: 8283, size: 0x14, field offset: 0x14
enum ListTileStyle extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa288, size: 0x64
    // 0x11aa288: EnterFrame
    //     0x11aa288: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa28c: mov             fp, SP
    // 0x11aa290: AllocStack(0x10)
    //     0x11aa290: sub             SP, SP, #0x10
    // 0x11aa294: SetupParameters(ListTileStyle this /* r1 => r0, fp-0x8 */)
    //     0x11aa294: mov             x0, x1
    //     0x11aa298: stur            x1, [fp, #-8]
    // 0x11aa29c: CheckStackOverflow
    //     0x11aa29c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa2a0: cmp             SP, x16
    //     0x11aa2a4: b.ls            #0x11aa2e4
    // 0x11aa2a8: r1 = Null
    //     0x11aa2a8: mov             x1, NULL
    // 0x11aa2ac: r2 = 4
    //     0x11aa2ac: mov             x2, #4
    // 0x11aa2b0: r0 = AllocateArray()
    //     0x11aa2b0: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa2b4: r16 = "ListTileStyle."
    //     0x11aa2b4: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fcf0] "ListTileStyle."
    //     0x11aa2b8: ldr             x16, [x16, #0xcf0]
    // 0x11aa2bc: StoreField: r0->field_f = r16
    //     0x11aa2bc: stur            w16, [x0, #0xf]
    // 0x11aa2c0: ldur            x1, [fp, #-8]
    // 0x11aa2c4: LoadField: r2 = r1->field_f
    //     0x11aa2c4: ldur            w2, [x1, #0xf]
    // 0x11aa2c8: DecompressPointer r2
    //     0x11aa2c8: add             x2, x2, HEAP, lsl #32
    // 0x11aa2cc: StoreField: r0->field_13 = r2
    //     0x11aa2cc: stur            w2, [x0, #0x13]
    // 0x11aa2d0: str             x0, [SP]
    // 0x11aa2d4: r0 = _interpolate()
    //     0x11aa2d4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa2d8: LeaveFrame
    //     0x11aa2d8: mov             SP, fp
    //     0x11aa2dc: ldp             fp, lr, [SP], #0x10
    // 0x11aa2e0: ret
    //     0x11aa2e0: ret             
    // 0x11aa2e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa2e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa2e8: b               #0x11aa2a8
  }
}
