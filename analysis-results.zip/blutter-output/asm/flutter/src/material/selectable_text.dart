// lib: , url: package:flutter/src/material/selectable_text.dart

// class id: 1048944, size: 0x8
class :: {
}

// class id: 2988, size: 0x30, field offset: 0x2c
class _SelectableTextSelectionGestureDetectorBuilder extends TextSelectionGestureDetectorBuilder {

  [closure] void onSingleTapUp(dynamic, TapDragUpDetails) {
    // ** addr: 0xd47824, size: 0x3c
    // 0xd47824: EnterFrame
    //     0xd47824: stp             fp, lr, [SP, #-0x10]!
    //     0xd47828: mov             fp, SP
    // 0xd4782c: ldr             x0, [fp, #0x18]
    // 0xd47830: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd47830: ldur            w1, [x0, #0x17]
    // 0xd47834: DecompressPointer r1
    //     0xd47834: add             x1, x1, HEAP, lsl #32
    // 0xd47838: CheckStackOverflow
    //     0xd47838: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4783c: cmp             SP, x16
    //     0xd47840: b.ls            #0xd47858
    // 0xd47844: ldr             x2, [fp, #0x10]
    // 0xd47848: r0 = onSingleTapUp()
    //     0xd47848: bl              #0xd47860  ; [package:flutter/src/material/selectable_text.dart] _SelectableTextSelectionGestureDetectorBuilder::onSingleTapUp
    // 0xd4784c: LeaveFrame
    //     0xd4784c: mov             SP, fp
    //     0xd47850: ldp             fp, lr, [SP], #0x10
    // 0xd47854: ret
    //     0xd47854: ret             
    // 0xd47858: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd47858: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4785c: b               #0xd47844
  }
  _ onSingleTapUp(/* No info */) {
    // ** addr: 0xd47860, size: 0x9c
    // 0xd47860: EnterFrame
    //     0xd47860: stp             fp, lr, [SP, #-0x10]!
    //     0xd47864: mov             fp, SP
    // 0xd47868: AllocStack(0x10)
    //     0xd47868: sub             SP, SP, #0x10
    // 0xd4786c: SetupParameters(_SelectableTextSelectionGestureDetectorBuilder this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd4786c: mov             x3, x1
    //     0xd47870: stur            x1, [fp, #-8]
    //     0xd47874: stur            x2, [fp, #-0x10]
    // 0xd47878: CheckStackOverflow
    //     0xd47878: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4787c: cmp             SP, x16
    //     0xd47880: b.ls            #0xd478f0
    // 0xd47884: LoadField: r1 = r3->field_7
    //     0xd47884: ldur            w1, [x3, #7]
    // 0xd47888: DecompressPointer r1
    //     0xd47888: add             x1, x1, HEAP, lsl #32
    // 0xd4788c: r0 = LoadClassIdInstr(r1)
    //     0xd4788c: ldur            x0, [x1, #-1]
    //     0xd47890: ubfx            x0, x0, #0xc, #0x14
    // 0xd47894: r0 = GDT[cid_x0 + -0xff6]()
    //     0xd47894: sub             lr, x0, #0xff6
    //     0xd47898: ldr             lr, [x21, lr, lsl #3]
    //     0xd4789c: blr             lr
    // 0xd478a0: tbz             w0, #4, #0xd478b4
    // 0xd478a4: r0 = Null
    //     0xd478a4: mov             x0, NULL
    // 0xd478a8: LeaveFrame
    //     0xd478a8: mov             SP, fp
    //     0xd478ac: ldp             fp, lr, [SP], #0x10
    // 0xd478b0: ret
    //     0xd478b0: ret             
    // 0xd478b4: ldur            x0, [fp, #-8]
    // 0xd478b8: mov             x1, x0
    // 0xd478bc: ldur            x2, [fp, #-0x10]
    // 0xd478c0: r0 = onSingleTapUp()
    //     0xd478c0: bl              #0xd478fc  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionGestureDetectorBuilder::onSingleTapUp
    // 0xd478c4: ldur            x1, [fp, #-8]
    // 0xd478c8: LoadField: r2 = r1->field_2b
    //     0xd478c8: ldur            w2, [x1, #0x2b]
    // 0xd478cc: DecompressPointer r2
    //     0xd478cc: add             x2, x2, HEAP, lsl #32
    // 0xd478d0: LoadField: r1 = r2->field_b
    //     0xd478d0: ldur            w1, [x2, #0xb]
    // 0xd478d4: DecompressPointer r1
    //     0xd478d4: add             x1, x1, HEAP, lsl #32
    // 0xd478d8: cmp             w1, NULL
    // 0xd478dc: b.eq            #0xd478f8
    // 0xd478e0: r0 = Null
    //     0xd478e0: mov             x0, NULL
    // 0xd478e4: LeaveFrame
    //     0xd478e4: mov             SP, fp
    //     0xd478e8: ldp             fp, lr, [SP], #0x10
    // 0xd478ec: ret
    //     0xd478ec: ret             
    // 0xd478f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd478f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd478f4: b               #0xd47884
    // 0xd478f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd478f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4532, size: 0x30, field offset: 0x2c
class _TextSpanEditingController extends TextEditingController {

  _ buildTextSpan(/* No info */) {
    // ** addr: 0x12336cc, size: 0x8c
    // 0x12336cc: EnterFrame
    //     0x12336cc: stp             fp, lr, [SP, #-0x10]!
    //     0x12336d0: mov             fp, SP
    // 0x12336d4: AllocStack(0x18)
    //     0x12336d4: sub             SP, SP, #0x18
    // 0x12336d8: r0 = 2
    //     0x12336d8: mov             x0, #2
    // 0x12336dc: mov             x4, x2
    // 0x12336e0: stur            x2, [fp, #-0x10]
    // 0x12336e4: LoadField: r3 = r1->field_2b
    //     0x12336e4: ldur            w3, [x1, #0x2b]
    // 0x12336e8: DecompressPointer r3
    //     0x12336e8: add             x3, x3, HEAP, lsl #32
    // 0x12336ec: mov             x2, x0
    // 0x12336f0: stur            x3, [fp, #-8]
    // 0x12336f4: r1 = Null
    //     0x12336f4: mov             x1, NULL
    // 0x12336f8: r0 = AllocateArray()
    //     0x12336f8: bl              #0x13df928  ; AllocateArrayStub
    // 0x12336fc: mov             x2, x0
    // 0x1233700: ldur            x0, [fp, #-8]
    // 0x1233704: stur            x2, [fp, #-0x18]
    // 0x1233708: StoreField: r2->field_f = r0
    //     0x1233708: stur            w0, [x2, #0xf]
    // 0x123370c: r1 = <TextSpan>
    //     0x123370c: add             x1, PP, #0x7c, lsl #12  ; [pp+0x7ced8] TypeArguments: <TextSpan>
    //     0x1233710: ldr             x1, [x1, #0xed8]
    // 0x1233714: r0 = AllocateGrowableArray()
    //     0x1233714: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x1233718: mov             x1, x0
    // 0x123371c: ldur            x0, [fp, #-0x18]
    // 0x1233720: stur            x1, [fp, #-8]
    // 0x1233724: StoreField: r1->field_f = r0
    //     0x1233724: stur            w0, [x1, #0xf]
    // 0x1233728: r0 = 2
    //     0x1233728: mov             x0, #2
    // 0x123372c: StoreField: r1->field_b = r0
    //     0x123372c: stur            w0, [x1, #0xb]
    // 0x1233730: r0 = TextSpan()
    //     0x1233730: bl              #0xb57880  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0x1233734: ldur            x1, [fp, #-8]
    // 0x1233738: StoreField: r0->field_f = r1
    //     0x1233738: stur            w1, [x0, #0xf]
    // 0x123373c: r1 = Instance__DeferringMouseCursor
    //     0x123373c: ldr             x1, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0x1233740: ArrayStore: r0[0] = r1  ; List_4
    //     0x1233740: stur            w1, [x0, #0x17]
    // 0x1233744: ldur            x1, [fp, #-0x10]
    // 0x1233748: StoreField: r0->field_7 = r1
    //     0x1233748: stur            w1, [x0, #7]
    // 0x123374c: LeaveFrame
    //     0x123374c: mov             SP, fp
    //     0x1233750: ldp             fp, lr, [SP], #0x10
    // 0x1233754: ret
    //     0x1233754: ret             
  }
}

// class id: 5456, size: 0x2c, field offset: 0x14
class _SelectableTextState extends State<dynamic>
    implements TextSelectionGestureDetectorBuilderDelegate {

  late _TextSpanEditingController _controller; // offset: 0x14
  late _SelectableTextSelectionGestureDetectorBuilder _selectionGestureDetectorBuilder; // offset: 0x20
  late bool forcePressEnabled; // offset: 0x24

  _ build(/* No info */) {
    // ** addr: 0xdfc2bc, size: 0x850
    // 0xdfc2bc: EnterFrame
    //     0xdfc2bc: stp             fp, lr, [SP, #-0x10]!
    //     0xdfc2c0: mov             fp, SP
    // 0xdfc2c4: AllocStack(0x160)
    //     0xdfc2c4: sub             SP, SP, #0x160
    // 0xdfc2c8: SetupParameters(_SelectableTextState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xdfc2c8: mov             x0, x1
    //     0xdfc2cc: stur            x1, [fp, #-8]
    //     0xdfc2d0: mov             x1, x2
    //     0xdfc2d4: stur            x2, [fp, #-0x10]
    // 0xdfc2d8: CheckStackOverflow
    //     0xdfc2d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfc2dc: cmp             SP, x16
    //     0xdfc2e0: b.ls            #0xdfcac8
    // 0xdfc2e4: r1 = 1
    //     0xdfc2e4: mov             x1, #1
    // 0xdfc2e8: r0 = AllocateContext()
    //     0xdfc2e8: bl              #0x13de838  ; AllocateContextStub
    // 0xdfc2ec: mov             x2, x0
    // 0xdfc2f0: ldur            x0, [fp, #-8]
    // 0xdfc2f4: stur            x2, [fp, #-0x18]
    // 0xdfc2f8: StoreField: r2->field_f = r0
    //     0xdfc2f8: stur            w0, [x2, #0xf]
    // 0xdfc2fc: ldur            x1, [fp, #-0x10]
    // 0xdfc300: r0 = of()
    //     0xdfc300: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdfc304: ldur            x1, [fp, #-0x10]
    // 0xdfc308: stur            x0, [fp, #-0x20]
    // 0xdfc30c: r0 = of()
    //     0xdfc30c: bl              #0xd2096c  ; [package:flutter/src/widgets/default_selection_style.dart] DefaultSelectionStyle::of
    // 0xdfc310: ldur            x1, [fp, #-8]
    // 0xdfc314: stur            x0, [fp, #-0x28]
    // 0xdfc318: r0 = _effectiveFocusNode()
    //     0xdfc318: bl              #0xdfcb30  ; [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_effectiveFocusNode
    // 0xdfc31c: ldur            x2, [fp, #-8]
    // 0xdfc320: stur            x0, [fp, #-0x30]
    // 0xdfc324: LoadField: r1 = r2->field_b
    //     0xdfc324: ldur            w1, [x2, #0xb]
    // 0xdfc328: DecompressPointer r1
    //     0xdfc328: add             x1, x1, HEAP, lsl #32
    // 0xdfc32c: cmp             w1, NULL
    // 0xdfc330: b.eq            #0xdfcad0
    // 0xdfc334: ldur            x1, [fp, #-0x20]
    // 0xdfc338: LoadField: r3 = r1->field_23
    //     0xdfc338: ldur            w3, [x1, #0x23]
    // 0xdfc33c: DecompressPointer r3
    //     0xdfc33c: add             x3, x3, HEAP, lsl #32
    // 0xdfc340: LoadField: r4 = r3->field_7
    //     0xdfc340: ldur            x4, [x3, #7]
    // 0xdfc344: cmp             x4, #2
    // 0xdfc348: b.gt            #0xdfc5bc
    // 0xdfc34c: cmp             x4, #1
    // 0xdfc350: b.gt            #0xdfc428
    // 0xdfc354: ldur            x3, [fp, #-0x28]
    // 0xdfc358: r4 = false
    //     0xdfc358: add             x4, NULL, #0x30  ; false
    // 0xdfc35c: StoreField: r2->field_23 = r4
    //     0xdfc35c: stur            w4, [x2, #0x23]
    // 0xdfc360: r0 = LoadStaticField(0x7b8)
    //     0xdfc360: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xdfc364: ldr             x0, [x0, #0xf70]
    // 0xdfc368: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfc36c: cmp             w0, w16
    // 0xdfc370: b.ne            #0xdfc380
    // 0xdfc374: r2 = materialTextSelectionHandleControls
    //     0xdfc374: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f610] Field <::.materialTextSelectionHandleControls>: static late final (offset: 0x7b8)
    //     0xdfc378: ldr             x2, [x2, #0x610]
    // 0xdfc37c: r0 = InitLateFinalStaticField()
    //     0xdfc37c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xdfc380: ldur            x2, [fp, #-8]
    // 0xdfc384: stur            x0, [fp, #-0x40]
    // 0xdfc388: LoadField: r1 = r2->field_b
    //     0xdfc388: ldur            w1, [x2, #0xb]
    // 0xdfc38c: DecompressPointer r1
    //     0xdfc38c: add             x1, x1, HEAP, lsl #32
    // 0xdfc390: cmp             w1, NULL
    // 0xdfc394: b.eq            #0xdfcad4
    // 0xdfc398: ldur            x3, [fp, #-0x28]
    // 0xdfc39c: LoadField: r1 = r3->field_f
    //     0xdfc39c: ldur            w1, [x3, #0xf]
    // 0xdfc3a0: DecompressPointer r1
    //     0xdfc3a0: add             x1, x1, HEAP, lsl #32
    // 0xdfc3a4: cmp             w1, NULL
    // 0xdfc3a8: b.ne            #0xdfc3c4
    // 0xdfc3ac: ldur            x5, [fp, #-0x20]
    // 0xdfc3b0: LoadField: r1 = r5->field_3f
    //     0xdfc3b0: ldur            w1, [x5, #0x3f]
    // 0xdfc3b4: DecompressPointer r1
    //     0xdfc3b4: add             x1, x1, HEAP, lsl #32
    // 0xdfc3b8: LoadField: r4 = r1->field_b
    //     0xdfc3b8: ldur            w4, [x1, #0xb]
    // 0xdfc3bc: DecompressPointer r4
    //     0xdfc3bc: add             x4, x4, HEAP, lsl #32
    // 0xdfc3c0: b               #0xdfc3cc
    // 0xdfc3c4: ldur            x5, [fp, #-0x20]
    // 0xdfc3c8: mov             x4, x1
    // 0xdfc3cc: stur            x4, [fp, #-0x38]
    // 0xdfc3d0: LoadField: r1 = r3->field_13
    //     0xdfc3d0: ldur            w1, [x3, #0x13]
    // 0xdfc3d4: DecompressPointer r1
    //     0xdfc3d4: add             x1, x1, HEAP, lsl #32
    // 0xdfc3d8: cmp             w1, NULL
    // 0xdfc3dc: b.ne            #0xdfc404
    // 0xdfc3e0: LoadField: r1 = r5->field_3f
    //     0xdfc3e0: ldur            w1, [x5, #0x3f]
    // 0xdfc3e4: DecompressPointer r1
    //     0xdfc3e4: add             x1, x1, HEAP, lsl #32
    // 0xdfc3e8: LoadField: r3 = r1->field_b
    //     0xdfc3e8: ldur            w3, [x1, #0xb]
    // 0xdfc3ec: DecompressPointer r3
    //     0xdfc3ec: add             x3, x3, HEAP, lsl #32
    // 0xdfc3f0: mov             x1, x3
    // 0xdfc3f4: d0 = 0.400000
    //     0xdfc3f4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13368] IMM: double(0.4) from 0x3fd999999999999a
    //     0xdfc3f8: ldr             d0, [x17, #0x368]
    // 0xdfc3fc: r0 = withOpacity()
    //     0xdfc3fc: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xdfc400: b               #0xdfc408
    // 0xdfc404: mov             x0, x1
    // 0xdfc408: ldur            x8, [fp, #-0x40]
    // 0xdfc40c: ldur            x7, [fp, #-0x38]
    // 0xdfc410: mov             x3, x0
    // 0xdfc414: r6 = false
    //     0xdfc414: add             x6, NULL, #0x30  ; false
    // 0xdfc418: r5 = false
    //     0xdfc418: add             x5, NULL, #0x30  ; false
    // 0xdfc41c: r4 = Null
    //     0xdfc41c: mov             x4, NULL
    // 0xdfc420: r0 = Null
    //     0xdfc420: mov             x0, NULL
    // 0xdfc424: b               #0xdfc838
    // 0xdfc428: ldur            x3, [fp, #-0x28]
    // 0xdfc42c: ldur            x1, [fp, #-0x10]
    // 0xdfc430: r0 = of()
    //     0xdfc430: bl              #0xccc364  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0xdfc434: mov             x1, x0
    // 0xdfc438: ldur            x2, [fp, #-8]
    // 0xdfc43c: r0 = true
    //     0xdfc43c: add             x0, NULL, #0x20  ; true
    // 0xdfc440: stur            x1, [fp, #-0x38]
    // 0xdfc444: StoreField: r2->field_23 = r0
    //     0xdfc444: stur            w0, [x2, #0x23]
    // 0xdfc448: r0 = LoadStaticField(0x9bc)
    //     0xdfc448: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xdfc44c: ldr             x0, [x0, #0x1378]
    // 0xdfc450: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfc454: cmp             w0, w16
    // 0xdfc458: b.ne            #0xdfc468
    // 0xdfc45c: r2 = cupertinoTextSelectionHandleControls
    //     0xdfc45c: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f618] Field <::.cupertinoTextSelectionHandleControls>: static late final (offset: 0x9bc)
    //     0xdfc460: ldr             x2, [x2, #0x618]
    // 0xdfc464: r0 = InitLateFinalStaticField()
    //     0xdfc464: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xdfc468: mov             x3, x0
    // 0xdfc46c: ldur            x2, [fp, #-8]
    // 0xdfc470: stur            x3, [fp, #-0x48]
    // 0xdfc474: LoadField: r0 = r2->field_b
    //     0xdfc474: ldur            w0, [x2, #0xb]
    // 0xdfc478: DecompressPointer r0
    //     0xdfc478: add             x0, x0, HEAP, lsl #32
    // 0xdfc47c: cmp             w0, NULL
    // 0xdfc480: b.eq            #0xdfcad8
    // 0xdfc484: ldur            x0, [fp, #-0x28]
    // 0xdfc488: LoadField: r1 = r0->field_f
    //     0xdfc488: ldur            w1, [x0, #0xf]
    // 0xdfc48c: DecompressPointer r1
    //     0xdfc48c: add             x1, x1, HEAP, lsl #32
    // 0xdfc490: cmp             w1, NULL
    // 0xdfc494: b.ne            #0xdfc4e8
    // 0xdfc498: ldur            x4, [fp, #-0x38]
    // 0xdfc49c: r1 = LoadClassIdInstr(r4)
    //     0xdfc49c: ldur            x1, [x4, #-1]
    //     0xdfc4a0: ubfx            x1, x1, #0xc, #0x14
    // 0xdfc4a4: r17 = 4617
    //     0xdfc4a4: mov             x17, #0x1209
    // 0xdfc4a8: cmp             x1, x17
    // 0xdfc4ac: b.ne            #0xdfc4c8
    // 0xdfc4b0: LoadField: r1 = r4->field_27
    //     0xdfc4b0: ldur            w1, [x4, #0x27]
    // 0xdfc4b4: DecompressPointer r1
    //     0xdfc4b4: add             x1, x1, HEAP, lsl #32
    // 0xdfc4b8: LoadField: r5 = r1->field_b
    //     0xdfc4b8: ldur            w5, [x1, #0xb]
    // 0xdfc4bc: DecompressPointer r5
    //     0xdfc4bc: add             x5, x5, HEAP, lsl #32
    // 0xdfc4c0: mov             x1, x5
    // 0xdfc4c4: b               #0xdfc4e0
    // 0xdfc4c8: LoadField: r1 = r4->field_2b
    //     0xdfc4c8: ldur            w1, [x4, #0x2b]
    // 0xdfc4cc: DecompressPointer r1
    //     0xdfc4cc: add             x1, x1, HEAP, lsl #32
    // 0xdfc4d0: LoadField: r5 = r1->field_3f
    //     0xdfc4d0: ldur            w5, [x1, #0x3f]
    // 0xdfc4d4: DecompressPointer r5
    //     0xdfc4d4: add             x5, x5, HEAP, lsl #32
    // 0xdfc4d8: LoadField: r1 = r5->field_b
    //     0xdfc4d8: ldur            w1, [x5, #0xb]
    // 0xdfc4dc: DecompressPointer r1
    //     0xdfc4dc: add             x1, x1, HEAP, lsl #32
    // 0xdfc4e0: mov             x5, x1
    // 0xdfc4e4: b               #0xdfc4f0
    // 0xdfc4e8: ldur            x4, [fp, #-0x38]
    // 0xdfc4ec: mov             x5, x1
    // 0xdfc4f0: stur            x5, [fp, #-0x40]
    // 0xdfc4f4: LoadField: r1 = r0->field_13
    //     0xdfc4f4: ldur            w1, [x0, #0x13]
    // 0xdfc4f8: DecompressPointer r1
    //     0xdfc4f8: add             x1, x1, HEAP, lsl #32
    // 0xdfc4fc: cmp             w1, NULL
    // 0xdfc500: b.ne            #0xdfc568
    // 0xdfc504: r0 = LoadClassIdInstr(r4)
    //     0xdfc504: ldur            x0, [x4, #-1]
    //     0xdfc508: ubfx            x0, x0, #0xc, #0x14
    // 0xdfc50c: r17 = 4617
    //     0xdfc50c: mov             x17, #0x1209
    // 0xdfc510: cmp             x0, x17
    // 0xdfc514: b.ne            #0xdfc52c
    // 0xdfc518: LoadField: r0 = r4->field_27
    //     0xdfc518: ldur            w0, [x4, #0x27]
    // 0xdfc51c: DecompressPointer r0
    //     0xdfc51c: add             x0, x0, HEAP, lsl #32
    // 0xdfc520: LoadField: r1 = r0->field_b
    //     0xdfc520: ldur            w1, [x0, #0xb]
    // 0xdfc524: DecompressPointer r1
    //     0xdfc524: add             x1, x1, HEAP, lsl #32
    // 0xdfc528: b               #0xdfc548
    // 0xdfc52c: LoadField: r0 = r4->field_2b
    //     0xdfc52c: ldur            w0, [x4, #0x2b]
    // 0xdfc530: DecompressPointer r0
    //     0xdfc530: add             x0, x0, HEAP, lsl #32
    // 0xdfc534: LoadField: r1 = r0->field_3f
    //     0xdfc534: ldur            w1, [x0, #0x3f]
    // 0xdfc538: DecompressPointer r1
    //     0xdfc538: add             x1, x1, HEAP, lsl #32
    // 0xdfc53c: LoadField: r0 = r1->field_b
    //     0xdfc53c: ldur            w0, [x1, #0xb]
    // 0xdfc540: DecompressPointer r0
    //     0xdfc540: add             x0, x0, HEAP, lsl #32
    // 0xdfc544: mov             x1, x0
    // 0xdfc548: r0 = LoadClassIdInstr(r1)
    //     0xdfc548: ldur            x0, [x1, #-1]
    //     0xdfc54c: ubfx            x0, x0, #0xc, #0x14
    // 0xdfc550: d0 = 0.400000
    //     0xdfc550: add             x17, PP, #0x13, lsl #12  ; [pp+0x13368] IMM: double(0.4) from 0x3fd999999999999a
    //     0xdfc554: ldr             d0, [x17, #0x368]
    // 0xdfc558: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdfc558: sub             lr, x0, #1, lsl #12
    //     0xdfc55c: ldr             lr, [x21, lr, lsl #3]
    //     0xdfc560: blr             lr
    // 0xdfc564: b               #0xdfc56c
    // 0xdfc568: mov             x0, x1
    // 0xdfc56c: ldur            x1, [fp, #-0x10]
    // 0xdfc570: stur            x0, [fp, #-0x38]
    // 0xdfc574: r0 = devicePixelRatioOf()
    //     0xdfc574: bl              #0xcfce5c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::devicePixelRatioOf
    // 0xdfc578: mov             v1.16b, v0.16b
    // 0xdfc57c: d0 = -2.000000
    //     0xdfc57c: fmov            d0, #-2.00000000
    // 0xdfc580: fdiv            d2, d0, d1
    // 0xdfc584: stur            d2, [fp, #-0xa8]
    // 0xdfc588: r0 = Offset()
    //     0xdfc588: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xdfc58c: ldur            d0, [fp, #-0xa8]
    // 0xdfc590: StoreField: r0->field_7 = d0
    //     0xdfc590: stur            d0, [x0, #7]
    // 0xdfc594: StoreField: r0->field_f = rZR
    //     0xdfc594: stur            xzr, [x0, #0xf]
    // 0xdfc598: ldur            x8, [fp, #-0x48]
    // 0xdfc59c: mov             x4, x0
    // 0xdfc5a0: ldur            x7, [fp, #-0x40]
    // 0xdfc5a4: ldur            x3, [fp, #-0x38]
    // 0xdfc5a8: r6 = true
    //     0xdfc5a8: add             x6, NULL, #0x20  ; true
    // 0xdfc5ac: r5 = true
    //     0xdfc5ac: add             x5, NULL, #0x20  ; true
    // 0xdfc5b0: r0 = Instance_Radius
    //     0xdfc5b0: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8f620] Obj!Radius@12a7241
    //     0xdfc5b4: ldr             x0, [x0, #0x620]
    // 0xdfc5b8: b               #0xdfc838
    // 0xdfc5bc: mov             x5, x1
    // 0xdfc5c0: ldur            x0, [fp, #-0x28]
    // 0xdfc5c4: d0 = -2.000000
    //     0xdfc5c4: fmov            d0, #-2.00000000
    // 0xdfc5c8: cmp             x4, #4
    // 0xdfc5cc: b.gt            #0xdfc768
    // 0xdfc5d0: cmp             x4, #3
    // 0xdfc5d4: b.le            #0xdfc768
    // 0xdfc5d8: ldur            x2, [fp, #-8]
    // 0xdfc5dc: ldur            x1, [fp, #-0x10]
    // 0xdfc5e0: r0 = of()
    //     0xdfc5e0: bl              #0xccc364  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0xdfc5e4: ldur            x2, [fp, #-8]
    // 0xdfc5e8: r3 = false
    //     0xdfc5e8: add             x3, NULL, #0x30  ; false
    // 0xdfc5ec: stur            x0, [fp, #-0x38]
    // 0xdfc5f0: StoreField: r2->field_23 = r3
    //     0xdfc5f0: stur            w3, [x2, #0x23]
    // 0xdfc5f4: r0 = LoadStaticField(0x9b8)
    //     0xdfc5f4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xdfc5f8: ldr             x0, [x0, #0x1370]
    // 0xdfc5fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfc600: cmp             w0, w16
    // 0xdfc604: b.ne            #0xdfc614
    // 0xdfc608: r2 = cupertinoDesktopTextSelectionHandleControls
    //     0xdfc608: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f640] Field <::.cupertinoDesktopTextSelectionHandleControls>: static late final (offset: 0x9b8)
    //     0xdfc60c: ldr             x2, [x2, #0x640]
    // 0xdfc610: r0 = InitLateFinalStaticField()
    //     0xdfc610: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xdfc614: mov             x3, x0
    // 0xdfc618: ldur            x2, [fp, #-8]
    // 0xdfc61c: stur            x3, [fp, #-0x48]
    // 0xdfc620: LoadField: r0 = r2->field_b
    //     0xdfc620: ldur            w0, [x2, #0xb]
    // 0xdfc624: DecompressPointer r0
    //     0xdfc624: add             x0, x0, HEAP, lsl #32
    // 0xdfc628: cmp             w0, NULL
    // 0xdfc62c: b.eq            #0xdfcadc
    // 0xdfc630: ldur            x0, [fp, #-0x28]
    // 0xdfc634: LoadField: r1 = r0->field_f
    //     0xdfc634: ldur            w1, [x0, #0xf]
    // 0xdfc638: DecompressPointer r1
    //     0xdfc638: add             x1, x1, HEAP, lsl #32
    // 0xdfc63c: cmp             w1, NULL
    // 0xdfc640: b.ne            #0xdfc694
    // 0xdfc644: ldur            x4, [fp, #-0x38]
    // 0xdfc648: r1 = LoadClassIdInstr(r4)
    //     0xdfc648: ldur            x1, [x4, #-1]
    //     0xdfc64c: ubfx            x1, x1, #0xc, #0x14
    // 0xdfc650: r17 = 4617
    //     0xdfc650: mov             x17, #0x1209
    // 0xdfc654: cmp             x1, x17
    // 0xdfc658: b.ne            #0xdfc674
    // 0xdfc65c: LoadField: r1 = r4->field_27
    //     0xdfc65c: ldur            w1, [x4, #0x27]
    // 0xdfc660: DecompressPointer r1
    //     0xdfc660: add             x1, x1, HEAP, lsl #32
    // 0xdfc664: LoadField: r5 = r1->field_b
    //     0xdfc664: ldur            w5, [x1, #0xb]
    // 0xdfc668: DecompressPointer r5
    //     0xdfc668: add             x5, x5, HEAP, lsl #32
    // 0xdfc66c: mov             x1, x5
    // 0xdfc670: b               #0xdfc68c
    // 0xdfc674: LoadField: r1 = r4->field_2b
    //     0xdfc674: ldur            w1, [x4, #0x2b]
    // 0xdfc678: DecompressPointer r1
    //     0xdfc678: add             x1, x1, HEAP, lsl #32
    // 0xdfc67c: LoadField: r5 = r1->field_3f
    //     0xdfc67c: ldur            w5, [x1, #0x3f]
    // 0xdfc680: DecompressPointer r5
    //     0xdfc680: add             x5, x5, HEAP, lsl #32
    // 0xdfc684: LoadField: r1 = r5->field_b
    //     0xdfc684: ldur            w1, [x5, #0xb]
    // 0xdfc688: DecompressPointer r1
    //     0xdfc688: add             x1, x1, HEAP, lsl #32
    // 0xdfc68c: mov             x5, x1
    // 0xdfc690: b               #0xdfc69c
    // 0xdfc694: ldur            x4, [fp, #-0x38]
    // 0xdfc698: mov             x5, x1
    // 0xdfc69c: stur            x5, [fp, #-0x40]
    // 0xdfc6a0: LoadField: r1 = r0->field_13
    //     0xdfc6a0: ldur            w1, [x0, #0x13]
    // 0xdfc6a4: DecompressPointer r1
    //     0xdfc6a4: add             x1, x1, HEAP, lsl #32
    // 0xdfc6a8: cmp             w1, NULL
    // 0xdfc6ac: b.ne            #0xdfc714
    // 0xdfc6b0: r0 = LoadClassIdInstr(r4)
    //     0xdfc6b0: ldur            x0, [x4, #-1]
    //     0xdfc6b4: ubfx            x0, x0, #0xc, #0x14
    // 0xdfc6b8: r17 = 4617
    //     0xdfc6b8: mov             x17, #0x1209
    // 0xdfc6bc: cmp             x0, x17
    // 0xdfc6c0: b.ne            #0xdfc6d8
    // 0xdfc6c4: LoadField: r0 = r4->field_27
    //     0xdfc6c4: ldur            w0, [x4, #0x27]
    // 0xdfc6c8: DecompressPointer r0
    //     0xdfc6c8: add             x0, x0, HEAP, lsl #32
    // 0xdfc6cc: LoadField: r1 = r0->field_b
    //     0xdfc6cc: ldur            w1, [x0, #0xb]
    // 0xdfc6d0: DecompressPointer r1
    //     0xdfc6d0: add             x1, x1, HEAP, lsl #32
    // 0xdfc6d4: b               #0xdfc6f4
    // 0xdfc6d8: LoadField: r0 = r4->field_2b
    //     0xdfc6d8: ldur            w0, [x4, #0x2b]
    // 0xdfc6dc: DecompressPointer r0
    //     0xdfc6dc: add             x0, x0, HEAP, lsl #32
    // 0xdfc6e0: LoadField: r1 = r0->field_3f
    //     0xdfc6e0: ldur            w1, [x0, #0x3f]
    // 0xdfc6e4: DecompressPointer r1
    //     0xdfc6e4: add             x1, x1, HEAP, lsl #32
    // 0xdfc6e8: LoadField: r0 = r1->field_b
    //     0xdfc6e8: ldur            w0, [x1, #0xb]
    // 0xdfc6ec: DecompressPointer r0
    //     0xdfc6ec: add             x0, x0, HEAP, lsl #32
    // 0xdfc6f0: mov             x1, x0
    // 0xdfc6f4: r0 = LoadClassIdInstr(r1)
    //     0xdfc6f4: ldur            x0, [x1, #-1]
    //     0xdfc6f8: ubfx            x0, x0, #0xc, #0x14
    // 0xdfc6fc: d0 = 0.400000
    //     0xdfc6fc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13368] IMM: double(0.4) from 0x3fd999999999999a
    //     0xdfc700: ldr             d0, [x17, #0x368]
    // 0xdfc704: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdfc704: sub             lr, x0, #1, lsl #12
    //     0xdfc708: ldr             lr, [x21, lr, lsl #3]
    //     0xdfc70c: blr             lr
    // 0xdfc710: b               #0xdfc718
    // 0xdfc714: mov             x0, x1
    // 0xdfc718: ldur            x1, [fp, #-0x10]
    // 0xdfc71c: stur            x0, [fp, #-0x38]
    // 0xdfc720: r0 = devicePixelRatioOf()
    //     0xdfc720: bl              #0xcfce5c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::devicePixelRatioOf
    // 0xdfc724: mov             v1.16b, v0.16b
    // 0xdfc728: d0 = -2.000000
    //     0xdfc728: fmov            d0, #-2.00000000
    // 0xdfc72c: fdiv            d2, d0, d1
    // 0xdfc730: stur            d2, [fp, #-0xa8]
    // 0xdfc734: r0 = Offset()
    //     0xdfc734: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xdfc738: ldur            d0, [fp, #-0xa8]
    // 0xdfc73c: StoreField: r0->field_7 = d0
    //     0xdfc73c: stur            d0, [x0, #7]
    // 0xdfc740: StoreField: r0->field_f = rZR
    //     0xdfc740: stur            xzr, [x0, #0xf]
    // 0xdfc744: ldur            x8, [fp, #-0x48]
    // 0xdfc748: mov             x4, x0
    // 0xdfc74c: ldur            x7, [fp, #-0x40]
    // 0xdfc750: ldur            x3, [fp, #-0x38]
    // 0xdfc754: r6 = true
    //     0xdfc754: add             x6, NULL, #0x20  ; true
    // 0xdfc758: r5 = true
    //     0xdfc758: add             x5, NULL, #0x20  ; true
    // 0xdfc75c: r0 = Instance_Radius
    //     0xdfc75c: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8f620] Obj!Radius@12a7241
    //     0xdfc760: ldr             x0, [x0, #0x620]
    // 0xdfc764: b               #0xdfc838
    // 0xdfc768: ldur            x2, [fp, #-8]
    // 0xdfc76c: r3 = false
    //     0xdfc76c: add             x3, NULL, #0x30  ; false
    // 0xdfc770: StoreField: r2->field_23 = r3
    //     0xdfc770: stur            w3, [x2, #0x23]
    // 0xdfc774: r0 = LoadStaticField(0x668)
    //     0xdfc774: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xdfc778: ldr             x0, [x0, #0xcd0]
    // 0xdfc77c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfc780: cmp             w0, w16
    // 0xdfc784: b.ne            #0xdfc794
    // 0xdfc788: r2 = desktopTextSelectionHandleControls
    //     0xdfc788: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f628] Field <::.desktopTextSelectionHandleControls>: static late final (offset: 0x668)
    //     0xdfc78c: ldr             x2, [x2, #0x628]
    // 0xdfc790: r0 = InitLateFinalStaticField()
    //     0xdfc790: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xdfc794: ldur            x2, [fp, #-8]
    // 0xdfc798: stur            x0, [fp, #-0x40]
    // 0xdfc79c: LoadField: r1 = r2->field_b
    //     0xdfc79c: ldur            w1, [x2, #0xb]
    // 0xdfc7a0: DecompressPointer r1
    //     0xdfc7a0: add             x1, x1, HEAP, lsl #32
    // 0xdfc7a4: cmp             w1, NULL
    // 0xdfc7a8: b.eq            #0xdfcae0
    // 0xdfc7ac: ldur            x1, [fp, #-0x28]
    // 0xdfc7b0: LoadField: r3 = r1->field_f
    //     0xdfc7b0: ldur            w3, [x1, #0xf]
    // 0xdfc7b4: DecompressPointer r3
    //     0xdfc7b4: add             x3, x3, HEAP, lsl #32
    // 0xdfc7b8: cmp             w3, NULL
    // 0xdfc7bc: b.ne            #0xdfc7dc
    // 0xdfc7c0: ldur            x4, [fp, #-0x20]
    // 0xdfc7c4: LoadField: r3 = r4->field_3f
    //     0xdfc7c4: ldur            w3, [x4, #0x3f]
    // 0xdfc7c8: DecompressPointer r3
    //     0xdfc7c8: add             x3, x3, HEAP, lsl #32
    // 0xdfc7cc: LoadField: r5 = r3->field_b
    //     0xdfc7cc: ldur            w5, [x3, #0xb]
    // 0xdfc7d0: DecompressPointer r5
    //     0xdfc7d0: add             x5, x5, HEAP, lsl #32
    // 0xdfc7d4: mov             x3, x5
    // 0xdfc7d8: b               #0xdfc7e0
    // 0xdfc7dc: ldur            x4, [fp, #-0x20]
    // 0xdfc7e0: stur            x3, [fp, #-0x38]
    // 0xdfc7e4: LoadField: r5 = r1->field_13
    //     0xdfc7e4: ldur            w5, [x1, #0x13]
    // 0xdfc7e8: DecompressPointer r5
    //     0xdfc7e8: add             x5, x5, HEAP, lsl #32
    // 0xdfc7ec: cmp             w5, NULL
    // 0xdfc7f0: b.ne            #0xdfc818
    // 0xdfc7f4: LoadField: r1 = r4->field_3f
    //     0xdfc7f4: ldur            w1, [x4, #0x3f]
    // 0xdfc7f8: DecompressPointer r1
    //     0xdfc7f8: add             x1, x1, HEAP, lsl #32
    // 0xdfc7fc: LoadField: r4 = r1->field_b
    //     0xdfc7fc: ldur            w4, [x1, #0xb]
    // 0xdfc800: DecompressPointer r4
    //     0xdfc800: add             x4, x4, HEAP, lsl #32
    // 0xdfc804: mov             x1, x4
    // 0xdfc808: d0 = 0.400000
    //     0xdfc808: add             x17, PP, #0x13, lsl #12  ; [pp+0x13368] IMM: double(0.4) from 0x3fd999999999999a
    //     0xdfc80c: ldr             d0, [x17, #0x368]
    // 0xdfc810: r0 = withOpacity()
    //     0xdfc810: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xdfc814: b               #0xdfc81c
    // 0xdfc818: mov             x0, x5
    // 0xdfc81c: ldur            x8, [fp, #-0x40]
    // 0xdfc820: ldur            x7, [fp, #-0x38]
    // 0xdfc824: mov             x3, x0
    // 0xdfc828: r6 = false
    //     0xdfc828: add             x6, NULL, #0x30  ; false
    // 0xdfc82c: r5 = false
    //     0xdfc82c: add             x5, NULL, #0x30  ; false
    // 0xdfc830: r4 = Null
    //     0xdfc830: mov             x4, NULL
    // 0xdfc834: r0 = Null
    //     0xdfc834: mov             x0, NULL
    // 0xdfc838: ldur            x2, [fp, #-8]
    // 0xdfc83c: ldur            x1, [fp, #-0x10]
    // 0xdfc840: stur            x8, [fp, #-0x20]
    // 0xdfc844: stur            x6, [fp, #-0x28]
    // 0xdfc848: stur            x5, [fp, #-0x38]
    // 0xdfc84c: stur            x4, [fp, #-0x40]
    // 0xdfc850: stur            x7, [fp, #-0x48]
    // 0xdfc854: stur            x3, [fp, #-0x50]
    // 0xdfc858: stur            x0, [fp, #-0x58]
    // 0xdfc85c: r0 = of()
    //     0xdfc85c: bl              #0xd0b128  ; [package:flutter/src/widgets/text.dart] DefaultTextStyle::of
    // 0xdfc860: mov             x3, x0
    // 0xdfc864: ldur            x0, [fp, #-8]
    // 0xdfc868: stur            x3, [fp, #-0x10]
    // 0xdfc86c: LoadField: r1 = r0->field_b
    //     0xdfc86c: ldur            w1, [x0, #0xb]
    // 0xdfc870: DecompressPointer r1
    //     0xdfc870: add             x1, x1, HEAP, lsl #32
    // 0xdfc874: cmp             w1, NULL
    // 0xdfc878: b.eq            #0xdfcae4
    // 0xdfc87c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xdfc87c: ldur            w2, [x1, #0x17]
    // 0xdfc880: DecompressPointer r2
    //     0xdfc880: add             x2, x2, HEAP, lsl #32
    // 0xdfc884: LoadField: r1 = r2->field_7
    //     0xdfc884: ldur            w1, [x2, #7]
    // 0xdfc888: DecompressPointer r1
    //     0xdfc888: add             x1, x1, HEAP, lsl #32
    // 0xdfc88c: tbnz            w1, #4, #0xdfc8a4
    // 0xdfc890: LoadField: r1 = r3->field_f
    //     0xdfc890: ldur            w1, [x3, #0xf]
    // 0xdfc894: DecompressPointer r1
    //     0xdfc894: add             x1, x1, HEAP, lsl #32
    // 0xdfc898: r0 = merge()
    //     0xdfc898: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0xdfc89c: mov             x1, x0
    // 0xdfc8a0: b               #0xdfc8a8
    // 0xdfc8a4: mov             x1, x2
    // 0xdfc8a8: ldur            x2, [fp, #-8]
    // 0xdfc8ac: ldur            x0, [fp, #-0x10]
    // 0xdfc8b0: stur            x1, [fp, #-0x88]
    // 0xdfc8b4: LoadField: r3 = r2->field_b
    //     0xdfc8b4: ldur            w3, [x2, #0xb]
    // 0xdfc8b8: DecompressPointer r3
    //     0xdfc8b8: add             x3, x3, HEAP, lsl #32
    // 0xdfc8bc: cmp             w3, NULL
    // 0xdfc8c0: b.eq            #0xdfcae8
    // 0xdfc8c4: LoadField: r3 = r2->field_27
    //     0xdfc8c4: ldur            w3, [x2, #0x27]
    // 0xdfc8c8: DecompressPointer r3
    //     0xdfc8c8: add             x3, x3, HEAP, lsl #32
    // 0xdfc8cc: stur            x3, [fp, #-0x80]
    // 0xdfc8d0: LoadField: r4 = r2->field_1b
    //     0xdfc8d0: ldur            w4, [x2, #0x1b]
    // 0xdfc8d4: DecompressPointer r4
    //     0xdfc8d4: add             x4, x4, HEAP, lsl #32
    // 0xdfc8d8: stur            x4, [fp, #-0x78]
    // 0xdfc8dc: LoadField: r6 = r2->field_13
    //     0xdfc8dc: ldur            w6, [x2, #0x13]
    // 0xdfc8e0: DecompressPointer r6
    //     0xdfc8e0: add             x6, x6, HEAP, lsl #32
    // 0xdfc8e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfc8e8: cmp             w6, w16
    // 0xdfc8ec: b.eq            #0xdfcaec
    // 0xdfc8f0: stur            x6, [fp, #-0x70]
    // 0xdfc8f4: LoadField: r5 = r0->field_13
    //     0xdfc8f4: ldur            w5, [x0, #0x13]
    // 0xdfc8f8: DecompressPointer r5
    //     0xdfc8f8: add             x5, x5, HEAP, lsl #32
    // 0xdfc8fc: cmp             w5, NULL
    // 0xdfc900: b.ne            #0xdfc908
    // 0xdfc904: r5 = Instance_TextAlign
    //     0xdfc904: ldr             x5, [PP, #0x4c78]  ; [pp+0x4c78] Obj!TextAlign@12c7541
    // 0xdfc908: stur            x5, [fp, #-0x68]
    // 0xdfc90c: LoadField: r7 = r0->field_1f
    //     0xdfc90c: ldur            w7, [x0, #0x1f]
    // 0xdfc910: DecompressPointer r7
    //     0xdfc910: add             x7, x7, HEAP, lsl #32
    // 0xdfc914: stur            x7, [fp, #-0x60]
    // 0xdfc918: r0 = LoadStaticField(0xcb4)
    //     0xdfc918: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xdfc91c: ldr             x0, [x0, #0x1968]
    // 0xdfc920: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfc924: cmp             w0, w16
    // 0xdfc928: b.ne            #0xdfc938
    // 0xdfc92c: r2 = adaptiveMagnifierConfiguration
    //     0xdfc92c: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f668] Field <TextMagnifier.adaptiveMagnifierConfiguration>: static late (offset: 0xcb4)
    //     0xdfc930: ldr             x2, [x2, #0x668]
    // 0xdfc934: r0 = InitLateStaticField()
    //     0xdfc934: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xdfc938: mov             x3, x0
    // 0xdfc93c: ldur            x0, [fp, #-8]
    // 0xdfc940: stur            x3, [fp, #-0x10]
    // 0xdfc944: LoadField: r1 = r0->field_b
    //     0xdfc944: ldur            w1, [x0, #0xb]
    // 0xdfc948: DecompressPointer r1
    //     0xdfc948: add             x1, x1, HEAP, lsl #32
    // 0xdfc94c: cmp             w1, NULL
    // 0xdfc950: b.eq            #0xdfcaf8
    // 0xdfc954: mov             x2, x0
    // 0xdfc958: r1 = Function '_handleSelectionChanged@772286899':.
    //     0xdfc958: add             x1, PP, #0x95, lsl #12  ; [pp+0x95b80] AnonymousClosure: (0xdfcd14), in [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_handleSelectionChanged (0xdfcd54)
    //     0xdfc95c: ldr             x1, [x1, #0xb80]
    // 0xdfc960: r0 = AllocateClosure()
    //     0xdfc960: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfc964: ldur            x2, [fp, #-8]
    // 0xdfc968: r1 = Function '_handleSelectionHandleTapped@772286899':.
    //     0xdfc968: add             x1, PP, #0x95, lsl #12  ; [pp+0x95b88] AnonymousClosure: (0xdfcc20), in [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_handleSelectionHandleTapped (0xdfcc58)
    //     0xdfc96c: ldr             x1, [x1, #0xb88]
    // 0xdfc970: stur            x0, [fp, #-0x90]
    // 0xdfc974: r0 = AllocateClosure()
    //     0xdfc974: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfc978: stur            x0, [fp, #-0x98]
    // 0xdfc97c: r0 = EditableText()
    //     0xdfc97c: bl              #0xd48c68  ; AllocateEditableTextStub -> EditableText (size=0x140)
    // 0xdfc980: stur            x0, [fp, #-0xa0]
    // 0xdfc984: ldur            x16, [fp, #-0x40]
    // 0xdfc988: ldur            lr, [fp, #-0x38]
    // 0xdfc98c: stp             lr, x16, [SP, #0xa8]
    // 0xdfc990: ldur            x16, [fp, #-0x58]
    // 0xdfc994: r30 = true
    //     0xdfc994: add             lr, NULL, #0x20  ; true
    // 0xdfc998: stp             lr, x16, [SP, #0x98]
    // 0xdfc99c: ldur            x16, [fp, #-0x30]
    // 0xdfc9a0: ldur            lr, [fp, #-0x80]
    // 0xdfc9a4: stp             lr, x16, [SP, #0x88]
    // 0xdfc9a8: ldur            x16, [fp, #-0x10]
    // 0xdfc9ac: ldur            lr, [fp, #-0x60]
    // 0xdfc9b0: stp             lr, x16, [SP, #0x78]
    // 0xdfc9b4: ldur            x16, [fp, #-0x90]
    // 0xdfc9b8: ldur            lr, [fp, #-0x98]
    // 0xdfc9bc: stp             lr, x16, [SP, #0x68]
    // 0xdfc9c0: ldur            x16, [fp, #-0x28]
    // 0xdfc9c4: r30 = true
    //     0xdfc9c4: add             lr, NULL, #0x20  ; true
    // 0xdfc9c8: stp             lr, x16, [SP, #0x58]
    // 0xdfc9cc: ldur            x16, [fp, #-0x50]
    // 0xdfc9d0: stp             x16, NULL, [SP, #0x48]
    // 0xdfc9d4: ldur            x16, [fp, #-0x20]
    // 0xdfc9d8: stp             NULL, x16, [SP, #0x38]
    // 0xdfc9dc: r16 = false
    //     0xdfc9dc: add             x16, NULL, #0x30  ; false
    // 0xdfc9e0: stp             x16, NULL, [SP, #0x28]
    // 0xdfc9e4: ldur            x16, [fp, #-0x78]
    // 0xdfc9e8: r30 = Instance_StrutStyle
    //     0xdfc9e8: add             lr, PP, #0x95, lsl #12  ; [pp+0x95b90] Obj!StrutStyle@12b1af1
    //     0xdfc9ec: ldr             lr, [lr, #0xb90]
    // 0xdfc9f0: stp             lr, x16, [SP, #0x18]
    // 0xdfc9f4: ldur            x16, [fp, #-0x88]
    // 0xdfc9f8: ldur            lr, [fp, #-0x68]
    // 0xdfc9fc: stp             lr, x16, [SP, #8]
    // 0xdfca00: r16 = false
    //     0xdfca00: add             x16, NULL, #0x30  ; false
    // 0xdfca04: str             x16, [SP]
    // 0xdfca08: mov             x1, x0
    // 0xdfca0c: ldur            x6, [fp, #-0x70]
    // 0xdfca10: ldur            x7, [fp, #-0x48]
    // 0xdfca14: r2 = Null
    //     0xdfca14: mov             x2, NULL
    // 0xdfca18: r3 = false
    //     0xdfca18: add             x3, NULL, #0x30  ; false
    // 0xdfca1c: r5 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@772286899': static.
    //     0xdfca1c: add             x5, PP, #0x7a, lsl #12  ; [pp+0x7aa30] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@772286899': static. (0x7f2adace3fc8)
    //     0xdfca20: ldr             x5, [x5, #0xa30]
    // 0xdfca24: d0 = 2.000000
    //     0xdfca24: fmov            d0, #2.00000000
    // 0xdfca28: r4 = const [0, 0x1e, 0x17, 0x1d, forceLine, 0x1d, null]
    //     0xdfca28: add             x4, PP, #0x95, lsl #12  ; [pp+0x95b98] List(7) [0, 0x1e, 0x17, 0x1d, "forceLine", 0x1d, Null]
    //     0xdfca2c: ldr             x4, [x4, #0xb98]
    // 0xdfca30: r0 = EditableText()
    //     0xdfca30: bl              #0xd47c38  ; [package:flutter/src/widgets/editable_text.dart] EditableText::EditableText
    // 0xdfca34: r0 = RepaintBoundary()
    //     0xdfca34: bl              #0xd1a860  ; AllocateRepaintBoundaryStub -> RepaintBoundary (size=0x10)
    // 0xdfca38: mov             x1, x0
    // 0xdfca3c: ldur            x0, [fp, #-0xa0]
    // 0xdfca40: StoreField: r1->field_b = r0
    //     0xdfca40: stur            w0, [x1, #0xb]
    // 0xdfca44: ldur            x0, [fp, #-8]
    // 0xdfca48: LoadField: r2 = r0->field_b
    //     0xdfca48: ldur            w2, [x0, #0xb]
    // 0xdfca4c: DecompressPointer r2
    //     0xdfca4c: add             x2, x2, HEAP, lsl #32
    // 0xdfca50: cmp             w2, NULL
    // 0xdfca54: b.eq            #0xdfcafc
    // 0xdfca58: LoadField: r2 = r0->field_1f
    //     0xdfca58: ldur            w2, [x0, #0x1f]
    // 0xdfca5c: DecompressPointer r2
    //     0xdfca5c: add             x2, x2, HEAP, lsl #32
    // 0xdfca60: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfca64: cmp             w2, w16
    // 0xdfca68: b.eq            #0xdfcb00
    // 0xdfca6c: mov             x16, x1
    // 0xdfca70: mov             x1, x2
    // 0xdfca74: mov             x2, x16
    // 0xdfca78: r0 = buildGestureDetector()
    //     0xdfca78: bl              #0xd467ec  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionGestureDetectorBuilder::buildGestureDetector
    // 0xdfca7c: stur            x0, [fp, #-8]
    // 0xdfca80: r0 = Semantics()
    //     0xdfca80: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xdfca84: ldur            x2, [fp, #-0x18]
    // 0xdfca88: r1 = Function '<anonymous closure>':.
    //     0xdfca88: add             x1, PP, #0x95, lsl #12  ; [pp+0x95ba0] AnonymousClosure: (0xdfcbcc), in [package:flutter/src/material/selectable_text.dart] _SelectableTextState::build (0xdfc2bc)
    //     0xdfca8c: ldr             x1, [x1, #0xba0]
    // 0xdfca90: stur            x0, [fp, #-0x10]
    // 0xdfca94: r0 = AllocateClosure()
    //     0xdfca94: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfca98: r16 = false
    //     0xdfca98: add             x16, NULL, #0x30  ; false
    // 0xdfca9c: stp             x16, NULL, [SP, #0x10]
    // 0xdfcaa0: ldur            x16, [fp, #-8]
    // 0xdfcaa4: stp             x16, x0, [SP]
    // 0xdfcaa8: ldur            x1, [fp, #-0x10]
    // 0xdfcaac: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, excludeSemantics, 0x2, label, 0x1, onLongPress, 0x3, null]
    //     0xdfcaac: add             x4, PP, #0x95, lsl #12  ; [pp+0x95ba8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "excludeSemantics", 0x2, "label", 0x1, "onLongPress", 0x3, Null]
    //     0xdfcab0: ldr             x4, [x4, #0xba8]
    // 0xdfcab4: r0 = Semantics()
    //     0xdfcab4: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xdfcab8: ldur            x0, [fp, #-0x10]
    // 0xdfcabc: LeaveFrame
    //     0xdfcabc: mov             SP, fp
    //     0xdfcac0: ldp             fp, lr, [SP], #0x10
    // 0xdfcac4: ret
    //     0xdfcac4: ret             
    // 0xdfcac8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfcac8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfcacc: b               #0xdfc2e4
    // 0xdfcad0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfcad0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfcad4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfcad4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfcad8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfcad8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfcadc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfcadc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfcae0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfcae0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfcae4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfcae4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfcae8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfcae8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfcaec: r9 = _controller
    //     0xdfcaec: add             x9, PP, #0x95, lsl #12  ; [pp+0x95bb0] Field <_SelectableTextState@772286899._controller@772286899>: late (offset: 0x14)
    //     0xdfcaf0: ldr             x9, [x9, #0xbb0]
    // 0xdfcaf4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdfcaf4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdfcaf8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfcaf8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfcafc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfcafc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfcb00: r9 = _selectionGestureDetectorBuilder
    //     0xdfcb00: add             x9, PP, #0x95, lsl #12  ; [pp+0x95bb8] Field <_SelectableTextState@772286899._selectionGestureDetectorBuilder@772286899>: late (offset: 0x20)
    //     0xdfcb04: ldr             x9, [x9, #0xbb8]
    // 0xdfcb08: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdfcb08: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _effectiveFocusNode(/* No info */) {
    // ** addr: 0xdfcb30, size: 0x9c
    // 0xdfcb30: EnterFrame
    //     0xdfcb30: stp             fp, lr, [SP, #-0x10]!
    //     0xdfcb34: mov             fp, SP
    // 0xdfcb38: AllocStack(0x18)
    //     0xdfcb38: sub             SP, SP, #0x18
    // 0xdfcb3c: SetupParameters(_SelectableTextState this /* r1 => r1, fp-0x8 */)
    //     0xdfcb3c: stur            x1, [fp, #-8]
    // 0xdfcb40: CheckStackOverflow
    //     0xdfcb40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfcb44: cmp             SP, x16
    //     0xdfcb48: b.ls            #0xdfcbc0
    // 0xdfcb4c: LoadField: r0 = r1->field_b
    //     0xdfcb4c: ldur            w0, [x1, #0xb]
    // 0xdfcb50: DecompressPointer r0
    //     0xdfcb50: add             x0, x0, HEAP, lsl #32
    // 0xdfcb54: cmp             w0, NULL
    // 0xdfcb58: b.eq            #0xdfcbc8
    // 0xdfcb5c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xdfcb5c: ldur            w0, [x1, #0x17]
    // 0xdfcb60: DecompressPointer r0
    //     0xdfcb60: add             x0, x0, HEAP, lsl #32
    // 0xdfcb64: cmp             w0, NULL
    // 0xdfcb68: b.ne            #0xdfcbb4
    // 0xdfcb6c: r0 = FocusNode()
    //     0xdfcb6c: bl              #0xd4952c  ; AllocateFocusNodeStub -> FocusNode (size=0x68)
    // 0xdfcb70: stur            x0, [fp, #-0x10]
    // 0xdfcb74: r16 = true
    //     0xdfcb74: add             x16, NULL, #0x20  ; true
    // 0xdfcb78: str             x16, [SP]
    // 0xdfcb7c: mov             x1, x0
    // 0xdfcb80: r4 = const [0, 0x2, 0x1, 0x1, skipTraversal, 0x1, null]
    //     0xdfcb80: add             x4, PP, #0x95, lsl #12  ; [pp+0x95bc8] List(7) [0, 0x2, 0x1, 0x1, "skipTraversal", 0x1, Null]
    //     0xdfcb84: ldr             x4, [x4, #0xbc8]
    // 0xdfcb88: r0 = FocusNode()
    //     0xdfcb88: bl              #0x83cf84  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::FocusNode
    // 0xdfcb8c: ldur            x0, [fp, #-0x10]
    // 0xdfcb90: ldur            x1, [fp, #-8]
    // 0xdfcb94: ArrayStore: r1[0] = r0  ; List_4
    //     0xdfcb94: stur            w0, [x1, #0x17]
    //     0xdfcb98: ldurb           w16, [x1, #-1]
    //     0xdfcb9c: ldurb           w17, [x0, #-1]
    //     0xdfcba0: and             x16, x17, x16, lsr #2
    //     0xdfcba4: tst             x16, HEAP, lsr #32
    //     0xdfcba8: b.eq            #0xdfcbb0
    //     0xdfcbac: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdfcbb0: ldur            x0, [fp, #-0x10]
    // 0xdfcbb4: LeaveFrame
    //     0xdfcbb4: mov             SP, fp
    //     0xdfcbb8: ldp             fp, lr, [SP], #0x10
    // 0xdfcbbc: ret
    //     0xdfcbbc: ret             
    // 0xdfcbc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfcbc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfcbc4: b               #0xdfcb4c
    // 0xdfcbc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfcbc8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdfcbcc, size: 0x54
    // 0xdfcbcc: EnterFrame
    //     0xdfcbcc: stp             fp, lr, [SP, #-0x10]!
    //     0xdfcbd0: mov             fp, SP
    // 0xdfcbd4: ldr             x0, [fp, #0x10]
    // 0xdfcbd8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdfcbd8: ldur            w1, [x0, #0x17]
    // 0xdfcbdc: DecompressPointer r1
    //     0xdfcbdc: add             x1, x1, HEAP, lsl #32
    // 0xdfcbe0: CheckStackOverflow
    //     0xdfcbe0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfcbe4: cmp             SP, x16
    //     0xdfcbe8: b.ls            #0xdfcc18
    // 0xdfcbec: LoadField: r0 = r1->field_f
    //     0xdfcbec: ldur            w0, [x1, #0xf]
    // 0xdfcbf0: DecompressPointer r0
    //     0xdfcbf0: add             x0, x0, HEAP, lsl #32
    // 0xdfcbf4: mov             x1, x0
    // 0xdfcbf8: r0 = _effectiveFocusNode()
    //     0xdfcbf8: bl              #0xdfcb30  ; [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_effectiveFocusNode
    // 0xdfcbfc: mov             x1, x0
    // 0xdfcc00: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xdfcc00: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xdfcc04: r0 = requestFocus()
    //     0xdfcc04: bl              #0x83e7b8  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::requestFocus
    // 0xdfcc08: r0 = Null
    //     0xdfcc08: mov             x0, NULL
    // 0xdfcc0c: LeaveFrame
    //     0xdfcc0c: mov             SP, fp
    //     0xdfcc10: ldp             fp, lr, [SP], #0x10
    // 0xdfcc14: ret
    //     0xdfcc14: ret             
    // 0xdfcc18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfcc18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfcc1c: b               #0xdfcbec
  }
  [closure] void _handleSelectionHandleTapped(dynamic) {
    // ** addr: 0xdfcc20, size: 0x38
    // 0xdfcc20: EnterFrame
    //     0xdfcc20: stp             fp, lr, [SP, #-0x10]!
    //     0xdfcc24: mov             fp, SP
    // 0xdfcc28: ldr             x0, [fp, #0x10]
    // 0xdfcc2c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdfcc2c: ldur            w1, [x0, #0x17]
    // 0xdfcc30: DecompressPointer r1
    //     0xdfcc30: add             x1, x1, HEAP, lsl #32
    // 0xdfcc34: CheckStackOverflow
    //     0xdfcc34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfcc38: cmp             SP, x16
    //     0xdfcc3c: b.ls            #0xdfcc50
    // 0xdfcc40: r0 = _handleSelectionHandleTapped()
    //     0xdfcc40: bl              #0xdfcc58  ; [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_handleSelectionHandleTapped
    // 0xdfcc44: LeaveFrame
    //     0xdfcc44: mov             SP, fp
    //     0xdfcc48: ldp             fp, lr, [SP], #0x10
    // 0xdfcc4c: ret
    //     0xdfcc4c: ret             
    // 0xdfcc50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfcc50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfcc54: b               #0xdfcc40
  }
  _ _handleSelectionHandleTapped(/* No info */) {
    // ** addr: 0xdfcc58, size: 0x84
    // 0xdfcc58: EnterFrame
    //     0xdfcc58: stp             fp, lr, [SP, #-0x10]!
    //     0xdfcc5c: mov             fp, SP
    // 0xdfcc60: CheckStackOverflow
    //     0xdfcc60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfcc64: cmp             SP, x16
    //     0xdfcc68: b.ls            #0xdfccc4
    // 0xdfcc6c: LoadField: r0 = r1->field_13
    //     0xdfcc6c: ldur            w0, [x1, #0x13]
    // 0xdfcc70: DecompressPointer r0
    //     0xdfcc70: add             x0, x0, HEAP, lsl #32
    // 0xdfcc74: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfcc78: cmp             w0, w16
    // 0xdfcc7c: b.eq            #0xdfcccc
    // 0xdfcc80: LoadField: r2 = r0->field_27
    //     0xdfcc80: ldur            w2, [x0, #0x27]
    // 0xdfcc84: DecompressPointer r2
    //     0xdfcc84: add             x2, x2, HEAP, lsl #32
    // 0xdfcc88: LoadField: r0 = r2->field_b
    //     0xdfcc88: ldur            w0, [x2, #0xb]
    // 0xdfcc8c: DecompressPointer r0
    //     0xdfcc8c: add             x0, x0, HEAP, lsl #32
    // 0xdfcc90: LoadField: r2 = r0->field_7
    //     0xdfcc90: ldur            x2, [x0, #7]
    // 0xdfcc94: LoadField: r3 = r0->field_f
    //     0xdfcc94: ldur            x3, [x0, #0xf]
    // 0xdfcc98: cmp             x2, x3
    // 0xdfcc9c: b.ne            #0xdfccb4
    // 0xdfcca0: r0 = _editableText()
    //     0xdfcca0: bl              #0xdfccdc  ; [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_editableText
    // 0xdfcca4: cmp             w0, NULL
    // 0xdfcca8: b.eq            #0xdfccd8
    // 0xdfccac: mov             x1, x0
    // 0xdfccb0: r0 = toggleToolbar()
    //     0xdfccb0: bl              #0xd476b8  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::toggleToolbar
    // 0xdfccb4: r0 = Null
    //     0xdfccb4: mov             x0, NULL
    // 0xdfccb8: LeaveFrame
    //     0xdfccb8: mov             SP, fp
    //     0xdfccbc: ldp             fp, lr, [SP], #0x10
    // 0xdfccc0: ret
    //     0xdfccc0: ret             
    // 0xdfccc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfccc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfccc8: b               #0xdfcc6c
    // 0xdfcccc: r9 = _controller
    //     0xdfcccc: add             x9, PP, #0x95, lsl #12  ; [pp+0x95bb0] Field <_SelectableTextState@772286899._controller@772286899>: late (offset: 0x14)
    //     0xdfccd0: ldr             x9, [x9, #0xbb0]
    // 0xdfccd4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdfccd4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdfccd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfccd8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _editableText(/* No info */) {
    // ** addr: 0xdfccdc, size: 0x38
    // 0xdfccdc: EnterFrame
    //     0xdfccdc: stp             fp, lr, [SP, #-0x10]!
    //     0xdfcce0: mov             fp, SP
    // 0xdfcce4: CheckStackOverflow
    //     0xdfcce4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfcce8: cmp             SP, x16
    //     0xdfccec: b.ls            #0xdfcd0c
    // 0xdfccf0: LoadField: r0 = r1->field_27
    //     0xdfccf0: ldur            w0, [x1, #0x27]
    // 0xdfccf4: DecompressPointer r0
    //     0xdfccf4: add             x0, x0, HEAP, lsl #32
    // 0xdfccf8: mov             x1, x0
    // 0xdfccfc: r0 = currentState()
    //     0xdfccfc: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0xdfcd00: LeaveFrame
    //     0xdfcd00: mov             SP, fp
    //     0xdfcd04: ldp             fp, lr, [SP], #0x10
    // 0xdfcd08: ret
    //     0xdfcd08: ret             
    // 0xdfcd0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfcd0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfcd10: b               #0xdfccf0
  }
  [closure] void _handleSelectionChanged(dynamic, TextSelection, SelectionChangedCause?) {
    // ** addr: 0xdfcd14, size: 0x40
    // 0xdfcd14: EnterFrame
    //     0xdfcd14: stp             fp, lr, [SP, #-0x10]!
    //     0xdfcd18: mov             fp, SP
    // 0xdfcd1c: ldr             x0, [fp, #0x20]
    // 0xdfcd20: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdfcd20: ldur            w1, [x0, #0x17]
    // 0xdfcd24: DecompressPointer r1
    //     0xdfcd24: add             x1, x1, HEAP, lsl #32
    // 0xdfcd28: CheckStackOverflow
    //     0xdfcd28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfcd2c: cmp             SP, x16
    //     0xdfcd30: b.ls            #0xdfcd4c
    // 0xdfcd34: ldr             x2, [fp, #0x18]
    // 0xdfcd38: ldr             x3, [fp, #0x10]
    // 0xdfcd3c: r0 = _handleSelectionChanged()
    //     0xdfcd3c: bl              #0xdfcd54  ; [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_handleSelectionChanged
    // 0xdfcd40: LeaveFrame
    //     0xdfcd40: mov             SP, fp
    //     0xdfcd44: ldp             fp, lr, [SP], #0x10
    // 0xdfcd48: ret
    //     0xdfcd48: ret             
    // 0xdfcd4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfcd4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfcd50: b               #0xdfcd34
  }
  _ _handleSelectionChanged(/* No info */) {
    // ** addr: 0xdfcd54, size: 0x150
    // 0xdfcd54: EnterFrame
    //     0xdfcd54: stp             fp, lr, [SP, #-0x10]!
    //     0xdfcd58: mov             fp, SP
    // 0xdfcd5c: AllocStack(0x20)
    //     0xdfcd5c: sub             SP, SP, #0x20
    // 0xdfcd60: SetupParameters(_SelectableTextState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xdfcd60: mov             x0, x1
    //     0xdfcd64: stur            x1, [fp, #-8]
    //     0xdfcd68: mov             x1, x2
    //     0xdfcd6c: stur            x2, [fp, #-0x10]
    //     0xdfcd70: mov             x2, x3
    //     0xdfcd74: stur            x3, [fp, #-0x18]
    // 0xdfcd78: CheckStackOverflow
    //     0xdfcd78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfcd7c: cmp             SP, x16
    //     0xdfcd80: b.ls            #0xdfce94
    // 0xdfcd84: r1 = 2
    //     0xdfcd84: mov             x1, #2
    // 0xdfcd88: r0 = AllocateContext()
    //     0xdfcd88: bl              #0x13de838  ; AllocateContextStub
    // 0xdfcd8c: mov             x3, x0
    // 0xdfcd90: ldur            x0, [fp, #-8]
    // 0xdfcd94: stur            x3, [fp, #-0x20]
    // 0xdfcd98: StoreField: r3->field_f = r0
    //     0xdfcd98: stur            w0, [x3, #0xf]
    // 0xdfcd9c: mov             x1, x0
    // 0xdfcda0: ldur            x2, [fp, #-0x18]
    // 0xdfcda4: r0 = _shouldShowSelectionHandles()
    //     0xdfcda4: bl              #0xdfcea4  ; [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_shouldShowSelectionHandles
    // 0xdfcda8: ldur            x2, [fp, #-0x20]
    // 0xdfcdac: StoreField: r2->field_13 = r0
    //     0xdfcdac: stur            w0, [x2, #0x13]
    // 0xdfcdb0: ldur            x3, [fp, #-8]
    // 0xdfcdb4: LoadField: r1 = r3->field_1b
    //     0xdfcdb4: ldur            w1, [x3, #0x1b]
    // 0xdfcdb8: DecompressPointer r1
    //     0xdfcdb8: add             x1, x1, HEAP, lsl #32
    // 0xdfcdbc: cmp             w0, w1
    // 0xdfcdc0: b.eq            #0xdfcddc
    // 0xdfcdc4: r1 = Function '<anonymous closure>':.
    //     0xdfcdc4: add             x1, PP, #0x95, lsl #12  ; [pp+0x95bc0] AnonymousClosure: (0xdfcfa0), in [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_handleSelectionChanged (0xdfcd54)
    //     0xdfcdc8: ldr             x1, [x1, #0xbc0]
    // 0xdfcdcc: r0 = AllocateClosure()
    //     0xdfcdcc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfcdd0: ldur            x1, [fp, #-8]
    // 0xdfcdd4: mov             x2, x0
    // 0xdfcdd8: r0 = setState()
    //     0xdfcdd8: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdfcddc: ldur            x0, [fp, #-8]
    // 0xdfcde0: LoadField: r1 = r0->field_b
    //     0xdfcde0: ldur            w1, [x0, #0xb]
    // 0xdfcde4: DecompressPointer r1
    //     0xdfcde4: add             x1, x1, HEAP, lsl #32
    // 0xdfcde8: cmp             w1, NULL
    // 0xdfcdec: b.eq            #0xdfce9c
    // 0xdfcdf0: LoadField: r1 = r0->field_f
    //     0xdfcdf0: ldur            w1, [x0, #0xf]
    // 0xdfcdf4: DecompressPointer r1
    //     0xdfcdf4: add             x1, x1, HEAP, lsl #32
    // 0xdfcdf8: cmp             w1, NULL
    // 0xdfcdfc: b.eq            #0xdfcea0
    // 0xdfce00: r0 = of()
    //     0xdfce00: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdfce04: LoadField: r1 = r0->field_23
    //     0xdfce04: ldur            w1, [x0, #0x23]
    // 0xdfce08: DecompressPointer r1
    //     0xdfce08: add             x1, x1, HEAP, lsl #32
    // 0xdfce0c: LoadField: r0 = r1->field_7
    //     0xdfce0c: ldur            x0, [x1, #7]
    // 0xdfce10: cmp             x0, #2
    // 0xdfce14: b.gt            #0xdfce24
    // 0xdfce18: cmp             x0, #1
    // 0xdfce1c: b.gt            #0xdfce34
    // 0xdfce20: b               #0xdfce84
    // 0xdfce24: cmp             x0, #4
    // 0xdfce28: b.gt            #0xdfce84
    // 0xdfce2c: cmp             x0, #3
    // 0xdfce30: b.le            #0xdfce84
    // 0xdfce34: ldur            x0, [fp, #-0x18]
    // 0xdfce38: r16 = Instance_SelectionChangedCause
    //     0xdfce38: ldr             x16, [PP, #0x5300]  ; [pp+0x5300] Obj!SelectionChangedCause@12c36e1
    // 0xdfce3c: cmp             w0, w16
    // 0xdfce40: b.ne            #0xdfce74
    // 0xdfce44: ldur            x0, [fp, #-8]
    // 0xdfce48: LoadField: r1 = r0->field_27
    //     0xdfce48: ldur            w1, [x0, #0x27]
    // 0xdfce4c: DecompressPointer r1
    //     0xdfce4c: add             x1, x1, HEAP, lsl #32
    // 0xdfce50: r0 = currentState()
    //     0xdfce50: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0xdfce54: stur            x0, [fp, #-8]
    // 0xdfce58: cmp             w0, NULL
    // 0xdfce5c: b.eq            #0xdfce74
    // 0xdfce60: ldur            x1, [fp, #-0x10]
    // 0xdfce64: r0 = base()
    //     0xdfce64: bl              #0x86de9c  ; [package:flutter/src/services/text_editing.dart] TextSelection::base
    // 0xdfce68: ldur            x1, [fp, #-8]
    // 0xdfce6c: mov             x2, x0
    // 0xdfce70: r0 = bringIntoView()
    //     0xdfce70: bl              #0x86b880  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::bringIntoView
    // 0xdfce74: r0 = Null
    //     0xdfce74: mov             x0, NULL
    // 0xdfce78: LeaveFrame
    //     0xdfce78: mov             SP, fp
    //     0xdfce7c: ldp             fp, lr, [SP], #0x10
    // 0xdfce80: ret
    //     0xdfce80: ret             
    // 0xdfce84: r0 = Null
    //     0xdfce84: mov             x0, NULL
    // 0xdfce88: LeaveFrame
    //     0xdfce88: mov             SP, fp
    //     0xdfce8c: ldp             fp, lr, [SP], #0x10
    // 0xdfce90: ret
    //     0xdfce90: ret             
    // 0xdfce94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfce94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfce98: b               #0xdfcd84
    // 0xdfce9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfce9c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfcea0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfcea0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _shouldShowSelectionHandles(/* No info */) {
    // ** addr: 0xdfcea4, size: 0xfc
    // 0xdfcea4: EnterFrame
    //     0xdfcea4: stp             fp, lr, [SP, #-0x10]!
    //     0xdfcea8: mov             fp, SP
    // 0xdfceac: LoadField: r3 = r1->field_1f
    //     0xdfceac: ldur            w3, [x1, #0x1f]
    // 0xdfceb0: DecompressPointer r3
    //     0xdfceb0: add             x3, x3, HEAP, lsl #32
    // 0xdfceb4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfceb8: cmp             w3, w16
    // 0xdfcebc: b.eq            #0xdfcf88
    // 0xdfcec0: LoadField: r4 = r3->field_b
    //     0xdfcec0: ldur            w4, [x3, #0xb]
    // 0xdfcec4: DecompressPointer r4
    //     0xdfcec4: add             x4, x4, HEAP, lsl #32
    // 0xdfcec8: tbz             w4, #4, #0xdfcedc
    // 0xdfcecc: r0 = false
    //     0xdfcecc: add             x0, NULL, #0x30  ; false
    // 0xdfced0: LeaveFrame
    //     0xdfced0: mov             SP, fp
    //     0xdfced4: ldp             fp, lr, [SP], #0x10
    // 0xdfced8: ret
    //     0xdfced8: ret             
    // 0xdfcedc: LoadField: r3 = r1->field_13
    //     0xdfcedc: ldur            w3, [x1, #0x13]
    // 0xdfcee0: DecompressPointer r3
    //     0xdfcee0: add             x3, x3, HEAP, lsl #32
    // 0xdfcee4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfcee8: cmp             w3, w16
    // 0xdfceec: b.eq            #0xdfcf94
    // 0xdfcef0: LoadField: r1 = r3->field_27
    //     0xdfcef0: ldur            w1, [x3, #0x27]
    // 0xdfcef4: DecompressPointer r1
    //     0xdfcef4: add             x1, x1, HEAP, lsl #32
    // 0xdfcef8: LoadField: r3 = r1->field_b
    //     0xdfcef8: ldur            w3, [x1, #0xb]
    // 0xdfcefc: DecompressPointer r3
    //     0xdfcefc: add             x3, x3, HEAP, lsl #32
    // 0xdfcf00: LoadField: r4 = r3->field_7
    //     0xdfcf00: ldur            x4, [x3, #7]
    // 0xdfcf04: LoadField: r5 = r3->field_f
    //     0xdfcf04: ldur            x5, [x3, #0xf]
    // 0xdfcf08: cmp             x4, x5
    // 0xdfcf0c: b.ne            #0xdfcf20
    // 0xdfcf10: r0 = false
    //     0xdfcf10: add             x0, NULL, #0x30  ; false
    // 0xdfcf14: LeaveFrame
    //     0xdfcf14: mov             SP, fp
    //     0xdfcf18: ldp             fp, lr, [SP], #0x10
    // 0xdfcf1c: ret
    //     0xdfcf1c: ret             
    // 0xdfcf20: r16 = Instance_SelectionChangedCause
    //     0xdfcf20: ldr             x16, [PP, #0x53c8]  ; [pp+0x53c8] Obj!SelectionChangedCause@12c3661
    // 0xdfcf24: cmp             w2, w16
    // 0xdfcf28: b.ne            #0xdfcf3c
    // 0xdfcf2c: r0 = false
    //     0xdfcf2c: add             x0, NULL, #0x30  ; false
    // 0xdfcf30: LeaveFrame
    //     0xdfcf30: mov             SP, fp
    //     0xdfcf34: ldp             fp, lr, [SP], #0x10
    // 0xdfcf38: ret
    //     0xdfcf38: ret             
    // 0xdfcf3c: r16 = Instance_SelectionChangedCause
    //     0xdfcf3c: ldr             x16, [PP, #0x5300]  ; [pp+0x5300] Obj!SelectionChangedCause@12c36e1
    // 0xdfcf40: cmp             w2, w16
    // 0xdfcf44: b.ne            #0xdfcf58
    // 0xdfcf48: r0 = true
    //     0xdfcf48: add             x0, NULL, #0x20  ; true
    // 0xdfcf4c: LeaveFrame
    //     0xdfcf4c: mov             SP, fp
    //     0xdfcf50: ldp             fp, lr, [SP], #0x10
    // 0xdfcf54: ret
    //     0xdfcf54: ret             
    // 0xdfcf58: LoadField: r2 = r1->field_7
    //     0xdfcf58: ldur            w2, [x1, #7]
    // 0xdfcf5c: DecompressPointer r2
    //     0xdfcf5c: add             x2, x2, HEAP, lsl #32
    // 0xdfcf60: LoadField: r1 = r2->field_7
    //     0xdfcf60: ldur            w1, [x2, #7]
    // 0xdfcf64: cbz             w1, #0xdfcf78
    // 0xdfcf68: r0 = true
    //     0xdfcf68: add             x0, NULL, #0x20  ; true
    // 0xdfcf6c: LeaveFrame
    //     0xdfcf6c: mov             SP, fp
    //     0xdfcf70: ldp             fp, lr, [SP], #0x10
    // 0xdfcf74: ret
    //     0xdfcf74: ret             
    // 0xdfcf78: r0 = false
    //     0xdfcf78: add             x0, NULL, #0x30  ; false
    // 0xdfcf7c: LeaveFrame
    //     0xdfcf7c: mov             SP, fp
    //     0xdfcf80: ldp             fp, lr, [SP], #0x10
    // 0xdfcf84: ret
    //     0xdfcf84: ret             
    // 0xdfcf88: r9 = _selectionGestureDetectorBuilder
    //     0xdfcf88: add             x9, PP, #0x95, lsl #12  ; [pp+0x95bb8] Field <_SelectableTextState@772286899._selectionGestureDetectorBuilder@772286899>: late (offset: 0x20)
    //     0xdfcf8c: ldr             x9, [x9, #0xbb8]
    // 0xdfcf90: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdfcf90: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdfcf94: r9 = _controller
    //     0xdfcf94: add             x9, PP, #0x95, lsl #12  ; [pp+0x95bb0] Field <_SelectableTextState@772286899._controller@772286899>: late (offset: 0x14)
    //     0xdfcf98: ldr             x9, [x9, #0xbb0]
    // 0xdfcf9c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdfcf9c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdfcfa0, size: 0x28
    // 0xdfcfa0: ldr             x1, [SP]
    // 0xdfcfa4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xdfcfa4: ldur            w2, [x1, #0x17]
    // 0xdfcfa8: DecompressPointer r2
    //     0xdfcfa8: add             x2, x2, HEAP, lsl #32
    // 0xdfcfac: LoadField: r1 = r2->field_f
    //     0xdfcfac: ldur            w1, [x2, #0xf]
    // 0xdfcfb0: DecompressPointer r1
    //     0xdfcfb0: add             x1, x1, HEAP, lsl #32
    // 0xdfcfb4: LoadField: r3 = r2->field_13
    //     0xdfcfb4: ldur            w3, [x2, #0x13]
    // 0xdfcfb8: DecompressPointer r3
    //     0xdfcfb8: add             x3, x3, HEAP, lsl #32
    // 0xdfcfbc: StoreField: r1->field_1b = r3
    //     0xdfcfbc: stur            w3, [x1, #0x1b]
    // 0xdfcfc0: r0 = Null
    //     0xdfcfc0: mov             x0, NULL
    // 0xdfcfc4: ret
    //     0xdfcfc4: ret             
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf6e4ec, size: 0x298
    // 0xf6e4ec: EnterFrame
    //     0xf6e4ec: stp             fp, lr, [SP, #-0x10]!
    //     0xf6e4f0: mov             fp, SP
    // 0xf6e4f4: AllocStack(0x30)
    //     0xf6e4f4: sub             SP, SP, #0x30
    // 0xf6e4f8: SetupParameters(_SelectableTextState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf6e4f8: mov             x4, x1
    //     0xf6e4fc: mov             x3, x2
    //     0xf6e500: stur            x1, [fp, #-8]
    //     0xf6e504: stur            x2, [fp, #-0x10]
    // 0xf6e508: CheckStackOverflow
    //     0xf6e508: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6e50c: cmp             SP, x16
    //     0xf6e510: b.ls            #0xf6e754
    // 0xf6e514: mov             x0, x3
    // 0xf6e518: r2 = Null
    //     0xf6e518: mov             x2, NULL
    // 0xf6e51c: r1 = Null
    //     0xf6e51c: mov             x1, NULL
    // 0xf6e520: r4 = 60
    //     0xf6e520: mov             x4, #0x3c
    // 0xf6e524: branchIfSmi(r0, 0xf6e530)
    //     0xf6e524: tbz             w0, #0, #0xf6e530
    // 0xf6e528: r4 = LoadClassIdInstr(r0)
    //     0xf6e528: ldur            x4, [x0, #-1]
    //     0xf6e52c: ubfx            x4, x4, #0xc, #0x14
    // 0xf6e530: r17 = 6435
    //     0xf6e530: mov             x17, #0x1923
    // 0xf6e534: cmp             x4, x17
    // 0xf6e538: b.eq            #0xf6e550
    // 0xf6e53c: r8 = SelectableText
    //     0xf6e53c: add             x8, PP, #0x95, lsl #12  ; [pp+0x95bd8] Type: SelectableText
    //     0xf6e540: ldr             x8, [x8, #0xbd8]
    // 0xf6e544: r3 = Null
    //     0xf6e544: add             x3, PP, #0x95, lsl #12  ; [pp+0x95be0] Null
    //     0xf6e548: ldr             x3, [x3, #0xbe0]
    // 0xf6e54c: r0 = SelectableText()
    //     0xf6e54c: bl              #0xdfcb0c  ; IsType_SelectableText_Stub
    // 0xf6e550: ldur            x3, [fp, #-8]
    // 0xf6e554: LoadField: r2 = r3->field_7
    //     0xf6e554: ldur            w2, [x3, #7]
    // 0xf6e558: DecompressPointer r2
    //     0xf6e558: add             x2, x2, HEAP, lsl #32
    // 0xf6e55c: ldur            x0, [fp, #-0x10]
    // 0xf6e560: r1 = Null
    //     0xf6e560: mov             x1, NULL
    // 0xf6e564: cmp             w2, NULL
    // 0xf6e568: b.eq            #0xf6e58c
    // 0xf6e56c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6e56c: ldur            w4, [x2, #0x17]
    // 0xf6e570: DecompressPointer r4
    //     0xf6e570: add             x4, x4, HEAP, lsl #32
    // 0xf6e574: r8 = X0 bound StatefulWidget
    //     0xf6e574: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf6e578: ldr             x8, [x8, #0x498]
    // 0xf6e57c: LoadField: r9 = r4->field_7
    //     0xf6e57c: ldur            x9, [x4, #7]
    // 0xf6e580: r3 = Null
    //     0xf6e580: add             x3, PP, #0x95, lsl #12  ; [pp+0x95bf0] Null
    //     0xf6e584: ldr             x3, [x3, #0xbf0]
    // 0xf6e588: blr             x9
    // 0xf6e58c: ldur            x2, [fp, #-8]
    // 0xf6e590: LoadField: r0 = r2->field_b
    //     0xf6e590: ldur            w0, [x2, #0xb]
    // 0xf6e594: DecompressPointer r0
    //     0xf6e594: add             x0, x0, HEAP, lsl #32
    // 0xf6e598: cmp             w0, NULL
    // 0xf6e59c: b.eq            #0xf6e75c
    // 0xf6e5a0: LoadField: r1 = r0->field_b
    //     0xf6e5a0: ldur            w1, [x0, #0xb]
    // 0xf6e5a4: DecompressPointer r1
    //     0xf6e5a4: add             x1, x1, HEAP, lsl #32
    // 0xf6e5a8: ldur            x0, [fp, #-0x10]
    // 0xf6e5ac: LoadField: r3 = r0->field_b
    //     0xf6e5ac: ldur            w3, [x0, #0xb]
    // 0xf6e5b0: DecompressPointer r3
    //     0xf6e5b0: add             x3, x3, HEAP, lsl #32
    // 0xf6e5b4: r0 = LoadClassIdInstr(r1)
    //     0xf6e5b4: ldur            x0, [x1, #-1]
    //     0xf6e5b8: ubfx            x0, x0, #0xc, #0x14
    // 0xf6e5bc: stp             x3, x1, [SP]
    // 0xf6e5c0: mov             lr, x0
    // 0xf6e5c4: ldr             lr, [x21, lr, lsl #3]
    // 0xf6e5c8: blr             lr
    // 0xf6e5cc: tbz             w0, #4, #0xf6e6bc
    // 0xf6e5d0: ldur            x0, [fp, #-8]
    // 0xf6e5d4: LoadField: r3 = r0->field_13
    //     0xf6e5d4: ldur            w3, [x0, #0x13]
    // 0xf6e5d8: DecompressPointer r3
    //     0xf6e5d8: add             x3, x3, HEAP, lsl #32
    // 0xf6e5dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf6e5e0: cmp             w3, w16
    // 0xf6e5e4: b.eq            #0xf6e760
    // 0xf6e5e8: mov             x2, x0
    // 0xf6e5ec: stur            x3, [fp, #-0x10]
    // 0xf6e5f0: r1 = Function '_onControllerChanged@772286899':.
    //     0xf6e5f0: add             x1, PP, #0x95, lsl #12  ; [pp+0x95c00] AnonymousClosure: (0xf6e790), in [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_onControllerChanged (0xf6e7c8)
    //     0xf6e5f4: ldr             x1, [x1, #0xc00]
    // 0xf6e5f8: r0 = AllocateClosure()
    //     0xf6e5f8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf6e5fc: ldur            x1, [fp, #-0x10]
    // 0xf6e600: mov             x2, x0
    // 0xf6e604: stur            x0, [fp, #-0x10]
    // 0xf6e608: r0 = removeListener()
    //     0xf6e608: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xf6e60c: ldur            x0, [fp, #-8]
    // 0xf6e610: LoadField: r1 = r0->field_13
    //     0xf6e610: ldur            w1, [x0, #0x13]
    // 0xf6e614: DecompressPointer r1
    //     0xf6e614: add             x1, x1, HEAP, lsl #32
    // 0xf6e618: r0 = dispose()
    //     0xf6e618: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0xf6e61c: ldur            x1, [fp, #-8]
    // 0xf6e620: LoadField: r0 = r1->field_b
    //     0xf6e620: ldur            w0, [x1, #0xb]
    // 0xf6e624: DecompressPointer r0
    //     0xf6e624: add             x0, x0, HEAP, lsl #32
    // 0xf6e628: cmp             w0, NULL
    // 0xf6e62c: b.eq            #0xf6e76c
    // 0xf6e630: LoadField: r2 = r0->field_b
    //     0xf6e630: ldur            w2, [x0, #0xb]
    // 0xf6e634: DecompressPointer r2
    //     0xf6e634: add             x2, x2, HEAP, lsl #32
    // 0xf6e638: stur            x2, [fp, #-0x18]
    // 0xf6e63c: r0 = TextSpan()
    //     0xf6e63c: bl              #0xb57880  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0xf6e640: mov             x2, x0
    // 0xf6e644: ldur            x0, [fp, #-0x18]
    // 0xf6e648: stur            x2, [fp, #-0x20]
    // 0xf6e64c: StoreField: r2->field_b = r0
    //     0xf6e64c: stur            w0, [x2, #0xb]
    // 0xf6e650: r0 = Instance__DeferringMouseCursor
    //     0xf6e650: ldr             x0, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0xf6e654: ArrayStore: r2[0] = r0  ; List_4
    //     0xf6e654: stur            w0, [x2, #0x17]
    // 0xf6e658: r1 = <TextEditingValue>
    //     0xf6e658: ldr             x1, [PP, #0x53b8]  ; [pp+0x53b8] TypeArguments: <TextEditingValue>
    // 0xf6e65c: r0 = _TextSpanEditingController()
    //     0xf6e65c: bl              #0xf6e784  ; Allocate_TextSpanEditingControllerStub -> _TextSpanEditingController (size=0x30)
    // 0xf6e660: ldur            x1, [fp, #-0x20]
    // 0xf6e664: stur            x0, [fp, #-0x18]
    // 0xf6e668: StoreField: r0->field_2b = r1
    //     0xf6e668: stur            w1, [x0, #0x2b]
    // 0xf6e66c: r0 = toPlainText()
    //     0xf6e66c: bl              #0x85f3d4  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::toPlainText
    // 0xf6e670: str             x0, [SP]
    // 0xf6e674: ldur            x1, [fp, #-0x18]
    // 0xf6e678: r4 = const [0, 0x2, 0x1, 0x1, text, 0x1, null]
    //     0xf6e678: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a728] List(7) [0, 0x2, 0x1, 0x1, "text", 0x1, Null]
    //     0xf6e67c: ldr             x4, [x4, #0x728]
    // 0xf6e680: r0 = TextEditingController()
    //     0xf6e680: bl              #0xd7ef60  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0xf6e684: ldur            x0, [fp, #-0x18]
    // 0xf6e688: ldur            x3, [fp, #-8]
    // 0xf6e68c: StoreField: r3->field_13 = r0
    //     0xf6e68c: stur            w0, [x3, #0x13]
    //     0xf6e690: ldurb           w16, [x3, #-1]
    //     0xf6e694: ldurb           w17, [x0, #-1]
    //     0xf6e698: and             x16, x17, x16, lsr #2
    //     0xf6e69c: tst             x16, HEAP, lsr #32
    //     0xf6e6a0: b.eq            #0xf6e6a8
    //     0xf6e6a4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf6e6a8: ldur            x1, [fp, #-0x18]
    // 0xf6e6ac: ldur            x2, [fp, #-0x10]
    // 0xf6e6b0: r0 = addListener()
    //     0xf6e6b0: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xf6e6b4: ldur            x0, [fp, #-8]
    // 0xf6e6b8: b               #0xf6e6d0
    // 0xf6e6bc: ldur            x0, [fp, #-8]
    // 0xf6e6c0: LoadField: r1 = r0->field_b
    //     0xf6e6c0: ldur            w1, [x0, #0xb]
    // 0xf6e6c4: DecompressPointer r1
    //     0xf6e6c4: add             x1, x1, HEAP, lsl #32
    // 0xf6e6c8: cmp             w1, NULL
    // 0xf6e6cc: b.eq            #0xf6e770
    // 0xf6e6d0: LoadField: r1 = r0->field_b
    //     0xf6e6d0: ldur            w1, [x0, #0xb]
    // 0xf6e6d4: DecompressPointer r1
    //     0xf6e6d4: add             x1, x1, HEAP, lsl #32
    // 0xf6e6d8: cmp             w1, NULL
    // 0xf6e6dc: b.eq            #0xf6e774
    // 0xf6e6e0: mov             x1, x0
    // 0xf6e6e4: r0 = _effectiveFocusNode()
    //     0xf6e6e4: bl              #0xdfcb30  ; [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_effectiveFocusNode
    // 0xf6e6e8: mov             x1, x0
    // 0xf6e6ec: r0 = hasFocus()
    //     0xf6e6ec: bl              #0x843d08  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0xf6e6f0: tbnz            w0, #4, #0xf6e738
    // 0xf6e6f4: ldur            x1, [fp, #-8]
    // 0xf6e6f8: LoadField: r2 = r1->field_13
    //     0xf6e6f8: ldur            w2, [x1, #0x13]
    // 0xf6e6fc: DecompressPointer r2
    //     0xf6e6fc: add             x2, x2, HEAP, lsl #32
    // 0xf6e700: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf6e704: cmp             w2, w16
    // 0xf6e708: b.eq            #0xf6e778
    // 0xf6e70c: LoadField: r3 = r2->field_27
    //     0xf6e70c: ldur            w3, [x2, #0x27]
    // 0xf6e710: DecompressPointer r3
    //     0xf6e710: add             x3, x3, HEAP, lsl #32
    // 0xf6e714: LoadField: r2 = r3->field_b
    //     0xf6e714: ldur            w2, [x3, #0xb]
    // 0xf6e718: DecompressPointer r2
    //     0xf6e718: add             x2, x2, HEAP, lsl #32
    // 0xf6e71c: LoadField: r3 = r2->field_7
    //     0xf6e71c: ldur            x3, [x2, #7]
    // 0xf6e720: LoadField: r4 = r2->field_f
    //     0xf6e720: ldur            x4, [x2, #0xf]
    // 0xf6e724: cmp             x3, x4
    // 0xf6e728: b.ne            #0xf6e73c
    // 0xf6e72c: r2 = false
    //     0xf6e72c: add             x2, NULL, #0x30  ; false
    // 0xf6e730: StoreField: r1->field_1b = r2
    //     0xf6e730: stur            w2, [x1, #0x1b]
    // 0xf6e734: b               #0xf6e744
    // 0xf6e738: ldur            x1, [fp, #-8]
    // 0xf6e73c: r2 = true
    //     0xf6e73c: add             x2, NULL, #0x20  ; true
    // 0xf6e740: StoreField: r1->field_1b = r2
    //     0xf6e740: stur            w2, [x1, #0x1b]
    // 0xf6e744: r0 = Null
    //     0xf6e744: mov             x0, NULL
    // 0xf6e748: LeaveFrame
    //     0xf6e748: mov             SP, fp
    //     0xf6e74c: ldp             fp, lr, [SP], #0x10
    // 0xf6e750: ret
    //     0xf6e750: ret             
    // 0xf6e754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6e754: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6e758: b               #0xf6e514
    // 0xf6e75c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6e75c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6e760: r9 = _controller
    //     0xf6e760: add             x9, PP, #0x95, lsl #12  ; [pp+0x95bb0] Field <_SelectableTextState@772286899._controller@772286899>: late (offset: 0x14)
    //     0xf6e764: ldr             x9, [x9, #0xbb0]
    // 0xf6e768: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf6e768: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf6e76c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6e76c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6e770: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6e770: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6e774: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6e774: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6e778: r9 = _controller
    //     0xf6e778: add             x9, PP, #0x95, lsl #12  ; [pp+0x95bb0] Field <_SelectableTextState@772286899._controller@772286899>: late (offset: 0x14)
    //     0xf6e77c: ldr             x9, [x9, #0xbb0]
    // 0xf6e780: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf6e780: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _onControllerChanged(dynamic) {
    // ** addr: 0xf6e790, size: 0x38
    // 0xf6e790: EnterFrame
    //     0xf6e790: stp             fp, lr, [SP, #-0x10]!
    //     0xf6e794: mov             fp, SP
    // 0xf6e798: ldr             x0, [fp, #0x10]
    // 0xf6e79c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf6e79c: ldur            w1, [x0, #0x17]
    // 0xf6e7a0: DecompressPointer r1
    //     0xf6e7a0: add             x1, x1, HEAP, lsl #32
    // 0xf6e7a4: CheckStackOverflow
    //     0xf6e7a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6e7a8: cmp             SP, x16
    //     0xf6e7ac: b.ls            #0xf6e7c0
    // 0xf6e7b0: r0 = _onControllerChanged()
    //     0xf6e7b0: bl              #0xf6e7c8  ; [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_onControllerChanged
    // 0xf6e7b4: LeaveFrame
    //     0xf6e7b4: mov             SP, fp
    //     0xf6e7b8: ldp             fp, lr, [SP], #0x10
    // 0xf6e7bc: ret
    //     0xf6e7bc: ret             
    // 0xf6e7c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6e7c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6e7c4: b               #0xf6e7b0
  }
  _ _onControllerChanged(/* No info */) {
    // ** addr: 0xf6e7c8, size: 0xf8
    // 0xf6e7c8: EnterFrame
    //     0xf6e7c8: stp             fp, lr, [SP, #-0x10]!
    //     0xf6e7cc: mov             fp, SP
    // 0xf6e7d0: AllocStack(0x10)
    //     0xf6e7d0: sub             SP, SP, #0x10
    // 0xf6e7d4: SetupParameters(_SelectableTextState this /* r1 => r1, fp-0x8 */)
    //     0xf6e7d4: stur            x1, [fp, #-8]
    // 0xf6e7d8: CheckStackOverflow
    //     0xf6e7d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6e7dc: cmp             SP, x16
    //     0xf6e7e0: b.ls            #0xf6e8ac
    // 0xf6e7e4: r1 = 2
    //     0xf6e7e4: mov             x1, #2
    // 0xf6e7e8: r0 = AllocateContext()
    //     0xf6e7e8: bl              #0x13de838  ; AllocateContextStub
    // 0xf6e7ec: mov             x2, x0
    // 0xf6e7f0: ldur            x0, [fp, #-8]
    // 0xf6e7f4: stur            x2, [fp, #-0x10]
    // 0xf6e7f8: StoreField: r2->field_f = r0
    //     0xf6e7f8: stur            w0, [x2, #0xf]
    // 0xf6e7fc: mov             x1, x0
    // 0xf6e800: r0 = _effectiveFocusNode()
    //     0xf6e800: bl              #0xdfcb30  ; [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_effectiveFocusNode
    // 0xf6e804: mov             x1, x0
    // 0xf6e808: r0 = hasFocus()
    //     0xf6e808: bl              #0x843d08  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0xf6e80c: tbz             w0, #4, #0xf6e81c
    // 0xf6e810: ldur            x0, [fp, #-8]
    // 0xf6e814: r1 = true
    //     0xf6e814: add             x1, NULL, #0x20  ; true
    // 0xf6e818: b               #0xf6e85c
    // 0xf6e81c: ldur            x0, [fp, #-8]
    // 0xf6e820: LoadField: r1 = r0->field_13
    //     0xf6e820: ldur            w1, [x0, #0x13]
    // 0xf6e824: DecompressPointer r1
    //     0xf6e824: add             x1, x1, HEAP, lsl #32
    // 0xf6e828: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf6e82c: cmp             w1, w16
    // 0xf6e830: b.eq            #0xf6e8b4
    // 0xf6e834: LoadField: r2 = r1->field_27
    //     0xf6e834: ldur            w2, [x1, #0x27]
    // 0xf6e838: DecompressPointer r2
    //     0xf6e838: add             x2, x2, HEAP, lsl #32
    // 0xf6e83c: LoadField: r1 = r2->field_b
    //     0xf6e83c: ldur            w1, [x2, #0xb]
    // 0xf6e840: DecompressPointer r1
    //     0xf6e840: add             x1, x1, HEAP, lsl #32
    // 0xf6e844: LoadField: r2 = r1->field_7
    //     0xf6e844: ldur            x2, [x1, #7]
    // 0xf6e848: LoadField: r3 = r1->field_f
    //     0xf6e848: ldur            x3, [x1, #0xf]
    // 0xf6e84c: cmp             x2, x3
    // 0xf6e850: r16 = true
    //     0xf6e850: add             x16, NULL, #0x20  ; true
    // 0xf6e854: r17 = false
    //     0xf6e854: add             x17, NULL, #0x30  ; false
    // 0xf6e858: csel            x1, x16, x17, ne
    // 0xf6e85c: ldur            x2, [fp, #-0x10]
    // 0xf6e860: StoreField: r2->field_13 = r1
    //     0xf6e860: stur            w1, [x2, #0x13]
    // 0xf6e864: LoadField: r3 = r0->field_1b
    //     0xf6e864: ldur            w3, [x0, #0x1b]
    // 0xf6e868: DecompressPointer r3
    //     0xf6e868: add             x3, x3, HEAP, lsl #32
    // 0xf6e86c: cmp             w1, w3
    // 0xf6e870: b.ne            #0xf6e884
    // 0xf6e874: r0 = Null
    //     0xf6e874: mov             x0, NULL
    // 0xf6e878: LeaveFrame
    //     0xf6e878: mov             SP, fp
    //     0xf6e87c: ldp             fp, lr, [SP], #0x10
    // 0xf6e880: ret
    //     0xf6e880: ret             
    // 0xf6e884: r1 = Function '<anonymous closure>':.
    //     0xf6e884: add             x1, PP, #0x95, lsl #12  ; [pp+0x95c08] AnonymousClosure: (0xdfcfa0), in [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_handleSelectionChanged (0xdfcd54)
    //     0xf6e888: ldr             x1, [x1, #0xc08]
    // 0xf6e88c: r0 = AllocateClosure()
    //     0xf6e88c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf6e890: ldur            x1, [fp, #-8]
    // 0xf6e894: mov             x2, x0
    // 0xf6e898: r0 = setState()
    //     0xf6e898: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf6e89c: r0 = Null
    //     0xf6e89c: mov             x0, NULL
    // 0xf6e8a0: LeaveFrame
    //     0xf6e8a0: mov             SP, fp
    //     0xf6e8a4: ldp             fp, lr, [SP], #0x10
    // 0xf6e8a8: ret
    //     0xf6e8a8: ret             
    // 0xf6e8ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6e8ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6e8b0: b               #0xf6e7e4
    // 0xf6e8b4: r9 = _controller
    //     0xf6e8b4: add             x9, PP, #0x95, lsl #12  ; [pp+0x95bb0] Field <_SelectableTextState@772286899._controller@772286899>: late (offset: 0x14)
    //     0xf6e8b8: ldr             x9, [x9, #0xbb0]
    // 0xf6e8bc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf6e8bc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf9112c, size: 0x150
    // 0xf9112c: EnterFrame
    //     0xf9112c: stp             fp, lr, [SP, #-0x10]!
    //     0xf91130: mov             fp, SP
    // 0xf91134: AllocStack(0x20)
    //     0xf91134: sub             SP, SP, #0x20
    // 0xf91138: SetupParameters(_SelectableTextState this /* r1 => r2, fp-0x8 */)
    //     0xf91138: mov             x2, x1
    //     0xf9113c: stur            x1, [fp, #-8]
    // 0xf91140: CheckStackOverflow
    //     0xf91140: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf91144: cmp             SP, x16
    //     0xf91148: b.ls            #0xf91270
    // 0xf9114c: r0 = _SelectableTextSelectionGestureDetectorBuilder()
    //     0xf9114c: bl              #0xf9127c  ; Allocate_SelectableTextSelectionGestureDetectorBuilderStub -> _SelectableTextSelectionGestureDetectorBuilder (size=0x30)
    // 0xf91150: ldur            x2, [fp, #-8]
    // 0xf91154: StoreField: r0->field_2b = r2
    //     0xf91154: stur            w2, [x0, #0x2b]
    // 0xf91158: r1 = true
    //     0xf91158: add             x1, NULL, #0x20  ; true
    // 0xf9115c: StoreField: r0->field_b = r1
    //     0xf9115c: stur            w1, [x0, #0xb]
    // 0xf91160: StoreField: r0->field_f = r1
    //     0xf91160: stur            w1, [x0, #0xf]
    // 0xf91164: r1 = false
    //     0xf91164: add             x1, NULL, #0x30  ; false
    // 0xf91168: StoreField: r0->field_13 = r1
    //     0xf91168: stur            w1, [x0, #0x13]
    // 0xf9116c: ArrayStore: r0[0] = rZR  ; List_8
    //     0xf9116c: stur            xzr, [x0, #0x17]
    // 0xf91170: StoreField: r0->field_1f = rZR
    //     0xf91170: stur            xzr, [x0, #0x1f]
    // 0xf91174: StoreField: r0->field_7 = r2
    //     0xf91174: stur            w2, [x0, #7]
    // 0xf91178: StoreField: r2->field_1f = r0
    //     0xf91178: stur            w0, [x2, #0x1f]
    //     0xf9117c: ldurb           w16, [x2, #-1]
    //     0xf91180: ldurb           w17, [x0, #-1]
    //     0xf91184: and             x16, x17, x16, lsr #2
    //     0xf91188: tst             x16, HEAP, lsr #32
    //     0xf9118c: b.eq            #0xf91194
    //     0xf91190: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf91194: LoadField: r0 = r2->field_b
    //     0xf91194: ldur            w0, [x2, #0xb]
    // 0xf91198: DecompressPointer r0
    //     0xf91198: add             x0, x0, HEAP, lsl #32
    // 0xf9119c: cmp             w0, NULL
    // 0xf911a0: b.eq            #0xf91278
    // 0xf911a4: LoadField: r1 = r0->field_b
    //     0xf911a4: ldur            w1, [x0, #0xb]
    // 0xf911a8: DecompressPointer r1
    //     0xf911a8: add             x1, x1, HEAP, lsl #32
    // 0xf911ac: stur            x1, [fp, #-0x10]
    // 0xf911b0: r0 = TextSpan()
    //     0xf911b0: bl              #0xb57880  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0xf911b4: mov             x2, x0
    // 0xf911b8: ldur            x0, [fp, #-0x10]
    // 0xf911bc: stur            x2, [fp, #-0x18]
    // 0xf911c0: StoreField: r2->field_b = r0
    //     0xf911c0: stur            w0, [x2, #0xb]
    // 0xf911c4: r0 = Instance__DeferringMouseCursor
    //     0xf911c4: ldr             x0, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0xf911c8: ArrayStore: r2[0] = r0  ; List_4
    //     0xf911c8: stur            w0, [x2, #0x17]
    // 0xf911cc: r1 = <TextEditingValue>
    //     0xf911cc: ldr             x1, [PP, #0x53b8]  ; [pp+0x53b8] TypeArguments: <TextEditingValue>
    // 0xf911d0: r0 = _TextSpanEditingController()
    //     0xf911d0: bl              #0xf6e784  ; Allocate_TextSpanEditingControllerStub -> _TextSpanEditingController (size=0x30)
    // 0xf911d4: ldur            x1, [fp, #-0x18]
    // 0xf911d8: stur            x0, [fp, #-0x10]
    // 0xf911dc: StoreField: r0->field_2b = r1
    //     0xf911dc: stur            w1, [x0, #0x2b]
    // 0xf911e0: r0 = toPlainText()
    //     0xf911e0: bl              #0x85f3d4  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::toPlainText
    // 0xf911e4: str             x0, [SP]
    // 0xf911e8: ldur            x1, [fp, #-0x10]
    // 0xf911ec: r4 = const [0, 0x2, 0x1, 0x1, text, 0x1, null]
    //     0xf911ec: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a728] List(7) [0, 0x2, 0x1, 0x1, "text", 0x1, Null]
    //     0xf911f0: ldr             x4, [x4, #0x728]
    // 0xf911f4: r0 = TextEditingController()
    //     0xf911f4: bl              #0xd7ef60  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0xf911f8: ldur            x0, [fp, #-0x10]
    // 0xf911fc: ldur            x3, [fp, #-8]
    // 0xf91200: StoreField: r3->field_13 = r0
    //     0xf91200: stur            w0, [x3, #0x13]
    //     0xf91204: ldurb           w16, [x3, #-1]
    //     0xf91208: ldurb           w17, [x0, #-1]
    //     0xf9120c: and             x16, x17, x16, lsr #2
    //     0xf91210: tst             x16, HEAP, lsr #32
    //     0xf91214: b.eq            #0xf9121c
    //     0xf91218: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf9121c: mov             x2, x3
    // 0xf91220: r1 = Function '_onControllerChanged@772286899':.
    //     0xf91220: add             x1, PP, #0x95, lsl #12  ; [pp+0x95c00] AnonymousClosure: (0xf6e790), in [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_onControllerChanged (0xf6e7c8)
    //     0xf91224: ldr             x1, [x1, #0xc00]
    // 0xf91228: r0 = AllocateClosure()
    //     0xf91228: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf9122c: ldur            x1, [fp, #-0x10]
    // 0xf91230: mov             x2, x0
    // 0xf91234: r0 = addListener()
    //     0xf91234: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xf91238: ldur            x1, [fp, #-8]
    // 0xf9123c: r0 = _effectiveFocusNode()
    //     0xf9123c: bl              #0xdfcb30  ; [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_effectiveFocusNode
    // 0xf91240: ldur            x2, [fp, #-8]
    // 0xf91244: r1 = Function '_handleFocusChanged@772286899':.
    //     0xf91244: add             x1, PP, #0x95, lsl #12  ; [pp+0x95bd0] AnonymousClosure: (0xf91288), in [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_handleFocusChanged (0xf912c0)
    //     0xf91248: ldr             x1, [x1, #0xbd0]
    // 0xf9124c: stur            x0, [fp, #-8]
    // 0xf91250: r0 = AllocateClosure()
    //     0xf91250: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf91254: ldur            x1, [fp, #-8]
    // 0xf91258: mov             x2, x0
    // 0xf9125c: r0 = addListener()
    //     0xf9125c: bl              #0xd01514  ; [dart:mixin_deduplication] _MixinApplication219&Object&DiagnosticableTreeMixin&ChangeNotifier::addListener
    // 0xf91260: r0 = Null
    //     0xf91260: mov             x0, NULL
    // 0xf91264: LeaveFrame
    //     0xf91264: mov             SP, fp
    //     0xf91268: ldp             fp, lr, [SP], #0x10
    // 0xf9126c: ret
    //     0xf9126c: ret             
    // 0xf91270: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf91270: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf91274: b               #0xf9114c
    // 0xf91278: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf91278: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleFocusChanged(dynamic) {
    // ** addr: 0xf91288, size: 0x38
    // 0xf91288: EnterFrame
    //     0xf91288: stp             fp, lr, [SP, #-0x10]!
    //     0xf9128c: mov             fp, SP
    // 0xf91290: ldr             x0, [fp, #0x10]
    // 0xf91294: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf91294: ldur            w1, [x0, #0x17]
    // 0xf91298: DecompressPointer r1
    //     0xf91298: add             x1, x1, HEAP, lsl #32
    // 0xf9129c: CheckStackOverflow
    //     0xf9129c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf912a0: cmp             SP, x16
    //     0xf912a4: b.ls            #0xf912b8
    // 0xf912a8: r0 = _handleFocusChanged()
    //     0xf912a8: bl              #0xf912c0  ; [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_handleFocusChanged
    // 0xf912ac: LeaveFrame
    //     0xf912ac: mov             SP, fp
    //     0xf912b0: ldp             fp, lr, [SP], #0x10
    // 0xf912b4: ret
    //     0xf912b4: ret             
    // 0xf912b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf912b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf912bc: b               #0xf912a8
  }
  _ _handleFocusChanged(/* No info */) {
    // ** addr: 0xf912c0, size: 0xe0
    // 0xf912c0: EnterFrame
    //     0xf912c0: stp             fp, lr, [SP, #-0x10]!
    //     0xf912c4: mov             fp, SP
    // 0xf912c8: AllocStack(0x10)
    //     0xf912c8: sub             SP, SP, #0x10
    // 0xf912cc: SetupParameters(_SelectableTextState this /* r1 => r0, fp-0x8 */)
    //     0xf912cc: mov             x0, x1
    //     0xf912d0: stur            x1, [fp, #-8]
    // 0xf912d4: CheckStackOverflow
    //     0xf912d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf912d8: cmp             SP, x16
    //     0xf912dc: b.ls            #0xf91388
    // 0xf912e0: mov             x1, x0
    // 0xf912e4: r0 = _effectiveFocusNode()
    //     0xf912e4: bl              #0xdfcb30  ; [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_effectiveFocusNode
    // 0xf912e8: mov             x1, x0
    // 0xf912ec: r0 = hasFocus()
    //     0xf912ec: bl              #0x843d08  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0xf912f0: tbz             w0, #4, #0xf91378
    // 0xf912f4: r0 = LoadStaticField(0x5e4)
    //     0xf912f4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf912f8: ldr             x0, [x0, #0xbc8]
    // 0xf912fc: cmp             w0, NULL
    // 0xf91300: b.eq            #0xf91390
    // 0xf91304: LoadField: r1 = r0->field_2f
    //     0xf91304: ldur            w1, [x0, #0x2f]
    // 0xf91308: DecompressPointer r1
    //     0xf91308: add             x1, x1, HEAP, lsl #32
    // 0xf9130c: r16 = Instance_AppLifecycleState
    //     0xf9130c: ldr             x16, [PP, #0x1e28]  ; [pp+0x1e28] Obj!AppLifecycleState@12c7ee1
    // 0xf91310: cmp             w1, w16
    // 0xf91314: b.ne            #0xf91378
    // 0xf91318: ldur            x0, [fp, #-8]
    // 0xf9131c: LoadField: r1 = r0->field_13
    //     0xf9131c: ldur            w1, [x0, #0x13]
    // 0xf91320: DecompressPointer r1
    //     0xf91320: add             x1, x1, HEAP, lsl #32
    // 0xf91324: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf91328: cmp             w1, w16
    // 0xf9132c: b.eq            #0xf91394
    // 0xf91330: stur            x1, [fp, #-0x10]
    // 0xf91334: LoadField: r0 = r1->field_27
    //     0xf91334: ldur            w0, [x1, #0x27]
    // 0xf91338: DecompressPointer r0
    //     0xf91338: add             x0, x0, HEAP, lsl #32
    // 0xf9133c: LoadField: r2 = r0->field_7
    //     0xf9133c: ldur            w2, [x0, #7]
    // 0xf91340: DecompressPointer r2
    //     0xf91340: add             x2, x2, HEAP, lsl #32
    // 0xf91344: stur            x2, [fp, #-8]
    // 0xf91348: r0 = TextEditingValue()
    //     0xf91348: bl              #0x86e1d4  ; AllocateTextEditingValueStub -> TextEditingValue (size=0x14)
    // 0xf9134c: mov             x1, x0
    // 0xf91350: ldur            x0, [fp, #-8]
    // 0xf91354: StoreField: r1->field_7 = r0
    //     0xf91354: stur            w0, [x1, #7]
    // 0xf91358: r0 = Instance_TextSelection
    //     0xf91358: add             x0, PP, #0x14, lsl #12  ; [pp+0x14b30] Obj!TextSelection@12a0491
    //     0xf9135c: ldr             x0, [x0, #0xb30]
    // 0xf91360: StoreField: r1->field_b = r0
    //     0xf91360: stur            w0, [x1, #0xb]
    // 0xf91364: r0 = Instance_TextRange
    //     0xf91364: ldr             x0, [PP, #0x53d8]  ; [pp+0x53d8] Obj!TextRange@12a0471
    // 0xf91368: StoreField: r1->field_f = r0
    //     0xf91368: stur            w0, [x1, #0xf]
    // 0xf9136c: mov             x2, x1
    // 0xf91370: ldur            x1, [fp, #-0x10]
    // 0xf91374: r0 = value=()
    //     0xf91374: bl              #0xb68ce8  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0xf91378: r0 = Null
    //     0xf91378: mov             x0, NULL
    // 0xf9137c: LeaveFrame
    //     0xf9137c: mov             SP, fp
    //     0xf91380: ldp             fp, lr, [SP], #0x10
    // 0xf91384: ret
    //     0xf91384: ret             
    // 0xf91388: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf91388: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf9138c: b               #0xf912e0
    // 0xf91390: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf91390: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf91394: r9 = _controller
    //     0xf91394: add             x9, PP, #0x95, lsl #12  ; [pp+0x95bb0] Field <_SelectableTextState@772286899._controller@772286899>: late (offset: 0x14)
    //     0xf91398: ldr             x9, [x9, #0xbb0]
    // 0xf9139c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf9139c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e5fb8, size: 0xa0
    // 0x10e5fb8: EnterFrame
    //     0x10e5fb8: stp             fp, lr, [SP, #-0x10]!
    //     0x10e5fbc: mov             fp, SP
    // 0x10e5fc0: AllocStack(0x10)
    //     0x10e5fc0: sub             SP, SP, #0x10
    // 0x10e5fc4: SetupParameters(_SelectableTextState this /* r1 => r0, fp-0x8 */)
    //     0x10e5fc4: mov             x0, x1
    //     0x10e5fc8: stur            x1, [fp, #-8]
    // 0x10e5fcc: CheckStackOverflow
    //     0x10e5fcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e5fd0: cmp             SP, x16
    //     0x10e5fd4: b.ls            #0x10e6044
    // 0x10e5fd8: mov             x1, x0
    // 0x10e5fdc: r0 = _effectiveFocusNode()
    //     0x10e5fdc: bl              #0xdfcb30  ; [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_effectiveFocusNode
    // 0x10e5fe0: ldur            x2, [fp, #-8]
    // 0x10e5fe4: r1 = Function '_handleFocusChanged@772286899':.
    //     0x10e5fe4: add             x1, PP, #0x95, lsl #12  ; [pp+0x95bd0] AnonymousClosure: (0xf91288), in [package:flutter/src/material/selectable_text.dart] _SelectableTextState::_handleFocusChanged (0xf912c0)
    //     0x10e5fe8: ldr             x1, [x1, #0xbd0]
    // 0x10e5fec: stur            x0, [fp, #-0x10]
    // 0x10e5ff0: r0 = AllocateClosure()
    //     0x10e5ff0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e5ff4: ldur            x1, [fp, #-0x10]
    // 0x10e5ff8: mov             x2, x0
    // 0x10e5ffc: r0 = removeListener()
    //     0x10e5ffc: bl              #0xcff298  ; [dart:mixin_deduplication] _MixinApplication219&Object&DiagnosticableTreeMixin&ChangeNotifier::removeListener
    // 0x10e6000: ldur            x0, [fp, #-8]
    // 0x10e6004: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10e6004: ldur            w1, [x0, #0x17]
    // 0x10e6008: DecompressPointer r1
    //     0x10e6008: add             x1, x1, HEAP, lsl #32
    // 0x10e600c: cmp             w1, NULL
    // 0x10e6010: b.eq            #0x10e601c
    // 0x10e6014: r0 = dispose()
    //     0x10e6014: bl              #0x10ec024  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::dispose
    // 0x10e6018: ldur            x0, [fp, #-8]
    // 0x10e601c: LoadField: r1 = r0->field_13
    //     0x10e601c: ldur            w1, [x0, #0x13]
    // 0x10e6020: DecompressPointer r1
    //     0x10e6020: add             x1, x1, HEAP, lsl #32
    // 0x10e6024: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10e6028: cmp             w1, w16
    // 0x10e602c: b.eq            #0x10e604c
    // 0x10e6030: r0 = dispose()
    //     0x10e6030: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0x10e6034: r0 = Null
    //     0x10e6034: mov             x0, NULL
    // 0x10e6038: LeaveFrame
    //     0x10e6038: mov             SP, fp
    //     0x10e603c: ldp             fp, lr, [SP], #0x10
    // 0x10e6040: ret
    //     0x10e6040: ret             
    // 0x10e6044: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e6044: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e6048: b               #0x10e5fd8
    // 0x10e604c: r9 = _controller
    //     0x10e604c: add             x9, PP, #0x95, lsl #12  ; [pp+0x95bb0] Field <_SelectableTextState@772286899._controller@772286899>: late (offset: 0x14)
    //     0x10e6050: ldr             x9, [x9, #0xbb0]
    // 0x10e6054: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10e6054: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ forcePressEnabled(/* No info */) {
    // ** addr: 0x1283e9c, size: 0x2c
    // 0x1283e9c: LoadField: r0 = r1->field_23
    //     0x1283e9c: ldur            w0, [x1, #0x23]
    // 0x1283ea0: DecompressPointer r0
    //     0x1283ea0: add             x0, x0, HEAP, lsl #32
    // 0x1283ea4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1283ea8: cmp             w0, w16
    // 0x1283eac: b.eq            #0x1283eb4
    // 0x1283eb0: ret
    //     0x1283eb0: ret             
    // 0x1283eb4: EnterFrame
    //     0x1283eb4: stp             fp, lr, [SP, #-0x10]!
    //     0x1283eb8: mov             fp, SP
    // 0x1283ebc: r9 = forcePressEnabled
    //     0x1283ebc: add             x9, PP, #0x95, lsl #12  ; [pp+0x95c10] Field <_SelectableTextState@772286899.forcePressEnabled>: late (offset: 0x24)
    //     0x1283ec0: ldr             x9, [x9, #0xc10]
    // 0x1283ec4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1283ec4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ selectionEnabled(/* No info */) {
    // ** addr: 0x12a39c8, size: 0x24
    // 0x12a39c8: LoadField: r2 = r1->field_b
    //     0x12a39c8: ldur            w2, [x1, #0xb]
    // 0x12a39cc: DecompressPointer r2
    //     0x12a39cc: add             x2, x2, HEAP, lsl #32
    // 0x12a39d0: cmp             w2, NULL
    // 0x12a39d4: b.eq            #0x12a39e0
    // 0x12a39d8: r0 = true
    //     0x12a39d8: add             x0, NULL, #0x20  ; true
    // 0x12a39dc: ret
    //     0x12a39dc: ret             
    // 0x12a39e0: EnterFrame
    //     0x12a39e0: stp             fp, lr, [SP, #-0x10]!
    //     0x12a39e4: mov             fp, SP
    // 0x12a39e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12a39e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6435, size: 0x94, field offset: 0xc
//   const constructor, 
class SelectableText extends StatefulWidget {

  [closure] static Widget _defaultContextMenuBuilder(dynamic, BuildContext, EditableTextState) {
    // ** addr: 0xdfcfc8, size: 0x34
    // 0xdfcfc8: EnterFrame
    //     0xdfcfc8: stp             fp, lr, [SP, #-0x10]!
    //     0xdfcfcc: mov             fp, SP
    // 0xdfcfd0: CheckStackOverflow
    //     0xdfcfd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfcfd4: cmp             SP, x16
    //     0xdfcfd8: b.ls            #0xdfcff4
    // 0xdfcfdc: ldr             x1, [fp, #0x18]
    // 0xdfcfe0: ldr             x2, [fp, #0x10]
    // 0xdfcfe4: r0 = _defaultContextMenuBuilder()
    //     0xdfcfe4: bl              #0xdfcffc  ; [package:flutter/src/material/selectable_text.dart] SelectableText::_defaultContextMenuBuilder
    // 0xdfcfe8: LeaveFrame
    //     0xdfcfe8: mov             SP, fp
    //     0xdfcfec: ldp             fp, lr, [SP], #0x10
    // 0xdfcff0: ret
    //     0xdfcff0: ret             
    // 0xdfcff4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfcff4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfcff8: b               #0xdfcfdc
  }
  static _ _defaultContextMenuBuilder(/* No info */) {
    // ** addr: 0xdfcffc, size: 0x80
    // 0xdfcffc: EnterFrame
    //     0xdfcffc: stp             fp, lr, [SP, #-0x10]!
    //     0xdfd000: mov             fp, SP
    // 0xdfd004: AllocStack(0x18)
    //     0xdfd004: sub             SP, SP, #0x18
    // 0xdfd008: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xdfd008: mov             x0, x2
    //     0xdfd00c: stur            x2, [fp, #-8]
    // 0xdfd010: CheckStackOverflow
    //     0xdfd010: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfd014: cmp             SP, x16
    //     0xdfd018: b.ls            #0xdfd074
    // 0xdfd01c: mov             x1, x0
    // 0xdfd020: r0 = contextMenuButtonItems()
    //     0xdfd020: bl              #0xd91b28  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::contextMenuButtonItems
    // 0xdfd024: stur            x0, [fp, #-0x10]
    // 0xdfd028: r0 = AdaptiveTextSelectionToolbar()
    //     0xdfd028: bl              #0xd91b1c  ; AllocateAdaptiveTextSelectionToolbarStub -> AdaptiveTextSelectionToolbar (size=0x18)
    // 0xdfd02c: mov             x2, x0
    // 0xdfd030: ldur            x0, [fp, #-0x10]
    // 0xdfd034: stur            x2, [fp, #-0x18]
    // 0xdfd038: StoreField: r2->field_b = r0
    //     0xdfd038: stur            w0, [x2, #0xb]
    // 0xdfd03c: ldur            x1, [fp, #-8]
    // 0xdfd040: r0 = contextMenuAnchors()
    //     0xdfd040: bl              #0xd9114c  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::contextMenuAnchors
    // 0xdfd044: ldur            x1, [fp, #-0x18]
    // 0xdfd048: StoreField: r1->field_13 = r0
    //     0xdfd048: stur            w0, [x1, #0x13]
    //     0xdfd04c: ldurb           w16, [x1, #-1]
    //     0xdfd050: ldurb           w17, [x0, #-1]
    //     0xdfd054: and             x16, x17, x16, lsr #2
    //     0xdfd058: tst             x16, HEAP, lsr #32
    //     0xdfd05c: b.eq            #0xdfd064
    //     0xdfd060: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdfd064: mov             x0, x1
    // 0xdfd068: LeaveFrame
    //     0xdfd068: mov             SP, fp
    //     0xdfd06c: ldp             fp, lr, [SP], #0x10
    // 0xdfd070: ret
    //     0xdfd070: ret             
    // 0xdfd074: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfd074: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfd078: b               #0xdfd01c
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa2e04, size: 0x60
    // 0xfa2e04: EnterFrame
    //     0xfa2e04: stp             fp, lr, [SP, #-0x10]!
    //     0xfa2e08: mov             fp, SP
    // 0xfa2e0c: AllocStack(0x8)
    //     0xfa2e0c: sub             SP, SP, #8
    // 0xfa2e10: SetupParameters(SelectableText this /* r1 => r0 */)
    //     0xfa2e10: mov             x0, x1
    // 0xfa2e14: r1 = <SelectableText>
    //     0xfa2e14: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c928] TypeArguments: <SelectableText>
    //     0xfa2e18: ldr             x1, [x1, #0x928]
    // 0xfa2e1c: r0 = _SelectableTextState()
    //     0xfa2e1c: bl              #0xfa2e64  ; Allocate_SelectableTextStateStub -> _SelectableTextState (size=0x2c)
    // 0xfa2e20: mov             x2, x0
    // 0xfa2e24: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa2e28: stur            x2, [fp, #-8]
    // 0xfa2e2c: StoreField: r2->field_13 = r0
    //     0xfa2e2c: stur            w0, [x2, #0x13]
    // 0xfa2e30: r1 = false
    //     0xfa2e30: add             x1, NULL, #0x30  ; false
    // 0xfa2e34: StoreField: r2->field_1b = r1
    //     0xfa2e34: stur            w1, [x2, #0x1b]
    // 0xfa2e38: StoreField: r2->field_1f = r0
    //     0xfa2e38: stur            w0, [x2, #0x1f]
    // 0xfa2e3c: StoreField: r2->field_23 = r0
    //     0xfa2e3c: stur            w0, [x2, #0x23]
    // 0xfa2e40: r1 = <EditableTextState>
    //     0xfa2e40: add             x1, PP, #0x84, lsl #12  ; [pp+0x84930] TypeArguments: <EditableTextState>
    //     0xfa2e44: ldr             x1, [x1, #0x930]
    // 0xfa2e48: r0 = LabeledGlobalKey()
    //     0xfa2e48: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa2e4c: mov             x1, x0
    // 0xfa2e50: ldur            x0, [fp, #-8]
    // 0xfa2e54: StoreField: r0->field_27 = r1
    //     0xfa2e54: stur            w1, [x0, #0x27]
    // 0xfa2e58: LeaveFrame
    //     0xfa2e58: mov             SP, fp
    //     0xfa2e5c: ldp             fp, lr, [SP], #0x10
    // 0xfa2e60: ret
    //     0xfa2e60: ret             
  }
}
