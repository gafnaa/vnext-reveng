// lib: , url: package:flutter/src/material/arc.dart

// class id: 1048845, size: 0x8
class :: {

  static _ _maxBy(/* No info */) {
    // ** addr: 0x115cf2c, size: 0xfc
    // 0x115cf2c: EnterFrame
    //     0x115cf2c: stp             fp, lr, [SP, #-0x10]!
    //     0x115cf30: mov             fp, SP
    // 0x115cf34: AllocStack(0x30)
    //     0x115cf34: sub             SP, SP, #0x30
    // 0x115cf38: CheckStackOverflow
    //     0x115cf38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115cf3c: cmp             SP, x16
    //     0x115cf40: b.ls            #0x115d014
    // 0x115cf44: ldr             x3, [THR, #0x90]  ; THR::object_sentinel
    // 0x115cf48: r2 = Null
    //     0x115cf48: mov             x2, NULL
    // 0x115cf4c: r0 = 0
    //     0x115cf4c: mov             x0, #0
    // 0x115cf50: r1 = const [Instance of '_Diagonal', Instance of '_Diagonal', Instance of '_Diagonal', Instance of '_Diagonal']
    //     0x115cf50: add             x1, PP, #0x95, lsl #12  ; [pp+0x95ef0] List<_Diagonal>(4)
    //     0x115cf54: ldr             x1, [x1, #0xef0]
    // 0x115cf58: stur            x3, [fp, #-0x18]
    // 0x115cf5c: stur            x2, [fp, #-0x20]
    // 0x115cf60: CheckStackOverflow
    //     0x115cf60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115cf64: cmp             SP, x16
    //     0x115cf68: b.ls            #0x115d01c
    // 0x115cf6c: cmp             x0, #4
    // 0x115cf70: b.ge            #0x115cfe4
    // 0x115cf74: ArrayLoad: r4 = r1[r0]  ; Unknown_4
    //     0x115cf74: add             x16, x1, x0, lsl #2
    //     0x115cf78: ldur            w4, [x16, #0xf]
    // 0x115cf7c: DecompressPointer r4
    //     0x115cf7c: add             x4, x4, HEAP, lsl #32
    // 0x115cf80: stur            x4, [fp, #-0x10]
    // 0x115cf84: add             x5, x0, #1
    // 0x115cf88: stur            x5, [fp, #-8]
    // 0x115cf8c: ldr             x16, [fp, #0x10]
    // 0x115cf90: stp             x4, x16, [SP]
    // 0x115cf94: ldr             x0, [fp, #0x10]
    // 0x115cf98: ClosureCall
    //     0x115cf98: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x115cf9c: ldur            x2, [x0, #0x1f]
    //     0x115cfa0: blr             x2
    // 0x115cfa4: mov             x2, x0
    // 0x115cfa8: ldur            x1, [fp, #-0x20]
    // 0x115cfac: cmp             w1, NULL
    // 0x115cfb0: b.eq            #0x115cfcc
    // 0x115cfb4: cmp             w2, NULL
    // 0x115cfb8: b.eq            #0x115d024
    // 0x115cfbc: LoadField: d0 = r1->field_7
    //     0x115cfbc: ldur            d0, [x1, #7]
    // 0x115cfc0: LoadField: d1 = r2->field_7
    //     0x115cfc0: ldur            d1, [x2, #7]
    // 0x115cfc4: fcmp            d1, d0
    // 0x115cfc8: b.le            #0x115cfd4
    // 0x115cfcc: ldur            x3, [fp, #-0x10]
    // 0x115cfd0: b               #0x115cfdc
    // 0x115cfd4: ldur            x3, [fp, #-0x18]
    // 0x115cfd8: mov             x2, x1
    // 0x115cfdc: ldur            x0, [fp, #-8]
    // 0x115cfe0: b               #0x115cf50
    // 0x115cfe4: mov             x0, x3
    // 0x115cfe8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x115cfec: cmp             w0, w16
    // 0x115cff0: b.eq            #0x115d000
    // 0x115cff4: LeaveFrame
    //     0x115cff4: mov             SP, fp
    //     0x115cff8: ldp             fp, lr, [SP], #0x10
    // 0x115cffc: ret
    //     0x115cffc: ret             
    // 0x115d000: r16 = "maxValue"
    //     0x115d000: add             x16, PP, #0x15, lsl #12  ; [pp+0x15180] "maxValue"
    //     0x115d004: ldr             x16, [x16, #0x180]
    // 0x115d008: str             x16, [SP]
    // 0x115d00c: r0 = _throwLocalNotInitialized()
    //     0x115d00c: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x115d010: brk             #0
    // 0x115d014: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x115d014: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x115d018: b               #0x115cf44
    // 0x115d01c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x115d01c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x115d020: b               #0x115cf6c
    // 0x115d024: r0 = NullErrorSharedWithoutFPURegs()
    //     0x115d024: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 3124, size: 0x10, field offset: 0x8
//   const constructor, 
class _Diagonal extends Object {

  _CornerId field_8;
  _CornerId field_c;
}

// class id: 3311, size: 0x28, field offset: 0x14
class MaterialPointArcTween extends Tween<dynamic> {

  set _ begin=(/* No info */) {
    // ** addr: 0x1144d50, size: 0x118
    // 0x1144d50: EnterFrame
    //     0x1144d50: stp             fp, lr, [SP, #-0x10]!
    //     0x1144d54: mov             fp, SP
    // 0x1144d58: AllocStack(0x20)
    //     0x1144d58: sub             SP, SP, #0x20
    // 0x1144d5c: SetupParameters(MaterialPointArcTween this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x1144d5c: mov             x4, x1
    //     0x1144d60: mov             x3, x2
    //     0x1144d64: stur            x1, [fp, #-8]
    //     0x1144d68: stur            x2, [fp, #-0x10]
    // 0x1144d6c: CheckStackOverflow
    //     0x1144d6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1144d70: cmp             SP, x16
    //     0x1144d74: b.ls            #0x1144e60
    // 0x1144d78: mov             x0, x3
    // 0x1144d7c: r2 = Null
    //     0x1144d7c: mov             x2, NULL
    // 0x1144d80: r1 = Null
    //     0x1144d80: mov             x1, NULL
    // 0x1144d84: r4 = 60
    //     0x1144d84: mov             x4, #0x3c
    // 0x1144d88: branchIfSmi(r0, 0x1144d94)
    //     0x1144d88: tbz             w0, #0, #0x1144d94
    // 0x1144d8c: r4 = LoadClassIdInstr(r0)
    //     0x1144d8c: ldur            x4, [x0, #-1]
    //     0x1144d90: ubfx            x4, x4, #0xc, #0x14
    // 0x1144d94: cmp             x4, #0xedc
    // 0x1144d98: b.eq            #0x1144db0
    // 0x1144d9c: r8 = Offset?
    //     0x1144d9c: add             x8, PP, #0xa0, lsl #12  ; [pp+0xa0f70] Type: Offset?
    //     0x1144da0: ldr             x8, [x8, #0xf70]
    // 0x1144da4: r3 = Null
    //     0x1144da4: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0f98] Null
    //     0x1144da8: ldr             x3, [x3, #0xf98]
    // 0x1144dac: r0 = DefaultNullableTypeTest()
    //     0x1144dac: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x1144db0: ldur            x1, [fp, #-8]
    // 0x1144db4: LoadField: r0 = r1->field_b
    //     0x1144db4: ldur            w0, [x1, #0xb]
    // 0x1144db8: DecompressPointer r0
    //     0x1144db8: add             x0, x0, HEAP, lsl #32
    // 0x1144dbc: ldur            x2, [fp, #-0x10]
    // 0x1144dc0: r3 = LoadClassIdInstr(r2)
    //     0x1144dc0: ldur            x3, [x2, #-1]
    //     0x1144dc4: ubfx            x3, x3, #0xc, #0x14
    // 0x1144dc8: stp             x0, x2, [SP]
    // 0x1144dcc: mov             x0, x3
    // 0x1144dd0: mov             lr, x0
    // 0x1144dd4: ldr             lr, [x21, lr, lsl #3]
    // 0x1144dd8: blr             lr
    // 0x1144ddc: tbz             w0, #4, #0x1144e50
    // 0x1144de0: ldur            x3, [fp, #-8]
    // 0x1144de4: LoadField: r2 = r3->field_7
    //     0x1144de4: ldur            w2, [x3, #7]
    // 0x1144de8: DecompressPointer r2
    //     0x1144de8: add             x2, x2, HEAP, lsl #32
    // 0x1144dec: ldur            x0, [fp, #-0x10]
    // 0x1144df0: r1 = Null
    //     0x1144df0: mov             x1, NULL
    // 0x1144df4: cmp             w0, NULL
    // 0x1144df8: b.eq            #0x1144e20
    // 0x1144dfc: cmp             w2, NULL
    // 0x1144e00: b.eq            #0x1144e20
    // 0x1144e04: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x1144e04: ldur            w4, [x2, #0x17]
    // 0x1144e08: DecompressPointer r4
    //     0x1144e08: add             x4, x4, HEAP, lsl #32
    // 0x1144e0c: r8 = X0?
    //     0x1144e0c: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0x1144e10: LoadField: r9 = r4->field_7
    //     0x1144e10: ldur            x9, [x4, #7]
    // 0x1144e14: r3 = Null
    //     0x1144e14: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0fa8] Null
    //     0x1144e18: ldr             x3, [x3, #0xfa8]
    // 0x1144e1c: blr             x9
    // 0x1144e20: ldur            x0, [fp, #-0x10]
    // 0x1144e24: ldur            x1, [fp, #-8]
    // 0x1144e28: StoreField: r1->field_b = r0
    //     0x1144e28: stur            w0, [x1, #0xb]
    //     0x1144e2c: tbz             w0, #0, #0x1144e48
    //     0x1144e30: ldurb           w16, [x1, #-1]
    //     0x1144e34: ldurb           w17, [x0, #-1]
    //     0x1144e38: and             x16, x17, x16, lsr #2
    //     0x1144e3c: tst             x16, HEAP, lsr #32
    //     0x1144e40: b.eq            #0x1144e48
    //     0x1144e44: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1144e48: r2 = true
    //     0x1144e48: add             x2, NULL, #0x20  ; true
    // 0x1144e4c: StoreField: r1->field_13 = r2
    //     0x1144e4c: stur            w2, [x1, #0x13]
    // 0x1144e50: r0 = Null
    //     0x1144e50: mov             x0, NULL
    // 0x1144e54: LeaveFrame
    //     0x1144e54: mov             SP, fp
    //     0x1144e58: ldp             fp, lr, [SP], #0x10
    // 0x1144e5c: ret
    //     0x1144e5c: ret             
    // 0x1144e60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1144e60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1144e64: b               #0x1144d78
  }
  _ lerp(/* No info */) {
    // ** addr: 0x115d3a0, size: 0x294
    // 0x115d3a0: EnterFrame
    //     0x115d3a0: stp             fp, lr, [SP, #-0x10]!
    //     0x115d3a4: mov             fp, SP
    // 0x115d3a8: AllocStack(0x28)
    //     0x115d3a8: sub             SP, SP, #0x28
    // 0x115d3ac: SetupParameters(MaterialPointArcTween this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x18 */)
    //     0x115d3ac: mov             x0, x1
    //     0x115d3b0: stur            x1, [fp, #-8]
    //     0x115d3b4: stur            d0, [fp, #-0x18]
    // 0x115d3b8: CheckStackOverflow
    //     0x115d3b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115d3bc: cmp             SP, x16
    //     0x115d3c0: b.ls            #0x115d5d4
    // 0x115d3c4: LoadField: r1 = r0->field_13
    //     0x115d3c4: ldur            w1, [x0, #0x13]
    // 0x115d3c8: DecompressPointer r1
    //     0x115d3c8: add             x1, x1, HEAP, lsl #32
    // 0x115d3cc: tbnz            w1, #4, #0x115d3d8
    // 0x115d3d0: mov             x1, x0
    // 0x115d3d4: r0 = _initialize()
    //     0x115d3d4: bl              #0x115d634  ; [package:flutter/src/material/arc.dart] MaterialPointArcTween::_initialize
    // 0x115d3d8: ldur            d0, [fp, #-0x18]
    // 0x115d3dc: d1 = 0.000000
    //     0x115d3dc: eor             v1.16b, v1.16b, v1.16b
    // 0x115d3e0: fcmp            d0, d1
    // 0x115d3e4: b.ne            #0x115d40c
    // 0x115d3e8: ldur            x0, [fp, #-8]
    // 0x115d3ec: LoadField: r1 = r0->field_b
    //     0x115d3ec: ldur            w1, [x0, #0xb]
    // 0x115d3f0: DecompressPointer r1
    //     0x115d3f0: add             x1, x1, HEAP, lsl #32
    // 0x115d3f4: cmp             w1, NULL
    // 0x115d3f8: b.eq            #0x115d5dc
    // 0x115d3fc: mov             x0, x1
    // 0x115d400: LeaveFrame
    //     0x115d400: mov             SP, fp
    //     0x115d404: ldp             fp, lr, [SP], #0x10
    // 0x115d408: ret
    //     0x115d408: ret             
    // 0x115d40c: ldur            x0, [fp, #-8]
    // 0x115d410: d1 = 1.000000
    //     0x115d410: fmov            d1, #1.00000000
    // 0x115d414: fcmp            d0, d1
    // 0x115d418: b.ne            #0x115d43c
    // 0x115d41c: LoadField: r1 = r0->field_f
    //     0x115d41c: ldur            w1, [x0, #0xf]
    // 0x115d420: DecompressPointer r1
    //     0x115d420: add             x1, x1, HEAP, lsl #32
    // 0x115d424: cmp             w1, NULL
    // 0x115d428: b.eq            #0x115d5e0
    // 0x115d42c: mov             x0, x1
    // 0x115d430: LeaveFrame
    //     0x115d430: mov             SP, fp
    //     0x115d434: ldp             fp, lr, [SP], #0x10
    // 0x115d438: ret
    //     0x115d438: ret             
    // 0x115d43c: LoadField: r1 = r0->field_1f
    //     0x115d43c: ldur            w1, [x0, #0x1f]
    // 0x115d440: DecompressPointer r1
    //     0x115d440: add             x1, x1, HEAP, lsl #32
    // 0x115d444: cmp             w1, NULL
    // 0x115d448: b.eq            #0x115d45c
    // 0x115d44c: LoadField: r2 = r0->field_23
    //     0x115d44c: ldur            w2, [x0, #0x23]
    // 0x115d450: DecompressPointer r2
    //     0x115d450: add             x2, x2, HEAP, lsl #32
    // 0x115d454: cmp             w2, NULL
    // 0x115d458: b.ne            #0x115d4b0
    // 0x115d45c: LoadField: r1 = r0->field_b
    //     0x115d45c: ldur            w1, [x0, #0xb]
    // 0x115d460: DecompressPointer r1
    //     0x115d460: add             x1, x1, HEAP, lsl #32
    // 0x115d464: LoadField: r2 = r0->field_f
    //     0x115d464: ldur            w2, [x0, #0xf]
    // 0x115d468: DecompressPointer r2
    //     0x115d468: add             x2, x2, HEAP, lsl #32
    // 0x115d46c: r3 = inline_Allocate_Double()
    //     0x115d46c: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x115d470: add             x3, x3, #0x10
    //     0x115d474: cmp             x0, x3
    //     0x115d478: b.ls            #0x115d5e4
    //     0x115d47c: str             x3, [THR, #0x60]  ; THR::top
    //     0x115d480: sub             x3, x3, #0xf
    //     0x115d484: mov             x0, #0xe19c
    //     0x115d488: movk            x0, #3, lsl #16
    //     0x115d48c: stur            x0, [x3, #-1]
    // 0x115d490: dmb             ishst
    // 0x115d494: StoreField: r3->field_7 = d0
    //     0x115d494: stur            d0, [x3, #7]
    // 0x115d498: r0 = lerp()
    //     0x115d498: bl              #0xb6bc84  ; [dart:ui] Offset::lerp
    // 0x115d49c: cmp             w0, NULL
    // 0x115d4a0: b.eq            #0x115d600
    // 0x115d4a4: LeaveFrame
    //     0x115d4a4: mov             SP, fp
    //     0x115d4a8: ldp             fp, lr, [SP], #0x10
    // 0x115d4ac: ret
    //     0x115d4ac: ret             
    // 0x115d4b0: r3 = inline_Allocate_Double()
    //     0x115d4b0: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x115d4b4: add             x3, x3, #0x10
    //     0x115d4b8: cmp             x4, x3
    //     0x115d4bc: b.ls            #0x115d604
    //     0x115d4c0: str             x3, [THR, #0x60]  ; THR::top
    //     0x115d4c4: sub             x3, x3, #0xf
    //     0x115d4c8: mov             x4, #0xe19c
    //     0x115d4cc: movk            x4, #3, lsl #16
    //     0x115d4d0: stur            x4, [x3, #-1]
    // 0x115d4d4: dmb             ishst
    // 0x115d4d8: StoreField: r3->field_7 = d0
    //     0x115d4d8: stur            d0, [x3, #7]
    // 0x115d4dc: r0 = lerpDouble()
    //     0x115d4dc: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x115d4e0: cmp             w0, NULL
    // 0x115d4e4: b.eq            #0x115d628
    // 0x115d4e8: LoadField: d1 = r0->field_7
    //     0x115d4e8: ldur            d1, [x0, #7]
    // 0x115d4ec: mov             v0.16b, v1.16b
    // 0x115d4f0: stur            d1, [fp, #-0x18]
    // 0x115d4f4: stp             fp, lr, [SP, #-0x10]!
    // 0x115d4f8: mov             fp, SP
    // 0x115d4fc: CallRuntime_LibcCos(double) -> double
    //     0x115d4fc: and             SP, SP, #0xfffffffffffffff0
    //     0x115d500: mov             sp, SP
    //     0x115d504: ldr             x16, [THR, #0x778]  ; THR::LibcCos
    //     0x115d508: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x115d50c: blr             x16
    //     0x115d510: mov             x16, #8
    //     0x115d514: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x115d518: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x115d51c: sub             sp, x16, #1, lsl #12
    //     0x115d520: mov             SP, fp
    //     0x115d524: ldp             fp, lr, [SP], #0x10
    // 0x115d528: ldur            x19, [fp, #-8]
    // 0x115d52c: LoadField: r0 = r19->field_1b
    //     0x115d52c: ldur            w0, [x19, #0x1b]
    // 0x115d530: DecompressPointer r0
    //     0x115d530: add             x0, x0, HEAP, lsl #32
    // 0x115d534: cmp             w0, NULL
    // 0x115d538: b.eq            #0x115d62c
    // 0x115d53c: LoadField: d1 = r0->field_7
    //     0x115d53c: ldur            d1, [x0, #7]
    // 0x115d540: stur            d1, [fp, #-0x28]
    // 0x115d544: fmul            d2, d0, d1
    // 0x115d548: ldur            d0, [fp, #-0x18]
    // 0x115d54c: stur            d2, [fp, #-0x20]
    // 0x115d550: stp             fp, lr, [SP, #-0x10]!
    // 0x115d554: mov             fp, SP
    // 0x115d558: CallRuntime_LibcSin(double) -> double
    //     0x115d558: and             SP, SP, #0xfffffffffffffff0
    //     0x115d55c: mov             sp, SP
    //     0x115d560: ldr             x16, [THR, #0x780]  ; THR::LibcSin
    //     0x115d564: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x115d568: blr             x16
    //     0x115d56c: mov             x16, #8
    //     0x115d570: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x115d574: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x115d578: sub             sp, x16, #1, lsl #12
    //     0x115d57c: mov             SP, fp
    //     0x115d580: ldp             fp, lr, [SP], #0x10
    // 0x115d584: mov             v1.16b, v0.16b
    // 0x115d588: ldur            d0, [fp, #-0x28]
    // 0x115d58c: fmul            d2, d1, d0
    // 0x115d590: stur            d2, [fp, #-0x18]
    // 0x115d594: ArrayLoad: r1 = r19[0]  ; List_4
    //     0x115d594: ldur            w1, [x19, #0x17]
    // 0x115d598: DecompressPointer r1
    //     0x115d598: add             x1, x1, HEAP, lsl #32
    // 0x115d59c: stur            x1, [fp, #-0x10]
    // 0x115d5a0: cmp             w1, NULL
    // 0x115d5a4: b.eq            #0x115d630
    // 0x115d5a8: r0 = Offset()
    //     0x115d5a8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x115d5ac: ldur            d0, [fp, #-0x20]
    // 0x115d5b0: StoreField: r0->field_7 = d0
    //     0x115d5b0: stur            d0, [x0, #7]
    // 0x115d5b4: ldur            d0, [fp, #-0x18]
    // 0x115d5b8: StoreField: r0->field_f = d0
    //     0x115d5b8: stur            d0, [x0, #0xf]
    // 0x115d5bc: ldur            x1, [fp, #-0x10]
    // 0x115d5c0: mov             x2, x0
    // 0x115d5c4: r0 = +()
    //     0x115d5c4: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0x115d5c8: LeaveFrame
    //     0x115d5c8: mov             SP, fp
    //     0x115d5cc: ldp             fp, lr, [SP], #0x10
    // 0x115d5d0: ret
    //     0x115d5d0: ret             
    // 0x115d5d4: r0 = StackOverflowSharedWithFPURegs()
    //     0x115d5d4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x115d5d8: b               #0x115d3c4
    // 0x115d5dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115d5dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x115d5e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115d5e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x115d5e4: SaveReg d0
    //     0x115d5e4: str             q0, [SP, #-0x10]!
    // 0x115d5e8: stp             x1, x2, [SP, #-0x10]!
    // 0x115d5ec: r0 = AllocateDouble()
    //     0x115d5ec: bl              #0x13df878  ; AllocateDoubleStub
    // 0x115d5f0: mov             x3, x0
    // 0x115d5f4: ldp             x1, x2, [SP], #0x10
    // 0x115d5f8: RestoreReg d0
    //     0x115d5f8: ldr             q0, [SP], #0x10
    // 0x115d5fc: b               #0x115d494
    // 0x115d600: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115d600: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x115d604: SaveReg d0
    //     0x115d604: str             q0, [SP, #-0x10]!
    // 0x115d608: stp             x1, x2, [SP, #-0x10]!
    // 0x115d60c: SaveReg r0
    //     0x115d60c: str             x0, [SP, #-8]!
    // 0x115d610: r0 = AllocateDouble()
    //     0x115d610: bl              #0x13df878  ; AllocateDoubleStub
    // 0x115d614: mov             x3, x0
    // 0x115d618: RestoreReg r0
    //     0x115d618: ldr             x0, [SP], #8
    // 0x115d61c: ldp             x1, x2, [SP], #0x10
    // 0x115d620: RestoreReg d0
    //     0x115d620: ldr             q0, [SP], #0x10
    // 0x115d624: b               #0x115d4d8
    // 0x115d628: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115d628: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x115d62c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x115d62c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x115d630: r0 = NullCastErrorSharedWithFPURegs()
    //     0x115d630: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _initialize(/* No info */) {
    // ** addr: 0x115d634, size: 0x7f0
    // 0x115d634: EnterFrame
    //     0x115d634: stp             fp, lr, [SP, #-0x10]!
    //     0x115d638: mov             fp, SP
    // 0x115d63c: AllocStack(0x50)
    //     0x115d63c: sub             SP, SP, #0x50
    // 0x115d640: SetupParameters(MaterialPointArcTween this /* r1 => r0, fp-0x18 */)
    //     0x115d640: mov             x0, x1
    //     0x115d644: stur            x1, [fp, #-0x18]
    // 0x115d648: CheckStackOverflow
    //     0x115d648: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115d64c: cmp             SP, x16
    //     0x115d650: b.ls            #0x115dd94
    // 0x115d654: LoadField: r3 = r0->field_b
    //     0x115d654: ldur            w3, [x0, #0xb]
    // 0x115d658: DecompressPointer r3
    //     0x115d658: add             x3, x3, HEAP, lsl #32
    // 0x115d65c: stur            x3, [fp, #-0x10]
    // 0x115d660: cmp             w3, NULL
    // 0x115d664: b.eq            #0x115dd9c
    // 0x115d668: LoadField: r4 = r0->field_f
    //     0x115d668: ldur            w4, [x0, #0xf]
    // 0x115d66c: DecompressPointer r4
    //     0x115d66c: add             x4, x4, HEAP, lsl #32
    // 0x115d670: stur            x4, [fp, #-8]
    // 0x115d674: cmp             w4, NULL
    // 0x115d678: b.eq            #0x115dda0
    // 0x115d67c: mov             x1, x4
    // 0x115d680: mov             x2, x3
    // 0x115d684: r0 = -()
    //     0x115d684: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x115d688: LoadField: d0 = r0->field_7
    //     0x115d688: ldur            d0, [x0, #7]
    // 0x115d68c: d1 = 0.000000
    //     0x115d68c: eor             v1.16b, v1.16b, v1.16b
    // 0x115d690: fcmp            d0, d1
    // 0x115d694: b.ne            #0x115d6a0
    // 0x115d698: d2 = 0.000000
    //     0x115d698: eor             v2.16b, v2.16b, v2.16b
    // 0x115d69c: b               #0x115d6b4
    // 0x115d6a0: fcmp            d1, d0
    // 0x115d6a4: b.le            #0x115d6b0
    // 0x115d6a8: fneg            d2, d0
    // 0x115d6ac: b               #0x115d6b4
    // 0x115d6b0: mov             v2.16b, v0.16b
    // 0x115d6b4: stur            d2, [fp, #-0x40]
    // 0x115d6b8: LoadField: d3 = r0->field_f
    //     0x115d6b8: ldur            d3, [x0, #0xf]
    // 0x115d6bc: fcmp            d3, d1
    // 0x115d6c0: b.ne            #0x115d6cc
    // 0x115d6c4: d4 = 0.000000
    //     0x115d6c4: eor             v4.16b, v4.16b, v4.16b
    // 0x115d6c8: b               #0x115d6e0
    // 0x115d6cc: fcmp            d1, d3
    // 0x115d6d0: b.le            #0x115d6dc
    // 0x115d6d4: fneg            d4, d3
    // 0x115d6d8: b               #0x115d6e0
    // 0x115d6dc: mov             v4.16b, v3.16b
    // 0x115d6e0: ldur            x2, [fp, #-0x10]
    // 0x115d6e4: ldur            x0, [fp, #-8]
    // 0x115d6e8: stur            d4, [fp, #-0x38]
    // 0x115d6ec: fmul            d5, d0, d0
    // 0x115d6f0: fmul            d0, d3, d3
    // 0x115d6f4: fadd            d3, d5, d0
    // 0x115d6f8: fsqrt           d0, d3
    // 0x115d6fc: stur            d0, [fp, #-0x30]
    // 0x115d700: LoadField: d3 = r0->field_7
    //     0x115d700: ldur            d3, [x0, #7]
    // 0x115d704: stur            d3, [fp, #-0x28]
    // 0x115d708: LoadField: d5 = r2->field_f
    //     0x115d708: ldur            d5, [x2, #0xf]
    // 0x115d70c: stur            d5, [fp, #-0x20]
    // 0x115d710: r0 = Offset()
    //     0x115d710: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x115d714: ldur            d0, [fp, #-0x28]
    // 0x115d718: StoreField: r0->field_7 = d0
    //     0x115d718: stur            d0, [x0, #7]
    // 0x115d71c: ldur            d1, [fp, #-0x20]
    // 0x115d720: StoreField: r0->field_f = d1
    //     0x115d720: stur            d1, [x0, #0xf]
    // 0x115d724: ldur            d2, [fp, #-0x40]
    // 0x115d728: d3 = 2.000000
    //     0x115d728: fmov            d3, #2.00000000
    // 0x115d72c: fcmp            d2, d3
    // 0x115d730: b.le            #0x115dd70
    // 0x115d734: ldur            d4, [fp, #-0x38]
    // 0x115d738: fcmp            d4, d3
    // 0x115d73c: b.le            #0x115dd68
    // 0x115d740: fcmp            d4, d2
    // 0x115d744: b.le            #0x115da44
    // 0x115d748: ldur            x4, [fp, #-0x18]
    // 0x115d74c: ldur            x3, [fp, #-0x10]
    // 0x115d750: ldur            d2, [fp, #-0x30]
    // 0x115d754: fmul            d4, d2, d2
    // 0x115d758: mov             x1, x0
    // 0x115d75c: mov             x2, x3
    // 0x115d760: stur            d4, [fp, #-0x38]
    // 0x115d764: r0 = -()
    //     0x115d764: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x115d768: LoadField: d0 = r0->field_7
    //     0x115d768: ldur            d0, [x0, #7]
    // 0x115d76c: fmul            d1, d0, d0
    // 0x115d770: LoadField: d0 = r0->field_f
    //     0x115d770: ldur            d0, [x0, #0xf]
    // 0x115d774: fmul            d2, d0, d0
    // 0x115d778: fadd            d0, d1, d2
    // 0x115d77c: fsqrt           d1, d0
    // 0x115d780: ldur            d0, [fp, #-0x38]
    // 0x115d784: fdiv            d2, d0, d1
    // 0x115d788: d0 = 2.000000
    //     0x115d788: fmov            d0, #2.00000000
    // 0x115d78c: fdiv            d1, d2, d0
    // 0x115d790: stur            d1, [fp, #-0x50]
    // 0x115d794: r0 = inline_Allocate_Double()
    //     0x115d794: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x115d798: add             x0, x0, #0x10
    //     0x115d79c: cmp             x1, x0
    //     0x115d7a0: b.ls            #0x115dda4
    //     0x115d7a4: str             x0, [THR, #0x60]  ; THR::top
    //     0x115d7a8: sub             x0, x0, #0xf
    //     0x115d7ac: mov             x1, #0xe19c
    //     0x115d7b0: movk            x1, #3, lsl #16
    //     0x115d7b4: stur            x1, [x0, #-1]
    // 0x115d7b8: dmb             ishst
    // 0x115d7bc: StoreField: r0->field_7 = d1
    //     0x115d7bc: stur            d1, [x0, #7]
    // 0x115d7c0: ldur            x1, [fp, #-0x18]
    // 0x115d7c4: StoreField: r1->field_1b = r0
    //     0x115d7c4: stur            w0, [x1, #0x1b]
    //     0x115d7c8: ldurb           w16, [x1, #-1]
    //     0x115d7cc: ldurb           w17, [x0, #-1]
    //     0x115d7d0: and             x16, x17, x16, lsr #2
    //     0x115d7d4: tst             x16, HEAP, lsr #32
    //     0x115d7d8: b.eq            #0x115d7e0
    //     0x115d7dc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x115d7e0: ldur            x3, [fp, #-0x10]
    // 0x115d7e4: LoadField: d2 = r3->field_7
    //     0x115d7e4: ldur            d2, [x3, #7]
    // 0x115d7e8: ldur            d3, [fp, #-0x28]
    // 0x115d7ec: stur            d2, [fp, #-0x48]
    // 0x115d7f0: fsub            d4, d2, d3
    // 0x115d7f4: d5 = 0.000000
    //     0x115d7f4: eor             v5.16b, v5.16b, v5.16b
    // 0x115d7f8: fcmp            d4, d5
    // 0x115d7fc: b.le            #0x115d808
    // 0x115d800: d4 = 1.000000
    //     0x115d800: fmov            d4, #1.00000000
    // 0x115d804: b               #0x115d814
    // 0x115d808: fcmp            d5, d4
    // 0x115d80c: b.le            #0x115d814
    // 0x115d810: d4 = -1.000000
    //     0x115d810: fmov            d4, #-1.00000000
    // 0x115d814: ldur            x4, [fp, #-8]
    // 0x115d818: fmul            d6, d1, d4
    // 0x115d81c: fadd            d4, d3, d6
    // 0x115d820: stur            d4, [fp, #-0x40]
    // 0x115d824: LoadField: d6 = r4->field_f
    //     0x115d824: ldur            d6, [x4, #0xf]
    // 0x115d828: stur            d6, [fp, #-0x38]
    // 0x115d82c: r0 = Offset()
    //     0x115d82c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x115d830: ldur            d0, [fp, #-0x40]
    // 0x115d834: StoreField: r0->field_7 = d0
    //     0x115d834: stur            d0, [x0, #7]
    // 0x115d838: ldur            d1, [fp, #-0x38]
    // 0x115d83c: StoreField: r0->field_f = d1
    //     0x115d83c: stur            d1, [x0, #0xf]
    // 0x115d840: ldur            x19, [fp, #-0x18]
    // 0x115d844: ArrayStore: r19[0] = r0  ; List_4
    //     0x115d844: stur            w0, [x19, #0x17]
    //     0x115d848: ldurb           w16, [x19, #-1]
    //     0x115d84c: ldurb           w17, [x0, #-1]
    //     0x115d850: and             x16, x17, x16, lsr #2
    //     0x115d854: tst             x16, HEAP, lsr #32
    //     0x115d858: b.eq            #0x115d860
    //     0x115d85c: bl              #0x13de154  ; WriteBarrierWrappersStub
    // 0x115d860: ldur            d0, [fp, #-0x48]
    // 0x115d864: ldur            d2, [fp, #-0x28]
    // 0x115d868: fcmp            d2, d0
    // 0x115d86c: b.le            #0x115d948
    // 0x115d870: ldur            d0, [fp, #-0x50]
    // 0x115d874: ldur            d3, [fp, #-0x20]
    // 0x115d878: ldur            d4, [fp, #-0x30]
    // 0x115d87c: d2 = 2.000000
    //     0x115d87c: fmov            d2, #2.00000000
    // 0x115d880: fmul            d5, d0, d2
    // 0x115d884: fdiv            d0, d4, d5
    // 0x115d888: stp             fp, lr, [SP, #-0x10]!
    // 0x115d88c: mov             fp, SP
    // 0x115d890: CallRuntime_LibcAsin(double) -> double
    //     0x115d890: and             SP, SP, #0xfffffffffffffff0
    //     0x115d894: mov             sp, SP
    //     0x115d898: ldr             x16, [THR, #0x798]  ; THR::LibcAsin
    //     0x115d89c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x115d8a0: blr             x16
    //     0x115d8a4: mov             x16, #8
    //     0x115d8a8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x115d8ac: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x115d8b0: sub             sp, x16, #1, lsl #12
    //     0x115d8b4: mov             SP, fp
    //     0x115d8b8: ldp             fp, lr, [SP], #0x10
    // 0x115d8bc: d1 = 2.000000
    //     0x115d8bc: fmov            d1, #2.00000000
    // 0x115d8c0: fmul            d2, d0, d1
    // 0x115d8c4: ldur            d3, [fp, #-0x38]
    // 0x115d8c8: ldur            d5, [fp, #-0x20]
    // 0x115d8cc: fsub            d0, d5, d3
    // 0x115d8d0: d6 = 0.000000
    //     0x115d8d0: eor             v6.16b, v6.16b, v6.16b
    // 0x115d8d4: fcmp            d0, d6
    // 0x115d8d8: b.le            #0x115d8e4
    // 0x115d8dc: d0 = 1.000000
    //     0x115d8dc: fmov            d0, #1.00000000
    // 0x115d8e0: b               #0x115d8f0
    // 0x115d8e4: fcmp            d6, d0
    // 0x115d8e8: b.le            #0x115d8f0
    // 0x115d8ec: d0 = -1.000000
    //     0x115d8ec: fmov            d0, #-1.00000000
    // 0x115d8f0: r1 = 0.000000
    //     0x115d8f0: ldr             x1, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x115d8f4: fmul            d1, d2, d0
    // 0x115d8f8: r0 = inline_Allocate_Double()
    //     0x115d8f8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x115d8fc: add             x0, x0, #0x10
    //     0x115d900: cmp             x2, x0
    //     0x115d904: b.ls            #0x115ddb4
    //     0x115d908: str             x0, [THR, #0x60]  ; THR::top
    //     0x115d90c: sub             x0, x0, #0xf
    //     0x115d910: mov             x2, #0xe19c
    //     0x115d914: movk            x2, #3, lsl #16
    //     0x115d918: stur            x2, [x0, #-1]
    // 0x115d91c: dmb             ishst
    // 0x115d920: StoreField: r0->field_7 = d1
    //     0x115d920: stur            d1, [x0, #7]
    // 0x115d924: StoreField: r19->field_1f = r0
    //     0x115d924: stur            w0, [x19, #0x1f]
    //     0x115d928: ldurb           w16, [x19, #-1]
    //     0x115d92c: ldurb           w17, [x0, #-1]
    //     0x115d930: and             x16, x17, x16, lsr #2
    //     0x115d934: tst             x16, HEAP, lsr #32
    //     0x115d938: b.eq            #0x115d940
    //     0x115d93c: bl              #0x13de154  ; WriteBarrierWrappersStub
    // 0x115d940: StoreField: r19->field_23 = r1
    //     0x115d940: stur            w1, [x19, #0x23]
    // 0x115d944: b               #0x115dd7c
    // 0x115d948: ldur            d0, [fp, #-0x50]
    // 0x115d94c: mov             v3.16b, v1.16b
    // 0x115d950: ldur            d5, [fp, #-0x20]
    // 0x115d954: ldur            d4, [fp, #-0x30]
    // 0x115d958: d6 = 0.000000
    //     0x115d958: eor             v6.16b, v6.16b, v6.16b
    // 0x115d95c: d1 = 2.000000
    //     0x115d95c: fmov            d1, #2.00000000
    // 0x115d960: fmul            d2, d0, d1
    // 0x115d964: fdiv            d0, d4, d2
    // 0x115d968: stp             fp, lr, [SP, #-0x10]!
    // 0x115d96c: mov             fp, SP
    // 0x115d970: CallRuntime_LibcAsin(double) -> double
    //     0x115d970: and             SP, SP, #0xfffffffffffffff0
    //     0x115d974: mov             sp, SP
    //     0x115d978: ldr             x16, [THR, #0x798]  ; THR::LibcAsin
    //     0x115d97c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x115d980: blr             x16
    //     0x115d984: mov             x16, #8
    //     0x115d988: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x115d98c: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x115d990: sub             sp, x16, #1, lsl #12
    //     0x115d994: mov             SP, fp
    //     0x115d998: ldp             fp, lr, [SP], #0x10
    // 0x115d99c: mov             v1.16b, v0.16b
    // 0x115d9a0: d0 = 2.000000
    //     0x115d9a0: fmov            d0, #2.00000000
    // 0x115d9a4: fmul            d2, d1, d0
    // 0x115d9a8: ldur            d0, [fp, #-0x38]
    // 0x115d9ac: ldur            d1, [fp, #-0x20]
    // 0x115d9b0: fsub            d3, d0, d1
    // 0x115d9b4: d5 = 0.000000
    //     0x115d9b4: eor             v5.16b, v5.16b, v5.16b
    // 0x115d9b8: fcmp            d3, d5
    // 0x115d9bc: b.le            #0x115d9c8
    // 0x115d9c0: d1 = 1.000000
    //     0x115d9c0: fmov            d1, #1.00000000
    // 0x115d9c4: b               #0x115d9dc
    // 0x115d9c8: fcmp            d5, d3
    // 0x115d9cc: b.le            #0x115d9d8
    // 0x115d9d0: d1 = -1.000000
    //     0x115d9d0: fmov            d1, #-1.00000000
    // 0x115d9d4: b               #0x115d9dc
    // 0x115d9d8: mov             v1.16b, v3.16b
    // 0x115d9dc: r1 = 3.141593
    //     0x115d9dc: add             x1, PP, #0x95, lsl #12  ; [pp+0x95ec0] 3.141592653589793
    //     0x115d9e0: ldr             x1, [x1, #0xec0]
    // 0x115d9e4: d0 = 3.141593
    //     0x115d9e4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13178] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0x115d9e8: ldr             d0, [x17, #0x178]
    // 0x115d9ec: fmul            d3, d2, d1
    // 0x115d9f0: fadd            d1, d3, d0
    // 0x115d9f4: r0 = inline_Allocate_Double()
    //     0x115d9f4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x115d9f8: add             x0, x0, #0x10
    //     0x115d9fc: cmp             x2, x0
    //     0x115da00: b.ls            #0x115ddcc
    //     0x115da04: str             x0, [THR, #0x60]  ; THR::top
    //     0x115da08: sub             x0, x0, #0xf
    //     0x115da0c: mov             x2, #0xe19c
    //     0x115da10: movk            x2, #3, lsl #16
    //     0x115da14: stur            x2, [x0, #-1]
    // 0x115da18: dmb             ishst
    // 0x115da1c: StoreField: r0->field_7 = d1
    //     0x115da1c: stur            d1, [x0, #7]
    // 0x115da20: StoreField: r19->field_1f = r0
    //     0x115da20: stur            w0, [x19, #0x1f]
    //     0x115da24: ldurb           w16, [x19, #-1]
    //     0x115da28: ldurb           w17, [x0, #-1]
    //     0x115da2c: and             x16, x17, x16, lsr #2
    //     0x115da30: tst             x16, HEAP, lsr #32
    //     0x115da34: b.eq            #0x115da3c
    //     0x115da38: bl              #0x13de154  ; WriteBarrierWrappersStub
    // 0x115da3c: StoreField: r19->field_23 = r1
    //     0x115da3c: stur            w1, [x19, #0x23]
    // 0x115da40: b               #0x115dd7c
    // 0x115da44: ldur            x19, [fp, #-0x18]
    // 0x115da48: ldur            x3, [fp, #-0x10]
    // 0x115da4c: ldur            x4, [fp, #-8]
    // 0x115da50: mov             v2.16b, v0.16b
    // 0x115da54: ldur            d4, [fp, #-0x30]
    // 0x115da58: mov             v0.16b, v3.16b
    // 0x115da5c: d5 = 0.000000
    //     0x115da5c: eor             v5.16b, v5.16b, v5.16b
    // 0x115da60: fmul            d3, d4, d4
    // 0x115da64: mov             x1, x0
    // 0x115da68: mov             x2, x4
    // 0x115da6c: stur            d3, [fp, #-0x38]
    // 0x115da70: r0 = -()
    //     0x115da70: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x115da74: LoadField: d0 = r0->field_7
    //     0x115da74: ldur            d0, [x0, #7]
    // 0x115da78: fmul            d1, d0, d0
    // 0x115da7c: LoadField: d0 = r0->field_f
    //     0x115da7c: ldur            d0, [x0, #0xf]
    // 0x115da80: fmul            d2, d0, d0
    // 0x115da84: fadd            d0, d1, d2
    // 0x115da88: fsqrt           d1, d0
    // 0x115da8c: ldur            d0, [fp, #-0x38]
    // 0x115da90: fdiv            d2, d0, d1
    // 0x115da94: d0 = 2.000000
    //     0x115da94: fmov            d0, #2.00000000
    // 0x115da98: fdiv            d1, d2, d0
    // 0x115da9c: stur            d1, [fp, #-0x50]
    // 0x115daa0: r0 = inline_Allocate_Double()
    //     0x115daa0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x115daa4: add             x0, x0, #0x10
    //     0x115daa8: cmp             x1, x0
    //     0x115daac: b.ls            #0x115dde4
    //     0x115dab0: str             x0, [THR, #0x60]  ; THR::top
    //     0x115dab4: sub             x0, x0, #0xf
    //     0x115dab8: mov             x1, #0xe19c
    //     0x115dabc: movk            x1, #3, lsl #16
    //     0x115dac0: stur            x1, [x0, #-1]
    // 0x115dac4: dmb             ishst
    // 0x115dac8: StoreField: r0->field_7 = d1
    //     0x115dac8: stur            d1, [x0, #7]
    // 0x115dacc: ldur            x1, [fp, #-0x18]
    // 0x115dad0: StoreField: r1->field_1b = r0
    //     0x115dad0: stur            w0, [x1, #0x1b]
    //     0x115dad4: ldurb           w16, [x1, #-1]
    //     0x115dad8: ldurb           w17, [x0, #-1]
    //     0x115dadc: and             x16, x17, x16, lsr #2
    //     0x115dae0: tst             x16, HEAP, lsr #32
    //     0x115dae4: b.eq            #0x115daec
    //     0x115dae8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x115daec: ldur            x0, [fp, #-0x10]
    // 0x115daf0: LoadField: d2 = r0->field_7
    //     0x115daf0: ldur            d2, [x0, #7]
    // 0x115daf4: ldur            x0, [fp, #-8]
    // 0x115daf8: stur            d2, [fp, #-0x48]
    // 0x115dafc: LoadField: d3 = r0->field_f
    //     0x115dafc: ldur            d3, [x0, #0xf]
    // 0x115db00: ldur            d4, [fp, #-0x20]
    // 0x115db04: stur            d3, [fp, #-0x40]
    // 0x115db08: fsub            d5, d3, d4
    // 0x115db0c: d6 = 0.000000
    //     0x115db0c: eor             v6.16b, v6.16b, v6.16b
    // 0x115db10: fcmp            d5, d6
    // 0x115db14: b.le            #0x115db20
    // 0x115db18: d5 = 1.000000
    //     0x115db18: fmov            d5, #1.00000000
    // 0x115db1c: b               #0x115db2c
    // 0x115db20: fcmp            d6, d5
    // 0x115db24: b.le            #0x115db2c
    // 0x115db28: d5 = -1.000000
    //     0x115db28: fmov            d5, #-1.00000000
    // 0x115db2c: fmul            d7, d5, d1
    // 0x115db30: fadd            d5, d4, d7
    // 0x115db34: stur            d5, [fp, #-0x38]
    // 0x115db38: r0 = Offset()
    //     0x115db38: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x115db3c: ldur            d1, [fp, #-0x48]
    // 0x115db40: StoreField: r0->field_7 = d1
    //     0x115db40: stur            d1, [x0, #7]
    // 0x115db44: ldur            d0, [fp, #-0x38]
    // 0x115db48: StoreField: r0->field_f = d0
    //     0x115db48: stur            d0, [x0, #0xf]
    // 0x115db4c: ldur            x19, [fp, #-0x18]
    // 0x115db50: ArrayStore: r19[0] = r0  ; List_4
    //     0x115db50: stur            w0, [x19, #0x17]
    //     0x115db54: ldurb           w16, [x19, #-1]
    //     0x115db58: ldurb           w17, [x0, #-1]
    //     0x115db5c: and             x16, x17, x16, lsr #2
    //     0x115db60: tst             x16, HEAP, lsr #32
    //     0x115db64: b.eq            #0x115db6c
    //     0x115db68: bl              #0x13de154  ; WriteBarrierWrappersStub
    // 0x115db6c: ldur            d0, [fp, #-0x40]
    // 0x115db70: ldur            d2, [fp, #-0x20]
    // 0x115db74: fcmp            d0, d2
    // 0x115db78: b.le            #0x115dc6c
    // 0x115db7c: ldur            d0, [fp, #-0x50]
    // 0x115db80: ldur            d3, [fp, #-0x28]
    // 0x115db84: ldur            d4, [fp, #-0x30]
    // 0x115db88: d2 = 2.000000
    //     0x115db88: fmov            d2, #2.00000000
    // 0x115db8c: r20 = -1.570796
    //     0x115db8c: add             x20, PP, #0x95, lsl #12  ; [pp+0x95ec8] -1.5707963267948966
    //     0x115db90: ldr             x20, [x20, #0xec8]
    // 0x115db94: StoreField: r19->field_1f = r20
    //     0x115db94: stur            w20, [x19, #0x1f]
    // 0x115db98: fmul            d5, d0, d2
    // 0x115db9c: fdiv            d0, d4, d5
    // 0x115dba0: stp             fp, lr, [SP, #-0x10]!
    // 0x115dba4: mov             fp, SP
    // 0x115dba8: CallRuntime_LibcAsin(double) -> double
    //     0x115dba8: and             SP, SP, #0xfffffffffffffff0
    //     0x115dbac: mov             sp, SP
    //     0x115dbb0: ldr             x16, [THR, #0x798]  ; THR::LibcAsin
    //     0x115dbb4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x115dbb8: blr             x16
    //     0x115dbbc: mov             x16, #8
    //     0x115dbc0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x115dbc4: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x115dbc8: sub             sp, x16, #1, lsl #12
    //     0x115dbcc: mov             SP, fp
    //     0x115dbd0: ldp             fp, lr, [SP], #0x10
    // 0x115dbd4: d1 = 2.000000
    //     0x115dbd4: fmov            d1, #2.00000000
    // 0x115dbd8: fmul            d2, d0, d1
    // 0x115dbdc: ldur            d3, [fp, #-0x48]
    // 0x115dbe0: ldur            d5, [fp, #-0x28]
    // 0x115dbe4: fsub            d0, d5, d3
    // 0x115dbe8: d6 = 0.000000
    //     0x115dbe8: eor             v6.16b, v6.16b, v6.16b
    // 0x115dbec: fcmp            d0, d6
    // 0x115dbf0: b.le            #0x115dbfc
    // 0x115dbf4: d1 = 1.000000
    //     0x115dbf4: fmov            d1, #1.00000000
    // 0x115dbf8: b               #0x115dc10
    // 0x115dbfc: fcmp            d6, d0
    // 0x115dc00: b.le            #0x115dc0c
    // 0x115dc04: d1 = -1.000000
    //     0x115dc04: fmov            d1, #-1.00000000
    // 0x115dc08: b               #0x115dc10
    // 0x115dc0c: mov             v1.16b, v0.16b
    // 0x115dc10: d0 = -1.570796
    //     0x115dc10: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1f148] IMM: double(-1.5707963267948966) from 0xbff921fb54442d18
    //     0x115dc14: ldr             d0, [x17, #0x148]
    // 0x115dc18: fmul            d3, d2, d1
    // 0x115dc1c: fadd            d1, d3, d0
    // 0x115dc20: r0 = inline_Allocate_Double()
    //     0x115dc20: ldp             x0, x20, [THR, #0x60]  ; THR::top
    //     0x115dc24: add             x0, x0, #0x10
    //     0x115dc28: cmp             x20, x0
    //     0x115dc2c: b.ls            #0x115ddf4
    //     0x115dc30: str             x0, [THR, #0x60]  ; THR::top
    //     0x115dc34: sub             x0, x0, #0xf
    //     0x115dc38: mov             x20, #0xe19c
    //     0x115dc3c: movk            x20, #3, lsl #16
    //     0x115dc40: stur            x20, [x0, #-1]
    // 0x115dc44: dmb             ishst
    // 0x115dc48: StoreField: r0->field_7 = d1
    //     0x115dc48: stur            d1, [x0, #7]
    // 0x115dc4c: StoreField: r19->field_23 = r0
    //     0x115dc4c: stur            w0, [x19, #0x23]
    //     0x115dc50: ldurb           w16, [x19, #-1]
    //     0x115dc54: ldurb           w17, [x0, #-1]
    //     0x115dc58: and             x16, x17, x16, lsr #2
    //     0x115dc5c: tst             x16, HEAP, lsr #32
    //     0x115dc60: b.eq            #0x115dc68
    //     0x115dc64: bl              #0x13de154  ; WriteBarrierWrappersStub
    // 0x115dc68: b               #0x115dd7c
    // 0x115dc6c: ldur            d0, [fp, #-0x50]
    // 0x115dc70: mov             v3.16b, v1.16b
    // 0x115dc74: ldur            d5, [fp, #-0x28]
    // 0x115dc78: ldur            d4, [fp, #-0x30]
    // 0x115dc7c: d6 = 0.000000
    //     0x115dc7c: eor             v6.16b, v6.16b, v6.16b
    // 0x115dc80: d1 = 2.000000
    //     0x115dc80: fmov            d1, #2.00000000
    // 0x115dc84: r20 = 1.570796
    //     0x115dc84: add             x20, PP, #0x95, lsl #12  ; [pp+0x95ed0] 1.5707963267948966
    //     0x115dc88: ldr             x20, [x20, #0xed0]
    // 0x115dc8c: StoreField: r19->field_1f = r20
    //     0x115dc8c: stur            w20, [x19, #0x1f]
    // 0x115dc90: fmul            d2, d0, d1
    // 0x115dc94: fdiv            d0, d4, d2
    // 0x115dc98: stp             fp, lr, [SP, #-0x10]!
    // 0x115dc9c: mov             fp, SP
    // 0x115dca0: CallRuntime_LibcAsin(double) -> double
    //     0x115dca0: and             SP, SP, #0xfffffffffffffff0
    //     0x115dca4: mov             sp, SP
    //     0x115dca8: ldr             x16, [THR, #0x798]  ; THR::LibcAsin
    //     0x115dcac: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x115dcb0: blr             x16
    //     0x115dcb4: mov             x16, #8
    //     0x115dcb8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x115dcbc: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x115dcc0: sub             sp, x16, #1, lsl #12
    //     0x115dcc4: mov             SP, fp
    //     0x115dcc8: ldp             fp, lr, [SP], #0x10
    // 0x115dccc: mov             v1.16b, v0.16b
    // 0x115dcd0: d0 = 2.000000
    //     0x115dcd0: fmov            d0, #2.00000000
    // 0x115dcd4: fmul            d2, d1, d0
    // 0x115dcd8: ldur            d0, [fp, #-0x48]
    // 0x115dcdc: ldur            d1, [fp, #-0x28]
    // 0x115dce0: fsub            d3, d0, d1
    // 0x115dce4: d0 = 0.000000
    //     0x115dce4: eor             v0.16b, v0.16b, v0.16b
    // 0x115dce8: fcmp            d3, d0
    // 0x115dcec: b.le            #0x115dcf8
    // 0x115dcf0: d1 = 1.000000
    //     0x115dcf0: fmov            d1, #1.00000000
    // 0x115dcf4: b               #0x115dd0c
    // 0x115dcf8: fcmp            d0, d3
    // 0x115dcfc: b.le            #0x115dd08
    // 0x115dd00: d1 = -1.000000
    //     0x115dd00: fmov            d1, #-1.00000000
    // 0x115dd04: b               #0x115dd0c
    // 0x115dd08: mov             v1.16b, v3.16b
    // 0x115dd0c: d0 = 1.570796
    //     0x115dd0c: add             x17, PP, #0x95, lsl #12  ; [pp+0x95ed8] IMM: double(1.5707963267948966) from 0x3ff921fb54442d18
    //     0x115dd10: ldr             d0, [x17, #0xed8]
    // 0x115dd14: fmul            d3, d2, d1
    // 0x115dd18: fadd            d1, d3, d0
    // 0x115dd1c: r0 = inline_Allocate_Double()
    //     0x115dd1c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x115dd20: add             x0, x0, #0x10
    //     0x115dd24: cmp             x1, x0
    //     0x115dd28: b.ls            #0x115de0c
    //     0x115dd2c: str             x0, [THR, #0x60]  ; THR::top
    //     0x115dd30: sub             x0, x0, #0xf
    //     0x115dd34: mov             x1, #0xe19c
    //     0x115dd38: movk            x1, #3, lsl #16
    //     0x115dd3c: stur            x1, [x0, #-1]
    // 0x115dd40: dmb             ishst
    // 0x115dd44: StoreField: r0->field_7 = d1
    //     0x115dd44: stur            d1, [x0, #7]
    // 0x115dd48: StoreField: r19->field_23 = r0
    //     0x115dd48: stur            w0, [x19, #0x23]
    //     0x115dd4c: ldurb           w16, [x19, #-1]
    //     0x115dd50: ldurb           w17, [x0, #-1]
    //     0x115dd54: and             x16, x17, x16, lsr #2
    //     0x115dd58: tst             x16, HEAP, lsr #32
    //     0x115dd5c: b.eq            #0x115dd64
    //     0x115dd60: bl              #0x13de154  ; WriteBarrierWrappersStub
    // 0x115dd64: b               #0x115dd7c
    // 0x115dd68: ldur            x19, [fp, #-0x18]
    // 0x115dd6c: b               #0x115dd74
    // 0x115dd70: ldur            x19, [fp, #-0x18]
    // 0x115dd74: StoreField: r19->field_1f = rNULL
    //     0x115dd74: stur            NULL, [x19, #0x1f]
    // 0x115dd78: StoreField: r19->field_23 = rNULL
    //     0x115dd78: stur            NULL, [x19, #0x23]
    // 0x115dd7c: r1 = false
    //     0x115dd7c: add             x1, NULL, #0x30  ; false
    // 0x115dd80: StoreField: r19->field_13 = r1
    //     0x115dd80: stur            w1, [x19, #0x13]
    // 0x115dd84: r0 = Null
    //     0x115dd84: mov             x0, NULL
    // 0x115dd88: LeaveFrame
    //     0x115dd88: mov             SP, fp
    //     0x115dd8c: ldp             fp, lr, [SP], #0x10
    // 0x115dd90: ret
    //     0x115dd90: ret             
    // 0x115dd94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x115dd94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x115dd98: b               #0x115d654
    // 0x115dd9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115dd9c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x115dda0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115dda0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x115dda4: stp             q0, q1, [SP, #-0x20]!
    // 0x115dda8: r0 = AllocateDouble()
    //     0x115dda8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x115ddac: ldp             q0, q1, [SP], #0x20
    // 0x115ddb0: b               #0x115d7bc
    // 0x115ddb4: SaveReg d1
    //     0x115ddb4: str             q1, [SP, #-0x10]!
    // 0x115ddb8: stp             x1, x19, [SP, #-0x10]!
    // 0x115ddbc: r0 = AllocateDouble()
    //     0x115ddbc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x115ddc0: ldp             x1, x19, [SP], #0x10
    // 0x115ddc4: RestoreReg d1
    //     0x115ddc4: ldr             q1, [SP], #0x10
    // 0x115ddc8: b               #0x115d920
    // 0x115ddcc: SaveReg d1
    //     0x115ddcc: str             q1, [SP, #-0x10]!
    // 0x115ddd0: stp             x1, x19, [SP, #-0x10]!
    // 0x115ddd4: r0 = AllocateDouble()
    //     0x115ddd4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x115ddd8: ldp             x1, x19, [SP], #0x10
    // 0x115dddc: RestoreReg d1
    //     0x115dddc: ldr             q1, [SP], #0x10
    // 0x115dde0: b               #0x115da1c
    // 0x115dde4: stp             q0, q1, [SP, #-0x20]!
    // 0x115dde8: r0 = AllocateDouble()
    //     0x115dde8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x115ddec: ldp             q0, q1, [SP], #0x20
    // 0x115ddf0: b               #0x115dac8
    // 0x115ddf4: SaveReg d1
    //     0x115ddf4: str             q1, [SP, #-0x10]!
    // 0x115ddf8: SaveReg r19
    //     0x115ddf8: str             x19, [SP, #-8]!
    // 0x115ddfc: r0 = AllocateDouble()
    //     0x115ddfc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x115de00: RestoreReg r19
    //     0x115de00: ldr             x19, [SP], #8
    // 0x115de04: RestoreReg d1
    //     0x115de04: ldr             q1, [SP], #0x10
    // 0x115de08: b               #0x115dc48
    // 0x115de0c: SaveReg d1
    //     0x115de0c: str             q1, [SP, #-0x10]!
    // 0x115de10: SaveReg r19
    //     0x115de10: str             x19, [SP, #-8]!
    // 0x115de14: r0 = AllocateDouble()
    //     0x115de14: bl              #0x13df878  ; AllocateDoubleStub
    // 0x115de18: RestoreReg r19
    //     0x115de18: ldr             x19, [SP], #8
    // 0x115de1c: RestoreReg d1
    //     0x115de1c: ldr             q1, [SP], #0x10
    // 0x115de20: b               #0x115dd44
  }
  set _ end=(/* No info */) {
    // ** addr: 0x11969ec, size: 0x118
    // 0x11969ec: EnterFrame
    //     0x11969ec: stp             fp, lr, [SP, #-0x10]!
    //     0x11969f0: mov             fp, SP
    // 0x11969f4: AllocStack(0x20)
    //     0x11969f4: sub             SP, SP, #0x20
    // 0x11969f8: SetupParameters(MaterialPointArcTween this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x11969f8: mov             x4, x1
    //     0x11969fc: mov             x3, x2
    //     0x1196a00: stur            x1, [fp, #-8]
    //     0x1196a04: stur            x2, [fp, #-0x10]
    // 0x1196a08: CheckStackOverflow
    //     0x1196a08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1196a0c: cmp             SP, x16
    //     0x1196a10: b.ls            #0x1196afc
    // 0x1196a14: mov             x0, x3
    // 0x1196a18: r2 = Null
    //     0x1196a18: mov             x2, NULL
    // 0x1196a1c: r1 = Null
    //     0x1196a1c: mov             x1, NULL
    // 0x1196a20: r4 = 60
    //     0x1196a20: mov             x4, #0x3c
    // 0x1196a24: branchIfSmi(r0, 0x1196a30)
    //     0x1196a24: tbz             w0, #0, #0x1196a30
    // 0x1196a28: r4 = LoadClassIdInstr(r0)
    //     0x1196a28: ldur            x4, [x0, #-1]
    //     0x1196a2c: ubfx            x4, x4, #0xc, #0x14
    // 0x1196a30: cmp             x4, #0xedc
    // 0x1196a34: b.eq            #0x1196a4c
    // 0x1196a38: r8 = Offset?
    //     0x1196a38: add             x8, PP, #0xa0, lsl #12  ; [pp+0xa0f70] Type: Offset?
    //     0x1196a3c: ldr             x8, [x8, #0xf70]
    // 0x1196a40: r3 = Null
    //     0x1196a40: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0f78] Null
    //     0x1196a44: ldr             x3, [x3, #0xf78]
    // 0x1196a48: r0 = DefaultNullableTypeTest()
    //     0x1196a48: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x1196a4c: ldur            x1, [fp, #-8]
    // 0x1196a50: LoadField: r0 = r1->field_f
    //     0x1196a50: ldur            w0, [x1, #0xf]
    // 0x1196a54: DecompressPointer r0
    //     0x1196a54: add             x0, x0, HEAP, lsl #32
    // 0x1196a58: ldur            x2, [fp, #-0x10]
    // 0x1196a5c: r3 = LoadClassIdInstr(r2)
    //     0x1196a5c: ldur            x3, [x2, #-1]
    //     0x1196a60: ubfx            x3, x3, #0xc, #0x14
    // 0x1196a64: stp             x0, x2, [SP]
    // 0x1196a68: mov             x0, x3
    // 0x1196a6c: mov             lr, x0
    // 0x1196a70: ldr             lr, [x21, lr, lsl #3]
    // 0x1196a74: blr             lr
    // 0x1196a78: tbz             w0, #4, #0x1196aec
    // 0x1196a7c: ldur            x3, [fp, #-8]
    // 0x1196a80: LoadField: r2 = r3->field_7
    //     0x1196a80: ldur            w2, [x3, #7]
    // 0x1196a84: DecompressPointer r2
    //     0x1196a84: add             x2, x2, HEAP, lsl #32
    // 0x1196a88: ldur            x0, [fp, #-0x10]
    // 0x1196a8c: r1 = Null
    //     0x1196a8c: mov             x1, NULL
    // 0x1196a90: cmp             w0, NULL
    // 0x1196a94: b.eq            #0x1196abc
    // 0x1196a98: cmp             w2, NULL
    // 0x1196a9c: b.eq            #0x1196abc
    // 0x1196aa0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x1196aa0: ldur            w4, [x2, #0x17]
    // 0x1196aa4: DecompressPointer r4
    //     0x1196aa4: add             x4, x4, HEAP, lsl #32
    // 0x1196aa8: r8 = X0?
    //     0x1196aa8: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0x1196aac: LoadField: r9 = r4->field_7
    //     0x1196aac: ldur            x9, [x4, #7]
    // 0x1196ab0: r3 = Null
    //     0x1196ab0: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0f88] Null
    //     0x1196ab4: ldr             x3, [x3, #0xf88]
    // 0x1196ab8: blr             x9
    // 0x1196abc: ldur            x0, [fp, #-0x10]
    // 0x1196ac0: ldur            x1, [fp, #-8]
    // 0x1196ac4: StoreField: r1->field_f = r0
    //     0x1196ac4: stur            w0, [x1, #0xf]
    //     0x1196ac8: tbz             w0, #0, #0x1196ae4
    //     0x1196acc: ldurb           w16, [x1, #-1]
    //     0x1196ad0: ldurb           w17, [x0, #-1]
    //     0x1196ad4: and             x16, x17, x16, lsr #2
    //     0x1196ad8: tst             x16, HEAP, lsr #32
    //     0x1196adc: b.eq            #0x1196ae4
    //     0x1196ae0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1196ae4: r2 = true
    //     0x1196ae4: add             x2, NULL, #0x20  ; true
    // 0x1196ae8: StoreField: r1->field_13 = r2
    //     0x1196ae8: stur            w2, [x1, #0x13]
    // 0x1196aec: r0 = Null
    //     0x1196aec: mov             x0, NULL
    // 0x1196af0: LeaveFrame
    //     0x1196af0: mov             SP, fp
    //     0x1196af4: ldp             fp, lr, [SP], #0x10
    // 0x1196af8: ret
    //     0x1196af8: ret             
    // 0x1196afc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1196afc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1196b00: b               #0x1196a14
  }
}

// class id: 3315, size: 0x20, field offset: 0x14
class MaterialRectArcTween extends RectTween {

  late MaterialPointArcTween _beginArc; // offset: 0x18
  late MaterialPointArcTween _endArc; // offset: 0x1c

  set _ begin=(/* No info */) {
    // ** addr: 0x1144c38, size: 0x118
    // 0x1144c38: EnterFrame
    //     0x1144c38: stp             fp, lr, [SP, #-0x10]!
    //     0x1144c3c: mov             fp, SP
    // 0x1144c40: AllocStack(0x20)
    //     0x1144c40: sub             SP, SP, #0x20
    // 0x1144c44: SetupParameters(MaterialRectArcTween this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x1144c44: mov             x4, x1
    //     0x1144c48: mov             x3, x2
    //     0x1144c4c: stur            x1, [fp, #-8]
    //     0x1144c50: stur            x2, [fp, #-0x10]
    // 0x1144c54: CheckStackOverflow
    //     0x1144c54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1144c58: cmp             SP, x16
    //     0x1144c5c: b.ls            #0x1144d48
    // 0x1144c60: mov             x0, x3
    // 0x1144c64: r2 = Null
    //     0x1144c64: mov             x2, NULL
    // 0x1144c68: r1 = Null
    //     0x1144c68: mov             x1, NULL
    // 0x1144c6c: r4 = 60
    //     0x1144c6c: mov             x4, #0x3c
    // 0x1144c70: branchIfSmi(r0, 0x1144c7c)
    //     0x1144c70: tbz             w0, #0, #0x1144c7c
    // 0x1144c74: r4 = LoadClassIdInstr(r0)
    //     0x1144c74: ldur            x4, [x0, #-1]
    //     0x1144c78: ubfx            x4, x4, #0xc, #0x14
    // 0x1144c7c: cmp             x4, #0xed8
    // 0x1144c80: b.eq            #0x1144c98
    // 0x1144c84: r8 = Rect?
    //     0x1144c84: add             x8, PP, #0x95, lsl #12  ; [pp+0x95ef8] Type: Rect?
    //     0x1144c88: ldr             x8, [x8, #0xef8]
    // 0x1144c8c: r3 = Null
    //     0x1144c8c: add             x3, PP, #0x95, lsl #12  ; [pp+0x95f20] Null
    //     0x1144c90: ldr             x3, [x3, #0xf20]
    // 0x1144c94: r0 = Rect?()
    //     0x1144c94: bl              #0x86126c  ; IsType_Rect?_Stub
    // 0x1144c98: ldur            x1, [fp, #-8]
    // 0x1144c9c: LoadField: r0 = r1->field_b
    //     0x1144c9c: ldur            w0, [x1, #0xb]
    // 0x1144ca0: DecompressPointer r0
    //     0x1144ca0: add             x0, x0, HEAP, lsl #32
    // 0x1144ca4: ldur            x2, [fp, #-0x10]
    // 0x1144ca8: r3 = LoadClassIdInstr(r2)
    //     0x1144ca8: ldur            x3, [x2, #-1]
    //     0x1144cac: ubfx            x3, x3, #0xc, #0x14
    // 0x1144cb0: stp             x0, x2, [SP]
    // 0x1144cb4: mov             x0, x3
    // 0x1144cb8: mov             lr, x0
    // 0x1144cbc: ldr             lr, [x21, lr, lsl #3]
    // 0x1144cc0: blr             lr
    // 0x1144cc4: tbz             w0, #4, #0x1144d38
    // 0x1144cc8: ldur            x3, [fp, #-8]
    // 0x1144ccc: LoadField: r2 = r3->field_7
    //     0x1144ccc: ldur            w2, [x3, #7]
    // 0x1144cd0: DecompressPointer r2
    //     0x1144cd0: add             x2, x2, HEAP, lsl #32
    // 0x1144cd4: ldur            x0, [fp, #-0x10]
    // 0x1144cd8: r1 = Null
    //     0x1144cd8: mov             x1, NULL
    // 0x1144cdc: cmp             w0, NULL
    // 0x1144ce0: b.eq            #0x1144d08
    // 0x1144ce4: cmp             w2, NULL
    // 0x1144ce8: b.eq            #0x1144d08
    // 0x1144cec: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x1144cec: ldur            w4, [x2, #0x17]
    // 0x1144cf0: DecompressPointer r4
    //     0x1144cf0: add             x4, x4, HEAP, lsl #32
    // 0x1144cf4: r8 = X0?
    //     0x1144cf4: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0x1144cf8: LoadField: r9 = r4->field_7
    //     0x1144cf8: ldur            x9, [x4, #7]
    // 0x1144cfc: r3 = Null
    //     0x1144cfc: add             x3, PP, #0x95, lsl #12  ; [pp+0x95f30] Null
    //     0x1144d00: ldr             x3, [x3, #0xf30]
    // 0x1144d04: blr             x9
    // 0x1144d08: ldur            x0, [fp, #-0x10]
    // 0x1144d0c: ldur            x1, [fp, #-8]
    // 0x1144d10: StoreField: r1->field_b = r0
    //     0x1144d10: stur            w0, [x1, #0xb]
    //     0x1144d14: tbz             w0, #0, #0x1144d30
    //     0x1144d18: ldurb           w16, [x1, #-1]
    //     0x1144d1c: ldurb           w17, [x0, #-1]
    //     0x1144d20: and             x16, x17, x16, lsr #2
    //     0x1144d24: tst             x16, HEAP, lsr #32
    //     0x1144d28: b.eq            #0x1144d30
    //     0x1144d2c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1144d30: r2 = true
    //     0x1144d30: add             x2, NULL, #0x20  ; true
    // 0x1144d34: StoreField: r1->field_13 = r2
    //     0x1144d34: stur            w2, [x1, #0x13]
    // 0x1144d38: r0 = Null
    //     0x1144d38: mov             x0, NULL
    // 0x1144d3c: LeaveFrame
    //     0x1144d3c: mov             SP, fp
    //     0x1144d40: ldp             fp, lr, [SP], #0x10
    // 0x1144d44: ret
    //     0x1144d44: ret             
    // 0x1144d48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1144d48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1144d4c: b               #0x1144c60
  }
  _ lerp(/* No info */) {
    // ** addr: 0x115caf0, size: 0x134
    // 0x115caf0: EnterFrame
    //     0x115caf0: stp             fp, lr, [SP, #-0x10]!
    //     0x115caf4: mov             fp, SP
    // 0x115caf8: AllocStack(0x18)
    //     0x115caf8: sub             SP, SP, #0x18
    // 0x115cafc: SetupParameters(MaterialRectArcTween this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x18 */)
    //     0x115cafc: mov             x0, x1
    //     0x115cb00: stur            x1, [fp, #-8]
    //     0x115cb04: stur            d0, [fp, #-0x18]
    // 0x115cb08: CheckStackOverflow
    //     0x115cb08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115cb0c: cmp             SP, x16
    //     0x115cb10: b.ls            #0x115cbfc
    // 0x115cb14: LoadField: r1 = r0->field_13
    //     0x115cb14: ldur            w1, [x0, #0x13]
    // 0x115cb18: DecompressPointer r1
    //     0x115cb18: add             x1, x1, HEAP, lsl #32
    // 0x115cb1c: tbnz            w1, #4, #0x115cb28
    // 0x115cb20: mov             x1, x0
    // 0x115cb24: r0 = _initialize()
    //     0x115cb24: bl              #0x115cc24  ; [package:flutter/src/material/arc.dart] MaterialRectArcTween::_initialize
    // 0x115cb28: ldur            d1, [fp, #-0x18]
    // 0x115cb2c: d0 = 0.000000
    //     0x115cb2c: eor             v0.16b, v0.16b, v0.16b
    // 0x115cb30: fcmp            d1, d0
    // 0x115cb34: b.ne            #0x115cb5c
    // 0x115cb38: ldur            x0, [fp, #-8]
    // 0x115cb3c: LoadField: r1 = r0->field_b
    //     0x115cb3c: ldur            w1, [x0, #0xb]
    // 0x115cb40: DecompressPointer r1
    //     0x115cb40: add             x1, x1, HEAP, lsl #32
    // 0x115cb44: cmp             w1, NULL
    // 0x115cb48: b.eq            #0x115cc04
    // 0x115cb4c: mov             x0, x1
    // 0x115cb50: LeaveFrame
    //     0x115cb50: mov             SP, fp
    //     0x115cb54: ldp             fp, lr, [SP], #0x10
    // 0x115cb58: ret
    //     0x115cb58: ret             
    // 0x115cb5c: ldur            x0, [fp, #-8]
    // 0x115cb60: d0 = 1.000000
    //     0x115cb60: fmov            d0, #1.00000000
    // 0x115cb64: fcmp            d1, d0
    // 0x115cb68: b.ne            #0x115cb8c
    // 0x115cb6c: LoadField: r1 = r0->field_f
    //     0x115cb6c: ldur            w1, [x0, #0xf]
    // 0x115cb70: DecompressPointer r1
    //     0x115cb70: add             x1, x1, HEAP, lsl #32
    // 0x115cb74: cmp             w1, NULL
    // 0x115cb78: b.eq            #0x115cc08
    // 0x115cb7c: mov             x0, x1
    // 0x115cb80: LeaveFrame
    //     0x115cb80: mov             SP, fp
    //     0x115cb84: ldp             fp, lr, [SP], #0x10
    // 0x115cb88: ret
    //     0x115cb88: ret             
    // 0x115cb8c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x115cb8c: ldur            w1, [x0, #0x17]
    // 0x115cb90: DecompressPointer r1
    //     0x115cb90: add             x1, x1, HEAP, lsl #32
    // 0x115cb94: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x115cb98: cmp             w1, w16
    // 0x115cb9c: b.eq            #0x115cc0c
    // 0x115cba0: mov             v0.16b, v1.16b
    // 0x115cba4: r0 = lerp()
    //     0x115cba4: bl              #0x115d3a0  ; [package:flutter/src/material/arc.dart] MaterialPointArcTween::lerp
    // 0x115cba8: mov             x2, x0
    // 0x115cbac: ldur            x0, [fp, #-8]
    // 0x115cbb0: stur            x2, [fp, #-0x10]
    // 0x115cbb4: LoadField: r1 = r0->field_1b
    //     0x115cbb4: ldur            w1, [x0, #0x1b]
    // 0x115cbb8: DecompressPointer r1
    //     0x115cbb8: add             x1, x1, HEAP, lsl #32
    // 0x115cbbc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x115cbc0: cmp             w1, w16
    // 0x115cbc4: b.eq            #0x115cc18
    // 0x115cbc8: ldur            d0, [fp, #-0x18]
    // 0x115cbcc: r0 = lerp()
    //     0x115cbcc: bl              #0x115d3a0  ; [package:flutter/src/material/arc.dart] MaterialPointArcTween::lerp
    // 0x115cbd0: stur            x0, [fp, #-8]
    // 0x115cbd4: r0 = Rect()
    //     0x115cbd4: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x115cbd8: mov             x1, x0
    // 0x115cbdc: ldur            x2, [fp, #-0x10]
    // 0x115cbe0: ldur            x3, [fp, #-8]
    // 0x115cbe4: stur            x0, [fp, #-8]
    // 0x115cbe8: r0 = Rect.fromPoints()
    //     0x115cbe8: bl              #0x858780  ; [dart:ui] Rect::Rect.fromPoints
    // 0x115cbec: ldur            x0, [fp, #-8]
    // 0x115cbf0: LeaveFrame
    //     0x115cbf0: mov             SP, fp
    //     0x115cbf4: ldp             fp, lr, [SP], #0x10
    // 0x115cbf8: ret
    //     0x115cbf8: ret             
    // 0x115cbfc: r0 = StackOverflowSharedWithFPURegs()
    //     0x115cbfc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x115cc00: b               #0x115cb14
    // 0x115cc04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115cc04: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x115cc08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115cc08: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x115cc0c: r9 = _beginArc
    //     0x115cc0c: add             x9, PP, #0x95, lsl #12  ; [pp+0x95eb0] Field <MaterialRectArcTween._beginArc@719458455>: late (offset: 0x18)
    //     0x115cc10: ldr             x9, [x9, #0xeb0]
    // 0x115cc14: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x115cc14: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x115cc18: r9 = _endArc
    //     0x115cc18: add             x9, PP, #0x95, lsl #12  ; [pp+0x95eb8] Field <MaterialRectArcTween._endArc@719458455>: late (offset: 0x1c)
    //     0x115cc1c: ldr             x9, [x9, #0xeb8]
    // 0x115cc20: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x115cc20: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _initialize(/* No info */) {
    // ** addr: 0x115cc24, size: 0x22c
    // 0x115cc24: EnterFrame
    //     0x115cc24: stp             fp, lr, [SP, #-0x10]!
    //     0x115cc28: mov             fp, SP
    // 0x115cc2c: AllocStack(0x30)
    //     0x115cc2c: sub             SP, SP, #0x30
    // 0x115cc30: SetupParameters(MaterialRectArcTween this /* r1 => r1, fp-0x8 */)
    //     0x115cc30: stur            x1, [fp, #-8]
    // 0x115cc34: CheckStackOverflow
    //     0x115cc34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115cc38: cmp             SP, x16
    //     0x115cc3c: b.ls            #0x115ce30
    // 0x115cc40: r1 = 2
    //     0x115cc40: mov             x1, #2
    // 0x115cc44: r0 = AllocateContext()
    //     0x115cc44: bl              #0x13de838  ; AllocateContextStub
    // 0x115cc48: mov             x2, x0
    // 0x115cc4c: ldur            x0, [fp, #-8]
    // 0x115cc50: stur            x2, [fp, #-0x10]
    // 0x115cc54: StoreField: r2->field_f = r0
    //     0x115cc54: stur            w0, [x2, #0xf]
    // 0x115cc58: LoadField: r1 = r0->field_f
    //     0x115cc58: ldur            w1, [x0, #0xf]
    // 0x115cc5c: DecompressPointer r1
    //     0x115cc5c: add             x1, x1, HEAP, lsl #32
    // 0x115cc60: cmp             w1, NULL
    // 0x115cc64: b.eq            #0x115ce38
    // 0x115cc68: r0 = center()
    //     0x115cc68: bl              #0x869350  ; [dart:ui] Rect::center
    // 0x115cc6c: mov             x2, x0
    // 0x115cc70: ldur            x0, [fp, #-8]
    // 0x115cc74: stur            x2, [fp, #-0x18]
    // 0x115cc78: LoadField: r1 = r0->field_b
    //     0x115cc78: ldur            w1, [x0, #0xb]
    // 0x115cc7c: DecompressPointer r1
    //     0x115cc7c: add             x1, x1, HEAP, lsl #32
    // 0x115cc80: cmp             w1, NULL
    // 0x115cc84: b.eq            #0x115ce3c
    // 0x115cc88: r0 = center()
    //     0x115cc88: bl              #0x869350  ; [dart:ui] Rect::center
    // 0x115cc8c: ldur            x1, [fp, #-0x18]
    // 0x115cc90: mov             x2, x0
    // 0x115cc94: r0 = -()
    //     0x115cc94: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x115cc98: ldur            x2, [fp, #-0x10]
    // 0x115cc9c: StoreField: r2->field_13 = r0
    //     0x115cc9c: stur            w0, [x2, #0x13]
    //     0x115cca0: ldurb           w16, [x2, #-1]
    //     0x115cca4: ldurb           w17, [x0, #-1]
    //     0x115cca8: and             x16, x17, x16, lsr #2
    //     0x115ccac: tst             x16, HEAP, lsr #32
    //     0x115ccb0: b.eq            #0x115ccb8
    //     0x115ccb4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x115ccb8: r1 = Function '<anonymous closure>':.
    //     0x115ccb8: add             x1, PP, #0x95, lsl #12  ; [pp+0x95ee0] AnonymousClosure: (0x115d028), in [package:flutter/src/material/arc.dart] MaterialRectArcTween::_initialize (0x115cc24)
    //     0x115ccbc: ldr             x1, [x1, #0xee0]
    // 0x115ccc0: r0 = AllocateClosure()
    //     0x115ccc0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x115ccc4: r16 = <_Diagonal>
    //     0x115ccc4: add             x16, PP, #0x95, lsl #12  ; [pp+0x95ee8] TypeArguments: <_Diagonal>
    //     0x115ccc8: ldr             x16, [x16, #0xee8]
    // 0x115cccc: stp             x0, x16, [SP]
    // 0x115ccd0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x115ccd0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x115ccd4: r0 = _maxBy()
    //     0x115ccd4: bl              #0x115cf2c  ; [package:flutter/src/material/arc.dart] ::_maxBy
    // 0x115ccd8: mov             x4, x0
    // 0x115ccdc: ldur            x0, [fp, #-8]
    // 0x115cce0: stur            x4, [fp, #-0x18]
    // 0x115cce4: LoadField: r2 = r0->field_b
    //     0x115cce4: ldur            w2, [x0, #0xb]
    // 0x115cce8: DecompressPointer r2
    //     0x115cce8: add             x2, x2, HEAP, lsl #32
    // 0x115ccec: cmp             w2, NULL
    // 0x115ccf0: b.eq            #0x115ce40
    // 0x115ccf4: LoadField: r5 = r4->field_7
    //     0x115ccf4: ldur            w5, [x4, #7]
    // 0x115ccf8: DecompressPointer r5
    //     0x115ccf8: add             x5, x5, HEAP, lsl #32
    // 0x115ccfc: mov             x1, x0
    // 0x115cd00: mov             x3, x5
    // 0x115cd04: stur            x5, [fp, #-0x10]
    // 0x115cd08: r0 = _cornerFor()
    //     0x115cd08: bl              #0x115ce5c  ; [package:flutter/src/material/arc.dart] MaterialRectArcTween::_cornerFor
    // 0x115cd0c: mov             x4, x0
    // 0x115cd10: ldur            x0, [fp, #-8]
    // 0x115cd14: stur            x4, [fp, #-0x20]
    // 0x115cd18: LoadField: r2 = r0->field_f
    //     0x115cd18: ldur            w2, [x0, #0xf]
    // 0x115cd1c: DecompressPointer r2
    //     0x115cd1c: add             x2, x2, HEAP, lsl #32
    // 0x115cd20: cmp             w2, NULL
    // 0x115cd24: b.eq            #0x115ce44
    // 0x115cd28: mov             x1, x0
    // 0x115cd2c: ldur            x3, [fp, #-0x10]
    // 0x115cd30: r0 = _cornerFor()
    //     0x115cd30: bl              #0x115ce5c  ; [package:flutter/src/material/arc.dart] MaterialRectArcTween::_cornerFor
    // 0x115cd34: r1 = <Offset>
    //     0x115cd34: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a48] TypeArguments: <Offset>
    //     0x115cd38: ldr             x1, [x1, #0xa48]
    // 0x115cd3c: stur            x0, [fp, #-0x10]
    // 0x115cd40: r0 = MaterialPointArcTween()
    //     0x115cd40: bl              #0x115ce50  ; AllocateMaterialPointArcTweenStub -> MaterialPointArcTween (size=0x28)
    // 0x115cd44: r4 = true
    //     0x115cd44: add             x4, NULL, #0x20  ; true
    // 0x115cd48: StoreField: r0->field_13 = r4
    //     0x115cd48: stur            w4, [x0, #0x13]
    // 0x115cd4c: ldur            x1, [fp, #-0x20]
    // 0x115cd50: StoreField: r0->field_b = r1
    //     0x115cd50: stur            w1, [x0, #0xb]
    // 0x115cd54: ldur            x1, [fp, #-0x10]
    // 0x115cd58: StoreField: r0->field_f = r1
    //     0x115cd58: stur            w1, [x0, #0xf]
    // 0x115cd5c: ldur            x5, [fp, #-8]
    // 0x115cd60: ArrayStore: r5[0] = r0  ; List_4
    //     0x115cd60: stur            w0, [x5, #0x17]
    //     0x115cd64: ldurb           w16, [x5, #-1]
    //     0x115cd68: ldurb           w17, [x0, #-1]
    //     0x115cd6c: and             x16, x17, x16, lsr #2
    //     0x115cd70: tst             x16, HEAP, lsr #32
    //     0x115cd74: b.eq            #0x115cd7c
    //     0x115cd78: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0x115cd7c: LoadField: r2 = r5->field_b
    //     0x115cd7c: ldur            w2, [x5, #0xb]
    // 0x115cd80: DecompressPointer r2
    //     0x115cd80: add             x2, x2, HEAP, lsl #32
    // 0x115cd84: cmp             w2, NULL
    // 0x115cd88: b.eq            #0x115ce48
    // 0x115cd8c: ldur            x0, [fp, #-0x18]
    // 0x115cd90: LoadField: r6 = r0->field_b
    //     0x115cd90: ldur            w6, [x0, #0xb]
    // 0x115cd94: DecompressPointer r6
    //     0x115cd94: add             x6, x6, HEAP, lsl #32
    // 0x115cd98: mov             x1, x5
    // 0x115cd9c: mov             x3, x6
    // 0x115cda0: stur            x6, [fp, #-0x10]
    // 0x115cda4: r0 = _cornerFor()
    //     0x115cda4: bl              #0x115ce5c  ; [package:flutter/src/material/arc.dart] MaterialRectArcTween::_cornerFor
    // 0x115cda8: mov             x4, x0
    // 0x115cdac: ldur            x0, [fp, #-8]
    // 0x115cdb0: stur            x4, [fp, #-0x18]
    // 0x115cdb4: LoadField: r2 = r0->field_f
    //     0x115cdb4: ldur            w2, [x0, #0xf]
    // 0x115cdb8: DecompressPointer r2
    //     0x115cdb8: add             x2, x2, HEAP, lsl #32
    // 0x115cdbc: cmp             w2, NULL
    // 0x115cdc0: b.eq            #0x115ce4c
    // 0x115cdc4: mov             x1, x0
    // 0x115cdc8: ldur            x3, [fp, #-0x10]
    // 0x115cdcc: r0 = _cornerFor()
    //     0x115cdcc: bl              #0x115ce5c  ; [package:flutter/src/material/arc.dart] MaterialRectArcTween::_cornerFor
    // 0x115cdd0: r1 = <Offset>
    //     0x115cdd0: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a48] TypeArguments: <Offset>
    //     0x115cdd4: ldr             x1, [x1, #0xa48]
    // 0x115cdd8: stur            x0, [fp, #-0x10]
    // 0x115cddc: r0 = MaterialPointArcTween()
    //     0x115cddc: bl              #0x115ce50  ; AllocateMaterialPointArcTweenStub -> MaterialPointArcTween (size=0x28)
    // 0x115cde0: r1 = true
    //     0x115cde0: add             x1, NULL, #0x20  ; true
    // 0x115cde4: StoreField: r0->field_13 = r1
    //     0x115cde4: stur            w1, [x0, #0x13]
    // 0x115cde8: ldur            x1, [fp, #-0x18]
    // 0x115cdec: StoreField: r0->field_b = r1
    //     0x115cdec: stur            w1, [x0, #0xb]
    // 0x115cdf0: ldur            x1, [fp, #-0x10]
    // 0x115cdf4: StoreField: r0->field_f = r1
    //     0x115cdf4: stur            w1, [x0, #0xf]
    // 0x115cdf8: ldur            x1, [fp, #-8]
    // 0x115cdfc: StoreField: r1->field_1b = r0
    //     0x115cdfc: stur            w0, [x1, #0x1b]
    //     0x115ce00: ldurb           w16, [x1, #-1]
    //     0x115ce04: ldurb           w17, [x0, #-1]
    //     0x115ce08: and             x16, x17, x16, lsr #2
    //     0x115ce0c: tst             x16, HEAP, lsr #32
    //     0x115ce10: b.eq            #0x115ce18
    //     0x115ce14: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x115ce18: r2 = false
    //     0x115ce18: add             x2, NULL, #0x30  ; false
    // 0x115ce1c: StoreField: r1->field_13 = r2
    //     0x115ce1c: stur            w2, [x1, #0x13]
    // 0x115ce20: r0 = Null
    //     0x115ce20: mov             x0, NULL
    // 0x115ce24: LeaveFrame
    //     0x115ce24: mov             SP, fp
    //     0x115ce28: ldp             fp, lr, [SP], #0x10
    // 0x115ce2c: ret
    //     0x115ce2c: ret             
    // 0x115ce30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x115ce30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x115ce34: b               #0x115cc40
    // 0x115ce38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115ce38: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x115ce3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115ce3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x115ce40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115ce40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x115ce44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115ce44: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x115ce48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115ce48: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x115ce4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115ce4c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _cornerFor(/* No info */) {
    // ** addr: 0x115ce5c, size: 0xd0
    // 0x115ce5c: EnterFrame
    //     0x115ce5c: stp             fp, lr, [SP, #-0x10]!
    //     0x115ce60: mov             fp, SP
    // 0x115ce64: AllocStack(0x10)
    //     0x115ce64: sub             SP, SP, #0x10
    // 0x115ce68: LoadField: r0 = r3->field_7
    //     0x115ce68: ldur            x0, [x3, #7]
    // 0x115ce6c: cmp             x0, #1
    // 0x115ce70: b.gt            #0x115cecc
    // 0x115ce74: cmp             x0, #0
    // 0x115ce78: b.gt            #0x115cea4
    // 0x115ce7c: LoadField: d0 = r2->field_7
    //     0x115ce7c: ldur            d0, [x2, #7]
    // 0x115ce80: stur            d0, [fp, #-0x10]
    // 0x115ce84: LoadField: d1 = r2->field_f
    //     0x115ce84: ldur            d1, [x2, #0xf]
    // 0x115ce88: stur            d1, [fp, #-8]
    // 0x115ce8c: r0 = Offset()
    //     0x115ce8c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x115ce90: ldur            d0, [fp, #-0x10]
    // 0x115ce94: StoreField: r0->field_7 = d0
    //     0x115ce94: stur            d0, [x0, #7]
    // 0x115ce98: ldur            d0, [fp, #-8]
    // 0x115ce9c: StoreField: r0->field_f = d0
    //     0x115ce9c: stur            d0, [x0, #0xf]
    // 0x115cea0: b               #0x115cf20
    // 0x115cea4: ArrayLoad: d0 = r2[0]  ; List_8
    //     0x115cea4: ldur            d0, [x2, #0x17]
    // 0x115cea8: stur            d0, [fp, #-0x10]
    // 0x115ceac: LoadField: d1 = r2->field_f
    //     0x115ceac: ldur            d1, [x2, #0xf]
    // 0x115ceb0: stur            d1, [fp, #-8]
    // 0x115ceb4: r0 = Offset()
    //     0x115ceb4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x115ceb8: ldur            d0, [fp, #-0x10]
    // 0x115cebc: StoreField: r0->field_7 = d0
    //     0x115cebc: stur            d0, [x0, #7]
    // 0x115cec0: ldur            d0, [fp, #-8]
    // 0x115cec4: StoreField: r0->field_f = d0
    //     0x115cec4: stur            d0, [x0, #0xf]
    // 0x115cec8: b               #0x115cf20
    // 0x115cecc: cmp             x0, #2
    // 0x115ced0: b.gt            #0x115cefc
    // 0x115ced4: LoadField: d0 = r2->field_7
    //     0x115ced4: ldur            d0, [x2, #7]
    // 0x115ced8: stur            d0, [fp, #-0x10]
    // 0x115cedc: LoadField: d1 = r2->field_1f
    //     0x115cedc: ldur            d1, [x2, #0x1f]
    // 0x115cee0: stur            d1, [fp, #-8]
    // 0x115cee4: r0 = Offset()
    //     0x115cee4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x115cee8: ldur            d0, [fp, #-0x10]
    // 0x115ceec: StoreField: r0->field_7 = d0
    //     0x115ceec: stur            d0, [x0, #7]
    // 0x115cef0: ldur            d0, [fp, #-8]
    // 0x115cef4: StoreField: r0->field_f = d0
    //     0x115cef4: stur            d0, [x0, #0xf]
    // 0x115cef8: b               #0x115cf20
    // 0x115cefc: ArrayLoad: d0 = r2[0]  ; List_8
    //     0x115cefc: ldur            d0, [x2, #0x17]
    // 0x115cf00: stur            d0, [fp, #-0x10]
    // 0x115cf04: LoadField: d1 = r2->field_1f
    //     0x115cf04: ldur            d1, [x2, #0x1f]
    // 0x115cf08: stur            d1, [fp, #-8]
    // 0x115cf0c: r0 = Offset()
    //     0x115cf0c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x115cf10: ldur            d0, [fp, #-0x10]
    // 0x115cf14: StoreField: r0->field_7 = d0
    //     0x115cf14: stur            d0, [x0, #7]
    // 0x115cf18: ldur            d0, [fp, #-8]
    // 0x115cf1c: StoreField: r0->field_f = d0
    //     0x115cf1c: stur            d0, [x0, #0xf]
    // 0x115cf20: LeaveFrame
    //     0x115cf20: mov             SP, fp
    //     0x115cf24: ldp             fp, lr, [SP], #0x10
    // 0x115cf28: ret
    //     0x115cf28: ret             
  }
  [closure] double <anonymous closure>(dynamic, _Diagonal) {
    // ** addr: 0x115d028, size: 0x8c
    // 0x115d028: EnterFrame
    //     0x115d028: stp             fp, lr, [SP, #-0x10]!
    //     0x115d02c: mov             fp, SP
    // 0x115d030: ldr             x0, [fp, #0x18]
    // 0x115d034: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x115d034: ldur            w1, [x0, #0x17]
    // 0x115d038: DecompressPointer r1
    //     0x115d038: add             x1, x1, HEAP, lsl #32
    // 0x115d03c: CheckStackOverflow
    //     0x115d03c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115d040: cmp             SP, x16
    //     0x115d044: b.ls            #0x115d09c
    // 0x115d048: LoadField: r0 = r1->field_f
    //     0x115d048: ldur            w0, [x1, #0xf]
    // 0x115d04c: DecompressPointer r0
    //     0x115d04c: add             x0, x0, HEAP, lsl #32
    // 0x115d050: LoadField: r2 = r1->field_13
    //     0x115d050: ldur            w2, [x1, #0x13]
    // 0x115d054: DecompressPointer r2
    //     0x115d054: add             x2, x2, HEAP, lsl #32
    // 0x115d058: mov             x1, x0
    // 0x115d05c: ldr             x3, [fp, #0x10]
    // 0x115d060: r0 = _diagonalSupport()
    //     0x115d060: bl              #0x115d0b4  ; [package:flutter/src/material/arc.dart] MaterialRectArcTween::_diagonalSupport
    // 0x115d064: r0 = inline_Allocate_Double()
    //     0x115d064: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x115d068: add             x0, x0, #0x10
    //     0x115d06c: cmp             x1, x0
    //     0x115d070: b.ls            #0x115d0a4
    //     0x115d074: str             x0, [THR, #0x60]  ; THR::top
    //     0x115d078: sub             x0, x0, #0xf
    //     0x115d07c: mov             x1, #0xe19c
    //     0x115d080: movk            x1, #3, lsl #16
    //     0x115d084: stur            x1, [x0, #-1]
    // 0x115d088: dmb             ishst
    // 0x115d08c: StoreField: r0->field_7 = d0
    //     0x115d08c: stur            d0, [x0, #7]
    // 0x115d090: LeaveFrame
    //     0x115d090: mov             SP, fp
    //     0x115d094: ldp             fp, lr, [SP], #0x10
    // 0x115d098: ret
    //     0x115d098: ret             
    // 0x115d09c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x115d09c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x115d0a0: b               #0x115d048
    // 0x115d0a4: SaveReg d0
    //     0x115d0a4: str             q0, [SP, #-0x10]!
    // 0x115d0a8: r0 = AllocateDouble()
    //     0x115d0a8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x115d0ac: RestoreReg d0
    //     0x115d0ac: ldr             q0, [SP], #0x10
    // 0x115d0b0: b               #0x115d08c
  }
  _ _diagonalSupport(/* No info */) {
    // ** addr: 0x115d0b4, size: 0xdc
    // 0x115d0b4: EnterFrame
    //     0x115d0b4: stp             fp, lr, [SP, #-0x10]!
    //     0x115d0b8: mov             fp, SP
    // 0x115d0bc: AllocStack(0x20)
    //     0x115d0bc: sub             SP, SP, #0x20
    // 0x115d0c0: SetupParameters(MaterialRectArcTween this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0x115d0c0: mov             x5, x1
    //     0x115d0c4: mov             x4, x2
    //     0x115d0c8: mov             x0, x3
    //     0x115d0cc: stur            x1, [fp, #-8]
    //     0x115d0d0: stur            x2, [fp, #-0x10]
    //     0x115d0d4: stur            x3, [fp, #-0x18]
    // 0x115d0d8: CheckStackOverflow
    //     0x115d0d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115d0dc: cmp             SP, x16
    //     0x115d0e0: b.ls            #0x115d180
    // 0x115d0e4: LoadField: r2 = r5->field_b
    //     0x115d0e4: ldur            w2, [x5, #0xb]
    // 0x115d0e8: DecompressPointer r2
    //     0x115d0e8: add             x2, x2, HEAP, lsl #32
    // 0x115d0ec: cmp             w2, NULL
    // 0x115d0f0: b.eq            #0x115d188
    // 0x115d0f4: LoadField: r3 = r0->field_b
    //     0x115d0f4: ldur            w3, [x0, #0xb]
    // 0x115d0f8: DecompressPointer r3
    //     0x115d0f8: add             x3, x3, HEAP, lsl #32
    // 0x115d0fc: mov             x1, x5
    // 0x115d100: r0 = _cornerFor()
    //     0x115d100: bl              #0x115ce5c  ; [package:flutter/src/material/arc.dart] MaterialRectArcTween::_cornerFor
    // 0x115d104: ldur            x1, [fp, #-8]
    // 0x115d108: stur            x0, [fp, #-0x20]
    // 0x115d10c: LoadField: r2 = r1->field_b
    //     0x115d10c: ldur            w2, [x1, #0xb]
    // 0x115d110: DecompressPointer r2
    //     0x115d110: add             x2, x2, HEAP, lsl #32
    // 0x115d114: cmp             w2, NULL
    // 0x115d118: b.eq            #0x115d18c
    // 0x115d11c: ldur            x3, [fp, #-0x18]
    // 0x115d120: LoadField: r4 = r3->field_7
    //     0x115d120: ldur            w4, [x3, #7]
    // 0x115d124: DecompressPointer r4
    //     0x115d124: add             x4, x4, HEAP, lsl #32
    // 0x115d128: mov             x3, x4
    // 0x115d12c: r0 = _cornerFor()
    //     0x115d12c: bl              #0x115ce5c  ; [package:flutter/src/material/arc.dart] MaterialRectArcTween::_cornerFor
    // 0x115d130: ldur            x1, [fp, #-0x20]
    // 0x115d134: mov             x2, x0
    // 0x115d138: r0 = -()
    //     0x115d138: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x115d13c: LoadField: d1 = r0->field_7
    //     0x115d13c: ldur            d1, [x0, #7]
    // 0x115d140: fmul            d2, d1, d1
    // 0x115d144: LoadField: d3 = r0->field_f
    //     0x115d144: ldur            d3, [x0, #0xf]
    // 0x115d148: fmul            d4, d3, d3
    // 0x115d14c: fadd            d5, d2, d4
    // 0x115d150: fsqrt           d2, d5
    // 0x115d154: ldur            x0, [fp, #-0x10]
    // 0x115d158: LoadField: d4 = r0->field_7
    //     0x115d158: ldur            d4, [x0, #7]
    // 0x115d15c: fmul            d5, d4, d1
    // 0x115d160: fdiv            d1, d5, d2
    // 0x115d164: LoadField: d4 = r0->field_f
    //     0x115d164: ldur            d4, [x0, #0xf]
    // 0x115d168: fmul            d5, d4, d3
    // 0x115d16c: fdiv            d3, d5, d2
    // 0x115d170: fadd            d0, d1, d3
    // 0x115d174: LeaveFrame
    //     0x115d174: mov             SP, fp
    //     0x115d178: ldp             fp, lr, [SP], #0x10
    // 0x115d17c: ret
    //     0x115d17c: ret             
    // 0x115d180: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x115d180: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x115d184: b               #0x115d0e4
    // 0x115d188: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115d188: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x115d18c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115d18c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ end=(/* No info */) {
    // ** addr: 0x11968d4, size: 0x118
    // 0x11968d4: EnterFrame
    //     0x11968d4: stp             fp, lr, [SP, #-0x10]!
    //     0x11968d8: mov             fp, SP
    // 0x11968dc: AllocStack(0x20)
    //     0x11968dc: sub             SP, SP, #0x20
    // 0x11968e0: SetupParameters(MaterialRectArcTween this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x11968e0: mov             x4, x1
    //     0x11968e4: mov             x3, x2
    //     0x11968e8: stur            x1, [fp, #-8]
    //     0x11968ec: stur            x2, [fp, #-0x10]
    // 0x11968f0: CheckStackOverflow
    //     0x11968f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11968f4: cmp             SP, x16
    //     0x11968f8: b.ls            #0x11969e4
    // 0x11968fc: mov             x0, x3
    // 0x1196900: r2 = Null
    //     0x1196900: mov             x2, NULL
    // 0x1196904: r1 = Null
    //     0x1196904: mov             x1, NULL
    // 0x1196908: r4 = 60
    //     0x1196908: mov             x4, #0x3c
    // 0x119690c: branchIfSmi(r0, 0x1196918)
    //     0x119690c: tbz             w0, #0, #0x1196918
    // 0x1196910: r4 = LoadClassIdInstr(r0)
    //     0x1196910: ldur            x4, [x0, #-1]
    //     0x1196914: ubfx            x4, x4, #0xc, #0x14
    // 0x1196918: cmp             x4, #0xed8
    // 0x119691c: b.eq            #0x1196934
    // 0x1196920: r8 = Rect?
    //     0x1196920: add             x8, PP, #0x95, lsl #12  ; [pp+0x95ef8] Type: Rect?
    //     0x1196924: ldr             x8, [x8, #0xef8]
    // 0x1196928: r3 = Null
    //     0x1196928: add             x3, PP, #0x95, lsl #12  ; [pp+0x95f00] Null
    //     0x119692c: ldr             x3, [x3, #0xf00]
    // 0x1196930: r0 = Rect?()
    //     0x1196930: bl              #0x86126c  ; IsType_Rect?_Stub
    // 0x1196934: ldur            x1, [fp, #-8]
    // 0x1196938: LoadField: r0 = r1->field_f
    //     0x1196938: ldur            w0, [x1, #0xf]
    // 0x119693c: DecompressPointer r0
    //     0x119693c: add             x0, x0, HEAP, lsl #32
    // 0x1196940: ldur            x2, [fp, #-0x10]
    // 0x1196944: r3 = LoadClassIdInstr(r2)
    //     0x1196944: ldur            x3, [x2, #-1]
    //     0x1196948: ubfx            x3, x3, #0xc, #0x14
    // 0x119694c: stp             x0, x2, [SP]
    // 0x1196950: mov             x0, x3
    // 0x1196954: mov             lr, x0
    // 0x1196958: ldr             lr, [x21, lr, lsl #3]
    // 0x119695c: blr             lr
    // 0x1196960: tbz             w0, #4, #0x11969d4
    // 0x1196964: ldur            x3, [fp, #-8]
    // 0x1196968: LoadField: r2 = r3->field_7
    //     0x1196968: ldur            w2, [x3, #7]
    // 0x119696c: DecompressPointer r2
    //     0x119696c: add             x2, x2, HEAP, lsl #32
    // 0x1196970: ldur            x0, [fp, #-0x10]
    // 0x1196974: r1 = Null
    //     0x1196974: mov             x1, NULL
    // 0x1196978: cmp             w0, NULL
    // 0x119697c: b.eq            #0x11969a4
    // 0x1196980: cmp             w2, NULL
    // 0x1196984: b.eq            #0x11969a4
    // 0x1196988: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x1196988: ldur            w4, [x2, #0x17]
    // 0x119698c: DecompressPointer r4
    //     0x119698c: add             x4, x4, HEAP, lsl #32
    // 0x1196990: r8 = X0?
    //     0x1196990: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0x1196994: LoadField: r9 = r4->field_7
    //     0x1196994: ldur            x9, [x4, #7]
    // 0x1196998: r3 = Null
    //     0x1196998: add             x3, PP, #0x95, lsl #12  ; [pp+0x95f10] Null
    //     0x119699c: ldr             x3, [x3, #0xf10]
    // 0x11969a0: blr             x9
    // 0x11969a4: ldur            x0, [fp, #-0x10]
    // 0x11969a8: ldur            x1, [fp, #-8]
    // 0x11969ac: StoreField: r1->field_f = r0
    //     0x11969ac: stur            w0, [x1, #0xf]
    //     0x11969b0: tbz             w0, #0, #0x11969cc
    //     0x11969b4: ldurb           w16, [x1, #-1]
    //     0x11969b8: ldurb           w17, [x0, #-1]
    //     0x11969bc: and             x16, x17, x16, lsr #2
    //     0x11969c0: tst             x16, HEAP, lsr #32
    //     0x11969c4: b.eq            #0x11969cc
    //     0x11969c8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11969cc: r2 = true
    //     0x11969cc: add             x2, NULL, #0x20  ; true
    // 0x11969d0: StoreField: r1->field_13 = r2
    //     0x11969d0: stur            w2, [x1, #0x13]
    // 0x11969d4: r0 = Null
    //     0x11969d4: mov             x0, NULL
    // 0x11969d8: LeaveFrame
    //     0x11969d8: mov             SP, fp
    //     0x11969dc: ldp             fp, lr, [SP], #0x10
    // 0x11969e0: ret
    //     0x11969e0: ret             
    // 0x11969e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11969e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11969e8: b               #0x11968fc
  }
}

// class id: 8302, size: 0x14, field offset: 0x14
enum _CornerId extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9cac, size: 0x64
    // 0x11a9cac: EnterFrame
    //     0x11a9cac: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9cb0: mov             fp, SP
    // 0x11a9cb4: AllocStack(0x10)
    //     0x11a9cb4: sub             SP, SP, #0x10
    // 0x11a9cb8: SetupParameters(_CornerId this /* r1 => r0, fp-0x8 */)
    //     0x11a9cb8: mov             x0, x1
    //     0x11a9cbc: stur            x1, [fp, #-8]
    // 0x11a9cc0: CheckStackOverflow
    //     0x11a9cc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9cc4: cmp             SP, x16
    //     0x11a9cc8: b.ls            #0x11a9d08
    // 0x11a9ccc: r1 = Null
    //     0x11a9ccc: mov             x1, NULL
    // 0x11a9cd0: r2 = 4
    //     0x11a9cd0: mov             x2, #4
    // 0x11a9cd4: r0 = AllocateArray()
    //     0x11a9cd4: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9cd8: r16 = "_CornerId."
    //     0x11a9cd8: add             x16, PP, #0xa0, lsl #12  ; [pp+0xa0f68] "_CornerId."
    //     0x11a9cdc: ldr             x16, [x16, #0xf68]
    // 0x11a9ce0: StoreField: r0->field_f = r16
    //     0x11a9ce0: stur            w16, [x0, #0xf]
    // 0x11a9ce4: ldur            x1, [fp, #-8]
    // 0x11a9ce8: LoadField: r2 = r1->field_f
    //     0x11a9ce8: ldur            w2, [x1, #0xf]
    // 0x11a9cec: DecompressPointer r2
    //     0x11a9cec: add             x2, x2, HEAP, lsl #32
    // 0x11a9cf0: StoreField: r0->field_13 = r2
    //     0x11a9cf0: stur            w2, [x0, #0x13]
    // 0x11a9cf4: str             x0, [SP]
    // 0x11a9cf8: r0 = _interpolate()
    //     0x11a9cf8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9cfc: LeaveFrame
    //     0x11a9cfc: mov             SP, fp
    //     0x11a9d00: ldp             fp, lr, [SP], #0x10
    // 0x11a9d04: ret
    //     0x11a9d04: ret             
    // 0x11a9d08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9d08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9d0c: b               #0x11a9ccc
  }
}
