// lib: , url: package:flutter/src/material/navigation_bar_theme.dart

// class id: 1048920, size: 0x8
class :: {
}

// class id: 5136, size: 0x38, field offset: 0x8
//   const constructor, 
class NavigationBarThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x1134db8, size: 0x7c
    // 0x1134db8: EnterFrame
    //     0x1134db8: stp             fp, lr, [SP, #-0x10]!
    //     0x1134dbc: mov             fp, SP
    // 0x1134dc0: AllocStack(0x50)
    //     0x1134dc0: sub             SP, SP, #0x50
    // 0x1134dc4: CheckStackOverflow
    //     0x1134dc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1134dc8: cmp             SP, x16
    //     0x1134dcc: b.ls            #0x1134e2c
    // 0x1134dd0: ldr             x0, [fp, #0x10]
    // 0x1134dd4: LoadField: r1 = r0->field_7
    //     0x1134dd4: ldur            w1, [x0, #7]
    // 0x1134dd8: DecompressPointer r1
    //     0x1134dd8: add             x1, x1, HEAP, lsl #32
    // 0x1134ddc: LoadField: r2 = r0->field_f
    //     0x1134ddc: ldur            w2, [x0, #0xf]
    // 0x1134de0: DecompressPointer r2
    //     0x1134de0: add             x2, x2, HEAP, lsl #32
    // 0x1134de4: stp             NULL, x2, [SP, #0x40]
    // 0x1134de8: stp             NULL, NULL, [SP, #0x30]
    // 0x1134dec: stp             NULL, NULL, [SP, #0x20]
    // 0x1134df0: stp             NULL, NULL, [SP, #0x10]
    // 0x1134df4: stp             NULL, NULL, [SP]
    // 0x1134df8: r2 = Null
    //     0x1134df8: mov             x2, NULL
    // 0x1134dfc: r4 = const [0, 0xc, 0xa, 0xc, null]
    //     0x1134dfc: add             x4, PP, #0x26, lsl #12  ; [pp+0x26270] List(5) [0, 0xc, 0xa, 0xc, Null]
    //     0x1134e00: ldr             x4, [x4, #0x270]
    // 0x1134e04: r0 = hash()
    //     0x1134e04: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1134e08: mov             x2, x0
    // 0x1134e0c: r0 = BoxInt64Instr(r2)
    //     0x1134e0c: sbfiz           x0, x2, #1, #0x1f
    //     0x1134e10: cmp             x2, x0, asr #1
    //     0x1134e14: b.eq            #0x1134e20
    //     0x1134e18: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1134e1c: stur            x2, [x0, #7]
    // 0x1134e20: LeaveFrame
    //     0x1134e20: mov             SP, fp
    //     0x1134e24: ldp             fp, lr, [SP], #0x10
    // 0x1134e28: ret
    //     0x1134e28: ret             
    // 0x1134e2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1134e2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1134e30: b               #0x1134dd0
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x11667d8, size: 0x160
    // 0x11667d8: EnterFrame
    //     0x11667d8: stp             fp, lr, [SP, #-0x10]!
    //     0x11667dc: mov             fp, SP
    // 0x11667e0: AllocStack(0x28)
    //     0x11667e0: sub             SP, SP, #0x28
    // 0x11667e4: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x28 */)
    //     0x11667e4: mov             x4, x1
    //     0x11667e8: mov             x0, x2
    //     0x11667ec: stur            x1, [fp, #-0x10]
    //     0x11667f0: stur            x2, [fp, #-0x18]
    //     0x11667f4: stur            d0, [fp, #-0x28]
    // 0x11667f8: CheckStackOverflow
    //     0x11667f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11667fc: cmp             SP, x16
    //     0x1166800: b.ls            #0x116690c
    // 0x1166804: cmp             w4, w0
    // 0x1166808: b.ne            #0x116681c
    // 0x116680c: mov             x0, x4
    // 0x1166810: LeaveFrame
    //     0x1166810: mov             SP, fp
    //     0x1166814: ldp             fp, lr, [SP], #0x10
    // 0x1166818: ret
    //     0x1166818: ret             
    // 0x116681c: LoadField: r1 = r4->field_7
    //     0x116681c: ldur            w1, [x4, #7]
    // 0x1166820: DecompressPointer r1
    //     0x1166820: add             x1, x1, HEAP, lsl #32
    // 0x1166824: LoadField: r2 = r0->field_7
    //     0x1166824: ldur            w2, [x0, #7]
    // 0x1166828: DecompressPointer r2
    //     0x1166828: add             x2, x2, HEAP, lsl #32
    // 0x116682c: r5 = inline_Allocate_Double()
    //     0x116682c: ldp             x5, x3, [THR, #0x60]  ; THR::top
    //     0x1166830: add             x5, x5, #0x10
    //     0x1166834: cmp             x3, x5
    //     0x1166838: b.ls            #0x1166914
    //     0x116683c: str             x5, [THR, #0x60]  ; THR::top
    //     0x1166840: sub             x5, x5, #0xf
    //     0x1166844: mov             x3, #0xe19c
    //     0x1166848: movk            x3, #3, lsl #16
    //     0x116684c: stur            x3, [x5, #-1]
    // 0x1166850: dmb             ishst
    // 0x1166854: StoreField: r5->field_7 = d0
    //     0x1166854: stur            d0, [x5, #7]
    // 0x1166858: mov             x3, x5
    // 0x116685c: stur            x5, [fp, #-8]
    // 0x1166860: r0 = lerpDouble()
    //     0x1166860: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1166864: ldur            x3, [fp, #-8]
    // 0x1166868: r1 = Null
    //     0x1166868: mov             x1, NULL
    // 0x116686c: r2 = Null
    //     0x116686c: mov             x2, NULL
    // 0x1166870: stur            x0, [fp, #-0x20]
    // 0x1166874: r0 = lerp()
    //     0x1166874: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1166878: ldur            x0, [fp, #-0x10]
    // 0x116687c: LoadField: r1 = r0->field_f
    //     0x116687c: ldur            w1, [x0, #0xf]
    // 0x1166880: DecompressPointer r1
    //     0x1166880: add             x1, x1, HEAP, lsl #32
    // 0x1166884: ldur            x0, [fp, #-0x18]
    // 0x1166888: LoadField: r2 = r0->field_f
    //     0x1166888: ldur            w2, [x0, #0xf]
    // 0x116688c: DecompressPointer r2
    //     0x116688c: add             x2, x2, HEAP, lsl #32
    // 0x1166890: ldur            x3, [fp, #-8]
    // 0x1166894: r0 = lerpDouble()
    //     0x1166894: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1166898: ldur            x3, [fp, #-8]
    // 0x116689c: r1 = Null
    //     0x116689c: mov             x1, NULL
    // 0x11668a0: r2 = Null
    //     0x11668a0: mov             x2, NULL
    // 0x11668a4: stur            x0, [fp, #-0x10]
    // 0x11668a8: r0 = lerp()
    //     0x11668a8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11668ac: ldur            x3, [fp, #-8]
    // 0x11668b0: r1 = Null
    //     0x11668b0: mov             x1, NULL
    // 0x11668b4: r2 = Null
    //     0x11668b4: mov             x2, NULL
    // 0x11668b8: r0 = lerp()
    //     0x11668b8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11668bc: ldur            x3, [fp, #-8]
    // 0x11668c0: r1 = Null
    //     0x11668c0: mov             x1, NULL
    // 0x11668c4: r2 = Null
    //     0x11668c4: mov             x2, NULL
    // 0x11668c8: r0 = lerp()
    //     0x11668c8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11668cc: ldur            d0, [fp, #-0x28]
    // 0x11668d0: r1 = Null
    //     0x11668d0: mov             x1, NULL
    // 0x11668d4: r2 = Null
    //     0x11668d4: mov             x2, NULL
    // 0x11668d8: r0 = lerp()
    //     0x11668d8: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x11668dc: ldur            x3, [fp, #-8]
    // 0x11668e0: r1 = Null
    //     0x11668e0: mov             x1, NULL
    // 0x11668e4: r2 = Null
    //     0x11668e4: mov             x2, NULL
    // 0x11668e8: r0 = lerp()
    //     0x11668e8: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x11668ec: r0 = NavigationBarThemeData()
    //     0x11668ec: bl              #0x1166938  ; AllocateNavigationBarThemeDataStub -> NavigationBarThemeData (size=0x38)
    // 0x11668f0: ldur            x1, [fp, #-0x20]
    // 0x11668f4: StoreField: r0->field_7 = r1
    //     0x11668f4: stur            w1, [x0, #7]
    // 0x11668f8: ldur            x1, [fp, #-0x10]
    // 0x11668fc: StoreField: r0->field_f = r1
    //     0x11668fc: stur            w1, [x0, #0xf]
    // 0x1166900: LeaveFrame
    //     0x1166900: mov             SP, fp
    //     0x1166904: ldp             fp, lr, [SP], #0x10
    // 0x1166908: ret
    //     0x1166908: ret             
    // 0x116690c: r0 = StackOverflowSharedWithFPURegs()
    //     0x116690c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1166910: b               #0x1166804
    // 0x1166914: SaveReg d0
    //     0x1166914: str             q0, [SP, #-0x10]!
    // 0x1166918: stp             x2, x4, [SP, #-0x10]!
    // 0x116691c: stp             x0, x1, [SP, #-0x10]!
    // 0x1166920: r0 = AllocateDouble()
    //     0x1166920: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1166924: mov             x5, x0
    // 0x1166928: ldp             x0, x1, [SP], #0x10
    // 0x116692c: ldp             x2, x4, [SP], #0x10
    // 0x1166930: RestoreReg d0
    //     0x1166930: ldr             q0, [SP], #0x10
    // 0x1166934: b               #0x1166854
  }
  _ ==(/* No info */) {
    // ** addr: 0x126fce4, size: 0x13c
    // 0x126fce4: EnterFrame
    //     0x126fce4: stp             fp, lr, [SP, #-0x10]!
    //     0x126fce8: mov             fp, SP
    // 0x126fcec: AllocStack(0x10)
    //     0x126fcec: sub             SP, SP, #0x10
    // 0x126fcf0: CheckStackOverflow
    //     0x126fcf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x126fcf4: cmp             SP, x16
    //     0x126fcf8: b.ls            #0x126fe18
    // 0x126fcfc: ldr             x0, [fp, #0x10]
    // 0x126fd00: cmp             w0, NULL
    // 0x126fd04: b.ne            #0x126fd18
    // 0x126fd08: r0 = false
    //     0x126fd08: add             x0, NULL, #0x30  ; false
    // 0x126fd0c: LeaveFrame
    //     0x126fd0c: mov             SP, fp
    //     0x126fd10: ldp             fp, lr, [SP], #0x10
    // 0x126fd14: ret
    //     0x126fd14: ret             
    // 0x126fd18: ldr             x1, [fp, #0x18]
    // 0x126fd1c: cmp             w1, w0
    // 0x126fd20: b.ne            #0x126fd34
    // 0x126fd24: r0 = true
    //     0x126fd24: add             x0, NULL, #0x20  ; true
    // 0x126fd28: LeaveFrame
    //     0x126fd28: mov             SP, fp
    //     0x126fd2c: ldp             fp, lr, [SP], #0x10
    // 0x126fd30: ret
    //     0x126fd30: ret             
    // 0x126fd34: str             x0, [SP]
    // 0x126fd38: r0 = runtimeType()
    //     0x126fd38: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x126fd3c: r1 = LoadClassIdInstr(r0)
    //     0x126fd3c: ldur            x1, [x0, #-1]
    //     0x126fd40: ubfx            x1, x1, #0xc, #0x14
    // 0x126fd44: r16 = NavigationBarThemeData
    //     0x126fd44: add             x16, PP, #0x26, lsl #12  ; [pp+0x26318] Type: NavigationBarThemeData
    //     0x126fd48: ldr             x16, [x16, #0x318]
    // 0x126fd4c: stp             x16, x0, [SP]
    // 0x126fd50: mov             x0, x1
    // 0x126fd54: mov             lr, x0
    // 0x126fd58: ldr             lr, [x21, lr, lsl #3]
    // 0x126fd5c: blr             lr
    // 0x126fd60: tbz             w0, #4, #0x126fd74
    // 0x126fd64: r0 = false
    //     0x126fd64: add             x0, NULL, #0x30  ; false
    // 0x126fd68: LeaveFrame
    //     0x126fd68: mov             SP, fp
    //     0x126fd6c: ldp             fp, lr, [SP], #0x10
    // 0x126fd70: ret
    //     0x126fd70: ret             
    // 0x126fd74: ldr             x1, [fp, #0x10]
    // 0x126fd78: r0 = 60
    //     0x126fd78: mov             x0, #0x3c
    // 0x126fd7c: branchIfSmi(r1, 0x126fd88)
    //     0x126fd7c: tbz             w1, #0, #0x126fd88
    // 0x126fd80: r0 = LoadClassIdInstr(r1)
    //     0x126fd80: ldur            x0, [x1, #-1]
    //     0x126fd84: ubfx            x0, x0, #0xc, #0x14
    // 0x126fd88: r17 = 5136
    //     0x126fd88: mov             x17, #0x1410
    // 0x126fd8c: cmp             x0, x17
    // 0x126fd90: b.ne            #0x126fe08
    // 0x126fd94: ldr             x2, [fp, #0x18]
    // 0x126fd98: LoadField: r0 = r1->field_7
    //     0x126fd98: ldur            w0, [x1, #7]
    // 0x126fd9c: DecompressPointer r0
    //     0x126fd9c: add             x0, x0, HEAP, lsl #32
    // 0x126fda0: LoadField: r3 = r2->field_7
    //     0x126fda0: ldur            w3, [x2, #7]
    // 0x126fda4: DecompressPointer r3
    //     0x126fda4: add             x3, x3, HEAP, lsl #32
    // 0x126fda8: r4 = LoadClassIdInstr(r0)
    //     0x126fda8: ldur            x4, [x0, #-1]
    //     0x126fdac: ubfx            x4, x4, #0xc, #0x14
    // 0x126fdb0: stp             x3, x0, [SP]
    // 0x126fdb4: mov             x0, x4
    // 0x126fdb8: mov             lr, x0
    // 0x126fdbc: ldr             lr, [x21, lr, lsl #3]
    // 0x126fdc0: blr             lr
    // 0x126fdc4: tbnz            w0, #4, #0x126fe08
    // 0x126fdc8: ldr             x1, [fp, #0x18]
    // 0x126fdcc: ldr             x0, [fp, #0x10]
    // 0x126fdd0: LoadField: r2 = r0->field_f
    //     0x126fdd0: ldur            w2, [x0, #0xf]
    // 0x126fdd4: DecompressPointer r2
    //     0x126fdd4: add             x2, x2, HEAP, lsl #32
    // 0x126fdd8: LoadField: r0 = r1->field_f
    //     0x126fdd8: ldur            w0, [x1, #0xf]
    // 0x126fddc: DecompressPointer r0
    //     0x126fddc: add             x0, x0, HEAP, lsl #32
    // 0x126fde0: r1 = LoadClassIdInstr(r2)
    //     0x126fde0: ldur            x1, [x2, #-1]
    //     0x126fde4: ubfx            x1, x1, #0xc, #0x14
    // 0x126fde8: stp             x0, x2, [SP]
    // 0x126fdec: mov             x0, x1
    // 0x126fdf0: mov             lr, x0
    // 0x126fdf4: ldr             lr, [x21, lr, lsl #3]
    // 0x126fdf8: blr             lr
    // 0x126fdfc: tbnz            w0, #4, #0x126fe08
    // 0x126fe00: r0 = true
    //     0x126fe00: add             x0, NULL, #0x20  ; true
    // 0x126fe04: b               #0x126fe0c
    // 0x126fe08: r0 = false
    //     0x126fe08: add             x0, NULL, #0x30  ; false
    // 0x126fe0c: LeaveFrame
    //     0x126fe0c: mov             SP, fp
    //     0x126fe10: ldp             fp, lr, [SP], #0x10
    // 0x126fe14: ret
    //     0x126fe14: ret             
    // 0x126fe18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x126fe18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x126fe1c: b               #0x126fcfc
  }
}
