// lib: , url: package:flutter/src/material/badge_theme.dart

// class id: 1048846, size: 0x8
class :: {
}

// class id: 5208, size: 0x28, field offset: 0x8
//   const constructor, 
class BadgeThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x112ec2c, size: 0x78
    // 0x112ec2c: EnterFrame
    //     0x112ec2c: stp             fp, lr, [SP, #-0x10]!
    //     0x112ec30: mov             fp, SP
    // 0x112ec34: AllocStack(0x30)
    //     0x112ec34: sub             SP, SP, #0x30
    // 0x112ec38: CheckStackOverflow
    //     0x112ec38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112ec3c: cmp             SP, x16
    //     0x112ec40: b.ls            #0x112ec9c
    // 0x112ec44: ldr             x0, [fp, #0x10]
    // 0x112ec48: LoadField: r1 = r0->field_f
    //     0x112ec48: ldur            w1, [x0, #0xf]
    // 0x112ec4c: DecompressPointer r1
    //     0x112ec4c: add             x1, x1, HEAP, lsl #32
    // 0x112ec50: LoadField: r2 = r0->field_13
    //     0x112ec50: ldur            w2, [x0, #0x13]
    // 0x112ec54: DecompressPointer r2
    //     0x112ec54: add             x2, x2, HEAP, lsl #32
    // 0x112ec58: stp             x2, x1, [SP, #0x20]
    // 0x112ec5c: stp             NULL, NULL, [SP, #0x10]
    // 0x112ec60: stp             NULL, NULL, [SP]
    // 0x112ec64: r1 = Null
    //     0x112ec64: mov             x1, NULL
    // 0x112ec68: r2 = Null
    //     0x112ec68: mov             x2, NULL
    // 0x112ec6c: r4 = const [0, 0x8, 0x6, 0x8, null]
    //     0x112ec6c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe090] List(5) [0, 0x8, 0x6, 0x8, Null]
    //     0x112ec70: ldr             x4, [x4, #0x90]
    // 0x112ec74: r0 = hash()
    //     0x112ec74: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x112ec78: mov             x2, x0
    // 0x112ec7c: r0 = BoxInt64Instr(r2)
    //     0x112ec7c: sbfiz           x0, x2, #1, #0x1f
    //     0x112ec80: cmp             x2, x0, asr #1
    //     0x112ec84: b.eq            #0x112ec90
    //     0x112ec88: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x112ec8c: stur            x2, [x0, #7]
    // 0x112ec90: LeaveFrame
    //     0x112ec90: mov             SP, fp
    //     0x112ec94: ldp             fp, lr, [SP], #0x10
    // 0x112ec98: ret
    //     0x112ec98: ret             
    // 0x112ec9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112ec9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112eca0: b               #0x112ec44
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1168d38, size: 0x154
    // 0x1168d38: EnterFrame
    //     0x1168d38: stp             fp, lr, [SP, #-0x10]!
    //     0x1168d3c: mov             fp, SP
    // 0x1168d40: AllocStack(0x28)
    //     0x1168d40: sub             SP, SP, #0x28
    // 0x1168d44: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x28 */)
    //     0x1168d44: mov             x4, x1
    //     0x1168d48: mov             x0, x2
    //     0x1168d4c: stur            x1, [fp, #-0x10]
    //     0x1168d50: stur            x2, [fp, #-0x18]
    //     0x1168d54: stur            d0, [fp, #-0x28]
    // 0x1168d58: CheckStackOverflow
    //     0x1168d58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1168d5c: cmp             SP, x16
    //     0x1168d60: b.ls            #0x1168e68
    // 0x1168d64: cmp             w4, w0
    // 0x1168d68: b.ne            #0x1168d7c
    // 0x1168d6c: mov             x0, x4
    // 0x1168d70: LeaveFrame
    //     0x1168d70: mov             SP, fp
    //     0x1168d74: ldp             fp, lr, [SP], #0x10
    // 0x1168d78: ret
    //     0x1168d78: ret             
    // 0x1168d7c: r5 = inline_Allocate_Double()
    //     0x1168d7c: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x1168d80: add             x5, x5, #0x10
    //     0x1168d84: cmp             x1, x5
    //     0x1168d88: b.ls            #0x1168e70
    //     0x1168d8c: str             x5, [THR, #0x60]  ; THR::top
    //     0x1168d90: sub             x5, x5, #0xf
    //     0x1168d94: mov             x1, #0xe19c
    //     0x1168d98: movk            x1, #3, lsl #16
    //     0x1168d9c: stur            x1, [x5, #-1]
    // 0x1168da0: dmb             ishst
    // 0x1168da4: StoreField: r5->field_7 = d0
    //     0x1168da4: stur            d0, [x5, #7]
    // 0x1168da8: mov             x3, x5
    // 0x1168dac: stur            x5, [fp, #-8]
    // 0x1168db0: r1 = Null
    //     0x1168db0: mov             x1, NULL
    // 0x1168db4: r2 = Null
    //     0x1168db4: mov             x2, NULL
    // 0x1168db8: r0 = lerp()
    //     0x1168db8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168dbc: ldur            x3, [fp, #-8]
    // 0x1168dc0: r1 = Null
    //     0x1168dc0: mov             x1, NULL
    // 0x1168dc4: r2 = Null
    //     0x1168dc4: mov             x2, NULL
    // 0x1168dc8: r0 = lerp()
    //     0x1168dc8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168dcc: ldur            x0, [fp, #-0x10]
    // 0x1168dd0: LoadField: r1 = r0->field_f
    //     0x1168dd0: ldur            w1, [x0, #0xf]
    // 0x1168dd4: DecompressPointer r1
    //     0x1168dd4: add             x1, x1, HEAP, lsl #32
    // 0x1168dd8: ldur            x4, [fp, #-0x18]
    // 0x1168ddc: LoadField: r2 = r4->field_f
    //     0x1168ddc: ldur            w2, [x4, #0xf]
    // 0x1168de0: DecompressPointer r2
    //     0x1168de0: add             x2, x2, HEAP, lsl #32
    // 0x1168de4: ldur            x3, [fp, #-8]
    // 0x1168de8: r0 = lerpDouble()
    //     0x1168de8: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1168dec: mov             x4, x0
    // 0x1168df0: ldur            x0, [fp, #-0x10]
    // 0x1168df4: stur            x4, [fp, #-0x20]
    // 0x1168df8: LoadField: r1 = r0->field_13
    //     0x1168df8: ldur            w1, [x0, #0x13]
    // 0x1168dfc: DecompressPointer r1
    //     0x1168dfc: add             x1, x1, HEAP, lsl #32
    // 0x1168e00: ldur            x0, [fp, #-0x18]
    // 0x1168e04: LoadField: r2 = r0->field_13
    //     0x1168e04: ldur            w2, [x0, #0x13]
    // 0x1168e08: DecompressPointer r2
    //     0x1168e08: add             x2, x2, HEAP, lsl #32
    // 0x1168e0c: ldur            x3, [fp, #-8]
    // 0x1168e10: r0 = lerpDouble()
    //     0x1168e10: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1168e14: ldur            x3, [fp, #-8]
    // 0x1168e18: r1 = Null
    //     0x1168e18: mov             x1, NULL
    // 0x1168e1c: r2 = Null
    //     0x1168e1c: mov             x2, NULL
    // 0x1168e20: stur            x0, [fp, #-0x10]
    // 0x1168e24: r0 = lerp()
    //     0x1168e24: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1168e28: ldur            x3, [fp, #-8]
    // 0x1168e2c: r1 = Null
    //     0x1168e2c: mov             x1, NULL
    // 0x1168e30: r2 = Null
    //     0x1168e30: mov             x2, NULL
    // 0x1168e34: r0 = lerp()
    //     0x1168e34: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x1168e38: ldur            d0, [fp, #-0x28]
    // 0x1168e3c: r1 = Null
    //     0x1168e3c: mov             x1, NULL
    // 0x1168e40: r2 = Null
    //     0x1168e40: mov             x2, NULL
    // 0x1168e44: r0 = lerp()
    //     0x1168e44: bl              #0x1160c48  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::lerp
    // 0x1168e48: r0 = BadgeThemeData()
    //     0x1168e48: bl              #0x1168e8c  ; AllocateBadgeThemeDataStub -> BadgeThemeData (size=0x28)
    // 0x1168e4c: ldur            x1, [fp, #-0x20]
    // 0x1168e50: StoreField: r0->field_f = r1
    //     0x1168e50: stur            w1, [x0, #0xf]
    // 0x1168e54: ldur            x1, [fp, #-0x10]
    // 0x1168e58: StoreField: r0->field_13 = r1
    //     0x1168e58: stur            w1, [x0, #0x13]
    // 0x1168e5c: LeaveFrame
    //     0x1168e5c: mov             SP, fp
    //     0x1168e60: ldp             fp, lr, [SP], #0x10
    // 0x1168e64: ret
    //     0x1168e64: ret             
    // 0x1168e68: r0 = StackOverflowSharedWithFPURegs()
    //     0x1168e68: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1168e6c: b               #0x1168d64
    // 0x1168e70: SaveReg d0
    //     0x1168e70: str             q0, [SP, #-0x10]!
    // 0x1168e74: stp             x0, x4, [SP, #-0x10]!
    // 0x1168e78: r0 = AllocateDouble()
    //     0x1168e78: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1168e7c: mov             x5, x0
    // 0x1168e80: ldp             x0, x4, [SP], #0x10
    // 0x1168e84: RestoreReg d0
    //     0x1168e84: ldr             q0, [SP], #0x10
    // 0x1168e88: b               #0x1168da4
  }
  _ ==(/* No info */) {
    // ** addr: 0x1263f34, size: 0x13c
    // 0x1263f34: EnterFrame
    //     0x1263f34: stp             fp, lr, [SP, #-0x10]!
    //     0x1263f38: mov             fp, SP
    // 0x1263f3c: AllocStack(0x10)
    //     0x1263f3c: sub             SP, SP, #0x10
    // 0x1263f40: CheckStackOverflow
    //     0x1263f40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1263f44: cmp             SP, x16
    //     0x1263f48: b.ls            #0x1264068
    // 0x1263f4c: ldr             x0, [fp, #0x10]
    // 0x1263f50: cmp             w0, NULL
    // 0x1263f54: b.ne            #0x1263f68
    // 0x1263f58: r0 = false
    //     0x1263f58: add             x0, NULL, #0x30  ; false
    // 0x1263f5c: LeaveFrame
    //     0x1263f5c: mov             SP, fp
    //     0x1263f60: ldp             fp, lr, [SP], #0x10
    // 0x1263f64: ret
    //     0x1263f64: ret             
    // 0x1263f68: ldr             x1, [fp, #0x18]
    // 0x1263f6c: cmp             w1, w0
    // 0x1263f70: b.ne            #0x1263f84
    // 0x1263f74: r0 = true
    //     0x1263f74: add             x0, NULL, #0x20  ; true
    // 0x1263f78: LeaveFrame
    //     0x1263f78: mov             SP, fp
    //     0x1263f7c: ldp             fp, lr, [SP], #0x10
    // 0x1263f80: ret
    //     0x1263f80: ret             
    // 0x1263f84: str             x0, [SP]
    // 0x1263f88: r0 = runtimeType()
    //     0x1263f88: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1263f8c: r1 = LoadClassIdInstr(r0)
    //     0x1263f8c: ldur            x1, [x0, #-1]
    //     0x1263f90: ubfx            x1, x1, #0xc, #0x14
    // 0x1263f94: r16 = BadgeThemeData
    //     0x1263f94: add             x16, PP, #0x26, lsl #12  ; [pp+0x26580] Type: BadgeThemeData
    //     0x1263f98: ldr             x16, [x16, #0x580]
    // 0x1263f9c: stp             x16, x0, [SP]
    // 0x1263fa0: mov             x0, x1
    // 0x1263fa4: mov             lr, x0
    // 0x1263fa8: ldr             lr, [x21, lr, lsl #3]
    // 0x1263fac: blr             lr
    // 0x1263fb0: tbz             w0, #4, #0x1263fc4
    // 0x1263fb4: r0 = false
    //     0x1263fb4: add             x0, NULL, #0x30  ; false
    // 0x1263fb8: LeaveFrame
    //     0x1263fb8: mov             SP, fp
    //     0x1263fbc: ldp             fp, lr, [SP], #0x10
    // 0x1263fc0: ret
    //     0x1263fc0: ret             
    // 0x1263fc4: ldr             x1, [fp, #0x10]
    // 0x1263fc8: r0 = 60
    //     0x1263fc8: mov             x0, #0x3c
    // 0x1263fcc: branchIfSmi(r1, 0x1263fd8)
    //     0x1263fcc: tbz             w1, #0, #0x1263fd8
    // 0x1263fd0: r0 = LoadClassIdInstr(r1)
    //     0x1263fd0: ldur            x0, [x1, #-1]
    //     0x1263fd4: ubfx            x0, x0, #0xc, #0x14
    // 0x1263fd8: r17 = 5208
    //     0x1263fd8: mov             x17, #0x1458
    // 0x1263fdc: cmp             x0, x17
    // 0x1263fe0: b.ne            #0x1264058
    // 0x1263fe4: ldr             x2, [fp, #0x18]
    // 0x1263fe8: LoadField: r0 = r1->field_f
    //     0x1263fe8: ldur            w0, [x1, #0xf]
    // 0x1263fec: DecompressPointer r0
    //     0x1263fec: add             x0, x0, HEAP, lsl #32
    // 0x1263ff0: LoadField: r3 = r2->field_f
    //     0x1263ff0: ldur            w3, [x2, #0xf]
    // 0x1263ff4: DecompressPointer r3
    //     0x1263ff4: add             x3, x3, HEAP, lsl #32
    // 0x1263ff8: r4 = LoadClassIdInstr(r0)
    //     0x1263ff8: ldur            x4, [x0, #-1]
    //     0x1263ffc: ubfx            x4, x4, #0xc, #0x14
    // 0x1264000: stp             x3, x0, [SP]
    // 0x1264004: mov             x0, x4
    // 0x1264008: mov             lr, x0
    // 0x126400c: ldr             lr, [x21, lr, lsl #3]
    // 0x1264010: blr             lr
    // 0x1264014: tbnz            w0, #4, #0x1264058
    // 0x1264018: ldr             x1, [fp, #0x18]
    // 0x126401c: ldr             x0, [fp, #0x10]
    // 0x1264020: LoadField: r2 = r0->field_13
    //     0x1264020: ldur            w2, [x0, #0x13]
    // 0x1264024: DecompressPointer r2
    //     0x1264024: add             x2, x2, HEAP, lsl #32
    // 0x1264028: LoadField: r0 = r1->field_13
    //     0x1264028: ldur            w0, [x1, #0x13]
    // 0x126402c: DecompressPointer r0
    //     0x126402c: add             x0, x0, HEAP, lsl #32
    // 0x1264030: r1 = LoadClassIdInstr(r2)
    //     0x1264030: ldur            x1, [x2, #-1]
    //     0x1264034: ubfx            x1, x1, #0xc, #0x14
    // 0x1264038: stp             x0, x2, [SP]
    // 0x126403c: mov             x0, x1
    // 0x1264040: mov             lr, x0
    // 0x1264044: ldr             lr, [x21, lr, lsl #3]
    // 0x1264048: blr             lr
    // 0x126404c: tbnz            w0, #4, #0x1264058
    // 0x1264050: r0 = true
    //     0x1264050: add             x0, NULL, #0x20  ; true
    // 0x1264054: b               #0x126405c
    // 0x1264058: r0 = false
    //     0x1264058: add             x0, NULL, #0x30  ; false
    // 0x126405c: LeaveFrame
    //     0x126405c: mov             SP, fp
    //     0x1264060: ldp             fp, lr, [SP], #0x10
    // 0x1264064: ret
    //     0x1264064: ret             
    // 0x1264068: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1264068: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x126406c: b               #0x1263f4c
  }
}
