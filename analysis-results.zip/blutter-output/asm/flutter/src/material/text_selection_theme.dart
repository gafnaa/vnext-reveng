// lib: , url: package:flutter/src/material/text_selection_theme.dart

// class id: 1048964, size: 0x8
class :: {
}

// class id: 5056, size: 0x14, field offset: 0x8
//   const constructor, 
class TextSelectionThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x11387c4, size: 0x58
    // 0x11387c4: EnterFrame
    //     0x11387c4: stp             fp, lr, [SP, #-0x10]!
    //     0x11387c8: mov             fp, SP
    // 0x11387cc: AllocStack(0x8)
    //     0x11387cc: sub             SP, SP, #8
    // 0x11387d0: CheckStackOverflow
    //     0x11387d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11387d4: cmp             SP, x16
    //     0x11387d8: b.ls            #0x1138814
    // 0x11387dc: str             NULL, [SP]
    // 0x11387e0: r1 = Null
    //     0x11387e0: mov             x1, NULL
    // 0x11387e4: r2 = Null
    //     0x11387e4: mov             x2, NULL
    // 0x11387e8: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x11387e8: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x11387ec: r0 = hash()
    //     0x11387ec: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x11387f0: mov             x2, x0
    // 0x11387f4: r0 = BoxInt64Instr(r2)
    //     0x11387f4: sbfiz           x0, x2, #1, #0x1f
    //     0x11387f8: cmp             x2, x0, asr #1
    //     0x11387fc: b.eq            #0x1138808
    //     0x1138800: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1138804: stur            x2, [x0, #7]
    // 0x1138808: LeaveFrame
    //     0x1138808: mov             SP, fp
    //     0x113880c: ldp             fp, lr, [SP], #0x10
    // 0x1138810: ret
    //     0x1138810: ret             
    // 0x1138814: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1138814: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1138818: b               #0x11387dc
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1165260, size: 0xb8
    // 0x1165260: EnterFrame
    //     0x1165260: stp             fp, lr, [SP, #-0x10]!
    //     0x1165264: mov             fp, SP
    // 0x1165268: AllocStack(0x8)
    //     0x1165268: sub             SP, SP, #8
    // 0x116526c: SetupParameters(dynamic _ /* r1 => r0 */)
    //     0x116526c: mov             x0, x1
    // 0x1165270: CheckStackOverflow
    //     0x1165270: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1165274: cmp             SP, x16
    //     0x1165278: b.ls            #0x1165300
    // 0x116527c: cmp             w0, w2
    // 0x1165280: b.ne            #0x1165290
    // 0x1165284: LeaveFrame
    //     0x1165284: mov             SP, fp
    //     0x1165288: ldp             fp, lr, [SP], #0x10
    // 0x116528c: ret
    //     0x116528c: ret             
    // 0x1165290: r0 = inline_Allocate_Double()
    //     0x1165290: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x1165294: add             x0, x0, #0x10
    //     0x1165298: cmp             x1, x0
    //     0x116529c: b.ls            #0x1165308
    //     0x11652a0: str             x0, [THR, #0x60]  ; THR::top
    //     0x11652a4: sub             x0, x0, #0xf
    //     0x11652a8: mov             x1, #0xe19c
    //     0x11652ac: movk            x1, #3, lsl #16
    //     0x11652b0: stur            x1, [x0, #-1]
    // 0x11652b4: dmb             ishst
    // 0x11652b8: StoreField: r0->field_7 = d0
    //     0x11652b8: stur            d0, [x0, #7]
    // 0x11652bc: mov             x3, x0
    // 0x11652c0: stur            x0, [fp, #-8]
    // 0x11652c4: r1 = Null
    //     0x11652c4: mov             x1, NULL
    // 0x11652c8: r2 = Null
    //     0x11652c8: mov             x2, NULL
    // 0x11652cc: r0 = lerp()
    //     0x11652cc: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11652d0: ldur            x3, [fp, #-8]
    // 0x11652d4: r1 = Null
    //     0x11652d4: mov             x1, NULL
    // 0x11652d8: r2 = Null
    //     0x11652d8: mov             x2, NULL
    // 0x11652dc: r0 = lerp()
    //     0x11652dc: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11652e0: ldur            x3, [fp, #-8]
    // 0x11652e4: r1 = Null
    //     0x11652e4: mov             x1, NULL
    // 0x11652e8: r2 = Null
    //     0x11652e8: mov             x2, NULL
    // 0x11652ec: r0 = lerp()
    //     0x11652ec: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11652f0: r0 = TextSelectionThemeData()
    //     0x11652f0: bl              #0x1165318  ; AllocateTextSelectionThemeDataStub -> TextSelectionThemeData (size=0x14)
    // 0x11652f4: LeaveFrame
    //     0x11652f4: mov             SP, fp
    //     0x11652f8: ldp             fp, lr, [SP], #0x10
    // 0x11652fc: ret
    //     0x11652fc: ret             
    // 0x1165300: r0 = StackOverflowSharedWithFPURegs()
    //     0x1165300: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1165304: b               #0x116527c
    // 0x1165308: SaveReg d0
    //     0x1165308: str             q0, [SP, #-0x10]!
    // 0x116530c: r0 = AllocateDouble()
    //     0x116530c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1165310: RestoreReg d0
    //     0x1165310: ldr             q0, [SP], #0x10
    // 0x1165314: b               #0x11652b8
  }
  _ ==(/* No info */) {
    // ** addr: 0x1277028, size: 0xd0
    // 0x1277028: EnterFrame
    //     0x1277028: stp             fp, lr, [SP, #-0x10]!
    //     0x127702c: mov             fp, SP
    // 0x1277030: AllocStack(0x10)
    //     0x1277030: sub             SP, SP, #0x10
    // 0x1277034: CheckStackOverflow
    //     0x1277034: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1277038: cmp             SP, x16
    //     0x127703c: b.ls            #0x12770f0
    // 0x1277040: ldr             x0, [fp, #0x10]
    // 0x1277044: cmp             w0, NULL
    // 0x1277048: b.ne            #0x127705c
    // 0x127704c: r0 = false
    //     0x127704c: add             x0, NULL, #0x30  ; false
    // 0x1277050: LeaveFrame
    //     0x1277050: mov             SP, fp
    //     0x1277054: ldp             fp, lr, [SP], #0x10
    // 0x1277058: ret
    //     0x1277058: ret             
    // 0x127705c: ldr             x1, [fp, #0x18]
    // 0x1277060: cmp             w1, w0
    // 0x1277064: b.ne            #0x1277078
    // 0x1277068: r0 = true
    //     0x1277068: add             x0, NULL, #0x20  ; true
    // 0x127706c: LeaveFrame
    //     0x127706c: mov             SP, fp
    //     0x1277070: ldp             fp, lr, [SP], #0x10
    // 0x1277074: ret
    //     0x1277074: ret             
    // 0x1277078: str             x0, [SP]
    // 0x127707c: r0 = runtimeType()
    //     0x127707c: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1277080: r1 = LoadClassIdInstr(r0)
    //     0x1277080: ldur            x1, [x0, #-1]
    //     0x1277084: ubfx            x1, x1, #0xc, #0x14
    // 0x1277088: r16 = TextSelectionThemeData
    //     0x1277088: add             x16, PP, #0x26, lsl #12  ; [pp+0x260a0] Type: TextSelectionThemeData
    //     0x127708c: ldr             x16, [x16, #0xa0]
    // 0x1277090: stp             x16, x0, [SP]
    // 0x1277094: mov             x0, x1
    // 0x1277098: mov             lr, x0
    // 0x127709c: ldr             lr, [x21, lr, lsl #3]
    // 0x12770a0: blr             lr
    // 0x12770a4: tbz             w0, #4, #0x12770b8
    // 0x12770a8: r0 = false
    //     0x12770a8: add             x0, NULL, #0x30  ; false
    // 0x12770ac: LeaveFrame
    //     0x12770ac: mov             SP, fp
    //     0x12770b0: ldp             fp, lr, [SP], #0x10
    // 0x12770b4: ret
    //     0x12770b4: ret             
    // 0x12770b8: ldr             x1, [fp, #0x10]
    // 0x12770bc: r2 = 60
    //     0x12770bc: mov             x2, #0x3c
    // 0x12770c0: branchIfSmi(r1, 0x12770cc)
    //     0x12770c0: tbz             w1, #0, #0x12770cc
    // 0x12770c4: r2 = LoadClassIdInstr(r1)
    //     0x12770c4: ldur            x2, [x1, #-1]
    //     0x12770c8: ubfx            x2, x2, #0xc, #0x14
    // 0x12770cc: r17 = 5056
    //     0x12770cc: mov             x17, #0x13c0
    // 0x12770d0: cmp             x2, x17
    // 0x12770d4: b.ne            #0x12770e0
    // 0x12770d8: r0 = true
    //     0x12770d8: add             x0, NULL, #0x20  ; true
    // 0x12770dc: b               #0x12770e4
    // 0x12770e0: r0 = false
    //     0x12770e0: add             x0, NULL, #0x30  ; false
    // 0x12770e4: LeaveFrame
    //     0x12770e4: mov             SP, fp
    //     0x12770e8: ldp             fp, lr, [SP], #0x10
    // 0x12770ec: ret
    //     0x12770ec: ret             
    // 0x12770f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12770f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12770f4: b               #0x1277040
  }
}

// class id: 6835, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class TextSelectionTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xccc478, size: 0x5c
    // 0xccc478: EnterFrame
    //     0xccc478: stp             fp, lr, [SP, #-0x10]!
    //     0xccc47c: mov             fp, SP
    // 0xccc480: AllocStack(0x18)
    //     0xccc480: sub             SP, SP, #0x18
    // 0xccc484: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xccc484: stur            x1, [fp, #-8]
    // 0xccc488: CheckStackOverflow
    //     0xccc488: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xccc48c: cmp             SP, x16
    //     0xccc490: b.ls            #0xccc4cc
    // 0xccc494: r16 = <TextSelectionTheme>
    //     0xccc494: add             x16, PP, #0x98, lsl #12  ; [pp+0x98e78] TypeArguments: <TextSelectionTheme>
    //     0xccc498: ldr             x16, [x16, #0xe78]
    // 0xccc49c: stp             x1, x16, [SP]
    // 0xccc4a0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xccc4a0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xccc4a4: r0 = dependOnInheritedWidgetOfExactType()
    //     0xccc4a4: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xccc4a8: ldur            x1, [fp, #-8]
    // 0xccc4ac: r0 = of()
    //     0xccc4ac: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xccc4b0: r17 = 311
    //     0xccc4b0: mov             x17, #0x137
    // 0xccc4b4: ldr             w1, [x0, x17]
    // 0xccc4b8: DecompressPointer r1
    //     0xccc4b8: add             x1, x1, HEAP, lsl #32
    // 0xccc4bc: mov             x0, x1
    // 0xccc4c0: LeaveFrame
    //     0xccc4c0: mov             SP, fp
    //     0xccc4c4: ldp             fp, lr, [SP], #0x10
    // 0xccc4c8: ret
    //     0xccc4c8: ret             
    // 0xccc4cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccc4cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccc4d0: b               #0xccc494
  }
}
