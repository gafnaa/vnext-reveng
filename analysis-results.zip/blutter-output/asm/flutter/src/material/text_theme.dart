// lib: , url: package:flutter/src/material/text_theme.dart

// class id: 1048967, size: 0x8
class :: {
}

// class id: 5055, size: 0x44, field offset: 0x8
//   const constructor, 
class TextTheme extends _MixinApplication3&Object&Diagnosticable {

  TextStyle field_8;
  TextStyle field_c;
  TextStyle field_10;
  TextStyle field_14;
  TextStyle field_18;
  TextStyle field_1c;
  TextStyle field_20;
  TextStyle field_24;
  TextStyle field_28;
  TextStyle field_2c;
  TextStyle field_30;
  TextStyle field_34;
  TextStyle field_38;
  TextStyle field_3c;
  TextStyle field_40;

  _ merge(/* No info */) {
    // ** addr: 0x8a91f8, size: 0x4c0
    // 0x8a91f8: EnterFrame
    //     0x8a91f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8a91fc: mov             fp, SP
    // 0x8a9200: AllocStack(0xd0)
    //     0x8a9200: sub             SP, SP, #0xd0
    // 0x8a9204: SetupParameters(TextTheme this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x8a9204: mov             x3, x1
    //     0x8a9208: mov             x0, x2
    //     0x8a920c: stur            x1, [fp, #-8]
    //     0x8a9210: stur            x2, [fp, #-0x10]
    // 0x8a9214: CheckStackOverflow
    //     0x8a9214: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a9218: cmp             SP, x16
    //     0x8a921c: b.ls            #0x8a96b0
    // 0x8a9220: cmp             w0, NULL
    // 0x8a9224: b.ne            #0x8a9238
    // 0x8a9228: mov             x0, x3
    // 0x8a922c: LeaveFrame
    //     0x8a922c: mov             SP, fp
    //     0x8a9230: ldp             fp, lr, [SP], #0x10
    // 0x8a9234: ret
    //     0x8a9234: ret             
    // 0x8a9238: LoadField: r1 = r3->field_7
    //     0x8a9238: ldur            w1, [x3, #7]
    // 0x8a923c: DecompressPointer r1
    //     0x8a923c: add             x1, x1, HEAP, lsl #32
    // 0x8a9240: cmp             w1, NULL
    // 0x8a9244: b.ne            #0x8a9250
    // 0x8a9248: r0 = Null
    //     0x8a9248: mov             x0, NULL
    // 0x8a924c: b               #0x8a925c
    // 0x8a9250: LoadField: r2 = r0->field_7
    //     0x8a9250: ldur            w2, [x0, #7]
    // 0x8a9254: DecompressPointer r2
    //     0x8a9254: add             x2, x2, HEAP, lsl #32
    // 0x8a9258: r0 = merge()
    //     0x8a9258: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x8a925c: cmp             w0, NULL
    // 0x8a9260: b.ne            #0x8a9278
    // 0x8a9264: ldur            x3, [fp, #-0x10]
    // 0x8a9268: LoadField: r0 = r3->field_7
    //     0x8a9268: ldur            w0, [x3, #7]
    // 0x8a926c: DecompressPointer r0
    //     0x8a926c: add             x0, x0, HEAP, lsl #32
    // 0x8a9270: mov             x6, x0
    // 0x8a9274: b               #0x8a9280
    // 0x8a9278: ldur            x3, [fp, #-0x10]
    // 0x8a927c: mov             x6, x0
    // 0x8a9280: ldur            x0, [fp, #-8]
    // 0x8a9284: stur            x6, [fp, #-0x18]
    // 0x8a9288: LoadField: r1 = r0->field_b
    //     0x8a9288: ldur            w1, [x0, #0xb]
    // 0x8a928c: DecompressPointer r1
    //     0x8a928c: add             x1, x1, HEAP, lsl #32
    // 0x8a9290: cmp             w1, NULL
    // 0x8a9294: b.ne            #0x8a92a0
    // 0x8a9298: r0 = Null
    //     0x8a9298: mov             x0, NULL
    // 0x8a929c: b               #0x8a92ac
    // 0x8a92a0: LoadField: r2 = r3->field_b
    //     0x8a92a0: ldur            w2, [x3, #0xb]
    // 0x8a92a4: DecompressPointer r2
    //     0x8a92a4: add             x2, x2, HEAP, lsl #32
    // 0x8a92a8: r0 = merge()
    //     0x8a92a8: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x8a92ac: cmp             w0, NULL
    // 0x8a92b0: b.ne            #0x8a92c8
    // 0x8a92b4: ldur            x3, [fp, #-0x10]
    // 0x8a92b8: LoadField: r0 = r3->field_b
    //     0x8a92b8: ldur            w0, [x3, #0xb]
    // 0x8a92bc: DecompressPointer r0
    //     0x8a92bc: add             x0, x0, HEAP, lsl #32
    // 0x8a92c0: mov             x7, x0
    // 0x8a92c4: b               #0x8a92d0
    // 0x8a92c8: ldur            x3, [fp, #-0x10]
    // 0x8a92cc: mov             x7, x0
    // 0x8a92d0: ldur            x0, [fp, #-8]
    // 0x8a92d4: stur            x7, [fp, #-0x20]
    // 0x8a92d8: LoadField: r1 = r0->field_f
    //     0x8a92d8: ldur            w1, [x0, #0xf]
    // 0x8a92dc: DecompressPointer r1
    //     0x8a92dc: add             x1, x1, HEAP, lsl #32
    // 0x8a92e0: cmp             w1, NULL
    // 0x8a92e4: b.ne            #0x8a92f0
    // 0x8a92e8: r0 = Null
    //     0x8a92e8: mov             x0, NULL
    // 0x8a92ec: b               #0x8a92fc
    // 0x8a92f0: LoadField: r2 = r3->field_f
    //     0x8a92f0: ldur            w2, [x3, #0xf]
    // 0x8a92f4: DecompressPointer r2
    //     0x8a92f4: add             x2, x2, HEAP, lsl #32
    // 0x8a92f8: r0 = merge()
    //     0x8a92f8: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x8a92fc: cmp             w0, NULL
    // 0x8a9300: b.ne            #0x8a9318
    // 0x8a9304: ldur            x3, [fp, #-0x10]
    // 0x8a9308: LoadField: r0 = r3->field_f
    //     0x8a9308: ldur            w0, [x3, #0xf]
    // 0x8a930c: DecompressPointer r0
    //     0x8a930c: add             x0, x0, HEAP, lsl #32
    // 0x8a9310: mov             x4, x0
    // 0x8a9314: b               #0x8a9320
    // 0x8a9318: ldur            x3, [fp, #-0x10]
    // 0x8a931c: mov             x4, x0
    // 0x8a9320: ldur            x0, [fp, #-8]
    // 0x8a9324: stur            x4, [fp, #-0x28]
    // 0x8a9328: LoadField: r1 = r0->field_13
    //     0x8a9328: ldur            w1, [x0, #0x13]
    // 0x8a932c: DecompressPointer r1
    //     0x8a932c: add             x1, x1, HEAP, lsl #32
    // 0x8a9330: cmp             w1, NULL
    // 0x8a9334: b.ne            #0x8a9340
    // 0x8a9338: r0 = Null
    //     0x8a9338: mov             x0, NULL
    // 0x8a933c: b               #0x8a934c
    // 0x8a9340: LoadField: r2 = r3->field_13
    //     0x8a9340: ldur            w2, [x3, #0x13]
    // 0x8a9344: DecompressPointer r2
    //     0x8a9344: add             x2, x2, HEAP, lsl #32
    // 0x8a9348: r0 = merge()
    //     0x8a9348: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x8a934c: cmp             w0, NULL
    // 0x8a9350: b.ne            #0x8a9368
    // 0x8a9354: ldur            x3, [fp, #-0x10]
    // 0x8a9358: LoadField: r0 = r3->field_13
    //     0x8a9358: ldur            w0, [x3, #0x13]
    // 0x8a935c: DecompressPointer r0
    //     0x8a935c: add             x0, x0, HEAP, lsl #32
    // 0x8a9360: mov             x4, x0
    // 0x8a9364: b               #0x8a9370
    // 0x8a9368: ldur            x3, [fp, #-0x10]
    // 0x8a936c: mov             x4, x0
    // 0x8a9370: ldur            x0, [fp, #-8]
    // 0x8a9374: stur            x4, [fp, #-0x30]
    // 0x8a9378: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8a9378: ldur            w1, [x0, #0x17]
    // 0x8a937c: DecompressPointer r1
    //     0x8a937c: add             x1, x1, HEAP, lsl #32
    // 0x8a9380: cmp             w1, NULL
    // 0x8a9384: b.ne            #0x8a9390
    // 0x8a9388: r0 = Null
    //     0x8a9388: mov             x0, NULL
    // 0x8a938c: b               #0x8a939c
    // 0x8a9390: ArrayLoad: r2 = r3[0]  ; List_4
    //     0x8a9390: ldur            w2, [x3, #0x17]
    // 0x8a9394: DecompressPointer r2
    //     0x8a9394: add             x2, x2, HEAP, lsl #32
    // 0x8a9398: r0 = merge()
    //     0x8a9398: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x8a939c: cmp             w0, NULL
    // 0x8a93a0: b.ne            #0x8a93b8
    // 0x8a93a4: ldur            x3, [fp, #-0x10]
    // 0x8a93a8: ArrayLoad: r0 = r3[0]  ; List_4
    //     0x8a93a8: ldur            w0, [x3, #0x17]
    // 0x8a93ac: DecompressPointer r0
    //     0x8a93ac: add             x0, x0, HEAP, lsl #32
    // 0x8a93b0: mov             x4, x0
    // 0x8a93b4: b               #0x8a93c0
    // 0x8a93b8: ldur            x3, [fp, #-0x10]
    // 0x8a93bc: mov             x4, x0
    // 0x8a93c0: ldur            x0, [fp, #-8]
    // 0x8a93c4: stur            x4, [fp, #-0x38]
    // 0x8a93c8: LoadField: r1 = r0->field_1b
    //     0x8a93c8: ldur            w1, [x0, #0x1b]
    // 0x8a93cc: DecompressPointer r1
    //     0x8a93cc: add             x1, x1, HEAP, lsl #32
    // 0x8a93d0: cmp             w1, NULL
    // 0x8a93d4: b.ne            #0x8a93e0
    // 0x8a93d8: r0 = Null
    //     0x8a93d8: mov             x0, NULL
    // 0x8a93dc: b               #0x8a93ec
    // 0x8a93e0: LoadField: r2 = r3->field_1b
    //     0x8a93e0: ldur            w2, [x3, #0x1b]
    // 0x8a93e4: DecompressPointer r2
    //     0x8a93e4: add             x2, x2, HEAP, lsl #32
    // 0x8a93e8: r0 = merge()
    //     0x8a93e8: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x8a93ec: cmp             w0, NULL
    // 0x8a93f0: b.ne            #0x8a9408
    // 0x8a93f4: ldur            x3, [fp, #-0x10]
    // 0x8a93f8: LoadField: r0 = r3->field_1b
    //     0x8a93f8: ldur            w0, [x3, #0x1b]
    // 0x8a93fc: DecompressPointer r0
    //     0x8a93fc: add             x0, x0, HEAP, lsl #32
    // 0x8a9400: mov             x4, x0
    // 0x8a9404: b               #0x8a9410
    // 0x8a9408: ldur            x3, [fp, #-0x10]
    // 0x8a940c: mov             x4, x0
    // 0x8a9410: ldur            x0, [fp, #-8]
    // 0x8a9414: stur            x4, [fp, #-0x40]
    // 0x8a9418: LoadField: r1 = r0->field_1f
    //     0x8a9418: ldur            w1, [x0, #0x1f]
    // 0x8a941c: DecompressPointer r1
    //     0x8a941c: add             x1, x1, HEAP, lsl #32
    // 0x8a9420: cmp             w1, NULL
    // 0x8a9424: b.ne            #0x8a9430
    // 0x8a9428: r0 = Null
    //     0x8a9428: mov             x0, NULL
    // 0x8a942c: b               #0x8a943c
    // 0x8a9430: LoadField: r2 = r3->field_1f
    //     0x8a9430: ldur            w2, [x3, #0x1f]
    // 0x8a9434: DecompressPointer r2
    //     0x8a9434: add             x2, x2, HEAP, lsl #32
    // 0x8a9438: r0 = merge()
    //     0x8a9438: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x8a943c: cmp             w0, NULL
    // 0x8a9440: b.ne            #0x8a9458
    // 0x8a9444: ldur            x3, [fp, #-0x10]
    // 0x8a9448: LoadField: r0 = r3->field_1f
    //     0x8a9448: ldur            w0, [x3, #0x1f]
    // 0x8a944c: DecompressPointer r0
    //     0x8a944c: add             x0, x0, HEAP, lsl #32
    // 0x8a9450: mov             x4, x0
    // 0x8a9454: b               #0x8a9460
    // 0x8a9458: ldur            x3, [fp, #-0x10]
    // 0x8a945c: mov             x4, x0
    // 0x8a9460: ldur            x0, [fp, #-8]
    // 0x8a9464: stur            x4, [fp, #-0x48]
    // 0x8a9468: LoadField: r1 = r0->field_23
    //     0x8a9468: ldur            w1, [x0, #0x23]
    // 0x8a946c: DecompressPointer r1
    //     0x8a946c: add             x1, x1, HEAP, lsl #32
    // 0x8a9470: LoadField: r2 = r3->field_23
    //     0x8a9470: ldur            w2, [x3, #0x23]
    // 0x8a9474: DecompressPointer r2
    //     0x8a9474: add             x2, x2, HEAP, lsl #32
    // 0x8a9478: r0 = merge()
    //     0x8a9478: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x8a947c: mov             x3, x0
    // 0x8a9480: ldur            x0, [fp, #-8]
    // 0x8a9484: stur            x3, [fp, #-0x50]
    // 0x8a9488: LoadField: r1 = r0->field_27
    //     0x8a9488: ldur            w1, [x0, #0x27]
    // 0x8a948c: DecompressPointer r1
    //     0x8a948c: add             x1, x1, HEAP, lsl #32
    // 0x8a9490: cmp             w1, NULL
    // 0x8a9494: b.ne            #0x8a94a0
    // 0x8a9498: r0 = Null
    //     0x8a9498: mov             x0, NULL
    // 0x8a949c: b               #0x8a94b0
    // 0x8a94a0: ldur            x4, [fp, #-0x10]
    // 0x8a94a4: LoadField: r2 = r4->field_27
    //     0x8a94a4: ldur            w2, [x4, #0x27]
    // 0x8a94a8: DecompressPointer r2
    //     0x8a94a8: add             x2, x2, HEAP, lsl #32
    // 0x8a94ac: r0 = merge()
    //     0x8a94ac: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x8a94b0: cmp             w0, NULL
    // 0x8a94b4: b.ne            #0x8a94cc
    // 0x8a94b8: ldur            x3, [fp, #-0x10]
    // 0x8a94bc: LoadField: r0 = r3->field_27
    //     0x8a94bc: ldur            w0, [x3, #0x27]
    // 0x8a94c0: DecompressPointer r0
    //     0x8a94c0: add             x0, x0, HEAP, lsl #32
    // 0x8a94c4: mov             x4, x0
    // 0x8a94c8: b               #0x8a94d4
    // 0x8a94cc: ldur            x3, [fp, #-0x10]
    // 0x8a94d0: mov             x4, x0
    // 0x8a94d4: ldur            x0, [fp, #-8]
    // 0x8a94d8: stur            x4, [fp, #-0x58]
    // 0x8a94dc: LoadField: r1 = r0->field_2b
    //     0x8a94dc: ldur            w1, [x0, #0x2b]
    // 0x8a94e0: DecompressPointer r1
    //     0x8a94e0: add             x1, x1, HEAP, lsl #32
    // 0x8a94e4: LoadField: r2 = r3->field_2b
    //     0x8a94e4: ldur            w2, [x3, #0x2b]
    // 0x8a94e8: DecompressPointer r2
    //     0x8a94e8: add             x2, x2, HEAP, lsl #32
    // 0x8a94ec: r0 = merge()
    //     0x8a94ec: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x8a94f0: mov             x3, x0
    // 0x8a94f4: ldur            x0, [fp, #-8]
    // 0x8a94f8: stur            x3, [fp, #-0x60]
    // 0x8a94fc: LoadField: r1 = r0->field_2f
    //     0x8a94fc: ldur            w1, [x0, #0x2f]
    // 0x8a9500: DecompressPointer r1
    //     0x8a9500: add             x1, x1, HEAP, lsl #32
    // 0x8a9504: cmp             w1, NULL
    // 0x8a9508: b.ne            #0x8a9514
    // 0x8a950c: r0 = Null
    //     0x8a950c: mov             x0, NULL
    // 0x8a9510: b               #0x8a9524
    // 0x8a9514: ldur            x4, [fp, #-0x10]
    // 0x8a9518: LoadField: r2 = r4->field_2f
    //     0x8a9518: ldur            w2, [x4, #0x2f]
    // 0x8a951c: DecompressPointer r2
    //     0x8a951c: add             x2, x2, HEAP, lsl #32
    // 0x8a9520: r0 = merge()
    //     0x8a9520: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x8a9524: cmp             w0, NULL
    // 0x8a9528: b.ne            #0x8a9540
    // 0x8a952c: ldur            x3, [fp, #-0x10]
    // 0x8a9530: LoadField: r0 = r3->field_2f
    //     0x8a9530: ldur            w0, [x3, #0x2f]
    // 0x8a9534: DecompressPointer r0
    //     0x8a9534: add             x0, x0, HEAP, lsl #32
    // 0x8a9538: mov             x4, x0
    // 0x8a953c: b               #0x8a9548
    // 0x8a9540: ldur            x3, [fp, #-0x10]
    // 0x8a9544: mov             x4, x0
    // 0x8a9548: ldur            x0, [fp, #-8]
    // 0x8a954c: stur            x4, [fp, #-0x68]
    // 0x8a9550: LoadField: r1 = r0->field_33
    //     0x8a9550: ldur            w1, [x0, #0x33]
    // 0x8a9554: DecompressPointer r1
    //     0x8a9554: add             x1, x1, HEAP, lsl #32
    // 0x8a9558: cmp             w1, NULL
    // 0x8a955c: b.ne            #0x8a9568
    // 0x8a9560: r0 = Null
    //     0x8a9560: mov             x0, NULL
    // 0x8a9564: b               #0x8a9574
    // 0x8a9568: LoadField: r2 = r3->field_33
    //     0x8a9568: ldur            w2, [x3, #0x33]
    // 0x8a956c: DecompressPointer r2
    //     0x8a956c: add             x2, x2, HEAP, lsl #32
    // 0x8a9570: r0 = merge()
    //     0x8a9570: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x8a9574: cmp             w0, NULL
    // 0x8a9578: b.ne            #0x8a9590
    // 0x8a957c: ldur            x3, [fp, #-0x10]
    // 0x8a9580: LoadField: r0 = r3->field_33
    //     0x8a9580: ldur            w0, [x3, #0x33]
    // 0x8a9584: DecompressPointer r0
    //     0x8a9584: add             x0, x0, HEAP, lsl #32
    // 0x8a9588: mov             x5, x0
    // 0x8a958c: b               #0x8a9598
    // 0x8a9590: ldur            x3, [fp, #-0x10]
    // 0x8a9594: mov             x5, x0
    // 0x8a9598: ldur            x0, [fp, #-8]
    // 0x8a959c: stur            x5, [fp, #-0x70]
    // 0x8a95a0: LoadField: r1 = r0->field_37
    //     0x8a95a0: ldur            w1, [x0, #0x37]
    // 0x8a95a4: DecompressPointer r1
    //     0x8a95a4: add             x1, x1, HEAP, lsl #32
    // 0x8a95a8: LoadField: r2 = r3->field_37
    //     0x8a95a8: ldur            w2, [x3, #0x37]
    // 0x8a95ac: DecompressPointer r2
    //     0x8a95ac: add             x2, x2, HEAP, lsl #32
    // 0x8a95b0: r0 = merge()
    //     0x8a95b0: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x8a95b4: mov             x3, x0
    // 0x8a95b8: ldur            x0, [fp, #-8]
    // 0x8a95bc: stur            x3, [fp, #-0x78]
    // 0x8a95c0: LoadField: r1 = r0->field_3b
    //     0x8a95c0: ldur            w1, [x0, #0x3b]
    // 0x8a95c4: DecompressPointer r1
    //     0x8a95c4: add             x1, x1, HEAP, lsl #32
    // 0x8a95c8: cmp             w1, NULL
    // 0x8a95cc: b.ne            #0x8a95d8
    // 0x8a95d0: r0 = Null
    //     0x8a95d0: mov             x0, NULL
    // 0x8a95d4: b               #0x8a95e8
    // 0x8a95d8: ldur            x4, [fp, #-0x10]
    // 0x8a95dc: LoadField: r2 = r4->field_3b
    //     0x8a95dc: ldur            w2, [x4, #0x3b]
    // 0x8a95e0: DecompressPointer r2
    //     0x8a95e0: add             x2, x2, HEAP, lsl #32
    // 0x8a95e4: r0 = merge()
    //     0x8a95e4: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x8a95e8: cmp             w0, NULL
    // 0x8a95ec: b.ne            #0x8a9604
    // 0x8a95f0: ldur            x3, [fp, #-0x10]
    // 0x8a95f4: LoadField: r0 = r3->field_3b
    //     0x8a95f4: ldur            w0, [x3, #0x3b]
    // 0x8a95f8: DecompressPointer r0
    //     0x8a95f8: add             x0, x0, HEAP, lsl #32
    // 0x8a95fc: mov             x4, x0
    // 0x8a9600: b               #0x8a960c
    // 0x8a9604: ldur            x3, [fp, #-0x10]
    // 0x8a9608: mov             x4, x0
    // 0x8a960c: ldur            x0, [fp, #-8]
    // 0x8a9610: stur            x4, [fp, #-0x80]
    // 0x8a9614: LoadField: r1 = r0->field_3f
    //     0x8a9614: ldur            w1, [x0, #0x3f]
    // 0x8a9618: DecompressPointer r1
    //     0x8a9618: add             x1, x1, HEAP, lsl #32
    // 0x8a961c: cmp             w1, NULL
    // 0x8a9620: b.ne            #0x8a962c
    // 0x8a9624: r0 = Null
    //     0x8a9624: mov             x0, NULL
    // 0x8a9628: b               #0x8a9638
    // 0x8a962c: LoadField: r2 = r3->field_3f
    //     0x8a962c: ldur            w2, [x3, #0x3f]
    // 0x8a9630: DecompressPointer r2
    //     0x8a9630: add             x2, x2, HEAP, lsl #32
    // 0x8a9634: r0 = merge()
    //     0x8a9634: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x8a9638: cmp             w0, NULL
    // 0x8a963c: b.ne            #0x8a9650
    // 0x8a9640: ldur            x0, [fp, #-0x10]
    // 0x8a9644: LoadField: r1 = r0->field_3f
    //     0x8a9644: ldur            w1, [x0, #0x3f]
    // 0x8a9648: DecompressPointer r1
    //     0x8a9648: add             x1, x1, HEAP, lsl #32
    // 0x8a964c: mov             x0, x1
    // 0x8a9650: ldur            x16, [fp, #-0x28]
    // 0x8a9654: ldur            lr, [fp, #-0x30]
    // 0x8a9658: stp             lr, x16, [SP, #0x40]
    // 0x8a965c: ldur            x16, [fp, #-0x38]
    // 0x8a9660: ldur            lr, [fp, #-0x40]
    // 0x8a9664: stp             lr, x16, [SP, #0x30]
    // 0x8a9668: ldur            x16, [fp, #-0x78]
    // 0x8a966c: ldur            lr, [fp, #-0x80]
    // 0x8a9670: stp             lr, x16, [SP, #0x20]
    // 0x8a9674: ldur            x16, [fp, #-0x48]
    // 0x8a9678: stp             x16, x0, [SP, #0x10]
    // 0x8a967c: ldur            x16, [fp, #-0x50]
    // 0x8a9680: ldur            lr, [fp, #-0x58]
    // 0x8a9684: stp             lr, x16, [SP]
    // 0x8a9688: ldur            x1, [fp, #-8]
    // 0x8a968c: ldur            x2, [fp, #-0x60]
    // 0x8a9690: ldur            x3, [fp, #-0x68]
    // 0x8a9694: ldur            x5, [fp, #-0x70]
    // 0x8a9698: ldur            x6, [fp, #-0x18]
    // 0x8a969c: ldur            x7, [fp, #-0x20]
    // 0x8a96a0: r0 = copyWith()
    //     0x8a96a0: bl              #0x8a96b8  ; [package:flutter/src/material/text_theme.dart] TextTheme::copyWith
    // 0x8a96a4: LeaveFrame
    //     0x8a96a4: mov             SP, fp
    //     0x8a96a8: ldp             fp, lr, [SP], #0x10
    // 0x8a96ac: ret
    //     0x8a96ac: ret             
    // 0x8a96b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a96b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a96b4: b               #0x8a9220
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x8a96b8, size: 0x224
    // 0x8a96b8: EnterFrame
    //     0x8a96b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8a96bc: mov             fp, SP
    // 0x8a96c0: AllocStack(0x68)
    //     0x8a96c0: sub             SP, SP, #0x68
    // 0x8a96c4: SetupParameters(dynamic _ /* r2 => r2, fp-0x68 */)
    //     0x8a96c4: stur            x2, [fp, #-0x68]
    // 0x8a96c8: cmp             w6, NULL
    // 0x8a96cc: b.ne            #0x8a96dc
    // 0x8a96d0: LoadField: r0 = r1->field_7
    //     0x8a96d0: ldur            w0, [x1, #7]
    // 0x8a96d4: DecompressPointer r0
    //     0x8a96d4: add             x0, x0, HEAP, lsl #32
    // 0x8a96d8: b               #0x8a96e0
    // 0x8a96dc: mov             x0, x6
    // 0x8a96e0: stur            x0, [fp, #-0x60]
    // 0x8a96e4: cmp             w7, NULL
    // 0x8a96e8: b.ne            #0x8a96fc
    // 0x8a96ec: LoadField: r4 = r1->field_b
    //     0x8a96ec: ldur            w4, [x1, #0xb]
    // 0x8a96f0: DecompressPointer r4
    //     0x8a96f0: add             x4, x4, HEAP, lsl #32
    // 0x8a96f4: mov             x6, x4
    // 0x8a96f8: b               #0x8a9700
    // 0x8a96fc: mov             x6, x7
    // 0x8a9700: ldr             x4, [fp, #0x58]
    // 0x8a9704: stur            x6, [fp, #-0x58]
    // 0x8a9708: cmp             w4, NULL
    // 0x8a970c: b.ne            #0x8a9720
    // 0x8a9710: LoadField: r4 = r1->field_f
    //     0x8a9710: ldur            w4, [x1, #0xf]
    // 0x8a9714: DecompressPointer r4
    //     0x8a9714: add             x4, x4, HEAP, lsl #32
    // 0x8a9718: mov             x7, x4
    // 0x8a971c: b               #0x8a9724
    // 0x8a9720: mov             x7, x4
    // 0x8a9724: ldr             x4, [fp, #0x50]
    // 0x8a9728: stur            x7, [fp, #-0x50]
    // 0x8a972c: cmp             w4, NULL
    // 0x8a9730: b.ne            #0x8a9744
    // 0x8a9734: LoadField: r4 = r1->field_13
    //     0x8a9734: ldur            w4, [x1, #0x13]
    // 0x8a9738: DecompressPointer r4
    //     0x8a9738: add             x4, x4, HEAP, lsl #32
    // 0x8a973c: mov             x8, x4
    // 0x8a9740: b               #0x8a9748
    // 0x8a9744: mov             x8, x4
    // 0x8a9748: ldr             x4, [fp, #0x48]
    // 0x8a974c: stur            x8, [fp, #-0x48]
    // 0x8a9750: cmp             w4, NULL
    // 0x8a9754: b.ne            #0x8a9768
    // 0x8a9758: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x8a9758: ldur            w4, [x1, #0x17]
    // 0x8a975c: DecompressPointer r4
    //     0x8a975c: add             x4, x4, HEAP, lsl #32
    // 0x8a9760: mov             x9, x4
    // 0x8a9764: b               #0x8a976c
    // 0x8a9768: mov             x9, x4
    // 0x8a976c: ldr             x4, [fp, #0x40]
    // 0x8a9770: stur            x9, [fp, #-0x40]
    // 0x8a9774: cmp             w4, NULL
    // 0x8a9778: b.ne            #0x8a978c
    // 0x8a977c: LoadField: r4 = r1->field_1b
    //     0x8a977c: ldur            w4, [x1, #0x1b]
    // 0x8a9780: DecompressPointer r4
    //     0x8a9780: add             x4, x4, HEAP, lsl #32
    // 0x8a9784: mov             x10, x4
    // 0x8a9788: b               #0x8a9790
    // 0x8a978c: mov             x10, x4
    // 0x8a9790: ldr             x4, [fp, #0x20]
    // 0x8a9794: stur            x10, [fp, #-0x38]
    // 0x8a9798: cmp             w4, NULL
    // 0x8a979c: b.ne            #0x8a97b0
    // 0x8a97a0: LoadField: r4 = r1->field_1f
    //     0x8a97a0: ldur            w4, [x1, #0x1f]
    // 0x8a97a4: DecompressPointer r4
    //     0x8a97a4: add             x4, x4, HEAP, lsl #32
    // 0x8a97a8: mov             x11, x4
    // 0x8a97ac: b               #0x8a97b4
    // 0x8a97b0: mov             x11, x4
    // 0x8a97b4: ldr             x4, [fp, #0x10]
    // 0x8a97b8: stur            x11, [fp, #-0x30]
    // 0x8a97bc: cmp             w4, NULL
    // 0x8a97c0: b.ne            #0x8a97cc
    // 0x8a97c4: LoadField: r4 = r1->field_27
    //     0x8a97c4: ldur            w4, [x1, #0x27]
    // 0x8a97c8: DecompressPointer r4
    //     0x8a97c8: add             x4, x4, HEAP, lsl #32
    // 0x8a97cc: stur            x4, [fp, #-0x28]
    // 0x8a97d0: cmp             w3, NULL
    // 0x8a97d4: b.ne            #0x8a97e0
    // 0x8a97d8: LoadField: r3 = r1->field_2f
    //     0x8a97d8: ldur            w3, [x1, #0x2f]
    // 0x8a97dc: DecompressPointer r3
    //     0x8a97dc: add             x3, x3, HEAP, lsl #32
    // 0x8a97e0: stur            x3, [fp, #-0x20]
    // 0x8a97e4: cmp             w5, NULL
    // 0x8a97e8: b.ne            #0x8a97fc
    // 0x8a97ec: LoadField: r5 = r1->field_33
    //     0x8a97ec: ldur            w5, [x1, #0x33]
    // 0x8a97f0: DecompressPointer r5
    //     0x8a97f0: add             x5, x5, HEAP, lsl #32
    // 0x8a97f4: mov             x12, x5
    // 0x8a97f8: b               #0x8a9800
    // 0x8a97fc: mov             x12, x5
    // 0x8a9800: ldr             x5, [fp, #0x30]
    // 0x8a9804: stur            x12, [fp, #-0x18]
    // 0x8a9808: cmp             w5, NULL
    // 0x8a980c: b.ne            #0x8a9820
    // 0x8a9810: LoadField: r5 = r1->field_3b
    //     0x8a9810: ldur            w5, [x1, #0x3b]
    // 0x8a9814: DecompressPointer r5
    //     0x8a9814: add             x5, x5, HEAP, lsl #32
    // 0x8a9818: mov             x13, x5
    // 0x8a981c: b               #0x8a9824
    // 0x8a9820: mov             x13, x5
    // 0x8a9824: ldr             x5, [fp, #0x28]
    // 0x8a9828: stur            x13, [fp, #-0x10]
    // 0x8a982c: cmp             w5, NULL
    // 0x8a9830: b.ne            #0x8a9844
    // 0x8a9834: LoadField: r5 = r1->field_3f
    //     0x8a9834: ldur            w5, [x1, #0x3f]
    // 0x8a9838: DecompressPointer r5
    //     0x8a9838: add             x5, x5, HEAP, lsl #32
    // 0x8a983c: mov             x14, x5
    // 0x8a9840: b               #0x8a9848
    // 0x8a9844: mov             x14, x5
    // 0x8a9848: ldr             x5, [fp, #0x38]
    // 0x8a984c: ldr             x1, [fp, #0x18]
    // 0x8a9850: stur            x14, [fp, #-8]
    // 0x8a9854: r0 = TextTheme()
    //     0x8a9854: bl              #0x8a98dc  ; AllocateTextThemeStub -> TextTheme (size=0x44)
    // 0x8a9858: ldur            x1, [fp, #-0x60]
    // 0x8a985c: StoreField: r0->field_7 = r1
    //     0x8a985c: stur            w1, [x0, #7]
    // 0x8a9860: ldur            x1, [fp, #-0x58]
    // 0x8a9864: StoreField: r0->field_b = r1
    //     0x8a9864: stur            w1, [x0, #0xb]
    // 0x8a9868: ldur            x1, [fp, #-0x50]
    // 0x8a986c: StoreField: r0->field_f = r1
    //     0x8a986c: stur            w1, [x0, #0xf]
    // 0x8a9870: ldur            x1, [fp, #-0x48]
    // 0x8a9874: StoreField: r0->field_13 = r1
    //     0x8a9874: stur            w1, [x0, #0x13]
    // 0x8a9878: ldur            x1, [fp, #-0x40]
    // 0x8a987c: ArrayStore: r0[0] = r1  ; List_4
    //     0x8a987c: stur            w1, [x0, #0x17]
    // 0x8a9880: ldur            x1, [fp, #-0x38]
    // 0x8a9884: StoreField: r0->field_1b = r1
    //     0x8a9884: stur            w1, [x0, #0x1b]
    // 0x8a9888: ldur            x1, [fp, #-0x30]
    // 0x8a988c: StoreField: r0->field_1f = r1
    //     0x8a988c: stur            w1, [x0, #0x1f]
    // 0x8a9890: ldr             x1, [fp, #0x18]
    // 0x8a9894: StoreField: r0->field_23 = r1
    //     0x8a9894: stur            w1, [x0, #0x23]
    // 0x8a9898: ldur            x1, [fp, #-0x28]
    // 0x8a989c: StoreField: r0->field_27 = r1
    //     0x8a989c: stur            w1, [x0, #0x27]
    // 0x8a98a0: ldur            x1, [fp, #-0x68]
    // 0x8a98a4: StoreField: r0->field_2b = r1
    //     0x8a98a4: stur            w1, [x0, #0x2b]
    // 0x8a98a8: ldur            x1, [fp, #-0x20]
    // 0x8a98ac: StoreField: r0->field_2f = r1
    //     0x8a98ac: stur            w1, [x0, #0x2f]
    // 0x8a98b0: ldur            x1, [fp, #-0x18]
    // 0x8a98b4: StoreField: r0->field_33 = r1
    //     0x8a98b4: stur            w1, [x0, #0x33]
    // 0x8a98b8: ldr             x1, [fp, #0x38]
    // 0x8a98bc: StoreField: r0->field_37 = r1
    //     0x8a98bc: stur            w1, [x0, #0x37]
    // 0x8a98c0: ldur            x1, [fp, #-0x10]
    // 0x8a98c4: StoreField: r0->field_3b = r1
    //     0x8a98c4: stur            w1, [x0, #0x3b]
    // 0x8a98c8: ldur            x1, [fp, #-8]
    // 0x8a98cc: StoreField: r0->field_3f = r1
    //     0x8a98cc: stur            w1, [x0, #0x3f]
    // 0x8a98d0: LeaveFrame
    //     0x8a98d0: mov             SP, fp
    //     0x8a98d4: ldp             fp, lr, [SP], #0x10
    // 0x8a98d8: ret
    //     0x8a98d8: ret             
  }
  _ apply(/* No info */) {
    // ** addr: 0x8acad0, size: 0x450
    // 0x8acad0: EnterFrame
    //     0x8acad0: stp             fp, lr, [SP, #-0x10]!
    //     0x8acad4: mov             fp, SP
    // 0x8acad8: AllocStack(0x90)
    //     0x8acad8: sub             SP, SP, #0x90
    // 0x8acadc: SetupParameters(TextTheme this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r0, fp-0x20 */)
    //     0x8acadc: mov             x0, x5
    //     0x8acae0: stur            x5, [fp, #-0x20]
    //     0x8acae4: mov             x5, x1
    //     0x8acae8: mov             x4, x2
    //     0x8acaec: stur            x1, [fp, #-8]
    //     0x8acaf0: stur            x2, [fp, #-0x10]
    //     0x8acaf4: stur            x3, [fp, #-0x18]
    // 0x8acaf8: CheckStackOverflow
    //     0x8acaf8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8acafc: cmp             SP, x16
    //     0x8acb00: b.ls            #0x8acf18
    // 0x8acb04: LoadField: r1 = r5->field_7
    //     0x8acb04: ldur            w1, [x5, #7]
    // 0x8acb08: DecompressPointer r1
    //     0x8acb08: add             x1, x1, HEAP, lsl #32
    // 0x8acb0c: cmp             w1, NULL
    // 0x8acb10: b.ne            #0x8acb20
    // 0x8acb14: mov             x0, x5
    // 0x8acb18: r3 = Null
    //     0x8acb18: mov             x3, NULL
    // 0x8acb1c: b               #0x8acb3c
    // 0x8acb20: str             x3, [SP]
    // 0x8acb24: mov             x2, x0
    // 0x8acb28: r4 = const [0, 0x3, 0x1, 0x2, decorationColor, 0x2, null]
    //     0x8acb28: add             x4, PP, #0x12, lsl #12  ; [pp+0x12ed8] List(7) [0, 0x3, 0x1, 0x2, "decorationColor", 0x2, Null]
    //     0x8acb2c: ldr             x4, [x4, #0xed8]
    // 0x8acb30: r0 = apply()
    //     0x8acb30: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x8acb34: mov             x3, x0
    // 0x8acb38: ldur            x0, [fp, #-8]
    // 0x8acb3c: stur            x3, [fp, #-0x28]
    // 0x8acb40: LoadField: r1 = r0->field_b
    //     0x8acb40: ldur            w1, [x0, #0xb]
    // 0x8acb44: DecompressPointer r1
    //     0x8acb44: add             x1, x1, HEAP, lsl #32
    // 0x8acb48: cmp             w1, NULL
    // 0x8acb4c: b.ne            #0x8acb58
    // 0x8acb50: r3 = Null
    //     0x8acb50: mov             x3, NULL
    // 0x8acb54: b               #0x8acb78
    // 0x8acb58: ldur            x16, [fp, #-0x18]
    // 0x8acb5c: str             x16, [SP]
    // 0x8acb60: ldur            x2, [fp, #-0x20]
    // 0x8acb64: r4 = const [0, 0x3, 0x1, 0x2, decorationColor, 0x2, null]
    //     0x8acb64: add             x4, PP, #0x12, lsl #12  ; [pp+0x12ed8] List(7) [0, 0x3, 0x1, 0x2, "decorationColor", 0x2, Null]
    //     0x8acb68: ldr             x4, [x4, #0xed8]
    // 0x8acb6c: r0 = apply()
    //     0x8acb6c: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x8acb70: mov             x3, x0
    // 0x8acb74: ldur            x0, [fp, #-8]
    // 0x8acb78: stur            x3, [fp, #-0x30]
    // 0x8acb7c: LoadField: r1 = r0->field_f
    //     0x8acb7c: ldur            w1, [x0, #0xf]
    // 0x8acb80: DecompressPointer r1
    //     0x8acb80: add             x1, x1, HEAP, lsl #32
    // 0x8acb84: cmp             w1, NULL
    // 0x8acb88: b.ne            #0x8acb94
    // 0x8acb8c: r3 = Null
    //     0x8acb8c: mov             x3, NULL
    // 0x8acb90: b               #0x8acbb4
    // 0x8acb94: ldur            x16, [fp, #-0x18]
    // 0x8acb98: str             x16, [SP]
    // 0x8acb9c: ldur            x2, [fp, #-0x20]
    // 0x8acba0: r4 = const [0, 0x3, 0x1, 0x2, decorationColor, 0x2, null]
    //     0x8acba0: add             x4, PP, #0x12, lsl #12  ; [pp+0x12ed8] List(7) [0, 0x3, 0x1, 0x2, "decorationColor", 0x2, Null]
    //     0x8acba4: ldr             x4, [x4, #0xed8]
    // 0x8acba8: r0 = apply()
    //     0x8acba8: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x8acbac: mov             x3, x0
    // 0x8acbb0: ldur            x0, [fp, #-8]
    // 0x8acbb4: stur            x3, [fp, #-0x38]
    // 0x8acbb8: LoadField: r1 = r0->field_13
    //     0x8acbb8: ldur            w1, [x0, #0x13]
    // 0x8acbbc: DecompressPointer r1
    //     0x8acbbc: add             x1, x1, HEAP, lsl #32
    // 0x8acbc0: cmp             w1, NULL
    // 0x8acbc4: b.ne            #0x8acbd0
    // 0x8acbc8: r3 = Null
    //     0x8acbc8: mov             x3, NULL
    // 0x8acbcc: b               #0x8acbf0
    // 0x8acbd0: ldur            x16, [fp, #-0x18]
    // 0x8acbd4: str             x16, [SP]
    // 0x8acbd8: ldur            x2, [fp, #-0x20]
    // 0x8acbdc: r4 = const [0, 0x3, 0x1, 0x2, decorationColor, 0x2, null]
    //     0x8acbdc: add             x4, PP, #0x12, lsl #12  ; [pp+0x12ed8] List(7) [0, 0x3, 0x1, 0x2, "decorationColor", 0x2, Null]
    //     0x8acbe0: ldr             x4, [x4, #0xed8]
    // 0x8acbe4: r0 = apply()
    //     0x8acbe4: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x8acbe8: mov             x3, x0
    // 0x8acbec: ldur            x0, [fp, #-8]
    // 0x8acbf0: stur            x3, [fp, #-0x40]
    // 0x8acbf4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8acbf4: ldur            w1, [x0, #0x17]
    // 0x8acbf8: DecompressPointer r1
    //     0x8acbf8: add             x1, x1, HEAP, lsl #32
    // 0x8acbfc: cmp             w1, NULL
    // 0x8acc00: b.ne            #0x8acc0c
    // 0x8acc04: r3 = Null
    //     0x8acc04: mov             x3, NULL
    // 0x8acc08: b               #0x8acc2c
    // 0x8acc0c: ldur            x16, [fp, #-0x18]
    // 0x8acc10: str             x16, [SP]
    // 0x8acc14: ldur            x2, [fp, #-0x20]
    // 0x8acc18: r4 = const [0, 0x3, 0x1, 0x2, decorationColor, 0x2, null]
    //     0x8acc18: add             x4, PP, #0x12, lsl #12  ; [pp+0x12ed8] List(7) [0, 0x3, 0x1, 0x2, "decorationColor", 0x2, Null]
    //     0x8acc1c: ldr             x4, [x4, #0xed8]
    // 0x8acc20: r0 = apply()
    //     0x8acc20: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x8acc24: mov             x3, x0
    // 0x8acc28: ldur            x0, [fp, #-8]
    // 0x8acc2c: stur            x3, [fp, #-0x48]
    // 0x8acc30: LoadField: r1 = r0->field_1b
    //     0x8acc30: ldur            w1, [x0, #0x1b]
    // 0x8acc34: DecompressPointer r1
    //     0x8acc34: add             x1, x1, HEAP, lsl #32
    // 0x8acc38: cmp             w1, NULL
    // 0x8acc3c: b.ne            #0x8acc48
    // 0x8acc40: r3 = Null
    //     0x8acc40: mov             x3, NULL
    // 0x8acc44: b               #0x8acc68
    // 0x8acc48: ldur            x16, [fp, #-0x18]
    // 0x8acc4c: str             x16, [SP]
    // 0x8acc50: ldur            x2, [fp, #-0x10]
    // 0x8acc54: r4 = const [0, 0x3, 0x1, 0x2, decorationColor, 0x2, null]
    //     0x8acc54: add             x4, PP, #0x12, lsl #12  ; [pp+0x12ed8] List(7) [0, 0x3, 0x1, 0x2, "decorationColor", 0x2, Null]
    //     0x8acc58: ldr             x4, [x4, #0xed8]
    // 0x8acc5c: r0 = apply()
    //     0x8acc5c: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x8acc60: mov             x3, x0
    // 0x8acc64: ldur            x0, [fp, #-8]
    // 0x8acc68: stur            x3, [fp, #-0x50]
    // 0x8acc6c: LoadField: r1 = r0->field_1f
    //     0x8acc6c: ldur            w1, [x0, #0x1f]
    // 0x8acc70: DecompressPointer r1
    //     0x8acc70: add             x1, x1, HEAP, lsl #32
    // 0x8acc74: cmp             w1, NULL
    // 0x8acc78: b.ne            #0x8acc84
    // 0x8acc7c: r3 = Null
    //     0x8acc7c: mov             x3, NULL
    // 0x8acc80: b               #0x8acca4
    // 0x8acc84: ldur            x16, [fp, #-0x18]
    // 0x8acc88: str             x16, [SP]
    // 0x8acc8c: ldur            x2, [fp, #-0x10]
    // 0x8acc90: r4 = const [0, 0x3, 0x1, 0x2, decorationColor, 0x2, null]
    //     0x8acc90: add             x4, PP, #0x12, lsl #12  ; [pp+0x12ed8] List(7) [0, 0x3, 0x1, 0x2, "decorationColor", 0x2, Null]
    //     0x8acc94: ldr             x4, [x4, #0xed8]
    // 0x8acc98: r0 = apply()
    //     0x8acc98: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x8acc9c: mov             x3, x0
    // 0x8acca0: ldur            x0, [fp, #-8]
    // 0x8acca4: stur            x3, [fp, #-0x58]
    // 0x8acca8: LoadField: r1 = r0->field_23
    //     0x8acca8: ldur            w1, [x0, #0x23]
    // 0x8accac: DecompressPointer r1
    //     0x8accac: add             x1, x1, HEAP, lsl #32
    // 0x8accb0: ldur            x16, [fp, #-0x18]
    // 0x8accb4: str             x16, [SP]
    // 0x8accb8: ldur            x2, [fp, #-0x10]
    // 0x8accbc: r4 = const [0, 0x3, 0x1, 0x2, decorationColor, 0x2, null]
    //     0x8accbc: add             x4, PP, #0x12, lsl #12  ; [pp+0x12ed8] List(7) [0, 0x3, 0x1, 0x2, "decorationColor", 0x2, Null]
    //     0x8accc0: ldr             x4, [x4, #0xed8]
    // 0x8accc4: r0 = apply()
    //     0x8accc4: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x8accc8: mov             x3, x0
    // 0x8acccc: ldur            x0, [fp, #-8]
    // 0x8accd0: stur            x3, [fp, #-0x60]
    // 0x8accd4: LoadField: r1 = r0->field_27
    //     0x8accd4: ldur            w1, [x0, #0x27]
    // 0x8accd8: DecompressPointer r1
    //     0x8accd8: add             x1, x1, HEAP, lsl #32
    // 0x8accdc: cmp             w1, NULL
    // 0x8acce0: b.ne            #0x8accec
    // 0x8acce4: r3 = Null
    //     0x8acce4: mov             x3, NULL
    // 0x8acce8: b               #0x8acd0c
    // 0x8accec: ldur            x16, [fp, #-0x18]
    // 0x8accf0: str             x16, [SP]
    // 0x8accf4: ldur            x2, [fp, #-0x10]
    // 0x8accf8: r4 = const [0, 0x3, 0x1, 0x2, decorationColor, 0x2, null]
    //     0x8accf8: add             x4, PP, #0x12, lsl #12  ; [pp+0x12ed8] List(7) [0, 0x3, 0x1, 0x2, "decorationColor", 0x2, Null]
    //     0x8accfc: ldr             x4, [x4, #0xed8]
    // 0x8acd00: r0 = apply()
    //     0x8acd00: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x8acd04: mov             x3, x0
    // 0x8acd08: ldur            x0, [fp, #-8]
    // 0x8acd0c: stur            x3, [fp, #-0x68]
    // 0x8acd10: LoadField: r1 = r0->field_2b
    //     0x8acd10: ldur            w1, [x0, #0x2b]
    // 0x8acd14: DecompressPointer r1
    //     0x8acd14: add             x1, x1, HEAP, lsl #32
    // 0x8acd18: ldur            x16, [fp, #-0x18]
    // 0x8acd1c: str             x16, [SP]
    // 0x8acd20: ldur            x2, [fp, #-0x10]
    // 0x8acd24: r4 = const [0, 0x3, 0x1, 0x2, decorationColor, 0x2, null]
    //     0x8acd24: add             x4, PP, #0x12, lsl #12  ; [pp+0x12ed8] List(7) [0, 0x3, 0x1, 0x2, "decorationColor", 0x2, Null]
    //     0x8acd28: ldr             x4, [x4, #0xed8]
    // 0x8acd2c: r0 = apply()
    //     0x8acd2c: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x8acd30: mov             x3, x0
    // 0x8acd34: ldur            x0, [fp, #-8]
    // 0x8acd38: stur            x3, [fp, #-0x70]
    // 0x8acd3c: LoadField: r1 = r0->field_2f
    //     0x8acd3c: ldur            w1, [x0, #0x2f]
    // 0x8acd40: DecompressPointer r1
    //     0x8acd40: add             x1, x1, HEAP, lsl #32
    // 0x8acd44: cmp             w1, NULL
    // 0x8acd48: b.ne            #0x8acd54
    // 0x8acd4c: r3 = Null
    //     0x8acd4c: mov             x3, NULL
    // 0x8acd50: b               #0x8acd74
    // 0x8acd54: ldur            x16, [fp, #-0x18]
    // 0x8acd58: str             x16, [SP]
    // 0x8acd5c: ldur            x2, [fp, #-0x10]
    // 0x8acd60: r4 = const [0, 0x3, 0x1, 0x2, decorationColor, 0x2, null]
    //     0x8acd60: add             x4, PP, #0x12, lsl #12  ; [pp+0x12ed8] List(7) [0, 0x3, 0x1, 0x2, "decorationColor", 0x2, Null]
    //     0x8acd64: ldr             x4, [x4, #0xed8]
    // 0x8acd68: r0 = apply()
    //     0x8acd68: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x8acd6c: mov             x3, x0
    // 0x8acd70: ldur            x0, [fp, #-8]
    // 0x8acd74: stur            x3, [fp, #-0x78]
    // 0x8acd78: LoadField: r1 = r0->field_33
    //     0x8acd78: ldur            w1, [x0, #0x33]
    // 0x8acd7c: DecompressPointer r1
    //     0x8acd7c: add             x1, x1, HEAP, lsl #32
    // 0x8acd80: cmp             w1, NULL
    // 0x8acd84: b.ne            #0x8acd90
    // 0x8acd88: r3 = Null
    //     0x8acd88: mov             x3, NULL
    // 0x8acd8c: b               #0x8acdb0
    // 0x8acd90: ldur            x16, [fp, #-0x18]
    // 0x8acd94: str             x16, [SP]
    // 0x8acd98: ldur            x2, [fp, #-0x20]
    // 0x8acd9c: r4 = const [0, 0x3, 0x1, 0x2, decorationColor, 0x2, null]
    //     0x8acd9c: add             x4, PP, #0x12, lsl #12  ; [pp+0x12ed8] List(7) [0, 0x3, 0x1, 0x2, "decorationColor", 0x2, Null]
    //     0x8acda0: ldr             x4, [x4, #0xed8]
    // 0x8acda4: r0 = apply()
    //     0x8acda4: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x8acda8: mov             x3, x0
    // 0x8acdac: ldur            x0, [fp, #-8]
    // 0x8acdb0: stur            x3, [fp, #-0x20]
    // 0x8acdb4: LoadField: r1 = r0->field_37
    //     0x8acdb4: ldur            w1, [x0, #0x37]
    // 0x8acdb8: DecompressPointer r1
    //     0x8acdb8: add             x1, x1, HEAP, lsl #32
    // 0x8acdbc: ldur            x16, [fp, #-0x18]
    // 0x8acdc0: str             x16, [SP]
    // 0x8acdc4: ldur            x2, [fp, #-0x10]
    // 0x8acdc8: r4 = const [0, 0x3, 0x1, 0x2, decorationColor, 0x2, null]
    //     0x8acdc8: add             x4, PP, #0x12, lsl #12  ; [pp+0x12ed8] List(7) [0, 0x3, 0x1, 0x2, "decorationColor", 0x2, Null]
    //     0x8acdcc: ldr             x4, [x4, #0xed8]
    // 0x8acdd0: r0 = apply()
    //     0x8acdd0: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x8acdd4: mov             x3, x0
    // 0x8acdd8: ldur            x0, [fp, #-8]
    // 0x8acddc: stur            x3, [fp, #-0x80]
    // 0x8acde0: LoadField: r1 = r0->field_3b
    //     0x8acde0: ldur            w1, [x0, #0x3b]
    // 0x8acde4: DecompressPointer r1
    //     0x8acde4: add             x1, x1, HEAP, lsl #32
    // 0x8acde8: cmp             w1, NULL
    // 0x8acdec: b.ne            #0x8acdf8
    // 0x8acdf0: r3 = Null
    //     0x8acdf0: mov             x3, NULL
    // 0x8acdf4: b               #0x8ace18
    // 0x8acdf8: ldur            x16, [fp, #-0x18]
    // 0x8acdfc: str             x16, [SP]
    // 0x8ace00: ldur            x2, [fp, #-0x10]
    // 0x8ace04: r4 = const [0, 0x3, 0x1, 0x2, decorationColor, 0x2, null]
    //     0x8ace04: add             x4, PP, #0x12, lsl #12  ; [pp+0x12ed8] List(7) [0, 0x3, 0x1, 0x2, "decorationColor", 0x2, Null]
    //     0x8ace08: ldr             x4, [x4, #0xed8]
    // 0x8ace0c: r0 = apply()
    //     0x8ace0c: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x8ace10: mov             x3, x0
    // 0x8ace14: ldur            x0, [fp, #-8]
    // 0x8ace18: stur            x3, [fp, #-0x88]
    // 0x8ace1c: LoadField: r1 = r0->field_3f
    //     0x8ace1c: ldur            w1, [x0, #0x3f]
    // 0x8ace20: DecompressPointer r1
    //     0x8ace20: add             x1, x1, HEAP, lsl #32
    // 0x8ace24: cmp             w1, NULL
    // 0x8ace28: b.ne            #0x8ace38
    // 0x8ace2c: mov             x0, x3
    // 0x8ace30: r14 = Null
    //     0x8ace30: mov             x14, NULL
    // 0x8ace34: b               #0x8ace58
    // 0x8ace38: ldur            x16, [fp, #-0x18]
    // 0x8ace3c: str             x16, [SP]
    // 0x8ace40: ldur            x2, [fp, #-0x10]
    // 0x8ace44: r4 = const [0, 0x3, 0x1, 0x2, decorationColor, 0x2, null]
    //     0x8ace44: add             x4, PP, #0x12, lsl #12  ; [pp+0x12ed8] List(7) [0, 0x3, 0x1, 0x2, "decorationColor", 0x2, Null]
    //     0x8ace48: ldr             x4, [x4, #0xed8]
    // 0x8ace4c: r0 = apply()
    //     0x8ace4c: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x8ace50: mov             x14, x0
    // 0x8ace54: ldur            x0, [fp, #-0x88]
    // 0x8ace58: ldur            x13, [fp, #-0x28]
    // 0x8ace5c: ldur            x12, [fp, #-0x30]
    // 0x8ace60: ldur            x11, [fp, #-0x38]
    // 0x8ace64: ldur            x10, [fp, #-0x40]
    // 0x8ace68: ldur            x9, [fp, #-0x48]
    // 0x8ace6c: ldur            x8, [fp, #-0x50]
    // 0x8ace70: ldur            x7, [fp, #-0x58]
    // 0x8ace74: ldur            x6, [fp, #-0x60]
    // 0x8ace78: ldur            x5, [fp, #-0x68]
    // 0x8ace7c: ldur            x4, [fp, #-0x70]
    // 0x8ace80: ldur            x3, [fp, #-0x78]
    // 0x8ace84: ldur            x2, [fp, #-0x20]
    // 0x8ace88: ldur            x1, [fp, #-0x80]
    // 0x8ace8c: stur            x14, [fp, #-8]
    // 0x8ace90: r0 = TextTheme()
    //     0x8ace90: bl              #0x8a98dc  ; AllocateTextThemeStub -> TextTheme (size=0x44)
    // 0x8ace94: ldur            x1, [fp, #-0x28]
    // 0x8ace98: StoreField: r0->field_7 = r1
    //     0x8ace98: stur            w1, [x0, #7]
    // 0x8ace9c: ldur            x1, [fp, #-0x30]
    // 0x8acea0: StoreField: r0->field_b = r1
    //     0x8acea0: stur            w1, [x0, #0xb]
    // 0x8acea4: ldur            x1, [fp, #-0x38]
    // 0x8acea8: StoreField: r0->field_f = r1
    //     0x8acea8: stur            w1, [x0, #0xf]
    // 0x8aceac: ldur            x1, [fp, #-0x40]
    // 0x8aceb0: StoreField: r0->field_13 = r1
    //     0x8aceb0: stur            w1, [x0, #0x13]
    // 0x8aceb4: ldur            x1, [fp, #-0x48]
    // 0x8aceb8: ArrayStore: r0[0] = r1  ; List_4
    //     0x8aceb8: stur            w1, [x0, #0x17]
    // 0x8acebc: ldur            x1, [fp, #-0x50]
    // 0x8acec0: StoreField: r0->field_1b = r1
    //     0x8acec0: stur            w1, [x0, #0x1b]
    // 0x8acec4: ldur            x1, [fp, #-0x58]
    // 0x8acec8: StoreField: r0->field_1f = r1
    //     0x8acec8: stur            w1, [x0, #0x1f]
    // 0x8acecc: ldur            x1, [fp, #-0x60]
    // 0x8aced0: StoreField: r0->field_23 = r1
    //     0x8aced0: stur            w1, [x0, #0x23]
    // 0x8aced4: ldur            x1, [fp, #-0x68]
    // 0x8aced8: StoreField: r0->field_27 = r1
    //     0x8aced8: stur            w1, [x0, #0x27]
    // 0x8acedc: ldur            x1, [fp, #-0x70]
    // 0x8acee0: StoreField: r0->field_2b = r1
    //     0x8acee0: stur            w1, [x0, #0x2b]
    // 0x8acee4: ldur            x1, [fp, #-0x78]
    // 0x8acee8: StoreField: r0->field_2f = r1
    //     0x8acee8: stur            w1, [x0, #0x2f]
    // 0x8aceec: ldur            x1, [fp, #-0x20]
    // 0x8acef0: StoreField: r0->field_33 = r1
    //     0x8acef0: stur            w1, [x0, #0x33]
    // 0x8acef4: ldur            x1, [fp, #-0x80]
    // 0x8acef8: StoreField: r0->field_37 = r1
    //     0x8acef8: stur            w1, [x0, #0x37]
    // 0x8acefc: ldur            x1, [fp, #-0x88]
    // 0x8acf00: StoreField: r0->field_3b = r1
    //     0x8acf00: stur            w1, [x0, #0x3b]
    // 0x8acf04: ldur            x1, [fp, #-8]
    // 0x8acf08: StoreField: r0->field_3f = r1
    //     0x8acf08: stur            w1, [x0, #0x3f]
    // 0x8acf0c: LeaveFrame
    //     0x8acf0c: mov             SP, fp
    //     0x8acf10: ldp             fp, lr, [SP], #0x10
    // 0x8acf14: ret
    //     0x8acf14: ret             
    // 0x8acf18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8acf18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8acf1c: b               #0x8acb04
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x113881c, size: 0xe8
    // 0x113881c: EnterFrame
    //     0x113881c: stp             fp, lr, [SP, #-0x10]!
    //     0x1138820: mov             fp, SP
    // 0x1138824: AllocStack(0x68)
    //     0x1138824: sub             SP, SP, #0x68
    // 0x1138828: CheckStackOverflow
    //     0x1138828: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x113882c: cmp             SP, x16
    //     0x1138830: b.ls            #0x11388fc
    // 0x1138834: ldr             x0, [fp, #0x10]
    // 0x1138838: LoadField: r1 = r0->field_7
    //     0x1138838: ldur            w1, [x0, #7]
    // 0x113883c: DecompressPointer r1
    //     0x113883c: add             x1, x1, HEAP, lsl #32
    // 0x1138840: LoadField: r2 = r0->field_b
    //     0x1138840: ldur            w2, [x0, #0xb]
    // 0x1138844: DecompressPointer r2
    //     0x1138844: add             x2, x2, HEAP, lsl #32
    // 0x1138848: LoadField: r3 = r0->field_f
    //     0x1138848: ldur            w3, [x0, #0xf]
    // 0x113884c: DecompressPointer r3
    //     0x113884c: add             x3, x3, HEAP, lsl #32
    // 0x1138850: LoadField: r4 = r0->field_13
    //     0x1138850: ldur            w4, [x0, #0x13]
    // 0x1138854: DecompressPointer r4
    //     0x1138854: add             x4, x4, HEAP, lsl #32
    // 0x1138858: ArrayLoad: r5 = r0[0]  ; List_4
    //     0x1138858: ldur            w5, [x0, #0x17]
    // 0x113885c: DecompressPointer r5
    //     0x113885c: add             x5, x5, HEAP, lsl #32
    // 0x1138860: LoadField: r6 = r0->field_1b
    //     0x1138860: ldur            w6, [x0, #0x1b]
    // 0x1138864: DecompressPointer r6
    //     0x1138864: add             x6, x6, HEAP, lsl #32
    // 0x1138868: LoadField: r7 = r0->field_1f
    //     0x1138868: ldur            w7, [x0, #0x1f]
    // 0x113886c: DecompressPointer r7
    //     0x113886c: add             x7, x7, HEAP, lsl #32
    // 0x1138870: LoadField: r8 = r0->field_23
    //     0x1138870: ldur            w8, [x0, #0x23]
    // 0x1138874: DecompressPointer r8
    //     0x1138874: add             x8, x8, HEAP, lsl #32
    // 0x1138878: LoadField: r9 = r0->field_27
    //     0x1138878: ldur            w9, [x0, #0x27]
    // 0x113887c: DecompressPointer r9
    //     0x113887c: add             x9, x9, HEAP, lsl #32
    // 0x1138880: LoadField: r10 = r0->field_2b
    //     0x1138880: ldur            w10, [x0, #0x2b]
    // 0x1138884: DecompressPointer r10
    //     0x1138884: add             x10, x10, HEAP, lsl #32
    // 0x1138888: LoadField: r11 = r0->field_2f
    //     0x1138888: ldur            w11, [x0, #0x2f]
    // 0x113888c: DecompressPointer r11
    //     0x113888c: add             x11, x11, HEAP, lsl #32
    // 0x1138890: LoadField: r12 = r0->field_33
    //     0x1138890: ldur            w12, [x0, #0x33]
    // 0x1138894: DecompressPointer r12
    //     0x1138894: add             x12, x12, HEAP, lsl #32
    // 0x1138898: LoadField: r13 = r0->field_37
    //     0x1138898: ldur            w13, [x0, #0x37]
    // 0x113889c: DecompressPointer r13
    //     0x113889c: add             x13, x13, HEAP, lsl #32
    // 0x11388a0: LoadField: r14 = r0->field_3b
    //     0x11388a0: ldur            w14, [x0, #0x3b]
    // 0x11388a4: DecompressPointer r14
    //     0x11388a4: add             x14, x14, HEAP, lsl #32
    // 0x11388a8: LoadField: r19 = r0->field_3f
    //     0x11388a8: ldur            w19, [x0, #0x3f]
    // 0x11388ac: DecompressPointer r19
    //     0x11388ac: add             x19, x19, HEAP, lsl #32
    // 0x11388b0: stp             x4, x3, [SP, #0x58]
    // 0x11388b4: stp             x6, x5, [SP, #0x48]
    // 0x11388b8: stp             x8, x7, [SP, #0x38]
    // 0x11388bc: stp             x10, x9, [SP, #0x28]
    // 0x11388c0: stp             x12, x11, [SP, #0x18]
    // 0x11388c4: stp             x14, x13, [SP, #8]
    // 0x11388c8: str             x19, [SP]
    // 0x11388cc: r4 = const [0, 0xf, 0xd, 0xf, null]
    //     0x11388cc: add             x4, PP, #0xd, lsl #12  ; [pp+0xdf18] List(5) [0, 0xf, 0xd, 0xf, Null]
    //     0x11388d0: ldr             x4, [x4, #0xf18]
    // 0x11388d4: r0 = hash()
    //     0x11388d4: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x11388d8: mov             x2, x0
    // 0x11388dc: r0 = BoxInt64Instr(r2)
    //     0x11388dc: sbfiz           x0, x2, #1, #0x1f
    //     0x11388e0: cmp             x2, x0, asr #1
    //     0x11388e4: b.eq            #0x11388f0
    //     0x11388e8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11388ec: stur            x2, [x0, #7]
    // 0x11388f0: LeaveFrame
    //     0x11388f0: mov             SP, fp
    //     0x11388f4: ldp             fp, lr, [SP], #0x10
    // 0x11388f8: ret
    //     0x11388f8: ret             
    // 0x11388fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11388fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1138900: b               #0x1138834
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1169308, size: 0x370
    // 0x1169308: EnterFrame
    //     0x1169308: stp             fp, lr, [SP, #-0x10]!
    //     0x116930c: mov             fp, SP
    // 0x1169310: AllocStack(0x88)
    //     0x1169310: sub             SP, SP, #0x88
    // 0x1169314: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0x1169314: mov             x4, x1
    //     0x1169318: mov             x0, x2
    //     0x116931c: stur            x1, [fp, #-0x10]
    //     0x1169320: stur            x2, [fp, #-0x18]
    // 0x1169324: CheckStackOverflow
    //     0x1169324: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1169328: cmp             SP, x16
    //     0x116932c: b.ls            #0x116964c
    // 0x1169330: cmp             w4, w0
    // 0x1169334: b.ne            #0x1169348
    // 0x1169338: mov             x0, x4
    // 0x116933c: LeaveFrame
    //     0x116933c: mov             SP, fp
    //     0x1169340: ldp             fp, lr, [SP], #0x10
    // 0x1169344: ret
    //     0x1169344: ret             
    // 0x1169348: LoadField: r1 = r4->field_7
    //     0x1169348: ldur            w1, [x4, #7]
    // 0x116934c: DecompressPointer r1
    //     0x116934c: add             x1, x1, HEAP, lsl #32
    // 0x1169350: LoadField: r2 = r0->field_7
    //     0x1169350: ldur            w2, [x0, #7]
    // 0x1169354: DecompressPointer r2
    //     0x1169354: add             x2, x2, HEAP, lsl #32
    // 0x1169358: r5 = inline_Allocate_Double()
    //     0x1169358: ldp             x5, x3, [THR, #0x60]  ; THR::top
    //     0x116935c: add             x5, x5, #0x10
    //     0x1169360: cmp             x3, x5
    //     0x1169364: b.ls            #0x1169654
    //     0x1169368: str             x5, [THR, #0x60]  ; THR::top
    //     0x116936c: sub             x5, x5, #0xf
    //     0x1169370: mov             x3, #0xe19c
    //     0x1169374: movk            x3, #3, lsl #16
    //     0x1169378: stur            x3, [x5, #-1]
    // 0x116937c: dmb             ishst
    // 0x1169380: StoreField: r5->field_7 = d0
    //     0x1169380: stur            d0, [x5, #7]
    // 0x1169384: mov             x3, x5
    // 0x1169388: stur            x5, [fp, #-8]
    // 0x116938c: r0 = lerp()
    //     0x116938c: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1169390: mov             x4, x0
    // 0x1169394: ldur            x0, [fp, #-0x10]
    // 0x1169398: stur            x4, [fp, #-0x20]
    // 0x116939c: LoadField: r1 = r0->field_b
    //     0x116939c: ldur            w1, [x0, #0xb]
    // 0x11693a0: DecompressPointer r1
    //     0x11693a0: add             x1, x1, HEAP, lsl #32
    // 0x11693a4: ldur            x5, [fp, #-0x18]
    // 0x11693a8: LoadField: r2 = r5->field_b
    //     0x11693a8: ldur            w2, [x5, #0xb]
    // 0x11693ac: DecompressPointer r2
    //     0x11693ac: add             x2, x2, HEAP, lsl #32
    // 0x11693b0: ldur            x3, [fp, #-8]
    // 0x11693b4: r0 = lerp()
    //     0x11693b4: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x11693b8: mov             x4, x0
    // 0x11693bc: ldur            x0, [fp, #-0x10]
    // 0x11693c0: stur            x4, [fp, #-0x28]
    // 0x11693c4: LoadField: r1 = r0->field_f
    //     0x11693c4: ldur            w1, [x0, #0xf]
    // 0x11693c8: DecompressPointer r1
    //     0x11693c8: add             x1, x1, HEAP, lsl #32
    // 0x11693cc: ldur            x5, [fp, #-0x18]
    // 0x11693d0: LoadField: r2 = r5->field_f
    //     0x11693d0: ldur            w2, [x5, #0xf]
    // 0x11693d4: DecompressPointer r2
    //     0x11693d4: add             x2, x2, HEAP, lsl #32
    // 0x11693d8: ldur            x3, [fp, #-8]
    // 0x11693dc: r0 = lerp()
    //     0x11693dc: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x11693e0: mov             x4, x0
    // 0x11693e4: ldur            x0, [fp, #-0x10]
    // 0x11693e8: stur            x4, [fp, #-0x30]
    // 0x11693ec: LoadField: r1 = r0->field_13
    //     0x11693ec: ldur            w1, [x0, #0x13]
    // 0x11693f0: DecompressPointer r1
    //     0x11693f0: add             x1, x1, HEAP, lsl #32
    // 0x11693f4: ldur            x5, [fp, #-0x18]
    // 0x11693f8: LoadField: r2 = r5->field_13
    //     0x11693f8: ldur            w2, [x5, #0x13]
    // 0x11693fc: DecompressPointer r2
    //     0x11693fc: add             x2, x2, HEAP, lsl #32
    // 0x1169400: ldur            x3, [fp, #-8]
    // 0x1169404: r0 = lerp()
    //     0x1169404: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1169408: mov             x4, x0
    // 0x116940c: ldur            x0, [fp, #-0x10]
    // 0x1169410: stur            x4, [fp, #-0x38]
    // 0x1169414: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1169414: ldur            w1, [x0, #0x17]
    // 0x1169418: DecompressPointer r1
    //     0x1169418: add             x1, x1, HEAP, lsl #32
    // 0x116941c: ldur            x5, [fp, #-0x18]
    // 0x1169420: ArrayLoad: r2 = r5[0]  ; List_4
    //     0x1169420: ldur            w2, [x5, #0x17]
    // 0x1169424: DecompressPointer r2
    //     0x1169424: add             x2, x2, HEAP, lsl #32
    // 0x1169428: ldur            x3, [fp, #-8]
    // 0x116942c: r0 = lerp()
    //     0x116942c: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1169430: mov             x4, x0
    // 0x1169434: ldur            x0, [fp, #-0x10]
    // 0x1169438: stur            x4, [fp, #-0x40]
    // 0x116943c: LoadField: r1 = r0->field_1b
    //     0x116943c: ldur            w1, [x0, #0x1b]
    // 0x1169440: DecompressPointer r1
    //     0x1169440: add             x1, x1, HEAP, lsl #32
    // 0x1169444: ldur            x5, [fp, #-0x18]
    // 0x1169448: LoadField: r2 = r5->field_1b
    //     0x1169448: ldur            w2, [x5, #0x1b]
    // 0x116944c: DecompressPointer r2
    //     0x116944c: add             x2, x2, HEAP, lsl #32
    // 0x1169450: ldur            x3, [fp, #-8]
    // 0x1169454: r0 = lerp()
    //     0x1169454: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1169458: mov             x4, x0
    // 0x116945c: ldur            x0, [fp, #-0x10]
    // 0x1169460: stur            x4, [fp, #-0x48]
    // 0x1169464: LoadField: r1 = r0->field_1f
    //     0x1169464: ldur            w1, [x0, #0x1f]
    // 0x1169468: DecompressPointer r1
    //     0x1169468: add             x1, x1, HEAP, lsl #32
    // 0x116946c: ldur            x5, [fp, #-0x18]
    // 0x1169470: LoadField: r2 = r5->field_1f
    //     0x1169470: ldur            w2, [x5, #0x1f]
    // 0x1169474: DecompressPointer r2
    //     0x1169474: add             x2, x2, HEAP, lsl #32
    // 0x1169478: ldur            x3, [fp, #-8]
    // 0x116947c: r0 = lerp()
    //     0x116947c: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1169480: mov             x4, x0
    // 0x1169484: ldur            x0, [fp, #-0x10]
    // 0x1169488: stur            x4, [fp, #-0x50]
    // 0x116948c: LoadField: r1 = r0->field_23
    //     0x116948c: ldur            w1, [x0, #0x23]
    // 0x1169490: DecompressPointer r1
    //     0x1169490: add             x1, x1, HEAP, lsl #32
    // 0x1169494: ldur            x5, [fp, #-0x18]
    // 0x1169498: LoadField: r2 = r5->field_23
    //     0x1169498: ldur            w2, [x5, #0x23]
    // 0x116949c: DecompressPointer r2
    //     0x116949c: add             x2, x2, HEAP, lsl #32
    // 0x11694a0: ldur            x3, [fp, #-8]
    // 0x11694a4: r0 = lerp()
    //     0x11694a4: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x11694a8: mov             x4, x0
    // 0x11694ac: ldur            x0, [fp, #-0x10]
    // 0x11694b0: stur            x4, [fp, #-0x58]
    // 0x11694b4: LoadField: r1 = r0->field_27
    //     0x11694b4: ldur            w1, [x0, #0x27]
    // 0x11694b8: DecompressPointer r1
    //     0x11694b8: add             x1, x1, HEAP, lsl #32
    // 0x11694bc: ldur            x5, [fp, #-0x18]
    // 0x11694c0: LoadField: r2 = r5->field_27
    //     0x11694c0: ldur            w2, [x5, #0x27]
    // 0x11694c4: DecompressPointer r2
    //     0x11694c4: add             x2, x2, HEAP, lsl #32
    // 0x11694c8: ldur            x3, [fp, #-8]
    // 0x11694cc: r0 = lerp()
    //     0x11694cc: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x11694d0: mov             x4, x0
    // 0x11694d4: ldur            x0, [fp, #-0x10]
    // 0x11694d8: stur            x4, [fp, #-0x60]
    // 0x11694dc: LoadField: r1 = r0->field_2b
    //     0x11694dc: ldur            w1, [x0, #0x2b]
    // 0x11694e0: DecompressPointer r1
    //     0x11694e0: add             x1, x1, HEAP, lsl #32
    // 0x11694e4: ldur            x5, [fp, #-0x18]
    // 0x11694e8: LoadField: r2 = r5->field_2b
    //     0x11694e8: ldur            w2, [x5, #0x2b]
    // 0x11694ec: DecompressPointer r2
    //     0x11694ec: add             x2, x2, HEAP, lsl #32
    // 0x11694f0: ldur            x3, [fp, #-8]
    // 0x11694f4: r0 = lerp()
    //     0x11694f4: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x11694f8: mov             x4, x0
    // 0x11694fc: ldur            x0, [fp, #-0x10]
    // 0x1169500: stur            x4, [fp, #-0x68]
    // 0x1169504: LoadField: r1 = r0->field_2f
    //     0x1169504: ldur            w1, [x0, #0x2f]
    // 0x1169508: DecompressPointer r1
    //     0x1169508: add             x1, x1, HEAP, lsl #32
    // 0x116950c: ldur            x5, [fp, #-0x18]
    // 0x1169510: LoadField: r2 = r5->field_2f
    //     0x1169510: ldur            w2, [x5, #0x2f]
    // 0x1169514: DecompressPointer r2
    //     0x1169514: add             x2, x2, HEAP, lsl #32
    // 0x1169518: ldur            x3, [fp, #-8]
    // 0x116951c: r0 = lerp()
    //     0x116951c: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1169520: mov             x4, x0
    // 0x1169524: ldur            x0, [fp, #-0x10]
    // 0x1169528: stur            x4, [fp, #-0x70]
    // 0x116952c: LoadField: r1 = r0->field_33
    //     0x116952c: ldur            w1, [x0, #0x33]
    // 0x1169530: DecompressPointer r1
    //     0x1169530: add             x1, x1, HEAP, lsl #32
    // 0x1169534: ldur            x5, [fp, #-0x18]
    // 0x1169538: LoadField: r2 = r5->field_33
    //     0x1169538: ldur            w2, [x5, #0x33]
    // 0x116953c: DecompressPointer r2
    //     0x116953c: add             x2, x2, HEAP, lsl #32
    // 0x1169540: ldur            x3, [fp, #-8]
    // 0x1169544: r0 = lerp()
    //     0x1169544: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1169548: mov             x4, x0
    // 0x116954c: ldur            x0, [fp, #-0x10]
    // 0x1169550: stur            x4, [fp, #-0x78]
    // 0x1169554: LoadField: r1 = r0->field_37
    //     0x1169554: ldur            w1, [x0, #0x37]
    // 0x1169558: DecompressPointer r1
    //     0x1169558: add             x1, x1, HEAP, lsl #32
    // 0x116955c: ldur            x5, [fp, #-0x18]
    // 0x1169560: LoadField: r2 = r5->field_37
    //     0x1169560: ldur            w2, [x5, #0x37]
    // 0x1169564: DecompressPointer r2
    //     0x1169564: add             x2, x2, HEAP, lsl #32
    // 0x1169568: ldur            x3, [fp, #-8]
    // 0x116956c: r0 = lerp()
    //     0x116956c: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1169570: mov             x4, x0
    // 0x1169574: ldur            x0, [fp, #-0x10]
    // 0x1169578: stur            x4, [fp, #-0x80]
    // 0x116957c: LoadField: r1 = r0->field_3b
    //     0x116957c: ldur            w1, [x0, #0x3b]
    // 0x1169580: DecompressPointer r1
    //     0x1169580: add             x1, x1, HEAP, lsl #32
    // 0x1169584: ldur            x5, [fp, #-0x18]
    // 0x1169588: LoadField: r2 = r5->field_3b
    //     0x1169588: ldur            w2, [x5, #0x3b]
    // 0x116958c: DecompressPointer r2
    //     0x116958c: add             x2, x2, HEAP, lsl #32
    // 0x1169590: ldur            x3, [fp, #-8]
    // 0x1169594: r0 = lerp()
    //     0x1169594: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1169598: mov             x4, x0
    // 0x116959c: ldur            x0, [fp, #-0x10]
    // 0x11695a0: stur            x4, [fp, #-0x88]
    // 0x11695a4: LoadField: r1 = r0->field_3f
    //     0x11695a4: ldur            w1, [x0, #0x3f]
    // 0x11695a8: DecompressPointer r1
    //     0x11695a8: add             x1, x1, HEAP, lsl #32
    // 0x11695ac: ldur            x0, [fp, #-0x18]
    // 0x11695b0: LoadField: r2 = r0->field_3f
    //     0x11695b0: ldur            w2, [x0, #0x3f]
    // 0x11695b4: DecompressPointer r2
    //     0x11695b4: add             x2, x2, HEAP, lsl #32
    // 0x11695b8: ldur            x3, [fp, #-8]
    // 0x11695bc: r0 = lerp()
    //     0x11695bc: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x11695c0: stur            x0, [fp, #-8]
    // 0x11695c4: r0 = TextTheme()
    //     0x11695c4: bl              #0x8a98dc  ; AllocateTextThemeStub -> TextTheme (size=0x44)
    // 0x11695c8: ldur            x1, [fp, #-0x20]
    // 0x11695cc: StoreField: r0->field_7 = r1
    //     0x11695cc: stur            w1, [x0, #7]
    // 0x11695d0: ldur            x1, [fp, #-0x28]
    // 0x11695d4: StoreField: r0->field_b = r1
    //     0x11695d4: stur            w1, [x0, #0xb]
    // 0x11695d8: ldur            x1, [fp, #-0x30]
    // 0x11695dc: StoreField: r0->field_f = r1
    //     0x11695dc: stur            w1, [x0, #0xf]
    // 0x11695e0: ldur            x1, [fp, #-0x38]
    // 0x11695e4: StoreField: r0->field_13 = r1
    //     0x11695e4: stur            w1, [x0, #0x13]
    // 0x11695e8: ldur            x1, [fp, #-0x40]
    // 0x11695ec: ArrayStore: r0[0] = r1  ; List_4
    //     0x11695ec: stur            w1, [x0, #0x17]
    // 0x11695f0: ldur            x1, [fp, #-0x48]
    // 0x11695f4: StoreField: r0->field_1b = r1
    //     0x11695f4: stur            w1, [x0, #0x1b]
    // 0x11695f8: ldur            x1, [fp, #-0x50]
    // 0x11695fc: StoreField: r0->field_1f = r1
    //     0x11695fc: stur            w1, [x0, #0x1f]
    // 0x1169600: ldur            x1, [fp, #-0x58]
    // 0x1169604: StoreField: r0->field_23 = r1
    //     0x1169604: stur            w1, [x0, #0x23]
    // 0x1169608: ldur            x1, [fp, #-0x60]
    // 0x116960c: StoreField: r0->field_27 = r1
    //     0x116960c: stur            w1, [x0, #0x27]
    // 0x1169610: ldur            x1, [fp, #-0x68]
    // 0x1169614: StoreField: r0->field_2b = r1
    //     0x1169614: stur            w1, [x0, #0x2b]
    // 0x1169618: ldur            x1, [fp, #-0x70]
    // 0x116961c: StoreField: r0->field_2f = r1
    //     0x116961c: stur            w1, [x0, #0x2f]
    // 0x1169620: ldur            x1, [fp, #-0x78]
    // 0x1169624: StoreField: r0->field_33 = r1
    //     0x1169624: stur            w1, [x0, #0x33]
    // 0x1169628: ldur            x1, [fp, #-0x80]
    // 0x116962c: StoreField: r0->field_37 = r1
    //     0x116962c: stur            w1, [x0, #0x37]
    // 0x1169630: ldur            x1, [fp, #-0x88]
    // 0x1169634: StoreField: r0->field_3b = r1
    //     0x1169634: stur            w1, [x0, #0x3b]
    // 0x1169638: ldur            x1, [fp, #-8]
    // 0x116963c: StoreField: r0->field_3f = r1
    //     0x116963c: stur            w1, [x0, #0x3f]
    // 0x1169640: LeaveFrame
    //     0x1169640: mov             SP, fp
    //     0x1169644: ldp             fp, lr, [SP], #0x10
    // 0x1169648: ret
    //     0x1169648: ret             
    // 0x116964c: r0 = StackOverflowSharedWithFPURegs()
    //     0x116964c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1169650: b               #0x1169330
    // 0x1169654: SaveReg d0
    //     0x1169654: str             q0, [SP, #-0x10]!
    // 0x1169658: stp             x2, x4, [SP, #-0x10]!
    // 0x116965c: stp             x0, x1, [SP, #-0x10]!
    // 0x1169660: r0 = AllocateDouble()
    //     0x1169660: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1169664: mov             x5, x0
    // 0x1169668: ldp             x0, x1, [SP], #0x10
    // 0x116966c: ldp             x2, x4, [SP], #0x10
    // 0x1169670: RestoreReg d0
    //     0x1169670: ldr             q0, [SP], #0x10
    // 0x1169674: b               #0x1169380
  }
  _ ==(/* No info */) {
    // ** addr: 0x12770f8, size: 0x3cc
    // 0x12770f8: EnterFrame
    //     0x12770f8: stp             fp, lr, [SP, #-0x10]!
    //     0x12770fc: mov             fp, SP
    // 0x1277100: AllocStack(0x10)
    //     0x1277100: sub             SP, SP, #0x10
    // 0x1277104: CheckStackOverflow
    //     0x1277104: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1277108: cmp             SP, x16
    //     0x127710c: b.ls            #0x12774bc
    // 0x1277110: ldr             x0, [fp, #0x10]
    // 0x1277114: cmp             w0, NULL
    // 0x1277118: b.ne            #0x127712c
    // 0x127711c: r0 = false
    //     0x127711c: add             x0, NULL, #0x30  ; false
    // 0x1277120: LeaveFrame
    //     0x1277120: mov             SP, fp
    //     0x1277124: ldp             fp, lr, [SP], #0x10
    // 0x1277128: ret
    //     0x1277128: ret             
    // 0x127712c: ldr             x1, [fp, #0x18]
    // 0x1277130: cmp             w1, w0
    // 0x1277134: b.ne            #0x1277148
    // 0x1277138: r0 = true
    //     0x1277138: add             x0, NULL, #0x20  ; true
    // 0x127713c: LeaveFrame
    //     0x127713c: mov             SP, fp
    //     0x1277140: ldp             fp, lr, [SP], #0x10
    // 0x1277144: ret
    //     0x1277144: ret             
    // 0x1277148: str             x0, [SP]
    // 0x127714c: r0 = runtimeType()
    //     0x127714c: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1277150: r1 = LoadClassIdInstr(r0)
    //     0x1277150: ldur            x1, [x0, #-1]
    //     0x1277154: ubfx            x1, x1, #0xc, #0x14
    // 0x1277158: r16 = TextTheme
    //     0x1277158: add             x16, PP, #0x26, lsl #12  ; [pp+0x267e8] Type: TextTheme
    //     0x127715c: ldr             x16, [x16, #0x7e8]
    // 0x1277160: stp             x16, x0, [SP]
    // 0x1277164: mov             x0, x1
    // 0x1277168: mov             lr, x0
    // 0x127716c: ldr             lr, [x21, lr, lsl #3]
    // 0x1277170: blr             lr
    // 0x1277174: tbz             w0, #4, #0x1277188
    // 0x1277178: r0 = false
    //     0x1277178: add             x0, NULL, #0x30  ; false
    // 0x127717c: LeaveFrame
    //     0x127717c: mov             SP, fp
    //     0x1277180: ldp             fp, lr, [SP], #0x10
    // 0x1277184: ret
    //     0x1277184: ret             
    // 0x1277188: ldr             x1, [fp, #0x10]
    // 0x127718c: r0 = 60
    //     0x127718c: mov             x0, #0x3c
    // 0x1277190: branchIfSmi(r1, 0x127719c)
    //     0x1277190: tbz             w1, #0, #0x127719c
    // 0x1277194: r0 = LoadClassIdInstr(r1)
    //     0x1277194: ldur            x0, [x1, #-1]
    //     0x1277198: ubfx            x0, x0, #0xc, #0x14
    // 0x127719c: r17 = 5055
    //     0x127719c: mov             x17, #0x13bf
    // 0x12771a0: cmp             x0, x17
    // 0x12771a4: b.ne            #0x12774ac
    // 0x12771a8: ldr             x2, [fp, #0x18]
    // 0x12771ac: LoadField: r0 = r2->field_7
    //     0x12771ac: ldur            w0, [x2, #7]
    // 0x12771b0: DecompressPointer r0
    //     0x12771b0: add             x0, x0, HEAP, lsl #32
    // 0x12771b4: LoadField: r3 = r1->field_7
    //     0x12771b4: ldur            w3, [x1, #7]
    // 0x12771b8: DecompressPointer r3
    //     0x12771b8: add             x3, x3, HEAP, lsl #32
    // 0x12771bc: r4 = LoadClassIdInstr(r0)
    //     0x12771bc: ldur            x4, [x0, #-1]
    //     0x12771c0: ubfx            x4, x4, #0xc, #0x14
    // 0x12771c4: stp             x3, x0, [SP]
    // 0x12771c8: mov             x0, x4
    // 0x12771cc: mov             lr, x0
    // 0x12771d0: ldr             lr, [x21, lr, lsl #3]
    // 0x12771d4: blr             lr
    // 0x12771d8: tbnz            w0, #4, #0x12774ac
    // 0x12771dc: ldr             x2, [fp, #0x18]
    // 0x12771e0: ldr             x1, [fp, #0x10]
    // 0x12771e4: LoadField: r0 = r2->field_b
    //     0x12771e4: ldur            w0, [x2, #0xb]
    // 0x12771e8: DecompressPointer r0
    //     0x12771e8: add             x0, x0, HEAP, lsl #32
    // 0x12771ec: LoadField: r3 = r1->field_b
    //     0x12771ec: ldur            w3, [x1, #0xb]
    // 0x12771f0: DecompressPointer r3
    //     0x12771f0: add             x3, x3, HEAP, lsl #32
    // 0x12771f4: r4 = LoadClassIdInstr(r0)
    //     0x12771f4: ldur            x4, [x0, #-1]
    //     0x12771f8: ubfx            x4, x4, #0xc, #0x14
    // 0x12771fc: stp             x3, x0, [SP]
    // 0x1277200: mov             x0, x4
    // 0x1277204: mov             lr, x0
    // 0x1277208: ldr             lr, [x21, lr, lsl #3]
    // 0x127720c: blr             lr
    // 0x1277210: tbnz            w0, #4, #0x12774ac
    // 0x1277214: ldr             x2, [fp, #0x18]
    // 0x1277218: ldr             x1, [fp, #0x10]
    // 0x127721c: LoadField: r0 = r2->field_f
    //     0x127721c: ldur            w0, [x2, #0xf]
    // 0x1277220: DecompressPointer r0
    //     0x1277220: add             x0, x0, HEAP, lsl #32
    // 0x1277224: LoadField: r3 = r1->field_f
    //     0x1277224: ldur            w3, [x1, #0xf]
    // 0x1277228: DecompressPointer r3
    //     0x1277228: add             x3, x3, HEAP, lsl #32
    // 0x127722c: r4 = LoadClassIdInstr(r0)
    //     0x127722c: ldur            x4, [x0, #-1]
    //     0x1277230: ubfx            x4, x4, #0xc, #0x14
    // 0x1277234: stp             x3, x0, [SP]
    // 0x1277238: mov             x0, x4
    // 0x127723c: mov             lr, x0
    // 0x1277240: ldr             lr, [x21, lr, lsl #3]
    // 0x1277244: blr             lr
    // 0x1277248: tbnz            w0, #4, #0x12774ac
    // 0x127724c: ldr             x2, [fp, #0x18]
    // 0x1277250: ldr             x1, [fp, #0x10]
    // 0x1277254: LoadField: r0 = r2->field_13
    //     0x1277254: ldur            w0, [x2, #0x13]
    // 0x1277258: DecompressPointer r0
    //     0x1277258: add             x0, x0, HEAP, lsl #32
    // 0x127725c: LoadField: r3 = r1->field_13
    //     0x127725c: ldur            w3, [x1, #0x13]
    // 0x1277260: DecompressPointer r3
    //     0x1277260: add             x3, x3, HEAP, lsl #32
    // 0x1277264: r4 = LoadClassIdInstr(r0)
    //     0x1277264: ldur            x4, [x0, #-1]
    //     0x1277268: ubfx            x4, x4, #0xc, #0x14
    // 0x127726c: stp             x3, x0, [SP]
    // 0x1277270: mov             x0, x4
    // 0x1277274: mov             lr, x0
    // 0x1277278: ldr             lr, [x21, lr, lsl #3]
    // 0x127727c: blr             lr
    // 0x1277280: tbnz            w0, #4, #0x12774ac
    // 0x1277284: ldr             x2, [fp, #0x18]
    // 0x1277288: ldr             x1, [fp, #0x10]
    // 0x127728c: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x127728c: ldur            w0, [x2, #0x17]
    // 0x1277290: DecompressPointer r0
    //     0x1277290: add             x0, x0, HEAP, lsl #32
    // 0x1277294: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x1277294: ldur            w3, [x1, #0x17]
    // 0x1277298: DecompressPointer r3
    //     0x1277298: add             x3, x3, HEAP, lsl #32
    // 0x127729c: r4 = LoadClassIdInstr(r0)
    //     0x127729c: ldur            x4, [x0, #-1]
    //     0x12772a0: ubfx            x4, x4, #0xc, #0x14
    // 0x12772a4: stp             x3, x0, [SP]
    // 0x12772a8: mov             x0, x4
    // 0x12772ac: mov             lr, x0
    // 0x12772b0: ldr             lr, [x21, lr, lsl #3]
    // 0x12772b4: blr             lr
    // 0x12772b8: tbnz            w0, #4, #0x12774ac
    // 0x12772bc: ldr             x2, [fp, #0x18]
    // 0x12772c0: ldr             x1, [fp, #0x10]
    // 0x12772c4: LoadField: r0 = r2->field_1b
    //     0x12772c4: ldur            w0, [x2, #0x1b]
    // 0x12772c8: DecompressPointer r0
    //     0x12772c8: add             x0, x0, HEAP, lsl #32
    // 0x12772cc: LoadField: r3 = r1->field_1b
    //     0x12772cc: ldur            w3, [x1, #0x1b]
    // 0x12772d0: DecompressPointer r3
    //     0x12772d0: add             x3, x3, HEAP, lsl #32
    // 0x12772d4: r4 = LoadClassIdInstr(r0)
    //     0x12772d4: ldur            x4, [x0, #-1]
    //     0x12772d8: ubfx            x4, x4, #0xc, #0x14
    // 0x12772dc: stp             x3, x0, [SP]
    // 0x12772e0: mov             x0, x4
    // 0x12772e4: mov             lr, x0
    // 0x12772e8: ldr             lr, [x21, lr, lsl #3]
    // 0x12772ec: blr             lr
    // 0x12772f0: tbnz            w0, #4, #0x12774ac
    // 0x12772f4: ldr             x2, [fp, #0x18]
    // 0x12772f8: ldr             x1, [fp, #0x10]
    // 0x12772fc: LoadField: r0 = r2->field_1f
    //     0x12772fc: ldur            w0, [x2, #0x1f]
    // 0x1277300: DecompressPointer r0
    //     0x1277300: add             x0, x0, HEAP, lsl #32
    // 0x1277304: LoadField: r3 = r1->field_1f
    //     0x1277304: ldur            w3, [x1, #0x1f]
    // 0x1277308: DecompressPointer r3
    //     0x1277308: add             x3, x3, HEAP, lsl #32
    // 0x127730c: r4 = LoadClassIdInstr(r0)
    //     0x127730c: ldur            x4, [x0, #-1]
    //     0x1277310: ubfx            x4, x4, #0xc, #0x14
    // 0x1277314: stp             x3, x0, [SP]
    // 0x1277318: mov             x0, x4
    // 0x127731c: mov             lr, x0
    // 0x1277320: ldr             lr, [x21, lr, lsl #3]
    // 0x1277324: blr             lr
    // 0x1277328: tbnz            w0, #4, #0x12774ac
    // 0x127732c: ldr             x1, [fp, #0x18]
    // 0x1277330: ldr             x0, [fp, #0x10]
    // 0x1277334: LoadField: r2 = r1->field_23
    //     0x1277334: ldur            w2, [x1, #0x23]
    // 0x1277338: DecompressPointer r2
    //     0x1277338: add             x2, x2, HEAP, lsl #32
    // 0x127733c: LoadField: r3 = r0->field_23
    //     0x127733c: ldur            w3, [x0, #0x23]
    // 0x1277340: DecompressPointer r3
    //     0x1277340: add             x3, x3, HEAP, lsl #32
    // 0x1277344: stp             x3, x2, [SP]
    // 0x1277348: r0 = ==()
    //     0x1277348: bl              #0x1278be0  ; [package:flutter/src/painting/text_style.dart] TextStyle::==
    // 0x127734c: tbnz            w0, #4, #0x12774ac
    // 0x1277350: ldr             x2, [fp, #0x18]
    // 0x1277354: ldr             x1, [fp, #0x10]
    // 0x1277358: LoadField: r0 = r2->field_27
    //     0x1277358: ldur            w0, [x2, #0x27]
    // 0x127735c: DecompressPointer r0
    //     0x127735c: add             x0, x0, HEAP, lsl #32
    // 0x1277360: LoadField: r3 = r1->field_27
    //     0x1277360: ldur            w3, [x1, #0x27]
    // 0x1277364: DecompressPointer r3
    //     0x1277364: add             x3, x3, HEAP, lsl #32
    // 0x1277368: r4 = LoadClassIdInstr(r0)
    //     0x1277368: ldur            x4, [x0, #-1]
    //     0x127736c: ubfx            x4, x4, #0xc, #0x14
    // 0x1277370: stp             x3, x0, [SP]
    // 0x1277374: mov             x0, x4
    // 0x1277378: mov             lr, x0
    // 0x127737c: ldr             lr, [x21, lr, lsl #3]
    // 0x1277380: blr             lr
    // 0x1277384: tbnz            w0, #4, #0x12774ac
    // 0x1277388: ldr             x1, [fp, #0x18]
    // 0x127738c: ldr             x0, [fp, #0x10]
    // 0x1277390: LoadField: r2 = r1->field_2b
    //     0x1277390: ldur            w2, [x1, #0x2b]
    // 0x1277394: DecompressPointer r2
    //     0x1277394: add             x2, x2, HEAP, lsl #32
    // 0x1277398: LoadField: r3 = r0->field_2b
    //     0x1277398: ldur            w3, [x0, #0x2b]
    // 0x127739c: DecompressPointer r3
    //     0x127739c: add             x3, x3, HEAP, lsl #32
    // 0x12773a0: stp             x3, x2, [SP]
    // 0x12773a4: r0 = ==()
    //     0x12773a4: bl              #0x1278be0  ; [package:flutter/src/painting/text_style.dart] TextStyle::==
    // 0x12773a8: tbnz            w0, #4, #0x12774ac
    // 0x12773ac: ldr             x2, [fp, #0x18]
    // 0x12773b0: ldr             x1, [fp, #0x10]
    // 0x12773b4: LoadField: r0 = r2->field_2f
    //     0x12773b4: ldur            w0, [x2, #0x2f]
    // 0x12773b8: DecompressPointer r0
    //     0x12773b8: add             x0, x0, HEAP, lsl #32
    // 0x12773bc: LoadField: r3 = r1->field_2f
    //     0x12773bc: ldur            w3, [x1, #0x2f]
    // 0x12773c0: DecompressPointer r3
    //     0x12773c0: add             x3, x3, HEAP, lsl #32
    // 0x12773c4: r4 = LoadClassIdInstr(r0)
    //     0x12773c4: ldur            x4, [x0, #-1]
    //     0x12773c8: ubfx            x4, x4, #0xc, #0x14
    // 0x12773cc: stp             x3, x0, [SP]
    // 0x12773d0: mov             x0, x4
    // 0x12773d4: mov             lr, x0
    // 0x12773d8: ldr             lr, [x21, lr, lsl #3]
    // 0x12773dc: blr             lr
    // 0x12773e0: tbnz            w0, #4, #0x12774ac
    // 0x12773e4: ldr             x2, [fp, #0x18]
    // 0x12773e8: ldr             x1, [fp, #0x10]
    // 0x12773ec: LoadField: r0 = r2->field_33
    //     0x12773ec: ldur            w0, [x2, #0x33]
    // 0x12773f0: DecompressPointer r0
    //     0x12773f0: add             x0, x0, HEAP, lsl #32
    // 0x12773f4: LoadField: r3 = r1->field_33
    //     0x12773f4: ldur            w3, [x1, #0x33]
    // 0x12773f8: DecompressPointer r3
    //     0x12773f8: add             x3, x3, HEAP, lsl #32
    // 0x12773fc: r4 = LoadClassIdInstr(r0)
    //     0x12773fc: ldur            x4, [x0, #-1]
    //     0x1277400: ubfx            x4, x4, #0xc, #0x14
    // 0x1277404: stp             x3, x0, [SP]
    // 0x1277408: mov             x0, x4
    // 0x127740c: mov             lr, x0
    // 0x1277410: ldr             lr, [x21, lr, lsl #3]
    // 0x1277414: blr             lr
    // 0x1277418: tbnz            w0, #4, #0x12774ac
    // 0x127741c: ldr             x1, [fp, #0x18]
    // 0x1277420: ldr             x0, [fp, #0x10]
    // 0x1277424: LoadField: r2 = r1->field_37
    //     0x1277424: ldur            w2, [x1, #0x37]
    // 0x1277428: DecompressPointer r2
    //     0x1277428: add             x2, x2, HEAP, lsl #32
    // 0x127742c: LoadField: r3 = r0->field_37
    //     0x127742c: ldur            w3, [x0, #0x37]
    // 0x1277430: DecompressPointer r3
    //     0x1277430: add             x3, x3, HEAP, lsl #32
    // 0x1277434: stp             x3, x2, [SP]
    // 0x1277438: r0 = ==()
    //     0x1277438: bl              #0x1278be0  ; [package:flutter/src/painting/text_style.dart] TextStyle::==
    // 0x127743c: tbnz            w0, #4, #0x12774ac
    // 0x1277440: ldr             x2, [fp, #0x18]
    // 0x1277444: ldr             x1, [fp, #0x10]
    // 0x1277448: LoadField: r0 = r2->field_3b
    //     0x1277448: ldur            w0, [x2, #0x3b]
    // 0x127744c: DecompressPointer r0
    //     0x127744c: add             x0, x0, HEAP, lsl #32
    // 0x1277450: LoadField: r3 = r1->field_3b
    //     0x1277450: ldur            w3, [x1, #0x3b]
    // 0x1277454: DecompressPointer r3
    //     0x1277454: add             x3, x3, HEAP, lsl #32
    // 0x1277458: r4 = LoadClassIdInstr(r0)
    //     0x1277458: ldur            x4, [x0, #-1]
    //     0x127745c: ubfx            x4, x4, #0xc, #0x14
    // 0x1277460: stp             x3, x0, [SP]
    // 0x1277464: mov             x0, x4
    // 0x1277468: mov             lr, x0
    // 0x127746c: ldr             lr, [x21, lr, lsl #3]
    // 0x1277470: blr             lr
    // 0x1277474: tbnz            w0, #4, #0x12774ac
    // 0x1277478: ldr             x1, [fp, #0x18]
    // 0x127747c: ldr             x0, [fp, #0x10]
    // 0x1277480: LoadField: r2 = r1->field_3f
    //     0x1277480: ldur            w2, [x1, #0x3f]
    // 0x1277484: DecompressPointer r2
    //     0x1277484: add             x2, x2, HEAP, lsl #32
    // 0x1277488: LoadField: r1 = r0->field_3f
    //     0x1277488: ldur            w1, [x0, #0x3f]
    // 0x127748c: DecompressPointer r1
    //     0x127748c: add             x1, x1, HEAP, lsl #32
    // 0x1277490: r0 = LoadClassIdInstr(r2)
    //     0x1277490: ldur            x0, [x2, #-1]
    //     0x1277494: ubfx            x0, x0, #0xc, #0x14
    // 0x1277498: stp             x1, x2, [SP]
    // 0x127749c: mov             lr, x0
    // 0x12774a0: ldr             lr, [x21, lr, lsl #3]
    // 0x12774a4: blr             lr
    // 0x12774a8: b               #0x12774b0
    // 0x12774ac: r0 = false
    //     0x12774ac: add             x0, NULL, #0x30  ; false
    // 0x12774b0: LeaveFrame
    //     0x12774b0: mov             SP, fp
    //     0x12774b4: ldp             fp, lr, [SP], #0x10
    // 0x12774b8: ret
    //     0x12774b8: ret             
    // 0x12774bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12774bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12774c0: b               #0x1277110
  }
}
