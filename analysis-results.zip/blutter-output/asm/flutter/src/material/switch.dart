// lib: , url: package:flutter/src/material/switch.dart

// class id: 1048953, size: 0x8
class :: {
}

// class id: 4512, size: 0x10c, field offset: 0x60
class _SwitchPainter extends ToggleablePainter {

  late double? _pressedThumbExtension; // offset: 0x108

  _ paint(/* No info */) {
    // ** addr: 0xb6c818, size: 0xd24
    // 0xb6c818: EnterFrame
    //     0xb6c818: stp             fp, lr, [SP, #-0x10]!
    //     0xb6c81c: mov             fp, SP
    // 0xb6c820: AllocStack(0x78)
    //     0xb6c820: sub             SP, SP, #0x78
    // 0xb6c824: SetupParameters(_SwitchPainter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xb6c824: mov             x0, x2
    //     0xb6c828: stur            x2, [fp, #-0x10]
    //     0xb6c82c: mov             x2, x3
    //     0xb6c830: stur            x1, [fp, #-8]
    //     0xb6c834: stur            x3, [fp, #-0x18]
    // 0xb6c838: CheckStackOverflow
    //     0xb6c838: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6c83c: cmp             SP, x16
    //     0xb6c840: b.ls            #0xb6d424
    // 0xb6c844: r1 = 3
    //     0xb6c844: mov             x1, #3
    // 0xb6c848: r0 = AllocateContext()
    //     0xb6c848: bl              #0x13de838  ; AllocateContextStub
    // 0xb6c84c: mov             x2, x0
    // 0xb6c850: ldur            x0, [fp, #-8]
    // 0xb6c854: stur            x2, [fp, #-0x20]
    // 0xb6c858: StoreField: r2->field_f = r0
    //     0xb6c858: stur            w0, [x2, #0xf]
    // 0xb6c85c: LoadField: r1 = r0->field_23
    //     0xb6c85c: ldur            w1, [x0, #0x23]
    // 0xb6c860: DecompressPointer r1
    //     0xb6c860: add             x1, x1, HEAP, lsl #32
    // 0xb6c864: cmp             w1, NULL
    // 0xb6c868: b.eq            #0xb6d42c
    // 0xb6c86c: r0 = value()
    //     0xb6c86c: bl              #0xae5f84  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xb6c870: mov             x2, x0
    // 0xb6c874: ldur            x0, [fp, #-8]
    // 0xb6c878: stur            x2, [fp, #-0x28]
    // 0xb6c87c: LoadField: r1 = r0->field_cb
    //     0xb6c87c: ldur            w1, [x0, #0xcb]
    // 0xb6c880: DecompressPointer r1
    //     0xb6c880: add             x1, x1, HEAP, lsl #32
    // 0xb6c884: cmp             w1, NULL
    // 0xb6c888: b.eq            #0xb6d430
    // 0xb6c88c: LoadField: r3 = r1->field_7
    //     0xb6c88c: ldur            x3, [x1, #7]
    // 0xb6c890: cmp             x3, #0
    // 0xb6c894: b.gt            #0xb6c8ac
    // 0xb6c898: d0 = 1.000000
    //     0xb6c898: fmov            d0, #1.00000000
    // 0xb6c89c: LoadField: d1 = r2->field_7
    //     0xb6c89c: ldur            d1, [x2, #7]
    // 0xb6c8a0: fsub            d2, d0, d1
    // 0xb6c8a4: mov             v1.16b, v2.16b
    // 0xb6c8a8: b               #0xb6c8b4
    // 0xb6c8ac: d0 = 1.000000
    //     0xb6c8ac: fmov            d0, #1.00000000
    // 0xb6c8b0: LoadField: d1 = r2->field_7
    //     0xb6c8b0: ldur            d1, [x2, #7]
    // 0xb6c8b4: stur            d1, [fp, #-0x58]
    // 0xb6c8b8: LoadField: r1 = r0->field_27
    //     0xb6c8b8: ldur            w1, [x0, #0x27]
    // 0xb6c8bc: DecompressPointer r1
    //     0xb6c8bc: add             x1, x1, HEAP, lsl #32
    // 0xb6c8c0: cmp             w1, NULL
    // 0xb6c8c4: b.eq            #0xb6d434
    // 0xb6c8c8: r0 = status()
    //     0xb6c8c8: bl              #0x1284c0c  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::status
    // 0xb6c8cc: r16 = Instance_AnimationStatus
    //     0xb6c8cc: ldr             x16, [PP, #0x51c0]  ; [pp+0x51c0] Obj!AnimationStatus@12c6161
    // 0xb6c8d0: cmp             w0, w16
    // 0xb6c8d4: b.ne            #0xb6c8f8
    // 0xb6c8d8: ldur            x0, [fp, #-8]
    // 0xb6c8dc: LoadField: r1 = r0->field_fb
    //     0xb6c8dc: ldur            w1, [x0, #0xfb]
    // 0xb6c8e0: DecompressPointer r1
    //     0xb6c8e0: add             x1, x1, HEAP, lsl #32
    // 0xb6c8e4: tbz             w1, #4, #0xb6c8fc
    // 0xb6c8e8: r1 = true
    //     0xb6c8e8: add             x1, NULL, #0x20  ; true
    // 0xb6c8ec: StoreField: r0->field_fb = r1
    //     0xb6c8ec: stur            w1, [x0, #0xfb]
    // 0xb6c8f0: r1 = true
    //     0xb6c8f0: add             x1, NULL, #0x20  ; true
    // 0xb6c8f4: b               #0xb6c908
    // 0xb6c8f8: ldur            x0, [fp, #-8]
    // 0xb6c8fc: r1 = false
    //     0xb6c8fc: add             x1, NULL, #0x30  ; false
    // 0xb6c900: StoreField: r0->field_fb = r1
    //     0xb6c900: stur            w1, [x0, #0xfb]
    // 0xb6c904: r1 = false
    //     0xb6c904: add             x1, NULL, #0x30  ; false
    // 0xb6c908: tbz             w1, #4, #0xb6cc10
    // 0xb6c90c: LoadField: r1 = r0->field_db
    //     0xb6c90c: ldur            w1, [x0, #0xdb]
    // 0xb6c910: DecompressPointer r1
    //     0xb6c910: add             x1, x1, HEAP, lsl #32
    // 0xb6c914: cmp             w1, NULL
    // 0xb6c918: b.eq            #0xb6d438
    // 0xb6c91c: tbnz            w1, #4, #0xb6c948
    // 0xb6c920: LoadField: r1 = r0->field_27
    //     0xb6c920: ldur            w1, [x0, #0x27]
    // 0xb6c924: DecompressPointer r1
    //     0xb6c924: add             x1, x1, HEAP, lsl #32
    // 0xb6c928: cmp             w1, NULL
    // 0xb6c92c: b.eq            #0xb6d43c
    // 0xb6c930: r0 = value()
    //     0xb6c930: bl              #0xae5f84  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xb6c934: LoadField: d0 = r0->field_7
    //     0xb6c934: ldur            d0, [x0, #7]
    // 0xb6c938: d1 = 7.000000
    //     0xb6c938: fmov            d1, #7.00000000
    // 0xb6c93c: fmul            d2, d0, d1
    // 0xb6c940: mov             v0.16b, v2.16b
    // 0xb6c944: b               #0xb6c94c
    // 0xb6c948: d0 = 0.000000
    //     0xb6c948: eor             v0.16b, v0.16b, v0.16b
    // 0xb6c94c: ldur            x2, [fp, #-8]
    // 0xb6c950: r0 = inline_Allocate_Double()
    //     0xb6c950: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb6c954: add             x0, x0, #0x10
    //     0xb6c958: cmp             x1, x0
    //     0xb6c95c: b.ls            #0xb6d440
    //     0xb6c960: str             x0, [THR, #0x60]  ; THR::top
    //     0xb6c964: sub             x0, x0, #0xf
    //     0xb6c968: mov             x1, #0xe19c
    //     0xb6c96c: movk            x1, #3, lsl #16
    //     0xb6c970: stur            x1, [x0, #-1]
    // 0xb6c974: dmb             ishst
    // 0xb6c978: StoreField: r0->field_7 = d0
    //     0xb6c978: stur            d0, [x0, #7]
    // 0xb6c97c: r17 = 263
    //     0xb6c97c: mov             x17, #0x107
    // 0xb6c980: str             w0, [x2, x17]
    // 0xb6c984: WriteBarrierInstr(obj = r2, val = r0)
    //     0xb6c984: ldurb           w16, [x2, #-1]
    //     0xb6c988: ldurb           w17, [x0, #-1]
    //     0xb6c98c: and             x16, x17, x16, lsr #2
    //     0xb6c990: tst             x16, HEAP, lsr #32
    //     0xb6c994: b.eq            #0xb6c99c
    //     0xb6c998: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb6c99c: LoadField: r1 = r2->field_27
    //     0xb6c99c: ldur            w1, [x2, #0x27]
    // 0xb6c9a0: DecompressPointer r1
    //     0xb6c9a0: add             x1, x1, HEAP, lsl #32
    // 0xb6c9a4: cmp             w1, NULL
    // 0xb6c9a8: b.eq            #0xb6d458
    // 0xb6c9ac: r0 = status()
    //     0xb6c9ac: bl              #0x1284c0c  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::status
    // 0xb6c9b0: r16 = Instance_AnimationStatus
    //     0xb6c9b0: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0xb6c9b4: cmp             w0, w16
    // 0xb6c9b8: b.ne            #0xb6caa0
    // 0xb6c9bc: ldur            x0, [fp, #-8]
    // 0xb6c9c0: LoadField: r2 = r0->field_87
    //     0xb6c9c0: ldur            w2, [x0, #0x87]
    // 0xb6c9c4: DecompressPointer r2
    //     0xb6c9c4: add             x2, x2, HEAP, lsl #32
    // 0xb6c9c8: stur            x2, [fp, #-0x38]
    // 0xb6c9cc: cmp             w2, NULL
    // 0xb6c9d0: b.eq            #0xb6d45c
    // 0xb6c9d4: LoadField: r3 = r0->field_8b
    //     0xb6c9d4: ldur            w3, [x0, #0x8b]
    // 0xb6c9d8: DecompressPointer r3
    //     0xb6c9d8: add             x3, x3, HEAP, lsl #32
    // 0xb6c9dc: stur            x3, [fp, #-0x30]
    // 0xb6c9e0: cmp             w3, NULL
    // 0xb6c9e4: b.eq            #0xb6d460
    // 0xb6c9e8: LoadField: r1 = r0->field_27
    //     0xb6c9e8: ldur            w1, [x0, #0x27]
    // 0xb6c9ec: DecompressPointer r1
    //     0xb6c9ec: add             x1, x1, HEAP, lsl #32
    // 0xb6c9f0: cmp             w1, NULL
    // 0xb6c9f4: b.eq            #0xb6d464
    // 0xb6c9f8: r0 = value()
    //     0xb6c9f8: bl              #0xae5f84  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xb6c9fc: ldur            x1, [fp, #-0x38]
    // 0xb6ca00: ldur            x2, [fp, #-0x30]
    // 0xb6ca04: mov             x3, x0
    // 0xb6ca08: r0 = lerpDouble()
    //     0xb6ca08: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xb6ca0c: ldur            x2, [fp, #-8]
    // 0xb6ca10: StoreField: r2->field_ff = r0
    //     0xb6ca10: stur            w0, [x2, #0xff]
    //     0xb6ca14: ldurb           w16, [x2, #-1]
    //     0xb6ca18: ldurb           w17, [x0, #-1]
    //     0xb6ca1c: and             x16, x17, x16, lsr #2
    //     0xb6ca20: tst             x16, HEAP, lsr #32
    //     0xb6ca24: b.eq            #0xb6ca2c
    //     0xb6ca28: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb6ca2c: LoadField: r0 = r2->field_83
    //     0xb6ca2c: ldur            w0, [x2, #0x83]
    // 0xb6ca30: DecompressPointer r0
    //     0xb6ca30: add             x0, x0, HEAP, lsl #32
    // 0xb6ca34: stur            x0, [fp, #-0x38]
    // 0xb6ca38: cmp             w0, NULL
    // 0xb6ca3c: b.eq            #0xb6d468
    // 0xb6ca40: LoadField: r3 = r2->field_8b
    //     0xb6ca40: ldur            w3, [x2, #0x8b]
    // 0xb6ca44: DecompressPointer r3
    //     0xb6ca44: add             x3, x3, HEAP, lsl #32
    // 0xb6ca48: stur            x3, [fp, #-0x30]
    // 0xb6ca4c: cmp             w3, NULL
    // 0xb6ca50: b.eq            #0xb6d46c
    // 0xb6ca54: LoadField: r1 = r2->field_27
    //     0xb6ca54: ldur            w1, [x2, #0x27]
    // 0xb6ca58: DecompressPointer r1
    //     0xb6ca58: add             x1, x1, HEAP, lsl #32
    // 0xb6ca5c: cmp             w1, NULL
    // 0xb6ca60: b.eq            #0xb6d470
    // 0xb6ca64: r0 = value()
    //     0xb6ca64: bl              #0xae5f84  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xb6ca68: ldur            x1, [fp, #-0x38]
    // 0xb6ca6c: ldur            x2, [fp, #-0x30]
    // 0xb6ca70: mov             x3, x0
    // 0xb6ca74: r0 = lerpDouble()
    //     0xb6ca74: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xb6ca78: ldur            x2, [fp, #-8]
    // 0xb6ca7c: r17 = 259
    //     0xb6ca7c: mov             x17, #0x103
    // 0xb6ca80: str             w0, [x2, x17]
    // 0xb6ca84: WriteBarrierInstr(obj = r2, val = r0)
    //     0xb6ca84: ldurb           w16, [x2, #-1]
    //     0xb6ca88: ldurb           w17, [x0, #-1]
    //     0xb6ca8c: and             x16, x17, x16, lsr #2
    //     0xb6ca90: tst             x16, HEAP, lsr #32
    //     0xb6ca94: b.eq            #0xb6ca9c
    //     0xb6ca98: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb6ca9c: b               #0xb6caa4
    // 0xb6caa0: ldur            x2, [fp, #-8]
    // 0xb6caa4: ldur            x0, [fp, #-0x28]
    // 0xb6caa8: d0 = 0.000000
    //     0xb6caa8: eor             v0.16b, v0.16b, v0.16b
    // 0xb6caac: LoadField: d1 = r0->field_7
    //     0xb6caac: ldur            d1, [x0, #7]
    // 0xb6cab0: stur            d1, [fp, #-0x60]
    // 0xb6cab4: fcmp            d1, d0
    // 0xb6cab8: b.ne            #0xb6cb58
    // 0xb6cabc: LoadField: r3 = r2->field_87
    //     0xb6cabc: ldur            w3, [x2, #0x87]
    // 0xb6cac0: DecompressPointer r3
    //     0xb6cac0: add             x3, x3, HEAP, lsl #32
    // 0xb6cac4: stur            x3, [fp, #-0x38]
    // 0xb6cac8: cmp             w3, NULL
    // 0xb6cacc: b.eq            #0xb6d474
    // 0xb6cad0: LoadField: r4 = r2->field_8b
    //     0xb6cad0: ldur            w4, [x2, #0x8b]
    // 0xb6cad4: DecompressPointer r4
    //     0xb6cad4: add             x4, x4, HEAP, lsl #32
    // 0xb6cad8: stur            x4, [fp, #-0x30]
    // 0xb6cadc: cmp             w4, NULL
    // 0xb6cae0: b.eq            #0xb6d478
    // 0xb6cae4: LoadField: r1 = r2->field_27
    //     0xb6cae4: ldur            w1, [x2, #0x27]
    // 0xb6cae8: DecompressPointer r1
    //     0xb6cae8: add             x1, x1, HEAP, lsl #32
    // 0xb6caec: cmp             w1, NULL
    // 0xb6caf0: b.eq            #0xb6d47c
    // 0xb6caf4: r0 = value()
    //     0xb6caf4: bl              #0xae5f84  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xb6caf8: ldur            x1, [fp, #-0x38]
    // 0xb6cafc: ldur            x2, [fp, #-0x30]
    // 0xb6cb00: mov             x3, x0
    // 0xb6cb04: r0 = lerpDouble()
    //     0xb6cb04: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xb6cb08: ldur            x2, [fp, #-8]
    // 0xb6cb0c: StoreField: r2->field_ff = r0
    //     0xb6cb0c: stur            w0, [x2, #0xff]
    //     0xb6cb10: ldurb           w16, [x2, #-1]
    //     0xb6cb14: ldurb           w17, [x0, #-1]
    //     0xb6cb18: and             x16, x17, x16, lsr #2
    //     0xb6cb1c: tst             x16, HEAP, lsr #32
    //     0xb6cb20: b.eq            #0xb6cb28
    //     0xb6cb24: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb6cb28: LoadField: r0 = r2->field_83
    //     0xb6cb28: ldur            w0, [x2, #0x83]
    // 0xb6cb2c: DecompressPointer r0
    //     0xb6cb2c: add             x0, x0, HEAP, lsl #32
    // 0xb6cb30: cmp             w0, NULL
    // 0xb6cb34: b.eq            #0xb6d480
    // 0xb6cb38: r17 = 259
    //     0xb6cb38: mov             x17, #0x103
    // 0xb6cb3c: str             w0, [x2, x17]
    // 0xb6cb40: WriteBarrierInstr(obj = r2, val = r0)
    //     0xb6cb40: ldurb           w16, [x2, #-1]
    //     0xb6cb44: ldurb           w17, [x0, #-1]
    //     0xb6cb48: and             x16, x17, x16, lsr #2
    //     0xb6cb4c: tst             x16, HEAP, lsr #32
    //     0xb6cb50: b.eq            #0xb6cb58
    //     0xb6cb54: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb6cb58: ldur            d0, [fp, #-0x60]
    // 0xb6cb5c: d1 = 1.000000
    //     0xb6cb5c: fmov            d1, #1.00000000
    // 0xb6cb60: fcmp            d0, d1
    // 0xb6cb64: b.ne            #0xb6cc08
    // 0xb6cb68: LoadField: r0 = r2->field_83
    //     0xb6cb68: ldur            w0, [x2, #0x83]
    // 0xb6cb6c: DecompressPointer r0
    //     0xb6cb6c: add             x0, x0, HEAP, lsl #32
    // 0xb6cb70: stur            x0, [fp, #-0x38]
    // 0xb6cb74: cmp             w0, NULL
    // 0xb6cb78: b.eq            #0xb6d484
    // 0xb6cb7c: LoadField: r3 = r2->field_8b
    //     0xb6cb7c: ldur            w3, [x2, #0x8b]
    // 0xb6cb80: DecompressPointer r3
    //     0xb6cb80: add             x3, x3, HEAP, lsl #32
    // 0xb6cb84: stur            x3, [fp, #-0x30]
    // 0xb6cb88: cmp             w3, NULL
    // 0xb6cb8c: b.eq            #0xb6d488
    // 0xb6cb90: LoadField: r1 = r2->field_27
    //     0xb6cb90: ldur            w1, [x2, #0x27]
    // 0xb6cb94: DecompressPointer r1
    //     0xb6cb94: add             x1, x1, HEAP, lsl #32
    // 0xb6cb98: cmp             w1, NULL
    // 0xb6cb9c: b.eq            #0xb6d48c
    // 0xb6cba0: r0 = value()
    //     0xb6cba0: bl              #0xae5f84  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xb6cba4: ldur            x1, [fp, #-0x38]
    // 0xb6cba8: ldur            x2, [fp, #-0x30]
    // 0xb6cbac: mov             x3, x0
    // 0xb6cbb0: r0 = lerpDouble()
    //     0xb6cbb0: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xb6cbb4: ldur            x1, [fp, #-8]
    // 0xb6cbb8: r17 = 259
    //     0xb6cbb8: mov             x17, #0x103
    // 0xb6cbbc: str             w0, [x1, x17]
    // 0xb6cbc0: WriteBarrierInstr(obj = r1, val = r0)
    //     0xb6cbc0: ldurb           w16, [x1, #-1]
    //     0xb6cbc4: ldurb           w17, [x0, #-1]
    //     0xb6cbc8: and             x16, x17, x16, lsr #2
    //     0xb6cbcc: tst             x16, HEAP, lsr #32
    //     0xb6cbd0: b.eq            #0xb6cbd8
    //     0xb6cbd4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb6cbd8: LoadField: r0 = r1->field_87
    //     0xb6cbd8: ldur            w0, [x1, #0x87]
    // 0xb6cbdc: DecompressPointer r0
    //     0xb6cbdc: add             x0, x0, HEAP, lsl #32
    // 0xb6cbe0: cmp             w0, NULL
    // 0xb6cbe4: b.eq            #0xb6d490
    // 0xb6cbe8: StoreField: r1->field_ff = r0
    //     0xb6cbe8: stur            w0, [x1, #0xff]
    //     0xb6cbec: ldurb           w16, [x1, #-1]
    //     0xb6cbf0: ldurb           w17, [x0, #-1]
    //     0xb6cbf4: and             x16, x17, x16, lsr #2
    //     0xb6cbf8: tst             x16, HEAP, lsr #32
    //     0xb6cbfc: b.eq            #0xb6cc04
    //     0xb6cc00: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb6cc04: b               #0xb6cc14
    // 0xb6cc08: mov             x1, x2
    // 0xb6cc0c: b               #0xb6cc14
    // 0xb6cc10: mov             x1, x0
    // 0xb6cc14: LoadField: r0 = r1->field_db
    //     0xb6cc14: ldur            w0, [x1, #0xdb]
    // 0xb6cc18: DecompressPointer r0
    //     0xb6cc18: add             x0, x0, HEAP, lsl #32
    // 0xb6cc1c: stur            x0, [fp, #-0x30]
    // 0xb6cc20: cmp             w0, NULL
    // 0xb6cc24: b.eq            #0xb6d494
    // 0xb6cc28: tbnz            w0, #4, #0xb6cc8c
    // 0xb6cc2c: d0 = 2.000000
    //     0xb6cc2c: fmov            d0, #2.00000000
    // 0xb6cc30: LoadField: r2 = r1->field_ff
    //     0xb6cc30: ldur            w2, [x1, #0xff]
    // 0xb6cc34: DecompressPointer r2
    //     0xb6cc34: add             x2, x2, HEAP, lsl #32
    // 0xb6cc38: cmp             w2, NULL
    // 0xb6cc3c: b.eq            #0xb6d498
    // 0xb6cc40: LoadField: d1 = r2->field_7
    //     0xb6cc40: ldur            d1, [x2, #7]
    // 0xb6cc44: fmul            d2, d1, d0
    // 0xb6cc48: stur            d2, [fp, #-0x68]
    // 0xb6cc4c: r17 = 263
    //     0xb6cc4c: mov             x17, #0x107
    // 0xb6cc50: ldr             w2, [x1, x17]
    // 0xb6cc54: DecompressPointer r2
    //     0xb6cc54: add             x2, x2, HEAP, lsl #32
    // 0xb6cc58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb6cc5c: cmp             w2, w16
    // 0xb6cc60: b.eq            #0xb6d49c
    // 0xb6cc64: LoadField: d1 = r2->field_7
    //     0xb6cc64: ldur            d1, [x2, #7]
    // 0xb6cc68: fadd            d3, d2, d1
    // 0xb6cc6c: stur            d3, [fp, #-0x60]
    // 0xb6cc70: r0 = Size()
    //     0xb6cc70: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb6cc74: ldur            d0, [fp, #-0x60]
    // 0xb6cc78: StoreField: r0->field_7 = d0
    //     0xb6cc78: stur            d0, [x0, #7]
    // 0xb6cc7c: ldur            d0, [fp, #-0x68]
    // 0xb6cc80: StoreField: r0->field_f = d0
    //     0xb6cc80: stur            d0, [x0, #0xf]
    // 0xb6cc84: mov             x3, x0
    // 0xb6cc88: b               #0xb6cce0
    // 0xb6cc8c: LoadField: r0 = r1->field_ff
    //     0xb6cc8c: ldur            w0, [x1, #0xff]
    // 0xb6cc90: DecompressPointer r0
    //     0xb6cc90: add             x0, x0, HEAP, lsl #32
    // 0xb6cc94: cmp             w0, NULL
    // 0xb6cc98: b.ne            #0xb6ccb8
    // 0xb6cc9c: LoadField: r0 = r1->field_87
    //     0xb6cc9c: ldur            w0, [x1, #0x87]
    // 0xb6cca0: DecompressPointer r0
    //     0xb6cca0: add             x0, x0, HEAP, lsl #32
    // 0xb6cca4: cmp             w0, NULL
    // 0xb6cca8: b.eq            #0xb6d4a8
    // 0xb6ccac: LoadField: d0 = r0->field_7
    //     0xb6ccac: ldur            d0, [x0, #7]
    // 0xb6ccb0: mov             v1.16b, v0.16b
    // 0xb6ccb4: b               #0xb6ccc0
    // 0xb6ccb8: LoadField: d0 = r0->field_7
    //     0xb6ccb8: ldur            d0, [x0, #7]
    // 0xb6ccbc: mov             v1.16b, v0.16b
    // 0xb6ccc0: d0 = 2.000000
    //     0xb6ccc0: fmov            d0, #2.00000000
    // 0xb6ccc4: fmul            d2, d1, d0
    // 0xb6ccc8: stur            d2, [fp, #-0x60]
    // 0xb6cccc: r0 = Size()
    //     0xb6cccc: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb6ccd0: ldur            d0, [fp, #-0x60]
    // 0xb6ccd4: StoreField: r0->field_7 = d0
    //     0xb6ccd4: stur            d0, [x0, #7]
    // 0xb6ccd8: StoreField: r0->field_f = d0
    //     0xb6ccd8: stur            d0, [x0, #0xf]
    // 0xb6ccdc: mov             x3, x0
    // 0xb6cce0: ldur            x2, [fp, #-0x20]
    // 0xb6cce4: ldur            x1, [fp, #-0x30]
    // 0xb6cce8: mov             x0, x3
    // 0xb6ccec: stur            x3, [fp, #-0x38]
    // 0xb6ccf0: StoreField: r2->field_13 = r0
    //     0xb6ccf0: stur            w0, [x2, #0x13]
    //     0xb6ccf4: ldurb           w16, [x2, #-1]
    //     0xb6ccf8: ldurb           w17, [x0, #-1]
    //     0xb6ccfc: and             x16, x17, x16, lsr #2
    //     0xb6cd00: tst             x16, HEAP, lsr #32
    //     0xb6cd04: b.eq            #0xb6cd0c
    //     0xb6cd08: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb6cd0c: tbnz            w1, #4, #0xb6cd78
    // 0xb6cd10: ldur            x0, [fp, #-8]
    // 0xb6cd14: d0 = 2.000000
    //     0xb6cd14: fmov            d0, #2.00000000
    // 0xb6cd18: r17 = 259
    //     0xb6cd18: mov             x17, #0x103
    // 0xb6cd1c: ldr             w4, [x0, x17]
    // 0xb6cd20: DecompressPointer r4
    //     0xb6cd20: add             x4, x4, HEAP, lsl #32
    // 0xb6cd24: cmp             w4, NULL
    // 0xb6cd28: b.eq            #0xb6d4ac
    // 0xb6cd2c: LoadField: d1 = r4->field_7
    //     0xb6cd2c: ldur            d1, [x4, #7]
    // 0xb6cd30: fmul            d2, d1, d0
    // 0xb6cd34: stur            d2, [fp, #-0x68]
    // 0xb6cd38: r17 = 263
    //     0xb6cd38: mov             x17, #0x107
    // 0xb6cd3c: ldr             w4, [x0, x17]
    // 0xb6cd40: DecompressPointer r4
    //     0xb6cd40: add             x4, x4, HEAP, lsl #32
    // 0xb6cd44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb6cd48: cmp             w4, w16
    // 0xb6cd4c: b.eq            #0xb6d4b0
    // 0xb6cd50: LoadField: d1 = r4->field_7
    //     0xb6cd50: ldur            d1, [x4, #7]
    // 0xb6cd54: fadd            d3, d2, d1
    // 0xb6cd58: stur            d3, [fp, #-0x60]
    // 0xb6cd5c: r0 = Size()
    //     0xb6cd5c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb6cd60: ldur            d0, [fp, #-0x60]
    // 0xb6cd64: StoreField: r0->field_7 = d0
    //     0xb6cd64: stur            d0, [x0, #7]
    // 0xb6cd68: ldur            d0, [fp, #-0x68]
    // 0xb6cd6c: StoreField: r0->field_f = d0
    //     0xb6cd6c: stur            d0, [x0, #0xf]
    // 0xb6cd70: mov             x4, x0
    // 0xb6cd74: b               #0xb6cdd4
    // 0xb6cd78: ldur            x1, [fp, #-8]
    // 0xb6cd7c: r17 = 259
    //     0xb6cd7c: mov             x17, #0x103
    // 0xb6cd80: ldr             w0, [x1, x17]
    // 0xb6cd84: DecompressPointer r0
    //     0xb6cd84: add             x0, x0, HEAP, lsl #32
    // 0xb6cd88: cmp             w0, NULL
    // 0xb6cd8c: b.ne            #0xb6cdac
    // 0xb6cd90: LoadField: r0 = r1->field_83
    //     0xb6cd90: ldur            w0, [x1, #0x83]
    // 0xb6cd94: DecompressPointer r0
    //     0xb6cd94: add             x0, x0, HEAP, lsl #32
    // 0xb6cd98: cmp             w0, NULL
    // 0xb6cd9c: b.eq            #0xb6d4bc
    // 0xb6cda0: LoadField: d0 = r0->field_7
    //     0xb6cda0: ldur            d0, [x0, #7]
    // 0xb6cda4: mov             v1.16b, v0.16b
    // 0xb6cda8: b               #0xb6cdb4
    // 0xb6cdac: LoadField: d0 = r0->field_7
    //     0xb6cdac: ldur            d0, [x0, #7]
    // 0xb6cdb0: mov             v1.16b, v0.16b
    // 0xb6cdb4: d0 = 2.000000
    //     0xb6cdb4: fmov            d0, #2.00000000
    // 0xb6cdb8: fmul            d2, d1, d0
    // 0xb6cdbc: stur            d2, [fp, #-0x60]
    // 0xb6cdc0: r0 = Size()
    //     0xb6cdc0: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb6cdc4: ldur            d0, [fp, #-0x60]
    // 0xb6cdc8: StoreField: r0->field_7 = d0
    //     0xb6cdc8: stur            d0, [x0, #7]
    // 0xb6cdcc: StoreField: r0->field_f = d0
    //     0xb6cdcc: stur            d0, [x0, #0xf]
    // 0xb6cdd0: mov             x4, x0
    // 0xb6cdd4: ldur            x2, [fp, #-0x20]
    // 0xb6cdd8: ldur            x3, [fp, #-0x30]
    // 0xb6cddc: mov             x0, x4
    // 0xb6cde0: stur            x4, [fp, #-0x40]
    // 0xb6cde4: ArrayStore: r2[0] = r0  ; List_4
    //     0xb6cde4: stur            w0, [x2, #0x17]
    //     0xb6cde8: ldurb           w16, [x2, #-1]
    //     0xb6cdec: ldurb           w17, [x0, #-1]
    //     0xb6cdf0: and             x16, x17, x16, lsr #2
    //     0xb6cdf4: tst             x16, HEAP, lsr #32
    //     0xb6cdf8: b.eq            #0xb6ce00
    //     0xb6cdfc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb6ce00: r1 = Function 'thumbSizeAnimation':.
    //     0xb6ce00: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3548] AnonymousClosure: (0xb6ef78), in [package:flutter/src/material/switch.dart] _SwitchPainter::paint (0xb6c818)
    //     0xb6ce04: ldr             x1, [x1, #0x548]
    // 0xb6ce08: r0 = AllocateClosure()
    //     0xb6ce08: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb6ce0c: mov             x2, x0
    // 0xb6ce10: ldur            x0, [fp, #-0x30]
    // 0xb6ce14: stur            x2, [fp, #-0x20]
    // 0xb6ce18: tbnz            w0, #4, #0xb6cf40
    // 0xb6ce1c: ldur            x0, [fp, #-8]
    // 0xb6ce20: LoadField: r1 = r0->field_27
    //     0xb6ce20: ldur            w1, [x0, #0x27]
    // 0xb6ce24: DecompressPointer r1
    //     0xb6ce24: add             x1, x1, HEAP, lsl #32
    // 0xb6ce28: cmp             w1, NULL
    // 0xb6ce2c: b.eq            #0xb6d4c0
    // 0xb6ce30: r0 = status()
    //     0xb6ce30: bl              #0x1284c0c  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::status
    // 0xb6ce34: r16 = Instance_AnimationStatus
    //     0xb6ce34: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0xb6ce38: cmp             w0, w16
    // 0xb6ce3c: b.ne            #0xb6cea0
    // 0xb6ce40: ldur            x1, [fp, #-8]
    // 0xb6ce44: d0 = 2.000000
    //     0xb6ce44: fmov            d0, #2.00000000
    // 0xb6ce48: LoadField: r0 = r1->field_ff
    //     0xb6ce48: ldur            w0, [x1, #0xff]
    // 0xb6ce4c: DecompressPointer r0
    //     0xb6ce4c: add             x0, x0, HEAP, lsl #32
    // 0xb6ce50: cmp             w0, NULL
    // 0xb6ce54: b.eq            #0xb6d4c4
    // 0xb6ce58: LoadField: d1 = r0->field_7
    //     0xb6ce58: ldur            d1, [x0, #7]
    // 0xb6ce5c: fmul            d2, d1, d0
    // 0xb6ce60: stur            d2, [fp, #-0x68]
    // 0xb6ce64: r17 = 263
    //     0xb6ce64: mov             x17, #0x107
    // 0xb6ce68: ldr             w0, [x1, x17]
    // 0xb6ce6c: DecompressPointer r0
    //     0xb6ce6c: add             x0, x0, HEAP, lsl #32
    // 0xb6ce70: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb6ce74: cmp             w0, w16
    // 0xb6ce78: b.eq            #0xb6d4c8
    // 0xb6ce7c: LoadField: d1 = r0->field_7
    //     0xb6ce7c: ldur            d1, [x0, #7]
    // 0xb6ce80: fadd            d3, d2, d1
    // 0xb6ce84: stur            d3, [fp, #-0x60]
    // 0xb6ce88: r0 = Size()
    //     0xb6ce88: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb6ce8c: ldur            d0, [fp, #-0x60]
    // 0xb6ce90: StoreField: r0->field_7 = d0
    //     0xb6ce90: stur            d0, [x0, #7]
    // 0xb6ce94: ldur            d0, [fp, #-0x68]
    // 0xb6ce98: StoreField: r0->field_f = d0
    //     0xb6ce98: stur            d0, [x0, #0xf]
    // 0xb6ce9c: b               #0xb6d070
    // 0xb6cea0: ldur            x0, [fp, #-8]
    // 0xb6cea4: LoadField: r1 = r0->field_23
    //     0xb6cea4: ldur            w1, [x0, #0x23]
    // 0xb6cea8: DecompressPointer r1
    //     0xb6cea8: add             x1, x1, HEAP, lsl #32
    // 0xb6ceac: cmp             w1, NULL
    // 0xb6ceb0: b.eq            #0xb6d4d4
    // 0xb6ceb4: r0 = status()
    //     0xb6ceb4: bl              #0x1284c0c  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::status
    // 0xb6ceb8: r16 = Instance_AnimationStatus
    //     0xb6ceb8: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xb6cebc: cmp             w0, w16
    // 0xb6cec0: b.eq            #0xb6cee8
    // 0xb6cec4: ldur            x0, [fp, #-8]
    // 0xb6cec8: LoadField: r1 = r0->field_23
    //     0xb6cec8: ldur            w1, [x0, #0x23]
    // 0xb6cecc: DecompressPointer r1
    //     0xb6cecc: add             x1, x1, HEAP, lsl #32
    // 0xb6ced0: cmp             w1, NULL
    // 0xb6ced4: b.eq            #0xb6d4d8
    // 0xb6ced8: r0 = status()
    //     0xb6ced8: bl              #0x1284c0c  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::status
    // 0xb6cedc: r16 = Instance_AnimationStatus
    //     0xb6cedc: ldr             x16, [PP, #0x51b8]  ; [pp+0x51b8] Obj!AnimationStatus@12c6181
    // 0xb6cee0: cmp             w0, w16
    // 0xb6cee4: b.ne            #0xb6cf14
    // 0xb6cee8: ldur            x0, [fp, #-8]
    // 0xb6ceec: LoadField: r1 = r0->field_23
    //     0xb6ceec: ldur            w1, [x0, #0x23]
    // 0xb6cef0: DecompressPointer r1
    //     0xb6cef0: add             x1, x1, HEAP, lsl #32
    // 0xb6cef4: cmp             w1, NULL
    // 0xb6cef8: b.eq            #0xb6d4dc
    // 0xb6cefc: r0 = value()
    //     0xb6cefc: bl              #0xae5f84  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xb6cf00: ldur            x1, [fp, #-0x38]
    // 0xb6cf04: ldur            x2, [fp, #-0x40]
    // 0xb6cf08: mov             x3, x0
    // 0xb6cf0c: r0 = lerp()
    //     0xb6cf0c: bl              #0xb6ee5c  ; [dart:ui] Size::lerp
    // 0xb6cf10: b               #0xb6d070
    // 0xb6cf14: ldur            x0, [fp, #-8]
    // 0xb6cf18: LoadField: r1 = r0->field_23
    //     0xb6cf18: ldur            w1, [x0, #0x23]
    // 0xb6cf1c: DecompressPointer r1
    //     0xb6cf1c: add             x1, x1, HEAP, lsl #32
    // 0xb6cf20: cmp             w1, NULL
    // 0xb6cf24: b.eq            #0xb6d4e0
    // 0xb6cf28: r0 = value()
    //     0xb6cf28: bl              #0xae5f84  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xb6cf2c: ldur            x1, [fp, #-0x38]
    // 0xb6cf30: ldur            x2, [fp, #-0x40]
    // 0xb6cf34: mov             x3, x0
    // 0xb6cf38: r0 = lerp()
    //     0xb6cf38: bl              #0xb6ee5c  ; [dart:ui] Size::lerp
    // 0xb6cf3c: b               #0xb6d070
    // 0xb6cf40: ldur            x0, [fp, #-8]
    // 0xb6cf44: LoadField: r1 = r0->field_27
    //     0xb6cf44: ldur            w1, [x0, #0x27]
    // 0xb6cf48: DecompressPointer r1
    //     0xb6cf48: add             x1, x1, HEAP, lsl #32
    // 0xb6cf4c: cmp             w1, NULL
    // 0xb6cf50: b.eq            #0xb6d4e4
    // 0xb6cf54: r0 = status()
    //     0xb6cf54: bl              #0x1284c0c  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::status
    // 0xb6cf58: r16 = Instance_AnimationStatus
    //     0xb6cf58: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0xb6cf5c: cmp             w0, w16
    // 0xb6cf60: b.ne            #0xb6cf9c
    // 0xb6cf64: ldur            x1, [fp, #-8]
    // 0xb6cf68: d0 = 2.000000
    //     0xb6cf68: fmov            d0, #2.00000000
    // 0xb6cf6c: LoadField: r0 = r1->field_8b
    //     0xb6cf6c: ldur            w0, [x1, #0x8b]
    // 0xb6cf70: DecompressPointer r0
    //     0xb6cf70: add             x0, x0, HEAP, lsl #32
    // 0xb6cf74: cmp             w0, NULL
    // 0xb6cf78: b.eq            #0xb6d4e8
    // 0xb6cf7c: LoadField: d1 = r0->field_7
    //     0xb6cf7c: ldur            d1, [x0, #7]
    // 0xb6cf80: fmul            d2, d1, d0
    // 0xb6cf84: stur            d2, [fp, #-0x60]
    // 0xb6cf88: r0 = Size()
    //     0xb6cf88: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb6cf8c: ldur            d0, [fp, #-0x60]
    // 0xb6cf90: StoreField: r0->field_7 = d0
    //     0xb6cf90: stur            d0, [x0, #7]
    // 0xb6cf94: StoreField: r0->field_f = d0
    //     0xb6cf94: stur            d0, [x0, #0xf]
    // 0xb6cf98: b               #0xb6d070
    // 0xb6cf9c: ldur            x0, [fp, #-8]
    // 0xb6cfa0: LoadField: r1 = r0->field_23
    //     0xb6cfa0: ldur            w1, [x0, #0x23]
    // 0xb6cfa4: DecompressPointer r1
    //     0xb6cfa4: add             x1, x1, HEAP, lsl #32
    // 0xb6cfa8: cmp             w1, NULL
    // 0xb6cfac: b.eq            #0xb6d4ec
    // 0xb6cfb0: r0 = status()
    //     0xb6cfb0: bl              #0x1284c0c  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::status
    // 0xb6cfb4: r16 = Instance_AnimationStatus
    //     0xb6cfb4: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xb6cfb8: cmp             w0, w16
    // 0xb6cfbc: b.eq            #0xb6cfe4
    // 0xb6cfc0: ldur            x0, [fp, #-8]
    // 0xb6cfc4: LoadField: r1 = r0->field_23
    //     0xb6cfc4: ldur            w1, [x0, #0x23]
    // 0xb6cfc8: DecompressPointer r1
    //     0xb6cfc8: add             x1, x1, HEAP, lsl #32
    // 0xb6cfcc: cmp             w1, NULL
    // 0xb6cfd0: b.eq            #0xb6d4f0
    // 0xb6cfd4: r0 = status()
    //     0xb6cfd4: bl              #0x1284c0c  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::status
    // 0xb6cfd8: r16 = Instance_AnimationStatus
    //     0xb6cfd8: ldr             x16, [PP, #0x51b8]  ; [pp+0x51b8] Obj!AnimationStatus@12c6181
    // 0xb6cfdc: cmp             w0, w16
    // 0xb6cfe0: b.ne            #0xb6d02c
    // 0xb6cfe4: ldur            x16, [fp, #-0x20]
    // 0xb6cfe8: r30 = true
    //     0xb6cfe8: add             lr, NULL, #0x20  ; true
    // 0xb6cfec: stp             lr, x16, [SP]
    // 0xb6cff0: ldur            x0, [fp, #-0x20]
    // 0xb6cff4: ClosureCall
    //     0xb6cff4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb6cff8: ldur            x2, [x0, #0x1f]
    //     0xb6cffc: blr             x2
    // 0xb6d000: LoadField: r1 = r0->field_f
    //     0xb6d000: ldur            w1, [x0, #0xf]
    // 0xb6d004: DecompressPointer r1
    //     0xb6d004: add             x1, x1, HEAP, lsl #32
    // 0xb6d008: LoadField: r2 = r0->field_b
    //     0xb6d008: ldur            w2, [x0, #0xb]
    // 0xb6d00c: DecompressPointer r2
    //     0xb6d00c: add             x2, x2, HEAP, lsl #32
    // 0xb6d010: r0 = LoadClassIdInstr(r1)
    //     0xb6d010: ldur            x0, [x1, #-1]
    //     0xb6d014: ubfx            x0, x0, #0xc, #0x14
    // 0xb6d018: r0 = GDT[cid_x0 + 0x80ed]()
    //     0xb6d018: mov             x17, #0x80ed
    //     0xb6d01c: add             lr, x0, x17
    //     0xb6d020: ldr             lr, [x21, lr, lsl #3]
    //     0xb6d024: blr             lr
    // 0xb6d028: b               #0xb6d070
    // 0xb6d02c: ldur            x16, [fp, #-0x20]
    // 0xb6d030: r30 = false
    //     0xb6d030: add             lr, NULL, #0x30  ; false
    // 0xb6d034: stp             lr, x16, [SP]
    // 0xb6d038: ldur            x0, [fp, #-0x20]
    // 0xb6d03c: ClosureCall
    //     0xb6d03c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb6d040: ldur            x2, [x0, #0x1f]
    //     0xb6d044: blr             x2
    // 0xb6d048: LoadField: r1 = r0->field_f
    //     0xb6d048: ldur            w1, [x0, #0xf]
    // 0xb6d04c: DecompressPointer r1
    //     0xb6d04c: add             x1, x1, HEAP, lsl #32
    // 0xb6d050: LoadField: r2 = r0->field_b
    //     0xb6d050: ldur            w2, [x0, #0xb]
    // 0xb6d054: DecompressPointer r2
    //     0xb6d054: add             x2, x2, HEAP, lsl #32
    // 0xb6d058: r0 = LoadClassIdInstr(r1)
    //     0xb6d058: ldur            x0, [x1, #-1]
    //     0xb6d05c: ubfx            x0, x0, #0xc, #0x14
    // 0xb6d060: r0 = GDT[cid_x0 + 0x80ed]()
    //     0xb6d060: mov             x17, #0x80ed
    //     0xb6d064: add             lr, x0, x17
    //     0xb6d068: ldr             lr, [x21, lr, lsl #3]
    //     0xb6d06c: blr             lr
    // 0xb6d070: ldur            x1, [fp, #-8]
    // 0xb6d074: LoadField: r2 = r1->field_8f
    //     0xb6d074: ldur            w2, [x1, #0x8f]
    // 0xb6d078: DecompressPointer r2
    //     0xb6d078: add             x2, x2, HEAP, lsl #32
    // 0xb6d07c: cmp             w2, NULL
    // 0xb6d080: b.ne            #0xb6d090
    // 0xb6d084: d1 = 0.000000
    //     0xb6d084: eor             v1.16b, v1.16b, v1.16b
    // 0xb6d088: d0 = 2.000000
    //     0xb6d088: fmov            d0, #2.00000000
    // 0xb6d08c: b               #0xb6d0e0
    // 0xb6d090: ldur            x3, [fp, #-0x28]
    // 0xb6d094: d0 = 0.000000
    //     0xb6d094: eor             v0.16b, v0.16b, v0.16b
    // 0xb6d098: LoadField: d1 = r3->field_7
    //     0xb6d098: ldur            d1, [x3, #7]
    // 0xb6d09c: LoadField: d2 = r2->field_7
    //     0xb6d09c: ldur            d2, [x2, #7]
    // 0xb6d0a0: fsub            d3, d1, d2
    // 0xb6d0a4: fcmp            d3, d0
    // 0xb6d0a8: b.ne            #0xb6d0b4
    // 0xb6d0ac: d2 = 0.000000
    //     0xb6d0ac: eor             v2.16b, v2.16b, v2.16b
    // 0xb6d0b0: b               #0xb6d0cc
    // 0xb6d0b4: fcmp            d0, d3
    // 0xb6d0b8: b.le            #0xb6d0c4
    // 0xb6d0bc: fneg            d0, d3
    // 0xb6d0c0: b               #0xb6d0c8
    // 0xb6d0c4: mov             v0.16b, v3.16b
    // 0xb6d0c8: mov             v2.16b, v0.16b
    // 0xb6d0cc: d1 = 1.000000
    //     0xb6d0cc: fmov            d1, #1.00000000
    // 0xb6d0d0: d0 = 2.000000
    //     0xb6d0d0: fmov            d0, #2.00000000
    // 0xb6d0d4: fmul            d3, d2, d0
    // 0xb6d0d8: fsub            d2, d1, d3
    // 0xb6d0dc: mov             v1.16b, v2.16b
    // 0xb6d0e0: LoadField: d2 = r0->field_7
    //     0xb6d0e0: ldur            d2, [x0, #7]
    // 0xb6d0e4: fsub            d3, d2, d1
    // 0xb6d0e8: stur            d3, [fp, #-0x68]
    // 0xb6d0ec: LoadField: d2 = r0->field_f
    //     0xb6d0ec: ldur            d2, [x0, #0xf]
    // 0xb6d0f0: fsub            d4, d2, d1
    // 0xb6d0f4: stur            d4, [fp, #-0x60]
    // 0xb6d0f8: r0 = Size()
    //     0xb6d0f8: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb6d0fc: ldur            d0, [fp, #-0x68]
    // 0xb6d100: stur            x0, [fp, #-0x20]
    // 0xb6d104: StoreField: r0->field_7 = d0
    //     0xb6d104: stur            d0, [x0, #7]
    // 0xb6d108: ldur            d0, [fp, #-0x60]
    // 0xb6d10c: StoreField: r0->field_f = d0
    //     0xb6d10c: stur            d0, [x0, #0xf]
    // 0xb6d110: ldur            x2, [fp, #-8]
    // 0xb6d114: LoadField: r1 = r2->field_63
    //     0xb6d114: ldur            w1, [x2, #0x63]
    // 0xb6d118: DecompressPointer r1
    //     0xb6d118: add             x1, x1, HEAP, lsl #32
    // 0xb6d11c: cmp             w1, NULL
    // 0xb6d120: b.eq            #0xb6d4f4
    // 0xb6d124: r0 = value()
    //     0xb6d124: bl              #0xae5f84  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xb6d128: mov             x4, x0
    // 0xb6d12c: ldur            x0, [fp, #-8]
    // 0xb6d130: stur            x4, [fp, #-0x28]
    // 0xb6d134: LoadField: r1 = r0->field_c3
    //     0xb6d134: ldur            w1, [x0, #0xc3]
    // 0xb6d138: DecompressPointer r1
    //     0xb6d138: add             x1, x1, HEAP, lsl #32
    // 0xb6d13c: cmp             w1, NULL
    // 0xb6d140: b.eq            #0xb6d4f8
    // 0xb6d144: LoadField: r2 = r0->field_af
    //     0xb6d144: ldur            w2, [x0, #0xaf]
    // 0xb6d148: DecompressPointer r2
    //     0xb6d148: add             x2, x2, HEAP, lsl #32
    // 0xb6d14c: cmp             w2, NULL
    // 0xb6d150: b.eq            #0xb6d4fc
    // 0xb6d154: mov             x3, x4
    // 0xb6d158: r0 = lerp()
    //     0xb6d158: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0xb6d15c: mov             x4, x0
    // 0xb6d160: ldur            x0, [fp, #-8]
    // 0xb6d164: stur            x4, [fp, #-0x30]
    // 0xb6d168: LoadField: r1 = r0->field_b7
    //     0xb6d168: ldur            w1, [x0, #0xb7]
    // 0xb6d16c: DecompressPointer r1
    //     0xb6d16c: add             x1, x1, HEAP, lsl #32
    // 0xb6d170: cmp             w1, NULL
    // 0xb6d174: b.eq            #0xb6d188
    // 0xb6d178: LoadField: r2 = r0->field_b3
    //     0xb6d178: ldur            w2, [x0, #0xb3]
    // 0xb6d17c: DecompressPointer r2
    //     0xb6d17c: add             x2, x2, HEAP, lsl #32
    // 0xb6d180: cmp             w2, NULL
    // 0xb6d184: b.ne            #0xb6d190
    // 0xb6d188: r6 = Null
    //     0xb6d188: mov             x6, NULL
    // 0xb6d18c: b               #0xb6d1a0
    // 0xb6d190: ldur            x3, [fp, #-0x28]
    // 0xb6d194: r0 = lerp()
    //     0xb6d194: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0xb6d198: mov             x6, x0
    // 0xb6d19c: ldur            x0, [fp, #-8]
    // 0xb6d1a0: stur            x6, [fp, #-0x38]
    // 0xb6d1a4: LoadField: r1 = r0->field_bf
    //     0xb6d1a4: ldur            w1, [x0, #0xbf]
    // 0xb6d1a8: DecompressPointer r1
    //     0xb6d1a8: add             x1, x1, HEAP, lsl #32
    // 0xb6d1ac: LoadField: r2 = r0->field_bb
    //     0xb6d1ac: ldur            w2, [x0, #0xbb]
    // 0xb6d1b0: DecompressPointer r2
    //     0xb6d1b0: add             x2, x2, HEAP, lsl #32
    // 0xb6d1b4: ldur            x3, [fp, #-0x28]
    // 0xb6d1b8: r0 = lerpDouble()
    //     0xb6d1b8: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xb6d1bc: mov             x2, x0
    // 0xb6d1c0: ldur            x0, [fp, #-8]
    // 0xb6d1c4: stur            x2, [fp, #-0x40]
    // 0xb6d1c8: LoadField: r1 = r0->field_27
    //     0xb6d1c8: ldur            w1, [x0, #0x27]
    // 0xb6d1cc: DecompressPointer r1
    //     0xb6d1cc: add             x1, x1, HEAP, lsl #32
    // 0xb6d1d0: cmp             w1, NULL
    // 0xb6d1d4: b.eq            #0xb6d500
    // 0xb6d1d8: r0 = status()
    //     0xb6d1d8: bl              #0x1284c0c  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::status
    // 0xb6d1dc: r16 = Instance_AnimationStatus
    //     0xb6d1dc: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xb6d1e0: cmp             w0, w16
    // 0xb6d1e4: b.eq            #0xb6d21c
    // 0xb6d1e8: ldur            x0, [fp, #-8]
    // 0xb6d1ec: LoadField: r1 = r0->field_7f
    //     0xb6d1ec: ldur            w1, [x0, #0x7f]
    // 0xb6d1f0: DecompressPointer r1
    //     0xb6d1f0: add             x1, x1, HEAP, lsl #32
    // 0xb6d1f4: cmp             w1, NULL
    // 0xb6d1f8: b.eq            #0xb6d504
    // 0xb6d1fc: LoadField: r2 = r0->field_7b
    //     0xb6d1fc: ldur            w2, [x0, #0x7b]
    // 0xb6d200: DecompressPointer r2
    //     0xb6d200: add             x2, x2, HEAP, lsl #32
    // 0xb6d204: cmp             w2, NULL
    // 0xb6d208: b.eq            #0xb6d508
    // 0xb6d20c: ldur            x3, [fp, #-0x28]
    // 0xb6d210: r0 = lerp()
    //     0xb6d210: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0xb6d214: mov             x1, x0
    // 0xb6d218: b               #0xb6d2e8
    // 0xb6d21c: ldur            x0, [fp, #-8]
    // 0xb6d220: LoadField: r1 = r0->field_5f
    //     0xb6d220: ldur            w1, [x0, #0x5f]
    // 0xb6d224: DecompressPointer r1
    //     0xb6d224: add             x1, x1, HEAP, lsl #32
    // 0xb6d228: cmp             w1, NULL
    // 0xb6d22c: b.eq            #0xb6d50c
    // 0xb6d230: LoadField: r2 = r1->field_43
    //     0xb6d230: ldur            w2, [x1, #0x43]
    // 0xb6d234: DecompressPointer r2
    //     0xb6d234: add             x2, x2, HEAP, lsl #32
    // 0xb6d238: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb6d23c: cmp             w2, w16
    // 0xb6d240: b.eq            #0xb6d510
    // 0xb6d244: r16 = Instance_AnimationStatus
    //     0xb6d244: ldr             x16, [PP, #0x51b8]  ; [pp+0x51b8] Obj!AnimationStatus@12c6181
    // 0xb6d248: cmp             w2, w16
    // 0xb6d24c: b.ne            #0xb6d27c
    // 0xb6d250: LoadField: r1 = r0->field_7f
    //     0xb6d250: ldur            w1, [x0, #0x7f]
    // 0xb6d254: DecompressPointer r1
    //     0xb6d254: add             x1, x1, HEAP, lsl #32
    // 0xb6d258: cmp             w1, NULL
    // 0xb6d25c: b.eq            #0xb6d518
    // 0xb6d260: LoadField: r2 = r0->field_33
    //     0xb6d260: ldur            w2, [x0, #0x33]
    // 0xb6d264: DecompressPointer r2
    //     0xb6d264: add             x2, x2, HEAP, lsl #32
    // 0xb6d268: cmp             w2, NULL
    // 0xb6d26c: b.eq            #0xb6d51c
    // 0xb6d270: ldur            x3, [fp, #-0x28]
    // 0xb6d274: r0 = lerp()
    //     0xb6d274: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0xb6d278: b               #0xb6d2e4
    // 0xb6d27c: r16 = Instance_AnimationStatus
    //     0xb6d27c: ldr             x16, [PP, #0x51c0]  ; [pp+0x51c0] Obj!AnimationStatus@12c6161
    // 0xb6d280: cmp             w2, w16
    // 0xb6d284: b.ne            #0xb6d2b8
    // 0xb6d288: ldur            x0, [fp, #-8]
    // 0xb6d28c: LoadField: r1 = r0->field_37
    //     0xb6d28c: ldur            w1, [x0, #0x37]
    // 0xb6d290: DecompressPointer r1
    //     0xb6d290: add             x1, x1, HEAP, lsl #32
    // 0xb6d294: cmp             w1, NULL
    // 0xb6d298: b.eq            #0xb6d520
    // 0xb6d29c: LoadField: r2 = r0->field_7b
    //     0xb6d29c: ldur            w2, [x0, #0x7b]
    // 0xb6d2a0: DecompressPointer r2
    //     0xb6d2a0: add             x2, x2, HEAP, lsl #32
    // 0xb6d2a4: cmp             w2, NULL
    // 0xb6d2a8: b.eq            #0xb6d524
    // 0xb6d2ac: ldur            x3, [fp, #-0x28]
    // 0xb6d2b0: r0 = lerp()
    //     0xb6d2b0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0xb6d2b4: b               #0xb6d2e4
    // 0xb6d2b8: ldur            x0, [fp, #-8]
    // 0xb6d2bc: LoadField: r1 = r0->field_37
    //     0xb6d2bc: ldur            w1, [x0, #0x37]
    // 0xb6d2c0: DecompressPointer r1
    //     0xb6d2c0: add             x1, x1, HEAP, lsl #32
    // 0xb6d2c4: cmp             w1, NULL
    // 0xb6d2c8: b.eq            #0xb6d528
    // 0xb6d2cc: LoadField: r2 = r0->field_33
    //     0xb6d2cc: ldur            w2, [x0, #0x33]
    // 0xb6d2d0: DecompressPointer r2
    //     0xb6d2d0: add             x2, x2, HEAP, lsl #32
    // 0xb6d2d4: cmp             w2, NULL
    // 0xb6d2d8: b.eq            #0xb6d52c
    // 0xb6d2dc: ldur            x3, [fp, #-0x28]
    // 0xb6d2e0: r0 = lerp()
    //     0xb6d2e0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0xb6d2e4: mov             x1, x0
    // 0xb6d2e8: ldur            x0, [fp, #-8]
    // 0xb6d2ec: ldur            x3, [fp, #-0x18]
    // 0xb6d2f0: ldur            d0, [fp, #-0x60]
    // 0xb6d2f4: LoadField: r2 = r0->field_cf
    //     0xb6d2f4: ldur            w2, [x0, #0xcf]
    // 0xb6d2f8: DecompressPointer r2
    //     0xb6d2f8: add             x2, x2, HEAP, lsl #32
    // 0xb6d2fc: cmp             w2, NULL
    // 0xb6d300: b.eq            #0xb6d530
    // 0xb6d304: r0 = alphaBlend()
    //     0xb6d304: bl              #0xb6ea90  ; [dart:ui] Color::alphaBlend
    // 0xb6d308: stur            x0, [fp, #-0x28]
    // 0xb6d30c: r16 = 136
    //     0xb6d30c: mov             x16, #0x88
    // 0xb6d310: stp             x16, NULL, [SP]
    // 0xb6d314: r0 = ByteData()
    //     0xb6d314: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb6d318: stur            x0, [fp, #-0x48]
    // 0xb6d31c: r0 = Paint()
    //     0xb6d31c: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb6d320: mov             x3, x0
    // 0xb6d324: ldur            x0, [fp, #-0x48]
    // 0xb6d328: stur            x3, [fp, #-0x50]
    // 0xb6d32c: StoreField: r3->field_7 = r0
    //     0xb6d32c: stur            w0, [x3, #7]
    // 0xb6d330: mov             x1, x3
    // 0xb6d334: ldur            x2, [fp, #-0x30]
    // 0xb6d338: r0 = color=()
    //     0xb6d338: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb6d33c: ldur            x0, [fp, #-8]
    // 0xb6d340: LoadField: r1 = r0->field_9b
    //     0xb6d340: ldur            w1, [x0, #0x9b]
    // 0xb6d344: DecompressPointer r1
    //     0xb6d344: add             x1, x1, HEAP, lsl #32
    // 0xb6d348: cmp             w1, NULL
    // 0xb6d34c: b.eq            #0xb6d534
    // 0xb6d350: LoadField: r2 = r0->field_97
    //     0xb6d350: ldur            w2, [x0, #0x97]
    // 0xb6d354: DecompressPointer r2
    //     0xb6d354: add             x2, x2, HEAP, lsl #32
    // 0xb6d358: cmp             w2, NULL
    // 0xb6d35c: b.eq            #0xb6d538
    // 0xb6d360: LoadField: d0 = r1->field_7
    //     0xb6d360: ldur            d0, [x1, #7]
    // 0xb6d364: LoadField: d1 = r2->field_7
    //     0xb6d364: ldur            d1, [x2, #7]
    // 0xb6d368: mov             x1, x0
    // 0xb6d36c: ldur            x2, [fp, #-0x18]
    // 0xb6d370: r0 = _computeTrackPaintOffset()
    //     0xb6d370: bl              #0xb6ea40  ; [package:flutter/src/material/switch.dart] _SwitchPainter::_computeTrackPaintOffset
    // 0xb6d374: ldur            x1, [fp, #-8]
    // 0xb6d378: mov             x2, x0
    // 0xb6d37c: ldur            x3, [fp, #-0x20]
    // 0xb6d380: ldur            d0, [fp, #-0x58]
    // 0xb6d384: stur            x0, [fp, #-0x30]
    // 0xb6d388: r0 = _computeThumbPaintOffset()
    //     0xb6d388: bl              #0xb6e970  ; [package:flutter/src/material/switch.dart] _SwitchPainter::_computeThumbPaintOffset
    // 0xb6d38c: stur            x0, [fp, #-0x48]
    // 0xb6d390: LoadField: d0 = r0->field_7
    //     0xb6d390: ldur            d0, [x0, #7]
    // 0xb6d394: ldur            d1, [fp, #-0x60]
    // 0xb6d398: d2 = 2.000000
    //     0xb6d398: fmov            d2, #2.00000000
    // 0xb6d39c: fdiv            d3, d1, d2
    // 0xb6d3a0: fadd            d1, d0, d3
    // 0xb6d3a4: ldur            x1, [fp, #-0x18]
    // 0xb6d3a8: stur            d1, [fp, #-0x60]
    // 0xb6d3ac: LoadField: d0 = r1->field_f
    //     0xb6d3ac: ldur            d0, [x1, #0xf]
    // 0xb6d3b0: fdiv            d3, d0, d2
    // 0xb6d3b4: stur            d3, [fp, #-0x58]
    // 0xb6d3b8: r0 = Offset()
    //     0xb6d3b8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb6d3bc: ldur            d0, [fp, #-0x60]
    // 0xb6d3c0: stur            x0, [fp, #-0x18]
    // 0xb6d3c4: StoreField: r0->field_7 = d0
    //     0xb6d3c4: stur            d0, [x0, #7]
    // 0xb6d3c8: ldur            d0, [fp, #-0x58]
    // 0xb6d3cc: StoreField: r0->field_f = d0
    //     0xb6d3cc: stur            d0, [x0, #0xf]
    // 0xb6d3d0: ldur            x1, [fp, #-8]
    // 0xb6d3d4: ldur            x2, [fp, #-0x10]
    // 0xb6d3d8: ldur            x3, [fp, #-0x50]
    // 0xb6d3dc: ldur            x5, [fp, #-0x30]
    // 0xb6d3e0: ldur            x6, [fp, #-0x38]
    // 0xb6d3e4: ldur            x7, [fp, #-0x40]
    // 0xb6d3e8: r0 = _paintTrackWith()
    //     0xb6d3e8: bl              #0xb6e308  ; [package:flutter/src/material/switch.dart] _SwitchPainter::_paintTrackWith
    // 0xb6d3ec: ldur            x1, [fp, #-8]
    // 0xb6d3f0: ldur            x2, [fp, #-0x10]
    // 0xb6d3f4: ldur            x3, [fp, #-0x18]
    // 0xb6d3f8: r0 = paintRadialReaction()
    //     0xb6d3f8: bl              #0xb6c1b8  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::paintRadialReaction
    // 0xb6d3fc: ldur            x1, [fp, #-8]
    // 0xb6d400: ldur            x2, [fp, #-0x48]
    // 0xb6d404: ldur            x3, [fp, #-0x10]
    // 0xb6d408: ldur            x5, [fp, #-0x28]
    // 0xb6d40c: ldur            x6, [fp, #-0x20]
    // 0xb6d410: r0 = _paintThumbWith()
    //     0xb6d410: bl              #0xb6d53c  ; [package:flutter/src/material/switch.dart] _SwitchPainter::_paintThumbWith
    // 0xb6d414: r0 = Null
    //     0xb6d414: mov             x0, NULL
    // 0xb6d418: LeaveFrame
    //     0xb6d418: mov             SP, fp
    //     0xb6d41c: ldp             fp, lr, [SP], #0x10
    // 0xb6d420: ret
    //     0xb6d420: ret             
    // 0xb6d424: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6d424: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6d428: b               #0xb6c844
    // 0xb6d42c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d42c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d430: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d430: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d434: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6d434: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6d438: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d438: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d43c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d43c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d440: SaveReg d0
    //     0xb6d440: str             q0, [SP, #-0x10]!
    // 0xb6d444: SaveReg r2
    //     0xb6d444: str             x2, [SP, #-8]!
    // 0xb6d448: r0 = AllocateDouble()
    //     0xb6d448: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb6d44c: RestoreReg r2
    //     0xb6d44c: ldr             x2, [SP], #8
    // 0xb6d450: RestoreReg d0
    //     0xb6d450: ldr             q0, [SP], #0x10
    // 0xb6d454: b               #0xb6c978
    // 0xb6d458: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d458: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d45c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d45c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d460: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d460: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d464: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d464: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d468: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d468: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d46c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d46c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d470: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d470: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d474: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6d474: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6d478: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6d478: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6d47c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6d47c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6d480: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d480: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d484: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6d484: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6d488: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6d488: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6d48c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6d48c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6d490: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d490: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d494: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d494: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d498: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6d498: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6d49c: r9 = _pressedThumbExtension
    //     0xb6d49c: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3550] Field <_SwitchPainter@127328938._pressedThumbExtension@127328938>: late (offset: 0x108)
    //     0xb6d4a0: ldr             x9, [x9, #0x550]
    // 0xb6d4a4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xb6d4a4: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xb6d4a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d4a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d4ac: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6d4ac: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6d4b0: r9 = _pressedThumbExtension
    //     0xb6d4b0: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3550] Field <_SwitchPainter@127328938._pressedThumbExtension@127328938>: late (offset: 0x108)
    //     0xb6d4b4: ldr             x9, [x9, #0x550]
    // 0xb6d4b8: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xb6d4b8: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xb6d4bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d4bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d4c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d4c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d4c4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6d4c4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6d4c8: r9 = _pressedThumbExtension
    //     0xb6d4c8: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3550] Field <_SwitchPainter@127328938._pressedThumbExtension@127328938>: late (offset: 0x108)
    //     0xb6d4cc: ldr             x9, [x9, #0x550]
    // 0xb6d4d0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xb6d4d0: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xb6d4d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d4d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d4d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d4d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d4dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d4dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d4e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d4e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d4e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d4e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d4e8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6d4e8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6d4ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d4ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d4f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d4f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d4f4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6d4f4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6d4f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d4f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d4fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d4fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d500: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d500: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d504: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d504: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d508: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d508: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d50c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d50c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d510: r9 = _status
    //     0xb6d510: ldr             x9, [PP, #0x51e8]  ; [pp+0x51e8] Field <AnimationController._status@62066280>: late (offset: 0x44)
    // 0xb6d514: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb6d514: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xb6d518: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d518: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d51c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d51c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d520: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d520: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d524: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d524: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d528: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d528: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d52c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d52c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d530: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6d530: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6d534: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d534: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d538: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d538: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _paintThumbWith(/* No info */) {
    // ** addr: 0xb6d53c, size: 0x1ec
    // 0xb6d53c: EnterFrame
    //     0xb6d53c: stp             fp, lr, [SP, #-0x10]!
    //     0xb6d540: mov             fp, SP
    // 0xb6d544: AllocStack(0x90)
    //     0xb6d544: sub             SP, SP, #0x90
    // 0xb6d548: SetupParameters(_SwitchPainter this /* r1 => r4, fp-0x58 */, dynamic _ /* r2 => r3, fp-0x70 */, dynamic _ /* r3 => r5, fp-0x78 */)
    //     0xb6d548: mov             x4, x1
    //     0xb6d54c: stur            x2, [fp, #-0x60]
    //     0xb6d550: mov             x16, x3
    //     0xb6d554: mov             x3, x2
    //     0xb6d558: mov             x2, x16
    //     0xb6d55c: stur            x1, [fp, #-0x58]
    //     0xb6d560: mov             x1, x5
    //     0xb6d564: stur            x5, [fp, #-0x70]
    //     0xb6d568: mov             x5, x6
    //     0xb6d56c: stur            x2, [fp, #-0x68]
    //     0xb6d570: stur            x6, [fp, #-0x78]
    // 0xb6d574: CheckStackOverflow
    //     0xb6d574: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6d578: cmp             SP, x16
    //     0xb6d57c: b.ls            #0xb6d714
    // 0xb6d580: r0 = true
    //     0xb6d580: add             x0, NULL, #0x20  ; true
    // 0xb6d584: StoreField: r4->field_f7 = r0
    //     0xb6d584: stur            w0, [x4, #0xf7]
    // 0xb6d588: LoadField: r0 = r4->field_f3
    //     0xb6d588: ldur            w0, [x4, #0xf3]
    // 0xb6d58c: DecompressPointer r0
    //     0xb6d58c: add             x0, x0, HEAP, lsl #32
    // 0xb6d590: cmp             w0, NULL
    // 0xb6d594: b.ne            #0xb6d5a0
    // 0xb6d598: mov             x2, x4
    // 0xb6d59c: b               #0xb6d5cc
    // 0xb6d5a0: LoadField: r0 = r4->field_e7
    //     0xb6d5a0: ldur            w0, [x4, #0xe7]
    // 0xb6d5a4: DecompressPointer r0
    //     0xb6d5a4: add             x0, x0, HEAP, lsl #32
    // 0xb6d5a8: r6 = LoadClassIdInstr(r1)
    //     0xb6d5a8: ldur            x6, [x1, #-1]
    //     0xb6d5ac: ubfx            x6, x6, #0xc, #0x14
    // 0xb6d5b0: stp             x0, x1, [SP]
    // 0xb6d5b4: mov             x0, x6
    // 0xb6d5b8: mov             lr, x0
    // 0xb6d5bc: ldr             lr, [x21, lr, lsl #3]
    // 0xb6d5c0: blr             lr
    // 0xb6d5c4: tbz             w0, #4, #0xb6d670
    // 0xb6d5c8: ldur            x2, [fp, #-0x58]
    // 0xb6d5cc: ldur            x0, [fp, #-0x70]
    // 0xb6d5d0: StoreField: r2->field_e7 = r0
    //     0xb6d5d0: stur            w0, [x2, #0xe7]
    //     0xb6d5d4: ldurb           w16, [x2, #-1]
    //     0xb6d5d8: ldurb           w17, [x0, #-1]
    //     0xb6d5dc: and             x16, x17, x16, lsr #2
    //     0xb6d5e0: tst             x16, HEAP, lsr #32
    //     0xb6d5e4: b.eq            #0xb6d5ec
    //     0xb6d5e8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb6d5ec: StoreField: r2->field_eb = rNULL
    //     0xb6d5ec: stur            NULL, [x2, #0xeb]
    // 0xb6d5f0: StoreField: r2->field_ef = rNULL
    //     0xb6d5f0: stur            NULL, [x2, #0xef]
    // 0xb6d5f4: LoadField: r0 = r2->field_f3
    //     0xb6d5f4: ldur            w0, [x2, #0xf3]
    // 0xb6d5f8: DecompressPointer r0
    //     0xb6d5f8: add             x0, x0, HEAP, lsl #32
    // 0xb6d5fc: stur            x0, [fp, #-0x80]
    // 0xb6d600: cmp             w0, NULL
    // 0xb6d604: b.ne            #0xb6d610
    // 0xb6d608: mov             x0, x2
    // 0xb6d60c: b               #0xb6d61c
    // 0xb6d610: mov             x1, x0
    // 0xb6d614: r0 = dispose()
    //     0xb6d614: bl              #0x12f9694  ; [package:flutter/src/painting/shape_decoration.dart] _ShapeDecorationPainter::dispose
    // 0xb6d618: ldur            x0, [fp, #-0x58]
    // 0xb6d61c: mov             x1, x0
    // 0xb6d620: ldur            x2, [fp, #-0x70]
    // 0xb6d624: r0 = _createDefaultThumbDecoration()
    //     0xb6d624: bl              #0xb6e220  ; [package:flutter/src/material/switch.dart] _SwitchPainter::_createDefaultThumbDecoration
    // 0xb6d628: ldur            x2, [fp, #-0x58]
    // 0xb6d62c: r1 = Function '_handleDecorationChanged@127328938':.
    //     0xb6d62c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3570] AnonymousClosure: (0xb6e294), in [package:flutter/src/material/switch.dart] _SwitchPainter::_handleDecorationChanged (0xb6e2cc)
    //     0xb6d630: ldr             x1, [x1, #0x570]
    // 0xb6d634: stur            x0, [fp, #-0x80]
    // 0xb6d638: r0 = AllocateClosure()
    //     0xb6d638: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb6d63c: str             x0, [SP]
    // 0xb6d640: ldur            x1, [fp, #-0x80]
    // 0xb6d644: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xb6d644: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xb6d648: r0 = createBoxPainter()
    //     0xb6d648: bl              #0x1255018  ; [package:flutter/src/painting/shape_decoration.dart] ShapeDecoration::createBoxPainter
    // 0xb6d64c: ldur            x4, [fp, #-0x58]
    // 0xb6d650: StoreField: r4->field_f3 = r0
    //     0xb6d650: stur            w0, [x4, #0xf3]
    //     0xb6d654: ldurb           w16, [x4, #-1]
    //     0xb6d658: ldurb           w17, [x0, #-1]
    //     0xb6d65c: and             x16, x17, x16, lsr #2
    //     0xb6d660: tst             x16, HEAP, lsr #32
    //     0xb6d664: b.eq            #0xb6d66c
    //     0xb6d668: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xb6d66c: b               #0xb6d674
    // 0xb6d670: ldur            x4, [fp, #-0x58]
    // 0xb6d674: LoadField: r0 = r4->field_f3
    //     0xb6d674: ldur            w0, [x4, #0xf3]
    // 0xb6d678: DecompressPointer r0
    //     0xb6d678: add             x0, x0, HEAP, lsl #32
    // 0xb6d67c: stur            x0, [fp, #-0x70]
    // 0xb6d680: cmp             w0, NULL
    // 0xb6d684: b.eq            #0xb6d71c
    // 0xb6d688: LoadField: r1 = r4->field_db
    //     0xb6d688: ldur            w1, [x4, #0xdb]
    // 0xb6d68c: DecompressPointer r1
    //     0xb6d68c: add             x1, x1, HEAP, lsl #32
    // 0xb6d690: cmp             w1, NULL
    // 0xb6d694: b.eq            #0xb6d720
    // 0xb6d698: tbnz            w1, #4, #0xb6d6b0
    // 0xb6d69c: mov             x1, x4
    // 0xb6d6a0: ldur            x2, [fp, #-0x68]
    // 0xb6d6a4: ldur            x3, [fp, #-0x60]
    // 0xb6d6a8: ldur            x5, [fp, #-0x78]
    // 0xb6d6ac: r0 = _paintCupertinoThumbShadowAndBorder()
    //     0xb6d6ac: bl              #0xb6d7c0  ; [package:flutter/src/material/switch.dart] _SwitchPainter::_paintCupertinoThumbShadowAndBorder
    // 0xb6d6b0: ldur            x0, [fp, #-0x58]
    // 0xb6d6b4: LoadField: r1 = r0->field_c7
    //     0xb6d6b4: ldur            w1, [x0, #0xc7]
    // 0xb6d6b8: DecompressPointer r1
    //     0xb6d6b8: add             x1, x1, HEAP, lsl #32
    // 0xb6d6bc: cmp             w1, NULL
    // 0xb6d6c0: b.eq            #0xb6d724
    // 0xb6d6c4: ldur            x2, [fp, #-0x78]
    // 0xb6d6c8: r0 = copyWith()
    //     0xb6d6c8: bl              #0xb6d728  ; [package:flutter/src/painting/image_provider.dart] ImageConfiguration::copyWith
    // 0xb6d6cc: ldur            x1, [fp, #-0x70]
    // 0xb6d6d0: ldur            x2, [fp, #-0x68]
    // 0xb6d6d4: ldur            x3, [fp, #-0x60]
    // 0xb6d6d8: mov             x5, x0
    // 0xb6d6dc: r0 = paint()
    //     0xb6d6dc: bl              #0x12f81c4  ; [package:flutter/src/painting/shape_decoration.dart] _ShapeDecorationPainter::paint
    // 0xb6d6e0: ldur            x2, [fp, #-0x58]
    // 0xb6d6e4: r3 = false
    //     0xb6d6e4: add             x3, NULL, #0x30  ; false
    // 0xb6d6e8: StoreField: r2->field_f7 = r3
    //     0xb6d6e8: stur            w3, [x2, #0xf7]
    // 0xb6d6ec: r0 = Null
    //     0xb6d6ec: mov             x0, NULL
    // 0xb6d6f0: LeaveFrame
    //     0xb6d6f0: mov             SP, fp
    //     0xb6d6f4: ldp             fp, lr, [SP], #0x10
    // 0xb6d6f8: ret
    //     0xb6d6f8: ret             
    // 0xb6d6fc: sub             SP, fp, #0x90
    // 0xb6d700: ldur            x2, [fp, #-0x58]
    // 0xb6d704: r3 = false
    //     0xb6d704: add             x3, NULL, #0x30  ; false
    // 0xb6d708: StoreField: r2->field_f7 = r3
    //     0xb6d708: stur            w3, [x2, #0xf7]
    // 0xb6d70c: r0 = ReThrow()
    //     0xb6d70c: bl              #0x13ddb00  ; ReThrowStub
    // 0xb6d710: brk             #0
    // 0xb6d714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6d714: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6d718: b               #0xb6d580
    // 0xb6d71c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d71c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d720: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d720: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6d724: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6d724: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _paintCupertinoThumbShadowAndBorder(/* No info */) {
    // ** addr: 0xb6d7c0, size: 0x264
    // 0xb6d7c0: EnterFrame
    //     0xb6d7c0: stp             fp, lr, [SP, #-0x10]!
    //     0xb6d7c4: mov             fp, SP
    // 0xb6d7c8: AllocStack(0x70)
    //     0xb6d7c8: sub             SP, SP, #0x70
    // 0xb6d7cc: d0 = 2.000000
    //     0xb6d7cc: fmov            d0, #2.00000000
    // 0xb6d7d0: mov             x0, x1
    // 0xb6d7d4: stur            x1, [fp, #-8]
    // 0xb6d7d8: mov             x1, x2
    // 0xb6d7dc: stur            x2, [fp, #-0x10]
    // 0xb6d7e0: CheckStackOverflow
    //     0xb6d7e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6d7e4: cmp             SP, x16
    //     0xb6d7e8: b.ls            #0xb6da14
    // 0xb6d7ec: LoadField: d1 = r3->field_7
    //     0xb6d7ec: ldur            d1, [x3, #7]
    // 0xb6d7f0: stur            d1, [fp, #-0x60]
    // 0xb6d7f4: LoadField: d2 = r3->field_f
    //     0xb6d7f4: ldur            d2, [x3, #0xf]
    // 0xb6d7f8: stur            d2, [fp, #-0x58]
    // 0xb6d7fc: LoadField: d3 = r5->field_7
    //     0xb6d7fc: ldur            d3, [x5, #7]
    // 0xb6d800: fadd            d4, d1, d3
    // 0xb6d804: stur            d4, [fp, #-0x50]
    // 0xb6d808: LoadField: d3 = r5->field_f
    //     0xb6d808: ldur            d3, [x5, #0xf]
    // 0xb6d80c: fadd            d5, d2, d3
    // 0xb6d810: stur            d5, [fp, #-0x48]
    // 0xb6d814: fdiv            d6, d3, d0
    // 0xb6d818: stur            d6, [fp, #-0x40]
    // 0xb6d81c: r0 = Radius()
    //     0xb6d81c: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xb6d820: ldur            d0, [fp, #-0x40]
    // 0xb6d824: stur            x0, [fp, #-0x18]
    // 0xb6d828: StoreField: r0->field_7 = d0
    //     0xb6d828: stur            d0, [x0, #7]
    // 0xb6d82c: StoreField: r0->field_f = d0
    //     0xb6d82c: stur            d0, [x0, #0xf]
    // 0xb6d830: r1 = <RRect>
    //     0xb6d830: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0xb6d834: ldr             x1, [x1, #0x108]
    // 0xb6d838: r0 = RRect()
    //     0xb6d838: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0xb6d83c: mov             x1, x0
    // 0xb6d840: ldur            d0, [fp, #-0x60]
    // 0xb6d844: ldur            d1, [fp, #-0x58]
    // 0xb6d848: ldur            d2, [fp, #-0x50]
    // 0xb6d84c: ldur            d3, [fp, #-0x48]
    // 0xb6d850: ldur            x2, [fp, #-0x18]
    // 0xb6d854: stur            x0, [fp, #-0x18]
    // 0xb6d858: r0 = RRect.fromLTRBR()
    //     0xb6d858: bl              #0xb6e1d4  ; [dart:ui] RRect::RRect.fromLTRBR
    // 0xb6d85c: ldur            x0, [fp, #-8]
    // 0xb6d860: LoadField: r1 = r0->field_df
    //     0xb6d860: ldur            w1, [x0, #0xdf]
    // 0xb6d864: DecompressPointer r1
    //     0xb6d864: add             x1, x1, HEAP, lsl #32
    // 0xb6d868: cmp             w1, NULL
    // 0xb6d86c: b.eq            #0xb6d9b0
    // 0xb6d870: r0 = LoadClassIdInstr(r1)
    //     0xb6d870: ldur            x0, [x1, #-1]
    //     0xb6d874: ubfx            x0, x0, #0xc, #0x14
    // 0xb6d878: r0 = GDT[cid_x0 + 0x12641]()
    //     0xb6d878: mov             x17, #0x2641
    //     0xb6d87c: movk            x17, #1, lsl #16
    //     0xb6d880: add             lr, x0, x17
    //     0xb6d884: ldr             lr, [x21, lr, lsl #3]
    //     0xb6d888: blr             lr
    // 0xb6d88c: mov             x2, x0
    // 0xb6d890: stur            x2, [fp, #-8]
    // 0xb6d894: CheckStackOverflow
    //     0xb6d894: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6d898: cmp             SP, x16
    //     0xb6d89c: b.ls            #0xb6da1c
    // 0xb6d8a0: r0 = LoadClassIdInstr(r2)
    //     0xb6d8a0: ldur            x0, [x2, #-1]
    //     0xb6d8a4: ubfx            x0, x0, #0xc, #0x14
    // 0xb6d8a8: mov             x1, x2
    // 0xb6d8ac: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xb6d8ac: mov             x17, #0x845b
    //     0xb6d8b0: movk            x17, #1, lsl #16
    //     0xb6d8b4: add             lr, x0, x17
    //     0xb6d8b8: ldr             lr, [x21, lr, lsl #3]
    //     0xb6d8bc: blr             lr
    // 0xb6d8c0: tbnz            w0, #4, #0xb6d9b0
    // 0xb6d8c4: ldur            x2, [fp, #-8]
    // 0xb6d8c8: r0 = LoadClassIdInstr(r2)
    //     0xb6d8c8: ldur            x0, [x2, #-1]
    //     0xb6d8cc: ubfx            x0, x0, #0xc, #0x14
    // 0xb6d8d0: mov             x1, x2
    // 0xb6d8d4: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xb6d8d4: mov             x17, #0x7d4c
    //     0xb6d8d8: movk            x17, #1, lsl #16
    //     0xb6d8dc: add             lr, x0, x17
    //     0xb6d8e0: ldr             lr, [x21, lr, lsl #3]
    //     0xb6d8e4: blr             lr
    // 0xb6d8e8: stur            x0, [fp, #-0x20]
    // 0xb6d8ec: LoadField: r2 = r0->field_b
    //     0xb6d8ec: ldur            w2, [x0, #0xb]
    // 0xb6d8f0: DecompressPointer r2
    //     0xb6d8f0: add             x2, x2, HEAP, lsl #32
    // 0xb6d8f4: ldur            x1, [fp, #-0x18]
    // 0xb6d8f8: r0 = shift()
    //     0xb6d8f8: bl              #0xb6e004  ; [dart:ui] _RRectLike::shift
    // 0xb6d8fc: stur            x0, [fp, #-0x28]
    // 0xb6d900: r16 = 136
    //     0xb6d900: mov             x16, #0x88
    // 0xb6d904: stp             x16, NULL, [SP]
    // 0xb6d908: r0 = ByteData()
    //     0xb6d908: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb6d90c: stur            x0, [fp, #-0x30]
    // 0xb6d910: r0 = Paint()
    //     0xb6d910: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb6d914: mov             x3, x0
    // 0xb6d918: ldur            x0, [fp, #-0x30]
    // 0xb6d91c: stur            x3, [fp, #-0x38]
    // 0xb6d920: StoreField: r3->field_7 = r0
    //     0xb6d920: stur            w0, [x3, #7]
    // 0xb6d924: ldur            x4, [fp, #-0x20]
    // 0xb6d928: LoadField: r2 = r4->field_7
    //     0xb6d928: ldur            w2, [x4, #7]
    // 0xb6d92c: DecompressPointer r2
    //     0xb6d92c: add             x2, x2, HEAP, lsl #32
    // 0xb6d930: mov             x1, x3
    // 0xb6d934: r0 = color=()
    //     0xb6d934: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb6d938: ldur            x0, [fp, #-0x20]
    // 0xb6d93c: LoadField: d0 = r0->field_f
    //     0xb6d93c: ldur            d0, [x0, #0xf]
    // 0xb6d940: d1 = 0.000000
    //     0xb6d940: eor             v1.16b, v1.16b, v1.16b
    // 0xb6d944: fcmp            d0, d1
    // 0xb6d948: b.le            #0xb6d960
    // 0xb6d94c: d3 = 0.577350
    //     0xb6d94c: ldr             d3, [PP, #0x4a48]  ; [pp+0x4a48] IMM: double(0.57735) from 0x3fe279a6b50b0f28
    // 0xb6d950: d2 = 0.500000
    //     0xb6d950: fmov            d2, #0.50000000
    // 0xb6d954: fmul            d4, d0, d3
    // 0xb6d958: fadd            d0, d4, d2
    // 0xb6d95c: b               #0xb6d96c
    // 0xb6d960: d3 = 0.577350
    //     0xb6d960: ldr             d3, [PP, #0x4a48]  ; [pp+0x4a48] IMM: double(0.57735) from 0x3fe279a6b50b0f28
    // 0xb6d964: d2 = 0.500000
    //     0xb6d964: fmov            d2, #0.50000000
    // 0xb6d968: d0 = 0.000000
    //     0xb6d968: eor             v0.16b, v0.16b, v0.16b
    // 0xb6d96c: ldur            x0, [fp, #-0x30]
    // 0xb6d970: r4 = 1
    //     0xb6d970: mov             x4, #1
    // 0xb6d974: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb6d974: ldur            w1, [x0, #0x17]
    // 0xb6d978: DecompressPointer r1
    //     0xb6d978: add             x1, x1, HEAP, lsl #32
    // 0xb6d97c: LoadField: r0 = r1->field_7
    //     0xb6d97c: ldur            x0, [x1, #7]
    // 0xb6d980: str             w4, [x0, #0x34]
    // 0xb6d984: LoadField: r0 = r1->field_7
    //     0xb6d984: ldur            x0, [x1, #7]
    // 0xb6d988: str             wzr, [x0, #0x38]
    // 0xb6d98c: fcvt            s4, d0
    // 0xb6d990: LoadField: r0 = r1->field_7
    //     0xb6d990: ldur            x0, [x1, #7]
    // 0xb6d994: str             s4, [x0, #0x3c]
    // 0xb6d998: ldur            x1, [fp, #-0x10]
    // 0xb6d99c: ldur            x2, [fp, #-0x28]
    // 0xb6d9a0: ldur            x3, [fp, #-0x38]
    // 0xb6d9a4: r0 = drawRRect()
    //     0xb6d9a4: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0xb6d9a8: ldur            x2, [fp, #-8]
    // 0xb6d9ac: b               #0xb6d894
    // 0xb6d9b0: ldur            x1, [fp, #-0x18]
    // 0xb6d9b4: d0 = 0.500000
    //     0xb6d9b4: fmov            d0, #0.50000000
    // 0xb6d9b8: r0 = inflate()
    //     0xb6d9b8: bl              #0xb6daf4  ; [dart:ui] _RRectLike::inflate
    // 0xb6d9bc: stur            x0, [fp, #-8]
    // 0xb6d9c0: r16 = 136
    //     0xb6d9c0: mov             x16, #0x88
    // 0xb6d9c4: stp             x16, NULL, [SP]
    // 0xb6d9c8: r0 = ByteData()
    //     0xb6d9c8: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb6d9cc: stur            x0, [fp, #-0x18]
    // 0xb6d9d0: r0 = Paint()
    //     0xb6d9d0: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb6d9d4: mov             x3, x0
    // 0xb6d9d8: ldur            x0, [fp, #-0x18]
    // 0xb6d9dc: stur            x3, [fp, #-0x20]
    // 0xb6d9e0: StoreField: r3->field_7 = r0
    //     0xb6d9e0: stur            w0, [x3, #7]
    // 0xb6d9e4: mov             x1, x3
    // 0xb6d9e8: r2 = Instance_Color
    //     0xb6d9e8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26c28] Obj!Color@12a2731
    //     0xb6d9ec: ldr             x2, [x2, #0xc28]
    // 0xb6d9f0: r0 = color=()
    //     0xb6d9f0: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb6d9f4: ldur            x1, [fp, #-0x10]
    // 0xb6d9f8: ldur            x2, [fp, #-8]
    // 0xb6d9fc: ldur            x3, [fp, #-0x20]
    // 0xb6da00: r0 = drawRRect()
    //     0xb6da00: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0xb6da04: r0 = Null
    //     0xb6da04: mov             x0, NULL
    // 0xb6da08: LeaveFrame
    //     0xb6da08: mov             SP, fp
    //     0xb6da0c: ldp             fp, lr, [SP], #0x10
    // 0xb6da10: ret
    //     0xb6da10: ret             
    // 0xb6da14: r0 = StackOverflowSharedWithFPURegs()
    //     0xb6da14: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb6da18: b               #0xb6d7ec
    // 0xb6da1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6da1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6da20: b               #0xb6d8a0
  }
  _ _createDefaultThumbDecoration(/* No info */) {
    // ** addr: 0xb6e220, size: 0x68
    // 0xb6e220: EnterFrame
    //     0xb6e220: stp             fp, lr, [SP, #-0x10]!
    //     0xb6e224: mov             fp, SP
    // 0xb6e228: AllocStack(0x10)
    //     0xb6e228: sub             SP, SP, #0x10
    // 0xb6e22c: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb6e22c: stur            x2, [fp, #-0x10]
    // 0xb6e230: LoadField: r0 = r1->field_db
    //     0xb6e230: ldur            w0, [x1, #0xdb]
    // 0xb6e234: DecompressPointer r0
    //     0xb6e234: add             x0, x0, HEAP, lsl #32
    // 0xb6e238: cmp             w0, NULL
    // 0xb6e23c: b.eq            #0xb6e284
    // 0xb6e240: tbnz            w0, #4, #0xb6e24c
    // 0xb6e244: r0 = Null
    //     0xb6e244: mov             x0, NULL
    // 0xb6e248: b               #0xb6e254
    // 0xb6e24c: LoadField: r0 = r1->field_df
    //     0xb6e24c: ldur            w0, [x1, #0xdf]
    // 0xb6e250: DecompressPointer r0
    //     0xb6e250: add             x0, x0, HEAP, lsl #32
    // 0xb6e254: stur            x0, [fp, #-8]
    // 0xb6e258: r0 = ShapeDecoration()
    //     0xb6e258: bl              #0xb6e288  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0xb6e25c: ldur            x1, [fp, #-0x10]
    // 0xb6e260: StoreField: r0->field_7 = r1
    //     0xb6e260: stur            w1, [x0, #7]
    // 0xb6e264: ldur            x1, [fp, #-8]
    // 0xb6e268: StoreField: r0->field_13 = r1
    //     0xb6e268: stur            w1, [x0, #0x13]
    // 0xb6e26c: r1 = Instance_StadiumBorder
    //     0xb6e26c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3578] Obj!StadiumBorder@129ebe1
    //     0xb6e270: ldr             x1, [x1, #0x578]
    // 0xb6e274: ArrayStore: r0[0] = r1  ; List_4
    //     0xb6e274: stur            w1, [x0, #0x17]
    // 0xb6e278: LeaveFrame
    //     0xb6e278: mov             SP, fp
    //     0xb6e27c: ldp             fp, lr, [SP], #0x10
    // 0xb6e280: ret
    //     0xb6e280: ret             
    // 0xb6e284: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6e284: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleDecorationChanged(dynamic) {
    // ** addr: 0xb6e294, size: 0x38
    // 0xb6e294: EnterFrame
    //     0xb6e294: stp             fp, lr, [SP, #-0x10]!
    //     0xb6e298: mov             fp, SP
    // 0xb6e29c: ldr             x0, [fp, #0x10]
    // 0xb6e2a0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb6e2a0: ldur            w1, [x0, #0x17]
    // 0xb6e2a4: DecompressPointer r1
    //     0xb6e2a4: add             x1, x1, HEAP, lsl #32
    // 0xb6e2a8: CheckStackOverflow
    //     0xb6e2a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6e2ac: cmp             SP, x16
    //     0xb6e2b0: b.ls            #0xb6e2c4
    // 0xb6e2b4: r0 = _handleDecorationChanged()
    //     0xb6e2b4: bl              #0xb6e2cc  ; [package:flutter/src/material/switch.dart] _SwitchPainter::_handleDecorationChanged
    // 0xb6e2b8: LeaveFrame
    //     0xb6e2b8: mov             SP, fp
    //     0xb6e2bc: ldp             fp, lr, [SP], #0x10
    // 0xb6e2c0: ret
    //     0xb6e2c0: ret             
    // 0xb6e2c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6e2c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6e2c8: b               #0xb6e2b4
  }
  _ _handleDecorationChanged(/* No info */) {
    // ** addr: 0xb6e2cc, size: 0x3c
    // 0xb6e2cc: EnterFrame
    //     0xb6e2cc: stp             fp, lr, [SP, #-0x10]!
    //     0xb6e2d0: mov             fp, SP
    // 0xb6e2d4: CheckStackOverflow
    //     0xb6e2d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6e2d8: cmp             SP, x16
    //     0xb6e2dc: b.ls            #0xb6e300
    // 0xb6e2e0: LoadField: r0 = r1->field_f7
    //     0xb6e2e0: ldur            w0, [x1, #0xf7]
    // 0xb6e2e4: DecompressPointer r0
    //     0xb6e2e4: add             x0, x0, HEAP, lsl #32
    // 0xb6e2e8: tbz             w0, #4, #0xb6e2f0
    // 0xb6e2ec: r0 = notifyListeners()
    //     0xb6e2ec: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xb6e2f0: r0 = Null
    //     0xb6e2f0: mov             x0, NULL
    // 0xb6e2f4: LeaveFrame
    //     0xb6e2f4: mov             SP, fp
    //     0xb6e2f8: ldp             fp, lr, [SP], #0x10
    // 0xb6e2fc: ret
    //     0xb6e2fc: ret             
    // 0xb6e300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6e300: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6e304: b               #0xb6e2e0
  }
  _ _paintTrackWith(/* No info */) {
    // ** addr: 0xb6e308, size: 0x444
    // 0xb6e308: EnterFrame
    //     0xb6e308: stp             fp, lr, [SP, #-0x10]!
    //     0xb6e30c: mov             fp, SP
    // 0xb6e310: AllocStack(0x88)
    //     0xb6e310: sub             SP, SP, #0x88
    // 0xb6e314: SetupParameters(_SwitchPainter this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r6 => r2, fp-0x20 */, dynamic _ /* r7 => r7, fp-0x28 */)
    //     0xb6e314: mov             x0, x1
    //     0xb6e318: stur            x1, [fp, #-8]
    //     0xb6e31c: mov             x1, x2
    //     0xb6e320: stur            x2, [fp, #-0x10]
    //     0xb6e324: mov             x2, x6
    //     0xb6e328: stur            x3, [fp, #-0x18]
    //     0xb6e32c: stur            x6, [fp, #-0x20]
    //     0xb6e330: stur            x7, [fp, #-0x28]
    // 0xb6e334: CheckStackOverflow
    //     0xb6e334: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6e338: cmp             SP, x16
    //     0xb6e33c: b.ls            #0xb6e724
    // 0xb6e340: LoadField: d0 = r5->field_7
    //     0xb6e340: ldur            d0, [x5, #7]
    // 0xb6e344: stur            d0, [fp, #-0x70]
    // 0xb6e348: LoadField: d1 = r5->field_f
    //     0xb6e348: ldur            d1, [x5, #0xf]
    // 0xb6e34c: stur            d1, [fp, #-0x68]
    // 0xb6e350: LoadField: r4 = r0->field_9b
    //     0xb6e350: ldur            w4, [x0, #0x9b]
    // 0xb6e354: DecompressPointer r4
    //     0xb6e354: add             x4, x4, HEAP, lsl #32
    // 0xb6e358: cmp             w4, NULL
    // 0xb6e35c: b.eq            #0xb6e72c
    // 0xb6e360: LoadField: r5 = r0->field_97
    //     0xb6e360: ldur            w5, [x0, #0x97]
    // 0xb6e364: DecompressPointer r5
    //     0xb6e364: add             x5, x5, HEAP, lsl #32
    // 0xb6e368: cmp             w5, NULL
    // 0xb6e36c: b.eq            #0xb6e730
    // 0xb6e370: LoadField: d2 = r4->field_7
    //     0xb6e370: ldur            d2, [x4, #7]
    // 0xb6e374: fadd            d3, d0, d2
    // 0xb6e378: stur            d3, [fp, #-0x60]
    // 0xb6e37c: LoadField: d2 = r5->field_7
    //     0xb6e37c: ldur            d2, [x5, #7]
    // 0xb6e380: stur            d2, [fp, #-0x58]
    // 0xb6e384: fadd            d4, d1, d2
    // 0xb6e388: stur            d4, [fp, #-0x50]
    // 0xb6e38c: r0 = Rect()
    //     0xb6e38c: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xb6e390: ldur            d0, [fp, #-0x70]
    // 0xb6e394: stur            x0, [fp, #-0x30]
    // 0xb6e398: StoreField: r0->field_7 = d0
    //     0xb6e398: stur            d0, [x0, #7]
    // 0xb6e39c: ldur            d1, [fp, #-0x68]
    // 0xb6e3a0: StoreField: r0->field_f = d1
    //     0xb6e3a0: stur            d1, [x0, #0xf]
    // 0xb6e3a4: ldur            d2, [fp, #-0x60]
    // 0xb6e3a8: ArrayStore: r0[0] = d2  ; List_8
    //     0xb6e3a8: stur            d2, [x0, #0x17]
    // 0xb6e3ac: ldur            d2, [fp, #-0x50]
    // 0xb6e3b0: StoreField: r0->field_1f = d2
    //     0xb6e3b0: stur            d2, [x0, #0x1f]
    // 0xb6e3b4: ldur            d3, [fp, #-0x58]
    // 0xb6e3b8: d2 = 2.000000
    //     0xb6e3b8: fmov            d2, #2.00000000
    // 0xb6e3bc: fdiv            d4, d3, d2
    // 0xb6e3c0: stur            d4, [fp, #-0x50]
    // 0xb6e3c4: r0 = Radius()
    //     0xb6e3c4: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xb6e3c8: ldur            d0, [fp, #-0x50]
    // 0xb6e3cc: stur            x0, [fp, #-0x38]
    // 0xb6e3d0: StoreField: r0->field_7 = d0
    //     0xb6e3d0: stur            d0, [x0, #7]
    // 0xb6e3d4: StoreField: r0->field_f = d0
    //     0xb6e3d4: stur            d0, [x0, #0xf]
    // 0xb6e3d8: r1 = <RRect>
    //     0xb6e3d8: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0xb6e3dc: ldr             x1, [x1, #0x108]
    // 0xb6e3e0: r0 = RRect()
    //     0xb6e3e0: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0xb6e3e4: mov             x1, x0
    // 0xb6e3e8: ldur            x2, [fp, #-0x30]
    // 0xb6e3ec: ldur            x3, [fp, #-0x38]
    // 0xb6e3f0: stur            x0, [fp, #-0x30]
    // 0xb6e3f4: r0 = RRect.fromRectAndRadius()
    //     0xb6e3f4: bl              #0xb6e920  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0xb6e3f8: ldur            x1, [fp, #-0x10]
    // 0xb6e3fc: ldur            x2, [fp, #-0x30]
    // 0xb6e400: ldur            x3, [fp, #-0x18]
    // 0xb6e404: r0 = drawRRect()
    //     0xb6e404: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0xb6e408: ldur            x2, [fp, #-0x20]
    // 0xb6e40c: cmp             w2, NULL
    // 0xb6e410: b.eq            #0xb6e554
    // 0xb6e414: ldur            x1, [fp, #-8]
    // 0xb6e418: ldur            x0, [fp, #-0x28]
    // 0xb6e41c: ldur            d0, [fp, #-0x50]
    // 0xb6e420: ldur            d1, [fp, #-0x70]
    // 0xb6e424: ldur            d2, [fp, #-0x68]
    // 0xb6e428: d3 = 2.000000
    //     0xb6e428: fmov            d3, #2.00000000
    // 0xb6e42c: d4 = 1.000000
    //     0xb6e42c: fmov            d4, #1.00000000
    // 0xb6e430: fadd            d5, d1, d4
    // 0xb6e434: stur            d5, [fp, #-0x78]
    // 0xb6e438: fadd            d1, d2, d4
    // 0xb6e43c: stur            d1, [fp, #-0x70]
    // 0xb6e440: LoadField: r3 = r1->field_9b
    //     0xb6e440: ldur            w3, [x1, #0x9b]
    // 0xb6e444: DecompressPointer r3
    //     0xb6e444: add             x3, x3, HEAP, lsl #32
    // 0xb6e448: cmp             w3, NULL
    // 0xb6e44c: b.eq            #0xb6e734
    // 0xb6e450: LoadField: d2 = r3->field_7
    //     0xb6e450: ldur            d2, [x3, #7]
    // 0xb6e454: fsub            d4, d2, d3
    // 0xb6e458: LoadField: r3 = r1->field_97
    //     0xb6e458: ldur            w3, [x1, #0x97]
    // 0xb6e45c: DecompressPointer r3
    //     0xb6e45c: add             x3, x3, HEAP, lsl #32
    // 0xb6e460: cmp             w3, NULL
    // 0xb6e464: b.eq            #0xb6e738
    // 0xb6e468: LoadField: d2 = r3->field_7
    //     0xb6e468: ldur            d2, [x3, #7]
    // 0xb6e46c: fsub            d6, d2, d3
    // 0xb6e470: fadd            d2, d5, d4
    // 0xb6e474: stur            d2, [fp, #-0x60]
    // 0xb6e478: fadd            d3, d1, d6
    // 0xb6e47c: stur            d3, [fp, #-0x58]
    // 0xb6e480: r0 = Rect()
    //     0xb6e480: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xb6e484: ldur            d0, [fp, #-0x78]
    // 0xb6e488: stur            x0, [fp, #-0x18]
    // 0xb6e48c: StoreField: r0->field_7 = d0
    //     0xb6e48c: stur            d0, [x0, #7]
    // 0xb6e490: ldur            d0, [fp, #-0x70]
    // 0xb6e494: StoreField: r0->field_f = d0
    //     0xb6e494: stur            d0, [x0, #0xf]
    // 0xb6e498: ldur            d0, [fp, #-0x60]
    // 0xb6e49c: ArrayStore: r0[0] = d0  ; List_8
    //     0xb6e49c: stur            d0, [x0, #0x17]
    // 0xb6e4a0: ldur            d0, [fp, #-0x58]
    // 0xb6e4a4: StoreField: r0->field_1f = d0
    //     0xb6e4a4: stur            d0, [x0, #0x1f]
    // 0xb6e4a8: r0 = Radius()
    //     0xb6e4a8: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xb6e4ac: ldur            d0, [fp, #-0x50]
    // 0xb6e4b0: stur            x0, [fp, #-0x38]
    // 0xb6e4b4: StoreField: r0->field_7 = d0
    //     0xb6e4b4: stur            d0, [x0, #7]
    // 0xb6e4b8: StoreField: r0->field_f = d0
    //     0xb6e4b8: stur            d0, [x0, #0xf]
    // 0xb6e4bc: r1 = <RRect>
    //     0xb6e4bc: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0xb6e4c0: ldr             x1, [x1, #0x108]
    // 0xb6e4c4: r0 = RRect()
    //     0xb6e4c4: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0xb6e4c8: mov             x1, x0
    // 0xb6e4cc: ldur            x2, [fp, #-0x18]
    // 0xb6e4d0: ldur            x3, [fp, #-0x38]
    // 0xb6e4d4: stur            x0, [fp, #-0x18]
    // 0xb6e4d8: r0 = RRect.fromRectAndRadius()
    //     0xb6e4d8: bl              #0xb6e920  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0xb6e4dc: r16 = 136
    //     0xb6e4dc: mov             x16, #0x88
    // 0xb6e4e0: stp             x16, NULL, [SP]
    // 0xb6e4e4: r0 = ByteData()
    //     0xb6e4e4: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb6e4e8: stur            x0, [fp, #-0x38]
    // 0xb6e4ec: r0 = Paint()
    //     0xb6e4ec: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb6e4f0: mov             x3, x0
    // 0xb6e4f4: ldur            x0, [fp, #-0x38]
    // 0xb6e4f8: stur            x3, [fp, #-0x40]
    // 0xb6e4fc: StoreField: r3->field_7 = r0
    //     0xb6e4fc: stur            w0, [x3, #7]
    // 0xb6e500: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb6e500: ldur            w1, [x0, #0x17]
    // 0xb6e504: DecompressPointer r1
    //     0xb6e504: add             x1, x1, HEAP, lsl #32
    // 0xb6e508: LoadField: r0 = r1->field_7
    //     0xb6e508: ldur            x0, [x1, #7]
    // 0xb6e50c: r4 = 1
    //     0xb6e50c: mov             x4, #1
    // 0xb6e510: str             w4, [x0, #0x1c]
    // 0xb6e514: ldur            x0, [fp, #-0x28]
    // 0xb6e518: cmp             w0, NULL
    // 0xb6e51c: b.ne            #0xb6e528
    // 0xb6e520: d0 = 2.000000
    //     0xb6e520: fmov            d0, #2.00000000
    // 0xb6e524: b               #0xb6e52c
    // 0xb6e528: LoadField: d0 = r0->field_7
    //     0xb6e528: ldur            d0, [x0, #7]
    // 0xb6e52c: fcvt            s1, d0
    // 0xb6e530: LoadField: r0 = r1->field_7
    //     0xb6e530: ldur            x0, [x1, #7]
    // 0xb6e534: str             s1, [x0, #0x20]
    // 0xb6e538: mov             x1, x3
    // 0xb6e53c: ldur            x2, [fp, #-0x20]
    // 0xb6e540: r0 = color=()
    //     0xb6e540: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb6e544: ldur            x1, [fp, #-0x10]
    // 0xb6e548: ldur            x2, [fp, #-0x18]
    // 0xb6e54c: ldur            x3, [fp, #-0x40]
    // 0xb6e550: r0 = drawRRect()
    //     0xb6e550: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0xb6e554: ldur            x0, [fp, #-8]
    // 0xb6e558: LoadField: r1 = r0->field_db
    //     0xb6e558: ldur            w1, [x0, #0xdb]
    // 0xb6e55c: DecompressPointer r1
    //     0xb6e55c: add             x1, x1, HEAP, lsl #32
    // 0xb6e560: cmp             w1, NULL
    // 0xb6e564: b.eq            #0xb6e73c
    // 0xb6e568: tbnz            w1, #4, #0xb6e704
    // 0xb6e56c: LoadField: r1 = r0->field_53
    //     0xb6e56c: ldur            w1, [x0, #0x53]
    // 0xb6e570: DecompressPointer r1
    //     0xb6e570: add             x1, x1, HEAP, lsl #32
    // 0xb6e574: cmp             w1, NULL
    // 0xb6e578: b.eq            #0xb6e740
    // 0xb6e57c: tbnz            w1, #4, #0xb6e60c
    // 0xb6e580: ldur            x1, [fp, #-0x30]
    // 0xb6e584: d0 = 1.750000
    //     0xb6e584: fmov            d0, #1.75000000
    // 0xb6e588: r0 = inflate()
    //     0xb6e588: bl              #0xb6daf4  ; [dart:ui] _RRectLike::inflate
    // 0xb6e58c: stur            x0, [fp, #-0x18]
    // 0xb6e590: r16 = 136
    //     0xb6e590: mov             x16, #0x88
    // 0xb6e594: stp             x16, NULL, [SP]
    // 0xb6e598: r0 = ByteData()
    //     0xb6e598: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb6e59c: stur            x0, [fp, #-0x20]
    // 0xb6e5a0: r0 = Paint()
    //     0xb6e5a0: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb6e5a4: mov             x3, x0
    // 0xb6e5a8: ldur            x0, [fp, #-0x20]
    // 0xb6e5ac: stur            x3, [fp, #-0x38]
    // 0xb6e5b0: StoreField: r3->field_7 = r0
    //     0xb6e5b0: stur            w0, [x3, #7]
    // 0xb6e5b4: ArrayLoad: r4 = r0[0]  ; List_4
    //     0xb6e5b4: ldur            w4, [x0, #0x17]
    // 0xb6e5b8: DecompressPointer r4
    //     0xb6e5b8: add             x4, x4, HEAP, lsl #32
    // 0xb6e5bc: stur            x4, [fp, #-0x28]
    // 0xb6e5c0: LoadField: r0 = r4->field_7
    //     0xb6e5c0: ldur            x0, [x4, #7]
    // 0xb6e5c4: r1 = 1
    //     0xb6e5c4: mov             x1, #1
    // 0xb6e5c8: str             w1, [x0, #0x1c]
    // 0xb6e5cc: ldur            x0, [fp, #-8]
    // 0xb6e5d0: LoadField: r2 = r0->field_47
    //     0xb6e5d0: ldur            w2, [x0, #0x47]
    // 0xb6e5d4: DecompressPointer r2
    //     0xb6e5d4: add             x2, x2, HEAP, lsl #32
    // 0xb6e5d8: cmp             w2, NULL
    // 0xb6e5dc: b.eq            #0xb6e744
    // 0xb6e5e0: mov             x1, x3
    // 0xb6e5e4: r0 = color=()
    //     0xb6e5e4: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb6e5e8: ldur            x0, [fp, #-0x28]
    // 0xb6e5ec: LoadField: r1 = r0->field_7
    //     0xb6e5ec: ldur            x1, [x0, #7]
    // 0xb6e5f0: d0 = 0.000000
    //     0xb6e5f0: add             x17, PP, #0xa2, lsl #12  ; [pp+0xa2ab8] IMM: 0x40600000
    //     0xb6e5f4: ldr             s0, [x17, #0xab8]
    // 0xb6e5f8: str             s0, [x1, #0x20]
    // 0xb6e5fc: ldur            x1, [fp, #-0x10]
    // 0xb6e600: ldur            x2, [fp, #-0x18]
    // 0xb6e604: ldur            x3, [fp, #-0x38]
    // 0xb6e608: r0 = drawRRect()
    //     0xb6e608: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0xb6e60c: ldur            x1, [fp, #-0x10]
    // 0xb6e610: ldur            x0, [fp, #-0x30]
    // 0xb6e614: LoadField: d0 = r0->field_b
    //     0xb6e614: ldur            d0, [x0, #0xb]
    // 0xb6e618: fcvt            s1, d0
    // 0xb6e61c: stur            d1, [fp, #-0x50]
    // 0xb6e620: r4 = 24
    //     0xb6e620: mov             x4, #0x18
    // 0xb6e624: r0 = AllocateFloat32Array()
    //     0xb6e624: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0xb6e628: ldur            d0, [fp, #-0x50]
    // 0xb6e62c: stur            x0, [fp, #-8]
    // 0xb6e630: ArrayStore: r0[0] = d0  ; List_8
    //     0xb6e630: stur            s0, [x0, #0x17]
    // 0xb6e634: ldur            x1, [fp, #-0x30]
    // 0xb6e638: LoadField: d0 = r1->field_13
    //     0xb6e638: ldur            d0, [x1, #0x13]
    // 0xb6e63c: fcvt            s1, d0
    // 0xb6e640: StoreField: r0->field_1b = d1
    //     0xb6e640: stur            s1, [x0, #0x1b]
    // 0xb6e644: LoadField: d0 = r1->field_1b
    //     0xb6e644: ldur            d0, [x1, #0x1b]
    // 0xb6e648: fcvt            s1, d0
    // 0xb6e64c: StoreField: r0->field_1f = d1
    //     0xb6e64c: stur            s1, [x0, #0x1f]
    // 0xb6e650: LoadField: d0 = r1->field_23
    //     0xb6e650: ldur            d0, [x1, #0x23]
    // 0xb6e654: fcvt            s1, d0
    // 0xb6e658: StoreField: r0->field_23 = d1
    //     0xb6e658: stur            s1, [x0, #0x23]
    // 0xb6e65c: LoadField: d0 = r1->field_2b
    //     0xb6e65c: ldur            d0, [x1, #0x2b]
    // 0xb6e660: fcvt            s1, d0
    // 0xb6e664: StoreField: r0->field_27 = d1
    //     0xb6e664: stur            s1, [x0, #0x27]
    // 0xb6e668: LoadField: d0 = r1->field_33
    //     0xb6e668: ldur            d0, [x1, #0x33]
    // 0xb6e66c: fcvt            s1, d0
    // 0xb6e670: StoreField: r0->field_2b = d1
    //     0xb6e670: stur            s1, [x0, #0x2b]
    // 0xb6e674: LoadField: d0 = r1->field_3b
    //     0xb6e674: ldur            d0, [x1, #0x3b]
    // 0xb6e678: fcvt            s1, d0
    // 0xb6e67c: StoreField: r0->field_2f = d1
    //     0xb6e67c: stur            s1, [x0, #0x2f]
    // 0xb6e680: LoadField: d0 = r1->field_43
    //     0xb6e680: ldur            d0, [x1, #0x43]
    // 0xb6e684: fcvt            s1, d0
    // 0xb6e688: StoreField: r0->field_33 = d1
    //     0xb6e688: stur            s1, [x0, #0x33]
    // 0xb6e68c: LoadField: d0 = r1->field_4b
    //     0xb6e68c: ldur            d0, [x1, #0x4b]
    // 0xb6e690: fcvt            s1, d0
    // 0xb6e694: StoreField: r0->field_37 = d1
    //     0xb6e694: stur            s1, [x0, #0x37]
    // 0xb6e698: LoadField: d0 = r1->field_53
    //     0xb6e698: ldur            d0, [x1, #0x53]
    // 0xb6e69c: fcvt            s1, d0
    // 0xb6e6a0: StoreField: r0->field_3b = d1
    //     0xb6e6a0: stur            s1, [x0, #0x3b]
    // 0xb6e6a4: LoadField: d0 = r1->field_5b
    //     0xb6e6a4: ldur            d0, [x1, #0x5b]
    // 0xb6e6a8: fcvt            s1, d0
    // 0xb6e6ac: StoreField: r0->field_3f = d1
    //     0xb6e6ac: stur            s1, [x0, #0x3f]
    // 0xb6e6b0: LoadField: d0 = r1->field_63
    //     0xb6e6b0: ldur            d0, [x1, #0x63]
    // 0xb6e6b4: fcvt            s1, d0
    // 0xb6e6b8: StoreField: r0->field_43 = d1
    //     0xb6e6b8: stur            s1, [x0, #0x43]
    // 0xb6e6bc: ldur            x2, [fp, #-0x10]
    // 0xb6e6c0: LoadField: r1 = r2->field_7
    //     0xb6e6c0: ldur            w1, [x2, #7]
    // 0xb6e6c4: DecompressPointer r1
    //     0xb6e6c4: add             x1, x1, HEAP, lsl #32
    // 0xb6e6c8: cmp             w1, NULL
    // 0xb6e6cc: b.eq            #0xb6e748
    // 0xb6e6d0: LoadField: r3 = r1->field_7
    //     0xb6e6d0: ldur            x3, [x1, #7]
    // 0xb6e6d4: ldr             x1, [x3]
    // 0xb6e6d8: cbz             x1, #0xb6e714
    // 0xb6e6dc: mov             x3, x1
    // 0xb6e6e0: stur            x3, [fp, #-0x48]
    // 0xb6e6e4: r1 = <Never>
    //     0xb6e6e4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb6e6e8: r0 = Pointer()
    //     0xb6e6e8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb6e6ec: mov             x1, x0
    // 0xb6e6f0: ldur            x0, [fp, #-0x48]
    // 0xb6e6f4: StoreField: r1->field_7 = r0
    //     0xb6e6f4: stur            x0, [x1, #7]
    // 0xb6e6f8: ldur            x2, [fp, #-8]
    // 0xb6e6fc: r3 = true
    //     0xb6e6fc: add             x3, NULL, #0x20  ; true
    // 0xb6e700: r0 = __clipRRect$Method$FfiNative()
    //     0xb6e700: bl              #0xb6e74c  ; [dart:ui] _NativeCanvas::__clipRRect$Method$FfiNative
    // 0xb6e704: r0 = Null
    //     0xb6e704: mov             x0, NULL
    // 0xb6e708: LeaveFrame
    //     0xb6e708: mov             SP, fp
    //     0xb6e70c: ldp             fp, lr, [SP], #0x10
    // 0xb6e710: ret
    //     0xb6e710: ret             
    // 0xb6e714: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb6e714: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb6e718: str             x16, [SP]
    // 0xb6e71c: r0 = _throwNew()
    //     0xb6e71c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb6e720: brk             #0
    // 0xb6e724: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6e724: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6e728: b               #0xb6e340
    // 0xb6e72c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6e72c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6e730: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6e730: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6e734: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6e734: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6e738: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6e738: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6e73c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6e73c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6e740: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6e740: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6e744: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6e744: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6e748: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb6e748: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _computeThumbPaintOffset(/* No info */) {
    // ** addr: 0xb6e970, size: 0xd0
    // 0xb6e970: EnterFrame
    //     0xb6e970: stp             fp, lr, [SP, #-0x10]!
    //     0xb6e974: mov             fp, SP
    // 0xb6e978: AllocStack(0x10)
    //     0xb6e978: sub             SP, SP, #0x10
    // 0xb6e97c: d1 = 2.000000
    //     0xb6e97c: fmov            d1, #2.00000000
    // 0xb6e980: LoadField: r0 = r1->field_97
    //     0xb6e980: ldur            w0, [x1, #0x97]
    // 0xb6e984: DecompressPointer r0
    //     0xb6e984: add             x0, x0, HEAP, lsl #32
    // 0xb6e988: cmp             w0, NULL
    // 0xb6e98c: b.eq            #0xb6ea2c
    // 0xb6e990: LoadField: d2 = r0->field_7
    //     0xb6e990: ldur            d2, [x0, #7]
    // 0xb6e994: fdiv            d3, d2, d1
    // 0xb6e998: LoadField: d2 = r3->field_f
    //     0xb6e998: ldur            d2, [x3, #0xf]
    // 0xb6e99c: fdiv            d4, d2, d1
    // 0xb6e9a0: fsub            d2, d4, d3
    // 0xb6e9a4: LoadField: r0 = r1->field_d7
    //     0xb6e9a4: ldur            w0, [x1, #0xd7]
    // 0xb6e9a8: DecompressPointer r0
    //     0xb6e9a8: add             x0, x0, HEAP, lsl #32
    // 0xb6e9ac: cmp             w0, NULL
    // 0xb6e9b0: b.eq            #0xb6ea30
    // 0xb6e9b4: r17 = 263
    //     0xb6e9b4: mov             x17, #0x107
    // 0xb6e9b8: ldr             w4, [x1, x17]
    // 0xb6e9bc: DecompressPointer r4
    //     0xb6e9bc: add             x4, x4, HEAP, lsl #32
    // 0xb6e9c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb6e9c4: cmp             w4, w16
    // 0xb6e9c8: b.eq            #0xb6ea34
    // 0xb6e9cc: LoadField: d4 = r0->field_7
    //     0xb6e9cc: ldur            d4, [x0, #7]
    // 0xb6e9d0: LoadField: d5 = r4->field_7
    //     0xb6e9d0: ldur            d5, [x4, #7]
    // 0xb6e9d4: fsub            d6, d4, d5
    // 0xb6e9d8: fmul            d4, d0, d6
    // 0xb6e9dc: LoadField: d0 = r2->field_7
    //     0xb6e9dc: ldur            d0, [x2, #7]
    // 0xb6e9e0: fadd            d6, d0, d3
    // 0xb6e9e4: fdiv            d0, d5, d1
    // 0xb6e9e8: fadd            d3, d6, d0
    // 0xb6e9ec: LoadField: d0 = r3->field_7
    //     0xb6e9ec: ldur            d0, [x3, #7]
    // 0xb6e9f0: fdiv            d5, d0, d1
    // 0xb6e9f4: fsub            d0, d3, d5
    // 0xb6e9f8: fadd            d1, d0, d4
    // 0xb6e9fc: stur            d1, [fp, #-0x10]
    // 0xb6ea00: LoadField: d0 = r2->field_f
    //     0xb6ea00: ldur            d0, [x2, #0xf]
    // 0xb6ea04: fsub            d3, d0, d2
    // 0xb6ea08: stur            d3, [fp, #-8]
    // 0xb6ea0c: r0 = Offset()
    //     0xb6ea0c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb6ea10: ldur            d0, [fp, #-0x10]
    // 0xb6ea14: StoreField: r0->field_7 = d0
    //     0xb6ea14: stur            d0, [x0, #7]
    // 0xb6ea18: ldur            d0, [fp, #-8]
    // 0xb6ea1c: StoreField: r0->field_f = d0
    //     0xb6ea1c: stur            d0, [x0, #0xf]
    // 0xb6ea20: LeaveFrame
    //     0xb6ea20: mov             SP, fp
    //     0xb6ea24: ldp             fp, lr, [SP], #0x10
    // 0xb6ea28: ret
    //     0xb6ea28: ret             
    // 0xb6ea2c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6ea2c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6ea30: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb6ea30: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb6ea34: r9 = _pressedThumbExtension
    //     0xb6ea34: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3550] Field <_SwitchPainter@127328938._pressedThumbExtension@127328938>: late (offset: 0x108)
    //     0xb6ea38: ldr             x9, [x9, #0x550]
    // 0xb6ea3c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xb6ea3c: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  _ _computeTrackPaintOffset(/* No info */) {
    // ** addr: 0xb6ea40, size: 0x50
    // 0xb6ea40: EnterFrame
    //     0xb6ea40: stp             fp, lr, [SP, #-0x10]!
    //     0xb6ea44: mov             fp, SP
    // 0xb6ea48: AllocStack(0x10)
    //     0xb6ea48: sub             SP, SP, #0x10
    // 0xb6ea4c: d2 = 2.000000
    //     0xb6ea4c: fmov            d2, #2.00000000
    // 0xb6ea50: LoadField: d3 = r2->field_7
    //     0xb6ea50: ldur            d3, [x2, #7]
    // 0xb6ea54: fsub            d4, d3, d0
    // 0xb6ea58: fdiv            d0, d4, d2
    // 0xb6ea5c: stur            d0, [fp, #-0x10]
    // 0xb6ea60: LoadField: d3 = r2->field_f
    //     0xb6ea60: ldur            d3, [x2, #0xf]
    // 0xb6ea64: fsub            d4, d3, d1
    // 0xb6ea68: fdiv            d1, d4, d2
    // 0xb6ea6c: stur            d1, [fp, #-8]
    // 0xb6ea70: r0 = Offset()
    //     0xb6ea70: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb6ea74: ldur            d0, [fp, #-0x10]
    // 0xb6ea78: StoreField: r0->field_7 = d0
    //     0xb6ea78: stur            d0, [x0, #7]
    // 0xb6ea7c: ldur            d0, [fp, #-8]
    // 0xb6ea80: StoreField: r0->field_f = d0
    //     0xb6ea80: stur            d0, [x0, #0xf]
    // 0xb6ea84: LeaveFrame
    //     0xb6ea84: mov             SP, fp
    //     0xb6ea88: ldp             fp, lr, [SP], #0x10
    // 0xb6ea8c: ret
    //     0xb6ea8c: ret             
  }
  [closure] Animation<Size> thumbSizeAnimation(dynamic, bool) {
    // ** addr: 0xb6ef78, size: 0x494
    // 0xb6ef78: EnterFrame
    //     0xb6ef78: stp             fp, lr, [SP, #-0x10]!
    //     0xb6ef7c: mov             fp, SP
    // 0xb6ef80: AllocStack(0x30)
    //     0xb6ef80: sub             SP, SP, #0x30
    // 0xb6ef84: SetupParameters([dynamic _ /* r0 */])
    //     0xb6ef84: ldr             x0, [fp, #0x18]
    //     0xb6ef88: ldur            w2, [x0, #0x17]
    //     0xb6ef8c: add             x2, x2, HEAP, lsl #32
    //     0xb6ef90: stur            x2, [fp, #-0x18]
    // 0xb6ef94: CheckStackOverflow
    //     0xb6ef94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6ef98: cmp             SP, x16
    //     0xb6ef9c: b.ls            #0xb6f3f0
    // 0xb6efa0: ldr             x0, [fp, #0x10]
    // 0xb6efa4: tbnz            w0, #4, #0xb6f174
    // 0xb6efa8: LoadField: r0 = r2->field_13
    //     0xb6efa8: ldur            w0, [x2, #0x13]
    // 0xb6efac: DecompressPointer r0
    //     0xb6efac: add             x0, x0, HEAP, lsl #32
    // 0xb6efb0: stur            x0, [fp, #-0x10]
    // 0xb6efb4: LoadField: r1 = r2->field_f
    //     0xb6efb4: ldur            w1, [x2, #0xf]
    // 0xb6efb8: DecompressPointer r1
    //     0xb6efb8: add             x1, x1, HEAP, lsl #32
    // 0xb6efbc: LoadField: r3 = r1->field_93
    //     0xb6efbc: ldur            w3, [x1, #0x93]
    // 0xb6efc0: DecompressPointer r3
    //     0xb6efc0: add             x3, x3, HEAP, lsl #32
    // 0xb6efc4: stur            x3, [fp, #-8]
    // 0xb6efc8: cmp             w3, NULL
    // 0xb6efcc: b.eq            #0xb6f3f8
    // 0xb6efd0: r1 = <Size>
    //     0xb6efd0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xb6efd4: ldr             x1, [x1, #0xaa0]
    // 0xb6efd8: r0 = Tween()
    //     0xb6efd8: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xb6efdc: mov             x2, x0
    // 0xb6efe0: ldur            x0, [fp, #-0x10]
    // 0xb6efe4: stur            x2, [fp, #-0x20]
    // 0xb6efe8: StoreField: r2->field_b = r0
    //     0xb6efe8: stur            w0, [x2, #0xb]
    // 0xb6efec: ldur            x0, [fp, #-8]
    // 0xb6eff0: StoreField: r2->field_f = r0
    //     0xb6eff0: stur            w0, [x2, #0xf]
    // 0xb6eff4: r1 = <double>
    //     0xb6eff4: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xb6eff8: r0 = CurveTween()
    //     0xb6eff8: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xb6effc: mov             x1, x0
    // 0xb6f000: r0 = Instance_Cubic
    //     0xb6f000: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3558] Obj!Cubic@129f5d1
    //     0xb6f004: ldr             x0, [x0, #0x558]
    // 0xb6f008: StoreField: r1->field_b = r0
    //     0xb6f008: stur            w0, [x1, #0xb]
    // 0xb6f00c: mov             x2, x1
    // 0xb6f010: ldur            x1, [fp, #-0x20]
    // 0xb6f014: r0 = chain()
    //     0xb6f014: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xb6f018: r1 = <Size>
    //     0xb6f018: add             x1, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xb6f01c: ldr             x1, [x1, #0xaa0]
    // 0xb6f020: stur            x0, [fp, #-8]
    // 0xb6f024: r0 = TweenSequenceItem()
    //     0xb6f024: bl              #0xb6f82c  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0xb6f028: mov             x2, x0
    // 0xb6f02c: ldur            x0, [fp, #-8]
    // 0xb6f030: stur            x2, [fp, #-0x20]
    // 0xb6f034: StoreField: r2->field_b = r0
    //     0xb6f034: stur            w0, [x2, #0xb]
    // 0xb6f038: d0 = 11.000000
    //     0xb6f038: fmov            d0, #11.00000000
    // 0xb6f03c: StoreField: r2->field_f = d0
    //     0xb6f03c: stur            d0, [x2, #0xf]
    // 0xb6f040: ldur            x0, [fp, #-0x18]
    // 0xb6f044: LoadField: r1 = r0->field_f
    //     0xb6f044: ldur            w1, [x0, #0xf]
    // 0xb6f048: DecompressPointer r1
    //     0xb6f048: add             x1, x1, HEAP, lsl #32
    // 0xb6f04c: LoadField: r3 = r1->field_93
    //     0xb6f04c: ldur            w3, [x1, #0x93]
    // 0xb6f050: DecompressPointer r3
    //     0xb6f050: add             x3, x3, HEAP, lsl #32
    // 0xb6f054: stur            x3, [fp, #-0x10]
    // 0xb6f058: cmp             w3, NULL
    // 0xb6f05c: b.eq            #0xb6f3fc
    // 0xb6f060: ArrayLoad: r4 = r0[0]  ; List_4
    //     0xb6f060: ldur            w4, [x0, #0x17]
    // 0xb6f064: DecompressPointer r4
    //     0xb6f064: add             x4, x4, HEAP, lsl #32
    // 0xb6f068: stur            x4, [fp, #-8]
    // 0xb6f06c: r1 = <Size>
    //     0xb6f06c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xb6f070: ldr             x1, [x1, #0xaa0]
    // 0xb6f074: r0 = Tween()
    //     0xb6f074: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xb6f078: mov             x2, x0
    // 0xb6f07c: ldur            x0, [fp, #-0x10]
    // 0xb6f080: stur            x2, [fp, #-0x28]
    // 0xb6f084: StoreField: r2->field_b = r0
    //     0xb6f084: stur            w0, [x2, #0xb]
    // 0xb6f088: ldur            x0, [fp, #-8]
    // 0xb6f08c: StoreField: r2->field_f = r0
    //     0xb6f08c: stur            w0, [x2, #0xf]
    // 0xb6f090: r1 = <double>
    //     0xb6f090: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xb6f094: r0 = CurveTween()
    //     0xb6f094: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xb6f098: r2 = Instance_Cubic
    //     0xb6f098: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3560] Obj!Cubic@129f5a1
    //     0xb6f09c: ldr             x2, [x2, #0x560]
    // 0xb6f0a0: StoreField: r0->field_b = r2
    //     0xb6f0a0: stur            w2, [x0, #0xb]
    // 0xb6f0a4: ldur            x1, [fp, #-0x28]
    // 0xb6f0a8: mov             x2, x0
    // 0xb6f0ac: r0 = chain()
    //     0xb6f0ac: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xb6f0b0: r1 = <Size>
    //     0xb6f0b0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xb6f0b4: ldr             x1, [x1, #0xaa0]
    // 0xb6f0b8: stur            x0, [fp, #-0x10]
    // 0xb6f0bc: r0 = TweenSequenceItem()
    //     0xb6f0bc: bl              #0xb6f82c  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0xb6f0c0: mov             x2, x0
    // 0xb6f0c4: ldur            x0, [fp, #-0x10]
    // 0xb6f0c8: stur            x2, [fp, #-0x28]
    // 0xb6f0cc: StoreField: r2->field_b = r0
    //     0xb6f0cc: stur            w0, [x2, #0xb]
    // 0xb6f0d0: d1 = 72.000000
    //     0xb6f0d0: add             x17, PP, #0x89, lsl #12  ; [pp+0x89030] IMM: double(72) from 0x4052000000000000
    //     0xb6f0d4: ldr             d1, [x17, #0x30]
    // 0xb6f0d8: StoreField: r2->field_f = d1
    //     0xb6f0d8: stur            d1, [x2, #0xf]
    // 0xb6f0dc: r1 = <Size>
    //     0xb6f0dc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xb6f0e0: ldr             x1, [x1, #0xaa0]
    // 0xb6f0e4: r0 = ConstantTween()
    //     0xb6f0e4: bl              #0xb6f820  ; AllocateConstantTweenStub -> ConstantTween<X0> (size=0x14)
    // 0xb6f0e8: mov             x2, x0
    // 0xb6f0ec: ldur            x0, [fp, #-8]
    // 0xb6f0f0: stur            x2, [fp, #-0x10]
    // 0xb6f0f4: StoreField: r2->field_b = r0
    //     0xb6f0f4: stur            w0, [x2, #0xb]
    // 0xb6f0f8: StoreField: r2->field_f = r0
    //     0xb6f0f8: stur            w0, [x2, #0xf]
    // 0xb6f0fc: r1 = <Size>
    //     0xb6f0fc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xb6f100: ldr             x1, [x1, #0xaa0]
    // 0xb6f104: r0 = TweenSequenceItem()
    //     0xb6f104: bl              #0xb6f82c  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0xb6f108: mov             x3, x0
    // 0xb6f10c: ldur            x0, [fp, #-0x10]
    // 0xb6f110: stur            x3, [fp, #-8]
    // 0xb6f114: StoreField: r3->field_b = r0
    //     0xb6f114: stur            w0, [x3, #0xb]
    // 0xb6f118: d2 = 17.000000
    //     0xb6f118: fmov            d2, #17.00000000
    // 0xb6f11c: StoreField: r3->field_f = d2
    //     0xb6f11c: stur            d2, [x3, #0xf]
    // 0xb6f120: r1 = Null
    //     0xb6f120: mov             x1, NULL
    // 0xb6f124: r2 = 6
    //     0xb6f124: mov             x2, #6
    // 0xb6f128: r0 = AllocateArray()
    //     0xb6f128: bl              #0x13df928  ; AllocateArrayStub
    // 0xb6f12c: mov             x2, x0
    // 0xb6f130: ldur            x0, [fp, #-0x20]
    // 0xb6f134: stur            x2, [fp, #-0x10]
    // 0xb6f138: StoreField: r2->field_f = r0
    //     0xb6f138: stur            w0, [x2, #0xf]
    // 0xb6f13c: ldur            x0, [fp, #-0x28]
    // 0xb6f140: StoreField: r2->field_13 = r0
    //     0xb6f140: stur            w0, [x2, #0x13]
    // 0xb6f144: ldur            x0, [fp, #-8]
    // 0xb6f148: ArrayStore: r2[0] = r0  ; List_4
    //     0xb6f148: stur            w0, [x2, #0x17]
    // 0xb6f14c: r1 = <TweenSequenceItem<Size>>
    //     0xb6f14c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3568] TypeArguments: <TweenSequenceItem<Size>>
    //     0xb6f150: ldr             x1, [x1, #0x568]
    // 0xb6f154: r0 = AllocateGrowableArray()
    //     0xb6f154: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xb6f158: mov             x1, x0
    // 0xb6f15c: ldur            x0, [fp, #-0x10]
    // 0xb6f160: StoreField: r1->field_f = r0
    //     0xb6f160: stur            w0, [x1, #0xf]
    // 0xb6f164: r3 = 6
    //     0xb6f164: mov             x3, #6
    // 0xb6f168: StoreField: r1->field_b = r3
    //     0xb6f168: stur            w3, [x1, #0xb]
    // 0xb6f16c: mov             x2, x1
    // 0xb6f170: b               #0xb6f39c
    // 0xb6f174: mov             x4, x2
    // 0xb6f178: r2 = Instance_Cubic
    //     0xb6f178: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3560] Obj!Cubic@129f5a1
    //     0xb6f17c: ldr             x2, [x2, #0x560]
    // 0xb6f180: r0 = Instance_Cubic
    //     0xb6f180: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3558] Obj!Cubic@129f5d1
    //     0xb6f184: ldr             x0, [x0, #0x558]
    // 0xb6f188: r3 = 6
    //     0xb6f188: mov             x3, #6
    // 0xb6f18c: d0 = 11.000000
    //     0xb6f18c: fmov            d0, #11.00000000
    // 0xb6f190: d1 = 72.000000
    //     0xb6f190: add             x17, PP, #0x89, lsl #12  ; [pp+0x89030] IMM: double(72) from 0x4052000000000000
    //     0xb6f194: ldr             d1, [x17, #0x30]
    // 0xb6f198: d2 = 17.000000
    //     0xb6f198: fmov            d2, #17.00000000
    // 0xb6f19c: LoadField: r5 = r4->field_13
    //     0xb6f19c: ldur            w5, [x4, #0x13]
    // 0xb6f1a0: DecompressPointer r5
    //     0xb6f1a0: add             x5, x5, HEAP, lsl #32
    // 0xb6f1a4: stur            x5, [fp, #-8]
    // 0xb6f1a8: r1 = <Size>
    //     0xb6f1a8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xb6f1ac: ldr             x1, [x1, #0xaa0]
    // 0xb6f1b0: r0 = ConstantTween()
    //     0xb6f1b0: bl              #0xb6f820  ; AllocateConstantTweenStub -> ConstantTween<X0> (size=0x14)
    // 0xb6f1b4: mov             x2, x0
    // 0xb6f1b8: ldur            x0, [fp, #-8]
    // 0xb6f1bc: stur            x2, [fp, #-0x10]
    // 0xb6f1c0: StoreField: r2->field_b = r0
    //     0xb6f1c0: stur            w0, [x2, #0xb]
    // 0xb6f1c4: StoreField: r2->field_f = r0
    //     0xb6f1c4: stur            w0, [x2, #0xf]
    // 0xb6f1c8: r1 = <Size>
    //     0xb6f1c8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xb6f1cc: ldr             x1, [x1, #0xaa0]
    // 0xb6f1d0: r0 = TweenSequenceItem()
    //     0xb6f1d0: bl              #0xb6f82c  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0xb6f1d4: mov             x2, x0
    // 0xb6f1d8: ldur            x0, [fp, #-0x10]
    // 0xb6f1dc: stur            x2, [fp, #-0x20]
    // 0xb6f1e0: StoreField: r2->field_b = r0
    //     0xb6f1e0: stur            w0, [x2, #0xb]
    // 0xb6f1e4: d0 = 17.000000
    //     0xb6f1e4: fmov            d0, #17.00000000
    // 0xb6f1e8: StoreField: r2->field_f = d0
    //     0xb6f1e8: stur            d0, [x2, #0xf]
    // 0xb6f1ec: ldur            x0, [fp, #-0x18]
    // 0xb6f1f0: LoadField: r1 = r0->field_f
    //     0xb6f1f0: ldur            w1, [x0, #0xf]
    // 0xb6f1f4: DecompressPointer r1
    //     0xb6f1f4: add             x1, x1, HEAP, lsl #32
    // 0xb6f1f8: LoadField: r3 = r1->field_93
    //     0xb6f1f8: ldur            w3, [x1, #0x93]
    // 0xb6f1fc: DecompressPointer r3
    //     0xb6f1fc: add             x3, x3, HEAP, lsl #32
    // 0xb6f200: stur            x3, [fp, #-0x10]
    // 0xb6f204: cmp             w3, NULL
    // 0xb6f208: b.eq            #0xb6f400
    // 0xb6f20c: r1 = <Size>
    //     0xb6f20c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xb6f210: ldr             x1, [x1, #0xaa0]
    // 0xb6f214: r0 = Tween()
    //     0xb6f214: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xb6f218: mov             x2, x0
    // 0xb6f21c: ldur            x0, [fp, #-8]
    // 0xb6f220: stur            x2, [fp, #-0x28]
    // 0xb6f224: StoreField: r2->field_b = r0
    //     0xb6f224: stur            w0, [x2, #0xb]
    // 0xb6f228: ldur            x0, [fp, #-0x10]
    // 0xb6f22c: StoreField: r2->field_f = r0
    //     0xb6f22c: stur            w0, [x2, #0xf]
    // 0xb6f230: r1 = <double>
    //     0xb6f230: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xb6f234: r0 = FlippedCurve()
    //     0xb6f234: bl              #0xb6f814  ; AllocateFlippedCurveStub -> FlippedCurve (size=0x10)
    // 0xb6f238: mov             x2, x0
    // 0xb6f23c: r0 = Instance_Cubic
    //     0xb6f23c: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3560] Obj!Cubic@129f5a1
    //     0xb6f240: ldr             x0, [x0, #0x560]
    // 0xb6f244: stur            x2, [fp, #-8]
    // 0xb6f248: StoreField: r2->field_b = r0
    //     0xb6f248: stur            w0, [x2, #0xb]
    // 0xb6f24c: r1 = <double>
    //     0xb6f24c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xb6f250: r0 = CurveTween()
    //     0xb6f250: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xb6f254: mov             x1, x0
    // 0xb6f258: ldur            x0, [fp, #-8]
    // 0xb6f25c: StoreField: r1->field_b = r0
    //     0xb6f25c: stur            w0, [x1, #0xb]
    // 0xb6f260: mov             x2, x1
    // 0xb6f264: ldur            x1, [fp, #-0x28]
    // 0xb6f268: r0 = chain()
    //     0xb6f268: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xb6f26c: r1 = <Size>
    //     0xb6f26c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xb6f270: ldr             x1, [x1, #0xaa0]
    // 0xb6f274: stur            x0, [fp, #-8]
    // 0xb6f278: r0 = TweenSequenceItem()
    //     0xb6f278: bl              #0xb6f82c  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0xb6f27c: mov             x2, x0
    // 0xb6f280: ldur            x0, [fp, #-8]
    // 0xb6f284: stur            x2, [fp, #-0x28]
    // 0xb6f288: StoreField: r2->field_b = r0
    //     0xb6f288: stur            w0, [x2, #0xb]
    // 0xb6f28c: d0 = 72.000000
    //     0xb6f28c: add             x17, PP, #0x89, lsl #12  ; [pp+0x89030] IMM: double(72) from 0x4052000000000000
    //     0xb6f290: ldr             d0, [x17, #0x30]
    // 0xb6f294: StoreField: r2->field_f = d0
    //     0xb6f294: stur            d0, [x2, #0xf]
    // 0xb6f298: ldur            x0, [fp, #-0x18]
    // 0xb6f29c: LoadField: r1 = r0->field_f
    //     0xb6f29c: ldur            w1, [x0, #0xf]
    // 0xb6f2a0: DecompressPointer r1
    //     0xb6f2a0: add             x1, x1, HEAP, lsl #32
    // 0xb6f2a4: LoadField: r3 = r1->field_93
    //     0xb6f2a4: ldur            w3, [x1, #0x93]
    // 0xb6f2a8: DecompressPointer r3
    //     0xb6f2a8: add             x3, x3, HEAP, lsl #32
    // 0xb6f2ac: stur            x3, [fp, #-0x10]
    // 0xb6f2b0: cmp             w3, NULL
    // 0xb6f2b4: b.eq            #0xb6f404
    // 0xb6f2b8: ArrayLoad: r4 = r0[0]  ; List_4
    //     0xb6f2b8: ldur            w4, [x0, #0x17]
    // 0xb6f2bc: DecompressPointer r4
    //     0xb6f2bc: add             x4, x4, HEAP, lsl #32
    // 0xb6f2c0: stur            x4, [fp, #-8]
    // 0xb6f2c4: r1 = <Size>
    //     0xb6f2c4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xb6f2c8: ldr             x1, [x1, #0xaa0]
    // 0xb6f2cc: r0 = Tween()
    //     0xb6f2cc: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xb6f2d0: mov             x2, x0
    // 0xb6f2d4: ldur            x0, [fp, #-0x10]
    // 0xb6f2d8: stur            x2, [fp, #-0x30]
    // 0xb6f2dc: StoreField: r2->field_b = r0
    //     0xb6f2dc: stur            w0, [x2, #0xb]
    // 0xb6f2e0: ldur            x0, [fp, #-8]
    // 0xb6f2e4: StoreField: r2->field_f = r0
    //     0xb6f2e4: stur            w0, [x2, #0xf]
    // 0xb6f2e8: r1 = <double>
    //     0xb6f2e8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xb6f2ec: r0 = FlippedCurve()
    //     0xb6f2ec: bl              #0xb6f814  ; AllocateFlippedCurveStub -> FlippedCurve (size=0x10)
    // 0xb6f2f0: mov             x2, x0
    // 0xb6f2f4: r0 = Instance_Cubic
    //     0xb6f2f4: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3558] Obj!Cubic@129f5d1
    //     0xb6f2f8: ldr             x0, [x0, #0x558]
    // 0xb6f2fc: stur            x2, [fp, #-8]
    // 0xb6f300: StoreField: r2->field_b = r0
    //     0xb6f300: stur            w0, [x2, #0xb]
    // 0xb6f304: r1 = <double>
    //     0xb6f304: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xb6f308: r0 = CurveTween()
    //     0xb6f308: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xb6f30c: mov             x1, x0
    // 0xb6f310: ldur            x0, [fp, #-8]
    // 0xb6f314: StoreField: r1->field_b = r0
    //     0xb6f314: stur            w0, [x1, #0xb]
    // 0xb6f318: mov             x2, x1
    // 0xb6f31c: ldur            x1, [fp, #-0x30]
    // 0xb6f320: r0 = chain()
    //     0xb6f320: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xb6f324: r1 = <Size>
    //     0xb6f324: add             x1, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xb6f328: ldr             x1, [x1, #0xaa0]
    // 0xb6f32c: stur            x0, [fp, #-8]
    // 0xb6f330: r0 = TweenSequenceItem()
    //     0xb6f330: bl              #0xb6f82c  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0xb6f334: mov             x3, x0
    // 0xb6f338: ldur            x0, [fp, #-8]
    // 0xb6f33c: stur            x3, [fp, #-0x10]
    // 0xb6f340: StoreField: r3->field_b = r0
    //     0xb6f340: stur            w0, [x3, #0xb]
    // 0xb6f344: d0 = 11.000000
    //     0xb6f344: fmov            d0, #11.00000000
    // 0xb6f348: StoreField: r3->field_f = d0
    //     0xb6f348: stur            d0, [x3, #0xf]
    // 0xb6f34c: r1 = Null
    //     0xb6f34c: mov             x1, NULL
    // 0xb6f350: r2 = 6
    //     0xb6f350: mov             x2, #6
    // 0xb6f354: r0 = AllocateArray()
    //     0xb6f354: bl              #0x13df928  ; AllocateArrayStub
    // 0xb6f358: mov             x2, x0
    // 0xb6f35c: ldur            x0, [fp, #-0x20]
    // 0xb6f360: stur            x2, [fp, #-8]
    // 0xb6f364: StoreField: r2->field_f = r0
    //     0xb6f364: stur            w0, [x2, #0xf]
    // 0xb6f368: ldur            x0, [fp, #-0x28]
    // 0xb6f36c: StoreField: r2->field_13 = r0
    //     0xb6f36c: stur            w0, [x2, #0x13]
    // 0xb6f370: ldur            x0, [fp, #-0x10]
    // 0xb6f374: ArrayStore: r2[0] = r0  ; List_4
    //     0xb6f374: stur            w0, [x2, #0x17]
    // 0xb6f378: r1 = <TweenSequenceItem<Size>>
    //     0xb6f378: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3568] TypeArguments: <TweenSequenceItem<Size>>
    //     0xb6f37c: ldr             x1, [x1, #0x568]
    // 0xb6f380: r0 = AllocateGrowableArray()
    //     0xb6f380: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xb6f384: mov             x1, x0
    // 0xb6f388: ldur            x0, [fp, #-8]
    // 0xb6f38c: StoreField: r1->field_f = r0
    //     0xb6f38c: stur            w0, [x1, #0xf]
    // 0xb6f390: r0 = 6
    //     0xb6f390: mov             x0, #6
    // 0xb6f394: StoreField: r1->field_b = r0
    //     0xb6f394: stur            w0, [x1, #0xb]
    // 0xb6f398: mov             x2, x1
    // 0xb6f39c: ldur            x0, [fp, #-0x18]
    // 0xb6f3a0: stur            x2, [fp, #-8]
    // 0xb6f3a4: r1 = <Size>
    //     0xb6f3a4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xb6f3a8: ldr             x1, [x1, #0xaa0]
    // 0xb6f3ac: r0 = TweenSequence()
    //     0xb6f3ac: bl              #0xb6f808  ; AllocateTweenSequenceStub -> TweenSequence<X0> (size=0x14)
    // 0xb6f3b0: mov             x1, x0
    // 0xb6f3b4: ldur            x2, [fp, #-8]
    // 0xb6f3b8: stur            x0, [fp, #-8]
    // 0xb6f3bc: r0 = TweenSequence()
    //     0xb6f3bc: bl              #0xb6f43c  ; [package:flutter/src/animation/tween_sequence.dart] TweenSequence::TweenSequence
    // 0xb6f3c0: ldur            x0, [fp, #-0x18]
    // 0xb6f3c4: LoadField: r1 = r0->field_f
    //     0xb6f3c4: ldur            w1, [x0, #0xf]
    // 0xb6f3c8: DecompressPointer r1
    //     0xb6f3c8: add             x1, x1, HEAP, lsl #32
    // 0xb6f3cc: LoadField: r2 = r1->field_5f
    //     0xb6f3cc: ldur            w2, [x1, #0x5f]
    // 0xb6f3d0: DecompressPointer r2
    //     0xb6f3d0: add             x2, x2, HEAP, lsl #32
    // 0xb6f3d4: cmp             w2, NULL
    // 0xb6f3d8: b.eq            #0xb6f408
    // 0xb6f3dc: ldur            x1, [fp, #-8]
    // 0xb6f3e0: r0 = animate()
    //     0xb6f3e0: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xb6f3e4: LeaveFrame
    //     0xb6f3e4: mov             SP, fp
    //     0xb6f3e8: ldp             fp, lr, [SP], #0x10
    // 0xb6f3ec: ret
    //     0xb6f3ec: ret             
    // 0xb6f3f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6f3f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6f3f4: b               #0xb6efa0
    // 0xb6f3f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6f3f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6f3fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6f3fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6f400: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6f400: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6f404: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6f404: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6f408: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6f408: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ isCupertino=(/* No info */) {
    // ** addr: 0xd40cc0, size: 0x54
    // 0xd40cc0: EnterFrame
    //     0xd40cc0: stp             fp, lr, [SP, #-0x10]!
    //     0xd40cc4: mov             fp, SP
    // 0xd40cc8: CheckStackOverflow
    //     0xd40cc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd40ccc: cmp             SP, x16
    //     0xd40cd0: b.ls            #0xd40d0c
    // 0xd40cd4: LoadField: r0 = r1->field_db
    //     0xd40cd4: ldur            w0, [x1, #0xdb]
    // 0xd40cd8: DecompressPointer r0
    //     0xd40cd8: add             x0, x0, HEAP, lsl #32
    // 0xd40cdc: cmp             w2, w0
    // 0xd40ce0: b.ne            #0xd40cf4
    // 0xd40ce4: r0 = Null
    //     0xd40ce4: mov             x0, NULL
    // 0xd40ce8: LeaveFrame
    //     0xd40ce8: mov             SP, fp
    //     0xd40cec: ldp             fp, lr, [SP], #0x10
    // 0xd40cf0: ret
    //     0xd40cf0: ret             
    // 0xd40cf4: StoreField: r1->field_db = r2
    //     0xd40cf4: stur            w2, [x1, #0xdb]
    // 0xd40cf8: r0 = notifyListeners()
    //     0xd40cf8: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd40cfc: r0 = Null
    //     0xd40cfc: mov             x0, NULL
    // 0xd40d00: LeaveFrame
    //     0xd40d00: mov             SP, fp
    //     0xd40d04: ldp             fp, lr, [SP], #0x10
    // 0xd40d08: ret
    //     0xd40d08: ret             
    // 0xd40d0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd40d0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd40d10: b               #0xd40cd4
  }
  set _ positionController=(/* No info */) {
    // ** addr: 0xd40d14, size: 0x10c
    // 0xd40d14: EnterFrame
    //     0xd40d14: stp             fp, lr, [SP, #-0x10]!
    //     0xd40d18: mov             fp, SP
    // 0xd40d1c: AllocStack(0x20)
    //     0xd40d1c: sub             SP, SP, #0x20
    // 0xd40d20: SetupParameters(_SwitchPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0 */)
    //     0xd40d20: mov             x0, x2
    //     0xd40d24: mov             x2, x1
    //     0xd40d28: stur            x1, [fp, #-8]
    // 0xd40d2c: CheckStackOverflow
    //     0xd40d2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd40d30: cmp             SP, x16
    //     0xd40d34: b.ls            #0xd40e14
    // 0xd40d38: LoadField: r1 = r2->field_5f
    //     0xd40d38: ldur            w1, [x2, #0x5f]
    // 0xd40d3c: DecompressPointer r1
    //     0xd40d3c: add             x1, x1, HEAP, lsl #32
    // 0xd40d40: cmp             w0, w1
    // 0xd40d44: b.ne            #0xd40d58
    // 0xd40d48: r0 = Null
    //     0xd40d48: mov             x0, NULL
    // 0xd40d4c: LeaveFrame
    //     0xd40d4c: mov             SP, fp
    //     0xd40d50: ldp             fp, lr, [SP], #0x10
    // 0xd40d54: ret
    //     0xd40d54: ret             
    // 0xd40d58: StoreField: r2->field_5f = r0
    //     0xd40d58: stur            w0, [x2, #0x5f]
    //     0xd40d5c: ldurb           w16, [x2, #-1]
    //     0xd40d60: ldurb           w17, [x0, #-1]
    //     0xd40d64: and             x16, x17, x16, lsr #2
    //     0xd40d68: tst             x16, HEAP, lsr #32
    //     0xd40d6c: b.eq            #0xd40d74
    //     0xd40d70: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd40d74: LoadField: r1 = r2->field_63
    //     0xd40d74: ldur            w1, [x2, #0x63]
    // 0xd40d78: DecompressPointer r1
    //     0xd40d78: add             x1, x1, HEAP, lsl #32
    // 0xd40d7c: cmp             w1, NULL
    // 0xd40d80: b.ne            #0xd40d8c
    // 0xd40d84: mov             x0, x2
    // 0xd40d88: b               #0xd40d94
    // 0xd40d8c: r0 = dispose()
    //     0xd40d8c: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xd40d90: ldur            x0, [fp, #-8]
    // 0xd40d94: LoadField: r3 = r0->field_5f
    //     0xd40d94: ldur            w3, [x0, #0x5f]
    // 0xd40d98: DecompressPointer r3
    //     0xd40d98: add             x3, x3, HEAP, lsl #32
    // 0xd40d9c: stur            x3, [fp, #-0x10]
    // 0xd40da0: cmp             w3, NULL
    // 0xd40da4: b.eq            #0xd40e1c
    // 0xd40da8: r1 = <double>
    //     0xd40da8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd40dac: r0 = CurvedAnimation()
    //     0xd40dac: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xd40db0: stur            x0, [fp, #-0x18]
    // 0xd40db4: r16 = Instance_Cubic
    //     0xd40db4: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e970] Obj!Cubic@129f541
    //     0xd40db8: ldr             x16, [x16, #0x970]
    // 0xd40dbc: str             x16, [SP]
    // 0xd40dc0: mov             x1, x0
    // 0xd40dc4: ldur            x3, [fp, #-0x10]
    // 0xd40dc8: r2 = Instance_Cubic
    //     0xd40dc8: add             x2, PP, #0x15, lsl #12  ; [pp+0x158f0] Obj!Cubic@129f571
    //     0xd40dcc: ldr             x2, [x2, #0x8f0]
    // 0xd40dd0: r4 = const [0, 0x4, 0x1, 0x3, reverseCurve, 0x3, null]
    //     0xd40dd0: add             x4, PP, #0x16, lsl #12  ; [pp+0x16dc0] List(7) [0, 0x4, 0x1, 0x3, "reverseCurve", 0x3, Null]
    //     0xd40dd4: ldr             x4, [x4, #0xdc0]
    // 0xd40dd8: r0 = CurvedAnimation()
    //     0xd40dd8: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xd40ddc: ldur            x0, [fp, #-0x18]
    // 0xd40de0: ldur            x1, [fp, #-8]
    // 0xd40de4: StoreField: r1->field_63 = r0
    //     0xd40de4: stur            w0, [x1, #0x63]
    //     0xd40de8: ldurb           w16, [x1, #-1]
    //     0xd40dec: ldurb           w17, [x0, #-1]
    //     0xd40df0: and             x16, x17, x16, lsr #2
    //     0xd40df4: tst             x16, HEAP, lsr #32
    //     0xd40df8: b.eq            #0xd40e00
    //     0xd40dfc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd40e00: r0 = notifyListeners()
    //     0xd40e00: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd40e04: r0 = Null
    //     0xd40e04: mov             x0, NULL
    // 0xd40e08: LeaveFrame
    //     0xd40e08: mov             SP, fp
    //     0xd40e0c: ldp             fp, lr, [SP], #0x10
    // 0xd40e10: ret
    //     0xd40e10: ret             
    // 0xd40e14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd40e14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd40e18: b               #0xd40d38
    // 0xd40e1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40e1c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ transitionalThumbSize=(/* No info */) {
    // ** addr: 0xd40e20, size: 0x90
    // 0xd40e20: EnterFrame
    //     0xd40e20: stp             fp, lr, [SP, #-0x10]!
    //     0xd40e24: mov             fp, SP
    // 0xd40e28: mov             x0, x2
    // 0xd40e2c: CheckStackOverflow
    //     0xd40e2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd40e30: cmp             SP, x16
    //     0xd40e34: b.ls            #0xd40ea8
    // 0xd40e38: LoadField: r2 = r1->field_93
    //     0xd40e38: ldur            w2, [x1, #0x93]
    // 0xd40e3c: DecompressPointer r2
    //     0xd40e3c: add             x2, x2, HEAP, lsl #32
    // 0xd40e40: cmp             w2, NULL
    // 0xd40e44: b.eq            #0xd40e78
    // 0xd40e48: LoadField: d0 = r2->field_7
    //     0xd40e48: ldur            d0, [x2, #7]
    // 0xd40e4c: LoadField: d1 = r0->field_7
    //     0xd40e4c: ldur            d1, [x0, #7]
    // 0xd40e50: fcmp            d0, d1
    // 0xd40e54: b.ne            #0xd40e78
    // 0xd40e58: LoadField: d0 = r2->field_f
    //     0xd40e58: ldur            d0, [x2, #0xf]
    // 0xd40e5c: LoadField: d1 = r0->field_f
    //     0xd40e5c: ldur            d1, [x0, #0xf]
    // 0xd40e60: fcmp            d0, d1
    // 0xd40e64: b.ne            #0xd40e78
    // 0xd40e68: r0 = Null
    //     0xd40e68: mov             x0, NULL
    // 0xd40e6c: LeaveFrame
    //     0xd40e6c: mov             SP, fp
    //     0xd40e70: ldp             fp, lr, [SP], #0x10
    // 0xd40e74: ret
    //     0xd40e74: ret             
    // 0xd40e78: StoreField: r1->field_93 = r0
    //     0xd40e78: stur            w0, [x1, #0x93]
    //     0xd40e7c: ldurb           w16, [x1, #-1]
    //     0xd40e80: ldurb           w17, [x0, #-1]
    //     0xd40e84: and             x16, x17, x16, lsr #2
    //     0xd40e88: tst             x16, HEAP, lsr #32
    //     0xd40e8c: b.eq            #0xd40e94
    //     0xd40e90: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd40e94: r0 = notifyListeners()
    //     0xd40e94: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd40e98: r0 = Null
    //     0xd40e98: mov             x0, NULL
    // 0xd40e9c: LeaveFrame
    //     0xd40e9c: mov             SP, fp
    //     0xd40ea0: ldp             fp, lr, [SP], #0x10
    // 0xd40ea4: ret
    //     0xd40ea4: ret             
    // 0xd40ea8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd40ea8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd40eac: b               #0xd40e38
  }
  set _ thumbShadow=(/* No info */) {
    // ** addr: 0xd40eb0, size: 0xa4
    // 0xd40eb0: EnterFrame
    //     0xd40eb0: stp             fp, lr, [SP, #-0x10]!
    //     0xd40eb4: mov             fp, SP
    // 0xd40eb8: AllocStack(0x20)
    //     0xd40eb8: sub             SP, SP, #0x20
    // 0xd40ebc: SetupParameters(_SwitchPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd40ebc: stur            x1, [fp, #-8]
    //     0xd40ec0: mov             x16, x2
    //     0xd40ec4: mov             x2, x1
    //     0xd40ec8: mov             x1, x16
    //     0xd40ecc: stur            x1, [fp, #-0x10]
    // 0xd40ed0: CheckStackOverflow
    //     0xd40ed0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd40ed4: cmp             SP, x16
    //     0xd40ed8: b.ls            #0xd40f4c
    // 0xd40edc: LoadField: r0 = r2->field_df
    //     0xd40edc: ldur            w0, [x2, #0xdf]
    // 0xd40ee0: DecompressPointer r0
    //     0xd40ee0: add             x0, x0, HEAP, lsl #32
    // 0xd40ee4: r3 = LoadClassIdInstr(r1)
    //     0xd40ee4: ldur            x3, [x1, #-1]
    //     0xd40ee8: ubfx            x3, x3, #0xc, #0x14
    // 0xd40eec: stp             x0, x1, [SP]
    // 0xd40ef0: mov             x0, x3
    // 0xd40ef4: mov             lr, x0
    // 0xd40ef8: ldr             lr, [x21, lr, lsl #3]
    // 0xd40efc: blr             lr
    // 0xd40f00: tbnz            w0, #4, #0xd40f14
    // 0xd40f04: r0 = Null
    //     0xd40f04: mov             x0, NULL
    // 0xd40f08: LeaveFrame
    //     0xd40f08: mov             SP, fp
    //     0xd40f0c: ldp             fp, lr, [SP], #0x10
    // 0xd40f10: ret
    //     0xd40f10: ret             
    // 0xd40f14: ldur            x1, [fp, #-8]
    // 0xd40f18: ldur            x0, [fp, #-0x10]
    // 0xd40f1c: StoreField: r1->field_df = r0
    //     0xd40f1c: stur            w0, [x1, #0xdf]
    //     0xd40f20: ldurb           w16, [x1, #-1]
    //     0xd40f24: ldurb           w17, [x0, #-1]
    //     0xd40f28: and             x16, x17, x16, lsr #2
    //     0xd40f2c: tst             x16, HEAP, lsr #32
    //     0xd40f30: b.eq            #0xd40f38
    //     0xd40f34: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd40f38: r0 = notifyListeners()
    //     0xd40f38: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd40f3c: r0 = Null
    //     0xd40f3c: mov             x0, NULL
    // 0xd40f40: LeaveFrame
    //     0xd40f40: mov             SP, fp
    //     0xd40f44: ldp             fp, lr, [SP], #0x10
    // 0xd40f48: ret
    //     0xd40f48: ret             
    // 0xd40f4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd40f4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd40f50: b               #0xd40edc
  }
  set _ iconTheme=(/* No info */) {
    // ** addr: 0xd40f54, size: 0x88
    // 0xd40f54: EnterFrame
    //     0xd40f54: stp             fp, lr, [SP, #-0x10]!
    //     0xd40f58: mov             fp, SP
    // 0xd40f5c: AllocStack(0x20)
    //     0xd40f5c: sub             SP, SP, #0x20
    // 0xd40f60: SetupParameters(_SwitchPainter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xd40f60: mov             x0, x2
    //     0xd40f64: stur            x1, [fp, #-8]
    //     0xd40f68: stur            x2, [fp, #-0x10]
    // 0xd40f6c: CheckStackOverflow
    //     0xd40f6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd40f70: cmp             SP, x16
    //     0xd40f74: b.ls            #0xd40fd4
    // 0xd40f78: LoadField: r2 = r1->field_6f
    //     0xd40f78: ldur            w2, [x1, #0x6f]
    // 0xd40f7c: DecompressPointer r2
    //     0xd40f7c: add             x2, x2, HEAP, lsl #32
    // 0xd40f80: stp             x2, x0, [SP]
    // 0xd40f84: r0 = ==()
    //     0xd40f84: bl              #0x12625cc  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::==
    // 0xd40f88: tbnz            w0, #4, #0xd40f9c
    // 0xd40f8c: r0 = Null
    //     0xd40f8c: mov             x0, NULL
    // 0xd40f90: LeaveFrame
    //     0xd40f90: mov             SP, fp
    //     0xd40f94: ldp             fp, lr, [SP], #0x10
    // 0xd40f98: ret
    //     0xd40f98: ret             
    // 0xd40f9c: ldur            x1, [fp, #-8]
    // 0xd40fa0: ldur            x0, [fp, #-0x10]
    // 0xd40fa4: StoreField: r1->field_6f = r0
    //     0xd40fa4: stur            w0, [x1, #0x6f]
    //     0xd40fa8: ldurb           w16, [x1, #-1]
    //     0xd40fac: ldurb           w17, [x0, #-1]
    //     0xd40fb0: and             x16, x17, x16, lsr #2
    //     0xd40fb4: tst             x16, HEAP, lsr #32
    //     0xd40fb8: b.eq            #0xd40fc0
    //     0xd40fbc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd40fc0: r0 = notifyListeners()
    //     0xd40fc0: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd40fc4: r0 = Null
    //     0xd40fc4: mov             x0, NULL
    // 0xd40fc8: LeaveFrame
    //     0xd40fc8: mov             SP, fp
    //     0xd40fcc: ldp             fp, lr, [SP], #0x10
    // 0xd40fd0: ret
    //     0xd40fd0: ret             
    // 0xd40fd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd40fd4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd40fd8: b               #0xd40f78
  }
  set _ inactiveIconColor=(/* No info */) {
    // ** addr: 0xd40fdc, size: 0xa4
    // 0xd40fdc: EnterFrame
    //     0xd40fdc: stp             fp, lr, [SP, #-0x10]!
    //     0xd40fe0: mov             fp, SP
    // 0xd40fe4: AllocStack(0x20)
    //     0xd40fe4: sub             SP, SP, #0x20
    // 0xd40fe8: SetupParameters(_SwitchPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd40fe8: stur            x1, [fp, #-8]
    //     0xd40fec: mov             x16, x2
    //     0xd40ff0: mov             x2, x1
    //     0xd40ff4: mov             x1, x16
    //     0xd40ff8: stur            x1, [fp, #-0x10]
    // 0xd40ffc: CheckStackOverflow
    //     0xd40ffc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd41000: cmp             SP, x16
    //     0xd41004: b.ls            #0xd41078
    // 0xd41008: LoadField: r0 = r2->field_77
    //     0xd41008: ldur            w0, [x2, #0x77]
    // 0xd4100c: DecompressPointer r0
    //     0xd4100c: add             x0, x0, HEAP, lsl #32
    // 0xd41010: r3 = LoadClassIdInstr(r1)
    //     0xd41010: ldur            x3, [x1, #-1]
    //     0xd41014: ubfx            x3, x3, #0xc, #0x14
    // 0xd41018: stp             x0, x1, [SP]
    // 0xd4101c: mov             x0, x3
    // 0xd41020: mov             lr, x0
    // 0xd41024: ldr             lr, [x21, lr, lsl #3]
    // 0xd41028: blr             lr
    // 0xd4102c: tbnz            w0, #4, #0xd41040
    // 0xd41030: r0 = Null
    //     0xd41030: mov             x0, NULL
    // 0xd41034: LeaveFrame
    //     0xd41034: mov             SP, fp
    //     0xd41038: ldp             fp, lr, [SP], #0x10
    // 0xd4103c: ret
    //     0xd4103c: ret             
    // 0xd41040: ldur            x1, [fp, #-8]
    // 0xd41044: ldur            x0, [fp, #-0x10]
    // 0xd41048: StoreField: r1->field_77 = r0
    //     0xd41048: stur            w0, [x1, #0x77]
    //     0xd4104c: ldurb           w16, [x1, #-1]
    //     0xd41050: ldurb           w17, [x0, #-1]
    //     0xd41054: and             x16, x17, x16, lsr #2
    //     0xd41058: tst             x16, HEAP, lsr #32
    //     0xd4105c: b.eq            #0xd41064
    //     0xd41060: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd41064: r0 = notifyListeners()
    //     0xd41064: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd41068: r0 = Null
    //     0xd41068: mov             x0, NULL
    // 0xd4106c: LeaveFrame
    //     0xd4106c: mov             SP, fp
    //     0xd41070: ldp             fp, lr, [SP], #0x10
    // 0xd41074: ret
    //     0xd41074: ret             
    // 0xd41078: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd41078: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4107c: b               #0xd41008
  }
  set _ activeIconColor=(/* No info */) {
    // ** addr: 0xd41080, size: 0xa4
    // 0xd41080: EnterFrame
    //     0xd41080: stp             fp, lr, [SP, #-0x10]!
    //     0xd41084: mov             fp, SP
    // 0xd41088: AllocStack(0x20)
    //     0xd41088: sub             SP, SP, #0x20
    // 0xd4108c: SetupParameters(_SwitchPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd4108c: stur            x1, [fp, #-8]
    //     0xd41090: mov             x16, x2
    //     0xd41094: mov             x2, x1
    //     0xd41098: mov             x1, x16
    //     0xd4109c: stur            x1, [fp, #-0x10]
    // 0xd410a0: CheckStackOverflow
    //     0xd410a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd410a4: cmp             SP, x16
    //     0xd410a8: b.ls            #0xd4111c
    // 0xd410ac: LoadField: r0 = r2->field_73
    //     0xd410ac: ldur            w0, [x2, #0x73]
    // 0xd410b0: DecompressPointer r0
    //     0xd410b0: add             x0, x0, HEAP, lsl #32
    // 0xd410b4: r3 = LoadClassIdInstr(r1)
    //     0xd410b4: ldur            x3, [x1, #-1]
    //     0xd410b8: ubfx            x3, x3, #0xc, #0x14
    // 0xd410bc: stp             x0, x1, [SP]
    // 0xd410c0: mov             x0, x3
    // 0xd410c4: mov             lr, x0
    // 0xd410c8: ldr             lr, [x21, lr, lsl #3]
    // 0xd410cc: blr             lr
    // 0xd410d0: tbnz            w0, #4, #0xd410e4
    // 0xd410d4: r0 = Null
    //     0xd410d4: mov             x0, NULL
    // 0xd410d8: LeaveFrame
    //     0xd410d8: mov             SP, fp
    //     0xd410dc: ldp             fp, lr, [SP], #0x10
    // 0xd410e0: ret
    //     0xd410e0: ret             
    // 0xd410e4: ldur            x1, [fp, #-8]
    // 0xd410e8: ldur            x0, [fp, #-0x10]
    // 0xd410ec: StoreField: r1->field_73 = r0
    //     0xd410ec: stur            w0, [x1, #0x73]
    //     0xd410f0: ldurb           w16, [x1, #-1]
    //     0xd410f4: ldurb           w17, [x0, #-1]
    //     0xd410f8: and             x16, x17, x16, lsr #2
    //     0xd410fc: tst             x16, HEAP, lsr #32
    //     0xd41100: b.eq            #0xd41108
    //     0xd41104: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd41108: r0 = notifyListeners()
    //     0xd41108: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd4110c: r0 = Null
    //     0xd4110c: mov             x0, NULL
    // 0xd41110: LeaveFrame
    //     0xd41110: mov             SP, fp
    //     0xd41114: ldp             fp, lr, [SP], #0x10
    // 0xd41118: ret
    //     0xd41118: ret             
    // 0xd4111c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4111c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd41120: b               #0xd410ac
  }
  set _ trackWidth=(/* No info */) {
    // ** addr: 0xd41124, size: 0xcc
    // 0xd41124: EnterFrame
    //     0xd41124: stp             fp, lr, [SP, #-0x10]!
    //     0xd41128: mov             fp, SP
    // 0xd4112c: AllocStack(0x20)
    //     0xd4112c: sub             SP, SP, #0x20
    // 0xd41130: SetupParameters(_SwitchPainter this /* r1 => r1, fp-0x10 */)
    //     0xd41130: stur            x1, [fp, #-0x10]
    // 0xd41134: CheckStackOverflow
    //     0xd41134: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd41138: cmp             SP, x16
    //     0xd4113c: b.ls            #0xd411cc
    // 0xd41140: LoadField: r0 = r1->field_9b
    //     0xd41140: ldur            w0, [x1, #0x9b]
    // 0xd41144: DecompressPointer r0
    //     0xd41144: add             x0, x0, HEAP, lsl #32
    // 0xd41148: r2 = inline_Allocate_Double()
    //     0xd41148: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xd4114c: add             x2, x2, #0x10
    //     0xd41150: cmp             x3, x2
    //     0xd41154: b.ls            #0xd411d4
    //     0xd41158: str             x2, [THR, #0x60]  ; THR::top
    //     0xd4115c: sub             x2, x2, #0xf
    //     0xd41160: mov             x3, #0xe19c
    //     0xd41164: movk            x3, #3, lsl #16
    //     0xd41168: stur            x3, [x2, #-1]
    // 0xd4116c: dmb             ishst
    // 0xd41170: StoreField: r2->field_7 = d0
    //     0xd41170: stur            d0, [x2, #7]
    // 0xd41174: stur            x2, [fp, #-8]
    // 0xd41178: stp             x0, x2, [SP]
    // 0xd4117c: r0 = ==()
    //     0xd4117c: bl              #0x12b7c00  ; [dart:core] _Double::==
    // 0xd41180: tbnz            w0, #4, #0xd41194
    // 0xd41184: r0 = Null
    //     0xd41184: mov             x0, NULL
    // 0xd41188: LeaveFrame
    //     0xd41188: mov             SP, fp
    //     0xd4118c: ldp             fp, lr, [SP], #0x10
    // 0xd41190: ret
    //     0xd41190: ret             
    // 0xd41194: ldur            x1, [fp, #-0x10]
    // 0xd41198: ldur            x0, [fp, #-8]
    // 0xd4119c: StoreField: r1->field_9b = r0
    //     0xd4119c: stur            w0, [x1, #0x9b]
    //     0xd411a0: ldurb           w16, [x1, #-1]
    //     0xd411a4: ldurb           w17, [x0, #-1]
    //     0xd411a8: and             x16, x17, x16, lsr #2
    //     0xd411ac: tst             x16, HEAP, lsr #32
    //     0xd411b0: b.eq            #0xd411b8
    //     0xd411b4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd411b8: r0 = notifyListeners()
    //     0xd411b8: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd411bc: r0 = Null
    //     0xd411bc: mov             x0, NULL
    // 0xd411c0: LeaveFrame
    //     0xd411c0: mov             SP, fp
    //     0xd411c4: ldp             fp, lr, [SP], #0x10
    // 0xd411c8: ret
    //     0xd411c8: ret             
    // 0xd411cc: r0 = StackOverflowSharedWithFPURegs()
    //     0xd411cc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd411d0: b               #0xd41140
    // 0xd411d4: SaveReg d0
    //     0xd411d4: str             q0, [SP, #-0x10]!
    // 0xd411d8: stp             x0, x1, [SP, #-0x10]!
    // 0xd411dc: r0 = AllocateDouble()
    //     0xd411dc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd411e0: mov             x2, x0
    // 0xd411e4: ldp             x0, x1, [SP], #0x10
    // 0xd411e8: RestoreReg d0
    //     0xd411e8: ldr             q0, [SP], #0x10
    // 0xd411ec: b               #0xd41170
  }
  set _ trackHeight=(/* No info */) {
    // ** addr: 0xd411f0, size: 0xcc
    // 0xd411f0: EnterFrame
    //     0xd411f0: stp             fp, lr, [SP, #-0x10]!
    //     0xd411f4: mov             fp, SP
    // 0xd411f8: AllocStack(0x20)
    //     0xd411f8: sub             SP, SP, #0x20
    // 0xd411fc: SetupParameters(_SwitchPainter this /* r1 => r1, fp-0x10 */)
    //     0xd411fc: stur            x1, [fp, #-0x10]
    // 0xd41200: CheckStackOverflow
    //     0xd41200: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd41204: cmp             SP, x16
    //     0xd41208: b.ls            #0xd41298
    // 0xd4120c: LoadField: r0 = r1->field_97
    //     0xd4120c: ldur            w0, [x1, #0x97]
    // 0xd41210: DecompressPointer r0
    //     0xd41210: add             x0, x0, HEAP, lsl #32
    // 0xd41214: r2 = inline_Allocate_Double()
    //     0xd41214: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xd41218: add             x2, x2, #0x10
    //     0xd4121c: cmp             x3, x2
    //     0xd41220: b.ls            #0xd412a0
    //     0xd41224: str             x2, [THR, #0x60]  ; THR::top
    //     0xd41228: sub             x2, x2, #0xf
    //     0xd4122c: mov             x3, #0xe19c
    //     0xd41230: movk            x3, #3, lsl #16
    //     0xd41234: stur            x3, [x2, #-1]
    // 0xd41238: dmb             ishst
    // 0xd4123c: StoreField: r2->field_7 = d0
    //     0xd4123c: stur            d0, [x2, #7]
    // 0xd41240: stur            x2, [fp, #-8]
    // 0xd41244: stp             x0, x2, [SP]
    // 0xd41248: r0 = ==()
    //     0xd41248: bl              #0x12b7c00  ; [dart:core] _Double::==
    // 0xd4124c: tbnz            w0, #4, #0xd41260
    // 0xd41250: r0 = Null
    //     0xd41250: mov             x0, NULL
    // 0xd41254: LeaveFrame
    //     0xd41254: mov             SP, fp
    //     0xd41258: ldp             fp, lr, [SP], #0x10
    // 0xd4125c: ret
    //     0xd4125c: ret             
    // 0xd41260: ldur            x1, [fp, #-0x10]
    // 0xd41264: ldur            x0, [fp, #-8]
    // 0xd41268: StoreField: r1->field_97 = r0
    //     0xd41268: stur            w0, [x1, #0x97]
    //     0xd4126c: ldurb           w16, [x1, #-1]
    //     0xd41270: ldurb           w17, [x0, #-1]
    //     0xd41274: and             x16, x17, x16, lsr #2
    //     0xd41278: tst             x16, HEAP, lsr #32
    //     0xd4127c: b.eq            #0xd41284
    //     0xd41280: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd41284: r0 = notifyListeners()
    //     0xd41284: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd41288: r0 = Null
    //     0xd41288: mov             x0, NULL
    // 0xd4128c: LeaveFrame
    //     0xd4128c: mov             SP, fp
    //     0xd41290: ldp             fp, lr, [SP], #0x10
    // 0xd41294: ret
    //     0xd41294: ret             
    // 0xd41298: r0 = StackOverflowSharedWithFPURegs()
    //     0xd41298: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd4129c: b               #0xd4120c
    // 0xd412a0: SaveReg d0
    //     0xd412a0: str             q0, [SP, #-0x10]!
    // 0xd412a4: stp             x0, x1, [SP, #-0x10]!
    // 0xd412a8: r0 = AllocateDouble()
    //     0xd412a8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd412ac: mov             x2, x0
    // 0xd412b0: ldp             x0, x1, [SP], #0x10
    // 0xd412b4: RestoreReg d0
    //     0xd412b4: ldr             q0, [SP], #0x10
    // 0xd412b8: b               #0xd4123c
  }
  set _ thumbOffset=(/* No info */) {
    // ** addr: 0xd412bc, size: 0xa4
    // 0xd412bc: EnterFrame
    //     0xd412bc: stp             fp, lr, [SP, #-0x10]!
    //     0xd412c0: mov             fp, SP
    // 0xd412c4: AllocStack(0x20)
    //     0xd412c4: sub             SP, SP, #0x20
    // 0xd412c8: SetupParameters(_SwitchPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd412c8: stur            x1, [fp, #-8]
    //     0xd412cc: mov             x16, x2
    //     0xd412d0: mov             x2, x1
    //     0xd412d4: mov             x1, x16
    //     0xd412d8: stur            x1, [fp, #-0x10]
    // 0xd412dc: CheckStackOverflow
    //     0xd412dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd412e0: cmp             SP, x16
    //     0xd412e4: b.ls            #0xd41358
    // 0xd412e8: LoadField: r0 = r2->field_8f
    //     0xd412e8: ldur            w0, [x2, #0x8f]
    // 0xd412ec: DecompressPointer r0
    //     0xd412ec: add             x0, x0, HEAP, lsl #32
    // 0xd412f0: r3 = LoadClassIdInstr(r1)
    //     0xd412f0: ldur            x3, [x1, #-1]
    //     0xd412f4: ubfx            x3, x3, #0xc, #0x14
    // 0xd412f8: stp             x0, x1, [SP]
    // 0xd412fc: mov             x0, x3
    // 0xd41300: mov             lr, x0
    // 0xd41304: ldr             lr, [x21, lr, lsl #3]
    // 0xd41308: blr             lr
    // 0xd4130c: tbnz            w0, #4, #0xd41320
    // 0xd41310: r0 = Null
    //     0xd41310: mov             x0, NULL
    // 0xd41314: LeaveFrame
    //     0xd41314: mov             SP, fp
    //     0xd41318: ldp             fp, lr, [SP], #0x10
    // 0xd4131c: ret
    //     0xd4131c: ret             
    // 0xd41320: ldur            x1, [fp, #-8]
    // 0xd41324: ldur            x0, [fp, #-0x10]
    // 0xd41328: StoreField: r1->field_8f = r0
    //     0xd41328: stur            w0, [x1, #0x8f]
    //     0xd4132c: ldurb           w16, [x1, #-1]
    //     0xd41330: ldurb           w17, [x0, #-1]
    //     0xd41334: and             x16, x17, x16, lsr #2
    //     0xd41338: tst             x16, HEAP, lsr #32
    //     0xd4133c: b.eq            #0xd41344
    //     0xd41340: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd41344: r0 = notifyListeners()
    //     0xd41344: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd41348: r0 = Null
    //     0xd41348: mov             x0, NULL
    // 0xd4134c: LeaveFrame
    //     0xd4134c: mov             SP, fp
    //     0xd41350: ldp             fp, lr, [SP], #0x10
    // 0xd41354: ret
    //     0xd41354: ret             
    // 0xd41358: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd41358: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4135c: b               #0xd412e8
  }
  set _ pressedThumbRadius=(/* No info */) {
    // ** addr: 0xd41360, size: 0xcc
    // 0xd41360: EnterFrame
    //     0xd41360: stp             fp, lr, [SP, #-0x10]!
    //     0xd41364: mov             fp, SP
    // 0xd41368: AllocStack(0x20)
    //     0xd41368: sub             SP, SP, #0x20
    // 0xd4136c: SetupParameters(_SwitchPainter this /* r1 => r1, fp-0x10 */)
    //     0xd4136c: stur            x1, [fp, #-0x10]
    // 0xd41370: CheckStackOverflow
    //     0xd41370: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd41374: cmp             SP, x16
    //     0xd41378: b.ls            #0xd41408
    // 0xd4137c: LoadField: r0 = r1->field_8b
    //     0xd4137c: ldur            w0, [x1, #0x8b]
    // 0xd41380: DecompressPointer r0
    //     0xd41380: add             x0, x0, HEAP, lsl #32
    // 0xd41384: r2 = inline_Allocate_Double()
    //     0xd41384: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xd41388: add             x2, x2, #0x10
    //     0xd4138c: cmp             x3, x2
    //     0xd41390: b.ls            #0xd41410
    //     0xd41394: str             x2, [THR, #0x60]  ; THR::top
    //     0xd41398: sub             x2, x2, #0xf
    //     0xd4139c: mov             x3, #0xe19c
    //     0xd413a0: movk            x3, #3, lsl #16
    //     0xd413a4: stur            x3, [x2, #-1]
    // 0xd413a8: dmb             ishst
    // 0xd413ac: StoreField: r2->field_7 = d0
    //     0xd413ac: stur            d0, [x2, #7]
    // 0xd413b0: stur            x2, [fp, #-8]
    // 0xd413b4: stp             x0, x2, [SP]
    // 0xd413b8: r0 = ==()
    //     0xd413b8: bl              #0x12b7c00  ; [dart:core] _Double::==
    // 0xd413bc: tbnz            w0, #4, #0xd413d0
    // 0xd413c0: r0 = Null
    //     0xd413c0: mov             x0, NULL
    // 0xd413c4: LeaveFrame
    //     0xd413c4: mov             SP, fp
    //     0xd413c8: ldp             fp, lr, [SP], #0x10
    // 0xd413cc: ret
    //     0xd413cc: ret             
    // 0xd413d0: ldur            x1, [fp, #-0x10]
    // 0xd413d4: ldur            x0, [fp, #-8]
    // 0xd413d8: StoreField: r1->field_8b = r0
    //     0xd413d8: stur            w0, [x1, #0x8b]
    //     0xd413dc: ldurb           w16, [x1, #-1]
    //     0xd413e0: ldurb           w17, [x0, #-1]
    //     0xd413e4: and             x16, x17, x16, lsr #2
    //     0xd413e8: tst             x16, HEAP, lsr #32
    //     0xd413ec: b.eq            #0xd413f4
    //     0xd413f0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd413f4: r0 = notifyListeners()
    //     0xd413f4: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd413f8: r0 = Null
    //     0xd413f8: mov             x0, NULL
    // 0xd413fc: LeaveFrame
    //     0xd413fc: mov             SP, fp
    //     0xd41400: ldp             fp, lr, [SP], #0x10
    // 0xd41404: ret
    //     0xd41404: ret             
    // 0xd41408: r0 = StackOverflowSharedWithFPURegs()
    //     0xd41408: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd4140c: b               #0xd4137c
    // 0xd41410: SaveReg d0
    //     0xd41410: str             q0, [SP, #-0x10]!
    // 0xd41414: stp             x0, x1, [SP, #-0x10]!
    // 0xd41418: r0 = AllocateDouble()
    //     0xd41418: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd4141c: mov             x2, x0
    // 0xd41420: ldp             x0, x1, [SP], #0x10
    // 0xd41424: RestoreReg d0
    //     0xd41424: ldr             q0, [SP], #0x10
    // 0xd41428: b               #0xd413ac
  }
  set _ activeThumbRadius=(/* No info */) {
    // ** addr: 0xd4142c, size: 0xcc
    // 0xd4142c: EnterFrame
    //     0xd4142c: stp             fp, lr, [SP, #-0x10]!
    //     0xd41430: mov             fp, SP
    // 0xd41434: AllocStack(0x20)
    //     0xd41434: sub             SP, SP, #0x20
    // 0xd41438: SetupParameters(_SwitchPainter this /* r1 => r1, fp-0x10 */)
    //     0xd41438: stur            x1, [fp, #-0x10]
    // 0xd4143c: CheckStackOverflow
    //     0xd4143c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd41440: cmp             SP, x16
    //     0xd41444: b.ls            #0xd414d4
    // 0xd41448: LoadField: r0 = r1->field_83
    //     0xd41448: ldur            w0, [x1, #0x83]
    // 0xd4144c: DecompressPointer r0
    //     0xd4144c: add             x0, x0, HEAP, lsl #32
    // 0xd41450: r2 = inline_Allocate_Double()
    //     0xd41450: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xd41454: add             x2, x2, #0x10
    //     0xd41458: cmp             x3, x2
    //     0xd4145c: b.ls            #0xd414dc
    //     0xd41460: str             x2, [THR, #0x60]  ; THR::top
    //     0xd41464: sub             x2, x2, #0xf
    //     0xd41468: mov             x3, #0xe19c
    //     0xd4146c: movk            x3, #3, lsl #16
    //     0xd41470: stur            x3, [x2, #-1]
    // 0xd41474: dmb             ishst
    // 0xd41478: StoreField: r2->field_7 = d0
    //     0xd41478: stur            d0, [x2, #7]
    // 0xd4147c: stur            x2, [fp, #-8]
    // 0xd41480: stp             x0, x2, [SP]
    // 0xd41484: r0 = ==()
    //     0xd41484: bl              #0x12b7c00  ; [dart:core] _Double::==
    // 0xd41488: tbnz            w0, #4, #0xd4149c
    // 0xd4148c: r0 = Null
    //     0xd4148c: mov             x0, NULL
    // 0xd41490: LeaveFrame
    //     0xd41490: mov             SP, fp
    //     0xd41494: ldp             fp, lr, [SP], #0x10
    // 0xd41498: ret
    //     0xd41498: ret             
    // 0xd4149c: ldur            x1, [fp, #-0x10]
    // 0xd414a0: ldur            x0, [fp, #-8]
    // 0xd414a4: StoreField: r1->field_83 = r0
    //     0xd414a4: stur            w0, [x1, #0x83]
    //     0xd414a8: ldurb           w16, [x1, #-1]
    //     0xd414ac: ldurb           w17, [x0, #-1]
    //     0xd414b0: and             x16, x17, x16, lsr #2
    //     0xd414b4: tst             x16, HEAP, lsr #32
    //     0xd414b8: b.eq            #0xd414c0
    //     0xd414bc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd414c0: r0 = notifyListeners()
    //     0xd414c0: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd414c4: r0 = Null
    //     0xd414c4: mov             x0, NULL
    // 0xd414c8: LeaveFrame
    //     0xd414c8: mov             SP, fp
    //     0xd414cc: ldp             fp, lr, [SP], #0x10
    // 0xd414d0: ret
    //     0xd414d0: ret             
    // 0xd414d4: r0 = StackOverflowSharedWithFPURegs()
    //     0xd414d4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd414d8: b               #0xd41448
    // 0xd414dc: SaveReg d0
    //     0xd414dc: str             q0, [SP, #-0x10]!
    // 0xd414e0: stp             x0, x1, [SP, #-0x10]!
    // 0xd414e4: r0 = AllocateDouble()
    //     0xd414e4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd414e8: mov             x2, x0
    // 0xd414ec: ldp             x0, x1, [SP], #0x10
    // 0xd414f0: RestoreReg d0
    //     0xd414f0: ldr             q0, [SP], #0x10
    // 0xd414f4: b               #0xd41478
  }
  set _ inactiveThumbRadius=(/* No info */) {
    // ** addr: 0xd414f8, size: 0xcc
    // 0xd414f8: EnterFrame
    //     0xd414f8: stp             fp, lr, [SP, #-0x10]!
    //     0xd414fc: mov             fp, SP
    // 0xd41500: AllocStack(0x20)
    //     0xd41500: sub             SP, SP, #0x20
    // 0xd41504: SetupParameters(_SwitchPainter this /* r1 => r1, fp-0x10 */)
    //     0xd41504: stur            x1, [fp, #-0x10]
    // 0xd41508: CheckStackOverflow
    //     0xd41508: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4150c: cmp             SP, x16
    //     0xd41510: b.ls            #0xd415a0
    // 0xd41514: LoadField: r0 = r1->field_87
    //     0xd41514: ldur            w0, [x1, #0x87]
    // 0xd41518: DecompressPointer r0
    //     0xd41518: add             x0, x0, HEAP, lsl #32
    // 0xd4151c: r2 = inline_Allocate_Double()
    //     0xd4151c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xd41520: add             x2, x2, #0x10
    //     0xd41524: cmp             x3, x2
    //     0xd41528: b.ls            #0xd415a8
    //     0xd4152c: str             x2, [THR, #0x60]  ; THR::top
    //     0xd41530: sub             x2, x2, #0xf
    //     0xd41534: mov             x3, #0xe19c
    //     0xd41538: movk            x3, #3, lsl #16
    //     0xd4153c: stur            x3, [x2, #-1]
    // 0xd41540: dmb             ishst
    // 0xd41544: StoreField: r2->field_7 = d0
    //     0xd41544: stur            d0, [x2, #7]
    // 0xd41548: stur            x2, [fp, #-8]
    // 0xd4154c: stp             x0, x2, [SP]
    // 0xd41550: r0 = ==()
    //     0xd41550: bl              #0x12b7c00  ; [dart:core] _Double::==
    // 0xd41554: tbnz            w0, #4, #0xd41568
    // 0xd41558: r0 = Null
    //     0xd41558: mov             x0, NULL
    // 0xd4155c: LeaveFrame
    //     0xd4155c: mov             SP, fp
    //     0xd41560: ldp             fp, lr, [SP], #0x10
    // 0xd41564: ret
    //     0xd41564: ret             
    // 0xd41568: ldur            x1, [fp, #-0x10]
    // 0xd4156c: ldur            x0, [fp, #-8]
    // 0xd41570: StoreField: r1->field_87 = r0
    //     0xd41570: stur            w0, [x1, #0x87]
    //     0xd41574: ldurb           w16, [x1, #-1]
    //     0xd41578: ldurb           w17, [x0, #-1]
    //     0xd4157c: and             x16, x17, x16, lsr #2
    //     0xd41580: tst             x16, HEAP, lsr #32
    //     0xd41584: b.eq            #0xd4158c
    //     0xd41588: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd4158c: r0 = notifyListeners()
    //     0xd4158c: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd41590: r0 = Null
    //     0xd41590: mov             x0, NULL
    // 0xd41594: LeaveFrame
    //     0xd41594: mov             SP, fp
    //     0xd41598: ldp             fp, lr, [SP], #0x10
    // 0xd4159c: ret
    //     0xd4159c: ret             
    // 0xd415a0: r0 = StackOverflowSharedWithFPURegs()
    //     0xd415a0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd415a4: b               #0xd41514
    // 0xd415a8: SaveReg d0
    //     0xd415a8: str             q0, [SP, #-0x10]!
    // 0xd415ac: stp             x0, x1, [SP, #-0x10]!
    // 0xd415b0: r0 = AllocateDouble()
    //     0xd415b0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd415b4: mov             x2, x0
    // 0xd415b8: ldp             x0, x1, [SP], #0x10
    // 0xd415bc: RestoreReg d0
    //     0xd415bc: ldr             q0, [SP], #0x10
    // 0xd415c0: b               #0xd41544
  }
  set _ surfaceColor=(/* No info */) {
    // ** addr: 0xd415c4, size: 0xa4
    // 0xd415c4: EnterFrame
    //     0xd415c4: stp             fp, lr, [SP, #-0x10]!
    //     0xd415c8: mov             fp, SP
    // 0xd415cc: AllocStack(0x20)
    //     0xd415cc: sub             SP, SP, #0x20
    // 0xd415d0: SetupParameters(_SwitchPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd415d0: stur            x1, [fp, #-8]
    //     0xd415d4: mov             x16, x2
    //     0xd415d8: mov             x2, x1
    //     0xd415dc: mov             x1, x16
    //     0xd415e0: stur            x1, [fp, #-0x10]
    // 0xd415e4: CheckStackOverflow
    //     0xd415e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd415e8: cmp             SP, x16
    //     0xd415ec: b.ls            #0xd41660
    // 0xd415f0: LoadField: r0 = r2->field_cf
    //     0xd415f0: ldur            w0, [x2, #0xcf]
    // 0xd415f4: DecompressPointer r0
    //     0xd415f4: add             x0, x0, HEAP, lsl #32
    // 0xd415f8: r3 = LoadClassIdInstr(r1)
    //     0xd415f8: ldur            x3, [x1, #-1]
    //     0xd415fc: ubfx            x3, x3, #0xc, #0x14
    // 0xd41600: stp             x0, x1, [SP]
    // 0xd41604: mov             x0, x3
    // 0xd41608: mov             lr, x0
    // 0xd4160c: ldr             lr, [x21, lr, lsl #3]
    // 0xd41610: blr             lr
    // 0xd41614: tbnz            w0, #4, #0xd41628
    // 0xd41618: r0 = Null
    //     0xd41618: mov             x0, NULL
    // 0xd4161c: LeaveFrame
    //     0xd4161c: mov             SP, fp
    //     0xd41620: ldp             fp, lr, [SP], #0x10
    // 0xd41624: ret
    //     0xd41624: ret             
    // 0xd41628: ldur            x1, [fp, #-8]
    // 0xd4162c: ldur            x0, [fp, #-0x10]
    // 0xd41630: StoreField: r1->field_cf = r0
    //     0xd41630: stur            w0, [x1, #0xcf]
    //     0xd41634: ldurb           w16, [x1, #-1]
    //     0xd41638: ldurb           w17, [x0, #-1]
    //     0xd4163c: and             x16, x17, x16, lsr #2
    //     0xd41640: tst             x16, HEAP, lsr #32
    //     0xd41644: b.eq            #0xd4164c
    //     0xd41648: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd4164c: r0 = notifyListeners()
    //     0xd4164c: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd41650: r0 = Null
    //     0xd41650: mov             x0, NULL
    // 0xd41654: LeaveFrame
    //     0xd41654: mov             SP, fp
    //     0xd41658: ldp             fp, lr, [SP], #0x10
    // 0xd4165c: ret
    //     0xd4165c: ret             
    // 0xd41660: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd41660: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd41664: b               #0xd415f0
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0xd41668, size: 0x70
    // 0xd41668: EnterFrame
    //     0xd41668: stp             fp, lr, [SP, #-0x10]!
    //     0xd4166c: mov             fp, SP
    // 0xd41670: mov             x0, x2
    // 0xd41674: CheckStackOverflow
    //     0xd41674: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd41678: cmp             SP, x16
    //     0xd4167c: b.ls            #0xd416d0
    // 0xd41680: LoadField: r2 = r1->field_cb
    //     0xd41680: ldur            w2, [x1, #0xcb]
    // 0xd41684: DecompressPointer r2
    //     0xd41684: add             x2, x2, HEAP, lsl #32
    // 0xd41688: cmp             w2, w0
    // 0xd4168c: b.ne            #0xd416a0
    // 0xd41690: r0 = Null
    //     0xd41690: mov             x0, NULL
    // 0xd41694: LeaveFrame
    //     0xd41694: mov             SP, fp
    //     0xd41698: ldp             fp, lr, [SP], #0x10
    // 0xd4169c: ret
    //     0xd4169c: ret             
    // 0xd416a0: StoreField: r1->field_cb = r0
    //     0xd416a0: stur            w0, [x1, #0xcb]
    //     0xd416a4: ldurb           w16, [x1, #-1]
    //     0xd416a8: ldurb           w17, [x0, #-1]
    //     0xd416ac: and             x16, x17, x16, lsr #2
    //     0xd416b0: tst             x16, HEAP, lsr #32
    //     0xd416b4: b.eq            #0xd416bc
    //     0xd416b8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd416bc: r0 = notifyListeners()
    //     0xd416bc: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd416c0: r0 = Null
    //     0xd416c0: mov             x0, NULL
    // 0xd416c4: LeaveFrame
    //     0xd416c4: mov             SP, fp
    //     0xd416c8: ldp             fp, lr, [SP], #0x10
    // 0xd416cc: ret
    //     0xd416cc: ret             
    // 0xd416d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd416d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd416d4: b               #0xd41680
  }
  set _ trackInnerLength=(/* No info */) {
    // ** addr: 0xd416d8, size: 0xcc
    // 0xd416d8: EnterFrame
    //     0xd416d8: stp             fp, lr, [SP, #-0x10]!
    //     0xd416dc: mov             fp, SP
    // 0xd416e0: AllocStack(0x20)
    //     0xd416e0: sub             SP, SP, #0x20
    // 0xd416e4: SetupParameters(_SwitchPainter this /* r1 => r1, fp-0x10 */)
    //     0xd416e4: stur            x1, [fp, #-0x10]
    // 0xd416e8: CheckStackOverflow
    //     0xd416e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd416ec: cmp             SP, x16
    //     0xd416f0: b.ls            #0xd41780
    // 0xd416f4: LoadField: r0 = r1->field_d7
    //     0xd416f4: ldur            w0, [x1, #0xd7]
    // 0xd416f8: DecompressPointer r0
    //     0xd416f8: add             x0, x0, HEAP, lsl #32
    // 0xd416fc: r2 = inline_Allocate_Double()
    //     0xd416fc: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xd41700: add             x2, x2, #0x10
    //     0xd41704: cmp             x3, x2
    //     0xd41708: b.ls            #0xd41788
    //     0xd4170c: str             x2, [THR, #0x60]  ; THR::top
    //     0xd41710: sub             x2, x2, #0xf
    //     0xd41714: mov             x3, #0xe19c
    //     0xd41718: movk            x3, #3, lsl #16
    //     0xd4171c: stur            x3, [x2, #-1]
    // 0xd41720: dmb             ishst
    // 0xd41724: StoreField: r2->field_7 = d0
    //     0xd41724: stur            d0, [x2, #7]
    // 0xd41728: stur            x2, [fp, #-8]
    // 0xd4172c: stp             x0, x2, [SP]
    // 0xd41730: r0 = ==()
    //     0xd41730: bl              #0x12b7c00  ; [dart:core] _Double::==
    // 0xd41734: tbnz            w0, #4, #0xd41748
    // 0xd41738: r0 = Null
    //     0xd41738: mov             x0, NULL
    // 0xd4173c: LeaveFrame
    //     0xd4173c: mov             SP, fp
    //     0xd41740: ldp             fp, lr, [SP], #0x10
    // 0xd41744: ret
    //     0xd41744: ret             
    // 0xd41748: ldur            x1, [fp, #-0x10]
    // 0xd4174c: ldur            x0, [fp, #-8]
    // 0xd41750: StoreField: r1->field_d7 = r0
    //     0xd41750: stur            w0, [x1, #0xd7]
    //     0xd41754: ldurb           w16, [x1, #-1]
    //     0xd41758: ldurb           w17, [x0, #-1]
    //     0xd4175c: and             x16, x17, x16, lsr #2
    //     0xd41760: tst             x16, HEAP, lsr #32
    //     0xd41764: b.eq            #0xd4176c
    //     0xd41768: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd4176c: r0 = notifyListeners()
    //     0xd4176c: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd41770: r0 = Null
    //     0xd41770: mov             x0, NULL
    // 0xd41774: LeaveFrame
    //     0xd41774: mov             SP, fp
    //     0xd41778: ldp             fp, lr, [SP], #0x10
    // 0xd4177c: ret
    //     0xd4177c: ret             
    // 0xd41780: r0 = StackOverflowSharedWithFPURegs()
    //     0xd41780: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd41784: b               #0xd416f4
    // 0xd41788: SaveReg d0
    //     0xd41788: str             q0, [SP, #-0x10]!
    // 0xd4178c: stp             x0, x1, [SP, #-0x10]!
    // 0xd41790: r0 = AllocateDouble()
    //     0xd41790: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd41794: mov             x2, x0
    // 0xd41798: ldp             x0, x1, [SP], #0x10
    // 0xd4179c: RestoreReg d0
    //     0xd4179c: ldr             q0, [SP], #0x10
    // 0xd417a0: b               #0xd41724
  }
  set _ isInteractive=(/* No info */) {
    // ** addr: 0xd41a64, size: 0x5c
    // 0xd41a64: EnterFrame
    //     0xd41a64: stp             fp, lr, [SP, #-0x10]!
    //     0xd41a68: mov             fp, SP
    // 0xd41a6c: CheckStackOverflow
    //     0xd41a6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd41a70: cmp             SP, x16
    //     0xd41a74: b.ls            #0xd41ab8
    // 0xd41a78: LoadField: r0 = r1->field_d3
    //     0xd41a78: ldur            w0, [x1, #0xd3]
    // 0xd41a7c: DecompressPointer r0
    //     0xd41a7c: add             x0, x0, HEAP, lsl #32
    // 0xd41a80: r16 = true
    //     0xd41a80: add             x16, NULL, #0x20  ; true
    // 0xd41a84: cmp             w0, w16
    // 0xd41a88: b.ne            #0xd41a9c
    // 0xd41a8c: r0 = Null
    //     0xd41a8c: mov             x0, NULL
    // 0xd41a90: LeaveFrame
    //     0xd41a90: mov             SP, fp
    //     0xd41a94: ldp             fp, lr, [SP], #0x10
    // 0xd41a98: ret
    //     0xd41a98: ret             
    // 0xd41a9c: r0 = true
    //     0xd41a9c: add             x0, NULL, #0x20  ; true
    // 0xd41aa0: StoreField: r1->field_d3 = r0
    //     0xd41aa0: stur            w0, [x1, #0xd3]
    // 0xd41aa4: r0 = notifyListeners()
    //     0xd41aa4: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd41aa8: r0 = Null
    //     0xd41aa8: mov             x0, NULL
    // 0xd41aac: LeaveFrame
    //     0xd41aac: mov             SP, fp
    //     0xd41ab0: ldp             fp, lr, [SP], #0x10
    // 0xd41ab4: ret
    //     0xd41ab4: ret             
    // 0xd41ab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd41ab8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd41abc: b               #0xd41a78
  }
  set _ configuration=(/* No info */) {
    // ** addr: 0xd41ac0, size: 0x88
    // 0xd41ac0: EnterFrame
    //     0xd41ac0: stp             fp, lr, [SP, #-0x10]!
    //     0xd41ac4: mov             fp, SP
    // 0xd41ac8: AllocStack(0x20)
    //     0xd41ac8: sub             SP, SP, #0x20
    // 0xd41acc: SetupParameters(_SwitchPainter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xd41acc: mov             x0, x2
    //     0xd41ad0: stur            x1, [fp, #-8]
    //     0xd41ad4: stur            x2, [fp, #-0x10]
    // 0xd41ad8: CheckStackOverflow
    //     0xd41ad8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd41adc: cmp             SP, x16
    //     0xd41ae0: b.ls            #0xd41b40
    // 0xd41ae4: LoadField: r2 = r1->field_c7
    //     0xd41ae4: ldur            w2, [x1, #0xc7]
    // 0xd41ae8: DecompressPointer r2
    //     0xd41ae8: add             x2, x2, HEAP, lsl #32
    // 0xd41aec: stp             x2, x0, [SP]
    // 0xd41af0: r0 = ==()
    //     0xd41af0: bl              #0x1299204  ; [package:flutter/src/painting/image_provider.dart] ImageConfiguration::==
    // 0xd41af4: tbnz            w0, #4, #0xd41b08
    // 0xd41af8: r0 = Null
    //     0xd41af8: mov             x0, NULL
    // 0xd41afc: LeaveFrame
    //     0xd41afc: mov             SP, fp
    //     0xd41b00: ldp             fp, lr, [SP], #0x10
    // 0xd41b04: ret
    //     0xd41b04: ret             
    // 0xd41b08: ldur            x1, [fp, #-8]
    // 0xd41b0c: ldur            x0, [fp, #-0x10]
    // 0xd41b10: StoreField: r1->field_c7 = r0
    //     0xd41b10: stur            w0, [x1, #0xc7]
    //     0xd41b14: ldurb           w16, [x1, #-1]
    //     0xd41b18: ldurb           w17, [x0, #-1]
    //     0xd41b1c: and             x16, x17, x16, lsr #2
    //     0xd41b20: tst             x16, HEAP, lsr #32
    //     0xd41b24: b.eq            #0xd41b2c
    //     0xd41b28: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd41b2c: r0 = notifyListeners()
    //     0xd41b2c: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd41b30: r0 = Null
    //     0xd41b30: mov             x0, NULL
    // 0xd41b34: LeaveFrame
    //     0xd41b34: mov             SP, fp
    //     0xd41b38: ldp             fp, lr, [SP], #0x10
    // 0xd41b3c: ret
    //     0xd41b3c: ret             
    // 0xd41b40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd41b40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd41b44: b               #0xd41ae4
  }
  set _ inactiveTrackOutlineWidth=(/* No info */) {
    // ** addr: 0xd41b48, size: 0xa4
    // 0xd41b48: EnterFrame
    //     0xd41b48: stp             fp, lr, [SP, #-0x10]!
    //     0xd41b4c: mov             fp, SP
    // 0xd41b50: AllocStack(0x20)
    //     0xd41b50: sub             SP, SP, #0x20
    // 0xd41b54: SetupParameters(_SwitchPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd41b54: stur            x1, [fp, #-8]
    //     0xd41b58: mov             x16, x2
    //     0xd41b5c: mov             x2, x1
    //     0xd41b60: mov             x1, x16
    //     0xd41b64: stur            x1, [fp, #-0x10]
    // 0xd41b68: CheckStackOverflow
    //     0xd41b68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd41b6c: cmp             SP, x16
    //     0xd41b70: b.ls            #0xd41be4
    // 0xd41b74: LoadField: r0 = r2->field_bf
    //     0xd41b74: ldur            w0, [x2, #0xbf]
    // 0xd41b78: DecompressPointer r0
    //     0xd41b78: add             x0, x0, HEAP, lsl #32
    // 0xd41b7c: r3 = LoadClassIdInstr(r1)
    //     0xd41b7c: ldur            x3, [x1, #-1]
    //     0xd41b80: ubfx            x3, x3, #0xc, #0x14
    // 0xd41b84: stp             x0, x1, [SP]
    // 0xd41b88: mov             x0, x3
    // 0xd41b8c: mov             lr, x0
    // 0xd41b90: ldr             lr, [x21, lr, lsl #3]
    // 0xd41b94: blr             lr
    // 0xd41b98: tbnz            w0, #4, #0xd41bac
    // 0xd41b9c: r0 = Null
    //     0xd41b9c: mov             x0, NULL
    // 0xd41ba0: LeaveFrame
    //     0xd41ba0: mov             SP, fp
    //     0xd41ba4: ldp             fp, lr, [SP], #0x10
    // 0xd41ba8: ret
    //     0xd41ba8: ret             
    // 0xd41bac: ldur            x1, [fp, #-8]
    // 0xd41bb0: ldur            x0, [fp, #-0x10]
    // 0xd41bb4: StoreField: r1->field_bf = r0
    //     0xd41bb4: stur            w0, [x1, #0xbf]
    //     0xd41bb8: ldurb           w16, [x1, #-1]
    //     0xd41bbc: ldurb           w17, [x0, #-1]
    //     0xd41bc0: and             x16, x17, x16, lsr #2
    //     0xd41bc4: tst             x16, HEAP, lsr #32
    //     0xd41bc8: b.eq            #0xd41bd0
    //     0xd41bcc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd41bd0: r0 = notifyListeners()
    //     0xd41bd0: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd41bd4: r0 = Null
    //     0xd41bd4: mov             x0, NULL
    // 0xd41bd8: LeaveFrame
    //     0xd41bd8: mov             SP, fp
    //     0xd41bdc: ldp             fp, lr, [SP], #0x10
    // 0xd41be0: ret
    //     0xd41be0: ret             
    // 0xd41be4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd41be4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd41be8: b               #0xd41b74
  }
  set _ inactiveTrackOutlineColor=(/* No info */) {
    // ** addr: 0xd41bec, size: 0xa4
    // 0xd41bec: EnterFrame
    //     0xd41bec: stp             fp, lr, [SP, #-0x10]!
    //     0xd41bf0: mov             fp, SP
    // 0xd41bf4: AllocStack(0x20)
    //     0xd41bf4: sub             SP, SP, #0x20
    // 0xd41bf8: SetupParameters(_SwitchPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd41bf8: stur            x1, [fp, #-8]
    //     0xd41bfc: mov             x16, x2
    //     0xd41c00: mov             x2, x1
    //     0xd41c04: mov             x1, x16
    //     0xd41c08: stur            x1, [fp, #-0x10]
    // 0xd41c0c: CheckStackOverflow
    //     0xd41c0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd41c10: cmp             SP, x16
    //     0xd41c14: b.ls            #0xd41c88
    // 0xd41c18: LoadField: r0 = r2->field_b7
    //     0xd41c18: ldur            w0, [x2, #0xb7]
    // 0xd41c1c: DecompressPointer r0
    //     0xd41c1c: add             x0, x0, HEAP, lsl #32
    // 0xd41c20: r3 = LoadClassIdInstr(r1)
    //     0xd41c20: ldur            x3, [x1, #-1]
    //     0xd41c24: ubfx            x3, x3, #0xc, #0x14
    // 0xd41c28: stp             x0, x1, [SP]
    // 0xd41c2c: mov             x0, x3
    // 0xd41c30: mov             lr, x0
    // 0xd41c34: ldr             lr, [x21, lr, lsl #3]
    // 0xd41c38: blr             lr
    // 0xd41c3c: tbnz            w0, #4, #0xd41c50
    // 0xd41c40: r0 = Null
    //     0xd41c40: mov             x0, NULL
    // 0xd41c44: LeaveFrame
    //     0xd41c44: mov             SP, fp
    //     0xd41c48: ldp             fp, lr, [SP], #0x10
    // 0xd41c4c: ret
    //     0xd41c4c: ret             
    // 0xd41c50: ldur            x1, [fp, #-8]
    // 0xd41c54: ldur            x0, [fp, #-0x10]
    // 0xd41c58: StoreField: r1->field_b7 = r0
    //     0xd41c58: stur            w0, [x1, #0xb7]
    //     0xd41c5c: ldurb           w16, [x1, #-1]
    //     0xd41c60: ldurb           w17, [x0, #-1]
    //     0xd41c64: and             x16, x17, x16, lsr #2
    //     0xd41c68: tst             x16, HEAP, lsr #32
    //     0xd41c6c: b.eq            #0xd41c74
    //     0xd41c70: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd41c74: r0 = notifyListeners()
    //     0xd41c74: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd41c78: r0 = Null
    //     0xd41c78: mov             x0, NULL
    // 0xd41c7c: LeaveFrame
    //     0xd41c7c: mov             SP, fp
    //     0xd41c80: ldp             fp, lr, [SP], #0x10
    // 0xd41c84: ret
    //     0xd41c84: ret             
    // 0xd41c88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd41c88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd41c8c: b               #0xd41c18
  }
  set _ inactiveTrackColor=(/* No info */) {
    // ** addr: 0xd41c90, size: 0xa4
    // 0xd41c90: EnterFrame
    //     0xd41c90: stp             fp, lr, [SP, #-0x10]!
    //     0xd41c94: mov             fp, SP
    // 0xd41c98: AllocStack(0x20)
    //     0xd41c98: sub             SP, SP, #0x20
    // 0xd41c9c: SetupParameters(_SwitchPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd41c9c: stur            x1, [fp, #-8]
    //     0xd41ca0: mov             x16, x2
    //     0xd41ca4: mov             x2, x1
    //     0xd41ca8: mov             x1, x16
    //     0xd41cac: stur            x1, [fp, #-0x10]
    // 0xd41cb0: CheckStackOverflow
    //     0xd41cb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd41cb4: cmp             SP, x16
    //     0xd41cb8: b.ls            #0xd41d2c
    // 0xd41cbc: LoadField: r0 = r2->field_c3
    //     0xd41cbc: ldur            w0, [x2, #0xc3]
    // 0xd41cc0: DecompressPointer r0
    //     0xd41cc0: add             x0, x0, HEAP, lsl #32
    // 0xd41cc4: r3 = LoadClassIdInstr(r1)
    //     0xd41cc4: ldur            x3, [x1, #-1]
    //     0xd41cc8: ubfx            x3, x3, #0xc, #0x14
    // 0xd41ccc: stp             x0, x1, [SP]
    // 0xd41cd0: mov             x0, x3
    // 0xd41cd4: mov             lr, x0
    // 0xd41cd8: ldr             lr, [x21, lr, lsl #3]
    // 0xd41cdc: blr             lr
    // 0xd41ce0: tbnz            w0, #4, #0xd41cf4
    // 0xd41ce4: r0 = Null
    //     0xd41ce4: mov             x0, NULL
    // 0xd41ce8: LeaveFrame
    //     0xd41ce8: mov             SP, fp
    //     0xd41cec: ldp             fp, lr, [SP], #0x10
    // 0xd41cf0: ret
    //     0xd41cf0: ret             
    // 0xd41cf4: ldur            x1, [fp, #-8]
    // 0xd41cf8: ldur            x0, [fp, #-0x10]
    // 0xd41cfc: StoreField: r1->field_c3 = r0
    //     0xd41cfc: stur            w0, [x1, #0xc3]
    //     0xd41d00: ldurb           w16, [x1, #-1]
    //     0xd41d04: ldurb           w17, [x0, #-1]
    //     0xd41d08: and             x16, x17, x16, lsr #2
    //     0xd41d0c: tst             x16, HEAP, lsr #32
    //     0xd41d10: b.eq            #0xd41d18
    //     0xd41d14: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd41d18: r0 = notifyListeners()
    //     0xd41d18: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd41d1c: r0 = Null
    //     0xd41d1c: mov             x0, NULL
    // 0xd41d20: LeaveFrame
    //     0xd41d20: mov             SP, fp
    //     0xd41d24: ldp             fp, lr, [SP], #0x10
    // 0xd41d28: ret
    //     0xd41d28: ret             
    // 0xd41d2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd41d2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd41d30: b               #0xd41cbc
  }
  set _ activeTrackOutlineWidth=(/* No info */) {
    // ** addr: 0xd41d34, size: 0xa4
    // 0xd41d34: EnterFrame
    //     0xd41d34: stp             fp, lr, [SP, #-0x10]!
    //     0xd41d38: mov             fp, SP
    // 0xd41d3c: AllocStack(0x20)
    //     0xd41d3c: sub             SP, SP, #0x20
    // 0xd41d40: SetupParameters(_SwitchPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd41d40: stur            x1, [fp, #-8]
    //     0xd41d44: mov             x16, x2
    //     0xd41d48: mov             x2, x1
    //     0xd41d4c: mov             x1, x16
    //     0xd41d50: stur            x1, [fp, #-0x10]
    // 0xd41d54: CheckStackOverflow
    //     0xd41d54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd41d58: cmp             SP, x16
    //     0xd41d5c: b.ls            #0xd41dd0
    // 0xd41d60: LoadField: r0 = r2->field_bb
    //     0xd41d60: ldur            w0, [x2, #0xbb]
    // 0xd41d64: DecompressPointer r0
    //     0xd41d64: add             x0, x0, HEAP, lsl #32
    // 0xd41d68: r3 = LoadClassIdInstr(r1)
    //     0xd41d68: ldur            x3, [x1, #-1]
    //     0xd41d6c: ubfx            x3, x3, #0xc, #0x14
    // 0xd41d70: stp             x0, x1, [SP]
    // 0xd41d74: mov             x0, x3
    // 0xd41d78: mov             lr, x0
    // 0xd41d7c: ldr             lr, [x21, lr, lsl #3]
    // 0xd41d80: blr             lr
    // 0xd41d84: tbnz            w0, #4, #0xd41d98
    // 0xd41d88: r0 = Null
    //     0xd41d88: mov             x0, NULL
    // 0xd41d8c: LeaveFrame
    //     0xd41d8c: mov             SP, fp
    //     0xd41d90: ldp             fp, lr, [SP], #0x10
    // 0xd41d94: ret
    //     0xd41d94: ret             
    // 0xd41d98: ldur            x1, [fp, #-8]
    // 0xd41d9c: ldur            x0, [fp, #-0x10]
    // 0xd41da0: StoreField: r1->field_bb = r0
    //     0xd41da0: stur            w0, [x1, #0xbb]
    //     0xd41da4: ldurb           w16, [x1, #-1]
    //     0xd41da8: ldurb           w17, [x0, #-1]
    //     0xd41dac: and             x16, x17, x16, lsr #2
    //     0xd41db0: tst             x16, HEAP, lsr #32
    //     0xd41db4: b.eq            #0xd41dbc
    //     0xd41db8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd41dbc: r0 = notifyListeners()
    //     0xd41dbc: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd41dc0: r0 = Null
    //     0xd41dc0: mov             x0, NULL
    // 0xd41dc4: LeaveFrame
    //     0xd41dc4: mov             SP, fp
    //     0xd41dc8: ldp             fp, lr, [SP], #0x10
    // 0xd41dcc: ret
    //     0xd41dcc: ret             
    // 0xd41dd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd41dd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd41dd4: b               #0xd41d60
  }
  set _ activeTrackOutlineColor=(/* No info */) {
    // ** addr: 0xd41dd8, size: 0xa4
    // 0xd41dd8: EnterFrame
    //     0xd41dd8: stp             fp, lr, [SP, #-0x10]!
    //     0xd41ddc: mov             fp, SP
    // 0xd41de0: AllocStack(0x20)
    //     0xd41de0: sub             SP, SP, #0x20
    // 0xd41de4: SetupParameters(_SwitchPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd41de4: stur            x1, [fp, #-8]
    //     0xd41de8: mov             x16, x2
    //     0xd41dec: mov             x2, x1
    //     0xd41df0: mov             x1, x16
    //     0xd41df4: stur            x1, [fp, #-0x10]
    // 0xd41df8: CheckStackOverflow
    //     0xd41df8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd41dfc: cmp             SP, x16
    //     0xd41e00: b.ls            #0xd41e74
    // 0xd41e04: LoadField: r0 = r2->field_b3
    //     0xd41e04: ldur            w0, [x2, #0xb3]
    // 0xd41e08: DecompressPointer r0
    //     0xd41e08: add             x0, x0, HEAP, lsl #32
    // 0xd41e0c: r3 = LoadClassIdInstr(r1)
    //     0xd41e0c: ldur            x3, [x1, #-1]
    //     0xd41e10: ubfx            x3, x3, #0xc, #0x14
    // 0xd41e14: stp             x0, x1, [SP]
    // 0xd41e18: mov             x0, x3
    // 0xd41e1c: mov             lr, x0
    // 0xd41e20: ldr             lr, [x21, lr, lsl #3]
    // 0xd41e24: blr             lr
    // 0xd41e28: tbnz            w0, #4, #0xd41e3c
    // 0xd41e2c: r0 = Null
    //     0xd41e2c: mov             x0, NULL
    // 0xd41e30: LeaveFrame
    //     0xd41e30: mov             SP, fp
    //     0xd41e34: ldp             fp, lr, [SP], #0x10
    // 0xd41e38: ret
    //     0xd41e38: ret             
    // 0xd41e3c: ldur            x1, [fp, #-8]
    // 0xd41e40: ldur            x0, [fp, #-0x10]
    // 0xd41e44: StoreField: r1->field_b3 = r0
    //     0xd41e44: stur            w0, [x1, #0xb3]
    //     0xd41e48: ldurb           w16, [x1, #-1]
    //     0xd41e4c: ldurb           w17, [x0, #-1]
    //     0xd41e50: and             x16, x17, x16, lsr #2
    //     0xd41e54: tst             x16, HEAP, lsr #32
    //     0xd41e58: b.eq            #0xd41e60
    //     0xd41e5c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd41e60: r0 = notifyListeners()
    //     0xd41e60: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd41e64: r0 = Null
    //     0xd41e64: mov             x0, NULL
    // 0xd41e68: LeaveFrame
    //     0xd41e68: mov             SP, fp
    //     0xd41e6c: ldp             fp, lr, [SP], #0x10
    // 0xd41e70: ret
    //     0xd41e70: ret             
    // 0xd41e74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd41e74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd41e78: b               #0xd41e04
  }
  set _ activeTrackColor=(/* No info */) {
    // ** addr: 0xd41e7c, size: 0xa4
    // 0xd41e7c: EnterFrame
    //     0xd41e7c: stp             fp, lr, [SP, #-0x10]!
    //     0xd41e80: mov             fp, SP
    // 0xd41e84: AllocStack(0x20)
    //     0xd41e84: sub             SP, SP, #0x20
    // 0xd41e88: SetupParameters(_SwitchPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd41e88: stur            x1, [fp, #-8]
    //     0xd41e8c: mov             x16, x2
    //     0xd41e90: mov             x2, x1
    //     0xd41e94: mov             x1, x16
    //     0xd41e98: stur            x1, [fp, #-0x10]
    // 0xd41e9c: CheckStackOverflow
    //     0xd41e9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd41ea0: cmp             SP, x16
    //     0xd41ea4: b.ls            #0xd41f18
    // 0xd41ea8: LoadField: r0 = r2->field_af
    //     0xd41ea8: ldur            w0, [x2, #0xaf]
    // 0xd41eac: DecompressPointer r0
    //     0xd41eac: add             x0, x0, HEAP, lsl #32
    // 0xd41eb0: r3 = LoadClassIdInstr(r1)
    //     0xd41eb0: ldur            x3, [x1, #-1]
    //     0xd41eb4: ubfx            x3, x3, #0xc, #0x14
    // 0xd41eb8: stp             x0, x1, [SP]
    // 0xd41ebc: mov             x0, x3
    // 0xd41ec0: mov             lr, x0
    // 0xd41ec4: ldr             lr, [x21, lr, lsl #3]
    // 0xd41ec8: blr             lr
    // 0xd41ecc: tbnz            w0, #4, #0xd41ee0
    // 0xd41ed0: r0 = Null
    //     0xd41ed0: mov             x0, NULL
    // 0xd41ed4: LeaveFrame
    //     0xd41ed4: mov             SP, fp
    //     0xd41ed8: ldp             fp, lr, [SP], #0x10
    // 0xd41edc: ret
    //     0xd41edc: ret             
    // 0xd41ee0: ldur            x1, [fp, #-8]
    // 0xd41ee4: ldur            x0, [fp, #-0x10]
    // 0xd41ee8: StoreField: r1->field_af = r0
    //     0xd41ee8: stur            w0, [x1, #0xaf]
    //     0xd41eec: ldurb           w16, [x1, #-1]
    //     0xd41ef0: ldurb           w17, [x0, #-1]
    //     0xd41ef4: and             x16, x17, x16, lsr #2
    //     0xd41ef8: tst             x16, HEAP, lsr #32
    //     0xd41efc: b.eq            #0xd41f04
    //     0xd41f00: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd41f04: r0 = notifyListeners()
    //     0xd41f04: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd41f08: r0 = Null
    //     0xd41f08: mov             x0, NULL
    // 0xd41f0c: LeaveFrame
    //     0xd41f0c: mov             SP, fp
    //     0xd41f10: ldp             fp, lr, [SP], #0x10
    // 0xd41f14: ret
    //     0xd41f14: ret             
    // 0xd41f18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd41f18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd41f1c: b               #0xd41ea8
  }
  set _ inactivePressedColor=(/* No info */) {
    // ** addr: 0xd41f20, size: 0xa4
    // 0xd41f20: EnterFrame
    //     0xd41f20: stp             fp, lr, [SP, #-0x10]!
    //     0xd41f24: mov             fp, SP
    // 0xd41f28: AllocStack(0x20)
    //     0xd41f28: sub             SP, SP, #0x20
    // 0xd41f2c: SetupParameters(_SwitchPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd41f2c: stur            x1, [fp, #-8]
    //     0xd41f30: mov             x16, x2
    //     0xd41f34: mov             x2, x1
    //     0xd41f38: mov             x1, x16
    //     0xd41f3c: stur            x1, [fp, #-0x10]
    // 0xd41f40: CheckStackOverflow
    //     0xd41f40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd41f44: cmp             SP, x16
    //     0xd41f48: b.ls            #0xd41fbc
    // 0xd41f4c: LoadField: r0 = r2->field_7f
    //     0xd41f4c: ldur            w0, [x2, #0x7f]
    // 0xd41f50: DecompressPointer r0
    //     0xd41f50: add             x0, x0, HEAP, lsl #32
    // 0xd41f54: r3 = LoadClassIdInstr(r1)
    //     0xd41f54: ldur            x3, [x1, #-1]
    //     0xd41f58: ubfx            x3, x3, #0xc, #0x14
    // 0xd41f5c: stp             x0, x1, [SP]
    // 0xd41f60: mov             x0, x3
    // 0xd41f64: mov             lr, x0
    // 0xd41f68: ldr             lr, [x21, lr, lsl #3]
    // 0xd41f6c: blr             lr
    // 0xd41f70: tbnz            w0, #4, #0xd41f84
    // 0xd41f74: r0 = Null
    //     0xd41f74: mov             x0, NULL
    // 0xd41f78: LeaveFrame
    //     0xd41f78: mov             SP, fp
    //     0xd41f7c: ldp             fp, lr, [SP], #0x10
    // 0xd41f80: ret
    //     0xd41f80: ret             
    // 0xd41f84: ldur            x1, [fp, #-8]
    // 0xd41f88: ldur            x0, [fp, #-0x10]
    // 0xd41f8c: StoreField: r1->field_7f = r0
    //     0xd41f8c: stur            w0, [x1, #0x7f]
    //     0xd41f90: ldurb           w16, [x1, #-1]
    //     0xd41f94: ldurb           w17, [x0, #-1]
    //     0xd41f98: and             x16, x17, x16, lsr #2
    //     0xd41f9c: tst             x16, HEAP, lsr #32
    //     0xd41fa0: b.eq            #0xd41fa8
    //     0xd41fa4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd41fa8: r0 = notifyListeners()
    //     0xd41fa8: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd41fac: r0 = Null
    //     0xd41fac: mov             x0, NULL
    // 0xd41fb0: LeaveFrame
    //     0xd41fb0: mov             SP, fp
    //     0xd41fb4: ldp             fp, lr, [SP], #0x10
    // 0xd41fb8: ret
    //     0xd41fb8: ret             
    // 0xd41fbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd41fbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd41fc0: b               #0xd41f4c
  }
  set _ activePressedColor=(/* No info */) {
    // ** addr: 0xd41fc4, size: 0xa4
    // 0xd41fc4: EnterFrame
    //     0xd41fc4: stp             fp, lr, [SP, #-0x10]!
    //     0xd41fc8: mov             fp, SP
    // 0xd41fcc: AllocStack(0x20)
    //     0xd41fcc: sub             SP, SP, #0x20
    // 0xd41fd0: SetupParameters(_SwitchPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd41fd0: stur            x1, [fp, #-8]
    //     0xd41fd4: mov             x16, x2
    //     0xd41fd8: mov             x2, x1
    //     0xd41fdc: mov             x1, x16
    //     0xd41fe0: stur            x1, [fp, #-0x10]
    // 0xd41fe4: CheckStackOverflow
    //     0xd41fe4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd41fe8: cmp             SP, x16
    //     0xd41fec: b.ls            #0xd42060
    // 0xd41ff0: LoadField: r0 = r2->field_7b
    //     0xd41ff0: ldur            w0, [x2, #0x7b]
    // 0xd41ff4: DecompressPointer r0
    //     0xd41ff4: add             x0, x0, HEAP, lsl #32
    // 0xd41ff8: r3 = LoadClassIdInstr(r1)
    //     0xd41ff8: ldur            x3, [x1, #-1]
    //     0xd41ffc: ubfx            x3, x3, #0xc, #0x14
    // 0xd42000: stp             x0, x1, [SP]
    // 0xd42004: mov             x0, x3
    // 0xd42008: mov             lr, x0
    // 0xd4200c: ldr             lr, [x21, lr, lsl #3]
    // 0xd42010: blr             lr
    // 0xd42014: tbnz            w0, #4, #0xd42028
    // 0xd42018: r0 = Null
    //     0xd42018: mov             x0, NULL
    // 0xd4201c: LeaveFrame
    //     0xd4201c: mov             SP, fp
    //     0xd42020: ldp             fp, lr, [SP], #0x10
    // 0xd42024: ret
    //     0xd42024: ret             
    // 0xd42028: ldur            x1, [fp, #-8]
    // 0xd4202c: ldur            x0, [fp, #-0x10]
    // 0xd42030: StoreField: r1->field_7b = r0
    //     0xd42030: stur            w0, [x1, #0x7b]
    //     0xd42034: ldurb           w16, [x1, #-1]
    //     0xd42038: ldurb           w17, [x0, #-1]
    //     0xd4203c: and             x16, x17, x16, lsr #2
    //     0xd42040: tst             x16, HEAP, lsr #32
    //     0xd42044: b.eq            #0xd4204c
    //     0xd42048: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd4204c: r0 = notifyListeners()
    //     0xd4204c: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd42050: r0 = Null
    //     0xd42050: mov             x0, NULL
    // 0xd42054: LeaveFrame
    //     0xd42054: mov             SP, fp
    //     0xd42058: ldp             fp, lr, [SP], #0x10
    // 0xd4205c: ret
    //     0xd4205c: ret             
    // 0xd42060: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd42060: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd42064: b               #0xd41ff0
  }
  _ _SwitchPainter(/* No info */) {
    // ** addr: 0xfa30c4, size: 0xcc
    // 0xfa30c4: EnterFrame
    //     0xfa30c4: stp             fp, lr, [SP, #-0x10]!
    //     0xfa30c8: mov             fp, SP
    // 0xfa30cc: AllocStack(0x10)
    //     0xfa30cc: sub             SP, SP, #0x10
    // 0xfa30d0: r2 = false
    //     0xfa30d0: add             x2, NULL, #0x30  ; false
    // 0xfa30d4: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa30d8: stur            x1, [fp, #-8]
    // 0xfa30dc: CheckStackOverflow
    //     0xfa30dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa30e0: cmp             SP, x16
    //     0xfa30e4: b.ls            #0xfa3188
    // 0xfa30e8: StoreField: r1->field_f7 = r2
    //     0xfa30e8: stur            w2, [x1, #0xf7]
    // 0xfa30ec: StoreField: r1->field_fb = r2
    //     0xfa30ec: stur            w2, [x1, #0xfb]
    // 0xfa30f0: r17 = 263
    //     0xfa30f0: mov             x17, #0x107
    // 0xfa30f4: str             w0, [x1, x17]
    // 0xfa30f8: r0 = TextPainter()
    //     0xfa30f8: bl              #0xb13a1c  ; AllocateTextPainterStub -> TextPainter (size=0x48)
    // 0xfa30fc: mov             x1, x0
    // 0xfa3100: stur            x0, [fp, #-0x10]
    // 0xfa3104: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xfa3104: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xfa3108: r0 = TextPainter()
    //     0xfa3108: bl              #0xb135d4  ; [package:flutter/src/painting/text_painter.dart] TextPainter::TextPainter
    // 0xfa310c: ldur            x0, [fp, #-0x10]
    // 0xfa3110: ldur            x1, [fp, #-8]
    // 0xfa3114: StoreField: r1->field_e3 = r0
    //     0xfa3114: stur            w0, [x1, #0xe3]
    //     0xfa3118: ldurb           w16, [x1, #-1]
    //     0xfa311c: ldurb           w17, [x0, #-1]
    //     0xfa3120: and             x16, x17, x16, lsr #2
    //     0xfa3124: tst             x16, HEAP, lsr #32
    //     0xfa3128: b.eq            #0xfa3130
    //     0xfa312c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa3130: StoreField: r1->field_7 = rZR
    //     0xfa3130: stur            xzr, [x1, #7]
    // 0xfa3134: StoreField: r1->field_13 = rZR
    //     0xfa3134: stur            xzr, [x1, #0x13]
    // 0xfa3138: StoreField: r1->field_1b = rZR
    //     0xfa3138: stur            xzr, [x1, #0x1b]
    // 0xfa313c: r0 = LoadStaticField(0x45c)
    //     0xfa313c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfa3140: ldr             x0, [x0, #0x8b8]
    // 0xfa3144: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa3148: cmp             w0, w16
    // 0xfa314c: b.ne            #0xfa3158
    // 0xfa3150: r2 = _emptyListeners
    //     0xfa3150: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xfa3154: r0 = InitLateFinalStaticField()
    //     0xfa3154: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xfa3158: ldur            x1, [fp, #-8]
    // 0xfa315c: StoreField: r1->field_f = r0
    //     0xfa315c: stur            w0, [x1, #0xf]
    //     0xfa3160: ldurb           w16, [x1, #-1]
    //     0xfa3164: ldurb           w17, [x0, #-1]
    //     0xfa3168: and             x16, x17, x16, lsr #2
    //     0xfa316c: tst             x16, HEAP, lsr #32
    //     0xfa3170: b.eq            #0xfa3178
    //     0xfa3174: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa3178: r0 = Null
    //     0xfa3178: mov             x0, NULL
    // 0xfa317c: LeaveFrame
    //     0xfa317c: mov             SP, fp
    //     0xfa3180: ldp             fp, lr, [SP], #0x10
    // 0xfa3184: ret
    //     0xfa3184: ret             
    // 0xfa3188: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa3188: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa318c: b               #0xfa30e8
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10ef044, size: 0x8c
    // 0x10ef044: EnterFrame
    //     0x10ef044: stp             fp, lr, [SP, #-0x10]!
    //     0x10ef048: mov             fp, SP
    // 0x10ef04c: AllocStack(0x8)
    //     0x10ef04c: sub             SP, SP, #8
    // 0x10ef050: SetupParameters(_SwitchPainter this /* r1 => r0, fp-0x8 */)
    //     0x10ef050: mov             x0, x1
    //     0x10ef054: stur            x1, [fp, #-8]
    // 0x10ef058: CheckStackOverflow
    //     0x10ef058: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ef05c: cmp             SP, x16
    //     0x10ef060: b.ls            #0x10ef0c8
    // 0x10ef064: LoadField: r1 = r0->field_e3
    //     0x10ef064: ldur            w1, [x0, #0xe3]
    // 0x10ef068: DecompressPointer r1
    //     0x10ef068: add             x1, x1, HEAP, lsl #32
    // 0x10ef06c: r0 = dispose()
    //     0x10ef06c: bl              #0xbcb780  ; [package:flutter/src/painting/text_painter.dart] TextPainter::dispose
    // 0x10ef070: ldur            x0, [fp, #-8]
    // 0x10ef074: LoadField: r1 = r0->field_f3
    //     0x10ef074: ldur            w1, [x0, #0xf3]
    // 0x10ef078: DecompressPointer r1
    //     0x10ef078: add             x1, x1, HEAP, lsl #32
    // 0x10ef07c: cmp             w1, NULL
    // 0x10ef080: b.eq            #0x10ef08c
    // 0x10ef084: r0 = dispose()
    //     0x10ef084: bl              #0x12f9694  ; [package:flutter/src/painting/shape_decoration.dart] _ShapeDecorationPainter::dispose
    // 0x10ef088: ldur            x0, [fp, #-8]
    // 0x10ef08c: StoreField: r0->field_f3 = rNULL
    //     0x10ef08c: stur            NULL, [x0, #0xf3]
    // 0x10ef090: StoreField: r0->field_e7 = rNULL
    //     0x10ef090: stur            NULL, [x0, #0xe7]
    // 0x10ef094: StoreField: r0->field_eb = rNULL
    //     0x10ef094: stur            NULL, [x0, #0xeb]
    // 0x10ef098: StoreField: r0->field_ef = rNULL
    //     0x10ef098: stur            NULL, [x0, #0xef]
    // 0x10ef09c: LoadField: r1 = r0->field_63
    //     0x10ef09c: ldur            w1, [x0, #0x63]
    // 0x10ef0a0: DecompressPointer r1
    //     0x10ef0a0: add             x1, x1, HEAP, lsl #32
    // 0x10ef0a4: cmp             w1, NULL
    // 0x10ef0a8: b.eq            #0x10ef0b0
    // 0x10ef0ac: r0 = dispose()
    //     0x10ef0ac: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0x10ef0b0: ldur            x1, [fp, #-8]
    // 0x10ef0b4: r0 = dispose()
    //     0x10ef0b4: bl              #0x10eef48  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::dispose
    // 0x10ef0b8: r0 = Null
    //     0x10ef0b8: mov             x0, NULL
    // 0x10ef0bc: LeaveFrame
    //     0x10ef0bc: mov             SP, fp
    //     0x10ef0c0: ldp             fp, lr, [SP], #0x10
    // 0x10ef0c4: ret
    //     0x10ef0c4: ret             
    // 0x10ef0c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ef0c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ef0cc: b               #0x10ef064
  }
}

// class id: 4620, size: 0x8, field offset: 0x8
abstract class _SwitchConfig extends Object {
}

// class id: 4622, size: 0xc, field offset: 0x8
class _SwitchConfigM3 extends _MixinApplication111&Object&_SwitchConfig {

  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd42b38, size: 0x47c
    // 0xd42b38: EnterFrame
    //     0xd42b38: stp             fp, lr, [SP, #-0x10]!
    //     0xd42b3c: mov             fp, SP
    // 0xd42b40: AllocStack(0x8)
    //     0xd42b40: sub             SP, SP, #8
    // 0xd42b44: SetupParameters([dynamic _ /* r0 */])
    //     0xd42b44: ldr             x0, [fp, #0x18]
    //     0xd42b48: ldur            w3, [x0, #0x17]
    //     0xd42b4c: add             x3, x3, HEAP, lsl #32
    //     0xd42b50: stur            x3, [fp, #-8]
    // 0xd42b54: CheckStackOverflow
    //     0xd42b54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd42b58: cmp             SP, x16
    //     0xd42b5c: b.ls            #0xd42fac
    // 0xd42b60: ldr             x4, [fp, #0x10]
    // 0xd42b64: r0 = LoadClassIdInstr(r4)
    //     0xd42b64: ldur            x0, [x4, #-1]
    //     0xd42b68: ubfx            x0, x0, #0xc, #0x14
    // 0xd42b6c: mov             x1, x4
    // 0xd42b70: r2 = Instance_WidgetState
    //     0xd42b70: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd42b74: ldr             x2, [x2, #0xa70]
    // 0xd42b78: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd42b78: mov             x17, #0x2929
    //     0xd42b7c: movk            x17, #1, lsl #16
    //     0xd42b80: add             lr, x0, x17
    //     0xd42b84: ldr             lr, [x21, lr, lsl #3]
    //     0xd42b88: blr             lr
    // 0xd42b8c: tbnz            w0, #4, #0xd42c70
    // 0xd42b90: ldr             x3, [fp, #0x10]
    // 0xd42b94: r0 = LoadClassIdInstr(r3)
    //     0xd42b94: ldur            x0, [x3, #-1]
    //     0xd42b98: ubfx            x0, x0, #0xc, #0x14
    // 0xd42b9c: mov             x1, x3
    // 0xd42ba0: r2 = Instance_WidgetState
    //     0xd42ba0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd42ba4: ldr             x2, [x2, #0x100]
    // 0xd42ba8: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd42ba8: mov             x17, #0x2929
    //     0xd42bac: movk            x17, #1, lsl #16
    //     0xd42bb0: add             lr, x0, x17
    //     0xd42bb4: ldr             lr, [x21, lr, lsl #3]
    //     0xd42bb8: blr             lr
    // 0xd42bbc: tbnz            w0, #4, #0xd42c10
    // 0xd42bc0: ldur            x4, [fp, #-8]
    // 0xd42bc4: LoadField: r0 = r4->field_f
    //     0xd42bc4: ldur            w0, [x4, #0xf]
    // 0xd42bc8: DecompressPointer r0
    //     0xd42bc8: add             x0, x0, HEAP, lsl #32
    // 0xd42bcc: LoadField: r1 = r0->field_7
    //     0xd42bcc: ldur            w1, [x0, #7]
    // 0xd42bd0: DecompressPointer r1
    //     0xd42bd0: add             x1, x1, HEAP, lsl #32
    // 0xd42bd4: LoadField: r0 = r1->field_7f
    //     0xd42bd4: ldur            w0, [x1, #0x7f]
    // 0xd42bd8: DecompressPointer r0
    //     0xd42bd8: add             x0, x0, HEAP, lsl #32
    // 0xd42bdc: r1 = LoadClassIdInstr(r0)
    //     0xd42bdc: ldur            x1, [x0, #-1]
    //     0xd42be0: ubfx            x1, x1, #0xc, #0x14
    // 0xd42be4: mov             x16, x0
    // 0xd42be8: mov             x0, x1
    // 0xd42bec: mov             x1, x16
    // 0xd42bf0: d0 = 0.380000
    //     0xd42bf0: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xd42bf4: ldr             d0, [x17, #0x1f0]
    // 0xd42bf8: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd42bf8: sub             lr, x0, #1, lsl #12
    //     0xd42bfc: ldr             lr, [x21, lr, lsl #3]
    //     0xd42c00: blr             lr
    // 0xd42c04: LeaveFrame
    //     0xd42c04: mov             SP, fp
    //     0xd42c08: ldp             fp, lr, [SP], #0x10
    // 0xd42c0c: ret
    //     0xd42c0c: ret             
    // 0xd42c10: ldur            x4, [fp, #-8]
    // 0xd42c14: LoadField: r0 = r4->field_f
    //     0xd42c14: ldur            w0, [x4, #0xf]
    // 0xd42c18: DecompressPointer r0
    //     0xd42c18: add             x0, x0, HEAP, lsl #32
    // 0xd42c1c: LoadField: r1 = r0->field_7
    //     0xd42c1c: ldur            w1, [x0, #7]
    // 0xd42c20: DecompressPointer r1
    //     0xd42c20: add             x1, x1, HEAP, lsl #32
    // 0xd42c24: LoadField: r0 = r1->field_9f
    //     0xd42c24: ldur            w0, [x1, #0x9f]
    // 0xd42c28: DecompressPointer r0
    //     0xd42c28: add             x0, x0, HEAP, lsl #32
    // 0xd42c2c: cmp             w0, NULL
    // 0xd42c30: b.ne            #0xd42c44
    // 0xd42c34: LoadField: r0 = r1->field_7b
    //     0xd42c34: ldur            w0, [x1, #0x7b]
    // 0xd42c38: DecompressPointer r0
    //     0xd42c38: add             x0, x0, HEAP, lsl #32
    // 0xd42c3c: mov             x1, x0
    // 0xd42c40: b               #0xd42c48
    // 0xd42c44: mov             x1, x0
    // 0xd42c48: r0 = LoadClassIdInstr(r1)
    //     0xd42c48: ldur            x0, [x1, #-1]
    //     0xd42c4c: ubfx            x0, x0, #0xc, #0x14
    // 0xd42c50: d0 = 0.380000
    //     0xd42c50: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xd42c54: ldr             d0, [x17, #0x1f0]
    // 0xd42c58: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd42c58: sub             lr, x0, #1, lsl #12
    //     0xd42c5c: ldr             lr, [x21, lr, lsl #3]
    //     0xd42c60: blr             lr
    // 0xd42c64: LeaveFrame
    //     0xd42c64: mov             SP, fp
    //     0xd42c68: ldp             fp, lr, [SP], #0x10
    // 0xd42c6c: ret
    //     0xd42c6c: ret             
    // 0xd42c70: ldr             x3, [fp, #0x10]
    // 0xd42c74: ldur            x4, [fp, #-8]
    // 0xd42c78: r0 = LoadClassIdInstr(r3)
    //     0xd42c78: ldur            x0, [x3, #-1]
    //     0xd42c7c: ubfx            x0, x0, #0xc, #0x14
    // 0xd42c80: mov             x1, x3
    // 0xd42c84: r2 = Instance_WidgetState
    //     0xd42c84: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd42c88: ldr             x2, [x2, #0x100]
    // 0xd42c8c: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd42c8c: mov             x17, #0x2929
    //     0xd42c90: movk            x17, #1, lsl #16
    //     0xd42c94: add             lr, x0, x17
    //     0xd42c98: ldr             lr, [x21, lr, lsl #3]
    //     0xd42c9c: blr             lr
    // 0xd42ca0: tbnz            w0, #4, #0xd42e1c
    // 0xd42ca4: ldr             x3, [fp, #0x10]
    // 0xd42ca8: r0 = LoadClassIdInstr(r3)
    //     0xd42ca8: ldur            x0, [x3, #-1]
    //     0xd42cac: ubfx            x0, x0, #0xc, #0x14
    // 0xd42cb0: mov             x1, x3
    // 0xd42cb4: r2 = Instance_WidgetState
    //     0xd42cb4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd42cb8: ldr             x2, [x2, #0xa48]
    // 0xd42cbc: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd42cbc: mov             x17, #0x2929
    //     0xd42cc0: movk            x17, #1, lsl #16
    //     0xd42cc4: add             lr, x0, x17
    //     0xd42cc8: ldr             lr, [x21, lr, lsl #3]
    //     0xd42ccc: blr             lr
    // 0xd42cd0: tbnz            w0, #4, #0xd42d0c
    // 0xd42cd4: ldur            x3, [fp, #-8]
    // 0xd42cd8: LoadField: r0 = r3->field_f
    //     0xd42cd8: ldur            w0, [x3, #0xf]
    // 0xd42cdc: DecompressPointer r0
    //     0xd42cdc: add             x0, x0, HEAP, lsl #32
    // 0xd42ce0: LoadField: r1 = r0->field_7
    //     0xd42ce0: ldur            w1, [x0, #7]
    // 0xd42ce4: DecompressPointer r1
    //     0xd42ce4: add             x1, x1, HEAP, lsl #32
    // 0xd42ce8: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xd42ce8: ldur            w0, [x1, #0x17]
    // 0xd42cec: DecompressPointer r0
    //     0xd42cec: add             x0, x0, HEAP, lsl #32
    // 0xd42cf0: cmp             w0, NULL
    // 0xd42cf4: b.ne            #0xd42d00
    // 0xd42cf8: LoadField: r0 = r1->field_f
    //     0xd42cf8: ldur            w0, [x1, #0xf]
    // 0xd42cfc: DecompressPointer r0
    //     0xd42cfc: add             x0, x0, HEAP, lsl #32
    // 0xd42d00: LeaveFrame
    //     0xd42d00: mov             SP, fp
    //     0xd42d04: ldp             fp, lr, [SP], #0x10
    // 0xd42d08: ret
    //     0xd42d08: ret             
    // 0xd42d0c: ldr             x4, [fp, #0x10]
    // 0xd42d10: ldur            x3, [fp, #-8]
    // 0xd42d14: r0 = LoadClassIdInstr(r4)
    //     0xd42d14: ldur            x0, [x4, #-1]
    //     0xd42d18: ubfx            x0, x0, #0xc, #0x14
    // 0xd42d1c: mov             x1, x4
    // 0xd42d20: r2 = Instance_WidgetState
    //     0xd42d20: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd42d24: ldr             x2, [x2, #0xa50]
    // 0xd42d28: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd42d28: mov             x17, #0x2929
    //     0xd42d2c: movk            x17, #1, lsl #16
    //     0xd42d30: add             lr, x0, x17
    //     0xd42d34: ldr             lr, [x21, lr, lsl #3]
    //     0xd42d38: blr             lr
    // 0xd42d3c: tbnz            w0, #4, #0xd42d78
    // 0xd42d40: ldur            x3, [fp, #-8]
    // 0xd42d44: LoadField: r0 = r3->field_f
    //     0xd42d44: ldur            w0, [x3, #0xf]
    // 0xd42d48: DecompressPointer r0
    //     0xd42d48: add             x0, x0, HEAP, lsl #32
    // 0xd42d4c: LoadField: r1 = r0->field_7
    //     0xd42d4c: ldur            w1, [x0, #7]
    // 0xd42d50: DecompressPointer r1
    //     0xd42d50: add             x1, x1, HEAP, lsl #32
    // 0xd42d54: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xd42d54: ldur            w0, [x1, #0x17]
    // 0xd42d58: DecompressPointer r0
    //     0xd42d58: add             x0, x0, HEAP, lsl #32
    // 0xd42d5c: cmp             w0, NULL
    // 0xd42d60: b.ne            #0xd42d6c
    // 0xd42d64: LoadField: r0 = r1->field_f
    //     0xd42d64: ldur            w0, [x1, #0xf]
    // 0xd42d68: DecompressPointer r0
    //     0xd42d68: add             x0, x0, HEAP, lsl #32
    // 0xd42d6c: LeaveFrame
    //     0xd42d6c: mov             SP, fp
    //     0xd42d70: ldp             fp, lr, [SP], #0x10
    // 0xd42d74: ret
    //     0xd42d74: ret             
    // 0xd42d78: ldr             x4, [fp, #0x10]
    // 0xd42d7c: ldur            x3, [fp, #-8]
    // 0xd42d80: r0 = LoadClassIdInstr(r4)
    //     0xd42d80: ldur            x0, [x4, #-1]
    //     0xd42d84: ubfx            x0, x0, #0xc, #0x14
    // 0xd42d88: mov             x1, x4
    // 0xd42d8c: r2 = Instance_WidgetState
    //     0xd42d8c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd42d90: ldr             x2, [x2, #0xa60]
    // 0xd42d94: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd42d94: mov             x17, #0x2929
    //     0xd42d98: movk            x17, #1, lsl #16
    //     0xd42d9c: add             lr, x0, x17
    //     0xd42da0: ldr             lr, [x21, lr, lsl #3]
    //     0xd42da4: blr             lr
    // 0xd42da8: tbnz            w0, #4, #0xd42de4
    // 0xd42dac: ldur            x3, [fp, #-8]
    // 0xd42db0: LoadField: r0 = r3->field_f
    //     0xd42db0: ldur            w0, [x3, #0xf]
    // 0xd42db4: DecompressPointer r0
    //     0xd42db4: add             x0, x0, HEAP, lsl #32
    // 0xd42db8: LoadField: r1 = r0->field_7
    //     0xd42db8: ldur            w1, [x0, #7]
    // 0xd42dbc: DecompressPointer r1
    //     0xd42dbc: add             x1, x1, HEAP, lsl #32
    // 0xd42dc0: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xd42dc0: ldur            w0, [x1, #0x17]
    // 0xd42dc4: DecompressPointer r0
    //     0xd42dc4: add             x0, x0, HEAP, lsl #32
    // 0xd42dc8: cmp             w0, NULL
    // 0xd42dcc: b.ne            #0xd42dd8
    // 0xd42dd0: LoadField: r0 = r1->field_f
    //     0xd42dd0: ldur            w0, [x1, #0xf]
    // 0xd42dd4: DecompressPointer r0
    //     0xd42dd4: add             x0, x0, HEAP, lsl #32
    // 0xd42dd8: LeaveFrame
    //     0xd42dd8: mov             SP, fp
    //     0xd42ddc: ldp             fp, lr, [SP], #0x10
    // 0xd42de0: ret
    //     0xd42de0: ret             
    // 0xd42de4: ldur            x3, [fp, #-8]
    // 0xd42de8: LoadField: r0 = r3->field_f
    //     0xd42de8: ldur            w0, [x3, #0xf]
    // 0xd42dec: DecompressPointer r0
    //     0xd42dec: add             x0, x0, HEAP, lsl #32
    // 0xd42df0: LoadField: r1 = r0->field_7
    //     0xd42df0: ldur            w1, [x0, #7]
    // 0xd42df4: DecompressPointer r1
    //     0xd42df4: add             x1, x1, HEAP, lsl #32
    // 0xd42df8: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xd42df8: ldur            w0, [x1, #0x17]
    // 0xd42dfc: DecompressPointer r0
    //     0xd42dfc: add             x0, x0, HEAP, lsl #32
    // 0xd42e00: cmp             w0, NULL
    // 0xd42e04: b.ne            #0xd42e10
    // 0xd42e08: LoadField: r0 = r1->field_f
    //     0xd42e08: ldur            w0, [x1, #0xf]
    // 0xd42e0c: DecompressPointer r0
    //     0xd42e0c: add             x0, x0, HEAP, lsl #32
    // 0xd42e10: LeaveFrame
    //     0xd42e10: mov             SP, fp
    //     0xd42e14: ldp             fp, lr, [SP], #0x10
    // 0xd42e18: ret
    //     0xd42e18: ret             
    // 0xd42e1c: ldr             x4, [fp, #0x10]
    // 0xd42e20: ldur            x3, [fp, #-8]
    // 0xd42e24: r0 = LoadClassIdInstr(r4)
    //     0xd42e24: ldur            x0, [x4, #-1]
    //     0xd42e28: ubfx            x0, x0, #0xc, #0x14
    // 0xd42e2c: mov             x1, x4
    // 0xd42e30: r2 = Instance_WidgetState
    //     0xd42e30: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd42e34: ldr             x2, [x2, #0xa48]
    // 0xd42e38: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd42e38: mov             x17, #0x2929
    //     0xd42e3c: movk            x17, #1, lsl #16
    //     0xd42e40: add             lr, x0, x17
    //     0xd42e44: ldr             lr, [x21, lr, lsl #3]
    //     0xd42e48: blr             lr
    // 0xd42e4c: tbnz            w0, #4, #0xd42e88
    // 0xd42e50: ldur            x3, [fp, #-8]
    // 0xd42e54: LoadField: r0 = r3->field_f
    //     0xd42e54: ldur            w0, [x3, #0xf]
    // 0xd42e58: DecompressPointer r0
    //     0xd42e58: add             x0, x0, HEAP, lsl #32
    // 0xd42e5c: LoadField: r1 = r0->field_7
    //     0xd42e5c: ldur            w1, [x0, #7]
    // 0xd42e60: DecompressPointer r1
    //     0xd42e60: add             x1, x1, HEAP, lsl #32
    // 0xd42e64: LoadField: r0 = r1->field_9f
    //     0xd42e64: ldur            w0, [x1, #0x9f]
    // 0xd42e68: DecompressPointer r0
    //     0xd42e68: add             x0, x0, HEAP, lsl #32
    // 0xd42e6c: cmp             w0, NULL
    // 0xd42e70: b.ne            #0xd42e7c
    // 0xd42e74: LoadField: r0 = r1->field_7b
    //     0xd42e74: ldur            w0, [x1, #0x7b]
    // 0xd42e78: DecompressPointer r0
    //     0xd42e78: add             x0, x0, HEAP, lsl #32
    // 0xd42e7c: LeaveFrame
    //     0xd42e7c: mov             SP, fp
    //     0xd42e80: ldp             fp, lr, [SP], #0x10
    // 0xd42e84: ret
    //     0xd42e84: ret             
    // 0xd42e88: ldr             x4, [fp, #0x10]
    // 0xd42e8c: ldur            x3, [fp, #-8]
    // 0xd42e90: r0 = LoadClassIdInstr(r4)
    //     0xd42e90: ldur            x0, [x4, #-1]
    //     0xd42e94: ubfx            x0, x0, #0xc, #0x14
    // 0xd42e98: mov             x1, x4
    // 0xd42e9c: r2 = Instance_WidgetState
    //     0xd42e9c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd42ea0: ldr             x2, [x2, #0xa50]
    // 0xd42ea4: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd42ea4: mov             x17, #0x2929
    //     0xd42ea8: movk            x17, #1, lsl #16
    //     0xd42eac: add             lr, x0, x17
    //     0xd42eb0: ldr             lr, [x21, lr, lsl #3]
    //     0xd42eb4: blr             lr
    // 0xd42eb8: tbnz            w0, #4, #0xd42ef4
    // 0xd42ebc: ldur            x3, [fp, #-8]
    // 0xd42ec0: LoadField: r0 = r3->field_f
    //     0xd42ec0: ldur            w0, [x3, #0xf]
    // 0xd42ec4: DecompressPointer r0
    //     0xd42ec4: add             x0, x0, HEAP, lsl #32
    // 0xd42ec8: LoadField: r1 = r0->field_7
    //     0xd42ec8: ldur            w1, [x0, #7]
    // 0xd42ecc: DecompressPointer r1
    //     0xd42ecc: add             x1, x1, HEAP, lsl #32
    // 0xd42ed0: LoadField: r0 = r1->field_9f
    //     0xd42ed0: ldur            w0, [x1, #0x9f]
    // 0xd42ed4: DecompressPointer r0
    //     0xd42ed4: add             x0, x0, HEAP, lsl #32
    // 0xd42ed8: cmp             w0, NULL
    // 0xd42edc: b.ne            #0xd42ee8
    // 0xd42ee0: LoadField: r0 = r1->field_7b
    //     0xd42ee0: ldur            w0, [x1, #0x7b]
    // 0xd42ee4: DecompressPointer r0
    //     0xd42ee4: add             x0, x0, HEAP, lsl #32
    // 0xd42ee8: LeaveFrame
    //     0xd42ee8: mov             SP, fp
    //     0xd42eec: ldp             fp, lr, [SP], #0x10
    // 0xd42ef0: ret
    //     0xd42ef0: ret             
    // 0xd42ef4: ldr             x1, [fp, #0x10]
    // 0xd42ef8: ldur            x3, [fp, #-8]
    // 0xd42efc: r0 = LoadClassIdInstr(r1)
    //     0xd42efc: ldur            x0, [x1, #-1]
    //     0xd42f00: ubfx            x0, x0, #0xc, #0x14
    // 0xd42f04: r2 = Instance_WidgetState
    //     0xd42f04: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd42f08: ldr             x2, [x2, #0xa60]
    // 0xd42f0c: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd42f0c: mov             x17, #0x2929
    //     0xd42f10: movk            x17, #1, lsl #16
    //     0xd42f14: add             lr, x0, x17
    //     0xd42f18: ldr             lr, [x21, lr, lsl #3]
    //     0xd42f1c: blr             lr
    // 0xd42f20: tbnz            w0, #4, #0xd42f68
    // 0xd42f24: ldur            x1, [fp, #-8]
    // 0xd42f28: LoadField: r2 = r1->field_f
    //     0xd42f28: ldur            w2, [x1, #0xf]
    // 0xd42f2c: DecompressPointer r2
    //     0xd42f2c: add             x2, x2, HEAP, lsl #32
    // 0xd42f30: LoadField: r3 = r2->field_7
    //     0xd42f30: ldur            w3, [x2, #7]
    // 0xd42f34: DecompressPointer r3
    //     0xd42f34: add             x3, x3, HEAP, lsl #32
    // 0xd42f38: LoadField: r2 = r3->field_9f
    //     0xd42f38: ldur            w2, [x3, #0x9f]
    // 0xd42f3c: DecompressPointer r2
    //     0xd42f3c: add             x2, x2, HEAP, lsl #32
    // 0xd42f40: cmp             w2, NULL
    // 0xd42f44: b.ne            #0xd42f58
    // 0xd42f48: LoadField: r4 = r3->field_7b
    //     0xd42f48: ldur            w4, [x3, #0x7b]
    // 0xd42f4c: DecompressPointer r4
    //     0xd42f4c: add             x4, x4, HEAP, lsl #32
    // 0xd42f50: mov             x0, x4
    // 0xd42f54: b               #0xd42f5c
    // 0xd42f58: mov             x0, x2
    // 0xd42f5c: LeaveFrame
    //     0xd42f5c: mov             SP, fp
    //     0xd42f60: ldp             fp, lr, [SP], #0x10
    // 0xd42f64: ret
    //     0xd42f64: ret             
    // 0xd42f68: ldur            x1, [fp, #-8]
    // 0xd42f6c: LoadField: r2 = r1->field_f
    //     0xd42f6c: ldur            w2, [x1, #0xf]
    // 0xd42f70: DecompressPointer r2
    //     0xd42f70: add             x2, x2, HEAP, lsl #32
    // 0xd42f74: LoadField: r1 = r2->field_7
    //     0xd42f74: ldur            w1, [x2, #7]
    // 0xd42f78: DecompressPointer r1
    //     0xd42f78: add             x1, x1, HEAP, lsl #32
    // 0xd42f7c: LoadField: r2 = r1->field_9f
    //     0xd42f7c: ldur            w2, [x1, #0x9f]
    // 0xd42f80: DecompressPointer r2
    //     0xd42f80: add             x2, x2, HEAP, lsl #32
    // 0xd42f84: cmp             w2, NULL
    // 0xd42f88: b.ne            #0xd42f9c
    // 0xd42f8c: LoadField: r3 = r1->field_7b
    //     0xd42f8c: ldur            w3, [x1, #0x7b]
    // 0xd42f90: DecompressPointer r3
    //     0xd42f90: add             x3, x3, HEAP, lsl #32
    // 0xd42f94: mov             x0, x3
    // 0xd42f98: b               #0xd42fa0
    // 0xd42f9c: mov             x0, x2
    // 0xd42fa0: LeaveFrame
    //     0xd42fa0: mov             SP, fp
    //     0xd42fa4: ldp             fp, lr, [SP], #0x10
    // 0xd42fa8: ret
    //     0xd42fa8: ret             
    // 0xd42fac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd42fac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd42fb0: b               #0xd42b60
  }
  get _ switchHeight(/* No info */) {
    // ** addr: 0x125bf44, size: 0x8
    // 0x125bf44: d0 = 48.000000
    //     0x125bf44: ldr             d0, [PP, #0x5650]  ; [pp+0x5650] IMM: double(48) from 0x4048000000000000
    // 0x125bf48: ret
    //     0x125bf48: ret             
  }
  get _ switchHeightCollapsed(/* No info */) {
    // ** addr: 0x125c308, size: 0x10
    // 0x125c308: r0 = Instance_Size
    //     0x125c308: add             x0, PP, #0x98, lsl #12  ; [pp+0x98eb8] Obj!Size@12a7a51
    //     0x125c30c: ldr             x0, [x0, #0xeb8]
    // 0x125c310: LoadField: d0 = r0->field_f
    //     0x125c310: ldur            d0, [x0, #0xf]
    // 0x125c314: ret
    //     0x125c314: ret             
  }
  get _ switchWidth(/* No info */) {
    // ** addr: 0x12842ac, size: 0xc
    // 0x12842ac: d0 = 52.000000
    //     0x12842ac: add             x17, PP, #0x22, lsl #12  ; [pp+0x22108] IMM: double(52) from 0x404a000000000000
    //     0x12842b0: ldr             d0, [x17, #0x108]
    // 0x12842b4: ret
    //     0x12842b4: ret             
  }
}

// class id: 4623, size: 0x8, field offset: 0x8
class _SwitchConfigM2 extends _MixinApplication111&Object&_SwitchConfig {

  get _ switchHeightCollapsed(/* No info */) {
    // ** addr: 0x125c2f8, size: 0x10
    // 0x125c2f8: r0 = Instance_Size
    //     0x125c2f8: add             x0, PP, #0x90, lsl #12  ; [pp+0x90408] Obj!Size@12a75b1
    //     0x125c2fc: ldr             x0, [x0, #0x408]
    // 0x125c300: LoadField: d0 = r0->field_f
    //     0x125c300: ldur            d0, [x0, #0xf]
    // 0x125c304: ret
    //     0x125c304: ret             
  }
  get _ switchWidth(/* No info */) {
    // ** addr: 0x12842a0, size: 0xc
    // 0x12842a0: d0 = 59.000000
    //     0x12842a0: add             x17, PP, #0x98, lsl #12  ; [pp+0x98eb0] IMM: double(59) from 0x404d800000000000
    //     0x12842a4: ldr             d0, [x17, #0xeb0]
    // 0x12842a8: ret
    //     0x12842a8: ret             
  }
}

// class id: 4624, size: 0xc, field offset: 0x8
class _SwitchConfigCupertino extends _MixinApplication111&Object&_SwitchConfig {

  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd42a54, size: 0xe4
    // 0xd42a54: EnterFrame
    //     0xd42a54: stp             fp, lr, [SP, #-0x10]!
    //     0xd42a58: mov             fp, SP
    // 0xd42a5c: AllocStack(0x8)
    //     0xd42a5c: sub             SP, SP, #8
    // 0xd42a60: SetupParameters([dynamic _ /* r0 */])
    //     0xd42a60: ldr             x0, [fp, #0x18]
    //     0xd42a64: ldur            w3, [x0, #0x17]
    //     0xd42a68: add             x3, x3, HEAP, lsl #32
    //     0xd42a6c: stur            x3, [fp, #-8]
    // 0xd42a70: CheckStackOverflow
    //     0xd42a70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd42a74: cmp             SP, x16
    //     0xd42a78: b.ls            #0xd42b30
    // 0xd42a7c: ldr             x1, [fp, #0x10]
    // 0xd42a80: r0 = LoadClassIdInstr(r1)
    //     0xd42a80: ldur            x0, [x1, #-1]
    //     0xd42a84: ubfx            x0, x0, #0xc, #0x14
    // 0xd42a88: r2 = Instance_WidgetState
    //     0xd42a88: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd42a8c: ldr             x2, [x2, #0xa70]
    // 0xd42a90: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd42a90: mov             x17, #0x2929
    //     0xd42a94: movk            x17, #1, lsl #16
    //     0xd42a98: add             lr, x0, x17
    //     0xd42a9c: ldr             lr, [x21, lr, lsl #3]
    //     0xd42aa0: blr             lr
    // 0xd42aa4: tbnz            w0, #4, #0xd42aec
    // 0xd42aa8: ldur            x0, [fp, #-8]
    // 0xd42aac: LoadField: r1 = r0->field_f
    //     0xd42aac: ldur            w1, [x0, #0xf]
    // 0xd42ab0: DecompressPointer r1
    //     0xd42ab0: add             x1, x1, HEAP, lsl #32
    // 0xd42ab4: LoadField: r0 = r1->field_7
    //     0xd42ab4: ldur            w0, [x1, #7]
    // 0xd42ab8: DecompressPointer r0
    //     0xd42ab8: add             x0, x0, HEAP, lsl #32
    // 0xd42abc: LoadField: r1 = r0->field_7f
    //     0xd42abc: ldur            w1, [x0, #0x7f]
    // 0xd42ac0: DecompressPointer r1
    //     0xd42ac0: add             x1, x1, HEAP, lsl #32
    // 0xd42ac4: r0 = LoadClassIdInstr(r1)
    //     0xd42ac4: ldur            x0, [x1, #-1]
    //     0xd42ac8: ubfx            x0, x0, #0xc, #0x14
    // 0xd42acc: d0 = 0.380000
    //     0xd42acc: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xd42ad0: ldr             d0, [x17, #0x1f0]
    // 0xd42ad4: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd42ad4: sub             lr, x0, #1, lsl #12
    //     0xd42ad8: ldr             lr, [x21, lr, lsl #3]
    //     0xd42adc: blr             lr
    // 0xd42ae0: LeaveFrame
    //     0xd42ae0: mov             SP, fp
    //     0xd42ae4: ldp             fp, lr, [SP], #0x10
    // 0xd42ae8: ret
    //     0xd42ae8: ret             
    // 0xd42aec: ldur            x0, [fp, #-8]
    // 0xd42af0: LoadField: r1 = r0->field_f
    //     0xd42af0: ldur            w1, [x0, #0xf]
    // 0xd42af4: DecompressPointer r1
    //     0xd42af4: add             x1, x1, HEAP, lsl #32
    // 0xd42af8: LoadField: r2 = r1->field_7
    //     0xd42af8: ldur            w2, [x1, #7]
    // 0xd42afc: DecompressPointer r2
    //     0xd42afc: add             x2, x2, HEAP, lsl #32
    // 0xd42b00: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd42b00: ldur            w1, [x2, #0x17]
    // 0xd42b04: DecompressPointer r1
    //     0xd42b04: add             x1, x1, HEAP, lsl #32
    // 0xd42b08: cmp             w1, NULL
    // 0xd42b0c: b.ne            #0xd42b20
    // 0xd42b10: LoadField: r3 = r2->field_f
    //     0xd42b10: ldur            w3, [x2, #0xf]
    // 0xd42b14: DecompressPointer r3
    //     0xd42b14: add             x3, x3, HEAP, lsl #32
    // 0xd42b18: mov             x0, x3
    // 0xd42b1c: b               #0xd42b24
    // 0xd42b20: mov             x0, x1
    // 0xd42b24: LeaveFrame
    //     0xd42b24: mov             SP, fp
    //     0xd42b28: ldp             fp, lr, [SP], #0x10
    // 0xd42b2c: ret
    //     0xd42b2c: ret             
    // 0xd42b30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd42b30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd42b34: b               #0xd42a7c
  }
}

// class id: 5063, size: 0x38, field offset: 0x30
class _SwitchDefaultsM3 extends SwitchThemeData {

  late final ColorScheme _colors; // offset: 0x34

  [closure] MouseCursor <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd42a1c, size: 0x38
    // 0xd42a1c: EnterFrame
    //     0xd42a1c: stp             fp, lr, [SP, #-0x10]!
    //     0xd42a20: mov             fp, SP
    // 0xd42a24: CheckStackOverflow
    //     0xd42a24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd42a28: cmp             SP, x16
    //     0xd42a2c: b.ls            #0xd42a4c
    // 0xd42a30: ldr             x2, [fp, #0x10]
    // 0xd42a34: r1 = Instance__WidgetStateMouseCursor
    //     0xd42a34: add             x1, PP, #0x26, lsl #12  ; [pp+0x261c0] Obj!_WidgetStateMouseCursor@12b3261
    //     0xd42a38: ldr             x1, [x1, #0x1c0]
    // 0xd42a3c: r0 = resolve()
    //     0xd42a3c: bl              #0x8de794  ; [package:flutter/src/widgets/widget_state.dart] _WidgetStateMouseCursor::resolve
    // 0xd42a40: LeaveFrame
    //     0xd42a40: mov             SP, fp
    //     0xd42a44: ldp             fp, lr, [SP], #0x10
    // 0xd42a48: ret
    //     0xd42a48: ret             
    // 0xd42a4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd42a4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd42a50: b               #0xd42a30
  }
  [closure] Color? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd440d4, size: 0x3a8
    // 0xd440d4: EnterFrame
    //     0xd440d4: stp             fp, lr, [SP, #-0x10]!
    //     0xd440d8: mov             fp, SP
    // 0xd440dc: AllocStack(0x8)
    //     0xd440dc: sub             SP, SP, #8
    // 0xd440e0: SetupParameters([dynamic _ /* r0 */])
    //     0xd440e0: ldr             x0, [fp, #0x18]
    //     0xd440e4: ldur            w3, [x0, #0x17]
    //     0xd440e8: add             x3, x3, HEAP, lsl #32
    //     0xd440ec: stur            x3, [fp, #-8]
    // 0xd440f0: CheckStackOverflow
    //     0xd440f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd440f4: cmp             SP, x16
    //     0xd440f8: b.ls            #0xd44474
    // 0xd440fc: ldr             x4, [fp, #0x10]
    // 0xd44100: r0 = LoadClassIdInstr(r4)
    //     0xd44100: ldur            x0, [x4, #-1]
    //     0xd44104: ubfx            x0, x0, #0xc, #0x14
    // 0xd44108: mov             x1, x4
    // 0xd4410c: r2 = Instance_WidgetState
    //     0xd4410c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd44110: ldr             x2, [x2, #0x100]
    // 0xd44114: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd44114: mov             x17, #0x2929
    //     0xd44118: movk            x17, #1, lsl #16
    //     0xd4411c: add             lr, x0, x17
    //     0xd44120: ldr             lr, [x21, lr, lsl #3]
    //     0xd44124: blr             lr
    // 0xd44128: tbnz            w0, #4, #0xd442b8
    // 0xd4412c: ldr             x3, [fp, #0x10]
    // 0xd44130: r0 = LoadClassIdInstr(r3)
    //     0xd44130: ldur            x0, [x3, #-1]
    //     0xd44134: ubfx            x0, x0, #0xc, #0x14
    // 0xd44138: mov             x1, x3
    // 0xd4413c: r2 = Instance_WidgetState
    //     0xd4413c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd44140: ldr             x2, [x2, #0xa48]
    // 0xd44144: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd44144: mov             x17, #0x2929
    //     0xd44148: movk            x17, #1, lsl #16
    //     0xd4414c: add             lr, x0, x17
    //     0xd44150: ldr             lr, [x21, lr, lsl #3]
    //     0xd44154: blr             lr
    // 0xd44158: tbnz            w0, #4, #0xd441a8
    // 0xd4415c: ldur            x3, [fp, #-8]
    // 0xd44160: LoadField: r1 = r3->field_f
    //     0xd44160: ldur            w1, [x3, #0xf]
    // 0xd44164: DecompressPointer r1
    //     0xd44164: add             x1, x1, HEAP, lsl #32
    // 0xd44168: LoadField: r0 = r1->field_33
    //     0xd44168: ldur            w0, [x1, #0x33]
    // 0xd4416c: DecompressPointer r0
    //     0xd4416c: add             x0, x0, HEAP, lsl #32
    // 0xd44170: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd44174: cmp             w0, w16
    // 0xd44178: b.ne            #0xd44188
    // 0xd4417c: r2 = _colors
    //     0xd4417c: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd44180: ldr             x2, [x2, #0x1b8]
    // 0xd44184: r0 = InitLateFinalInstanceField()
    //     0xd44184: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd44188: LoadField: r1 = r0->field_b
    //     0xd44188: ldur            w1, [x0, #0xb]
    // 0xd4418c: DecompressPointer r1
    //     0xd4418c: add             x1, x1, HEAP, lsl #32
    // 0xd44190: d0 = 0.100000
    //     0xd44190: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xd44194: ldr             d0, [x17, #0x1e0]
    // 0xd44198: r0 = withOpacity()
    //     0xd44198: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd4419c: LeaveFrame
    //     0xd4419c: mov             SP, fp
    //     0xd441a0: ldp             fp, lr, [SP], #0x10
    // 0xd441a4: ret
    //     0xd441a4: ret             
    // 0xd441a8: ldr             x4, [fp, #0x10]
    // 0xd441ac: ldur            x3, [fp, #-8]
    // 0xd441b0: r0 = LoadClassIdInstr(r4)
    //     0xd441b0: ldur            x0, [x4, #-1]
    //     0xd441b4: ubfx            x0, x0, #0xc, #0x14
    // 0xd441b8: mov             x1, x4
    // 0xd441bc: r2 = Instance_WidgetState
    //     0xd441bc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd441c0: ldr             x2, [x2, #0xa50]
    // 0xd441c4: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd441c4: mov             x17, #0x2929
    //     0xd441c8: movk            x17, #1, lsl #16
    //     0xd441cc: add             lr, x0, x17
    //     0xd441d0: ldr             lr, [x21, lr, lsl #3]
    //     0xd441d4: blr             lr
    // 0xd441d8: tbnz            w0, #4, #0xd44228
    // 0xd441dc: ldur            x3, [fp, #-8]
    // 0xd441e0: LoadField: r1 = r3->field_f
    //     0xd441e0: ldur            w1, [x3, #0xf]
    // 0xd441e4: DecompressPointer r1
    //     0xd441e4: add             x1, x1, HEAP, lsl #32
    // 0xd441e8: LoadField: r0 = r1->field_33
    //     0xd441e8: ldur            w0, [x1, #0x33]
    // 0xd441ec: DecompressPointer r0
    //     0xd441ec: add             x0, x0, HEAP, lsl #32
    // 0xd441f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd441f4: cmp             w0, w16
    // 0xd441f8: b.ne            #0xd44208
    // 0xd441fc: r2 = _colors
    //     0xd441fc: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd44200: ldr             x2, [x2, #0x1b8]
    // 0xd44204: r0 = InitLateFinalInstanceField()
    //     0xd44204: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd44208: LoadField: r1 = r0->field_b
    //     0xd44208: ldur            w1, [x0, #0xb]
    // 0xd4420c: DecompressPointer r1
    //     0xd4420c: add             x1, x1, HEAP, lsl #32
    // 0xd44210: d0 = 0.080000
    //     0xd44210: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xd44214: ldr             d0, [x17, #0xa58]
    // 0xd44218: r0 = withOpacity()
    //     0xd44218: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd4421c: LeaveFrame
    //     0xd4421c: mov             SP, fp
    //     0xd44220: ldp             fp, lr, [SP], #0x10
    // 0xd44224: ret
    //     0xd44224: ret             
    // 0xd44228: ldr             x4, [fp, #0x10]
    // 0xd4422c: ldur            x3, [fp, #-8]
    // 0xd44230: r0 = LoadClassIdInstr(r4)
    //     0xd44230: ldur            x0, [x4, #-1]
    //     0xd44234: ubfx            x0, x0, #0xc, #0x14
    // 0xd44238: mov             x1, x4
    // 0xd4423c: r2 = Instance_WidgetState
    //     0xd4423c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd44240: ldr             x2, [x2, #0xa60]
    // 0xd44244: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd44244: mov             x17, #0x2929
    //     0xd44248: movk            x17, #1, lsl #16
    //     0xd4424c: add             lr, x0, x17
    //     0xd44250: ldr             lr, [x21, lr, lsl #3]
    //     0xd44254: blr             lr
    // 0xd44258: tbnz            w0, #4, #0xd442a8
    // 0xd4425c: ldur            x3, [fp, #-8]
    // 0xd44260: LoadField: r1 = r3->field_f
    //     0xd44260: ldur            w1, [x3, #0xf]
    // 0xd44264: DecompressPointer r1
    //     0xd44264: add             x1, x1, HEAP, lsl #32
    // 0xd44268: LoadField: r0 = r1->field_33
    //     0xd44268: ldur            w0, [x1, #0x33]
    // 0xd4426c: DecompressPointer r0
    //     0xd4426c: add             x0, x0, HEAP, lsl #32
    // 0xd44270: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd44274: cmp             w0, w16
    // 0xd44278: b.ne            #0xd44288
    // 0xd4427c: r2 = _colors
    //     0xd4427c: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd44280: ldr             x2, [x2, #0x1b8]
    // 0xd44284: r0 = InitLateFinalInstanceField()
    //     0xd44284: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd44288: LoadField: r1 = r0->field_b
    //     0xd44288: ldur            w1, [x0, #0xb]
    // 0xd4428c: DecompressPointer r1
    //     0xd4428c: add             x1, x1, HEAP, lsl #32
    // 0xd44290: d0 = 0.100000
    //     0xd44290: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xd44294: ldr             d0, [x17, #0x1e0]
    // 0xd44298: r0 = withOpacity()
    //     0xd44298: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd4429c: LeaveFrame
    //     0xd4429c: mov             SP, fp
    //     0xd442a0: ldp             fp, lr, [SP], #0x10
    // 0xd442a4: ret
    //     0xd442a4: ret             
    // 0xd442a8: r0 = Null
    //     0xd442a8: mov             x0, NULL
    // 0xd442ac: LeaveFrame
    //     0xd442ac: mov             SP, fp
    //     0xd442b0: ldp             fp, lr, [SP], #0x10
    // 0xd442b4: ret
    //     0xd442b4: ret             
    // 0xd442b8: ldr             x4, [fp, #0x10]
    // 0xd442bc: ldur            x3, [fp, #-8]
    // 0xd442c0: r0 = LoadClassIdInstr(r4)
    //     0xd442c0: ldur            x0, [x4, #-1]
    //     0xd442c4: ubfx            x0, x0, #0xc, #0x14
    // 0xd442c8: mov             x1, x4
    // 0xd442cc: r2 = Instance_WidgetState
    //     0xd442cc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd442d0: ldr             x2, [x2, #0xa48]
    // 0xd442d4: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd442d4: mov             x17, #0x2929
    //     0xd442d8: movk            x17, #1, lsl #16
    //     0xd442dc: add             lr, x0, x17
    //     0xd442e0: ldr             lr, [x21, lr, lsl #3]
    //     0xd442e4: blr             lr
    // 0xd442e8: tbnz            w0, #4, #0xd44348
    // 0xd442ec: ldur            x3, [fp, #-8]
    // 0xd442f0: LoadField: r1 = r3->field_f
    //     0xd442f0: ldur            w1, [x3, #0xf]
    // 0xd442f4: DecompressPointer r1
    //     0xd442f4: add             x1, x1, HEAP, lsl #32
    // 0xd442f8: LoadField: r0 = r1->field_33
    //     0xd442f8: ldur            w0, [x1, #0x33]
    // 0xd442fc: DecompressPointer r0
    //     0xd442fc: add             x0, x0, HEAP, lsl #32
    // 0xd44300: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd44304: cmp             w0, w16
    // 0xd44308: b.ne            #0xd44318
    // 0xd4430c: r2 = _colors
    //     0xd4430c: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd44310: ldr             x2, [x2, #0x1b8]
    // 0xd44314: r0 = InitLateFinalInstanceField()
    //     0xd44314: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd44318: LoadField: r1 = r0->field_7f
    //     0xd44318: ldur            w1, [x0, #0x7f]
    // 0xd4431c: DecompressPointer r1
    //     0xd4431c: add             x1, x1, HEAP, lsl #32
    // 0xd44320: r0 = LoadClassIdInstr(r1)
    //     0xd44320: ldur            x0, [x1, #-1]
    //     0xd44324: ubfx            x0, x0, #0xc, #0x14
    // 0xd44328: d0 = 0.100000
    //     0xd44328: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xd4432c: ldr             d0, [x17, #0x1e0]
    // 0xd44330: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd44330: sub             lr, x0, #1, lsl #12
    //     0xd44334: ldr             lr, [x21, lr, lsl #3]
    //     0xd44338: blr             lr
    // 0xd4433c: LeaveFrame
    //     0xd4433c: mov             SP, fp
    //     0xd44340: ldp             fp, lr, [SP], #0x10
    // 0xd44344: ret
    //     0xd44344: ret             
    // 0xd44348: ldr             x4, [fp, #0x10]
    // 0xd4434c: ldur            x3, [fp, #-8]
    // 0xd44350: r0 = LoadClassIdInstr(r4)
    //     0xd44350: ldur            x0, [x4, #-1]
    //     0xd44354: ubfx            x0, x0, #0xc, #0x14
    // 0xd44358: mov             x1, x4
    // 0xd4435c: r2 = Instance_WidgetState
    //     0xd4435c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd44360: ldr             x2, [x2, #0xa50]
    // 0xd44364: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd44364: mov             x17, #0x2929
    //     0xd44368: movk            x17, #1, lsl #16
    //     0xd4436c: add             lr, x0, x17
    //     0xd44370: ldr             lr, [x21, lr, lsl #3]
    //     0xd44374: blr             lr
    // 0xd44378: tbnz            w0, #4, #0xd443d8
    // 0xd4437c: ldur            x3, [fp, #-8]
    // 0xd44380: LoadField: r1 = r3->field_f
    //     0xd44380: ldur            w1, [x3, #0xf]
    // 0xd44384: DecompressPointer r1
    //     0xd44384: add             x1, x1, HEAP, lsl #32
    // 0xd44388: LoadField: r0 = r1->field_33
    //     0xd44388: ldur            w0, [x1, #0x33]
    // 0xd4438c: DecompressPointer r0
    //     0xd4438c: add             x0, x0, HEAP, lsl #32
    // 0xd44390: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd44394: cmp             w0, w16
    // 0xd44398: b.ne            #0xd443a8
    // 0xd4439c: r2 = _colors
    //     0xd4439c: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd443a0: ldr             x2, [x2, #0x1b8]
    // 0xd443a4: r0 = InitLateFinalInstanceField()
    //     0xd443a4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd443a8: LoadField: r1 = r0->field_7f
    //     0xd443a8: ldur            w1, [x0, #0x7f]
    // 0xd443ac: DecompressPointer r1
    //     0xd443ac: add             x1, x1, HEAP, lsl #32
    // 0xd443b0: r0 = LoadClassIdInstr(r1)
    //     0xd443b0: ldur            x0, [x1, #-1]
    //     0xd443b4: ubfx            x0, x0, #0xc, #0x14
    // 0xd443b8: d0 = 0.080000
    //     0xd443b8: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xd443bc: ldr             d0, [x17, #0xa58]
    // 0xd443c0: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd443c0: sub             lr, x0, #1, lsl #12
    //     0xd443c4: ldr             lr, [x21, lr, lsl #3]
    //     0xd443c8: blr             lr
    // 0xd443cc: LeaveFrame
    //     0xd443cc: mov             SP, fp
    //     0xd443d0: ldp             fp, lr, [SP], #0x10
    // 0xd443d4: ret
    //     0xd443d4: ret             
    // 0xd443d8: ldr             x1, [fp, #0x10]
    // 0xd443dc: ldur            x3, [fp, #-8]
    // 0xd443e0: r0 = LoadClassIdInstr(r1)
    //     0xd443e0: ldur            x0, [x1, #-1]
    //     0xd443e4: ubfx            x0, x0, #0xc, #0x14
    // 0xd443e8: r2 = Instance_WidgetState
    //     0xd443e8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd443ec: ldr             x2, [x2, #0xa60]
    // 0xd443f0: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd443f0: mov             x17, #0x2929
    //     0xd443f4: movk            x17, #1, lsl #16
    //     0xd443f8: add             lr, x0, x17
    //     0xd443fc: ldr             lr, [x21, lr, lsl #3]
    //     0xd44400: blr             lr
    // 0xd44404: tbnz            w0, #4, #0xd44464
    // 0xd44408: ldur            x0, [fp, #-8]
    // 0xd4440c: LoadField: r1 = r0->field_f
    //     0xd4440c: ldur            w1, [x0, #0xf]
    // 0xd44410: DecompressPointer r1
    //     0xd44410: add             x1, x1, HEAP, lsl #32
    // 0xd44414: LoadField: r0 = r1->field_33
    //     0xd44414: ldur            w0, [x1, #0x33]
    // 0xd44418: DecompressPointer r0
    //     0xd44418: add             x0, x0, HEAP, lsl #32
    // 0xd4441c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd44420: cmp             w0, w16
    // 0xd44424: b.ne            #0xd44434
    // 0xd44428: r2 = _colors
    //     0xd44428: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd4442c: ldr             x2, [x2, #0x1b8]
    // 0xd44430: r0 = InitLateFinalInstanceField()
    //     0xd44430: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd44434: LoadField: r1 = r0->field_7f
    //     0xd44434: ldur            w1, [x0, #0x7f]
    // 0xd44438: DecompressPointer r1
    //     0xd44438: add             x1, x1, HEAP, lsl #32
    // 0xd4443c: r0 = LoadClassIdInstr(r1)
    //     0xd4443c: ldur            x0, [x1, #-1]
    //     0xd44440: ubfx            x0, x0, #0xc, #0x14
    // 0xd44444: d0 = 0.100000
    //     0xd44444: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xd44448: ldr             d0, [x17, #0x1e0]
    // 0xd4444c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd4444c: sub             lr, x0, #1, lsl #12
    //     0xd44450: ldr             lr, [x21, lr, lsl #3]
    //     0xd44454: blr             lr
    // 0xd44458: LeaveFrame
    //     0xd44458: mov             SP, fp
    //     0xd4445c: ldp             fp, lr, [SP], #0x10
    // 0xd44460: ret
    //     0xd44460: ret             
    // 0xd44464: r0 = Null
    //     0xd44464: mov             x0, NULL
    // 0xd44468: LeaveFrame
    //     0xd44468: mov             SP, fp
    //     0xd4446c: ldp             fp, lr, [SP], #0x10
    // 0xd44470: ret
    //     0xd44470: ret             
    // 0xd44474: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd44474: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd44478: b               #0xd440fc
  }
  ColorScheme _colors(_SwitchDefaultsM3) {
    // ** addr: 0xd4447c, size: 0x44
    // 0xd4447c: EnterFrame
    //     0xd4447c: stp             fp, lr, [SP, #-0x10]!
    //     0xd44480: mov             fp, SP
    // 0xd44484: CheckStackOverflow
    //     0xd44484: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd44488: cmp             SP, x16
    //     0xd4448c: b.ls            #0xd444b8
    // 0xd44490: ldr             x0, [fp, #0x10]
    // 0xd44494: LoadField: r1 = r0->field_2f
    //     0xd44494: ldur            w1, [x0, #0x2f]
    // 0xd44498: DecompressPointer r1
    //     0xd44498: add             x1, x1, HEAP, lsl #32
    // 0xd4449c: r0 = of()
    //     0xd4449c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd444a0: LoadField: r1 = r0->field_3f
    //     0xd444a0: ldur            w1, [x0, #0x3f]
    // 0xd444a4: DecompressPointer r1
    //     0xd444a4: add             x1, x1, HEAP, lsl #32
    // 0xd444a8: mov             x0, x1
    // 0xd444ac: LeaveFrame
    //     0xd444ac: mov             SP, fp
    //     0xd444b0: ldp             fp, lr, [SP], #0x10
    // 0xd444b4: ret
    //     0xd444b4: ret             
    // 0xd444b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd444b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd444bc: b               #0xd44490
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd444c0, size: 0x158
    // 0xd444c0: EnterFrame
    //     0xd444c0: stp             fp, lr, [SP, #-0x10]!
    //     0xd444c4: mov             fp, SP
    // 0xd444c8: AllocStack(0x8)
    //     0xd444c8: sub             SP, SP, #8
    // 0xd444cc: SetupParameters([dynamic _ /* r0 */])
    //     0xd444cc: ldr             x0, [fp, #0x18]
    //     0xd444d0: ldur            w3, [x0, #0x17]
    //     0xd444d4: add             x3, x3, HEAP, lsl #32
    //     0xd444d8: stur            x3, [fp, #-8]
    // 0xd444dc: CheckStackOverflow
    //     0xd444dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd444e0: cmp             SP, x16
    //     0xd444e4: b.ls            #0xd44610
    // 0xd444e8: ldr             x4, [fp, #0x10]
    // 0xd444ec: r0 = LoadClassIdInstr(r4)
    //     0xd444ec: ldur            x0, [x4, #-1]
    //     0xd444f0: ubfx            x0, x0, #0xc, #0x14
    // 0xd444f4: mov             x1, x4
    // 0xd444f8: r2 = Instance_WidgetState
    //     0xd444f8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd444fc: ldr             x2, [x2, #0x100]
    // 0xd44500: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd44500: mov             x17, #0x2929
    //     0xd44504: movk            x17, #1, lsl #16
    //     0xd44508: add             lr, x0, x17
    //     0xd4450c: ldr             lr, [x21, lr, lsl #3]
    //     0xd44510: blr             lr
    // 0xd44514: tbnz            w0, #4, #0xd4452c
    // 0xd44518: r0 = Instance_Color
    //     0xd44518: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xd4451c: ldr             x0, [x0, #0x810]
    // 0xd44520: LeaveFrame
    //     0xd44520: mov             SP, fp
    //     0xd44524: ldp             fp, lr, [SP], #0x10
    // 0xd44528: ret
    //     0xd44528: ret             
    // 0xd4452c: ldr             x1, [fp, #0x10]
    // 0xd44530: r0 = LoadClassIdInstr(r1)
    //     0xd44530: ldur            x0, [x1, #-1]
    //     0xd44534: ubfx            x0, x0, #0xc, #0x14
    // 0xd44538: r2 = Instance_WidgetState
    //     0xd44538: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd4453c: ldr             x2, [x2, #0xa70]
    // 0xd44540: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd44540: mov             x17, #0x2929
    //     0xd44544: movk            x17, #1, lsl #16
    //     0xd44548: add             lr, x0, x17
    //     0xd4454c: ldr             lr, [x21, lr, lsl #3]
    //     0xd44550: blr             lr
    // 0xd44554: tbnz            w0, #4, #0xd445b4
    // 0xd44558: ldur            x0, [fp, #-8]
    // 0xd4455c: LoadField: r1 = r0->field_f
    //     0xd4455c: ldur            w1, [x0, #0xf]
    // 0xd44560: DecompressPointer r1
    //     0xd44560: add             x1, x1, HEAP, lsl #32
    // 0xd44564: LoadField: r0 = r1->field_33
    //     0xd44564: ldur            w0, [x1, #0x33]
    // 0xd44568: DecompressPointer r0
    //     0xd44568: add             x0, x0, HEAP, lsl #32
    // 0xd4456c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd44570: cmp             w0, w16
    // 0xd44574: b.ne            #0xd44584
    // 0xd44578: r2 = _colors
    //     0xd44578: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd4457c: ldr             x2, [x2, #0x1b8]
    // 0xd44580: r0 = InitLateFinalInstanceField()
    //     0xd44580: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd44584: LoadField: r1 = r0->field_7f
    //     0xd44584: ldur            w1, [x0, #0x7f]
    // 0xd44588: DecompressPointer r1
    //     0xd44588: add             x1, x1, HEAP, lsl #32
    // 0xd4458c: r0 = LoadClassIdInstr(r1)
    //     0xd4458c: ldur            x0, [x1, #-1]
    //     0xd44590: ubfx            x0, x0, #0xc, #0x14
    // 0xd44594: d0 = 0.120000
    //     0xd44594: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xd44598: ldr             d0, [x17, #0xc40]
    // 0xd4459c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd4459c: sub             lr, x0, #1, lsl #12
    //     0xd445a0: ldr             lr, [x21, lr, lsl #3]
    //     0xd445a4: blr             lr
    // 0xd445a8: LeaveFrame
    //     0xd445a8: mov             SP, fp
    //     0xd445ac: ldp             fp, lr, [SP], #0x10
    // 0xd445b0: ret
    //     0xd445b0: ret             
    // 0xd445b4: ldur            x0, [fp, #-8]
    // 0xd445b8: LoadField: r1 = r0->field_f
    //     0xd445b8: ldur            w1, [x0, #0xf]
    // 0xd445bc: DecompressPointer r1
    //     0xd445bc: add             x1, x1, HEAP, lsl #32
    // 0xd445c0: LoadField: r0 = r1->field_33
    //     0xd445c0: ldur            w0, [x1, #0x33]
    // 0xd445c4: DecompressPointer r0
    //     0xd445c4: add             x0, x0, HEAP, lsl #32
    // 0xd445c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd445cc: cmp             w0, w16
    // 0xd445d0: b.ne            #0xd445e0
    // 0xd445d4: r2 = _colors
    //     0xd445d4: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd445d8: ldr             x2, [x2, #0x1b8]
    // 0xd445dc: r0 = InitLateFinalInstanceField()
    //     0xd445dc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd445e0: LoadField: r1 = r0->field_a7
    //     0xd445e0: ldur            w1, [x0, #0xa7]
    // 0xd445e4: DecompressPointer r1
    //     0xd445e4: add             x1, x1, HEAP, lsl #32
    // 0xd445e8: cmp             w1, NULL
    // 0xd445ec: b.ne            #0xd44600
    // 0xd445f0: LoadField: r2 = r0->field_cb
    //     0xd445f0: ldur            w2, [x0, #0xcb]
    // 0xd445f4: DecompressPointer r2
    //     0xd445f4: add             x2, x2, HEAP, lsl #32
    // 0xd445f8: mov             x0, x2
    // 0xd445fc: b               #0xd44604
    // 0xd44600: mov             x0, x1
    // 0xd44604: LeaveFrame
    //     0xd44604: mov             SP, fp
    //     0xd44608: ldp             fp, lr, [SP], #0x10
    // 0xd4460c: ret
    //     0xd4460c: ret             
    // 0xd44610: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd44610: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd44614: b               #0xd444e8
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd447fc, size: 0x53c
    // 0xd447fc: EnterFrame
    //     0xd447fc: stp             fp, lr, [SP, #-0x10]!
    //     0xd44800: mov             fp, SP
    // 0xd44804: AllocStack(0x8)
    //     0xd44804: sub             SP, SP, #8
    // 0xd44808: SetupParameters([dynamic _ /* r0 */])
    //     0xd44808: ldr             x0, [fp, #0x18]
    //     0xd4480c: ldur            w3, [x0, #0x17]
    //     0xd44810: add             x3, x3, HEAP, lsl #32
    //     0xd44814: stur            x3, [fp, #-8]
    // 0xd44818: CheckStackOverflow
    //     0xd44818: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4481c: cmp             SP, x16
    //     0xd44820: b.ls            #0xd44d30
    // 0xd44824: ldr             x4, [fp, #0x10]
    // 0xd44828: r0 = LoadClassIdInstr(r4)
    //     0xd44828: ldur            x0, [x4, #-1]
    //     0xd4482c: ubfx            x0, x0, #0xc, #0x14
    // 0xd44830: mov             x1, x4
    // 0xd44834: r2 = Instance_WidgetState
    //     0xd44834: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd44838: ldr             x2, [x2, #0xa70]
    // 0xd4483c: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd4483c: mov             x17, #0x2929
    //     0xd44840: movk            x17, #1, lsl #16
    //     0xd44844: add             lr, x0, x17
    //     0xd44848: ldr             lr, [x21, lr, lsl #3]
    //     0xd4484c: blr             lr
    // 0xd44850: tbnz            w0, #4, #0xd4494c
    // 0xd44854: ldr             x3, [fp, #0x10]
    // 0xd44858: r0 = LoadClassIdInstr(r3)
    //     0xd44858: ldur            x0, [x3, #-1]
    //     0xd4485c: ubfx            x0, x0, #0xc, #0x14
    // 0xd44860: mov             x1, x3
    // 0xd44864: r2 = Instance_WidgetState
    //     0xd44864: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd44868: ldr             x2, [x2, #0x100]
    // 0xd4486c: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd4486c: mov             x17, #0x2929
    //     0xd44870: movk            x17, #1, lsl #16
    //     0xd44874: add             lr, x0, x17
    //     0xd44878: ldr             lr, [x21, lr, lsl #3]
    //     0xd4487c: blr             lr
    // 0xd44880: tbnz            w0, #4, #0xd448e0
    // 0xd44884: ldur            x4, [fp, #-8]
    // 0xd44888: LoadField: r1 = r4->field_f
    //     0xd44888: ldur            w1, [x4, #0xf]
    // 0xd4488c: DecompressPointer r1
    //     0xd4488c: add             x1, x1, HEAP, lsl #32
    // 0xd44890: LoadField: r0 = r1->field_33
    //     0xd44890: ldur            w0, [x1, #0x33]
    // 0xd44894: DecompressPointer r0
    //     0xd44894: add             x0, x0, HEAP, lsl #32
    // 0xd44898: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd4489c: cmp             w0, w16
    // 0xd448a0: b.ne            #0xd448b0
    // 0xd448a4: r2 = _colors
    //     0xd448a4: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd448a8: ldr             x2, [x2, #0x1b8]
    // 0xd448ac: r0 = InitLateFinalInstanceField()
    //     0xd448ac: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd448b0: LoadField: r1 = r0->field_7f
    //     0xd448b0: ldur            w1, [x0, #0x7f]
    // 0xd448b4: DecompressPointer r1
    //     0xd448b4: add             x1, x1, HEAP, lsl #32
    // 0xd448b8: r0 = LoadClassIdInstr(r1)
    //     0xd448b8: ldur            x0, [x1, #-1]
    //     0xd448bc: ubfx            x0, x0, #0xc, #0x14
    // 0xd448c0: d0 = 0.120000
    //     0xd448c0: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xd448c4: ldr             d0, [x17, #0xc40]
    // 0xd448c8: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd448c8: sub             lr, x0, #1, lsl #12
    //     0xd448cc: ldr             lr, [x21, lr, lsl #3]
    //     0xd448d0: blr             lr
    // 0xd448d4: LeaveFrame
    //     0xd448d4: mov             SP, fp
    //     0xd448d8: ldp             fp, lr, [SP], #0x10
    // 0xd448dc: ret
    //     0xd448dc: ret             
    // 0xd448e0: ldur            x4, [fp, #-8]
    // 0xd448e4: LoadField: r1 = r4->field_f
    //     0xd448e4: ldur            w1, [x4, #0xf]
    // 0xd448e8: DecompressPointer r1
    //     0xd448e8: add             x1, x1, HEAP, lsl #32
    // 0xd448ec: LoadField: r0 = r1->field_33
    //     0xd448ec: ldur            w0, [x1, #0x33]
    // 0xd448f0: DecompressPointer r0
    //     0xd448f0: add             x0, x0, HEAP, lsl #32
    // 0xd448f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd448f8: cmp             w0, w16
    // 0xd448fc: b.ne            #0xd4490c
    // 0xd44900: r2 = _colors
    //     0xd44900: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd44904: ldr             x2, [x2, #0x1b8]
    // 0xd44908: r0 = InitLateFinalInstanceField()
    //     0xd44908: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd4490c: LoadField: r1 = r0->field_9f
    //     0xd4490c: ldur            w1, [x0, #0x9f]
    // 0xd44910: DecompressPointer r1
    //     0xd44910: add             x1, x1, HEAP, lsl #32
    // 0xd44914: cmp             w1, NULL
    // 0xd44918: b.ne            #0xd44924
    // 0xd4491c: LoadField: r1 = r0->field_7b
    //     0xd4491c: ldur            w1, [x0, #0x7b]
    // 0xd44920: DecompressPointer r1
    //     0xd44920: add             x1, x1, HEAP, lsl #32
    // 0xd44924: r0 = LoadClassIdInstr(r1)
    //     0xd44924: ldur            x0, [x1, #-1]
    //     0xd44928: ubfx            x0, x0, #0xc, #0x14
    // 0xd4492c: d0 = 0.120000
    //     0xd4492c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xd44930: ldr             d0, [x17, #0xc40]
    // 0xd44934: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd44934: sub             lr, x0, #1, lsl #12
    //     0xd44938: ldr             lr, [x21, lr, lsl #3]
    //     0xd4493c: blr             lr
    // 0xd44940: LeaveFrame
    //     0xd44940: mov             SP, fp
    //     0xd44944: ldp             fp, lr, [SP], #0x10
    // 0xd44948: ret
    //     0xd44948: ret             
    // 0xd4494c: ldr             x3, [fp, #0x10]
    // 0xd44950: ldur            x4, [fp, #-8]
    // 0xd44954: r0 = LoadClassIdInstr(r3)
    //     0xd44954: ldur            x0, [x3, #-1]
    //     0xd44958: ubfx            x0, x0, #0xc, #0x14
    // 0xd4495c: mov             x1, x3
    // 0xd44960: r2 = Instance_WidgetState
    //     0xd44960: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd44964: ldr             x2, [x2, #0x100]
    // 0xd44968: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd44968: mov             x17, #0x2929
    //     0xd4496c: movk            x17, #1, lsl #16
    //     0xd44970: add             lr, x0, x17
    //     0xd44974: ldr             lr, [x21, lr, lsl #3]
    //     0xd44978: blr             lr
    // 0xd4497c: tbnz            w0, #4, #0xd44b28
    // 0xd44980: ldr             x3, [fp, #0x10]
    // 0xd44984: r0 = LoadClassIdInstr(r3)
    //     0xd44984: ldur            x0, [x3, #-1]
    //     0xd44988: ubfx            x0, x0, #0xc, #0x14
    // 0xd4498c: mov             x1, x3
    // 0xd44990: r2 = Instance_WidgetState
    //     0xd44990: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd44994: ldr             x2, [x2, #0xa48]
    // 0xd44998: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd44998: mov             x17, #0x2929
    //     0xd4499c: movk            x17, #1, lsl #16
    //     0xd449a0: add             lr, x0, x17
    //     0xd449a4: ldr             lr, [x21, lr, lsl #3]
    //     0xd449a8: blr             lr
    // 0xd449ac: tbnz            w0, #4, #0xd449f4
    // 0xd449b0: ldur            x3, [fp, #-8]
    // 0xd449b4: LoadField: r1 = r3->field_f
    //     0xd449b4: ldur            w1, [x3, #0xf]
    // 0xd449b8: DecompressPointer r1
    //     0xd449b8: add             x1, x1, HEAP, lsl #32
    // 0xd449bc: LoadField: r0 = r1->field_33
    //     0xd449bc: ldur            w0, [x1, #0x33]
    // 0xd449c0: DecompressPointer r0
    //     0xd449c0: add             x0, x0, HEAP, lsl #32
    // 0xd449c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd449c8: cmp             w0, w16
    // 0xd449cc: b.ne            #0xd449dc
    // 0xd449d0: r2 = _colors
    //     0xd449d0: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd449d4: ldr             x2, [x2, #0x1b8]
    // 0xd449d8: r0 = InitLateFinalInstanceField()
    //     0xd449d8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd449dc: LoadField: r1 = r0->field_b
    //     0xd449dc: ldur            w1, [x0, #0xb]
    // 0xd449e0: DecompressPointer r1
    //     0xd449e0: add             x1, x1, HEAP, lsl #32
    // 0xd449e4: mov             x0, x1
    // 0xd449e8: LeaveFrame
    //     0xd449e8: mov             SP, fp
    //     0xd449ec: ldp             fp, lr, [SP], #0x10
    // 0xd449f0: ret
    //     0xd449f0: ret             
    // 0xd449f4: ldr             x4, [fp, #0x10]
    // 0xd449f8: ldur            x3, [fp, #-8]
    // 0xd449fc: r0 = LoadClassIdInstr(r4)
    //     0xd449fc: ldur            x0, [x4, #-1]
    //     0xd44a00: ubfx            x0, x0, #0xc, #0x14
    // 0xd44a04: mov             x1, x4
    // 0xd44a08: r2 = Instance_WidgetState
    //     0xd44a08: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd44a0c: ldr             x2, [x2, #0xa50]
    // 0xd44a10: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd44a10: mov             x17, #0x2929
    //     0xd44a14: movk            x17, #1, lsl #16
    //     0xd44a18: add             lr, x0, x17
    //     0xd44a1c: ldr             lr, [x21, lr, lsl #3]
    //     0xd44a20: blr             lr
    // 0xd44a24: tbnz            w0, #4, #0xd44a6c
    // 0xd44a28: ldur            x3, [fp, #-8]
    // 0xd44a2c: LoadField: r1 = r3->field_f
    //     0xd44a2c: ldur            w1, [x3, #0xf]
    // 0xd44a30: DecompressPointer r1
    //     0xd44a30: add             x1, x1, HEAP, lsl #32
    // 0xd44a34: LoadField: r0 = r1->field_33
    //     0xd44a34: ldur            w0, [x1, #0x33]
    // 0xd44a38: DecompressPointer r0
    //     0xd44a38: add             x0, x0, HEAP, lsl #32
    // 0xd44a3c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd44a40: cmp             w0, w16
    // 0xd44a44: b.ne            #0xd44a54
    // 0xd44a48: r2 = _colors
    //     0xd44a48: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd44a4c: ldr             x2, [x2, #0x1b8]
    // 0xd44a50: r0 = InitLateFinalInstanceField()
    //     0xd44a50: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd44a54: LoadField: r1 = r0->field_b
    //     0xd44a54: ldur            w1, [x0, #0xb]
    // 0xd44a58: DecompressPointer r1
    //     0xd44a58: add             x1, x1, HEAP, lsl #32
    // 0xd44a5c: mov             x0, x1
    // 0xd44a60: LeaveFrame
    //     0xd44a60: mov             SP, fp
    //     0xd44a64: ldp             fp, lr, [SP], #0x10
    // 0xd44a68: ret
    //     0xd44a68: ret             
    // 0xd44a6c: ldr             x4, [fp, #0x10]
    // 0xd44a70: ldur            x3, [fp, #-8]
    // 0xd44a74: r0 = LoadClassIdInstr(r4)
    //     0xd44a74: ldur            x0, [x4, #-1]
    //     0xd44a78: ubfx            x0, x0, #0xc, #0x14
    // 0xd44a7c: mov             x1, x4
    // 0xd44a80: r2 = Instance_WidgetState
    //     0xd44a80: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd44a84: ldr             x2, [x2, #0xa60]
    // 0xd44a88: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd44a88: mov             x17, #0x2929
    //     0xd44a8c: movk            x17, #1, lsl #16
    //     0xd44a90: add             lr, x0, x17
    //     0xd44a94: ldr             lr, [x21, lr, lsl #3]
    //     0xd44a98: blr             lr
    // 0xd44a9c: tbnz            w0, #4, #0xd44ae4
    // 0xd44aa0: ldur            x3, [fp, #-8]
    // 0xd44aa4: LoadField: r1 = r3->field_f
    //     0xd44aa4: ldur            w1, [x3, #0xf]
    // 0xd44aa8: DecompressPointer r1
    //     0xd44aa8: add             x1, x1, HEAP, lsl #32
    // 0xd44aac: LoadField: r0 = r1->field_33
    //     0xd44aac: ldur            w0, [x1, #0x33]
    // 0xd44ab0: DecompressPointer r0
    //     0xd44ab0: add             x0, x0, HEAP, lsl #32
    // 0xd44ab4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd44ab8: cmp             w0, w16
    // 0xd44abc: b.ne            #0xd44acc
    // 0xd44ac0: r2 = _colors
    //     0xd44ac0: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd44ac4: ldr             x2, [x2, #0x1b8]
    // 0xd44ac8: r0 = InitLateFinalInstanceField()
    //     0xd44ac8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd44acc: LoadField: r1 = r0->field_b
    //     0xd44acc: ldur            w1, [x0, #0xb]
    // 0xd44ad0: DecompressPointer r1
    //     0xd44ad0: add             x1, x1, HEAP, lsl #32
    // 0xd44ad4: mov             x0, x1
    // 0xd44ad8: LeaveFrame
    //     0xd44ad8: mov             SP, fp
    //     0xd44adc: ldp             fp, lr, [SP], #0x10
    // 0xd44ae0: ret
    //     0xd44ae0: ret             
    // 0xd44ae4: ldur            x3, [fp, #-8]
    // 0xd44ae8: LoadField: r1 = r3->field_f
    //     0xd44ae8: ldur            w1, [x3, #0xf]
    // 0xd44aec: DecompressPointer r1
    //     0xd44aec: add             x1, x1, HEAP, lsl #32
    // 0xd44af0: LoadField: r0 = r1->field_33
    //     0xd44af0: ldur            w0, [x1, #0x33]
    // 0xd44af4: DecompressPointer r0
    //     0xd44af4: add             x0, x0, HEAP, lsl #32
    // 0xd44af8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd44afc: cmp             w0, w16
    // 0xd44b00: b.ne            #0xd44b10
    // 0xd44b04: r2 = _colors
    //     0xd44b04: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd44b08: ldr             x2, [x2, #0x1b8]
    // 0xd44b0c: r0 = InitLateFinalInstanceField()
    //     0xd44b0c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd44b10: LoadField: r1 = r0->field_b
    //     0xd44b10: ldur            w1, [x0, #0xb]
    // 0xd44b14: DecompressPointer r1
    //     0xd44b14: add             x1, x1, HEAP, lsl #32
    // 0xd44b18: mov             x0, x1
    // 0xd44b1c: LeaveFrame
    //     0xd44b1c: mov             SP, fp
    //     0xd44b20: ldp             fp, lr, [SP], #0x10
    // 0xd44b24: ret
    //     0xd44b24: ret             
    // 0xd44b28: ldr             x4, [fp, #0x10]
    // 0xd44b2c: ldur            x3, [fp, #-8]
    // 0xd44b30: r0 = LoadClassIdInstr(r4)
    //     0xd44b30: ldur            x0, [x4, #-1]
    //     0xd44b34: ubfx            x0, x0, #0xc, #0x14
    // 0xd44b38: mov             x1, x4
    // 0xd44b3c: r2 = Instance_WidgetState
    //     0xd44b3c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd44b40: ldr             x2, [x2, #0xa48]
    // 0xd44b44: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd44b44: mov             x17, #0x2929
    //     0xd44b48: movk            x17, #1, lsl #16
    //     0xd44b4c: add             lr, x0, x17
    //     0xd44b50: ldr             lr, [x21, lr, lsl #3]
    //     0xd44b54: blr             lr
    // 0xd44b58: tbnz            w0, #4, #0xd44bb8
    // 0xd44b5c: ldur            x3, [fp, #-8]
    // 0xd44b60: LoadField: r1 = r3->field_f
    //     0xd44b60: ldur            w1, [x3, #0xf]
    // 0xd44b64: DecompressPointer r1
    //     0xd44b64: add             x1, x1, HEAP, lsl #32
    // 0xd44b68: LoadField: r0 = r1->field_33
    //     0xd44b68: ldur            w0, [x1, #0x33]
    // 0xd44b6c: DecompressPointer r0
    //     0xd44b6c: add             x0, x0, HEAP, lsl #32
    // 0xd44b70: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd44b74: cmp             w0, w16
    // 0xd44b78: b.ne            #0xd44b88
    // 0xd44b7c: r2 = _colors
    //     0xd44b7c: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd44b80: ldr             x2, [x2, #0x1b8]
    // 0xd44b84: r0 = InitLateFinalInstanceField()
    //     0xd44b84: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd44b88: LoadField: r1 = r0->field_9f
    //     0xd44b88: ldur            w1, [x0, #0x9f]
    // 0xd44b8c: DecompressPointer r1
    //     0xd44b8c: add             x1, x1, HEAP, lsl #32
    // 0xd44b90: cmp             w1, NULL
    // 0xd44b94: b.ne            #0xd44ba8
    // 0xd44b98: LoadField: r1 = r0->field_7b
    //     0xd44b98: ldur            w1, [x0, #0x7b]
    // 0xd44b9c: DecompressPointer r1
    //     0xd44b9c: add             x1, x1, HEAP, lsl #32
    // 0xd44ba0: mov             x0, x1
    // 0xd44ba4: b               #0xd44bac
    // 0xd44ba8: mov             x0, x1
    // 0xd44bac: LeaveFrame
    //     0xd44bac: mov             SP, fp
    //     0xd44bb0: ldp             fp, lr, [SP], #0x10
    // 0xd44bb4: ret
    //     0xd44bb4: ret             
    // 0xd44bb8: ldr             x4, [fp, #0x10]
    // 0xd44bbc: ldur            x3, [fp, #-8]
    // 0xd44bc0: r0 = LoadClassIdInstr(r4)
    //     0xd44bc0: ldur            x0, [x4, #-1]
    //     0xd44bc4: ubfx            x0, x0, #0xc, #0x14
    // 0xd44bc8: mov             x1, x4
    // 0xd44bcc: r2 = Instance_WidgetState
    //     0xd44bcc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd44bd0: ldr             x2, [x2, #0xa50]
    // 0xd44bd4: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd44bd4: mov             x17, #0x2929
    //     0xd44bd8: movk            x17, #1, lsl #16
    //     0xd44bdc: add             lr, x0, x17
    //     0xd44be0: ldr             lr, [x21, lr, lsl #3]
    //     0xd44be4: blr             lr
    // 0xd44be8: tbnz            w0, #4, #0xd44c48
    // 0xd44bec: ldur            x3, [fp, #-8]
    // 0xd44bf0: LoadField: r1 = r3->field_f
    //     0xd44bf0: ldur            w1, [x3, #0xf]
    // 0xd44bf4: DecompressPointer r1
    //     0xd44bf4: add             x1, x1, HEAP, lsl #32
    // 0xd44bf8: LoadField: r0 = r1->field_33
    //     0xd44bf8: ldur            w0, [x1, #0x33]
    // 0xd44bfc: DecompressPointer r0
    //     0xd44bfc: add             x0, x0, HEAP, lsl #32
    // 0xd44c00: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd44c04: cmp             w0, w16
    // 0xd44c08: b.ne            #0xd44c18
    // 0xd44c0c: r2 = _colors
    //     0xd44c0c: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd44c10: ldr             x2, [x2, #0x1b8]
    // 0xd44c14: r0 = InitLateFinalInstanceField()
    //     0xd44c14: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd44c18: LoadField: r1 = r0->field_9f
    //     0xd44c18: ldur            w1, [x0, #0x9f]
    // 0xd44c1c: DecompressPointer r1
    //     0xd44c1c: add             x1, x1, HEAP, lsl #32
    // 0xd44c20: cmp             w1, NULL
    // 0xd44c24: b.ne            #0xd44c38
    // 0xd44c28: LoadField: r1 = r0->field_7b
    //     0xd44c28: ldur            w1, [x0, #0x7b]
    // 0xd44c2c: DecompressPointer r1
    //     0xd44c2c: add             x1, x1, HEAP, lsl #32
    // 0xd44c30: mov             x0, x1
    // 0xd44c34: b               #0xd44c3c
    // 0xd44c38: mov             x0, x1
    // 0xd44c3c: LeaveFrame
    //     0xd44c3c: mov             SP, fp
    //     0xd44c40: ldp             fp, lr, [SP], #0x10
    // 0xd44c44: ret
    //     0xd44c44: ret             
    // 0xd44c48: ldr             x1, [fp, #0x10]
    // 0xd44c4c: ldur            x3, [fp, #-8]
    // 0xd44c50: r0 = LoadClassIdInstr(r1)
    //     0xd44c50: ldur            x0, [x1, #-1]
    //     0xd44c54: ubfx            x0, x0, #0xc, #0x14
    // 0xd44c58: r2 = Instance_WidgetState
    //     0xd44c58: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd44c5c: ldr             x2, [x2, #0xa60]
    // 0xd44c60: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd44c60: mov             x17, #0x2929
    //     0xd44c64: movk            x17, #1, lsl #16
    //     0xd44c68: add             lr, x0, x17
    //     0xd44c6c: ldr             lr, [x21, lr, lsl #3]
    //     0xd44c70: blr             lr
    // 0xd44c74: tbnz            w0, #4, #0xd44cd4
    // 0xd44c78: ldur            x0, [fp, #-8]
    // 0xd44c7c: LoadField: r1 = r0->field_f
    //     0xd44c7c: ldur            w1, [x0, #0xf]
    // 0xd44c80: DecompressPointer r1
    //     0xd44c80: add             x1, x1, HEAP, lsl #32
    // 0xd44c84: LoadField: r0 = r1->field_33
    //     0xd44c84: ldur            w0, [x1, #0x33]
    // 0xd44c88: DecompressPointer r0
    //     0xd44c88: add             x0, x0, HEAP, lsl #32
    // 0xd44c8c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd44c90: cmp             w0, w16
    // 0xd44c94: b.ne            #0xd44ca4
    // 0xd44c98: r2 = _colors
    //     0xd44c98: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd44c9c: ldr             x2, [x2, #0x1b8]
    // 0xd44ca0: r0 = InitLateFinalInstanceField()
    //     0xd44ca0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd44ca4: LoadField: r1 = r0->field_9f
    //     0xd44ca4: ldur            w1, [x0, #0x9f]
    // 0xd44ca8: DecompressPointer r1
    //     0xd44ca8: add             x1, x1, HEAP, lsl #32
    // 0xd44cac: cmp             w1, NULL
    // 0xd44cb0: b.ne            #0xd44cc4
    // 0xd44cb4: LoadField: r1 = r0->field_7b
    //     0xd44cb4: ldur            w1, [x0, #0x7b]
    // 0xd44cb8: DecompressPointer r1
    //     0xd44cb8: add             x1, x1, HEAP, lsl #32
    // 0xd44cbc: mov             x0, x1
    // 0xd44cc0: b               #0xd44cc8
    // 0xd44cc4: mov             x0, x1
    // 0xd44cc8: LeaveFrame
    //     0xd44cc8: mov             SP, fp
    //     0xd44ccc: ldp             fp, lr, [SP], #0x10
    // 0xd44cd0: ret
    //     0xd44cd0: ret             
    // 0xd44cd4: ldur            x0, [fp, #-8]
    // 0xd44cd8: LoadField: r1 = r0->field_f
    //     0xd44cd8: ldur            w1, [x0, #0xf]
    // 0xd44cdc: DecompressPointer r1
    //     0xd44cdc: add             x1, x1, HEAP, lsl #32
    // 0xd44ce0: LoadField: r0 = r1->field_33
    //     0xd44ce0: ldur            w0, [x1, #0x33]
    // 0xd44ce4: DecompressPointer r0
    //     0xd44ce4: add             x0, x0, HEAP, lsl #32
    // 0xd44ce8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd44cec: cmp             w0, w16
    // 0xd44cf0: b.ne            #0xd44d00
    // 0xd44cf4: r2 = _colors
    //     0xd44cf4: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd44cf8: ldr             x2, [x2, #0x1b8]
    // 0xd44cfc: r0 = InitLateFinalInstanceField()
    //     0xd44cfc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd44d00: LoadField: r1 = r0->field_9f
    //     0xd44d00: ldur            w1, [x0, #0x9f]
    // 0xd44d04: DecompressPointer r1
    //     0xd44d04: add             x1, x1, HEAP, lsl #32
    // 0xd44d08: cmp             w1, NULL
    // 0xd44d0c: b.ne            #0xd44d20
    // 0xd44d10: LoadField: r2 = r0->field_7b
    //     0xd44d10: ldur            w2, [x0, #0x7b]
    // 0xd44d14: DecompressPointer r2
    //     0xd44d14: add             x2, x2, HEAP, lsl #32
    // 0xd44d18: mov             x0, x2
    // 0xd44d1c: b               #0xd44d24
    // 0xd44d20: mov             x0, x1
    // 0xd44d24: LeaveFrame
    //     0xd44d24: mov             SP, fp
    //     0xd44d28: ldp             fp, lr, [SP], #0x10
    // 0xd44d2c: ret
    //     0xd44d2c: ret             
    // 0xd44d30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd44d30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd44d34: b               #0xd44824
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd44f24, size: 0x570
    // 0xd44f24: EnterFrame
    //     0xd44f24: stp             fp, lr, [SP, #-0x10]!
    //     0xd44f28: mov             fp, SP
    // 0xd44f2c: AllocStack(0x8)
    //     0xd44f2c: sub             SP, SP, #8
    // 0xd44f30: SetupParameters([dynamic _ /* r0 */])
    //     0xd44f30: ldr             x0, [fp, #0x18]
    //     0xd44f34: ldur            w3, [x0, #0x17]
    //     0xd44f38: add             x3, x3, HEAP, lsl #32
    //     0xd44f3c: stur            x3, [fp, #-8]
    // 0xd44f40: CheckStackOverflow
    //     0xd44f40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd44f44: cmp             SP, x16
    //     0xd44f48: b.ls            #0xd4548c
    // 0xd44f4c: ldr             x4, [fp, #0x10]
    // 0xd44f50: r0 = LoadClassIdInstr(r4)
    //     0xd44f50: ldur            x0, [x4, #-1]
    //     0xd44f54: ubfx            x0, x0, #0xc, #0x14
    // 0xd44f58: mov             x1, x4
    // 0xd44f5c: r2 = Instance_WidgetState
    //     0xd44f5c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd44f60: ldr             x2, [x2, #0xa70]
    // 0xd44f64: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd44f64: mov             x17, #0x2929
    //     0xd44f68: movk            x17, #1, lsl #16
    //     0xd44f6c: add             lr, x0, x17
    //     0xd44f70: ldr             lr, [x21, lr, lsl #3]
    //     0xd44f74: blr             lr
    // 0xd44f78: tbnz            w0, #4, #0xd45060
    // 0xd44f7c: ldr             x3, [fp, #0x10]
    // 0xd44f80: r0 = LoadClassIdInstr(r3)
    //     0xd44f80: ldur            x0, [x3, #-1]
    //     0xd44f84: ubfx            x0, x0, #0xc, #0x14
    // 0xd44f88: mov             x1, x3
    // 0xd44f8c: r2 = Instance_WidgetState
    //     0xd44f8c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd44f90: ldr             x2, [x2, #0x100]
    // 0xd44f94: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd44f94: mov             x17, #0x2929
    //     0xd44f98: movk            x17, #1, lsl #16
    //     0xd44f9c: add             lr, x0, x17
    //     0xd44fa0: ldr             lr, [x21, lr, lsl #3]
    //     0xd44fa4: blr             lr
    // 0xd44fa8: tbnz            w0, #4, #0xd45004
    // 0xd44fac: ldur            x4, [fp, #-8]
    // 0xd44fb0: LoadField: r1 = r4->field_f
    //     0xd44fb0: ldur            w1, [x4, #0xf]
    // 0xd44fb4: DecompressPointer r1
    //     0xd44fb4: add             x1, x1, HEAP, lsl #32
    // 0xd44fb8: LoadField: r0 = r1->field_33
    //     0xd44fb8: ldur            w0, [x1, #0x33]
    // 0xd44fbc: DecompressPointer r0
    //     0xd44fbc: add             x0, x0, HEAP, lsl #32
    // 0xd44fc0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd44fc4: cmp             w0, w16
    // 0xd44fc8: b.ne            #0xd44fd8
    // 0xd44fcc: r2 = _colors
    //     0xd44fcc: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd44fd0: ldr             x2, [x2, #0x1b8]
    // 0xd44fd4: r0 = InitLateFinalInstanceField()
    //     0xd44fd4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd44fd8: LoadField: r1 = r0->field_7b
    //     0xd44fd8: ldur            w1, [x0, #0x7b]
    // 0xd44fdc: DecompressPointer r1
    //     0xd44fdc: add             x1, x1, HEAP, lsl #32
    // 0xd44fe0: r0 = LoadClassIdInstr(r1)
    //     0xd44fe0: ldur            x0, [x1, #-1]
    //     0xd44fe4: ubfx            x0, x0, #0xc, #0x14
    // 0xd44fe8: d0 = 1.000000
    //     0xd44fe8: fmov            d0, #1.00000000
    // 0xd44fec: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd44fec: sub             lr, x0, #1, lsl #12
    //     0xd44ff0: ldr             lr, [x21, lr, lsl #3]
    //     0xd44ff4: blr             lr
    // 0xd44ff8: LeaveFrame
    //     0xd44ff8: mov             SP, fp
    //     0xd44ffc: ldp             fp, lr, [SP], #0x10
    // 0xd45000: ret
    //     0xd45000: ret             
    // 0xd45004: ldur            x4, [fp, #-8]
    // 0xd45008: LoadField: r1 = r4->field_f
    //     0xd45008: ldur            w1, [x4, #0xf]
    // 0xd4500c: DecompressPointer r1
    //     0xd4500c: add             x1, x1, HEAP, lsl #32
    // 0xd45010: LoadField: r0 = r1->field_33
    //     0xd45010: ldur            w0, [x1, #0x33]
    // 0xd45014: DecompressPointer r0
    //     0xd45014: add             x0, x0, HEAP, lsl #32
    // 0xd45018: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd4501c: cmp             w0, w16
    // 0xd45020: b.ne            #0xd45030
    // 0xd45024: r2 = _colors
    //     0xd45024: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd45028: ldr             x2, [x2, #0x1b8]
    // 0xd4502c: r0 = InitLateFinalInstanceField()
    //     0xd4502c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd45030: LoadField: r1 = r0->field_7f
    //     0xd45030: ldur            w1, [x0, #0x7f]
    // 0xd45034: DecompressPointer r1
    //     0xd45034: add             x1, x1, HEAP, lsl #32
    // 0xd45038: r0 = LoadClassIdInstr(r1)
    //     0xd45038: ldur            x0, [x1, #-1]
    //     0xd4503c: ubfx            x0, x0, #0xc, #0x14
    // 0xd45040: d0 = 0.380000
    //     0xd45040: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xd45044: ldr             d0, [x17, #0x1f0]
    // 0xd45048: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd45048: sub             lr, x0, #1, lsl #12
    //     0xd4504c: ldr             lr, [x21, lr, lsl #3]
    //     0xd45050: blr             lr
    // 0xd45054: LeaveFrame
    //     0xd45054: mov             SP, fp
    //     0xd45058: ldp             fp, lr, [SP], #0x10
    // 0xd4505c: ret
    //     0xd4505c: ret             
    // 0xd45060: ldr             x3, [fp, #0x10]
    // 0xd45064: ldur            x4, [fp, #-8]
    // 0xd45068: r0 = LoadClassIdInstr(r3)
    //     0xd45068: ldur            x0, [x3, #-1]
    //     0xd4506c: ubfx            x0, x0, #0xc, #0x14
    // 0xd45070: mov             x1, x3
    // 0xd45074: r2 = Instance_WidgetState
    //     0xd45074: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd45078: ldr             x2, [x2, #0x100]
    // 0xd4507c: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd4507c: mov             x17, #0x2929
    //     0xd45080: movk            x17, #1, lsl #16
    //     0xd45084: add             lr, x0, x17
    //     0xd45088: ldr             lr, [x21, lr, lsl #3]
    //     0xd4508c: blr             lr
    // 0xd45090: tbnz            w0, #4, #0xd45284
    // 0xd45094: ldr             x3, [fp, #0x10]
    // 0xd45098: r0 = LoadClassIdInstr(r3)
    //     0xd45098: ldur            x0, [x3, #-1]
    //     0xd4509c: ubfx            x0, x0, #0xc, #0x14
    // 0xd450a0: mov             x1, x3
    // 0xd450a4: r2 = Instance_WidgetState
    //     0xd450a4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd450a8: ldr             x2, [x2, #0xa48]
    // 0xd450ac: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd450ac: mov             x17, #0x2929
    //     0xd450b0: movk            x17, #1, lsl #16
    //     0xd450b4: add             lr, x0, x17
    //     0xd450b8: ldr             lr, [x21, lr, lsl #3]
    //     0xd450bc: blr             lr
    // 0xd450c0: tbnz            w0, #4, #0xd45120
    // 0xd450c4: ldur            x3, [fp, #-8]
    // 0xd450c8: LoadField: r1 = r3->field_f
    //     0xd450c8: ldur            w1, [x3, #0xf]
    // 0xd450cc: DecompressPointer r1
    //     0xd450cc: add             x1, x1, HEAP, lsl #32
    // 0xd450d0: LoadField: r0 = r1->field_33
    //     0xd450d0: ldur            w0, [x1, #0x33]
    // 0xd450d4: DecompressPointer r0
    //     0xd450d4: add             x0, x0, HEAP, lsl #32
    // 0xd450d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd450dc: cmp             w0, w16
    // 0xd450e0: b.ne            #0xd450f0
    // 0xd450e4: r2 = _colors
    //     0xd450e4: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd450e8: ldr             x2, [x2, #0x1b8]
    // 0xd450ec: r0 = InitLateFinalInstanceField()
    //     0xd450ec: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd450f0: LoadField: r1 = r0->field_13
    //     0xd450f0: ldur            w1, [x0, #0x13]
    // 0xd450f4: DecompressPointer r1
    //     0xd450f4: add             x1, x1, HEAP, lsl #32
    // 0xd450f8: cmp             w1, NULL
    // 0xd450fc: b.ne            #0xd45110
    // 0xd45100: LoadField: r1 = r0->field_b
    //     0xd45100: ldur            w1, [x0, #0xb]
    // 0xd45104: DecompressPointer r1
    //     0xd45104: add             x1, x1, HEAP, lsl #32
    // 0xd45108: mov             x0, x1
    // 0xd4510c: b               #0xd45114
    // 0xd45110: mov             x0, x1
    // 0xd45114: LeaveFrame
    //     0xd45114: mov             SP, fp
    //     0xd45118: ldp             fp, lr, [SP], #0x10
    // 0xd4511c: ret
    //     0xd4511c: ret             
    // 0xd45120: ldr             x4, [fp, #0x10]
    // 0xd45124: ldur            x3, [fp, #-8]
    // 0xd45128: r0 = LoadClassIdInstr(r4)
    //     0xd45128: ldur            x0, [x4, #-1]
    //     0xd4512c: ubfx            x0, x0, #0xc, #0x14
    // 0xd45130: mov             x1, x4
    // 0xd45134: r2 = Instance_WidgetState
    //     0xd45134: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd45138: ldr             x2, [x2, #0xa50]
    // 0xd4513c: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd4513c: mov             x17, #0x2929
    //     0xd45140: movk            x17, #1, lsl #16
    //     0xd45144: add             lr, x0, x17
    //     0xd45148: ldr             lr, [x21, lr, lsl #3]
    //     0xd4514c: blr             lr
    // 0xd45150: tbnz            w0, #4, #0xd451b0
    // 0xd45154: ldur            x3, [fp, #-8]
    // 0xd45158: LoadField: r1 = r3->field_f
    //     0xd45158: ldur            w1, [x3, #0xf]
    // 0xd4515c: DecompressPointer r1
    //     0xd4515c: add             x1, x1, HEAP, lsl #32
    // 0xd45160: LoadField: r0 = r1->field_33
    //     0xd45160: ldur            w0, [x1, #0x33]
    // 0xd45164: DecompressPointer r0
    //     0xd45164: add             x0, x0, HEAP, lsl #32
    // 0xd45168: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd4516c: cmp             w0, w16
    // 0xd45170: b.ne            #0xd45180
    // 0xd45174: r2 = _colors
    //     0xd45174: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd45178: ldr             x2, [x2, #0x1b8]
    // 0xd4517c: r0 = InitLateFinalInstanceField()
    //     0xd4517c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd45180: LoadField: r1 = r0->field_13
    //     0xd45180: ldur            w1, [x0, #0x13]
    // 0xd45184: DecompressPointer r1
    //     0xd45184: add             x1, x1, HEAP, lsl #32
    // 0xd45188: cmp             w1, NULL
    // 0xd4518c: b.ne            #0xd451a0
    // 0xd45190: LoadField: r1 = r0->field_b
    //     0xd45190: ldur            w1, [x0, #0xb]
    // 0xd45194: DecompressPointer r1
    //     0xd45194: add             x1, x1, HEAP, lsl #32
    // 0xd45198: mov             x0, x1
    // 0xd4519c: b               #0xd451a4
    // 0xd451a0: mov             x0, x1
    // 0xd451a4: LeaveFrame
    //     0xd451a4: mov             SP, fp
    //     0xd451a8: ldp             fp, lr, [SP], #0x10
    // 0xd451ac: ret
    //     0xd451ac: ret             
    // 0xd451b0: ldr             x4, [fp, #0x10]
    // 0xd451b4: ldur            x3, [fp, #-8]
    // 0xd451b8: r0 = LoadClassIdInstr(r4)
    //     0xd451b8: ldur            x0, [x4, #-1]
    //     0xd451bc: ubfx            x0, x0, #0xc, #0x14
    // 0xd451c0: mov             x1, x4
    // 0xd451c4: r2 = Instance_WidgetState
    //     0xd451c4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd451c8: ldr             x2, [x2, #0xa60]
    // 0xd451cc: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd451cc: mov             x17, #0x2929
    //     0xd451d0: movk            x17, #1, lsl #16
    //     0xd451d4: add             lr, x0, x17
    //     0xd451d8: ldr             lr, [x21, lr, lsl #3]
    //     0xd451dc: blr             lr
    // 0xd451e0: tbnz            w0, #4, #0xd45240
    // 0xd451e4: ldur            x3, [fp, #-8]
    // 0xd451e8: LoadField: r1 = r3->field_f
    //     0xd451e8: ldur            w1, [x3, #0xf]
    // 0xd451ec: DecompressPointer r1
    //     0xd451ec: add             x1, x1, HEAP, lsl #32
    // 0xd451f0: LoadField: r0 = r1->field_33
    //     0xd451f0: ldur            w0, [x1, #0x33]
    // 0xd451f4: DecompressPointer r0
    //     0xd451f4: add             x0, x0, HEAP, lsl #32
    // 0xd451f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd451fc: cmp             w0, w16
    // 0xd45200: b.ne            #0xd45210
    // 0xd45204: r2 = _colors
    //     0xd45204: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd45208: ldr             x2, [x2, #0x1b8]
    // 0xd4520c: r0 = InitLateFinalInstanceField()
    //     0xd4520c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd45210: LoadField: r1 = r0->field_13
    //     0xd45210: ldur            w1, [x0, #0x13]
    // 0xd45214: DecompressPointer r1
    //     0xd45214: add             x1, x1, HEAP, lsl #32
    // 0xd45218: cmp             w1, NULL
    // 0xd4521c: b.ne            #0xd45230
    // 0xd45220: LoadField: r1 = r0->field_b
    //     0xd45220: ldur            w1, [x0, #0xb]
    // 0xd45224: DecompressPointer r1
    //     0xd45224: add             x1, x1, HEAP, lsl #32
    // 0xd45228: mov             x0, x1
    // 0xd4522c: b               #0xd45234
    // 0xd45230: mov             x0, x1
    // 0xd45234: LeaveFrame
    //     0xd45234: mov             SP, fp
    //     0xd45238: ldp             fp, lr, [SP], #0x10
    // 0xd4523c: ret
    //     0xd4523c: ret             
    // 0xd45240: ldur            x3, [fp, #-8]
    // 0xd45244: LoadField: r1 = r3->field_f
    //     0xd45244: ldur            w1, [x3, #0xf]
    // 0xd45248: DecompressPointer r1
    //     0xd45248: add             x1, x1, HEAP, lsl #32
    // 0xd4524c: LoadField: r0 = r1->field_33
    //     0xd4524c: ldur            w0, [x1, #0x33]
    // 0xd45250: DecompressPointer r0
    //     0xd45250: add             x0, x0, HEAP, lsl #32
    // 0xd45254: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd45258: cmp             w0, w16
    // 0xd4525c: b.ne            #0xd4526c
    // 0xd45260: r2 = _colors
    //     0xd45260: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd45264: ldr             x2, [x2, #0x1b8]
    // 0xd45268: r0 = InitLateFinalInstanceField()
    //     0xd45268: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd4526c: LoadField: r1 = r0->field_f
    //     0xd4526c: ldur            w1, [x0, #0xf]
    // 0xd45270: DecompressPointer r1
    //     0xd45270: add             x1, x1, HEAP, lsl #32
    // 0xd45274: mov             x0, x1
    // 0xd45278: LeaveFrame
    //     0xd45278: mov             SP, fp
    //     0xd4527c: ldp             fp, lr, [SP], #0x10
    // 0xd45280: ret
    //     0xd45280: ret             
    // 0xd45284: ldr             x4, [fp, #0x10]
    // 0xd45288: ldur            x3, [fp, #-8]
    // 0xd4528c: r0 = LoadClassIdInstr(r4)
    //     0xd4528c: ldur            x0, [x4, #-1]
    //     0xd45290: ubfx            x0, x0, #0xc, #0x14
    // 0xd45294: mov             x1, x4
    // 0xd45298: r2 = Instance_WidgetState
    //     0xd45298: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd4529c: ldr             x2, [x2, #0xa48]
    // 0xd452a0: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd452a0: mov             x17, #0x2929
    //     0xd452a4: movk            x17, #1, lsl #16
    //     0xd452a8: add             lr, x0, x17
    //     0xd452ac: ldr             lr, [x21, lr, lsl #3]
    //     0xd452b0: blr             lr
    // 0xd452b4: tbnz            w0, #4, #0xd45314
    // 0xd452b8: ldur            x3, [fp, #-8]
    // 0xd452bc: LoadField: r1 = r3->field_f
    //     0xd452bc: ldur            w1, [x3, #0xf]
    // 0xd452c0: DecompressPointer r1
    //     0xd452c0: add             x1, x1, HEAP, lsl #32
    // 0xd452c4: LoadField: r0 = r1->field_33
    //     0xd452c4: ldur            w0, [x1, #0x33]
    // 0xd452c8: DecompressPointer r0
    //     0xd452c8: add             x0, x0, HEAP, lsl #32
    // 0xd452cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd452d0: cmp             w0, w16
    // 0xd452d4: b.ne            #0xd452e4
    // 0xd452d8: r2 = _colors
    //     0xd452d8: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd452dc: ldr             x2, [x2, #0x1b8]
    // 0xd452e0: r0 = InitLateFinalInstanceField()
    //     0xd452e0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd452e4: LoadField: r1 = r0->field_a3
    //     0xd452e4: ldur            w1, [x0, #0xa3]
    // 0xd452e8: DecompressPointer r1
    //     0xd452e8: add             x1, x1, HEAP, lsl #32
    // 0xd452ec: cmp             w1, NULL
    // 0xd452f0: b.ne            #0xd45304
    // 0xd452f4: LoadField: r1 = r0->field_7f
    //     0xd452f4: ldur            w1, [x0, #0x7f]
    // 0xd452f8: DecompressPointer r1
    //     0xd452f8: add             x1, x1, HEAP, lsl #32
    // 0xd452fc: mov             x0, x1
    // 0xd45300: b               #0xd45308
    // 0xd45304: mov             x0, x1
    // 0xd45308: LeaveFrame
    //     0xd45308: mov             SP, fp
    //     0xd4530c: ldp             fp, lr, [SP], #0x10
    // 0xd45310: ret
    //     0xd45310: ret             
    // 0xd45314: ldr             x4, [fp, #0x10]
    // 0xd45318: ldur            x3, [fp, #-8]
    // 0xd4531c: r0 = LoadClassIdInstr(r4)
    //     0xd4531c: ldur            x0, [x4, #-1]
    //     0xd45320: ubfx            x0, x0, #0xc, #0x14
    // 0xd45324: mov             x1, x4
    // 0xd45328: r2 = Instance_WidgetState
    //     0xd45328: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd4532c: ldr             x2, [x2, #0xa50]
    // 0xd45330: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd45330: mov             x17, #0x2929
    //     0xd45334: movk            x17, #1, lsl #16
    //     0xd45338: add             lr, x0, x17
    //     0xd4533c: ldr             lr, [x21, lr, lsl #3]
    //     0xd45340: blr             lr
    // 0xd45344: tbnz            w0, #4, #0xd453a4
    // 0xd45348: ldur            x3, [fp, #-8]
    // 0xd4534c: LoadField: r1 = r3->field_f
    //     0xd4534c: ldur            w1, [x3, #0xf]
    // 0xd45350: DecompressPointer r1
    //     0xd45350: add             x1, x1, HEAP, lsl #32
    // 0xd45354: LoadField: r0 = r1->field_33
    //     0xd45354: ldur            w0, [x1, #0x33]
    // 0xd45358: DecompressPointer r0
    //     0xd45358: add             x0, x0, HEAP, lsl #32
    // 0xd4535c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd45360: cmp             w0, w16
    // 0xd45364: b.ne            #0xd45374
    // 0xd45368: r2 = _colors
    //     0xd45368: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd4536c: ldr             x2, [x2, #0x1b8]
    // 0xd45370: r0 = InitLateFinalInstanceField()
    //     0xd45370: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd45374: LoadField: r1 = r0->field_a3
    //     0xd45374: ldur            w1, [x0, #0xa3]
    // 0xd45378: DecompressPointer r1
    //     0xd45378: add             x1, x1, HEAP, lsl #32
    // 0xd4537c: cmp             w1, NULL
    // 0xd45380: b.ne            #0xd45394
    // 0xd45384: LoadField: r1 = r0->field_7f
    //     0xd45384: ldur            w1, [x0, #0x7f]
    // 0xd45388: DecompressPointer r1
    //     0xd45388: add             x1, x1, HEAP, lsl #32
    // 0xd4538c: mov             x0, x1
    // 0xd45390: b               #0xd45398
    // 0xd45394: mov             x0, x1
    // 0xd45398: LeaveFrame
    //     0xd45398: mov             SP, fp
    //     0xd4539c: ldp             fp, lr, [SP], #0x10
    // 0xd453a0: ret
    //     0xd453a0: ret             
    // 0xd453a4: ldr             x1, [fp, #0x10]
    // 0xd453a8: ldur            x3, [fp, #-8]
    // 0xd453ac: r0 = LoadClassIdInstr(r1)
    //     0xd453ac: ldur            x0, [x1, #-1]
    //     0xd453b0: ubfx            x0, x0, #0xc, #0x14
    // 0xd453b4: r2 = Instance_WidgetState
    //     0xd453b4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd453b8: ldr             x2, [x2, #0xa60]
    // 0xd453bc: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd453bc: mov             x17, #0x2929
    //     0xd453c0: movk            x17, #1, lsl #16
    //     0xd453c4: add             lr, x0, x17
    //     0xd453c8: ldr             lr, [x21, lr, lsl #3]
    //     0xd453cc: blr             lr
    // 0xd453d0: tbnz            w0, #4, #0xd45430
    // 0xd453d4: ldur            x0, [fp, #-8]
    // 0xd453d8: LoadField: r1 = r0->field_f
    //     0xd453d8: ldur            w1, [x0, #0xf]
    // 0xd453dc: DecompressPointer r1
    //     0xd453dc: add             x1, x1, HEAP, lsl #32
    // 0xd453e0: LoadField: r0 = r1->field_33
    //     0xd453e0: ldur            w0, [x1, #0x33]
    // 0xd453e4: DecompressPointer r0
    //     0xd453e4: add             x0, x0, HEAP, lsl #32
    // 0xd453e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd453ec: cmp             w0, w16
    // 0xd453f0: b.ne            #0xd45400
    // 0xd453f4: r2 = _colors
    //     0xd453f4: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd453f8: ldr             x2, [x2, #0x1b8]
    // 0xd453fc: r0 = InitLateFinalInstanceField()
    //     0xd453fc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd45400: LoadField: r1 = r0->field_a3
    //     0xd45400: ldur            w1, [x0, #0xa3]
    // 0xd45404: DecompressPointer r1
    //     0xd45404: add             x1, x1, HEAP, lsl #32
    // 0xd45408: cmp             w1, NULL
    // 0xd4540c: b.ne            #0xd45420
    // 0xd45410: LoadField: r1 = r0->field_7f
    //     0xd45410: ldur            w1, [x0, #0x7f]
    // 0xd45414: DecompressPointer r1
    //     0xd45414: add             x1, x1, HEAP, lsl #32
    // 0xd45418: mov             x0, x1
    // 0xd4541c: b               #0xd45424
    // 0xd45420: mov             x0, x1
    // 0xd45424: LeaveFrame
    //     0xd45424: mov             SP, fp
    //     0xd45428: ldp             fp, lr, [SP], #0x10
    // 0xd4542c: ret
    //     0xd4542c: ret             
    // 0xd45430: ldur            x0, [fp, #-8]
    // 0xd45434: LoadField: r1 = r0->field_f
    //     0xd45434: ldur            w1, [x0, #0xf]
    // 0xd45438: DecompressPointer r1
    //     0xd45438: add             x1, x1, HEAP, lsl #32
    // 0xd4543c: LoadField: r0 = r1->field_33
    //     0xd4543c: ldur            w0, [x1, #0x33]
    // 0xd45440: DecompressPointer r0
    //     0xd45440: add             x0, x0, HEAP, lsl #32
    // 0xd45444: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd45448: cmp             w0, w16
    // 0xd4544c: b.ne            #0xd4545c
    // 0xd45450: r2 = _colors
    //     0xd45450: add             x2, PP, #0x26, lsl #12  ; [pp+0x261b8] Field <_SwitchDefaultsM3@127328938._colors@127328938>: late final (offset: 0x34)
    //     0xd45454: ldr             x2, [x2, #0x1b8]
    // 0xd45458: r0 = InitLateFinalInstanceField()
    //     0xd45458: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd4545c: LoadField: r1 = r0->field_a7
    //     0xd4545c: ldur            w1, [x0, #0xa7]
    // 0xd45460: DecompressPointer r1
    //     0xd45460: add             x1, x1, HEAP, lsl #32
    // 0xd45464: cmp             w1, NULL
    // 0xd45468: b.ne            #0xd4547c
    // 0xd4546c: LoadField: r2 = r0->field_cb
    //     0xd4546c: ldur            w2, [x0, #0xcb]
    // 0xd45470: DecompressPointer r2
    //     0xd45470: add             x2, x2, HEAP, lsl #32
    // 0xd45474: mov             x0, x2
    // 0xd45478: b               #0xd45480
    // 0xd4547c: mov             x0, x1
    // 0xd45480: LeaveFrame
    //     0xd45480: mov             SP, fp
    //     0xd45484: ldp             fp, lr, [SP], #0x10
    // 0xd45488: ret
    //     0xd45488: ret             
    // 0xd4548c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4548c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd45490: b               #0xd44f4c
  }
}

// class id: 5064, size: 0x38, field offset: 0x30
class _SwitchDefaultsM2 extends SwitchThemeData {

  [closure] Color? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd43f64, size: 0x170
    // 0xd43f64: EnterFrame
    //     0xd43f64: stp             fp, lr, [SP, #-0x10]!
    //     0xd43f68: mov             fp, SP
    // 0xd43f6c: AllocStack(0x8)
    //     0xd43f6c: sub             SP, SP, #8
    // 0xd43f70: SetupParameters([dynamic _ /* r0 */])
    //     0xd43f70: ldr             x0, [fp, #0x18]
    //     0xd43f74: ldur            w3, [x0, #0x17]
    //     0xd43f78: add             x3, x3, HEAP, lsl #32
    //     0xd43f7c: stur            x3, [fp, #-8]
    // 0xd43f80: CheckStackOverflow
    //     0xd43f80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd43f84: cmp             SP, x16
    //     0xd43f88: b.ls            #0xd440cc
    // 0xd43f8c: ldr             x4, [fp, #0x10]
    // 0xd43f90: r0 = LoadClassIdInstr(r4)
    //     0xd43f90: ldur            x0, [x4, #-1]
    //     0xd43f94: ubfx            x0, x0, #0xc, #0x14
    // 0xd43f98: mov             x1, x4
    // 0xd43f9c: r2 = Instance_WidgetState
    //     0xd43f9c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd43fa0: ldr             x2, [x2, #0xa48]
    // 0xd43fa4: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd43fa4: mov             x17, #0x2929
    //     0xd43fa8: movk            x17, #1, lsl #16
    //     0xd43fac: add             lr, x0, x17
    //     0xd43fb0: ldr             lr, [x21, lr, lsl #3]
    //     0xd43fb4: blr             lr
    // 0xd43fb8: tbnz            w0, #4, #0xd44008
    // 0xd43fbc: ldur            x3, [fp, #-8]
    // 0xd43fc0: LoadField: r1 = r3->field_f
    //     0xd43fc0: ldur            w1, [x3, #0xf]
    // 0xd43fc4: DecompressPointer r1
    //     0xd43fc4: add             x1, x1, HEAP, lsl #32
    // 0xd43fc8: r0 = thumbColor()
    //     0xd43fc8: bl              #0x129d570  ; [package:flutter/src/material/switch.dart] _SwitchDefaultsM2::thumbColor
    // 0xd43fcc: mov             x1, x0
    // 0xd43fd0: ldr             x2, [fp, #0x10]
    // 0xd43fd4: r0 = build()
    //     0xd43fd4: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd43fd8: r1 = LoadClassIdInstr(r0)
    //     0xd43fd8: ldur            x1, [x0, #-1]
    //     0xd43fdc: ubfx            x1, x1, #0xc, #0x14
    // 0xd43fe0: mov             x16, x0
    // 0xd43fe4: mov             x0, x1
    // 0xd43fe8: mov             x1, x16
    // 0xd43fec: r2 = 31
    //     0xd43fec: mov             x2, #0x1f
    // 0xd43ff0: r0 = GDT[cid_x0 + -0xff4]()
    //     0xd43ff0: sub             lr, x0, #0xff4
    //     0xd43ff4: ldr             lr, [x21, lr, lsl #3]
    //     0xd43ff8: blr             lr
    // 0xd43ffc: LeaveFrame
    //     0xd43ffc: mov             SP, fp
    //     0xd44000: ldp             fp, lr, [SP], #0x10
    // 0xd44004: ret
    //     0xd44004: ret             
    // 0xd44008: ldr             x4, [fp, #0x10]
    // 0xd4400c: ldur            x3, [fp, #-8]
    // 0xd44010: r0 = LoadClassIdInstr(r4)
    //     0xd44010: ldur            x0, [x4, #-1]
    //     0xd44014: ubfx            x0, x0, #0xc, #0x14
    // 0xd44018: mov             x1, x4
    // 0xd4401c: r2 = Instance_WidgetState
    //     0xd4401c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd44020: ldr             x2, [x2, #0xa50]
    // 0xd44024: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd44024: mov             x17, #0x2929
    //     0xd44028: movk            x17, #1, lsl #16
    //     0xd4402c: add             lr, x0, x17
    //     0xd44030: ldr             lr, [x21, lr, lsl #3]
    //     0xd44034: blr             lr
    // 0xd44038: tbnz            w0, #4, #0xd44064
    // 0xd4403c: ldur            x3, [fp, #-8]
    // 0xd44040: LoadField: r0 = r3->field_f
    //     0xd44040: ldur            w0, [x3, #0xf]
    // 0xd44044: DecompressPointer r0
    //     0xd44044: add             x0, x0, HEAP, lsl #32
    // 0xd44048: LoadField: r1 = r0->field_2f
    //     0xd44048: ldur            w1, [x0, #0x2f]
    // 0xd4404c: DecompressPointer r1
    //     0xd4404c: add             x1, x1, HEAP, lsl #32
    // 0xd44050: LoadField: r0 = r1->field_57
    //     0xd44050: ldur            w0, [x1, #0x57]
    // 0xd44054: DecompressPointer r0
    //     0xd44054: add             x0, x0, HEAP, lsl #32
    // 0xd44058: LeaveFrame
    //     0xd44058: mov             SP, fp
    //     0xd4405c: ldp             fp, lr, [SP], #0x10
    // 0xd44060: ret
    //     0xd44060: ret             
    // 0xd44064: ldr             x1, [fp, #0x10]
    // 0xd44068: ldur            x3, [fp, #-8]
    // 0xd4406c: r0 = LoadClassIdInstr(r1)
    //     0xd4406c: ldur            x0, [x1, #-1]
    //     0xd44070: ubfx            x0, x0, #0xc, #0x14
    // 0xd44074: r2 = Instance_WidgetState
    //     0xd44074: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd44078: ldr             x2, [x2, #0xa60]
    // 0xd4407c: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd4407c: mov             x17, #0x2929
    //     0xd44080: movk            x17, #1, lsl #16
    //     0xd44084: add             lr, x0, x17
    //     0xd44088: ldr             lr, [x21, lr, lsl #3]
    //     0xd4408c: blr             lr
    // 0xd44090: tbnz            w0, #4, #0xd440bc
    // 0xd44094: ldur            x1, [fp, #-8]
    // 0xd44098: LoadField: r2 = r1->field_f
    //     0xd44098: ldur            w2, [x1, #0xf]
    // 0xd4409c: DecompressPointer r2
    //     0xd4409c: add             x2, x2, HEAP, lsl #32
    // 0xd440a0: LoadField: r1 = r2->field_2f
    //     0xd440a0: ldur            w1, [x2, #0x2f]
    // 0xd440a4: DecompressPointer r1
    //     0xd440a4: add             x1, x1, HEAP, lsl #32
    // 0xd440a8: LoadField: r0 = r1->field_4b
    //     0xd440a8: ldur            w0, [x1, #0x4b]
    // 0xd440ac: DecompressPointer r0
    //     0xd440ac: add             x0, x0, HEAP, lsl #32
    // 0xd440b0: LeaveFrame
    //     0xd440b0: mov             SP, fp
    //     0xd440b4: ldp             fp, lr, [SP], #0x10
    // 0xd440b8: ret
    //     0xd440b8: ret             
    // 0xd440bc: r0 = Null
    //     0xd440bc: mov             x0, NULL
    // 0xd440c0: LeaveFrame
    //     0xd440c0: mov             SP, fp
    //     0xd440c4: ldp             fp, lr, [SP], #0x10
    // 0xd440c8: ret
    //     0xd440c8: ret             
    // 0xd440cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd440cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd440d0: b               #0xd43f8c
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd446cc, size: 0x130
    // 0xd446cc: EnterFrame
    //     0xd446cc: stp             fp, lr, [SP, #-0x10]!
    //     0xd446d0: mov             fp, SP
    // 0xd446d4: AllocStack(0x8)
    //     0xd446d4: sub             SP, SP, #8
    // 0xd446d8: SetupParameters([dynamic _ /* r0 */])
    //     0xd446d8: ldr             x0, [fp, #0x18]
    //     0xd446dc: ldur            w3, [x0, #0x17]
    //     0xd446e0: add             x3, x3, HEAP, lsl #32
    //     0xd446e4: stur            x3, [fp, #-8]
    // 0xd446e8: CheckStackOverflow
    //     0xd446e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd446ec: cmp             SP, x16
    //     0xd446f0: b.ls            #0xd447f4
    // 0xd446f4: ldr             x4, [fp, #0x10]
    // 0xd446f8: r0 = LoadClassIdInstr(r4)
    //     0xd446f8: ldur            x0, [x4, #-1]
    //     0xd446fc: ubfx            x0, x0, #0xc, #0x14
    // 0xd44700: mov             x1, x4
    // 0xd44704: r2 = Instance_WidgetState
    //     0xd44704: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd44708: ldr             x2, [x2, #0xa70]
    // 0xd4470c: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd4470c: mov             x17, #0x2929
    //     0xd44710: movk            x17, #1, lsl #16
    //     0xd44714: add             lr, x0, x17
    //     0xd44718: ldr             lr, [x21, lr, lsl #3]
    //     0xd4471c: blr             lr
    // 0xd44720: tbnz            w0, #4, #0xd44754
    // 0xd44724: ldur            x3, [fp, #-8]
    // 0xd44728: LoadField: r0 = r3->field_13
    //     0xd44728: ldur            w0, [x3, #0x13]
    // 0xd4472c: DecompressPointer r0
    //     0xd4472c: add             x0, x0, HEAP, lsl #32
    // 0xd44730: tbnz            w0, #4, #0xd44740
    // 0xd44734: r0 = Instance_Color
    //     0xd44734: add             x0, PP, #0x26, lsl #12  ; [pp+0x261d8] Obj!Color@12a2b81
    //     0xd44738: ldr             x0, [x0, #0x1d8]
    // 0xd4473c: b               #0xd44748
    // 0xd44740: r0 = Instance_Color
    //     0xd44740: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c58] Obj!Color@12a1a41
    //     0xd44744: ldr             x0, [x0, #0xc58]
    // 0xd44748: LeaveFrame
    //     0xd44748: mov             SP, fp
    //     0xd4474c: ldp             fp, lr, [SP], #0x10
    // 0xd44750: ret
    //     0xd44750: ret             
    // 0xd44754: ldr             x1, [fp, #0x10]
    // 0xd44758: ldur            x3, [fp, #-8]
    // 0xd4475c: r0 = LoadClassIdInstr(r1)
    //     0xd4475c: ldur            x0, [x1, #-1]
    //     0xd44760: ubfx            x0, x0, #0xc, #0x14
    // 0xd44764: r2 = Instance_WidgetState
    //     0xd44764: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd44768: ldr             x2, [x2, #0x100]
    // 0xd4476c: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd4476c: mov             x17, #0x2929
    //     0xd44770: movk            x17, #1, lsl #16
    //     0xd44774: add             lr, x0, x17
    //     0xd44778: ldr             lr, [x21, lr, lsl #3]
    //     0xd4477c: blr             lr
    // 0xd44780: tbnz            w0, #4, #0xd447c4
    // 0xd44784: ldur            x0, [fp, #-8]
    // 0xd44788: LoadField: r1 = r0->field_f
    //     0xd44788: ldur            w1, [x0, #0xf]
    // 0xd4478c: DecompressPointer r1
    //     0xd4478c: add             x1, x1, HEAP, lsl #32
    // 0xd44790: LoadField: r0 = r1->field_33
    //     0xd44790: ldur            w0, [x1, #0x33]
    // 0xd44794: DecompressPointer r0
    //     0xd44794: add             x0, x0, HEAP, lsl #32
    // 0xd44798: LoadField: r1 = r0->field_2b
    //     0xd44798: ldur            w1, [x0, #0x2b]
    // 0xd4479c: DecompressPointer r1
    //     0xd4479c: add             x1, x1, HEAP, lsl #32
    // 0xd447a0: r0 = LoadClassIdInstr(r1)
    //     0xd447a0: ldur            x0, [x1, #-1]
    //     0xd447a4: ubfx            x0, x0, #0xc, #0x14
    // 0xd447a8: r2 = 128
    //     0xd447a8: mov             x2, #0x80
    // 0xd447ac: r0 = GDT[cid_x0 + -0xff4]()
    //     0xd447ac: sub             lr, x0, #0xff4
    //     0xd447b0: ldr             lr, [x21, lr, lsl #3]
    //     0xd447b4: blr             lr
    // 0xd447b8: LeaveFrame
    //     0xd447b8: mov             SP, fp
    //     0xd447bc: ldp             fp, lr, [SP], #0x10
    // 0xd447c0: ret
    //     0xd447c0: ret             
    // 0xd447c4: ldur            x0, [fp, #-8]
    // 0xd447c8: LoadField: r1 = r0->field_13
    //     0xd447c8: ldur            w1, [x0, #0x13]
    // 0xd447cc: DecompressPointer r1
    //     0xd447cc: add             x1, x1, HEAP, lsl #32
    // 0xd447d0: tbnz            w1, #4, #0xd447e0
    // 0xd447d4: r0 = Instance_Color
    //     0xd447d4: add             x0, PP, #0x26, lsl #12  ; [pp+0x261e0] Obj!Color@12a2e81
    //     0xd447d8: ldr             x0, [x0, #0x1e0]
    // 0xd447dc: b               #0xd447e8
    // 0xd447e0: r0 = Instance_Color
    //     0xd447e0: add             x0, PP, #0x26, lsl #12  ; [pp+0x261e8] Obj!Color@12a2e51
    //     0xd447e4: ldr             x0, [x0, #0x1e8]
    // 0xd447e8: LeaveFrame
    //     0xd447e8: mov             SP, fp
    //     0xd447ec: ldp             fp, lr, [SP], #0x10
    // 0xd447f0: ret
    //     0xd447f0: ret             
    // 0xd447f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd447f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd447f8: b               #0xd446f4
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd44d38, size: 0x12c
    // 0xd44d38: EnterFrame
    //     0xd44d38: stp             fp, lr, [SP, #-0x10]!
    //     0xd44d3c: mov             fp, SP
    // 0xd44d40: AllocStack(0x8)
    //     0xd44d40: sub             SP, SP, #8
    // 0xd44d44: SetupParameters([dynamic _ /* r0 */])
    //     0xd44d44: ldr             x0, [fp, #0x18]
    //     0xd44d48: ldur            w3, [x0, #0x17]
    //     0xd44d4c: add             x3, x3, HEAP, lsl #32
    //     0xd44d50: stur            x3, [fp, #-8]
    // 0xd44d54: CheckStackOverflow
    //     0xd44d54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd44d58: cmp             SP, x16
    //     0xd44d5c: b.ls            #0xd44e5c
    // 0xd44d60: ldr             x4, [fp, #0x10]
    // 0xd44d64: r0 = LoadClassIdInstr(r4)
    //     0xd44d64: ldur            x0, [x4, #-1]
    //     0xd44d68: ubfx            x0, x0, #0xc, #0x14
    // 0xd44d6c: mov             x1, x4
    // 0xd44d70: r2 = Instance_WidgetState
    //     0xd44d70: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd44d74: ldr             x2, [x2, #0xa70]
    // 0xd44d78: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd44d78: mov             x17, #0x2929
    //     0xd44d7c: movk            x17, #1, lsl #16
    //     0xd44d80: add             lr, x0, x17
    //     0xd44d84: ldr             lr, [x21, lr, lsl #3]
    //     0xd44d88: blr             lr
    // 0xd44d8c: tbnz            w0, #4, #0xd44dc8
    // 0xd44d90: ldur            x3, [fp, #-8]
    // 0xd44d94: LoadField: r0 = r3->field_13
    //     0xd44d94: ldur            w0, [x3, #0x13]
    // 0xd44d98: DecompressPointer r0
    //     0xd44d98: add             x0, x0, HEAP, lsl #32
    // 0xd44d9c: tbnz            w0, #4, #0xd44db0
    // 0xd44da0: r1 = Instance_MaterialColor
    //     0xd44da0: add             x1, PP, #0x16, lsl #12  ; [pp+0x16d48] Obj!MaterialColor@12a6e71
    //     0xd44da4: ldr             x1, [x1, #0xd48]
    // 0xd44da8: r0 = shade800()
    //     0xd44da8: bl              #0xd44ec4  ; [package:flutter/src/material/colors.dart] MaterialColor::shade800
    // 0xd44dac: b               #0xd44dbc
    // 0xd44db0: r1 = Instance_MaterialColor
    //     0xd44db0: add             x1, PP, #0x16, lsl #12  ; [pp+0x16d48] Obj!MaterialColor@12a6e71
    //     0xd44db4: ldr             x1, [x1, #0xd48]
    // 0xd44db8: r0 = shade400()
    //     0xd44db8: bl              #0xd1e41c  ; [package:flutter/src/material/colors.dart] MaterialColor::shade400
    // 0xd44dbc: LeaveFrame
    //     0xd44dbc: mov             SP, fp
    //     0xd44dc0: ldp             fp, lr, [SP], #0x10
    // 0xd44dc4: ret
    //     0xd44dc4: ret             
    // 0xd44dc8: ldr             x1, [fp, #0x10]
    // 0xd44dcc: ldur            x3, [fp, #-8]
    // 0xd44dd0: r0 = LoadClassIdInstr(r1)
    //     0xd44dd0: ldur            x0, [x1, #-1]
    //     0xd44dd4: ubfx            x0, x0, #0xc, #0x14
    // 0xd44dd8: r2 = Instance_WidgetState
    //     0xd44dd8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd44ddc: ldr             x2, [x2, #0x100]
    // 0xd44de0: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd44de0: mov             x17, #0x2929
    //     0xd44de4: movk            x17, #1, lsl #16
    //     0xd44de8: add             lr, x0, x17
    //     0xd44dec: ldr             lr, [x21, lr, lsl #3]
    //     0xd44df0: blr             lr
    // 0xd44df4: tbnz            w0, #4, #0xd44e24
    // 0xd44df8: ldur            x0, [fp, #-8]
    // 0xd44dfc: LoadField: r1 = r0->field_f
    //     0xd44dfc: ldur            w1, [x0, #0xf]
    // 0xd44e00: DecompressPointer r1
    //     0xd44e00: add             x1, x1, HEAP, lsl #32
    // 0xd44e04: LoadField: r0 = r1->field_33
    //     0xd44e04: ldur            w0, [x1, #0x33]
    // 0xd44e08: DecompressPointer r0
    //     0xd44e08: add             x0, x0, HEAP, lsl #32
    // 0xd44e0c: LoadField: r1 = r0->field_2b
    //     0xd44e0c: ldur            w1, [x0, #0x2b]
    // 0xd44e10: DecompressPointer r1
    //     0xd44e10: add             x1, x1, HEAP, lsl #32
    // 0xd44e14: mov             x0, x1
    // 0xd44e18: LeaveFrame
    //     0xd44e18: mov             SP, fp
    //     0xd44e1c: ldp             fp, lr, [SP], #0x10
    // 0xd44e20: ret
    //     0xd44e20: ret             
    // 0xd44e24: ldur            x0, [fp, #-8]
    // 0xd44e28: LoadField: r1 = r0->field_13
    //     0xd44e28: ldur            w1, [x0, #0x13]
    // 0xd44e2c: DecompressPointer r1
    //     0xd44e2c: add             x1, x1, HEAP, lsl #32
    // 0xd44e30: tbnz            w1, #4, #0xd44e44
    // 0xd44e34: r1 = Instance_MaterialColor
    //     0xd44e34: add             x1, PP, #0x16, lsl #12  ; [pp+0x16d48] Obj!MaterialColor@12a6e71
    //     0xd44e38: ldr             x1, [x1, #0xd48]
    // 0xd44e3c: r0 = shade400()
    //     0xd44e3c: bl              #0xd1e41c  ; [package:flutter/src/material/colors.dart] MaterialColor::shade400
    // 0xd44e40: b               #0xd44e50
    // 0xd44e44: r1 = Instance_MaterialColor
    //     0xd44e44: add             x1, PP, #0x16, lsl #12  ; [pp+0x16d48] Obj!MaterialColor@12a6e71
    //     0xd44e48: ldr             x1, [x1, #0xd48]
    // 0xd44e4c: r0 = shade50()
    //     0xd44e4c: bl              #0xd44e64  ; [package:flutter/src/material/colors.dart] MaterialColor::shade50
    // 0xd44e50: LeaveFrame
    //     0xd44e50: mov             SP, fp
    //     0xd44e54: ldp             fp, lr, [SP], #0x10
    // 0xd44e58: ret
    //     0xd44e58: ret             
    // 0xd44e5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd44e5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd44e60: b               #0xd44d60
  }
  get _ thumbColor(/* No info */) {
    // ** addr: 0x129d570, size: 0x98
    // 0x129d570: EnterFrame
    //     0x129d570: stp             fp, lr, [SP, #-0x10]!
    //     0x129d574: mov             fp, SP
    // 0x129d578: AllocStack(0x18)
    //     0x129d578: sub             SP, SP, #0x18
    // 0x129d57c: SetupParameters(_SwitchDefaultsM2 this /* r1 => r1, fp-0x8 */)
    //     0x129d57c: stur            x1, [fp, #-8]
    // 0x129d580: CheckStackOverflow
    //     0x129d580: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x129d584: cmp             SP, x16
    //     0x129d588: b.ls            #0x129d600
    // 0x129d58c: r1 = 2
    //     0x129d58c: mov             x1, #2
    // 0x129d590: r0 = AllocateContext()
    //     0x129d590: bl              #0x13de838  ; AllocateContextStub
    // 0x129d594: mov             x1, x0
    // 0x129d598: ldur            x0, [fp, #-8]
    // 0x129d59c: StoreField: r1->field_f = r0
    //     0x129d59c: stur            w0, [x1, #0xf]
    // 0x129d5a0: LoadField: r2 = r0->field_2f
    //     0x129d5a0: ldur            w2, [x0, #0x2f]
    // 0x129d5a4: DecompressPointer r2
    //     0x129d5a4: add             x2, x2, HEAP, lsl #32
    // 0x129d5a8: LoadField: r0 = r2->field_3f
    //     0x129d5a8: ldur            w0, [x2, #0x3f]
    // 0x129d5ac: DecompressPointer r0
    //     0x129d5ac: add             x0, x0, HEAP, lsl #32
    // 0x129d5b0: LoadField: r2 = r0->field_7
    //     0x129d5b0: ldur            w2, [x0, #7]
    // 0x129d5b4: DecompressPointer r2
    //     0x129d5b4: add             x2, x2, HEAP, lsl #32
    // 0x129d5b8: r16 = Instance_Brightness
    //     0x129d5b8: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x129d5bc: cmp             w2, w16
    // 0x129d5c0: r16 = true
    //     0x129d5c0: add             x16, NULL, #0x20  ; true
    // 0x129d5c4: r17 = false
    //     0x129d5c4: add             x17, NULL, #0x30  ; false
    // 0x129d5c8: csel            x0, x16, x17, eq
    // 0x129d5cc: StoreField: r1->field_13 = r0
    //     0x129d5cc: stur            w0, [x1, #0x13]
    // 0x129d5d0: mov             x2, x1
    // 0x129d5d4: r1 = Function '<anonymous closure>':.
    //     0x129d5d4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26118] AnonymousClosure: (0xd44d38), in [package:flutter/src/material/switch.dart] _SwitchDefaultsM2::thumbColor (0x129d570)
    //     0x129d5d8: ldr             x1, [x1, #0x118]
    // 0x129d5dc: r0 = AllocateClosure()
    //     0x129d5dc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x129d5e0: r16 = <Color>
    //     0x129d5e0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x129d5e4: ldr             x16, [x16, #0xa90]
    // 0x129d5e8: stp             x0, x16, [SP]
    // 0x129d5ec: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x129d5ec: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x129d5f0: r0 = resolveWith()
    //     0x129d5f0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x129d5f4: LeaveFrame
    //     0x129d5f4: mov             SP, fp
    //     0x129d5f8: ldp             fp, lr, [SP], #0x10
    // 0x129d5fc: ret
    //     0x129d5fc: ret             
    // 0x129d600: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x129d600: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129d604: b               #0x129d58c
  }
}

// class id: 5065, size: 0x34, field offset: 0x30
//   const constructor, 
class _SwitchDefaultsCupertino extends SwitchThemeData {

  [closure] SystemMouseCursor <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd429b4, size: 0x68
    // 0xd429b4: EnterFrame
    //     0xd429b4: stp             fp, lr, [SP, #-0x10]!
    //     0xd429b8: mov             fp, SP
    // 0xd429bc: CheckStackOverflow
    //     0xd429bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd429c0: cmp             SP, x16
    //     0xd429c4: b.ls            #0xd42a14
    // 0xd429c8: ldr             x1, [fp, #0x10]
    // 0xd429cc: r0 = LoadClassIdInstr(r1)
    //     0xd429cc: ldur            x0, [x1, #-1]
    //     0xd429d0: ubfx            x0, x0, #0xc, #0x14
    // 0xd429d4: r2 = Instance_WidgetState
    //     0xd429d4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd429d8: ldr             x2, [x2, #0xa70]
    // 0xd429dc: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd429dc: mov             x17, #0x2929
    //     0xd429e0: movk            x17, #1, lsl #16
    //     0xd429e4: add             lr, x0, x17
    //     0xd429e8: ldr             lr, [x21, lr, lsl #3]
    //     0xd429ec: blr             lr
    // 0xd429f0: tbnz            w0, #4, #0xd42a04
    // 0xd429f4: r0 = Instance_SystemMouseCursor
    //     0xd429f4: ldr             x0, [PP, #0x21b0]  ; [pp+0x21b0] Obj!SystemMouseCursor@12b3201
    // 0xd429f8: LeaveFrame
    //     0xd429f8: mov             SP, fp
    //     0xd429fc: ldp             fp, lr, [SP], #0x10
    // 0xd42a00: ret
    //     0xd42a00: ret             
    // 0xd42a04: r0 = Instance_SystemMouseCursor
    //     0xd42a04: ldr             x0, [PP, #0x21b0]  ; [pp+0x21b0] Obj!SystemMouseCursor@12b3201
    // 0xd42a08: LeaveFrame
    //     0xd42a08: mov             SP, fp
    //     0xd42a0c: ldp             fp, lr, [SP], #0x10
    // 0xd42a10: ret
    //     0xd42a10: ret             
    // 0xd42a14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd42a14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd42a18: b               #0xd429c8
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd431a0, size: 0xd0
    // 0xd431a0: EnterFrame
    //     0xd431a0: stp             fp, lr, [SP, #-0x10]!
    //     0xd431a4: mov             fp, SP
    // 0xd431a8: AllocStack(0x8)
    //     0xd431a8: sub             SP, SP, #8
    // 0xd431ac: SetupParameters([dynamic _ /* r0 */])
    //     0xd431ac: ldr             x0, [fp, #0x18]
    //     0xd431b0: ldur            w3, [x0, #0x17]
    //     0xd431b4: add             x3, x3, HEAP, lsl #32
    //     0xd431b8: stur            x3, [fp, #-8]
    // 0xd431bc: CheckStackOverflow
    //     0xd431bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd431c0: cmp             SP, x16
    //     0xd431c4: b.ls            #0xd43268
    // 0xd431c8: ldr             x1, [fp, #0x10]
    // 0xd431cc: r0 = LoadClassIdInstr(r1)
    //     0xd431cc: ldur            x0, [x1, #-1]
    //     0xd431d0: ubfx            x0, x0, #0xc, #0x14
    // 0xd431d4: r2 = Instance_WidgetState
    //     0xd431d4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd431d8: ldr             x2, [x2, #0xa60]
    // 0xd431dc: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd431dc: mov             x17, #0x2929
    //     0xd431e0: movk            x17, #1, lsl #16
    //     0xd431e4: add             lr, x0, x17
    //     0xd431e8: ldr             lr, [x21, lr, lsl #3]
    //     0xd431ec: blr             lr
    // 0xd431f0: tbnz            w0, #4, #0xd43254
    // 0xd431f4: ldur            x0, [fp, #-8]
    // 0xd431f8: LoadField: r1 = r0->field_f
    //     0xd431f8: ldur            w1, [x0, #0xf]
    // 0xd431fc: DecompressPointer r1
    //     0xd431fc: add             x1, x1, HEAP, lsl #32
    // 0xd43200: LoadField: r2 = r1->field_2f
    //     0xd43200: ldur            w2, [x1, #0x2f]
    // 0xd43204: DecompressPointer r2
    //     0xd43204: add             x2, x2, HEAP, lsl #32
    // 0xd43208: r1 = Instance_CupertinoDynamicColor
    //     0xd43208: add             x1, PP, #0x26, lsl #12  ; [pp+0x26188] Obj!CupertinoDynamicColor@12b3871
    //     0xd4320c: ldr             x1, [x1, #0x188]
    // 0xd43210: r0 = resolveFrom()
    //     0xd43210: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xd43214: mov             x1, x0
    // 0xd43218: d0 = 0.800000
    //     0xd43218: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a58] IMM: double(0.8) from 0x3fe999999999999a
    //     0xd4321c: ldr             d0, [x17, #0xa58]
    // 0xd43220: r0 = withOpacity()
    //     0xd43220: bl              #0x12ac564  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::withOpacity
    // 0xd43224: mov             x2, x0
    // 0xd43228: r1 = Null
    //     0xd43228: mov             x1, NULL
    // 0xd4322c: r0 = HSLColor.fromColor()
    //     0xd4322c: bl              #0xd43b8c  ; [package:flutter/src/painting/colors.dart] HSLColor::HSLColor.fromColor
    // 0xd43230: mov             x1, x0
    // 0xd43234: r0 = withLightness()
    //     0xd43234: bl              #0xd43b34  ; [package:flutter/src/painting/colors.dart] HSLColor::withLightness
    // 0xd43238: mov             x1, x0
    // 0xd4323c: r0 = withSaturation()
    //     0xd4323c: bl              #0xd43ad0  ; [package:flutter/src/painting/colors.dart] HSLColor::withSaturation
    // 0xd43240: mov             x1, x0
    // 0xd43244: r0 = toColor()
    //     0xd43244: bl              #0xd43270  ; [package:flutter/src/painting/colors.dart] HSLColor::toColor
    // 0xd43248: LeaveFrame
    //     0xd43248: mov             SP, fp
    //     0xd4324c: ldp             fp, lr, [SP], #0x10
    // 0xd43250: ret
    //     0xd43250: ret             
    // 0xd43254: r0 = Instance_Color
    //     0xd43254: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xd43258: ldr             x0, [x0, #0x810]
    // 0xd4325c: LeaveFrame
    //     0xd4325c: mov             SP, fp
    //     0xd43260: ldp             fp, lr, [SP], #0x10
    // 0xd43264: ret
    //     0xd43264: ret             
    // 0xd43268: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd43268: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4326c: b               #0xd431c8
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd44618, size: 0xb4
    // 0xd44618: EnterFrame
    //     0xd44618: stp             fp, lr, [SP, #-0x10]!
    //     0xd4461c: mov             fp, SP
    // 0xd44620: AllocStack(0x8)
    //     0xd44620: sub             SP, SP, #8
    // 0xd44624: SetupParameters([dynamic _ /* r0 */])
    //     0xd44624: ldr             x0, [fp, #0x18]
    //     0xd44628: ldur            w3, [x0, #0x17]
    //     0xd4462c: add             x3, x3, HEAP, lsl #32
    //     0xd44630: stur            x3, [fp, #-8]
    // 0xd44634: CheckStackOverflow
    //     0xd44634: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd44638: cmp             SP, x16
    //     0xd4463c: b.ls            #0xd446c4
    // 0xd44640: ldr             x1, [fp, #0x10]
    // 0xd44644: r0 = LoadClassIdInstr(r1)
    //     0xd44644: ldur            x0, [x1, #-1]
    //     0xd44648: ubfx            x0, x0, #0xc, #0x14
    // 0xd4464c: r2 = Instance_WidgetState
    //     0xd4464c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd44650: ldr             x2, [x2, #0x100]
    // 0xd44654: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd44654: mov             x17, #0x2929
    //     0xd44658: movk            x17, #1, lsl #16
    //     0xd4465c: add             lr, x0, x17
    //     0xd44660: ldr             lr, [x21, lr, lsl #3]
    //     0xd44664: blr             lr
    // 0xd44668: tbnz            w0, #4, #0xd44698
    // 0xd4466c: ldur            x0, [fp, #-8]
    // 0xd44670: LoadField: r1 = r0->field_f
    //     0xd44670: ldur            w1, [x0, #0xf]
    // 0xd44674: DecompressPointer r1
    //     0xd44674: add             x1, x1, HEAP, lsl #32
    // 0xd44678: LoadField: r2 = r1->field_2f
    //     0xd44678: ldur            w2, [x1, #0x2f]
    // 0xd4467c: DecompressPointer r2
    //     0xd4467c: add             x2, x2, HEAP, lsl #32
    // 0xd44680: r1 = Instance_CupertinoDynamicColor
    //     0xd44680: add             x1, PP, #0x26, lsl #12  ; [pp+0x26188] Obj!CupertinoDynamicColor@12b3871
    //     0xd44684: ldr             x1, [x1, #0x188]
    // 0xd44688: r0 = resolveFrom()
    //     0xd44688: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xd4468c: LeaveFrame
    //     0xd4468c: mov             SP, fp
    //     0xd44690: ldp             fp, lr, [SP], #0x10
    // 0xd44694: ret
    //     0xd44694: ret             
    // 0xd44698: ldur            x0, [fp, #-8]
    // 0xd4469c: LoadField: r1 = r0->field_f
    //     0xd4469c: ldur            w1, [x0, #0xf]
    // 0xd446a0: DecompressPointer r1
    //     0xd446a0: add             x1, x1, HEAP, lsl #32
    // 0xd446a4: LoadField: r2 = r1->field_2f
    //     0xd446a4: ldur            w2, [x1, #0x2f]
    // 0xd446a8: DecompressPointer r2
    //     0xd446a8: add             x2, x2, HEAP, lsl #32
    // 0xd446ac: r1 = Instance_CupertinoDynamicColor
    //     0xd446ac: add             x1, PP, #0x26, lsl #12  ; [pp+0x261d0] Obj!CupertinoDynamicColor@12b38b1
    //     0xd446b0: ldr             x1, [x1, #0x1d0]
    // 0xd446b4: r0 = resolveFrom()
    //     0xd446b4: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xd446b8: LeaveFrame
    //     0xd446b8: mov             SP, fp
    //     0xd446bc: ldp             fp, lr, [SP], #0x10
    // 0xd446c0: ret
    //     0xd446c0: ret             
    // 0xd446c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd446c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd446c8: b               #0xd44640
  }
}

// class id: 5700, size: 0x5c, field offset: 0x50
class _MaterialSwitchState extends _MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin {

  _ build(/* No info */) {
    // ** addr: 0xd3e174, size: 0x2268
    // 0xd3e174: EnterFrame
    //     0xd3e174: stp             fp, lr, [SP, #-0x10]!
    //     0xd3e178: mov             fp, SP
    // 0xd3e17c: AllocStack(0x108)
    //     0xd3e17c: sub             SP, SP, #0x108
    // 0xd3e180: SetupParameters(_MaterialSwitchState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd3e180: mov             x0, x1
    //     0xd3e184: stur            x1, [fp, #-8]
    //     0xd3e188: mov             x1, x2
    //     0xd3e18c: stur            x2, [fp, #-0x10]
    // 0xd3e190: CheckStackOverflow
    //     0xd3e190: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3e194: cmp             SP, x16
    //     0xd3e198: b.ls            #0xd40304
    // 0xd3e19c: r1 = 3
    //     0xd3e19c: mov             x1, #3
    // 0xd3e1a0: r0 = AllocateContext()
    //     0xd3e1a0: bl              #0x13de838  ; AllocateContextStub
    // 0xd3e1a4: mov             x2, x0
    // 0xd3e1a8: ldur            x0, [fp, #-8]
    // 0xd3e1ac: stur            x2, [fp, #-0x18]
    // 0xd3e1b0: StoreField: r2->field_f = r0
    //     0xd3e1b0: stur            w0, [x2, #0xf]
    // 0xd3e1b4: LoadField: r1 = r0->field_53
    //     0xd3e1b4: ldur            w1, [x0, #0x53]
    // 0xd3e1b8: DecompressPointer r1
    //     0xd3e1b8: add             x1, x1, HEAP, lsl #32
    // 0xd3e1bc: tbnz            w1, #4, #0xd3e1d0
    // 0xd3e1c0: r3 = false
    //     0xd3e1c0: add             x3, NULL, #0x30  ; false
    // 0xd3e1c4: StoreField: r0->field_53 = r3
    //     0xd3e1c4: stur            w3, [x0, #0x53]
    // 0xd3e1c8: mov             x1, x0
    // 0xd3e1cc: r0 = animateToValue()
    //     0xd3e1cc: bl              #0xd423d8  ; [dart:mixin_deduplication] _MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin::animateToValue
    // 0xd3e1d0: ldur            x0, [fp, #-8]
    // 0xd3e1d4: ldur            x2, [fp, #-0x18]
    // 0xd3e1d8: ldur            x1, [fp, #-0x10]
    // 0xd3e1dc: r0 = of()
    //     0xd3e1dc: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd3e1e0: ldur            x1, [fp, #-0x10]
    // 0xd3e1e4: stur            x0, [fp, #-0x20]
    // 0xd3e1e8: r0 = of()
    //     0xd3e1e8: bl              #0xd4237c  ; [package:flutter/src/material/switch_theme.dart] SwitchTheme::of
    // 0xd3e1ec: ldur            x2, [fp, #-0x18]
    // 0xd3e1f0: StoreField: r2->field_13 = r0
    //     0xd3e1f0: stur            w0, [x2, #0x13]
    //     0xd3e1f4: ldurb           w16, [x2, #-1]
    //     0xd3e1f8: ldurb           w17, [x0, #-1]
    //     0xd3e1fc: and             x16, x17, x16, lsr #2
    //     0xd3e200: tst             x16, HEAP, lsr #32
    //     0xd3e204: b.eq            #0xd3e20c
    //     0xd3e208: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd3e20c: ldur            x0, [fp, #-0x20]
    // 0xd3e210: LoadField: r3 = r0->field_3f
    //     0xd3e210: ldur            w3, [x0, #0x3f]
    // 0xd3e214: DecompressPointer r3
    //     0xd3e214: add             x3, x3, HEAP, lsl #32
    // 0xd3e218: stur            x3, [fp, #-0x30]
    // 0xd3e21c: ArrayStore: r2[0] = rNULL  ; List_4
    //     0xd3e21c: stur            NULL, [x2, #0x17]
    // 0xd3e220: ldur            x4, [fp, #-8]
    // 0xd3e224: LoadField: r1 = r4->field_b
    //     0xd3e224: ldur            w1, [x4, #0xb]
    // 0xd3e228: DecompressPointer r1
    //     0xd3e228: add             x1, x1, HEAP, lsl #32
    // 0xd3e22c: cmp             w1, NULL
    // 0xd3e230: b.eq            #0xd4030c
    // 0xd3e234: LoadField: r5 = r1->field_73
    //     0xd3e234: ldur            w5, [x1, #0x73]
    // 0xd3e238: DecompressPointer r5
    //     0xd3e238: add             x5, x5, HEAP, lsl #32
    // 0xd3e23c: LoadField: r1 = r5->field_7
    //     0xd3e23c: ldur            x1, [x5, #7]
    // 0xd3e240: cmp             x1, #0
    // 0xd3e244: b.gt            #0xd3e334
    // 0xd3e248: LoadField: r5 = r0->field_2f
    //     0xd3e248: ldur            w5, [x0, #0x2f]
    // 0xd3e24c: DecompressPointer r5
    //     0xd3e24c: add             x5, x5, HEAP, lsl #32
    // 0xd3e250: stur            x5, [fp, #-0x28]
    // 0xd3e254: tbnz            w5, #4, #0xd3e280
    // 0xd3e258: ldur            x1, [fp, #-0x10]
    // 0xd3e25c: r0 = of()
    //     0xd3e25c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd3e260: LoadField: r1 = r0->field_3f
    //     0xd3e260: ldur            w1, [x0, #0x3f]
    // 0xd3e264: DecompressPointer r1
    //     0xd3e264: add             x1, x1, HEAP, lsl #32
    // 0xd3e268: stur            x1, [fp, #-0x38]
    // 0xd3e26c: r0 = _SwitchConfigM3()
    //     0xd3e26c: bl              #0xd42370  ; Allocate_SwitchConfigM3Stub -> _SwitchConfigM3 (size=0xc)
    // 0xd3e270: mov             x1, x0
    // 0xd3e274: ldur            x0, [fp, #-0x38]
    // 0xd3e278: StoreField: r1->field_7 = r0
    //     0xd3e278: stur            w0, [x1, #7]
    // 0xd3e27c: b               #0xd3e288
    // 0xd3e280: r0 = _SwitchConfigM2()
    //     0xd3e280: bl              #0xd42364  ; Allocate_SwitchConfigM2Stub -> _SwitchConfigM2 (size=0x8)
    // 0xd3e284: mov             x1, x0
    // 0xd3e288: ldur            x0, [fp, #-0x28]
    // 0xd3e28c: stur            x1, [fp, #-0x38]
    // 0xd3e290: tbnz            w0, #4, #0xd3e2b0
    // 0xd3e294: ldur            x0, [fp, #-0x10]
    // 0xd3e298: r0 = _SwitchDefaultsM3()
    //     0xd3e298: bl              #0xd42358  ; Allocate_SwitchDefaultsM3Stub -> _SwitchDefaultsM3 (size=0x38)
    // 0xd3e29c: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3e2a0: StoreField: r0->field_33 = r1
    //     0xd3e2a0: stur            w1, [x0, #0x33]
    // 0xd3e2a4: ldur            x2, [fp, #-0x10]
    // 0xd3e2a8: StoreField: r0->field_2f = r2
    //     0xd3e2a8: stur            w2, [x0, #0x2f]
    // 0xd3e2ac: b               #0xd3e30c
    // 0xd3e2b0: ldur            x2, [fp, #-0x10]
    // 0xd3e2b4: mov             x1, x2
    // 0xd3e2b8: r0 = of()
    //     0xd3e2b8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd3e2bc: stur            x0, [fp, #-0x28]
    // 0xd3e2c0: r0 = _SwitchDefaultsM2()
    //     0xd3e2c0: bl              #0xd4234c  ; Allocate_SwitchDefaultsM2Stub -> _SwitchDefaultsM2 (size=0x38)
    // 0xd3e2c4: mov             x2, x0
    // 0xd3e2c8: ldur            x0, [fp, #-0x28]
    // 0xd3e2cc: stur            x2, [fp, #-0x40]
    // 0xd3e2d0: StoreField: r2->field_2f = r0
    //     0xd3e2d0: stur            w0, [x2, #0x2f]
    // 0xd3e2d4: ldur            x1, [fp, #-0x10]
    // 0xd3e2d8: r0 = of()
    //     0xd3e2d8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd3e2dc: LoadField: r1 = r0->field_3f
    //     0xd3e2dc: ldur            w1, [x0, #0x3f]
    // 0xd3e2e0: DecompressPointer r1
    //     0xd3e2e0: add             x1, x1, HEAP, lsl #32
    // 0xd3e2e4: mov             x0, x1
    // 0xd3e2e8: ldur            x1, [fp, #-0x40]
    // 0xd3e2ec: StoreField: r1->field_33 = r0
    //     0xd3e2ec: stur            w0, [x1, #0x33]
    //     0xd3e2f0: ldurb           w16, [x1, #-1]
    //     0xd3e2f4: ldurb           w17, [x0, #-1]
    //     0xd3e2f8: and             x16, x17, x16, lsr #2
    //     0xd3e2fc: tst             x16, HEAP, lsr #32
    //     0xd3e300: b.eq            #0xd3e308
    //     0xd3e304: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd3e308: mov             x0, x1
    // 0xd3e30c: ldur            x2, [fp, #-0x18]
    // 0xd3e310: ArrayStore: r2[0] = r0  ; List_4
    //     0xd3e310: stur            w0, [x2, #0x17]
    //     0xd3e314: ldurb           w16, [x2, #-1]
    //     0xd3e318: ldurb           w17, [x0, #-1]
    //     0xd3e31c: and             x16, x17, x16, lsr #2
    //     0xd3e320: tst             x16, HEAP, lsr #32
    //     0xd3e324: b.eq            #0xd3e32c
    //     0xd3e328: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd3e32c: ldur            x0, [fp, #-0x38]
    // 0xd3e330: b               #0xd3e590
    // 0xd3e334: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3e338: r16 = <SwitchThemeData>
    //     0xd3e338: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3580] TypeArguments: <SwitchThemeData>
    //     0xd3e33c: ldr             x16, [x16, #0x580]
    // 0xd3e340: stp             x0, x16, [SP]
    // 0xd3e344: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3e344: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3e348: r0 = getAdaptation()
    //     0xd3e348: bl              #0xd42188  ; [package:flutter/src/material/theme_data.dart] ThemeData::getAdaptation
    // 0xd3e34c: ldur            x2, [fp, #-0x18]
    // 0xd3e350: LoadField: r0 = r2->field_13
    //     0xd3e350: ldur            w0, [x2, #0x13]
    // 0xd3e354: DecompressPointer r0
    //     0xd3e354: add             x0, x0, HEAP, lsl #32
    // 0xd3e358: ldur            x1, [fp, #-0x20]
    // 0xd3e35c: LoadField: r3 = r1->field_23
    //     0xd3e35c: ldur            w3, [x1, #0x23]
    // 0xd3e360: DecompressPointer r3
    //     0xd3e360: add             x3, x3, HEAP, lsl #32
    // 0xd3e364: LoadField: r4 = r3->field_7
    //     0xd3e364: ldur            x4, [x3, #7]
    // 0xd3e368: cmp             x4, #2
    // 0xd3e36c: b.gt            #0xd3e37c
    // 0xd3e370: cmp             x4, #1
    // 0xd3e374: b.gt            #0xd3e38c
    // 0xd3e378: b               #0xd3e394
    // 0xd3e37c: cmp             x4, #4
    // 0xd3e380: b.gt            #0xd3e394
    // 0xd3e384: cmp             x4, #3
    // 0xd3e388: b.le            #0xd3e394
    // 0xd3e38c: r0 = Instance_SwitchThemeData
    //     0xd3e38c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12e38] Obj!SwitchThemeData@12b20a1
    //     0xd3e390: ldr             x0, [x0, #0xe38]
    // 0xd3e394: StoreField: r2->field_13 = r0
    //     0xd3e394: stur            w0, [x2, #0x13]
    //     0xd3e398: ldurb           w16, [x2, #-1]
    //     0xd3e39c: ldurb           w17, [x0, #-1]
    //     0xd3e3a0: and             x16, x17, x16, lsr #2
    //     0xd3e3a4: tst             x16, HEAP, lsr #32
    //     0xd3e3a8: b.eq            #0xd3e3b0
    //     0xd3e3ac: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd3e3b0: cmp             x4, #2
    // 0xd3e3b4: b.gt            #0xd3e3d0
    // 0xd3e3b8: cmp             x4, #1
    // 0xd3e3bc: b.gt            #0xd3e3f0
    // 0xd3e3c0: ldur            x0, [fp, #-8]
    // 0xd3e3c4: mov             x3, x2
    // 0xd3e3c8: ldur            x2, [fp, #-0x10]
    // 0xd3e3cc: b               #0xd3e4a0
    // 0xd3e3d0: cmp             x4, #4
    // 0xd3e3d4: b.gt            #0xd3e494
    // 0xd3e3d8: cmp             x4, #3
    // 0xd3e3dc: b.gt            #0xd3e3f0
    // 0xd3e3e0: ldur            x0, [fp, #-8]
    // 0xd3e3e4: mov             x3, x2
    // 0xd3e3e8: ldur            x2, [fp, #-0x10]
    // 0xd3e3ec: b               #0xd3e4a0
    // 0xd3e3f0: ldur            x3, [fp, #-8]
    // 0xd3e3f4: ldur            x0, [fp, #-0x10]
    // 0xd3e3f8: r4 = true
    //     0xd3e3f8: add             x4, NULL, #0x20  ; true
    // 0xd3e3fc: StoreField: r3->field_57 = r4
    //     0xd3e3fc: stur            w4, [x3, #0x57]
    // 0xd3e400: LoadField: r1 = r3->field_b
    //     0xd3e400: ldur            w1, [x3, #0xb]
    // 0xd3e404: DecompressPointer r1
    //     0xd3e404: add             x1, x1, HEAP, lsl #32
    // 0xd3e408: cmp             w1, NULL
    // 0xd3e40c: b.eq            #0xd40310
    // 0xd3e410: mov             x1, x0
    // 0xd3e414: r0 = of()
    //     0xd3e414: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd3e418: LoadField: r1 = r0->field_3f
    //     0xd3e418: ldur            w1, [x0, #0x3f]
    // 0xd3e41c: DecompressPointer r1
    //     0xd3e41c: add             x1, x1, HEAP, lsl #32
    // 0xd3e420: stur            x1, [fp, #-0x28]
    // 0xd3e424: r0 = _SwitchConfigCupertino()
    //     0xd3e424: bl              #0xd4217c  ; Allocate_SwitchConfigCupertinoStub -> _SwitchConfigCupertino (size=0xc)
    // 0xd3e428: mov             x1, x0
    // 0xd3e42c: ldur            x0, [fp, #-0x28]
    // 0xd3e430: stur            x1, [fp, #-0x38]
    // 0xd3e434: StoreField: r1->field_7 = r0
    //     0xd3e434: stur            w0, [x1, #7]
    // 0xd3e438: r0 = _SwitchDefaultsCupertino()
    //     0xd3e438: bl              #0xd42170  ; Allocate_SwitchDefaultsCupertinoStub -> _SwitchDefaultsCupertino (size=0x34)
    // 0xd3e43c: ldur            x2, [fp, #-0x10]
    // 0xd3e440: StoreField: r0->field_2f = r2
    //     0xd3e440: stur            w2, [x0, #0x2f]
    // 0xd3e444: ldur            x3, [fp, #-0x18]
    // 0xd3e448: ArrayStore: r3[0] = r0  ; List_4
    //     0xd3e448: stur            w0, [x3, #0x17]
    //     0xd3e44c: ldurb           w16, [x3, #-1]
    //     0xd3e450: ldurb           w17, [x0, #-1]
    //     0xd3e454: and             x16, x17, x16, lsr #2
    //     0xd3e458: tst             x16, HEAP, lsr #32
    //     0xd3e45c: b.eq            #0xd3e464
    //     0xd3e460: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd3e464: ldur            x0, [fp, #-8]
    // 0xd3e468: LoadField: r1 = r0->field_23
    //     0xd3e468: ldur            w1, [x0, #0x23]
    // 0xd3e46c: DecompressPointer r1
    //     0xd3e46c: add             x1, x1, HEAP, lsl #32
    // 0xd3e470: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3e474: cmp             w1, w16
    // 0xd3e478: b.eq            #0xd40314
    // 0xd3e47c: r4 = Instance_Duration
    //     0xd3e47c: add             x4, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xd3e480: ldr             x4, [x4, #0x318]
    // 0xd3e484: StoreField: r1->field_27 = r4
    //     0xd3e484: stur            w4, [x1, #0x27]
    // 0xd3e488: ldur            x0, [fp, #-0x38]
    // 0xd3e48c: mov             x2, x3
    // 0xd3e490: b               #0xd3e590
    // 0xd3e494: ldur            x0, [fp, #-8]
    // 0xd3e498: mov             x3, x2
    // 0xd3e49c: ldur            x2, [fp, #-0x10]
    // 0xd3e4a0: LoadField: r4 = r1->field_2f
    //     0xd3e4a0: ldur            w4, [x1, #0x2f]
    // 0xd3e4a4: DecompressPointer r4
    //     0xd3e4a4: add             x4, x4, HEAP, lsl #32
    // 0xd3e4a8: stur            x4, [fp, #-0x28]
    // 0xd3e4ac: tbnz            w4, #4, #0xd3e4d8
    // 0xd3e4b0: mov             x1, x2
    // 0xd3e4b4: r0 = of()
    //     0xd3e4b4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd3e4b8: LoadField: r1 = r0->field_3f
    //     0xd3e4b8: ldur            w1, [x0, #0x3f]
    // 0xd3e4bc: DecompressPointer r1
    //     0xd3e4bc: add             x1, x1, HEAP, lsl #32
    // 0xd3e4c0: stur            x1, [fp, #-0x20]
    // 0xd3e4c4: r0 = _SwitchConfigM3()
    //     0xd3e4c4: bl              #0xd42370  ; Allocate_SwitchConfigM3Stub -> _SwitchConfigM3 (size=0xc)
    // 0xd3e4c8: mov             x1, x0
    // 0xd3e4cc: ldur            x0, [fp, #-0x20]
    // 0xd3e4d0: StoreField: r1->field_7 = r0
    //     0xd3e4d0: stur            w0, [x1, #7]
    // 0xd3e4d4: b               #0xd3e4e0
    // 0xd3e4d8: r0 = _SwitchConfigM2()
    //     0xd3e4d8: bl              #0xd42364  ; Allocate_SwitchConfigM2Stub -> _SwitchConfigM2 (size=0x8)
    // 0xd3e4dc: mov             x1, x0
    // 0xd3e4e0: ldur            x0, [fp, #-0x28]
    // 0xd3e4e4: stur            x1, [fp, #-0x20]
    // 0xd3e4e8: tbnz            w0, #4, #0xd3e510
    // 0xd3e4ec: ldur            x0, [fp, #-0x10]
    // 0xd3e4f0: r0 = _SwitchDefaultsM3()
    //     0xd3e4f0: bl              #0xd42358  ; Allocate_SwitchDefaultsM3Stub -> _SwitchDefaultsM3 (size=0x38)
    // 0xd3e4f4: mov             x1, x0
    // 0xd3e4f8: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3e4fc: StoreField: r1->field_33 = r0
    //     0xd3e4fc: stur            w0, [x1, #0x33]
    // 0xd3e500: ldur            x0, [fp, #-0x10]
    // 0xd3e504: StoreField: r1->field_2f = r0
    //     0xd3e504: stur            w0, [x1, #0x2f]
    // 0xd3e508: mov             x0, x1
    // 0xd3e50c: b               #0xd3e56c
    // 0xd3e510: ldur            x0, [fp, #-0x10]
    // 0xd3e514: mov             x1, x0
    // 0xd3e518: r0 = of()
    //     0xd3e518: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd3e51c: stur            x0, [fp, #-0x28]
    // 0xd3e520: r0 = _SwitchDefaultsM2()
    //     0xd3e520: bl              #0xd4234c  ; Allocate_SwitchDefaultsM2Stub -> _SwitchDefaultsM2 (size=0x38)
    // 0xd3e524: mov             x2, x0
    // 0xd3e528: ldur            x0, [fp, #-0x28]
    // 0xd3e52c: stur            x2, [fp, #-0x38]
    // 0xd3e530: StoreField: r2->field_2f = r0
    //     0xd3e530: stur            w0, [x2, #0x2f]
    // 0xd3e534: ldur            x1, [fp, #-0x10]
    // 0xd3e538: r0 = of()
    //     0xd3e538: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd3e53c: LoadField: r1 = r0->field_3f
    //     0xd3e53c: ldur            w1, [x0, #0x3f]
    // 0xd3e540: DecompressPointer r1
    //     0xd3e540: add             x1, x1, HEAP, lsl #32
    // 0xd3e544: mov             x0, x1
    // 0xd3e548: ldur            x1, [fp, #-0x38]
    // 0xd3e54c: StoreField: r1->field_33 = r0
    //     0xd3e54c: stur            w0, [x1, #0x33]
    //     0xd3e550: ldurb           w16, [x1, #-1]
    //     0xd3e554: ldurb           w17, [x0, #-1]
    //     0xd3e558: and             x16, x17, x16, lsr #2
    //     0xd3e55c: tst             x16, HEAP, lsr #32
    //     0xd3e560: b.eq            #0xd3e568
    //     0xd3e564: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd3e568: mov             x0, x1
    // 0xd3e56c: ldur            x2, [fp, #-0x18]
    // 0xd3e570: ArrayStore: r2[0] = r0  ; List_4
    //     0xd3e570: stur            w0, [x2, #0x17]
    //     0xd3e574: ldurb           w16, [x2, #-1]
    //     0xd3e578: ldurb           w17, [x0, #-1]
    //     0xd3e57c: and             x16, x17, x16, lsr #2
    //     0xd3e580: tst             x16, HEAP, lsr #32
    //     0xd3e584: b.eq            #0xd3e58c
    //     0xd3e588: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd3e58c: ldur            x0, [fp, #-0x20]
    // 0xd3e590: ldur            x1, [fp, #-8]
    // 0xd3e594: stur            x0, [fp, #-0x28]
    // 0xd3e598: LoadField: r3 = r1->field_1b
    //     0xd3e598: ldur            w3, [x1, #0x1b]
    // 0xd3e59c: DecompressPointer r3
    //     0xd3e59c: add             x3, x3, HEAP, lsl #32
    // 0xd3e5a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3e5a4: cmp             w3, w16
    // 0xd3e5a8: b.eq            #0xd40320
    // 0xd3e5ac: stur            x3, [fp, #-0x20]
    // 0xd3e5b0: r4 = LoadClassIdInstr(r0)
    //     0xd3e5b0: ldur            x4, [x0, #-1]
    //     0xd3e5b4: ubfx            x4, x4, #0xc, #0x14
    // 0xd3e5b8: stur            x4, [fp, #-0x50]
    // 0xd3e5bc: r17 = 4622
    //     0xd3e5bc: mov             x17, #0x120e
    // 0xd3e5c0: cmp             x4, x17
    // 0xd3e5c4: b.ne            #0xd3e5d0
    // 0xd3e5c8: r5 = 300
    //     0xd3e5c8: mov             x5, #0x12c
    // 0xd3e5cc: b               #0xd3e5e8
    // 0xd3e5d0: r17 = 4623
    //     0xd3e5d0: mov             x17, #0x120f
    // 0xd3e5d4: cmp             x4, x17
    // 0xd3e5d8: b.ne            #0xd3e5e4
    // 0xd3e5dc: r5 = 200
    //     0xd3e5dc: mov             x5, #0xc8
    // 0xd3e5e0: b               #0xd3e5e8
    // 0xd3e5e4: r5 = 140
    //     0xd3e5e4: mov             x5, #0x8c
    // 0xd3e5e8: r16 = 1000
    //     0xd3e5e8: mov             x16, #0x3e8
    // 0xd3e5ec: mul             x6, x5, x16
    // 0xd3e5f0: stur            x6, [fp, #-0x48]
    // 0xd3e5f4: r0 = Duration()
    //     0xd3e5f4: bl              #0x7dd0d0  ; AllocateDurationStub -> Duration (size=0x10)
    // 0xd3e5f8: mov             x1, x0
    // 0xd3e5fc: ldur            x0, [fp, #-0x48]
    // 0xd3e600: StoreField: r1->field_7 = r0
    //     0xd3e600: stur            x0, [x1, #7]
    // 0xd3e604: mov             x0, x1
    // 0xd3e608: ldur            x1, [fp, #-0x20]
    // 0xd3e60c: StoreField: r1->field_27 = r0
    //     0xd3e60c: stur            w0, [x1, #0x27]
    //     0xd3e610: ldurb           w16, [x1, #-1]
    //     0xd3e614: ldurb           w17, [x0, #-1]
    //     0xd3e618: and             x16, x17, x16, lsr #2
    //     0xd3e61c: tst             x16, HEAP, lsr #32
    //     0xd3e620: b.eq            #0xd3e628
    //     0xd3e624: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd3e628: ldur            x1, [fp, #-8]
    // 0xd3e62c: r0 = states()
    //     0xd3e62c: bl              #0x129daa0  ; [dart:mixin_deduplication] _MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0xd3e630: mov             x1, x0
    // 0xd3e634: r2 = Instance_WidgetState
    //     0xd3e634: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd3e638: ldr             x2, [x2, #0x100]
    // 0xd3e63c: stur            x0, [fp, #-0x20]
    // 0xd3e640: r0 = add()
    //     0xd3e640: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xd3e644: ldur            x1, [fp, #-8]
    // 0xd3e648: r0 = states()
    //     0xd3e648: bl              #0x129daa0  ; [dart:mixin_deduplication] _MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0xd3e64c: mov             x1, x0
    // 0xd3e650: r2 = Instance_WidgetState
    //     0xd3e650: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd3e654: ldr             x2, [x2, #0x100]
    // 0xd3e658: stur            x0, [fp, #-0x38]
    // 0xd3e65c: r0 = remove()
    //     0xd3e65c: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0xd3e660: ldur            x1, [fp, #-8]
    // 0xd3e664: LoadField: r0 = r1->field_b
    //     0xd3e664: ldur            w0, [x1, #0xb]
    // 0xd3e668: DecompressPointer r0
    //     0xd3e668: add             x0, x0, HEAP, lsl #32
    // 0xd3e66c: cmp             w0, NULL
    // 0xd3e670: b.eq            #0xd4032c
    // 0xd3e674: r1 = 1
    //     0xd3e674: mov             x1, #1
    // 0xd3e678: r0 = AllocateContext()
    //     0xd3e678: bl              #0x13de838  ; AllocateContextStub
    // 0xd3e67c: mov             x1, x0
    // 0xd3e680: ldur            x0, [fp, #-8]
    // 0xd3e684: StoreField: r1->field_f = r0
    //     0xd3e684: stur            w0, [x1, #0xf]
    // 0xd3e688: mov             x2, x1
    // 0xd3e68c: r1 = Function '<anonymous closure>':.
    //     0xd3e68c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3588] AnonymousClosure: (0xd43078), in [package:flutter/src/material/switch.dart] _MaterialSwitchState::_widgetThumbColor (0xd420a0)
    //     0xd3e690: ldr             x1, [x1, #0x588]
    // 0xd3e694: r0 = AllocateClosure()
    //     0xd3e694: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3e698: r16 = <Color?>
    //     0xd3e698: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd3e69c: ldr             x16, [x16, #0xa40]
    // 0xd3e6a0: stp             x0, x16, [SP]
    // 0xd3e6a4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3e6a4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3e6a8: r0 = resolveWith()
    //     0xd3e6a8: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3e6ac: mov             x1, x0
    // 0xd3e6b0: ldur            x2, [fp, #-0x20]
    // 0xd3e6b4: r0 = build()
    //     0xd3e6b4: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd3e6b8: cmp             w0, NULL
    // 0xd3e6bc: b.ne            #0xd3e6c4
    // 0xd3e6c0: r0 = Null
    //     0xd3e6c0: mov             x0, NULL
    // 0xd3e6c4: stur            x0, [fp, #-0x58]
    // 0xd3e6c8: cmp             w0, NULL
    // 0xd3e6cc: b.ne            #0xd3e808
    // 0xd3e6d0: ldur            x2, [fp, #-0x18]
    // 0xd3e6d4: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd3e6d4: ldur            w1, [x2, #0x17]
    // 0xd3e6d8: DecompressPointer r1
    //     0xd3e6d8: add             x1, x1, HEAP, lsl #32
    // 0xd3e6dc: stur            x1, [fp, #-0x40]
    // 0xd3e6e0: r3 = LoadClassIdInstr(r1)
    //     0xd3e6e0: ldur            x3, [x1, #-1]
    //     0xd3e6e4: ubfx            x3, x3, #0xc, #0x14
    // 0xd3e6e8: r17 = 5062
    //     0xd3e6e8: mov             x17, #0x13c6
    // 0xd3e6ec: cmp             x3, x17
    // 0xd3e6f0: b.ne            #0xd3e704
    // 0xd3e6f4: LoadField: r3 = r1->field_7
    //     0xd3e6f4: ldur            w3, [x1, #7]
    // 0xd3e6f8: DecompressPointer r3
    //     0xd3e6f8: add             x3, x3, HEAP, lsl #32
    // 0xd3e6fc: mov             x1, x3
    // 0xd3e700: b               #0xd3e7d8
    // 0xd3e704: r17 = 5063
    //     0xd3e704: mov             x17, #0x13c7
    // 0xd3e708: cmp             x3, x17
    // 0xd3e70c: b.ne            #0xd3e750
    // 0xd3e710: r1 = 1
    //     0xd3e710: mov             x1, #1
    // 0xd3e714: r0 = AllocateContext()
    //     0xd3e714: bl              #0x13de838  ; AllocateContextStub
    // 0xd3e718: mov             x1, x0
    // 0xd3e71c: ldur            x0, [fp, #-0x40]
    // 0xd3e720: StoreField: r1->field_f = r0
    //     0xd3e720: stur            w0, [x1, #0xf]
    // 0xd3e724: mov             x2, x1
    // 0xd3e728: r1 = Function '<anonymous closure>':.
    //     0xd3e728: add             x1, PP, #0x26, lsl #12  ; [pp+0x26110] AnonymousClosure: (0xd44f24), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0xd3e72c: ldr             x1, [x1, #0x110]
    // 0xd3e730: r0 = AllocateClosure()
    //     0xd3e730: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3e734: r16 = <Color>
    //     0xd3e734: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd3e738: ldr             x16, [x16, #0xa90]
    // 0xd3e73c: stp             x0, x16, [SP]
    // 0xd3e740: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3e740: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3e744: r0 = resolveWith()
    //     0xd3e744: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3e748: mov             x1, x0
    // 0xd3e74c: b               #0xd3e7d8
    // 0xd3e750: mov             x0, x1
    // 0xd3e754: r17 = 5064
    //     0xd3e754: mov             x17, #0x13c8
    // 0xd3e758: cmp             x3, x17
    // 0xd3e75c: b.ne            #0xd3e7d0
    // 0xd3e760: r1 = 2
    //     0xd3e760: mov             x1, #2
    // 0xd3e764: r0 = AllocateContext()
    //     0xd3e764: bl              #0x13de838  ; AllocateContextStub
    // 0xd3e768: mov             x1, x0
    // 0xd3e76c: ldur            x0, [fp, #-0x40]
    // 0xd3e770: StoreField: r1->field_f = r0
    //     0xd3e770: stur            w0, [x1, #0xf]
    // 0xd3e774: LoadField: r2 = r0->field_2f
    //     0xd3e774: ldur            w2, [x0, #0x2f]
    // 0xd3e778: DecompressPointer r2
    //     0xd3e778: add             x2, x2, HEAP, lsl #32
    // 0xd3e77c: LoadField: r0 = r2->field_3f
    //     0xd3e77c: ldur            w0, [x2, #0x3f]
    // 0xd3e780: DecompressPointer r0
    //     0xd3e780: add             x0, x0, HEAP, lsl #32
    // 0xd3e784: LoadField: r2 = r0->field_7
    //     0xd3e784: ldur            w2, [x0, #7]
    // 0xd3e788: DecompressPointer r2
    //     0xd3e788: add             x2, x2, HEAP, lsl #32
    // 0xd3e78c: r16 = Instance_Brightness
    //     0xd3e78c: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xd3e790: cmp             w2, w16
    // 0xd3e794: r16 = true
    //     0xd3e794: add             x16, NULL, #0x20  ; true
    // 0xd3e798: r17 = false
    //     0xd3e798: add             x17, NULL, #0x30  ; false
    // 0xd3e79c: csel            x0, x16, x17, eq
    // 0xd3e7a0: StoreField: r1->field_13 = r0
    //     0xd3e7a0: stur            w0, [x1, #0x13]
    // 0xd3e7a4: mov             x2, x1
    // 0xd3e7a8: r1 = Function '<anonymous closure>':.
    //     0xd3e7a8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26118] AnonymousClosure: (0xd44d38), in [package:flutter/src/material/switch.dart] _SwitchDefaultsM2::thumbColor (0x129d570)
    //     0xd3e7ac: ldr             x1, [x1, #0x118]
    // 0xd3e7b0: r0 = AllocateClosure()
    //     0xd3e7b0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3e7b4: r16 = <Color>
    //     0xd3e7b4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd3e7b8: ldr             x16, [x16, #0xa90]
    // 0xd3e7bc: stp             x0, x16, [SP]
    // 0xd3e7c0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3e7c0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3e7c4: r0 = resolveWith()
    //     0xd3e7c4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3e7c8: mov             x1, x0
    // 0xd3e7cc: b               #0xd3e7d8
    // 0xd3e7d0: r1 = Instance_WidgetStatePropertyAll
    //     0xd3e7d0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26120] Obj!WidgetStatePropertyAll<Color>@128a081
    //     0xd3e7d4: ldr             x1, [x1, #0x120]
    // 0xd3e7d8: r0 = LoadClassIdInstr(r1)
    //     0xd3e7d8: ldur            x0, [x1, #-1]
    //     0xd3e7dc: ubfx            x0, x0, #0xc, #0x14
    // 0xd3e7e0: ldur            x2, [fp, #-0x20]
    // 0xd3e7e4: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd3e7e4: mov             x17, #0x7c77
    //     0xd3e7e8: movk            x17, #1, lsl #16
    //     0xd3e7ec: add             lr, x0, x17
    //     0xd3e7f0: ldr             lr, [x21, lr, lsl #3]
    //     0xd3e7f4: blr             lr
    // 0xd3e7f8: cmp             w0, NULL
    // 0xd3e7fc: b.eq            #0xd40330
    // 0xd3e800: mov             x2, x0
    // 0xd3e804: b               #0xd3e80c
    // 0xd3e808: ldur            x2, [fp, #-0x58]
    // 0xd3e80c: ldur            x1, [fp, #-8]
    // 0xd3e810: stur            x2, [fp, #-0x40]
    // 0xd3e814: LoadField: r0 = r1->field_b
    //     0xd3e814: ldur            w0, [x1, #0xb]
    // 0xd3e818: DecompressPointer r0
    //     0xd3e818: add             x0, x0, HEAP, lsl #32
    // 0xd3e81c: cmp             w0, NULL
    // 0xd3e820: b.eq            #0xd40334
    // 0xd3e824: r1 = 1
    //     0xd3e824: mov             x1, #1
    // 0xd3e828: r0 = AllocateContext()
    //     0xd3e828: bl              #0x13de838  ; AllocateContextStub
    // 0xd3e82c: mov             x1, x0
    // 0xd3e830: ldur            x0, [fp, #-8]
    // 0xd3e834: StoreField: r1->field_f = r0
    //     0xd3e834: stur            w0, [x1, #0xf]
    // 0xd3e838: mov             x2, x1
    // 0xd3e83c: r1 = Function '<anonymous closure>':.
    //     0xd3e83c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3588] AnonymousClosure: (0xd43078), in [package:flutter/src/material/switch.dart] _MaterialSwitchState::_widgetThumbColor (0xd420a0)
    //     0xd3e840: ldr             x1, [x1, #0x588]
    // 0xd3e844: r0 = AllocateClosure()
    //     0xd3e844: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3e848: r16 = <Color?>
    //     0xd3e848: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd3e84c: ldr             x16, [x16, #0xa40]
    // 0xd3e850: stp             x0, x16, [SP]
    // 0xd3e854: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3e854: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3e858: r0 = resolveWith()
    //     0xd3e858: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3e85c: mov             x1, x0
    // 0xd3e860: ldur            x2, [fp, #-0x38]
    // 0xd3e864: r0 = build()
    //     0xd3e864: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd3e868: cmp             w0, NULL
    // 0xd3e86c: b.ne            #0xd3e874
    // 0xd3e870: r0 = Null
    //     0xd3e870: mov             x0, NULL
    // 0xd3e874: stur            x0, [fp, #-0x68]
    // 0xd3e878: cmp             w0, NULL
    // 0xd3e87c: b.ne            #0xd3e9b8
    // 0xd3e880: ldur            x2, [fp, #-0x18]
    // 0xd3e884: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd3e884: ldur            w1, [x2, #0x17]
    // 0xd3e888: DecompressPointer r1
    //     0xd3e888: add             x1, x1, HEAP, lsl #32
    // 0xd3e88c: stur            x1, [fp, #-0x60]
    // 0xd3e890: r3 = LoadClassIdInstr(r1)
    //     0xd3e890: ldur            x3, [x1, #-1]
    //     0xd3e894: ubfx            x3, x3, #0xc, #0x14
    // 0xd3e898: r17 = 5062
    //     0xd3e898: mov             x17, #0x13c6
    // 0xd3e89c: cmp             x3, x17
    // 0xd3e8a0: b.ne            #0xd3e8b4
    // 0xd3e8a4: LoadField: r3 = r1->field_7
    //     0xd3e8a4: ldur            w3, [x1, #7]
    // 0xd3e8a8: DecompressPointer r3
    //     0xd3e8a8: add             x3, x3, HEAP, lsl #32
    // 0xd3e8ac: mov             x1, x3
    // 0xd3e8b0: b               #0xd3e988
    // 0xd3e8b4: r17 = 5063
    //     0xd3e8b4: mov             x17, #0x13c7
    // 0xd3e8b8: cmp             x3, x17
    // 0xd3e8bc: b.ne            #0xd3e900
    // 0xd3e8c0: r1 = 1
    //     0xd3e8c0: mov             x1, #1
    // 0xd3e8c4: r0 = AllocateContext()
    //     0xd3e8c4: bl              #0x13de838  ; AllocateContextStub
    // 0xd3e8c8: mov             x1, x0
    // 0xd3e8cc: ldur            x0, [fp, #-0x60]
    // 0xd3e8d0: StoreField: r1->field_f = r0
    //     0xd3e8d0: stur            w0, [x1, #0xf]
    // 0xd3e8d4: mov             x2, x1
    // 0xd3e8d8: r1 = Function '<anonymous closure>':.
    //     0xd3e8d8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26110] AnonymousClosure: (0xd44f24), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0xd3e8dc: ldr             x1, [x1, #0x110]
    // 0xd3e8e0: r0 = AllocateClosure()
    //     0xd3e8e0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3e8e4: r16 = <Color>
    //     0xd3e8e4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd3e8e8: ldr             x16, [x16, #0xa90]
    // 0xd3e8ec: stp             x0, x16, [SP]
    // 0xd3e8f0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3e8f0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3e8f4: r0 = resolveWith()
    //     0xd3e8f4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3e8f8: mov             x1, x0
    // 0xd3e8fc: b               #0xd3e988
    // 0xd3e900: mov             x0, x1
    // 0xd3e904: r17 = 5064
    //     0xd3e904: mov             x17, #0x13c8
    // 0xd3e908: cmp             x3, x17
    // 0xd3e90c: b.ne            #0xd3e980
    // 0xd3e910: r1 = 2
    //     0xd3e910: mov             x1, #2
    // 0xd3e914: r0 = AllocateContext()
    //     0xd3e914: bl              #0x13de838  ; AllocateContextStub
    // 0xd3e918: mov             x1, x0
    // 0xd3e91c: ldur            x0, [fp, #-0x60]
    // 0xd3e920: StoreField: r1->field_f = r0
    //     0xd3e920: stur            w0, [x1, #0xf]
    // 0xd3e924: LoadField: r2 = r0->field_2f
    //     0xd3e924: ldur            w2, [x0, #0x2f]
    // 0xd3e928: DecompressPointer r2
    //     0xd3e928: add             x2, x2, HEAP, lsl #32
    // 0xd3e92c: LoadField: r0 = r2->field_3f
    //     0xd3e92c: ldur            w0, [x2, #0x3f]
    // 0xd3e930: DecompressPointer r0
    //     0xd3e930: add             x0, x0, HEAP, lsl #32
    // 0xd3e934: LoadField: r2 = r0->field_7
    //     0xd3e934: ldur            w2, [x0, #7]
    // 0xd3e938: DecompressPointer r2
    //     0xd3e938: add             x2, x2, HEAP, lsl #32
    // 0xd3e93c: r16 = Instance_Brightness
    //     0xd3e93c: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xd3e940: cmp             w2, w16
    // 0xd3e944: r16 = true
    //     0xd3e944: add             x16, NULL, #0x20  ; true
    // 0xd3e948: r17 = false
    //     0xd3e948: add             x17, NULL, #0x30  ; false
    // 0xd3e94c: csel            x0, x16, x17, eq
    // 0xd3e950: StoreField: r1->field_13 = r0
    //     0xd3e950: stur            w0, [x1, #0x13]
    // 0xd3e954: mov             x2, x1
    // 0xd3e958: r1 = Function '<anonymous closure>':.
    //     0xd3e958: add             x1, PP, #0x26, lsl #12  ; [pp+0x26118] AnonymousClosure: (0xd44d38), in [package:flutter/src/material/switch.dart] _SwitchDefaultsM2::thumbColor (0x129d570)
    //     0xd3e95c: ldr             x1, [x1, #0x118]
    // 0xd3e960: r0 = AllocateClosure()
    //     0xd3e960: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3e964: r16 = <Color>
    //     0xd3e964: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd3e968: ldr             x16, [x16, #0xa90]
    // 0xd3e96c: stp             x0, x16, [SP]
    // 0xd3e970: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3e970: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3e974: r0 = resolveWith()
    //     0xd3e974: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3e978: mov             x1, x0
    // 0xd3e97c: b               #0xd3e988
    // 0xd3e980: r1 = Instance_WidgetStatePropertyAll
    //     0xd3e980: add             x1, PP, #0x26, lsl #12  ; [pp+0x26120] Obj!WidgetStatePropertyAll<Color>@128a081
    //     0xd3e984: ldr             x1, [x1, #0x120]
    // 0xd3e988: r0 = LoadClassIdInstr(r1)
    //     0xd3e988: ldur            x0, [x1, #-1]
    //     0xd3e98c: ubfx            x0, x0, #0xc, #0x14
    // 0xd3e990: ldur            x2, [fp, #-0x38]
    // 0xd3e994: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd3e994: mov             x17, #0x7c77
    //     0xd3e998: movk            x17, #1, lsl #16
    //     0xd3e99c: add             lr, x0, x17
    //     0xd3e9a0: ldr             lr, [x21, lr, lsl #3]
    //     0xd3e9a4: blr             lr
    // 0xd3e9a8: cmp             w0, NULL
    // 0xd3e9ac: b.eq            #0xd40338
    // 0xd3e9b0: mov             x2, x0
    // 0xd3e9b4: b               #0xd3e9bc
    // 0xd3e9b8: ldur            x2, [fp, #-0x68]
    // 0xd3e9bc: ldur            x1, [fp, #-8]
    // 0xd3e9c0: stur            x2, [fp, #-0x60]
    // 0xd3e9c4: LoadField: r0 = r1->field_b
    //     0xd3e9c4: ldur            w0, [x1, #0xb]
    // 0xd3e9c8: DecompressPointer r0
    //     0xd3e9c8: add             x0, x0, HEAP, lsl #32
    // 0xd3e9cc: cmp             w0, NULL
    // 0xd3e9d0: b.eq            #0xd4033c
    // 0xd3e9d4: r1 = 1
    //     0xd3e9d4: mov             x1, #1
    // 0xd3e9d8: r0 = AllocateContext()
    //     0xd3e9d8: bl              #0x13de838  ; AllocateContextStub
    // 0xd3e9dc: mov             x1, x0
    // 0xd3e9e0: ldur            x0, [fp, #-8]
    // 0xd3e9e4: StoreField: r1->field_f = r0
    //     0xd3e9e4: stur            w0, [x1, #0xf]
    // 0xd3e9e8: mov             x2, x1
    // 0xd3e9ec: r1 = Function '<anonymous closure>':.
    //     0xd3e9ec: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3590] AnonymousClosure: (0xd42fb4), in [package:flutter/src/material/switch.dart] _MaterialSwitchState::_widgetTrackColor (0xd42108)
    //     0xd3e9f0: ldr             x1, [x1, #0x590]
    // 0xd3e9f4: r0 = AllocateClosure()
    //     0xd3e9f4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3e9f8: r16 = <Color?>
    //     0xd3e9f8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd3e9fc: ldr             x16, [x16, #0xa40]
    // 0xd3ea00: stp             x0, x16, [SP]
    // 0xd3ea04: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3ea04: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3ea08: r0 = resolveWith()
    //     0xd3ea08: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3ea0c: mov             x1, x0
    // 0xd3ea10: ldur            x2, [fp, #-0x20]
    // 0xd3ea14: r0 = build()
    //     0xd3ea14: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd3ea18: cmp             w0, NULL
    // 0xd3ea1c: b.ne            #0xd3ea24
    // 0xd3ea20: r0 = Null
    //     0xd3ea20: mov             x0, NULL
    // 0xd3ea24: cmp             w0, NULL
    // 0xd3ea28: b.ne            #0xd3eaa8
    // 0xd3ea2c: ldur            x1, [fp, #-8]
    // 0xd3ea30: r1 = 1
    //     0xd3ea30: mov             x1, #1
    // 0xd3ea34: r0 = AllocateContext()
    //     0xd3ea34: bl              #0x13de838  ; AllocateContextStub
    // 0xd3ea38: mov             x1, x0
    // 0xd3ea3c: ldur            x0, [fp, #-8]
    // 0xd3ea40: StoreField: r1->field_f = r0
    //     0xd3ea40: stur            w0, [x1, #0xf]
    // 0xd3ea44: mov             x2, x1
    // 0xd3ea48: r1 = Function '<anonymous closure>':.
    //     0xd3ea48: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3588] AnonymousClosure: (0xd43078), in [package:flutter/src/material/switch.dart] _MaterialSwitchState::_widgetThumbColor (0xd420a0)
    //     0xd3ea4c: ldr             x1, [x1, #0x588]
    // 0xd3ea50: r0 = AllocateClosure()
    //     0xd3ea50: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3ea54: r16 = <Color?>
    //     0xd3ea54: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd3ea58: ldr             x16, [x16, #0xa40]
    // 0xd3ea5c: stp             x0, x16, [SP]
    // 0xd3ea60: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3ea60: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3ea64: r0 = resolveWith()
    //     0xd3ea64: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3ea68: mov             x1, x0
    // 0xd3ea6c: ldur            x2, [fp, #-0x20]
    // 0xd3ea70: r0 = build()
    //     0xd3ea70: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd3ea74: cmp             w0, NULL
    // 0xd3ea78: b.ne            #0xd3ea84
    // 0xd3ea7c: r0 = Null
    //     0xd3ea7c: mov             x0, NULL
    // 0xd3ea80: b               #0xd3eaa8
    // 0xd3ea84: r1 = LoadClassIdInstr(r0)
    //     0xd3ea84: ldur            x1, [x0, #-1]
    //     0xd3ea88: ubfx            x1, x1, #0xc, #0x14
    // 0xd3ea8c: mov             x16, x0
    // 0xd3ea90: mov             x0, x1
    // 0xd3ea94: mov             x1, x16
    // 0xd3ea98: r2 = 128
    //     0xd3ea98: mov             x2, #0x80
    // 0xd3ea9c: r0 = GDT[cid_x0 + -0xff4]()
    //     0xd3ea9c: sub             lr, x0, #0xff4
    //     0xd3eaa0: ldr             lr, [x21, lr, lsl #3]
    //     0xd3eaa4: blr             lr
    // 0xd3eaa8: cmp             w0, NULL
    // 0xd3eaac: b.ne            #0xd3ebfc
    // 0xd3eab0: ldur            x2, [fp, #-0x18]
    // 0xd3eab4: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xd3eab4: ldur            w0, [x2, #0x17]
    // 0xd3eab8: DecompressPointer r0
    //     0xd3eab8: add             x0, x0, HEAP, lsl #32
    // 0xd3eabc: stur            x0, [fp, #-0x70]
    // 0xd3eac0: r1 = LoadClassIdInstr(r0)
    //     0xd3eac0: ldur            x1, [x0, #-1]
    //     0xd3eac4: ubfx            x1, x1, #0xc, #0x14
    // 0xd3eac8: r17 = 5062
    //     0xd3eac8: mov             x17, #0x13c6
    // 0xd3eacc: cmp             x1, x17
    // 0xd3ead0: b.ne            #0xd3eae0
    // 0xd3ead4: LoadField: r1 = r0->field_b
    //     0xd3ead4: ldur            w1, [x0, #0xb]
    // 0xd3ead8: DecompressPointer r1
    //     0xd3ead8: add             x1, x1, HEAP, lsl #32
    // 0xd3eadc: b               #0xd3ebe4
    // 0xd3eae0: r17 = 5063
    //     0xd3eae0: mov             x17, #0x13c7
    // 0xd3eae4: cmp             x1, x17
    // 0xd3eae8: b.ne            #0xd3eb2c
    // 0xd3eaec: r1 = 1
    //     0xd3eaec: mov             x1, #1
    // 0xd3eaf0: r0 = AllocateContext()
    //     0xd3eaf0: bl              #0x13de838  ; AllocateContextStub
    // 0xd3eaf4: mov             x1, x0
    // 0xd3eaf8: ldur            x0, [fp, #-0x70]
    // 0xd3eafc: StoreField: r1->field_f = r0
    //     0xd3eafc: stur            w0, [x1, #0xf]
    // 0xd3eb00: mov             x2, x1
    // 0xd3eb04: r1 = Function '<anonymous closure>':.
    //     0xd3eb04: add             x1, PP, #0x26, lsl #12  ; [pp+0x26128] AnonymousClosure: (0xd447fc), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0xd3eb08: ldr             x1, [x1, #0x128]
    // 0xd3eb0c: r0 = AllocateClosure()
    //     0xd3eb0c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3eb10: r16 = <Color>
    //     0xd3eb10: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd3eb14: ldr             x16, [x16, #0xa90]
    // 0xd3eb18: stp             x0, x16, [SP]
    // 0xd3eb1c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3eb1c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3eb20: r0 = resolveWith()
    //     0xd3eb20: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3eb24: mov             x1, x0
    // 0xd3eb28: b               #0xd3ebe4
    // 0xd3eb2c: r17 = 5064
    //     0xd3eb2c: mov             x17, #0x13c8
    // 0xd3eb30: cmp             x1, x17
    // 0xd3eb34: b.ne            #0xd3eba8
    // 0xd3eb38: r1 = 2
    //     0xd3eb38: mov             x1, #2
    // 0xd3eb3c: r0 = AllocateContext()
    //     0xd3eb3c: bl              #0x13de838  ; AllocateContextStub
    // 0xd3eb40: mov             x1, x0
    // 0xd3eb44: ldur            x0, [fp, #-0x70]
    // 0xd3eb48: StoreField: r1->field_f = r0
    //     0xd3eb48: stur            w0, [x1, #0xf]
    // 0xd3eb4c: LoadField: r2 = r0->field_2f
    //     0xd3eb4c: ldur            w2, [x0, #0x2f]
    // 0xd3eb50: DecompressPointer r2
    //     0xd3eb50: add             x2, x2, HEAP, lsl #32
    // 0xd3eb54: LoadField: r0 = r2->field_3f
    //     0xd3eb54: ldur            w0, [x2, #0x3f]
    // 0xd3eb58: DecompressPointer r0
    //     0xd3eb58: add             x0, x0, HEAP, lsl #32
    // 0xd3eb5c: LoadField: r2 = r0->field_7
    //     0xd3eb5c: ldur            w2, [x0, #7]
    // 0xd3eb60: DecompressPointer r2
    //     0xd3eb60: add             x2, x2, HEAP, lsl #32
    // 0xd3eb64: r16 = Instance_Brightness
    //     0xd3eb64: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xd3eb68: cmp             w2, w16
    // 0xd3eb6c: r16 = true
    //     0xd3eb6c: add             x16, NULL, #0x20  ; true
    // 0xd3eb70: r17 = false
    //     0xd3eb70: add             x17, NULL, #0x30  ; false
    // 0xd3eb74: csel            x0, x16, x17, eq
    // 0xd3eb78: StoreField: r1->field_13 = r0
    //     0xd3eb78: stur            w0, [x1, #0x13]
    // 0xd3eb7c: mov             x2, x1
    // 0xd3eb80: r1 = Function '<anonymous closure>':.
    //     0xd3eb80: add             x1, PP, #0x26, lsl #12  ; [pp+0x26130] AnonymousClosure: (0xd446cc), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM2
    //     0xd3eb84: ldr             x1, [x1, #0x130]
    // 0xd3eb88: r0 = AllocateClosure()
    //     0xd3eb88: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3eb8c: r16 = <Color>
    //     0xd3eb8c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd3eb90: ldr             x16, [x16, #0xa90]
    // 0xd3eb94: stp             x0, x16, [SP]
    // 0xd3eb98: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3eb98: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3eb9c: r0 = resolveWith()
    //     0xd3eb9c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3eba0: mov             x1, x0
    // 0xd3eba4: b               #0xd3ebe4
    // 0xd3eba8: r1 = 1
    //     0xd3eba8: mov             x1, #1
    // 0xd3ebac: r0 = AllocateContext()
    //     0xd3ebac: bl              #0x13de838  ; AllocateContextStub
    // 0xd3ebb0: mov             x1, x0
    // 0xd3ebb4: ldur            x0, [fp, #-0x70]
    // 0xd3ebb8: StoreField: r1->field_f = r0
    //     0xd3ebb8: stur            w0, [x1, #0xf]
    // 0xd3ebbc: mov             x2, x1
    // 0xd3ebc0: r1 = Function '<anonymous closure>':.
    //     0xd3ebc0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26138] AnonymousClosure: (0xd44618), of [package:flutter/src/material/switch.dart] _SwitchDefaultsCupertino
    //     0xd3ebc4: ldr             x1, [x1, #0x138]
    // 0xd3ebc8: r0 = AllocateClosure()
    //     0xd3ebc8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3ebcc: r16 = <Color>
    //     0xd3ebcc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd3ebd0: ldr             x16, [x16, #0xa90]
    // 0xd3ebd4: stp             x0, x16, [SP]
    // 0xd3ebd8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3ebd8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3ebdc: r0 = resolveWith()
    //     0xd3ebdc: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3ebe0: mov             x1, x0
    // 0xd3ebe4: ldur            x2, [fp, #-0x20]
    // 0xd3ebe8: r0 = build()
    //     0xd3ebe8: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd3ebec: cmp             w0, NULL
    // 0xd3ebf0: b.eq            #0xd40340
    // 0xd3ebf4: mov             x3, x0
    // 0xd3ebf8: b               #0xd3ec00
    // 0xd3ebfc: mov             x3, x0
    // 0xd3ec00: ldur            x0, [fp, #-8]
    // 0xd3ec04: stur            x3, [fp, #-0x70]
    // 0xd3ec08: LoadField: r1 = r0->field_b
    //     0xd3ec08: ldur            w1, [x0, #0xb]
    // 0xd3ec0c: DecompressPointer r1
    //     0xd3ec0c: add             x1, x1, HEAP, lsl #32
    // 0xd3ec10: cmp             w1, NULL
    // 0xd3ec14: b.eq            #0xd40344
    // 0xd3ec18: LoadField: r2 = r1->field_3b
    //     0xd3ec18: ldur            w2, [x1, #0x3b]
    // 0xd3ec1c: DecompressPointer r2
    //     0xd3ec1c: add             x2, x2, HEAP, lsl #32
    // 0xd3ec20: mov             x1, x2
    // 0xd3ec24: ldur            x2, [fp, #-0x20]
    // 0xd3ec28: r0 = build()
    //     0xd3ec28: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd3ec2c: cmp             w0, NULL
    // 0xd3ec30: b.ne            #0xd3ec38
    // 0xd3ec34: r0 = Null
    //     0xd3ec34: mov             x0, NULL
    // 0xd3ec38: cmp             w0, NULL
    // 0xd3ec3c: b.ne            #0xd3ed04
    // 0xd3ec40: ldur            x2, [fp, #-0x18]
    // 0xd3ec44: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xd3ec44: ldur            w0, [x2, #0x17]
    // 0xd3ec48: DecompressPointer r0
    //     0xd3ec48: add             x0, x0, HEAP, lsl #32
    // 0xd3ec4c: stur            x0, [fp, #-0x78]
    // 0xd3ec50: r1 = LoadClassIdInstr(r0)
    //     0xd3ec50: ldur            x1, [x0, #-1]
    //     0xd3ec54: ubfx            x1, x1, #0xc, #0x14
    // 0xd3ec58: r17 = 5062
    //     0xd3ec58: mov             x17, #0x13c6
    // 0xd3ec5c: cmp             x1, x17
    // 0xd3ec60: b.ne            #0xd3ec70
    // 0xd3ec64: LoadField: r1 = r0->field_f
    //     0xd3ec64: ldur            w1, [x0, #0xf]
    // 0xd3ec68: DecompressPointer r1
    //     0xd3ec68: add             x1, x1, HEAP, lsl #32
    // 0xd3ec6c: b               #0xd3ecdc
    // 0xd3ec70: r17 = 5063
    //     0xd3ec70: mov             x17, #0x13c7
    // 0xd3ec74: cmp             x1, x17
    // 0xd3ec78: b.ne            #0xd3ecbc
    // 0xd3ec7c: r1 = 1
    //     0xd3ec7c: mov             x1, #1
    // 0xd3ec80: r0 = AllocateContext()
    //     0xd3ec80: bl              #0x13de838  ; AllocateContextStub
    // 0xd3ec84: mov             x1, x0
    // 0xd3ec88: ldur            x0, [fp, #-0x78]
    // 0xd3ec8c: StoreField: r1->field_f = r0
    //     0xd3ec8c: stur            w0, [x1, #0xf]
    // 0xd3ec90: mov             x2, x1
    // 0xd3ec94: r1 = Function '<anonymous closure>':.
    //     0xd3ec94: add             x1, PP, #0x26, lsl #12  ; [pp+0x26140] AnonymousClosure: (0xd444c0), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0xd3ec98: ldr             x1, [x1, #0x140]
    // 0xd3ec9c: r0 = AllocateClosure()
    //     0xd3ec9c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3eca0: r16 = <Color?>
    //     0xd3eca0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd3eca4: ldr             x16, [x16, #0xa40]
    // 0xd3eca8: stp             x0, x16, [SP]
    // 0xd3ecac: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3ecac: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3ecb0: r0 = resolveWith()
    //     0xd3ecb0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3ecb4: mov             x1, x0
    // 0xd3ecb8: b               #0xd3ecdc
    // 0xd3ecbc: r17 = 5064
    //     0xd3ecbc: mov             x17, #0x13c8
    // 0xd3ecc0: cmp             x1, x17
    // 0xd3ecc4: b.ne            #0xd3ecd4
    // 0xd3ecc8: r1 = Instance_WidgetStatePropertyAll
    //     0xd3ecc8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26148] Obj!WidgetStatePropertyAll<Color>@128a071
    //     0xd3eccc: ldr             x1, [x1, #0x148]
    // 0xd3ecd0: b               #0xd3ecdc
    // 0xd3ecd4: r1 = Instance_WidgetStatePropertyAll
    //     0xd3ecd4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26148] Obj!WidgetStatePropertyAll<Color>@128a071
    //     0xd3ecd8: ldr             x1, [x1, #0x148]
    // 0xd3ecdc: r0 = LoadClassIdInstr(r1)
    //     0xd3ecdc: ldur            x0, [x1, #-1]
    //     0xd3ece0: ubfx            x0, x0, #0xc, #0x14
    // 0xd3ece4: ldur            x2, [fp, #-0x20]
    // 0xd3ece8: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd3ece8: mov             x17, #0x7c77
    //     0xd3ecec: movk            x17, #1, lsl #16
    //     0xd3ecf0: add             lr, x0, x17
    //     0xd3ecf4: ldr             lr, [x21, lr, lsl #3]
    //     0xd3ecf8: blr             lr
    // 0xd3ecfc: mov             x3, x0
    // 0xd3ed00: b               #0xd3ed08
    // 0xd3ed04: mov             x3, x0
    // 0xd3ed08: ldur            x0, [fp, #-8]
    // 0xd3ed0c: stur            x3, [fp, #-0x78]
    // 0xd3ed10: LoadField: r1 = r0->field_b
    //     0xd3ed10: ldur            w1, [x0, #0xb]
    // 0xd3ed14: DecompressPointer r1
    //     0xd3ed14: add             x1, x1, HEAP, lsl #32
    // 0xd3ed18: cmp             w1, NULL
    // 0xd3ed1c: b.eq            #0xd40348
    // 0xd3ed20: LoadField: r2 = r1->field_3f
    //     0xd3ed20: ldur            w2, [x1, #0x3f]
    // 0xd3ed24: DecompressPointer r2
    //     0xd3ed24: add             x2, x2, HEAP, lsl #32
    // 0xd3ed28: mov             x1, x2
    // 0xd3ed2c: ldur            x2, [fp, #-0x20]
    // 0xd3ed30: r0 = build()
    //     0xd3ed30: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd3ed34: cmp             w0, NULL
    // 0xd3ed38: b.ne            #0xd3ed40
    // 0xd3ed3c: r0 = Null
    //     0xd3ed3c: mov             x0, NULL
    // 0xd3ed40: cmp             w0, NULL
    // 0xd3ed44: b.ne            #0xd3edb4
    // 0xd3ed48: ldur            x2, [fp, #-0x18]
    // 0xd3ed4c: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xd3ed4c: ldur            w0, [x2, #0x17]
    // 0xd3ed50: DecompressPointer r0
    //     0xd3ed50: add             x0, x0, HEAP, lsl #32
    // 0xd3ed54: r1 = LoadClassIdInstr(r0)
    //     0xd3ed54: ldur            x1, [x0, #-1]
    //     0xd3ed58: ubfx            x1, x1, #0xc, #0x14
    // 0xd3ed5c: r17 = -5064
    //     0xd3ed5c: mov             x17, #-0x13c8
    // 0xd3ed60: add             x16, x1, x17
    // 0xd3ed64: cmp             x16, #1
    // 0xd3ed68: b.ls            #0xd3ed78
    // 0xd3ed6c: r17 = 5062
    //     0xd3ed6c: mov             x17, #0x13c6
    // 0xd3ed70: cmp             x1, x17
    // 0xd3ed74: b.ne            #0xd3ed88
    // 0xd3ed78: LoadField: r1 = r0->field_13
    //     0xd3ed78: ldur            w1, [x0, #0x13]
    // 0xd3ed7c: DecompressPointer r1
    //     0xd3ed7c: add             x1, x1, HEAP, lsl #32
    // 0xd3ed80: mov             x0, x1
    // 0xd3ed84: b               #0xd3ed90
    // 0xd3ed88: r0 = Instance_WidgetStatePropertyAll
    //     0xd3ed88: add             x0, PP, #0x26, lsl #12  ; [pp+0x26150] Obj!WidgetStatePropertyAll<double>@128a061
    //     0xd3ed8c: ldr             x0, [x0, #0x150]
    // 0xd3ed90: cmp             w0, NULL
    // 0xd3ed94: b.ne            #0xd3eda0
    // 0xd3ed98: r0 = Null
    //     0xd3ed98: mov             x0, NULL
    // 0xd3ed9c: b               #0xd3edac
    // 0xd3eda0: LoadField: r1 = r0->field_b
    //     0xd3eda0: ldur            w1, [x0, #0xb]
    // 0xd3eda4: DecompressPointer r1
    //     0xd3eda4: add             x1, x1, HEAP, lsl #32
    // 0xd3eda8: mov             x0, x1
    // 0xd3edac: mov             x3, x0
    // 0xd3edb0: b               #0xd3edbc
    // 0xd3edb4: ldur            x2, [fp, #-0x18]
    // 0xd3edb8: mov             x3, x0
    // 0xd3edbc: ldur            x0, [fp, #-8]
    // 0xd3edc0: stur            x3, [fp, #-0x80]
    // 0xd3edc4: LoadField: r1 = r0->field_b
    //     0xd3edc4: ldur            w1, [x0, #0xb]
    // 0xd3edc8: DecompressPointer r1
    //     0xd3edc8: add             x1, x1, HEAP, lsl #32
    // 0xd3edcc: cmp             w1, NULL
    // 0xd3edd0: b.eq            #0xd4034c
    // 0xd3edd4: mov             x1, x0
    // 0xd3edd8: r0 = _widgetTrackColor()
    //     0xd3edd8: bl              #0xd42108  ; [package:flutter/src/material/switch.dart] _MaterialSwitchState::_widgetTrackColor
    // 0xd3eddc: mov             x1, x0
    // 0xd3ede0: ldur            x2, [fp, #-0x38]
    // 0xd3ede4: r0 = build()
    //     0xd3ede4: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd3ede8: cmp             w0, NULL
    // 0xd3edec: b.ne            #0xd3edf4
    // 0xd3edf0: r0 = Null
    //     0xd3edf0: mov             x0, NULL
    // 0xd3edf4: cmp             w0, NULL
    // 0xd3edf8: b.ne            #0xd3ef48
    // 0xd3edfc: ldur            x2, [fp, #-0x18]
    // 0xd3ee00: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xd3ee00: ldur            w0, [x2, #0x17]
    // 0xd3ee04: DecompressPointer r0
    //     0xd3ee04: add             x0, x0, HEAP, lsl #32
    // 0xd3ee08: stur            x0, [fp, #-0x88]
    // 0xd3ee0c: r1 = LoadClassIdInstr(r0)
    //     0xd3ee0c: ldur            x1, [x0, #-1]
    //     0xd3ee10: ubfx            x1, x1, #0xc, #0x14
    // 0xd3ee14: r17 = 5062
    //     0xd3ee14: mov             x17, #0x13c6
    // 0xd3ee18: cmp             x1, x17
    // 0xd3ee1c: b.ne            #0xd3ee2c
    // 0xd3ee20: LoadField: r1 = r0->field_b
    //     0xd3ee20: ldur            w1, [x0, #0xb]
    // 0xd3ee24: DecompressPointer r1
    //     0xd3ee24: add             x1, x1, HEAP, lsl #32
    // 0xd3ee28: b               #0xd3ef30
    // 0xd3ee2c: r17 = 5063
    //     0xd3ee2c: mov             x17, #0x13c7
    // 0xd3ee30: cmp             x1, x17
    // 0xd3ee34: b.ne            #0xd3ee78
    // 0xd3ee38: r1 = 1
    //     0xd3ee38: mov             x1, #1
    // 0xd3ee3c: r0 = AllocateContext()
    //     0xd3ee3c: bl              #0x13de838  ; AllocateContextStub
    // 0xd3ee40: mov             x1, x0
    // 0xd3ee44: ldur            x0, [fp, #-0x88]
    // 0xd3ee48: StoreField: r1->field_f = r0
    //     0xd3ee48: stur            w0, [x1, #0xf]
    // 0xd3ee4c: mov             x2, x1
    // 0xd3ee50: r1 = Function '<anonymous closure>':.
    //     0xd3ee50: add             x1, PP, #0x26, lsl #12  ; [pp+0x26128] AnonymousClosure: (0xd447fc), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0xd3ee54: ldr             x1, [x1, #0x128]
    // 0xd3ee58: r0 = AllocateClosure()
    //     0xd3ee58: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3ee5c: r16 = <Color>
    //     0xd3ee5c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd3ee60: ldr             x16, [x16, #0xa90]
    // 0xd3ee64: stp             x0, x16, [SP]
    // 0xd3ee68: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3ee68: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3ee6c: r0 = resolveWith()
    //     0xd3ee6c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3ee70: mov             x1, x0
    // 0xd3ee74: b               #0xd3ef30
    // 0xd3ee78: r17 = 5064
    //     0xd3ee78: mov             x17, #0x13c8
    // 0xd3ee7c: cmp             x1, x17
    // 0xd3ee80: b.ne            #0xd3eef4
    // 0xd3ee84: r1 = 2
    //     0xd3ee84: mov             x1, #2
    // 0xd3ee88: r0 = AllocateContext()
    //     0xd3ee88: bl              #0x13de838  ; AllocateContextStub
    // 0xd3ee8c: mov             x1, x0
    // 0xd3ee90: ldur            x0, [fp, #-0x88]
    // 0xd3ee94: StoreField: r1->field_f = r0
    //     0xd3ee94: stur            w0, [x1, #0xf]
    // 0xd3ee98: LoadField: r2 = r0->field_2f
    //     0xd3ee98: ldur            w2, [x0, #0x2f]
    // 0xd3ee9c: DecompressPointer r2
    //     0xd3ee9c: add             x2, x2, HEAP, lsl #32
    // 0xd3eea0: LoadField: r0 = r2->field_3f
    //     0xd3eea0: ldur            w0, [x2, #0x3f]
    // 0xd3eea4: DecompressPointer r0
    //     0xd3eea4: add             x0, x0, HEAP, lsl #32
    // 0xd3eea8: LoadField: r2 = r0->field_7
    //     0xd3eea8: ldur            w2, [x0, #7]
    // 0xd3eeac: DecompressPointer r2
    //     0xd3eeac: add             x2, x2, HEAP, lsl #32
    // 0xd3eeb0: r16 = Instance_Brightness
    //     0xd3eeb0: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xd3eeb4: cmp             w2, w16
    // 0xd3eeb8: r16 = true
    //     0xd3eeb8: add             x16, NULL, #0x20  ; true
    // 0xd3eebc: r17 = false
    //     0xd3eebc: add             x17, NULL, #0x30  ; false
    // 0xd3eec0: csel            x0, x16, x17, eq
    // 0xd3eec4: StoreField: r1->field_13 = r0
    //     0xd3eec4: stur            w0, [x1, #0x13]
    // 0xd3eec8: mov             x2, x1
    // 0xd3eecc: r1 = Function '<anonymous closure>':.
    //     0xd3eecc: add             x1, PP, #0x26, lsl #12  ; [pp+0x26130] AnonymousClosure: (0xd446cc), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM2
    //     0xd3eed0: ldr             x1, [x1, #0x130]
    // 0xd3eed4: r0 = AllocateClosure()
    //     0xd3eed4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3eed8: r16 = <Color>
    //     0xd3eed8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd3eedc: ldr             x16, [x16, #0xa90]
    // 0xd3eee0: stp             x0, x16, [SP]
    // 0xd3eee4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3eee4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3eee8: r0 = resolveWith()
    //     0xd3eee8: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3eeec: mov             x1, x0
    // 0xd3eef0: b               #0xd3ef30
    // 0xd3eef4: r1 = 1
    //     0xd3eef4: mov             x1, #1
    // 0xd3eef8: r0 = AllocateContext()
    //     0xd3eef8: bl              #0x13de838  ; AllocateContextStub
    // 0xd3eefc: mov             x1, x0
    // 0xd3ef00: ldur            x0, [fp, #-0x88]
    // 0xd3ef04: StoreField: r1->field_f = r0
    //     0xd3ef04: stur            w0, [x1, #0xf]
    // 0xd3ef08: mov             x2, x1
    // 0xd3ef0c: r1 = Function '<anonymous closure>':.
    //     0xd3ef0c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26138] AnonymousClosure: (0xd44618), of [package:flutter/src/material/switch.dart] _SwitchDefaultsCupertino
    //     0xd3ef10: ldr             x1, [x1, #0x138]
    // 0xd3ef14: r0 = AllocateClosure()
    //     0xd3ef14: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3ef18: r16 = <Color>
    //     0xd3ef18: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd3ef1c: ldr             x16, [x16, #0xa90]
    // 0xd3ef20: stp             x0, x16, [SP]
    // 0xd3ef24: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3ef24: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3ef28: r0 = resolveWith()
    //     0xd3ef28: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3ef2c: mov             x1, x0
    // 0xd3ef30: ldur            x2, [fp, #-0x38]
    // 0xd3ef34: r0 = build()
    //     0xd3ef34: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd3ef38: cmp             w0, NULL
    // 0xd3ef3c: b.eq            #0xd40350
    // 0xd3ef40: mov             x3, x0
    // 0xd3ef44: b               #0xd3ef4c
    // 0xd3ef48: mov             x3, x0
    // 0xd3ef4c: ldur            x0, [fp, #-8]
    // 0xd3ef50: stur            x3, [fp, #-0x88]
    // 0xd3ef54: LoadField: r1 = r0->field_b
    //     0xd3ef54: ldur            w1, [x0, #0xb]
    // 0xd3ef58: DecompressPointer r1
    //     0xd3ef58: add             x1, x1, HEAP, lsl #32
    // 0xd3ef5c: cmp             w1, NULL
    // 0xd3ef60: b.eq            #0xd40354
    // 0xd3ef64: LoadField: r2 = r1->field_3b
    //     0xd3ef64: ldur            w2, [x1, #0x3b]
    // 0xd3ef68: DecompressPointer r2
    //     0xd3ef68: add             x2, x2, HEAP, lsl #32
    // 0xd3ef6c: mov             x1, x2
    // 0xd3ef70: ldur            x2, [fp, #-0x38]
    // 0xd3ef74: r0 = build()
    //     0xd3ef74: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd3ef78: cmp             w0, NULL
    // 0xd3ef7c: b.ne            #0xd3ef84
    // 0xd3ef80: r0 = Null
    //     0xd3ef80: mov             x0, NULL
    // 0xd3ef84: cmp             w0, NULL
    // 0xd3ef88: b.ne            #0xd3f050
    // 0xd3ef8c: ldur            x2, [fp, #-0x18]
    // 0xd3ef90: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xd3ef90: ldur            w0, [x2, #0x17]
    // 0xd3ef94: DecompressPointer r0
    //     0xd3ef94: add             x0, x0, HEAP, lsl #32
    // 0xd3ef98: stur            x0, [fp, #-0x90]
    // 0xd3ef9c: r1 = LoadClassIdInstr(r0)
    //     0xd3ef9c: ldur            x1, [x0, #-1]
    //     0xd3efa0: ubfx            x1, x1, #0xc, #0x14
    // 0xd3efa4: r17 = 5062
    //     0xd3efa4: mov             x17, #0x13c6
    // 0xd3efa8: cmp             x1, x17
    // 0xd3efac: b.ne            #0xd3efbc
    // 0xd3efb0: LoadField: r1 = r0->field_f
    //     0xd3efb0: ldur            w1, [x0, #0xf]
    // 0xd3efb4: DecompressPointer r1
    //     0xd3efb4: add             x1, x1, HEAP, lsl #32
    // 0xd3efb8: b               #0xd3f028
    // 0xd3efbc: r17 = 5063
    //     0xd3efbc: mov             x17, #0x13c7
    // 0xd3efc0: cmp             x1, x17
    // 0xd3efc4: b.ne            #0xd3f008
    // 0xd3efc8: r1 = 1
    //     0xd3efc8: mov             x1, #1
    // 0xd3efcc: r0 = AllocateContext()
    //     0xd3efcc: bl              #0x13de838  ; AllocateContextStub
    // 0xd3efd0: mov             x1, x0
    // 0xd3efd4: ldur            x0, [fp, #-0x90]
    // 0xd3efd8: StoreField: r1->field_f = r0
    //     0xd3efd8: stur            w0, [x1, #0xf]
    // 0xd3efdc: mov             x2, x1
    // 0xd3efe0: r1 = Function '<anonymous closure>':.
    //     0xd3efe0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26140] AnonymousClosure: (0xd444c0), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0xd3efe4: ldr             x1, [x1, #0x140]
    // 0xd3efe8: r0 = AllocateClosure()
    //     0xd3efe8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3efec: r16 = <Color?>
    //     0xd3efec: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd3eff0: ldr             x16, [x16, #0xa40]
    // 0xd3eff4: stp             x0, x16, [SP]
    // 0xd3eff8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3eff8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3effc: r0 = resolveWith()
    //     0xd3effc: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3f000: mov             x1, x0
    // 0xd3f004: b               #0xd3f028
    // 0xd3f008: r17 = 5064
    //     0xd3f008: mov             x17, #0x13c8
    // 0xd3f00c: cmp             x1, x17
    // 0xd3f010: b.ne            #0xd3f020
    // 0xd3f014: r1 = Instance_WidgetStatePropertyAll
    //     0xd3f014: add             x1, PP, #0x26, lsl #12  ; [pp+0x26148] Obj!WidgetStatePropertyAll<Color>@128a071
    //     0xd3f018: ldr             x1, [x1, #0x148]
    // 0xd3f01c: b               #0xd3f028
    // 0xd3f020: r1 = Instance_WidgetStatePropertyAll
    //     0xd3f020: add             x1, PP, #0x26, lsl #12  ; [pp+0x26148] Obj!WidgetStatePropertyAll<Color>@128a071
    //     0xd3f024: ldr             x1, [x1, #0x148]
    // 0xd3f028: r0 = LoadClassIdInstr(r1)
    //     0xd3f028: ldur            x0, [x1, #-1]
    //     0xd3f02c: ubfx            x0, x0, #0xc, #0x14
    // 0xd3f030: ldur            x2, [fp, #-0x38]
    // 0xd3f034: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd3f034: mov             x17, #0x7c77
    //     0xd3f038: movk            x17, #1, lsl #16
    //     0xd3f03c: add             lr, x0, x17
    //     0xd3f040: ldr             lr, [x21, lr, lsl #3]
    //     0xd3f044: blr             lr
    // 0xd3f048: mov             x3, x0
    // 0xd3f04c: b               #0xd3f054
    // 0xd3f050: mov             x3, x0
    // 0xd3f054: ldur            x0, [fp, #-8]
    // 0xd3f058: stur            x3, [fp, #-0x90]
    // 0xd3f05c: LoadField: r1 = r0->field_b
    //     0xd3f05c: ldur            w1, [x0, #0xb]
    // 0xd3f060: DecompressPointer r1
    //     0xd3f060: add             x1, x1, HEAP, lsl #32
    // 0xd3f064: cmp             w1, NULL
    // 0xd3f068: b.eq            #0xd40358
    // 0xd3f06c: LoadField: r2 = r1->field_3f
    //     0xd3f06c: ldur            w2, [x1, #0x3f]
    // 0xd3f070: DecompressPointer r2
    //     0xd3f070: add             x2, x2, HEAP, lsl #32
    // 0xd3f074: mov             x1, x2
    // 0xd3f078: ldur            x2, [fp, #-0x38]
    // 0xd3f07c: r0 = build()
    //     0xd3f07c: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd3f080: cmp             w0, NULL
    // 0xd3f084: b.ne            #0xd3f08c
    // 0xd3f088: r0 = Null
    //     0xd3f088: mov             x0, NULL
    // 0xd3f08c: cmp             w0, NULL
    // 0xd3f090: b.ne            #0xd3f100
    // 0xd3f094: ldur            x2, [fp, #-0x18]
    // 0xd3f098: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xd3f098: ldur            w0, [x2, #0x17]
    // 0xd3f09c: DecompressPointer r0
    //     0xd3f09c: add             x0, x0, HEAP, lsl #32
    // 0xd3f0a0: r1 = LoadClassIdInstr(r0)
    //     0xd3f0a0: ldur            x1, [x0, #-1]
    //     0xd3f0a4: ubfx            x1, x1, #0xc, #0x14
    // 0xd3f0a8: r17 = -5064
    //     0xd3f0a8: mov             x17, #-0x13c8
    // 0xd3f0ac: add             x16, x1, x17
    // 0xd3f0b0: cmp             x16, #1
    // 0xd3f0b4: b.ls            #0xd3f0c4
    // 0xd3f0b8: r17 = 5062
    //     0xd3f0b8: mov             x17, #0x13c6
    // 0xd3f0bc: cmp             x1, x17
    // 0xd3f0c0: b.ne            #0xd3f0d4
    // 0xd3f0c4: LoadField: r1 = r0->field_13
    //     0xd3f0c4: ldur            w1, [x0, #0x13]
    // 0xd3f0c8: DecompressPointer r1
    //     0xd3f0c8: add             x1, x1, HEAP, lsl #32
    // 0xd3f0cc: mov             x0, x1
    // 0xd3f0d0: b               #0xd3f0dc
    // 0xd3f0d4: r0 = Instance_WidgetStatePropertyAll
    //     0xd3f0d4: add             x0, PP, #0x26, lsl #12  ; [pp+0x26150] Obj!WidgetStatePropertyAll<double>@128a061
    //     0xd3f0d8: ldr             x0, [x0, #0x150]
    // 0xd3f0dc: cmp             w0, NULL
    // 0xd3f0e0: b.ne            #0xd3f0ec
    // 0xd3f0e4: r0 = Null
    //     0xd3f0e4: mov             x0, NULL
    // 0xd3f0e8: b               #0xd3f0f8
    // 0xd3f0ec: LoadField: r1 = r0->field_b
    //     0xd3f0ec: ldur            w1, [x0, #0xb]
    // 0xd3f0f0: DecompressPointer r1
    //     0xd3f0f0: add             x1, x1, HEAP, lsl #32
    // 0xd3f0f4: mov             x0, x1
    // 0xd3f0f8: mov             x3, x0
    // 0xd3f0fc: b               #0xd3f108
    // 0xd3f100: ldur            x2, [fp, #-0x18]
    // 0xd3f104: mov             x3, x0
    // 0xd3f108: ldur            x1, [fp, #-8]
    // 0xd3f10c: ldur            x0, [fp, #-0x50]
    // 0xd3f110: stur            x3, [fp, #-0x98]
    // 0xd3f114: LoadField: r4 = r1->field_b
    //     0xd3f114: ldur            w4, [x1, #0xb]
    // 0xd3f118: DecompressPointer r4
    //     0xd3f118: add             x4, x4, HEAP, lsl #32
    // 0xd3f11c: cmp             w4, NULL
    // 0xd3f120: b.eq            #0xd4035c
    // 0xd3f124: r17 = 4622
    //     0xd3f124: mov             x17, #0x120e
    // 0xd3f128: cmp             x0, x17
    // 0xd3f12c: b.ne            #0xd3f174
    // 0xd3f130: ldur            x4, [fp, #-0x28]
    // 0xd3f134: r1 = 1
    //     0xd3f134: mov             x1, #1
    // 0xd3f138: r0 = AllocateContext()
    //     0xd3f138: bl              #0x13de838  ; AllocateContextStub
    // 0xd3f13c: mov             x1, x0
    // 0xd3f140: ldur            x0, [fp, #-0x28]
    // 0xd3f144: StoreField: r1->field_f = r0
    //     0xd3f144: stur            w0, [x1, #0xf]
    // 0xd3f148: mov             x2, x1
    // 0xd3f14c: r1 = Function '<anonymous closure>':.
    //     0xd3f14c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3598] AnonymousClosure: (0xd42b38), of [package:flutter/src/material/switch.dart] _SwitchConfigM3
    //     0xd3f150: ldr             x1, [x1, #0x598]
    // 0xd3f154: r0 = AllocateClosure()
    //     0xd3f154: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3f158: r16 = <Color>
    //     0xd3f158: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd3f15c: ldr             x16, [x16, #0xa90]
    // 0xd3f160: stp             x0, x16, [SP]
    // 0xd3f164: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3f164: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3f168: r0 = resolveWith()
    //     0xd3f168: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3f16c: mov             x1, x0
    // 0xd3f170: b               #0xd3f1e4
    // 0xd3f174: r17 = 4623
    //     0xd3f174: mov             x17, #0x120f
    // 0xd3f178: cmp             x0, x17
    // 0xd3f17c: b.ne            #0xd3f1a4
    // 0xd3f180: r16 = <Color>
    //     0xd3f180: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd3f184: ldr             x16, [x16, #0xa90]
    // 0xd3f188: r30 = Instance_Color
    //     0xd3f188: add             lr, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xd3f18c: ldr             lr, [lr, #0x810]
    // 0xd3f190: stp             lr, x16, [SP]
    // 0xd3f194: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3f194: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3f198: r0 = all()
    //     0xd3f198: bl              #0xd13288  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::all
    // 0xd3f19c: mov             x1, x0
    // 0xd3f1a0: b               #0xd3f1e4
    // 0xd3f1a4: ldur            x0, [fp, #-0x28]
    // 0xd3f1a8: r1 = 1
    //     0xd3f1a8: mov             x1, #1
    // 0xd3f1ac: r0 = AllocateContext()
    //     0xd3f1ac: bl              #0x13de838  ; AllocateContextStub
    // 0xd3f1b0: mov             x1, x0
    // 0xd3f1b4: ldur            x0, [fp, #-0x28]
    // 0xd3f1b8: StoreField: r1->field_f = r0
    //     0xd3f1b8: stur            w0, [x1, #0xf]
    // 0xd3f1bc: mov             x2, x1
    // 0xd3f1c0: r1 = Function '<anonymous closure>':.
    //     0xd3f1c0: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa35a0] AnonymousClosure: (0xd42a54), of [package:flutter/src/material/switch.dart] _SwitchConfigCupertino
    //     0xd3f1c4: ldr             x1, [x1, #0x5a0]
    // 0xd3f1c8: r0 = AllocateClosure()
    //     0xd3f1c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3f1cc: r16 = <Color>
    //     0xd3f1cc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd3f1d0: ldr             x16, [x16, #0xa90]
    // 0xd3f1d4: stp             x0, x16, [SP]
    // 0xd3f1d8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3f1d8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3f1dc: r0 = resolveWith()
    //     0xd3f1dc: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3f1e0: mov             x1, x0
    // 0xd3f1e4: ldur            x3, [fp, #-0x50]
    // 0xd3f1e8: r0 = LoadClassIdInstr(r1)
    //     0xd3f1e8: ldur            x0, [x1, #-1]
    //     0xd3f1ec: ubfx            x0, x0, #0xc, #0x14
    // 0xd3f1f0: ldur            x2, [fp, #-0x20]
    // 0xd3f1f4: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd3f1f4: mov             x17, #0x7c77
    //     0xd3f1f8: movk            x17, #1, lsl #16
    //     0xd3f1fc: add             lr, x0, x17
    //     0xd3f200: ldr             lr, [x21, lr, lsl #3]
    //     0xd3f204: blr             lr
    // 0xd3f208: mov             x1, x0
    // 0xd3f20c: ldur            x0, [fp, #-0x50]
    // 0xd3f210: stur            x1, [fp, #-0xa0]
    // 0xd3f214: r17 = 4622
    //     0xd3f214: mov             x17, #0x120e
    // 0xd3f218: cmp             x0, x17
    // 0xd3f21c: b.ne            #0xd3f264
    // 0xd3f220: ldur            x2, [fp, #-0x28]
    // 0xd3f224: r1 = 1
    //     0xd3f224: mov             x1, #1
    // 0xd3f228: r0 = AllocateContext()
    //     0xd3f228: bl              #0x13de838  ; AllocateContextStub
    // 0xd3f22c: mov             x1, x0
    // 0xd3f230: ldur            x0, [fp, #-0x28]
    // 0xd3f234: StoreField: r1->field_f = r0
    //     0xd3f234: stur            w0, [x1, #0xf]
    // 0xd3f238: mov             x2, x1
    // 0xd3f23c: r1 = Function '<anonymous closure>':.
    //     0xd3f23c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3598] AnonymousClosure: (0xd42b38), of [package:flutter/src/material/switch.dart] _SwitchConfigM3
    //     0xd3f240: ldr             x1, [x1, #0x598]
    // 0xd3f244: r0 = AllocateClosure()
    //     0xd3f244: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3f248: r16 = <Color>
    //     0xd3f248: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd3f24c: ldr             x16, [x16, #0xa90]
    // 0xd3f250: stp             x0, x16, [SP]
    // 0xd3f254: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3f254: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3f258: r0 = resolveWith()
    //     0xd3f258: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3f25c: mov             x1, x0
    // 0xd3f260: b               #0xd3f2d8
    // 0xd3f264: mov             x1, x0
    // 0xd3f268: ldur            x0, [fp, #-0x28]
    // 0xd3f26c: r17 = 4623
    //     0xd3f26c: mov             x17, #0x120f
    // 0xd3f270: cmp             x1, x17
    // 0xd3f274: b.ne            #0xd3f29c
    // 0xd3f278: r16 = <Color>
    //     0xd3f278: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd3f27c: ldr             x16, [x16, #0xa90]
    // 0xd3f280: r30 = Instance_Color
    //     0xd3f280: add             lr, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xd3f284: ldr             lr, [lr, #0x810]
    // 0xd3f288: stp             lr, x16, [SP]
    // 0xd3f28c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3f28c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3f290: r0 = all()
    //     0xd3f290: bl              #0xd13288  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::all
    // 0xd3f294: mov             x1, x0
    // 0xd3f298: b               #0xd3f2d8
    // 0xd3f29c: r1 = 1
    //     0xd3f29c: mov             x1, #1
    // 0xd3f2a0: r0 = AllocateContext()
    //     0xd3f2a0: bl              #0x13de838  ; AllocateContextStub
    // 0xd3f2a4: mov             x1, x0
    // 0xd3f2a8: ldur            x0, [fp, #-0x28]
    // 0xd3f2ac: StoreField: r1->field_f = r0
    //     0xd3f2ac: stur            w0, [x1, #0xf]
    // 0xd3f2b0: mov             x2, x1
    // 0xd3f2b4: r1 = Function '<anonymous closure>':.
    //     0xd3f2b4: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa35a0] AnonymousClosure: (0xd42a54), of [package:flutter/src/material/switch.dart] _SwitchConfigCupertino
    //     0xd3f2b8: ldr             x1, [x1, #0x5a0]
    // 0xd3f2bc: r0 = AllocateClosure()
    //     0xd3f2bc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3f2c0: r16 = <Color>
    //     0xd3f2c0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd3f2c4: ldr             x16, [x16, #0xa90]
    // 0xd3f2c8: stp             x0, x16, [SP]
    // 0xd3f2cc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3f2cc: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3f2d0: r0 = resolveWith()
    //     0xd3f2d0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3f2d4: mov             x1, x0
    // 0xd3f2d8: ldur            x4, [fp, #-8]
    // 0xd3f2dc: ldur            x3, [fp, #-0x18]
    // 0xd3f2e0: r0 = LoadClassIdInstr(r1)
    //     0xd3f2e0: ldur            x0, [x1, #-1]
    //     0xd3f2e4: ubfx            x0, x0, #0xc, #0x14
    // 0xd3f2e8: ldur            x2, [fp, #-0x38]
    // 0xd3f2ec: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd3f2ec: mov             x17, #0x7c77
    //     0xd3f2f0: movk            x17, #1, lsl #16
    //     0xd3f2f4: add             lr, x0, x17
    //     0xd3f2f8: ldr             lr, [x21, lr, lsl #3]
    //     0xd3f2fc: blr             lr
    // 0xd3f300: ldur            x1, [fp, #-8]
    // 0xd3f304: stur            x0, [fp, #-0x28]
    // 0xd3f308: r0 = states()
    //     0xd3f308: bl              #0x129daa0  ; [dart:mixin_deduplication] _MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0xd3f30c: mov             x1, x0
    // 0xd3f310: r2 = Instance_WidgetState
    //     0xd3f310: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd3f314: ldr             x2, [x2, #0xa60]
    // 0xd3f318: stur            x0, [fp, #-0xa8]
    // 0xd3f31c: r0 = add()
    //     0xd3f31c: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xd3f320: ldur            x1, [fp, #-8]
    // 0xd3f324: LoadField: r0 = r1->field_b
    //     0xd3f324: ldur            w0, [x1, #0xb]
    // 0xd3f328: DecompressPointer r0
    //     0xd3f328: add             x0, x0, HEAP, lsl #32
    // 0xd3f32c: cmp             w0, NULL
    // 0xd3f330: b.eq            #0xd40360
    // 0xd3f334: ldur            x2, [fp, #-0x18]
    // 0xd3f338: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xd3f338: ldur            w0, [x2, #0x17]
    // 0xd3f33c: DecompressPointer r0
    //     0xd3f33c: add             x0, x0, HEAP, lsl #32
    // 0xd3f340: stur            x0, [fp, #-0xb0]
    // 0xd3f344: r3 = LoadClassIdInstr(r0)
    //     0xd3f344: ldur            x3, [x0, #-1]
    //     0xd3f348: ubfx            x3, x3, #0xc, #0x14
    // 0xd3f34c: r17 = 5062
    //     0xd3f34c: mov             x17, #0x13c6
    // 0xd3f350: cmp             x3, x17
    // 0xd3f354: b.ne            #0xd3f370
    // 0xd3f358: LoadField: r3 = r0->field_1f
    //     0xd3f358: ldur            w3, [x0, #0x1f]
    // 0xd3f35c: DecompressPointer r3
    //     0xd3f35c: add             x3, x3, HEAP, lsl #32
    // 0xd3f360: mov             x0, x1
    // 0xd3f364: mov             x1, x3
    // 0xd3f368: mov             x3, x2
    // 0xd3f36c: b               #0xd3f45c
    // 0xd3f370: r17 = 5063
    //     0xd3f370: mov             x17, #0x13c7
    // 0xd3f374: cmp             x3, x17
    // 0xd3f378: b.ne            #0xd3f3c4
    // 0xd3f37c: r1 = 1
    //     0xd3f37c: mov             x1, #1
    // 0xd3f380: r0 = AllocateContext()
    //     0xd3f380: bl              #0x13de838  ; AllocateContextStub
    // 0xd3f384: mov             x1, x0
    // 0xd3f388: ldur            x0, [fp, #-0xb0]
    // 0xd3f38c: StoreField: r1->field_f = r0
    //     0xd3f38c: stur            w0, [x1, #0xf]
    // 0xd3f390: mov             x2, x1
    // 0xd3f394: r1 = Function '<anonymous closure>':.
    //     0xd3f394: add             x1, PP, #0x26, lsl #12  ; [pp+0x26170] AnonymousClosure: (0xd440d4), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0xd3f398: ldr             x1, [x1, #0x170]
    // 0xd3f39c: r0 = AllocateClosure()
    //     0xd3f39c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3f3a0: r16 = <Color?>
    //     0xd3f3a0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd3f3a4: ldr             x16, [x16, #0xa40]
    // 0xd3f3a8: stp             x0, x16, [SP]
    // 0xd3f3ac: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3f3ac: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3f3b0: r0 = resolveWith()
    //     0xd3f3b0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3f3b4: mov             x1, x0
    // 0xd3f3b8: ldur            x0, [fp, #-8]
    // 0xd3f3bc: ldur            x3, [fp, #-0x18]
    // 0xd3f3c0: b               #0xd3f45c
    // 0xd3f3c4: r17 = 5064
    //     0xd3f3c4: mov             x17, #0x13c8
    // 0xd3f3c8: cmp             x3, x17
    // 0xd3f3cc: b.ne            #0xd3f418
    // 0xd3f3d0: r1 = 1
    //     0xd3f3d0: mov             x1, #1
    // 0xd3f3d4: r0 = AllocateContext()
    //     0xd3f3d4: bl              #0x13de838  ; AllocateContextStub
    // 0xd3f3d8: mov             x1, x0
    // 0xd3f3dc: ldur            x0, [fp, #-0xb0]
    // 0xd3f3e0: StoreField: r1->field_f = r0
    //     0xd3f3e0: stur            w0, [x1, #0xf]
    // 0xd3f3e4: mov             x2, x1
    // 0xd3f3e8: r1 = Function '<anonymous closure>':.
    //     0xd3f3e8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26178] AnonymousClosure: (0xd43f64), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM2
    //     0xd3f3ec: ldr             x1, [x1, #0x178]
    // 0xd3f3f0: r0 = AllocateClosure()
    //     0xd3f3f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3f3f4: r16 = <Color?>
    //     0xd3f3f4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd3f3f8: ldr             x16, [x16, #0xa40]
    // 0xd3f3fc: stp             x0, x16, [SP]
    // 0xd3f400: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3f400: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3f404: r0 = resolveWith()
    //     0xd3f404: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3f408: mov             x1, x0
    // 0xd3f40c: ldur            x0, [fp, #-8]
    // 0xd3f410: ldur            x3, [fp, #-0x18]
    // 0xd3f414: b               #0xd3f45c
    // 0xd3f418: r1 = 1
    //     0xd3f418: mov             x1, #1
    // 0xd3f41c: r0 = AllocateContext()
    //     0xd3f41c: bl              #0x13de838  ; AllocateContextStub
    // 0xd3f420: mov             x1, x0
    // 0xd3f424: ldur            x0, [fp, #-0xb0]
    // 0xd3f428: StoreField: r1->field_f = r0
    //     0xd3f428: stur            w0, [x1, #0xf]
    // 0xd3f42c: mov             x2, x1
    // 0xd3f430: r1 = Function '<anonymous closure>':.
    //     0xd3f430: add             x1, PP, #0x26, lsl #12  ; [pp+0x26180] AnonymousClosure: (0xd431a0), of [package:flutter/src/material/switch.dart] _SwitchDefaultsCupertino
    //     0xd3f434: ldr             x1, [x1, #0x180]
    // 0xd3f438: r0 = AllocateClosure()
    //     0xd3f438: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3f43c: r16 = <Color?>
    //     0xd3f43c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd3f440: ldr             x16, [x16, #0xa40]
    // 0xd3f444: stp             x0, x16, [SP]
    // 0xd3f448: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3f448: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3f44c: r0 = resolveWith()
    //     0xd3f44c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3f450: mov             x1, x0
    // 0xd3f454: ldur            x0, [fp, #-8]
    // 0xd3f458: ldur            x3, [fp, #-0x18]
    // 0xd3f45c: ldur            x2, [fp, #-0xa8]
    // 0xd3f460: r0 = build()
    //     0xd3f460: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd3f464: stur            x0, [fp, #-0xa8]
    // 0xd3f468: cmp             w0, NULL
    // 0xd3f46c: b.eq            #0xd40364
    // 0xd3f470: ldur            x1, [fp, #-8]
    // 0xd3f474: r0 = states()
    //     0xd3f474: bl              #0x129daa0  ; [dart:mixin_deduplication] _MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0xd3f478: mov             x1, x0
    // 0xd3f47c: r2 = Instance_WidgetState
    //     0xd3f47c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd3f480: ldr             x2, [x2, #0xa50]
    // 0xd3f484: stur            x0, [fp, #-0xb0]
    // 0xd3f488: r0 = add()
    //     0xd3f488: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xd3f48c: ldur            x1, [fp, #-8]
    // 0xd3f490: LoadField: r0 = r1->field_b
    //     0xd3f490: ldur            w0, [x1, #0xb]
    // 0xd3f494: DecompressPointer r0
    //     0xd3f494: add             x0, x0, HEAP, lsl #32
    // 0xd3f498: cmp             w0, NULL
    // 0xd3f49c: b.eq            #0xd40368
    // 0xd3f4a0: ldur            x2, [fp, #-0x18]
    // 0xd3f4a4: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xd3f4a4: ldur            w0, [x2, #0x17]
    // 0xd3f4a8: DecompressPointer r0
    //     0xd3f4a8: add             x0, x0, HEAP, lsl #32
    // 0xd3f4ac: stur            x0, [fp, #-0xb8]
    // 0xd3f4b0: r3 = LoadClassIdInstr(r0)
    //     0xd3f4b0: ldur            x3, [x0, #-1]
    //     0xd3f4b4: ubfx            x3, x3, #0xc, #0x14
    // 0xd3f4b8: r17 = 5062
    //     0xd3f4b8: mov             x17, #0x13c6
    // 0xd3f4bc: cmp             x3, x17
    // 0xd3f4c0: b.ne            #0xd3f4d8
    // 0xd3f4c4: LoadField: r3 = r0->field_1f
    //     0xd3f4c4: ldur            w3, [x0, #0x1f]
    // 0xd3f4c8: DecompressPointer r3
    //     0xd3f4c8: add             x3, x3, HEAP, lsl #32
    // 0xd3f4cc: mov             x0, x1
    // 0xd3f4d0: mov             x1, x3
    // 0xd3f4d4: b               #0xd3f5b8
    // 0xd3f4d8: r17 = 5063
    //     0xd3f4d8: mov             x17, #0x13c7
    // 0xd3f4dc: cmp             x3, x17
    // 0xd3f4e0: b.ne            #0xd3f528
    // 0xd3f4e4: r1 = 1
    //     0xd3f4e4: mov             x1, #1
    // 0xd3f4e8: r0 = AllocateContext()
    //     0xd3f4e8: bl              #0x13de838  ; AllocateContextStub
    // 0xd3f4ec: mov             x1, x0
    // 0xd3f4f0: ldur            x0, [fp, #-0xb8]
    // 0xd3f4f4: StoreField: r1->field_f = r0
    //     0xd3f4f4: stur            w0, [x1, #0xf]
    // 0xd3f4f8: mov             x2, x1
    // 0xd3f4fc: r1 = Function '<anonymous closure>':.
    //     0xd3f4fc: add             x1, PP, #0x26, lsl #12  ; [pp+0x26170] AnonymousClosure: (0xd440d4), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0xd3f500: ldr             x1, [x1, #0x170]
    // 0xd3f504: r0 = AllocateClosure()
    //     0xd3f504: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3f508: r16 = <Color?>
    //     0xd3f508: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd3f50c: ldr             x16, [x16, #0xa40]
    // 0xd3f510: stp             x0, x16, [SP]
    // 0xd3f514: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3f514: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3f518: r0 = resolveWith()
    //     0xd3f518: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3f51c: mov             x1, x0
    // 0xd3f520: ldur            x0, [fp, #-8]
    // 0xd3f524: b               #0xd3f5b8
    // 0xd3f528: r17 = 5064
    //     0xd3f528: mov             x17, #0x13c8
    // 0xd3f52c: cmp             x3, x17
    // 0xd3f530: b.ne            #0xd3f578
    // 0xd3f534: r1 = 1
    //     0xd3f534: mov             x1, #1
    // 0xd3f538: r0 = AllocateContext()
    //     0xd3f538: bl              #0x13de838  ; AllocateContextStub
    // 0xd3f53c: mov             x1, x0
    // 0xd3f540: ldur            x0, [fp, #-0xb8]
    // 0xd3f544: StoreField: r1->field_f = r0
    //     0xd3f544: stur            w0, [x1, #0xf]
    // 0xd3f548: mov             x2, x1
    // 0xd3f54c: r1 = Function '<anonymous closure>':.
    //     0xd3f54c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26178] AnonymousClosure: (0xd43f64), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM2
    //     0xd3f550: ldr             x1, [x1, #0x178]
    // 0xd3f554: r0 = AllocateClosure()
    //     0xd3f554: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3f558: r16 = <Color?>
    //     0xd3f558: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd3f55c: ldr             x16, [x16, #0xa40]
    // 0xd3f560: stp             x0, x16, [SP]
    // 0xd3f564: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3f564: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3f568: r0 = resolveWith()
    //     0xd3f568: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3f56c: mov             x1, x0
    // 0xd3f570: ldur            x0, [fp, #-8]
    // 0xd3f574: b               #0xd3f5b8
    // 0xd3f578: r1 = 1
    //     0xd3f578: mov             x1, #1
    // 0xd3f57c: r0 = AllocateContext()
    //     0xd3f57c: bl              #0x13de838  ; AllocateContextStub
    // 0xd3f580: mov             x1, x0
    // 0xd3f584: ldur            x0, [fp, #-0xb8]
    // 0xd3f588: StoreField: r1->field_f = r0
    //     0xd3f588: stur            w0, [x1, #0xf]
    // 0xd3f58c: mov             x2, x1
    // 0xd3f590: r1 = Function '<anonymous closure>':.
    //     0xd3f590: add             x1, PP, #0x26, lsl #12  ; [pp+0x26180] AnonymousClosure: (0xd431a0), of [package:flutter/src/material/switch.dart] _SwitchDefaultsCupertino
    //     0xd3f594: ldr             x1, [x1, #0x180]
    // 0xd3f598: r0 = AllocateClosure()
    //     0xd3f598: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3f59c: r16 = <Color?>
    //     0xd3f59c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd3f5a0: ldr             x16, [x16, #0xa40]
    // 0xd3f5a4: stp             x0, x16, [SP]
    // 0xd3f5a8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3f5a8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3f5ac: r0 = resolveWith()
    //     0xd3f5ac: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3f5b0: mov             x1, x0
    // 0xd3f5b4: ldur            x0, [fp, #-8]
    // 0xd3f5b8: ldur            x2, [fp, #-0xb0]
    // 0xd3f5bc: r0 = build()
    //     0xd3f5bc: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd3f5c0: stur            x0, [fp, #-0xb0]
    // 0xd3f5c4: cmp             w0, NULL
    // 0xd3f5c8: b.eq            #0xd4036c
    // 0xd3f5cc: ldur            x1, [fp, #-0x20]
    // 0xd3f5d0: r2 = Instance_WidgetState
    //     0xd3f5d0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd3f5d4: ldr             x2, [x2, #0xa48]
    // 0xd3f5d8: r0 = add()
    //     0xd3f5d8: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xd3f5dc: ldur            x1, [fp, #-8]
    // 0xd3f5e0: LoadField: r0 = r1->field_b
    //     0xd3f5e0: ldur            w0, [x1, #0xb]
    // 0xd3f5e4: DecompressPointer r0
    //     0xd3f5e4: add             x0, x0, HEAP, lsl #32
    // 0xd3f5e8: cmp             w0, NULL
    // 0xd3f5ec: b.eq            #0xd40370
    // 0xd3f5f0: r1 = 1
    //     0xd3f5f0: mov             x1, #1
    // 0xd3f5f4: r0 = AllocateContext()
    //     0xd3f5f4: bl              #0x13de838  ; AllocateContextStub
    // 0xd3f5f8: mov             x1, x0
    // 0xd3f5fc: ldur            x0, [fp, #-8]
    // 0xd3f600: StoreField: r1->field_f = r0
    //     0xd3f600: stur            w0, [x1, #0xf]
    // 0xd3f604: mov             x2, x1
    // 0xd3f608: r1 = Function '<anonymous closure>':.
    //     0xd3f608: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3588] AnonymousClosure: (0xd43078), in [package:flutter/src/material/switch.dart] _MaterialSwitchState::_widgetThumbColor (0xd420a0)
    //     0xd3f60c: ldr             x1, [x1, #0x588]
    // 0xd3f610: r0 = AllocateClosure()
    //     0xd3f610: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3f614: r16 = <Color?>
    //     0xd3f614: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd3f618: ldr             x16, [x16, #0xa40]
    // 0xd3f61c: stp             x0, x16, [SP]
    // 0xd3f620: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3f620: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3f624: r0 = resolveWith()
    //     0xd3f624: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3f628: mov             x1, x0
    // 0xd3f62c: ldur            x2, [fp, #-0x20]
    // 0xd3f630: r0 = build()
    //     0xd3f630: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd3f634: cmp             w0, NULL
    // 0xd3f638: b.ne            #0xd3f640
    // 0xd3f63c: r0 = Null
    //     0xd3f63c: mov             x0, NULL
    // 0xd3f640: cmp             w0, NULL
    // 0xd3f644: b.ne            #0xd3f778
    // 0xd3f648: ldur            x2, [fp, #-0x18]
    // 0xd3f64c: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xd3f64c: ldur            w0, [x2, #0x17]
    // 0xd3f650: DecompressPointer r0
    //     0xd3f650: add             x0, x0, HEAP, lsl #32
    // 0xd3f654: stur            x0, [fp, #-0xb8]
    // 0xd3f658: r1 = LoadClassIdInstr(r0)
    //     0xd3f658: ldur            x1, [x0, #-1]
    //     0xd3f65c: ubfx            x1, x1, #0xc, #0x14
    // 0xd3f660: r17 = 5062
    //     0xd3f660: mov             x17, #0x13c6
    // 0xd3f664: cmp             x1, x17
    // 0xd3f668: b.ne            #0xd3f678
    // 0xd3f66c: LoadField: r1 = r0->field_7
    //     0xd3f66c: ldur            w1, [x0, #7]
    // 0xd3f670: DecompressPointer r1
    //     0xd3f670: add             x1, x1, HEAP, lsl #32
    // 0xd3f674: b               #0xd3f748
    // 0xd3f678: r17 = 5063
    //     0xd3f678: mov             x17, #0x13c7
    // 0xd3f67c: cmp             x1, x17
    // 0xd3f680: b.ne            #0xd3f6c4
    // 0xd3f684: r1 = 1
    //     0xd3f684: mov             x1, #1
    // 0xd3f688: r0 = AllocateContext()
    //     0xd3f688: bl              #0x13de838  ; AllocateContextStub
    // 0xd3f68c: mov             x1, x0
    // 0xd3f690: ldur            x0, [fp, #-0xb8]
    // 0xd3f694: StoreField: r1->field_f = r0
    //     0xd3f694: stur            w0, [x1, #0xf]
    // 0xd3f698: mov             x2, x1
    // 0xd3f69c: r1 = Function '<anonymous closure>':.
    //     0xd3f69c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26110] AnonymousClosure: (0xd44f24), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0xd3f6a0: ldr             x1, [x1, #0x110]
    // 0xd3f6a4: r0 = AllocateClosure()
    //     0xd3f6a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3f6a8: r16 = <Color>
    //     0xd3f6a8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd3f6ac: ldr             x16, [x16, #0xa90]
    // 0xd3f6b0: stp             x0, x16, [SP]
    // 0xd3f6b4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3f6b4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3f6b8: r0 = resolveWith()
    //     0xd3f6b8: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3f6bc: mov             x1, x0
    // 0xd3f6c0: b               #0xd3f748
    // 0xd3f6c4: r17 = 5064
    //     0xd3f6c4: mov             x17, #0x13c8
    // 0xd3f6c8: cmp             x1, x17
    // 0xd3f6cc: b.ne            #0xd3f740
    // 0xd3f6d0: r1 = 2
    //     0xd3f6d0: mov             x1, #2
    // 0xd3f6d4: r0 = AllocateContext()
    //     0xd3f6d4: bl              #0x13de838  ; AllocateContextStub
    // 0xd3f6d8: mov             x1, x0
    // 0xd3f6dc: ldur            x0, [fp, #-0xb8]
    // 0xd3f6e0: StoreField: r1->field_f = r0
    //     0xd3f6e0: stur            w0, [x1, #0xf]
    // 0xd3f6e4: LoadField: r2 = r0->field_2f
    //     0xd3f6e4: ldur            w2, [x0, #0x2f]
    // 0xd3f6e8: DecompressPointer r2
    //     0xd3f6e8: add             x2, x2, HEAP, lsl #32
    // 0xd3f6ec: LoadField: r0 = r2->field_3f
    //     0xd3f6ec: ldur            w0, [x2, #0x3f]
    // 0xd3f6f0: DecompressPointer r0
    //     0xd3f6f0: add             x0, x0, HEAP, lsl #32
    // 0xd3f6f4: LoadField: r2 = r0->field_7
    //     0xd3f6f4: ldur            w2, [x0, #7]
    // 0xd3f6f8: DecompressPointer r2
    //     0xd3f6f8: add             x2, x2, HEAP, lsl #32
    // 0xd3f6fc: r16 = Instance_Brightness
    //     0xd3f6fc: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xd3f700: cmp             w2, w16
    // 0xd3f704: r16 = true
    //     0xd3f704: add             x16, NULL, #0x20  ; true
    // 0xd3f708: r17 = false
    //     0xd3f708: add             x17, NULL, #0x30  ; false
    // 0xd3f70c: csel            x0, x16, x17, eq
    // 0xd3f710: StoreField: r1->field_13 = r0
    //     0xd3f710: stur            w0, [x1, #0x13]
    // 0xd3f714: mov             x2, x1
    // 0xd3f718: r1 = Function '<anonymous closure>':.
    //     0xd3f718: add             x1, PP, #0x26, lsl #12  ; [pp+0x26118] AnonymousClosure: (0xd44d38), in [package:flutter/src/material/switch.dart] _SwitchDefaultsM2::thumbColor (0x129d570)
    //     0xd3f71c: ldr             x1, [x1, #0x118]
    // 0xd3f720: r0 = AllocateClosure()
    //     0xd3f720: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3f724: r16 = <Color>
    //     0xd3f724: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd3f728: ldr             x16, [x16, #0xa90]
    // 0xd3f72c: stp             x0, x16, [SP]
    // 0xd3f730: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3f730: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3f734: r0 = resolveWith()
    //     0xd3f734: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3f738: mov             x1, x0
    // 0xd3f73c: b               #0xd3f748
    // 0xd3f740: r1 = Instance_WidgetStatePropertyAll
    //     0xd3f740: add             x1, PP, #0x26, lsl #12  ; [pp+0x26120] Obj!WidgetStatePropertyAll<Color>@128a081
    //     0xd3f744: ldr             x1, [x1, #0x120]
    // 0xd3f748: r0 = LoadClassIdInstr(r1)
    //     0xd3f748: ldur            x0, [x1, #-1]
    //     0xd3f74c: ubfx            x0, x0, #0xc, #0x14
    // 0xd3f750: ldur            x2, [fp, #-0x20]
    // 0xd3f754: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd3f754: mov             x17, #0x7c77
    //     0xd3f758: movk            x17, #1, lsl #16
    //     0xd3f75c: add             lr, x0, x17
    //     0xd3f760: ldr             lr, [x21, lr, lsl #3]
    //     0xd3f764: blr             lr
    // 0xd3f768: cmp             w0, NULL
    // 0xd3f76c: b.eq            #0xd40374
    // 0xd3f770: mov             x4, x0
    // 0xd3f774: b               #0xd3f77c
    // 0xd3f778: mov             x4, x0
    // 0xd3f77c: ldur            x3, [fp, #-8]
    // 0xd3f780: ldur            x1, [fp, #-0x58]
    // 0xd3f784: stur            x4, [fp, #-0xb8]
    // 0xd3f788: LoadField: r0 = r3->field_b
    //     0xd3f788: ldur            w0, [x3, #0xb]
    // 0xd3f78c: DecompressPointer r0
    //     0xd3f78c: add             x0, x0, HEAP, lsl #32
    // 0xd3f790: cmp             w0, NULL
    // 0xd3f794: b.eq            #0xd40378
    // 0xd3f798: cmp             w1, NULL
    // 0xd3f79c: b.ne            #0xd3f7a8
    // 0xd3f7a0: r0 = Null
    //     0xd3f7a0: mov             x0, NULL
    // 0xd3f7a4: b               #0xd3f7c0
    // 0xd3f7a8: r0 = LoadClassIdInstr(r1)
    //     0xd3f7a8: ldur            x0, [x1, #-1]
    //     0xd3f7ac: ubfx            x0, x0, #0xc, #0x14
    // 0xd3f7b0: r2 = 31
    //     0xd3f7b0: mov             x2, #0x1f
    // 0xd3f7b4: r0 = GDT[cid_x0 + -0xff4]()
    //     0xd3f7b4: sub             lr, x0, #0xff4
    //     0xd3f7b8: ldr             lr, [x21, lr, lsl #3]
    //     0xd3f7bc: blr             lr
    // 0xd3f7c0: cmp             w0, NULL
    // 0xd3f7c4: b.ne            #0xd3f8e4
    // 0xd3f7c8: ldur            x2, [fp, #-0x18]
    // 0xd3f7cc: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xd3f7cc: ldur            w0, [x2, #0x17]
    // 0xd3f7d0: DecompressPointer r0
    //     0xd3f7d0: add             x0, x0, HEAP, lsl #32
    // 0xd3f7d4: stur            x0, [fp, #-0x58]
    // 0xd3f7d8: r1 = LoadClassIdInstr(r0)
    //     0xd3f7d8: ldur            x1, [x0, #-1]
    //     0xd3f7dc: ubfx            x1, x1, #0xc, #0x14
    // 0xd3f7e0: r17 = 5062
    //     0xd3f7e0: mov             x17, #0x13c6
    // 0xd3f7e4: cmp             x1, x17
    // 0xd3f7e8: b.ne            #0xd3f7f8
    // 0xd3f7ec: LoadField: r1 = r0->field_1f
    //     0xd3f7ec: ldur            w1, [x0, #0x1f]
    // 0xd3f7f0: DecompressPointer r1
    //     0xd3f7f0: add             x1, x1, HEAP, lsl #32
    // 0xd3f7f4: b               #0xd3f8cc
    // 0xd3f7f8: r17 = 5063
    //     0xd3f7f8: mov             x17, #0x13c7
    // 0xd3f7fc: cmp             x1, x17
    // 0xd3f800: b.ne            #0xd3f844
    // 0xd3f804: r1 = 1
    //     0xd3f804: mov             x1, #1
    // 0xd3f808: r0 = AllocateContext()
    //     0xd3f808: bl              #0x13de838  ; AllocateContextStub
    // 0xd3f80c: mov             x1, x0
    // 0xd3f810: ldur            x0, [fp, #-0x58]
    // 0xd3f814: StoreField: r1->field_f = r0
    //     0xd3f814: stur            w0, [x1, #0xf]
    // 0xd3f818: mov             x2, x1
    // 0xd3f81c: r1 = Function '<anonymous closure>':.
    //     0xd3f81c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26170] AnonymousClosure: (0xd440d4), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0xd3f820: ldr             x1, [x1, #0x170]
    // 0xd3f824: r0 = AllocateClosure()
    //     0xd3f824: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3f828: r16 = <Color?>
    //     0xd3f828: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd3f82c: ldr             x16, [x16, #0xa40]
    // 0xd3f830: stp             x0, x16, [SP]
    // 0xd3f834: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3f834: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3f838: r0 = resolveWith()
    //     0xd3f838: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3f83c: mov             x1, x0
    // 0xd3f840: b               #0xd3f8cc
    // 0xd3f844: r17 = 5064
    //     0xd3f844: mov             x17, #0x13c8
    // 0xd3f848: cmp             x1, x17
    // 0xd3f84c: b.ne            #0xd3f890
    // 0xd3f850: r1 = 1
    //     0xd3f850: mov             x1, #1
    // 0xd3f854: r0 = AllocateContext()
    //     0xd3f854: bl              #0x13de838  ; AllocateContextStub
    // 0xd3f858: mov             x1, x0
    // 0xd3f85c: ldur            x0, [fp, #-0x58]
    // 0xd3f860: StoreField: r1->field_f = r0
    //     0xd3f860: stur            w0, [x1, #0xf]
    // 0xd3f864: mov             x2, x1
    // 0xd3f868: r1 = Function '<anonymous closure>':.
    //     0xd3f868: add             x1, PP, #0x26, lsl #12  ; [pp+0x26178] AnonymousClosure: (0xd43f64), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM2
    //     0xd3f86c: ldr             x1, [x1, #0x178]
    // 0xd3f870: r0 = AllocateClosure()
    //     0xd3f870: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3f874: r16 = <Color?>
    //     0xd3f874: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd3f878: ldr             x16, [x16, #0xa40]
    // 0xd3f87c: stp             x0, x16, [SP]
    // 0xd3f880: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3f880: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3f884: r0 = resolveWith()
    //     0xd3f884: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3f888: mov             x1, x0
    // 0xd3f88c: b               #0xd3f8cc
    // 0xd3f890: r1 = 1
    //     0xd3f890: mov             x1, #1
    // 0xd3f894: r0 = AllocateContext()
    //     0xd3f894: bl              #0x13de838  ; AllocateContextStub
    // 0xd3f898: mov             x1, x0
    // 0xd3f89c: ldur            x0, [fp, #-0x58]
    // 0xd3f8a0: StoreField: r1->field_f = r0
    //     0xd3f8a0: stur            w0, [x1, #0xf]
    // 0xd3f8a4: mov             x2, x1
    // 0xd3f8a8: r1 = Function '<anonymous closure>':.
    //     0xd3f8a8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26180] AnonymousClosure: (0xd431a0), of [package:flutter/src/material/switch.dart] _SwitchDefaultsCupertino
    //     0xd3f8ac: ldr             x1, [x1, #0x180]
    // 0xd3f8b0: r0 = AllocateClosure()
    //     0xd3f8b0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3f8b4: r16 = <Color?>
    //     0xd3f8b4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd3f8b8: ldr             x16, [x16, #0xa40]
    // 0xd3f8bc: stp             x0, x16, [SP]
    // 0xd3f8c0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3f8c0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3f8c4: r0 = resolveWith()
    //     0xd3f8c4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3f8c8: mov             x1, x0
    // 0xd3f8cc: ldur            x2, [fp, #-0x20]
    // 0xd3f8d0: r0 = build()
    //     0xd3f8d0: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd3f8d4: cmp             w0, NULL
    // 0xd3f8d8: b.eq            #0xd4037c
    // 0xd3f8dc: mov             x3, x0
    // 0xd3f8e0: b               #0xd3f8e8
    // 0xd3f8e4: mov             x3, x0
    // 0xd3f8e8: ldur            x0, [fp, #-8]
    // 0xd3f8ec: ldur            x1, [fp, #-0x38]
    // 0xd3f8f0: stur            x3, [fp, #-0x20]
    // 0xd3f8f4: r2 = Instance_WidgetState
    //     0xd3f8f4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd3f8f8: ldr             x2, [x2, #0xa48]
    // 0xd3f8fc: r0 = add()
    //     0xd3f8fc: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xd3f900: ldur            x0, [fp, #-8]
    // 0xd3f904: LoadField: r1 = r0->field_b
    //     0xd3f904: ldur            w1, [x0, #0xb]
    // 0xd3f908: DecompressPointer r1
    //     0xd3f908: add             x1, x1, HEAP, lsl #32
    // 0xd3f90c: cmp             w1, NULL
    // 0xd3f910: b.eq            #0xd40380
    // 0xd3f914: mov             x1, x0
    // 0xd3f918: r0 = _widgetThumbColor()
    //     0xd3f918: bl              #0xd420a0  ; [package:flutter/src/material/switch.dart] _MaterialSwitchState::_widgetThumbColor
    // 0xd3f91c: mov             x1, x0
    // 0xd3f920: ldur            x2, [fp, #-0x38]
    // 0xd3f924: r0 = build()
    //     0xd3f924: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd3f928: cmp             w0, NULL
    // 0xd3f92c: b.ne            #0xd3f934
    // 0xd3f930: r0 = Null
    //     0xd3f930: mov             x0, NULL
    // 0xd3f934: cmp             w0, NULL
    // 0xd3f938: b.ne            #0xd3fa6c
    // 0xd3f93c: ldur            x2, [fp, #-0x18]
    // 0xd3f940: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xd3f940: ldur            w0, [x2, #0x17]
    // 0xd3f944: DecompressPointer r0
    //     0xd3f944: add             x0, x0, HEAP, lsl #32
    // 0xd3f948: stur            x0, [fp, #-0x58]
    // 0xd3f94c: r1 = LoadClassIdInstr(r0)
    //     0xd3f94c: ldur            x1, [x0, #-1]
    //     0xd3f950: ubfx            x1, x1, #0xc, #0x14
    // 0xd3f954: r17 = 5062
    //     0xd3f954: mov             x17, #0x13c6
    // 0xd3f958: cmp             x1, x17
    // 0xd3f95c: b.ne            #0xd3f96c
    // 0xd3f960: LoadField: r1 = r0->field_7
    //     0xd3f960: ldur            w1, [x0, #7]
    // 0xd3f964: DecompressPointer r1
    //     0xd3f964: add             x1, x1, HEAP, lsl #32
    // 0xd3f968: b               #0xd3fa3c
    // 0xd3f96c: r17 = 5063
    //     0xd3f96c: mov             x17, #0x13c7
    // 0xd3f970: cmp             x1, x17
    // 0xd3f974: b.ne            #0xd3f9b8
    // 0xd3f978: r1 = 1
    //     0xd3f978: mov             x1, #1
    // 0xd3f97c: r0 = AllocateContext()
    //     0xd3f97c: bl              #0x13de838  ; AllocateContextStub
    // 0xd3f980: mov             x1, x0
    // 0xd3f984: ldur            x0, [fp, #-0x58]
    // 0xd3f988: StoreField: r1->field_f = r0
    //     0xd3f988: stur            w0, [x1, #0xf]
    // 0xd3f98c: mov             x2, x1
    // 0xd3f990: r1 = Function '<anonymous closure>':.
    //     0xd3f990: add             x1, PP, #0x26, lsl #12  ; [pp+0x26110] AnonymousClosure: (0xd44f24), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0xd3f994: ldr             x1, [x1, #0x110]
    // 0xd3f998: r0 = AllocateClosure()
    //     0xd3f998: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3f99c: r16 = <Color>
    //     0xd3f99c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd3f9a0: ldr             x16, [x16, #0xa90]
    // 0xd3f9a4: stp             x0, x16, [SP]
    // 0xd3f9a8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3f9a8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3f9ac: r0 = resolveWith()
    //     0xd3f9ac: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3f9b0: mov             x1, x0
    // 0xd3f9b4: b               #0xd3fa3c
    // 0xd3f9b8: r17 = 5064
    //     0xd3f9b8: mov             x17, #0x13c8
    // 0xd3f9bc: cmp             x1, x17
    // 0xd3f9c0: b.ne            #0xd3fa34
    // 0xd3f9c4: r1 = 2
    //     0xd3f9c4: mov             x1, #2
    // 0xd3f9c8: r0 = AllocateContext()
    //     0xd3f9c8: bl              #0x13de838  ; AllocateContextStub
    // 0xd3f9cc: mov             x1, x0
    // 0xd3f9d0: ldur            x0, [fp, #-0x58]
    // 0xd3f9d4: StoreField: r1->field_f = r0
    //     0xd3f9d4: stur            w0, [x1, #0xf]
    // 0xd3f9d8: LoadField: r2 = r0->field_2f
    //     0xd3f9d8: ldur            w2, [x0, #0x2f]
    // 0xd3f9dc: DecompressPointer r2
    //     0xd3f9dc: add             x2, x2, HEAP, lsl #32
    // 0xd3f9e0: LoadField: r0 = r2->field_3f
    //     0xd3f9e0: ldur            w0, [x2, #0x3f]
    // 0xd3f9e4: DecompressPointer r0
    //     0xd3f9e4: add             x0, x0, HEAP, lsl #32
    // 0xd3f9e8: LoadField: r2 = r0->field_7
    //     0xd3f9e8: ldur            w2, [x0, #7]
    // 0xd3f9ec: DecompressPointer r2
    //     0xd3f9ec: add             x2, x2, HEAP, lsl #32
    // 0xd3f9f0: r16 = Instance_Brightness
    //     0xd3f9f0: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xd3f9f4: cmp             w2, w16
    // 0xd3f9f8: r16 = true
    //     0xd3f9f8: add             x16, NULL, #0x20  ; true
    // 0xd3f9fc: r17 = false
    //     0xd3f9fc: add             x17, NULL, #0x30  ; false
    // 0xd3fa00: csel            x0, x16, x17, eq
    // 0xd3fa04: StoreField: r1->field_13 = r0
    //     0xd3fa04: stur            w0, [x1, #0x13]
    // 0xd3fa08: mov             x2, x1
    // 0xd3fa0c: r1 = Function '<anonymous closure>':.
    //     0xd3fa0c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26118] AnonymousClosure: (0xd44d38), in [package:flutter/src/material/switch.dart] _SwitchDefaultsM2::thumbColor (0x129d570)
    //     0xd3fa10: ldr             x1, [x1, #0x118]
    // 0xd3fa14: r0 = AllocateClosure()
    //     0xd3fa14: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3fa18: r16 = <Color>
    //     0xd3fa18: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd3fa1c: ldr             x16, [x16, #0xa90]
    // 0xd3fa20: stp             x0, x16, [SP]
    // 0xd3fa24: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3fa24: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3fa28: r0 = resolveWith()
    //     0xd3fa28: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3fa2c: mov             x1, x0
    // 0xd3fa30: b               #0xd3fa3c
    // 0xd3fa34: r1 = Instance_WidgetStatePropertyAll
    //     0xd3fa34: add             x1, PP, #0x26, lsl #12  ; [pp+0x26120] Obj!WidgetStatePropertyAll<Color>@128a081
    //     0xd3fa38: ldr             x1, [x1, #0x120]
    // 0xd3fa3c: r0 = LoadClassIdInstr(r1)
    //     0xd3fa3c: ldur            x0, [x1, #-1]
    //     0xd3fa40: ubfx            x0, x0, #0xc, #0x14
    // 0xd3fa44: ldur            x2, [fp, #-0x38]
    // 0xd3fa48: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd3fa48: mov             x17, #0x7c77
    //     0xd3fa4c: movk            x17, #1, lsl #16
    //     0xd3fa50: add             lr, x0, x17
    //     0xd3fa54: ldr             lr, [x21, lr, lsl #3]
    //     0xd3fa58: blr             lr
    // 0xd3fa5c: cmp             w0, NULL
    // 0xd3fa60: b.eq            #0xd40384
    // 0xd3fa64: mov             x4, x0
    // 0xd3fa68: b               #0xd3fa70
    // 0xd3fa6c: mov             x4, x0
    // 0xd3fa70: ldur            x3, [fp, #-8]
    // 0xd3fa74: ldur            x1, [fp, #-0x68]
    // 0xd3fa78: stur            x4, [fp, #-0x58]
    // 0xd3fa7c: LoadField: r0 = r3->field_b
    //     0xd3fa7c: ldur            w0, [x3, #0xb]
    // 0xd3fa80: DecompressPointer r0
    //     0xd3fa80: add             x0, x0, HEAP, lsl #32
    // 0xd3fa84: cmp             w0, NULL
    // 0xd3fa88: b.eq            #0xd40388
    // 0xd3fa8c: cmp             w1, NULL
    // 0xd3fa90: b.ne            #0xd3fa9c
    // 0xd3fa94: r0 = Null
    //     0xd3fa94: mov             x0, NULL
    // 0xd3fa98: b               #0xd3fab4
    // 0xd3fa9c: r0 = LoadClassIdInstr(r1)
    //     0xd3fa9c: ldur            x0, [x1, #-1]
    //     0xd3faa0: ubfx            x0, x0, #0xc, #0x14
    // 0xd3faa4: r2 = 31
    //     0xd3faa4: mov             x2, #0x1f
    // 0xd3faa8: r0 = GDT[cid_x0 + -0xff4]()
    //     0xd3faa8: sub             lr, x0, #0xff4
    //     0xd3faac: ldr             lr, [x21, lr, lsl #3]
    //     0xd3fab0: blr             lr
    // 0xd3fab4: cmp             w0, NULL
    // 0xd3fab8: b.ne            #0xd3fbd8
    // 0xd3fabc: ldur            x2, [fp, #-0x18]
    // 0xd3fac0: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xd3fac0: ldur            w0, [x2, #0x17]
    // 0xd3fac4: DecompressPointer r0
    //     0xd3fac4: add             x0, x0, HEAP, lsl #32
    // 0xd3fac8: stur            x0, [fp, #-0x68]
    // 0xd3facc: r1 = LoadClassIdInstr(r0)
    //     0xd3facc: ldur            x1, [x0, #-1]
    //     0xd3fad0: ubfx            x1, x1, #0xc, #0x14
    // 0xd3fad4: r17 = 5062
    //     0xd3fad4: mov             x17, #0x13c6
    // 0xd3fad8: cmp             x1, x17
    // 0xd3fadc: b.ne            #0xd3faec
    // 0xd3fae0: LoadField: r1 = r0->field_1f
    //     0xd3fae0: ldur            w1, [x0, #0x1f]
    // 0xd3fae4: DecompressPointer r1
    //     0xd3fae4: add             x1, x1, HEAP, lsl #32
    // 0xd3fae8: b               #0xd3fbc0
    // 0xd3faec: r17 = 5063
    //     0xd3faec: mov             x17, #0x13c7
    // 0xd3faf0: cmp             x1, x17
    // 0xd3faf4: b.ne            #0xd3fb38
    // 0xd3faf8: r1 = 1
    //     0xd3faf8: mov             x1, #1
    // 0xd3fafc: r0 = AllocateContext()
    //     0xd3fafc: bl              #0x13de838  ; AllocateContextStub
    // 0xd3fb00: mov             x1, x0
    // 0xd3fb04: ldur            x0, [fp, #-0x68]
    // 0xd3fb08: StoreField: r1->field_f = r0
    //     0xd3fb08: stur            w0, [x1, #0xf]
    // 0xd3fb0c: mov             x2, x1
    // 0xd3fb10: r1 = Function '<anonymous closure>':.
    //     0xd3fb10: add             x1, PP, #0x26, lsl #12  ; [pp+0x26170] AnonymousClosure: (0xd440d4), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0xd3fb14: ldr             x1, [x1, #0x170]
    // 0xd3fb18: r0 = AllocateClosure()
    //     0xd3fb18: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3fb1c: r16 = <Color?>
    //     0xd3fb1c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd3fb20: ldr             x16, [x16, #0xa40]
    // 0xd3fb24: stp             x0, x16, [SP]
    // 0xd3fb28: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3fb28: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3fb2c: r0 = resolveWith()
    //     0xd3fb2c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3fb30: mov             x1, x0
    // 0xd3fb34: b               #0xd3fbc0
    // 0xd3fb38: r17 = 5064
    //     0xd3fb38: mov             x17, #0x13c8
    // 0xd3fb3c: cmp             x1, x17
    // 0xd3fb40: b.ne            #0xd3fb84
    // 0xd3fb44: r1 = 1
    //     0xd3fb44: mov             x1, #1
    // 0xd3fb48: r0 = AllocateContext()
    //     0xd3fb48: bl              #0x13de838  ; AllocateContextStub
    // 0xd3fb4c: mov             x1, x0
    // 0xd3fb50: ldur            x0, [fp, #-0x68]
    // 0xd3fb54: StoreField: r1->field_f = r0
    //     0xd3fb54: stur            w0, [x1, #0xf]
    // 0xd3fb58: mov             x2, x1
    // 0xd3fb5c: r1 = Function '<anonymous closure>':.
    //     0xd3fb5c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26178] AnonymousClosure: (0xd43f64), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM2
    //     0xd3fb60: ldr             x1, [x1, #0x178]
    // 0xd3fb64: r0 = AllocateClosure()
    //     0xd3fb64: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3fb68: r16 = <Color?>
    //     0xd3fb68: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd3fb6c: ldr             x16, [x16, #0xa40]
    // 0xd3fb70: stp             x0, x16, [SP]
    // 0xd3fb74: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3fb74: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3fb78: r0 = resolveWith()
    //     0xd3fb78: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3fb7c: mov             x1, x0
    // 0xd3fb80: b               #0xd3fbc0
    // 0xd3fb84: r1 = 1
    //     0xd3fb84: mov             x1, #1
    // 0xd3fb88: r0 = AllocateContext()
    //     0xd3fb88: bl              #0x13de838  ; AllocateContextStub
    // 0xd3fb8c: mov             x1, x0
    // 0xd3fb90: ldur            x0, [fp, #-0x68]
    // 0xd3fb94: StoreField: r1->field_f = r0
    //     0xd3fb94: stur            w0, [x1, #0xf]
    // 0xd3fb98: mov             x2, x1
    // 0xd3fb9c: r1 = Function '<anonymous closure>':.
    //     0xd3fb9c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26180] AnonymousClosure: (0xd431a0), of [package:flutter/src/material/switch.dart] _SwitchDefaultsCupertino
    //     0xd3fba0: ldr             x1, [x1, #0x180]
    // 0xd3fba4: r0 = AllocateClosure()
    //     0xd3fba4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3fba8: r16 = <Color?>
    //     0xd3fba8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd3fbac: ldr             x16, [x16, #0xa40]
    // 0xd3fbb0: stp             x0, x16, [SP]
    // 0xd3fbb4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3fbb4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3fbb8: r0 = resolveWith()
    //     0xd3fbb8: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3fbbc: mov             x1, x0
    // 0xd3fbc0: ldur            x2, [fp, #-0x38]
    // 0xd3fbc4: r0 = build()
    //     0xd3fbc4: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd3fbc8: cmp             w0, NULL
    // 0xd3fbcc: b.eq            #0xd4038c
    // 0xd3fbd0: mov             x3, x0
    // 0xd3fbd4: b               #0xd3fbdc
    // 0xd3fbd8: mov             x3, x0
    // 0xd3fbdc: ldur            x0, [fp, #-0x50]
    // 0xd3fbe0: ldur            x2, [fp, #-0x18]
    // 0xd3fbe4: stur            x3, [fp, #-0x38]
    // 0xd3fbe8: r1 = Function '<anonymous closure>':.
    //     0xd3fbe8: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa35a8] AnonymousClosure: (0xd4286c), in [package:flutter/src/material/switch.dart] _MaterialSwitchState::build (0xd3e174)
    //     0xd3fbec: ldr             x1, [x1, #0x5a8]
    // 0xd3fbf0: r0 = AllocateClosure()
    //     0xd3fbf0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3fbf4: r16 = <MouseCursor>
    //     0xd3fbf4: ldr             x16, [PP, #0x21a8]  ; [pp+0x21a8] TypeArguments: <MouseCursor>
    // 0xd3fbf8: stp             x0, x16, [SP]
    // 0xd3fbfc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3fbfc: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd3fc00: r0 = resolveWith()
    //     0xd3fc00: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd3fc04: mov             x2, x0
    // 0xd3fc08: ldur            x0, [fp, #-0x50]
    // 0xd3fc0c: stur            x2, [fp, #-0xc0]
    // 0xd3fc10: r17 = 4622
    //     0xd3fc10: mov             x17, #0x120e
    // 0xd3fc14: cmp             x0, x17
    // 0xd3fc18: b.ne            #0xd3fc24
    // 0xd3fc1c: d0 = 12.000000
    //     0xd3fc1c: fmov            d0, #12.00000000
    // 0xd3fc20: b               #0xd3fc3c
    // 0xd3fc24: r17 = 4623
    //     0xd3fc24: mov             x17, #0x120f
    // 0xd3fc28: cmp             x0, x17
    // 0xd3fc2c: b.ne            #0xd3fc38
    // 0xd3fc30: d0 = 10.000000
    //     0xd3fc30: fmov            d0, #10.00000000
    // 0xd3fc34: b               #0xd3fc3c
    // 0xd3fc38: d0 = 14.000000
    //     0xd3fc38: fmov            d0, #14.00000000
    // 0xd3fc3c: ldur            x3, [fp, #-8]
    // 0xd3fc40: stur            d0, [fp, #-0xe0]
    // 0xd3fc44: LoadField: r1 = r3->field_b
    //     0xd3fc44: ldur            w1, [x3, #0xb]
    // 0xd3fc48: DecompressPointer r1
    //     0xd3fc48: add             x1, x1, HEAP, lsl #32
    // 0xd3fc4c: cmp             w1, NULL
    // 0xd3fc50: b.eq            #0xd40390
    // 0xd3fc54: r17 = 4622
    //     0xd3fc54: mov             x17, #0x120e
    // 0xd3fc58: cmp             x0, x17
    // 0xd3fc5c: b.ne            #0xd3fc68
    // 0xd3fc60: d1 = 8.000000
    //     0xd3fc60: fmov            d1, #8.00000000
    // 0xd3fc64: b               #0xd3fc80
    // 0xd3fc68: r17 = 4623
    //     0xd3fc68: mov             x17, #0x120f
    // 0xd3fc6c: cmp             x0, x17
    // 0xd3fc70: b.ne            #0xd3fc7c
    // 0xd3fc74: d1 = 10.000000
    //     0xd3fc74: fmov            d1, #10.00000000
    // 0xd3fc78: b               #0xd3fc80
    // 0xd3fc7c: d1 = 14.000000
    //     0xd3fc7c: fmov            d1, #14.00000000
    // 0xd3fc80: ldur            x4, [fp, #-0x18]
    // 0xd3fc84: stur            d1, [fp, #-0xd8]
    // 0xd3fc88: LoadField: r5 = r4->field_13
    //     0xd3fc88: ldur            w5, [x4, #0x13]
    // 0xd3fc8c: DecompressPointer r5
    //     0xd3fc8c: add             x5, x5, HEAP, lsl #32
    // 0xd3fc90: LoadField: r6 = r5->field_23
    //     0xd3fc90: ldur            w6, [x5, #0x23]
    // 0xd3fc94: DecompressPointer r6
    //     0xd3fc94: add             x6, x6, HEAP, lsl #32
    // 0xd3fc98: cmp             w6, NULL
    // 0xd3fc9c: b.ne            #0xd3fd00
    // 0xd3fca0: ArrayLoad: r5 = r4[0]  ; List_4
    //     0xd3fca0: ldur            w5, [x4, #0x17]
    // 0xd3fca4: DecompressPointer r5
    //     0xd3fca4: add             x5, x5, HEAP, lsl #32
    // 0xd3fca8: r4 = LoadClassIdInstr(r5)
    //     0xd3fca8: ldur            x4, [x5, #-1]
    //     0xd3fcac: ubfx            x4, x4, #0xc, #0x14
    // 0xd3fcb0: r17 = 5062
    //     0xd3fcb0: mov             x17, #0x13c6
    // 0xd3fcb4: cmp             x4, x17
    // 0xd3fcb8: b.ne            #0xd3fcc8
    // 0xd3fcbc: LoadField: r4 = r5->field_23
    //     0xd3fcbc: ldur            w4, [x5, #0x23]
    // 0xd3fcc0: DecompressPointer r4
    //     0xd3fcc0: add             x4, x4, HEAP, lsl #32
    // 0xd3fcc4: b               #0xd3fd04
    // 0xd3fcc8: r17 = 5063
    //     0xd3fcc8: mov             x17, #0x13c7
    // 0xd3fccc: cmp             x4, x17
    // 0xd3fcd0: b.ne            #0xd3fce0
    // 0xd3fcd4: r4 = 20.000000
    //     0xd3fcd4: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1ae98] 20
    //     0xd3fcd8: ldr             x4, [x4, #0xe98]
    // 0xd3fcdc: b               #0xd3fd04
    // 0xd3fce0: r17 = 5064
    //     0xd3fce0: mov             x17, #0x13c8
    // 0xd3fce4: cmp             x4, x17
    // 0xd3fce8: b.ne            #0xd3fcf8
    // 0xd3fcec: r4 = 20.000000
    //     0xd3fcec: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1ae98] 20
    //     0xd3fcf0: ldr             x4, [x4, #0xe98]
    // 0xd3fcf4: b               #0xd3fd04
    // 0xd3fcf8: r4 = 0.000000
    //     0xd3fcf8: ldr             x4, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd3fcfc: b               #0xd3fd04
    // 0xd3fd00: mov             x4, x6
    // 0xd3fd04: stur            x4, [fp, #-0x68]
    // 0xd3fd08: LoadField: r5 = r1->field_b
    //     0xd3fd08: ldur            w5, [x1, #0xb]
    // 0xd3fd0c: DecompressPointer r5
    //     0xd3fd0c: add             x5, x5, HEAP, lsl #32
    // 0xd3fd10: mov             x1, x3
    // 0xd3fd14: stur            x5, [fp, #-0x18]
    // 0xd3fd18: r0 = onChanged()
    //     0xd3fd18: bl              #0xd42068  ; [package:flutter/src/material/switch.dart] _MaterialSwitchState::onChanged
    // 0xd3fd1c: ldur            x0, [fp, #-8]
    // 0xd3fd20: LoadField: r1 = r0->field_b
    //     0xd3fd20: ldur            w1, [x0, #0xb]
    // 0xd3fd24: DecompressPointer r1
    //     0xd3fd24: add             x1, x1, HEAP, lsl #32
    // 0xd3fd28: cmp             w1, NULL
    // 0xd3fd2c: b.eq            #0xd40394
    // 0xd3fd30: LoadField: r5 = r1->field_6b
    //     0xd3fd30: ldur            w5, [x1, #0x6b]
    // 0xd3fd34: DecompressPointer r5
    //     0xd3fd34: add             x5, x5, HEAP, lsl #32
    // 0xd3fd38: stur            x5, [fp, #-0xd0]
    // 0xd3fd3c: LoadField: r3 = r0->field_4f
    //     0xd3fd3c: ldur            w3, [x0, #0x4f]
    // 0xd3fd40: DecompressPointer r3
    //     0xd3fd40: add             x3, x3, HEAP, lsl #32
    // 0xd3fd44: stur            x3, [fp, #-0xc8]
    // 0xd3fd48: LoadField: r2 = r0->field_1f
    //     0xd3fd48: ldur            w2, [x0, #0x1f]
    // 0xd3fd4c: DecompressPointer r2
    //     0xd3fd4c: add             x2, x2, HEAP, lsl #32
    // 0xd3fd50: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3fd54: cmp             w2, w16
    // 0xd3fd58: b.eq            #0xd40398
    // 0xd3fd5c: mov             x1, x3
    // 0xd3fd60: r0 = position=()
    //     0xd3fd60: bl              #0xd131b8  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::position=
    // 0xd3fd64: ldur            x0, [fp, #-8]
    // 0xd3fd68: LoadField: r2 = r0->field_27
    //     0xd3fd68: ldur            w2, [x0, #0x27]
    // 0xd3fd6c: DecompressPointer r2
    //     0xd3fd6c: add             x2, x2, HEAP, lsl #32
    // 0xd3fd70: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3fd74: cmp             w2, w16
    // 0xd3fd78: b.eq            #0xd403a4
    // 0xd3fd7c: ldur            x1, [fp, #-0xc8]
    // 0xd3fd80: r0 = reaction=()
    //     0xd3fd80: bl              #0xd130e8  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::reaction=
    // 0xd3fd84: ldur            x0, [fp, #-8]
    // 0xd3fd88: LoadField: r2 = r0->field_33
    //     0xd3fd88: ldur            w2, [x0, #0x33]
    // 0xd3fd8c: DecompressPointer r2
    //     0xd3fd8c: add             x2, x2, HEAP, lsl #32
    // 0xd3fd90: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3fd94: cmp             w2, w16
    // 0xd3fd98: b.eq            #0xd403b0
    // 0xd3fd9c: ldur            x1, [fp, #-0xc8]
    // 0xd3fda0: r0 = reactionFocusFade=()
    //     0xd3fda0: bl              #0xd13018  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::reactionFocusFade=
    // 0xd3fda4: ldur            x0, [fp, #-8]
    // 0xd3fda8: LoadField: r2 = r0->field_2b
    //     0xd3fda8: ldur            w2, [x0, #0x2b]
    // 0xd3fdac: DecompressPointer r2
    //     0xd3fdac: add             x2, x2, HEAP, lsl #32
    // 0xd3fdb0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3fdb4: cmp             w2, w16
    // 0xd3fdb8: b.eq            #0xd403bc
    // 0xd3fdbc: ldur            x1, [fp, #-0xc8]
    // 0xd3fdc0: r0 = reactionHoverFade=()
    //     0xd3fdc0: bl              #0xd12f48  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::reactionHoverFade=
    // 0xd3fdc4: ldur            x1, [fp, #-0xc8]
    // 0xd3fdc8: ldur            x2, [fp, #-0x38]
    // 0xd3fdcc: r0 = inactiveReactionColor=()
    //     0xd3fdcc: bl              #0xd12ea4  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::inactiveReactionColor=
    // 0xd3fdd0: ldur            x1, [fp, #-0xc8]
    // 0xd3fdd4: ldur            x2, [fp, #-0x20]
    // 0xd3fdd8: r0 = reactionColor=()
    //     0xd3fdd8: bl              #0xd12e00  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::reactionColor=
    // 0xd3fddc: ldur            x1, [fp, #-0xc8]
    // 0xd3fde0: ldur            x2, [fp, #-0xb0]
    // 0xd3fde4: r0 = hoverColor=()
    //     0xd3fde4: bl              #0xd12d5c  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::hoverColor=
    // 0xd3fde8: ldur            x1, [fp, #-0xc8]
    // 0xd3fdec: ldur            x2, [fp, #-0xa8]
    // 0xd3fdf0: r0 = focusColor=()
    //     0xd3fdf0: bl              #0xd12cb8  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::focusColor=
    // 0xd3fdf4: ldur            x0, [fp, #-0x68]
    // 0xd3fdf8: LoadField: d0 = r0->field_7
    //     0xd3fdf8: ldur            d0, [x0, #7]
    // 0xd3fdfc: ldur            x1, [fp, #-0xc8]
    // 0xd3fe00: r0 = splashRadius=()
    //     0xd3fe00: bl              #0xd12bec  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::splashRadius=
    // 0xd3fe04: ldur            x0, [fp, #-8]
    // 0xd3fe08: LoadField: r2 = r0->field_43
    //     0xd3fe08: ldur            w2, [x0, #0x43]
    // 0xd3fe0c: DecompressPointer r2
    //     0xd3fe0c: add             x2, x2, HEAP, lsl #32
    // 0xd3fe10: ldur            x1, [fp, #-0xc8]
    // 0xd3fe14: r0 = downPosition=()
    //     0xd3fe14: bl              #0xd12b48  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::downPosition=
    // 0xd3fe18: ldur            x1, [fp, #-8]
    // 0xd3fe1c: r0 = states()
    //     0xd3fe1c: bl              #0x129daa0  ; [dart:mixin_deduplication] _MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0xd3fe20: mov             x1, x0
    // 0xd3fe24: r2 = Instance_WidgetState
    //     0xd3fe24: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd3fe28: ldr             x2, [x2, #0xa60]
    // 0xd3fe2c: r0 = contains()
    //     0xd3fe2c: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xd3fe30: mov             x1, x0
    // 0xd3fe34: ldur            x0, [fp, #-0xc8]
    // 0xd3fe38: LoadField: r2 = r0->field_53
    //     0xd3fe38: ldur            w2, [x0, #0x53]
    // 0xd3fe3c: DecompressPointer r2
    //     0xd3fe3c: add             x2, x2, HEAP, lsl #32
    // 0xd3fe40: cmp             w1, w2
    // 0xd3fe44: b.eq            #0xd3fe58
    // 0xd3fe48: StoreField: r0->field_53 = r1
    //     0xd3fe48: stur            w1, [x0, #0x53]
    // 0xd3fe4c: mov             x1, x0
    // 0xd3fe50: r0 = notifyListeners()
    //     0xd3fe50: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd3fe54: ldur            x0, [fp, #-0xc8]
    // 0xd3fe58: ldur            x1, [fp, #-8]
    // 0xd3fe5c: r0 = states()
    //     0xd3fe5c: bl              #0x129daa0  ; [dart:mixin_deduplication] _MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0xd3fe60: mov             x1, x0
    // 0xd3fe64: r2 = Instance_WidgetState
    //     0xd3fe64: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd3fe68: ldr             x2, [x2, #0xa50]
    // 0xd3fe6c: r0 = contains()
    //     0xd3fe6c: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xd3fe70: mov             x1, x0
    // 0xd3fe74: ldur            x0, [fp, #-0xc8]
    // 0xd3fe78: LoadField: r2 = r0->field_57
    //     0xd3fe78: ldur            w2, [x0, #0x57]
    // 0xd3fe7c: DecompressPointer r2
    //     0xd3fe7c: add             x2, x2, HEAP, lsl #32
    // 0xd3fe80: cmp             w1, w2
    // 0xd3fe84: b.eq            #0xd3fe94
    // 0xd3fe88: StoreField: r0->field_57 = r1
    //     0xd3fe88: stur            w1, [x0, #0x57]
    // 0xd3fe8c: mov             x1, x0
    // 0xd3fe90: r0 = notifyListeners()
    //     0xd3fe90: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd3fe94: ldur            x0, [fp, #-8]
    // 0xd3fe98: ldur            x4, [fp, #-0x30]
    // 0xd3fe9c: ldur            x3, [fp, #-0x50]
    // 0xd3fea0: ldur            x1, [fp, #-0xc8]
    // 0xd3fea4: ldur            x2, [fp, #-0x40]
    // 0xd3fea8: r0 = activeColor=()
    //     0xd3fea8: bl              #0xd129fc  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::activeColor=
    // 0xd3feac: ldur            x1, [fp, #-0xc8]
    // 0xd3feb0: ldur            x2, [fp, #-0x60]
    // 0xd3feb4: r0 = inactiveColor=()
    //     0xd3feb4: bl              #0xcf0d78  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::inactiveColor=
    // 0xd3feb8: ldur            x1, [fp, #-0xc8]
    // 0xd3febc: ldur            x2, [fp, #-0xb8]
    // 0xd3fec0: r0 = activePressedColor=()
    //     0xd3fec0: bl              #0xd41fc4  ; [package:flutter/src/material/switch.dart] _SwitchPainter::activePressedColor=
    // 0xd3fec4: ldur            x1, [fp, #-0xc8]
    // 0xd3fec8: ldur            x2, [fp, #-0x58]
    // 0xd3fecc: r0 = inactivePressedColor=()
    //     0xd3fecc: bl              #0xd41f20  ; [package:flutter/src/material/switch.dart] _SwitchPainter::inactivePressedColor=
    // 0xd3fed0: ldur            x0, [fp, #-8]
    // 0xd3fed4: LoadField: r1 = r0->field_b
    //     0xd3fed4: ldur            w1, [x0, #0xb]
    // 0xd3fed8: DecompressPointer r1
    //     0xd3fed8: add             x1, x1, HEAP, lsl #32
    // 0xd3fedc: cmp             w1, NULL
    // 0xd3fee0: b.eq            #0xd403c8
    // 0xd3fee4: ldur            x1, [fp, #-0xc8]
    // 0xd3fee8: r2 = Null
    //     0xd3fee8: mov             x2, NULL
    // 0xd3feec: r0 = Shader._()
    //     0xd3feec: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xd3fef0: ldur            x0, [fp, #-8]
    // 0xd3fef4: LoadField: r1 = r0->field_b
    //     0xd3fef4: ldur            w1, [x0, #0xb]
    // 0xd3fef8: DecompressPointer r1
    //     0xd3fef8: add             x1, x1, HEAP, lsl #32
    // 0xd3fefc: cmp             w1, NULL
    // 0xd3ff00: b.eq            #0xd403cc
    // 0xd3ff04: ldur            x1, [fp, #-0xc8]
    // 0xd3ff08: r2 = Null
    //     0xd3ff08: mov             x2, NULL
    // 0xd3ff0c: r0 = Shader._()
    //     0xd3ff0c: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xd3ff10: ldur            x0, [fp, #-8]
    // 0xd3ff14: LoadField: r1 = r0->field_b
    //     0xd3ff14: ldur            w1, [x0, #0xb]
    // 0xd3ff18: DecompressPointer r1
    //     0xd3ff18: add             x1, x1, HEAP, lsl #32
    // 0xd3ff1c: cmp             w1, NULL
    // 0xd3ff20: b.eq            #0xd403d0
    // 0xd3ff24: ldur            x1, [fp, #-0xc8]
    // 0xd3ff28: r2 = Null
    //     0xd3ff28: mov             x2, NULL
    // 0xd3ff2c: r0 = Shader._()
    //     0xd3ff2c: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xd3ff30: ldur            x0, [fp, #-8]
    // 0xd3ff34: LoadField: r1 = r0->field_b
    //     0xd3ff34: ldur            w1, [x0, #0xb]
    // 0xd3ff38: DecompressPointer r1
    //     0xd3ff38: add             x1, x1, HEAP, lsl #32
    // 0xd3ff3c: cmp             w1, NULL
    // 0xd3ff40: b.eq            #0xd403d4
    // 0xd3ff44: ldur            x1, [fp, #-0xc8]
    // 0xd3ff48: r2 = Null
    //     0xd3ff48: mov             x2, NULL
    // 0xd3ff4c: r0 = Shader._()
    //     0xd3ff4c: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xd3ff50: ldur            x1, [fp, #-0xc8]
    // 0xd3ff54: ldur            x2, [fp, #-0x70]
    // 0xd3ff58: r0 = activeTrackColor=()
    //     0xd3ff58: bl              #0xd41e7c  ; [package:flutter/src/material/switch.dart] _SwitchPainter::activeTrackColor=
    // 0xd3ff5c: ldur            x1, [fp, #-0xc8]
    // 0xd3ff60: ldur            x2, [fp, #-0x78]
    // 0xd3ff64: r0 = activeTrackOutlineColor=()
    //     0xd3ff64: bl              #0xd41dd8  ; [package:flutter/src/material/switch.dart] _SwitchPainter::activeTrackOutlineColor=
    // 0xd3ff68: ldur            x1, [fp, #-0xc8]
    // 0xd3ff6c: ldur            x2, [fp, #-0x80]
    // 0xd3ff70: r0 = activeTrackOutlineWidth=()
    //     0xd3ff70: bl              #0xd41d34  ; [package:flutter/src/material/switch.dart] _SwitchPainter::activeTrackOutlineWidth=
    // 0xd3ff74: ldur            x1, [fp, #-0xc8]
    // 0xd3ff78: ldur            x2, [fp, #-0x88]
    // 0xd3ff7c: r0 = inactiveTrackColor=()
    //     0xd3ff7c: bl              #0xd41c90  ; [package:flutter/src/material/switch.dart] _SwitchPainter::inactiveTrackColor=
    // 0xd3ff80: ldur            x1, [fp, #-0xc8]
    // 0xd3ff84: ldur            x2, [fp, #-0x90]
    // 0xd3ff88: r0 = inactiveTrackOutlineColor=()
    //     0xd3ff88: bl              #0xd41bec  ; [package:flutter/src/material/switch.dart] _SwitchPainter::inactiveTrackOutlineColor=
    // 0xd3ff8c: ldur            x1, [fp, #-0xc8]
    // 0xd3ff90: ldur            x2, [fp, #-0x98]
    // 0xd3ff94: r0 = inactiveTrackOutlineWidth=()
    //     0xd3ff94: bl              #0xd41b48  ; [package:flutter/src/material/switch.dart] _SwitchPainter::inactiveTrackOutlineWidth=
    // 0xd3ff98: ldur            x1, [fp, #-0x10]
    // 0xd3ff9c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd3ff9c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd3ffa0: r0 = createLocalImageConfiguration()
    //     0xd3ffa0: bl              #0xcf9e34  ; [package:flutter/src/widgets/image.dart] ::createLocalImageConfiguration
    // 0xd3ffa4: ldur            x1, [fp, #-0xc8]
    // 0xd3ffa8: mov             x2, x0
    // 0xd3ffac: r0 = configuration=()
    //     0xd3ffac: bl              #0xd41ac0  ; [package:flutter/src/material/switch.dart] _SwitchPainter::configuration=
    // 0xd3ffb0: ldur            x0, [fp, #-8]
    // 0xd3ffb4: LoadField: r1 = r0->field_b
    //     0xd3ffb4: ldur            w1, [x0, #0xb]
    // 0xd3ffb8: DecompressPointer r1
    //     0xd3ffb8: add             x1, x1, HEAP, lsl #32
    // 0xd3ffbc: cmp             w1, NULL
    // 0xd3ffc0: b.eq            #0xd403d8
    // 0xd3ffc4: ldur            x1, [fp, #-0xc8]
    // 0xd3ffc8: r2 = true
    //     0xd3ffc8: add             x2, NULL, #0x20  ; true
    // 0xd3ffcc: r0 = isInteractive=()
    //     0xd3ffcc: bl              #0xd41a64  ; [package:flutter/src/material/switch.dart] _SwitchPainter::isInteractive=
    // 0xd3ffd0: ldur            x1, [fp, #-8]
    // 0xd3ffd4: r0 = _trackInnerLength()
    //     0xd3ffd4: bl              #0xd417a4  ; [package:flutter/src/material/switch.dart] _MaterialSwitchState::_trackInnerLength
    // 0xd3ffd8: ldur            x1, [fp, #-0xc8]
    // 0xd3ffdc: r0 = trackInnerLength=()
    //     0xd3ffdc: bl              #0xd416d8  ; [package:flutter/src/material/switch.dart] _SwitchPainter::trackInnerLength=
    // 0xd3ffe0: ldur            x1, [fp, #-0x10]
    // 0xd3ffe4: r0 = of()
    //     0xd3ffe4: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xd3ffe8: ldur            x1, [fp, #-0xc8]
    // 0xd3ffec: mov             x2, x0
    // 0xd3fff0: r0 = textDirection=()
    //     0xd3fff0: bl              #0xd41668  ; [package:flutter/src/material/switch.dart] _SwitchPainter::textDirection=
    // 0xd3fff4: ldur            x0, [fp, #-0x30]
    // 0xd3fff8: LoadField: r2 = r0->field_7b
    //     0xd3fff8: ldur            w2, [x0, #0x7b]
    // 0xd3fffc: DecompressPointer r2
    //     0xd3fffc: add             x2, x2, HEAP, lsl #32
    // 0xd40000: ldur            x1, [fp, #-0xc8]
    // 0xd40004: r0 = surfaceColor=()
    //     0xd40004: bl              #0xd415c4  ; [package:flutter/src/material/switch.dart] _SwitchPainter::surfaceColor=
    // 0xd40008: ldur            x1, [fp, #-0xc8]
    // 0xd4000c: ldur            d0, [fp, #-0xd8]
    // 0xd40010: r0 = inactiveThumbRadius=()
    //     0xd40010: bl              #0xd414f8  ; [package:flutter/src/material/switch.dart] _SwitchPainter::inactiveThumbRadius=
    // 0xd40014: ldur            x1, [fp, #-0xc8]
    // 0xd40018: ldur            d0, [fp, #-0xe0]
    // 0xd4001c: r0 = activeThumbRadius=()
    //     0xd4001c: bl              #0xd4142c  ; [package:flutter/src/material/switch.dart] _SwitchPainter::activeThumbRadius=
    // 0xd40020: ldur            x0, [fp, #-0x50]
    // 0xd40024: r17 = 4622
    //     0xd40024: mov             x17, #0x120e
    // 0xd40028: cmp             x0, x17
    // 0xd4002c: b.ne            #0xd40038
    // 0xd40030: d0 = 14.000000
    //     0xd40030: fmov            d0, #14.00000000
    // 0xd40034: b               #0xd40050
    // 0xd40038: r17 = 4623
    //     0xd40038: mov             x17, #0x120f
    // 0xd4003c: cmp             x0, x17
    // 0xd40040: b.ne            #0xd4004c
    // 0xd40044: d0 = 10.000000
    //     0xd40044: fmov            d0, #10.00000000
    // 0xd40048: b               #0xd40050
    // 0xd4004c: d0 = 14.000000
    //     0xd4004c: fmov            d0, #14.00000000
    // 0xd40050: ldur            x1, [fp, #-0xc8]
    // 0xd40054: r0 = pressedThumbRadius=()
    //     0xd40054: bl              #0xd41360  ; [package:flutter/src/material/switch.dart] _SwitchPainter::pressedThumbRadius=
    // 0xd40058: ldur            x0, [fp, #-0x50]
    // 0xd4005c: r17 = 4622
    //     0xd4005c: mov             x17, #0x120e
    // 0xd40060: cmp             x0, x17
    // 0xd40064: b.ne            #0xd40070
    // 0xd40068: r2 = Null
    //     0xd40068: mov             x2, NULL
    // 0xd4006c: b               #0xd40088
    // 0xd40070: r17 = 4623
    //     0xd40070: mov             x17, #0x120f
    // 0xd40074: cmp             x0, x17
    // 0xd40078: b.ne            #0xd40084
    // 0xd4007c: r2 = 0.500000
    //     0xd4007c: ldr             x2, [PP, #0x4c70]  ; [pp+0x4c70] 0.5
    // 0xd40080: b               #0xd40088
    // 0xd40084: r2 = Null
    //     0xd40084: mov             x2, NULL
    // 0xd40088: ldur            x1, [fp, #-0xc8]
    // 0xd4008c: r0 = thumbOffset=()
    //     0xd4008c: bl              #0xd412bc  ; [package:flutter/src/material/switch.dart] _SwitchPainter::thumbOffset=
    // 0xd40090: ldur            x0, [fp, #-0x50]
    // 0xd40094: r17 = 4622
    //     0xd40094: mov             x17, #0x120e
    // 0xd40098: cmp             x0, x17
    // 0xd4009c: b.ne            #0xd400ac
    // 0xd400a0: d0 = 32.000000
    //     0xd400a0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a60] IMM: double(32) from 0x4040000000000000
    //     0xd400a4: ldr             d0, [x17, #0xa60]
    // 0xd400a8: b               #0xd400c4
    // 0xd400ac: r17 = 4623
    //     0xd400ac: mov             x17, #0x120f
    // 0xd400b0: cmp             x0, x17
    // 0xd400b4: b.ne            #0xd400c0
    // 0xd400b8: d0 = 14.000000
    //     0xd400b8: fmov            d0, #14.00000000
    // 0xd400bc: b               #0xd400c4
    // 0xd400c0: d0 = 31.000000
    //     0xd400c0: fmov            d0, #31.00000000
    // 0xd400c4: ldur            x1, [fp, #-0xc8]
    // 0xd400c8: r0 = trackHeight=()
    //     0xd400c8: bl              #0xd411f0  ; [package:flutter/src/material/switch.dart] _SwitchPainter::trackHeight=
    // 0xd400cc: ldur            x0, [fp, #-0x50]
    // 0xd400d0: r17 = 4622
    //     0xd400d0: mov             x17, #0x120e
    // 0xd400d4: cmp             x0, x17
    // 0xd400d8: b.ne            #0xd400e8
    // 0xd400dc: d0 = 52.000000
    //     0xd400dc: add             x17, PP, #0x22, lsl #12  ; [pp+0x22108] IMM: double(52) from 0x404a000000000000
    //     0xd400e0: ldr             d0, [x17, #0x108]
    // 0xd400e4: b               #0xd40108
    // 0xd400e8: r17 = 4623
    //     0xd400e8: mov             x17, #0x120f
    // 0xd400ec: cmp             x0, x17
    // 0xd400f0: b.ne            #0xd40100
    // 0xd400f4: d0 = 33.000000
    //     0xd400f4: add             x17, PP, #0xa3, lsl #12  ; [pp+0xa35b0] IMM: double(33) from 0x4040800000000000
    //     0xd400f8: ldr             d0, [x17, #0x5b0]
    // 0xd400fc: b               #0xd40108
    // 0xd40100: d0 = 51.000000
    //     0xd40100: add             x17, PP, #0xa3, lsl #12  ; [pp+0xa35b8] IMM: double(51) from 0x4049800000000000
    //     0xd40104: ldr             d0, [x17, #0x5b8]
    // 0xd40108: ldur            x1, [fp, #-0xc8]
    // 0xd4010c: r0 = trackWidth=()
    //     0xd4010c: bl              #0xd41124  ; [package:flutter/src/material/switch.dart] _SwitchPainter::trackWidth=
    // 0xd40110: ldur            x1, [fp, #-0xc8]
    // 0xd40114: ldur            x2, [fp, #-0xa0]
    // 0xd40118: r0 = activeIconColor=()
    //     0xd40118: bl              #0xd41080  ; [package:flutter/src/material/switch.dart] _SwitchPainter::activeIconColor=
    // 0xd4011c: ldur            x1, [fp, #-0xc8]
    // 0xd40120: ldur            x2, [fp, #-0x28]
    // 0xd40124: r0 = inactiveIconColor=()
    //     0xd40124: bl              #0xd40fdc  ; [package:flutter/src/material/switch.dart] _SwitchPainter::inactiveIconColor=
    // 0xd40128: ldur            x1, [fp, #-0xc8]
    // 0xd4012c: r2 = Null
    //     0xd4012c: mov             x2, NULL
    // 0xd40130: r0 = Shader._()
    //     0xd40130: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xd40134: ldur            x1, [fp, #-0xc8]
    // 0xd40138: r2 = Null
    //     0xd40138: mov             x2, NULL
    // 0xd4013c: r0 = Shader._()
    //     0xd4013c: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xd40140: ldur            x1, [fp, #-0x10]
    // 0xd40144: r0 = of()
    //     0xd40144: bl              #0xd0e004  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::of
    // 0xd40148: ldur            x1, [fp, #-0xc8]
    // 0xd4014c: mov             x2, x0
    // 0xd40150: r0 = iconTheme=()
    //     0xd40150: bl              #0xd40f54  ; [package:flutter/src/material/switch.dart] _SwitchPainter::iconTheme=
    // 0xd40154: ldur            x0, [fp, #-0x50]
    // 0xd40158: r17 = 4622
    //     0xd40158: mov             x17, #0x120e
    // 0xd4015c: cmp             x0, x17
    // 0xd40160: b.ne            #0xd4017c
    // 0xd40164: r1 = _ConstMap len:11
    //     0xd40164: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa35c0] Map<int, List<BoxShadow>>(11)
    //     0xd40168: ldr             x1, [x1, #0x5c0]
    // 0xd4016c: r2 = 0
    //     0xd4016c: mov             x2, #0
    // 0xd40170: r0 = []()
    //     0xd40170: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0xd40174: mov             x2, x0
    // 0xd40178: b               #0xd401a8
    // 0xd4017c: r17 = 4623
    //     0xd4017c: mov             x17, #0x120f
    // 0xd40180: cmp             x0, x17
    // 0xd40184: b.ne            #0xd401a0
    // 0xd40188: r1 = _ConstMap len:11
    //     0xd40188: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa35c0] Map<int, List<BoxShadow>>(11)
    //     0xd4018c: ldr             x1, [x1, #0x5c0]
    // 0xd40190: r2 = 2
    //     0xd40190: mov             x2, #2
    // 0xd40194: r0 = []()
    //     0xd40194: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0xd40198: mov             x2, x0
    // 0xd4019c: b               #0xd401a8
    // 0xd401a0: r2 = const [Instance of 'BoxShadow', Instance of 'BoxShadow']
    //     0xd401a0: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa35c8] List<BoxShadow>(2)
    //     0xd401a4: ldr             x2, [x2, #0x5c8]
    // 0xd401a8: ldur            x0, [fp, #-0x50]
    // 0xd401ac: ldur            x1, [fp, #-0xc8]
    // 0xd401b0: r0 = thumbShadow=()
    //     0xd401b0: bl              #0xd40eb0  ; [package:flutter/src/material/switch.dart] _SwitchPainter::thumbShadow=
    // 0xd401b4: ldur            x0, [fp, #-0x50]
    // 0xd401b8: r17 = 4622
    //     0xd401b8: mov             x17, #0x120e
    // 0xd401bc: cmp             x0, x17
    // 0xd401c0: b.ne            #0xd401d0
    // 0xd401c4: r2 = Instance_Size
    //     0xd401c4: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa35d0] Obj!Size@12a7711
    //     0xd401c8: ldr             x2, [x2, #0x5d0]
    // 0xd401cc: b               #0xd401f0
    // 0xd401d0: r17 = 4623
    //     0xd401d0: mov             x17, #0x120f
    // 0xd401d4: cmp             x0, x17
    // 0xd401d8: b.ne            #0xd401e8
    // 0xd401dc: r2 = Instance_Size
    //     0xd401dc: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa35d8] Obj!Size@12a76f1
    //     0xd401e0: ldr             x2, [x2, #0x5d8]
    // 0xd401e4: b               #0xd401f0
    // 0xd401e8: r2 = Instance_Size
    //     0xd401e8: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa35e0] Obj!Size@12a76d1
    //     0xd401ec: ldr             x2, [x2, #0x5e0]
    // 0xd401f0: ldur            x0, [fp, #-8]
    // 0xd401f4: ldur            x1, [fp, #-0xc8]
    // 0xd401f8: r0 = transitionalThumbSize=()
    //     0xd401f8: bl              #0xd40e20  ; [package:flutter/src/material/switch.dart] _SwitchPainter::transitionalThumbSize=
    // 0xd401fc: ldur            x0, [fp, #-8]
    // 0xd40200: LoadField: r2 = r0->field_1b
    //     0xd40200: ldur            w2, [x0, #0x1b]
    // 0xd40204: DecompressPointer r2
    //     0xd40204: add             x2, x2, HEAP, lsl #32
    // 0xd40208: ldur            x1, [fp, #-0xc8]
    // 0xd4020c: r0 = positionController=()
    //     0xd4020c: bl              #0xd40d14  ; [package:flutter/src/material/switch.dart] _SwitchPainter::positionController=
    // 0xd40210: ldur            x0, [fp, #-8]
    // 0xd40214: LoadField: r2 = r0->field_57
    //     0xd40214: ldur            w2, [x0, #0x57]
    // 0xd40218: DecompressPointer r2
    //     0xd40218: add             x2, x2, HEAP, lsl #32
    // 0xd4021c: ldur            x1, [fp, #-0xc8]
    // 0xd40220: r0 = isCupertino=()
    //     0xd40220: bl              #0xd40cc0  ; [package:flutter/src/material/switch.dart] _SwitchPainter::isCupertino=
    // 0xd40224: ldur            x1, [fp, #-8]
    // 0xd40228: ldur            x2, [fp, #-0xc0]
    // 0xd4022c: ldur            x3, [fp, #-0xc8]
    // 0xd40230: ldur            x5, [fp, #-0xd0]
    // 0xd40234: r0 = buildToggleable()
    //     0xd40234: bl              #0xd403dc  ; [dart:mixin_deduplication] _MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin::buildToggleable
    // 0xd40238: stur            x0, [fp, #-0x10]
    // 0xd4023c: r0 = Opacity()
    //     0xd4023c: bl              #0xd3015c  ; AllocateOpacityStub -> Opacity (size=0x1c)
    // 0xd40240: d0 = 1.000000
    //     0xd40240: fmov            d0, #1.00000000
    // 0xd40244: stur            x0, [fp, #-0x20]
    // 0xd40248: StoreField: r0->field_f = d0
    //     0xd40248: stur            d0, [x0, #0xf]
    // 0xd4024c: r1 = false
    //     0xd4024c: add             x1, NULL, #0x30  ; false
    // 0xd40250: ArrayStore: r0[0] = r1  ; List_4
    //     0xd40250: stur            w1, [x0, #0x17]
    // 0xd40254: ldur            x1, [fp, #-0x10]
    // 0xd40258: StoreField: r0->field_b = r1
    //     0xd40258: stur            w1, [x0, #0xb]
    // 0xd4025c: ldur            x2, [fp, #-8]
    // 0xd40260: r1 = Function '_handleDragStart@127328938':.
    //     0xd40260: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa35e8] AnonymousClosure: (0xd427c4), in [package:flutter/src/material/switch.dart] _MaterialSwitchState::_handleDragStart (0xd42800)
    //     0xd40264: ldr             x1, [x1, #0x5e8]
    // 0xd40268: r0 = AllocateClosure()
    //     0xd40268: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd4026c: ldur            x2, [fp, #-8]
    // 0xd40270: r1 = Function '_handleDragUpdate@127328938':.
    //     0xd40270: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa35f0] AnonymousClosure: (0xd4260c), in [package:flutter/src/material/switch.dart] _MaterialSwitchState::_handleDragUpdate (0xd42648)
    //     0xd40274: ldr             x1, [x1, #0x5f0]
    // 0xd40278: stur            x0, [fp, #-0x10]
    // 0xd4027c: r0 = AllocateClosure()
    //     0xd4027c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd40280: ldur            x2, [fp, #-8]
    // 0xd40284: r1 = Function '_handleDragEnd@127328938':.
    //     0xd40284: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa35f8] AnonymousClosure: (0xd42480), in [package:flutter/src/material/switch.dart] _MaterialSwitchState::_handleDragEnd (0xd424bc)
    //     0xd40288: ldr             x1, [x1, #0x5f8]
    // 0xd4028c: stur            x0, [fp, #-8]
    // 0xd40290: r0 = AllocateClosure()
    //     0xd40290: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd40294: stur            x0, [fp, #-0x28]
    // 0xd40298: r0 = GestureDetector()
    //     0xd40298: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xd4029c: stur            x0, [fp, #-0x30]
    // 0xd402a0: r16 = true
    //     0xd402a0: add             x16, NULL, #0x20  ; true
    // 0xd402a4: ldur            lr, [fp, #-0x10]
    // 0xd402a8: stp             lr, x16, [SP, #0x18]
    // 0xd402ac: ldur            x16, [fp, #-8]
    // 0xd402b0: ldur            lr, [fp, #-0x28]
    // 0xd402b4: stp             lr, x16, [SP, #8]
    // 0xd402b8: ldur            x16, [fp, #-0x20]
    // 0xd402bc: str             x16, [SP]
    // 0xd402c0: mov             x1, x0
    // 0xd402c4: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, excludeFromSemantics, 0x1, onHorizontalDragEnd, 0x4, onHorizontalDragStart, 0x2, onHorizontalDragUpdate, 0x3, null]
    //     0xd402c4: add             x4, PP, #0xa3, lsl #12  ; [pp+0xa3600] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "excludeFromSemantics", 0x1, "onHorizontalDragEnd", 0x4, "onHorizontalDragStart", 0x2, "onHorizontalDragUpdate", 0x3, Null]
    //     0xd402c8: ldr             x4, [x4, #0x600]
    // 0xd402cc: r0 = GestureDetector()
    //     0xd402cc: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xd402d0: r0 = Semantics()
    //     0xd402d0: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xd402d4: stur            x0, [fp, #-8]
    // 0xd402d8: ldur            x16, [fp, #-0x18]
    // 0xd402dc: ldur            lr, [fp, #-0x30]
    // 0xd402e0: stp             lr, x16, [SP]
    // 0xd402e4: mov             x1, x0
    // 0xd402e8: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, toggled, 0x1, null]
    //     0xd402e8: add             x4, PP, #0xa3, lsl #12  ; [pp+0xa3608] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "toggled", 0x1, Null]
    //     0xd402ec: ldr             x4, [x4, #0x608]
    // 0xd402f0: r0 = Semantics()
    //     0xd402f0: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xd402f4: ldur            x0, [fp, #-8]
    // 0xd402f8: LeaveFrame
    //     0xd402f8: mov             SP, fp
    //     0xd402fc: ldp             fp, lr, [SP], #0x10
    // 0xd40300: ret
    //     0xd40300: ret             
    // 0xd40304: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd40304: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd40308: b               #0xd3e19c
    // 0xd4030c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4030c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40310: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40310: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40314: r9 = _reactionController
    //     0xd40314: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3610] Field <_MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin@18353248._reactionController@61045596>: late (offset: 0x24)
    //     0xd40318: ldr             x9, [x9, #0x610]
    // 0xd4031c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd4031c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd40320: r9 = _positionController
    //     0xd40320: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3618] Field <_MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin@18353248._positionController@61045596>: late (offset: 0x1c)
    //     0xd40324: ldr             x9, [x9, #0x618]
    // 0xd40328: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd40328: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd4032c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4032c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40330: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40330: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40334: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40334: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40338: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40338: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4033c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4033c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40340: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40340: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40344: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40344: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40348: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40348: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4034c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4034c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40350: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40350: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40354: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40354: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40358: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40358: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4035c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4035c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40360: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40360: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40364: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40364: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40368: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40368: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4036c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4036c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40370: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40370: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40374: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40374: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40378: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40378: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4037c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4037c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40380: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40380: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40384: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40384: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40388: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40388: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4038c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4038c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40390: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd40390: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd40394: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40394: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40398: r9 = _position
    //     0xd40398: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3620] Field <_MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin@18353248._position@61045596>: late (offset: 0x20)
    //     0xd4039c: ldr             x9, [x9, #0x620]
    // 0xd403a0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd403a0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd403a4: r9 = _reaction
    //     0xd403a4: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3628] Field <_MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin@18353248._reaction@61045596>: late (offset: 0x28)
    //     0xd403a8: ldr             x9, [x9, #0x628]
    // 0xd403ac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd403ac: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd403b0: r9 = _reactionFocusFade
    //     0xd403b0: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3630] Field <_MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin@18353248._reactionFocusFade@61045596>: late (offset: 0x34)
    //     0xd403b4: ldr             x9, [x9, #0x630]
    // 0xd403b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd403b8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd403bc: r9 = _reactionHoverFade
    //     0xd403bc: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3638] Field <_MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin@18353248._reactionHoverFade@61045596>: late (offset: 0x2c)
    //     0xd403c0: ldr             x9, [x9, #0x638]
    // 0xd403c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd403c4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd403c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd403c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd403cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd403cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd403d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd403d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd403d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd403d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd403d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd403d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleChanged(dynamic, bool?) {
    // ** addr: 0xd40a10, size: 0x3c
    // 0xd40a10: EnterFrame
    //     0xd40a10: stp             fp, lr, [SP, #-0x10]!
    //     0xd40a14: mov             fp, SP
    // 0xd40a18: ldr             x0, [fp, #0x18]
    // 0xd40a1c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd40a1c: ldur            w1, [x0, #0x17]
    // 0xd40a20: DecompressPointer r1
    //     0xd40a20: add             x1, x1, HEAP, lsl #32
    // 0xd40a24: CheckStackOverflow
    //     0xd40a24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd40a28: cmp             SP, x16
    //     0xd40a2c: b.ls            #0xd40a44
    // 0xd40a30: ldr             x2, [fp, #0x10]
    // 0xd40a34: r0 = _handleChanged()
    //     0xd40a34: bl              #0xd40a4c  ; [package:flutter/src/material/switch.dart] _MaterialSwitchState::_handleChanged
    // 0xd40a38: LeaveFrame
    //     0xd40a38: mov             SP, fp
    //     0xd40a3c: ldp             fp, lr, [SP], #0x10
    // 0xd40a40: ret
    //     0xd40a40: ret             
    // 0xd40a44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd40a44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd40a48: b               #0xd40a30
  }
  _ _handleChanged(/* No info */) {
    // ** addr: 0xd40a4c, size: 0x78
    // 0xd40a4c: EnterFrame
    //     0xd40a4c: stp             fp, lr, [SP, #-0x10]!
    //     0xd40a50: mov             fp, SP
    // 0xd40a54: AllocStack(0x10)
    //     0xd40a54: sub             SP, SP, #0x10
    // 0xd40a58: CheckStackOverflow
    //     0xd40a58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd40a5c: cmp             SP, x16
    //     0xd40a60: b.ls            #0xd40ab0
    // 0xd40a64: LoadField: r0 = r1->field_b
    //     0xd40a64: ldur            w0, [x1, #0xb]
    // 0xd40a68: DecompressPointer r0
    //     0xd40a68: add             x0, x0, HEAP, lsl #32
    // 0xd40a6c: cmp             w0, NULL
    // 0xd40a70: b.eq            #0xd40ab8
    // 0xd40a74: LoadField: r1 = r0->field_f
    //     0xd40a74: ldur            w1, [x0, #0xf]
    // 0xd40a78: DecompressPointer r1
    //     0xd40a78: add             x1, x1, HEAP, lsl #32
    // 0xd40a7c: cmp             w2, NULL
    // 0xd40a80: b.eq            #0xd40abc
    // 0xd40a84: cmp             w1, NULL
    // 0xd40a88: b.eq            #0xd40ac0
    // 0xd40a8c: stp             x2, x1, [SP]
    // 0xd40a90: mov             x0, x1
    // 0xd40a94: ClosureCall
    //     0xd40a94: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd40a98: ldur            x2, [x0, #0x1f]
    //     0xd40a9c: blr             x2
    // 0xd40aa0: r0 = Null
    //     0xd40aa0: mov             x0, NULL
    // 0xd40aa4: LeaveFrame
    //     0xd40aa4: mov             SP, fp
    //     0xd40aa8: ldp             fp, lr, [SP], #0x10
    // 0xd40aac: ret
    //     0xd40aac: ret             
    // 0xd40ab0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd40ab0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd40ab4: b               #0xd40a64
    // 0xd40ab8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40ab8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40abc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd40abc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd40ac0: r0 = NullErrorSharedWithoutFPURegs()
    //     0xd40ac0: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  get _ _trackInnerLength(/* No info */) {
    // ** addr: 0xd417a4, size: 0x2c0
    // 0xd417a4: EnterFrame
    //     0xd417a4: stp             fp, lr, [SP, #-0x10]!
    //     0xd417a8: mov             fp, SP
    // 0xd417ac: AllocStack(0x10)
    //     0xd417ac: sub             SP, SP, #0x10
    // 0xd417b0: SetupParameters(_MaterialSwitchState this /* r1 => r0, fp-0x8 */)
    //     0xd417b0: mov             x0, x1
    //     0xd417b4: stur            x1, [fp, #-8]
    // 0xd417b8: CheckStackOverflow
    //     0xd417b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd417bc: cmp             SP, x16
    //     0xd417c0: b.ls            #0xd41a40
    // 0xd417c4: LoadField: r1 = r0->field_b
    //     0xd417c4: ldur            w1, [x0, #0xb]
    // 0xd417c8: DecompressPointer r1
    //     0xd417c8: add             x1, x1, HEAP, lsl #32
    // 0xd417cc: cmp             w1, NULL
    // 0xd417d0: b.eq            #0xd41a48
    // 0xd417d4: LoadField: r2 = r1->field_73
    //     0xd417d4: ldur            w2, [x1, #0x73]
    // 0xd417d8: DecompressPointer r2
    //     0xd417d8: add             x2, x2, HEAP, lsl #32
    // 0xd417dc: LoadField: r1 = r2->field_7
    //     0xd417dc: ldur            x1, [x2, #7]
    // 0xd417e0: cmp             x1, #0
    // 0xd417e4: b.gt            #0xd418d4
    // 0xd417e8: LoadField: r1 = r0->field_f
    //     0xd417e8: ldur            w1, [x0, #0xf]
    // 0xd417ec: DecompressPointer r1
    //     0xd417ec: add             x1, x1, HEAP, lsl #32
    // 0xd417f0: cmp             w1, NULL
    // 0xd417f4: b.eq            #0xd41a4c
    // 0xd417f8: r0 = of()
    //     0xd417f8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd417fc: LoadField: r1 = r0->field_2f
    //     0xd417fc: ldur            w1, [x0, #0x2f]
    // 0xd41800: DecompressPointer r1
    //     0xd41800: add             x1, x1, HEAP, lsl #32
    // 0xd41804: tbnz            w1, #4, #0xd41844
    // 0xd41808: ldur            x0, [fp, #-8]
    // 0xd4180c: LoadField: r1 = r0->field_f
    //     0xd4180c: ldur            w1, [x0, #0xf]
    // 0xd41810: DecompressPointer r1
    //     0xd41810: add             x1, x1, HEAP, lsl #32
    // 0xd41814: cmp             w1, NULL
    // 0xd41818: b.eq            #0xd41a50
    // 0xd4181c: r0 = of()
    //     0xd4181c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd41820: LoadField: r1 = r0->field_3f
    //     0xd41820: ldur            w1, [x0, #0x3f]
    // 0xd41824: DecompressPointer r1
    //     0xd41824: add             x1, x1, HEAP, lsl #32
    // 0xd41828: stur            x1, [fp, #-0x10]
    // 0xd4182c: r0 = _SwitchConfigM3()
    //     0xd4182c: bl              #0xd42370  ; Allocate_SwitchConfigM3Stub -> _SwitchConfigM3 (size=0xc)
    // 0xd41830: mov             x1, x0
    // 0xd41834: ldur            x0, [fp, #-0x10]
    // 0xd41838: StoreField: r1->field_7 = r0
    //     0xd41838: stur            w0, [x1, #7]
    // 0xd4183c: mov             x0, x1
    // 0xd41840: b               #0xd41848
    // 0xd41844: r0 = _SwitchConfigM2()
    //     0xd41844: bl              #0xd42364  ; Allocate_SwitchConfigM2Stub -> _SwitchConfigM2 (size=0x8)
    // 0xd41848: r1 = LoadClassIdInstr(r0)
    //     0xd41848: ldur            x1, [x0, #-1]
    //     0xd4184c: ubfx            x1, x1, #0xc, #0x14
    // 0xd41850: r17 = 4622
    //     0xd41850: mov             x17, #0x120e
    // 0xd41854: cmp             x1, x17
    // 0xd41858: b.ne            #0xd41868
    // 0xd4185c: d1 = 32.000000
    //     0xd4185c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a60] IMM: double(32) from 0x4040000000000000
    //     0xd41860: ldr             d1, [x17, #0xa60]
    // 0xd41864: b               #0xd41880
    // 0xd41868: r17 = 4623
    //     0xd41868: mov             x17, #0x120f
    // 0xd4186c: cmp             x1, x17
    // 0xd41870: b.ne            #0xd4187c
    // 0xd41874: d1 = 14.000000
    //     0xd41874: fmov            d1, #14.00000000
    // 0xd41878: b               #0xd41880
    // 0xd4187c: d1 = 31.000000
    //     0xd4187c: fmov            d1, #31.00000000
    // 0xd41880: d0 = 2.000000
    //     0xd41880: fmov            d0, #2.00000000
    // 0xd41884: fdiv            d2, d1, d0
    // 0xd41888: r17 = 4622
    //     0xd41888: mov             x17, #0x120e
    // 0xd4188c: cmp             x1, x17
    // 0xd41890: b.ne            #0xd418a0
    // 0xd41894: d0 = 52.000000
    //     0xd41894: add             x17, PP, #0x22, lsl #12  ; [pp+0x22108] IMM: double(52) from 0x404a000000000000
    //     0xd41898: ldr             d0, [x17, #0x108]
    // 0xd4189c: b               #0xd418c0
    // 0xd418a0: r17 = 4623
    //     0xd418a0: mov             x17, #0x120f
    // 0xd418a4: cmp             x1, x17
    // 0xd418a8: b.ne            #0xd418b8
    // 0xd418ac: d0 = 33.000000
    //     0xd418ac: add             x17, PP, #0xa3, lsl #12  ; [pp+0xa35b0] IMM: double(33) from 0x4040800000000000
    //     0xd418b0: ldr             d0, [x17, #0x5b0]
    // 0xd418b4: b               #0xd418c0
    // 0xd418b8: d0 = 51.000000
    //     0xd418b8: add             x17, PP, #0xa3, lsl #12  ; [pp+0xa35b8] IMM: double(51) from 0x4049800000000000
    //     0xd418bc: ldr             d0, [x17, #0x5b8]
    // 0xd418c0: fsub            d1, d0, d2
    // 0xd418c4: fsub            d0, d1, d2
    // 0xd418c8: LeaveFrame
    //     0xd418c8: mov             SP, fp
    //     0xd418cc: ldp             fp, lr, [SP], #0x10
    // 0xd418d0: ret
    //     0xd418d0: ret             
    // 0xd418d4: d0 = 2.000000
    //     0xd418d4: fmov            d0, #2.00000000
    // 0xd418d8: LoadField: r1 = r0->field_f
    //     0xd418d8: ldur            w1, [x0, #0xf]
    // 0xd418dc: DecompressPointer r1
    //     0xd418dc: add             x1, x1, HEAP, lsl #32
    // 0xd418e0: cmp             w1, NULL
    // 0xd418e4: b.eq            #0xd41a54
    // 0xd418e8: r0 = of()
    //     0xd418e8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd418ec: LoadField: r1 = r0->field_23
    //     0xd418ec: ldur            w1, [x0, #0x23]
    // 0xd418f0: DecompressPointer r1
    //     0xd418f0: add             x1, x1, HEAP, lsl #32
    // 0xd418f4: LoadField: r0 = r1->field_7
    //     0xd418f4: ldur            x0, [x1, #7]
    // 0xd418f8: cmp             x0, #2
    // 0xd418fc: b.gt            #0xd41910
    // 0xd41900: cmp             x0, #1
    // 0xd41904: b.gt            #0xd41928
    // 0xd41908: ldur            x0, [fp, #-8]
    // 0xd4190c: b               #0xd41954
    // 0xd41910: cmp             x0, #4
    // 0xd41914: b.gt            #0xd41950
    // 0xd41918: cmp             x0, #3
    // 0xd4191c: b.gt            #0xd41928
    // 0xd41920: ldur            x0, [fp, #-8]
    // 0xd41924: b               #0xd41954
    // 0xd41928: ldur            x0, [fp, #-8]
    // 0xd4192c: LoadField: r1 = r0->field_f
    //     0xd4192c: ldur            w1, [x0, #0xf]
    // 0xd41930: DecompressPointer r1
    //     0xd41930: add             x1, x1, HEAP, lsl #32
    // 0xd41934: cmp             w1, NULL
    // 0xd41938: b.eq            #0xd41a58
    // 0xd4193c: r0 = of()
    //     0xd4193c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd41940: d0 = 20.000000
    //     0xd41940: fmov            d0, #20.00000000
    // 0xd41944: LeaveFrame
    //     0xd41944: mov             SP, fp
    //     0xd41948: ldp             fp, lr, [SP], #0x10
    // 0xd4194c: ret
    //     0xd4194c: ret             
    // 0xd41950: ldur            x0, [fp, #-8]
    // 0xd41954: LoadField: r1 = r0->field_f
    //     0xd41954: ldur            w1, [x0, #0xf]
    // 0xd41958: DecompressPointer r1
    //     0xd41958: add             x1, x1, HEAP, lsl #32
    // 0xd4195c: cmp             w1, NULL
    // 0xd41960: b.eq            #0xd41a5c
    // 0xd41964: r0 = of()
    //     0xd41964: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd41968: LoadField: r1 = r0->field_2f
    //     0xd41968: ldur            w1, [x0, #0x2f]
    // 0xd4196c: DecompressPointer r1
    //     0xd4196c: add             x1, x1, HEAP, lsl #32
    // 0xd41970: tbnz            w1, #4, #0xd419b0
    // 0xd41974: ldur            x0, [fp, #-8]
    // 0xd41978: LoadField: r1 = r0->field_f
    //     0xd41978: ldur            w1, [x0, #0xf]
    // 0xd4197c: DecompressPointer r1
    //     0xd4197c: add             x1, x1, HEAP, lsl #32
    // 0xd41980: cmp             w1, NULL
    // 0xd41984: b.eq            #0xd41a60
    // 0xd41988: r0 = of()
    //     0xd41988: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd4198c: LoadField: r1 = r0->field_3f
    //     0xd4198c: ldur            w1, [x0, #0x3f]
    // 0xd41990: DecompressPointer r1
    //     0xd41990: add             x1, x1, HEAP, lsl #32
    // 0xd41994: stur            x1, [fp, #-8]
    // 0xd41998: r0 = _SwitchConfigM3()
    //     0xd41998: bl              #0xd42370  ; Allocate_SwitchConfigM3Stub -> _SwitchConfigM3 (size=0xc)
    // 0xd4199c: mov             x1, x0
    // 0xd419a0: ldur            x0, [fp, #-8]
    // 0xd419a4: StoreField: r1->field_7 = r0
    //     0xd419a4: stur            w0, [x1, #7]
    // 0xd419a8: mov             x0, x1
    // 0xd419ac: b               #0xd419b4
    // 0xd419b0: r0 = _SwitchConfigM2()
    //     0xd419b0: bl              #0xd42364  ; Allocate_SwitchConfigM2Stub -> _SwitchConfigM2 (size=0x8)
    // 0xd419b4: r1 = LoadClassIdInstr(r0)
    //     0xd419b4: ldur            x1, [x0, #-1]
    //     0xd419b8: ubfx            x1, x1, #0xc, #0x14
    // 0xd419bc: r17 = 4622
    //     0xd419bc: mov             x17, #0x120e
    // 0xd419c0: cmp             x1, x17
    // 0xd419c4: b.ne            #0xd419d4
    // 0xd419c8: d2 = 32.000000
    //     0xd419c8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a60] IMM: double(32) from 0x4040000000000000
    //     0xd419cc: ldr             d2, [x17, #0xa60]
    // 0xd419d0: b               #0xd419ec
    // 0xd419d4: r17 = 4623
    //     0xd419d4: mov             x17, #0x120f
    // 0xd419d8: cmp             x1, x17
    // 0xd419dc: b.ne            #0xd419e8
    // 0xd419e0: d2 = 14.000000
    //     0xd419e0: fmov            d2, #14.00000000
    // 0xd419e4: b               #0xd419ec
    // 0xd419e8: d2 = 31.000000
    //     0xd419e8: fmov            d2, #31.00000000
    // 0xd419ec: d1 = 2.000000
    //     0xd419ec: fmov            d1, #2.00000000
    // 0xd419f0: fdiv            d3, d2, d1
    // 0xd419f4: r17 = 4622
    //     0xd419f4: mov             x17, #0x120e
    // 0xd419f8: cmp             x1, x17
    // 0xd419fc: b.ne            #0xd41a0c
    // 0xd41a00: d1 = 52.000000
    //     0xd41a00: add             x17, PP, #0x22, lsl #12  ; [pp+0x22108] IMM: double(52) from 0x404a000000000000
    //     0xd41a04: ldr             d1, [x17, #0x108]
    // 0xd41a08: b               #0xd41a2c
    // 0xd41a0c: r17 = 4623
    //     0xd41a0c: mov             x17, #0x120f
    // 0xd41a10: cmp             x1, x17
    // 0xd41a14: b.ne            #0xd41a24
    // 0xd41a18: d1 = 33.000000
    //     0xd41a18: add             x17, PP, #0xa3, lsl #12  ; [pp+0xa35b0] IMM: double(33) from 0x4040800000000000
    //     0xd41a1c: ldr             d1, [x17, #0x5b0]
    // 0xd41a20: b               #0xd41a2c
    // 0xd41a24: d1 = 51.000000
    //     0xd41a24: add             x17, PP, #0xa3, lsl #12  ; [pp+0xa35b8] IMM: double(51) from 0x4049800000000000
    //     0xd41a28: ldr             d1, [x17, #0x5b8]
    // 0xd41a2c: fsub            d2, d1, d3
    // 0xd41a30: fsub            d0, d2, d3
    // 0xd41a34: LeaveFrame
    //     0xd41a34: mov             SP, fp
    //     0xd41a38: ldp             fp, lr, [SP], #0x10
    // 0xd41a3c: ret
    //     0xd41a3c: ret             
    // 0xd41a40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd41a40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd41a44: b               #0xd417c4
    // 0xd41a48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd41a48: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd41a4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd41a4c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd41a50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd41a50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd41a54: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd41a54: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd41a58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd41a58: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd41a5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd41a5c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd41a60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd41a60: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ onChanged(/* No info */) {
    // ** addr: 0xd42068, size: 0x38
    // 0xd42068: EnterFrame
    //     0xd42068: stp             fp, lr, [SP, #-0x10]!
    //     0xd4206c: mov             fp, SP
    // 0xd42070: mov             x2, x1
    // 0xd42074: LoadField: r0 = r2->field_b
    //     0xd42074: ldur            w0, [x2, #0xb]
    // 0xd42078: DecompressPointer r0
    //     0xd42078: add             x0, x0, HEAP, lsl #32
    // 0xd4207c: cmp             w0, NULL
    // 0xd42080: b.eq            #0xd4209c
    // 0xd42084: r1 = Function '_handleChanged@127328938':.
    //     0xd42084: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa36a8] AnonymousClosure: (0xd40a10), in [package:flutter/src/material/switch.dart] _MaterialSwitchState::_handleChanged (0xd40a4c)
    //     0xd42088: ldr             x1, [x1, #0x6a8]
    // 0xd4208c: r0 = AllocateClosure()
    //     0xd4208c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd42090: LeaveFrame
    //     0xd42090: mov             SP, fp
    //     0xd42094: ldp             fp, lr, [SP], #0x10
    // 0xd42098: ret
    //     0xd42098: ret             
    // 0xd4209c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4209c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _widgetThumbColor(/* No info */) {
    // ** addr: 0xd420a0, size: 0x68
    // 0xd420a0: EnterFrame
    //     0xd420a0: stp             fp, lr, [SP, #-0x10]!
    //     0xd420a4: mov             fp, SP
    // 0xd420a8: AllocStack(0x18)
    //     0xd420a8: sub             SP, SP, #0x18
    // 0xd420ac: SetupParameters(_MaterialSwitchState this /* r1 => r1, fp-0x8 */)
    //     0xd420ac: stur            x1, [fp, #-8]
    // 0xd420b0: CheckStackOverflow
    //     0xd420b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd420b4: cmp             SP, x16
    //     0xd420b8: b.ls            #0xd42100
    // 0xd420bc: r1 = 1
    //     0xd420bc: mov             x1, #1
    // 0xd420c0: r0 = AllocateContext()
    //     0xd420c0: bl              #0x13de838  ; AllocateContextStub
    // 0xd420c4: mov             x1, x0
    // 0xd420c8: ldur            x0, [fp, #-8]
    // 0xd420cc: StoreField: r1->field_f = r0
    //     0xd420cc: stur            w0, [x1, #0xf]
    // 0xd420d0: mov             x2, x1
    // 0xd420d4: r1 = Function '<anonymous closure>':.
    //     0xd420d4: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3588] AnonymousClosure: (0xd43078), in [package:flutter/src/material/switch.dart] _MaterialSwitchState::_widgetThumbColor (0xd420a0)
    //     0xd420d8: ldr             x1, [x1, #0x588]
    // 0xd420dc: r0 = AllocateClosure()
    //     0xd420dc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd420e0: r16 = <Color?>
    //     0xd420e0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd420e4: ldr             x16, [x16, #0xa40]
    // 0xd420e8: stp             x0, x16, [SP]
    // 0xd420ec: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd420ec: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd420f0: r0 = resolveWith()
    //     0xd420f0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd420f4: LeaveFrame
    //     0xd420f4: mov             SP, fp
    //     0xd420f8: ldp             fp, lr, [SP], #0x10
    // 0xd420fc: ret
    //     0xd420fc: ret             
    // 0xd42100: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd42100: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd42104: b               #0xd420bc
  }
  get _ _widgetTrackColor(/* No info */) {
    // ** addr: 0xd42108, size: 0x68
    // 0xd42108: EnterFrame
    //     0xd42108: stp             fp, lr, [SP, #-0x10]!
    //     0xd4210c: mov             fp, SP
    // 0xd42110: AllocStack(0x18)
    //     0xd42110: sub             SP, SP, #0x18
    // 0xd42114: SetupParameters(_MaterialSwitchState this /* r1 => r1, fp-0x8 */)
    //     0xd42114: stur            x1, [fp, #-8]
    // 0xd42118: CheckStackOverflow
    //     0xd42118: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4211c: cmp             SP, x16
    //     0xd42120: b.ls            #0xd42168
    // 0xd42124: r1 = 1
    //     0xd42124: mov             x1, #1
    // 0xd42128: r0 = AllocateContext()
    //     0xd42128: bl              #0x13de838  ; AllocateContextStub
    // 0xd4212c: mov             x1, x0
    // 0xd42130: ldur            x0, [fp, #-8]
    // 0xd42134: StoreField: r1->field_f = r0
    //     0xd42134: stur            w0, [x1, #0xf]
    // 0xd42138: mov             x2, x1
    // 0xd4213c: r1 = Function '<anonymous closure>':.
    //     0xd4213c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3590] AnonymousClosure: (0xd42fb4), in [package:flutter/src/material/switch.dart] _MaterialSwitchState::_widgetTrackColor (0xd42108)
    //     0xd42140: ldr             x1, [x1, #0x590]
    // 0xd42144: r0 = AllocateClosure()
    //     0xd42144: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd42148: r16 = <Color?>
    //     0xd42148: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd4214c: ldr             x16, [x16, #0xa40]
    // 0xd42150: stp             x0, x16, [SP]
    // 0xd42154: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd42154: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd42158: r0 = resolveWith()
    //     0xd42158: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd4215c: LeaveFrame
    //     0xd4215c: mov             SP, fp
    //     0xd42160: ldp             fp, lr, [SP], #0x10
    // 0xd42164: ret
    //     0xd42164: ret             
    // 0xd42168: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd42168: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4216c: b               #0xd42124
  }
  [closure] void _handleDragEnd(dynamic, DragEndDetails) {
    // ** addr: 0xd42480, size: 0x3c
    // 0xd42480: EnterFrame
    //     0xd42480: stp             fp, lr, [SP, #-0x10]!
    //     0xd42484: mov             fp, SP
    // 0xd42488: ldr             x0, [fp, #0x18]
    // 0xd4248c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd4248c: ldur            w1, [x0, #0x17]
    // 0xd42490: DecompressPointer r1
    //     0xd42490: add             x1, x1, HEAP, lsl #32
    // 0xd42494: CheckStackOverflow
    //     0xd42494: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd42498: cmp             SP, x16
    //     0xd4249c: b.ls            #0xd424b4
    // 0xd424a0: ldr             x2, [fp, #0x10]
    // 0xd424a4: r0 = _handleDragEnd()
    //     0xd424a4: bl              #0xd424bc  ; [package:flutter/src/material/switch.dart] _MaterialSwitchState::_handleDragEnd
    // 0xd424a8: LeaveFrame
    //     0xd424a8: mov             SP, fp
    //     0xd424ac: ldp             fp, lr, [SP], #0x10
    // 0xd424b0: ret
    //     0xd424b0: ret             
    // 0xd424b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd424b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd424b8: b               #0xd424a0
  }
  _ _handleDragEnd(/* No info */) {
    // ** addr: 0xd424bc, size: 0x12c
    // 0xd424bc: EnterFrame
    //     0xd424bc: stp             fp, lr, [SP, #-0x10]!
    //     0xd424c0: mov             fp, SP
    // 0xd424c4: AllocStack(0x20)
    //     0xd424c4: sub             SP, SP, #0x20
    // 0xd424c8: SetupParameters(_MaterialSwitchState this /* r1 => r1, fp-0x8 */)
    //     0xd424c8: stur            x1, [fp, #-8]
    // 0xd424cc: CheckStackOverflow
    //     0xd424cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd424d0: cmp             SP, x16
    //     0xd424d4: b.ls            #0xd425c0
    // 0xd424d8: r1 = 1
    //     0xd424d8: mov             x1, #1
    // 0xd424dc: r0 = AllocateContext()
    //     0xd424dc: bl              #0x13de838  ; AllocateContextStub
    // 0xd424e0: mov             x2, x0
    // 0xd424e4: ldur            x0, [fp, #-8]
    // 0xd424e8: stur            x2, [fp, #-0x10]
    // 0xd424ec: StoreField: r2->field_f = r0
    //     0xd424ec: stur            w0, [x2, #0xf]
    // 0xd424f0: LoadField: r1 = r0->field_1f
    //     0xd424f0: ldur            w1, [x0, #0x1f]
    // 0xd424f4: DecompressPointer r1
    //     0xd424f4: add             x1, x1, HEAP, lsl #32
    // 0xd424f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd424fc: cmp             w1, w16
    // 0xd42500: b.eq            #0xd425c8
    // 0xd42504: r0 = value()
    //     0xd42504: bl              #0xae5f84  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xd42508: LoadField: d0 = r0->field_7
    //     0xd42508: ldur            d0, [x0, #7]
    // 0xd4250c: d1 = 0.500000
    //     0xd4250c: fmov            d1, #0.50000000
    // 0xd42510: fcmp            d0, d1
    // 0xd42514: r16 = true
    //     0xd42514: add             x16, NULL, #0x20  ; true
    // 0xd42518: r17 = false
    //     0xd42518: add             x17, NULL, #0x30  ; false
    // 0xd4251c: csel            x0, x16, x17, ge
    // 0xd42520: ldur            x1, [fp, #-8]
    // 0xd42524: LoadField: r2 = r1->field_b
    //     0xd42524: ldur            w2, [x1, #0xb]
    // 0xd42528: DecompressPointer r2
    //     0xd42528: add             x2, x2, HEAP, lsl #32
    // 0xd4252c: cmp             w2, NULL
    // 0xd42530: b.eq            #0xd425d4
    // 0xd42534: LoadField: r3 = r2->field_b
    //     0xd42534: ldur            w3, [x2, #0xb]
    // 0xd42538: DecompressPointer r3
    //     0xd42538: add             x3, x3, HEAP, lsl #32
    // 0xd4253c: cmp             w0, w3
    // 0xd42540: b.eq            #0xd42588
    // 0xd42544: LoadField: r0 = r2->field_f
    //     0xd42544: ldur            w0, [x2, #0xf]
    // 0xd42548: DecompressPointer r0
    //     0xd42548: add             x0, x0, HEAP, lsl #32
    // 0xd4254c: eor             x2, x3, #0x10
    // 0xd42550: cmp             w0, NULL
    // 0xd42554: b.eq            #0xd425d8
    // 0xd42558: stp             x2, x0, [SP]
    // 0xd4255c: ClosureCall
    //     0xd4255c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd42560: ldur            x2, [x0, #0x1f]
    //     0xd42564: blr             x2
    // 0xd42568: ldur            x2, [fp, #-0x10]
    // 0xd4256c: r1 = Function '<anonymous closure>':.
    //     0xd4256c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3640] AnonymousClosure: (0xd425e8), in [package:flutter/src/material/switch.dart] _MaterialSwitchState::_handleDragEnd (0xd424bc)
    //     0xd42570: ldr             x1, [x1, #0x640]
    // 0xd42574: r0 = AllocateClosure()
    //     0xd42574: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd42578: ldur            x1, [fp, #-8]
    // 0xd4257c: mov             x2, x0
    // 0xd42580: r0 = setState()
    //     0xd42580: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd42584: b               #0xd42590
    // 0xd42588: ldur            x1, [fp, #-8]
    // 0xd4258c: r0 = animateToValue()
    //     0xd4258c: bl              #0xd423d8  ; [dart:mixin_deduplication] _MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin::animateToValue
    // 0xd42590: ldur            x0, [fp, #-8]
    // 0xd42594: LoadField: r1 = r0->field_23
    //     0xd42594: ldur            w1, [x0, #0x23]
    // 0xd42598: DecompressPointer r1
    //     0xd42598: add             x1, x1, HEAP, lsl #32
    // 0xd4259c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd425a0: cmp             w1, w16
    // 0xd425a4: b.eq            #0xd425dc
    // 0xd425a8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd425a8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd425ac: r0 = reverse()
    //     0xd425ac: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xd425b0: r0 = Null
    //     0xd425b0: mov             x0, NULL
    // 0xd425b4: LeaveFrame
    //     0xd425b4: mov             SP, fp
    //     0xd425b8: ldp             fp, lr, [SP], #0x10
    // 0xd425bc: ret
    //     0xd425bc: ret             
    // 0xd425c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd425c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd425c4: b               #0xd424d8
    // 0xd425c8: r9 = _position
    //     0xd425c8: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3620] Field <_MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin@18353248._position@61045596>: late (offset: 0x20)
    //     0xd425cc: ldr             x9, [x9, #0x620]
    // 0xd425d0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd425d0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd425d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd425d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd425d8: r0 = NullErrorSharedWithoutFPURegs()
    //     0xd425d8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xd425dc: r9 = _reactionController
    //     0xd425dc: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3610] Field <_MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin@18353248._reactionController@61045596>: late (offset: 0x24)
    //     0xd425e0: ldr             x9, [x9, #0x610]
    // 0xd425e4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd425e4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd425e8, size: 0x24
    // 0xd425e8: r1 = true
    //     0xd425e8: add             x1, NULL, #0x20  ; true
    // 0xd425ec: ldr             x2, [SP]
    // 0xd425f0: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xd425f0: ldur            w3, [x2, #0x17]
    // 0xd425f4: DecompressPointer r3
    //     0xd425f4: add             x3, x3, HEAP, lsl #32
    // 0xd425f8: LoadField: r2 = r3->field_f
    //     0xd425f8: ldur            w2, [x3, #0xf]
    // 0xd425fc: DecompressPointer r2
    //     0xd425fc: add             x2, x2, HEAP, lsl #32
    // 0xd42600: StoreField: r2->field_53 = r1
    //     0xd42600: stur            w1, [x2, #0x53]
    // 0xd42604: r0 = Null
    //     0xd42604: mov             x0, NULL
    // 0xd42608: ret
    //     0xd42608: ret             
  }
  [closure] void _handleDragUpdate(dynamic, DragUpdateDetails) {
    // ** addr: 0xd4260c, size: 0x3c
    // 0xd4260c: EnterFrame
    //     0xd4260c: stp             fp, lr, [SP, #-0x10]!
    //     0xd42610: mov             fp, SP
    // 0xd42614: ldr             x0, [fp, #0x18]
    // 0xd42618: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd42618: ldur            w1, [x0, #0x17]
    // 0xd4261c: DecompressPointer r1
    //     0xd4261c: add             x1, x1, HEAP, lsl #32
    // 0xd42620: CheckStackOverflow
    //     0xd42620: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd42624: cmp             SP, x16
    //     0xd42628: b.ls            #0xd42640
    // 0xd4262c: ldr             x2, [fp, #0x10]
    // 0xd42630: r0 = _handleDragUpdate()
    //     0xd42630: bl              #0xd42648  ; [package:flutter/src/material/switch.dart] _MaterialSwitchState::_handleDragUpdate
    // 0xd42634: LeaveFrame
    //     0xd42634: mov             SP, fp
    //     0xd42638: ldp             fp, lr, [SP], #0x10
    // 0xd4263c: ret
    //     0xd4263c: ret             
    // 0xd42640: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd42640: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd42644: b               #0xd4262c
  }
  _ _handleDragUpdate(/* No info */) {
    // ** addr: 0xd42648, size: 0x17c
    // 0xd42648: EnterFrame
    //     0xd42648: stp             fp, lr, [SP, #-0x10]!
    //     0xd4264c: mov             fp, SP
    // 0xd42650: AllocStack(0x20)
    //     0xd42650: sub             SP, SP, #0x20
    // 0xd42654: r0 = Instance__Linear
    //     0xd42654: ldr             x0, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xd42658: mov             x3, x1
    // 0xd4265c: stur            x1, [fp, #-0x10]
    // 0xd42660: CheckStackOverflow
    //     0xd42660: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd42664: cmp             SP, x16
    //     0xd42668: b.ls            #0xd4277c
    // 0xd4266c: LoadField: r1 = r3->field_b
    //     0xd4266c: ldur            w1, [x3, #0xb]
    // 0xd42670: DecompressPointer r1
    //     0xd42670: add             x1, x1, HEAP, lsl #32
    // 0xd42674: cmp             w1, NULL
    // 0xd42678: b.eq            #0xd42784
    // 0xd4267c: LoadField: r1 = r3->field_1f
    //     0xd4267c: ldur            w1, [x3, #0x1f]
    // 0xd42680: DecompressPointer r1
    //     0xd42680: add             x1, x1, HEAP, lsl #32
    // 0xd42684: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd42688: cmp             w1, w16
    // 0xd4268c: b.eq            #0xd42788
    // 0xd42690: StoreField: r1->field_f = r0
    //     0xd42690: stur            w0, [x1, #0xf]
    // 0xd42694: StoreField: r1->field_13 = rNULL
    //     0xd42694: stur            NULL, [x1, #0x13]
    // 0xd42698: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xd42698: ldur            w0, [x2, #0x17]
    // 0xd4269c: DecompressPointer r0
    //     0xd4269c: add             x0, x0, HEAP, lsl #32
    // 0xd426a0: stur            x0, [fp, #-8]
    // 0xd426a4: cmp             w0, NULL
    // 0xd426a8: b.eq            #0xd42794
    // 0xd426ac: mov             x1, x3
    // 0xd426b0: r0 = _trackInnerLength()
    //     0xd426b0: bl              #0xd417a4  ; [package:flutter/src/material/switch.dart] _MaterialSwitchState::_trackInnerLength
    // 0xd426b4: ldur            x0, [fp, #-8]
    // 0xd426b8: LoadField: d1 = r0->field_7
    //     0xd426b8: ldur            d1, [x0, #7]
    // 0xd426bc: fdiv            d2, d1, d0
    // 0xd426c0: ldur            x0, [fp, #-0x10]
    // 0xd426c4: stur            d2, [fp, #-0x20]
    // 0xd426c8: LoadField: r2 = r0->field_1b
    //     0xd426c8: ldur            w2, [x0, #0x1b]
    // 0xd426cc: DecompressPointer r2
    //     0xd426cc: add             x2, x2, HEAP, lsl #32
    // 0xd426d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd426d4: cmp             w2, w16
    // 0xd426d8: b.eq            #0xd42798
    // 0xd426dc: stur            x2, [fp, #-0x18]
    // 0xd426e0: LoadField: r3 = r2->field_37
    //     0xd426e0: ldur            w3, [x2, #0x37]
    // 0xd426e4: DecompressPointer r3
    //     0xd426e4: add             x3, x3, HEAP, lsl #32
    // 0xd426e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd426ec: cmp             w3, w16
    // 0xd426f0: b.eq            #0xd427a4
    // 0xd426f4: stur            x3, [fp, #-8]
    // 0xd426f8: LoadField: r1 = r0->field_f
    //     0xd426f8: ldur            w1, [x0, #0xf]
    // 0xd426fc: DecompressPointer r1
    //     0xd426fc: add             x1, x1, HEAP, lsl #32
    // 0xd42700: cmp             w1, NULL
    // 0xd42704: b.eq            #0xd427ac
    // 0xd42708: r0 = of()
    //     0xd42708: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xd4270c: LoadField: r1 = r0->field_7
    //     0xd4270c: ldur            x1, [x0, #7]
    // 0xd42710: cmp             x1, #0
    // 0xd42714: b.gt            #0xd42728
    // 0xd42718: ldur            d0, [fp, #-0x20]
    // 0xd4271c: fneg            d1, d0
    // 0xd42720: mov             v0.16b, v1.16b
    // 0xd42724: b               #0xd4272c
    // 0xd42728: ldur            d0, [fp, #-0x20]
    // 0xd4272c: ldur            x0, [fp, #-8]
    // 0xd42730: LoadField: d1 = r0->field_7
    //     0xd42730: ldur            d1, [x0, #7]
    // 0xd42734: fadd            d2, d1, d0
    // 0xd42738: r2 = inline_Allocate_Double()
    //     0xd42738: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xd4273c: add             x2, x2, #0x10
    //     0xd42740: cmp             x0, x2
    //     0xd42744: b.ls            #0xd427b0
    //     0xd42748: str             x2, [THR, #0x60]  ; THR::top
    //     0xd4274c: sub             x2, x2, #0xf
    //     0xd42750: mov             x0, #0xe19c
    //     0xd42754: movk            x0, #3, lsl #16
    //     0xd42758: stur            x0, [x2, #-1]
    // 0xd4275c: dmb             ishst
    // 0xd42760: StoreField: r2->field_7 = d2
    //     0xd42760: stur            d2, [x2, #7]
    // 0xd42764: ldur            x1, [fp, #-0x18]
    // 0xd42768: r0 = value=()
    //     0xd42768: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xd4276c: r0 = Null
    //     0xd4276c: mov             x0, NULL
    // 0xd42770: LeaveFrame
    //     0xd42770: mov             SP, fp
    //     0xd42774: ldp             fp, lr, [SP], #0x10
    // 0xd42778: ret
    //     0xd42778: ret             
    // 0xd4277c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4277c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd42780: b               #0xd4266c
    // 0xd42784: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd42784: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd42788: r9 = _position
    //     0xd42788: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3620] Field <_MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin@18353248._position@61045596>: late (offset: 0x20)
    //     0xd4278c: ldr             x9, [x9, #0x620]
    // 0xd42790: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd42790: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd42794: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd42794: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd42798: r9 = _positionController
    //     0xd42798: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3618] Field <_MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin@18353248._positionController@61045596>: late (offset: 0x1c)
    //     0xd4279c: ldr             x9, [x9, #0x618]
    // 0xd427a0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xd427a0: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xd427a4: r9 = _value
    //     0xd427a4: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xd427a8: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xd427a8: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xd427ac: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd427ac: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd427b0: SaveReg d2
    //     0xd427b0: str             q2, [SP, #-0x10]!
    // 0xd427b4: r0 = AllocateDouble()
    //     0xd427b4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd427b8: mov             x2, x0
    // 0xd427bc: RestoreReg d2
    //     0xd427bc: ldr             q2, [SP], #0x10
    // 0xd427c0: b               #0xd42760
  }
  [closure] void _handleDragStart(dynamic, DragStartDetails) {
    // ** addr: 0xd427c4, size: 0x3c
    // 0xd427c4: EnterFrame
    //     0xd427c4: stp             fp, lr, [SP, #-0x10]!
    //     0xd427c8: mov             fp, SP
    // 0xd427cc: ldr             x0, [fp, #0x18]
    // 0xd427d0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd427d0: ldur            w1, [x0, #0x17]
    // 0xd427d4: DecompressPointer r1
    //     0xd427d4: add             x1, x1, HEAP, lsl #32
    // 0xd427d8: CheckStackOverflow
    //     0xd427d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd427dc: cmp             SP, x16
    //     0xd427e0: b.ls            #0xd427f8
    // 0xd427e4: ldr             x2, [fp, #0x10]
    // 0xd427e8: r0 = _handleDragStart()
    //     0xd427e8: bl              #0xd42800  ; [package:flutter/src/material/switch.dart] _MaterialSwitchState::_handleDragStart
    // 0xd427ec: LeaveFrame
    //     0xd427ec: mov             SP, fp
    //     0xd427f0: ldp             fp, lr, [SP], #0x10
    // 0xd427f4: ret
    //     0xd427f4: ret             
    // 0xd427f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd427f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd427fc: b               #0xd427e4
  }
  _ _handleDragStart(/* No info */) {
    // ** addr: 0xd42800, size: 0x6c
    // 0xd42800: EnterFrame
    //     0xd42800: stp             fp, lr, [SP, #-0x10]!
    //     0xd42804: mov             fp, SP
    // 0xd42808: CheckStackOverflow
    //     0xd42808: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4280c: cmp             SP, x16
    //     0xd42810: b.ls            #0xd42854
    // 0xd42814: LoadField: r0 = r1->field_b
    //     0xd42814: ldur            w0, [x1, #0xb]
    // 0xd42818: DecompressPointer r0
    //     0xd42818: add             x0, x0, HEAP, lsl #32
    // 0xd4281c: cmp             w0, NULL
    // 0xd42820: b.eq            #0xd4285c
    // 0xd42824: LoadField: r0 = r1->field_23
    //     0xd42824: ldur            w0, [x1, #0x23]
    // 0xd42828: DecompressPointer r0
    //     0xd42828: add             x0, x0, HEAP, lsl #32
    // 0xd4282c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd42830: cmp             w0, w16
    // 0xd42834: b.eq            #0xd42860
    // 0xd42838: mov             x1, x0
    // 0xd4283c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd4283c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd42840: r0 = forward()
    //     0xd42840: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xd42844: r0 = Null
    //     0xd42844: mov             x0, NULL
    // 0xd42848: LeaveFrame
    //     0xd42848: mov             SP, fp
    //     0xd4284c: ldp             fp, lr, [SP], #0x10
    // 0xd42850: ret
    //     0xd42850: ret             
    // 0xd42854: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd42854: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd42858: b               #0xd42814
    // 0xd4285c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4285c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd42860: r9 = _reactionController
    //     0xd42860: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3610] Field <_MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin@18353248._reactionController@61045596>: late (offset: 0x24)
    //     0xd42864: ldr             x9, [x9, #0x610]
    // 0xd42868: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd42868: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] MouseCursor <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd4286c, size: 0x148
    // 0xd4286c: EnterFrame
    //     0xd4286c: stp             fp, lr, [SP, #-0x10]!
    //     0xd42870: mov             fp, SP
    // 0xd42874: AllocStack(0x20)
    //     0xd42874: sub             SP, SP, #0x20
    // 0xd42878: SetupParameters([dynamic _ /* r0 */])
    //     0xd42878: ldr             x0, [fp, #0x18]
    //     0xd4287c: ldur            w1, [x0, #0x17]
    //     0xd42880: add             x1, x1, HEAP, lsl #32
    //     0xd42884: stur            x1, [fp, #-8]
    // 0xd42888: CheckStackOverflow
    //     0xd42888: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4288c: cmp             SP, x16
    //     0xd42890: b.ls            #0xd429a4
    // 0xd42894: LoadField: r0 = r1->field_f
    //     0xd42894: ldur            w0, [x1, #0xf]
    // 0xd42898: DecompressPointer r0
    //     0xd42898: add             x0, x0, HEAP, lsl #32
    // 0xd4289c: LoadField: r2 = r0->field_b
    //     0xd4289c: ldur            w2, [x0, #0xb]
    // 0xd428a0: DecompressPointer r2
    //     0xd428a0: add             x2, x2, HEAP, lsl #32
    // 0xd428a4: cmp             w2, NULL
    // 0xd428a8: b.eq            #0xd429ac
    // 0xd428ac: r16 = <MouseCursor?>
    //     0xd428ac: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ab8] TypeArguments: <MouseCursor?>
    //     0xd428b0: ldr             x16, [x16, #0xab8]
    // 0xd428b4: stp             NULL, x16, [SP, #8]
    // 0xd428b8: ldr             x16, [fp, #0x10]
    // 0xd428bc: str             x16, [SP]
    // 0xd428c0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd428c0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd428c4: r0 = resolveAs()
    //     0xd428c4: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xd428c8: ldur            x0, [fp, #-8]
    // 0xd428cc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd428cc: ldur            w1, [x0, #0x17]
    // 0xd428d0: DecompressPointer r1
    //     0xd428d0: add             x1, x1, HEAP, lsl #32
    // 0xd428d4: r0 = LoadClassIdInstr(r1)
    //     0xd428d4: ldur            x0, [x1, #-1]
    //     0xd428d8: ubfx            x0, x0, #0xc, #0x14
    // 0xd428dc: r17 = 5062
    //     0xd428dc: mov             x17, #0x13c6
    // 0xd428e0: cmp             x0, x17
    // 0xd428e4: b.ne            #0xd428f8
    // 0xd428e8: LoadField: r0 = r1->field_1b
    //     0xd428e8: ldur            w0, [x1, #0x1b]
    // 0xd428ec: DecompressPointer r0
    //     0xd428ec: add             x0, x0, HEAP, lsl #32
    // 0xd428f0: mov             x1, x0
    // 0xd428f4: b               #0xd42988
    // 0xd428f8: r17 = 5063
    //     0xd428f8: mov             x17, #0x13c7
    // 0xd428fc: cmp             x0, x17
    // 0xd42900: b.ne            #0xd4292c
    // 0xd42904: r1 = Function '<anonymous closure>':.
    //     0xd42904: add             x1, PP, #0x26, lsl #12  ; [pp+0x26158] AnonymousClosure: (0xd42a1c), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0xd42908: ldr             x1, [x1, #0x158]
    // 0xd4290c: r2 = Null
    //     0xd4290c: mov             x2, NULL
    // 0xd42910: r0 = AllocateClosure()
    //     0xd42910: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd42914: r16 = <MouseCursor>
    //     0xd42914: ldr             x16, [PP, #0x21a8]  ; [pp+0x21a8] TypeArguments: <MouseCursor>
    // 0xd42918: stp             x0, x16, [SP]
    // 0xd4291c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd4291c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd42920: r0 = resolveWith()
    //     0xd42920: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd42924: mov             x1, x0
    // 0xd42928: b               #0xd42988
    // 0xd4292c: r17 = 5064
    //     0xd4292c: mov             x17, #0x13c8
    // 0xd42930: cmp             x0, x17
    // 0xd42934: b.ne            #0xd42960
    // 0xd42938: r1 = Function '<anonymous closure>':.
    //     0xd42938: add             x1, PP, #0x26, lsl #12  ; [pp+0x26160] AnonymousClosure: (0xd42a1c), of [package:flutter/src/material/switch.dart] _SwitchDefaultsM3
    //     0xd4293c: ldr             x1, [x1, #0x160]
    // 0xd42940: r2 = Null
    //     0xd42940: mov             x2, NULL
    // 0xd42944: r0 = AllocateClosure()
    //     0xd42944: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd42948: r16 = <MouseCursor>
    //     0xd42948: ldr             x16, [PP, #0x21a8]  ; [pp+0x21a8] TypeArguments: <MouseCursor>
    // 0xd4294c: stp             x0, x16, [SP]
    // 0xd42950: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd42950: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd42954: r0 = resolveWith()
    //     0xd42954: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd42958: mov             x1, x0
    // 0xd4295c: b               #0xd42988
    // 0xd42960: r1 = Function '<anonymous closure>':.
    //     0xd42960: add             x1, PP, #0x26, lsl #12  ; [pp+0x26168] AnonymousClosure: (0xd429b4), of [package:flutter/src/material/switch.dart] _SwitchDefaultsCupertino
    //     0xd42964: ldr             x1, [x1, #0x168]
    // 0xd42968: r2 = Null
    //     0xd42968: mov             x2, NULL
    // 0xd4296c: r0 = AllocateClosure()
    //     0xd4296c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd42970: r16 = <MouseCursor?>
    //     0xd42970: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ab8] TypeArguments: <MouseCursor?>
    //     0xd42974: ldr             x16, [x16, #0xab8]
    // 0xd42978: stp             x0, x16, [SP]
    // 0xd4297c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd4297c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd42980: r0 = resolveWith()
    //     0xd42980: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd42984: mov             x1, x0
    // 0xd42988: ldr             x2, [fp, #0x10]
    // 0xd4298c: r0 = build()
    //     0xd4298c: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd42990: cmp             w0, NULL
    // 0xd42994: b.eq            #0xd429b0
    // 0xd42998: LeaveFrame
    //     0xd42998: mov             SP, fp
    //     0xd4299c: ldp             fp, lr, [SP], #0x10
    // 0xd429a0: ret
    //     0xd429a0: ret             
    // 0xd429a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd429a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd429a8: b               #0xd42894
    // 0xd429ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd429ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd429b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd429b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Color? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd42fb4, size: 0xc4
    // 0xd42fb4: EnterFrame
    //     0xd42fb4: stp             fp, lr, [SP, #-0x10]!
    //     0xd42fb8: mov             fp, SP
    // 0xd42fbc: AllocStack(0x8)
    //     0xd42fbc: sub             SP, SP, #8
    // 0xd42fc0: SetupParameters([dynamic _ /* r0 */])
    //     0xd42fc0: ldr             x0, [fp, #0x18]
    //     0xd42fc4: ldur            w3, [x0, #0x17]
    //     0xd42fc8: add             x3, x3, HEAP, lsl #32
    //     0xd42fcc: stur            x3, [fp, #-8]
    // 0xd42fd0: CheckStackOverflow
    //     0xd42fd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd42fd4: cmp             SP, x16
    //     0xd42fd8: b.ls            #0xd43068
    // 0xd42fdc: ldr             x1, [fp, #0x10]
    // 0xd42fe0: r0 = LoadClassIdInstr(r1)
    //     0xd42fe0: ldur            x0, [x1, #-1]
    //     0xd42fe4: ubfx            x0, x0, #0xc, #0x14
    // 0xd42fe8: r2 = Instance_WidgetState
    //     0xd42fe8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd42fec: ldr             x2, [x2, #0x100]
    // 0xd42ff0: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd42ff0: mov             x17, #0x2929
    //     0xd42ff4: movk            x17, #1, lsl #16
    //     0xd42ff8: add             lr, x0, x17
    //     0xd42ffc: ldr             lr, [x21, lr, lsl #3]
    //     0xd43000: blr             lr
    // 0xd43004: tbnz            w0, #4, #0xd43038
    // 0xd43008: ldur            x1, [fp, #-8]
    // 0xd4300c: LoadField: r2 = r1->field_f
    //     0xd4300c: ldur            w2, [x1, #0xf]
    // 0xd43010: DecompressPointer r2
    //     0xd43010: add             x2, x2, HEAP, lsl #32
    // 0xd43014: LoadField: r3 = r2->field_b
    //     0xd43014: ldur            w3, [x2, #0xb]
    // 0xd43018: DecompressPointer r3
    //     0xd43018: add             x3, x3, HEAP, lsl #32
    // 0xd4301c: cmp             w3, NULL
    // 0xd43020: b.eq            #0xd43070
    // 0xd43024: ArrayLoad: r0 = r3[0]  ; List_4
    //     0xd43024: ldur            w0, [x3, #0x17]
    // 0xd43028: DecompressPointer r0
    //     0xd43028: add             x0, x0, HEAP, lsl #32
    // 0xd4302c: LeaveFrame
    //     0xd4302c: mov             SP, fp
    //     0xd43030: ldp             fp, lr, [SP], #0x10
    // 0xd43034: ret
    //     0xd43034: ret             
    // 0xd43038: ldur            x1, [fp, #-8]
    // 0xd4303c: LoadField: r2 = r1->field_f
    //     0xd4303c: ldur            w2, [x1, #0xf]
    // 0xd43040: DecompressPointer r2
    //     0xd43040: add             x2, x2, HEAP, lsl #32
    // 0xd43044: LoadField: r1 = r2->field_b
    //     0xd43044: ldur            w1, [x2, #0xb]
    // 0xd43048: DecompressPointer r1
    //     0xd43048: add             x1, x1, HEAP, lsl #32
    // 0xd4304c: cmp             w1, NULL
    // 0xd43050: b.eq            #0xd43074
    // 0xd43054: LoadField: r0 = r1->field_1f
    //     0xd43054: ldur            w0, [x1, #0x1f]
    // 0xd43058: DecompressPointer r0
    //     0xd43058: add             x0, x0, HEAP, lsl #32
    // 0xd4305c: LeaveFrame
    //     0xd4305c: mov             SP, fp
    //     0xd43060: ldp             fp, lr, [SP], #0x10
    // 0xd43064: ret
    //     0xd43064: ret             
    // 0xd43068: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd43068: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4306c: b               #0xd42fdc
    // 0xd43070: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd43070: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd43074: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd43074: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Color? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd43078, size: 0x128
    // 0xd43078: EnterFrame
    //     0xd43078: stp             fp, lr, [SP, #-0x10]!
    //     0xd4307c: mov             fp, SP
    // 0xd43080: AllocStack(0x8)
    //     0xd43080: sub             SP, SP, #8
    // 0xd43084: SetupParameters([dynamic _ /* r0 */])
    //     0xd43084: ldr             x0, [fp, #0x18]
    //     0xd43088: ldur            w3, [x0, #0x17]
    //     0xd4308c: add             x3, x3, HEAP, lsl #32
    //     0xd43090: stur            x3, [fp, #-8]
    // 0xd43094: CheckStackOverflow
    //     0xd43094: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd43098: cmp             SP, x16
    //     0xd4309c: b.ls            #0xd4318c
    // 0xd430a0: ldr             x4, [fp, #0x10]
    // 0xd430a4: r0 = LoadClassIdInstr(r4)
    //     0xd430a4: ldur            x0, [x4, #-1]
    //     0xd430a8: ubfx            x0, x0, #0xc, #0x14
    // 0xd430ac: mov             x1, x4
    // 0xd430b0: r2 = Instance_WidgetState
    //     0xd430b0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd430b4: ldr             x2, [x2, #0xa70]
    // 0xd430b8: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd430b8: mov             x17, #0x2929
    //     0xd430bc: movk            x17, #1, lsl #16
    //     0xd430c0: add             lr, x0, x17
    //     0xd430c4: ldr             lr, [x21, lr, lsl #3]
    //     0xd430c8: blr             lr
    // 0xd430cc: tbnz            w0, #4, #0xd43100
    // 0xd430d0: ldur            x3, [fp, #-8]
    // 0xd430d4: LoadField: r0 = r3->field_f
    //     0xd430d4: ldur            w0, [x3, #0xf]
    // 0xd430d8: DecompressPointer r0
    //     0xd430d8: add             x0, x0, HEAP, lsl #32
    // 0xd430dc: LoadField: r1 = r0->field_b
    //     0xd430dc: ldur            w1, [x0, #0xb]
    // 0xd430e0: DecompressPointer r1
    //     0xd430e0: add             x1, x1, HEAP, lsl #32
    // 0xd430e4: cmp             w1, NULL
    // 0xd430e8: b.eq            #0xd43194
    // 0xd430ec: LoadField: r0 = r1->field_1b
    //     0xd430ec: ldur            w0, [x1, #0x1b]
    // 0xd430f0: DecompressPointer r0
    //     0xd430f0: add             x0, x0, HEAP, lsl #32
    // 0xd430f4: LeaveFrame
    //     0xd430f4: mov             SP, fp
    //     0xd430f8: ldp             fp, lr, [SP], #0x10
    // 0xd430fc: ret
    //     0xd430fc: ret             
    // 0xd43100: ldr             x1, [fp, #0x10]
    // 0xd43104: ldur            x3, [fp, #-8]
    // 0xd43108: r0 = LoadClassIdInstr(r1)
    //     0xd43108: ldur            x0, [x1, #-1]
    //     0xd4310c: ubfx            x0, x0, #0xc, #0x14
    // 0xd43110: r2 = Instance_WidgetState
    //     0xd43110: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd43114: ldr             x2, [x2, #0x100]
    // 0xd43118: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd43118: mov             x17, #0x2929
    //     0xd4311c: movk            x17, #1, lsl #16
    //     0xd43120: add             lr, x0, x17
    //     0xd43124: ldr             lr, [x21, lr, lsl #3]
    //     0xd43128: blr             lr
    // 0xd4312c: tbnz            w0, #4, #0xd4315c
    // 0xd43130: ldur            x1, [fp, #-8]
    // 0xd43134: LoadField: r2 = r1->field_f
    //     0xd43134: ldur            w2, [x1, #0xf]
    // 0xd43138: DecompressPointer r2
    //     0xd43138: add             x2, x2, HEAP, lsl #32
    // 0xd4313c: LoadField: r3 = r2->field_b
    //     0xd4313c: ldur            w3, [x2, #0xb]
    // 0xd43140: DecompressPointer r3
    //     0xd43140: add             x3, x3, HEAP, lsl #32
    // 0xd43144: cmp             w3, NULL
    // 0xd43148: b.eq            #0xd43198
    // 0xd4314c: r0 = Null
    //     0xd4314c: mov             x0, NULL
    // 0xd43150: LeaveFrame
    //     0xd43150: mov             SP, fp
    //     0xd43154: ldp             fp, lr, [SP], #0x10
    // 0xd43158: ret
    //     0xd43158: ret             
    // 0xd4315c: ldur            x1, [fp, #-8]
    // 0xd43160: LoadField: r2 = r1->field_f
    //     0xd43160: ldur            w2, [x1, #0xf]
    // 0xd43164: DecompressPointer r2
    //     0xd43164: add             x2, x2, HEAP, lsl #32
    // 0xd43168: LoadField: r1 = r2->field_b
    //     0xd43168: ldur            w1, [x2, #0xb]
    // 0xd4316c: DecompressPointer r1
    //     0xd4316c: add             x1, x1, HEAP, lsl #32
    // 0xd43170: cmp             w1, NULL
    // 0xd43174: b.eq            #0xd4319c
    // 0xd43178: LoadField: r0 = r1->field_1b
    //     0xd43178: ldur            w0, [x1, #0x1b]
    // 0xd4317c: DecompressPointer r0
    //     0xd4317c: add             x0, x0, HEAP, lsl #32
    // 0xd43180: LeaveFrame
    //     0xd43180: mov             SP, fp
    //     0xd43184: ldp             fp, lr, [SP], #0x10
    // 0xd43188: ret
    //     0xd43188: ret             
    // 0xd4318c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4318c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd43190: b               #0xd430a0
    // 0xd43194: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd43194: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd43198: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd43198: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4319c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4319c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf3d988, size: 0x1fc
    // 0xf3d988: EnterFrame
    //     0xf3d988: stp             fp, lr, [SP, #-0x10]!
    //     0xf3d98c: mov             fp, SP
    // 0xf3d990: AllocStack(0x10)
    //     0xf3d990: sub             SP, SP, #0x10
    // 0xf3d994: SetupParameters(_MaterialSwitchState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf3d994: mov             x4, x1
    //     0xf3d998: mov             x3, x2
    //     0xf3d99c: stur            x1, [fp, #-8]
    //     0xf3d9a0: stur            x2, [fp, #-0x10]
    // 0xf3d9a4: CheckStackOverflow
    //     0xf3d9a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3d9a8: cmp             SP, x16
    //     0xf3d9ac: b.ls            #0xf3db64
    // 0xf3d9b0: mov             x0, x3
    // 0xf3d9b4: r2 = Null
    //     0xf3d9b4: mov             x2, NULL
    // 0xf3d9b8: r1 = Null
    //     0xf3d9b8: mov             x1, NULL
    // 0xf3d9bc: r4 = 60
    //     0xf3d9bc: mov             x4, #0x3c
    // 0xf3d9c0: branchIfSmi(r0, 0xf3d9cc)
    //     0xf3d9c0: tbz             w0, #0, #0xf3d9cc
    // 0xf3d9c4: r4 = LoadClassIdInstr(r0)
    //     0xf3d9c4: ldur            x4, [x0, #-1]
    //     0xf3d9c8: ubfx            x4, x4, #0xc, #0x14
    // 0xf3d9cc: r17 = 6431
    //     0xf3d9cc: mov             x17, #0x191f
    // 0xf3d9d0: cmp             x4, x17
    // 0xf3d9d4: b.eq            #0xf3d9ec
    // 0xf3d9d8: r8 = _MaterialSwitch
    //     0xf3d9d8: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa36d0] Type: _MaterialSwitch
    //     0xf3d9dc: ldr             x8, [x8, #0x6d0]
    // 0xf3d9e0: r3 = Null
    //     0xf3d9e0: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa36d8] Null
    //     0xf3d9e4: ldr             x3, [x3, #0x6d8]
    // 0xf3d9e8: r0 = _MaterialSwitch()
    //     0xf3d9e8: bl              #0xad1748  ; IsType__MaterialSwitch_Stub
    // 0xf3d9ec: ldur            x3, [fp, #-8]
    // 0xf3d9f0: LoadField: r2 = r3->field_7
    //     0xf3d9f0: ldur            w2, [x3, #7]
    // 0xf3d9f4: DecompressPointer r2
    //     0xf3d9f4: add             x2, x2, HEAP, lsl #32
    // 0xf3d9f8: ldur            x0, [fp, #-0x10]
    // 0xf3d9fc: r1 = Null
    //     0xf3d9fc: mov             x1, NULL
    // 0xf3da00: cmp             w2, NULL
    // 0xf3da04: b.eq            #0xf3da28
    // 0xf3da08: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf3da08: ldur            w4, [x2, #0x17]
    // 0xf3da0c: DecompressPointer r4
    //     0xf3da0c: add             x4, x4, HEAP, lsl #32
    // 0xf3da10: r8 = X0 bound StatefulWidget
    //     0xf3da10: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf3da14: ldr             x8, [x8, #0x498]
    // 0xf3da18: LoadField: r9 = r4->field_7
    //     0xf3da18: ldur            x9, [x4, #7]
    // 0xf3da1c: r3 = Null
    //     0xf3da1c: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa36e8] Null
    //     0xf3da20: ldr             x3, [x3, #0x6e8]
    // 0xf3da24: blr             x9
    // 0xf3da28: ldur            x0, [fp, #-0x10]
    // 0xf3da2c: LoadField: r1 = r0->field_b
    //     0xf3da2c: ldur            w1, [x0, #0xb]
    // 0xf3da30: DecompressPointer r1
    //     0xf3da30: add             x1, x1, HEAP, lsl #32
    // 0xf3da34: ldur            x0, [fp, #-8]
    // 0xf3da38: LoadField: r2 = r0->field_b
    //     0xf3da38: ldur            w2, [x0, #0xb]
    // 0xf3da3c: DecompressPointer r2
    //     0xf3da3c: add             x2, x2, HEAP, lsl #32
    // 0xf3da40: cmp             w2, NULL
    // 0xf3da44: b.eq            #0xf3db6c
    // 0xf3da48: LoadField: r3 = r2->field_b
    //     0xf3da48: ldur            w3, [x2, #0xb]
    // 0xf3da4c: DecompressPointer r3
    //     0xf3da4c: add             x3, x3, HEAP, lsl #32
    // 0xf3da50: cmp             w1, w3
    // 0xf3da54: b.eq            #0xf3db54
    // 0xf3da58: LoadField: r1 = r0->field_1f
    //     0xf3da58: ldur            w1, [x0, #0x1f]
    // 0xf3da5c: DecompressPointer r1
    //     0xf3da5c: add             x1, x1, HEAP, lsl #32
    // 0xf3da60: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3da64: cmp             w1, w16
    // 0xf3da68: b.eq            #0xf3db70
    // 0xf3da6c: r0 = value()
    //     0xf3da6c: bl              #0xae5f84  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xf3da70: LoadField: d0 = r0->field_7
    //     0xf3da70: ldur            d0, [x0, #7]
    // 0xf3da74: d1 = 0.000000
    //     0xf3da74: eor             v1.16b, v1.16b, v1.16b
    // 0xf3da78: fcmp            d0, d1
    // 0xf3da7c: b.eq            #0xf3daa0
    // 0xf3da80: ldur            x0, [fp, #-8]
    // 0xf3da84: LoadField: r1 = r0->field_1f
    //     0xf3da84: ldur            w1, [x0, #0x1f]
    // 0xf3da88: DecompressPointer r1
    //     0xf3da88: add             x1, x1, HEAP, lsl #32
    // 0xf3da8c: r0 = value()
    //     0xf3da8c: bl              #0xae5f84  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xf3da90: LoadField: d0 = r0->field_7
    //     0xf3da90: ldur            d0, [x0, #7]
    // 0xf3da94: d1 = 1.000000
    //     0xf3da94: fmov            d1, #1.00000000
    // 0xf3da98: fcmp            d0, d1
    // 0xf3da9c: b.ne            #0xf3db4c
    // 0xf3daa0: ldur            x0, [fp, #-8]
    // 0xf3daa4: LoadField: r1 = r0->field_b
    //     0xf3daa4: ldur            w1, [x0, #0xb]
    // 0xf3daa8: DecompressPointer r1
    //     0xf3daa8: add             x1, x1, HEAP, lsl #32
    // 0xf3daac: cmp             w1, NULL
    // 0xf3dab0: b.eq            #0xf3db7c
    // 0xf3dab4: LoadField: r2 = r1->field_73
    //     0xf3dab4: ldur            w2, [x1, #0x73]
    // 0xf3dab8: DecompressPointer r2
    //     0xf3dab8: add             x2, x2, HEAP, lsl #32
    // 0xf3dabc: LoadField: r1 = r2->field_7
    //     0xf3dabc: ldur            x1, [x2, #7]
    // 0xf3dac0: cmp             x1, #0
    // 0xf3dac4: b.gt            #0xf3dad4
    // 0xf3dac8: mov             x1, x0
    // 0xf3dacc: r0 = updateCurve()
    //     0xf3dacc: bl              #0xf3db84  ; [package:flutter/src/material/switch.dart] _MaterialSwitchState::updateCurve
    // 0xf3dad0: b               #0xf3db4c
    // 0xf3dad4: LoadField: r1 = r0->field_f
    //     0xf3dad4: ldur            w1, [x0, #0xf]
    // 0xf3dad8: DecompressPointer r1
    //     0xf3dad8: add             x1, x1, HEAP, lsl #32
    // 0xf3dadc: cmp             w1, NULL
    // 0xf3dae0: b.eq            #0xf3db80
    // 0xf3dae4: r0 = of()
    //     0xf3dae4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xf3dae8: LoadField: r1 = r0->field_23
    //     0xf3dae8: ldur            w1, [x0, #0x23]
    // 0xf3daec: DecompressPointer r1
    //     0xf3daec: add             x1, x1, HEAP, lsl #32
    // 0xf3daf0: LoadField: r0 = r1->field_7
    //     0xf3daf0: ldur            x0, [x1, #7]
    // 0xf3daf4: cmp             x0, #2
    // 0xf3daf8: b.gt            #0xf3db0c
    // 0xf3dafc: cmp             x0, #1
    // 0xf3db00: b.gt            #0xf3db24
    // 0xf3db04: ldur            x0, [fp, #-8]
    // 0xf3db08: b               #0xf3db44
    // 0xf3db0c: cmp             x0, #4
    // 0xf3db10: b.gt            #0xf3db40
    // 0xf3db14: cmp             x0, #3
    // 0xf3db18: b.gt            #0xf3db24
    // 0xf3db1c: ldur            x0, [fp, #-8]
    // 0xf3db20: b               #0xf3db44
    // 0xf3db24: ldur            x0, [fp, #-8]
    // 0xf3db28: r1 = Instance__Linear
    //     0xf3db28: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xf3db2c: LoadField: r2 = r0->field_1f
    //     0xf3db2c: ldur            w2, [x0, #0x1f]
    // 0xf3db30: DecompressPointer r2
    //     0xf3db30: add             x2, x2, HEAP, lsl #32
    // 0xf3db34: StoreField: r2->field_f = r1
    //     0xf3db34: stur            w1, [x2, #0xf]
    // 0xf3db38: StoreField: r2->field_13 = r1
    //     0xf3db38: stur            w1, [x2, #0x13]
    // 0xf3db3c: b               #0xf3db4c
    // 0xf3db40: ldur            x0, [fp, #-8]
    // 0xf3db44: mov             x1, x0
    // 0xf3db48: r0 = updateCurve()
    //     0xf3db48: bl              #0xf3db84  ; [package:flutter/src/material/switch.dart] _MaterialSwitchState::updateCurve
    // 0xf3db4c: ldur            x1, [fp, #-8]
    // 0xf3db50: r0 = animateToValue()
    //     0xf3db50: bl              #0xd423d8  ; [dart:mixin_deduplication] _MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin::animateToValue
    // 0xf3db54: r0 = Null
    //     0xf3db54: mov             x0, NULL
    // 0xf3db58: LeaveFrame
    //     0xf3db58: mov             SP, fp
    //     0xf3db5c: ldp             fp, lr, [SP], #0x10
    // 0xf3db60: ret
    //     0xf3db60: ret             
    // 0xf3db64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3db64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3db68: b               #0xf3d9b0
    // 0xf3db6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3db6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3db70: r9 = _position
    //     0xf3db70: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3620] Field <_MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin@18353248._position@61045596>: late (offset: 0x20)
    //     0xf3db74: ldr             x9, [x9, #0x620]
    // 0xf3db78: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3db78: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf3db7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3db7c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3db80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3db80: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ updateCurve(/* No info */) {
    // ** addr: 0xf3db84, size: 0x104
    // 0xf3db84: EnterFrame
    //     0xf3db84: stp             fp, lr, [SP, #-0x10]!
    //     0xf3db88: mov             fp, SP
    // 0xf3db8c: AllocStack(0x10)
    //     0xf3db8c: sub             SP, SP, #0x10
    // 0xf3db90: SetupParameters(_MaterialSwitchState this /* r1 => r0, fp-0x8 */)
    //     0xf3db90: mov             x0, x1
    //     0xf3db94: stur            x1, [fp, #-8]
    // 0xf3db98: CheckStackOverflow
    //     0xf3db98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3db9c: cmp             SP, x16
    //     0xf3dba0: b.ls            #0xf3dc64
    // 0xf3dba4: LoadField: r1 = r0->field_f
    //     0xf3dba4: ldur            w1, [x0, #0xf]
    // 0xf3dba8: DecompressPointer r1
    //     0xf3dba8: add             x1, x1, HEAP, lsl #32
    // 0xf3dbac: cmp             w1, NULL
    // 0xf3dbb0: b.eq            #0xf3dc6c
    // 0xf3dbb4: r0 = of()
    //     0xf3dbb4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xf3dbb8: LoadField: r1 = r0->field_2f
    //     0xf3dbb8: ldur            w1, [x0, #0x2f]
    // 0xf3dbbc: DecompressPointer r1
    //     0xf3dbbc: add             x1, x1, HEAP, lsl #32
    // 0xf3dbc0: tbnz            w1, #4, #0xf3dc24
    // 0xf3dbc4: ldur            x0, [fp, #-8]
    // 0xf3dbc8: r2 = Instance_Cubic
    //     0xf3dbc8: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa36f8] Obj!Cubic@129f781
    //     0xf3dbcc: ldr             x2, [x2, #0x6f8]
    // 0xf3dbd0: LoadField: r3 = r0->field_1f
    //     0xf3dbd0: ldur            w3, [x0, #0x1f]
    // 0xf3dbd4: DecompressPointer r3
    //     0xf3dbd4: add             x3, x3, HEAP, lsl #32
    // 0xf3dbd8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3dbdc: cmp             w3, w16
    // 0xf3dbe0: b.eq            #0xf3dc70
    // 0xf3dbe4: stur            x3, [fp, #-0x10]
    // 0xf3dbe8: StoreField: r3->field_f = r2
    //     0xf3dbe8: stur            w2, [x3, #0xf]
    // 0xf3dbec: r1 = <double>
    //     0xf3dbec: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3dbf0: r0 = FlippedCurve()
    //     0xf3dbf0: bl              #0xb6f814  ; AllocateFlippedCurveStub -> FlippedCurve (size=0x10)
    // 0xf3dbf4: r1 = Instance_Cubic
    //     0xf3dbf4: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa36f8] Obj!Cubic@129f781
    //     0xf3dbf8: ldr             x1, [x1, #0x6f8]
    // 0xf3dbfc: StoreField: r0->field_b = r1
    //     0xf3dbfc: stur            w1, [x0, #0xb]
    // 0xf3dc00: ldur            x1, [fp, #-0x10]
    // 0xf3dc04: StoreField: r1->field_13 = r0
    //     0xf3dc04: stur            w0, [x1, #0x13]
    //     0xf3dc08: ldurb           w16, [x1, #-1]
    //     0xf3dc0c: ldurb           w17, [x0, #-1]
    //     0xf3dc10: and             x16, x17, x16, lsr #2
    //     0xf3dc14: tst             x16, HEAP, lsr #32
    //     0xf3dc18: b.eq            #0xf3dc20
    //     0xf3dc1c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf3dc20: b               #0xf3dc54
    // 0xf3dc24: ldur            x0, [fp, #-8]
    // 0xf3dc28: r2 = Instance_Cubic
    //     0xf3dc28: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e970] Obj!Cubic@129f541
    //     0xf3dc2c: ldr             x2, [x2, #0x970]
    // 0xf3dc30: r1 = Instance_Cubic
    //     0xf3dc30: add             x1, PP, #0x15, lsl #12  ; [pp+0x158f0] Obj!Cubic@129f571
    //     0xf3dc34: ldr             x1, [x1, #0x8f0]
    // 0xf3dc38: LoadField: r3 = r0->field_1f
    //     0xf3dc38: ldur            w3, [x0, #0x1f]
    // 0xf3dc3c: DecompressPointer r3
    //     0xf3dc3c: add             x3, x3, HEAP, lsl #32
    // 0xf3dc40: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3dc44: cmp             w3, w16
    // 0xf3dc48: b.eq            #0xf3dc7c
    // 0xf3dc4c: StoreField: r3->field_f = r2
    //     0xf3dc4c: stur            w2, [x3, #0xf]
    // 0xf3dc50: StoreField: r3->field_13 = r1
    //     0xf3dc50: stur            w1, [x3, #0x13]
    // 0xf3dc54: r0 = Null
    //     0xf3dc54: mov             x0, NULL
    // 0xf3dc58: LeaveFrame
    //     0xf3dc58: mov             SP, fp
    //     0xf3dc5c: ldp             fp, lr, [SP], #0x10
    // 0xf3dc60: ret
    //     0xf3dc60: ret             
    // 0xf3dc64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3dc64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3dc68: b               #0xf3dba4
    // 0xf3dc6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3dc6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3dc70: r9 = _position
    //     0xf3dc70: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3620] Field <_MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin@18353248._position@61045596>: late (offset: 0x20)
    //     0xf3dc74: ldr             x9, [x9, #0x620]
    // 0xf3dc78: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3dc78: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf3dc7c: r9 = _position
    //     0xf3dc7c: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3620] Field <_MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin@18353248._position@61045596>: late (offset: 0x20)
    //     0xf3dc80: ldr             x9, [x9, #0x620]
    // 0xf3dc84: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3dc84: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _MaterialSwitchState(/* No info */) {
    // ** addr: 0xfa304c, size: 0x78
    // 0xfa304c: EnterFrame
    //     0xfa304c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa3050: mov             fp, SP
    // 0xfa3054: AllocStack(0x10)
    //     0xfa3054: sub             SP, SP, #0x10
    // 0xfa3058: r0 = false
    //     0xfa3058: add             x0, NULL, #0x30  ; false
    // 0xfa305c: stur            x1, [fp, #-8]
    // 0xfa3060: CheckStackOverflow
    //     0xfa3060: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa3064: cmp             SP, x16
    //     0xfa3068: b.ls            #0xfa30bc
    // 0xfa306c: StoreField: r1->field_53 = r0
    //     0xfa306c: stur            w0, [x1, #0x53]
    // 0xfa3070: StoreField: r1->field_57 = r0
    //     0xfa3070: stur            w0, [x1, #0x57]
    // 0xfa3074: r0 = _SwitchPainter()
    //     0xfa3074: bl              #0xfa3190  ; Allocate_SwitchPainterStub -> _SwitchPainter (size=0x10c)
    // 0xfa3078: mov             x1, x0
    // 0xfa307c: stur            x0, [fp, #-0x10]
    // 0xfa3080: r0 = _SwitchPainter()
    //     0xfa3080: bl              #0xfa30c4  ; [package:flutter/src/material/switch.dart] _SwitchPainter::_SwitchPainter
    // 0xfa3084: ldur            x0, [fp, #-0x10]
    // 0xfa3088: ldur            x1, [fp, #-8]
    // 0xfa308c: StoreField: r1->field_4f = r0
    //     0xfa308c: stur            w0, [x1, #0x4f]
    //     0xfa3090: ldurb           w16, [x1, #-1]
    //     0xfa3094: ldurb           w17, [x0, #-1]
    //     0xfa3098: and             x16, x17, x16, lsr #2
    //     0xfa309c: tst             x16, HEAP, lsr #32
    //     0xfa30a0: b.eq            #0xfa30a8
    //     0xfa30a4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa30a8: r0 = _MixinApplication257&State&TickerProviderStateMixin&ToggleableStateMixin()
    //     0xfa30a8: bl              #0xfa0328  ; [dart:mixin_deduplication] _MixinApplication257&State&TickerProviderStateMixin&ToggleableStateMixin::_MixinApplication257&State&TickerProviderStateMixin&ToggleableStateMixin
    // 0xfa30ac: r0 = Null
    //     0xfa30ac: mov             x0, NULL
    // 0xfa30b0: LeaveFrame
    //     0xfa30b0: mov             SP, fp
    //     0xfa30b4: ldp             fp, lr, [SP], #0x10
    // 0xfa30b8: ret
    //     0xfa30b8: ret             
    // 0xfa30bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa30bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa30c0: b               #0xfa306c
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10de140, size: 0x4c
    // 0x10de140: EnterFrame
    //     0x10de140: stp             fp, lr, [SP, #-0x10]!
    //     0x10de144: mov             fp, SP
    // 0x10de148: AllocStack(0x8)
    //     0x10de148: sub             SP, SP, #8
    // 0x10de14c: SetupParameters(_MaterialSwitchState this /* r1 => r0, fp-0x8 */)
    //     0x10de14c: mov             x0, x1
    //     0x10de150: stur            x1, [fp, #-8]
    // 0x10de154: CheckStackOverflow
    //     0x10de154: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10de158: cmp             SP, x16
    //     0x10de15c: b.ls            #0x10de184
    // 0x10de160: LoadField: r1 = r0->field_4f
    //     0x10de160: ldur            w1, [x0, #0x4f]
    // 0x10de164: DecompressPointer r1
    //     0x10de164: add             x1, x1, HEAP, lsl #32
    // 0x10de168: r0 = dispose()
    //     0x10de168: bl              #0x10ef044  ; [package:flutter/src/material/switch.dart] _SwitchPainter::dispose
    // 0x10de16c: ldur            x1, [fp, #-8]
    // 0x10de170: r0 = dispose()
    //     0x10de170: bl              #0x10de18c  ; [dart:mixin_deduplication] _MixinApplication110&State&TickerProviderStateMixin&ToggleableStateMixin::dispose
    // 0x10de174: r0 = Null
    //     0x10de174: mov             x0, NULL
    // 0x10de178: LeaveFrame
    //     0x10de178: mov             SP, fp
    //     0x10de17c: ldp             fp, lr, [SP], #0x10
    // 0x10de180: ret
    //     0x10de180: ret             
    // 0x10de184: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10de184: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10de188: b               #0x10de160
  }
}

// class id: 6142, size: 0x80, field offset: 0xc
//   const constructor, 
class Switch extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfbe0f8, size: 0x164
    // 0xfbe0f8: EnterFrame
    //     0xfbe0f8: stp             fp, lr, [SP, #-0x10]!
    //     0xfbe0fc: mov             fp, SP
    // 0xfbe100: AllocStack(0x48)
    //     0xfbe100: sub             SP, SP, #0x48
    // 0xfbe104: SetupParameters(Switch this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfbe104: mov             x0, x2
    //     0xfbe108: stur            x2, [fp, #-0x10]
    //     0xfbe10c: mov             x2, x1
    //     0xfbe110: stur            x1, [fp, #-8]
    // 0xfbe114: CheckStackOverflow
    //     0xfbe114: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbe118: cmp             SP, x16
    //     0xfbe11c: b.ls            #0xfbe254
    // 0xfbe120: LoadField: r1 = r2->field_4f
    //     0xfbe120: ldur            w1, [x2, #0x4f]
    // 0xfbe124: DecompressPointer r1
    //     0xfbe124: add             x1, x1, HEAP, lsl #32
    // 0xfbe128: LoadField: r3 = r1->field_7
    //     0xfbe128: ldur            x3, [x1, #7]
    // 0xfbe12c: cmp             x3, #0
    // 0xfbe130: b.gt            #0xfbe13c
    // 0xfbe134: mov             x0, x2
    // 0xfbe138: b               #0xfbe178
    // 0xfbe13c: mov             x1, x0
    // 0xfbe140: r0 = of()
    //     0xfbe140: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfbe144: LoadField: r1 = r0->field_23
    //     0xfbe144: ldur            w1, [x0, #0x23]
    // 0xfbe148: DecompressPointer r1
    //     0xfbe148: add             x1, x1, HEAP, lsl #32
    // 0xfbe14c: LoadField: r0 = r1->field_7
    //     0xfbe14c: ldur            x0, [x1, #7]
    // 0xfbe150: cmp             x0, #2
    // 0xfbe154: b.gt            #0xfbe164
    // 0xfbe158: cmp             x0, #1
    // 0xfbe15c: b.gt            #0xfbe174
    // 0xfbe160: b               #0xfbe174
    // 0xfbe164: cmp             x0, #4
    // 0xfbe168: b.gt            #0xfbe174
    // 0xfbe16c: cmp             x0, #3
    // 0xfbe170: b.le            #0xfbe174
    // 0xfbe174: ldur            x0, [fp, #-8]
    // 0xfbe178: LoadField: r3 = r0->field_b
    //     0xfbe178: ldur            w3, [x0, #0xb]
    // 0xfbe17c: DecompressPointer r3
    //     0xfbe17c: add             x3, x3, HEAP, lsl #32
    // 0xfbe180: stur            x3, [fp, #-0x20]
    // 0xfbe184: LoadField: r4 = r0->field_f
    //     0xfbe184: ldur            w4, [x0, #0xf]
    // 0xfbe188: DecompressPointer r4
    //     0xfbe188: add             x4, x4, HEAP, lsl #32
    // 0xfbe18c: mov             x1, x0
    // 0xfbe190: ldur            x2, [fp, #-0x10]
    // 0xfbe194: stur            x4, [fp, #-0x18]
    // 0xfbe198: r0 = _getSwitchSize()
    //     0xfbe198: bl              #0xfbe268  ; [package:flutter/src/material/switch.dart] Switch::_getSwitchSize
    // 0xfbe19c: mov             x1, x0
    // 0xfbe1a0: ldur            x0, [fp, #-8]
    // 0xfbe1a4: stur            x1, [fp, #-0x48]
    // 0xfbe1a8: LoadField: r2 = r0->field_1b
    //     0xfbe1a8: ldur            w2, [x0, #0x1b]
    // 0xfbe1ac: DecompressPointer r2
    //     0xfbe1ac: add             x2, x2, HEAP, lsl #32
    // 0xfbe1b0: stur            x2, [fp, #-0x40]
    // 0xfbe1b4: LoadField: r3 = r0->field_1f
    //     0xfbe1b4: ldur            w3, [x0, #0x1f]
    // 0xfbe1b8: DecompressPointer r3
    //     0xfbe1b8: add             x3, x3, HEAP, lsl #32
    // 0xfbe1bc: stur            x3, [fp, #-0x38]
    // 0xfbe1c0: LoadField: r4 = r0->field_23
    //     0xfbe1c0: ldur            w4, [x0, #0x23]
    // 0xfbe1c4: DecompressPointer r4
    //     0xfbe1c4: add             x4, x4, HEAP, lsl #32
    // 0xfbe1c8: stur            x4, [fp, #-0x30]
    // 0xfbe1cc: LoadField: r5 = r0->field_3f
    //     0xfbe1cc: ldur            w5, [x0, #0x3f]
    // 0xfbe1d0: DecompressPointer r5
    //     0xfbe1d0: add             x5, x5, HEAP, lsl #32
    // 0xfbe1d4: stur            x5, [fp, #-0x28]
    // 0xfbe1d8: LoadField: r6 = r0->field_43
    //     0xfbe1d8: ldur            w6, [x0, #0x43]
    // 0xfbe1dc: DecompressPointer r6
    //     0xfbe1dc: add             x6, x6, HEAP, lsl #32
    // 0xfbe1e0: stur            x6, [fp, #-0x10]
    // 0xfbe1e4: r0 = _MaterialSwitch()
    //     0xfbe1e4: bl              #0xfbe25c  ; Allocate_MaterialSwitchStub -> _MaterialSwitch (size=0x78)
    // 0xfbe1e8: ldur            x1, [fp, #-0x20]
    // 0xfbe1ec: StoreField: r0->field_b = r1
    //     0xfbe1ec: stur            w1, [x0, #0xb]
    // 0xfbe1f0: ldur            x1, [fp, #-0x18]
    // 0xfbe1f4: StoreField: r0->field_f = r1
    //     0xfbe1f4: stur            w1, [x0, #0xf]
    // 0xfbe1f8: ldur            x1, [fp, #-0x48]
    // 0xfbe1fc: StoreField: r0->field_6b = r1
    //     0xfbe1fc: stur            w1, [x0, #0x6b]
    // 0xfbe200: r1 = Instance__SwitchType
    //     0xfbe200: add             x1, PP, #0x7a, lsl #12  ; [pp+0x7abb8] Obj!_SwitchType@12c4d21
    //     0xfbe204: ldr             x1, [x1, #0xbb8]
    // 0xfbe208: StoreField: r0->field_73 = r1
    //     0xfbe208: stur            w1, [x0, #0x73]
    // 0xfbe20c: ldur            x1, [fp, #-0x40]
    // 0xfbe210: ArrayStore: r0[0] = r1  ; List_4
    //     0xfbe210: stur            w1, [x0, #0x17]
    // 0xfbe214: ldur            x1, [fp, #-0x38]
    // 0xfbe218: StoreField: r0->field_1b = r1
    //     0xfbe218: stur            w1, [x0, #0x1b]
    // 0xfbe21c: ldur            x1, [fp, #-0x30]
    // 0xfbe220: StoreField: r0->field_1f = r1
    //     0xfbe220: stur            w1, [x0, #0x1f]
    // 0xfbe224: ldur            x1, [fp, #-0x28]
    // 0xfbe228: StoreField: r0->field_3b = r1
    //     0xfbe228: stur            w1, [x0, #0x3b]
    // 0xfbe22c: ldur            x1, [fp, #-0x10]
    // 0xfbe230: StoreField: r0->field_3f = r1
    //     0xfbe230: stur            w1, [x0, #0x3f]
    // 0xfbe234: r1 = Instance_DragStartBehavior
    //     0xfbe234: ldr             x1, [PP, #0x5360]  ; [pp+0x5360] Obj!DragStartBehavior@12c5c61
    // 0xfbe238: StoreField: r0->field_47 = r1
    //     0xfbe238: stur            w1, [x0, #0x47]
    // 0xfbe23c: r1 = false
    //     0xfbe23c: add             x1, NULL, #0x30  ; false
    // 0xfbe240: StoreField: r0->field_67 = r1
    //     0xfbe240: stur            w1, [x0, #0x67]
    // 0xfbe244: StoreField: r0->field_6f = r1
    //     0xfbe244: stur            w1, [x0, #0x6f]
    // 0xfbe248: LeaveFrame
    //     0xfbe248: mov             SP, fp
    //     0xfbe24c: ldp             fp, lr, [SP], #0x10
    // 0xfbe250: ret
    //     0xfbe250: ret             
    // 0xfbe254: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbe254: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbe258: b               #0xfbe120
  }
  _ _getSwitchSize(/* No info */) {
    // ** addr: 0xfbe268, size: 0x28c
    // 0xfbe268: EnterFrame
    //     0xfbe268: stp             fp, lr, [SP, #-0x10]!
    //     0xfbe26c: mov             fp, SP
    // 0xfbe270: AllocStack(0x40)
    //     0xfbe270: sub             SP, SP, #0x40
    // 0xfbe274: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xfbe274: mov             x0, x2
    //     0xfbe278: stur            x2, [fp, #-8]
    // 0xfbe27c: CheckStackOverflow
    //     0xfbe27c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbe280: cmp             SP, x16
    //     0xfbe284: b.ls            #0xfbe4ec
    // 0xfbe288: mov             x1, x0
    // 0xfbe28c: r0 = of()
    //     0xfbe28c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfbe290: ldur            x1, [fp, #-8]
    // 0xfbe294: stur            x0, [fp, #-0x10]
    // 0xfbe298: r0 = of()
    //     0xfbe298: bl              #0xd4237c  ; [package:flutter/src/material/switch_theme.dart] SwitchTheme::of
    // 0xfbe29c: ldur            x0, [fp, #-0x10]
    // 0xfbe2a0: LoadField: r1 = r0->field_2f
    //     0xfbe2a0: ldur            w1, [x0, #0x2f]
    // 0xfbe2a4: DecompressPointer r1
    //     0xfbe2a4: add             x1, x1, HEAP, lsl #32
    // 0xfbe2a8: stur            x1, [fp, #-0x18]
    // 0xfbe2ac: tbnz            w1, #4, #0xfbe2d4
    // 0xfbe2b0: ldur            x2, [fp, #-8]
    // 0xfbe2b4: r0 = _SwitchDefaultsM3()
    //     0xfbe2b4: bl              #0xd42358  ; Allocate_SwitchDefaultsM3Stub -> _SwitchDefaultsM3 (size=0x38)
    // 0xfbe2b8: mov             x1, x0
    // 0xfbe2bc: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbe2c0: StoreField: r1->field_33 = r0
    //     0xfbe2c0: stur            w0, [x1, #0x33]
    // 0xfbe2c4: ldur            x0, [fp, #-8]
    // 0xfbe2c8: StoreField: r1->field_2f = r0
    //     0xfbe2c8: stur            w0, [x1, #0x2f]
    // 0xfbe2cc: mov             x2, x1
    // 0xfbe2d0: b               #0xfbe330
    // 0xfbe2d4: ldur            x0, [fp, #-8]
    // 0xfbe2d8: mov             x1, x0
    // 0xfbe2dc: r0 = of()
    //     0xfbe2dc: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfbe2e0: stur            x0, [fp, #-0x20]
    // 0xfbe2e4: r0 = _SwitchDefaultsM2()
    //     0xfbe2e4: bl              #0xd4234c  ; Allocate_SwitchDefaultsM2Stub -> _SwitchDefaultsM2 (size=0x38)
    // 0xfbe2e8: mov             x2, x0
    // 0xfbe2ec: ldur            x0, [fp, #-0x20]
    // 0xfbe2f0: stur            x2, [fp, #-0x28]
    // 0xfbe2f4: StoreField: r2->field_2f = r0
    //     0xfbe2f4: stur            w0, [x2, #0x2f]
    // 0xfbe2f8: ldur            x1, [fp, #-8]
    // 0xfbe2fc: r0 = of()
    //     0xfbe2fc: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfbe300: LoadField: r1 = r0->field_3f
    //     0xfbe300: ldur            w1, [x0, #0x3f]
    // 0xfbe304: DecompressPointer r1
    //     0xfbe304: add             x1, x1, HEAP, lsl #32
    // 0xfbe308: mov             x0, x1
    // 0xfbe30c: ldur            x1, [fp, #-0x28]
    // 0xfbe310: StoreField: r1->field_33 = r0
    //     0xfbe310: stur            w0, [x1, #0x33]
    //     0xfbe314: ldurb           w16, [x1, #-1]
    //     0xfbe318: ldurb           w17, [x0, #-1]
    //     0xfbe31c: and             x16, x17, x16, lsr #2
    //     0xfbe320: tst             x16, HEAP, lsr #32
    //     0xfbe324: b.eq            #0xfbe32c
    //     0xfbe328: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfbe32c: mov             x2, x1
    // 0xfbe330: ldur            x0, [fp, #-0x18]
    // 0xfbe334: stur            x2, [fp, #-0x20]
    // 0xfbe338: tbnz            w0, #4, #0xfbe368
    // 0xfbe33c: ldur            x1, [fp, #-8]
    // 0xfbe340: r0 = of()
    //     0xfbe340: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfbe344: LoadField: r1 = r0->field_3f
    //     0xfbe344: ldur            w1, [x0, #0x3f]
    // 0xfbe348: DecompressPointer r1
    //     0xfbe348: add             x1, x1, HEAP, lsl #32
    // 0xfbe34c: stur            x1, [fp, #-8]
    // 0xfbe350: r0 = _SwitchConfigM3()
    //     0xfbe350: bl              #0xd42370  ; Allocate_SwitchConfigM3Stub -> _SwitchConfigM3 (size=0xc)
    // 0xfbe354: mov             x1, x0
    // 0xfbe358: ldur            x0, [fp, #-8]
    // 0xfbe35c: StoreField: r1->field_7 = r0
    //     0xfbe35c: stur            w0, [x1, #7]
    // 0xfbe360: mov             x2, x1
    // 0xfbe364: b               #0xfbe370
    // 0xfbe368: r0 = _SwitchConfigM2()
    //     0xfbe368: bl              #0xd42364  ; Allocate_SwitchConfigM2Stub -> _SwitchConfigM2 (size=0x8)
    // 0xfbe36c: mov             x2, x0
    // 0xfbe370: ldur            x1, [fp, #-0x10]
    // 0xfbe374: ldur            x0, [fp, #-0x20]
    // 0xfbe378: stur            x2, [fp, #-0x18]
    // 0xfbe37c: LoadField: r3 = r1->field_1b
    //     0xfbe37c: ldur            w3, [x1, #0x1b]
    // 0xfbe380: DecompressPointer r3
    //     0xfbe380: add             x3, x3, HEAP, lsl #32
    // 0xfbe384: r1 = LoadClassIdInstr(r0)
    //     0xfbe384: ldur            x1, [x0, #-1]
    //     0xfbe388: ubfx            x1, x1, #0xc, #0x14
    // 0xfbe38c: r17 = 5062
    //     0xfbe38c: mov             x17, #0x13c6
    // 0xfbe390: cmp             x1, x17
    // 0xfbe394: b.eq            #0xfbe3c4
    // 0xfbe398: r17 = 5063
    //     0xfbe398: mov             x17, #0x13c7
    // 0xfbe39c: cmp             x1, x17
    // 0xfbe3a0: b.ne            #0xfbe3b0
    // 0xfbe3a4: r4 = Instance_EdgeInsets
    //     0xfbe3a4: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1c430] Obj!EdgeInsets@129dc51
    //     0xfbe3a8: ldr             x4, [x4, #0x430]
    // 0xfbe3ac: b               #0xfbe3d0
    // 0xfbe3b0: r17 = 5064
    //     0xfbe3b0: mov             x17, #0x13c8
    // 0xfbe3b4: cmp             x1, x17
    // 0xfbe3b8: b.ne            #0xfbe3c4
    // 0xfbe3bc: r4 = Instance_EdgeInsets
    //     0xfbe3bc: ldr             x4, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xfbe3c0: b               #0xfbe3d0
    // 0xfbe3c4: LoadField: r1 = r0->field_2b
    //     0xfbe3c4: ldur            w1, [x0, #0x2b]
    // 0xfbe3c8: DecompressPointer r1
    //     0xfbe3c8: add             x1, x1, HEAP, lsl #32
    // 0xfbe3cc: mov             x4, x1
    // 0xfbe3d0: stur            x4, [fp, #-8]
    // 0xfbe3d4: LoadField: r0 = r3->field_7
    //     0xfbe3d4: ldur            x0, [x3, #7]
    // 0xfbe3d8: cmp             x0, #0
    // 0xfbe3dc: b.gt            #0xfbe464
    // 0xfbe3e0: r0 = LoadClassIdInstr(r2)
    //     0xfbe3e0: ldur            x0, [x2, #-1]
    //     0xfbe3e4: ubfx            x0, x0, #0xc, #0x14
    // 0xfbe3e8: mov             x1, x2
    // 0xfbe3ec: r0 = GDT[cid_x0 + -0xc3]()
    //     0xfbe3ec: sub             lr, x0, #0xc3
    //     0xfbe3f0: ldr             lr, [x21, lr, lsl #3]
    //     0xfbe3f4: blr             lr
    // 0xfbe3f8: ldur            x1, [fp, #-8]
    // 0xfbe3fc: stur            d0, [fp, #-0x30]
    // 0xfbe400: r0 = horizontal()
    //     0xfbe400: bl              #0xb17264  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::horizontal
    // 0xfbe404: mov             v1.16b, v0.16b
    // 0xfbe408: ldur            d0, [fp, #-0x30]
    // 0xfbe40c: fadd            d2, d0, d1
    // 0xfbe410: ldur            x2, [fp, #-0x18]
    // 0xfbe414: stur            d2, [fp, #-0x38]
    // 0xfbe418: r0 = LoadClassIdInstr(r2)
    //     0xfbe418: ldur            x0, [x2, #-1]
    //     0xfbe41c: ubfx            x0, x0, #0xc, #0x14
    // 0xfbe420: mov             x1, x2
    // 0xfbe424: r0 = GDT[cid_x0 + 0x89e]()
    //     0xfbe424: add             lr, x0, #0x89e
    //     0xfbe428: ldr             lr, [x21, lr, lsl #3]
    //     0xfbe42c: blr             lr
    // 0xfbe430: ldur            x1, [fp, #-8]
    // 0xfbe434: stur            d0, [fp, #-0x30]
    // 0xfbe438: r0 = vertical()
    //     0xfbe438: bl              #0xb1730c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::vertical
    // 0xfbe43c: mov             v1.16b, v0.16b
    // 0xfbe440: ldur            d0, [fp, #-0x30]
    // 0xfbe444: fadd            d2, d0, d1
    // 0xfbe448: stur            d2, [fp, #-0x40]
    // 0xfbe44c: r0 = Size()
    //     0xfbe44c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xfbe450: ldur            d0, [fp, #-0x38]
    // 0xfbe454: StoreField: r0->field_7 = d0
    //     0xfbe454: stur            d0, [x0, #7]
    // 0xfbe458: ldur            d0, [fp, #-0x40]
    // 0xfbe45c: StoreField: r0->field_f = d0
    //     0xfbe45c: stur            d0, [x0, #0xf]
    // 0xfbe460: b               #0xfbe4e0
    // 0xfbe464: r0 = LoadClassIdInstr(r2)
    //     0xfbe464: ldur            x0, [x2, #-1]
    //     0xfbe468: ubfx            x0, x0, #0xc, #0x14
    // 0xfbe46c: mov             x1, x2
    // 0xfbe470: r0 = GDT[cid_x0 + -0xc3]()
    //     0xfbe470: sub             lr, x0, #0xc3
    //     0xfbe474: ldr             lr, [x21, lr, lsl #3]
    //     0xfbe478: blr             lr
    // 0xfbe47c: ldur            x1, [fp, #-8]
    // 0xfbe480: stur            d0, [fp, #-0x30]
    // 0xfbe484: r0 = horizontal()
    //     0xfbe484: bl              #0xb17264  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::horizontal
    // 0xfbe488: mov             v1.16b, v0.16b
    // 0xfbe48c: ldur            d0, [fp, #-0x30]
    // 0xfbe490: fadd            d2, d0, d1
    // 0xfbe494: ldur            x1, [fp, #-0x18]
    // 0xfbe498: stur            d2, [fp, #-0x38]
    // 0xfbe49c: r0 = LoadClassIdInstr(r1)
    //     0xfbe49c: ldur            x0, [x1, #-1]
    //     0xfbe4a0: ubfx            x0, x0, #0xc, #0x14
    // 0xfbe4a4: r0 = GDT[cid_x0 + 0x84d]()
    //     0xfbe4a4: add             lr, x0, #0x84d
    //     0xfbe4a8: ldr             lr, [x21, lr, lsl #3]
    //     0xfbe4ac: blr             lr
    // 0xfbe4b0: ldur            x1, [fp, #-8]
    // 0xfbe4b4: stur            d0, [fp, #-0x30]
    // 0xfbe4b8: r0 = vertical()
    //     0xfbe4b8: bl              #0xb1730c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::vertical
    // 0xfbe4bc: mov             v1.16b, v0.16b
    // 0xfbe4c0: ldur            d0, [fp, #-0x30]
    // 0xfbe4c4: fadd            d2, d0, d1
    // 0xfbe4c8: stur            d2, [fp, #-0x40]
    // 0xfbe4cc: r0 = Size()
    //     0xfbe4cc: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xfbe4d0: ldur            d0, [fp, #-0x38]
    // 0xfbe4d4: StoreField: r0->field_7 = d0
    //     0xfbe4d4: stur            d0, [x0, #7]
    // 0xfbe4d8: ldur            d0, [fp, #-0x40]
    // 0xfbe4dc: StoreField: r0->field_f = d0
    //     0xfbe4dc: stur            d0, [x0, #0xf]
    // 0xfbe4e0: LeaveFrame
    //     0xfbe4e0: mov             SP, fp
    //     0xfbe4e4: ldp             fp, lr, [SP], #0x10
    // 0xfbe4e8: ret
    //     0xfbe4e8: ret             
    // 0xfbe4ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbe4ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbe4f0: b               #0xfbe288
  }
}

// class id: 6431, size: 0x78, field offset: 0xc
//   const constructor, 
class _MaterialSwitch extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa3004, size: 0x48
    // 0xfa3004: EnterFrame
    //     0xfa3004: stp             fp, lr, [SP, #-0x10]!
    //     0xfa3008: mov             fp, SP
    // 0xfa300c: AllocStack(0x8)
    //     0xfa300c: sub             SP, SP, #8
    // 0xfa3010: CheckStackOverflow
    //     0xfa3010: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa3014: cmp             SP, x16
    //     0xfa3018: b.ls            #0xfa3044
    // 0xfa301c: r1 = <_MaterialSwitch>
    //     0xfa301c: add             x1, PP, #0x98, lsl #12  ; [pp+0x98ea8] TypeArguments: <_MaterialSwitch>
    //     0xfa3020: ldr             x1, [x1, #0xea8]
    // 0xfa3024: r0 = _MaterialSwitchState()
    //     0xfa3024: bl              #0xfa31a4  ; Allocate_MaterialSwitchStateStub -> _MaterialSwitchState (size=0x5c)
    // 0xfa3028: mov             x1, x0
    // 0xfa302c: stur            x0, [fp, #-8]
    // 0xfa3030: r0 = _MaterialSwitchState()
    //     0xfa3030: bl              #0xfa304c  ; [package:flutter/src/material/switch.dart] _MaterialSwitchState::_MaterialSwitchState
    // 0xfa3034: ldur            x0, [fp, #-8]
    // 0xfa3038: LeaveFrame
    //     0xfa3038: mov             SP, fp
    //     0xfa303c: ldp             fp, lr, [SP], #0x10
    // 0xfa3040: ret
    //     0xfa3040: ret             
    // 0xfa3044: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa3044: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa3048: b               #0xfa301c
  }
}

// class id: 8260, size: 0x14, field offset: 0x14
enum _SwitchType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa990, size: 0x64
    // 0x11aa990: EnterFrame
    //     0x11aa990: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa994: mov             fp, SP
    // 0x11aa998: AllocStack(0x10)
    //     0x11aa998: sub             SP, SP, #0x10
    // 0x11aa99c: SetupParameters(_SwitchType this /* r1 => r0, fp-0x8 */)
    //     0x11aa99c: mov             x0, x1
    //     0x11aa9a0: stur            x1, [fp, #-8]
    // 0x11aa9a4: CheckStackOverflow
    //     0x11aa9a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa9a8: cmp             SP, x16
    //     0x11aa9ac: b.ls            #0x11aa9ec
    // 0x11aa9b0: r1 = Null
    //     0x11aa9b0: mov             x1, NULL
    // 0x11aa9b4: r2 = 4
    //     0x11aa9b4: mov             x2, #4
    // 0x11aa9b8: r0 = AllocateArray()
    //     0x11aa9b8: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa9bc: r16 = "_SwitchType."
    //     0x11aa9bc: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8f9c8] "_SwitchType."
    //     0x11aa9c0: ldr             x16, [x16, #0x9c8]
    // 0x11aa9c4: StoreField: r0->field_f = r16
    //     0x11aa9c4: stur            w16, [x0, #0xf]
    // 0x11aa9c8: ldur            x1, [fp, #-8]
    // 0x11aa9cc: LoadField: r2 = r1->field_f
    //     0x11aa9cc: ldur            w2, [x1, #0xf]
    // 0x11aa9d0: DecompressPointer r2
    //     0x11aa9d0: add             x2, x2, HEAP, lsl #32
    // 0x11aa9d4: StoreField: r0->field_13 = r2
    //     0x11aa9d4: stur            w2, [x0, #0x13]
    // 0x11aa9d8: str             x0, [SP]
    // 0x11aa9dc: r0 = _interpolate()
    //     0x11aa9dc: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa9e0: LeaveFrame
    //     0x11aa9e0: mov             SP, fp
    //     0x11aa9e4: ldp             fp, lr, [SP], #0x10
    // 0x11aa9e8: ret
    //     0x11aa9e8: ret             
    // 0x11aa9ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa9ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa9f0: b               #0x11aa9b0
  }
}
