// lib: , url: package:flutter/src/material/scrollbar_theme.dart

// class id: 1048940, size: 0x8
class :: {
}

// class id: 5118, size: 0x34, field offset: 0x8
//   const constructor, 
class ScrollbarThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x11359fc, size: 0x88
    // 0x11359fc: EnterFrame
    //     0x11359fc: stp             fp, lr, [SP, #-0x10]!
    //     0x1135a00: mov             fp, SP
    // 0x1135a04: AllocStack(0x48)
    //     0x1135a04: sub             SP, SP, #0x48
    // 0x1135a08: CheckStackOverflow
    //     0x1135a08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1135a0c: cmp             SP, x16
    //     0x1135a10: b.ls            #0x1135a7c
    // 0x1135a14: ldr             x0, [fp, #0x10]
    // 0x1135a18: LoadField: r1 = r0->field_27
    //     0x1135a18: ldur            w1, [x0, #0x27]
    // 0x1135a1c: DecompressPointer r1
    //     0x1135a1c: add             x1, x1, HEAP, lsl #32
    // 0x1135a20: LoadField: r2 = r0->field_2b
    //     0x1135a20: ldur            w2, [x0, #0x2b]
    // 0x1135a24: DecompressPointer r2
    //     0x1135a24: add             x2, x2, HEAP, lsl #32
    // 0x1135a28: LoadField: r3 = r0->field_2f
    //     0x1135a28: ldur            w3, [x0, #0x2f]
    // 0x1135a2c: DecompressPointer r3
    //     0x1135a2c: add             x3, x3, HEAP, lsl #32
    // 0x1135a30: stp             NULL, NULL, [SP, #0x38]
    // 0x1135a34: stp             NULL, NULL, [SP, #0x28]
    // 0x1135a38: stp             NULL, NULL, [SP, #0x18]
    // 0x1135a3c: stp             x2, x1, [SP, #8]
    // 0x1135a40: str             x3, [SP]
    // 0x1135a44: r1 = Null
    //     0x1135a44: mov             x1, NULL
    // 0x1135a48: r2 = Null
    //     0x1135a48: mov             x2, NULL
    // 0x1135a4c: r4 = const [0, 0xb, 0x9, 0xb, null]
    //     0x1135a4c: add             x4, PP, #0x26, lsl #12  ; [pp+0x26280] List(5) [0, 0xb, 0x9, 0xb, Null]
    //     0x1135a50: ldr             x4, [x4, #0x280]
    // 0x1135a54: r0 = hash()
    //     0x1135a54: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1135a58: mov             x2, x0
    // 0x1135a5c: r0 = BoxInt64Instr(r2)
    //     0x1135a5c: sbfiz           x0, x2, #1, #0x1f
    //     0x1135a60: cmp             x2, x0, asr #1
    //     0x1135a64: b.eq            #0x1135a70
    //     0x1135a68: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1135a6c: stur            x2, [x0, #7]
    // 0x1135a70: LeaveFrame
    //     0x1135a70: mov             SP, fp
    //     0x1135a74: ldp             fp, lr, [SP], #0x10
    // 0x1135a78: ret
    //     0x1135a78: ret             
    // 0x1135a7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1135a7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1135a80: b               #0x1135a14
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x116a838, size: 0x130
    // 0x116a838: EnterFrame
    //     0x116a838: stp             fp, lr, [SP, #-0x10]!
    //     0x116a83c: mov             fp, SP
    // 0x116a840: AllocStack(0x28)
    //     0x116a840: sub             SP, SP, #0x28
    // 0x116a844: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0x116a844: mov             x4, x1
    //     0x116a848: mov             x0, x2
    //     0x116a84c: stur            x1, [fp, #-0x10]
    //     0x116a850: stur            x2, [fp, #-0x18]
    // 0x116a854: CheckStackOverflow
    //     0x116a854: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116a858: cmp             SP, x16
    //     0x116a85c: b.ls            #0x116a93c
    // 0x116a860: cmp             w4, w0
    // 0x116a864: b.ne            #0x116a878
    // 0x116a868: mov             x0, x4
    // 0x116a86c: LeaveFrame
    //     0x116a86c: mov             SP, fp
    //     0x116a870: ldp             fp, lr, [SP], #0x10
    // 0x116a874: ret
    //     0x116a874: ret             
    // 0x116a878: LoadField: r1 = r4->field_27
    //     0x116a878: ldur            w1, [x4, #0x27]
    // 0x116a87c: DecompressPointer r1
    //     0x116a87c: add             x1, x1, HEAP, lsl #32
    // 0x116a880: LoadField: r2 = r0->field_27
    //     0x116a880: ldur            w2, [x0, #0x27]
    // 0x116a884: DecompressPointer r2
    //     0x116a884: add             x2, x2, HEAP, lsl #32
    // 0x116a888: r5 = inline_Allocate_Double()
    //     0x116a888: ldp             x5, x3, [THR, #0x60]  ; THR::top
    //     0x116a88c: add             x5, x5, #0x10
    //     0x116a890: cmp             x3, x5
    //     0x116a894: b.ls            #0x116a944
    //     0x116a898: str             x5, [THR, #0x60]  ; THR::top
    //     0x116a89c: sub             x5, x5, #0xf
    //     0x116a8a0: mov             x3, #0xe19c
    //     0x116a8a4: movk            x3, #3, lsl #16
    //     0x116a8a8: stur            x3, [x5, #-1]
    // 0x116a8ac: dmb             ishst
    // 0x116a8b0: StoreField: r5->field_7 = d0
    //     0x116a8b0: stur            d0, [x5, #7]
    // 0x116a8b4: mov             x3, x5
    // 0x116a8b8: stur            x5, [fp, #-8]
    // 0x116a8bc: r0 = lerpDouble()
    //     0x116a8bc: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x116a8c0: mov             x4, x0
    // 0x116a8c4: ldur            x0, [fp, #-0x10]
    // 0x116a8c8: stur            x4, [fp, #-0x20]
    // 0x116a8cc: LoadField: r1 = r0->field_2b
    //     0x116a8cc: ldur            w1, [x0, #0x2b]
    // 0x116a8d0: DecompressPointer r1
    //     0x116a8d0: add             x1, x1, HEAP, lsl #32
    // 0x116a8d4: ldur            x5, [fp, #-0x18]
    // 0x116a8d8: LoadField: r2 = r5->field_2b
    //     0x116a8d8: ldur            w2, [x5, #0x2b]
    // 0x116a8dc: DecompressPointer r2
    //     0x116a8dc: add             x2, x2, HEAP, lsl #32
    // 0x116a8e0: ldur            x3, [fp, #-8]
    // 0x116a8e4: r0 = lerpDouble()
    //     0x116a8e4: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x116a8e8: mov             x4, x0
    // 0x116a8ec: ldur            x0, [fp, #-0x10]
    // 0x116a8f0: stur            x4, [fp, #-0x28]
    // 0x116a8f4: LoadField: r1 = r0->field_2f
    //     0x116a8f4: ldur            w1, [x0, #0x2f]
    // 0x116a8f8: DecompressPointer r1
    //     0x116a8f8: add             x1, x1, HEAP, lsl #32
    // 0x116a8fc: ldur            x0, [fp, #-0x18]
    // 0x116a900: LoadField: r2 = r0->field_2f
    //     0x116a900: ldur            w2, [x0, #0x2f]
    // 0x116a904: DecompressPointer r2
    //     0x116a904: add             x2, x2, HEAP, lsl #32
    // 0x116a908: ldur            x3, [fp, #-8]
    // 0x116a90c: r0 = lerpDouble()
    //     0x116a90c: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x116a910: stur            x0, [fp, #-8]
    // 0x116a914: r0 = ScrollbarThemeData()
    //     0x116a914: bl              #0x116a968  ; AllocateScrollbarThemeDataStub -> ScrollbarThemeData (size=0x34)
    // 0x116a918: ldur            x1, [fp, #-0x20]
    // 0x116a91c: StoreField: r0->field_27 = r1
    //     0x116a91c: stur            w1, [x0, #0x27]
    // 0x116a920: ldur            x1, [fp, #-0x28]
    // 0x116a924: StoreField: r0->field_2b = r1
    //     0x116a924: stur            w1, [x0, #0x2b]
    // 0x116a928: ldur            x1, [fp, #-8]
    // 0x116a92c: StoreField: r0->field_2f = r1
    //     0x116a92c: stur            w1, [x0, #0x2f]
    // 0x116a930: LeaveFrame
    //     0x116a930: mov             SP, fp
    //     0x116a934: ldp             fp, lr, [SP], #0x10
    // 0x116a938: ret
    //     0x116a938: ret             
    // 0x116a93c: r0 = StackOverflowSharedWithFPURegs()
    //     0x116a93c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x116a940: b               #0x116a860
    // 0x116a944: SaveReg d0
    //     0x116a944: str             q0, [SP, #-0x10]!
    // 0x116a948: stp             x2, x4, [SP, #-0x10]!
    // 0x116a94c: stp             x0, x1, [SP, #-0x10]!
    // 0x116a950: r0 = AllocateDouble()
    //     0x116a950: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116a954: mov             x5, x0
    // 0x116a958: ldp             x0, x1, [SP], #0x10
    // 0x116a95c: ldp             x2, x4, [SP], #0x10
    // 0x116a960: RestoreReg d0
    //     0x116a960: ldr             q0, [SP], #0x10
    // 0x116a964: b               #0x116a8b0
  }
  _ ==(/* No info */) {
    // ** addr: 0x1271718, size: 0x16c
    // 0x1271718: EnterFrame
    //     0x1271718: stp             fp, lr, [SP, #-0x10]!
    //     0x127171c: mov             fp, SP
    // 0x1271720: AllocStack(0x10)
    //     0x1271720: sub             SP, SP, #0x10
    // 0x1271724: CheckStackOverflow
    //     0x1271724: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1271728: cmp             SP, x16
    //     0x127172c: b.ls            #0x127187c
    // 0x1271730: ldr             x0, [fp, #0x10]
    // 0x1271734: cmp             w0, NULL
    // 0x1271738: b.ne            #0x127174c
    // 0x127173c: r0 = false
    //     0x127173c: add             x0, NULL, #0x30  ; false
    // 0x1271740: LeaveFrame
    //     0x1271740: mov             SP, fp
    //     0x1271744: ldp             fp, lr, [SP], #0x10
    // 0x1271748: ret
    //     0x1271748: ret             
    // 0x127174c: ldr             x1, [fp, #0x18]
    // 0x1271750: cmp             w1, w0
    // 0x1271754: b.ne            #0x1271768
    // 0x1271758: r0 = true
    //     0x1271758: add             x0, NULL, #0x20  ; true
    // 0x127175c: LeaveFrame
    //     0x127175c: mov             SP, fp
    //     0x1271760: ldp             fp, lr, [SP], #0x10
    // 0x1271764: ret
    //     0x1271764: ret             
    // 0x1271768: str             x0, [SP]
    // 0x127176c: r0 = runtimeType()
    //     0x127176c: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1271770: r1 = LoadClassIdInstr(r0)
    //     0x1271770: ldur            x1, [x0, #-1]
    //     0x1271774: ubfx            x1, x1, #0xc, #0x14
    // 0x1271778: r16 = ScrollbarThemeData
    //     0x1271778: add             x16, PP, #0x26, lsl #12  ; [pp+0x26278] Type: ScrollbarThemeData
    //     0x127177c: ldr             x16, [x16, #0x278]
    // 0x1271780: stp             x16, x0, [SP]
    // 0x1271784: mov             x0, x1
    // 0x1271788: mov             lr, x0
    // 0x127178c: ldr             lr, [x21, lr, lsl #3]
    // 0x1271790: blr             lr
    // 0x1271794: tbz             w0, #4, #0x12717a8
    // 0x1271798: r0 = false
    //     0x1271798: add             x0, NULL, #0x30  ; false
    // 0x127179c: LeaveFrame
    //     0x127179c: mov             SP, fp
    //     0x12717a0: ldp             fp, lr, [SP], #0x10
    // 0x12717a4: ret
    //     0x12717a4: ret             
    // 0x12717a8: ldr             x1, [fp, #0x10]
    // 0x12717ac: r0 = 60
    //     0x12717ac: mov             x0, #0x3c
    // 0x12717b0: branchIfSmi(r1, 0x12717bc)
    //     0x12717b0: tbz             w1, #0, #0x12717bc
    // 0x12717b4: r0 = LoadClassIdInstr(r1)
    //     0x12717b4: ldur            x0, [x1, #-1]
    //     0x12717b8: ubfx            x0, x0, #0xc, #0x14
    // 0x12717bc: r17 = 5118
    //     0x12717bc: mov             x17, #0x13fe
    // 0x12717c0: cmp             x0, x17
    // 0x12717c4: b.ne            #0x127186c
    // 0x12717c8: ldr             x2, [fp, #0x18]
    // 0x12717cc: LoadField: r0 = r1->field_27
    //     0x12717cc: ldur            w0, [x1, #0x27]
    // 0x12717d0: DecompressPointer r0
    //     0x12717d0: add             x0, x0, HEAP, lsl #32
    // 0x12717d4: LoadField: r3 = r2->field_27
    //     0x12717d4: ldur            w3, [x2, #0x27]
    // 0x12717d8: DecompressPointer r3
    //     0x12717d8: add             x3, x3, HEAP, lsl #32
    // 0x12717dc: r4 = LoadClassIdInstr(r0)
    //     0x12717dc: ldur            x4, [x0, #-1]
    //     0x12717e0: ubfx            x4, x4, #0xc, #0x14
    // 0x12717e4: stp             x3, x0, [SP]
    // 0x12717e8: mov             x0, x4
    // 0x12717ec: mov             lr, x0
    // 0x12717f0: ldr             lr, [x21, lr, lsl #3]
    // 0x12717f4: blr             lr
    // 0x12717f8: tbnz            w0, #4, #0x127186c
    // 0x12717fc: ldr             x2, [fp, #0x18]
    // 0x1271800: ldr             x1, [fp, #0x10]
    // 0x1271804: LoadField: r0 = r1->field_2b
    //     0x1271804: ldur            w0, [x1, #0x2b]
    // 0x1271808: DecompressPointer r0
    //     0x1271808: add             x0, x0, HEAP, lsl #32
    // 0x127180c: LoadField: r3 = r2->field_2b
    //     0x127180c: ldur            w3, [x2, #0x2b]
    // 0x1271810: DecompressPointer r3
    //     0x1271810: add             x3, x3, HEAP, lsl #32
    // 0x1271814: r4 = LoadClassIdInstr(r0)
    //     0x1271814: ldur            x4, [x0, #-1]
    //     0x1271818: ubfx            x4, x4, #0xc, #0x14
    // 0x127181c: stp             x3, x0, [SP]
    // 0x1271820: mov             x0, x4
    // 0x1271824: mov             lr, x0
    // 0x1271828: ldr             lr, [x21, lr, lsl #3]
    // 0x127182c: blr             lr
    // 0x1271830: tbnz            w0, #4, #0x127186c
    // 0x1271834: ldr             x1, [fp, #0x18]
    // 0x1271838: ldr             x0, [fp, #0x10]
    // 0x127183c: LoadField: r2 = r0->field_2f
    //     0x127183c: ldur            w2, [x0, #0x2f]
    // 0x1271840: DecompressPointer r2
    //     0x1271840: add             x2, x2, HEAP, lsl #32
    // 0x1271844: LoadField: r0 = r1->field_2f
    //     0x1271844: ldur            w0, [x1, #0x2f]
    // 0x1271848: DecompressPointer r0
    //     0x1271848: add             x0, x0, HEAP, lsl #32
    // 0x127184c: r1 = LoadClassIdInstr(r2)
    //     0x127184c: ldur            x1, [x2, #-1]
    //     0x1271850: ubfx            x1, x1, #0xc, #0x14
    // 0x1271854: stp             x0, x2, [SP]
    // 0x1271858: mov             x0, x1
    // 0x127185c: mov             lr, x0
    // 0x1271860: ldr             lr, [x21, lr, lsl #3]
    // 0x1271864: blr             lr
    // 0x1271868: b               #0x1271870
    // 0x127186c: r0 = false
    //     0x127186c: add             x0, NULL, #0x30  ; false
    // 0x1271870: LeaveFrame
    //     0x1271870: mov             SP, fp
    //     0x1271874: ldp             fp, lr, [SP], #0x10
    // 0x1271878: ret
    //     0x1271878: ret             
    // 0x127187c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x127187c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1271880: b               #0x1271730
  }
}

// class id: 6839, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class ScrollbarTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xeeedc0, size: 0x58
    // 0xeeedc0: EnterFrame
    //     0xeeedc0: stp             fp, lr, [SP, #-0x10]!
    //     0xeeedc4: mov             fp, SP
    // 0xeeedc8: AllocStack(0x18)
    //     0xeeedc8: sub             SP, SP, #0x18
    // 0xeeedcc: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xeeedcc: stur            x1, [fp, #-8]
    // 0xeeedd0: CheckStackOverflow
    //     0xeeedd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeeedd4: cmp             SP, x16
    //     0xeeedd8: b.ls            #0xeeee10
    // 0xeeeddc: r16 = <ScrollbarTheme>
    //     0xeeeddc: add             x16, PP, #0xab, lsl #12  ; [pp+0xab350] TypeArguments: <ScrollbarTheme>
    //     0xeeede0: ldr             x16, [x16, #0x350]
    // 0xeeede4: stp             x1, x16, [SP]
    // 0xeeede8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xeeede8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xeeedec: r0 = dependOnInheritedWidgetOfExactType()
    //     0xeeedec: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xeeedf0: ldur            x1, [fp, #-8]
    // 0xeeedf4: r0 = of()
    //     0xeeedf4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xeeedf8: LoadField: r1 = r0->field_27
    //     0xeeedf8: ldur            w1, [x0, #0x27]
    // 0xeeedfc: DecompressPointer r1
    //     0xeeedfc: add             x1, x1, HEAP, lsl #32
    // 0xeeee00: mov             x0, x1
    // 0xeeee04: LeaveFrame
    //     0xeeee04: mov             SP, fp
    //     0xeeee08: ldp             fp, lr, [SP], #0x10
    // 0xeeee0c: ret
    //     0xeeee0c: ret             
    // 0xeeee10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeeee10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeeee14: b               #0xeeeddc
  }
}
