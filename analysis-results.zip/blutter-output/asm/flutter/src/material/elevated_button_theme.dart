// lib: , url: package:flutter/src/material/elevated_button_theme.dart

// class id: 1048889, size: 0x8
class :: {
}

// class id: 5155, size: 0xc, field offset: 0x8
//   const constructor, 
class ElevatedButtonThemeData extends _MixinApplication3&Object&Diagnosticable {

  static _ lerp(/* No info */) {
    // ** addr: 0x11673ec, size: 0x6c
    // 0x11673ec: EnterFrame
    //     0x11673ec: stp             fp, lr, [SP, #-0x10]!
    //     0x11673f0: mov             fp, SP
    // 0x11673f4: AllocStack(0x8)
    //     0x11673f4: sub             SP, SP, #8
    // 0x11673f8: SetupParameters(dynamic _ /* r1 => r0 */)
    //     0x11673f8: mov             x0, x1
    // 0x11673fc: CheckStackOverflow
    //     0x11673fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1167400: cmp             SP, x16
    //     0x1167404: b.ls            #0x1167450
    // 0x1167408: cmp             w0, w2
    // 0x116740c: b.ne            #0x116741c
    // 0x1167410: LeaveFrame
    //     0x1167410: mov             SP, fp
    //     0x1167414: ldp             fp, lr, [SP], #0x10
    // 0x1167418: ret
    //     0x1167418: ret             
    // 0x116741c: LoadField: r1 = r0->field_7
    //     0x116741c: ldur            w1, [x0, #7]
    // 0x1167420: DecompressPointer r1
    //     0x1167420: add             x1, x1, HEAP, lsl #32
    // 0x1167424: LoadField: r0 = r2->field_7
    //     0x1167424: ldur            w0, [x2, #7]
    // 0x1167428: DecompressPointer r0
    //     0x1167428: add             x0, x0, HEAP, lsl #32
    // 0x116742c: mov             x2, x0
    // 0x1167430: r0 = lerp()
    //     0x1167430: bl              #0x1164644  ; [package:flutter/src/material/button_style.dart] ButtonStyle::lerp
    // 0x1167434: stur            x0, [fp, #-8]
    // 0x1167438: r0 = ElevatedButtonThemeData()
    //     0x1167438: bl              #0x1167458  ; AllocateElevatedButtonThemeDataStub -> ElevatedButtonThemeData (size=0xc)
    // 0x116743c: ldur            x1, [fp, #-8]
    // 0x1167440: StoreField: r0->field_7 = r1
    //     0x1167440: stur            w1, [x0, #7]
    // 0x1167444: LeaveFrame
    //     0x1167444: mov             SP, fp
    //     0x1167448: ldp             fp, lr, [SP], #0x10
    // 0x116744c: ret
    //     0x116744c: ret             
    // 0x1167450: r0 = StackOverflowSharedWithFPURegs()
    //     0x1167450: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1167454: b               #0x1167408
  }
  _ ==(/* No info */) {
    // ** addr: 0x126bff4, size: 0xfc
    // 0x126bff4: EnterFrame
    //     0x126bff4: stp             fp, lr, [SP, #-0x10]!
    //     0x126bff8: mov             fp, SP
    // 0x126bffc: AllocStack(0x10)
    //     0x126bffc: sub             SP, SP, #0x10
    // 0x126c000: CheckStackOverflow
    //     0x126c000: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x126c004: cmp             SP, x16
    //     0x126c008: b.ls            #0x126c0e8
    // 0x126c00c: ldr             x0, [fp, #0x10]
    // 0x126c010: cmp             w0, NULL
    // 0x126c014: b.ne            #0x126c028
    // 0x126c018: r0 = false
    //     0x126c018: add             x0, NULL, #0x30  ; false
    // 0x126c01c: LeaveFrame
    //     0x126c01c: mov             SP, fp
    //     0x126c020: ldp             fp, lr, [SP], #0x10
    // 0x126c024: ret
    //     0x126c024: ret             
    // 0x126c028: ldr             x1, [fp, #0x18]
    // 0x126c02c: cmp             w1, w0
    // 0x126c030: b.ne            #0x126c044
    // 0x126c034: r0 = true
    //     0x126c034: add             x0, NULL, #0x20  ; true
    // 0x126c038: LeaveFrame
    //     0x126c038: mov             SP, fp
    //     0x126c03c: ldp             fp, lr, [SP], #0x10
    // 0x126c040: ret
    //     0x126c040: ret             
    // 0x126c044: str             x0, [SP]
    // 0x126c048: r0 = runtimeType()
    //     0x126c048: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x126c04c: r1 = LoadClassIdInstr(r0)
    //     0x126c04c: ldur            x1, [x0, #-1]
    //     0x126c050: ubfx            x1, x1, #0xc, #0x14
    // 0x126c054: r16 = ElevatedButtonThemeData
    //     0x126c054: add             x16, PP, #0x26, lsl #12  ; [pp+0x263b0] Type: ElevatedButtonThemeData
    //     0x126c058: ldr             x16, [x16, #0x3b0]
    // 0x126c05c: stp             x16, x0, [SP]
    // 0x126c060: mov             x0, x1
    // 0x126c064: mov             lr, x0
    // 0x126c068: ldr             lr, [x21, lr, lsl #3]
    // 0x126c06c: blr             lr
    // 0x126c070: tbz             w0, #4, #0x126c084
    // 0x126c074: r0 = false
    //     0x126c074: add             x0, NULL, #0x30  ; false
    // 0x126c078: LeaveFrame
    //     0x126c078: mov             SP, fp
    //     0x126c07c: ldp             fp, lr, [SP], #0x10
    // 0x126c080: ret
    //     0x126c080: ret             
    // 0x126c084: ldr             x0, [fp, #0x10]
    // 0x126c088: r1 = 60
    //     0x126c088: mov             x1, #0x3c
    // 0x126c08c: branchIfSmi(r0, 0x126c098)
    //     0x126c08c: tbz             w0, #0, #0x126c098
    // 0x126c090: r1 = LoadClassIdInstr(r0)
    //     0x126c090: ldur            x1, [x0, #-1]
    //     0x126c094: ubfx            x1, x1, #0xc, #0x14
    // 0x126c098: r17 = 5155
    //     0x126c098: mov             x17, #0x1423
    // 0x126c09c: cmp             x1, x17
    // 0x126c0a0: b.ne            #0x126c0d8
    // 0x126c0a4: ldr             x1, [fp, #0x18]
    // 0x126c0a8: LoadField: r2 = r0->field_7
    //     0x126c0a8: ldur            w2, [x0, #7]
    // 0x126c0ac: DecompressPointer r2
    //     0x126c0ac: add             x2, x2, HEAP, lsl #32
    // 0x126c0b0: LoadField: r0 = r1->field_7
    //     0x126c0b0: ldur            w0, [x1, #7]
    // 0x126c0b4: DecompressPointer r0
    //     0x126c0b4: add             x0, x0, HEAP, lsl #32
    // 0x126c0b8: r1 = LoadClassIdInstr(r2)
    //     0x126c0b8: ldur            x1, [x2, #-1]
    //     0x126c0bc: ubfx            x1, x1, #0xc, #0x14
    // 0x126c0c0: stp             x0, x2, [SP]
    // 0x126c0c4: mov             x0, x1
    // 0x126c0c8: mov             lr, x0
    // 0x126c0cc: ldr             lr, [x21, lr, lsl #3]
    // 0x126c0d0: blr             lr
    // 0x126c0d4: b               #0x126c0dc
    // 0x126c0d8: r0 = false
    //     0x126c0d8: add             x0, NULL, #0x30  ; false
    // 0x126c0dc: LeaveFrame
    //     0x126c0dc: mov             SP, fp
    //     0x126c0e0: ldp             fp, lr, [SP], #0x10
    // 0x126c0e4: ret
    //     0x126c0e4: ret             
    // 0x126c0e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x126c0e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x126c0ec: b               #0x126c00c
  }
}

// class id: 6847, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class ElevatedButtonTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xfba2ec, size: 0x58
    // 0xfba2ec: EnterFrame
    //     0xfba2ec: stp             fp, lr, [SP, #-0x10]!
    //     0xfba2f0: mov             fp, SP
    // 0xfba2f4: AllocStack(0x18)
    //     0xfba2f4: sub             SP, SP, #0x18
    // 0xfba2f8: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xfba2f8: stur            x1, [fp, #-8]
    // 0xfba2fc: CheckStackOverflow
    //     0xfba2fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfba300: cmp             SP, x16
    //     0xfba304: b.ls            #0xfba33c
    // 0xfba308: r16 = <ElevatedButtonTheme>
    //     0xfba308: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c968] TypeArguments: <ElevatedButtonTheme>
    //     0xfba30c: ldr             x16, [x16, #0x968]
    // 0xfba310: stp             x1, x16, [SP]
    // 0xfba314: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xfba314: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xfba318: r0 = dependOnInheritedWidgetOfExactType()
    //     0xfba318: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xfba31c: ldur            x1, [fp, #-8]
    // 0xfba320: r0 = of()
    //     0xfba320: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfba324: LoadField: r1 = r0->field_d7
    //     0xfba324: ldur            w1, [x0, #0xd7]
    // 0xfba328: DecompressPointer r1
    //     0xfba328: add             x1, x1, HEAP, lsl #32
    // 0xfba32c: mov             x0, x1
    // 0xfba330: LeaveFrame
    //     0xfba330: mov             SP, fp
    //     0xfba334: ldp             fp, lr, [SP], #0x10
    // 0xfba338: ret
    //     0xfba338: ret             
    // 0xfba33c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfba33c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfba340: b               #0xfba308
  }
}
