// lib: , url: package:flutter/src/material/app_bar.dart

// class id: 1048843, size: 0x8
class :: {
}

// class id: 3134, size: 0x14, field offset: 0xc
//   const constructor, 
class _ToolbarContainerLayout extends SingleChildLayoutDelegate {

  _ getSize(/* No info */) {
    // ** addr: 0x112e2fc, size: 0x3c
    // 0x112e2fc: EnterFrame
    //     0x112e2fc: stp             fp, lr, [SP, #-0x10]!
    //     0x112e300: mov             fp, SP
    // 0x112e304: AllocStack(0x10)
    //     0x112e304: sub             SP, SP, #0x10
    // 0x112e308: LoadField: d0 = r2->field_f
    //     0x112e308: ldur            d0, [x2, #0xf]
    // 0x112e30c: stur            d0, [fp, #-0x10]
    // 0x112e310: LoadField: d1 = r1->field_b
    //     0x112e310: ldur            d1, [x1, #0xb]
    // 0x112e314: stur            d1, [fp, #-8]
    // 0x112e318: r0 = Size()
    //     0x112e318: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x112e31c: ldur            d0, [fp, #-0x10]
    // 0x112e320: StoreField: r0->field_7 = d0
    //     0x112e320: stur            d0, [x0, #7]
    // 0x112e324: ldur            d0, [fp, #-8]
    // 0x112e328: StoreField: r0->field_f = d0
    //     0x112e328: stur            d0, [x0, #0xf]
    // 0x112e32c: LeaveFrame
    //     0x112e32c: mov             SP, fp
    //     0x112e330: ldp             fp, lr, [SP], #0x10
    // 0x112e334: ret
    //     0x112e334: ret             
  }
  _ shouldRelayout(/* No info */) {
    // ** addr: 0x1141ecc, size: 0x80
    // 0x1141ecc: EnterFrame
    //     0x1141ecc: stp             fp, lr, [SP, #-0x10]!
    //     0x1141ed0: mov             fp, SP
    // 0x1141ed4: AllocStack(0x10)
    //     0x1141ed4: sub             SP, SP, #0x10
    // 0x1141ed8: SetupParameters(_ToolbarContainerLayout this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x1141ed8: mov             x0, x2
    //     0x1141edc: mov             x4, x1
    //     0x1141ee0: mov             x3, x2
    //     0x1141ee4: stur            x1, [fp, #-8]
    //     0x1141ee8: stur            x2, [fp, #-0x10]
    // 0x1141eec: r2 = Null
    //     0x1141eec: mov             x2, NULL
    // 0x1141ef0: r1 = Null
    //     0x1141ef0: mov             x1, NULL
    // 0x1141ef4: r4 = 60
    //     0x1141ef4: mov             x4, #0x3c
    // 0x1141ef8: branchIfSmi(r0, 0x1141f04)
    //     0x1141ef8: tbz             w0, #0, #0x1141f04
    // 0x1141efc: r4 = LoadClassIdInstr(r0)
    //     0x1141efc: ldur            x4, [x0, #-1]
    //     0x1141f00: ubfx            x4, x4, #0xc, #0x14
    // 0x1141f04: cmp             x4, #0xc3e
    // 0x1141f08: b.eq            #0x1141f20
    // 0x1141f0c: r8 = _ToolbarContainerLayout
    //     0x1141f0c: add             x8, PP, #0xa4, lsl #12  ; [pp+0xa4490] Type: _ToolbarContainerLayout
    //     0x1141f10: ldr             x8, [x8, #0x490]
    // 0x1141f14: r3 = Null
    //     0x1141f14: add             x3, PP, #0xa4, lsl #12  ; [pp+0xa4498] Null
    //     0x1141f18: ldr             x3, [x3, #0x498]
    // 0x1141f1c: r0 = DefaultTypeTest()
    //     0x1141f1c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x1141f20: ldur            x1, [fp, #-8]
    // 0x1141f24: LoadField: d0 = r1->field_b
    //     0x1141f24: ldur            d0, [x1, #0xb]
    // 0x1141f28: ldur            x1, [fp, #-0x10]
    // 0x1141f2c: LoadField: d1 = r1->field_b
    //     0x1141f2c: ldur            d1, [x1, #0xb]
    // 0x1141f30: fcmp            d0, d1
    // 0x1141f34: r16 = true
    //     0x1141f34: add             x16, NULL, #0x20  ; true
    // 0x1141f38: r17 = false
    //     0x1141f38: add             x17, NULL, #0x30  ; false
    // 0x1141f3c: csel            x0, x16, x17, ne
    // 0x1141f40: LeaveFrame
    //     0x1141f40: mov             SP, fp
    //     0x1141f44: ldp             fp, lr, [SP], #0x10
    // 0x1141f48: ret
    //     0x1141f48: ret             
  }
  _ getConstraintsForChild(/* No info */) {
    // ** addr: 0x12dc920, size: 0x8c
    // 0x12dc920: EnterFrame
    //     0x12dc920: stp             fp, lr, [SP, #-0x10]!
    //     0x12dc924: mov             fp, SP
    // 0x12dc928: AllocStack(0x8)
    //     0x12dc928: sub             SP, SP, #8
    // 0x12dc92c: SetupParameters(_ToolbarContainerLayout this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x12dc92c: mov             x0, x1
    //     0x12dc930: mov             x1, x2
    // 0x12dc934: CheckStackOverflow
    //     0x12dc934: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12dc938: cmp             SP, x16
    //     0x12dc93c: b.ls            #0x12dc98c
    // 0x12dc940: LoadField: d0 = r0->field_b
    //     0x12dc940: ldur            d0, [x0, #0xb]
    // 0x12dc944: r0 = inline_Allocate_Double()
    //     0x12dc944: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x12dc948: add             x0, x0, #0x10
    //     0x12dc94c: cmp             x2, x0
    //     0x12dc950: b.ls            #0x12dc994
    //     0x12dc954: str             x0, [THR, #0x60]  ; THR::top
    //     0x12dc958: sub             x0, x0, #0xf
    //     0x12dc95c: mov             x2, #0xe19c
    //     0x12dc960: movk            x2, #3, lsl #16
    //     0x12dc964: stur            x2, [x0, #-1]
    // 0x12dc968: dmb             ishst
    // 0x12dc96c: StoreField: r0->field_7 = d0
    //     0x12dc96c: stur            d0, [x0, #7]
    // 0x12dc970: str             x0, [SP]
    // 0x12dc974: r4 = const [0, 0x2, 0x1, 0x1, height, 0x1, null]
    //     0x12dc974: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f1a0] List(7) [0, 0x2, 0x1, 0x1, "height", 0x1, Null]
    //     0x12dc978: ldr             x4, [x4, #0x1a0]
    // 0x12dc97c: r0 = tighten()
    //     0x12dc97c: bl              #0xb4aa24  ; [package:flutter/src/rendering/box.dart] BoxConstraints::tighten
    // 0x12dc980: LeaveFrame
    //     0x12dc980: mov             SP, fp
    //     0x12dc984: ldp             fp, lr, [SP], #0x10
    // 0x12dc988: ret
    //     0x12dc988: ret             
    // 0x12dc98c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12dc98c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12dc990: b               #0x12dc940
    // 0x12dc994: SaveReg d0
    //     0x12dc994: str             q0, [SP, #-0x10]!
    // 0x12dc998: SaveReg r1
    //     0x12dc998: str             x1, [SP, #-8]!
    // 0x12dc99c: r0 = AllocateDouble()
    //     0x12dc99c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12dc9a0: RestoreReg r1
    //     0x12dc9a0: ldr             x1, [SP], #8
    // 0x12dc9a4: RestoreReg d0
    //     0x12dc9a4: ldr             q0, [SP], #0x10
    // 0x12dc9a8: b               #0x12dc96c
  }
  _ getPositionForChild(/* No info */) {
    // ** addr: 0x12e433c, size: 0x38
    // 0x12e433c: EnterFrame
    //     0x12e433c: stp             fp, lr, [SP, #-0x10]!
    //     0x12e4340: mov             fp, SP
    // 0x12e4344: AllocStack(0x8)
    //     0x12e4344: sub             SP, SP, #8
    // 0x12e4348: LoadField: d0 = r2->field_f
    //     0x12e4348: ldur            d0, [x2, #0xf]
    // 0x12e434c: LoadField: d1 = r3->field_f
    //     0x12e434c: ldur            d1, [x3, #0xf]
    // 0x12e4350: fsub            d2, d0, d1
    // 0x12e4354: stur            d2, [fp, #-8]
    // 0x12e4358: r0 = Offset()
    //     0x12e4358: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12e435c: StoreField: r0->field_7 = rZR
    //     0x12e435c: stur            xzr, [x0, #7]
    // 0x12e4360: ldur            d0, [fp, #-8]
    // 0x12e4364: StoreField: r0->field_f = d0
    //     0x12e4364: stur            d0, [x0, #0xf]
    // 0x12e4368: LeaveFrame
    //     0x12e4368: mov             SP, fp
    //     0x12e436c: ldp             fp, lr, [SP], #0x10
    // 0x12e4370: ret
    //     0x12e4370: ret             
  }
}

// class id: 3803, size: 0x20, field offset: 0x18
class _PreferredAppBarSize extends Size {

  _ _PreferredAppBarSize(/* No info */) {
    // ** addr: 0xd4c894, size: 0x98
    // 0xd4c894: EnterFrame
    //     0xd4c894: stp             fp, lr, [SP, #-0x10]!
    //     0xd4c898: mov             fp, SP
    // 0xd4c89c: AllocStack(0x18)
    //     0xd4c89c: sub             SP, SP, #0x18
    // 0xd4c8a0: SetupParameters(_PreferredAppBarSize this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xd4c8a0: stur            x1, [fp, #-8]
    //     0xd4c8a4: mov             x16, x2
    //     0xd4c8a8: mov             x2, x1
    //     0xd4c8ac: mov             x1, x16
    // 0xd4c8b0: CheckStackOverflow
    //     0xd4c8b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4c8b4: cmp             SP, x16
    //     0xd4c8b8: b.ls            #0xd4c924
    // 0xd4c8bc: mov             x0, x1
    // 0xd4c8c0: StoreField: r2->field_1b = r0
    //     0xd4c8c0: stur            w0, [x2, #0x1b]
    //     0xd4c8c4: ldurb           w16, [x2, #-1]
    //     0xd4c8c8: ldurb           w17, [x0, #-1]
    //     0xd4c8cc: and             x16, x17, x16, lsr #2
    //     0xd4c8d0: tst             x16, HEAP, lsr #32
    //     0xd4c8d4: b.eq            #0xd4c8dc
    //     0xd4c8d8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd4c8dc: cmp             w1, NULL
    // 0xd4c8e0: b.ne            #0xd4c8ec
    // 0xd4c8e4: r0 = 0
    //     0xd4c8e4: mov             x0, #0
    // 0xd4c8e8: b               #0xd4c8f0
    // 0xd4c8ec: mov             x0, x1
    // 0xd4c8f0: r16 = 56.000000
    //     0xd4c8f0: add             x16, PP, #0x18, lsl #12  ; [pp+0x180d0] 56
    //     0xd4c8f4: ldr             x16, [x16, #0xd0]
    // 0xd4c8f8: stp             x0, x16, [SP]
    // 0xd4c8fc: r0 = +()
    //     0xd4c8fc: bl              #0x13dce50  ; [dart:core] _Double::+
    // 0xd4c900: ldur            x1, [fp, #-8]
    // 0xd4c904: d0 = inf
    //     0xd4c904: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xd4c908: StoreField: r1->field_7 = d0
    //     0xd4c908: stur            d0, [x1, #7]
    // 0xd4c90c: LoadField: d0 = r0->field_7
    //     0xd4c90c: ldur            d0, [x0, #7]
    // 0xd4c910: StoreField: r1->field_f = d0
    //     0xd4c910: stur            d0, [x1, #0xf]
    // 0xd4c914: r0 = Null
    //     0xd4c914: mov             x0, NULL
    // 0xd4c918: LeaveFrame
    //     0xd4c918: mov             SP, fp
    //     0xd4c91c: ldp             fp, lr, [SP], #0x10
    // 0xd4c920: ret
    //     0xd4c920: ret             
    // 0xd4c924: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4c924: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4c928: b               #0xd4c8bc
  }
}

// class id: 4889, size: 0x60, field offset: 0x60
class _RenderAppBarTitleBox extends RenderAligningShiftedBox {

  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4cf58, size: 0x90
    // 0xb4cf58: EnterFrame
    //     0xb4cf58: stp             fp, lr, [SP, #-0x10]!
    //     0xb4cf5c: mov             fp, SP
    // 0xb4cf60: AllocStack(0x18)
    //     0xb4cf60: sub             SP, SP, #0x18
    // 0xb4cf64: SetupParameters(_RenderAppBarTitleBox this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb4cf64: mov             x0, x2
    //     0xb4cf68: stur            x2, [fp, #-0x10]
    //     0xb4cf6c: mov             x2, x1
    //     0xb4cf70: stur            x1, [fp, #-8]
    // 0xb4cf74: CheckStackOverflow
    //     0xb4cf74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4cf78: cmp             SP, x16
    //     0xb4cf7c: b.ls            #0xb4cfdc
    // 0xb4cf80: r16 = inf
    //     0xb4cf80: add             x16, PP, #0x15, lsl #12  ; [pp+0x158a8] inf
    //     0xb4cf84: ldr             x16, [x16, #0x8a8]
    // 0xb4cf88: str             x16, [SP]
    // 0xb4cf8c: mov             x1, x0
    // 0xb4cf90: r4 = const [0, 0x2, 0x1, 0x1, maxHeight, 0x1, null]
    //     0xb4cf90: add             x4, PP, #0xa1, lsl #12  ; [pp+0xa1e80] List(7) [0, 0x2, 0x1, 0x1, "maxHeight", 0x1, Null]
    //     0xb4cf94: ldr             x4, [x4, #0xe80]
    // 0xb4cf98: r0 = copyWith()
    //     0xb4cf98: bl              #0xb4cfe8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::copyWith
    // 0xb4cf9c: mov             x1, x0
    // 0xb4cfa0: ldur            x0, [fp, #-8]
    // 0xb4cfa4: LoadField: r2 = r0->field_4f
    //     0xb4cfa4: ldur            w2, [x0, #0x4f]
    // 0xb4cfa8: DecompressPointer r2
    //     0xb4cfa8: add             x2, x2, HEAP, lsl #32
    // 0xb4cfac: cmp             w2, NULL
    // 0xb4cfb0: b.eq            #0xb4cfe4
    // 0xb4cfb4: mov             x16, x1
    // 0xb4cfb8: mov             x1, x2
    // 0xb4cfbc: mov             x2, x16
    // 0xb4cfc0: r0 = getDryLayout()
    //     0xb4cfc0: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb4cfc4: ldur            x1, [fp, #-0x10]
    // 0xb4cfc8: mov             x2, x0
    // 0xb4cfcc: r0 = constrain()
    //     0xb4cfcc: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb4cfd0: LeaveFrame
    //     0xb4cfd0: mov             SP, fp
    //     0xb4cfd4: ldp             fp, lr, [SP], #0x10
    // 0xb4cfd8: ret
    //     0xb4cfd8: ret             
    // 0xb4cfdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4cfdc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4cfe0: b               #0xb4cf80
    // 0xb4cfe4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb4cfe4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb5ff80, size: 0x17c
    // 0xb5ff80: EnterFrame
    //     0xb5ff80: stp             fp, lr, [SP, #-0x10]!
    //     0xb5ff84: mov             fp, SP
    // 0xb5ff88: AllocStack(0x30)
    //     0xb5ff88: sub             SP, SP, #0x30
    // 0xb5ff8c: SetupParameters(_RenderAppBarTitleBox this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb5ff8c: mov             x5, x1
    //     0xb5ff90: mov             x4, x2
    //     0xb5ff94: stur            x1, [fp, #-8]
    //     0xb5ff98: stur            x2, [fp, #-0x10]
    //     0xb5ff9c: stur            x3, [fp, #-0x18]
    // 0xb5ffa0: CheckStackOverflow
    //     0xb5ffa0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5ffa4: cmp             SP, x16
    //     0xb5ffa8: b.ls            #0xb600e4
    // 0xb5ffac: mov             x0, x4
    // 0xb5ffb0: r2 = Null
    //     0xb5ffb0: mov             x2, NULL
    // 0xb5ffb4: r1 = Null
    //     0xb5ffb4: mov             x1, NULL
    // 0xb5ffb8: r4 = 60
    //     0xb5ffb8: mov             x4, #0x3c
    // 0xb5ffbc: branchIfSmi(r0, 0xb5ffc8)
    //     0xb5ffbc: tbz             w0, #0, #0xb5ffc8
    // 0xb5ffc0: r4 = LoadClassIdInstr(r0)
    //     0xb5ffc0: ldur            x4, [x0, #-1]
    //     0xb5ffc4: ubfx            x4, x4, #0xc, #0x14
    // 0xb5ffc8: sub             x4, x4, #0xb46
    // 0xb5ffcc: cmp             x4, #1
    // 0xb5ffd0: b.ls            #0xb5ffe4
    // 0xb5ffd4: r8 = BoxConstraints
    //     0xb5ffd4: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb5ffd8: r3 = Null
    //     0xb5ffd8: add             x3, PP, #0xa4, lsl #12  ; [pp+0xa4480] Null
    //     0xb5ffdc: ldr             x3, [x3, #0x480]
    // 0xb5ffe0: r0 = BoxConstraints()
    //     0xb5ffe0: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb5ffe4: r16 = inf
    //     0xb5ffe4: add             x16, PP, #0x15, lsl #12  ; [pp+0x158a8] inf
    //     0xb5ffe8: ldr             x16, [x16, #0x8a8]
    // 0xb5ffec: str             x16, [SP]
    // 0xb5fff0: ldur            x1, [fp, #-0x10]
    // 0xb5fff4: r4 = const [0, 0x2, 0x1, 0x1, maxHeight, 0x1, null]
    //     0xb5fff4: add             x4, PP, #0xa1, lsl #12  ; [pp+0xa1e80] List(7) [0, 0x2, 0x1, 0x1, "maxHeight", 0x1, Null]
    //     0xb5fff8: ldr             x4, [x4, #0xe80]
    // 0xb5fffc: r0 = copyWith()
    //     0xb5fffc: bl              #0xb4cfe8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::copyWith
    // 0xb60000: mov             x4, x0
    // 0xb60004: ldur            x0, [fp, #-8]
    // 0xb60008: stur            x4, [fp, #-0x28]
    // 0xb6000c: LoadField: r5 = r0->field_4f
    //     0xb6000c: ldur            w5, [x0, #0x4f]
    // 0xb60010: DecompressPointer r5
    //     0xb60010: add             x5, x5, HEAP, lsl #32
    // 0xb60014: stur            x5, [fp, #-0x20]
    // 0xb60018: cmp             w5, NULL
    // 0xb6001c: b.ne            #0xb60030
    // 0xb60020: r0 = Null
    //     0xb60020: mov             x0, NULL
    // 0xb60024: LeaveFrame
    //     0xb60024: mov             SP, fp
    //     0xb60028: ldp             fp, lr, [SP], #0x10
    // 0xb6002c: ret
    //     0xb6002c: ret             
    // 0xb60030: mov             x1, x5
    // 0xb60034: mov             x2, x4
    // 0xb60038: ldur            x3, [fp, #-0x18]
    // 0xb6003c: r0 = getDryBaseline()
    //     0xb6003c: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb60040: stur            x0, [fp, #-0x18]
    // 0xb60044: cmp             w0, NULL
    // 0xb60048: b.ne            #0xb6005c
    // 0xb6004c: r0 = Null
    //     0xb6004c: mov             x0, NULL
    // 0xb60050: LeaveFrame
    //     0xb60050: mov             SP, fp
    //     0xb60054: ldp             fp, lr, [SP], #0x10
    // 0xb60058: ret
    //     0xb60058: ret             
    // 0xb6005c: ldur            x1, [fp, #-0x20]
    // 0xb60060: ldur            x2, [fp, #-0x28]
    // 0xb60064: r0 = getDryLayout()
    //     0xb60064: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb60068: ldur            x1, [fp, #-8]
    // 0xb6006c: stur            x0, [fp, #-0x20]
    // 0xb60070: r0 = resolvedAlignment()
    //     0xb60070: bl              #0xb5fd7c  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::resolvedAlignment
    // 0xb60074: ldur            x1, [fp, #-8]
    // 0xb60078: ldur            x2, [fp, #-0x10]
    // 0xb6007c: stur            x0, [fp, #-8]
    // 0xb60080: r0 = getDryLayout()
    //     0xb60080: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb60084: mov             x1, x0
    // 0xb60088: ldur            x2, [fp, #-0x20]
    // 0xb6008c: r0 = -()
    //     0xb6008c: bl              #0x81d2c0  ; [dart:ui] Size::-
    // 0xb60090: ldur            x1, [fp, #-8]
    // 0xb60094: mov             x2, x0
    // 0xb60098: r0 = alongOffset()
    //     0xb60098: bl              #0xb5f054  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0xb6009c: LoadField: d0 = r0->field_f
    //     0xb6009c: ldur            d0, [x0, #0xf]
    // 0xb600a0: ldur            x1, [fp, #-0x18]
    // 0xb600a4: LoadField: d1 = r1->field_7
    //     0xb600a4: ldur            d1, [x1, #7]
    // 0xb600a8: fadd            d2, d1, d0
    // 0xb600ac: r0 = inline_Allocate_Double()
    //     0xb600ac: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb600b0: add             x0, x0, #0x10
    //     0xb600b4: cmp             x1, x0
    //     0xb600b8: b.ls            #0xb600ec
    //     0xb600bc: str             x0, [THR, #0x60]  ; THR::top
    //     0xb600c0: sub             x0, x0, #0xf
    //     0xb600c4: mov             x1, #0xe19c
    //     0xb600c8: movk            x1, #3, lsl #16
    //     0xb600cc: stur            x1, [x0, #-1]
    // 0xb600d0: dmb             ishst
    // 0xb600d4: StoreField: r0->field_7 = d2
    //     0xb600d4: stur            d2, [x0, #7]
    // 0xb600d8: LeaveFrame
    //     0xb600d8: mov             SP, fp
    //     0xb600dc: ldp             fp, lr, [SP], #0x10
    // 0xb600e0: ret
    //     0xb600e0: ret             
    // 0xb600e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb600e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb600e8: b               #0xb5ffac
    // 0xb600ec: SaveReg d2
    //     0xb600ec: str             q2, [SP, #-0x10]!
    // 0xb600f0: r0 = AllocateDouble()
    //     0xb600f0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb600f4: RestoreReg d2
    //     0xb600f4: ldr             q2, [SP], #0x10
    // 0xb600f8: b               #0xb600d4
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbbae5c, size: 0x1b4
    // 0xbbae5c: EnterFrame
    //     0xbbae5c: stp             fp, lr, [SP, #-0x10]!
    //     0xbbae60: mov             fp, SP
    // 0xbbae64: AllocStack(0x18)
    //     0xbbae64: sub             SP, SP, #0x18
    // 0xbbae68: SetupParameters(_RenderAppBarTitleBox this /* r1 => r3, fp-0x10 */)
    //     0xbbae68: mov             x3, x1
    //     0xbbae6c: stur            x1, [fp, #-0x10]
    // 0xbbae70: CheckStackOverflow
    //     0xbbae70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbae74: cmp             SP, x16
    //     0xbbae78: b.ls            #0xbbb000
    // 0xbbae7c: LoadField: r4 = r3->field_27
    //     0xbbae7c: ldur            w4, [x3, #0x27]
    // 0xbbae80: DecompressPointer r4
    //     0xbbae80: add             x4, x4, HEAP, lsl #32
    // 0xbbae84: stur            x4, [fp, #-8]
    // 0xbbae88: cmp             w4, NULL
    // 0xbbae8c: b.eq            #0xbbafc4
    // 0xbbae90: mov             x0, x4
    // 0xbbae94: r2 = Null
    //     0xbbae94: mov             x2, NULL
    // 0xbbae98: r1 = Null
    //     0xbbae98: mov             x1, NULL
    // 0xbbae9c: r4 = LoadClassIdInstr(r0)
    //     0xbbae9c: ldur            x4, [x0, #-1]
    //     0xbbaea0: ubfx            x4, x4, #0xc, #0x14
    // 0xbbaea4: sub             x4, x4, #0xb46
    // 0xbbaea8: cmp             x4, #1
    // 0xbbaeac: b.ls            #0xbbaec0
    // 0xbbaeb0: r8 = BoxConstraints
    //     0xbbaeb0: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbaeb4: r3 = Null
    //     0xbbaeb4: add             x3, PP, #0xa4, lsl #12  ; [pp+0xa4460] Null
    //     0xbbaeb8: ldr             x3, [x3, #0x460]
    // 0xbbaebc: r0 = BoxConstraints()
    //     0xbbaebc: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbaec0: r16 = inf
    //     0xbbaec0: add             x16, PP, #0x15, lsl #12  ; [pp+0x158a8] inf
    //     0xbbaec4: ldr             x16, [x16, #0x8a8]
    // 0xbbaec8: str             x16, [SP]
    // 0xbbaecc: ldur            x1, [fp, #-8]
    // 0xbbaed0: r4 = const [0, 0x2, 0x1, 0x1, maxHeight, 0x1, null]
    //     0xbbaed0: add             x4, PP, #0xa1, lsl #12  ; [pp+0xa1e80] List(7) [0, 0x2, 0x1, 0x1, "maxHeight", 0x1, Null]
    //     0xbbaed4: ldr             x4, [x4, #0xe80]
    // 0xbbaed8: r0 = copyWith()
    //     0xbbaed8: bl              #0xb4cfe8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::copyWith
    // 0xbbaedc: ldur            x3, [fp, #-0x10]
    // 0xbbaee0: LoadField: r1 = r3->field_4f
    //     0xbbaee0: ldur            w1, [x3, #0x4f]
    // 0xbbaee4: DecompressPointer r1
    //     0xbbaee4: add             x1, x1, HEAP, lsl #32
    // 0xbbaee8: cmp             w1, NULL
    // 0xbbaeec: b.eq            #0xbbb008
    // 0xbbaef0: r2 = LoadClassIdInstr(r1)
    //     0xbbaef0: ldur            x2, [x1, #-1]
    //     0xbbaef4: ubfx            x2, x2, #0xc, #0x14
    // 0xbbaef8: r16 = true
    //     0xbbaef8: add             x16, NULL, #0x20  ; true
    // 0xbbaefc: str             x16, [SP]
    // 0xbbaf00: mov             x16, x0
    // 0xbbaf04: mov             x0, x2
    // 0xbbaf08: mov             x2, x16
    // 0xbbaf0c: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbbaf0c: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbbaf10: ldr             x4, [x4, #0xed0]
    // 0xbbaf14: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbbaf14: mov             x17, #0xe6b9
    //     0xbbaf18: add             lr, x0, x17
    //     0xbbaf1c: ldr             lr, [x21, lr, lsl #3]
    //     0xbbaf20: blr             lr
    // 0xbbaf24: ldur            x3, [fp, #-0x10]
    // 0xbbaf28: LoadField: r4 = r3->field_27
    //     0xbbaf28: ldur            w4, [x3, #0x27]
    // 0xbbaf2c: DecompressPointer r4
    //     0xbbaf2c: add             x4, x4, HEAP, lsl #32
    // 0xbbaf30: stur            x4, [fp, #-8]
    // 0xbbaf34: cmp             w4, NULL
    // 0xbbaf38: b.eq            #0xbbafe0
    // 0xbbaf3c: mov             x0, x4
    // 0xbbaf40: r2 = Null
    //     0xbbaf40: mov             x2, NULL
    // 0xbbaf44: r1 = Null
    //     0xbbaf44: mov             x1, NULL
    // 0xbbaf48: r4 = LoadClassIdInstr(r0)
    //     0xbbaf48: ldur            x4, [x0, #-1]
    //     0xbbaf4c: ubfx            x4, x4, #0xc, #0x14
    // 0xbbaf50: sub             x4, x4, #0xb46
    // 0xbbaf54: cmp             x4, #1
    // 0xbbaf58: b.ls            #0xbbaf6c
    // 0xbbaf5c: r8 = BoxConstraints
    //     0xbbaf5c: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbaf60: r3 = Null
    //     0xbbaf60: add             x3, PP, #0xa4, lsl #12  ; [pp+0xa4470] Null
    //     0xbbaf64: ldr             x3, [x3, #0x470]
    // 0xbbaf68: r0 = BoxConstraints()
    //     0xbbaf68: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbaf6c: ldur            x0, [fp, #-0x10]
    // 0xbbaf70: LoadField: r1 = r0->field_4f
    //     0xbbaf70: ldur            w1, [x0, #0x4f]
    // 0xbbaf74: DecompressPointer r1
    //     0xbbaf74: add             x1, x1, HEAP, lsl #32
    // 0xbbaf78: cmp             w1, NULL
    // 0xbbaf7c: b.eq            #0xbbb00c
    // 0xbbaf80: r0 = size()
    //     0xbbaf80: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbaf84: ldur            x1, [fp, #-8]
    // 0xbbaf88: mov             x2, x0
    // 0xbbaf8c: r0 = constrain()
    //     0xbbaf8c: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbbaf90: ldur            x1, [fp, #-0x10]
    // 0xbbaf94: StoreField: r1->field_4b = r0
    //     0xbbaf94: stur            w0, [x1, #0x4b]
    //     0xbbaf98: ldurb           w16, [x1, #-1]
    //     0xbbaf9c: ldurb           w17, [x0, #-1]
    //     0xbbafa0: and             x16, x17, x16, lsr #2
    //     0xbbafa4: tst             x16, HEAP, lsr #32
    //     0xbbafa8: b.eq            #0xbbafb0
    //     0xbbafac: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbafb0: r0 = alignChild()
    //     0xbbafb0: bl              #0xbbad50  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::alignChild
    // 0xbbafb4: r0 = Null
    //     0xbbafb4: mov             x0, NULL
    // 0xbbafb8: LeaveFrame
    //     0xbbafb8: mov             SP, fp
    //     0xbbafbc: ldp             fp, lr, [SP], #0x10
    // 0xbbafc0: ret
    //     0xbbafc0: ret             
    // 0xbbafc4: r0 = StateError()
    //     0xbbafc4: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbafc8: mov             x1, x0
    // 0xbbafcc: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbafcc: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbafd0: StoreField: r1->field_b = r0
    //     0xbbafd0: stur            w0, [x1, #0xb]
    // 0xbbafd4: mov             x0, x1
    // 0xbbafd8: r0 = Throw()
    //     0xbbafd8: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbafdc: brk             #0
    // 0xbbafe0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbafe0: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbafe4: r0 = StateError()
    //     0xbbafe4: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbafe8: mov             x1, x0
    // 0xbbafec: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbafec: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbaff0: StoreField: r1->field_b = r0
    //     0xbbaff0: stur            w0, [x1, #0xb]
    // 0xbbaff4: mov             x0, x1
    // 0xbbaff8: r0 = Throw()
    //     0xbbaff8: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbaffc: brk             #0
    // 0xbbb000: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbb000: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbb004: b               #0xbbae7c
    // 0xbbb008: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbb008: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbb00c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbb00c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _RenderAppBarTitleBox(/* No info */) {
    // ** addr: 0x11cf6bc, size: 0xa4
    // 0x11cf6bc: EnterFrame
    //     0x11cf6bc: stp             fp, lr, [SP, #-0x10]!
    //     0x11cf6c0: mov             fp, SP
    // 0x11cf6c4: AllocStack(0x8)
    //     0x11cf6c4: sub             SP, SP, #8
    // 0x11cf6c8: r0 = Instance_Alignment
    //     0x11cf6c8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0x11cf6cc: ldr             x0, [x0, #0xb80]
    // 0x11cf6d0: stur            x1, [fp, #-8]
    // 0x11cf6d4: mov             x16, x2
    // 0x11cf6d8: mov             x2, x1
    // 0x11cf6dc: mov             x1, x16
    // 0x11cf6e0: CheckStackOverflow
    //     0x11cf6e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cf6e4: cmp             SP, x16
    //     0x11cf6e8: b.ls            #0x11cf758
    // 0x11cf6ec: StoreField: r2->field_57 = r0
    //     0x11cf6ec: stur            w0, [x2, #0x57]
    // 0x11cf6f0: mov             x0, x1
    // 0x11cf6f4: StoreField: r2->field_5b = r0
    //     0x11cf6f4: stur            w0, [x2, #0x5b]
    //     0x11cf6f8: ldurb           w16, [x2, #-1]
    //     0x11cf6fc: ldurb           w17, [x0, #-1]
    //     0x11cf700: and             x16, x17, x16, lsr #2
    //     0x11cf704: tst             x16, HEAP, lsr #32
    //     0x11cf708: b.eq            #0x11cf710
    //     0x11cf70c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11cf710: r0 = _LayoutCacheStorage()
    //     0x11cf710: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11cf714: ldur            x2, [fp, #-8]
    // 0x11cf718: StoreField: r2->field_47 = r0
    //     0x11cf718: stur            w0, [x2, #0x47]
    //     0x11cf71c: ldurb           w16, [x2, #-1]
    //     0x11cf720: ldurb           w17, [x0, #-1]
    //     0x11cf724: and             x16, x17, x16, lsr #2
    //     0x11cf728: tst             x16, HEAP, lsr #32
    //     0x11cf72c: b.eq            #0x11cf734
    //     0x11cf730: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11cf734: mov             x1, x2
    // 0x11cf738: r0 = RenderObject()
    //     0x11cf738: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11cf73c: ldur            x1, [fp, #-8]
    // 0x11cf740: r2 = Null
    //     0x11cf740: mov             x2, NULL
    // 0x11cf744: r0 = child=()
    //     0x11cf744: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11cf748: r0 = Null
    //     0x11cf748: mov             x0, NULL
    // 0x11cf74c: LeaveFrame
    //     0x11cf74c: mov             SP, fp
    //     0x11cf750: ldp             fp, lr, [SP], #0x10
    // 0x11cf754: ret
    //     0x11cf754: ret             
    // 0x11cf758: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cf758: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cf75c: b               #0x11cf6ec
  }
}

// class id: 5210, size: 0x5c, field offset: 0x4c
class _AppBarDefaultsM3 extends AppBarThemeData {

  late final ColorScheme _colors; // offset: 0x54
  late final TextTheme _textTheme; // offset: 0x58
  late final ThemeData _theme; // offset: 0x50

  TextTheme _textTheme(_AppBarDefaultsM3) {
    // ** addr: 0xdea858, size: 0x58
    // 0xdea858: EnterFrame
    //     0xdea858: stp             fp, lr, [SP, #-0x10]!
    //     0xdea85c: mov             fp, SP
    // 0xdea860: CheckStackOverflow
    //     0xdea860: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdea864: cmp             SP, x16
    //     0xdea868: b.ls            #0xdea8a8
    // 0xdea86c: ldr             x1, [fp, #0x10]
    // 0xdea870: LoadField: r0 = r1->field_4f
    //     0xdea870: ldur            w0, [x1, #0x4f]
    // 0xdea874: DecompressPointer r0
    //     0xdea874: add             x0, x0, HEAP, lsl #32
    // 0xdea878: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdea87c: cmp             w0, w16
    // 0xdea880: b.ne            #0xdea890
    // 0xdea884: r2 = _theme
    //     0xdea884: add             x2, PP, #0x26, lsl #12  ; [pp+0x265a8] Field <_AppBarDefaultsM3@25187611._theme@25187611>: late final (offset: 0x50)
    //     0xdea888: ldr             x2, [x2, #0x5a8]
    // 0xdea88c: r0 = InitLateFinalInstanceField()
    //     0xdea88c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdea890: LoadField: r1 = r0->field_87
    //     0xdea890: ldur            w1, [x0, #0x87]
    // 0xdea894: DecompressPointer r1
    //     0xdea894: add             x1, x1, HEAP, lsl #32
    // 0xdea898: mov             x0, x1
    // 0xdea89c: LeaveFrame
    //     0xdea89c: mov             SP, fp
    //     0xdea8a0: ldp             fp, lr, [SP], #0x10
    // 0xdea8a4: ret
    //     0xdea8a4: ret             
    // 0xdea8a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdea8a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdea8ac: b               #0xdea86c
  }
  ThemeData _theme(_AppBarDefaultsM3) {
    // ** addr: 0xdea8b0, size: 0x38
    // 0xdea8b0: EnterFrame
    //     0xdea8b0: stp             fp, lr, [SP, #-0x10]!
    //     0xdea8b4: mov             fp, SP
    // 0xdea8b8: CheckStackOverflow
    //     0xdea8b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdea8bc: cmp             SP, x16
    //     0xdea8c0: b.ls            #0xdea8e0
    // 0xdea8c4: ldr             x0, [fp, #0x10]
    // 0xdea8c8: LoadField: r1 = r0->field_4b
    //     0xdea8c8: ldur            w1, [x0, #0x4b]
    // 0xdea8cc: DecompressPointer r1
    //     0xdea8cc: add             x1, x1, HEAP, lsl #32
    // 0xdea8d0: r0 = of()
    //     0xdea8d0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdea8d4: LeaveFrame
    //     0xdea8d4: mov             SP, fp
    //     0xdea8d8: ldp             fp, lr, [SP], #0x10
    // 0xdea8dc: ret
    //     0xdea8dc: ret             
    // 0xdea8e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdea8e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdea8e4: b               #0xdea8c4
  }
  ColorScheme _colors(_AppBarDefaultsM3) {
    // ** addr: 0xdea940, size: 0x58
    // 0xdea940: EnterFrame
    //     0xdea940: stp             fp, lr, [SP, #-0x10]!
    //     0xdea944: mov             fp, SP
    // 0xdea948: CheckStackOverflow
    //     0xdea948: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdea94c: cmp             SP, x16
    //     0xdea950: b.ls            #0xdea990
    // 0xdea954: ldr             x1, [fp, #0x10]
    // 0xdea958: LoadField: r0 = r1->field_4f
    //     0xdea958: ldur            w0, [x1, #0x4f]
    // 0xdea95c: DecompressPointer r0
    //     0xdea95c: add             x0, x0, HEAP, lsl #32
    // 0xdea960: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdea964: cmp             w0, w16
    // 0xdea968: b.ne            #0xdea978
    // 0xdea96c: r2 = _theme
    //     0xdea96c: add             x2, PP, #0x26, lsl #12  ; [pp+0x265a8] Field <_AppBarDefaultsM3@25187611._theme@25187611>: late final (offset: 0x50)
    //     0xdea970: ldr             x2, [x2, #0x5a8]
    // 0xdea974: r0 = InitLateFinalInstanceField()
    //     0xdea974: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdea978: LoadField: r1 = r0->field_3f
    //     0xdea978: ldur            w1, [x0, #0x3f]
    // 0xdea97c: DecompressPointer r1
    //     0xdea97c: add             x1, x1, HEAP, lsl #32
    // 0xdea980: mov             x0, x1
    // 0xdea984: LeaveFrame
    //     0xdea984: mov             SP, fp
    //     0xdea988: ldp             fp, lr, [SP], #0x10
    // 0xdea98c: ret
    //     0xdea98c: ret             
    // 0xdea990: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdea990: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdea994: b               #0xdea954
  }
}

// class id: 5211, size: 0x58, field offset: 0x4c
class _AppBarDefaultsM2 extends AppBarThemeData {

  late final ColorScheme _colors; // offset: 0x54
  late final ThemeData _theme; // offset: 0x50

  ColorScheme _colors(_AppBarDefaultsM2) {
    // ** addr: 0xdea8e8, size: 0x58
    // 0xdea8e8: EnterFrame
    //     0xdea8e8: stp             fp, lr, [SP, #-0x10]!
    //     0xdea8ec: mov             fp, SP
    // 0xdea8f0: CheckStackOverflow
    //     0xdea8f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdea8f4: cmp             SP, x16
    //     0xdea8f8: b.ls            #0xdea938
    // 0xdea8fc: ldr             x1, [fp, #0x10]
    // 0xdea900: LoadField: r0 = r1->field_4f
    //     0xdea900: ldur            w0, [x1, #0x4f]
    // 0xdea904: DecompressPointer r0
    //     0xdea904: add             x0, x0, HEAP, lsl #32
    // 0xdea908: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdea90c: cmp             w0, w16
    // 0xdea910: b.ne            #0xdea920
    // 0xdea914: r2 = _theme
    //     0xdea914: add             x2, PP, #0x26, lsl #12  ; [pp+0x26598] Field <_AppBarDefaultsM2@25187611._theme@25187611>: late final (offset: 0x50)
    //     0xdea918: ldr             x2, [x2, #0x598]
    // 0xdea91c: r0 = InitLateFinalInstanceField()
    //     0xdea91c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdea920: LoadField: r1 = r0->field_3f
    //     0xdea920: ldur            w1, [x0, #0x3f]
    // 0xdea924: DecompressPointer r1
    //     0xdea924: add             x1, x1, HEAP, lsl #32
    // 0xdea928: mov             x0, x1
    // 0xdea92c: LeaveFrame
    //     0xdea92c: mov             SP, fp
    //     0xdea930: ldp             fp, lr, [SP], #0x10
    // 0xdea934: ret
    //     0xdea934: ret             
    // 0xdea938: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdea938: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdea93c: b               #0xdea8fc
  }
}

// class id: 5480, size: 0x1c, field offset: 0x14
class _AppBarState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xde827c, size: 0x1b78
    // 0xde827c: EnterFrame
    //     0xde827c: stp             fp, lr, [SP, #-0x10]!
    //     0xde8280: mov             fp, SP
    // 0xde8284: AllocStack(0xd8)
    //     0xde8284: sub             SP, SP, #0xd8
    // 0xde8288: SetupParameters(_AppBarState this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xde8288: mov             x0, x2
    //     0xde828c: stur            x2, [fp, #-0x10]
    //     0xde8290: mov             x2, x1
    //     0xde8294: stur            x1, [fp, #-8]
    // 0xde8298: CheckStackOverflow
    //     0xde8298: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde829c: cmp             SP, x16
    //     0xde82a0: b.ls            #0xde9d28
    // 0xde82a4: mov             x1, x0
    // 0xde82a8: r0 = of()
    //     0xde82a8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xde82ac: ldur            x1, [fp, #-0x10]
    // 0xde82b0: stur            x0, [fp, #-0x18]
    // 0xde82b4: r0 = of()
    //     0xde82b4: bl              #0xd2d638  ; [package:flutter/src/material/icon_button_theme.dart] IconButtonTheme::of
    // 0xde82b8: ldur            x1, [fp, #-0x10]
    // 0xde82bc: stur            x0, [fp, #-0x20]
    // 0xde82c0: r0 = of()
    //     0xde82c0: bl              #0xd366b0  ; [package:flutter/src/material/app_bar_theme.dart] AppBarTheme::of
    // 0xde82c4: ldur            x2, [fp, #-0x18]
    // 0xde82c8: stur            x0, [fp, #-0x30]
    // 0xde82cc: LoadField: r1 = r2->field_2f
    //     0xde82cc: ldur            w1, [x2, #0x2f]
    // 0xde82d0: DecompressPointer r1
    //     0xde82d0: add             x1, x1, HEAP, lsl #32
    // 0xde82d4: stur            x1, [fp, #-0x28]
    // 0xde82d8: tbnz            w1, #4, #0xde833c
    // 0xde82dc: ldur            x3, [fp, #-0x10]
    // 0xde82e0: r0 = _AppBarDefaultsM3()
    //     0xde82e0: bl              #0xdea84c  ; Allocate_AppBarDefaultsM3Stub -> _AppBarDefaultsM3 (size=0x5c)
    // 0xde82e4: mov             x1, x0
    // 0xde82e8: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xde82ec: StoreField: r1->field_4f = r0
    //     0xde82ec: stur            w0, [x1, #0x4f]
    // 0xde82f0: StoreField: r1->field_53 = r0
    //     0xde82f0: stur            w0, [x1, #0x53]
    // 0xde82f4: StoreField: r1->field_57 = r0
    //     0xde82f4: stur            w0, [x1, #0x57]
    // 0xde82f8: ldur            x2, [fp, #-0x10]
    // 0xde82fc: StoreField: r1->field_4b = r2
    //     0xde82fc: stur            w2, [x1, #0x4b]
    // 0xde8300: r0 = 0.000000
    //     0xde8300: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xde8304: StoreField: r1->field_f = r0
    //     0xde8304: stur            w0, [x1, #0xf]
    // 0xde8308: r0 = 3.000000
    //     0xde8308: add             x0, PP, #0x22, lsl #12  ; [pp+0x223f8] 3
    //     0xde830c: ldr             x0, [x0, #0x3f8]
    // 0xde8310: StoreField: r1->field_13 = r0
    //     0xde8310: stur            w0, [x1, #0x13]
    // 0xde8314: r3 = 16.000000
    //     0xde8314: add             x3, PP, #0x13, lsl #12  ; [pp+0x13df8] 16
    //     0xde8318: ldr             x3, [x3, #0xdf8]
    // 0xde831c: StoreField: r1->field_2f = r3
    //     0xde831c: stur            w3, [x1, #0x2f]
    // 0xde8320: r0 = 64.000000
    //     0xde8320: add             x0, PP, #0x90, lsl #12  ; [pp+0x90d00] 64
    //     0xde8324: ldr             x0, [x0, #0xd00]
    // 0xde8328: StoreField: r1->field_37 = r0
    //     0xde8328: stur            w0, [x1, #0x37]
    // 0xde832c: mov             x3, x1
    // 0xde8330: mov             x0, x2
    // 0xde8334: d0 = 0.000000
    //     0xde8334: eor             v0.16b, v0.16b, v0.16b
    // 0xde8338: b               #0xde83a0
    // 0xde833c: ldur            x2, [fp, #-0x10]
    // 0xde8340: r3 = 16.000000
    //     0xde8340: add             x3, PP, #0x13, lsl #12  ; [pp+0x13df8] 16
    //     0xde8344: ldr             x3, [x3, #0xdf8]
    // 0xde8348: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xde834c: r0 = _AppBarDefaultsM2()
    //     0xde834c: bl              #0xdea840  ; Allocate_AppBarDefaultsM2Stub -> _AppBarDefaultsM2 (size=0x58)
    // 0xde8350: mov             x1, x0
    // 0xde8354: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xde8358: StoreField: r1->field_4f = r0
    //     0xde8358: stur            w0, [x1, #0x4f]
    // 0xde835c: StoreField: r1->field_53 = r0
    //     0xde835c: stur            w0, [x1, #0x53]
    // 0xde8360: ldur            x0, [fp, #-0x10]
    // 0xde8364: StoreField: r1->field_4b = r0
    //     0xde8364: stur            w0, [x1, #0x4b]
    // 0xde8368: r2 = 4.000000
    //     0xde8368: add             x2, PP, #0x19, lsl #12  ; [pp+0x19e28] 4
    //     0xde836c: ldr             x2, [x2, #0xe28]
    // 0xde8370: StoreField: r1->field_f = r2
    //     0xde8370: stur            w2, [x1, #0xf]
    // 0xde8374: r2 = Instance_Color
    //     0xde8374: add             x2, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0xde8378: ldr             x2, [x2, #0x948]
    // 0xde837c: ArrayStore: r1[0] = r2  ; List_4
    //     0xde837c: stur            w2, [x1, #0x17]
    // 0xde8380: r2 = 16.000000
    //     0xde8380: add             x2, PP, #0x13, lsl #12  ; [pp+0x13df8] 16
    //     0xde8384: ldr             x2, [x2, #0xdf8]
    // 0xde8388: StoreField: r1->field_2f = r2
    //     0xde8388: stur            w2, [x1, #0x2f]
    // 0xde838c: r2 = 56.000000
    //     0xde838c: add             x2, PP, #0x18, lsl #12  ; [pp+0x180d0] 56
    //     0xde8390: ldr             x2, [x2, #0xd0]
    // 0xde8394: StoreField: r1->field_37 = r2
    //     0xde8394: stur            w2, [x1, #0x37]
    // 0xde8398: mov             x3, x1
    // 0xde839c: d0 = 4.000000
    //     0xde839c: fmov            d0, #4.00000000
    // 0xde83a0: ldur            x2, [fp, #-8]
    // 0xde83a4: mov             x1, x0
    // 0xde83a8: stur            x3, [fp, #-0x38]
    // 0xde83ac: stur            d0, [fp, #-0xb0]
    // 0xde83b0: r0 = maybeOf()
    //     0xde83b0: bl              #0xdea800  ; [package:flutter/src/material/scaffold.dart] Scaffold::maybeOf
    // 0xde83b4: stur            x0, [fp, #-0x40]
    // 0xde83b8: r16 = <Object?>
    //     0xde83b8: ldr             x16, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0xde83bc: ldur            lr, [fp, #-0x10]
    // 0xde83c0: stp             lr, x16, [SP]
    // 0xde83c4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xde83c4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xde83c8: r0 = of()
    //     0xde83c8: bl              #0xbfcc54  ; [package:flutter/src/widgets/routes.dart] ModalRoute::of
    // 0xde83cc: stur            x0, [fp, #-0x48]
    // 0xde83d0: r16 = <FlexibleSpaceBarSettings>
    //     0xde83d0: add             x16, PP, #0x90, lsl #12  ; [pp+0x90d08] TypeArguments: <FlexibleSpaceBarSettings>
    //     0xde83d4: ldr             x16, [x16, #0xd08]
    // 0xde83d8: ldur            lr, [fp, #-0x10]
    // 0xde83dc: stp             lr, x16, [SP]
    // 0xde83e0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xde83e0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xde83e4: r0 = dependOnInheritedWidgetOfExactType()
    //     0xde83e4: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xde83e8: r1 = <WidgetState>
    //     0xde83e8: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a10] TypeArguments: <WidgetState>
    //     0xde83ec: ldr             x1, [x1, #0xa10]
    // 0xde83f0: r0 = _Set()
    //     0xde83f0: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xde83f4: mov             x3, x0
    // 0xde83f8: r0 = _Uint32List
    //     0xde83f8: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0xde83fc: stur            x3, [fp, #-0x50]
    // 0xde8400: StoreField: r3->field_1b = r0
    //     0xde8400: stur            w0, [x3, #0x1b]
    // 0xde8404: StoreField: r3->field_b = rZR
    //     0xde8404: stur            wzr, [x3, #0xb]
    // 0xde8408: r0 = const []
    //     0xde8408: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0xde840c: StoreField: r3->field_f = r0
    //     0xde840c: stur            w0, [x3, #0xf]
    // 0xde8410: StoreField: r3->field_13 = rZR
    //     0xde8410: stur            wzr, [x3, #0x13]
    // 0xde8414: ArrayStore: r3[0] = rZR  ; List_4
    //     0xde8414: stur            wzr, [x3, #0x17]
    // 0xde8418: ldur            x0, [fp, #-8]
    // 0xde841c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xde841c: ldur            w1, [x0, #0x17]
    // 0xde8420: DecompressPointer r1
    //     0xde8420: add             x1, x1, HEAP, lsl #32
    // 0xde8424: tbnz            w1, #4, #0xde8438
    // 0xde8428: mov             x1, x3
    // 0xde842c: r2 = Instance_WidgetState
    //     0xde842c: add             x2, PP, #0x90, lsl #12  ; [pp+0x90d10] Obj!WidgetState@12c87c1
    //     0xde8430: ldr             x2, [x2, #0xd10]
    // 0xde8434: r0 = add()
    //     0xde8434: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xde8438: ldur            x0, [fp, #-0x40]
    // 0xde843c: cmp             w0, NULL
    // 0xde8440: b.ne            #0xde844c
    // 0xde8444: r1 = Null
    //     0xde8444: mov             x1, NULL
    // 0xde8448: b               #0xde8474
    // 0xde844c: LoadField: r1 = r0->field_b
    //     0xde844c: ldur            w1, [x0, #0xb]
    // 0xde8450: DecompressPointer r1
    //     0xde8450: add             x1, x1, HEAP, lsl #32
    // 0xde8454: cmp             w1, NULL
    // 0xde8458: b.eq            #0xde9d30
    // 0xde845c: LoadField: r2 = r1->field_33
    //     0xde845c: ldur            w2, [x1, #0x33]
    // 0xde8460: DecompressPointer r2
    //     0xde8460: add             x2, x2, HEAP, lsl #32
    // 0xde8464: cmp             w2, NULL
    // 0xde8468: r16 = true
    //     0xde8468: add             x16, NULL, #0x20  ; true
    // 0xde846c: r17 = false
    //     0xde846c: add             x17, NULL, #0x30  ; false
    // 0xde8470: csel            x1, x16, x17, ne
    // 0xde8474: cmp             w1, NULL
    // 0xde8478: b.ne            #0xde8484
    // 0xde847c: r2 = false
    //     0xde847c: add             x2, NULL, #0x30  ; false
    // 0xde8480: b               #0xde8488
    // 0xde8484: mov             x2, x1
    // 0xde8488: stur            x2, [fp, #-0x58]
    // 0xde848c: cmp             w0, NULL
    // 0xde8490: b.ne            #0xde849c
    // 0xde8494: r0 = Null
    //     0xde8494: mov             x0, NULL
    // 0xde8498: b               #0xde84b0
    // 0xde849c: LoadField: r1 = r0->field_b
    //     0xde849c: ldur            w1, [x0, #0xb]
    // 0xde84a0: DecompressPointer r1
    //     0xde84a0: add             x1, x1, HEAP, lsl #32
    // 0xde84a4: cmp             w1, NULL
    // 0xde84a8: b.eq            #0xde9d34
    // 0xde84ac: r0 = false
    //     0xde84ac: add             x0, NULL, #0x30  ; false
    // 0xde84b0: cmp             w0, NULL
    // 0xde84b4: b.ne            #0xde84c0
    // 0xde84b8: r4 = false
    //     0xde84b8: add             x4, NULL, #0x30  ; false
    // 0xde84bc: b               #0xde84c4
    // 0xde84c0: mov             x4, x0
    // 0xde84c4: ldur            x3, [fp, #-0x48]
    // 0xde84c8: stur            x4, [fp, #-0x40]
    // 0xde84cc: cmp             w3, NULL
    // 0xde84d0: b.ne            #0xde84dc
    // 0xde84d4: r0 = Null
    //     0xde84d4: mov             x0, NULL
    // 0xde84d8: b               #0xde84f8
    // 0xde84dc: r0 = LoadClassIdInstr(r3)
    //     0xde84dc: ldur            x0, [x3, #-1]
    //     0xde84e0: ubfx            x0, x0, #0xc, #0x14
    // 0xde84e4: mov             x1, x3
    // 0xde84e8: r0 = GDT[cid_x0 + 0xe85a]()
    //     0xde84e8: mov             x17, #0xe85a
    //     0xde84ec: add             lr, x0, x17
    //     0xde84f0: ldr             lr, [x21, lr, lsl #3]
    //     0xde84f4: blr             lr
    // 0xde84f8: cmp             w0, NULL
    // 0xde84fc: b.ne            #0xde8508
    // 0xde8500: r2 = false
    //     0xde8500: add             x2, NULL, #0x30  ; false
    // 0xde8504: b               #0xde850c
    // 0xde8508: mov             x2, x0
    // 0xde850c: ldur            x0, [fp, #-8]
    // 0xde8510: ldur            x3, [fp, #-0x30]
    // 0xde8514: stur            x2, [fp, #-0x78]
    // 0xde8518: LoadField: r1 = r0->field_b
    //     0xde8518: ldur            w1, [x0, #0xb]
    // 0xde851c: DecompressPointer r1
    //     0xde851c: add             x1, x1, HEAP, lsl #32
    // 0xde8520: cmp             w1, NULL
    // 0xde8524: b.eq            #0xde9d38
    // 0xde8528: LoadField: r4 = r3->field_37
    //     0xde8528: ldur            w4, [x3, #0x37]
    // 0xde852c: DecompressPointer r4
    //     0xde852c: add             x4, x4, HEAP, lsl #32
    // 0xde8530: cmp             w4, NULL
    // 0xde8534: b.ne            #0xde8544
    // 0xde8538: d0 = 56.000000
    //     0xde8538: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a70] IMM: double(56) from 0x404c000000000000
    //     0xde853c: ldr             d0, [x17, #0xa70]
    // 0xde8540: b               #0xde8548
    // 0xde8544: LoadField: d0 = r4->field_7
    //     0xde8544: ldur            d0, [x4, #7]
    // 0xde8548: ldur            x4, [fp, #-0x38]
    // 0xde854c: stur            d0, [fp, #-0xb8]
    // 0xde8550: LoadField: r5 = r1->field_3b
    //     0xde8550: ldur            w5, [x1, #0x3b]
    // 0xde8554: DecompressPointer r5
    //     0xde8554: add             x5, x5, HEAP, lsl #32
    // 0xde8558: stur            x5, [fp, #-0x70]
    // 0xde855c: LoadField: r6 = r3->field_7
    //     0xde855c: ldur            w6, [x3, #7]
    // 0xde8560: DecompressPointer r6
    //     0xde8560: add             x6, x6, HEAP, lsl #32
    // 0xde8564: stur            x6, [fp, #-0x68]
    // 0xde8568: r7 = LoadClassIdInstr(r4)
    //     0xde8568: ldur            x7, [x4, #-1]
    //     0xde856c: ubfx            x7, x7, #0xc, #0x14
    // 0xde8570: stur            x7, [fp, #-0x60]
    // 0xde8574: r17 = 5209
    //     0xde8574: mov             x17, #0x1459
    // 0xde8578: cmp             x7, x17
    // 0xde857c: b.ne            #0xde8590
    // 0xde8580: LoadField: r1 = r4->field_7
    //     0xde8580: ldur            w1, [x4, #7]
    // 0xde8584: DecompressPointer r1
    //     0xde8584: add             x1, x1, HEAP, lsl #32
    // 0xde8588: mov             x6, x1
    // 0xde858c: b               #0xde8630
    // 0xde8590: r17 = 5210
    //     0xde8590: mov             x17, #0x145a
    // 0xde8594: cmp             x7, x17
    // 0xde8598: b.ne            #0xde85d4
    // 0xde859c: mov             x1, x4
    // 0xde85a0: LoadField: r0 = r1->field_53
    //     0xde85a0: ldur            w0, [x1, #0x53]
    // 0xde85a4: DecompressPointer r0
    //     0xde85a4: add             x0, x0, HEAP, lsl #32
    // 0xde85a8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde85ac: cmp             w0, w16
    // 0xde85b0: b.ne            #0xde85c0
    // 0xde85b4: r2 = _colors
    //     0xde85b4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26588] Field <_AppBarDefaultsM3@25187611._colors@25187611>: late final (offset: 0x54)
    //     0xde85b8: ldr             x2, [x2, #0x588]
    // 0xde85bc: r0 = InitLateFinalInstanceField()
    //     0xde85bc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xde85c0: LoadField: r1 = r0->field_7b
    //     0xde85c0: ldur            w1, [x0, #0x7b]
    // 0xde85c4: DecompressPointer r1
    //     0xde85c4: add             x1, x1, HEAP, lsl #32
    // 0xde85c8: mov             x6, x1
    // 0xde85cc: ldur            x0, [fp, #-8]
    // 0xde85d0: b               #0xde8630
    // 0xde85d4: ldur            x1, [fp, #-0x38]
    // 0xde85d8: LoadField: r0 = r1->field_53
    //     0xde85d8: ldur            w0, [x1, #0x53]
    // 0xde85dc: DecompressPointer r0
    //     0xde85dc: add             x0, x0, HEAP, lsl #32
    // 0xde85e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde85e4: cmp             w0, w16
    // 0xde85e8: b.ne            #0xde85f8
    // 0xde85ec: r2 = _colors
    //     0xde85ec: add             x2, PP, #0x26, lsl #12  ; [pp+0x26590] Field <_AppBarDefaultsM2@25187611._colors@25187611>: late final (offset: 0x54)
    //     0xde85f0: ldr             x2, [x2, #0x590]
    // 0xde85f4: r0 = InitLateFinalInstanceField()
    //     0xde85f4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xde85f8: LoadField: r1 = r0->field_7
    //     0xde85f8: ldur            w1, [x0, #7]
    // 0xde85fc: DecompressPointer r1
    //     0xde85fc: add             x1, x1, HEAP, lsl #32
    // 0xde8600: r16 = Instance_Brightness
    //     0xde8600: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xde8604: cmp             w1, w16
    // 0xde8608: b.ne            #0xde861c
    // 0xde860c: LoadField: r1 = r0->field_7b
    //     0xde860c: ldur            w1, [x0, #0x7b]
    // 0xde8610: DecompressPointer r1
    //     0xde8610: add             x1, x1, HEAP, lsl #32
    // 0xde8614: mov             x0, x1
    // 0xde8618: b               #0xde8628
    // 0xde861c: LoadField: r1 = r0->field_b
    //     0xde861c: ldur            w1, [x0, #0xb]
    // 0xde8620: DecompressPointer r1
    //     0xde8620: add             x1, x1, HEAP, lsl #32
    // 0xde8624: mov             x0, x1
    // 0xde8628: mov             x6, x0
    // 0xde862c: ldur            x0, [fp, #-8]
    // 0xde8630: mov             x1, x0
    // 0xde8634: ldur            x2, [fp, #-0x50]
    // 0xde8638: ldur            x3, [fp, #-0x70]
    // 0xde863c: ldur            x5, [fp, #-0x68]
    // 0xde8640: r0 = _resolveColor()
    //     0xde8640: bl              #0xdea760  ; [package:flutter/src/material/app_bar.dart] _AppBarState::_resolveColor
    // 0xde8644: mov             x2, x0
    // 0xde8648: ldur            x0, [fp, #-8]
    // 0xde864c: stur            x2, [fp, #-0x80]
    // 0xde8650: LoadField: r1 = r0->field_b
    //     0xde8650: ldur            w1, [x0, #0xb]
    // 0xde8654: DecompressPointer r1
    //     0xde8654: add             x1, x1, HEAP, lsl #32
    // 0xde8658: cmp             w1, NULL
    // 0xde865c: b.eq            #0xde9d3c
    // 0xde8660: LoadField: r3 = r1->field_3b
    //     0xde8660: ldur            w3, [x1, #0x3b]
    // 0xde8664: DecompressPointer r3
    //     0xde8664: add             x3, x3, HEAP, lsl #32
    // 0xde8668: ldur            x1, [fp, #-0x10]
    // 0xde866c: stur            x3, [fp, #-0x70]
    // 0xde8670: r0 = of()
    //     0xde8670: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xde8674: LoadField: r1 = r0->field_3f
    //     0xde8674: ldur            w1, [x0, #0x3f]
    // 0xde8678: DecompressPointer r1
    //     0xde8678: add             x1, x1, HEAP, lsl #32
    // 0xde867c: LoadField: r0 = r1->field_97
    //     0xde867c: ldur            w0, [x1, #0x97]
    // 0xde8680: DecompressPointer r0
    //     0xde8680: add             x0, x0, HEAP, lsl #32
    // 0xde8684: cmp             w0, NULL
    // 0xde8688: b.ne            #0xde869c
    // 0xde868c: LoadField: r0 = r1->field_7b
    //     0xde868c: ldur            w0, [x1, #0x7b]
    // 0xde8690: DecompressPointer r0
    //     0xde8690: add             x0, x0, HEAP, lsl #32
    // 0xde8694: mov             x6, x0
    // 0xde8698: b               #0xde86a0
    // 0xde869c: mov             x6, x0
    // 0xde86a0: ldur            x1, [fp, #-8]
    // 0xde86a4: ldur            x2, [fp, #-0x50]
    // 0xde86a8: ldur            x3, [fp, #-0x70]
    // 0xde86ac: ldur            x5, [fp, #-0x68]
    // 0xde86b0: r0 = _resolveColor()
    //     0xde86b0: bl              #0xdea760  ; [package:flutter/src/material/app_bar.dart] _AppBarState::_resolveColor
    // 0xde86b4: ldur            x1, [fp, #-0x50]
    // 0xde86b8: r2 = Instance_WidgetState
    //     0xde86b8: add             x2, PP, #0x90, lsl #12  ; [pp+0x90d10] Obj!WidgetState@12c87c1
    //     0xde86bc: ldr             x2, [x2, #0xd10]
    // 0xde86c0: stur            x0, [fp, #-0x10]
    // 0xde86c4: r0 = contains()
    //     0xde86c4: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xde86c8: tbnz            w0, #4, #0xde86d4
    // 0xde86cc: ldur            x3, [fp, #-0x10]
    // 0xde86d0: b               #0xde86d8
    // 0xde86d4: ldur            x3, [fp, #-0x80]
    // 0xde86d8: ldur            x0, [fp, #-8]
    // 0xde86dc: ldur            x2, [fp, #-0x60]
    // 0xde86e0: stur            x3, [fp, #-0x10]
    // 0xde86e4: LoadField: r1 = r0->field_b
    //     0xde86e4: ldur            w1, [x0, #0xb]
    // 0xde86e8: DecompressPointer r1
    //     0xde86e8: add             x1, x1, HEAP, lsl #32
    // 0xde86ec: cmp             w1, NULL
    // 0xde86f0: b.eq            #0xde9d40
    // 0xde86f4: r17 = 5209
    //     0xde86f4: mov             x17, #0x1459
    // 0xde86f8: cmp             x2, x17
    // 0xde86fc: b.ne            #0xde8714
    // 0xde8700: ldur            x4, [fp, #-0x38]
    // 0xde8704: LoadField: r1 = r4->field_b
    //     0xde8704: ldur            w1, [x4, #0xb]
    // 0xde8708: DecompressPointer r1
    //     0xde8708: add             x1, x1, HEAP, lsl #32
    // 0xde870c: mov             x3, x1
    // 0xde8710: b               #0xde87b8
    // 0xde8714: ldur            x4, [fp, #-0x38]
    // 0xde8718: r17 = 5210
    //     0xde8718: mov             x17, #0x145a
    // 0xde871c: cmp             x2, x17
    // 0xde8720: b.ne            #0xde875c
    // 0xde8724: mov             x1, x4
    // 0xde8728: LoadField: r0 = r1->field_53
    //     0xde8728: ldur            w0, [x1, #0x53]
    // 0xde872c: DecompressPointer r0
    //     0xde872c: add             x0, x0, HEAP, lsl #32
    // 0xde8730: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde8734: cmp             w0, w16
    // 0xde8738: b.ne            #0xde8748
    // 0xde873c: r2 = _colors
    //     0xde873c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26588] Field <_AppBarDefaultsM3@25187611._colors@25187611>: late final (offset: 0x54)
    //     0xde8740: ldr             x2, [x2, #0x588]
    // 0xde8744: r0 = InitLateFinalInstanceField()
    //     0xde8744: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xde8748: LoadField: r1 = r0->field_7f
    //     0xde8748: ldur            w1, [x0, #0x7f]
    // 0xde874c: DecompressPointer r1
    //     0xde874c: add             x1, x1, HEAP, lsl #32
    // 0xde8750: mov             x3, x1
    // 0xde8754: ldur            x0, [fp, #-8]
    // 0xde8758: b               #0xde87b8
    // 0xde875c: ldur            x1, [fp, #-0x38]
    // 0xde8760: LoadField: r0 = r1->field_53
    //     0xde8760: ldur            w0, [x1, #0x53]
    // 0xde8764: DecompressPointer r0
    //     0xde8764: add             x0, x0, HEAP, lsl #32
    // 0xde8768: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde876c: cmp             w0, w16
    // 0xde8770: b.ne            #0xde8780
    // 0xde8774: r2 = _colors
    //     0xde8774: add             x2, PP, #0x26, lsl #12  ; [pp+0x26590] Field <_AppBarDefaultsM2@25187611._colors@25187611>: late final (offset: 0x54)
    //     0xde8778: ldr             x2, [x2, #0x590]
    // 0xde877c: r0 = InitLateFinalInstanceField()
    //     0xde877c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xde8780: LoadField: r1 = r0->field_7
    //     0xde8780: ldur            w1, [x0, #7]
    // 0xde8784: DecompressPointer r1
    //     0xde8784: add             x1, x1, HEAP, lsl #32
    // 0xde8788: r16 = Instance_Brightness
    //     0xde8788: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xde878c: cmp             w1, w16
    // 0xde8790: b.ne            #0xde87a4
    // 0xde8794: LoadField: r1 = r0->field_7f
    //     0xde8794: ldur            w1, [x0, #0x7f]
    // 0xde8798: DecompressPointer r1
    //     0xde8798: add             x1, x1, HEAP, lsl #32
    // 0xde879c: mov             x0, x1
    // 0xde87a0: b               #0xde87b0
    // 0xde87a4: LoadField: r1 = r0->field_f
    //     0xde87a4: ldur            w1, [x0, #0xf]
    // 0xde87a8: DecompressPointer r1
    //     0xde87a8: add             x1, x1, HEAP, lsl #32
    // 0xde87ac: mov             x0, x1
    // 0xde87b0: mov             x3, x0
    // 0xde87b4: ldur            x0, [fp, #-8]
    // 0xde87b8: stur            x3, [fp, #-0x68]
    // 0xde87bc: LoadField: r1 = r0->field_b
    //     0xde87bc: ldur            w1, [x0, #0xb]
    // 0xde87c0: DecompressPointer r1
    //     0xde87c0: add             x1, x1, HEAP, lsl #32
    // 0xde87c4: cmp             w1, NULL
    // 0xde87c8: b.eq            #0xde9d44
    // 0xde87cc: LoadField: r2 = r1->field_23
    //     0xde87cc: ldur            w2, [x1, #0x23]
    // 0xde87d0: DecompressPointer r2
    //     0xde87d0: add             x2, x2, HEAP, lsl #32
    // 0xde87d4: cmp             w2, NULL
    // 0xde87d8: b.ne            #0xde87ec
    // 0xde87dc: ldur            x4, [fp, #-0x30]
    // 0xde87e0: LoadField: r1 = r4->field_f
    //     0xde87e0: ldur            w1, [x4, #0xf]
    // 0xde87e4: DecompressPointer r1
    //     0xde87e4: add             x1, x1, HEAP, lsl #32
    // 0xde87e8: b               #0xde87f4
    // 0xde87ec: ldur            x4, [fp, #-0x30]
    // 0xde87f0: mov             x1, x2
    // 0xde87f4: cmp             w1, NULL
    // 0xde87f8: b.ne            #0xde8804
    // 0xde87fc: ldur            d0, [fp, #-0xb0]
    // 0xde8800: b               #0xde8808
    // 0xde8804: LoadField: d0 = r1->field_7
    //     0xde8804: ldur            d0, [x1, #7]
    // 0xde8808: ldur            x1, [fp, #-0x50]
    // 0xde880c: stur            d0, [fp, #-0xb0]
    // 0xde8810: r2 = Instance_WidgetState
    //     0xde8810: add             x2, PP, #0x90, lsl #12  ; [pp+0x90d10] Obj!WidgetState@12c87c1
    //     0xde8814: ldr             x2, [x2, #0xd10]
    // 0xde8818: r0 = contains()
    //     0xde8818: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xde881c: tbnz            w0, #4, #0xde8890
    // 0xde8820: ldur            x0, [fp, #-8]
    // 0xde8824: LoadField: r1 = r0->field_b
    //     0xde8824: ldur            w1, [x0, #0xb]
    // 0xde8828: DecompressPointer r1
    //     0xde8828: add             x1, x1, HEAP, lsl #32
    // 0xde882c: cmp             w1, NULL
    // 0xde8830: b.eq            #0xde9d48
    // 0xde8834: LoadField: r2 = r1->field_27
    //     0xde8834: ldur            w2, [x1, #0x27]
    // 0xde8838: DecompressPointer r2
    //     0xde8838: add             x2, x2, HEAP, lsl #32
    // 0xde883c: cmp             w2, NULL
    // 0xde8840: b.ne            #0xde8854
    // 0xde8844: ldur            x3, [fp, #-0x30]
    // 0xde8848: LoadField: r1 = r3->field_13
    //     0xde8848: ldur            w1, [x3, #0x13]
    // 0xde884c: DecompressPointer r1
    //     0xde884c: add             x1, x1, HEAP, lsl #32
    // 0xde8850: b               #0xde885c
    // 0xde8854: ldur            x3, [fp, #-0x30]
    // 0xde8858: mov             x1, x2
    // 0xde885c: cmp             w1, NULL
    // 0xde8860: b.ne            #0xde8874
    // 0xde8864: ldur            x2, [fp, #-0x38]
    // 0xde8868: LoadField: r1 = r2->field_13
    //     0xde8868: ldur            w1, [x2, #0x13]
    // 0xde886c: DecompressPointer r1
    //     0xde886c: add             x1, x1, HEAP, lsl #32
    // 0xde8870: b               #0xde8878
    // 0xde8874: ldur            x2, [fp, #-0x38]
    // 0xde8878: cmp             w1, NULL
    // 0xde887c: b.ne            #0xde8888
    // 0xde8880: ldur            d0, [fp, #-0xb0]
    // 0xde8884: b               #0xde88a0
    // 0xde8888: LoadField: d0 = r1->field_7
    //     0xde8888: ldur            d0, [x1, #7]
    // 0xde888c: b               #0xde88a0
    // 0xde8890: ldur            x0, [fp, #-8]
    // 0xde8894: ldur            x3, [fp, #-0x30]
    // 0xde8898: ldur            x2, [fp, #-0x38]
    // 0xde889c: ldur            d0, [fp, #-0xb0]
    // 0xde88a0: stur            d0, [fp, #-0xb0]
    // 0xde88a4: LoadField: r1 = r0->field_b
    //     0xde88a4: ldur            w1, [x0, #0xb]
    // 0xde88a8: DecompressPointer r1
    //     0xde88a8: add             x1, x1, HEAP, lsl #32
    // 0xde88ac: cmp             w1, NULL
    // 0xde88b0: b.eq            #0xde9d4c
    // 0xde88b4: LoadField: r4 = r1->field_43
    //     0xde88b4: ldur            w4, [x1, #0x43]
    // 0xde88b8: DecompressPointer r4
    //     0xde88b8: add             x4, x4, HEAP, lsl #32
    // 0xde88bc: cmp             w4, NULL
    // 0xde88c0: b.ne            #0xde88d0
    // 0xde88c4: LoadField: r1 = r3->field_23
    //     0xde88c4: ldur            w1, [x3, #0x23]
    // 0xde88c8: DecompressPointer r1
    //     0xde88c8: add             x1, x1, HEAP, lsl #32
    // 0xde88cc: b               #0xde88d4
    // 0xde88d0: mov             x1, x4
    // 0xde88d4: cmp             w1, NULL
    // 0xde88d8: b.ne            #0xde89b4
    // 0xde88dc: ldur            x4, [fp, #-0x60]
    // 0xde88e0: r17 = 5209
    //     0xde88e0: mov             x17, #0x1459
    // 0xde88e4: cmp             x4, x17
    // 0xde88e8: b.ne            #0xde88f8
    // 0xde88ec: LoadField: r1 = r2->field_23
    //     0xde88ec: ldur            w1, [x2, #0x23]
    // 0xde88f0: DecompressPointer r1
    //     0xde88f0: add             x1, x1, HEAP, lsl #32
    // 0xde88f4: b               #0xde8988
    // 0xde88f8: r17 = 5210
    //     0xde88f8: mov             x17, #0x145a
    // 0xde88fc: cmp             x4, x17
    // 0xde8900: b.ne            #0xde8954
    // 0xde8904: mov             x1, x2
    // 0xde8908: LoadField: r0 = r1->field_53
    //     0xde8908: ldur            w0, [x1, #0x53]
    // 0xde890c: DecompressPointer r0
    //     0xde890c: add             x0, x0, HEAP, lsl #32
    // 0xde8910: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde8914: cmp             w0, w16
    // 0xde8918: b.ne            #0xde8928
    // 0xde891c: r2 = _colors
    //     0xde891c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26588] Field <_AppBarDefaultsM3@25187611._colors@25187611>: late final (offset: 0x54)
    //     0xde8920: ldr             x2, [x2, #0x588]
    // 0xde8924: r0 = InitLateFinalInstanceField()
    //     0xde8924: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xde8928: LoadField: r1 = r0->field_7f
    //     0xde8928: ldur            w1, [x0, #0x7f]
    // 0xde892c: DecompressPointer r1
    //     0xde892c: add             x1, x1, HEAP, lsl #32
    // 0xde8930: stur            x1, [fp, #-0x50]
    // 0xde8934: r0 = IconThemeData()
    //     0xde8934: bl              #0x8ac78c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0xde8938: mov             x1, x0
    // 0xde893c: r0 = 24.000000
    //     0xde893c: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0xde8940: ldr             x0, [x0, #0x4d0]
    // 0xde8944: StoreField: r1->field_7 = r0
    //     0xde8944: stur            w0, [x1, #7]
    // 0xde8948: ldur            x2, [fp, #-0x50]
    // 0xde894c: StoreField: r1->field_1b = r2
    //     0xde894c: stur            w2, [x1, #0x1b]
    // 0xde8950: b               #0xde8988
    // 0xde8954: r0 = 24.000000
    //     0xde8954: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0xde8958: ldr             x0, [x0, #0x4d0]
    // 0xde895c: ldur            x1, [fp, #-0x38]
    // 0xde8960: LoadField: r0 = r1->field_4f
    //     0xde8960: ldur            w0, [x1, #0x4f]
    // 0xde8964: DecompressPointer r0
    //     0xde8964: add             x0, x0, HEAP, lsl #32
    // 0xde8968: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde896c: cmp             w0, w16
    // 0xde8970: b.ne            #0xde8980
    // 0xde8974: r2 = _theme
    //     0xde8974: add             x2, PP, #0x26, lsl #12  ; [pp+0x26598] Field <_AppBarDefaultsM2@25187611._theme@25187611>: late final (offset: 0x50)
    //     0xde8978: ldr             x2, [x2, #0x598]
    // 0xde897c: r0 = InitLateFinalInstanceField()
    //     0xde897c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xde8980: LoadField: r1 = r0->field_7b
    //     0xde8980: ldur            w1, [x0, #0x7b]
    // 0xde8984: DecompressPointer r1
    //     0xde8984: add             x1, x1, HEAP, lsl #32
    // 0xde8988: r0 = LoadClassIdInstr(r1)
    //     0xde8988: ldur            x0, [x1, #-1]
    //     0xde898c: ubfx            x0, x0, #0xc, #0x14
    // 0xde8990: ldur            x16, [fp, #-0x68]
    // 0xde8994: str             x16, [SP]
    // 0xde8998: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xde8998: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xde899c: ldr             x4, [x4, #0x7f0]
    // 0xde89a0: r0 = GDT[cid_x0 + -0xff8]()
    //     0xde89a0: sub             lr, x0, #0xff8
    //     0xde89a4: ldr             lr, [x21, lr, lsl #3]
    //     0xde89a8: blr             lr
    // 0xde89ac: mov             x2, x0
    // 0xde89b0: b               #0xde89b8
    // 0xde89b4: mov             x2, x1
    // 0xde89b8: ldur            x0, [fp, #-8]
    // 0xde89bc: ldur            x3, [fp, #-0x30]
    // 0xde89c0: stur            x2, [fp, #-0x50]
    // 0xde89c4: LoadField: r1 = r0->field_b
    //     0xde89c4: ldur            w1, [x0, #0xb]
    // 0xde89c8: DecompressPointer r1
    //     0xde89c8: add             x1, x1, HEAP, lsl #32
    // 0xde89cc: cmp             w1, NULL
    // 0xde89d0: b.eq            #0xde9d50
    // 0xde89d4: LoadField: r4 = r3->field_27
    //     0xde89d4: ldur            w4, [x3, #0x27]
    // 0xde89d8: DecompressPointer r4
    //     0xde89d8: add             x4, x4, HEAP, lsl #32
    // 0xde89dc: cmp             w4, NULL
    // 0xde89e0: b.ne            #0xde89f4
    // 0xde89e4: LoadField: r4 = r1->field_43
    //     0xde89e4: ldur            w4, [x1, #0x43]
    // 0xde89e8: DecompressPointer r4
    //     0xde89e8: add             x4, x4, HEAP, lsl #32
    // 0xde89ec: mov             x1, x4
    // 0xde89f0: b               #0xde89f8
    // 0xde89f4: mov             x1, x4
    // 0xde89f8: cmp             w1, NULL
    // 0xde89fc: b.ne            #0xde8a08
    // 0xde8a00: LoadField: r1 = r3->field_23
    //     0xde8a00: ldur            w1, [x3, #0x23]
    // 0xde8a04: DecompressPointer r1
    //     0xde8a04: add             x1, x1, HEAP, lsl #32
    // 0xde8a08: cmp             w1, NULL
    // 0xde8a0c: b.ne            #0xde8ae0
    // 0xde8a10: ldur            x4, [fp, #-0x60]
    // 0xde8a14: r17 = 5209
    //     0xde8a14: mov             x17, #0x1459
    // 0xde8a18: cmp             x4, x17
    // 0xde8a1c: b.ne            #0xde8a2c
    // 0xde8a20: r0 = 24.000000
    //     0xde8a20: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0xde8a24: ldr             x0, [x0, #0x4d0]
    // 0xde8a28: b               #0xde8ab0
    // 0xde8a2c: r17 = 5210
    //     0xde8a2c: mov             x17, #0x145a
    // 0xde8a30: cmp             x4, x17
    // 0xde8a34: b.ne            #0xde8aa8
    // 0xde8a38: ldur            x1, [fp, #-0x38]
    // 0xde8a3c: LoadField: r0 = r1->field_53
    //     0xde8a3c: ldur            w0, [x1, #0x53]
    // 0xde8a40: DecompressPointer r0
    //     0xde8a40: add             x0, x0, HEAP, lsl #32
    // 0xde8a44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde8a48: cmp             w0, w16
    // 0xde8a4c: b.ne            #0xde8a5c
    // 0xde8a50: r2 = _colors
    //     0xde8a50: add             x2, PP, #0x26, lsl #12  ; [pp+0x26588] Field <_AppBarDefaultsM3@25187611._colors@25187611>: late final (offset: 0x54)
    //     0xde8a54: ldr             x2, [x2, #0x588]
    // 0xde8a58: r0 = InitLateFinalInstanceField()
    //     0xde8a58: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xde8a5c: LoadField: r1 = r0->field_a3
    //     0xde8a5c: ldur            w1, [x0, #0xa3]
    // 0xde8a60: DecompressPointer r1
    //     0xde8a60: add             x1, x1, HEAP, lsl #32
    // 0xde8a64: cmp             w1, NULL
    // 0xde8a68: b.ne            #0xde8a7c
    // 0xde8a6c: LoadField: r1 = r0->field_7f
    //     0xde8a6c: ldur            w1, [x0, #0x7f]
    // 0xde8a70: DecompressPointer r1
    //     0xde8a70: add             x1, x1, HEAP, lsl #32
    // 0xde8a74: mov             x0, x1
    // 0xde8a78: b               #0xde8a80
    // 0xde8a7c: mov             x0, x1
    // 0xde8a80: stur            x0, [fp, #-0x70]
    // 0xde8a84: r0 = IconThemeData()
    //     0xde8a84: bl              #0x8ac78c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0xde8a88: mov             x1, x0
    // 0xde8a8c: r0 = 24.000000
    //     0xde8a8c: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0xde8a90: ldr             x0, [x0, #0x4d0]
    // 0xde8a94: StoreField: r1->field_7 = r0
    //     0xde8a94: stur            w0, [x1, #7]
    // 0xde8a98: ldur            x2, [fp, #-0x70]
    // 0xde8a9c: StoreField: r1->field_1b = r2
    //     0xde8a9c: stur            w2, [x1, #0x1b]
    // 0xde8aa0: ldur            x2, [fp, #-0x38]
    // 0xde8aa4: b               #0xde8abc
    // 0xde8aa8: r0 = 24.000000
    //     0xde8aa8: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0xde8aac: ldr             x0, [x0, #0x4d0]
    // 0xde8ab0: ldur            x2, [fp, #-0x38]
    // 0xde8ab4: LoadField: r1 = r2->field_27
    //     0xde8ab4: ldur            w1, [x2, #0x27]
    // 0xde8ab8: DecompressPointer r1
    //     0xde8ab8: add             x1, x1, HEAP, lsl #32
    // 0xde8abc: cmp             w1, NULL
    // 0xde8ac0: b.ne            #0xde8acc
    // 0xde8ac4: r0 = Null
    //     0xde8ac4: mov             x0, NULL
    // 0xde8ac8: b               #0xde8ae4
    // 0xde8acc: str             NULL, [SP]
    // 0xde8ad0: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xde8ad0: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xde8ad4: ldr             x4, [x4, #0x7f0]
    // 0xde8ad8: r0 = copyWith()
    //     0xde8ad8: bl              #0x12ab758  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::copyWith
    // 0xde8adc: b               #0xde8ae4
    // 0xde8ae0: mov             x0, x1
    // 0xde8ae4: cmp             w0, NULL
    // 0xde8ae8: b.ne            #0xde8af4
    // 0xde8aec: ldur            x3, [fp, #-0x50]
    // 0xde8af0: b               #0xde8af8
    // 0xde8af4: mov             x3, x0
    // 0xde8af8: ldur            x0, [fp, #-8]
    // 0xde8afc: ldur            x2, [fp, #-0x60]
    // 0xde8b00: stur            x3, [fp, #-0x70]
    // 0xde8b04: LoadField: r1 = r0->field_b
    //     0xde8b04: ldur            w1, [x0, #0xb]
    // 0xde8b08: DecompressPointer r1
    //     0xde8b08: add             x1, x1, HEAP, lsl #32
    // 0xde8b0c: cmp             w1, NULL
    // 0xde8b10: b.eq            #0xde9d54
    // 0xde8b14: r17 = 5209
    //     0xde8b14: mov             x17, #0x1459
    // 0xde8b18: cmp             x2, x17
    // 0xde8b1c: b.ne            #0xde8b30
    // 0xde8b20: ldur            x4, [fp, #-0x38]
    // 0xde8b24: LoadField: r1 = r4->field_3b
    //     0xde8b24: ldur            w1, [x4, #0x3b]
    // 0xde8b28: DecompressPointer r1
    //     0xde8b28: add             x1, x1, HEAP, lsl #32
    // 0xde8b2c: b               #0xde8ba8
    // 0xde8b30: ldur            x4, [fp, #-0x38]
    // 0xde8b34: r17 = 5210
    //     0xde8b34: mov             x17, #0x145a
    // 0xde8b38: cmp             x2, x17
    // 0xde8b3c: b.ne            #0xde8b70
    // 0xde8b40: mov             x1, x4
    // 0xde8b44: LoadField: r0 = r1->field_57
    //     0xde8b44: ldur            w0, [x1, #0x57]
    // 0xde8b48: DecompressPointer r0
    //     0xde8b48: add             x0, x0, HEAP, lsl #32
    // 0xde8b4c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde8b50: cmp             w0, w16
    // 0xde8b54: b.ne            #0xde8b64
    // 0xde8b58: r2 = _textTheme
    //     0xde8b58: add             x2, PP, #0x26, lsl #12  ; [pp+0x265a0] Field <_AppBarDefaultsM3@25187611._textTheme@25187611>: late final (offset: 0x58)
    //     0xde8b5c: ldr             x2, [x2, #0x5a0]
    // 0xde8b60: r0 = InitLateFinalInstanceField()
    //     0xde8b60: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xde8b64: LoadField: r1 = r0->field_2f
    //     0xde8b64: ldur            w1, [x0, #0x2f]
    // 0xde8b68: DecompressPointer r1
    //     0xde8b68: add             x1, x1, HEAP, lsl #32
    // 0xde8b6c: b               #0xde8ba8
    // 0xde8b70: ldur            x1, [fp, #-0x38]
    // 0xde8b74: LoadField: r0 = r1->field_4f
    //     0xde8b74: ldur            w0, [x1, #0x4f]
    // 0xde8b78: DecompressPointer r0
    //     0xde8b78: add             x0, x0, HEAP, lsl #32
    // 0xde8b7c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde8b80: cmp             w0, w16
    // 0xde8b84: b.ne            #0xde8b94
    // 0xde8b88: r2 = _theme
    //     0xde8b88: add             x2, PP, #0x26, lsl #12  ; [pp+0x26598] Field <_AppBarDefaultsM2@25187611._theme@25187611>: late final (offset: 0x50)
    //     0xde8b8c: ldr             x2, [x2, #0x598]
    // 0xde8b90: r0 = InitLateFinalInstanceField()
    //     0xde8b90: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xde8b94: LoadField: r1 = r0->field_87
    //     0xde8b94: ldur            w1, [x0, #0x87]
    // 0xde8b98: DecompressPointer r1
    //     0xde8b98: add             x1, x1, HEAP, lsl #32
    // 0xde8b9c: LoadField: r0 = r1->field_2f
    //     0xde8b9c: ldur            w0, [x1, #0x2f]
    // 0xde8ba0: DecompressPointer r0
    //     0xde8ba0: add             x0, x0, HEAP, lsl #32
    // 0xde8ba4: mov             x1, x0
    // 0xde8ba8: cmp             w1, NULL
    // 0xde8bac: b.ne            #0xde8bb8
    // 0xde8bb0: r2 = Null
    //     0xde8bb0: mov             x2, NULL
    // 0xde8bb4: b               #0xde8bd0
    // 0xde8bb8: ldur            x16, [fp, #-0x68]
    // 0xde8bbc: str             x16, [SP]
    // 0xde8bc0: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xde8bc0: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xde8bc4: ldr             x4, [x4, #0x7f0]
    // 0xde8bc8: r0 = copyWith()
    //     0xde8bc8: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xde8bcc: mov             x2, x0
    // 0xde8bd0: ldur            x0, [fp, #-8]
    // 0xde8bd4: ldur            x3, [fp, #-0x30]
    // 0xde8bd8: stur            x2, [fp, #-0x88]
    // 0xde8bdc: LoadField: r1 = r0->field_b
    //     0xde8bdc: ldur            w1, [x0, #0xb]
    // 0xde8be0: DecompressPointer r1
    //     0xde8be0: add             x1, x1, HEAP, lsl #32
    // 0xde8be4: cmp             w1, NULL
    // 0xde8be8: b.eq            #0xde9d58
    // 0xde8bec: LoadField: r1 = r3->field_3f
    //     0xde8bec: ldur            w1, [x3, #0x3f]
    // 0xde8bf0: DecompressPointer r1
    //     0xde8bf0: add             x1, x1, HEAP, lsl #32
    // 0xde8bf4: cmp             w1, NULL
    // 0xde8bf8: b.ne            #0xde8cc0
    // 0xde8bfc: ldur            x4, [fp, #-0x60]
    // 0xde8c00: r17 = 5209
    //     0xde8c00: mov             x17, #0x1459
    // 0xde8c04: cmp             x4, x17
    // 0xde8c08: b.ne            #0xde8c1c
    // 0xde8c0c: ldur            x5, [fp, #-0x38]
    // 0xde8c10: LoadField: r1 = r5->field_3f
    //     0xde8c10: ldur            w1, [x5, #0x3f]
    // 0xde8c14: DecompressPointer r1
    //     0xde8c14: add             x1, x1, HEAP, lsl #32
    // 0xde8c18: b               #0xde8c94
    // 0xde8c1c: ldur            x5, [fp, #-0x38]
    // 0xde8c20: r17 = 5210
    //     0xde8c20: mov             x17, #0x145a
    // 0xde8c24: cmp             x4, x17
    // 0xde8c28: b.ne            #0xde8c5c
    // 0xde8c2c: mov             x1, x5
    // 0xde8c30: LoadField: r0 = r1->field_57
    //     0xde8c30: ldur            w0, [x1, #0x57]
    // 0xde8c34: DecompressPointer r0
    //     0xde8c34: add             x0, x0, HEAP, lsl #32
    // 0xde8c38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde8c3c: cmp             w0, w16
    // 0xde8c40: b.ne            #0xde8c50
    // 0xde8c44: r2 = _textTheme
    //     0xde8c44: add             x2, PP, #0x26, lsl #12  ; [pp+0x265a0] Field <_AppBarDefaultsM3@25187611._textTheme@25187611>: late final (offset: 0x58)
    //     0xde8c48: ldr             x2, [x2, #0x5a0]
    // 0xde8c4c: r0 = InitLateFinalInstanceField()
    //     0xde8c4c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xde8c50: LoadField: r1 = r0->field_1f
    //     0xde8c50: ldur            w1, [x0, #0x1f]
    // 0xde8c54: DecompressPointer r1
    //     0xde8c54: add             x1, x1, HEAP, lsl #32
    // 0xde8c58: b               #0xde8c94
    // 0xde8c5c: ldur            x1, [fp, #-0x38]
    // 0xde8c60: LoadField: r0 = r1->field_4f
    //     0xde8c60: ldur            w0, [x1, #0x4f]
    // 0xde8c64: DecompressPointer r0
    //     0xde8c64: add             x0, x0, HEAP, lsl #32
    // 0xde8c68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde8c6c: cmp             w0, w16
    // 0xde8c70: b.ne            #0xde8c80
    // 0xde8c74: r2 = _theme
    //     0xde8c74: add             x2, PP, #0x26, lsl #12  ; [pp+0x26598] Field <_AppBarDefaultsM2@25187611._theme@25187611>: late final (offset: 0x50)
    //     0xde8c78: ldr             x2, [x2, #0x598]
    // 0xde8c7c: r0 = InitLateFinalInstanceField()
    //     0xde8c7c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xde8c80: LoadField: r1 = r0->field_87
    //     0xde8c80: ldur            w1, [x0, #0x87]
    // 0xde8c84: DecompressPointer r1
    //     0xde8c84: add             x1, x1, HEAP, lsl #32
    // 0xde8c88: LoadField: r0 = r1->field_1f
    //     0xde8c88: ldur            w0, [x1, #0x1f]
    // 0xde8c8c: DecompressPointer r0
    //     0xde8c8c: add             x0, x0, HEAP, lsl #32
    // 0xde8c90: mov             x1, x0
    // 0xde8c94: cmp             w1, NULL
    // 0xde8c98: b.ne            #0xde8ca4
    // 0xde8c9c: r0 = Null
    //     0xde8c9c: mov             x0, NULL
    // 0xde8ca0: b               #0xde8cb8
    // 0xde8ca4: ldur            x16, [fp, #-0x68]
    // 0xde8ca8: str             x16, [SP]
    // 0xde8cac: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xde8cac: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xde8cb0: ldr             x4, [x4, #0x7f0]
    // 0xde8cb4: r0 = copyWith()
    //     0xde8cb4: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xde8cb8: mov             x2, x0
    // 0xde8cbc: b               #0xde8cc4
    // 0xde8cc0: mov             x2, x1
    // 0xde8cc4: ldur            x0, [fp, #-8]
    // 0xde8cc8: d1 = 1.000000
    //     0xde8cc8: fmov            d1, #1.00000000
    // 0xde8ccc: stur            x2, [fp, #-0x68]
    // 0xde8cd0: LoadField: r1 = r0->field_b
    //     0xde8cd0: ldur            w1, [x0, #0xb]
    // 0xde8cd4: DecompressPointer r1
    //     0xde8cd4: add             x1, x1, HEAP, lsl #32
    // 0xde8cd8: cmp             w1, NULL
    // 0xde8cdc: b.eq            #0xde9d5c
    // 0xde8ce0: fcmp            d1, d1
    // 0xde8ce4: b.eq            #0xde8ec0
    // 0xde8ce8: mov             v0.16b, v1.16b
    // 0xde8cec: r1 = Instance_Interval
    //     0xde8cec: add             x1, PP, #0x90, lsl #12  ; [pp+0x90d18] Obj!Interval@129fa71
    //     0xde8cf0: ldr             x1, [x1, #0xd18]
    // 0xde8cf4: r0 = transform()
    //     0xde8cf4: bl              #0x12f4dac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0xde8cf8: mov             v1.16b, v0.16b
    // 0xde8cfc: ldur            x2, [fp, #-0x68]
    // 0xde8d00: stur            d1, [fp, #-0xc0]
    // 0xde8d04: cmp             w2, NULL
    // 0xde8d08: b.eq            #0xde8d50
    // 0xde8d0c: LoadField: r1 = r2->field_b
    //     0xde8d0c: ldur            w1, [x2, #0xb]
    // 0xde8d10: DecompressPointer r1
    //     0xde8d10: add             x1, x1, HEAP, lsl #32
    // 0xde8d14: cmp             w1, NULL
    // 0xde8d18: b.eq            #0xde8d50
    // 0xde8d1c: r0 = LoadClassIdInstr(r1)
    //     0xde8d1c: ldur            x0, [x1, #-1]
    //     0xde8d20: ubfx            x0, x0, #0xc, #0x14
    // 0xde8d24: mov             v0.16b, v1.16b
    // 0xde8d28: r0 = GDT[cid_x0 + -0x1000]()
    //     0xde8d28: sub             lr, x0, #1, lsl #12
    //     0xde8d2c: ldr             lr, [x21, lr, lsl #3]
    //     0xde8d30: blr             lr
    // 0xde8d34: str             x0, [SP]
    // 0xde8d38: ldur            x1, [fp, #-0x68]
    // 0xde8d3c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xde8d3c: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xde8d40: ldr             x4, [x4, #0x7f0]
    // 0xde8d44: r0 = copyWith()
    //     0xde8d44: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xde8d48: mov             x3, x0
    // 0xde8d4c: b               #0xde8d54
    // 0xde8d50: ldur            x3, [fp, #-0x68]
    // 0xde8d54: ldur            x2, [fp, #-0x88]
    // 0xde8d58: stur            x3, [fp, #-0x90]
    // 0xde8d5c: cmp             w2, NULL
    // 0xde8d60: b.eq            #0xde8da4
    // 0xde8d64: LoadField: r1 = r2->field_b
    //     0xde8d64: ldur            w1, [x2, #0xb]
    // 0xde8d68: DecompressPointer r1
    //     0xde8d68: add             x1, x1, HEAP, lsl #32
    // 0xde8d6c: cmp             w1, NULL
    // 0xde8d70: b.eq            #0xde8da4
    // 0xde8d74: r0 = LoadClassIdInstr(r1)
    //     0xde8d74: ldur            x0, [x1, #-1]
    //     0xde8d78: ubfx            x0, x0, #0xc, #0x14
    // 0xde8d7c: ldur            d0, [fp, #-0xc0]
    // 0xde8d80: r0 = GDT[cid_x0 + -0x1000]()
    //     0xde8d80: sub             lr, x0, #1, lsl #12
    //     0xde8d84: ldr             lr, [x21, lr, lsl #3]
    //     0xde8d88: blr             lr
    // 0xde8d8c: str             x0, [SP]
    // 0xde8d90: ldur            x1, [fp, #-0x88]
    // 0xde8d94: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xde8d94: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xde8d98: ldr             x4, [x4, #0x7f0]
    // 0xde8d9c: r0 = copyWith()
    //     0xde8d9c: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xde8da0: b               #0xde8da8
    // 0xde8da4: ldur            x0, [fp, #-0x88]
    // 0xde8da8: ldur            x1, [fp, #-0x50]
    // 0xde8dac: stur            x0, [fp, #-0x98]
    // 0xde8db0: r0 = opacity()
    //     0xde8db0: bl              #0xd0c778  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::opacity
    // 0xde8db4: cmp             w0, NULL
    // 0xde8db8: b.ne            #0xde8dc4
    // 0xde8dbc: d1 = 1.000000
    //     0xde8dbc: fmov            d1, #1.00000000
    // 0xde8dc0: b               #0xde8dcc
    // 0xde8dc4: LoadField: d0 = r0->field_7
    //     0xde8dc4: ldur            d0, [x0, #7]
    // 0xde8dc8: mov             v1.16b, v0.16b
    // 0xde8dcc: ldur            x1, [fp, #-0x50]
    // 0xde8dd0: ldur            d0, [fp, #-0xc0]
    // 0xde8dd4: fmul            d2, d0, d1
    // 0xde8dd8: r0 = inline_Allocate_Double()
    //     0xde8dd8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xde8ddc: add             x0, x0, #0x10
    //     0xde8de0: cmp             x2, x0
    //     0xde8de4: b.ls            #0xde9d60
    //     0xde8de8: str             x0, [THR, #0x60]  ; THR::top
    //     0xde8dec: sub             x0, x0, #0xf
    //     0xde8df0: mov             x2, #0xe19c
    //     0xde8df4: movk            x2, #3, lsl #16
    //     0xde8df8: stur            x2, [x0, #-1]
    // 0xde8dfc: dmb             ishst
    // 0xde8e00: StoreField: r0->field_7 = d2
    //     0xde8e00: stur            d2, [x0, #7]
    // 0xde8e04: r2 = LoadClassIdInstr(r1)
    //     0xde8e04: ldur            x2, [x1, #-1]
    //     0xde8e08: ubfx            x2, x2, #0xc, #0x14
    // 0xde8e0c: str             x0, [SP]
    // 0xde8e10: mov             x0, x2
    // 0xde8e14: r4 = const [0, 0x2, 0x1, 0x1, opacity, 0x1, null]
    //     0xde8e14: add             x4, PP, #0x90, lsl #12  ; [pp+0x90d20] List(7) [0, 0x2, 0x1, 0x1, "opacity", 0x1, Null]
    //     0xde8e18: ldr             x4, [x4, #0xd20]
    // 0xde8e1c: r0 = GDT[cid_x0 + -0xff8]()
    //     0xde8e1c: sub             lr, x0, #0xff8
    //     0xde8e20: ldr             lr, [x21, lr, lsl #3]
    //     0xde8e24: blr             lr
    // 0xde8e28: ldur            x1, [fp, #-0x70]
    // 0xde8e2c: stur            x0, [fp, #-0xa0]
    // 0xde8e30: r0 = opacity()
    //     0xde8e30: bl              #0xd0c778  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::opacity
    // 0xde8e34: cmp             w0, NULL
    // 0xde8e38: b.ne            #0xde8e44
    // 0xde8e3c: d1 = 1.000000
    //     0xde8e3c: fmov            d1, #1.00000000
    // 0xde8e40: b               #0xde8e4c
    // 0xde8e44: LoadField: d0 = r0->field_7
    //     0xde8e44: ldur            d0, [x0, #7]
    // 0xde8e48: mov             v1.16b, v0.16b
    // 0xde8e4c: ldur            x0, [fp, #-0x70]
    // 0xde8e50: ldur            d0, [fp, #-0xc0]
    // 0xde8e54: fmul            d2, d0, d1
    // 0xde8e58: r1 = inline_Allocate_Double()
    //     0xde8e58: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xde8e5c: add             x1, x1, #0x10
    //     0xde8e60: cmp             x2, x1
    //     0xde8e64: b.ls            #0xde9d78
    //     0xde8e68: str             x1, [THR, #0x60]  ; THR::top
    //     0xde8e6c: sub             x1, x1, #0xf
    //     0xde8e70: mov             x2, #0xe19c
    //     0xde8e74: movk            x2, #3, lsl #16
    //     0xde8e78: stur            x2, [x1, #-1]
    // 0xde8e7c: dmb             ishst
    // 0xde8e80: StoreField: r1->field_7 = d2
    //     0xde8e80: stur            d2, [x1, #7]
    // 0xde8e84: r2 = LoadClassIdInstr(r0)
    //     0xde8e84: ldur            x2, [x0, #-1]
    //     0xde8e88: ubfx            x2, x2, #0xc, #0x14
    // 0xde8e8c: str             x1, [SP]
    // 0xde8e90: mov             x1, x0
    // 0xde8e94: mov             x0, x2
    // 0xde8e98: r4 = const [0, 0x2, 0x1, 0x1, opacity, 0x1, null]
    //     0xde8e98: add             x4, PP, #0x90, lsl #12  ; [pp+0x90d20] List(7) [0, 0x2, 0x1, 0x1, "opacity", 0x1, Null]
    //     0xde8e9c: ldr             x4, [x4, #0xd20]
    // 0xde8ea0: r0 = GDT[cid_x0 + -0xff8]()
    //     0xde8ea0: sub             lr, x0, #0xff8
    //     0xde8ea4: ldr             lr, [x21, lr, lsl #3]
    //     0xde8ea8: blr             lr
    // 0xde8eac: ldur            x4, [fp, #-0xa0]
    // 0xde8eb0: mov             x3, x0
    // 0xde8eb4: ldur            x2, [fp, #-0x98]
    // 0xde8eb8: ldur            x0, [fp, #-0x90]
    // 0xde8ebc: b               #0xde8ed8
    // 0xde8ec0: ldur            x1, [fp, #-0x50]
    // 0xde8ec4: ldur            x0, [fp, #-0x70]
    // 0xde8ec8: mov             x4, x1
    // 0xde8ecc: mov             x3, x0
    // 0xde8ed0: ldur            x2, [fp, #-0x88]
    // 0xde8ed4: ldur            x0, [fp, #-0x68]
    // 0xde8ed8: ldur            x1, [fp, #-8]
    // 0xde8edc: stur            x4, [fp, #-0x50]
    // 0xde8ee0: stur            x3, [fp, #-0x68]
    // 0xde8ee4: stur            x2, [fp, #-0x70]
    // 0xde8ee8: stur            x0, [fp, #-0x88]
    // 0xde8eec: LoadField: r5 = r1->field_b
    //     0xde8eec: ldur            w5, [x1, #0xb]
    // 0xde8ef0: DecompressPointer r5
    //     0xde8ef0: add             x5, x5, HEAP, lsl #32
    // 0xde8ef4: cmp             w5, NULL
    // 0xde8ef8: b.eq            #0xde9d94
    // 0xde8efc: LoadField: r6 = r5->field_b
    //     0xde8efc: ldur            w6, [x5, #0xb]
    // 0xde8f00: DecompressPointer r6
    //     0xde8f00: add             x6, x6, HEAP, lsl #32
    // 0xde8f04: stur            x6, [fp, #-0x90]
    // 0xde8f08: cmp             w6, NULL
    // 0xde8f0c: b.ne            #0xde903c
    // 0xde8f10: LoadField: r7 = r5->field_f
    //     0xde8f10: ldur            w7, [x5, #0xf]
    // 0xde8f14: DecompressPointer r7
    //     0xde8f14: add             x7, x7, HEAP, lsl #32
    // 0xde8f18: tbnz            w7, #4, #0xde903c
    // 0xde8f1c: ldur            x5, [fp, #-0x58]
    // 0xde8f20: tbnz            w5, #4, #0xde8fc4
    // 0xde8f24: LoadField: r5 = r4->field_7
    //     0xde8f24: ldur            w5, [x4, #7]
    // 0xde8f28: DecompressPointer r5
    //     0xde8f28: add             x5, x5, HEAP, lsl #32
    // 0xde8f2c: cmp             w5, NULL
    // 0xde8f30: b.ne            #0xde8f3c
    // 0xde8f34: d0 = 24.000000
    //     0xde8f34: fmov            d0, #24.00000000
    // 0xde8f38: b               #0xde8f40
    // 0xde8f3c: LoadField: d0 = r5->field_7
    //     0xde8f3c: ldur            d0, [x5, #7]
    // 0xde8f40: r5 = inline_Allocate_Double()
    //     0xde8f40: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0xde8f44: add             x5, x5, #0x10
    //     0xde8f48: cmp             x6, x5
    //     0xde8f4c: b.ls            #0xde9d98
    //     0xde8f50: str             x5, [THR, #0x60]  ; THR::top
    //     0xde8f54: sub             x5, x5, #0xf
    //     0xde8f58: mov             x6, #0xe19c
    //     0xde8f5c: movk            x6, #3, lsl #16
    //     0xde8f60: stur            x6, [x5, #-1]
    // 0xde8f64: dmb             ishst
    // 0xde8f68: StoreField: r5->field_7 = d0
    //     0xde8f68: stur            d0, [x5, #7]
    // 0xde8f6c: str             x5, [SP]
    // 0xde8f70: r4 = const [0, 0x1, 0x1, 0, iconSize, 0, null]
    //     0xde8f70: add             x4, PP, #0x90, lsl #12  ; [pp+0x90d28] List(7) [0, 0x1, 0x1, 0, "iconSize", 0, Null]
    //     0xde8f74: ldr             x4, [x4, #0xd28]
    // 0xde8f78: r0 = styleFrom()
    //     0xde8f78: bl              #0xdea068  ; [package:flutter/src/material/icon_button.dart] IconButton::styleFrom
    // 0xde8f7c: stur            x0, [fp, #-0x58]
    // 0xde8f80: r0 = DrawerButton()
    //     0xde8f80: bl              #0xdea05c  ; AllocateDrawerButtonStub -> DrawerButton (size=0x78)
    // 0xde8f84: mov             x1, x0
    // 0xde8f88: r0 = Instance_StandardComponentType
    //     0xde8f88: add             x0, PP, #0x90, lsl #12  ; [pp+0x90d30] Obj!StandardComponentType@12c2541
    //     0xde8f8c: ldr             x0, [x0, #0xd30]
    // 0xde8f90: StoreField: r1->field_73 = r0
    //     0xde8f90: stur            w0, [x1, #0x73]
    // 0xde8f94: r0 = false
    //     0xde8f94: add             x0, NULL, #0x30  ; false
    // 0xde8f98: StoreField: r1->field_4f = r0
    //     0xde8f98: stur            w0, [x1, #0x4f]
    // 0xde8f9c: ldur            x2, [fp, #-0x58]
    // 0xde8fa0: StoreField: r1->field_5f = r2
    //     0xde8fa0: stur            w2, [x1, #0x5f]
    // 0xde8fa4: r2 = Instance_DrawerButtonIcon
    //     0xde8fa4: add             x2, PP, #0x90, lsl #12  ; [pp+0x90d38] Obj!DrawerButtonIcon@12b69c1
    //     0xde8fa8: ldr             x2, [x2, #0xd38]
    // 0xde8fac: StoreField: r1->field_1f = r2
    //     0xde8fac: stur            w2, [x1, #0x1f]
    // 0xde8fb0: r2 = Instance__IconButtonVariant
    //     0xde8fb0: add             x2, PP, #0x17, lsl #12  ; [pp+0x177a8] Obj!_IconButtonVariant@12c57a1
    //     0xde8fb4: ldr             x2, [x2, #0x7a8]
    // 0xde8fb8: StoreField: r1->field_6f = r2
    //     0xde8fb8: stur            w2, [x1, #0x6f]
    // 0xde8fbc: mov             x0, x1
    // 0xde8fc0: b               #0xde9040
    // 0xde8fc4: ldur            x2, [fp, #-0x48]
    // 0xde8fc8: r0 = false
    //     0xde8fc8: add             x0, NULL, #0x30  ; false
    // 0xde8fcc: cmp             w2, NULL
    // 0xde8fd0: b.ne            #0xde8fdc
    // 0xde8fd4: r0 = Null
    //     0xde8fd4: mov             x0, NULL
    // 0xde8fd8: b               #0xde9008
    // 0xde8fdc: mov             x1, x2
    // 0xde8fe0: r0 = hasActiveRouteBelow()
    //     0xde8fe0: bl              #0xde9f98  ; [package:flutter/src/widgets/navigator.dart] Route::hasActiveRouteBelow
    // 0xde8fe4: tbnz            w0, #4, #0xde8ff0
    // 0xde8fe8: r0 = true
    //     0xde8fe8: add             x0, NULL, #0x20  ; true
    // 0xde8fec: b               #0xde9008
    // 0xde8ff0: ldur            x0, [fp, #-0x48]
    // 0xde8ff4: LoadField: r1 = r0->field_53
    //     0xde8ff4: ldur            x1, [x0, #0x53]
    // 0xde8ff8: cmp             x1, #0
    // 0xde8ffc: r16 = true
    //     0xde8ffc: add             x16, NULL, #0x20  ; true
    // 0xde9000: r17 = false
    //     0xde9000: add             x17, NULL, #0x30  ; false
    // 0xde9004: csel            x0, x16, x17, gt
    // 0xde9008: cmp             w0, NULL
    // 0xde900c: b.eq            #0xde9034
    // 0xde9010: tbnz            w0, #4, #0xde9034
    // 0xde9014: ldur            x0, [fp, #-0x78]
    // 0xde9018: tbnz            w0, #4, #0xde9028
    // 0xde901c: r0 = Instance_CloseButton
    //     0xde901c: add             x0, PP, #0x90, lsl #12  ; [pp+0x90d40] Obj!CloseButton@12b69f1
    //     0xde9020: ldr             x0, [x0, #0xd40]
    // 0xde9024: b               #0xde9040
    // 0xde9028: r0 = Instance_BackButton
    //     0xde9028: add             x0, PP, #0x90, lsl #12  ; [pp+0x90d48] Obj!BackButton@12b6a71
    //     0xde902c: ldr             x0, [x0, #0xd48]
    // 0xde9030: b               #0xde9040
    // 0xde9034: ldur            x0, [fp, #-0x90]
    // 0xde9038: b               #0xde9040
    // 0xde903c: ldur            x0, [fp, #-0x90]
    // 0xde9040: stur            x0, [fp, #-0x48]
    // 0xde9044: cmp             w0, NULL
    // 0xde9048: b.eq            #0xde9328
    // 0xde904c: ldur            x2, [fp, #-0x28]
    // 0xde9050: tbnz            w2, #4, #0xde92a8
    // 0xde9054: ldur            x3, [fp, #-0x60]
    // 0xde9058: r17 = 5209
    //     0xde9058: mov             x17, #0x1459
    // 0xde905c: cmp             x3, x17
    // 0xde9060: b.ne            #0xde9078
    // 0xde9064: ldur            x4, [fp, #-0x38]
    // 0xde9068: LoadField: r1 = r4->field_23
    //     0xde9068: ldur            w1, [x4, #0x23]
    // 0xde906c: DecompressPointer r1
    //     0xde906c: add             x1, x1, HEAP, lsl #32
    // 0xde9070: mov             x0, x1
    // 0xde9074: b               #0xde9114
    // 0xde9078: ldur            x4, [fp, #-0x38]
    // 0xde907c: r17 = 5210
    //     0xde907c: mov             x17, #0x145a
    // 0xde9080: cmp             x3, x17
    // 0xde9084: b.ne            #0xde90dc
    // 0xde9088: mov             x1, x4
    // 0xde908c: LoadField: r0 = r1->field_53
    //     0xde908c: ldur            w0, [x1, #0x53]
    // 0xde9090: DecompressPointer r0
    //     0xde9090: add             x0, x0, HEAP, lsl #32
    // 0xde9094: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde9098: cmp             w0, w16
    // 0xde909c: b.ne            #0xde90ac
    // 0xde90a0: r2 = _colors
    //     0xde90a0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26588] Field <_AppBarDefaultsM3@25187611._colors@25187611>: late final (offset: 0x54)
    //     0xde90a4: ldr             x2, [x2, #0x588]
    // 0xde90a8: r0 = InitLateFinalInstanceField()
    //     0xde90a8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xde90ac: LoadField: r1 = r0->field_7f
    //     0xde90ac: ldur            w1, [x0, #0x7f]
    // 0xde90b0: DecompressPointer r1
    //     0xde90b0: add             x1, x1, HEAP, lsl #32
    // 0xde90b4: stur            x1, [fp, #-0x58]
    // 0xde90b8: r0 = IconThemeData()
    //     0xde90b8: bl              #0x8ac78c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0xde90bc: mov             x1, x0
    // 0xde90c0: r0 = 24.000000
    //     0xde90c0: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0xde90c4: ldr             x0, [x0, #0x4d0]
    // 0xde90c8: StoreField: r1->field_7 = r0
    //     0xde90c8: stur            w0, [x1, #7]
    // 0xde90cc: ldur            x2, [fp, #-0x58]
    // 0xde90d0: StoreField: r1->field_1b = r2
    //     0xde90d0: stur            w2, [x1, #0x1b]
    // 0xde90d4: mov             x0, x1
    // 0xde90d8: b               #0xde9114
    // 0xde90dc: r0 = 24.000000
    //     0xde90dc: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0xde90e0: ldr             x0, [x0, #0x4d0]
    // 0xde90e4: ldur            x1, [fp, #-0x38]
    // 0xde90e8: LoadField: r0 = r1->field_4f
    //     0xde90e8: ldur            w0, [x1, #0x4f]
    // 0xde90ec: DecompressPointer r0
    //     0xde90ec: add             x0, x0, HEAP, lsl #32
    // 0xde90f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde90f4: cmp             w0, w16
    // 0xde90f8: b.ne            #0xde9108
    // 0xde90fc: r2 = _theme
    //     0xde90fc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26598] Field <_AppBarDefaultsM2@25187611._theme@25187611>: late final (offset: 0x50)
    //     0xde9100: ldr             x2, [x2, #0x598]
    // 0xde9104: r0 = InitLateFinalInstanceField()
    //     0xde9104: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xde9108: LoadField: r1 = r0->field_7b
    //     0xde9108: ldur            w1, [x0, #0x7b]
    // 0xde910c: DecompressPointer r1
    //     0xde910c: add             x1, x1, HEAP, lsl #32
    // 0xde9110: mov             x0, x1
    // 0xde9114: ldur            x16, [fp, #-0x50]
    // 0xde9118: stp             x0, x16, [SP]
    // 0xde911c: r0 = ==()
    //     0xde911c: bl              #0x12625cc  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::==
    // 0xde9120: tbnz            w0, #4, #0xde912c
    // 0xde9124: ldur            x1, [fp, #-0x20]
    // 0xde9128: b               #0xde91b8
    // 0xde912c: ldur            x0, [fp, #-0x20]
    // 0xde9130: ldur            x2, [fp, #-0x50]
    // 0xde9134: LoadField: r1 = r2->field_1b
    //     0xde9134: ldur            w1, [x2, #0x1b]
    // 0xde9138: DecompressPointer r1
    //     0xde9138: add             x1, x1, HEAP, lsl #32
    // 0xde913c: LoadField: r3 = r2->field_7
    //     0xde913c: ldur            w3, [x2, #7]
    // 0xde9140: DecompressPointer r3
    //     0xde9140: add             x3, x3, HEAP, lsl #32
    // 0xde9144: stp             x3, x1, [SP]
    // 0xde9148: r4 = const [0, 0x2, 0x2, 0, foregroundColor, 0, iconSize, 0x1, null]
    //     0xde9148: add             x4, PP, #0x90, lsl #12  ; [pp+0x90d50] List(9) [0, 0x2, 0x2, 0, "foregroundColor", 0, "iconSize", 0x1, Null]
    //     0xde914c: ldr             x4, [x4, #0xd50]
    // 0xde9150: r0 = styleFrom()
    //     0xde9150: bl              #0xdea068  ; [package:flutter/src/material/icon_button.dart] IconButton::styleFrom
    // 0xde9154: mov             x1, x0
    // 0xde9158: ldur            x0, [fp, #-0x20]
    // 0xde915c: LoadField: r2 = r0->field_7
    //     0xde915c: ldur            w2, [x0, #7]
    // 0xde9160: DecompressPointer r2
    //     0xde9160: add             x2, x2, HEAP, lsl #32
    // 0xde9164: cmp             w2, NULL
    // 0xde9168: b.ne            #0xde9174
    // 0xde916c: r0 = Null
    //     0xde916c: mov             x0, NULL
    // 0xde9170: b               #0xde91a4
    // 0xde9174: LoadField: r3 = r1->field_f
    //     0xde9174: ldur            w3, [x1, #0xf]
    // 0xde9178: DecompressPointer r3
    //     0xde9178: add             x3, x3, HEAP, lsl #32
    // 0xde917c: LoadField: r4 = r1->field_13
    //     0xde917c: ldur            w4, [x1, #0x13]
    // 0xde9180: DecompressPointer r4
    //     0xde9180: add             x4, x4, HEAP, lsl #32
    // 0xde9184: LoadField: r5 = r1->field_37
    //     0xde9184: ldur            w5, [x1, #0x37]
    // 0xde9188: DecompressPointer r5
    //     0xde9188: add             x5, x5, HEAP, lsl #32
    // 0xde918c: stp             x4, x3, [SP, #8]
    // 0xde9190: str             x5, [SP]
    // 0xde9194: mov             x1, x2
    // 0xde9198: r4 = const [0, 0x4, 0x3, 0x1, foregroundColor, 0x1, iconSize, 0x3, overlayColor, 0x2, null]
    //     0xde9198: add             x4, PP, #0x90, lsl #12  ; [pp+0x90d58] List(11) [0, 0x4, 0x3, 0x1, "foregroundColor", 0x1, "iconSize", 0x3, "overlayColor", 0x2, Null]
    //     0xde919c: ldr             x4, [x4, #0xd58]
    // 0xde91a0: r0 = copyWith()
    //     0xde91a0: bl              #0xd2991c  ; [package:flutter/src/material/button_style.dart] ButtonStyle::copyWith
    // 0xde91a4: stur            x0, [fp, #-0x58]
    // 0xde91a8: r0 = IconButtonThemeData()
    //     0xde91a8: bl              #0xd29654  ; AllocateIconButtonThemeDataStub -> IconButtonThemeData (size=0xc)
    // 0xde91ac: mov             x1, x0
    // 0xde91b0: ldur            x0, [fp, #-0x58]
    // 0xde91b4: StoreField: r1->field_7 = r0
    //     0xde91b4: stur            w0, [x1, #7]
    // 0xde91b8: ldur            x0, [fp, #-0x48]
    // 0xde91bc: stur            x1, [fp, #-0x58]
    // 0xde91c0: r2 = LoadClassIdInstr(r0)
    //     0xde91c0: ldur            x2, [x0, #-1]
    //     0xde91c4: ubfx            x2, x2, #0xc, #0x14
    // 0xde91c8: r17 = -6193
    //     0xde91c8: mov             x17, #-0x1831
    // 0xde91cc: add             x16, x2, x17
    // 0xde91d0: cmp             x16, #5
    // 0xde91d4: b.hi            #0xde91fc
    // 0xde91d8: r0 = Center()
    //     0xde91d8: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xde91dc: mov             x1, x0
    // 0xde91e0: r0 = Instance_Alignment
    //     0xde91e0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xde91e4: ldr             x0, [x0, #0xb80]
    // 0xde91e8: StoreField: r1->field_f = r0
    //     0xde91e8: stur            w0, [x1, #0xf]
    // 0xde91ec: ldur            x0, [fp, #-0x48]
    // 0xde91f0: StoreField: r1->field_b = r0
    //     0xde91f0: stur            w0, [x1, #0xb]
    // 0xde91f4: mov             x2, x1
    // 0xde91f8: b               #0xde9200
    // 0xde91fc: mov             x2, x0
    // 0xde9200: ldur            x1, [fp, #-8]
    // 0xde9204: ldur            x3, [fp, #-0x30]
    // 0xde9208: ldur            x0, [fp, #-0x58]
    // 0xde920c: stur            x2, [fp, #-0x78]
    // 0xde9210: r0 = IconButtonTheme()
    //     0xde9210: bl              #0xd29648  ; AllocateIconButtonThemeStub -> IconButtonTheme (size=0x14)
    // 0xde9214: mov             x1, x0
    // 0xde9218: ldur            x0, [fp, #-0x58]
    // 0xde921c: stur            x1, [fp, #-0x90]
    // 0xde9220: StoreField: r1->field_f = r0
    //     0xde9220: stur            w0, [x1, #0xf]
    // 0xde9224: ldur            x0, [fp, #-0x78]
    // 0xde9228: StoreField: r1->field_b = r0
    //     0xde9228: stur            w0, [x1, #0xb]
    // 0xde922c: ldur            x0, [fp, #-8]
    // 0xde9230: LoadField: r2 = r0->field_b
    //     0xde9230: ldur            w2, [x0, #0xb]
    // 0xde9234: DecompressPointer r2
    //     0xde9234: add             x2, x2, HEAP, lsl #32
    // 0xde9238: cmp             w2, NULL
    // 0xde923c: b.eq            #0xde9dc4
    // 0xde9240: ldur            x3, [fp, #-0x30]
    // 0xde9244: LoadField: r2 = r3->field_33
    //     0xde9244: ldur            w2, [x3, #0x33]
    // 0xde9248: DecompressPointer r2
    //     0xde9248: add             x2, x2, HEAP, lsl #32
    // 0xde924c: cmp             w2, NULL
    // 0xde9250: b.ne            #0xde9260
    // 0xde9254: d0 = 56.000000
    //     0xde9254: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a70] IMM: double(56) from 0x404c000000000000
    //     0xde9258: ldr             d0, [x17, #0xa70]
    // 0xde925c: b               #0xde9264
    // 0xde9260: LoadField: d0 = r2->field_7
    //     0xde9260: ldur            d0, [x2, #7]
    // 0xde9264: stur            d0, [fp, #-0xc0]
    // 0xde9268: r0 = BoxConstraints()
    //     0xde9268: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xde926c: ldur            d0, [fp, #-0xc0]
    // 0xde9270: stur            x0, [fp, #-0x58]
    // 0xde9274: StoreField: r0->field_7 = d0
    //     0xde9274: stur            d0, [x0, #7]
    // 0xde9278: StoreField: r0->field_f = d0
    //     0xde9278: stur            d0, [x0, #0xf]
    // 0xde927c: ArrayStore: r0[0] = rZR  ; List_8
    //     0xde927c: stur            xzr, [x0, #0x17]
    // 0xde9280: d0 = inf
    //     0xde9280: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xde9284: StoreField: r0->field_1f = d0
    //     0xde9284: stur            d0, [x0, #0x1f]
    // 0xde9288: r0 = ConstrainedBox()
    //     0xde9288: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xde928c: mov             x1, x0
    // 0xde9290: ldur            x0, [fp, #-0x58]
    // 0xde9294: StoreField: r1->field_f = r0
    //     0xde9294: stur            w0, [x1, #0xf]
    // 0xde9298: ldur            x0, [fp, #-0x90]
    // 0xde929c: StoreField: r1->field_b = r0
    //     0xde929c: stur            w0, [x1, #0xb]
    // 0xde92a0: mov             x0, x1
    // 0xde92a4: b               #0xde9320
    // 0xde92a8: ldur            x1, [fp, #-8]
    // 0xde92ac: ldur            x3, [fp, #-0x30]
    // 0xde92b0: LoadField: r2 = r1->field_b
    //     0xde92b0: ldur            w2, [x1, #0xb]
    // 0xde92b4: DecompressPointer r2
    //     0xde92b4: add             x2, x2, HEAP, lsl #32
    // 0xde92b8: cmp             w2, NULL
    // 0xde92bc: b.eq            #0xde9dc8
    // 0xde92c0: LoadField: r2 = r3->field_33
    //     0xde92c0: ldur            w2, [x3, #0x33]
    // 0xde92c4: DecompressPointer r2
    //     0xde92c4: add             x2, x2, HEAP, lsl #32
    // 0xde92c8: cmp             w2, NULL
    // 0xde92cc: b.ne            #0xde92dc
    // 0xde92d0: d0 = 56.000000
    //     0xde92d0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a70] IMM: double(56) from 0x404c000000000000
    //     0xde92d4: ldr             d0, [x17, #0xa70]
    // 0xde92d8: b               #0xde92e0
    // 0xde92dc: LoadField: d0 = r2->field_7
    //     0xde92dc: ldur            d0, [x2, #7]
    // 0xde92e0: stur            d0, [fp, #-0xc0]
    // 0xde92e4: r0 = BoxConstraints()
    //     0xde92e4: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xde92e8: ldur            d0, [fp, #-0xc0]
    // 0xde92ec: stur            x0, [fp, #-0x58]
    // 0xde92f0: StoreField: r0->field_7 = d0
    //     0xde92f0: stur            d0, [x0, #7]
    // 0xde92f4: StoreField: r0->field_f = d0
    //     0xde92f4: stur            d0, [x0, #0xf]
    // 0xde92f8: ArrayStore: r0[0] = rZR  ; List_8
    //     0xde92f8: stur            xzr, [x0, #0x17]
    // 0xde92fc: d0 = inf
    //     0xde92fc: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xde9300: StoreField: r0->field_1f = d0
    //     0xde9300: stur            d0, [x0, #0x1f]
    // 0xde9304: r0 = ConstrainedBox()
    //     0xde9304: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xde9308: mov             x1, x0
    // 0xde930c: ldur            x0, [fp, #-0x58]
    // 0xde9310: StoreField: r1->field_f = r0
    //     0xde9310: stur            w0, [x1, #0xf]
    // 0xde9314: ldur            x0, [fp, #-0x48]
    // 0xde9318: StoreField: r1->field_b = r0
    //     0xde9318: stur            w0, [x1, #0xb]
    // 0xde931c: mov             x0, x1
    // 0xde9320: mov             x2, x0
    // 0xde9324: b               #0xde932c
    // 0xde9328: mov             x2, x0
    // 0xde932c: ldur            x1, [fp, #-8]
    // 0xde9330: ldur            x0, [fp, #-0x88]
    // 0xde9334: stur            x2, [fp, #-0x58]
    // 0xde9338: LoadField: r3 = r1->field_b
    //     0xde9338: ldur            w3, [x1, #0xb]
    // 0xde933c: DecompressPointer r3
    //     0xde933c: add             x3, x3, HEAP, lsl #32
    // 0xde9340: cmp             w3, NULL
    // 0xde9344: b.eq            #0xde9dcc
    // 0xde9348: LoadField: r4 = r3->field_13
    //     0xde9348: ldur            w4, [x3, #0x13]
    // 0xde934c: DecompressPointer r4
    //     0xde934c: add             x4, x4, HEAP, lsl #32
    // 0xde9350: stur            x4, [fp, #-0x48]
    // 0xde9354: r0 = _AppBarTitleBox()
    //     0xde9354: bl              #0xde9f8c  ; Allocate_AppBarTitleBoxStub -> _AppBarTitleBox (size=0x10)
    // 0xde9358: mov             x1, x0
    // 0xde935c: ldur            x0, [fp, #-0x48]
    // 0xde9360: stur            x1, [fp, #-0x78]
    // 0xde9364: StoreField: r1->field_b = r0
    //     0xde9364: stur            w0, [x1, #0xb]
    // 0xde9368: r0 = Semantics()
    //     0xde9368: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xde936c: stur            x0, [fp, #-0x48]
    // 0xde9370: r16 = true
    //     0xde9370: add             x16, NULL, #0x20  ; true
    // 0xde9374: r30 = true
    //     0xde9374: add             lr, NULL, #0x20  ; true
    // 0xde9378: stp             lr, x16, [SP, #8]
    // 0xde937c: ldur            x16, [fp, #-0x78]
    // 0xde9380: str             x16, [SP]
    // 0xde9384: mov             x1, x0
    // 0xde9388: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, header, 0x2, namesRoute, 0x1, null]
    //     0xde9388: add             x4, PP, #0x90, lsl #12  ; [pp+0x90d60] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "header", 0x2, "namesRoute", 0x1, Null]
    //     0xde938c: ldr             x4, [x4, #0xd60]
    // 0xde9390: r0 = Semantics()
    //     0xde9390: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xde9394: ldur            x0, [fp, #-0x88]
    // 0xde9398: cmp             w0, NULL
    // 0xde939c: b.eq            #0xde9dd0
    // 0xde93a0: r0 = DefaultTextStyle()
    //     0xde93a0: bl              #0xd0b11c  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xde93a4: mov             x1, x0
    // 0xde93a8: ldur            x0, [fp, #-0x88]
    // 0xde93ac: StoreField: r1->field_f = r0
    //     0xde93ac: stur            w0, [x1, #0xf]
    // 0xde93b0: r0 = false
    //     0xde93b0: add             x0, NULL, #0x30  ; false
    // 0xde93b4: ArrayStore: r1[0] = r0  ; List_4
    //     0xde93b4: stur            w0, [x1, #0x17]
    // 0xde93b8: r2 = Instance_TextOverflow
    //     0xde93b8: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1ac18] Obj!TextOverflow@12c47a1
    //     0xde93bc: ldr             x2, [x2, #0xc18]
    // 0xde93c0: StoreField: r1->field_1b = r2
    //     0xde93c0: stur            w2, [x1, #0x1b]
    // 0xde93c4: r2 = Instance_TextWidthBasis
    //     0xde93c4: add             x2, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xde93c8: ldr             x2, [x2, #0x110]
    // 0xde93cc: StoreField: r1->field_23 = r2
    //     0xde93cc: stur            w2, [x1, #0x23]
    // 0xde93d0: ldur            x3, [fp, #-0x48]
    // 0xde93d4: StoreField: r1->field_b = r3
    //     0xde93d4: stur            w3, [x1, #0xb]
    // 0xde93d8: r16 = 1.340000
    //     0xde93d8: add             x16, PP, #0x90, lsl #12  ; [pp+0x90d68] 1.34
    //     0xde93dc: ldr             x16, [x16, #0xd68]
    // 0xde93e0: str             x16, [SP]
    // 0xde93e4: r4 = const [0, 0x2, 0x1, 0x1, maxScaleFactor, 0x1, null]
    //     0xde93e4: add             x4, PP, #0x90, lsl #12  ; [pp+0x90d70] List(7) [0, 0x2, 0x1, 0x1, "maxScaleFactor", 0x1, Null]
    //     0xde93e8: ldr             x4, [x4, #0xd70]
    // 0xde93ec: r0 = withClampedTextScaling()
    //     0xde93ec: bl              #0xd16294  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::withClampedTextScaling
    // 0xde93f0: ldur            x1, [fp, #-8]
    // 0xde93f4: stur            x0, [fp, #-0x88]
    // 0xde93f8: LoadField: r2 = r1->field_b
    //     0xde93f8: ldur            w2, [x1, #0xb]
    // 0xde93fc: DecompressPointer r2
    //     0xde93fc: add             x2, x2, HEAP, lsl #32
    // 0xde9400: cmp             w2, NULL
    // 0xde9404: b.eq            #0xde9dd4
    // 0xde9408: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xde9408: ldur            w3, [x2, #0x17]
    // 0xde940c: DecompressPointer r3
    //     0xde940c: add             x3, x3, HEAP, lsl #32
    // 0xde9410: stur            x3, [fp, #-0x78]
    // 0xde9414: cmp             w3, NULL
    // 0xde9418: b.eq            #0xde94c4
    // 0xde941c: LoadField: r2 = r3->field_b
    //     0xde941c: ldur            w2, [x3, #0xb]
    // 0xde9420: cbz             w2, #0xde94bc
    // 0xde9424: ldur            x2, [fp, #-0x28]
    // 0xde9428: tbnz            w2, #4, #0xde9438
    // 0xde942c: r4 = Instance_CrossAxisAlignment
    //     0xde942c: add             x4, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xde9430: ldr             x4, [x4, #0x888]
    // 0xde9434: b               #0xde9440
    // 0xde9438: r4 = Instance_CrossAxisAlignment
    //     0xde9438: add             x4, PP, #0x7b, lsl #12  ; [pp+0x7bc40] Obj!CrossAxisAlignment@12c4521
    //     0xde943c: ldr             x4, [x4, #0xc40]
    // 0xde9440: stur            x4, [fp, #-0x48]
    // 0xde9444: r0 = Row()
    //     0xde9444: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xde9448: mov             x1, x0
    // 0xde944c: r0 = Instance_Axis
    //     0xde944c: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xde9450: stur            x1, [fp, #-0x90]
    // 0xde9454: StoreField: r1->field_f = r0
    //     0xde9454: stur            w0, [x1, #0xf]
    // 0xde9458: r0 = Instance_MainAxisAlignment
    //     0xde9458: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xde945c: ldr             x0, [x0, #0x820]
    // 0xde9460: StoreField: r1->field_13 = r0
    //     0xde9460: stur            w0, [x1, #0x13]
    // 0xde9464: r0 = Instance_MainAxisSize
    //     0xde9464: add             x0, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xde9468: ldr             x0, [x0, #0x200]
    // 0xde946c: ArrayStore: r1[0] = r0  ; List_4
    //     0xde946c: stur            w0, [x1, #0x17]
    // 0xde9470: ldur            x0, [fp, #-0x48]
    // 0xde9474: StoreField: r1->field_1b = r0
    //     0xde9474: stur            w0, [x1, #0x1b]
    // 0xde9478: r0 = Instance_VerticalDirection
    //     0xde9478: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xde947c: ldr             x0, [x0, #0x838]
    // 0xde9480: StoreField: r1->field_23 = r0
    //     0xde9480: stur            w0, [x1, #0x23]
    // 0xde9484: r2 = Instance_Clip
    //     0xde9484: add             x2, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xde9488: ldr             x2, [x2, #0x840]
    // 0xde948c: StoreField: r1->field_2b = r2
    //     0xde948c: stur            w2, [x1, #0x2b]
    // 0xde9490: StoreField: r1->field_2f = rZR
    //     0xde9490: stur            xzr, [x1, #0x2f]
    // 0xde9494: ldur            x3, [fp, #-0x78]
    // 0xde9498: StoreField: r1->field_b = r3
    //     0xde9498: stur            w3, [x1, #0xb]
    // 0xde949c: r0 = Padding()
    //     0xde949c: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xde94a0: mov             x1, x0
    // 0xde94a4: r0 = Instance_EdgeInsets
    //     0xde94a4: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xde94a8: StoreField: r1->field_f = r0
    //     0xde94a8: stur            w0, [x1, #0xf]
    // 0xde94ac: ldur            x2, [fp, #-0x90]
    // 0xde94b0: StoreField: r1->field_b = r2
    //     0xde94b0: stur            w2, [x1, #0xb]
    // 0xde94b4: mov             x2, x1
    // 0xde94b8: b               #0xde94d4
    // 0xde94bc: r0 = Instance_EdgeInsets
    //     0xde94bc: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xde94c0: b               #0xde94c8
    // 0xde94c4: r0 = Instance_EdgeInsets
    //     0xde94c4: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xde94c8: ldur            x1, [fp, #-0x40]
    // 0xde94cc: tbz             w1, #4, #0xde9d1c
    // 0xde94d0: r2 = Null
    //     0xde94d0: mov             x2, NULL
    // 0xde94d4: stur            x2, [fp, #-0x40]
    // 0xde94d8: cmp             w2, NULL
    // 0xde94dc: b.eq            #0xde9654
    // 0xde94e0: ldur            x3, [fp, #-0x60]
    // 0xde94e4: r17 = 5209
    //     0xde94e4: mov             x17, #0x1459
    // 0xde94e8: cmp             x3, x17
    // 0xde94ec: b.eq            #0xde956c
    // 0xde94f0: r17 = 5210
    //     0xde94f0: mov             x17, #0x145a
    // 0xde94f4: cmp             x3, x17
    // 0xde94f8: b.ne            #0xde956c
    // 0xde94fc: ldur            x1, [fp, #-0x38]
    // 0xde9500: LoadField: r0 = r1->field_53
    //     0xde9500: ldur            w0, [x1, #0x53]
    // 0xde9504: DecompressPointer r0
    //     0xde9504: add             x0, x0, HEAP, lsl #32
    // 0xde9508: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde950c: cmp             w0, w16
    // 0xde9510: b.ne            #0xde9520
    // 0xde9514: r2 = _colors
    //     0xde9514: add             x2, PP, #0x26, lsl #12  ; [pp+0x26588] Field <_AppBarDefaultsM3@25187611._colors@25187611>: late final (offset: 0x54)
    //     0xde9518: ldr             x2, [x2, #0x588]
    // 0xde951c: r0 = InitLateFinalInstanceField()
    //     0xde951c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xde9520: LoadField: r1 = r0->field_a3
    //     0xde9520: ldur            w1, [x0, #0xa3]
    // 0xde9524: DecompressPointer r1
    //     0xde9524: add             x1, x1, HEAP, lsl #32
    // 0xde9528: cmp             w1, NULL
    // 0xde952c: b.ne            #0xde9540
    // 0xde9530: LoadField: r1 = r0->field_7f
    //     0xde9530: ldur            w1, [x0, #0x7f]
    // 0xde9534: DecompressPointer r1
    //     0xde9534: add             x1, x1, HEAP, lsl #32
    // 0xde9538: mov             x0, x1
    // 0xde953c: b               #0xde9544
    // 0xde9540: mov             x0, x1
    // 0xde9544: stur            x0, [fp, #-0x48]
    // 0xde9548: r0 = IconThemeData()
    //     0xde9548: bl              #0x8ac78c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0xde954c: mov             x1, x0
    // 0xde9550: r0 = 24.000000
    //     0xde9550: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0xde9554: ldr             x0, [x0, #0x4d0]
    // 0xde9558: StoreField: r1->field_7 = r0
    //     0xde9558: stur            w0, [x1, #7]
    // 0xde955c: ldur            x0, [fp, #-0x48]
    // 0xde9560: StoreField: r1->field_1b = r0
    //     0xde9560: stur            w0, [x1, #0x1b]
    // 0xde9564: ldur            x0, [fp, #-0x38]
    // 0xde9568: b               #0xde9578
    // 0xde956c: ldur            x0, [fp, #-0x38]
    // 0xde9570: LoadField: r1 = r0->field_27
    //     0xde9570: ldur            w1, [x0, #0x27]
    // 0xde9574: DecompressPointer r1
    //     0xde9574: add             x1, x1, HEAP, lsl #32
    // 0xde9578: ldur            x16, [fp, #-0x68]
    // 0xde957c: stp             x1, x16, [SP]
    // 0xde9580: r0 = ==()
    //     0xde9580: bl              #0x12625cc  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::==
    // 0xde9584: tbnz            w0, #4, #0xde9590
    // 0xde9588: ldur            x0, [fp, #-0x20]
    // 0xde958c: b               #0xde9620
    // 0xde9590: ldur            x0, [fp, #-0x20]
    // 0xde9594: ldur            x2, [fp, #-0x68]
    // 0xde9598: LoadField: r1 = r2->field_1b
    //     0xde9598: ldur            w1, [x2, #0x1b]
    // 0xde959c: DecompressPointer r1
    //     0xde959c: add             x1, x1, HEAP, lsl #32
    // 0xde95a0: LoadField: r3 = r2->field_7
    //     0xde95a0: ldur            w3, [x2, #7]
    // 0xde95a4: DecompressPointer r3
    //     0xde95a4: add             x3, x3, HEAP, lsl #32
    // 0xde95a8: stp             x3, x1, [SP]
    // 0xde95ac: r4 = const [0, 0x2, 0x2, 0, foregroundColor, 0, iconSize, 0x1, null]
    //     0xde95ac: add             x4, PP, #0x90, lsl #12  ; [pp+0x90d50] List(9) [0, 0x2, 0x2, 0, "foregroundColor", 0, "iconSize", 0x1, Null]
    //     0xde95b0: ldr             x4, [x4, #0xd50]
    // 0xde95b4: r0 = styleFrom()
    //     0xde95b4: bl              #0xdea068  ; [package:flutter/src/material/icon_button.dart] IconButton::styleFrom
    // 0xde95b8: mov             x1, x0
    // 0xde95bc: ldur            x0, [fp, #-0x20]
    // 0xde95c0: LoadField: r2 = r0->field_7
    //     0xde95c0: ldur            w2, [x0, #7]
    // 0xde95c4: DecompressPointer r2
    //     0xde95c4: add             x2, x2, HEAP, lsl #32
    // 0xde95c8: cmp             w2, NULL
    // 0xde95cc: b.ne            #0xde95d8
    // 0xde95d0: r0 = Null
    //     0xde95d0: mov             x0, NULL
    // 0xde95d4: b               #0xde9608
    // 0xde95d8: LoadField: r0 = r1->field_f
    //     0xde95d8: ldur            w0, [x1, #0xf]
    // 0xde95dc: DecompressPointer r0
    //     0xde95dc: add             x0, x0, HEAP, lsl #32
    // 0xde95e0: LoadField: r3 = r1->field_13
    //     0xde95e0: ldur            w3, [x1, #0x13]
    // 0xde95e4: DecompressPointer r3
    //     0xde95e4: add             x3, x3, HEAP, lsl #32
    // 0xde95e8: LoadField: r4 = r1->field_37
    //     0xde95e8: ldur            w4, [x1, #0x37]
    // 0xde95ec: DecompressPointer r4
    //     0xde95ec: add             x4, x4, HEAP, lsl #32
    // 0xde95f0: stp             x3, x0, [SP, #8]
    // 0xde95f4: str             x4, [SP]
    // 0xde95f8: mov             x1, x2
    // 0xde95fc: r4 = const [0, 0x4, 0x3, 0x1, foregroundColor, 0x1, iconSize, 0x3, overlayColor, 0x2, null]
    //     0xde95fc: add             x4, PP, #0x90, lsl #12  ; [pp+0x90d58] List(11) [0, 0x4, 0x3, 0x1, "foregroundColor", 0x1, "iconSize", 0x3, "overlayColor", 0x2, Null]
    //     0xde9600: ldr             x4, [x4, #0xd58]
    // 0xde9604: r0 = copyWith()
    //     0xde9604: bl              #0xd2991c  ; [package:flutter/src/material/button_style.dart] ButtonStyle::copyWith
    // 0xde9608: stur            x0, [fp, #-0x20]
    // 0xde960c: r0 = IconButtonThemeData()
    //     0xde960c: bl              #0xd29654  ; AllocateIconButtonThemeDataStub -> IconButtonThemeData (size=0xc)
    // 0xde9610: mov             x1, x0
    // 0xde9614: ldur            x0, [fp, #-0x20]
    // 0xde9618: StoreField: r1->field_7 = r0
    //     0xde9618: stur            w0, [x1, #7]
    // 0xde961c: mov             x0, x1
    // 0xde9620: ldur            x1, [fp, #-0x40]
    // 0xde9624: ldur            x2, [fp, #-0x68]
    // 0xde9628: stur            x0, [fp, #-0x20]
    // 0xde962c: r0 = merge()
    //     0xde962c: bl              #0xd0c588  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::merge
    // 0xde9630: stur            x0, [fp, #-0x48]
    // 0xde9634: r0 = IconButtonTheme()
    //     0xde9634: bl              #0xd29648  ; AllocateIconButtonThemeStub -> IconButtonTheme (size=0x14)
    // 0xde9638: mov             x1, x0
    // 0xde963c: ldur            x0, [fp, #-0x20]
    // 0xde9640: StoreField: r1->field_f = r0
    //     0xde9640: stur            w0, [x1, #0xf]
    // 0xde9644: ldur            x0, [fp, #-0x48]
    // 0xde9648: StoreField: r1->field_b = r0
    //     0xde9648: stur            w0, [x1, #0xb]
    // 0xde964c: mov             x4, x1
    // 0xde9650: b               #0xde9658
    // 0xde9654: ldur            x4, [fp, #-0x40]
    // 0xde9658: ldur            x0, [fp, #-8]
    // 0xde965c: stur            x4, [fp, #-0x20]
    // 0xde9660: LoadField: r1 = r0->field_b
    //     0xde9660: ldur            w1, [x0, #0xb]
    // 0xde9664: DecompressPointer r1
    //     0xde9664: add             x1, x1, HEAP, lsl #32
    // 0xde9668: cmp             w1, NULL
    // 0xde966c: b.eq            #0xde9dd8
    // 0xde9670: ldur            x2, [fp, #-0x18]
    // 0xde9674: ldur            x3, [fp, #-0x30]
    // 0xde9678: r0 = _getEffectiveCenterTitle()
    //     0xde9678: bl              #0xde9eec  ; [package:flutter/src/material/app_bar.dart] AppBar::_getEffectiveCenterTitle
    // 0xde967c: ldur            x1, [fp, #-8]
    // 0xde9680: stur            x0, [fp, #-0x40]
    // 0xde9684: LoadField: r2 = r1->field_b
    //     0xde9684: ldur            w2, [x1, #0xb]
    // 0xde9688: DecompressPointer r2
    //     0xde9688: add             x2, x2, HEAP, lsl #32
    // 0xde968c: cmp             w2, NULL
    // 0xde9690: b.eq            #0xde9ddc
    // 0xde9694: LoadField: r3 = r2->field_57
    //     0xde9694: ldur            w3, [x2, #0x57]
    // 0xde9698: DecompressPointer r3
    //     0xde9698: add             x3, x3, HEAP, lsl #32
    // 0xde969c: cmp             w3, NULL
    // 0xde96a0: b.ne            #0xde96b4
    // 0xde96a4: ldur            x2, [fp, #-0x30]
    // 0xde96a8: LoadField: r3 = r2->field_2f
    //     0xde96a8: ldur            w3, [x2, #0x2f]
    // 0xde96ac: DecompressPointer r3
    //     0xde96ac: add             x3, x3, HEAP, lsl #32
    // 0xde96b0: b               #0xde96b8
    // 0xde96b4: ldur            x2, [fp, #-0x30]
    // 0xde96b8: cmp             w3, NULL
    // 0xde96bc: b.ne            #0xde96c8
    // 0xde96c0: d1 = 16.000000
    //     0xde96c0: fmov            d1, #16.00000000
    // 0xde96c4: b               #0xde96d0
    // 0xde96c8: LoadField: d0 = r3->field_7
    //     0xde96c8: ldur            d0, [x3, #7]
    // 0xde96cc: mov             v1.16b, v0.16b
    // 0xde96d0: ldur            d0, [fp, #-0xb8]
    // 0xde96d4: ldur            x6, [fp, #-0x70]
    // 0xde96d8: ldur            x5, [fp, #-0x58]
    // 0xde96dc: ldur            x4, [fp, #-0x88]
    // 0xde96e0: ldur            x3, [fp, #-0x20]
    // 0xde96e4: stur            d1, [fp, #-0xc0]
    // 0xde96e8: r0 = NavigationToolbar()
    //     0xde96e8: bl              #0xde9ee0  ; AllocateNavigationToolbarStub -> NavigationToolbar (size=0x24)
    // 0xde96ec: mov             x1, x0
    // 0xde96f0: ldur            x0, [fp, #-0x58]
    // 0xde96f4: stur            x1, [fp, #-0x48]
    // 0xde96f8: StoreField: r1->field_b = r0
    //     0xde96f8: stur            w0, [x1, #0xb]
    // 0xde96fc: ldur            x0, [fp, #-0x88]
    // 0xde9700: StoreField: r1->field_f = r0
    //     0xde9700: stur            w0, [x1, #0xf]
    // 0xde9704: ldur            x0, [fp, #-0x20]
    // 0xde9708: StoreField: r1->field_13 = r0
    //     0xde9708: stur            w0, [x1, #0x13]
    // 0xde970c: ldur            x0, [fp, #-0x40]
    // 0xde9710: ArrayStore: r1[0] = r0  ; List_4
    //     0xde9710: stur            w0, [x1, #0x17]
    // 0xde9714: ldur            d0, [fp, #-0xc0]
    // 0xde9718: StoreField: r1->field_1b = d0
    //     0xde9718: stur            d0, [x1, #0x1b]
    // 0xde971c: r0 = _ToolbarContainerLayout()
    //     0xde971c: bl              #0xde9ed4  ; Allocate_ToolbarContainerLayoutStub -> _ToolbarContainerLayout (size=0x14)
    // 0xde9720: ldur            d0, [fp, #-0xb8]
    // 0xde9724: stur            x0, [fp, #-0x20]
    // 0xde9728: StoreField: r0->field_b = d0
    //     0xde9728: stur            d0, [x0, #0xb]
    // 0xde972c: ldur            x1, [fp, #-0x70]
    // 0xde9730: cmp             w1, NULL
    // 0xde9734: b.eq            #0xde9de0
    // 0xde9738: r0 = DefaultTextStyle()
    //     0xde9738: bl              #0xd0b11c  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xde973c: mov             x1, x0
    // 0xde9740: ldur            x0, [fp, #-0x70]
    // 0xde9744: StoreField: r1->field_f = r0
    //     0xde9744: stur            w0, [x1, #0xf]
    // 0xde9748: r0 = true
    //     0xde9748: add             x0, NULL, #0x20  ; true
    // 0xde974c: ArrayStore: r1[0] = r0  ; List_4
    //     0xde974c: stur            w0, [x1, #0x17]
    // 0xde9750: r2 = Instance_TextOverflow
    //     0xde9750: add             x2, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xde9754: ldr             x2, [x2, #0x108]
    // 0xde9758: StoreField: r1->field_1b = r2
    //     0xde9758: stur            w2, [x1, #0x1b]
    // 0xde975c: r2 = Instance_TextWidthBasis
    //     0xde975c: add             x2, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xde9760: ldr             x2, [x2, #0x110]
    // 0xde9764: StoreField: r1->field_23 = r2
    //     0xde9764: stur            w2, [x1, #0x23]
    // 0xde9768: ldur            x2, [fp, #-0x48]
    // 0xde976c: StoreField: r1->field_b = r2
    //     0xde976c: stur            w2, [x1, #0xb]
    // 0xde9770: ldur            x2, [fp, #-0x50]
    // 0xde9774: r0 = merge()
    //     0xde9774: bl              #0xd0c588  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::merge
    // 0xde9778: stur            x0, [fp, #-0x40]
    // 0xde977c: r0 = CustomSingleChildLayout()
    //     0xde977c: bl              #0xd70b7c  ; AllocateCustomSingleChildLayoutStub -> CustomSingleChildLayout (size=0x14)
    // 0xde9780: mov             x1, x0
    // 0xde9784: ldur            x0, [fp, #-0x20]
    // 0xde9788: stur            x1, [fp, #-0x48]
    // 0xde978c: StoreField: r1->field_f = r0
    //     0xde978c: stur            w0, [x1, #0xf]
    // 0xde9790: ldur            x0, [fp, #-0x40]
    // 0xde9794: StoreField: r1->field_b = r0
    //     0xde9794: stur            w0, [x1, #0xb]
    // 0xde9798: r0 = ClipRect()
    //     0xde9798: bl              #0xd5c118  ; AllocateClipRectStub -> ClipRect (size=0x18)
    // 0xde979c: mov             x1, x0
    // 0xde97a0: r0 = Instance_Clip
    //     0xde97a0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xde97a4: ldr             x0, [x0, #0x850]
    // 0xde97a8: stur            x1, [fp, #-0x40]
    // 0xde97ac: StoreField: r1->field_13 = r0
    //     0xde97ac: stur            w0, [x1, #0x13]
    // 0xde97b0: ldur            x0, [fp, #-0x48]
    // 0xde97b4: StoreField: r1->field_b = r0
    //     0xde97b4: stur            w0, [x1, #0xb]
    // 0xde97b8: ldur            x0, [fp, #-8]
    // 0xde97bc: LoadField: r2 = r0->field_b
    //     0xde97bc: ldur            w2, [x0, #0xb]
    // 0xde97c0: DecompressPointer r2
    //     0xde97c0: add             x2, x2, HEAP, lsl #32
    // 0xde97c4: cmp             w2, NULL
    // 0xde97c8: b.eq            #0xde9de4
    // 0xde97cc: LoadField: r3 = r2->field_1f
    //     0xde97cc: ldur            w3, [x2, #0x1f]
    // 0xde97d0: DecompressPointer r3
    //     0xde97d0: add             x3, x3, HEAP, lsl #32
    // 0xde97d4: stur            x3, [fp, #-0x20]
    // 0xde97d8: cmp             w3, NULL
    // 0xde97dc: b.eq            #0xde9a0c
    // 0xde97e0: ldur            d0, [fp, #-0xb8]
    // 0xde97e4: r0 = BoxConstraints()
    //     0xde97e4: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xde97e8: stur            x0, [fp, #-0x48]
    // 0xde97ec: StoreField: r0->field_7 = rZR
    //     0xde97ec: stur            xzr, [x0, #7]
    // 0xde97f0: d0 = inf
    //     0xde97f0: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xde97f4: StoreField: r0->field_f = d0
    //     0xde97f4: stur            d0, [x0, #0xf]
    // 0xde97f8: ArrayStore: r0[0] = rZR  ; List_8
    //     0xde97f8: stur            xzr, [x0, #0x17]
    // 0xde97fc: ldur            d0, [fp, #-0xb8]
    // 0xde9800: StoreField: r0->field_1f = d0
    //     0xde9800: stur            d0, [x0, #0x1f]
    // 0xde9804: r0 = ConstrainedBox()
    //     0xde9804: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xde9808: mov             x2, x0
    // 0xde980c: ldur            x0, [fp, #-0x48]
    // 0xde9810: stur            x2, [fp, #-0x50]
    // 0xde9814: StoreField: r2->field_f = r0
    //     0xde9814: stur            w0, [x2, #0xf]
    // 0xde9818: ldur            x0, [fp, #-0x40]
    // 0xde981c: StoreField: r2->field_b = r0
    //     0xde981c: stur            w0, [x2, #0xb]
    // 0xde9820: r1 = <FlexParentData>
    //     0xde9820: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xde9824: ldr             x1, [x1, #0x878]
    // 0xde9828: r0 = Flexible()
    //     0xde9828: bl              #0xd0fd68  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0xde982c: mov             x3, x0
    // 0xde9830: r0 = 1
    //     0xde9830: mov             x0, #1
    // 0xde9834: stur            x3, [fp, #-0x48]
    // 0xde9838: StoreField: r3->field_13 = r0
    //     0xde9838: stur            x0, [x3, #0x13]
    // 0xde983c: r0 = Instance_FlexFit
    //     0xde983c: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ac30] Obj!FlexFit@12c4661
    //     0xde9840: ldr             x0, [x0, #0xc30]
    // 0xde9844: StoreField: r3->field_1b = r0
    //     0xde9844: stur            w0, [x3, #0x1b]
    // 0xde9848: ldur            x0, [fp, #-0x50]
    // 0xde984c: StoreField: r3->field_b = r0
    //     0xde984c: stur            w0, [x3, #0xb]
    // 0xde9850: r1 = Null
    //     0xde9850: mov             x1, NULL
    // 0xde9854: r2 = 2
    //     0xde9854: mov             x2, #2
    // 0xde9858: r0 = AllocateArray()
    //     0xde9858: bl              #0x13df928  ; AllocateArrayStub
    // 0xde985c: mov             x2, x0
    // 0xde9860: ldur            x0, [fp, #-0x48]
    // 0xde9864: stur            x2, [fp, #-0x50]
    // 0xde9868: StoreField: r2->field_f = r0
    //     0xde9868: stur            w0, [x2, #0xf]
    // 0xde986c: r1 = <Widget>
    //     0xde986c: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xde9870: r0 = AllocateGrowableArray()
    //     0xde9870: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xde9874: mov             x2, x0
    // 0xde9878: ldur            x0, [fp, #-0x50]
    // 0xde987c: stur            x2, [fp, #-0x48]
    // 0xde9880: StoreField: r2->field_f = r0
    //     0xde9880: stur            w0, [x2, #0xf]
    // 0xde9884: r0 = 2
    //     0xde9884: mov             x0, #2
    // 0xde9888: StoreField: r2->field_b = r0
    //     0xde9888: stur            w0, [x2, #0xb]
    // 0xde988c: d0 = 1.000000
    //     0xde988c: fmov            d0, #1.00000000
    // 0xde9890: fcmp            d0, d0
    // 0xde9894: b.ne            #0xde98e0
    // 0xde9898: mov             x1, x2
    // 0xde989c: r0 = _growToNextCapacity()
    //     0xde989c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xde98a0: ldur            x2, [fp, #-0x48]
    // 0xde98a4: r0 = 4
    //     0xde98a4: mov             x0, #4
    // 0xde98a8: StoreField: r2->field_b = r0
    //     0xde98a8: stur            w0, [x2, #0xb]
    // 0xde98ac: LoadField: r1 = r2->field_f
    //     0xde98ac: ldur            w1, [x2, #0xf]
    // 0xde98b0: DecompressPointer r1
    //     0xde98b0: add             x1, x1, HEAP, lsl #32
    // 0xde98b4: ldur            x0, [fp, #-0x20]
    // 0xde98b8: ArrayStore: r1[1] = r0  ; List_4
    //     0xde98b8: add             x25, x1, #0x13
    //     0xde98bc: str             w0, [x25]
    //     0xde98c0: tbz             w0, #0, #0xde98dc
    //     0xde98c4: ldurb           w16, [x1, #-1]
    //     0xde98c8: ldurb           w17, [x0, #-1]
    //     0xde98cc: and             x16, x17, x16, lsr #2
    //     0xde98d0: tst             x16, HEAP, lsr #32
    //     0xde98d4: b.eq            #0xde98dc
    //     0xde98d8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xde98dc: b               #0xde99ac
    // 0xde98e0: ldur            x0, [fp, #-8]
    // 0xde98e4: r1 = Instance_Interval
    //     0xde98e4: add             x1, PP, #0x90, lsl #12  ; [pp+0x90d18] Obj!Interval@129fa71
    //     0xde98e8: ldr             x1, [x1, #0xd18]
    // 0xde98ec: r0 = transform()
    //     0xde98ec: bl              #0x12f4dac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0xde98f0: ldur            x1, [fp, #-8]
    // 0xde98f4: stur            d0, [fp, #-0xb8]
    // 0xde98f8: LoadField: r0 = r1->field_b
    //     0xde98f8: ldur            w0, [x1, #0xb]
    // 0xde98fc: DecompressPointer r0
    //     0xde98fc: add             x0, x0, HEAP, lsl #32
    // 0xde9900: cmp             w0, NULL
    // 0xde9904: b.eq            #0xde9de8
    // 0xde9908: LoadField: r2 = r0->field_1f
    //     0xde9908: ldur            w2, [x0, #0x1f]
    // 0xde990c: DecompressPointer r2
    //     0xde990c: add             x2, x2, HEAP, lsl #32
    // 0xde9910: stur            x2, [fp, #-0x20]
    // 0xde9914: r0 = Opacity()
    //     0xde9914: bl              #0xd3015c  ; AllocateOpacityStub -> Opacity (size=0x1c)
    // 0xde9918: ldur            d0, [fp, #-0xb8]
    // 0xde991c: stur            x0, [fp, #-0x50]
    // 0xde9920: StoreField: r0->field_f = d0
    //     0xde9920: stur            d0, [x0, #0xf]
    // 0xde9924: r2 = false
    //     0xde9924: add             x2, NULL, #0x30  ; false
    // 0xde9928: ArrayStore: r0[0] = r2  ; List_4
    //     0xde9928: stur            w2, [x0, #0x17]
    // 0xde992c: ldur            x1, [fp, #-0x20]
    // 0xde9930: StoreField: r0->field_b = r1
    //     0xde9930: stur            w1, [x0, #0xb]
    // 0xde9934: ldur            x3, [fp, #-0x48]
    // 0xde9938: LoadField: r1 = r3->field_b
    //     0xde9938: ldur            w1, [x3, #0xb]
    // 0xde993c: LoadField: r4 = r3->field_f
    //     0xde993c: ldur            w4, [x3, #0xf]
    // 0xde9940: DecompressPointer r4
    //     0xde9940: add             x4, x4, HEAP, lsl #32
    // 0xde9944: LoadField: r5 = r4->field_b
    //     0xde9944: ldur            w5, [x4, #0xb]
    // 0xde9948: r4 = LoadInt32Instr(r1)
    //     0xde9948: sbfx            x4, x1, #1, #0x1f
    // 0xde994c: stur            x4, [fp, #-0xa8]
    // 0xde9950: r1 = LoadInt32Instr(r5)
    //     0xde9950: sbfx            x1, x5, #1, #0x1f
    // 0xde9954: cmp             x4, x1
    // 0xde9958: b.ne            #0xde9964
    // 0xde995c: mov             x1, x3
    // 0xde9960: r0 = _growToNextCapacity()
    //     0xde9960: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xde9964: ldur            x2, [fp, #-0x48]
    // 0xde9968: ldur            x3, [fp, #-0xa8]
    // 0xde996c: add             x0, x3, #1
    // 0xde9970: lsl             x1, x0, #1
    // 0xde9974: StoreField: r2->field_b = r1
    //     0xde9974: stur            w1, [x2, #0xb]
    // 0xde9978: LoadField: r1 = r2->field_f
    //     0xde9978: ldur            w1, [x2, #0xf]
    // 0xde997c: DecompressPointer r1
    //     0xde997c: add             x1, x1, HEAP, lsl #32
    // 0xde9980: ldur            x0, [fp, #-0x50]
    // 0xde9984: ArrayStore: r1[r3] = r0  ; List_4
    //     0xde9984: add             x25, x1, x3, lsl #2
    //     0xde9988: add             x25, x25, #0xf
    //     0xde998c: str             w0, [x25]
    //     0xde9990: tbz             w0, #0, #0xde99ac
    //     0xde9994: ldurb           w16, [x1, #-1]
    //     0xde9998: ldurb           w17, [x0, #-1]
    //     0xde999c: and             x16, x17, x16, lsr #2
    //     0xde99a0: tst             x16, HEAP, lsr #32
    //     0xde99a4: b.eq            #0xde99ac
    //     0xde99a8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xde99ac: r0 = Column()
    //     0xde99ac: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xde99b0: mov             x1, x0
    // 0xde99b4: r0 = Instance_Axis
    //     0xde99b4: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xde99b8: StoreField: r1->field_f = r0
    //     0xde99b8: stur            w0, [x1, #0xf]
    // 0xde99bc: r0 = Instance_MainAxisAlignment
    //     0xde99bc: add             x0, PP, #0x17, lsl #12  ; [pp+0x177b0] Obj!MainAxisAlignment@12c45c1
    //     0xde99c0: ldr             x0, [x0, #0x7b0]
    // 0xde99c4: StoreField: r1->field_13 = r0
    //     0xde99c4: stur            w0, [x1, #0x13]
    // 0xde99c8: r0 = Instance_MainAxisSize
    //     0xde99c8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xde99cc: ldr             x0, [x0, #0x828]
    // 0xde99d0: ArrayStore: r1[0] = r0  ; List_4
    //     0xde99d0: stur            w0, [x1, #0x17]
    // 0xde99d4: r0 = Instance_CrossAxisAlignment
    //     0xde99d4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xde99d8: ldr             x0, [x0, #0x888]
    // 0xde99dc: StoreField: r1->field_1b = r0
    //     0xde99dc: stur            w0, [x1, #0x1b]
    // 0xde99e0: r0 = Instance_VerticalDirection
    //     0xde99e0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xde99e4: ldr             x0, [x0, #0x838]
    // 0xde99e8: StoreField: r1->field_23 = r0
    //     0xde99e8: stur            w0, [x1, #0x23]
    // 0xde99ec: r2 = Instance_Clip
    //     0xde99ec: add             x2, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xde99f0: ldr             x2, [x2, #0x840]
    // 0xde99f4: StoreField: r1->field_2b = r2
    //     0xde99f4: stur            w2, [x1, #0x2b]
    // 0xde99f8: StoreField: r1->field_2f = rZR
    //     0xde99f8: stur            xzr, [x1, #0x2f]
    // 0xde99fc: ldur            x0, [fp, #-0x48]
    // 0xde9a00: StoreField: r1->field_b = r0
    //     0xde9a00: stur            w0, [x1, #0xb]
    // 0xde9a04: mov             x0, x1
    // 0xde9a08: b               #0xde9a18
    // 0xde9a0c: mov             x0, x1
    // 0xde9a10: r2 = Instance_Clip
    //     0xde9a10: add             x2, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xde9a14: ldr             x2, [x2, #0x840]
    // 0xde9a18: ldur            x1, [fp, #-8]
    // 0xde9a1c: stur            x0, [fp, #-0x40]
    // 0xde9a20: LoadField: r3 = r1->field_b
    //     0xde9a20: ldur            w3, [x1, #0xb]
    // 0xde9a24: DecompressPointer r3
    //     0xde9a24: add             x3, x3, HEAP, lsl #32
    // 0xde9a28: stur            x3, [fp, #-0x20]
    // 0xde9a2c: cmp             w3, NULL
    // 0xde9a30: b.eq            #0xde9dec
    // 0xde9a34: r0 = SafeArea()
    //     0xde9a34: bl              #0xd73100  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0xde9a38: mov             x1, x0
    // 0xde9a3c: r0 = true
    //     0xde9a3c: add             x0, NULL, #0x20  ; true
    // 0xde9a40: stur            x1, [fp, #-0x48]
    // 0xde9a44: StoreField: r1->field_b = r0
    //     0xde9a44: stur            w0, [x1, #0xb]
    // 0xde9a48: StoreField: r1->field_f = r0
    //     0xde9a48: stur            w0, [x1, #0xf]
    // 0xde9a4c: StoreField: r1->field_13 = r0
    //     0xde9a4c: stur            w0, [x1, #0x13]
    // 0xde9a50: r2 = false
    //     0xde9a50: add             x2, NULL, #0x30  ; false
    // 0xde9a54: ArrayStore: r1[0] = r2  ; List_4
    //     0xde9a54: stur            w2, [x1, #0x17]
    // 0xde9a58: r3 = Instance_EdgeInsets
    //     0xde9a58: ldr             x3, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xde9a5c: StoreField: r1->field_1b = r3
    //     0xde9a5c: stur            w3, [x1, #0x1b]
    // 0xde9a60: StoreField: r1->field_1f = r2
    //     0xde9a60: stur            w2, [x1, #0x1f]
    // 0xde9a64: ldur            x3, [fp, #-0x40]
    // 0xde9a68: StoreField: r1->field_23 = r3
    //     0xde9a68: stur            w3, [x1, #0x23]
    // 0xde9a6c: r0 = Align()
    //     0xde9a6c: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xde9a70: mov             x2, x0
    // 0xde9a74: r0 = Instance_Alignment
    //     0xde9a74: add             x0, PP, #0x19, lsl #12  ; [pp+0x197a8] Obj!Alignment@129e7d1
    //     0xde9a78: ldr             x0, [x0, #0x7a8]
    // 0xde9a7c: stur            x2, [fp, #-0x40]
    // 0xde9a80: StoreField: r2->field_f = r0
    //     0xde9a80: stur            w0, [x2, #0xf]
    // 0xde9a84: ldur            x0, [fp, #-0x48]
    // 0xde9a88: StoreField: r2->field_b = r0
    //     0xde9a88: stur            w0, [x2, #0xb]
    // 0xde9a8c: ldur            x0, [fp, #-0x20]
    // 0xde9a90: LoadField: r1 = r0->field_7f
    //     0xde9a90: ldur            w1, [x0, #0x7f]
    // 0xde9a94: DecompressPointer r1
    //     0xde9a94: add             x1, x1, HEAP, lsl #32
    // 0xde9a98: cmp             w1, NULL
    // 0xde9a9c: b.ne            #0xde9ab0
    // 0xde9aa0: ldur            x0, [fp, #-0x30]
    // 0xde9aa4: LoadField: r1 = r0->field_43
    //     0xde9aa4: ldur            w1, [x0, #0x43]
    // 0xde9aa8: DecompressPointer r1
    //     0xde9aa8: add             x1, x1, HEAP, lsl #32
    // 0xde9aac: b               #0xde9ab4
    // 0xde9ab0: ldur            x0, [fp, #-0x30]
    // 0xde9ab4: cmp             w1, NULL
    // 0xde9ab8: b.ne            #0xde9acc
    // 0xde9abc: ldur            x3, [fp, #-0x38]
    // 0xde9ac0: LoadField: r1 = r3->field_43
    //     0xde9ac0: ldur            w1, [x3, #0x43]
    // 0xde9ac4: DecompressPointer r1
    //     0xde9ac4: add             x1, x1, HEAP, lsl #32
    // 0xde9ac8: b               #0xde9ad0
    // 0xde9acc: ldur            x3, [fp, #-0x38]
    // 0xde9ad0: cmp             w1, NULL
    // 0xde9ad4: b.ne            #0xde9b10
    // 0xde9ad8: ldur            x4, [fp, #-0x28]
    // 0xde9adc: ldur            x1, [fp, #-0x10]
    // 0xde9ae0: r0 = estimateBrightnessForColor()
    //     0xde9ae0: bl              #0x8ad774  ; [package:flutter/src/material/theme_data.dart] ThemeData::estimateBrightnessForColor
    // 0xde9ae4: mov             x1, x0
    // 0xde9ae8: ldur            x0, [fp, #-0x28]
    // 0xde9aec: tbnz            w0, #4, #0xde9afc
    // 0xde9af0: r3 = Instance_Color
    //     0xde9af0: add             x3, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xde9af4: ldr             x3, [x3, #0x810]
    // 0xde9af8: b               #0xde9b00
    // 0xde9afc: r3 = Null
    //     0xde9afc: mov             x3, NULL
    // 0xde9b00: mov             x2, x1
    // 0xde9b04: ldur            x1, [fp, #-8]
    // 0xde9b08: r0 = _systemOverlayStyleForBrightness()
    //     0xde9b08: bl              #0xde9e64  ; [package:flutter/src/material/app_bar.dart] _AppBarState::_systemOverlayStyleForBrightness
    // 0xde9b0c: mov             x1, x0
    // 0xde9b10: ldur            x0, [fp, #-0x28]
    // 0xde9b14: stur            x1, [fp, #-0x50]
    // 0xde9b18: tbnz            w0, #4, #0xde9b24
    // 0xde9b1c: ldur            x3, [fp, #-0x10]
    // 0xde9b20: b               #0xde9b28
    // 0xde9b24: ldur            x3, [fp, #-0x80]
    // 0xde9b28: ldur            x2, [fp, #-8]
    // 0xde9b2c: stur            x3, [fp, #-0x48]
    // 0xde9b30: LoadField: r4 = r2->field_b
    //     0xde9b30: ldur            w4, [x2, #0xb]
    // 0xde9b34: DecompressPointer r4
    //     0xde9b34: add             x4, x4, HEAP, lsl #32
    // 0xde9b38: cmp             w4, NULL
    // 0xde9b3c: b.eq            #0xde9df0
    // 0xde9b40: LoadField: r2 = r4->field_2f
    //     0xde9b40: ldur            w2, [x4, #0x2f]
    // 0xde9b44: DecompressPointer r2
    //     0xde9b44: add             x2, x2, HEAP, lsl #32
    // 0xde9b48: cmp             w2, NULL
    // 0xde9b4c: b.ne            #0xde9b60
    // 0xde9b50: ldur            x2, [fp, #-0x30]
    // 0xde9b54: ArrayLoad: r5 = r2[0]  ; List_4
    //     0xde9b54: ldur            w5, [x2, #0x17]
    // 0xde9b58: DecompressPointer r5
    //     0xde9b58: add             x5, x5, HEAP, lsl #32
    // 0xde9b5c: mov             x2, x5
    // 0xde9b60: cmp             w2, NULL
    // 0xde9b64: b.ne            #0xde9ba0
    // 0xde9b68: ldur            x2, [fp, #-0x60]
    // 0xde9b6c: r17 = 5209
    //     0xde9b6c: mov             x17, #0x1459
    // 0xde9b70: cmp             x2, x17
    // 0xde9b74: b.eq            #0xde9b90
    // 0xde9b78: r17 = 5210
    //     0xde9b78: mov             x17, #0x145a
    // 0xde9b7c: cmp             x2, x17
    // 0xde9b80: b.ne            #0xde9b90
    // 0xde9b84: r2 = Instance_Color
    //     0xde9b84: add             x2, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xde9b88: ldr             x2, [x2, #0x810]
    // 0xde9b8c: b               #0xde9ba0
    // 0xde9b90: ldur            x2, [fp, #-0x38]
    // 0xde9b94: ArrayLoad: r5 = r2[0]  ; List_4
    //     0xde9b94: ldur            w5, [x2, #0x17]
    // 0xde9b98: DecompressPointer r5
    //     0xde9b98: add             x5, x5, HEAP, lsl #32
    // 0xde9b9c: mov             x2, x5
    // 0xde9ba0: stur            x2, [fp, #-0x20]
    // 0xde9ba4: LoadField: r5 = r4->field_33
    //     0xde9ba4: ldur            w5, [x4, #0x33]
    // 0xde9ba8: DecompressPointer r5
    //     0xde9ba8: add             x5, x5, HEAP, lsl #32
    // 0xde9bac: cmp             w5, NULL
    // 0xde9bb0: b.ne            #0xde9bb8
    // 0xde9bb4: r5 = Null
    //     0xde9bb4: mov             x5, NULL
    // 0xde9bb8: cmp             w5, NULL
    // 0xde9bbc: b.ne            #0xde9bf4
    // 0xde9bc0: tbnz            w0, #4, #0xde9bec
    // 0xde9bc4: ldur            x0, [fp, #-0x18]
    // 0xde9bc8: LoadField: r5 = r0->field_3f
    //     0xde9bc8: ldur            w5, [x0, #0x3f]
    // 0xde9bcc: DecompressPointer r5
    //     0xde9bcc: add             x5, x5, HEAP, lsl #32
    // 0xde9bd0: LoadField: r0 = r5->field_c3
    //     0xde9bd0: ldur            w0, [x5, #0xc3]
    // 0xde9bd4: DecompressPointer r0
    //     0xde9bd4: add             x0, x0, HEAP, lsl #32
    // 0xde9bd8: cmp             w0, NULL
    // 0xde9bdc: b.ne            #0xde9bf8
    // 0xde9be0: LoadField: r0 = r5->field_b
    //     0xde9be0: ldur            w0, [x5, #0xb]
    // 0xde9be4: DecompressPointer r0
    //     0xde9be4: add             x0, x0, HEAP, lsl #32
    // 0xde9be8: b               #0xde9bf8
    // 0xde9bec: r0 = Null
    //     0xde9bec: mov             x0, NULL
    // 0xde9bf0: b               #0xde9bf8
    // 0xde9bf4: mov             x0, x5
    // 0xde9bf8: stur            x0, [fp, #-0x10]
    // 0xde9bfc: LoadField: r5 = r4->field_37
    //     0xde9bfc: ldur            w5, [x4, #0x37]
    // 0xde9c00: DecompressPointer r5
    //     0xde9c00: add             x5, x5, HEAP, lsl #32
    // 0xde9c04: cmp             w5, NULL
    // 0xde9c08: b.ne            #0xde9c14
    // 0xde9c0c: r4 = Null
    //     0xde9c0c: mov             x4, NULL
    // 0xde9c10: b               #0xde9c18
    // 0xde9c14: mov             x4, x5
    // 0xde9c18: cmp             w4, NULL
    // 0xde9c1c: b.ne            #0xde9c24
    // 0xde9c20: r4 = Null
    //     0xde9c20: mov             x4, NULL
    // 0xde9c24: ldur            d0, [fp, #-0xb0]
    // 0xde9c28: stur            x4, [fp, #-8]
    // 0xde9c2c: r0 = Semantics()
    //     0xde9c2c: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xde9c30: stur            x0, [fp, #-0x18]
    // 0xde9c34: r16 = true
    //     0xde9c34: add             x16, NULL, #0x20  ; true
    // 0xde9c38: ldur            lr, [fp, #-0x40]
    // 0xde9c3c: stp             lr, x16, [SP]
    // 0xde9c40: mov             x1, x0
    // 0xde9c44: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, explicitChildNodes, 0x1, null]
    //     0xde9c44: add             x4, PP, #0x80, lsl #12  ; [pp+0x80e48] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "explicitChildNodes", 0x1, Null]
    //     0xde9c48: ldr             x4, [x4, #0xe48]
    // 0xde9c4c: r0 = Semantics()
    //     0xde9c4c: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xde9c50: r0 = Material()
    //     0xde9c50: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xde9c54: mov             x2, x0
    // 0xde9c58: r0 = Instance_MaterialType
    //     0xde9c58: add             x0, PP, #0x17, lsl #12  ; [pp+0x17210] Obj!MaterialType@12c5341
    //     0xde9c5c: ldr             x0, [x0, #0x210]
    // 0xde9c60: stur            x2, [fp, #-0x28]
    // 0xde9c64: StoreField: r2->field_f = r0
    //     0xde9c64: stur            w0, [x2, #0xf]
    // 0xde9c68: ldur            d0, [fp, #-0xb0]
    // 0xde9c6c: ArrayStore: r2[0] = d0  ; List_8
    //     0xde9c6c: stur            d0, [x2, #0x17]
    // 0xde9c70: ldur            x0, [fp, #-0x48]
    // 0xde9c74: StoreField: r2->field_1f = r0
    //     0xde9c74: stur            w0, [x2, #0x1f]
    // 0xde9c78: ldur            x0, [fp, #-0x20]
    // 0xde9c7c: StoreField: r2->field_23 = r0
    //     0xde9c7c: stur            w0, [x2, #0x23]
    // 0xde9c80: ldur            x0, [fp, #-0x10]
    // 0xde9c84: StoreField: r2->field_27 = r0
    //     0xde9c84: stur            w0, [x2, #0x27]
    // 0xde9c88: ldur            x0, [fp, #-8]
    // 0xde9c8c: StoreField: r2->field_2f = r0
    //     0xde9c8c: stur            w0, [x2, #0x2f]
    // 0xde9c90: r0 = true
    //     0xde9c90: add             x0, NULL, #0x20  ; true
    // 0xde9c94: StoreField: r2->field_33 = r0
    //     0xde9c94: stur            w0, [x2, #0x33]
    // 0xde9c98: r1 = Instance_Clip
    //     0xde9c98: add             x1, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xde9c9c: ldr             x1, [x1, #0x840]
    // 0xde9ca0: StoreField: r2->field_37 = r1
    //     0xde9ca0: stur            w1, [x2, #0x37]
    // 0xde9ca4: r1 = Instance_Duration
    //     0xde9ca4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xde9ca8: ldr             x1, [x1, #0x318]
    // 0xde9cac: StoreField: r2->field_3b = r1
    //     0xde9cac: stur            w1, [x2, #0x3b]
    // 0xde9cb0: ldur            x1, [fp, #-0x18]
    // 0xde9cb4: StoreField: r2->field_b = r1
    //     0xde9cb4: stur            w1, [x2, #0xb]
    // 0xde9cb8: r1 = false
    //     0xde9cb8: add             x1, NULL, #0x30  ; false
    // 0xde9cbc: StoreField: r2->field_13 = r1
    //     0xde9cbc: stur            w1, [x2, #0x13]
    // 0xde9cc0: r1 = <SystemUiOverlayStyle>
    //     0xde9cc0: ldr             x1, [PP, #0x2c08]  ; [pp+0x2c08] TypeArguments: <SystemUiOverlayStyle>
    // 0xde9cc4: r0 = AnnotatedRegion()
    //     0xde9cc4: bl              #0xde9e58  ; AllocateAnnotatedRegionStub -> AnnotatedRegion<X0> (size=0x1c)
    // 0xde9cc8: mov             x1, x0
    // 0xde9ccc: ldur            x0, [fp, #-0x50]
    // 0xde9cd0: stur            x1, [fp, #-8]
    // 0xde9cd4: StoreField: r1->field_13 = r0
    //     0xde9cd4: stur            w0, [x1, #0x13]
    // 0xde9cd8: r0 = true
    //     0xde9cd8: add             x0, NULL, #0x20  ; true
    // 0xde9cdc: ArrayStore: r1[0] = r0  ; List_4
    //     0xde9cdc: stur            w0, [x1, #0x17]
    // 0xde9ce0: ldur            x0, [fp, #-0x28]
    // 0xde9ce4: StoreField: r1->field_b = r0
    //     0xde9ce4: stur            w0, [x1, #0xb]
    // 0xde9ce8: r0 = Semantics()
    //     0xde9ce8: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xde9cec: stur            x0, [fp, #-0x10]
    // 0xde9cf0: r16 = true
    //     0xde9cf0: add             x16, NULL, #0x20  ; true
    // 0xde9cf4: ldur            lr, [fp, #-8]
    // 0xde9cf8: stp             lr, x16, [SP]
    // 0xde9cfc: mov             x1, x0
    // 0xde9d00: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, container, 0x1, null]
    //     0xde9d00: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8c9b8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "container", 0x1, Null]
    //     0xde9d04: ldr             x4, [x4, #0x9b8]
    // 0xde9d08: r0 = Semantics()
    //     0xde9d08: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xde9d0c: ldur            x0, [fp, #-0x10]
    // 0xde9d10: LeaveFrame
    //     0xde9d10: mov             SP, fp
    //     0xde9d14: ldp             fp, lr, [SP], #0x10
    // 0xde9d18: ret
    //     0xde9d18: ret             
    // 0xde9d1c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xde9d1c: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xde9d20: r0 = Throw()
    //     0xde9d20: bl              #0x13ddb2c  ; ThrowStub
    // 0xde9d24: brk             #0
    // 0xde9d28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde9d28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde9d2c: b               #0xde82a4
    // 0xde9d30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde9d30: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde9d34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde9d34: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde9d38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde9d38: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde9d3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde9d3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde9d40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde9d40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde9d44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde9d44: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde9d48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde9d48: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde9d4c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xde9d4c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xde9d50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde9d50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde9d54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde9d54: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde9d58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde9d58: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde9d5c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xde9d5c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xde9d60: stp             q0, q2, [SP, #-0x20]!
    // 0xde9d64: SaveReg r1
    //     0xde9d64: str             x1, [SP, #-8]!
    // 0xde9d68: r0 = AllocateDouble()
    //     0xde9d68: bl              #0x13df878  ; AllocateDoubleStub
    // 0xde9d6c: RestoreReg r1
    //     0xde9d6c: ldr             x1, [SP], #8
    // 0xde9d70: ldp             q0, q2, [SP], #0x20
    // 0xde9d74: b               #0xde8e00
    // 0xde9d78: SaveReg d2
    //     0xde9d78: str             q2, [SP, #-0x10]!
    // 0xde9d7c: SaveReg r0
    //     0xde9d7c: str             x0, [SP, #-8]!
    // 0xde9d80: r0 = AllocateDouble()
    //     0xde9d80: bl              #0x13df878  ; AllocateDoubleStub
    // 0xde9d84: mov             x1, x0
    // 0xde9d88: RestoreReg r0
    //     0xde9d88: ldr             x0, [SP], #8
    // 0xde9d8c: RestoreReg d2
    //     0xde9d8c: ldr             q2, [SP], #0x10
    // 0xde9d90: b               #0xde8e80
    // 0xde9d94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde9d94: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde9d98: SaveReg d0
    //     0xde9d98: str             q0, [SP, #-0x10]!
    // 0xde9d9c: stp             x3, x4, [SP, #-0x10]!
    // 0xde9da0: stp             x1, x2, [SP, #-0x10]!
    // 0xde9da4: SaveReg r0
    //     0xde9da4: str             x0, [SP, #-8]!
    // 0xde9da8: r0 = AllocateDouble()
    //     0xde9da8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xde9dac: mov             x5, x0
    // 0xde9db0: RestoreReg r0
    //     0xde9db0: ldr             x0, [SP], #8
    // 0xde9db4: ldp             x1, x2, [SP], #0x10
    // 0xde9db8: ldp             x3, x4, [SP], #0x10
    // 0xde9dbc: RestoreReg d0
    //     0xde9dbc: ldr             q0, [SP], #0x10
    // 0xde9dc0: b               #0xde8f68
    // 0xde9dc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde9dc4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde9dc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde9dc8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde9dcc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde9dcc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde9dd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde9dd0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde9dd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde9dd4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde9dd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde9dd8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde9ddc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde9ddc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde9de0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xde9de0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xde9de4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde9de4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde9de8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xde9de8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xde9dec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde9dec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde9df0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde9df0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _systemOverlayStyleForBrightness(/* No info */) {
    // ** addr: 0xde9e64, size: 0x70
    // 0xde9e64: EnterFrame
    //     0xde9e64: stp             fp, lr, [SP, #-0x10]!
    //     0xde9e68: mov             fp, SP
    // 0xde9e6c: AllocStack(0x18)
    //     0xde9e6c: sub             SP, SP, #0x18
    // 0xde9e70: SetupParameters(dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xde9e70: stur            x3, [fp, #-0x18]
    // 0xde9e74: r16 = Instance_Brightness
    //     0xde9e74: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xde9e78: cmp             w2, w16
    // 0xde9e7c: b.ne            #0xde9e8c
    // 0xde9e80: r0 = Instance_SystemUiOverlayStyle
    //     0xde9e80: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8ca08] Obj!SystemUiOverlayStyle@12aa591
    //     0xde9e84: ldr             x0, [x0, #0xa08]
    // 0xde9e88: b               #0xde9e94
    // 0xde9e8c: r0 = Instance_SystemUiOverlayStyle
    //     0xde9e8c: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8ca10] Obj!SystemUiOverlayStyle@12aa561
    //     0xde9e90: ldr             x0, [x0, #0xa10]
    // 0xde9e94: LoadField: r1 = r0->field_1b
    //     0xde9e94: ldur            w1, [x0, #0x1b]
    // 0xde9e98: DecompressPointer r1
    //     0xde9e98: add             x1, x1, HEAP, lsl #32
    // 0xde9e9c: stur            x1, [fp, #-0x10]
    // 0xde9ea0: LoadField: r2 = r0->field_1f
    //     0xde9ea0: ldur            w2, [x0, #0x1f]
    // 0xde9ea4: DecompressPointer r2
    //     0xde9ea4: add             x2, x2, HEAP, lsl #32
    // 0xde9ea8: stur            x2, [fp, #-8]
    // 0xde9eac: r0 = SystemUiOverlayStyle()
    //     0xde9eac: bl              #0x899754  ; AllocateSystemUiOverlayStyleStub -> SystemUiOverlayStyle (size=0x28)
    // 0xde9eb0: ldur            x1, [fp, #-0x18]
    // 0xde9eb4: ArrayStore: r0[0] = r1  ; List_4
    //     0xde9eb4: stur            w1, [x0, #0x17]
    // 0xde9eb8: ldur            x1, [fp, #-0x10]
    // 0xde9ebc: StoreField: r0->field_1b = r1
    //     0xde9ebc: stur            w1, [x0, #0x1b]
    // 0xde9ec0: ldur            x1, [fp, #-8]
    // 0xde9ec4: StoreField: r0->field_1f = r1
    //     0xde9ec4: stur            w1, [x0, #0x1f]
    // 0xde9ec8: LeaveFrame
    //     0xde9ec8: mov             SP, fp
    //     0xde9ecc: ldp             fp, lr, [SP], #0x10
    // 0xde9ed0: ret
    //     0xde9ed0: ret             
  }
  _ _resolveColor(/* No info */) {
    // ** addr: 0xdea760, size: 0xa0
    // 0xdea760: EnterFrame
    //     0xdea760: stp             fp, lr, [SP, #-0x10]!
    //     0xdea764: mov             fp, SP
    // 0xdea768: AllocStack(0x30)
    //     0xdea768: sub             SP, SP, #0x30
    // 0xdea76c: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r5 => r5, fp-0x10 */, dynamic _ /* r6 => r6, fp-0x18 */)
    //     0xdea76c: stur            x2, [fp, #-8]
    //     0xdea770: stur            x5, [fp, #-0x10]
    //     0xdea774: stur            x6, [fp, #-0x18]
    // 0xdea778: CheckStackOverflow
    //     0xdea778: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdea77c: cmp             SP, x16
    //     0xdea780: b.ls            #0xdea7f8
    // 0xdea784: r16 = <Color?>
    //     0xdea784: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdea788: ldr             x16, [x16, #0xa40]
    // 0xdea78c: stp             x3, x16, [SP, #8]
    // 0xdea790: str             x2, [SP]
    // 0xdea794: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xdea794: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xdea798: r0 = resolveAs()
    //     0xdea798: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xdea79c: cmp             w0, NULL
    // 0xdea7a0: b.ne            #0xdea7c4
    // 0xdea7a4: r16 = <Color?>
    //     0xdea7a4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdea7a8: ldr             x16, [x16, #0xa40]
    // 0xdea7ac: ldur            lr, [fp, #-0x10]
    // 0xdea7b0: stp             lr, x16, [SP, #8]
    // 0xdea7b4: ldur            x16, [fp, #-8]
    // 0xdea7b8: str             x16, [SP]
    // 0xdea7bc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xdea7bc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xdea7c0: r0 = resolveAs()
    //     0xdea7c0: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xdea7c4: cmp             w0, NULL
    // 0xdea7c8: b.ne            #0xdea7ec
    // 0xdea7cc: r16 = <Color>
    //     0xdea7cc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xdea7d0: ldr             x16, [x16, #0xa90]
    // 0xdea7d4: ldur            lr, [fp, #-0x18]
    // 0xdea7d8: stp             lr, x16, [SP, #8]
    // 0xdea7dc: ldur            x16, [fp, #-8]
    // 0xdea7e0: str             x16, [SP]
    // 0xdea7e4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xdea7e4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xdea7e8: r0 = resolveAs()
    //     0xdea7e8: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xdea7ec: LeaveFrame
    //     0xdea7ec: mov             SP, fp
    //     0xdea7f0: ldp             fp, lr, [SP], #0x10
    // 0xdea7f4: ret
    //     0xdea7f4: ret             
    // 0xdea7f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdea7f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdea7fc: b               #0xdea784
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xef3b4c, size: 0x1c4
    // 0xef3b4c: EnterFrame
    //     0xef3b4c: stp             fp, lr, [SP, #-0x10]!
    //     0xef3b50: mov             fp, SP
    // 0xef3b54: AllocStack(0x18)
    //     0xef3b54: sub             SP, SP, #0x18
    // 0xef3b58: SetupParameters(_AppBarState this /* r1 => r0, fp-0x10 */)
    //     0xef3b58: mov             x0, x1
    //     0xef3b5c: stur            x1, [fp, #-0x10]
    // 0xef3b60: CheckStackOverflow
    //     0xef3b60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef3b64: cmp             SP, x16
    //     0xef3b68: b.ls            #0xef3d00
    // 0xef3b6c: LoadField: r3 = r0->field_13
    //     0xef3b6c: ldur            w3, [x0, #0x13]
    // 0xef3b70: DecompressPointer r3
    //     0xef3b70: add             x3, x3, HEAP, lsl #32
    // 0xef3b74: stur            x3, [fp, #-8]
    // 0xef3b78: cmp             w3, NULL
    // 0xef3b7c: b.ne            #0xef3b88
    // 0xef3b80: mov             x2, x0
    // 0xef3b84: b               #0xef3ba8
    // 0xef3b88: mov             x2, x0
    // 0xef3b8c: r1 = Function '_handleScrollNotification@25187611':.
    //     0xef3b8c: add             x1, PP, #0x90, lsl #12  ; [pp+0x90da0] AnonymousClosure: (0xef3d10), in [package:flutter/src/material/app_bar.dart] _AppBarState::_handleScrollNotification (0xef3d4c)
    //     0xef3b90: ldr             x1, [x1, #0xda0]
    // 0xef3b94: r0 = AllocateClosure()
    //     0xef3b94: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef3b98: ldur            x1, [fp, #-8]
    // 0xef3b9c: mov             x2, x0
    // 0xef3ba0: r0 = removeListener()
    //     0xef3ba0: bl              #0x854d74  ; [package:flutter/src/widgets/scroll_notification_observer.dart] ScrollNotificationObserverState::removeListener
    // 0xef3ba4: ldur            x2, [fp, #-0x10]
    // 0xef3ba8: LoadField: r1 = r2->field_f
    //     0xef3ba8: ldur            w1, [x2, #0xf]
    // 0xef3bac: DecompressPointer r1
    //     0xef3bac: add             x1, x1, HEAP, lsl #32
    // 0xef3bb0: cmp             w1, NULL
    // 0xef3bb4: b.eq            #0xef3d08
    // 0xef3bb8: r0 = maybeOf()
    //     0xef3bb8: bl              #0xdea800  ; [package:flutter/src/material/scaffold.dart] Scaffold::maybeOf
    // 0xef3bbc: mov             x3, x0
    // 0xef3bc0: stur            x3, [fp, #-0x18]
    // 0xef3bc4: cmp             w3, NULL
    // 0xef3bc8: b.eq            #0xef3c90
    // 0xef3bcc: LoadField: r0 = r3->field_3f
    //     0xef3bcc: ldur            w0, [x3, #0x3f]
    // 0xef3bd0: DecompressPointer r0
    //     0xef3bd0: add             x0, x0, HEAP, lsl #32
    // 0xef3bd4: LoadField: r4 = r0->field_33
    //     0xef3bd4: ldur            w4, [x0, #0x33]
    // 0xef3bd8: DecompressPointer r4
    //     0xef3bd8: add             x4, x4, HEAP, lsl #32
    // 0xef3bdc: stur            x4, [fp, #-8]
    // 0xef3be0: cmp             w4, NULL
    // 0xef3be4: b.ne            #0xef3c1c
    // 0xef3be8: LoadField: r2 = r0->field_23
    //     0xef3be8: ldur            w2, [x0, #0x23]
    // 0xef3bec: DecompressPointer r2
    //     0xef3bec: add             x2, x2, HEAP, lsl #32
    // 0xef3bf0: mov             x0, x4
    // 0xef3bf4: r1 = Null
    //     0xef3bf4: mov             x1, NULL
    // 0xef3bf8: cmp             w2, NULL
    // 0xef3bfc: b.eq            #0xef3c1c
    // 0xef3c00: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xef3c00: ldur            w4, [x2, #0x17]
    // 0xef3c04: DecompressPointer r4
    //     0xef3c04: add             x4, x4, HEAP, lsl #32
    // 0xef3c08: r8 = X0
    //     0xef3c08: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xef3c0c: LoadField: r9 = r4->field_7
    //     0xef3c0c: ldur            x9, [x4, #7]
    // 0xef3c10: r3 = Null
    //     0xef3c10: add             x3, PP, #0x90, lsl #12  ; [pp+0x90db0] Null
    //     0xef3c14: ldr             x3, [x3, #0xdb0]
    // 0xef3c18: blr             x9
    // 0xef3c1c: ldur            x0, [fp, #-8]
    // 0xef3c20: tbz             w0, #4, #0xef3c80
    // 0xef3c24: ldur            x0, [fp, #-0x18]
    // 0xef3c28: LoadField: r1 = r0->field_43
    //     0xef3c28: ldur            w1, [x0, #0x43]
    // 0xef3c2c: DecompressPointer r1
    //     0xef3c2c: add             x1, x1, HEAP, lsl #32
    // 0xef3c30: LoadField: r3 = r1->field_33
    //     0xef3c30: ldur            w3, [x1, #0x33]
    // 0xef3c34: DecompressPointer r3
    //     0xef3c34: add             x3, x3, HEAP, lsl #32
    // 0xef3c38: stur            x3, [fp, #-8]
    // 0xef3c3c: cmp             w3, NULL
    // 0xef3c40: b.ne            #0xef3c78
    // 0xef3c44: LoadField: r2 = r1->field_23
    //     0xef3c44: ldur            w2, [x1, #0x23]
    // 0xef3c48: DecompressPointer r2
    //     0xef3c48: add             x2, x2, HEAP, lsl #32
    // 0xef3c4c: mov             x0, x3
    // 0xef3c50: r1 = Null
    //     0xef3c50: mov             x1, NULL
    // 0xef3c54: cmp             w2, NULL
    // 0xef3c58: b.eq            #0xef3c78
    // 0xef3c5c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xef3c5c: ldur            w4, [x2, #0x17]
    // 0xef3c60: DecompressPointer r4
    //     0xef3c60: add             x4, x4, HEAP, lsl #32
    // 0xef3c64: r8 = X0
    //     0xef3c64: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xef3c68: LoadField: r9 = r4->field_7
    //     0xef3c68: ldur            x9, [x4, #7]
    // 0xef3c6c: r3 = Null
    //     0xef3c6c: add             x3, PP, #0x90, lsl #12  ; [pp+0x90dc0] Null
    //     0xef3c70: ldr             x3, [x3, #0xdc0]
    // 0xef3c74: blr             x9
    // 0xef3c78: ldur            x0, [fp, #-8]
    // 0xef3c7c: tbnz            w0, #4, #0xef3c90
    // 0xef3c80: r0 = Null
    //     0xef3c80: mov             x0, NULL
    // 0xef3c84: LeaveFrame
    //     0xef3c84: mov             SP, fp
    //     0xef3c88: ldp             fp, lr, [SP], #0x10
    // 0xef3c8c: ret
    //     0xef3c8c: ret             
    // 0xef3c90: ldur            x2, [fp, #-0x10]
    // 0xef3c94: LoadField: r1 = r2->field_f
    //     0xef3c94: ldur            w1, [x2, #0xf]
    // 0xef3c98: DecompressPointer r1
    //     0xef3c98: add             x1, x1, HEAP, lsl #32
    // 0xef3c9c: cmp             w1, NULL
    // 0xef3ca0: b.eq            #0xef3d0c
    // 0xef3ca4: r0 = maybeOf()
    //     0xef3ca4: bl              #0x854d1c  ; [package:flutter/src/widgets/scroll_notification_observer.dart] ScrollNotificationObserver::maybeOf
    // 0xef3ca8: mov             x3, x0
    // 0xef3cac: ldur            x2, [fp, #-0x10]
    // 0xef3cb0: stur            x3, [fp, #-8]
    // 0xef3cb4: StoreField: r2->field_13 = r0
    //     0xef3cb4: stur            w0, [x2, #0x13]
    //     0xef3cb8: ldurb           w16, [x2, #-1]
    //     0xef3cbc: ldurb           w17, [x0, #-1]
    //     0xef3cc0: and             x16, x17, x16, lsr #2
    //     0xef3cc4: tst             x16, HEAP, lsr #32
    //     0xef3cc8: b.eq            #0xef3cd0
    //     0xef3ccc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xef3cd0: cmp             w3, NULL
    // 0xef3cd4: b.eq            #0xef3cf0
    // 0xef3cd8: r1 = Function '_handleScrollNotification@25187611':.
    //     0xef3cd8: add             x1, PP, #0x90, lsl #12  ; [pp+0x90da0] AnonymousClosure: (0xef3d10), in [package:flutter/src/material/app_bar.dart] _AppBarState::_handleScrollNotification (0xef3d4c)
    //     0xef3cdc: ldr             x1, [x1, #0xda0]
    // 0xef3ce0: r0 = AllocateClosure()
    //     0xef3ce0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef3ce4: ldur            x1, [fp, #-8]
    // 0xef3ce8: mov             x2, x0
    // 0xef3cec: r0 = addListener()
    //     0xef3cec: bl              #0x854914  ; [package:flutter/src/widgets/scroll_notification_observer.dart] ScrollNotificationObserverState::addListener
    // 0xef3cf0: r0 = Null
    //     0xef3cf0: mov             x0, NULL
    // 0xef3cf4: LeaveFrame
    //     0xef3cf4: mov             SP, fp
    //     0xef3cf8: ldp             fp, lr, [SP], #0x10
    // 0xef3cfc: ret
    //     0xef3cfc: ret             
    // 0xef3d00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef3d00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef3d04: b               #0xef3b6c
    // 0xef3d08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef3d08: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef3d0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef3d0c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleScrollNotification(dynamic, ScrollNotification) {
    // ** addr: 0xef3d10, size: 0x3c
    // 0xef3d10: EnterFrame
    //     0xef3d10: stp             fp, lr, [SP, #-0x10]!
    //     0xef3d14: mov             fp, SP
    // 0xef3d18: ldr             x0, [fp, #0x18]
    // 0xef3d1c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xef3d1c: ldur            w1, [x0, #0x17]
    // 0xef3d20: DecompressPointer r1
    //     0xef3d20: add             x1, x1, HEAP, lsl #32
    // 0xef3d24: CheckStackOverflow
    //     0xef3d24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef3d28: cmp             SP, x16
    //     0xef3d2c: b.ls            #0xef3d44
    // 0xef3d30: ldr             x2, [fp, #0x10]
    // 0xef3d34: r0 = _handleScrollNotification()
    //     0xef3d34: bl              #0xef3d4c  ; [package:flutter/src/material/app_bar.dart] _AppBarState::_handleScrollNotification
    // 0xef3d38: LeaveFrame
    //     0xef3d38: mov             SP, fp
    //     0xef3d3c: ldp             fp, lr, [SP], #0x10
    // 0xef3d40: ret
    //     0xef3d40: ret             
    // 0xef3d44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef3d44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef3d48: b               #0xef3d30
  }
  _ _handleScrollNotification(/* No info */) {
    // ** addr: 0xef3d4c, size: 0x180
    // 0xef3d4c: EnterFrame
    //     0xef3d4c: stp             fp, lr, [SP, #-0x10]!
    //     0xef3d50: mov             fp, SP
    // 0xef3d54: AllocStack(0x10)
    //     0xef3d54: sub             SP, SP, #0x10
    // 0xef3d58: SetupParameters(_AppBarState this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xef3d58: mov             x0, x2
    //     0xef3d5c: stur            x2, [fp, #-0x10]
    //     0xef3d60: mov             x2, x1
    //     0xef3d64: stur            x1, [fp, #-8]
    // 0xef3d68: CheckStackOverflow
    //     0xef3d68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef3d6c: cmp             SP, x16
    //     0xef3d70: b.ls            #0xef3eb0
    // 0xef3d74: r1 = LoadClassIdInstr(r0)
    //     0xef3d74: ldur            x1, [x0, #-1]
    //     0xef3d78: ubfx            x1, x1, #0xc, #0x14
    // 0xef3d7c: r17 = 4556
    //     0xef3d7c: mov             x17, #0x11cc
    // 0xef3d80: cmp             x1, x17
    // 0xef3d84: b.ne            #0xef3ea0
    // 0xef3d88: LoadField: r1 = r2->field_b
    //     0xef3d88: ldur            w1, [x2, #0xb]
    // 0xef3d8c: DecompressPointer r1
    //     0xef3d8c: add             x1, x1, HEAP, lsl #32
    // 0xef3d90: cmp             w1, NULL
    // 0xef3d94: b.eq            #0xef3eb8
    // 0xef3d98: mov             x1, x0
    // 0xef3d9c: r0 = defaultScrollNotificationPredicate()
    //     0xef3d9c: bl              #0xd34bb0  ; [package:flutter/src/widgets/scroll_notification.dart] ::defaultScrollNotificationPredicate
    // 0xef3da0: tbnz            w0, #4, #0xef3ea0
    // 0xef3da4: ldur            x3, [fp, #-8]
    // 0xef3da8: ldur            x0, [fp, #-0x10]
    // 0xef3dac: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xef3dac: ldur            w1, [x3, #0x17]
    // 0xef3db0: DecompressPointer r1
    //     0xef3db0: add             x1, x1, HEAP, lsl #32
    // 0xef3db4: LoadField: r2 = r0->field_f
    //     0xef3db4: ldur            w2, [x0, #0xf]
    // 0xef3db8: DecompressPointer r2
    //     0xef3db8: add             x2, x2, HEAP, lsl #32
    // 0xef3dbc: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xef3dbc: ldur            w0, [x2, #0x17]
    // 0xef3dc0: DecompressPointer r0
    //     0xef3dc0: add             x0, x0, HEAP, lsl #32
    // 0xef3dc4: LoadField: r4 = r0->field_7
    //     0xef3dc4: ldur            x4, [x0, #7]
    // 0xef3dc8: cmp             x4, #1
    // 0xef3dcc: b.gt            #0xef3e24
    // 0xef3dd0: cmp             x4, #0
    // 0xef3dd4: b.gt            #0xef3e78
    // 0xef3dd8: d0 = 0.000000
    //     0xef3dd8: eor             v0.16b, v0.16b, v0.16b
    // 0xef3ddc: LoadField: r0 = r2->field_b
    //     0xef3ddc: ldur            w0, [x2, #0xb]
    // 0xef3de0: DecompressPointer r0
    //     0xef3de0: add             x0, x0, HEAP, lsl #32
    // 0xef3de4: cmp             w0, NULL
    // 0xef3de8: b.eq            #0xef3ebc
    // 0xef3dec: LoadField: r4 = r2->field_f
    //     0xef3dec: ldur            w4, [x2, #0xf]
    // 0xef3df0: DecompressPointer r4
    //     0xef3df0: add             x4, x4, HEAP, lsl #32
    // 0xef3df4: cmp             w4, NULL
    // 0xef3df8: b.eq            #0xef3ec0
    // 0xef3dfc: LoadField: d1 = r0->field_7
    //     0xef3dfc: ldur            d1, [x0, #7]
    // 0xef3e00: LoadField: d2 = r4->field_7
    //     0xef3e00: ldur            d2, [x4, #7]
    // 0xef3e04: fsub            d3, d1, d2
    // 0xef3e08: fmax            v1.2d, v3.2d, v0.2d
    // 0xef3e0c: fcmp            d1, d0
    // 0xef3e10: r16 = true
    //     0xef3e10: add             x16, NULL, #0x20  ; true
    // 0xef3e14: r17 = false
    //     0xef3e14: add             x17, NULL, #0x30  ; false
    // 0xef3e18: csel            x0, x16, x17, gt
    // 0xef3e1c: ArrayStore: r3[0] = r0  ; List_4
    //     0xef3e1c: stur            w0, [x3, #0x17]
    // 0xef3e20: b               #0xef3e7c
    // 0xef3e24: d0 = 0.000000
    //     0xef3e24: eor             v0.16b, v0.16b, v0.16b
    // 0xef3e28: cmp             x4, #2
    // 0xef3e2c: b.gt            #0xef3e78
    // 0xef3e30: LoadField: r0 = r2->field_f
    //     0xef3e30: ldur            w0, [x2, #0xf]
    // 0xef3e34: DecompressPointer r0
    //     0xef3e34: add             x0, x0, HEAP, lsl #32
    // 0xef3e38: cmp             w0, NULL
    // 0xef3e3c: b.eq            #0xef3ec4
    // 0xef3e40: LoadField: r4 = r2->field_7
    //     0xef3e40: ldur            w4, [x2, #7]
    // 0xef3e44: DecompressPointer r4
    //     0xef3e44: add             x4, x4, HEAP, lsl #32
    // 0xef3e48: cmp             w4, NULL
    // 0xef3e4c: b.eq            #0xef3ec8
    // 0xef3e50: LoadField: d1 = r0->field_7
    //     0xef3e50: ldur            d1, [x0, #7]
    // 0xef3e54: LoadField: d2 = r4->field_7
    //     0xef3e54: ldur            d2, [x4, #7]
    // 0xef3e58: fsub            d3, d1, d2
    // 0xef3e5c: fmax            v1.2d, v3.2d, v0.2d
    // 0xef3e60: fcmp            d1, d0
    // 0xef3e64: r16 = true
    //     0xef3e64: add             x16, NULL, #0x20  ; true
    // 0xef3e68: r17 = false
    //     0xef3e68: add             x17, NULL, #0x30  ; false
    // 0xef3e6c: csel            x0, x16, x17, gt
    // 0xef3e70: ArrayStore: r3[0] = r0  ; List_4
    //     0xef3e70: stur            w0, [x3, #0x17]
    // 0xef3e74: b               #0xef3e7c
    // 0xef3e78: mov             x0, x1
    // 0xef3e7c: cmp             w0, w1
    // 0xef3e80: b.eq            #0xef3ea0
    // 0xef3e84: r1 = Function '<anonymous closure>':.
    //     0xef3e84: add             x1, PP, #0x90, lsl #12  ; [pp+0x90da8] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xef3e88: ldr             x1, [x1, #0xda8]
    // 0xef3e8c: r2 = Null
    //     0xef3e8c: mov             x2, NULL
    // 0xef3e90: r0 = AllocateClosure()
    //     0xef3e90: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef3e94: ldur            x1, [fp, #-8]
    // 0xef3e98: mov             x2, x0
    // 0xef3e9c: r0 = setState()
    //     0xef3e9c: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xef3ea0: r0 = Null
    //     0xef3ea0: mov             x0, NULL
    // 0xef3ea4: LeaveFrame
    //     0xef3ea4: mov             SP, fp
    //     0xef3ea8: ldp             fp, lr, [SP], #0x10
    // 0xef3eac: ret
    //     0xef3eac: ret             
    // 0xef3eb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef3eb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef3eb4: b               #0xef3d74
    // 0xef3eb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef3eb8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef3ebc: r0 = NullCastErrorSharedWithFPURegs()
    //     0xef3ebc: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xef3ec0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xef3ec0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xef3ec4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xef3ec4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xef3ec8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xef3ec8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e57cc, size: 0x70
    // 0x10e57cc: EnterFrame
    //     0x10e57cc: stp             fp, lr, [SP, #-0x10]!
    //     0x10e57d0: mov             fp, SP
    // 0x10e57d4: AllocStack(0x10)
    //     0x10e57d4: sub             SP, SP, #0x10
    // 0x10e57d8: SetupParameters(_AppBarState this /* r1 => r0, fp-0x10 */)
    //     0x10e57d8: mov             x0, x1
    //     0x10e57dc: stur            x1, [fp, #-0x10]
    // 0x10e57e0: CheckStackOverflow
    //     0x10e57e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e57e4: cmp             SP, x16
    //     0x10e57e8: b.ls            #0x10e5834
    // 0x10e57ec: LoadField: r3 = r0->field_13
    //     0x10e57ec: ldur            w3, [x0, #0x13]
    // 0x10e57f0: DecompressPointer r3
    //     0x10e57f0: add             x3, x3, HEAP, lsl #32
    // 0x10e57f4: stur            x3, [fp, #-8]
    // 0x10e57f8: cmp             w3, NULL
    // 0x10e57fc: b.eq            #0x10e5824
    // 0x10e5800: mov             x2, x0
    // 0x10e5804: r1 = Function '_handleScrollNotification@25187611':.
    //     0x10e5804: add             x1, PP, #0x90, lsl #12  ; [pp+0x90da0] AnonymousClosure: (0xef3d10), in [package:flutter/src/material/app_bar.dart] _AppBarState::_handleScrollNotification (0xef3d4c)
    //     0x10e5808: ldr             x1, [x1, #0xda0]
    // 0x10e580c: r0 = AllocateClosure()
    //     0x10e580c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e5810: ldur            x1, [fp, #-8]
    // 0x10e5814: mov             x2, x0
    // 0x10e5818: r0 = removeListener()
    //     0x10e5818: bl              #0x854d74  ; [package:flutter/src/widgets/scroll_notification_observer.dart] ScrollNotificationObserverState::removeListener
    // 0x10e581c: ldur            x1, [fp, #-0x10]
    // 0x10e5820: StoreField: r1->field_13 = rNULL
    //     0x10e5820: stur            NULL, [x1, #0x13]
    // 0x10e5824: r0 = Null
    //     0x10e5824: mov             x0, NULL
    // 0x10e5828: LeaveFrame
    //     0x10e5828: mov             SP, fp
    //     0x10e582c: ldp             fp, lr, [SP], #0x10
    // 0x10e5830: ret
    //     0x10e5830: ret             
    // 0x10e5834: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e5834: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e5838: b               #0x10e57ec
  }
}

// class id: 6505, size: 0x94, field offset: 0xc
class AppBar extends StatefulWidget
    implements PreferredSizeWidget {

  static _ preferredHeightFor(/* No info */) {
    // ** addr: 0xd365a0, size: 0xec
    // 0xd365a0: EnterFrame
    //     0xd365a0: stp             fp, lr, [SP, #-0x10]!
    //     0xd365a4: mov             fp, SP
    // 0xd365a8: AllocStack(0x18)
    //     0xd365a8: sub             SP, SP, #0x18
    // 0xd365ac: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0xd365ac: stur            x2, [fp, #-8]
    // 0xd365b0: CheckStackOverflow
    //     0xd365b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd365b4: cmp             SP, x16
    //     0xd365b8: b.ls            #0xd36668
    // 0xd365bc: r0 = LoadClassIdInstr(r2)
    //     0xd365bc: ldur            x0, [x2, #-1]
    //     0xd365c0: ubfx            x0, x0, #0xc, #0x14
    // 0xd365c4: cmp             x0, #0xedb
    // 0xd365c8: b.ne            #0xd36654
    // 0xd365cc: r0 = of()
    //     0xd365cc: bl              #0xd366b0  ; [package:flutter/src/material/app_bar_theme.dart] AppBarTheme::of
    // 0xd365d0: LoadField: r1 = r0->field_37
    //     0xd365d0: ldur            w1, [x0, #0x37]
    // 0xd365d4: DecompressPointer r1
    //     0xd365d4: add             x1, x1, HEAP, lsl #32
    // 0xd365d8: cmp             w1, NULL
    // 0xd365dc: b.ne            #0xd365ec
    // 0xd365e0: d0 = 56.000000
    //     0xd365e0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a70] IMM: double(56) from 0x404c000000000000
    //     0xd365e4: ldr             d0, [x17, #0xa70]
    // 0xd365e8: b               #0xd365f0
    // 0xd365ec: LoadField: d0 = r1->field_7
    //     0xd365ec: ldur            d0, [x1, #7]
    // 0xd365f0: ldur            x0, [fp, #-8]
    // 0xd365f4: LoadField: r1 = r0->field_1b
    //     0xd365f4: ldur            w1, [x0, #0x1b]
    // 0xd365f8: DecompressPointer r1
    //     0xd365f8: add             x1, x1, HEAP, lsl #32
    // 0xd365fc: cmp             w1, NULL
    // 0xd36600: b.ne            #0xd3660c
    // 0xd36604: r0 = 0
    //     0xd36604: mov             x0, #0
    // 0xd36608: b               #0xd36610
    // 0xd3660c: mov             x0, x1
    // 0xd36610: r1 = inline_Allocate_Double()
    //     0xd36610: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xd36614: add             x1, x1, #0x10
    //     0xd36618: cmp             x2, x1
    //     0xd3661c: b.ls            #0xd36670
    //     0xd36620: str             x1, [THR, #0x60]  ; THR::top
    //     0xd36624: sub             x1, x1, #0xf
    //     0xd36628: mov             x2, #0xe19c
    //     0xd3662c: movk            x2, #3, lsl #16
    //     0xd36630: stur            x2, [x1, #-1]
    // 0xd36634: dmb             ishst
    // 0xd36638: StoreField: r1->field_7 = d0
    //     0xd36638: stur            d0, [x1, #7]
    // 0xd3663c: stp             x0, x1, [SP]
    // 0xd36640: r0 = +()
    //     0xd36640: bl              #0x13dce50  ; [dart:core] _Double::+
    // 0xd36644: LoadField: d0 = r0->field_7
    //     0xd36644: ldur            d0, [x0, #7]
    // 0xd36648: LeaveFrame
    //     0xd36648: mov             SP, fp
    //     0xd3664c: ldp             fp, lr, [SP], #0x10
    // 0xd36650: ret
    //     0xd36650: ret             
    // 0xd36654: mov             x0, x2
    // 0xd36658: LoadField: d0 = r0->field_f
    //     0xd36658: ldur            d0, [x0, #0xf]
    // 0xd3665c: LeaveFrame
    //     0xd3665c: mov             SP, fp
    //     0xd36660: ldp             fp, lr, [SP], #0x10
    // 0xd36664: ret
    //     0xd36664: ret             
    // 0xd36668: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd36668: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd3666c: b               #0xd365bc
    // 0xd36670: SaveReg d0
    //     0xd36670: str             q0, [SP, #-0x10]!
    // 0xd36674: SaveReg r0
    //     0xd36674: str             x0, [SP, #-8]!
    // 0xd36678: r0 = AllocateDouble()
    //     0xd36678: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd3667c: mov             x1, x0
    // 0xd36680: RestoreReg r0
    //     0xd36680: ldr             x0, [SP], #8
    // 0xd36684: RestoreReg d0
    //     0xd36684: ldr             q0, [SP], #0x10
    // 0xd36688: b               #0xd36638
  }
  _ AppBar(/* No info */) {
    // ** addr: 0xd4c0e8, size: 0x7ac
    // 0xd4c0e8: EnterFrame
    //     0xd4c0e8: stp             fp, lr, [SP, #-0x10]!
    //     0xd4c0ec: mov             fp, SP
    // 0xd4c0f0: AllocStack(0x10)
    //     0xd4c0f0: sub             SP, SP, #0x10
    // 0xd4c0f4: SetupParameters(AppBar this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r1 */)
    //     0xd4c0f4: stur            x1, [fp, #-0x10]
    //     0xd4c0f8: mov             x16, x2
    //     0xd4c0fc: mov             x2, x1
    //     0xd4c100: mov             x1, x16
    // 0xd4c104: LoadField: r0 = r4->field_13
    //     0xd4c104: ldur            w0, [x4, #0x13]
    // 0xd4c108: LoadField: r3 = r4->field_1f
    //     0xd4c108: ldur            w3, [x4, #0x1f]
    // 0xd4c10c: DecompressPointer r3
    //     0xd4c10c: add             x3, x3, HEAP, lsl #32
    // 0xd4c110: r16 = "actions"
    //     0xd4c110: add             x16, PP, #0x18, lsl #12  ; [pp+0x18118] "actions"
    //     0xd4c114: ldr             x16, [x16, #0x118]
    // 0xd4c118: cmp             w3, w16
    // 0xd4c11c: b.ne            #0xd4c140
    // 0xd4c120: LoadField: r3 = r4->field_23
    //     0xd4c120: ldur            w3, [x4, #0x23]
    // 0xd4c124: DecompressPointer r3
    //     0xd4c124: add             x3, x3, HEAP, lsl #32
    // 0xd4c128: sub             w5, w0, w3
    // 0xd4c12c: add             x3, fp, w5, sxtw #2
    // 0xd4c130: ldr             x3, [x3, #8]
    // 0xd4c134: mov             x5, x3
    // 0xd4c138: r3 = 1
    //     0xd4c138: mov             x3, #1
    // 0xd4c13c: b               #0xd4c148
    // 0xd4c140: r5 = Null
    //     0xd4c140: mov             x5, NULL
    // 0xd4c144: r3 = 0
    //     0xd4c144: mov             x3, #0
    // 0xd4c148: lsl             x6, x3, #1
    // 0xd4c14c: lsl             w7, w6, #1
    // 0xd4c150: add             w8, w7, #8
    // 0xd4c154: ArrayLoad: r9 = r4[r8]  ; Unknown_4
    //     0xd4c154: add             x16, x4, w8, sxtw #1
    //     0xd4c158: ldur            w9, [x16, #0xf]
    // 0xd4c15c: DecompressPointer r9
    //     0xd4c15c: add             x9, x9, HEAP, lsl #32
    // 0xd4c160: r16 = "automaticallyImplyLeading"
    //     0xd4c160: add             x16, PP, #0x18, lsl #12  ; [pp+0x18120] "automaticallyImplyLeading"
    //     0xd4c164: ldr             x16, [x16, #0x120]
    // 0xd4c168: cmp             w9, w16
    // 0xd4c16c: b.ne            #0xd4c1a0
    // 0xd4c170: add             w3, w7, #0xa
    // 0xd4c174: ArrayLoad: r7 = r4[r3]  ; Unknown_4
    //     0xd4c174: add             x16, x4, w3, sxtw #1
    //     0xd4c178: ldur            w7, [x16, #0xf]
    // 0xd4c17c: DecompressPointer r7
    //     0xd4c17c: add             x7, x7, HEAP, lsl #32
    // 0xd4c180: sub             w3, w0, w7
    // 0xd4c184: add             x7, fp, w3, sxtw #2
    // 0xd4c188: ldr             x7, [x7, #8]
    // 0xd4c18c: add             w3, w6, #2
    // 0xd4c190: r6 = LoadInt32Instr(r3)
    //     0xd4c190: sbfx            x6, x3, #1, #0x1f
    // 0xd4c194: mov             x3, x6
    // 0xd4c198: mov             x6, x7
    // 0xd4c19c: b               #0xd4c1a4
    // 0xd4c1a0: r6 = true
    //     0xd4c1a0: add             x6, NULL, #0x20  ; true
    // 0xd4c1a4: lsl             x7, x3, #1
    // 0xd4c1a8: lsl             w8, w7, #1
    // 0xd4c1ac: add             w9, w8, #8
    // 0xd4c1b0: ArrayLoad: r10 = r4[r9]  ; Unknown_4
    //     0xd4c1b0: add             x16, x4, w9, sxtw #1
    //     0xd4c1b4: ldur            w10, [x16, #0xf]
    // 0xd4c1b8: DecompressPointer r10
    //     0xd4c1b8: add             x10, x10, HEAP, lsl #32
    // 0xd4c1bc: r16 = "backgroundColor"
    //     0xd4c1bc: add             x16, PP, #0x12, lsl #12  ; [pp+0x12958] "backgroundColor"
    //     0xd4c1c0: ldr             x16, [x16, #0x958]
    // 0xd4c1c4: cmp             w10, w16
    // 0xd4c1c8: b.ne            #0xd4c1fc
    // 0xd4c1cc: add             w3, w8, #0xa
    // 0xd4c1d0: ArrayLoad: r8 = r4[r3]  ; Unknown_4
    //     0xd4c1d0: add             x16, x4, w3, sxtw #1
    //     0xd4c1d4: ldur            w8, [x16, #0xf]
    // 0xd4c1d8: DecompressPointer r8
    //     0xd4c1d8: add             x8, x8, HEAP, lsl #32
    // 0xd4c1dc: sub             w3, w0, w8
    // 0xd4c1e0: add             x8, fp, w3, sxtw #2
    // 0xd4c1e4: ldr             x8, [x8, #8]
    // 0xd4c1e8: add             w3, w7, #2
    // 0xd4c1ec: r7 = LoadInt32Instr(r3)
    //     0xd4c1ec: sbfx            x7, x3, #1, #0x1f
    // 0xd4c1f0: mov             x3, x7
    // 0xd4c1f4: mov             x7, x8
    // 0xd4c1f8: b               #0xd4c200
    // 0xd4c1fc: r7 = Null
    //     0xd4c1fc: mov             x7, NULL
    // 0xd4c200: lsl             x8, x3, #1
    // 0xd4c204: lsl             w9, w8, #1
    // 0xd4c208: add             w10, w9, #8
    // 0xd4c20c: ArrayLoad: r11 = r4[r10]  ; Unknown_4
    //     0xd4c20c: add             x16, x4, w10, sxtw #1
    //     0xd4c210: ldur            w11, [x16, #0xf]
    // 0xd4c214: DecompressPointer r11
    //     0xd4c214: add             x11, x11, HEAP, lsl #32
    // 0xd4c218: r16 = "bottom"
    //     0xd4c218: ldr             x16, [PP, #0x57b8]  ; [pp+0x57b8] "bottom"
    // 0xd4c21c: cmp             w11, w16
    // 0xd4c220: b.ne            #0xd4c254
    // 0xd4c224: add             w3, w9, #0xa
    // 0xd4c228: ArrayLoad: r9 = r4[r3]  ; Unknown_4
    //     0xd4c228: add             x16, x4, w3, sxtw #1
    //     0xd4c22c: ldur            w9, [x16, #0xf]
    // 0xd4c230: DecompressPointer r9
    //     0xd4c230: add             x9, x9, HEAP, lsl #32
    // 0xd4c234: sub             w3, w0, w9
    // 0xd4c238: add             x9, fp, w3, sxtw #2
    // 0xd4c23c: ldr             x9, [x9, #8]
    // 0xd4c240: add             w3, w8, #2
    // 0xd4c244: r8 = LoadInt32Instr(r3)
    //     0xd4c244: sbfx            x8, x3, #1, #0x1f
    // 0xd4c248: mov             x3, x8
    // 0xd4c24c: mov             x8, x9
    // 0xd4c250: b               #0xd4c258
    // 0xd4c254: r8 = Null
    //     0xd4c254: mov             x8, NULL
    // 0xd4c258: stur            x8, [fp, #-8]
    // 0xd4c25c: lsl             x9, x3, #1
    // 0xd4c260: lsl             w10, w9, #1
    // 0xd4c264: add             w11, w10, #8
    // 0xd4c268: ArrayLoad: r12 = r4[r11]  ; Unknown_4
    //     0xd4c268: add             x16, x4, w11, sxtw #1
    //     0xd4c26c: ldur            w12, [x16, #0xf]
    // 0xd4c270: DecompressPointer r12
    //     0xd4c270: add             x12, x12, HEAP, lsl #32
    // 0xd4c274: r16 = "centerTitle"
    //     0xd4c274: add             x16, PP, #0x18, lsl #12  ; [pp+0x18128] "centerTitle"
    //     0xd4c278: ldr             x16, [x16, #0x128]
    // 0xd4c27c: cmp             w12, w16
    // 0xd4c280: b.ne            #0xd4c2b4
    // 0xd4c284: add             w3, w10, #0xa
    // 0xd4c288: ArrayLoad: r10 = r4[r3]  ; Unknown_4
    //     0xd4c288: add             x16, x4, w3, sxtw #1
    //     0xd4c28c: ldur            w10, [x16, #0xf]
    // 0xd4c290: DecompressPointer r10
    //     0xd4c290: add             x10, x10, HEAP, lsl #32
    // 0xd4c294: sub             w3, w0, w10
    // 0xd4c298: add             x10, fp, w3, sxtw #2
    // 0xd4c29c: ldr             x10, [x10, #8]
    // 0xd4c2a0: add             w3, w9, #2
    // 0xd4c2a4: r9 = LoadInt32Instr(r3)
    //     0xd4c2a4: sbfx            x9, x3, #1, #0x1f
    // 0xd4c2a8: mov             x3, x9
    // 0xd4c2ac: mov             x9, x10
    // 0xd4c2b0: b               #0xd4c2b8
    // 0xd4c2b4: r9 = Null
    //     0xd4c2b4: mov             x9, NULL
    // 0xd4c2b8: lsl             x10, x3, #1
    // 0xd4c2bc: lsl             w11, w10, #1
    // 0xd4c2c0: add             w12, w11, #8
    // 0xd4c2c4: ArrayLoad: r13 = r4[r12]  ; Unknown_4
    //     0xd4c2c4: add             x16, x4, w12, sxtw #1
    //     0xd4c2c8: ldur            w13, [x16, #0xf]
    // 0xd4c2cc: DecompressPointer r13
    //     0xd4c2cc: add             x13, x13, HEAP, lsl #32
    // 0xd4c2d0: r16 = "elevation"
    //     0xd4c2d0: add             x16, PP, #0x15, lsl #12  ; [pp+0x159f0] "elevation"
    //     0xd4c2d4: ldr             x16, [x16, #0x9f0]
    // 0xd4c2d8: cmp             w13, w16
    // 0xd4c2dc: b.ne            #0xd4c310
    // 0xd4c2e0: add             w3, w11, #0xa
    // 0xd4c2e4: ArrayLoad: r11 = r4[r3]  ; Unknown_4
    //     0xd4c2e4: add             x16, x4, w3, sxtw #1
    //     0xd4c2e8: ldur            w11, [x16, #0xf]
    // 0xd4c2ec: DecompressPointer r11
    //     0xd4c2ec: add             x11, x11, HEAP, lsl #32
    // 0xd4c2f0: sub             w3, w0, w11
    // 0xd4c2f4: add             x11, fp, w3, sxtw #2
    // 0xd4c2f8: ldr             x11, [x11, #8]
    // 0xd4c2fc: add             w3, w10, #2
    // 0xd4c300: r10 = LoadInt32Instr(r3)
    //     0xd4c300: sbfx            x10, x3, #1, #0x1f
    // 0xd4c304: mov             x3, x10
    // 0xd4c308: mov             x10, x11
    // 0xd4c30c: b               #0xd4c314
    // 0xd4c310: r10 = Null
    //     0xd4c310: mov             x10, NULL
    // 0xd4c314: lsl             x11, x3, #1
    // 0xd4c318: lsl             w12, w11, #1
    // 0xd4c31c: add             w13, w12, #8
    // 0xd4c320: ArrayLoad: r14 = r4[r13]  ; Unknown_4
    //     0xd4c320: add             x16, x4, w13, sxtw #1
    //     0xd4c324: ldur            w14, [x16, #0xf]
    // 0xd4c328: DecompressPointer r14
    //     0xd4c328: add             x14, x14, HEAP, lsl #32
    // 0xd4c32c: r16 = "iconTheme"
    //     0xd4c32c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12918] "iconTheme"
    //     0xd4c330: ldr             x16, [x16, #0x918]
    // 0xd4c334: cmp             w14, w16
    // 0xd4c338: b.ne            #0xd4c36c
    // 0xd4c33c: add             w3, w12, #0xa
    // 0xd4c340: ArrayLoad: r12 = r4[r3]  ; Unknown_4
    //     0xd4c340: add             x16, x4, w3, sxtw #1
    //     0xd4c344: ldur            w12, [x16, #0xf]
    // 0xd4c348: DecompressPointer r12
    //     0xd4c348: add             x12, x12, HEAP, lsl #32
    // 0xd4c34c: sub             w3, w0, w12
    // 0xd4c350: add             x12, fp, w3, sxtw #2
    // 0xd4c354: ldr             x12, [x12, #8]
    // 0xd4c358: add             w3, w11, #2
    // 0xd4c35c: r11 = LoadInt32Instr(r3)
    //     0xd4c35c: sbfx            x11, x3, #1, #0x1f
    // 0xd4c360: mov             x3, x11
    // 0xd4c364: mov             x11, x12
    // 0xd4c368: b               #0xd4c370
    // 0xd4c36c: r11 = Null
    //     0xd4c36c: mov             x11, NULL
    // 0xd4c370: lsl             x12, x3, #1
    // 0xd4c374: lsl             w13, w12, #1
    // 0xd4c378: add             w14, w13, #8
    // 0xd4c37c: ArrayLoad: r19 = r4[r14]  ; Unknown_4
    //     0xd4c37c: add             x16, x4, w14, sxtw #1
    //     0xd4c380: ldur            w19, [x16, #0xf]
    // 0xd4c384: DecompressPointer r19
    //     0xd4c384: add             x19, x19, HEAP, lsl #32
    // 0xd4c388: r16 = "leading"
    //     0xd4c388: add             x16, PP, #0x18, lsl #12  ; [pp+0x18130] "leading"
    //     0xd4c38c: ldr             x16, [x16, #0x130]
    // 0xd4c390: cmp             w19, w16
    // 0xd4c394: b.ne            #0xd4c3c8
    // 0xd4c398: add             w3, w13, #0xa
    // 0xd4c39c: ArrayLoad: r13 = r4[r3]  ; Unknown_4
    //     0xd4c39c: add             x16, x4, w3, sxtw #1
    //     0xd4c3a0: ldur            w13, [x16, #0xf]
    // 0xd4c3a4: DecompressPointer r13
    //     0xd4c3a4: add             x13, x13, HEAP, lsl #32
    // 0xd4c3a8: sub             w3, w0, w13
    // 0xd4c3ac: add             x13, fp, w3, sxtw #2
    // 0xd4c3b0: ldr             x13, [x13, #8]
    // 0xd4c3b4: add             w3, w12, #2
    // 0xd4c3b8: r12 = LoadInt32Instr(r3)
    //     0xd4c3b8: sbfx            x12, x3, #1, #0x1f
    // 0xd4c3bc: mov             x3, x12
    // 0xd4c3c0: mov             x12, x13
    // 0xd4c3c4: b               #0xd4c3cc
    // 0xd4c3c8: r12 = Null
    //     0xd4c3c8: mov             x12, NULL
    // 0xd4c3cc: lsl             x13, x3, #1
    // 0xd4c3d0: lsl             w14, w13, #1
    // 0xd4c3d4: add             w19, w14, #8
    // 0xd4c3d8: ArrayLoad: r20 = r4[r19]  ; Unknown_4
    //     0xd4c3d8: add             x16, x4, w19, sxtw #1
    //     0xd4c3dc: ldur            w20, [x16, #0xf]
    // 0xd4c3e0: DecompressPointer r20
    //     0xd4c3e0: add             x20, x20, HEAP, lsl #32
    // 0xd4c3e4: r16 = "scrolledUnderElevation"
    //     0xd4c3e4: add             x16, PP, #0x18, lsl #12  ; [pp+0x18138] "scrolledUnderElevation"
    //     0xd4c3e8: ldr             x16, [x16, #0x138]
    // 0xd4c3ec: cmp             w20, w16
    // 0xd4c3f0: b.ne            #0xd4c424
    // 0xd4c3f4: add             w3, w14, #0xa
    // 0xd4c3f8: ArrayLoad: r14 = r4[r3]  ; Unknown_4
    //     0xd4c3f8: add             x16, x4, w3, sxtw #1
    //     0xd4c3fc: ldur            w14, [x16, #0xf]
    // 0xd4c400: DecompressPointer r14
    //     0xd4c400: add             x14, x14, HEAP, lsl #32
    // 0xd4c404: sub             w3, w0, w14
    // 0xd4c408: add             x14, fp, w3, sxtw #2
    // 0xd4c40c: ldr             x14, [x14, #8]
    // 0xd4c410: add             w3, w13, #2
    // 0xd4c414: r13 = LoadInt32Instr(r3)
    //     0xd4c414: sbfx            x13, x3, #1, #0x1f
    // 0xd4c418: mov             x3, x13
    // 0xd4c41c: mov             x13, x14
    // 0xd4c420: b               #0xd4c428
    // 0xd4c424: r13 = Null
    //     0xd4c424: mov             x13, NULL
    // 0xd4c428: lsl             x14, x3, #1
    // 0xd4c42c: lsl             w19, w14, #1
    // 0xd4c430: add             w20, w19, #8
    // 0xd4c434: ArrayLoad: r23 = r4[r20]  ; Unknown_4
    //     0xd4c434: add             x16, x4, w20, sxtw #1
    //     0xd4c438: ldur            w23, [x16, #0xf]
    // 0xd4c43c: DecompressPointer r23
    //     0xd4c43c: add             x23, x23, HEAP, lsl #32
    // 0xd4c440: r16 = "shadowColor"
    //     0xd4c440: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b70] "shadowColor"
    //     0xd4c444: ldr             x16, [x16, #0xb70]
    // 0xd4c448: cmp             w23, w16
    // 0xd4c44c: b.ne            #0xd4c480
    // 0xd4c450: add             w3, w19, #0xa
    // 0xd4c454: ArrayLoad: r19 = r4[r3]  ; Unknown_4
    //     0xd4c454: add             x16, x4, w3, sxtw #1
    //     0xd4c458: ldur            w19, [x16, #0xf]
    // 0xd4c45c: DecompressPointer r19
    //     0xd4c45c: add             x19, x19, HEAP, lsl #32
    // 0xd4c460: sub             w3, w0, w19
    // 0xd4c464: add             x19, fp, w3, sxtw #2
    // 0xd4c468: ldr             x19, [x19, #8]
    // 0xd4c46c: add             w3, w14, #2
    // 0xd4c470: r14 = LoadInt32Instr(r3)
    //     0xd4c470: sbfx            x14, x3, #1, #0x1f
    // 0xd4c474: mov             x3, x14
    // 0xd4c478: mov             x14, x19
    // 0xd4c47c: b               #0xd4c484
    // 0xd4c480: r14 = Null
    //     0xd4c480: mov             x14, NULL
    // 0xd4c484: lsl             x19, x3, #1
    // 0xd4c488: lsl             w20, w19, #1
    // 0xd4c48c: add             w23, w20, #8
    // 0xd4c490: ArrayLoad: r24 = r4[r23]  ; Unknown_4
    //     0xd4c490: add             x16, x4, w23, sxtw #1
    //     0xd4c494: ldur            w24, [x16, #0xf]
    // 0xd4c498: DecompressPointer r24
    //     0xd4c498: add             x24, x24, HEAP, lsl #32
    // 0xd4c49c: r16 = "shape"
    //     0xd4c49c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a28] "shape"
    //     0xd4c4a0: ldr             x16, [x16, #0xa28]
    // 0xd4c4a4: cmp             w24, w16
    // 0xd4c4a8: b.ne            #0xd4c4dc
    // 0xd4c4ac: add             w3, w20, #0xa
    // 0xd4c4b0: ArrayLoad: r20 = r4[r3]  ; Unknown_4
    //     0xd4c4b0: add             x16, x4, w3, sxtw #1
    //     0xd4c4b4: ldur            w20, [x16, #0xf]
    // 0xd4c4b8: DecompressPointer r20
    //     0xd4c4b8: add             x20, x20, HEAP, lsl #32
    // 0xd4c4bc: sub             w3, w0, w20
    // 0xd4c4c0: add             x20, fp, w3, sxtw #2
    // 0xd4c4c4: ldr             x20, [x20, #8]
    // 0xd4c4c8: add             w3, w19, #2
    // 0xd4c4cc: r19 = LoadInt32Instr(r3)
    //     0xd4c4cc: sbfx            x19, x3, #1, #0x1f
    // 0xd4c4d0: mov             x3, x19
    // 0xd4c4d4: mov             x19, x20
    // 0xd4c4d8: b               #0xd4c4e0
    // 0xd4c4dc: r19 = Null
    //     0xd4c4dc: mov             x19, NULL
    // 0xd4c4e0: lsl             x20, x3, #1
    // 0xd4c4e4: lsl             w23, w20, #1
    // 0xd4c4e8: add             w24, w23, #8
    // 0xd4c4ec: ArrayLoad: r25 = r4[r24]  ; Unknown_4
    //     0xd4c4ec: add             x16, x4, w24, sxtw #1
    //     0xd4c4f0: ldur            w25, [x16, #0xf]
    // 0xd4c4f4: DecompressPointer r25
    //     0xd4c4f4: add             x25, x25, HEAP, lsl #32
    // 0xd4c4f8: r16 = "surfaceTintColor"
    //     0xd4c4f8: add             x16, PP, #0x18, lsl #12  ; [pp+0x18140] "surfaceTintColor"
    //     0xd4c4fc: ldr             x16, [x16, #0x140]
    // 0xd4c500: cmp             w25, w16
    // 0xd4c504: b.ne            #0xd4c538
    // 0xd4c508: add             w3, w23, #0xa
    // 0xd4c50c: ArrayLoad: r23 = r4[r3]  ; Unknown_4
    //     0xd4c50c: add             x16, x4, w3, sxtw #1
    //     0xd4c510: ldur            w23, [x16, #0xf]
    // 0xd4c514: DecompressPointer r23
    //     0xd4c514: add             x23, x23, HEAP, lsl #32
    // 0xd4c518: sub             w3, w0, w23
    // 0xd4c51c: add             x23, fp, w3, sxtw #2
    // 0xd4c520: ldr             x23, [x23, #8]
    // 0xd4c524: add             w3, w20, #2
    // 0xd4c528: r20 = LoadInt32Instr(r3)
    //     0xd4c528: sbfx            x20, x3, #1, #0x1f
    // 0xd4c52c: mov             x3, x20
    // 0xd4c530: mov             x20, x23
    // 0xd4c534: b               #0xd4c53c
    // 0xd4c538: r20 = Null
    //     0xd4c538: mov             x20, NULL
    // 0xd4c53c: lsl             x23, x3, #1
    // 0xd4c540: lsl             w24, w23, #1
    // 0xd4c544: add             w25, w24, #8
    // 0xd4c548: ArrayLoad: r8 = r4[r25]  ; Unknown_4
    //     0xd4c548: add             x16, x4, w25, sxtw #1
    //     0xd4c54c: ldur            w8, [x16, #0xf]
    // 0xd4c550: DecompressPointer r8
    //     0xd4c550: add             x8, x8, HEAP, lsl #32
    // 0xd4c554: r16 = "systemOverlayStyle"
    //     0xd4c554: add             x16, PP, #0x18, lsl #12  ; [pp+0x18148] "systemOverlayStyle"
    //     0xd4c558: ldr             x16, [x16, #0x148]
    // 0xd4c55c: cmp             w8, w16
    // 0xd4c560: b.ne            #0xd4c590
    // 0xd4c564: add             w3, w24, #0xa
    // 0xd4c568: ArrayLoad: r8 = r4[r3]  ; Unknown_4
    //     0xd4c568: add             x16, x4, w3, sxtw #1
    //     0xd4c56c: ldur            w8, [x16, #0xf]
    // 0xd4c570: DecompressPointer r8
    //     0xd4c570: add             x8, x8, HEAP, lsl #32
    // 0xd4c574: sub             w3, w0, w8
    // 0xd4c578: add             x8, fp, w3, sxtw #2
    // 0xd4c57c: ldr             x8, [x8, #8]
    // 0xd4c580: add             w3, w23, #2
    // 0xd4c584: r23 = LoadInt32Instr(r3)
    //     0xd4c584: sbfx            x23, x3, #1, #0x1f
    // 0xd4c588: mov             x3, x23
    // 0xd4c58c: b               #0xd4c594
    // 0xd4c590: r8 = Null
    //     0xd4c590: mov             x8, NULL
    // 0xd4c594: lsl             x23, x3, #1
    // 0xd4c598: lsl             w3, w23, #1
    // 0xd4c59c: add             w23, w3, #8
    // 0xd4c5a0: ArrayLoad: r24 = r4[r23]  ; Unknown_4
    //     0xd4c5a0: add             x16, x4, w23, sxtw #1
    //     0xd4c5a4: ldur            w24, [x16, #0xf]
    // 0xd4c5a8: DecompressPointer r24
    //     0xd4c5a8: add             x24, x24, HEAP, lsl #32
    // 0xd4c5ac: r16 = "titleSpacing"
    //     0xd4c5ac: add             x16, PP, #0x18, lsl #12  ; [pp+0x18150] "titleSpacing"
    //     0xd4c5b0: ldr             x16, [x16, #0x150]
    // 0xd4c5b4: cmp             w24, w16
    // 0xd4c5b8: b.ne            #0xd4c5e0
    // 0xd4c5bc: add             w23, w3, #0xa
    // 0xd4c5c0: ArrayLoad: r3 = r4[r23]  ; Unknown_4
    //     0xd4c5c0: add             x16, x4, w23, sxtw #1
    //     0xd4c5c4: ldur            w3, [x16, #0xf]
    // 0xd4c5c8: DecompressPointer r3
    //     0xd4c5c8: add             x3, x3, HEAP, lsl #32
    // 0xd4c5cc: sub             w4, w0, w3
    // 0xd4c5d0: add             x0, fp, w4, sxtw #2
    // 0xd4c5d4: ldr             x0, [x0, #8]
    // 0xd4c5d8: mov             x25, x0
    // 0xd4c5dc: b               #0xd4c5e4
    // 0xd4c5e0: r25 = Null
    //     0xd4c5e0: mov             x25, NULL
    // 0xd4c5e4: ldur            x3, [fp, #-8]
    // 0xd4c5e8: r24 = true
    //     0xd4c5e8: add             x24, NULL, #0x20  ; true
    // 0xd4c5ec: r23 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0xd4c5ec: add             x23, PP, #0x18, lsl #12  ; [pp+0x18158] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x7f2adac1b19c)
    //     0xd4c5f0: ldr             x23, [x23, #0x158]
    // 0xd4c5f4: r4 = false
    //     0xd4c5f4: add             x4, NULL, #0x30  ; false
    // 0xd4c5f8: d0 = 1.000000
    //     0xd4c5f8: fmov            d0, #1.00000000
    // 0xd4c5fc: CheckStackOverflow
    //     0xd4c5fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4c600: cmp             SP, x16
    //     0xd4c604: b.ls            #0xd4c87c
    // 0xd4c608: mov             x0, x12
    // 0xd4c60c: StoreField: r2->field_b = r0
    //     0xd4c60c: stur            w0, [x2, #0xb]
    //     0xd4c610: ldurb           w16, [x2, #-1]
    //     0xd4c614: ldurb           w17, [x0, #-1]
    //     0xd4c618: and             x16, x17, x16, lsr #2
    //     0xd4c61c: tst             x16, HEAP, lsr #32
    //     0xd4c620: b.eq            #0xd4c628
    //     0xd4c624: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd4c628: StoreField: r2->field_f = r6
    //     0xd4c628: stur            w6, [x2, #0xf]
    // 0xd4c62c: mov             x0, x1
    // 0xd4c630: StoreField: r2->field_13 = r0
    //     0xd4c630: stur            w0, [x2, #0x13]
    //     0xd4c634: ldurb           w16, [x2, #-1]
    //     0xd4c638: ldurb           w17, [x0, #-1]
    //     0xd4c63c: and             x16, x17, x16, lsr #2
    //     0xd4c640: tst             x16, HEAP, lsr #32
    //     0xd4c644: b.eq            #0xd4c64c
    //     0xd4c648: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd4c64c: mov             x0, x5
    // 0xd4c650: ArrayStore: r2[0] = r0  ; List_4
    //     0xd4c650: stur            w0, [x2, #0x17]
    //     0xd4c654: ldurb           w16, [x2, #-1]
    //     0xd4c658: ldurb           w17, [x0, #-1]
    //     0xd4c65c: and             x16, x17, x16, lsr #2
    //     0xd4c660: tst             x16, HEAP, lsr #32
    //     0xd4c664: b.eq            #0xd4c66c
    //     0xd4c668: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd4c66c: mov             x0, x3
    // 0xd4c670: StoreField: r2->field_1f = r0
    //     0xd4c670: stur            w0, [x2, #0x1f]
    //     0xd4c674: ldurb           w16, [x2, #-1]
    //     0xd4c678: ldurb           w17, [x0, #-1]
    //     0xd4c67c: and             x16, x17, x16, lsr #2
    //     0xd4c680: tst             x16, HEAP, lsr #32
    //     0xd4c684: b.eq            #0xd4c68c
    //     0xd4c688: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd4c68c: mov             x0, x10
    // 0xd4c690: StoreField: r2->field_23 = r0
    //     0xd4c690: stur            w0, [x2, #0x23]
    //     0xd4c694: ldurb           w16, [x2, #-1]
    //     0xd4c698: ldurb           w17, [x0, #-1]
    //     0xd4c69c: and             x16, x17, x16, lsr #2
    //     0xd4c6a0: tst             x16, HEAP, lsr #32
    //     0xd4c6a4: b.eq            #0xd4c6ac
    //     0xd4c6a8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd4c6ac: mov             x0, x13
    // 0xd4c6b0: StoreField: r2->field_27 = r0
    //     0xd4c6b0: stur            w0, [x2, #0x27]
    //     0xd4c6b4: ldurb           w16, [x2, #-1]
    //     0xd4c6b8: ldurb           w17, [x0, #-1]
    //     0xd4c6bc: and             x16, x17, x16, lsr #2
    //     0xd4c6c0: tst             x16, HEAP, lsr #32
    //     0xd4c6c4: b.eq            #0xd4c6cc
    //     0xd4c6c8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd4c6cc: StoreField: r2->field_2b = r23
    //     0xd4c6cc: stur            w23, [x2, #0x2b]
    // 0xd4c6d0: mov             x0, x14
    // 0xd4c6d4: StoreField: r2->field_2f = r0
    //     0xd4c6d4: stur            w0, [x2, #0x2f]
    //     0xd4c6d8: ldurb           w16, [x2, #-1]
    //     0xd4c6dc: ldurb           w17, [x0, #-1]
    //     0xd4c6e0: and             x16, x17, x16, lsr #2
    //     0xd4c6e4: tst             x16, HEAP, lsr #32
    //     0xd4c6e8: b.eq            #0xd4c6f0
    //     0xd4c6ec: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd4c6f0: mov             x0, x20
    // 0xd4c6f4: StoreField: r2->field_33 = r0
    //     0xd4c6f4: stur            w0, [x2, #0x33]
    //     0xd4c6f8: ldurb           w16, [x2, #-1]
    //     0xd4c6fc: ldurb           w17, [x0, #-1]
    //     0xd4c700: and             x16, x17, x16, lsr #2
    //     0xd4c704: tst             x16, HEAP, lsr #32
    //     0xd4c708: b.eq            #0xd4c710
    //     0xd4c70c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd4c710: mov             x0, x19
    // 0xd4c714: StoreField: r2->field_37 = r0
    //     0xd4c714: stur            w0, [x2, #0x37]
    //     0xd4c718: ldurb           w16, [x2, #-1]
    //     0xd4c71c: ldurb           w17, [x0, #-1]
    //     0xd4c720: and             x16, x17, x16, lsr #2
    //     0xd4c724: tst             x16, HEAP, lsr #32
    //     0xd4c728: b.eq            #0xd4c730
    //     0xd4c72c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd4c730: mov             x0, x7
    // 0xd4c734: StoreField: r2->field_3b = r0
    //     0xd4c734: stur            w0, [x2, #0x3b]
    //     0xd4c738: ldurb           w16, [x2, #-1]
    //     0xd4c73c: ldurb           w17, [x0, #-1]
    //     0xd4c740: and             x16, x17, x16, lsr #2
    //     0xd4c744: tst             x16, HEAP, lsr #32
    //     0xd4c748: b.eq            #0xd4c750
    //     0xd4c74c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd4c750: mov             x0, x11
    // 0xd4c754: StoreField: r2->field_43 = r0
    //     0xd4c754: stur            w0, [x2, #0x43]
    //     0xd4c758: ldurb           w16, [x2, #-1]
    //     0xd4c75c: ldurb           w17, [x0, #-1]
    //     0xd4c760: and             x16, x17, x16, lsr #2
    //     0xd4c764: tst             x16, HEAP, lsr #32
    //     0xd4c768: b.eq            #0xd4c770
    //     0xd4c76c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd4c770: StoreField: r2->field_4b = r24
    //     0xd4c770: stur            w24, [x2, #0x4b]
    // 0xd4c774: StoreField: r2->field_4f = r9
    //     0xd4c774: stur            w9, [x2, #0x4f]
    // 0xd4c778: StoreField: r2->field_53 = r4
    //     0xd4c778: stur            w4, [x2, #0x53]
    // 0xd4c77c: mov             x0, x25
    // 0xd4c780: StoreField: r2->field_57 = r0
    //     0xd4c780: stur            w0, [x2, #0x57]
    //     0xd4c784: ldurb           w16, [x2, #-1]
    //     0xd4c788: ldurb           w17, [x0, #-1]
    //     0xd4c78c: and             x16, x17, x16, lsr #2
    //     0xd4c790: tst             x16, HEAP, lsr #32
    //     0xd4c794: b.eq            #0xd4c79c
    //     0xd4c798: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd4c79c: StoreField: r2->field_5b = d0
    //     0xd4c79c: stur            d0, [x2, #0x5b]
    // 0xd4c7a0: StoreField: r2->field_63 = d0
    //     0xd4c7a0: stur            d0, [x2, #0x63]
    // 0xd4c7a4: mov             x0, x8
    // 0xd4c7a8: StoreField: r2->field_7f = r0
    //     0xd4c7a8: stur            w0, [x2, #0x7f]
    //     0xd4c7ac: ldurb           w16, [x2, #-1]
    //     0xd4c7b0: ldurb           w17, [x0, #-1]
    //     0xd4c7b4: and             x16, x17, x16, lsr #2
    //     0xd4c7b8: tst             x16, HEAP, lsr #32
    //     0xd4c7bc: b.eq            #0xd4c7c4
    //     0xd4c7c0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd4c7c4: StoreField: r2->field_83 = r4
    //     0xd4c7c4: stur            w4, [x2, #0x83]
    // 0xd4c7c8: StoreField: r2->field_8f = r4
    //     0xd4c7c8: stur            w4, [x2, #0x8f]
    // 0xd4c7cc: cmp             w3, NULL
    // 0xd4c7d0: b.ne            #0xd4c7e0
    // 0xd4c7d4: mov             x0, x2
    // 0xd4c7d8: r2 = Null
    //     0xd4c7d8: mov             x2, NULL
    // 0xd4c7dc: b               #0xd4c830
    // 0xd4c7e0: r0 = LoadClassIdInstr(r3)
    //     0xd4c7e0: ldur            x0, [x3, #-1]
    //     0xd4c7e4: ubfx            x0, x0, #0xc, #0x14
    // 0xd4c7e8: mov             x1, x3
    // 0xd4c7ec: r0 = GDT[cid_x0 + 0xade]()
    //     0xd4c7ec: add             lr, x0, #0xade
    //     0xd4c7f0: ldr             lr, [x21, lr, lsl #3]
    //     0xd4c7f4: blr             lr
    // 0xd4c7f8: LoadField: d0 = r0->field_f
    //     0xd4c7f8: ldur            d0, [x0, #0xf]
    // 0xd4c7fc: r0 = inline_Allocate_Double()
    //     0xd4c7fc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd4c800: add             x0, x0, #0x10
    //     0xd4c804: cmp             x1, x0
    //     0xd4c808: b.ls            #0xd4c884
    //     0xd4c80c: str             x0, [THR, #0x60]  ; THR::top
    //     0xd4c810: sub             x0, x0, #0xf
    //     0xd4c814: mov             x1, #0xe19c
    //     0xd4c818: movk            x1, #3, lsl #16
    //     0xd4c81c: stur            x1, [x0, #-1]
    // 0xd4c820: dmb             ishst
    // 0xd4c824: StoreField: r0->field_7 = d0
    //     0xd4c824: stur            d0, [x0, #7]
    // 0xd4c828: mov             x2, x0
    // 0xd4c82c: ldur            x0, [fp, #-0x10]
    // 0xd4c830: stur            x2, [fp, #-8]
    // 0xd4c834: r0 = _PreferredAppBarSize()
    //     0xd4c834: bl              #0xd4c92c  ; Allocate_PreferredAppBarSizeStub -> _PreferredAppBarSize (size=0x20)
    // 0xd4c838: mov             x1, x0
    // 0xd4c83c: ldur            x2, [fp, #-8]
    // 0xd4c840: stur            x0, [fp, #-8]
    // 0xd4c844: r0 = _PreferredAppBarSize()
    //     0xd4c844: bl              #0xd4c894  ; [package:flutter/src/material/app_bar.dart] _PreferredAppBarSize::_PreferredAppBarSize
    // 0xd4c848: ldur            x0, [fp, #-8]
    // 0xd4c84c: ldur            x1, [fp, #-0x10]
    // 0xd4c850: StoreField: r1->field_6b = r0
    //     0xd4c850: stur            w0, [x1, #0x6b]
    //     0xd4c854: ldurb           w16, [x1, #-1]
    //     0xd4c858: ldurb           w17, [x0, #-1]
    //     0xd4c85c: and             x16, x17, x16, lsr #2
    //     0xd4c860: tst             x16, HEAP, lsr #32
    //     0xd4c864: b.eq            #0xd4c86c
    //     0xd4c868: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd4c86c: r0 = Null
    //     0xd4c86c: mov             x0, NULL
    // 0xd4c870: LeaveFrame
    //     0xd4c870: mov             SP, fp
    //     0xd4c874: ldp             fp, lr, [SP], #0x10
    // 0xd4c878: ret
    //     0xd4c878: ret             
    // 0xd4c87c: r0 = StackOverflowSharedWithFPURegs()
    //     0xd4c87c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd4c880: b               #0xd4c608
    // 0xd4c884: SaveReg d0
    //     0xd4c884: str             q0, [SP, #-0x10]!
    // 0xd4c888: r0 = AllocateDouble()
    //     0xd4c888: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd4c88c: RestoreReg d0
    //     0xd4c88c: ldr             q0, [SP], #0x10
    // 0xd4c890: b               #0xd4c824
  }
  _ _getEffectiveCenterTitle(/* No info */) {
    // ** addr: 0xde9eec, size: 0xa0
    // 0xde9eec: EnterFrame
    //     0xde9eec: stp             fp, lr, [SP, #-0x10]!
    //     0xde9ef0: mov             fp, SP
    // 0xde9ef4: AllocStack(0x18)
    //     0xde9ef4: sub             SP, SP, #0x18
    // 0xde9ef8: SetupParameters(AppBar this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xde9ef8: stur            x1, [fp, #-8]
    //     0xde9efc: stur            x2, [fp, #-0x10]
    // 0xde9f00: CheckStackOverflow
    //     0xde9f00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde9f04: cmp             SP, x16
    //     0xde9f08: b.ls            #0xde9f84
    // 0xde9f0c: r1 = 2
    //     0xde9f0c: mov             x1, #2
    // 0xde9f10: r0 = AllocateContext()
    //     0xde9f10: bl              #0x13de838  ; AllocateContextStub
    // 0xde9f14: mov             x1, x0
    // 0xde9f18: ldur            x0, [fp, #-8]
    // 0xde9f1c: StoreField: r1->field_f = r0
    //     0xde9f1c: stur            w0, [x1, #0xf]
    // 0xde9f20: ldur            x2, [fp, #-0x10]
    // 0xde9f24: StoreField: r1->field_13 = r2
    //     0xde9f24: stur            w2, [x1, #0x13]
    // 0xde9f28: mov             x2, x1
    // 0xde9f2c: r1 = Function 'platformCenter':.
    //     0xde9f2c: add             x1, PP, #0x90, lsl #12  ; [pp+0x90d78] Function: [dart:core] Object::_simpleInstanceOfFalse (0x13dce48)
    //     0xde9f30: ldr             x1, [x1, #0xd78]
    // 0xde9f34: r0 = AllocateClosure()
    //     0xde9f34: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde9f38: mov             x1, x0
    // 0xde9f3c: ldur            x0, [fp, #-8]
    // 0xde9f40: LoadField: r2 = r0->field_4f
    //     0xde9f40: ldur            w2, [x0, #0x4f]
    // 0xde9f44: DecompressPointer r2
    //     0xde9f44: add             x2, x2, HEAP, lsl #32
    // 0xde9f48: cmp             w2, NULL
    // 0xde9f4c: b.ne            #0xde9f58
    // 0xde9f50: r0 = Null
    //     0xde9f50: mov             x0, NULL
    // 0xde9f54: b               #0xde9f5c
    // 0xde9f58: mov             x0, x2
    // 0xde9f5c: cmp             w0, NULL
    // 0xde9f60: b.ne            #0xde9f78
    // 0xde9f64: str             x1, [SP]
    // 0xde9f68: mov             x0, x1
    // 0xde9f6c: ClosureCall
    //     0xde9f6c: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xde9f70: ldur            x2, [x0, #0x1f]
    //     0xde9f74: blr             x2
    // 0xde9f78: LeaveFrame
    //     0xde9f78: mov             SP, fp
    //     0xde9f7c: ldp             fp, lr, [SP], #0x10
    // 0xde9f80: ret
    //     0xde9f80: ret             
    // 0xde9f84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde9f84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde9f88: b               #0xde9f0c
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa0a58, size: 0x2c
    // 0xfa0a58: EnterFrame
    //     0xfa0a58: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0a5c: mov             fp, SP
    // 0xfa0a60: mov             x0, x1
    // 0xfa0a64: r1 = <AppBar>
    //     0xfa0a64: add             x1, PP, #0x85, lsl #12  ; [pp+0x855c0] TypeArguments: <AppBar>
    //     0xfa0a68: ldr             x1, [x1, #0x5c0]
    // 0xfa0a6c: r0 = _AppBarState()
    //     0xfa0a6c: bl              #0xfa0a84  ; Allocate_AppBarStateStub -> _AppBarState (size=0x1c)
    // 0xfa0a70: r1 = false
    //     0xfa0a70: add             x1, NULL, #0x30  ; false
    // 0xfa0a74: ArrayStore: r0[0] = r1  ; List_4
    //     0xfa0a74: stur            w1, [x0, #0x17]
    // 0xfa0a78: LeaveFrame
    //     0xfa0a78: mov             SP, fp
    //     0xfa0a7c: ldp             fp, lr, [SP], #0x10
    // 0xfa0a80: ret
    //     0xfa0a80: ret             
  }
}

// class id: 6658, size: 0x10, field offset: 0x10
//   const constructor, 
class _AppBarTitleBox extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf451c, size: 0xb4
    // 0xcf451c: EnterFrame
    //     0xcf451c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4520: mov             fp, SP
    // 0xcf4524: AllocStack(0x10)
    //     0xcf4524: sub             SP, SP, #0x10
    // 0xcf4528: SetupParameters(dynamic _ /* r2 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf4528: mov             x4, x2
    //     0xcf452c: stur            x2, [fp, #-8]
    //     0xcf4530: stur            x3, [fp, #-0x10]
    // 0xcf4534: CheckStackOverflow
    //     0xcf4534: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf4538: cmp             SP, x16
    //     0xcf453c: b.ls            #0xcf45c8
    // 0xcf4540: mov             x0, x3
    // 0xcf4544: r2 = Null
    //     0xcf4544: mov             x2, NULL
    // 0xcf4548: r1 = Null
    //     0xcf4548: mov             x1, NULL
    // 0xcf454c: r4 = 60
    //     0xcf454c: mov             x4, #0x3c
    // 0xcf4550: branchIfSmi(r0, 0xcf455c)
    //     0xcf4550: tbz             w0, #0, #0xcf455c
    // 0xcf4554: r4 = LoadClassIdInstr(r0)
    //     0xcf4554: ldur            x4, [x0, #-1]
    //     0xcf4558: ubfx            x4, x4, #0xc, #0x14
    // 0xcf455c: r17 = 4889
    //     0xcf455c: mov             x17, #0x1319
    // 0xcf4560: cmp             x4, x17
    // 0xcf4564: b.eq            #0xcf457c
    // 0xcf4568: r8 = _RenderAppBarTitleBox
    //     0xcf4568: add             x8, PP, #0x9a, lsl #12  ; [pp+0x9a868] Type: _RenderAppBarTitleBox
    //     0xcf456c: ldr             x8, [x8, #0x868]
    // 0xcf4570: r3 = Null
    //     0xcf4570: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a870] Null
    //     0xcf4574: ldr             x3, [x3, #0x870]
    // 0xcf4578: r0 = DefaultTypeTest()
    //     0xcf4578: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf457c: ldur            x1, [fp, #-8]
    // 0xcf4580: r0 = of()
    //     0xcf4580: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xcf4584: ldur            x1, [fp, #-0x10]
    // 0xcf4588: LoadField: r2 = r1->field_5b
    //     0xcf4588: ldur            w2, [x1, #0x5b]
    // 0xcf458c: DecompressPointer r2
    //     0xcf458c: add             x2, x2, HEAP, lsl #32
    // 0xcf4590: cmp             w2, w0
    // 0xcf4594: b.eq            #0xcf45b8
    // 0xcf4598: StoreField: r1->field_5b = r0
    //     0xcf4598: stur            w0, [x1, #0x5b]
    //     0xcf459c: ldurb           w16, [x1, #-1]
    //     0xcf45a0: ldurb           w17, [x0, #-1]
    //     0xcf45a4: and             x16, x17, x16, lsr #2
    //     0xcf45a8: tst             x16, HEAP, lsr #32
    //     0xcf45ac: b.eq            #0xcf45b4
    //     0xcf45b0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf45b4: r0 = _markNeedResolution()
    //     0xcf45b4: bl              #0xcf4640  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::_markNeedResolution
    // 0xcf45b8: r0 = Null
    //     0xcf45b8: mov             x0, NULL
    // 0xcf45bc: LeaveFrame
    //     0xcf45bc: mov             SP, fp
    //     0xcf45c0: ldp             fp, lr, [SP], #0x10
    // 0xcf45c4: ret
    //     0xcf45c4: ret             
    // 0xcf45c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf45c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf45cc: b               #0xcf4540
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11cf668, size: 0x54
    // 0x11cf668: EnterFrame
    //     0x11cf668: stp             fp, lr, [SP, #-0x10]!
    //     0x11cf66c: mov             fp, SP
    // 0x11cf670: AllocStack(0x8)
    //     0x11cf670: sub             SP, SP, #8
    // 0x11cf674: SetupParameters(_AppBarTitleBox this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x11cf674: mov             x0, x1
    //     0x11cf678: mov             x1, x2
    // 0x11cf67c: CheckStackOverflow
    //     0x11cf67c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cf680: cmp             SP, x16
    //     0x11cf684: b.ls            #0x11cf6b4
    // 0x11cf688: r0 = of()
    //     0x11cf688: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x11cf68c: stur            x0, [fp, #-8]
    // 0x11cf690: r0 = _RenderAppBarTitleBox()
    //     0x11cf690: bl              #0x11cf760  ; Allocate_RenderAppBarTitleBoxStub -> _RenderAppBarTitleBox (size=0x60)
    // 0x11cf694: mov             x1, x0
    // 0x11cf698: ldur            x2, [fp, #-8]
    // 0x11cf69c: stur            x0, [fp, #-8]
    // 0x11cf6a0: r0 = _RenderAppBarTitleBox()
    //     0x11cf6a0: bl              #0x11cf6bc  ; [package:flutter/src/material/app_bar.dart] _RenderAppBarTitleBox::_RenderAppBarTitleBox
    // 0x11cf6a4: ldur            x0, [fp, #-8]
    // 0x11cf6a8: LeaveFrame
    //     0x11cf6a8: mov             SP, fp
    //     0x11cf6ac: ldp             fp, lr, [SP], #0x10
    // 0x11cf6b0: ret
    //     0x11cf6b0: ret             
    // 0x11cf6b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cf6b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cf6b8: b               #0x11cf688
  }
}
