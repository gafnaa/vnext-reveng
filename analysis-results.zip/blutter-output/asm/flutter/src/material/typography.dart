// lib: , url: package:flutter/src/material/typography.dart

// class id: 1048975, size: 0x8
class :: {
}

// class id: 5049, size: 0x1c, field offset: 0x8
//   const constructor, 
class Typography extends _MixinApplication3&Object&Diagnosticable {

  factory _ Typography.material2014(/* No info */) {
    // ** addr: 0x8ac808, size: 0x48
    // 0x8ac808: EnterFrame
    //     0x8ac808: stp             fp, lr, [SP, #-0x10]!
    //     0x8ac80c: mov             fp, SP
    // 0x8ac810: CheckStackOverflow
    //     0x8ac810: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ac814: cmp             SP, x16
    //     0x8ac818: b.ls            #0x8ac848
    // 0x8ac81c: r1 = Null
    //     0x8ac81c: mov             x1, NULL
    // 0x8ac820: r2 = Instance_TextTheme
    //     0x8ac820: add             x2, PP, #0x12, lsl #12  ; [pp+0x12e98] Obj!TextTheme@12b1ee1
    //     0x8ac824: ldr             x2, [x2, #0xe98]
    // 0x8ac828: r3 = Instance_TextTheme
    //     0x8ac828: add             x3, PP, #0x12, lsl #12  ; [pp+0x12ea0] Obj!TextTheme@12b1e91
    //     0x8ac82c: ldr             x3, [x3, #0xea0]
    // 0x8ac830: r5 = Instance_TextTheme
    //     0x8ac830: add             x5, PP, #0x12, lsl #12  ; [pp+0x12ea8] Obj!TextTheme@12b1e41
    //     0x8ac834: ldr             x5, [x5, #0xea8]
    // 0x8ac838: r0 = Typography._withPlatform()
    //     0x8ac838: bl              #0x8ac850  ; [package:flutter/src/material/typography.dart] Typography::Typography._withPlatform
    // 0x8ac83c: LeaveFrame
    //     0x8ac83c: mov             SP, fp
    //     0x8ac840: ldp             fp, lr, [SP], #0x10
    // 0x8ac844: ret
    //     0x8ac844: ret             
    // 0x8ac848: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ac848: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ac84c: b               #0x8ac81c
  }
  factory _ Typography._withPlatform(/* No info */) {
    // ** addr: 0x8ac850, size: 0x58
    // 0x8ac850: EnterFrame
    //     0x8ac850: stp             fp, lr, [SP, #-0x10]!
    //     0x8ac854: mov             fp, SP
    // 0x8ac858: AllocStack(0x18)
    //     0x8ac858: sub             SP, SP, #0x18
    // 0x8ac85c: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */)
    //     0x8ac85c: stur            x2, [fp, #-8]
    //     0x8ac860: stur            x3, [fp, #-0x10]
    //     0x8ac864: stur            x5, [fp, #-0x18]
    // 0x8ac868: r0 = Typography()
    //     0x8ac868: bl              #0x8ac8a8  ; AllocateTypographyStub -> Typography (size=0x1c)
    // 0x8ac86c: r1 = Instance_TextTheme
    //     0x8ac86c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12eb0] Obj!TextTheme@12b1df1
    //     0x8ac870: ldr             x1, [x1, #0xeb0]
    // 0x8ac874: StoreField: r0->field_7 = r1
    //     0x8ac874: stur            w1, [x0, #7]
    // 0x8ac878: r1 = Instance_TextTheme
    //     0x8ac878: add             x1, PP, #0x12, lsl #12  ; [pp+0x12eb8] Obj!TextTheme@12b1da1
    //     0x8ac87c: ldr             x1, [x1, #0xeb8]
    // 0x8ac880: StoreField: r0->field_b = r1
    //     0x8ac880: stur            w1, [x0, #0xb]
    // 0x8ac884: ldur            x1, [fp, #-8]
    // 0x8ac888: StoreField: r0->field_f = r1
    //     0x8ac888: stur            w1, [x0, #0xf]
    // 0x8ac88c: ldur            x1, [fp, #-0x10]
    // 0x8ac890: StoreField: r0->field_13 = r1
    //     0x8ac890: stur            w1, [x0, #0x13]
    // 0x8ac894: ldur            x1, [fp, #-0x18]
    // 0x8ac898: ArrayStore: r0[0] = r1  ; List_4
    //     0x8ac898: stur            w1, [x0, #0x17]
    // 0x8ac89c: LeaveFrame
    //     0x8ac89c: mov             SP, fp
    //     0x8ac8a0: ldp             fp, lr, [SP], #0x10
    // 0x8ac8a4: ret
    //     0x8ac8a4: ret             
  }
  factory _ Typography.material2021(/* No info */) {
    // ** addr: 0x8ac95c, size: 0x104
    // 0x8ac95c: EnterFrame
    //     0x8ac95c: stp             fp, lr, [SP, #-0x10]!
    //     0x8ac960: mov             fp, SP
    // 0x8ac964: AllocStack(0x18)
    //     0x8ac964: sub             SP, SP, #0x18
    // 0x8ac968: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x8ac968: mov             x0, x2
    //     0x8ac96c: stur            x2, [fp, #-8]
    // 0x8ac970: CheckStackOverflow
    //     0x8ac970: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ac974: cmp             SP, x16
    //     0x8ac978: b.ls            #0x8aca58
    // 0x8ac97c: r1 = Null
    //     0x8ac97c: mov             x1, NULL
    // 0x8ac980: r2 = Instance_TextTheme
    //     0x8ac980: add             x2, PP, #0x12, lsl #12  ; [pp+0x12ec0] Obj!TextTheme@12b1fd1
    //     0x8ac984: ldr             x2, [x2, #0xec0]
    // 0x8ac988: r3 = Instance_TextTheme
    //     0x8ac988: add             x3, PP, #0x12, lsl #12  ; [pp+0x12ec8] Obj!TextTheme@12b1f81
    //     0x8ac98c: ldr             x3, [x3, #0xec8]
    // 0x8ac990: r5 = Instance_TextTheme
    //     0x8ac990: add             x5, PP, #0x12, lsl #12  ; [pp+0x12ed0] Obj!TextTheme@12b1f31
    //     0x8ac994: ldr             x5, [x5, #0xed0]
    // 0x8ac998: r0 = Typography._withPlatform()
    //     0x8ac998: bl              #0x8ac850  ; [package:flutter/src/material/typography.dart] Typography::Typography._withPlatform
    // 0x8ac99c: mov             x4, x0
    // 0x8ac9a0: ldur            x0, [fp, #-8]
    // 0x8ac9a4: stur            x4, [fp, #-0x10]
    // 0x8ac9a8: LoadField: r1 = r0->field_7
    //     0x8ac9a8: ldur            w1, [x0, #7]
    // 0x8ac9ac: DecompressPointer r1
    //     0x8ac9ac: add             x1, x1, HEAP, lsl #32
    // 0x8ac9b0: r16 = Instance_Brightness
    //     0x8ac9b0: ldr             x16, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0x8ac9b4: cmp             w1, w16
    // 0x8ac9b8: b.ne            #0x8ac9cc
    // 0x8ac9bc: LoadField: r2 = r0->field_7f
    //     0x8ac9bc: ldur            w2, [x0, #0x7f]
    // 0x8ac9c0: DecompressPointer r2
    //     0x8ac9c0: add             x2, x2, HEAP, lsl #32
    // 0x8ac9c4: mov             x5, x2
    // 0x8ac9c8: b               #0x8ac9d8
    // 0x8ac9cc: LoadField: r2 = r0->field_7b
    //     0x8ac9cc: ldur            w2, [x0, #0x7b]
    // 0x8ac9d0: DecompressPointer r2
    //     0x8ac9d0: add             x2, x2, HEAP, lsl #32
    // 0x8ac9d4: mov             x5, x2
    // 0x8ac9d8: r16 = Instance_Brightness
    //     0x8ac9d8: ldr             x16, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0x8ac9dc: cmp             w1, w16
    // 0x8ac9e0: b.ne            #0x8ac9f4
    // 0x8ac9e4: LoadField: r1 = r0->field_7b
    //     0x8ac9e4: ldur            w1, [x0, #0x7b]
    // 0x8ac9e8: DecompressPointer r1
    //     0x8ac9e8: add             x1, x1, HEAP, lsl #32
    // 0x8ac9ec: mov             x0, x1
    // 0x8ac9f0: b               #0x8aca00
    // 0x8ac9f4: LoadField: r1 = r0->field_7f
    //     0x8ac9f4: ldur            w1, [x0, #0x7f]
    // 0x8ac9f8: DecompressPointer r1
    //     0x8ac9f8: add             x1, x1, HEAP, lsl #32
    // 0x8ac9fc: mov             x0, x1
    // 0x8aca00: stur            x0, [fp, #-8]
    // 0x8aca04: LoadField: r1 = r4->field_7
    //     0x8aca04: ldur            w1, [x4, #7]
    // 0x8aca08: DecompressPointer r1
    //     0x8aca08: add             x1, x1, HEAP, lsl #32
    // 0x8aca0c: mov             x2, x5
    // 0x8aca10: mov             x3, x5
    // 0x8aca14: r0 = apply()
    //     0x8aca14: bl              #0x8acad0  ; [package:flutter/src/material/text_theme.dart] TextTheme::apply
    // 0x8aca18: mov             x4, x0
    // 0x8aca1c: ldur            x0, [fp, #-0x10]
    // 0x8aca20: stur            x4, [fp, #-0x18]
    // 0x8aca24: LoadField: r1 = r0->field_b
    //     0x8aca24: ldur            w1, [x0, #0xb]
    // 0x8aca28: DecompressPointer r1
    //     0x8aca28: add             x1, x1, HEAP, lsl #32
    // 0x8aca2c: ldur            x2, [fp, #-8]
    // 0x8aca30: ldur            x3, [fp, #-8]
    // 0x8aca34: ldur            x5, [fp, #-8]
    // 0x8aca38: r0 = apply()
    //     0x8aca38: bl              #0x8acad0  ; [package:flutter/src/material/text_theme.dart] TextTheme::apply
    // 0x8aca3c: ldur            x1, [fp, #-0x10]
    // 0x8aca40: ldur            x2, [fp, #-0x18]
    // 0x8aca44: mov             x3, x0
    // 0x8aca48: r0 = copyWith()
    //     0x8aca48: bl              #0x8aca60  ; [package:flutter/src/material/typography.dart] Typography::copyWith
    // 0x8aca4c: LeaveFrame
    //     0x8aca4c: mov             SP, fp
    //     0x8aca50: ldp             fp, lr, [SP], #0x10
    // 0x8aca54: ret
    //     0x8aca54: ret             
    // 0x8aca58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8aca58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8aca5c: b               #0x8ac97c
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x8aca60, size: 0x70
    // 0x8aca60: EnterFrame
    //     0x8aca60: stp             fp, lr, [SP, #-0x10]!
    //     0x8aca64: mov             fp, SP
    // 0x8aca68: AllocStack(0x28)
    //     0x8aca68: sub             SP, SP, #0x28
    // 0x8aca6c: SetupParameters(dynamic _ /* r2 => r2, fp-0x20 */, dynamic _ /* r3 => r3, fp-0x28 */)
    //     0x8aca6c: stur            x2, [fp, #-0x20]
    //     0x8aca70: stur            x3, [fp, #-0x28]
    // 0x8aca74: LoadField: r0 = r1->field_f
    //     0x8aca74: ldur            w0, [x1, #0xf]
    // 0x8aca78: DecompressPointer r0
    //     0x8aca78: add             x0, x0, HEAP, lsl #32
    // 0x8aca7c: stur            x0, [fp, #-0x18]
    // 0x8aca80: LoadField: r4 = r1->field_13
    //     0x8aca80: ldur            w4, [x1, #0x13]
    // 0x8aca84: DecompressPointer r4
    //     0x8aca84: add             x4, x4, HEAP, lsl #32
    // 0x8aca88: stur            x4, [fp, #-0x10]
    // 0x8aca8c: ArrayLoad: r5 = r1[0]  ; List_4
    //     0x8aca8c: ldur            w5, [x1, #0x17]
    // 0x8aca90: DecompressPointer r5
    //     0x8aca90: add             x5, x5, HEAP, lsl #32
    // 0x8aca94: stur            x5, [fp, #-8]
    // 0x8aca98: r0 = Typography()
    //     0x8aca98: bl              #0x8ac8a8  ; AllocateTypographyStub -> Typography (size=0x1c)
    // 0x8aca9c: ldur            x1, [fp, #-0x20]
    // 0x8acaa0: StoreField: r0->field_7 = r1
    //     0x8acaa0: stur            w1, [x0, #7]
    // 0x8acaa4: ldur            x1, [fp, #-0x28]
    // 0x8acaa8: StoreField: r0->field_b = r1
    //     0x8acaa8: stur            w1, [x0, #0xb]
    // 0x8acaac: ldur            x1, [fp, #-0x18]
    // 0x8acab0: StoreField: r0->field_f = r1
    //     0x8acab0: stur            w1, [x0, #0xf]
    // 0x8acab4: ldur            x1, [fp, #-0x10]
    // 0x8acab8: StoreField: r0->field_13 = r1
    //     0x8acab8: stur            w1, [x0, #0x13]
    // 0x8acabc: ldur            x1, [fp, #-8]
    // 0x8acac0: ArrayStore: r0[0] = r1  ; List_4
    //     0x8acac0: stur            w1, [x0, #0x17]
    // 0x8acac4: LeaveFrame
    //     0x8acac4: mov             SP, fp
    //     0x8acac8: ldp             fp, lr, [SP], #0x10
    // 0x8acacc: ret
    //     0x8acacc: ret             
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x113b200, size: 0x84
    // 0x113b200: EnterFrame
    //     0x113b200: stp             fp, lr, [SP, #-0x10]!
    //     0x113b204: mov             fp, SP
    // 0x113b208: AllocStack(0x18)
    //     0x113b208: sub             SP, SP, #0x18
    // 0x113b20c: CheckStackOverflow
    //     0x113b20c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x113b210: cmp             SP, x16
    //     0x113b214: b.ls            #0x113b27c
    // 0x113b218: ldr             x0, [fp, #0x10]
    // 0x113b21c: LoadField: r1 = r0->field_7
    //     0x113b21c: ldur            w1, [x0, #7]
    // 0x113b220: DecompressPointer r1
    //     0x113b220: add             x1, x1, HEAP, lsl #32
    // 0x113b224: LoadField: r2 = r0->field_b
    //     0x113b224: ldur            w2, [x0, #0xb]
    // 0x113b228: DecompressPointer r2
    //     0x113b228: add             x2, x2, HEAP, lsl #32
    // 0x113b22c: LoadField: r3 = r0->field_f
    //     0x113b22c: ldur            w3, [x0, #0xf]
    // 0x113b230: DecompressPointer r3
    //     0x113b230: add             x3, x3, HEAP, lsl #32
    // 0x113b234: LoadField: r4 = r0->field_13
    //     0x113b234: ldur            w4, [x0, #0x13]
    // 0x113b238: DecompressPointer r4
    //     0x113b238: add             x4, x4, HEAP, lsl #32
    // 0x113b23c: ArrayLoad: r5 = r0[0]  ; List_4
    //     0x113b23c: ldur            w5, [x0, #0x17]
    // 0x113b240: DecompressPointer r5
    //     0x113b240: add             x5, x5, HEAP, lsl #32
    // 0x113b244: stp             x4, x3, [SP, #8]
    // 0x113b248: str             x5, [SP]
    // 0x113b24c: r4 = const [0, 0x5, 0x3, 0x5, null]
    //     0x113b24c: add             x4, PP, #0xd, lsl #12  ; [pp+0xdc80] List(5) [0, 0x5, 0x3, 0x5, Null]
    //     0x113b250: ldr             x4, [x4, #0xc80]
    // 0x113b254: r0 = hash()
    //     0x113b254: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x113b258: mov             x2, x0
    // 0x113b25c: r0 = BoxInt64Instr(r2)
    //     0x113b25c: sbfiz           x0, x2, #1, #0x1f
    //     0x113b260: cmp             x2, x0, asr #1
    //     0x113b264: b.eq            #0x113b270
    //     0x113b268: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113b26c: stur            x2, [x0, #7]
    // 0x113b270: LeaveFrame
    //     0x113b270: mov             SP, fp
    //     0x113b274: ldp             fp, lr, [SP], #0x10
    // 0x113b278: ret
    //     0x113b278: ret             
    // 0x113b27c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x113b27c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x113b280: b               #0x113b218
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x11691c4, size: 0x144
    // 0x11691c4: EnterFrame
    //     0x11691c4: stp             fp, lr, [SP, #-0x10]!
    //     0x11691c8: mov             fp, SP
    // 0x11691cc: AllocStack(0x38)
    //     0x11691cc: sub             SP, SP, #0x38
    // 0x11691d0: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x38 */)
    //     0x11691d0: mov             x3, x1
    //     0x11691d4: mov             x0, x2
    //     0x11691d8: mov             v1.16b, v0.16b
    //     0x11691dc: stur            x1, [fp, #-8]
    //     0x11691e0: stur            x2, [fp, #-0x10]
    //     0x11691e4: stur            d0, [fp, #-0x38]
    // 0x11691e8: CheckStackOverflow
    //     0x11691e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11691ec: cmp             SP, x16
    //     0x11691f0: b.ls            #0x1169300
    // 0x11691f4: cmp             w3, w0
    // 0x11691f8: b.ne            #0x116920c
    // 0x11691fc: mov             x0, x3
    // 0x1169200: LeaveFrame
    //     0x1169200: mov             SP, fp
    //     0x1169204: ldp             fp, lr, [SP], #0x10
    // 0x1169208: ret
    //     0x1169208: ret             
    // 0x116920c: LoadField: r1 = r3->field_7
    //     0x116920c: ldur            w1, [x3, #7]
    // 0x1169210: DecompressPointer r1
    //     0x1169210: add             x1, x1, HEAP, lsl #32
    // 0x1169214: LoadField: r2 = r0->field_7
    //     0x1169214: ldur            w2, [x0, #7]
    // 0x1169218: DecompressPointer r2
    //     0x1169218: add             x2, x2, HEAP, lsl #32
    // 0x116921c: mov             v0.16b, v1.16b
    // 0x1169220: r0 = lerp()
    //     0x1169220: bl              #0x1169308  ; [package:flutter/src/material/text_theme.dart] TextTheme::lerp
    // 0x1169224: mov             x3, x0
    // 0x1169228: ldur            x0, [fp, #-8]
    // 0x116922c: stur            x3, [fp, #-0x18]
    // 0x1169230: LoadField: r1 = r0->field_b
    //     0x1169230: ldur            w1, [x0, #0xb]
    // 0x1169234: DecompressPointer r1
    //     0x1169234: add             x1, x1, HEAP, lsl #32
    // 0x1169238: ldur            x4, [fp, #-0x10]
    // 0x116923c: LoadField: r2 = r4->field_b
    //     0x116923c: ldur            w2, [x4, #0xb]
    // 0x1169240: DecompressPointer r2
    //     0x1169240: add             x2, x2, HEAP, lsl #32
    // 0x1169244: ldur            d0, [fp, #-0x38]
    // 0x1169248: r0 = lerp()
    //     0x1169248: bl              #0x1169308  ; [package:flutter/src/material/text_theme.dart] TextTheme::lerp
    // 0x116924c: mov             x3, x0
    // 0x1169250: ldur            x0, [fp, #-8]
    // 0x1169254: stur            x3, [fp, #-0x20]
    // 0x1169258: LoadField: r1 = r0->field_f
    //     0x1169258: ldur            w1, [x0, #0xf]
    // 0x116925c: DecompressPointer r1
    //     0x116925c: add             x1, x1, HEAP, lsl #32
    // 0x1169260: ldur            x4, [fp, #-0x10]
    // 0x1169264: LoadField: r2 = r4->field_f
    //     0x1169264: ldur            w2, [x4, #0xf]
    // 0x1169268: DecompressPointer r2
    //     0x1169268: add             x2, x2, HEAP, lsl #32
    // 0x116926c: ldur            d0, [fp, #-0x38]
    // 0x1169270: r0 = lerp()
    //     0x1169270: bl              #0x1169308  ; [package:flutter/src/material/text_theme.dart] TextTheme::lerp
    // 0x1169274: mov             x3, x0
    // 0x1169278: ldur            x0, [fp, #-8]
    // 0x116927c: stur            x3, [fp, #-0x28]
    // 0x1169280: LoadField: r1 = r0->field_13
    //     0x1169280: ldur            w1, [x0, #0x13]
    // 0x1169284: DecompressPointer r1
    //     0x1169284: add             x1, x1, HEAP, lsl #32
    // 0x1169288: ldur            x4, [fp, #-0x10]
    // 0x116928c: LoadField: r2 = r4->field_13
    //     0x116928c: ldur            w2, [x4, #0x13]
    // 0x1169290: DecompressPointer r2
    //     0x1169290: add             x2, x2, HEAP, lsl #32
    // 0x1169294: ldur            d0, [fp, #-0x38]
    // 0x1169298: r0 = lerp()
    //     0x1169298: bl              #0x1169308  ; [package:flutter/src/material/text_theme.dart] TextTheme::lerp
    // 0x116929c: mov             x3, x0
    // 0x11692a0: ldur            x0, [fp, #-8]
    // 0x11692a4: stur            x3, [fp, #-0x30]
    // 0x11692a8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11692a8: ldur            w1, [x0, #0x17]
    // 0x11692ac: DecompressPointer r1
    //     0x11692ac: add             x1, x1, HEAP, lsl #32
    // 0x11692b0: ldur            x0, [fp, #-0x10]
    // 0x11692b4: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x11692b4: ldur            w2, [x0, #0x17]
    // 0x11692b8: DecompressPointer r2
    //     0x11692b8: add             x2, x2, HEAP, lsl #32
    // 0x11692bc: ldur            d0, [fp, #-0x38]
    // 0x11692c0: r0 = lerp()
    //     0x11692c0: bl              #0x1169308  ; [package:flutter/src/material/text_theme.dart] TextTheme::lerp
    // 0x11692c4: stur            x0, [fp, #-8]
    // 0x11692c8: r0 = Typography()
    //     0x11692c8: bl              #0x8ac8a8  ; AllocateTypographyStub -> Typography (size=0x1c)
    // 0x11692cc: ldur            x1, [fp, #-0x18]
    // 0x11692d0: StoreField: r0->field_7 = r1
    //     0x11692d0: stur            w1, [x0, #7]
    // 0x11692d4: ldur            x1, [fp, #-0x20]
    // 0x11692d8: StoreField: r0->field_b = r1
    //     0x11692d8: stur            w1, [x0, #0xb]
    // 0x11692dc: ldur            x1, [fp, #-0x28]
    // 0x11692e0: StoreField: r0->field_f = r1
    //     0x11692e0: stur            w1, [x0, #0xf]
    // 0x11692e4: ldur            x1, [fp, #-0x30]
    // 0x11692e8: StoreField: r0->field_13 = r1
    //     0x11692e8: stur            w1, [x0, #0x13]
    // 0x11692ec: ldur            x1, [fp, #-8]
    // 0x11692f0: ArrayStore: r0[0] = r1  ; List_4
    //     0x11692f0: stur            w1, [x0, #0x17]
    // 0x11692f4: LeaveFrame
    //     0x11692f4: mov             SP, fp
    //     0x11692f8: ldp             fp, lr, [SP], #0x10
    // 0x11692fc: ret
    //     0x11692fc: ret             
    // 0x1169300: r0 = StackOverflowSharedWithFPURegs()
    //     0x1169300: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1169304: b               #0x11691f4
  }
  _ ==(/* No info */) {
    // ** addr: 0x12786dc, size: 0x178
    // 0x12786dc: EnterFrame
    //     0x12786dc: stp             fp, lr, [SP, #-0x10]!
    //     0x12786e0: mov             fp, SP
    // 0x12786e4: AllocStack(0x10)
    //     0x12786e4: sub             SP, SP, #0x10
    // 0x12786e8: CheckStackOverflow
    //     0x12786e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12786ec: cmp             SP, x16
    //     0x12786f0: b.ls            #0x127884c
    // 0x12786f4: ldr             x0, [fp, #0x10]
    // 0x12786f8: cmp             w0, NULL
    // 0x12786fc: b.ne            #0x1278710
    // 0x1278700: r0 = false
    //     0x1278700: add             x0, NULL, #0x30  ; false
    // 0x1278704: LeaveFrame
    //     0x1278704: mov             SP, fp
    //     0x1278708: ldp             fp, lr, [SP], #0x10
    // 0x127870c: ret
    //     0x127870c: ret             
    // 0x1278710: ldr             x1, [fp, #0x18]
    // 0x1278714: cmp             w1, w0
    // 0x1278718: b.ne            #0x127872c
    // 0x127871c: r0 = true
    //     0x127871c: add             x0, NULL, #0x20  ; true
    // 0x1278720: LeaveFrame
    //     0x1278720: mov             SP, fp
    //     0x1278724: ldp             fp, lr, [SP], #0x10
    // 0x1278728: ret
    //     0x1278728: ret             
    // 0x127872c: str             x0, [SP]
    // 0x1278730: r0 = runtimeType()
    //     0x1278730: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1278734: r1 = LoadClassIdInstr(r0)
    //     0x1278734: ldur            x1, [x0, #-1]
    //     0x1278738: ubfx            x1, x1, #0xc, #0x14
    // 0x127873c: r16 = Typography
    //     0x127873c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26088] Type: Typography
    //     0x1278740: ldr             x16, [x16, #0x88]
    // 0x1278744: stp             x16, x0, [SP]
    // 0x1278748: mov             x0, x1
    // 0x127874c: mov             lr, x0
    // 0x1278750: ldr             lr, [x21, lr, lsl #3]
    // 0x1278754: blr             lr
    // 0x1278758: tbz             w0, #4, #0x127876c
    // 0x127875c: r0 = false
    //     0x127875c: add             x0, NULL, #0x30  ; false
    // 0x1278760: LeaveFrame
    //     0x1278760: mov             SP, fp
    //     0x1278764: ldp             fp, lr, [SP], #0x10
    // 0x1278768: ret
    //     0x1278768: ret             
    // 0x127876c: ldr             x0, [fp, #0x10]
    // 0x1278770: r1 = 60
    //     0x1278770: mov             x1, #0x3c
    // 0x1278774: branchIfSmi(r0, 0x1278780)
    //     0x1278774: tbz             w0, #0, #0x1278780
    // 0x1278778: r1 = LoadClassIdInstr(r0)
    //     0x1278778: ldur            x1, [x0, #-1]
    //     0x127877c: ubfx            x1, x1, #0xc, #0x14
    // 0x1278780: r17 = 5049
    //     0x1278780: mov             x17, #0x13b9
    // 0x1278784: cmp             x1, x17
    // 0x1278788: b.ne            #0x127883c
    // 0x127878c: ldr             x1, [fp, #0x18]
    // 0x1278790: LoadField: r2 = r0->field_7
    //     0x1278790: ldur            w2, [x0, #7]
    // 0x1278794: DecompressPointer r2
    //     0x1278794: add             x2, x2, HEAP, lsl #32
    // 0x1278798: LoadField: r3 = r1->field_7
    //     0x1278798: ldur            w3, [x1, #7]
    // 0x127879c: DecompressPointer r3
    //     0x127879c: add             x3, x3, HEAP, lsl #32
    // 0x12787a0: stp             x3, x2, [SP]
    // 0x12787a4: r0 = ==()
    //     0x12787a4: bl              #0x12770f8  ; [package:flutter/src/material/text_theme.dart] TextTheme::==
    // 0x12787a8: tbnz            w0, #4, #0x127883c
    // 0x12787ac: ldr             x1, [fp, #0x18]
    // 0x12787b0: ldr             x0, [fp, #0x10]
    // 0x12787b4: LoadField: r2 = r0->field_b
    //     0x12787b4: ldur            w2, [x0, #0xb]
    // 0x12787b8: DecompressPointer r2
    //     0x12787b8: add             x2, x2, HEAP, lsl #32
    // 0x12787bc: LoadField: r3 = r1->field_b
    //     0x12787bc: ldur            w3, [x1, #0xb]
    // 0x12787c0: DecompressPointer r3
    //     0x12787c0: add             x3, x3, HEAP, lsl #32
    // 0x12787c4: stp             x3, x2, [SP]
    // 0x12787c8: r0 = ==()
    //     0x12787c8: bl              #0x12770f8  ; [package:flutter/src/material/text_theme.dart] TextTheme::==
    // 0x12787cc: tbnz            w0, #4, #0x127883c
    // 0x12787d0: ldr             x1, [fp, #0x18]
    // 0x12787d4: ldr             x0, [fp, #0x10]
    // 0x12787d8: LoadField: r2 = r0->field_f
    //     0x12787d8: ldur            w2, [x0, #0xf]
    // 0x12787dc: DecompressPointer r2
    //     0x12787dc: add             x2, x2, HEAP, lsl #32
    // 0x12787e0: LoadField: r3 = r1->field_f
    //     0x12787e0: ldur            w3, [x1, #0xf]
    // 0x12787e4: DecompressPointer r3
    //     0x12787e4: add             x3, x3, HEAP, lsl #32
    // 0x12787e8: stp             x3, x2, [SP]
    // 0x12787ec: r0 = ==()
    //     0x12787ec: bl              #0x12770f8  ; [package:flutter/src/material/text_theme.dart] TextTheme::==
    // 0x12787f0: tbnz            w0, #4, #0x127883c
    // 0x12787f4: ldr             x1, [fp, #0x18]
    // 0x12787f8: ldr             x0, [fp, #0x10]
    // 0x12787fc: LoadField: r2 = r0->field_13
    //     0x12787fc: ldur            w2, [x0, #0x13]
    // 0x1278800: DecompressPointer r2
    //     0x1278800: add             x2, x2, HEAP, lsl #32
    // 0x1278804: LoadField: r3 = r1->field_13
    //     0x1278804: ldur            w3, [x1, #0x13]
    // 0x1278808: DecompressPointer r3
    //     0x1278808: add             x3, x3, HEAP, lsl #32
    // 0x127880c: stp             x3, x2, [SP]
    // 0x1278810: r0 = ==()
    //     0x1278810: bl              #0x12770f8  ; [package:flutter/src/material/text_theme.dart] TextTheme::==
    // 0x1278814: tbnz            w0, #4, #0x127883c
    // 0x1278818: ldr             x1, [fp, #0x18]
    // 0x127881c: ldr             x0, [fp, #0x10]
    // 0x1278820: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x1278820: ldur            w2, [x0, #0x17]
    // 0x1278824: DecompressPointer r2
    //     0x1278824: add             x2, x2, HEAP, lsl #32
    // 0x1278828: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x1278828: ldur            w0, [x1, #0x17]
    // 0x127882c: DecompressPointer r0
    //     0x127882c: add             x0, x0, HEAP, lsl #32
    // 0x1278830: stp             x0, x2, [SP]
    // 0x1278834: r0 = ==()
    //     0x1278834: bl              #0x12770f8  ; [package:flutter/src/material/text_theme.dart] TextTheme::==
    // 0x1278838: b               #0x1278840
    // 0x127883c: r0 = false
    //     0x127883c: add             x0, NULL, #0x30  ; false
    // 0x1278840: LeaveFrame
    //     0x1278840: mov             SP, fp
    //     0x1278844: ldp             fp, lr, [SP], #0x10
    // 0x1278848: ret
    //     0x1278848: ret             
    // 0x127884c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x127884c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1278850: b               #0x12786f4
  }
}

// class id: 8254, size: 0x14, field offset: 0x14
enum ScriptCategory extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aabe8, size: 0x64
    // 0x11aabe8: EnterFrame
    //     0x11aabe8: stp             fp, lr, [SP, #-0x10]!
    //     0x11aabec: mov             fp, SP
    // 0x11aabf0: AllocStack(0x10)
    //     0x11aabf0: sub             SP, SP, #0x10
    // 0x11aabf4: SetupParameters(ScriptCategory this /* r1 => r0, fp-0x8 */)
    //     0x11aabf4: mov             x0, x1
    //     0x11aabf8: stur            x1, [fp, #-8]
    // 0x11aabfc: CheckStackOverflow
    //     0x11aabfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aac00: cmp             SP, x16
    //     0x11aac04: b.ls            #0x11aac44
    // 0x11aac08: r1 = Null
    //     0x11aac08: mov             x1, NULL
    // 0x11aac0c: r2 = 4
    //     0x11aac0c: mov             x2, #4
    // 0x11aac10: r0 = AllocateArray()
    //     0x11aac10: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aac14: r16 = "ScriptCategory."
    //     0x11aac14: add             x16, PP, #0x26, lsl #12  ; [pp+0x26080] "ScriptCategory."
    //     0x11aac18: ldr             x16, [x16, #0x80]
    // 0x11aac1c: StoreField: r0->field_f = r16
    //     0x11aac1c: stur            w16, [x0, #0xf]
    // 0x11aac20: ldur            x1, [fp, #-8]
    // 0x11aac24: LoadField: r2 = r1->field_f
    //     0x11aac24: ldur            w2, [x1, #0xf]
    // 0x11aac28: DecompressPointer r2
    //     0x11aac28: add             x2, x2, HEAP, lsl #32
    // 0x11aac2c: StoreField: r0->field_13 = r2
    //     0x11aac2c: stur            w2, [x0, #0x13]
    // 0x11aac30: str             x0, [SP]
    // 0x11aac34: r0 = _interpolate()
    //     0x11aac34: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aac38: LeaveFrame
    //     0x11aac38: mov             SP, fp
    //     0x11aac3c: ldp             fp, lr, [SP], #0x10
    // 0x11aac40: ret
    //     0x11aac40: ret             
    // 0x11aac44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aac44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aac48: b               #0x11aac08
  }
}
