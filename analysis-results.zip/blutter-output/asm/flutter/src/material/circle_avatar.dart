// lib: , url: package:flutter/src/material/circle_avatar.dart

// class id: 1048868, size: 0x8
class :: {
}

// class id: 6174, size: 0x30, field offset: 0xc
//   const constructor, 
class CircleAvatar extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfb40c0, size: 0x468
    // 0xfb40c0: EnterFrame
    //     0xfb40c0: stp             fp, lr, [SP, #-0x10]!
    //     0xfb40c4: mov             fp, SP
    // 0xfb40c8: AllocStack(0x60)
    //     0xfb40c8: sub             SP, SP, #0x60
    // 0xfb40cc: SetupParameters(CircleAvatar this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xfb40cc: mov             x0, x1
    //     0xfb40d0: stur            x1, [fp, #-8]
    //     0xfb40d4: mov             x1, x2
    // 0xfb40d8: CheckStackOverflow
    //     0xfb40d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb40dc: cmp             SP, x16
    //     0xfb40e0: b.ls            #0xfb4518
    // 0xfb40e4: r0 = of()
    //     0xfb40e4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb40e8: stur            x0, [fp, #-0x20]
    // 0xfb40ec: LoadField: r2 = r0->field_2f
    //     0xfb40ec: ldur            w2, [x0, #0x2f]
    // 0xfb40f0: DecompressPointer r2
    //     0xfb40f0: add             x2, x2, HEAP, lsl #32
    // 0xfb40f4: stur            x2, [fp, #-0x18]
    // 0xfb40f8: tbnz            w2, #4, #0xfb4130
    // 0xfb40fc: LoadField: r1 = r0->field_3f
    //     0xfb40fc: ldur            w1, [x0, #0x3f]
    // 0xfb4100: DecompressPointer r1
    //     0xfb4100: add             x1, x1, HEAP, lsl #32
    // 0xfb4104: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xfb4104: ldur            w3, [x1, #0x17]
    // 0xfb4108: DecompressPointer r3
    //     0xfb4108: add             x3, x3, HEAP, lsl #32
    // 0xfb410c: cmp             w3, NULL
    // 0xfb4110: b.ne            #0xfb4124
    // 0xfb4114: LoadField: r3 = r1->field_f
    //     0xfb4114: ldur            w3, [x1, #0xf]
    // 0xfb4118: DecompressPointer r3
    //     0xfb4118: add             x3, x3, HEAP, lsl #32
    // 0xfb411c: mov             x1, x3
    // 0xfb4120: b               #0xfb4128
    // 0xfb4124: mov             x1, x3
    // 0xfb4128: mov             x3, x1
    // 0xfb412c: b               #0xfb4134
    // 0xfb4130: r3 = Null
    //     0xfb4130: mov             x3, NULL
    // 0xfb4134: stur            x3, [fp, #-0x10]
    // 0xfb4138: tbnz            w2, #4, #0xfb4154
    // 0xfb413c: LoadField: r1 = r0->field_87
    //     0xfb413c: ldur            w1, [x0, #0x87]
    // 0xfb4140: DecompressPointer r1
    //     0xfb4140: add             x1, x1, HEAP, lsl #32
    // 0xfb4144: LoadField: r4 = r1->field_23
    //     0xfb4144: ldur            w4, [x1, #0x23]
    // 0xfb4148: DecompressPointer r4
    //     0xfb4148: add             x4, x4, HEAP, lsl #32
    // 0xfb414c: mov             x1, x4
    // 0xfb4150: b               #0xfb4168
    // 0xfb4154: LoadField: r1 = r0->field_83
    //     0xfb4154: ldur            w1, [x0, #0x83]
    // 0xfb4158: DecompressPointer r1
    //     0xfb4158: add             x1, x1, HEAP, lsl #32
    // 0xfb415c: LoadField: r4 = r1->field_23
    //     0xfb415c: ldur            w4, [x1, #0x23]
    // 0xfb4160: DecompressPointer r4
    //     0xfb4160: add             x4, x4, HEAP, lsl #32
    // 0xfb4164: mov             x1, x4
    // 0xfb4168: ldur            x4, [fp, #-8]
    // 0xfb416c: str             x3, [SP]
    // 0xfb4170: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xfb4170: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xfb4174: ldr             x4, [x4, #0x7f0]
    // 0xfb4178: r0 = copyWith()
    //     0xfb4178: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xfb417c: mov             x2, x0
    // 0xfb4180: ldur            x0, [fp, #-8]
    // 0xfb4184: stur            x2, [fp, #-0x28]
    // 0xfb4188: LoadField: r1 = r0->field_f
    //     0xfb4188: ldur            w1, [x0, #0xf]
    // 0xfb418c: DecompressPointer r1
    //     0xfb418c: add             x1, x1, HEAP, lsl #32
    // 0xfb4190: cmp             w1, NULL
    // 0xfb4194: b.ne            #0xfb41e0
    // 0xfb4198: ldur            x3, [fp, #-0x18]
    // 0xfb419c: tbnz            w3, #4, #0xfb41d4
    // 0xfb41a0: ldur            x3, [fp, #-0x20]
    // 0xfb41a4: LoadField: r4 = r3->field_3f
    //     0xfb41a4: ldur            w4, [x3, #0x3f]
    // 0xfb41a8: DecompressPointer r4
    //     0xfb41a8: add             x4, x4, HEAP, lsl #32
    // 0xfb41ac: LoadField: r5 = r4->field_13
    //     0xfb41ac: ldur            w5, [x4, #0x13]
    // 0xfb41b0: DecompressPointer r5
    //     0xfb41b0: add             x5, x5, HEAP, lsl #32
    // 0xfb41b4: cmp             w5, NULL
    // 0xfb41b8: b.ne            #0xfb41cc
    // 0xfb41bc: LoadField: r5 = r4->field_b
    //     0xfb41bc: ldur            w5, [x4, #0xb]
    // 0xfb41c0: DecompressPointer r5
    //     0xfb41c0: add             x5, x5, HEAP, lsl #32
    // 0xfb41c4: mov             x4, x5
    // 0xfb41c8: b               #0xfb41e8
    // 0xfb41cc: mov             x4, x5
    // 0xfb41d0: b               #0xfb41e8
    // 0xfb41d4: ldur            x3, [fp, #-0x20]
    // 0xfb41d8: r4 = Null
    //     0xfb41d8: mov             x4, NULL
    // 0xfb41dc: b               #0xfb41e8
    // 0xfb41e0: ldur            x3, [fp, #-0x20]
    // 0xfb41e4: mov             x4, x1
    // 0xfb41e8: stur            x4, [fp, #-0x18]
    // 0xfb41ec: cmp             w4, NULL
    // 0xfb41f0: b.ne            #0xfb4238
    // 0xfb41f4: LoadField: r1 = r2->field_b
    //     0xfb41f4: ldur            w1, [x2, #0xb]
    // 0xfb41f8: DecompressPointer r1
    //     0xfb41f8: add             x1, x1, HEAP, lsl #32
    // 0xfb41fc: cmp             w1, NULL
    // 0xfb4200: b.eq            #0xfb4520
    // 0xfb4204: r0 = estimateBrightnessForColor()
    //     0xfb4204: bl              #0x8ad774  ; [package:flutter/src/material/theme_data.dart] ThemeData::estimateBrightnessForColor
    // 0xfb4208: LoadField: r1 = r0->field_7
    //     0xfb4208: ldur            x1, [x0, #7]
    // 0xfb420c: cmp             x1, #0
    // 0xfb4210: b.gt            #0xfb4224
    // 0xfb4214: ldur            x0, [fp, #-0x20]
    // 0xfb4218: LoadField: r1 = r0->field_63
    //     0xfb4218: ldur            w1, [x0, #0x63]
    // 0xfb421c: DecompressPointer r1
    //     0xfb421c: add             x1, x1, HEAP, lsl #32
    // 0xfb4220: b               #0xfb4230
    // 0xfb4224: ldur            x0, [fp, #-0x20]
    // 0xfb4228: LoadField: r1 = r0->field_5f
    //     0xfb4228: ldur            w1, [x0, #0x5f]
    // 0xfb422c: DecompressPointer r1
    //     0xfb422c: add             x1, x1, HEAP, lsl #32
    // 0xfb4230: ldur            x2, [fp, #-0x28]
    // 0xfb4234: b               #0xfb42b4
    // 0xfb4238: mov             x0, x3
    // 0xfb423c: ldur            x2, [fp, #-0x10]
    // 0xfb4240: cmp             w2, NULL
    // 0xfb4244: b.ne            #0xfb42a8
    // 0xfb4248: cmp             w1, NULL
    // 0xfb424c: b.eq            #0xfb4524
    // 0xfb4250: r0 = estimateBrightnessForColor()
    //     0xfb4250: bl              #0x8ad774  ; [package:flutter/src/material/theme_data.dart] ThemeData::estimateBrightnessForColor
    // 0xfb4254: LoadField: r1 = r0->field_7
    //     0xfb4254: ldur            x1, [x0, #7]
    // 0xfb4258: cmp             x1, #0
    // 0xfb425c: b.gt            #0xfb4284
    // 0xfb4260: ldur            x0, [fp, #-0x20]
    // 0xfb4264: LoadField: r1 = r0->field_63
    //     0xfb4264: ldur            w1, [x0, #0x63]
    // 0xfb4268: DecompressPointer r1
    //     0xfb4268: add             x1, x1, HEAP, lsl #32
    // 0xfb426c: str             x1, [SP]
    // 0xfb4270: ldur            x1, [fp, #-0x28]
    // 0xfb4274: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xfb4274: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xfb4278: ldr             x4, [x4, #0x7f0]
    // 0xfb427c: r0 = copyWith()
    //     0xfb427c: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xfb4280: b               #0xfb42ac
    // 0xfb4284: ldur            x0, [fp, #-0x20]
    // 0xfb4288: LoadField: r1 = r0->field_5f
    //     0xfb4288: ldur            w1, [x0, #0x5f]
    // 0xfb428c: DecompressPointer r1
    //     0xfb428c: add             x1, x1, HEAP, lsl #32
    // 0xfb4290: str             x1, [SP]
    // 0xfb4294: ldur            x1, [fp, #-0x28]
    // 0xfb4298: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xfb4298: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xfb429c: ldr             x4, [x4, #0x7f0]
    // 0xfb42a0: r0 = copyWith()
    //     0xfb42a0: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xfb42a4: b               #0xfb42ac
    // 0xfb42a8: ldur            x0, [fp, #-0x28]
    // 0xfb42ac: mov             x2, x0
    // 0xfb42b0: ldur            x1, [fp, #-0x18]
    // 0xfb42b4: ldur            x0, [fp, #-8]
    // 0xfb42b8: stur            x2, [fp, #-0x10]
    // 0xfb42bc: stur            x1, [fp, #-0x18]
    // 0xfb42c0: LoadField: r3 = r0->field_23
    //     0xfb42c0: ldur            w3, [x0, #0x23]
    // 0xfb42c4: DecompressPointer r3
    //     0xfb42c4: add             x3, x3, HEAP, lsl #32
    // 0xfb42c8: cmp             w3, NULL
    // 0xfb42cc: b.ne            #0xfb42e0
    // 0xfb42d0: d1 = 40.000000
    //     0xfb42d0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13168] IMM: double(40) from 0x4044000000000000
    //     0xfb42d4: ldr             d1, [x17, #0x168]
    // 0xfb42d8: d0 = 2.000000
    //     0xfb42d8: fmov            d0, #2.00000000
    // 0xfb42dc: b               #0xfb42f0
    // 0xfb42e0: d0 = 2.000000
    //     0xfb42e0: fmov            d0, #2.00000000
    // 0xfb42e4: LoadField: d1 = r3->field_7
    //     0xfb42e4: ldur            d1, [x3, #7]
    // 0xfb42e8: fmul            d2, d1, d0
    // 0xfb42ec: mov             v1.16b, v2.16b
    // 0xfb42f0: stur            d1, [fp, #-0x48]
    // 0xfb42f4: cmp             w3, NULL
    // 0xfb42f8: b.ne            #0xfb4308
    // 0xfb42fc: d0 = 40.000000
    //     0xfb42fc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13168] IMM: double(40) from 0x4044000000000000
    //     0xfb4300: ldr             d0, [x17, #0x168]
    // 0xfb4304: b               #0xfb4314
    // 0xfb4308: LoadField: d2 = r3->field_7
    //     0xfb4308: ldur            d2, [x3, #7]
    // 0xfb430c: fmul            d3, d2, d0
    // 0xfb4310: mov             v0.16b, v3.16b
    // 0xfb4314: stur            d0, [fp, #-0x40]
    // 0xfb4318: r0 = BoxConstraints()
    //     0xfb4318: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xfb431c: ldur            d0, [fp, #-0x48]
    // 0xfb4320: stur            x0, [fp, #-0x30]
    // 0xfb4324: StoreField: r0->field_7 = d0
    //     0xfb4324: stur            d0, [x0, #7]
    // 0xfb4328: ldur            d1, [fp, #-0x40]
    // 0xfb432c: StoreField: r0->field_f = d1
    //     0xfb432c: stur            d1, [x0, #0xf]
    // 0xfb4330: ArrayStore: r0[0] = d0  ; List_8
    //     0xfb4330: stur            d0, [x0, #0x17]
    // 0xfb4334: StoreField: r0->field_1f = d1
    //     0xfb4334: stur            d1, [x0, #0x1f]
    // 0xfb4338: ldur            x1, [fp, #-8]
    // 0xfb433c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xfb433c: ldur            w2, [x1, #0x17]
    // 0xfb4340: DecompressPointer r2
    //     0xfb4340: add             x2, x2, HEAP, lsl #32
    // 0xfb4344: stur            x2, [fp, #-0x28]
    // 0xfb4348: cmp             w2, NULL
    // 0xfb434c: b.eq            #0xfb43b4
    // 0xfb4350: r0 = DecorationImage()
    //     0xfb4350: bl              #0xe3940c  ; AllocateDecorationImageStub -> DecorationImage (size=0x44)
    // 0xfb4354: mov             x1, x0
    // 0xfb4358: ldur            x0, [fp, #-0x28]
    // 0xfb435c: StoreField: r1->field_7 = r0
    //     0xfb435c: stur            w0, [x1, #7]
    // 0xfb4360: r0 = Instance_BoxFit
    //     0xfb4360: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e928] Obj!BoxFit@12c4901
    //     0xfb4364: ldr             x0, [x0, #0x928]
    // 0xfb4368: StoreField: r1->field_13 = r0
    //     0xfb4368: stur            w0, [x1, #0x13]
    // 0xfb436c: r0 = Instance_Alignment
    //     0xfb436c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfb4370: ldr             x0, [x0, #0xb80]
    // 0xfb4374: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb4374: stur            w0, [x1, #0x17]
    // 0xfb4378: r2 = Instance_ImageRepeat
    //     0xfb4378: add             x2, PP, #0x16, lsl #12  ; [pp+0x16fb8] Obj!ImageRepeat@12c4821
    //     0xfb437c: ldr             x2, [x2, #0xfb8]
    // 0xfb4380: StoreField: r1->field_1f = r2
    //     0xfb4380: stur            w2, [x1, #0x1f]
    // 0xfb4384: r2 = false
    //     0xfb4384: add             x2, NULL, #0x30  ; false
    // 0xfb4388: StoreField: r1->field_23 = r2
    //     0xfb4388: stur            w2, [x1, #0x23]
    // 0xfb438c: d0 = 1.000000
    //     0xfb438c: fmov            d0, #1.00000000
    // 0xfb4390: StoreField: r1->field_27 = d0
    //     0xfb4390: stur            d0, [x1, #0x27]
    // 0xfb4394: StoreField: r1->field_2f = d0
    //     0xfb4394: stur            d0, [x1, #0x2f]
    // 0xfb4398: r3 = Instance_FilterQuality
    //     0xfb4398: add             x3, PP, #0x16, lsl #12  ; [pp+0x16fc0] Obj!FilterQuality@12c8241
    //     0xfb439c: ldr             x3, [x3, #0xfc0]
    // 0xfb43a0: StoreField: r1->field_37 = r3
    //     0xfb43a0: stur            w3, [x1, #0x37]
    // 0xfb43a4: StoreField: r1->field_3b = r2
    //     0xfb43a4: stur            w2, [x1, #0x3b]
    // 0xfb43a8: StoreField: r1->field_3f = r2
    //     0xfb43a8: stur            w2, [x1, #0x3f]
    // 0xfb43ac: mov             x3, x1
    // 0xfb43b0: b               #0xfb43c0
    // 0xfb43b4: r0 = Instance_Alignment
    //     0xfb43b4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfb43b8: ldr             x0, [x0, #0xb80]
    // 0xfb43bc: r3 = Null
    //     0xfb43bc: mov             x3, NULL
    // 0xfb43c0: ldur            x1, [fp, #-8]
    // 0xfb43c4: ldur            x2, [fp, #-0x18]
    // 0xfb43c8: stur            x3, [fp, #-0x28]
    // 0xfb43cc: r0 = BoxDecoration()
    //     0xfb43cc: bl              #0x8a721c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xfb43d0: mov             x2, x0
    // 0xfb43d4: ldur            x0, [fp, #-0x18]
    // 0xfb43d8: stur            x2, [fp, #-0x38]
    // 0xfb43dc: StoreField: r2->field_7 = r0
    //     0xfb43dc: stur            w0, [x2, #7]
    // 0xfb43e0: ldur            x0, [fp, #-0x28]
    // 0xfb43e4: StoreField: r2->field_b = r0
    //     0xfb43e4: stur            w0, [x2, #0xb]
    // 0xfb43e8: r0 = Instance_BoxShape
    //     0xfb43e8: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1abf0] Obj!BoxShape@12c4941
    //     0xfb43ec: ldr             x0, [x0, #0xbf0]
    // 0xfb43f0: StoreField: r2->field_23 = r0
    //     0xfb43f0: stur            w0, [x2, #0x23]
    // 0xfb43f4: ldur            x0, [fp, #-8]
    // 0xfb43f8: LoadField: r3 = r0->field_b
    //     0xfb43f8: ldur            w3, [x0, #0xb]
    // 0xfb43fc: DecompressPointer r3
    //     0xfb43fc: add             x3, x3, HEAP, lsl #32
    // 0xfb4400: stur            x3, [fp, #-0x18]
    // 0xfb4404: cmp             w3, NULL
    // 0xfb4408: b.ne            #0xfb4414
    // 0xfb440c: r0 = Null
    //     0xfb440c: mov             x0, NULL
    // 0xfb4410: b               #0xfb44d0
    // 0xfb4414: ldur            x0, [fp, #-0x20]
    // 0xfb4418: ldur            x4, [fp, #-0x10]
    // 0xfb441c: LoadField: r1 = r0->field_7b
    //     0xfb441c: ldur            w1, [x0, #0x7b]
    // 0xfb4420: DecompressPointer r1
    //     0xfb4420: add             x1, x1, HEAP, lsl #32
    // 0xfb4424: LoadField: r0 = r4->field_b
    //     0xfb4424: ldur            w0, [x4, #0xb]
    // 0xfb4428: DecompressPointer r0
    //     0xfb4428: add             x0, x0, HEAP, lsl #32
    // 0xfb442c: r5 = LoadClassIdInstr(r1)
    //     0xfb442c: ldur            x5, [x1, #-1]
    //     0xfb4430: ubfx            x5, x5, #0xc, #0x14
    // 0xfb4434: str             x0, [SP]
    // 0xfb4438: mov             x0, x5
    // 0xfb443c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xfb443c: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xfb4440: ldr             x4, [x4, #0x7f0]
    // 0xfb4444: r0 = GDT[cid_x0 + -0xff8]()
    //     0xfb4444: sub             lr, x0, #0xff8
    //     0xfb4448: ldr             lr, [x21, lr, lsl #3]
    //     0xfb444c: blr             lr
    // 0xfb4450: stur            x0, [fp, #-8]
    // 0xfb4454: r0 = DefaultTextStyle()
    //     0xfb4454: bl              #0xd0b11c  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xfb4458: mov             x1, x0
    // 0xfb445c: ldur            x0, [fp, #-0x10]
    // 0xfb4460: stur            x1, [fp, #-0x20]
    // 0xfb4464: StoreField: r1->field_f = r0
    //     0xfb4464: stur            w0, [x1, #0xf]
    // 0xfb4468: r0 = true
    //     0xfb4468: add             x0, NULL, #0x20  ; true
    // 0xfb446c: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb446c: stur            w0, [x1, #0x17]
    // 0xfb4470: r0 = Instance_TextOverflow
    //     0xfb4470: add             x0, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xfb4474: ldr             x0, [x0, #0x108]
    // 0xfb4478: StoreField: r1->field_1b = r0
    //     0xfb4478: stur            w0, [x1, #0x1b]
    // 0xfb447c: r0 = Instance_TextWidthBasis
    //     0xfb447c: add             x0, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xfb4480: ldr             x0, [x0, #0x110]
    // 0xfb4484: StoreField: r1->field_23 = r0
    //     0xfb4484: stur            w0, [x1, #0x23]
    // 0xfb4488: ldur            x0, [fp, #-0x18]
    // 0xfb448c: StoreField: r1->field_b = r0
    //     0xfb448c: stur            w0, [x1, #0xb]
    // 0xfb4490: r0 = IconTheme()
    //     0xfb4490: bl              #0xd0c668  ; AllocateIconThemeStub -> IconTheme (size=0x14)
    // 0xfb4494: mov             x1, x0
    // 0xfb4498: ldur            x0, [fp, #-8]
    // 0xfb449c: StoreField: r1->field_f = r0
    //     0xfb449c: stur            w0, [x1, #0xf]
    // 0xfb44a0: ldur            x0, [fp, #-0x20]
    // 0xfb44a4: StoreField: r1->field_b = r0
    //     0xfb44a4: stur            w0, [x1, #0xb]
    // 0xfb44a8: r0 = withNoTextScaling()
    //     0xfb44a8: bl              #0xfb4528  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::withNoTextScaling
    // 0xfb44ac: stur            x0, [fp, #-8]
    // 0xfb44b0: r0 = Center()
    //     0xfb44b0: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xfb44b4: mov             x1, x0
    // 0xfb44b8: r0 = Instance_Alignment
    //     0xfb44b8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfb44bc: ldr             x0, [x0, #0xb80]
    // 0xfb44c0: StoreField: r1->field_f = r0
    //     0xfb44c0: stur            w0, [x1, #0xf]
    // 0xfb44c4: ldur            x0, [fp, #-8]
    // 0xfb44c8: StoreField: r1->field_b = r0
    //     0xfb44c8: stur            w0, [x1, #0xb]
    // 0xfb44cc: mov             x0, x1
    // 0xfb44d0: stur            x0, [fp, #-8]
    // 0xfb44d4: r0 = AnimatedContainer()
    //     0xfb44d4: bl              #0xd15d44  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0xfb44d8: stur            x0, [fp, #-0x10]
    // 0xfb44dc: ldur            x16, [fp, #-0x30]
    // 0xfb44e0: ldur            lr, [fp, #-0x38]
    // 0xfb44e4: stp             lr, x16, [SP, #8]
    // 0xfb44e8: ldur            x16, [fp, #-8]
    // 0xfb44ec: str             x16, [SP]
    // 0xfb44f0: mov             x1, x0
    // 0xfb44f4: r2 = Instance_Duration
    //     0xfb44f4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xfb44f8: ldr             x2, [x2, #0x318]
    // 0xfb44fc: r4 = const [0, 0x5, 0x3, 0x2, child, 0x4, constraints, 0x2, decoration, 0x3, null]
    //     0xfb44fc: add             x4, PP, #0x80, lsl #12  ; [pp+0x80998] List(11) [0, 0x5, 0x3, 0x2, "child", 0x4, "constraints", 0x2, "decoration", 0x3, Null]
    //     0xfb4500: ldr             x4, [x4, #0x998]
    // 0xfb4504: r0 = AnimatedContainer()
    //     0xfb4504: bl              #0xd15840  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0xfb4508: ldur            x0, [fp, #-0x10]
    // 0xfb450c: LeaveFrame
    //     0xfb450c: mov             SP, fp
    //     0xfb4510: ldp             fp, lr, [SP], #0x10
    // 0xfb4514: ret
    //     0xfb4514: ret             
    // 0xfb4518: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb4518: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb451c: b               #0xfb40e4
    // 0xfb4520: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfb4520: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfb4524: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfb4524: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}
