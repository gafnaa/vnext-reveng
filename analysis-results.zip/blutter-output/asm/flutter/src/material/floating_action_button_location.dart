// lib: , url: package:flutter/src/material/floating_action_button_location.dart

// class id: 1048896, size: 0x8
class :: {
}

// class id: 3043, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class FloatingActionButtonAnimator extends Object {
}

// class id: 3045, size: 0x8, field offset: 0x8
//   const constructor, 
class _ScalingFabMotionAnimator extends FloatingActionButtonAnimator {

  static late final Animatable<double> _rotationTween; // offset: 0x6b0
  static late final Animatable<double> _thresholdCenterTween; // offset: 0x6b4

  _ getRotationAnimation(/* No info */) {
    // ** addr: 0xf3cd34, size: 0x140
    // 0xf3cd34: EnterFrame
    //     0xf3cd34: stp             fp, lr, [SP, #-0x10]!
    //     0xf3cd38: mov             fp, SP
    // 0xf3cd3c: AllocStack(0x20)
    //     0xf3cd3c: sub             SP, SP, #0x20
    // 0xf3cd40: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0xf3cd40: stur            x2, [fp, #-8]
    // 0xf3cd44: CheckStackOverflow
    //     0xf3cd44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3cd48: cmp             SP, x16
    //     0xf3cd4c: b.ls            #0xf3ce6c
    // 0xf3cd50: r0 = LoadStaticField(0x6b0)
    //     0xf3cd50: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf3cd54: ldr             x0, [x0, #0xd60]
    // 0xf3cd58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3cd5c: cmp             w0, w16
    // 0xf3cd60: b.ne            #0xf3cd70
    // 0xf3cd64: r2 = _rotationTween
    //     0xf3cd64: add             x2, PP, #0x99, lsl #12  ; [pp+0x99878] Field <_ScalingFabMotionAnimator@88063916._rotationTween@88063916>: static late final (offset: 0x6b0)
    //     0xf3cd68: ldr             x2, [x2, #0x878]
    // 0xf3cd6c: r0 = InitLateFinalStaticField()
    //     0xf3cd6c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf3cd70: mov             x1, x0
    // 0xf3cd74: ldur            x2, [fp, #-8]
    // 0xf3cd78: r0 = animate()
    //     0xf3cd78: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf3cd7c: stur            x0, [fp, #-0x10]
    // 0xf3cd80: r0 = LoadStaticField(0x6b4)
    //     0xf3cd80: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf3cd84: ldr             x0, [x0, #0xd68]
    // 0xf3cd88: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3cd8c: cmp             w0, w16
    // 0xf3cd90: b.ne            #0xf3cda0
    // 0xf3cd94: r2 = _thresholdCenterTween
    //     0xf3cd94: add             x2, PP, #0x99, lsl #12  ; [pp+0x99880] Field <_ScalingFabMotionAnimator@88063916._thresholdCenterTween@88063916>: static late final (offset: 0x6b4)
    //     0xf3cd98: ldr             x2, [x2, #0x880]
    // 0xf3cd9c: r0 = InitLateFinalStaticField()
    //     0xf3cd9c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf3cda0: mov             x1, x0
    // 0xf3cda4: ldur            x2, [fp, #-8]
    // 0xf3cda8: r0 = animate()
    //     0xf3cda8: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf3cdac: r1 = <double>
    //     0xf3cdac: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3cdb0: stur            x0, [fp, #-0x18]
    // 0xf3cdb4: r0 = ReverseAnimation()
    //     0xf3cdb4: bl              #0xdffa24  ; AllocateReverseAnimationStub -> ReverseAnimation (size=0x1c)
    // 0xf3cdb8: mov             x2, x0
    // 0xf3cdbc: ldur            x0, [fp, #-0x18]
    // 0xf3cdc0: stur            x2, [fp, #-0x20]
    // 0xf3cdc4: ArrayStore: r2[0] = r0  ; List_4
    //     0xf3cdc4: stur            w0, [x2, #0x17]
    // 0xf3cdc8: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xf3cdc8: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xf3cdcc: r0 = ObserverList()
    //     0xf3cdcc: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xf3cdd0: mov             x3, x0
    // 0xf3cdd4: r0 = false
    //     0xf3cdd4: add             x0, NULL, #0x30  ; false
    // 0xf3cdd8: stur            x3, [fp, #-0x18]
    // 0xf3cddc: StoreField: r3->field_f = r0
    //     0xf3cddc: stur            w0, [x3, #0xf]
    // 0xf3cde0: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3cde4: StoreField: r3->field_13 = r0
    //     0xf3cde4: stur            w0, [x3, #0x13]
    // 0xf3cde8: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xf3cde8: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xf3cdec: r2 = 0
    //     0xf3cdec: mov             x2, #0
    // 0xf3cdf0: r0 = _GrowableList()
    //     0xf3cdf0: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xf3cdf4: ldur            x1, [fp, #-0x18]
    // 0xf3cdf8: StoreField: r1->field_b = r0
    //     0xf3cdf8: stur            w0, [x1, #0xb]
    //     0xf3cdfc: ldurb           w16, [x1, #-1]
    //     0xf3ce00: ldurb           w17, [x0, #-1]
    //     0xf3ce04: and             x16, x17, x16, lsr #2
    //     0xf3ce08: tst             x16, HEAP, lsr #32
    //     0xf3ce0c: b.eq            #0xf3ce14
    //     0xf3ce10: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf3ce14: mov             x0, x1
    // 0xf3ce18: ldur            x3, [fp, #-0x20]
    // 0xf3ce1c: StoreField: r3->field_13 = r0
    //     0xf3ce1c: stur            w0, [x3, #0x13]
    //     0xf3ce20: ldurb           w16, [x3, #-1]
    //     0xf3ce24: ldurb           w17, [x0, #-1]
    //     0xf3ce28: and             x16, x17, x16, lsr #2
    //     0xf3ce2c: tst             x16, HEAP, lsr #32
    //     0xf3ce30: b.eq            #0xf3ce38
    //     0xf3ce34: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf3ce38: StoreField: r3->field_b = rZR
    //     0xf3ce38: stur            xzr, [x3, #0xb]
    // 0xf3ce3c: r1 = <double>
    //     0xf3ce3c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3ce40: r0 = _AnimationSwap()
    //     0xf3ce40: bl              #0xf3cf90  ; Allocate_AnimationSwapStub -> _AnimationSwap<X0> (size=0x38)
    // 0xf3ce44: mov             x1, x0
    // 0xf3ce48: ldur            x2, [fp, #-0x10]
    // 0xf3ce4c: ldur            x3, [fp, #-0x20]
    // 0xf3ce50: ldur            x5, [fp, #-8]
    // 0xf3ce54: stur            x0, [fp, #-8]
    // 0xf3ce58: r0 = _AnimationSwap()
    //     0xf3ce58: bl              #0xf3ce74  ; [package:flutter/src/material/floating_action_button_location.dart] _AnimationSwap::_AnimationSwap
    // 0xf3ce5c: ldur            x0, [fp, #-8]
    // 0xf3ce60: LeaveFrame
    //     0xf3ce60: mov             SP, fp
    //     0xf3ce64: ldp             fp, lr, [SP], #0x10
    // 0xf3ce68: ret
    //     0xf3ce68: ret             
    // 0xf3ce6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3ce6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3ce70: b               #0xf3cd50
  }
  static Animatable<double> _thresholdCenterTween() {
    // ** addr: 0xf3cf9c, size: 0x28
    // 0xf3cf9c: EnterFrame
    //     0xf3cf9c: stp             fp, lr, [SP, #-0x10]!
    //     0xf3cfa0: mov             fp, SP
    // 0xf3cfa4: r1 = <double>
    //     0xf3cfa4: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3cfa8: r0 = CurveTween()
    //     0xf3cfa8: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xf3cfac: r1 = Instance_Threshold
    //     0xf3cfac: add             x1, PP, #0x99, lsl #12  ; [pp+0x99888] Obj!Threshold@129f8d1
    //     0xf3cfb0: ldr             x1, [x1, #0x888]
    // 0xf3cfb4: StoreField: r0->field_b = r1
    //     0xf3cfb4: stur            w1, [x0, #0xb]
    // 0xf3cfb8: LeaveFrame
    //     0xf3cfb8: mov             SP, fp
    //     0xf3cfbc: ldp             fp, lr, [SP], #0x10
    // 0xf3cfc0: ret
    //     0xf3cfc0: ret             
  }
  static Animatable<double> _rotationTween() {
    // ** addr: 0xf3cfc4, size: 0x30
    // 0xf3cfc4: EnterFrame
    //     0xf3cfc4: stp             fp, lr, [SP, #-0x10]!
    //     0xf3cfc8: mov             fp, SP
    // 0xf3cfcc: r1 = <double>
    //     0xf3cfcc: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3cfd0: r0 = Tween()
    //     0xf3cfd0: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xf3cfd4: r1 = 0.750000
    //     0xf3cfd4: add             x1, PP, #0x8e, lsl #12  ; [pp+0x8e168] 0.75
    //     0xf3cfd8: ldr             x1, [x1, #0x168]
    // 0xf3cfdc: StoreField: r0->field_b = r1
    //     0xf3cfdc: stur            w1, [x0, #0xb]
    // 0xf3cfe0: r1 = 1.000000
    //     0xf3cfe0: ldr             x1, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xf3cfe4: StoreField: r0->field_f = r1
    //     0xf3cfe4: stur            w1, [x0, #0xf]
    // 0xf3cfe8: LeaveFrame
    //     0xf3cfe8: mov             SP, fp
    //     0xf3cfec: ldp             fp, lr, [SP], #0x10
    // 0xf3cff0: ret
    //     0xf3cff0: ret             
  }
  _ getScaleAnimation(/* No info */) {
    // ** addr: 0xf3cff4, size: 0x140
    // 0xf3cff4: EnterFrame
    //     0xf3cff4: stp             fp, lr, [SP, #-0x10]!
    //     0xf3cff8: mov             fp, SP
    // 0xf3cffc: AllocStack(0x18)
    //     0xf3cffc: sub             SP, SP, #0x18
    // 0xf3d000: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0xf3d000: stur            x2, [fp, #-8]
    // 0xf3d004: CheckStackOverflow
    //     0xf3d004: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3d008: cmp             SP, x16
    //     0xf3d00c: b.ls            #0xf3d12c
    // 0xf3d010: r1 = <double>
    //     0xf3d010: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3d014: r0 = FlippedCurve()
    //     0xf3d014: bl              #0xb6f814  ; AllocateFlippedCurveStub -> FlippedCurve (size=0x10)
    // 0xf3d018: mov             x2, x0
    // 0xf3d01c: r0 = Instance_Interval
    //     0xf3d01c: add             x0, PP, #0x99, lsl #12  ; [pp+0x99890] Obj!Interval@129fb11
    //     0xf3d020: ldr             x0, [x0, #0x890]
    // 0xf3d024: stur            x2, [fp, #-0x10]
    // 0xf3d028: StoreField: r2->field_b = r0
    //     0xf3d028: stur            w0, [x2, #0xb]
    // 0xf3d02c: r1 = <double>
    //     0xf3d02c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3d030: r0 = CurveTween()
    //     0xf3d030: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xf3d034: mov             x1, x0
    // 0xf3d038: ldur            x0, [fp, #-0x10]
    // 0xf3d03c: StoreField: r1->field_b = r0
    //     0xf3d03c: stur            w0, [x1, #0xb]
    // 0xf3d040: ldur            x2, [fp, #-8]
    // 0xf3d044: r0 = animate()
    //     0xf3d044: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf3d048: r1 = <double>
    //     0xf3d048: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3d04c: stur            x0, [fp, #-0x10]
    // 0xf3d050: r0 = ReverseAnimation()
    //     0xf3d050: bl              #0xdffa24  ; AllocateReverseAnimationStub -> ReverseAnimation (size=0x1c)
    // 0xf3d054: mov             x2, x0
    // 0xf3d058: ldur            x0, [fp, #-0x10]
    // 0xf3d05c: stur            x2, [fp, #-0x18]
    // 0xf3d060: ArrayStore: r2[0] = r0  ; List_4
    //     0xf3d060: stur            w0, [x2, #0x17]
    // 0xf3d064: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xf3d064: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xf3d068: r0 = ObserverList()
    //     0xf3d068: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xf3d06c: mov             x3, x0
    // 0xf3d070: r0 = false
    //     0xf3d070: add             x0, NULL, #0x30  ; false
    // 0xf3d074: stur            x3, [fp, #-0x10]
    // 0xf3d078: StoreField: r3->field_f = r0
    //     0xf3d078: stur            w0, [x3, #0xf]
    // 0xf3d07c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3d080: StoreField: r3->field_13 = r0
    //     0xf3d080: stur            w0, [x3, #0x13]
    // 0xf3d084: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xf3d084: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xf3d088: r2 = 0
    //     0xf3d088: mov             x2, #0
    // 0xf3d08c: r0 = _GrowableList()
    //     0xf3d08c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xf3d090: ldur            x1, [fp, #-0x10]
    // 0xf3d094: StoreField: r1->field_b = r0
    //     0xf3d094: stur            w0, [x1, #0xb]
    //     0xf3d098: ldurb           w16, [x1, #-1]
    //     0xf3d09c: ldurb           w17, [x0, #-1]
    //     0xf3d0a0: and             x16, x17, x16, lsr #2
    //     0xf3d0a4: tst             x16, HEAP, lsr #32
    //     0xf3d0a8: b.eq            #0xf3d0b0
    //     0xf3d0ac: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf3d0b0: mov             x0, x1
    // 0xf3d0b4: ldur            x2, [fp, #-0x18]
    // 0xf3d0b8: StoreField: r2->field_13 = r0
    //     0xf3d0b8: stur            w0, [x2, #0x13]
    //     0xf3d0bc: ldurb           w16, [x2, #-1]
    //     0xf3d0c0: ldurb           w17, [x0, #-1]
    //     0xf3d0c4: and             x16, x17, x16, lsr #2
    //     0xf3d0c8: tst             x16, HEAP, lsr #32
    //     0xf3d0cc: b.eq            #0xf3d0d4
    //     0xf3d0d0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3d0d4: StoreField: r2->field_b = rZR
    //     0xf3d0d4: stur            xzr, [x2, #0xb]
    // 0xf3d0d8: r1 = <double>
    //     0xf3d0d8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3d0dc: r0 = CurveTween()
    //     0xf3d0dc: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xf3d0e0: mov             x1, x0
    // 0xf3d0e4: r0 = Instance_Interval
    //     0xf3d0e4: add             x0, PP, #0x99, lsl #12  ; [pp+0x99890] Obj!Interval@129fb11
    //     0xf3d0e8: ldr             x0, [x0, #0x890]
    // 0xf3d0ec: StoreField: r1->field_b = r0
    //     0xf3d0ec: stur            w0, [x1, #0xb]
    // 0xf3d0f0: ldur            x2, [fp, #-8]
    // 0xf3d0f4: r0 = animate()
    //     0xf3d0f4: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf3d0f8: r1 = <double>
    //     0xf3d0f8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3d0fc: stur            x0, [fp, #-0x10]
    // 0xf3d100: r0 = _AnimationSwap()
    //     0xf3d100: bl              #0xf3cf90  ; Allocate_AnimationSwapStub -> _AnimationSwap<X0> (size=0x38)
    // 0xf3d104: mov             x1, x0
    // 0xf3d108: ldur            x2, [fp, #-0x18]
    // 0xf3d10c: ldur            x3, [fp, #-0x10]
    // 0xf3d110: ldur            x5, [fp, #-8]
    // 0xf3d114: stur            x0, [fp, #-8]
    // 0xf3d118: r0 = _AnimationSwap()
    //     0xf3d118: bl              #0xf3ce74  ; [package:flutter/src/material/floating_action_button_location.dart] _AnimationSwap::_AnimationSwap
    // 0xf3d11c: ldur            x0, [fp, #-8]
    // 0xf3d120: LeaveFrame
    //     0xf3d120: mov             SP, fp
    //     0xf3d124: ldp             fp, lr, [SP], #0x10
    // 0xf3d128: ret
    //     0xf3d128: ret             
    // 0xf3d12c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3d12c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3d130: b               #0xf3d010
  }
}

// class id: 3046, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class FloatingActionButtonLocation extends Object {
}

// class id: 3048, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class StandardFabLocation extends FloatingActionButtonLocation {

  _ getOffset(/* No info */) {
    // ** addr: 0x119e4dc, size: 0x7c
    // 0x119e4dc: EnterFrame
    //     0x119e4dc: stp             fp, lr, [SP, #-0x10]!
    //     0x119e4e0: mov             fp, SP
    // 0x119e4e4: AllocStack(0x20)
    //     0x119e4e4: sub             SP, SP, #0x20
    // 0x119e4e8: SetupParameters(StandardFabLocation this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x119e4e8: mov             x3, x1
    //     0x119e4ec: mov             x0, x2
    //     0x119e4f0: stur            x1, [fp, #-8]
    //     0x119e4f4: stur            x2, [fp, #-0x10]
    // 0x119e4f8: CheckStackOverflow
    //     0x119e4f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119e4fc: cmp             SP, x16
    //     0x119e500: b.ls            #0x119e550
    // 0x119e504: mov             x1, x3
    // 0x119e508: mov             x2, x0
    // 0x119e50c: d0 = 0.000000
    //     0x119e50c: eor             v0.16b, v0.16b, v0.16b
    // 0x119e510: r0 = getOffsetX()
    //     0x119e510: bl              #0x119e600  ; [dart:mixin_deduplication] _MixinApplication50&StandardFabLocation&FabEndOffsetX::getOffsetX
    // 0x119e514: ldur            x1, [fp, #-8]
    // 0x119e518: ldur            x2, [fp, #-0x10]
    // 0x119e51c: mov             v1.16b, v0.16b
    // 0x119e520: d0 = 0.000000
    //     0x119e520: eor             v0.16b, v0.16b, v0.16b
    // 0x119e524: stur            d1, [fp, #-0x18]
    // 0x119e528: r0 = getOffsetY()
    //     0x119e528: bl              #0x119e558  ; [dart:mixin_deduplication] _MixinApplication58&StandardFabLocation&FabEndOffsetX&FabFloatOffsetY::getOffsetY
    // 0x119e52c: stur            d0, [fp, #-0x20]
    // 0x119e530: r0 = Offset()
    //     0x119e530: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x119e534: ldur            d0, [fp, #-0x18]
    // 0x119e538: StoreField: r0->field_7 = d0
    //     0x119e538: stur            d0, [x0, #7]
    // 0x119e53c: ldur            d0, [fp, #-0x20]
    // 0x119e540: StoreField: r0->field_f = d0
    //     0x119e540: stur            d0, [x0, #0xf]
    // 0x119e544: LeaveFrame
    //     0x119e544: mov             SP, fp
    //     0x119e548: ldp             fp, lr, [SP], #0x10
    // 0x119e54c: ret
    //     0x119e54c: ret             
    // 0x119e550: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119e550: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119e554: b               #0x119e504
  }
  static _ _rightOffsetX(/* No info */) {
    // ** addr: 0x119e66c, size: 0x40
    // 0x119e66c: d2 = 16.000000
    //     0x119e66c: fmov            d2, #16.00000000
    // 0x119e670: d1 = 0.000000
    //     0x119e670: eor             v1.16b, v1.16b, v1.16b
    // 0x119e674: LoadField: r0 = r1->field_1f
    //     0x119e674: ldur            w0, [x1, #0x1f]
    // 0x119e678: DecompressPointer r0
    //     0x119e678: add             x0, x0, HEAP, lsl #32
    // 0x119e67c: LoadField: d3 = r0->field_7
    //     0x119e67c: ldur            d3, [x0, #7]
    // 0x119e680: fsub            d4, d3, d2
    // 0x119e684: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x119e684: ldur            w0, [x1, #0x17]
    // 0x119e688: DecompressPointer r0
    //     0x119e688: add             x0, x0, HEAP, lsl #32
    // 0x119e68c: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x119e68c: ldur            d2, [x0, #0x17]
    // 0x119e690: fsub            d3, d4, d2
    // 0x119e694: LoadField: r0 = r1->field_7
    //     0x119e694: ldur            w0, [x1, #7]
    // 0x119e698: DecompressPointer r0
    //     0x119e698: add             x0, x0, HEAP, lsl #32
    // 0x119e69c: LoadField: d2 = r0->field_7
    //     0x119e69c: ldur            d2, [x0, #7]
    // 0x119e6a0: fsub            d4, d3, d2
    // 0x119e6a4: fadd            d0, d4, d1
    // 0x119e6a8: ret
    //     0x119e6a8: ret             
  }
}

// class id: 3051, size: 0x8, field offset: 0x8
abstract class FabFloatOffsetY extends StandardFabLocation {
}

// class id: 3058, size: 0x8, field offset: 0x8
//   const constructor, 
class _EndFloatFabLocation extends _MixinApplication58&StandardFabLocation&FabEndOffsetX&FabFloatOffsetY {
}

// class id: 3061, size: 0x8, field offset: 0x8
abstract class FabEndOffsetX extends StandardFabLocation {
}

// class id: 4378, size: 0x38, field offset: 0x2c
class _AnimationSwap<X0> extends CompoundAnimation<X0> {

  X0 value(_AnimationSwap<X0>) {
    // ** addr: 0xae5e7c, size: 0xc0
    // 0xae5e7c: EnterFrame
    //     0xae5e7c: stp             fp, lr, [SP, #-0x10]!
    //     0xae5e80: mov             fp, SP
    // 0xae5e84: d0 = 0.500000
    //     0xae5e84: fmov            d0, #0.50000000
    // 0xae5e88: CheckStackOverflow
    //     0xae5e88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae5e8c: cmp             SP, x16
    //     0xae5e90: b.ls            #0xae5f2c
    // 0xae5e94: LoadField: r0 = r1->field_2b
    //     0xae5e94: ldur            w0, [x1, #0x2b]
    // 0xae5e98: DecompressPointer r0
    //     0xae5e98: add             x0, x0, HEAP, lsl #32
    // 0xae5e9c: LoadField: r2 = r0->field_37
    //     0xae5e9c: ldur            w2, [x0, #0x37]
    // 0xae5ea0: DecompressPointer r2
    //     0xae5ea0: add             x2, x2, HEAP, lsl #32
    // 0xae5ea4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xae5ea8: cmp             w2, w16
    // 0xae5eac: b.eq            #0xae5f34
    // 0xae5eb0: LoadField: d1 = r2->field_7
    //     0xae5eb0: ldur            d1, [x2, #7]
    // 0xae5eb4: fcmp            d0, d1
    // 0xae5eb8: b.le            #0xae5ef0
    // 0xae5ebc: LoadField: r0 = r1->field_1b
    //     0xae5ebc: ldur            w0, [x1, #0x1b]
    // 0xae5ec0: DecompressPointer r0
    //     0xae5ec0: add             x0, x0, HEAP, lsl #32
    // 0xae5ec4: r1 = LoadClassIdInstr(r0)
    //     0xae5ec4: ldur            x1, [x0, #-1]
    //     0xae5ec8: ubfx            x1, x1, #0xc, #0x14
    // 0xae5ecc: mov             x16, x0
    // 0xae5ed0: mov             x0, x1
    // 0xae5ed4: mov             x1, x16
    // 0xae5ed8: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xae5ed8: mov             x17, #0x4e2e
    //     0xae5edc: movk            x17, #1, lsl #16
    //     0xae5ee0: add             lr, x0, x17
    //     0xae5ee4: ldr             lr, [x21, lr, lsl #3]
    //     0xae5ee8: blr             lr
    // 0xae5eec: b               #0xae5f20
    // 0xae5ef0: LoadField: r0 = r1->field_1f
    //     0xae5ef0: ldur            w0, [x1, #0x1f]
    // 0xae5ef4: DecompressPointer r0
    //     0xae5ef4: add             x0, x0, HEAP, lsl #32
    // 0xae5ef8: r1 = LoadClassIdInstr(r0)
    //     0xae5ef8: ldur            x1, [x0, #-1]
    //     0xae5efc: ubfx            x1, x1, #0xc, #0x14
    // 0xae5f00: mov             x16, x0
    // 0xae5f04: mov             x0, x1
    // 0xae5f08: mov             x1, x16
    // 0xae5f0c: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xae5f0c: mov             x17, #0x4e2e
    //     0xae5f10: movk            x17, #1, lsl #16
    //     0xae5f14: add             lr, x0, x17
    //     0xae5f18: ldr             lr, [x21, lr, lsl #3]
    //     0xae5f1c: blr             lr
    // 0xae5f20: LeaveFrame
    //     0xae5f20: mov             SP, fp
    //     0xae5f24: ldp             fp, lr, [SP], #0x10
    // 0xae5f28: ret
    //     0xae5f28: ret             
    // 0xae5f2c: r0 = StackOverflowSharedWithFPURegs()
    //     0xae5f2c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xae5f30: b               #0xae5e94
    // 0xae5f34: r9 = _value
    //     0xae5f34: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xae5f38: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xae5f38: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  X0 dyn:get:value(_AnimationSwap<X0>) {
    // ** addr: 0xae5f54, size: 0x48
    // 0xae5f54: EnterFrame
    //     0xae5f54: stp             fp, lr, [SP, #-0x10]!
    //     0xae5f58: mov             fp, SP
    // 0xae5f5c: CheckStackOverflow
    //     0xae5f5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae5f60: cmp             SP, x16
    //     0xae5f64: b.ls            #0xae5f7c
    // 0xae5f68: ldr             x1, [fp, #0x10]
    // 0xae5f6c: r0 = value()
    //     0xae5f6c: bl              #0xae5e7c  ; [package:flutter/src/material/floating_action_button_location.dart] _AnimationSwap::value
    // 0xae5f70: LeaveFrame
    //     0xae5f70: mov             SP, fp
    //     0xae5f74: ldp             fp, lr, [SP], #0x10
    // 0xae5f78: ret
    //     0xae5f78: ret             
    // 0xae5f7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae5f7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae5f80: b               #0xae5f68
  }
  _ _AnimationSwap(/* No info */) {
    // ** addr: 0xf3ce74, size: 0x11c
    // 0xf3ce74: EnterFrame
    //     0xf3ce74: stp             fp, lr, [SP, #-0x10]!
    //     0xf3ce78: mov             fp, SP
    // 0xf3ce7c: AllocStack(0x10)
    //     0xf3ce7c: sub             SP, SP, #0x10
    // 0xf3ce80: d0 = 0.500000
    //     0xf3ce80: fmov            d0, #0.50000000
    // 0xf3ce84: stur            x1, [fp, #-8]
    // 0xf3ce88: mov             x16, x3
    // 0xf3ce8c: mov             x3, x1
    // 0xf3ce90: mov             x1, x16
    // 0xf3ce94: mov             x0, x5
    // 0xf3ce98: CheckStackOverflow
    //     0xf3ce98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3ce9c: cmp             SP, x16
    //     0xf3cea0: b.ls            #0xf3cf88
    // 0xf3cea4: StoreField: r3->field_2b = r0
    //     0xf3cea4: stur            w0, [x3, #0x2b]
    //     0xf3cea8: ldurb           w16, [x3, #-1]
    //     0xf3ceac: ldurb           w17, [x0, #-1]
    //     0xf3ceb0: and             x16, x17, x16, lsr #2
    //     0xf3ceb4: tst             x16, HEAP, lsr #32
    //     0xf3ceb8: b.eq            #0xf3cec0
    //     0xf3cebc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf3cec0: StoreField: r3->field_2f = d0
    //     0xf3cec0: stur            d0, [x3, #0x2f]
    // 0xf3cec4: mov             x0, x2
    // 0xf3cec8: StoreField: r3->field_1b = r0
    //     0xf3cec8: stur            w0, [x3, #0x1b]
    //     0xf3cecc: ldurb           w16, [x3, #-1]
    //     0xf3ced0: ldurb           w17, [x0, #-1]
    //     0xf3ced4: and             x16, x17, x16, lsr #2
    //     0xf3ced8: tst             x16, HEAP, lsr #32
    //     0xf3cedc: b.eq            #0xf3cee4
    //     0xf3cee0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf3cee4: mov             x0, x1
    // 0xf3cee8: StoreField: r3->field_1f = r0
    //     0xf3cee8: stur            w0, [x3, #0x1f]
    //     0xf3ceec: ldurb           w16, [x3, #-1]
    //     0xf3cef0: ldurb           w17, [x0, #-1]
    //     0xf3cef4: and             x16, x17, x16, lsr #2
    //     0xf3cef8: tst             x16, HEAP, lsr #32
    //     0xf3cefc: b.eq            #0xf3cf04
    //     0xf3cf00: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf3cf04: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xf3cf04: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xf3cf08: r0 = ObserverList()
    //     0xf3cf08: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xf3cf0c: mov             x3, x0
    // 0xf3cf10: r0 = false
    //     0xf3cf10: add             x0, NULL, #0x30  ; false
    // 0xf3cf14: stur            x3, [fp, #-0x10]
    // 0xf3cf18: StoreField: r3->field_f = r0
    //     0xf3cf18: stur            w0, [x3, #0xf]
    // 0xf3cf1c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3cf20: StoreField: r3->field_13 = r0
    //     0xf3cf20: stur            w0, [x3, #0x13]
    // 0xf3cf24: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xf3cf24: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xf3cf28: r2 = 0
    //     0xf3cf28: mov             x2, #0
    // 0xf3cf2c: r0 = _GrowableList()
    //     0xf3cf2c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xf3cf30: ldur            x1, [fp, #-0x10]
    // 0xf3cf34: StoreField: r1->field_b = r0
    //     0xf3cf34: stur            w0, [x1, #0xb]
    //     0xf3cf38: ldurb           w16, [x1, #-1]
    //     0xf3cf3c: ldurb           w17, [x0, #-1]
    //     0xf3cf40: and             x16, x17, x16, lsr #2
    //     0xf3cf44: tst             x16, HEAP, lsr #32
    //     0xf3cf48: b.eq            #0xf3cf50
    //     0xf3cf4c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf3cf50: mov             x0, x1
    // 0xf3cf54: ldur            x1, [fp, #-8]
    // 0xf3cf58: ArrayStore: r1[0] = r0  ; List_4
    //     0xf3cf58: stur            w0, [x1, #0x17]
    //     0xf3cf5c: ldurb           w16, [x1, #-1]
    //     0xf3cf60: ldurb           w17, [x0, #-1]
    //     0xf3cf64: and             x16, x17, x16, lsr #2
    //     0xf3cf68: tst             x16, HEAP, lsr #32
    //     0xf3cf6c: b.eq            #0xf3cf74
    //     0xf3cf70: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf3cf74: r0 = _MixinApplication68&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin()
    //     0xf3cf74: bl              #0x8e0b2c  ; [dart:mixin_deduplication] _MixinApplication68&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin::_MixinApplication68&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin
    // 0xf3cf78: r0 = Null
    //     0xf3cf78: mov             x0, NULL
    // 0xf3cf7c: LeaveFrame
    //     0xf3cf7c: mov             SP, fp
    //     0xf3cf80: ldp             fp, lr, [SP], #0x10
    // 0xf3cf84: ret
    //     0xf3cf84: ret             
    // 0xf3cf88: r0 = StackOverflowSharedWithFPURegs()
    //     0xf3cf88: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xf3cf8c: b               #0xf3cea4
  }
}
