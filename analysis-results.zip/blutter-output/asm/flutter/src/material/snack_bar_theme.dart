// lib: , url: package:flutter/src/material/snack_bar_theme.dart

// class id: 1048950, size: 0x8
class :: {
}

// class id: 5066, size: 0x44, field offset: 0x8
//   const constructor, 
class SnackBarThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x1137014, size: 0x698
    // 0x1137014: EnterFrame
    //     0x1137014: stp             fp, lr, [SP, #-0x10]!
    //     0x1137018: mov             fp, SP
    // 0x113701c: AllocStack(0xc0)
    //     0x113701c: sub             SP, SP, #0xc0
    // 0x1137020: CheckStackOverflow
    //     0x1137020: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1137024: cmp             SP, x16
    //     0x1137028: b.ls            #0x1137664
    // 0x113702c: ldr             x0, [fp, #0x10]
    // 0x1137030: r2 = LoadClassIdInstr(r0)
    //     0x1137030: ldur            x2, [x0, #-1]
    //     0x1137034: ubfx            x2, x2, #0xc, #0x14
    // 0x1137038: stur            x2, [fp, #-8]
    // 0x113703c: r17 = 5066
    //     0x113703c: mov             x17, #0x13ca
    // 0x1137040: cmp             x2, x17
    // 0x1137044: b.ne            #0x1137058
    // 0x1137048: LoadField: r1 = r0->field_7
    //     0x1137048: ldur            w1, [x0, #7]
    // 0x113704c: DecompressPointer r1
    //     0x113704c: add             x1, x1, HEAP, lsl #32
    // 0x1137050: mov             x0, x2
    // 0x1137054: b               #0x11370dc
    // 0x1137058: r17 = 5067
    //     0x1137058: mov             x17, #0x13cb
    // 0x113705c: cmp             x2, x17
    // 0x1137060: b.ne            #0x11370b8
    // 0x1137064: mov             x1, x0
    // 0x1137068: LoadField: r0 = r1->field_4b
    //     0x1137068: ldur            w0, [x1, #0x4b]
    // 0x113706c: DecompressPointer r0
    //     0x113706c: add             x0, x0, HEAP, lsl #32
    // 0x1137070: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1137074: cmp             w0, w16
    // 0x1137078: b.ne            #0x1137088
    // 0x113707c: r2 = _colors
    //     0x113707c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26200] Field <_SnackbarDefaultsM3@773267081._colors@773267081>: late final (offset: 0x4c)
    //     0x1137080: ldr             x2, [x2, #0x200]
    // 0x1137084: r0 = InitLateFinalInstanceField()
    //     0x1137084: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1137088: LoadField: r1 = r0->field_b7
    //     0x1137088: ldur            w1, [x0, #0xb7]
    // 0x113708c: DecompressPointer r1
    //     0x113708c: add             x1, x1, HEAP, lsl #32
    // 0x1137090: cmp             w1, NULL
    // 0x1137094: b.ne            #0x11370a8
    // 0x1137098: LoadField: r1 = r0->field_7f
    //     0x1137098: ldur            w1, [x0, #0x7f]
    // 0x113709c: DecompressPointer r1
    //     0x113709c: add             x1, x1, HEAP, lsl #32
    // 0x11370a0: mov             x0, x1
    // 0x11370a4: b               #0x11370ac
    // 0x11370a8: mov             x0, x1
    // 0x11370ac: mov             x1, x0
    // 0x11370b0: ldur            x0, [fp, #-8]
    // 0x11370b4: b               #0x11370dc
    // 0x11370b8: mov             x2, x0
    // 0x11370bc: r0 = LoadClassIdInstr(r2)
    //     0x11370bc: ldur            x0, [x2, #-1]
    //     0x11370c0: ubfx            x0, x0, #0xc, #0x14
    // 0x11370c4: mov             x1, x2
    // 0x11370c8: r0 = GDT[cid_x0 + -0xf44]()
    //     0x11370c8: sub             lr, x0, #0xf44
    //     0x11370cc: ldr             lr, [x21, lr, lsl #3]
    //     0x11370d0: blr             lr
    // 0x11370d4: mov             x1, x0
    // 0x11370d8: ldur            x0, [fp, #-8]
    // 0x11370dc: stur            x1, [fp, #-0x10]
    // 0x11370e0: r17 = 5066
    //     0x11370e0: mov             x17, #0x13ca
    // 0x11370e4: cmp             x0, x17
    // 0x11370e8: b.ne            #0x1137108
    // 0x11370ec: ldr             x2, [fp, #0x10]
    // 0x11370f0: LoadField: r3 = r2->field_b
    //     0x11370f0: ldur            w3, [x2, #0xb]
    // 0x11370f4: DecompressPointer r3
    //     0x11370f4: add             x3, x3, HEAP, lsl #32
    // 0x11370f8: mov             x16, x0
    // 0x11370fc: mov             x0, x2
    // 0x1137100: mov             x2, x16
    // 0x1137104: b               #0x1137188
    // 0x1137108: ldr             x2, [fp, #0x10]
    // 0x113710c: r17 = 5067
    //     0x113710c: mov             x17, #0x13cb
    // 0x1137110: cmp             x0, x17
    // 0x1137114: b.ne            #0x1137160
    // 0x1137118: r1 = 1
    //     0x1137118: mov             x1, #1
    // 0x113711c: r0 = AllocateContext()
    //     0x113711c: bl              #0x13de838  ; AllocateContextStub
    // 0x1137120: ldr             x1, [fp, #0x10]
    // 0x1137124: stur            x0, [fp, #-0x18]
    // 0x1137128: StoreField: r0->field_f = r1
    //     0x1137128: stur            w1, [x0, #0xf]
    // 0x113712c: r0 = _WidgetStateColor()
    //     0x113712c: bl              #0xd29244  ; Allocate_WidgetStateColorStub -> _WidgetStateColor (size=0x30)
    // 0x1137130: ldur            x2, [fp, #-0x18]
    // 0x1137134: r1 = Function '<anonymous closure>':.
    //     0x1137134: add             x1, PP, #0x26, lsl #12  ; [pp+0x26208] AnonymousClosure: (0x11376ac), of [package:flutter/src/material/snack_bar.dart] _SnackbarDefaultsM3
    //     0x1137138: ldr             x1, [x1, #0x208]
    // 0x113713c: stur            x0, [fp, #-0x18]
    // 0x1137140: r0 = AllocateClosure()
    //     0x1137140: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1137144: ldur            x1, [fp, #-0x18]
    // 0x1137148: mov             x2, x0
    // 0x113714c: r0 = _WidgetStateColor()
    //     0x113714c: bl              #0xd29128  ; [package:flutter/src/widgets/widget_state.dart] _WidgetStateColor::_WidgetStateColor
    // 0x1137150: ldur            x3, [fp, #-0x18]
    // 0x1137154: ldr             x0, [fp, #0x10]
    // 0x1137158: ldur            x2, [fp, #-8]
    // 0x113715c: b               #0x1137188
    // 0x1137160: mov             x0, x2
    // 0x1137164: LoadField: r1 = r0->field_47
    //     0x1137164: ldur            w1, [x0, #0x47]
    // 0x1137168: DecompressPointer r1
    //     0x1137168: add             x1, x1, HEAP, lsl #32
    // 0x113716c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1137170: cmp             w1, w16
    // 0x1137174: b.eq            #0x113766c
    // 0x1137178: LoadField: r2 = r1->field_2b
    //     0x1137178: ldur            w2, [x1, #0x2b]
    // 0x113717c: DecompressPointer r2
    //     0x113717c: add             x2, x2, HEAP, lsl #32
    // 0x1137180: mov             x3, x2
    // 0x1137184: ldur            x2, [fp, #-8]
    // 0x1137188: stur            x3, [fp, #-0x18]
    // 0x113718c: r17 = 5066
    //     0x113718c: mov             x17, #0x13ca
    // 0x1137190: cmp             x2, x17
    // 0x1137194: b.ne            #0x11371ac
    // 0x1137198: LoadField: r1 = r0->field_f
    //     0x1137198: ldur            w1, [x0, #0xf]
    // 0x113719c: DecompressPointer r1
    //     0x113719c: add             x1, x1, HEAP, lsl #32
    // 0x11371a0: mov             x0, x2
    // 0x11371a4: mov             x2, x1
    // 0x11371a8: b               #0x113728c
    // 0x11371ac: r17 = 5067
    //     0x11371ac: mov             x17, #0x13cb
    // 0x11371b0: cmp             x2, x17
    // 0x11371b4: b.ne            #0x113720c
    // 0x11371b8: mov             x1, x0
    // 0x11371bc: LoadField: r0 = r1->field_4b
    //     0x11371bc: ldur            w0, [x1, #0x4b]
    // 0x11371c0: DecompressPointer r0
    //     0x11371c0: add             x0, x0, HEAP, lsl #32
    // 0x11371c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11371c8: cmp             w0, w16
    // 0x11371cc: b.ne            #0x11371dc
    // 0x11371d0: r2 = _colors
    //     0x11371d0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26200] Field <_SnackbarDefaultsM3@773267081._colors@773267081>: late final (offset: 0x4c)
    //     0x11371d4: ldr             x2, [x2, #0x200]
    // 0x11371d8: r0 = InitLateFinalInstanceField()
    //     0x11371d8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11371dc: LoadField: r1 = r0->field_bf
    //     0x11371dc: ldur            w1, [x0, #0xbf]
    // 0x11371e0: DecompressPointer r1
    //     0x11371e0: add             x1, x1, HEAP, lsl #32
    // 0x11371e4: cmp             w1, NULL
    // 0x11371e8: b.ne            #0x11371fc
    // 0x11371ec: LoadField: r1 = r0->field_f
    //     0x11371ec: ldur            w1, [x0, #0xf]
    // 0x11371f0: DecompressPointer r1
    //     0x11371f0: add             x1, x1, HEAP, lsl #32
    // 0x11371f4: mov             x0, x1
    // 0x11371f8: b               #0x1137200
    // 0x11371fc: mov             x0, x1
    // 0x1137200: mov             x2, x0
    // 0x1137204: ldur            x0, [fp, #-8]
    // 0x1137208: b               #0x113728c
    // 0x113720c: mov             x2, x0
    // 0x1137210: LoadField: r0 = r2->field_47
    //     0x1137210: ldur            w0, [x2, #0x47]
    // 0x1137214: DecompressPointer r0
    //     0x1137214: add             x0, x0, HEAP, lsl #32
    // 0x1137218: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x113721c: cmp             w0, w16
    // 0x1137220: b.eq            #0x1137678
    // 0x1137224: LoadField: r1 = r0->field_7f
    //     0x1137224: ldur            w1, [x0, #0x7f]
    // 0x1137228: DecompressPointer r1
    //     0x1137228: add             x1, x1, HEAP, lsl #32
    // 0x113722c: LoadField: r0 = r2->field_43
    //     0x113722c: ldur            w0, [x2, #0x43]
    // 0x1137230: DecompressPointer r0
    //     0x1137230: add             x0, x0, HEAP, lsl #32
    // 0x1137234: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1137238: cmp             w0, w16
    // 0x113723c: b.eq            #0x1137684
    // 0x1137240: LoadField: r3 = r0->field_3f
    //     0x1137240: ldur            w3, [x0, #0x3f]
    // 0x1137244: DecompressPointer r3
    //     0x1137244: add             x3, x3, HEAP, lsl #32
    // 0x1137248: LoadField: r0 = r3->field_7
    //     0x1137248: ldur            w0, [x3, #7]
    // 0x113724c: DecompressPointer r0
    //     0x113724c: add             x0, x0, HEAP, lsl #32
    // 0x1137250: r16 = Instance_Brightness
    //     0x1137250: ldr             x16, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0x1137254: cmp             w0, w16
    // 0x1137258: b.ne            #0x1137268
    // 0x113725c: d0 = 0.380000
    //     0x113725c: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1137260: ldr             d0, [x17, #0x1f0]
    // 0x1137264: b               #0x1137270
    // 0x1137268: d0 = 0.300000
    //     0x1137268: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a88] IMM: double(0.3) from 0x3fd3333333333333
    //     0x113726c: ldr             d0, [x17, #0xa88]
    // 0x1137270: r0 = LoadClassIdInstr(r1)
    //     0x1137270: ldur            x0, [x1, #-1]
    //     0x1137274: ubfx            x0, x0, #0xc, #0x14
    // 0x1137278: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1137278: sub             lr, x0, #1, lsl #12
    //     0x113727c: ldr             lr, [x21, lr, lsl #3]
    //     0x1137280: blr             lr
    // 0x1137284: mov             x2, x0
    // 0x1137288: ldur            x0, [fp, #-8]
    // 0x113728c: stur            x2, [fp, #-0x20]
    // 0x1137290: r17 = 5066
    //     0x1137290: mov             x17, #0x13ca
    // 0x1137294: cmp             x0, x17
    // 0x1137298: b.ne            #0x11372b0
    // 0x113729c: ldr             x3, [fp, #0x10]
    // 0x11372a0: LoadField: r1 = r3->field_13
    //     0x11372a0: ldur            w1, [x3, #0x13]
    // 0x11372a4: DecompressPointer r1
    //     0x11372a4: add             x1, x1, HEAP, lsl #32
    // 0x11372a8: mov             x2, x1
    // 0x11372ac: b               #0x11373c4
    // 0x11372b0: ldr             x3, [fp, #0x10]
    // 0x11372b4: r17 = 5067
    //     0x11372b4: mov             x17, #0x13cb
    // 0x11372b8: cmp             x0, x17
    // 0x11372bc: b.ne            #0x1137350
    // 0x11372c0: LoadField: r1 = r3->field_43
    //     0x11372c0: ldur            w1, [x3, #0x43]
    // 0x11372c4: DecompressPointer r1
    //     0x11372c4: add             x1, x1, HEAP, lsl #32
    // 0x11372c8: r0 = of()
    //     0x11372c8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x11372cc: LoadField: r1 = r0->field_87
    //     0x11372cc: ldur            w1, [x0, #0x87]
    // 0x11372d0: DecompressPointer r1
    //     0x11372d0: add             x1, x1, HEAP, lsl #32
    // 0x11372d4: LoadField: r0 = r1->field_2f
    //     0x11372d4: ldur            w0, [x1, #0x2f]
    // 0x11372d8: DecompressPointer r0
    //     0x11372d8: add             x0, x0, HEAP, lsl #32
    // 0x11372dc: stur            x0, [fp, #-0x28]
    // 0x11372e0: cmp             w0, NULL
    // 0x11372e4: b.eq            #0x1137690
    // 0x11372e8: ldr             x1, [fp, #0x10]
    // 0x11372ec: LoadField: r0 = r1->field_4b
    //     0x11372ec: ldur            w0, [x1, #0x4b]
    // 0x11372f0: DecompressPointer r0
    //     0x11372f0: add             x0, x0, HEAP, lsl #32
    // 0x11372f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11372f8: cmp             w0, w16
    // 0x11372fc: b.ne            #0x113730c
    // 0x1137300: r2 = _colors
    //     0x1137300: add             x2, PP, #0x26, lsl #12  ; [pp+0x26200] Field <_SnackbarDefaultsM3@773267081._colors@773267081>: late final (offset: 0x4c)
    //     0x1137304: ldr             x2, [x2, #0x200]
    // 0x1137308: r0 = InitLateFinalInstanceField()
    //     0x1137308: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113730c: LoadField: r1 = r0->field_bb
    //     0x113730c: ldur            w1, [x0, #0xbb]
    // 0x1137310: DecompressPointer r1
    //     0x1137310: add             x1, x1, HEAP, lsl #32
    // 0x1137314: cmp             w1, NULL
    // 0x1137318: b.ne            #0x113732c
    // 0x113731c: LoadField: r1 = r0->field_7b
    //     0x113731c: ldur            w1, [x0, #0x7b]
    // 0x1137320: DecompressPointer r1
    //     0x1137320: add             x1, x1, HEAP, lsl #32
    // 0x1137324: mov             x0, x1
    // 0x1137328: b               #0x1137330
    // 0x113732c: mov             x0, x1
    // 0x1137330: str             x0, [SP]
    // 0x1137334: ldur            x1, [fp, #-0x28]
    // 0x1137338: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x1137338: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x113733c: ldr             x4, [x4, #0x7f0]
    // 0x1137340: r0 = copyWith()
    //     0x1137340: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x1137344: mov             x2, x0
    // 0x1137348: ldur            x0, [fp, #-8]
    // 0x113734c: b               #0x11373c4
    // 0x1137350: mov             x0, x3
    // 0x1137354: LoadField: r1 = r0->field_43
    //     0x1137354: ldur            w1, [x0, #0x43]
    // 0x1137358: DecompressPointer r1
    //     0x1137358: add             x1, x1, HEAP, lsl #32
    // 0x113735c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1137360: cmp             w1, w16
    // 0x1137364: b.eq            #0x1137694
    // 0x1137368: LoadField: r2 = r1->field_2f
    //     0x1137368: ldur            w2, [x1, #0x2f]
    // 0x113736c: DecompressPointer r2
    //     0x113736c: add             x2, x2, HEAP, lsl #32
    // 0x1137370: LoadField: r3 = r1->field_3f
    //     0x1137370: ldur            w3, [x1, #0x3f]
    // 0x1137374: DecompressPointer r3
    //     0x1137374: add             x3, x3, HEAP, lsl #32
    // 0x1137378: LoadField: r1 = r3->field_7
    //     0x1137378: ldur            w1, [x3, #7]
    // 0x113737c: DecompressPointer r1
    //     0x113737c: add             x1, x1, HEAP, lsl #32
    // 0x1137380: r16 = Instance_Brightness
    //     0x1137380: ldr             x16, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0x1137384: cmp             w1, w16
    // 0x1137388: b.ne            #0x1137394
    // 0x113738c: r1 = Instance_Brightness
    //     0x113738c: ldr             x1, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x1137390: b               #0x1137398
    // 0x1137394: r1 = Instance_Brightness
    //     0x1137394: ldr             x1, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0x1137398: stp             x1, x2, [SP]
    // 0x113739c: r1 = Null
    //     0x113739c: mov             x1, NULL
    // 0x11373a0: r4 = const [0, 0x3, 0x2, 0x1, brightness, 0x2, useMaterial3, 0x1, null]
    //     0x11373a0: add             x4, PP, #0x26, lsl #12  ; [pp+0x26210] List(9) [0, 0x3, 0x2, 0x1, "brightness", 0x2, "useMaterial3", 0x1, Null]
    //     0x11373a4: ldr             x4, [x4, #0x210]
    // 0x11373a8: r0 = ThemeData()
    //     0x11373a8: bl              #0x8a9c18  ; [package:flutter/src/material/theme_data.dart] ThemeData::ThemeData
    // 0x11373ac: LoadField: r1 = r0->field_87
    //     0x11373ac: ldur            w1, [x0, #0x87]
    // 0x11373b0: DecompressPointer r1
    //     0x11373b0: add             x1, x1, HEAP, lsl #32
    // 0x11373b4: LoadField: r0 = r1->field_23
    //     0x11373b4: ldur            w0, [x1, #0x23]
    // 0x11373b8: DecompressPointer r0
    //     0x11373b8: add             x0, x0, HEAP, lsl #32
    // 0x11373bc: mov             x2, x0
    // 0x11373c0: ldur            x0, [fp, #-8]
    // 0x11373c4: stur            x2, [fp, #-0x58]
    // 0x11373c8: r17 = 5066
    //     0x11373c8: mov             x17, #0x13ca
    // 0x11373cc: cmp             x0, x17
    // 0x11373d0: b.eq            #0x11373f0
    // 0x11373d4: r17 = 5067
    //     0x11373d4: mov             x17, #0x13cb
    // 0x11373d8: cmp             x0, x17
    // 0x11373dc: b.ne            #0x11373f0
    // 0x11373e0: ldr             x3, [fp, #0x10]
    // 0x11373e4: r4 = 6.000000
    //     0x11373e4: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1c438] 6
    //     0x11373e8: ldr             x4, [x4, #0x438]
    // 0x11373ec: b               #0x1137400
    // 0x11373f0: ldr             x3, [fp, #0x10]
    // 0x11373f4: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x11373f4: ldur            w1, [x3, #0x17]
    // 0x11373f8: DecompressPointer r1
    //     0x11373f8: add             x1, x1, HEAP, lsl #32
    // 0x11373fc: mov             x4, x1
    // 0x1137400: stur            x4, [fp, #-0x50]
    // 0x1137404: r17 = 5066
    //     0x1137404: mov             x17, #0x13ca
    // 0x1137408: cmp             x0, x17
    // 0x113740c: b.ne            #0x1137420
    // 0x1137410: LoadField: r1 = r3->field_1b
    //     0x1137410: ldur            w1, [x3, #0x1b]
    // 0x1137414: DecompressPointer r1
    //     0x1137414: add             x1, x1, HEAP, lsl #32
    // 0x1137418: mov             x5, x1
    // 0x113741c: b               #0x1137440
    // 0x1137420: r17 = 5067
    //     0x1137420: mov             x17, #0x13cb
    // 0x1137424: cmp             x0, x17
    // 0x1137428: b.ne            #0x1137438
    // 0x113742c: r5 = Instance_RoundedRectangleBorder
    //     0x113742c: add             x5, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0x1137430: ldr             x5, [x5, #0x218]
    // 0x1137434: b               #0x1137440
    // 0x1137438: r5 = Instance_RoundedRectangleBorder
    //     0x1137438: add             x5, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0x113743c: ldr             x5, [x5, #0x218]
    // 0x1137440: stur            x5, [fp, #-0x48]
    // 0x1137444: r17 = 5066
    //     0x1137444: mov             x17, #0x13ca
    // 0x1137448: cmp             x0, x17
    // 0x113744c: b.ne            #0x1137460
    // 0x1137450: LoadField: r1 = r3->field_1f
    //     0x1137450: ldur            w1, [x3, #0x1f]
    // 0x1137454: DecompressPointer r1
    //     0x1137454: add             x1, x1, HEAP, lsl #32
    // 0x1137458: mov             x6, x1
    // 0x113745c: b               #0x1137480
    // 0x1137460: r17 = 5067
    //     0x1137460: mov             x17, #0x13cb
    // 0x1137464: cmp             x0, x17
    // 0x1137468: b.ne            #0x1137478
    // 0x113746c: r6 = Instance_SnackBarBehavior
    //     0x113746c: add             x6, PP, #0x26, lsl #12  ; [pp+0x26220] Obj!SnackBarBehavior@12c4d61
    //     0x1137470: ldr             x6, [x6, #0x220]
    // 0x1137474: b               #0x1137480
    // 0x1137478: r6 = Instance_SnackBarBehavior
    //     0x1137478: add             x6, PP, #0x26, lsl #12  ; [pp+0x26220] Obj!SnackBarBehavior@12c4d61
    //     0x113747c: ldr             x6, [x6, #0x220]
    // 0x1137480: stur            x6, [fp, #-0x40]
    // 0x1137484: LoadField: r7 = r3->field_23
    //     0x1137484: ldur            w7, [x3, #0x23]
    // 0x1137488: DecompressPointer r7
    //     0x1137488: add             x7, x7, HEAP, lsl #32
    // 0x113748c: stur            x7, [fp, #-0x38]
    // 0x1137490: r17 = 5066
    //     0x1137490: mov             x17, #0x13ca
    // 0x1137494: cmp             x0, x17
    // 0x1137498: b.ne            #0x11374ac
    // 0x113749c: LoadField: r1 = r3->field_27
    //     0x113749c: ldur            w1, [x3, #0x27]
    // 0x11374a0: DecompressPointer r1
    //     0x11374a0: add             x1, x1, HEAP, lsl #32
    // 0x11374a4: mov             x8, x1
    // 0x11374a8: b               #0x11374cc
    // 0x11374ac: r17 = 5067
    //     0x11374ac: mov             x17, #0x13cb
    // 0x11374b0: cmp             x0, x17
    // 0x11374b4: b.ne            #0x11374c4
    // 0x11374b8: r8 = Instance_EdgeInsets
    //     0x11374b8: add             x8, PP, #0x26, lsl #12  ; [pp+0x26228] Obj!EdgeInsets@129d681
    //     0x11374bc: ldr             x8, [x8, #0x228]
    // 0x11374c0: b               #0x11374cc
    // 0x11374c4: r8 = Instance_EdgeInsets
    //     0x11374c4: add             x8, PP, #0x26, lsl #12  ; [pp+0x26228] Obj!EdgeInsets@129d681
    //     0x11374c8: ldr             x8, [x8, #0x228]
    // 0x11374cc: stur            x8, [fp, #-0x30]
    // 0x11374d0: r17 = 5066
    //     0x11374d0: mov             x17, #0x13ca
    // 0x11374d4: cmp             x0, x17
    // 0x11374d8: b.ne            #0x11374ec
    // 0x11374dc: LoadField: r1 = r3->field_2b
    //     0x11374dc: ldur            w1, [x3, #0x2b]
    // 0x11374e0: DecompressPointer r1
    //     0x11374e0: add             x1, x1, HEAP, lsl #32
    // 0x11374e4: mov             x9, x1
    // 0x11374e8: b               #0x1137504
    // 0x11374ec: r17 = 5067
    //     0x11374ec: mov             x17, #0x13cb
    // 0x11374f0: cmp             x0, x17
    // 0x11374f4: b.ne            #0x1137500
    // 0x11374f8: r9 = false
    //     0x11374f8: add             x9, NULL, #0x30  ; false
    // 0x11374fc: b               #0x1137504
    // 0x1137500: r9 = false
    //     0x1137500: add             x9, NULL, #0x30  ; false
    // 0x1137504: stur            x9, [fp, #-0x28]
    // 0x1137508: r17 = 5066
    //     0x1137508: mov             x17, #0x13ca
    // 0x113750c: cmp             x0, x17
    // 0x1137510: b.ne            #0x113752c
    // 0x1137514: LoadField: r1 = r3->field_2f
    //     0x1137514: ldur            w1, [x3, #0x2f]
    // 0x1137518: DecompressPointer r1
    //     0x1137518: add             x1, x1, HEAP, lsl #32
    // 0x113751c: mov             x2, x1
    // 0x1137520: mov             x1, x0
    // 0x1137524: mov             x0, x3
    // 0x1137528: b               #0x11375b4
    // 0x113752c: r17 = 5067
    //     0x113752c: mov             x17, #0x13cb
    // 0x1137530: cmp             x0, x17
    // 0x1137534: b.ne            #0x1137590
    // 0x1137538: mov             x1, x3
    // 0x113753c: LoadField: r0 = r1->field_4b
    //     0x113753c: ldur            w0, [x1, #0x4b]
    // 0x1137540: DecompressPointer r0
    //     0x1137540: add             x0, x0, HEAP, lsl #32
    // 0x1137544: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1137548: cmp             w0, w16
    // 0x113754c: b.ne            #0x113755c
    // 0x1137550: r2 = _colors
    //     0x1137550: add             x2, PP, #0x26, lsl #12  ; [pp+0x26200] Field <_SnackbarDefaultsM3@773267081._colors@773267081>: late final (offset: 0x4c)
    //     0x1137554: ldr             x2, [x2, #0x200]
    // 0x1137558: r0 = InitLateFinalInstanceField()
    //     0x1137558: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113755c: LoadField: r1 = r0->field_bb
    //     0x113755c: ldur            w1, [x0, #0xbb]
    // 0x1137560: DecompressPointer r1
    //     0x1137560: add             x1, x1, HEAP, lsl #32
    // 0x1137564: cmp             w1, NULL
    // 0x1137568: b.ne            #0x113757c
    // 0x113756c: LoadField: r1 = r0->field_7b
    //     0x113756c: ldur            w1, [x0, #0x7b]
    // 0x1137570: DecompressPointer r1
    //     0x1137570: add             x1, x1, HEAP, lsl #32
    // 0x1137574: mov             x0, x1
    // 0x1137578: b               #0x1137580
    // 0x113757c: mov             x0, x1
    // 0x1137580: mov             x2, x0
    // 0x1137584: ldr             x0, [fp, #0x10]
    // 0x1137588: ldur            x1, [fp, #-8]
    // 0x113758c: b               #0x11375b4
    // 0x1137590: mov             x0, x3
    // 0x1137594: LoadField: r1 = r0->field_47
    //     0x1137594: ldur            w1, [x0, #0x47]
    // 0x1137598: DecompressPointer r1
    //     0x1137598: add             x1, x1, HEAP, lsl #32
    // 0x113759c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11375a0: cmp             w1, w16
    // 0x11375a4: b.eq            #0x11376a0
    // 0x11375a8: LoadField: r2 = r1->field_7f
    //     0x11375a8: ldur            w2, [x1, #0x7f]
    // 0x11375ac: DecompressPointer r2
    //     0x11375ac: add             x2, x2, HEAP, lsl #32
    // 0x11375b0: ldur            x1, [fp, #-8]
    // 0x11375b4: r17 = 5066
    //     0x11375b4: mov             x17, #0x13ca
    // 0x11375b8: cmp             x1, x17
    // 0x11375bc: b.ne            #0x11375d0
    // 0x11375c0: LoadField: r1 = r0->field_33
    //     0x11375c0: ldur            w1, [x0, #0x33]
    // 0x11375c4: DecompressPointer r1
    //     0x11375c4: add             x1, x1, HEAP, lsl #32
    // 0x11375c8: mov             x0, x1
    // 0x11375cc: b               #0x11375f0
    // 0x11375d0: r17 = 5067
    //     0x11375d0: mov             x17, #0x13cb
    // 0x11375d4: cmp             x1, x17
    // 0x11375d8: b.ne            #0x11375e8
    // 0x11375dc: r0 = 0.250000
    //     0x11375dc: add             x0, PP, #0x12, lsl #12  ; [pp+0x12800] 0.25
    //     0x11375e0: ldr             x0, [x0, #0x800]
    // 0x11375e4: b               #0x11375f0
    // 0x11375e8: r0 = 0.250000
    //     0x11375e8: add             x0, PP, #0x12, lsl #12  ; [pp+0x12800] 0.25
    //     0x11375ec: ldr             x0, [x0, #0x800]
    // 0x11375f0: ldur            x16, [fp, #-0x20]
    // 0x11375f4: ldur            lr, [fp, #-0x58]
    // 0x11375f8: stp             lr, x16, [SP, #0x58]
    // 0x11375fc: ldur            x16, [fp, #-0x50]
    // 0x1137600: ldur            lr, [fp, #-0x48]
    // 0x1137604: stp             lr, x16, [SP, #0x48]
    // 0x1137608: ldur            x16, [fp, #-0x40]
    // 0x113760c: ldur            lr, [fp, #-0x38]
    // 0x1137610: stp             lr, x16, [SP, #0x38]
    // 0x1137614: ldur            x16, [fp, #-0x30]
    // 0x1137618: ldur            lr, [fp, #-0x28]
    // 0x113761c: stp             lr, x16, [SP, #0x28]
    // 0x1137620: stp             x0, x2, [SP, #0x18]
    // 0x1137624: stp             NULL, NULL, [SP, #8]
    // 0x1137628: str             NULL, [SP]
    // 0x113762c: ldur            x1, [fp, #-0x10]
    // 0x1137630: ldur            x2, [fp, #-0x18]
    // 0x1137634: r4 = const [0, 0xf, 0xd, 0xf, null]
    //     0x1137634: add             x4, PP, #0xd, lsl #12  ; [pp+0xdf18] List(5) [0, 0xf, 0xd, 0xf, Null]
    //     0x1137638: ldr             x4, [x4, #0xf18]
    // 0x113763c: r0 = hash()
    //     0x113763c: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1137640: mov             x2, x0
    // 0x1137644: r0 = BoxInt64Instr(r2)
    //     0x1137644: sbfiz           x0, x2, #1, #0x1f
    //     0x1137648: cmp             x2, x0, asr #1
    //     0x113764c: b.eq            #0x1137658
    //     0x1137650: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1137654: stur            x2, [x0, #7]
    // 0x1137658: LeaveFrame
    //     0x1137658: mov             SP, fp
    //     0x113765c: ldp             fp, lr, [SP], #0x10
    // 0x1137660: ret
    //     0x1137660: ret             
    // 0x1137664: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1137664: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1137668: b               #0x113702c
    // 0x113766c: r9 = _colors
    //     0x113766c: add             x9, PP, #0x26, lsl #12  ; [pp+0x26230] Field <_SnackbarDefaultsM2@773267081._colors@773267081>: late final (offset: 0x48)
    //     0x1137670: ldr             x9, [x9, #0x230]
    // 0x1137674: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1137674: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x1137678: r9 = _colors
    //     0x1137678: add             x9, PP, #0x26, lsl #12  ; [pp+0x26230] Field <_SnackbarDefaultsM2@773267081._colors@773267081>: late final (offset: 0x48)
    //     0x113767c: ldr             x9, [x9, #0x230]
    // 0x1137680: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1137680: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x1137684: r9 = _theme
    //     0x1137684: add             x9, PP, #0x26, lsl #12  ; [pp+0x26238] Field <_SnackbarDefaultsM2@773267081._theme@773267081>: late final (offset: 0x44)
    //     0x1137688: ldr             x9, [x9, #0x238]
    // 0x113768c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x113768c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x1137690: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1137690: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1137694: r9 = _theme
    //     0x1137694: add             x9, PP, #0x26, lsl #12  ; [pp+0x26238] Field <_SnackbarDefaultsM2@773267081._theme@773267081>: late final (offset: 0x44)
    //     0x1137698: ldr             x9, [x9, #0x238]
    // 0x113769c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x113769c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x11376a0: r9 = _colors
    //     0x11376a0: add             x9, PP, #0x26, lsl #12  ; [pp+0x26230] Field <_SnackbarDefaultsM2@773267081._colors@773267081>: late final (offset: 0x48)
    //     0x11376a4: ldr             x9, [x9, #0x230]
    // 0x11376a8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x11376a8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x116560c, size: 0x1bc
    // 0x116560c: EnterFrame
    //     0x116560c: stp             fp, lr, [SP, #-0x10]!
    //     0x1165610: mov             fp, SP
    // 0x1165614: AllocStack(0x30)
    //     0x1165614: sub             SP, SP, #0x30
    // 0x1165618: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x30 */)
    //     0x1165618: mov             x4, x1
    //     0x116561c: mov             x0, x2
    //     0x1165620: stur            x1, [fp, #-0x10]
    //     0x1165624: stur            x2, [fp, #-0x18]
    //     0x1165628: stur            d0, [fp, #-0x30]
    // 0x116562c: CheckStackOverflow
    //     0x116562c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1165630: cmp             SP, x16
    //     0x1165634: b.ls            #0x11657a4
    // 0x1165638: cmp             w4, w0
    // 0x116563c: b.ne            #0x1165650
    // 0x1165640: mov             x0, x4
    // 0x1165644: LeaveFrame
    //     0x1165644: mov             SP, fp
    //     0x1165648: ldp             fp, lr, [SP], #0x10
    // 0x116564c: ret
    //     0x116564c: ret             
    // 0x1165650: r5 = inline_Allocate_Double()
    //     0x1165650: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x1165654: add             x5, x5, #0x10
    //     0x1165658: cmp             x1, x5
    //     0x116565c: b.ls            #0x11657ac
    //     0x1165660: str             x5, [THR, #0x60]  ; THR::top
    //     0x1165664: sub             x5, x5, #0xf
    //     0x1165668: mov             x1, #0xe19c
    //     0x116566c: movk            x1, #3, lsl #16
    //     0x1165670: stur            x1, [x5, #-1]
    // 0x1165674: dmb             ishst
    // 0x1165678: StoreField: r5->field_7 = d0
    //     0x1165678: stur            d0, [x5, #7]
    // 0x116567c: mov             x3, x5
    // 0x1165680: stur            x5, [fp, #-8]
    // 0x1165684: r1 = Null
    //     0x1165684: mov             x1, NULL
    // 0x1165688: r2 = Null
    //     0x1165688: mov             x2, NULL
    // 0x116568c: r0 = lerp()
    //     0x116568c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1165690: ldur            x3, [fp, #-8]
    // 0x1165694: r1 = Null
    //     0x1165694: mov             x1, NULL
    // 0x1165698: r2 = Null
    //     0x1165698: mov             x2, NULL
    // 0x116569c: r0 = lerp()
    //     0x116569c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11656a0: ldur            x3, [fp, #-8]
    // 0x11656a4: r1 = Null
    //     0x11656a4: mov             x1, NULL
    // 0x11656a8: r2 = Null
    //     0x11656a8: mov             x2, NULL
    // 0x11656ac: r0 = lerp()
    //     0x11656ac: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11656b0: ldur            x3, [fp, #-8]
    // 0x11656b4: r1 = Null
    //     0x11656b4: mov             x1, NULL
    // 0x11656b8: r2 = Null
    //     0x11656b8: mov             x2, NULL
    // 0x11656bc: r0 = lerp()
    //     0x11656bc: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x11656c0: ldur            x0, [fp, #-0x10]
    // 0x11656c4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11656c4: ldur            w1, [x0, #0x17]
    // 0x11656c8: DecompressPointer r1
    //     0x11656c8: add             x1, x1, HEAP, lsl #32
    // 0x11656cc: ldur            x4, [fp, #-0x18]
    // 0x11656d0: ArrayLoad: r2 = r4[0]  ; List_4
    //     0x11656d0: ldur            w2, [x4, #0x17]
    // 0x11656d4: DecompressPointer r2
    //     0x11656d4: add             x2, x2, HEAP, lsl #32
    // 0x11656d8: ldur            x3, [fp, #-8]
    // 0x11656dc: r0 = lerpDouble()
    //     0x11656dc: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x11656e0: ldur            d0, [fp, #-0x30]
    // 0x11656e4: r1 = Null
    //     0x11656e4: mov             x1, NULL
    // 0x11656e8: r2 = Null
    //     0x11656e8: mov             x2, NULL
    // 0x11656ec: stur            x0, [fp, #-0x20]
    // 0x11656f0: r0 = lerp()
    //     0x11656f0: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x11656f4: ldur            x0, [fp, #-0x10]
    // 0x11656f8: LoadField: r1 = r0->field_23
    //     0x11656f8: ldur            w1, [x0, #0x23]
    // 0x11656fc: DecompressPointer r1
    //     0x11656fc: add             x1, x1, HEAP, lsl #32
    // 0x1165700: ldur            x4, [fp, #-0x18]
    // 0x1165704: LoadField: r2 = r4->field_23
    //     0x1165704: ldur            w2, [x4, #0x23]
    // 0x1165708: DecompressPointer r2
    //     0x1165708: add             x2, x2, HEAP, lsl #32
    // 0x116570c: ldur            x3, [fp, #-8]
    // 0x1165710: r0 = lerpDouble()
    //     0x1165710: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1165714: ldur            d0, [fp, #-0x30]
    // 0x1165718: r1 = Null
    //     0x1165718: mov             x1, NULL
    // 0x116571c: r2 = Null
    //     0x116571c: mov             x2, NULL
    // 0x1165720: stur            x0, [fp, #-0x28]
    // 0x1165724: r0 = lerp()
    //     0x1165724: bl              #0x868640  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::lerp
    // 0x1165728: ldur            x3, [fp, #-8]
    // 0x116572c: r1 = Null
    //     0x116572c: mov             x1, NULL
    // 0x1165730: r2 = Null
    //     0x1165730: mov             x2, NULL
    // 0x1165734: r0 = lerp()
    //     0x1165734: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1165738: ldur            x0, [fp, #-0x10]
    // 0x116573c: LoadField: r1 = r0->field_33
    //     0x116573c: ldur            w1, [x0, #0x33]
    // 0x1165740: DecompressPointer r1
    //     0x1165740: add             x1, x1, HEAP, lsl #32
    // 0x1165744: ldur            x0, [fp, #-0x18]
    // 0x1165748: LoadField: r2 = r0->field_33
    //     0x1165748: ldur            w2, [x0, #0x33]
    // 0x116574c: DecompressPointer r2
    //     0x116574c: add             x2, x2, HEAP, lsl #32
    // 0x1165750: ldur            x3, [fp, #-8]
    // 0x1165754: r0 = lerpDouble()
    //     0x1165754: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1165758: ldur            x3, [fp, #-8]
    // 0x116575c: r1 = Null
    //     0x116575c: mov             x1, NULL
    // 0x1165760: r2 = Null
    //     0x1165760: mov             x2, NULL
    // 0x1165764: stur            x0, [fp, #-0x10]
    // 0x1165768: r0 = lerp()
    //     0x1165768: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116576c: ldur            x3, [fp, #-8]
    // 0x1165770: r1 = Null
    //     0x1165770: mov             x1, NULL
    // 0x1165774: r2 = Null
    //     0x1165774: mov             x2, NULL
    // 0x1165778: r0 = lerp()
    //     0x1165778: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116577c: r0 = SnackBarThemeData()
    //     0x116577c: bl              #0x11657c8  ; AllocateSnackBarThemeDataStub -> SnackBarThemeData (size=0x44)
    // 0x1165780: ldur            x1, [fp, #-0x20]
    // 0x1165784: ArrayStore: r0[0] = r1  ; List_4
    //     0x1165784: stur            w1, [x0, #0x17]
    // 0x1165788: ldur            x1, [fp, #-0x28]
    // 0x116578c: StoreField: r0->field_23 = r1
    //     0x116578c: stur            w1, [x0, #0x23]
    // 0x1165790: ldur            x1, [fp, #-0x10]
    // 0x1165794: StoreField: r0->field_33 = r1
    //     0x1165794: stur            w1, [x0, #0x33]
    // 0x1165798: LeaveFrame
    //     0x1165798: mov             SP, fp
    //     0x116579c: ldp             fp, lr, [SP], #0x10
    // 0x11657a0: ret
    //     0x11657a0: ret             
    // 0x11657a4: r0 = StackOverflowSharedWithFPURegs()
    //     0x11657a4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11657a8: b               #0x1165638
    // 0x11657ac: SaveReg d0
    //     0x11657ac: str             q0, [SP, #-0x10]!
    // 0x11657b0: stp             x0, x4, [SP, #-0x10]!
    // 0x11657b4: r0 = AllocateDouble()
    //     0x11657b4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11657b8: mov             x5, x0
    // 0x11657bc: ldp             x0, x4, [SP], #0x10
    // 0x11657c0: RestoreReg d0
    //     0x11657c0: ldr             q0, [SP], #0x10
    // 0x11657c4: b               #0x1165678
  }
  _ ==(/* No info */) {
    // ** addr: 0x1274308, size: 0xdfc
    // 0x1274308: EnterFrame
    //     0x1274308: stp             fp, lr, [SP, #-0x10]!
    //     0x127430c: mov             fp, SP
    // 0x1274310: AllocStack(0x30)
    //     0x1274310: sub             SP, SP, #0x30
    // 0x1274314: CheckStackOverflow
    //     0x1274314: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1274318: cmp             SP, x16
    //     0x127431c: b.ls            #0x127507c
    // 0x1274320: ldr             x1, [fp, #0x10]
    // 0x1274324: cmp             w1, NULL
    // 0x1274328: b.ne            #0x127433c
    // 0x127432c: r0 = false
    //     0x127432c: add             x0, NULL, #0x30  ; false
    // 0x1274330: LeaveFrame
    //     0x1274330: mov             SP, fp
    //     0x1274334: ldp             fp, lr, [SP], #0x10
    // 0x1274338: ret
    //     0x1274338: ret             
    // 0x127433c: ldr             x0, [fp, #0x18]
    // 0x1274340: cmp             w0, w1
    // 0x1274344: b.ne            #0x1274358
    // 0x1274348: r0 = true
    //     0x1274348: add             x0, NULL, #0x20  ; true
    // 0x127434c: LeaveFrame
    //     0x127434c: mov             SP, fp
    //     0x1274350: ldp             fp, lr, [SP], #0x10
    // 0x1274354: ret
    //     0x1274354: ret             
    // 0x1274358: stp             x0, x1, [SP]
    // 0x127435c: r0 = _haveSameRuntimeType()
    //     0x127435c: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x1274360: tbz             w0, #4, #0x1274374
    // 0x1274364: r0 = false
    //     0x1274364: add             x0, NULL, #0x30  ; false
    // 0x1274368: LeaveFrame
    //     0x1274368: mov             SP, fp
    //     0x127436c: ldp             fp, lr, [SP], #0x10
    // 0x1274370: ret
    //     0x1274370: ret             
    // 0x1274374: ldr             x0, [fp, #0x10]
    // 0x1274378: r2 = 60
    //     0x1274378: mov             x2, #0x3c
    // 0x127437c: branchIfSmi(r0, 0x1274388)
    //     0x127437c: tbz             w0, #0, #0x1274388
    // 0x1274380: r2 = LoadClassIdInstr(r0)
    //     0x1274380: ldur            x2, [x0, #-1]
    //     0x1274384: ubfx            x2, x2, #0xc, #0x14
    // 0x1274388: stur            x2, [fp, #-8]
    // 0x127438c: r17 = -5066
    //     0x127438c: mov             x17, #-0x13ca
    // 0x1274390: add             x16, x2, x17
    // 0x1274394: cmp             x16, #2
    // 0x1274398: b.hi            #0x127506c
    // 0x127439c: r17 = 5066
    //     0x127439c: mov             x17, #0x13ca
    // 0x12743a0: cmp             x2, x17
    // 0x12743a4: b.ne            #0x12743b8
    // 0x12743a8: LoadField: r1 = r0->field_7
    //     0x12743a8: ldur            w1, [x0, #7]
    // 0x12743ac: DecompressPointer r1
    //     0x12743ac: add             x1, x1, HEAP, lsl #32
    // 0x12743b0: mov             x2, x1
    // 0x12743b4: b               #0x1274434
    // 0x12743b8: r17 = 5067
    //     0x12743b8: mov             x17, #0x13cb
    // 0x12743bc: cmp             x2, x17
    // 0x12743c0: b.ne            #0x1274414
    // 0x12743c4: mov             x1, x0
    // 0x12743c8: LoadField: r0 = r1->field_4b
    //     0x12743c8: ldur            w0, [x1, #0x4b]
    // 0x12743cc: DecompressPointer r0
    //     0x12743cc: add             x0, x0, HEAP, lsl #32
    // 0x12743d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12743d4: cmp             w0, w16
    // 0x12743d8: b.ne            #0x12743e8
    // 0x12743dc: r2 = _colors
    //     0x12743dc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26200] Field <_SnackbarDefaultsM3@773267081._colors@773267081>: late final (offset: 0x4c)
    //     0x12743e0: ldr             x2, [x2, #0x200]
    // 0x12743e4: r0 = InitLateFinalInstanceField()
    //     0x12743e4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12743e8: LoadField: r1 = r0->field_b7
    //     0x12743e8: ldur            w1, [x0, #0xb7]
    // 0x12743ec: DecompressPointer r1
    //     0x12743ec: add             x1, x1, HEAP, lsl #32
    // 0x12743f0: cmp             w1, NULL
    // 0x12743f4: b.ne            #0x1274408
    // 0x12743f8: LoadField: r1 = r0->field_7f
    //     0x12743f8: ldur            w1, [x0, #0x7f]
    // 0x12743fc: DecompressPointer r1
    //     0x12743fc: add             x1, x1, HEAP, lsl #32
    // 0x1274400: mov             x0, x1
    // 0x1274404: b               #0x127440c
    // 0x1274408: mov             x0, x1
    // 0x127440c: mov             x2, x0
    // 0x1274410: b               #0x1274434
    // 0x1274414: mov             x2, x0
    // 0x1274418: r0 = LoadClassIdInstr(r2)
    //     0x1274418: ldur            x0, [x2, #-1]
    //     0x127441c: ubfx            x0, x0, #0xc, #0x14
    // 0x1274420: mov             x1, x2
    // 0x1274424: r0 = GDT[cid_x0 + -0xf44]()
    //     0x1274424: sub             lr, x0, #0xf44
    //     0x1274428: ldr             lr, [x21, lr, lsl #3]
    //     0x127442c: blr             lr
    // 0x1274430: mov             x2, x0
    // 0x1274434: ldr             x0, [fp, #0x18]
    // 0x1274438: stur            x2, [fp, #-0x18]
    // 0x127443c: r3 = LoadClassIdInstr(r0)
    //     0x127443c: ldur            x3, [x0, #-1]
    //     0x1274440: ubfx            x3, x3, #0xc, #0x14
    // 0x1274444: stur            x3, [fp, #-0x10]
    // 0x1274448: r17 = 5066
    //     0x1274448: mov             x17, #0x13ca
    // 0x127444c: cmp             x3, x17
    // 0x1274450: b.ne            #0x1274464
    // 0x1274454: LoadField: r1 = r0->field_7
    //     0x1274454: ldur            w1, [x0, #7]
    // 0x1274458: DecompressPointer r1
    //     0x1274458: add             x1, x1, HEAP, lsl #32
    // 0x127445c: mov             x0, x2
    // 0x1274460: b               #0x12744e8
    // 0x1274464: r17 = 5067
    //     0x1274464: mov             x17, #0x13cb
    // 0x1274468: cmp             x3, x17
    // 0x127446c: b.ne            #0x12744c4
    // 0x1274470: mov             x1, x0
    // 0x1274474: LoadField: r0 = r1->field_4b
    //     0x1274474: ldur            w0, [x1, #0x4b]
    // 0x1274478: DecompressPointer r0
    //     0x1274478: add             x0, x0, HEAP, lsl #32
    // 0x127447c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1274480: cmp             w0, w16
    // 0x1274484: b.ne            #0x1274494
    // 0x1274488: r2 = _colors
    //     0x1274488: add             x2, PP, #0x26, lsl #12  ; [pp+0x26200] Field <_SnackbarDefaultsM3@773267081._colors@773267081>: late final (offset: 0x4c)
    //     0x127448c: ldr             x2, [x2, #0x200]
    // 0x1274490: r0 = InitLateFinalInstanceField()
    //     0x1274490: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1274494: LoadField: r1 = r0->field_b7
    //     0x1274494: ldur            w1, [x0, #0xb7]
    // 0x1274498: DecompressPointer r1
    //     0x1274498: add             x1, x1, HEAP, lsl #32
    // 0x127449c: cmp             w1, NULL
    // 0x12744a0: b.ne            #0x12744b4
    // 0x12744a4: LoadField: r1 = r0->field_7f
    //     0x12744a4: ldur            w1, [x0, #0x7f]
    // 0x12744a8: DecompressPointer r1
    //     0x12744a8: add             x1, x1, HEAP, lsl #32
    // 0x12744ac: mov             x0, x1
    // 0x12744b0: b               #0x12744b8
    // 0x12744b4: mov             x0, x1
    // 0x12744b8: mov             x1, x0
    // 0x12744bc: ldur            x0, [fp, #-0x18]
    // 0x12744c0: b               #0x12744e8
    // 0x12744c4: mov             x2, x0
    // 0x12744c8: r0 = LoadClassIdInstr(r2)
    //     0x12744c8: ldur            x0, [x2, #-1]
    //     0x12744cc: ubfx            x0, x0, #0xc, #0x14
    // 0x12744d0: mov             x1, x2
    // 0x12744d4: r0 = GDT[cid_x0 + -0xf44]()
    //     0x12744d4: sub             lr, x0, #0xf44
    //     0x12744d8: ldr             lr, [x21, lr, lsl #3]
    //     0x12744dc: blr             lr
    // 0x12744e0: mov             x1, x0
    // 0x12744e4: ldur            x0, [fp, #-0x18]
    // 0x12744e8: r2 = LoadClassIdInstr(r0)
    //     0x12744e8: ldur            x2, [x0, #-1]
    //     0x12744ec: ubfx            x2, x2, #0xc, #0x14
    // 0x12744f0: stp             x1, x0, [SP]
    // 0x12744f4: mov             x0, x2
    // 0x12744f8: mov             lr, x0
    // 0x12744fc: ldr             lr, [x21, lr, lsl #3]
    // 0x1274500: blr             lr
    // 0x1274504: tbnz            w0, #4, #0x127506c
    // 0x1274508: ldur            x0, [fp, #-8]
    // 0x127450c: r17 = 5066
    //     0x127450c: mov             x17, #0x13ca
    // 0x1274510: cmp             x0, x17
    // 0x1274514: b.ne            #0x1274528
    // 0x1274518: ldr             x1, [fp, #0x10]
    // 0x127451c: LoadField: r2 = r1->field_b
    //     0x127451c: ldur            w2, [x1, #0xb]
    // 0x1274520: DecompressPointer r2
    //     0x1274520: add             x2, x2, HEAP, lsl #32
    // 0x1274524: b               #0x1274598
    // 0x1274528: ldr             x1, [fp, #0x10]
    // 0x127452c: r17 = 5067
    //     0x127452c: mov             x17, #0x13cb
    // 0x1274530: cmp             x0, x17
    // 0x1274534: b.ne            #0x127457c
    // 0x1274538: r1 = 1
    //     0x1274538: mov             x1, #1
    // 0x127453c: r0 = AllocateContext()
    //     0x127453c: bl              #0x13de838  ; AllocateContextStub
    // 0x1274540: ldr             x1, [fp, #0x10]
    // 0x1274544: stur            x0, [fp, #-0x18]
    // 0x1274548: StoreField: r0->field_f = r1
    //     0x1274548: stur            w1, [x0, #0xf]
    // 0x127454c: r0 = _WidgetStateColor()
    //     0x127454c: bl              #0xd29244  ; Allocate_WidgetStateColorStub -> _WidgetStateColor (size=0x30)
    // 0x1274550: ldur            x2, [fp, #-0x18]
    // 0x1274554: r1 = Function '<anonymous closure>':.
    //     0x1274554: add             x1, PP, #0x26, lsl #12  ; [pp+0x26208] AnonymousClosure: (0x11376ac), of [package:flutter/src/material/snack_bar.dart] _SnackbarDefaultsM3
    //     0x1274558: ldr             x1, [x1, #0x208]
    // 0x127455c: stur            x0, [fp, #-0x18]
    // 0x1274560: r0 = AllocateClosure()
    //     0x1274560: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1274564: ldur            x1, [fp, #-0x18]
    // 0x1274568: mov             x2, x0
    // 0x127456c: r0 = _WidgetStateColor()
    //     0x127456c: bl              #0xd29128  ; [package:flutter/src/widgets/widget_state.dart] _WidgetStateColor::_WidgetStateColor
    // 0x1274570: ldur            x2, [fp, #-0x18]
    // 0x1274574: ldr             x1, [fp, #0x10]
    // 0x1274578: b               #0x1274598
    // 0x127457c: LoadField: r0 = r1->field_47
    //     0x127457c: ldur            w0, [x1, #0x47]
    // 0x1274580: DecompressPointer r0
    //     0x1274580: add             x0, x0, HEAP, lsl #32
    // 0x1274584: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1274588: cmp             w0, w16
    // 0x127458c: b.eq            #0x1275084
    // 0x1274590: LoadField: r2 = r0->field_2b
    //     0x1274590: ldur            w2, [x0, #0x2b]
    // 0x1274594: DecompressPointer r2
    //     0x1274594: add             x2, x2, HEAP, lsl #32
    // 0x1274598: ldur            x0, [fp, #-0x10]
    // 0x127459c: stur            x2, [fp, #-0x18]
    // 0x12745a0: r17 = 5066
    //     0x12745a0: mov             x17, #0x13ca
    // 0x12745a4: cmp             x0, x17
    // 0x12745a8: b.ne            #0x12745c8
    // 0x12745ac: ldr             x3, [fp, #0x18]
    // 0x12745b0: LoadField: r4 = r3->field_b
    //     0x12745b0: ldur            w4, [x3, #0xb]
    // 0x12745b4: DecompressPointer r4
    //     0x12745b4: add             x4, x4, HEAP, lsl #32
    // 0x12745b8: mov             x0, x2
    // 0x12745bc: mov             x2, x4
    // 0x12745c0: mov             x1, x3
    // 0x12745c4: b               #0x1274644
    // 0x12745c8: ldr             x3, [fp, #0x18]
    // 0x12745cc: r17 = 5067
    //     0x12745cc: mov             x17, #0x13cb
    // 0x12745d0: cmp             x0, x17
    // 0x12745d4: b.ne            #0x1274620
    // 0x12745d8: r1 = 1
    //     0x12745d8: mov             x1, #1
    // 0x12745dc: r0 = AllocateContext()
    //     0x12745dc: bl              #0x13de838  ; AllocateContextStub
    // 0x12745e0: ldr             x1, [fp, #0x18]
    // 0x12745e4: stur            x0, [fp, #-0x20]
    // 0x12745e8: StoreField: r0->field_f = r1
    //     0x12745e8: stur            w1, [x0, #0xf]
    // 0x12745ec: r0 = _WidgetStateColor()
    //     0x12745ec: bl              #0xd29244  ; Allocate_WidgetStateColorStub -> _WidgetStateColor (size=0x30)
    // 0x12745f0: ldur            x2, [fp, #-0x20]
    // 0x12745f4: r1 = Function '<anonymous closure>':.
    //     0x12745f4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26208] AnonymousClosure: (0x11376ac), of [package:flutter/src/material/snack_bar.dart] _SnackbarDefaultsM3
    //     0x12745f8: ldr             x1, [x1, #0x208]
    // 0x12745fc: stur            x0, [fp, #-0x20]
    // 0x1274600: r0 = AllocateClosure()
    //     0x1274600: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1274604: ldur            x1, [fp, #-0x20]
    // 0x1274608: mov             x2, x0
    // 0x127460c: r0 = _WidgetStateColor()
    //     0x127460c: bl              #0xd29128  ; [package:flutter/src/widgets/widget_state.dart] _WidgetStateColor::_WidgetStateColor
    // 0x1274610: ldur            x2, [fp, #-0x20]
    // 0x1274614: ldr             x1, [fp, #0x18]
    // 0x1274618: ldur            x0, [fp, #-0x18]
    // 0x127461c: b               #0x1274644
    // 0x1274620: mov             x1, x3
    // 0x1274624: LoadField: r0 = r1->field_47
    //     0x1274624: ldur            w0, [x1, #0x47]
    // 0x1274628: DecompressPointer r0
    //     0x1274628: add             x0, x0, HEAP, lsl #32
    // 0x127462c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1274630: cmp             w0, w16
    // 0x1274634: b.eq            #0x1275090
    // 0x1274638: LoadField: r2 = r0->field_2b
    //     0x1274638: ldur            w2, [x0, #0x2b]
    // 0x127463c: DecompressPointer r2
    //     0x127463c: add             x2, x2, HEAP, lsl #32
    // 0x1274640: ldur            x0, [fp, #-0x18]
    // 0x1274644: r3 = LoadClassIdInstr(r0)
    //     0x1274644: ldur            x3, [x0, #-1]
    //     0x1274648: ubfx            x3, x3, #0xc, #0x14
    // 0x127464c: stp             x2, x0, [SP]
    // 0x1274650: mov             x0, x3
    // 0x1274654: mov             lr, x0
    // 0x1274658: ldr             lr, [x21, lr, lsl #3]
    // 0x127465c: blr             lr
    // 0x1274660: tbnz            w0, #4, #0x127506c
    // 0x1274664: ldur            x0, [fp, #-8]
    // 0x1274668: r17 = 5066
    //     0x1274668: mov             x17, #0x13ca
    // 0x127466c: cmp             x0, x17
    // 0x1274670: b.ne            #0x1274688
    // 0x1274674: ldr             x2, [fp, #0x10]
    // 0x1274678: LoadField: r1 = r2->field_f
    //     0x1274678: ldur            w1, [x2, #0xf]
    // 0x127467c: DecompressPointer r1
    //     0x127467c: add             x1, x1, HEAP, lsl #32
    // 0x1274680: mov             x2, x1
    // 0x1274684: b               #0x1274760
    // 0x1274688: ldr             x2, [fp, #0x10]
    // 0x127468c: r17 = 5067
    //     0x127468c: mov             x17, #0x13cb
    // 0x1274690: cmp             x0, x17
    // 0x1274694: b.ne            #0x12746e8
    // 0x1274698: mov             x1, x2
    // 0x127469c: LoadField: r0 = r1->field_4b
    //     0x127469c: ldur            w0, [x1, #0x4b]
    // 0x12746a0: DecompressPointer r0
    //     0x12746a0: add             x0, x0, HEAP, lsl #32
    // 0x12746a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12746a8: cmp             w0, w16
    // 0x12746ac: b.ne            #0x12746bc
    // 0x12746b0: r2 = _colors
    //     0x12746b0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26200] Field <_SnackbarDefaultsM3@773267081._colors@773267081>: late final (offset: 0x4c)
    //     0x12746b4: ldr             x2, [x2, #0x200]
    // 0x12746b8: r0 = InitLateFinalInstanceField()
    //     0x12746b8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12746bc: LoadField: r1 = r0->field_bf
    //     0x12746bc: ldur            w1, [x0, #0xbf]
    // 0x12746c0: DecompressPointer r1
    //     0x12746c0: add             x1, x1, HEAP, lsl #32
    // 0x12746c4: cmp             w1, NULL
    // 0x12746c8: b.ne            #0x12746dc
    // 0x12746cc: LoadField: r1 = r0->field_f
    //     0x12746cc: ldur            w1, [x0, #0xf]
    // 0x12746d0: DecompressPointer r1
    //     0x12746d0: add             x1, x1, HEAP, lsl #32
    // 0x12746d4: mov             x0, x1
    // 0x12746d8: b               #0x12746e0
    // 0x12746dc: mov             x0, x1
    // 0x12746e0: mov             x2, x0
    // 0x12746e4: b               #0x1274760
    // 0x12746e8: LoadField: r0 = r2->field_47
    //     0x12746e8: ldur            w0, [x2, #0x47]
    // 0x12746ec: DecompressPointer r0
    //     0x12746ec: add             x0, x0, HEAP, lsl #32
    // 0x12746f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12746f4: cmp             w0, w16
    // 0x12746f8: b.eq            #0x127509c
    // 0x12746fc: LoadField: r1 = r0->field_7f
    //     0x12746fc: ldur            w1, [x0, #0x7f]
    // 0x1274700: DecompressPointer r1
    //     0x1274700: add             x1, x1, HEAP, lsl #32
    // 0x1274704: LoadField: r0 = r2->field_43
    //     0x1274704: ldur            w0, [x2, #0x43]
    // 0x1274708: DecompressPointer r0
    //     0x1274708: add             x0, x0, HEAP, lsl #32
    // 0x127470c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1274710: cmp             w0, w16
    // 0x1274714: b.eq            #0x12750a8
    // 0x1274718: LoadField: r3 = r0->field_3f
    //     0x1274718: ldur            w3, [x0, #0x3f]
    // 0x127471c: DecompressPointer r3
    //     0x127471c: add             x3, x3, HEAP, lsl #32
    // 0x1274720: LoadField: r0 = r3->field_7
    //     0x1274720: ldur            w0, [x3, #7]
    // 0x1274724: DecompressPointer r0
    //     0x1274724: add             x0, x0, HEAP, lsl #32
    // 0x1274728: r16 = Instance_Brightness
    //     0x1274728: ldr             x16, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0x127472c: cmp             w0, w16
    // 0x1274730: b.ne            #0x1274740
    // 0x1274734: d0 = 0.380000
    //     0x1274734: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1274738: ldr             d0, [x17, #0x1f0]
    // 0x127473c: b               #0x1274748
    // 0x1274740: d0 = 0.300000
    //     0x1274740: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a88] IMM: double(0.3) from 0x3fd3333333333333
    //     0x1274744: ldr             d0, [x17, #0xa88]
    // 0x1274748: r0 = LoadClassIdInstr(r1)
    //     0x1274748: ldur            x0, [x1, #-1]
    //     0x127474c: ubfx            x0, x0, #0xc, #0x14
    // 0x1274750: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1274750: sub             lr, x0, #1, lsl #12
    //     0x1274754: ldr             lr, [x21, lr, lsl #3]
    //     0x1274758: blr             lr
    // 0x127475c: mov             x2, x0
    // 0x1274760: ldur            x0, [fp, #-0x10]
    // 0x1274764: stur            x2, [fp, #-0x18]
    // 0x1274768: r17 = 5066
    //     0x1274768: mov             x17, #0x13ca
    // 0x127476c: cmp             x0, x17
    // 0x1274770: b.ne            #0x1274788
    // 0x1274774: ldr             x3, [fp, #0x18]
    // 0x1274778: LoadField: r1 = r3->field_f
    //     0x1274778: ldur            w1, [x3, #0xf]
    // 0x127477c: DecompressPointer r1
    //     0x127477c: add             x1, x1, HEAP, lsl #32
    // 0x1274780: mov             x0, x2
    // 0x1274784: b               #0x127486c
    // 0x1274788: ldr             x3, [fp, #0x18]
    // 0x127478c: r17 = 5067
    //     0x127478c: mov             x17, #0x13cb
    // 0x1274790: cmp             x0, x17
    // 0x1274794: b.ne            #0x12747ec
    // 0x1274798: mov             x1, x3
    // 0x127479c: LoadField: r0 = r1->field_4b
    //     0x127479c: ldur            w0, [x1, #0x4b]
    // 0x12747a0: DecompressPointer r0
    //     0x12747a0: add             x0, x0, HEAP, lsl #32
    // 0x12747a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12747a8: cmp             w0, w16
    // 0x12747ac: b.ne            #0x12747bc
    // 0x12747b0: r2 = _colors
    //     0x12747b0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26200] Field <_SnackbarDefaultsM3@773267081._colors@773267081>: late final (offset: 0x4c)
    //     0x12747b4: ldr             x2, [x2, #0x200]
    // 0x12747b8: r0 = InitLateFinalInstanceField()
    //     0x12747b8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12747bc: LoadField: r1 = r0->field_bf
    //     0x12747bc: ldur            w1, [x0, #0xbf]
    // 0x12747c0: DecompressPointer r1
    //     0x12747c0: add             x1, x1, HEAP, lsl #32
    // 0x12747c4: cmp             w1, NULL
    // 0x12747c8: b.ne            #0x12747dc
    // 0x12747cc: LoadField: r1 = r0->field_f
    //     0x12747cc: ldur            w1, [x0, #0xf]
    // 0x12747d0: DecompressPointer r1
    //     0x12747d0: add             x1, x1, HEAP, lsl #32
    // 0x12747d4: mov             x0, x1
    // 0x12747d8: b               #0x12747e0
    // 0x12747dc: mov             x0, x1
    // 0x12747e0: mov             x1, x0
    // 0x12747e4: ldur            x0, [fp, #-0x18]
    // 0x12747e8: b               #0x127486c
    // 0x12747ec: mov             x2, x3
    // 0x12747f0: LoadField: r0 = r2->field_47
    //     0x12747f0: ldur            w0, [x2, #0x47]
    // 0x12747f4: DecompressPointer r0
    //     0x12747f4: add             x0, x0, HEAP, lsl #32
    // 0x12747f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12747fc: cmp             w0, w16
    // 0x1274800: b.eq            #0x12750b4
    // 0x1274804: LoadField: r1 = r0->field_7f
    //     0x1274804: ldur            w1, [x0, #0x7f]
    // 0x1274808: DecompressPointer r1
    //     0x1274808: add             x1, x1, HEAP, lsl #32
    // 0x127480c: LoadField: r0 = r2->field_43
    //     0x127480c: ldur            w0, [x2, #0x43]
    // 0x1274810: DecompressPointer r0
    //     0x1274810: add             x0, x0, HEAP, lsl #32
    // 0x1274814: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1274818: cmp             w0, w16
    // 0x127481c: b.eq            #0x12750c0
    // 0x1274820: LoadField: r3 = r0->field_3f
    //     0x1274820: ldur            w3, [x0, #0x3f]
    // 0x1274824: DecompressPointer r3
    //     0x1274824: add             x3, x3, HEAP, lsl #32
    // 0x1274828: LoadField: r0 = r3->field_7
    //     0x1274828: ldur            w0, [x3, #7]
    // 0x127482c: DecompressPointer r0
    //     0x127482c: add             x0, x0, HEAP, lsl #32
    // 0x1274830: r16 = Instance_Brightness
    //     0x1274830: ldr             x16, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0x1274834: cmp             w0, w16
    // 0x1274838: b.ne            #0x1274848
    // 0x127483c: d0 = 0.380000
    //     0x127483c: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1274840: ldr             d0, [x17, #0x1f0]
    // 0x1274844: b               #0x1274850
    // 0x1274848: d0 = 0.300000
    //     0x1274848: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a88] IMM: double(0.3) from 0x3fd3333333333333
    //     0x127484c: ldr             d0, [x17, #0xa88]
    // 0x1274850: r0 = LoadClassIdInstr(r1)
    //     0x1274850: ldur            x0, [x1, #-1]
    //     0x1274854: ubfx            x0, x0, #0xc, #0x14
    // 0x1274858: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1274858: sub             lr, x0, #1, lsl #12
    //     0x127485c: ldr             lr, [x21, lr, lsl #3]
    //     0x1274860: blr             lr
    // 0x1274864: mov             x1, x0
    // 0x1274868: ldur            x0, [fp, #-0x18]
    // 0x127486c: r2 = LoadClassIdInstr(r0)
    //     0x127486c: ldur            x2, [x0, #-1]
    //     0x1274870: ubfx            x2, x2, #0xc, #0x14
    // 0x1274874: stp             x1, x0, [SP]
    // 0x1274878: mov             x0, x2
    // 0x127487c: mov             lr, x0
    // 0x1274880: ldr             lr, [x21, lr, lsl #3]
    // 0x1274884: blr             lr
    // 0x1274888: tbnz            w0, #4, #0x127506c
    // 0x127488c: ldur            x0, [fp, #-8]
    // 0x1274890: r17 = 5066
    //     0x1274890: mov             x17, #0x13ca
    // 0x1274894: cmp             x0, x17
    // 0x1274898: b.ne            #0x12748b0
    // 0x127489c: ldr             x2, [fp, #0x10]
    // 0x12748a0: LoadField: r1 = r2->field_13
    //     0x12748a0: ldur            w1, [x2, #0x13]
    // 0x12748a4: DecompressPointer r1
    //     0x12748a4: add             x1, x1, HEAP, lsl #32
    // 0x12748a8: mov             x2, x1
    // 0x12748ac: b               #0x12749bc
    // 0x12748b0: ldr             x2, [fp, #0x10]
    // 0x12748b4: r17 = 5067
    //     0x12748b4: mov             x17, #0x13cb
    // 0x12748b8: cmp             x0, x17
    // 0x12748bc: b.ne            #0x127494c
    // 0x12748c0: LoadField: r1 = r2->field_43
    //     0x12748c0: ldur            w1, [x2, #0x43]
    // 0x12748c4: DecompressPointer r1
    //     0x12748c4: add             x1, x1, HEAP, lsl #32
    // 0x12748c8: r0 = of()
    //     0x12748c8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x12748cc: LoadField: r1 = r0->field_87
    //     0x12748cc: ldur            w1, [x0, #0x87]
    // 0x12748d0: DecompressPointer r1
    //     0x12748d0: add             x1, x1, HEAP, lsl #32
    // 0x12748d4: LoadField: r0 = r1->field_2f
    //     0x12748d4: ldur            w0, [x1, #0x2f]
    // 0x12748d8: DecompressPointer r0
    //     0x12748d8: add             x0, x0, HEAP, lsl #32
    // 0x12748dc: stur            x0, [fp, #-0x18]
    // 0x12748e0: cmp             w0, NULL
    // 0x12748e4: b.eq            #0x12750cc
    // 0x12748e8: ldr             x1, [fp, #0x10]
    // 0x12748ec: LoadField: r0 = r1->field_4b
    //     0x12748ec: ldur            w0, [x1, #0x4b]
    // 0x12748f0: DecompressPointer r0
    //     0x12748f0: add             x0, x0, HEAP, lsl #32
    // 0x12748f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12748f8: cmp             w0, w16
    // 0x12748fc: b.ne            #0x127490c
    // 0x1274900: r2 = _colors
    //     0x1274900: add             x2, PP, #0x26, lsl #12  ; [pp+0x26200] Field <_SnackbarDefaultsM3@773267081._colors@773267081>: late final (offset: 0x4c)
    //     0x1274904: ldr             x2, [x2, #0x200]
    // 0x1274908: r0 = InitLateFinalInstanceField()
    //     0x1274908: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x127490c: LoadField: r1 = r0->field_bb
    //     0x127490c: ldur            w1, [x0, #0xbb]
    // 0x1274910: DecompressPointer r1
    //     0x1274910: add             x1, x1, HEAP, lsl #32
    // 0x1274914: cmp             w1, NULL
    // 0x1274918: b.ne            #0x127492c
    // 0x127491c: LoadField: r1 = r0->field_7b
    //     0x127491c: ldur            w1, [x0, #0x7b]
    // 0x1274920: DecompressPointer r1
    //     0x1274920: add             x1, x1, HEAP, lsl #32
    // 0x1274924: mov             x0, x1
    // 0x1274928: b               #0x1274930
    // 0x127492c: mov             x0, x1
    // 0x1274930: str             x0, [SP]
    // 0x1274934: ldur            x1, [fp, #-0x18]
    // 0x1274938: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x1274938: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x127493c: ldr             x4, [x4, #0x7f0]
    // 0x1274940: r0 = copyWith()
    //     0x1274940: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x1274944: mov             x2, x0
    // 0x1274948: b               #0x12749bc
    // 0x127494c: mov             x0, x2
    // 0x1274950: LoadField: r1 = r0->field_43
    //     0x1274950: ldur            w1, [x0, #0x43]
    // 0x1274954: DecompressPointer r1
    //     0x1274954: add             x1, x1, HEAP, lsl #32
    // 0x1274958: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x127495c: cmp             w1, w16
    // 0x1274960: b.eq            #0x12750d0
    // 0x1274964: LoadField: r2 = r1->field_2f
    //     0x1274964: ldur            w2, [x1, #0x2f]
    // 0x1274968: DecompressPointer r2
    //     0x1274968: add             x2, x2, HEAP, lsl #32
    // 0x127496c: LoadField: r3 = r1->field_3f
    //     0x127496c: ldur            w3, [x1, #0x3f]
    // 0x1274970: DecompressPointer r3
    //     0x1274970: add             x3, x3, HEAP, lsl #32
    // 0x1274974: LoadField: r1 = r3->field_7
    //     0x1274974: ldur            w1, [x3, #7]
    // 0x1274978: DecompressPointer r1
    //     0x1274978: add             x1, x1, HEAP, lsl #32
    // 0x127497c: r16 = Instance_Brightness
    //     0x127497c: ldr             x16, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0x1274980: cmp             w1, w16
    // 0x1274984: b.ne            #0x1274990
    // 0x1274988: r1 = Instance_Brightness
    //     0x1274988: ldr             x1, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x127498c: b               #0x1274994
    // 0x1274990: r1 = Instance_Brightness
    //     0x1274990: ldr             x1, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0x1274994: stp             x1, x2, [SP]
    // 0x1274998: r1 = Null
    //     0x1274998: mov             x1, NULL
    // 0x127499c: r4 = const [0, 0x3, 0x2, 0x1, brightness, 0x2, useMaterial3, 0x1, null]
    //     0x127499c: add             x4, PP, #0x26, lsl #12  ; [pp+0x26210] List(9) [0, 0x3, 0x2, 0x1, "brightness", 0x2, "useMaterial3", 0x1, Null]
    //     0x12749a0: ldr             x4, [x4, #0x210]
    // 0x12749a4: r0 = ThemeData()
    //     0x12749a4: bl              #0x8a9c18  ; [package:flutter/src/material/theme_data.dart] ThemeData::ThemeData
    // 0x12749a8: LoadField: r1 = r0->field_87
    //     0x12749a8: ldur            w1, [x0, #0x87]
    // 0x12749ac: DecompressPointer r1
    //     0x12749ac: add             x1, x1, HEAP, lsl #32
    // 0x12749b0: LoadField: r0 = r1->field_23
    //     0x12749b0: ldur            w0, [x1, #0x23]
    // 0x12749b4: DecompressPointer r0
    //     0x12749b4: add             x0, x0, HEAP, lsl #32
    // 0x12749b8: mov             x2, x0
    // 0x12749bc: ldur            x0, [fp, #-0x10]
    // 0x12749c0: stur            x2, [fp, #-0x18]
    // 0x12749c4: r17 = 5066
    //     0x12749c4: mov             x17, #0x13ca
    // 0x12749c8: cmp             x0, x17
    // 0x12749cc: b.ne            #0x12749e4
    // 0x12749d0: ldr             x3, [fp, #0x18]
    // 0x12749d4: LoadField: r1 = r3->field_13
    //     0x12749d4: ldur            w1, [x3, #0x13]
    // 0x12749d8: DecompressPointer r1
    //     0x12749d8: add             x1, x1, HEAP, lsl #32
    // 0x12749dc: mov             x0, x2
    // 0x12749e0: b               #0x1274af8
    // 0x12749e4: ldr             x3, [fp, #0x18]
    // 0x12749e8: r17 = 5067
    //     0x12749e8: mov             x17, #0x13cb
    // 0x12749ec: cmp             x0, x17
    // 0x12749f0: b.ne            #0x1274a84
    // 0x12749f4: LoadField: r1 = r3->field_43
    //     0x12749f4: ldur            w1, [x3, #0x43]
    // 0x12749f8: DecompressPointer r1
    //     0x12749f8: add             x1, x1, HEAP, lsl #32
    // 0x12749fc: r0 = of()
    //     0x12749fc: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1274a00: LoadField: r1 = r0->field_87
    //     0x1274a00: ldur            w1, [x0, #0x87]
    // 0x1274a04: DecompressPointer r1
    //     0x1274a04: add             x1, x1, HEAP, lsl #32
    // 0x1274a08: LoadField: r0 = r1->field_2f
    //     0x1274a08: ldur            w0, [x1, #0x2f]
    // 0x1274a0c: DecompressPointer r0
    //     0x1274a0c: add             x0, x0, HEAP, lsl #32
    // 0x1274a10: stur            x0, [fp, #-0x20]
    // 0x1274a14: cmp             w0, NULL
    // 0x1274a18: b.eq            #0x12750dc
    // 0x1274a1c: ldr             x1, [fp, #0x18]
    // 0x1274a20: LoadField: r0 = r1->field_4b
    //     0x1274a20: ldur            w0, [x1, #0x4b]
    // 0x1274a24: DecompressPointer r0
    //     0x1274a24: add             x0, x0, HEAP, lsl #32
    // 0x1274a28: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1274a2c: cmp             w0, w16
    // 0x1274a30: b.ne            #0x1274a40
    // 0x1274a34: r2 = _colors
    //     0x1274a34: add             x2, PP, #0x26, lsl #12  ; [pp+0x26200] Field <_SnackbarDefaultsM3@773267081._colors@773267081>: late final (offset: 0x4c)
    //     0x1274a38: ldr             x2, [x2, #0x200]
    // 0x1274a3c: r0 = InitLateFinalInstanceField()
    //     0x1274a3c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1274a40: LoadField: r1 = r0->field_bb
    //     0x1274a40: ldur            w1, [x0, #0xbb]
    // 0x1274a44: DecompressPointer r1
    //     0x1274a44: add             x1, x1, HEAP, lsl #32
    // 0x1274a48: cmp             w1, NULL
    // 0x1274a4c: b.ne            #0x1274a60
    // 0x1274a50: LoadField: r1 = r0->field_7b
    //     0x1274a50: ldur            w1, [x0, #0x7b]
    // 0x1274a54: DecompressPointer r1
    //     0x1274a54: add             x1, x1, HEAP, lsl #32
    // 0x1274a58: mov             x0, x1
    // 0x1274a5c: b               #0x1274a64
    // 0x1274a60: mov             x0, x1
    // 0x1274a64: str             x0, [SP]
    // 0x1274a68: ldur            x1, [fp, #-0x20]
    // 0x1274a6c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x1274a6c: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x1274a70: ldr             x4, [x4, #0x7f0]
    // 0x1274a74: r0 = copyWith()
    //     0x1274a74: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x1274a78: mov             x1, x0
    // 0x1274a7c: ldur            x0, [fp, #-0x18]
    // 0x1274a80: b               #0x1274af8
    // 0x1274a84: mov             x0, x3
    // 0x1274a88: LoadField: r1 = r0->field_43
    //     0x1274a88: ldur            w1, [x0, #0x43]
    // 0x1274a8c: DecompressPointer r1
    //     0x1274a8c: add             x1, x1, HEAP, lsl #32
    // 0x1274a90: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1274a94: cmp             w1, w16
    // 0x1274a98: b.eq            #0x12750e0
    // 0x1274a9c: LoadField: r2 = r1->field_2f
    //     0x1274a9c: ldur            w2, [x1, #0x2f]
    // 0x1274aa0: DecompressPointer r2
    //     0x1274aa0: add             x2, x2, HEAP, lsl #32
    // 0x1274aa4: LoadField: r3 = r1->field_3f
    //     0x1274aa4: ldur            w3, [x1, #0x3f]
    // 0x1274aa8: DecompressPointer r3
    //     0x1274aa8: add             x3, x3, HEAP, lsl #32
    // 0x1274aac: LoadField: r1 = r3->field_7
    //     0x1274aac: ldur            w1, [x3, #7]
    // 0x1274ab0: DecompressPointer r1
    //     0x1274ab0: add             x1, x1, HEAP, lsl #32
    // 0x1274ab4: r16 = Instance_Brightness
    //     0x1274ab4: ldr             x16, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0x1274ab8: cmp             w1, w16
    // 0x1274abc: b.ne            #0x1274ac8
    // 0x1274ac0: r1 = Instance_Brightness
    //     0x1274ac0: ldr             x1, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x1274ac4: b               #0x1274acc
    // 0x1274ac8: r1 = Instance_Brightness
    //     0x1274ac8: ldr             x1, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0x1274acc: stp             x1, x2, [SP]
    // 0x1274ad0: r1 = Null
    //     0x1274ad0: mov             x1, NULL
    // 0x1274ad4: r4 = const [0, 0x3, 0x2, 0x1, brightness, 0x2, useMaterial3, 0x1, null]
    //     0x1274ad4: add             x4, PP, #0x26, lsl #12  ; [pp+0x26210] List(9) [0, 0x3, 0x2, 0x1, "brightness", 0x2, "useMaterial3", 0x1, Null]
    //     0x1274ad8: ldr             x4, [x4, #0x210]
    // 0x1274adc: r0 = ThemeData()
    //     0x1274adc: bl              #0x8a9c18  ; [package:flutter/src/material/theme_data.dart] ThemeData::ThemeData
    // 0x1274ae0: LoadField: r1 = r0->field_87
    //     0x1274ae0: ldur            w1, [x0, #0x87]
    // 0x1274ae4: DecompressPointer r1
    //     0x1274ae4: add             x1, x1, HEAP, lsl #32
    // 0x1274ae8: LoadField: r0 = r1->field_23
    //     0x1274ae8: ldur            w0, [x1, #0x23]
    // 0x1274aec: DecompressPointer r0
    //     0x1274aec: add             x0, x0, HEAP, lsl #32
    // 0x1274af0: mov             x1, x0
    // 0x1274af4: ldur            x0, [fp, #-0x18]
    // 0x1274af8: r2 = LoadClassIdInstr(r0)
    //     0x1274af8: ldur            x2, [x0, #-1]
    //     0x1274afc: ubfx            x2, x2, #0xc, #0x14
    // 0x1274b00: stp             x1, x0, [SP]
    // 0x1274b04: mov             x0, x2
    // 0x1274b08: mov             lr, x0
    // 0x1274b0c: ldr             lr, [x21, lr, lsl #3]
    // 0x1274b10: blr             lr
    // 0x1274b14: tbnz            w0, #4, #0x127506c
    // 0x1274b18: ldur            x1, [fp, #-8]
    // 0x1274b1c: r17 = 5066
    //     0x1274b1c: mov             x17, #0x13ca
    // 0x1274b20: cmp             x1, x17
    // 0x1274b24: b.eq            #0x1274b44
    // 0x1274b28: r17 = 5067
    //     0x1274b28: mov             x17, #0x13cb
    // 0x1274b2c: cmp             x1, x17
    // 0x1274b30: b.ne            #0x1274b44
    // 0x1274b34: ldr             x2, [fp, #0x10]
    // 0x1274b38: r0 = 6.000000
    //     0x1274b38: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c438] 6
    //     0x1274b3c: ldr             x0, [x0, #0x438]
    // 0x1274b40: b               #0x1274b50
    // 0x1274b44: ldr             x2, [fp, #0x10]
    // 0x1274b48: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x1274b48: ldur            w0, [x2, #0x17]
    // 0x1274b4c: DecompressPointer r0
    //     0x1274b4c: add             x0, x0, HEAP, lsl #32
    // 0x1274b50: ldur            x3, [fp, #-0x10]
    // 0x1274b54: r17 = 5066
    //     0x1274b54: mov             x17, #0x13ca
    // 0x1274b58: cmp             x3, x17
    // 0x1274b5c: b.eq            #0x1274b7c
    // 0x1274b60: r17 = 5067
    //     0x1274b60: mov             x17, #0x13cb
    // 0x1274b64: cmp             x3, x17
    // 0x1274b68: b.ne            #0x1274b7c
    // 0x1274b6c: ldr             x4, [fp, #0x18]
    // 0x1274b70: r5 = 6.000000
    //     0x1274b70: add             x5, PP, #0x1c, lsl #12  ; [pp+0x1c438] 6
    //     0x1274b74: ldr             x5, [x5, #0x438]
    // 0x1274b78: b               #0x1274b88
    // 0x1274b7c: ldr             x4, [fp, #0x18]
    // 0x1274b80: ArrayLoad: r5 = r4[0]  ; List_4
    //     0x1274b80: ldur            w5, [x4, #0x17]
    // 0x1274b84: DecompressPointer r5
    //     0x1274b84: add             x5, x5, HEAP, lsl #32
    // 0x1274b88: r6 = LoadClassIdInstr(r0)
    //     0x1274b88: ldur            x6, [x0, #-1]
    //     0x1274b8c: ubfx            x6, x6, #0xc, #0x14
    // 0x1274b90: stp             x5, x0, [SP]
    // 0x1274b94: mov             x0, x6
    // 0x1274b98: mov             lr, x0
    // 0x1274b9c: ldr             lr, [x21, lr, lsl #3]
    // 0x1274ba0: blr             lr
    // 0x1274ba4: tbnz            w0, #4, #0x127506c
    // 0x1274ba8: ldur            x1, [fp, #-8]
    // 0x1274bac: r17 = 5066
    //     0x1274bac: mov             x17, #0x13ca
    // 0x1274bb0: cmp             x1, x17
    // 0x1274bb4: b.ne            #0x1274bc8
    // 0x1274bb8: ldr             x2, [fp, #0x10]
    // 0x1274bbc: LoadField: r0 = r2->field_1b
    //     0x1274bbc: ldur            w0, [x2, #0x1b]
    // 0x1274bc0: DecompressPointer r0
    //     0x1274bc0: add             x0, x0, HEAP, lsl #32
    // 0x1274bc4: b               #0x1274bec
    // 0x1274bc8: ldr             x2, [fp, #0x10]
    // 0x1274bcc: r17 = 5067
    //     0x1274bcc: mov             x17, #0x13cb
    // 0x1274bd0: cmp             x1, x17
    // 0x1274bd4: b.ne            #0x1274be4
    // 0x1274bd8: r0 = Instance_RoundedRectangleBorder
    //     0x1274bd8: add             x0, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0x1274bdc: ldr             x0, [x0, #0x218]
    // 0x1274be0: b               #0x1274bec
    // 0x1274be4: r0 = Instance_RoundedRectangleBorder
    //     0x1274be4: add             x0, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0x1274be8: ldr             x0, [x0, #0x218]
    // 0x1274bec: ldur            x3, [fp, #-0x10]
    // 0x1274bf0: r17 = 5066
    //     0x1274bf0: mov             x17, #0x13ca
    // 0x1274bf4: cmp             x3, x17
    // 0x1274bf8: b.ne            #0x1274c0c
    // 0x1274bfc: ldr             x4, [fp, #0x18]
    // 0x1274c00: LoadField: r5 = r4->field_1b
    //     0x1274c00: ldur            w5, [x4, #0x1b]
    // 0x1274c04: DecompressPointer r5
    //     0x1274c04: add             x5, x5, HEAP, lsl #32
    // 0x1274c08: b               #0x1274c30
    // 0x1274c0c: ldr             x4, [fp, #0x18]
    // 0x1274c10: r17 = 5067
    //     0x1274c10: mov             x17, #0x13cb
    // 0x1274c14: cmp             x3, x17
    // 0x1274c18: b.ne            #0x1274c28
    // 0x1274c1c: r5 = Instance_RoundedRectangleBorder
    //     0x1274c1c: add             x5, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0x1274c20: ldr             x5, [x5, #0x218]
    // 0x1274c24: b               #0x1274c30
    // 0x1274c28: r5 = Instance_RoundedRectangleBorder
    //     0x1274c28: add             x5, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0x1274c2c: ldr             x5, [x5, #0x218]
    // 0x1274c30: r6 = LoadClassIdInstr(r0)
    //     0x1274c30: ldur            x6, [x0, #-1]
    //     0x1274c34: ubfx            x6, x6, #0xc, #0x14
    // 0x1274c38: stp             x5, x0, [SP]
    // 0x1274c3c: mov             x0, x6
    // 0x1274c40: mov             lr, x0
    // 0x1274c44: ldr             lr, [x21, lr, lsl #3]
    // 0x1274c48: blr             lr
    // 0x1274c4c: tbnz            w0, #4, #0x127506c
    // 0x1274c50: ldur            x1, [fp, #-8]
    // 0x1274c54: r17 = 5066
    //     0x1274c54: mov             x17, #0x13ca
    // 0x1274c58: cmp             x1, x17
    // 0x1274c5c: b.ne            #0x1274c70
    // 0x1274c60: ldr             x2, [fp, #0x10]
    // 0x1274c64: LoadField: r0 = r2->field_1f
    //     0x1274c64: ldur            w0, [x2, #0x1f]
    // 0x1274c68: DecompressPointer r0
    //     0x1274c68: add             x0, x0, HEAP, lsl #32
    // 0x1274c6c: b               #0x1274c94
    // 0x1274c70: ldr             x2, [fp, #0x10]
    // 0x1274c74: r17 = 5067
    //     0x1274c74: mov             x17, #0x13cb
    // 0x1274c78: cmp             x1, x17
    // 0x1274c7c: b.ne            #0x1274c8c
    // 0x1274c80: r0 = Instance_SnackBarBehavior
    //     0x1274c80: add             x0, PP, #0x26, lsl #12  ; [pp+0x26220] Obj!SnackBarBehavior@12c4d61
    //     0x1274c84: ldr             x0, [x0, #0x220]
    // 0x1274c88: b               #0x1274c94
    // 0x1274c8c: r0 = Instance_SnackBarBehavior
    //     0x1274c8c: add             x0, PP, #0x26, lsl #12  ; [pp+0x26220] Obj!SnackBarBehavior@12c4d61
    //     0x1274c90: ldr             x0, [x0, #0x220]
    // 0x1274c94: ldur            x3, [fp, #-0x10]
    // 0x1274c98: r17 = 5066
    //     0x1274c98: mov             x17, #0x13ca
    // 0x1274c9c: cmp             x3, x17
    // 0x1274ca0: b.ne            #0x1274cb4
    // 0x1274ca4: ldr             x4, [fp, #0x18]
    // 0x1274ca8: LoadField: r5 = r4->field_1f
    //     0x1274ca8: ldur            w5, [x4, #0x1f]
    // 0x1274cac: DecompressPointer r5
    //     0x1274cac: add             x5, x5, HEAP, lsl #32
    // 0x1274cb0: b               #0x1274cd8
    // 0x1274cb4: ldr             x4, [fp, #0x18]
    // 0x1274cb8: r17 = 5067
    //     0x1274cb8: mov             x17, #0x13cb
    // 0x1274cbc: cmp             x3, x17
    // 0x1274cc0: b.ne            #0x1274cd0
    // 0x1274cc4: r5 = Instance_SnackBarBehavior
    //     0x1274cc4: add             x5, PP, #0x26, lsl #12  ; [pp+0x26220] Obj!SnackBarBehavior@12c4d61
    //     0x1274cc8: ldr             x5, [x5, #0x220]
    // 0x1274ccc: b               #0x1274cd8
    // 0x1274cd0: r5 = Instance_SnackBarBehavior
    //     0x1274cd0: add             x5, PP, #0x26, lsl #12  ; [pp+0x26220] Obj!SnackBarBehavior@12c4d61
    //     0x1274cd4: ldr             x5, [x5, #0x220]
    // 0x1274cd8: cmp             w0, w5
    // 0x1274cdc: b.ne            #0x127506c
    // 0x1274ce0: LoadField: r0 = r2->field_23
    //     0x1274ce0: ldur            w0, [x2, #0x23]
    // 0x1274ce4: DecompressPointer r0
    //     0x1274ce4: add             x0, x0, HEAP, lsl #32
    // 0x1274ce8: LoadField: r5 = r4->field_23
    //     0x1274ce8: ldur            w5, [x4, #0x23]
    // 0x1274cec: DecompressPointer r5
    //     0x1274cec: add             x5, x5, HEAP, lsl #32
    // 0x1274cf0: r6 = LoadClassIdInstr(r0)
    //     0x1274cf0: ldur            x6, [x0, #-1]
    //     0x1274cf4: ubfx            x6, x6, #0xc, #0x14
    // 0x1274cf8: stp             x5, x0, [SP]
    // 0x1274cfc: mov             x0, x6
    // 0x1274d00: mov             lr, x0
    // 0x1274d04: ldr             lr, [x21, lr, lsl #3]
    // 0x1274d08: blr             lr
    // 0x1274d0c: tbnz            w0, #4, #0x127506c
    // 0x1274d10: ldur            x1, [fp, #-8]
    // 0x1274d14: r17 = 5066
    //     0x1274d14: mov             x17, #0x13ca
    // 0x1274d18: cmp             x1, x17
    // 0x1274d1c: b.ne            #0x1274d30
    // 0x1274d20: ldr             x2, [fp, #0x10]
    // 0x1274d24: LoadField: r0 = r2->field_27
    //     0x1274d24: ldur            w0, [x2, #0x27]
    // 0x1274d28: DecompressPointer r0
    //     0x1274d28: add             x0, x0, HEAP, lsl #32
    // 0x1274d2c: b               #0x1274d54
    // 0x1274d30: ldr             x2, [fp, #0x10]
    // 0x1274d34: r17 = 5067
    //     0x1274d34: mov             x17, #0x13cb
    // 0x1274d38: cmp             x1, x17
    // 0x1274d3c: b.ne            #0x1274d4c
    // 0x1274d40: r0 = Instance_EdgeInsets
    //     0x1274d40: add             x0, PP, #0x26, lsl #12  ; [pp+0x26228] Obj!EdgeInsets@129d681
    //     0x1274d44: ldr             x0, [x0, #0x228]
    // 0x1274d48: b               #0x1274d54
    // 0x1274d4c: r0 = Instance_EdgeInsets
    //     0x1274d4c: add             x0, PP, #0x26, lsl #12  ; [pp+0x26228] Obj!EdgeInsets@129d681
    //     0x1274d50: ldr             x0, [x0, #0x228]
    // 0x1274d54: ldur            x3, [fp, #-0x10]
    // 0x1274d58: r17 = 5066
    //     0x1274d58: mov             x17, #0x13ca
    // 0x1274d5c: cmp             x3, x17
    // 0x1274d60: b.ne            #0x1274d74
    // 0x1274d64: ldr             x4, [fp, #0x18]
    // 0x1274d68: LoadField: r5 = r4->field_27
    //     0x1274d68: ldur            w5, [x4, #0x27]
    // 0x1274d6c: DecompressPointer r5
    //     0x1274d6c: add             x5, x5, HEAP, lsl #32
    // 0x1274d70: b               #0x1274d98
    // 0x1274d74: ldr             x4, [fp, #0x18]
    // 0x1274d78: r17 = 5067
    //     0x1274d78: mov             x17, #0x13cb
    // 0x1274d7c: cmp             x3, x17
    // 0x1274d80: b.ne            #0x1274d90
    // 0x1274d84: r5 = Instance_EdgeInsets
    //     0x1274d84: add             x5, PP, #0x26, lsl #12  ; [pp+0x26228] Obj!EdgeInsets@129d681
    //     0x1274d88: ldr             x5, [x5, #0x228]
    // 0x1274d8c: b               #0x1274d98
    // 0x1274d90: r5 = Instance_EdgeInsets
    //     0x1274d90: add             x5, PP, #0x26, lsl #12  ; [pp+0x26228] Obj!EdgeInsets@129d681
    //     0x1274d94: ldr             x5, [x5, #0x228]
    // 0x1274d98: r6 = LoadClassIdInstr(r0)
    //     0x1274d98: ldur            x6, [x0, #-1]
    //     0x1274d9c: ubfx            x6, x6, #0xc, #0x14
    // 0x1274da0: stp             x5, x0, [SP]
    // 0x1274da4: mov             x0, x6
    // 0x1274da8: mov             lr, x0
    // 0x1274dac: ldr             lr, [x21, lr, lsl #3]
    // 0x1274db0: blr             lr
    // 0x1274db4: tbnz            w0, #4, #0x127506c
    // 0x1274db8: ldur            x0, [fp, #-8]
    // 0x1274dbc: r17 = 5066
    //     0x1274dbc: mov             x17, #0x13ca
    // 0x1274dc0: cmp             x0, x17
    // 0x1274dc4: b.ne            #0x1274dd8
    // 0x1274dc8: ldr             x2, [fp, #0x10]
    // 0x1274dcc: LoadField: r1 = r2->field_2b
    //     0x1274dcc: ldur            w1, [x2, #0x2b]
    // 0x1274dd0: DecompressPointer r1
    //     0x1274dd0: add             x1, x1, HEAP, lsl #32
    // 0x1274dd4: b               #0x1274df4
    // 0x1274dd8: ldr             x2, [fp, #0x10]
    // 0x1274ddc: r17 = 5067
    //     0x1274ddc: mov             x17, #0x13cb
    // 0x1274de0: cmp             x0, x17
    // 0x1274de4: b.ne            #0x1274df0
    // 0x1274de8: r1 = false
    //     0x1274de8: add             x1, NULL, #0x30  ; false
    // 0x1274dec: b               #0x1274df4
    // 0x1274df0: r1 = false
    //     0x1274df0: add             x1, NULL, #0x30  ; false
    // 0x1274df4: ldur            x3, [fp, #-0x10]
    // 0x1274df8: r17 = 5066
    //     0x1274df8: mov             x17, #0x13ca
    // 0x1274dfc: cmp             x3, x17
    // 0x1274e00: b.ne            #0x1274e14
    // 0x1274e04: ldr             x4, [fp, #0x18]
    // 0x1274e08: LoadField: r5 = r4->field_2b
    //     0x1274e08: ldur            w5, [x4, #0x2b]
    // 0x1274e0c: DecompressPointer r5
    //     0x1274e0c: add             x5, x5, HEAP, lsl #32
    // 0x1274e10: b               #0x1274e30
    // 0x1274e14: ldr             x4, [fp, #0x18]
    // 0x1274e18: r17 = 5067
    //     0x1274e18: mov             x17, #0x13cb
    // 0x1274e1c: cmp             x3, x17
    // 0x1274e20: b.ne            #0x1274e2c
    // 0x1274e24: r5 = false
    //     0x1274e24: add             x5, NULL, #0x30  ; false
    // 0x1274e28: b               #0x1274e30
    // 0x1274e2c: r5 = false
    //     0x1274e2c: add             x5, NULL, #0x30  ; false
    // 0x1274e30: cmp             w1, w5
    // 0x1274e34: b.ne            #0x127506c
    // 0x1274e38: r17 = 5066
    //     0x1274e38: mov             x17, #0x13ca
    // 0x1274e3c: cmp             x0, x17
    // 0x1274e40: b.ne            #0x1274e5c
    // 0x1274e44: LoadField: r1 = r2->field_2f
    //     0x1274e44: ldur            w1, [x2, #0x2f]
    // 0x1274e48: DecompressPointer r1
    //     0x1274e48: add             x1, x1, HEAP, lsl #32
    // 0x1274e4c: mov             x0, x2
    // 0x1274e50: mov             x2, x3
    // 0x1274e54: mov             x3, x1
    // 0x1274e58: b               #0x1274ee8
    // 0x1274e5c: r17 = 5067
    //     0x1274e5c: mov             x17, #0x13cb
    // 0x1274e60: cmp             x0, x17
    // 0x1274e64: b.ne            #0x1274ec0
    // 0x1274e68: mov             x1, x2
    // 0x1274e6c: LoadField: r0 = r1->field_4b
    //     0x1274e6c: ldur            w0, [x1, #0x4b]
    // 0x1274e70: DecompressPointer r0
    //     0x1274e70: add             x0, x0, HEAP, lsl #32
    // 0x1274e74: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1274e78: cmp             w0, w16
    // 0x1274e7c: b.ne            #0x1274e8c
    // 0x1274e80: r2 = _colors
    //     0x1274e80: add             x2, PP, #0x26, lsl #12  ; [pp+0x26200] Field <_SnackbarDefaultsM3@773267081._colors@773267081>: late final (offset: 0x4c)
    //     0x1274e84: ldr             x2, [x2, #0x200]
    // 0x1274e88: r0 = InitLateFinalInstanceField()
    //     0x1274e88: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1274e8c: LoadField: r1 = r0->field_bb
    //     0x1274e8c: ldur            w1, [x0, #0xbb]
    // 0x1274e90: DecompressPointer r1
    //     0x1274e90: add             x1, x1, HEAP, lsl #32
    // 0x1274e94: cmp             w1, NULL
    // 0x1274e98: b.ne            #0x1274eac
    // 0x1274e9c: LoadField: r1 = r0->field_7b
    //     0x1274e9c: ldur            w1, [x0, #0x7b]
    // 0x1274ea0: DecompressPointer r1
    //     0x1274ea0: add             x1, x1, HEAP, lsl #32
    // 0x1274ea4: mov             x0, x1
    // 0x1274ea8: b               #0x1274eb0
    // 0x1274eac: mov             x0, x1
    // 0x1274eb0: mov             x3, x0
    // 0x1274eb4: ldr             x0, [fp, #0x10]
    // 0x1274eb8: ldur            x2, [fp, #-0x10]
    // 0x1274ebc: b               #0x1274ee8
    // 0x1274ec0: mov             x0, x2
    // 0x1274ec4: LoadField: r1 = r0->field_47
    //     0x1274ec4: ldur            w1, [x0, #0x47]
    // 0x1274ec8: DecompressPointer r1
    //     0x1274ec8: add             x1, x1, HEAP, lsl #32
    // 0x1274ecc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1274ed0: cmp             w1, w16
    // 0x1274ed4: b.eq            #0x12750ec
    // 0x1274ed8: LoadField: r2 = r1->field_7f
    //     0x1274ed8: ldur            w2, [x1, #0x7f]
    // 0x1274edc: DecompressPointer r2
    //     0x1274edc: add             x2, x2, HEAP, lsl #32
    // 0x1274ee0: mov             x3, x2
    // 0x1274ee4: ldur            x2, [fp, #-0x10]
    // 0x1274ee8: stur            x3, [fp, #-0x18]
    // 0x1274eec: r17 = 5066
    //     0x1274eec: mov             x17, #0x13ca
    // 0x1274ef0: cmp             x2, x17
    // 0x1274ef4: b.ne            #0x1274f14
    // 0x1274ef8: ldr             x4, [fp, #0x18]
    // 0x1274efc: LoadField: r1 = r4->field_2f
    //     0x1274efc: ldur            w1, [x4, #0x2f]
    // 0x1274f00: DecompressPointer r1
    //     0x1274f00: add             x1, x1, HEAP, lsl #32
    // 0x1274f04: mov             x2, x1
    // 0x1274f08: mov             x1, x4
    // 0x1274f0c: mov             x0, x3
    // 0x1274f10: b               #0x1274fa0
    // 0x1274f14: ldr             x4, [fp, #0x18]
    // 0x1274f18: r17 = 5067
    //     0x1274f18: mov             x17, #0x13cb
    // 0x1274f1c: cmp             x2, x17
    // 0x1274f20: b.ne            #0x1274f7c
    // 0x1274f24: mov             x1, x4
    // 0x1274f28: LoadField: r0 = r1->field_4b
    //     0x1274f28: ldur            w0, [x1, #0x4b]
    // 0x1274f2c: DecompressPointer r0
    //     0x1274f2c: add             x0, x0, HEAP, lsl #32
    // 0x1274f30: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1274f34: cmp             w0, w16
    // 0x1274f38: b.ne            #0x1274f48
    // 0x1274f3c: r2 = _colors
    //     0x1274f3c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26200] Field <_SnackbarDefaultsM3@773267081._colors@773267081>: late final (offset: 0x4c)
    //     0x1274f40: ldr             x2, [x2, #0x200]
    // 0x1274f44: r0 = InitLateFinalInstanceField()
    //     0x1274f44: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1274f48: LoadField: r1 = r0->field_bb
    //     0x1274f48: ldur            w1, [x0, #0xbb]
    // 0x1274f4c: DecompressPointer r1
    //     0x1274f4c: add             x1, x1, HEAP, lsl #32
    // 0x1274f50: cmp             w1, NULL
    // 0x1274f54: b.ne            #0x1274f68
    // 0x1274f58: LoadField: r1 = r0->field_7b
    //     0x1274f58: ldur            w1, [x0, #0x7b]
    // 0x1274f5c: DecompressPointer r1
    //     0x1274f5c: add             x1, x1, HEAP, lsl #32
    // 0x1274f60: mov             x0, x1
    // 0x1274f64: b               #0x1274f6c
    // 0x1274f68: mov             x0, x1
    // 0x1274f6c: mov             x2, x0
    // 0x1274f70: ldr             x1, [fp, #0x18]
    // 0x1274f74: ldur            x0, [fp, #-0x18]
    // 0x1274f78: b               #0x1274fa0
    // 0x1274f7c: mov             x1, x4
    // 0x1274f80: LoadField: r0 = r1->field_47
    //     0x1274f80: ldur            w0, [x1, #0x47]
    // 0x1274f84: DecompressPointer r0
    //     0x1274f84: add             x0, x0, HEAP, lsl #32
    // 0x1274f88: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1274f8c: cmp             w0, w16
    // 0x1274f90: b.eq            #0x12750f8
    // 0x1274f94: LoadField: r2 = r0->field_7f
    //     0x1274f94: ldur            w2, [x0, #0x7f]
    // 0x1274f98: DecompressPointer r2
    //     0x1274f98: add             x2, x2, HEAP, lsl #32
    // 0x1274f9c: ldur            x0, [fp, #-0x18]
    // 0x1274fa0: r3 = LoadClassIdInstr(r0)
    //     0x1274fa0: ldur            x3, [x0, #-1]
    //     0x1274fa4: ubfx            x3, x3, #0xc, #0x14
    // 0x1274fa8: stp             x2, x0, [SP]
    // 0x1274fac: mov             x0, x3
    // 0x1274fb0: mov             lr, x0
    // 0x1274fb4: ldr             lr, [x21, lr, lsl #3]
    // 0x1274fb8: blr             lr
    // 0x1274fbc: tbnz            w0, #4, #0x127506c
    // 0x1274fc0: ldur            x0, [fp, #-8]
    // 0x1274fc4: r17 = 5066
    //     0x1274fc4: mov             x17, #0x13ca
    // 0x1274fc8: cmp             x0, x17
    // 0x1274fcc: b.ne            #0x1274fe0
    // 0x1274fd0: ldr             x0, [fp, #0x10]
    // 0x1274fd4: LoadField: r1 = r0->field_33
    //     0x1274fd4: ldur            w1, [x0, #0x33]
    // 0x1274fd8: DecompressPointer r1
    //     0x1274fd8: add             x1, x1, HEAP, lsl #32
    // 0x1274fdc: b               #0x1275000
    // 0x1274fe0: r17 = 5067
    //     0x1274fe0: mov             x17, #0x13cb
    // 0x1274fe4: cmp             x0, x17
    // 0x1274fe8: b.ne            #0x1274ff8
    // 0x1274fec: r1 = 0.250000
    //     0x1274fec: add             x1, PP, #0x12, lsl #12  ; [pp+0x12800] 0.25
    //     0x1274ff0: ldr             x1, [x1, #0x800]
    // 0x1274ff4: b               #0x1275000
    // 0x1274ff8: r1 = 0.250000
    //     0x1274ff8: add             x1, PP, #0x12, lsl #12  ; [pp+0x12800] 0.25
    //     0x1274ffc: ldr             x1, [x1, #0x800]
    // 0x1275000: ldur            x0, [fp, #-0x10]
    // 0x1275004: r17 = 5066
    //     0x1275004: mov             x17, #0x13ca
    // 0x1275008: cmp             x0, x17
    // 0x127500c: b.ne            #0x1275024
    // 0x1275010: ldr             x0, [fp, #0x18]
    // 0x1275014: LoadField: r2 = r0->field_33
    //     0x1275014: ldur            w2, [x0, #0x33]
    // 0x1275018: DecompressPointer r2
    //     0x1275018: add             x2, x2, HEAP, lsl #32
    // 0x127501c: mov             x0, x2
    // 0x1275020: b               #0x1275044
    // 0x1275024: r17 = 5067
    //     0x1275024: mov             x17, #0x13cb
    // 0x1275028: cmp             x0, x17
    // 0x127502c: b.ne            #0x127503c
    // 0x1275030: r0 = 0.250000
    //     0x1275030: add             x0, PP, #0x12, lsl #12  ; [pp+0x12800] 0.25
    //     0x1275034: ldr             x0, [x0, #0x800]
    // 0x1275038: b               #0x1275044
    // 0x127503c: r0 = 0.250000
    //     0x127503c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12800] 0.25
    //     0x1275040: ldr             x0, [x0, #0x800]
    // 0x1275044: r2 = LoadClassIdInstr(r1)
    //     0x1275044: ldur            x2, [x1, #-1]
    //     0x1275048: ubfx            x2, x2, #0xc, #0x14
    // 0x127504c: stp             x0, x1, [SP]
    // 0x1275050: mov             x0, x2
    // 0x1275054: mov             lr, x0
    // 0x1275058: ldr             lr, [x21, lr, lsl #3]
    // 0x127505c: blr             lr
    // 0x1275060: tbnz            w0, #4, #0x127506c
    // 0x1275064: r0 = true
    //     0x1275064: add             x0, NULL, #0x20  ; true
    // 0x1275068: b               #0x1275070
    // 0x127506c: r0 = false
    //     0x127506c: add             x0, NULL, #0x30  ; false
    // 0x1275070: LeaveFrame
    //     0x1275070: mov             SP, fp
    //     0x1275074: ldp             fp, lr, [SP], #0x10
    // 0x1275078: ret
    //     0x1275078: ret             
    // 0x127507c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x127507c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1275080: b               #0x1274320
    // 0x1275084: r9 = _colors
    //     0x1275084: add             x9, PP, #0x26, lsl #12  ; [pp+0x26230] Field <_SnackbarDefaultsM2@773267081._colors@773267081>: late final (offset: 0x48)
    //     0x1275088: ldr             x9, [x9, #0x230]
    // 0x127508c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x127508c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x1275090: r9 = _colors
    //     0x1275090: add             x9, PP, #0x26, lsl #12  ; [pp+0x26230] Field <_SnackbarDefaultsM2@773267081._colors@773267081>: late final (offset: 0x48)
    //     0x1275094: ldr             x9, [x9, #0x230]
    // 0x1275098: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1275098: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x127509c: r9 = _colors
    //     0x127509c: add             x9, PP, #0x26, lsl #12  ; [pp+0x26230] Field <_SnackbarDefaultsM2@773267081._colors@773267081>: late final (offset: 0x48)
    //     0x12750a0: ldr             x9, [x9, #0x230]
    // 0x12750a4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12750a4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12750a8: r9 = _theme
    //     0x12750a8: add             x9, PP, #0x26, lsl #12  ; [pp+0x26238] Field <_SnackbarDefaultsM2@773267081._theme@773267081>: late final (offset: 0x44)
    //     0x12750ac: ldr             x9, [x9, #0x238]
    // 0x12750b0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12750b0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12750b4: r9 = _colors
    //     0x12750b4: add             x9, PP, #0x26, lsl #12  ; [pp+0x26230] Field <_SnackbarDefaultsM2@773267081._colors@773267081>: late final (offset: 0x48)
    //     0x12750b8: ldr             x9, [x9, #0x230]
    // 0x12750bc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12750bc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12750c0: r9 = _theme
    //     0x12750c0: add             x9, PP, #0x26, lsl #12  ; [pp+0x26238] Field <_SnackbarDefaultsM2@773267081._theme@773267081>: late final (offset: 0x44)
    //     0x12750c4: ldr             x9, [x9, #0x238]
    // 0x12750c8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12750c8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12750cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12750cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12750d0: r9 = _theme
    //     0x12750d0: add             x9, PP, #0x26, lsl #12  ; [pp+0x26238] Field <_SnackbarDefaultsM2@773267081._theme@773267081>: late final (offset: 0x44)
    //     0x12750d4: ldr             x9, [x9, #0x238]
    // 0x12750d8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12750d8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12750dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12750dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12750e0: r9 = _theme
    //     0x12750e0: add             x9, PP, #0x26, lsl #12  ; [pp+0x26238] Field <_SnackbarDefaultsM2@773267081._theme@773267081>: late final (offset: 0x44)
    //     0x12750e4: ldr             x9, [x9, #0x238]
    // 0x12750e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12750e8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12750ec: r9 = _colors
    //     0x12750ec: add             x9, PP, #0x26, lsl #12  ; [pp+0x26230] Field <_SnackbarDefaultsM2@773267081._colors@773267081>: late final (offset: 0x48)
    //     0x12750f0: ldr             x9, [x9, #0x230]
    // 0x12750f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12750f4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12750f8: r9 = _colors
    //     0x12750f8: add             x9, PP, #0x26, lsl #12  ; [pp+0x26230] Field <_SnackbarDefaultsM2@773267081._colors@773267081>: late final (offset: 0x48)
    //     0x12750fc: ldr             x9, [x9, #0x230]
    // 0x1275100: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1275100: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 6837, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class SnackBarTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xd364f4, size: 0x5c
    // 0xd364f4: EnterFrame
    //     0xd364f4: stp             fp, lr, [SP, #-0x10]!
    //     0xd364f8: mov             fp, SP
    // 0xd364fc: AllocStack(0x18)
    //     0xd364fc: sub             SP, SP, #0x18
    // 0xd36500: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xd36500: stur            x1, [fp, #-8]
    // 0xd36504: CheckStackOverflow
    //     0xd36504: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd36508: cmp             SP, x16
    //     0xd3650c: b.ls            #0xd36548
    // 0xd36510: r16 = <SnackBarTheme>
    //     0xd36510: add             x16, PP, #0x84, lsl #12  ; [pp+0x84bd0] TypeArguments: <SnackBarTheme>
    //     0xd36514: ldr             x16, [x16, #0xbd0]
    // 0xd36518: stp             x1, x16, [SP]
    // 0xd3651c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3651c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd36520: r0 = dependOnInheritedWidgetOfExactType()
    //     0xd36520: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xd36524: ldur            x1, [fp, #-8]
    // 0xd36528: r0 = of()
    //     0xd36528: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd3652c: r17 = 295
    //     0xd3652c: mov             x17, #0x127
    // 0xd36530: ldr             w1, [x0, x17]
    // 0xd36534: DecompressPointer r1
    //     0xd36534: add             x1, x1, HEAP, lsl #32
    // 0xd36538: mov             x0, x1
    // 0xd3653c: LeaveFrame
    //     0xd3653c: mov             SP, fp
    //     0xd36540: ldp             fp, lr, [SP], #0x10
    // 0xd36544: ret
    //     0xd36544: ret             
    // 0xd36548: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd36548: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd3654c: b               #0xd36510
  }
}

// class id: 8261, size: 0x14, field offset: 0x14
enum SnackBarBehavior extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa92c, size: 0x64
    // 0x11aa92c: EnterFrame
    //     0x11aa92c: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa930: mov             fp, SP
    // 0x11aa934: AllocStack(0x10)
    //     0x11aa934: sub             SP, SP, #0x10
    // 0x11aa938: SetupParameters(SnackBarBehavior this /* r1 => r0, fp-0x8 */)
    //     0x11aa938: mov             x0, x1
    //     0x11aa93c: stur            x1, [fp, #-8]
    // 0x11aa940: CheckStackOverflow
    //     0x11aa940: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa944: cmp             SP, x16
    //     0x11aa948: b.ls            #0x11aa988
    // 0x11aa94c: r1 = Null
    //     0x11aa94c: mov             x1, NULL
    // 0x11aa950: r2 = 4
    //     0x11aa950: mov             x2, #4
    // 0x11aa954: r0 = AllocateArray()
    //     0x11aa954: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa958: r16 = "SnackBarBehavior."
    //     0x11aa958: add             x16, PP, #0x80, lsl #12  ; [pp+0x80928] "SnackBarBehavior."
    //     0x11aa95c: ldr             x16, [x16, #0x928]
    // 0x11aa960: StoreField: r0->field_f = r16
    //     0x11aa960: stur            w16, [x0, #0xf]
    // 0x11aa964: ldur            x1, [fp, #-8]
    // 0x11aa968: LoadField: r2 = r1->field_f
    //     0x11aa968: ldur            w2, [x1, #0xf]
    // 0x11aa96c: DecompressPointer r2
    //     0x11aa96c: add             x2, x2, HEAP, lsl #32
    // 0x11aa970: StoreField: r0->field_13 = r2
    //     0x11aa970: stur            w2, [x0, #0x13]
    // 0x11aa974: str             x0, [SP]
    // 0x11aa978: r0 = _interpolate()
    //     0x11aa978: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa97c: LeaveFrame
    //     0x11aa97c: mov             SP, fp
    //     0x11aa980: ldp             fp, lr, [SP], #0x10
    // 0x11aa984: ret
    //     0x11aa984: ret             
    // 0x11aa988: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa988: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa98c: b               #0x11aa94c
  }
}
