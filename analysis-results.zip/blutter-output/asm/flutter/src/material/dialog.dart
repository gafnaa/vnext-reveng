// lib: , url: package:flutter/src/material/dialog.dart

// class id: 1048880, size: 0x8
class :: {

  static Future<Y0?> showDialog<Y0>((dynamic, BuildContext) => Widget, BuildContext, {Color? barrierColor, bool barrierDismissible, RouteSettings? routeSettings}) {
    // ** addr: 0xd94f50, size: 0x298
    // 0xd94f50: EnterFrame
    //     0xd94f50: stp             fp, lr, [SP, #-0x10]!
    //     0xd94f54: mov             fp, SP
    // 0xd94f58: AllocStack(0x60)
    //     0xd94f58: sub             SP, SP, #0x60
    // 0xd94f5c: SetupParameters(dynamic _ /* r2, fp-0x30 */, dynamic _ /* r3, fp-0x28 */, {dynamic barrierColor = Null /* r1, fp-0x20 */, dynamic barrierDismissible = true /* r5, fp-0x18 */, dynamic routeSettings = Null /* r0, fp-0x10 */})
    //     0xd94f5c: ldur            w0, [x4, #0x13]
    //     0xd94f60: sub             x1, x0, #4
    //     0xd94f64: add             x2, fp, w1, sxtw #2
    //     0xd94f68: ldr             x2, [x2, #0x18]
    //     0xd94f6c: stur            x2, [fp, #-0x30]
    //     0xd94f70: add             x3, fp, w1, sxtw #2
    //     0xd94f74: ldr             x3, [x3, #0x10]
    //     0xd94f78: stur            x3, [fp, #-0x28]
    //     0xd94f7c: ldur            w1, [x4, #0x1f]
    //     0xd94f80: add             x1, x1, HEAP, lsl #32
    //     0xd94f84: add             x16, PP, #0x15, lsl #12  ; [pp+0x15088] "barrierColor"
    //     0xd94f88: ldr             x16, [x16, #0x88]
    //     0xd94f8c: cmp             w1, w16
    //     0xd94f90: b.ne            #0xd94fb0
    //     0xd94f94: ldur            w1, [x4, #0x23]
    //     0xd94f98: add             x1, x1, HEAP, lsl #32
    //     0xd94f9c: sub             w5, w0, w1
    //     0xd94fa0: add             x1, fp, w5, sxtw #2
    //     0xd94fa4: ldr             x1, [x1, #8]
    //     0xd94fa8: mov             x5, #1
    //     0xd94fac: b               #0xd94fb8
    //     0xd94fb0: mov             x5, #0
    //     0xd94fb4: mov             x1, NULL
    //     0xd94fb8: stur            x1, [fp, #-0x20]
    //     0xd94fbc: lsl             x6, x5, #1
    //     0xd94fc0: lsl             w7, w6, #1
    //     0xd94fc4: add             w8, w7, #8
    //     0xd94fc8: add             x16, x4, w8, sxtw #1
    //     0xd94fcc: ldur            w9, [x16, #0xf]
    //     0xd94fd0: add             x9, x9, HEAP, lsl #32
    //     0xd94fd4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15090] "barrierDismissible"
    //     0xd94fd8: ldr             x16, [x16, #0x90]
    //     0xd94fdc: cmp             w9, w16
    //     0xd94fe0: b.ne            #0xd95010
    //     0xd94fe4: add             w5, w7, #0xa
    //     0xd94fe8: add             x16, x4, w5, sxtw #1
    //     0xd94fec: ldur            w7, [x16, #0xf]
    //     0xd94ff0: add             x7, x7, HEAP, lsl #32
    //     0xd94ff4: sub             w5, w0, w7
    //     0xd94ff8: add             x7, fp, w5, sxtw #2
    //     0xd94ffc: ldr             x7, [x7, #8]
    //     0xd95000: add             w5, w6, #2
    //     0xd95004: sbfx            x6, x5, #1, #0x1f
    //     0xd95008: mov             x5, x7
    //     0xd9500c: b               #0xd95018
    //     0xd95010: mov             x6, x5
    //     0xd95014: add             x5, NULL, #0x20  ; true
    //     0xd95018: stur            x5, [fp, #-0x18]
    //     0xd9501c: lsl             x7, x6, #1
    //     0xd95020: lsl             w6, w7, #1
    //     0xd95024: add             w7, w6, #8
    //     0xd95028: add             x16, x4, w7, sxtw #1
    //     0xd9502c: ldur            w8, [x16, #0xf]
    //     0xd95030: add             x8, x8, HEAP, lsl #32
    //     0xd95034: add             x16, PP, #0x15, lsl #12  ; [pp+0x15098] "routeSettings"
    //     0xd95038: ldr             x16, [x16, #0x98]
    //     0xd9503c: cmp             w8, w16
    //     0xd95040: b.ne            #0xd95064
    //     0xd95044: add             w7, w6, #0xa
    //     0xd95048: add             x16, x4, w7, sxtw #1
    //     0xd9504c: ldur            w6, [x16, #0xf]
    //     0xd95050: add             x6, x6, HEAP, lsl #32
    //     0xd95054: sub             w7, w0, w6
    //     0xd95058: add             x0, fp, w7, sxtw #2
    //     0xd9505c: ldr             x0, [x0, #8]
    //     0xd95060: b               #0xd95068
    //     0xd95064: mov             x0, NULL
    //     0xd95068: stur            x0, [fp, #-0x10]
    //     0xd9506c: ldur            w6, [x4, #0xf]
    //     0xd95070: cbnz            w6, #0xd9507c
    //     0xd95074: mov             x4, NULL
    //     0xd95078: b               #0xd95088
    //     0xd9507c: ldur            w6, [x4, #0x17]
    //     0xd95080: add             x4, fp, w6, sxtw #2
    //     0xd95084: ldr             x4, [x4, #0x10]
    //     0xd95088: stur            x4, [fp, #-8]
    // 0xd9508c: CheckStackOverflow
    //     0xd9508c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd95090: cmp             SP, x16
    //     0xd95094: b.ls            #0xd951dc
    // 0xd95098: r1 = 7
    //     0xd95098: mov             x1, #7
    // 0xd9509c: r0 = AllocateContext()
    //     0xd9509c: bl              #0x13de838  ; AllocateContextStub
    // 0xd950a0: mov             x2, x0
    // 0xd950a4: ldur            x0, [fp, #-0x30]
    // 0xd950a8: stur            x2, [fp, #-0x38]
    // 0xd950ac: StoreField: r2->field_f = r0
    //     0xd950ac: stur            w0, [x2, #0xf]
    // 0xd950b0: ldur            x0, [fp, #-0x28]
    // 0xd950b4: StoreField: r2->field_13 = r0
    //     0xd950b4: stur            w0, [x2, #0x13]
    // 0xd950b8: ldur            x1, [fp, #-0x20]
    // 0xd950bc: ArrayStore: r2[0] = r1  ; List_4
    //     0xd950bc: stur            w1, [x2, #0x17]
    // 0xd950c0: ldur            x1, [fp, #-0x18]
    // 0xd950c4: StoreField: r2->field_1b = r1
    //     0xd950c4: stur            w1, [x2, #0x1b]
    // 0xd950c8: ldur            x1, [fp, #-0x10]
    // 0xd950cc: StoreField: r2->field_1f = r1
    //     0xd950cc: stur            w1, [x2, #0x1f]
    // 0xd950d0: r16 = true
    //     0xd950d0: add             x16, NULL, #0x20  ; true
    // 0xd950d4: str             x16, [SP]
    // 0xd950d8: mov             x1, x0
    // 0xd950dc: r4 = const [0, 0x2, 0x1, 0x1, rootNavigator, 0x1, null]
    //     0xd950dc: add             x4, PP, #0x15, lsl #12  ; [pp+0x150a0] List(7) [0, 0x2, 0x1, 0x1, "rootNavigator", 0x1, Null]
    //     0xd950e0: ldr             x4, [x4, #0xa0]
    // 0xd950e4: r0 = of()
    //     0xd950e4: bl              #0xb35e68  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0xd950e8: LoadField: r2 = r0->field_f
    //     0xd950e8: ldur            w2, [x0, #0xf]
    // 0xd950ec: DecompressPointer r2
    //     0xd950ec: add             x2, x2, HEAP, lsl #32
    // 0xd950f0: cmp             w2, NULL
    // 0xd950f4: b.eq            #0xd951e4
    // 0xd950f8: ldur            x1, [fp, #-0x28]
    // 0xd950fc: r0 = capture()
    //     0xd950fc: bl              #0x8556d4  ; [package:flutter/src/widgets/inherited_theme.dart] InheritedTheme::capture
    // 0xd95100: ldur            x2, [fp, #-0x38]
    // 0xd95104: StoreField: r2->field_23 = r0
    //     0xd95104: stur            w0, [x2, #0x23]
    //     0xd95108: ldurb           w16, [x2, #-1]
    //     0xd9510c: ldurb           w17, [x0, #-1]
    //     0xd95110: and             x16, x17, x16, lsr #2
    //     0xd95114: tst             x16, HEAP, lsr #32
    //     0xd95118: b.eq            #0xd95120
    //     0xd9511c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd95120: LoadField: r1 = r2->field_13
    //     0xd95120: ldur            w1, [x2, #0x13]
    // 0xd95124: DecompressPointer r1
    //     0xd95124: add             x1, x1, HEAP, lsl #32
    // 0xd95128: r16 = true
    //     0xd95128: add             x16, NULL, #0x20  ; true
    // 0xd9512c: str             x16, [SP]
    // 0xd95130: r4 = const [0, 0x2, 0x1, 0x1, rootNavigator, 0x1, null]
    //     0xd95130: add             x4, PP, #0x15, lsl #12  ; [pp+0x150a0] List(7) [0, 0x2, 0x1, 0x1, "rootNavigator", 0x1, Null]
    //     0xd95134: ldr             x4, [x4, #0xa0]
    // 0xd95138: r0 = of()
    //     0xd95138: bl              #0xb35e68  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0xd9513c: ldur            x3, [fp, #-0x38]
    // 0xd95140: StoreField: r3->field_27 = r0
    //     0xd95140: stur            w0, [x3, #0x27]
    //     0xd95144: ldurb           w16, [x3, #-1]
    //     0xd95148: ldurb           w17, [x0, #-1]
    //     0xd9514c: and             x16, x17, x16, lsr #2
    //     0xd95150: tst             x16, HEAP, lsr #32
    //     0xd95154: b.eq            #0xd9515c
    //     0xd95158: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd9515c: LoadField: r0 = r3->field_13
    //     0xd9515c: ldur            w0, [x3, #0x13]
    // 0xd95160: DecompressPointer r0
    //     0xd95160: add             x0, x0, HEAP, lsl #32
    // 0xd95164: stur            x0, [fp, #-0x18]
    // 0xd95168: LoadField: r4 = r3->field_1f
    //     0xd95168: ldur            w4, [x3, #0x1f]
    // 0xd9516c: DecompressPointer r4
    //     0xd9516c: add             x4, x4, HEAP, lsl #32
    // 0xd95170: mov             x2, x3
    // 0xd95174: stur            x4, [fp, #-0x10]
    // 0xd95178: r1 = Function '<anonymous closure>': static.
    //     0xd95178: add             x1, PP, #0x15, lsl #12  ; [pp+0x150a8] AnonymousClosure: static (0xd958f4), in [package:flutter/src/material/dialog.dart] ::showDialog (0xd94f50)
    //     0xd9517c: ldr             x1, [x1, #0xa8]
    // 0xd95180: r0 = AllocateClosure()
    //     0xd95180: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd95184: mov             x3, x0
    // 0xd95188: ldur            x0, [fp, #-8]
    // 0xd9518c: stur            x3, [fp, #-0x20]
    // 0xd95190: StoreField: r3->field_b = r0
    //     0xd95190: stur            w0, [x3, #0xb]
    // 0xd95194: ldur            x2, [fp, #-0x38]
    // 0xd95198: r1 = Function '<anonymous closure>': static.
    //     0xd95198: add             x1, PP, #0x15, lsl #12  ; [pp+0x150b0] AnonymousClosure: static (0xd95704), in [package:flutter/src/material/dialog.dart] ::showDialog (0xd94f50)
    //     0xd9519c: ldr             x1, [x1, #0xb0]
    // 0xd951a0: r0 = AllocateClosure()
    //     0xd951a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd951a4: mov             x1, x0
    // 0xd951a8: ldur            x0, [fp, #-8]
    // 0xd951ac: StoreField: r1->field_b = r0
    //     0xd951ac: stur            w0, [x1, #0xb]
    // 0xd951b0: stp             x1, x0, [SP, #0x18]
    // 0xd951b4: ldur            x16, [fp, #-0x18]
    // 0xd951b8: ldur            lr, [fp, #-0x20]
    // 0xd951bc: stp             lr, x16, [SP, #8]
    // 0xd951c0: ldur            x16, [fp, #-0x10]
    // 0xd951c4: str             x16, [SP]
    // 0xd951c8: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xd951c8: ldr             x4, [PP, #0x560]  ; [pp+0x560] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xd951cc: r0 = showRawDialog()
    //     0xd951cc: bl              #0xd951e8  ; [package:flutter/src/widgets/dialog.dart] ::showRawDialog
    // 0xd951d0: LeaveFrame
    //     0xd951d0: mov             SP, fp
    //     0xd951d4: ldp             fp, lr, [SP], #0x10
    // 0xd951d8: ret
    //     0xd951d8: ret             
    // 0xd951dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd951dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd951e0: b               #0xd95098
    // 0xd951e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd951e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] static Directionality <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xd95704, size: 0x174
    // 0xd95704: EnterFrame
    //     0xd95704: stp             fp, lr, [SP, #-0x10]!
    //     0xd95708: mov             fp, SP
    // 0xd9570c: AllocStack(0x40)
    //     0xd9570c: sub             SP, SP, #0x40
    // 0xd95710: SetupParameters([dynamic _ /* r0 */])
    //     0xd95710: ldr             x0, [fp, #0x18]
    //     0xd95714: ldur            w2, [x0, #0x17]
    //     0xd95718: add             x2, x2, HEAP, lsl #32
    //     0xd9571c: stur            x2, [fp, #-0x10]
    // 0xd95720: CheckStackOverflow
    //     0xd95720: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd95724: cmp             SP, x16
    //     0xd95728: b.ls            #0xd9586c
    // 0xd9572c: LoadField: r3 = r0->field_b
    //     0xd9572c: ldur            w3, [x0, #0xb]
    // 0xd95730: DecompressPointer r3
    //     0xd95730: add             x3, x3, HEAP, lsl #32
    // 0xd95734: stur            x3, [fp, #-8]
    // 0xd95738: LoadField: r1 = r2->field_13
    //     0xd95738: ldur            w1, [x2, #0x13]
    // 0xd9573c: DecompressPointer r1
    //     0xd9573c: add             x1, x1, HEAP, lsl #32
    // 0xd95740: r0 = of()
    //     0xd95740: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xd95744: ldur            x2, [fp, #-0x10]
    // 0xd95748: stur            x0, [fp, #-0x18]
    // 0xd9574c: LoadField: r1 = r2->field_13
    //     0xd9574c: ldur            w1, [x2, #0x13]
    // 0xd95750: DecompressPointer r1
    //     0xd95750: add             x1, x1, HEAP, lsl #32
    // 0xd95754: r0 = of()
    //     0xd95754: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd95758: ldur            x2, [fp, #-0x10]
    // 0xd9575c: stur            x0, [fp, #-0x20]
    // 0xd95760: LoadField: r1 = r2->field_13
    //     0xd95760: ldur            w1, [x2, #0x13]
    // 0xd95764: DecompressPointer r1
    //     0xd95764: add             x1, x1, HEAP, lsl #32
    // 0xd95768: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd95768: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd9576c: r0 = _of()
    //     0xd9576c: bl              #0x8651cc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0xd95770: ldur            x2, [fp, #-0x10]
    // 0xd95774: stur            x0, [fp, #-0x28]
    // 0xd95778: LoadField: r1 = r2->field_27
    //     0xd95778: ldur            w1, [x2, #0x27]
    // 0xd9577c: DecompressPointer r1
    //     0xd9577c: add             x1, x1, HEAP, lsl #32
    // 0xd95780: LoadField: r3 = r1->field_f
    //     0xd95780: ldur            w3, [x1, #0xf]
    // 0xd95784: DecompressPointer r3
    //     0xd95784: add             x3, x3, HEAP, lsl #32
    // 0xd95788: cmp             w3, NULL
    // 0xd9578c: b.eq            #0xd95874
    // 0xd95790: mov             x1, x3
    // 0xd95794: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd95794: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd95798: r0 = of()
    //     0xd95798: bl              #0xb35e68  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0xd9579c: mov             x2, x0
    // 0xd957a0: r1 = Function 'pop':.
    //     0xd957a0: add             x1, PP, #0x15, lsl #12  ; [pp+0x150b8] AnonymousClosure: (0x8c88f8), in [package:flutter/src/widgets/navigator.dart] NavigatorState::pop (0x8c87a0)
    //     0xd957a4: ldr             x1, [x1, #0xb8]
    // 0xd957a8: r0 = AllocateClosureGeneric()
    //     0xd957a8: bl              #0x13deb28  ; AllocateClosureGenericStub
    // 0xd957ac: r16 = <Object>
    //     0xd957ac: ldr             x16, [PP, #0x720]  ; [pp+0x720] TypeArguments: <Object>
    // 0xd957b0: stp             x16, x0, [SP]
    // 0xd957b4: r0 = _instantiateClosure()
    //     0xd957b4: bl              #0x7d92dc  ; [dart:_internal] ::_instantiateClosure
    // 0xd957b8: ldur            x2, [fp, #-0x10]
    // 0xd957bc: r1 = Function '<anonymous closure>': static.
    //     0xd957bc: add             x1, PP, #0x15, lsl #12  ; [pp+0x150c0] AnonymousClosure: static (0xd95884), in [package:flutter/src/material/dialog.dart] ::showDialog (0xd94f50)
    //     0xd957c0: ldr             x1, [x1, #0xc0]
    // 0xd957c4: stur            x0, [fp, #-0x10]
    // 0xd957c8: r0 = AllocateClosure()
    //     0xd957c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd957cc: mov             x1, x0
    // 0xd957d0: ldur            x0, [fp, #-8]
    // 0xd957d4: stur            x1, [fp, #-0x30]
    // 0xd957d8: StoreField: r1->field_b = r0
    //     0xd957d8: stur            w0, [x1, #0xb]
    // 0xd957dc: r0 = Builder()
    //     0xd957dc: bl              #0x858774  ; AllocateBuilderStub -> Builder (size=0x10)
    // 0xd957e0: mov             x1, x0
    // 0xd957e4: ldur            x0, [fp, #-0x30]
    // 0xd957e8: stur            x1, [fp, #-8]
    // 0xd957ec: StoreField: r1->field_b = r0
    //     0xd957ec: stur            w0, [x1, #0xb]
    // 0xd957f0: r0 = _DialogPopScope()
    //     0xd957f0: bl              #0xd95878  ; Allocate_DialogPopScopeStub -> _DialogPopScope (size=0x14)
    // 0xd957f4: mov             x2, x0
    // 0xd957f8: ldur            x0, [fp, #-8]
    // 0xd957fc: stur            x2, [fp, #-0x30]
    // 0xd95800: StoreField: r2->field_b = r0
    //     0xd95800: stur            w0, [x2, #0xb]
    // 0xd95804: ldur            x0, [fp, #-0x10]
    // 0xd95808: StoreField: r2->field_f = r0
    //     0xd95808: stur            w0, [x2, #0xf]
    // 0xd9580c: r1 = <_MediaQueryAspect>
    //     0xd9580c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12828] TypeArguments: <_MediaQueryAspect>
    //     0xd95810: ldr             x1, [x1, #0x828]
    // 0xd95814: r0 = MediaQuery()
    //     0xd95814: bl              #0xd0af24  ; AllocateMediaQueryStub -> MediaQuery (size=0x18)
    // 0xd95818: mov             x1, x0
    // 0xd9581c: ldur            x0, [fp, #-0x28]
    // 0xd95820: stur            x1, [fp, #-8]
    // 0xd95824: StoreField: r1->field_13 = r0
    //     0xd95824: stur            w0, [x1, #0x13]
    // 0xd95828: ldur            x0, [fp, #-0x30]
    // 0xd9582c: StoreField: r1->field_b = r0
    //     0xd9582c: stur            w0, [x1, #0xb]
    // 0xd95830: r0 = Theme()
    //     0xd95830: bl              #0xd2f05c  ; AllocateThemeStub -> Theme (size=0x14)
    // 0xd95834: mov             x1, x0
    // 0xd95838: ldur            x0, [fp, #-0x20]
    // 0xd9583c: stur            x1, [fp, #-0x10]
    // 0xd95840: StoreField: r1->field_b = r0
    //     0xd95840: stur            w0, [x1, #0xb]
    // 0xd95844: ldur            x0, [fp, #-8]
    // 0xd95848: StoreField: r1->field_f = r0
    //     0xd95848: stur            w0, [x1, #0xf]
    // 0xd9584c: r0 = Directionality()
    //     0xd9584c: bl              #0xd5e5d8  ; AllocateDirectionalityStub -> Directionality (size=0x14)
    // 0xd95850: ldur            x1, [fp, #-0x18]
    // 0xd95854: StoreField: r0->field_f = r1
    //     0xd95854: stur            w1, [x0, #0xf]
    // 0xd95858: ldur            x1, [fp, #-0x10]
    // 0xd9585c: StoreField: r0->field_b = r1
    //     0xd9585c: stur            w1, [x0, #0xb]
    // 0xd95860: LeaveFrame
    //     0xd95860: mov             SP, fp
    //     0xd95864: ldp             fp, lr, [SP], #0x10
    // 0xd95868: ret
    //     0xd95868: ret             
    // 0xd9586c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd9586c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd95870: b               #0xd9572c
    // 0xd95874: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd95874: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] static _FullWindowDialogWrapper <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xd95884, size: 0x64
    // 0xd95884: EnterFrame
    //     0xd95884: stp             fp, lr, [SP, #-0x10]!
    //     0xd95888: mov             fp, SP
    // 0xd9588c: AllocStack(0x18)
    //     0xd9588c: sub             SP, SP, #0x18
    // 0xd95890: SetupParameters([dynamic _ /* r0 */])
    //     0xd95890: ldr             x0, [fp, #0x18]
    //     0xd95894: ldur            w1, [x0, #0x17]
    //     0xd95898: add             x1, x1, HEAP, lsl #32
    // 0xd9589c: CheckStackOverflow
    //     0xd9589c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd958a0: cmp             SP, x16
    //     0xd958a4: b.ls            #0xd958e0
    // 0xd958a8: LoadField: r0 = r1->field_f
    //     0xd958a8: ldur            w0, [x1, #0xf]
    // 0xd958ac: DecompressPointer r0
    //     0xd958ac: add             x0, x0, HEAP, lsl #32
    // 0xd958b0: ldr             x16, [fp, #0x10]
    // 0xd958b4: stp             x16, x0, [SP]
    // 0xd958b8: ClosureCall
    //     0xd958b8: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd958bc: ldur            x2, [x0, #0x1f]
    //     0xd958c0: blr             x2
    // 0xd958c4: stur            x0, [fp, #-8]
    // 0xd958c8: r0 = _FullWindowDialogWrapper()
    //     0xd958c8: bl              #0xd958e8  ; Allocate_FullWindowDialogWrapperStub -> _FullWindowDialogWrapper (size=0x10)
    // 0xd958cc: ldur            x1, [fp, #-8]
    // 0xd958d0: StoreField: r0->field_b = r1
    //     0xd958d0: stur            w1, [x0, #0xb]
    // 0xd958d4: LeaveFrame
    //     0xd958d4: mov             SP, fp
    //     0xd958d8: ldp             fp, lr, [SP], #0x10
    // 0xd958dc: ret
    //     0xd958dc: ret             
    // 0xd958e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd958e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd958e4: b               #0xd958a8
  }
  [closure] static DialogRoute<Y0> <anonymous closure>(dynamic, BuildContext, (dynamic, BuildContext) => Widget) {
    // ** addr: 0xd958f4, size: 0x108
    // 0xd958f4: EnterFrame
    //     0xd958f4: stp             fp, lr, [SP, #-0x10]!
    //     0xd958f8: mov             fp, SP
    // 0xd958fc: AllocStack(0x40)
    //     0xd958fc: sub             SP, SP, #0x40
    // 0xd95900: SetupParameters([dynamic _ /* r0 */])
    //     0xd95900: ldr             x0, [fp, #0x20]
    //     0xd95904: ldur            w2, [x0, #0x17]
    //     0xd95908: add             x2, x2, HEAP, lsl #32
    //     0xd9590c: stur            x2, [fp, #-0x18]
    // 0xd95910: CheckStackOverflow
    //     0xd95910: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd95914: cmp             SP, x16
    //     0xd95918: b.ls            #0xd959f4
    // 0xd9591c: LoadField: r3 = r0->field_b
    //     0xd9591c: ldur            w3, [x0, #0xb]
    // 0xd95920: DecompressPointer r3
    //     0xd95920: add             x3, x3, HEAP, lsl #32
    // 0xd95924: stur            x3, [fp, #-0x10]
    // 0xd95928: LoadField: r5 = r2->field_f
    //     0xd95928: ldur            w5, [x2, #0xf]
    // 0xd9592c: DecompressPointer r5
    //     0xd9592c: add             x5, x5, HEAP, lsl #32
    // 0xd95930: stur            x5, [fp, #-8]
    // 0xd95934: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xd95934: ldur            w0, [x2, #0x17]
    // 0xd95938: DecompressPointer r0
    //     0xd95938: add             x0, x0, HEAP, lsl #32
    // 0xd9593c: cmp             w0, NULL
    // 0xd95940: b.ne            #0xd95954
    // 0xd95944: LoadField: r1 = r2->field_13
    //     0xd95944: ldur            w1, [x2, #0x13]
    // 0xd95948: DecompressPointer r1
    //     0xd95948: add             x1, x1, HEAP, lsl #32
    // 0xd9594c: r0 = of()
    //     0xd9594c: bl              #0xd95ca0  ; [package:flutter/src/material/dialog_theme.dart] DialogTheme::of
    // 0xd95950: r0 = Null
    //     0xd95950: mov             x0, NULL
    // 0xd95954: cmp             w0, NULL
    // 0xd95958: b.ne            #0xd95970
    // 0xd9595c: ldur            x0, [fp, #-0x18]
    // 0xd95960: LoadField: r1 = r0->field_13
    //     0xd95960: ldur            w1, [x0, #0x13]
    // 0xd95964: DecompressPointer r1
    //     0xd95964: add             x1, x1, HEAP, lsl #32
    // 0xd95968: r0 = of()
    //     0xd95968: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd9596c: r0 = Null
    //     0xd9596c: mov             x0, NULL
    // 0xd95970: cmp             w0, NULL
    // 0xd95974: b.ne            #0xd95984
    // 0xd95978: r2 = Instance_Color
    //     0xd95978: add             x2, PP, #0x12, lsl #12  ; [pp+0x12c78] Obj!Color@12a1741
    //     0xd9597c: ldr             x2, [x2, #0xc78]
    // 0xd95980: b               #0xd95988
    // 0xd95984: mov             x2, x0
    // 0xd95988: ldur            x0, [fp, #-0x18]
    // 0xd9598c: stur            x2, [fp, #-0x38]
    // 0xd95990: LoadField: r3 = r0->field_1b
    //     0xd95990: ldur            w3, [x0, #0x1b]
    // 0xd95994: DecompressPointer r3
    //     0xd95994: add             x3, x3, HEAP, lsl #32
    // 0xd95998: stur            x3, [fp, #-0x30]
    // 0xd9599c: LoadField: r7 = r0->field_1f
    //     0xd9599c: ldur            w7, [x0, #0x1f]
    // 0xd959a0: DecompressPointer r7
    //     0xd959a0: add             x7, x7, HEAP, lsl #32
    // 0xd959a4: stur            x7, [fp, #-0x28]
    // 0xd959a8: LoadField: r4 = r0->field_23
    //     0xd959a8: ldur            w4, [x0, #0x23]
    // 0xd959ac: DecompressPointer r4
    //     0xd959ac: add             x4, x4, HEAP, lsl #32
    // 0xd959b0: ldur            x1, [fp, #-0x10]
    // 0xd959b4: stur            x4, [fp, #-0x20]
    // 0xd959b8: r0 = DialogRoute()
    //     0xd959b8: bl              #0xd95c94  ; AllocateDialogRouteStub -> DialogRoute<X0> (size=0xc0)
    // 0xd959bc: stur            x0, [fp, #-0x10]
    // 0xd959c0: ldur            x16, [fp, #-0x20]
    // 0xd959c4: str             x16, [SP]
    // 0xd959c8: mov             x1, x0
    // 0xd959cc: ldur            x2, [fp, #-0x38]
    // 0xd959d0: ldur            x3, [fp, #-0x30]
    // 0xd959d4: ldur            x5, [fp, #-8]
    // 0xd959d8: ldr             x6, [fp, #0x18]
    // 0xd959dc: ldur            x7, [fp, #-0x28]
    // 0xd959e0: r0 = DialogRoute()
    //     0xd959e0: bl              #0xd959fc  ; [package:flutter/src/material/dialog.dart] DialogRoute::DialogRoute
    // 0xd959e4: ldur            x0, [fp, #-0x10]
    // 0xd959e8: LeaveFrame
    //     0xd959e8: mov             SP, fp
    //     0xd959ec: ldp             fp, lr, [SP], #0x10
    // 0xd959f0: ret
    //     0xd959f0: ret             
    // 0xd959f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd959f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd959f8: b               #0xd9591c
  }
  static _ _scalePadding(/* No info */) {
    // ** addr: 0xfb8774, size: 0xb4
    // 0xfb8774: EnterFrame
    //     0xfb8774: stp             fp, lr, [SP, #-0x10]!
    //     0xfb8778: mov             fp, SP
    // 0xfb877c: d1 = 1.000000
    //     0xfb877c: fmov            d1, #1.00000000
    // 0xfb8780: CheckStackOverflow
    //     0xfb8780: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb8784: cmp             SP, x16
    //     0xfb8788: b.ls            #0xfb880c
    // 0xfb878c: fcmp            d1, d0
    // 0xfb8790: b.le            #0xfb879c
    // 0xfb8794: d0 = 1.000000
    //     0xfb8794: fmov            d0, #1.00000000
    // 0xfb8798: b               #0xfb87bc
    // 0xfb879c: d2 = 2.000000
    //     0xfb879c: fmov            d2, #2.00000000
    // 0xfb87a0: fcmp            d0, d2
    // 0xfb87a4: b.le            #0xfb87b0
    // 0xfb87a8: d0 = 2.000000
    //     0xfb87a8: fmov            d0, #2.00000000
    // 0xfb87ac: b               #0xfb87bc
    // 0xfb87b0: fcmp            d0, d0
    // 0xfb87b4: b.vc            #0xfb87bc
    // 0xfb87b8: d0 = 2.000000
    //     0xfb87b8: fmov            d0, #2.00000000
    // 0xfb87bc: fsub            d2, d0, d1
    // 0xfb87c0: r3 = inline_Allocate_Double()
    //     0xfb87c0: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xfb87c4: add             x3, x3, #0x10
    //     0xfb87c8: cmp             x0, x3
    //     0xfb87cc: b.ls            #0xfb8814
    //     0xfb87d0: str             x3, [THR, #0x60]  ; THR::top
    //     0xfb87d4: sub             x3, x3, #0xf
    //     0xfb87d8: mov             x0, #0xe19c
    //     0xfb87dc: movk            x0, #3, lsl #16
    //     0xfb87e0: stur            x0, [x3, #-1]
    // 0xfb87e4: dmb             ishst
    // 0xfb87e8: StoreField: r3->field_7 = d2
    //     0xfb87e8: stur            d2, [x3, #7]
    // 0xfb87ec: r1 = 1.000000
    //     0xfb87ec: ldr             x1, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xfb87f0: r2 = 0.333333
    //     0xfb87f0: add             x2, PP, #0x80, lsl #12  ; [pp+0x80ac8] 0.3333333333333333
    //     0xfb87f4: ldr             x2, [x2, #0xac8]
    // 0xfb87f8: r0 = lerpDouble()
    //     0xfb87f8: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xfb87fc: LoadField: d0 = r0->field_7
    //     0xfb87fc: ldur            d0, [x0, #7]
    // 0xfb8800: LeaveFrame
    //     0xfb8800: mov             SP, fp
    //     0xfb8804: ldp             fp, lr, [SP], #0x10
    // 0xfb8808: ret
    //     0xfb8808: ret             
    // 0xfb880c: r0 = StackOverflowSharedWithFPURegs()
    //     0xfb880c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xfb8810: b               #0xfb878c
    // 0xfb8814: SaveReg d2
    //     0xfb8814: str             q2, [SP, #-0x10]!
    // 0xfb8818: r0 = AllocateDouble()
    //     0xfb8818: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfb881c: mov             x3, x0
    // 0xfb8820: RestoreReg d2
    //     0xfb8820: ldr             q2, [SP], #0x10
    // 0xfb8824: b               #0xfb87e8
  }
}

// class id: 2631, size: 0x28, field offset: 0x24
//   const constructor, 
class _DialogContentPage extends Page<dynamic> {

  _ createRoute(/* No info */) {
    // ** addr: 0x13119a4, size: 0x90
    // 0x13119a4: EnterFrame
    //     0x13119a4: stp             fp, lr, [SP, #-0x10]!
    //     0x13119a8: mov             fp, SP
    // 0x13119ac: AllocStack(0x30)
    //     0x13119ac: sub             SP, SP, #0x30
    // 0x13119b0: SetupParameters(_DialogContentPage this /* r1 => r1, fp-0x8 */)
    //     0x13119b0: stur            x1, [fp, #-8]
    // 0x13119b4: CheckStackOverflow
    //     0x13119b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13119b8: cmp             SP, x16
    //     0x13119bc: b.ls            #0x1311a2c
    // 0x13119c0: r1 = 1
    //     0x13119c0: mov             x1, #1
    // 0x13119c4: r0 = AllocateContext()
    //     0x13119c4: bl              #0x13de838  ; AllocateContextStub
    // 0x13119c8: mov             x1, x0
    // 0x13119cc: ldur            x0, [fp, #-8]
    // 0x13119d0: StoreField: r1->field_f = r0
    //     0x13119d0: stur            w0, [x1, #0xf]
    // 0x13119d4: mov             x2, x1
    // 0x13119d8: r1 = Function '<anonymous closure>':.
    //     0x13119d8: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa10a8] AnonymousClosure: (0x1311a34), in [package:flutter/src/material/dialog.dart] _DialogContentPage::createRoute (0x13119a4)
    //     0x13119dc: ldr             x1, [x1, #0xa8]
    // 0x13119e0: r0 = AllocateClosure()
    //     0x13119e0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x13119e4: r1 = <void?>
    //     0x13119e4: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x13119e8: stur            x0, [fp, #-0x10]
    // 0x13119ec: r0 = PageRouteBuilder()
    //     0x13119ec: bl              #0xf6c5ac  ; AllocatePageRouteBuilderStub -> PageRouteBuilder<X0> (size=0xc8)
    // 0x13119f0: stur            x0, [fp, #-0x18]
    // 0x13119f4: ldur            x16, [fp, #-8]
    // 0x13119f8: r30 = Instance_Duration
    //     0x13119f8: ldr             lr, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    // 0x13119fc: stp             lr, x16, [SP, #8]
    // 0x1311a00: r16 = Instance_Duration
    //     0x1311a00: ldr             x16, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    // 0x1311a04: str             x16, [SP]
    // 0x1311a08: mov             x1, x0
    // 0x1311a0c: ldur            x2, [fp, #-0x10]
    // 0x1311a10: r4 = const [0, 0x5, 0x3, 0x2, reverseTransitionDuration, 0x4, settings, 0x2, transitionDuration, 0x3, null]
    //     0x1311a10: add             x4, PP, #0xa1, lsl #12  ; [pp+0xa10b0] List(11) [0, 0x5, 0x3, 0x2, "reverseTransitionDuration", 0x4, "settings", 0x2, "transitionDuration", 0x3, Null]
    //     0x1311a14: ldr             x4, [x4, #0xb0]
    // 0x1311a18: r0 = PageRouteBuilder()
    //     0x1311a18: bl              #0xf6c3f8  ; [package:flutter/src/widgets/pages.dart] PageRouteBuilder::PageRouteBuilder
    // 0x1311a1c: ldur            x0, [fp, #-0x18]
    // 0x1311a20: LeaveFrame
    //     0x1311a20: mov             SP, fp
    //     0x1311a24: ldp             fp, lr, [SP], #0x10
    // 0x1311a28: ret
    //     0x1311a28: ret             
    // 0x1311a2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1311a2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1311a30: b               #0x13119c0
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, Animation<double>, Animation<double>) {
    // ** addr: 0x1311a34, size: 0x20
    // 0x1311a34: ldr             x1, [SP, #0x18]
    // 0x1311a38: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x1311a38: ldur            w2, [x1, #0x17]
    // 0x1311a3c: DecompressPointer r2
    //     0x1311a3c: add             x2, x2, HEAP, lsl #32
    // 0x1311a40: LoadField: r1 = r2->field_f
    //     0x1311a40: ldur            w1, [x2, #0xf]
    // 0x1311a44: DecompressPointer r1
    //     0x1311a44: add             x1, x1, HEAP, lsl #32
    // 0x1311a48: LoadField: r0 = r1->field_23
    //     0x1311a48: ldur            w0, [x1, #0x23]
    // 0x1311a4c: DecompressPointer r0
    //     0x1311a4c: add             x0, x0, HEAP, lsl #32
    // 0x1311a50: ret
    //     0x1311a50: ret             
  }
}

// class id: 2648, size: 0xc0, field offset: 0xb8
class DialogRoute<X0> extends RawDialogRoute<X0> {

  _ buildTransitions(/* No info */) {
    // ** addr: 0xb28e78, size: 0xa8
    // 0xb28e78: EnterFrame
    //     0xb28e78: stp             fp, lr, [SP, #-0x10]!
    //     0xb28e7c: mov             fp, SP
    // 0xb28e80: AllocStack(0x30)
    //     0xb28e80: sub             SP, SP, #0x30
    // 0xb28e84: SetupParameters(DialogRoute<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */)
    //     0xb28e84: mov             x4, x1
    //     0xb28e88: mov             x0, x3
    //     0xb28e8c: stur            x3, [fp, #-0x18]
    //     0xb28e90: mov             x3, x2
    //     0xb28e94: stur            x1, [fp, #-8]
    //     0xb28e98: stur            x2, [fp, #-0x10]
    //     0xb28e9c: stur            x5, [fp, #-0x20]
    //     0xb28ea0: stur            x6, [fp, #-0x28]
    // 0xb28ea4: CheckStackOverflow
    //     0xb28ea4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb28ea8: cmp             SP, x16
    //     0xb28eac: b.ls            #0xb28f14
    // 0xb28eb0: mov             x1, x4
    // 0xb28eb4: mov             x2, x0
    // 0xb28eb8: r0 = _setAnimation()
    //     0xb28eb8: bl              #0xb28f20  ; [package:flutter/src/material/dialog.dart] DialogRoute::_setAnimation
    // 0xb28ebc: ldur            x1, [fp, #-8]
    // 0xb28ec0: LoadField: r0 = r1->field_b7
    //     0xb28ec0: ldur            w0, [x1, #0xb7]
    // 0xb28ec4: DecompressPointer r0
    //     0xb28ec4: add             x0, x0, HEAP, lsl #32
    // 0xb28ec8: stur            x0, [fp, #-0x30]
    // 0xb28ecc: cmp             w0, NULL
    // 0xb28ed0: b.eq            #0xb28f1c
    // 0xb28ed4: ldur            x2, [fp, #-0x10]
    // 0xb28ed8: ldur            x3, [fp, #-0x18]
    // 0xb28edc: ldur            x5, [fp, #-0x20]
    // 0xb28ee0: ldur            x6, [fp, #-0x28]
    // 0xb28ee4: r0 = buildTransitions()
    //     0xb28ee4: bl              #0xb29084  ; [package:flutter/src/widgets/routes.dart] ModalRoute::buildTransitions
    // 0xb28ee8: stur            x0, [fp, #-8]
    // 0xb28eec: r0 = FadeTransition()
    //     0xb28eec: bl              #0xb28358  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0xb28ef0: ldur            x1, [fp, #-0x30]
    // 0xb28ef4: StoreField: r0->field_f = r1
    //     0xb28ef4: stur            w1, [x0, #0xf]
    // 0xb28ef8: r1 = false
    //     0xb28ef8: add             x1, NULL, #0x30  ; false
    // 0xb28efc: StoreField: r0->field_13 = r1
    //     0xb28efc: stur            w1, [x0, #0x13]
    // 0xb28f00: ldur            x1, [fp, #-8]
    // 0xb28f04: StoreField: r0->field_b = r1
    //     0xb28f04: stur            w1, [x0, #0xb]
    // 0xb28f08: LeaveFrame
    //     0xb28f08: mov             SP, fp
    //     0xb28f0c: ldp             fp, lr, [SP], #0x10
    // 0xb28f10: ret
    //     0xb28f10: ret             
    // 0xb28f14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb28f14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb28f18: b               #0xb28eb0
    // 0xb28f1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb28f1c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _setAnimation(/* No info */) {
    // ** addr: 0xb28f20, size: 0xf4
    // 0xb28f20: EnterFrame
    //     0xb28f20: stp             fp, lr, [SP, #-0x10]!
    //     0xb28f24: mov             fp, SP
    // 0xb28f28: AllocStack(0x28)
    //     0xb28f28: sub             SP, SP, #0x28
    // 0xb28f2c: SetupParameters(DialogRoute<X0> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xb28f2c: mov             x3, x2
    //     0xb28f30: stur            x1, [fp, #-8]
    //     0xb28f34: stur            x2, [fp, #-0x10]
    // 0xb28f38: CheckStackOverflow
    //     0xb28f38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb28f3c: cmp             SP, x16
    //     0xb28f40: b.ls            #0xb2900c
    // 0xb28f44: LoadField: r0 = r1->field_b7
    //     0xb28f44: ldur            w0, [x1, #0xb7]
    // 0xb28f48: DecompressPointer r0
    //     0xb28f48: add             x0, x0, HEAP, lsl #32
    // 0xb28f4c: cmp             w0, NULL
    // 0xb28f50: b.ne            #0xb28f5c
    // 0xb28f54: r0 = Null
    //     0xb28f54: mov             x0, NULL
    // 0xb28f58: b               #0xb28f68
    // 0xb28f5c: LoadField: r2 = r0->field_b
    //     0xb28f5c: ldur            w2, [x0, #0xb]
    // 0xb28f60: DecompressPointer r2
    //     0xb28f60: add             x2, x2, HEAP, lsl #32
    // 0xb28f64: mov             x0, x2
    // 0xb28f68: r2 = LoadClassIdInstr(r0)
    //     0xb28f68: ldur            x2, [x0, #-1]
    //     0xb28f6c: ubfx            x2, x2, #0xc, #0x14
    // 0xb28f70: stp             x3, x0, [SP]
    // 0xb28f74: mov             x0, x2
    // 0xb28f78: mov             lr, x0
    // 0xb28f7c: ldr             lr, [x21, lr, lsl #3]
    // 0xb28f80: blr             lr
    // 0xb28f84: tbz             w0, #4, #0xb28ffc
    // 0xb28f88: ldur            x0, [fp, #-8]
    // 0xb28f8c: LoadField: r1 = r0->field_b7
    //     0xb28f8c: ldur            w1, [x0, #0xb7]
    // 0xb28f90: DecompressPointer r1
    //     0xb28f90: add             x1, x1, HEAP, lsl #32
    // 0xb28f94: cmp             w1, NULL
    // 0xb28f98: b.eq            #0xb28fa4
    // 0xb28f9c: r0 = dispose()
    //     0xb28f9c: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xb28fa0: ldur            x0, [fp, #-8]
    // 0xb28fa4: r1 = <double>
    //     0xb28fa4: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xb28fa8: r0 = CurvedAnimation()
    //     0xb28fa8: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xb28fac: stur            x0, [fp, #-0x18]
    // 0xb28fb0: r16 = Instance_Cubic
    //     0xb28fb0: add             x16, PP, #0x15, lsl #12  ; [pp+0x158f0] Obj!Cubic@129f571
    //     0xb28fb4: ldr             x16, [x16, #0x8f0]
    // 0xb28fb8: str             x16, [SP]
    // 0xb28fbc: mov             x1, x0
    // 0xb28fc0: ldur            x3, [fp, #-0x10]
    // 0xb28fc4: r2 = Instance_Cubic
    //     0xb28fc4: add             x2, PP, #0x15, lsl #12  ; [pp+0x158f0] Obj!Cubic@129f571
    //     0xb28fc8: ldr             x2, [x2, #0x8f0]
    // 0xb28fcc: r4 = const [0, 0x4, 0x1, 0x3, reverseCurve, 0x3, null]
    //     0xb28fcc: add             x4, PP, #0x16, lsl #12  ; [pp+0x16dc0] List(7) [0, 0x4, 0x1, 0x3, "reverseCurve", 0x3, Null]
    //     0xb28fd0: ldr             x4, [x4, #0xdc0]
    // 0xb28fd4: r0 = CurvedAnimation()
    //     0xb28fd4: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xb28fd8: ldur            x0, [fp, #-0x18]
    // 0xb28fdc: ldur            x1, [fp, #-8]
    // 0xb28fe0: StoreField: r1->field_b7 = r0
    //     0xb28fe0: stur            w0, [x1, #0xb7]
    //     0xb28fe4: ldurb           w16, [x1, #-1]
    //     0xb28fe8: ldurb           w17, [x0, #-1]
    //     0xb28fec: and             x16, x17, x16, lsr #2
    //     0xb28ff0: tst             x16, HEAP, lsr #32
    //     0xb28ff4: b.eq            #0xb28ffc
    //     0xb28ff8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb28ffc: r0 = Null
    //     0xb28ffc: mov             x0, NULL
    // 0xb29000: LeaveFrame
    //     0xb29000: mov             SP, fp
    //     0xb29004: ldp             fp, lr, [SP], #0x10
    // 0xb29008: ret
    //     0xb29008: ret             
    // 0xb2900c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2900c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb29010: b               #0xb28f44
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbb1024, size: 0x54
    // 0xbb1024: EnterFrame
    //     0xbb1024: stp             fp, lr, [SP, #-0x10]!
    //     0xbb1028: mov             fp, SP
    // 0xbb102c: AllocStack(0x8)
    //     0xbb102c: sub             SP, SP, #8
    // 0xbb1030: SetupParameters(DialogRoute<X0> this /* r1 => r0, fp-0x8 */)
    //     0xbb1030: mov             x0, x1
    //     0xbb1034: stur            x1, [fp, #-8]
    // 0xbb1038: CheckStackOverflow
    //     0xbb1038: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb103c: cmp             SP, x16
    //     0xbb1040: b.ls            #0xbb1070
    // 0xbb1044: LoadField: r1 = r0->field_b7
    //     0xbb1044: ldur            w1, [x0, #0xb7]
    // 0xbb1048: DecompressPointer r1
    //     0xbb1048: add             x1, x1, HEAP, lsl #32
    // 0xbb104c: cmp             w1, NULL
    // 0xbb1050: b.eq            #0xbb1058
    // 0xbb1054: r0 = dispose()
    //     0xbb1054: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xbb1058: ldur            x1, [fp, #-8]
    // 0xbb105c: r0 = dispose()
    //     0xbb105c: bl              #0xbb10c4  ; [package:flutter/src/widgets/routes.dart] TransitionRoute::dispose
    // 0xbb1060: r0 = Null
    //     0xbb1060: mov             x0, NULL
    // 0xbb1064: LeaveFrame
    //     0xbb1064: mov             SP, fp
    //     0xbb1068: ldp             fp, lr, [SP], #0x10
    // 0xbb106c: ret
    //     0xbb106c: ret             
    // 0xbb1070: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb1070: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb1074: b               #0xbb1044
  }
  _ DialogRoute(/* No info */) {
    // ** addr: 0xd959fc, size: 0xd0
    // 0xd959fc: EnterFrame
    //     0xd959fc: stp             fp, lr, [SP, #-0x10]!
    //     0xd95a00: mov             fp, SP
    // 0xd95a04: AllocStack(0x38)
    //     0xd95a04: sub             SP, SP, #0x38
    // 0xd95a08: SetupParameters(DialogRoute<X0> this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r1, fp-0x28 */, dynamic _ /* r7 => r7, fp-0x30 */)
    //     0xd95a08: mov             x0, x1
    //     0xd95a0c: stur            x1, [fp, #-8]
    //     0xd95a10: mov             x1, x6
    //     0xd95a14: stur            x2, [fp, #-0x10]
    //     0xd95a18: stur            x3, [fp, #-0x18]
    //     0xd95a1c: stur            x5, [fp, #-0x20]
    //     0xd95a20: stur            x6, [fp, #-0x28]
    //     0xd95a24: stur            x7, [fp, #-0x30]
    // 0xd95a28: CheckStackOverflow
    //     0xd95a28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd95a2c: cmp             SP, x16
    //     0xd95a30: b.ls            #0xd95ac4
    // 0xd95a34: r1 = 2
    //     0xd95a34: mov             x1, #2
    // 0xd95a38: r0 = AllocateContext()
    //     0xd95a38: bl              #0x13de838  ; AllocateContextStub
    // 0xd95a3c: mov             x2, x0
    // 0xd95a40: ldur            x0, [fp, #-0x20]
    // 0xd95a44: stur            x2, [fp, #-0x38]
    // 0xd95a48: StoreField: r2->field_f = r0
    //     0xd95a48: stur            w0, [x2, #0xf]
    // 0xd95a4c: ldr             x0, [fp, #0x10]
    // 0xd95a50: StoreField: r2->field_13 = r0
    //     0xd95a50: stur            w0, [x2, #0x13]
    // 0xd95a54: ldur            x1, [fp, #-0x28]
    // 0xd95a58: r0 = of()
    //     0xd95a58: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xd95a5c: r1 = LoadClassIdInstr(r0)
    //     0xd95a5c: ldur            x1, [x0, #-1]
    //     0xd95a60: ubfx            x1, x1, #0xc, #0x14
    // 0xd95a64: mov             x16, x0
    // 0xd95a68: mov             x0, x1
    // 0xd95a6c: mov             x1, x16
    // 0xd95a70: r0 = GDT[cid_x0 + 0x173c8]()
    //     0xd95a70: mov             x17, #0x73c8
    //     0xd95a74: movk            x17, #1, lsl #16
    //     0xd95a78: add             lr, x0, x17
    //     0xd95a7c: ldr             lr, [x21, lr, lsl #3]
    //     0xd95a80: blr             lr
    // 0xd95a84: ldur            x2, [fp, #-0x38]
    // 0xd95a88: r1 = Function '<anonymous closure>':.
    //     0xd95a88: add             x1, PP, #0x15, lsl #12  ; [pp+0x150d8] AnonymousClosure: (0xd95bb8), in [package:flutter/src/material/dialog.dart] DialogRoute::DialogRoute (0xd959fc)
    //     0xd95a8c: ldr             x1, [x1, #0xd8]
    // 0xd95a90: stur            x0, [fp, #-0x20]
    // 0xd95a94: r0 = AllocateClosure()
    //     0xd95a94: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd95a98: ldur            x1, [fp, #-8]
    // 0xd95a9c: ldur            x2, [fp, #-0x10]
    // 0xd95aa0: ldur            x3, [fp, #-0x18]
    // 0xd95aa4: ldur            x5, [fp, #-0x20]
    // 0xd95aa8: mov             x6, x0
    // 0xd95aac: ldur            x7, [fp, #-0x30]
    // 0xd95ab0: r0 = RawDialogRoute()
    //     0xd95ab0: bl              #0xd95acc  ; [package:flutter/src/widgets/routes.dart] RawDialogRoute::RawDialogRoute
    // 0xd95ab4: r0 = Null
    //     0xd95ab4: mov             x0, NULL
    // 0xd95ab8: LeaveFrame
    //     0xd95ab8: mov             SP, fp
    //     0xd95abc: ldp             fp, lr, [SP], #0x10
    // 0xd95ac0: ret
    //     0xd95ac0: ret             
    // 0xd95ac4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd95ac4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd95ac8: b               #0xd95a34
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, Animation<double>, Animation<double>) {
    // ** addr: 0xd95bb8, size: 0xdc
    // 0xd95bb8: EnterFrame
    //     0xd95bb8: stp             fp, lr, [SP, #-0x10]!
    //     0xd95bbc: mov             fp, SP
    // 0xd95bc0: AllocStack(0x20)
    //     0xd95bc0: sub             SP, SP, #0x20
    // 0xd95bc4: SetupParameters([dynamic _ /* r0 */])
    //     0xd95bc4: ldr             x0, [fp, #0x28]
    //     0xd95bc8: ldur            w1, [x0, #0x17]
    //     0xd95bcc: add             x1, x1, HEAP, lsl #32
    //     0xd95bd0: stur            x1, [fp, #-0x10]
    // 0xd95bd4: CheckStackOverflow
    //     0xd95bd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd95bd8: cmp             SP, x16
    //     0xd95bdc: b.ls            #0xd95c8c
    // 0xd95be0: LoadField: r0 = r1->field_f
    //     0xd95be0: ldur            w0, [x1, #0xf]
    // 0xd95be4: DecompressPointer r0
    //     0xd95be4: add             x0, x0, HEAP, lsl #32
    // 0xd95be8: stur            x0, [fp, #-8]
    // 0xd95bec: r0 = Builder()
    //     0xd95bec: bl              #0x858774  ; AllocateBuilderStub -> Builder (size=0x10)
    // 0xd95bf0: mov             x1, x0
    // 0xd95bf4: ldur            x0, [fp, #-8]
    // 0xd95bf8: StoreField: r1->field_b = r0
    //     0xd95bf8: stur            w0, [x1, #0xb]
    // 0xd95bfc: ldur            x0, [fp, #-0x10]
    // 0xd95c00: LoadField: r2 = r0->field_13
    //     0xd95c00: ldur            w2, [x0, #0x13]
    // 0xd95c04: DecompressPointer r2
    //     0xd95c04: add             x2, x2, HEAP, lsl #32
    // 0xd95c08: mov             x16, x1
    // 0xd95c0c: mov             x1, x2
    // 0xd95c10: mov             x2, x16
    // 0xd95c14: r0 = wrap()
    //     0xd95c14: bl              #0x856110  ; [package:flutter/src/widgets/inherited_theme.dart] CapturedThemes::wrap
    // 0xd95c18: stur            x0, [fp, #-8]
    // 0xd95c1c: r0 = SafeArea()
    //     0xd95c1c: bl              #0xd73100  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0xd95c20: mov             x1, x0
    // 0xd95c24: r0 = true
    //     0xd95c24: add             x0, NULL, #0x20  ; true
    // 0xd95c28: stur            x1, [fp, #-0x10]
    // 0xd95c2c: StoreField: r1->field_b = r0
    //     0xd95c2c: stur            w0, [x1, #0xb]
    // 0xd95c30: StoreField: r1->field_f = r0
    //     0xd95c30: stur            w0, [x1, #0xf]
    // 0xd95c34: StoreField: r1->field_13 = r0
    //     0xd95c34: stur            w0, [x1, #0x13]
    // 0xd95c38: ArrayStore: r1[0] = r0  ; List_4
    //     0xd95c38: stur            w0, [x1, #0x17]
    // 0xd95c3c: r0 = Instance_EdgeInsets
    //     0xd95c3c: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xd95c40: StoreField: r1->field_1b = r0
    //     0xd95c40: stur            w0, [x1, #0x1b]
    // 0xd95c44: r0 = false
    //     0xd95c44: add             x0, NULL, #0x30  ; false
    // 0xd95c48: StoreField: r1->field_1f = r0
    //     0xd95c48: stur            w0, [x1, #0x1f]
    // 0xd95c4c: ldur            x0, [fp, #-8]
    // 0xd95c50: StoreField: r1->field_23 = r0
    //     0xd95c50: stur            w0, [x1, #0x23]
    // 0xd95c54: r0 = Semantics()
    //     0xd95c54: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xd95c58: stur            x0, [fp, #-8]
    // 0xd95c5c: r16 = Instance_SemanticsHitTestBehavior
    //     0xd95c5c: add             x16, PP, #0x15, lsl #12  ; [pp+0x150e0] Obj!SemanticsHitTestBehavior@12c7681
    //     0xd95c60: ldr             x16, [x16, #0xe0]
    // 0xd95c64: ldur            lr, [fp, #-0x10]
    // 0xd95c68: stp             lr, x16, [SP]
    // 0xd95c6c: mov             x1, x0
    // 0xd95c70: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, hitTestBehavior, 0x1, null]
    //     0xd95c70: add             x4, PP, #0x15, lsl #12  ; [pp+0x150e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "hitTestBehavior", 0x1, Null]
    //     0xd95c74: ldr             x4, [x4, #0xe8]
    // 0xd95c78: r0 = Semantics()
    //     0xd95c78: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xd95c7c: ldur            x0, [fp, #-8]
    // 0xd95c80: LeaveFrame
    //     0xd95c80: mov             SP, fp
    //     0xd95c84: ldp             fp, lr, [SP], #0x10
    // 0xd95c88: ret
    //     0xd95c88: ret             
    // 0xd95c8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd95c8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd95c90: b               #0xd95be0
  }
}

// class id: 5164, size: 0x4c, field offset: 0x40
class _DialogDefaultsM3 extends DialogThemeData {

  late final ColorScheme _colors; // offset: 0x44
  late final TextTheme _textTheme; // offset: 0x48

  ColorScheme _colors(_DialogDefaultsM3) {
    // ** addr: 0xfb794c, size: 0x44
    // 0xfb794c: EnterFrame
    //     0xfb794c: stp             fp, lr, [SP, #-0x10]!
    //     0xfb7950: mov             fp, SP
    // 0xfb7954: CheckStackOverflow
    //     0xfb7954: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb7958: cmp             SP, x16
    //     0xfb795c: b.ls            #0xfb7988
    // 0xfb7960: ldr             x0, [fp, #0x10]
    // 0xfb7964: LoadField: r1 = r0->field_3f
    //     0xfb7964: ldur            w1, [x0, #0x3f]
    // 0xfb7968: DecompressPointer r1
    //     0xfb7968: add             x1, x1, HEAP, lsl #32
    // 0xfb796c: r0 = of()
    //     0xfb796c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb7970: LoadField: r1 = r0->field_3f
    //     0xfb7970: ldur            w1, [x0, #0x3f]
    // 0xfb7974: DecompressPointer r1
    //     0xfb7974: add             x1, x1, HEAP, lsl #32
    // 0xfb7978: mov             x0, x1
    // 0xfb797c: LeaveFrame
    //     0xfb797c: mov             SP, fp
    //     0xfb7980: ldp             fp, lr, [SP], #0x10
    // 0xfb7984: ret
    //     0xfb7984: ret             
    // 0xfb7988: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb7988: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb798c: b               #0xfb7960
  }
  TextTheme _textTheme(_DialogDefaultsM3) {
    // ** addr: 0xfb8880, size: 0x44
    // 0xfb8880: EnterFrame
    //     0xfb8880: stp             fp, lr, [SP, #-0x10]!
    //     0xfb8884: mov             fp, SP
    // 0xfb8888: CheckStackOverflow
    //     0xfb8888: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb888c: cmp             SP, x16
    //     0xfb8890: b.ls            #0xfb88bc
    // 0xfb8894: ldr             x0, [fp, #0x10]
    // 0xfb8898: LoadField: r1 = r0->field_3f
    //     0xfb8898: ldur            w1, [x0, #0x3f]
    // 0xfb889c: DecompressPointer r1
    //     0xfb889c: add             x1, x1, HEAP, lsl #32
    // 0xfb88a0: r0 = of()
    //     0xfb88a0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb88a4: LoadField: r1 = r0->field_87
    //     0xfb88a4: ldur            w1, [x0, #0x87]
    // 0xfb88a8: DecompressPointer r1
    //     0xfb88a8: add             x1, x1, HEAP, lsl #32
    // 0xfb88ac: mov             x0, x1
    // 0xfb88b0: LeaveFrame
    //     0xfb88b0: mov             SP, fp
    //     0xfb88b4: ldp             fp, lr, [SP], #0x10
    // 0xfb88b8: ret
    //     0xfb88b8: ret             
    // 0xfb88bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb88bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb88c0: b               #0xfb8894
  }
}

// class id: 5166, size: 0x50, field offset: 0x40
class _DialogDefaultsM2 extends DialogThemeData {

  late final ThemeData theme; // offset: 0x44
  late final IconThemeData iconTheme; // offset: 0x4c
  late final TextTheme textTheme; // offset: 0x48

  ThemeData theme(_DialogDefaultsM2) {
    // ** addr: 0xfb7914, size: 0x38
    // 0xfb7914: EnterFrame
    //     0xfb7914: stp             fp, lr, [SP, #-0x10]!
    //     0xfb7918: mov             fp, SP
    // 0xfb791c: CheckStackOverflow
    //     0xfb791c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb7920: cmp             SP, x16
    //     0xfb7924: b.ls            #0xfb7944
    // 0xfb7928: ldr             x0, [fp, #0x10]
    // 0xfb792c: LoadField: r1 = r0->field_3f
    //     0xfb792c: ldur            w1, [x0, #0x3f]
    // 0xfb7930: DecompressPointer r1
    //     0xfb7930: add             x1, x1, HEAP, lsl #32
    // 0xfb7934: r0 = of()
    //     0xfb7934: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb7938: LeaveFrame
    //     0xfb7938: mov             SP, fp
    //     0xfb793c: ldp             fp, lr, [SP], #0x10
    // 0xfb7940: ret
    //     0xfb7940: ret             
    // 0xfb7944: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb7944: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb7948: b               #0xfb7928
  }
  TextTheme textTheme(_DialogDefaultsM2) {
    // ** addr: 0xfb8828, size: 0x58
    // 0xfb8828: EnterFrame
    //     0xfb8828: stp             fp, lr, [SP, #-0x10]!
    //     0xfb882c: mov             fp, SP
    // 0xfb8830: CheckStackOverflow
    //     0xfb8830: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb8834: cmp             SP, x16
    //     0xfb8838: b.ls            #0xfb8878
    // 0xfb883c: ldr             x1, [fp, #0x10]
    // 0xfb8840: LoadField: r0 = r1->field_43
    //     0xfb8840: ldur            w0, [x1, #0x43]
    // 0xfb8844: DecompressPointer r0
    //     0xfb8844: add             x0, x0, HEAP, lsl #32
    // 0xfb8848: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb884c: cmp             w0, w16
    // 0xfb8850: b.ne            #0xfb8860
    // 0xfb8854: r2 = theme
    //     0xfb8854: add             x2, PP, #0x26, lsl #12  ; [pp+0x263d8] Field <_DialogDefaultsM2@664506021.theme>: late final (offset: 0x44)
    //     0xfb8858: ldr             x2, [x2, #0x3d8]
    // 0xfb885c: r0 = InitLateFinalInstanceField()
    //     0xfb885c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfb8860: LoadField: r1 = r0->field_87
    //     0xfb8860: ldur            w1, [x0, #0x87]
    // 0xfb8864: DecompressPointer r1
    //     0xfb8864: add             x1, x1, HEAP, lsl #32
    // 0xfb8868: mov             x0, x1
    // 0xfb886c: LeaveFrame
    //     0xfb886c: mov             SP, fp
    //     0xfb8870: ldp             fp, lr, [SP], #0x10
    // 0xfb8874: ret
    //     0xfb8874: ret             
    // 0xfb8878: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb8878: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb887c: b               #0xfb883c
  }
  IconThemeData iconTheme(_DialogDefaultsM2) {
    // ** addr: 0x1132d14, size: 0x58
    // 0x1132d14: EnterFrame
    //     0x1132d14: stp             fp, lr, [SP, #-0x10]!
    //     0x1132d18: mov             fp, SP
    // 0x1132d1c: CheckStackOverflow
    //     0x1132d1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1132d20: cmp             SP, x16
    //     0x1132d24: b.ls            #0x1132d64
    // 0x1132d28: ldr             x1, [fp, #0x10]
    // 0x1132d2c: LoadField: r0 = r1->field_43
    //     0x1132d2c: ldur            w0, [x1, #0x43]
    // 0x1132d30: DecompressPointer r0
    //     0x1132d30: add             x0, x0, HEAP, lsl #32
    // 0x1132d34: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1132d38: cmp             w0, w16
    // 0x1132d3c: b.ne            #0x1132d4c
    // 0x1132d40: r2 = theme
    //     0x1132d40: add             x2, PP, #0x26, lsl #12  ; [pp+0x263d8] Field <_DialogDefaultsM2@664506021.theme>: late final (offset: 0x44)
    //     0x1132d44: ldr             x2, [x2, #0x3d8]
    // 0x1132d48: r0 = InitLateFinalInstanceField()
    //     0x1132d48: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1132d4c: LoadField: r1 = r0->field_7b
    //     0x1132d4c: ldur            w1, [x0, #0x7b]
    // 0x1132d50: DecompressPointer r1
    //     0x1132d50: add             x1, x1, HEAP, lsl #32
    // 0x1132d54: mov             x0, x1
    // 0x1132d58: LeaveFrame
    //     0x1132d58: mov             SP, fp
    //     0x1132d5c: ldp             fp, lr, [SP], #0x10
    // 0x1132d60: ret
    //     0x1132d60: ret             
    // 0x1132d64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1132d64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1132d68: b               #0x1132d28
  }
}

// class id: 6162, size: 0x14, field offset: 0xc
//   const constructor, 
class _NavigatorShim extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfb8c58, size: 0x13c
    // 0xfb8c58: EnterFrame
    //     0xfb8c58: stp             fp, lr, [SP, #-0x10]!
    //     0xfb8c5c: mov             fp, SP
    // 0xfb8c60: AllocStack(0x18)
    //     0xfb8c60: sub             SP, SP, #0x18
    // 0xfb8c64: SetupParameters(_NavigatorShim this /* r1 => r1, fp-0x8 */)
    //     0xfb8c64: stur            x1, [fp, #-8]
    // 0xfb8c68: r1 = 1
    //     0xfb8c68: mov             x1, #1
    // 0xfb8c6c: r0 = AllocateContext()
    //     0xfb8c6c: bl              #0x13de838  ; AllocateContextStub
    // 0xfb8c70: mov             x2, x0
    // 0xfb8c74: ldur            x0, [fp, #-8]
    // 0xfb8c78: stur            x2, [fp, #-0x18]
    // 0xfb8c7c: StoreField: r2->field_f = r0
    //     0xfb8c7c: stur            w0, [x2, #0xf]
    // 0xfb8c80: LoadField: r3 = r0->field_f
    //     0xfb8c80: ldur            w3, [x0, #0xf]
    // 0xfb8c84: DecompressPointer r3
    //     0xfb8c84: add             x3, x3, HEAP, lsl #32
    // 0xfb8c88: stur            x3, [fp, #-0x10]
    // 0xfb8c8c: r1 = <void?>
    //     0xfb8c8c: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xfb8c90: r0 = _DialogContentPage()
    //     0xfb8c90: bl              #0xfb8d94  ; Allocate_DialogContentPageStub -> _DialogContentPage (size=0x28)
    // 0xfb8c94: mov             x3, x0
    // 0xfb8c98: ldur            x0, [fp, #-0x10]
    // 0xfb8c9c: stur            x3, [fp, #-8]
    // 0xfb8ca0: StoreField: r3->field_23 = r0
    //     0xfb8ca0: stur            w0, [x3, #0x23]
    // 0xfb8ca4: r0 = true
    //     0xfb8ca4: add             x0, NULL, #0x20  ; true
    // 0xfb8ca8: StoreField: r3->field_1f = r0
    //     0xfb8ca8: stur            w0, [x3, #0x1f]
    // 0xfb8cac: r1 = Closure: (bool, Object?) => void from Function '_defaultPopInvokedHandler@42124995': static.
    //     0xfb8cac: add             x1, PP, #0x14, lsl #12  ; [pp+0x14390] Closure: (bool, Object?) => void from Function '_defaultPopInvokedHandler@42124995': static. (0x7f2adb2b6838)
    //     0xfb8cb0: ldr             x1, [x1, #0x390]
    // 0xfb8cb4: StoreField: r3->field_1b = r1
    //     0xfb8cb4: stur            w1, [x3, #0x1b]
    // 0xfb8cb8: r1 = Null
    //     0xfb8cb8: mov             x1, NULL
    // 0xfb8cbc: r2 = 2
    //     0xfb8cbc: mov             x2, #2
    // 0xfb8cc0: r0 = AllocateArray()
    //     0xfb8cc0: bl              #0x13df928  ; AllocateArrayStub
    // 0xfb8cc4: mov             x2, x0
    // 0xfb8cc8: ldur            x0, [fp, #-8]
    // 0xfb8ccc: stur            x2, [fp, #-0x10]
    // 0xfb8cd0: StoreField: r2->field_f = r0
    //     0xfb8cd0: stur            w0, [x2, #0xf]
    // 0xfb8cd4: r1 = <Page<void?>>
    //     0xfb8cd4: add             x1, PP, #0x80, lsl #12  ; [pp+0x80ad8] TypeArguments: <Page<void?>>
    //     0xfb8cd8: ldr             x1, [x1, #0xad8]
    // 0xfb8cdc: r0 = AllocateGrowableArray()
    //     0xfb8cdc: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xfb8ce0: mov             x1, x0
    // 0xfb8ce4: ldur            x0, [fp, #-0x10]
    // 0xfb8ce8: stur            x1, [fp, #-8]
    // 0xfb8cec: StoreField: r1->field_f = r0
    //     0xfb8cec: stur            w0, [x1, #0xf]
    // 0xfb8cf0: r0 = 2
    //     0xfb8cf0: mov             x0, #2
    // 0xfb8cf4: StoreField: r1->field_b = r0
    //     0xfb8cf4: stur            w0, [x1, #0xb]
    // 0xfb8cf8: r0 = Navigator()
    //     0xfb8cf8: bl              #0xd5cdd0  ; AllocateNavigatorStub -> Navigator (size=0x44)
    // 0xfb8cfc: mov             x3, x0
    // 0xfb8d00: ldur            x0, [fp, #-8]
    // 0xfb8d04: stur            x3, [fp, #-0x10]
    // 0xfb8d08: StoreField: r3->field_b = r0
    //     0xfb8d08: stur            w0, [x3, #0xb]
    // 0xfb8d0c: ldur            x2, [fp, #-0x18]
    // 0xfb8d10: r1 = Function '<anonymous closure>':.
    //     0xfb8d10: add             x1, PP, #0x80, lsl #12  ; [pp+0x80ae0] AnonymousClosure: (0xfb9374), in [package:flutter/src/material/dialog.dart] _NavigatorShim::build (0xfb8c58)
    //     0xfb8d14: ldr             x1, [x1, #0xae0]
    // 0xfb8d18: r0 = AllocateClosure()
    //     0xfb8d18: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfb8d1c: mov             x1, x0
    // 0xfb8d20: ldur            x0, [fp, #-0x10]
    // 0xfb8d24: StoreField: r0->field_f = r1
    //     0xfb8d24: stur            w1, [x0, #0xf]
    // 0xfb8d28: r1 = Closure: (NavigatorState, String) => List<Route<dynamic>> from Function 'defaultGenerateInitialRoutes': static.
    //     0xfb8d28: add             x1, PP, #0x80, lsl #12  ; [pp+0x80ae8] Closure: (NavigatorState, String) => List<Route<dynamic>> from Function 'defaultGenerateInitialRoutes': static. (0x7f2adae9fdc4)
    //     0xfb8d2c: ldr             x1, [x1, #0xae8]
    // 0xfb8d30: StoreField: r0->field_33 = r1
    //     0xfb8d30: stur            w1, [x0, #0x33]
    // 0xfb8d34: r1 = Instance_DefaultTransitionDelegate
    //     0xfb8d34: add             x1, PP, #0x80, lsl #12  ; [pp+0x80af0] Obj!DefaultTransitionDelegate@128a171
    //     0xfb8d38: ldr             x1, [x1, #0xaf0]
    // 0xfb8d3c: ArrayStore: r0[0] = r1  ; List_4
    //     0xfb8d3c: stur            w1, [x0, #0x17]
    // 0xfb8d40: r1 = false
    //     0xfb8d40: add             x1, NULL, #0x30  ; false
    // 0xfb8d44: StoreField: r0->field_37 = r1
    //     0xfb8d44: stur            w1, [x0, #0x37]
    // 0xfb8d48: r1 = Instance_Clip
    //     0xfb8d48: add             x1, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xfb8d4c: ldr             x1, [x1, #0x850]
    // 0xfb8d50: StoreField: r0->field_3b = r1
    //     0xfb8d50: stur            w1, [x0, #0x3b]
    // 0xfb8d54: r1 = const []
    //     0xfb8d54: add             x1, PP, #0x80, lsl #12  ; [pp+0x80af8] List<NavigatorObserver>(0)
    //     0xfb8d58: ldr             x1, [x1, #0xaf8]
    // 0xfb8d5c: StoreField: r0->field_23 = r1
    //     0xfb8d5c: stur            w1, [x0, #0x23]
    // 0xfb8d60: r1 = true
    //     0xfb8d60: add             x1, NULL, #0x20  ; true
    // 0xfb8d64: StoreField: r0->field_3f = r1
    //     0xfb8d64: stur            w1, [x0, #0x3f]
    // 0xfb8d68: r1 = Instance_TraversalEdgeBehavior
    //     0xfb8d68: add             x1, PP, #0x80, lsl #12  ; [pp+0x80b00] Obj!TraversalEdgeBehavior@12c3141
    //     0xfb8d6c: ldr             x1, [x1, #0xb00]
    // 0xfb8d70: StoreField: r0->field_2b = r1
    //     0xfb8d70: stur            w1, [x0, #0x2b]
    // 0xfb8d74: r1 = Instance_TraversalEdgeBehavior
    //     0xfb8d74: ldr             x1, [PP, #0x2090]  ; [pp+0x2090] Obj!TraversalEdgeBehavior@12c3101
    // 0xfb8d78: StoreField: r0->field_2f = r1
    //     0xfb8d78: stur            w1, [x0, #0x2f]
    // 0xfb8d7c: r0 = HeroControllerScope()
    //     0xfb8d7c: bl              #0xd6cd9c  ; AllocateHeroControllerScopeStub -> HeroControllerScope (size=0x14)
    // 0xfb8d80: ldur            x1, [fp, #-0x10]
    // 0xfb8d84: StoreField: r0->field_b = r1
    //     0xfb8d84: stur            w1, [x0, #0xb]
    // 0xfb8d88: LeaveFrame
    //     0xfb8d88: mov             SP, fp
    //     0xfb8d8c: ldp             fp, lr, [SP], #0x10
    // 0xfb8d90: ret
    //     0xfb8d90: ret             
  }
  [closure] bool <anonymous closure>(dynamic, Route<dynamic>, dynamic) {
    // ** addr: 0xfb9374, size: 0x70
    // 0xfb9374: EnterFrame
    //     0xfb9374: stp             fp, lr, [SP, #-0x10]!
    //     0xfb9378: mov             fp, SP
    // 0xfb937c: AllocStack(0x10)
    //     0xfb937c: sub             SP, SP, #0x10
    // 0xfb9380: SetupParameters([dynamic _ /* r0 */])
    //     0xfb9380: ldr             x0, [fp, #0x20]
    //     0xfb9384: ldur            w1, [x0, #0x17]
    //     0xfb9388: add             x1, x1, HEAP, lsl #32
    // 0xfb938c: CheckStackOverflow
    //     0xfb938c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb9390: cmp             SP, x16
    //     0xfb9394: b.ls            #0xfb93d8
    // 0xfb9398: LoadField: r0 = r1->field_f
    //     0xfb9398: ldur            w0, [x1, #0xf]
    // 0xfb939c: DecompressPointer r0
    //     0xfb939c: add             x0, x0, HEAP, lsl #32
    // 0xfb93a0: LoadField: r1 = r0->field_b
    //     0xfb93a0: ldur            w1, [x0, #0xb]
    // 0xfb93a4: DecompressPointer r1
    //     0xfb93a4: add             x1, x1, HEAP, lsl #32
    // 0xfb93a8: cmp             w1, NULL
    // 0xfb93ac: b.eq            #0xfb93e0
    // 0xfb93b0: ldr             x16, [fp, #0x10]
    // 0xfb93b4: stp             x16, x1, [SP]
    // 0xfb93b8: mov             x0, x1
    // 0xfb93bc: ClosureCall
    //     0xfb93bc: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xfb93c0: ldur            x2, [x0, #0x1f]
    //     0xfb93c4: blr             x2
    // 0xfb93c8: r0 = false
    //     0xfb93c8: add             x0, NULL, #0x30  ; false
    // 0xfb93cc: LeaveFrame
    //     0xfb93cc: mov             SP, fp
    //     0xfb93d0: ldp             fp, lr, [SP], #0x10
    // 0xfb93d4: ret
    //     0xfb93d4: ret             
    // 0xfb93d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb93d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb93dc: b               #0xfb9398
    // 0xfb93e0: r0 = NullErrorSharedWithoutFPURegs()
    //     0xfb93e0: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 6163, size: 0x14, field offset: 0xc
//   const constructor, 
class _DialogPopScope extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfb8ae4, size: 0x98
    // 0xfb8ae4: EnterFrame
    //     0xfb8ae4: stp             fp, lr, [SP, #-0x10]!
    //     0xfb8ae8: mov             fp, SP
    // 0xfb8aec: AllocStack(0x18)
    //     0xfb8aec: sub             SP, SP, #0x18
    // 0xfb8af0: SetupParameters(_DialogPopScope this /* r1 => r1, fp-0x8 */)
    //     0xfb8af0: stur            x1, [fp, #-8]
    // 0xfb8af4: r1 = 1
    //     0xfb8af4: mov             x1, #1
    // 0xfb8af8: r0 = AllocateContext()
    //     0xfb8af8: bl              #0x13de838  ; AllocateContextStub
    // 0xfb8afc: mov             x3, x0
    // 0xfb8b00: ldur            x0, [fp, #-8]
    // 0xfb8b04: stur            x3, [fp, #-0x10]
    // 0xfb8b08: StoreField: r3->field_f = r0
    //     0xfb8b08: stur            w0, [x3, #0xf]
    // 0xfb8b0c: mov             x2, x3
    // 0xfb8b10: r1 = Function '<anonymous closure>':.
    //     0xfb8b10: add             x1, PP, #0x26, lsl #12  ; [pp+0x265b8] AnonymousClosure: (0xfb8bf4), in [package:flutter/src/material/dialog.dart] _DialogPopScope::build (0xfb8ae4)
    //     0xfb8b14: ldr             x1, [x1, #0x5b8]
    // 0xfb8b18: r0 = AllocateClosure()
    //     0xfb8b18: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfb8b1c: stur            x0, [fp, #-8]
    // 0xfb8b20: r0 = Builder()
    //     0xfb8b20: bl              #0x858774  ; AllocateBuilderStub -> Builder (size=0x10)
    // 0xfb8b24: mov             x2, x0
    // 0xfb8b28: ldur            x0, [fp, #-8]
    // 0xfb8b2c: stur            x2, [fp, #-0x18]
    // 0xfb8b30: StoreField: r2->field_b = r0
    //     0xfb8b30: stur            w0, [x2, #0xb]
    // 0xfb8b34: r1 = <Object>
    //     0xfb8b34: ldr             x1, [PP, #0x720]  ; [pp+0x720] TypeArguments: <Object>
    // 0xfb8b38: r0 = PopScope()
    //     0xfb8b38: bl              #0xd55f9c  ; AllocatePopScopeStub -> PopScope<X0> (size=0x1c)
    // 0xfb8b3c: mov             x3, x0
    // 0xfb8b40: ldur            x0, [fp, #-0x18]
    // 0xfb8b44: stur            x3, [fp, #-8]
    // 0xfb8b48: StoreField: r3->field_f = r0
    //     0xfb8b48: stur            w0, [x3, #0xf]
    // 0xfb8b4c: r0 = false
    //     0xfb8b4c: add             x0, NULL, #0x30  ; false
    // 0xfb8b50: ArrayStore: r3[0] = r0  ; List_4
    //     0xfb8b50: stur            w0, [x3, #0x17]
    // 0xfb8b54: ldur            x2, [fp, #-0x10]
    // 0xfb8b58: r1 = Function '<anonymous closure>':.
    //     0xfb8b58: add             x1, PP, #0x26, lsl #12  ; [pp+0x265c0] AnonymousClosure: (0xfb8b7c), in [package:flutter/src/material/dialog.dart] _DialogPopScope::build (0xfb8ae4)
    //     0xfb8b5c: ldr             x1, [x1, #0x5c0]
    // 0xfb8b60: r0 = AllocateClosure()
    //     0xfb8b60: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfb8b64: mov             x1, x0
    // 0xfb8b68: ldur            x0, [fp, #-8]
    // 0xfb8b6c: StoreField: r0->field_13 = r1
    //     0xfb8b6c: stur            w1, [x0, #0x13]
    // 0xfb8b70: LeaveFrame
    //     0xfb8b70: mov             SP, fp
    //     0xfb8b74: ldp             fp, lr, [SP], #0x10
    // 0xfb8b78: ret
    //     0xfb8b78: ret             
  }
  [closure] void <anonymous closure>(dynamic, bool, Object?) {
    // ** addr: 0xfb8b7c, size: 0x78
    // 0xfb8b7c: EnterFrame
    //     0xfb8b7c: stp             fp, lr, [SP, #-0x10]!
    //     0xfb8b80: mov             fp, SP
    // 0xfb8b84: AllocStack(0x10)
    //     0xfb8b84: sub             SP, SP, #0x10
    // 0xfb8b88: SetupParameters([dynamic _ /* r0 */])
    //     0xfb8b88: ldr             x0, [fp, #0x20]
    //     0xfb8b8c: ldur            w1, [x0, #0x17]
    //     0xfb8b90: add             x1, x1, HEAP, lsl #32
    // 0xfb8b94: CheckStackOverflow
    //     0xfb8b94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb8b98: cmp             SP, x16
    //     0xfb8b9c: b.ls            #0xfb8be8
    // 0xfb8ba0: ldr             x0, [fp, #0x18]
    // 0xfb8ba4: tbz             w0, #4, #0xfb8bd8
    // 0xfb8ba8: LoadField: r0 = r1->field_f
    //     0xfb8ba8: ldur            w0, [x1, #0xf]
    // 0xfb8bac: DecompressPointer r0
    //     0xfb8bac: add             x0, x0, HEAP, lsl #32
    // 0xfb8bb0: LoadField: r1 = r0->field_f
    //     0xfb8bb0: ldur            w1, [x0, #0xf]
    // 0xfb8bb4: DecompressPointer r1
    //     0xfb8bb4: add             x1, x1, HEAP, lsl #32
    // 0xfb8bb8: cmp             w1, NULL
    // 0xfb8bbc: b.eq            #0xfb8bf0
    // 0xfb8bc0: ldr             x16, [fp, #0x10]
    // 0xfb8bc4: stp             x16, x1, [SP]
    // 0xfb8bc8: mov             x0, x1
    // 0xfb8bcc: ClosureCall
    //     0xfb8bcc: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xfb8bd0: ldur            x2, [x0, #0x1f]
    //     0xfb8bd4: blr             x2
    // 0xfb8bd8: r0 = Null
    //     0xfb8bd8: mov             x0, NULL
    // 0xfb8bdc: LeaveFrame
    //     0xfb8bdc: mov             SP, fp
    //     0xfb8be0: ldp             fp, lr, [SP], #0x10
    // 0xfb8be4: ret
    //     0xfb8be4: ret             
    // 0xfb8be8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb8be8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb8bec: b               #0xfb8ba0
    // 0xfb8bf0: r0 = NullErrorSharedWithoutFPURegs()
    //     0xfb8bf0: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] _NavigatorShim <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xfb8bf4, size: 0x58
    // 0xfb8bf4: EnterFrame
    //     0xfb8bf4: stp             fp, lr, [SP, #-0x10]!
    //     0xfb8bf8: mov             fp, SP
    // 0xfb8bfc: AllocStack(0x10)
    //     0xfb8bfc: sub             SP, SP, #0x10
    // 0xfb8c00: SetupParameters([dynamic _ /* r0 */])
    //     0xfb8c00: ldr             x0, [fp, #0x18]
    //     0xfb8c04: ldur            w1, [x0, #0x17]
    //     0xfb8c08: add             x1, x1, HEAP, lsl #32
    // 0xfb8c0c: LoadField: r0 = r1->field_f
    //     0xfb8c0c: ldur            w0, [x1, #0xf]
    // 0xfb8c10: DecompressPointer r0
    //     0xfb8c10: add             x0, x0, HEAP, lsl #32
    // 0xfb8c14: LoadField: r1 = r0->field_f
    //     0xfb8c14: ldur            w1, [x0, #0xf]
    // 0xfb8c18: DecompressPointer r1
    //     0xfb8c18: add             x1, x1, HEAP, lsl #32
    // 0xfb8c1c: stur            x1, [fp, #-0x10]
    // 0xfb8c20: LoadField: r2 = r0->field_b
    //     0xfb8c20: ldur            w2, [x0, #0xb]
    // 0xfb8c24: DecompressPointer r2
    //     0xfb8c24: add             x2, x2, HEAP, lsl #32
    // 0xfb8c28: stur            x2, [fp, #-8]
    // 0xfb8c2c: r0 = _NavigatorShim()
    //     0xfb8c2c: bl              #0xfb8c4c  ; Allocate_NavigatorShimStub -> _NavigatorShim (size=0x14)
    // 0xfb8c30: ldur            x1, [fp, #-8]
    // 0xfb8c34: StoreField: r0->field_f = r1
    //     0xfb8c34: stur            w1, [x0, #0xf]
    // 0xfb8c38: ldur            x1, [fp, #-0x10]
    // 0xfb8c3c: StoreField: r0->field_b = r1
    //     0xfb8c3c: stur            w1, [x0, #0xb]
    // 0xfb8c40: LeaveFrame
    //     0xfb8c40: mov             SP, fp
    //     0xfb8c44: ldp             fp, lr, [SP], #0x10
    // 0xfb8c48: ret
    //     0xfb8c48: ret             
  }
}

// class id: 6164, size: 0x10, field offset: 0xc
//   const constructor, 
class _FullWindowDialogWrapper extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfb88c4, size: 0xe8
    // 0xfb88c4: EnterFrame
    //     0xfb88c4: stp             fp, lr, [SP, #-0x10]!
    //     0xfb88c8: mov             fp, SP
    // 0xfb88cc: AllocStack(0x28)
    //     0xfb88cc: sub             SP, SP, #0x28
    // 0xfb88d0: SetupParameters(_FullWindowDialogWrapper this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfb88d0: mov             x0, x2
    //     0xfb88d4: stur            x2, [fp, #-0x10]
    //     0xfb88d8: mov             x2, x1
    //     0xfb88dc: stur            x1, [fp, #-8]
    // 0xfb88e0: CheckStackOverflow
    //     0xfb88e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb88e4: cmp             SP, x16
    //     0xfb88e8: b.ls            #0xfb89a4
    // 0xfb88ec: mov             x1, x0
    // 0xfb88f0: r0 = of()
    //     0xfb88f0: bl              #0xd95ca0  ; [package:flutter/src/material/dialog_theme.dart] DialogTheme::of
    // 0xfb88f4: mov             x1, x0
    // 0xfb88f8: r0 = copyWith()
    //     0xfb88f8: bl              #0xfb8a68  ; [package:flutter/src/material/dialog_theme.dart] DialogThemeData::copyWith
    // 0xfb88fc: mov             x2, x0
    // 0xfb8900: ldur            x0, [fp, #-8]
    // 0xfb8904: stur            x2, [fp, #-0x20]
    // 0xfb8908: LoadField: r3 = r0->field_b
    //     0xfb8908: ldur            w3, [x0, #0xb]
    // 0xfb890c: DecompressPointer r3
    //     0xfb890c: add             x3, x3, HEAP, lsl #32
    // 0xfb8910: ldur            x1, [fp, #-0x10]
    // 0xfb8914: stur            x3, [fp, #-0x18]
    // 0xfb8918: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xfb8918: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xfb891c: r0 = _of()
    //     0xfb891c: bl              #0x8651cc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0xfb8920: mov             x1, x0
    // 0xfb8924: r0 = removeViewPadding()
    //     0xfb8924: bl              #0xfb89b8  ; [package:flutter/src/widgets/media_query.dart] MediaQueryData::removeViewPadding
    // 0xfb8928: r1 = <_MediaQueryAspect>
    //     0xfb8928: add             x1, PP, #0x12, lsl #12  ; [pp+0x12828] TypeArguments: <_MediaQueryAspect>
    //     0xfb892c: ldr             x1, [x1, #0x828]
    // 0xfb8930: stur            x0, [fp, #-8]
    // 0xfb8934: r0 = MediaQuery()
    //     0xfb8934: bl              #0xd0af24  ; AllocateMediaQueryStub -> MediaQuery (size=0x18)
    // 0xfb8938: mov             x2, x0
    // 0xfb893c: ldur            x0, [fp, #-8]
    // 0xfb8940: stur            x2, [fp, #-0x28]
    // 0xfb8944: StoreField: r2->field_13 = r0
    //     0xfb8944: stur            w0, [x2, #0x13]
    // 0xfb8948: ldur            x0, [fp, #-0x18]
    // 0xfb894c: StoreField: r2->field_b = r0
    //     0xfb894c: stur            w0, [x2, #0xb]
    // 0xfb8950: r1 = <_MediaQueryAspect>
    //     0xfb8950: add             x1, PP, #0x12, lsl #12  ; [pp+0x12828] TypeArguments: <_MediaQueryAspect>
    //     0xfb8954: ldr             x1, [x1, #0x828]
    // 0xfb8958: r0 = MediaQuery()
    //     0xfb8958: bl              #0xd0af24  ; AllocateMediaQueryStub -> MediaQuery (size=0x18)
    // 0xfb895c: mov             x1, x0
    // 0xfb8960: ldur            x2, [fp, #-0x28]
    // 0xfb8964: ldur            x3, [fp, #-0x10]
    // 0xfb8968: stur            x0, [fp, #-8]
    // 0xfb896c: r0 = MediaQuery.removeViewInsets()
    //     0xfb896c: bl              #0xde3a9c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::MediaQuery.removeViewInsets
    // 0xfb8970: r0 = DialogTheme()
    //     0xfb8970: bl              #0xfb89ac  ; AllocateDialogThemeStub -> DialogTheme (size=0x14)
    // 0xfb8974: mov             x2, x0
    // 0xfb8978: ldur            x0, [fp, #-0x20]
    // 0xfb897c: stur            x2, [fp, #-0x10]
    // 0xfb8980: StoreField: r2->field_f = r0
    //     0xfb8980: stur            w0, [x2, #0xf]
    // 0xfb8984: ldur            x0, [fp, #-8]
    // 0xfb8988: StoreField: r2->field_b = r0
    //     0xfb8988: stur            w0, [x2, #0xb]
    // 0xfb898c: mov             x1, x2
    // 0xfb8990: r0 = Shader._()
    //     0xfb8990: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xfb8994: ldur            x0, [fp, #-0x10]
    // 0xfb8998: LeaveFrame
    //     0xfb8998: mov             SP, fp
    //     0xfb899c: ldp             fp, lr, [SP], #0x10
    // 0xfb89a0: ret
    //     0xfb89a0: ret             
    // 0xfb89a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb89a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb89a8: b               #0xfb88ec
  }
}

// class id: 6165, size: 0x70, field offset: 0xc
//   const constructor, 
class AlertDialog extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfb7990, size: 0xde4
    // 0xfb7990: EnterFrame
    //     0xfb7990: stp             fp, lr, [SP, #-0x10]!
    //     0xfb7994: mov             fp, SP
    // 0xfb7998: AllocStack(0xa8)
    //     0xfb7998: sub             SP, SP, #0xa8
    // 0xfb799c: SetupParameters(AlertDialog this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfb799c: mov             x0, x2
    //     0xfb79a0: stur            x2, [fp, #-0x10]
    //     0xfb79a4: mov             x2, x1
    //     0xfb79a8: stur            x1, [fp, #-8]
    // 0xfb79ac: CheckStackOverflow
    //     0xfb79ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb79b0: cmp             SP, x16
    //     0xfb79b4: b.ls            #0xfb8754
    // 0xfb79b8: mov             x1, x0
    // 0xfb79bc: r0 = of()
    //     0xfb79bc: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb79c0: ldur            x1, [fp, #-0x10]
    // 0xfb79c4: stur            x0, [fp, #-0x18]
    // 0xfb79c8: r0 = of()
    //     0xfb79c8: bl              #0xd95ca0  ; [package:flutter/src/material/dialog_theme.dart] DialogTheme::of
    // 0xfb79cc: ldur            x0, [fp, #-0x18]
    // 0xfb79d0: LoadField: r1 = r0->field_2f
    //     0xfb79d0: ldur            w1, [x0, #0x2f]
    // 0xfb79d4: DecompressPointer r1
    //     0xfb79d4: add             x1, x1, HEAP, lsl #32
    // 0xfb79d8: stur            x1, [fp, #-0x20]
    // 0xfb79dc: tbnz            w1, #4, #0xfb7a40
    // 0xfb79e0: ldur            x0, [fp, #-0x10]
    // 0xfb79e4: r0 = _DialogDefaultsM3()
    //     0xfb79e4: bl              #0xfb7908  ; Allocate_DialogDefaultsM3Stub -> _DialogDefaultsM3 (size=0x4c)
    // 0xfb79e8: mov             x1, x0
    // 0xfb79ec: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb79f0: StoreField: r1->field_43 = r0
    //     0xfb79f0: stur            w0, [x1, #0x43]
    // 0xfb79f4: StoreField: r1->field_47 = r0
    //     0xfb79f4: stur            w0, [x1, #0x47]
    // 0xfb79f8: ldur            x2, [fp, #-0x10]
    // 0xfb79fc: StoreField: r1->field_3f = r2
    //     0xfb79fc: stur            w2, [x1, #0x3f]
    // 0xfb7a00: r0 = 6.000000
    //     0xfb7a00: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c438] 6
    //     0xfb7a04: ldr             x0, [x0, #0x438]
    // 0xfb7a08: StoreField: r1->field_b = r0
    //     0xfb7a08: stur            w0, [x1, #0xb]
    // 0xfb7a0c: r0 = Instance_RoundedRectangleBorder
    //     0xfb7a0c: add             x0, PP, #0x26, lsl #12  ; [pp+0x26370] Obj!RoundedRectangleBorder@129ec41
    //     0xfb7a10: ldr             x0, [x0, #0x370]
    // 0xfb7a14: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb7a14: stur            w0, [x1, #0x17]
    // 0xfb7a18: r3 = Instance_Alignment
    //     0xfb7a18: add             x3, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfb7a1c: ldr             x3, [x3, #0xb80]
    // 0xfb7a20: StoreField: r1->field_1b = r3
    //     0xfb7a20: stur            w3, [x1, #0x1b]
    // 0xfb7a24: r4 = Instance_Clip
    //     0xfb7a24: add             x4, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb7a28: ldr             x4, [x4, #0x840]
    // 0xfb7a2c: StoreField: r1->field_37 = r4
    //     0xfb7a2c: stur            w4, [x1, #0x37]
    // 0xfb7a30: mov             x0, x2
    // 0xfb7a34: mov             x2, x4
    // 0xfb7a38: mov             x4, x1
    // 0xfb7a3c: b               #0xfb7aac
    // 0xfb7a40: ldur            x2, [fp, #-0x10]
    // 0xfb7a44: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb7a48: r3 = Instance_Alignment
    //     0xfb7a48: add             x3, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfb7a4c: ldr             x3, [x3, #0xb80]
    // 0xfb7a50: r4 = Instance_Clip
    //     0xfb7a50: add             x4, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb7a54: ldr             x4, [x4, #0x840]
    // 0xfb7a58: r0 = _DialogDefaultsM2()
    //     0xfb7a58: bl              #0xfb78fc  ; Allocate_DialogDefaultsM2Stub -> _DialogDefaultsM2 (size=0x50)
    // 0xfb7a5c: mov             x1, x0
    // 0xfb7a60: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb7a64: StoreField: r1->field_43 = r0
    //     0xfb7a64: stur            w0, [x1, #0x43]
    // 0xfb7a68: StoreField: r1->field_47 = r0
    //     0xfb7a68: stur            w0, [x1, #0x47]
    // 0xfb7a6c: StoreField: r1->field_4b = r0
    //     0xfb7a6c: stur            w0, [x1, #0x4b]
    // 0xfb7a70: ldur            x0, [fp, #-0x10]
    // 0xfb7a74: StoreField: r1->field_3f = r0
    //     0xfb7a74: stur            w0, [x1, #0x3f]
    // 0xfb7a78: r2 = 24.000000
    //     0xfb7a78: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0xfb7a7c: ldr             x2, [x2, #0x4d0]
    // 0xfb7a80: StoreField: r1->field_b = r2
    //     0xfb7a80: stur            w2, [x1, #0xb]
    // 0xfb7a84: r2 = Instance_RoundedRectangleBorder
    //     0xfb7a84: add             x2, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0xfb7a88: ldr             x2, [x2, #0x218]
    // 0xfb7a8c: ArrayStore: r1[0] = r2  ; List_4
    //     0xfb7a8c: stur            w2, [x1, #0x17]
    // 0xfb7a90: r2 = Instance_Alignment
    //     0xfb7a90: add             x2, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfb7a94: ldr             x2, [x2, #0xb80]
    // 0xfb7a98: StoreField: r1->field_1b = r2
    //     0xfb7a98: stur            w2, [x1, #0x1b]
    // 0xfb7a9c: r2 = Instance_Clip
    //     0xfb7a9c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb7aa0: ldr             x2, [x2, #0x840]
    // 0xfb7aa4: StoreField: r1->field_37 = r2
    //     0xfb7aa4: stur            w2, [x1, #0x37]
    // 0xfb7aa8: mov             x4, x1
    // 0xfb7aac: ldur            x3, [fp, #-8]
    // 0xfb7ab0: mov             x1, x0
    // 0xfb7ab4: stur            x4, [fp, #-0x18]
    // 0xfb7ab8: r0 = of()
    //     0xfb7ab8: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xfb7abc: r1 = LoadClassIdInstr(r0)
    //     0xfb7abc: ldur            x1, [x0, #-1]
    //     0xfb7ac0: ubfx            x1, x1, #0xc, #0x14
    // 0xfb7ac4: mov             x16, x0
    // 0xfb7ac8: mov             x0, x1
    // 0xfb7acc: mov             x1, x16
    // 0xfb7ad0: r0 = GDT[cid_x0 + 0x1641f]()
    //     0xfb7ad0: mov             x17, #0x641f
    //     0xfb7ad4: movk            x17, #1, lsl #16
    //     0xfb7ad8: add             lr, x0, x17
    //     0xfb7adc: ldr             lr, [x21, lr, lsl #3]
    //     0xfb7ae0: blr             lr
    // 0xfb7ae4: ldur            x1, [fp, #-0x10]
    // 0xfb7ae8: stur            x0, [fp, #-0x28]
    // 0xfb7aec: r0 = textScalerOf()
    //     0xfb7aec: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0xfb7af0: r1 = LoadClassIdInstr(r0)
    //     0xfb7af0: ldur            x1, [x0, #-1]
    //     0xfb7af4: ubfx            x1, x1, #0xc, #0x14
    // 0xfb7af8: mov             x16, x0
    // 0xfb7afc: mov             x0, x1
    // 0xfb7b00: mov             x1, x16
    // 0xfb7b04: d0 = 14.000000
    //     0xfb7b04: fmov            d0, #14.00000000
    // 0xfb7b08: r0 = GDT[cid_x0 + -0x1000]()
    //     0xfb7b08: sub             lr, x0, #1, lsl #12
    //     0xfb7b0c: ldr             lr, [x21, lr, lsl #3]
    //     0xfb7b10: blr             lr
    // 0xfb7b14: LoadField: d0 = r0->field_7
    //     0xfb7b14: ldur            d0, [x0, #7]
    // 0xfb7b18: d1 = 14.000000
    //     0xfb7b18: fmov            d1, #14.00000000
    // 0xfb7b1c: fdiv            d2, d0, d1
    // 0xfb7b20: mov             v0.16b, v2.16b
    // 0xfb7b24: r0 = _scalePadding()
    //     0xfb7b24: bl              #0xfb8774  ; [package:flutter/src/material/dialog.dart] ::_scalePadding
    // 0xfb7b28: ldur            x1, [fp, #-0x10]
    // 0xfb7b2c: stur            d0, [fp, #-0x60]
    // 0xfb7b30: r0 = maybeOf()
    //     0xfb7b30: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xfb7b34: ldur            x0, [fp, #-8]
    // 0xfb7b38: LoadField: r1 = r0->field_f
    //     0xfb7b38: ldur            w1, [x0, #0xf]
    // 0xfb7b3c: DecompressPointer r1
    //     0xfb7b3c: add             x1, x1, HEAP, lsl #32
    // 0xfb7b40: stur            x1, [fp, #-0x10]
    // 0xfb7b44: cmp             w1, NULL
    // 0xfb7b48: b.eq            #0xfb7d28
    // 0xfb7b4c: r0 = EdgeInsets()
    //     0xfb7b4c: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xfb7b50: d0 = 24.000000
    //     0xfb7b50: fmov            d0, #24.00000000
    // 0xfb7b54: StoreField: r0->field_7 = d0
    //     0xfb7b54: stur            d0, [x0, #7]
    // 0xfb7b58: StoreField: r0->field_f = d0
    //     0xfb7b58: stur            d0, [x0, #0xf]
    // 0xfb7b5c: ArrayStore: r0[0] = d0  ; List_8
    //     0xfb7b5c: stur            d0, [x0, #0x17]
    // 0xfb7b60: StoreField: r0->field_1f = rZR
    //     0xfb7b60: stur            xzr, [x0, #0x1f]
    // 0xfb7b64: ldur            x1, [fp, #-8]
    // 0xfb7b68: LoadField: r2 = r1->field_13
    //     0xfb7b68: ldur            w2, [x1, #0x13]
    // 0xfb7b6c: DecompressPointer r2
    //     0xfb7b6c: add             x2, x2, HEAP, lsl #32
    // 0xfb7b70: cmp             w2, NULL
    // 0xfb7b74: b.ne            #0xfb7b7c
    // 0xfb7b78: r2 = Null
    //     0xfb7b78: mov             x2, NULL
    // 0xfb7b7c: cmp             w2, NULL
    // 0xfb7b80: b.ne            #0xfb7b88
    // 0xfb7b84: mov             x2, x0
    // 0xfb7b88: ldur            x0, [fp, #-0x18]
    // 0xfb7b8c: ldur            d1, [fp, #-0x60]
    // 0xfb7b90: LoadField: d2 = r2->field_7
    //     0xfb7b90: ldur            d2, [x2, #7]
    // 0xfb7b94: fmul            d3, d2, d1
    // 0xfb7b98: stur            d3, [fp, #-0x80]
    // 0xfb7b9c: ArrayLoad: d2 = r2[0]  ; List_8
    //     0xfb7b9c: ldur            d2, [x2, #0x17]
    // 0xfb7ba0: fmul            d4, d2, d1
    // 0xfb7ba4: stur            d4, [fp, #-0x78]
    // 0xfb7ba8: LoadField: d2 = r2->field_f
    //     0xfb7ba8: ldur            d2, [x2, #0xf]
    // 0xfb7bac: fmul            d5, d2, d1
    // 0xfb7bb0: stur            d5, [fp, #-0x70]
    // 0xfb7bb4: LoadField: d2 = r2->field_1f
    //     0xfb7bb4: ldur            d2, [x2, #0x1f]
    // 0xfb7bb8: stur            d2, [fp, #-0x68]
    // 0xfb7bbc: r0 = EdgeInsets()
    //     0xfb7bbc: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xfb7bc0: ldur            d0, [fp, #-0x80]
    // 0xfb7bc4: stur            x0, [fp, #-0x30]
    // 0xfb7bc8: StoreField: r0->field_7 = d0
    //     0xfb7bc8: stur            d0, [x0, #7]
    // 0xfb7bcc: ldur            d0, [fp, #-0x70]
    // 0xfb7bd0: StoreField: r0->field_f = d0
    //     0xfb7bd0: stur            d0, [x0, #0xf]
    // 0xfb7bd4: ldur            d0, [fp, #-0x78]
    // 0xfb7bd8: ArrayStore: r0[0] = d0  ; List_8
    //     0xfb7bd8: stur            d0, [x0, #0x17]
    // 0xfb7bdc: ldur            d0, [fp, #-0x68]
    // 0xfb7be0: StoreField: r0->field_1f = d0
    //     0xfb7be0: stur            d0, [x0, #0x1f]
    // 0xfb7be4: ldur            x2, [fp, #-0x18]
    // 0xfb7be8: r1 = LoadClassIdInstr(r2)
    //     0xfb7be8: ldur            x1, [x2, #-1]
    //     0xfb7bec: ubfx            x1, x1, #0xc, #0x14
    // 0xfb7bf0: r17 = 5163
    //     0xfb7bf0: mov             x17, #0x142b
    // 0xfb7bf4: cmp             x1, x17
    // 0xfb7bf8: b.ne            #0xfb7c04
    // 0xfb7bfc: mov             x0, x2
    // 0xfb7c00: b               #0xfb7c50
    // 0xfb7c04: r17 = 5164
    //     0xfb7c04: mov             x17, #0x142c
    // 0xfb7c08: cmp             x1, x17
    // 0xfb7c0c: b.ne            #0xfb7c40
    // 0xfb7c10: mov             x1, x2
    // 0xfb7c14: LoadField: r0 = r1->field_47
    //     0xfb7c14: ldur            w0, [x1, #0x47]
    // 0xfb7c18: DecompressPointer r0
    //     0xfb7c18: add             x0, x0, HEAP, lsl #32
    // 0xfb7c1c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb7c20: cmp             w0, w16
    // 0xfb7c24: b.ne            #0xfb7c34
    // 0xfb7c28: r2 = _textTheme
    //     0xfb7c28: add             x2, PP, #0x26, lsl #12  ; [pp+0x263e8] Field <_DialogDefaultsM3@664506021._textTheme@664506021>: late final (offset: 0x48)
    //     0xfb7c2c: ldr             x2, [x2, #0x3e8]
    // 0xfb7c30: r0 = InitLateFinalInstanceField()
    //     0xfb7c30: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfb7c34: LoadField: r1 = r0->field_1b
    //     0xfb7c34: ldur            w1, [x0, #0x1b]
    // 0xfb7c38: DecompressPointer r1
    //     0xfb7c38: add             x1, x1, HEAP, lsl #32
    // 0xfb7c3c: b               #0xfb7c8c
    // 0xfb7c40: r17 = 5165
    //     0xfb7c40: mov             x17, #0x142d
    // 0xfb7c44: cmp             x1, x17
    // 0xfb7c48: b.ne            #0xfb7c5c
    // 0xfb7c4c: ldur            x0, [fp, #-0x18]
    // 0xfb7c50: LoadField: r1 = r0->field_1f
    //     0xfb7c50: ldur            w1, [x0, #0x1f]
    // 0xfb7c54: DecompressPointer r1
    //     0xfb7c54: add             x1, x1, HEAP, lsl #32
    // 0xfb7c58: b               #0xfb7c8c
    // 0xfb7c5c: ldur            x0, [fp, #-0x18]
    // 0xfb7c60: mov             x1, x0
    // 0xfb7c64: LoadField: r0 = r1->field_47
    //     0xfb7c64: ldur            w0, [x1, #0x47]
    // 0xfb7c68: DecompressPointer r0
    //     0xfb7c68: add             x0, x0, HEAP, lsl #32
    // 0xfb7c6c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb7c70: cmp             w0, w16
    // 0xfb7c74: b.ne            #0xfb7c84
    // 0xfb7c78: r2 = textTheme
    //     0xfb7c78: add             x2, PP, #0x26, lsl #12  ; [pp+0x263f0] Field <_DialogDefaultsM2@664506021.textTheme>: late final (offset: 0x48)
    //     0xfb7c7c: ldr             x2, [x2, #0x3f0]
    // 0xfb7c80: r0 = InitLateFinalInstanceField()
    //     0xfb7c80: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfb7c84: LoadField: r1 = r0->field_1f
    //     0xfb7c84: ldur            w1, [x0, #0x1f]
    // 0xfb7c88: DecompressPointer r1
    //     0xfb7c88: add             x1, x1, HEAP, lsl #32
    // 0xfb7c8c: ldur            x0, [fp, #-0x30]
    // 0xfb7c90: stur            x1, [fp, #-0x38]
    // 0xfb7c94: cmp             w1, NULL
    // 0xfb7c98: b.eq            #0xfb875c
    // 0xfb7c9c: r0 = Semantics()
    //     0xfb7c9c: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xfb7ca0: stur            x0, [fp, #-0x40]
    // 0xfb7ca4: r16 = false
    //     0xfb7ca4: add             x16, NULL, #0x30  ; false
    // 0xfb7ca8: r30 = true
    //     0xfb7ca8: add             lr, NULL, #0x20  ; true
    // 0xfb7cac: stp             lr, x16, [SP, #8]
    // 0xfb7cb0: ldur            x16, [fp, #-0x10]
    // 0xfb7cb4: str             x16, [SP]
    // 0xfb7cb8: mov             x1, x0
    // 0xfb7cbc: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, container, 0x2, namesRoute, 0x1, null]
    //     0xfb7cbc: add             x4, PP, #0x80, lsl #12  ; [pp+0x80aa0] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "container", 0x2, "namesRoute", 0x1, Null]
    //     0xfb7cc0: ldr             x4, [x4, #0xaa0]
    // 0xfb7cc4: r0 = Semantics()
    //     0xfb7cc4: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xfb7cc8: r0 = DefaultTextStyle()
    //     0xfb7cc8: bl              #0xd0b11c  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xfb7ccc: mov             x1, x0
    // 0xfb7cd0: ldur            x0, [fp, #-0x38]
    // 0xfb7cd4: stur            x1, [fp, #-0x48]
    // 0xfb7cd8: StoreField: r1->field_f = r0
    //     0xfb7cd8: stur            w0, [x1, #0xf]
    // 0xfb7cdc: r0 = Instance_TextAlign
    //     0xfb7cdc: ldr             x0, [PP, #0x4c78]  ; [pp+0x4c78] Obj!TextAlign@12c7541
    // 0xfb7ce0: StoreField: r1->field_13 = r0
    //     0xfb7ce0: stur            w0, [x1, #0x13]
    // 0xfb7ce4: r0 = true
    //     0xfb7ce4: add             x0, NULL, #0x20  ; true
    // 0xfb7ce8: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb7ce8: stur            w0, [x1, #0x17]
    // 0xfb7cec: r2 = Instance_TextOverflow
    //     0xfb7cec: add             x2, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xfb7cf0: ldr             x2, [x2, #0x108]
    // 0xfb7cf4: StoreField: r1->field_1b = r2
    //     0xfb7cf4: stur            w2, [x1, #0x1b]
    // 0xfb7cf8: r3 = Instance_TextWidthBasis
    //     0xfb7cf8: add             x3, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xfb7cfc: ldr             x3, [x3, #0x110]
    // 0xfb7d00: StoreField: r1->field_23 = r3
    //     0xfb7d00: stur            w3, [x1, #0x23]
    // 0xfb7d04: ldur            x4, [fp, #-0x40]
    // 0xfb7d08: StoreField: r1->field_b = r4
    //     0xfb7d08: stur            w4, [x1, #0xb]
    // 0xfb7d0c: r0 = Padding()
    //     0xfb7d0c: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xfb7d10: mov             x1, x0
    // 0xfb7d14: ldur            x0, [fp, #-0x30]
    // 0xfb7d18: StoreField: r1->field_f = r0
    //     0xfb7d18: stur            w0, [x1, #0xf]
    // 0xfb7d1c: ldur            x0, [fp, #-0x48]
    // 0xfb7d20: StoreField: r1->field_b = r0
    //     0xfb7d20: stur            w0, [x1, #0xb]
    // 0xfb7d24: b               #0xfb7d2c
    // 0xfb7d28: r1 = Null
    //     0xfb7d28: mov             x1, NULL
    // 0xfb7d2c: ldur            x0, [fp, #-0x20]
    // 0xfb7d30: stur            x1, [fp, #-0x30]
    // 0xfb7d34: tbnz            w0, #4, #0xfb7d40
    // 0xfb7d38: d0 = 16.000000
    //     0xfb7d38: fmov            d0, #16.00000000
    // 0xfb7d3c: b               #0xfb7d44
    // 0xfb7d40: d0 = 20.000000
    //     0xfb7d40: fmov            d0, #20.00000000
    // 0xfb7d44: ldur            x2, [fp, #-8]
    // 0xfb7d48: stur            d0, [fp, #-0x68]
    // 0xfb7d4c: r0 = EdgeInsets()
    //     0xfb7d4c: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xfb7d50: d0 = 24.000000
    //     0xfb7d50: fmov            d0, #24.00000000
    // 0xfb7d54: StoreField: r0->field_7 = d0
    //     0xfb7d54: stur            d0, [x0, #7]
    // 0xfb7d58: ldur            d1, [fp, #-0x68]
    // 0xfb7d5c: StoreField: r0->field_f = d1
    //     0xfb7d5c: stur            d1, [x0, #0xf]
    // 0xfb7d60: ArrayStore: r0[0] = d0  ; List_8
    //     0xfb7d60: stur            d0, [x0, #0x17]
    // 0xfb7d64: StoreField: r0->field_1f = d0
    //     0xfb7d64: stur            d0, [x0, #0x1f]
    // 0xfb7d68: ldur            x1, [fp, #-8]
    // 0xfb7d6c: LoadField: r2 = r1->field_1f
    //     0xfb7d6c: ldur            w2, [x1, #0x1f]
    // 0xfb7d70: DecompressPointer r2
    //     0xfb7d70: add             x2, x2, HEAP, lsl #32
    // 0xfb7d74: cmp             w2, NULL
    // 0xfb7d78: b.ne            #0xfb7d80
    // 0xfb7d7c: r2 = Null
    //     0xfb7d7c: mov             x2, NULL
    // 0xfb7d80: cmp             w2, NULL
    // 0xfb7d84: b.ne            #0xfb7d8c
    // 0xfb7d88: mov             x2, x0
    // 0xfb7d8c: ldur            d0, [fp, #-0x60]
    // 0xfb7d90: ldur            x0, [fp, #-0x10]
    // 0xfb7d94: LoadField: d1 = r2->field_7
    //     0xfb7d94: ldur            d1, [x2, #7]
    // 0xfb7d98: fmul            d2, d1, d0
    // 0xfb7d9c: stur            d2, [fp, #-0x78]
    // 0xfb7da0: ArrayLoad: d1 = r2[0]  ; List_8
    //     0xfb7da0: ldur            d1, [x2, #0x17]
    // 0xfb7da4: fmul            d3, d1, d0
    // 0xfb7da8: stur            d3, [fp, #-0x70]
    // 0xfb7dac: cmp             w0, NULL
    // 0xfb7db0: b.ne            #0xfb7dc4
    // 0xfb7db4: LoadField: d1 = r2->field_f
    //     0xfb7db4: ldur            d1, [x2, #0xf]
    // 0xfb7db8: fmul            d4, d1, d0
    // 0xfb7dbc: mov             v0.16b, v4.16b
    // 0xfb7dc0: b               #0xfb7dc8
    // 0xfb7dc4: LoadField: d0 = r2->field_f
    //     0xfb7dc4: ldur            d0, [x2, #0xf]
    // 0xfb7dc8: ldur            x0, [fp, #-0x18]
    // 0xfb7dcc: stur            d0, [fp, #-0x68]
    // 0xfb7dd0: LoadField: d1 = r2->field_1f
    //     0xfb7dd0: ldur            d1, [x2, #0x1f]
    // 0xfb7dd4: stur            d1, [fp, #-0x60]
    // 0xfb7dd8: r0 = EdgeInsets()
    //     0xfb7dd8: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xfb7ddc: ldur            d0, [fp, #-0x78]
    // 0xfb7de0: stur            x0, [fp, #-0x10]
    // 0xfb7de4: StoreField: r0->field_7 = d0
    //     0xfb7de4: stur            d0, [x0, #7]
    // 0xfb7de8: ldur            d0, [fp, #-0x68]
    // 0xfb7dec: StoreField: r0->field_f = d0
    //     0xfb7dec: stur            d0, [x0, #0xf]
    // 0xfb7df0: ldur            d0, [fp, #-0x70]
    // 0xfb7df4: ArrayStore: r0[0] = d0  ; List_8
    //     0xfb7df4: stur            d0, [x0, #0x17]
    // 0xfb7df8: ldur            d0, [fp, #-0x60]
    // 0xfb7dfc: StoreField: r0->field_1f = d0
    //     0xfb7dfc: stur            d0, [x0, #0x1f]
    // 0xfb7e00: ldur            x2, [fp, #-0x18]
    // 0xfb7e04: r3 = LoadClassIdInstr(r2)
    //     0xfb7e04: ldur            x3, [x2, #-1]
    //     0xfb7e08: ubfx            x3, x3, #0xc, #0x14
    // 0xfb7e0c: stur            x3, [fp, #-0x50]
    // 0xfb7e10: r17 = 5163
    //     0xfb7e10: mov             x17, #0x142b
    // 0xfb7e14: cmp             x3, x17
    // 0xfb7e18: b.ne            #0xfb7e24
    // 0xfb7e1c: mov             x0, x3
    // 0xfb7e20: b               #0xfb7e78
    // 0xfb7e24: r17 = 5164
    //     0xfb7e24: mov             x17, #0x142c
    // 0xfb7e28: cmp             x3, x17
    // 0xfb7e2c: b.ne            #0xfb7e64
    // 0xfb7e30: mov             x1, x2
    // 0xfb7e34: LoadField: r0 = r1->field_47
    //     0xfb7e34: ldur            w0, [x1, #0x47]
    // 0xfb7e38: DecompressPointer r0
    //     0xfb7e38: add             x0, x0, HEAP, lsl #32
    // 0xfb7e3c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb7e40: cmp             w0, w16
    // 0xfb7e44: b.ne            #0xfb7e54
    // 0xfb7e48: r2 = _textTheme
    //     0xfb7e48: add             x2, PP, #0x26, lsl #12  ; [pp+0x263e8] Field <_DialogDefaultsM3@664506021._textTheme@664506021>: late final (offset: 0x48)
    //     0xfb7e4c: ldr             x2, [x2, #0x3e8]
    // 0xfb7e50: r0 = InitLateFinalInstanceField()
    //     0xfb7e50: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfb7e54: LoadField: r1 = r0->field_2f
    //     0xfb7e54: ldur            w1, [x0, #0x2f]
    // 0xfb7e58: DecompressPointer r1
    //     0xfb7e58: add             x1, x1, HEAP, lsl #32
    // 0xfb7e5c: mov             x2, x1
    // 0xfb7e60: b               #0xfb7ebc
    // 0xfb7e64: mov             x0, x3
    // 0xfb7e68: r17 = 5165
    //     0xfb7e68: mov             x17, #0x142d
    // 0xfb7e6c: cmp             x0, x17
    // 0xfb7e70: b.ne            #0xfb7e88
    // 0xfb7e74: ldur            x2, [fp, #-0x18]
    // 0xfb7e78: LoadField: r1 = r2->field_23
    //     0xfb7e78: ldur            w1, [x2, #0x23]
    // 0xfb7e7c: DecompressPointer r1
    //     0xfb7e7c: add             x1, x1, HEAP, lsl #32
    // 0xfb7e80: mov             x2, x1
    // 0xfb7e84: b               #0xfb7ebc
    // 0xfb7e88: ldur            x2, [fp, #-0x18]
    // 0xfb7e8c: mov             x1, x2
    // 0xfb7e90: LoadField: r0 = r1->field_47
    //     0xfb7e90: ldur            w0, [x1, #0x47]
    // 0xfb7e94: DecompressPointer r0
    //     0xfb7e94: add             x0, x0, HEAP, lsl #32
    // 0xfb7e98: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb7e9c: cmp             w0, w16
    // 0xfb7ea0: b.ne            #0xfb7eb0
    // 0xfb7ea4: r2 = textTheme
    //     0xfb7ea4: add             x2, PP, #0x26, lsl #12  ; [pp+0x263f0] Field <_DialogDefaultsM2@664506021.textTheme>: late final (offset: 0x48)
    //     0xfb7ea8: ldr             x2, [x2, #0x3f0]
    // 0xfb7eac: r0 = InitLateFinalInstanceField()
    //     0xfb7eac: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfb7eb0: LoadField: r1 = r0->field_23
    //     0xfb7eb0: ldur            w1, [x0, #0x23]
    // 0xfb7eb4: DecompressPointer r1
    //     0xfb7eb4: add             x1, x1, HEAP, lsl #32
    // 0xfb7eb8: mov             x2, x1
    // 0xfb7ebc: ldur            x1, [fp, #-8]
    // 0xfb7ec0: ldur            x0, [fp, #-0x10]
    // 0xfb7ec4: stur            x2, [fp, #-0x40]
    // 0xfb7ec8: cmp             w2, NULL
    // 0xfb7ecc: b.eq            #0xfb8760
    // 0xfb7ed0: LoadField: r3 = r1->field_1b
    //     0xfb7ed0: ldur            w3, [x1, #0x1b]
    // 0xfb7ed4: DecompressPointer r3
    //     0xfb7ed4: add             x3, x3, HEAP, lsl #32
    // 0xfb7ed8: stur            x3, [fp, #-0x38]
    // 0xfb7edc: r0 = Semantics()
    //     0xfb7edc: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xfb7ee0: stur            x0, [fp, #-0x48]
    // 0xfb7ee4: r16 = true
    //     0xfb7ee4: add             x16, NULL, #0x20  ; true
    // 0xfb7ee8: r30 = true
    //     0xfb7ee8: add             lr, NULL, #0x20  ; true
    // 0xfb7eec: stp             lr, x16, [SP, #8]
    // 0xfb7ef0: ldur            x16, [fp, #-0x38]
    // 0xfb7ef4: str             x16, [SP]
    // 0xfb7ef8: mov             x1, x0
    // 0xfb7efc: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, container, 0x1, explicitChildNodes, 0x2, null]
    //     0xfb7efc: add             x4, PP, #0x80, lsl #12  ; [pp+0x80aa8] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "container", 0x1, "explicitChildNodes", 0x2, Null]
    //     0xfb7f00: ldr             x4, [x4, #0xaa8]
    // 0xfb7f04: r0 = Semantics()
    //     0xfb7f04: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xfb7f08: r0 = DefaultTextStyle()
    //     0xfb7f08: bl              #0xd0b11c  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xfb7f0c: mov             x1, x0
    // 0xfb7f10: ldur            x0, [fp, #-0x40]
    // 0xfb7f14: stur            x1, [fp, #-0x38]
    // 0xfb7f18: StoreField: r1->field_f = r0
    //     0xfb7f18: stur            w0, [x1, #0xf]
    // 0xfb7f1c: r0 = true
    //     0xfb7f1c: add             x0, NULL, #0x20  ; true
    // 0xfb7f20: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb7f20: stur            w0, [x1, #0x17]
    // 0xfb7f24: r0 = Instance_TextOverflow
    //     0xfb7f24: add             x0, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xfb7f28: ldr             x0, [x0, #0x108]
    // 0xfb7f2c: StoreField: r1->field_1b = r0
    //     0xfb7f2c: stur            w0, [x1, #0x1b]
    // 0xfb7f30: r0 = Instance_TextWidthBasis
    //     0xfb7f30: add             x0, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xfb7f34: ldr             x0, [x0, #0x110]
    // 0xfb7f38: StoreField: r1->field_23 = r0
    //     0xfb7f38: stur            w0, [x1, #0x23]
    // 0xfb7f3c: ldur            x0, [fp, #-0x48]
    // 0xfb7f40: StoreField: r1->field_b = r0
    //     0xfb7f40: stur            w0, [x1, #0xb]
    // 0xfb7f44: r0 = Padding()
    //     0xfb7f44: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xfb7f48: mov             x2, x0
    // 0xfb7f4c: ldur            x0, [fp, #-0x10]
    // 0xfb7f50: stur            x2, [fp, #-0x40]
    // 0xfb7f54: StoreField: r2->field_f = r0
    //     0xfb7f54: stur            w0, [x2, #0xf]
    // 0xfb7f58: ldur            x0, [fp, #-0x38]
    // 0xfb7f5c: StoreField: r2->field_b = r0
    //     0xfb7f5c: stur            w0, [x2, #0xb]
    // 0xfb7f60: ldur            x0, [fp, #-8]
    // 0xfb7f64: LoadField: r3 = r0->field_27
    //     0xfb7f64: ldur            w3, [x0, #0x27]
    // 0xfb7f68: DecompressPointer r3
    //     0xfb7f68: add             x3, x3, HEAP, lsl #32
    // 0xfb7f6c: stur            x3, [fp, #-0x10]
    // 0xfb7f70: cmp             w3, NULL
    // 0xfb7f74: b.eq            #0xfb813c
    // 0xfb7f78: LoadField: r1 = r0->field_3f
    //     0xfb7f78: ldur            w1, [x0, #0x3f]
    // 0xfb7f7c: DecompressPointer r1
    //     0xfb7f7c: add             x1, x1, HEAP, lsl #32
    // 0xfb7f80: cmp             w1, NULL
    // 0xfb7f84: b.ne            #0xfb7f90
    // 0xfb7f88: r0 = Null
    //     0xfb7f88: mov             x0, NULL
    // 0xfb7f8c: b               #0xfb7fc0
    // 0xfb7f90: r0 = horizontal()
    //     0xfb7f90: bl              #0xb17264  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::horizontal
    // 0xfb7f94: r0 = inline_Allocate_Double()
    //     0xfb7f94: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xfb7f98: add             x0, x0, #0x10
    //     0xfb7f9c: cmp             x1, x0
    //     0xfb7fa0: b.ls            #0xfb8764
    //     0xfb7fa4: str             x0, [THR, #0x60]  ; THR::top
    //     0xfb7fa8: sub             x0, x0, #0xf
    //     0xfb7fac: mov             x1, #0xe19c
    //     0xfb7fb0: movk            x1, #3, lsl #16
    //     0xfb7fb4: stur            x1, [x0, #-1]
    // 0xfb7fb8: dmb             ishst
    // 0xfb7fbc: StoreField: r0->field_7 = d0
    //     0xfb7fbc: stur            d0, [x0, #7]
    // 0xfb7fc0: cmp             w0, NULL
    // 0xfb7fc4: b.ne            #0xfb7fd0
    // 0xfb7fc8: d1 = 16.000000
    //     0xfb7fc8: fmov            d1, #16.00000000
    // 0xfb7fcc: b               #0xfb7fd8
    // 0xfb7fd0: LoadField: d0 = r0->field_7
    //     0xfb7fd0: ldur            d0, [x0, #7]
    // 0xfb7fd4: mov             v1.16b, v0.16b
    // 0xfb7fd8: ldur            x0, [fp, #-8]
    // 0xfb7fdc: d0 = 2.000000
    //     0xfb7fdc: fmov            d0, #2.00000000
    // 0xfb7fe0: fdiv            d2, d1, d0
    // 0xfb7fe4: stur            d2, [fp, #-0x60]
    // 0xfb7fe8: LoadField: r1 = r0->field_2b
    //     0xfb7fe8: ldur            w1, [x0, #0x2b]
    // 0xfb7fec: DecompressPointer r1
    //     0xfb7fec: add             x1, x1, HEAP, lsl #32
    // 0xfb7ff0: cmp             w1, NULL
    // 0xfb7ff4: b.ne            #0xfb7ffc
    // 0xfb7ff8: r1 = Null
    //     0xfb7ff8: mov             x1, NULL
    // 0xfb7ffc: cmp             w1, NULL
    // 0xfb8000: b.ne            #0xfb80d0
    // 0xfb8004: ldur            x1, [fp, #-0x20]
    // 0xfb8008: tbnz            w1, #4, #0xfb805c
    // 0xfb800c: ldur            x1, [fp, #-0x50]
    // 0xfb8010: r17 = 5163
    //     0xfb8010: mov             x17, #0x142b
    // 0xfb8014: cmp             x1, x17
    // 0xfb8018: b.eq            #0xfb8040
    // 0xfb801c: r17 = 5164
    //     0xfb801c: mov             x17, #0x142c
    // 0xfb8020: cmp             x1, x17
    // 0xfb8024: b.ne            #0xfb8034
    // 0xfb8028: r1 = Instance_EdgeInsets
    //     0xfb8028: add             x1, PP, #0x26, lsl #12  ; [pp+0x263f8] Obj!EdgeInsets@129d9e1
    //     0xfb802c: ldr             x1, [x1, #0x3f8]
    // 0xfb8030: b               #0xfb8054
    // 0xfb8034: r17 = 5165
    //     0xfb8034: mov             x17, #0x142d
    // 0xfb8038: cmp             x1, x17
    // 0xfb803c: b.ne            #0xfb8050
    // 0xfb8040: ldur            x2, [fp, #-0x18]
    // 0xfb8044: LoadField: r1 = r2->field_27
    //     0xfb8044: ldur            w1, [x2, #0x27]
    // 0xfb8048: DecompressPointer r1
    //     0xfb8048: add             x1, x1, HEAP, lsl #32
    // 0xfb804c: b               #0xfb8054
    // 0xfb8050: r1 = Instance_EdgeInsets
    //     0xfb8050: ldr             x1, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xfb8054: mov             x0, x1
    // 0xfb8058: b               #0xfb80cc
    // 0xfb805c: ldur            x2, [fp, #-0x18]
    // 0xfb8060: ldur            x1, [fp, #-0x50]
    // 0xfb8064: r17 = 5163
    //     0xfb8064: mov             x17, #0x142b
    // 0xfb8068: cmp             x1, x17
    // 0xfb806c: b.eq            #0xfb8094
    // 0xfb8070: r17 = 5164
    //     0xfb8070: mov             x17, #0x142c
    // 0xfb8074: cmp             x1, x17
    // 0xfb8078: b.ne            #0xfb8088
    // 0xfb807c: r1 = Instance_EdgeInsets
    //     0xfb807c: add             x1, PP, #0x26, lsl #12  ; [pp+0x263f8] Obj!EdgeInsets@129d9e1
    //     0xfb8080: ldr             x1, [x1, #0x3f8]
    // 0xfb8084: b               #0xfb80a4
    // 0xfb8088: r17 = 5165
    //     0xfb8088: mov             x17, #0x142d
    // 0xfb808c: cmp             x1, x17
    // 0xfb8090: b.ne            #0xfb80a0
    // 0xfb8094: LoadField: r1 = r2->field_27
    //     0xfb8094: ldur            w1, [x2, #0x27]
    // 0xfb8098: DecompressPointer r1
    //     0xfb8098: add             x1, x1, HEAP, lsl #32
    // 0xfb809c: b               #0xfb80a4
    // 0xfb80a0: r1 = Instance_EdgeInsets
    //     0xfb80a0: ldr             x1, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xfb80a4: stur            x1, [fp, #-0x18]
    // 0xfb80a8: r0 = EdgeInsets()
    //     0xfb80a8: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xfb80ac: ldur            d0, [fp, #-0x60]
    // 0xfb80b0: StoreField: r0->field_7 = d0
    //     0xfb80b0: stur            d0, [x0, #7]
    // 0xfb80b4: StoreField: r0->field_f = d0
    //     0xfb80b4: stur            d0, [x0, #0xf]
    // 0xfb80b8: ArrayStore: r0[0] = d0  ; List_8
    //     0xfb80b8: stur            d0, [x0, #0x17]
    // 0xfb80bc: StoreField: r0->field_1f = d0
    //     0xfb80bc: stur            d0, [x0, #0x1f]
    // 0xfb80c0: ldur            x1, [fp, #-0x18]
    // 0xfb80c4: mov             x2, x0
    // 0xfb80c8: r0 = +()
    //     0xfb80c8: bl              #0x8584ec  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::+
    // 0xfb80cc: mov             x1, x0
    // 0xfb80d0: ldur            x0, [fp, #-0x10]
    // 0xfb80d4: ldur            d0, [fp, #-0x60]
    // 0xfb80d8: stur            x1, [fp, #-0x18]
    // 0xfb80dc: r0 = OverflowBar()
    //     0xfb80dc: bl              #0xd16520  ; AllocateOverflowBarStub -> OverflowBar (size=0x30)
    // 0xfb80e0: ldur            d0, [fp, #-0x60]
    // 0xfb80e4: stur            x0, [fp, #-0x20]
    // 0xfb80e8: StoreField: r0->field_f = d0
    //     0xfb80e8: stur            d0, [x0, #0xf]
    // 0xfb80ec: r1 = Instance_MainAxisAlignment
    //     0xfb80ec: add             x1, PP, #0x18, lsl #12  ; [pp+0x182b8] Obj!MainAxisAlignment@12c45e1
    //     0xfb80f0: ldr             x1, [x1, #0x2b8]
    // 0xfb80f4: ArrayStore: r0[0] = r1  ; List_4
    //     0xfb80f4: stur            w1, [x0, #0x17]
    // 0xfb80f8: StoreField: r0->field_1b = rZR
    //     0xfb80f8: stur            xzr, [x0, #0x1b]
    // 0xfb80fc: r1 = Instance_OverflowBarAlignment
    //     0xfb80fc: add             x1, PP, #0x80, lsl #12  ; [pp+0x80ab0] Obj!OverflowBarAlignment@12c2881
    //     0xfb8100: ldr             x1, [x1, #0xab0]
    // 0xfb8104: StoreField: r0->field_23 = r1
    //     0xfb8104: stur            w1, [x0, #0x23]
    // 0xfb8108: r1 = Instance_VerticalDirection
    //     0xfb8108: add             x1, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xfb810c: ldr             x1, [x1, #0x838]
    // 0xfb8110: StoreField: r0->field_27 = r1
    //     0xfb8110: stur            w1, [x0, #0x27]
    // 0xfb8114: ldur            x2, [fp, #-0x10]
    // 0xfb8118: StoreField: r0->field_b = r2
    //     0xfb8118: stur            w2, [x0, #0xb]
    // 0xfb811c: r0 = Padding()
    //     0xfb811c: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xfb8120: mov             x1, x0
    // 0xfb8124: ldur            x0, [fp, #-0x18]
    // 0xfb8128: StoreField: r1->field_f = r0
    //     0xfb8128: stur            w0, [x1, #0xf]
    // 0xfb812c: ldur            x0, [fp, #-0x20]
    // 0xfb8130: StoreField: r1->field_b = r0
    //     0xfb8130: stur            w0, [x1, #0xb]
    // 0xfb8134: mov             x3, x1
    // 0xfb8138: b               #0xfb8140
    // 0xfb813c: r3 = Null
    //     0xfb813c: mov             x3, NULL
    // 0xfb8140: ldur            x0, [fp, #-8]
    // 0xfb8144: stur            x3, [fp, #-0x10]
    // 0xfb8148: LoadField: r1 = r0->field_6b
    //     0xfb8148: ldur            w1, [x0, #0x6b]
    // 0xfb814c: DecompressPointer r1
    //     0xfb814c: add             x1, x1, HEAP, lsl #32
    // 0xfb8150: tbnz            w1, #4, #0xfb8438
    // 0xfb8154: ldur            x4, [fp, #-0x30]
    // 0xfb8158: r1 = <Widget>
    //     0xfb8158: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfb815c: r2 = 0
    //     0xfb815c: mov             x2, #0
    // 0xfb8160: r0 = _GrowableList()
    //     0xfb8160: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfb8164: r1 = <Widget>
    //     0xfb8164: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfb8168: r2 = 0
    //     0xfb8168: mov             x2, #0
    // 0xfb816c: stur            x0, [fp, #-0x18]
    // 0xfb8170: r0 = _GrowableList()
    //     0xfb8170: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfb8174: mov             x2, x0
    // 0xfb8178: ldur            x0, [fp, #-0x30]
    // 0xfb817c: stur            x2, [fp, #-0x20]
    // 0xfb8180: cmp             w0, NULL
    // 0xfb8184: b.eq            #0xfb81fc
    // 0xfb8188: LoadField: r1 = r2->field_b
    //     0xfb8188: ldur            w1, [x2, #0xb]
    // 0xfb818c: LoadField: r3 = r2->field_f
    //     0xfb818c: ldur            w3, [x2, #0xf]
    // 0xfb8190: DecompressPointer r3
    //     0xfb8190: add             x3, x3, HEAP, lsl #32
    // 0xfb8194: LoadField: r4 = r3->field_b
    //     0xfb8194: ldur            w4, [x3, #0xb]
    // 0xfb8198: r3 = LoadInt32Instr(r1)
    //     0xfb8198: sbfx            x3, x1, #1, #0x1f
    // 0xfb819c: stur            x3, [fp, #-0x50]
    // 0xfb81a0: r1 = LoadInt32Instr(r4)
    //     0xfb81a0: sbfx            x1, x4, #1, #0x1f
    // 0xfb81a4: cmp             x3, x1
    // 0xfb81a8: b.ne            #0xfb81b4
    // 0xfb81ac: mov             x1, x2
    // 0xfb81b0: r0 = _growToNextCapacity()
    //     0xfb81b0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfb81b4: ldur            x2, [fp, #-0x20]
    // 0xfb81b8: ldur            x3, [fp, #-0x50]
    // 0xfb81bc: add             x0, x3, #1
    // 0xfb81c0: lsl             x1, x0, #1
    // 0xfb81c4: StoreField: r2->field_b = r1
    //     0xfb81c4: stur            w1, [x2, #0xb]
    // 0xfb81c8: LoadField: r1 = r2->field_f
    //     0xfb81c8: ldur            w1, [x2, #0xf]
    // 0xfb81cc: DecompressPointer r1
    //     0xfb81cc: add             x1, x1, HEAP, lsl #32
    // 0xfb81d0: ldur            x0, [fp, #-0x30]
    // 0xfb81d4: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfb81d4: add             x25, x1, x3, lsl #2
    //     0xfb81d8: add             x25, x25, #0xf
    //     0xfb81dc: str             w0, [x25]
    //     0xfb81e0: tbz             w0, #0, #0xfb81fc
    //     0xfb81e4: ldurb           w16, [x1, #-1]
    //     0xfb81e8: ldurb           w17, [x0, #-1]
    //     0xfb81ec: and             x16, x17, x16, lsr #2
    //     0xfb81f0: tst             x16, HEAP, lsr #32
    //     0xfb81f4: b.eq            #0xfb81fc
    //     0xfb81f8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfb81fc: LoadField: r0 = r2->field_b
    //     0xfb81fc: ldur            w0, [x2, #0xb]
    // 0xfb8200: LoadField: r1 = r2->field_f
    //     0xfb8200: ldur            w1, [x2, #0xf]
    // 0xfb8204: DecompressPointer r1
    //     0xfb8204: add             x1, x1, HEAP, lsl #32
    // 0xfb8208: LoadField: r3 = r1->field_b
    //     0xfb8208: ldur            w3, [x1, #0xb]
    // 0xfb820c: r4 = LoadInt32Instr(r0)
    //     0xfb820c: sbfx            x4, x0, #1, #0x1f
    // 0xfb8210: stur            x4, [fp, #-0x50]
    // 0xfb8214: r0 = LoadInt32Instr(r3)
    //     0xfb8214: sbfx            x0, x3, #1, #0x1f
    // 0xfb8218: cmp             x4, x0
    // 0xfb821c: b.ne            #0xfb8228
    // 0xfb8220: mov             x1, x2
    // 0xfb8224: r0 = _growToNextCapacity()
    //     0xfb8224: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfb8228: ldur            x4, [fp, #-0x18]
    // 0xfb822c: ldur            x2, [fp, #-0x20]
    // 0xfb8230: ldur            x3, [fp, #-0x50]
    // 0xfb8234: add             x0, x3, #1
    // 0xfb8238: lsl             x1, x0, #1
    // 0xfb823c: StoreField: r2->field_b = r1
    //     0xfb823c: stur            w1, [x2, #0xb]
    // 0xfb8240: LoadField: r1 = r2->field_f
    //     0xfb8240: ldur            w1, [x2, #0xf]
    // 0xfb8244: DecompressPointer r1
    //     0xfb8244: add             x1, x1, HEAP, lsl #32
    // 0xfb8248: ldur            x0, [fp, #-0x40]
    // 0xfb824c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfb824c: add             x25, x1, x3, lsl #2
    //     0xfb8250: add             x25, x25, #0xf
    //     0xfb8254: str             w0, [x25]
    //     0xfb8258: tbz             w0, #0, #0xfb8274
    //     0xfb825c: ldurb           w16, [x1, #-1]
    //     0xfb8260: ldurb           w17, [x0, #-1]
    //     0xfb8264: and             x16, x17, x16, lsr #2
    //     0xfb8268: tst             x16, HEAP, lsr #32
    //     0xfb826c: b.eq            #0xfb8274
    //     0xfb8270: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfb8274: r0 = Column()
    //     0xfb8274: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xfb8278: mov             x1, x0
    // 0xfb827c: r0 = Instance_Axis
    //     0xfb827c: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xfb8280: stur            x1, [fp, #-0x38]
    // 0xfb8284: StoreField: r1->field_f = r0
    //     0xfb8284: stur            w0, [x1, #0xf]
    // 0xfb8288: r2 = Instance_MainAxisAlignment
    //     0xfb8288: add             x2, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xfb828c: ldr             x2, [x2, #0x820]
    // 0xfb8290: StoreField: r1->field_13 = r2
    //     0xfb8290: stur            w2, [x1, #0x13]
    // 0xfb8294: r3 = Instance_MainAxisSize
    //     0xfb8294: add             x3, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xfb8298: ldr             x3, [x3, #0x200]
    // 0xfb829c: ArrayStore: r1[0] = r3  ; List_4
    //     0xfb829c: stur            w3, [x1, #0x17]
    // 0xfb82a0: r4 = Instance_CrossAxisAlignment
    //     0xfb82a0: add             x4, PP, #0x7b, lsl #12  ; [pp+0x7bc40] Obj!CrossAxisAlignment@12c4521
    //     0xfb82a4: ldr             x4, [x4, #0xc40]
    // 0xfb82a8: StoreField: r1->field_1b = r4
    //     0xfb82a8: stur            w4, [x1, #0x1b]
    // 0xfb82ac: r5 = Instance_VerticalDirection
    //     0xfb82ac: add             x5, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xfb82b0: ldr             x5, [x5, #0x838]
    // 0xfb82b4: StoreField: r1->field_23 = r5
    //     0xfb82b4: stur            w5, [x1, #0x23]
    // 0xfb82b8: r6 = Instance_Clip
    //     0xfb82b8: add             x6, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb82bc: ldr             x6, [x6, #0x840]
    // 0xfb82c0: StoreField: r1->field_2b = r6
    //     0xfb82c0: stur            w6, [x1, #0x2b]
    // 0xfb82c4: StoreField: r1->field_2f = rZR
    //     0xfb82c4: stur            xzr, [x1, #0x2f]
    // 0xfb82c8: ldur            x7, [fp, #-0x20]
    // 0xfb82cc: StoreField: r1->field_b = r7
    //     0xfb82cc: stur            w7, [x1, #0xb]
    // 0xfb82d0: r0 = SingleChildScrollView()
    //     0xfb82d0: bl              #0xdc8fa4  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0xfb82d4: mov             x2, x0
    // 0xfb82d8: r0 = Instance_Axis
    //     0xfb82d8: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xfb82dc: stur            x2, [fp, #-0x20]
    // 0xfb82e0: StoreField: r2->field_b = r0
    //     0xfb82e0: stur            w0, [x2, #0xb]
    // 0xfb82e4: r3 = false
    //     0xfb82e4: add             x3, NULL, #0x30  ; false
    // 0xfb82e8: StoreField: r2->field_f = r3
    //     0xfb82e8: stur            w3, [x2, #0xf]
    // 0xfb82ec: ldur            x1, [fp, #-0x38]
    // 0xfb82f0: StoreField: r2->field_23 = r1
    //     0xfb82f0: stur            w1, [x2, #0x23]
    // 0xfb82f4: r1 = Instance_DragStartBehavior
    //     0xfb82f4: ldr             x1, [PP, #0x5360]  ; [pp+0x5360] Obj!DragStartBehavior@12c5c61
    // 0xfb82f8: StoreField: r2->field_27 = r1
    //     0xfb82f8: stur            w1, [x2, #0x27]
    // 0xfb82fc: r1 = Instance_Clip
    //     0xfb82fc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xfb8300: ldr             x1, [x1, #0x850]
    // 0xfb8304: StoreField: r2->field_2b = r1
    //     0xfb8304: stur            w1, [x2, #0x2b]
    // 0xfb8308: r1 = Instance_HitTestBehavior
    //     0xfb8308: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c0] Obj!HitTestBehavior@12c43c1
    //     0xfb830c: ldr             x1, [x1, #0x5c0]
    // 0xfb8310: StoreField: r2->field_2f = r1
    //     0xfb8310: stur            w1, [x2, #0x2f]
    // 0xfb8314: r1 = <FlexParentData>
    //     0xfb8314: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xfb8318: ldr             x1, [x1, #0x878]
    // 0xfb831c: r0 = Flexible()
    //     0xfb831c: bl              #0xd0fd68  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0xfb8320: mov             x2, x0
    // 0xfb8324: r0 = 1
    //     0xfb8324: mov             x0, #1
    // 0xfb8328: stur            x2, [fp, #-0x38]
    // 0xfb832c: StoreField: r2->field_13 = r0
    //     0xfb832c: stur            x0, [x2, #0x13]
    // 0xfb8330: r3 = Instance_FlexFit
    //     0xfb8330: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1ac30] Obj!FlexFit@12c4661
    //     0xfb8334: ldr             x3, [x3, #0xc30]
    // 0xfb8338: StoreField: r2->field_1b = r3
    //     0xfb8338: stur            w3, [x2, #0x1b]
    // 0xfb833c: ldur            x0, [fp, #-0x20]
    // 0xfb8340: StoreField: r2->field_b = r0
    //     0xfb8340: stur            w0, [x2, #0xb]
    // 0xfb8344: ldur            x0, [fp, #-0x18]
    // 0xfb8348: LoadField: r1 = r0->field_b
    //     0xfb8348: ldur            w1, [x0, #0xb]
    // 0xfb834c: LoadField: r3 = r0->field_f
    //     0xfb834c: ldur            w3, [x0, #0xf]
    // 0xfb8350: DecompressPointer r3
    //     0xfb8350: add             x3, x3, HEAP, lsl #32
    // 0xfb8354: LoadField: r4 = r3->field_b
    //     0xfb8354: ldur            w4, [x3, #0xb]
    // 0xfb8358: r3 = LoadInt32Instr(r1)
    //     0xfb8358: sbfx            x3, x1, #1, #0x1f
    // 0xfb835c: stur            x3, [fp, #-0x50]
    // 0xfb8360: r1 = LoadInt32Instr(r4)
    //     0xfb8360: sbfx            x1, x4, #1, #0x1f
    // 0xfb8364: cmp             x3, x1
    // 0xfb8368: b.ne            #0xfb8374
    // 0xfb836c: mov             x1, x0
    // 0xfb8370: r0 = _growToNextCapacity()
    //     0xfb8370: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfb8374: ldur            x4, [fp, #-0x10]
    // 0xfb8378: ldur            x2, [fp, #-0x18]
    // 0xfb837c: ldur            x3, [fp, #-0x50]
    // 0xfb8380: add             x5, x3, #1
    // 0xfb8384: stur            x5, [fp, #-0x58]
    // 0xfb8388: lsl             x0, x5, #1
    // 0xfb838c: StoreField: r2->field_b = r0
    //     0xfb838c: stur            w0, [x2, #0xb]
    // 0xfb8390: LoadField: r6 = r2->field_f
    //     0xfb8390: ldur            w6, [x2, #0xf]
    // 0xfb8394: DecompressPointer r6
    //     0xfb8394: add             x6, x6, HEAP, lsl #32
    // 0xfb8398: mov             x1, x6
    // 0xfb839c: ldur            x0, [fp, #-0x38]
    // 0xfb83a0: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfb83a0: add             x25, x1, x3, lsl #2
    //     0xfb83a4: add             x25, x25, #0xf
    //     0xfb83a8: str             w0, [x25]
    //     0xfb83ac: tbz             w0, #0, #0xfb83c8
    //     0xfb83b0: ldurb           w16, [x1, #-1]
    //     0xfb83b4: ldurb           w17, [x0, #-1]
    //     0xfb83b8: and             x16, x17, x16, lsr #2
    //     0xfb83bc: tst             x16, HEAP, lsr #32
    //     0xfb83c0: b.eq            #0xfb83c8
    //     0xfb83c4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfb83c8: cmp             w4, NULL
    // 0xfb83cc: b.eq            #0xfb8430
    // 0xfb83d0: LoadField: r0 = r6->field_b
    //     0xfb83d0: ldur            w0, [x6, #0xb]
    // 0xfb83d4: r1 = LoadInt32Instr(r0)
    //     0xfb83d4: sbfx            x1, x0, #1, #0x1f
    // 0xfb83d8: cmp             x5, x1
    // 0xfb83dc: b.ne            #0xfb83e8
    // 0xfb83e0: mov             x1, x2
    // 0xfb83e4: r0 = _growToNextCapacity()
    //     0xfb83e4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfb83e8: ldur            x2, [fp, #-0x18]
    // 0xfb83ec: ldur            x3, [fp, #-0x58]
    // 0xfb83f0: add             x0, x3, #1
    // 0xfb83f4: lsl             x1, x0, #1
    // 0xfb83f8: StoreField: r2->field_b = r1
    //     0xfb83f8: stur            w1, [x2, #0xb]
    // 0xfb83fc: LoadField: r1 = r2->field_f
    //     0xfb83fc: ldur            w1, [x2, #0xf]
    // 0xfb8400: DecompressPointer r1
    //     0xfb8400: add             x1, x1, HEAP, lsl #32
    // 0xfb8404: ldur            x0, [fp, #-0x10]
    // 0xfb8408: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfb8408: add             x25, x1, x3, lsl #2
    //     0xfb840c: add             x25, x25, #0xf
    //     0xfb8410: str             w0, [x25]
    //     0xfb8414: tbz             w0, #0, #0xfb8430
    //     0xfb8418: ldurb           w16, [x1, #-1]
    //     0xfb841c: ldurb           w17, [x0, #-1]
    //     0xfb8420: and             x16, x17, x16, lsr #2
    //     0xfb8424: tst             x16, HEAP, lsr #32
    //     0xfb8428: b.eq            #0xfb8430
    //     0xfb842c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfb8430: mov             x1, x2
    // 0xfb8434: b               #0xfb8600
    // 0xfb8438: ldur            x4, [fp, #-0x30]
    // 0xfb843c: r3 = Instance_FlexFit
    //     0xfb843c: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1ac30] Obj!FlexFit@12c4661
    //     0xfb8440: ldr             x3, [x3, #0xc30]
    // 0xfb8444: r0 = 1
    //     0xfb8444: mov             x0, #1
    // 0xfb8448: r1 = <Widget>
    //     0xfb8448: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfb844c: r2 = 0
    //     0xfb844c: mov             x2, #0
    // 0xfb8450: r0 = _GrowableList()
    //     0xfb8450: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfb8454: mov             x2, x0
    // 0xfb8458: ldur            x0, [fp, #-0x30]
    // 0xfb845c: stur            x2, [fp, #-0x18]
    // 0xfb8460: cmp             w0, NULL
    // 0xfb8464: b.eq            #0xfb84dc
    // 0xfb8468: LoadField: r1 = r2->field_b
    //     0xfb8468: ldur            w1, [x2, #0xb]
    // 0xfb846c: LoadField: r3 = r2->field_f
    //     0xfb846c: ldur            w3, [x2, #0xf]
    // 0xfb8470: DecompressPointer r3
    //     0xfb8470: add             x3, x3, HEAP, lsl #32
    // 0xfb8474: LoadField: r4 = r3->field_b
    //     0xfb8474: ldur            w4, [x3, #0xb]
    // 0xfb8478: r3 = LoadInt32Instr(r1)
    //     0xfb8478: sbfx            x3, x1, #1, #0x1f
    // 0xfb847c: stur            x3, [fp, #-0x50]
    // 0xfb8480: r1 = LoadInt32Instr(r4)
    //     0xfb8480: sbfx            x1, x4, #1, #0x1f
    // 0xfb8484: cmp             x3, x1
    // 0xfb8488: b.ne            #0xfb8494
    // 0xfb848c: mov             x1, x2
    // 0xfb8490: r0 = _growToNextCapacity()
    //     0xfb8490: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfb8494: ldur            x2, [fp, #-0x18]
    // 0xfb8498: ldur            x3, [fp, #-0x50]
    // 0xfb849c: add             x0, x3, #1
    // 0xfb84a0: lsl             x1, x0, #1
    // 0xfb84a4: StoreField: r2->field_b = r1
    //     0xfb84a4: stur            w1, [x2, #0xb]
    // 0xfb84a8: LoadField: r1 = r2->field_f
    //     0xfb84a8: ldur            w1, [x2, #0xf]
    // 0xfb84ac: DecompressPointer r1
    //     0xfb84ac: add             x1, x1, HEAP, lsl #32
    // 0xfb84b0: ldur            x0, [fp, #-0x30]
    // 0xfb84b4: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfb84b4: add             x25, x1, x3, lsl #2
    //     0xfb84b8: add             x25, x25, #0xf
    //     0xfb84bc: str             w0, [x25]
    //     0xfb84c0: tbz             w0, #0, #0xfb84dc
    //     0xfb84c4: ldurb           w16, [x1, #-1]
    //     0xfb84c8: ldurb           w17, [x0, #-1]
    //     0xfb84cc: and             x16, x17, x16, lsr #2
    //     0xfb84d0: tst             x16, HEAP, lsr #32
    //     0xfb84d4: b.eq            #0xfb84dc
    //     0xfb84d8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfb84dc: ldur            x0, [fp, #-0x40]
    // 0xfb84e0: r1 = <FlexParentData>
    //     0xfb84e0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xfb84e4: ldr             x1, [x1, #0x878]
    // 0xfb84e8: r0 = Flexible()
    //     0xfb84e8: bl              #0xd0fd68  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0xfb84ec: mov             x2, x0
    // 0xfb84f0: r0 = 1
    //     0xfb84f0: mov             x0, #1
    // 0xfb84f4: stur            x2, [fp, #-0x20]
    // 0xfb84f8: StoreField: r2->field_13 = r0
    //     0xfb84f8: stur            x0, [x2, #0x13]
    // 0xfb84fc: r0 = Instance_FlexFit
    //     0xfb84fc: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ac30] Obj!FlexFit@12c4661
    //     0xfb8500: ldr             x0, [x0, #0xc30]
    // 0xfb8504: StoreField: r2->field_1b = r0
    //     0xfb8504: stur            w0, [x2, #0x1b]
    // 0xfb8508: ldur            x0, [fp, #-0x40]
    // 0xfb850c: StoreField: r2->field_b = r0
    //     0xfb850c: stur            w0, [x2, #0xb]
    // 0xfb8510: ldur            x0, [fp, #-0x18]
    // 0xfb8514: LoadField: r1 = r0->field_b
    //     0xfb8514: ldur            w1, [x0, #0xb]
    // 0xfb8518: LoadField: r3 = r0->field_f
    //     0xfb8518: ldur            w3, [x0, #0xf]
    // 0xfb851c: DecompressPointer r3
    //     0xfb851c: add             x3, x3, HEAP, lsl #32
    // 0xfb8520: LoadField: r4 = r3->field_b
    //     0xfb8520: ldur            w4, [x3, #0xb]
    // 0xfb8524: r3 = LoadInt32Instr(r1)
    //     0xfb8524: sbfx            x3, x1, #1, #0x1f
    // 0xfb8528: stur            x3, [fp, #-0x50]
    // 0xfb852c: r1 = LoadInt32Instr(r4)
    //     0xfb852c: sbfx            x1, x4, #1, #0x1f
    // 0xfb8530: cmp             x3, x1
    // 0xfb8534: b.ne            #0xfb8540
    // 0xfb8538: mov             x1, x0
    // 0xfb853c: r0 = _growToNextCapacity()
    //     0xfb853c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfb8540: ldur            x4, [fp, #-0x10]
    // 0xfb8544: ldur            x2, [fp, #-0x18]
    // 0xfb8548: ldur            x3, [fp, #-0x50]
    // 0xfb854c: add             x5, x3, #1
    // 0xfb8550: stur            x5, [fp, #-0x58]
    // 0xfb8554: lsl             x0, x5, #1
    // 0xfb8558: StoreField: r2->field_b = r0
    //     0xfb8558: stur            w0, [x2, #0xb]
    // 0xfb855c: LoadField: r6 = r2->field_f
    //     0xfb855c: ldur            w6, [x2, #0xf]
    // 0xfb8560: DecompressPointer r6
    //     0xfb8560: add             x6, x6, HEAP, lsl #32
    // 0xfb8564: mov             x1, x6
    // 0xfb8568: ldur            x0, [fp, #-0x20]
    // 0xfb856c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfb856c: add             x25, x1, x3, lsl #2
    //     0xfb8570: add             x25, x25, #0xf
    //     0xfb8574: str             w0, [x25]
    //     0xfb8578: tbz             w0, #0, #0xfb8594
    //     0xfb857c: ldurb           w16, [x1, #-1]
    //     0xfb8580: ldurb           w17, [x0, #-1]
    //     0xfb8584: and             x16, x17, x16, lsr #2
    //     0xfb8588: tst             x16, HEAP, lsr #32
    //     0xfb858c: b.eq            #0xfb8594
    //     0xfb8590: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfb8594: cmp             w4, NULL
    // 0xfb8598: b.eq            #0xfb85fc
    // 0xfb859c: LoadField: r0 = r6->field_b
    //     0xfb859c: ldur            w0, [x6, #0xb]
    // 0xfb85a0: r1 = LoadInt32Instr(r0)
    //     0xfb85a0: sbfx            x1, x0, #1, #0x1f
    // 0xfb85a4: cmp             x5, x1
    // 0xfb85a8: b.ne            #0xfb85b4
    // 0xfb85ac: mov             x1, x2
    // 0xfb85b0: r0 = _growToNextCapacity()
    //     0xfb85b0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfb85b4: ldur            x2, [fp, #-0x18]
    // 0xfb85b8: ldur            x3, [fp, #-0x58]
    // 0xfb85bc: add             x0, x3, #1
    // 0xfb85c0: lsl             x1, x0, #1
    // 0xfb85c4: StoreField: r2->field_b = r1
    //     0xfb85c4: stur            w1, [x2, #0xb]
    // 0xfb85c8: LoadField: r1 = r2->field_f
    //     0xfb85c8: ldur            w1, [x2, #0xf]
    // 0xfb85cc: DecompressPointer r1
    //     0xfb85cc: add             x1, x1, HEAP, lsl #32
    // 0xfb85d0: ldur            x0, [fp, #-0x10]
    // 0xfb85d4: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfb85d4: add             x25, x1, x3, lsl #2
    //     0xfb85d8: add             x25, x25, #0xf
    //     0xfb85dc: str             w0, [x25]
    //     0xfb85e0: tbz             w0, #0, #0xfb85fc
    //     0xfb85e4: ldurb           w16, [x1, #-1]
    //     0xfb85e8: ldurb           w17, [x0, #-1]
    //     0xfb85ec: and             x16, x17, x16, lsr #2
    //     0xfb85f0: tst             x16, HEAP, lsr #32
    //     0xfb85f4: b.eq            #0xfb85fc
    //     0xfb85f8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfb85fc: mov             x1, x2
    // 0xfb8600: ldur            x0, [fp, #-8]
    // 0xfb8604: stur            x1, [fp, #-0x10]
    // 0xfb8608: r0 = Column()
    //     0xfb8608: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xfb860c: mov             x1, x0
    // 0xfb8610: r0 = Instance_Axis
    //     0xfb8610: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xfb8614: stur            x1, [fp, #-0x18]
    // 0xfb8618: StoreField: r1->field_f = r0
    //     0xfb8618: stur            w0, [x1, #0xf]
    // 0xfb861c: r0 = Instance_MainAxisAlignment
    //     0xfb861c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xfb8620: ldr             x0, [x0, #0x820]
    // 0xfb8624: StoreField: r1->field_13 = r0
    //     0xfb8624: stur            w0, [x1, #0x13]
    // 0xfb8628: r0 = Instance_MainAxisSize
    //     0xfb8628: add             x0, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xfb862c: ldr             x0, [x0, #0x200]
    // 0xfb8630: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb8630: stur            w0, [x1, #0x17]
    // 0xfb8634: r0 = Instance_CrossAxisAlignment
    //     0xfb8634: add             x0, PP, #0x7b, lsl #12  ; [pp+0x7bc40] Obj!CrossAxisAlignment@12c4521
    //     0xfb8638: ldr             x0, [x0, #0xc40]
    // 0xfb863c: StoreField: r1->field_1b = r0
    //     0xfb863c: stur            w0, [x1, #0x1b]
    // 0xfb8640: r0 = Instance_VerticalDirection
    //     0xfb8640: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xfb8644: ldr             x0, [x0, #0x838]
    // 0xfb8648: StoreField: r1->field_23 = r0
    //     0xfb8648: stur            w0, [x1, #0x23]
    // 0xfb864c: r0 = Instance_Clip
    //     0xfb864c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb8650: ldr             x0, [x0, #0x840]
    // 0xfb8654: StoreField: r1->field_2b = r0
    //     0xfb8654: stur            w0, [x1, #0x2b]
    // 0xfb8658: StoreField: r1->field_2f = rZR
    //     0xfb8658: stur            xzr, [x1, #0x2f]
    // 0xfb865c: ldur            x0, [fp, #-0x10]
    // 0xfb8660: StoreField: r1->field_b = r0
    //     0xfb8660: stur            w0, [x1, #0xb]
    // 0xfb8664: r0 = IntrinsicWidth()
    //     0xfb8664: bl              #0xdf914c  ; AllocateIntrinsicWidthStub -> IntrinsicWidth (size=0x18)
    // 0xfb8668: mov             x1, x0
    // 0xfb866c: ldur            x0, [fp, #-0x18]
    // 0xfb8670: stur            x1, [fp, #-0x10]
    // 0xfb8674: StoreField: r1->field_b = r0
    //     0xfb8674: stur            w0, [x1, #0xb]
    // 0xfb8678: r0 = Semantics()
    //     0xfb8678: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xfb867c: stur            x0, [fp, #-0x18]
    // 0xfb8680: r16 = true
    //     0xfb8680: add             x16, NULL, #0x20  ; true
    // 0xfb8684: r30 = true
    //     0xfb8684: add             lr, NULL, #0x20  ; true
    // 0xfb8688: stp             lr, x16, [SP, #0x18]
    // 0xfb868c: r16 = true
    //     0xfb868c: add             x16, NULL, #0x20  ; true
    // 0xfb8690: ldur            lr, [fp, #-0x28]
    // 0xfb8694: stp             lr, x16, [SP, #8]
    // 0xfb8698: ldur            x16, [fp, #-0x10]
    // 0xfb869c: str             x16, [SP]
    // 0xfb86a0: mov             x1, x0
    // 0xfb86a4: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, explicitChildNodes, 0x2, label, 0x4, namesRoute, 0x3, scopesRoute, 0x1, null]
    //     0xfb86a4: add             x4, PP, #0x80, lsl #12  ; [pp+0x80ab8] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "explicitChildNodes", 0x2, "label", 0x4, "namesRoute", 0x3, "scopesRoute", 0x1, Null]
    //     0xfb86a8: ldr             x4, [x4, #0xab8]
    // 0xfb86ac: r0 = Semantics()
    //     0xfb86ac: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xfb86b0: ldur            x0, [fp, #-8]
    // 0xfb86b4: LoadField: r1 = r0->field_43
    //     0xfb86b4: ldur            w1, [x0, #0x43]
    // 0xfb86b8: DecompressPointer r1
    //     0xfb86b8: add             x1, x1, HEAP, lsl #32
    // 0xfb86bc: stur            x1, [fp, #-0x38]
    // 0xfb86c0: LoadField: r2 = r0->field_4b
    //     0xfb86c0: ldur            w2, [x0, #0x4b]
    // 0xfb86c4: DecompressPointer r2
    //     0xfb86c4: add             x2, x2, HEAP, lsl #32
    // 0xfb86c8: stur            x2, [fp, #-0x30]
    // 0xfb86cc: LoadField: r3 = r0->field_4f
    //     0xfb86cc: ldur            w3, [x0, #0x4f]
    // 0xfb86d0: DecompressPointer r3
    //     0xfb86d0: add             x3, x3, HEAP, lsl #32
    // 0xfb86d4: stur            x3, [fp, #-0x28]
    // 0xfb86d8: LoadField: r4 = r0->field_57
    //     0xfb86d8: ldur            w4, [x0, #0x57]
    // 0xfb86dc: DecompressPointer r4
    //     0xfb86dc: add             x4, x4, HEAP, lsl #32
    // 0xfb86e0: stur            x4, [fp, #-0x20]
    // 0xfb86e4: LoadField: r5 = r0->field_5f
    //     0xfb86e4: ldur            w5, [x0, #0x5f]
    // 0xfb86e8: DecompressPointer r5
    //     0xfb86e8: add             x5, x5, HEAP, lsl #32
    // 0xfb86ec: stur            x5, [fp, #-0x10]
    // 0xfb86f0: r0 = Dialog()
    //     0xfb86f0: bl              #0xd15834  ; AllocateDialogStub -> Dialog (size=0x44)
    // 0xfb86f4: ldur            x1, [fp, #-0x38]
    // 0xfb86f8: StoreField: r0->field_b = r1
    //     0xfb86f8: stur            w1, [x0, #0xb]
    // 0xfb86fc: ldur            x1, [fp, #-0x30]
    // 0xfb8700: StoreField: r0->field_13 = r1
    //     0xfb8700: stur            w1, [x0, #0x13]
    // 0xfb8704: ldur            x1, [fp, #-0x28]
    // 0xfb8708: ArrayStore: r0[0] = r1  ; List_4
    //     0xfb8708: stur            w1, [x0, #0x17]
    // 0xfb870c: r1 = Instance_Duration
    //     0xfb870c: ldr             x1, [PP, #0x5668]  ; [pp+0x5668] Obj!Duration@12c8941
    // 0xfb8710: StoreField: r0->field_1b = r1
    //     0xfb8710: stur            w1, [x0, #0x1b]
    // 0xfb8714: r1 = Instance__DecelerateCurve
    //     0xfb8714: ldr             x1, [PP, #0x5150]  ; [pp+0x5150] Obj!_DecelerateCurve@129f3d1
    // 0xfb8718: StoreField: r0->field_1f = r1
    //     0xfb8718: stur            w1, [x0, #0x1f]
    // 0xfb871c: ldur            x1, [fp, #-0x20]
    // 0xfb8720: StoreField: r0->field_23 = r1
    //     0xfb8720: stur            w1, [x0, #0x23]
    // 0xfb8724: ldur            x1, [fp, #-0x10]
    // 0xfb8728: StoreField: r0->field_2b = r1
    //     0xfb8728: stur            w1, [x0, #0x2b]
    // 0xfb872c: ldur            x1, [fp, #-0x18]
    // 0xfb8730: StoreField: r0->field_33 = r1
    //     0xfb8730: stur            w1, [x0, #0x33]
    // 0xfb8734: r1 = Instance_SemanticsRole
    //     0xfb8734: add             x1, PP, #0x80, lsl #12  ; [pp+0x80ac0] Obj!SemanticsRole@12c7921
    //     0xfb8738: ldr             x1, [x1, #0xac0]
    // 0xfb873c: StoreField: r0->field_3b = r1
    //     0xfb873c: stur            w1, [x0, #0x3b]
    // 0xfb8740: r1 = false
    //     0xfb8740: add             x1, NULL, #0x30  ; false
    // 0xfb8744: StoreField: r0->field_37 = r1
    //     0xfb8744: stur            w1, [x0, #0x37]
    // 0xfb8748: LeaveFrame
    //     0xfb8748: mov             SP, fp
    //     0xfb874c: ldp             fp, lr, [SP], #0x10
    // 0xfb8750: ret
    //     0xfb8750: ret             
    // 0xfb8754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb8754: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb8758: b               #0xfb79b8
    // 0xfb875c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfb875c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfb8760: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfb8760: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfb8764: SaveReg d0
    //     0xfb8764: str             q0, [SP, #-0x10]!
    // 0xfb8768: r0 = AllocateDouble()
    //     0xfb8768: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfb876c: RestoreReg d0
    //     0xfb876c: ldr             q0, [SP], #0x10
    // 0xfb8770: b               #0xfb7fbc
  }
}

// class id: 6166, size: 0x44, field offset: 0xc
//   const constructor, 
class Dialog extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfb72e4, size: 0x618
    // 0xfb72e4: EnterFrame
    //     0xfb72e4: stp             fp, lr, [SP, #-0x10]!
    //     0xfb72e8: mov             fp, SP
    // 0xfb72ec: AllocStack(0x78)
    //     0xfb72ec: sub             SP, SP, #0x78
    // 0xfb72f0: SetupParameters(Dialog this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfb72f0: mov             x0, x2
    //     0xfb72f4: stur            x2, [fp, #-0x10]
    //     0xfb72f8: mov             x2, x1
    //     0xfb72fc: stur            x1, [fp, #-8]
    // 0xfb7300: CheckStackOverflow
    //     0xfb7300: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb7304: cmp             SP, x16
    //     0xfb7308: b.ls            #0xfb78f0
    // 0xfb730c: mov             x1, x0
    // 0xfb7310: r0 = of()
    //     0xfb7310: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb7314: ldur            x1, [fp, #-0x10]
    // 0xfb7318: stur            x0, [fp, #-0x18]
    // 0xfb731c: r0 = of()
    //     0xfb731c: bl              #0xd95ca0  ; [package:flutter/src/material/dialog_theme.dart] DialogTheme::of
    // 0xfb7320: ldur            x1, [fp, #-0x10]
    // 0xfb7324: stur            x0, [fp, #-0x20]
    // 0xfb7328: r0 = viewInsetsOf()
    //     0xfb7328: bl              #0xd362b0  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::viewInsetsOf
    // 0xfb732c: mov             x1, x0
    // 0xfb7330: ldur            x0, [fp, #-8]
    // 0xfb7334: LoadField: r2 = r0->field_23
    //     0xfb7334: ldur            w2, [x0, #0x23]
    // 0xfb7338: DecompressPointer r2
    //     0xfb7338: add             x2, x2, HEAP, lsl #32
    // 0xfb733c: cmp             w2, NULL
    // 0xfb7340: b.ne            #0xfb7354
    // 0xfb7344: ldur            x3, [fp, #-0x20]
    // 0xfb7348: LoadField: r2 = r3->field_33
    //     0xfb7348: ldur            w2, [x3, #0x33]
    // 0xfb734c: DecompressPointer r2
    //     0xfb734c: add             x2, x2, HEAP, lsl #32
    // 0xfb7350: b               #0xfb7358
    // 0xfb7354: ldur            x3, [fp, #-0x20]
    // 0xfb7358: cmp             w2, NULL
    // 0xfb735c: b.ne            #0xfb7368
    // 0xfb7360: r2 = Instance_EdgeInsets
    //     0xfb7360: add             x2, PP, #0x8c, lsl #12  ; [pp+0x8cc00] Obj!EdgeInsets@129d501
    //     0xfb7364: ldr             x2, [x2, #0xc00]
    // 0xfb7368: ldur            x4, [fp, #-0x18]
    // 0xfb736c: r0 = +()
    //     0xfb736c: bl              #0x8584ec  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::+
    // 0xfb7370: mov             x1, x0
    // 0xfb7374: ldur            x0, [fp, #-0x18]
    // 0xfb7378: stur            x1, [fp, #-0x28]
    // 0xfb737c: LoadField: r2 = r0->field_2f
    //     0xfb737c: ldur            w2, [x0, #0x2f]
    // 0xfb7380: DecompressPointer r2
    //     0xfb7380: add             x2, x2, HEAP, lsl #32
    // 0xfb7384: tbnz            w2, #4, #0xfb73ec
    // 0xfb7388: ldur            x3, [fp, #-0x10]
    // 0xfb738c: r0 = _DialogDefaultsM3()
    //     0xfb738c: bl              #0xfb7908  ; Allocate_DialogDefaultsM3Stub -> _DialogDefaultsM3 (size=0x4c)
    // 0xfb7390: mov             x1, x0
    // 0xfb7394: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb7398: StoreField: r1->field_43 = r0
    //     0xfb7398: stur            w0, [x1, #0x43]
    // 0xfb739c: StoreField: r1->field_47 = r0
    //     0xfb739c: stur            w0, [x1, #0x47]
    // 0xfb73a0: ldur            x3, [fp, #-0x10]
    // 0xfb73a4: StoreField: r1->field_3f = r3
    //     0xfb73a4: stur            w3, [x1, #0x3f]
    // 0xfb73a8: r0 = 6.000000
    //     0xfb73a8: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c438] 6
    //     0xfb73ac: ldr             x0, [x0, #0x438]
    // 0xfb73b0: StoreField: r1->field_b = r0
    //     0xfb73b0: stur            w0, [x1, #0xb]
    // 0xfb73b4: r0 = Instance_RoundedRectangleBorder
    //     0xfb73b4: add             x0, PP, #0x26, lsl #12  ; [pp+0x26370] Obj!RoundedRectangleBorder@129ec41
    //     0xfb73b8: ldr             x0, [x0, #0x370]
    // 0xfb73bc: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb73bc: stur            w0, [x1, #0x17]
    // 0xfb73c0: r2 = Instance_Alignment
    //     0xfb73c0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfb73c4: ldr             x2, [x2, #0xb80]
    // 0xfb73c8: StoreField: r1->field_1b = r2
    //     0xfb73c8: stur            w2, [x1, #0x1b]
    // 0xfb73cc: r4 = Instance_Clip
    //     0xfb73cc: add             x4, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb73d0: ldr             x4, [x4, #0x840]
    // 0xfb73d4: StoreField: r1->field_37 = r4
    //     0xfb73d4: stur            w4, [x1, #0x37]
    // 0xfb73d8: mov             x4, x1
    // 0xfb73dc: d0 = 6.000000
    //     0xfb73dc: fmov            d0, #6.00000000
    // 0xfb73e0: r2 = Instance_RoundedRectangleBorder
    //     0xfb73e0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26370] Obj!RoundedRectangleBorder@129ec41
    //     0xfb73e4: ldr             x2, [x2, #0x370]
    // 0xfb73e8: b               #0xfb7464
    // 0xfb73ec: ldur            x3, [fp, #-0x10]
    // 0xfb73f0: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb73f4: r2 = Instance_Alignment
    //     0xfb73f4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfb73f8: ldr             x2, [x2, #0xb80]
    // 0xfb73fc: r4 = Instance_Clip
    //     0xfb73fc: add             x4, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb7400: ldr             x4, [x4, #0x840]
    // 0xfb7404: r0 = _DialogDefaultsM2()
    //     0xfb7404: bl              #0xfb78fc  ; Allocate_DialogDefaultsM2Stub -> _DialogDefaultsM2 (size=0x50)
    // 0xfb7408: mov             x1, x0
    // 0xfb740c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb7410: StoreField: r1->field_43 = r0
    //     0xfb7410: stur            w0, [x1, #0x43]
    // 0xfb7414: StoreField: r1->field_47 = r0
    //     0xfb7414: stur            w0, [x1, #0x47]
    // 0xfb7418: StoreField: r1->field_4b = r0
    //     0xfb7418: stur            w0, [x1, #0x4b]
    // 0xfb741c: ldur            x3, [fp, #-0x10]
    // 0xfb7420: StoreField: r1->field_3f = r3
    //     0xfb7420: stur            w3, [x1, #0x3f]
    // 0xfb7424: r0 = 24.000000
    //     0xfb7424: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0xfb7428: ldr             x0, [x0, #0x4d0]
    // 0xfb742c: StoreField: r1->field_b = r0
    //     0xfb742c: stur            w0, [x1, #0xb]
    // 0xfb7430: r0 = Instance_RoundedRectangleBorder
    //     0xfb7430: add             x0, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0xfb7434: ldr             x0, [x0, #0x218]
    // 0xfb7438: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb7438: stur            w0, [x1, #0x17]
    // 0xfb743c: r0 = Instance_Alignment
    //     0xfb743c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfb7440: ldr             x0, [x0, #0xb80]
    // 0xfb7444: StoreField: r1->field_1b = r0
    //     0xfb7444: stur            w0, [x1, #0x1b]
    // 0xfb7448: r0 = Instance_Clip
    //     0xfb7448: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb744c: ldr             x0, [x0, #0x840]
    // 0xfb7450: StoreField: r1->field_37 = r0
    //     0xfb7450: stur            w0, [x1, #0x37]
    // 0xfb7454: mov             x4, x1
    // 0xfb7458: d0 = 24.000000
    //     0xfb7458: fmov            d0, #24.00000000
    // 0xfb745c: r2 = Instance_RoundedRectangleBorder
    //     0xfb745c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0xfb7460: ldr             x2, [x2, #0x218]
    // 0xfb7464: ldur            x0, [fp, #-0x20]
    // 0xfb7468: stur            x4, [fp, #-0x38]
    // 0xfb746c: stur            x2, [fp, #-0x40]
    // 0xfb7470: stur            d0, [fp, #-0x68]
    // 0xfb7474: LoadField: r1 = r0->field_3b
    //     0xfb7474: ldur            w1, [x0, #0x3b]
    // 0xfb7478: DecompressPointer r1
    //     0xfb7478: add             x1, x1, HEAP, lsl #32
    // 0xfb747c: cmp             w1, NULL
    // 0xfb7480: b.ne            #0xfb7490
    // 0xfb7484: r5 = Instance_BoxConstraints
    //     0xfb7484: add             x5, PP, #0x8c, lsl #12  ; [pp+0x8cc08] Obj!BoxConstraints@129c441
    //     0xfb7488: ldr             x5, [x5, #0xc08]
    // 0xfb748c: b               #0xfb7494
    // 0xfb7490: mov             x5, x1
    // 0xfb7494: stur            x5, [fp, #-0x30]
    // 0xfb7498: LoadField: r1 = r0->field_1b
    //     0xfb7498: ldur            w1, [x0, #0x1b]
    // 0xfb749c: DecompressPointer r1
    //     0xfb749c: add             x1, x1, HEAP, lsl #32
    // 0xfb74a0: cmp             w1, NULL
    // 0xfb74a4: b.ne            #0xfb74b4
    // 0xfb74a8: r7 = Instance_Alignment
    //     0xfb74a8: add             x7, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfb74ac: ldr             x7, [x7, #0xb80]
    // 0xfb74b0: b               #0xfb74b8
    // 0xfb74b4: mov             x7, x1
    // 0xfb74b8: ldur            x6, [fp, #-8]
    // 0xfb74bc: stur            x7, [fp, #-0x18]
    // 0xfb74c0: LoadField: r1 = r6->field_b
    //     0xfb74c0: ldur            w1, [x6, #0xb]
    // 0xfb74c4: DecompressPointer r1
    //     0xfb74c4: add             x1, x1, HEAP, lsl #32
    // 0xfb74c8: cmp             w1, NULL
    // 0xfb74cc: b.ne            #0xfb74d4
    // 0xfb74d0: r1 = Null
    //     0xfb74d0: mov             x1, NULL
    // 0xfb74d4: cmp             w1, NULL
    // 0xfb74d8: b.ne            #0xfb75d0
    // 0xfb74dc: r1 = LoadClassIdInstr(r4)
    //     0xfb74dc: ldur            x1, [x4, #-1]
    //     0xfb74e0: ubfx            x1, x1, #0xc, #0x14
    // 0xfb74e4: r17 = 5163
    //     0xfb74e4: mov             x17, #0x142b
    // 0xfb74e8: cmp             x1, x17
    // 0xfb74ec: b.ne            #0xfb7500
    // 0xfb74f0: LoadField: r1 = r4->field_7
    //     0xfb74f0: ldur            w1, [x4, #7]
    // 0xfb74f4: DecompressPointer r1
    //     0xfb74f4: add             x1, x1, HEAP, lsl #32
    // 0xfb74f8: mov             x0, x1
    // 0xfb74fc: b               #0xfb75c8
    // 0xfb7500: r17 = 5164
    //     0xfb7500: mov             x17, #0x142c
    // 0xfb7504: cmp             x1, x17
    // 0xfb7508: b.ne            #0xfb7558
    // 0xfb750c: mov             x1, x4
    // 0xfb7510: LoadField: r0 = r1->field_43
    //     0xfb7510: ldur            w0, [x1, #0x43]
    // 0xfb7514: DecompressPointer r0
    //     0xfb7514: add             x0, x0, HEAP, lsl #32
    // 0xfb7518: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb751c: cmp             w0, w16
    // 0xfb7520: b.ne            #0xfb7530
    // 0xfb7524: r2 = _colors
    //     0xfb7524: add             x2, PP, #0x26, lsl #12  ; [pp+0x263d0] Field <_DialogDefaultsM3@664506021._colors@664506021>: late final (offset: 0x44)
    //     0xfb7528: ldr             x2, [x2, #0x3d0]
    // 0xfb752c: r0 = InitLateFinalInstanceField()
    //     0xfb752c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfb7530: LoadField: r1 = r0->field_9b
    //     0xfb7530: ldur            w1, [x0, #0x9b]
    // 0xfb7534: DecompressPointer r1
    //     0xfb7534: add             x1, x1, HEAP, lsl #32
    // 0xfb7538: cmp             w1, NULL
    // 0xfb753c: b.ne            #0xfb7550
    // 0xfb7540: LoadField: r1 = r0->field_7b
    //     0xfb7540: ldur            w1, [x0, #0x7b]
    // 0xfb7544: DecompressPointer r1
    //     0xfb7544: add             x1, x1, HEAP, lsl #32
    // 0xfb7548: mov             x0, x1
    // 0xfb754c: b               #0xfb75c8
    // 0xfb7550: mov             x0, x1
    // 0xfb7554: b               #0xfb75c8
    // 0xfb7558: r17 = 5165
    //     0xfb7558: mov             x17, #0x142d
    // 0xfb755c: cmp             x1, x17
    // 0xfb7560: b.eq            #0xfb78e4
    // 0xfb7564: ldur            x1, [fp, #-0x38]
    // 0xfb7568: LoadField: r0 = r1->field_43
    //     0xfb7568: ldur            w0, [x1, #0x43]
    // 0xfb756c: DecompressPointer r0
    //     0xfb756c: add             x0, x0, HEAP, lsl #32
    // 0xfb7570: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb7574: cmp             w0, w16
    // 0xfb7578: b.ne            #0xfb7588
    // 0xfb757c: r2 = theme
    //     0xfb757c: add             x2, PP, #0x26, lsl #12  ; [pp+0x263d8] Field <_DialogDefaultsM2@664506021.theme>: late final (offset: 0x44)
    //     0xfb7580: ldr             x2, [x2, #0x3d8]
    // 0xfb7584: r0 = InitLateFinalInstanceField()
    //     0xfb7584: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfb7588: LoadField: r1 = r0->field_3f
    //     0xfb7588: ldur            w1, [x0, #0x3f]
    // 0xfb758c: DecompressPointer r1
    //     0xfb758c: add             x1, x1, HEAP, lsl #32
    // 0xfb7590: LoadField: r0 = r1->field_7
    //     0xfb7590: ldur            w0, [x1, #7]
    // 0xfb7594: DecompressPointer r0
    //     0xfb7594: add             x0, x0, HEAP, lsl #32
    // 0xfb7598: r16 = Instance_Brightness
    //     0xfb7598: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xfb759c: cmp             w0, w16
    // 0xfb75a0: b.ne            #0xfb75c0
    // 0xfb75a4: r1 = _ConstMap len:12
    //     0xfb75a4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c20] Map<int, Color>(12)
    //     0xfb75a8: ldr             x1, [x1, #0xc20]
    // 0xfb75ac: r2 = 1600
    //     0xfb75ac: mov             x2, #0x640
    // 0xfb75b0: r0 = []()
    //     0xfb75b0: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0xfb75b4: cmp             w0, NULL
    // 0xfb75b8: b.eq            #0xfb78f8
    // 0xfb75bc: b               #0xfb75c8
    // 0xfb75c0: r0 = Instance_Color
    //     0xfb75c0: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xfb75c4: ldr             x0, [x0, #0xc38]
    // 0xfb75c8: mov             x2, x0
    // 0xfb75cc: b               #0xfb75d4
    // 0xfb75d0: mov             x2, x1
    // 0xfb75d4: ldur            x0, [fp, #-8]
    // 0xfb75d8: stur            x2, [fp, #-0x48]
    // 0xfb75dc: LoadField: r1 = r0->field_f
    //     0xfb75dc: ldur            w1, [x0, #0xf]
    // 0xfb75e0: DecompressPointer r1
    //     0xfb75e0: add             x1, x1, HEAP, lsl #32
    // 0xfb75e4: cmp             w1, NULL
    // 0xfb75e8: b.ne            #0xfb75fc
    // 0xfb75ec: ldur            x3, [fp, #-0x20]
    // 0xfb75f0: LoadField: r1 = r3->field_b
    //     0xfb75f0: ldur            w1, [x3, #0xb]
    // 0xfb75f4: DecompressPointer r1
    //     0xfb75f4: add             x1, x1, HEAP, lsl #32
    // 0xfb75f8: b               #0xfb7600
    // 0xfb75fc: ldur            x3, [fp, #-0x20]
    // 0xfb7600: cmp             w1, NULL
    // 0xfb7604: b.ne            #0xfb7610
    // 0xfb7608: ldur            d0, [fp, #-0x68]
    // 0xfb760c: b               #0xfb7614
    // 0xfb7610: LoadField: d0 = r1->field_7
    //     0xfb7610: ldur            d0, [x1, #7]
    // 0xfb7614: stur            d0, [fp, #-0x68]
    // 0xfb7618: LoadField: r1 = r0->field_13
    //     0xfb7618: ldur            w1, [x0, #0x13]
    // 0xfb761c: DecompressPointer r1
    //     0xfb761c: add             x1, x1, HEAP, lsl #32
    // 0xfb7620: cmp             w1, NULL
    // 0xfb7624: b.ne            #0xfb762c
    // 0xfb7628: r1 = Null
    //     0xfb7628: mov             x1, NULL
    // 0xfb762c: cmp             w1, NULL
    // 0xfb7630: b.ne            #0xfb76b4
    // 0xfb7634: ldur            x4, [fp, #-0x38]
    // 0xfb7638: r1 = LoadClassIdInstr(r4)
    //     0xfb7638: ldur            x1, [x4, #-1]
    //     0xfb763c: ubfx            x1, x1, #0xc, #0x14
    // 0xfb7640: r17 = 5163
    //     0xfb7640: mov             x17, #0x142b
    // 0xfb7644: cmp             x1, x17
    // 0xfb7648: b.eq            #0xfb7670
    // 0xfb764c: r17 = 5164
    //     0xfb764c: mov             x17, #0x142c
    // 0xfb7650: cmp             x1, x17
    // 0xfb7654: b.ne            #0xfb7664
    // 0xfb7658: r0 = Instance_Color
    //     0xfb7658: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xfb765c: ldr             x0, [x0, #0x810]
    // 0xfb7660: b               #0xfb76b0
    // 0xfb7664: r17 = 5165
    //     0xfb7664: mov             x17, #0x142d
    // 0xfb7668: cmp             x1, x17
    // 0xfb766c: b.ne            #0xfb7680
    // 0xfb7670: LoadField: r1 = r4->field_f
    //     0xfb7670: ldur            w1, [x4, #0xf]
    // 0xfb7674: DecompressPointer r1
    //     0xfb7674: add             x1, x1, HEAP, lsl #32
    // 0xfb7678: mov             x0, x1
    // 0xfb767c: b               #0xfb76b0
    // 0xfb7680: mov             x1, x4
    // 0xfb7684: LoadField: r0 = r1->field_43
    //     0xfb7684: ldur            w0, [x1, #0x43]
    // 0xfb7688: DecompressPointer r0
    //     0xfb7688: add             x0, x0, HEAP, lsl #32
    // 0xfb768c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb7690: cmp             w0, w16
    // 0xfb7694: b.ne            #0xfb76a4
    // 0xfb7698: r2 = theme
    //     0xfb7698: add             x2, PP, #0x26, lsl #12  ; [pp+0x263d8] Field <_DialogDefaultsM2@664506021.theme>: late final (offset: 0x44)
    //     0xfb769c: ldr             x2, [x2, #0x3d8]
    // 0xfb76a0: r0 = InitLateFinalInstanceField()
    //     0xfb76a0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfb76a4: LoadField: r1 = r0->field_6f
    //     0xfb76a4: ldur            w1, [x0, #0x6f]
    // 0xfb76a8: DecompressPointer r1
    //     0xfb76a8: add             x1, x1, HEAP, lsl #32
    // 0xfb76ac: mov             x0, x1
    // 0xfb76b0: mov             x1, x0
    // 0xfb76b4: ldur            x0, [fp, #-8]
    // 0xfb76b8: stur            x1, [fp, #-0x58]
    // 0xfb76bc: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xfb76bc: ldur            w2, [x0, #0x17]
    // 0xfb76c0: DecompressPointer r2
    //     0xfb76c0: add             x2, x2, HEAP, lsl #32
    // 0xfb76c4: cmp             w2, NULL
    // 0xfb76c8: b.ne            #0xfb76d0
    // 0xfb76cc: r2 = Null
    //     0xfb76cc: mov             x2, NULL
    // 0xfb76d0: cmp             w2, NULL
    // 0xfb76d4: b.ne            #0xfb7718
    // 0xfb76d8: ldur            x2, [fp, #-0x38]
    // 0xfb76dc: r3 = LoadClassIdInstr(r2)
    //     0xfb76dc: ldur            x3, [x2, #-1]
    //     0xfb76e0: ubfx            x3, x3, #0xc, #0x14
    // 0xfb76e4: r17 = -5165
    //     0xfb76e4: mov             x17, #-0x142d
    // 0xfb76e8: add             x16, x3, x17
    // 0xfb76ec: cmp             x16, #1
    // 0xfb76f0: b.ls            #0xfb7700
    // 0xfb76f4: r17 = 5163
    //     0xfb76f4: mov             x17, #0x142b
    // 0xfb76f8: cmp             x3, x17
    // 0xfb76fc: b.ne            #0xfb7710
    // 0xfb7700: LoadField: r3 = r2->field_13
    //     0xfb7700: ldur            w3, [x2, #0x13]
    // 0xfb7704: DecompressPointer r3
    //     0xfb7704: add             x3, x3, HEAP, lsl #32
    // 0xfb7708: mov             x2, x3
    // 0xfb770c: b               #0xfb7718
    // 0xfb7710: r2 = Instance_Color
    //     0xfb7710: add             x2, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xfb7714: ldr             x2, [x2, #0x810]
    // 0xfb7718: stur            x2, [fp, #-0x50]
    // 0xfb771c: LoadField: r3 = r0->field_2b
    //     0xfb771c: ldur            w3, [x0, #0x2b]
    // 0xfb7720: DecompressPointer r3
    //     0xfb7720: add             x3, x3, HEAP, lsl #32
    // 0xfb7724: cmp             w3, NULL
    // 0xfb7728: b.ne            #0xfb773c
    // 0xfb772c: ldur            x4, [fp, #-0x20]
    // 0xfb7730: ArrayLoad: r3 = r4[0]  ; List_4
    //     0xfb7730: ldur            w3, [x4, #0x17]
    // 0xfb7734: DecompressPointer r3
    //     0xfb7734: add             x3, x3, HEAP, lsl #32
    // 0xfb7738: b               #0xfb7740
    // 0xfb773c: ldur            x4, [fp, #-0x20]
    // 0xfb7740: cmp             w3, NULL
    // 0xfb7744: b.ne            #0xfb774c
    // 0xfb7748: ldur            x3, [fp, #-0x40]
    // 0xfb774c: stur            x3, [fp, #-0x40]
    // 0xfb7750: LoadField: r5 = r0->field_27
    //     0xfb7750: ldur            w5, [x0, #0x27]
    // 0xfb7754: DecompressPointer r5
    //     0xfb7754: add             x5, x5, HEAP, lsl #32
    // 0xfb7758: cmp             w5, NULL
    // 0xfb775c: b.ne            #0xfb7770
    // 0xfb7760: LoadField: r5 = r4->field_37
    //     0xfb7760: ldur            w5, [x4, #0x37]
    // 0xfb7764: DecompressPointer r5
    //     0xfb7764: add             x5, x5, HEAP, lsl #32
    // 0xfb7768: mov             x4, x5
    // 0xfb776c: b               #0xfb7774
    // 0xfb7770: mov             x4, x5
    // 0xfb7774: cmp             w4, NULL
    // 0xfb7778: b.ne            #0xfb7788
    // 0xfb777c: r8 = Instance_Clip
    //     0xfb777c: add             x8, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb7780: ldr             x8, [x8, #0x840]
    // 0xfb7784: b               #0xfb778c
    // 0xfb7788: mov             x8, x4
    // 0xfb778c: ldur            x7, [fp, #-0x28]
    // 0xfb7790: ldur            x5, [fp, #-0x30]
    // 0xfb7794: ldur            x6, [fp, #-0x18]
    // 0xfb7798: ldur            x4, [fp, #-0x48]
    // 0xfb779c: ldur            d0, [fp, #-0x68]
    // 0xfb77a0: stur            x8, [fp, #-0x38]
    // 0xfb77a4: LoadField: r9 = r0->field_33
    //     0xfb77a4: ldur            w9, [x0, #0x33]
    // 0xfb77a8: DecompressPointer r9
    //     0xfb77a8: add             x9, x9, HEAP, lsl #32
    // 0xfb77ac: stur            x9, [fp, #-0x20]
    // 0xfb77b0: r0 = Material()
    //     0xfb77b0: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xfb77b4: mov             x1, x0
    // 0xfb77b8: r0 = Instance_MaterialType
    //     0xfb77b8: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8c988] Obj!MaterialType@12c53c1
    //     0xfb77bc: ldr             x0, [x0, #0x988]
    // 0xfb77c0: stur            x1, [fp, #-0x60]
    // 0xfb77c4: StoreField: r1->field_f = r0
    //     0xfb77c4: stur            w0, [x1, #0xf]
    // 0xfb77c8: ldur            d0, [fp, #-0x68]
    // 0xfb77cc: ArrayStore: r1[0] = d0  ; List_8
    //     0xfb77cc: stur            d0, [x1, #0x17]
    // 0xfb77d0: ldur            x0, [fp, #-0x48]
    // 0xfb77d4: StoreField: r1->field_1f = r0
    //     0xfb77d4: stur            w0, [x1, #0x1f]
    // 0xfb77d8: ldur            x0, [fp, #-0x58]
    // 0xfb77dc: StoreField: r1->field_23 = r0
    //     0xfb77dc: stur            w0, [x1, #0x23]
    // 0xfb77e0: ldur            x0, [fp, #-0x50]
    // 0xfb77e4: StoreField: r1->field_27 = r0
    //     0xfb77e4: stur            w0, [x1, #0x27]
    // 0xfb77e8: ldur            x0, [fp, #-0x40]
    // 0xfb77ec: StoreField: r1->field_2f = r0
    //     0xfb77ec: stur            w0, [x1, #0x2f]
    // 0xfb77f0: r0 = true
    //     0xfb77f0: add             x0, NULL, #0x20  ; true
    // 0xfb77f4: StoreField: r1->field_33 = r0
    //     0xfb77f4: stur            w0, [x1, #0x33]
    // 0xfb77f8: ldur            x0, [fp, #-0x38]
    // 0xfb77fc: StoreField: r1->field_37 = r0
    //     0xfb77fc: stur            w0, [x1, #0x37]
    // 0xfb7800: r0 = Instance_Duration
    //     0xfb7800: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xfb7804: ldr             x0, [x0, #0x318]
    // 0xfb7808: StoreField: r1->field_3b = r0
    //     0xfb7808: stur            w0, [x1, #0x3b]
    // 0xfb780c: ldur            x0, [fp, #-0x20]
    // 0xfb7810: StoreField: r1->field_b = r0
    //     0xfb7810: stur            w0, [x1, #0xb]
    // 0xfb7814: r0 = false
    //     0xfb7814: add             x0, NULL, #0x30  ; false
    // 0xfb7818: StoreField: r1->field_13 = r0
    //     0xfb7818: stur            w0, [x1, #0x13]
    // 0xfb781c: r0 = ConstrainedBox()
    //     0xfb781c: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xfb7820: mov             x1, x0
    // 0xfb7824: ldur            x0, [fp, #-0x30]
    // 0xfb7828: stur            x1, [fp, #-0x20]
    // 0xfb782c: StoreField: r1->field_f = r0
    //     0xfb782c: stur            w0, [x1, #0xf]
    // 0xfb7830: ldur            x0, [fp, #-0x60]
    // 0xfb7834: StoreField: r1->field_b = r0
    //     0xfb7834: stur            w0, [x1, #0xb]
    // 0xfb7838: r0 = Align()
    //     0xfb7838: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xfb783c: mov             x2, x0
    // 0xfb7840: ldur            x0, [fp, #-0x18]
    // 0xfb7844: stur            x2, [fp, #-0x30]
    // 0xfb7848: StoreField: r2->field_f = r0
    //     0xfb7848: stur            w0, [x2, #0xf]
    // 0xfb784c: ldur            x0, [fp, #-0x20]
    // 0xfb7850: StoreField: r2->field_b = r0
    //     0xfb7850: stur            w0, [x2, #0xb]
    // 0xfb7854: ldur            x0, [fp, #-8]
    // 0xfb7858: LoadField: r3 = r0->field_3b
    //     0xfb7858: ldur            w3, [x0, #0x3b]
    // 0xfb785c: DecompressPointer r3
    //     0xfb785c: add             x3, x3, HEAP, lsl #32
    // 0xfb7860: stur            x3, [fp, #-0x18]
    // 0xfb7864: r1 = <_MediaQueryAspect>
    //     0xfb7864: add             x1, PP, #0x12, lsl #12  ; [pp+0x12828] TypeArguments: <_MediaQueryAspect>
    //     0xfb7868: ldr             x1, [x1, #0x828]
    // 0xfb786c: r0 = MediaQuery()
    //     0xfb786c: bl              #0xd0af24  ; AllocateMediaQueryStub -> MediaQuery (size=0x18)
    // 0xfb7870: mov             x1, x0
    // 0xfb7874: ldur            x2, [fp, #-0x30]
    // 0xfb7878: ldur            x3, [fp, #-0x10]
    // 0xfb787c: stur            x0, [fp, #-8]
    // 0xfb7880: r0 = MediaQuery.removeViewInsets()
    //     0xfb7880: bl              #0xde3a9c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::MediaQuery.removeViewInsets
    // 0xfb7884: r0 = AnimatedPadding()
    //     0xfb7884: bl              #0xde3a90  ; AllocateAnimatedPaddingStub -> AnimatedPadding (size=0x20)
    // 0xfb7888: mov             x1, x0
    // 0xfb788c: ldur            x0, [fp, #-0x28]
    // 0xfb7890: stur            x1, [fp, #-0x10]
    // 0xfb7894: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb7894: stur            w0, [x1, #0x17]
    // 0xfb7898: ldur            x0, [fp, #-8]
    // 0xfb789c: StoreField: r1->field_1b = r0
    //     0xfb789c: stur            w0, [x1, #0x1b]
    // 0xfb78a0: r0 = Instance__DecelerateCurve
    //     0xfb78a0: ldr             x0, [PP, #0x5150]  ; [pp+0x5150] Obj!_DecelerateCurve@129f3d1
    // 0xfb78a4: StoreField: r1->field_b = r0
    //     0xfb78a4: stur            w0, [x1, #0xb]
    // 0xfb78a8: r0 = Instance_Duration
    //     0xfb78a8: ldr             x0, [PP, #0x5668]  ; [pp+0x5668] Obj!Duration@12c8941
    // 0xfb78ac: StoreField: r1->field_f = r0
    //     0xfb78ac: stur            w0, [x1, #0xf]
    // 0xfb78b0: r0 = Semantics()
    //     0xfb78b0: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xfb78b4: stur            x0, [fp, #-8]
    // 0xfb78b8: ldur            x16, [fp, #-0x18]
    // 0xfb78bc: ldur            lr, [fp, #-0x10]
    // 0xfb78c0: stp             lr, x16, [SP]
    // 0xfb78c4: mov             x1, x0
    // 0xfb78c8: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, role, 0x1, null]
    //     0xfb78c8: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8c7f8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "role", 0x1, Null]
    //     0xfb78cc: ldr             x4, [x4, #0x7f8]
    // 0xfb78d0: r0 = Semantics()
    //     0xfb78d0: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xfb78d4: ldur            x0, [fp, #-8]
    // 0xfb78d8: LeaveFrame
    //     0xfb78d8: mov             SP, fp
    //     0xfb78dc: ldp             fp, lr, [SP], #0x10
    // 0xfb78e0: ret
    //     0xfb78e0: ret             
    // 0xfb78e4: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xfb78e4: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xfb78e8: r0 = Throw()
    //     0xfb78e8: bl              #0x13ddb2c  ; ThrowStub
    // 0xfb78ec: brk             #0
    // 0xfb78f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb78f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb78f4: b               #0xfb730c
    // 0xfb78f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfb78f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}
