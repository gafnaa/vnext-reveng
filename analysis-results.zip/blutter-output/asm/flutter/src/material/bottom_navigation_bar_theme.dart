// lib: , url: package:flutter/src/material/bottom_navigation_bar_theme.dart

// class id: 1048852, size: 0x8
class :: {
}

// class id: 5203, size: 0x40, field offset: 0x8
//   const constructor, 
class BottomNavigationBarThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x112ef74, size: 0x88
    // 0x112ef74: EnterFrame
    //     0x112ef74: stp             fp, lr, [SP, #-0x10]!
    //     0x112ef78: mov             fp, SP
    // 0x112ef7c: AllocStack(0x60)
    //     0x112ef7c: sub             SP, SP, #0x60
    // 0x112ef80: CheckStackOverflow
    //     0x112ef80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112ef84: cmp             SP, x16
    //     0x112ef88: b.ls            #0x112eff4
    // 0x112ef8c: ldr             x0, [fp, #0x10]
    // 0x112ef90: LoadField: r2 = r0->field_b
    //     0x112ef90: ldur            w2, [x0, #0xb]
    // 0x112ef94: DecompressPointer r2
    //     0x112ef94: add             x2, x2, HEAP, lsl #32
    // 0x112ef98: LoadField: r1 = r0->field_f
    //     0x112ef98: ldur            w1, [x0, #0xf]
    // 0x112ef9c: DecompressPointer r1
    //     0x112ef9c: add             x1, x1, HEAP, lsl #32
    // 0x112efa0: LoadField: r3 = r0->field_13
    //     0x112efa0: ldur            w3, [x0, #0x13]
    // 0x112efa4: DecompressPointer r3
    //     0x112efa4: add             x3, x3, HEAP, lsl #32
    // 0x112efa8: stp             x3, x1, [SP, #0x50]
    // 0x112efac: stp             NULL, NULL, [SP, #0x40]
    // 0x112efb0: stp             NULL, NULL, [SP, #0x30]
    // 0x112efb4: stp             NULL, NULL, [SP, #0x20]
    // 0x112efb8: stp             NULL, NULL, [SP, #0x10]
    // 0x112efbc: stp             NULL, NULL, [SP]
    // 0x112efc0: r1 = Null
    //     0x112efc0: mov             x1, NULL
    // 0x112efc4: r4 = const [0, 0xe, 0xc, 0xe, null]
    //     0x112efc4: add             x4, PP, #0x26, lsl #12  ; [pp+0x26520] List(5) [0, 0xe, 0xc, 0xe, Null]
    //     0x112efc8: ldr             x4, [x4, #0x520]
    // 0x112efcc: r0 = hash()
    //     0x112efcc: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x112efd0: mov             x2, x0
    // 0x112efd4: r0 = BoxInt64Instr(r2)
    //     0x112efd4: sbfiz           x0, x2, #1, #0x1f
    //     0x112efd8: cmp             x2, x0, asr #1
    //     0x112efdc: b.eq            #0x112efe8
    //     0x112efe0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x112efe4: stur            x2, [x0, #7]
    // 0x112efe8: LeaveFrame
    //     0x112efe8: mov             SP, fp
    //     0x112efec: ldp             fp, lr, [SP], #0x10
    // 0x112eff0: ret
    //     0x112eff0: ret             
    // 0x112eff4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112eff4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112eff8: b               #0x112ef8c
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x11688e4, size: 0x180
    // 0x11688e4: EnterFrame
    //     0x11688e4: stp             fp, lr, [SP, #-0x10]!
    //     0x11688e8: mov             fp, SP
    // 0x11688ec: AllocStack(0x28)
    //     0x11688ec: sub             SP, SP, #0x28
    // 0x11688f0: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0x11688f0: mov             x4, x1
    //     0x11688f4: mov             x0, x2
    //     0x11688f8: stur            x1, [fp, #-0x10]
    //     0x11688fc: stur            x2, [fp, #-0x18]
    // 0x1168900: CheckStackOverflow
    //     0x1168900: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1168904: cmp             SP, x16
    //     0x1168908: b.ls            #0x1168a40
    // 0x116890c: cmp             w4, w0
    // 0x1168910: b.ne            #0x1168924
    // 0x1168914: mov             x0, x4
    // 0x1168918: LeaveFrame
    //     0x1168918: mov             SP, fp
    //     0x116891c: ldp             fp, lr, [SP], #0x10
    // 0x1168920: ret
    //     0x1168920: ret             
    // 0x1168924: r5 = inline_Allocate_Double()
    //     0x1168924: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x1168928: add             x5, x5, #0x10
    //     0x116892c: cmp             x1, x5
    //     0x1168930: b.ls            #0x1168a48
    //     0x1168934: str             x5, [THR, #0x60]  ; THR::top
    //     0x1168938: sub             x5, x5, #0xf
    //     0x116893c: mov             x1, #0xe19c
    //     0x1168940: movk            x1, #3, lsl #16
    //     0x1168944: stur            x1, [x5, #-1]
    // 0x1168948: dmb             ishst
    // 0x116894c: StoreField: r5->field_7 = d0
    //     0x116894c: stur            d0, [x5, #7]
    // 0x1168950: mov             x3, x5
    // 0x1168954: stur            x5, [fp, #-8]
    // 0x1168958: r1 = Null
    //     0x1168958: mov             x1, NULL
    // 0x116895c: r2 = Null
    //     0x116895c: mov             x2, NULL
    // 0x1168960: r0 = lerp()
    //     0x1168960: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168964: ldur            x0, [fp, #-0x10]
    // 0x1168968: LoadField: r1 = r0->field_b
    //     0x1168968: ldur            w1, [x0, #0xb]
    // 0x116896c: DecompressPointer r1
    //     0x116896c: add             x1, x1, HEAP, lsl #32
    // 0x1168970: ldur            x4, [fp, #-0x18]
    // 0x1168974: LoadField: r2 = r4->field_b
    //     0x1168974: ldur            w2, [x4, #0xb]
    // 0x1168978: DecompressPointer r2
    //     0x1168978: add             x2, x2, HEAP, lsl #32
    // 0x116897c: ldur            x3, [fp, #-8]
    // 0x1168980: r0 = lerpDouble()
    //     0x1168980: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1168984: mov             x4, x0
    // 0x1168988: ldur            x0, [fp, #-0x10]
    // 0x116898c: stur            x4, [fp, #-0x20]
    // 0x1168990: LoadField: r1 = r0->field_f
    //     0x1168990: ldur            w1, [x0, #0xf]
    // 0x1168994: DecompressPointer r1
    //     0x1168994: add             x1, x1, HEAP, lsl #32
    // 0x1168998: ldur            x5, [fp, #-0x18]
    // 0x116899c: LoadField: r2 = r5->field_f
    //     0x116899c: ldur            w2, [x5, #0xf]
    // 0x11689a0: DecompressPointer r2
    //     0x11689a0: add             x2, x2, HEAP, lsl #32
    // 0x11689a4: ldur            x3, [fp, #-8]
    // 0x11689a8: r0 = lerp()
    //     0x11689a8: bl              #0xfb012c  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::lerp
    // 0x11689ac: mov             x4, x0
    // 0x11689b0: ldur            x0, [fp, #-0x10]
    // 0x11689b4: stur            x4, [fp, #-0x28]
    // 0x11689b8: LoadField: r1 = r0->field_13
    //     0x11689b8: ldur            w1, [x0, #0x13]
    // 0x11689bc: DecompressPointer r1
    //     0x11689bc: add             x1, x1, HEAP, lsl #32
    // 0x11689c0: ldur            x0, [fp, #-0x18]
    // 0x11689c4: LoadField: r2 = r0->field_13
    //     0x11689c4: ldur            w2, [x0, #0x13]
    // 0x11689c8: DecompressPointer r2
    //     0x11689c8: add             x2, x2, HEAP, lsl #32
    // 0x11689cc: ldur            x3, [fp, #-8]
    // 0x11689d0: r0 = lerp()
    //     0x11689d0: bl              #0xfb012c  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::lerp
    // 0x11689d4: ldur            x3, [fp, #-8]
    // 0x11689d8: r1 = Null
    //     0x11689d8: mov             x1, NULL
    // 0x11689dc: r2 = Null
    //     0x11689dc: mov             x2, NULL
    // 0x11689e0: stur            x0, [fp, #-0x10]
    // 0x11689e4: r0 = lerp()
    //     0x11689e4: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11689e8: ldur            x3, [fp, #-8]
    // 0x11689ec: r1 = Null
    //     0x11689ec: mov             x1, NULL
    // 0x11689f0: r2 = Null
    //     0x11689f0: mov             x2, NULL
    // 0x11689f4: r0 = lerp()
    //     0x11689f4: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11689f8: ldur            x3, [fp, #-8]
    // 0x11689fc: r1 = Null
    //     0x11689fc: mov             x1, NULL
    // 0x1168a00: r2 = Null
    //     0x1168a00: mov             x2, NULL
    // 0x1168a04: r0 = lerp()
    //     0x1168a04: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1168a08: ldur            x3, [fp, #-8]
    // 0x1168a0c: r1 = Null
    //     0x1168a0c: mov             x1, NULL
    // 0x1168a10: r2 = Null
    //     0x1168a10: mov             x2, NULL
    // 0x1168a14: r0 = lerp()
    //     0x1168a14: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1168a18: r0 = BottomNavigationBarThemeData()
    //     0x1168a18: bl              #0x1168a64  ; AllocateBottomNavigationBarThemeDataStub -> BottomNavigationBarThemeData (size=0x40)
    // 0x1168a1c: ldur            x1, [fp, #-0x20]
    // 0x1168a20: StoreField: r0->field_b = r1
    //     0x1168a20: stur            w1, [x0, #0xb]
    // 0x1168a24: ldur            x1, [fp, #-0x28]
    // 0x1168a28: StoreField: r0->field_f = r1
    //     0x1168a28: stur            w1, [x0, #0xf]
    // 0x1168a2c: ldur            x1, [fp, #-0x10]
    // 0x1168a30: StoreField: r0->field_13 = r1
    //     0x1168a30: stur            w1, [x0, #0x13]
    // 0x1168a34: LeaveFrame
    //     0x1168a34: mov             SP, fp
    //     0x1168a38: ldp             fp, lr, [SP], #0x10
    // 0x1168a3c: ret
    //     0x1168a3c: ret             
    // 0x1168a40: r0 = StackOverflowSharedWithFPURegs()
    //     0x1168a40: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1168a44: b               #0x116890c
    // 0x1168a48: SaveReg d0
    //     0x1168a48: str             q0, [SP, #-0x10]!
    // 0x1168a4c: stp             x0, x4, [SP, #-0x10]!
    // 0x1168a50: r0 = AllocateDouble()
    //     0x1168a50: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1168a54: mov             x5, x0
    // 0x1168a58: ldp             x0, x4, [SP], #0x10
    // 0x1168a5c: RestoreReg d0
    //     0x1168a5c: ldr             q0, [SP], #0x10
    // 0x1168a60: b               #0x116894c
  }
  _ ==(/* No info */) {
    // ** addr: 0x1264614, size: 0x174
    // 0x1264614: EnterFrame
    //     0x1264614: stp             fp, lr, [SP, #-0x10]!
    //     0x1264618: mov             fp, SP
    // 0x126461c: AllocStack(0x10)
    //     0x126461c: sub             SP, SP, #0x10
    // 0x1264620: CheckStackOverflow
    //     0x1264620: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1264624: cmp             SP, x16
    //     0x1264628: b.ls            #0x1264780
    // 0x126462c: ldr             x0, [fp, #0x10]
    // 0x1264630: cmp             w0, NULL
    // 0x1264634: b.ne            #0x1264648
    // 0x1264638: r0 = false
    //     0x1264638: add             x0, NULL, #0x30  ; false
    // 0x126463c: LeaveFrame
    //     0x126463c: mov             SP, fp
    //     0x1264640: ldp             fp, lr, [SP], #0x10
    // 0x1264644: ret
    //     0x1264644: ret             
    // 0x1264648: ldr             x1, [fp, #0x18]
    // 0x126464c: cmp             w1, w0
    // 0x1264650: b.ne            #0x1264664
    // 0x1264654: r0 = true
    //     0x1264654: add             x0, NULL, #0x20  ; true
    // 0x1264658: LeaveFrame
    //     0x1264658: mov             SP, fp
    //     0x126465c: ldp             fp, lr, [SP], #0x10
    // 0x1264660: ret
    //     0x1264660: ret             
    // 0x1264664: str             x0, [SP]
    // 0x1264668: r0 = runtimeType()
    //     0x1264668: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x126466c: r1 = LoadClassIdInstr(r0)
    //     0x126466c: ldur            x1, [x0, #-1]
    //     0x1264670: ubfx            x1, x1, #0xc, #0x14
    // 0x1264674: r16 = BottomNavigationBarThemeData
    //     0x1264674: add             x16, PP, #0x26, lsl #12  ; [pp+0x26568] Type: BottomNavigationBarThemeData
    //     0x1264678: ldr             x16, [x16, #0x568]
    // 0x126467c: stp             x16, x0, [SP]
    // 0x1264680: mov             x0, x1
    // 0x1264684: mov             lr, x0
    // 0x1264688: ldr             lr, [x21, lr, lsl #3]
    // 0x126468c: blr             lr
    // 0x1264690: tbz             w0, #4, #0x12646a4
    // 0x1264694: r0 = false
    //     0x1264694: add             x0, NULL, #0x30  ; false
    // 0x1264698: LeaveFrame
    //     0x1264698: mov             SP, fp
    //     0x126469c: ldp             fp, lr, [SP], #0x10
    // 0x12646a0: ret
    //     0x12646a0: ret             
    // 0x12646a4: ldr             x1, [fp, #0x10]
    // 0x12646a8: r0 = 60
    //     0x12646a8: mov             x0, #0x3c
    // 0x12646ac: branchIfSmi(r1, 0x12646b8)
    //     0x12646ac: tbz             w1, #0, #0x12646b8
    // 0x12646b0: r0 = LoadClassIdInstr(r1)
    //     0x12646b0: ldur            x0, [x1, #-1]
    //     0x12646b4: ubfx            x0, x0, #0xc, #0x14
    // 0x12646b8: r17 = 5203
    //     0x12646b8: mov             x17, #0x1453
    // 0x12646bc: cmp             x0, x17
    // 0x12646c0: b.ne            #0x1264770
    // 0x12646c4: ldr             x2, [fp, #0x18]
    // 0x12646c8: LoadField: r0 = r1->field_b
    //     0x12646c8: ldur            w0, [x1, #0xb]
    // 0x12646cc: DecompressPointer r0
    //     0x12646cc: add             x0, x0, HEAP, lsl #32
    // 0x12646d0: LoadField: r3 = r2->field_b
    //     0x12646d0: ldur            w3, [x2, #0xb]
    // 0x12646d4: DecompressPointer r3
    //     0x12646d4: add             x3, x3, HEAP, lsl #32
    // 0x12646d8: r4 = LoadClassIdInstr(r0)
    //     0x12646d8: ldur            x4, [x0, #-1]
    //     0x12646dc: ubfx            x4, x4, #0xc, #0x14
    // 0x12646e0: stp             x3, x0, [SP]
    // 0x12646e4: mov             x0, x4
    // 0x12646e8: mov             lr, x0
    // 0x12646ec: ldr             lr, [x21, lr, lsl #3]
    // 0x12646f0: blr             lr
    // 0x12646f4: tbnz            w0, #4, #0x1264770
    // 0x12646f8: ldr             x2, [fp, #0x18]
    // 0x12646fc: ldr             x1, [fp, #0x10]
    // 0x1264700: LoadField: r0 = r1->field_f
    //     0x1264700: ldur            w0, [x1, #0xf]
    // 0x1264704: DecompressPointer r0
    //     0x1264704: add             x0, x0, HEAP, lsl #32
    // 0x1264708: LoadField: r3 = r2->field_f
    //     0x1264708: ldur            w3, [x2, #0xf]
    // 0x126470c: DecompressPointer r3
    //     0x126470c: add             x3, x3, HEAP, lsl #32
    // 0x1264710: r4 = LoadClassIdInstr(r0)
    //     0x1264710: ldur            x4, [x0, #-1]
    //     0x1264714: ubfx            x4, x4, #0xc, #0x14
    // 0x1264718: stp             x3, x0, [SP]
    // 0x126471c: mov             x0, x4
    // 0x1264720: mov             lr, x0
    // 0x1264724: ldr             lr, [x21, lr, lsl #3]
    // 0x1264728: blr             lr
    // 0x126472c: tbnz            w0, #4, #0x1264770
    // 0x1264730: ldr             x1, [fp, #0x18]
    // 0x1264734: ldr             x0, [fp, #0x10]
    // 0x1264738: LoadField: r2 = r0->field_13
    //     0x1264738: ldur            w2, [x0, #0x13]
    // 0x126473c: DecompressPointer r2
    //     0x126473c: add             x2, x2, HEAP, lsl #32
    // 0x1264740: LoadField: r0 = r1->field_13
    //     0x1264740: ldur            w0, [x1, #0x13]
    // 0x1264744: DecompressPointer r0
    //     0x1264744: add             x0, x0, HEAP, lsl #32
    // 0x1264748: r1 = LoadClassIdInstr(r2)
    //     0x1264748: ldur            x1, [x2, #-1]
    //     0x126474c: ubfx            x1, x1, #0xc, #0x14
    // 0x1264750: stp             x0, x2, [SP]
    // 0x1264754: mov             x0, x1
    // 0x1264758: mov             lr, x0
    // 0x126475c: ldr             lr, [x21, lr, lsl #3]
    // 0x1264760: blr             lr
    // 0x1264764: tbnz            w0, #4, #0x1264770
    // 0x1264768: r0 = true
    //     0x1264768: add             x0, NULL, #0x20  ; true
    // 0x126476c: b               #0x1264774
    // 0x1264770: r0 = false
    //     0x1264770: add             x0, NULL, #0x30  ; false
    // 0x1264774: LeaveFrame
    //     0x1264774: mov             SP, fp
    //     0x1264778: ldp             fp, lr, [SP], #0x10
    // 0x126477c: ret
    //     0x126477c: ret             
    // 0x1264780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1264780: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1264784: b               #0x126462c
  }
}

// class id: 6819, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class BottomNavigationBarTheme extends InheritedWidget {

  static _ of(/* No info */) {
    // ** addr: 0xd0becc, size: 0x58
    // 0xd0becc: EnterFrame
    //     0xd0becc: stp             fp, lr, [SP, #-0x10]!
    //     0xd0bed0: mov             fp, SP
    // 0xd0bed4: AllocStack(0x18)
    //     0xd0bed4: sub             SP, SP, #0x18
    // 0xd0bed8: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xd0bed8: stur            x1, [fp, #-8]
    // 0xd0bedc: CheckStackOverflow
    //     0xd0bedc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0bee0: cmp             SP, x16
    //     0xd0bee4: b.ls            #0xd0bf1c
    // 0xd0bee8: r16 = <BottomNavigationBarTheme>
    //     0xd0bee8: add             x16, PP, #0x90, lsl #12  ; [pp+0x90a10] TypeArguments: <BottomNavigationBarTheme>
    //     0xd0beec: ldr             x16, [x16, #0xa10]
    // 0xd0bef0: stp             x1, x16, [SP]
    // 0xd0bef4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd0bef4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd0bef8: r0 = dependOnInheritedWidgetOfExactType()
    //     0xd0bef8: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xd0befc: ldur            x1, [fp, #-8]
    // 0xd0bf00: r0 = of()
    //     0xd0bf00: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd0bf04: LoadField: r1 = r0->field_a3
    //     0xd0bf04: ldur            w1, [x0, #0xa3]
    // 0xd0bf08: DecompressPointer r1
    //     0xd0bf08: add             x1, x1, HEAP, lsl #32
    // 0xd0bf0c: mov             x0, x1
    // 0xd0bf10: LeaveFrame
    //     0xd0bf10: mov             SP, fp
    //     0xd0bf14: ldp             fp, lr, [SP], #0x10
    // 0xd0bf18: ret
    //     0xd0bf18: ret             
    // 0xd0bf1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0bf1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0bf20: b               #0xd0bee8
  }
}
