// lib: , url: package:flutter/src/material/search_view_theme.dart

// class id: 1048942, size: 0x8
class :: {
}

// class id: 5116, size: 0x3c, field offset: 0x8
//   const constructor, 
class SearchViewThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x1135af0, size: 0x80
    // 0x1135af0: EnterFrame
    //     0x1135af0: stp             fp, lr, [SP, #-0x10]!
    //     0x1135af4: mov             fp, SP
    // 0x1135af8: AllocStack(0x58)
    //     0x1135af8: sub             SP, SP, #0x58
    // 0x1135afc: CheckStackOverflow
    //     0x1135afc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1135b00: cmp             SP, x16
    //     0x1135b04: b.ls            #0x1135b68
    // 0x1135b08: ldr             x0, [fp, #0x10]
    // 0x1135b0c: LoadField: r2 = r0->field_b
    //     0x1135b0c: ldur            w2, [x0, #0xb]
    // 0x1135b10: DecompressPointer r2
    //     0x1135b10: add             x2, x2, HEAP, lsl #32
    // 0x1135b14: LoadField: r1 = r0->field_1b
    //     0x1135b14: ldur            w1, [x0, #0x1b]
    // 0x1135b18: DecompressPointer r1
    //     0x1135b18: add             x1, x1, HEAP, lsl #32
    // 0x1135b1c: stp             NULL, NULL, [SP, #0x48]
    // 0x1135b20: stp             x1, NULL, [SP, #0x38]
    // 0x1135b24: stp             NULL, NULL, [SP, #0x28]
    // 0x1135b28: stp             NULL, NULL, [SP, #0x18]
    // 0x1135b2c: stp             NULL, NULL, [SP, #8]
    // 0x1135b30: str             NULL, [SP]
    // 0x1135b34: r1 = Null
    //     0x1135b34: mov             x1, NULL
    // 0x1135b38: r4 = const [0, 0xd, 0xb, 0xd, null]
    //     0x1135b38: add             x4, PP, #0x26, lsl #12  ; [pp+0x26260] List(5) [0, 0xd, 0xb, 0xd, Null]
    //     0x1135b3c: ldr             x4, [x4, #0x260]
    // 0x1135b40: r0 = hash()
    //     0x1135b40: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1135b44: mov             x2, x0
    // 0x1135b48: r0 = BoxInt64Instr(r2)
    //     0x1135b48: sbfiz           x0, x2, #1, #0x1f
    //     0x1135b4c: cmp             x2, x0, asr #1
    //     0x1135b50: b.eq            #0x1135b5c
    //     0x1135b54: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1135b58: stur            x2, [x0, #7]
    // 0x1135b5c: LeaveFrame
    //     0x1135b5c: mov             SP, fp
    //     0x1135b60: ldp             fp, lr, [SP], #0x10
    // 0x1135b64: ret
    //     0x1135b64: ret             
    // 0x1135b68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1135b68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1135b6c: b               #0x1135b08
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1165de4, size: 0x190
    // 0x1165de4: EnterFrame
    //     0x1165de4: stp             fp, lr, [SP, #-0x10]!
    //     0x1165de8: mov             fp, SP
    // 0x1165dec: AllocStack(0x28)
    //     0x1165dec: sub             SP, SP, #0x28
    // 0x1165df0: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x28 */)
    //     0x1165df0: mov             x4, x1
    //     0x1165df4: mov             x0, x2
    //     0x1165df8: stur            x1, [fp, #-0x10]
    //     0x1165dfc: stur            x2, [fp, #-0x18]
    //     0x1165e00: stur            d0, [fp, #-0x28]
    // 0x1165e04: CheckStackOverflow
    //     0x1165e04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1165e08: cmp             SP, x16
    //     0x1165e0c: b.ls            #0x1165f50
    // 0x1165e10: cmp             w4, w0
    // 0x1165e14: b.ne            #0x1165e28
    // 0x1165e18: mov             x0, x4
    // 0x1165e1c: LeaveFrame
    //     0x1165e1c: mov             SP, fp
    //     0x1165e20: ldp             fp, lr, [SP], #0x10
    // 0x1165e24: ret
    //     0x1165e24: ret             
    // 0x1165e28: r5 = inline_Allocate_Double()
    //     0x1165e28: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x1165e2c: add             x5, x5, #0x10
    //     0x1165e30: cmp             x1, x5
    //     0x1165e34: b.ls            #0x1165f58
    //     0x1165e38: str             x5, [THR, #0x60]  ; THR::top
    //     0x1165e3c: sub             x5, x5, #0xf
    //     0x1165e40: mov             x1, #0xe19c
    //     0x1165e44: movk            x1, #3, lsl #16
    //     0x1165e48: stur            x1, [x5, #-1]
    // 0x1165e4c: dmb             ishst
    // 0x1165e50: StoreField: r5->field_7 = d0
    //     0x1165e50: stur            d0, [x5, #7]
    // 0x1165e54: mov             x3, x5
    // 0x1165e58: stur            x5, [fp, #-8]
    // 0x1165e5c: r1 = Null
    //     0x1165e5c: mov             x1, NULL
    // 0x1165e60: r2 = Null
    //     0x1165e60: mov             x2, NULL
    // 0x1165e64: r0 = lerp()
    //     0x1165e64: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1165e68: ldur            x0, [fp, #-0x10]
    // 0x1165e6c: LoadField: r1 = r0->field_b
    //     0x1165e6c: ldur            w1, [x0, #0xb]
    // 0x1165e70: DecompressPointer r1
    //     0x1165e70: add             x1, x1, HEAP, lsl #32
    // 0x1165e74: ldur            x4, [fp, #-0x18]
    // 0x1165e78: LoadField: r2 = r4->field_b
    //     0x1165e78: ldur            w2, [x4, #0xb]
    // 0x1165e7c: DecompressPointer r2
    //     0x1165e7c: add             x2, x2, HEAP, lsl #32
    // 0x1165e80: ldur            x3, [fp, #-8]
    // 0x1165e84: r0 = lerpDouble()
    //     0x1165e84: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1165e88: ldur            x3, [fp, #-8]
    // 0x1165e8c: r1 = Null
    //     0x1165e8c: mov             x1, NULL
    // 0x1165e90: r2 = Null
    //     0x1165e90: mov             x2, NULL
    // 0x1165e94: stur            x0, [fp, #-0x20]
    // 0x1165e98: r0 = lerp()
    //     0x1165e98: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1165e9c: ldur            x3, [fp, #-8]
    // 0x1165ea0: r1 = Null
    //     0x1165ea0: mov             x1, NULL
    // 0x1165ea4: r2 = Null
    //     0x1165ea4: mov             x2, NULL
    // 0x1165ea8: r0 = lerp()
    //     0x1165ea8: bl              #0x1165150  ; [package:flutter/src/painting/borders.dart] OutlinedBorder::lerp
    // 0x1165eac: ldur            x0, [fp, #-0x10]
    // 0x1165eb0: LoadField: r1 = r0->field_1b
    //     0x1165eb0: ldur            w1, [x0, #0x1b]
    // 0x1165eb4: DecompressPointer r1
    //     0x1165eb4: add             x1, x1, HEAP, lsl #32
    // 0x1165eb8: ldur            x0, [fp, #-0x18]
    // 0x1165ebc: LoadField: r2 = r0->field_1b
    //     0x1165ebc: ldur            w2, [x0, #0x1b]
    // 0x1165ec0: DecompressPointer r2
    //     0x1165ec0: add             x2, x2, HEAP, lsl #32
    // 0x1165ec4: ldur            x3, [fp, #-8]
    // 0x1165ec8: r0 = lerpDouble()
    //     0x1165ec8: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1165ecc: ldur            x3, [fp, #-8]
    // 0x1165ed0: r1 = Null
    //     0x1165ed0: mov             x1, NULL
    // 0x1165ed4: r2 = Null
    //     0x1165ed4: mov             x2, NULL
    // 0x1165ed8: stur            x0, [fp, #-0x10]
    // 0x1165edc: r0 = lerp()
    //     0x1165edc: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1165ee0: ldur            x3, [fp, #-8]
    // 0x1165ee4: r1 = Null
    //     0x1165ee4: mov             x1, NULL
    // 0x1165ee8: r2 = Null
    //     0x1165ee8: mov             x2, NULL
    // 0x1165eec: r0 = lerp()
    //     0x1165eec: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1165ef0: ldur            d0, [fp, #-0x28]
    // 0x1165ef4: r1 = Null
    //     0x1165ef4: mov             x1, NULL
    // 0x1165ef8: r2 = Null
    //     0x1165ef8: mov             x2, NULL
    // 0x1165efc: r0 = lerp()
    //     0x1165efc: bl              #0x1163c14  ; [package:flutter/src/rendering/box.dart] BoxConstraints::lerp
    // 0x1165f00: ldur            x3, [fp, #-8]
    // 0x1165f04: r1 = Null
    //     0x1165f04: mov             x1, NULL
    // 0x1165f08: r2 = Null
    //     0x1165f08: mov             x2, NULL
    // 0x1165f0c: r0 = lerp()
    //     0x1165f0c: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x1165f10: ldur            x3, [fp, #-8]
    // 0x1165f14: r1 = Null
    //     0x1165f14: mov             x1, NULL
    // 0x1165f18: r2 = Null
    //     0x1165f18: mov             x2, NULL
    // 0x1165f1c: r0 = lerp()
    //     0x1165f1c: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x1165f20: ldur            x3, [fp, #-8]
    // 0x1165f24: r1 = Null
    //     0x1165f24: mov             x1, NULL
    // 0x1165f28: r2 = Null
    //     0x1165f28: mov             x2, NULL
    // 0x1165f2c: r0 = lerp()
    //     0x1165f2c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1165f30: r0 = SearchViewThemeData()
    //     0x1165f30: bl              #0x1165f74  ; AllocateSearchViewThemeDataStub -> SearchViewThemeData (size=0x3c)
    // 0x1165f34: ldur            x1, [fp, #-0x20]
    // 0x1165f38: StoreField: r0->field_b = r1
    //     0x1165f38: stur            w1, [x0, #0xb]
    // 0x1165f3c: ldur            x1, [fp, #-0x10]
    // 0x1165f40: StoreField: r0->field_1b = r1
    //     0x1165f40: stur            w1, [x0, #0x1b]
    // 0x1165f44: LeaveFrame
    //     0x1165f44: mov             SP, fp
    //     0x1165f48: ldp             fp, lr, [SP], #0x10
    // 0x1165f4c: ret
    //     0x1165f4c: ret             
    // 0x1165f50: r0 = StackOverflowSharedWithFPURegs()
    //     0x1165f50: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1165f54: b               #0x1165e10
    // 0x1165f58: SaveReg d0
    //     0x1165f58: str             q0, [SP, #-0x10]!
    // 0x1165f5c: stp             x0, x4, [SP, #-0x10]!
    // 0x1165f60: r0 = AllocateDouble()
    //     0x1165f60: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1165f64: mov             x5, x0
    // 0x1165f68: ldp             x0, x4, [SP], #0x10
    // 0x1165f6c: RestoreReg d0
    //     0x1165f6c: ldr             q0, [SP], #0x10
    // 0x1165f70: b               #0x1165e50
  }
  _ ==(/* No info */) {
    // ** addr: 0x1271954, size: 0x13c
    // 0x1271954: EnterFrame
    //     0x1271954: stp             fp, lr, [SP, #-0x10]!
    //     0x1271958: mov             fp, SP
    // 0x127195c: AllocStack(0x10)
    //     0x127195c: sub             SP, SP, #0x10
    // 0x1271960: CheckStackOverflow
    //     0x1271960: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1271964: cmp             SP, x16
    //     0x1271968: b.ls            #0x1271a88
    // 0x127196c: ldr             x0, [fp, #0x10]
    // 0x1271970: cmp             w0, NULL
    // 0x1271974: b.ne            #0x1271988
    // 0x1271978: r0 = false
    //     0x1271978: add             x0, NULL, #0x30  ; false
    // 0x127197c: LeaveFrame
    //     0x127197c: mov             SP, fp
    //     0x1271980: ldp             fp, lr, [SP], #0x10
    // 0x1271984: ret
    //     0x1271984: ret             
    // 0x1271988: ldr             x1, [fp, #0x18]
    // 0x127198c: cmp             w1, w0
    // 0x1271990: b.ne            #0x12719a4
    // 0x1271994: r0 = true
    //     0x1271994: add             x0, NULL, #0x20  ; true
    // 0x1271998: LeaveFrame
    //     0x1271998: mov             SP, fp
    //     0x127199c: ldp             fp, lr, [SP], #0x10
    // 0x12719a0: ret
    //     0x12719a0: ret             
    // 0x12719a4: str             x0, [SP]
    // 0x12719a8: r0 = runtimeType()
    //     0x12719a8: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x12719ac: r1 = LoadClassIdInstr(r0)
    //     0x12719ac: ldur            x1, [x0, #-1]
    //     0x12719b0: ubfx            x1, x1, #0xc, #0x14
    // 0x12719b4: r16 = SearchViewThemeData
    //     0x12719b4: add             x16, PP, #0x26, lsl #12  ; [pp+0x26258] Type: SearchViewThemeData
    //     0x12719b8: ldr             x16, [x16, #0x258]
    // 0x12719bc: stp             x16, x0, [SP]
    // 0x12719c0: mov             x0, x1
    // 0x12719c4: mov             lr, x0
    // 0x12719c8: ldr             lr, [x21, lr, lsl #3]
    // 0x12719cc: blr             lr
    // 0x12719d0: tbz             w0, #4, #0x12719e4
    // 0x12719d4: r0 = false
    //     0x12719d4: add             x0, NULL, #0x30  ; false
    // 0x12719d8: LeaveFrame
    //     0x12719d8: mov             SP, fp
    //     0x12719dc: ldp             fp, lr, [SP], #0x10
    // 0x12719e0: ret
    //     0x12719e0: ret             
    // 0x12719e4: ldr             x1, [fp, #0x10]
    // 0x12719e8: r0 = 60
    //     0x12719e8: mov             x0, #0x3c
    // 0x12719ec: branchIfSmi(r1, 0x12719f8)
    //     0x12719ec: tbz             w1, #0, #0x12719f8
    // 0x12719f0: r0 = LoadClassIdInstr(r1)
    //     0x12719f0: ldur            x0, [x1, #-1]
    //     0x12719f4: ubfx            x0, x0, #0xc, #0x14
    // 0x12719f8: r17 = 5116
    //     0x12719f8: mov             x17, #0x13fc
    // 0x12719fc: cmp             x0, x17
    // 0x1271a00: b.ne            #0x1271a78
    // 0x1271a04: ldr             x2, [fp, #0x18]
    // 0x1271a08: LoadField: r0 = r1->field_b
    //     0x1271a08: ldur            w0, [x1, #0xb]
    // 0x1271a0c: DecompressPointer r0
    //     0x1271a0c: add             x0, x0, HEAP, lsl #32
    // 0x1271a10: LoadField: r3 = r2->field_b
    //     0x1271a10: ldur            w3, [x2, #0xb]
    // 0x1271a14: DecompressPointer r3
    //     0x1271a14: add             x3, x3, HEAP, lsl #32
    // 0x1271a18: r4 = LoadClassIdInstr(r0)
    //     0x1271a18: ldur            x4, [x0, #-1]
    //     0x1271a1c: ubfx            x4, x4, #0xc, #0x14
    // 0x1271a20: stp             x3, x0, [SP]
    // 0x1271a24: mov             x0, x4
    // 0x1271a28: mov             lr, x0
    // 0x1271a2c: ldr             lr, [x21, lr, lsl #3]
    // 0x1271a30: blr             lr
    // 0x1271a34: tbnz            w0, #4, #0x1271a78
    // 0x1271a38: ldr             x1, [fp, #0x18]
    // 0x1271a3c: ldr             x0, [fp, #0x10]
    // 0x1271a40: LoadField: r2 = r0->field_1b
    //     0x1271a40: ldur            w2, [x0, #0x1b]
    // 0x1271a44: DecompressPointer r2
    //     0x1271a44: add             x2, x2, HEAP, lsl #32
    // 0x1271a48: LoadField: r0 = r1->field_1b
    //     0x1271a48: ldur            w0, [x1, #0x1b]
    // 0x1271a4c: DecompressPointer r0
    //     0x1271a4c: add             x0, x0, HEAP, lsl #32
    // 0x1271a50: r1 = LoadClassIdInstr(r2)
    //     0x1271a50: ldur            x1, [x2, #-1]
    //     0x1271a54: ubfx            x1, x1, #0xc, #0x14
    // 0x1271a58: stp             x0, x2, [SP]
    // 0x1271a5c: mov             x0, x1
    // 0x1271a60: mov             lr, x0
    // 0x1271a64: ldr             lr, [x21, lr, lsl #3]
    // 0x1271a68: blr             lr
    // 0x1271a6c: tbnz            w0, #4, #0x1271a78
    // 0x1271a70: r0 = true
    //     0x1271a70: add             x0, NULL, #0x20  ; true
    // 0x1271a74: b               #0x1271a7c
    // 0x1271a78: r0 = false
    //     0x1271a78: add             x0, NULL, #0x30  ; false
    // 0x1271a7c: LeaveFrame
    //     0x1271a7c: mov             SP, fp
    //     0x1271a80: ldp             fp, lr, [SP], #0x10
    // 0x1271a84: ret
    //     0x1271a84: ret             
    // 0x1271a88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1271a88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1271a8c: b               #0x127196c
  }
}
