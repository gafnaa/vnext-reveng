// lib: , url: package:flutter/src/material/banner_theme.dart

// class id: 1048848, size: 0x8
class :: {
}

// class id: 5207, size: 0x28, field offset: 0x8
//   const constructor, 
class MaterialBannerThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x112eca4, size: 0x70
    // 0x112eca4: EnterFrame
    //     0x112eca4: stp             fp, lr, [SP, #-0x10]!
    //     0x112eca8: mov             fp, SP
    // 0x112ecac: AllocStack(0x30)
    //     0x112ecac: sub             SP, SP, #0x30
    // 0x112ecb0: CheckStackOverflow
    //     0x112ecb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112ecb4: cmp             SP, x16
    //     0x112ecb8: b.ls            #0x112ed0c
    // 0x112ecbc: ldr             x0, [fp, #0x10]
    // 0x112ecc0: LoadField: r1 = r0->field_1b
    //     0x112ecc0: ldur            w1, [x0, #0x1b]
    // 0x112ecc4: DecompressPointer r1
    //     0x112ecc4: add             x1, x1, HEAP, lsl #32
    // 0x112ecc8: stp             NULL, NULL, [SP, #0x20]
    // 0x112eccc: stp             x1, NULL, [SP, #0x10]
    // 0x112ecd0: stp             NULL, NULL, [SP]
    // 0x112ecd4: r1 = Null
    //     0x112ecd4: mov             x1, NULL
    // 0x112ecd8: r2 = Null
    //     0x112ecd8: mov             x2, NULL
    // 0x112ecdc: r4 = const [0, 0x8, 0x6, 0x8, null]
    //     0x112ecdc: add             x4, PP, #0xe, lsl #12  ; [pp+0xe090] List(5) [0, 0x8, 0x6, 0x8, Null]
    //     0x112ece0: ldr             x4, [x4, #0x90]
    // 0x112ece4: r0 = hash()
    //     0x112ece4: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x112ece8: mov             x2, x0
    // 0x112ecec: r0 = BoxInt64Instr(r2)
    //     0x112ecec: sbfiz           x0, x2, #1, #0x1f
    //     0x112ecf0: cmp             x2, x0, asr #1
    //     0x112ecf4: b.eq            #0x112ed00
    //     0x112ecf8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x112ecfc: stur            x2, [x0, #7]
    // 0x112ed00: LeaveFrame
    //     0x112ed00: mov             SP, fp
    //     0x112ed04: ldp             fp, lr, [SP], #0x10
    // 0x112ed08: ret
    //     0x112ed08: ret             
    // 0x112ed0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112ed0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112ed10: b               #0x112ecbc
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1168c04, size: 0x128
    // 0x1168c04: EnterFrame
    //     0x1168c04: stp             fp, lr, [SP, #-0x10]!
    //     0x1168c08: mov             fp, SP
    // 0x1168c0c: AllocStack(0x18)
    //     0x1168c0c: sub             SP, SP, #0x18
    // 0x1168c10: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0x1168c10: mov             x4, x1
    //     0x1168c14: mov             x0, x2
    //     0x1168c18: stur            x1, [fp, #-0x10]
    //     0x1168c1c: stur            x2, [fp, #-0x18]
    // 0x1168c20: CheckStackOverflow
    //     0x1168c20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1168c24: cmp             SP, x16
    //     0x1168c28: b.ls            #0x1168d08
    // 0x1168c2c: r5 = inline_Allocate_Double()
    //     0x1168c2c: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x1168c30: add             x5, x5, #0x10
    //     0x1168c34: cmp             x1, x5
    //     0x1168c38: b.ls            #0x1168d10
    //     0x1168c3c: str             x5, [THR, #0x60]  ; THR::top
    //     0x1168c40: sub             x5, x5, #0xf
    //     0x1168c44: mov             x1, #0xe19c
    //     0x1168c48: movk            x1, #3, lsl #16
    //     0x1168c4c: stur            x1, [x5, #-1]
    // 0x1168c50: dmb             ishst
    // 0x1168c54: StoreField: r5->field_7 = d0
    //     0x1168c54: stur            d0, [x5, #7]
    // 0x1168c58: mov             x3, x5
    // 0x1168c5c: stur            x5, [fp, #-8]
    // 0x1168c60: r1 = Null
    //     0x1168c60: mov             x1, NULL
    // 0x1168c64: r2 = Null
    //     0x1168c64: mov             x2, NULL
    // 0x1168c68: r0 = lerp()
    //     0x1168c68: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168c6c: ldur            x3, [fp, #-8]
    // 0x1168c70: r1 = Null
    //     0x1168c70: mov             x1, NULL
    // 0x1168c74: r2 = Null
    //     0x1168c74: mov             x2, NULL
    // 0x1168c78: r0 = lerp()
    //     0x1168c78: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168c7c: ldur            x3, [fp, #-8]
    // 0x1168c80: r1 = Null
    //     0x1168c80: mov             x1, NULL
    // 0x1168c84: r2 = Null
    //     0x1168c84: mov             x2, NULL
    // 0x1168c88: r0 = lerp()
    //     0x1168c88: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168c8c: ldur            x3, [fp, #-8]
    // 0x1168c90: r1 = Null
    //     0x1168c90: mov             x1, NULL
    // 0x1168c94: r2 = Null
    //     0x1168c94: mov             x2, NULL
    // 0x1168c98: r0 = lerp()
    //     0x1168c98: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168c9c: ldur            x3, [fp, #-8]
    // 0x1168ca0: r1 = Null
    //     0x1168ca0: mov             x1, NULL
    // 0x1168ca4: r2 = Null
    //     0x1168ca4: mov             x2, NULL
    // 0x1168ca8: r0 = lerp()
    //     0x1168ca8: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1168cac: ldur            x0, [fp, #-0x10]
    // 0x1168cb0: LoadField: r1 = r0->field_1b
    //     0x1168cb0: ldur            w1, [x0, #0x1b]
    // 0x1168cb4: DecompressPointer r1
    //     0x1168cb4: add             x1, x1, HEAP, lsl #32
    // 0x1168cb8: ldur            x0, [fp, #-0x18]
    // 0x1168cbc: LoadField: r2 = r0->field_1b
    //     0x1168cbc: ldur            w2, [x0, #0x1b]
    // 0x1168cc0: DecompressPointer r2
    //     0x1168cc0: add             x2, x2, HEAP, lsl #32
    // 0x1168cc4: ldur            x3, [fp, #-8]
    // 0x1168cc8: r0 = lerpDouble()
    //     0x1168cc8: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1168ccc: ldur            x3, [fp, #-8]
    // 0x1168cd0: r1 = Null
    //     0x1168cd0: mov             x1, NULL
    // 0x1168cd4: r2 = Null
    //     0x1168cd4: mov             x2, NULL
    // 0x1168cd8: stur            x0, [fp, #-0x10]
    // 0x1168cdc: r0 = lerp()
    //     0x1168cdc: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x1168ce0: ldur            x3, [fp, #-8]
    // 0x1168ce4: r1 = Null
    //     0x1168ce4: mov             x1, NULL
    // 0x1168ce8: r2 = Null
    //     0x1168ce8: mov             x2, NULL
    // 0x1168cec: r0 = lerp()
    //     0x1168cec: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x1168cf0: r0 = MaterialBannerThemeData()
    //     0x1168cf0: bl              #0x1168d2c  ; AllocateMaterialBannerThemeDataStub -> MaterialBannerThemeData (size=0x28)
    // 0x1168cf4: ldur            x1, [fp, #-0x10]
    // 0x1168cf8: StoreField: r0->field_1b = r1
    //     0x1168cf8: stur            w1, [x0, #0x1b]
    // 0x1168cfc: LeaveFrame
    //     0x1168cfc: mov             SP, fp
    //     0x1168d00: ldp             fp, lr, [SP], #0x10
    // 0x1168d04: ret
    //     0x1168d04: ret             
    // 0x1168d08: r0 = StackOverflowSharedWithFPURegs()
    //     0x1168d08: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1168d0c: b               #0x1168c2c
    // 0x1168d10: SaveReg d0
    //     0x1168d10: str             q0, [SP, #-0x10]!
    // 0x1168d14: stp             x0, x4, [SP, #-0x10]!
    // 0x1168d18: r0 = AllocateDouble()
    //     0x1168d18: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1168d1c: mov             x5, x0
    // 0x1168d20: ldp             x0, x4, [SP], #0x10
    // 0x1168d24: RestoreReg d0
    //     0x1168d24: ldr             q0, [SP], #0x10
    // 0x1168d28: b               #0x1168c54
  }
  _ ==(/* No info */) {
    // ** addr: 0x1264070, size: 0x104
    // 0x1264070: EnterFrame
    //     0x1264070: stp             fp, lr, [SP, #-0x10]!
    //     0x1264074: mov             fp, SP
    // 0x1264078: AllocStack(0x10)
    //     0x1264078: sub             SP, SP, #0x10
    // 0x126407c: CheckStackOverflow
    //     0x126407c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1264080: cmp             SP, x16
    //     0x1264084: b.ls            #0x126416c
    // 0x1264088: ldr             x0, [fp, #0x10]
    // 0x126408c: cmp             w0, NULL
    // 0x1264090: b.ne            #0x12640a4
    // 0x1264094: r0 = false
    //     0x1264094: add             x0, NULL, #0x30  ; false
    // 0x1264098: LeaveFrame
    //     0x1264098: mov             SP, fp
    //     0x126409c: ldp             fp, lr, [SP], #0x10
    // 0x12640a0: ret
    //     0x12640a0: ret             
    // 0x12640a4: ldr             x1, [fp, #0x18]
    // 0x12640a8: cmp             w1, w0
    // 0x12640ac: b.ne            #0x12640c0
    // 0x12640b0: r0 = true
    //     0x12640b0: add             x0, NULL, #0x20  ; true
    // 0x12640b4: LeaveFrame
    //     0x12640b4: mov             SP, fp
    //     0x12640b8: ldp             fp, lr, [SP], #0x10
    // 0x12640bc: ret
    //     0x12640bc: ret             
    // 0x12640c0: str             x0, [SP]
    // 0x12640c4: r0 = runtimeType()
    //     0x12640c4: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x12640c8: r1 = LoadClassIdInstr(r0)
    //     0x12640c8: ldur            x1, [x0, #-1]
    //     0x12640cc: ubfx            x1, x1, #0xc, #0x14
    // 0x12640d0: r16 = MaterialBannerThemeData
    //     0x12640d0: add             x16, PP, #0x26, lsl #12  ; [pp+0x26578] Type: MaterialBannerThemeData
    //     0x12640d4: ldr             x16, [x16, #0x578]
    // 0x12640d8: stp             x16, x0, [SP]
    // 0x12640dc: mov             x0, x1
    // 0x12640e0: mov             lr, x0
    // 0x12640e4: ldr             lr, [x21, lr, lsl #3]
    // 0x12640e8: blr             lr
    // 0x12640ec: tbz             w0, #4, #0x1264100
    // 0x12640f0: r0 = false
    //     0x12640f0: add             x0, NULL, #0x30  ; false
    // 0x12640f4: LeaveFrame
    //     0x12640f4: mov             SP, fp
    //     0x12640f8: ldp             fp, lr, [SP], #0x10
    // 0x12640fc: ret
    //     0x12640fc: ret             
    // 0x1264100: ldr             x0, [fp, #0x10]
    // 0x1264104: r1 = 60
    //     0x1264104: mov             x1, #0x3c
    // 0x1264108: branchIfSmi(r0, 0x1264114)
    //     0x1264108: tbz             w0, #0, #0x1264114
    // 0x126410c: r1 = LoadClassIdInstr(r0)
    //     0x126410c: ldur            x1, [x0, #-1]
    //     0x1264110: ubfx            x1, x1, #0xc, #0x14
    // 0x1264114: r17 = 5207
    //     0x1264114: mov             x17, #0x1457
    // 0x1264118: cmp             x1, x17
    // 0x126411c: b.ne            #0x126415c
    // 0x1264120: ldr             x1, [fp, #0x18]
    // 0x1264124: LoadField: r2 = r0->field_1b
    //     0x1264124: ldur            w2, [x0, #0x1b]
    // 0x1264128: DecompressPointer r2
    //     0x1264128: add             x2, x2, HEAP, lsl #32
    // 0x126412c: LoadField: r0 = r1->field_1b
    //     0x126412c: ldur            w0, [x1, #0x1b]
    // 0x1264130: DecompressPointer r0
    //     0x1264130: add             x0, x0, HEAP, lsl #32
    // 0x1264134: r1 = LoadClassIdInstr(r2)
    //     0x1264134: ldur            x1, [x2, #-1]
    //     0x1264138: ubfx            x1, x1, #0xc, #0x14
    // 0x126413c: stp             x0, x2, [SP]
    // 0x1264140: mov             x0, x1
    // 0x1264144: mov             lr, x0
    // 0x1264148: ldr             lr, [x21, lr, lsl #3]
    // 0x126414c: blr             lr
    // 0x1264150: tbnz            w0, #4, #0x126415c
    // 0x1264154: r0 = true
    //     0x1264154: add             x0, NULL, #0x20  ; true
    // 0x1264158: b               #0x1264160
    // 0x126415c: r0 = false
    //     0x126415c: add             x0, NULL, #0x30  ; false
    // 0x1264160: LeaveFrame
    //     0x1264160: mov             SP, fp
    //     0x1264164: ldp             fp, lr, [SP], #0x10
    // 0x1264168: ret
    //     0x1264168: ret             
    // 0x126416c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x126416c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1264170: b               #0x1264088
  }
}

// class id: 6852, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class MaterialBannerTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xd3649c, size: 0x58
    // 0xd3649c: EnterFrame
    //     0xd3649c: stp             fp, lr, [SP, #-0x10]!
    //     0xd364a0: mov             fp, SP
    // 0xd364a4: AllocStack(0x18)
    //     0xd364a4: sub             SP, SP, #0x18
    // 0xd364a8: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xd364a8: stur            x1, [fp, #-8]
    // 0xd364ac: CheckStackOverflow
    //     0xd364ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd364b0: cmp             SP, x16
    //     0xd364b4: b.ls            #0xd364ec
    // 0xd364b8: r16 = <MaterialBannerTheme>
    //     0xd364b8: add             x16, PP, #0x84, lsl #12  ; [pp+0x84bc8] TypeArguments: <MaterialBannerTheme>
    //     0xd364bc: ldr             x16, [x16, #0xbc8]
    // 0xd364c0: stp             x1, x16, [SP]
    // 0xd364c4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd364c4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd364c8: r0 = dependOnInheritedWidgetOfExactType()
    //     0xd364c8: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xd364cc: ldur            x1, [fp, #-8]
    // 0xd364d0: r0 = of()
    //     0xd364d0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd364d4: LoadField: r1 = r0->field_9b
    //     0xd364d4: ldur            w1, [x0, #0x9b]
    // 0xd364d8: DecompressPointer r1
    //     0xd364d8: add             x1, x1, HEAP, lsl #32
    // 0xd364dc: mov             x0, x1
    // 0xd364e0: LeaveFrame
    //     0xd364e0: mov             SP, fp
    //     0xd364e4: ldp             fp, lr, [SP], #0x10
    // 0xd364e8: ret
    //     0xd364e8: ret             
    // 0xd364ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd364ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd364f0: b               #0xd364b8
  }
}
