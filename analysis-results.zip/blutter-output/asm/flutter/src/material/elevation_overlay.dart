// lib: , url: package:flutter/src/material/elevation_overlay.dart

// class id: 1048890, size: 0x8
class :: {
}

// class id: 3104, size: 0x18, field offset: 0x8
//   const constructor, 
class _ElevationOpacity extends Object {

  _Mint field_8;
  _Mint field_10;
}

// class id: 3105, size: 0x8, field offset: 0x8
abstract class ElevationOverlay extends Object {

  static _ applyOverlay(/* No info */) {
    // ** addr: 0xd2e708, size: 0x114
    // 0xd2e708: EnterFrame
    //     0xd2e708: stp             fp, lr, [SP, #-0x10]!
    //     0xd2e70c: mov             fp, SP
    // 0xd2e710: AllocStack(0x30)
    //     0xd2e710: sub             SP, SP, #0x30
    // 0xd2e714: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x20 */)
    //     0xd2e714: mov             x0, x2
    //     0xd2e718: stur            x2, [fp, #-8]
    //     0xd2e71c: stur            d0, [fp, #-0x20]
    // 0xd2e720: CheckStackOverflow
    //     0xd2e720: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd2e724: cmp             SP, x16
    //     0xd2e728: b.ls            #0xd2e814
    // 0xd2e72c: r0 = of()
    //     0xd2e72c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd2e730: ldur            d1, [fp, #-0x20]
    // 0xd2e734: d0 = 0.000000
    //     0xd2e734: eor             v0.16b, v0.16b, v0.16b
    // 0xd2e738: fcmp            d1, d0
    // 0xd2e73c: b.le            #0xd2e804
    // 0xd2e740: LoadField: r1 = r0->field_7
    //     0xd2e740: ldur            w1, [x0, #7]
    // 0xd2e744: DecompressPointer r1
    //     0xd2e744: add             x1, x1, HEAP, lsl #32
    // 0xd2e748: tbnz            w1, #4, #0xd2e804
    // 0xd2e74c: LoadField: r2 = r0->field_3f
    //     0xd2e74c: ldur            w2, [x0, #0x3f]
    // 0xd2e750: DecompressPointer r2
    //     0xd2e750: add             x2, x2, HEAP, lsl #32
    // 0xd2e754: stur            x2, [fp, #-0x10]
    // 0xd2e758: LoadField: r0 = r2->field_7
    //     0xd2e758: ldur            w0, [x2, #7]
    // 0xd2e75c: DecompressPointer r0
    //     0xd2e75c: add             x0, x0, HEAP, lsl #32
    // 0xd2e760: r16 = Instance_Brightness
    //     0xd2e760: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xd2e764: cmp             w0, w16
    // 0xd2e768: b.ne            #0xd2e804
    // 0xd2e76c: ldur            x3, [fp, #-8]
    // 0xd2e770: r0 = LoadClassIdInstr(r3)
    //     0xd2e770: ldur            x0, [x3, #-1]
    //     0xd2e774: ubfx            x0, x0, #0xc, #0x14
    // 0xd2e778: mov             x1, x3
    // 0xd2e77c: d0 = 1.000000
    //     0xd2e77c: fmov            d0, #1.00000000
    // 0xd2e780: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd2e780: sub             lr, x0, #1, lsl #12
    //     0xd2e784: ldr             lr, [x21, lr, lsl #3]
    //     0xd2e788: blr             lr
    // 0xd2e78c: mov             x3, x0
    // 0xd2e790: ldur            x2, [fp, #-0x10]
    // 0xd2e794: stur            x3, [fp, #-0x18]
    // 0xd2e798: LoadField: r1 = r2->field_7b
    //     0xd2e798: ldur            w1, [x2, #0x7b]
    // 0xd2e79c: DecompressPointer r1
    //     0xd2e79c: add             x1, x1, HEAP, lsl #32
    // 0xd2e7a0: r0 = LoadClassIdInstr(r1)
    //     0xd2e7a0: ldur            x0, [x1, #-1]
    //     0xd2e7a4: ubfx            x0, x0, #0xc, #0x14
    // 0xd2e7a8: d0 = 1.000000
    //     0xd2e7a8: fmov            d0, #1.00000000
    // 0xd2e7ac: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd2e7ac: sub             lr, x0, #1, lsl #12
    //     0xd2e7b0: ldr             lr, [x21, lr, lsl #3]
    //     0xd2e7b4: blr             lr
    // 0xd2e7b8: mov             x1, x0
    // 0xd2e7bc: ldur            x0, [fp, #-0x18]
    // 0xd2e7c0: r2 = LoadClassIdInstr(r0)
    //     0xd2e7c0: ldur            x2, [x0, #-1]
    //     0xd2e7c4: ubfx            x2, x2, #0xc, #0x14
    // 0xd2e7c8: stp             x1, x0, [SP]
    // 0xd2e7cc: mov             x0, x2
    // 0xd2e7d0: mov             lr, x0
    // 0xd2e7d4: ldr             lr, [x21, lr, lsl #3]
    // 0xd2e7d8: blr             lr
    // 0xd2e7dc: tbnz            w0, #4, #0xd2e804
    // 0xd2e7e0: ldur            x0, [fp, #-0x10]
    // 0xd2e7e4: LoadField: r2 = r0->field_7f
    //     0xd2e7e4: ldur            w2, [x0, #0x7f]
    // 0xd2e7e8: DecompressPointer r2
    //     0xd2e7e8: add             x2, x2, HEAP, lsl #32
    // 0xd2e7ec: ldur            x1, [fp, #-8]
    // 0xd2e7f0: ldur            d0, [fp, #-0x20]
    // 0xd2e7f4: r0 = colorWithOverlay()
    //     0xd2e7f4: bl              #0xd2e81c  ; [package:flutter/src/material/elevation_overlay.dart] ElevationOverlay::colorWithOverlay
    // 0xd2e7f8: LeaveFrame
    //     0xd2e7f8: mov             SP, fp
    //     0xd2e7fc: ldp             fp, lr, [SP], #0x10
    // 0xd2e800: ret
    //     0xd2e800: ret             
    // 0xd2e804: ldur            x0, [fp, #-8]
    // 0xd2e808: LeaveFrame
    //     0xd2e808: mov             SP, fp
    //     0xd2e80c: ldp             fp, lr, [SP], #0x10
    // 0xd2e810: ret
    //     0xd2e810: ret             
    // 0xd2e814: r0 = StackOverflowSharedWithFPURegs()
    //     0xd2e814: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd2e818: b               #0xd2e72c
  }
  static _ colorWithOverlay(/* No info */) {
    // ** addr: 0xd2e81c, size: 0x4c
    // 0xd2e81c: EnterFrame
    //     0xd2e81c: stp             fp, lr, [SP, #-0x10]!
    //     0xd2e820: mov             fp, SP
    // 0xd2e824: AllocStack(0x8)
    //     0xd2e824: sub             SP, SP, #8
    // 0xd2e828: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xd2e828: stur            x1, [fp, #-8]
    //     0xd2e82c: mov             x16, x2
    //     0xd2e830: mov             x2, x1
    //     0xd2e834: mov             x1, x16
    // 0xd2e838: CheckStackOverflow
    //     0xd2e838: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd2e83c: cmp             SP, x16
    //     0xd2e840: b.ls            #0xd2e860
    // 0xd2e844: r0 = _overlayColor()
    //     0xd2e844: bl              #0xd2e868  ; [package:flutter/src/material/elevation_overlay.dart] ElevationOverlay::_overlayColor
    // 0xd2e848: mov             x1, x0
    // 0xd2e84c: ldur            x2, [fp, #-8]
    // 0xd2e850: r0 = alphaBlend()
    //     0xd2e850: bl              #0xb6ea90  ; [dart:ui] Color::alphaBlend
    // 0xd2e854: LeaveFrame
    //     0xd2e854: mov             SP, fp
    //     0xd2e858: ldp             fp, lr, [SP], #0x10
    // 0xd2e85c: ret
    //     0xd2e85c: ret             
    // 0xd2e860: r0 = StackOverflowSharedWithFPURegs()
    //     0xd2e860: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd2e864: b               #0xd2e844
  }
  static _ _overlayColor(/* No info */) {
    // ** addr: 0xd2e868, size: 0xa8
    // 0xd2e868: EnterFrame
    //     0xd2e868: stp             fp, lr, [SP, #-0x10]!
    //     0xd2e86c: mov             fp, SP
    // 0xd2e870: d1 = 1.000000
    //     0xd2e870: fmov            d1, #1.00000000
    // 0xd2e874: mov             x19, x1
    // 0xd2e878: CheckStackOverflow
    //     0xd2e878: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd2e87c: cmp             SP, x16
    //     0xd2e880: b.ls            #0xd2e908
    // 0xd2e884: fadd            d2, d0, d1
    // 0xd2e888: mov             v0.16b, v2.16b
    // 0xd2e88c: stp             fp, lr, [SP, #-0x10]!
    // 0xd2e890: mov             fp, SP
    // 0xd2e894: CallRuntime_LibcLog(double) -> double
    //     0xd2e894: and             SP, SP, #0xfffffffffffffff0
    //     0xd2e898: mov             sp, SP
    //     0xd2e89c: ldr             x16, [THR, #0x7b8]  ; THR::LibcLog
    //     0xd2e8a0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd2e8a4: blr             x16
    //     0xd2e8a8: mov             x16, #8
    //     0xd2e8ac: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd2e8b0: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xd2e8b4: sub             sp, x16, #1, lsl #12
    //     0xd2e8b8: mov             SP, fp
    //     0xd2e8bc: ldp             fp, lr, [SP], #0x10
    // 0xd2e8c0: mov             v1.16b, v0.16b
    // 0xd2e8c4: d0 = 4.500000
    //     0xd2e8c4: fmov            d0, #4.50000000
    // 0xd2e8c8: fmul            d2, d1, d0
    // 0xd2e8cc: d0 = 2.000000
    //     0xd2e8cc: fmov            d0, #2.00000000
    // 0xd2e8d0: fadd            d1, d2, d0
    // 0xd2e8d4: d0 = 100.000000
    //     0xd2e8d4: add             x17, PP, #0x13, lsl #12  ; [pp+0x130a8] IMM: double(100) from 0x4059000000000000
    //     0xd2e8d8: ldr             d0, [x17, #0xa8]
    // 0xd2e8dc: fdiv            d2, d1, d0
    // 0xd2e8e0: r0 = LoadClassIdInstr(r19)
    //     0xd2e8e0: ldur            x0, [x19, #-1]
    //     0xd2e8e4: ubfx            x0, x0, #0xc, #0x14
    // 0xd2e8e8: mov             x1, x19
    // 0xd2e8ec: mov             v0.16b, v2.16b
    // 0xd2e8f0: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd2e8f0: sub             lr, x0, #1, lsl #12
    //     0xd2e8f4: ldr             lr, [x21, lr, lsl #3]
    //     0xd2e8f8: blr             lr
    // 0xd2e8fc: LeaveFrame
    //     0xd2e8fc: mov             SP, fp
    //     0xd2e900: ldp             fp, lr, [SP], #0x10
    // 0xd2e904: ret
    //     0xd2e904: ret             
    // 0xd2e908: r0 = StackOverflowSharedWithFPURegs()
    //     0xd2e908: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd2e90c: b               #0xd2e884
  }
  static _ applySurfaceTint(/* No info */) {
    // ** addr: 0xd2e910, size: 0x180
    // 0xd2e910: EnterFrame
    //     0xd2e910: stp             fp, lr, [SP, #-0x10]!
    //     0xd2e914: mov             fp, SP
    // 0xd2e918: AllocStack(0x28)
    //     0xd2e918: sub             SP, SP, #0x28
    // 0xd2e91c: SetupParameters(dynamic _ /* r1 => r2, fp-0x18 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd2e91c: stur            x1, [fp, #-8]
    //     0xd2e920: mov             x16, x2
    //     0xd2e924: mov             x2, x1
    //     0xd2e928: mov             x1, x16
    //     0xd2e92c: stur            x1, [fp, #-0x10]
    //     0xd2e930: stur            d0, [fp, #-0x18]
    // 0xd2e934: CheckStackOverflow
    //     0xd2e934: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd2e938: cmp             SP, x16
    //     0xd2e93c: b.ls            #0xd2ea78
    // 0xd2e940: cmp             w1, NULL
    // 0xd2e944: b.eq            #0xd2ea68
    // 0xd2e948: r0 = LoadClassIdInstr(r1)
    //     0xd2e948: ldur            x0, [x1, #-1]
    //     0xd2e94c: ubfx            x0, x0, #0xc, #0x14
    // 0xd2e950: r16 = Instance_Color
    //     0xd2e950: add             x16, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xd2e954: ldr             x16, [x16, #0x810]
    // 0xd2e958: stp             x16, x1, [SP]
    // 0xd2e95c: mov             lr, x0
    // 0xd2e960: ldr             lr, [x21, lr, lsl #3]
    // 0xd2e964: blr             lr
    // 0xd2e968: tbz             w0, #4, #0xd2ea68
    // 0xd2e96c: ldur            d0, [fp, #-0x18]
    // 0xd2e970: r0 = Instance__ElevationOpacity
    //     0xd2e970: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8fce0] Obj!_ElevationOpacity@129edb1
    //     0xd2e974: ldr             x0, [x0, #0xce0]
    // 0xd2e978: LoadField: d1 = r0->field_7
    //     0xd2e978: ldur            d1, [x0, #7]
    // 0xd2e97c: fcmp            d1, d0
    // 0xd2e980: b.le            #0xd2e98c
    // 0xd2e984: LoadField: d0 = r0->field_f
    //     0xd2e984: ldur            d0, [x0, #0xf]
    // 0xd2e988: b               #0xd2ea38
    // 0xd2e98c: r3 = 0
    //     0xd2e98c: mov             x3, #0
    // 0xd2e990: r2 = const [Instance of '_ElevationOpacity', Instance of '_ElevationOpacity', Instance of '_ElevationOpacity', Instance of '_ElevationOpacity', Instance of '_ElevationOpacity', Instance of '_ElevationOpacity']
    //     0xd2e990: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fce8] List<_ElevationOpacity>(6)
    //     0xd2e994: ldr             x2, [x2, #0xce8]
    // 0xd2e998: CheckStackOverflow
    //     0xd2e998: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd2e99c: cmp             SP, x16
    //     0xd2e9a0: b.ls            #0xd2ea80
    // 0xd2e9a4: mov             x1, x3
    // 0xd2e9a8: r0 = 6
    //     0xd2e9a8: mov             x0, #6
    // 0xd2e9ac: cmp             x1, x0
    // 0xd2e9b0: b.hs            #0xd2ea88
    // 0xd2e9b4: ArrayLoad: r4 = r2[r3]  ; Unknown_4
    //     0xd2e9b4: add             x16, x2, x3, lsl #2
    //     0xd2e9b8: ldur            w4, [x16, #0xf]
    // 0xd2e9bc: DecompressPointer r4
    //     0xd2e9bc: add             x4, x4, HEAP, lsl #32
    // 0xd2e9c0: LoadField: d1 = r4->field_7
    //     0xd2e9c0: ldur            d1, [x4, #7]
    // 0xd2e9c4: fcmp            d0, d1
    // 0xd2e9c8: b.lt            #0xd2e9f0
    // 0xd2e9cc: fcmp            d0, d1
    // 0xd2e9d0: b.eq            #0xd2e9e8
    // 0xd2e9d4: add             x0, x3, #1
    // 0xd2e9d8: cmp             x0, #6
    // 0xd2e9dc: b.eq            #0xd2e9e8
    // 0xd2e9e0: mov             x3, x0
    // 0xd2e9e4: b               #0xd2e998
    // 0xd2e9e8: LoadField: d0 = r4->field_f
    //     0xd2e9e8: ldur            d0, [x4, #0xf]
    // 0xd2e9ec: b               #0xd2ea38
    // 0xd2e9f0: sub             x5, x3, #1
    // 0xd2e9f4: mov             x1, x5
    // 0xd2e9f8: r0 = 6
    //     0xd2e9f8: mov             x0, #6
    // 0xd2e9fc: cmp             x1, x0
    // 0xd2ea00: b.hs            #0xd2ea8c
    // 0xd2ea04: ArrayLoad: r0 = r2[r5]  ; Unknown_4
    //     0xd2ea04: add             x16, x2, x5, lsl #2
    //     0xd2ea08: ldur            w0, [x16, #0xf]
    // 0xd2ea0c: DecompressPointer r0
    //     0xd2ea0c: add             x0, x0, HEAP, lsl #32
    // 0xd2ea10: LoadField: d2 = r0->field_7
    //     0xd2ea10: ldur            d2, [x0, #7]
    // 0xd2ea14: fsub            d3, d0, d2
    // 0xd2ea18: fsub            d0, d1, d2
    // 0xd2ea1c: fdiv            d1, d3, d0
    // 0xd2ea20: LoadField: d0 = r0->field_f
    //     0xd2ea20: ldur            d0, [x0, #0xf]
    // 0xd2ea24: LoadField: d2 = r4->field_f
    //     0xd2ea24: ldur            d2, [x4, #0xf]
    // 0xd2ea28: fsub            d3, d2, d0
    // 0xd2ea2c: fmul            d2, d1, d3
    // 0xd2ea30: fadd            d1, d0, d2
    // 0xd2ea34: mov             v0.16b, v1.16b
    // 0xd2ea38: ldur            x1, [fp, #-0x10]
    // 0xd2ea3c: r0 = LoadClassIdInstr(r1)
    //     0xd2ea3c: ldur            x0, [x1, #-1]
    //     0xd2ea40: ubfx            x0, x0, #0xc, #0x14
    // 0xd2ea44: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd2ea44: sub             lr, x0, #1, lsl #12
    //     0xd2ea48: ldr             lr, [x21, lr, lsl #3]
    //     0xd2ea4c: blr             lr
    // 0xd2ea50: mov             x1, x0
    // 0xd2ea54: ldur            x2, [fp, #-8]
    // 0xd2ea58: r0 = alphaBlend()
    //     0xd2ea58: bl              #0xb6ea90  ; [dart:ui] Color::alphaBlend
    // 0xd2ea5c: LeaveFrame
    //     0xd2ea5c: mov             SP, fp
    //     0xd2ea60: ldp             fp, lr, [SP], #0x10
    // 0xd2ea64: ret
    //     0xd2ea64: ret             
    // 0xd2ea68: ldur            x0, [fp, #-8]
    // 0xd2ea6c: LeaveFrame
    //     0xd2ea6c: mov             SP, fp
    //     0xd2ea70: ldp             fp, lr, [SP], #0x10
    // 0xd2ea74: ret
    //     0xd2ea74: ret             
    // 0xd2ea78: r0 = StackOverflowSharedWithFPURegs()
    //     0xd2ea78: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd2ea7c: b               #0xd2e940
    // 0xd2ea80: r0 = StackOverflowSharedWithFPURegs()
    //     0xd2ea80: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd2ea84: b               #0xd2e9a4
    // 0xd2ea88: r0 = RangeErrorSharedWithFPURegs()
    //     0xd2ea88: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xd2ea8c: r0 = RangeErrorSharedWithFPURegs()
    //     0xd2ea8c: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
}
