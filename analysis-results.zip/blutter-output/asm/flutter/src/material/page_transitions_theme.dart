// lib: , url: package:flutter/src/material/page_transitions_theme.dart

// class id: 1048927, size: 0x8
class :: {

  static _ _drawImageScaledAndCentered(/* No info */) {
    // ** addr: 0x121ab64, size: 0x20c
    // 0x121ab64: EnterFrame
    //     0x121ab64: stp             fp, lr, [SP, #-0x10]!
    //     0x121ab68: mov             fp, SP
    // 0x121ab6c: AllocStack(0x68)
    //     0x121ab6c: sub             SP, SP, #0x68
    // 0x121ab70: d3 = 0.000000
    //     0x121ab70: eor             v3.16b, v3.16b, v3.16b
    // 0x121ab74: stur            x1, [fp, #-8]
    // 0x121ab78: stur            x2, [fp, #-0x10]
    // 0x121ab7c: stur            d0, [fp, #-0x40]
    // 0x121ab80: stur            d1, [fp, #-0x48]
    // 0x121ab84: stur            d2, [fp, #-0x50]
    // 0x121ab88: CheckStackOverflow
    //     0x121ab88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121ab8c: cmp             SP, x16
    //     0x121ab90: b.ls            #0x121ad68
    // 0x121ab94: fcmp            d3, d0
    // 0x121ab98: b.ge            #0x121aba4
    // 0x121ab9c: fcmp            d3, d1
    // 0x121aba0: b.lt            #0x121abb4
    // 0x121aba4: r0 = Null
    //     0x121aba4: mov             x0, NULL
    // 0x121aba8: LeaveFrame
    //     0x121aba8: mov             SP, fp
    //     0x121abac: ldp             fp, lr, [SP], #0x10
    // 0x121abb0: ret
    //     0x121abb0: ret             
    // 0x121abb4: r16 = 136
    //     0x121abb4: mov             x16, #0x88
    // 0x121abb8: stp             x16, NULL, [SP]
    // 0x121abbc: r0 = ByteData()
    //     0x121abbc: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x121abc0: stur            x0, [fp, #-0x18]
    // 0x121abc4: r0 = Paint()
    //     0x121abc4: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x121abc8: mov             x1, x0
    // 0x121abcc: ldur            x0, [fp, #-0x18]
    // 0x121abd0: stur            x1, [fp, #-0x20]
    // 0x121abd4: StoreField: r1->field_7 = r0
    //     0x121abd4: stur            w0, [x1, #7]
    // 0x121abd8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x121abd8: ldur            w2, [x0, #0x17]
    // 0x121abdc: DecompressPointer r2
    //     0x121abdc: add             x2, x2, HEAP, lsl #32
    // 0x121abe0: LoadField: r0 = r2->field_7
    //     0x121abe0: ldur            x0, [x2, #7]
    // 0x121abe4: r2 = 2
    //     0x121abe4: mov             x2, #2
    // 0x121abe8: str             w2, [x0, #0x30]
    // 0x121abec: r0 = Color()
    //     0x121abec: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x121abf0: mov             x1, x0
    // 0x121abf4: r0 = Instance_ColorSpace
    //     0x121abf4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x121abf8: ldr             x0, [x0, #0x298]
    // 0x121abfc: StoreField: r1->field_27 = r0
    //     0x121abfc: stur            w0, [x1, #0x27]
    // 0x121ac00: ldur            d0, [fp, #-0x48]
    // 0x121ac04: StoreField: r1->field_7 = d0
    //     0x121ac04: stur            d0, [x1, #7]
    // 0x121ac08: StoreField: r1->field_f = rZR
    //     0x121ac08: stur            xzr, [x1, #0xf]
    // 0x121ac0c: ArrayStore: r1[0] = rZR  ; List_8
    //     0x121ac0c: stur            xzr, [x1, #0x17]
    // 0x121ac10: StoreField: r1->field_1f = rZR
    //     0x121ac10: stur            xzr, [x1, #0x1f]
    // 0x121ac14: mov             x2, x1
    // 0x121ac18: ldur            x1, [fp, #-0x20]
    // 0x121ac1c: r0 = color=()
    //     0x121ac1c: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x121ac20: ldur            x2, [fp, #-0x10]
    // 0x121ac24: LoadField: r0 = r2->field_f
    //     0x121ac24: ldur            x0, [x2, #0xf]
    // 0x121ac28: stur            x0, [fp, #-0x30]
    // 0x121ac2c: scvtf           d0, x0
    // 0x121ac30: ldur            d1, [fp, #-0x50]
    // 0x121ac34: fdiv            d2, d0, d1
    // 0x121ac38: ArrayLoad: r1 = r2[0]  ; List_8
    //     0x121ac38: ldur            x1, [x2, #0x17]
    // 0x121ac3c: stur            x1, [fp, #-0x28]
    // 0x121ac40: scvtf           d0, x1
    // 0x121ac44: fdiv            d3, d0, d1
    // 0x121ac48: ldur            d0, [fp, #-0x40]
    // 0x121ac4c: fmul            d1, d2, d0
    // 0x121ac50: fmul            d4, d3, d0
    // 0x121ac54: fsub            d0, d2, d1
    // 0x121ac58: d2 = 2.000000
    //     0x121ac58: fmov            d2, #2.00000000
    // 0x121ac5c: fdiv            d5, d0, d2
    // 0x121ac60: stur            d5, [fp, #-0x58]
    // 0x121ac64: fsub            d0, d3, d4
    // 0x121ac68: fdiv            d3, d0, d2
    // 0x121ac6c: stur            d3, [fp, #-0x50]
    // 0x121ac70: fadd            d0, d5, d1
    // 0x121ac74: stur            d0, [fp, #-0x48]
    // 0x121ac78: fadd            d1, d3, d4
    // 0x121ac7c: stur            d1, [fp, #-0x40]
    // 0x121ac80: r0 = Rect()
    //     0x121ac80: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x121ac84: ldur            d0, [fp, #-0x58]
    // 0x121ac88: stur            x0, [fp, #-0x18]
    // 0x121ac8c: StoreField: r0->field_7 = d0
    //     0x121ac8c: stur            d0, [x0, #7]
    // 0x121ac90: ldur            d0, [fp, #-0x50]
    // 0x121ac94: StoreField: r0->field_f = d0
    //     0x121ac94: stur            d0, [x0, #0xf]
    // 0x121ac98: ldur            d0, [fp, #-0x48]
    // 0x121ac9c: ArrayStore: r0[0] = d0  ; List_8
    //     0x121ac9c: stur            d0, [x0, #0x17]
    // 0x121aca0: ldur            d0, [fp, #-0x40]
    // 0x121aca4: StoreField: r0->field_1f = d0
    //     0x121aca4: stur            d0, [x0, #0x1f]
    // 0x121aca8: ldur            x1, [fp, #-8]
    // 0x121acac: r0 = canvas()
    //     0x121acac: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x121acb0: mov             x3, x0
    // 0x121acb4: ldur            x2, [fp, #-0x30]
    // 0x121acb8: stur            x3, [fp, #-8]
    // 0x121acbc: r0 = BoxInt64Instr(r2)
    //     0x121acbc: sbfiz           x0, x2, #1, #0x1f
    //     0x121acc0: cmp             x2, x0, asr #1
    //     0x121acc4: b.eq            #0x121acd0
    //     0x121acc8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x121accc: stur            x2, [x0, #7]
    // 0x121acd0: stp             x0, NULL, [SP]
    // 0x121acd4: r0 = _Double.fromInteger()
    //     0x121acd4: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0x121acd8: mov             x3, x0
    // 0x121acdc: ldur            x2, [fp, #-0x28]
    // 0x121ace0: stur            x3, [fp, #-0x38]
    // 0x121ace4: r0 = BoxInt64Instr(r2)
    //     0x121ace4: sbfiz           x0, x2, #1, #0x1f
    //     0x121ace8: cmp             x2, x0, asr #1
    //     0x121acec: b.eq            #0x121acf8
    //     0x121acf0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x121acf4: stur            x2, [x0, #7]
    // 0x121acf8: stp             x0, NULL, [SP]
    // 0x121acfc: r0 = _Double.fromInteger()
    //     0x121acfc: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0x121ad00: mov             x1, x0
    // 0x121ad04: ldur            x0, [fp, #-0x38]
    // 0x121ad08: LoadField: d0 = r0->field_7
    //     0x121ad08: ldur            d0, [x0, #7]
    // 0x121ad0c: d1 = 0.000000
    //     0x121ad0c: eor             v1.16b, v1.16b, v1.16b
    // 0x121ad10: fadd            d2, d0, d1
    // 0x121ad14: stur            d2, [fp, #-0x48]
    // 0x121ad18: LoadField: d0 = r1->field_7
    //     0x121ad18: ldur            d0, [x1, #7]
    // 0x121ad1c: fadd            d3, d0, d1
    // 0x121ad20: stur            d3, [fp, #-0x40]
    // 0x121ad24: r0 = Rect()
    //     0x121ad24: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x121ad28: StoreField: r0->field_7 = rZR
    //     0x121ad28: stur            xzr, [x0, #7]
    // 0x121ad2c: StoreField: r0->field_f = rZR
    //     0x121ad2c: stur            xzr, [x0, #0xf]
    // 0x121ad30: ldur            d0, [fp, #-0x48]
    // 0x121ad34: ArrayStore: r0[0] = d0  ; List_8
    //     0x121ad34: stur            d0, [x0, #0x17]
    // 0x121ad38: ldur            d0, [fp, #-0x40]
    // 0x121ad3c: StoreField: r0->field_1f = d0
    //     0x121ad3c: stur            d0, [x0, #0x1f]
    // 0x121ad40: ldur            x1, [fp, #-8]
    // 0x121ad44: ldur            x2, [fp, #-0x10]
    // 0x121ad48: mov             x3, x0
    // 0x121ad4c: ldur            x5, [fp, #-0x18]
    // 0x121ad50: ldur            x6, [fp, #-0x20]
    // 0x121ad54: r0 = drawImageRect()
    //     0x121ad54: bl              #0xb7d5e0  ; [dart:ui] _NativeCanvas::drawImageRect
    // 0x121ad58: r0 = Null
    //     0x121ad58: mov             x0, NULL
    // 0x121ad5c: LeaveFrame
    //     0x121ad5c: mov             SP, fp
    //     0x121ad60: ldp             fp, lr, [SP], #0x10
    // 0x121ad64: ret
    //     0x121ad64: ret             
    // 0x121ad68: r0 = StackOverflowSharedWithFPURegs()
    //     0x121ad68: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x121ad6c: b               #0x121ab94
  }
  static _ _updateScaledTransform(/* No info */) {
    // ** addr: 0x1282240, size: 0xc0
    // 0x1282240: EnterFrame
    //     0x1282240: stp             fp, lr, [SP, #-0x10]!
    //     0x1282244: mov             fp, SP
    // 0x1282248: AllocStack(0x18)
    //     0x1282248: sub             SP, SP, #0x18
    // 0x128224c: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* d0 => d2, fp-0x18 */)
    //     0x128224c: mov             x0, x1
    //     0x1282250: mov             v2.16b, v0.16b
    //     0x1282254: stur            x1, [fp, #-8]
    //     0x1282258: stur            x2, [fp, #-0x10]
    //     0x128225c: stur            d0, [fp, #-0x18]
    // 0x1282260: CheckStackOverflow
    //     0x1282260: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1282264: cmp             SP, x16
    //     0x1282268: b.ls            #0x12822f8
    // 0x128226c: mov             x1, x0
    // 0x1282270: r0 = setIdentity()
    //     0x1282270: bl              #0x836d10  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0x1282274: ldur            d3, [fp, #-0x18]
    // 0x1282278: d0 = 1.000000
    //     0x1282278: fmov            d0, #1.00000000
    // 0x128227c: fcmp            d3, d0
    // 0x1282280: b.ne            #0x1282294
    // 0x1282284: r0 = Null
    //     0x1282284: mov             x0, NULL
    // 0x1282288: LeaveFrame
    //     0x1282288: mov             SP, fp
    //     0x128228c: ldp             fp, lr, [SP], #0x10
    // 0x1282290: ret
    //     0x1282290: ret             
    // 0x1282294: ldur            x0, [fp, #-0x10]
    // 0x1282298: ldur            x1, [fp, #-8]
    // 0x128229c: mov             v0.16b, v3.16b
    // 0x12822a0: mov             v1.16b, v3.16b
    // 0x12822a4: mov             v2.16b, v3.16b
    // 0x12822a8: r0 = scaleByDouble()
    //     0x12822a8: bl              #0x832ce4  ; [package:vector_math/vector_math_64.dart] Matrix4::scaleByDouble
    // 0x12822ac: ldur            x0, [fp, #-0x10]
    // 0x12822b0: LoadField: d0 = r0->field_7
    //     0x12822b0: ldur            d0, [x0, #7]
    // 0x12822b4: ldur            d1, [fp, #-0x18]
    // 0x12822b8: fmul            d2, d0, d1
    // 0x12822bc: fsub            d3, d2, d0
    // 0x12822c0: d0 = 2.000000
    //     0x12822c0: fmov            d0, #2.00000000
    // 0x12822c4: fdiv            d2, d3, d0
    // 0x12822c8: LoadField: d3 = r0->field_f
    //     0x12822c8: ldur            d3, [x0, #0xf]
    // 0x12822cc: fmul            d4, d3, d1
    // 0x12822d0: fsub            d1, d4, d3
    // 0x12822d4: fdiv            d3, d1, d0
    // 0x12822d8: fneg            d0, d2
    // 0x12822dc: fneg            d1, d3
    // 0x12822e0: ldur            x1, [fp, #-8]
    // 0x12822e4: r0 = translateByDouble()
    //     0x12822e4: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0x12822e8: r0 = Null
    //     0x12822e8: mov             x0, NULL
    // 0x12822ec: LeaveFrame
    //     0x12822ec: mov             SP, fp
    //     0x12822f0: ldp             fp, lr, [SP], #0x10
    // 0x12822f4: ret
    //     0x12822f4: ret             
    // 0x12822f8: r0 = StackOverflowSharedWithFPURegs()
    //     0x12822f8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12822fc: b               #0x128226c
  }
}

// class id: 3253, size: 0x14, field offset: 0x8
//   const constructor, 
class ZoomPageTransitionsBuilder extends PageTransitionsBuilder {

  bool field_8;
  bool field_c;

  static _ _snapshotAwareDelegatedTransition(/* No info */) {
    // ** addr: 0xfbd3d0, size: 0x184
    // 0xfbd3d0: EnterFrame
    //     0xfbd3d0: stp             fp, lr, [SP, #-0x10]!
    //     0xfbd3d4: mov             fp, SP
    // 0xfbd3d8: AllocStack(0x30)
    //     0xfbd3d8: sub             SP, SP, #0x30
    // 0xfbd3dc: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */)
    //     0xfbd3dc: stur            x1, [fp, #-8]
    //     0xfbd3e0: stur            x2, [fp, #-0x10]
    //     0xfbd3e4: stur            x3, [fp, #-0x18]
    //     0xfbd3e8: stur            x5, [fp, #-0x20]
    //     0xfbd3ec: stur            x6, [fp, #-0x28]
    // 0xfbd3f0: CheckStackOverflow
    //     0xfbd3f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbd3f4: cmp             SP, x16
    //     0xfbd3f8: b.ls            #0xfbd54c
    // 0xfbd3fc: r1 = 2
    //     0xfbd3fc: mov             x1, #2
    // 0xfbd400: r0 = AllocateContext()
    //     0xfbd400: bl              #0x13de838  ; AllocateContextStub
    // 0xfbd404: mov             x2, x0
    // 0xfbd408: ldur            x0, [fp, #-0x20]
    // 0xfbd40c: stur            x2, [fp, #-0x30]
    // 0xfbd410: StoreField: r2->field_f = r0
    //     0xfbd410: stur            w0, [x2, #0xf]
    // 0xfbd414: ldur            x0, [fp, #-0x28]
    // 0xfbd418: cmp             w0, NULL
    // 0xfbd41c: b.ne            #0xfbd438
    // 0xfbd420: ldur            x1, [fp, #-8]
    // 0xfbd424: r0 = of()
    //     0xfbd424: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfbd428: LoadField: r1 = r0->field_3f
    //     0xfbd428: ldur            w1, [x0, #0x3f]
    // 0xfbd42c: DecompressPointer r1
    //     0xfbd42c: add             x1, x1, HEAP, lsl #32
    // 0xfbd430: LoadField: r0 = r1->field_7b
    //     0xfbd430: ldur            w0, [x1, #0x7b]
    // 0xfbd434: DecompressPointer r0
    //     0xfbd434: add             x0, x0, HEAP, lsl #32
    // 0xfbd438: ldur            x4, [fp, #-0x10]
    // 0xfbd43c: ldur            x3, [fp, #-0x18]
    // 0xfbd440: ldur            x2, [fp, #-0x30]
    // 0xfbd444: StoreField: r2->field_13 = r0
    //     0xfbd444: stur            w0, [x2, #0x13]
    //     0xfbd448: ldurb           w16, [x2, #-1]
    //     0xfbd44c: ldurb           w17, [x0, #-1]
    //     0xfbd450: and             x16, x17, x16, lsr #2
    //     0xfbd454: tst             x16, HEAP, lsr #32
    //     0xfbd458: b.eq            #0xfbd460
    //     0xfbd45c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfbd460: r1 = <double>
    //     0xfbd460: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfbd464: r0 = ReverseAnimation()
    //     0xfbd464: bl              #0xdffa24  ; AllocateReverseAnimationStub -> ReverseAnimation (size=0x1c)
    // 0xfbd468: mov             x2, x0
    // 0xfbd46c: ldur            x0, [fp, #-0x10]
    // 0xfbd470: stur            x2, [fp, #-8]
    // 0xfbd474: ArrayStore: r2[0] = r0  ; List_4
    //     0xfbd474: stur            w0, [x2, #0x17]
    // 0xfbd478: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xfbd478: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xfbd47c: r0 = ObserverList()
    //     0xfbd47c: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xfbd480: mov             x3, x0
    // 0xfbd484: r0 = false
    //     0xfbd484: add             x0, NULL, #0x30  ; false
    // 0xfbd488: stur            x3, [fp, #-0x10]
    // 0xfbd48c: StoreField: r3->field_f = r0
    //     0xfbd48c: stur            w0, [x3, #0xf]
    // 0xfbd490: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbd494: StoreField: r3->field_13 = r0
    //     0xfbd494: stur            w0, [x3, #0x13]
    // 0xfbd498: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xfbd498: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xfbd49c: r2 = 0
    //     0xfbd49c: mov             x2, #0
    // 0xfbd4a0: r0 = _GrowableList()
    //     0xfbd4a0: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfbd4a4: ldur            x1, [fp, #-0x10]
    // 0xfbd4a8: StoreField: r1->field_b = r0
    //     0xfbd4a8: stur            w0, [x1, #0xb]
    //     0xfbd4ac: ldurb           w16, [x1, #-1]
    //     0xfbd4b0: ldurb           w17, [x0, #-1]
    //     0xfbd4b4: and             x16, x17, x16, lsr #2
    //     0xfbd4b8: tst             x16, HEAP, lsr #32
    //     0xfbd4bc: b.eq            #0xfbd4c4
    //     0xfbd4c0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfbd4c4: mov             x0, x1
    // 0xfbd4c8: ldur            x1, [fp, #-8]
    // 0xfbd4cc: StoreField: r1->field_13 = r0
    //     0xfbd4cc: stur            w0, [x1, #0x13]
    //     0xfbd4d0: ldurb           w16, [x1, #-1]
    //     0xfbd4d4: ldurb           w17, [x0, #-1]
    //     0xfbd4d8: and             x16, x17, x16, lsr #2
    //     0xfbd4dc: tst             x16, HEAP, lsr #32
    //     0xfbd4e0: b.eq            #0xfbd4e8
    //     0xfbd4e4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfbd4e8: StoreField: r1->field_b = rZR
    //     0xfbd4e8: stur            xzr, [x1, #0xb]
    // 0xfbd4ec: r0 = DualTransitionBuilder()
    //     0xfbd4ec: bl              #0xfbd3c4  ; AllocateDualTransitionBuilderStub -> DualTransitionBuilder (size=0x1c)
    // 0xfbd4f0: mov             x3, x0
    // 0xfbd4f4: ldur            x0, [fp, #-8]
    // 0xfbd4f8: stur            x3, [fp, #-0x10]
    // 0xfbd4fc: StoreField: r3->field_b = r0
    //     0xfbd4fc: stur            w0, [x3, #0xb]
    // 0xfbd500: ldur            x2, [fp, #-0x30]
    // 0xfbd504: r1 = Function '<anonymous closure>': static.
    //     0xfbd504: add             x1, PP, #0x99, lsl #12  ; [pp+0x990c0] AnonymousClosure: static (0xfbd5b4), in [package:flutter/src/material/page_transitions_theme.dart] ZoomPageTransitionsBuilder::_snapshotAwareDelegatedTransition (0xfbd3d0)
    //     0xfbd508: ldr             x1, [x1, #0xc0]
    // 0xfbd50c: r0 = AllocateClosure()
    //     0xfbd50c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfbd510: mov             x1, x0
    // 0xfbd514: ldur            x0, [fp, #-0x10]
    // 0xfbd518: StoreField: r0->field_f = r1
    //     0xfbd518: stur            w1, [x0, #0xf]
    // 0xfbd51c: ldur            x2, [fp, #-0x30]
    // 0xfbd520: r1 = Function '<anonymous closure>': static.
    //     0xfbd520: add             x1, PP, #0x99, lsl #12  ; [pp+0x990c8] AnonymousClosure: static (0xfbd554), in [package:flutter/src/material/page_transitions_theme.dart] ZoomPageTransitionsBuilder::_snapshotAwareDelegatedTransition (0xfbd3d0)
    //     0xfbd524: ldr             x1, [x1, #0xc8]
    // 0xfbd528: r0 = AllocateClosure()
    //     0xfbd528: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfbd52c: mov             x1, x0
    // 0xfbd530: ldur            x0, [fp, #-0x10]
    // 0xfbd534: StoreField: r0->field_13 = r1
    //     0xfbd534: stur            w1, [x0, #0x13]
    // 0xfbd538: ldur            x1, [fp, #-0x18]
    // 0xfbd53c: ArrayStore: r0[0] = r1  ; List_4
    //     0xfbd53c: stur            w1, [x0, #0x17]
    // 0xfbd540: LeaveFrame
    //     0xfbd540: mov             SP, fp
    //     0xfbd544: ldp             fp, lr, [SP], #0x10
    // 0xfbd548: ret
    //     0xfbd548: ret             
    // 0xfbd54c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbd54c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbd550: b               #0xfbd3fc
  }
  [closure] static _ZoomExitTransition <anonymous closure>(dynamic, BuildContext, Animation<double>, Widget?) {
    // ** addr: 0xfbd554, size: 0x54
    // 0xfbd554: EnterFrame
    //     0xfbd554: stp             fp, lr, [SP, #-0x10]!
    //     0xfbd558: mov             fp, SP
    // 0xfbd55c: AllocStack(0x8)
    //     0xfbd55c: sub             SP, SP, #8
    // 0xfbd560: SetupParameters([dynamic _ /* r0 */])
    //     0xfbd560: ldr             x0, [fp, #0x28]
    //     0xfbd564: ldur            w1, [x0, #0x17]
    //     0xfbd568: add             x1, x1, HEAP, lsl #32
    // 0xfbd56c: LoadField: r0 = r1->field_f
    //     0xfbd56c: ldur            w0, [x1, #0xf]
    // 0xfbd570: DecompressPointer r0
    //     0xfbd570: add             x0, x0, HEAP, lsl #32
    // 0xfbd574: stur            x0, [fp, #-8]
    // 0xfbd578: r0 = _ZoomExitTransition()
    //     0xfbd578: bl              #0xfbd5a8  ; Allocate_ZoomExitTransitionStub -> _ZoomExitTransition (size=0x1c)
    // 0xfbd57c: ldr             x1, [fp, #0x18]
    // 0xfbd580: StoreField: r0->field_b = r1
    //     0xfbd580: stur            w1, [x0, #0xb]
    // 0xfbd584: r1 = false
    //     0xfbd584: add             x1, NULL, #0x30  ; false
    // 0xfbd588: StoreField: r0->field_13 = r1
    //     0xfbd588: stur            w1, [x0, #0x13]
    // 0xfbd58c: ldur            x1, [fp, #-8]
    // 0xfbd590: StoreField: r0->field_f = r1
    //     0xfbd590: stur            w1, [x0, #0xf]
    // 0xfbd594: ldr             x1, [fp, #0x10]
    // 0xfbd598: ArrayStore: r0[0] = r1  ; List_4
    //     0xfbd598: stur            w1, [x0, #0x17]
    // 0xfbd59c: LeaveFrame
    //     0xfbd59c: mov             SP, fp
    //     0xfbd5a0: ldp             fp, lr, [SP], #0x10
    // 0xfbd5a4: ret
    //     0xfbd5a4: ret             
  }
  [closure] static _ZoomEnterTransition <anonymous closure>(dynamic, BuildContext, Animation<double>, Widget?) {
    // ** addr: 0xfbd5b4, size: 0x80
    // 0xfbd5b4: EnterFrame
    //     0xfbd5b4: stp             fp, lr, [SP, #-0x10]!
    //     0xfbd5b8: mov             fp, SP
    // 0xfbd5bc: AllocStack(0x10)
    //     0xfbd5bc: sub             SP, SP, #0x10
    // 0xfbd5c0: SetupParameters([dynamic _ /* r0 */])
    //     0xfbd5c0: ldr             x0, [fp, #0x28]
    //     0xfbd5c4: ldur            w1, [x0, #0x17]
    //     0xfbd5c8: add             x1, x1, HEAP, lsl #32
    // 0xfbd5cc: LoadField: r0 = r1->field_f
    //     0xfbd5cc: ldur            w0, [x1, #0xf]
    // 0xfbd5d0: DecompressPointer r0
    //     0xfbd5d0: add             x0, x0, HEAP, lsl #32
    // 0xfbd5d4: tbnz            w0, #4, #0xfbd5e0
    // 0xfbd5d8: r3 = true
    //     0xfbd5d8: add             x3, NULL, #0x20  ; true
    // 0xfbd5dc: b               #0xfbd5e4
    // 0xfbd5e0: r3 = false
    //     0xfbd5e0: add             x3, NULL, #0x30  ; false
    // 0xfbd5e4: ldr             x2, [fp, #0x18]
    // 0xfbd5e8: ldr             x0, [fp, #0x10]
    // 0xfbd5ec: stur            x3, [fp, #-0x10]
    // 0xfbd5f0: LoadField: r4 = r1->field_13
    //     0xfbd5f0: ldur            w4, [x1, #0x13]
    // 0xfbd5f4: DecompressPointer r4
    //     0xfbd5f4: add             x4, x4, HEAP, lsl #32
    // 0xfbd5f8: stur            x4, [fp, #-8]
    // 0xfbd5fc: r0 = _ZoomEnterTransition()
    //     0xfbd5fc: bl              #0xfbd634  ; Allocate_ZoomEnterTransitionStub -> _ZoomEnterTransition (size=0x20)
    // 0xfbd600: ldr             x1, [fp, #0x18]
    // 0xfbd604: StoreField: r0->field_b = r1
    //     0xfbd604: stur            w1, [x0, #0xb]
    // 0xfbd608: r1 = true
    //     0xfbd608: add             x1, NULL, #0x20  ; true
    // 0xfbd60c: ArrayStore: r0[0] = r1  ; List_4
    //     0xfbd60c: stur            w1, [x0, #0x17]
    // 0xfbd610: ldur            x1, [fp, #-0x10]
    // 0xfbd614: StoreField: r0->field_13 = r1
    //     0xfbd614: stur            w1, [x0, #0x13]
    // 0xfbd618: ldur            x1, [fp, #-8]
    // 0xfbd61c: StoreField: r0->field_1b = r1
    //     0xfbd61c: stur            w1, [x0, #0x1b]
    // 0xfbd620: ldr             x1, [fp, #0x10]
    // 0xfbd624: StoreField: r0->field_f = r1
    //     0xfbd624: stur            w1, [x0, #0xf]
    // 0xfbd628: LeaveFrame
    //     0xfbd628: mov             SP, fp
    //     0xfbd62c: ldp             fp, lr, [SP], #0x10
    // 0xfbd630: ret
    //     0xfbd630: ret             
  }
  _ buildTransitions(/* No info */) {
    // ** addr: 0x119fb14, size: 0x3c
    // 0x119fb14: EnterFrame
    //     0x119fb14: stp             fp, lr, [SP, #-0x10]!
    //     0x119fb18: mov             fp, SP
    // 0x119fb1c: r0 = _ZoomPageTransition()
    //     0x119fb1c: bl              #0xb27f50  ; Allocate_ZoomPageTransitionStub -> _ZoomPageTransition (size=0x24)
    // 0x119fb20: ldr             x1, [fp, #0x20]
    // 0x119fb24: StoreField: r0->field_b = r1
    //     0x119fb24: stur            w1, [x0, #0xb]
    // 0x119fb28: ldr             x1, [fp, #0x18]
    // 0x119fb2c: StoreField: r0->field_f = r1
    //     0x119fb2c: stur            w1, [x0, #0xf]
    // 0x119fb30: r1 = true
    //     0x119fb30: add             x1, NULL, #0x20  ; true
    // 0x119fb34: StoreField: r0->field_13 = r1
    //     0x119fb34: stur            w1, [x0, #0x13]
    // 0x119fb38: StoreField: r0->field_1f = r1
    //     0x119fb38: stur            w1, [x0, #0x1f]
    // 0x119fb3c: ldr             x1, [fp, #0x10]
    // 0x119fb40: StoreField: r0->field_1b = r1
    //     0x119fb40: stur            w1, [x0, #0x1b]
    // 0x119fb44: LeaveFrame
    //     0x119fb44: mov             SP, fp
    //     0x119fb48: ldp             fp, lr, [SP], #0x10
    // 0x119fb4c: ret
    //     0x119fb4c: ret             
  }
  get _ delegatedTransition(/* No info */) {
    // ** addr: 0x12b8acc, size: 0x40
    // 0x12b8acc: EnterFrame
    //     0x12b8acc: stp             fp, lr, [SP, #-0x10]!
    //     0x12b8ad0: mov             fp, SP
    // 0x12b8ad4: AllocStack(0x8)
    //     0x12b8ad4: sub             SP, SP, #8
    // 0x12b8ad8: SetupParameters(ZoomPageTransitionsBuilder this /* r1 => r1, fp-0x8 */)
    //     0x12b8ad8: stur            x1, [fp, #-8]
    // 0x12b8adc: r1 = 1
    //     0x12b8adc: mov             x1, #1
    // 0x12b8ae0: r0 = AllocateContext()
    //     0x12b8ae0: bl              #0x13de838  ; AllocateContextStub
    // 0x12b8ae4: mov             x1, x0
    // 0x12b8ae8: ldur            x0, [fp, #-8]
    // 0x12b8aec: StoreField: r1->field_f = r0
    //     0x12b8aec: stur            w0, [x1, #0xf]
    // 0x12b8af0: mov             x2, x1
    // 0x12b8af4: r1 = Function '<anonymous closure>':.
    //     0x12b8af4: add             x1, PP, #0x99, lsl #12  ; [pp+0x990b8] AnonymousClosure: (0x12b8b0c), in [package:flutter/src/material/page_transitions_theme.dart] ZoomPageTransitionsBuilder::delegatedTransition (0x12b8acc)
    //     0x12b8af8: ldr             x1, [x1, #0xb8]
    // 0x12b8afc: r0 = AllocateClosure()
    //     0x12b8afc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12b8b00: LeaveFrame
    //     0x12b8b00: mov             SP, fp
    //     0x12b8b04: ldp             fp, lr, [SP], #0x10
    // 0x12b8b08: ret
    //     0x12b8b08: ret             
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, Animation<double>, Animation<double>, bool, Widget?) {
    // ** addr: 0x12b8b0c, size: 0x50
    // 0x12b8b0c: EnterFrame
    //     0x12b8b0c: stp             fp, lr, [SP, #-0x10]!
    //     0x12b8b10: mov             fp, SP
    // 0x12b8b14: CheckStackOverflow
    //     0x12b8b14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12b8b18: cmp             SP, x16
    //     0x12b8b1c: b.ls            #0x12b8b54
    // 0x12b8b20: ldr             x0, [fp, #0x18]
    // 0x12b8b24: tbnz            w0, #4, #0x12b8b30
    // 0x12b8b28: r5 = true
    //     0x12b8b28: add             x5, NULL, #0x20  ; true
    // 0x12b8b2c: b               #0x12b8b34
    // 0x12b8b30: r5 = false
    //     0x12b8b30: add             x5, NULL, #0x30  ; false
    // 0x12b8b34: ldr             x1, [fp, #0x30]
    // 0x12b8b38: ldr             x2, [fp, #0x20]
    // 0x12b8b3c: ldr             x3, [fp, #0x10]
    // 0x12b8b40: r6 = Null
    //     0x12b8b40: mov             x6, NULL
    // 0x12b8b44: r0 = _snapshotAwareDelegatedTransition()
    //     0x12b8b44: bl              #0xfbd3d0  ; [package:flutter/src/material/page_transitions_theme.dart] ZoomPageTransitionsBuilder::_snapshotAwareDelegatedTransition
    // 0x12b8b48: LeaveFrame
    //     0x12b8b48: mov             SP, fp
    //     0x12b8b4c: ldp             fp, lr, [SP], #0x10
    // 0x12b8b50: ret
    //     0x12b8b50: ret             
    // 0x12b8b54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12b8b54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12b8b58: b               #0x12b8b20
  }
}

// class id: 3254, size: 0xc, field offset: 0x8
//   const constructor, 
class FadeForwardsPageTransitionsBuilder extends PageTransitionsBuilder {

  static late final Animatable<double> _fadeOutTransition; // offset: 0x714
  static late final Animatable<double> _fadeInTransition; // offset: 0x710
  static late final Animatable<Offset> _secondaryBackwardTranslationTween; // offset: 0x708
  static late final Animatable<Offset> _secondaryForwardTranslationTween; // offset: 0x70c

  static _ _delegatedTransition(/* No info */) {
    // ** addr: 0xfbd77c, size: 0x1a8
    // 0xfbd77c: EnterFrame
    //     0xfbd77c: stp             fp, lr, [SP, #-0x10]!
    //     0xfbd780: mov             fp, SP
    // 0xfbd784: AllocStack(0x28)
    //     0xfbd784: sub             SP, SP, #0x28
    // 0xfbd788: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xfbd788: mov             x0, x2
    //     0xfbd78c: stur            x2, [fp, #-0x10]
    //     0xfbd790: mov             x2, x1
    //     0xfbd794: stur            x1, [fp, #-8]
    //     0xfbd798: stur            x3, [fp, #-0x18]
    // 0xfbd79c: CheckStackOverflow
    //     0xfbd79c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbd7a0: cmp             SP, x16
    //     0xfbd7a4: b.ls            #0xfbd91c
    // 0xfbd7a8: r1 = <double>
    //     0xfbd7a8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfbd7ac: r0 = ReverseAnimation()
    //     0xfbd7ac: bl              #0xdffa24  ; AllocateReverseAnimationStub -> ReverseAnimation (size=0x1c)
    // 0xfbd7b0: mov             x2, x0
    // 0xfbd7b4: ldur            x0, [fp, #-0x10]
    // 0xfbd7b8: stur            x2, [fp, #-0x20]
    // 0xfbd7bc: ArrayStore: r2[0] = r0  ; List_4
    //     0xfbd7bc: stur            w0, [x2, #0x17]
    // 0xfbd7c0: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xfbd7c0: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xfbd7c4: r0 = ObserverList()
    //     0xfbd7c4: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xfbd7c8: mov             x3, x0
    // 0xfbd7cc: r0 = false
    //     0xfbd7cc: add             x0, NULL, #0x30  ; false
    // 0xfbd7d0: stur            x3, [fp, #-0x28]
    // 0xfbd7d4: StoreField: r3->field_f = r0
    //     0xfbd7d4: stur            w0, [x3, #0xf]
    // 0xfbd7d8: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbd7dc: StoreField: r3->field_13 = r0
    //     0xfbd7dc: stur            w0, [x3, #0x13]
    // 0xfbd7e0: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xfbd7e0: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xfbd7e4: r2 = 0
    //     0xfbd7e4: mov             x2, #0
    // 0xfbd7e8: r0 = _GrowableList()
    //     0xfbd7e8: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfbd7ec: ldur            x1, [fp, #-0x28]
    // 0xfbd7f0: StoreField: r1->field_b = r0
    //     0xfbd7f0: stur            w0, [x1, #0xb]
    //     0xfbd7f4: ldurb           w16, [x1, #-1]
    //     0xfbd7f8: ldurb           w17, [x0, #-1]
    //     0xfbd7fc: and             x16, x17, x16, lsr #2
    //     0xfbd800: tst             x16, HEAP, lsr #32
    //     0xfbd804: b.eq            #0xfbd80c
    //     0xfbd808: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfbd80c: mov             x0, x1
    // 0xfbd810: ldur            x1, [fp, #-0x20]
    // 0xfbd814: StoreField: r1->field_13 = r0
    //     0xfbd814: stur            w0, [x1, #0x13]
    //     0xfbd818: ldurb           w16, [x1, #-1]
    //     0xfbd81c: ldurb           w17, [x0, #-1]
    //     0xfbd820: and             x16, x17, x16, lsr #2
    //     0xfbd824: tst             x16, HEAP, lsr #32
    //     0xfbd828: b.eq            #0xfbd830
    //     0xfbd82c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfbd830: StoreField: r1->field_b = rZR
    //     0xfbd830: stur            xzr, [x1, #0xb]
    // 0xfbd834: r0 = DualTransitionBuilder()
    //     0xfbd834: bl              #0xfbd3c4  ; AllocateDualTransitionBuilderStub -> DualTransitionBuilder (size=0x1c)
    // 0xfbd838: mov             x3, x0
    // 0xfbd83c: ldur            x0, [fp, #-0x20]
    // 0xfbd840: stur            x3, [fp, #-0x28]
    // 0xfbd844: StoreField: r3->field_b = r0
    //     0xfbd844: stur            w0, [x3, #0xb]
    // 0xfbd848: r1 = Function '<anonymous closure>': static.
    //     0xfbd848: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0520] AnonymousClosure: static (0xfbdb88), in [package:flutter/src/material/page_transitions_theme.dart] FadeForwardsPageTransitionsBuilder::_delegatedTransition (0xfbd77c)
    //     0xfbd84c: ldr             x1, [x1, #0x520]
    // 0xfbd850: r2 = Null
    //     0xfbd850: mov             x2, NULL
    // 0xfbd854: r0 = AllocateClosure()
    //     0xfbd854: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfbd858: mov             x1, x0
    // 0xfbd85c: ldur            x0, [fp, #-0x28]
    // 0xfbd860: StoreField: r0->field_f = r1
    //     0xfbd860: stur            w1, [x0, #0xf]
    // 0xfbd864: r1 = Function '<anonymous closure>': static.
    //     0xfbd864: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0528] AnonymousClosure: static (0xfbd9d4), in [package:flutter/src/material/page_transitions_theme.dart] FadeForwardsPageTransitionsBuilder::_delegatedTransition (0xfbd77c)
    //     0xfbd868: ldr             x1, [x1, #0x528]
    // 0xfbd86c: r2 = Null
    //     0xfbd86c: mov             x2, NULL
    // 0xfbd870: r0 = AllocateClosure()
    //     0xfbd870: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfbd874: mov             x1, x0
    // 0xfbd878: ldur            x0, [fp, #-0x28]
    // 0xfbd87c: StoreField: r0->field_13 = r1
    //     0xfbd87c: stur            w1, [x0, #0x13]
    // 0xfbd880: ldur            x1, [fp, #-0x18]
    // 0xfbd884: ArrayStore: r0[0] = r1  ; List_4
    //     0xfbd884: stur            w1, [x0, #0x17]
    // 0xfbd888: ldur            x1, [fp, #-8]
    // 0xfbd88c: r0 = opaqueOf()
    //     0xfbd88c: bl              #0xfbd95c  ; [package:flutter/src/widgets/routes.dart] ModalRoute::opaqueOf
    // 0xfbd890: cmp             w0, NULL
    // 0xfbd894: b.eq            #0xfbd8ac
    // 0xfbd898: tbz             w0, #4, #0xfbd8ac
    // 0xfbd89c: ldur            x0, [fp, #-0x28]
    // 0xfbd8a0: LeaveFrame
    //     0xfbd8a0: mov             SP, fp
    //     0xfbd8a4: ldp             fp, lr, [SP], #0x10
    // 0xfbd8a8: ret
    //     0xfbd8a8: ret             
    // 0xfbd8ac: ldur            x1, [fp, #-0x10]
    // 0xfbd8b0: r0 = LoadClassIdInstr(r1)
    //     0xfbd8b0: ldur            x0, [x1, #-1]
    //     0xfbd8b4: ubfx            x0, x0, #0xc, #0x14
    // 0xfbd8b8: r0 = GDT[cid_x0 + 0x12d66]()
    //     0xfbd8b8: mov             x17, #0x2d66
    //     0xfbd8bc: movk            x17, #1, lsl #16
    //     0xfbd8c0: add             lr, x0, x17
    //     0xfbd8c4: ldr             lr, [x21, lr, lsl #3]
    //     0xfbd8c8: blr             lr
    // 0xfbd8cc: tbnz            w0, #4, #0xfbd8e4
    // 0xfbd8d0: ldur            x1, [fp, #-8]
    // 0xfbd8d4: r0 = of()
    //     0xfbd8d4: bl              #0xfbd924  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::of
    // 0xfbd8d8: LoadField: r1 = r0->field_7b
    //     0xfbd8d8: ldur            w1, [x0, #0x7b]
    // 0xfbd8dc: DecompressPointer r1
    //     0xfbd8dc: add             x1, x1, HEAP, lsl #32
    // 0xfbd8e0: b               #0xfbd8ec
    // 0xfbd8e4: r1 = Instance_Color
    //     0xfbd8e4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xfbd8e8: ldr             x1, [x1, #0x810]
    // 0xfbd8ec: ldur            x0, [fp, #-0x28]
    // 0xfbd8f0: stur            x1, [fp, #-8]
    // 0xfbd8f4: r0 = ColoredBox()
    //     0xfbd8f4: bl              #0xd1a914  ; AllocateColoredBoxStub -> ColoredBox (size=0x18)
    // 0xfbd8f8: ldur            x1, [fp, #-8]
    // 0xfbd8fc: StoreField: r0->field_f = r1
    //     0xfbd8fc: stur            w1, [x0, #0xf]
    // 0xfbd900: r1 = true
    //     0xfbd900: add             x1, NULL, #0x20  ; true
    // 0xfbd904: StoreField: r0->field_13 = r1
    //     0xfbd904: stur            w1, [x0, #0x13]
    // 0xfbd908: ldur            x1, [fp, #-0x28]
    // 0xfbd90c: StoreField: r0->field_b = r1
    //     0xfbd90c: stur            w1, [x0, #0xb]
    // 0xfbd910: LeaveFrame
    //     0xfbd910: mov             SP, fp
    //     0xfbd914: ldp             fp, lr, [SP], #0x10
    // 0xfbd918: ret
    //     0xfbd918: ret             
    // 0xfbd91c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbd91c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbd920: b               #0xfbd7a8
  }
  [closure] static FadeTransition <anonymous closure>(dynamic, BuildContext, Animation<double>, Widget?) {
    // ** addr: 0xfbd9d4, size: 0xcc
    // 0xfbd9d4: EnterFrame
    //     0xfbd9d4: stp             fp, lr, [SP, #-0x10]!
    //     0xfbd9d8: mov             fp, SP
    // 0xfbd9dc: AllocStack(0x18)
    //     0xfbd9dc: sub             SP, SP, #0x18
    // 0xfbd9e0: CheckStackOverflow
    //     0xfbd9e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbd9e4: cmp             SP, x16
    //     0xfbd9e8: b.ls            #0xfbda98
    // 0xfbd9ec: r0 = LoadStaticField(0x714)
    //     0xfbd9ec: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfbd9f0: ldr             x0, [x0, #0xe28]
    // 0xfbd9f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbd9f8: cmp             w0, w16
    // 0xfbd9fc: b.ne            #0xfbda0c
    // 0xfbda00: r2 = _fadeOutTransition
    //     0xfbda00: add             x2, PP, #0xd0, lsl #12  ; [pp+0xd04f0] Field <FadeForwardsPageTransitionsBuilder._fadeOutTransition@110490068>: static late final (offset: 0x714)
    //     0xfbda04: ldr             x2, [x2, #0x4f0]
    // 0xfbda08: r0 = InitLateFinalStaticField()
    //     0xfbda08: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xfbda0c: mov             x1, x0
    // 0xfbda10: ldr             x2, [fp, #0x18]
    // 0xfbda14: r0 = animate()
    //     0xfbda14: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xfbda18: stur            x0, [fp, #-8]
    // 0xfbda1c: r0 = LoadStaticField(0x708)
    //     0xfbda1c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfbda20: ldr             x0, [x0, #0xe10]
    // 0xfbda24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbda28: cmp             w0, w16
    // 0xfbda2c: b.ne            #0xfbda3c
    // 0xfbda30: r2 = _secondaryBackwardTranslationTween
    //     0xfbda30: add             x2, PP, #0xd0, lsl #12  ; [pp+0xd0530] Field <FadeForwardsPageTransitionsBuilder._secondaryBackwardTranslationTween@110490068>: static late final (offset: 0x708)
    //     0xfbda34: ldr             x2, [x2, #0x530]
    // 0xfbda38: r0 = InitLateFinalStaticField()
    //     0xfbda38: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xfbda3c: mov             x1, x0
    // 0xfbda40: ldr             x2, [fp, #0x18]
    // 0xfbda44: r0 = animate()
    //     0xfbda44: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xfbda48: stur            x0, [fp, #-0x10]
    // 0xfbda4c: r0 = SlideTransition()
    //     0xfbda4c: bl              #0xb28364  ; AllocateSlideTransitionStub -> SlideTransition (size=0x1c)
    // 0xfbda50: mov             x1, x0
    // 0xfbda54: r0 = true
    //     0xfbda54: add             x0, NULL, #0x20  ; true
    // 0xfbda58: stur            x1, [fp, #-0x18]
    // 0xfbda5c: StoreField: r1->field_13 = r0
    //     0xfbda5c: stur            w0, [x1, #0x13]
    // 0xfbda60: ldr             x0, [fp, #0x10]
    // 0xfbda64: ArrayStore: r1[0] = r0  ; List_4
    //     0xfbda64: stur            w0, [x1, #0x17]
    // 0xfbda68: ldur            x0, [fp, #-0x10]
    // 0xfbda6c: StoreField: r1->field_b = r0
    //     0xfbda6c: stur            w0, [x1, #0xb]
    // 0xfbda70: r0 = FadeTransition()
    //     0xfbda70: bl              #0xb28358  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0xfbda74: ldur            x1, [fp, #-8]
    // 0xfbda78: StoreField: r0->field_f = r1
    //     0xfbda78: stur            w1, [x0, #0xf]
    // 0xfbda7c: r1 = false
    //     0xfbda7c: add             x1, NULL, #0x30  ; false
    // 0xfbda80: StoreField: r0->field_13 = r1
    //     0xfbda80: stur            w1, [x0, #0x13]
    // 0xfbda84: ldur            x1, [fp, #-0x18]
    // 0xfbda88: StoreField: r0->field_b = r1
    //     0xfbda88: stur            w1, [x0, #0xb]
    // 0xfbda8c: LeaveFrame
    //     0xfbda8c: mov             SP, fp
    //     0xfbda90: ldp             fp, lr, [SP], #0x10
    // 0xfbda94: ret
    //     0xfbda94: ret             
    // 0xfbda98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbda98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbda9c: b               #0xfbd9ec
  }
  static Animatable<Offset> _secondaryBackwardTranslationTween() {
    // ** addr: 0xfbdaa0, size: 0x78
    // 0xfbdaa0: EnterFrame
    //     0xfbdaa0: stp             fp, lr, [SP, #-0x10]!
    //     0xfbdaa4: mov             fp, SP
    // 0xfbdaa8: AllocStack(0x8)
    //     0xfbdaa8: sub             SP, SP, #8
    // 0xfbdaac: CheckStackOverflow
    //     0xfbdaac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbdab0: cmp             SP, x16
    //     0xfbdab4: b.ls            #0xfbdb10
    // 0xfbdab8: r1 = <Offset>
    //     0xfbdab8: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a48] TypeArguments: <Offset>
    //     0xfbdabc: ldr             x1, [x1, #0xa48]
    // 0xfbdac0: r0 = Tween()
    //     0xfbdac0: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xfbdac4: mov             x2, x0
    // 0xfbdac8: r0 = Instance_Offset
    //     0xfbdac8: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xfbdacc: stur            x2, [fp, #-8]
    // 0xfbdad0: StoreField: r2->field_b = r0
    //     0xfbdad0: stur            w0, [x2, #0xb]
    // 0xfbdad4: r0 = Instance_Offset
    //     0xfbdad4: add             x0, PP, #0xd0, lsl #12  ; [pp+0xd0538] Obj!Offset@12aa0d1
    //     0xfbdad8: ldr             x0, [x0, #0x538]
    // 0xfbdadc: StoreField: r2->field_f = r0
    //     0xfbdadc: stur            w0, [x2, #0xf]
    // 0xfbdae0: r1 = <double>
    //     0xfbdae0: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfbdae4: r0 = CurveTween()
    //     0xfbdae4: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xfbdae8: mov             x1, x0
    // 0xfbdaec: r0 = Instance_ThreePointCubic
    //     0xfbdaec: add             x0, PP, #0xa4, lsl #12  ; [pp+0xa4068] Obj!ThreePointCubic@129f3e1
    //     0xfbdaf0: ldr             x0, [x0, #0x68]
    // 0xfbdaf4: StoreField: r1->field_b = r0
    //     0xfbdaf4: stur            w0, [x1, #0xb]
    // 0xfbdaf8: mov             x2, x1
    // 0xfbdafc: ldur            x1, [fp, #-8]
    // 0xfbdb00: r0 = chain()
    //     0xfbdb00: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xfbdb04: LeaveFrame
    //     0xfbdb04: mov             SP, fp
    //     0xfbdb08: ldp             fp, lr, [SP], #0x10
    // 0xfbdb0c: ret
    //     0xfbdb0c: ret             
    // 0xfbdb10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbdb10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbdb14: b               #0xfbdab8
  }
  static Animatable<double> _fadeOutTransition() {
    // ** addr: 0xfbdb18, size: 0x70
    // 0xfbdb18: EnterFrame
    //     0xfbdb18: stp             fp, lr, [SP, #-0x10]!
    //     0xfbdb1c: mov             fp, SP
    // 0xfbdb20: AllocStack(0x8)
    //     0xfbdb20: sub             SP, SP, #8
    // 0xfbdb24: CheckStackOverflow
    //     0xfbdb24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbdb28: cmp             SP, x16
    //     0xfbdb2c: b.ls            #0xfbdb80
    // 0xfbdb30: r1 = <double>
    //     0xfbdb30: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfbdb34: r0 = Tween()
    //     0xfbdb34: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xfbdb38: mov             x2, x0
    // 0xfbdb3c: r0 = 1.000000
    //     0xfbdb3c: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xfbdb40: stur            x2, [fp, #-8]
    // 0xfbdb44: StoreField: r2->field_b = r0
    //     0xfbdb44: stur            w0, [x2, #0xb]
    // 0xfbdb48: r0 = 0.000000
    //     0xfbdb48: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfbdb4c: StoreField: r2->field_f = r0
    //     0xfbdb4c: stur            w0, [x2, #0xf]
    // 0xfbdb50: r1 = <double>
    //     0xfbdb50: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfbdb54: r0 = CurveTween()
    //     0xfbdb54: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xfbdb58: mov             x1, x0
    // 0xfbdb5c: r0 = Instance_Interval
    //     0xfbdb5c: add             x0, PP, #0xd0, lsl #12  ; [pp+0xd0508] Obj!Interval@129fe71
    //     0xfbdb60: ldr             x0, [x0, #0x508]
    // 0xfbdb64: StoreField: r1->field_b = r0
    //     0xfbdb64: stur            w0, [x1, #0xb]
    // 0xfbdb68: mov             x2, x1
    // 0xfbdb6c: ldur            x1, [fp, #-8]
    // 0xfbdb70: r0 = chain()
    //     0xfbdb70: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xfbdb74: LeaveFrame
    //     0xfbdb74: mov             SP, fp
    //     0xfbdb78: ldp             fp, lr, [SP], #0x10
    // 0xfbdb7c: ret
    //     0xfbdb7c: ret             
    // 0xfbdb80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbdb80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbdb84: b               #0xfbdb30
  }
  [closure] static FadeTransition <anonymous closure>(dynamic, BuildContext, Animation<double>, Widget?) {
    // ** addr: 0xfbdb88, size: 0xcc
    // 0xfbdb88: EnterFrame
    //     0xfbdb88: stp             fp, lr, [SP, #-0x10]!
    //     0xfbdb8c: mov             fp, SP
    // 0xfbdb90: AllocStack(0x18)
    //     0xfbdb90: sub             SP, SP, #0x18
    // 0xfbdb94: CheckStackOverflow
    //     0xfbdb94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbdb98: cmp             SP, x16
    //     0xfbdb9c: b.ls            #0xfbdc4c
    // 0xfbdba0: r0 = LoadStaticField(0x710)
    //     0xfbdba0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfbdba4: ldr             x0, [x0, #0xe20]
    // 0xfbdba8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbdbac: cmp             w0, w16
    // 0xfbdbb0: b.ne            #0xfbdbc0
    // 0xfbdbb4: r2 = _fadeInTransition
    //     0xfbdbb4: add             x2, PP, #0xd0, lsl #12  ; [pp+0xd0510] Field <FadeForwardsPageTransitionsBuilder._fadeInTransition@110490068>: static late final (offset: 0x710)
    //     0xfbdbb8: ldr             x2, [x2, #0x510]
    // 0xfbdbbc: r0 = InitLateFinalStaticField()
    //     0xfbdbbc: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xfbdbc0: mov             x1, x0
    // 0xfbdbc4: ldr             x2, [fp, #0x18]
    // 0xfbdbc8: r0 = animate()
    //     0xfbdbc8: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xfbdbcc: stur            x0, [fp, #-8]
    // 0xfbdbd0: r0 = LoadStaticField(0x70c)
    //     0xfbdbd0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfbdbd4: ldr             x0, [x0, #0xe18]
    // 0xfbdbd8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbdbdc: cmp             w0, w16
    // 0xfbdbe0: b.ne            #0xfbdbf0
    // 0xfbdbe4: r2 = _secondaryForwardTranslationTween
    //     0xfbdbe4: add             x2, PP, #0xd0, lsl #12  ; [pp+0xd0540] Field <FadeForwardsPageTransitionsBuilder._secondaryForwardTranslationTween@110490068>: static late final (offset: 0x70c)
    //     0xfbdbe8: ldr             x2, [x2, #0x540]
    // 0xfbdbec: r0 = InitLateFinalStaticField()
    //     0xfbdbec: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xfbdbf0: mov             x1, x0
    // 0xfbdbf4: ldr             x2, [fp, #0x18]
    // 0xfbdbf8: r0 = animate()
    //     0xfbdbf8: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xfbdbfc: stur            x0, [fp, #-0x10]
    // 0xfbdc00: r0 = SlideTransition()
    //     0xfbdc00: bl              #0xb28364  ; AllocateSlideTransitionStub -> SlideTransition (size=0x1c)
    // 0xfbdc04: mov             x1, x0
    // 0xfbdc08: r0 = true
    //     0xfbdc08: add             x0, NULL, #0x20  ; true
    // 0xfbdc0c: stur            x1, [fp, #-0x18]
    // 0xfbdc10: StoreField: r1->field_13 = r0
    //     0xfbdc10: stur            w0, [x1, #0x13]
    // 0xfbdc14: ldr             x0, [fp, #0x10]
    // 0xfbdc18: ArrayStore: r1[0] = r0  ; List_4
    //     0xfbdc18: stur            w0, [x1, #0x17]
    // 0xfbdc1c: ldur            x0, [fp, #-0x10]
    // 0xfbdc20: StoreField: r1->field_b = r0
    //     0xfbdc20: stur            w0, [x1, #0xb]
    // 0xfbdc24: r0 = FadeTransition()
    //     0xfbdc24: bl              #0xb28358  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0xfbdc28: ldur            x1, [fp, #-8]
    // 0xfbdc2c: StoreField: r0->field_f = r1
    //     0xfbdc2c: stur            w1, [x0, #0xf]
    // 0xfbdc30: r1 = false
    //     0xfbdc30: add             x1, NULL, #0x30  ; false
    // 0xfbdc34: StoreField: r0->field_13 = r1
    //     0xfbdc34: stur            w1, [x0, #0x13]
    // 0xfbdc38: ldur            x1, [fp, #-0x18]
    // 0xfbdc3c: StoreField: r0->field_b = r1
    //     0xfbdc3c: stur            w1, [x0, #0xb]
    // 0xfbdc40: LeaveFrame
    //     0xfbdc40: mov             SP, fp
    //     0xfbdc44: ldp             fp, lr, [SP], #0x10
    // 0xfbdc48: ret
    //     0xfbdc48: ret             
    // 0xfbdc4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbdc4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbdc50: b               #0xfbdba0
  }
  static Animatable<Offset> _secondaryForwardTranslationTween() {
    // ** addr: 0xfbdc54, size: 0x78
    // 0xfbdc54: EnterFrame
    //     0xfbdc54: stp             fp, lr, [SP, #-0x10]!
    //     0xfbdc58: mov             fp, SP
    // 0xfbdc5c: AllocStack(0x8)
    //     0xfbdc5c: sub             SP, SP, #8
    // 0xfbdc60: CheckStackOverflow
    //     0xfbdc60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbdc64: cmp             SP, x16
    //     0xfbdc68: b.ls            #0xfbdcc4
    // 0xfbdc6c: r1 = <Offset>
    //     0xfbdc6c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a48] TypeArguments: <Offset>
    //     0xfbdc70: ldr             x1, [x1, #0xa48]
    // 0xfbdc74: r0 = Tween()
    //     0xfbdc74: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xfbdc78: mov             x2, x0
    // 0xfbdc7c: r0 = Instance_Offset
    //     0xfbdc7c: add             x0, PP, #0xd0, lsl #12  ; [pp+0xd0538] Obj!Offset@12aa0d1
    //     0xfbdc80: ldr             x0, [x0, #0x538]
    // 0xfbdc84: stur            x2, [fp, #-8]
    // 0xfbdc88: StoreField: r2->field_b = r0
    //     0xfbdc88: stur            w0, [x2, #0xb]
    // 0xfbdc8c: r0 = Instance_Offset
    //     0xfbdc8c: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xfbdc90: StoreField: r2->field_f = r0
    //     0xfbdc90: stur            w0, [x2, #0xf]
    // 0xfbdc94: r1 = <double>
    //     0xfbdc94: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfbdc98: r0 = CurveTween()
    //     0xfbdc98: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xfbdc9c: mov             x1, x0
    // 0xfbdca0: r0 = Instance_ThreePointCubic
    //     0xfbdca0: add             x0, PP, #0xa4, lsl #12  ; [pp+0xa4068] Obj!ThreePointCubic@129f3e1
    //     0xfbdca4: ldr             x0, [x0, #0x68]
    // 0xfbdca8: StoreField: r1->field_b = r0
    //     0xfbdca8: stur            w0, [x1, #0xb]
    // 0xfbdcac: mov             x2, x1
    // 0xfbdcb0: ldur            x1, [fp, #-8]
    // 0xfbdcb4: r0 = chain()
    //     0xfbdcb4: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xfbdcb8: LeaveFrame
    //     0xfbdcb8: mov             SP, fp
    //     0xfbdcbc: ldp             fp, lr, [SP], #0x10
    // 0xfbdcc0: ret
    //     0xfbdcc0: ret             
    // 0xfbdcc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbdcc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbdcc8: b               #0xfbdc6c
  }
  static Animatable<double> _fadeInTransition() {
    // ** addr: 0xfbdccc, size: 0x70
    // 0xfbdccc: EnterFrame
    //     0xfbdccc: stp             fp, lr, [SP, #-0x10]!
    //     0xfbdcd0: mov             fp, SP
    // 0xfbdcd4: AllocStack(0x8)
    //     0xfbdcd4: sub             SP, SP, #8
    // 0xfbdcd8: CheckStackOverflow
    //     0xfbdcd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbdcdc: cmp             SP, x16
    //     0xfbdce0: b.ls            #0xfbdd34
    // 0xfbdce4: r1 = <double>
    //     0xfbdce4: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfbdce8: r0 = Tween()
    //     0xfbdce8: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xfbdcec: mov             x2, x0
    // 0xfbdcf0: r0 = 0.000000
    //     0xfbdcf0: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfbdcf4: stur            x2, [fp, #-8]
    // 0xfbdcf8: StoreField: r2->field_b = r0
    //     0xfbdcf8: stur            w0, [x2, #0xb]
    // 0xfbdcfc: r0 = 1.000000
    //     0xfbdcfc: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xfbdd00: StoreField: r2->field_f = r0
    //     0xfbdd00: stur            w0, [x2, #0xf]
    // 0xfbdd04: r1 = <double>
    //     0xfbdd04: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfbdd08: r0 = CurveTween()
    //     0xfbdd08: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xfbdd0c: mov             x1, x0
    // 0xfbdd10: r0 = Instance_Interval
    //     0xfbdd10: add             x0, PP, #0xab, lsl #12  ; [pp+0xabfc0] Obj!Interval@129fd51
    //     0xfbdd14: ldr             x0, [x0, #0xfc0]
    // 0xfbdd18: StoreField: r1->field_b = r0
    //     0xfbdd18: stur            w0, [x1, #0xb]
    // 0xfbdd1c: mov             x2, x1
    // 0xfbdd20: ldur            x1, [fp, #-8]
    // 0xfbdd24: r0 = chain()
    //     0xfbdd24: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xfbdd28: LeaveFrame
    //     0xfbdd28: mov             SP, fp
    //     0xfbdd2c: ldp             fp, lr, [SP], #0x10
    // 0xfbdd30: ret
    //     0xfbdd30: ret             
    // 0xfbdd34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbdd34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbdd38: b               #0xfbdce4
  }
}

// class id: 4492, size: 0x40, field offset: 0x24
class _ZoomExitTransitionPainter extends SnapshotPainter {

  _ _ZoomExitTransitionPainter(/* No info */) {
    // ** addr: 0xf3b218, size: 0x208
    // 0xf3b218: EnterFrame
    //     0xf3b218: stp             fp, lr, [SP, #-0x10]!
    //     0xf3b21c: mov             fp, SP
    // 0xf3b220: AllocStack(0x30)
    //     0xf3b220: sub             SP, SP, #0x30
    // 0xf3b224: SetupParameters(_ZoomExitTransitionPainter this /* r1 => r3, fp-0x28 */, dynamic _ /* r3 => r1, fp-0x18 */, [dynamic _ /* fp-0x20 */])
    //     0xf3b224: stur            x1, [fp, #-8]
    //     0xf3b228: mov             x16, x3
    //     0xf3b22c: mov             x3, x1
    //     0xf3b230: mov             x1, x16
    //     0xf3b234: mov             x0, x6
    //     0xf3b238: stur            x2, [fp, #-0x10]
    //     0xf3b23c: stur            x1, [fp, #-0x18]
    //     0xf3b240: stur            x5, [fp, #-0x20]
    //     0xf3b244: stur            x6, [fp, #-0x28]
    // 0xf3b248: CheckStackOverflow
    //     0xf3b248: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3b24c: cmp             SP, x16
    //     0xf3b250: b.ls            #0xf3b418
    // 0xf3b254: r0 = Matrix4()
    //     0xf3b254: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xf3b258: r4 = 32
    //     0xf3b258: mov             x4, #0x20
    // 0xf3b25c: stur            x0, [fp, #-0x30]
    // 0xf3b260: r0 = AllocateFloat64Array()
    //     0xf3b260: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0xf3b264: mov             x1, x0
    // 0xf3b268: ldur            x0, [fp, #-0x30]
    // 0xf3b26c: StoreField: r0->field_7 = r1
    //     0xf3b26c: stur            w1, [x0, #7]
    // 0xf3b270: ldur            x2, [fp, #-8]
    // 0xf3b274: StoreField: r2->field_33 = r0
    //     0xf3b274: stur            w0, [x2, #0x33]
    //     0xf3b278: ldurb           w16, [x2, #-1]
    //     0xf3b27c: ldurb           w17, [x0, #-1]
    //     0xf3b280: and             x16, x17, x16, lsr #2
    //     0xf3b284: tst             x16, HEAP, lsr #32
    //     0xf3b288: b.eq            #0xf3b290
    //     0xf3b28c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3b290: r1 = <OpacityLayer>
    //     0xf3b290: add             x1, PP, #0xad, lsl #12  ; [pp+0xadbe0] TypeArguments: <OpacityLayer>
    //     0xf3b294: ldr             x1, [x1, #0xbe0]
    // 0xf3b298: r0 = LayerHandle()
    //     0xf3b298: bl              #0x89d118  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0xf3b29c: ldur            x2, [fp, #-8]
    // 0xf3b2a0: StoreField: r2->field_37 = r0
    //     0xf3b2a0: stur            w0, [x2, #0x37]
    //     0xf3b2a4: ldurb           w16, [x2, #-1]
    //     0xf3b2a8: ldurb           w17, [x0, #-1]
    //     0xf3b2ac: and             x16, x17, x16, lsr #2
    //     0xf3b2b0: tst             x16, HEAP, lsr #32
    //     0xf3b2b4: b.eq            #0xf3b2bc
    //     0xf3b2b8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3b2bc: r1 = <TransformLayer>
    //     0xf3b2bc: add             x1, PP, #0x90, lsl #12  ; [pp+0x901b8] TypeArguments: <TransformLayer>
    //     0xf3b2c0: ldr             x1, [x1, #0x1b8]
    // 0xf3b2c4: r0 = LayerHandle()
    //     0xf3b2c4: bl              #0x89d118  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0xf3b2c8: ldur            x2, [fp, #-8]
    // 0xf3b2cc: StoreField: r2->field_3b = r0
    //     0xf3b2cc: stur            w0, [x2, #0x3b]
    //     0xf3b2d0: ldurb           w16, [x2, #-1]
    //     0xf3b2d4: ldurb           w17, [x0, #-1]
    //     0xf3b2d8: and             x16, x17, x16, lsr #2
    //     0xf3b2dc: tst             x16, HEAP, lsr #32
    //     0xf3b2e0: b.eq            #0xf3b2e8
    //     0xf3b2e4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3b2e8: ldur            x0, [fp, #-0x20]
    // 0xf3b2ec: StoreField: r2->field_23 = r0
    //     0xf3b2ec: stur            w0, [x2, #0x23]
    // 0xf3b2f0: ldur            x0, [fp, #-0x28]
    // 0xf3b2f4: StoreField: r2->field_27 = r0
    //     0xf3b2f4: stur            w0, [x2, #0x27]
    //     0xf3b2f8: ldurb           w16, [x2, #-1]
    //     0xf3b2fc: ldurb           w17, [x0, #-1]
    //     0xf3b300: and             x16, x17, x16, lsr #2
    //     0xf3b304: tst             x16, HEAP, lsr #32
    //     0xf3b308: b.eq            #0xf3b310
    //     0xf3b30c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3b310: ldur            x0, [fp, #-0x18]
    // 0xf3b314: StoreField: r2->field_2b = r0
    //     0xf3b314: stur            w0, [x2, #0x2b]
    //     0xf3b318: ldurb           w16, [x2, #-1]
    //     0xf3b31c: ldurb           w17, [x0, #-1]
    //     0xf3b320: and             x16, x17, x16, lsr #2
    //     0xf3b324: tst             x16, HEAP, lsr #32
    //     0xf3b328: b.eq            #0xf3b330
    //     0xf3b32c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3b330: ldur            x0, [fp, #-0x10]
    // 0xf3b334: StoreField: r2->field_2f = r0
    //     0xf3b334: stur            w0, [x2, #0x2f]
    //     0xf3b338: ldurb           w16, [x2, #-1]
    //     0xf3b33c: ldurb           w17, [x0, #-1]
    //     0xf3b340: and             x16, x17, x16, lsr #2
    //     0xf3b344: tst             x16, HEAP, lsr #32
    //     0xf3b348: b.eq            #0xf3b350
    //     0xf3b34c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3b350: StoreField: r2->field_7 = rZR
    //     0xf3b350: stur            xzr, [x2, #7]
    // 0xf3b354: StoreField: r2->field_13 = rZR
    //     0xf3b354: stur            xzr, [x2, #0x13]
    // 0xf3b358: StoreField: r2->field_1b = rZR
    //     0xf3b358: stur            xzr, [x2, #0x1b]
    // 0xf3b35c: r0 = LoadStaticField(0x45c)
    //     0xf3b35c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf3b360: ldr             x0, [x0, #0x8b8]
    // 0xf3b364: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3b368: cmp             w0, w16
    // 0xf3b36c: b.ne            #0xf3b378
    // 0xf3b370: r2 = _emptyListeners
    //     0xf3b370: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xf3b374: r0 = InitLateFinalStaticField()
    //     0xf3b374: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf3b378: ldur            x3, [fp, #-8]
    // 0xf3b37c: StoreField: r3->field_f = r0
    //     0xf3b37c: stur            w0, [x3, #0xf]
    //     0xf3b380: ldurb           w16, [x3, #-1]
    //     0xf3b384: ldurb           w17, [x0, #-1]
    //     0xf3b388: and             x16, x17, x16, lsr #2
    //     0xf3b38c: tst             x16, HEAP, lsr #32
    //     0xf3b390: b.eq            #0xf3b398
    //     0xf3b394: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf3b398: mov             x2, x3
    // 0xf3b39c: r1 = Function 'notifyListeners':.
    //     0xf3b39c: ldr             x1, [PP, #0x2108]  ; [pp+0x2108] AnonymousClosure: (0x834128), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x833be0)
    // 0xf3b3a0: r0 = AllocateClosure()
    //     0xf3b3a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf3b3a4: ldur            x1, [fp, #-0x28]
    // 0xf3b3a8: mov             x2, x0
    // 0xf3b3ac: stur            x0, [fp, #-0x20]
    // 0xf3b3b0: r0 = addListener()
    //     0xf3b3b0: bl              #0xd04650  ; [dart:mixin_deduplication] _MixinApplication461&Animation&AnimationWithParentMixin::addListener
    // 0xf3b3b4: ldur            x1, [fp, #-0x18]
    // 0xf3b3b8: r0 = LoadClassIdInstr(r1)
    //     0xf3b3b8: ldur            x0, [x1, #-1]
    //     0xf3b3bc: ubfx            x0, x0, #0xc, #0x14
    // 0xf3b3c0: ldur            x2, [fp, #-0x20]
    // 0xf3b3c4: r0 = GDT[cid_x0 + 0xe0ec]()
    //     0xf3b3c4: mov             x17, #0xe0ec
    //     0xf3b3c8: add             lr, x0, x17
    //     0xf3b3cc: ldr             lr, [x21, lr, lsl #3]
    //     0xf3b3d0: blr             lr
    // 0xf3b3d4: ldur            x2, [fp, #-8]
    // 0xf3b3d8: r1 = Function '_onStatusChange@110490068':.
    //     0xf3b3d8: add             x1, PP, #0xad, lsl #12  ; [pp+0xadc68] AnonymousClosure: (0xf3a720), of [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionPainter
    //     0xf3b3dc: ldr             x1, [x1, #0xc68]
    // 0xf3b3e0: r0 = AllocateClosure()
    //     0xf3b3e0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf3b3e4: ldur            x1, [fp, #-0x10]
    // 0xf3b3e8: r2 = LoadClassIdInstr(r1)
    //     0xf3b3e8: ldur            x2, [x1, #-1]
    //     0xf3b3ec: ubfx            x2, x2, #0xc, #0x14
    // 0xf3b3f0: mov             x16, x0
    // 0xf3b3f4: mov             x0, x2
    // 0xf3b3f8: mov             x2, x16
    // 0xf3b3fc: r0 = GDT[cid_x0 + 0xbeb]()
    //     0xf3b3fc: add             lr, x0, #0xbeb
    //     0xf3b400: ldr             lr, [x21, lr, lsl #3]
    //     0xf3b404: blr             lr
    // 0xf3b408: r0 = Null
    //     0xf3b408: mov             x0, NULL
    // 0xf3b40c: LeaveFrame
    //     0xf3b40c: mov             SP, fp
    //     0xf3b410: ldp             fp, lr, [SP], #0x10
    // 0xf3b414: ret
    //     0xf3b414: ret             
    // 0xf3b418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3b418: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3b41c: b               #0xf3b254
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10ef3b0, size: 0xfc
    // 0x10ef3b0: EnterFrame
    //     0x10ef3b0: stp             fp, lr, [SP, #-0x10]!
    //     0x10ef3b4: mov             fp, SP
    // 0x10ef3b8: AllocStack(0x10)
    //     0x10ef3b8: sub             SP, SP, #0x10
    // 0x10ef3bc: SetupParameters(_ZoomExitTransitionPainter this /* r1 => r0, fp-0x8 */)
    //     0x10ef3bc: mov             x0, x1
    //     0x10ef3c0: stur            x1, [fp, #-8]
    // 0x10ef3c4: CheckStackOverflow
    //     0x10ef3c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ef3c8: cmp             SP, x16
    //     0x10ef3cc: b.ls            #0x10ef4a4
    // 0x10ef3d0: LoadField: r1 = r0->field_37
    //     0x10ef3d0: ldur            w1, [x0, #0x37]
    // 0x10ef3d4: DecompressPointer r1
    //     0x10ef3d4: add             x1, x1, HEAP, lsl #32
    // 0x10ef3d8: r2 = Null
    //     0x10ef3d8: mov             x2, NULL
    // 0x10ef3dc: r0 = layer=()
    //     0x10ef3dc: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x10ef3e0: ldur            x0, [fp, #-8]
    // 0x10ef3e4: LoadField: r1 = r0->field_3b
    //     0x10ef3e4: ldur            w1, [x0, #0x3b]
    // 0x10ef3e8: DecompressPointer r1
    //     0x10ef3e8: add             x1, x1, HEAP, lsl #32
    // 0x10ef3ec: r2 = Null
    //     0x10ef3ec: mov             x2, NULL
    // 0x10ef3f0: r0 = layer=()
    //     0x10ef3f0: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x10ef3f4: ldur            x0, [fp, #-8]
    // 0x10ef3f8: LoadField: r3 = r0->field_27
    //     0x10ef3f8: ldur            w3, [x0, #0x27]
    // 0x10ef3fc: DecompressPointer r3
    //     0x10ef3fc: add             x3, x3, HEAP, lsl #32
    // 0x10ef400: mov             x2, x0
    // 0x10ef404: stur            x3, [fp, #-0x10]
    // 0x10ef408: r1 = Function 'notifyListeners':.
    //     0x10ef408: ldr             x1, [PP, #0x2108]  ; [pp+0x2108] AnonymousClosure: (0x834128), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x833be0)
    // 0x10ef40c: r0 = AllocateClosure()
    //     0x10ef40c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10ef410: ldur            x1, [fp, #-0x10]
    // 0x10ef414: mov             x2, x0
    // 0x10ef418: stur            x0, [fp, #-0x10]
    // 0x10ef41c: r0 = removeListener()
    //     0x10ef41c: bl              #0xd011dc  ; [dart:mixin_deduplication] _MixinApplication461&Animation&AnimationWithParentMixin::removeListener
    // 0x10ef420: ldur            x3, [fp, #-8]
    // 0x10ef424: LoadField: r1 = r3->field_2b
    //     0x10ef424: ldur            w1, [x3, #0x2b]
    // 0x10ef428: DecompressPointer r1
    //     0x10ef428: add             x1, x1, HEAP, lsl #32
    // 0x10ef42c: r0 = LoadClassIdInstr(r1)
    //     0x10ef42c: ldur            x0, [x1, #-1]
    //     0x10ef430: ubfx            x0, x0, #0xc, #0x14
    // 0x10ef434: ldur            x2, [fp, #-0x10]
    // 0x10ef438: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0x10ef438: mov             x17, #0xe2a3
    //     0x10ef43c: add             lr, x0, x17
    //     0x10ef440: ldr             lr, [x21, lr, lsl #3]
    //     0x10ef444: blr             lr
    // 0x10ef448: ldur            x0, [fp, #-8]
    // 0x10ef44c: LoadField: r3 = r0->field_2f
    //     0x10ef44c: ldur            w3, [x0, #0x2f]
    // 0x10ef450: DecompressPointer r3
    //     0x10ef450: add             x3, x3, HEAP, lsl #32
    // 0x10ef454: mov             x2, x0
    // 0x10ef458: stur            x3, [fp, #-0x10]
    // 0x10ef45c: r1 = Function '_onStatusChange@110490068':.
    //     0x10ef45c: add             x1, PP, #0xad, lsl #12  ; [pp+0xadc68] AnonymousClosure: (0xf3a720), of [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionPainter
    //     0x10ef460: ldr             x1, [x1, #0xc68]
    // 0x10ef464: r0 = AllocateClosure()
    //     0x10ef464: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10ef468: ldur            x1, [fp, #-0x10]
    // 0x10ef46c: r2 = LoadClassIdInstr(r1)
    //     0x10ef46c: ldur            x2, [x1, #-1]
    //     0x10ef470: ubfx            x2, x2, #0xc, #0x14
    // 0x10ef474: mov             x16, x0
    // 0x10ef478: mov             x0, x2
    // 0x10ef47c: mov             x2, x16
    // 0x10ef480: r0 = GDT[cid_x0 + 0xabe]()
    //     0x10ef480: add             lr, x0, #0xabe
    //     0x10ef484: ldr             lr, [x21, lr, lsl #3]
    //     0x10ef488: blr             lr
    // 0x10ef48c: ldur            x1, [fp, #-8]
    // 0x10ef490: r0 = dispose()
    //     0x10ef490: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0x10ef494: r0 = Null
    //     0x10ef494: mov             x0, NULL
    // 0x10ef498: LeaveFrame
    //     0x10ef498: mov             SP, fp
    //     0x10ef49c: ldp             fp, lr, [SP], #0x10
    // 0x10ef4a0: ret
    //     0x10ef4a0: ret             
    // 0x10ef4a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ef4a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ef4a8: b               #0x10ef3d0
  }
  _ paintSnapshot(/* No info */) {
    // ** addr: 0x121af4c, size: 0xd4
    // 0x121af4c: EnterFrame
    //     0x121af4c: stp             fp, lr, [SP, #-0x10]!
    //     0x121af50: mov             fp, SP
    // 0x121af54: AllocStack(0x28)
    //     0x121af54: sub             SP, SP, #0x28
    // 0x121af58: SetupParameters(_ZoomExitTransitionPainter this /* r1 => r6, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r0 */, dynamic _ /* r6 => r3, fp-0x18 */, dynamic _ /* d0 => d2, fp-0x28 */)
    //     0x121af58: mov             x0, x3
    //     0x121af5c: mov             x3, x6
    //     0x121af60: stur            x6, [fp, #-0x18]
    //     0x121af64: mov             x6, x1
    //     0x121af68: mov             x4, x2
    //     0x121af6c: mov             v2.16b, v0.16b
    //     0x121af70: stur            x1, [fp, #-8]
    //     0x121af74: stur            x2, [fp, #-0x10]
    //     0x121af78: stur            d0, [fp, #-0x28]
    // 0x121af7c: CheckStackOverflow
    //     0x121af7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121af80: cmp             SP, x16
    //     0x121af84: b.ls            #0x121b018
    // 0x121af88: LoadField: r0 = r6->field_27
    //     0x121af88: ldur            w0, [x6, #0x27]
    // 0x121af8c: DecompressPointer r0
    //     0x121af8c: add             x0, x0, HEAP, lsl #32
    // 0x121af90: LoadField: r1 = r0->field_f
    //     0x121af90: ldur            w1, [x0, #0xf]
    // 0x121af94: DecompressPointer r1
    //     0x121af94: add             x1, x1, HEAP, lsl #32
    // 0x121af98: LoadField: r2 = r0->field_b
    //     0x121af98: ldur            w2, [x0, #0xb]
    // 0x121af9c: DecompressPointer r2
    //     0x121af9c: add             x2, x2, HEAP, lsl #32
    // 0x121afa0: r0 = LoadClassIdInstr(r1)
    //     0x121afa0: ldur            x0, [x1, #-1]
    //     0x121afa4: ubfx            x0, x0, #0xc, #0x14
    // 0x121afa8: r0 = GDT[cid_x0 + 0x80ed]()
    //     0x121afa8: mov             x17, #0x80ed
    //     0x121afac: add             lr, x0, x17
    //     0x121afb0: ldr             lr, [x21, lr, lsl #3]
    //     0x121afb4: blr             lr
    // 0x121afb8: mov             x2, x0
    // 0x121afbc: ldur            x0, [fp, #-8]
    // 0x121afc0: stur            x2, [fp, #-0x20]
    // 0x121afc4: LoadField: r1 = r0->field_2b
    //     0x121afc4: ldur            w1, [x0, #0x2b]
    // 0x121afc8: DecompressPointer r1
    //     0x121afc8: add             x1, x1, HEAP, lsl #32
    // 0x121afcc: r0 = LoadClassIdInstr(r1)
    //     0x121afcc: ldur            x0, [x1, #-1]
    //     0x121afd0: ubfx            x0, x0, #0xc, #0x14
    // 0x121afd4: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x121afd4: mov             x17, #0x4e2e
    //     0x121afd8: movk            x17, #1, lsl #16
    //     0x121afdc: add             lr, x0, x17
    //     0x121afe0: ldr             lr, [x21, lr, lsl #3]
    //     0x121afe4: blr             lr
    // 0x121afe8: mov             x1, x0
    // 0x121afec: ldur            x0, [fp, #-0x20]
    // 0x121aff0: LoadField: d0 = r0->field_7
    //     0x121aff0: ldur            d0, [x0, #7]
    // 0x121aff4: LoadField: d1 = r1->field_7
    //     0x121aff4: ldur            d1, [x1, #7]
    // 0x121aff8: ldur            x1, [fp, #-0x10]
    // 0x121affc: ldur            x2, [fp, #-0x18]
    // 0x121b000: ldur            d2, [fp, #-0x28]
    // 0x121b004: r0 = _drawImageScaledAndCentered()
    //     0x121b004: bl              #0x121ab64  ; [package:flutter/src/material/page_transitions_theme.dart] ::_drawImageScaledAndCentered
    // 0x121b008: r0 = Null
    //     0x121b008: mov             x0, NULL
    // 0x121b00c: LeaveFrame
    //     0x121b00c: mov             SP, fp
    //     0x121b010: ldp             fp, lr, [SP], #0x10
    // 0x121b014: ret
    //     0x121b014: ret             
    // 0x121b018: r0 = StackOverflowSharedWithFPURegs()
    //     0x121b018: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x121b01c: b               #0x121af88
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0x1224f14, size: 0x1b8
    // 0x1224f14: EnterFrame
    //     0x1224f14: stp             fp, lr, [SP, #-0x10]!
    //     0x1224f18: mov             fp, SP
    // 0x1224f1c: AllocStack(0x18)
    //     0x1224f1c: sub             SP, SP, #0x18
    // 0x1224f20: SetupParameters(_ZoomExitTransitionPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x1224f20: mov             x4, x1
    //     0x1224f24: mov             x3, x2
    //     0x1224f28: stur            x1, [fp, #-8]
    //     0x1224f2c: stur            x2, [fp, #-0x10]
    // 0x1224f30: CheckStackOverflow
    //     0x1224f30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1224f34: cmp             SP, x16
    //     0x1224f38: b.ls            #0x12250c4
    // 0x1224f3c: mov             x0, x3
    // 0x1224f40: r2 = Null
    //     0x1224f40: mov             x2, NULL
    // 0x1224f44: r1 = Null
    //     0x1224f44: mov             x1, NULL
    // 0x1224f48: r4 = 60
    //     0x1224f48: mov             x4, #0x3c
    // 0x1224f4c: branchIfSmi(r0, 0x1224f58)
    //     0x1224f4c: tbz             w0, #0, #0x1224f58
    // 0x1224f50: r4 = LoadClassIdInstr(r0)
    //     0x1224f50: ldur            x4, [x0, #-1]
    //     0x1224f54: ubfx            x4, x4, #0xc, #0x14
    // 0x1224f58: r17 = 4492
    //     0x1224f58: mov             x17, #0x118c
    // 0x1224f5c: cmp             x4, x17
    // 0x1224f60: b.eq            #0x1224f78
    // 0x1224f64: r8 = _ZoomExitTransitionPainter
    //     0x1224f64: add             x8, PP, #0xd0, lsl #12  ; [pp+0xd04c8] Type: _ZoomExitTransitionPainter
    //     0x1224f68: ldr             x8, [x8, #0x4c8]
    // 0x1224f6c: r3 = Null
    //     0x1224f6c: add             x3, PP, #0xd0, lsl #12  ; [pp+0xd04d0] Null
    //     0x1224f70: ldr             x3, [x3, #0x4d0]
    // 0x1224f74: r0 = DefaultTypeTest()
    //     0x1224f74: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x1224f78: ldur            x2, [fp, #-0x10]
    // 0x1224f7c: LoadField: r0 = r2->field_23
    //     0x1224f7c: ldur            w0, [x2, #0x23]
    // 0x1224f80: DecompressPointer r0
    //     0x1224f80: add             x0, x0, HEAP, lsl #32
    // 0x1224f84: ldur            x3, [fp, #-8]
    // 0x1224f88: LoadField: r1 = r3->field_23
    //     0x1224f88: ldur            w1, [x3, #0x23]
    // 0x1224f8c: DecompressPointer r1
    //     0x1224f8c: add             x1, x1, HEAP, lsl #32
    // 0x1224f90: cmp             w0, w1
    // 0x1224f94: b.ne            #0x1225004
    // 0x1224f98: LoadField: r1 = r2->field_2b
    //     0x1224f98: ldur            w1, [x2, #0x2b]
    // 0x1224f9c: DecompressPointer r1
    //     0x1224f9c: add             x1, x1, HEAP, lsl #32
    // 0x1224fa0: r0 = LoadClassIdInstr(r1)
    //     0x1224fa0: ldur            x0, [x1, #-1]
    //     0x1224fa4: ubfx            x0, x0, #0xc, #0x14
    // 0x1224fa8: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x1224fa8: mov             x17, #0x4e2e
    //     0x1224fac: movk            x17, #1, lsl #16
    //     0x1224fb0: add             lr, x0, x17
    //     0x1224fb4: ldr             lr, [x21, lr, lsl #3]
    //     0x1224fb8: blr             lr
    // 0x1224fbc: mov             x3, x0
    // 0x1224fc0: ldur            x2, [fp, #-8]
    // 0x1224fc4: stur            x3, [fp, #-0x18]
    // 0x1224fc8: LoadField: r1 = r2->field_2b
    //     0x1224fc8: ldur            w1, [x2, #0x2b]
    // 0x1224fcc: DecompressPointer r1
    //     0x1224fcc: add             x1, x1, HEAP, lsl #32
    // 0x1224fd0: r0 = LoadClassIdInstr(r1)
    //     0x1224fd0: ldur            x0, [x1, #-1]
    //     0x1224fd4: ubfx            x0, x0, #0xc, #0x14
    // 0x1224fd8: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x1224fd8: mov             x17, #0x4e2e
    //     0x1224fdc: movk            x17, #1, lsl #16
    //     0x1224fe0: add             lr, x0, x17
    //     0x1224fe4: ldr             lr, [x21, lr, lsl #3]
    //     0x1224fe8: blr             lr
    // 0x1224fec: mov             x1, x0
    // 0x1224ff0: ldur            x0, [fp, #-0x18]
    // 0x1224ff4: LoadField: d0 = r0->field_7
    //     0x1224ff4: ldur            d0, [x0, #7]
    // 0x1224ff8: LoadField: d1 = r1->field_7
    //     0x1224ff8: ldur            d1, [x1, #7]
    // 0x1224ffc: fcmp            d0, d1
    // 0x1225000: b.eq            #0x122500c
    // 0x1225004: r0 = true
    //     0x1225004: add             x0, NULL, #0x20  ; true
    // 0x1225008: b               #0x12250b8
    // 0x122500c: ldur            x3, [fp, #-8]
    // 0x1225010: ldur            x0, [fp, #-0x10]
    // 0x1225014: LoadField: r1 = r0->field_27
    //     0x1225014: ldur            w1, [x0, #0x27]
    // 0x1225018: DecompressPointer r1
    //     0x1225018: add             x1, x1, HEAP, lsl #32
    // 0x122501c: LoadField: r0 = r1->field_f
    //     0x122501c: ldur            w0, [x1, #0xf]
    // 0x1225020: DecompressPointer r0
    //     0x1225020: add             x0, x0, HEAP, lsl #32
    // 0x1225024: LoadField: r2 = r1->field_b
    //     0x1225024: ldur            w2, [x1, #0xb]
    // 0x1225028: DecompressPointer r2
    //     0x1225028: add             x2, x2, HEAP, lsl #32
    // 0x122502c: r1 = LoadClassIdInstr(r0)
    //     0x122502c: ldur            x1, [x0, #-1]
    //     0x1225030: ubfx            x1, x1, #0xc, #0x14
    // 0x1225034: mov             x16, x0
    // 0x1225038: mov             x0, x1
    // 0x122503c: mov             x1, x16
    // 0x1225040: r0 = GDT[cid_x0 + 0x80ed]()
    //     0x1225040: mov             x17, #0x80ed
    //     0x1225044: add             lr, x0, x17
    //     0x1225048: ldr             lr, [x21, lr, lsl #3]
    //     0x122504c: blr             lr
    // 0x1225050: mov             x3, x0
    // 0x1225054: ldur            x0, [fp, #-8]
    // 0x1225058: stur            x3, [fp, #-0x10]
    // 0x122505c: LoadField: r1 = r0->field_27
    //     0x122505c: ldur            w1, [x0, #0x27]
    // 0x1225060: DecompressPointer r1
    //     0x1225060: add             x1, x1, HEAP, lsl #32
    // 0x1225064: LoadField: r0 = r1->field_f
    //     0x1225064: ldur            w0, [x1, #0xf]
    // 0x1225068: DecompressPointer r0
    //     0x1225068: add             x0, x0, HEAP, lsl #32
    // 0x122506c: LoadField: r2 = r1->field_b
    //     0x122506c: ldur            w2, [x1, #0xb]
    // 0x1225070: DecompressPointer r2
    //     0x1225070: add             x2, x2, HEAP, lsl #32
    // 0x1225074: r1 = LoadClassIdInstr(r0)
    //     0x1225074: ldur            x1, [x0, #-1]
    //     0x1225078: ubfx            x1, x1, #0xc, #0x14
    // 0x122507c: mov             x16, x0
    // 0x1225080: mov             x0, x1
    // 0x1225084: mov             x1, x16
    // 0x1225088: r0 = GDT[cid_x0 + 0x80ed]()
    //     0x1225088: mov             x17, #0x80ed
    //     0x122508c: add             lr, x0, x17
    //     0x1225090: ldr             lr, [x21, lr, lsl #3]
    //     0x1225094: blr             lr
    // 0x1225098: ldur            x1, [fp, #-0x10]
    // 0x122509c: LoadField: d0 = r1->field_7
    //     0x122509c: ldur            d0, [x1, #7]
    // 0x12250a0: LoadField: d1 = r0->field_7
    //     0x12250a0: ldur            d1, [x0, #7]
    // 0x12250a4: fcmp            d0, d1
    // 0x12250a8: r16 = true
    //     0x12250a8: add             x16, NULL, #0x20  ; true
    // 0x12250ac: r17 = false
    //     0x12250ac: add             x17, NULL, #0x30  ; false
    // 0x12250b0: csel            x1, x16, x17, ne
    // 0x12250b4: mov             x0, x1
    // 0x12250b8: LeaveFrame
    //     0x12250b8: mov             SP, fp
    //     0x12250bc: ldp             fp, lr, [SP], #0x10
    // 0x12250c0: ret
    //     0x12250c0: ret             
    // 0x12250c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12250c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12250c8: b               #0x1224f3c
  }
  _ paint(/* No info */) {
    // ** addr: 0x12824fc, size: 0x16c
    // 0x12824fc: EnterFrame
    //     0x12824fc: stp             fp, lr, [SP, #-0x10]!
    //     0x1282500: mov             fp, SP
    // 0x1282504: AllocStack(0x30)
    //     0x1282504: sub             SP, SP, #0x30
    // 0x1282508: SetupParameters(_ZoomExitTransitionPainter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r2, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */)
    //     0x1282508: mov             x0, x2
    //     0x128250c: stur            x2, [fp, #-0x10]
    //     0x1282510: mov             x2, x5
    //     0x1282514: stur            x1, [fp, #-8]
    //     0x1282518: stur            x3, [fp, #-0x18]
    //     0x128251c: stur            x5, [fp, #-0x20]
    //     0x1282520: stur            x6, [fp, #-0x28]
    // 0x1282524: CheckStackOverflow
    //     0x1282524: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1282528: cmp             SP, x16
    //     0x128252c: b.ls            #0x1282660
    // 0x1282530: r1 = 2
    //     0x1282530: mov             x1, #2
    // 0x1282534: r0 = AllocateContext()
    //     0x1282534: bl              #0x13de838  ; AllocateContextStub
    // 0x1282538: mov             x3, x0
    // 0x128253c: ldur            x2, [fp, #-8]
    // 0x1282540: stur            x3, [fp, #-0x30]
    // 0x1282544: StoreField: r3->field_f = r2
    //     0x1282544: stur            w2, [x3, #0xf]
    // 0x1282548: ldur            x0, [fp, #-0x28]
    // 0x128254c: StoreField: r3->field_13 = r0
    //     0x128254c: stur            w0, [x3, #0x13]
    // 0x1282550: LoadField: r1 = r2->field_2f
    //     0x1282550: ldur            w1, [x2, #0x2f]
    // 0x1282554: DecompressPointer r1
    //     0x1282554: add             x1, x1, HEAP, lsl #32
    // 0x1282558: r0 = LoadClassIdInstr(r1)
    //     0x1282558: ldur            x0, [x1, #-1]
    //     0x128255c: ubfx            x0, x0, #0xc, #0x14
    // 0x1282560: r0 = GDT[cid_x0 + 0x12d66]()
    //     0x1282560: mov             x17, #0x2d66
    //     0x1282564: movk            x17, #1, lsl #16
    //     0x1282568: add             lr, x0, x17
    //     0x128256c: ldr             lr, [x21, lr, lsl #3]
    //     0x1282570: blr             lr
    // 0x1282574: tbz             w0, #4, #0x12825a8
    // 0x1282578: ldur            x3, [fp, #-0x30]
    // 0x128257c: LoadField: r0 = r3->field_13
    //     0x128257c: ldur            w0, [x3, #0x13]
    // 0x1282580: DecompressPointer r0
    //     0x1282580: add             x0, x0, HEAP, lsl #32
    // 0x1282584: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1282584: ldur            w1, [x0, #0x17]
    // 0x1282588: DecompressPointer r1
    //     0x1282588: add             x1, x1, HEAP, lsl #32
    // 0x128258c: ldur            x2, [fp, #-0x10]
    // 0x1282590: ldur            x3, [fp, #-0x18]
    // 0x1282594: r0 = paint()
    //     0x1282594: bl              #0xc1faf0  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint
    // 0x1282598: r0 = Null
    //     0x1282598: mov             x0, NULL
    // 0x128259c: LeaveFrame
    //     0x128259c: mov             SP, fp
    //     0x12825a0: ldp             fp, lr, [SP], #0x10
    // 0x12825a4: ret
    //     0x12825a4: ret             
    // 0x12825a8: ldur            x4, [fp, #-8]
    // 0x12825ac: ldur            x3, [fp, #-0x30]
    // 0x12825b0: LoadField: r5 = r4->field_33
    //     0x12825b0: ldur            w5, [x4, #0x33]
    // 0x12825b4: DecompressPointer r5
    //     0x12825b4: add             x5, x5, HEAP, lsl #32
    // 0x12825b8: stur            x5, [fp, #-0x28]
    // 0x12825bc: LoadField: r0 = r4->field_27
    //     0x12825bc: ldur            w0, [x4, #0x27]
    // 0x12825c0: DecompressPointer r0
    //     0x12825c0: add             x0, x0, HEAP, lsl #32
    // 0x12825c4: LoadField: r1 = r0->field_f
    //     0x12825c4: ldur            w1, [x0, #0xf]
    // 0x12825c8: DecompressPointer r1
    //     0x12825c8: add             x1, x1, HEAP, lsl #32
    // 0x12825cc: LoadField: r2 = r0->field_b
    //     0x12825cc: ldur            w2, [x0, #0xb]
    // 0x12825d0: DecompressPointer r2
    //     0x12825d0: add             x2, x2, HEAP, lsl #32
    // 0x12825d4: r0 = LoadClassIdInstr(r1)
    //     0x12825d4: ldur            x0, [x1, #-1]
    //     0x12825d8: ubfx            x0, x0, #0xc, #0x14
    // 0x12825dc: r0 = GDT[cid_x0 + 0x80ed]()
    //     0x12825dc: mov             x17, #0x80ed
    //     0x12825e0: add             lr, x0, x17
    //     0x12825e4: ldr             lr, [x21, lr, lsl #3]
    //     0x12825e8: blr             lr
    // 0x12825ec: LoadField: d0 = r0->field_7
    //     0x12825ec: ldur            d0, [x0, #7]
    // 0x12825f0: ldur            x1, [fp, #-0x28]
    // 0x12825f4: ldur            x2, [fp, #-0x20]
    // 0x12825f8: r0 = _updateScaledTransform()
    //     0x12825f8: bl              #0x1282240  ; [package:flutter/src/material/page_transitions_theme.dart] ::_updateScaledTransform
    // 0x12825fc: ldur            x0, [fp, #-8]
    // 0x1282600: LoadField: r3 = r0->field_3b
    //     0x1282600: ldur            w3, [x0, #0x3b]
    // 0x1282604: DecompressPointer r3
    //     0x1282604: add             x3, x3, HEAP, lsl #32
    // 0x1282608: stur            x3, [fp, #-0x20]
    // 0x128260c: LoadField: r7 = r3->field_b
    //     0x128260c: ldur            w7, [x3, #0xb]
    // 0x1282610: DecompressPointer r7
    //     0x1282610: add             x7, x7, HEAP, lsl #32
    // 0x1282614: ldur            x2, [fp, #-0x30]
    // 0x1282618: stur            x7, [fp, #-8]
    // 0x128261c: r1 = Function '<anonymous closure>':.
    //     0x128261c: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1dc0] AnonymousClosure: (0x1282668), in [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionPainter::paint (0x12824fc)
    //     0x1282620: ldr             x1, [x1, #0xdc0]
    // 0x1282624: r0 = AllocateClosure()
    //     0x1282624: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1282628: ldur            x1, [fp, #-0x10]
    // 0x128262c: ldur            x3, [fp, #-0x18]
    // 0x1282630: ldur            x5, [fp, #-0x28]
    // 0x1282634: mov             x6, x0
    // 0x1282638: ldur            x7, [fp, #-8]
    // 0x128263c: r2 = true
    //     0x128263c: add             x2, NULL, #0x20  ; true
    // 0x1282640: r0 = pushTransform()
    //     0x1282640: bl              #0xc1c818  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushTransform
    // 0x1282644: ldur            x1, [fp, #-0x20]
    // 0x1282648: mov             x2, x0
    // 0x128264c: r0 = layer=()
    //     0x128264c: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x1282650: r0 = Null
    //     0x1282650: mov             x0, NULL
    // 0x1282654: LeaveFrame
    //     0x1282654: mov             SP, fp
    //     0x1282658: ldp             fp, lr, [SP], #0x10
    // 0x128265c: ret
    //     0x128265c: ret             
    // 0x1282660: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1282660: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1282664: b               #0x1282530
  }
  [closure] void <anonymous closure>(dynamic, PaintingContext, Offset) {
    // ** addr: 0x1282668, size: 0x13c
    // 0x1282668: EnterFrame
    //     0x1282668: stp             fp, lr, [SP, #-0x10]!
    //     0x128266c: mov             fp, SP
    // 0x1282670: AllocStack(0x10)
    //     0x1282670: sub             SP, SP, #0x10
    // 0x1282674: SetupParameters([dynamic _ /* r0 */])
    //     0x1282674: ldr             x0, [fp, #0x20]
    //     0x1282678: ldur            w2, [x0, #0x17]
    //     0x128267c: add             x2, x2, HEAP, lsl #32
    //     0x1282680: stur            x2, [fp, #-0x10]
    // 0x1282684: CheckStackOverflow
    //     0x1282684: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1282688: cmp             SP, x16
    //     0x128268c: b.ls            #0x1282780
    // 0x1282690: LoadField: r0 = r2->field_f
    //     0x1282690: ldur            w0, [x2, #0xf]
    // 0x1282694: DecompressPointer r0
    //     0x1282694: add             x0, x0, HEAP, lsl #32
    // 0x1282698: LoadField: r3 = r0->field_37
    //     0x1282698: ldur            w3, [x0, #0x37]
    // 0x128269c: DecompressPointer r3
    //     0x128269c: add             x3, x3, HEAP, lsl #32
    // 0x12826a0: stur            x3, [fp, #-8]
    // 0x12826a4: LoadField: r1 = r0->field_2b
    //     0x12826a4: ldur            w1, [x0, #0x2b]
    // 0x12826a8: DecompressPointer r1
    //     0x12826a8: add             x1, x1, HEAP, lsl #32
    // 0x12826ac: r0 = LoadClassIdInstr(r1)
    //     0x12826ac: ldur            x0, [x1, #-1]
    //     0x12826b0: ubfx            x0, x0, #0xc, #0x14
    // 0x12826b4: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x12826b4: mov             x17, #0x4e2e
    //     0x12826b8: movk            x17, #1, lsl #16
    //     0x12826bc: add             lr, x0, x17
    //     0x12826c0: ldr             lr, [x21, lr, lsl #3]
    //     0x12826c4: blr             lr
    // 0x12826c8: LoadField: d0 = r0->field_7
    //     0x12826c8: ldur            d0, [x0, #7]
    // 0x12826cc: d1 = 255.000000
    //     0x12826cc: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x12826d0: fmul            d2, d0, d1
    // 0x12826d4: mov             v0.16b, v2.16b
    // 0x12826d8: stp             fp, lr, [SP, #-0x10]!
    // 0x12826dc: mov             fp, SP
    // 0x12826e0: CallRuntime_LibcRound(double) -> double
    //     0x12826e0: and             SP, SP, #0xfffffffffffffff0
    //     0x12826e4: mov             sp, SP
    //     0x12826e8: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0x12826ec: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12826f0: blr             x16
    //     0x12826f4: mov             x16, #8
    //     0x12826f8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12826fc: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x1282700: sub             sp, x16, #1, lsl #12
    //     0x1282704: mov             SP, fp
    //     0x1282708: ldp             fp, lr, [SP], #0x10
    // 0x128270c: fcmp            d0, d0
    // 0x1282710: b.vs            #0x1282788
    // 0x1282714: fcvtzs          x0, d0
    // 0x1282718: asr             x16, x0, #0x1e
    // 0x128271c: cmp             x16, x0, asr #63
    // 0x1282720: b.ne            #0x1282788
    // 0x1282724: lsl             x0, x0, #1
    // 0x1282728: ldur            x1, [fp, #-0x10]
    // 0x128272c: LoadField: r5 = r1->field_13
    //     0x128272c: ldur            w5, [x1, #0x13]
    // 0x1282730: DecompressPointer r5
    //     0x1282730: add             x5, x5, HEAP, lsl #32
    // 0x1282734: LoadField: r2 = r1->field_f
    //     0x1282734: ldur            w2, [x1, #0xf]
    // 0x1282738: DecompressPointer r2
    //     0x1282738: add             x2, x2, HEAP, lsl #32
    // 0x128273c: LoadField: r1 = r2->field_37
    //     0x128273c: ldur            w1, [x2, #0x37]
    // 0x1282740: DecompressPointer r1
    //     0x1282740: add             x1, x1, HEAP, lsl #32
    // 0x1282744: LoadField: r6 = r1->field_b
    //     0x1282744: ldur            w6, [x1, #0xb]
    // 0x1282748: DecompressPointer r6
    //     0x1282748: add             x6, x6, HEAP, lsl #32
    // 0x128274c: r3 = LoadInt32Instr(r0)
    //     0x128274c: sbfx            x3, x0, #1, #0x1f
    //     0x1282750: tbz             w0, #0, #0x1282758
    //     0x1282754: ldur            x3, [x0, #7]
    // 0x1282758: ldr             x1, [fp, #0x18]
    // 0x128275c: ldr             x2, [fp, #0x10]
    // 0x1282760: r0 = pushOpacity()
    //     0x1282760: bl              #0x128243c  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushOpacity
    // 0x1282764: ldur            x1, [fp, #-8]
    // 0x1282768: mov             x2, x0
    // 0x128276c: r0 = layer=()
    //     0x128276c: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x1282770: r0 = Null
    //     0x1282770: mov             x0, NULL
    // 0x1282774: LeaveFrame
    //     0x1282774: mov             SP, fp
    //     0x1282778: ldp             fp, lr, [SP], #0x10
    // 0x128277c: ret
    //     0x128277c: ret             
    // 0x1282780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1282780: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1282784: b               #0x1282690
    // 0x1282788: SaveReg d0
    //     0x1282788: str             q0, [SP, #-0x10]!
    // 0x128278c: r0 = 76
    //     0x128278c: mov             x0, #0x4c
    // 0x1282790: r30 = DoubleToIntegerStub
    //     0x1282790: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0x1282794: LoadField: r30 = r30->field_7
    //     0x1282794: ldur            lr, [lr, #7]
    // 0x1282798: blr             lr
    // 0x128279c: RestoreReg d0
    //     0x128279c: ldr             q0, [SP], #0x10
    // 0x12827a0: b               #0x1282728
  }
}

// class id: 4493, size: 0x44, field offset: 0x24
class _ZoomEnterTransitionPainter extends SnapshotPainter {

  _ _ZoomEnterTransitionPainter(/* No info */) {
    // ** addr: 0xf3a4c4, size: 0x25c
    // 0xf3a4c4: EnterFrame
    //     0xf3a4c4: stp             fp, lr, [SP, #-0x10]!
    //     0xf3a4c8: mov             fp, SP
    // 0xf3a4cc: AllocStack(0x38)
    //     0xf3a4cc: sub             SP, SP, #0x38
    // 0xf3a4d0: SetupParameters(_ZoomEnterTransitionPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x20 */, dynamic _ /* r3 => r2, fp-0x30 */, [dynamic _ /* fp-0x28 */])
    //     0xf3a4d0: mov             x4, x1
    //     0xf3a4d4: stur            x2, [fp, #-0x10]
    //     0xf3a4d8: mov             x16, x3
    //     0xf3a4dc: mov             x3, x2
    //     0xf3a4e0: mov             x2, x16
    //     0xf3a4e4: stur            x1, [fp, #-8]
    //     0xf3a4e8: mov             x1, x5
    //     0xf3a4ec: mov             x0, x7
    //     0xf3a4f0: stur            x2, [fp, #-0x18]
    //     0xf3a4f4: stur            x5, [fp, #-0x20]
    //     0xf3a4f8: stur            x6, [fp, #-0x28]
    //     0xf3a4fc: stur            x7, [fp, #-0x30]
    // 0xf3a500: CheckStackOverflow
    //     0xf3a500: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3a504: cmp             SP, x16
    //     0xf3a508: b.ls            #0xf3a718
    // 0xf3a50c: r0 = Matrix4()
    //     0xf3a50c: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xf3a510: r4 = 32
    //     0xf3a510: mov             x4, #0x20
    // 0xf3a514: stur            x0, [fp, #-0x38]
    // 0xf3a518: r0 = AllocateFloat64Array()
    //     0xf3a518: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0xf3a51c: mov             x1, x0
    // 0xf3a520: ldur            x0, [fp, #-0x38]
    // 0xf3a524: StoreField: r0->field_7 = r1
    //     0xf3a524: stur            w1, [x0, #7]
    // 0xf3a528: ldur            x2, [fp, #-8]
    // 0xf3a52c: StoreField: r2->field_37 = r0
    //     0xf3a52c: stur            w0, [x2, #0x37]
    //     0xf3a530: ldurb           w16, [x2, #-1]
    //     0xf3a534: ldurb           w17, [x0, #-1]
    //     0xf3a538: and             x16, x17, x16, lsr #2
    //     0xf3a53c: tst             x16, HEAP, lsr #32
    //     0xf3a540: b.eq            #0xf3a548
    //     0xf3a544: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3a548: r1 = <OpacityLayer>
    //     0xf3a548: add             x1, PP, #0xad, lsl #12  ; [pp+0xadbe0] TypeArguments: <OpacityLayer>
    //     0xf3a54c: ldr             x1, [x1, #0xbe0]
    // 0xf3a550: r0 = LayerHandle()
    //     0xf3a550: bl              #0x89d118  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0xf3a554: ldur            x2, [fp, #-8]
    // 0xf3a558: StoreField: r2->field_3b = r0
    //     0xf3a558: stur            w0, [x2, #0x3b]
    //     0xf3a55c: ldurb           w16, [x2, #-1]
    //     0xf3a560: ldurb           w17, [x0, #-1]
    //     0xf3a564: and             x16, x17, x16, lsr #2
    //     0xf3a568: tst             x16, HEAP, lsr #32
    //     0xf3a56c: b.eq            #0xf3a574
    //     0xf3a570: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3a574: r1 = <TransformLayer>
    //     0xf3a574: add             x1, PP, #0x90, lsl #12  ; [pp+0x901b8] TypeArguments: <TransformLayer>
    //     0xf3a578: ldr             x1, [x1, #0x1b8]
    // 0xf3a57c: r0 = LayerHandle()
    //     0xf3a57c: bl              #0x89d118  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0xf3a580: ldur            x2, [fp, #-8]
    // 0xf3a584: StoreField: r2->field_3f = r0
    //     0xf3a584: stur            w0, [x2, #0x3f]
    //     0xf3a588: ldurb           w16, [x2, #-1]
    //     0xf3a58c: ldurb           w17, [x0, #-1]
    //     0xf3a590: and             x16, x17, x16, lsr #2
    //     0xf3a594: tst             x16, HEAP, lsr #32
    //     0xf3a598: b.eq            #0xf3a5a0
    //     0xf3a59c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3a5a0: ldur            x0, [fp, #-0x28]
    // 0xf3a5a4: StoreField: r2->field_23 = r0
    //     0xf3a5a4: stur            w0, [x2, #0x23]
    // 0xf3a5a8: ldur            x0, [fp, #-0x30]
    // 0xf3a5ac: StoreField: r2->field_2b = r0
    //     0xf3a5ac: stur            w0, [x2, #0x2b]
    //     0xf3a5b0: ldurb           w16, [x2, #-1]
    //     0xf3a5b4: ldurb           w17, [x0, #-1]
    //     0xf3a5b8: and             x16, x17, x16, lsr #2
    //     0xf3a5bc: tst             x16, HEAP, lsr #32
    //     0xf3a5c0: b.eq            #0xf3a5c8
    //     0xf3a5c4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3a5c8: ldur            x0, [fp, #-0x20]
    // 0xf3a5cc: StoreField: r2->field_2f = r0
    //     0xf3a5cc: stur            w0, [x2, #0x2f]
    //     0xf3a5d0: ldurb           w16, [x2, #-1]
    //     0xf3a5d4: ldurb           w17, [x0, #-1]
    //     0xf3a5d8: and             x16, x17, x16, lsr #2
    //     0xf3a5dc: tst             x16, HEAP, lsr #32
    //     0xf3a5e0: b.eq            #0xf3a5e8
    //     0xf3a5e4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3a5e8: ldur            x0, [fp, #-0x10]
    // 0xf3a5ec: StoreField: r2->field_27 = r0
    //     0xf3a5ec: stur            w0, [x2, #0x27]
    //     0xf3a5f0: ldurb           w16, [x2, #-1]
    //     0xf3a5f4: ldurb           w17, [x0, #-1]
    //     0xf3a5f8: and             x16, x17, x16, lsr #2
    //     0xf3a5fc: tst             x16, HEAP, lsr #32
    //     0xf3a600: b.eq            #0xf3a608
    //     0xf3a604: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3a608: ldur            x0, [fp, #-0x18]
    // 0xf3a60c: StoreField: r2->field_33 = r0
    //     0xf3a60c: stur            w0, [x2, #0x33]
    //     0xf3a610: ldurb           w16, [x2, #-1]
    //     0xf3a614: ldurb           w17, [x0, #-1]
    //     0xf3a618: and             x16, x17, x16, lsr #2
    //     0xf3a61c: tst             x16, HEAP, lsr #32
    //     0xf3a620: b.eq            #0xf3a628
    //     0xf3a624: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3a628: StoreField: r2->field_7 = rZR
    //     0xf3a628: stur            xzr, [x2, #7]
    // 0xf3a62c: StoreField: r2->field_13 = rZR
    //     0xf3a62c: stur            xzr, [x2, #0x13]
    // 0xf3a630: StoreField: r2->field_1b = rZR
    //     0xf3a630: stur            xzr, [x2, #0x1b]
    // 0xf3a634: r0 = LoadStaticField(0x45c)
    //     0xf3a634: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf3a638: ldr             x0, [x0, #0x8b8]
    // 0xf3a63c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3a640: cmp             w0, w16
    // 0xf3a644: b.ne            #0xf3a650
    // 0xf3a648: r2 = _emptyListeners
    //     0xf3a648: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xf3a64c: r0 = InitLateFinalStaticField()
    //     0xf3a64c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf3a650: ldur            x3, [fp, #-8]
    // 0xf3a654: StoreField: r3->field_f = r0
    //     0xf3a654: stur            w0, [x3, #0xf]
    //     0xf3a658: ldurb           w16, [x3, #-1]
    //     0xf3a65c: ldurb           w17, [x0, #-1]
    //     0xf3a660: and             x16, x17, x16, lsr #2
    //     0xf3a664: tst             x16, HEAP, lsr #32
    //     0xf3a668: b.eq            #0xf3a670
    //     0xf3a66c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf3a670: mov             x2, x3
    // 0xf3a674: r1 = Function 'notifyListeners':.
    //     0xf3a674: ldr             x1, [PP, #0x2108]  ; [pp+0x2108] AnonymousClosure: (0x834128), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x833be0)
    // 0xf3a678: r0 = AllocateClosure()
    //     0xf3a678: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf3a67c: mov             x4, x0
    // 0xf3a680: ldur            x3, [fp, #-0x10]
    // 0xf3a684: stur            x4, [fp, #-0x18]
    // 0xf3a688: r0 = LoadClassIdInstr(r3)
    //     0xf3a688: ldur            x0, [x3, #-1]
    //     0xf3a68c: ubfx            x0, x0, #0xc, #0x14
    // 0xf3a690: mov             x1, x3
    // 0xf3a694: mov             x2, x4
    // 0xf3a698: r0 = GDT[cid_x0 + 0xe0ec]()
    //     0xf3a698: mov             x17, #0xe0ec
    //     0xf3a69c: add             lr, x0, x17
    //     0xf3a6a0: ldr             lr, [x21, lr, lsl #3]
    //     0xf3a6a4: blr             lr
    // 0xf3a6a8: ldur            x2, [fp, #-8]
    // 0xf3a6ac: r1 = Function '_onStatusChange@110490068':.
    //     0xf3a6ac: add             x1, PP, #0xad, lsl #12  ; [pp+0xadbb0] AnonymousClosure: (0xf3a720), of [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionPainter
    //     0xf3a6b0: ldr             x1, [x1, #0xbb0]
    // 0xf3a6b4: r0 = AllocateClosure()
    //     0xf3a6b4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf3a6b8: ldur            x1, [fp, #-0x10]
    // 0xf3a6bc: r2 = LoadClassIdInstr(r1)
    //     0xf3a6bc: ldur            x2, [x1, #-1]
    //     0xf3a6c0: ubfx            x2, x2, #0xc, #0x14
    // 0xf3a6c4: mov             x16, x0
    // 0xf3a6c8: mov             x0, x2
    // 0xf3a6cc: mov             x2, x16
    // 0xf3a6d0: r0 = GDT[cid_x0 + 0xbeb]()
    //     0xf3a6d0: add             lr, x0, #0xbeb
    //     0xf3a6d4: ldr             lr, [x21, lr, lsl #3]
    //     0xf3a6d8: blr             lr
    // 0xf3a6dc: ldur            x1, [fp, #-0x30]
    // 0xf3a6e0: ldur            x2, [fp, #-0x18]
    // 0xf3a6e4: r0 = addListener()
    //     0xf3a6e4: bl              #0xd04650  ; [dart:mixin_deduplication] _MixinApplication461&Animation&AnimationWithParentMixin::addListener
    // 0xf3a6e8: ldur            x1, [fp, #-0x20]
    // 0xf3a6ec: r0 = LoadClassIdInstr(r1)
    //     0xf3a6ec: ldur            x0, [x1, #-1]
    //     0xf3a6f0: ubfx            x0, x0, #0xc, #0x14
    // 0xf3a6f4: ldur            x2, [fp, #-0x18]
    // 0xf3a6f8: r0 = GDT[cid_x0 + 0xe0ec]()
    //     0xf3a6f8: mov             x17, #0xe0ec
    //     0xf3a6fc: add             lr, x0, x17
    //     0xf3a700: ldr             lr, [x21, lr, lsl #3]
    //     0xf3a704: blr             lr
    // 0xf3a708: r0 = Null
    //     0xf3a708: mov             x0, NULL
    // 0xf3a70c: LeaveFrame
    //     0xf3a70c: mov             SP, fp
    //     0xf3a710: ldp             fp, lr, [SP], #0x10
    // 0xf3a714: ret
    //     0xf3a714: ret             
    // 0xf3a718: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3a718: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3a71c: b               #0xf3a50c
  }
  [closure] void _onStatusChange(dynamic, AnimationStatus) {
    // ** addr: 0xf3a720, size: 0x3c
    // 0xf3a720: EnterFrame
    //     0xf3a720: stp             fp, lr, [SP, #-0x10]!
    //     0xf3a724: mov             fp, SP
    // 0xf3a728: ldr             x0, [fp, #0x18]
    // 0xf3a72c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf3a72c: ldur            w1, [x0, #0x17]
    // 0xf3a730: DecompressPointer r1
    //     0xf3a730: add             x1, x1, HEAP, lsl #32
    // 0xf3a734: CheckStackOverflow
    //     0xf3a734: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3a738: cmp             SP, x16
    //     0xf3a73c: b.ls            #0xf3a754
    // 0xf3a740: r0 = notifyListeners()
    //     0xf3a740: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xf3a744: r0 = Null
    //     0xf3a744: mov             x0, NULL
    // 0xf3a748: LeaveFrame
    //     0xf3a748: mov             SP, fp
    //     0xf3a74c: ldp             fp, lr, [SP], #0x10
    // 0xf3a750: ret
    //     0xf3a750: ret             
    // 0xf3a754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3a754: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3a758: b               #0xf3a740
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10ef294, size: 0x11c
    // 0x10ef294: EnterFrame
    //     0x10ef294: stp             fp, lr, [SP, #-0x10]!
    //     0x10ef298: mov             fp, SP
    // 0x10ef29c: AllocStack(0x18)
    //     0x10ef29c: sub             SP, SP, #0x18
    // 0x10ef2a0: SetupParameters(_ZoomEnterTransitionPainter this /* r1 => r0, fp-0x10 */)
    //     0x10ef2a0: mov             x0, x1
    //     0x10ef2a4: stur            x1, [fp, #-0x10]
    // 0x10ef2a8: CheckStackOverflow
    //     0x10ef2a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ef2ac: cmp             SP, x16
    //     0x10ef2b0: b.ls            #0x10ef3a8
    // 0x10ef2b4: LoadField: r3 = r0->field_27
    //     0x10ef2b4: ldur            w3, [x0, #0x27]
    // 0x10ef2b8: DecompressPointer r3
    //     0x10ef2b8: add             x3, x3, HEAP, lsl #32
    // 0x10ef2bc: mov             x2, x0
    // 0x10ef2c0: stur            x3, [fp, #-8]
    // 0x10ef2c4: r1 = Function 'notifyListeners':.
    //     0x10ef2c4: ldr             x1, [PP, #0x2108]  ; [pp+0x2108] AnonymousClosure: (0x834128), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x833be0)
    // 0x10ef2c8: r0 = AllocateClosure()
    //     0x10ef2c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10ef2cc: mov             x4, x0
    // 0x10ef2d0: ldur            x3, [fp, #-8]
    // 0x10ef2d4: stur            x4, [fp, #-0x18]
    // 0x10ef2d8: r0 = LoadClassIdInstr(r3)
    //     0x10ef2d8: ldur            x0, [x3, #-1]
    //     0x10ef2dc: ubfx            x0, x0, #0xc, #0x14
    // 0x10ef2e0: mov             x1, x3
    // 0x10ef2e4: mov             x2, x4
    // 0x10ef2e8: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0x10ef2e8: mov             x17, #0xe2a3
    //     0x10ef2ec: add             lr, x0, x17
    //     0x10ef2f0: ldr             lr, [x21, lr, lsl #3]
    //     0x10ef2f4: blr             lr
    // 0x10ef2f8: ldur            x2, [fp, #-0x10]
    // 0x10ef2fc: r1 = Function '_onStatusChange@110490068':.
    //     0x10ef2fc: add             x1, PP, #0xad, lsl #12  ; [pp+0xadbb0] AnonymousClosure: (0xf3a720), of [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionPainter
    //     0x10ef300: ldr             x1, [x1, #0xbb0]
    // 0x10ef304: r0 = AllocateClosure()
    //     0x10ef304: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10ef308: ldur            x1, [fp, #-8]
    // 0x10ef30c: r2 = LoadClassIdInstr(r1)
    //     0x10ef30c: ldur            x2, [x1, #-1]
    //     0x10ef310: ubfx            x2, x2, #0xc, #0x14
    // 0x10ef314: mov             x16, x0
    // 0x10ef318: mov             x0, x2
    // 0x10ef31c: mov             x2, x16
    // 0x10ef320: r0 = GDT[cid_x0 + 0xabe]()
    //     0x10ef320: add             lr, x0, #0xabe
    //     0x10ef324: ldr             lr, [x21, lr, lsl #3]
    //     0x10ef328: blr             lr
    // 0x10ef32c: ldur            x0, [fp, #-0x10]
    // 0x10ef330: LoadField: r1 = r0->field_2b
    //     0x10ef330: ldur            w1, [x0, #0x2b]
    // 0x10ef334: DecompressPointer r1
    //     0x10ef334: add             x1, x1, HEAP, lsl #32
    // 0x10ef338: ldur            x2, [fp, #-0x18]
    // 0x10ef33c: r0 = removeListener()
    //     0x10ef33c: bl              #0xd011dc  ; [dart:mixin_deduplication] _MixinApplication461&Animation&AnimationWithParentMixin::removeListener
    // 0x10ef340: ldur            x3, [fp, #-0x10]
    // 0x10ef344: LoadField: r1 = r3->field_2f
    //     0x10ef344: ldur            w1, [x3, #0x2f]
    // 0x10ef348: DecompressPointer r1
    //     0x10ef348: add             x1, x1, HEAP, lsl #32
    // 0x10ef34c: r0 = LoadClassIdInstr(r1)
    //     0x10ef34c: ldur            x0, [x1, #-1]
    //     0x10ef350: ubfx            x0, x0, #0xc, #0x14
    // 0x10ef354: ldur            x2, [fp, #-0x18]
    // 0x10ef358: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0x10ef358: mov             x17, #0xe2a3
    //     0x10ef35c: add             lr, x0, x17
    //     0x10ef360: ldr             lr, [x21, lr, lsl #3]
    //     0x10ef364: blr             lr
    // 0x10ef368: ldur            x0, [fp, #-0x10]
    // 0x10ef36c: LoadField: r1 = r0->field_3b
    //     0x10ef36c: ldur            w1, [x0, #0x3b]
    // 0x10ef370: DecompressPointer r1
    //     0x10ef370: add             x1, x1, HEAP, lsl #32
    // 0x10ef374: r2 = Null
    //     0x10ef374: mov             x2, NULL
    // 0x10ef378: r0 = layer=()
    //     0x10ef378: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x10ef37c: ldur            x0, [fp, #-0x10]
    // 0x10ef380: LoadField: r1 = r0->field_3f
    //     0x10ef380: ldur            w1, [x0, #0x3f]
    // 0x10ef384: DecompressPointer r1
    //     0x10ef384: add             x1, x1, HEAP, lsl #32
    // 0x10ef388: r2 = Null
    //     0x10ef388: mov             x2, NULL
    // 0x10ef38c: r0 = layer=()
    //     0x10ef38c: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x10ef390: ldur            x1, [fp, #-0x10]
    // 0x10ef394: r0 = dispose()
    //     0x10ef394: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0x10ef398: r0 = Null
    //     0x10ef398: mov             x0, NULL
    // 0x10ef39c: LeaveFrame
    //     0x10ef39c: mov             SP, fp
    //     0x10ef3a0: ldp             fp, lr, [SP], #0x10
    // 0x10ef3a4: ret
    //     0x10ef3a4: ret             
    // 0x10ef3a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ef3a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ef3ac: b               #0x10ef2b4
  }
  _ paintSnapshot(/* No info */) {
    // ** addr: 0x121aa84, size: 0xe0
    // 0x121aa84: EnterFrame
    //     0x121aa84: stp             fp, lr, [SP, #-0x10]!
    //     0x121aa88: mov             fp, SP
    // 0x121aa8c: AllocStack(0x28)
    //     0x121aa8c: sub             SP, SP, #0x28
    // 0x121aa90: SetupParameters(_ZoomEnterTransitionPainter this /* r1 => r6, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r6 => r0, fp-0x18 */, dynamic _ /* d0 => d2, fp-0x28 */)
    //     0x121aa90: mov             x0, x6
    //     0x121aa94: stur            x6, [fp, #-0x18]
    //     0x121aa98: mov             x6, x1
    //     0x121aa9c: mov             x4, x2
    //     0x121aaa0: mov             v2.16b, v0.16b
    //     0x121aaa4: stur            x1, [fp, #-8]
    //     0x121aaa8: stur            x2, [fp, #-0x10]
    //     0x121aaac: stur            d0, [fp, #-0x28]
    // 0x121aab0: CheckStackOverflow
    //     0x121aab0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121aab4: cmp             SP, x16
    //     0x121aab8: b.ls            #0x121ab5c
    // 0x121aabc: mov             x1, x6
    // 0x121aac0: mov             x2, x4
    // 0x121aac4: r0 = _drawScrim()
    //     0x121aac4: bl              #0x121ad70  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionPainter::_drawScrim
    // 0x121aac8: ldur            x3, [fp, #-8]
    // 0x121aacc: LoadField: r0 = r3->field_2b
    //     0x121aacc: ldur            w0, [x3, #0x2b]
    // 0x121aad0: DecompressPointer r0
    //     0x121aad0: add             x0, x0, HEAP, lsl #32
    // 0x121aad4: LoadField: r1 = r0->field_f
    //     0x121aad4: ldur            w1, [x0, #0xf]
    // 0x121aad8: DecompressPointer r1
    //     0x121aad8: add             x1, x1, HEAP, lsl #32
    // 0x121aadc: LoadField: r2 = r0->field_b
    //     0x121aadc: ldur            w2, [x0, #0xb]
    // 0x121aae0: DecompressPointer r2
    //     0x121aae0: add             x2, x2, HEAP, lsl #32
    // 0x121aae4: r0 = LoadClassIdInstr(r1)
    //     0x121aae4: ldur            x0, [x1, #-1]
    //     0x121aae8: ubfx            x0, x0, #0xc, #0x14
    // 0x121aaec: r0 = GDT[cid_x0 + 0x80ed]()
    //     0x121aaec: mov             x17, #0x80ed
    //     0x121aaf0: add             lr, x0, x17
    //     0x121aaf4: ldr             lr, [x21, lr, lsl #3]
    //     0x121aaf8: blr             lr
    // 0x121aafc: mov             x2, x0
    // 0x121ab00: ldur            x0, [fp, #-8]
    // 0x121ab04: stur            x2, [fp, #-0x20]
    // 0x121ab08: LoadField: r1 = r0->field_2f
    //     0x121ab08: ldur            w1, [x0, #0x2f]
    // 0x121ab0c: DecompressPointer r1
    //     0x121ab0c: add             x1, x1, HEAP, lsl #32
    // 0x121ab10: r0 = LoadClassIdInstr(r1)
    //     0x121ab10: ldur            x0, [x1, #-1]
    //     0x121ab14: ubfx            x0, x0, #0xc, #0x14
    // 0x121ab18: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x121ab18: mov             x17, #0x4e2e
    //     0x121ab1c: movk            x17, #1, lsl #16
    //     0x121ab20: add             lr, x0, x17
    //     0x121ab24: ldr             lr, [x21, lr, lsl #3]
    //     0x121ab28: blr             lr
    // 0x121ab2c: mov             x1, x0
    // 0x121ab30: ldur            x0, [fp, #-0x20]
    // 0x121ab34: LoadField: d0 = r0->field_7
    //     0x121ab34: ldur            d0, [x0, #7]
    // 0x121ab38: LoadField: d1 = r1->field_7
    //     0x121ab38: ldur            d1, [x1, #7]
    // 0x121ab3c: ldur            x1, [fp, #-0x10]
    // 0x121ab40: ldur            x2, [fp, #-0x18]
    // 0x121ab44: ldur            d2, [fp, #-0x28]
    // 0x121ab48: r0 = _drawImageScaledAndCentered()
    //     0x121ab48: bl              #0x121ab64  ; [package:flutter/src/material/page_transitions_theme.dart] ::_drawImageScaledAndCentered
    // 0x121ab4c: r0 = Null
    //     0x121ab4c: mov             x0, NULL
    // 0x121ab50: LeaveFrame
    //     0x121ab50: mov             SP, fp
    //     0x121ab54: ldp             fp, lr, [SP], #0x10
    // 0x121ab58: ret
    //     0x121ab58: ret             
    // 0x121ab5c: r0 = StackOverflowSharedWithFPURegs()
    //     0x121ab5c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x121ab60: b               #0x121aabc
  }
  _ _drawScrim(/* No info */) {
    // ** addr: 0x121ad70, size: 0x164
    // 0x121ad70: EnterFrame
    //     0x121ad70: stp             fp, lr, [SP, #-0x10]!
    //     0x121ad74: mov             fp, SP
    // 0x121ad78: AllocStack(0x40)
    //     0x121ad78: sub             SP, SP, #0x40
    // 0x121ad7c: SetupParameters(_ZoomEnterTransitionPainter this /* r1 => r5, fp-0x10 */, dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */, dynamic _ /* r5 => r2, fp-0x28 */)
    //     0x121ad7c: mov             x4, x2
    //     0x121ad80: stur            x2, [fp, #-0x18]
    //     0x121ad84: mov             x2, x5
    //     0x121ad88: stur            x5, [fp, #-0x28]
    //     0x121ad8c: mov             x5, x1
    //     0x121ad90: stur            x1, [fp, #-0x10]
    //     0x121ad94: stur            x3, [fp, #-0x20]
    // 0x121ad98: CheckStackOverflow
    //     0x121ad98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121ad9c: cmp             SP, x16
    //     0x121ada0: b.ls            #0x121aec8
    // 0x121ada4: LoadField: r0 = r5->field_23
    //     0x121ada4: ldur            w0, [x5, #0x23]
    // 0x121ada8: DecompressPointer r0
    //     0x121ada8: add             x0, x0, HEAP, lsl #32
    // 0x121adac: tbz             w0, #4, #0x121ae20
    // 0x121adb0: LoadField: r6 = r5->field_27
    //     0x121adb0: ldur            w6, [x5, #0x27]
    // 0x121adb4: DecompressPointer r6
    //     0x121adb4: add             x6, x6, HEAP, lsl #32
    // 0x121adb8: stur            x6, [fp, #-8]
    // 0x121adbc: r0 = LoadClassIdInstr(r6)
    //     0x121adbc: ldur            x0, [x6, #-1]
    //     0x121adc0: ubfx            x0, x0, #0xc, #0x14
    // 0x121adc4: mov             x1, x6
    // 0x121adc8: r0 = GDT[cid_x0 + -0x52]()
    //     0x121adc8: sub             lr, x0, #0x52
    //     0x121adcc: ldr             lr, [x21, lr, lsl #3]
    //     0x121add0: blr             lr
    // 0x121add4: r16 = Instance_AnimationStatus
    //     0x121add4: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0x121add8: cmp             w0, w16
    // 0x121addc: b.eq            #0x121ae20
    // 0x121ade0: r0 = LoadStaticField(0x740)
    //     0x121ade0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x121ade4: ldr             x0, [x0, #0xe80]
    // 0x121ade8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x121adec: cmp             w0, w16
    // 0x121adf0: b.ne            #0x121ae00
    // 0x121adf4: r2 = _scrimOpacityTween
    //     0x121adf4: add             x2, PP, #0xd1, lsl #12  ; [pp+0xd1dc8] Field <_ZoomEnterTransitionState@110490068._scrimOpacityTween@110490068>: static late final (offset: 0x740)
    //     0x121adf8: ldr             x2, [x2, #0xdc8]
    // 0x121adfc: r0 = InitLateFinalStaticField()
    //     0x121adfc: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x121ae00: mov             x1, x0
    // 0x121ae04: ldur            x2, [fp, #-8]
    // 0x121ae08: r0 = evaluate()
    //     0x121ae08: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x121ae0c: cmp             w0, NULL
    // 0x121ae10: b.eq            #0x121aed0
    // 0x121ae14: LoadField: d0 = r0->field_7
    //     0x121ae14: ldur            d0, [x0, #7]
    // 0x121ae18: mov             v1.16b, v0.16b
    // 0x121ae1c: b               #0x121ae24
    // 0x121ae20: d1 = 0.000000
    //     0x121ae20: eor             v1.16b, v1.16b, v1.16b
    // 0x121ae24: d0 = 0.000000
    //     0x121ae24: eor             v0.16b, v0.16b, v0.16b
    // 0x121ae28: stur            d1, [fp, #-0x30]
    // 0x121ae2c: fcmp            d1, d0
    // 0x121ae30: b.le            #0x121aeb8
    // 0x121ae34: ldur            x0, [fp, #-0x10]
    // 0x121ae38: ldur            x1, [fp, #-0x18]
    // 0x121ae3c: r0 = canvas()
    //     0x121ae3c: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x121ae40: ldur            x1, [fp, #-0x20]
    // 0x121ae44: ldur            x2, [fp, #-0x28]
    // 0x121ae48: stur            x0, [fp, #-8]
    // 0x121ae4c: r0 = &()
    //     0x121ae4c: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x121ae50: stur            x0, [fp, #-0x18]
    // 0x121ae54: r16 = 136
    //     0x121ae54: mov             x16, #0x88
    // 0x121ae58: stp             x16, NULL, [SP]
    // 0x121ae5c: r0 = ByteData()
    //     0x121ae5c: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x121ae60: stur            x0, [fp, #-0x20]
    // 0x121ae64: r0 = Paint()
    //     0x121ae64: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x121ae68: mov             x2, x0
    // 0x121ae6c: ldur            x0, [fp, #-0x20]
    // 0x121ae70: stur            x2, [fp, #-0x28]
    // 0x121ae74: StoreField: r2->field_7 = r0
    //     0x121ae74: stur            w0, [x2, #7]
    // 0x121ae78: ldur            x0, [fp, #-0x10]
    // 0x121ae7c: LoadField: r1 = r0->field_33
    //     0x121ae7c: ldur            w1, [x0, #0x33]
    // 0x121ae80: DecompressPointer r1
    //     0x121ae80: add             x1, x1, HEAP, lsl #32
    // 0x121ae84: r0 = LoadClassIdInstr(r1)
    //     0x121ae84: ldur            x0, [x1, #-1]
    //     0x121ae88: ubfx            x0, x0, #0xc, #0x14
    // 0x121ae8c: ldur            d0, [fp, #-0x30]
    // 0x121ae90: r0 = GDT[cid_x0 + -0x1000]()
    //     0x121ae90: sub             lr, x0, #1, lsl #12
    //     0x121ae94: ldr             lr, [x21, lr, lsl #3]
    //     0x121ae98: blr             lr
    // 0x121ae9c: ldur            x1, [fp, #-0x28]
    // 0x121aea0: mov             x2, x0
    // 0x121aea4: r0 = color=()
    //     0x121aea4: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x121aea8: ldur            x1, [fp, #-8]
    // 0x121aeac: ldur            x2, [fp, #-0x18]
    // 0x121aeb0: ldur            x3, [fp, #-0x28]
    // 0x121aeb4: r0 = drawRect()
    //     0x121aeb4: bl              #0xb704c8  ; [dart:ui] _NativeCanvas::drawRect
    // 0x121aeb8: r0 = Null
    //     0x121aeb8: mov             x0, NULL
    // 0x121aebc: LeaveFrame
    //     0x121aebc: mov             SP, fp
    //     0x121aec0: ldp             fp, lr, [SP], #0x10
    // 0x121aec4: ret
    //     0x121aec4: ret             
    // 0x121aec8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121aec8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121aecc: b               #0x121ada4
    // 0x121aed0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x121aed0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0x1224d00, size: 0x214
    // 0x1224d00: EnterFrame
    //     0x1224d00: stp             fp, lr, [SP, #-0x10]!
    //     0x1224d04: mov             fp, SP
    // 0x1224d08: AllocStack(0x18)
    //     0x1224d08: sub             SP, SP, #0x18
    // 0x1224d0c: SetupParameters(_ZoomEnterTransitionPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x1224d0c: mov             x4, x1
    //     0x1224d10: mov             x3, x2
    //     0x1224d14: stur            x1, [fp, #-8]
    //     0x1224d18: stur            x2, [fp, #-0x10]
    // 0x1224d1c: CheckStackOverflow
    //     0x1224d1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1224d20: cmp             SP, x16
    //     0x1224d24: b.ls            #0x1224f0c
    // 0x1224d28: mov             x0, x3
    // 0x1224d2c: r2 = Null
    //     0x1224d2c: mov             x2, NULL
    // 0x1224d30: r1 = Null
    //     0x1224d30: mov             x1, NULL
    // 0x1224d34: r4 = 60
    //     0x1224d34: mov             x4, #0x3c
    // 0x1224d38: branchIfSmi(r0, 0x1224d44)
    //     0x1224d38: tbz             w0, #0, #0x1224d44
    // 0x1224d3c: r4 = LoadClassIdInstr(r0)
    //     0x1224d3c: ldur            x4, [x0, #-1]
    //     0x1224d40: ubfx            x4, x4, #0xc, #0x14
    // 0x1224d44: r17 = 4493
    //     0x1224d44: mov             x17, #0x118d
    // 0x1224d48: cmp             x4, x17
    // 0x1224d4c: b.eq            #0x1224d64
    // 0x1224d50: r8 = _ZoomEnterTransitionPainter
    //     0x1224d50: add             x8, PP, #0xd0, lsl #12  ; [pp+0xd0550] Type: _ZoomEnterTransitionPainter
    //     0x1224d54: ldr             x8, [x8, #0x550]
    // 0x1224d58: r3 = Null
    //     0x1224d58: add             x3, PP, #0xd0, lsl #12  ; [pp+0xd0558] Null
    //     0x1224d5c: ldr             x3, [x3, #0x558]
    // 0x1224d60: r0 = DefaultTypeTest()
    //     0x1224d60: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x1224d64: ldur            x2, [fp, #-0x10]
    // 0x1224d68: LoadField: r0 = r2->field_23
    //     0x1224d68: ldur            w0, [x2, #0x23]
    // 0x1224d6c: DecompressPointer r0
    //     0x1224d6c: add             x0, x0, HEAP, lsl #32
    // 0x1224d70: ldur            x3, [fp, #-8]
    // 0x1224d74: LoadField: r1 = r3->field_23
    //     0x1224d74: ldur            w1, [x3, #0x23]
    // 0x1224d78: DecompressPointer r1
    //     0x1224d78: add             x1, x1, HEAP, lsl #32
    // 0x1224d7c: cmp             w0, w1
    // 0x1224d80: b.ne            #0x1224e7c
    // 0x1224d84: LoadField: r1 = r2->field_27
    //     0x1224d84: ldur            w1, [x2, #0x27]
    // 0x1224d88: DecompressPointer r1
    //     0x1224d88: add             x1, x1, HEAP, lsl #32
    // 0x1224d8c: r0 = LoadClassIdInstr(r1)
    //     0x1224d8c: ldur            x0, [x1, #-1]
    //     0x1224d90: ubfx            x0, x0, #0xc, #0x14
    // 0x1224d94: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x1224d94: mov             x17, #0x4e2e
    //     0x1224d98: movk            x17, #1, lsl #16
    //     0x1224d9c: add             lr, x0, x17
    //     0x1224da0: ldr             lr, [x21, lr, lsl #3]
    //     0x1224da4: blr             lr
    // 0x1224da8: mov             x3, x0
    // 0x1224dac: ldur            x2, [fp, #-8]
    // 0x1224db0: stur            x3, [fp, #-0x18]
    // 0x1224db4: LoadField: r1 = r2->field_27
    //     0x1224db4: ldur            w1, [x2, #0x27]
    // 0x1224db8: DecompressPointer r1
    //     0x1224db8: add             x1, x1, HEAP, lsl #32
    // 0x1224dbc: r0 = LoadClassIdInstr(r1)
    //     0x1224dbc: ldur            x0, [x1, #-1]
    //     0x1224dc0: ubfx            x0, x0, #0xc, #0x14
    // 0x1224dc4: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x1224dc4: mov             x17, #0x4e2e
    //     0x1224dc8: movk            x17, #1, lsl #16
    //     0x1224dcc: add             lr, x0, x17
    //     0x1224dd0: ldr             lr, [x21, lr, lsl #3]
    //     0x1224dd4: blr             lr
    // 0x1224dd8: mov             x1, x0
    // 0x1224ddc: ldur            x0, [fp, #-0x18]
    // 0x1224de0: LoadField: d0 = r0->field_7
    //     0x1224de0: ldur            d0, [x0, #7]
    // 0x1224de4: LoadField: d1 = r1->field_7
    //     0x1224de4: ldur            d1, [x1, #7]
    // 0x1224de8: fcmp            d0, d1
    // 0x1224dec: b.ne            #0x1224e7c
    // 0x1224df0: ldur            x3, [fp, #-8]
    // 0x1224df4: ldur            x4, [fp, #-0x10]
    // 0x1224df8: LoadField: r0 = r4->field_2b
    //     0x1224df8: ldur            w0, [x4, #0x2b]
    // 0x1224dfc: DecompressPointer r0
    //     0x1224dfc: add             x0, x0, HEAP, lsl #32
    // 0x1224e00: LoadField: r1 = r0->field_f
    //     0x1224e00: ldur            w1, [x0, #0xf]
    // 0x1224e04: DecompressPointer r1
    //     0x1224e04: add             x1, x1, HEAP, lsl #32
    // 0x1224e08: LoadField: r2 = r0->field_b
    //     0x1224e08: ldur            w2, [x0, #0xb]
    // 0x1224e0c: DecompressPointer r2
    //     0x1224e0c: add             x2, x2, HEAP, lsl #32
    // 0x1224e10: r0 = LoadClassIdInstr(r1)
    //     0x1224e10: ldur            x0, [x1, #-1]
    //     0x1224e14: ubfx            x0, x0, #0xc, #0x14
    // 0x1224e18: r0 = GDT[cid_x0 + 0x80ed]()
    //     0x1224e18: mov             x17, #0x80ed
    //     0x1224e1c: add             lr, x0, x17
    //     0x1224e20: ldr             lr, [x21, lr, lsl #3]
    //     0x1224e24: blr             lr
    // 0x1224e28: mov             x4, x0
    // 0x1224e2c: ldur            x3, [fp, #-8]
    // 0x1224e30: stur            x4, [fp, #-0x18]
    // 0x1224e34: LoadField: r0 = r3->field_2b
    //     0x1224e34: ldur            w0, [x3, #0x2b]
    // 0x1224e38: DecompressPointer r0
    //     0x1224e38: add             x0, x0, HEAP, lsl #32
    // 0x1224e3c: LoadField: r1 = r0->field_f
    //     0x1224e3c: ldur            w1, [x0, #0xf]
    // 0x1224e40: DecompressPointer r1
    //     0x1224e40: add             x1, x1, HEAP, lsl #32
    // 0x1224e44: LoadField: r2 = r0->field_b
    //     0x1224e44: ldur            w2, [x0, #0xb]
    // 0x1224e48: DecompressPointer r2
    //     0x1224e48: add             x2, x2, HEAP, lsl #32
    // 0x1224e4c: r0 = LoadClassIdInstr(r1)
    //     0x1224e4c: ldur            x0, [x1, #-1]
    //     0x1224e50: ubfx            x0, x0, #0xc, #0x14
    // 0x1224e54: r0 = GDT[cid_x0 + 0x80ed]()
    //     0x1224e54: mov             x17, #0x80ed
    //     0x1224e58: add             lr, x0, x17
    //     0x1224e5c: ldr             lr, [x21, lr, lsl #3]
    //     0x1224e60: blr             lr
    // 0x1224e64: mov             x1, x0
    // 0x1224e68: ldur            x0, [fp, #-0x18]
    // 0x1224e6c: LoadField: d0 = r0->field_7
    //     0x1224e6c: ldur            d0, [x0, #7]
    // 0x1224e70: LoadField: d1 = r1->field_7
    //     0x1224e70: ldur            d1, [x1, #7]
    // 0x1224e74: fcmp            d0, d1
    // 0x1224e78: b.eq            #0x1224e84
    // 0x1224e7c: r0 = true
    //     0x1224e7c: add             x0, NULL, #0x20  ; true
    // 0x1224e80: b               #0x1224f00
    // 0x1224e84: ldur            x2, [fp, #-8]
    // 0x1224e88: ldur            x0, [fp, #-0x10]
    // 0x1224e8c: LoadField: r1 = r0->field_2f
    //     0x1224e8c: ldur            w1, [x0, #0x2f]
    // 0x1224e90: DecompressPointer r1
    //     0x1224e90: add             x1, x1, HEAP, lsl #32
    // 0x1224e94: r0 = LoadClassIdInstr(r1)
    //     0x1224e94: ldur            x0, [x1, #-1]
    //     0x1224e98: ubfx            x0, x0, #0xc, #0x14
    // 0x1224e9c: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x1224e9c: mov             x17, #0x4e2e
    //     0x1224ea0: movk            x17, #1, lsl #16
    //     0x1224ea4: add             lr, x0, x17
    //     0x1224ea8: ldr             lr, [x21, lr, lsl #3]
    //     0x1224eac: blr             lr
    // 0x1224eb0: mov             x2, x0
    // 0x1224eb4: ldur            x0, [fp, #-8]
    // 0x1224eb8: stur            x2, [fp, #-0x10]
    // 0x1224ebc: LoadField: r1 = r0->field_2f
    //     0x1224ebc: ldur            w1, [x0, #0x2f]
    // 0x1224ec0: DecompressPointer r1
    //     0x1224ec0: add             x1, x1, HEAP, lsl #32
    // 0x1224ec4: r0 = LoadClassIdInstr(r1)
    //     0x1224ec4: ldur            x0, [x1, #-1]
    //     0x1224ec8: ubfx            x0, x0, #0xc, #0x14
    // 0x1224ecc: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x1224ecc: mov             x17, #0x4e2e
    //     0x1224ed0: movk            x17, #1, lsl #16
    //     0x1224ed4: add             lr, x0, x17
    //     0x1224ed8: ldr             lr, [x21, lr, lsl #3]
    //     0x1224edc: blr             lr
    // 0x1224ee0: ldur            x1, [fp, #-0x10]
    // 0x1224ee4: LoadField: d0 = r1->field_7
    //     0x1224ee4: ldur            d0, [x1, #7]
    // 0x1224ee8: LoadField: d1 = r0->field_7
    //     0x1224ee8: ldur            d1, [x0, #7]
    // 0x1224eec: fcmp            d0, d1
    // 0x1224ef0: r16 = true
    //     0x1224ef0: add             x16, NULL, #0x20  ; true
    // 0x1224ef4: r17 = false
    //     0x1224ef4: add             x17, NULL, #0x30  ; false
    // 0x1224ef8: csel            x1, x16, x17, ne
    // 0x1224efc: mov             x0, x1
    // 0x1224f00: LeaveFrame
    //     0x1224f00: mov             SP, fp
    //     0x1224f04: ldp             fp, lr, [SP], #0x10
    // 0x1224f08: ret
    //     0x1224f08: ret             
    // 0x1224f0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1224f0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1224f10: b               #0x1224d28
  }
  _ paint(/* No info */) {
    // ** addr: 0x12820c0, size: 0x180
    // 0x12820c0: EnterFrame
    //     0x12820c0: stp             fp, lr, [SP, #-0x10]!
    //     0x12820c4: mov             fp, SP
    // 0x12820c8: AllocStack(0x30)
    //     0x12820c8: sub             SP, SP, #0x30
    // 0x12820cc: SetupParameters(_ZoomEnterTransitionPainter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */)
    //     0x12820cc: stur            x1, [fp, #-8]
    //     0x12820d0: stur            x2, [fp, #-0x10]
    //     0x12820d4: stur            x3, [fp, #-0x18]
    //     0x12820d8: stur            x5, [fp, #-0x20]
    //     0x12820dc: stur            x6, [fp, #-0x28]
    // 0x12820e0: CheckStackOverflow
    //     0x12820e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12820e4: cmp             SP, x16
    //     0x12820e8: b.ls            #0x1282238
    // 0x12820ec: r1 = 2
    //     0x12820ec: mov             x1, #2
    // 0x12820f0: r0 = AllocateContext()
    //     0x12820f0: bl              #0x13de838  ; AllocateContextStub
    // 0x12820f4: mov             x3, x0
    // 0x12820f8: ldur            x2, [fp, #-8]
    // 0x12820fc: stur            x3, [fp, #-0x30]
    // 0x1282100: StoreField: r3->field_f = r2
    //     0x1282100: stur            w2, [x3, #0xf]
    // 0x1282104: ldur            x0, [fp, #-0x28]
    // 0x1282108: StoreField: r3->field_13 = r0
    //     0x1282108: stur            w0, [x3, #0x13]
    // 0x128210c: LoadField: r1 = r2->field_27
    //     0x128210c: ldur            w1, [x2, #0x27]
    // 0x1282110: DecompressPointer r1
    //     0x1282110: add             x1, x1, HEAP, lsl #32
    // 0x1282114: r0 = LoadClassIdInstr(r1)
    //     0x1282114: ldur            x0, [x1, #-1]
    //     0x1282118: ubfx            x0, x0, #0xc, #0x14
    // 0x128211c: r0 = GDT[cid_x0 + 0x12d66]()
    //     0x128211c: mov             x17, #0x2d66
    //     0x1282120: movk            x17, #1, lsl #16
    //     0x1282124: add             lr, x0, x17
    //     0x1282128: ldr             lr, [x21, lr, lsl #3]
    //     0x128212c: blr             lr
    // 0x1282130: tbz             w0, #4, #0x1282168
    // 0x1282134: ldur            x0, [fp, #-0x30]
    // 0x1282138: LoadField: r1 = r0->field_13
    //     0x1282138: ldur            w1, [x0, #0x13]
    // 0x128213c: DecompressPointer r1
    //     0x128213c: add             x1, x1, HEAP, lsl #32
    // 0x1282140: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x1282140: ldur            w0, [x1, #0x17]
    // 0x1282144: DecompressPointer r0
    //     0x1282144: add             x0, x0, HEAP, lsl #32
    // 0x1282148: mov             x1, x0
    // 0x128214c: ldur            x2, [fp, #-0x10]
    // 0x1282150: ldur            x3, [fp, #-0x18]
    // 0x1282154: r0 = paint()
    //     0x1282154: bl              #0xc1faf0  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint
    // 0x1282158: r0 = Null
    //     0x1282158: mov             x0, NULL
    // 0x128215c: LeaveFrame
    //     0x128215c: mov             SP, fp
    //     0x1282160: ldp             fp, lr, [SP], #0x10
    // 0x1282164: ret
    //     0x1282164: ret             
    // 0x1282168: ldur            x4, [fp, #-8]
    // 0x128216c: ldur            x0, [fp, #-0x30]
    // 0x1282170: mov             x1, x4
    // 0x1282174: ldur            x2, [fp, #-0x10]
    // 0x1282178: ldur            x3, [fp, #-0x18]
    // 0x128217c: ldur            x5, [fp, #-0x20]
    // 0x1282180: r0 = _drawScrim()
    //     0x1282180: bl              #0x121ad70  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionPainter::_drawScrim
    // 0x1282184: ldur            x3, [fp, #-8]
    // 0x1282188: LoadField: r4 = r3->field_37
    //     0x1282188: ldur            w4, [x3, #0x37]
    // 0x128218c: DecompressPointer r4
    //     0x128218c: add             x4, x4, HEAP, lsl #32
    // 0x1282190: stur            x4, [fp, #-0x28]
    // 0x1282194: LoadField: r0 = r3->field_2b
    //     0x1282194: ldur            w0, [x3, #0x2b]
    // 0x1282198: DecompressPointer r0
    //     0x1282198: add             x0, x0, HEAP, lsl #32
    // 0x128219c: LoadField: r1 = r0->field_f
    //     0x128219c: ldur            w1, [x0, #0xf]
    // 0x12821a0: DecompressPointer r1
    //     0x12821a0: add             x1, x1, HEAP, lsl #32
    // 0x12821a4: LoadField: r2 = r0->field_b
    //     0x12821a4: ldur            w2, [x0, #0xb]
    // 0x12821a8: DecompressPointer r2
    //     0x12821a8: add             x2, x2, HEAP, lsl #32
    // 0x12821ac: r0 = LoadClassIdInstr(r1)
    //     0x12821ac: ldur            x0, [x1, #-1]
    //     0x12821b0: ubfx            x0, x0, #0xc, #0x14
    // 0x12821b4: r0 = GDT[cid_x0 + 0x80ed]()
    //     0x12821b4: mov             x17, #0x80ed
    //     0x12821b8: add             lr, x0, x17
    //     0x12821bc: ldr             lr, [x21, lr, lsl #3]
    //     0x12821c0: blr             lr
    // 0x12821c4: LoadField: d0 = r0->field_7
    //     0x12821c4: ldur            d0, [x0, #7]
    // 0x12821c8: ldur            x1, [fp, #-0x28]
    // 0x12821cc: ldur            x2, [fp, #-0x20]
    // 0x12821d0: r0 = _updateScaledTransform()
    //     0x12821d0: bl              #0x1282240  ; [package:flutter/src/material/page_transitions_theme.dart] ::_updateScaledTransform
    // 0x12821d4: ldur            x0, [fp, #-8]
    // 0x12821d8: LoadField: r3 = r0->field_3f
    //     0x12821d8: ldur            w3, [x0, #0x3f]
    // 0x12821dc: DecompressPointer r3
    //     0x12821dc: add             x3, x3, HEAP, lsl #32
    // 0x12821e0: stur            x3, [fp, #-0x20]
    // 0x12821e4: LoadField: r7 = r3->field_b
    //     0x12821e4: ldur            w7, [x3, #0xb]
    // 0x12821e8: DecompressPointer r7
    //     0x12821e8: add             x7, x7, HEAP, lsl #32
    // 0x12821ec: ldur            x2, [fp, #-0x30]
    // 0x12821f0: stur            x7, [fp, #-8]
    // 0x12821f4: r1 = Function '<anonymous closure>':.
    //     0x12821f4: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1dd8] AnonymousClosure: (0x1282300), in [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionPainter::paint (0x12820c0)
    //     0x12821f8: ldr             x1, [x1, #0xdd8]
    // 0x12821fc: r0 = AllocateClosure()
    //     0x12821fc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1282200: ldur            x1, [fp, #-0x10]
    // 0x1282204: ldur            x3, [fp, #-0x18]
    // 0x1282208: ldur            x5, [fp, #-0x28]
    // 0x128220c: mov             x6, x0
    // 0x1282210: ldur            x7, [fp, #-8]
    // 0x1282214: r2 = true
    //     0x1282214: add             x2, NULL, #0x20  ; true
    // 0x1282218: r0 = pushTransform()
    //     0x1282218: bl              #0xc1c818  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushTransform
    // 0x128221c: ldur            x1, [fp, #-0x20]
    // 0x1282220: mov             x2, x0
    // 0x1282224: r0 = layer=()
    //     0x1282224: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x1282228: r0 = Null
    //     0x1282228: mov             x0, NULL
    // 0x128222c: LeaveFrame
    //     0x128222c: mov             SP, fp
    //     0x1282230: ldp             fp, lr, [SP], #0x10
    // 0x1282234: ret
    //     0x1282234: ret             
    // 0x1282238: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1282238: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x128223c: b               #0x12820ec
  }
  [closure] void <anonymous closure>(dynamic, PaintingContext, Offset) {
    // ** addr: 0x1282300, size: 0x13c
    // 0x1282300: EnterFrame
    //     0x1282300: stp             fp, lr, [SP, #-0x10]!
    //     0x1282304: mov             fp, SP
    // 0x1282308: AllocStack(0x10)
    //     0x1282308: sub             SP, SP, #0x10
    // 0x128230c: SetupParameters([dynamic _ /* r0 */])
    //     0x128230c: ldr             x0, [fp, #0x20]
    //     0x1282310: ldur            w2, [x0, #0x17]
    //     0x1282314: add             x2, x2, HEAP, lsl #32
    //     0x1282318: stur            x2, [fp, #-0x10]
    // 0x128231c: CheckStackOverflow
    //     0x128231c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1282320: cmp             SP, x16
    //     0x1282324: b.ls            #0x1282418
    // 0x1282328: LoadField: r0 = r2->field_f
    //     0x1282328: ldur            w0, [x2, #0xf]
    // 0x128232c: DecompressPointer r0
    //     0x128232c: add             x0, x0, HEAP, lsl #32
    // 0x1282330: LoadField: r3 = r0->field_3b
    //     0x1282330: ldur            w3, [x0, #0x3b]
    // 0x1282334: DecompressPointer r3
    //     0x1282334: add             x3, x3, HEAP, lsl #32
    // 0x1282338: stur            x3, [fp, #-8]
    // 0x128233c: LoadField: r1 = r0->field_2f
    //     0x128233c: ldur            w1, [x0, #0x2f]
    // 0x1282340: DecompressPointer r1
    //     0x1282340: add             x1, x1, HEAP, lsl #32
    // 0x1282344: r0 = LoadClassIdInstr(r1)
    //     0x1282344: ldur            x0, [x1, #-1]
    //     0x1282348: ubfx            x0, x0, #0xc, #0x14
    // 0x128234c: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x128234c: mov             x17, #0x4e2e
    //     0x1282350: movk            x17, #1, lsl #16
    //     0x1282354: add             lr, x0, x17
    //     0x1282358: ldr             lr, [x21, lr, lsl #3]
    //     0x128235c: blr             lr
    // 0x1282360: LoadField: d0 = r0->field_7
    //     0x1282360: ldur            d0, [x0, #7]
    // 0x1282364: d1 = 255.000000
    //     0x1282364: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x1282368: fmul            d2, d0, d1
    // 0x128236c: mov             v0.16b, v2.16b
    // 0x1282370: stp             fp, lr, [SP, #-0x10]!
    // 0x1282374: mov             fp, SP
    // 0x1282378: CallRuntime_LibcRound(double) -> double
    //     0x1282378: and             SP, SP, #0xfffffffffffffff0
    //     0x128237c: mov             sp, SP
    //     0x1282380: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0x1282384: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x1282388: blr             x16
    //     0x128238c: mov             x16, #8
    //     0x1282390: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x1282394: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x1282398: sub             sp, x16, #1, lsl #12
    //     0x128239c: mov             SP, fp
    //     0x12823a0: ldp             fp, lr, [SP], #0x10
    // 0x12823a4: fcmp            d0, d0
    // 0x12823a8: b.vs            #0x1282420
    // 0x12823ac: fcvtzs          x0, d0
    // 0x12823b0: asr             x16, x0, #0x1e
    // 0x12823b4: cmp             x16, x0, asr #63
    // 0x12823b8: b.ne            #0x1282420
    // 0x12823bc: lsl             x0, x0, #1
    // 0x12823c0: ldur            x1, [fp, #-0x10]
    // 0x12823c4: LoadField: r5 = r1->field_13
    //     0x12823c4: ldur            w5, [x1, #0x13]
    // 0x12823c8: DecompressPointer r5
    //     0x12823c8: add             x5, x5, HEAP, lsl #32
    // 0x12823cc: LoadField: r2 = r1->field_f
    //     0x12823cc: ldur            w2, [x1, #0xf]
    // 0x12823d0: DecompressPointer r2
    //     0x12823d0: add             x2, x2, HEAP, lsl #32
    // 0x12823d4: LoadField: r1 = r2->field_3b
    //     0x12823d4: ldur            w1, [x2, #0x3b]
    // 0x12823d8: DecompressPointer r1
    //     0x12823d8: add             x1, x1, HEAP, lsl #32
    // 0x12823dc: LoadField: r6 = r1->field_b
    //     0x12823dc: ldur            w6, [x1, #0xb]
    // 0x12823e0: DecompressPointer r6
    //     0x12823e0: add             x6, x6, HEAP, lsl #32
    // 0x12823e4: r3 = LoadInt32Instr(r0)
    //     0x12823e4: sbfx            x3, x0, #1, #0x1f
    //     0x12823e8: tbz             w0, #0, #0x12823f0
    //     0x12823ec: ldur            x3, [x0, #7]
    // 0x12823f0: ldr             x1, [fp, #0x18]
    // 0x12823f4: ldr             x2, [fp, #0x10]
    // 0x12823f8: r0 = pushOpacity()
    //     0x12823f8: bl              #0x128243c  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushOpacity
    // 0x12823fc: ldur            x1, [fp, #-8]
    // 0x1282400: mov             x2, x0
    // 0x1282404: r0 = layer=()
    //     0x1282404: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x1282408: r0 = Null
    //     0x1282408: mov             x0, NULL
    // 0x128240c: LeaveFrame
    //     0x128240c: mov             SP, fp
    //     0x1282410: ldp             fp, lr, [SP], #0x10
    // 0x1282414: ret
    //     0x1282414: ret             
    // 0x1282418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1282418: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x128241c: b               #0x1282328
    // 0x1282420: SaveReg d0
    //     0x1282420: str             q0, [SP, #-0x10]!
    // 0x1282424: r0 = 76
    //     0x1282424: mov             x0, #0x4c
    // 0x1282428: r30 = DoubleToIntegerStub
    //     0x1282428: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0x128242c: LoadField: r30 = r30->field_7
    //     0x128242c: ldur            lr, [lr, #7]
    // 0x1282430: blr             lr
    // 0x1282434: RestoreReg d0
    //     0x1282434: ldr             q0, [SP], #0x10
    // 0x1282438: b               #0x12823c0
  }
}

// class id: 5132, size: 0xc, field offset: 0x8
//   const constructor, 
class PageTransitionsTheme extends _MixinApplication3&Object&Diagnosticable {

  _ConstMap<TargetPlatform, PageTransitionsBuilder> field_8;

  _ buildTransitions(/* No info */) {
    // ** addr: 0xb272d4, size: 0x70
    // 0xb272d4: EnterFrame
    //     0xb272d4: stp             fp, lr, [SP, #-0x10]!
    //     0xb272d8: mov             fp, SP
    // 0xb272dc: LoadField: r0 = r4->field_f
    //     0xb272dc: ldur            w0, [x4, #0xf]
    // 0xb272e0: cbnz            w0, #0xb272ec
    // 0xb272e4: r1 = Null
    //     0xb272e4: mov             x1, NULL
    // 0xb272e8: b               #0xb272f8
    // 0xb272ec: ArrayLoad: r0 = r4[0]  ; List_4
    //     0xb272ec: ldur            w0, [x4, #0x17]
    // 0xb272f0: add             x1, fp, w0, sxtw #2
    // 0xb272f4: ldr             x1, [x1, #0x10]
    // 0xb272f8: ldr             x4, [fp, #0x28]
    // 0xb272fc: ldr             x3, [fp, #0x20]
    // 0xb27300: ldr             x2, [fp, #0x18]
    // 0xb27304: ldr             x0, [fp, #0x10]
    // 0xb27308: r0 = _PageTransitionsThemeTransitions()
    //     0xb27308: bl              #0xb27344  ; Allocate_PageTransitionsThemeTransitionsStub -> _PageTransitionsThemeTransitions<X0> (size=0x24)
    // 0xb2730c: r1 = _ConstMap len:5
    //     0xb2730c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26b08] Map<TargetPlatform, PageTransitionsBuilder>(5)
    //     0xb27310: ldr             x1, [x1, #0xb08]
    // 0xb27314: StoreField: r0->field_f = r1
    //     0xb27314: stur            w1, [x0, #0xf]
    // 0xb27318: ldr             x1, [fp, #0x28]
    // 0xb2731c: StoreField: r0->field_13 = r1
    //     0xb2731c: stur            w1, [x0, #0x13]
    // 0xb27320: ldr             x1, [fp, #0x20]
    // 0xb27324: ArrayStore: r0[0] = r1  ; List_4
    //     0xb27324: stur            w1, [x0, #0x17]
    // 0xb27328: ldr             x1, [fp, #0x18]
    // 0xb2732c: StoreField: r0->field_1b = r1
    //     0xb2732c: stur            w1, [x0, #0x1b]
    // 0xb27330: ldr             x1, [fp, #0x10]
    // 0xb27334: StoreField: r0->field_1f = r1
    //     0xb27334: stur            w1, [x0, #0x1f]
    // 0xb27338: LeaveFrame
    //     0xb27338: mov             SP, fp
    //     0xb2733c: ldp             fp, lr, [SP], #0x10
    // 0xb27340: ret
    //     0xb27340: ret             
  }
  _ delegatedTransition(/* No info */) {
    // ** addr: 0xe0d704, size: 0x68
    // 0xe0d704: EnterFrame
    //     0xe0d704: stp             fp, lr, [SP, #-0x10]!
    //     0xe0d708: mov             fp, SP
    // 0xe0d70c: CheckStackOverflow
    //     0xe0d70c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe0d710: cmp             SP, x16
    //     0xe0d714: b.ls            #0xe0d764
    // 0xe0d718: r1 = _ConstMap len:5
    //     0xe0d718: add             x1, PP, #0x26, lsl #12  ; [pp+0x26b08] Map<TargetPlatform, PageTransitionsBuilder>(5)
    //     0xe0d71c: ldr             x1, [x1, #0xb08]
    // 0xe0d720: r2 = Instance_TargetPlatform
    //     0xe0d720: add             x2, PP, #0x12, lsl #12  ; [pp+0x12940] Obj!TargetPlatform@12c5e81
    //     0xe0d724: ldr             x2, [x2, #0x940]
    // 0xe0d728: r0 = []()
    //     0xe0d728: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0xe0d72c: cmp             w0, NULL
    // 0xe0d730: b.ne            #0xe0d740
    // 0xe0d734: r1 = Instance_ZoomPageTransitionsBuilder
    //     0xe0d734: add             x1, PP, #0x90, lsl #12  ; [pp+0x90990] Obj!ZoomPageTransitionsBuilder@129f301
    //     0xe0d738: ldr             x1, [x1, #0x990]
    // 0xe0d73c: b               #0xe0d744
    // 0xe0d740: mov             x1, x0
    // 0xe0d744: r0 = LoadClassIdInstr(r1)
    //     0xe0d744: ldur            x0, [x1, #-1]
    //     0xe0d748: ubfx            x0, x0, #0xc, #0x14
    // 0xe0d74c: r0 = GDT[cid_x0 + -0xca9]()
    //     0xe0d74c: sub             lr, x0, #0xca9
    //     0xe0d750: ldr             lr, [x21, lr, lsl #3]
    //     0xe0d754: blr             lr
    // 0xe0d758: LeaveFrame
    //     0xe0d758: mov             SP, fp
    //     0xe0d75c: ldp             fp, lr, [SP], #0x10
    // 0xe0d760: ret
    //     0xe0d760: ret             
    // 0xe0d764: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe0d764: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe0d768: b               #0xe0d718
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x1134f3c, size: 0x50
    // 0x1134f3c: EnterFrame
    //     0x1134f3c: stp             fp, lr, [SP, #-0x10]!
    //     0x1134f40: mov             fp, SP
    // 0x1134f44: CheckStackOverflow
    //     0x1134f44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1134f48: cmp             SP, x16
    //     0x1134f4c: b.ls            #0x1134f84
    // 0x1134f50: ldr             x1, [fp, #0x10]
    // 0x1134f54: r0 = _all()
    //     0x1134f54: bl              #0x1134f8c  ; [package:flutter/src/material/page_transitions_theme.dart] PageTransitionsTheme::_all
    // 0x1134f58: mov             x1, x0
    // 0x1134f5c: r0 = hashAll()
    //     0x1134f5c: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x1134f60: mov             x2, x0
    // 0x1134f64: r0 = BoxInt64Instr(r2)
    //     0x1134f64: sbfiz           x0, x2, #1, #0x1f
    //     0x1134f68: cmp             x2, x0, asr #1
    //     0x1134f6c: b.eq            #0x1134f78
    //     0x1134f70: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1134f74: stur            x2, [x0, #7]
    // 0x1134f78: LeaveFrame
    //     0x1134f78: mov             SP, fp
    //     0x1134f7c: ldp             fp, lr, [SP], #0x10
    // 0x1134f80: ret
    //     0x1134f80: ret             
    // 0x1134f84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1134f84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1134f88: b               #0x1134f50
  }
  _ _all(/* No info */) {
    // ** addr: 0x1134f8c, size: 0x144
    // 0x1134f8c: EnterFrame
    //     0x1134f8c: stp             fp, lr, [SP, #-0x10]!
    //     0x1134f90: mov             fp, SP
    // 0x1134f94: AllocStack(0x28)
    //     0x1134f94: sub             SP, SP, #0x28
    // 0x1134f98: CheckStackOverflow
    //     0x1134f98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1134f9c: cmp             SP, x16
    //     0x1134fa0: b.ls            #0x11350c8
    // 0x1134fa4: r1 = Function '<anonymous closure>':.
    //     0x1134fa4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26ad8] AnonymousClosure: (0x11350d0), in [package:flutter/src/material/page_transitions_theme.dart] PageTransitionsTheme::_all (0x1134f8c)
    //     0x1134fa8: ldr             x1, [x1, #0xad8]
    // 0x1134fac: r2 = Null
    //     0x1134fac: mov             x2, NULL
    // 0x1134fb0: r0 = AllocateClosure()
    //     0x1134fb0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1134fb4: r16 = <PageTransitionsBuilder?>
    //     0x1134fb4: add             x16, PP, #0x26, lsl #12  ; [pp+0x26ae0] TypeArguments: <PageTransitionsBuilder?>
    //     0x1134fb8: ldr             x16, [x16, #0xae0]
    // 0x1134fbc: r30 = const [Instance of 'TargetPlatform', Instance of 'TargetPlatform', Instance of 'TargetPlatform', Instance of 'TargetPlatform', Instance of 'TargetPlatform', Instance of 'TargetPlatform']
    //     0x1134fbc: add             lr, PP, #0x26, lsl #12  ; [pp+0x26ae8] List<TargetPlatform>(6)
    //     0x1134fc0: ldr             lr, [lr, #0xae8]
    // 0x1134fc4: stp             lr, x16, [SP, #8]
    // 0x1134fc8: str             x0, [SP]
    // 0x1134fcc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1134fcc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1134fd0: r0 = map()
    //     0x1134fd0: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0x1134fd4: mov             x3, x0
    // 0x1134fd8: stur            x3, [fp, #-0x10]
    // 0x1134fdc: LoadField: r4 = r3->field_7
    //     0x1134fdc: ldur            w4, [x3, #7]
    // 0x1134fe0: DecompressPointer r4
    //     0x1134fe0: add             x4, x4, HEAP, lsl #32
    // 0x1134fe4: mov             x0, x3
    // 0x1134fe8: stur            x4, [fp, #-8]
    // 0x1134fec: r2 = Null
    //     0x1134fec: mov             x2, NULL
    // 0x1134ff0: r1 = Null
    //     0x1134ff0: mov             x1, NULL
    // 0x1134ff4: cmp             w0, NULL
    // 0x1134ff8: b.eq            #0x1135090
    // 0x1134ffc: branchIfSmi(r0, 0x1135090)
    //     0x1134ffc: tbz             w0, #0, #0x1135090
    // 0x1135000: r3 = LoadClassIdInstr(r0)
    //     0x1135000: ldur            x3, [x0, #-1]
    //     0x1135004: ubfx            x3, x3, #0xc, #0x14
    // 0x1135008: r17 = 7724
    //     0x1135008: mov             x17, #0x1e2c
    // 0x113500c: cmp             x3, x17
    // 0x1135010: b.eq            #0x1135098
    // 0x1135014: r4 = LoadClassIdInstr(r0)
    //     0x1135014: ldur            x4, [x0, #-1]
    //     0x1135018: ubfx            x4, x4, #0xc, #0x14
    // 0x113501c: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x1135020: ldr             x3, [x3, #0x18]
    // 0x1135024: ldr             x3, [x3, x4, lsl #3]
    // 0x1135028: LoadField: r3 = r3->field_2b
    //     0x1135028: ldur            w3, [x3, #0x2b]
    // 0x113502c: DecompressPointer r3
    //     0x113502c: add             x3, x3, HEAP, lsl #32
    // 0x1135030: cmp             w3, NULL
    // 0x1135034: b.eq            #0x1135090
    // 0x1135038: LoadField: r3 = r3->field_f
    //     0x1135038: ldur            w3, [x3, #0xf]
    // 0x113503c: lsr             x3, x3, #3
    // 0x1135040: r17 = 7724
    //     0x1135040: mov             x17, #0x1e2c
    // 0x1135044: cmp             x3, x17
    // 0x1135048: b.eq            #0x1135098
    // 0x113504c: r3 = SubtypeTestCache
    //     0x113504c: add             x3, PP, #0x26, lsl #12  ; [pp+0x26af0] SubtypeTestCache
    //     0x1135050: ldr             x3, [x3, #0xaf0]
    // 0x1135054: r30 = Subtype1TestCacheStub
    //     0x1135054: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x1135058: LoadField: r30 = r30->field_7
    //     0x1135058: ldur            lr, [lr, #7]
    // 0x113505c: blr             lr
    // 0x1135060: cmp             w7, NULL
    // 0x1135064: b.eq            #0x1135070
    // 0x1135068: tbnz            w7, #4, #0x1135090
    // 0x113506c: b               #0x1135098
    // 0x1135070: r8 = EfficientLengthIterable
    //     0x1135070: add             x8, PP, #0x26, lsl #12  ; [pp+0x26af8] Type: EfficientLengthIterable
    //     0x1135074: ldr             x8, [x8, #0xaf8]
    // 0x1135078: r3 = SubtypeTestCache
    //     0x1135078: add             x3, PP, #0x26, lsl #12  ; [pp+0x26b00] SubtypeTestCache
    //     0x113507c: ldr             x3, [x3, #0xb00]
    // 0x1135080: r30 = InstanceOfStub
    //     0x1135080: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x1135084: LoadField: r30 = r30->field_7
    //     0x1135084: ldur            lr, [lr, #7]
    // 0x1135088: blr             lr
    // 0x113508c: b               #0x113509c
    // 0x1135090: r0 = false
    //     0x1135090: add             x0, NULL, #0x30  ; false
    // 0x1135094: b               #0x113509c
    // 0x1135098: r0 = true
    //     0x1135098: add             x0, NULL, #0x20  ; true
    // 0x113509c: tbnz            w0, #4, #0x11350b0
    // 0x11350a0: ldur            x1, [fp, #-8]
    // 0x11350a4: ldur            x2, [fp, #-0x10]
    // 0x11350a8: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x11350a8: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x11350ac: b               #0x11350bc
    // 0x11350b0: ldur            x1, [fp, #-8]
    // 0x11350b4: ldur            x2, [fp, #-0x10]
    // 0x11350b8: r0 = _GrowableList._ofOther()
    //     0x11350b8: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0x11350bc: LeaveFrame
    //     0x11350bc: mov             SP, fp
    //     0x11350c0: ldp             fp, lr, [SP], #0x10
    // 0x11350c4: ret
    //     0x11350c4: ret             
    // 0x11350c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11350c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11350cc: b               #0x1134fa4
  }
  [closure] PageTransitionsBuilder? <anonymous closure>(dynamic, TargetPlatform) {
    // ** addr: 0x11350d0, size: 0x38
    // 0x11350d0: EnterFrame
    //     0x11350d0: stp             fp, lr, [SP, #-0x10]!
    //     0x11350d4: mov             fp, SP
    // 0x11350d8: CheckStackOverflow
    //     0x11350d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11350dc: cmp             SP, x16
    //     0x11350e0: b.ls            #0x1135100
    // 0x11350e4: ldr             x2, [fp, #0x10]
    // 0x11350e8: r1 = _ConstMap len:5
    //     0x11350e8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26b08] Map<TargetPlatform, PageTransitionsBuilder>(5)
    //     0x11350ec: ldr             x1, [x1, #0xb08]
    // 0x11350f0: r0 = []()
    //     0x11350f0: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x11350f4: LeaveFrame
    //     0x11350f4: mov             SP, fp
    //     0x11350f8: ldp             fp, lr, [SP], #0x10
    // 0x11350fc: ret
    //     0x11350fc: ret             
    // 0x1135100: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1135100: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1135104: b               #0x11350e4
  }
  _ ==(/* No info */) {
    // ** addr: 0x12701fc, size: 0x118
    // 0x12701fc: EnterFrame
    //     0x12701fc: stp             fp, lr, [SP, #-0x10]!
    //     0x1270200: mov             fp, SP
    // 0x1270204: AllocStack(0x20)
    //     0x1270204: sub             SP, SP, #0x20
    // 0x1270208: CheckStackOverflow
    //     0x1270208: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x127020c: cmp             SP, x16
    //     0x1270210: b.ls            #0x127030c
    // 0x1270214: ldr             x0, [fp, #0x10]
    // 0x1270218: cmp             w0, NULL
    // 0x127021c: b.ne            #0x1270230
    // 0x1270220: r0 = false
    //     0x1270220: add             x0, NULL, #0x30  ; false
    // 0x1270224: LeaveFrame
    //     0x1270224: mov             SP, fp
    //     0x1270228: ldp             fp, lr, [SP], #0x10
    // 0x127022c: ret
    //     0x127022c: ret             
    // 0x1270230: ldr             x1, [fp, #0x18]
    // 0x1270234: cmp             w1, w0
    // 0x1270238: b.ne            #0x127024c
    // 0x127023c: r0 = true
    //     0x127023c: add             x0, NULL, #0x20  ; true
    // 0x1270240: LeaveFrame
    //     0x1270240: mov             SP, fp
    //     0x1270244: ldp             fp, lr, [SP], #0x10
    // 0x1270248: ret
    //     0x1270248: ret             
    // 0x127024c: str             x0, [SP]
    // 0x1270250: r0 = runtimeType()
    //     0x1270250: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1270254: r1 = LoadClassIdInstr(r0)
    //     0x1270254: ldur            x1, [x0, #-1]
    //     0x1270258: ubfx            x1, x1, #0xc, #0x14
    // 0x127025c: r16 = PageTransitionsTheme
    //     0x127025c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26b10] Type: PageTransitionsTheme
    //     0x1270260: ldr             x16, [x16, #0xb10]
    // 0x1270264: stp             x16, x0, [SP]
    // 0x1270268: mov             x0, x1
    // 0x127026c: mov             lr, x0
    // 0x1270270: ldr             lr, [x21, lr, lsl #3]
    // 0x1270274: blr             lr
    // 0x1270278: tbz             w0, #4, #0x127028c
    // 0x127027c: r0 = false
    //     0x127027c: add             x0, NULL, #0x30  ; false
    // 0x1270280: LeaveFrame
    //     0x1270280: mov             SP, fp
    //     0x1270284: ldp             fp, lr, [SP], #0x10
    // 0x1270288: ret
    //     0x1270288: ret             
    // 0x127028c: ldr             x0, [fp, #0x10]
    // 0x1270290: r1 = 60
    //     0x1270290: mov             x1, #0x3c
    // 0x1270294: branchIfSmi(r0, 0x12702a0)
    //     0x1270294: tbz             w0, #0, #0x12702a0
    // 0x1270298: r1 = LoadClassIdInstr(r0)
    //     0x1270298: ldur            x1, [x0, #-1]
    //     0x127029c: ubfx            x1, x1, #0xc, #0x14
    // 0x12702a0: r17 = 5132
    //     0x12702a0: mov             x17, #0x140c
    // 0x12702a4: cmp             x1, x17
    // 0x12702a8: b.ne            #0x12702bc
    // 0x12702ac: r0 = true
    //     0x12702ac: add             x0, NULL, #0x20  ; true
    // 0x12702b0: LeaveFrame
    //     0x12702b0: mov             SP, fp
    //     0x12702b4: ldp             fp, lr, [SP], #0x10
    // 0x12702b8: ret
    //     0x12702b8: ret             
    // 0x12702bc: r17 = 5132
    //     0x12702bc: mov             x17, #0x140c
    // 0x12702c0: cmp             x1, x17
    // 0x12702c4: b.ne            #0x12702fc
    // 0x12702c8: ldr             x1, [fp, #0x18]
    // 0x12702cc: r0 = _all()
    //     0x12702cc: bl              #0x1134f8c  ; [package:flutter/src/material/page_transitions_theme.dart] PageTransitionsTheme::_all
    // 0x12702d0: ldr             x1, [fp, #0x18]
    // 0x12702d4: stur            x0, [fp, #-8]
    // 0x12702d8: r0 = _all()
    //     0x12702d8: bl              #0x1134f8c  ; [package:flutter/src/material/page_transitions_theme.dart] PageTransitionsTheme::_all
    // 0x12702dc: r16 = <PageTransitionsBuilder?>
    //     0x12702dc: add             x16, PP, #0x26, lsl #12  ; [pp+0x26ae0] TypeArguments: <PageTransitionsBuilder?>
    //     0x12702e0: ldr             x16, [x16, #0xae0]
    // 0x12702e4: ldur            lr, [fp, #-8]
    // 0x12702e8: stp             lr, x16, [SP, #8]
    // 0x12702ec: str             x0, [SP]
    // 0x12702f0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x12702f0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x12702f4: r0 = listEquals()
    //     0x12702f4: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x12702f8: b               #0x1270300
    // 0x12702fc: r0 = false
    //     0x12702fc: add             x0, NULL, #0x30  ; false
    // 0x1270300: LeaveFrame
    //     0x1270300: mov             SP, fp
    //     0x1270304: ldp             fp, lr, [SP], #0x10
    // 0x1270308: ret
    //     0x1270308: ret             
    // 0x127030c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x127030c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1270310: b               #0x1270214
  }
}

// class id: 5463, size: 0x18, field offset: 0x14
class _PageTransitionsThemeTransitionsState<C1X0> extends State<C1X0> {

  _ build(/* No info */) {
    // ** addr: 0xdf7e4c, size: 0x210
    // 0xdf7e4c: EnterFrame
    //     0xdf7e4c: stp             fp, lr, [SP, #-0x10]!
    //     0xdf7e50: mov             fp, SP
    // 0xdf7e54: AllocStack(0x40)
    //     0xdf7e54: sub             SP, SP, #0x40
    // 0xdf7e58: SetupParameters(_PageTransitionsThemeTransitionsState<C1X0> this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xdf7e58: mov             x0, x1
    //     0xdf7e5c: stur            x1, [fp, #-8]
    //     0xdf7e60: mov             x1, x2
    // 0xdf7e64: CheckStackOverflow
    //     0xdf7e64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf7e68: cmp             SP, x16
    //     0xdf7e6c: b.ls            #0xdf8048
    // 0xdf7e70: r0 = of()
    //     0xdf7e70: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdf7e74: ldur            x2, [fp, #-8]
    // 0xdf7e78: LoadField: r0 = r2->field_b
    //     0xdf7e78: ldur            w0, [x2, #0xb]
    // 0xdf7e7c: DecompressPointer r0
    //     0xdf7e7c: add             x0, x0, HEAP, lsl #32
    // 0xdf7e80: cmp             w0, NULL
    // 0xdf7e84: b.eq            #0xdf8050
    // 0xdf7e88: LoadField: r1 = r0->field_13
    //     0xdf7e88: ldur            w1, [x0, #0x13]
    // 0xdf7e8c: DecompressPointer r1
    //     0xdf7e8c: add             x1, x1, HEAP, lsl #32
    // 0xdf7e90: r0 = LoadClassIdInstr(r1)
    //     0xdf7e90: ldur            x0, [x1, #-1]
    //     0xdf7e94: ubfx            x0, x0, #0xc, #0x14
    // 0xdf7e98: r0 = GDT[cid_x0 + -0xd25]()
    //     0xdf7e98: sub             lr, x0, #0xd25
    //     0xdf7e9c: ldr             lr, [x21, lr, lsl #3]
    //     0xdf7ea0: blr             lr
    // 0xdf7ea4: tbnz            w0, #4, #0xdf7ed8
    // 0xdf7ea8: ldur            x0, [fp, #-8]
    // 0xdf7eac: LoadField: r1 = r0->field_13
    //     0xdf7eac: ldur            w1, [x0, #0x13]
    // 0xdf7eb0: DecompressPointer r1
    //     0xdf7eb0: add             x1, x1, HEAP, lsl #32
    // 0xdf7eb4: cmp             w1, NULL
    // 0xdf7eb8: b.ne            #0xdf7ed0
    // 0xdf7ebc: r1 = Instance_TargetPlatform
    //     0xdf7ebc: add             x1, PP, #0x12, lsl #12  ; [pp+0x12940] Obj!TargetPlatform@12c5e81
    //     0xdf7ec0: ldr             x1, [x1, #0x940]
    // 0xdf7ec4: StoreField: r0->field_13 = r1
    //     0xdf7ec4: stur            w1, [x0, #0x13]
    // 0xdf7ec8: r1 = Instance_TargetPlatform
    //     0xdf7ec8: add             x1, PP, #0x12, lsl #12  ; [pp+0x12940] Obj!TargetPlatform@12c5e81
    //     0xdf7ecc: ldr             x1, [x1, #0x940]
    // 0xdf7ed0: mov             x3, x1
    // 0xdf7ed4: b               #0xdf7ee8
    // 0xdf7ed8: ldur            x0, [fp, #-8]
    // 0xdf7edc: StoreField: r0->field_13 = rNULL
    //     0xdf7edc: stur            NULL, [x0, #0x13]
    // 0xdf7ee0: r3 = Instance_TargetPlatform
    //     0xdf7ee0: add             x3, PP, #0x12, lsl #12  ; [pp+0x12940] Obj!TargetPlatform@12c5e81
    //     0xdf7ee4: ldr             x3, [x3, #0x940]
    // 0xdf7ee8: stur            x3, [fp, #-0x10]
    // 0xdf7eec: LoadField: r1 = r0->field_b
    //     0xdf7eec: ldur            w1, [x0, #0xb]
    // 0xdf7ef0: DecompressPointer r1
    //     0xdf7ef0: add             x1, x1, HEAP, lsl #32
    // 0xdf7ef4: cmp             w1, NULL
    // 0xdf7ef8: b.eq            #0xdf8054
    // 0xdf7efc: mov             x2, x3
    // 0xdf7f00: r1 = _ConstMap len:5
    //     0xdf7f00: add             x1, PP, #0x26, lsl #12  ; [pp+0x26b08] Map<TargetPlatform, PageTransitionsBuilder>(5)
    //     0xdf7f04: ldr             x1, [x1, #0xb08]
    // 0xdf7f08: r0 = []()
    //     0xdf7f08: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0xdf7f0c: cmp             w0, NULL
    // 0xdf7f10: b.ne            #0xdf7f9c
    // 0xdf7f14: ldur            x0, [fp, #-0x10]
    // 0xdf7f18: r16 = Instance_TargetPlatform
    //     0xdf7f18: add             x16, PP, #0xad, lsl #12  ; [pp+0xadcc0] Obj!TargetPlatform@12c5f01
    //     0xdf7f1c: ldr             x16, [x16, #0xcc0]
    // 0xdf7f20: cmp             w0, w16
    // 0xdf7f24: b.ne            #0xdf7f34
    // 0xdf7f28: r0 = Instance_CupertinoPageTransitionsBuilder
    //     0xdf7f28: add             x0, PP, #0xad, lsl #12  ; [pp+0xadcc8] Obj!CupertinoPageTransitionsBuilder@129f321
    //     0xdf7f2c: ldr             x0, [x0, #0xcc8]
    // 0xdf7f30: b               #0xdf7f94
    // 0xdf7f34: r16 = Instance_TargetPlatform
    //     0xdf7f34: add             x16, PP, #0x12, lsl #12  ; [pp+0x12940] Obj!TargetPlatform@12c5e81
    //     0xdf7f38: ldr             x16, [x16, #0x940]
    // 0xdf7f3c: cmp             w0, w16
    // 0xdf7f40: b.eq            #0xdf7f84
    // 0xdf7f44: r16 = Instance_TargetPlatform
    //     0xdf7f44: add             x16, PP, #0xad, lsl #12  ; [pp+0xadcd0] Obj!TargetPlatform@12c5f21
    //     0xdf7f48: ldr             x16, [x16, #0xcd0]
    // 0xdf7f4c: cmp             w0, w16
    // 0xdf7f50: b.eq            #0xdf7f84
    // 0xdf7f54: r16 = Instance_TargetPlatform
    //     0xdf7f54: add             x16, PP, #0xad, lsl #12  ; [pp+0xadcd8] Obj!TargetPlatform@12c5ec1
    //     0xdf7f58: ldr             x16, [x16, #0xcd8]
    // 0xdf7f5c: cmp             w0, w16
    // 0xdf7f60: b.eq            #0xdf7f84
    // 0xdf7f64: r16 = Instance_TargetPlatform
    //     0xdf7f64: add             x16, PP, #0xad, lsl #12  ; [pp+0xadce0] Obj!TargetPlatform@12c5ee1
    //     0xdf7f68: ldr             x16, [x16, #0xce0]
    // 0xdf7f6c: cmp             w0, w16
    // 0xdf7f70: b.eq            #0xdf7f84
    // 0xdf7f74: r16 = Instance_TargetPlatform
    //     0xdf7f74: add             x16, PP, #0xad, lsl #12  ; [pp+0xadce8] Obj!TargetPlatform@12c5ea1
    //     0xdf7f78: ldr             x16, [x16, #0xce8]
    // 0xdf7f7c: cmp             w0, w16
    // 0xdf7f80: b.ne            #0xdf7f90
    // 0xdf7f84: r0 = Instance_ZoomPageTransitionsBuilder
    //     0xdf7f84: add             x0, PP, #0x90, lsl #12  ; [pp+0x90990] Obj!ZoomPageTransitionsBuilder@129f301
    //     0xdf7f88: ldr             x0, [x0, #0x990]
    // 0xdf7f8c: b               #0xdf7f94
    // 0xdf7f90: r0 = Null
    //     0xdf7f90: mov             x0, NULL
    // 0xdf7f94: mov             x4, x0
    // 0xdf7f98: b               #0xdf7fa0
    // 0xdf7f9c: mov             x4, x0
    // 0xdf7fa0: ldur            x0, [fp, #-8]
    // 0xdf7fa4: stur            x4, [fp, #-0x10]
    // 0xdf7fa8: LoadField: r2 = r0->field_7
    //     0xdf7fa8: ldur            w2, [x0, #7]
    // 0xdf7fac: DecompressPointer r2
    //     0xdf7fac: add             x2, x2, HEAP, lsl #32
    // 0xdf7fb0: r1 = Null
    //     0xdf7fb0: mov             x1, NULL
    // 0xdf7fb4: r3 = <C1X0>
    //     0xdf7fb4: add             x3, PP, #0x11, lsl #12  ; [pp+0x11880] TypeArguments: <C1X0>
    //     0xdf7fb8: ldr             x3, [x3, #0x880]
    // 0xdf7fbc: r0 = Null
    //     0xdf7fbc: mov             x0, NULL
    // 0xdf7fc0: cmp             x2, x0
    // 0xdf7fc4: b.eq            #0xdf7fd4
    // 0xdf7fc8: r30 = InstantiateTypeArgumentsStub
    //     0xdf7fc8: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xdf7fcc: LoadField: r30 = r30->field_7
    //     0xdf7fcc: ldur            lr, [lr, #7]
    // 0xdf7fd0: blr             lr
    // 0xdf7fd4: mov             x1, x0
    // 0xdf7fd8: ldur            x0, [fp, #-8]
    // 0xdf7fdc: LoadField: r2 = r0->field_b
    //     0xdf7fdc: ldur            w2, [x0, #0xb]
    // 0xdf7fe0: DecompressPointer r2
    //     0xdf7fe0: add             x2, x2, HEAP, lsl #32
    // 0xdf7fe4: cmp             w2, NULL
    // 0xdf7fe8: b.eq            #0xdf8058
    // 0xdf7fec: LoadField: r0 = r2->field_13
    //     0xdf7fec: ldur            w0, [x2, #0x13]
    // 0xdf7ff0: DecompressPointer r0
    //     0xdf7ff0: add             x0, x0, HEAP, lsl #32
    // 0xdf7ff4: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xdf7ff4: ldur            w3, [x2, #0x17]
    // 0xdf7ff8: DecompressPointer r3
    //     0xdf7ff8: add             x3, x3, HEAP, lsl #32
    // 0xdf7ffc: LoadField: r4 = r2->field_1b
    //     0xdf7ffc: ldur            w4, [x2, #0x1b]
    // 0xdf8000: DecompressPointer r4
    //     0xdf8000: add             x4, x4, HEAP, lsl #32
    // 0xdf8004: LoadField: r5 = r2->field_1f
    //     0xdf8004: ldur            w5, [x2, #0x1f]
    // 0xdf8008: DecompressPointer r5
    //     0xdf8008: add             x5, x5, HEAP, lsl #32
    // 0xdf800c: ldur            x2, [fp, #-0x10]
    // 0xdf8010: r6 = LoadClassIdInstr(r2)
    //     0xdf8010: ldur            x6, [x2, #-1]
    //     0xdf8014: ubfx            x6, x6, #0xc, #0x14
    // 0xdf8018: stp             x2, x1, [SP, #0x20]
    // 0xdf801c: stp             x3, x0, [SP, #0x10]
    // 0xdf8020: stp             x5, x4, [SP]
    // 0xdf8024: mov             x0, x6
    // 0xdf8028: r4 = const [0x1, 0x5, 0x5, 0x5, null]
    //     0xdf8028: ldr             x4, [PP, #0x570]  ; [pp+0x570] List(5) [0x1, 0x5, 0x5, 0x5, Null]
    // 0xdf802c: r0 = GDT[cid_x0 + 0x2c26]()
    //     0xdf802c: mov             x17, #0x2c26
    //     0xdf8030: add             lr, x0, x17
    //     0xdf8034: ldr             lr, [x21, lr, lsl #3]
    //     0xdf8038: blr             lr
    // 0xdf803c: LeaveFrame
    //     0xdf803c: mov             SP, fp
    //     0xdf8040: ldp             fp, lr, [SP], #0x10
    // 0xdf8044: ret
    //     0xdf8044: ret             
    // 0xdf8048: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf8048: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf804c: b               #0xdf7e70
    // 0xdf8050: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf8050: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf8054: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf8054: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf8058: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf8058: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5729, size: 0x24, field offset: 0x20
class _ZoomExitTransitionState extends _MixinApplication87&State&_ZoomTransitionBase {

  late _ZoomExitTransitionPainter delegate; // offset: 0x20
  static late final Animatable<double> _fadeOutTransition; // offset: 0x720
  static late final Animatable<double> _scaleDownTransition; // offset: 0x728
  static late final Animatable<double> _scaleUpTransition; // offset: 0x724

  _ build(/* No info */) {
    // ** addr: 0xd2fa74, size: 0x98
    // 0xd2fa74: EnterFrame
    //     0xd2fa74: stp             fp, lr, [SP, #-0x10]!
    //     0xd2fa78: mov             fp, SP
    // 0xd2fa7c: AllocStack(0x18)
    //     0xd2fa7c: sub             SP, SP, #0x18
    // 0xd2fa80: LoadField: r0 = r1->field_1f
    //     0xd2fa80: ldur            w0, [x1, #0x1f]
    // 0xd2fa84: DecompressPointer r0
    //     0xd2fa84: add             x0, x0, HEAP, lsl #32
    // 0xd2fa88: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd2fa8c: cmp             w0, w16
    // 0xd2fa90: b.eq            #0xd2fafc
    // 0xd2fa94: stur            x0, [fp, #-0x18]
    // 0xd2fa98: LoadField: r2 = r1->field_13
    //     0xd2fa98: ldur            w2, [x1, #0x13]
    // 0xd2fa9c: DecompressPointer r2
    //     0xd2fa9c: add             x2, x2, HEAP, lsl #32
    // 0xd2faa0: stur            x2, [fp, #-0x10]
    // 0xd2faa4: LoadField: r3 = r1->field_b
    //     0xd2faa4: ldur            w3, [x1, #0xb]
    // 0xd2faa8: DecompressPointer r3
    //     0xd2faa8: add             x3, x3, HEAP, lsl #32
    // 0xd2faac: cmp             w3, NULL
    // 0xd2fab0: b.eq            #0xd2fb08
    // 0xd2fab4: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xd2fab4: ldur            w1, [x3, #0x17]
    // 0xd2fab8: DecompressPointer r1
    //     0xd2fab8: add             x1, x1, HEAP, lsl #32
    // 0xd2fabc: stur            x1, [fp, #-8]
    // 0xd2fac0: r0 = SnapshotWidget()
    //     0xd2fac0: bl              #0xd2fa68  ; AllocateSnapshotWidgetStub -> SnapshotWidget (size=0x20)
    // 0xd2fac4: r1 = Instance_SnapshotMode
    //     0xd2fac4: add             x1, PP, #0xad, lsl #12  ; [pp+0xadb80] Obj!SnapshotMode@12c2561
    //     0xd2fac8: ldr             x1, [x1, #0xb80]
    // 0xd2facc: StoreField: r0->field_13 = r1
    //     0xd2facc: stur            w1, [x0, #0x13]
    // 0xd2fad0: ldur            x1, [fp, #-0x18]
    // 0xd2fad4: StoreField: r0->field_1b = r1
    //     0xd2fad4: stur            w1, [x0, #0x1b]
    // 0xd2fad8: r1 = true
    //     0xd2fad8: add             x1, NULL, #0x20  ; true
    // 0xd2fadc: ArrayStore: r0[0] = r1  ; List_4
    //     0xd2fadc: stur            w1, [x0, #0x17]
    // 0xd2fae0: ldur            x1, [fp, #-0x10]
    // 0xd2fae4: StoreField: r0->field_f = r1
    //     0xd2fae4: stur            w1, [x0, #0xf]
    // 0xd2fae8: ldur            x1, [fp, #-8]
    // 0xd2faec: StoreField: r0->field_b = r1
    //     0xd2faec: stur            w1, [x0, #0xb]
    // 0xd2faf0: LeaveFrame
    //     0xd2faf0: mov             SP, fp
    //     0xd2faf4: ldp             fp, lr, [SP], #0x10
    // 0xd2faf8: ret
    //     0xd2faf8: ret             
    // 0xd2fafc: r9 = delegate
    //     0xd2fafc: add             x9, PP, #0xad, lsl #12  ; [pp+0xadc40] Field <_ZoomExitTransitionState@110490068.delegate>: late (offset: 0x20)
    //     0xd2fb00: ldr             x9, [x9, #0xc40]
    // 0xd2fb04: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd2fb04: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd2fb08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2fb08: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf3afac, size: 0x26c
    // 0xf3afac: EnterFrame
    //     0xf3afac: stp             fp, lr, [SP, #-0x10]!
    //     0xf3afb0: mov             fp, SP
    // 0xf3afb4: AllocStack(0x30)
    //     0xf3afb4: sub             SP, SP, #0x30
    // 0xf3afb8: SetupParameters(_ZoomExitTransitionState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf3afb8: mov             x4, x1
    //     0xf3afbc: mov             x3, x2
    //     0xf3afc0: stur            x1, [fp, #-8]
    //     0xf3afc4: stur            x2, [fp, #-0x10]
    // 0xf3afc8: CheckStackOverflow
    //     0xf3afc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3afcc: cmp             SP, x16
    //     0xf3afd0: b.ls            #0xf3b1e4
    // 0xf3afd4: mov             x0, x3
    // 0xf3afd8: r2 = Null
    //     0xf3afd8: mov             x2, NULL
    // 0xf3afdc: r1 = Null
    //     0xf3afdc: mov             x1, NULL
    // 0xf3afe0: r4 = 60
    //     0xf3afe0: mov             x4, #0x3c
    // 0xf3afe4: branchIfSmi(r0, 0xf3aff0)
    //     0xf3afe4: tbz             w0, #0, #0xf3aff0
    // 0xf3afe8: r4 = LoadClassIdInstr(r0)
    //     0xf3afe8: ldur            x4, [x0, #-1]
    //     0xf3afec: ubfx            x4, x4, #0xc, #0x14
    // 0xf3aff0: r17 = 6455
    //     0xf3aff0: mov             x17, #0x1937
    // 0xf3aff4: cmp             x4, x17
    // 0xf3aff8: b.eq            #0xf3b010
    // 0xf3affc: r8 = _ZoomExitTransition
    //     0xf3affc: add             x8, PP, #0xad, lsl #12  ; [pp+0xadc70] Type: _ZoomExitTransition
    //     0xf3b000: ldr             x8, [x8, #0xc70]
    // 0xf3b004: r3 = Null
    //     0xf3b004: add             x3, PP, #0xad, lsl #12  ; [pp+0xadc78] Null
    //     0xf3b008: ldr             x3, [x3, #0xc78]
    // 0xf3b00c: r0 = _ZoomExitTransition()
    //     0xf3b00c: bl              #0xd2fb0c  ; IsType__ZoomExitTransition_Stub
    // 0xf3b010: ldur            x0, [fp, #-0x10]
    // 0xf3b014: LoadField: r1 = r0->field_13
    //     0xf3b014: ldur            w1, [x0, #0x13]
    // 0xf3b018: DecompressPointer r1
    //     0xf3b018: add             x1, x1, HEAP, lsl #32
    // 0xf3b01c: ldur            x3, [fp, #-8]
    // 0xf3b020: LoadField: r2 = r3->field_b
    //     0xf3b020: ldur            w2, [x3, #0xb]
    // 0xf3b024: DecompressPointer r2
    //     0xf3b024: add             x2, x2, HEAP, lsl #32
    // 0xf3b028: cmp             w2, NULL
    // 0xf3b02c: b.eq            #0xf3b1ec
    // 0xf3b030: LoadField: r4 = r2->field_13
    //     0xf3b030: ldur            w4, [x2, #0x13]
    // 0xf3b034: DecompressPointer r4
    //     0xf3b034: add             x4, x4, HEAP, lsl #32
    // 0xf3b038: cmp             w1, w4
    // 0xf3b03c: b.ne            #0xf3b058
    // 0xf3b040: LoadField: r1 = r0->field_b
    //     0xf3b040: ldur            w1, [x0, #0xb]
    // 0xf3b044: DecompressPointer r1
    //     0xf3b044: add             x1, x1, HEAP, lsl #32
    // 0xf3b048: LoadField: r4 = r2->field_b
    //     0xf3b048: ldur            w4, [x2, #0xb]
    // 0xf3b04c: DecompressPointer r4
    //     0xf3b04c: add             x4, x4, HEAP, lsl #32
    // 0xf3b050: cmp             w1, w4
    // 0xf3b054: b.eq            #0xf3b198
    // 0xf3b058: LoadField: r4 = r0->field_b
    //     0xf3b058: ldur            w4, [x0, #0xb]
    // 0xf3b05c: DecompressPointer r4
    //     0xf3b05c: add             x4, x4, HEAP, lsl #32
    // 0xf3b060: mov             x2, x3
    // 0xf3b064: stur            x4, [fp, #-0x18]
    // 0xf3b068: r1 = Function 'onAnimationValueChange':.
    //     0xf3b068: add             x1, PP, #0xad, lsl #12  ; [pp+0xadc48] AnonymousClosure: (0xf3b894), in [dart:mixin_deduplication] _MixinApplication87&State&_ZoomTransitionBase::onAnimationValueChange (0xf3b8cc)
    //     0xf3b06c: ldr             x1, [x1, #0xc48]
    // 0xf3b070: r0 = AllocateClosure()
    //     0xf3b070: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf3b074: ldur            x3, [fp, #-0x18]
    // 0xf3b078: r1 = LoadClassIdInstr(r3)
    //     0xf3b078: ldur            x1, [x3, #-1]
    //     0xf3b07c: ubfx            x1, x1, #0xc, #0x14
    // 0xf3b080: mov             x2, x0
    // 0xf3b084: mov             x0, x1
    // 0xf3b088: mov             x1, x3
    // 0xf3b08c: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0xf3b08c: mov             x17, #0xe2a3
    //     0xf3b090: add             lr, x0, x17
    //     0xf3b094: ldr             lr, [x21, lr, lsl #3]
    //     0xf3b098: blr             lr
    // 0xf3b09c: ldur            x2, [fp, #-8]
    // 0xf3b0a0: r1 = Function 'onAnimationStatusChange':.
    //     0xf3b0a0: add             x1, PP, #0xad, lsl #12  ; [pp+0xadc50] AnonymousClosure: (0xf3b7c4), in [dart:mixin_deduplication] _MixinApplication87&State&_ZoomTransitionBase::onAnimationStatusChange (0xf3b800)
    //     0xf3b0a4: ldr             x1, [x1, #0xc50]
    // 0xf3b0a8: r0 = AllocateClosure()
    //     0xf3b0a8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf3b0ac: ldur            x1, [fp, #-0x18]
    // 0xf3b0b0: r2 = LoadClassIdInstr(r1)
    //     0xf3b0b0: ldur            x2, [x1, #-1]
    //     0xf3b0b4: ubfx            x2, x2, #0xc, #0x14
    // 0xf3b0b8: mov             x16, x0
    // 0xf3b0bc: mov             x0, x2
    // 0xf3b0c0: mov             x2, x16
    // 0xf3b0c4: r0 = GDT[cid_x0 + 0xabe]()
    //     0xf3b0c4: add             lr, x0, #0xabe
    //     0xf3b0c8: ldr             lr, [x21, lr, lsl #3]
    //     0xf3b0cc: blr             lr
    // 0xf3b0d0: ldur            x1, [fp, #-8]
    // 0xf3b0d4: r0 = _updateAnimations()
    //     0xf3b0d4: bl              #0xf3b42c  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionState::_updateAnimations
    // 0xf3b0d8: ldur            x0, [fp, #-8]
    // 0xf3b0dc: LoadField: r1 = r0->field_1f
    //     0xf3b0dc: ldur            w1, [x0, #0x1f]
    // 0xf3b0e0: DecompressPointer r1
    //     0xf3b0e0: add             x1, x1, HEAP, lsl #32
    // 0xf3b0e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3b0e8: cmp             w1, w16
    // 0xf3b0ec: b.eq            #0xf3b1f0
    // 0xf3b0f0: r0 = dispose()
    //     0xf3b0f0: bl              #0x10ef3b0  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionPainter::dispose
    // 0xf3b0f4: ldur            x0, [fp, #-8]
    // 0xf3b0f8: LoadField: r1 = r0->field_b
    //     0xf3b0f8: ldur            w1, [x0, #0xb]
    // 0xf3b0fc: DecompressPointer r1
    //     0xf3b0fc: add             x1, x1, HEAP, lsl #32
    // 0xf3b100: cmp             w1, NULL
    // 0xf3b104: b.eq            #0xf3b1fc
    // 0xf3b108: LoadField: r5 = r1->field_13
    //     0xf3b108: ldur            w5, [x1, #0x13]
    // 0xf3b10c: DecompressPointer r5
    //     0xf3b10c: add             x5, x5, HEAP, lsl #32
    // 0xf3b110: stur            x5, [fp, #-0x30]
    // 0xf3b114: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xf3b114: ldur            w3, [x0, #0x17]
    // 0xf3b118: DecompressPointer r3
    //     0xf3b118: add             x3, x3, HEAP, lsl #32
    // 0xf3b11c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3b120: cmp             w3, w16
    // 0xf3b124: b.eq            #0xf3b200
    // 0xf3b128: stur            x3, [fp, #-0x28]
    // 0xf3b12c: LoadField: r6 = r0->field_1b
    //     0xf3b12c: ldur            w6, [x0, #0x1b]
    // 0xf3b130: DecompressPointer r6
    //     0xf3b130: add             x6, x6, HEAP, lsl #32
    // 0xf3b134: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3b138: cmp             w6, w16
    // 0xf3b13c: b.eq            #0xf3b20c
    // 0xf3b140: stur            x6, [fp, #-0x20]
    // 0xf3b144: LoadField: r2 = r1->field_b
    //     0xf3b144: ldur            w2, [x1, #0xb]
    // 0xf3b148: DecompressPointer r2
    //     0xf3b148: add             x2, x2, HEAP, lsl #32
    // 0xf3b14c: stur            x2, [fp, #-0x18]
    // 0xf3b150: r0 = _ZoomExitTransitionPainter()
    //     0xf3b150: bl              #0xf3b420  ; Allocate_ZoomExitTransitionPainterStub -> _ZoomExitTransitionPainter (size=0x40)
    // 0xf3b154: mov             x1, x0
    // 0xf3b158: ldur            x2, [fp, #-0x18]
    // 0xf3b15c: ldur            x3, [fp, #-0x28]
    // 0xf3b160: ldur            x5, [fp, #-0x30]
    // 0xf3b164: ldur            x6, [fp, #-0x20]
    // 0xf3b168: stur            x0, [fp, #-0x18]
    // 0xf3b16c: r0 = _ZoomExitTransitionPainter()
    //     0xf3b16c: bl              #0xf3b218  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionPainter::_ZoomExitTransitionPainter
    // 0xf3b170: ldur            x0, [fp, #-0x18]
    // 0xf3b174: ldur            x1, [fp, #-8]
    // 0xf3b178: StoreField: r1->field_1f = r0
    //     0xf3b178: stur            w0, [x1, #0x1f]
    //     0xf3b17c: ldurb           w16, [x1, #-1]
    //     0xf3b180: ldurb           w17, [x0, #-1]
    //     0xf3b184: and             x16, x17, x16, lsr #2
    //     0xf3b188: tst             x16, HEAP, lsr #32
    //     0xf3b18c: b.eq            #0xf3b194
    //     0xf3b190: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf3b194: b               #0xf3b19c
    // 0xf3b198: mov             x1, x3
    // 0xf3b19c: LoadField: r2 = r1->field_7
    //     0xf3b19c: ldur            w2, [x1, #7]
    // 0xf3b1a0: DecompressPointer r2
    //     0xf3b1a0: add             x2, x2, HEAP, lsl #32
    // 0xf3b1a4: ldur            x0, [fp, #-0x10]
    // 0xf3b1a8: r1 = Null
    //     0xf3b1a8: mov             x1, NULL
    // 0xf3b1ac: cmp             w2, NULL
    // 0xf3b1b0: b.eq            #0xf3b1d4
    // 0xf3b1b4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf3b1b4: ldur            w4, [x2, #0x17]
    // 0xf3b1b8: DecompressPointer r4
    //     0xf3b1b8: add             x4, x4, HEAP, lsl #32
    // 0xf3b1bc: r8 = X0 bound StatefulWidget
    //     0xf3b1bc: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf3b1c0: ldr             x8, [x8, #0x498]
    // 0xf3b1c4: LoadField: r9 = r4->field_7
    //     0xf3b1c4: ldur            x9, [x4, #7]
    // 0xf3b1c8: r3 = Null
    //     0xf3b1c8: add             x3, PP, #0xad, lsl #12  ; [pp+0xadc88] Null
    //     0xf3b1cc: ldr             x3, [x3, #0xc88]
    // 0xf3b1d0: blr             x9
    // 0xf3b1d4: r0 = Null
    //     0xf3b1d4: mov             x0, NULL
    // 0xf3b1d8: LeaveFrame
    //     0xf3b1d8: mov             SP, fp
    //     0xf3b1dc: ldp             fp, lr, [SP], #0x10
    // 0xf3b1e0: ret
    //     0xf3b1e0: ret             
    // 0xf3b1e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3b1e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3b1e8: b               #0xf3afd4
    // 0xf3b1ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3b1ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3b1f0: r9 = delegate
    //     0xf3b1f0: add             x9, PP, #0xad, lsl #12  ; [pp+0xadc40] Field <_ZoomExitTransitionState@110490068.delegate>: late (offset: 0x20)
    //     0xf3b1f4: ldr             x9, [x9, #0xc40]
    // 0xf3b1f8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3b1f8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf3b1fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3b1fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3b200: r9 = fadeTransition
    //     0xf3b200: add             x9, PP, #0xad, lsl #12  ; [pp+0xadc60] Field <_MixinApplication87&State&_ZoomTransitionBase@18353248.fadeTransition>: late (offset: 0x18)
    //     0xf3b204: ldr             x9, [x9, #0xc60]
    // 0xf3b208: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3b208: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf3b20c: r9 = scaleTransition
    //     0xf3b20c: add             x9, PP, #0xad, lsl #12  ; [pp+0xadc58] Field <_MixinApplication87&State&_ZoomTransitionBase@18353248.scaleTransition>: late (offset: 0x1c)
    //     0xf3b210: ldr             x9, [x9, #0xc58]
    // 0xf3b214: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3b214: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _updateAnimations(/* No info */) {
    // ** addr: 0xf3b42c, size: 0x230
    // 0xf3b42c: EnterFrame
    //     0xf3b42c: stp             fp, lr, [SP, #-0x10]!
    //     0xf3b430: mov             fp, SP
    // 0xf3b434: AllocStack(0x10)
    //     0xf3b434: sub             SP, SP, #0x10
    // 0xf3b438: SetupParameters(_ZoomExitTransitionState this /* r1 => r2, fp-0x8 */)
    //     0xf3b438: mov             x2, x1
    //     0xf3b43c: stur            x1, [fp, #-8]
    // 0xf3b440: CheckStackOverflow
    //     0xf3b440: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3b444: cmp             SP, x16
    //     0xf3b448: b.ls            #0xf3b63c
    // 0xf3b44c: LoadField: r0 = r2->field_b
    //     0xf3b44c: ldur            w0, [x2, #0xb]
    // 0xf3b450: DecompressPointer r0
    //     0xf3b450: add             x0, x0, HEAP, lsl #32
    // 0xf3b454: cmp             w0, NULL
    // 0xf3b458: b.eq            #0xf3b644
    // 0xf3b45c: LoadField: r1 = r0->field_13
    //     0xf3b45c: ldur            w1, [x0, #0x13]
    // 0xf3b460: DecompressPointer r1
    //     0xf3b460: add             x1, x1, HEAP, lsl #32
    // 0xf3b464: tbnz            w1, #4, #0xf3b4b4
    // 0xf3b468: r0 = LoadStaticField(0x720)
    //     0xf3b468: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf3b46c: ldr             x0, [x0, #0xe40]
    // 0xf3b470: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3b474: cmp             w0, w16
    // 0xf3b478: b.ne            #0xf3b488
    // 0xf3b47c: r2 = _fadeOutTransition
    //     0xf3b47c: add             x2, PP, #0xad, lsl #12  ; [pp+0xadc98] Field <_ZoomExitTransitionState@110490068._fadeOutTransition@110490068>: static late final (offset: 0x720)
    //     0xf3b480: ldr             x2, [x2, #0xc98]
    // 0xf3b484: r0 = InitLateFinalStaticField()
    //     0xf3b484: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf3b488: mov             x1, x0
    // 0xf3b48c: ldur            x0, [fp, #-8]
    // 0xf3b490: LoadField: r2 = r0->field_b
    //     0xf3b490: ldur            w2, [x0, #0xb]
    // 0xf3b494: DecompressPointer r2
    //     0xf3b494: add             x2, x2, HEAP, lsl #32
    // 0xf3b498: cmp             w2, NULL
    // 0xf3b49c: b.eq            #0xf3b648
    // 0xf3b4a0: LoadField: r3 = r2->field_b
    //     0xf3b4a0: ldur            w3, [x2, #0xb]
    // 0xf3b4a4: DecompressPointer r3
    //     0xf3b4a4: add             x3, x3, HEAP, lsl #32
    // 0xf3b4a8: mov             x2, x3
    // 0xf3b4ac: r0 = animate()
    //     0xf3b4ac: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf3b4b0: b               #0xf3b4bc
    // 0xf3b4b4: r0 = Instance__AlwaysCompleteAnimation
    //     0xf3b4b4: add             x0, PP, #0x97, lsl #12  ; [pp+0x97440] Obj!_AlwaysCompleteAnimation@12aa3f1
    //     0xf3b4b8: ldr             x0, [x0, #0x440]
    // 0xf3b4bc: ldur            x2, [fp, #-8]
    // 0xf3b4c0: ArrayStore: r2[0] = r0  ; List_4
    //     0xf3b4c0: stur            w0, [x2, #0x17]
    //     0xf3b4c4: ldurb           w16, [x2, #-1]
    //     0xf3b4c8: ldurb           w17, [x0, #-1]
    //     0xf3b4cc: and             x16, x17, x16, lsr #2
    //     0xf3b4d0: tst             x16, HEAP, lsr #32
    //     0xf3b4d4: b.eq            #0xf3b4dc
    //     0xf3b4d8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3b4dc: LoadField: r0 = r2->field_b
    //     0xf3b4dc: ldur            w0, [x2, #0xb]
    // 0xf3b4e0: DecompressPointer r0
    //     0xf3b4e0: add             x0, x0, HEAP, lsl #32
    // 0xf3b4e4: cmp             w0, NULL
    // 0xf3b4e8: b.eq            #0xf3b64c
    // 0xf3b4ec: LoadField: r1 = r0->field_13
    //     0xf3b4ec: ldur            w1, [x0, #0x13]
    // 0xf3b4f0: DecompressPointer r1
    //     0xf3b4f0: add             x1, x1, HEAP, lsl #32
    // 0xf3b4f4: tbnz            w1, #4, #0xf3b520
    // 0xf3b4f8: r0 = LoadStaticField(0x728)
    //     0xf3b4f8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf3b4fc: ldr             x0, [x0, #0xe50]
    // 0xf3b500: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3b504: cmp             w0, w16
    // 0xf3b508: b.ne            #0xf3b518
    // 0xf3b50c: r2 = _scaleDownTransition
    //     0xf3b50c: add             x2, PP, #0xad, lsl #12  ; [pp+0xadca0] Field <_ZoomExitTransitionState@110490068._scaleDownTransition@110490068>: static late final (offset: 0x728)
    //     0xf3b510: ldr             x2, [x2, #0xca0]
    // 0xf3b514: r0 = InitLateFinalStaticField()
    //     0xf3b514: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf3b518: mov             x1, x0
    // 0xf3b51c: b               #0xf3b544
    // 0xf3b520: r0 = LoadStaticField(0x724)
    //     0xf3b520: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf3b524: ldr             x0, [x0, #0xe48]
    // 0xf3b528: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3b52c: cmp             w0, w16
    // 0xf3b530: b.ne            #0xf3b540
    // 0xf3b534: r2 = _scaleUpTransition
    //     0xf3b534: add             x2, PP, #0xad, lsl #12  ; [pp+0xadca8] Field <_ZoomExitTransitionState@110490068._scaleUpTransition@110490068>: static late final (offset: 0x724)
    //     0xf3b538: ldr             x2, [x2, #0xca8]
    // 0xf3b53c: r0 = InitLateFinalStaticField()
    //     0xf3b53c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf3b540: mov             x1, x0
    // 0xf3b544: ldur            x0, [fp, #-8]
    // 0xf3b548: LoadField: r2 = r0->field_b
    //     0xf3b548: ldur            w2, [x0, #0xb]
    // 0xf3b54c: DecompressPointer r2
    //     0xf3b54c: add             x2, x2, HEAP, lsl #32
    // 0xf3b550: cmp             w2, NULL
    // 0xf3b554: b.eq            #0xf3b650
    // 0xf3b558: LoadField: r3 = r2->field_b
    //     0xf3b558: ldur            w3, [x2, #0xb]
    // 0xf3b55c: DecompressPointer r3
    //     0xf3b55c: add             x3, x3, HEAP, lsl #32
    // 0xf3b560: mov             x2, x3
    // 0xf3b564: r0 = animate()
    //     0xf3b564: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf3b568: ldur            x3, [fp, #-8]
    // 0xf3b56c: StoreField: r3->field_1b = r0
    //     0xf3b56c: stur            w0, [x3, #0x1b]
    //     0xf3b570: ldurb           w16, [x3, #-1]
    //     0xf3b574: ldurb           w17, [x0, #-1]
    //     0xf3b578: and             x16, x17, x16, lsr #2
    //     0xf3b57c: tst             x16, HEAP, lsr #32
    //     0xf3b580: b.eq            #0xf3b588
    //     0xf3b584: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf3b588: LoadField: r0 = r3->field_b
    //     0xf3b588: ldur            w0, [x3, #0xb]
    // 0xf3b58c: DecompressPointer r0
    //     0xf3b58c: add             x0, x0, HEAP, lsl #32
    // 0xf3b590: cmp             w0, NULL
    // 0xf3b594: b.eq            #0xf3b654
    // 0xf3b598: LoadField: r4 = r0->field_b
    //     0xf3b598: ldur            w4, [x0, #0xb]
    // 0xf3b59c: DecompressPointer r4
    //     0xf3b59c: add             x4, x4, HEAP, lsl #32
    // 0xf3b5a0: mov             x2, x3
    // 0xf3b5a4: stur            x4, [fp, #-0x10]
    // 0xf3b5a8: r1 = Function 'onAnimationValueChange':.
    //     0xf3b5a8: add             x1, PP, #0xad, lsl #12  ; [pp+0xadc48] AnonymousClosure: (0xf3b894), in [dart:mixin_deduplication] _MixinApplication87&State&_ZoomTransitionBase::onAnimationValueChange (0xf3b8cc)
    //     0xf3b5ac: ldr             x1, [x1, #0xc48]
    // 0xf3b5b0: r0 = AllocateClosure()
    //     0xf3b5b0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf3b5b4: ldur            x1, [fp, #-0x10]
    // 0xf3b5b8: r2 = LoadClassIdInstr(r1)
    //     0xf3b5b8: ldur            x2, [x1, #-1]
    //     0xf3b5bc: ubfx            x2, x2, #0xc, #0x14
    // 0xf3b5c0: mov             x16, x0
    // 0xf3b5c4: mov             x0, x2
    // 0xf3b5c8: mov             x2, x16
    // 0xf3b5cc: r0 = GDT[cid_x0 + 0xe0ec]()
    //     0xf3b5cc: mov             x17, #0xe0ec
    //     0xf3b5d0: add             lr, x0, x17
    //     0xf3b5d4: ldr             lr, [x21, lr, lsl #3]
    //     0xf3b5d8: blr             lr
    // 0xf3b5dc: ldur            x2, [fp, #-8]
    // 0xf3b5e0: LoadField: r0 = r2->field_b
    //     0xf3b5e0: ldur            w0, [x2, #0xb]
    // 0xf3b5e4: DecompressPointer r0
    //     0xf3b5e4: add             x0, x0, HEAP, lsl #32
    // 0xf3b5e8: cmp             w0, NULL
    // 0xf3b5ec: b.eq            #0xf3b658
    // 0xf3b5f0: LoadField: r3 = r0->field_b
    //     0xf3b5f0: ldur            w3, [x0, #0xb]
    // 0xf3b5f4: DecompressPointer r3
    //     0xf3b5f4: add             x3, x3, HEAP, lsl #32
    // 0xf3b5f8: stur            x3, [fp, #-0x10]
    // 0xf3b5fc: r1 = Function 'onAnimationStatusChange':.
    //     0xf3b5fc: add             x1, PP, #0xad, lsl #12  ; [pp+0xadc50] AnonymousClosure: (0xf3b7c4), in [dart:mixin_deduplication] _MixinApplication87&State&_ZoomTransitionBase::onAnimationStatusChange (0xf3b800)
    //     0xf3b600: ldr             x1, [x1, #0xc50]
    // 0xf3b604: r0 = AllocateClosure()
    //     0xf3b604: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf3b608: ldur            x1, [fp, #-0x10]
    // 0xf3b60c: r2 = LoadClassIdInstr(r1)
    //     0xf3b60c: ldur            x2, [x1, #-1]
    //     0xf3b610: ubfx            x2, x2, #0xc, #0x14
    // 0xf3b614: mov             x16, x0
    // 0xf3b618: mov             x0, x2
    // 0xf3b61c: mov             x2, x16
    // 0xf3b620: r0 = GDT[cid_x0 + 0xbeb]()
    //     0xf3b620: add             lr, x0, #0xbeb
    //     0xf3b624: ldr             lr, [x21, lr, lsl #3]
    //     0xf3b628: blr             lr
    // 0xf3b62c: r0 = Null
    //     0xf3b62c: mov             x0, NULL
    // 0xf3b630: LeaveFrame
    //     0xf3b630: mov             SP, fp
    //     0xf3b634: ldp             fp, lr, [SP], #0x10
    // 0xf3b638: ret
    //     0xf3b638: ret             
    // 0xf3b63c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3b63c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3b640: b               #0xf3b44c
    // 0xf3b644: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3b644: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3b648: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3b648: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3b64c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3b64c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3b650: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3b650: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3b654: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3b654: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3b658: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3b658: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static Animatable<double> _scaleUpTransition() {
    // ** addr: 0xf3b65c, size: 0x7c
    // 0xf3b65c: EnterFrame
    //     0xf3b65c: stp             fp, lr, [SP, #-0x10]!
    //     0xf3b660: mov             fp, SP
    // 0xf3b664: AllocStack(0x8)
    //     0xf3b664: sub             SP, SP, #8
    // 0xf3b668: CheckStackOverflow
    //     0xf3b668: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3b66c: cmp             SP, x16
    //     0xf3b670: b.ls            #0xf3b6d0
    // 0xf3b674: r1 = <double>
    //     0xf3b674: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3b678: r0 = Tween()
    //     0xf3b678: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xf3b67c: mov             x1, x0
    // 0xf3b680: r0 = 1.000000
    //     0xf3b680: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xf3b684: stur            x1, [fp, #-8]
    // 0xf3b688: StoreField: r1->field_b = r0
    //     0xf3b688: stur            w0, [x1, #0xb]
    // 0xf3b68c: r0 = 1.050000
    //     0xf3b68c: add             x0, PP, #0xad, lsl #12  ; [pp+0xadcb0] 1.05
    //     0xf3b690: ldr             x0, [x0, #0xcb0]
    // 0xf3b694: StoreField: r1->field_f = r0
    //     0xf3b694: stur            w0, [x1, #0xf]
    // 0xf3b698: r0 = LoadStaticField(0x71c)
    //     0xf3b698: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf3b69c: ldr             x0, [x0, #0xe38]
    // 0xf3b6a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3b6a4: cmp             w0, w16
    // 0xf3b6a8: b.ne            #0xf3b6b8
    // 0xf3b6ac: r2 = _scaleCurveSequence
    //     0xf3b6ac: add             x2, PP, #0xad, lsl #12  ; [pp+0xadc00] Field <_ZoomPageTransition@110490068._scaleCurveSequence@110490068>: static late final (offset: 0x71c)
    //     0xf3b6b0: ldr             x2, [x2, #0xc00]
    // 0xf3b6b4: r0 = InitLateFinalStaticField()
    //     0xf3b6b4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf3b6b8: ldur            x1, [fp, #-8]
    // 0xf3b6bc: mov             x2, x0
    // 0xf3b6c0: r0 = chain()
    //     0xf3b6c0: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xf3b6c4: LeaveFrame
    //     0xf3b6c4: mov             SP, fp
    //     0xf3b6c8: ldp             fp, lr, [SP], #0x10
    // 0xf3b6cc: ret
    //     0xf3b6cc: ret             
    // 0xf3b6d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3b6d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3b6d4: b               #0xf3b674
  }
  static Animatable<double> _scaleDownTransition() {
    // ** addr: 0xf3b6d8, size: 0x7c
    // 0xf3b6d8: EnterFrame
    //     0xf3b6d8: stp             fp, lr, [SP, #-0x10]!
    //     0xf3b6dc: mov             fp, SP
    // 0xf3b6e0: AllocStack(0x8)
    //     0xf3b6e0: sub             SP, SP, #8
    // 0xf3b6e4: CheckStackOverflow
    //     0xf3b6e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3b6e8: cmp             SP, x16
    //     0xf3b6ec: b.ls            #0xf3b74c
    // 0xf3b6f0: r1 = <double>
    //     0xf3b6f0: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3b6f4: r0 = Tween()
    //     0xf3b6f4: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xf3b6f8: mov             x1, x0
    // 0xf3b6fc: r0 = 1.000000
    //     0xf3b6fc: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xf3b700: stur            x1, [fp, #-8]
    // 0xf3b704: StoreField: r1->field_b = r0
    //     0xf3b704: stur            w0, [x1, #0xb]
    // 0xf3b708: r0 = 0.900000
    //     0xf3b708: add             x0, PP, #0xac, lsl #12  ; [pp+0xac188] 0.9
    //     0xf3b70c: ldr             x0, [x0, #0x188]
    // 0xf3b710: StoreField: r1->field_f = r0
    //     0xf3b710: stur            w0, [x1, #0xf]
    // 0xf3b714: r0 = LoadStaticField(0x71c)
    //     0xf3b714: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf3b718: ldr             x0, [x0, #0xe38]
    // 0xf3b71c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3b720: cmp             w0, w16
    // 0xf3b724: b.ne            #0xf3b734
    // 0xf3b728: r2 = _scaleCurveSequence
    //     0xf3b728: add             x2, PP, #0xad, lsl #12  ; [pp+0xadc00] Field <_ZoomPageTransition@110490068._scaleCurveSequence@110490068>: static late final (offset: 0x71c)
    //     0xf3b72c: ldr             x2, [x2, #0xc00]
    // 0xf3b730: r0 = InitLateFinalStaticField()
    //     0xf3b730: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf3b734: ldur            x1, [fp, #-8]
    // 0xf3b738: mov             x2, x0
    // 0xf3b73c: r0 = chain()
    //     0xf3b73c: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xf3b740: LeaveFrame
    //     0xf3b740: mov             SP, fp
    //     0xf3b744: ldp             fp, lr, [SP], #0x10
    // 0xf3b748: ret
    //     0xf3b748: ret             
    // 0xf3b74c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3b74c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3b750: b               #0xf3b6f0
  }
  static Animatable<double> _fadeOutTransition() {
    // ** addr: 0xf3b754, size: 0x70
    // 0xf3b754: EnterFrame
    //     0xf3b754: stp             fp, lr, [SP, #-0x10]!
    //     0xf3b758: mov             fp, SP
    // 0xf3b75c: AllocStack(0x8)
    //     0xf3b75c: sub             SP, SP, #8
    // 0xf3b760: CheckStackOverflow
    //     0xf3b760: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3b764: cmp             SP, x16
    //     0xf3b768: b.ls            #0xf3b7bc
    // 0xf3b76c: r1 = <double>
    //     0xf3b76c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3b770: r0 = Tween()
    //     0xf3b770: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xf3b774: mov             x2, x0
    // 0xf3b778: r0 = 1.000000
    //     0xf3b778: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xf3b77c: stur            x2, [fp, #-8]
    // 0xf3b780: StoreField: r2->field_b = r0
    //     0xf3b780: stur            w0, [x2, #0xb]
    // 0xf3b784: r0 = 0.000000
    //     0xf3b784: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xf3b788: StoreField: r2->field_f = r0
    //     0xf3b788: stur            w0, [x2, #0xf]
    // 0xf3b78c: r1 = <double>
    //     0xf3b78c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3b790: r0 = CurveTween()
    //     0xf3b790: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xf3b794: mov             x1, x0
    // 0xf3b798: r0 = Instance_Interval
    //     0xf3b798: add             x0, PP, #0xad, lsl #12  ; [pp+0xadcb8] Obj!Interval@129faf1
    //     0xf3b79c: ldr             x0, [x0, #0xcb8]
    // 0xf3b7a0: StoreField: r1->field_b = r0
    //     0xf3b7a0: stur            w0, [x1, #0xb]
    // 0xf3b7a4: mov             x2, x1
    // 0xf3b7a8: ldur            x1, [fp, #-8]
    // 0xf3b7ac: r0 = chain()
    //     0xf3b7ac: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xf3b7b0: LeaveFrame
    //     0xf3b7b0: mov             SP, fp
    //     0xf3b7b4: ldp             fp, lr, [SP], #0x10
    // 0xf3b7b8: ret
    //     0xf3b7b8: ret             
    // 0xf3b7bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3b7bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3b7c0: b               #0xf3b76c
  }
  _ initState(/* No info */) {
    // ** addr: 0xf7ae80, size: 0xfc
    // 0xf7ae80: EnterFrame
    //     0xf7ae80: stp             fp, lr, [SP, #-0x10]!
    //     0xf7ae84: mov             fp, SP
    // 0xf7ae88: AllocStack(0x28)
    //     0xf7ae88: sub             SP, SP, #0x28
    // 0xf7ae8c: SetupParameters(_ZoomExitTransitionState this /* r1 => r0, fp-0x8 */)
    //     0xf7ae8c: mov             x0, x1
    //     0xf7ae90: stur            x1, [fp, #-8]
    // 0xf7ae94: CheckStackOverflow
    //     0xf7ae94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7ae98: cmp             SP, x16
    //     0xf7ae9c: b.ls            #0xf7af58
    // 0xf7aea0: mov             x1, x0
    // 0xf7aea4: r0 = _updateAnimations()
    //     0xf7aea4: bl              #0xf3b42c  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionState::_updateAnimations
    // 0xf7aea8: ldur            x0, [fp, #-8]
    // 0xf7aeac: LoadField: r1 = r0->field_b
    //     0xf7aeac: ldur            w1, [x0, #0xb]
    // 0xf7aeb0: DecompressPointer r1
    //     0xf7aeb0: add             x1, x1, HEAP, lsl #32
    // 0xf7aeb4: cmp             w1, NULL
    // 0xf7aeb8: b.eq            #0xf7af60
    // 0xf7aebc: LoadField: r5 = r1->field_13
    //     0xf7aebc: ldur            w5, [x1, #0x13]
    // 0xf7aec0: DecompressPointer r5
    //     0xf7aec0: add             x5, x5, HEAP, lsl #32
    // 0xf7aec4: stur            x5, [fp, #-0x28]
    // 0xf7aec8: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xf7aec8: ldur            w3, [x0, #0x17]
    // 0xf7aecc: DecompressPointer r3
    //     0xf7aecc: add             x3, x3, HEAP, lsl #32
    // 0xf7aed0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7aed4: cmp             w3, w16
    // 0xf7aed8: b.eq            #0xf7af64
    // 0xf7aedc: stur            x3, [fp, #-0x20]
    // 0xf7aee0: LoadField: r6 = r0->field_1b
    //     0xf7aee0: ldur            w6, [x0, #0x1b]
    // 0xf7aee4: DecompressPointer r6
    //     0xf7aee4: add             x6, x6, HEAP, lsl #32
    // 0xf7aee8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7aeec: cmp             w6, w16
    // 0xf7aef0: b.eq            #0xf7af70
    // 0xf7aef4: stur            x6, [fp, #-0x18]
    // 0xf7aef8: LoadField: r2 = r1->field_b
    //     0xf7aef8: ldur            w2, [x1, #0xb]
    // 0xf7aefc: DecompressPointer r2
    //     0xf7aefc: add             x2, x2, HEAP, lsl #32
    // 0xf7af00: stur            x2, [fp, #-0x10]
    // 0xf7af04: r0 = _ZoomExitTransitionPainter()
    //     0xf7af04: bl              #0xf3b420  ; Allocate_ZoomExitTransitionPainterStub -> _ZoomExitTransitionPainter (size=0x40)
    // 0xf7af08: mov             x1, x0
    // 0xf7af0c: ldur            x2, [fp, #-0x10]
    // 0xf7af10: ldur            x3, [fp, #-0x20]
    // 0xf7af14: ldur            x5, [fp, #-0x28]
    // 0xf7af18: ldur            x6, [fp, #-0x18]
    // 0xf7af1c: stur            x0, [fp, #-0x10]
    // 0xf7af20: r0 = _ZoomExitTransitionPainter()
    //     0xf7af20: bl              #0xf3b218  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionPainter::_ZoomExitTransitionPainter
    // 0xf7af24: ldur            x0, [fp, #-0x10]
    // 0xf7af28: ldur            x1, [fp, #-8]
    // 0xf7af2c: StoreField: r1->field_1f = r0
    //     0xf7af2c: stur            w0, [x1, #0x1f]
    //     0xf7af30: ldurb           w16, [x1, #-1]
    //     0xf7af34: ldurb           w17, [x0, #-1]
    //     0xf7af38: and             x16, x17, x16, lsr #2
    //     0xf7af3c: tst             x16, HEAP, lsr #32
    //     0xf7af40: b.eq            #0xf7af48
    //     0xf7af44: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf7af48: r0 = Null
    //     0xf7af48: mov             x0, NULL
    // 0xf7af4c: LeaveFrame
    //     0xf7af4c: mov             SP, fp
    //     0xf7af50: ldp             fp, lr, [SP], #0x10
    // 0xf7af54: ret
    //     0xf7af54: ret             
    // 0xf7af58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7af58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7af5c: b               #0xf7aea0
    // 0xf7af60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7af60: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7af64: r9 = fadeTransition
    //     0xf7af64: add             x9, PP, #0xad, lsl #12  ; [pp+0xadc60] Field <_MixinApplication87&State&_ZoomTransitionBase@18353248.fadeTransition>: late (offset: 0x18)
    //     0xf7af68: ldr             x9, [x9, #0xc60]
    // 0xf7af6c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf7af6c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf7af70: r9 = scaleTransition
    //     0xf7af70: add             x9, PP, #0xad, lsl #12  ; [pp+0xadc58] Field <_MixinApplication87&State&_ZoomTransitionBase@18353248.scaleTransition>: late (offset: 0x1c)
    //     0xf7af74: ldr             x9, [x9, #0xc58]
    // 0xf7af78: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf7af78: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _ZoomExitTransitionState(/* No info */) {
    // ** addr: 0xfa21cc, size: 0xac
    // 0xfa21cc: EnterFrame
    //     0xfa21cc: stp             fp, lr, [SP, #-0x10]!
    //     0xfa21d0: mov             fp, SP
    // 0xfa21d4: AllocStack(0x10)
    //     0xfa21d4: sub             SP, SP, #0x10
    // 0xfa21d8: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa21dc: stur            x1, [fp, #-8]
    // 0xfa21e0: CheckStackOverflow
    //     0xfa21e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa21e4: cmp             SP, x16
    //     0xfa21e8: b.ls            #0xfa2270
    // 0xfa21ec: StoreField: r1->field_1f = r0
    //     0xfa21ec: stur            w0, [x1, #0x1f]
    // 0xfa21f0: ArrayStore: r1[0] = r0  ; List_4
    //     0xfa21f0: stur            w0, [x1, #0x17]
    // 0xfa21f4: StoreField: r1->field_1b = r0
    //     0xfa21f4: stur            w0, [x1, #0x1b]
    // 0xfa21f8: r0 = SnapshotController()
    //     0xfa21f8: bl              #0xfa216c  ; AllocateSnapshotControllerStub -> SnapshotController (size=0x28)
    // 0xfa21fc: mov             x1, x0
    // 0xfa2200: r0 = false
    //     0xfa2200: add             x0, NULL, #0x30  ; false
    // 0xfa2204: stur            x1, [fp, #-0x10]
    // 0xfa2208: StoreField: r1->field_23 = r0
    //     0xfa2208: stur            w0, [x1, #0x23]
    // 0xfa220c: StoreField: r1->field_7 = rZR
    //     0xfa220c: stur            xzr, [x1, #7]
    // 0xfa2210: StoreField: r1->field_13 = rZR
    //     0xfa2210: stur            xzr, [x1, #0x13]
    // 0xfa2214: StoreField: r1->field_1b = rZR
    //     0xfa2214: stur            xzr, [x1, #0x1b]
    // 0xfa2218: r0 = LoadStaticField(0x45c)
    //     0xfa2218: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfa221c: ldr             x0, [x0, #0x8b8]
    // 0xfa2220: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa2224: cmp             w0, w16
    // 0xfa2228: b.ne            #0xfa2234
    // 0xfa222c: r2 = _emptyListeners
    //     0xfa222c: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xfa2230: r0 = InitLateFinalStaticField()
    //     0xfa2230: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xfa2234: mov             x1, x0
    // 0xfa2238: ldur            x0, [fp, #-0x10]
    // 0xfa223c: StoreField: r0->field_f = r1
    //     0xfa223c: stur            w1, [x0, #0xf]
    // 0xfa2240: ldur            x1, [fp, #-8]
    // 0xfa2244: StoreField: r1->field_13 = r0
    //     0xfa2244: stur            w0, [x1, #0x13]
    //     0xfa2248: ldurb           w16, [x1, #-1]
    //     0xfa224c: ldurb           w17, [x0, #-1]
    //     0xfa2250: and             x16, x17, x16, lsr #2
    //     0xfa2254: tst             x16, HEAP, lsr #32
    //     0xfa2258: b.eq            #0xfa2260
    //     0xfa225c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa2260: r0 = Null
    //     0xfa2260: mov             x0, NULL
    // 0xfa2264: LeaveFrame
    //     0xfa2264: mov             SP, fp
    //     0xfa2268: ldp             fp, lr, [SP], #0x10
    // 0xfa226c: ret
    //     0xfa226c: ret             
    // 0xfa2270: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa2270: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa2274: b               #0xfa21ec
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10dd480, size: 0x118
    // 0x10dd480: EnterFrame
    //     0x10dd480: stp             fp, lr, [SP, #-0x10]!
    //     0x10dd484: mov             fp, SP
    // 0x10dd488: AllocStack(0x10)
    //     0x10dd488: sub             SP, SP, #0x10
    // 0x10dd48c: SetupParameters(_ZoomExitTransitionState this /* r1 => r0, fp-0x10 */)
    //     0x10dd48c: mov             x0, x1
    //     0x10dd490: stur            x1, [fp, #-0x10]
    // 0x10dd494: CheckStackOverflow
    //     0x10dd494: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10dd498: cmp             SP, x16
    //     0x10dd49c: b.ls            #0x10dd57c
    // 0x10dd4a0: LoadField: r1 = r0->field_b
    //     0x10dd4a0: ldur            w1, [x0, #0xb]
    // 0x10dd4a4: DecompressPointer r1
    //     0x10dd4a4: add             x1, x1, HEAP, lsl #32
    // 0x10dd4a8: cmp             w1, NULL
    // 0x10dd4ac: b.eq            #0x10dd584
    // 0x10dd4b0: LoadField: r3 = r1->field_b
    //     0x10dd4b0: ldur            w3, [x1, #0xb]
    // 0x10dd4b4: DecompressPointer r3
    //     0x10dd4b4: add             x3, x3, HEAP, lsl #32
    // 0x10dd4b8: mov             x2, x0
    // 0x10dd4bc: stur            x3, [fp, #-8]
    // 0x10dd4c0: r1 = Function 'onAnimationValueChange':.
    //     0x10dd4c0: add             x1, PP, #0xad, lsl #12  ; [pp+0xadc48] AnonymousClosure: (0xf3b894), in [dart:mixin_deduplication] _MixinApplication87&State&_ZoomTransitionBase::onAnimationValueChange (0xf3b8cc)
    //     0x10dd4c4: ldr             x1, [x1, #0xc48]
    // 0x10dd4c8: r0 = AllocateClosure()
    //     0x10dd4c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10dd4cc: ldur            x1, [fp, #-8]
    // 0x10dd4d0: r2 = LoadClassIdInstr(r1)
    //     0x10dd4d0: ldur            x2, [x1, #-1]
    //     0x10dd4d4: ubfx            x2, x2, #0xc, #0x14
    // 0x10dd4d8: mov             x16, x0
    // 0x10dd4dc: mov             x0, x2
    // 0x10dd4e0: mov             x2, x16
    // 0x10dd4e4: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0x10dd4e4: mov             x17, #0xe2a3
    //     0x10dd4e8: add             lr, x0, x17
    //     0x10dd4ec: ldr             lr, [x21, lr, lsl #3]
    //     0x10dd4f0: blr             lr
    // 0x10dd4f4: ldur            x0, [fp, #-0x10]
    // 0x10dd4f8: LoadField: r1 = r0->field_b
    //     0x10dd4f8: ldur            w1, [x0, #0xb]
    // 0x10dd4fc: DecompressPointer r1
    //     0x10dd4fc: add             x1, x1, HEAP, lsl #32
    // 0x10dd500: cmp             w1, NULL
    // 0x10dd504: b.eq            #0x10dd588
    // 0x10dd508: LoadField: r3 = r1->field_b
    //     0x10dd508: ldur            w3, [x1, #0xb]
    // 0x10dd50c: DecompressPointer r3
    //     0x10dd50c: add             x3, x3, HEAP, lsl #32
    // 0x10dd510: mov             x2, x0
    // 0x10dd514: stur            x3, [fp, #-8]
    // 0x10dd518: r1 = Function 'onAnimationStatusChange':.
    //     0x10dd518: add             x1, PP, #0xad, lsl #12  ; [pp+0xadc50] AnonymousClosure: (0xf3b7c4), in [dart:mixin_deduplication] _MixinApplication87&State&_ZoomTransitionBase::onAnimationStatusChange (0xf3b800)
    //     0x10dd51c: ldr             x1, [x1, #0xc50]
    // 0x10dd520: r0 = AllocateClosure()
    //     0x10dd520: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10dd524: ldur            x1, [fp, #-8]
    // 0x10dd528: r2 = LoadClassIdInstr(r1)
    //     0x10dd528: ldur            x2, [x1, #-1]
    //     0x10dd52c: ubfx            x2, x2, #0xc, #0x14
    // 0x10dd530: mov             x16, x0
    // 0x10dd534: mov             x0, x2
    // 0x10dd538: mov             x2, x16
    // 0x10dd53c: r0 = GDT[cid_x0 + 0xabe]()
    //     0x10dd53c: add             lr, x0, #0xabe
    //     0x10dd540: ldr             lr, [x21, lr, lsl #3]
    //     0x10dd544: blr             lr
    // 0x10dd548: ldur            x0, [fp, #-0x10]
    // 0x10dd54c: LoadField: r1 = r0->field_1f
    //     0x10dd54c: ldur            w1, [x0, #0x1f]
    // 0x10dd550: DecompressPointer r1
    //     0x10dd550: add             x1, x1, HEAP, lsl #32
    // 0x10dd554: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10dd558: cmp             w1, w16
    // 0x10dd55c: b.eq            #0x10dd58c
    // 0x10dd560: r0 = dispose()
    //     0x10dd560: bl              #0x10ef3b0  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionPainter::dispose
    // 0x10dd564: ldur            x1, [fp, #-0x10]
    // 0x10dd568: r0 = dispose()
    //     0x10dd568: bl              #0x10e66cc  ; [package:flutter/src/widgets/draggable_scrollable_sheet.dart] _DraggableScrollableActuatorState::dispose
    // 0x10dd56c: r0 = Null
    //     0x10dd56c: mov             x0, NULL
    // 0x10dd570: LeaveFrame
    //     0x10dd570: mov             SP, fp
    //     0x10dd574: ldp             fp, lr, [SP], #0x10
    // 0x10dd578: ret
    //     0x10dd578: ret             
    // 0x10dd57c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dd57c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dd580: b               #0x10dd4a0
    // 0x10dd584: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10dd584: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10dd588: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10dd588: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10dd58c: r9 = delegate
    //     0x10dd58c: add             x9, PP, #0xad, lsl #12  ; [pp+0xadc40] Field <_ZoomExitTransitionState@110490068.delegate>: late (offset: 0x20)
    //     0x10dd590: ldr             x9, [x9, #0xc40]
    // 0x10dd594: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10dd594: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 5731, size: 0x24, field offset: 0x20
class _ZoomEnterTransitionState extends _MixinApplication86&State&_ZoomTransitionBase {

  late _ZoomEnterTransitionPainter delegate; // offset: 0x20
  static late final Animatable<double> _fadeInTransition; // offset: 0x734
  static late final Animatable<double> _scaleDownTransition; // offset: 0x738
  static late final Animatable<double> _scaleUpTransition; // offset: 0x73c
  static late final Animatable<double?> _scrimOpacityTween; // offset: 0x740

  _ build(/* No info */) {
    // ** addr: 0xd2f9ac, size: 0x98
    // 0xd2f9ac: EnterFrame
    //     0xd2f9ac: stp             fp, lr, [SP, #-0x10]!
    //     0xd2f9b0: mov             fp, SP
    // 0xd2f9b4: AllocStack(0x18)
    //     0xd2f9b4: sub             SP, SP, #0x18
    // 0xd2f9b8: LoadField: r0 = r1->field_1f
    //     0xd2f9b8: ldur            w0, [x1, #0x1f]
    // 0xd2f9bc: DecompressPointer r0
    //     0xd2f9bc: add             x0, x0, HEAP, lsl #32
    // 0xd2f9c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd2f9c4: cmp             w0, w16
    // 0xd2f9c8: b.eq            #0xd2fa34
    // 0xd2f9cc: stur            x0, [fp, #-0x18]
    // 0xd2f9d0: LoadField: r2 = r1->field_13
    //     0xd2f9d0: ldur            w2, [x1, #0x13]
    // 0xd2f9d4: DecompressPointer r2
    //     0xd2f9d4: add             x2, x2, HEAP, lsl #32
    // 0xd2f9d8: stur            x2, [fp, #-0x10]
    // 0xd2f9dc: LoadField: r3 = r1->field_b
    //     0xd2f9dc: ldur            w3, [x1, #0xb]
    // 0xd2f9e0: DecompressPointer r3
    //     0xd2f9e0: add             x3, x3, HEAP, lsl #32
    // 0xd2f9e4: cmp             w3, NULL
    // 0xd2f9e8: b.eq            #0xd2fa40
    // 0xd2f9ec: LoadField: r1 = r3->field_f
    //     0xd2f9ec: ldur            w1, [x3, #0xf]
    // 0xd2f9f0: DecompressPointer r1
    //     0xd2f9f0: add             x1, x1, HEAP, lsl #32
    // 0xd2f9f4: stur            x1, [fp, #-8]
    // 0xd2f9f8: r0 = SnapshotWidget()
    //     0xd2f9f8: bl              #0xd2fa68  ; AllocateSnapshotWidgetStub -> SnapshotWidget (size=0x20)
    // 0xd2f9fc: r1 = Instance_SnapshotMode
    //     0xd2f9fc: add             x1, PP, #0xad, lsl #12  ; [pp+0xadb80] Obj!SnapshotMode@12c2561
    //     0xd2fa00: ldr             x1, [x1, #0xb80]
    // 0xd2fa04: StoreField: r0->field_13 = r1
    //     0xd2fa04: stur            w1, [x0, #0x13]
    // 0xd2fa08: ldur            x1, [fp, #-0x18]
    // 0xd2fa0c: StoreField: r0->field_1b = r1
    //     0xd2fa0c: stur            w1, [x0, #0x1b]
    // 0xd2fa10: r1 = true
    //     0xd2fa10: add             x1, NULL, #0x20  ; true
    // 0xd2fa14: ArrayStore: r0[0] = r1  ; List_4
    //     0xd2fa14: stur            w1, [x0, #0x17]
    // 0xd2fa18: ldur            x1, [fp, #-0x10]
    // 0xd2fa1c: StoreField: r0->field_f = r1
    //     0xd2fa1c: stur            w1, [x0, #0xf]
    // 0xd2fa20: ldur            x1, [fp, #-8]
    // 0xd2fa24: StoreField: r0->field_b = r1
    //     0xd2fa24: stur            w1, [x0, #0xb]
    // 0xd2fa28: LeaveFrame
    //     0xd2fa28: mov             SP, fp
    //     0xd2fa2c: ldp             fp, lr, [SP], #0x10
    // 0xd2fa30: ret
    //     0xd2fa30: ret             
    // 0xd2fa34: r9 = delegate
    //     0xd2fa34: add             x9, PP, #0xad, lsl #12  ; [pp+0xadb88] Field <_ZoomEnterTransitionState@110490068.delegate>: late (offset: 0x20)
    //     0xd2fa38: ldr             x9, [x9, #0xb88]
    // 0xd2fa3c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd2fa3c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd2fa40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2fa40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf3a248, size: 0x27c
    // 0xf3a248: EnterFrame
    //     0xf3a248: stp             fp, lr, [SP, #-0x10]!
    //     0xf3a24c: mov             fp, SP
    // 0xf3a250: AllocStack(0x38)
    //     0xf3a250: sub             SP, SP, #0x38
    // 0xf3a254: SetupParameters(_ZoomEnterTransitionState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf3a254: mov             x4, x1
    //     0xf3a258: mov             x3, x2
    //     0xf3a25c: stur            x1, [fp, #-8]
    //     0xf3a260: stur            x2, [fp, #-0x10]
    // 0xf3a264: CheckStackOverflow
    //     0xf3a264: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3a268: cmp             SP, x16
    //     0xf3a26c: b.ls            #0xf3a490
    // 0xf3a270: mov             x0, x3
    // 0xf3a274: r2 = Null
    //     0xf3a274: mov             x2, NULL
    // 0xf3a278: r1 = Null
    //     0xf3a278: mov             x1, NULL
    // 0xf3a27c: r4 = 60
    //     0xf3a27c: mov             x4, #0x3c
    // 0xf3a280: branchIfSmi(r0, 0xf3a28c)
    //     0xf3a280: tbz             w0, #0, #0xf3a28c
    // 0xf3a284: r4 = LoadClassIdInstr(r0)
    //     0xf3a284: ldur            x4, [x0, #-1]
    //     0xf3a288: ubfx            x4, x4, #0xc, #0x14
    // 0xf3a28c: r17 = 6456
    //     0xf3a28c: mov             x17, #0x1938
    // 0xf3a290: cmp             x4, x17
    // 0xf3a294: b.eq            #0xf3a2ac
    // 0xf3a298: r8 = _ZoomEnterTransition
    //     0xf3a298: add             x8, PP, #0xad, lsl #12  ; [pp+0xadbb8] Type: _ZoomEnterTransition
    //     0xf3a29c: ldr             x8, [x8, #0xbb8]
    // 0xf3a2a0: r3 = Null
    //     0xf3a2a0: add             x3, PP, #0xad, lsl #12  ; [pp+0xadbc0] Null
    //     0xf3a2a4: ldr             x3, [x3, #0xbc0]
    // 0xf3a2a8: r0 = _ZoomEnterTransition()
    //     0xf3a2a8: bl              #0xd2fa44  ; IsType__ZoomEnterTransition_Stub
    // 0xf3a2ac: ldur            x0, [fp, #-0x10]
    // 0xf3a2b0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf3a2b0: ldur            w1, [x0, #0x17]
    // 0xf3a2b4: DecompressPointer r1
    //     0xf3a2b4: add             x1, x1, HEAP, lsl #32
    // 0xf3a2b8: ldur            x3, [fp, #-8]
    // 0xf3a2bc: LoadField: r2 = r3->field_b
    //     0xf3a2bc: ldur            w2, [x3, #0xb]
    // 0xf3a2c0: DecompressPointer r2
    //     0xf3a2c0: add             x2, x2, HEAP, lsl #32
    // 0xf3a2c4: cmp             w2, NULL
    // 0xf3a2c8: b.eq            #0xf3a498
    // 0xf3a2cc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf3a2cc: ldur            w4, [x2, #0x17]
    // 0xf3a2d0: DecompressPointer r4
    //     0xf3a2d0: add             x4, x4, HEAP, lsl #32
    // 0xf3a2d4: cmp             w1, w4
    // 0xf3a2d8: b.ne            #0xf3a2f4
    // 0xf3a2dc: LoadField: r1 = r0->field_b
    //     0xf3a2dc: ldur            w1, [x0, #0xb]
    // 0xf3a2e0: DecompressPointer r1
    //     0xf3a2e0: add             x1, x1, HEAP, lsl #32
    // 0xf3a2e4: LoadField: r4 = r2->field_b
    //     0xf3a2e4: ldur            w4, [x2, #0xb]
    // 0xf3a2e8: DecompressPointer r4
    //     0xf3a2e8: add             x4, x4, HEAP, lsl #32
    // 0xf3a2ec: cmp             w1, w4
    // 0xf3a2f0: b.eq            #0xf3a444
    // 0xf3a2f4: LoadField: r4 = r0->field_b
    //     0xf3a2f4: ldur            w4, [x0, #0xb]
    // 0xf3a2f8: DecompressPointer r4
    //     0xf3a2f8: add             x4, x4, HEAP, lsl #32
    // 0xf3a2fc: mov             x2, x3
    // 0xf3a300: stur            x4, [fp, #-0x18]
    // 0xf3a304: r1 = Function 'onAnimationValueChange':.
    //     0xf3a304: add             x1, PP, #0xad, lsl #12  ; [pp+0xadb90] AnonymousClosure: (0xf3adec), in [dart:mixin_deduplication] _MixinApplication86&State&_ZoomTransitionBase::onAnimationValueChange (0xf3ae24)
    //     0xf3a308: ldr             x1, [x1, #0xb90]
    // 0xf3a30c: r0 = AllocateClosure()
    //     0xf3a30c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf3a310: ldur            x3, [fp, #-0x18]
    // 0xf3a314: r1 = LoadClassIdInstr(r3)
    //     0xf3a314: ldur            x1, [x3, #-1]
    //     0xf3a318: ubfx            x1, x1, #0xc, #0x14
    // 0xf3a31c: mov             x2, x0
    // 0xf3a320: mov             x0, x1
    // 0xf3a324: mov             x1, x3
    // 0xf3a328: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0xf3a328: mov             x17, #0xe2a3
    //     0xf3a32c: add             lr, x0, x17
    //     0xf3a330: ldr             lr, [x21, lr, lsl #3]
    //     0xf3a334: blr             lr
    // 0xf3a338: ldur            x2, [fp, #-8]
    // 0xf3a33c: r1 = Function 'onAnimationStatusChange':.
    //     0xf3a33c: add             x1, PP, #0xad, lsl #12  ; [pp+0xadb98] AnonymousClosure: (0xf3acd8), in [dart:mixin_deduplication] _MixinApplication86&State&_ZoomTransitionBase::onAnimationStatusChange (0xf3ad14)
    //     0xf3a340: ldr             x1, [x1, #0xb98]
    // 0xf3a344: r0 = AllocateClosure()
    //     0xf3a344: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf3a348: ldur            x1, [fp, #-0x18]
    // 0xf3a34c: r2 = LoadClassIdInstr(r1)
    //     0xf3a34c: ldur            x2, [x1, #-1]
    //     0xf3a350: ubfx            x2, x2, #0xc, #0x14
    // 0xf3a354: mov             x16, x0
    // 0xf3a358: mov             x0, x2
    // 0xf3a35c: mov             x2, x16
    // 0xf3a360: r0 = GDT[cid_x0 + 0xabe]()
    //     0xf3a360: add             lr, x0, #0xabe
    //     0xf3a364: ldr             lr, [x21, lr, lsl #3]
    //     0xf3a368: blr             lr
    // 0xf3a36c: ldur            x1, [fp, #-8]
    // 0xf3a370: r0 = _updateAnimations()
    //     0xf3a370: bl              #0xf3a768  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionState::_updateAnimations
    // 0xf3a374: ldur            x0, [fp, #-8]
    // 0xf3a378: LoadField: r1 = r0->field_1f
    //     0xf3a378: ldur            w1, [x0, #0x1f]
    // 0xf3a37c: DecompressPointer r1
    //     0xf3a37c: add             x1, x1, HEAP, lsl #32
    // 0xf3a380: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3a384: cmp             w1, w16
    // 0xf3a388: b.eq            #0xf3a49c
    // 0xf3a38c: r0 = dispose()
    //     0xf3a38c: bl              #0x10ef294  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionPainter::dispose
    // 0xf3a390: ldur            x0, [fp, #-8]
    // 0xf3a394: LoadField: r1 = r0->field_b
    //     0xf3a394: ldur            w1, [x0, #0xb]
    // 0xf3a398: DecompressPointer r1
    //     0xf3a398: add             x1, x1, HEAP, lsl #32
    // 0xf3a39c: cmp             w1, NULL
    // 0xf3a3a0: b.eq            #0xf3a4a8
    // 0xf3a3a4: ArrayLoad: r6 = r1[0]  ; List_4
    //     0xf3a3a4: ldur            w6, [x1, #0x17]
    // 0xf3a3a8: DecompressPointer r6
    //     0xf3a3a8: add             x6, x6, HEAP, lsl #32
    // 0xf3a3ac: stur            x6, [fp, #-0x38]
    // 0xf3a3b0: ArrayLoad: r5 = r0[0]  ; List_4
    //     0xf3a3b0: ldur            w5, [x0, #0x17]
    // 0xf3a3b4: DecompressPointer r5
    //     0xf3a3b4: add             x5, x5, HEAP, lsl #32
    // 0xf3a3b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3a3bc: cmp             w5, w16
    // 0xf3a3c0: b.eq            #0xf3a4ac
    // 0xf3a3c4: stur            x5, [fp, #-0x30]
    // 0xf3a3c8: LoadField: r7 = r0->field_1b
    //     0xf3a3c8: ldur            w7, [x0, #0x1b]
    // 0xf3a3cc: DecompressPointer r7
    //     0xf3a3cc: add             x7, x7, HEAP, lsl #32
    // 0xf3a3d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3a3d4: cmp             w7, w16
    // 0xf3a3d8: b.eq            #0xf3a4b8
    // 0xf3a3dc: stur            x7, [fp, #-0x28]
    // 0xf3a3e0: LoadField: r2 = r1->field_b
    //     0xf3a3e0: ldur            w2, [x1, #0xb]
    // 0xf3a3e4: DecompressPointer r2
    //     0xf3a3e4: add             x2, x2, HEAP, lsl #32
    // 0xf3a3e8: stur            x2, [fp, #-0x20]
    // 0xf3a3ec: LoadField: r3 = r1->field_1b
    //     0xf3a3ec: ldur            w3, [x1, #0x1b]
    // 0xf3a3f0: DecompressPointer r3
    //     0xf3a3f0: add             x3, x3, HEAP, lsl #32
    // 0xf3a3f4: stur            x3, [fp, #-0x18]
    // 0xf3a3f8: r0 = _ZoomEnterTransitionPainter()
    //     0xf3a3f8: bl              #0xf3a75c  ; Allocate_ZoomEnterTransitionPainterStub -> _ZoomEnterTransitionPainter (size=0x44)
    // 0xf3a3fc: mov             x1, x0
    // 0xf3a400: ldur            x2, [fp, #-0x20]
    // 0xf3a404: ldur            x3, [fp, #-0x18]
    // 0xf3a408: ldur            x5, [fp, #-0x30]
    // 0xf3a40c: ldur            x6, [fp, #-0x38]
    // 0xf3a410: ldur            x7, [fp, #-0x28]
    // 0xf3a414: stur            x0, [fp, #-0x18]
    // 0xf3a418: r0 = _ZoomEnterTransitionPainter()
    //     0xf3a418: bl              #0xf3a4c4  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionPainter::_ZoomEnterTransitionPainter
    // 0xf3a41c: ldur            x0, [fp, #-0x18]
    // 0xf3a420: ldur            x1, [fp, #-8]
    // 0xf3a424: StoreField: r1->field_1f = r0
    //     0xf3a424: stur            w0, [x1, #0x1f]
    //     0xf3a428: ldurb           w16, [x1, #-1]
    //     0xf3a42c: ldurb           w17, [x0, #-1]
    //     0xf3a430: and             x16, x17, x16, lsr #2
    //     0xf3a434: tst             x16, HEAP, lsr #32
    //     0xf3a438: b.eq            #0xf3a440
    //     0xf3a43c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf3a440: b               #0xf3a448
    // 0xf3a444: mov             x1, x3
    // 0xf3a448: LoadField: r2 = r1->field_7
    //     0xf3a448: ldur            w2, [x1, #7]
    // 0xf3a44c: DecompressPointer r2
    //     0xf3a44c: add             x2, x2, HEAP, lsl #32
    // 0xf3a450: ldur            x0, [fp, #-0x10]
    // 0xf3a454: r1 = Null
    //     0xf3a454: mov             x1, NULL
    // 0xf3a458: cmp             w2, NULL
    // 0xf3a45c: b.eq            #0xf3a480
    // 0xf3a460: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf3a460: ldur            w4, [x2, #0x17]
    // 0xf3a464: DecompressPointer r4
    //     0xf3a464: add             x4, x4, HEAP, lsl #32
    // 0xf3a468: r8 = X0 bound StatefulWidget
    //     0xf3a468: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf3a46c: ldr             x8, [x8, #0x498]
    // 0xf3a470: LoadField: r9 = r4->field_7
    //     0xf3a470: ldur            x9, [x4, #7]
    // 0xf3a474: r3 = Null
    //     0xf3a474: add             x3, PP, #0xad, lsl #12  ; [pp+0xadbd0] Null
    //     0xf3a478: ldr             x3, [x3, #0xbd0]
    // 0xf3a47c: blr             x9
    // 0xf3a480: r0 = Null
    //     0xf3a480: mov             x0, NULL
    // 0xf3a484: LeaveFrame
    //     0xf3a484: mov             SP, fp
    //     0xf3a488: ldp             fp, lr, [SP], #0x10
    // 0xf3a48c: ret
    //     0xf3a48c: ret             
    // 0xf3a490: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3a490: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3a494: b               #0xf3a270
    // 0xf3a498: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3a498: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3a49c: r9 = delegate
    //     0xf3a49c: add             x9, PP, #0xad, lsl #12  ; [pp+0xadb88] Field <_ZoomEnterTransitionState@110490068.delegate>: late (offset: 0x20)
    //     0xf3a4a0: ldr             x9, [x9, #0xb88]
    // 0xf3a4a4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3a4a4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf3a4a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3a4a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3a4ac: r9 = fadeTransition
    //     0xf3a4ac: add             x9, PP, #0xad, lsl #12  ; [pp+0xadba8] Field <_MixinApplication86&State&_ZoomTransitionBase@18353248.fadeTransition>: late (offset: 0x18)
    //     0xf3a4b0: ldr             x9, [x9, #0xba8]
    // 0xf3a4b4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3a4b4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf3a4b8: r9 = scaleTransition
    //     0xf3a4b8: add             x9, PP, #0xad, lsl #12  ; [pp+0xadba0] Field <_MixinApplication86&State&_ZoomTransitionBase@18353248.scaleTransition>: late (offset: 0x1c)
    //     0xf3a4bc: ldr             x9, [x9, #0xba0]
    // 0xf3a4c0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3a4c0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _updateAnimations(/* No info */) {
    // ** addr: 0xf3a768, size: 0x230
    // 0xf3a768: EnterFrame
    //     0xf3a768: stp             fp, lr, [SP, #-0x10]!
    //     0xf3a76c: mov             fp, SP
    // 0xf3a770: AllocStack(0x10)
    //     0xf3a770: sub             SP, SP, #0x10
    // 0xf3a774: SetupParameters(_ZoomEnterTransitionState this /* r1 => r2, fp-0x8 */)
    //     0xf3a774: mov             x2, x1
    //     0xf3a778: stur            x1, [fp, #-8]
    // 0xf3a77c: CheckStackOverflow
    //     0xf3a77c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3a780: cmp             SP, x16
    //     0xf3a784: b.ls            #0xf3a978
    // 0xf3a788: LoadField: r0 = r2->field_b
    //     0xf3a788: ldur            w0, [x2, #0xb]
    // 0xf3a78c: DecompressPointer r0
    //     0xf3a78c: add             x0, x0, HEAP, lsl #32
    // 0xf3a790: cmp             w0, NULL
    // 0xf3a794: b.eq            #0xf3a980
    // 0xf3a798: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf3a798: ldur            w1, [x0, #0x17]
    // 0xf3a79c: DecompressPointer r1
    //     0xf3a79c: add             x1, x1, HEAP, lsl #32
    // 0xf3a7a0: tbnz            w1, #4, #0xf3a7b0
    // 0xf3a7a4: r0 = Instance__AlwaysCompleteAnimation
    //     0xf3a7a4: add             x0, PP, #0x97, lsl #12  ; [pp+0x97440] Obj!_AlwaysCompleteAnimation@12aa3f1
    //     0xf3a7a8: ldr             x0, [x0, #0x440]
    // 0xf3a7ac: b               #0xf3a7fc
    // 0xf3a7b0: r0 = LoadStaticField(0x734)
    //     0xf3a7b0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf3a7b4: ldr             x0, [x0, #0xe68]
    // 0xf3a7b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3a7bc: cmp             w0, w16
    // 0xf3a7c0: b.ne            #0xf3a7d0
    // 0xf3a7c4: r2 = _fadeInTransition
    //     0xf3a7c4: add             x2, PP, #0xad, lsl #12  ; [pp+0xadbe8] Field <_ZoomEnterTransitionState@110490068._fadeInTransition@110490068>: static late final (offset: 0x734)
    //     0xf3a7c8: ldr             x2, [x2, #0xbe8]
    // 0xf3a7cc: r0 = InitLateFinalStaticField()
    //     0xf3a7cc: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf3a7d0: mov             x1, x0
    // 0xf3a7d4: ldur            x0, [fp, #-8]
    // 0xf3a7d8: LoadField: r2 = r0->field_b
    //     0xf3a7d8: ldur            w2, [x0, #0xb]
    // 0xf3a7dc: DecompressPointer r2
    //     0xf3a7dc: add             x2, x2, HEAP, lsl #32
    // 0xf3a7e0: cmp             w2, NULL
    // 0xf3a7e4: b.eq            #0xf3a984
    // 0xf3a7e8: LoadField: r3 = r2->field_b
    //     0xf3a7e8: ldur            w3, [x2, #0xb]
    // 0xf3a7ec: DecompressPointer r3
    //     0xf3a7ec: add             x3, x3, HEAP, lsl #32
    // 0xf3a7f0: mov             x2, x3
    // 0xf3a7f4: r0 = animate()
    //     0xf3a7f4: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf3a7f8: ldur            x2, [fp, #-8]
    // 0xf3a7fc: ArrayStore: r2[0] = r0  ; List_4
    //     0xf3a7fc: stur            w0, [x2, #0x17]
    //     0xf3a800: ldurb           w16, [x2, #-1]
    //     0xf3a804: ldurb           w17, [x0, #-1]
    //     0xf3a808: and             x16, x17, x16, lsr #2
    //     0xf3a80c: tst             x16, HEAP, lsr #32
    //     0xf3a810: b.eq            #0xf3a818
    //     0xf3a814: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3a818: LoadField: r0 = r2->field_b
    //     0xf3a818: ldur            w0, [x2, #0xb]
    // 0xf3a81c: DecompressPointer r0
    //     0xf3a81c: add             x0, x0, HEAP, lsl #32
    // 0xf3a820: cmp             w0, NULL
    // 0xf3a824: b.eq            #0xf3a988
    // 0xf3a828: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf3a828: ldur            w1, [x0, #0x17]
    // 0xf3a82c: DecompressPointer r1
    //     0xf3a82c: add             x1, x1, HEAP, lsl #32
    // 0xf3a830: tbnz            w1, #4, #0xf3a85c
    // 0xf3a834: r0 = LoadStaticField(0x738)
    //     0xf3a834: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf3a838: ldr             x0, [x0, #0xe70]
    // 0xf3a83c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3a840: cmp             w0, w16
    // 0xf3a844: b.ne            #0xf3a854
    // 0xf3a848: r2 = _scaleDownTransition
    //     0xf3a848: add             x2, PP, #0xad, lsl #12  ; [pp+0xadbf0] Field <_ZoomEnterTransitionState@110490068._scaleDownTransition@110490068>: static late final (offset: 0x738)
    //     0xf3a84c: ldr             x2, [x2, #0xbf0]
    // 0xf3a850: r0 = InitLateFinalStaticField()
    //     0xf3a850: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf3a854: mov             x1, x0
    // 0xf3a858: b               #0xf3a880
    // 0xf3a85c: r0 = LoadStaticField(0x73c)
    //     0xf3a85c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf3a860: ldr             x0, [x0, #0xe78]
    // 0xf3a864: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3a868: cmp             w0, w16
    // 0xf3a86c: b.ne            #0xf3a87c
    // 0xf3a870: r2 = _scaleUpTransition
    //     0xf3a870: add             x2, PP, #0xad, lsl #12  ; [pp+0xadbf8] Field <_ZoomEnterTransitionState@110490068._scaleUpTransition@110490068>: static late final (offset: 0x73c)
    //     0xf3a874: ldr             x2, [x2, #0xbf8]
    // 0xf3a878: r0 = InitLateFinalStaticField()
    //     0xf3a878: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf3a87c: mov             x1, x0
    // 0xf3a880: ldur            x0, [fp, #-8]
    // 0xf3a884: LoadField: r2 = r0->field_b
    //     0xf3a884: ldur            w2, [x0, #0xb]
    // 0xf3a888: DecompressPointer r2
    //     0xf3a888: add             x2, x2, HEAP, lsl #32
    // 0xf3a88c: cmp             w2, NULL
    // 0xf3a890: b.eq            #0xf3a98c
    // 0xf3a894: LoadField: r3 = r2->field_b
    //     0xf3a894: ldur            w3, [x2, #0xb]
    // 0xf3a898: DecompressPointer r3
    //     0xf3a898: add             x3, x3, HEAP, lsl #32
    // 0xf3a89c: mov             x2, x3
    // 0xf3a8a0: r0 = animate()
    //     0xf3a8a0: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf3a8a4: ldur            x3, [fp, #-8]
    // 0xf3a8a8: StoreField: r3->field_1b = r0
    //     0xf3a8a8: stur            w0, [x3, #0x1b]
    //     0xf3a8ac: ldurb           w16, [x3, #-1]
    //     0xf3a8b0: ldurb           w17, [x0, #-1]
    //     0xf3a8b4: and             x16, x17, x16, lsr #2
    //     0xf3a8b8: tst             x16, HEAP, lsr #32
    //     0xf3a8bc: b.eq            #0xf3a8c4
    //     0xf3a8c0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf3a8c4: LoadField: r0 = r3->field_b
    //     0xf3a8c4: ldur            w0, [x3, #0xb]
    // 0xf3a8c8: DecompressPointer r0
    //     0xf3a8c8: add             x0, x0, HEAP, lsl #32
    // 0xf3a8cc: cmp             w0, NULL
    // 0xf3a8d0: b.eq            #0xf3a990
    // 0xf3a8d4: LoadField: r4 = r0->field_b
    //     0xf3a8d4: ldur            w4, [x0, #0xb]
    // 0xf3a8d8: DecompressPointer r4
    //     0xf3a8d8: add             x4, x4, HEAP, lsl #32
    // 0xf3a8dc: mov             x2, x3
    // 0xf3a8e0: stur            x4, [fp, #-0x10]
    // 0xf3a8e4: r1 = Function 'onAnimationValueChange':.
    //     0xf3a8e4: add             x1, PP, #0xad, lsl #12  ; [pp+0xadb90] AnonymousClosure: (0xf3adec), in [dart:mixin_deduplication] _MixinApplication86&State&_ZoomTransitionBase::onAnimationValueChange (0xf3ae24)
    //     0xf3a8e8: ldr             x1, [x1, #0xb90]
    // 0xf3a8ec: r0 = AllocateClosure()
    //     0xf3a8ec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf3a8f0: ldur            x1, [fp, #-0x10]
    // 0xf3a8f4: r2 = LoadClassIdInstr(r1)
    //     0xf3a8f4: ldur            x2, [x1, #-1]
    //     0xf3a8f8: ubfx            x2, x2, #0xc, #0x14
    // 0xf3a8fc: mov             x16, x0
    // 0xf3a900: mov             x0, x2
    // 0xf3a904: mov             x2, x16
    // 0xf3a908: r0 = GDT[cid_x0 + 0xe0ec]()
    //     0xf3a908: mov             x17, #0xe0ec
    //     0xf3a90c: add             lr, x0, x17
    //     0xf3a910: ldr             lr, [x21, lr, lsl #3]
    //     0xf3a914: blr             lr
    // 0xf3a918: ldur            x2, [fp, #-8]
    // 0xf3a91c: LoadField: r0 = r2->field_b
    //     0xf3a91c: ldur            w0, [x2, #0xb]
    // 0xf3a920: DecompressPointer r0
    //     0xf3a920: add             x0, x0, HEAP, lsl #32
    // 0xf3a924: cmp             w0, NULL
    // 0xf3a928: b.eq            #0xf3a994
    // 0xf3a92c: LoadField: r3 = r0->field_b
    //     0xf3a92c: ldur            w3, [x0, #0xb]
    // 0xf3a930: DecompressPointer r3
    //     0xf3a930: add             x3, x3, HEAP, lsl #32
    // 0xf3a934: stur            x3, [fp, #-0x10]
    // 0xf3a938: r1 = Function 'onAnimationStatusChange':.
    //     0xf3a938: add             x1, PP, #0xad, lsl #12  ; [pp+0xadb98] AnonymousClosure: (0xf3acd8), in [dart:mixin_deduplication] _MixinApplication86&State&_ZoomTransitionBase::onAnimationStatusChange (0xf3ad14)
    //     0xf3a93c: ldr             x1, [x1, #0xb98]
    // 0xf3a940: r0 = AllocateClosure()
    //     0xf3a940: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf3a944: ldur            x1, [fp, #-0x10]
    // 0xf3a948: r2 = LoadClassIdInstr(r1)
    //     0xf3a948: ldur            x2, [x1, #-1]
    //     0xf3a94c: ubfx            x2, x2, #0xc, #0x14
    // 0xf3a950: mov             x16, x0
    // 0xf3a954: mov             x0, x2
    // 0xf3a958: mov             x2, x16
    // 0xf3a95c: r0 = GDT[cid_x0 + 0xbeb]()
    //     0xf3a95c: add             lr, x0, #0xbeb
    //     0xf3a960: ldr             lr, [x21, lr, lsl #3]
    //     0xf3a964: blr             lr
    // 0xf3a968: r0 = Null
    //     0xf3a968: mov             x0, NULL
    // 0xf3a96c: LeaveFrame
    //     0xf3a96c: mov             SP, fp
    //     0xf3a970: ldp             fp, lr, [SP], #0x10
    // 0xf3a974: ret
    //     0xf3a974: ret             
    // 0xf3a978: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3a978: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3a97c: b               #0xf3a788
    // 0xf3a980: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3a980: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3a984: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3a984: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3a988: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3a988: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3a98c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3a98c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3a990: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3a990: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3a994: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3a994: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static Animatable<double> _scaleUpTransition() {
    // ** addr: 0xf3a998, size: 0x7c
    // 0xf3a998: EnterFrame
    //     0xf3a998: stp             fp, lr, [SP, #-0x10]!
    //     0xf3a99c: mov             fp, SP
    // 0xf3a9a0: AllocStack(0x8)
    //     0xf3a9a0: sub             SP, SP, #8
    // 0xf3a9a4: CheckStackOverflow
    //     0xf3a9a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3a9a8: cmp             SP, x16
    //     0xf3a9ac: b.ls            #0xf3aa0c
    // 0xf3a9b0: r1 = <double>
    //     0xf3a9b0: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3a9b4: r0 = Tween()
    //     0xf3a9b4: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xf3a9b8: mov             x1, x0
    // 0xf3a9bc: r0 = 0.850000
    //     0xf3a9bc: add             x0, PP, #0x8e, lsl #12  ; [pp+0x8e0e8] 0.85
    //     0xf3a9c0: ldr             x0, [x0, #0xe8]
    // 0xf3a9c4: stur            x1, [fp, #-8]
    // 0xf3a9c8: StoreField: r1->field_b = r0
    //     0xf3a9c8: stur            w0, [x1, #0xb]
    // 0xf3a9cc: r0 = 1.000000
    //     0xf3a9cc: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xf3a9d0: StoreField: r1->field_f = r0
    //     0xf3a9d0: stur            w0, [x1, #0xf]
    // 0xf3a9d4: r0 = LoadStaticField(0x71c)
    //     0xf3a9d4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf3a9d8: ldr             x0, [x0, #0xe38]
    // 0xf3a9dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3a9e0: cmp             w0, w16
    // 0xf3a9e4: b.ne            #0xf3a9f4
    // 0xf3a9e8: r2 = _scaleCurveSequence
    //     0xf3a9e8: add             x2, PP, #0xad, lsl #12  ; [pp+0xadc00] Field <_ZoomPageTransition@110490068._scaleCurveSequence@110490068>: static late final (offset: 0x71c)
    //     0xf3a9ec: ldr             x2, [x2, #0xc00]
    // 0xf3a9f0: r0 = InitLateFinalStaticField()
    //     0xf3a9f0: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf3a9f4: ldur            x1, [fp, #-8]
    // 0xf3a9f8: mov             x2, x0
    // 0xf3a9fc: r0 = chain()
    //     0xf3a9fc: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xf3aa00: LeaveFrame
    //     0xf3aa00: mov             SP, fp
    //     0xf3aa04: ldp             fp, lr, [SP], #0x10
    // 0xf3aa08: ret
    //     0xf3aa08: ret             
    // 0xf3aa0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3aa0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3aa10: b               #0xf3a9b0
  }
  static Animatable<double> _scaleDownTransition() {
    // ** addr: 0xf3abcc, size: 0x7c
    // 0xf3abcc: EnterFrame
    //     0xf3abcc: stp             fp, lr, [SP, #-0x10]!
    //     0xf3abd0: mov             fp, SP
    // 0xf3abd4: AllocStack(0x8)
    //     0xf3abd4: sub             SP, SP, #8
    // 0xf3abd8: CheckStackOverflow
    //     0xf3abd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3abdc: cmp             SP, x16
    //     0xf3abe0: b.ls            #0xf3ac40
    // 0xf3abe4: r1 = <double>
    //     0xf3abe4: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3abe8: r0 = Tween()
    //     0xf3abe8: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xf3abec: mov             x1, x0
    // 0xf3abf0: r0 = 1.100000
    //     0xf3abf0: add             x0, PP, #0xad, lsl #12  ; [pp+0xadc30] 1.1
    //     0xf3abf4: ldr             x0, [x0, #0xc30]
    // 0xf3abf8: stur            x1, [fp, #-8]
    // 0xf3abfc: StoreField: r1->field_b = r0
    //     0xf3abfc: stur            w0, [x1, #0xb]
    // 0xf3ac00: r0 = 1.000000
    //     0xf3ac00: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xf3ac04: StoreField: r1->field_f = r0
    //     0xf3ac04: stur            w0, [x1, #0xf]
    // 0xf3ac08: r0 = LoadStaticField(0x71c)
    //     0xf3ac08: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf3ac0c: ldr             x0, [x0, #0xe38]
    // 0xf3ac10: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3ac14: cmp             w0, w16
    // 0xf3ac18: b.ne            #0xf3ac28
    // 0xf3ac1c: r2 = _scaleCurveSequence
    //     0xf3ac1c: add             x2, PP, #0xad, lsl #12  ; [pp+0xadc00] Field <_ZoomPageTransition@110490068._scaleCurveSequence@110490068>: static late final (offset: 0x71c)
    //     0xf3ac20: ldr             x2, [x2, #0xc00]
    // 0xf3ac24: r0 = InitLateFinalStaticField()
    //     0xf3ac24: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf3ac28: ldur            x1, [fp, #-8]
    // 0xf3ac2c: mov             x2, x0
    // 0xf3ac30: r0 = chain()
    //     0xf3ac30: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xf3ac34: LeaveFrame
    //     0xf3ac34: mov             SP, fp
    //     0xf3ac38: ldp             fp, lr, [SP], #0x10
    // 0xf3ac3c: ret
    //     0xf3ac3c: ret             
    // 0xf3ac40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3ac40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3ac44: b               #0xf3abe4
  }
  static Animatable<double> _fadeInTransition() {
    // ** addr: 0xf3ac48, size: 0x70
    // 0xf3ac48: EnterFrame
    //     0xf3ac48: stp             fp, lr, [SP, #-0x10]!
    //     0xf3ac4c: mov             fp, SP
    // 0xf3ac50: AllocStack(0x8)
    //     0xf3ac50: sub             SP, SP, #8
    // 0xf3ac54: CheckStackOverflow
    //     0xf3ac54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3ac58: cmp             SP, x16
    //     0xf3ac5c: b.ls            #0xf3acb0
    // 0xf3ac60: r1 = <double>
    //     0xf3ac60: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3ac64: r0 = Tween()
    //     0xf3ac64: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xf3ac68: mov             x2, x0
    // 0xf3ac6c: r0 = 0.000000
    //     0xf3ac6c: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xf3ac70: stur            x2, [fp, #-8]
    // 0xf3ac74: StoreField: r2->field_b = r0
    //     0xf3ac74: stur            w0, [x2, #0xb]
    // 0xf3ac78: r0 = 1.000000
    //     0xf3ac78: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xf3ac7c: StoreField: r2->field_f = r0
    //     0xf3ac7c: stur            w0, [x2, #0xf]
    // 0xf3ac80: r1 = <double>
    //     0xf3ac80: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3ac84: r0 = CurveTween()
    //     0xf3ac84: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xf3ac88: mov             x1, x0
    // 0xf3ac8c: r0 = Instance_Interval
    //     0xf3ac8c: add             x0, PP, #0xad, lsl #12  ; [pp+0xadc38] Obj!Interval@129fad1
    //     0xf3ac90: ldr             x0, [x0, #0xc38]
    // 0xf3ac94: StoreField: r1->field_b = r0
    //     0xf3ac94: stur            w0, [x1, #0xb]
    // 0xf3ac98: mov             x2, x1
    // 0xf3ac9c: ldur            x1, [fp, #-8]
    // 0xf3aca0: r0 = chain()
    //     0xf3aca0: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xf3aca4: LeaveFrame
    //     0xf3aca4: mov             SP, fp
    //     0xf3aca8: ldp             fp, lr, [SP], #0x10
    // 0xf3acac: ret
    //     0xf3acac: ret             
    // 0xf3acb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3acb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3acb4: b               #0xf3ac60
  }
  _ initState(/* No info */) {
    // ** addr: 0xf7ad74, size: 0x10c
    // 0xf7ad74: EnterFrame
    //     0xf7ad74: stp             fp, lr, [SP, #-0x10]!
    //     0xf7ad78: mov             fp, SP
    // 0xf7ad7c: AllocStack(0x30)
    //     0xf7ad7c: sub             SP, SP, #0x30
    // 0xf7ad80: SetupParameters(_ZoomEnterTransitionState this /* r1 => r0, fp-0x8 */)
    //     0xf7ad80: mov             x0, x1
    //     0xf7ad84: stur            x1, [fp, #-8]
    // 0xf7ad88: CheckStackOverflow
    //     0xf7ad88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7ad8c: cmp             SP, x16
    //     0xf7ad90: b.ls            #0xf7ae5c
    // 0xf7ad94: mov             x1, x0
    // 0xf7ad98: r0 = _updateAnimations()
    //     0xf7ad98: bl              #0xf3a768  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionState::_updateAnimations
    // 0xf7ad9c: ldur            x0, [fp, #-8]
    // 0xf7ada0: LoadField: r1 = r0->field_b
    //     0xf7ada0: ldur            w1, [x0, #0xb]
    // 0xf7ada4: DecompressPointer r1
    //     0xf7ada4: add             x1, x1, HEAP, lsl #32
    // 0xf7ada8: cmp             w1, NULL
    // 0xf7adac: b.eq            #0xf7ae64
    // 0xf7adb0: ArrayLoad: r6 = r1[0]  ; List_4
    //     0xf7adb0: ldur            w6, [x1, #0x17]
    // 0xf7adb4: DecompressPointer r6
    //     0xf7adb4: add             x6, x6, HEAP, lsl #32
    // 0xf7adb8: stur            x6, [fp, #-0x30]
    // 0xf7adbc: ArrayLoad: r5 = r0[0]  ; List_4
    //     0xf7adbc: ldur            w5, [x0, #0x17]
    // 0xf7adc0: DecompressPointer r5
    //     0xf7adc0: add             x5, x5, HEAP, lsl #32
    // 0xf7adc4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7adc8: cmp             w5, w16
    // 0xf7adcc: b.eq            #0xf7ae68
    // 0xf7add0: stur            x5, [fp, #-0x28]
    // 0xf7add4: LoadField: r7 = r0->field_1b
    //     0xf7add4: ldur            w7, [x0, #0x1b]
    // 0xf7add8: DecompressPointer r7
    //     0xf7add8: add             x7, x7, HEAP, lsl #32
    // 0xf7addc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7ade0: cmp             w7, w16
    // 0xf7ade4: b.eq            #0xf7ae74
    // 0xf7ade8: stur            x7, [fp, #-0x20]
    // 0xf7adec: LoadField: r2 = r1->field_b
    //     0xf7adec: ldur            w2, [x1, #0xb]
    // 0xf7adf0: DecompressPointer r2
    //     0xf7adf0: add             x2, x2, HEAP, lsl #32
    // 0xf7adf4: stur            x2, [fp, #-0x18]
    // 0xf7adf8: LoadField: r3 = r1->field_1b
    //     0xf7adf8: ldur            w3, [x1, #0x1b]
    // 0xf7adfc: DecompressPointer r3
    //     0xf7adfc: add             x3, x3, HEAP, lsl #32
    // 0xf7ae00: stur            x3, [fp, #-0x10]
    // 0xf7ae04: r0 = _ZoomEnterTransitionPainter()
    //     0xf7ae04: bl              #0xf3a75c  ; Allocate_ZoomEnterTransitionPainterStub -> _ZoomEnterTransitionPainter (size=0x44)
    // 0xf7ae08: mov             x1, x0
    // 0xf7ae0c: ldur            x2, [fp, #-0x18]
    // 0xf7ae10: ldur            x3, [fp, #-0x10]
    // 0xf7ae14: ldur            x5, [fp, #-0x28]
    // 0xf7ae18: ldur            x6, [fp, #-0x30]
    // 0xf7ae1c: ldur            x7, [fp, #-0x20]
    // 0xf7ae20: stur            x0, [fp, #-0x10]
    // 0xf7ae24: r0 = _ZoomEnterTransitionPainter()
    //     0xf7ae24: bl              #0xf3a4c4  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionPainter::_ZoomEnterTransitionPainter
    // 0xf7ae28: ldur            x0, [fp, #-0x10]
    // 0xf7ae2c: ldur            x1, [fp, #-8]
    // 0xf7ae30: StoreField: r1->field_1f = r0
    //     0xf7ae30: stur            w0, [x1, #0x1f]
    //     0xf7ae34: ldurb           w16, [x1, #-1]
    //     0xf7ae38: ldurb           w17, [x0, #-1]
    //     0xf7ae3c: and             x16, x17, x16, lsr #2
    //     0xf7ae40: tst             x16, HEAP, lsr #32
    //     0xf7ae44: b.eq            #0xf7ae4c
    //     0xf7ae48: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf7ae4c: r0 = Null
    //     0xf7ae4c: mov             x0, NULL
    // 0xf7ae50: LeaveFrame
    //     0xf7ae50: mov             SP, fp
    //     0xf7ae54: ldp             fp, lr, [SP], #0x10
    // 0xf7ae58: ret
    //     0xf7ae58: ret             
    // 0xf7ae5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7ae5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7ae60: b               #0xf7ad94
    // 0xf7ae64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7ae64: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7ae68: r9 = fadeTransition
    //     0xf7ae68: add             x9, PP, #0xad, lsl #12  ; [pp+0xadba8] Field <_MixinApplication86&State&_ZoomTransitionBase@18353248.fadeTransition>: late (offset: 0x18)
    //     0xf7ae6c: ldr             x9, [x9, #0xba8]
    // 0xf7ae70: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf7ae70: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf7ae74: r9 = scaleTransition
    //     0xf7ae74: add             x9, PP, #0xad, lsl #12  ; [pp+0xadba0] Field <_MixinApplication86&State&_ZoomTransitionBase@18353248.scaleTransition>: late (offset: 0x1c)
    //     0xf7ae78: ldr             x9, [x9, #0xba0]
    // 0xf7ae7c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf7ae7c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10dd368, size: 0x118
    // 0x10dd368: EnterFrame
    //     0x10dd368: stp             fp, lr, [SP, #-0x10]!
    //     0x10dd36c: mov             fp, SP
    // 0x10dd370: AllocStack(0x10)
    //     0x10dd370: sub             SP, SP, #0x10
    // 0x10dd374: SetupParameters(_ZoomEnterTransitionState this /* r1 => r0, fp-0x10 */)
    //     0x10dd374: mov             x0, x1
    //     0x10dd378: stur            x1, [fp, #-0x10]
    // 0x10dd37c: CheckStackOverflow
    //     0x10dd37c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10dd380: cmp             SP, x16
    //     0x10dd384: b.ls            #0x10dd464
    // 0x10dd388: LoadField: r1 = r0->field_b
    //     0x10dd388: ldur            w1, [x0, #0xb]
    // 0x10dd38c: DecompressPointer r1
    //     0x10dd38c: add             x1, x1, HEAP, lsl #32
    // 0x10dd390: cmp             w1, NULL
    // 0x10dd394: b.eq            #0x10dd46c
    // 0x10dd398: LoadField: r3 = r1->field_b
    //     0x10dd398: ldur            w3, [x1, #0xb]
    // 0x10dd39c: DecompressPointer r3
    //     0x10dd39c: add             x3, x3, HEAP, lsl #32
    // 0x10dd3a0: mov             x2, x0
    // 0x10dd3a4: stur            x3, [fp, #-8]
    // 0x10dd3a8: r1 = Function 'onAnimationValueChange':.
    //     0x10dd3a8: add             x1, PP, #0xad, lsl #12  ; [pp+0xadb90] AnonymousClosure: (0xf3adec), in [dart:mixin_deduplication] _MixinApplication86&State&_ZoomTransitionBase::onAnimationValueChange (0xf3ae24)
    //     0x10dd3ac: ldr             x1, [x1, #0xb90]
    // 0x10dd3b0: r0 = AllocateClosure()
    //     0x10dd3b0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10dd3b4: ldur            x1, [fp, #-8]
    // 0x10dd3b8: r2 = LoadClassIdInstr(r1)
    //     0x10dd3b8: ldur            x2, [x1, #-1]
    //     0x10dd3bc: ubfx            x2, x2, #0xc, #0x14
    // 0x10dd3c0: mov             x16, x0
    // 0x10dd3c4: mov             x0, x2
    // 0x10dd3c8: mov             x2, x16
    // 0x10dd3cc: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0x10dd3cc: mov             x17, #0xe2a3
    //     0x10dd3d0: add             lr, x0, x17
    //     0x10dd3d4: ldr             lr, [x21, lr, lsl #3]
    //     0x10dd3d8: blr             lr
    // 0x10dd3dc: ldur            x0, [fp, #-0x10]
    // 0x10dd3e0: LoadField: r1 = r0->field_b
    //     0x10dd3e0: ldur            w1, [x0, #0xb]
    // 0x10dd3e4: DecompressPointer r1
    //     0x10dd3e4: add             x1, x1, HEAP, lsl #32
    // 0x10dd3e8: cmp             w1, NULL
    // 0x10dd3ec: b.eq            #0x10dd470
    // 0x10dd3f0: LoadField: r3 = r1->field_b
    //     0x10dd3f0: ldur            w3, [x1, #0xb]
    // 0x10dd3f4: DecompressPointer r3
    //     0x10dd3f4: add             x3, x3, HEAP, lsl #32
    // 0x10dd3f8: mov             x2, x0
    // 0x10dd3fc: stur            x3, [fp, #-8]
    // 0x10dd400: r1 = Function 'onAnimationStatusChange':.
    //     0x10dd400: add             x1, PP, #0xad, lsl #12  ; [pp+0xadb98] AnonymousClosure: (0xf3acd8), in [dart:mixin_deduplication] _MixinApplication86&State&_ZoomTransitionBase::onAnimationStatusChange (0xf3ad14)
    //     0x10dd404: ldr             x1, [x1, #0xb98]
    // 0x10dd408: r0 = AllocateClosure()
    //     0x10dd408: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10dd40c: ldur            x1, [fp, #-8]
    // 0x10dd410: r2 = LoadClassIdInstr(r1)
    //     0x10dd410: ldur            x2, [x1, #-1]
    //     0x10dd414: ubfx            x2, x2, #0xc, #0x14
    // 0x10dd418: mov             x16, x0
    // 0x10dd41c: mov             x0, x2
    // 0x10dd420: mov             x2, x16
    // 0x10dd424: r0 = GDT[cid_x0 + 0xabe]()
    //     0x10dd424: add             lr, x0, #0xabe
    //     0x10dd428: ldr             lr, [x21, lr, lsl #3]
    //     0x10dd42c: blr             lr
    // 0x10dd430: ldur            x0, [fp, #-0x10]
    // 0x10dd434: LoadField: r1 = r0->field_1f
    //     0x10dd434: ldur            w1, [x0, #0x1f]
    // 0x10dd438: DecompressPointer r1
    //     0x10dd438: add             x1, x1, HEAP, lsl #32
    // 0x10dd43c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10dd440: cmp             w1, w16
    // 0x10dd444: b.eq            #0x10dd474
    // 0x10dd448: r0 = dispose()
    //     0x10dd448: bl              #0x10ef294  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionPainter::dispose
    // 0x10dd44c: ldur            x1, [fp, #-0x10]
    // 0x10dd450: r0 = dispose()
    //     0x10dd450: bl              #0x10e66cc  ; [package:flutter/src/widgets/draggable_scrollable_sheet.dart] _DraggableScrollableActuatorState::dispose
    // 0x10dd454: r0 = Null
    //     0x10dd454: mov             x0, NULL
    // 0x10dd458: LeaveFrame
    //     0x10dd458: mov             SP, fp
    //     0x10dd45c: ldp             fp, lr, [SP], #0x10
    // 0x10dd460: ret
    //     0x10dd460: ret             
    // 0x10dd464: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dd464: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dd468: b               #0x10dd388
    // 0x10dd46c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10dd46c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10dd470: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10dd470: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10dd474: r9 = delegate
    //     0x10dd474: add             x9, PP, #0xad, lsl #12  ; [pp+0xadb88] Field <_ZoomEnterTransitionState@110490068.delegate>: late (offset: 0x20)
    //     0x10dd478: ldr             x9, [x9, #0xb88]
    // 0x10dd47c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10dd47c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  static Animatable<double?> _scrimOpacityTween() {
    // ** addr: 0x121aed4, size: 0x78
    // 0x121aed4: EnterFrame
    //     0x121aed4: stp             fp, lr, [SP, #-0x10]!
    //     0x121aed8: mov             fp, SP
    // 0x121aedc: AllocStack(0x8)
    //     0x121aedc: sub             SP, SP, #8
    // 0x121aee0: CheckStackOverflow
    //     0x121aee0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121aee4: cmp             SP, x16
    //     0x121aee8: b.ls            #0x121af44
    // 0x121aeec: r1 = <double?>
    //     0x121aeec: add             x1, PP, #0x7a, lsl #12  ; [pp+0x7aba8] TypeArguments: <double?>
    //     0x121aef0: ldr             x1, [x1, #0xba8]
    // 0x121aef4: r0 = Tween()
    //     0x121aef4: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x121aef8: mov             x2, x0
    // 0x121aefc: r0 = 0.000000
    //     0x121aefc: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x121af00: stur            x2, [fp, #-8]
    // 0x121af04: StoreField: r2->field_b = r0
    //     0x121af04: stur            w0, [x2, #0xb]
    // 0x121af08: r0 = 0.600000
    //     0x121af08: add             x0, PP, #0x87, lsl #12  ; [pp+0x87238] 0.6
    //     0x121af0c: ldr             x0, [x0, #0x238]
    // 0x121af10: StoreField: r2->field_f = r0
    //     0x121af10: stur            w0, [x2, #0xf]
    // 0x121af14: r1 = <double>
    //     0x121af14: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x121af18: r0 = CurveTween()
    //     0x121af18: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x121af1c: mov             x1, x0
    // 0x121af20: r0 = Instance_Interval
    //     0x121af20: add             x0, PP, #0xd1, lsl #12  ; [pp+0xd1dd0] Obj!Interval@129fe91
    //     0x121af24: ldr             x0, [x0, #0xdd0]
    // 0x121af28: StoreField: r1->field_b = r0
    //     0x121af28: stur            w0, [x1, #0xb]
    // 0x121af2c: mov             x2, x1
    // 0x121af30: ldur            x1, [fp, #-8]
    // 0x121af34: r0 = chain()
    //     0x121af34: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0x121af38: LeaveFrame
    //     0x121af38: mov             SP, fp
    //     0x121af3c: ldp             fp, lr, [SP], #0x10
    // 0x121af40: ret
    //     0x121af40: ret             
    // 0x121af44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121af44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121af48: b               #0x121aeec
  }
}

// class id: 5732, size: 0x14, field offset: 0x14
abstract class _ZoomTransitionBase<X0 bound StatefulWidget> extends State<X0 bound StatefulWidget> {
}

// class id: 6148, size: 0x1c, field offset: 0xc
//   const constructor, 
class _FadeForwardsPageTransition extends StatelessWidget {

  static late final Animatable<Offset> _backwardTranslationTween; // offset: 0x730
  static late final Animatable<Offset> _forwardTranslationTween; // offset: 0x72c

  _ build(/* No info */) {
    // ** addr: 0xfbd6d0, size: 0xac
    // 0xfbd6d0: EnterFrame
    //     0xfbd6d0: stp             fp, lr, [SP, #-0x10]!
    //     0xfbd6d4: mov             fp, SP
    // 0xfbd6d8: AllocStack(0x18)
    //     0xfbd6d8: sub             SP, SP, #0x18
    // 0xfbd6dc: SetupParameters(_FadeForwardsPageTransition this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0xfbd6dc: mov             x0, x1
    //     0xfbd6e0: mov             x1, x2
    // 0xfbd6e4: CheckStackOverflow
    //     0xfbd6e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbd6e8: cmp             SP, x16
    //     0xfbd6ec: b.ls            #0xfbd774
    // 0xfbd6f0: LoadField: r4 = r0->field_b
    //     0xfbd6f0: ldur            w4, [x0, #0xb]
    // 0xfbd6f4: DecompressPointer r4
    //     0xfbd6f4: add             x4, x4, HEAP, lsl #32
    // 0xfbd6f8: stur            x4, [fp, #-8]
    // 0xfbd6fc: LoadField: r2 = r0->field_f
    //     0xfbd6fc: ldur            w2, [x0, #0xf]
    // 0xfbd700: DecompressPointer r2
    //     0xfbd700: add             x2, x2, HEAP, lsl #32
    // 0xfbd704: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xfbd704: ldur            w3, [x0, #0x17]
    // 0xfbd708: DecompressPointer r3
    //     0xfbd708: add             x3, x3, HEAP, lsl #32
    // 0xfbd70c: r0 = _delegatedTransition()
    //     0xfbd70c: bl              #0xfbd77c  ; [package:flutter/src/material/page_transitions_theme.dart] FadeForwardsPageTransitionsBuilder::_delegatedTransition
    // 0xfbd710: stur            x0, [fp, #-0x10]
    // 0xfbd714: r0 = DualTransitionBuilder()
    //     0xfbd714: bl              #0xfbd3c4  ; AllocateDualTransitionBuilderStub -> DualTransitionBuilder (size=0x1c)
    // 0xfbd718: mov             x3, x0
    // 0xfbd71c: ldur            x0, [fp, #-8]
    // 0xfbd720: stur            x3, [fp, #-0x18]
    // 0xfbd724: StoreField: r3->field_b = r0
    //     0xfbd724: stur            w0, [x3, #0xb]
    // 0xfbd728: r1 = Function '<anonymous closure>':.
    //     0xfbd728: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd04e0] AnonymousClosure: (0xfbded0), in [package:flutter/src/material/page_transitions_theme.dart] _FadeForwardsPageTransition::build (0xfbd6d0)
    //     0xfbd72c: ldr             x1, [x1, #0x4e0]
    // 0xfbd730: r2 = Null
    //     0xfbd730: mov             x2, NULL
    // 0xfbd734: r0 = AllocateClosure()
    //     0xfbd734: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfbd738: mov             x1, x0
    // 0xfbd73c: ldur            x0, [fp, #-0x18]
    // 0xfbd740: StoreField: r0->field_f = r1
    //     0xfbd740: stur            w1, [x0, #0xf]
    // 0xfbd744: r1 = Function '<anonymous closure>':.
    //     0xfbd744: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd04e8] AnonymousClosure: (0xfbdd3c), in [package:flutter/src/material/page_transitions_theme.dart] _FadeForwardsPageTransition::build (0xfbd6d0)
    //     0xfbd748: ldr             x1, [x1, #0x4e8]
    // 0xfbd74c: r2 = Null
    //     0xfbd74c: mov             x2, NULL
    // 0xfbd750: r0 = AllocateClosure()
    //     0xfbd750: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfbd754: mov             x1, x0
    // 0xfbd758: ldur            x0, [fp, #-0x18]
    // 0xfbd75c: StoreField: r0->field_13 = r1
    //     0xfbd75c: stur            w1, [x0, #0x13]
    // 0xfbd760: ldur            x1, [fp, #-0x10]
    // 0xfbd764: ArrayStore: r0[0] = r1  ; List_4
    //     0xfbd764: stur            w1, [x0, #0x17]
    // 0xfbd768: LeaveFrame
    //     0xfbd768: mov             SP, fp
    //     0xfbd76c: ldp             fp, lr, [SP], #0x10
    // 0xfbd770: ret
    //     0xfbd770: ret             
    // 0xfbd774: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbd774: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbd778: b               #0xfbd6f0
  }
  [closure] IgnorePointer <anonymous closure>(dynamic, BuildContext, Animation<double>, Widget?) {
    // ** addr: 0xfbdd3c, size: 0x11c
    // 0xfbdd3c: EnterFrame
    //     0xfbdd3c: stp             fp, lr, [SP, #-0x10]!
    //     0xfbdd40: mov             fp, SP
    // 0xfbdd44: AllocStack(0x20)
    //     0xfbdd44: sub             SP, SP, #0x20
    // 0xfbdd48: CheckStackOverflow
    //     0xfbdd48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbdd4c: cmp             SP, x16
    //     0xfbdd50: b.ls            #0xfbde50
    // 0xfbdd54: ldr             x2, [fp, #0x18]
    // 0xfbdd58: r0 = LoadClassIdInstr(r2)
    //     0xfbdd58: ldur            x0, [x2, #-1]
    //     0xfbdd5c: ubfx            x0, x0, #0xc, #0x14
    // 0xfbdd60: mov             x1, x2
    // 0xfbdd64: r0 = GDT[cid_x0 + -0x52]()
    //     0xfbdd64: sub             lr, x0, #0x52
    //     0xfbdd68: ldr             lr, [x21, lr, lsl #3]
    //     0xfbdd6c: blr             lr
    // 0xfbdd70: r16 = Instance_AnimationStatus
    //     0xfbdd70: ldr             x16, [PP, #0x51b8]  ; [pp+0x51b8] Obj!AnimationStatus@12c6181
    // 0xfbdd74: cmp             w0, w16
    // 0xfbdd78: r16 = true
    //     0xfbdd78: add             x16, NULL, #0x20  ; true
    // 0xfbdd7c: r17 = false
    //     0xfbdd7c: add             x17, NULL, #0x30  ; false
    // 0xfbdd80: csel            x1, x16, x17, eq
    // 0xfbdd84: stur            x1, [fp, #-8]
    // 0xfbdd88: r0 = LoadStaticField(0x714)
    //     0xfbdd88: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfbdd8c: ldr             x0, [x0, #0xe28]
    // 0xfbdd90: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbdd94: cmp             w0, w16
    // 0xfbdd98: b.ne            #0xfbdda8
    // 0xfbdd9c: r2 = _fadeOutTransition
    //     0xfbdd9c: add             x2, PP, #0xd0, lsl #12  ; [pp+0xd04f0] Field <FadeForwardsPageTransitionsBuilder._fadeOutTransition@110490068>: static late final (offset: 0x714)
    //     0xfbdda0: ldr             x2, [x2, #0x4f0]
    // 0xfbdda4: r0 = InitLateFinalStaticField()
    //     0xfbdda4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xfbdda8: mov             x1, x0
    // 0xfbddac: ldr             x2, [fp, #0x18]
    // 0xfbddb0: r0 = animate()
    //     0xfbddb0: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xfbddb4: stur            x0, [fp, #-0x10]
    // 0xfbddb8: r0 = LoadStaticField(0x730)
    //     0xfbddb8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfbddbc: ldr             x0, [x0, #0xe60]
    // 0xfbddc0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbddc4: cmp             w0, w16
    // 0xfbddc8: b.ne            #0xfbddd8
    // 0xfbddcc: r2 = _backwardTranslationTween
    //     0xfbddcc: add             x2, PP, #0xd0, lsl #12  ; [pp+0xd04f8] Field <_FadeForwardsPageTransition@110490068._backwardTranslationTween@110490068>: static late final (offset: 0x730)
    //     0xfbddd0: ldr             x2, [x2, #0x4f8]
    // 0xfbddd4: r0 = InitLateFinalStaticField()
    //     0xfbddd4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xfbddd8: mov             x1, x0
    // 0xfbdddc: ldr             x2, [fp, #0x18]
    // 0xfbdde0: r0 = animate()
    //     0xfbdde0: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xfbdde4: stur            x0, [fp, #-0x18]
    // 0xfbdde8: r0 = SlideTransition()
    //     0xfbdde8: bl              #0xb28364  ; AllocateSlideTransitionStub -> SlideTransition (size=0x1c)
    // 0xfbddec: mov             x1, x0
    // 0xfbddf0: r0 = true
    //     0xfbddf0: add             x0, NULL, #0x20  ; true
    // 0xfbddf4: stur            x1, [fp, #-0x20]
    // 0xfbddf8: StoreField: r1->field_13 = r0
    //     0xfbddf8: stur            w0, [x1, #0x13]
    // 0xfbddfc: ldr             x0, [fp, #0x10]
    // 0xfbde00: ArrayStore: r1[0] = r0  ; List_4
    //     0xfbde00: stur            w0, [x1, #0x17]
    // 0xfbde04: ldur            x0, [fp, #-0x18]
    // 0xfbde08: StoreField: r1->field_b = r0
    //     0xfbde08: stur            w0, [x1, #0xb]
    // 0xfbde0c: r0 = FadeTransition()
    //     0xfbde0c: bl              #0xb28358  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0xfbde10: mov             x1, x0
    // 0xfbde14: ldur            x0, [fp, #-0x10]
    // 0xfbde18: stur            x1, [fp, #-0x18]
    // 0xfbde1c: StoreField: r1->field_f = r0
    //     0xfbde1c: stur            w0, [x1, #0xf]
    // 0xfbde20: r0 = false
    //     0xfbde20: add             x0, NULL, #0x30  ; false
    // 0xfbde24: StoreField: r1->field_13 = r0
    //     0xfbde24: stur            w0, [x1, #0x13]
    // 0xfbde28: ldur            x0, [fp, #-0x20]
    // 0xfbde2c: StoreField: r1->field_b = r0
    //     0xfbde2c: stur            w0, [x1, #0xb]
    // 0xfbde30: r0 = IgnorePointer()
    //     0xfbde30: bl              #0xbadc08  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0xfbde34: ldur            x1, [fp, #-8]
    // 0xfbde38: StoreField: r0->field_f = r1
    //     0xfbde38: stur            w1, [x0, #0xf]
    // 0xfbde3c: ldur            x1, [fp, #-0x18]
    // 0xfbde40: StoreField: r0->field_b = r1
    //     0xfbde40: stur            w1, [x0, #0xb]
    // 0xfbde44: LeaveFrame
    //     0xfbde44: mov             SP, fp
    //     0xfbde48: ldp             fp, lr, [SP], #0x10
    // 0xfbde4c: ret
    //     0xfbde4c: ret             
    // 0xfbde50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbde50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbde54: b               #0xfbdd54
  }
  static Animatable<Offset> _backwardTranslationTween() {
    // ** addr: 0xfbde58, size: 0x78
    // 0xfbde58: EnterFrame
    //     0xfbde58: stp             fp, lr, [SP, #-0x10]!
    //     0xfbde5c: mov             fp, SP
    // 0xfbde60: AllocStack(0x8)
    //     0xfbde60: sub             SP, SP, #8
    // 0xfbde64: CheckStackOverflow
    //     0xfbde64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbde68: cmp             SP, x16
    //     0xfbde6c: b.ls            #0xfbdec8
    // 0xfbde70: r1 = <Offset>
    //     0xfbde70: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a48] TypeArguments: <Offset>
    //     0xfbde74: ldr             x1, [x1, #0xa48]
    // 0xfbde78: r0 = Tween()
    //     0xfbde78: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xfbde7c: mov             x2, x0
    // 0xfbde80: r0 = Instance_Offset
    //     0xfbde80: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xfbde84: stur            x2, [fp, #-8]
    // 0xfbde88: StoreField: r2->field_b = r0
    //     0xfbde88: stur            w0, [x2, #0xb]
    // 0xfbde8c: r0 = Instance_Offset
    //     0xfbde8c: add             x0, PP, #0xd0, lsl #12  ; [pp+0xd0500] Obj!Offset@12aa0f1
    //     0xfbde90: ldr             x0, [x0, #0x500]
    // 0xfbde94: StoreField: r2->field_f = r0
    //     0xfbde94: stur            w0, [x2, #0xf]
    // 0xfbde98: r1 = <double>
    //     0xfbde98: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfbde9c: r0 = CurveTween()
    //     0xfbde9c: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xfbdea0: mov             x1, x0
    // 0xfbdea4: r0 = Instance_ThreePointCubic
    //     0xfbdea4: add             x0, PP, #0xa4, lsl #12  ; [pp+0xa4068] Obj!ThreePointCubic@129f3e1
    //     0xfbdea8: ldr             x0, [x0, #0x68]
    // 0xfbdeac: StoreField: r1->field_b = r0
    //     0xfbdeac: stur            w0, [x1, #0xb]
    // 0xfbdeb0: mov             x2, x1
    // 0xfbdeb4: ldur            x1, [fp, #-8]
    // 0xfbdeb8: r0 = chain()
    //     0xfbdeb8: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xfbdebc: LeaveFrame
    //     0xfbdebc: mov             SP, fp
    //     0xfbdec0: ldp             fp, lr, [SP], #0x10
    // 0xfbdec4: ret
    //     0xfbdec4: ret             
    // 0xfbdec8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbdec8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbdecc: b               #0xfbde70
  }
  [closure] FadeTransition <anonymous closure>(dynamic, BuildContext, Animation<double>, Widget?) {
    // ** addr: 0xfbded0, size: 0xcc
    // 0xfbded0: EnterFrame
    //     0xfbded0: stp             fp, lr, [SP, #-0x10]!
    //     0xfbded4: mov             fp, SP
    // 0xfbded8: AllocStack(0x18)
    //     0xfbded8: sub             SP, SP, #0x18
    // 0xfbdedc: CheckStackOverflow
    //     0xfbdedc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbdee0: cmp             SP, x16
    //     0xfbdee4: b.ls            #0xfbdf94
    // 0xfbdee8: r0 = LoadStaticField(0x710)
    //     0xfbdee8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfbdeec: ldr             x0, [x0, #0xe20]
    // 0xfbdef0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbdef4: cmp             w0, w16
    // 0xfbdef8: b.ne            #0xfbdf08
    // 0xfbdefc: r2 = _fadeInTransition
    //     0xfbdefc: add             x2, PP, #0xd0, lsl #12  ; [pp+0xd0510] Field <FadeForwardsPageTransitionsBuilder._fadeInTransition@110490068>: static late final (offset: 0x710)
    //     0xfbdf00: ldr             x2, [x2, #0x510]
    // 0xfbdf04: r0 = InitLateFinalStaticField()
    //     0xfbdf04: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xfbdf08: mov             x1, x0
    // 0xfbdf0c: ldr             x2, [fp, #0x18]
    // 0xfbdf10: r0 = animate()
    //     0xfbdf10: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xfbdf14: stur            x0, [fp, #-8]
    // 0xfbdf18: r0 = LoadStaticField(0x72c)
    //     0xfbdf18: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfbdf1c: ldr             x0, [x0, #0xe58]
    // 0xfbdf20: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfbdf24: cmp             w0, w16
    // 0xfbdf28: b.ne            #0xfbdf38
    // 0xfbdf2c: r2 = _forwardTranslationTween
    //     0xfbdf2c: add             x2, PP, #0xd0, lsl #12  ; [pp+0xd0518] Field <_FadeForwardsPageTransition@110490068._forwardTranslationTween@110490068>: static late final (offset: 0x72c)
    //     0xfbdf30: ldr             x2, [x2, #0x518]
    // 0xfbdf34: r0 = InitLateFinalStaticField()
    //     0xfbdf34: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xfbdf38: mov             x1, x0
    // 0xfbdf3c: ldr             x2, [fp, #0x18]
    // 0xfbdf40: r0 = animate()
    //     0xfbdf40: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xfbdf44: stur            x0, [fp, #-0x10]
    // 0xfbdf48: r0 = SlideTransition()
    //     0xfbdf48: bl              #0xb28364  ; AllocateSlideTransitionStub -> SlideTransition (size=0x1c)
    // 0xfbdf4c: mov             x1, x0
    // 0xfbdf50: r0 = true
    //     0xfbdf50: add             x0, NULL, #0x20  ; true
    // 0xfbdf54: stur            x1, [fp, #-0x18]
    // 0xfbdf58: StoreField: r1->field_13 = r0
    //     0xfbdf58: stur            w0, [x1, #0x13]
    // 0xfbdf5c: ldr             x0, [fp, #0x10]
    // 0xfbdf60: ArrayStore: r1[0] = r0  ; List_4
    //     0xfbdf60: stur            w0, [x1, #0x17]
    // 0xfbdf64: ldur            x0, [fp, #-0x10]
    // 0xfbdf68: StoreField: r1->field_b = r0
    //     0xfbdf68: stur            w0, [x1, #0xb]
    // 0xfbdf6c: r0 = FadeTransition()
    //     0xfbdf6c: bl              #0xb28358  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0xfbdf70: ldur            x1, [fp, #-8]
    // 0xfbdf74: StoreField: r0->field_f = r1
    //     0xfbdf74: stur            w1, [x0, #0xf]
    // 0xfbdf78: r1 = false
    //     0xfbdf78: add             x1, NULL, #0x30  ; false
    // 0xfbdf7c: StoreField: r0->field_13 = r1
    //     0xfbdf7c: stur            w1, [x0, #0x13]
    // 0xfbdf80: ldur            x1, [fp, #-0x18]
    // 0xfbdf84: StoreField: r0->field_b = r1
    //     0xfbdf84: stur            w1, [x0, #0xb]
    // 0xfbdf88: LeaveFrame
    //     0xfbdf88: mov             SP, fp
    //     0xfbdf8c: ldp             fp, lr, [SP], #0x10
    // 0xfbdf90: ret
    //     0xfbdf90: ret             
    // 0xfbdf94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbdf94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbdf98: b               #0xfbdee8
  }
  static Animatable<Offset> _forwardTranslationTween() {
    // ** addr: 0xfbdf9c, size: 0x78
    // 0xfbdf9c: EnterFrame
    //     0xfbdf9c: stp             fp, lr, [SP, #-0x10]!
    //     0xfbdfa0: mov             fp, SP
    // 0xfbdfa4: AllocStack(0x8)
    //     0xfbdfa4: sub             SP, SP, #8
    // 0xfbdfa8: CheckStackOverflow
    //     0xfbdfa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbdfac: cmp             SP, x16
    //     0xfbdfb0: b.ls            #0xfbe00c
    // 0xfbdfb4: r1 = <Offset>
    //     0xfbdfb4: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a48] TypeArguments: <Offset>
    //     0xfbdfb8: ldr             x1, [x1, #0xa48]
    // 0xfbdfbc: r0 = Tween()
    //     0xfbdfbc: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xfbdfc0: mov             x2, x0
    // 0xfbdfc4: r0 = Instance_Offset
    //     0xfbdfc4: add             x0, PP, #0xd0, lsl #12  ; [pp+0xd0500] Obj!Offset@12aa0f1
    //     0xfbdfc8: ldr             x0, [x0, #0x500]
    // 0xfbdfcc: stur            x2, [fp, #-8]
    // 0xfbdfd0: StoreField: r2->field_b = r0
    //     0xfbdfd0: stur            w0, [x2, #0xb]
    // 0xfbdfd4: r0 = Instance_Offset
    //     0xfbdfd4: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xfbdfd8: StoreField: r2->field_f = r0
    //     0xfbdfd8: stur            w0, [x2, #0xf]
    // 0xfbdfdc: r1 = <double>
    //     0xfbdfdc: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfbdfe0: r0 = CurveTween()
    //     0xfbdfe0: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xfbdfe4: mov             x1, x0
    // 0xfbdfe8: r0 = Instance_ThreePointCubic
    //     0xfbdfe8: add             x0, PP, #0xa4, lsl #12  ; [pp+0xa4068] Obj!ThreePointCubic@129f3e1
    //     0xfbdfec: ldr             x0, [x0, #0x68]
    // 0xfbdff0: StoreField: r1->field_b = r0
    //     0xfbdff0: stur            w0, [x1, #0xb]
    // 0xfbdff4: mov             x2, x1
    // 0xfbdff8: ldur            x1, [fp, #-8]
    // 0xfbdffc: r0 = chain()
    //     0xfbdffc: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xfbe000: LeaveFrame
    //     0xfbe000: mov             SP, fp
    //     0xfbe004: ldp             fp, lr, [SP], #0x10
    // 0xfbe008: ret
    //     0xfbe008: ret             
    // 0xfbe00c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbe00c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbe010: b               #0xfbdfb4
  }
}

// class id: 6149, size: 0x24, field offset: 0xc
//   const constructor, 
class _ZoomPageTransition extends StatelessWidget {

  static late final TweenSequence<double> _scaleCurveSequence; // offset: 0x71c
  static late final List<TweenSequenceItem<double>> fastOutExtraSlowInTweenSequenceItems; // offset: 0x718

  static TweenSequence<double> _scaleCurveSequence() {
    // ** addr: 0xf3aa14, size: 0x6c
    // 0xf3aa14: EnterFrame
    //     0xf3aa14: stp             fp, lr, [SP, #-0x10]!
    //     0xf3aa18: mov             fp, SP
    // 0xf3aa1c: AllocStack(0x8)
    //     0xf3aa1c: sub             SP, SP, #8
    // 0xf3aa20: CheckStackOverflow
    //     0xf3aa20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3aa24: cmp             SP, x16
    //     0xf3aa28: b.ls            #0xf3aa78
    // 0xf3aa2c: r0 = LoadStaticField(0x718)
    //     0xf3aa2c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf3aa30: ldr             x0, [x0, #0xe30]
    // 0xf3aa34: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3aa38: cmp             w0, w16
    // 0xf3aa3c: b.ne            #0xf3aa4c
    // 0xf3aa40: r2 = fastOutExtraSlowInTweenSequenceItems
    //     0xf3aa40: add             x2, PP, #0xad, lsl #12  ; [pp+0xadc08] Field <_ZoomPageTransition@110490068.fastOutExtraSlowInTweenSequenceItems>: static late final (offset: 0x718)
    //     0xf3aa44: ldr             x2, [x2, #0xc08]
    // 0xf3aa48: r0 = InitLateFinalStaticField()
    //     0xf3aa48: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf3aa4c: r1 = <double>
    //     0xf3aa4c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3aa50: stur            x0, [fp, #-8]
    // 0xf3aa54: r0 = TweenSequence()
    //     0xf3aa54: bl              #0xb6f808  ; AllocateTweenSequenceStub -> TweenSequence<X0> (size=0x14)
    // 0xf3aa58: mov             x1, x0
    // 0xf3aa5c: ldur            x2, [fp, #-8]
    // 0xf3aa60: stur            x0, [fp, #-8]
    // 0xf3aa64: r0 = TweenSequence()
    //     0xf3aa64: bl              #0xb6f43c  ; [package:flutter/src/animation/tween_sequence.dart] TweenSequence::TweenSequence
    // 0xf3aa68: ldur            x0, [fp, #-8]
    // 0xf3aa6c: LeaveFrame
    //     0xf3aa6c: mov             SP, fp
    //     0xf3aa70: ldp             fp, lr, [SP], #0x10
    // 0xf3aa74: ret
    //     0xf3aa74: ret             
    // 0xf3aa78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3aa78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3aa7c: b               #0xf3aa2c
  }
  static List<TweenSequenceItem<double>> fastOutExtraSlowInTweenSequenceItems() {
    // ** addr: 0xf3aa80, size: 0x14c
    // 0xf3aa80: EnterFrame
    //     0xf3aa80: stp             fp, lr, [SP, #-0x10]!
    //     0xf3aa84: mov             fp, SP
    // 0xf3aa88: AllocStack(0x18)
    //     0xf3aa88: sub             SP, SP, #0x18
    // 0xf3aa8c: CheckStackOverflow
    //     0xf3aa8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3aa90: cmp             SP, x16
    //     0xf3aa94: b.ls            #0xf3abc4
    // 0xf3aa98: r1 = <double>
    //     0xf3aa98: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3aa9c: r0 = Tween()
    //     0xf3aa9c: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xf3aaa0: mov             x2, x0
    // 0xf3aaa4: r0 = 0.000000
    //     0xf3aaa4: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xf3aaa8: stur            x2, [fp, #-8]
    // 0xf3aaac: StoreField: r2->field_b = r0
    //     0xf3aaac: stur            w0, [x2, #0xb]
    // 0xf3aab0: r0 = 0.400000
    //     0xf3aab0: add             x0, PP, #0x8e, lsl #12  ; [pp+0x8edc0] 0.4
    //     0xf3aab4: ldr             x0, [x0, #0xdc0]
    // 0xf3aab8: StoreField: r2->field_f = r0
    //     0xf3aab8: stur            w0, [x2, #0xf]
    // 0xf3aabc: r1 = <double>
    //     0xf3aabc: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3aac0: r0 = CurveTween()
    //     0xf3aac0: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xf3aac4: mov             x1, x0
    // 0xf3aac8: r0 = Instance_Cubic
    //     0xf3aac8: add             x0, PP, #0xad, lsl #12  ; [pp+0xadc10] Obj!Cubic@129f751
    //     0xf3aacc: ldr             x0, [x0, #0xc10]
    // 0xf3aad0: StoreField: r1->field_b = r0
    //     0xf3aad0: stur            w0, [x1, #0xb]
    // 0xf3aad4: mov             x2, x1
    // 0xf3aad8: ldur            x1, [fp, #-8]
    // 0xf3aadc: r0 = chain()
    //     0xf3aadc: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xf3aae0: r1 = <double>
    //     0xf3aae0: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3aae4: stur            x0, [fp, #-8]
    // 0xf3aae8: r0 = TweenSequenceItem()
    //     0xf3aae8: bl              #0xb6f82c  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0xf3aaec: mov             x2, x0
    // 0xf3aaf0: ldur            x0, [fp, #-8]
    // 0xf3aaf4: stur            x2, [fp, #-0x10]
    // 0xf3aaf8: StoreField: r2->field_b = r0
    //     0xf3aaf8: stur            w0, [x2, #0xb]
    // 0xf3aafc: d0 = 0.166666
    //     0xf3aafc: add             x17, PP, #0xad, lsl #12  ; [pp+0xadc18] IMM: double(0.166666) from 0x3fc5554fbdad7519
    //     0xf3ab00: ldr             d0, [x17, #0xc18]
    // 0xf3ab04: StoreField: r2->field_f = d0
    //     0xf3ab04: stur            d0, [x2, #0xf]
    // 0xf3ab08: r1 = <double>
    //     0xf3ab08: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3ab0c: r0 = Tween()
    //     0xf3ab0c: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xf3ab10: mov             x2, x0
    // 0xf3ab14: r0 = 0.400000
    //     0xf3ab14: add             x0, PP, #0x8e, lsl #12  ; [pp+0x8edc0] 0.4
    //     0xf3ab18: ldr             x0, [x0, #0xdc0]
    // 0xf3ab1c: stur            x2, [fp, #-8]
    // 0xf3ab20: StoreField: r2->field_b = r0
    //     0xf3ab20: stur            w0, [x2, #0xb]
    // 0xf3ab24: r0 = 1.000000
    //     0xf3ab24: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xf3ab28: StoreField: r2->field_f = r0
    //     0xf3ab28: stur            w0, [x2, #0xf]
    // 0xf3ab2c: r1 = <double>
    //     0xf3ab2c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3ab30: r0 = CurveTween()
    //     0xf3ab30: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xf3ab34: mov             x1, x0
    // 0xf3ab38: r0 = Instance_Cubic
    //     0xf3ab38: add             x0, PP, #0xad, lsl #12  ; [pp+0xadc20] Obj!Cubic@129f721
    //     0xf3ab3c: ldr             x0, [x0, #0xc20]
    // 0xf3ab40: StoreField: r1->field_b = r0
    //     0xf3ab40: stur            w0, [x1, #0xb]
    // 0xf3ab44: mov             x2, x1
    // 0xf3ab48: ldur            x1, [fp, #-8]
    // 0xf3ab4c: r0 = chain()
    //     0xf3ab4c: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xf3ab50: r1 = <double>
    //     0xf3ab50: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3ab54: stur            x0, [fp, #-8]
    // 0xf3ab58: r0 = TweenSequenceItem()
    //     0xf3ab58: bl              #0xb6f82c  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0xf3ab5c: mov             x3, x0
    // 0xf3ab60: ldur            x0, [fp, #-8]
    // 0xf3ab64: stur            x3, [fp, #-0x18]
    // 0xf3ab68: StoreField: r3->field_b = r0
    //     0xf3ab68: stur            w0, [x3, #0xb]
    // 0xf3ab6c: d0 = 0.833334
    //     0xf3ab6c: add             x17, PP, #0xad, lsl #12  ; [pp+0xadc28] IMM: double(0.833334) from 0x3feaaaac1094a2ba
    //     0xf3ab70: ldr             d0, [x17, #0xc28]
    // 0xf3ab74: StoreField: r3->field_f = d0
    //     0xf3ab74: stur            d0, [x3, #0xf]
    // 0xf3ab78: r1 = Null
    //     0xf3ab78: mov             x1, NULL
    // 0xf3ab7c: r2 = 4
    //     0xf3ab7c: mov             x2, #4
    // 0xf3ab80: r0 = AllocateArray()
    //     0xf3ab80: bl              #0x13df928  ; AllocateArrayStub
    // 0xf3ab84: mov             x2, x0
    // 0xf3ab88: ldur            x0, [fp, #-0x10]
    // 0xf3ab8c: stur            x2, [fp, #-8]
    // 0xf3ab90: StoreField: r2->field_f = r0
    //     0xf3ab90: stur            w0, [x2, #0xf]
    // 0xf3ab94: ldur            x0, [fp, #-0x18]
    // 0xf3ab98: StoreField: r2->field_13 = r0
    //     0xf3ab98: stur            w0, [x2, #0x13]
    // 0xf3ab9c: r1 = <TweenSequenceItem<double>>
    //     0xf3ab9c: add             x1, PP, #0x99, lsl #12  ; [pp+0x995e0] TypeArguments: <TweenSequenceItem<double>>
    //     0xf3aba0: ldr             x1, [x1, #0x5e0]
    // 0xf3aba4: r0 = AllocateGrowableArray()
    //     0xf3aba4: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xf3aba8: ldur            x1, [fp, #-8]
    // 0xf3abac: StoreField: r0->field_f = r1
    //     0xf3abac: stur            w1, [x0, #0xf]
    // 0xf3abb0: r1 = 4
    //     0xf3abb0: mov             x1, #4
    // 0xf3abb4: StoreField: r0->field_b = r1
    //     0xf3abb4: stur            w1, [x0, #0xb]
    // 0xf3abb8: LeaveFrame
    //     0xf3abb8: mov             SP, fp
    //     0xf3abbc: ldp             fp, lr, [SP], #0x10
    // 0xf3abc0: ret
    //     0xf3abc0: ret             
    // 0xf3abc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3abc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3abc8: b               #0xf3aa98
  }
  _ build(/* No info */) {
    // ** addr: 0xfbd2a8, size: 0x11c
    // 0xfbd2a8: EnterFrame
    //     0xfbd2a8: stp             fp, lr, [SP, #-0x10]!
    //     0xfbd2ac: mov             fp, SP
    // 0xfbd2b0: AllocStack(0x20)
    //     0xfbd2b0: sub             SP, SP, #0x20
    // 0xfbd2b4: SetupParameters(_ZoomPageTransition this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xfbd2b4: mov             x0, x1
    //     0xfbd2b8: stur            x1, [fp, #-8]
    //     0xfbd2bc: mov             x1, x2
    //     0xfbd2c0: stur            x2, [fp, #-0x10]
    // 0xfbd2c4: CheckStackOverflow
    //     0xfbd2c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbd2c8: cmp             SP, x16
    //     0xfbd2cc: b.ls            #0xfbd3bc
    // 0xfbd2d0: r1 = 2
    //     0xfbd2d0: mov             x1, #2
    // 0xfbd2d4: r0 = AllocateContext()
    //     0xfbd2d4: bl              #0x13de838  ; AllocateContextStub
    // 0xfbd2d8: mov             x2, x0
    // 0xfbd2dc: ldur            x0, [fp, #-8]
    // 0xfbd2e0: stur            x2, [fp, #-0x18]
    // 0xfbd2e4: StoreField: r2->field_f = r0
    //     0xfbd2e4: stur            w0, [x2, #0xf]
    // 0xfbd2e8: ldur            x1, [fp, #-0x10]
    // 0xfbd2ec: r0 = of()
    //     0xfbd2ec: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfbd2f0: LoadField: r1 = r0->field_3f
    //     0xfbd2f0: ldur            w1, [x0, #0x3f]
    // 0xfbd2f4: DecompressPointer r1
    //     0xfbd2f4: add             x1, x1, HEAP, lsl #32
    // 0xfbd2f8: LoadField: r2 = r1->field_7b
    //     0xfbd2f8: ldur            w2, [x1, #0x7b]
    // 0xfbd2fc: DecompressPointer r2
    //     0xfbd2fc: add             x2, x2, HEAP, lsl #32
    // 0xfbd300: mov             x0, x2
    // 0xfbd304: ldur            x4, [fp, #-0x18]
    // 0xfbd308: StoreField: r4->field_13 = r0
    //     0xfbd308: stur            w0, [x4, #0x13]
    //     0xfbd30c: ldurb           w16, [x4, #-1]
    //     0xfbd310: ldurb           w17, [x0, #-1]
    //     0xfbd314: and             x16, x17, x16, lsr #2
    //     0xfbd318: tst             x16, HEAP, lsr #32
    //     0xfbd31c: b.eq            #0xfbd324
    //     0xfbd320: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xfbd324: ldur            x0, [fp, #-8]
    // 0xfbd328: LoadField: r7 = r0->field_b
    //     0xfbd328: ldur            w7, [x0, #0xb]
    // 0xfbd32c: DecompressPointer r7
    //     0xfbd32c: add             x7, x7, HEAP, lsl #32
    // 0xfbd330: stur            x7, [fp, #-0x20]
    // 0xfbd334: LoadField: r1 = r0->field_f
    //     0xfbd334: ldur            w1, [x0, #0xf]
    // 0xfbd338: DecompressPointer r1
    //     0xfbd338: add             x1, x1, HEAP, lsl #32
    // 0xfbd33c: LoadField: r3 = r0->field_1b
    //     0xfbd33c: ldur            w3, [x0, #0x1b]
    // 0xfbd340: DecompressPointer r3
    //     0xfbd340: add             x3, x3, HEAP, lsl #32
    // 0xfbd344: mov             x6, x2
    // 0xfbd348: mov             x2, x1
    // 0xfbd34c: ldur            x1, [fp, #-0x10]
    // 0xfbd350: r5 = true
    //     0xfbd350: add             x5, NULL, #0x20  ; true
    // 0xfbd354: r0 = _snapshotAwareDelegatedTransition()
    //     0xfbd354: bl              #0xfbd3d0  ; [package:flutter/src/material/page_transitions_theme.dart] ZoomPageTransitionsBuilder::_snapshotAwareDelegatedTransition
    // 0xfbd358: stur            x0, [fp, #-8]
    // 0xfbd35c: r0 = DualTransitionBuilder()
    //     0xfbd35c: bl              #0xfbd3c4  ; AllocateDualTransitionBuilderStub -> DualTransitionBuilder (size=0x1c)
    // 0xfbd360: mov             x3, x0
    // 0xfbd364: ldur            x0, [fp, #-0x20]
    // 0xfbd368: stur            x3, [fp, #-0x10]
    // 0xfbd36c: StoreField: r3->field_b = r0
    //     0xfbd36c: stur            w0, [x3, #0xb]
    // 0xfbd370: ldur            x2, [fp, #-0x18]
    // 0xfbd374: r1 = Function '<anonymous closure>':.
    //     0xfbd374: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa38d0] AnonymousClosure: (0xfbd674), in [package:flutter/src/material/page_transitions_theme.dart] _ZoomPageTransition::build (0xfbd2a8)
    //     0xfbd378: ldr             x1, [x1, #0x8d0]
    // 0xfbd37c: r0 = AllocateClosure()
    //     0xfbd37c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfbd380: mov             x1, x0
    // 0xfbd384: ldur            x0, [fp, #-0x10]
    // 0xfbd388: StoreField: r0->field_f = r1
    //     0xfbd388: stur            w1, [x0, #0xf]
    // 0xfbd38c: ldur            x2, [fp, #-0x18]
    // 0xfbd390: r1 = Function '<anonymous closure>':.
    //     0xfbd390: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa38d8] AnonymousClosure: (0xfbd640), in [package:flutter/src/material/page_transitions_theme.dart] _ZoomPageTransition::build (0xfbd2a8)
    //     0xfbd394: ldr             x1, [x1, #0x8d8]
    // 0xfbd398: r0 = AllocateClosure()
    //     0xfbd398: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfbd39c: mov             x1, x0
    // 0xfbd3a0: ldur            x0, [fp, #-0x10]
    // 0xfbd3a4: StoreField: r0->field_13 = r1
    //     0xfbd3a4: stur            w1, [x0, #0x13]
    // 0xfbd3a8: ldur            x1, [fp, #-8]
    // 0xfbd3ac: ArrayStore: r0[0] = r1  ; List_4
    //     0xfbd3ac: stur            w1, [x0, #0x17]
    // 0xfbd3b0: LeaveFrame
    //     0xfbd3b0: mov             SP, fp
    //     0xfbd3b4: ldp             fp, lr, [SP], #0x10
    // 0xfbd3b8: ret
    //     0xfbd3b8: ret             
    // 0xfbd3bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbd3bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbd3c0: b               #0xfbd2d0
  }
  [closure] _ZoomExitTransition <anonymous closure>(dynamic, BuildContext, Animation<double>, Widget?) {
    // ** addr: 0xfbd640, size: 0x34
    // 0xfbd640: EnterFrame
    //     0xfbd640: stp             fp, lr, [SP, #-0x10]!
    //     0xfbd644: mov             fp, SP
    // 0xfbd648: r0 = _ZoomExitTransition()
    //     0xfbd648: bl              #0xfbd5a8  ; Allocate_ZoomExitTransitionStub -> _ZoomExitTransition (size=0x1c)
    // 0xfbd64c: ldr             x1, [fp, #0x18]
    // 0xfbd650: StoreField: r0->field_b = r1
    //     0xfbd650: stur            w1, [x0, #0xb]
    // 0xfbd654: r1 = true
    //     0xfbd654: add             x1, NULL, #0x20  ; true
    // 0xfbd658: StoreField: r0->field_13 = r1
    //     0xfbd658: stur            w1, [x0, #0x13]
    // 0xfbd65c: StoreField: r0->field_f = r1
    //     0xfbd65c: stur            w1, [x0, #0xf]
    // 0xfbd660: ldr             x1, [fp, #0x10]
    // 0xfbd664: ArrayStore: r0[0] = r1  ; List_4
    //     0xfbd664: stur            w1, [x0, #0x17]
    // 0xfbd668: LeaveFrame
    //     0xfbd668: mov             SP, fp
    //     0xfbd66c: ldp             fp, lr, [SP], #0x10
    // 0xfbd670: ret
    //     0xfbd670: ret             
  }
  [closure] _ZoomEnterTransition <anonymous closure>(dynamic, BuildContext, Animation<double>, Widget?) {
    // ** addr: 0xfbd674, size: 0x5c
    // 0xfbd674: EnterFrame
    //     0xfbd674: stp             fp, lr, [SP, #-0x10]!
    //     0xfbd678: mov             fp, SP
    // 0xfbd67c: AllocStack(0x8)
    //     0xfbd67c: sub             SP, SP, #8
    // 0xfbd680: SetupParameters([dynamic _ /* r0 */])
    //     0xfbd680: ldr             x0, [fp, #0x28]
    //     0xfbd684: ldur            w1, [x0, #0x17]
    //     0xfbd688: add             x1, x1, HEAP, lsl #32
    // 0xfbd68c: LoadField: r0 = r1->field_13
    //     0xfbd68c: ldur            w0, [x1, #0x13]
    // 0xfbd690: DecompressPointer r0
    //     0xfbd690: add             x0, x0, HEAP, lsl #32
    // 0xfbd694: stur            x0, [fp, #-8]
    // 0xfbd698: r0 = _ZoomEnterTransition()
    //     0xfbd698: bl              #0xfbd634  ; Allocate_ZoomEnterTransitionStub -> _ZoomEnterTransition (size=0x20)
    // 0xfbd69c: ldr             x1, [fp, #0x18]
    // 0xfbd6a0: StoreField: r0->field_b = r1
    //     0xfbd6a0: stur            w1, [x0, #0xb]
    // 0xfbd6a4: r1 = false
    //     0xfbd6a4: add             x1, NULL, #0x30  ; false
    // 0xfbd6a8: ArrayStore: r0[0] = r1  ; List_4
    //     0xfbd6a8: stur            w1, [x0, #0x17]
    // 0xfbd6ac: r1 = true
    //     0xfbd6ac: add             x1, NULL, #0x20  ; true
    // 0xfbd6b0: StoreField: r0->field_13 = r1
    //     0xfbd6b0: stur            w1, [x0, #0x13]
    // 0xfbd6b4: ldur            x1, [fp, #-8]
    // 0xfbd6b8: StoreField: r0->field_1b = r1
    //     0xfbd6b8: stur            w1, [x0, #0x1b]
    // 0xfbd6bc: ldr             x1, [fp, #0x10]
    // 0xfbd6c0: StoreField: r0->field_f = r1
    //     0xfbd6c0: stur            w1, [x0, #0xf]
    // 0xfbd6c4: LeaveFrame
    //     0xfbd6c4: mov             SP, fp
    //     0xfbd6c8: ldp             fp, lr, [SP], #0x10
    // 0xfbd6cc: ret
    //     0xfbd6cc: ret             
  }
}

// class id: 6454, size: 0x24, field offset: 0xc
//   const constructor, 
class _PageTransitionsThemeTransitions<X0> extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa2284, size: 0x3c
    // 0xfa2284: EnterFrame
    //     0xfa2284: stp             fp, lr, [SP, #-0x10]!
    //     0xfa2288: mov             fp, SP
    // 0xfa228c: LoadField: r2 = r1->field_b
    //     0xfa228c: ldur            w2, [x1, #0xb]
    // 0xfa2290: DecompressPointer r2
    //     0xfa2290: add             x2, x2, HEAP, lsl #32
    // 0xfa2294: r1 = Null
    //     0xfa2294: mov             x1, NULL
    // 0xfa2298: r3 = <_PageTransitionsThemeTransitions<X0>, X0>
    //     0xfa2298: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa38c8] TypeArguments: <_PageTransitionsThemeTransitions<X0>, X0>
    //     0xfa229c: ldr             x3, [x3, #0x8c8]
    // 0xfa22a0: r30 = InstantiateTypeArgumentsStub
    //     0xfa22a0: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xfa22a4: LoadField: r30 = r30->field_7
    //     0xfa22a4: ldur            lr, [lr, #7]
    // 0xfa22a8: blr             lr
    // 0xfa22ac: mov             x1, x0
    // 0xfa22b0: r0 = _PageTransitionsThemeTransitionsState()
    //     0xfa22b0: bl              #0xfa22c0  ; Allocate_PageTransitionsThemeTransitionsStateStub -> _PageTransitionsThemeTransitionsState<C1X0> (size=0x18)
    // 0xfa22b4: LeaveFrame
    //     0xfa22b4: mov             SP, fp
    //     0xfa22b8: ldp             fp, lr, [SP], #0x10
    // 0xfa22bc: ret
    //     0xfa22bc: ret             
  }
}

// class id: 6455, size: 0x1c, field offset: 0xc
//   const constructor, 
class _ZoomExitTransition extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa2184, size: 0x48
    // 0xfa2184: EnterFrame
    //     0xfa2184: stp             fp, lr, [SP, #-0x10]!
    //     0xfa2188: mov             fp, SP
    // 0xfa218c: AllocStack(0x8)
    //     0xfa218c: sub             SP, SP, #8
    // 0xfa2190: CheckStackOverflow
    //     0xfa2190: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa2194: cmp             SP, x16
    //     0xfa2198: b.ls            #0xfa21c4
    // 0xfa219c: r1 = <_ZoomExitTransition>
    //     0xfa219c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa38c0] TypeArguments: <_ZoomExitTransition>
    //     0xfa21a0: ldr             x1, [x1, #0x8c0]
    // 0xfa21a4: r0 = _ZoomExitTransitionState()
    //     0xfa21a4: bl              #0xfa2278  ; Allocate_ZoomExitTransitionStateStub -> _ZoomExitTransitionState (size=0x24)
    // 0xfa21a8: mov             x1, x0
    // 0xfa21ac: stur            x0, [fp, #-8]
    // 0xfa21b0: r0 = _ZoomExitTransitionState()
    //     0xfa21b0: bl              #0xfa21cc  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionState::_ZoomExitTransitionState
    // 0xfa21b4: ldur            x0, [fp, #-8]
    // 0xfa21b8: LeaveFrame
    //     0xfa21b8: mov             SP, fp
    //     0xfa21bc: ldp             fp, lr, [SP], #0x10
    // 0xfa21c0: ret
    //     0xfa21c0: ret             
    // 0xfa21c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa21c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa21c8: b               #0xfa219c
  }
}

// class id: 6456, size: 0x20, field offset: 0xc
//   const constructor, 
class _ZoomEnterTransition extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa2070, size: 0x54
    // 0xfa2070: EnterFrame
    //     0xfa2070: stp             fp, lr, [SP, #-0x10]!
    //     0xfa2074: mov             fp, SP
    // 0xfa2078: AllocStack(0x8)
    //     0xfa2078: sub             SP, SP, #8
    // 0xfa207c: CheckStackOverflow
    //     0xfa207c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa2080: cmp             SP, x16
    //     0xfa2084: b.ls            #0xfa20bc
    // 0xfa2088: r1 = <_ZoomEnterTransition>
    //     0xfa2088: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa38b8] TypeArguments: <_ZoomEnterTransition>
    //     0xfa208c: ldr             x1, [x1, #0x8b8]
    // 0xfa2090: r0 = _ZoomEnterTransitionState()
    //     0xfa2090: bl              #0xfa2178  ; Allocate_ZoomEnterTransitionStateStub -> _ZoomEnterTransitionState (size=0x24)
    // 0xfa2094: mov             x2, x0
    // 0xfa2098: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa209c: stur            x2, [fp, #-8]
    // 0xfa20a0: StoreField: r2->field_1f = r0
    //     0xfa20a0: stur            w0, [x2, #0x1f]
    // 0xfa20a4: mov             x1, x2
    // 0xfa20a8: r0 = _MixinApplication86&State&_ZoomTransitionBase()
    //     0xfa20a8: bl              #0xfa20c4  ; [dart:mixin_deduplication] _MixinApplication86&State&_ZoomTransitionBase::_MixinApplication86&State&_ZoomTransitionBase
    // 0xfa20ac: ldur            x0, [fp, #-8]
    // 0xfa20b0: LeaveFrame
    //     0xfa20b0: mov             SP, fp
    //     0xfa20b4: ldp             fp, lr, [SP], #0x10
    // 0xfa20b8: ret
    //     0xfa20b8: ret             
    // 0xfa20bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa20bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa20c0: b               #0xfa2088
  }
}
