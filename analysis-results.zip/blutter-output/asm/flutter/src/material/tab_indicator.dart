// lib: , url: package:flutter/src/material/tab_indicator.dart

// class id: 1048957, size: 0x8
class :: {
}

// class id: 3259, size: 0x14, field offset: 0xc
class _UnderlinePainter extends BoxPainter {

  _ paint(/* No info */) {
    // ** addr: 0x12f6984, size: 0x270
    // 0x12f6984: EnterFrame
    //     0x12f6984: stp             fp, lr, [SP, #-0x10]!
    //     0x12f6988: mov             fp, SP
    // 0x12f698c: AllocStack(0x78)
    //     0x12f698c: sub             SP, SP, #0x78
    // 0x12f6990: SetupParameters(_UnderlinePainter this /* r1 => r3, fp-0x10 */, dynamic _ /* r3 => r1, fp-0x18 */)
    //     0x12f6990: stur            x1, [fp, #-8]
    //     0x12f6994: mov             x16, x3
    //     0x12f6998: mov             x3, x1
    //     0x12f699c: mov             x1, x16
    //     0x12f69a0: mov             x0, x2
    //     0x12f69a4: stur            x2, [fp, #-0x10]
    //     0x12f69a8: stur            x5, [fp, #-0x18]
    // 0x12f69ac: CheckStackOverflow
    //     0x12f69ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f69b0: cmp             SP, x16
    //     0x12f69b4: b.ls            #0x12f6be0
    // 0x12f69b8: ArrayLoad: r2 = r5[0]  ; List_4
    //     0x12f69b8: ldur            w2, [x5, #0x17]
    // 0x12f69bc: DecompressPointer r2
    //     0x12f69bc: add             x2, x2, HEAP, lsl #32
    // 0x12f69c0: cmp             w2, NULL
    // 0x12f69c4: b.eq            #0x12f6be8
    // 0x12f69c8: r0 = &()
    //     0x12f69c8: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x12f69cc: mov             x1, x0
    // 0x12f69d0: ldur            x0, [fp, #-0x18]
    // 0x12f69d4: stur            x1, [fp, #-0x28]
    // 0x12f69d8: LoadField: r3 = r0->field_13
    //     0x12f69d8: ldur            w3, [x0, #0x13]
    // 0x12f69dc: DecompressPointer r3
    //     0x12f69dc: add             x3, x3, HEAP, lsl #32
    // 0x12f69e0: stur            x3, [fp, #-0x20]
    // 0x12f69e4: cmp             w3, NULL
    // 0x12f69e8: b.eq            #0x12f6bec
    // 0x12f69ec: ldur            x0, [fp, #-8]
    // 0x12f69f0: LoadField: r2 = r0->field_f
    //     0x12f69f0: ldur            w2, [x0, #0xf]
    // 0x12f69f4: DecompressPointer r2
    //     0x12f69f4: add             x2, x2, HEAP, lsl #32
    // 0x12f69f8: stur            x2, [fp, #-0x18]
    // 0x12f69fc: cmp             w2, NULL
    // 0x12f6a00: b.eq            #0x12f6adc
    // 0x12f6a04: r16 = 136
    //     0x12f6a04: mov             x16, #0x88
    // 0x12f6a08: stp             x16, NULL, [SP]
    // 0x12f6a0c: r0 = ByteData()
    //     0x12f6a0c: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x12f6a10: stur            x0, [fp, #-0x30]
    // 0x12f6a14: r0 = Paint()
    //     0x12f6a14: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x12f6a18: mov             x3, x0
    // 0x12f6a1c: ldur            x0, [fp, #-0x30]
    // 0x12f6a20: stur            x3, [fp, #-0x38]
    // 0x12f6a24: StoreField: r3->field_7 = r0
    //     0x12f6a24: stur            w0, [x3, #7]
    // 0x12f6a28: ldur            x0, [fp, #-8]
    // 0x12f6a2c: LoadField: r4 = r0->field_b
    //     0x12f6a2c: ldur            w4, [x0, #0xb]
    // 0x12f6a30: DecompressPointer r4
    //     0x12f6a30: add             x4, x4, HEAP, lsl #32
    // 0x12f6a34: stur            x4, [fp, #-0x30]
    // 0x12f6a38: LoadField: r0 = r4->field_b
    //     0x12f6a38: ldur            w0, [x4, #0xb]
    // 0x12f6a3c: DecompressPointer r0
    //     0x12f6a3c: add             x0, x0, HEAP, lsl #32
    // 0x12f6a40: LoadField: r2 = r0->field_7
    //     0x12f6a40: ldur            w2, [x0, #7]
    // 0x12f6a44: DecompressPointer r2
    //     0x12f6a44: add             x2, x2, HEAP, lsl #32
    // 0x12f6a48: mov             x1, x3
    // 0x12f6a4c: r0 = color=()
    //     0x12f6a4c: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x12f6a50: ldur            x1, [fp, #-0x30]
    // 0x12f6a54: ldur            x2, [fp, #-0x28]
    // 0x12f6a58: ldur            x3, [fp, #-0x20]
    // 0x12f6a5c: r0 = _indicatorRectFor()
    //     0x12f6a5c: bl              #0x1196f38  ; [package:flutter/src/material/tab_indicator.dart] UnderlineTabIndicator::_indicatorRectFor
    // 0x12f6a60: mov             x2, x0
    // 0x12f6a64: ldur            x0, [fp, #-0x18]
    // 0x12f6a68: stur            x2, [fp, #-0x58]
    // 0x12f6a6c: LoadField: r6 = r0->field_7
    //     0x12f6a6c: ldur            w6, [x0, #7]
    // 0x12f6a70: DecompressPointer r6
    //     0x12f6a70: add             x6, x6, HEAP, lsl #32
    // 0x12f6a74: stur            x6, [fp, #-0x50]
    // 0x12f6a78: LoadField: r7 = r0->field_b
    //     0x12f6a78: ldur            w7, [x0, #0xb]
    // 0x12f6a7c: DecompressPointer r7
    //     0x12f6a7c: add             x7, x7, HEAP, lsl #32
    // 0x12f6a80: stur            x7, [fp, #-0x48]
    // 0x12f6a84: LoadField: r5 = r0->field_13
    //     0x12f6a84: ldur            w5, [x0, #0x13]
    // 0x12f6a88: DecompressPointer r5
    //     0x12f6a88: add             x5, x5, HEAP, lsl #32
    // 0x12f6a8c: stur            x5, [fp, #-0x40]
    // 0x12f6a90: LoadField: r3 = r0->field_f
    //     0x12f6a90: ldur            w3, [x0, #0xf]
    // 0x12f6a94: DecompressPointer r3
    //     0x12f6a94: add             x3, x3, HEAP, lsl #32
    // 0x12f6a98: stur            x3, [fp, #-0x30]
    // 0x12f6a9c: r1 = <RRect>
    //     0x12f6a9c: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0x12f6aa0: ldr             x1, [x1, #0x108]
    // 0x12f6aa4: r0 = RRect()
    //     0x12f6aa4: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0x12f6aa8: mov             x1, x0
    // 0x12f6aac: ldur            x2, [fp, #-0x58]
    // 0x12f6ab0: ldur            x3, [fp, #-0x30]
    // 0x12f6ab4: ldur            x5, [fp, #-0x40]
    // 0x12f6ab8: ldur            x6, [fp, #-0x50]
    // 0x12f6abc: ldur            x7, [fp, #-0x48]
    // 0x12f6ac0: stur            x0, [fp, #-0x18]
    // 0x12f6ac4: r0 = RSuperellipse.fromRectAndCorners()
    //     0x12f6ac4: bl              #0xb77b20  ; [dart:ui] RSuperellipse::RSuperellipse.fromRectAndCorners
    // 0x12f6ac8: ldur            x1, [fp, #-0x10]
    // 0x12f6acc: ldur            x2, [fp, #-0x18]
    // 0x12f6ad0: ldur            x3, [fp, #-0x38]
    // 0x12f6ad4: r0 = drawRRect()
    //     0x12f6ad4: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0x12f6ad8: b               #0x12f6bd0
    // 0x12f6adc: LoadField: r2 = r0->field_b
    //     0x12f6adc: ldur            w2, [x0, #0xb]
    // 0x12f6ae0: DecompressPointer r2
    //     0x12f6ae0: add             x2, x2, HEAP, lsl #32
    // 0x12f6ae4: stur            x2, [fp, #-0x18]
    // 0x12f6ae8: LoadField: r0 = r2->field_b
    //     0x12f6ae8: ldur            w0, [x2, #0xb]
    // 0x12f6aec: DecompressPointer r0
    //     0x12f6aec: add             x0, x0, HEAP, lsl #32
    // 0x12f6af0: mov             x1, x0
    // 0x12f6af4: stur            x0, [fp, #-8]
    // 0x12f6af8: r0 = toPaint()
    //     0x12f6af8: bl              #0x12ed2c0  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0x12f6afc: mov             x4, x0
    // 0x12f6b00: stur            x4, [fp, #-0x30]
    // 0x12f6b04: LoadField: r2 = r4->field_7
    //     0x12f6b04: ldur            w2, [x4, #7]
    // 0x12f6b08: DecompressPointer r2
    //     0x12f6b08: add             x2, x2, HEAP, lsl #32
    // 0x12f6b0c: LoadField: r0 = r2->field_13
    //     0x12f6b0c: ldur            w0, [x2, #0x13]
    // 0x12f6b10: r1 = LoadInt32Instr(r0)
    //     0x12f6b10: sbfx            x1, x0, #1, #0x1f
    // 0x12f6b14: mov             x0, x1
    // 0x12f6b18: r1 = 39
    //     0x12f6b18: mov             x1, #0x27
    // 0x12f6b1c: cmp             x1, x0
    // 0x12f6b20: b.hs            #0x12f6bf0
    // 0x12f6b24: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x12f6b24: ldur            w0, [x2, #0x17]
    // 0x12f6b28: DecompressPointer r0
    //     0x12f6b28: add             x0, x0, HEAP, lsl #32
    // 0x12f6b2c: LoadField: r1 = r2->field_1b
    //     0x12f6b2c: ldur            w1, [x2, #0x1b]
    // 0x12f6b30: r2 = LoadInt32Instr(r1)
    //     0x12f6b30: sbfx            x2, x1, #1, #0x1f
    // 0x12f6b34: add             x1, x2, #0x24
    // 0x12f6b38: LoadField: r2 = r0->field_7
    //     0x12f6b38: ldur            x2, [x0, #7]
    // 0x12f6b3c: r0 = 2
    //     0x12f6b3c: mov             x0, #2
    // 0x12f6b40: str             w0, [x2, x1]
    // 0x12f6b44: ldur            x1, [fp, #-0x18]
    // 0x12f6b48: ldur            x2, [fp, #-0x28]
    // 0x12f6b4c: ldur            x3, [fp, #-0x20]
    // 0x12f6b50: r0 = _indicatorRectFor()
    //     0x12f6b50: bl              #0x1196f38  ; [package:flutter/src/material/tab_indicator.dart] UnderlineTabIndicator::_indicatorRectFor
    // 0x12f6b54: mov             x1, x0
    // 0x12f6b58: ldur            x0, [fp, #-8]
    // 0x12f6b5c: LoadField: d0 = r0->field_b
    //     0x12f6b5c: ldur            d0, [x0, #0xb]
    // 0x12f6b60: d1 = 2.000000
    //     0x12f6b60: fmov            d1, #2.00000000
    // 0x12f6b64: fdiv            d2, d0, d1
    // 0x12f6b68: mov             v0.16b, v2.16b
    // 0x12f6b6c: r0 = deflate()
    //     0x12f6b6c: bl              #0x882c84  ; [dart:ui] Rect::deflate
    // 0x12f6b70: stur            x0, [fp, #-8]
    // 0x12f6b74: LoadField: d0 = r0->field_7
    //     0x12f6b74: ldur            d0, [x0, #7]
    // 0x12f6b78: stur            d0, [fp, #-0x68]
    // 0x12f6b7c: LoadField: d1 = r0->field_1f
    //     0x12f6b7c: ldur            d1, [x0, #0x1f]
    // 0x12f6b80: stur            d1, [fp, #-0x60]
    // 0x12f6b84: r0 = Offset()
    //     0x12f6b84: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12f6b88: ldur            d0, [fp, #-0x68]
    // 0x12f6b8c: stur            x0, [fp, #-0x18]
    // 0x12f6b90: StoreField: r0->field_7 = d0
    //     0x12f6b90: stur            d0, [x0, #7]
    // 0x12f6b94: ldur            d0, [fp, #-0x60]
    // 0x12f6b98: StoreField: r0->field_f = d0
    //     0x12f6b98: stur            d0, [x0, #0xf]
    // 0x12f6b9c: ldur            x1, [fp, #-8]
    // 0x12f6ba0: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x12f6ba0: ldur            d1, [x1, #0x17]
    // 0x12f6ba4: stur            d1, [fp, #-0x68]
    // 0x12f6ba8: r0 = Offset()
    //     0x12f6ba8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12f6bac: ldur            d0, [fp, #-0x68]
    // 0x12f6bb0: StoreField: r0->field_7 = d0
    //     0x12f6bb0: stur            d0, [x0, #7]
    // 0x12f6bb4: ldur            d0, [fp, #-0x60]
    // 0x12f6bb8: StoreField: r0->field_f = d0
    //     0x12f6bb8: stur            d0, [x0, #0xf]
    // 0x12f6bbc: ldur            x1, [fp, #-0x10]
    // 0x12f6bc0: ldur            x2, [fp, #-0x18]
    // 0x12f6bc4: mov             x3, x0
    // 0x12f6bc8: ldur            x5, [fp, #-0x30]
    // 0x12f6bcc: r0 = drawLine()
    //     0x12f6bcc: bl              #0xb6932c  ; [dart:ui] _NativeCanvas::drawLine
    // 0x12f6bd0: r0 = Null
    //     0x12f6bd0: mov             x0, NULL
    // 0x12f6bd4: LeaveFrame
    //     0x12f6bd4: mov             SP, fp
    //     0x12f6bd8: ldp             fp, lr, [SP], #0x10
    // 0x12f6bdc: ret
    //     0x12f6bdc: ret             
    // 0x12f6be0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f6be0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f6be4: b               #0x12f69b8
    // 0x12f6be8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f6be8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12f6bec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f6bec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12f6bf0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12f6bf0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 5239, size: 0x14, field offset: 0x8
//   const constructor, 
class UnderlineTabIndicator extends Decoration {

  _ getClipPath(/* No info */) {
    // ** addr: 0x1196d04, size: 0x234
    // 0x1196d04: EnterFrame
    //     0x1196d04: stp             fp, lr, [SP, #-0x10]!
    //     0x1196d08: mov             fp, SP
    // 0x1196d0c: AllocStack(0x60)
    //     0x1196d0c: sub             SP, SP, #0x60
    // 0x1196d10: SetupParameters(UnderlineTabIndicator this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x1196d10: stur            x1, [fp, #-0x10]
    //     0x1196d14: stur            x2, [fp, #-0x18]
    //     0x1196d18: stur            x3, [fp, #-0x20]
    // 0x1196d1c: CheckStackOverflow
    //     0x1196d1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1196d20: cmp             SP, x16
    //     0x1196d24: b.ls            #0x1196f28
    // 0x1196d28: LoadField: r0 = r1->field_7
    //     0x1196d28: ldur            w0, [x1, #7]
    // 0x1196d2c: DecompressPointer r0
    //     0x1196d2c: add             x0, x0, HEAP, lsl #32
    // 0x1196d30: stur            x0, [fp, #-8]
    // 0x1196d34: cmp             w0, NULL
    // 0x1196d38: b.eq            #0x1196e68
    // 0x1196d3c: r0 = _NativePath()
    //     0x1196d3c: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x1196d40: mov             x1, x0
    // 0x1196d44: stur            x0, [fp, #-0x28]
    // 0x1196d48: r0 = __constructor$Method$FfiNative()
    //     0x1196d48: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x1196d4c: ldur            x1, [fp, #-0x10]
    // 0x1196d50: ldur            x2, [fp, #-0x18]
    // 0x1196d54: ldur            x3, [fp, #-0x20]
    // 0x1196d58: r0 = _indicatorRectFor()
    //     0x1196d58: bl              #0x1196f38  ; [package:flutter/src/material/tab_indicator.dart] UnderlineTabIndicator::_indicatorRectFor
    // 0x1196d5c: ldur            x1, [fp, #-8]
    // 0x1196d60: mov             x2, x0
    // 0x1196d64: r0 = toRRect()
    //     0x1196d64: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x1196d68: stur            x0, [fp, #-8]
    // 0x1196d6c: LoadField: d0 = r0->field_b
    //     0x1196d6c: ldur            d0, [x0, #0xb]
    // 0x1196d70: fcvt            s1, d0
    // 0x1196d74: stur            d1, [fp, #-0x40]
    // 0x1196d78: r4 = 24
    //     0x1196d78: mov             x4, #0x18
    // 0x1196d7c: r0 = AllocateFloat32Array()
    //     0x1196d7c: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0x1196d80: ldur            d0, [fp, #-0x40]
    // 0x1196d84: stur            x0, [fp, #-0x38]
    // 0x1196d88: ArrayStore: r0[0] = d0  ; List_8
    //     0x1196d88: stur            s0, [x0, #0x17]
    // 0x1196d8c: ldur            x1, [fp, #-8]
    // 0x1196d90: LoadField: d0 = r1->field_13
    //     0x1196d90: ldur            d0, [x1, #0x13]
    // 0x1196d94: fcvt            s1, d0
    // 0x1196d98: StoreField: r0->field_1b = d1
    //     0x1196d98: stur            s1, [x0, #0x1b]
    // 0x1196d9c: LoadField: d0 = r1->field_1b
    //     0x1196d9c: ldur            d0, [x1, #0x1b]
    // 0x1196da0: fcvt            s1, d0
    // 0x1196da4: StoreField: r0->field_1f = d1
    //     0x1196da4: stur            s1, [x0, #0x1f]
    // 0x1196da8: LoadField: d0 = r1->field_23
    //     0x1196da8: ldur            d0, [x1, #0x23]
    // 0x1196dac: fcvt            s1, d0
    // 0x1196db0: StoreField: r0->field_23 = d1
    //     0x1196db0: stur            s1, [x0, #0x23]
    // 0x1196db4: LoadField: d0 = r1->field_2b
    //     0x1196db4: ldur            d0, [x1, #0x2b]
    // 0x1196db8: fcvt            s1, d0
    // 0x1196dbc: StoreField: r0->field_27 = d1
    //     0x1196dbc: stur            s1, [x0, #0x27]
    // 0x1196dc0: LoadField: d0 = r1->field_33
    //     0x1196dc0: ldur            d0, [x1, #0x33]
    // 0x1196dc4: fcvt            s1, d0
    // 0x1196dc8: StoreField: r0->field_2b = d1
    //     0x1196dc8: stur            s1, [x0, #0x2b]
    // 0x1196dcc: LoadField: d0 = r1->field_3b
    //     0x1196dcc: ldur            d0, [x1, #0x3b]
    // 0x1196dd0: fcvt            s1, d0
    // 0x1196dd4: StoreField: r0->field_2f = d1
    //     0x1196dd4: stur            s1, [x0, #0x2f]
    // 0x1196dd8: LoadField: d0 = r1->field_43
    //     0x1196dd8: ldur            d0, [x1, #0x43]
    // 0x1196ddc: fcvt            s1, d0
    // 0x1196de0: StoreField: r0->field_33 = d1
    //     0x1196de0: stur            s1, [x0, #0x33]
    // 0x1196de4: LoadField: d0 = r1->field_4b
    //     0x1196de4: ldur            d0, [x1, #0x4b]
    // 0x1196de8: fcvt            s1, d0
    // 0x1196dec: StoreField: r0->field_37 = d1
    //     0x1196dec: stur            s1, [x0, #0x37]
    // 0x1196df0: LoadField: d0 = r1->field_53
    //     0x1196df0: ldur            d0, [x1, #0x53]
    // 0x1196df4: fcvt            s1, d0
    // 0x1196df8: StoreField: r0->field_3b = d1
    //     0x1196df8: stur            s1, [x0, #0x3b]
    // 0x1196dfc: LoadField: d0 = r1->field_5b
    //     0x1196dfc: ldur            d0, [x1, #0x5b]
    // 0x1196e00: fcvt            s1, d0
    // 0x1196e04: StoreField: r0->field_3f = d1
    //     0x1196e04: stur            s1, [x0, #0x3f]
    // 0x1196e08: LoadField: d0 = r1->field_63
    //     0x1196e08: ldur            d0, [x1, #0x63]
    // 0x1196e0c: fcvt            s1, d0
    // 0x1196e10: StoreField: r0->field_43 = d1
    //     0x1196e10: stur            s1, [x0, #0x43]
    // 0x1196e14: ldur            x2, [fp, #-0x28]
    // 0x1196e18: LoadField: r1 = r2->field_7
    //     0x1196e18: ldur            w1, [x2, #7]
    // 0x1196e1c: DecompressPointer r1
    //     0x1196e1c: add             x1, x1, HEAP, lsl #32
    // 0x1196e20: cmp             w1, NULL
    // 0x1196e24: b.eq            #0x1196f30
    // 0x1196e28: LoadField: r3 = r1->field_7
    //     0x1196e28: ldur            x3, [x1, #7]
    // 0x1196e2c: ldr             x1, [x3]
    // 0x1196e30: cbz             x1, #0x1196f08
    // 0x1196e34: mov             x3, x1
    // 0x1196e38: stur            x3, [fp, #-0x30]
    // 0x1196e3c: r1 = <Never>
    //     0x1196e3c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x1196e40: r0 = Pointer()
    //     0x1196e40: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x1196e44: mov             x1, x0
    // 0x1196e48: ldur            x0, [fp, #-0x30]
    // 0x1196e4c: StoreField: r1->field_7 = r0
    //     0x1196e4c: stur            x0, [x1, #7]
    // 0x1196e50: ldur            x2, [fp, #-0x38]
    // 0x1196e54: r0 = __addRRect$Method$FfiNative()
    //     0x1196e54: bl              #0xbfd930  ; [dart:ui] _NativePath::__addRRect$Method$FfiNative
    // 0x1196e58: ldur            x0, [fp, #-0x28]
    // 0x1196e5c: LeaveFrame
    //     0x1196e5c: mov             SP, fp
    //     0x1196e60: ldp             fp, lr, [SP], #0x10
    // 0x1196e64: ret
    //     0x1196e64: ret             
    // 0x1196e68: r0 = _NativePath()
    //     0x1196e68: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x1196e6c: mov             x1, x0
    // 0x1196e70: stur            x0, [fp, #-8]
    // 0x1196e74: r0 = __constructor$Method$FfiNative()
    //     0x1196e74: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x1196e78: ldur            x1, [fp, #-0x10]
    // 0x1196e7c: ldur            x2, [fp, #-0x18]
    // 0x1196e80: ldur            x3, [fp, #-0x20]
    // 0x1196e84: r0 = _indicatorRectFor()
    //     0x1196e84: bl              #0x1196f38  ; [package:flutter/src/material/tab_indicator.dart] UnderlineTabIndicator::_indicatorRectFor
    // 0x1196e88: LoadField: d0 = r0->field_7
    //     0x1196e88: ldur            d0, [x0, #7]
    // 0x1196e8c: stur            d0, [fp, #-0x58]
    // 0x1196e90: LoadField: d1 = r0->field_f
    //     0x1196e90: ldur            d1, [x0, #0xf]
    // 0x1196e94: stur            d1, [fp, #-0x50]
    // 0x1196e98: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x1196e98: ldur            d2, [x0, #0x17]
    // 0x1196e9c: stur            d2, [fp, #-0x48]
    // 0x1196ea0: LoadField: d3 = r0->field_1f
    //     0x1196ea0: ldur            d3, [x0, #0x1f]
    // 0x1196ea4: ldur            x0, [fp, #-8]
    // 0x1196ea8: stur            d3, [fp, #-0x40]
    // 0x1196eac: LoadField: r1 = r0->field_7
    //     0x1196eac: ldur            w1, [x0, #7]
    // 0x1196eb0: DecompressPointer r1
    //     0x1196eb0: add             x1, x1, HEAP, lsl #32
    // 0x1196eb4: cmp             w1, NULL
    // 0x1196eb8: b.eq            #0x1196f34
    // 0x1196ebc: LoadField: r2 = r1->field_7
    //     0x1196ebc: ldur            x2, [x1, #7]
    // 0x1196ec0: ldr             x1, [x2]
    // 0x1196ec4: cbz             x1, #0x1196f18
    // 0x1196ec8: mov             x2, x1
    // 0x1196ecc: stur            x2, [fp, #-0x30]
    // 0x1196ed0: r1 = <Never>
    //     0x1196ed0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x1196ed4: r0 = Pointer()
    //     0x1196ed4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x1196ed8: mov             x1, x0
    // 0x1196edc: ldur            x0, [fp, #-0x30]
    // 0x1196ee0: StoreField: r1->field_7 = r0
    //     0x1196ee0: stur            x0, [x1, #7]
    // 0x1196ee4: ldur            d0, [fp, #-0x58]
    // 0x1196ee8: ldur            d1, [fp, #-0x50]
    // 0x1196eec: ldur            d2, [fp, #-0x48]
    // 0x1196ef0: ldur            d3, [fp, #-0x40]
    // 0x1196ef4: r0 = __addRect$Method$FfiNative()
    //     0x1196ef4: bl              #0xb74e24  ; [dart:ui] _NativePath::__addRect$Method$FfiNative
    // 0x1196ef8: ldur            x0, [fp, #-8]
    // 0x1196efc: LeaveFrame
    //     0x1196efc: mov             SP, fp
    //     0x1196f00: ldp             fp, lr, [SP], #0x10
    // 0x1196f04: ret
    //     0x1196f04: ret             
    // 0x1196f08: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x1196f08: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x1196f0c: str             x16, [SP]
    // 0x1196f10: r0 = _throwNew()
    //     0x1196f10: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x1196f14: brk             #0
    // 0x1196f18: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x1196f18: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x1196f1c: str             x16, [SP]
    // 0x1196f20: r0 = _throwNew()
    //     0x1196f20: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x1196f24: brk             #0
    // 0x1196f28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1196f28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1196f2c: b               #0x1196d28
    // 0x1196f30: r0 = NullErrorSharedWithoutFPURegs()
    //     0x1196f30: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x1196f34: r0 = NullErrorSharedWithFPURegs()
    //     0x1196f34: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
  _ _indicatorRectFor(/* No info */) {
    // ** addr: 0x1196f38, size: 0xf8
    // 0x1196f38: EnterFrame
    //     0x1196f38: stp             fp, lr, [SP, #-0x10]!
    //     0x1196f3c: mov             fp, SP
    // 0x1196f40: AllocStack(0x30)
    //     0x1196f40: sub             SP, SP, #0x30
    // 0x1196f44: SetupParameters(UnderlineTabIndicator this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r2 */)
    //     0x1196f44: mov             x4, x1
    //     0x1196f48: stur            x2, [fp, #-0x10]
    //     0x1196f4c: mov             x16, x3
    //     0x1196f50: mov             x3, x2
    //     0x1196f54: mov             x2, x16
    //     0x1196f58: stur            x1, [fp, #-8]
    // 0x1196f5c: CheckStackOverflow
    //     0x1196f5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1196f60: cmp             SP, x16
    //     0x1196f64: b.ls            #0x1197028
    // 0x1196f68: LoadField: r0 = r4->field_f
    //     0x1196f68: ldur            w0, [x4, #0xf]
    // 0x1196f6c: DecompressPointer r0
    //     0x1196f6c: add             x0, x0, HEAP, lsl #32
    // 0x1196f70: r1 = LoadClassIdInstr(r0)
    //     0x1196f70: ldur            x1, [x0, #-1]
    //     0x1196f74: ubfx            x1, x1, #0xc, #0x14
    // 0x1196f78: cmp             x1, #0xb7c
    // 0x1196f7c: b.ne            #0x1196f8c
    // 0x1196f80: mov             x1, x0
    // 0x1196f84: mov             x0, x4
    // 0x1196f88: b               #0x1196fb4
    // 0x1196f8c: r1 = LoadClassIdInstr(r0)
    //     0x1196f8c: ldur            x1, [x0, #-1]
    //     0x1196f90: ubfx            x1, x1, #0xc, #0x14
    // 0x1196f94: mov             x16, x0
    // 0x1196f98: mov             x0, x1
    // 0x1196f9c: mov             x1, x16
    // 0x1196fa0: r0 = GDT[cid_x0 + -0xfea]()
    //     0x1196fa0: sub             lr, x0, #0xfea
    //     0x1196fa4: ldr             lr, [x21, lr, lsl #3]
    //     0x1196fa8: blr             lr
    // 0x1196fac: mov             x1, x0
    // 0x1196fb0: ldur            x0, [fp, #-8]
    // 0x1196fb4: ldur            x2, [fp, #-0x10]
    // 0x1196fb8: r0 = deflateRect()
    //     0x1196fb8: bl              #0xb7a1f4  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::deflateRect
    // 0x1196fbc: LoadField: d0 = r0->field_7
    //     0x1196fbc: ldur            d0, [x0, #7]
    // 0x1196fc0: stur            d0, [fp, #-0x30]
    // 0x1196fc4: LoadField: d1 = r0->field_1f
    //     0x1196fc4: ldur            d1, [x0, #0x1f]
    // 0x1196fc8: ldur            x1, [fp, #-8]
    // 0x1196fcc: LoadField: r2 = r1->field_b
    //     0x1196fcc: ldur            w2, [x1, #0xb]
    // 0x1196fd0: DecompressPointer r2
    //     0x1196fd0: add             x2, x2, HEAP, lsl #32
    // 0x1196fd4: LoadField: d2 = r2->field_b
    //     0x1196fd4: ldur            d2, [x2, #0xb]
    // 0x1196fd8: fsub            d3, d1, d2
    // 0x1196fdc: stur            d3, [fp, #-0x28]
    // 0x1196fe0: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x1196fe0: ldur            d1, [x0, #0x17]
    // 0x1196fe4: fsub            d4, d1, d0
    // 0x1196fe8: fadd            d1, d0, d4
    // 0x1196fec: stur            d1, [fp, #-0x20]
    // 0x1196ff0: fadd            d4, d3, d2
    // 0x1196ff4: stur            d4, [fp, #-0x18]
    // 0x1196ff8: r0 = Rect()
    //     0x1196ff8: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x1196ffc: ldur            d0, [fp, #-0x30]
    // 0x1197000: StoreField: r0->field_7 = d0
    //     0x1197000: stur            d0, [x0, #7]
    // 0x1197004: ldur            d0, [fp, #-0x28]
    // 0x1197008: StoreField: r0->field_f = d0
    //     0x1197008: stur            d0, [x0, #0xf]
    // 0x119700c: ldur            d0, [fp, #-0x20]
    // 0x1197010: ArrayStore: r0[0] = d0  ; List_8
    //     0x1197010: stur            d0, [x0, #0x17]
    // 0x1197014: ldur            d0, [fp, #-0x18]
    // 0x1197018: StoreField: r0->field_1f = d0
    //     0x1197018: stur            d0, [x0, #0x1f]
    // 0x119701c: LeaveFrame
    //     0x119701c: mov             SP, fp
    //     0x1197020: ldp             fp, lr, [SP], #0x10
    // 0x1197024: ret
    //     0x1197024: ret             
    // 0x1197028: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1197028: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119702c: b               #0x1196f68
  }
}
