// lib: , url: package:flutter/src/material/dropdown_menu_theme.dart

// class id: 1048887, size: 0x8
class :: {
}

// class id: 5156, size: 0x18, field offset: 0x8
//   const constructor, 
class DropdownMenuThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x1133140, size: 0x64
    // 0x1133140: EnterFrame
    //     0x1133140: stp             fp, lr, [SP, #-0x10]!
    //     0x1133144: mov             fp, SP
    // 0x1133148: AllocStack(0x10)
    //     0x1133148: sub             SP, SP, #0x10
    // 0x113314c: CheckStackOverflow
    //     0x113314c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1133150: cmp             SP, x16
    //     0x1133154: b.ls            #0x113319c
    // 0x1133158: ldr             x0, [fp, #0x10]
    // 0x113315c: LoadField: r1 = r0->field_f
    //     0x113315c: ldur            w1, [x0, #0xf]
    // 0x1133160: DecompressPointer r1
    //     0x1133160: add             x1, x1, HEAP, lsl #32
    // 0x1133164: stp             NULL, x1, [SP]
    // 0x1133168: r1 = Null
    //     0x1133168: mov             x1, NULL
    // 0x113316c: r2 = Null
    //     0x113316c: mov             x2, NULL
    // 0x1133170: r4 = const [0, 0x4, 0x2, 0x4, null]
    //     0x1133170: ldr             x4, [PP, #0x1388]  ; [pp+0x1388] List(5) [0, 0x4, 0x2, 0x4, Null]
    // 0x1133174: r0 = hash()
    //     0x1133174: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1133178: mov             x2, x0
    // 0x113317c: r0 = BoxInt64Instr(r2)
    //     0x113317c: sbfiz           x0, x2, #1, #0x1f
    //     0x1133180: cmp             x2, x0, asr #1
    //     0x1133184: b.eq            #0x1133190
    //     0x1133188: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113318c: stur            x2, [x0, #7]
    // 0x1133190: LeaveFrame
    //     0x1133190: mov             SP, fp
    //     0x1133194: ldp             fp, lr, [SP], #0x10
    // 0x1133198: ret
    //     0x1133198: ret             
    // 0x113319c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x113319c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11331a0: b               #0x1133158
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1167464, size: 0xf4
    // 0x1167464: EnterFrame
    //     0x1167464: stp             fp, lr, [SP, #-0x10]!
    //     0x1167468: mov             fp, SP
    // 0x116746c: AllocStack(0x20)
    //     0x116746c: sub             SP, SP, #0x20
    // 0x1167470: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x20 */)
    //     0x1167470: mov             x4, x1
    //     0x1167474: mov             x0, x2
    //     0x1167478: stur            x1, [fp, #-0x10]
    //     0x116747c: stur            x2, [fp, #-0x18]
    //     0x1167480: stur            d0, [fp, #-0x20]
    // 0x1167484: CheckStackOverflow
    //     0x1167484: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1167488: cmp             SP, x16
    //     0x116748c: b.ls            #0x1167534
    // 0x1167490: cmp             w4, w0
    // 0x1167494: b.ne            #0x11674a8
    // 0x1167498: mov             x0, x4
    // 0x116749c: LeaveFrame
    //     0x116749c: mov             SP, fp
    //     0x11674a0: ldp             fp, lr, [SP], #0x10
    // 0x11674a4: ret
    //     0x11674a4: ret             
    // 0x11674a8: r5 = inline_Allocate_Double()
    //     0x11674a8: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x11674ac: add             x5, x5, #0x10
    //     0x11674b0: cmp             x1, x5
    //     0x11674b4: b.ls            #0x116753c
    //     0x11674b8: str             x5, [THR, #0x60]  ; THR::top
    //     0x11674bc: sub             x5, x5, #0xf
    //     0x11674c0: mov             x1, #0xe19c
    //     0x11674c4: movk            x1, #3, lsl #16
    //     0x11674c8: stur            x1, [x5, #-1]
    // 0x11674cc: dmb             ishst
    // 0x11674d0: StoreField: r5->field_7 = d0
    //     0x11674d0: stur            d0, [x5, #7]
    // 0x11674d4: mov             x3, x5
    // 0x11674d8: stur            x5, [fp, #-8]
    // 0x11674dc: r1 = Null
    //     0x11674dc: mov             x1, NULL
    // 0x11674e0: r2 = Null
    //     0x11674e0: mov             x2, NULL
    // 0x11674e4: r0 = lerp()
    //     0x11674e4: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x11674e8: ldur            x0, [fp, #-0x10]
    // 0x11674ec: LoadField: r1 = r0->field_f
    //     0x11674ec: ldur            w1, [x0, #0xf]
    // 0x11674f0: DecompressPointer r1
    //     0x11674f0: add             x1, x1, HEAP, lsl #32
    // 0x11674f4: ldur            x0, [fp, #-0x18]
    // 0x11674f8: LoadField: r2 = r0->field_f
    //     0x11674f8: ldur            w2, [x0, #0xf]
    // 0x11674fc: DecompressPointer r2
    //     0x11674fc: add             x2, x2, HEAP, lsl #32
    // 0x1167500: ldur            d0, [fp, #-0x20]
    // 0x1167504: r0 = lerp()
    //     0x1167504: bl              #0x11669bc  ; [package:flutter/src/material/menu_style.dart] MenuStyle::lerp
    // 0x1167508: ldur            x3, [fp, #-8]
    // 0x116750c: r1 = Null
    //     0x116750c: mov             x1, NULL
    // 0x1167510: r2 = Null
    //     0x1167510: mov             x2, NULL
    // 0x1167514: stur            x0, [fp, #-8]
    // 0x1167518: r0 = lerp()
    //     0x1167518: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116751c: r0 = DropdownMenuThemeData()
    //     0x116751c: bl              #0x1167558  ; AllocateDropdownMenuThemeDataStub -> DropdownMenuThemeData (size=0x18)
    // 0x1167520: ldur            x1, [fp, #-8]
    // 0x1167524: StoreField: r0->field_f = r1
    //     0x1167524: stur            w1, [x0, #0xf]
    // 0x1167528: LeaveFrame
    //     0x1167528: mov             SP, fp
    //     0x116752c: ldp             fp, lr, [SP], #0x10
    // 0x1167530: ret
    //     0x1167530: ret             
    // 0x1167534: r0 = StackOverflowSharedWithFPURegs()
    //     0x1167534: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1167538: b               #0x1167490
    // 0x116753c: SaveReg d0
    //     0x116753c: str             q0, [SP, #-0x10]!
    // 0x1167540: stp             x0, x4, [SP, #-0x10]!
    // 0x1167544: r0 = AllocateDouble()
    //     0x1167544: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1167548: mov             x5, x0
    // 0x116754c: ldp             x0, x4, [SP], #0x10
    // 0x1167550: RestoreReg d0
    //     0x1167550: ldr             q0, [SP], #0x10
    // 0x1167554: b               #0x11674d0
  }
  _ ==(/* No info */) {
    // ** addr: 0x126bef0, size: 0x104
    // 0x126bef0: EnterFrame
    //     0x126bef0: stp             fp, lr, [SP, #-0x10]!
    //     0x126bef4: mov             fp, SP
    // 0x126bef8: AllocStack(0x10)
    //     0x126bef8: sub             SP, SP, #0x10
    // 0x126befc: CheckStackOverflow
    //     0x126befc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x126bf00: cmp             SP, x16
    //     0x126bf04: b.ls            #0x126bfec
    // 0x126bf08: ldr             x0, [fp, #0x10]
    // 0x126bf0c: cmp             w0, NULL
    // 0x126bf10: b.ne            #0x126bf24
    // 0x126bf14: r0 = false
    //     0x126bf14: add             x0, NULL, #0x30  ; false
    // 0x126bf18: LeaveFrame
    //     0x126bf18: mov             SP, fp
    //     0x126bf1c: ldp             fp, lr, [SP], #0x10
    // 0x126bf20: ret
    //     0x126bf20: ret             
    // 0x126bf24: ldr             x1, [fp, #0x18]
    // 0x126bf28: cmp             w1, w0
    // 0x126bf2c: b.ne            #0x126bf40
    // 0x126bf30: r0 = true
    //     0x126bf30: add             x0, NULL, #0x20  ; true
    // 0x126bf34: LeaveFrame
    //     0x126bf34: mov             SP, fp
    //     0x126bf38: ldp             fp, lr, [SP], #0x10
    // 0x126bf3c: ret
    //     0x126bf3c: ret             
    // 0x126bf40: str             x0, [SP]
    // 0x126bf44: r0 = runtimeType()
    //     0x126bf44: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x126bf48: r1 = LoadClassIdInstr(r0)
    //     0x126bf48: ldur            x1, [x0, #-1]
    //     0x126bf4c: ubfx            x1, x1, #0xc, #0x14
    // 0x126bf50: r16 = DropdownMenuThemeData
    //     0x126bf50: add             x16, PP, #0x26, lsl #12  ; [pp+0x26698] Type: DropdownMenuThemeData
    //     0x126bf54: ldr             x16, [x16, #0x698]
    // 0x126bf58: stp             x16, x0, [SP]
    // 0x126bf5c: mov             x0, x1
    // 0x126bf60: mov             lr, x0
    // 0x126bf64: ldr             lr, [x21, lr, lsl #3]
    // 0x126bf68: blr             lr
    // 0x126bf6c: tbz             w0, #4, #0x126bf80
    // 0x126bf70: r0 = false
    //     0x126bf70: add             x0, NULL, #0x30  ; false
    // 0x126bf74: LeaveFrame
    //     0x126bf74: mov             SP, fp
    //     0x126bf78: ldp             fp, lr, [SP], #0x10
    // 0x126bf7c: ret
    //     0x126bf7c: ret             
    // 0x126bf80: ldr             x0, [fp, #0x10]
    // 0x126bf84: r1 = 60
    //     0x126bf84: mov             x1, #0x3c
    // 0x126bf88: branchIfSmi(r0, 0x126bf94)
    //     0x126bf88: tbz             w0, #0, #0x126bf94
    // 0x126bf8c: r1 = LoadClassIdInstr(r0)
    //     0x126bf8c: ldur            x1, [x0, #-1]
    //     0x126bf90: ubfx            x1, x1, #0xc, #0x14
    // 0x126bf94: r17 = 5156
    //     0x126bf94: mov             x17, #0x1424
    // 0x126bf98: cmp             x1, x17
    // 0x126bf9c: b.ne            #0x126bfdc
    // 0x126bfa0: ldr             x1, [fp, #0x18]
    // 0x126bfa4: LoadField: r2 = r0->field_f
    //     0x126bfa4: ldur            w2, [x0, #0xf]
    // 0x126bfa8: DecompressPointer r2
    //     0x126bfa8: add             x2, x2, HEAP, lsl #32
    // 0x126bfac: LoadField: r0 = r1->field_f
    //     0x126bfac: ldur            w0, [x1, #0xf]
    // 0x126bfb0: DecompressPointer r0
    //     0x126bfb0: add             x0, x0, HEAP, lsl #32
    // 0x126bfb4: r1 = LoadClassIdInstr(r2)
    //     0x126bfb4: ldur            x1, [x2, #-1]
    //     0x126bfb8: ubfx            x1, x1, #0xc, #0x14
    // 0x126bfbc: stp             x0, x2, [SP]
    // 0x126bfc0: mov             x0, x1
    // 0x126bfc4: mov             lr, x0
    // 0x126bfc8: ldr             lr, [x21, lr, lsl #3]
    // 0x126bfcc: blr             lr
    // 0x126bfd0: tbnz            w0, #4, #0x126bfdc
    // 0x126bfd4: r0 = true
    //     0x126bfd4: add             x0, NULL, #0x20  ; true
    // 0x126bfd8: b               #0x126bfe0
    // 0x126bfdc: r0 = false
    //     0x126bfdc: add             x0, NULL, #0x30  ; false
    // 0x126bfe0: LeaveFrame
    //     0x126bfe0: mov             SP, fp
    //     0x126bfe4: ldp             fp, lr, [SP], #0x10
    // 0x126bfe8: ret
    //     0x126bfe8: ret             
    // 0x126bfec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x126bfec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x126bff0: b               #0x126bf08
  }
}
