// lib: , url: package:flutter/src/material/scrollbar.dart

// class id: 1048939, size: 0x8
class :: {
}

// class id: 5705, size: 0x70, field offset: 0x58
class _MaterialScrollbarState extends RawScrollbarState<dynamic> {

  late AnimationController _hoverAnimationController; // offset: 0x58
  late ScrollbarThemeData _scrollbarTheme; // offset: 0x68
  late bool _useAndroidScrollbar; // offset: 0x6c
  late ColorScheme _colorScheme; // offset: 0x64

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd388d0, size: 0x24
    // 0xd388d0: r1 = false
    //     0xd388d0: add             x1, NULL, #0x30  ; false
    // 0xd388d4: ldr             x2, [SP]
    // 0xd388d8: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xd388d8: ldur            w3, [x2, #0x17]
    // 0xd388dc: DecompressPointer r3
    //     0xd388dc: add             x3, x3, HEAP, lsl #32
    // 0xd388e0: LoadField: r2 = r3->field_f
    //     0xd388e0: ldur            w2, [x3, #0xf]
    // 0xd388e4: DecompressPointer r2
    //     0xd388e4: add             x2, x2, HEAP, lsl #32
    // 0xd388e8: StoreField: r2->field_5b = r1
    //     0xd388e8: stur            w1, [x2, #0x5b]
    // 0xd388ec: r0 = Null
    //     0xd388ec: mov             x0, NULL
    // 0xd388f0: ret
    //     0xd388f0: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd39830, size: 0x24
    // 0xd39830: r1 = true
    //     0xd39830: add             x1, NULL, #0x20  ; true
    // 0xd39834: ldr             x2, [SP]
    // 0xd39838: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xd39838: ldur            w3, [x2, #0x17]
    // 0xd3983c: DecompressPointer r3
    //     0xd3983c: add             x3, x3, HEAP, lsl #32
    // 0xd39840: LoadField: r2 = r3->field_f
    //     0xd39840: ldur            w2, [x3, #0xf]
    // 0xd39844: DecompressPointer r2
    //     0xd39844: add             x2, x2, HEAP, lsl #32
    // 0xd39848: StoreField: r2->field_5b = r1
    //     0xd39848: stur            w1, [x2, #0x5b]
    // 0xd3984c: r0 = Null
    //     0xd3984c: mov             x0, NULL
    // 0xd39850: ret
    //     0xd39850: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd3b7cc, size: 0x24
    // 0xd3b7cc: r1 = false
    //     0xd3b7cc: add             x1, NULL, #0x30  ; false
    // 0xd3b7d0: ldr             x2, [SP]
    // 0xd3b7d4: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xd3b7d4: ldur            w3, [x2, #0x17]
    // 0xd3b7d8: DecompressPointer r3
    //     0xd3b7d8: add             x3, x3, HEAP, lsl #32
    // 0xd3b7dc: LoadField: r2 = r3->field_f
    //     0xd3b7dc: ldur            w2, [x3, #0xf]
    // 0xd3b7e0: DecompressPointer r2
    //     0xd3b7e0: add             x2, x2, HEAP, lsl #32
    // 0xd3b7e4: StoreField: r2->field_5f = r1
    //     0xd3b7e4: stur            w1, [x2, #0x5f]
    // 0xd3b7e8: r0 = Null
    //     0xd3b7e8: mov             x0, NULL
    // 0xd3b7ec: ret
    //     0xd3b7ec: ret             
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xeeeccc, size: 0xf4
    // 0xeeeccc: EnterFrame
    //     0xeeeccc: stp             fp, lr, [SP, #-0x10]!
    //     0xeeecd0: mov             fp, SP
    // 0xeeecd4: AllocStack(0x10)
    //     0xeeecd4: sub             SP, SP, #0x10
    // 0xeeecd8: SetupParameters(_MaterialScrollbarState this /* r1 => r0, fp-0x8 */)
    //     0xeeecd8: mov             x0, x1
    //     0xeeecdc: stur            x1, [fp, #-8]
    // 0xeeece0: CheckStackOverflow
    //     0xeeece0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeeece4: cmp             SP, x16
    //     0xeeece8: b.ls            #0xeeedb0
    // 0xeeecec: LoadField: r1 = r0->field_f
    //     0xeeecec: ldur            w1, [x0, #0xf]
    // 0xeeecf0: DecompressPointer r1
    //     0xeeecf0: add             x1, x1, HEAP, lsl #32
    // 0xeeecf4: cmp             w1, NULL
    // 0xeeecf8: b.eq            #0xeeedb8
    // 0xeeecfc: r0 = of()
    //     0xeeecfc: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xeeed00: mov             x2, x0
    // 0xeeed04: stur            x2, [fp, #-0x10]
    // 0xeeed08: LoadField: r0 = r2->field_3f
    //     0xeeed08: ldur            w0, [x2, #0x3f]
    // 0xeeed0c: DecompressPointer r0
    //     0xeeed0c: add             x0, x0, HEAP, lsl #32
    // 0xeeed10: ldur            x3, [fp, #-8]
    // 0xeeed14: StoreField: r3->field_63 = r0
    //     0xeeed14: stur            w0, [x3, #0x63]
    //     0xeeed18: ldurb           w16, [x3, #-1]
    //     0xeeed1c: ldurb           w17, [x0, #-1]
    //     0xeeed20: and             x16, x17, x16, lsr #2
    //     0xeeed24: tst             x16, HEAP, lsr #32
    //     0xeeed28: b.eq            #0xeeed30
    //     0xeeed2c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xeeed30: LoadField: r1 = r3->field_f
    //     0xeeed30: ldur            w1, [x3, #0xf]
    // 0xeeed34: DecompressPointer r1
    //     0xeeed34: add             x1, x1, HEAP, lsl #32
    // 0xeeed38: cmp             w1, NULL
    // 0xeeed3c: b.eq            #0xeeedbc
    // 0xeeed40: r0 = of()
    //     0xeeed40: bl              #0xeeedc0  ; [package:flutter/src/material/scrollbar_theme.dart] ScrollbarTheme::of
    // 0xeeed44: ldur            x1, [fp, #-8]
    // 0xeeed48: StoreField: r1->field_67 = r0
    //     0xeeed48: stur            w0, [x1, #0x67]
    //     0xeeed4c: ldurb           w16, [x1, #-1]
    //     0xeeed50: ldurb           w17, [x0, #-1]
    //     0xeeed54: and             x16, x17, x16, lsr #2
    //     0xeeed58: tst             x16, HEAP, lsr #32
    //     0xeeed5c: b.eq            #0xeeed64
    //     0xeeed60: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xeeed64: ldur            x2, [fp, #-0x10]
    // 0xeeed68: LoadField: r3 = r2->field_23
    //     0xeeed68: ldur            w3, [x2, #0x23]
    // 0xeeed6c: DecompressPointer r3
    //     0xeeed6c: add             x3, x3, HEAP, lsl #32
    // 0xeeed70: LoadField: r2 = r3->field_7
    //     0xeeed70: ldur            x2, [x3, #7]
    // 0xeeed74: cmp             x2, #2
    // 0xeeed78: b.gt            #0xeeed98
    // 0xeeed7c: cmp             x2, #1
    // 0xeeed80: b.gt            #0xeeed98
    // 0xeeed84: cmp             x2, #0
    // 0xeeed88: b.gt            #0xeeed98
    // 0xeeed8c: r2 = true
    //     0xeeed8c: add             x2, NULL, #0x20  ; true
    // 0xeeed90: StoreField: r1->field_6b = r2
    //     0xeeed90: stur            w2, [x1, #0x6b]
    // 0xeeed94: b               #0xeeeda0
    // 0xeeed98: r2 = false
    //     0xeeed98: add             x2, NULL, #0x30  ; false
    // 0xeeed9c: StoreField: r1->field_6b = r2
    //     0xeeed9c: stur            w2, [x1, #0x6b]
    // 0xeeeda0: r0 = Null
    //     0xeeeda0: mov             x0, NULL
    // 0xeeeda4: LeaveFrame
    //     0xeeeda4: mov             SP, fp
    //     0xeeeda8: ldp             fp, lr, [SP], #0x10
    // 0xeeedac: ret
    //     0xeeedac: ret             
    // 0xeeedb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeeedb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeeedb4: b               #0xeeecec
    // 0xeeedb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeeedb8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xeeedbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeeedbc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf7b8e4, size: 0xc0
    // 0xf7b8e4: EnterFrame
    //     0xf7b8e4: stp             fp, lr, [SP, #-0x10]!
    //     0xf7b8e8: mov             fp, SP
    // 0xf7b8ec: AllocStack(0x20)
    //     0xf7b8ec: sub             SP, SP, #0x20
    // 0xf7b8f0: SetupParameters(_MaterialScrollbarState this /* r1 => r1, fp-0x8 */)
    //     0xf7b8f0: stur            x1, [fp, #-8]
    // 0xf7b8f4: CheckStackOverflow
    //     0xf7b8f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7b8f8: cmp             SP, x16
    //     0xf7b8fc: b.ls            #0xf7b99c
    // 0xf7b900: r1 = 1
    //     0xf7b900: mov             x1, #1
    // 0xf7b904: r0 = AllocateContext()
    //     0xf7b904: bl              #0x13de838  ; AllocateContextStub
    // 0xf7b908: mov             x2, x0
    // 0xf7b90c: ldur            x0, [fp, #-8]
    // 0xf7b910: stur            x2, [fp, #-0x10]
    // 0xf7b914: StoreField: r2->field_f = r0
    //     0xf7b914: stur            w0, [x2, #0xf]
    // 0xf7b918: mov             x1, x0
    // 0xf7b91c: r0 = initState()
    //     0xf7b91c: bl              #0xf7b9ec  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::initState
    // 0xf7b920: r1 = <double>
    //     0xf7b920: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf7b924: r0 = AnimationController()
    //     0xf7b924: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf7b928: stur            x0, [fp, #-0x18]
    // 0xf7b92c: r16 = Instance_Duration
    //     0xf7b92c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xf7b930: ldr             x16, [x16, #0x318]
    // 0xf7b934: str             x16, [SP]
    // 0xf7b938: mov             x1, x0
    // 0xf7b93c: ldur            x2, [fp, #-8]
    // 0xf7b940: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xf7b940: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xf7b944: ldr             x4, [x4, #0x5a0]
    // 0xf7b948: r0 = AnimationController()
    //     0xf7b948: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf7b94c: ldur            x0, [fp, #-0x18]
    // 0xf7b950: ldur            x1, [fp, #-8]
    // 0xf7b954: StoreField: r1->field_57 = r0
    //     0xf7b954: stur            w0, [x1, #0x57]
    //     0xf7b958: ldurb           w16, [x1, #-1]
    //     0xf7b95c: ldurb           w17, [x0, #-1]
    //     0xf7b960: and             x16, x17, x16, lsr #2
    //     0xf7b964: tst             x16, HEAP, lsr #32
    //     0xf7b968: b.eq            #0xf7b970
    //     0xf7b96c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf7b970: ldur            x2, [fp, #-0x10]
    // 0xf7b974: r1 = Function '<anonymous closure>':.
    //     0xf7b974: add             x1, PP, #0xab, lsl #12  ; [pp+0xab358] AnonymousClosure: (0xf7b9a4), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::initState (0xf7b8e4)
    //     0xf7b978: ldr             x1, [x1, #0x358]
    // 0xf7b97c: r0 = AllocateClosure()
    //     0xf7b97c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf7b980: ldur            x1, [fp, #-0x18]
    // 0xf7b984: mov             x2, x0
    // 0xf7b988: r0 = addListener()
    //     0xf7b988: bl              #0xd0440c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::addListener
    // 0xf7b98c: r0 = Null
    //     0xf7b98c: mov             x0, NULL
    // 0xf7b990: LeaveFrame
    //     0xf7b990: mov             SP, fp
    //     0xf7b994: ldp             fp, lr, [SP], #0x10
    // 0xf7b998: ret
    //     0xf7b998: ret             
    // 0xf7b99c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7b99c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7b9a0: b               #0xf7b900
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf7b9a4, size: 0x48
    // 0xf7b9a4: EnterFrame
    //     0xf7b9a4: stp             fp, lr, [SP, #-0x10]!
    //     0xf7b9a8: mov             fp, SP
    // 0xf7b9ac: ldr             x0, [fp, #0x10]
    // 0xf7b9b0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf7b9b0: ldur            w1, [x0, #0x17]
    // 0xf7b9b4: DecompressPointer r1
    //     0xf7b9b4: add             x1, x1, HEAP, lsl #32
    // 0xf7b9b8: CheckStackOverflow
    //     0xf7b9b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7b9bc: cmp             SP, x16
    //     0xf7b9c0: b.ls            #0xf7b9e4
    // 0xf7b9c4: LoadField: r0 = r1->field_f
    //     0xf7b9c4: ldur            w0, [x1, #0xf]
    // 0xf7b9c8: DecompressPointer r0
    //     0xf7b9c8: add             x0, x0, HEAP, lsl #32
    // 0xf7b9cc: mov             x1, x0
    // 0xf7b9d0: r0 = updateScrollbarPainter()
    //     0xf7b9d0: bl              #0x1230718  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::updateScrollbarPainter
    // 0xf7b9d4: r0 = Null
    //     0xf7b9d4: mov             x0, NULL
    // 0xf7b9d8: LeaveFrame
    //     0xf7b9d8: mov             SP, fp
    //     0xf7b9dc: ldp             fp, lr, [SP], #0x10
    // 0xf7b9e0: ret
    //     0xf7b9e0: ret             
    // 0xf7b9e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7b9e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7b9e8: b               #0xf7b9c4
  }
  _ _MaterialScrollbarState(/* No info */) {
    // ** addr: 0xfa08ac, size: 0x50
    // 0xfa08ac: EnterFrame
    //     0xfa08ac: stp             fp, lr, [SP, #-0x10]!
    //     0xfa08b0: mov             fp, SP
    // 0xfa08b4: ldr             x2, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa08b8: r0 = false
    //     0xfa08b8: add             x0, NULL, #0x30  ; false
    // 0xfa08bc: CheckStackOverflow
    //     0xfa08bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa08c0: cmp             SP, x16
    //     0xfa08c4: b.ls            #0xfa08f4
    // 0xfa08c8: StoreField: r1->field_57 = r2
    //     0xfa08c8: stur            w2, [x1, #0x57]
    // 0xfa08cc: StoreField: r1->field_5b = r0
    //     0xfa08cc: stur            w0, [x1, #0x5b]
    // 0xfa08d0: StoreField: r1->field_5f = r0
    //     0xfa08d0: stur            w0, [x1, #0x5f]
    // 0xfa08d4: StoreField: r1->field_63 = r2
    //     0xfa08d4: stur            w2, [x1, #0x63]
    // 0xfa08d8: StoreField: r1->field_67 = r2
    //     0xfa08d8: stur            w2, [x1, #0x67]
    // 0xfa08dc: StoreField: r1->field_6b = r2
    //     0xfa08dc: stur            w2, [x1, #0x6b]
    // 0xfa08e0: r0 = RawScrollbarState()
    //     0xfa08e0: bl              #0xfa07c4  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::RawScrollbarState
    // 0xfa08e4: r0 = Null
    //     0xfa08e4: mov             x0, NULL
    // 0xfa08e8: LeaveFrame
    //     0xfa08e8: mov             SP, fp
    //     0xfa08ec: ldp             fp, lr, [SP], #0x10
    // 0xfa08f0: ret
    //     0xfa08f0: ret             
    // 0xfa08f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa08f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa08f8: b               #0xfa08c8
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10ddddc, size: 0x64
    // 0x10ddddc: EnterFrame
    //     0x10ddddc: stp             fp, lr, [SP, #-0x10]!
    //     0x10ddde0: mov             fp, SP
    // 0x10ddde4: AllocStack(0x8)
    //     0x10ddde4: sub             SP, SP, #8
    // 0x10ddde8: SetupParameters(_MaterialScrollbarState this /* r1 => r0, fp-0x8 */)
    //     0x10ddde8: mov             x0, x1
    //     0x10dddec: stur            x1, [fp, #-8]
    // 0x10dddf0: CheckStackOverflow
    //     0x10dddf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10dddf4: cmp             SP, x16
    //     0x10dddf8: b.ls            #0x10dde2c
    // 0x10dddfc: LoadField: r1 = r0->field_57
    //     0x10dddfc: ldur            w1, [x0, #0x57]
    // 0x10dde00: DecompressPointer r1
    //     0x10dde00: add             x1, x1, HEAP, lsl #32
    // 0x10dde04: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10dde08: cmp             w1, w16
    // 0x10dde0c: b.eq            #0x10dde34
    // 0x10dde10: r0 = dispose()
    //     0x10dde10: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10dde14: ldur            x1, [fp, #-8]
    // 0x10dde18: r0 = dispose()
    //     0x10dde18: bl              #0x10dde40  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::dispose
    // 0x10dde1c: r0 = Null
    //     0x10dde1c: mov             x0, NULL
    // 0x10dde20: LeaveFrame
    //     0x10dde20: mov             SP, fp
    //     0x10dde24: ldp             fp, lr, [SP], #0x10
    // 0x10dde28: ret
    //     0x10dde28: ret             
    // 0x10dde2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dde2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dde30: b               #0x10dddfc
    // 0x10dde34: r9 = _hoverAnimationController
    //     0x10dde34: add             x9, PP, #0xab, lsl #12  ; [pp+0xab348] Field <_MaterialScrollbarState@626083257._hoverAnimationController@626083257>: late (offset: 0x58)
    //     0x10dde38: ldr             x9, [x9, #0x348]
    // 0x10dde3c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10dde3c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ updateScrollbarPainter(/* No info */) {
    // ** addr: 0x1230718, size: 0x30c
    // 0x1230718: EnterFrame
    //     0x1230718: stp             fp, lr, [SP, #-0x10]!
    //     0x123071c: mov             fp, SP
    // 0x1230720: AllocStack(0x18)
    //     0x1230720: sub             SP, SP, #0x18
    // 0x1230724: SetupParameters(_MaterialScrollbarState this /* r1 => r0, fp-0x10 */)
    //     0x1230724: mov             x0, x1
    //     0x1230728: stur            x1, [fp, #-0x10]
    // 0x123072c: CheckStackOverflow
    //     0x123072c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1230730: cmp             SP, x16
    //     0x1230734: b.ls            #0x12309d0
    // 0x1230738: LoadField: r2 = r0->field_53
    //     0x1230738: ldur            w2, [x0, #0x53]
    // 0x123073c: DecompressPointer r2
    //     0x123073c: add             x2, x2, HEAP, lsl #32
    // 0x1230740: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1230744: cmp             w2, w16
    // 0x1230748: b.eq            #0x12309d8
    // 0x123074c: mov             x1, x0
    // 0x1230750: stur            x2, [fp, #-8]
    // 0x1230754: r0 = _thumbColor()
    //     0x1230754: bl              #0x1231380  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_thumbColor
    // 0x1230758: ldur            x1, [fp, #-0x10]
    // 0x123075c: stur            x0, [fp, #-0x18]
    // 0x1230760: r0 = _states()
    //     0x1230760: bl              #0x12312d8  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_states
    // 0x1230764: ldur            x1, [fp, #-0x18]
    // 0x1230768: mov             x2, x0
    // 0x123076c: r0 = build()
    //     0x123076c: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0x1230770: ldur            x1, [fp, #-8]
    // 0x1230774: mov             x2, x0
    // 0x1230778: r0 = color=()
    //     0x1230778: bl              #0x1230674  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::color=
    // 0x123077c: ldur            x1, [fp, #-0x10]
    // 0x1230780: r0 = _trackColor()
    //     0x1230780: bl              #0x12310fc  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_trackColor
    // 0x1230784: ldur            x1, [fp, #-0x10]
    // 0x1230788: stur            x0, [fp, #-0x18]
    // 0x123078c: r0 = _states()
    //     0x123078c: bl              #0x12312d8  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_states
    // 0x1230790: ldur            x1, [fp, #-0x18]
    // 0x1230794: mov             x2, x0
    // 0x1230798: r0 = build()
    //     0x1230798: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0x123079c: ldur            x1, [fp, #-8]
    // 0x12307a0: mov             x2, x0
    // 0x12307a4: r0 = trackColor=()
    //     0x12307a4: bl              #0x1231058  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::trackColor=
    // 0x12307a8: ldur            x1, [fp, #-0x10]
    // 0x12307ac: r0 = _trackBorderColor()
    //     0x12307ac: bl              #0x1230e7c  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_trackBorderColor
    // 0x12307b0: ldur            x1, [fp, #-0x10]
    // 0x12307b4: stur            x0, [fp, #-0x18]
    // 0x12307b8: r0 = _states()
    //     0x12307b8: bl              #0x12312d8  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_states
    // 0x12307bc: ldur            x1, [fp, #-0x18]
    // 0x12307c0: mov             x2, x0
    // 0x12307c4: r0 = build()
    //     0x12307c4: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0x12307c8: ldur            x1, [fp, #-8]
    // 0x12307cc: mov             x2, x0
    // 0x12307d0: r0 = trackBorderColor=()
    //     0x12307d0: bl              #0x1230dd8  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::trackBorderColor=
    // 0x12307d4: ldur            x0, [fp, #-0x10]
    // 0x12307d8: LoadField: r1 = r0->field_f
    //     0x12307d8: ldur            w1, [x0, #0xf]
    // 0x12307dc: DecompressPointer r1
    //     0x12307dc: add             x1, x1, HEAP, lsl #32
    // 0x12307e0: cmp             w1, NULL
    // 0x12307e4: b.eq            #0x12309e4
    // 0x12307e8: r0 = of()
    //     0x12307e8: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x12307ec: ldur            x1, [fp, #-8]
    // 0x12307f0: mov             x2, x0
    // 0x12307f4: r0 = textDirection=()
    //     0x12307f4: bl              #0x12305e0  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::textDirection=
    // 0x12307f8: ldur            x1, [fp, #-0x10]
    // 0x12307fc: r0 = _thickness()
    //     0x12307fc: bl              #0x1230a78  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_thickness
    // 0x1230800: ldur            x1, [fp, #-0x10]
    // 0x1230804: stur            x0, [fp, #-0x18]
    // 0x1230808: r0 = _states()
    //     0x1230808: bl              #0x12312d8  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_states
    // 0x123080c: ldur            x1, [fp, #-0x18]
    // 0x1230810: mov             x2, x0
    // 0x1230814: r0 = build()
    //     0x1230814: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0x1230818: LoadField: d0 = r0->field_7
    //     0x1230818: ldur            d0, [x0, #7]
    // 0x123081c: ldur            x1, [fp, #-8]
    // 0x1230820: r0 = thickness=()
    //     0x1230820: bl              #0x1230320  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::thickness=
    // 0x1230824: ldur            x0, [fp, #-0x10]
    // 0x1230828: LoadField: r1 = r0->field_b
    //     0x1230828: ldur            w1, [x0, #0xb]
    // 0x123082c: DecompressPointer r1
    //     0x123082c: add             x1, x1, HEAP, lsl #32
    // 0x1230830: cmp             w1, NULL
    // 0x1230834: b.eq            #0x12309e8
    // 0x1230838: LoadField: r2 = r1->field_1b
    //     0x1230838: ldur            w2, [x1, #0x1b]
    // 0x123083c: DecompressPointer r2
    //     0x123083c: add             x2, x2, HEAP, lsl #32
    // 0x1230840: cmp             w2, NULL
    // 0x1230844: b.ne            #0x1230864
    // 0x1230848: LoadField: r1 = r0->field_67
    //     0x1230848: ldur            w1, [x0, #0x67]
    // 0x123084c: DecompressPointer r1
    //     0x123084c: add             x1, x1, HEAP, lsl #32
    // 0x1230850: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1230854: cmp             w1, w16
    // 0x1230858: b.eq            #0x12309ec
    // 0x123085c: r1 = Null
    //     0x123085c: mov             x1, NULL
    // 0x1230860: b               #0x1230868
    // 0x1230864: mov             x1, x2
    // 0x1230868: cmp             w1, NULL
    // 0x123086c: b.ne            #0x12308a0
    // 0x1230870: LoadField: r1 = r0->field_6b
    //     0x1230870: ldur            w1, [x0, #0x6b]
    // 0x1230874: DecompressPointer r1
    //     0x1230874: add             x1, x1, HEAP, lsl #32
    // 0x1230878: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x123087c: cmp             w1, w16
    // 0x1230880: b.eq            #0x12309f8
    // 0x1230884: tbnz            w1, #4, #0x1230890
    // 0x1230888: r1 = Null
    //     0x1230888: mov             x1, NULL
    // 0x123088c: b               #0x1230898
    // 0x1230890: r1 = Instance_Radius
    //     0x1230890: add             x1, PP, #0x98, lsl #12  ; [pp+0x986c8] Obj!Radius@12a71e1
    //     0x1230894: ldr             x1, [x1, #0x6c8]
    // 0x1230898: mov             x2, x1
    // 0x123089c: b               #0x12308a4
    // 0x12308a0: mov             x2, x1
    // 0x12308a4: ldur            x1, [fp, #-8]
    // 0x12308a8: r0 = radius=()
    //     0x12308a8: bl              #0x1230418  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::radius=
    // 0x12308ac: ldur            x0, [fp, #-0x10]
    // 0x12308b0: LoadField: r1 = r0->field_67
    //     0x12308b0: ldur            w1, [x0, #0x67]
    // 0x12308b4: DecompressPointer r1
    //     0x12308b4: add             x1, x1, HEAP, lsl #32
    // 0x12308b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12308bc: cmp             w1, w16
    // 0x12308c0: b.eq            #0x1230a04
    // 0x12308c4: LoadField: r2 = r1->field_27
    //     0x12308c4: ldur            w2, [x1, #0x27]
    // 0x12308c8: DecompressPointer r2
    //     0x12308c8: add             x2, x2, HEAP, lsl #32
    // 0x12308cc: cmp             w2, NULL
    // 0x12308d0: b.ne            #0x12308fc
    // 0x12308d4: LoadField: r1 = r0->field_6b
    //     0x12308d4: ldur            w1, [x0, #0x6b]
    // 0x12308d8: DecompressPointer r1
    //     0x12308d8: add             x1, x1, HEAP, lsl #32
    // 0x12308dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12308e0: cmp             w1, w16
    // 0x12308e4: b.eq            #0x1230a10
    // 0x12308e8: tbnz            w1, #4, #0x12308f4
    // 0x12308ec: d0 = 0.000000
    //     0x12308ec: eor             v0.16b, v0.16b, v0.16b
    // 0x12308f0: b               #0x1230900
    // 0x12308f4: d0 = 2.000000
    //     0x12308f4: fmov            d0, #2.00000000
    // 0x12308f8: b               #0x1230900
    // 0x12308fc: LoadField: d0 = r2->field_7
    //     0x12308fc: ldur            d0, [x2, #7]
    // 0x1230900: ldur            x1, [fp, #-8]
    // 0x1230904: r0 = crossAxisMargin=()
    //     0x1230904: bl              #0x1230280  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::crossAxisMargin=
    // 0x1230908: ldur            x0, [fp, #-0x10]
    // 0x123090c: LoadField: r1 = r0->field_67
    //     0x123090c: ldur            w1, [x0, #0x67]
    // 0x1230910: DecompressPointer r1
    //     0x1230910: add             x1, x1, HEAP, lsl #32
    // 0x1230914: LoadField: r2 = r1->field_2b
    //     0x1230914: ldur            w2, [x1, #0x2b]
    // 0x1230918: DecompressPointer r2
    //     0x1230918: add             x2, x2, HEAP, lsl #32
    // 0x123091c: cmp             w2, NULL
    // 0x1230920: b.ne            #0x123092c
    // 0x1230924: d0 = 0.000000
    //     0x1230924: eor             v0.16b, v0.16b, v0.16b
    // 0x1230928: b               #0x1230930
    // 0x123092c: LoadField: d0 = r2->field_7
    //     0x123092c: ldur            d0, [x2, #7]
    // 0x1230930: ldur            x1, [fp, #-8]
    // 0x1230934: r0 = mainAxisMargin=()
    //     0x1230934: bl              #0x12302d0  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::mainAxisMargin=
    // 0x1230938: ldur            x0, [fp, #-0x10]
    // 0x123093c: LoadField: r1 = r0->field_67
    //     0x123093c: ldur            w1, [x0, #0x67]
    // 0x1230940: DecompressPointer r1
    //     0x1230940: add             x1, x1, HEAP, lsl #32
    // 0x1230944: LoadField: r2 = r1->field_2f
    //     0x1230944: ldur            w2, [x1, #0x2f]
    // 0x1230948: DecompressPointer r2
    //     0x1230948: add             x2, x2, HEAP, lsl #32
    // 0x123094c: cmp             w2, NULL
    // 0x1230950: b.ne            #0x123095c
    // 0x1230954: d0 = 48.000000
    //     0x1230954: ldr             d0, [PP, #0x5650]  ; [pp+0x5650] IMM: double(48) from 0x4048000000000000
    // 0x1230958: b               #0x1230960
    // 0x123095c: LoadField: d0 = r2->field_7
    //     0x123095c: ldur            d0, [x2, #7]
    // 0x1230960: ldur            x1, [fp, #-8]
    // 0x1230964: r0 = minLength=()
    //     0x1230964: bl              #0x1230230  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::minLength=
    // 0x1230968: ldur            x0, [fp, #-0x10]
    // 0x123096c: LoadField: r1 = r0->field_f
    //     0x123096c: ldur            w1, [x0, #0xf]
    // 0x1230970: DecompressPointer r1
    //     0x1230970: add             x1, x1, HEAP, lsl #32
    // 0x1230974: cmp             w1, NULL
    // 0x1230978: b.eq            #0x1230a1c
    // 0x123097c: r0 = paddingOf()
    //     0x123097c: bl              #0xd1a984  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::paddingOf
    // 0x1230980: ldur            x1, [fp, #-8]
    // 0x1230984: mov             x2, x0
    // 0x1230988: r0 = padding=()
    //     0x1230988: bl              #0x1230370  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::padding=
    // 0x123098c: ldur            x0, [fp, #-0x10]
    // 0x1230990: LoadField: r1 = r0->field_b
    //     0x1230990: ldur            w1, [x0, #0xb]
    // 0x1230994: DecompressPointer r1
    //     0x1230994: add             x1, x1, HEAP, lsl #32
    // 0x1230998: cmp             w1, NULL
    // 0x123099c: b.eq            #0x1230a20
    // 0x12309a0: ldur            x1, [fp, #-8]
    // 0x12309a4: r2 = Null
    //     0x12309a4: mov             x2, NULL
    // 0x12309a8: r0 = Shader._()
    //     0x12309a8: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0x12309ac: ldur            x1, [fp, #-0x10]
    // 0x12309b0: r0 = enableGestures()
    //     0x12309b0: bl              #0x1283ca4  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::enableGestures
    // 0x12309b4: eor             x2, x0, #0x10
    // 0x12309b8: ldur            x1, [fp, #-8]
    // 0x12309bc: r0 = ignorePointer=()
    //     0x12309bc: bl              #0x1230a24  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::ignorePointer=
    // 0x12309c0: r0 = Null
    //     0x12309c0: mov             x0, NULL
    // 0x12309c4: LeaveFrame
    //     0x12309c4: mov             SP, fp
    //     0x12309c8: ldp             fp, lr, [SP], #0x10
    // 0x12309cc: ret
    //     0x12309cc: ret             
    // 0x12309d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12309d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12309d4: b               #0x1230738
    // 0x12309d8: r9 = scrollbarPainter
    //     0x12309d8: add             x9, PP, #0xab, lsl #12  ; [pp+0xab360] Field <RawScrollbarState.scrollbarPainter>: late final (offset: 0x54)
    //     0x12309dc: ldr             x9, [x9, #0x360]
    // 0x12309e0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12309e0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12309e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12309e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12309e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12309e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12309ec: r9 = _scrollbarTheme
    //     0x12309ec: add             x9, PP, #0xab, lsl #12  ; [pp+0xab368] Field <_MaterialScrollbarState@626083257._scrollbarTheme@626083257>: late (offset: 0x68)
    //     0x12309f0: ldr             x9, [x9, #0x368]
    // 0x12309f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12309f4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12309f8: r9 = _useAndroidScrollbar
    //     0x12309f8: add             x9, PP, #0xab, lsl #12  ; [pp+0xab370] Field <_MaterialScrollbarState@626083257._useAndroidScrollbar@626083257>: late (offset: 0x6c)
    //     0x12309fc: ldr             x9, [x9, #0x370]
    // 0x1230a00: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1230a00: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x1230a04: r9 = _scrollbarTheme
    //     0x1230a04: add             x9, PP, #0xab, lsl #12  ; [pp+0xab368] Field <_MaterialScrollbarState@626083257._scrollbarTheme@626083257>: late (offset: 0x68)
    //     0x1230a08: ldr             x9, [x9, #0x368]
    // 0x1230a0c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1230a0c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x1230a10: r9 = _useAndroidScrollbar
    //     0x1230a10: add             x9, PP, #0xab, lsl #12  ; [pp+0xab370] Field <_MaterialScrollbarState@626083257._useAndroidScrollbar@626083257>: late (offset: 0x6c)
    //     0x1230a14: ldr             x9, [x9, #0x370]
    // 0x1230a18: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1230a18: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x1230a1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1230a1c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1230a20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1230a20: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _thickness(/* No info */) {
    // ** addr: 0x1230a78, size: 0x64
    // 0x1230a78: EnterFrame
    //     0x1230a78: stp             fp, lr, [SP, #-0x10]!
    //     0x1230a7c: mov             fp, SP
    // 0x1230a80: AllocStack(0x18)
    //     0x1230a80: sub             SP, SP, #0x18
    // 0x1230a84: SetupParameters(_MaterialScrollbarState this /* r1 => r1, fp-0x8 */)
    //     0x1230a84: stur            x1, [fp, #-8]
    // 0x1230a88: CheckStackOverflow
    //     0x1230a88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1230a8c: cmp             SP, x16
    //     0x1230a90: b.ls            #0x1230ad4
    // 0x1230a94: r1 = 1
    //     0x1230a94: mov             x1, #1
    // 0x1230a98: r0 = AllocateContext()
    //     0x1230a98: bl              #0x13de838  ; AllocateContextStub
    // 0x1230a9c: mov             x1, x0
    // 0x1230aa0: ldur            x0, [fp, #-8]
    // 0x1230aa4: StoreField: r1->field_f = r0
    //     0x1230aa4: stur            w0, [x1, #0xf]
    // 0x1230aa8: mov             x2, x1
    // 0x1230aac: r1 = Function '<anonymous closure>':.
    //     0x1230aac: add             x1, PP, #0xab, lsl #12  ; [pp+0xab378] AnonymousClosure: (0x1230adc), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_thickness (0x1230a78)
    //     0x1230ab0: ldr             x1, [x1, #0x378]
    // 0x1230ab4: r0 = AllocateClosure()
    //     0x1230ab4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1230ab8: r16 = <double>
    //     0x1230ab8: ldr             x16, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x1230abc: stp             x0, x16, [SP]
    // 0x1230ac0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1230ac0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1230ac4: r0 = resolveWith()
    //     0x1230ac4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1230ac8: LeaveFrame
    //     0x1230ac8: mov             SP, fp
    //     0x1230acc: ldp             fp, lr, [SP], #0x10
    // 0x1230ad0: ret
    //     0x1230ad0: ret             
    // 0x1230ad4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1230ad4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1230ad8: b               #0x1230a94
  }
  [closure] double <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x1230adc, size: 0x238
    // 0x1230adc: EnterFrame
    //     0x1230adc: stp             fp, lr, [SP, #-0x10]!
    //     0x1230ae0: mov             fp, SP
    // 0x1230ae4: AllocStack(0x8)
    //     0x1230ae4: sub             SP, SP, #8
    // 0x1230ae8: SetupParameters([dynamic _ /* r0 */])
    //     0x1230ae8: ldr             x0, [fp, #0x18]
    //     0x1230aec: ldur            w3, [x0, #0x17]
    //     0x1230af0: add             x3, x3, HEAP, lsl #32
    //     0x1230af4: stur            x3, [fp, #-8]
    // 0x1230af8: CheckStackOverflow
    //     0x1230af8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1230afc: cmp             SP, x16
    //     0x1230b00: b.ls            #0x1230cc0
    // 0x1230b04: ldr             x4, [fp, #0x10]
    // 0x1230b08: r0 = LoadClassIdInstr(r4)
    //     0x1230b08: ldur            x0, [x4, #-1]
    //     0x1230b0c: ubfx            x0, x0, #0xc, #0x14
    // 0x1230b10: mov             x1, x4
    // 0x1230b14: r2 = Instance_WidgetState
    //     0x1230b14: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0x1230b18: ldr             x2, [x2, #0xa50]
    // 0x1230b1c: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1230b1c: mov             x17, #0x2929
    //     0x1230b20: movk            x17, #1, lsl #16
    //     0x1230b24: add             lr, x0, x17
    //     0x1230b28: ldr             lr, [x21, lr, lsl #3]
    //     0x1230b2c: blr             lr
    // 0x1230b30: tbnz            w0, #4, #0x1230bf4
    // 0x1230b34: ldur            x0, [fp, #-8]
    // 0x1230b38: LoadField: r1 = r0->field_f
    //     0x1230b38: ldur            w1, [x0, #0xf]
    // 0x1230b3c: DecompressPointer r1
    //     0x1230b3c: add             x1, x1, HEAP, lsl #32
    // 0x1230b40: r0 = _trackVisibility()
    //     0x1230b40: bl              #0x1230d14  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_trackVisibility
    // 0x1230b44: mov             x1, x0
    // 0x1230b48: ldr             x2, [fp, #0x10]
    // 0x1230b4c: r0 = build()
    //     0x1230b4c: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0x1230b50: tbnz            w0, #4, #0x1230bec
    // 0x1230b54: ldur            x1, [fp, #-8]
    // 0x1230b58: LoadField: r2 = r1->field_f
    //     0x1230b58: ldur            w2, [x1, #0xf]
    // 0x1230b5c: DecompressPointer r2
    //     0x1230b5c: add             x2, x2, HEAP, lsl #32
    // 0x1230b60: LoadField: r3 = r2->field_b
    //     0x1230b60: ldur            w3, [x2, #0xb]
    // 0x1230b64: DecompressPointer r3
    //     0x1230b64: add             x3, x3, HEAP, lsl #32
    // 0x1230b68: cmp             w3, NULL
    // 0x1230b6c: b.eq            #0x1230cc8
    // 0x1230b70: LoadField: r4 = r3->field_1f
    //     0x1230b70: ldur            w4, [x3, #0x1f]
    // 0x1230b74: DecompressPointer r4
    //     0x1230b74: add             x4, x4, HEAP, lsl #32
    // 0x1230b78: cmp             w4, NULL
    // 0x1230b7c: b.ne            #0x1230b9c
    // 0x1230b80: LoadField: r3 = r2->field_67
    //     0x1230b80: ldur            w3, [x2, #0x67]
    // 0x1230b84: DecompressPointer r3
    //     0x1230b84: add             x3, x3, HEAP, lsl #32
    // 0x1230b88: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1230b8c: cmp             w3, w16
    // 0x1230b90: b.eq            #0x1230ccc
    // 0x1230b94: r2 = Null
    //     0x1230b94: mov             x2, NULL
    // 0x1230b98: b               #0x1230ba0
    // 0x1230b9c: mov             x2, x4
    // 0x1230ba0: cmp             w2, NULL
    // 0x1230ba4: b.ne            #0x1230bb0
    // 0x1230ba8: d0 = 12.000000
    //     0x1230ba8: fmov            d0, #12.00000000
    // 0x1230bac: b               #0x1230bb4
    // 0x1230bb0: LoadField: d0 = r2->field_7
    //     0x1230bb0: ldur            d0, [x2, #7]
    // 0x1230bb4: r0 = inline_Allocate_Double()
    //     0x1230bb4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x1230bb8: add             x0, x0, #0x10
    //     0x1230bbc: cmp             x2, x0
    //     0x1230bc0: b.ls            #0x1230cd8
    //     0x1230bc4: str             x0, [THR, #0x60]  ; THR::top
    //     0x1230bc8: sub             x0, x0, #0xf
    //     0x1230bcc: mov             x2, #0xe19c
    //     0x1230bd0: movk            x2, #3, lsl #16
    //     0x1230bd4: stur            x2, [x0, #-1]
    // 0x1230bd8: dmb             ishst
    // 0x1230bdc: StoreField: r0->field_7 = d0
    //     0x1230bdc: stur            d0, [x0, #7]
    // 0x1230be0: LeaveFrame
    //     0x1230be0: mov             SP, fp
    //     0x1230be4: ldp             fp, lr, [SP], #0x10
    // 0x1230be8: ret
    //     0x1230be8: ret             
    // 0x1230bec: ldur            x1, [fp, #-8]
    // 0x1230bf0: b               #0x1230bf8
    // 0x1230bf4: ldur            x1, [fp, #-8]
    // 0x1230bf8: LoadField: r2 = r1->field_f
    //     0x1230bf8: ldur            w2, [x1, #0xf]
    // 0x1230bfc: DecompressPointer r2
    //     0x1230bfc: add             x2, x2, HEAP, lsl #32
    // 0x1230c00: LoadField: r1 = r2->field_b
    //     0x1230c00: ldur            w1, [x2, #0xb]
    // 0x1230c04: DecompressPointer r1
    //     0x1230c04: add             x1, x1, HEAP, lsl #32
    // 0x1230c08: cmp             w1, NULL
    // 0x1230c0c: b.eq            #0x1230ce8
    // 0x1230c10: LoadField: r3 = r1->field_1f
    //     0x1230c10: ldur            w3, [x1, #0x1f]
    // 0x1230c14: DecompressPointer r3
    //     0x1230c14: add             x3, x3, HEAP, lsl #32
    // 0x1230c18: cmp             w3, NULL
    // 0x1230c1c: b.ne            #0x1230c3c
    // 0x1230c20: LoadField: r1 = r2->field_67
    //     0x1230c20: ldur            w1, [x2, #0x67]
    // 0x1230c24: DecompressPointer r1
    //     0x1230c24: add             x1, x1, HEAP, lsl #32
    // 0x1230c28: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1230c2c: cmp             w1, w16
    // 0x1230c30: b.eq            #0x1230cec
    // 0x1230c34: r1 = Null
    //     0x1230c34: mov             x1, NULL
    // 0x1230c38: b               #0x1230c40
    // 0x1230c3c: mov             x1, x3
    // 0x1230c40: cmp             w1, NULL
    // 0x1230c44: b.ne            #0x1230c84
    // 0x1230c48: d0 = 8.000000
    //     0x1230c48: fmov            d0, #8.00000000
    // 0x1230c4c: LoadField: r3 = r2->field_6b
    //     0x1230c4c: ldur            w3, [x2, #0x6b]
    // 0x1230c50: DecompressPointer r3
    //     0x1230c50: add             x3, x3, HEAP, lsl #32
    // 0x1230c54: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1230c58: cmp             w3, w16
    // 0x1230c5c: b.eq            #0x1230cf8
    // 0x1230c60: tst             x3, #0x10
    // 0x1230c64: csetm           x2, eq
    // 0x1230c68: and             x2, x2, #2
    // 0x1230c6c: add             x2, x2, #2
    // 0x1230c70: r16 = LoadInt32Instr(r2)
    //     0x1230c70: sbfx            x16, x2, #1, #0x1f
    // 0x1230c74: scvtf           d1, w16
    // 0x1230c78: fdiv            d2, d0, d1
    // 0x1230c7c: mov             v0.16b, v2.16b
    // 0x1230c80: b               #0x1230c88
    // 0x1230c84: LoadField: d0 = r1->field_7
    //     0x1230c84: ldur            d0, [x1, #7]
    // 0x1230c88: r0 = inline_Allocate_Double()
    //     0x1230c88: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x1230c8c: add             x0, x0, #0x10
    //     0x1230c90: cmp             x1, x0
    //     0x1230c94: b.ls            #0x1230d04
    //     0x1230c98: str             x0, [THR, #0x60]  ; THR::top
    //     0x1230c9c: sub             x0, x0, #0xf
    //     0x1230ca0: mov             x1, #0xe19c
    //     0x1230ca4: movk            x1, #3, lsl #16
    //     0x1230ca8: stur            x1, [x0, #-1]
    // 0x1230cac: dmb             ishst
    // 0x1230cb0: StoreField: r0->field_7 = d0
    //     0x1230cb0: stur            d0, [x0, #7]
    // 0x1230cb4: LeaveFrame
    //     0x1230cb4: mov             SP, fp
    //     0x1230cb8: ldp             fp, lr, [SP], #0x10
    // 0x1230cbc: ret
    //     0x1230cbc: ret             
    // 0x1230cc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1230cc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1230cc4: b               #0x1230b04
    // 0x1230cc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1230cc8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1230ccc: r9 = _scrollbarTheme
    //     0x1230ccc: add             x9, PP, #0xab, lsl #12  ; [pp+0xab368] Field <_MaterialScrollbarState@626083257._scrollbarTheme@626083257>: late (offset: 0x68)
    //     0x1230cd0: ldr             x9, [x9, #0x368]
    // 0x1230cd4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1230cd4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x1230cd8: SaveReg d0
    //     0x1230cd8: str             q0, [SP, #-0x10]!
    // 0x1230cdc: r0 = AllocateDouble()
    //     0x1230cdc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1230ce0: RestoreReg d0
    //     0x1230ce0: ldr             q0, [SP], #0x10
    // 0x1230ce4: b               #0x1230bdc
    // 0x1230ce8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1230ce8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1230cec: r9 = _scrollbarTheme
    //     0x1230cec: add             x9, PP, #0xab, lsl #12  ; [pp+0xab368] Field <_MaterialScrollbarState@626083257._scrollbarTheme@626083257>: late (offset: 0x68)
    //     0x1230cf0: ldr             x9, [x9, #0x368]
    // 0x1230cf4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1230cf4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x1230cf8: r9 = _useAndroidScrollbar
    //     0x1230cf8: add             x9, PP, #0xab, lsl #12  ; [pp+0xab370] Field <_MaterialScrollbarState@626083257._useAndroidScrollbar@626083257>: late (offset: 0x6c)
    //     0x1230cfc: ldr             x9, [x9, #0x370]
    // 0x1230d00: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x1230d00: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x1230d04: SaveReg d0
    //     0x1230d04: str             q0, [SP, #-0x10]!
    // 0x1230d08: r0 = AllocateDouble()
    //     0x1230d08: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1230d0c: RestoreReg d0
    //     0x1230d0c: ldr             q0, [SP], #0x10
    // 0x1230d10: b               #0x1230cb0
  }
  get _ _trackVisibility(/* No info */) {
    // ** addr: 0x1230d14, size: 0x64
    // 0x1230d14: EnterFrame
    //     0x1230d14: stp             fp, lr, [SP, #-0x10]!
    //     0x1230d18: mov             fp, SP
    // 0x1230d1c: AllocStack(0x18)
    //     0x1230d1c: sub             SP, SP, #0x18
    // 0x1230d20: SetupParameters(_MaterialScrollbarState this /* r1 => r1, fp-0x8 */)
    //     0x1230d20: stur            x1, [fp, #-8]
    // 0x1230d24: CheckStackOverflow
    //     0x1230d24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1230d28: cmp             SP, x16
    //     0x1230d2c: b.ls            #0x1230d70
    // 0x1230d30: r1 = 1
    //     0x1230d30: mov             x1, #1
    // 0x1230d34: r0 = AllocateContext()
    //     0x1230d34: bl              #0x13de838  ; AllocateContextStub
    // 0x1230d38: mov             x1, x0
    // 0x1230d3c: ldur            x0, [fp, #-8]
    // 0x1230d40: StoreField: r1->field_f = r0
    //     0x1230d40: stur            w0, [x1, #0xf]
    // 0x1230d44: mov             x2, x1
    // 0x1230d48: r1 = Function '<anonymous closure>':.
    //     0x1230d48: add             x1, PP, #0xab, lsl #12  ; [pp+0xab380] AnonymousClosure: (0x1230d78), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_trackVisibility (0x1230d14)
    //     0x1230d4c: ldr             x1, [x1, #0x380]
    // 0x1230d50: r0 = AllocateClosure()
    //     0x1230d50: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1230d54: r16 = <bool>
    //     0x1230d54: ldr             x16, [PP, #0x1918]  ; [pp+0x1918] TypeArguments: <bool>
    // 0x1230d58: stp             x0, x16, [SP]
    // 0x1230d5c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1230d5c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1230d60: r0 = resolveWith()
    //     0x1230d60: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1230d64: LeaveFrame
    //     0x1230d64: mov             SP, fp
    //     0x1230d68: ldp             fp, lr, [SP], #0x10
    // 0x1230d6c: ret
    //     0x1230d6c: ret             
    // 0x1230d70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1230d70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1230d74: b               #0x1230d30
  }
  [closure] bool <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x1230d78, size: 0x60
    // 0x1230d78: EnterFrame
    //     0x1230d78: stp             fp, lr, [SP, #-0x10]!
    //     0x1230d7c: mov             fp, SP
    // 0x1230d80: ldr             x1, [fp, #0x18]
    // 0x1230d84: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x1230d84: ldur            w2, [x1, #0x17]
    // 0x1230d88: DecompressPointer r2
    //     0x1230d88: add             x2, x2, HEAP, lsl #32
    // 0x1230d8c: LoadField: r1 = r2->field_f
    //     0x1230d8c: ldur            w1, [x2, #0xf]
    // 0x1230d90: DecompressPointer r1
    //     0x1230d90: add             x1, x1, HEAP, lsl #32
    // 0x1230d94: LoadField: r2 = r1->field_b
    //     0x1230d94: ldur            w2, [x1, #0xb]
    // 0x1230d98: DecompressPointer r2
    //     0x1230d98: add             x2, x2, HEAP, lsl #32
    // 0x1230d9c: cmp             w2, NULL
    // 0x1230da0: b.eq            #0x1230dc8
    // 0x1230da4: LoadField: r2 = r1->field_67
    //     0x1230da4: ldur            w2, [x1, #0x67]
    // 0x1230da8: DecompressPointer r2
    //     0x1230da8: add             x2, x2, HEAP, lsl #32
    // 0x1230dac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1230db0: cmp             w2, w16
    // 0x1230db4: b.eq            #0x1230dcc
    // 0x1230db8: r0 = false
    //     0x1230db8: add             x0, NULL, #0x30  ; false
    // 0x1230dbc: LeaveFrame
    //     0x1230dbc: mov             SP, fp
    //     0x1230dc0: ldp             fp, lr, [SP], #0x10
    // 0x1230dc4: ret
    //     0x1230dc4: ret             
    // 0x1230dc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1230dc8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1230dcc: r9 = _scrollbarTheme
    //     0x1230dcc: add             x9, PP, #0xab, lsl #12  ; [pp+0xab368] Field <_MaterialScrollbarState@626083257._scrollbarTheme@626083257>: late (offset: 0x68)
    //     0x1230dd0: ldr             x9, [x9, #0x368]
    // 0x1230dd4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1230dd4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _trackBorderColor(/* No info */) {
    // ** addr: 0x1230e7c, size: 0xa0
    // 0x1230e7c: EnterFrame
    //     0x1230e7c: stp             fp, lr, [SP, #-0x10]!
    //     0x1230e80: mov             fp, SP
    // 0x1230e84: AllocStack(0x18)
    //     0x1230e84: sub             SP, SP, #0x18
    // 0x1230e88: SetupParameters(_MaterialScrollbarState this /* r1 => r1, fp-0x8 */)
    //     0x1230e88: stur            x1, [fp, #-8]
    // 0x1230e8c: CheckStackOverflow
    //     0x1230e8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1230e90: cmp             SP, x16
    //     0x1230e94: b.ls            #0x1230f08
    // 0x1230e98: r1 = 3
    //     0x1230e98: mov             x1, #3
    // 0x1230e9c: r0 = AllocateContext()
    //     0x1230e9c: bl              #0x13de838  ; AllocateContextStub
    // 0x1230ea0: mov             x1, x0
    // 0x1230ea4: ldur            x0, [fp, #-8]
    // 0x1230ea8: StoreField: r1->field_f = r0
    //     0x1230ea8: stur            w0, [x1, #0xf]
    // 0x1230eac: LoadField: r2 = r0->field_63
    //     0x1230eac: ldur            w2, [x0, #0x63]
    // 0x1230eb0: DecompressPointer r2
    //     0x1230eb0: add             x2, x2, HEAP, lsl #32
    // 0x1230eb4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1230eb8: cmp             w2, w16
    // 0x1230ebc: b.eq            #0x1230f10
    // 0x1230ec0: LoadField: r0 = r2->field_7f
    //     0x1230ec0: ldur            w0, [x2, #0x7f]
    // 0x1230ec4: DecompressPointer r0
    //     0x1230ec4: add             x0, x0, HEAP, lsl #32
    // 0x1230ec8: StoreField: r1->field_13 = r0
    //     0x1230ec8: stur            w0, [x1, #0x13]
    // 0x1230ecc: LoadField: r0 = r2->field_7
    //     0x1230ecc: ldur            w0, [x2, #7]
    // 0x1230ed0: DecompressPointer r0
    //     0x1230ed0: add             x0, x0, HEAP, lsl #32
    // 0x1230ed4: ArrayStore: r1[0] = r0  ; List_4
    //     0x1230ed4: stur            w0, [x1, #0x17]
    // 0x1230ed8: mov             x2, x1
    // 0x1230edc: r1 = Function '<anonymous closure>':.
    //     0x1230edc: add             x1, PP, #0xab, lsl #12  ; [pp+0xab388] AnonymousClosure: (0x1230f1c), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_trackBorderColor (0x1230e7c)
    //     0x1230ee0: ldr             x1, [x1, #0x388]
    // 0x1230ee4: r0 = AllocateClosure()
    //     0x1230ee4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1230ee8: r16 = <Color>
    //     0x1230ee8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1230eec: ldr             x16, [x16, #0xa90]
    // 0x1230ef0: stp             x0, x16, [SP]
    // 0x1230ef4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1230ef4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1230ef8: r0 = resolveWith()
    //     0x1230ef8: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1230efc: LeaveFrame
    //     0x1230efc: mov             SP, fp
    //     0x1230f00: ldp             fp, lr, [SP], #0x10
    // 0x1230f04: ret
    //     0x1230f04: ret             
    // 0x1230f08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1230f08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1230f0c: b               #0x1230e98
    // 0x1230f10: r9 = _colorScheme
    //     0x1230f10: add             x9, PP, #0xab, lsl #12  ; [pp+0xab390] Field <_MaterialScrollbarState@626083257._colorScheme@626083257>: late (offset: 0x64)
    //     0x1230f14: ldr             x9, [x9, #0x390]
    // 0x1230f18: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1230f18: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x1230f1c, size: 0x13c
    // 0x1230f1c: EnterFrame
    //     0x1230f1c: stp             fp, lr, [SP, #-0x10]!
    //     0x1230f20: mov             fp, SP
    // 0x1230f24: AllocStack(0x20)
    //     0x1230f24: sub             SP, SP, #0x20
    // 0x1230f28: SetupParameters([dynamic _ /* r0 */])
    //     0x1230f28: ldr             x0, [fp, #0x18]
    //     0x1230f2c: ldur            w2, [x0, #0x17]
    //     0x1230f30: add             x2, x2, HEAP, lsl #32
    //     0x1230f34: stur            x2, [fp, #-8]
    // 0x1230f38: CheckStackOverflow
    //     0x1230f38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1230f3c: cmp             SP, x16
    //     0x1230f40: b.ls            #0x1231044
    // 0x1230f44: LoadField: r1 = r2->field_f
    //     0x1230f44: ldur            w1, [x2, #0xf]
    // 0x1230f48: DecompressPointer r1
    //     0x1230f48: add             x1, x1, HEAP, lsl #32
    // 0x1230f4c: r0 = showScrollbar()
    //     0x1230f4c: bl              #0x124a1d8  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::showScrollbar
    // 0x1230f50: tbnz            w0, #4, #0x1231030
    // 0x1230f54: ldur            x0, [fp, #-8]
    // 0x1230f58: LoadField: r1 = r0->field_f
    //     0x1230f58: ldur            w1, [x0, #0xf]
    // 0x1230f5c: DecompressPointer r1
    //     0x1230f5c: add             x1, x1, HEAP, lsl #32
    // 0x1230f60: stur            x1, [fp, #-0x10]
    // 0x1230f64: r1 = 1
    //     0x1230f64: mov             x1, #1
    // 0x1230f68: r0 = AllocateContext()
    //     0x1230f68: bl              #0x13de838  ; AllocateContextStub
    // 0x1230f6c: mov             x1, x0
    // 0x1230f70: ldur            x0, [fp, #-0x10]
    // 0x1230f74: StoreField: r1->field_f = r0
    //     0x1230f74: stur            w0, [x1, #0xf]
    // 0x1230f78: mov             x2, x1
    // 0x1230f7c: r1 = Function '<anonymous closure>':.
    //     0x1230f7c: add             x1, PP, #0xab, lsl #12  ; [pp+0xab380] AnonymousClosure: (0x1230d78), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_trackVisibility (0x1230d14)
    //     0x1230f80: ldr             x1, [x1, #0x380]
    // 0x1230f84: r0 = AllocateClosure()
    //     0x1230f84: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1230f88: r16 = <bool>
    //     0x1230f88: ldr             x16, [PP, #0x1918]  ; [pp+0x1918] TypeArguments: <bool>
    // 0x1230f8c: stp             x0, x16, [SP]
    // 0x1230f90: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1230f90: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1230f94: r0 = resolveWith()
    //     0x1230f94: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1230f98: mov             x1, x0
    // 0x1230f9c: ldr             x2, [fp, #0x10]
    // 0x1230fa0: r0 = build()
    //     0x1230fa0: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0x1230fa4: tbnz            w0, #4, #0x1231030
    // 0x1230fa8: ldur            x0, [fp, #-8]
    // 0x1230fac: LoadField: r1 = r0->field_f
    //     0x1230fac: ldur            w1, [x0, #0xf]
    // 0x1230fb0: DecompressPointer r1
    //     0x1230fb0: add             x1, x1, HEAP, lsl #32
    // 0x1230fb4: LoadField: r2 = r1->field_67
    //     0x1230fb4: ldur            w2, [x1, #0x67]
    // 0x1230fb8: DecompressPointer r2
    //     0x1230fb8: add             x2, x2, HEAP, lsl #32
    // 0x1230fbc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1230fc0: cmp             w2, w16
    // 0x1230fc4: b.eq            #0x123104c
    // 0x1230fc8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1230fc8: ldur            w1, [x0, #0x17]
    // 0x1230fcc: DecompressPointer r1
    //     0x1230fcc: add             x1, x1, HEAP, lsl #32
    // 0x1230fd0: LoadField: r2 = r1->field_7
    //     0x1230fd0: ldur            x2, [x1, #7]
    // 0x1230fd4: cmp             x2, #0
    // 0x1230fd8: b.gt            #0x1231000
    // 0x1230fdc: LoadField: r1 = r0->field_13
    //     0x1230fdc: ldur            w1, [x0, #0x13]
    // 0x1230fe0: DecompressPointer r1
    //     0x1230fe0: add             x1, x1, HEAP, lsl #32
    // 0x1230fe4: r0 = LoadClassIdInstr(r1)
    //     0x1230fe4: ldur            x0, [x1, #-1]
    //     0x1230fe8: ubfx            x0, x0, #0xc, #0x14
    // 0x1230fec: d0 = 0.250000
    //     0x1230fec: fmov            d0, #0.25000000
    // 0x1230ff0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1230ff0: sub             lr, x0, #1, lsl #12
    //     0x1230ff4: ldr             lr, [x21, lr, lsl #3]
    //     0x1230ff8: blr             lr
    // 0x1230ffc: b               #0x1231024
    // 0x1231000: LoadField: r1 = r0->field_13
    //     0x1231000: ldur            w1, [x0, #0x13]
    // 0x1231004: DecompressPointer r1
    //     0x1231004: add             x1, x1, HEAP, lsl #32
    // 0x1231008: r0 = LoadClassIdInstr(r1)
    //     0x1231008: ldur            x0, [x1, #-1]
    //     0x123100c: ubfx            x0, x0, #0xc, #0x14
    // 0x1231010: d0 = 0.100000
    //     0x1231010: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x1231014: ldr             d0, [x17, #0x1e0]
    // 0x1231018: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1231018: sub             lr, x0, #1, lsl #12
    //     0x123101c: ldr             lr, [x21, lr, lsl #3]
    //     0x1231020: blr             lr
    // 0x1231024: LeaveFrame
    //     0x1231024: mov             SP, fp
    //     0x1231028: ldp             fp, lr, [SP], #0x10
    // 0x123102c: ret
    //     0x123102c: ret             
    // 0x1231030: r0 = Instance_Color
    //     0x1231030: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1231034: ldr             x0, [x0, #0x810]
    // 0x1231038: LeaveFrame
    //     0x1231038: mov             SP, fp
    //     0x123103c: ldp             fp, lr, [SP], #0x10
    // 0x1231040: ret
    //     0x1231040: ret             
    // 0x1231044: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1231044: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1231048: b               #0x1230f44
    // 0x123104c: r9 = _scrollbarTheme
    //     0x123104c: add             x9, PP, #0xab, lsl #12  ; [pp+0xab368] Field <_MaterialScrollbarState@626083257._scrollbarTheme@626083257>: late (offset: 0x68)
    //     0x1231050: ldr             x9, [x9, #0x368]
    // 0x1231054: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1231054: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _trackColor(/* No info */) {
    // ** addr: 0x12310fc, size: 0xa0
    // 0x12310fc: EnterFrame
    //     0x12310fc: stp             fp, lr, [SP, #-0x10]!
    //     0x1231100: mov             fp, SP
    // 0x1231104: AllocStack(0x18)
    //     0x1231104: sub             SP, SP, #0x18
    // 0x1231108: SetupParameters(_MaterialScrollbarState this /* r1 => r1, fp-0x8 */)
    //     0x1231108: stur            x1, [fp, #-8]
    // 0x123110c: CheckStackOverflow
    //     0x123110c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1231110: cmp             SP, x16
    //     0x1231114: b.ls            #0x1231188
    // 0x1231118: r1 = 3
    //     0x1231118: mov             x1, #3
    // 0x123111c: r0 = AllocateContext()
    //     0x123111c: bl              #0x13de838  ; AllocateContextStub
    // 0x1231120: mov             x1, x0
    // 0x1231124: ldur            x0, [fp, #-8]
    // 0x1231128: StoreField: r1->field_f = r0
    //     0x1231128: stur            w0, [x1, #0xf]
    // 0x123112c: LoadField: r2 = r0->field_63
    //     0x123112c: ldur            w2, [x0, #0x63]
    // 0x1231130: DecompressPointer r2
    //     0x1231130: add             x2, x2, HEAP, lsl #32
    // 0x1231134: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1231138: cmp             w2, w16
    // 0x123113c: b.eq            #0x1231190
    // 0x1231140: LoadField: r0 = r2->field_7f
    //     0x1231140: ldur            w0, [x2, #0x7f]
    // 0x1231144: DecompressPointer r0
    //     0x1231144: add             x0, x0, HEAP, lsl #32
    // 0x1231148: StoreField: r1->field_13 = r0
    //     0x1231148: stur            w0, [x1, #0x13]
    // 0x123114c: LoadField: r0 = r2->field_7
    //     0x123114c: ldur            w0, [x2, #7]
    // 0x1231150: DecompressPointer r0
    //     0x1231150: add             x0, x0, HEAP, lsl #32
    // 0x1231154: ArrayStore: r1[0] = r0  ; List_4
    //     0x1231154: stur            w0, [x1, #0x17]
    // 0x1231158: mov             x2, x1
    // 0x123115c: r1 = Function '<anonymous closure>':.
    //     0x123115c: add             x1, PP, #0xab, lsl #12  ; [pp+0xab398] AnonymousClosure: (0x123119c), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_trackColor (0x12310fc)
    //     0x1231160: ldr             x1, [x1, #0x398]
    // 0x1231164: r0 = AllocateClosure()
    //     0x1231164: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1231168: r16 = <Color>
    //     0x1231168: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x123116c: ldr             x16, [x16, #0xa90]
    // 0x1231170: stp             x0, x16, [SP]
    // 0x1231174: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1231174: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1231178: r0 = resolveWith()
    //     0x1231178: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x123117c: LeaveFrame
    //     0x123117c: mov             SP, fp
    //     0x1231180: ldp             fp, lr, [SP], #0x10
    // 0x1231184: ret
    //     0x1231184: ret             
    // 0x1231188: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1231188: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x123118c: b               #0x1231118
    // 0x1231190: r9 = _colorScheme
    //     0x1231190: add             x9, PP, #0xab, lsl #12  ; [pp+0xab390] Field <_MaterialScrollbarState@626083257._colorScheme@626083257>: late (offset: 0x64)
    //     0x1231194: ldr             x9, [x9, #0x390]
    // 0x1231198: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1231198: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x123119c, size: 0x13c
    // 0x123119c: EnterFrame
    //     0x123119c: stp             fp, lr, [SP, #-0x10]!
    //     0x12311a0: mov             fp, SP
    // 0x12311a4: AllocStack(0x20)
    //     0x12311a4: sub             SP, SP, #0x20
    // 0x12311a8: SetupParameters([dynamic _ /* r0 */])
    //     0x12311a8: ldr             x0, [fp, #0x18]
    //     0x12311ac: ldur            w2, [x0, #0x17]
    //     0x12311b0: add             x2, x2, HEAP, lsl #32
    //     0x12311b4: stur            x2, [fp, #-8]
    // 0x12311b8: CheckStackOverflow
    //     0x12311b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12311bc: cmp             SP, x16
    //     0x12311c0: b.ls            #0x12312c4
    // 0x12311c4: LoadField: r1 = r2->field_f
    //     0x12311c4: ldur            w1, [x2, #0xf]
    // 0x12311c8: DecompressPointer r1
    //     0x12311c8: add             x1, x1, HEAP, lsl #32
    // 0x12311cc: r0 = showScrollbar()
    //     0x12311cc: bl              #0x124a1d8  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::showScrollbar
    // 0x12311d0: tbnz            w0, #4, #0x12312b0
    // 0x12311d4: ldur            x0, [fp, #-8]
    // 0x12311d8: LoadField: r1 = r0->field_f
    //     0x12311d8: ldur            w1, [x0, #0xf]
    // 0x12311dc: DecompressPointer r1
    //     0x12311dc: add             x1, x1, HEAP, lsl #32
    // 0x12311e0: stur            x1, [fp, #-0x10]
    // 0x12311e4: r1 = 1
    //     0x12311e4: mov             x1, #1
    // 0x12311e8: r0 = AllocateContext()
    //     0x12311e8: bl              #0x13de838  ; AllocateContextStub
    // 0x12311ec: mov             x1, x0
    // 0x12311f0: ldur            x0, [fp, #-0x10]
    // 0x12311f4: StoreField: r1->field_f = r0
    //     0x12311f4: stur            w0, [x1, #0xf]
    // 0x12311f8: mov             x2, x1
    // 0x12311fc: r1 = Function '<anonymous closure>':.
    //     0x12311fc: add             x1, PP, #0xab, lsl #12  ; [pp+0xab380] AnonymousClosure: (0x1230d78), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_trackVisibility (0x1230d14)
    //     0x1231200: ldr             x1, [x1, #0x380]
    // 0x1231204: r0 = AllocateClosure()
    //     0x1231204: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1231208: r16 = <bool>
    //     0x1231208: ldr             x16, [PP, #0x1918]  ; [pp+0x1918] TypeArguments: <bool>
    // 0x123120c: stp             x0, x16, [SP]
    // 0x1231210: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1231210: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1231214: r0 = resolveWith()
    //     0x1231214: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1231218: mov             x1, x0
    // 0x123121c: ldr             x2, [fp, #0x10]
    // 0x1231220: r0 = build()
    //     0x1231220: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0x1231224: tbnz            w0, #4, #0x12312b0
    // 0x1231228: ldur            x0, [fp, #-8]
    // 0x123122c: LoadField: r1 = r0->field_f
    //     0x123122c: ldur            w1, [x0, #0xf]
    // 0x1231230: DecompressPointer r1
    //     0x1231230: add             x1, x1, HEAP, lsl #32
    // 0x1231234: LoadField: r2 = r1->field_67
    //     0x1231234: ldur            w2, [x1, #0x67]
    // 0x1231238: DecompressPointer r2
    //     0x1231238: add             x2, x2, HEAP, lsl #32
    // 0x123123c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1231240: cmp             w2, w16
    // 0x1231244: b.eq            #0x12312cc
    // 0x1231248: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1231248: ldur            w1, [x0, #0x17]
    // 0x123124c: DecompressPointer r1
    //     0x123124c: add             x1, x1, HEAP, lsl #32
    // 0x1231250: LoadField: r2 = r1->field_7
    //     0x1231250: ldur            x2, [x1, #7]
    // 0x1231254: cmp             x2, #0
    // 0x1231258: b.gt            #0x1231280
    // 0x123125c: LoadField: r1 = r0->field_13
    //     0x123125c: ldur            w1, [x0, #0x13]
    // 0x1231260: DecompressPointer r1
    //     0x1231260: add             x1, x1, HEAP, lsl #32
    // 0x1231264: r0 = LoadClassIdInstr(r1)
    //     0x1231264: ldur            x0, [x1, #-1]
    //     0x1231268: ubfx            x0, x0, #0xc, #0x14
    // 0x123126c: d0 = 0.050000
    //     0x123126c: ldr             d0, [PP, #0x57a0]  ; [pp+0x57a0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x1231270: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1231270: sub             lr, x0, #1, lsl #12
    //     0x1231274: ldr             lr, [x21, lr, lsl #3]
    //     0x1231278: blr             lr
    // 0x123127c: b               #0x12312a4
    // 0x1231280: LoadField: r1 = r0->field_13
    //     0x1231280: ldur            w1, [x0, #0x13]
    // 0x1231284: DecompressPointer r1
    //     0x1231284: add             x1, x1, HEAP, lsl #32
    // 0x1231288: r0 = LoadClassIdInstr(r1)
    //     0x1231288: ldur            x0, [x1, #-1]
    //     0x123128c: ubfx            x0, x0, #0xc, #0x14
    // 0x1231290: d0 = 0.030000
    //     0x1231290: add             x17, PP, #0xab, lsl #12  ; [pp+0xab3a0] IMM: double(0.03) from 0x3f9eb851eb851eb8
    //     0x1231294: ldr             d0, [x17, #0x3a0]
    // 0x1231298: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1231298: sub             lr, x0, #1, lsl #12
    //     0x123129c: ldr             lr, [x21, lr, lsl #3]
    //     0x12312a0: blr             lr
    // 0x12312a4: LeaveFrame
    //     0x12312a4: mov             SP, fp
    //     0x12312a8: ldp             fp, lr, [SP], #0x10
    // 0x12312ac: ret
    //     0x12312ac: ret             
    // 0x12312b0: r0 = Instance_Color
    //     0x12312b0: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x12312b4: ldr             x0, [x0, #0x810]
    // 0x12312b8: LeaveFrame
    //     0x12312b8: mov             SP, fp
    //     0x12312bc: ldp             fp, lr, [SP], #0x10
    // 0x12312c0: ret
    //     0x12312c0: ret             
    // 0x12312c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12312c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12312c8: b               #0x12311c4
    // 0x12312cc: r9 = _scrollbarTheme
    //     0x12312cc: add             x9, PP, #0xab, lsl #12  ; [pp+0xab368] Field <_MaterialScrollbarState@626083257._scrollbarTheme@626083257>: late (offset: 0x68)
    //     0x12312d0: ldr             x9, [x9, #0x368]
    // 0x12312d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12312d4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _states(/* No info */) {
    // ** addr: 0x12312d8, size: 0xa8
    // 0x12312d8: EnterFrame
    //     0x12312d8: stp             fp, lr, [SP, #-0x10]!
    //     0x12312dc: mov             fp, SP
    // 0x12312e0: AllocStack(0x10)
    //     0x12312e0: sub             SP, SP, #0x10
    // 0x12312e4: SetupParameters(_MaterialScrollbarState this /* r1 => r0, fp-0x8 */)
    //     0x12312e4: mov             x0, x1
    //     0x12312e8: stur            x1, [fp, #-8]
    // 0x12312ec: CheckStackOverflow
    //     0x12312ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12312f0: cmp             SP, x16
    //     0x12312f4: b.ls            #0x1231378
    // 0x12312f8: r1 = <WidgetState>
    //     0x12312f8: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a10] TypeArguments: <WidgetState>
    //     0x12312fc: ldr             x1, [x1, #0xa10]
    // 0x1231300: r0 = _Set()
    //     0x1231300: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x1231304: mov             x3, x0
    // 0x1231308: r0 = _Uint32List
    //     0x1231308: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x123130c: stur            x3, [fp, #-0x10]
    // 0x1231310: StoreField: r3->field_1b = r0
    //     0x1231310: stur            w0, [x3, #0x1b]
    // 0x1231314: StoreField: r3->field_b = rZR
    //     0x1231314: stur            wzr, [x3, #0xb]
    // 0x1231318: r0 = const []
    //     0x1231318: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x123131c: StoreField: r3->field_f = r0
    //     0x123131c: stur            w0, [x3, #0xf]
    // 0x1231320: StoreField: r3->field_13 = rZR
    //     0x1231320: stur            wzr, [x3, #0x13]
    // 0x1231324: ArrayStore: r3[0] = rZR  ; List_4
    //     0x1231324: stur            wzr, [x3, #0x17]
    // 0x1231328: ldur            x0, [fp, #-8]
    // 0x123132c: LoadField: r1 = r0->field_5b
    //     0x123132c: ldur            w1, [x0, #0x5b]
    // 0x1231330: DecompressPointer r1
    //     0x1231330: add             x1, x1, HEAP, lsl #32
    // 0x1231334: tbnz            w1, #4, #0x1231348
    // 0x1231338: mov             x1, x3
    // 0x123133c: r2 = Instance_WidgetState
    //     0x123133c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ad0] Obj!WidgetState@12c87a1
    //     0x1231340: ldr             x2, [x2, #0xad0]
    // 0x1231344: r0 = add()
    //     0x1231344: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x1231348: ldur            x0, [fp, #-8]
    // 0x123134c: LoadField: r1 = r0->field_5f
    //     0x123134c: ldur            w1, [x0, #0x5f]
    // 0x1231350: DecompressPointer r1
    //     0x1231350: add             x1, x1, HEAP, lsl #32
    // 0x1231354: tbnz            w1, #4, #0x1231368
    // 0x1231358: ldur            x1, [fp, #-0x10]
    // 0x123135c: r2 = Instance_WidgetState
    //     0x123135c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0x1231360: ldr             x2, [x2, #0xa50]
    // 0x1231364: r0 = add()
    //     0x1231364: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x1231368: ldur            x0, [fp, #-0x10]
    // 0x123136c: LeaveFrame
    //     0x123136c: mov             SP, fp
    //     0x1231370: ldp             fp, lr, [SP], #0x10
    // 0x1231374: ret
    //     0x1231374: ret             
    // 0x1231378: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1231378: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x123137c: b               #0x12312f8
  }
  get _ _thumbColor(/* No info */) {
    // ** addr: 0x1231380, size: 0x304
    // 0x1231380: EnterFrame
    //     0x1231380: stp             fp, lr, [SP, #-0x10]!
    //     0x1231384: mov             fp, SP
    // 0x1231388: AllocStack(0x28)
    //     0x1231388: sub             SP, SP, #0x28
    // 0x123138c: SetupParameters(_MaterialScrollbarState this /* r1 => r1, fp-0x8 */)
    //     0x123138c: stur            x1, [fp, #-8]
    // 0x1231390: CheckStackOverflow
    //     0x1231390: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1231394: cmp             SP, x16
    //     0x1231398: b.ls            #0x1231650
    // 0x123139c: r1 = 4
    //     0x123139c: mov             x1, #4
    // 0x12313a0: r0 = AllocateContext()
    //     0x12313a0: bl              #0x13de838  ; AllocateContextStub
    // 0x12313a4: mov             x3, x0
    // 0x12313a8: ldur            x2, [fp, #-8]
    // 0x12313ac: stur            x3, [fp, #-0x18]
    // 0x12313b0: StoreField: r3->field_f = r2
    //     0x12313b0: stur            w2, [x3, #0xf]
    // 0x12313b4: LoadField: r0 = r2->field_63
    //     0x12313b4: ldur            w0, [x2, #0x63]
    // 0x12313b8: DecompressPointer r0
    //     0x12313b8: add             x0, x0, HEAP, lsl #32
    // 0x12313bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12313c0: cmp             w0, w16
    // 0x12313c4: b.eq            #0x1231658
    // 0x12313c8: LoadField: r4 = r0->field_7f
    //     0x12313c8: ldur            w4, [x0, #0x7f]
    // 0x12313cc: DecompressPointer r4
    //     0x12313cc: add             x4, x4, HEAP, lsl #32
    // 0x12313d0: stur            x4, [fp, #-0x10]
    // 0x12313d4: LoadField: r1 = r0->field_7
    //     0x12313d4: ldur            w1, [x0, #7]
    // 0x12313d8: DecompressPointer r1
    //     0x12313d8: add             x1, x1, HEAP, lsl #32
    // 0x12313dc: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x12313e0: StoreField: r3->field_13 = r0
    //     0x12313e0: stur            w0, [x3, #0x13]
    // 0x12313e4: ArrayStore: r3[0] = r0  ; List_4
    //     0x12313e4: stur            w0, [x3, #0x17]
    // 0x12313e8: StoreField: r3->field_1b = r0
    //     0x12313e8: stur            w0, [x3, #0x1b]
    // 0x12313ec: LoadField: r0 = r1->field_7
    //     0x12313ec: ldur            x0, [x1, #7]
    // 0x12313f0: cmp             x0, #0
    // 0x12313f4: b.gt            #0x1231508
    // 0x12313f8: r0 = LoadClassIdInstr(r4)
    //     0x12313f8: ldur            x0, [x4, #-1]
    //     0x12313fc: ubfx            x0, x0, #0xc, #0x14
    // 0x1231400: mov             x1, x4
    // 0x1231404: d0 = 0.750000
    //     0x1231404: fmov            d0, #0.75000000
    // 0x1231408: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1231408: sub             lr, x0, #1, lsl #12
    //     0x123140c: ldr             lr, [x21, lr, lsl #3]
    //     0x1231410: blr             lr
    // 0x1231414: ldur            x2, [fp, #-0x18]
    // 0x1231418: StoreField: r2->field_13 = r0
    //     0x1231418: stur            w0, [x2, #0x13]
    //     0x123141c: ldurb           w16, [x2, #-1]
    //     0x1231420: ldurb           w17, [x0, #-1]
    //     0x1231424: and             x16, x17, x16, lsr #2
    //     0x1231428: tst             x16, HEAP, lsr #32
    //     0x123142c: b.eq            #0x1231434
    //     0x1231430: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x1231434: ldur            x3, [fp, #-0x10]
    // 0x1231438: r0 = LoadClassIdInstr(r3)
    //     0x1231438: ldur            x0, [x3, #-1]
    //     0x123143c: ubfx            x0, x0, #0xc, #0x14
    // 0x1231440: mov             x1, x3
    // 0x1231444: d0 = 0.650000
    //     0x1231444: add             x17, PP, #0x9c, lsl #12  ; [pp+0x9cf68] IMM: double(0.65) from 0x3fe4cccccccccccd
    //     0x1231448: ldr             d0, [x17, #0xf68]
    // 0x123144c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x123144c: sub             lr, x0, #1, lsl #12
    //     0x1231450: ldr             lr, [x21, lr, lsl #3]
    //     0x1231454: blr             lr
    // 0x1231458: ldur            x2, [fp, #-0x18]
    // 0x123145c: ArrayStore: r2[0] = r0  ; List_4
    //     0x123145c: stur            w0, [x2, #0x17]
    //     0x1231460: ldurb           w16, [x2, #-1]
    //     0x1231464: ldurb           w17, [x0, #-1]
    //     0x1231468: and             x16, x17, x16, lsr #2
    //     0x123146c: tst             x16, HEAP, lsr #32
    //     0x1231470: b.eq            #0x1231478
    //     0x1231474: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x1231478: ldur            x3, [fp, #-8]
    // 0x123147c: LoadField: r0 = r3->field_6b
    //     0x123147c: ldur            w0, [x3, #0x6b]
    // 0x1231480: DecompressPointer r0
    //     0x1231480: add             x0, x0, HEAP, lsl #32
    // 0x1231484: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1231488: cmp             w0, w16
    // 0x123148c: b.eq            #0x1231664
    // 0x1231490: tbnz            w0, #4, #0x12314bc
    // 0x1231494: LoadField: r1 = r3->field_f
    //     0x1231494: ldur            w1, [x3, #0xf]
    // 0x1231498: DecompressPointer r1
    //     0x1231498: add             x1, x1, HEAP, lsl #32
    // 0x123149c: cmp             w1, NULL
    // 0x12314a0: b.eq            #0x1231670
    // 0x12314a4: r0 = of()
    //     0x12314a4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x12314a8: LoadField: r1 = r0->field_4f
    //     0x12314a8: ldur            w1, [x0, #0x4f]
    // 0x12314ac: DecompressPointer r1
    //     0x12314ac: add             x1, x1, HEAP, lsl #32
    // 0x12314b0: d0 = 1.000000
    //     0x12314b0: fmov            d0, #1.00000000
    // 0x12314b4: r0 = withOpacity()
    //     0x12314b4: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x12314b8: b               #0x12314e0
    // 0x12314bc: ldur            x2, [fp, #-0x10]
    // 0x12314c0: r0 = LoadClassIdInstr(r2)
    //     0x12314c0: ldur            x0, [x2, #-1]
    //     0x12314c4: ubfx            x0, x0, #0xc, #0x14
    // 0x12314c8: mov             x1, x2
    // 0x12314cc: d0 = 0.300000
    //     0x12314cc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a88] IMM: double(0.3) from 0x3fd3333333333333
    //     0x12314d0: ldr             d0, [x17, #0xa88]
    // 0x12314d4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12314d4: sub             lr, x0, #1, lsl #12
    //     0x12314d8: ldr             lr, [x21, lr, lsl #3]
    //     0x12314dc: blr             lr
    // 0x12314e0: ldur            x4, [fp, #-0x18]
    // 0x12314e4: StoreField: r4->field_1b = r0
    //     0x12314e4: stur            w0, [x4, #0x1b]
    //     0x12314e8: ldurb           w16, [x4, #-1]
    //     0x12314ec: ldurb           w17, [x0, #-1]
    //     0x12314f0: and             x16, x17, x16, lsr #2
    //     0x12314f4: tst             x16, HEAP, lsr #32
    //     0x12314f8: b.eq            #0x1231500
    //     0x12314fc: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x1231500: mov             x2, x4
    // 0x1231504: b               #0x1231624
    // 0x1231508: mov             x16, x4
    // 0x123150c: mov             x4, x2
    // 0x1231510: mov             x2, x16
    // 0x1231514: mov             x16, x3
    // 0x1231518: mov             x3, x4
    // 0x123151c: mov             x4, x16
    // 0x1231520: r0 = LoadClassIdInstr(r2)
    //     0x1231520: ldur            x0, [x2, #-1]
    //     0x1231524: ubfx            x0, x0, #0xc, #0x14
    // 0x1231528: mov             x1, x2
    // 0x123152c: d0 = 0.600000
    //     0x123152c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0x1231530: ldr             d0, [x17, #0xc88]
    // 0x1231534: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1231534: sub             lr, x0, #1, lsl #12
    //     0x1231538: ldr             lr, [x21, lr, lsl #3]
    //     0x123153c: blr             lr
    // 0x1231540: ldur            x2, [fp, #-0x18]
    // 0x1231544: StoreField: r2->field_13 = r0
    //     0x1231544: stur            w0, [x2, #0x13]
    //     0x1231548: ldurb           w16, [x2, #-1]
    //     0x123154c: ldurb           w17, [x0, #-1]
    //     0x1231550: and             x16, x17, x16, lsr #2
    //     0x1231554: tst             x16, HEAP, lsr #32
    //     0x1231558: b.eq            #0x1231560
    //     0x123155c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x1231560: ldur            x3, [fp, #-0x10]
    // 0x1231564: r0 = LoadClassIdInstr(r3)
    //     0x1231564: ldur            x0, [x3, #-1]
    //     0x1231568: ubfx            x0, x0, #0xc, #0x14
    // 0x123156c: mov             x1, x3
    // 0x1231570: d0 = 0.500000
    //     0x1231570: fmov            d0, #0.50000000
    // 0x1231574: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1231574: sub             lr, x0, #1, lsl #12
    //     0x1231578: ldr             lr, [x21, lr, lsl #3]
    //     0x123157c: blr             lr
    // 0x1231580: ldur            x2, [fp, #-0x18]
    // 0x1231584: ArrayStore: r2[0] = r0  ; List_4
    //     0x1231584: stur            w0, [x2, #0x17]
    //     0x1231588: ldurb           w16, [x2, #-1]
    //     0x123158c: ldurb           w17, [x0, #-1]
    //     0x1231590: and             x16, x17, x16, lsr #2
    //     0x1231594: tst             x16, HEAP, lsr #32
    //     0x1231598: b.eq            #0x12315a0
    //     0x123159c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x12315a0: ldur            x0, [fp, #-8]
    // 0x12315a4: LoadField: r1 = r0->field_6b
    //     0x12315a4: ldur            w1, [x0, #0x6b]
    // 0x12315a8: DecompressPointer r1
    //     0x12315a8: add             x1, x1, HEAP, lsl #32
    // 0x12315ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12315b0: cmp             w1, w16
    // 0x12315b4: b.eq            #0x1231674
    // 0x12315b8: tbnz            w1, #4, #0x12315e4
    // 0x12315bc: LoadField: r1 = r0->field_f
    //     0x12315bc: ldur            w1, [x0, #0xf]
    // 0x12315c0: DecompressPointer r1
    //     0x12315c0: add             x1, x1, HEAP, lsl #32
    // 0x12315c4: cmp             w1, NULL
    // 0x12315c8: b.eq            #0x1231680
    // 0x12315cc: r0 = of()
    //     0x12315cc: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x12315d0: LoadField: r1 = r0->field_4f
    //     0x12315d0: ldur            w1, [x0, #0x4f]
    // 0x12315d4: DecompressPointer r1
    //     0x12315d4: add             x1, x1, HEAP, lsl #32
    // 0x12315d8: d0 = 1.000000
    //     0x12315d8: fmov            d0, #1.00000000
    // 0x12315dc: r0 = withOpacity()
    //     0x12315dc: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x12315e0: b               #0x1231604
    // 0x12315e4: ldur            x1, [fp, #-0x10]
    // 0x12315e8: r0 = LoadClassIdInstr(r1)
    //     0x12315e8: ldur            x0, [x1, #-1]
    //     0x12315ec: ubfx            x0, x0, #0xc, #0x14
    // 0x12315f0: d0 = 0.100000
    //     0x12315f0: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x12315f4: ldr             d0, [x17, #0x1e0]
    // 0x12315f8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12315f8: sub             lr, x0, #1, lsl #12
    //     0x12315fc: ldr             lr, [x21, lr, lsl #3]
    //     0x1231600: blr             lr
    // 0x1231604: ldur            x2, [fp, #-0x18]
    // 0x1231608: StoreField: r2->field_1b = r0
    //     0x1231608: stur            w0, [x2, #0x1b]
    //     0x123160c: ldurb           w16, [x2, #-1]
    //     0x1231610: ldurb           w17, [x0, #-1]
    //     0x1231614: and             x16, x17, x16, lsr #2
    //     0x1231618: tst             x16, HEAP, lsr #32
    //     0x123161c: b.eq            #0x1231624
    //     0x1231620: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x1231624: r1 = Function '<anonymous closure>':.
    //     0x1231624: add             x1, PP, #0xab, lsl #12  ; [pp+0xab3a8] AnonymousClosure: (0x1231684), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_thumbColor (0x1231380)
    //     0x1231628: ldr             x1, [x1, #0x3a8]
    // 0x123162c: r0 = AllocateClosure()
    //     0x123162c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1231630: r16 = <Color>
    //     0x1231630: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1231634: ldr             x16, [x16, #0xa90]
    // 0x1231638: stp             x0, x16, [SP]
    // 0x123163c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x123163c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1231640: r0 = resolveWith()
    //     0x1231640: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1231644: LeaveFrame
    //     0x1231644: mov             SP, fp
    //     0x1231648: ldp             fp, lr, [SP], #0x10
    // 0x123164c: ret
    //     0x123164c: ret             
    // 0x1231650: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1231650: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1231654: b               #0x123139c
    // 0x1231658: r9 = _colorScheme
    //     0x1231658: add             x9, PP, #0xab, lsl #12  ; [pp+0xab390] Field <_MaterialScrollbarState@626083257._colorScheme@626083257>: late (offset: 0x64)
    //     0x123165c: ldr             x9, [x9, #0x390]
    // 0x1231660: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1231660: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x1231664: r9 = _useAndroidScrollbar
    //     0x1231664: add             x9, PP, #0xab, lsl #12  ; [pp+0xab370] Field <_MaterialScrollbarState@626083257._useAndroidScrollbar@626083257>: late (offset: 0x6c)
    //     0x1231668: ldr             x9, [x9, #0x370]
    // 0x123166c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x123166c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x1231670: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1231670: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1231674: r9 = _useAndroidScrollbar
    //     0x1231674: add             x9, PP, #0xab, lsl #12  ; [pp+0xab370] Field <_MaterialScrollbarState@626083257._useAndroidScrollbar@626083257>: late (offset: 0x6c)
    //     0x1231678: ldr             x9, [x9, #0x370]
    // 0x123167c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x123167c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x1231680: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1231680: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x1231684, size: 0x25c
    // 0x1231684: EnterFrame
    //     0x1231684: stp             fp, lr, [SP, #-0x10]!
    //     0x1231688: mov             fp, SP
    // 0x123168c: AllocStack(0x20)
    //     0x123168c: sub             SP, SP, #0x20
    // 0x1231690: SetupParameters([dynamic _ /* r0 */])
    //     0x1231690: ldr             x0, [fp, #0x18]
    //     0x1231694: ldur            w3, [x0, #0x17]
    //     0x1231698: add             x3, x3, HEAP, lsl #32
    //     0x123169c: stur            x3, [fp, #-8]
    // 0x12316a0: CheckStackOverflow
    //     0x12316a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12316a4: cmp             SP, x16
    //     0x12316a8: b.ls            #0x12318a0
    // 0x12316ac: ldr             x4, [fp, #0x10]
    // 0x12316b0: r0 = LoadClassIdInstr(r4)
    //     0x12316b0: ldur            x0, [x4, #-1]
    //     0x12316b4: ubfx            x0, x0, #0xc, #0x14
    // 0x12316b8: mov             x1, x4
    // 0x12316bc: r2 = Instance_WidgetState
    //     0x12316bc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ad0] Obj!WidgetState@12c87a1
    //     0x12316c0: ldr             x2, [x2, #0xad0]
    // 0x12316c4: r0 = GDT[cid_x0 + 0x12929]()
    //     0x12316c4: mov             x17, #0x2929
    //     0x12316c8: movk            x17, #1, lsl #16
    //     0x12316cc: add             lr, x0, x17
    //     0x12316d0: ldr             lr, [x21, lr, lsl #3]
    //     0x12316d4: blr             lr
    // 0x12316d8: tbnz            w0, #4, #0x1231720
    // 0x12316dc: ldur            x0, [fp, #-8]
    // 0x12316e0: LoadField: r1 = r0->field_f
    //     0x12316e0: ldur            w1, [x0, #0xf]
    // 0x12316e4: DecompressPointer r1
    //     0x12316e4: add             x1, x1, HEAP, lsl #32
    // 0x12316e8: LoadField: r2 = r1->field_67
    //     0x12316e8: ldur            w2, [x1, #0x67]
    // 0x12316ec: DecompressPointer r2
    //     0x12316ec: add             x2, x2, HEAP, lsl #32
    // 0x12316f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12316f4: cmp             w2, w16
    // 0x12316f8: b.eq            #0x12318a8
    // 0x12316fc: LoadField: r1 = r0->field_13
    //     0x12316fc: ldur            w1, [x0, #0x13]
    // 0x1231700: DecompressPointer r1
    //     0x1231700: add             x1, x1, HEAP, lsl #32
    // 0x1231704: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1231708: cmp             w1, w16
    // 0x123170c: b.eq            #0x1231850
    // 0x1231710: mov             x0, x1
    // 0x1231714: LeaveFrame
    //     0x1231714: mov             SP, fp
    //     0x1231718: ldp             fp, lr, [SP], #0x10
    // 0x123171c: ret
    //     0x123171c: ret             
    // 0x1231720: ldur            x0, [fp, #-8]
    // 0x1231724: LoadField: r1 = r0->field_f
    //     0x1231724: ldur            w1, [x0, #0xf]
    // 0x1231728: DecompressPointer r1
    //     0x1231728: add             x1, x1, HEAP, lsl #32
    // 0x123172c: stur            x1, [fp, #-0x10]
    // 0x1231730: r1 = 1
    //     0x1231730: mov             x1, #1
    // 0x1231734: r0 = AllocateContext()
    //     0x1231734: bl              #0x13de838  ; AllocateContextStub
    // 0x1231738: mov             x1, x0
    // 0x123173c: ldur            x0, [fp, #-0x10]
    // 0x1231740: StoreField: r1->field_f = r0
    //     0x1231740: stur            w0, [x1, #0xf]
    // 0x1231744: mov             x2, x1
    // 0x1231748: r1 = Function '<anonymous closure>':.
    //     0x1231748: add             x1, PP, #0xab, lsl #12  ; [pp+0xab380] AnonymousClosure: (0x1230d78), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_trackVisibility (0x1230d14)
    //     0x123174c: ldr             x1, [x1, #0x380]
    // 0x1231750: r0 = AllocateClosure()
    //     0x1231750: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1231754: r16 = <bool>
    //     0x1231754: ldr             x16, [PP, #0x1918]  ; [pp+0x1918] TypeArguments: <bool>
    // 0x1231758: stp             x0, x16, [SP]
    // 0x123175c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x123175c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1231760: r0 = resolveWith()
    //     0x1231760: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1231764: mov             x1, x0
    // 0x1231768: ldr             x2, [fp, #0x10]
    // 0x123176c: r0 = build()
    //     0x123176c: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0x1231770: tbnz            w0, #4, #0x12317b8
    // 0x1231774: ldur            x0, [fp, #-8]
    // 0x1231778: LoadField: r1 = r0->field_f
    //     0x1231778: ldur            w1, [x0, #0xf]
    // 0x123177c: DecompressPointer r1
    //     0x123177c: add             x1, x1, HEAP, lsl #32
    // 0x1231780: LoadField: r2 = r1->field_67
    //     0x1231780: ldur            w2, [x1, #0x67]
    // 0x1231784: DecompressPointer r2
    //     0x1231784: add             x2, x2, HEAP, lsl #32
    // 0x1231788: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x123178c: cmp             w2, w16
    // 0x1231790: b.eq            #0x12318b4
    // 0x1231794: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1231794: ldur            w1, [x0, #0x17]
    // 0x1231798: DecompressPointer r1
    //     0x1231798: add             x1, x1, HEAP, lsl #32
    // 0x123179c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12317a0: cmp             w1, w16
    // 0x12317a4: b.eq            #0x1231864
    // 0x12317a8: mov             x0, x1
    // 0x12317ac: LeaveFrame
    //     0x12317ac: mov             SP, fp
    //     0x12317b0: ldp             fp, lr, [SP], #0x10
    // 0x12317b4: ret
    //     0x12317b4: ret             
    // 0x12317b8: ldur            x0, [fp, #-8]
    // 0x12317bc: LoadField: r1 = r0->field_f
    //     0x12317bc: ldur            w1, [x0, #0xf]
    // 0x12317c0: DecompressPointer r1
    //     0x12317c0: add             x1, x1, HEAP, lsl #32
    // 0x12317c4: LoadField: r2 = r1->field_67
    //     0x12317c4: ldur            w2, [x1, #0x67]
    // 0x12317c8: DecompressPointer r2
    //     0x12317c8: add             x2, x2, HEAP, lsl #32
    // 0x12317cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12317d0: cmp             w2, w16
    // 0x12317d4: b.eq            #0x12318c0
    // 0x12317d8: LoadField: r2 = r0->field_1b
    //     0x12317d8: ldur            w2, [x0, #0x1b]
    // 0x12317dc: DecompressPointer r2
    //     0x12317dc: add             x2, x2, HEAP, lsl #32
    // 0x12317e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12317e4: cmp             w2, w16
    // 0x12317e8: b.eq            #0x1231878
    // 0x12317ec: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x12317ec: ldur            w3, [x0, #0x17]
    // 0x12317f0: DecompressPointer r3
    //     0x12317f0: add             x3, x3, HEAP, lsl #32
    // 0x12317f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12317f8: cmp             w3, w16
    // 0x12317fc: b.eq            #0x123188c
    // 0x1231800: LoadField: r0 = r1->field_57
    //     0x1231800: ldur            w0, [x1, #0x57]
    // 0x1231804: DecompressPointer r0
    //     0x1231804: add             x0, x0, HEAP, lsl #32
    // 0x1231808: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x123180c: cmp             w0, w16
    // 0x1231810: b.eq            #0x12318cc
    // 0x1231814: LoadField: r1 = r0->field_37
    //     0x1231814: ldur            w1, [x0, #0x37]
    // 0x1231818: DecompressPointer r1
    //     0x1231818: add             x1, x1, HEAP, lsl #32
    // 0x123181c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1231820: cmp             w1, w16
    // 0x1231824: b.eq            #0x12318d8
    // 0x1231828: mov             x16, x3
    // 0x123182c: mov             x3, x2
    // 0x1231830: mov             x2, x16
    // 0x1231834: mov             x16, x1
    // 0x1231838: mov             x1, x3
    // 0x123183c: mov             x3, x16
    // 0x1231840: r0 = lerp()
    //     0x1231840: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1231844: LeaveFrame
    //     0x1231844: mov             SP, fp
    //     0x1231848: ldp             fp, lr, [SP], #0x10
    // 0x123184c: ret
    //     0x123184c: ret             
    // 0x1231850: r16 = "dragColor"
    //     0x1231850: add             x16, PP, #0xab, lsl #12  ; [pp+0xab3b0] "dragColor"
    //     0x1231854: ldr             x16, [x16, #0x3b0]
    // 0x1231858: str             x16, [SP]
    // 0x123185c: r0 = _throwLocalNotInitialized()
    //     0x123185c: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x1231860: brk             #0
    // 0x1231864: r16 = "hoverColor"
    //     0x1231864: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a88] "hoverColor"
    //     0x1231868: ldr             x16, [x16, #0xa88]
    // 0x123186c: str             x16, [SP]
    // 0x1231870: r0 = _throwLocalNotInitialized()
    //     0x1231870: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x1231874: brk             #0
    // 0x1231878: r16 = "idleColor"
    //     0x1231878: add             x16, PP, #0xab, lsl #12  ; [pp+0xab3b8] "idleColor"
    //     0x123187c: ldr             x16, [x16, #0x3b8]
    // 0x1231880: str             x16, [SP]
    // 0x1231884: r0 = _throwLocalNotInitialized()
    //     0x1231884: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x1231888: brk             #0
    // 0x123188c: r16 = "hoverColor"
    //     0x123188c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a88] "hoverColor"
    //     0x1231890: ldr             x16, [x16, #0xa88]
    // 0x1231894: str             x16, [SP]
    // 0x1231898: r0 = _throwLocalNotInitialized()
    //     0x1231898: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x123189c: brk             #0
    // 0x12318a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12318a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12318a4: b               #0x12316ac
    // 0x12318a8: r9 = _scrollbarTheme
    //     0x12318a8: add             x9, PP, #0xab, lsl #12  ; [pp+0xab368] Field <_MaterialScrollbarState@626083257._scrollbarTheme@626083257>: late (offset: 0x68)
    //     0x12318ac: ldr             x9, [x9, #0x368]
    // 0x12318b0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12318b0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12318b4: r9 = _scrollbarTheme
    //     0x12318b4: add             x9, PP, #0xab, lsl #12  ; [pp+0xab368] Field <_MaterialScrollbarState@626083257._scrollbarTheme@626083257>: late (offset: 0x68)
    //     0x12318b8: ldr             x9, [x9, #0x368]
    // 0x12318bc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12318bc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12318c0: r9 = _scrollbarTheme
    //     0x12318c0: add             x9, PP, #0xab, lsl #12  ; [pp+0xab368] Field <_MaterialScrollbarState@626083257._scrollbarTheme@626083257>: late (offset: 0x68)
    //     0x12318c4: ldr             x9, [x9, #0x368]
    // 0x12318c8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12318c8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12318cc: r9 = _hoverAnimationController
    //     0x12318cc: add             x9, PP, #0xab, lsl #12  ; [pp+0xab348] Field <_MaterialScrollbarState@626083257._hoverAnimationController@626083257>: late (offset: 0x58)
    //     0x12318d0: ldr             x9, [x9, #0x348]
    // 0x12318d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12318d4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12318d8: r9 = _value
    //     0x12318d8: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0x12318dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12318dc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ handleThumbPressStart(/* No info */) {
    // ** addr: 0x1231cf4, size: 0x78
    // 0x1231cf4: EnterFrame
    //     0x1231cf4: stp             fp, lr, [SP, #-0x10]!
    //     0x1231cf8: mov             fp, SP
    // 0x1231cfc: AllocStack(0x18)
    //     0x1231cfc: sub             SP, SP, #0x18
    // 0x1231d00: SetupParameters(_MaterialScrollbarState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x1231d00: stur            x1, [fp, #-8]
    //     0x1231d04: stur            x2, [fp, #-0x10]
    // 0x1231d08: CheckStackOverflow
    //     0x1231d08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1231d0c: cmp             SP, x16
    //     0x1231d10: b.ls            #0x1231d64
    // 0x1231d14: r1 = 1
    //     0x1231d14: mov             x1, #1
    // 0x1231d18: r0 = AllocateContext()
    //     0x1231d18: bl              #0x13de838  ; AllocateContextStub
    // 0x1231d1c: mov             x3, x0
    // 0x1231d20: ldur            x0, [fp, #-8]
    // 0x1231d24: stur            x3, [fp, #-0x18]
    // 0x1231d28: StoreField: r3->field_f = r0
    //     0x1231d28: stur            w0, [x3, #0xf]
    // 0x1231d2c: mov             x1, x0
    // 0x1231d30: ldur            x2, [fp, #-0x10]
    // 0x1231d34: r0 = handleThumbPressStart()
    //     0x1231d34: bl              #0x1231d6c  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::handleThumbPressStart
    // 0x1231d38: ldur            x2, [fp, #-0x18]
    // 0x1231d3c: r1 = Function '<anonymous closure>':.
    //     0x1231d3c: add             x1, PP, #0xad, lsl #12  ; [pp+0xada08] AnonymousClosure: (0xd39830), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::handleThumbPressStart (0x1231cf4)
    //     0x1231d40: ldr             x1, [x1, #0xa08]
    // 0x1231d44: r0 = AllocateClosure()
    //     0x1231d44: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1231d48: ldur            x1, [fp, #-8]
    // 0x1231d4c: mov             x2, x0
    // 0x1231d50: r0 = setState()
    //     0x1231d50: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x1231d54: r0 = Null
    //     0x1231d54: mov             x0, NULL
    // 0x1231d58: LeaveFrame
    //     0x1231d58: mov             SP, fp
    //     0x1231d5c: ldp             fp, lr, [SP], #0x10
    // 0x1231d60: ret
    //     0x1231d60: ret             
    // 0x1231d64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1231d64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1231d68: b               #0x1231d14
  }
  _ handleThumbPressEnd(/* No info */) {
    // ** addr: 0x1232494, size: 0x80
    // 0x1232494: EnterFrame
    //     0x1232494: stp             fp, lr, [SP, #-0x10]!
    //     0x1232498: mov             fp, SP
    // 0x123249c: AllocStack(0x20)
    //     0x123249c: sub             SP, SP, #0x20
    // 0x12324a0: SetupParameters(_MaterialScrollbarState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x12324a0: stur            x1, [fp, #-8]
    //     0x12324a4: stur            x2, [fp, #-0x10]
    //     0x12324a8: stur            x3, [fp, #-0x18]
    // 0x12324ac: CheckStackOverflow
    //     0x12324ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12324b0: cmp             SP, x16
    //     0x12324b4: b.ls            #0x123250c
    // 0x12324b8: r1 = 1
    //     0x12324b8: mov             x1, #1
    // 0x12324bc: r0 = AllocateContext()
    //     0x12324bc: bl              #0x13de838  ; AllocateContextStub
    // 0x12324c0: mov             x4, x0
    // 0x12324c4: ldur            x0, [fp, #-8]
    // 0x12324c8: stur            x4, [fp, #-0x20]
    // 0x12324cc: StoreField: r4->field_f = r0
    //     0x12324cc: stur            w0, [x4, #0xf]
    // 0x12324d0: mov             x1, x0
    // 0x12324d4: ldur            x2, [fp, #-0x10]
    // 0x12324d8: ldur            x3, [fp, #-0x18]
    // 0x12324dc: r0 = handleThumbPressEnd()
    //     0x12324dc: bl              #0x1232514  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::handleThumbPressEnd
    // 0x12324e0: ldur            x2, [fp, #-0x20]
    // 0x12324e4: r1 = Function '<anonymous closure>':.
    //     0x12324e4: add             x1, PP, #0xad, lsl #12  ; [pp+0xad9a8] AnonymousClosure: (0xd388d0), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::handleThumbPressEnd (0x1232494)
    //     0x12324e8: ldr             x1, [x1, #0x9a8]
    // 0x12324ec: r0 = AllocateClosure()
    //     0x12324ec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12324f0: ldur            x1, [fp, #-8]
    // 0x12324f4: mov             x2, x0
    // 0x12324f8: r0 = setState()
    //     0x12324f8: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x12324fc: r0 = Null
    //     0x12324fc: mov             x0, NULL
    // 0x1232500: LeaveFrame
    //     0x1232500: mov             SP, fp
    //     0x1232504: ldp             fp, lr, [SP], #0x10
    // 0x1232508: ret
    //     0x1232508: ret             
    // 0x123250c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x123250c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1232510: b               #0x12324b8
  }
  _ handleHover(/* No info */) {
    // ** addr: 0x1232958, size: 0x164
    // 0x1232958: EnterFrame
    //     0x1232958: stp             fp, lr, [SP, #-0x10]!
    //     0x123295c: mov             fp, SP
    // 0x1232960: AllocStack(0x20)
    //     0x1232960: sub             SP, SP, #0x20
    // 0x1232964: SetupParameters(_MaterialScrollbarState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x1232964: stur            x1, [fp, #-8]
    //     0x1232968: stur            x2, [fp, #-0x10]
    // 0x123296c: CheckStackOverflow
    //     0x123296c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1232970: cmp             SP, x16
    //     0x1232974: b.ls            #0x1232a9c
    // 0x1232978: r1 = 1
    //     0x1232978: mov             x1, #1
    // 0x123297c: r0 = AllocateContext()
    //     0x123297c: bl              #0x13de838  ; AllocateContextStub
    // 0x1232980: mov             x3, x0
    // 0x1232984: ldur            x0, [fp, #-8]
    // 0x1232988: stur            x3, [fp, #-0x18]
    // 0x123298c: StoreField: r3->field_f = r0
    //     0x123298c: stur            w0, [x3, #0xf]
    // 0x1232990: mov             x1, x0
    // 0x1232994: ldur            x2, [fp, #-0x10]
    // 0x1232998: r0 = handleHover()
    //     0x1232998: bl              #0x1232ba4  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::handleHover
    // 0x123299c: ldur            x2, [fp, #-0x10]
    // 0x12329a0: r0 = LoadClassIdInstr(r2)
    //     0x12329a0: ldur            x0, [x2, #-1]
    //     0x12329a4: ubfx            x0, x0, #0xc, #0x14
    // 0x12329a8: mov             x1, x2
    // 0x12329ac: r0 = GDT[cid_x0 + 0x13f27]()
    //     0x12329ac: mov             x17, #0x3f27
    //     0x12329b0: movk            x17, #1, lsl #16
    //     0x12329b4: add             lr, x0, x17
    //     0x12329b8: ldr             lr, [x21, lr, lsl #3]
    //     0x12329bc: blr             lr
    // 0x12329c0: mov             x2, x0
    // 0x12329c4: ldur            x1, [fp, #-0x10]
    // 0x12329c8: stur            x2, [fp, #-0x20]
    // 0x12329cc: r0 = LoadClassIdInstr(r1)
    //     0x12329cc: ldur            x0, [x1, #-1]
    //     0x12329d0: ubfx            x0, x0, #0xc, #0x14
    // 0x12329d4: r0 = GDT[cid_x0 + 0x15e74]()
    //     0x12329d4: mov             x17, #0x5e74
    //     0x12329d8: movk            x17, #1, lsl #16
    //     0x12329dc: add             lr, x0, x17
    //     0x12329e0: ldr             lr, [x21, lr, lsl #3]
    //     0x12329e4: blr             lr
    // 0x12329e8: ldur            x1, [fp, #-8]
    // 0x12329ec: ldur            x2, [fp, #-0x20]
    // 0x12329f0: mov             x3, x0
    // 0x12329f4: r0 = isPointerOverScrollbar()
    //     0x12329f4: bl              #0x1232abc  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::isPointerOverScrollbar
    // 0x12329f8: tbnz            w0, #4, #0x1232a40
    // 0x12329fc: ldur            x0, [fp, #-8]
    // 0x1232a00: ldur            x2, [fp, #-0x18]
    // 0x1232a04: r1 = Function '<anonymous closure>':.
    //     0x1232a04: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb09c0] AnonymousClosure: (0x1232b80), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::handleHover (0x1232958)
    //     0x1232a08: ldr             x1, [x1, #0x9c0]
    // 0x1232a0c: r0 = AllocateClosure()
    //     0x1232a0c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1232a10: ldur            x1, [fp, #-8]
    // 0x1232a14: mov             x2, x0
    // 0x1232a18: r0 = setState()
    //     0x1232a18: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x1232a1c: ldur            x0, [fp, #-8]
    // 0x1232a20: LoadField: r1 = r0->field_57
    //     0x1232a20: ldur            w1, [x0, #0x57]
    // 0x1232a24: DecompressPointer r1
    //     0x1232a24: add             x1, x1, HEAP, lsl #32
    // 0x1232a28: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1232a2c: cmp             w1, w16
    // 0x1232a30: b.eq            #0x1232aa4
    // 0x1232a34: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x1232a34: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x1232a38: r0 = forward()
    //     0x1232a38: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x1232a3c: b               #0x1232a8c
    // 0x1232a40: ldur            x0, [fp, #-8]
    // 0x1232a44: LoadField: r1 = r0->field_5f
    //     0x1232a44: ldur            w1, [x0, #0x5f]
    // 0x1232a48: DecompressPointer r1
    //     0x1232a48: add             x1, x1, HEAP, lsl #32
    // 0x1232a4c: tbnz            w1, #4, #0x1232a8c
    // 0x1232a50: ldur            x2, [fp, #-0x18]
    // 0x1232a54: r1 = Function '<anonymous closure>':.
    //     0x1232a54: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb09c8] AnonymousClosure: (0xd3b7cc), of [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState
    //     0x1232a58: ldr             x1, [x1, #0x9c8]
    // 0x1232a5c: r0 = AllocateClosure()
    //     0x1232a5c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1232a60: ldur            x1, [fp, #-8]
    // 0x1232a64: mov             x2, x0
    // 0x1232a68: r0 = setState()
    //     0x1232a68: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x1232a6c: ldur            x0, [fp, #-8]
    // 0x1232a70: LoadField: r1 = r0->field_57
    //     0x1232a70: ldur            w1, [x0, #0x57]
    // 0x1232a74: DecompressPointer r1
    //     0x1232a74: add             x1, x1, HEAP, lsl #32
    // 0x1232a78: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1232a7c: cmp             w1, w16
    // 0x1232a80: b.eq            #0x1232ab0
    // 0x1232a84: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x1232a84: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x1232a88: r0 = reverse()
    //     0x1232a88: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x1232a8c: r0 = Null
    //     0x1232a8c: mov             x0, NULL
    // 0x1232a90: LeaveFrame
    //     0x1232a90: mov             SP, fp
    //     0x1232a94: ldp             fp, lr, [SP], #0x10
    // 0x1232a98: ret
    //     0x1232a98: ret             
    // 0x1232a9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1232a9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1232aa0: b               #0x1232978
    // 0x1232aa4: r9 = _hoverAnimationController
    //     0x1232aa4: add             x9, PP, #0xab, lsl #12  ; [pp+0xab348] Field <_MaterialScrollbarState@626083257._hoverAnimationController@626083257>: late (offset: 0x58)
    //     0x1232aa8: ldr             x9, [x9, #0x348]
    // 0x1232aac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1232aac: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x1232ab0: r9 = _hoverAnimationController
    //     0x1232ab0: add             x9, PP, #0xab, lsl #12  ; [pp+0xab348] Field <_MaterialScrollbarState@626083257._hoverAnimationController@626083257>: late (offset: 0x58)
    //     0x1232ab4: ldr             x9, [x9, #0x348]
    // 0x1232ab8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1232ab8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x1232b80, size: 0x24
    // 0x1232b80: r1 = true
    //     0x1232b80: add             x1, NULL, #0x20  ; true
    // 0x1232b84: ldr             x2, [SP]
    // 0x1232b88: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x1232b88: ldur            w3, [x2, #0x17]
    // 0x1232b8c: DecompressPointer r3
    //     0x1232b8c: add             x3, x3, HEAP, lsl #32
    // 0x1232b90: LoadField: r2 = r3->field_f
    //     0x1232b90: ldur            w2, [x3, #0xf]
    // 0x1232b94: DecompressPointer r2
    //     0x1232b94: add             x2, x2, HEAP, lsl #32
    // 0x1232b98: StoreField: r2->field_5f = r1
    //     0x1232b98: stur            w1, [x2, #0x5f]
    // 0x1232b9c: r0 = Null
    //     0x1232b9c: mov             x0, NULL
    // 0x1232ba0: ret
    //     0x1232ba0: ret             
  }
  get _ showScrollbar(/* No info */) {
    // ** addr: 0x124a1d8, size: 0x78
    // 0x124a1d8: EnterFrame
    //     0x124a1d8: stp             fp, lr, [SP, #-0x10]!
    //     0x124a1dc: mov             fp, SP
    // 0x124a1e0: LoadField: r2 = r1->field_b
    //     0x124a1e0: ldur            w2, [x1, #0xb]
    // 0x124a1e4: DecompressPointer r2
    //     0x124a1e4: add             x2, x2, HEAP, lsl #32
    // 0x124a1e8: cmp             w2, NULL
    // 0x124a1ec: b.eq            #0x124a240
    // 0x124a1f0: LoadField: r3 = r2->field_13
    //     0x124a1f0: ldur            w3, [x2, #0x13]
    // 0x124a1f4: DecompressPointer r3
    //     0x124a1f4: add             x3, x3, HEAP, lsl #32
    // 0x124a1f8: cmp             w3, NULL
    // 0x124a1fc: b.ne            #0x124a21c
    // 0x124a200: LoadField: r2 = r1->field_67
    //     0x124a200: ldur            w2, [x1, #0x67]
    // 0x124a204: DecompressPointer r2
    //     0x124a204: add             x2, x2, HEAP, lsl #32
    // 0x124a208: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124a20c: cmp             w2, w16
    // 0x124a210: b.eq            #0x124a244
    // 0x124a214: r1 = Null
    //     0x124a214: mov             x1, NULL
    // 0x124a218: b               #0x124a220
    // 0x124a21c: mov             x1, x3
    // 0x124a220: cmp             w1, NULL
    // 0x124a224: b.ne            #0x124a230
    // 0x124a228: r0 = false
    //     0x124a228: add             x0, NULL, #0x30  ; false
    // 0x124a22c: b               #0x124a234
    // 0x124a230: mov             x0, x1
    // 0x124a234: LeaveFrame
    //     0x124a234: mov             SP, fp
    //     0x124a238: ldp             fp, lr, [SP], #0x10
    // 0x124a23c: ret
    //     0x124a23c: ret             
    // 0x124a240: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x124a240: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x124a244: r9 = _scrollbarTheme
    //     0x124a244: add             x9, PP, #0xab, lsl #12  ; [pp+0xab368] Field <_MaterialScrollbarState@626083257._scrollbarTheme@626083257>: late (offset: 0x68)
    //     0x124a248: ldr             x9, [x9, #0x368]
    // 0x124a24c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x124a24c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ enableGestures(/* No info */) {
    // ** addr: 0x1283ca4, size: 0x6c
    // 0x1283ca4: EnterFrame
    //     0x1283ca4: stp             fp, lr, [SP, #-0x10]!
    //     0x1283ca8: mov             fp, SP
    // 0x1283cac: LoadField: r2 = r1->field_b
    //     0x1283cac: ldur            w2, [x1, #0xb]
    // 0x1283cb0: DecompressPointer r2
    //     0x1283cb0: add             x2, x2, HEAP, lsl #32
    // 0x1283cb4: cmp             w2, NULL
    // 0x1283cb8: b.eq            #0x1283cf4
    // 0x1283cbc: LoadField: r2 = r1->field_67
    //     0x1283cbc: ldur            w2, [x1, #0x67]
    // 0x1283cc0: DecompressPointer r2
    //     0x1283cc0: add             x2, x2, HEAP, lsl #32
    // 0x1283cc4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1283cc8: cmp             w2, w16
    // 0x1283ccc: b.eq            #0x1283cf8
    // 0x1283cd0: LoadField: r2 = r1->field_6b
    //     0x1283cd0: ldur            w2, [x1, #0x6b]
    // 0x1283cd4: DecompressPointer r2
    //     0x1283cd4: add             x2, x2, HEAP, lsl #32
    // 0x1283cd8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1283cdc: cmp             w2, w16
    // 0x1283ce0: b.eq            #0x1283d04
    // 0x1283ce4: eor             x0, x2, #0x10
    // 0x1283ce8: LeaveFrame
    //     0x1283ce8: mov             SP, fp
    //     0x1283cec: ldp             fp, lr, [SP], #0x10
    // 0x1283cf0: ret
    //     0x1283cf0: ret             
    // 0x1283cf4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1283cf4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1283cf8: r9 = _scrollbarTheme
    //     0x1283cf8: add             x9, PP, #0xab, lsl #12  ; [pp+0xab368] Field <_MaterialScrollbarState@626083257._scrollbarTheme@626083257>: late (offset: 0x68)
    //     0x1283cfc: ldr             x9, [x9, #0x368]
    // 0x1283d00: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1283d00: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x1283d04: r9 = _useAndroidScrollbar
    //     0x1283d04: add             x9, PP, #0xab, lsl #12  ; [pp+0xab370] Field <_MaterialScrollbarState@626083257._useAndroidScrollbar@626083257>: late (offset: 0x6c)
    //     0x1283d08: ldr             x9, [x9, #0x370]
    // 0x1283d0c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1283d0c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 6145, size: 0x30, field offset: 0xc
//   const constructor, 
class Scrollbar extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfbe014, size: 0xd8
    // 0xfbe014: EnterFrame
    //     0xfbe014: stp             fp, lr, [SP, #-0x10]!
    //     0xfbe018: mov             fp, SP
    // 0xfbe01c: AllocStack(0x30)
    //     0xfbe01c: sub             SP, SP, #0x30
    // 0xfbe020: SetupParameters(Scrollbar this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xfbe020: mov             x0, x1
    //     0xfbe024: stur            x1, [fp, #-8]
    //     0xfbe028: mov             x1, x2
    // 0xfbe02c: CheckStackOverflow
    //     0xfbe02c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbe030: cmp             SP, x16
    //     0xfbe034: b.ls            #0xfbe0e4
    // 0xfbe038: r0 = of()
    //     0xfbe038: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfbe03c: ldur            x0, [fp, #-8]
    // 0xfbe040: LoadField: r1 = r0->field_f
    //     0xfbe040: ldur            w1, [x0, #0xf]
    // 0xfbe044: DecompressPointer r1
    //     0xfbe044: add             x1, x1, HEAP, lsl #32
    // 0xfbe048: stur            x1, [fp, #-0x30]
    // 0xfbe04c: LoadField: r2 = r0->field_13
    //     0xfbe04c: ldur            w2, [x0, #0x13]
    // 0xfbe050: DecompressPointer r2
    //     0xfbe050: add             x2, x2, HEAP, lsl #32
    // 0xfbe054: stur            x2, [fp, #-0x28]
    // 0xfbe058: LoadField: r3 = r0->field_1b
    //     0xfbe058: ldur            w3, [x0, #0x1b]
    // 0xfbe05c: DecompressPointer r3
    //     0xfbe05c: add             x3, x3, HEAP, lsl #32
    // 0xfbe060: stur            x3, [fp, #-0x20]
    // 0xfbe064: LoadField: r4 = r0->field_1f
    //     0xfbe064: ldur            w4, [x0, #0x1f]
    // 0xfbe068: DecompressPointer r4
    //     0xfbe068: add             x4, x4, HEAP, lsl #32
    // 0xfbe06c: stur            x4, [fp, #-0x18]
    // 0xfbe070: LoadField: r5 = r0->field_b
    //     0xfbe070: ldur            w5, [x0, #0xb]
    // 0xfbe074: DecompressPointer r5
    //     0xfbe074: add             x5, x5, HEAP, lsl #32
    // 0xfbe078: stur            x5, [fp, #-0x10]
    // 0xfbe07c: r0 = _MaterialScrollbar()
    //     0xfbe07c: bl              #0xfbe0ec  ; Allocate_MaterialScrollbarStub -> _MaterialScrollbar (size=0x6c)
    // 0xfbe080: ldur            x1, [fp, #-0x10]
    // 0xfbe084: StoreField: r0->field_b = r1
    //     0xfbe084: stur            w1, [x0, #0xb]
    // 0xfbe088: ldur            x1, [fp, #-0x30]
    // 0xfbe08c: StoreField: r0->field_f = r1
    //     0xfbe08c: stur            w1, [x0, #0xf]
    // 0xfbe090: ldur            x1, [fp, #-0x28]
    // 0xfbe094: StoreField: r0->field_13 = r1
    //     0xfbe094: stur            w1, [x0, #0x13]
    // 0xfbe098: ldur            x1, [fp, #-0x18]
    // 0xfbe09c: StoreField: r0->field_1b = r1
    //     0xfbe09c: stur            w1, [x0, #0x1b]
    // 0xfbe0a0: ldur            x1, [fp, #-0x20]
    // 0xfbe0a4: StoreField: r0->field_1f = r1
    //     0xfbe0a4: stur            w1, [x0, #0x1f]
    // 0xfbe0a8: d0 = 18.000000
    //     0xfbe0a8: fmov            d0, #18.00000000
    // 0xfbe0ac: StoreField: r0->field_27 = d0
    //     0xfbe0ac: stur            d0, [x0, #0x27]
    // 0xfbe0b0: r1 = Instance_Duration
    //     0xfbe0b0: ldr             x1, [PP, #0x7cd8]  ; [pp+0x7cd8] Obj!Duration@12c8971
    // 0xfbe0b4: StoreField: r0->field_43 = r1
    //     0xfbe0b4: stur            w1, [x0, #0x43]
    // 0xfbe0b8: r1 = Instance_Duration
    //     0xfbe0b8: add             x1, PP, #0x96, lsl #12  ; [pp+0x96170] Obj!Duration@12c8af1
    //     0xfbe0bc: ldr             x1, [x1, #0x170]
    // 0xfbe0c0: StoreField: r0->field_47 = r1
    //     0xfbe0c0: stur            w1, [x0, #0x47]
    // 0xfbe0c4: r1 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0xfbe0c4: add             x1, PP, #0x18, lsl #12  ; [pp+0x18158] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x7f2adac1b19c)
    //     0xfbe0c8: ldr             x1, [x1, #0x158]
    // 0xfbe0cc: StoreField: r0->field_4b = r1
    //     0xfbe0cc: stur            w1, [x0, #0x4b]
    // 0xfbe0d0: StoreField: r0->field_57 = rZR
    //     0xfbe0d0: stur            xzr, [x0, #0x57]
    // 0xfbe0d4: StoreField: r0->field_5f = rZR
    //     0xfbe0d4: stur            xzr, [x0, #0x5f]
    // 0xfbe0d8: LeaveFrame
    //     0xfbe0d8: mov             SP, fp
    //     0xfbe0dc: ldp             fp, lr, [SP], #0x10
    // 0xfbe0e0: ret
    //     0xfbe0e0: ret             
    // 0xfbe0e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbe0e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbe0e8: b               #0xfbe038
  }
}

// class id: 6511, size: 0x6c, field offset: 0x6c
//   const constructor, 
class _MaterialScrollbar extends RawScrollbar {

  _ createState(/* No info */) {
    // ** addr: 0xfa0864, size: 0x48
    // 0xfa0864: EnterFrame
    //     0xfa0864: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0868: mov             fp, SP
    // 0xfa086c: AllocStack(0x8)
    //     0xfa086c: sub             SP, SP, #8
    // 0xfa0870: CheckStackOverflow
    //     0xfa0870: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa0874: cmp             SP, x16
    //     0xfa0878: b.ls            #0xfa08a4
    // 0xfa087c: r1 = <_MaterialScrollbar>
    //     0xfa087c: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1100] TypeArguments: <_MaterialScrollbar>
    //     0xfa0880: ldr             x1, [x1, #0x100]
    // 0xfa0884: r0 = _MaterialScrollbarState()
    //     0xfa0884: bl              #0xfa08fc  ; Allocate_MaterialScrollbarStateStub -> _MaterialScrollbarState (size=0x70)
    // 0xfa0888: mov             x1, x0
    // 0xfa088c: stur            x0, [fp, #-8]
    // 0xfa0890: r0 = _MaterialScrollbarState()
    //     0xfa0890: bl              #0xfa08ac  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_MaterialScrollbarState
    // 0xfa0894: ldur            x0, [fp, #-8]
    // 0xfa0898: LeaveFrame
    //     0xfa0898: mov             SP, fp
    //     0xfa089c: ldp             fp, lr, [SP], #0x10
    // 0xfa08a0: ret
    //     0xfa08a0: ret             
    // 0xfa08a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa08a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa08a8: b               #0xfa087c
  }
}
