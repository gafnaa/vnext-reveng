// lib: , url: package:flutter/src/material/button_style.dart

// class id: 1048857, size: 0x8
class :: {
}

// class id: 5192, size: 0x6c, field offset: 0x8
//   const constructor, 
class ButtonStyle extends _MixinApplication3&Object&Diagnosticable {

  _ merge(/* No info */) {
    // ** addr: 0xd29660, size: 0x2bc
    // 0xd29660: EnterFrame
    //     0xd29660: stp             fp, lr, [SP, #-0x10]!
    //     0xd29664: mov             fp, SP
    // 0xd29668: AllocStack(0xd0)
    //     0xd29668: sub             SP, SP, #0xd0
    // 0xd2966c: SetupParameters(ButtonStyle this /* r1 => r0 */)
    //     0xd2966c: mov             x0, x1
    // 0xd29670: CheckStackOverflow
    //     0xd29670: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd29674: cmp             SP, x16
    //     0xd29678: b.ls            #0xd29914
    // 0xd2967c: cmp             w2, NULL
    // 0xd29680: b.ne            #0xd29690
    // 0xd29684: LeaveFrame
    //     0xd29684: mov             SP, fp
    //     0xd29688: ldp             fp, lr, [SP], #0x10
    // 0xd2968c: ret
    //     0xd2968c: ret             
    // 0xd29690: LoadField: r1 = r0->field_7
    //     0xd29690: ldur            w1, [x0, #7]
    // 0xd29694: DecompressPointer r1
    //     0xd29694: add             x1, x1, HEAP, lsl #32
    // 0xd29698: cmp             w1, NULL
    // 0xd2969c: b.ne            #0xd296a8
    // 0xd296a0: LoadField: r1 = r2->field_7
    //     0xd296a0: ldur            w1, [x2, #7]
    // 0xd296a4: DecompressPointer r1
    //     0xd296a4: add             x1, x1, HEAP, lsl #32
    // 0xd296a8: LoadField: r3 = r0->field_b
    //     0xd296a8: ldur            w3, [x0, #0xb]
    // 0xd296ac: DecompressPointer r3
    //     0xd296ac: add             x3, x3, HEAP, lsl #32
    // 0xd296b0: cmp             w3, NULL
    // 0xd296b4: b.ne            #0xd296c0
    // 0xd296b8: LoadField: r3 = r2->field_b
    //     0xd296b8: ldur            w3, [x2, #0xb]
    // 0xd296bc: DecompressPointer r3
    //     0xd296bc: add             x3, x3, HEAP, lsl #32
    // 0xd296c0: LoadField: r4 = r0->field_f
    //     0xd296c0: ldur            w4, [x0, #0xf]
    // 0xd296c4: DecompressPointer r4
    //     0xd296c4: add             x4, x4, HEAP, lsl #32
    // 0xd296c8: cmp             w4, NULL
    // 0xd296cc: b.ne            #0xd296d8
    // 0xd296d0: LoadField: r4 = r2->field_f
    //     0xd296d0: ldur            w4, [x2, #0xf]
    // 0xd296d4: DecompressPointer r4
    //     0xd296d4: add             x4, x4, HEAP, lsl #32
    // 0xd296d8: LoadField: r5 = r0->field_13
    //     0xd296d8: ldur            w5, [x0, #0x13]
    // 0xd296dc: DecompressPointer r5
    //     0xd296dc: add             x5, x5, HEAP, lsl #32
    // 0xd296e0: cmp             w5, NULL
    // 0xd296e4: b.ne            #0xd296f0
    // 0xd296e8: LoadField: r5 = r2->field_13
    //     0xd296e8: ldur            w5, [x2, #0x13]
    // 0xd296ec: DecompressPointer r5
    //     0xd296ec: add             x5, x5, HEAP, lsl #32
    // 0xd296f0: ArrayLoad: r6 = r0[0]  ; List_4
    //     0xd296f0: ldur            w6, [x0, #0x17]
    // 0xd296f4: DecompressPointer r6
    //     0xd296f4: add             x6, x6, HEAP, lsl #32
    // 0xd296f8: cmp             w6, NULL
    // 0xd296fc: b.ne            #0xd29708
    // 0xd29700: ArrayLoad: r6 = r2[0]  ; List_4
    //     0xd29700: ldur            w6, [x2, #0x17]
    // 0xd29704: DecompressPointer r6
    //     0xd29704: add             x6, x6, HEAP, lsl #32
    // 0xd29708: LoadField: r7 = r0->field_1b
    //     0xd29708: ldur            w7, [x0, #0x1b]
    // 0xd2970c: DecompressPointer r7
    //     0xd2970c: add             x7, x7, HEAP, lsl #32
    // 0xd29710: cmp             w7, NULL
    // 0xd29714: b.ne            #0xd29720
    // 0xd29718: LoadField: r7 = r2->field_1b
    //     0xd29718: ldur            w7, [x2, #0x1b]
    // 0xd2971c: DecompressPointer r7
    //     0xd2971c: add             x7, x7, HEAP, lsl #32
    // 0xd29720: LoadField: r8 = r0->field_1f
    //     0xd29720: ldur            w8, [x0, #0x1f]
    // 0xd29724: DecompressPointer r8
    //     0xd29724: add             x8, x8, HEAP, lsl #32
    // 0xd29728: cmp             w8, NULL
    // 0xd2972c: b.ne            #0xd29738
    // 0xd29730: LoadField: r8 = r2->field_1f
    //     0xd29730: ldur            w8, [x2, #0x1f]
    // 0xd29734: DecompressPointer r8
    //     0xd29734: add             x8, x8, HEAP, lsl #32
    // 0xd29738: LoadField: r9 = r0->field_23
    //     0xd29738: ldur            w9, [x0, #0x23]
    // 0xd2973c: DecompressPointer r9
    //     0xd2973c: add             x9, x9, HEAP, lsl #32
    // 0xd29740: cmp             w9, NULL
    // 0xd29744: b.ne            #0xd29750
    // 0xd29748: LoadField: r9 = r2->field_23
    //     0xd29748: ldur            w9, [x2, #0x23]
    // 0xd2974c: DecompressPointer r9
    //     0xd2974c: add             x9, x9, HEAP, lsl #32
    // 0xd29750: LoadField: r10 = r0->field_27
    //     0xd29750: ldur            w10, [x0, #0x27]
    // 0xd29754: DecompressPointer r10
    //     0xd29754: add             x10, x10, HEAP, lsl #32
    // 0xd29758: cmp             w10, NULL
    // 0xd2975c: b.ne            #0xd29768
    // 0xd29760: LoadField: r10 = r2->field_27
    //     0xd29760: ldur            w10, [x2, #0x27]
    // 0xd29764: DecompressPointer r10
    //     0xd29764: add             x10, x10, HEAP, lsl #32
    // 0xd29768: LoadField: r11 = r0->field_2b
    //     0xd29768: ldur            w11, [x0, #0x2b]
    // 0xd2976c: DecompressPointer r11
    //     0xd2976c: add             x11, x11, HEAP, lsl #32
    // 0xd29770: cmp             w11, NULL
    // 0xd29774: b.ne            #0xd29780
    // 0xd29778: LoadField: r11 = r2->field_2b
    //     0xd29778: ldur            w11, [x2, #0x2b]
    // 0xd2977c: DecompressPointer r11
    //     0xd2977c: add             x11, x11, HEAP, lsl #32
    // 0xd29780: LoadField: r12 = r0->field_2f
    //     0xd29780: ldur            w12, [x0, #0x2f]
    // 0xd29784: DecompressPointer r12
    //     0xd29784: add             x12, x12, HEAP, lsl #32
    // 0xd29788: cmp             w12, NULL
    // 0xd2978c: b.ne            #0xd29798
    // 0xd29790: LoadField: r12 = r2->field_2f
    //     0xd29790: ldur            w12, [x2, #0x2f]
    // 0xd29794: DecompressPointer r12
    //     0xd29794: add             x12, x12, HEAP, lsl #32
    // 0xd29798: LoadField: r13 = r0->field_33
    //     0xd29798: ldur            w13, [x0, #0x33]
    // 0xd2979c: DecompressPointer r13
    //     0xd2979c: add             x13, x13, HEAP, lsl #32
    // 0xd297a0: cmp             w13, NULL
    // 0xd297a4: b.ne            #0xd297b0
    // 0xd297a8: LoadField: r13 = r2->field_33
    //     0xd297a8: ldur            w13, [x2, #0x33]
    // 0xd297ac: DecompressPointer r13
    //     0xd297ac: add             x13, x13, HEAP, lsl #32
    // 0xd297b0: LoadField: r14 = r0->field_37
    //     0xd297b0: ldur            w14, [x0, #0x37]
    // 0xd297b4: DecompressPointer r14
    //     0xd297b4: add             x14, x14, HEAP, lsl #32
    // 0xd297b8: cmp             w14, NULL
    // 0xd297bc: b.ne            #0xd297c8
    // 0xd297c0: LoadField: r14 = r2->field_37
    //     0xd297c0: ldur            w14, [x2, #0x37]
    // 0xd297c4: DecompressPointer r14
    //     0xd297c4: add             x14, x14, HEAP, lsl #32
    // 0xd297c8: LoadField: r19 = r0->field_3f
    //     0xd297c8: ldur            w19, [x0, #0x3f]
    // 0xd297cc: DecompressPointer r19
    //     0xd297cc: add             x19, x19, HEAP, lsl #32
    // 0xd297d0: cmp             w19, NULL
    // 0xd297d4: b.ne            #0xd297e0
    // 0xd297d8: LoadField: r19 = r2->field_3f
    //     0xd297d8: ldur            w19, [x2, #0x3f]
    // 0xd297dc: DecompressPointer r19
    //     0xd297dc: add             x19, x19, HEAP, lsl #32
    // 0xd297e0: LoadField: r20 = r0->field_43
    //     0xd297e0: ldur            w20, [x0, #0x43]
    // 0xd297e4: DecompressPointer r20
    //     0xd297e4: add             x20, x20, HEAP, lsl #32
    // 0xd297e8: cmp             w20, NULL
    // 0xd297ec: b.ne            #0xd297f8
    // 0xd297f0: LoadField: r20 = r2->field_43
    //     0xd297f0: ldur            w20, [x2, #0x43]
    // 0xd297f4: DecompressPointer r20
    //     0xd297f4: add             x20, x20, HEAP, lsl #32
    // 0xd297f8: LoadField: r23 = r0->field_47
    //     0xd297f8: ldur            w23, [x0, #0x47]
    // 0xd297fc: DecompressPointer r23
    //     0xd297fc: add             x23, x23, HEAP, lsl #32
    // 0xd29800: cmp             w23, NULL
    // 0xd29804: b.ne            #0xd29810
    // 0xd29808: LoadField: r23 = r2->field_47
    //     0xd29808: ldur            w23, [x2, #0x47]
    // 0xd2980c: DecompressPointer r23
    //     0xd2980c: add             x23, x23, HEAP, lsl #32
    // 0xd29810: LoadField: r24 = r0->field_4b
    //     0xd29810: ldur            w24, [x0, #0x4b]
    // 0xd29814: DecompressPointer r24
    //     0xd29814: add             x24, x24, HEAP, lsl #32
    // 0xd29818: cmp             w24, NULL
    // 0xd2981c: b.ne            #0xd29828
    // 0xd29820: LoadField: r24 = r2->field_4b
    //     0xd29820: ldur            w24, [x2, #0x4b]
    // 0xd29824: DecompressPointer r24
    //     0xd29824: add             x24, x24, HEAP, lsl #32
    // 0xd29828: LoadField: r25 = r0->field_4f
    //     0xd29828: ldur            w25, [x0, #0x4f]
    // 0xd2982c: DecompressPointer r25
    //     0xd2982c: add             x25, x25, HEAP, lsl #32
    // 0xd29830: cmp             w25, NULL
    // 0xd29834: b.ne            #0xd29840
    // 0xd29838: LoadField: r25 = r2->field_4f
    //     0xd29838: ldur            w25, [x2, #0x4f]
    // 0xd2983c: DecompressPointer r25
    //     0xd2983c: add             x25, x25, HEAP, lsl #32
    // 0xd29840: stur            x25, [fp, #-8]
    // 0xd29844: LoadField: r25 = r0->field_53
    //     0xd29844: ldur            w25, [x0, #0x53]
    // 0xd29848: DecompressPointer r25
    //     0xd29848: add             x25, x25, HEAP, lsl #32
    // 0xd2984c: cmp             w25, NULL
    // 0xd29850: b.ne            #0xd2985c
    // 0xd29854: LoadField: r25 = r2->field_53
    //     0xd29854: ldur            w25, [x2, #0x53]
    // 0xd29858: DecompressPointer r25
    //     0xd29858: add             x25, x25, HEAP, lsl #32
    // 0xd2985c: stur            x25, [fp, #-0x10]
    // 0xd29860: LoadField: r25 = r0->field_57
    //     0xd29860: ldur            w25, [x0, #0x57]
    // 0xd29864: DecompressPointer r25
    //     0xd29864: add             x25, x25, HEAP, lsl #32
    // 0xd29868: cmp             w25, NULL
    // 0xd2986c: b.ne            #0xd29878
    // 0xd29870: LoadField: r25 = r2->field_57
    //     0xd29870: ldur            w25, [x2, #0x57]
    // 0xd29874: DecompressPointer r25
    //     0xd29874: add             x25, x25, HEAP, lsl #32
    // 0xd29878: stur            x25, [fp, #-0x18]
    // 0xd2987c: LoadField: r25 = r0->field_5b
    //     0xd2987c: ldur            w25, [x0, #0x5b]
    // 0xd29880: DecompressPointer r25
    //     0xd29880: add             x25, x25, HEAP, lsl #32
    // 0xd29884: cmp             w25, NULL
    // 0xd29888: b.ne            #0xd29894
    // 0xd2988c: LoadField: r25 = r2->field_5b
    //     0xd2988c: ldur            w25, [x2, #0x5b]
    // 0xd29890: DecompressPointer r25
    //     0xd29890: add             x25, x25, HEAP, lsl #32
    // 0xd29894: stur            x25, [fp, #-0x20]
    // 0xd29898: LoadField: r25 = r0->field_5f
    //     0xd29898: ldur            w25, [x0, #0x5f]
    // 0xd2989c: DecompressPointer r25
    //     0xd2989c: add             x25, x25, HEAP, lsl #32
    // 0xd298a0: cmp             w25, NULL
    // 0xd298a4: b.ne            #0xd298b8
    // 0xd298a8: LoadField: r25 = r2->field_5f
    //     0xd298a8: ldur            w25, [x2, #0x5f]
    // 0xd298ac: DecompressPointer r25
    //     0xd298ac: add             x25, x25, HEAP, lsl #32
    // 0xd298b0: mov             x2, x25
    // 0xd298b4: b               #0xd298bc
    // 0xd298b8: mov             x2, x25
    // 0xd298bc: stp             x3, x1, [SP, #0xa0]
    // 0xd298c0: stp             x5, x4, [SP, #0x90]
    // 0xd298c4: stp             x7, x6, [SP, #0x80]
    // 0xd298c8: stp             x9, x8, [SP, #0x70]
    // 0xd298cc: stp             x11, x10, [SP, #0x60]
    // 0xd298d0: stp             x13, x12, [SP, #0x50]
    // 0xd298d4: stp             x19, x14, [SP, #0x40]
    // 0xd298d8: stp             x23, x20, [SP, #0x30]
    // 0xd298dc: ldur            x16, [fp, #-8]
    // 0xd298e0: stp             x16, x24, [SP, #0x20]
    // 0xd298e4: ldur            x16, [fp, #-0x10]
    // 0xd298e8: ldur            lr, [fp, #-0x18]
    // 0xd298ec: stp             lr, x16, [SP, #0x10]
    // 0xd298f0: ldur            x16, [fp, #-0x20]
    // 0xd298f4: stp             x2, x16, [SP]
    // 0xd298f8: mov             x1, x0
    // 0xd298fc: r4 = const [0, 0x17, 0x16, 0x1, alignment, 0x15, animationDuration, 0x13, backgroundColor, 0x2, elevation, 0x7, enableFeedback, 0x14, fixedSize, 0xa, foregroundColor, 0x3, iconColor, 0xc, iconSize, 0xd, maximumSize, 0xb, minimumSize, 0x9, mouseCursor, 0x10, overlayColor, 0x4, padding, 0x8, shadowColor, 0x5, shape, 0xf, side, 0xe, splashFactory, 0x16, surfaceTintColor, 0x6, tapTargetSize, 0x12, textStyle, 0x1, visualDensity, 0x11, null]
    //     0xd298fc: add             x4, PP, #0x80, lsl #12  ; [pp+0x80c90] List(49) [0, 0x17, 0x16, 0x1, "alignment", 0x15, "animationDuration", 0x13, "backgroundColor", 0x2, "elevation", 0x7, "enableFeedback", 0x14, "fixedSize", 0xa, "foregroundColor", 0x3, "iconColor", 0xc, "iconSize", 0xd, "maximumSize", 0xb, "minimumSize", 0x9, "mouseCursor", 0x10, "overlayColor", 0x4, "padding", 0x8, "shadowColor", 0x5, "shape", 0xf, "side", 0xe, "splashFactory", 0x16, "surfaceTintColor", 0x6, "tapTargetSize", 0x12, "textStyle", 0x1, "visualDensity", 0x11, Null]
    //     0xd29900: ldr             x4, [x4, #0xc90]
    // 0xd29904: r0 = copyWith()
    //     0xd29904: bl              #0xd2991c  ; [package:flutter/src/material/button_style.dart] ButtonStyle::copyWith
    // 0xd29908: LeaveFrame
    //     0xd29908: mov             SP, fp
    //     0xd2990c: ldp             fp, lr, [SP], #0x10
    // 0xd29910: ret
    //     0xd29910: ret             
    // 0xd29914: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd29914: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd29918: b               #0xd2967c
  }
  _ copyWith(/* No info */) {
    // ** addr: 0xd2991c, size: 0xdac
    // 0xd2991c: EnterFrame
    //     0xd2991c: stp             fp, lr, [SP, #-0x10]!
    //     0xd29920: mov             fp, SP
    // 0xd29924: AllocStack(0xc8)
    //     0xd29924: sub             SP, SP, #0xc8
    // 0xd29928: SetupParameters(ButtonStyle this /* r1 => r2, fp-0xb0 */, {dynamic alignment = Null /* fp-0x8 */, dynamic animationDuration = Null /* r5, fp-0xa8 */, dynamic backgroundColor = Null /* r6, fp-0xa0 */, dynamic elevation = Null /* r7, fp-0x98 */, dynamic enableFeedback = Null /* r8, fp-0x90 */, dynamic fixedSize = Null /* r9, fp-0x88 */, dynamic foregroundColor = Null /* r10, fp-0x80 */, dynamic iconColor = Null /* r11, fp-0x78 */, dynamic iconSize = Null /* r12, fp-0x70 */, dynamic maximumSize = Null /* r13, fp-0x68 */, dynamic minimumSize = Null /* r14, fp-0x60 */, dynamic mouseCursor = Null /* r19, fp-0x58 */, dynamic overlayColor = Null /* r20, fp-0x50 */, dynamic padding = Null /* fp-0x10 */, dynamic shadowColor = Null /* fp-0x18 */, dynamic shape = Null /* fp-0x20 */, dynamic side = Null /* fp-0x28 */, dynamic splashFactory = Null /* fp-0x30 */, dynamic surfaceTintColor = Null /* fp-0x38 */, dynamic tapTargetSize = Null /* fp-0x40 */, dynamic textStyle = Null /* r3 */, dynamic visualDensity = Null /* r4, fp-0x48 */})
    //     0xd29928: mov             x2, x1
    //     0xd2992c: stur            x1, [fp, #-0xb0]
    //     0xd29930: ldur            w0, [x4, #0x13]
    //     0xd29934: ldur            w1, [x4, #0x1f]
    //     0xd29938: add             x1, x1, HEAP, lsl #32
    //     0xd2993c: ldr             x16, [PP, #0x5c70]  ; [pp+0x5c70] "alignment"
    //     0xd29940: cmp             w1, w16
    //     0xd29944: b.ne            #0xd29968
    //     0xd29948: ldur            w1, [x4, #0x23]
    //     0xd2994c: add             x1, x1, HEAP, lsl #32
    //     0xd29950: sub             w3, w0, w1
    //     0xd29954: add             x1, fp, w3, sxtw #2
    //     0xd29958: ldr             x1, [x1, #8]
    //     0xd2995c: mov             x3, x1
    //     0xd29960: mov             x1, #1
    //     0xd29964: b               #0xd29970
    //     0xd29968: mov             x3, NULL
    //     0xd2996c: mov             x1, #0
    //     0xd29970: stur            x3, [fp, #-8]
    //     0xd29974: lsl             x5, x1, #1
    //     0xd29978: lsl             w6, w5, #1
    //     0xd2997c: add             w7, w6, #8
    //     0xd29980: add             x16, x4, w7, sxtw #1
    //     0xd29984: ldur            w8, [x16, #0xf]
    //     0xd29988: add             x8, x8, HEAP, lsl #32
    //     0xd2998c: add             x16, PP, #0x15, lsl #12  ; [pp+0x159d0] "animationDuration"
    //     0xd29990: ldr             x16, [x16, #0x9d0]
    //     0xd29994: cmp             w8, w16
    //     0xd29998: b.ne            #0xd299cc
    //     0xd2999c: add             w1, w6, #0xa
    //     0xd299a0: add             x16, x4, w1, sxtw #1
    //     0xd299a4: ldur            w6, [x16, #0xf]
    //     0xd299a8: add             x6, x6, HEAP, lsl #32
    //     0xd299ac: sub             w1, w0, w6
    //     0xd299b0: add             x6, fp, w1, sxtw #2
    //     0xd299b4: ldr             x6, [x6, #8]
    //     0xd299b8: add             w1, w5, #2
    //     0xd299bc: sbfx            x5, x1, #1, #0x1f
    //     0xd299c0: mov             x1, x5
    //     0xd299c4: mov             x5, x6
    //     0xd299c8: b               #0xd299d0
    //     0xd299cc: mov             x5, NULL
    //     0xd299d0: stur            x5, [fp, #-0xa8]
    //     0xd299d4: lsl             x6, x1, #1
    //     0xd299d8: lsl             w7, w6, #1
    //     0xd299dc: add             w8, w7, #8
    //     0xd299e0: add             x16, x4, w8, sxtw #1
    //     0xd299e4: ldur            w9, [x16, #0xf]
    //     0xd299e8: add             x9, x9, HEAP, lsl #32
    //     0xd299ec: add             x16, PP, #0x12, lsl #12  ; [pp+0x12958] "backgroundColor"
    //     0xd299f0: ldr             x16, [x16, #0x958]
    //     0xd299f4: cmp             w9, w16
    //     0xd299f8: b.ne            #0xd29a2c
    //     0xd299fc: add             w1, w7, #0xa
    //     0xd29a00: add             x16, x4, w1, sxtw #1
    //     0xd29a04: ldur            w7, [x16, #0xf]
    //     0xd29a08: add             x7, x7, HEAP, lsl #32
    //     0xd29a0c: sub             w1, w0, w7
    //     0xd29a10: add             x7, fp, w1, sxtw #2
    //     0xd29a14: ldr             x7, [x7, #8]
    //     0xd29a18: add             w1, w6, #2
    //     0xd29a1c: sbfx            x6, x1, #1, #0x1f
    //     0xd29a20: mov             x1, x6
    //     0xd29a24: mov             x6, x7
    //     0xd29a28: b               #0xd29a30
    //     0xd29a2c: mov             x6, NULL
    //     0xd29a30: stur            x6, [fp, #-0xa0]
    //     0xd29a34: lsl             x7, x1, #1
    //     0xd29a38: lsl             w8, w7, #1
    //     0xd29a3c: add             w9, w8, #8
    //     0xd29a40: add             x16, x4, w9, sxtw #1
    //     0xd29a44: ldur            w10, [x16, #0xf]
    //     0xd29a48: add             x10, x10, HEAP, lsl #32
    //     0xd29a4c: add             x16, PP, #0x15, lsl #12  ; [pp+0x159f0] "elevation"
    //     0xd29a50: ldr             x16, [x16, #0x9f0]
    //     0xd29a54: cmp             w10, w16
    //     0xd29a58: b.ne            #0xd29a8c
    //     0xd29a5c: add             w1, w8, #0xa
    //     0xd29a60: add             x16, x4, w1, sxtw #1
    //     0xd29a64: ldur            w8, [x16, #0xf]
    //     0xd29a68: add             x8, x8, HEAP, lsl #32
    //     0xd29a6c: sub             w1, w0, w8
    //     0xd29a70: add             x8, fp, w1, sxtw #2
    //     0xd29a74: ldr             x8, [x8, #8]
    //     0xd29a78: add             w1, w7, #2
    //     0xd29a7c: sbfx            x7, x1, #1, #0x1f
    //     0xd29a80: mov             x1, x7
    //     0xd29a84: mov             x7, x8
    //     0xd29a88: b               #0xd29a90
    //     0xd29a8c: mov             x7, NULL
    //     0xd29a90: stur            x7, [fp, #-0x98]
    //     0xd29a94: lsl             x8, x1, #1
    //     0xd29a98: lsl             w9, w8, #1
    //     0xd29a9c: add             w10, w9, #8
    //     0xd29aa0: add             x16, x4, w10, sxtw #1
    //     0xd29aa4: ldur            w11, [x16, #0xf]
    //     0xd29aa8: add             x11, x11, HEAP, lsl #32
    //     0xd29aac: add             x16, PP, #0x15, lsl #12  ; [pp+0x159f8] "enableFeedback"
    //     0xd29ab0: ldr             x16, [x16, #0x9f8]
    //     0xd29ab4: cmp             w11, w16
    //     0xd29ab8: b.ne            #0xd29aec
    //     0xd29abc: add             w1, w9, #0xa
    //     0xd29ac0: add             x16, x4, w1, sxtw #1
    //     0xd29ac4: ldur            w9, [x16, #0xf]
    //     0xd29ac8: add             x9, x9, HEAP, lsl #32
    //     0xd29acc: sub             w1, w0, w9
    //     0xd29ad0: add             x9, fp, w1, sxtw #2
    //     0xd29ad4: ldr             x9, [x9, #8]
    //     0xd29ad8: add             w1, w8, #2
    //     0xd29adc: sbfx            x8, x1, #1, #0x1f
    //     0xd29ae0: mov             x1, x8
    //     0xd29ae4: mov             x8, x9
    //     0xd29ae8: b               #0xd29af0
    //     0xd29aec: mov             x8, NULL
    //     0xd29af0: stur            x8, [fp, #-0x90]
    //     0xd29af4: lsl             x9, x1, #1
    //     0xd29af8: lsl             w10, w9, #1
    //     0xd29afc: add             w11, w10, #8
    //     0xd29b00: add             x16, x4, w11, sxtw #1
    //     0xd29b04: ldur            w12, [x16, #0xf]
    //     0xd29b08: add             x12, x12, HEAP, lsl #32
    //     0xd29b0c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a08] "fixedSize"
    //     0xd29b10: ldr             x16, [x16, #0xa08]
    //     0xd29b14: cmp             w12, w16
    //     0xd29b18: b.ne            #0xd29b4c
    //     0xd29b1c: add             w1, w10, #0xa
    //     0xd29b20: add             x16, x4, w1, sxtw #1
    //     0xd29b24: ldur            w10, [x16, #0xf]
    //     0xd29b28: add             x10, x10, HEAP, lsl #32
    //     0xd29b2c: sub             w1, w0, w10
    //     0xd29b30: add             x10, fp, w1, sxtw #2
    //     0xd29b34: ldr             x10, [x10, #8]
    //     0xd29b38: add             w1, w9, #2
    //     0xd29b3c: sbfx            x9, x1, #1, #0x1f
    //     0xd29b40: mov             x1, x9
    //     0xd29b44: mov             x9, x10
    //     0xd29b48: b               #0xd29b50
    //     0xd29b4c: mov             x9, NULL
    //     0xd29b50: stur            x9, [fp, #-0x88]
    //     0xd29b54: lsl             x10, x1, #1
    //     0xd29b58: lsl             w11, w10, #1
    //     0xd29b5c: add             w12, w11, #8
    //     0xd29b60: add             x16, x4, w12, sxtw #1
    //     0xd29b64: ldur            w13, [x16, #0xf]
    //     0xd29b68: add             x13, x13, HEAP, lsl #32
    //     0xd29b6c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a10] "foregroundColor"
    //     0xd29b70: ldr             x16, [x16, #0xa10]
    //     0xd29b74: cmp             w13, w16
    //     0xd29b78: b.ne            #0xd29bac
    //     0xd29b7c: add             w1, w11, #0xa
    //     0xd29b80: add             x16, x4, w1, sxtw #1
    //     0xd29b84: ldur            w11, [x16, #0xf]
    //     0xd29b88: add             x11, x11, HEAP, lsl #32
    //     0xd29b8c: sub             w1, w0, w11
    //     0xd29b90: add             x11, fp, w1, sxtw #2
    //     0xd29b94: ldr             x11, [x11, #8]
    //     0xd29b98: add             w1, w10, #2
    //     0xd29b9c: sbfx            x10, x1, #1, #0x1f
    //     0xd29ba0: mov             x1, x10
    //     0xd29ba4: mov             x10, x11
    //     0xd29ba8: b               #0xd29bb0
    //     0xd29bac: mov             x10, NULL
    //     0xd29bb0: stur            x10, [fp, #-0x80]
    //     0xd29bb4: lsl             x11, x1, #1
    //     0xd29bb8: lsl             w12, w11, #1
    //     0xd29bbc: add             w13, w12, #8
    //     0xd29bc0: add             x16, x4, w13, sxtw #1
    //     0xd29bc4: ldur            w14, [x16, #0xf]
    //     0xd29bc8: add             x14, x14, HEAP, lsl #32
    //     0xd29bcc: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a9d0] "iconColor"
    //     0xd29bd0: ldr             x16, [x16, #0x9d0]
    //     0xd29bd4: cmp             w14, w16
    //     0xd29bd8: b.ne            #0xd29c0c
    //     0xd29bdc: add             w1, w12, #0xa
    //     0xd29be0: add             x16, x4, w1, sxtw #1
    //     0xd29be4: ldur            w12, [x16, #0xf]
    //     0xd29be8: add             x12, x12, HEAP, lsl #32
    //     0xd29bec: sub             w1, w0, w12
    //     0xd29bf0: add             x12, fp, w1, sxtw #2
    //     0xd29bf4: ldr             x12, [x12, #8]
    //     0xd29bf8: add             w1, w11, #2
    //     0xd29bfc: sbfx            x11, x1, #1, #0x1f
    //     0xd29c00: mov             x1, x11
    //     0xd29c04: mov             x11, x12
    //     0xd29c08: b               #0xd29c10
    //     0xd29c0c: mov             x11, NULL
    //     0xd29c10: stur            x11, [fp, #-0x78]
    //     0xd29c14: lsl             x12, x1, #1
    //     0xd29c18: lsl             w13, w12, #1
    //     0xd29c1c: add             w14, w13, #8
    //     0xd29c20: add             x16, x4, w14, sxtw #1
    //     0xd29c24: ldur            w19, [x16, #0xf]
    //     0xd29c28: add             x19, x19, HEAP, lsl #32
    //     0xd29c2c: add             x16, PP, #0x80, lsl #12  ; [pp+0x80c70] "iconSize"
    //     0xd29c30: ldr             x16, [x16, #0xc70]
    //     0xd29c34: cmp             w19, w16
    //     0xd29c38: b.ne            #0xd29c6c
    //     0xd29c3c: add             w1, w13, #0xa
    //     0xd29c40: add             x16, x4, w1, sxtw #1
    //     0xd29c44: ldur            w13, [x16, #0xf]
    //     0xd29c48: add             x13, x13, HEAP, lsl #32
    //     0xd29c4c: sub             w1, w0, w13
    //     0xd29c50: add             x13, fp, w1, sxtw #2
    //     0xd29c54: ldr             x13, [x13, #8]
    //     0xd29c58: add             w1, w12, #2
    //     0xd29c5c: sbfx            x12, x1, #1, #0x1f
    //     0xd29c60: mov             x1, x12
    //     0xd29c64: mov             x12, x13
    //     0xd29c68: b               #0xd29c70
    //     0xd29c6c: mov             x12, NULL
    //     0xd29c70: stur            x12, [fp, #-0x70]
    //     0xd29c74: lsl             x13, x1, #1
    //     0xd29c78: lsl             w14, w13, #1
    //     0xd29c7c: add             w19, w14, #8
    //     0xd29c80: add             x16, x4, w19, sxtw #1
    //     0xd29c84: ldur            w20, [x16, #0xf]
    //     0xd29c88: add             x20, x20, HEAP, lsl #32
    //     0xd29c8c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a18] "maximumSize"
    //     0xd29c90: ldr             x16, [x16, #0xa18]
    //     0xd29c94: cmp             w20, w16
    //     0xd29c98: b.ne            #0xd29ccc
    //     0xd29c9c: add             w1, w14, #0xa
    //     0xd29ca0: add             x16, x4, w1, sxtw #1
    //     0xd29ca4: ldur            w14, [x16, #0xf]
    //     0xd29ca8: add             x14, x14, HEAP, lsl #32
    //     0xd29cac: sub             w1, w0, w14
    //     0xd29cb0: add             x14, fp, w1, sxtw #2
    //     0xd29cb4: ldr             x14, [x14, #8]
    //     0xd29cb8: add             w1, w13, #2
    //     0xd29cbc: sbfx            x13, x1, #1, #0x1f
    //     0xd29cc0: mov             x1, x13
    //     0xd29cc4: mov             x13, x14
    //     0xd29cc8: b               #0xd29cd0
    //     0xd29ccc: mov             x13, NULL
    //     0xd29cd0: stur            x13, [fp, #-0x68]
    //     0xd29cd4: lsl             x14, x1, #1
    //     0xd29cd8: lsl             w19, w14, #1
    //     0xd29cdc: add             w20, w19, #8
    //     0xd29ce0: add             x16, x4, w20, sxtw #1
    //     0xd29ce4: ldur            w23, [x16, #0xf]
    //     0xd29ce8: add             x23, x23, HEAP, lsl #32
    //     0xd29cec: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a20] "minimumSize"
    //     0xd29cf0: ldr             x16, [x16, #0xa20]
    //     0xd29cf4: cmp             w23, w16
    //     0xd29cf8: b.ne            #0xd29d2c
    //     0xd29cfc: add             w1, w19, #0xa
    //     0xd29d00: add             x16, x4, w1, sxtw #1
    //     0xd29d04: ldur            w19, [x16, #0xf]
    //     0xd29d08: add             x19, x19, HEAP, lsl #32
    //     0xd29d0c: sub             w1, w0, w19
    //     0xd29d10: add             x19, fp, w1, sxtw #2
    //     0xd29d14: ldr             x19, [x19, #8]
    //     0xd29d18: add             w1, w14, #2
    //     0xd29d1c: sbfx            x14, x1, #1, #0x1f
    //     0xd29d20: mov             x1, x14
    //     0xd29d24: mov             x14, x19
    //     0xd29d28: b               #0xd29d30
    //     0xd29d2c: mov             x14, NULL
    //     0xd29d30: stur            x14, [fp, #-0x60]
    //     0xd29d34: lsl             x19, x1, #1
    //     0xd29d38: lsl             w20, w19, #1
    //     0xd29d3c: add             w23, w20, #8
    //     0xd29d40: add             x16, x4, w23, sxtw #1
    //     0xd29d44: ldur            w24, [x16, #0xf]
    //     0xd29d48: add             x24, x24, HEAP, lsl #32
    //     0xd29d4c: add             x16, PP, #0x80, lsl #12  ; [pp+0x80c78] "mouseCursor"
    //     0xd29d50: ldr             x16, [x16, #0xc78]
    //     0xd29d54: cmp             w24, w16
    //     0xd29d58: b.ne            #0xd29d8c
    //     0xd29d5c: add             w1, w20, #0xa
    //     0xd29d60: add             x16, x4, w1, sxtw #1
    //     0xd29d64: ldur            w20, [x16, #0xf]
    //     0xd29d68: add             x20, x20, HEAP, lsl #32
    //     0xd29d6c: sub             w1, w0, w20
    //     0xd29d70: add             x20, fp, w1, sxtw #2
    //     0xd29d74: ldr             x20, [x20, #8]
    //     0xd29d78: add             w1, w19, #2
    //     0xd29d7c: sbfx            x19, x1, #1, #0x1f
    //     0xd29d80: mov             x1, x19
    //     0xd29d84: mov             x19, x20
    //     0xd29d88: b               #0xd29d90
    //     0xd29d8c: mov             x19, NULL
    //     0xd29d90: stur            x19, [fp, #-0x58]
    //     0xd29d94: lsl             x20, x1, #1
    //     0xd29d98: lsl             w23, w20, #1
    //     0xd29d9c: add             w24, w23, #8
    //     0xd29da0: add             x16, x4, w24, sxtw #1
    //     0xd29da4: ldur            w25, [x16, #0xf]
    //     0xd29da8: add             x25, x25, HEAP, lsl #32
    //     0xd29dac: add             x16, PP, #0x80, lsl #12  ; [pp+0x80c80] "overlayColor"
    //     0xd29db0: ldr             x16, [x16, #0xc80]
    //     0xd29db4: cmp             w25, w16
    //     0xd29db8: b.ne            #0xd29dec
    //     0xd29dbc: add             w1, w23, #0xa
    //     0xd29dc0: add             x16, x4, w1, sxtw #1
    //     0xd29dc4: ldur            w23, [x16, #0xf]
    //     0xd29dc8: add             x23, x23, HEAP, lsl #32
    //     0xd29dcc: sub             w1, w0, w23
    //     0xd29dd0: add             x23, fp, w1, sxtw #2
    //     0xd29dd4: ldr             x23, [x23, #8]
    //     0xd29dd8: add             w1, w20, #2
    //     0xd29ddc: sbfx            x20, x1, #1, #0x1f
    //     0xd29de0: mov             x1, x20
    //     0xd29de4: mov             x20, x23
    //     0xd29de8: b               #0xd29df0
    //     0xd29dec: mov             x20, NULL
    //     0xd29df0: stur            x20, [fp, #-0x50]
    //     0xd29df4: lsl             x23, x1, #1
    //     0xd29df8: lsl             w24, w23, #1
    //     0xd29dfc: add             w25, w24, #8
    //     0xd29e00: add             x16, x4, w25, sxtw #1
    //     0xd29e04: ldur            w3, [x16, #0xf]
    //     0xd29e08: add             x3, x3, HEAP, lsl #32
    //     0xd29e0c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12838] "padding"
    //     0xd29e10: ldr             x16, [x16, #0x838]
    //     0xd29e14: cmp             w3, w16
    //     0xd29e18: b.ne            #0xd29e48
    //     0xd29e1c: add             w1, w24, #0xa
    //     0xd29e20: add             x16, x4, w1, sxtw #1
    //     0xd29e24: ldur            w3, [x16, #0xf]
    //     0xd29e28: add             x3, x3, HEAP, lsl #32
    //     0xd29e2c: sub             w1, w0, w3
    //     0xd29e30: add             x3, fp, w1, sxtw #2
    //     0xd29e34: ldr             x3, [x3, #8]
    //     0xd29e38: add             w1, w23, #2
    //     0xd29e3c: sbfx            x23, x1, #1, #0x1f
    //     0xd29e40: mov             x1, x23
    //     0xd29e44: b               #0xd29e4c
    //     0xd29e48: mov             x3, NULL
    //     0xd29e4c: stur            x3, [fp, #-0x10]
    //     0xd29e50: lsl             x23, x1, #1
    //     0xd29e54: lsl             w24, w23, #1
    //     0xd29e58: add             w25, w24, #8
    //     0xd29e5c: add             x16, x4, w25, sxtw #1
    //     0xd29e60: ldur            w3, [x16, #0xf]
    //     0xd29e64: add             x3, x3, HEAP, lsl #32
    //     0xd29e68: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b70] "shadowColor"
    //     0xd29e6c: ldr             x16, [x16, #0xb70]
    //     0xd29e70: cmp             w3, w16
    //     0xd29e74: b.ne            #0xd29ea4
    //     0xd29e78: add             w1, w24, #0xa
    //     0xd29e7c: add             x16, x4, w1, sxtw #1
    //     0xd29e80: ldur            w3, [x16, #0xf]
    //     0xd29e84: add             x3, x3, HEAP, lsl #32
    //     0xd29e88: sub             w1, w0, w3
    //     0xd29e8c: add             x3, fp, w1, sxtw #2
    //     0xd29e90: ldr             x3, [x3, #8]
    //     0xd29e94: add             w1, w23, #2
    //     0xd29e98: sbfx            x23, x1, #1, #0x1f
    //     0xd29e9c: mov             x1, x23
    //     0xd29ea0: b               #0xd29ea8
    //     0xd29ea4: mov             x3, NULL
    //     0xd29ea8: stur            x3, [fp, #-0x18]
    //     0xd29eac: lsl             x23, x1, #1
    //     0xd29eb0: lsl             w24, w23, #1
    //     0xd29eb4: add             w25, w24, #8
    //     0xd29eb8: add             x16, x4, w25, sxtw #1
    //     0xd29ebc: ldur            w3, [x16, #0xf]
    //     0xd29ec0: add             x3, x3, HEAP, lsl #32
    //     0xd29ec4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a28] "shape"
    //     0xd29ec8: ldr             x16, [x16, #0xa28]
    //     0xd29ecc: cmp             w3, w16
    //     0xd29ed0: b.ne            #0xd29f00
    //     0xd29ed4: add             w1, w24, #0xa
    //     0xd29ed8: add             x16, x4, w1, sxtw #1
    //     0xd29edc: ldur            w3, [x16, #0xf]
    //     0xd29ee0: add             x3, x3, HEAP, lsl #32
    //     0xd29ee4: sub             w1, w0, w3
    //     0xd29ee8: add             x3, fp, w1, sxtw #2
    //     0xd29eec: ldr             x3, [x3, #8]
    //     0xd29ef0: add             w1, w23, #2
    //     0xd29ef4: sbfx            x23, x1, #1, #0x1f
    //     0xd29ef8: mov             x1, x23
    //     0xd29efc: b               #0xd29f04
    //     0xd29f00: mov             x3, NULL
    //     0xd29f04: stur            x3, [fp, #-0x20]
    //     0xd29f08: lsl             x23, x1, #1
    //     0xd29f0c: lsl             w24, w23, #1
    //     0xd29f10: add             w25, w24, #8
    //     0xd29f14: add             x16, x4, w25, sxtw #1
    //     0xd29f18: ldur            w3, [x16, #0xf]
    //     0xd29f1c: add             x3, x3, HEAP, lsl #32
    //     0xd29f20: add             x16, PP, #0x80, lsl #12  ; [pp+0x80c88] "side"
    //     0xd29f24: ldr             x16, [x16, #0xc88]
    //     0xd29f28: cmp             w3, w16
    //     0xd29f2c: b.ne            #0xd29f5c
    //     0xd29f30: add             w1, w24, #0xa
    //     0xd29f34: add             x16, x4, w1, sxtw #1
    //     0xd29f38: ldur            w3, [x16, #0xf]
    //     0xd29f3c: add             x3, x3, HEAP, lsl #32
    //     0xd29f40: sub             w1, w0, w3
    //     0xd29f44: add             x3, fp, w1, sxtw #2
    //     0xd29f48: ldr             x3, [x3, #8]
    //     0xd29f4c: add             w1, w23, #2
    //     0xd29f50: sbfx            x23, x1, #1, #0x1f
    //     0xd29f54: mov             x1, x23
    //     0xd29f58: b               #0xd29f60
    //     0xd29f5c: mov             x3, NULL
    //     0xd29f60: stur            x3, [fp, #-0x28]
    //     0xd29f64: lsl             x23, x1, #1
    //     0xd29f68: lsl             w24, w23, #1
    //     0xd29f6c: add             w25, w24, #8
    //     0xd29f70: add             x16, x4, w25, sxtw #1
    //     0xd29f74: ldur            w3, [x16, #0xf]
    //     0xd29f78: add             x3, x3, HEAP, lsl #32
    //     0xd29f7c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b88] "splashFactory"
    //     0xd29f80: ldr             x16, [x16, #0xb88]
    //     0xd29f84: cmp             w3, w16
    //     0xd29f88: b.ne            #0xd29fb8
    //     0xd29f8c: add             w1, w24, #0xa
    //     0xd29f90: add             x16, x4, w1, sxtw #1
    //     0xd29f94: ldur            w3, [x16, #0xf]
    //     0xd29f98: add             x3, x3, HEAP, lsl #32
    //     0xd29f9c: sub             w1, w0, w3
    //     0xd29fa0: add             x3, fp, w1, sxtw #2
    //     0xd29fa4: ldr             x3, [x3, #8]
    //     0xd29fa8: add             w1, w23, #2
    //     0xd29fac: sbfx            x23, x1, #1, #0x1f
    //     0xd29fb0: mov             x1, x23
    //     0xd29fb4: b               #0xd29fbc
    //     0xd29fb8: mov             x3, NULL
    //     0xd29fbc: stur            x3, [fp, #-0x30]
    //     0xd29fc0: lsl             x23, x1, #1
    //     0xd29fc4: lsl             w24, w23, #1
    //     0xd29fc8: add             w25, w24, #8
    //     0xd29fcc: add             x16, x4, w25, sxtw #1
    //     0xd29fd0: ldur            w3, [x16, #0xf]
    //     0xd29fd4: add             x3, x3, HEAP, lsl #32
    //     0xd29fd8: add             x16, PP, #0x18, lsl #12  ; [pp+0x18140] "surfaceTintColor"
    //     0xd29fdc: ldr             x16, [x16, #0x140]
    //     0xd29fe0: cmp             w3, w16
    //     0xd29fe4: b.ne            #0xd2a014
    //     0xd29fe8: add             w1, w24, #0xa
    //     0xd29fec: add             x16, x4, w1, sxtw #1
    //     0xd29ff0: ldur            w3, [x16, #0xf]
    //     0xd29ff4: add             x3, x3, HEAP, lsl #32
    //     0xd29ff8: sub             w1, w0, w3
    //     0xd29ffc: add             x3, fp, w1, sxtw #2
    //     0xd2a000: ldr             x3, [x3, #8]
    //     0xd2a004: add             w1, w23, #2
    //     0xd2a008: sbfx            x23, x1, #1, #0x1f
    //     0xd2a00c: mov             x1, x23
    //     0xd2a010: b               #0xd2a018
    //     0xd2a014: mov             x3, NULL
    //     0xd2a018: stur            x3, [fp, #-0x38]
    //     0xd2a01c: lsl             x23, x1, #1
    //     0xd2a020: lsl             w24, w23, #1
    //     0xd2a024: add             w25, w24, #8
    //     0xd2a028: add             x16, x4, w25, sxtw #1
    //     0xd2a02c: ldur            w3, [x16, #0xf]
    //     0xd2a030: add             x3, x3, HEAP, lsl #32
    //     0xd2a034: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a30] "tapTargetSize"
    //     0xd2a038: ldr             x16, [x16, #0xa30]
    //     0xd2a03c: cmp             w3, w16
    //     0xd2a040: b.ne            #0xd2a070
    //     0xd2a044: add             w1, w24, #0xa
    //     0xd2a048: add             x16, x4, w1, sxtw #1
    //     0xd2a04c: ldur            w3, [x16, #0xf]
    //     0xd2a050: add             x3, x3, HEAP, lsl #32
    //     0xd2a054: sub             w1, w0, w3
    //     0xd2a058: add             x3, fp, w1, sxtw #2
    //     0xd2a05c: ldr             x3, [x3, #8]
    //     0xd2a060: add             w1, w23, #2
    //     0xd2a064: sbfx            x23, x1, #1, #0x1f
    //     0xd2a068: mov             x1, x23
    //     0xd2a06c: b               #0xd2a074
    //     0xd2a070: mov             x3, NULL
    //     0xd2a074: stur            x3, [fp, #-0x40]
    //     0xd2a078: lsl             x23, x1, #1
    //     0xd2a07c: lsl             w24, w23, #1
    //     0xd2a080: add             w25, w24, #8
    //     0xd2a084: add             x16, x4, w25, sxtw #1
    //     0xd2a088: ldur            w3, [x16, #0xf]
    //     0xd2a08c: add             x3, x3, HEAP, lsl #32
    //     0xd2a090: add             x16, PP, #0x13, lsl #12  ; [pp+0x13e08] "textStyle"
    //     0xd2a094: ldr             x16, [x16, #0xe08]
    //     0xd2a098: cmp             w3, w16
    //     0xd2a09c: b.ne            #0xd2a0cc
    //     0xd2a0a0: add             w1, w24, #0xa
    //     0xd2a0a4: add             x16, x4, w1, sxtw #1
    //     0xd2a0a8: ldur            w3, [x16, #0xf]
    //     0xd2a0ac: add             x3, x3, HEAP, lsl #32
    //     0xd2a0b0: sub             w1, w0, w3
    //     0xd2a0b4: add             x3, fp, w1, sxtw #2
    //     0xd2a0b8: ldr             x3, [x3, #8]
    //     0xd2a0bc: add             w1, w23, #2
    //     0xd2a0c0: sbfx            x23, x1, #1, #0x1f
    //     0xd2a0c4: mov             x1, x23
    //     0xd2a0c8: b               #0xd2a0d0
    //     0xd2a0cc: mov             x3, NULL
    //     0xd2a0d0: lsl             x23, x1, #1
    //     0xd2a0d4: lsl             w1, w23, #1
    //     0xd2a0d8: add             w23, w1, #8
    //     0xd2a0dc: add             x16, x4, w23, sxtw #1
    //     0xd2a0e0: ldur            w24, [x16, #0xf]
    //     0xd2a0e4: add             x24, x24, HEAP, lsl #32
    //     0xd2a0e8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a38] "visualDensity"
    //     0xd2a0ec: ldr             x16, [x16, #0xa38]
    //     0xd2a0f0: cmp             w24, w16
    //     0xd2a0f4: b.ne            #0xd2a11c
    //     0xd2a0f8: add             w23, w1, #0xa
    //     0xd2a0fc: add             x16, x4, w23, sxtw #1
    //     0xd2a100: ldur            w1, [x16, #0xf]
    //     0xd2a104: add             x1, x1, HEAP, lsl #32
    //     0xd2a108: sub             w4, w0, w1
    //     0xd2a10c: add             x0, fp, w4, sxtw #2
    //     0xd2a110: ldr             x0, [x0, #8]
    //     0xd2a114: mov             x4, x0
    //     0xd2a118: b               #0xd2a120
    //     0xd2a11c: mov             x4, NULL
    //     0xd2a120: stur            x4, [fp, #-0x48]
    // 0xd2a124: CheckStackOverflow
    //     0xd2a124: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd2a128: cmp             SP, x16
    //     0xd2a12c: b.ls            #0xd2a6c0
    // 0xd2a130: cmp             w3, NULL
    // 0xd2a134: b.ne            #0xd2a158
    // 0xd2a138: r0 = LoadClassIdInstr(r2)
    //     0xd2a138: ldur            x0, [x2, #-1]
    //     0xd2a13c: ubfx            x0, x0, #0xc, #0x14
    // 0xd2a140: mov             x1, x2
    // 0xd2a144: r0 = GDT[cid_x0 + 0xe00]()
    //     0xd2a144: add             lr, x0, #0xe00
    //     0xd2a148: ldr             lr, [x21, lr, lsl #3]
    //     0xd2a14c: blr             lr
    // 0xd2a150: mov             x2, x0
    // 0xd2a154: b               #0xd2a15c
    // 0xd2a158: mov             x2, x3
    // 0xd2a15c: ldur            x0, [fp, #-0xa0]
    // 0xd2a160: stur            x2, [fp, #-0xb8]
    // 0xd2a164: cmp             w0, NULL
    // 0xd2a168: b.ne            #0xd2a190
    // 0xd2a16c: ldur            x3, [fp, #-0xb0]
    // 0xd2a170: r0 = LoadClassIdInstr(r3)
    //     0xd2a170: ldur            x0, [x3, #-1]
    //     0xd2a174: ubfx            x0, x0, #0xc, #0x14
    // 0xd2a178: mov             x1, x3
    // 0xd2a17c: r0 = GDT[cid_x0 + 0xf75]()
    //     0xd2a17c: add             lr, x0, #0xf75
    //     0xd2a180: ldr             lr, [x21, lr, lsl #3]
    //     0xd2a184: blr             lr
    // 0xd2a188: mov             x2, x0
    // 0xd2a18c: b               #0xd2a194
    // 0xd2a190: mov             x2, x0
    // 0xd2a194: ldur            x0, [fp, #-0x80]
    // 0xd2a198: stur            x2, [fp, #-0xa0]
    // 0xd2a19c: cmp             w0, NULL
    // 0xd2a1a0: b.ne            #0xd2a1c8
    // 0xd2a1a4: ldur            x3, [fp, #-0xb0]
    // 0xd2a1a8: r0 = LoadClassIdInstr(r3)
    //     0xd2a1a8: ldur            x0, [x3, #-1]
    //     0xd2a1ac: ubfx            x0, x0, #0xc, #0x14
    // 0xd2a1b0: mov             x1, x3
    // 0xd2a1b4: r0 = GDT[cid_x0 + 0xe62]()
    //     0xd2a1b4: add             lr, x0, #0xe62
    //     0xd2a1b8: ldr             lr, [x21, lr, lsl #3]
    //     0xd2a1bc: blr             lr
    // 0xd2a1c0: mov             x2, x0
    // 0xd2a1c4: b               #0xd2a1cc
    // 0xd2a1c8: mov             x2, x0
    // 0xd2a1cc: ldur            x0, [fp, #-0x50]
    // 0xd2a1d0: stur            x2, [fp, #-0x80]
    // 0xd2a1d4: cmp             w0, NULL
    // 0xd2a1d8: b.ne            #0xd2a200
    // 0xd2a1dc: ldur            x3, [fp, #-0xb0]
    // 0xd2a1e0: r0 = LoadClassIdInstr(r3)
    //     0xd2a1e0: ldur            x0, [x3, #-1]
    //     0xd2a1e4: ubfx            x0, x0, #0xc, #0x14
    // 0xd2a1e8: mov             x1, x3
    // 0xd2a1ec: r0 = GDT[cid_x0 + 0xf41]()
    //     0xd2a1ec: add             lr, x0, #0xf41
    //     0xd2a1f0: ldr             lr, [x21, lr, lsl #3]
    //     0xd2a1f4: blr             lr
    // 0xd2a1f8: mov             x2, x0
    // 0xd2a1fc: b               #0xd2a204
    // 0xd2a200: mov             x2, x0
    // 0xd2a204: ldur            x0, [fp, #-0x18]
    // 0xd2a208: stur            x2, [fp, #-0x50]
    // 0xd2a20c: cmp             w0, NULL
    // 0xd2a210: b.ne            #0xd2a238
    // 0xd2a214: ldur            x3, [fp, #-0xb0]
    // 0xd2a218: r0 = LoadClassIdInstr(r3)
    //     0xd2a218: ldur            x0, [x3, #-1]
    //     0xd2a21c: ubfx            x0, x0, #0xc, #0x14
    // 0xd2a220: mov             x1, x3
    // 0xd2a224: r0 = GDT[cid_x0 + 0xf36]()
    //     0xd2a224: add             lr, x0, #0xf36
    //     0xd2a228: ldr             lr, [x21, lr, lsl #3]
    //     0xd2a22c: blr             lr
    // 0xd2a230: mov             x2, x0
    // 0xd2a234: b               #0xd2a23c
    // 0xd2a238: mov             x2, x0
    // 0xd2a23c: ldur            x0, [fp, #-0x38]
    // 0xd2a240: stur            x2, [fp, #-0x18]
    // 0xd2a244: cmp             w0, NULL
    // 0xd2a248: b.ne            #0xd2a274
    // 0xd2a24c: ldur            x3, [fp, #-0xb0]
    // 0xd2a250: r0 = LoadClassIdInstr(r3)
    //     0xd2a250: ldur            x0, [x3, #-1]
    //     0xd2a254: ubfx            x0, x0, #0xc, #0x14
    // 0xd2a258: mov             x1, x3
    // 0xd2a25c: r0 = GDT[cid_x0 + 0x2930]()
    //     0xd2a25c: mov             x17, #0x2930
    //     0xd2a260: add             lr, x0, x17
    //     0xd2a264: ldr             lr, [x21, lr, lsl #3]
    //     0xd2a268: blr             lr
    // 0xd2a26c: mov             x2, x0
    // 0xd2a270: b               #0xd2a278
    // 0xd2a274: mov             x2, x0
    // 0xd2a278: ldur            x0, [fp, #-0x98]
    // 0xd2a27c: stur            x2, [fp, #-0x38]
    // 0xd2a280: cmp             w0, NULL
    // 0xd2a284: b.ne            #0xd2a2ac
    // 0xd2a288: ldur            x3, [fp, #-0xb0]
    // 0xd2a28c: r0 = LoadClassIdInstr(r3)
    //     0xd2a28c: ldur            x0, [x3, #-1]
    //     0xd2a290: ubfx            x0, x0, #0xc, #0x14
    // 0xd2a294: mov             x1, x3
    // 0xd2a298: r0 = GDT[cid_x0 + 0xea7]()
    //     0xd2a298: add             lr, x0, #0xea7
    //     0xd2a29c: ldr             lr, [x21, lr, lsl #3]
    //     0xd2a2a0: blr             lr
    // 0xd2a2a4: mov             x2, x0
    // 0xd2a2a8: b               #0xd2a2b0
    // 0xd2a2ac: mov             x2, x0
    // 0xd2a2b0: ldur            x0, [fp, #-0x10]
    // 0xd2a2b4: stur            x2, [fp, #-0x98]
    // 0xd2a2b8: cmp             w0, NULL
    // 0xd2a2bc: b.ne            #0xd2a2d4
    // 0xd2a2c0: ldur            x3, [fp, #-0xb0]
    // 0xd2a2c4: LoadField: r0 = r3->field_23
    //     0xd2a2c4: ldur            w0, [x3, #0x23]
    // 0xd2a2c8: DecompressPointer r0
    //     0xd2a2c8: add             x0, x0, HEAP, lsl #32
    // 0xd2a2cc: mov             x4, x0
    // 0xd2a2d0: b               #0xd2a2dc
    // 0xd2a2d4: ldur            x3, [fp, #-0xb0]
    // 0xd2a2d8: mov             x4, x0
    // 0xd2a2dc: ldur            x0, [fp, #-0x60]
    // 0xd2a2e0: stur            x4, [fp, #-0x10]
    // 0xd2a2e4: cmp             w0, NULL
    // 0xd2a2e8: b.ne            #0xd2a310
    // 0xd2a2ec: r0 = LoadClassIdInstr(r3)
    //     0xd2a2ec: ldur            x0, [x3, #-1]
    //     0xd2a2f0: ubfx            x0, x0, #0xc, #0x14
    // 0xd2a2f4: mov             x1, x3
    // 0xd2a2f8: r0 = GDT[cid_x0 + 0x5659]()
    //     0xd2a2f8: mov             x17, #0x5659
    //     0xd2a2fc: add             lr, x0, x17
    //     0xd2a300: ldr             lr, [x21, lr, lsl #3]
    //     0xd2a304: blr             lr
    // 0xd2a308: mov             x2, x0
    // 0xd2a30c: b               #0xd2a314
    // 0xd2a310: mov             x2, x0
    // 0xd2a314: ldur            x0, [fp, #-0x88]
    // 0xd2a318: stur            x2, [fp, #-0xc0]
    // 0xd2a31c: cmp             w0, NULL
    // 0xd2a320: b.ne            #0xd2a338
    // 0xd2a324: ldur            x3, [fp, #-0xb0]
    // 0xd2a328: LoadField: r0 = r3->field_2b
    //     0xd2a328: ldur            w0, [x3, #0x2b]
    // 0xd2a32c: DecompressPointer r0
    //     0xd2a32c: add             x0, x0, HEAP, lsl #32
    // 0xd2a330: mov             x4, x0
    // 0xd2a334: b               #0xd2a340
    // 0xd2a338: ldur            x3, [fp, #-0xb0]
    // 0xd2a33c: mov             x4, x0
    // 0xd2a340: ldur            x0, [fp, #-0x68]
    // 0xd2a344: stur            x4, [fp, #-0x60]
    // 0xd2a348: cmp             w0, NULL
    // 0xd2a34c: b.ne            #0xd2a374
    // 0xd2a350: r0 = LoadClassIdInstr(r3)
    //     0xd2a350: ldur            x0, [x3, #-1]
    //     0xd2a354: ubfx            x0, x0, #0xc, #0x14
    // 0xd2a358: mov             x1, x3
    // 0xd2a35c: r0 = GDT[cid_x0 + 0x5978]()
    //     0xd2a35c: mov             x17, #0x5978
    //     0xd2a360: add             lr, x0, x17
    //     0xd2a364: ldr             lr, [x21, lr, lsl #3]
    //     0xd2a368: blr             lr
    // 0xd2a36c: mov             x2, x0
    // 0xd2a370: b               #0xd2a378
    // 0xd2a374: mov             x2, x0
    // 0xd2a378: ldur            x0, [fp, #-0x78]
    // 0xd2a37c: stur            x2, [fp, #-0x68]
    // 0xd2a380: cmp             w0, NULL
    // 0xd2a384: b.ne            #0xd2a3b0
    // 0xd2a388: ldur            x3, [fp, #-0xb0]
    // 0xd2a38c: r0 = LoadClassIdInstr(r3)
    //     0xd2a38c: ldur            x0, [x3, #-1]
    //     0xd2a390: ubfx            x0, x0, #0xc, #0x14
    // 0xd2a394: mov             x1, x3
    // 0xd2a398: r0 = GDT[cid_x0 + 0x60e5]()
    //     0xd2a398: mov             x17, #0x60e5
    //     0xd2a39c: add             lr, x0, x17
    //     0xd2a3a0: ldr             lr, [x21, lr, lsl #3]
    //     0xd2a3a4: blr             lr
    // 0xd2a3a8: mov             x2, x0
    // 0xd2a3ac: b               #0xd2a3b4
    // 0xd2a3b0: mov             x2, x0
    // 0xd2a3b4: ldur            x0, [fp, #-0x70]
    // 0xd2a3b8: stur            x2, [fp, #-0x78]
    // 0xd2a3bc: cmp             w0, NULL
    // 0xd2a3c0: b.ne            #0xd2a3ec
    // 0xd2a3c4: ldur            x3, [fp, #-0xb0]
    // 0xd2a3c8: r0 = LoadClassIdInstr(r3)
    //     0xd2a3c8: ldur            x0, [x3, #-1]
    //     0xd2a3cc: ubfx            x0, x0, #0xc, #0x14
    // 0xd2a3d0: mov             x1, x3
    // 0xd2a3d4: r0 = GDT[cid_x0 + 0x610d]()
    //     0xd2a3d4: mov             x17, #0x610d
    //     0xd2a3d8: add             lr, x0, x17
    //     0xd2a3dc: ldr             lr, [x21, lr, lsl #3]
    //     0xd2a3e0: blr             lr
    // 0xd2a3e4: mov             x2, x0
    // 0xd2a3e8: b               #0xd2a3f0
    // 0xd2a3ec: mov             x2, x0
    // 0xd2a3f0: ldur            x0, [fp, #-0x28]
    // 0xd2a3f4: stur            x2, [fp, #-0x70]
    // 0xd2a3f8: cmp             w0, NULL
    // 0xd2a3fc: b.ne            #0xd2a428
    // 0xd2a400: ldur            x3, [fp, #-0xb0]
    // 0xd2a404: r0 = LoadClassIdInstr(r3)
    //     0xd2a404: ldur            x0, [x3, #-1]
    //     0xd2a408: ubfx            x0, x0, #0xc, #0x14
    // 0xd2a40c: mov             x1, x3
    // 0xd2a410: r0 = GDT[cid_x0 + 0x3576]()
    //     0xd2a410: mov             x17, #0x3576
    //     0xd2a414: add             lr, x0, x17
    //     0xd2a418: ldr             lr, [x21, lr, lsl #3]
    //     0xd2a41c: blr             lr
    // 0xd2a420: mov             x2, x0
    // 0xd2a424: b               #0xd2a42c
    // 0xd2a428: mov             x2, x0
    // 0xd2a42c: ldur            x0, [fp, #-0x20]
    // 0xd2a430: stur            x2, [fp, #-0x28]
    // 0xd2a434: cmp             w0, NULL
    // 0xd2a438: b.ne            #0xd2a460
    // 0xd2a43c: ldur            x3, [fp, #-0xb0]
    // 0xd2a440: r0 = LoadClassIdInstr(r3)
    //     0xd2a440: ldur            x0, [x3, #-1]
    //     0xd2a444: ubfx            x0, x0, #0xc, #0x14
    // 0xd2a448: mov             x1, x3
    // 0xd2a44c: r0 = GDT[cid_x0 + 0xf2e]()
    //     0xd2a44c: add             lr, x0, #0xf2e
    //     0xd2a450: ldr             lr, [x21, lr, lsl #3]
    //     0xd2a454: blr             lr
    // 0xd2a458: mov             x2, x0
    // 0xd2a45c: b               #0xd2a464
    // 0xd2a460: mov             x2, x0
    // 0xd2a464: ldur            x0, [fp, #-0x58]
    // 0xd2a468: stur            x2, [fp, #-0x20]
    // 0xd2a46c: cmp             w0, NULL
    // 0xd2a470: b.ne            #0xd2a498
    // 0xd2a474: ldur            x3, [fp, #-0xb0]
    // 0xd2a478: r0 = LoadClassIdInstr(r3)
    //     0xd2a478: ldur            x0, [x3, #-1]
    //     0xd2a47c: ubfx            x0, x0, #0xc, #0x14
    // 0xd2a480: mov             x1, x3
    // 0xd2a484: r0 = GDT[cid_x0 + 0xf13]()
    //     0xd2a484: add             lr, x0, #0xf13
    //     0xd2a488: ldr             lr, [x21, lr, lsl #3]
    //     0xd2a48c: blr             lr
    // 0xd2a490: mov             x2, x0
    // 0xd2a494: b               #0xd2a49c
    // 0xd2a498: mov             x2, x0
    // 0xd2a49c: ldur            x0, [fp, #-0x48]
    // 0xd2a4a0: stur            x2, [fp, #-0x58]
    // 0xd2a4a4: cmp             w0, NULL
    // 0xd2a4a8: b.ne            #0xd2a4d0
    // 0xd2a4ac: ldur            x3, [fp, #-0xb0]
    // 0xd2a4b0: r0 = LoadClassIdInstr(r3)
    //     0xd2a4b0: ldur            x0, [x3, #-1]
    //     0xd2a4b4: ubfx            x0, x0, #0xc, #0x14
    // 0xd2a4b8: mov             x1, x3
    // 0xd2a4bc: r0 = GDT[cid_x0 + 0xef9]()
    //     0xd2a4bc: add             lr, x0, #0xef9
    //     0xd2a4c0: ldr             lr, [x21, lr, lsl #3]
    //     0xd2a4c4: blr             lr
    // 0xd2a4c8: mov             x2, x0
    // 0xd2a4cc: b               #0xd2a4d4
    // 0xd2a4d0: mov             x2, x0
    // 0xd2a4d4: ldur            x0, [fp, #-0x40]
    // 0xd2a4d8: stur            x2, [fp, #-0x48]
    // 0xd2a4dc: cmp             w0, NULL
    // 0xd2a4e0: b.ne            #0xd2a508
    // 0xd2a4e4: ldur            x3, [fp, #-0xb0]
    // 0xd2a4e8: r0 = LoadClassIdInstr(r3)
    //     0xd2a4e8: ldur            x0, [x3, #-1]
    //     0xd2a4ec: ubfx            x0, x0, #0xc, #0x14
    // 0xd2a4f0: mov             x1, x3
    // 0xd2a4f4: r0 = GDT[cid_x0 + 0xef1]()
    //     0xd2a4f4: add             lr, x0, #0xef1
    //     0xd2a4f8: ldr             lr, [x21, lr, lsl #3]
    //     0xd2a4fc: blr             lr
    // 0xd2a500: mov             x2, x0
    // 0xd2a504: b               #0xd2a50c
    // 0xd2a508: mov             x2, x0
    // 0xd2a50c: ldur            x0, [fp, #-0xa8]
    // 0xd2a510: stur            x2, [fp, #-0xc8]
    // 0xd2a514: cmp             w0, NULL
    // 0xd2a518: b.ne            #0xd2a530
    // 0xd2a51c: ldur            x1, [fp, #-0xb0]
    // 0xd2a520: LoadField: r0 = r1->field_53
    //     0xd2a520: ldur            w0, [x1, #0x53]
    // 0xd2a524: DecompressPointer r0
    //     0xd2a524: add             x0, x0, HEAP, lsl #32
    // 0xd2a528: mov             x3, x0
    // 0xd2a52c: b               #0xd2a538
    // 0xd2a530: ldur            x1, [fp, #-0xb0]
    // 0xd2a534: mov             x3, x0
    // 0xd2a538: ldur            x0, [fp, #-0x90]
    // 0xd2a53c: stur            x3, [fp, #-0x88]
    // 0xd2a540: cmp             w0, NULL
    // 0xd2a544: b.ne            #0xd2a558
    // 0xd2a548: LoadField: r0 = r1->field_57
    //     0xd2a548: ldur            w0, [x1, #0x57]
    // 0xd2a54c: DecompressPointer r0
    //     0xd2a54c: add             x0, x0, HEAP, lsl #32
    // 0xd2a550: mov             x4, x0
    // 0xd2a554: b               #0xd2a55c
    // 0xd2a558: mov             x4, x0
    // 0xd2a55c: ldur            x0, [fp, #-8]
    // 0xd2a560: stur            x4, [fp, #-0x40]
    // 0xd2a564: cmp             w0, NULL
    // 0xd2a568: b.ne            #0xd2a57c
    // 0xd2a56c: LoadField: r0 = r1->field_5b
    //     0xd2a56c: ldur            w0, [x1, #0x5b]
    // 0xd2a570: DecompressPointer r0
    //     0xd2a570: add             x0, x0, HEAP, lsl #32
    // 0xd2a574: mov             x5, x0
    // 0xd2a578: b               #0xd2a580
    // 0xd2a57c: mov             x5, x0
    // 0xd2a580: ldur            x0, [fp, #-0x30]
    // 0xd2a584: stur            x5, [fp, #-8]
    // 0xd2a588: cmp             w0, NULL
    // 0xd2a58c: b.ne            #0xd2a5ac
    // 0xd2a590: r0 = LoadClassIdInstr(r1)
    //     0xd2a590: ldur            x0, [x1, #-1]
    //     0xd2a594: ubfx            x0, x0, #0xc, #0x14
    // 0xd2a598: r0 = GDT[cid_x0 + 0xed5]()
    //     0xd2a598: add             lr, x0, #0xed5
    //     0xd2a59c: ldr             lr, [x21, lr, lsl #3]
    //     0xd2a5a0: blr             lr
    // 0xd2a5a4: stur            x0, [fp, #-0x30]
    // 0xd2a5a8: b               #0xd2a5b0
    // 0xd2a5ac: stur            x0, [fp, #-0x30]
    // 0xd2a5b0: ldur            x25, [fp, #-0xa0]
    // 0xd2a5b4: ldur            x24, [fp, #-0x80]
    // 0xd2a5b8: ldur            x23, [fp, #-0x50]
    // 0xd2a5bc: ldur            x20, [fp, #-0x18]
    // 0xd2a5c0: ldur            x19, [fp, #-0x38]
    // 0xd2a5c4: ldur            x13, [fp, #-0x98]
    // 0xd2a5c8: ldur            x14, [fp, #-0x10]
    // 0xd2a5cc: ldur            x11, [fp, #-0xc0]
    // 0xd2a5d0: ldur            x12, [fp, #-0x60]
    // 0xd2a5d4: ldur            x10, [fp, #-0x68]
    // 0xd2a5d8: ldur            x9, [fp, #-0x78]
    // 0xd2a5dc: ldur            x8, [fp, #-0x70]
    // 0xd2a5e0: ldur            x7, [fp, #-0x28]
    // 0xd2a5e4: ldur            x6, [fp, #-0x20]
    // 0xd2a5e8: ldur            x5, [fp, #-0x58]
    // 0xd2a5ec: ldur            x4, [fp, #-0x48]
    // 0xd2a5f0: ldur            x0, [fp, #-0xc8]
    // 0xd2a5f4: ldur            x1, [fp, #-0x88]
    // 0xd2a5f8: ldur            x2, [fp, #-0x40]
    // 0xd2a5fc: ldur            x3, [fp, #-8]
    // 0xd2a600: r0 = ButtonStyle()
    //     0xd2a600: bl              #0xd17184  ; AllocateButtonStyleStub -> ButtonStyle (size=0x6c)
    // 0xd2a604: ldur            x1, [fp, #-0xb8]
    // 0xd2a608: StoreField: r0->field_7 = r1
    //     0xd2a608: stur            w1, [x0, #7]
    // 0xd2a60c: ldur            x1, [fp, #-0xa0]
    // 0xd2a610: StoreField: r0->field_b = r1
    //     0xd2a610: stur            w1, [x0, #0xb]
    // 0xd2a614: ldur            x1, [fp, #-0x80]
    // 0xd2a618: StoreField: r0->field_f = r1
    //     0xd2a618: stur            w1, [x0, #0xf]
    // 0xd2a61c: ldur            x1, [fp, #-0x50]
    // 0xd2a620: StoreField: r0->field_13 = r1
    //     0xd2a620: stur            w1, [x0, #0x13]
    // 0xd2a624: ldur            x1, [fp, #-0x18]
    // 0xd2a628: ArrayStore: r0[0] = r1  ; List_4
    //     0xd2a628: stur            w1, [x0, #0x17]
    // 0xd2a62c: ldur            x1, [fp, #-0x38]
    // 0xd2a630: StoreField: r0->field_1b = r1
    //     0xd2a630: stur            w1, [x0, #0x1b]
    // 0xd2a634: ldur            x1, [fp, #-0x98]
    // 0xd2a638: StoreField: r0->field_1f = r1
    //     0xd2a638: stur            w1, [x0, #0x1f]
    // 0xd2a63c: ldur            x1, [fp, #-0x10]
    // 0xd2a640: StoreField: r0->field_23 = r1
    //     0xd2a640: stur            w1, [x0, #0x23]
    // 0xd2a644: ldur            x1, [fp, #-0xc0]
    // 0xd2a648: StoreField: r0->field_27 = r1
    //     0xd2a648: stur            w1, [x0, #0x27]
    // 0xd2a64c: ldur            x1, [fp, #-0x60]
    // 0xd2a650: StoreField: r0->field_2b = r1
    //     0xd2a650: stur            w1, [x0, #0x2b]
    // 0xd2a654: ldur            x1, [fp, #-0x68]
    // 0xd2a658: StoreField: r0->field_2f = r1
    //     0xd2a658: stur            w1, [x0, #0x2f]
    // 0xd2a65c: ldur            x1, [fp, #-0x78]
    // 0xd2a660: StoreField: r0->field_33 = r1
    //     0xd2a660: stur            w1, [x0, #0x33]
    // 0xd2a664: ldur            x1, [fp, #-0x70]
    // 0xd2a668: StoreField: r0->field_37 = r1
    //     0xd2a668: stur            w1, [x0, #0x37]
    // 0xd2a66c: ldur            x1, [fp, #-0x28]
    // 0xd2a670: StoreField: r0->field_3f = r1
    //     0xd2a670: stur            w1, [x0, #0x3f]
    // 0xd2a674: ldur            x1, [fp, #-0x20]
    // 0xd2a678: StoreField: r0->field_43 = r1
    //     0xd2a678: stur            w1, [x0, #0x43]
    // 0xd2a67c: ldur            x1, [fp, #-0x58]
    // 0xd2a680: StoreField: r0->field_47 = r1
    //     0xd2a680: stur            w1, [x0, #0x47]
    // 0xd2a684: ldur            x1, [fp, #-0x48]
    // 0xd2a688: StoreField: r0->field_4b = r1
    //     0xd2a688: stur            w1, [x0, #0x4b]
    // 0xd2a68c: ldur            x1, [fp, #-0xc8]
    // 0xd2a690: StoreField: r0->field_4f = r1
    //     0xd2a690: stur            w1, [x0, #0x4f]
    // 0xd2a694: ldur            x1, [fp, #-0x88]
    // 0xd2a698: StoreField: r0->field_53 = r1
    //     0xd2a698: stur            w1, [x0, #0x53]
    // 0xd2a69c: ldur            x1, [fp, #-0x40]
    // 0xd2a6a0: StoreField: r0->field_57 = r1
    //     0xd2a6a0: stur            w1, [x0, #0x57]
    // 0xd2a6a4: ldur            x1, [fp, #-8]
    // 0xd2a6a8: StoreField: r0->field_5b = r1
    //     0xd2a6a8: stur            w1, [x0, #0x5b]
    // 0xd2a6ac: ldur            x1, [fp, #-0x30]
    // 0xd2a6b0: StoreField: r0->field_5f = r1
    //     0xd2a6b0: stur            w1, [x0, #0x5f]
    // 0xd2a6b4: LeaveFrame
    //     0xd2a6b4: mov             SP, fp
    //     0xd2a6b8: ldp             fp, lr, [SP], #0x10
    // 0xd2a6bc: ret
    //     0xd2a6bc: ret             
    // 0xd2a6c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd2a6c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd2a6c4: b               #0xd2a130
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x112f2a8, size: 0x610
    // 0x112f2a8: EnterFrame
    //     0x112f2a8: stp             fp, lr, [SP, #-0x10]!
    //     0x112f2ac: mov             fp, SP
    // 0x112f2b0: AllocStack(0x10)
    //     0x112f2b0: sub             SP, SP, #0x10
    // 0x112f2b4: CheckStackOverflow
    //     0x112f2b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112f2b8: cmp             SP, x16
    //     0x112f2bc: b.ls            #0x112f8b0
    // 0x112f2c0: ldr             x2, [fp, #0x10]
    // 0x112f2c4: r0 = LoadClassIdInstr(r2)
    //     0x112f2c4: ldur            x0, [x2, #-1]
    //     0x112f2c8: ubfx            x0, x0, #0xc, #0x14
    // 0x112f2cc: mov             x1, x2
    // 0x112f2d0: r0 = GDT[cid_x0 + 0xe00]()
    //     0x112f2d0: add             lr, x0, #0xe00
    //     0x112f2d4: ldr             lr, [x21, lr, lsl #3]
    //     0x112f2d8: blr             lr
    // 0x112f2dc: r1 = <Object?>
    //     0x112f2dc: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x112f2e0: r2 = 50
    //     0x112f2e0: mov             x2, #0x32
    // 0x112f2e4: stur            x0, [fp, #-8]
    // 0x112f2e8: r0 = AllocateArray()
    //     0x112f2e8: bl              #0x13df928  ; AllocateArrayStub
    // 0x112f2ec: mov             x2, x0
    // 0x112f2f0: ldur            x0, [fp, #-8]
    // 0x112f2f4: stur            x2, [fp, #-0x10]
    // 0x112f2f8: StoreField: r2->field_f = r0
    //     0x112f2f8: stur            w0, [x2, #0xf]
    // 0x112f2fc: ldr             x3, [fp, #0x10]
    // 0x112f300: r0 = LoadClassIdInstr(r3)
    //     0x112f300: ldur            x0, [x3, #-1]
    //     0x112f304: ubfx            x0, x0, #0xc, #0x14
    // 0x112f308: mov             x1, x3
    // 0x112f30c: r0 = GDT[cid_x0 + 0xf75]()
    //     0x112f30c: add             lr, x0, #0xf75
    //     0x112f310: ldr             lr, [x21, lr, lsl #3]
    //     0x112f314: blr             lr
    // 0x112f318: ldur            x1, [fp, #-0x10]
    // 0x112f31c: ArrayStore: r1[1] = r0  ; List_4
    //     0x112f31c: add             x25, x1, #0x13
    //     0x112f320: str             w0, [x25]
    //     0x112f324: tbz             w0, #0, #0x112f340
    //     0x112f328: ldurb           w16, [x1, #-1]
    //     0x112f32c: ldurb           w17, [x0, #-1]
    //     0x112f330: and             x16, x17, x16, lsr #2
    //     0x112f334: tst             x16, HEAP, lsr #32
    //     0x112f338: b.eq            #0x112f340
    //     0x112f33c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x112f340: ldr             x2, [fp, #0x10]
    // 0x112f344: r0 = LoadClassIdInstr(r2)
    //     0x112f344: ldur            x0, [x2, #-1]
    //     0x112f348: ubfx            x0, x0, #0xc, #0x14
    // 0x112f34c: mov             x1, x2
    // 0x112f350: r0 = GDT[cid_x0 + 0xe62]()
    //     0x112f350: add             lr, x0, #0xe62
    //     0x112f354: ldr             lr, [x21, lr, lsl #3]
    //     0x112f358: blr             lr
    // 0x112f35c: ldur            x1, [fp, #-0x10]
    // 0x112f360: ArrayStore: r1[2] = r0  ; List_4
    //     0x112f360: add             x25, x1, #0x17
    //     0x112f364: str             w0, [x25]
    //     0x112f368: tbz             w0, #0, #0x112f384
    //     0x112f36c: ldurb           w16, [x1, #-1]
    //     0x112f370: ldurb           w17, [x0, #-1]
    //     0x112f374: and             x16, x17, x16, lsr #2
    //     0x112f378: tst             x16, HEAP, lsr #32
    //     0x112f37c: b.eq            #0x112f384
    //     0x112f380: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x112f384: ldr             x2, [fp, #0x10]
    // 0x112f388: r0 = LoadClassIdInstr(r2)
    //     0x112f388: ldur            x0, [x2, #-1]
    //     0x112f38c: ubfx            x0, x0, #0xc, #0x14
    // 0x112f390: mov             x1, x2
    // 0x112f394: r0 = GDT[cid_x0 + 0xf41]()
    //     0x112f394: add             lr, x0, #0xf41
    //     0x112f398: ldr             lr, [x21, lr, lsl #3]
    //     0x112f39c: blr             lr
    // 0x112f3a0: ldur            x1, [fp, #-0x10]
    // 0x112f3a4: ArrayStore: r1[3] = r0  ; List_4
    //     0x112f3a4: add             x25, x1, #0x1b
    //     0x112f3a8: str             w0, [x25]
    //     0x112f3ac: tbz             w0, #0, #0x112f3c8
    //     0x112f3b0: ldurb           w16, [x1, #-1]
    //     0x112f3b4: ldurb           w17, [x0, #-1]
    //     0x112f3b8: and             x16, x17, x16, lsr #2
    //     0x112f3bc: tst             x16, HEAP, lsr #32
    //     0x112f3c0: b.eq            #0x112f3c8
    //     0x112f3c4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x112f3c8: ldr             x2, [fp, #0x10]
    // 0x112f3cc: r0 = LoadClassIdInstr(r2)
    //     0x112f3cc: ldur            x0, [x2, #-1]
    //     0x112f3d0: ubfx            x0, x0, #0xc, #0x14
    // 0x112f3d4: mov             x1, x2
    // 0x112f3d8: r0 = GDT[cid_x0 + 0xf36]()
    //     0x112f3d8: add             lr, x0, #0xf36
    //     0x112f3dc: ldr             lr, [x21, lr, lsl #3]
    //     0x112f3e0: blr             lr
    // 0x112f3e4: ldur            x1, [fp, #-0x10]
    // 0x112f3e8: ArrayStore: r1[4] = r0  ; List_4
    //     0x112f3e8: add             x25, x1, #0x1f
    //     0x112f3ec: str             w0, [x25]
    //     0x112f3f0: tbz             w0, #0, #0x112f40c
    //     0x112f3f4: ldurb           w16, [x1, #-1]
    //     0x112f3f8: ldurb           w17, [x0, #-1]
    //     0x112f3fc: and             x16, x17, x16, lsr #2
    //     0x112f400: tst             x16, HEAP, lsr #32
    //     0x112f404: b.eq            #0x112f40c
    //     0x112f408: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x112f40c: ldr             x2, [fp, #0x10]
    // 0x112f410: r0 = LoadClassIdInstr(r2)
    //     0x112f410: ldur            x0, [x2, #-1]
    //     0x112f414: ubfx            x0, x0, #0xc, #0x14
    // 0x112f418: mov             x1, x2
    // 0x112f41c: r0 = GDT[cid_x0 + 0x2930]()
    //     0x112f41c: mov             x17, #0x2930
    //     0x112f420: add             lr, x0, x17
    //     0x112f424: ldr             lr, [x21, lr, lsl #3]
    //     0x112f428: blr             lr
    // 0x112f42c: ldur            x1, [fp, #-0x10]
    // 0x112f430: ArrayStore: r1[5] = r0  ; List_4
    //     0x112f430: add             x25, x1, #0x23
    //     0x112f434: str             w0, [x25]
    //     0x112f438: tbz             w0, #0, #0x112f454
    //     0x112f43c: ldurb           w16, [x1, #-1]
    //     0x112f440: ldurb           w17, [x0, #-1]
    //     0x112f444: and             x16, x17, x16, lsr #2
    //     0x112f448: tst             x16, HEAP, lsr #32
    //     0x112f44c: b.eq            #0x112f454
    //     0x112f450: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x112f454: ldr             x2, [fp, #0x10]
    // 0x112f458: r0 = LoadClassIdInstr(r2)
    //     0x112f458: ldur            x0, [x2, #-1]
    //     0x112f45c: ubfx            x0, x0, #0xc, #0x14
    // 0x112f460: mov             x1, x2
    // 0x112f464: r0 = GDT[cid_x0 + 0xea7]()
    //     0x112f464: add             lr, x0, #0xea7
    //     0x112f468: ldr             lr, [x21, lr, lsl #3]
    //     0x112f46c: blr             lr
    // 0x112f470: ldur            x1, [fp, #-0x10]
    // 0x112f474: ArrayStore: r1[6] = r0  ; List_4
    //     0x112f474: add             x25, x1, #0x27
    //     0x112f478: str             w0, [x25]
    //     0x112f47c: tbz             w0, #0, #0x112f498
    //     0x112f480: ldurb           w16, [x1, #-1]
    //     0x112f484: ldurb           w17, [x0, #-1]
    //     0x112f488: and             x16, x17, x16, lsr #2
    //     0x112f48c: tst             x16, HEAP, lsr #32
    //     0x112f490: b.eq            #0x112f498
    //     0x112f494: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x112f498: ldr             x2, [fp, #0x10]
    // 0x112f49c: r0 = LoadClassIdInstr(r2)
    //     0x112f49c: ldur            x0, [x2, #-1]
    //     0x112f4a0: ubfx            x0, x0, #0xc, #0x14
    // 0x112f4a4: mov             x1, x2
    // 0x112f4a8: r0 = GDT[cid_x0 + 0x6f31]()
    //     0x112f4a8: mov             x17, #0x6f31
    //     0x112f4ac: add             lr, x0, x17
    //     0x112f4b0: ldr             lr, [x21, lr, lsl #3]
    //     0x112f4b4: blr             lr
    // 0x112f4b8: ldur            x1, [fp, #-0x10]
    // 0x112f4bc: ArrayStore: r1[7] = r0  ; List_4
    //     0x112f4bc: add             x25, x1, #0x2b
    //     0x112f4c0: str             w0, [x25]
    //     0x112f4c4: tbz             w0, #0, #0x112f4e0
    //     0x112f4c8: ldurb           w16, [x1, #-1]
    //     0x112f4cc: ldurb           w17, [x0, #-1]
    //     0x112f4d0: and             x16, x17, x16, lsr #2
    //     0x112f4d4: tst             x16, HEAP, lsr #32
    //     0x112f4d8: b.eq            #0x112f4e0
    //     0x112f4dc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x112f4e0: ldr             x2, [fp, #0x10]
    // 0x112f4e4: r0 = LoadClassIdInstr(r2)
    //     0x112f4e4: ldur            x0, [x2, #-1]
    //     0x112f4e8: ubfx            x0, x0, #0xc, #0x14
    // 0x112f4ec: mov             x1, x2
    // 0x112f4f0: r0 = GDT[cid_x0 + 0x5659]()
    //     0x112f4f0: mov             x17, #0x5659
    //     0x112f4f4: add             lr, x0, x17
    //     0x112f4f8: ldr             lr, [x21, lr, lsl #3]
    //     0x112f4fc: blr             lr
    // 0x112f500: ldur            x1, [fp, #-0x10]
    // 0x112f504: ArrayStore: r1[8] = r0  ; List_4
    //     0x112f504: add             x25, x1, #0x2f
    //     0x112f508: str             w0, [x25]
    //     0x112f50c: tbz             w0, #0, #0x112f528
    //     0x112f510: ldurb           w16, [x1, #-1]
    //     0x112f514: ldurb           w17, [x0, #-1]
    //     0x112f518: and             x16, x17, x16, lsr #2
    //     0x112f51c: tst             x16, HEAP, lsr #32
    //     0x112f520: b.eq            #0x112f528
    //     0x112f524: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x112f528: ldr             x2, [fp, #0x10]
    // 0x112f52c: LoadField: r0 = r2->field_2b
    //     0x112f52c: ldur            w0, [x2, #0x2b]
    // 0x112f530: DecompressPointer r0
    //     0x112f530: add             x0, x0, HEAP, lsl #32
    // 0x112f534: ldur            x1, [fp, #-0x10]
    // 0x112f538: ArrayStore: r1[9] = r0  ; List_4
    //     0x112f538: add             x25, x1, #0x33
    //     0x112f53c: str             w0, [x25]
    //     0x112f540: tbz             w0, #0, #0x112f55c
    //     0x112f544: ldurb           w16, [x1, #-1]
    //     0x112f548: ldurb           w17, [x0, #-1]
    //     0x112f54c: and             x16, x17, x16, lsr #2
    //     0x112f550: tst             x16, HEAP, lsr #32
    //     0x112f554: b.eq            #0x112f55c
    //     0x112f558: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x112f55c: r0 = LoadClassIdInstr(r2)
    //     0x112f55c: ldur            x0, [x2, #-1]
    //     0x112f560: ubfx            x0, x0, #0xc, #0x14
    // 0x112f564: mov             x1, x2
    // 0x112f568: r0 = GDT[cid_x0 + 0x5978]()
    //     0x112f568: mov             x17, #0x5978
    //     0x112f56c: add             lr, x0, x17
    //     0x112f570: ldr             lr, [x21, lr, lsl #3]
    //     0x112f574: blr             lr
    // 0x112f578: ldur            x1, [fp, #-0x10]
    // 0x112f57c: ArrayStore: r1[10] = r0  ; List_4
    //     0x112f57c: add             x25, x1, #0x37
    //     0x112f580: str             w0, [x25]
    //     0x112f584: tbz             w0, #0, #0x112f5a0
    //     0x112f588: ldurb           w16, [x1, #-1]
    //     0x112f58c: ldurb           w17, [x0, #-1]
    //     0x112f590: and             x16, x17, x16, lsr #2
    //     0x112f594: tst             x16, HEAP, lsr #32
    //     0x112f598: b.eq            #0x112f5a0
    //     0x112f59c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x112f5a0: ldr             x2, [fp, #0x10]
    // 0x112f5a4: r0 = LoadClassIdInstr(r2)
    //     0x112f5a4: ldur            x0, [x2, #-1]
    //     0x112f5a8: ubfx            x0, x0, #0xc, #0x14
    // 0x112f5ac: mov             x1, x2
    // 0x112f5b0: r0 = GDT[cid_x0 + 0x60e5]()
    //     0x112f5b0: mov             x17, #0x60e5
    //     0x112f5b4: add             lr, x0, x17
    //     0x112f5b8: ldr             lr, [x21, lr, lsl #3]
    //     0x112f5bc: blr             lr
    // 0x112f5c0: ldur            x1, [fp, #-0x10]
    // 0x112f5c4: ArrayStore: r1[11] = r0  ; List_4
    //     0x112f5c4: add             x25, x1, #0x3b
    //     0x112f5c8: str             w0, [x25]
    //     0x112f5cc: tbz             w0, #0, #0x112f5e8
    //     0x112f5d0: ldurb           w16, [x1, #-1]
    //     0x112f5d4: ldurb           w17, [x0, #-1]
    //     0x112f5d8: and             x16, x17, x16, lsr #2
    //     0x112f5dc: tst             x16, HEAP, lsr #32
    //     0x112f5e0: b.eq            #0x112f5e8
    //     0x112f5e4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x112f5e8: ldr             x2, [fp, #0x10]
    // 0x112f5ec: r0 = LoadClassIdInstr(r2)
    //     0x112f5ec: ldur            x0, [x2, #-1]
    //     0x112f5f0: ubfx            x0, x0, #0xc, #0x14
    // 0x112f5f4: mov             x1, x2
    // 0x112f5f8: r0 = GDT[cid_x0 + 0x610d]()
    //     0x112f5f8: mov             x17, #0x610d
    //     0x112f5fc: add             lr, x0, x17
    //     0x112f600: ldr             lr, [x21, lr, lsl #3]
    //     0x112f604: blr             lr
    // 0x112f608: ldur            x1, [fp, #-0x10]
    // 0x112f60c: ArrayStore: r1[12] = r0  ; List_4
    //     0x112f60c: add             x25, x1, #0x3f
    //     0x112f610: str             w0, [x25]
    //     0x112f614: tbz             w0, #0, #0x112f630
    //     0x112f618: ldurb           w16, [x1, #-1]
    //     0x112f61c: ldurb           w17, [x0, #-1]
    //     0x112f620: and             x16, x17, x16, lsr #2
    //     0x112f624: tst             x16, HEAP, lsr #32
    //     0x112f628: b.eq            #0x112f630
    //     0x112f62c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x112f630: ldr             x2, [fp, #0x10]
    // 0x112f634: LoadField: r0 = r2->field_3b
    //     0x112f634: ldur            w0, [x2, #0x3b]
    // 0x112f638: DecompressPointer r0
    //     0x112f638: add             x0, x0, HEAP, lsl #32
    // 0x112f63c: ldur            x3, [fp, #-0x10]
    // 0x112f640: StoreField: r3->field_43 = r0
    //     0x112f640: stur            w0, [x3, #0x43]
    // 0x112f644: r0 = LoadClassIdInstr(r2)
    //     0x112f644: ldur            x0, [x2, #-1]
    //     0x112f648: ubfx            x0, x0, #0xc, #0x14
    // 0x112f64c: mov             x1, x2
    // 0x112f650: r0 = GDT[cid_x0 + 0x3576]()
    //     0x112f650: mov             x17, #0x3576
    //     0x112f654: add             lr, x0, x17
    //     0x112f658: ldr             lr, [x21, lr, lsl #3]
    //     0x112f65c: blr             lr
    // 0x112f660: ldur            x1, [fp, #-0x10]
    // 0x112f664: ArrayStore: r1[14] = r0  ; List_4
    //     0x112f664: add             x25, x1, #0x47
    //     0x112f668: str             w0, [x25]
    //     0x112f66c: tbz             w0, #0, #0x112f688
    //     0x112f670: ldurb           w16, [x1, #-1]
    //     0x112f674: ldurb           w17, [x0, #-1]
    //     0x112f678: and             x16, x17, x16, lsr #2
    //     0x112f67c: tst             x16, HEAP, lsr #32
    //     0x112f680: b.eq            #0x112f688
    //     0x112f684: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x112f688: ldr             x2, [fp, #0x10]
    // 0x112f68c: r0 = LoadClassIdInstr(r2)
    //     0x112f68c: ldur            x0, [x2, #-1]
    //     0x112f690: ubfx            x0, x0, #0xc, #0x14
    // 0x112f694: mov             x1, x2
    // 0x112f698: r0 = GDT[cid_x0 + 0xf2e]()
    //     0x112f698: add             lr, x0, #0xf2e
    //     0x112f69c: ldr             lr, [x21, lr, lsl #3]
    //     0x112f6a0: blr             lr
    // 0x112f6a4: ldur            x1, [fp, #-0x10]
    // 0x112f6a8: ArrayStore: r1[15] = r0  ; List_4
    //     0x112f6a8: add             x25, x1, #0x4b
    //     0x112f6ac: str             w0, [x25]
    //     0x112f6b0: tbz             w0, #0, #0x112f6cc
    //     0x112f6b4: ldurb           w16, [x1, #-1]
    //     0x112f6b8: ldurb           w17, [x0, #-1]
    //     0x112f6bc: and             x16, x17, x16, lsr #2
    //     0x112f6c0: tst             x16, HEAP, lsr #32
    //     0x112f6c4: b.eq            #0x112f6cc
    //     0x112f6c8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x112f6cc: ldr             x2, [fp, #0x10]
    // 0x112f6d0: r0 = LoadClassIdInstr(r2)
    //     0x112f6d0: ldur            x0, [x2, #-1]
    //     0x112f6d4: ubfx            x0, x0, #0xc, #0x14
    // 0x112f6d8: mov             x1, x2
    // 0x112f6dc: r0 = GDT[cid_x0 + 0xf13]()
    //     0x112f6dc: add             lr, x0, #0xf13
    //     0x112f6e0: ldr             lr, [x21, lr, lsl #3]
    //     0x112f6e4: blr             lr
    // 0x112f6e8: ldur            x1, [fp, #-0x10]
    // 0x112f6ec: ArrayStore: r1[16] = r0  ; List_4
    //     0x112f6ec: add             x25, x1, #0x4f
    //     0x112f6f0: str             w0, [x25]
    //     0x112f6f4: tbz             w0, #0, #0x112f710
    //     0x112f6f8: ldurb           w16, [x1, #-1]
    //     0x112f6fc: ldurb           w17, [x0, #-1]
    //     0x112f700: and             x16, x17, x16, lsr #2
    //     0x112f704: tst             x16, HEAP, lsr #32
    //     0x112f708: b.eq            #0x112f710
    //     0x112f70c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x112f710: ldr             x2, [fp, #0x10]
    // 0x112f714: r0 = LoadClassIdInstr(r2)
    //     0x112f714: ldur            x0, [x2, #-1]
    //     0x112f718: ubfx            x0, x0, #0xc, #0x14
    // 0x112f71c: mov             x1, x2
    // 0x112f720: r0 = GDT[cid_x0 + 0xef9]()
    //     0x112f720: add             lr, x0, #0xef9
    //     0x112f724: ldr             lr, [x21, lr, lsl #3]
    //     0x112f728: blr             lr
    // 0x112f72c: ldur            x1, [fp, #-0x10]
    // 0x112f730: ArrayStore: r1[17] = r0  ; List_4
    //     0x112f730: add             x25, x1, #0x53
    //     0x112f734: str             w0, [x25]
    //     0x112f738: tbz             w0, #0, #0x112f754
    //     0x112f73c: ldurb           w16, [x1, #-1]
    //     0x112f740: ldurb           w17, [x0, #-1]
    //     0x112f744: and             x16, x17, x16, lsr #2
    //     0x112f748: tst             x16, HEAP, lsr #32
    //     0x112f74c: b.eq            #0x112f754
    //     0x112f750: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x112f754: ldr             x2, [fp, #0x10]
    // 0x112f758: r0 = LoadClassIdInstr(r2)
    //     0x112f758: ldur            x0, [x2, #-1]
    //     0x112f75c: ubfx            x0, x0, #0xc, #0x14
    // 0x112f760: mov             x1, x2
    // 0x112f764: r0 = GDT[cid_x0 + 0xef1]()
    //     0x112f764: add             lr, x0, #0xef1
    //     0x112f768: ldr             lr, [x21, lr, lsl #3]
    //     0x112f76c: blr             lr
    // 0x112f770: ldur            x1, [fp, #-0x10]
    // 0x112f774: ArrayStore: r1[18] = r0  ; List_4
    //     0x112f774: add             x25, x1, #0x57
    //     0x112f778: str             w0, [x25]
    //     0x112f77c: tbz             w0, #0, #0x112f798
    //     0x112f780: ldurb           w16, [x1, #-1]
    //     0x112f784: ldurb           w17, [x0, #-1]
    //     0x112f788: and             x16, x17, x16, lsr #2
    //     0x112f78c: tst             x16, HEAP, lsr #32
    //     0x112f790: b.eq            #0x112f798
    //     0x112f794: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x112f798: ldr             x2, [fp, #0x10]
    // 0x112f79c: LoadField: r0 = r2->field_53
    //     0x112f79c: ldur            w0, [x2, #0x53]
    // 0x112f7a0: DecompressPointer r0
    //     0x112f7a0: add             x0, x0, HEAP, lsl #32
    // 0x112f7a4: ldur            x1, [fp, #-0x10]
    // 0x112f7a8: ArrayStore: r1[19] = r0  ; List_4
    //     0x112f7a8: add             x25, x1, #0x5b
    //     0x112f7ac: str             w0, [x25]
    //     0x112f7b0: tbz             w0, #0, #0x112f7cc
    //     0x112f7b4: ldurb           w16, [x1, #-1]
    //     0x112f7b8: ldurb           w17, [x0, #-1]
    //     0x112f7bc: and             x16, x17, x16, lsr #2
    //     0x112f7c0: tst             x16, HEAP, lsr #32
    //     0x112f7c4: b.eq            #0x112f7cc
    //     0x112f7c8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x112f7cc: LoadField: r0 = r2->field_57
    //     0x112f7cc: ldur            w0, [x2, #0x57]
    // 0x112f7d0: DecompressPointer r0
    //     0x112f7d0: add             x0, x0, HEAP, lsl #32
    // 0x112f7d4: ldur            x3, [fp, #-0x10]
    // 0x112f7d8: StoreField: r3->field_5f = r0
    //     0x112f7d8: stur            w0, [x3, #0x5f]
    // 0x112f7dc: LoadField: r0 = r2->field_5b
    //     0x112f7dc: ldur            w0, [x2, #0x5b]
    // 0x112f7e0: DecompressPointer r0
    //     0x112f7e0: add             x0, x0, HEAP, lsl #32
    // 0x112f7e4: mov             x1, x3
    // 0x112f7e8: ArrayStore: r1[21] = r0  ; List_4
    //     0x112f7e8: add             x25, x1, #0x63
    //     0x112f7ec: str             w0, [x25]
    //     0x112f7f0: tbz             w0, #0, #0x112f80c
    //     0x112f7f4: ldurb           w16, [x1, #-1]
    //     0x112f7f8: ldurb           w17, [x0, #-1]
    //     0x112f7fc: and             x16, x17, x16, lsr #2
    //     0x112f800: tst             x16, HEAP, lsr #32
    //     0x112f804: b.eq            #0x112f80c
    //     0x112f808: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x112f80c: r0 = LoadClassIdInstr(r2)
    //     0x112f80c: ldur            x0, [x2, #-1]
    //     0x112f810: ubfx            x0, x0, #0xc, #0x14
    // 0x112f814: mov             x1, x2
    // 0x112f818: r0 = GDT[cid_x0 + 0xed5]()
    //     0x112f818: add             lr, x0, #0xed5
    //     0x112f81c: ldr             lr, [x21, lr, lsl #3]
    //     0x112f820: blr             lr
    // 0x112f824: ldur            x1, [fp, #-0x10]
    // 0x112f828: ArrayStore: r1[22] = r0  ; List_4
    //     0x112f828: add             x25, x1, #0x67
    //     0x112f82c: str             w0, [x25]
    //     0x112f830: tbz             w0, #0, #0x112f84c
    //     0x112f834: ldurb           w16, [x1, #-1]
    //     0x112f838: ldurb           w17, [x0, #-1]
    //     0x112f83c: and             x16, x17, x16, lsr #2
    //     0x112f840: tst             x16, HEAP, lsr #32
    //     0x112f844: b.eq            #0x112f84c
    //     0x112f848: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x112f84c: ldr             x0, [fp, #0x10]
    // 0x112f850: LoadField: r1 = r0->field_63
    //     0x112f850: ldur            w1, [x0, #0x63]
    // 0x112f854: DecompressPointer r1
    //     0x112f854: add             x1, x1, HEAP, lsl #32
    // 0x112f858: ldur            x2, [fp, #-0x10]
    // 0x112f85c: StoreField: r2->field_6b = r1
    //     0x112f85c: stur            w1, [x2, #0x6b]
    // 0x112f860: LoadField: r1 = r0->field_67
    //     0x112f860: ldur            w1, [x0, #0x67]
    // 0x112f864: DecompressPointer r1
    //     0x112f864: add             x1, x1, HEAP, lsl #32
    // 0x112f868: StoreField: r2->field_6f = r1
    //     0x112f868: stur            w1, [x2, #0x6f]
    // 0x112f86c: r1 = <Object?>
    //     0x112f86c: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x112f870: r0 = AllocateGrowableArray()
    //     0x112f870: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x112f874: mov             x1, x0
    // 0x112f878: ldur            x0, [fp, #-0x10]
    // 0x112f87c: StoreField: r1->field_f = r0
    //     0x112f87c: stur            w0, [x1, #0xf]
    // 0x112f880: r0 = 50
    //     0x112f880: mov             x0, #0x32
    // 0x112f884: StoreField: r1->field_b = r0
    //     0x112f884: stur            w0, [x1, #0xb]
    // 0x112f888: r0 = hashAll()
    //     0x112f888: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x112f88c: mov             x2, x0
    // 0x112f890: r0 = BoxInt64Instr(r2)
    //     0x112f890: sbfiz           x0, x2, #1, #0x1f
    //     0x112f894: cmp             x2, x0, asr #1
    //     0x112f898: b.eq            #0x112f8a4
    //     0x112f89c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x112f8a0: stur            x2, [x0, #7]
    // 0x112f8a4: LeaveFrame
    //     0x112f8a4: mov             SP, fp
    //     0x112f8a8: ldp             fp, lr, [SP], #0x10
    // 0x112f8ac: ret
    //     0x112f8ac: ret             
    // 0x112f8b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112f8b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112f8b4: b               #0x112f2c0
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1164644, size: 0x9bc
    // 0x1164644: EnterFrame
    //     0x1164644: stp             fp, lr, [SP, #-0x10]!
    //     0x1164648: mov             fp, SP
    // 0x116464c: AllocStack(0xe8)
    //     0x116464c: sub             SP, SP, #0xe8
    // 0x1164650: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* d0 => d0, fp-0xc0 */)
    //     0x1164650: mov             x0, x1
    //     0x1164654: stur            x1, [fp, #-8]
    //     0x1164658: stur            x2, [fp, #-0x10]
    //     0x116465c: stur            d0, [fp, #-0xc0]
    // 0x1164660: CheckStackOverflow
    //     0x1164660: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1164664: cmp             SP, x16
    //     0x1164668: b.ls            #0x1164ff8
    // 0x116466c: cmp             w0, w2
    // 0x1164670: b.ne            #0x1164680
    // 0x1164674: LeaveFrame
    //     0x1164674: mov             SP, fp
    //     0x1164678: ldp             fp, lr, [SP], #0x10
    // 0x116467c: ret
    //     0x116467c: ret             
    // 0x1164680: cmp             w0, NULL
    // 0x1164684: b.ne            #0x1164690
    // 0x1164688: r1 = Null
    //     0x1164688: mov             x1, NULL
    // 0x116468c: b               #0x1164698
    // 0x1164690: LoadField: r1 = r0->field_7
    //     0x1164690: ldur            w1, [x0, #7]
    // 0x1164694: DecompressPointer r1
    //     0x1164694: add             x1, x1, HEAP, lsl #32
    // 0x1164698: cmp             w2, NULL
    // 0x116469c: b.ne            #0x11646a8
    // 0x11646a0: r3 = Null
    //     0x11646a0: mov             x3, NULL
    // 0x11646a4: b               #0x11646b0
    // 0x11646a8: LoadField: r3 = r2->field_7
    //     0x11646a8: ldur            w3, [x2, #7]
    // 0x11646ac: DecompressPointer r3
    //     0x11646ac: add             x3, x3, HEAP, lsl #32
    // 0x11646b0: r16 = <TextStyle?>
    //     0x11646b0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a88] TypeArguments: <TextStyle?>
    //     0x11646b4: ldr             x16, [x16, #0xa88]
    // 0x11646b8: stp             x1, x16, [SP, #0x18]
    // 0x11646bc: str             x3, [SP, #0x10]
    // 0x11646c0: str             d0, [SP, #8]
    // 0x11646c4: r16 = Closure: (TextStyle?, TextStyle?, double) => TextStyle? from Function 'lerp': static.
    //     0x11646c4: add             x16, PP, #0xad, lsl #12  ; [pp+0xadcf0] Closure: (TextStyle?, TextStyle?, double) => TextStyle? from Function 'lerp': static. (0x7f2adae990b4)
    //     0x11646c8: ldr             x16, [x16, #0xcf0]
    // 0x11646cc: str             x16, [SP]
    // 0x11646d0: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0x11646d0: ldr             x4, [PP, #0x560]  ; [pp+0x560] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0x11646d4: r0 = lerp()
    //     0x11646d4: bl              #0x1165084  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::lerp
    // 0x11646d8: mov             x1, x0
    // 0x11646dc: ldur            x0, [fp, #-8]
    // 0x11646e0: stur            x1, [fp, #-0x18]
    // 0x11646e4: cmp             w0, NULL
    // 0x11646e8: b.ne            #0x11646f4
    // 0x11646ec: r3 = Null
    //     0x11646ec: mov             x3, NULL
    // 0x11646f0: b               #0x1164700
    // 0x11646f4: LoadField: r2 = r0->field_b
    //     0x11646f4: ldur            w2, [x0, #0xb]
    // 0x11646f8: DecompressPointer r2
    //     0x11646f8: add             x2, x2, HEAP, lsl #32
    // 0x11646fc: mov             x3, x2
    // 0x1164700: ldur            x2, [fp, #-0x10]
    // 0x1164704: cmp             w2, NULL
    // 0x1164708: b.ne            #0x1164714
    // 0x116470c: r4 = Null
    //     0x116470c: mov             x4, NULL
    // 0x1164710: b               #0x116471c
    // 0x1164714: LoadField: r4 = r2->field_b
    //     0x1164714: ldur            w4, [x2, #0xb]
    // 0x1164718: DecompressPointer r4
    //     0x1164718: add             x4, x4, HEAP, lsl #32
    // 0x116471c: ldur            d0, [fp, #-0xc0]
    // 0x1164720: r16 = <Color?>
    //     0x1164720: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1164724: ldr             x16, [x16, #0xa40]
    // 0x1164728: stp             x3, x16, [SP, #0x18]
    // 0x116472c: str             x4, [SP, #0x10]
    // 0x1164730: str             d0, [SP, #8]
    // 0x1164734: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0x1164734: add             x16, PP, #0xad, lsl #12  ; [pp+0xadcf8] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7f2ada8ef4c4)
    //     0x1164738: ldr             x16, [x16, #0xcf8]
    // 0x116473c: str             x16, [SP]
    // 0x1164740: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0x1164740: ldr             x4, [PP, #0x560]  ; [pp+0x560] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0x1164744: r0 = lerp()
    //     0x1164744: bl              #0x1165084  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::lerp
    // 0x1164748: mov             x1, x0
    // 0x116474c: ldur            x0, [fp, #-8]
    // 0x1164750: stur            x1, [fp, #-0x20]
    // 0x1164754: cmp             w0, NULL
    // 0x1164758: b.ne            #0x1164764
    // 0x116475c: r3 = Null
    //     0x116475c: mov             x3, NULL
    // 0x1164760: b               #0x1164770
    // 0x1164764: LoadField: r2 = r0->field_f
    //     0x1164764: ldur            w2, [x0, #0xf]
    // 0x1164768: DecompressPointer r2
    //     0x1164768: add             x2, x2, HEAP, lsl #32
    // 0x116476c: mov             x3, x2
    // 0x1164770: ldur            x2, [fp, #-0x10]
    // 0x1164774: cmp             w2, NULL
    // 0x1164778: b.ne            #0x1164784
    // 0x116477c: r4 = Null
    //     0x116477c: mov             x4, NULL
    // 0x1164780: b               #0x116478c
    // 0x1164784: LoadField: r4 = r2->field_f
    //     0x1164784: ldur            w4, [x2, #0xf]
    // 0x1164788: DecompressPointer r4
    //     0x1164788: add             x4, x4, HEAP, lsl #32
    // 0x116478c: ldur            d0, [fp, #-0xc0]
    // 0x1164790: r16 = <Color?>
    //     0x1164790: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1164794: ldr             x16, [x16, #0xa40]
    // 0x1164798: stp             x3, x16, [SP, #0x18]
    // 0x116479c: str             x4, [SP, #0x10]
    // 0x11647a0: str             d0, [SP, #8]
    // 0x11647a4: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0x11647a4: add             x16, PP, #0xad, lsl #12  ; [pp+0xadcf8] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7f2ada8ef4c4)
    //     0x11647a8: ldr             x16, [x16, #0xcf8]
    // 0x11647ac: str             x16, [SP]
    // 0x11647b0: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0x11647b0: ldr             x4, [PP, #0x560]  ; [pp+0x560] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0x11647b4: r0 = lerp()
    //     0x11647b4: bl              #0x1165084  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::lerp
    // 0x11647b8: mov             x1, x0
    // 0x11647bc: ldur            x0, [fp, #-8]
    // 0x11647c0: stur            x1, [fp, #-0x28]
    // 0x11647c4: cmp             w0, NULL
    // 0x11647c8: b.ne            #0x11647d4
    // 0x11647cc: r3 = Null
    //     0x11647cc: mov             x3, NULL
    // 0x11647d0: b               #0x11647e0
    // 0x11647d4: LoadField: r2 = r0->field_13
    //     0x11647d4: ldur            w2, [x0, #0x13]
    // 0x11647d8: DecompressPointer r2
    //     0x11647d8: add             x2, x2, HEAP, lsl #32
    // 0x11647dc: mov             x3, x2
    // 0x11647e0: ldur            x2, [fp, #-0x10]
    // 0x11647e4: cmp             w2, NULL
    // 0x11647e8: b.ne            #0x11647f4
    // 0x11647ec: r4 = Null
    //     0x11647ec: mov             x4, NULL
    // 0x11647f0: b               #0x11647fc
    // 0x11647f4: LoadField: r4 = r2->field_13
    //     0x11647f4: ldur            w4, [x2, #0x13]
    // 0x11647f8: DecompressPointer r4
    //     0x11647f8: add             x4, x4, HEAP, lsl #32
    // 0x11647fc: ldur            d0, [fp, #-0xc0]
    // 0x1164800: r16 = <Color?>
    //     0x1164800: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1164804: ldr             x16, [x16, #0xa40]
    // 0x1164808: stp             x3, x16, [SP, #0x18]
    // 0x116480c: str             x4, [SP, #0x10]
    // 0x1164810: str             d0, [SP, #8]
    // 0x1164814: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0x1164814: add             x16, PP, #0xad, lsl #12  ; [pp+0xadcf8] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7f2ada8ef4c4)
    //     0x1164818: ldr             x16, [x16, #0xcf8]
    // 0x116481c: str             x16, [SP]
    // 0x1164820: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0x1164820: ldr             x4, [PP, #0x560]  ; [pp+0x560] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0x1164824: r0 = lerp()
    //     0x1164824: bl              #0x1165084  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::lerp
    // 0x1164828: mov             x1, x0
    // 0x116482c: ldur            x0, [fp, #-8]
    // 0x1164830: stur            x1, [fp, #-0x30]
    // 0x1164834: cmp             w0, NULL
    // 0x1164838: b.ne            #0x1164844
    // 0x116483c: r3 = Null
    //     0x116483c: mov             x3, NULL
    // 0x1164840: b               #0x1164850
    // 0x1164844: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x1164844: ldur            w2, [x0, #0x17]
    // 0x1164848: DecompressPointer r2
    //     0x1164848: add             x2, x2, HEAP, lsl #32
    // 0x116484c: mov             x3, x2
    // 0x1164850: ldur            x2, [fp, #-0x10]
    // 0x1164854: cmp             w2, NULL
    // 0x1164858: b.ne            #0x1164864
    // 0x116485c: r4 = Null
    //     0x116485c: mov             x4, NULL
    // 0x1164860: b               #0x116486c
    // 0x1164864: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x1164864: ldur            w4, [x2, #0x17]
    // 0x1164868: DecompressPointer r4
    //     0x1164868: add             x4, x4, HEAP, lsl #32
    // 0x116486c: ldur            d0, [fp, #-0xc0]
    // 0x1164870: r16 = <Color?>
    //     0x1164870: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1164874: ldr             x16, [x16, #0xa40]
    // 0x1164878: stp             x3, x16, [SP, #0x18]
    // 0x116487c: str             x4, [SP, #0x10]
    // 0x1164880: str             d0, [SP, #8]
    // 0x1164884: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0x1164884: add             x16, PP, #0xad, lsl #12  ; [pp+0xadcf8] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7f2ada8ef4c4)
    //     0x1164888: ldr             x16, [x16, #0xcf8]
    // 0x116488c: str             x16, [SP]
    // 0x1164890: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0x1164890: ldr             x4, [PP, #0x560]  ; [pp+0x560] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0x1164894: r0 = lerp()
    //     0x1164894: bl              #0x1165084  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::lerp
    // 0x1164898: mov             x1, x0
    // 0x116489c: ldur            x0, [fp, #-8]
    // 0x11648a0: stur            x1, [fp, #-0x38]
    // 0x11648a4: cmp             w0, NULL
    // 0x11648a8: b.ne            #0x11648b4
    // 0x11648ac: r3 = Null
    //     0x11648ac: mov             x3, NULL
    // 0x11648b0: b               #0x11648c0
    // 0x11648b4: LoadField: r2 = r0->field_1b
    //     0x11648b4: ldur            w2, [x0, #0x1b]
    // 0x11648b8: DecompressPointer r2
    //     0x11648b8: add             x2, x2, HEAP, lsl #32
    // 0x11648bc: mov             x3, x2
    // 0x11648c0: ldur            x2, [fp, #-0x10]
    // 0x11648c4: cmp             w2, NULL
    // 0x11648c8: b.ne            #0x11648d4
    // 0x11648cc: r4 = Null
    //     0x11648cc: mov             x4, NULL
    // 0x11648d0: b               #0x11648dc
    // 0x11648d4: LoadField: r4 = r2->field_1b
    //     0x11648d4: ldur            w4, [x2, #0x1b]
    // 0x11648d8: DecompressPointer r4
    //     0x11648d8: add             x4, x4, HEAP, lsl #32
    // 0x11648dc: ldur            d0, [fp, #-0xc0]
    // 0x11648e0: r16 = <Color?>
    //     0x11648e0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x11648e4: ldr             x16, [x16, #0xa40]
    // 0x11648e8: stp             x3, x16, [SP, #0x18]
    // 0x11648ec: str             x4, [SP, #0x10]
    // 0x11648f0: str             d0, [SP, #8]
    // 0x11648f4: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0x11648f4: add             x16, PP, #0xad, lsl #12  ; [pp+0xadcf8] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7f2ada8ef4c4)
    //     0x11648f8: ldr             x16, [x16, #0xcf8]
    // 0x11648fc: str             x16, [SP]
    // 0x1164900: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0x1164900: ldr             x4, [PP, #0x560]  ; [pp+0x560] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0x1164904: r0 = lerp()
    //     0x1164904: bl              #0x1165084  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::lerp
    // 0x1164908: mov             x1, x0
    // 0x116490c: ldur            x0, [fp, #-8]
    // 0x1164910: stur            x1, [fp, #-0x40]
    // 0x1164914: cmp             w0, NULL
    // 0x1164918: b.ne            #0x1164924
    // 0x116491c: r3 = Null
    //     0x116491c: mov             x3, NULL
    // 0x1164920: b               #0x1164930
    // 0x1164924: LoadField: r2 = r0->field_1f
    //     0x1164924: ldur            w2, [x0, #0x1f]
    // 0x1164928: DecompressPointer r2
    //     0x1164928: add             x2, x2, HEAP, lsl #32
    // 0x116492c: mov             x3, x2
    // 0x1164930: ldur            x2, [fp, #-0x10]
    // 0x1164934: cmp             w2, NULL
    // 0x1164938: b.ne            #0x1164944
    // 0x116493c: r4 = Null
    //     0x116493c: mov             x4, NULL
    // 0x1164940: b               #0x116494c
    // 0x1164944: LoadField: r4 = r2->field_1f
    //     0x1164944: ldur            w4, [x2, #0x1f]
    // 0x1164948: DecompressPointer r4
    //     0x1164948: add             x4, x4, HEAP, lsl #32
    // 0x116494c: ldur            d0, [fp, #-0xc0]
    // 0x1164950: r16 = <double?>
    //     0x1164950: add             x16, PP, #0x7a, lsl #12  ; [pp+0x7aba8] TypeArguments: <double?>
    //     0x1164954: ldr             x16, [x16, #0xba8]
    // 0x1164958: stp             x3, x16, [SP, #0x18]
    // 0x116495c: str             x4, [SP, #0x10]
    // 0x1164960: str             d0, [SP, #8]
    // 0x1164964: r16 = Closure: (num?, num?, double) => double? from Function 'lerpDouble': static.
    //     0x1164964: add             x16, PP, #0xad, lsl #12  ; [pp+0xadd00] Closure: (num?, num?, double) => double? from Function 'lerpDouble': static. (0x7f2ada74fcc8)
    //     0x1164968: ldr             x16, [x16, #0xd00]
    // 0x116496c: str             x16, [SP]
    // 0x1164970: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0x1164970: ldr             x4, [PP, #0x560]  ; [pp+0x560] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0x1164974: r0 = lerp()
    //     0x1164974: bl              #0x1165084  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::lerp
    // 0x1164978: mov             x1, x0
    // 0x116497c: ldur            x0, [fp, #-8]
    // 0x1164980: stur            x1, [fp, #-0x48]
    // 0x1164984: cmp             w0, NULL
    // 0x1164988: b.ne            #0x1164994
    // 0x116498c: r3 = Null
    //     0x116498c: mov             x3, NULL
    // 0x1164990: b               #0x11649a0
    // 0x1164994: LoadField: r2 = r0->field_23
    //     0x1164994: ldur            w2, [x0, #0x23]
    // 0x1164998: DecompressPointer r2
    //     0x1164998: add             x2, x2, HEAP, lsl #32
    // 0x116499c: mov             x3, x2
    // 0x11649a0: ldur            x2, [fp, #-0x10]
    // 0x11649a4: cmp             w2, NULL
    // 0x11649a8: b.ne            #0x11649b4
    // 0x11649ac: r4 = Null
    //     0x11649ac: mov             x4, NULL
    // 0x11649b0: b               #0x11649bc
    // 0x11649b4: LoadField: r4 = r2->field_23
    //     0x11649b4: ldur            w4, [x2, #0x23]
    // 0x11649b8: DecompressPointer r4
    //     0x11649b8: add             x4, x4, HEAP, lsl #32
    // 0x11649bc: ldur            d0, [fp, #-0xc0]
    // 0x11649c0: r16 = <EdgeInsetsGeometry?>
    //     0x11649c0: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d4a0] TypeArguments: <EdgeInsetsGeometry?>
    //     0x11649c4: ldr             x16, [x16, #0x4a0]
    // 0x11649c8: stp             x3, x16, [SP, #0x18]
    // 0x11649cc: str             x4, [SP, #0x10]
    // 0x11649d0: str             d0, [SP, #8]
    // 0x11649d4: r16 = Closure: (EdgeInsetsGeometry?, EdgeInsetsGeometry?, double) => EdgeInsetsGeometry? from Function 'lerp': static.
    //     0x11649d4: add             x16, PP, #0xad, lsl #12  ; [pp+0xadd08] Closure: (EdgeInsetsGeometry?, EdgeInsetsGeometry?, double) => EdgeInsetsGeometry? from Function 'lerp': static. (0x7f2adb028924)
    //     0x11649d8: ldr             x16, [x16, #0xd08]
    // 0x11649dc: str             x16, [SP]
    // 0x11649e0: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0x11649e0: ldr             x4, [PP, #0x560]  ; [pp+0x560] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0x11649e4: r0 = lerp()
    //     0x11649e4: bl              #0x1165084  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::lerp
    // 0x11649e8: mov             x1, x0
    // 0x11649ec: ldur            x0, [fp, #-8]
    // 0x11649f0: stur            x1, [fp, #-0x50]
    // 0x11649f4: cmp             w0, NULL
    // 0x11649f8: b.ne            #0x1164a04
    // 0x11649fc: r3 = Null
    //     0x11649fc: mov             x3, NULL
    // 0x1164a00: b               #0x1164a10
    // 0x1164a04: LoadField: r2 = r0->field_27
    //     0x1164a04: ldur            w2, [x0, #0x27]
    // 0x1164a08: DecompressPointer r2
    //     0x1164a08: add             x2, x2, HEAP, lsl #32
    // 0x1164a0c: mov             x3, x2
    // 0x1164a10: ldur            x2, [fp, #-0x10]
    // 0x1164a14: cmp             w2, NULL
    // 0x1164a18: b.ne            #0x1164a24
    // 0x1164a1c: r4 = Null
    //     0x1164a1c: mov             x4, NULL
    // 0x1164a20: b               #0x1164a2c
    // 0x1164a24: LoadField: r4 = r2->field_27
    //     0x1164a24: ldur            w4, [x2, #0x27]
    // 0x1164a28: DecompressPointer r4
    //     0x1164a28: add             x4, x4, HEAP, lsl #32
    // 0x1164a2c: ldur            d0, [fp, #-0xc0]
    // 0x1164a30: r16 = <Size?>
    //     0x1164a30: add             x16, PP, #0x26, lsl #12  ; [pp+0x26aa8] TypeArguments: <Size?>
    //     0x1164a34: ldr             x16, [x16, #0xaa8]
    // 0x1164a38: stp             x3, x16, [SP, #0x18]
    // 0x1164a3c: str             x4, [SP, #0x10]
    // 0x1164a40: str             d0, [SP, #8]
    // 0x1164a44: r16 = Closure: (Size?, Size?, double) => Size? from Function 'lerp': static.
    //     0x1164a44: add             x16, PP, #0xad, lsl #12  ; [pp+0xadd10] Closure: (Size?, Size?, double) => Size? from Function 'lerp': static. (0x7f2adaa55f40)
    //     0x1164a48: ldr             x16, [x16, #0xd10]
    // 0x1164a4c: str             x16, [SP]
    // 0x1164a50: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0x1164a50: ldr             x4, [PP, #0x560]  ; [pp+0x560] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0x1164a54: r0 = lerp()
    //     0x1164a54: bl              #0x1165084  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::lerp
    // 0x1164a58: mov             x1, x0
    // 0x1164a5c: ldur            x0, [fp, #-8]
    // 0x1164a60: stur            x1, [fp, #-0x58]
    // 0x1164a64: cmp             w0, NULL
    // 0x1164a68: b.ne            #0x1164a74
    // 0x1164a6c: r3 = Null
    //     0x1164a6c: mov             x3, NULL
    // 0x1164a70: b               #0x1164a80
    // 0x1164a74: LoadField: r2 = r0->field_2b
    //     0x1164a74: ldur            w2, [x0, #0x2b]
    // 0x1164a78: DecompressPointer r2
    //     0x1164a78: add             x2, x2, HEAP, lsl #32
    // 0x1164a7c: mov             x3, x2
    // 0x1164a80: ldur            x2, [fp, #-0x10]
    // 0x1164a84: cmp             w2, NULL
    // 0x1164a88: b.ne            #0x1164a94
    // 0x1164a8c: r4 = Null
    //     0x1164a8c: mov             x4, NULL
    // 0x1164a90: b               #0x1164a9c
    // 0x1164a94: LoadField: r4 = r2->field_2b
    //     0x1164a94: ldur            w4, [x2, #0x2b]
    // 0x1164a98: DecompressPointer r4
    //     0x1164a98: add             x4, x4, HEAP, lsl #32
    // 0x1164a9c: ldur            d0, [fp, #-0xc0]
    // 0x1164aa0: r16 = <Size?>
    //     0x1164aa0: add             x16, PP, #0x26, lsl #12  ; [pp+0x26aa8] TypeArguments: <Size?>
    //     0x1164aa4: ldr             x16, [x16, #0xaa8]
    // 0x1164aa8: stp             x3, x16, [SP, #0x18]
    // 0x1164aac: str             x4, [SP, #0x10]
    // 0x1164ab0: str             d0, [SP, #8]
    // 0x1164ab4: r16 = Closure: (Size?, Size?, double) => Size? from Function 'lerp': static.
    //     0x1164ab4: add             x16, PP, #0xad, lsl #12  ; [pp+0xadd10] Closure: (Size?, Size?, double) => Size? from Function 'lerp': static. (0x7f2adaa55f40)
    //     0x1164ab8: ldr             x16, [x16, #0xd10]
    // 0x1164abc: str             x16, [SP]
    // 0x1164ac0: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0x1164ac0: ldr             x4, [PP, #0x560]  ; [pp+0x560] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0x1164ac4: r0 = lerp()
    //     0x1164ac4: bl              #0x1165084  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::lerp
    // 0x1164ac8: mov             x1, x0
    // 0x1164acc: ldur            x0, [fp, #-8]
    // 0x1164ad0: stur            x1, [fp, #-0x60]
    // 0x1164ad4: cmp             w0, NULL
    // 0x1164ad8: b.ne            #0x1164ae4
    // 0x1164adc: r3 = Null
    //     0x1164adc: mov             x3, NULL
    // 0x1164ae0: b               #0x1164af0
    // 0x1164ae4: LoadField: r2 = r0->field_2f
    //     0x1164ae4: ldur            w2, [x0, #0x2f]
    // 0x1164ae8: DecompressPointer r2
    //     0x1164ae8: add             x2, x2, HEAP, lsl #32
    // 0x1164aec: mov             x3, x2
    // 0x1164af0: ldur            x2, [fp, #-0x10]
    // 0x1164af4: cmp             w2, NULL
    // 0x1164af8: b.ne            #0x1164b04
    // 0x1164afc: r4 = Null
    //     0x1164afc: mov             x4, NULL
    // 0x1164b00: b               #0x1164b0c
    // 0x1164b04: LoadField: r4 = r2->field_2f
    //     0x1164b04: ldur            w4, [x2, #0x2f]
    // 0x1164b08: DecompressPointer r4
    //     0x1164b08: add             x4, x4, HEAP, lsl #32
    // 0x1164b0c: ldur            d0, [fp, #-0xc0]
    // 0x1164b10: r16 = <Size?>
    //     0x1164b10: add             x16, PP, #0x26, lsl #12  ; [pp+0x26aa8] TypeArguments: <Size?>
    //     0x1164b14: ldr             x16, [x16, #0xaa8]
    // 0x1164b18: stp             x3, x16, [SP, #0x18]
    // 0x1164b1c: str             x4, [SP, #0x10]
    // 0x1164b20: str             d0, [SP, #8]
    // 0x1164b24: r16 = Closure: (Size?, Size?, double) => Size? from Function 'lerp': static.
    //     0x1164b24: add             x16, PP, #0xad, lsl #12  ; [pp+0xadd10] Closure: (Size?, Size?, double) => Size? from Function 'lerp': static. (0x7f2adaa55f40)
    //     0x1164b28: ldr             x16, [x16, #0xd10]
    // 0x1164b2c: str             x16, [SP]
    // 0x1164b30: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0x1164b30: ldr             x4, [PP, #0x560]  ; [pp+0x560] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0x1164b34: r0 = lerp()
    //     0x1164b34: bl              #0x1165084  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::lerp
    // 0x1164b38: mov             x1, x0
    // 0x1164b3c: ldur            x0, [fp, #-8]
    // 0x1164b40: stur            x1, [fp, #-0x68]
    // 0x1164b44: cmp             w0, NULL
    // 0x1164b48: b.ne            #0x1164b54
    // 0x1164b4c: r3 = Null
    //     0x1164b4c: mov             x3, NULL
    // 0x1164b50: b               #0x1164b60
    // 0x1164b54: LoadField: r2 = r0->field_33
    //     0x1164b54: ldur            w2, [x0, #0x33]
    // 0x1164b58: DecompressPointer r2
    //     0x1164b58: add             x2, x2, HEAP, lsl #32
    // 0x1164b5c: mov             x3, x2
    // 0x1164b60: ldur            x2, [fp, #-0x10]
    // 0x1164b64: cmp             w2, NULL
    // 0x1164b68: b.ne            #0x1164b74
    // 0x1164b6c: r4 = Null
    //     0x1164b6c: mov             x4, NULL
    // 0x1164b70: b               #0x1164b7c
    // 0x1164b74: LoadField: r4 = r2->field_33
    //     0x1164b74: ldur            w4, [x2, #0x33]
    // 0x1164b78: DecompressPointer r4
    //     0x1164b78: add             x4, x4, HEAP, lsl #32
    // 0x1164b7c: ldur            d0, [fp, #-0xc0]
    // 0x1164b80: r16 = <Color?>
    //     0x1164b80: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1164b84: ldr             x16, [x16, #0xa40]
    // 0x1164b88: stp             x3, x16, [SP, #0x18]
    // 0x1164b8c: str             x4, [SP, #0x10]
    // 0x1164b90: str             d0, [SP, #8]
    // 0x1164b94: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0x1164b94: add             x16, PP, #0xad, lsl #12  ; [pp+0xadcf8] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7f2ada8ef4c4)
    //     0x1164b98: ldr             x16, [x16, #0xcf8]
    // 0x1164b9c: str             x16, [SP]
    // 0x1164ba0: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0x1164ba0: ldr             x4, [PP, #0x560]  ; [pp+0x560] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0x1164ba4: r0 = lerp()
    //     0x1164ba4: bl              #0x1165084  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::lerp
    // 0x1164ba8: mov             x1, x0
    // 0x1164bac: ldur            x0, [fp, #-8]
    // 0x1164bb0: stur            x1, [fp, #-0x70]
    // 0x1164bb4: cmp             w0, NULL
    // 0x1164bb8: b.ne            #0x1164bc4
    // 0x1164bbc: r3 = Null
    //     0x1164bbc: mov             x3, NULL
    // 0x1164bc0: b               #0x1164bd0
    // 0x1164bc4: LoadField: r2 = r0->field_37
    //     0x1164bc4: ldur            w2, [x0, #0x37]
    // 0x1164bc8: DecompressPointer r2
    //     0x1164bc8: add             x2, x2, HEAP, lsl #32
    // 0x1164bcc: mov             x3, x2
    // 0x1164bd0: ldur            x2, [fp, #-0x10]
    // 0x1164bd4: cmp             w2, NULL
    // 0x1164bd8: b.ne            #0x1164be4
    // 0x1164bdc: r4 = Null
    //     0x1164bdc: mov             x4, NULL
    // 0x1164be0: b               #0x1164bec
    // 0x1164be4: LoadField: r4 = r2->field_37
    //     0x1164be4: ldur            w4, [x2, #0x37]
    // 0x1164be8: DecompressPointer r4
    //     0x1164be8: add             x4, x4, HEAP, lsl #32
    // 0x1164bec: ldur            d0, [fp, #-0xc0]
    // 0x1164bf0: r16 = <double?>
    //     0x1164bf0: add             x16, PP, #0x7a, lsl #12  ; [pp+0x7aba8] TypeArguments: <double?>
    //     0x1164bf4: ldr             x16, [x16, #0xba8]
    // 0x1164bf8: stp             x3, x16, [SP, #0x18]
    // 0x1164bfc: str             x4, [SP, #0x10]
    // 0x1164c00: str             d0, [SP, #8]
    // 0x1164c04: r16 = Closure: (num?, num?, double) => double? from Function 'lerpDouble': static.
    //     0x1164c04: add             x16, PP, #0xad, lsl #12  ; [pp+0xadd00] Closure: (num?, num?, double) => double? from Function 'lerpDouble': static. (0x7f2ada74fcc8)
    //     0x1164c08: ldr             x16, [x16, #0xd00]
    // 0x1164c0c: str             x16, [SP]
    // 0x1164c10: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0x1164c10: ldr             x4, [PP, #0x560]  ; [pp+0x560] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0x1164c14: r0 = lerp()
    //     0x1164c14: bl              #0x1165084  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::lerp
    // 0x1164c18: mov             x3, x0
    // 0x1164c1c: ldur            x0, [fp, #-8]
    // 0x1164c20: stur            x3, [fp, #-0x78]
    // 0x1164c24: cmp             w0, NULL
    // 0x1164c28: b.ne            #0x1164c34
    // 0x1164c2c: r1 = Null
    //     0x1164c2c: mov             x1, NULL
    // 0x1164c30: b               #0x1164c3c
    // 0x1164c34: LoadField: r1 = r0->field_3f
    //     0x1164c34: ldur            w1, [x0, #0x3f]
    // 0x1164c38: DecompressPointer r1
    //     0x1164c38: add             x1, x1, HEAP, lsl #32
    // 0x1164c3c: ldur            x4, [fp, #-0x10]
    // 0x1164c40: cmp             w4, NULL
    // 0x1164c44: b.ne            #0x1164c50
    // 0x1164c48: r2 = Null
    //     0x1164c48: mov             x2, NULL
    // 0x1164c4c: b               #0x1164c58
    // 0x1164c50: LoadField: r2 = r4->field_3f
    //     0x1164c50: ldur            w2, [x4, #0x3f]
    // 0x1164c54: DecompressPointer r2
    //     0x1164c54: add             x2, x2, HEAP, lsl #32
    // 0x1164c58: ldur            d0, [fp, #-0xc0]
    // 0x1164c5c: r0 = lerp()
    //     0x1164c5c: bl              #0x1165000  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateBorderSide::lerp
    // 0x1164c60: mov             x1, x0
    // 0x1164c64: ldur            x0, [fp, #-8]
    // 0x1164c68: stur            x1, [fp, #-0x80]
    // 0x1164c6c: cmp             w0, NULL
    // 0x1164c70: b.ne            #0x1164c7c
    // 0x1164c74: r3 = Null
    //     0x1164c74: mov             x3, NULL
    // 0x1164c78: b               #0x1164c88
    // 0x1164c7c: LoadField: r2 = r0->field_43
    //     0x1164c7c: ldur            w2, [x0, #0x43]
    // 0x1164c80: DecompressPointer r2
    //     0x1164c80: add             x2, x2, HEAP, lsl #32
    // 0x1164c84: mov             x3, x2
    // 0x1164c88: ldur            x2, [fp, #-0x10]
    // 0x1164c8c: cmp             w2, NULL
    // 0x1164c90: b.ne            #0x1164c9c
    // 0x1164c94: r4 = Null
    //     0x1164c94: mov             x4, NULL
    // 0x1164c98: b               #0x1164ca4
    // 0x1164c9c: LoadField: r4 = r2->field_43
    //     0x1164c9c: ldur            w4, [x2, #0x43]
    // 0x1164ca0: DecompressPointer r4
    //     0x1164ca0: add             x4, x4, HEAP, lsl #32
    // 0x1164ca4: ldur            d0, [fp, #-0xc0]
    // 0x1164ca8: r16 = <OutlinedBorder?>
    //     0x1164ca8: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d4a8] TypeArguments: <OutlinedBorder?>
    //     0x1164cac: ldr             x16, [x16, #0x4a8]
    // 0x1164cb0: stp             x3, x16, [SP, #0x18]
    // 0x1164cb4: str             x4, [SP, #0x10]
    // 0x1164cb8: str             d0, [SP, #8]
    // 0x1164cbc: r16 = Closure: (OutlinedBorder?, OutlinedBorder?, double) => OutlinedBorder? from Function 'lerp': static.
    //     0x1164cbc: add             x16, PP, #0xad, lsl #12  ; [pp+0xadd18] Closure: (OutlinedBorder?, OutlinedBorder?, double) => OutlinedBorder? from Function 'lerp': static. (0x7f2adb04c118)
    //     0x1164cc0: ldr             x16, [x16, #0xd18]
    // 0x1164cc4: str             x16, [SP]
    // 0x1164cc8: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0x1164cc8: ldr             x4, [PP, #0x560]  ; [pp+0x560] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0x1164ccc: r0 = lerp()
    //     0x1164ccc: bl              #0x1165084  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::lerp
    // 0x1164cd0: ldur            d1, [fp, #-0xc0]
    // 0x1164cd4: d2 = 0.500000
    //     0x1164cd4: fmov            d2, #0.50000000
    // 0x1164cd8: stur            x0, [fp, #-0xb0]
    // 0x1164cdc: fcmp            d2, d1
    // 0x1164ce0: b.le            #0x1164d0c
    // 0x1164ce4: ldur            x3, [fp, #-8]
    // 0x1164ce8: cmp             w3, NULL
    // 0x1164cec: b.ne            #0x1164cf8
    // 0x1164cf0: r1 = Null
    //     0x1164cf0: mov             x1, NULL
    // 0x1164cf4: b               #0x1164d00
    // 0x1164cf8: LoadField: r1 = r3->field_47
    //     0x1164cf8: ldur            w1, [x3, #0x47]
    // 0x1164cfc: DecompressPointer r1
    //     0x1164cfc: add             x1, x1, HEAP, lsl #32
    // 0x1164d00: mov             x5, x1
    // 0x1164d04: ldur            x4, [fp, #-0x10]
    // 0x1164d08: b               #0x1164d30
    // 0x1164d0c: ldur            x3, [fp, #-8]
    // 0x1164d10: ldur            x4, [fp, #-0x10]
    // 0x1164d14: cmp             w4, NULL
    // 0x1164d18: b.ne            #0x1164d24
    // 0x1164d1c: r1 = Null
    //     0x1164d1c: mov             x1, NULL
    // 0x1164d20: b               #0x1164d2c
    // 0x1164d24: LoadField: r1 = r4->field_47
    //     0x1164d24: ldur            w1, [x4, #0x47]
    // 0x1164d28: DecompressPointer r1
    //     0x1164d28: add             x1, x1, HEAP, lsl #32
    // 0x1164d2c: mov             x5, x1
    // 0x1164d30: stur            x5, [fp, #-0xa8]
    // 0x1164d34: fcmp            d2, d1
    // 0x1164d38: b.le            #0x1164d5c
    // 0x1164d3c: cmp             w3, NULL
    // 0x1164d40: b.ne            #0x1164d4c
    // 0x1164d44: r1 = Null
    //     0x1164d44: mov             x1, NULL
    // 0x1164d48: b               #0x1164d54
    // 0x1164d4c: LoadField: r1 = r3->field_4b
    //     0x1164d4c: ldur            w1, [x3, #0x4b]
    // 0x1164d50: DecompressPointer r1
    //     0x1164d50: add             x1, x1, HEAP, lsl #32
    // 0x1164d54: mov             x6, x1
    // 0x1164d58: b               #0x1164d78
    // 0x1164d5c: cmp             w4, NULL
    // 0x1164d60: b.ne            #0x1164d6c
    // 0x1164d64: r1 = Null
    //     0x1164d64: mov             x1, NULL
    // 0x1164d68: b               #0x1164d74
    // 0x1164d6c: LoadField: r1 = r4->field_4b
    //     0x1164d6c: ldur            w1, [x4, #0x4b]
    // 0x1164d70: DecompressPointer r1
    //     0x1164d70: add             x1, x1, HEAP, lsl #32
    // 0x1164d74: mov             x6, x1
    // 0x1164d78: stur            x6, [fp, #-0xa0]
    // 0x1164d7c: fcmp            d2, d1
    // 0x1164d80: b.le            #0x1164da4
    // 0x1164d84: cmp             w3, NULL
    // 0x1164d88: b.ne            #0x1164d94
    // 0x1164d8c: r1 = Null
    //     0x1164d8c: mov             x1, NULL
    // 0x1164d90: b               #0x1164d9c
    // 0x1164d94: LoadField: r1 = r3->field_4f
    //     0x1164d94: ldur            w1, [x3, #0x4f]
    // 0x1164d98: DecompressPointer r1
    //     0x1164d98: add             x1, x1, HEAP, lsl #32
    // 0x1164d9c: mov             x7, x1
    // 0x1164da0: b               #0x1164dc0
    // 0x1164da4: cmp             w4, NULL
    // 0x1164da8: b.ne            #0x1164db4
    // 0x1164dac: r1 = Null
    //     0x1164dac: mov             x1, NULL
    // 0x1164db0: b               #0x1164dbc
    // 0x1164db4: LoadField: r1 = r4->field_4f
    //     0x1164db4: ldur            w1, [x4, #0x4f]
    // 0x1164db8: DecompressPointer r1
    //     0x1164db8: add             x1, x1, HEAP, lsl #32
    // 0x1164dbc: mov             x7, x1
    // 0x1164dc0: stur            x7, [fp, #-0x98]
    // 0x1164dc4: fcmp            d2, d1
    // 0x1164dc8: b.le            #0x1164dec
    // 0x1164dcc: cmp             w3, NULL
    // 0x1164dd0: b.ne            #0x1164ddc
    // 0x1164dd4: r1 = Null
    //     0x1164dd4: mov             x1, NULL
    // 0x1164dd8: b               #0x1164de4
    // 0x1164ddc: LoadField: r1 = r3->field_53
    //     0x1164ddc: ldur            w1, [x3, #0x53]
    // 0x1164de0: DecompressPointer r1
    //     0x1164de0: add             x1, x1, HEAP, lsl #32
    // 0x1164de4: mov             x8, x1
    // 0x1164de8: b               #0x1164e08
    // 0x1164dec: cmp             w4, NULL
    // 0x1164df0: b.ne            #0x1164dfc
    // 0x1164df4: r1 = Null
    //     0x1164df4: mov             x1, NULL
    // 0x1164df8: b               #0x1164e04
    // 0x1164dfc: LoadField: r1 = r4->field_53
    //     0x1164dfc: ldur            w1, [x4, #0x53]
    // 0x1164e00: DecompressPointer r1
    //     0x1164e00: add             x1, x1, HEAP, lsl #32
    // 0x1164e04: mov             x8, x1
    // 0x1164e08: stur            x8, [fp, #-0x90]
    // 0x1164e0c: fcmp            d2, d1
    // 0x1164e10: b.le            #0x1164e34
    // 0x1164e14: cmp             w3, NULL
    // 0x1164e18: b.ne            #0x1164e24
    // 0x1164e1c: r1 = Null
    //     0x1164e1c: mov             x1, NULL
    // 0x1164e20: b               #0x1164e2c
    // 0x1164e24: LoadField: r1 = r3->field_57
    //     0x1164e24: ldur            w1, [x3, #0x57]
    // 0x1164e28: DecompressPointer r1
    //     0x1164e28: add             x1, x1, HEAP, lsl #32
    // 0x1164e2c: mov             x9, x1
    // 0x1164e30: b               #0x1164e50
    // 0x1164e34: cmp             w4, NULL
    // 0x1164e38: b.ne            #0x1164e44
    // 0x1164e3c: r1 = Null
    //     0x1164e3c: mov             x1, NULL
    // 0x1164e40: b               #0x1164e4c
    // 0x1164e44: LoadField: r1 = r4->field_57
    //     0x1164e44: ldur            w1, [x4, #0x57]
    // 0x1164e48: DecompressPointer r1
    //     0x1164e48: add             x1, x1, HEAP, lsl #32
    // 0x1164e4c: mov             x9, x1
    // 0x1164e50: stur            x9, [fp, #-0x88]
    // 0x1164e54: cmp             w3, NULL
    // 0x1164e58: b.ne            #0x1164e64
    // 0x1164e5c: r1 = Null
    //     0x1164e5c: mov             x1, NULL
    // 0x1164e60: b               #0x1164e6c
    // 0x1164e64: LoadField: r1 = r3->field_5b
    //     0x1164e64: ldur            w1, [x3, #0x5b]
    // 0x1164e68: DecompressPointer r1
    //     0x1164e68: add             x1, x1, HEAP, lsl #32
    // 0x1164e6c: cmp             w4, NULL
    // 0x1164e70: b.ne            #0x1164e7c
    // 0x1164e74: r2 = Null
    //     0x1164e74: mov             x2, NULL
    // 0x1164e78: b               #0x1164e84
    // 0x1164e7c: LoadField: r2 = r4->field_5b
    //     0x1164e7c: ldur            w2, [x4, #0x5b]
    // 0x1164e80: DecompressPointer r2
    //     0x1164e80: add             x2, x2, HEAP, lsl #32
    // 0x1164e84: mov             v0.16b, v1.16b
    // 0x1164e88: r0 = lerp()
    //     0x1164e88: bl              #0x1160c48  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::lerp
    // 0x1164e8c: ldur            d0, [fp, #-0xc0]
    // 0x1164e90: d1 = 0.500000
    //     0x1164e90: fmov            d1, #0.50000000
    // 0x1164e94: stur            x0, [fp, #-0xb8]
    // 0x1164e98: fcmp            d1, d0
    // 0x1164e9c: b.le            #0x1164ec8
    // 0x1164ea0: ldur            x1, [fp, #-8]
    // 0x1164ea4: cmp             w1, NULL
    // 0x1164ea8: b.ne            #0x1164eb4
    // 0x1164eac: r1 = Null
    //     0x1164eac: mov             x1, NULL
    // 0x1164eb0: b               #0x1164ec0
    // 0x1164eb4: LoadField: r2 = r1->field_5f
    //     0x1164eb4: ldur            w2, [x1, #0x5f]
    // 0x1164eb8: DecompressPointer r2
    //     0x1164eb8: add             x2, x2, HEAP, lsl #32
    // 0x1164ebc: mov             x1, x2
    // 0x1164ec0: stur            x1, [fp, #-8]
    // 0x1164ec4: b               #0x1164eec
    // 0x1164ec8: ldur            x1, [fp, #-0x10]
    // 0x1164ecc: cmp             w1, NULL
    // 0x1164ed0: b.ne            #0x1164edc
    // 0x1164ed4: r1 = Null
    //     0x1164ed4: mov             x1, NULL
    // 0x1164ed8: b               #0x1164ee8
    // 0x1164edc: LoadField: r2 = r1->field_5f
    //     0x1164edc: ldur            w2, [x1, #0x5f]
    // 0x1164ee0: DecompressPointer r2
    //     0x1164ee0: add             x2, x2, HEAP, lsl #32
    // 0x1164ee4: mov             x1, x2
    // 0x1164ee8: stur            x1, [fp, #-8]
    // 0x1164eec: ldur            x25, [fp, #-0x20]
    // 0x1164ef0: ldur            x24, [fp, #-0x28]
    // 0x1164ef4: ldur            x23, [fp, #-0x30]
    // 0x1164ef8: ldur            x20, [fp, #-0x38]
    // 0x1164efc: ldur            x19, [fp, #-0x40]
    // 0x1164f00: ldur            x14, [fp, #-0x48]
    // 0x1164f04: ldur            x13, [fp, #-0x50]
    // 0x1164f08: ldur            x12, [fp, #-0x58]
    // 0x1164f0c: ldur            x11, [fp, #-0x60]
    // 0x1164f10: ldur            x10, [fp, #-0x68]
    // 0x1164f14: ldur            x9, [fp, #-0x70]
    // 0x1164f18: ldur            x8, [fp, #-0x78]
    // 0x1164f1c: ldur            x7, [fp, #-0x80]
    // 0x1164f20: ldur            x1, [fp, #-0xb0]
    // 0x1164f24: ldur            x2, [fp, #-0xa8]
    // 0x1164f28: ldur            x3, [fp, #-0xa0]
    // 0x1164f2c: ldur            x4, [fp, #-0x98]
    // 0x1164f30: ldur            x5, [fp, #-0x90]
    // 0x1164f34: ldur            x6, [fp, #-0x88]
    // 0x1164f38: r0 = ButtonStyle()
    //     0x1164f38: bl              #0xd17184  ; AllocateButtonStyleStub -> ButtonStyle (size=0x6c)
    // 0x1164f3c: ldur            x1, [fp, #-0x18]
    // 0x1164f40: StoreField: r0->field_7 = r1
    //     0x1164f40: stur            w1, [x0, #7]
    // 0x1164f44: ldur            x1, [fp, #-0x20]
    // 0x1164f48: StoreField: r0->field_b = r1
    //     0x1164f48: stur            w1, [x0, #0xb]
    // 0x1164f4c: ldur            x1, [fp, #-0x28]
    // 0x1164f50: StoreField: r0->field_f = r1
    //     0x1164f50: stur            w1, [x0, #0xf]
    // 0x1164f54: ldur            x1, [fp, #-0x30]
    // 0x1164f58: StoreField: r0->field_13 = r1
    //     0x1164f58: stur            w1, [x0, #0x13]
    // 0x1164f5c: ldur            x1, [fp, #-0x38]
    // 0x1164f60: ArrayStore: r0[0] = r1  ; List_4
    //     0x1164f60: stur            w1, [x0, #0x17]
    // 0x1164f64: ldur            x1, [fp, #-0x40]
    // 0x1164f68: StoreField: r0->field_1b = r1
    //     0x1164f68: stur            w1, [x0, #0x1b]
    // 0x1164f6c: ldur            x1, [fp, #-0x48]
    // 0x1164f70: StoreField: r0->field_1f = r1
    //     0x1164f70: stur            w1, [x0, #0x1f]
    // 0x1164f74: ldur            x1, [fp, #-0x50]
    // 0x1164f78: StoreField: r0->field_23 = r1
    //     0x1164f78: stur            w1, [x0, #0x23]
    // 0x1164f7c: ldur            x1, [fp, #-0x58]
    // 0x1164f80: StoreField: r0->field_27 = r1
    //     0x1164f80: stur            w1, [x0, #0x27]
    // 0x1164f84: ldur            x1, [fp, #-0x60]
    // 0x1164f88: StoreField: r0->field_2b = r1
    //     0x1164f88: stur            w1, [x0, #0x2b]
    // 0x1164f8c: ldur            x1, [fp, #-0x68]
    // 0x1164f90: StoreField: r0->field_2f = r1
    //     0x1164f90: stur            w1, [x0, #0x2f]
    // 0x1164f94: ldur            x1, [fp, #-0x70]
    // 0x1164f98: StoreField: r0->field_33 = r1
    //     0x1164f98: stur            w1, [x0, #0x33]
    // 0x1164f9c: ldur            x1, [fp, #-0x78]
    // 0x1164fa0: StoreField: r0->field_37 = r1
    //     0x1164fa0: stur            w1, [x0, #0x37]
    // 0x1164fa4: ldur            x1, [fp, #-0x80]
    // 0x1164fa8: StoreField: r0->field_3f = r1
    //     0x1164fa8: stur            w1, [x0, #0x3f]
    // 0x1164fac: ldur            x1, [fp, #-0xb0]
    // 0x1164fb0: StoreField: r0->field_43 = r1
    //     0x1164fb0: stur            w1, [x0, #0x43]
    // 0x1164fb4: ldur            x1, [fp, #-0xa8]
    // 0x1164fb8: StoreField: r0->field_47 = r1
    //     0x1164fb8: stur            w1, [x0, #0x47]
    // 0x1164fbc: ldur            x1, [fp, #-0xa0]
    // 0x1164fc0: StoreField: r0->field_4b = r1
    //     0x1164fc0: stur            w1, [x0, #0x4b]
    // 0x1164fc4: ldur            x1, [fp, #-0x98]
    // 0x1164fc8: StoreField: r0->field_4f = r1
    //     0x1164fc8: stur            w1, [x0, #0x4f]
    // 0x1164fcc: ldur            x1, [fp, #-0x90]
    // 0x1164fd0: StoreField: r0->field_53 = r1
    //     0x1164fd0: stur            w1, [x0, #0x53]
    // 0x1164fd4: ldur            x1, [fp, #-0x88]
    // 0x1164fd8: StoreField: r0->field_57 = r1
    //     0x1164fd8: stur            w1, [x0, #0x57]
    // 0x1164fdc: ldur            x1, [fp, #-0xb8]
    // 0x1164fe0: StoreField: r0->field_5b = r1
    //     0x1164fe0: stur            w1, [x0, #0x5b]
    // 0x1164fe4: ldur            x1, [fp, #-8]
    // 0x1164fe8: StoreField: r0->field_5f = r1
    //     0x1164fe8: stur            w1, [x0, #0x5f]
    // 0x1164fec: LeaveFrame
    //     0x1164fec: mov             SP, fp
    //     0x1164ff0: ldp             fp, lr, [SP], #0x10
    // 0x1164ff4: ret
    //     0x1164ff4: ret             
    // 0x1164ff8: r0 = StackOverflowSharedWithFPURegs()
    //     0x1164ff8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1164ffc: b               #0x116466c
  }
  const get _ mouseCursor(/* No info */) {
    // ** addr: 0x1243d64, size: 0xc
    // 0x1243d64: LoadField: r0 = r1->field_47
    //     0x1243d64: ldur            w0, [x1, #0x47]
    // 0x1243d68: DecompressPointer r0
    //     0x1243d68: add             x0, x0, HEAP, lsl #32
    // 0x1243d6c: ret
    //     0x1243d6c: ret             
  }
  const get _ tapTargetSize(/* No info */) {
    // ** addr: 0x1245fcc, size: 0xc
    // 0x1245fcc: LoadField: r0 = r1->field_4f
    //     0x1245fcc: ldur            w0, [x1, #0x4f]
    // 0x1245fd0: DecompressPointer r0
    //     0x1245fd0: add             x0, x0, HEAP, lsl #32
    // 0x1245fd4: ret
    //     0x1245fd4: ret             
  }
  const get _ splashFactory(/* No info */) {
    // ** addr: 0x124863c, size: 0xc
    // 0x124863c: LoadField: r0 = r1->field_5f
    //     0x124863c: ldur            w0, [x1, #0x5f]
    // 0x1248640: DecompressPointer r0
    //     0x1248640: add             x0, x0, HEAP, lsl #32
    // 0x1248644: ret
    //     0x1248644: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0x1264e0c, size: 0x91c
    // 0x1264e0c: EnterFrame
    //     0x1264e0c: stp             fp, lr, [SP, #-0x10]!
    //     0x1264e10: mov             fp, SP
    // 0x1264e14: AllocStack(0x18)
    //     0x1264e14: sub             SP, SP, #0x18
    // 0x1264e18: CheckStackOverflow
    //     0x1264e18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1264e1c: cmp             SP, x16
    //     0x1264e20: b.ls            #0x1265720
    // 0x1264e24: ldr             x1, [fp, #0x10]
    // 0x1264e28: cmp             w1, NULL
    // 0x1264e2c: b.ne            #0x1264e40
    // 0x1264e30: r0 = false
    //     0x1264e30: add             x0, NULL, #0x30  ; false
    // 0x1264e34: LeaveFrame
    //     0x1264e34: mov             SP, fp
    //     0x1264e38: ldp             fp, lr, [SP], #0x10
    // 0x1264e3c: ret
    //     0x1264e3c: ret             
    // 0x1264e40: ldr             x0, [fp, #0x18]
    // 0x1264e44: cmp             w0, w1
    // 0x1264e48: b.ne            #0x1264e5c
    // 0x1264e4c: r0 = true
    //     0x1264e4c: add             x0, NULL, #0x20  ; true
    // 0x1264e50: LeaveFrame
    //     0x1264e50: mov             SP, fp
    //     0x1264e54: ldp             fp, lr, [SP], #0x10
    // 0x1264e58: ret
    //     0x1264e58: ret             
    // 0x1264e5c: stp             x0, x1, [SP]
    // 0x1264e60: r0 = _haveSameRuntimeType()
    //     0x1264e60: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x1264e64: tbz             w0, #4, #0x1264e78
    // 0x1264e68: r0 = false
    //     0x1264e68: add             x0, NULL, #0x30  ; false
    // 0x1264e6c: LeaveFrame
    //     0x1264e6c: mov             SP, fp
    //     0x1264e70: ldp             fp, lr, [SP], #0x10
    // 0x1264e74: ret
    //     0x1264e74: ret             
    // 0x1264e78: ldr             x2, [fp, #0x10]
    // 0x1264e7c: r0 = 60
    //     0x1264e7c: mov             x0, #0x3c
    // 0x1264e80: branchIfSmi(r2, 0x1264e8c)
    //     0x1264e80: tbz             w2, #0, #0x1264e8c
    // 0x1264e84: r0 = LoadClassIdInstr(r2)
    //     0x1264e84: ldur            x0, [x2, #-1]
    //     0x1264e88: ubfx            x0, x0, #0xc, #0x14
    // 0x1264e8c: r17 = -5192
    //     0x1264e8c: mov             x17, #-0x1448
    // 0x1264e90: add             x16, x0, x17
    // 0x1264e94: cmp             x16, #7
    // 0x1264e98: b.hi            #0x1265710
    // 0x1264e9c: ldr             x3, [fp, #0x18]
    // 0x1264ea0: r0 = LoadClassIdInstr(r2)
    //     0x1264ea0: ldur            x0, [x2, #-1]
    //     0x1264ea4: ubfx            x0, x0, #0xc, #0x14
    // 0x1264ea8: mov             x1, x2
    // 0x1264eac: r0 = GDT[cid_x0 + 0xe00]()
    //     0x1264eac: add             lr, x0, #0xe00
    //     0x1264eb0: ldr             lr, [x21, lr, lsl #3]
    //     0x1264eb4: blr             lr
    // 0x1264eb8: mov             x3, x0
    // 0x1264ebc: ldr             x2, [fp, #0x18]
    // 0x1264ec0: stur            x3, [fp, #-8]
    // 0x1264ec4: r0 = LoadClassIdInstr(r2)
    //     0x1264ec4: ldur            x0, [x2, #-1]
    //     0x1264ec8: ubfx            x0, x0, #0xc, #0x14
    // 0x1264ecc: mov             x1, x2
    // 0x1264ed0: r0 = GDT[cid_x0 + 0xe00]()
    //     0x1264ed0: add             lr, x0, #0xe00
    //     0x1264ed4: ldr             lr, [x21, lr, lsl #3]
    //     0x1264ed8: blr             lr
    // 0x1264edc: mov             x1, x0
    // 0x1264ee0: ldur            x0, [fp, #-8]
    // 0x1264ee4: r2 = LoadClassIdInstr(r0)
    //     0x1264ee4: ldur            x2, [x0, #-1]
    //     0x1264ee8: ubfx            x2, x2, #0xc, #0x14
    // 0x1264eec: stp             x1, x0, [SP]
    // 0x1264ef0: mov             x0, x2
    // 0x1264ef4: mov             lr, x0
    // 0x1264ef8: ldr             lr, [x21, lr, lsl #3]
    // 0x1264efc: blr             lr
    // 0x1264f00: tbnz            w0, #4, #0x1265710
    // 0x1264f04: ldr             x2, [fp, #0x18]
    // 0x1264f08: ldr             x3, [fp, #0x10]
    // 0x1264f0c: r0 = LoadClassIdInstr(r3)
    //     0x1264f0c: ldur            x0, [x3, #-1]
    //     0x1264f10: ubfx            x0, x0, #0xc, #0x14
    // 0x1264f14: mov             x1, x3
    // 0x1264f18: r0 = GDT[cid_x0 + 0xf75]()
    //     0x1264f18: add             lr, x0, #0xf75
    //     0x1264f1c: ldr             lr, [x21, lr, lsl #3]
    //     0x1264f20: blr             lr
    // 0x1264f24: mov             x3, x0
    // 0x1264f28: ldr             x2, [fp, #0x18]
    // 0x1264f2c: stur            x3, [fp, #-8]
    // 0x1264f30: r0 = LoadClassIdInstr(r2)
    //     0x1264f30: ldur            x0, [x2, #-1]
    //     0x1264f34: ubfx            x0, x0, #0xc, #0x14
    // 0x1264f38: mov             x1, x2
    // 0x1264f3c: r0 = GDT[cid_x0 + 0xf75]()
    //     0x1264f3c: add             lr, x0, #0xf75
    //     0x1264f40: ldr             lr, [x21, lr, lsl #3]
    //     0x1264f44: blr             lr
    // 0x1264f48: mov             x1, x0
    // 0x1264f4c: ldur            x0, [fp, #-8]
    // 0x1264f50: r2 = LoadClassIdInstr(r0)
    //     0x1264f50: ldur            x2, [x0, #-1]
    //     0x1264f54: ubfx            x2, x2, #0xc, #0x14
    // 0x1264f58: stp             x1, x0, [SP]
    // 0x1264f5c: mov             x0, x2
    // 0x1264f60: mov             lr, x0
    // 0x1264f64: ldr             lr, [x21, lr, lsl #3]
    // 0x1264f68: blr             lr
    // 0x1264f6c: tbnz            w0, #4, #0x1265710
    // 0x1264f70: ldr             x2, [fp, #0x18]
    // 0x1264f74: ldr             x3, [fp, #0x10]
    // 0x1264f78: r0 = LoadClassIdInstr(r3)
    //     0x1264f78: ldur            x0, [x3, #-1]
    //     0x1264f7c: ubfx            x0, x0, #0xc, #0x14
    // 0x1264f80: mov             x1, x3
    // 0x1264f84: r0 = GDT[cid_x0 + 0xe62]()
    //     0x1264f84: add             lr, x0, #0xe62
    //     0x1264f88: ldr             lr, [x21, lr, lsl #3]
    //     0x1264f8c: blr             lr
    // 0x1264f90: mov             x3, x0
    // 0x1264f94: ldr             x2, [fp, #0x18]
    // 0x1264f98: stur            x3, [fp, #-8]
    // 0x1264f9c: r0 = LoadClassIdInstr(r2)
    //     0x1264f9c: ldur            x0, [x2, #-1]
    //     0x1264fa0: ubfx            x0, x0, #0xc, #0x14
    // 0x1264fa4: mov             x1, x2
    // 0x1264fa8: r0 = GDT[cid_x0 + 0xe62]()
    //     0x1264fa8: add             lr, x0, #0xe62
    //     0x1264fac: ldr             lr, [x21, lr, lsl #3]
    //     0x1264fb0: blr             lr
    // 0x1264fb4: mov             x1, x0
    // 0x1264fb8: ldur            x0, [fp, #-8]
    // 0x1264fbc: r2 = LoadClassIdInstr(r0)
    //     0x1264fbc: ldur            x2, [x0, #-1]
    //     0x1264fc0: ubfx            x2, x2, #0xc, #0x14
    // 0x1264fc4: stp             x1, x0, [SP]
    // 0x1264fc8: mov             x0, x2
    // 0x1264fcc: mov             lr, x0
    // 0x1264fd0: ldr             lr, [x21, lr, lsl #3]
    // 0x1264fd4: blr             lr
    // 0x1264fd8: tbnz            w0, #4, #0x1265710
    // 0x1264fdc: ldr             x2, [fp, #0x18]
    // 0x1264fe0: ldr             x3, [fp, #0x10]
    // 0x1264fe4: r0 = LoadClassIdInstr(r3)
    //     0x1264fe4: ldur            x0, [x3, #-1]
    //     0x1264fe8: ubfx            x0, x0, #0xc, #0x14
    // 0x1264fec: mov             x1, x3
    // 0x1264ff0: r0 = GDT[cid_x0 + 0xf41]()
    //     0x1264ff0: add             lr, x0, #0xf41
    //     0x1264ff4: ldr             lr, [x21, lr, lsl #3]
    //     0x1264ff8: blr             lr
    // 0x1264ffc: mov             x3, x0
    // 0x1265000: ldr             x2, [fp, #0x18]
    // 0x1265004: stur            x3, [fp, #-8]
    // 0x1265008: r0 = LoadClassIdInstr(r2)
    //     0x1265008: ldur            x0, [x2, #-1]
    //     0x126500c: ubfx            x0, x0, #0xc, #0x14
    // 0x1265010: mov             x1, x2
    // 0x1265014: r0 = GDT[cid_x0 + 0xf41]()
    //     0x1265014: add             lr, x0, #0xf41
    //     0x1265018: ldr             lr, [x21, lr, lsl #3]
    //     0x126501c: blr             lr
    // 0x1265020: mov             x1, x0
    // 0x1265024: ldur            x0, [fp, #-8]
    // 0x1265028: r2 = LoadClassIdInstr(r0)
    //     0x1265028: ldur            x2, [x0, #-1]
    //     0x126502c: ubfx            x2, x2, #0xc, #0x14
    // 0x1265030: stp             x1, x0, [SP]
    // 0x1265034: mov             x0, x2
    // 0x1265038: mov             lr, x0
    // 0x126503c: ldr             lr, [x21, lr, lsl #3]
    // 0x1265040: blr             lr
    // 0x1265044: tbnz            w0, #4, #0x1265710
    // 0x1265048: ldr             x2, [fp, #0x18]
    // 0x126504c: ldr             x3, [fp, #0x10]
    // 0x1265050: r0 = LoadClassIdInstr(r3)
    //     0x1265050: ldur            x0, [x3, #-1]
    //     0x1265054: ubfx            x0, x0, #0xc, #0x14
    // 0x1265058: mov             x1, x3
    // 0x126505c: r0 = GDT[cid_x0 + 0xf36]()
    //     0x126505c: add             lr, x0, #0xf36
    //     0x1265060: ldr             lr, [x21, lr, lsl #3]
    //     0x1265064: blr             lr
    // 0x1265068: mov             x3, x0
    // 0x126506c: ldr             x2, [fp, #0x18]
    // 0x1265070: stur            x3, [fp, #-8]
    // 0x1265074: r0 = LoadClassIdInstr(r2)
    //     0x1265074: ldur            x0, [x2, #-1]
    //     0x1265078: ubfx            x0, x0, #0xc, #0x14
    // 0x126507c: mov             x1, x2
    // 0x1265080: r0 = GDT[cid_x0 + 0xf36]()
    //     0x1265080: add             lr, x0, #0xf36
    //     0x1265084: ldr             lr, [x21, lr, lsl #3]
    //     0x1265088: blr             lr
    // 0x126508c: mov             x1, x0
    // 0x1265090: ldur            x0, [fp, #-8]
    // 0x1265094: r2 = LoadClassIdInstr(r0)
    //     0x1265094: ldur            x2, [x0, #-1]
    //     0x1265098: ubfx            x2, x2, #0xc, #0x14
    // 0x126509c: stp             x1, x0, [SP]
    // 0x12650a0: mov             x0, x2
    // 0x12650a4: mov             lr, x0
    // 0x12650a8: ldr             lr, [x21, lr, lsl #3]
    // 0x12650ac: blr             lr
    // 0x12650b0: tbnz            w0, #4, #0x1265710
    // 0x12650b4: ldr             x2, [fp, #0x18]
    // 0x12650b8: ldr             x3, [fp, #0x10]
    // 0x12650bc: r0 = LoadClassIdInstr(r3)
    //     0x12650bc: ldur            x0, [x3, #-1]
    //     0x12650c0: ubfx            x0, x0, #0xc, #0x14
    // 0x12650c4: mov             x1, x3
    // 0x12650c8: r0 = GDT[cid_x0 + 0x2930]()
    //     0x12650c8: mov             x17, #0x2930
    //     0x12650cc: add             lr, x0, x17
    //     0x12650d0: ldr             lr, [x21, lr, lsl #3]
    //     0x12650d4: blr             lr
    // 0x12650d8: mov             x3, x0
    // 0x12650dc: ldr             x2, [fp, #0x18]
    // 0x12650e0: stur            x3, [fp, #-8]
    // 0x12650e4: r0 = LoadClassIdInstr(r2)
    //     0x12650e4: ldur            x0, [x2, #-1]
    //     0x12650e8: ubfx            x0, x0, #0xc, #0x14
    // 0x12650ec: mov             x1, x2
    // 0x12650f0: r0 = GDT[cid_x0 + 0x2930]()
    //     0x12650f0: mov             x17, #0x2930
    //     0x12650f4: add             lr, x0, x17
    //     0x12650f8: ldr             lr, [x21, lr, lsl #3]
    //     0x12650fc: blr             lr
    // 0x1265100: mov             x1, x0
    // 0x1265104: ldur            x0, [fp, #-8]
    // 0x1265108: r2 = LoadClassIdInstr(r0)
    //     0x1265108: ldur            x2, [x0, #-1]
    //     0x126510c: ubfx            x2, x2, #0xc, #0x14
    // 0x1265110: stp             x1, x0, [SP]
    // 0x1265114: mov             x0, x2
    // 0x1265118: mov             lr, x0
    // 0x126511c: ldr             lr, [x21, lr, lsl #3]
    // 0x1265120: blr             lr
    // 0x1265124: tbnz            w0, #4, #0x1265710
    // 0x1265128: ldr             x2, [fp, #0x18]
    // 0x126512c: ldr             x3, [fp, #0x10]
    // 0x1265130: r0 = LoadClassIdInstr(r3)
    //     0x1265130: ldur            x0, [x3, #-1]
    //     0x1265134: ubfx            x0, x0, #0xc, #0x14
    // 0x1265138: mov             x1, x3
    // 0x126513c: r0 = GDT[cid_x0 + 0xea7]()
    //     0x126513c: add             lr, x0, #0xea7
    //     0x1265140: ldr             lr, [x21, lr, lsl #3]
    //     0x1265144: blr             lr
    // 0x1265148: mov             x3, x0
    // 0x126514c: ldr             x2, [fp, #0x18]
    // 0x1265150: stur            x3, [fp, #-8]
    // 0x1265154: r0 = LoadClassIdInstr(r2)
    //     0x1265154: ldur            x0, [x2, #-1]
    //     0x1265158: ubfx            x0, x0, #0xc, #0x14
    // 0x126515c: mov             x1, x2
    // 0x1265160: r0 = GDT[cid_x0 + 0xea7]()
    //     0x1265160: add             lr, x0, #0xea7
    //     0x1265164: ldr             lr, [x21, lr, lsl #3]
    //     0x1265168: blr             lr
    // 0x126516c: mov             x1, x0
    // 0x1265170: ldur            x0, [fp, #-8]
    // 0x1265174: r2 = LoadClassIdInstr(r0)
    //     0x1265174: ldur            x2, [x0, #-1]
    //     0x1265178: ubfx            x2, x2, #0xc, #0x14
    // 0x126517c: stp             x1, x0, [SP]
    // 0x1265180: mov             x0, x2
    // 0x1265184: mov             lr, x0
    // 0x1265188: ldr             lr, [x21, lr, lsl #3]
    // 0x126518c: blr             lr
    // 0x1265190: tbnz            w0, #4, #0x1265710
    // 0x1265194: ldr             x2, [fp, #0x18]
    // 0x1265198: ldr             x3, [fp, #0x10]
    // 0x126519c: r0 = LoadClassIdInstr(r3)
    //     0x126519c: ldur            x0, [x3, #-1]
    //     0x12651a0: ubfx            x0, x0, #0xc, #0x14
    // 0x12651a4: mov             x1, x3
    // 0x12651a8: r0 = GDT[cid_x0 + 0x6f31]()
    //     0x12651a8: mov             x17, #0x6f31
    //     0x12651ac: add             lr, x0, x17
    //     0x12651b0: ldr             lr, [x21, lr, lsl #3]
    //     0x12651b4: blr             lr
    // 0x12651b8: mov             x3, x0
    // 0x12651bc: ldr             x2, [fp, #0x18]
    // 0x12651c0: stur            x3, [fp, #-8]
    // 0x12651c4: r0 = LoadClassIdInstr(r2)
    //     0x12651c4: ldur            x0, [x2, #-1]
    //     0x12651c8: ubfx            x0, x0, #0xc, #0x14
    // 0x12651cc: mov             x1, x2
    // 0x12651d0: r0 = GDT[cid_x0 + 0x6f31]()
    //     0x12651d0: mov             x17, #0x6f31
    //     0x12651d4: add             lr, x0, x17
    //     0x12651d8: ldr             lr, [x21, lr, lsl #3]
    //     0x12651dc: blr             lr
    // 0x12651e0: mov             x1, x0
    // 0x12651e4: ldur            x0, [fp, #-8]
    // 0x12651e8: r2 = LoadClassIdInstr(r0)
    //     0x12651e8: ldur            x2, [x0, #-1]
    //     0x12651ec: ubfx            x2, x2, #0xc, #0x14
    // 0x12651f0: stp             x1, x0, [SP]
    // 0x12651f4: mov             x0, x2
    // 0x12651f8: mov             lr, x0
    // 0x12651fc: ldr             lr, [x21, lr, lsl #3]
    // 0x1265200: blr             lr
    // 0x1265204: tbnz            w0, #4, #0x1265710
    // 0x1265208: ldr             x2, [fp, #0x18]
    // 0x126520c: ldr             x3, [fp, #0x10]
    // 0x1265210: r0 = LoadClassIdInstr(r3)
    //     0x1265210: ldur            x0, [x3, #-1]
    //     0x1265214: ubfx            x0, x0, #0xc, #0x14
    // 0x1265218: mov             x1, x3
    // 0x126521c: r0 = GDT[cid_x0 + 0x5659]()
    //     0x126521c: mov             x17, #0x5659
    //     0x1265220: add             lr, x0, x17
    //     0x1265224: ldr             lr, [x21, lr, lsl #3]
    //     0x1265228: blr             lr
    // 0x126522c: mov             x3, x0
    // 0x1265230: ldr             x2, [fp, #0x18]
    // 0x1265234: stur            x3, [fp, #-8]
    // 0x1265238: r0 = LoadClassIdInstr(r2)
    //     0x1265238: ldur            x0, [x2, #-1]
    //     0x126523c: ubfx            x0, x0, #0xc, #0x14
    // 0x1265240: mov             x1, x2
    // 0x1265244: r0 = GDT[cid_x0 + 0x5659]()
    //     0x1265244: mov             x17, #0x5659
    //     0x1265248: add             lr, x0, x17
    //     0x126524c: ldr             lr, [x21, lr, lsl #3]
    //     0x1265250: blr             lr
    // 0x1265254: mov             x1, x0
    // 0x1265258: ldur            x0, [fp, #-8]
    // 0x126525c: r2 = LoadClassIdInstr(r0)
    //     0x126525c: ldur            x2, [x0, #-1]
    //     0x1265260: ubfx            x2, x2, #0xc, #0x14
    // 0x1265264: stp             x1, x0, [SP]
    // 0x1265268: mov             x0, x2
    // 0x126526c: mov             lr, x0
    // 0x1265270: ldr             lr, [x21, lr, lsl #3]
    // 0x1265274: blr             lr
    // 0x1265278: tbnz            w0, #4, #0x1265710
    // 0x126527c: ldr             x1, [fp, #0x18]
    // 0x1265280: ldr             x2, [fp, #0x10]
    // 0x1265284: LoadField: r0 = r2->field_2b
    //     0x1265284: ldur            w0, [x2, #0x2b]
    // 0x1265288: DecompressPointer r0
    //     0x1265288: add             x0, x0, HEAP, lsl #32
    // 0x126528c: LoadField: r3 = r1->field_2b
    //     0x126528c: ldur            w3, [x1, #0x2b]
    // 0x1265290: DecompressPointer r3
    //     0x1265290: add             x3, x3, HEAP, lsl #32
    // 0x1265294: r4 = LoadClassIdInstr(r0)
    //     0x1265294: ldur            x4, [x0, #-1]
    //     0x1265298: ubfx            x4, x4, #0xc, #0x14
    // 0x126529c: stp             x3, x0, [SP]
    // 0x12652a0: mov             x0, x4
    // 0x12652a4: mov             lr, x0
    // 0x12652a8: ldr             lr, [x21, lr, lsl #3]
    // 0x12652ac: blr             lr
    // 0x12652b0: tbnz            w0, #4, #0x1265710
    // 0x12652b4: ldr             x2, [fp, #0x18]
    // 0x12652b8: ldr             x3, [fp, #0x10]
    // 0x12652bc: r0 = LoadClassIdInstr(r3)
    //     0x12652bc: ldur            x0, [x3, #-1]
    //     0x12652c0: ubfx            x0, x0, #0xc, #0x14
    // 0x12652c4: mov             x1, x3
    // 0x12652c8: r0 = GDT[cid_x0 + 0x5978]()
    //     0x12652c8: mov             x17, #0x5978
    //     0x12652cc: add             lr, x0, x17
    //     0x12652d0: ldr             lr, [x21, lr, lsl #3]
    //     0x12652d4: blr             lr
    // 0x12652d8: mov             x3, x0
    // 0x12652dc: ldr             x2, [fp, #0x18]
    // 0x12652e0: stur            x3, [fp, #-8]
    // 0x12652e4: r0 = LoadClassIdInstr(r2)
    //     0x12652e4: ldur            x0, [x2, #-1]
    //     0x12652e8: ubfx            x0, x0, #0xc, #0x14
    // 0x12652ec: mov             x1, x2
    // 0x12652f0: r0 = GDT[cid_x0 + 0x5978]()
    //     0x12652f0: mov             x17, #0x5978
    //     0x12652f4: add             lr, x0, x17
    //     0x12652f8: ldr             lr, [x21, lr, lsl #3]
    //     0x12652fc: blr             lr
    // 0x1265300: mov             x1, x0
    // 0x1265304: ldur            x0, [fp, #-8]
    // 0x1265308: r2 = LoadClassIdInstr(r0)
    //     0x1265308: ldur            x2, [x0, #-1]
    //     0x126530c: ubfx            x2, x2, #0xc, #0x14
    // 0x1265310: stp             x1, x0, [SP]
    // 0x1265314: mov             x0, x2
    // 0x1265318: mov             lr, x0
    // 0x126531c: ldr             lr, [x21, lr, lsl #3]
    // 0x1265320: blr             lr
    // 0x1265324: tbnz            w0, #4, #0x1265710
    // 0x1265328: ldr             x2, [fp, #0x18]
    // 0x126532c: ldr             x3, [fp, #0x10]
    // 0x1265330: r0 = LoadClassIdInstr(r3)
    //     0x1265330: ldur            x0, [x3, #-1]
    //     0x1265334: ubfx            x0, x0, #0xc, #0x14
    // 0x1265338: mov             x1, x3
    // 0x126533c: r0 = GDT[cid_x0 + 0x60e5]()
    //     0x126533c: mov             x17, #0x60e5
    //     0x1265340: add             lr, x0, x17
    //     0x1265344: ldr             lr, [x21, lr, lsl #3]
    //     0x1265348: blr             lr
    // 0x126534c: mov             x3, x0
    // 0x1265350: ldr             x2, [fp, #0x18]
    // 0x1265354: stur            x3, [fp, #-8]
    // 0x1265358: r0 = LoadClassIdInstr(r2)
    //     0x1265358: ldur            x0, [x2, #-1]
    //     0x126535c: ubfx            x0, x0, #0xc, #0x14
    // 0x1265360: mov             x1, x2
    // 0x1265364: r0 = GDT[cid_x0 + 0x60e5]()
    //     0x1265364: mov             x17, #0x60e5
    //     0x1265368: add             lr, x0, x17
    //     0x126536c: ldr             lr, [x21, lr, lsl #3]
    //     0x1265370: blr             lr
    // 0x1265374: mov             x1, x0
    // 0x1265378: ldur            x0, [fp, #-8]
    // 0x126537c: r2 = LoadClassIdInstr(r0)
    //     0x126537c: ldur            x2, [x0, #-1]
    //     0x1265380: ubfx            x2, x2, #0xc, #0x14
    // 0x1265384: stp             x1, x0, [SP]
    // 0x1265388: mov             x0, x2
    // 0x126538c: mov             lr, x0
    // 0x1265390: ldr             lr, [x21, lr, lsl #3]
    // 0x1265394: blr             lr
    // 0x1265398: tbnz            w0, #4, #0x1265710
    // 0x126539c: ldr             x2, [fp, #0x18]
    // 0x12653a0: ldr             x3, [fp, #0x10]
    // 0x12653a4: r0 = LoadClassIdInstr(r3)
    //     0x12653a4: ldur            x0, [x3, #-1]
    //     0x12653a8: ubfx            x0, x0, #0xc, #0x14
    // 0x12653ac: mov             x1, x3
    // 0x12653b0: r0 = GDT[cid_x0 + 0x610d]()
    //     0x12653b0: mov             x17, #0x610d
    //     0x12653b4: add             lr, x0, x17
    //     0x12653b8: ldr             lr, [x21, lr, lsl #3]
    //     0x12653bc: blr             lr
    // 0x12653c0: mov             x3, x0
    // 0x12653c4: ldr             x2, [fp, #0x18]
    // 0x12653c8: stur            x3, [fp, #-8]
    // 0x12653cc: r0 = LoadClassIdInstr(r2)
    //     0x12653cc: ldur            x0, [x2, #-1]
    //     0x12653d0: ubfx            x0, x0, #0xc, #0x14
    // 0x12653d4: mov             x1, x2
    // 0x12653d8: r0 = GDT[cid_x0 + 0x610d]()
    //     0x12653d8: mov             x17, #0x610d
    //     0x12653dc: add             lr, x0, x17
    //     0x12653e0: ldr             lr, [x21, lr, lsl #3]
    //     0x12653e4: blr             lr
    // 0x12653e8: mov             x1, x0
    // 0x12653ec: ldur            x0, [fp, #-8]
    // 0x12653f0: r2 = LoadClassIdInstr(r0)
    //     0x12653f0: ldur            x2, [x0, #-1]
    //     0x12653f4: ubfx            x2, x2, #0xc, #0x14
    // 0x12653f8: stp             x1, x0, [SP]
    // 0x12653fc: mov             x0, x2
    // 0x1265400: mov             lr, x0
    // 0x1265404: ldr             lr, [x21, lr, lsl #3]
    // 0x1265408: blr             lr
    // 0x126540c: tbnz            w0, #4, #0x1265710
    // 0x1265410: ldr             x2, [fp, #0x18]
    // 0x1265414: ldr             x3, [fp, #0x10]
    // 0x1265418: r0 = LoadClassIdInstr(r3)
    //     0x1265418: ldur            x0, [x3, #-1]
    //     0x126541c: ubfx            x0, x0, #0xc, #0x14
    // 0x1265420: mov             x1, x3
    // 0x1265424: r0 = GDT[cid_x0 + 0x3576]()
    //     0x1265424: mov             x17, #0x3576
    //     0x1265428: add             lr, x0, x17
    //     0x126542c: ldr             lr, [x21, lr, lsl #3]
    //     0x1265430: blr             lr
    // 0x1265434: mov             x3, x0
    // 0x1265438: ldr             x2, [fp, #0x18]
    // 0x126543c: stur            x3, [fp, #-8]
    // 0x1265440: r0 = LoadClassIdInstr(r2)
    //     0x1265440: ldur            x0, [x2, #-1]
    //     0x1265444: ubfx            x0, x0, #0xc, #0x14
    // 0x1265448: mov             x1, x2
    // 0x126544c: r0 = GDT[cid_x0 + 0x3576]()
    //     0x126544c: mov             x17, #0x3576
    //     0x1265450: add             lr, x0, x17
    //     0x1265454: ldr             lr, [x21, lr, lsl #3]
    //     0x1265458: blr             lr
    // 0x126545c: mov             x1, x0
    // 0x1265460: ldur            x0, [fp, #-8]
    // 0x1265464: r2 = LoadClassIdInstr(r0)
    //     0x1265464: ldur            x2, [x0, #-1]
    //     0x1265468: ubfx            x2, x2, #0xc, #0x14
    // 0x126546c: stp             x1, x0, [SP]
    // 0x1265470: mov             x0, x2
    // 0x1265474: mov             lr, x0
    // 0x1265478: ldr             lr, [x21, lr, lsl #3]
    // 0x126547c: blr             lr
    // 0x1265480: tbnz            w0, #4, #0x1265710
    // 0x1265484: ldr             x2, [fp, #0x18]
    // 0x1265488: ldr             x3, [fp, #0x10]
    // 0x126548c: r0 = LoadClassIdInstr(r3)
    //     0x126548c: ldur            x0, [x3, #-1]
    //     0x1265490: ubfx            x0, x0, #0xc, #0x14
    // 0x1265494: mov             x1, x3
    // 0x1265498: r0 = GDT[cid_x0 + 0xf2e]()
    //     0x1265498: add             lr, x0, #0xf2e
    //     0x126549c: ldr             lr, [x21, lr, lsl #3]
    //     0x12654a0: blr             lr
    // 0x12654a4: mov             x3, x0
    // 0x12654a8: ldr             x2, [fp, #0x18]
    // 0x12654ac: stur            x3, [fp, #-8]
    // 0x12654b0: r0 = LoadClassIdInstr(r2)
    //     0x12654b0: ldur            x0, [x2, #-1]
    //     0x12654b4: ubfx            x0, x0, #0xc, #0x14
    // 0x12654b8: mov             x1, x2
    // 0x12654bc: r0 = GDT[cid_x0 + 0xf2e]()
    //     0x12654bc: add             lr, x0, #0xf2e
    //     0x12654c0: ldr             lr, [x21, lr, lsl #3]
    //     0x12654c4: blr             lr
    // 0x12654c8: mov             x1, x0
    // 0x12654cc: ldur            x0, [fp, #-8]
    // 0x12654d0: r2 = LoadClassIdInstr(r0)
    //     0x12654d0: ldur            x2, [x0, #-1]
    //     0x12654d4: ubfx            x2, x2, #0xc, #0x14
    // 0x12654d8: stp             x1, x0, [SP]
    // 0x12654dc: mov             x0, x2
    // 0x12654e0: mov             lr, x0
    // 0x12654e4: ldr             lr, [x21, lr, lsl #3]
    // 0x12654e8: blr             lr
    // 0x12654ec: tbnz            w0, #4, #0x1265710
    // 0x12654f0: ldr             x2, [fp, #0x18]
    // 0x12654f4: ldr             x3, [fp, #0x10]
    // 0x12654f8: r0 = LoadClassIdInstr(r3)
    //     0x12654f8: ldur            x0, [x3, #-1]
    //     0x12654fc: ubfx            x0, x0, #0xc, #0x14
    // 0x1265500: mov             x1, x3
    // 0x1265504: r0 = GDT[cid_x0 + 0xf13]()
    //     0x1265504: add             lr, x0, #0xf13
    //     0x1265508: ldr             lr, [x21, lr, lsl #3]
    //     0x126550c: blr             lr
    // 0x1265510: mov             x3, x0
    // 0x1265514: ldr             x2, [fp, #0x18]
    // 0x1265518: stur            x3, [fp, #-8]
    // 0x126551c: r0 = LoadClassIdInstr(r2)
    //     0x126551c: ldur            x0, [x2, #-1]
    //     0x1265520: ubfx            x0, x0, #0xc, #0x14
    // 0x1265524: mov             x1, x2
    // 0x1265528: r0 = GDT[cid_x0 + 0xf13]()
    //     0x1265528: add             lr, x0, #0xf13
    //     0x126552c: ldr             lr, [x21, lr, lsl #3]
    //     0x1265530: blr             lr
    // 0x1265534: mov             x1, x0
    // 0x1265538: ldur            x0, [fp, #-8]
    // 0x126553c: r2 = LoadClassIdInstr(r0)
    //     0x126553c: ldur            x2, [x0, #-1]
    //     0x1265540: ubfx            x2, x2, #0xc, #0x14
    // 0x1265544: stp             x1, x0, [SP]
    // 0x1265548: mov             x0, x2
    // 0x126554c: mov             lr, x0
    // 0x1265550: ldr             lr, [x21, lr, lsl #3]
    // 0x1265554: blr             lr
    // 0x1265558: tbnz            w0, #4, #0x1265710
    // 0x126555c: ldr             x2, [fp, #0x18]
    // 0x1265560: ldr             x3, [fp, #0x10]
    // 0x1265564: r0 = LoadClassIdInstr(r3)
    //     0x1265564: ldur            x0, [x3, #-1]
    //     0x1265568: ubfx            x0, x0, #0xc, #0x14
    // 0x126556c: mov             x1, x3
    // 0x1265570: r0 = GDT[cid_x0 + 0xef9]()
    //     0x1265570: add             lr, x0, #0xef9
    //     0x1265574: ldr             lr, [x21, lr, lsl #3]
    //     0x1265578: blr             lr
    // 0x126557c: mov             x3, x0
    // 0x1265580: ldr             x2, [fp, #0x18]
    // 0x1265584: stur            x3, [fp, #-8]
    // 0x1265588: r0 = LoadClassIdInstr(r2)
    //     0x1265588: ldur            x0, [x2, #-1]
    //     0x126558c: ubfx            x0, x0, #0xc, #0x14
    // 0x1265590: mov             x1, x2
    // 0x1265594: r0 = GDT[cid_x0 + 0xef9]()
    //     0x1265594: add             lr, x0, #0xef9
    //     0x1265598: ldr             lr, [x21, lr, lsl #3]
    //     0x126559c: blr             lr
    // 0x12655a0: mov             x1, x0
    // 0x12655a4: ldur            x0, [fp, #-8]
    // 0x12655a8: r2 = LoadClassIdInstr(r0)
    //     0x12655a8: ldur            x2, [x0, #-1]
    //     0x12655ac: ubfx            x2, x2, #0xc, #0x14
    // 0x12655b0: stp             x1, x0, [SP]
    // 0x12655b4: mov             x0, x2
    // 0x12655b8: mov             lr, x0
    // 0x12655bc: ldr             lr, [x21, lr, lsl #3]
    // 0x12655c0: blr             lr
    // 0x12655c4: tbnz            w0, #4, #0x1265710
    // 0x12655c8: ldr             x2, [fp, #0x18]
    // 0x12655cc: ldr             x3, [fp, #0x10]
    // 0x12655d0: r0 = LoadClassIdInstr(r3)
    //     0x12655d0: ldur            x0, [x3, #-1]
    //     0x12655d4: ubfx            x0, x0, #0xc, #0x14
    // 0x12655d8: mov             x1, x3
    // 0x12655dc: r0 = GDT[cid_x0 + 0xef1]()
    //     0x12655dc: add             lr, x0, #0xef1
    //     0x12655e0: ldr             lr, [x21, lr, lsl #3]
    //     0x12655e4: blr             lr
    // 0x12655e8: mov             x3, x0
    // 0x12655ec: ldr             x2, [fp, #0x18]
    // 0x12655f0: stur            x3, [fp, #-8]
    // 0x12655f4: r0 = LoadClassIdInstr(r2)
    //     0x12655f4: ldur            x0, [x2, #-1]
    //     0x12655f8: ubfx            x0, x0, #0xc, #0x14
    // 0x12655fc: mov             x1, x2
    // 0x1265600: r0 = GDT[cid_x0 + 0xef1]()
    //     0x1265600: add             lr, x0, #0xef1
    //     0x1265604: ldr             lr, [x21, lr, lsl #3]
    //     0x1265608: blr             lr
    // 0x126560c: mov             x1, x0
    // 0x1265610: ldur            x0, [fp, #-8]
    // 0x1265614: cmp             w0, w1
    // 0x1265618: b.ne            #0x1265710
    // 0x126561c: ldr             x1, [fp, #0x18]
    // 0x1265620: ldr             x2, [fp, #0x10]
    // 0x1265624: LoadField: r0 = r2->field_53
    //     0x1265624: ldur            w0, [x2, #0x53]
    // 0x1265628: DecompressPointer r0
    //     0x1265628: add             x0, x0, HEAP, lsl #32
    // 0x126562c: LoadField: r3 = r1->field_53
    //     0x126562c: ldur            w3, [x1, #0x53]
    // 0x1265630: DecompressPointer r3
    //     0x1265630: add             x3, x3, HEAP, lsl #32
    // 0x1265634: r4 = LoadClassIdInstr(r0)
    //     0x1265634: ldur            x4, [x0, #-1]
    //     0x1265638: ubfx            x4, x4, #0xc, #0x14
    // 0x126563c: stp             x3, x0, [SP]
    // 0x1265640: mov             x0, x4
    // 0x1265644: mov             lr, x0
    // 0x1265648: ldr             lr, [x21, lr, lsl #3]
    // 0x126564c: blr             lr
    // 0x1265650: tbnz            w0, #4, #0x1265710
    // 0x1265654: ldr             x1, [fp, #0x18]
    // 0x1265658: ldr             x2, [fp, #0x10]
    // 0x126565c: LoadField: r0 = r2->field_57
    //     0x126565c: ldur            w0, [x2, #0x57]
    // 0x1265660: DecompressPointer r0
    //     0x1265660: add             x0, x0, HEAP, lsl #32
    // 0x1265664: LoadField: r3 = r1->field_57
    //     0x1265664: ldur            w3, [x1, #0x57]
    // 0x1265668: DecompressPointer r3
    //     0x1265668: add             x3, x3, HEAP, lsl #32
    // 0x126566c: cmp             w0, w3
    // 0x1265670: b.ne            #0x1265710
    // 0x1265674: LoadField: r0 = r2->field_5b
    //     0x1265674: ldur            w0, [x2, #0x5b]
    // 0x1265678: DecompressPointer r0
    //     0x1265678: add             x0, x0, HEAP, lsl #32
    // 0x126567c: LoadField: r3 = r1->field_5b
    //     0x126567c: ldur            w3, [x1, #0x5b]
    // 0x1265680: DecompressPointer r3
    //     0x1265680: add             x3, x3, HEAP, lsl #32
    // 0x1265684: r4 = LoadClassIdInstr(r0)
    //     0x1265684: ldur            x4, [x0, #-1]
    //     0x1265688: ubfx            x4, x4, #0xc, #0x14
    // 0x126568c: stp             x3, x0, [SP]
    // 0x1265690: mov             x0, x4
    // 0x1265694: mov             lr, x0
    // 0x1265698: ldr             lr, [x21, lr, lsl #3]
    // 0x126569c: blr             lr
    // 0x12656a0: tbnz            w0, #4, #0x1265710
    // 0x12656a4: ldr             x2, [fp, #0x18]
    // 0x12656a8: ldr             x1, [fp, #0x10]
    // 0x12656ac: r0 = LoadClassIdInstr(r1)
    //     0x12656ac: ldur            x0, [x1, #-1]
    //     0x12656b0: ubfx            x0, x0, #0xc, #0x14
    // 0x12656b4: r0 = GDT[cid_x0 + 0xed5]()
    //     0x12656b4: add             lr, x0, #0xed5
    //     0x12656b8: ldr             lr, [x21, lr, lsl #3]
    //     0x12656bc: blr             lr
    // 0x12656c0: mov             x2, x0
    // 0x12656c4: ldr             x1, [fp, #0x18]
    // 0x12656c8: stur            x2, [fp, #-8]
    // 0x12656cc: r0 = LoadClassIdInstr(r1)
    //     0x12656cc: ldur            x0, [x1, #-1]
    //     0x12656d0: ubfx            x0, x0, #0xc, #0x14
    // 0x12656d4: r0 = GDT[cid_x0 + 0xed5]()
    //     0x12656d4: add             lr, x0, #0xed5
    //     0x12656d8: ldr             lr, [x21, lr, lsl #3]
    //     0x12656dc: blr             lr
    // 0x12656e0: mov             x1, x0
    // 0x12656e4: ldur            x0, [fp, #-8]
    // 0x12656e8: r2 = LoadClassIdInstr(r0)
    //     0x12656e8: ldur            x2, [x0, #-1]
    //     0x12656ec: ubfx            x2, x2, #0xc, #0x14
    // 0x12656f0: stp             x1, x0, [SP]
    // 0x12656f4: mov             x0, x2
    // 0x12656f8: mov             lr, x0
    // 0x12656fc: ldr             lr, [x21, lr, lsl #3]
    // 0x1265700: blr             lr
    // 0x1265704: tbnz            w0, #4, #0x1265710
    // 0x1265708: r0 = true
    //     0x1265708: add             x0, NULL, #0x20  ; true
    // 0x126570c: b               #0x1265714
    // 0x1265710: r0 = false
    //     0x1265710: add             x0, NULL, #0x30  ; false
    // 0x1265714: LeaveFrame
    //     0x1265714: mov             SP, fp
    //     0x1265718: ldp             fp, lr, [SP], #0x10
    // 0x126571c: ret
    //     0x126571c: ret             
    // 0x1265720: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1265720: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1265724: b               #0x1264e24
  }
}
