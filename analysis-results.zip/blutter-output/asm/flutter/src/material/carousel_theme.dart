// lib: , url: package:flutter/src/material/carousel_theme.dart

// class id: 1048863, size: 0x8
class :: {
}

// class id: 5176, size: 0x20, field offset: 0x8
//   const constructor, 
class CarouselViewThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x112fbe0, size: 0x68
    // 0x112fbe0: EnterFrame
    //     0x112fbe0: stp             fp, lr, [SP, #-0x10]!
    //     0x112fbe4: mov             fp, SP
    // 0x112fbe8: AllocStack(0x20)
    //     0x112fbe8: sub             SP, SP, #0x20
    // 0x112fbec: CheckStackOverflow
    //     0x112fbec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112fbf0: cmp             SP, x16
    //     0x112fbf4: b.ls            #0x112fc40
    // 0x112fbf8: ldr             x0, [fp, #0x10]
    // 0x112fbfc: LoadField: r2 = r0->field_f
    //     0x112fbfc: ldur            w2, [x0, #0xf]
    // 0x112fc00: DecompressPointer r2
    //     0x112fc00: add             x2, x2, HEAP, lsl #32
    // 0x112fc04: stp             NULL, NULL, [SP, #0x10]
    // 0x112fc08: stp             NULL, NULL, [SP]
    // 0x112fc0c: r1 = Null
    //     0x112fc0c: mov             x1, NULL
    // 0x112fc10: r4 = const [0, 0x6, 0x4, 0x6, null]
    //     0x112fc10: add             x4, PP, #0xd, lsl #12  ; [pp+0xdd28] List(5) [0, 0x6, 0x4, 0x6, Null]
    //     0x112fc14: ldr             x4, [x4, #0xd28]
    // 0x112fc18: r0 = hash()
    //     0x112fc18: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x112fc1c: mov             x2, x0
    // 0x112fc20: r0 = BoxInt64Instr(r2)
    //     0x112fc20: sbfiz           x0, x2, #1, #0x1f
    //     0x112fc24: cmp             x2, x0, asr #1
    //     0x112fc28: b.eq            #0x112fc34
    //     0x112fc2c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x112fc30: stur            x2, [x0, #7]
    // 0x112fc34: LeaveFrame
    //     0x112fc34: mov             SP, fp
    //     0x112fc38: ldp             fp, lr, [SP], #0x10
    // 0x112fc3c: ret
    //     0x112fc3c: ret             
    // 0x112fc40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112fc40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112fc44: b               #0x112fbf8
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1168460, size: 0x104
    // 0x1168460: EnterFrame
    //     0x1168460: stp             fp, lr, [SP, #-0x10]!
    //     0x1168464: mov             fp, SP
    // 0x1168468: AllocStack(0x20)
    //     0x1168468: sub             SP, SP, #0x20
    // 0x116846c: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x20 */)
    //     0x116846c: mov             x4, x1
    //     0x1168470: mov             x0, x2
    //     0x1168474: stur            x1, [fp, #-0x10]
    //     0x1168478: stur            x2, [fp, #-0x18]
    //     0x116847c: stur            d0, [fp, #-0x20]
    // 0x1168480: CheckStackOverflow
    //     0x1168480: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1168484: cmp             SP, x16
    //     0x1168488: b.ls            #0x1168540
    // 0x116848c: cmp             w4, w0
    // 0x1168490: b.ne            #0x11684a4
    // 0x1168494: mov             x0, x4
    // 0x1168498: LeaveFrame
    //     0x1168498: mov             SP, fp
    //     0x116849c: ldp             fp, lr, [SP], #0x10
    // 0x11684a0: ret
    //     0x11684a0: ret             
    // 0x11684a4: r5 = inline_Allocate_Double()
    //     0x11684a4: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x11684a8: add             x5, x5, #0x10
    //     0x11684ac: cmp             x1, x5
    //     0x11684b0: b.ls            #0x1168548
    //     0x11684b4: str             x5, [THR, #0x60]  ; THR::top
    //     0x11684b8: sub             x5, x5, #0xf
    //     0x11684bc: mov             x1, #0xe19c
    //     0x11684c0: movk            x1, #3, lsl #16
    //     0x11684c4: stur            x1, [x5, #-1]
    // 0x11684c8: dmb             ishst
    // 0x11684cc: StoreField: r5->field_7 = d0
    //     0x11684cc: stur            d0, [x5, #7]
    // 0x11684d0: mov             x3, x5
    // 0x11684d4: stur            x5, [fp, #-8]
    // 0x11684d8: r1 = Null
    //     0x11684d8: mov             x1, NULL
    // 0x11684dc: r2 = Null
    //     0x11684dc: mov             x2, NULL
    // 0x11684e0: r0 = lerp()
    //     0x11684e0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11684e4: ldur            x0, [fp, #-0x10]
    // 0x11684e8: LoadField: r1 = r0->field_f
    //     0x11684e8: ldur            w1, [x0, #0xf]
    // 0x11684ec: DecompressPointer r1
    //     0x11684ec: add             x1, x1, HEAP, lsl #32
    // 0x11684f0: ldur            x0, [fp, #-0x18]
    // 0x11684f4: LoadField: r2 = r0->field_f
    //     0x11684f4: ldur            w2, [x0, #0xf]
    // 0x11684f8: DecompressPointer r2
    //     0x11684f8: add             x2, x2, HEAP, lsl #32
    // 0x11684fc: ldur            x3, [fp, #-8]
    // 0x1168500: r0 = lerpDouble()
    //     0x1168500: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1168504: ldur            d0, [fp, #-0x20]
    // 0x1168508: r1 = Null
    //     0x1168508: mov             x1, NULL
    // 0x116850c: r2 = Null
    //     0x116850c: mov             x2, NULL
    // 0x1168510: stur            x0, [fp, #-8]
    // 0x1168514: r0 = lerp()
    //     0x1168514: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x1168518: ldur            d0, [fp, #-0x20]
    // 0x116851c: r1 = Null
    //     0x116851c: mov             x1, NULL
    // 0x1168520: r2 = Null
    //     0x1168520: mov             x2, NULL
    // 0x1168524: r0 = lerp()
    //     0x1168524: bl              #0x868640  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::lerp
    // 0x1168528: r0 = CarouselViewThemeData()
    //     0x1168528: bl              #0x1168564  ; AllocateCarouselViewThemeDataStub -> CarouselViewThemeData (size=0x20)
    // 0x116852c: ldur            x1, [fp, #-8]
    // 0x1168530: StoreField: r0->field_f = r1
    //     0x1168530: stur            w1, [x0, #0xf]
    // 0x1168534: LeaveFrame
    //     0x1168534: mov             SP, fp
    //     0x1168538: ldp             fp, lr, [SP], #0x10
    // 0x116853c: ret
    //     0x116853c: ret             
    // 0x1168540: r0 = StackOverflowSharedWithFPURegs()
    //     0x1168540: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1168544: b               #0x116848c
    // 0x1168548: SaveReg d0
    //     0x1168548: str             q0, [SP, #-0x10]!
    // 0x116854c: stp             x0, x4, [SP, #-0x10]!
    // 0x1168550: r0 = AllocateDouble()
    //     0x1168550: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1168554: mov             x5, x0
    // 0x1168558: ldp             x0, x4, [SP], #0x10
    // 0x116855c: RestoreReg d0
    //     0x116855c: ldr             q0, [SP], #0x10
    // 0x1168560: b               #0x11684cc
  }
  _ ==(/* No info */) {
    // ** addr: 0x1265d94, size: 0x104
    // 0x1265d94: EnterFrame
    //     0x1265d94: stp             fp, lr, [SP, #-0x10]!
    //     0x1265d98: mov             fp, SP
    // 0x1265d9c: AllocStack(0x10)
    //     0x1265d9c: sub             SP, SP, #0x10
    // 0x1265da0: CheckStackOverflow
    //     0x1265da0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1265da4: cmp             SP, x16
    //     0x1265da8: b.ls            #0x1265e90
    // 0x1265dac: ldr             x0, [fp, #0x10]
    // 0x1265db0: cmp             w0, NULL
    // 0x1265db4: b.ne            #0x1265dc8
    // 0x1265db8: r0 = false
    //     0x1265db8: add             x0, NULL, #0x30  ; false
    // 0x1265dbc: LeaveFrame
    //     0x1265dbc: mov             SP, fp
    //     0x1265dc0: ldp             fp, lr, [SP], #0x10
    // 0x1265dc4: ret
    //     0x1265dc4: ret             
    // 0x1265dc8: ldr             x1, [fp, #0x18]
    // 0x1265dcc: cmp             w1, w0
    // 0x1265dd0: b.ne            #0x1265de4
    // 0x1265dd4: r0 = true
    //     0x1265dd4: add             x0, NULL, #0x20  ; true
    // 0x1265dd8: LeaveFrame
    //     0x1265dd8: mov             SP, fp
    //     0x1265ddc: ldp             fp, lr, [SP], #0x10
    // 0x1265de0: ret
    //     0x1265de0: ret             
    // 0x1265de4: str             x0, [SP]
    // 0x1265de8: r0 = runtimeType()
    //     0x1265de8: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1265dec: r1 = LoadClassIdInstr(r0)
    //     0x1265dec: ldur            x1, [x0, #-1]
    //     0x1265df0: ubfx            x1, x1, #0xc, #0x14
    // 0x1265df4: r16 = CarouselViewThemeData
    //     0x1265df4: add             x16, PP, #0x26, lsl #12  ; [pp+0x26508] Type: CarouselViewThemeData
    //     0x1265df8: ldr             x16, [x16, #0x508]
    // 0x1265dfc: stp             x16, x0, [SP]
    // 0x1265e00: mov             x0, x1
    // 0x1265e04: mov             lr, x0
    // 0x1265e08: ldr             lr, [x21, lr, lsl #3]
    // 0x1265e0c: blr             lr
    // 0x1265e10: tbz             w0, #4, #0x1265e24
    // 0x1265e14: r0 = false
    //     0x1265e14: add             x0, NULL, #0x30  ; false
    // 0x1265e18: LeaveFrame
    //     0x1265e18: mov             SP, fp
    //     0x1265e1c: ldp             fp, lr, [SP], #0x10
    // 0x1265e20: ret
    //     0x1265e20: ret             
    // 0x1265e24: ldr             x0, [fp, #0x10]
    // 0x1265e28: r1 = 60
    //     0x1265e28: mov             x1, #0x3c
    // 0x1265e2c: branchIfSmi(r0, 0x1265e38)
    //     0x1265e2c: tbz             w0, #0, #0x1265e38
    // 0x1265e30: r1 = LoadClassIdInstr(r0)
    //     0x1265e30: ldur            x1, [x0, #-1]
    //     0x1265e34: ubfx            x1, x1, #0xc, #0x14
    // 0x1265e38: r17 = 5176
    //     0x1265e38: mov             x17, #0x1438
    // 0x1265e3c: cmp             x1, x17
    // 0x1265e40: b.ne            #0x1265e80
    // 0x1265e44: ldr             x1, [fp, #0x18]
    // 0x1265e48: LoadField: r2 = r0->field_f
    //     0x1265e48: ldur            w2, [x0, #0xf]
    // 0x1265e4c: DecompressPointer r2
    //     0x1265e4c: add             x2, x2, HEAP, lsl #32
    // 0x1265e50: LoadField: r0 = r1->field_f
    //     0x1265e50: ldur            w0, [x1, #0xf]
    // 0x1265e54: DecompressPointer r0
    //     0x1265e54: add             x0, x0, HEAP, lsl #32
    // 0x1265e58: r1 = LoadClassIdInstr(r2)
    //     0x1265e58: ldur            x1, [x2, #-1]
    //     0x1265e5c: ubfx            x1, x1, #0xc, #0x14
    // 0x1265e60: stp             x0, x2, [SP]
    // 0x1265e64: mov             x0, x1
    // 0x1265e68: mov             lr, x0
    // 0x1265e6c: ldr             lr, [x21, lr, lsl #3]
    // 0x1265e70: blr             lr
    // 0x1265e74: tbnz            w0, #4, #0x1265e80
    // 0x1265e78: r0 = true
    //     0x1265e78: add             x0, NULL, #0x20  ; true
    // 0x1265e7c: b               #0x1265e84
    // 0x1265e80: r0 = false
    //     0x1265e80: add             x0, NULL, #0x30  ; false
    // 0x1265e84: LeaveFrame
    //     0x1265e84: mov             SP, fp
    //     0x1265e88: ldp             fp, lr, [SP], #0x10
    // 0x1265e8c: ret
    //     0x1265e8c: ret             
    // 0x1265e90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1265e90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1265e94: b               #0x1265dac
  }
}
