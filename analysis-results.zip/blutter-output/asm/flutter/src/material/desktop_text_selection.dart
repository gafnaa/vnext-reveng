// lib: , url: package:flutter/src/material/desktop_text_selection.dart

// class id: 1048877, size: 0x8
class :: {

  static late final TextSelectionControls desktopTextSelectionHandleControls; // offset: 0x668

  static TextSelectionControls desktopTextSelectionHandleControls() {
    // ** addr: 0xd4a6f8, size: 0x18
    // 0xd4a6f8: EnterFrame
    //     0xd4a6f8: stp             fp, lr, [SP, #-0x10]!
    //     0xd4a6fc: mov             fp, SP
    // 0xd4a700: r0 = _DesktopTextSelectionHandleControls()
    //     0xd4a700: bl              #0xd4a710  ; Allocate_DesktopTextSelectionHandleControlsStub -> _DesktopTextSelectionHandleControls (size=0x8)
    // 0xd4a704: LeaveFrame
    //     0xd4a704: mov             SP, fp
    //     0xd4a708: ldp             fp, lr, [SP], #0x10
    // 0xd4a70c: ret
    //     0xd4a70c: ret             
  }
}

// class id: 3288, size: 0x8, field offset: 0x8
abstract class DesktopTextSelectionControls extends TextSelectionControls {
}

// class id: 3290, size: 0x8, field offset: 0x8
class _DesktopTextSelectionHandleControls extends _MixinApplication33&DesktopTextSelectionControls&TextSelectionHandleControls {
}
