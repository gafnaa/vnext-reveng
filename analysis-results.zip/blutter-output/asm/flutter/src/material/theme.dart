// lib: , url: package:flutter/src/material/theme.dart

// class id: 1048968, size: 0x8
class :: {
}

// class id: 3308, size: 0x14, field offset: 0x14
class ThemeDataTween extends Tween<dynamic> {

  _ lerp(/* No info */) {
    // ** addr: 0x115e000, size: 0x58
    // 0x115e000: EnterFrame
    //     0x115e000: stp             fp, lr, [SP, #-0x10]!
    //     0x115e004: mov             fp, SP
    // 0x115e008: CheckStackOverflow
    //     0x115e008: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115e00c: cmp             SP, x16
    //     0x115e010: b.ls            #0x115e048
    // 0x115e014: LoadField: r0 = r1->field_b
    //     0x115e014: ldur            w0, [x1, #0xb]
    // 0x115e018: DecompressPointer r0
    //     0x115e018: add             x0, x0, HEAP, lsl #32
    // 0x115e01c: cmp             w0, NULL
    // 0x115e020: b.eq            #0x115e050
    // 0x115e024: LoadField: r2 = r1->field_f
    //     0x115e024: ldur            w2, [x1, #0xf]
    // 0x115e028: DecompressPointer r2
    //     0x115e028: add             x2, x2, HEAP, lsl #32
    // 0x115e02c: cmp             w2, NULL
    // 0x115e030: b.eq            #0x115e054
    // 0x115e034: mov             x1, x0
    // 0x115e038: r0 = lerp()
    //     0x115e038: bl              #0x115e058  ; [package:flutter/src/material/theme_data.dart] ThemeData::lerp
    // 0x115e03c: LeaveFrame
    //     0x115e03c: mov             SP, fp
    //     0x115e040: ldp             fp, lr, [SP], #0x10
    // 0x115e044: ret
    //     0x115e044: ret             
    // 0x115e048: r0 = StackOverflowSharedWithFPURegs()
    //     0x115e048: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x115e04c: b               #0x115e014
    // 0x115e050: r0 = NullCastErrorSharedWithFPURegs()
    //     0x115e050: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x115e054: r0 = NullCastErrorSharedWithFPURegs()
    //     0x115e054: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
}

// class id: 5743, size: 0x28, field offset: 0x24
class _AnimatedThemeState extends AnimatedWidgetBaseState<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xd2efa0, size: 0xbc
    // 0xd2efa0: EnterFrame
    //     0xd2efa0: stp             fp, lr, [SP, #-0x10]!
    //     0xd2efa4: mov             fp, SP
    // 0xd2efa8: AllocStack(0x18)
    //     0xd2efa8: sub             SP, SP, #0x18
    // 0xd2efac: SetupParameters(_AnimatedThemeState this /* r1 => r0, fp-0x10 */)
    //     0xd2efac: mov             x0, x1
    //     0xd2efb0: stur            x1, [fp, #-0x10]
    // 0xd2efb4: CheckStackOverflow
    //     0xd2efb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd2efb8: cmp             SP, x16
    //     0xd2efbc: b.ls            #0xd2f04c
    // 0xd2efc0: LoadField: r2 = r0->field_23
    //     0xd2efc0: ldur            w2, [x0, #0x23]
    // 0xd2efc4: DecompressPointer r2
    //     0xd2efc4: add             x2, x2, HEAP, lsl #32
    // 0xd2efc8: stur            x2, [fp, #-8]
    // 0xd2efcc: cmp             w2, NULL
    // 0xd2efd0: b.eq            #0xd2f054
    // 0xd2efd4: mov             x1, x0
    // 0xd2efd8: LoadField: r0 = r1->field_1f
    //     0xd2efd8: ldur            w0, [x1, #0x1f]
    // 0xd2efdc: DecompressPointer r0
    //     0xd2efdc: add             x0, x0, HEAP, lsl #32
    // 0xd2efe0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd2efe4: cmp             w0, w16
    // 0xd2efe8: b.ne            #0xd2eff8
    // 0xd2efec: r2 = _animation
    //     0xd2efec: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fc38] Field <ImplicitlyAnimatedWidgetState._animation@99443363>: late (offset: 0x20)
    //     0xd2eff0: ldr             x2, [x2, #0xc38]
    // 0xd2eff4: r0 = InitLateInstanceField()
    //     0xd2eff4: bl              #0x13dd948  ; InitLateInstanceFieldStub
    // 0xd2eff8: ldur            x1, [fp, #-8]
    // 0xd2effc: mov             x2, x0
    // 0xd2f000: r0 = evaluate()
    //     0xd2f000: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xd2f004: mov             x1, x0
    // 0xd2f008: ldur            x0, [fp, #-0x10]
    // 0xd2f00c: stur            x1, [fp, #-0x18]
    // 0xd2f010: LoadField: r2 = r0->field_b
    //     0xd2f010: ldur            w2, [x0, #0xb]
    // 0xd2f014: DecompressPointer r2
    //     0xd2f014: add             x2, x2, HEAP, lsl #32
    // 0xd2f018: cmp             w2, NULL
    // 0xd2f01c: b.eq            #0xd2f058
    // 0xd2f020: LoadField: r0 = r2->field_1b
    //     0xd2f020: ldur            w0, [x2, #0x1b]
    // 0xd2f024: DecompressPointer r0
    //     0xd2f024: add             x0, x0, HEAP, lsl #32
    // 0xd2f028: stur            x0, [fp, #-8]
    // 0xd2f02c: r0 = Theme()
    //     0xd2f02c: bl              #0xd2f05c  ; AllocateThemeStub -> Theme (size=0x14)
    // 0xd2f030: ldur            x1, [fp, #-0x18]
    // 0xd2f034: StoreField: r0->field_b = r1
    //     0xd2f034: stur            w1, [x0, #0xb]
    // 0xd2f038: ldur            x1, [fp, #-8]
    // 0xd2f03c: StoreField: r0->field_f = r1
    //     0xd2f03c: stur            w1, [x0, #0xf]
    // 0xd2f040: LeaveFrame
    //     0xd2f040: mov             SP, fp
    //     0xd2f044: ldp             fp, lr, [SP], #0x10
    // 0xd2f048: ret
    //     0xd2f048: ret             
    // 0xd2f04c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd2f04c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd2f050: b               #0xd2efc0
    // 0xd2f054: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2f054: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2f058: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2f058: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ forEachTween(/* No info */) {
    // ** addr: 0x1193c10, size: 0xcc
    // 0x1193c10: EnterFrame
    //     0x1193c10: stp             fp, lr, [SP, #-0x10]!
    //     0x1193c14: mov             fp, SP
    // 0x1193c18: AllocStack(0x40)
    //     0x1193c18: sub             SP, SP, #0x40
    // 0x1193c1c: SetupParameters(_AnimatedThemeState this /* r1 => r3, fp-0x18 */, dynamic _ /* r2 => r0, fp-0x20 */)
    //     0x1193c1c: mov             x3, x1
    //     0x1193c20: mov             x0, x2
    //     0x1193c24: stur            x1, [fp, #-0x18]
    //     0x1193c28: stur            x2, [fp, #-0x20]
    // 0x1193c2c: CheckStackOverflow
    //     0x1193c2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1193c30: cmp             SP, x16
    //     0x1193c34: b.ls            #0x1193ccc
    // 0x1193c38: LoadField: r4 = r3->field_23
    //     0x1193c38: ldur            w4, [x3, #0x23]
    // 0x1193c3c: DecompressPointer r4
    //     0x1193c3c: add             x4, x4, HEAP, lsl #32
    // 0x1193c40: stur            x4, [fp, #-0x10]
    // 0x1193c44: LoadField: r1 = r3->field_b
    //     0x1193c44: ldur            w1, [x3, #0xb]
    // 0x1193c48: DecompressPointer r1
    //     0x1193c48: add             x1, x1, HEAP, lsl #32
    // 0x1193c4c: cmp             w1, NULL
    // 0x1193c50: b.eq            #0x1193cd4
    // 0x1193c54: ArrayLoad: r5 = r1[0]  ; List_4
    //     0x1193c54: ldur            w5, [x1, #0x17]
    // 0x1193c58: DecompressPointer r5
    //     0x1193c58: add             x5, x5, HEAP, lsl #32
    // 0x1193c5c: stur            x5, [fp, #-8]
    // 0x1193c60: r1 = Function '<anonymous closure>':.
    //     0x1193c60: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa38e0] AnonymousClosure: (0x1193cdc), in [package:flutter/src/material/theme.dart] _AnimatedThemeState::forEachTween (0x1193c10)
    //     0x1193c64: ldr             x1, [x1, #0x8e0]
    // 0x1193c68: r2 = Null
    //     0x1193c68: mov             x2, NULL
    // 0x1193c6c: r0 = AllocateClosure()
    //     0x1193c6c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1193c70: ldur            x16, [fp, #-0x20]
    // 0x1193c74: ldur            lr, [fp, #-0x10]
    // 0x1193c78: stp             lr, x16, [SP, #0x10]
    // 0x1193c7c: ldur            x16, [fp, #-8]
    // 0x1193c80: stp             x0, x16, [SP]
    // 0x1193c84: ldur            x0, [fp, #-0x20]
    // 0x1193c88: ClosureCall
    //     0x1193c88: ldr             x4, [PP, #0x9d0]  ; [pp+0x9d0] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0x1193c8c: ldur            x2, [x0, #0x1f]
    //     0x1193c90: blr             x2
    // 0x1193c94: cmp             w0, NULL
    // 0x1193c98: b.eq            #0x1193cd8
    // 0x1193c9c: ldur            x1, [fp, #-0x18]
    // 0x1193ca0: StoreField: r1->field_23 = r0
    //     0x1193ca0: stur            w0, [x1, #0x23]
    //     0x1193ca4: ldurb           w16, [x1, #-1]
    //     0x1193ca8: ldurb           w17, [x0, #-1]
    //     0x1193cac: and             x16, x17, x16, lsr #2
    //     0x1193cb0: tst             x16, HEAP, lsr #32
    //     0x1193cb4: b.eq            #0x1193cbc
    //     0x1193cb8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1193cbc: r0 = Null
    //     0x1193cbc: mov             x0, NULL
    // 0x1193cc0: LeaveFrame
    //     0x1193cc0: mov             SP, fp
    //     0x1193cc4: ldp             fp, lr, [SP], #0x10
    // 0x1193cc8: ret
    //     0x1193cc8: ret             
    // 0x1193ccc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1193ccc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1193cd0: b               #0x1193c38
    // 0x1193cd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1193cd4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1193cd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1193cd8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] ThemeDataTween <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x1193cdc, size: 0x64
    // 0x1193cdc: EnterFrame
    //     0x1193cdc: stp             fp, lr, [SP, #-0x10]!
    //     0x1193ce0: mov             fp, SP
    // 0x1193ce4: ldr             x0, [fp, #0x10]
    // 0x1193ce8: r2 = Null
    //     0x1193ce8: mov             x2, NULL
    // 0x1193cec: r1 = Null
    //     0x1193cec: mov             x1, NULL
    // 0x1193cf0: r4 = 60
    //     0x1193cf0: mov             x4, #0x3c
    // 0x1193cf4: branchIfSmi(r0, 0x1193d00)
    //     0x1193cf4: tbz             w0, #0, #0x1193d00
    // 0x1193cf8: r4 = LoadClassIdInstr(r0)
    //     0x1193cf8: ldur            x4, [x0, #-1]
    //     0x1193cfc: ubfx            x4, x4, #0xc, #0x14
    // 0x1193d00: r17 = 5054
    //     0x1193d00: mov             x17, #0x13be
    // 0x1193d04: cmp             x4, x17
    // 0x1193d08: b.eq            #0x1193d20
    // 0x1193d0c: r8 = ThemeData
    //     0x1193d0c: add             x8, PP, #0x26, lsl #12  ; [pp+0x26b18] Type: ThemeData
    //     0x1193d10: ldr             x8, [x8, #0xb18]
    // 0x1193d14: r3 = Null
    //     0x1193d14: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa38e8] Null
    //     0x1193d18: ldr             x3, [x3, #0x8e8]
    // 0x1193d1c: r0 = ThemeData()
    //     0x1193d1c: bl              #0x8a76b0  ; IsType_ThemeData_Stub
    // 0x1193d20: r1 = <ThemeData>
    //     0x1193d20: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa38f8] TypeArguments: <ThemeData>
    //     0x1193d24: ldr             x1, [x1, #0x8f8]
    // 0x1193d28: r0 = ThemeDataTween()
    //     0x1193d28: bl              #0x1193d40  ; AllocateThemeDataTweenStub -> ThemeDataTween (size=0x14)
    // 0x1193d2c: ldr             x1, [fp, #0x10]
    // 0x1193d30: StoreField: r0->field_b = r1
    //     0x1193d30: stur            w1, [x0, #0xb]
    // 0x1193d34: LeaveFrame
    //     0x1193d34: mov             SP, fp
    //     0x1193d38: ldp             fp, lr, [SP], #0x10
    // 0x1193d3c: ret
    //     0x1193d3c: ret             
  }
}

// class id: 6135, size: 0x14, field offset: 0xc
//   const constructor, 
class Theme extends StatelessWidget {

  static late final ThemeData _kFallbackTheme; // offset: 0x6fc

  static _ of(/* No info */) {
    // ** addr: 0x8a76d4, size: 0x1cc
    // 0x8a76d4: EnterFrame
    //     0x8a76d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8a76d8: mov             fp, SP
    // 0x8a76dc: AllocStack(0x30)
    //     0x8a76dc: sub             SP, SP, #0x30
    // 0x8a76e0: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0x8a76e0: stur            x1, [fp, #-8]
    // 0x8a76e4: CheckStackOverflow
    //     0x8a76e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a76e8: cmp             SP, x16
    //     0x8a76ec: b.ls            #0x8a7898
    // 0x8a76f0: r16 = <_InheritedTheme>
    //     0x8a76f0: add             x16, PP, #0x12, lsl #12  ; [pp+0x128a8] TypeArguments: <_InheritedTheme>
    //     0x8a76f4: ldr             x16, [x16, #0x8a8]
    // 0x8a76f8: stp             x1, x16, [SP]
    // 0x8a76fc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8a76fc: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8a7700: r0 = dependOnInheritedWidgetOfExactType()
    //     0x8a7700: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0x8a7704: stur            x0, [fp, #-0x10]
    // 0x8a7708: r16 = <MaterialLocalizations>
    //     0x8a7708: add             x16, PP, #0x12, lsl #12  ; [pp+0x128b0] TypeArguments: <MaterialLocalizations>
    //     0x8a770c: ldr             x16, [x16, #0x8b0]
    // 0x8a7710: ldur            lr, [fp, #-8]
    // 0x8a7714: stp             lr, x16, [SP, #8]
    // 0x8a7718: r16 = MaterialLocalizations
    //     0x8a7718: add             x16, PP, #0x12, lsl #12  ; [pp+0x128b8] Type: MaterialLocalizations
    //     0x8a771c: ldr             x16, [x16, #0x8b8]
    // 0x8a7720: str             x16, [SP]
    // 0x8a7724: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8a7724: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8a7728: r0 = of()
    //     0x8a7728: bl              #0x8bde0c  ; [package:flutter/src/widgets/localizations.dart] Localizations::of
    // 0x8a772c: cmp             w0, NULL
    // 0x8a7730: b.ne            #0x8a773c
    // 0x8a7734: r0 = Null
    //     0x8a7734: mov             x0, NULL
    // 0x8a7738: b               #0x8a7764
    // 0x8a773c: r1 = LoadClassIdInstr(r0)
    //     0x8a773c: ldur            x1, [x0, #-1]
    //     0x8a7740: ubfx            x1, x1, #0xc, #0x14
    // 0x8a7744: mov             x16, x0
    // 0x8a7748: mov             x0, x1
    // 0x8a774c: mov             x1, x16
    // 0x8a7750: r0 = GDT[cid_x0 + 0x16ca6]()
    //     0x8a7750: mov             x17, #0x6ca6
    //     0x8a7754: movk            x17, #1, lsl #16
    //     0x8a7758: add             lr, x0, x17
    //     0x8a775c: ldr             lr, [x21, lr, lsl #3]
    //     0x8a7760: blr             lr
    // 0x8a7764: cmp             w0, NULL
    // 0x8a7768: b.ne            #0x8a7778
    // 0x8a776c: r1 = Instance_ScriptCategory
    //     0x8a776c: add             x1, PP, #0x12, lsl #12  ; [pp+0x128c0] Obj!ScriptCategory@12c4b21
    //     0x8a7770: ldr             x1, [x1, #0x8c0]
    // 0x8a7774: b               #0x8a777c
    // 0x8a7778: mov             x1, x0
    // 0x8a777c: ldur            x0, [fp, #-0x10]
    // 0x8a7780: stur            x1, [fp, #-0x18]
    // 0x8a7784: r16 = <InheritedCupertinoTheme>
    //     0x8a7784: add             x16, PP, #0x12, lsl #12  ; [pp+0x128c8] TypeArguments: <InheritedCupertinoTheme>
    //     0x8a7788: ldr             x16, [x16, #0x8c8]
    // 0x8a778c: ldur            lr, [fp, #-8]
    // 0x8a7790: stp             lr, x16, [SP]
    // 0x8a7794: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8a7794: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8a7798: r0 = dependOnInheritedWidgetOfExactType()
    //     0x8a7798: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0x8a779c: mov             x1, x0
    // 0x8a77a0: ldur            x0, [fp, #-0x10]
    // 0x8a77a4: cmp             w0, NULL
    // 0x8a77a8: b.ne            #0x8a77b4
    // 0x8a77ac: r0 = Null
    //     0x8a77ac: mov             x0, NULL
    // 0x8a77b0: b               #0x8a77c4
    // 0x8a77b4: LoadField: r2 = r0->field_f
    //     0x8a77b4: ldur            w2, [x0, #0xf]
    // 0x8a77b8: DecompressPointer r2
    //     0x8a77b8: add             x2, x2, HEAP, lsl #32
    // 0x8a77bc: LoadField: r0 = r2->field_b
    //     0x8a77bc: ldur            w0, [x2, #0xb]
    // 0x8a77c0: DecompressPointer r0
    //     0x8a77c0: add             x0, x0, HEAP, lsl #32
    // 0x8a77c4: cmp             w0, NULL
    // 0x8a77c8: b.ne            #0x8a7838
    // 0x8a77cc: cmp             w1, NULL
    // 0x8a77d0: b.eq            #0x8a7810
    // 0x8a77d4: LoadField: r0 = r1->field_f
    //     0x8a77d4: ldur            w0, [x1, #0xf]
    // 0x8a77d8: DecompressPointer r0
    //     0x8a77d8: add             x0, x0, HEAP, lsl #32
    // 0x8a77dc: LoadField: r2 = r0->field_b
    //     0x8a77dc: ldur            w2, [x0, #0xb]
    // 0x8a77e0: DecompressPointer r2
    //     0x8a77e0: add             x2, x2, HEAP, lsl #32
    // 0x8a77e4: stur            x2, [fp, #-8]
    // 0x8a77e8: r0 = CupertinoBasedMaterialThemeData()
    //     0x8a77e8: bl              #0x8bde00  ; AllocateCupertinoBasedMaterialThemeDataStub -> CupertinoBasedMaterialThemeData (size=0xc)
    // 0x8a77ec: mov             x1, x0
    // 0x8a77f0: ldur            x2, [fp, #-8]
    // 0x8a77f4: stur            x0, [fp, #-8]
    // 0x8a77f8: r0 = CupertinoBasedMaterialThemeData()
    //     0x8a77f8: bl              #0x8a9b68  ; [package:flutter/src/material/theme_data.dart] CupertinoBasedMaterialThemeData::CupertinoBasedMaterialThemeData
    // 0x8a77fc: ldur            x0, [fp, #-8]
    // 0x8a7800: LoadField: r1 = r0->field_7
    //     0x8a7800: ldur            w1, [x0, #7]
    // 0x8a7804: DecompressPointer r1
    //     0x8a7804: add             x1, x1, HEAP, lsl #32
    // 0x8a7808: mov             x0, x1
    // 0x8a780c: b               #0x8a7830
    // 0x8a7810: r0 = LoadStaticField(0x6fc)
    //     0x8a7810: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8a7814: ldr             x0, [x0, #0xdf8]
    // 0x8a7818: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8a781c: cmp             w0, w16
    // 0x8a7820: b.ne            #0x8a7830
    // 0x8a7824: r2 = _kFallbackTheme
    //     0x8a7824: add             x2, PP, #0x12, lsl #12  ; [pp+0x128d0] Field <Theme._kFallbackTheme@108067045>: static late final (offset: 0x6fc)
    //     0x8a7828: ldr             x2, [x2, #0x8d0]
    // 0x8a782c: r0 = InitLateFinalStaticField()
    //     0x8a782c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8a7830: mov             x1, x0
    // 0x8a7834: b               #0x8a783c
    // 0x8a7838: mov             x1, x0
    // 0x8a783c: ldur            x0, [fp, #-0x18]
    // 0x8a7840: LoadField: r2 = r1->field_8b
    //     0x8a7840: ldur            w2, [x1, #0x8b]
    // 0x8a7844: DecompressPointer r2
    //     0x8a7844: add             x2, x2, HEAP, lsl #32
    // 0x8a7848: LoadField: r3 = r0->field_7
    //     0x8a7848: ldur            x3, [x0, #7]
    // 0x8a784c: cmp             x3, #1
    // 0x8a7850: b.gt            #0x8a787c
    // 0x8a7854: cmp             x3, #0
    // 0x8a7858: b.gt            #0x8a786c
    // 0x8a785c: LoadField: r0 = r2->field_f
    //     0x8a785c: ldur            w0, [x2, #0xf]
    // 0x8a7860: DecompressPointer r0
    //     0x8a7860: add             x0, x0, HEAP, lsl #32
    // 0x8a7864: mov             x2, x0
    // 0x8a7868: b               #0x8a7888
    // 0x8a786c: LoadField: r0 = r2->field_13
    //     0x8a786c: ldur            w0, [x2, #0x13]
    // 0x8a7870: DecompressPointer r0
    //     0x8a7870: add             x0, x0, HEAP, lsl #32
    // 0x8a7874: mov             x2, x0
    // 0x8a7878: b               #0x8a7888
    // 0x8a787c: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x8a787c: ldur            w0, [x2, #0x17]
    // 0x8a7880: DecompressPointer r0
    //     0x8a7880: add             x0, x0, HEAP, lsl #32
    // 0x8a7884: mov             x2, x0
    // 0x8a7888: r0 = localize()
    //     0x8a7888: bl              #0x8a78a0  ; [package:flutter/src/material/theme_data.dart] ThemeData::localize
    // 0x8a788c: LeaveFrame
    //     0x8a788c: mov             SP, fp
    //     0x8a7890: ldp             fp, lr, [SP], #0x10
    // 0x8a7894: ret
    //     0x8a7894: ret             
    // 0x8a7898: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a7898: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a789c: b               #0x8a76f0
  }
  static ThemeData _kFallbackTheme() {
    // ** addr: 0x8bdfac, size: 0x30
    // 0x8bdfac: EnterFrame
    //     0x8bdfac: stp             fp, lr, [SP, #-0x10]!
    //     0x8bdfb0: mov             fp, SP
    // 0x8bdfb4: CheckStackOverflow
    //     0x8bdfb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bdfb8: cmp             SP, x16
    //     0x8bdfbc: b.ls            #0x8bdfd4
    // 0x8bdfc0: r1 = Null
    //     0x8bdfc0: mov             x1, NULL
    // 0x8bdfc4: r0 = ThemeData.light()
    //     0x8bdfc4: bl              #0x8bdfdc  ; [package:flutter/src/material/theme_data.dart] ThemeData::ThemeData.light
    // 0x8bdfc8: LeaveFrame
    //     0x8bdfc8: mov             SP, fp
    //     0x8bdfcc: ldp             fp, lr, [SP], #0x10
    // 0x8bdfd0: ret
    //     0x8bdfd0: ret             
    // 0x8bdfd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bdfd4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bdfd8: b               #0x8bdfc0
  }
  static _ brightnessOf(/* No info */) {
    // ** addr: 0xd1e4dc, size: 0x84
    // 0xd1e4dc: EnterFrame
    //     0xd1e4dc: stp             fp, lr, [SP, #-0x10]!
    //     0xd1e4e0: mov             fp, SP
    // 0xd1e4e4: AllocStack(0x18)
    //     0xd1e4e4: sub             SP, SP, #0x18
    // 0xd1e4e8: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xd1e4e8: stur            x1, [fp, #-8]
    // 0xd1e4ec: CheckStackOverflow
    //     0xd1e4ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1e4f0: cmp             SP, x16
    //     0xd1e4f4: b.ls            #0xd1e558
    // 0xd1e4f8: r16 = <_InheritedTheme>
    //     0xd1e4f8: add             x16, PP, #0x12, lsl #12  ; [pp+0x128a8] TypeArguments: <_InheritedTheme>
    //     0xd1e4fc: ldr             x16, [x16, #0x8a8]
    // 0xd1e500: stp             x1, x16, [SP]
    // 0xd1e504: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd1e504: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd1e508: r0 = dependOnInheritedWidgetOfExactType()
    //     0xd1e508: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xd1e50c: cmp             w0, NULL
    // 0xd1e510: b.ne            #0xd1e51c
    // 0xd1e514: r0 = Null
    //     0xd1e514: mov             x0, NULL
    // 0xd1e518: b               #0xd1e53c
    // 0xd1e51c: LoadField: r1 = r0->field_f
    //     0xd1e51c: ldur            w1, [x0, #0xf]
    // 0xd1e520: DecompressPointer r1
    //     0xd1e520: add             x1, x1, HEAP, lsl #32
    // 0xd1e524: LoadField: r0 = r1->field_b
    //     0xd1e524: ldur            w0, [x1, #0xb]
    // 0xd1e528: DecompressPointer r0
    //     0xd1e528: add             x0, x0, HEAP, lsl #32
    // 0xd1e52c: LoadField: r1 = r0->field_3f
    //     0xd1e52c: ldur            w1, [x0, #0x3f]
    // 0xd1e530: DecompressPointer r1
    //     0xd1e530: add             x1, x1, HEAP, lsl #32
    // 0xd1e534: LoadField: r0 = r1->field_7
    //     0xd1e534: ldur            w0, [x1, #7]
    // 0xd1e538: DecompressPointer r0
    //     0xd1e538: add             x0, x0, HEAP, lsl #32
    // 0xd1e53c: cmp             w0, NULL
    // 0xd1e540: b.ne            #0xd1e54c
    // 0xd1e544: ldur            x1, [fp, #-8]
    // 0xd1e548: r0 = platformBrightnessOf()
    //     0xd1e548: bl              #0xd1e560  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::platformBrightnessOf
    // 0xd1e54c: LeaveFrame
    //     0xd1e54c: mov             SP, fp
    //     0xd1e550: ldp             fp, lr, [SP], #0x10
    // 0xd1e554: ret
    //     0xd1e554: ret             
    // 0xd1e558: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1e558: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1e55c: b               #0xd1e4f8
  }
  _ build(/* No info */) {
    // ** addr: 0xfbeefc, size: 0x9c
    // 0xfbeefc: EnterFrame
    //     0xfbeefc: stp             fp, lr, [SP, #-0x10]!
    //     0xfbef00: mov             fp, SP
    // 0xfbef04: AllocStack(0x20)
    //     0xfbef04: sub             SP, SP, #0x20
    // 0xfbef08: SetupParameters(Theme this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfbef08: mov             x3, x1
    //     0xfbef0c: mov             x0, x2
    //     0xfbef10: stur            x1, [fp, #-8]
    //     0xfbef14: stur            x2, [fp, #-0x10]
    // 0xfbef18: CheckStackOverflow
    //     0xfbef18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbef1c: cmp             SP, x16
    //     0xfbef20: b.ls            #0xfbef90
    // 0xfbef24: mov             x1, x3
    // 0xfbef28: mov             x2, x0
    // 0xfbef2c: r0 = _inheritedCupertinoThemeData()
    //     0xfbef2c: bl              #0xfbf05c  ; [package:flutter/src/material/theme.dart] Theme::_inheritedCupertinoThemeData
    // 0xfbef30: mov             x4, x0
    // 0xfbef34: ldur            x0, [fp, #-8]
    // 0xfbef38: stur            x4, [fp, #-0x18]
    // 0xfbef3c: LoadField: r3 = r0->field_f
    //     0xfbef3c: ldur            w3, [x0, #0xf]
    // 0xfbef40: DecompressPointer r3
    //     0xfbef40: add             x3, x3, HEAP, lsl #32
    // 0xfbef44: mov             x1, x0
    // 0xfbef48: ldur            x2, [fp, #-0x10]
    // 0xfbef4c: r0 = _wrapsWidgetThemes()
    //     0xfbef4c: bl              #0xfbefb0  ; [package:flutter/src/material/theme.dart] Theme::_wrapsWidgetThemes
    // 0xfbef50: stur            x0, [fp, #-0x10]
    // 0xfbef54: r0 = CupertinoTheme()
    //     0xfbef54: bl              #0xfbefa4  ; AllocateCupertinoThemeStub -> CupertinoTheme (size=0x14)
    // 0xfbef58: mov             x1, x0
    // 0xfbef5c: ldur            x0, [fp, #-0x18]
    // 0xfbef60: stur            x1, [fp, #-0x20]
    // 0xfbef64: StoreField: r1->field_b = r0
    //     0xfbef64: stur            w0, [x1, #0xb]
    // 0xfbef68: ldur            x0, [fp, #-0x10]
    // 0xfbef6c: StoreField: r1->field_f = r0
    //     0xfbef6c: stur            w0, [x1, #0xf]
    // 0xfbef70: r0 = _InheritedTheme()
    //     0xfbef70: bl              #0xfbef98  ; Allocate_InheritedThemeStub -> _InheritedTheme (size=0x14)
    // 0xfbef74: ldur            x1, [fp, #-8]
    // 0xfbef78: StoreField: r0->field_f = r1
    //     0xfbef78: stur            w1, [x0, #0xf]
    // 0xfbef7c: ldur            x1, [fp, #-0x20]
    // 0xfbef80: StoreField: r0->field_b = r1
    //     0xfbef80: stur            w1, [x0, #0xb]
    // 0xfbef84: LeaveFrame
    //     0xfbef84: mov             SP, fp
    //     0xfbef88: ldp             fp, lr, [SP], #0x10
    // 0xfbef8c: ret
    //     0xfbef8c: ret             
    // 0xfbef90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbef90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbef94: b               #0xfbef24
  }
  _ _wrapsWidgetThemes(/* No info */) {
    // ** addr: 0xfbefb0, size: 0xac
    // 0xfbefb0: EnterFrame
    //     0xfbefb0: stp             fp, lr, [SP, #-0x10]!
    //     0xfbefb4: mov             fp, SP
    // 0xfbefb8: AllocStack(0x28)
    //     0xfbefb8: sub             SP, SP, #0x28
    // 0xfbefbc: SetupParameters(Theme this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xfbefbc: mov             x0, x1
    //     0xfbefc0: stur            x1, [fp, #-8]
    //     0xfbefc4: mov             x1, x2
    //     0xfbefc8: stur            x3, [fp, #-0x10]
    // 0xfbefcc: CheckStackOverflow
    //     0xfbefcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbefd0: cmp             SP, x16
    //     0xfbefd4: b.ls            #0xfbf054
    // 0xfbefd8: r0 = of()
    //     0xfbefd8: bl              #0xd2096c  ; [package:flutter/src/widgets/default_selection_style.dart] DefaultSelectionStyle::of
    // 0xfbefdc: mov             x1, x0
    // 0xfbefe0: ldur            x0, [fp, #-8]
    // 0xfbefe4: LoadField: r2 = r0->field_b
    //     0xfbefe4: ldur            w2, [x0, #0xb]
    // 0xfbefe8: DecompressPointer r2
    //     0xfbefe8: add             x2, x2, HEAP, lsl #32
    // 0xfbefec: LoadField: r0 = r2->field_7b
    //     0xfbefec: ldur            w0, [x2, #0x7b]
    // 0xfbeff0: DecompressPointer r0
    //     0xfbeff0: add             x0, x0, HEAP, lsl #32
    // 0xfbeff4: stur            x0, [fp, #-0x20]
    // 0xfbeff8: LoadField: r2 = r1->field_13
    //     0xfbeff8: ldur            w2, [x1, #0x13]
    // 0xfbeffc: DecompressPointer r2
    //     0xfbeffc: add             x2, x2, HEAP, lsl #32
    // 0xfbf000: stur            x2, [fp, #-0x18]
    // 0xfbf004: LoadField: r3 = r1->field_f
    //     0xfbf004: ldur            w3, [x1, #0xf]
    // 0xfbf008: DecompressPointer r3
    //     0xfbf008: add             x3, x3, HEAP, lsl #32
    // 0xfbf00c: stur            x3, [fp, #-8]
    // 0xfbf010: r0 = DefaultSelectionStyle()
    //     0xfbf010: bl              #0xd20960  ; AllocateDefaultSelectionStyleStub -> DefaultSelectionStyle (size=0x1c)
    // 0xfbf014: mov             x1, x0
    // 0xfbf018: ldur            x0, [fp, #-8]
    // 0xfbf01c: stur            x1, [fp, #-0x28]
    // 0xfbf020: StoreField: r1->field_f = r0
    //     0xfbf020: stur            w0, [x1, #0xf]
    // 0xfbf024: ldur            x0, [fp, #-0x18]
    // 0xfbf028: StoreField: r1->field_13 = r0
    //     0xfbf028: stur            w0, [x1, #0x13]
    // 0xfbf02c: ldur            x0, [fp, #-0x10]
    // 0xfbf030: StoreField: r1->field_b = r0
    //     0xfbf030: stur            w0, [x1, #0xb]
    // 0xfbf034: r0 = IconTheme()
    //     0xfbf034: bl              #0xd0c668  ; AllocateIconThemeStub -> IconTheme (size=0x14)
    // 0xfbf038: ldur            x1, [fp, #-0x20]
    // 0xfbf03c: StoreField: r0->field_f = r1
    //     0xfbf03c: stur            w1, [x0, #0xf]
    // 0xfbf040: ldur            x1, [fp, #-0x28]
    // 0xfbf044: StoreField: r0->field_b = r1
    //     0xfbf044: stur            w1, [x0, #0xb]
    // 0xfbf048: LeaveFrame
    //     0xfbf048: mov             SP, fp
    //     0xfbf04c: ldp             fp, lr, [SP], #0x10
    // 0xfbf050: ret
    //     0xfbf050: ret             
    // 0xfbf054: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbf054: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbf058: b               #0xfbefd8
  }
  _ _inheritedCupertinoThemeData(/* No info */) {
    // ** addr: 0xfbf05c, size: 0xdc
    // 0xfbf05c: EnterFrame
    //     0xfbf05c: stp             fp, lr, [SP, #-0x10]!
    //     0xfbf060: mov             fp, SP
    // 0xfbf064: AllocStack(0x28)
    //     0xfbf064: sub             SP, SP, #0x28
    // 0xfbf068: SetupParameters(Theme this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xfbf068: stur            x1, [fp, #-8]
    //     0xfbf06c: stur            x2, [fp, #-0x10]
    // 0xfbf070: CheckStackOverflow
    //     0xfbf070: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbf074: cmp             SP, x16
    //     0xfbf078: b.ls            #0xfbf130
    // 0xfbf07c: r16 = <InheritedCupertinoTheme>
    //     0xfbf07c: add             x16, PP, #0x12, lsl #12  ; [pp+0x128c8] TypeArguments: <InheritedCupertinoTheme>
    //     0xfbf080: ldr             x16, [x16, #0x8c8]
    // 0xfbf084: stp             x2, x16, [SP]
    // 0xfbf088: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xfbf088: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xfbf08c: r0 = dependOnInheritedWidgetOfExactType()
    //     0xfbf08c: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xfbf090: cmp             w0, NULL
    // 0xfbf094: b.ne            #0xfbf0a0
    // 0xfbf098: r0 = Null
    //     0xfbf098: mov             x0, NULL
    // 0xfbf09c: b               #0xfbf0b0
    // 0xfbf0a0: LoadField: r1 = r0->field_f
    //     0xfbf0a0: ldur            w1, [x0, #0xf]
    // 0xfbf0a4: DecompressPointer r1
    //     0xfbf0a4: add             x1, x1, HEAP, lsl #32
    // 0xfbf0a8: LoadField: r0 = r1->field_b
    //     0xfbf0a8: ldur            w0, [x1, #0xb]
    // 0xfbf0ac: DecompressPointer r0
    //     0xfbf0ac: add             x0, x0, HEAP, lsl #32
    // 0xfbf0b0: cmp             w0, NULL
    // 0xfbf0b4: b.ne            #0xfbf118
    // 0xfbf0b8: ldur            x0, [fp, #-8]
    // 0xfbf0bc: LoadField: r2 = r0->field_b
    //     0xfbf0bc: ldur            w2, [x0, #0xb]
    // 0xfbf0c0: DecompressPointer r2
    //     0xfbf0c0: add             x2, x2, HEAP, lsl #32
    // 0xfbf0c4: stur            x2, [fp, #-0x18]
    // 0xfbf0c8: r1 = Instance_CupertinoThemeData
    //     0xfbf0c8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26b40] Obj!CupertinoThemeData@12aa501
    //     0xfbf0cc: ldr             x1, [x1, #0xb40]
    // 0xfbf0d0: r0 = noDefault()
    //     0xfbf0d0: bl              #0xfbf144  ; [package:flutter/src/cupertino/theme.dart] CupertinoThemeData::noDefault
    // 0xfbf0d4: stur            x0, [fp, #-8]
    // 0xfbf0d8: r0 = MaterialBasedCupertinoThemeData()
    //     0xfbf0d8: bl              #0xfbf138  ; AllocateMaterialBasedCupertinoThemeDataStub -> MaterialBasedCupertinoThemeData (size=0x34)
    // 0xfbf0dc: mov             x1, x0
    // 0xfbf0e0: ldur            x0, [fp, #-0x18]
    // 0xfbf0e4: StoreField: r1->field_2b = r0
    //     0xfbf0e4: stur            w0, [x1, #0x2b]
    // 0xfbf0e8: ldur            x0, [fp, #-8]
    // 0xfbf0ec: StoreField: r1->field_2f = r0
    //     0xfbf0ec: stur            w0, [x1, #0x2f]
    // 0xfbf0f0: LoadField: r2 = r0->field_13
    //     0xfbf0f0: ldur            w2, [x0, #0x13]
    // 0xfbf0f4: DecompressPointer r2
    //     0xfbf0f4: add             x2, x2, HEAP, lsl #32
    // 0xfbf0f8: LoadField: r3 = r0->field_23
    //     0xfbf0f8: ldur            w3, [x0, #0x23]
    // 0xfbf0fc: DecompressPointer r3
    //     0xfbf0fc: add             x3, x3, HEAP, lsl #32
    // 0xfbf100: r0 = Instance__CupertinoThemeDefaults
    //     0xfbf100: add             x0, PP, #0x26, lsl #12  ; [pp+0x26b48] Obj!_CupertinoThemeDefaults@129f2b1
    //     0xfbf104: ldr             x0, [x0, #0xb48]
    // 0xfbf108: StoreField: r1->field_27 = r0
    //     0xfbf108: stur            w0, [x1, #0x27]
    // 0xfbf10c: StoreField: r1->field_13 = r2
    //     0xfbf10c: stur            w2, [x1, #0x13]
    // 0xfbf110: StoreField: r1->field_23 = r3
    //     0xfbf110: stur            w3, [x1, #0x23]
    // 0xfbf114: b               #0xfbf11c
    // 0xfbf118: mov             x1, x0
    // 0xfbf11c: ldur            x2, [fp, #-0x10]
    // 0xfbf120: r0 = resolveFrom()
    //     0xfbf120: bl              #0x121ed00  ; [package:flutter/src/material/theme_data.dart] MaterialBasedCupertinoThemeData::resolveFrom
    // 0xfbf124: LeaveFrame
    //     0xfbf124: mov             SP, fp
    //     0xfbf128: ldp             fp, lr, [SP], #0x10
    // 0xfbf12c: ret
    //     0xfbf12c: ret             
    // 0xfbf130: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbf130: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbf134: b               #0xfbf07c
  }
}

// class id: 6465, size: 0x20, field offset: 0x18
//   const constructor, 
class AnimatedTheme extends ImplicitlyAnimatedWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa1e8c, size: 0x30
    // 0xfa1e8c: EnterFrame
    //     0xfa1e8c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa1e90: mov             fp, SP
    // 0xfa1e94: mov             x0, x1
    // 0xfa1e98: r1 = <AnimatedTheme>
    //     0xfa1e98: add             x1, PP, #0x99, lsl #12  ; [pp+0x990d0] TypeArguments: <AnimatedTheme>
    //     0xfa1e9c: ldr             x1, [x1, #0xd0]
    // 0xfa1ea0: r0 = _AnimatedThemeState()
    //     0xfa1ea0: bl              #0xfa1ebc  ; Allocate_AnimatedThemeStateStub -> _AnimatedThemeState (size=0x28)
    // 0xfa1ea4: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa1ea8: StoreField: r0->field_1b = r1
    //     0xfa1ea8: stur            w1, [x0, #0x1b]
    // 0xfa1eac: StoreField: r0->field_1f = r1
    //     0xfa1eac: stur            w1, [x0, #0x1f]
    // 0xfa1eb0: LeaveFrame
    //     0xfa1eb0: mov             SP, fp
    //     0xfa1eb4: ldp             fp, lr, [SP], #0x10
    // 0xfa1eb8: ret
    //     0xfa1eb8: ret             
  }
}

// class id: 6834, size: 0x14, field offset: 0x10
//   const constructor, 
class _InheritedTheme extends InheritedTheme {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xc005dc, size: 0xb0
    // 0xc005dc: EnterFrame
    //     0xc005dc: stp             fp, lr, [SP, #-0x10]!
    //     0xc005e0: mov             fp, SP
    // 0xc005e4: AllocStack(0x20)
    //     0xc005e4: sub             SP, SP, #0x20
    // 0xc005e8: SetupParameters(_InheritedTheme this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xc005e8: mov             x4, x1
    //     0xc005ec: mov             x3, x2
    //     0xc005f0: stur            x1, [fp, #-8]
    //     0xc005f4: stur            x2, [fp, #-0x10]
    // 0xc005f8: CheckStackOverflow
    //     0xc005f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc005fc: cmp             SP, x16
    //     0xc00600: b.ls            #0xc00684
    // 0xc00604: mov             x0, x3
    // 0xc00608: r2 = Null
    //     0xc00608: mov             x2, NULL
    // 0xc0060c: r1 = Null
    //     0xc0060c: mov             x1, NULL
    // 0xc00610: r4 = 60
    //     0xc00610: mov             x4, #0x3c
    // 0xc00614: branchIfSmi(r0, 0xc00620)
    //     0xc00614: tbz             w0, #0, #0xc00620
    // 0xc00618: r4 = LoadClassIdInstr(r0)
    //     0xc00618: ldur            x4, [x0, #-1]
    //     0xc0061c: ubfx            x4, x4, #0xc, #0x14
    // 0xc00620: r17 = 6834
    //     0xc00620: mov             x17, #0x1ab2
    // 0xc00624: cmp             x4, x17
    // 0xc00628: b.eq            #0xc00640
    // 0xc0062c: r8 = _InheritedTheme
    //     0xc0062c: add             x8, PP, #0x99, lsl #12  ; [pp+0x990d8] Type: _InheritedTheme
    //     0xc00630: ldr             x8, [x8, #0xd8]
    // 0xc00634: r3 = Null
    //     0xc00634: add             x3, PP, #0x99, lsl #12  ; [pp+0x990e0] Null
    //     0xc00638: ldr             x3, [x3, #0xe0]
    // 0xc0063c: r0 = DefaultTypeTest()
    //     0xc0063c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc00640: ldur            x0, [fp, #-8]
    // 0xc00644: LoadField: r1 = r0->field_f
    //     0xc00644: ldur            w1, [x0, #0xf]
    // 0xc00648: DecompressPointer r1
    //     0xc00648: add             x1, x1, HEAP, lsl #32
    // 0xc0064c: LoadField: r0 = r1->field_b
    //     0xc0064c: ldur            w0, [x1, #0xb]
    // 0xc00650: DecompressPointer r0
    //     0xc00650: add             x0, x0, HEAP, lsl #32
    // 0xc00654: ldur            x1, [fp, #-0x10]
    // 0xc00658: LoadField: r2 = r1->field_f
    //     0xc00658: ldur            w2, [x1, #0xf]
    // 0xc0065c: DecompressPointer r2
    //     0xc0065c: add             x2, x2, HEAP, lsl #32
    // 0xc00660: LoadField: r1 = r2->field_b
    //     0xc00660: ldur            w1, [x2, #0xb]
    // 0xc00664: DecompressPointer r1
    //     0xc00664: add             x1, x1, HEAP, lsl #32
    // 0xc00668: stp             x1, x0, [SP]
    // 0xc0066c: r0 = ==()
    //     0xc0066c: bl              #0x12774c4  ; [package:flutter/src/material/theme_data.dart] ThemeData::==
    // 0xc00670: eor             x1, x0, #0x10
    // 0xc00674: mov             x0, x1
    // 0xc00678: LeaveFrame
    //     0xc00678: mov             SP, fp
    //     0xc0067c: ldp             fp, lr, [SP], #0x10
    // 0xc00680: ret
    //     0xc00680: ret             
    // 0xc00684: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc00684: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc00688: b               #0xc00604
  }
  _ wrap(/* No info */) {
    // ** addr: 0x1200f64, size: 0x44
    // 0x1200f64: EnterFrame
    //     0x1200f64: stp             fp, lr, [SP, #-0x10]!
    //     0x1200f68: mov             fp, SP
    // 0x1200f6c: AllocStack(0x10)
    //     0x1200f6c: sub             SP, SP, #0x10
    // 0x1200f70: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x1200f70: stur            x2, [fp, #-0x10]
    // 0x1200f74: LoadField: r0 = r1->field_f
    //     0x1200f74: ldur            w0, [x1, #0xf]
    // 0x1200f78: DecompressPointer r0
    //     0x1200f78: add             x0, x0, HEAP, lsl #32
    // 0x1200f7c: LoadField: r1 = r0->field_b
    //     0x1200f7c: ldur            w1, [x0, #0xb]
    // 0x1200f80: DecompressPointer r1
    //     0x1200f80: add             x1, x1, HEAP, lsl #32
    // 0x1200f84: stur            x1, [fp, #-8]
    // 0x1200f88: r0 = Theme()
    //     0x1200f88: bl              #0xd2f05c  ; AllocateThemeStub -> Theme (size=0x14)
    // 0x1200f8c: ldur            x1, [fp, #-8]
    // 0x1200f90: StoreField: r0->field_b = r1
    //     0x1200f90: stur            w1, [x0, #0xb]
    // 0x1200f94: ldur            x1, [fp, #-0x10]
    // 0x1200f98: StoreField: r0->field_f = r1
    //     0x1200f98: stur            w1, [x0, #0xf]
    // 0x1200f9c: LeaveFrame
    //     0x1200f9c: mov             SP, fp
    //     0x1200fa0: ldp             fp, lr, [SP], #0x10
    // 0x1200fa4: ret
    //     0x1200fa4: ret             
  }
}
