// lib: , url: package:flutter/src/material/button_bar_theme.dart

// class id: 1048856, size: 0x8
class :: {
}

// class id: 5200, size: 0x2c, field offset: 0x8
//   const constructor, 
class ButtonBarThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x112f22c, size: 0x7c
    // 0x112f22c: EnterFrame
    //     0x112f22c: stp             fp, lr, [SP, #-0x10]!
    //     0x112f230: mov             fp, SP
    // 0x112f234: AllocStack(0x38)
    //     0x112f234: sub             SP, SP, #0x38
    // 0x112f238: CheckStackOverflow
    //     0x112f238: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112f23c: cmp             SP, x16
    //     0x112f240: b.ls            #0x112f2a0
    // 0x112f244: ldr             x0, [fp, #0x10]
    // 0x112f248: LoadField: r1 = r0->field_13
    //     0x112f248: ldur            w1, [x0, #0x13]
    // 0x112f24c: DecompressPointer r1
    //     0x112f24c: add             x1, x1, HEAP, lsl #32
    // 0x112f250: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x112f250: ldur            w2, [x0, #0x17]
    // 0x112f254: DecompressPointer r2
    //     0x112f254: add             x2, x2, HEAP, lsl #32
    // 0x112f258: stp             x1, NULL, [SP, #0x28]
    // 0x112f25c: stp             NULL, x2, [SP, #0x18]
    // 0x112f260: stp             NULL, NULL, [SP, #8]
    // 0x112f264: str             NULL, [SP]
    // 0x112f268: r1 = Null
    //     0x112f268: mov             x1, NULL
    // 0x112f26c: r2 = Null
    //     0x112f26c: mov             x2, NULL
    // 0x112f270: r4 = const [0, 0x9, 0x7, 0x9, null]
    //     0x112f270: add             x4, PP, #0xe, lsl #12  ; [pp+0xe278] List(5) [0, 0x9, 0x7, 0x9, Null]
    //     0x112f274: ldr             x4, [x4, #0x278]
    // 0x112f278: r0 = hash()
    //     0x112f278: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x112f27c: mov             x2, x0
    // 0x112f280: r0 = BoxInt64Instr(r2)
    //     0x112f280: sbfiz           x0, x2, #1, #0x1f
    //     0x112f284: cmp             x2, x0, asr #1
    //     0x112f288: b.eq            #0x112f294
    //     0x112f28c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x112f290: stur            x2, [x0, #7]
    // 0x112f294: LeaveFrame
    //     0x112f294: mov             SP, fp
    //     0x112f298: ldp             fp, lr, [SP], #0x10
    // 0x112f29c: ret
    //     0x112f29c: ret             
    // 0x112f2a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112f2a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112f2a4: b               #0x112f244
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x115f3e4, size: 0x110
    // 0x115f3e4: EnterFrame
    //     0x115f3e4: stp             fp, lr, [SP, #-0x10]!
    //     0x115f3e8: mov             fp, SP
    // 0x115f3ec: AllocStack(0x20)
    //     0x115f3ec: sub             SP, SP, #0x20
    // 0x115f3f0: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0x115f3f0: mov             x4, x1
    //     0x115f3f4: mov             x0, x2
    //     0x115f3f8: stur            x1, [fp, #-0x10]
    //     0x115f3fc: stur            x2, [fp, #-0x18]
    // 0x115f400: CheckStackOverflow
    //     0x115f400: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115f404: cmp             SP, x16
    //     0x115f408: b.ls            #0x115f4c8
    // 0x115f40c: cmp             w4, w0
    // 0x115f410: b.ne            #0x115f424
    // 0x115f414: mov             x0, x4
    // 0x115f418: LeaveFrame
    //     0x115f418: mov             SP, fp
    //     0x115f41c: ldp             fp, lr, [SP], #0x10
    // 0x115f420: ret
    //     0x115f420: ret             
    // 0x115f424: LoadField: r1 = r4->field_13
    //     0x115f424: ldur            w1, [x4, #0x13]
    // 0x115f428: DecompressPointer r1
    //     0x115f428: add             x1, x1, HEAP, lsl #32
    // 0x115f42c: LoadField: r2 = r0->field_13
    //     0x115f42c: ldur            w2, [x0, #0x13]
    // 0x115f430: DecompressPointer r2
    //     0x115f430: add             x2, x2, HEAP, lsl #32
    // 0x115f434: r5 = inline_Allocate_Double()
    //     0x115f434: ldp             x5, x3, [THR, #0x60]  ; THR::top
    //     0x115f438: add             x5, x5, #0x10
    //     0x115f43c: cmp             x3, x5
    //     0x115f440: b.ls            #0x115f4d0
    //     0x115f444: str             x5, [THR, #0x60]  ; THR::top
    //     0x115f448: sub             x5, x5, #0xf
    //     0x115f44c: mov             x3, #0xe19c
    //     0x115f450: movk            x3, #3, lsl #16
    //     0x115f454: stur            x3, [x5, #-1]
    // 0x115f458: dmb             ishst
    // 0x115f45c: StoreField: r5->field_7 = d0
    //     0x115f45c: stur            d0, [x5, #7]
    // 0x115f460: mov             x3, x5
    // 0x115f464: stur            x5, [fp, #-8]
    // 0x115f468: r0 = lerpDouble()
    //     0x115f468: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x115f46c: mov             x4, x0
    // 0x115f470: ldur            x0, [fp, #-0x10]
    // 0x115f474: stur            x4, [fp, #-0x20]
    // 0x115f478: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x115f478: ldur            w1, [x0, #0x17]
    // 0x115f47c: DecompressPointer r1
    //     0x115f47c: add             x1, x1, HEAP, lsl #32
    // 0x115f480: ldur            x0, [fp, #-0x18]
    // 0x115f484: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x115f484: ldur            w2, [x0, #0x17]
    // 0x115f488: DecompressPointer r2
    //     0x115f488: add             x2, x2, HEAP, lsl #32
    // 0x115f48c: ldur            x3, [fp, #-8]
    // 0x115f490: r0 = lerpDouble()
    //     0x115f490: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x115f494: ldur            x3, [fp, #-8]
    // 0x115f498: r1 = Null
    //     0x115f498: mov             x1, NULL
    // 0x115f49c: r2 = Null
    //     0x115f49c: mov             x2, NULL
    // 0x115f4a0: stur            x0, [fp, #-8]
    // 0x115f4a4: r0 = lerp()
    //     0x115f4a4: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x115f4a8: r0 = ButtonBarThemeData()
    //     0x115f4a8: bl              #0x115f4f4  ; AllocateButtonBarThemeDataStub -> ButtonBarThemeData (size=0x2c)
    // 0x115f4ac: ldur            x1, [fp, #-0x20]
    // 0x115f4b0: StoreField: r0->field_13 = r1
    //     0x115f4b0: stur            w1, [x0, #0x13]
    // 0x115f4b4: ldur            x1, [fp, #-8]
    // 0x115f4b8: ArrayStore: r0[0] = r1  ; List_4
    //     0x115f4b8: stur            w1, [x0, #0x17]
    // 0x115f4bc: LeaveFrame
    //     0x115f4bc: mov             SP, fp
    //     0x115f4c0: ldp             fp, lr, [SP], #0x10
    // 0x115f4c4: ret
    //     0x115f4c4: ret             
    // 0x115f4c8: r0 = StackOverflowSharedWithFPURegs()
    //     0x115f4c8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x115f4cc: b               #0x115f40c
    // 0x115f4d0: SaveReg d0
    //     0x115f4d0: str             q0, [SP, #-0x10]!
    // 0x115f4d4: stp             x2, x4, [SP, #-0x10]!
    // 0x115f4d8: stp             x0, x1, [SP, #-0x10]!
    // 0x115f4dc: r0 = AllocateDouble()
    //     0x115f4dc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x115f4e0: mov             x5, x0
    // 0x115f4e4: ldp             x0, x1, [SP], #0x10
    // 0x115f4e8: ldp             x2, x4, [SP], #0x10
    // 0x115f4ec: RestoreReg d0
    //     0x115f4ec: ldr             q0, [SP], #0x10
    // 0x115f4f0: b               #0x115f45c
  }
  _ ==(/* No info */) {
    // ** addr: 0x1264cd0, size: 0x13c
    // 0x1264cd0: EnterFrame
    //     0x1264cd0: stp             fp, lr, [SP, #-0x10]!
    //     0x1264cd4: mov             fp, SP
    // 0x1264cd8: AllocStack(0x10)
    //     0x1264cd8: sub             SP, SP, #0x10
    // 0x1264cdc: CheckStackOverflow
    //     0x1264cdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1264ce0: cmp             SP, x16
    //     0x1264ce4: b.ls            #0x1264e04
    // 0x1264ce8: ldr             x0, [fp, #0x10]
    // 0x1264cec: cmp             w0, NULL
    // 0x1264cf0: b.ne            #0x1264d04
    // 0x1264cf4: r0 = false
    //     0x1264cf4: add             x0, NULL, #0x30  ; false
    // 0x1264cf8: LeaveFrame
    //     0x1264cf8: mov             SP, fp
    //     0x1264cfc: ldp             fp, lr, [SP], #0x10
    // 0x1264d00: ret
    //     0x1264d00: ret             
    // 0x1264d04: ldr             x1, [fp, #0x18]
    // 0x1264d08: cmp             w1, w0
    // 0x1264d0c: b.ne            #0x1264d20
    // 0x1264d10: r0 = true
    //     0x1264d10: add             x0, NULL, #0x20  ; true
    // 0x1264d14: LeaveFrame
    //     0x1264d14: mov             SP, fp
    //     0x1264d18: ldp             fp, lr, [SP], #0x10
    // 0x1264d1c: ret
    //     0x1264d1c: ret             
    // 0x1264d20: str             x0, [SP]
    // 0x1264d24: r0 = runtimeType()
    //     0x1264d24: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1264d28: r1 = LoadClassIdInstr(r0)
    //     0x1264d28: ldur            x1, [x0, #-1]
    //     0x1264d2c: ubfx            x1, x1, #0xc, #0x14
    // 0x1264d30: r16 = ButtonBarThemeData
    //     0x1264d30: add             x16, PP, #0x26, lsl #12  ; [pp+0x26548] Type: ButtonBarThemeData
    //     0x1264d34: ldr             x16, [x16, #0x548]
    // 0x1264d38: stp             x16, x0, [SP]
    // 0x1264d3c: mov             x0, x1
    // 0x1264d40: mov             lr, x0
    // 0x1264d44: ldr             lr, [x21, lr, lsl #3]
    // 0x1264d48: blr             lr
    // 0x1264d4c: tbz             w0, #4, #0x1264d60
    // 0x1264d50: r0 = false
    //     0x1264d50: add             x0, NULL, #0x30  ; false
    // 0x1264d54: LeaveFrame
    //     0x1264d54: mov             SP, fp
    //     0x1264d58: ldp             fp, lr, [SP], #0x10
    // 0x1264d5c: ret
    //     0x1264d5c: ret             
    // 0x1264d60: ldr             x1, [fp, #0x10]
    // 0x1264d64: r0 = 60
    //     0x1264d64: mov             x0, #0x3c
    // 0x1264d68: branchIfSmi(r1, 0x1264d74)
    //     0x1264d68: tbz             w1, #0, #0x1264d74
    // 0x1264d6c: r0 = LoadClassIdInstr(r1)
    //     0x1264d6c: ldur            x0, [x1, #-1]
    //     0x1264d70: ubfx            x0, x0, #0xc, #0x14
    // 0x1264d74: r17 = 5200
    //     0x1264d74: mov             x17, #0x1450
    // 0x1264d78: cmp             x0, x17
    // 0x1264d7c: b.ne            #0x1264df4
    // 0x1264d80: ldr             x2, [fp, #0x18]
    // 0x1264d84: LoadField: r0 = r1->field_13
    //     0x1264d84: ldur            w0, [x1, #0x13]
    // 0x1264d88: DecompressPointer r0
    //     0x1264d88: add             x0, x0, HEAP, lsl #32
    // 0x1264d8c: LoadField: r3 = r2->field_13
    //     0x1264d8c: ldur            w3, [x2, #0x13]
    // 0x1264d90: DecompressPointer r3
    //     0x1264d90: add             x3, x3, HEAP, lsl #32
    // 0x1264d94: r4 = LoadClassIdInstr(r0)
    //     0x1264d94: ldur            x4, [x0, #-1]
    //     0x1264d98: ubfx            x4, x4, #0xc, #0x14
    // 0x1264d9c: stp             x3, x0, [SP]
    // 0x1264da0: mov             x0, x4
    // 0x1264da4: mov             lr, x0
    // 0x1264da8: ldr             lr, [x21, lr, lsl #3]
    // 0x1264dac: blr             lr
    // 0x1264db0: tbnz            w0, #4, #0x1264df4
    // 0x1264db4: ldr             x1, [fp, #0x18]
    // 0x1264db8: ldr             x0, [fp, #0x10]
    // 0x1264dbc: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x1264dbc: ldur            w2, [x0, #0x17]
    // 0x1264dc0: DecompressPointer r2
    //     0x1264dc0: add             x2, x2, HEAP, lsl #32
    // 0x1264dc4: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x1264dc4: ldur            w0, [x1, #0x17]
    // 0x1264dc8: DecompressPointer r0
    //     0x1264dc8: add             x0, x0, HEAP, lsl #32
    // 0x1264dcc: r1 = LoadClassIdInstr(r2)
    //     0x1264dcc: ldur            x1, [x2, #-1]
    //     0x1264dd0: ubfx            x1, x1, #0xc, #0x14
    // 0x1264dd4: stp             x0, x2, [SP]
    // 0x1264dd8: mov             x0, x1
    // 0x1264ddc: mov             lr, x0
    // 0x1264de0: ldr             lr, [x21, lr, lsl #3]
    // 0x1264de4: blr             lr
    // 0x1264de8: tbnz            w0, #4, #0x1264df4
    // 0x1264dec: r0 = true
    //     0x1264dec: add             x0, NULL, #0x20  ; true
    // 0x1264df0: b               #0x1264df8
    // 0x1264df4: r0 = false
    //     0x1264df4: add             x0, NULL, #0x30  ; false
    // 0x1264df8: LeaveFrame
    //     0x1264df8: mov             SP, fp
    //     0x1264dfc: ldp             fp, lr, [SP], #0x10
    // 0x1264e00: ret
    //     0x1264e00: ret             
    // 0x1264e04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1264e04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1264e08: b               #0x1264ce8
  }
}
