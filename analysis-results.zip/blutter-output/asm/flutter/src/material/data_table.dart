// lib: , url: package:flutter/src/material/data_table.dart

// class id: 1048872, size: 0x8
class :: {
}

// class id: 3115, size: 0x8, field offset: 0x8
//   const constructor, 
class _NullTableColumnWidth extends TableColumnWidth {
}

// class id: 3116, size: 0x28, field offset: 0x8
//   const constructor, 
class DataCell extends Object {
}

// class id: 3117, size: 0x28, field offset: 0x8
//   const constructor, 
class DataRow extends Object {
}

// class id: 3118, size: 0x24, field offset: 0x8
//   const constructor, 
class DataColumn extends Object {
}

// class id: 5851, size: 0xc, field offset: 0xc
//   const constructor, 
class _NullWidget extends Widget {
}

// class id: 6172, size: 0x94, field offset: 0x94
//   const constructor, 
class TableRowInkWell extends InkResponse {

  [closure] (dynamic) => Rect getRectCallback(dynamic, RenderBox) {
    // ** addr: 0xfb6040, size: 0x38
    // 0xfb6040: EnterFrame
    //     0xfb6040: stp             fp, lr, [SP, #-0x10]!
    //     0xfb6044: mov             fp, SP
    // 0xfb6048: r1 = 1
    //     0xfb6048: mov             x1, #1
    // 0xfb604c: r0 = AllocateContext()
    //     0xfb604c: bl              #0x13de838  ; AllocateContextStub
    // 0xfb6050: mov             x1, x0
    // 0xfb6054: ldr             x0, [fp, #0x10]
    // 0xfb6058: StoreField: r1->field_f = r0
    //     0xfb6058: stur            w0, [x1, #0xf]
    // 0xfb605c: mov             x2, x1
    // 0xfb6060: r1 = Function '<anonymous closure>':.
    //     0xfb6060: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a90] AnonymousClosure: (0xfb6078), of [package:flutter/src/material/data_table.dart] TableRowInkWell
    //     0xfb6064: ldr             x1, [x1, #0xa90]
    // 0xfb6068: r0 = AllocateClosure()
    //     0xfb6068: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfb606c: LeaveFrame
    //     0xfb606c: mov             SP, fp
    //     0xfb6070: ldp             fp, lr, [SP], #0x10
    // 0xfb6074: ret
    //     0xfb6074: ret             
  }
  [closure] Rect <anonymous closure>(dynamic) {
    // ** addr: 0xfb6078, size: 0x1f8
    // 0xfb6078: EnterFrame
    //     0xfb6078: stp             fp, lr, [SP, #-0x10]!
    //     0xfb607c: mov             fp, SP
    // 0xfb6080: AllocStack(0x20)
    //     0xfb6080: sub             SP, SP, #0x20
    // 0xfb6084: SetupParameters([dynamic _ /* r0 */])
    //     0xfb6084: ldr             x0, [fp, #0x10]
    //     0xfb6088: ldur            w1, [x0, #0x17]
    //     0xfb608c: add             x1, x1, HEAP, lsl #32
    // 0xfb6090: CheckStackOverflow
    //     0xfb6090: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb6094: cmp             SP, x16
    //     0xfb6098: b.ls            #0xfb6258
    // 0xfb609c: LoadField: r2 = r1->field_f
    //     0xfb609c: ldur            w2, [x1, #0xf]
    // 0xfb60a0: DecompressPointer r2
    //     0xfb60a0: add             x2, x2, HEAP, lsl #32
    // 0xfb60a4: stur            x2, [fp, #-8]
    // 0xfb60a8: r0 = LoadClassIdInstr(r2)
    //     0xfb60a8: ldur            x0, [x2, #-1]
    //     0xfb60ac: ubfx            x0, x0, #0xc, #0x14
    // 0xfb60b0: mov             x1, x2
    // 0xfb60b4: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0xfb60b4: mov             x17, #0xfc0
    //     0xfb60b8: movk            x17, #1, lsl #16
    //     0xfb60bc: add             lr, x0, x17
    //     0xfb60c0: ldr             lr, [x21, lr, lsl #3]
    //     0xfb60c4: blr             lr
    // 0xfb60c8: stur            x0, [fp, #-0x10]
    // 0xfb60cc: r0 = Matrix4()
    //     0xfb60cc: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xfb60d0: r4 = 32
    //     0xfb60d0: mov             x4, #0x20
    // 0xfb60d4: stur            x0, [fp, #-0x18]
    // 0xfb60d8: r0 = AllocateFloat64Array()
    //     0xfb60d8: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0xfb60dc: mov             x1, x0
    // 0xfb60e0: ldur            x0, [fp, #-0x18]
    // 0xfb60e4: StoreField: r0->field_7 = r1
    //     0xfb60e4: stur            w1, [x0, #7]
    // 0xfb60e8: mov             x1, x0
    // 0xfb60ec: r0 = setIdentity()
    //     0xfb60ec: bl              #0x836d10  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0xfb60f0: ldur            x3, [fp, #-8]
    // 0xfb60f4: ldur            x4, [fp, #-0x10]
    // 0xfb60f8: stur            x4, [fp, #-8]
    // 0xfb60fc: stur            x3, [fp, #-0x20]
    // 0xfb6100: CheckStackOverflow
    //     0xfb6100: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb6104: cmp             SP, x16
    //     0xfb6108: b.ls            #0xfb6260
    // 0xfb610c: r0 = LoadClassIdInstr(r4)
    //     0xfb610c: ldur            x0, [x4, #-1]
    //     0xfb6110: ubfx            x0, x0, #0xc, #0x14
    // 0xfb6114: r17 = -4679
    //     0xfb6114: mov             x17, #-0x1247
    // 0xfb6118: add             x16, x0, x17
    // 0xfb611c: cmp             x16, #0x128
    // 0xfb6120: b.hi            #0xfb6188
    // 0xfb6124: r17 = 4723
    //     0xfb6124: mov             x17, #0x1273
    // 0xfb6128: cmp             x0, x17
    // 0xfb612c: b.eq            #0xfb6188
    // 0xfb6130: r0 = LoadClassIdInstr(r4)
    //     0xfb6130: ldur            x0, [x4, #-1]
    //     0xfb6134: ubfx            x0, x0, #0xc, #0x14
    // 0xfb6138: mov             x1, x4
    // 0xfb613c: mov             x2, x3
    // 0xfb6140: ldur            x3, [fp, #-0x18]
    // 0xfb6144: r0 = GDT[cid_x0 + 0x10462]()
    //     0xfb6144: mov             x17, #0x462
    //     0xfb6148: movk            x17, #1, lsl #16
    //     0xfb614c: add             lr, x0, x17
    //     0xfb6150: ldr             lr, [x21, lr, lsl #3]
    //     0xfb6154: blr             lr
    // 0xfb6158: ldur            x2, [fp, #-8]
    // 0xfb615c: r0 = LoadClassIdInstr(r2)
    //     0xfb615c: ldur            x0, [x2, #-1]
    //     0xfb6160: ubfx            x0, x0, #0xc, #0x14
    // 0xfb6164: mov             x1, x2
    // 0xfb6168: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0xfb6168: mov             x17, #0xfc0
    //     0xfb616c: movk            x17, #1, lsl #16
    //     0xfb6170: add             lr, x0, x17
    //     0xfb6174: ldr             lr, [x21, lr, lsl #3]
    //     0xfb6178: blr             lr
    // 0xfb617c: ldur            x3, [fp, #-8]
    // 0xfb6180: mov             x4, x0
    // 0xfb6184: b               #0xfb60f8
    // 0xfb6188: r17 = 4723
    //     0xfb6188: mov             x17, #0x1273
    // 0xfb618c: cmp             x0, x17
    // 0xfb6190: b.ne            #0xfb6248
    // 0xfb6194: LoadField: r4 = r3->field_7
    //     0xfb6194: ldur            w4, [x3, #7]
    // 0xfb6198: DecompressPointer r4
    //     0xfb6198: add             x4, x4, HEAP, lsl #32
    // 0xfb619c: stur            x4, [fp, #-0x10]
    // 0xfb61a0: cmp             w4, NULL
    // 0xfb61a4: b.eq            #0xfb6268
    // 0xfb61a8: mov             x0, x4
    // 0xfb61ac: r2 = Null
    //     0xfb61ac: mov             x2, NULL
    // 0xfb61b0: r1 = Null
    //     0xfb61b0: mov             x1, NULL
    // 0xfb61b4: r4 = LoadClassIdInstr(r0)
    //     0xfb61b4: ldur            x4, [x0, #-1]
    //     0xfb61b8: ubfx            x4, x4, #0xc, #0x14
    // 0xfb61bc: r17 = 4191
    //     0xfb61bc: mov             x17, #0x105f
    // 0xfb61c0: cmp             x4, x17
    // 0xfb61c4: b.eq            #0xfb61dc
    // 0xfb61c8: r8 = TableCellParentData
    //     0xfb61c8: add             x8, PP, #0x84, lsl #12  ; [pp+0x84a98] Type: TableCellParentData
    //     0xfb61cc: ldr             x8, [x8, #0xa98]
    // 0xfb61d0: r3 = Null
    //     0xfb61d0: add             x3, PP, #0x84, lsl #12  ; [pp+0x84aa0] Null
    //     0xfb61d4: ldr             x3, [x3, #0xaa0]
    // 0xfb61d8: r0 = DefaultTypeTest()
    //     0xfb61d8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xfb61dc: ldur            x0, [fp, #-0x10]
    // 0xfb61e0: LoadField: r1 = r0->field_f
    //     0xfb61e0: ldur            w1, [x0, #0xf]
    // 0xfb61e4: DecompressPointer r1
    //     0xfb61e4: add             x1, x1, HEAP, lsl #32
    // 0xfb61e8: cmp             w1, NULL
    // 0xfb61ec: b.eq            #0xfb626c
    // 0xfb61f0: r2 = LoadInt32Instr(r1)
    //     0xfb61f0: sbfx            x2, x1, #1, #0x1f
    //     0xfb61f4: tbz             w1, #0, #0xfb61fc
    //     0xfb61f8: ldur            x2, [x1, #7]
    // 0xfb61fc: ldur            x1, [fp, #-8]
    // 0xfb6200: r0 = getRowBox()
    //     0xfb6200: bl              #0xc154d8  ; [package:flutter/src/rendering/table.dart] RenderTable::getRowBox
    // 0xfb6204: ldur            x1, [fp, #-8]
    // 0xfb6208: ldur            x2, [fp, #-0x20]
    // 0xfb620c: ldur            x3, [fp, #-0x18]
    // 0xfb6210: stur            x0, [fp, #-8]
    // 0xfb6214: r0 = applyPaintTransform()
    //     0xfb6214: bl              #0xbf1f9c  ; [package:flutter/src/rendering/box.dart] RenderBox::applyPaintTransform
    // 0xfb6218: ldur            x1, [fp, #-0x18]
    // 0xfb621c: r0 = getAsTranslation()
    //     0xfb621c: bl              #0xc155c4  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::getAsTranslation
    // 0xfb6220: cmp             w0, NULL
    // 0xfb6224: b.eq            #0xfb6248
    // 0xfb6228: mov             x1, x0
    // 0xfb622c: r0 = unary-()
    //     0xfb622c: bl              #0x856e6c  ; [dart:ui] Offset::unary-
    // 0xfb6230: ldur            x1, [fp, #-8]
    // 0xfb6234: mov             x2, x0
    // 0xfb6238: r0 = shift()
    //     0xfb6238: bl              #0x8610a4  ; [dart:ui] Rect::shift
    // 0xfb623c: LeaveFrame
    //     0xfb623c: mov             SP, fp
    //     0xfb6240: ldp             fp, lr, [SP], #0x10
    // 0xfb6244: ret
    //     0xfb6244: ret             
    // 0xfb6248: r0 = Instance_Rect
    //     0xfb6248: ldr             x0, [PP, #0x2a60]  ; [pp+0x2a60] Obj!Rect@12a73c1
    // 0xfb624c: LeaveFrame
    //     0xfb624c: mov             SP, fp
    //     0xfb6250: ldp             fp, lr, [SP], #0x10
    // 0xfb6254: ret
    //     0xfb6254: ret             
    // 0xfb6258: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb6258: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb625c: b               #0xfb609c
    // 0xfb6260: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb6260: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb6264: b               #0xfb610c
    // 0xfb6268: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfb6268: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfb626c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfb626c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6173, size: 0x68, field offset: 0xc
class DataTable extends StatelessWidget {

  static late final LocalKey _headingRowKey; // offset: 0x660

  _ build(/* No info */) {
    // ** addr: 0xfb460c, size: 0xa04
    // 0xfb460c: EnterFrame
    //     0xfb460c: stp             fp, lr, [SP, #-0x10]!
    //     0xfb4610: mov             fp, SP
    // 0xfb4614: AllocStack(0xa8)
    //     0xfb4614: sub             SP, SP, #0xa8
    // 0xfb4618: SetupParameters(DataTable this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xfb4618: mov             x0, x1
    //     0xfb461c: stur            x1, [fp, #-8]
    //     0xfb4620: mov             x1, x2
    //     0xfb4624: stur            x2, [fp, #-0x10]
    // 0xfb4628: CheckStackOverflow
    //     0xfb4628: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb462c: cmp             SP, x16
    //     0xfb4630: b.ls            #0xfb4fcc
    // 0xfb4634: r1 = 10
    //     0xfb4634: mov             x1, #0xa
    // 0xfb4638: r0 = AllocateContext()
    //     0xfb4638: bl              #0x13de838  ; AllocateContextStub
    // 0xfb463c: mov             x2, x0
    // 0xfb4640: ldur            x0, [fp, #-8]
    // 0xfb4644: stur            x2, [fp, #-0x18]
    // 0xfb4648: StoreField: r2->field_f = r0
    //     0xfb4648: stur            w0, [x2, #0xf]
    // 0xfb464c: ldur            x1, [fp, #-0x10]
    // 0xfb4650: StoreField: r2->field_13 = r1
    //     0xfb4650: stur            w1, [x2, #0x13]
    // 0xfb4654: r0 = of()
    //     0xfb4654: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb4658: mov             x3, x0
    // 0xfb465c: ldur            x2, [fp, #-0x18]
    // 0xfb4660: stur            x3, [fp, #-0x10]
    // 0xfb4664: ArrayStore: r2[0] = r0  ; List_4
    //     0xfb4664: stur            w0, [x2, #0x17]
    //     0xfb4668: ldurb           w16, [x2, #-1]
    //     0xfb466c: ldurb           w17, [x0, #-1]
    //     0xfb4670: and             x16, x17, x16, lsr #2
    //     0xfb4674: tst             x16, HEAP, lsr #32
    //     0xfb4678: b.eq            #0xfb4680
    //     0xfb467c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfb4680: LoadField: r1 = r2->field_13
    //     0xfb4680: ldur            w1, [x2, #0x13]
    // 0xfb4684: DecompressPointer r1
    //     0xfb4684: add             x1, x1, HEAP, lsl #32
    // 0xfb4688: r0 = of()
    //     0xfb4688: bl              #0xfb561c  ; [package:flutter/src/material/data_table_theme.dart] DataTableTheme::of
    // 0xfb468c: mov             x4, x0
    // 0xfb4690: ldur            x3, [fp, #-0x18]
    // 0xfb4694: stur            x4, [fp, #-0x20]
    // 0xfb4698: StoreField: r3->field_1b = r0
    //     0xfb4698: stur            w0, [x3, #0x1b]
    //     0xfb469c: ldurb           w16, [x3, #-1]
    //     0xfb46a0: ldurb           w17, [x0, #-1]
    //     0xfb46a4: and             x16, x17, x16, lsr #2
    //     0xfb46a8: tst             x16, HEAP, lsr #32
    //     0xfb46ac: b.eq            #0xfb46b4
    //     0xfb46b0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xfb46b4: mov             x2, x3
    // 0xfb46b8: r1 = Function '<anonymous closure>':.
    //     0xfb46b8: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8ff38] AnonymousClosure: (0xfb5c40), in [package:flutter/src/material/data_table.dart] DataTable::build (0xfb460c)
    //     0xfb46bc: ldr             x1, [x1, #0xf38]
    // 0xfb46c0: r0 = AllocateClosure()
    //     0xfb46c0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfb46c4: r16 = <Color?>
    //     0xfb46c4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xfb46c8: ldr             x16, [x16, #0xa40]
    // 0xfb46cc: stp             x0, x16, [SP]
    // 0xfb46d0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xfb46d0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xfb46d4: r0 = resolveWith()
    //     0xfb46d4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xfb46d8: ldur            x3, [fp, #-0x18]
    // 0xfb46dc: StoreField: r3->field_27 = r0
    //     0xfb46dc: stur            w0, [x3, #0x27]
    //     0xfb46e0: ldurb           w16, [x3, #-1]
    //     0xfb46e4: ldurb           w17, [x0, #-1]
    //     0xfb46e8: and             x16, x17, x16, lsr #2
    //     0xfb46ec: tst             x16, HEAP, lsr #32
    //     0xfb46f0: b.eq            #0xfb46f8
    //     0xfb46f4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xfb46f8: ldur            x0, [fp, #-8]
    // 0xfb46fc: LoadField: r4 = r0->field_4b
    //     0xfb46fc: ldur            w4, [x0, #0x4b]
    // 0xfb4700: DecompressPointer r4
    //     0xfb4700: add             x4, x4, HEAP, lsl #32
    // 0xfb4704: stur            x4, [fp, #-0x28]
    // 0xfb4708: r1 = Function '<anonymous closure>':.
    //     0xfb4708: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8ff40] Function: [dart:core] Object::_simpleInstanceOfFalse (0x13dce48)
    //     0xfb470c: ldr             x1, [x1, #0xf40]
    // 0xfb4710: r2 = Null
    //     0xfb4710: mov             x2, NULL
    // 0xfb4714: r0 = AllocateClosure()
    //     0xfb4714: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfb4718: ldur            x1, [fp, #-0x28]
    // 0xfb471c: mov             x2, x0
    // 0xfb4720: r0 = any()
    //     0xfb4720: bl              #0xbae1ac  ; [dart:collection] ListBase::any
    // 0xfb4724: ldur            x0, [fp, #-0x18]
    // 0xfb4728: r3 = false
    //     0xfb4728: add             x3, NULL, #0x30  ; false
    // 0xfb472c: StoreField: r0->field_2b = r3
    //     0xfb472c: stur            w3, [x0, #0x2b]
    // 0xfb4730: r1 = <DataRow>
    //     0xfb4730: add             x1, PP, #0x7a, lsl #12  ; [pp+0x7aa28] TypeArguments: <DataRow>
    //     0xfb4734: ldr             x1, [x1, #0xa28]
    // 0xfb4738: r2 = 0
    //     0xfb4738: mov             x2, #0
    // 0xfb473c: r0 = _GrowableList()
    //     0xfb473c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfb4740: r1 = Function '<anonymous closure>':.
    //     0xfb4740: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8ff48] Function: [dart:core] Object::_simpleInstanceOfFalse (0x13dce48)
    //     0xfb4744: ldr             x1, [x1, #0xf48]
    // 0xfb4748: r2 = Null
    //     0xfb4748: mov             x2, NULL
    // 0xfb474c: stur            x0, [fp, #-0x30]
    // 0xfb4750: r0 = AllocateClosure()
    //     0xfb4750: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfb4754: ldur            x1, [fp, #-0x30]
    // 0xfb4758: mov             x2, x0
    // 0xfb475c: r0 = where()
    //     0xfb475c: bl              #0xb92e4c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0xfb4760: ldur            x0, [fp, #-0x18]
    // 0xfb4764: r4 = false
    //     0xfb4764: add             x4, NULL, #0x30  ; false
    // 0xfb4768: StoreField: r0->field_2f = r4
    //     0xfb4768: stur            w4, [x0, #0x2f]
    // 0xfb476c: ldur            x1, [fp, #-0x20]
    // 0xfb4770: LoadField: r2 = r1->field_27
    //     0xfb4770: ldur            w2, [x1, #0x27]
    // 0xfb4774: DecompressPointer r2
    //     0xfb4774: add             x2, x2, HEAP, lsl #32
    // 0xfb4778: cmp             w2, NULL
    // 0xfb477c: b.ne            #0xfb4794
    // 0xfb4780: ldur            x2, [fp, #-0x10]
    // 0xfb4784: LoadField: r3 = r2->field_bf
    //     0xfb4784: ldur            w3, [x2, #0xbf]
    // 0xfb4788: DecompressPointer r3
    //     0xfb4788: add             x3, x3, HEAP, lsl #32
    // 0xfb478c: LoadField: r2 = r3->field_27
    //     0xfb478c: ldur            w2, [x3, #0x27]
    // 0xfb4790: DecompressPointer r2
    //     0xfb4790: add             x2, x2, HEAP, lsl #32
    // 0xfb4794: cmp             w2, NULL
    // 0xfb4798: b.ne            #0xfb47a4
    // 0xfb479c: d0 = 24.000000
    //     0xfb479c: fmov            d0, #24.00000000
    // 0xfb47a0: b               #0xfb47a8
    // 0xfb47a4: LoadField: d0 = r2->field_7
    //     0xfb47a4: ldur            d0, [x2, #7]
    // 0xfb47a8: stur            d0, [fp, #-0x88]
    // 0xfb47ac: LoadField: r2 = r1->field_33
    //     0xfb47ac: ldur            w2, [x1, #0x33]
    // 0xfb47b0: DecompressPointer r2
    //     0xfb47b0: add             x2, x2, HEAP, lsl #32
    // 0xfb47b4: cmp             w2, NULL
    // 0xfb47b8: b.eq            #0xfb47bc
    // 0xfb47bc: cmp             w2, NULL
    // 0xfb47c0: b.eq            #0xfb47c4
    // 0xfb47c4: ldur            x5, [fp, #-8]
    // 0xfb47c8: ldur            x6, [fp, #-0x28]
    // 0xfb47cc: LoadField: r7 = r5->field_b
    //     0xfb47cc: ldur            w7, [x5, #0xb]
    // 0xfb47d0: DecompressPointer r7
    //     0xfb47d0: add             x7, x7, HEAP, lsl #32
    // 0xfb47d4: stur            x7, [fp, #-0x10]
    // 0xfb47d8: LoadField: r1 = r7->field_b
    //     0xfb47d8: ldur            w1, [x7, #0xb]
    // 0xfb47dc: r2 = LoadInt32Instr(r1)
    //     0xfb47dc: sbfx            x2, x1, #1, #0x1f
    // 0xfb47e0: r1 = <TableColumnWidth>
    //     0xfb47e0: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8ff50] TypeArguments: <TableColumnWidth>
    //     0xfb47e4: ldr             x1, [x1, #0xf50]
    // 0xfb47e8: r3 = Instance__NullTableColumnWidth
    //     0xfb47e8: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8ff58] Obj!_NullTableColumnWidth@129ee11
    //     0xfb47ec: ldr             x3, [x3, #0xf58]
    // 0xfb47f0: r0 = _List.filled()
    //     0xfb47f0: bl              #0x7f3644  ; [dart:core] _List::_List.filled
    // 0xfb47f4: ldur            x3, [fp, #-0x18]
    // 0xfb47f8: StoreField: r3->field_33 = r0
    //     0xfb47f8: stur            w0, [x3, #0x33]
    //     0xfb47fc: ldurb           w16, [x3, #-1]
    //     0xfb4800: ldurb           w17, [x0, #-1]
    //     0xfb4804: and             x16, x17, x16, lsr #2
    //     0xfb4808: tst             x16, HEAP, lsr #32
    //     0xfb480c: b.eq            #0xfb4814
    //     0xfb4810: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xfb4814: ldur            x0, [fp, #-0x28]
    // 0xfb4818: LoadField: r1 = r0->field_b
    //     0xfb4818: ldur            w1, [x0, #0xb]
    // 0xfb481c: r2 = LoadInt32Instr(r1)
    //     0xfb481c: sbfx            x2, x1, #1, #0x1f
    // 0xfb4820: add             x4, x2, #1
    // 0xfb4824: mov             x2, x3
    // 0xfb4828: stur            x4, [fp, #-0x38]
    // 0xfb482c: r1 = Function '<anonymous closure>':.
    //     0xfb482c: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8ff60] AnonymousClosure: (0xfb5674), in [package:flutter/src/material/data_table.dart] DataTable::build (0xfb460c)
    //     0xfb4830: ldr             x1, [x1, #0xf60]
    // 0xfb4834: r0 = AllocateClosure()
    //     0xfb4834: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfb4838: ldur            x2, [fp, #-0x38]
    // 0xfb483c: r1 = <TableRow>
    //     0xfb483c: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8ff68] TypeArguments: <TableRow>
    //     0xfb4840: ldr             x1, [x1, #0xf68]
    // 0xfb4844: stur            x0, [fp, #-0x20]
    // 0xfb4848: r0 = _GrowableList()
    //     0xfb4848: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfb484c: mov             x1, x0
    // 0xfb4850: stur            x1, [fp, #-0x30]
    // 0xfb4854: r2 = 0
    //     0xfb4854: mov             x2, #0
    // 0xfb4858: stur            x2, [fp, #-0x38]
    // 0xfb485c: CheckStackOverflow
    //     0xfb485c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb4860: cmp             SP, x16
    //     0xfb4864: b.ls            #0xfb4fd4
    // 0xfb4868: LoadField: r0 = r1->field_b
    //     0xfb4868: ldur            w0, [x1, #0xb]
    // 0xfb486c: r3 = LoadInt32Instr(r0)
    //     0xfb486c: sbfx            x3, x0, #1, #0x1f
    // 0xfb4870: cmp             x2, x3
    // 0xfb4874: b.ge            #0xfb4934
    // 0xfb4878: lsl             x0, x2, #1
    // 0xfb487c: ldur            x16, [fp, #-0x20]
    // 0xfb4880: stp             x0, x16, [SP]
    // 0xfb4884: ldur            x0, [fp, #-0x20]
    // 0xfb4888: ClosureCall
    //     0xfb4888: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xfb488c: ldur            x2, [x0, #0x1f]
    //     0xfb4890: blr             x2
    // 0xfb4894: mov             x3, x0
    // 0xfb4898: r2 = Null
    //     0xfb4898: mov             x2, NULL
    // 0xfb489c: r1 = Null
    //     0xfb489c: mov             x1, NULL
    // 0xfb48a0: stur            x3, [fp, #-0x40]
    // 0xfb48a4: r4 = 60
    //     0xfb48a4: mov             x4, #0x3c
    // 0xfb48a8: branchIfSmi(r0, 0xfb48b4)
    //     0xfb48a8: tbz             w0, #0, #0xfb48b4
    // 0xfb48ac: r4 = LoadClassIdInstr(r0)
    //     0xfb48ac: ldur            x4, [x0, #-1]
    //     0xfb48b0: ubfx            x4, x4, #0xc, #0x14
    // 0xfb48b4: cmp             x4, #0xa0d
    // 0xfb48b8: b.eq            #0xfb48d0
    // 0xfb48bc: r8 = TableRow
    //     0xfb48bc: add             x8, PP, #0x8f, lsl #12  ; [pp+0x8ff70] Type: TableRow
    //     0xfb48c0: ldr             x8, [x8, #0xf70]
    // 0xfb48c4: r3 = Null
    //     0xfb48c4: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8ff78] Null
    //     0xfb48c8: ldr             x3, [x3, #0xf78]
    // 0xfb48cc: r0 = TableRow()
    //     0xfb48cc: bl              #0xb91ce4  ; IsType_TableRow_Stub
    // 0xfb48d0: ldur            x3, [fp, #-0x30]
    // 0xfb48d4: LoadField: r0 = r3->field_b
    //     0xfb48d4: ldur            w0, [x3, #0xb]
    // 0xfb48d8: r1 = LoadInt32Instr(r0)
    //     0xfb48d8: sbfx            x1, x0, #1, #0x1f
    // 0xfb48dc: mov             x0, x1
    // 0xfb48e0: ldur            x1, [fp, #-0x38]
    // 0xfb48e4: cmp             x1, x0
    // 0xfb48e8: b.hs            #0xfb4fdc
    // 0xfb48ec: LoadField: r1 = r3->field_f
    //     0xfb48ec: ldur            w1, [x3, #0xf]
    // 0xfb48f0: DecompressPointer r1
    //     0xfb48f0: add             x1, x1, HEAP, lsl #32
    // 0xfb48f4: ldur            x0, [fp, #-0x40]
    // 0xfb48f8: ldur            x2, [fp, #-0x38]
    // 0xfb48fc: ArrayStore: r1[r2] = r0  ; List_4
    //     0xfb48fc: add             x25, x1, x2, lsl #2
    //     0xfb4900: add             x25, x25, #0xf
    //     0xfb4904: str             w0, [x25]
    //     0xfb4908: tbz             w0, #0, #0xfb4924
    //     0xfb490c: ldurb           w16, [x1, #-1]
    //     0xfb4910: ldurb           w17, [x0, #-1]
    //     0xfb4914: and             x16, x17, x16, lsr #2
    //     0xfb4918: tst             x16, HEAP, lsr #32
    //     0xfb491c: b.eq            #0xfb4924
    //     0xfb4920: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfb4924: add             x0, x2, #1
    // 0xfb4928: mov             x2, x0
    // 0xfb492c: mov             x1, x3
    // 0xfb4930: b               #0xfb4858
    // 0xfb4934: mov             x3, x1
    // 0xfb4938: ldur            x1, [fp, #-8]
    // 0xfb493c: ldur            x0, [fp, #-0x18]
    // 0xfb4940: r1 = 2
    //     0xfb4940: mov             x1, #2
    // 0xfb4944: r0 = AllocateContext()
    //     0xfb4944: bl              #0x13de838  ; AllocateContextStub
    // 0xfb4948: mov             x1, x0
    // 0xfb494c: ldur            x0, [fp, #-0x18]
    // 0xfb4950: StoreField: r1->field_b = r0
    //     0xfb4950: stur            w0, [x1, #0xb]
    // 0xfb4954: StoreField: r1->field_f = rZR
    //     0xfb4954: stur            wzr, [x1, #0xf]
    // 0xfb4958: ldur            x2, [fp, #-8]
    // 0xfb495c: LoadField: r3 = r2->field_63
    //     0xfb495c: ldur            w3, [x2, #0x63]
    // 0xfb4960: DecompressPointer r3
    //     0xfb4960: add             x3, x3, HEAP, lsl #32
    // 0xfb4964: stur            x3, [fp, #-0x40]
    // 0xfb4968: mov             x9, x1
    // 0xfb496c: r8 = 0
    //     0xfb496c: mov             x8, #0
    // 0xfb4970: r7 = 0
    //     0xfb4970: mov             x7, #0
    // 0xfb4974: ldur            x5, [fp, #-0x28]
    // 0xfb4978: ldur            x6, [fp, #-0x10]
    // 0xfb497c: ldur            x4, [fp, #-0x30]
    // 0xfb4980: stur            x9, [fp, #-0x20]
    // 0xfb4984: stur            x8, [fp, #-0x38]
    // 0xfb4988: stur            x7, [fp, #-0x48]
    // 0xfb498c: CheckStackOverflow
    //     0xfb498c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb4990: cmp             SP, x16
    //     0xfb4994: b.ls            #0xfb4fe0
    // 0xfb4998: LoadField: r0 = r6->field_b
    //     0xfb4998: ldur            w0, [x6, #0xb]
    // 0xfb499c: r10 = LoadInt32Instr(r0)
    //     0xfb499c: sbfx            x10, x0, #1, #0x1f
    // 0xfb49a0: cmp             x7, x10
    // 0xfb49a4: b.ge            #0xfb4ee8
    // 0xfb49a8: mov             x0, x10
    // 0xfb49ac: mov             x1, x7
    // 0xfb49b0: cmp             x1, x0
    // 0xfb49b4: b.hs            #0xfb4fe8
    // 0xfb49b8: LoadField: r0 = r6->field_f
    //     0xfb49b8: ldur            w0, [x6, #0xf]
    // 0xfb49bc: DecompressPointer r0
    //     0xfb49bc: add             x0, x0, HEAP, lsl #32
    // 0xfb49c0: ArrayLoad: r1 = r0[r7]  ; Unknown_4
    //     0xfb49c0: add             x16, x0, x7, lsl #2
    //     0xfb49c4: ldur            w1, [x16, #0xf]
    // 0xfb49c8: DecompressPointer r1
    //     0xfb49c8: add             x1, x1, HEAP, lsl #32
    // 0xfb49cc: mov             x0, x1
    // 0xfb49d0: stur            x1, [fp, #-0x18]
    // 0xfb49d4: StoreField: r9->field_13 = r0
    //     0xfb49d4: stur            w0, [x9, #0x13]
    //     0xfb49d8: ldurb           w16, [x9, #-1]
    //     0xfb49dc: ldurb           w17, [x0, #-1]
    //     0xfb49e0: and             x16, x17, x16, lsr #2
    //     0xfb49e4: tst             x16, HEAP, lsr #32
    //     0xfb49e8: b.eq            #0xfb49f0
    //     0xfb49ec: bl              #0x13de094  ; WriteBarrierWrappersStub
    // 0xfb49f0: cbnz            x7, #0xfb49fc
    // 0xfb49f4: ldur            d0, [fp, #-0x88]
    // 0xfb49f8: b               #0xfb4a00
    // 0xfb49fc: d0 = 10.000000
    //     0xfb49fc: fmov            d0, #10.00000000
    // 0xfb4a00: stur            d0, [fp, #-0x98]
    // 0xfb4a04: sub             x0, x10, #1
    // 0xfb4a08: cmp             x7, x0
    // 0xfb4a0c: b.ne            #0xfb4a18
    // 0xfb4a10: ldur            d1, [fp, #-0x88]
    // 0xfb4a14: b               #0xfb4a1c
    // 0xfb4a18: d1 = 10.000000
    //     0xfb4a18: fmov            d1, #10.00000000
    // 0xfb4a1c: stur            d1, [fp, #-0x90]
    // 0xfb4a20: r0 = EdgeInsetsDirectional()
    //     0xfb4a20: bl              #0xb50060  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xfb4a24: mov             x3, x0
    // 0xfb4a28: ldur            d0, [fp, #-0x98]
    // 0xfb4a2c: stur            x3, [fp, #-0x60]
    // 0xfb4a30: StoreField: r3->field_7 = d0
    //     0xfb4a30: stur            d0, [x3, #7]
    // 0xfb4a34: StoreField: r3->field_f = rZR
    //     0xfb4a34: stur            xzr, [x3, #0xf]
    // 0xfb4a38: ldur            d0, [fp, #-0x90]
    // 0xfb4a3c: ArrayStore: r3[0] = d0  ; List_8
    //     0xfb4a3c: stur            d0, [x3, #0x17]
    // 0xfb4a40: StoreField: r3->field_1f = rZR
    //     0xfb4a40: stur            xzr, [x3, #0x1f]
    // 0xfb4a44: ldur            x2, [fp, #-0x48]
    // 0xfb4a48: r0 = BoxInt64Instr(r2)
    //     0xfb4a48: sbfiz           x0, x2, #1, #0x1f
    //     0xfb4a4c: cmp             x2, x0, asr #1
    //     0xfb4a50: b.eq            #0xfb4a5c
    //     0xfb4a54: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xfb4a58: stur            x2, [x0, #7]
    // 0xfb4a5c: ldur            x4, [fp, #-0x40]
    // 0xfb4a60: cmp             w0, w4
    // 0xfb4a64: b.eq            #0xfb4aa0
    // 0xfb4a68: and             w16, w0, w4
    // 0xfb4a6c: branchIfSmi(r16, 0xfb4b34)
    //     0xfb4a6c: tbz             w16, #0, #0xfb4b34
    // 0xfb4a70: r16 = LoadClassIdInstr(r0)
    //     0xfb4a70: ldur            x16, [x0, #-1]
    //     0xfb4a74: ubfx            x16, x16, #0xc, #0x14
    // 0xfb4a78: cmp             x16, #0x3d
    // 0xfb4a7c: b.ne            #0xfb4b34
    // 0xfb4a80: r16 = LoadClassIdInstr(r4)
    //     0xfb4a80: ldur            x16, [x4, #-1]
    //     0xfb4a84: ubfx            x16, x16, #0xc, #0x14
    // 0xfb4a88: cmp             x16, #0x3d
    // 0xfb4a8c: b.ne            #0xfb4b34
    // 0xfb4a90: LoadField: r16 = r0->field_7
    //     0xfb4a90: ldur            x16, [x0, #7]
    // 0xfb4a94: LoadField: r17 = r4->field_7
    //     0xfb4a94: ldur            x17, [x4, #7]
    // 0xfb4a98: cmp             x16, x17
    // 0xfb4a9c: b.ne            #0xfb4b34
    // 0xfb4aa0: ldur            x6, [fp, #-0x20]
    // 0xfb4aa4: ldur            x5, [fp, #-0x38]
    // 0xfb4aa8: LoadField: r7 = r6->field_b
    //     0xfb4aa8: ldur            w7, [x6, #0xb]
    // 0xfb4aac: DecompressPointer r7
    //     0xfb4aac: add             x7, x7, HEAP, lsl #32
    // 0xfb4ab0: stur            x7, [fp, #-0x58]
    // 0xfb4ab4: LoadField: r8 = r7->field_33
    //     0xfb4ab4: ldur            w8, [x7, #0x33]
    // 0xfb4ab8: DecompressPointer r8
    //     0xfb4ab8: add             x8, x8, HEAP, lsl #32
    // 0xfb4abc: stur            x8, [fp, #-0x50]
    // 0xfb4ac0: LoadField: r2 = r8->field_7
    //     0xfb4ac0: ldur            w2, [x8, #7]
    // 0xfb4ac4: DecompressPointer r2
    //     0xfb4ac4: add             x2, x2, HEAP, lsl #32
    // 0xfb4ac8: r0 = Instance_IntrinsicColumnWidth
    //     0xfb4ac8: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8ff88] Obj!IntrinsicColumnWidth@129ee01
    //     0xfb4acc: ldr             x0, [x0, #0xf88]
    // 0xfb4ad0: r1 = Null
    //     0xfb4ad0: mov             x1, NULL
    // 0xfb4ad4: cmp             w2, NULL
    // 0xfb4ad8: b.eq            #0xfb4af8
    // 0xfb4adc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xfb4adc: ldur            w4, [x2, #0x17]
    // 0xfb4ae0: DecompressPointer r4
    //     0xfb4ae0: add             x4, x4, HEAP, lsl #32
    // 0xfb4ae4: r8 = X0
    //     0xfb4ae4: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xfb4ae8: LoadField: r9 = r4->field_7
    //     0xfb4ae8: ldur            x9, [x4, #7]
    // 0xfb4aec: r3 = Null
    //     0xfb4aec: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8ff90] Null
    //     0xfb4af0: ldr             x3, [x3, #0xf90]
    // 0xfb4af4: blr             x9
    // 0xfb4af8: ldur            x2, [fp, #-0x50]
    // 0xfb4afc: LoadField: r0 = r2->field_b
    //     0xfb4afc: ldur            w0, [x2, #0xb]
    // 0xfb4b00: r1 = LoadInt32Instr(r0)
    //     0xfb4b00: sbfx            x1, x0, #1, #0x1f
    // 0xfb4b04: mov             x0, x1
    // 0xfb4b08: ldur            x1, [fp, #-0x38]
    // 0xfb4b0c: cmp             x1, x0
    // 0xfb4b10: b.hs            #0xfb4fec
    // 0xfb4b14: ldur            x3, [fp, #-0x38]
    // 0xfb4b18: add             x0, x2, x3, lsl #2
    // 0xfb4b1c: r16 = Instance_IntrinsicColumnWidth
    //     0xfb4b1c: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8ff88] Obj!IntrinsicColumnWidth@129ee01
    //     0xfb4b20: ldr             x16, [x16, #0xf88]
    // 0xfb4b24: StoreField: r0->field_f = r16
    //     0xfb4b24: stur            w16, [x0, #0xf]
    // 0xfb4b28: ldur            x6, [fp, #-0x58]
    // 0xfb4b2c: mov             x0, x3
    // 0xfb4b30: b               #0xfb4bc0
    // 0xfb4b34: ldur            x5, [fp, #-0x20]
    // 0xfb4b38: ldur            x3, [fp, #-0x38]
    // 0xfb4b3c: LoadField: r4 = r5->field_b
    //     0xfb4b3c: ldur            w4, [x5, #0xb]
    // 0xfb4b40: DecompressPointer r4
    //     0xfb4b40: add             x4, x4, HEAP, lsl #32
    // 0xfb4b44: stur            x4, [fp, #-0x58]
    // 0xfb4b48: LoadField: r6 = r4->field_33
    //     0xfb4b48: ldur            w6, [x4, #0x33]
    // 0xfb4b4c: DecompressPointer r6
    //     0xfb4b4c: add             x6, x6, HEAP, lsl #32
    // 0xfb4b50: stur            x6, [fp, #-0x50]
    // 0xfb4b54: LoadField: r2 = r6->field_7
    //     0xfb4b54: ldur            w2, [x6, #7]
    // 0xfb4b58: DecompressPointer r2
    //     0xfb4b58: add             x2, x2, HEAP, lsl #32
    // 0xfb4b5c: r0 = Instance_IntrinsicColumnWidth
    //     0xfb4b5c: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8ffa0] Obj!IntrinsicColumnWidth@129edf1
    //     0xfb4b60: ldr             x0, [x0, #0xfa0]
    // 0xfb4b64: r1 = Null
    //     0xfb4b64: mov             x1, NULL
    // 0xfb4b68: cmp             w2, NULL
    // 0xfb4b6c: b.eq            #0xfb4b8c
    // 0xfb4b70: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xfb4b70: ldur            w4, [x2, #0x17]
    // 0xfb4b74: DecompressPointer r4
    //     0xfb4b74: add             x4, x4, HEAP, lsl #32
    // 0xfb4b78: r8 = X0
    //     0xfb4b78: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xfb4b7c: LoadField: r9 = r4->field_7
    //     0xfb4b7c: ldur            x9, [x4, #7]
    // 0xfb4b80: r3 = Null
    //     0xfb4b80: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8ffa8] Null
    //     0xfb4b84: ldr             x3, [x3, #0xfa8]
    // 0xfb4b88: blr             x9
    // 0xfb4b8c: ldur            x2, [fp, #-0x50]
    // 0xfb4b90: LoadField: r0 = r2->field_b
    //     0xfb4b90: ldur            w0, [x2, #0xb]
    // 0xfb4b94: r1 = LoadInt32Instr(r0)
    //     0xfb4b94: sbfx            x1, x0, #1, #0x1f
    // 0xfb4b98: mov             x0, x1
    // 0xfb4b9c: ldur            x1, [fp, #-0x38]
    // 0xfb4ba0: cmp             x1, x0
    // 0xfb4ba4: b.hs            #0xfb4ff0
    // 0xfb4ba8: ldur            x0, [fp, #-0x38]
    // 0xfb4bac: add             x1, x2, x0, lsl #2
    // 0xfb4bb0: r16 = Instance_IntrinsicColumnWidth
    //     0xfb4bb0: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8ffa0] Obj!IntrinsicColumnWidth@129edf1
    //     0xfb4bb4: ldr             x16, [x16, #0xfa0]
    // 0xfb4bb8: StoreField: r1->field_f = r16
    //     0xfb4bb8: stur            w16, [x1, #0xf]
    // 0xfb4bbc: ldur            x6, [fp, #-0x58]
    // 0xfb4bc0: ldur            x3, [fp, #-0x28]
    // 0xfb4bc4: ldur            x5, [fp, #-0x20]
    // 0xfb4bc8: ldur            x2, [fp, #-0x30]
    // 0xfb4bcc: ldur            x4, [fp, #-0x18]
    // 0xfb4bd0: stur            x6, [fp, #-0x50]
    // 0xfb4bd4: r1 = <WidgetState>
    //     0xfb4bd4: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a10] TypeArguments: <WidgetState>
    //     0xfb4bd8: ldr             x1, [x1, #0xa10]
    // 0xfb4bdc: r0 = _Set()
    //     0xfb4bdc: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xfb4be0: mov             x1, x0
    // 0xfb4be4: r0 = _Uint32List
    //     0xfb4be4: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0xfb4be8: stur            x1, [fp, #-0x58]
    // 0xfb4bec: StoreField: r1->field_1b = r0
    //     0xfb4bec: stur            w0, [x1, #0x1b]
    // 0xfb4bf0: StoreField: r1->field_b = rZR
    //     0xfb4bf0: stur            wzr, [x1, #0xb]
    // 0xfb4bf4: r2 = const []
    //     0xfb4bf4: ldr             x2, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0xfb4bf8: StoreField: r1->field_f = r2
    //     0xfb4bf8: stur            w2, [x1, #0xf]
    // 0xfb4bfc: StoreField: r1->field_13 = rZR
    //     0xfb4bfc: stur            wzr, [x1, #0x13]
    // 0xfb4c00: ArrayStore: r1[0] = rZR  ; List_4
    //     0xfb4c00: stur            wzr, [x1, #0x17]
    // 0xfb4c04: r16 = Instance_WidgetState
    //     0xfb4c04: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xfb4c08: ldr             x16, [x16, #0xa70]
    // 0xfb4c0c: str             x16, [SP]
    // 0xfb4c10: r0 = _getHash()
    //     0xfb4c10: bl              #0x84c644  ; [dart:core] ::_getHash
    // 0xfb4c14: r3 = LoadInt32Instr(r0)
    //     0xfb4c14: sbfx            x3, x0, #1, #0x1f
    // 0xfb4c18: ldur            x1, [fp, #-0x58]
    // 0xfb4c1c: r2 = Instance_WidgetState
    //     0xfb4c1c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xfb4c20: ldr             x2, [x2, #0xa70]
    // 0xfb4c24: r0 = _add()
    //     0xfb4c24: bl              #0x84ba3c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_add
    // 0xfb4c28: ldur            x2, [fp, #-0x30]
    // 0xfb4c2c: LoadField: r0 = r2->field_b
    //     0xfb4c2c: ldur            w0, [x2, #0xb]
    // 0xfb4c30: r1 = LoadInt32Instr(r0)
    //     0xfb4c30: sbfx            x1, x0, #1, #0x1f
    // 0xfb4c34: mov             x0, x1
    // 0xfb4c38: r1 = 0
    //     0xfb4c38: mov             x1, #0
    // 0xfb4c3c: cmp             x1, x0
    // 0xfb4c40: b.hs            #0xfb4ff4
    // 0xfb4c44: LoadField: r0 = r2->field_f
    //     0xfb4c44: ldur            w0, [x2, #0xf]
    // 0xfb4c48: DecompressPointer r0
    //     0xfb4c48: add             x0, x0, HEAP, lsl #32
    // 0xfb4c4c: LoadField: r1 = r0->field_f
    //     0xfb4c4c: ldur            w1, [x0, #0xf]
    // 0xfb4c50: DecompressPointer r1
    //     0xfb4c50: add             x1, x1, HEAP, lsl #32
    // 0xfb4c54: LoadField: r0 = r1->field_f
    //     0xfb4c54: ldur            w0, [x1, #0xf]
    // 0xfb4c58: DecompressPointer r0
    //     0xfb4c58: add             x0, x0, HEAP, lsl #32
    // 0xfb4c5c: ldur            x1, [fp, #-0x50]
    // 0xfb4c60: stur            x0, [fp, #-0x70]
    // 0xfb4c64: LoadField: r3 = r1->field_13
    //     0xfb4c64: ldur            w3, [x1, #0x13]
    // 0xfb4c68: DecompressPointer r3
    //     0xfb4c68: add             x3, x3, HEAP, lsl #32
    // 0xfb4c6c: ldur            x4, [fp, #-0x18]
    // 0xfb4c70: stur            x3, [fp, #-0x68]
    // 0xfb4c74: LoadField: r5 = r4->field_7
    //     0xfb4c74: ldur            w5, [x4, #7]
    // 0xfb4c78: DecompressPointer r5
    //     0xfb4c78: add             x5, x5, HEAP, lsl #32
    // 0xfb4c7c: ldur            x4, [fp, #-0x20]
    // 0xfb4c80: stur            x5, [fp, #-0x58]
    // 0xfb4c84: LoadField: r6 = r4->field_f
    //     0xfb4c84: ldur            w6, [x4, #0xf]
    // 0xfb4c88: DecompressPointer r6
    //     0xfb4c88: add             x6, x6, HEAP, lsl #32
    // 0xfb4c8c: stp             NULL, x6, [SP]
    // 0xfb4c90: r0 = ==()
    //     0xfb4c90: bl              #0x12b7d64  ; [dart:core] _IntegerImplementation::==
    // 0xfb4c94: ldur            x1, [fp, #-8]
    // 0xfb4c98: ldur            x2, [fp, #-0x68]
    // 0xfb4c9c: ldur            x3, [fp, #-0x58]
    // 0xfb4ca0: ldur            x5, [fp, #-0x60]
    // 0xfb4ca4: r0 = _buildHeadingCell()
    //     0xfb4ca4: bl              #0xfb5324  ; [package:flutter/src/material/data_table.dart] DataTable::_buildHeadingCell
    // 0xfb4ca8: mov             x3, x0
    // 0xfb4cac: ldur            x2, [fp, #-0x70]
    // 0xfb4cb0: LoadField: r0 = r2->field_b
    //     0xfb4cb0: ldur            w0, [x2, #0xb]
    // 0xfb4cb4: r1 = LoadInt32Instr(r0)
    //     0xfb4cb4: sbfx            x1, x0, #1, #0x1f
    // 0xfb4cb8: mov             x0, x1
    // 0xfb4cbc: ldur            x1, [fp, #-0x38]
    // 0xfb4cc0: cmp             x1, x0
    // 0xfb4cc4: b.hs            #0xfb4ff8
    // 0xfb4cc8: mov             x1, x2
    // 0xfb4ccc: mov             x0, x3
    // 0xfb4cd0: ldur            x4, [fp, #-0x38]
    // 0xfb4cd4: ArrayStore: r1[r4] = r0  ; List_4
    //     0xfb4cd4: add             x25, x1, x4, lsl #2
    //     0xfb4cd8: add             x25, x25, #0xf
    //     0xfb4cdc: str             w0, [x25]
    //     0xfb4ce0: tbz             w0, #0, #0xfb4cfc
    //     0xfb4ce4: ldurb           w16, [x1, #-1]
    //     0xfb4ce8: ldurb           w17, [x0, #-1]
    //     0xfb4cec: and             x16, x17, x16, lsr #2
    //     0xfb4cf0: tst             x16, HEAP, lsr #32
    //     0xfb4cf4: b.eq            #0xfb4cfc
    //     0xfb4cf8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfb4cfc: ldur            x6, [fp, #-0x28]
    // 0xfb4d00: LoadField: r0 = r6->field_b
    //     0xfb4d00: ldur            w0, [x6, #0xb]
    // 0xfb4d04: r7 = LoadInt32Instr(r0)
    //     0xfb4d04: sbfx            x7, x0, #1, #0x1f
    // 0xfb4d08: stur            x7, [fp, #-0x80]
    // 0xfb4d0c: r0 = 0
    //     0xfb4d0c: mov             x0, #0
    // 0xfb4d10: r11 = 1
    //     0xfb4d10: mov             x11, #1
    // 0xfb4d14: ldur            x10, [fp, #-0x20]
    // 0xfb4d18: ldur            x8, [fp, #-0x30]
    // 0xfb4d1c: ldur            x9, [fp, #-0x50]
    // 0xfb4d20: stur            x11, [fp, #-0x78]
    // 0xfb4d24: CheckStackOverflow
    //     0xfb4d24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb4d28: cmp             SP, x16
    //     0xfb4d2c: b.ls            #0xfb4ffc
    // 0xfb4d30: LoadField: r1 = r6->field_b
    //     0xfb4d30: ldur            w1, [x6, #0xb]
    // 0xfb4d34: r2 = LoadInt32Instr(r1)
    //     0xfb4d34: sbfx            x2, x1, #1, #0x1f
    // 0xfb4d38: cmp             x7, x2
    // 0xfb4d3c: b.ne            #0xfb4fac
    // 0xfb4d40: cmp             x0, x2
    // 0xfb4d44: b.ge            #0xfb4e70
    // 0xfb4d48: LoadField: r1 = r6->field_f
    //     0xfb4d48: ldur            w1, [x6, #0xf]
    // 0xfb4d4c: DecompressPointer r1
    //     0xfb4d4c: add             x1, x1, HEAP, lsl #32
    // 0xfb4d50: ArrayLoad: r2 = r1[r0]  ; Unknown_4
    //     0xfb4d50: add             x16, x1, x0, lsl #2
    //     0xfb4d54: ldur            w2, [x16, #0xf]
    // 0xfb4d58: DecompressPointer r2
    //     0xfb4d58: add             x2, x2, HEAP, lsl #32
    // 0xfb4d5c: add             x12, x0, #1
    // 0xfb4d60: stur            x12, [fp, #-0x48]
    // 0xfb4d64: LoadField: r3 = r2->field_1b
    //     0xfb4d64: ldur            w3, [x2, #0x1b]
    // 0xfb4d68: DecompressPointer r3
    //     0xfb4d68: add             x3, x3, HEAP, lsl #32
    // 0xfb4d6c: LoadField: r0 = r10->field_f
    //     0xfb4d6c: ldur            w0, [x10, #0xf]
    // 0xfb4d70: DecompressPointer r0
    //     0xfb4d70: add             x0, x0, HEAP, lsl #32
    // 0xfb4d74: LoadField: r1 = r3->field_b
    //     0xfb4d74: ldur            w1, [x3, #0xb]
    // 0xfb4d78: r2 = LoadInt32Instr(r0)
    //     0xfb4d78: sbfx            x2, x0, #1, #0x1f
    //     0xfb4d7c: tbz             w0, #0, #0xfb4d84
    //     0xfb4d80: ldur            x2, [x0, #7]
    // 0xfb4d84: r0 = LoadInt32Instr(r1)
    //     0xfb4d84: sbfx            x0, x1, #1, #0x1f
    // 0xfb4d88: mov             x1, x2
    // 0xfb4d8c: cmp             x1, x0
    // 0xfb4d90: b.hs            #0xfb5004
    // 0xfb4d94: LoadField: r0 = r3->field_f
    //     0xfb4d94: ldur            w0, [x3, #0xf]
    // 0xfb4d98: DecompressPointer r0
    //     0xfb4d98: add             x0, x0, HEAP, lsl #32
    // 0xfb4d9c: ArrayLoad: r3 = r0[r2]  ; Unknown_4
    //     0xfb4d9c: add             x16, x0, x2, lsl #2
    //     0xfb4da0: ldur            w3, [x16, #0xf]
    // 0xfb4da4: DecompressPointer r3
    //     0xfb4da4: add             x3, x3, HEAP, lsl #32
    // 0xfb4da8: LoadField: r0 = r8->field_b
    //     0xfb4da8: ldur            w0, [x8, #0xb]
    // 0xfb4dac: r1 = LoadInt32Instr(r0)
    //     0xfb4dac: sbfx            x1, x0, #1, #0x1f
    // 0xfb4db0: mov             x0, x1
    // 0xfb4db4: mov             x1, x11
    // 0xfb4db8: cmp             x1, x0
    // 0xfb4dbc: b.hs            #0xfb5008
    // 0xfb4dc0: LoadField: r0 = r8->field_f
    //     0xfb4dc0: ldur            w0, [x8, #0xf]
    // 0xfb4dc4: DecompressPointer r0
    //     0xfb4dc4: add             x0, x0, HEAP, lsl #32
    // 0xfb4dc8: ArrayLoad: r1 = r0[r11]  ; Unknown_4
    //     0xfb4dc8: add             x16, x0, x11, lsl #2
    //     0xfb4dcc: ldur            w1, [x16, #0xf]
    // 0xfb4dd0: DecompressPointer r1
    //     0xfb4dd0: add             x1, x1, HEAP, lsl #32
    // 0xfb4dd4: LoadField: r0 = r1->field_f
    //     0xfb4dd4: ldur            w0, [x1, #0xf]
    // 0xfb4dd8: DecompressPointer r0
    //     0xfb4dd8: add             x0, x0, HEAP, lsl #32
    // 0xfb4ddc: stur            x0, [fp, #-0x18]
    // 0xfb4de0: LoadField: r2 = r9->field_13
    //     0xfb4de0: ldur            w2, [x9, #0x13]
    // 0xfb4de4: DecompressPointer r2
    //     0xfb4de4: add             x2, x2, HEAP, lsl #32
    // 0xfb4de8: LoadField: r1 = r3->field_7
    //     0xfb4de8: ldur            w1, [x3, #7]
    // 0xfb4dec: DecompressPointer r1
    //     0xfb4dec: add             x1, x1, HEAP, lsl #32
    // 0xfb4df0: mov             x3, x1
    // 0xfb4df4: ldur            x1, [fp, #-8]
    // 0xfb4df8: ldur            x5, [fp, #-0x60]
    // 0xfb4dfc: r0 = _buildDataCell()
    //     0xfb4dfc: bl              #0xfb513c  ; [package:flutter/src/material/data_table.dart] DataTable::_buildDataCell
    // 0xfb4e00: mov             x3, x0
    // 0xfb4e04: ldur            x2, [fp, #-0x18]
    // 0xfb4e08: LoadField: r0 = r2->field_b
    //     0xfb4e08: ldur            w0, [x2, #0xb]
    // 0xfb4e0c: r1 = LoadInt32Instr(r0)
    //     0xfb4e0c: sbfx            x1, x0, #1, #0x1f
    // 0xfb4e10: mov             x0, x1
    // 0xfb4e14: ldur            x1, [fp, #-0x38]
    // 0xfb4e18: cmp             x1, x0
    // 0xfb4e1c: b.hs            #0xfb500c
    // 0xfb4e20: mov             x1, x2
    // 0xfb4e24: mov             x0, x3
    // 0xfb4e28: ldur            x2, [fp, #-0x38]
    // 0xfb4e2c: ArrayStore: r1[r2] = r0  ; List_4
    //     0xfb4e2c: add             x25, x1, x2, lsl #2
    //     0xfb4e30: add             x25, x25, #0xf
    //     0xfb4e34: str             w0, [x25]
    //     0xfb4e38: tbz             w0, #0, #0xfb4e54
    //     0xfb4e3c: ldurb           w16, [x1, #-1]
    //     0xfb4e40: ldurb           w17, [x0, #-1]
    //     0xfb4e44: and             x16, x17, x16, lsr #2
    //     0xfb4e48: tst             x16, HEAP, lsr #32
    //     0xfb4e4c: b.eq            #0xfb4e54
    //     0xfb4e50: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfb4e54: ldur            x0, [fp, #-0x78]
    // 0xfb4e58: add             x11, x0, #1
    // 0xfb4e5c: ldur            x0, [fp, #-0x48]
    // 0xfb4e60: ldur            x6, [fp, #-0x28]
    // 0xfb4e64: mov             x4, x2
    // 0xfb4e68: ldur            x7, [fp, #-0x80]
    // 0xfb4e6c: b               #0xfb4d14
    // 0xfb4e70: mov             x2, x4
    // 0xfb4e74: add             x8, x2, #1
    // 0xfb4e78: ldur            x5, [fp, #-0x20]
    // 0xfb4e7c: stur            x8, [fp, #-0x48]
    // 0xfb4e80: r0 = CloneContext()
    //     0xfb4e80: bl              #0x13de1f4  ; CloneContextStub
    // 0xfb4e84: mov             x2, x0
    // 0xfb4e88: LoadField: r0 = r2->field_f
    //     0xfb4e88: ldur            w0, [x2, #0xf]
    // 0xfb4e8c: DecompressPointer r0
    //     0xfb4e8c: add             x0, x0, HEAP, lsl #32
    // 0xfb4e90: r1 = LoadInt32Instr(r0)
    //     0xfb4e90: sbfx            x1, x0, #1, #0x1f
    //     0xfb4e94: tbz             w0, #0, #0xfb4e9c
    //     0xfb4e98: ldur            x1, [x0, #7]
    // 0xfb4e9c: add             x7, x1, #1
    // 0xfb4ea0: r0 = BoxInt64Instr(r7)
    //     0xfb4ea0: sbfiz           x0, x7, #1, #0x1f
    //     0xfb4ea4: cmp             x7, x0, asr #1
    //     0xfb4ea8: b.eq            #0xfb4eb4
    //     0xfb4eac: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xfb4eb0: stur            x7, [x0, #7]
    // 0xfb4eb4: StoreField: r2->field_f = r0
    //     0xfb4eb4: stur            w0, [x2, #0xf]
    //     0xfb4eb8: tbz             w0, #0, #0xfb4ed4
    //     0xfb4ebc: ldurb           w16, [x2, #-1]
    //     0xfb4ec0: ldurb           w17, [x0, #-1]
    //     0xfb4ec4: and             x16, x17, x16, lsr #2
    //     0xfb4ec8: tst             x16, HEAP, lsr #32
    //     0xfb4ecc: b.eq            #0xfb4ed4
    //     0xfb4ed0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfb4ed4: mov             x9, x2
    // 0xfb4ed8: ldur            x8, [fp, #-0x48]
    // 0xfb4edc: ldur            x2, [fp, #-8]
    // 0xfb4ee0: ldur            x3, [fp, #-0x40]
    // 0xfb4ee4: b               #0xfb4974
    // 0xfb4ee8: mov             x1, x2
    // 0xfb4eec: mov             x0, x9
    // 0xfb4ef0: LoadField: r2 = r0->field_b
    //     0xfb4ef0: ldur            w2, [x0, #0xb]
    // 0xfb4ef4: DecompressPointer r2
    //     0xfb4ef4: add             x2, x2, HEAP, lsl #32
    // 0xfb4ef8: LoadField: r0 = r1->field_1b
    //     0xfb4ef8: ldur            w0, [x1, #0x1b]
    // 0xfb4efc: DecompressPointer r0
    //     0xfb4efc: add             x0, x0, HEAP, lsl #32
    // 0xfb4f00: stur            x0, [fp, #-0x10]
    // 0xfb4f04: LoadField: r1 = r2->field_33
    //     0xfb4f04: ldur            w1, [x2, #0x33]
    // 0xfb4f08: DecompressPointer r1
    //     0xfb4f08: add             x1, x1, HEAP, lsl #32
    // 0xfb4f0c: r0 = asMap()
    //     0xfb4f0c: bl              #0xb563dc  ; [dart:collection] ListBase::asMap
    // 0xfb4f10: stur            x0, [fp, #-8]
    // 0xfb4f14: r0 = Table()
    //     0xfb4f14: bl              #0xfb5130  ; AllocateTableStub -> Table (size=0x2c)
    // 0xfb4f18: mov             x1, x0
    // 0xfb4f1c: ldur            x2, [fp, #-0x30]
    // 0xfb4f20: ldur            x3, [fp, #-8]
    // 0xfb4f24: stur            x0, [fp, #-8]
    // 0xfb4f28: r0 = Table()
    //     0xfb4f28: bl              #0xfb5010  ; [package:flutter/src/widgets/table.dart] Table::Table
    // 0xfb4f2c: r0 = Material()
    //     0xfb4f2c: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xfb4f30: mov             x1, x0
    // 0xfb4f34: r0 = Instance_MaterialType
    //     0xfb4f34: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8c618] Obj!MaterialType@12c5361
    //     0xfb4f38: ldr             x0, [x0, #0x618]
    // 0xfb4f3c: stur            x1, [fp, #-0x18]
    // 0xfb4f40: StoreField: r1->field_f = r0
    //     0xfb4f40: stur            w0, [x1, #0xf]
    // 0xfb4f44: ArrayStore: r1[0] = rZR  ; List_8
    //     0xfb4f44: stur            xzr, [x1, #0x17]
    // 0xfb4f48: r0 = true
    //     0xfb4f48: add             x0, NULL, #0x20  ; true
    // 0xfb4f4c: StoreField: r1->field_33 = r0
    //     0xfb4f4c: stur            w0, [x1, #0x33]
    // 0xfb4f50: r0 = Instance_Clip
    //     0xfb4f50: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb4f54: ldr             x0, [x0, #0x840]
    // 0xfb4f58: StoreField: r1->field_37 = r0
    //     0xfb4f58: stur            w0, [x1, #0x37]
    // 0xfb4f5c: r0 = Instance_Duration
    //     0xfb4f5c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xfb4f60: ldr             x0, [x0, #0x318]
    // 0xfb4f64: StoreField: r1->field_3b = r0
    //     0xfb4f64: stur            w0, [x1, #0x3b]
    // 0xfb4f68: ldur            x0, [fp, #-8]
    // 0xfb4f6c: StoreField: r1->field_b = r0
    //     0xfb4f6c: stur            w0, [x1, #0xb]
    // 0xfb4f70: r0 = false
    //     0xfb4f70: add             x0, NULL, #0x30  ; false
    // 0xfb4f74: StoreField: r1->field_13 = r0
    //     0xfb4f74: stur            w0, [x1, #0x13]
    // 0xfb4f78: r0 = Container()
    //     0xfb4f78: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xfb4f7c: stur            x0, [fp, #-8]
    // 0xfb4f80: ldur            x16, [fp, #-0x10]
    // 0xfb4f84: ldur            lr, [fp, #-0x18]
    // 0xfb4f88: stp             lr, x16, [SP]
    // 0xfb4f8c: mov             x1, x0
    // 0xfb4f90: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0xfb4f90: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1eab8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0xfb4f94: ldr             x4, [x4, #0xab8]
    // 0xfb4f98: r0 = Container()
    //     0xfb4f98: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xfb4f9c: ldur            x0, [fp, #-8]
    // 0xfb4fa0: LeaveFrame
    //     0xfb4fa0: mov             SP, fp
    //     0xfb4fa4: ldp             fp, lr, [SP], #0x10
    // 0xfb4fa8: ret
    //     0xfb4fa8: ret             
    // 0xfb4fac: mov             x0, x6
    // 0xfb4fb0: r0 = ConcurrentModificationError()
    //     0xfb4fb0: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xfb4fb4: mov             x1, x0
    // 0xfb4fb8: ldur            x0, [fp, #-0x28]
    // 0xfb4fbc: StoreField: r1->field_b = r0
    //     0xfb4fbc: stur            w0, [x1, #0xb]
    // 0xfb4fc0: mov             x0, x1
    // 0xfb4fc4: r0 = Throw()
    //     0xfb4fc4: bl              #0x13ddb2c  ; ThrowStub
    // 0xfb4fc8: brk             #0
    // 0xfb4fcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb4fcc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb4fd0: b               #0xfb4634
    // 0xfb4fd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb4fd4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb4fd8: b               #0xfb4868
    // 0xfb4fdc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfb4fdc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xfb4fe0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb4fe0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb4fe4: b               #0xfb4998
    // 0xfb4fe8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfb4fe8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xfb4fec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfb4fec: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xfb4ff0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfb4ff0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xfb4ff4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfb4ff4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xfb4ff8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfb4ff8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xfb4ffc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb4ffc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb5000: b               #0xfb4d30
    // 0xfb5004: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfb5004: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xfb5008: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfb5008: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xfb500c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfb500c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _buildDataCell(/* No info */) {
    // ** addr: 0xfb513c, size: 0x1dc
    // 0xfb513c: EnterFrame
    //     0xfb513c: stp             fp, lr, [SP, #-0x10]!
    //     0xfb5140: mov             fp, SP
    // 0xfb5144: AllocStack(0x58)
    //     0xfb5144: sub             SP, SP, #0x58
    // 0xfb5148: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */)
    //     0xfb5148: mov             x0, x2
    //     0xfb514c: stur            x2, [fp, #-8]
    //     0xfb5150: stur            x3, [fp, #-0x10]
    //     0xfb5154: stur            x5, [fp, #-0x18]
    // 0xfb5158: CheckStackOverflow
    //     0xfb5158: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb515c: cmp             SP, x16
    //     0xfb5160: b.ls            #0xfb530c
    // 0xfb5164: mov             x1, x0
    // 0xfb5168: r0 = of()
    //     0xfb5168: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb516c: ldur            x1, [fp, #-8]
    // 0xfb5170: stur            x0, [fp, #-0x20]
    // 0xfb5174: r0 = of()
    //     0xfb5174: bl              #0xfb561c  ; [package:flutter/src/material/data_table_theme.dart] DataTableTheme::of
    // 0xfb5178: mov             x1, x0
    // 0xfb517c: ldur            x0, [fp, #-0x20]
    // 0xfb5180: LoadField: r2 = r0->field_87
    //     0xfb5180: ldur            w2, [x0, #0x87]
    // 0xfb5184: DecompressPointer r2
    //     0xfb5184: add             x2, x2, HEAP, lsl #32
    // 0xfb5188: LoadField: r3 = r2->field_2f
    //     0xfb5188: ldur            w3, [x2, #0x2f]
    // 0xfb518c: DecompressPointer r3
    //     0xfb518c: add             x3, x3, HEAP, lsl #32
    // 0xfb5190: stur            x3, [fp, #-0x28]
    // 0xfb5194: cmp             w3, NULL
    // 0xfb5198: b.eq            #0xfb5314
    // 0xfb519c: LoadField: r2 = r1->field_f
    //     0xfb519c: ldur            w2, [x1, #0xf]
    // 0xfb51a0: DecompressPointer r2
    //     0xfb51a0: add             x2, x2, HEAP, lsl #32
    // 0xfb51a4: cmp             w2, NULL
    // 0xfb51a8: b.ne            #0xfb51c0
    // 0xfb51ac: LoadField: r2 = r0->field_bf
    //     0xfb51ac: ldur            w2, [x0, #0xbf]
    // 0xfb51b0: DecompressPointer r2
    //     0xfb51b0: add             x2, x2, HEAP, lsl #32
    // 0xfb51b4: LoadField: r4 = r2->field_f
    //     0xfb51b4: ldur            w4, [x2, #0xf]
    // 0xfb51b8: DecompressPointer r4
    //     0xfb51b8: add             x4, x4, HEAP, lsl #32
    // 0xfb51bc: mov             x2, x4
    // 0xfb51c0: cmp             w2, NULL
    // 0xfb51c4: b.ne            #0xfb51d0
    // 0xfb51c8: d0 = 48.000000
    //     0xfb51c8: ldr             d0, [PP, #0x5650]  ; [pp+0x5650] IMM: double(48) from 0x4048000000000000
    // 0xfb51cc: b               #0xfb51d4
    // 0xfb51d0: LoadField: d0 = r2->field_7
    //     0xfb51d0: ldur            d0, [x2, #7]
    // 0xfb51d4: stur            d0, [fp, #-0x38]
    // 0xfb51d8: LoadField: r2 = r1->field_13
    //     0xfb51d8: ldur            w2, [x1, #0x13]
    // 0xfb51dc: DecompressPointer r2
    //     0xfb51dc: add             x2, x2, HEAP, lsl #32
    // 0xfb51e0: cmp             w2, NULL
    // 0xfb51e4: b.ne            #0xfb51fc
    // 0xfb51e8: LoadField: r1 = r0->field_bf
    //     0xfb51e8: ldur            w1, [x0, #0xbf]
    // 0xfb51ec: DecompressPointer r1
    //     0xfb51ec: add             x1, x1, HEAP, lsl #32
    // 0xfb51f0: LoadField: r0 = r1->field_13
    //     0xfb51f0: ldur            w0, [x1, #0x13]
    // 0xfb51f4: DecompressPointer r0
    //     0xfb51f4: add             x0, x0, HEAP, lsl #32
    // 0xfb51f8: b               #0xfb5200
    // 0xfb51fc: mov             x0, x2
    // 0xfb5200: cmp             w0, NULL
    // 0xfb5204: b.ne            #0xfb5210
    // 0xfb5208: d1 = 48.000000
    //     0xfb5208: ldr             d1, [PP, #0x5650]  ; [pp+0x5650] IMM: double(48) from 0x4048000000000000
    // 0xfb520c: b               #0xfb5214
    // 0xfb5210: LoadField: d1 = r0->field_7
    //     0xfb5210: ldur            d1, [x0, #7]
    // 0xfb5214: ldur            x0, [fp, #-0x10]
    // 0xfb5218: stur            d1, [fp, #-0x30]
    // 0xfb521c: r0 = BoxConstraints()
    //     0xfb521c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xfb5220: stur            x0, [fp, #-0x20]
    // 0xfb5224: StoreField: r0->field_7 = rZR
    //     0xfb5224: stur            xzr, [x0, #7]
    // 0xfb5228: d0 = inf
    //     0xfb5228: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xfb522c: StoreField: r0->field_f = d0
    //     0xfb522c: stur            d0, [x0, #0xf]
    // 0xfb5230: ldur            d0, [fp, #-0x38]
    // 0xfb5234: ArrayStore: r0[0] = d0  ; List_8
    //     0xfb5234: stur            d0, [x0, #0x17]
    // 0xfb5238: ldur            d0, [fp, #-0x30]
    // 0xfb523c: StoreField: r0->field_1f = d0
    //     0xfb523c: stur            d0, [x0, #0x1f]
    // 0xfb5240: ldur            x1, [fp, #-8]
    // 0xfb5244: r0 = of()
    //     0xfb5244: bl              #0xd0b128  ; [package:flutter/src/widgets/text.dart] DefaultTextStyle::of
    // 0xfb5248: LoadField: r1 = r0->field_f
    //     0xfb5248: ldur            w1, [x0, #0xf]
    // 0xfb524c: DecompressPointer r1
    //     0xfb524c: add             x1, x1, HEAP, lsl #32
    // 0xfb5250: ldur            x2, [fp, #-0x28]
    // 0xfb5254: r0 = merge()
    //     0xfb5254: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0xfb5258: str             NULL, [SP]
    // 0xfb525c: mov             x1, x0
    // 0xfb5260: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xfb5260: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xfb5264: ldr             x4, [x4, #0x7f0]
    // 0xfb5268: r0 = copyWith()
    //     0xfb5268: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xfb526c: stur            x0, [fp, #-8]
    // 0xfb5270: r0 = DropdownButtonHideUnderline()
    //     0xfb5270: bl              #0xe63510  ; AllocateDropdownButtonHideUnderlineStub -> DropdownButtonHideUnderline (size=0x10)
    // 0xfb5274: mov             x1, x0
    // 0xfb5278: ldur            x0, [fp, #-0x10]
    // 0xfb527c: stur            x1, [fp, #-0x28]
    // 0xfb5280: StoreField: r1->field_b = r0
    //     0xfb5280: stur            w0, [x1, #0xb]
    // 0xfb5284: r0 = DefaultTextStyle()
    //     0xfb5284: bl              #0xd0b11c  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xfb5288: mov             x1, x0
    // 0xfb528c: ldur            x0, [fp, #-8]
    // 0xfb5290: stur            x1, [fp, #-0x10]
    // 0xfb5294: StoreField: r1->field_f = r0
    //     0xfb5294: stur            w0, [x1, #0xf]
    // 0xfb5298: r0 = true
    //     0xfb5298: add             x0, NULL, #0x20  ; true
    // 0xfb529c: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb529c: stur            w0, [x1, #0x17]
    // 0xfb52a0: r0 = Instance_TextOverflow
    //     0xfb52a0: add             x0, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xfb52a4: ldr             x0, [x0, #0x108]
    // 0xfb52a8: StoreField: r1->field_1b = r0
    //     0xfb52a8: stur            w0, [x1, #0x1b]
    // 0xfb52ac: r0 = Instance_TextWidthBasis
    //     0xfb52ac: add             x0, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xfb52b0: ldr             x0, [x0, #0x110]
    // 0xfb52b4: StoreField: r1->field_23 = r0
    //     0xfb52b4: stur            w0, [x1, #0x23]
    // 0xfb52b8: ldur            x0, [fp, #-0x28]
    // 0xfb52bc: StoreField: r1->field_b = r0
    //     0xfb52bc: stur            w0, [x1, #0xb]
    // 0xfb52c0: r0 = Container()
    //     0xfb52c0: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xfb52c4: stur            x0, [fp, #-8]
    // 0xfb52c8: ldur            x16, [fp, #-0x18]
    // 0xfb52cc: ldur            lr, [fp, #-0x20]
    // 0xfb52d0: stp             lr, x16, [SP, #0x10]
    // 0xfb52d4: r16 = Instance_AlignmentDirectional
    //     0xfb52d4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28258] Obj!AlignmentDirectional@129e651
    //     0xfb52d8: ldr             x16, [x16, #0x258]
    // 0xfb52dc: ldur            lr, [fp, #-0x10]
    // 0xfb52e0: stp             lr, x16, [SP]
    // 0xfb52e4: mov             x1, x0
    // 0xfb52e8: r4 = const [0, 0x5, 0x4, 0x1, alignment, 0x3, child, 0x4, constraints, 0x2, padding, 0x1, null]
    //     0xfb52e8: add             x4, PP, #0x8f, lsl #12  ; [pp+0x8fff0] List(13) [0, 0x5, 0x4, 0x1, "alignment", 0x3, "child", 0x4, "constraints", 0x2, "padding", 0x1, Null]
    //     0xfb52ec: ldr             x4, [x4, #0xff0]
    // 0xfb52f0: r0 = Container()
    //     0xfb52f0: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xfb52f4: r0 = TableCell()
    //     0xfb52f4: bl              #0xfb5318  ; AllocateTableCellStub -> TableCell (size=0x14)
    // 0xfb52f8: ldur            x1, [fp, #-8]
    // 0xfb52fc: StoreField: r0->field_f = r1
    //     0xfb52fc: stur            w1, [x0, #0xf]
    // 0xfb5300: LeaveFrame
    //     0xfb5300: mov             SP, fp
    //     0xfb5304: ldp             fp, lr, [SP], #0x10
    // 0xfb5308: ret
    //     0xfb5308: ret             
    // 0xfb530c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb530c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb5310: b               #0xfb5164
    // 0xfb5314: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfb5314: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildHeadingCell(/* No info */) {
    // ** addr: 0xfb5324, size: 0x2f8
    // 0xfb5324: EnterFrame
    //     0xfb5324: stp             fp, lr, [SP, #-0x10]!
    //     0xfb5328: mov             fp, SP
    // 0xfb532c: AllocStack(0x60)
    //     0xfb532c: sub             SP, SP, #0x60
    // 0xfb5330: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r0, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */)
    //     0xfb5330: mov             x0, x3
    //     0xfb5334: stur            x2, [fp, #-8]
    //     0xfb5338: stur            x3, [fp, #-0x10]
    //     0xfb533c: stur            x5, [fp, #-0x18]
    // 0xfb5340: CheckStackOverflow
    //     0xfb5340: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb5344: cmp             SP, x16
    //     0xfb5348: b.ls            #0xfb55f4
    // 0xfb534c: mov             x1, x2
    // 0xfb5350: r0 = of()
    //     0xfb5350: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb5354: ldur            x1, [fp, #-8]
    // 0xfb5358: stur            x0, [fp, #-0x20]
    // 0xfb535c: r0 = of()
    //     0xfb535c: bl              #0xfb561c  ; [package:flutter/src/material/data_table_theme.dart] DataTableTheme::of
    // 0xfb5360: r1 = <Widget>
    //     0xfb5360: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfb5364: r2 = 0
    //     0xfb5364: mov             x2, #0
    // 0xfb5368: stur            x0, [fp, #-0x28]
    // 0xfb536c: r0 = _GrowableList()
    //     0xfb536c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfb5370: stur            x0, [fp, #-0x38]
    // 0xfb5374: LoadField: r1 = r0->field_b
    //     0xfb5374: ldur            w1, [x0, #0xb]
    // 0xfb5378: LoadField: r2 = r0->field_f
    //     0xfb5378: ldur            w2, [x0, #0xf]
    // 0xfb537c: DecompressPointer r2
    //     0xfb537c: add             x2, x2, HEAP, lsl #32
    // 0xfb5380: LoadField: r3 = r2->field_b
    //     0xfb5380: ldur            w3, [x2, #0xb]
    // 0xfb5384: r2 = LoadInt32Instr(r1)
    //     0xfb5384: sbfx            x2, x1, #1, #0x1f
    // 0xfb5388: stur            x2, [fp, #-0x30]
    // 0xfb538c: r1 = LoadInt32Instr(r3)
    //     0xfb538c: sbfx            x1, x3, #1, #0x1f
    // 0xfb5390: cmp             x2, x1
    // 0xfb5394: b.ne            #0xfb53a0
    // 0xfb5398: mov             x1, x0
    // 0xfb539c: r0 = _growToNextCapacity()
    //     0xfb539c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfb53a0: ldur            x5, [fp, #-0x20]
    // 0xfb53a4: ldur            x4, [fp, #-0x28]
    // 0xfb53a8: ldur            x2, [fp, #-0x38]
    // 0xfb53ac: ldur            x3, [fp, #-0x30]
    // 0xfb53b0: add             x0, x3, #1
    // 0xfb53b4: lsl             x1, x0, #1
    // 0xfb53b8: StoreField: r2->field_b = r1
    //     0xfb53b8: stur            w1, [x2, #0xb]
    // 0xfb53bc: LoadField: r1 = r2->field_f
    //     0xfb53bc: ldur            w1, [x2, #0xf]
    // 0xfb53c0: DecompressPointer r1
    //     0xfb53c0: add             x1, x1, HEAP, lsl #32
    // 0xfb53c4: ldur            x0, [fp, #-0x10]
    // 0xfb53c8: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfb53c8: add             x25, x1, x3, lsl #2
    //     0xfb53cc: add             x25, x25, #0xf
    //     0xfb53d0: str             w0, [x25]
    //     0xfb53d4: tbz             w0, #0, #0xfb53f0
    //     0xfb53d8: ldurb           w16, [x1, #-1]
    //     0xfb53dc: ldurb           w17, [x0, #-1]
    //     0xfb53e0: and             x16, x17, x16, lsr #2
    //     0xfb53e4: tst             x16, HEAP, lsr #32
    //     0xfb53e8: b.eq            #0xfb53f0
    //     0xfb53ec: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfb53f0: r0 = Row()
    //     0xfb53f0: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xfb53f4: mov             x1, x0
    // 0xfb53f8: r0 = Instance_Axis
    //     0xfb53f8: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xfb53fc: stur            x1, [fp, #-0x10]
    // 0xfb5400: StoreField: r1->field_f = r0
    //     0xfb5400: stur            w0, [x1, #0xf]
    // 0xfb5404: r0 = Instance_MainAxisAlignment
    //     0xfb5404: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xfb5408: ldr             x0, [x0, #0x820]
    // 0xfb540c: StoreField: r1->field_13 = r0
    //     0xfb540c: stur            w0, [x1, #0x13]
    // 0xfb5410: r0 = Instance_MainAxisSize
    //     0xfb5410: add             x0, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xfb5414: ldr             x0, [x0, #0x828]
    // 0xfb5418: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb5418: stur            w0, [x1, #0x17]
    // 0xfb541c: r0 = Instance_CrossAxisAlignment
    //     0xfb541c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xfb5420: ldr             x0, [x0, #0x888]
    // 0xfb5424: StoreField: r1->field_1b = r0
    //     0xfb5424: stur            w0, [x1, #0x1b]
    // 0xfb5428: r0 = Instance_VerticalDirection
    //     0xfb5428: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xfb542c: ldr             x0, [x0, #0x838]
    // 0xfb5430: StoreField: r1->field_23 = r0
    //     0xfb5430: stur            w0, [x1, #0x23]
    // 0xfb5434: r0 = Instance_Clip
    //     0xfb5434: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb5438: ldr             x0, [x0, #0x840]
    // 0xfb543c: StoreField: r1->field_2b = r0
    //     0xfb543c: stur            w0, [x1, #0x2b]
    // 0xfb5440: StoreField: r1->field_2f = rZR
    //     0xfb5440: stur            xzr, [x1, #0x2f]
    // 0xfb5444: ldur            x0, [fp, #-0x38]
    // 0xfb5448: StoreField: r1->field_b = r0
    //     0xfb5448: stur            w0, [x1, #0xb]
    // 0xfb544c: r0 = Semantics()
    //     0xfb544c: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xfb5450: stur            x0, [fp, #-0x38]
    // 0xfb5454: r16 = Instance_SemanticsRole
    //     0xfb5454: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fff8] Obj!SemanticsRole@12c7881
    //     0xfb5458: ldr             x16, [x16, #0xff8]
    // 0xfb545c: ldur            lr, [fp, #-0x10]
    // 0xfb5460: stp             lr, x16, [SP]
    // 0xfb5464: mov             x1, x0
    // 0xfb5468: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, role, 0x1, null]
    //     0xfb5468: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8c7f8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "role", 0x1, Null]
    //     0xfb546c: ldr             x4, [x4, #0x7f8]
    // 0xfb5470: r0 = Semantics()
    //     0xfb5470: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xfb5474: ldur            x0, [fp, #-0x20]
    // 0xfb5478: LoadField: r1 = r0->field_87
    //     0xfb5478: ldur            w1, [x0, #0x87]
    // 0xfb547c: DecompressPointer r1
    //     0xfb547c: add             x1, x1, HEAP, lsl #32
    // 0xfb5480: LoadField: r2 = r1->field_27
    //     0xfb5480: ldur            w2, [x1, #0x27]
    // 0xfb5484: DecompressPointer r2
    //     0xfb5484: add             x2, x2, HEAP, lsl #32
    // 0xfb5488: stur            x2, [fp, #-0x10]
    // 0xfb548c: cmp             w2, NULL
    // 0xfb5490: b.eq            #0xfb55fc
    // 0xfb5494: ldur            x1, [fp, #-0x28]
    // 0xfb5498: LoadField: r3 = r1->field_1f
    //     0xfb5498: ldur            w3, [x1, #0x1f]
    // 0xfb549c: DecompressPointer r3
    //     0xfb549c: add             x3, x3, HEAP, lsl #32
    // 0xfb54a0: cmp             w3, NULL
    // 0xfb54a4: b.ne            #0xfb54bc
    // 0xfb54a8: LoadField: r1 = r0->field_bf
    //     0xfb54a8: ldur            w1, [x0, #0xbf]
    // 0xfb54ac: DecompressPointer r1
    //     0xfb54ac: add             x1, x1, HEAP, lsl #32
    // 0xfb54b0: LoadField: r0 = r1->field_1f
    //     0xfb54b0: ldur            w0, [x1, #0x1f]
    // 0xfb54b4: DecompressPointer r0
    //     0xfb54b4: add             x0, x0, HEAP, lsl #32
    // 0xfb54b8: b               #0xfb54c0
    // 0xfb54bc: mov             x0, x3
    // 0xfb54c0: cmp             w0, NULL
    // 0xfb54c4: b.ne            #0xfb54d4
    // 0xfb54c8: d0 = 56.000000
    //     0xfb54c8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a70] IMM: double(56) from 0x404c000000000000
    //     0xfb54cc: ldr             d0, [x17, #0xa70]
    // 0xfb54d0: b               #0xfb54d8
    // 0xfb54d4: LoadField: d0 = r0->field_7
    //     0xfb54d4: ldur            d0, [x0, #7]
    // 0xfb54d8: ldur            x0, [fp, #-0x38]
    // 0xfb54dc: ldur            x1, [fp, #-8]
    // 0xfb54e0: stur            d0, [fp, #-0x40]
    // 0xfb54e4: r0 = of()
    //     0xfb54e4: bl              #0xd0b128  ; [package:flutter/src/widgets/text.dart] DefaultTextStyle::of
    // 0xfb54e8: LoadField: r1 = r0->field_f
    //     0xfb54e8: ldur            w1, [x0, #0xf]
    // 0xfb54ec: DecompressPointer r1
    //     0xfb54ec: add             x1, x1, HEAP, lsl #32
    // 0xfb54f0: ldur            x2, [fp, #-0x10]
    // 0xfb54f4: r0 = merge()
    //     0xfb54f4: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0xfb54f8: stur            x0, [fp, #-8]
    // 0xfb54fc: r0 = AnimatedDefaultTextStyle()
    //     0xfb54fc: bl              #0xd2ad90  ; AllocateAnimatedDefaultTextStyleStub -> AnimatedDefaultTextStyle (size=0x38)
    // 0xfb5500: mov             x1, x0
    // 0xfb5504: ldur            x0, [fp, #-0x38]
    // 0xfb5508: stur            x1, [fp, #-0x10]
    // 0xfb550c: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb550c: stur            w0, [x1, #0x17]
    // 0xfb5510: ldur            x0, [fp, #-8]
    // 0xfb5514: StoreField: r1->field_1b = r0
    //     0xfb5514: stur            w0, [x1, #0x1b]
    // 0xfb5518: r0 = false
    //     0xfb5518: add             x0, NULL, #0x30  ; false
    // 0xfb551c: StoreField: r1->field_23 = r0
    //     0xfb551c: stur            w0, [x1, #0x23]
    // 0xfb5520: r2 = Instance_TextOverflow
    //     0xfb5520: add             x2, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xfb5524: ldr             x2, [x2, #0x108]
    // 0xfb5528: StoreField: r1->field_27 = r2
    //     0xfb5528: stur            w2, [x1, #0x27]
    // 0xfb552c: r2 = Instance_TextWidthBasis
    //     0xfb552c: add             x2, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xfb5530: ldr             x2, [x2, #0x110]
    // 0xfb5534: StoreField: r1->field_2f = r2
    //     0xfb5534: stur            w2, [x1, #0x2f]
    // 0xfb5538: r2 = Instance__Linear
    //     0xfb5538: ldr             x2, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xfb553c: StoreField: r1->field_b = r2
    //     0xfb553c: stur            w2, [x1, #0xb]
    // 0xfb5540: r2 = Instance_Duration
    //     0xfb5540: add             x2, PP, #0x15, lsl #12  ; [pp+0x15238] Obj!Duration@12c8a31
    //     0xfb5544: ldr             x2, [x2, #0x238]
    // 0xfb5548: StoreField: r1->field_f = r2
    //     0xfb5548: stur            w2, [x1, #0xf]
    // 0xfb554c: ldur            d0, [fp, #-0x40]
    // 0xfb5550: r2 = inline_Allocate_Double()
    //     0xfb5550: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xfb5554: add             x2, x2, #0x10
    //     0xfb5558: cmp             x3, x2
    //     0xfb555c: b.ls            #0xfb5600
    //     0xfb5560: str             x2, [THR, #0x60]  ; THR::top
    //     0xfb5564: sub             x2, x2, #0xf
    //     0xfb5568: mov             x3, #0xe19c
    //     0xfb556c: movk            x3, #3, lsl #16
    //     0xfb5570: stur            x3, [x2, #-1]
    // 0xfb5574: dmb             ishst
    // 0xfb5578: StoreField: r2->field_7 = d0
    //     0xfb5578: stur            d0, [x2, #7]
    // 0xfb557c: stur            x2, [fp, #-8]
    // 0xfb5580: r0 = Container()
    //     0xfb5580: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xfb5584: stur            x0, [fp, #-0x20]
    // 0xfb5588: ldur            x16, [fp, #-0x18]
    // 0xfb558c: ldur            lr, [fp, #-8]
    // 0xfb5590: stp             lr, x16, [SP, #0x10]
    // 0xfb5594: r16 = Instance_AlignmentDirectional
    //     0xfb5594: add             x16, PP, #0x28, lsl #12  ; [pp+0x28258] Obj!AlignmentDirectional@129e651
    //     0xfb5598: ldr             x16, [x16, #0x258]
    // 0xfb559c: ldur            lr, [fp, #-0x10]
    // 0xfb55a0: stp             lr, x16, [SP]
    // 0xfb55a4: mov             x1, x0
    // 0xfb55a8: r4 = const [0, 0x5, 0x4, 0x1, alignment, 0x3, child, 0x4, height, 0x2, padding, 0x1, null]
    //     0xfb55a8: add             x4, PP, #0x90, lsl #12  ; [pp+0x90000] List(13) [0, 0x5, 0x4, 0x1, "alignment", 0x3, "child", 0x4, "height", 0x2, "padding", 0x1, Null]
    //     0xfb55ac: ldr             x4, [x4]
    // 0xfb55b0: r0 = Container()
    //     0xfb55b0: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xfb55b4: r0 = InkWell()
    //     0xfb55b4: bl              #0xd0c57c  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0xfb55b8: ldur            x1, [fp, #-0x20]
    // 0xfb55bc: StoreField: r0->field_b = r1
    //     0xfb55bc: stur            w1, [x0, #0xb]
    // 0xfb55c0: r1 = true
    //     0xfb55c0: add             x1, NULL, #0x20  ; true
    // 0xfb55c4: StoreField: r0->field_47 = r1
    //     0xfb55c4: stur            w1, [x0, #0x47]
    // 0xfb55c8: r2 = Instance_BoxShape
    //     0xfb55c8: add             x2, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xfb55cc: ldr             x2, [x2, #0x1f8]
    // 0xfb55d0: StoreField: r0->field_4b = r2
    //     0xfb55d0: stur            w2, [x0, #0x4b]
    // 0xfb55d4: StoreField: r0->field_73 = r1
    //     0xfb55d4: stur            w1, [x0, #0x73]
    // 0xfb55d8: r2 = false
    //     0xfb55d8: add             x2, NULL, #0x30  ; false
    // 0xfb55dc: StoreField: r0->field_77 = r2
    //     0xfb55dc: stur            w2, [x0, #0x77]
    // 0xfb55e0: StoreField: r0->field_87 = r1
    //     0xfb55e0: stur            w1, [x0, #0x87]
    // 0xfb55e4: StoreField: r0->field_7f = r2
    //     0xfb55e4: stur            w2, [x0, #0x7f]
    // 0xfb55e8: LeaveFrame
    //     0xfb55e8: mov             SP, fp
    //     0xfb55ec: ldp             fp, lr, [SP], #0x10
    // 0xfb55f0: ret
    //     0xfb55f0: ret             
    // 0xfb55f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb55f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb55f8: b               #0xfb534c
    // 0xfb55fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfb55fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfb5600: SaveReg d0
    //     0xfb5600: str             q0, [SP, #-0x10]!
    // 0xfb5604: stp             x0, x1, [SP, #-0x10]!
    // 0xfb5608: r0 = AllocateDouble()
    //     0xfb5608: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfb560c: mov             x2, x0
    // 0xfb5610: ldp             x0, x1, [SP], #0x10
    // 0xfb5614: RestoreReg d0
    //     0xfb5614: ldr             q0, [SP], #0x10
    // 0xfb5618: b               #0xfb5578
  }
  [closure] TableRow <anonymous closure>(dynamic, int) {
    // ** addr: 0xfb5674, size: 0x350
    // 0xfb5674: EnterFrame
    //     0xfb5674: stp             fp, lr, [SP, #-0x10]!
    //     0xfb5678: mov             fp, SP
    // 0xfb567c: AllocStack(0x30)
    //     0xfb567c: sub             SP, SP, #0x30
    // 0xfb5680: SetupParameters([dynamic _ /* r0 */])
    //     0xfb5680: ldr             x0, [fp, #0x18]
    //     0xfb5684: ldur            w2, [x0, #0x17]
    //     0xfb5688: add             x2, x2, HEAP, lsl #32
    //     0xfb568c: stur            x2, [fp, #-0x18]
    // 0xfb5690: CheckStackOverflow
    //     0xfb5690: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb5694: cmp             SP, x16
    //     0xfb5698: b.ls            #0xfb59a4
    // 0xfb569c: ldr             x0, [fp, #0x10]
    // 0xfb56a0: r3 = LoadInt32Instr(r0)
    //     0xfb56a0: sbfx            x3, x0, #1, #0x1f
    //     0xfb56a4: tbz             w0, #0, #0xfb56ac
    //     0xfb56a8: ldur            x3, [x0, #7]
    // 0xfb56ac: stur            x3, [fp, #-0x10]
    // 0xfb56b0: cmp             x3, #0
    // 0xfb56b4: b.le            #0xfb56e8
    // 0xfb56b8: LoadField: r0 = r2->field_f
    //     0xfb56b8: ldur            w0, [x2, #0xf]
    // 0xfb56bc: DecompressPointer r0
    //     0xfb56bc: add             x0, x0, HEAP, lsl #32
    // 0xfb56c0: LoadField: r1 = r0->field_4b
    //     0xfb56c0: ldur            w1, [x0, #0x4b]
    // 0xfb56c4: DecompressPointer r1
    //     0xfb56c4: add             x1, x1, HEAP, lsl #32
    // 0xfb56c8: sub             x0, x3, #1
    // 0xfb56cc: LoadField: r4 = r1->field_b
    //     0xfb56cc: ldur            w4, [x1, #0xb]
    // 0xfb56d0: r1 = LoadInt32Instr(r4)
    //     0xfb56d0: sbfx            x1, x4, #1, #0x1f
    // 0xfb56d4: mov             x16, x0
    // 0xfb56d8: mov             x0, x1
    // 0xfb56dc: mov             x1, x16
    // 0xfb56e0: cmp             x1, x0
    // 0xfb56e4: b.hs            #0xfb59ac
    // 0xfb56e8: cmp             x3, #0
    // 0xfb56ec: b.le            #0xfb5734
    // 0xfb56f0: LoadField: r0 = r2->field_2b
    //     0xfb56f0: ldur            w0, [x2, #0x2b]
    // 0xfb56f4: DecompressPointer r0
    //     0xfb56f4: add             x0, x0, HEAP, lsl #32
    // 0xfb56f8: tbnz            w0, #4, #0xfb5734
    // 0xfb56fc: LoadField: r0 = r2->field_f
    //     0xfb56fc: ldur            w0, [x2, #0xf]
    // 0xfb5700: DecompressPointer r0
    //     0xfb5700: add             x0, x0, HEAP, lsl #32
    // 0xfb5704: LoadField: r1 = r0->field_4b
    //     0xfb5704: ldur            w1, [x0, #0x4b]
    // 0xfb5708: DecompressPointer r1
    //     0xfb5708: add             x1, x1, HEAP, lsl #32
    // 0xfb570c: sub             x0, x3, #1
    // 0xfb5710: LoadField: r4 = r1->field_b
    //     0xfb5710: ldur            w4, [x1, #0xb]
    // 0xfb5714: r1 = LoadInt32Instr(r4)
    //     0xfb5714: sbfx            x1, x4, #1, #0x1f
    // 0xfb5718: mov             x16, x0
    // 0xfb571c: mov             x0, x1
    // 0xfb5720: mov             x1, x16
    // 0xfb5724: cmp             x1, x0
    // 0xfb5728: b.hs            #0xfb59b0
    // 0xfb572c: r0 = true
    //     0xfb572c: add             x0, NULL, #0x20  ; true
    // 0xfb5730: b               #0xfb5738
    // 0xfb5734: r0 = false
    //     0xfb5734: add             x0, NULL, #0x30  ; false
    // 0xfb5738: stur            x0, [fp, #-8]
    // 0xfb573c: r1 = <WidgetState>
    //     0xfb573c: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a10] TypeArguments: <WidgetState>
    //     0xfb5740: ldr             x1, [x1, #0xa10]
    // 0xfb5744: r0 = _Set()
    //     0xfb5744: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xfb5748: mov             x3, x0
    // 0xfb574c: r0 = _Uint32List
    //     0xfb574c: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0xfb5750: stur            x3, [fp, #-0x20]
    // 0xfb5754: StoreField: r3->field_1b = r0
    //     0xfb5754: stur            w0, [x3, #0x1b]
    // 0xfb5758: StoreField: r3->field_b = rZR
    //     0xfb5758: stur            wzr, [x3, #0xb]
    // 0xfb575c: r0 = const []
    //     0xfb575c: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0xfb5760: StoreField: r3->field_f = r0
    //     0xfb5760: stur            w0, [x3, #0xf]
    // 0xfb5764: StoreField: r3->field_13 = rZR
    //     0xfb5764: stur            wzr, [x3, #0x13]
    // 0xfb5768: ArrayStore: r3[0] = rZR  ; List_4
    //     0xfb5768: stur            wzr, [x3, #0x17]
    // 0xfb576c: ldur            x0, [fp, #-8]
    // 0xfb5770: tbnz            w0, #4, #0xfb5784
    // 0xfb5774: mov             x1, x3
    // 0xfb5778: r2 = Instance_WidgetState
    //     0xfb5778: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xfb577c: ldr             x2, [x2, #0xa70]
    // 0xfb5780: r0 = add()
    //     0xfb5780: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xfb5784: ldur            x2, [fp, #-0x10]
    // 0xfb5788: cmp             x2, #0
    // 0xfb578c: b.le            #0xfb57c8
    // 0xfb5790: ldur            x3, [fp, #-0x18]
    // 0xfb5794: LoadField: r0 = r3->field_f
    //     0xfb5794: ldur            w0, [x3, #0xf]
    // 0xfb5798: DecompressPointer r0
    //     0xfb5798: add             x0, x0, HEAP, lsl #32
    // 0xfb579c: LoadField: r1 = r0->field_4b
    //     0xfb579c: ldur            w1, [x0, #0x4b]
    // 0xfb57a0: DecompressPointer r1
    //     0xfb57a0: add             x1, x1, HEAP, lsl #32
    // 0xfb57a4: sub             x0, x2, #1
    // 0xfb57a8: LoadField: r4 = r1->field_b
    //     0xfb57a8: ldur            w4, [x1, #0xb]
    // 0xfb57ac: r1 = LoadInt32Instr(r4)
    //     0xfb57ac: sbfx            x1, x4, #1, #0x1f
    // 0xfb57b0: mov             x16, x0
    // 0xfb57b4: mov             x0, x1
    // 0xfb57b8: mov             x1, x16
    // 0xfb57bc: cmp             x1, x0
    // 0xfb57c0: b.hs            #0xfb59b4
    // 0xfb57c4: b               #0xfb57cc
    // 0xfb57c8: ldur            x3, [fp, #-0x18]
    // 0xfb57cc: LoadField: r1 = r3->field_13
    //     0xfb57cc: ldur            w1, [x3, #0x13]
    // 0xfb57d0: DecompressPointer r1
    //     0xfb57d0: add             x1, x1, HEAP, lsl #32
    // 0xfb57d4: LoadField: r0 = r3->field_1b
    //     0xfb57d4: ldur            w0, [x3, #0x1b]
    // 0xfb57d8: DecompressPointer r0
    //     0xfb57d8: add             x0, x0, HEAP, lsl #32
    // 0xfb57dc: LoadField: r4 = r0->field_2f
    //     0xfb57dc: ldur            w4, [x0, #0x2f]
    // 0xfb57e0: DecompressPointer r4
    //     0xfb57e0: add             x4, x4, HEAP, lsl #32
    // 0xfb57e4: cmp             w4, NULL
    // 0xfb57e8: b.ne            #0xfb5808
    // 0xfb57ec: ArrayLoad: r0 = r3[0]  ; List_4
    //     0xfb57ec: ldur            w0, [x3, #0x17]
    // 0xfb57f0: DecompressPointer r0
    //     0xfb57f0: add             x0, x0, HEAP, lsl #32
    // 0xfb57f4: LoadField: r4 = r0->field_bf
    //     0xfb57f4: ldur            w4, [x0, #0xbf]
    // 0xfb57f8: DecompressPointer r4
    //     0xfb57f8: add             x4, x4, HEAP, lsl #32
    // 0xfb57fc: LoadField: r0 = r4->field_2f
    //     0xfb57fc: ldur            w0, [x4, #0x2f]
    // 0xfb5800: DecompressPointer r0
    //     0xfb5800: add             x0, x0, HEAP, lsl #32
    // 0xfb5804: b               #0xfb580c
    // 0xfb5808: mov             x0, x4
    // 0xfb580c: cmp             w0, NULL
    // 0xfb5810: b.ne            #0xfb581c
    // 0xfb5814: d0 = 1.000000
    //     0xfb5814: fmov            d0, #1.00000000
    // 0xfb5818: b               #0xfb5820
    // 0xfb581c: LoadField: d0 = r0->field_7
    //     0xfb581c: ldur            d0, [x0, #7]
    // 0xfb5820: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xfb5820: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xfb5824: r0 = createBorderSide()
    //     0xfb5824: bl              #0xfb59d0  ; [package:flutter/src/material/divider.dart] Divider::createBorderSide
    // 0xfb5828: mov             x1, x0
    // 0xfb582c: ldur            x0, [fp, #-0x10]
    // 0xfb5830: stur            x1, [fp, #-8]
    // 0xfb5834: cbnz            x0, #0xfb5840
    // 0xfb5838: r1 = Null
    //     0xfb5838: mov             x1, NULL
    // 0xfb583c: b               #0xfb5868
    // 0xfb5840: r0 = Border()
    //     0xfb5840: bl              #0x8a73b0  ; AllocateBorderStub -> Border (size=0x18)
    // 0xfb5844: mov             x1, x0
    // 0xfb5848: ldur            x0, [fp, #-8]
    // 0xfb584c: StoreField: r1->field_7 = r0
    //     0xfb584c: stur            w0, [x1, #7]
    // 0xfb5850: r0 = Instance_BorderSide
    //     0xfb5850: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0xfb5854: ldr             x0, [x0, #0x310]
    // 0xfb5858: StoreField: r1->field_b = r0
    //     0xfb5858: stur            w0, [x1, #0xb]
    // 0xfb585c: StoreField: r1->field_f = r0
    //     0xfb585c: stur            w0, [x1, #0xf]
    // 0xfb5860: StoreField: r1->field_13 = r0
    //     0xfb5860: stur            w0, [x1, #0x13]
    // 0xfb5864: ldur            x0, [fp, #-0x10]
    // 0xfb5868: stur            x1, [fp, #-8]
    // 0xfb586c: cbnz            x0, #0xfb589c
    // 0xfb5870: r0 = LoadStaticField(0x660)
    //     0xfb5870: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfb5874: ldr             x0, [x0, #0xcc0]
    // 0xfb5878: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb587c: cmp             w0, w16
    // 0xfb5880: b.ne            #0xfb5890
    // 0xfb5884: r2 = _headingRowKey
    //     0xfb5884: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8ffb8] Field <DataTable._headingRowKey@74002722>: static late final (offset: 0x660)
    //     0xfb5888: ldr             x2, [x2, #0xfb8]
    // 0xfb588c: r0 = InitLateFinalStaticField()
    //     0xfb588c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xfb5890: mov             x4, x0
    // 0xfb5894: ldur            x3, [fp, #-0x18]
    // 0xfb5898: b               #0xfb58cc
    // 0xfb589c: ldur            x3, [fp, #-0x18]
    // 0xfb58a0: LoadField: r1 = r3->field_f
    //     0xfb58a0: ldur            w1, [x3, #0xf]
    // 0xfb58a4: DecompressPointer r1
    //     0xfb58a4: add             x1, x1, HEAP, lsl #32
    // 0xfb58a8: LoadField: r2 = r1->field_4b
    //     0xfb58a8: ldur            w2, [x1, #0x4b]
    // 0xfb58ac: DecompressPointer r2
    //     0xfb58ac: add             x2, x2, HEAP, lsl #32
    // 0xfb58b0: sub             x1, x0, #1
    // 0xfb58b4: LoadField: r0 = r2->field_b
    //     0xfb58b4: ldur            w0, [x2, #0xb]
    // 0xfb58b8: r2 = LoadInt32Instr(r0)
    //     0xfb58b8: sbfx            x2, x0, #1, #0x1f
    // 0xfb58bc: mov             x0, x2
    // 0xfb58c0: cmp             x1, x0
    // 0xfb58c4: b.hs            #0xfb59b8
    // 0xfb58c8: r4 = Null
    //     0xfb58c8: mov             x4, NULL
    // 0xfb58cc: ldur            x0, [fp, #-8]
    // 0xfb58d0: stur            x4, [fp, #-0x28]
    // 0xfb58d4: LoadField: r1 = r3->field_27
    //     0xfb58d4: ldur            w1, [x3, #0x27]
    // 0xfb58d8: DecompressPointer r1
    //     0xfb58d8: add             x1, x1, HEAP, lsl #32
    // 0xfb58dc: ldur            x2, [fp, #-0x20]
    // 0xfb58e0: r0 = build()
    //     0xfb58e0: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xfb58e4: stur            x0, [fp, #-0x20]
    // 0xfb58e8: r0 = BoxDecoration()
    //     0xfb58e8: bl              #0x8a721c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xfb58ec: mov             x3, x0
    // 0xfb58f0: ldur            x0, [fp, #-0x20]
    // 0xfb58f4: stur            x3, [fp, #-0x30]
    // 0xfb58f8: StoreField: r3->field_7 = r0
    //     0xfb58f8: stur            w0, [x3, #7]
    // 0xfb58fc: ldur            x0, [fp, #-8]
    // 0xfb5900: StoreField: r3->field_f = r0
    //     0xfb5900: stur            w0, [x3, #0xf]
    // 0xfb5904: r0 = Instance_BoxShape
    //     0xfb5904: add             x0, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xfb5908: ldr             x0, [x0, #0x1f8]
    // 0xfb590c: StoreField: r3->field_23 = r0
    //     0xfb590c: stur            w0, [x3, #0x23]
    // 0xfb5910: ldur            x0, [fp, #-0x18]
    // 0xfb5914: LoadField: r1 = r0->field_33
    //     0xfb5914: ldur            w1, [x0, #0x33]
    // 0xfb5918: DecompressPointer r1
    //     0xfb5918: add             x1, x1, HEAP, lsl #32
    // 0xfb591c: LoadField: r0 = r1->field_b
    //     0xfb591c: ldur            w0, [x1, #0xb]
    // 0xfb5920: mov             x2, x0
    // 0xfb5924: stur            x0, [fp, #-8]
    // 0xfb5928: r1 = <Widget>
    //     0xfb5928: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfb592c: r0 = AllocateArray()
    //     0xfb592c: bl              #0x13df928  ; AllocateArrayStub
    // 0xfb5930: mov             x1, x0
    // 0xfb5934: ldur            x0, [fp, #-8]
    // 0xfb5938: stur            x1, [fp, #-0x18]
    // 0xfb593c: r2 = LoadInt32Instr(r0)
    //     0xfb593c: sbfx            x2, x0, #1, #0x1f
    // 0xfb5940: r0 = 0
    //     0xfb5940: mov             x0, #0
    // 0xfb5944: CheckStackOverflow
    //     0xfb5944: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb5948: cmp             SP, x16
    //     0xfb594c: b.ls            #0xfb59bc
    // 0xfb5950: cmp             x0, x2
    // 0xfb5954: b.ge            #0xfb5974
    // 0xfb5958: add             x3, x1, x0, lsl #2
    // 0xfb595c: r16 = Instance__NullWidget
    //     0xfb595c: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8ffc0] Obj!_NullWidget@12b4b11
    //     0xfb5960: ldr             x16, [x16, #0xfc0]
    // 0xfb5964: StoreField: r3->field_f = r16
    //     0xfb5964: stur            w16, [x3, #0xf]
    // 0xfb5968: add             x3, x0, #1
    // 0xfb596c: mov             x0, x3
    // 0xfb5970: b               #0xfb5944
    // 0xfb5974: ldur            x2, [fp, #-0x28]
    // 0xfb5978: ldur            x0, [fp, #-0x30]
    // 0xfb597c: r0 = TableRow()
    //     0xfb597c: bl              #0xfb59c4  ; AllocateTableRowStub -> TableRow (size=0x14)
    // 0xfb5980: ldur            x1, [fp, #-0x28]
    // 0xfb5984: StoreField: r0->field_7 = r1
    //     0xfb5984: stur            w1, [x0, #7]
    // 0xfb5988: ldur            x1, [fp, #-0x30]
    // 0xfb598c: StoreField: r0->field_b = r1
    //     0xfb598c: stur            w1, [x0, #0xb]
    // 0xfb5990: ldur            x1, [fp, #-0x18]
    // 0xfb5994: StoreField: r0->field_f = r1
    //     0xfb5994: stur            w1, [x0, #0xf]
    // 0xfb5998: LeaveFrame
    //     0xfb5998: mov             SP, fp
    //     0xfb599c: ldp             fp, lr, [SP], #0x10
    // 0xfb59a0: ret
    //     0xfb59a0: ret             
    // 0xfb59a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb59a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb59a8: b               #0xfb569c
    // 0xfb59ac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfb59ac: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xfb59b0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfb59b0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xfb59b4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfb59b4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xfb59b8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfb59b8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xfb59bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb59bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb59c0: b               #0xfb5950
  }
  static LocalKey _headingRowKey() {
    // ** addr: 0xfb5c08, size: 0x18
    // 0xfb5c08: EnterFrame
    //     0xfb5c08: stp             fp, lr, [SP, #-0x10]!
    //     0xfb5c0c: mov             fp, SP
    // 0xfb5c10: r0 = UniqueKey()
    //     0xfb5c10: bl              #0xb8f328  ; AllocateUniqueKeyStub -> UniqueKey (size=0x8)
    // 0xfb5c14: LeaveFrame
    //     0xfb5c14: mov             SP, fp
    //     0xfb5c18: ldp             fp, lr, [SP], #0x10
    // 0xfb5c1c: ret
    //     0xfb5c1c: ret             
  }
  [closure] Color? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xfb5c40, size: 0xa0
    // 0xfb5c40: EnterFrame
    //     0xfb5c40: stp             fp, lr, [SP, #-0x10]!
    //     0xfb5c44: mov             fp, SP
    // 0xfb5c48: AllocStack(0x8)
    //     0xfb5c48: sub             SP, SP, #8
    // 0xfb5c4c: SetupParameters([dynamic _ /* r0 */])
    //     0xfb5c4c: ldr             x0, [fp, #0x18]
    //     0xfb5c50: ldur            w3, [x0, #0x17]
    //     0xfb5c54: add             x3, x3, HEAP, lsl #32
    //     0xfb5c58: stur            x3, [fp, #-8]
    // 0xfb5c5c: CheckStackOverflow
    //     0xfb5c5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb5c60: cmp             SP, x16
    //     0xfb5c64: b.ls            #0xfb5cd8
    // 0xfb5c68: ldr             x1, [fp, #0x10]
    // 0xfb5c6c: r0 = LoadClassIdInstr(r1)
    //     0xfb5c6c: ldur            x0, [x1, #-1]
    //     0xfb5c70: ubfx            x0, x0, #0xc, #0x14
    // 0xfb5c74: r2 = Instance_WidgetState
    //     0xfb5c74: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xfb5c78: ldr             x2, [x2, #0x100]
    // 0xfb5c7c: r0 = GDT[cid_x0 + 0x12929]()
    //     0xfb5c7c: mov             x17, #0x2929
    //     0xfb5c80: movk            x17, #1, lsl #16
    //     0xfb5c84: add             lr, x0, x17
    //     0xfb5c88: ldr             lr, [x21, lr, lsl #3]
    //     0xfb5c8c: blr             lr
    // 0xfb5c90: tbnz            w0, #4, #0xfb5cc8
    // 0xfb5c94: ldur            x0, [fp, #-8]
    // 0xfb5c98: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xfb5c98: ldur            w1, [x0, #0x17]
    // 0xfb5c9c: DecompressPointer r1
    //     0xfb5c9c: add             x1, x1, HEAP, lsl #32
    // 0xfb5ca0: LoadField: r0 = r1->field_3f
    //     0xfb5ca0: ldur            w0, [x1, #0x3f]
    // 0xfb5ca4: DecompressPointer r0
    //     0xfb5ca4: add             x0, x0, HEAP, lsl #32
    // 0xfb5ca8: LoadField: r1 = r0->field_b
    //     0xfb5ca8: ldur            w1, [x0, #0xb]
    // 0xfb5cac: DecompressPointer r1
    //     0xfb5cac: add             x1, x1, HEAP, lsl #32
    // 0xfb5cb0: d0 = 0.080000
    //     0xfb5cb0: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xfb5cb4: ldr             d0, [x17, #0xa58]
    // 0xfb5cb8: r0 = withOpacity()
    //     0xfb5cb8: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xfb5cbc: LeaveFrame
    //     0xfb5cbc: mov             SP, fp
    //     0xfb5cc0: ldp             fp, lr, [SP], #0x10
    // 0xfb5cc4: ret
    //     0xfb5cc4: ret             
    // 0xfb5cc8: r0 = Null
    //     0xfb5cc8: mov             x0, NULL
    // 0xfb5ccc: LeaveFrame
    //     0xfb5ccc: mov             SP, fp
    //     0xfb5cd0: ldp             fp, lr, [SP], #0x10
    // 0xfb5cd4: ret
    //     0xfb5cd4: ret             
    // 0xfb5cd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb5cd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb5cdc: b               #0xfb5c68
  }
  _ DataTable(/* No info */) {
    // ** addr: 0x1057d88, size: 0x12c
    // 0x1057d88: EnterFrame
    //     0x1057d88: stp             fp, lr, [SP, #-0x10]!
    //     0x1057d8c: mov             fp, SP
    // 0x1057d90: r7 = true
    //     0x1057d90: add             x7, NULL, #0x20  ; true
    // 0x1057d94: r6 = false
    //     0x1057d94: add             x6, NULL, #0x30  ; false
    // 0x1057d98: r4 = Instance_Clip
    //     0x1057d98: add             x4, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0x1057d9c: ldr             x4, [x4, #0x840]
    // 0x1057da0: d0 = 20.000000
    //     0x1057da0: fmov            d0, #20.00000000
    // 0x1057da4: mov             x0, x2
    // 0x1057da8: mov             x16, x5
    // 0x1057dac: mov             x5, x1
    // 0x1057db0: mov             x1, x16
    // 0x1057db4: mov             x16, x3
    // 0x1057db8: mov             x3, x2
    // 0x1057dbc: mov             x2, x16
    // 0x1057dc0: StoreField: r5->field_b = r0
    //     0x1057dc0: stur            w0, [x5, #0xb]
    //     0x1057dc4: ldurb           w16, [x5, #-1]
    //     0x1057dc8: ldurb           w17, [x0, #-1]
    //     0x1057dcc: and             x16, x17, x16, lsr #2
    //     0x1057dd0: tst             x16, HEAP, lsr #32
    //     0x1057dd4: b.eq            #0x1057ddc
    //     0x1057dd8: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0x1057ddc: StoreField: r5->field_13 = r7
    //     0x1057ddc: stur            w7, [x5, #0x13]
    // 0x1057de0: mov             x0, x2
    // 0x1057de4: StoreField: r5->field_1b = r0
    //     0x1057de4: stur            w0, [x5, #0x1b]
    //     0x1057de8: ldurb           w16, [x5, #-1]
    //     0x1057dec: ldurb           w17, [x0, #-1]
    //     0x1057df0: and             x16, x17, x16, lsr #2
    //     0x1057df4: tst             x16, HEAP, lsr #32
    //     0x1057df8: b.eq            #0x1057e00
    //     0x1057dfc: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0x1057e00: StoreField: r5->field_3f = d0
    //     0x1057e00: stur            d0, [x5, #0x3f]
    // 0x1057e04: StoreField: r5->field_47 = r7
    //     0x1057e04: stur            w7, [x5, #0x47]
    // 0x1057e08: StoreField: r5->field_53 = r6
    //     0x1057e08: stur            w6, [x5, #0x53]
    // 0x1057e0c: mov             x0, x1
    // 0x1057e10: StoreField: r5->field_4b = r0
    //     0x1057e10: stur            w0, [x5, #0x4b]
    //     0x1057e14: ldurb           w16, [x5, #-1]
    //     0x1057e18: ldurb           w17, [x0, #-1]
    //     0x1057e1c: and             x16, x17, x16, lsr #2
    //     0x1057e20: tst             x16, HEAP, lsr #32
    //     0x1057e24: b.eq            #0x1057e2c
    //     0x1057e28: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0x1057e2c: StoreField: r5->field_5f = r4
    //     0x1057e2c: stur            w4, [x5, #0x5f]
    // 0x1057e30: LoadField: r1 = r3->field_b
    //     0x1057e30: ldur            w1, [x3, #0xb]
    // 0x1057e34: r2 = LoadInt32Instr(r1)
    //     0x1057e34: sbfx            x2, x1, #1, #0x1f
    // 0x1057e38: r3 = Null
    //     0x1057e38: mov             x3, NULL
    // 0x1057e3c: r1 = 0
    //     0x1057e3c: mov             x1, #0
    // 0x1057e40: CheckStackOverflow
    //     0x1057e40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1057e44: cmp             SP, x16
    //     0x1057e48: b.ls            #0x1057eac
    // 0x1057e4c: cmp             x1, x2
    // 0x1057e50: b.ge            #0x1057e78
    // 0x1057e54: lsl             x0, x1, #1
    // 0x1057e58: cmp             w3, NULL
    // 0x1057e5c: b.ne            #0x1057e70
    // 0x1057e60: add             x4, x1, #1
    // 0x1057e64: mov             x3, x0
    // 0x1057e68: mov             x1, x4
    // 0x1057e6c: b               #0x1057e40
    // 0x1057e70: r0 = Null
    //     0x1057e70: mov             x0, NULL
    // 0x1057e74: b               #0x1057e7c
    // 0x1057e78: mov             x0, x3
    // 0x1057e7c: StoreField: r5->field_63 = r0
    //     0x1057e7c: stur            w0, [x5, #0x63]
    //     0x1057e80: tbz             w0, #0, #0x1057e9c
    //     0x1057e84: ldurb           w16, [x5, #-1]
    //     0x1057e88: ldurb           w17, [x0, #-1]
    //     0x1057e8c: and             x16, x17, x16, lsr #2
    //     0x1057e90: tst             x16, HEAP, lsr #32
    //     0x1057e94: b.eq            #0x1057e9c
    //     0x1057e98: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0x1057e9c: r0 = Null
    //     0x1057e9c: mov             x0, NULL
    // 0x1057ea0: LeaveFrame
    //     0x1057ea0: mov             SP, fp
    //     0x1057ea4: ldp             fp, lr, [SP], #0x10
    // 0x1057ea8: ret
    //     0x1057ea8: ret             
    // 0x1057eac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1057eac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1057eb0: b               #0x1057e4c
  }
}
