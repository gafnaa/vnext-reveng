// lib: , url: package:flutter/src/material/progress_indicator.dart

// class id: 1048931, size: 0x8
class :: {
}

// class id: 4333, size: 0x64, field offset: 0xc
class _CircularProgressIndicatorPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0xb7821c, size: 0x6dc
    // 0xb7821c: EnterFrame
    //     0xb7821c: stp             fp, lr, [SP, #-0x10]!
    //     0xb78220: mov             fp, SP
    // 0xb78224: AllocStack(0xa8)
    //     0xb78224: sub             SP, SP, #0xa8
    // 0xb78228: SetupParameters(_CircularProgressIndicatorPainter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb78228: stur            x1, [fp, #-8]
    //     0xb7822c: stur            x2, [fp, #-0x10]
    //     0xb78230: stur            x3, [fp, #-0x18]
    // 0xb78234: CheckStackOverflow
    //     0xb78234: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb78238: cmp             SP, x16
    //     0xb7823c: b.ls            #0xb788d0
    // 0xb78240: r16 = 136
    //     0xb78240: mov             x16, #0x88
    // 0xb78244: stp             x16, NULL, [SP]
    // 0xb78248: r0 = ByteData()
    //     0xb78248: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb7824c: stur            x0, [fp, #-0x20]
    // 0xb78250: r0 = Paint()
    //     0xb78250: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb78254: ldur            x5, [fp, #-0x20]
    // 0xb78258: stur            x0, [fp, #-0x28]
    // 0xb7825c: StoreField: r0->field_7 = r5
    //     0xb7825c: stur            w5, [x0, #7]
    // 0xb78260: ldur            x3, [fp, #-8]
    // 0xb78264: LoadField: r2 = r3->field_f
    //     0xb78264: ldur            w2, [x3, #0xf]
    // 0xb78268: DecompressPointer r2
    //     0xb78268: add             x2, x2, HEAP, lsl #32
    // 0xb7826c: mov             x1, x0
    // 0xb78270: r0 = color=()
    //     0xb78270: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb78274: ldur            x0, [fp, #-8]
    // 0xb78278: LoadField: d0 = r0->field_37
    //     0xb78278: ldur            d0, [x0, #0x37]
    // 0xb7827c: ldur            x5, [fp, #-0x20]
    // 0xb78280: stur            d0, [fp, #-0x80]
    // 0xb78284: ArrayLoad: r1 = r5[0]  ; List_4
    //     0xb78284: ldur            w1, [x5, #0x17]
    // 0xb78288: DecompressPointer r1
    //     0xb78288: add             x1, x1, HEAP, lsl #32
    // 0xb7828c: stur            x1, [fp, #-0x30]
    // 0xb78290: fcvt            s1, d0
    // 0xb78294: stur            d1, [fp, #-0x78]
    // 0xb78298: LoadField: r2 = r1->field_7
    //     0xb78298: ldur            x2, [x1, #7]
    // 0xb7829c: str             s1, [x2, #0x20]
    // 0xb782a0: LoadField: r2 = r1->field_7
    //     0xb782a0: ldur            x2, [x1, #7]
    // 0xb782a4: r3 = 1
    //     0xb782a4: mov             x3, #1
    // 0xb782a8: str             w3, [x2, #0x1c]
    // 0xb782ac: d2 = 2.000000
    //     0xb782ac: fmov            d2, #2.00000000
    // 0xb782b0: fdiv            d3, d0, d2
    // 0xb782b4: LoadField: d4 = r0->field_3f
    //     0xb782b4: ldur            d4, [x0, #0x3f]
    // 0xb782b8: fneg            d5, d4
    // 0xb782bc: fmul            d4, d3, d5
    // 0xb782c0: stur            d4, [fp, #-0x70]
    // 0xb782c4: r0 = Offset()
    //     0xb782c4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb782c8: ldur            d0, [fp, #-0x70]
    // 0xb782cc: stur            x0, [fp, #-0x38]
    // 0xb782d0: StoreField: r0->field_7 = d0
    //     0xb782d0: stur            d0, [x0, #7]
    // 0xb782d4: StoreField: r0->field_f = d0
    //     0xb782d4: stur            d0, [x0, #0xf]
    // 0xb782d8: ldur            x1, [fp, #-0x18]
    // 0xb782dc: LoadField: d1 = r1->field_7
    //     0xb782dc: ldur            d1, [x1, #7]
    // 0xb782e0: stur            d1, [fp, #-0x90]
    // 0xb782e4: d2 = 2.000000
    //     0xb782e4: fmov            d2, #2.00000000
    // 0xb782e8: fmul            d3, d0, d2
    // 0xb782ec: fsub            d0, d1, d3
    // 0xb782f0: stur            d0, [fp, #-0x88]
    // 0xb782f4: LoadField: d4 = r1->field_f
    //     0xb782f4: ldur            d4, [x1, #0xf]
    // 0xb782f8: fsub            d5, d4, d3
    // 0xb782fc: stur            d5, [fp, #-0x70]
    // 0xb78300: r0 = Size()
    //     0xb78300: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb78304: ldur            d0, [fp, #-0x88]
    // 0xb78308: stur            x0, [fp, #-0x50]
    // 0xb7830c: StoreField: r0->field_7 = d0
    //     0xb7830c: stur            d0, [x0, #7]
    // 0xb78310: ldur            d0, [fp, #-0x70]
    // 0xb78314: StoreField: r0->field_f = d0
    //     0xb78314: stur            d0, [x0, #0xf]
    // 0xb78318: ldur            x1, [fp, #-8]
    // 0xb7831c: LoadField: r2 = r1->field_5b
    //     0xb7831c: ldur            w2, [x1, #0x5b]
    // 0xb78320: DecompressPointer r2
    //     0xb78320: add             x2, x2, HEAP, lsl #32
    // 0xb78324: stur            x2, [fp, #-0x48]
    // 0xb78328: cmp             w2, NULL
    // 0xb7832c: b.eq            #0xb7834c
    // 0xb78330: d1 = 0.000000
    //     0xb78330: eor             v1.16b, v1.16b, v1.16b
    // 0xb78334: LoadField: d0 = r2->field_7
    //     0xb78334: ldur            d0, [x2, #7]
    // 0xb78338: fcmp            d0, d1
    // 0xb7833c: r16 = true
    //     0xb7833c: add             x16, NULL, #0x20  ; true
    // 0xb78340: r17 = false
    //     0xb78340: add             x17, NULL, #0x30  ; false
    // 0xb78344: csel            x3, x16, x17, gt
    // 0xb78348: b               #0xb78354
    // 0xb7834c: d1 = 0.000000
    //     0xb7834c: eor             v1.16b, v1.16b, v1.16b
    // 0xb78350: r3 = false
    //     0xb78350: add             x3, NULL, #0x30  ; false
    // 0xb78354: stur            x3, [fp, #-0x40]
    // 0xb78358: LoadField: r4 = r1->field_b
    //     0xb78358: ldur            w4, [x1, #0xb]
    // 0xb7835c: DecompressPointer r4
    //     0xb7835c: add             x4, x4, HEAP, lsl #32
    // 0xb78360: stur            x4, [fp, #-0x18]
    // 0xb78364: cmp             w4, NULL
    // 0xb78368: b.eq            #0xb7873c
    // 0xb7836c: ldur            d0, [fp, #-0x78]
    // 0xb78370: r16 = 136
    //     0xb78370: mov             x16, #0x88
    // 0xb78374: stp             x16, NULL, [SP]
    // 0xb78378: r0 = ByteData()
    //     0xb78378: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb7837c: stur            x0, [fp, #-0x58]
    // 0xb78380: r0 = Paint()
    //     0xb78380: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb78384: ldur            x5, [fp, #-0x58]
    // 0xb78388: stur            x0, [fp, #-0x60]
    // 0xb7838c: StoreField: r0->field_7 = r5
    //     0xb7838c: stur            w5, [x0, #7]
    // 0xb78390: mov             x1, x0
    // 0xb78394: ldur            x2, [fp, #-0x18]
    // 0xb78398: r0 = color=()
    //     0xb78398: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb7839c: ldur            x5, [fp, #-0x58]
    // 0xb783a0: ArrayLoad: r0 = r5[0]  ; List_4
    //     0xb783a0: ldur            w0, [x5, #0x17]
    // 0xb783a4: DecompressPointer r0
    //     0xb783a4: add             x0, x0, HEAP, lsl #32
    // 0xb783a8: LoadField: r1 = r0->field_7
    //     0xb783a8: ldur            x1, [x0, #7]
    // 0xb783ac: ldur            d0, [fp, #-0x78]
    // 0xb783b0: str             s0, [x1, #0x20]
    // 0xb783b4: LoadField: r1 = r0->field_7
    //     0xb783b4: ldur            x1, [x0, #7]
    // 0xb783b8: r2 = 1
    //     0xb783b8: mov             x2, #1
    // 0xb783bc: str             w2, [x1, #0x24]
    // 0xb783c0: LoadField: r1 = r0->field_7
    //     0xb783c0: ldur            x1, [x0, #7]
    // 0xb783c4: str             w2, [x1, #0x1c]
    // 0xb783c8: ldur            x0, [fp, #-0x40]
    // 0xb783cc: tbnz            w0, #4, #0xb78690
    // 0xb783d0: ldur            x0, [fp, #-8]
    // 0xb783d4: LoadField: r1 = r0->field_13
    //     0xb783d4: ldur            w1, [x0, #0x13]
    // 0xb783d8: DecompressPointer r1
    //     0xb783d8: add             x1, x1, HEAP, lsl #32
    // 0xb783dc: cmp             w1, NULL
    // 0xb783e0: b.eq            #0xb78688
    // 0xb783e4: d0 = 0.001000
    //     0xb783e4: ldr             d0, [PP, #0x57a8]  ; [pp+0x57a8] IMM: double(0.001) from 0x3f50624dd2f1a9fc
    // 0xb783e8: LoadField: d1 = r1->field_7
    //     0xb783e8: ldur            d1, [x1, #7]
    // 0xb783ec: stur            d1, [fp, #-0x70]
    // 0xb783f0: fcmp            d1, d0
    // 0xb783f4: b.le            #0xb78680
    // 0xb783f8: ldur            d2, [fp, #-0x80]
    // 0xb783fc: ldur            x3, [fp, #-0x48]
    // 0xb78400: ldur            x1, [fp, #-0x50]
    // 0xb78404: r0 = shortestSide()
    //     0xb78404: bl              #0xb78b04  ; [dart:ui] Size::shortestSide
    // 0xb78408: mov             v1.16b, v0.16b
    // 0xb7840c: d0 = 2.000000
    //     0xb7840c: fmov            d0, #2.00000000
    // 0xb78410: fdiv            d2, d1, d0
    // 0xb78414: ldur            d1, [fp, #-0x80]
    // 0xb78418: fdiv            d3, d1, d2
    // 0xb7841c: ldur            x0, [fp, #-0x48]
    // 0xb78420: cmp             w0, NULL
    // 0xb78424: b.eq            #0xb788d8
    // 0xb78428: LoadField: d1 = r0->field_7
    //     0xb78428: ldur            d1, [x0, #7]
    // 0xb7842c: fdiv            d4, d1, d2
    // 0xb78430: fadd            d1, d3, d4
    // 0xb78434: ldur            d3, [fp, #-0x70]
    // 0xb78438: d2 = 0.001000
    //     0xb78438: ldr             d2, [PP, #0x57a8]  ; [pp+0x57a8] IMM: double(0.001) from 0x3f50624dd2f1a9fc
    // 0xb7843c: fcmp            d2, d3
    // 0xb78440: b.le            #0xb7844c
    // 0xb78444: mov             v4.16b, v1.16b
    // 0xb78448: b               #0xb78454
    // 0xb7844c: fmul            d2, d1, d0
    // 0xb78450: mov             v4.16b, v2.16b
    // 0xb78454: d0 = 0.000000
    //     0xb78454: eor             v0.16b, v0.16b, v0.16b
    // 0xb78458: d2 = -1.570796
    //     0xb78458: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1f148] IMM: double(-1.5707963267948966) from 0xbff921fb54442d18
    //     0xb7845c: ldr             d2, [x17, #0x148]
    // 0xb78460: fadd            d5, d1, d2
    // 0xb78464: stur            d5, [fp, #-0x78]
    // 0xb78468: fcmp            d0, d3
    // 0xb7846c: b.le            #0xb7847c
    // 0xb78470: d3 = 0.000000
    //     0xb78470: eor             v3.16b, v3.16b, v3.16b
    // 0xb78474: d1 = 1.000000
    //     0xb78474: fmov            d1, #1.00000000
    // 0xb78478: b               #0xb7849c
    // 0xb7847c: d1 = 1.000000
    //     0xb7847c: fmov            d1, #1.00000000
    // 0xb78480: fcmp            d3, d1
    // 0xb78484: b.le            #0xb78490
    // 0xb78488: d3 = 1.000000
    //     0xb78488: fmov            d3, #1.00000000
    // 0xb7848c: b               #0xb7849c
    // 0xb78490: fcmp            d3, d3
    // 0xb78494: b.vc            #0xb7849c
    // 0xb78498: d3 = 1.000000
    //     0xb78498: fmov            d3, #1.00000000
    // 0xb7849c: ldur            x0, [fp, #-0x10]
    // 0xb784a0: d2 = 6.283185
    //     0xb784a0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13298] IMM: double(6.283185307179586) from 0x401921fb54442d18
    //     0xb784a4: ldr             d2, [x17, #0x298]
    // 0xb784a8: fmul            d6, d3, d2
    // 0xb784ac: fsub            d3, d2, d6
    // 0xb784b0: fsub            d2, d3, d4
    // 0xb784b4: fmax            v3.2d, v0.2d, v2.2d
    // 0xb784b8: stur            d3, [fp, #-0x70]
    // 0xb784bc: LoadField: r1 = r0->field_7
    //     0xb784bc: ldur            w1, [x0, #7]
    // 0xb784c0: DecompressPointer r1
    //     0xb784c0: add             x1, x1, HEAP, lsl #32
    // 0xb784c4: cmp             w1, NULL
    // 0xb784c8: b.eq            #0xb788dc
    // 0xb784cc: LoadField: r2 = r1->field_7
    //     0xb784cc: ldur            x2, [x1, #7]
    // 0xb784d0: ldr             x1, [x2]
    // 0xb784d4: cbz             x1, #0xb78860
    // 0xb784d8: mov             x2, x1
    // 0xb784dc: stur            x2, [fp, #-0x68]
    // 0xb784e0: r1 = <Never>
    //     0xb784e0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb784e4: r0 = Pointer()
    //     0xb784e4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb784e8: mov             x1, x0
    // 0xb784ec: ldur            x0, [fp, #-0x68]
    // 0xb784f0: StoreField: r1->field_7 = r0
    //     0xb784f0: stur            x0, [x1, #7]
    // 0xb784f4: r0 = _save$Method$FfiNative()
    //     0xb784f4: bl              #0xb74adc  ; [dart:ui] _NativeCanvas::_save$Method$FfiNative
    // 0xb784f8: ldur            x0, [fp, #-0x10]
    // 0xb784fc: LoadField: r1 = r0->field_7
    //     0xb784fc: ldur            w1, [x0, #7]
    // 0xb78500: DecompressPointer r1
    //     0xb78500: add             x1, x1, HEAP, lsl #32
    // 0xb78504: cmp             w1, NULL
    // 0xb78508: b.eq            #0xb788e0
    // 0xb7850c: LoadField: r2 = r1->field_7
    //     0xb7850c: ldur            x2, [x1, #7]
    // 0xb78510: ldr             x1, [x2]
    // 0xb78514: cbz             x1, #0xb78870
    // 0xb78518: ldur            d0, [fp, #-0x90]
    // 0xb7851c: mov             x2, x1
    // 0xb78520: stur            x2, [fp, #-0x68]
    // 0xb78524: r1 = <Never>
    //     0xb78524: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb78528: r0 = Pointer()
    //     0xb78528: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb7852c: mov             x1, x0
    // 0xb78530: ldur            x0, [fp, #-0x68]
    // 0xb78534: StoreField: r1->field_7 = r0
    //     0xb78534: stur            x0, [x1, #7]
    // 0xb78538: d0 = -1.000000
    //     0xb78538: fmov            d0, #-1.00000000
    // 0xb7853c: d1 = 1.000000
    //     0xb7853c: fmov            d1, #1.00000000
    // 0xb78540: r0 = __scale$Method$FfiNative()
    //     0xb78540: bl              #0xb76308  ; [dart:ui] _NativeCanvas::__scale$Method$FfiNative
    // 0xb78544: ldur            d0, [fp, #-0x90]
    // 0xb78548: fneg            d1, d0
    // 0xb7854c: ldur            x0, [fp, #-0x10]
    // 0xb78550: stur            d1, [fp, #-0x80]
    // 0xb78554: LoadField: r1 = r0->field_7
    //     0xb78554: ldur            w1, [x0, #7]
    // 0xb78558: DecompressPointer r1
    //     0xb78558: add             x1, x1, HEAP, lsl #32
    // 0xb7855c: cmp             w1, NULL
    // 0xb78560: b.eq            #0xb788e4
    // 0xb78564: LoadField: r2 = r1->field_7
    //     0xb78564: ldur            x2, [x1, #7]
    // 0xb78568: ldr             x1, [x2]
    // 0xb7856c: cbz             x1, #0xb78880
    // 0xb78570: ldur            x2, [fp, #-0x60]
    // 0xb78574: mov             x3, x1
    // 0xb78578: stur            x3, [fp, #-0x68]
    // 0xb7857c: r1 = <Never>
    //     0xb7857c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb78580: r0 = Pointer()
    //     0xb78580: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb78584: mov             x1, x0
    // 0xb78588: ldur            x0, [fp, #-0x68]
    // 0xb7858c: StoreField: r1->field_7 = r0
    //     0xb7858c: stur            x0, [x1, #7]
    // 0xb78590: ldur            d0, [fp, #-0x80]
    // 0xb78594: d1 = 0.000000
    //     0xb78594: eor             v1.16b, v1.16b, v1.16b
    // 0xb78598: r0 = _translate$Method$FfiNative()
    //     0xb78598: bl              #0xb74a38  ; [dart:ui] _NativeCanvas::_translate$Method$FfiNative
    // 0xb7859c: ldur            x1, [fp, #-0x38]
    // 0xb785a0: ldur            x2, [fp, #-0x50]
    // 0xb785a4: r0 = &()
    //     0xb785a4: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xb785a8: LoadField: d0 = r0->field_7
    //     0xb785a8: ldur            d0, [x0, #7]
    // 0xb785ac: stur            d0, [fp, #-0x98]
    // 0xb785b0: LoadField: d1 = r0->field_f
    //     0xb785b0: ldur            d1, [x0, #0xf]
    // 0xb785b4: stur            d1, [fp, #-0x90]
    // 0xb785b8: ArrayLoad: d2 = r0[0]  ; List_8
    //     0xb785b8: ldur            d2, [x0, #0x17]
    // 0xb785bc: stur            d2, [fp, #-0x88]
    // 0xb785c0: LoadField: d3 = r0->field_1f
    //     0xb785c0: ldur            d3, [x0, #0x1f]
    // 0xb785c4: ldur            x0, [fp, #-0x60]
    // 0xb785c8: stur            d3, [fp, #-0x80]
    // 0xb785cc: LoadField: r3 = r0->field_b
    //     0xb785cc: ldur            w3, [x0, #0xb]
    // 0xb785d0: DecompressPointer r3
    //     0xb785d0: add             x3, x3, HEAP, lsl #32
    // 0xb785d4: ldur            x0, [fp, #-0x10]
    // 0xb785d8: stur            x3, [fp, #-0x18]
    // 0xb785dc: LoadField: r1 = r0->field_7
    //     0xb785dc: ldur            w1, [x0, #7]
    // 0xb785e0: DecompressPointer r1
    //     0xb785e0: add             x1, x1, HEAP, lsl #32
    // 0xb785e4: cmp             w1, NULL
    // 0xb785e8: b.eq            #0xb788e8
    // 0xb785ec: LoadField: r2 = r1->field_7
    //     0xb785ec: ldur            x2, [x1, #7]
    // 0xb785f0: ldr             x1, [x2]
    // 0xb785f4: cbz             x1, #0xb78890
    // 0xb785f8: mov             x2, x1
    // 0xb785fc: stur            x2, [fp, #-0x68]
    // 0xb78600: r1 = <Never>
    //     0xb78600: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb78604: r0 = Pointer()
    //     0xb78604: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb78608: mov             x1, x0
    // 0xb7860c: ldur            x0, [fp, #-0x68]
    // 0xb78610: StoreField: r1->field_7 = r0
    //     0xb78610: stur            x0, [x1, #7]
    // 0xb78614: ldur            d0, [fp, #-0x98]
    // 0xb78618: ldur            d1, [fp, #-0x90]
    // 0xb7861c: ldur            d2, [fp, #-0x88]
    // 0xb78620: ldur            d3, [fp, #-0x80]
    // 0xb78624: ldur            d4, [fp, #-0x78]
    // 0xb78628: ldur            d5, [fp, #-0x70]
    // 0xb7862c: ldur            x3, [fp, #-0x18]
    // 0xb78630: ldur            x5, [fp, #-0x58]
    // 0xb78634: r2 = false
    //     0xb78634: add             x2, NULL, #0x30  ; false
    // 0xb78638: r0 = __drawArc$Method$FfiNative()
    //     0xb78638: bl              #0xb788f8  ; [dart:ui] _NativeCanvas::__drawArc$Method$FfiNative
    // 0xb7863c: ldur            x0, [fp, #-0x10]
    // 0xb78640: LoadField: r1 = r0->field_7
    //     0xb78640: ldur            w1, [x0, #7]
    // 0xb78644: DecompressPointer r1
    //     0xb78644: add             x1, x1, HEAP, lsl #32
    // 0xb78648: cmp             w1, NULL
    // 0xb7864c: b.eq            #0xb788ec
    // 0xb78650: LoadField: r2 = r1->field_7
    //     0xb78650: ldur            x2, [x1, #7]
    // 0xb78654: ldr             x1, [x2]
    // 0xb78658: cbz             x1, #0xb788a0
    // 0xb7865c: mov             x2, x1
    // 0xb78660: stur            x2, [fp, #-0x68]
    // 0xb78664: r1 = <Never>
    //     0xb78664: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb78668: r0 = Pointer()
    //     0xb78668: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb7866c: mov             x1, x0
    // 0xb78670: ldur            x0, [fp, #-0x68]
    // 0xb78674: StoreField: r1->field_7 = r0
    //     0xb78674: stur            x0, [x1, #7]
    // 0xb78678: r0 = _restore$Method$FfiNative()
    //     0xb78678: bl              #0xb74908  ; [dart:ui] _NativeCanvas::_restore$Method$FfiNative
    // 0xb7867c: b               #0xb7873c
    // 0xb78680: ldur            x0, [fp, #-0x60]
    // 0xb78684: b               #0xb78694
    // 0xb78688: ldur            x0, [fp, #-0x60]
    // 0xb7868c: b               #0xb78694
    // 0xb78690: ldur            x0, [fp, #-0x60]
    // 0xb78694: ldur            x3, [fp, #-0x10]
    // 0xb78698: ldur            x1, [fp, #-0x38]
    // 0xb7869c: ldur            x2, [fp, #-0x50]
    // 0xb786a0: r0 = &()
    //     0xb786a0: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xb786a4: LoadField: d0 = r0->field_7
    //     0xb786a4: ldur            d0, [x0, #7]
    // 0xb786a8: stur            d0, [fp, #-0x88]
    // 0xb786ac: LoadField: d1 = r0->field_f
    //     0xb786ac: ldur            d1, [x0, #0xf]
    // 0xb786b0: stur            d1, [fp, #-0x80]
    // 0xb786b4: ArrayLoad: d2 = r0[0]  ; List_8
    //     0xb786b4: ldur            d2, [x0, #0x17]
    // 0xb786b8: stur            d2, [fp, #-0x78]
    // 0xb786bc: LoadField: d3 = r0->field_1f
    //     0xb786bc: ldur            d3, [x0, #0x1f]
    // 0xb786c0: ldur            x0, [fp, #-0x60]
    // 0xb786c4: stur            d3, [fp, #-0x70]
    // 0xb786c8: LoadField: r3 = r0->field_b
    //     0xb786c8: ldur            w3, [x0, #0xb]
    // 0xb786cc: DecompressPointer r3
    //     0xb786cc: add             x3, x3, HEAP, lsl #32
    // 0xb786d0: ldur            x0, [fp, #-0x10]
    // 0xb786d4: stur            x3, [fp, #-0x18]
    // 0xb786d8: LoadField: r1 = r0->field_7
    //     0xb786d8: ldur            w1, [x0, #7]
    // 0xb786dc: DecompressPointer r1
    //     0xb786dc: add             x1, x1, HEAP, lsl #32
    // 0xb786e0: cmp             w1, NULL
    // 0xb786e4: b.eq            #0xb788f0
    // 0xb786e8: LoadField: r2 = r1->field_7
    //     0xb786e8: ldur            x2, [x1, #7]
    // 0xb786ec: ldr             x1, [x2]
    // 0xb786f0: cbz             x1, #0xb788b0
    // 0xb786f4: mov             x2, x1
    // 0xb786f8: stur            x2, [fp, #-0x68]
    // 0xb786fc: r1 = <Never>
    //     0xb786fc: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb78700: r0 = Pointer()
    //     0xb78700: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb78704: mov             x1, x0
    // 0xb78708: ldur            x0, [fp, #-0x68]
    // 0xb7870c: StoreField: r1->field_7 = r0
    //     0xb7870c: stur            x0, [x1, #7]
    // 0xb78710: ldur            d0, [fp, #-0x88]
    // 0xb78714: ldur            d1, [fp, #-0x80]
    // 0xb78718: ldur            d2, [fp, #-0x78]
    // 0xb7871c: ldur            d3, [fp, #-0x70]
    // 0xb78720: ldur            x3, [fp, #-0x18]
    // 0xb78724: ldur            x5, [fp, #-0x58]
    // 0xb78728: d4 = 0.000000
    //     0xb78728: eor             v4.16b, v4.16b, v4.16b
    // 0xb7872c: d5 = 6.282185
    //     0xb7872c: add             x17, PP, #0x8f, lsl #12  ; [pp+0x8fbc0] IMM: double(6.282185307179586) from 0x401920f52f66fdfd
    //     0xb78730: ldr             d5, [x17, #0xbc0]
    // 0xb78734: r2 = false
    //     0xb78734: add             x2, NULL, #0x30  ; false
    // 0xb78738: r0 = __drawArc$Method$FfiNative()
    //     0xb78738: bl              #0xb788f8  ; [dart:ui] _NativeCanvas::__drawArc$Method$FfiNative
    // 0xb7873c: ldur            x0, [fp, #-8]
    // 0xb78740: LoadField: r1 = r0->field_5f
    //     0xb78740: ldur            w1, [x0, #0x5f]
    // 0xb78744: DecompressPointer r1
    //     0xb78744: add             x1, x1, HEAP, lsl #32
    // 0xb78748: tbnz            w1, #4, #0xb78780
    // 0xb7874c: LoadField: r1 = r0->field_13
    //     0xb7874c: ldur            w1, [x0, #0x13]
    // 0xb78750: DecompressPointer r1
    //     0xb78750: add             x1, x1, HEAP, lsl #32
    // 0xb78754: cmp             w1, NULL
    // 0xb78758: b.ne            #0xb78770
    // 0xb7875c: ldur            x1, [fp, #-0x30]
    // 0xb78760: r2 = 2
    //     0xb78760: mov             x2, #2
    // 0xb78764: LoadField: r3 = r1->field_7
    //     0xb78764: ldur            x3, [x1, #7]
    // 0xb78768: str             w2, [x3, #0x24]
    // 0xb7876c: b               #0xb78790
    // 0xb78770: ldur            x1, [fp, #-0x30]
    // 0xb78774: LoadField: r2 = r1->field_7
    //     0xb78774: ldur            x2, [x1, #7]
    // 0xb78778: str             wzr, [x2, #0x24]
    // 0xb7877c: b               #0xb78790
    // 0xb78780: ldur            x1, [fp, #-0x30]
    // 0xb78784: r2 = 1
    //     0xb78784: mov             x2, #1
    // 0xb78788: LoadField: r3 = r1->field_7
    //     0xb78788: ldur            x3, [x1, #7]
    // 0xb7878c: str             w2, [x3, #0x24]
    // 0xb78790: ldur            x3, [fp, #-0x10]
    // 0xb78794: ldur            x4, [fp, #-0x28]
    // 0xb78798: ldur            x1, [fp, #-0x38]
    // 0xb7879c: ldur            x2, [fp, #-0x50]
    // 0xb787a0: r0 = &()
    //     0xb787a0: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xb787a4: mov             x1, x0
    // 0xb787a8: ldur            x0, [fp, #-8]
    // 0xb787ac: LoadField: d4 = r0->field_47
    //     0xb787ac: ldur            d4, [x0, #0x47]
    // 0xb787b0: stur            d4, [fp, #-0x98]
    // 0xb787b4: LoadField: d5 = r0->field_4f
    //     0xb787b4: ldur            d5, [x0, #0x4f]
    // 0xb787b8: stur            d5, [fp, #-0x90]
    // 0xb787bc: LoadField: d0 = r1->field_7
    //     0xb787bc: ldur            d0, [x1, #7]
    // 0xb787c0: stur            d0, [fp, #-0x88]
    // 0xb787c4: LoadField: d1 = r1->field_f
    //     0xb787c4: ldur            d1, [x1, #0xf]
    // 0xb787c8: stur            d1, [fp, #-0x80]
    // 0xb787cc: ArrayLoad: d2 = r1[0]  ; List_8
    //     0xb787cc: ldur            d2, [x1, #0x17]
    // 0xb787d0: stur            d2, [fp, #-0x78]
    // 0xb787d4: LoadField: d3 = r1->field_1f
    //     0xb787d4: ldur            d3, [x1, #0x1f]
    // 0xb787d8: ldur            x0, [fp, #-0x28]
    // 0xb787dc: stur            d3, [fp, #-0x70]
    // 0xb787e0: LoadField: r3 = r0->field_b
    //     0xb787e0: ldur            w3, [x0, #0xb]
    // 0xb787e4: DecompressPointer r3
    //     0xb787e4: add             x3, x3, HEAP, lsl #32
    // 0xb787e8: ldur            x0, [fp, #-0x10]
    // 0xb787ec: stur            x3, [fp, #-8]
    // 0xb787f0: LoadField: r1 = r0->field_7
    //     0xb787f0: ldur            w1, [x0, #7]
    // 0xb787f4: DecompressPointer r1
    //     0xb787f4: add             x1, x1, HEAP, lsl #32
    // 0xb787f8: cmp             w1, NULL
    // 0xb787fc: b.eq            #0xb788f4
    // 0xb78800: LoadField: r2 = r1->field_7
    //     0xb78800: ldur            x2, [x1, #7]
    // 0xb78804: ldr             x1, [x2]
    // 0xb78808: cbz             x1, #0xb788c0
    // 0xb7880c: mov             x2, x1
    // 0xb78810: stur            x2, [fp, #-0x68]
    // 0xb78814: r1 = <Never>
    //     0xb78814: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb78818: r0 = Pointer()
    //     0xb78818: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb7881c: mov             x1, x0
    // 0xb78820: ldur            x0, [fp, #-0x68]
    // 0xb78824: StoreField: r1->field_7 = r0
    //     0xb78824: stur            x0, [x1, #7]
    // 0xb78828: ldur            d0, [fp, #-0x88]
    // 0xb7882c: ldur            d1, [fp, #-0x80]
    // 0xb78830: ldur            d2, [fp, #-0x78]
    // 0xb78834: ldur            d3, [fp, #-0x70]
    // 0xb78838: ldur            d4, [fp, #-0x98]
    // 0xb7883c: ldur            d5, [fp, #-0x90]
    // 0xb78840: ldur            x3, [fp, #-8]
    // 0xb78844: ldur            x5, [fp, #-0x20]
    // 0xb78848: r2 = false
    //     0xb78848: add             x2, NULL, #0x30  ; false
    // 0xb7884c: r0 = __drawArc$Method$FfiNative()
    //     0xb7884c: bl              #0xb788f8  ; [dart:ui] _NativeCanvas::__drawArc$Method$FfiNative
    // 0xb78850: r0 = Null
    //     0xb78850: mov             x0, NULL
    // 0xb78854: LeaveFrame
    //     0xb78854: mov             SP, fp
    //     0xb78858: ldp             fp, lr, [SP], #0x10
    // 0xb7885c: ret
    //     0xb7885c: ret             
    // 0xb78860: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb78860: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb78864: str             x16, [SP]
    // 0xb78868: r0 = _throwNew()
    //     0xb78868: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb7886c: brk             #0
    // 0xb78870: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb78870: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb78874: str             x16, [SP]
    // 0xb78878: r0 = _throwNew()
    //     0xb78878: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb7887c: brk             #0
    // 0xb78880: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb78880: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb78884: str             x16, [SP]
    // 0xb78888: r0 = _throwNew()
    //     0xb78888: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb7888c: brk             #0
    // 0xb78890: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb78890: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb78894: str             x16, [SP]
    // 0xb78898: r0 = _throwNew()
    //     0xb78898: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb7889c: brk             #0
    // 0xb788a0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb788a0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb788a4: str             x16, [SP]
    // 0xb788a8: r0 = _throwNew()
    //     0xb788a8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb788ac: brk             #0
    // 0xb788b0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb788b0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb788b4: str             x16, [SP]
    // 0xb788b8: r0 = _throwNew()
    //     0xb788b8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb788bc: brk             #0
    // 0xb788c0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb788c0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb788c4: str             x16, [SP]
    // 0xb788c8: r0 = _throwNew()
    //     0xb788c8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb788cc: brk             #0
    // 0xb788d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb788d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb788d4: b               #0xb78240
    // 0xb788d8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb788d8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb788dc: r0 = NullErrorSharedWithFPURegs()
    //     0xb788dc: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb788e0: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb788e0: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb788e4: r0 = NullErrorSharedWithFPURegs()
    //     0xb788e4: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb788e8: r0 = NullErrorSharedWithFPURegs()
    //     0xb788e8: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb788ec: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb788ec: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb788f0: r0 = NullErrorSharedWithFPURegs()
    //     0xb788f0: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb788f4: r0 = NullErrorSharedWithFPURegs()
    //     0xb788f4: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xb93944, size: 0x1f0
    // 0xb93944: EnterFrame
    //     0xb93944: stp             fp, lr, [SP, #-0x10]!
    //     0xb93948: mov             fp, SP
    // 0xb9394c: AllocStack(0x20)
    //     0xb9394c: sub             SP, SP, #0x20
    // 0xb93950: SetupParameters(_CircularProgressIndicatorPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xb93950: mov             x4, x1
    //     0xb93954: mov             x3, x2
    //     0xb93958: stur            x1, [fp, #-8]
    //     0xb9395c: stur            x2, [fp, #-0x10]
    // 0xb93960: CheckStackOverflow
    //     0xb93960: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb93964: cmp             SP, x16
    //     0xb93968: b.ls            #0xb93b2c
    // 0xb9396c: mov             x0, x3
    // 0xb93970: r2 = Null
    //     0xb93970: mov             x2, NULL
    // 0xb93974: r1 = Null
    //     0xb93974: mov             x1, NULL
    // 0xb93978: r4 = 60
    //     0xb93978: mov             x4, #0x3c
    // 0xb9397c: branchIfSmi(r0, 0xb93988)
    //     0xb9397c: tbz             w0, #0, #0xb93988
    // 0xb93980: r4 = LoadClassIdInstr(r0)
    //     0xb93980: ldur            x4, [x0, #-1]
    //     0xb93984: ubfx            x4, x4, #0xc, #0x14
    // 0xb93988: r17 = -4333
    //     0xb93988: mov             x17, #-0x10ed
    // 0xb9398c: add             x4, x4, x17
    // 0xb93990: cmp             x4, #1
    // 0xb93994: b.ls            #0xb939ac
    // 0xb93998: r8 = _CircularProgressIndicatorPainter
    //     0xb93998: add             x8, PP, #0x99, lsl #12  ; [pp+0x99068] Type: _CircularProgressIndicatorPainter
    //     0xb9399c: ldr             x8, [x8, #0x68]
    // 0xb939a0: r3 = Null
    //     0xb939a0: add             x3, PP, #0x99, lsl #12  ; [pp+0x99070] Null
    //     0xb939a4: ldr             x3, [x3, #0x70]
    // 0xb939a8: r0 = DefaultTypeTest()
    //     0xb939a8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb939ac: ldur            x1, [fp, #-0x10]
    // 0xb939b0: LoadField: r0 = r1->field_b
    //     0xb939b0: ldur            w0, [x1, #0xb]
    // 0xb939b4: DecompressPointer r0
    //     0xb939b4: add             x0, x0, HEAP, lsl #32
    // 0xb939b8: ldur            x2, [fp, #-8]
    // 0xb939bc: LoadField: r3 = r2->field_b
    //     0xb939bc: ldur            w3, [x2, #0xb]
    // 0xb939c0: DecompressPointer r3
    //     0xb939c0: add             x3, x3, HEAP, lsl #32
    // 0xb939c4: r4 = LoadClassIdInstr(r0)
    //     0xb939c4: ldur            x4, [x0, #-1]
    //     0xb939c8: ubfx            x4, x4, #0xc, #0x14
    // 0xb939cc: stp             x3, x0, [SP]
    // 0xb939d0: mov             x0, x4
    // 0xb939d4: mov             lr, x0
    // 0xb939d8: ldr             lr, [x21, lr, lsl #3]
    // 0xb939dc: blr             lr
    // 0xb939e0: tbnz            w0, #4, #0xb93aec
    // 0xb939e4: ldur            x2, [fp, #-8]
    // 0xb939e8: ldur            x1, [fp, #-0x10]
    // 0xb939ec: LoadField: r0 = r1->field_f
    //     0xb939ec: ldur            w0, [x1, #0xf]
    // 0xb939f0: DecompressPointer r0
    //     0xb939f0: add             x0, x0, HEAP, lsl #32
    // 0xb939f4: LoadField: r3 = r2->field_f
    //     0xb939f4: ldur            w3, [x2, #0xf]
    // 0xb939f8: DecompressPointer r3
    //     0xb939f8: add             x3, x3, HEAP, lsl #32
    // 0xb939fc: r4 = LoadClassIdInstr(r0)
    //     0xb939fc: ldur            x4, [x0, #-1]
    //     0xb93a00: ubfx            x4, x4, #0xc, #0x14
    // 0xb93a04: stp             x3, x0, [SP]
    // 0xb93a08: mov             x0, x4
    // 0xb93a0c: mov             lr, x0
    // 0xb93a10: ldr             lr, [x21, lr, lsl #3]
    // 0xb93a14: blr             lr
    // 0xb93a18: tbnz            w0, #4, #0xb93aec
    // 0xb93a1c: ldur            x2, [fp, #-8]
    // 0xb93a20: ldur            x1, [fp, #-0x10]
    // 0xb93a24: LoadField: r0 = r1->field_13
    //     0xb93a24: ldur            w0, [x1, #0x13]
    // 0xb93a28: DecompressPointer r0
    //     0xb93a28: add             x0, x0, HEAP, lsl #32
    // 0xb93a2c: LoadField: r3 = r2->field_13
    //     0xb93a2c: ldur            w3, [x2, #0x13]
    // 0xb93a30: DecompressPointer r3
    //     0xb93a30: add             x3, x3, HEAP, lsl #32
    // 0xb93a34: r4 = LoadClassIdInstr(r0)
    //     0xb93a34: ldur            x4, [x0, #-1]
    //     0xb93a38: ubfx            x4, x4, #0xc, #0x14
    // 0xb93a3c: stp             x3, x0, [SP]
    // 0xb93a40: mov             x0, x4
    // 0xb93a44: mov             lr, x0
    // 0xb93a48: ldr             lr, [x21, lr, lsl #3]
    // 0xb93a4c: blr             lr
    // 0xb93a50: tbnz            w0, #4, #0xb93aec
    // 0xb93a54: ldur            x2, [fp, #-8]
    // 0xb93a58: ldur            x1, [fp, #-0x10]
    // 0xb93a5c: ArrayLoad: d0 = r1[0]  ; List_8
    //     0xb93a5c: ldur            d0, [x1, #0x17]
    // 0xb93a60: ArrayLoad: d1 = r2[0]  ; List_8
    //     0xb93a60: ldur            d1, [x2, #0x17]
    // 0xb93a64: fcmp            d0, d1
    // 0xb93a68: b.ne            #0xb93aec
    // 0xb93a6c: LoadField: d0 = r1->field_1f
    //     0xb93a6c: ldur            d0, [x1, #0x1f]
    // 0xb93a70: LoadField: d1 = r2->field_1f
    //     0xb93a70: ldur            d1, [x2, #0x1f]
    // 0xb93a74: fcmp            d0, d1
    // 0xb93a78: b.ne            #0xb93aec
    // 0xb93a7c: LoadField: d0 = r1->field_27
    //     0xb93a7c: ldur            d0, [x1, #0x27]
    // 0xb93a80: LoadField: d1 = r2->field_27
    //     0xb93a80: ldur            d1, [x2, #0x27]
    // 0xb93a84: fcmp            d0, d1
    // 0xb93a88: b.ne            #0xb93aec
    // 0xb93a8c: LoadField: d0 = r1->field_2f
    //     0xb93a8c: ldur            d0, [x1, #0x2f]
    // 0xb93a90: LoadField: d1 = r2->field_2f
    //     0xb93a90: ldur            d1, [x2, #0x2f]
    // 0xb93a94: fcmp            d0, d1
    // 0xb93a98: b.ne            #0xb93aec
    // 0xb93a9c: LoadField: d0 = r1->field_37
    //     0xb93a9c: ldur            d0, [x1, #0x37]
    // 0xb93aa0: LoadField: d1 = r2->field_37
    //     0xb93aa0: ldur            d1, [x2, #0x37]
    // 0xb93aa4: fcmp            d0, d1
    // 0xb93aa8: b.ne            #0xb93aec
    // 0xb93aac: LoadField: d0 = r1->field_3f
    //     0xb93aac: ldur            d0, [x1, #0x3f]
    // 0xb93ab0: LoadField: d1 = r2->field_3f
    //     0xb93ab0: ldur            d1, [x2, #0x3f]
    // 0xb93ab4: fcmp            d0, d1
    // 0xb93ab8: b.ne            #0xb93aec
    // 0xb93abc: LoadField: r0 = r1->field_5b
    //     0xb93abc: ldur            w0, [x1, #0x5b]
    // 0xb93ac0: DecompressPointer r0
    //     0xb93ac0: add             x0, x0, HEAP, lsl #32
    // 0xb93ac4: LoadField: r3 = r2->field_5b
    //     0xb93ac4: ldur            w3, [x2, #0x5b]
    // 0xb93ac8: DecompressPointer r3
    //     0xb93ac8: add             x3, x3, HEAP, lsl #32
    // 0xb93acc: r4 = LoadClassIdInstr(r0)
    //     0xb93acc: ldur            x4, [x0, #-1]
    //     0xb93ad0: ubfx            x4, x4, #0xc, #0x14
    // 0xb93ad4: stp             x3, x0, [SP]
    // 0xb93ad8: mov             x0, x4
    // 0xb93adc: mov             lr, x0
    // 0xb93ae0: ldr             lr, [x21, lr, lsl #3]
    // 0xb93ae4: blr             lr
    // 0xb93ae8: tbz             w0, #4, #0xb93af4
    // 0xb93aec: r0 = true
    //     0xb93aec: add             x0, NULL, #0x20  ; true
    // 0xb93af0: b               #0xb93b20
    // 0xb93af4: ldur            x2, [fp, #-8]
    // 0xb93af8: ldur            x1, [fp, #-0x10]
    // 0xb93afc: LoadField: r3 = r1->field_5f
    //     0xb93afc: ldur            w3, [x1, #0x5f]
    // 0xb93b00: DecompressPointer r3
    //     0xb93b00: add             x3, x3, HEAP, lsl #32
    // 0xb93b04: LoadField: r1 = r2->field_5f
    //     0xb93b04: ldur            w1, [x2, #0x5f]
    // 0xb93b08: DecompressPointer r1
    //     0xb93b08: add             x1, x1, HEAP, lsl #32
    // 0xb93b0c: cmp             w3, w1
    // 0xb93b10: r16 = true
    //     0xb93b10: add             x16, NULL, #0x20  ; true
    // 0xb93b14: r17 = false
    //     0xb93b14: add             x17, NULL, #0x30  ; false
    // 0xb93b18: csel            x2, x16, x17, ne
    // 0xb93b1c: mov             x0, x2
    // 0xb93b20: LeaveFrame
    //     0xb93b20: mov             SP, fp
    //     0xb93b24: ldp             fp, lr, [SP], #0x10
    // 0xb93b28: ret
    //     0xb93b28: ret             
    // 0xb93b2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb93b2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb93b30: b               #0xb9396c
  }
  _ _CircularProgressIndicatorPainter(/* No info */) {
    // ** addr: 0xd31bb4, size: 0x298
    // 0xd31bb4: EnterFrame
    //     0xd31bb4: stp             fp, lr, [SP, #-0x10]!
    //     0xd31bb8: mov             fp, SP
    // 0xd31bbc: mov             x16, x3
    // 0xd31bc0: mov             x3, x1
    // 0xd31bc4: mov             x1, x16
    // 0xd31bc8: LoadField: r5 = r4->field_13
    //     0xd31bc8: ldur            w5, [x4, #0x13]
    // 0xd31bcc: LoadField: r6 = r4->field_1f
    //     0xd31bcc: ldur            w6, [x4, #0x1f]
    // 0xd31bd0: DecompressPointer r6
    //     0xd31bd0: add             x6, x6, HEAP, lsl #32
    // 0xd31bd4: r16 = "trackColor"
    //     0xd31bd4: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fba8] "trackColor"
    //     0xd31bd8: ldr             x16, [x16, #0xba8]
    // 0xd31bdc: cmp             w6, w16
    // 0xd31be0: b.ne            #0xd31c04
    // 0xd31be4: LoadField: r6 = r4->field_23
    //     0xd31be4: ldur            w6, [x4, #0x23]
    // 0xd31be8: DecompressPointer r6
    //     0xd31be8: add             x6, x6, HEAP, lsl #32
    // 0xd31bec: sub             w7, w5, w6
    // 0xd31bf0: add             x6, fp, w7, sxtw #2
    // 0xd31bf4: ldr             x6, [x6, #8]
    // 0xd31bf8: mov             x0, x6
    // 0xd31bfc: r6 = 1
    //     0xd31bfc: mov             x6, #1
    // 0xd31c00: b               #0xd31c0c
    // 0xd31c04: r0 = Null
    //     0xd31c04: mov             x0, NULL
    // 0xd31c08: r6 = 0
    //     0xd31c08: mov             x6, #0
    // 0xd31c0c: lsl             x7, x6, #1
    // 0xd31c10: lsl             w8, w7, #1
    // 0xd31c14: add             w9, w8, #8
    // 0xd31c18: ArrayLoad: r10 = r4[r9]  ; Unknown_4
    //     0xd31c18: add             x16, x4, w9, sxtw #1
    //     0xd31c1c: ldur            w10, [x16, #0xf]
    // 0xd31c20: DecompressPointer r10
    //     0xd31c20: add             x10, x10, HEAP, lsl #32
    // 0xd31c24: r16 = "trackGap"
    //     0xd31c24: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fbb0] "trackGap"
    //     0xd31c28: ldr             x16, [x16, #0xbb0]
    // 0xd31c2c: cmp             w10, w16
    // 0xd31c30: b.ne            #0xd31c64
    // 0xd31c34: add             w9, w8, #0xa
    // 0xd31c38: ArrayLoad: r8 = r4[r9]  ; Unknown_4
    //     0xd31c38: add             x16, x4, w9, sxtw #1
    //     0xd31c3c: ldur            w8, [x16, #0xf]
    // 0xd31c40: DecompressPointer r8
    //     0xd31c40: add             x8, x8, HEAP, lsl #32
    // 0xd31c44: sub             w9, w5, w8
    // 0xd31c48: add             x8, fp, w9, sxtw #2
    // 0xd31c4c: ldr             x8, [x8, #8]
    // 0xd31c50: add             w9, w7, #2
    // 0xd31c54: r7 = LoadInt32Instr(r9)
    //     0xd31c54: sbfx            x7, x9, #1, #0x1f
    // 0xd31c58: mov             x6, x7
    // 0xd31c5c: mov             x7, x8
    // 0xd31c60: b               #0xd31c68
    // 0xd31c64: r7 = Null
    //     0xd31c64: mov             x7, NULL
    // 0xd31c68: lsl             x8, x6, #1
    // 0xd31c6c: lsl             w6, w8, #1
    // 0xd31c70: add             w8, w6, #8
    // 0xd31c74: ArrayLoad: r9 = r4[r8]  ; Unknown_4
    //     0xd31c74: add             x16, x4, w8, sxtw #1
    //     0xd31c78: ldur            w9, [x16, #0xf]
    // 0xd31c7c: DecompressPointer r9
    //     0xd31c7c: add             x9, x9, HEAP, lsl #32
    // 0xd31c80: r16 = "year2023"
    //     0xd31c80: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fbb8] "year2023"
    //     0xd31c84: ldr             x16, [x16, #0xbb8]
    // 0xd31c88: cmp             w9, w16
    // 0xd31c8c: b.ne            #0xd31cb4
    // 0xd31c90: add             w8, w6, #0xa
    // 0xd31c94: ArrayLoad: r6 = r4[r8]  ; Unknown_4
    //     0xd31c94: add             x16, x4, w8, sxtw #1
    //     0xd31c98: ldur            w6, [x16, #0xf]
    // 0xd31c9c: DecompressPointer r6
    //     0xd31c9c: add             x6, x6, HEAP, lsl #32
    // 0xd31ca0: sub             w4, w5, w6
    // 0xd31ca4: add             x5, fp, w4, sxtw #2
    // 0xd31ca8: ldr             x5, [x5, #8]
    // 0xd31cac: mov             x4, x5
    // 0xd31cb0: b               #0xd31cb8
    // 0xd31cb4: r4 = true
    //     0xd31cb4: add             x4, NULL, #0x20  ; true
    // 0xd31cb8: StoreField: r3->field_b = r0
    //     0xd31cb8: stur            w0, [x3, #0xb]
    //     0xd31cbc: ldurb           w16, [x3, #-1]
    //     0xd31cc0: ldurb           w17, [x0, #-1]
    //     0xd31cc4: and             x16, x17, x16, lsr #2
    //     0xd31cc8: tst             x16, HEAP, lsr #32
    //     0xd31ccc: b.eq            #0xd31cd4
    //     0xd31cd0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd31cd4: mov             x0, x1
    // 0xd31cd8: StoreField: r3->field_f = r0
    //     0xd31cd8: stur            w0, [x3, #0xf]
    //     0xd31cdc: ldurb           w16, [x3, #-1]
    //     0xd31ce0: ldurb           w17, [x0, #-1]
    //     0xd31ce4: and             x16, x17, x16, lsr #2
    //     0xd31ce8: tst             x16, HEAP, lsr #32
    //     0xd31cec: b.eq            #0xd31cf4
    //     0xd31cf0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd31cf4: mov             x0, x2
    // 0xd31cf8: StoreField: r3->field_13 = r0
    //     0xd31cf8: stur            w0, [x3, #0x13]
    //     0xd31cfc: ldurb           w16, [x3, #-1]
    //     0xd31d00: ldurb           w17, [x0, #-1]
    //     0xd31d04: and             x16, x17, x16, lsr #2
    //     0xd31d08: tst             x16, HEAP, lsr #32
    //     0xd31d0c: b.eq            #0xd31d14
    //     0xd31d10: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd31d14: ArrayStore: r3[0] = d0  ; List_8
    //     0xd31d14: stur            d0, [x3, #0x17]
    // 0xd31d18: StoreField: r3->field_1f = d5
    //     0xd31d18: stur            d5, [x3, #0x1f]
    // 0xd31d1c: StoreField: r3->field_27 = d1
    //     0xd31d1c: stur            d1, [x3, #0x27]
    // 0xd31d20: StoreField: r3->field_2f = d2
    //     0xd31d20: stur            d2, [x3, #0x2f]
    // 0xd31d24: StoreField: r3->field_37 = d4
    //     0xd31d24: stur            d4, [x3, #0x37]
    // 0xd31d28: StoreField: r3->field_3f = d3
    //     0xd31d28: stur            d3, [x3, #0x3f]
    // 0xd31d2c: mov             x0, x7
    // 0xd31d30: StoreField: r3->field_5b = r0
    //     0xd31d30: stur            w0, [x3, #0x5b]
    //     0xd31d34: ldurb           w16, [x3, #-1]
    //     0xd31d38: ldurb           w17, [x0, #-1]
    //     0xd31d3c: and             x16, x17, x16, lsr #2
    //     0xd31d40: tst             x16, HEAP, lsr #32
    //     0xd31d44: b.eq            #0xd31d4c
    //     0xd31d48: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd31d4c: StoreField: r3->field_5f = r4
    //     0xd31d4c: stur            w4, [x3, #0x5f]
    // 0xd31d50: cmp             w2, NULL
    // 0xd31d54: b.eq            #0xd31d74
    // 0xd31d58: d1 = -1.570796
    //     0xd31d58: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1f148] IMM: double(-1.5707963267948966) from 0xbff921fb54442d18
    //     0xd31d5c: ldr             d1, [x17, #0x148]
    // 0xd31d60: d8 = 3.000000
    //     0xd31d60: fmov            d8, #3.00000000
    // 0xd31d64: d7 = 2.000000
    //     0xd31d64: fmov            d7, #2.00000000
    // 0xd31d68: d4 = 3.141593
    //     0xd31d68: add             x17, PP, #0x13, lsl #12  ; [pp+0x13178] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0xd31d6c: ldr             d4, [x17, #0x178]
    // 0xd31d70: b               #0xd31dbc
    // 0xd31d74: d8 = 3.000000
    //     0xd31d74: fmov            d8, #3.00000000
    // 0xd31d78: d7 = 2.000000
    //     0xd31d78: fmov            d7, #2.00000000
    // 0xd31d7c: d6 = -1.570796
    //     0xd31d7c: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1f148] IMM: double(-1.5707963267948966) from 0xbff921fb54442d18
    //     0xd31d80: ldr             d6, [x17, #0x148]
    // 0xd31d84: d4 = 3.141593
    //     0xd31d84: add             x17, PP, #0x13, lsl #12  ; [pp+0x13178] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0xd31d88: ldr             d4, [x17, #0x178]
    // 0xd31d8c: d3 = 0.500000
    //     0xd31d8c: fmov            d3, #0.50000000
    // 0xd31d90: fmul            d9, d5, d8
    // 0xd31d94: fdiv            d10, d9, d7
    // 0xd31d98: fmul            d9, d10, d4
    // 0xd31d9c: fadd            d10, d9, d6
    // 0xd31da0: fmul            d6, d2, d4
    // 0xd31da4: fmul            d2, d6, d7
    // 0xd31da8: fadd            d6, d10, d2
    // 0xd31dac: fmul            d2, d1, d3
    // 0xd31db0: fmul            d1, d2, d4
    // 0xd31db4: fadd            d2, d6, d1
    // 0xd31db8: mov             v1.16b, v2.16b
    // 0xd31dbc: StoreField: r3->field_47 = d1
    //     0xd31dbc: stur            d1, [x3, #0x47]
    // 0xd31dc0: cmp             w2, NULL
    // 0xd31dc4: b.eq            #0xd31e14
    // 0xd31dc8: d1 = 0.000000
    //     0xd31dc8: eor             v1.16b, v1.16b, v1.16b
    // 0xd31dcc: LoadField: d2 = r2->field_7
    //     0xd31dcc: ldur            d2, [x2, #7]
    // 0xd31dd0: fcmp            d1, d2
    // 0xd31dd4: b.le            #0xd31de0
    // 0xd31dd8: d2 = 0.000000
    //     0xd31dd8: eor             v2.16b, v2.16b, v2.16b
    // 0xd31ddc: b               #0xd31e00
    // 0xd31de0: d1 = 1.000000
    //     0xd31de0: fmov            d1, #1.00000000
    // 0xd31de4: fcmp            d2, d1
    // 0xd31de8: b.le            #0xd31df4
    // 0xd31dec: d2 = 1.000000
    //     0xd31dec: fmov            d2, #1.00000000
    // 0xd31df0: b               #0xd31e00
    // 0xd31df4: fcmp            d2, d2
    // 0xd31df8: b.vc            #0xd31e00
    // 0xd31dfc: d2 = 1.000000
    //     0xd31dfc: fmov            d2, #1.00000000
    // 0xd31e00: d1 = 6.282185
    //     0xd31e00: add             x17, PP, #0x8f, lsl #12  ; [pp+0x8fbc0] IMM: double(6.282185307179586) from 0x401920f52f66fdfd
    //     0xd31e04: ldr             d1, [x17, #0xbc0]
    // 0xd31e08: fmul            d3, d2, d1
    // 0xd31e0c: mov             v0.16b, v3.16b
    // 0xd31e10: b               #0xd31e38
    // 0xd31e14: d1 = 0.001000
    //     0xd31e14: ldr             d1, [PP, #0x57a8]  ; [pp+0x57a8] IMM: double(0.001) from 0x3f50624dd2f1a9fc
    // 0xd31e18: fmul            d2, d0, d8
    // 0xd31e1c: fdiv            d0, d2, d7
    // 0xd31e20: fmul            d2, d0, d4
    // 0xd31e24: fmul            d0, d5, d8
    // 0xd31e28: fdiv            d3, d0, d7
    // 0xd31e2c: fmul            d0, d3, d4
    // 0xd31e30: fsub            d3, d2, d0
    // 0xd31e34: fmax            v0.2d, v3.2d, v1.2d
    // 0xd31e38: StoreField: r3->field_4f = d0
    //     0xd31e38: stur            d0, [x3, #0x4f]
    // 0xd31e3c: r0 = Null
    //     0xd31e3c: mov             x0, NULL
    // 0xd31e40: LeaveFrame
    //     0xd31e40: mov             SP, fp
    //     0xd31e44: ldp             fp, lr, [SP], #0x10
    // 0xd31e48: ret
    //     0xd31e48: ret             
  }
}

// class id: 4334, size: 0x6c, field offset: 0x64
class _RefreshProgressIndicatorPainter extends _CircularProgressIndicatorPainter {

  _ paint(/* No info */) {
    // ** addr: 0xb77ce4, size: 0x78
    // 0xb77ce4: EnterFrame
    //     0xb77ce4: stp             fp, lr, [SP, #-0x10]!
    //     0xb77ce8: mov             fp, SP
    // 0xb77cec: AllocStack(0x18)
    //     0xb77cec: sub             SP, SP, #0x18
    // 0xb77cf0: SetupParameters(_RefreshProgressIndicatorPainter this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0xb77cf0: mov             x5, x1
    //     0xb77cf4: mov             x4, x2
    //     0xb77cf8: mov             x0, x3
    //     0xb77cfc: stur            x1, [fp, #-8]
    //     0xb77d00: stur            x2, [fp, #-0x10]
    //     0xb77d04: stur            x3, [fp, #-0x18]
    // 0xb77d08: CheckStackOverflow
    //     0xb77d08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb77d0c: cmp             SP, x16
    //     0xb77d10: b.ls            #0xb77d54
    // 0xb77d14: mov             x1, x5
    // 0xb77d18: mov             x2, x4
    // 0xb77d1c: mov             x3, x0
    // 0xb77d20: r0 = paint()
    //     0xb77d20: bl              #0xb7821c  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorPainter::paint
    // 0xb77d24: ldur            x1, [fp, #-8]
    // 0xb77d28: LoadField: d0 = r1->field_63
    //     0xb77d28: ldur            d0, [x1, #0x63]
    // 0xb77d2c: d1 = 0.000000
    //     0xb77d2c: eor             v1.16b, v1.16b, v1.16b
    // 0xb77d30: fcmp            d0, d1
    // 0xb77d34: b.le            #0xb77d44
    // 0xb77d38: ldur            x2, [fp, #-0x10]
    // 0xb77d3c: ldur            x3, [fp, #-0x18]
    // 0xb77d40: r0 = paintArrowhead()
    //     0xb77d40: bl              #0xb77d5c  ; [package:flutter/src/material/progress_indicator.dart] _RefreshProgressIndicatorPainter::paintArrowhead
    // 0xb77d44: r0 = Null
    //     0xb77d44: mov             x0, NULL
    // 0xb77d48: LeaveFrame
    //     0xb77d48: mov             SP, fp
    //     0xb77d4c: ldp             fp, lr, [SP], #0x10
    // 0xb77d50: ret
    //     0xb77d50: ret             
    // 0xb77d54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb77d54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb77d58: b               #0xb77d14
  }
  _ paintArrowhead(/* No info */) {
    // ** addr: 0xb77d5c, size: 0x42c
    // 0xb77d5c: EnterFrame
    //     0xb77d5c: stp             fp, lr, [SP, #-0x10]!
    //     0xb77d60: mov             fp, SP
    // 0xb77d64: AllocStack(0x88)
    //     0xb77d64: sub             SP, SP, #0x88
    // 0xb77d68: SetupParameters(_RefreshProgressIndicatorPainter this /* r1 => r23, fp-0x8 */, dynamic _ /* r2 => r20, fp-0x10 */, dynamic _ /* r3 => r19 */)
    //     0xb77d68: mov             x23, x1
    //     0xb77d6c: mov             x20, x2
    //     0xb77d70: mov             x19, x3
    //     0xb77d74: stur            x1, [fp, #-8]
    //     0xb77d78: stur            x2, [fp, #-0x10]
    // 0xb77d7c: CheckStackOverflow
    //     0xb77d7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb77d80: cmp             SP, x16
    //     0xb77d84: b.ls            #0xb78168
    // 0xb77d88: LoadField: d0 = r23->field_47
    //     0xb77d88: ldur            d0, [x23, #0x47]
    // 0xb77d8c: LoadField: d1 = r23->field_4f
    //     0xb77d8c: ldur            d1, [x23, #0x4f]
    // 0xb77d90: fadd            d2, d0, d1
    // 0xb77d94: mov             v0.16b, v2.16b
    // 0xb77d98: stur            d2, [fp, #-0x38]
    // 0xb77d9c: stp             fp, lr, [SP, #-0x10]!
    // 0xb77da0: mov             fp, SP
    // 0xb77da4: CallRuntime_LibcCos(double) -> double
    //     0xb77da4: and             SP, SP, #0xfffffffffffffff0
    //     0xb77da8: mov             sp, SP
    //     0xb77dac: ldr             x16, [THR, #0x778]  ; THR::LibcCos
    //     0xb77db0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb77db4: blr             x16
    //     0xb77db8: mov             x16, #8
    //     0xb77dbc: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb77dc0: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xb77dc4: sub             sp, x16, #1, lsl #12
    //     0xb77dc8: mov             SP, fp
    //     0xb77dcc: ldp             fp, lr, [SP], #0x10
    // 0xb77dd0: mov             v1.16b, v0.16b
    // 0xb77dd4: ldur            d0, [fp, #-0x38]
    // 0xb77dd8: stur            d1, [fp, #-0x38]
    // 0xb77ddc: stp             fp, lr, [SP, #-0x10]!
    // 0xb77de0: mov             fp, SP
    // 0xb77de4: CallRuntime_LibcSin(double) -> double
    //     0xb77de4: and             SP, SP, #0xfffffffffffffff0
    //     0xb77de8: mov             sp, SP
    //     0xb77dec: ldr             x16, [THR, #0x780]  ; THR::LibcSin
    //     0xb77df0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb77df4: blr             x16
    //     0xb77df8: mov             x16, #8
    //     0xb77dfc: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb77e00: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xb77e04: sub             sp, x16, #1, lsl #12
    //     0xb77e08: mov             SP, fp
    //     0xb77e0c: ldp             fp, lr, [SP], #0x10
    // 0xb77e10: stur            d0, [fp, #-0x70]
    // 0xb77e14: LoadField: d1 = r19->field_7
    //     0xb77e14: ldur            d1, [x19, #7]
    // 0xb77e18: d2 = 2.000000
    //     0xb77e18: fmov            d2, #2.00000000
    // 0xb77e1c: fdiv            d3, d1, d2
    // 0xb77e20: ldur            d1, [fp, #-0x38]
    // 0xb77e24: stur            d3, [fp, #-0x68]
    // 0xb77e28: fmul            d4, d1, d3
    // 0xb77e2c: fadd            d5, d3, d4
    // 0xb77e30: fneg            d4, d0
    // 0xb77e34: LoadField: d6 = r23->field_37
    //     0xb77e34: ldur            d6, [x23, #0x37]
    // 0xb77e38: stur            d6, [fp, #-0x60]
    // 0xb77e3c: fmul            d7, d4, d6
    // 0xb77e40: fmul            d4, d7, d2
    // 0xb77e44: LoadField: d7 = r23->field_63
    //     0xb77e44: ldur            d7, [x23, #0x63]
    // 0xb77e48: fmul            d8, d4, d7
    // 0xb77e4c: fadd            d4, d5, d8
    // 0xb77e50: stur            d4, [fp, #-0x58]
    // 0xb77e54: fmul            d5, d0, d3
    // 0xb77e58: fadd            d8, d3, d5
    // 0xb77e5c: fmul            d5, d1, d6
    // 0xb77e60: fmul            d9, d5, d2
    // 0xb77e64: fmul            d5, d9, d7
    // 0xb77e68: fadd            d9, d8, d5
    // 0xb77e6c: stur            d9, [fp, #-0x50]
    // 0xb77e70: fmul            d5, d6, d2
    // 0xb77e74: fmul            d2, d5, d7
    // 0xb77e78: fsub            d5, d3, d2
    // 0xb77e7c: stur            d5, [fp, #-0x48]
    // 0xb77e80: fadd            d7, d3, d2
    // 0xb77e84: stur            d7, [fp, #-0x40]
    // 0xb77e88: r0 = _NativePath()
    //     0xb77e88: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xb77e8c: mov             x1, x0
    // 0xb77e90: stur            x0, [fp, #-0x18]
    // 0xb77e94: r0 = __constructor$Method$FfiNative()
    //     0xb77e94: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xb77e98: ldur            d1, [fp, #-0x48]
    // 0xb77e9c: ldur            d0, [fp, #-0x38]
    // 0xb77ea0: fmul            d2, d0, d1
    // 0xb77ea4: ldur            d3, [fp, #-0x68]
    // 0xb77ea8: fadd            d4, d3, d2
    // 0xb77eac: ldur            d2, [fp, #-0x70]
    // 0xb77eb0: stur            d4, [fp, #-0x78]
    // 0xb77eb4: fmul            d5, d2, d1
    // 0xb77eb8: fadd            d1, d3, d5
    // 0xb77ebc: ldur            x0, [fp, #-0x18]
    // 0xb77ec0: stur            d1, [fp, #-0x48]
    // 0xb77ec4: LoadField: r1 = r0->field_7
    //     0xb77ec4: ldur            w1, [x0, #7]
    // 0xb77ec8: DecompressPointer r1
    //     0xb77ec8: add             x1, x1, HEAP, lsl #32
    // 0xb77ecc: cmp             w1, NULL
    // 0xb77ed0: b.eq            #0xb78170
    // 0xb77ed4: LoadField: r2 = r1->field_7
    //     0xb77ed4: ldur            x2, [x1, #7]
    // 0xb77ed8: ldr             x1, [x2]
    // 0xb77edc: cbz             x1, #0xb78118
    // 0xb77ee0: ldur            d5, [fp, #-0x40]
    // 0xb77ee4: mov             x2, x1
    // 0xb77ee8: stur            x2, [fp, #-0x20]
    // 0xb77eec: r1 = <Never>
    //     0xb77eec: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb77ef0: r0 = Pointer()
    //     0xb77ef0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb77ef4: mov             x1, x0
    // 0xb77ef8: ldur            x0, [fp, #-0x20]
    // 0xb77efc: StoreField: r1->field_7 = r0
    //     0xb77efc: stur            x0, [x1, #7]
    // 0xb77f00: ldur            d0, [fp, #-0x78]
    // 0xb77f04: ldur            d1, [fp, #-0x48]
    // 0xb77f08: r0 = _moveTo$Method$FfiNative()
    //     0xb77f08: bl              #0xb69c74  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0xb77f0c: ldur            d1, [fp, #-0x40]
    // 0xb77f10: ldur            d0, [fp, #-0x38]
    // 0xb77f14: fmul            d2, d0, d1
    // 0xb77f18: ldur            d0, [fp, #-0x68]
    // 0xb77f1c: fadd            d3, d0, d2
    // 0xb77f20: ldur            d2, [fp, #-0x70]
    // 0xb77f24: stur            d3, [fp, #-0x48]
    // 0xb77f28: fmul            d4, d2, d1
    // 0xb77f2c: fadd            d1, d0, d4
    // 0xb77f30: ldur            x0, [fp, #-0x18]
    // 0xb77f34: stur            d1, [fp, #-0x38]
    // 0xb77f38: LoadField: r1 = r0->field_7
    //     0xb77f38: ldur            w1, [x0, #7]
    // 0xb77f3c: DecompressPointer r1
    //     0xb77f3c: add             x1, x1, HEAP, lsl #32
    // 0xb77f40: cmp             w1, NULL
    // 0xb77f44: b.eq            #0xb78174
    // 0xb77f48: LoadField: r2 = r1->field_7
    //     0xb77f48: ldur            x2, [x1, #7]
    // 0xb77f4c: ldr             x1, [x2]
    // 0xb77f50: cbz             x1, #0xb78128
    // 0xb77f54: mov             x2, x1
    // 0xb77f58: stur            x2, [fp, #-0x20]
    // 0xb77f5c: r1 = <Never>
    //     0xb77f5c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb77f60: r0 = Pointer()
    //     0xb77f60: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb77f64: mov             x1, x0
    // 0xb77f68: ldur            x0, [fp, #-0x20]
    // 0xb77f6c: StoreField: r1->field_7 = r0
    //     0xb77f6c: stur            x0, [x1, #7]
    // 0xb77f70: ldur            d0, [fp, #-0x48]
    // 0xb77f74: ldur            d1, [fp, #-0x38]
    // 0xb77f78: r0 = _lineTo$Method$FfiNative()
    //     0xb77f78: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0xb77f7c: ldur            x0, [fp, #-0x18]
    // 0xb77f80: LoadField: r1 = r0->field_7
    //     0xb77f80: ldur            w1, [x0, #7]
    // 0xb77f84: DecompressPointer r1
    //     0xb77f84: add             x1, x1, HEAP, lsl #32
    // 0xb77f88: cmp             w1, NULL
    // 0xb77f8c: b.eq            #0xb78178
    // 0xb77f90: LoadField: r2 = r1->field_7
    //     0xb77f90: ldur            x2, [x1, #7]
    // 0xb77f94: ldr             x1, [x2]
    // 0xb77f98: cbz             x1, #0xb78138
    // 0xb77f9c: mov             x2, x1
    // 0xb77fa0: stur            x2, [fp, #-0x20]
    // 0xb77fa4: r1 = <Never>
    //     0xb77fa4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb77fa8: r0 = Pointer()
    //     0xb77fa8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb77fac: mov             x1, x0
    // 0xb77fb0: ldur            x0, [fp, #-0x20]
    // 0xb77fb4: StoreField: r1->field_7 = r0
    //     0xb77fb4: stur            x0, [x1, #7]
    // 0xb77fb8: ldur            d0, [fp, #-0x58]
    // 0xb77fbc: ldur            d1, [fp, #-0x50]
    // 0xb77fc0: r0 = _lineTo$Method$FfiNative()
    //     0xb77fc0: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0xb77fc4: ldur            x0, [fp, #-0x18]
    // 0xb77fc8: LoadField: r1 = r0->field_7
    //     0xb77fc8: ldur            w1, [x0, #7]
    // 0xb77fcc: DecompressPointer r1
    //     0xb77fcc: add             x1, x1, HEAP, lsl #32
    // 0xb77fd0: cmp             w1, NULL
    // 0xb77fd4: b.eq            #0xb7817c
    // 0xb77fd8: LoadField: r2 = r1->field_7
    //     0xb77fd8: ldur            x2, [x1, #7]
    // 0xb77fdc: ldr             x1, [x2]
    // 0xb77fe0: cbz             x1, #0xb78148
    // 0xb77fe4: ldur            x3, [fp, #-8]
    // 0xb77fe8: ldur            x2, [fp, #-0x10]
    // 0xb77fec: ldur            d0, [fp, #-0x60]
    // 0xb77ff0: mov             x4, x1
    // 0xb77ff4: stur            x4, [fp, #-0x20]
    // 0xb77ff8: r1 = <Never>
    //     0xb77ff8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb77ffc: r0 = Pointer()
    //     0xb77ffc: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb78000: mov             x1, x0
    // 0xb78004: ldur            x0, [fp, #-0x20]
    // 0xb78008: StoreField: r1->field_7 = r0
    //     0xb78008: stur            x0, [x1, #7]
    // 0xb7800c: r0 = _close$Method$FfiNative()
    //     0xb7800c: bl              #0xb78188  ; [dart:ui] _NativePath::_close$Method$FfiNative
    // 0xb78010: r16 = 136
    //     0xb78010: mov             x16, #0x88
    // 0xb78014: stp             x16, NULL, [SP]
    // 0xb78018: r0 = ByteData()
    //     0xb78018: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb7801c: stur            x0, [fp, #-0x28]
    // 0xb78020: r0 = Paint()
    //     0xb78020: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb78024: ldur            x5, [fp, #-0x28]
    // 0xb78028: stur            x0, [fp, #-0x30]
    // 0xb7802c: StoreField: r0->field_7 = r5
    //     0xb7802c: stur            w5, [x0, #7]
    // 0xb78030: ldur            x1, [fp, #-8]
    // 0xb78034: LoadField: r2 = r1->field_f
    //     0xb78034: ldur            w2, [x1, #0xf]
    // 0xb78038: DecompressPointer r2
    //     0xb78038: add             x2, x2, HEAP, lsl #32
    // 0xb7803c: mov             x1, x0
    // 0xb78040: r0 = color=()
    //     0xb78040: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb78044: ldur            x5, [fp, #-0x28]
    // 0xb78048: ArrayLoad: r0 = r5[0]  ; List_4
    //     0xb78048: ldur            w0, [x5, #0x17]
    // 0xb7804c: DecompressPointer r0
    //     0xb7804c: add             x0, x0, HEAP, lsl #32
    // 0xb78050: ldur            d0, [fp, #-0x60]
    // 0xb78054: fcvt            s1, d0
    // 0xb78058: LoadField: r1 = r0->field_7
    //     0xb78058: ldur            x1, [x0, #7]
    // 0xb7805c: str             s1, [x1, #0x20]
    // 0xb78060: LoadField: r1 = r0->field_7
    //     0xb78060: ldur            x1, [x0, #7]
    // 0xb78064: str             wzr, [x1, #0x1c]
    // 0xb78068: ldur            x0, [fp, #-0x30]
    // 0xb7806c: LoadField: r3 = r0->field_b
    //     0xb7806c: ldur            w3, [x0, #0xb]
    // 0xb78070: DecompressPointer r3
    //     0xb78070: add             x3, x3, HEAP, lsl #32
    // 0xb78074: ldur            x0, [fp, #-0x10]
    // 0xb78078: stur            x3, [fp, #-8]
    // 0xb7807c: LoadField: r1 = r0->field_7
    //     0xb7807c: ldur            w1, [x0, #7]
    // 0xb78080: DecompressPointer r1
    //     0xb78080: add             x1, x1, HEAP, lsl #32
    // 0xb78084: cmp             w1, NULL
    // 0xb78088: b.eq            #0xb78180
    // 0xb7808c: LoadField: r2 = r1->field_7
    //     0xb7808c: ldur            x2, [x1, #7]
    // 0xb78090: ldr             x1, [x2]
    // 0xb78094: cbz             x1, #0xb78158
    // 0xb78098: ldur            x2, [fp, #-0x18]
    // 0xb7809c: mov             x4, x1
    // 0xb780a0: stur            x4, [fp, #-0x20]
    // 0xb780a4: r1 = <Never>
    //     0xb780a4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb780a8: r0 = Pointer()
    //     0xb780a8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb780ac: mov             x2, x0
    // 0xb780b0: ldur            x0, [fp, #-0x20]
    // 0xb780b4: stur            x2, [fp, #-0x30]
    // 0xb780b8: StoreField: r2->field_7 = r0
    //     0xb780b8: stur            x0, [x2, #7]
    // 0xb780bc: ldur            x0, [fp, #-0x18]
    // 0xb780c0: LoadField: r1 = r0->field_7
    //     0xb780c0: ldur            w1, [x0, #7]
    // 0xb780c4: DecompressPointer r1
    //     0xb780c4: add             x1, x1, HEAP, lsl #32
    // 0xb780c8: cmp             w1, NULL
    // 0xb780cc: b.eq            #0xb78184
    // 0xb780d0: LoadField: r3 = r1->field_7
    //     0xb780d0: ldur            x3, [x1, #7]
    // 0xb780d4: ldr             x1, [x3]
    // 0xb780d8: mov             x3, x1
    // 0xb780dc: stur            x3, [fp, #-0x20]
    // 0xb780e0: r1 = <Never>
    //     0xb780e0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb780e4: r0 = Pointer()
    //     0xb780e4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb780e8: mov             x1, x0
    // 0xb780ec: ldur            x0, [fp, #-0x20]
    // 0xb780f0: StoreField: r1->field_7 = r0
    //     0xb780f0: stur            x0, [x1, #7]
    // 0xb780f4: mov             x2, x1
    // 0xb780f8: ldur            x1, [fp, #-0x30]
    // 0xb780fc: ldur            x3, [fp, #-8]
    // 0xb78100: ldur            x5, [fp, #-0x28]
    // 0xb78104: r0 = __drawPath$Method$FfiNative()
    //     0xb78104: bl              #0xb69a00  ; [dart:ui] _NativeCanvas::__drawPath$Method$FfiNative
    // 0xb78108: r0 = Null
    //     0xb78108: mov             x0, NULL
    // 0xb7810c: LeaveFrame
    //     0xb7810c: mov             SP, fp
    //     0xb78110: ldp             fp, lr, [SP], #0x10
    // 0xb78114: ret
    //     0xb78114: ret             
    // 0xb78118: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb78118: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb7811c: str             x16, [SP]
    // 0xb78120: r0 = _throwNew()
    //     0xb78120: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb78124: brk             #0
    // 0xb78128: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb78128: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb7812c: str             x16, [SP]
    // 0xb78130: r0 = _throwNew()
    //     0xb78130: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb78134: brk             #0
    // 0xb78138: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb78138: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb7813c: str             x16, [SP]
    // 0xb78140: r0 = _throwNew()
    //     0xb78140: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb78144: brk             #0
    // 0xb78148: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb78148: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb7814c: str             x16, [SP]
    // 0xb78150: r0 = _throwNew()
    //     0xb78150: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb78154: brk             #0
    // 0xb78158: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb78158: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb7815c: str             x16, [SP]
    // 0xb78160: r0 = _throwNew()
    //     0xb78160: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb78164: brk             #0
    // 0xb78168: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb78168: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7816c: b               #0xb77d88
    // 0xb78170: r0 = NullErrorSharedWithFPURegs()
    //     0xb78170: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb78174: r0 = NullErrorSharedWithFPURegs()
    //     0xb78174: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb78178: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb78178: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb7817c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb7817c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb78180: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb78180: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb78184: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb78184: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _RefreshProgressIndicatorPainter(/* No info */) {
    // ** addr: 0xd31b30, size: 0x84
    // 0xd31b30: EnterFrame
    //     0xd31b30: stp             fp, lr, [SP, #-0x10]!
    //     0xd31b34: mov             fp, SP
    // 0xd31b38: mov             v31.16b, v1.16b
    // 0xd31b3c: mov             v1.16b, v0.16b
    // 0xd31b40: mov             v0.16b, v31.16b
    // 0xd31b44: mov             v31.16b, v2.16b
    // 0xd31b48: mov             v2.16b, v1.16b
    // 0xd31b4c: mov             v1.16b, v31.16b
    // 0xd31b50: mov             v31.16b, v3.16b
    // 0xd31b54: mov             v3.16b, v2.16b
    // 0xd31b58: mov             v2.16b, v31.16b
    // 0xd31b5c: mov             v31.16b, v4.16b
    // 0xd31b60: mov             v4.16b, v3.16b
    // 0xd31b64: mov             v3.16b, v31.16b
    // 0xd31b68: mov             v31.16b, v5.16b
    // 0xd31b6c: mov             v5.16b, v4.16b
    // 0xd31b70: mov             v4.16b, v31.16b
    // 0xd31b74: mov             x3, x2
    // 0xd31b78: CheckStackOverflow
    //     0xd31b78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd31b7c: cmp             SP, x16
    //     0xd31b80: b.ls            #0xd31bac
    // 0xd31b84: StoreField: r1->field_63 = d5
    //     0xd31b84: stur            d5, [x1, #0x63]
    // 0xd31b88: ldr             d5, [fp, #0x10]
    // 0xd31b8c: r2 = Null
    //     0xd31b8c: mov             x2, NULL
    // 0xd31b90: r4 = const [0, 0x9, 0, 0x9, null]
    //     0xd31b90: add             x4, PP, #0xa3, lsl #12  ; [pp+0xa3880] List(5) [0, 0x9, 0, 0x9, Null]
    //     0xd31b94: ldr             x4, [x4, #0x880]
    // 0xd31b98: r0 = _CircularProgressIndicatorPainter()
    //     0xd31b98: bl              #0xd31bb4  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorPainter::_CircularProgressIndicatorPainter
    // 0xd31b9c: r0 = Null
    //     0xd31b9c: mov             x0, NULL
    // 0xd31ba0: LeaveFrame
    //     0xd31ba0: mov             SP, fp
    //     0xd31ba4: ldp             fp, lr, [SP], #0x10
    // 0xd31ba8: ret
    //     0xd31ba8: ret             
    // 0xd31bac: r0 = StackOverflowSharedWithFPURegs()
    //     0xd31bac: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd31bb0: b               #0xd31b84
  }
}

// class id: 4335, size: 0x34, field offset: 0xc
//   const constructor, 
class _LinearProgressIndicatorPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0xb76a24, size: 0x94c
    // 0xb76a24: EnterFrame
    //     0xb76a24: stp             fp, lr, [SP, #-0x10]!
    //     0xb76a28: mov             fp, SP
    // 0xb76a2c: AllocStack(0x70)
    //     0xb76a2c: sub             SP, SP, #0x70
    // 0xb76a30: SetupParameters(_LinearProgressIndicatorPainter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb76a30: stur            x1, [fp, #-8]
    //     0xb76a34: stur            x2, [fp, #-0x10]
    //     0xb76a38: stur            x3, [fp, #-0x18]
    // 0xb76a3c: CheckStackOverflow
    //     0xb76a3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb76a40: cmp             SP, x16
    //     0xb76a44: b.ls            #0xb771d4
    // 0xb76a48: r1 = 3
    //     0xb76a48: mov             x1, #3
    // 0xb76a4c: r0 = AllocateContext()
    //     0xb76a4c: bl              #0x13de838  ; AllocateContextStub
    // 0xb76a50: mov             x3, x0
    // 0xb76a54: ldur            x0, [fp, #-8]
    // 0xb76a58: stur            x3, [fp, #-0x20]
    // 0xb76a5c: StoreField: r3->field_f = r0
    //     0xb76a5c: stur            w0, [x3, #0xf]
    // 0xb76a60: ldur            x1, [fp, #-0x10]
    // 0xb76a64: StoreField: r3->field_13 = r1
    //     0xb76a64: stur            w1, [x3, #0x13]
    // 0xb76a68: ldur            x4, [fp, #-0x18]
    // 0xb76a6c: ArrayStore: r3[0] = r4  ; List_4
    //     0xb76a6c: stur            w4, [x3, #0x17]
    // 0xb76a70: LoadField: r1 = r0->field_2f
    //     0xb76a70: ldur            w1, [x0, #0x2f]
    // 0xb76a74: DecompressPointer r1
    //     0xb76a74: add             x1, x1, HEAP, lsl #32
    // 0xb76a78: cmp             w1, NULL
    // 0xb76a7c: b.ne            #0xb76a88
    // 0xb76a80: d0 = 0.000000
    //     0xb76a80: eor             v0.16b, v0.16b, v0.16b
    // 0xb76a84: b               #0xb76a8c
    // 0xb76a88: LoadField: d0 = r1->field_7
    //     0xb76a88: ldur            d0, [x1, #7]
    // 0xb76a8c: mov             x2, x3
    // 0xb76a90: stur            d0, [fp, #-0x30]
    // 0xb76a94: r1 = Function 'drawLinearIndicator':.
    //     0xb76a94: add             x1, PP, #0xd2, lsl #12  ; [pp+0xd2870] AnonymousClosure: (0xb77370), in [package:flutter/src/material/progress_indicator.dart] _LinearProgressIndicatorPainter::paint (0xb76a24)
    //     0xb76a98: ldr             x1, [x1, #0x870]
    // 0xb76a9c: r0 = AllocateClosure()
    //     0xb76a9c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb76aa0: mov             x1, x0
    // 0xb76aa4: ldur            x0, [fp, #-0x18]
    // 0xb76aa8: stur            x1, [fp, #-0x28]
    // 0xb76aac: LoadField: d0 = r0->field_7
    //     0xb76aac: ldur            d0, [x0, #7]
    // 0xb76ab0: ldur            d1, [fp, #-0x30]
    // 0xb76ab4: fdiv            d2, d1, d0
    // 0xb76ab8: ldur            x2, [fp, #-8]
    // 0xb76abc: stur            d2, [fp, #-0x38]
    // 0xb76ac0: LoadField: r0 = r2->field_13
    //     0xb76ac0: ldur            w0, [x2, #0x13]
    // 0xb76ac4: DecompressPointer r0
    //     0xb76ac4: add             x0, x0, HEAP, lsl #32
    // 0xb76ac8: cmp             w0, NULL
    // 0xb76acc: b.ne            #0xb76ae0
    // 0xb76ad0: r3 = Null
    //     0xb76ad0: mov             x3, NULL
    // 0xb76ad4: d0 = 0.000000
    //     0xb76ad4: eor             v0.16b, v0.16b, v0.16b
    // 0xb76ad8: d3 = 1.000000
    //     0xb76ad8: fmov            d3, #1.00000000
    // 0xb76adc: b               #0xb76b4c
    // 0xb76ae0: d0 = 0.000000
    //     0xb76ae0: eor             v0.16b, v0.16b, v0.16b
    // 0xb76ae4: LoadField: d1 = r0->field_7
    //     0xb76ae4: ldur            d1, [x0, #7]
    // 0xb76ae8: fcmp            d0, d1
    // 0xb76aec: b.le            #0xb76afc
    // 0xb76af0: d1 = 0.000000
    //     0xb76af0: eor             v1.16b, v1.16b, v1.16b
    // 0xb76af4: d3 = 1.000000
    //     0xb76af4: fmov            d3, #1.00000000
    // 0xb76af8: b               #0xb76b1c
    // 0xb76afc: d3 = 1.000000
    //     0xb76afc: fmov            d3, #1.00000000
    // 0xb76b00: fcmp            d1, d3
    // 0xb76b04: b.le            #0xb76b10
    // 0xb76b08: d1 = 1.000000
    //     0xb76b08: fmov            d1, #1.00000000
    // 0xb76b0c: b               #0xb76b1c
    // 0xb76b10: fcmp            d1, d1
    // 0xb76b14: b.vc            #0xb76b1c
    // 0xb76b18: d1 = 1.000000
    //     0xb76b18: fmov            d1, #1.00000000
    // 0xb76b1c: r0 = inline_Allocate_Double()
    //     0xb76b1c: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xb76b20: add             x0, x0, #0x10
    //     0xb76b24: cmp             x3, x0
    //     0xb76b28: b.ls            #0xb771dc
    //     0xb76b2c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb76b30: sub             x0, x0, #0xf
    //     0xb76b34: mov             x3, #0xe19c
    //     0xb76b38: movk            x3, #3, lsl #16
    //     0xb76b3c: stur            x3, [x0, #-1]
    // 0xb76b40: dmb             ishst
    // 0xb76b44: StoreField: r0->field_7 = d1
    //     0xb76b44: stur            d1, [x0, #7]
    // 0xb76b48: mov             x3, x0
    // 0xb76b4c: stur            x3, [fp, #-0x10]
    // 0xb76b50: cmp             w3, NULL
    // 0xb76b54: b.eq            #0xb76c9c
    // 0xb76b58: fcmp            d2, d0
    // 0xb76b5c: b.le            #0xb76bc4
    // 0xb76b60: LoadField: d1 = r3->field_7
    //     0xb76b60: ldur            d1, [x3, #7]
    // 0xb76b64: fcmp            d0, d1
    // 0xb76b68: b.le            #0xb76b7c
    // 0xb76b6c: d5 = 0.000000
    //     0xb76b6c: eor             v5.16b, v5.16b, v5.16b
    // 0xb76b70: d4 = 0.010000
    //     0xb76b70: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xb76b74: ldr             d4, [x17, #0x398]
    // 0xb76b78: b               #0xb76bb0
    // 0xb76b7c: d4 = 0.010000
    //     0xb76b7c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xb76b80: ldr             d4, [x17, #0x398]
    // 0xb76b84: fcmp            d1, d4
    // 0xb76b88: b.le            #0xb76b98
    // 0xb76b8c: d5 = 0.010000
    //     0xb76b8c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xb76b90: ldr             d5, [x17, #0x398]
    // 0xb76b94: b               #0xb76bb0
    // 0xb76b98: fcmp            d1, d1
    // 0xb76b9c: b.vc            #0xb76bac
    // 0xb76ba0: d5 = 0.010000
    //     0xb76ba0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xb76ba4: ldr             d5, [x17, #0x398]
    // 0xb76ba8: b               #0xb76bb0
    // 0xb76bac: mov             v5.16b, v1.16b
    // 0xb76bb0: fmul            d6, d2, d5
    // 0xb76bb4: fdiv            d2, d6, d4
    // 0xb76bb8: fadd            d4, d1, d2
    // 0xb76bbc: mov             v1.16b, v4.16b
    // 0xb76bc0: b               #0xb76bc8
    // 0xb76bc4: d1 = 0.000000
    //     0xb76bc4: eor             v1.16b, v1.16b, v1.16b
    // 0xb76bc8: r0 = inline_Allocate_Double()
    //     0xb76bc8: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0xb76bcc: add             x0, x0, #0x10
    //     0xb76bd0: cmp             x4, x0
    //     0xb76bd4: b.ls            #0xb771fc
    //     0xb76bd8: str             x0, [THR, #0x60]  ; THR::top
    //     0xb76bdc: sub             x0, x0, #0xf
    //     0xb76be0: mov             x4, #0xe19c
    //     0xb76be4: movk            x4, #3, lsl #16
    //     0xb76be8: stur            x4, [x0, #-1]
    // 0xb76bec: dmb             ishst
    // 0xb76bf0: StoreField: r0->field_7 = d1
    //     0xb76bf0: stur            d1, [x0, #7]
    // 0xb76bf4: fcmp            d3, d1
    // 0xb76bf8: b.le            #0xb76c24
    // 0xb76bfc: LoadField: r4 = r2->field_b
    //     0xb76bfc: ldur            w4, [x2, #0xb]
    // 0xb76c00: DecompressPointer r4
    //     0xb76c00: add             x4, x4, HEAP, lsl #32
    // 0xb76c04: stp             x0, x1, [SP, #0x10]
    // 0xb76c08: r16 = 1.000000
    //     0xb76c08: ldr             x16, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xb76c0c: stp             x4, x16, [SP]
    // 0xb76c10: mov             x0, x1
    // 0xb76c14: ClosureCall
    //     0xb76c14: add             x4, PP, #0xd2, lsl #12  ; [pp+0xd2878] List(11) [0, 0x4, 0x4, 0x1, "color", 0x3, "endFraction", 0x2, "startFraction", 0x1, Null]
    //     0xb76c18: ldr             x4, [x4, #0x878]
    //     0xb76c1c: ldur            x2, [x0, #0x1f]
    //     0xb76c20: blr             x2
    // 0xb76c24: ldur            x0, [fp, #-8]
    // 0xb76c28: LoadField: r1 = r0->field_2b
    //     0xb76c28: ldur            w1, [x0, #0x2b]
    // 0xb76c2c: DecompressPointer r1
    //     0xb76c2c: add             x1, x1, HEAP, lsl #32
    // 0xb76c30: cmp             w1, NULL
    // 0xb76c34: b.eq            #0xb76c4c
    // 0xb76c38: d1 = 0.000000
    //     0xb76c38: eor             v1.16b, v1.16b, v1.16b
    // 0xb76c3c: LoadField: d0 = r1->field_7
    //     0xb76c3c: ldur            d0, [x1, #7]
    // 0xb76c40: fcmp            d0, d1
    // 0xb76c44: b.le            #0xb76c50
    // 0xb76c48: b               #0xb77194
    // 0xb76c4c: d1 = 0.000000
    //     0xb76c4c: eor             v1.16b, v1.16b, v1.16b
    // 0xb76c50: ldur            x1, [fp, #-0x10]
    // 0xb76c54: LoadField: d0 = r1->field_7
    //     0xb76c54: ldur            d0, [x1, #7]
    // 0xb76c58: fcmp            d0, d1
    // 0xb76c5c: b.le            #0xb76c8c
    // 0xb76c60: LoadField: r2 = r0->field_f
    //     0xb76c60: ldur            w2, [x0, #0xf]
    // 0xb76c64: DecompressPointer r2
    //     0xb76c64: add             x2, x2, HEAP, lsl #32
    // 0xb76c68: ldur            x16, [fp, #-0x28]
    // 0xb76c6c: r30 = 0.000000
    //     0xb76c6c: ldr             lr, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xb76c70: stp             lr, x16, [SP, #0x10]
    // 0xb76c74: stp             x2, x1, [SP]
    // 0xb76c78: ldur            x0, [fp, #-0x28]
    // 0xb76c7c: ClosureCall
    //     0xb76c7c: add             x4, PP, #0xd2, lsl #12  ; [pp+0xd2878] List(11) [0, 0x4, 0x4, 0x1, "color", 0x3, "endFraction", 0x2, "startFraction", 0x1, Null]
    //     0xb76c80: ldr             x4, [x4, #0x878]
    //     0xb76c84: ldur            x2, [x0, #0x1f]
    //     0xb76c88: blr             x2
    // 0xb76c8c: r0 = Null
    //     0xb76c8c: mov             x0, NULL
    // 0xb76c90: LeaveFrame
    //     0xb76c90: mov             SP, fp
    //     0xb76c94: ldp             fp, lr, [SP], #0x10
    // 0xb76c98: ret
    //     0xb76c98: ret             
    // 0xb76c9c: mov             x0, x2
    // 0xb76ca0: mov             v1.16b, v0.16b
    // 0xb76ca4: d4 = 0.010000
    //     0xb76ca4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xb76ca8: ldr             d4, [x17, #0x398]
    // 0xb76cac: ArrayLoad: d5 = r0[0]  ; List_8
    //     0xb76cac: ldur            d5, [x0, #0x17]
    // 0xb76cb0: mov             v0.16b, v5.16b
    // 0xb76cb4: stur            d5, [fp, #-0x30]
    // 0xb76cb8: r1 = Instance_Interval
    //     0xb76cb8: add             x1, PP, #0xd2, lsl #12  ; [pp+0xd2880] Obj!Interval@129f991
    //     0xb76cbc: ldr             x1, [x1, #0x880]
    // 0xb76cc0: r0 = transform()
    //     0xb76cc0: bl              #0x12f4dac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0xb76cc4: mov             v1.16b, v0.16b
    // 0xb76cc8: ldur            d0, [fp, #-0x30]
    // 0xb76ccc: r1 = Instance_Interval
    //     0xb76ccc: add             x1, PP, #0xd2, lsl #12  ; [pp+0xd2888] Obj!Interval@129f971
    //     0xb76cd0: ldr             x1, [x1, #0x888]
    // 0xb76cd4: stur            d1, [fp, #-0x40]
    // 0xb76cd8: r0 = transform()
    //     0xb76cd8: bl              #0x12f4dac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0xb76cdc: mov             v1.16b, v0.16b
    // 0xb76ce0: ldur            d0, [fp, #-0x30]
    // 0xb76ce4: r1 = Instance_Interval
    //     0xb76ce4: add             x1, PP, #0xd2, lsl #12  ; [pp+0xd2890] Obj!Interval@129f951
    //     0xb76ce8: ldr             x1, [x1, #0x890]
    // 0xb76cec: stur            d1, [fp, #-0x48]
    // 0xb76cf0: r0 = transform()
    //     0xb76cf0: bl              #0x12f4dac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0xb76cf4: mov             v1.16b, v0.16b
    // 0xb76cf8: ldur            d0, [fp, #-0x30]
    // 0xb76cfc: r1 = Instance_Interval
    //     0xb76cfc: add             x1, PP, #0xd2, lsl #12  ; [pp+0xd2898] Obj!Interval@129f931
    //     0xb76d00: ldr             x1, [x1, #0x898]
    // 0xb76d04: stur            d1, [fp, #-0x30]
    // 0xb76d08: r0 = transform()
    //     0xb76d08: bl              #0x12f4dac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0xb76d0c: mov             v2.16b, v0.16b
    // 0xb76d10: ldur            d0, [fp, #-0x38]
    // 0xb76d14: d1 = 1.000000
    //     0xb76d14: fmov            d1, #1.00000000
    // 0xb76d18: stur            d2, [fp, #-0x50]
    // 0xb76d1c: fsub            d3, d1, d0
    // 0xb76d20: ldur            d4, [fp, #-0x40]
    // 0xb76d24: fcmp            d3, d4
    // 0xb76d28: b.le            #0xb76e00
    // 0xb76d2c: d3 = 0.000000
    //     0xb76d2c: eor             v3.16b, v3.16b, v3.16b
    // 0xb76d30: fcmp            d4, d3
    // 0xb76d34: b.le            #0xb76d98
    // 0xb76d38: fcmp            d3, d4
    // 0xb76d3c: b.le            #0xb76d50
    // 0xb76d40: d6 = 0.000000
    //     0xb76d40: eor             v6.16b, v6.16b, v6.16b
    // 0xb76d44: d5 = 0.010000
    //     0xb76d44: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xb76d48: ldr             d5, [x17, #0x398]
    // 0xb76d4c: b               #0xb76d84
    // 0xb76d50: d5 = 0.010000
    //     0xb76d50: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xb76d54: ldr             d5, [x17, #0x398]
    // 0xb76d58: fcmp            d4, d5
    // 0xb76d5c: b.le            #0xb76d6c
    // 0xb76d60: d6 = 0.010000
    //     0xb76d60: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xb76d64: ldr             d6, [x17, #0x398]
    // 0xb76d68: b               #0xb76d84
    // 0xb76d6c: fcmp            d4, d4
    // 0xb76d70: b.vc            #0xb76d80
    // 0xb76d74: d6 = 0.010000
    //     0xb76d74: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xb76d78: ldr             d6, [x17, #0x398]
    // 0xb76d7c: b               #0xb76d84
    // 0xb76d80: mov             v6.16b, v4.16b
    // 0xb76d84: fmul            d7, d0, d6
    // 0xb76d88: fdiv            d6, d7, d5
    // 0xb76d8c: fadd            d7, d4, d6
    // 0xb76d90: mov             v6.16b, v7.16b
    // 0xb76d94: b               #0xb76da4
    // 0xb76d98: d5 = 0.010000
    //     0xb76d98: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xb76d9c: ldr             d5, [x17, #0x398]
    // 0xb76da0: d6 = 0.000000
    //     0xb76da0: eor             v6.16b, v6.16b, v6.16b
    // 0xb76da4: ldur            x1, [fp, #-8]
    // 0xb76da8: LoadField: r0 = r1->field_b
    //     0xb76da8: ldur            w0, [x1, #0xb]
    // 0xb76dac: DecompressPointer r0
    //     0xb76dac: add             x0, x0, HEAP, lsl #32
    // 0xb76db0: r2 = inline_Allocate_Double()
    //     0xb76db0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xb76db4: add             x2, x2, #0x10
    //     0xb76db8: cmp             x3, x2
    //     0xb76dbc: b.ls            #0xb77224
    //     0xb76dc0: str             x2, [THR, #0x60]  ; THR::top
    //     0xb76dc4: sub             x2, x2, #0xf
    //     0xb76dc8: mov             x3, #0xe19c
    //     0xb76dcc: movk            x3, #3, lsl #16
    //     0xb76dd0: stur            x3, [x2, #-1]
    // 0xb76dd4: dmb             ishst
    // 0xb76dd8: StoreField: r2->field_7 = d6
    //     0xb76dd8: stur            d6, [x2, #7]
    // 0xb76ddc: ldur            x16, [fp, #-0x28]
    // 0xb76de0: stp             x2, x16, [SP, #0x10]
    // 0xb76de4: r16 = 1.000000
    //     0xb76de4: ldr             x16, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xb76de8: stp             x0, x16, [SP]
    // 0xb76dec: ldur            x0, [fp, #-0x28]
    // 0xb76df0: ClosureCall
    //     0xb76df0: add             x4, PP, #0xd2, lsl #12  ; [pp+0xd2878] List(11) [0, 0x4, 0x4, 0x1, "color", 0x3, "endFraction", 0x2, "startFraction", 0x1, Null]
    //     0xb76df4: ldr             x4, [x4, #0x878]
    //     0xb76df8: ldur            x2, [x0, #0x1f]
    //     0xb76dfc: blr             x2
    // 0xb76e00: ldur            d0, [fp, #-0x40]
    // 0xb76e04: ldur            d2, [fp, #-0x48]
    // 0xb76e08: d1 = 0.000000
    //     0xb76e08: eor             v1.16b, v1.16b, v1.16b
    // 0xb76e0c: fsub            d3, d0, d2
    // 0xb76e10: fcmp            d3, d1
    // 0xb76e14: b.le            #0xb76e9c
    // 0xb76e18: ldur            x1, [fp, #-8]
    // 0xb76e1c: LoadField: r0 = r1->field_f
    //     0xb76e1c: ldur            w0, [x1, #0xf]
    // 0xb76e20: DecompressPointer r0
    //     0xb76e20: add             x0, x0, HEAP, lsl #32
    // 0xb76e24: r2 = inline_Allocate_Double()
    //     0xb76e24: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xb76e28: add             x2, x2, #0x10
    //     0xb76e2c: cmp             x3, x2
    //     0xb76e30: b.ls            #0xb77258
    //     0xb76e34: str             x2, [THR, #0x60]  ; THR::top
    //     0xb76e38: sub             x2, x2, #0xf
    //     0xb76e3c: mov             x3, #0xe19c
    //     0xb76e40: movk            x3, #3, lsl #16
    //     0xb76e44: stur            x3, [x2, #-1]
    // 0xb76e48: dmb             ishst
    // 0xb76e4c: StoreField: r2->field_7 = d0
    //     0xb76e4c: stur            d0, [x2, #7]
    // 0xb76e50: r3 = inline_Allocate_Double()
    //     0xb76e50: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xb76e54: add             x3, x3, #0x10
    //     0xb76e58: cmp             x4, x3
    //     0xb76e5c: b.ls            #0xb7727c
    //     0xb76e60: str             x3, [THR, #0x60]  ; THR::top
    //     0xb76e64: sub             x3, x3, #0xf
    //     0xb76e68: mov             x4, #0xe19c
    //     0xb76e6c: movk            x4, #3, lsl #16
    //     0xb76e70: stur            x4, [x3, #-1]
    // 0xb76e74: dmb             ishst
    // 0xb76e78: StoreField: r3->field_7 = d2
    //     0xb76e78: stur            d2, [x3, #7]
    // 0xb76e7c: ldur            x16, [fp, #-0x28]
    // 0xb76e80: stp             x3, x16, [SP, #0x10]
    // 0xb76e84: stp             x0, x2, [SP]
    // 0xb76e88: ldur            x0, [fp, #-0x28]
    // 0xb76e8c: ClosureCall
    //     0xb76e8c: add             x4, PP, #0xd2, lsl #12  ; [pp+0xd2878] List(11) [0, 0x4, 0x4, 0x1, "color", 0x3, "endFraction", 0x2, "startFraction", 0x1, Null]
    //     0xb76e90: ldr             x4, [x4, #0x878]
    //     0xb76e94: ldur            x2, [x0, #0x1f]
    //     0xb76e98: blr             x2
    // 0xb76e9c: ldur            d1, [fp, #-0x38]
    // 0xb76ea0: ldur            d0, [fp, #-0x48]
    // 0xb76ea4: fcmp            d0, d1
    // 0xb76ea8: b.le            #0xb77004
    // 0xb76eac: ldur            d3, [fp, #-0x30]
    // 0xb76eb0: d2 = 0.000000
    //     0xb76eb0: eor             v2.16b, v2.16b, v2.16b
    // 0xb76eb4: fcmp            d3, d2
    // 0xb76eb8: b.le            #0xb76f18
    // 0xb76ebc: fcmp            d2, d3
    // 0xb76ec0: b.le            #0xb76ed4
    // 0xb76ec4: d5 = 0.000000
    //     0xb76ec4: eor             v5.16b, v5.16b, v5.16b
    // 0xb76ec8: d4 = 0.010000
    //     0xb76ec8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xb76ecc: ldr             d4, [x17, #0x398]
    // 0xb76ed0: b               #0xb76f08
    // 0xb76ed4: d4 = 0.010000
    //     0xb76ed4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xb76ed8: ldr             d4, [x17, #0x398]
    // 0xb76edc: fcmp            d3, d4
    // 0xb76ee0: b.le            #0xb76ef0
    // 0xb76ee4: d5 = 0.010000
    //     0xb76ee4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xb76ee8: ldr             d5, [x17, #0x398]
    // 0xb76eec: b               #0xb76f08
    // 0xb76ef0: fcmp            d3, d3
    // 0xb76ef4: b.vc            #0xb76f04
    // 0xb76ef8: d5 = 0.010000
    //     0xb76ef8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xb76efc: ldr             d5, [x17, #0x398]
    // 0xb76f00: b               #0xb76f08
    // 0xb76f04: mov             v5.16b, v3.16b
    // 0xb76f08: fmul            d6, d1, d5
    // 0xb76f0c: fdiv            d5, d6, d4
    // 0xb76f10: fadd            d6, d3, d5
    // 0xb76f14: b               #0xb76f24
    // 0xb76f18: d4 = 0.010000
    //     0xb76f18: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xb76f1c: ldr             d4, [x17, #0x398]
    // 0xb76f20: d6 = 0.000000
    //     0xb76f20: eor             v6.16b, v6.16b, v6.16b
    // 0xb76f24: d5 = 1.000000
    //     0xb76f24: fmov            d5, #1.00000000
    // 0xb76f28: fcmp            d5, d0
    // 0xb76f2c: b.le            #0xb76f7c
    // 0xb76f30: fsub            d7, d5, d0
    // 0xb76f34: fcmp            d2, d7
    // 0xb76f38: b.le            #0xb76f44
    // 0xb76f3c: d7 = 0.000000
    //     0xb76f3c: eor             v7.16b, v7.16b, v7.16b
    // 0xb76f40: b               #0xb76f68
    // 0xb76f44: fcmp            d7, d4
    // 0xb76f48: b.le            #0xb76f58
    // 0xb76f4c: d7 = 0.010000
    //     0xb76f4c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xb76f50: ldr             d7, [x17, #0x398]
    // 0xb76f54: b               #0xb76f68
    // 0xb76f58: fcmp            d7, d7
    // 0xb76f5c: b.vc            #0xb76f68
    // 0xb76f60: d7 = 0.010000
    //     0xb76f60: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xb76f64: ldr             d7, [x17, #0x398]
    // 0xb76f68: fmul            d8, d1, d7
    // 0xb76f6c: fdiv            d7, d8, d4
    // 0xb76f70: fsub            d8, d0, d7
    // 0xb76f74: mov             v0.16b, v8.16b
    // 0xb76f78: b               #0xb76f80
    // 0xb76f7c: d0 = 1.000000
    //     0xb76f7c: fmov            d0, #1.00000000
    // 0xb76f80: ldur            x1, [fp, #-8]
    // 0xb76f84: LoadField: r0 = r1->field_b
    //     0xb76f84: ldur            w0, [x1, #0xb]
    // 0xb76f88: DecompressPointer r0
    //     0xb76f88: add             x0, x0, HEAP, lsl #32
    // 0xb76f8c: r2 = inline_Allocate_Double()
    //     0xb76f8c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xb76f90: add             x2, x2, #0x10
    //     0xb76f94: cmp             x3, x2
    //     0xb76f98: b.ls            #0xb772a0
    //     0xb76f9c: str             x2, [THR, #0x60]  ; THR::top
    //     0xb76fa0: sub             x2, x2, #0xf
    //     0xb76fa4: mov             x3, #0xe19c
    //     0xb76fa8: movk            x3, #3, lsl #16
    //     0xb76fac: stur            x3, [x2, #-1]
    // 0xb76fb0: dmb             ishst
    // 0xb76fb4: StoreField: r2->field_7 = d6
    //     0xb76fb4: stur            d6, [x2, #7]
    // 0xb76fb8: r3 = inline_Allocate_Double()
    //     0xb76fb8: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xb76fbc: add             x3, x3, #0x10
    //     0xb76fc0: cmp             x4, x3
    //     0xb76fc4: b.ls            #0xb772d4
    //     0xb76fc8: str             x3, [THR, #0x60]  ; THR::top
    //     0xb76fcc: sub             x3, x3, #0xf
    //     0xb76fd0: mov             x4, #0xe19c
    //     0xb76fd4: movk            x4, #3, lsl #16
    //     0xb76fd8: stur            x4, [x3, #-1]
    // 0xb76fdc: dmb             ishst
    // 0xb76fe0: StoreField: r3->field_7 = d0
    //     0xb76fe0: stur            d0, [x3, #7]
    // 0xb76fe4: ldur            x16, [fp, #-0x28]
    // 0xb76fe8: stp             x2, x16, [SP, #0x10]
    // 0xb76fec: stp             x0, x3, [SP]
    // 0xb76ff0: ldur            x0, [fp, #-0x28]
    // 0xb76ff4: ClosureCall
    //     0xb76ff4: add             x4, PP, #0xd2, lsl #12  ; [pp+0xd2878] List(11) [0, 0x4, 0x4, 0x1, "color", 0x3, "endFraction", 0x2, "startFraction", 0x1, Null]
    //     0xb76ff8: ldr             x4, [x4, #0x878]
    //     0xb76ffc: ldur            x2, [x0, #0x1f]
    //     0xb77000: blr             x2
    // 0xb77004: ldur            d1, [fp, #-0x30]
    // 0xb77008: ldur            d2, [fp, #-0x50]
    // 0xb7700c: d0 = 0.000000
    //     0xb7700c: eor             v0.16b, v0.16b, v0.16b
    // 0xb77010: fsub            d3, d1, d2
    // 0xb77014: fcmp            d3, d0
    // 0xb77018: b.le            #0xb770a0
    // 0xb7701c: ldur            x1, [fp, #-8]
    // 0xb77020: LoadField: r0 = r1->field_f
    //     0xb77020: ldur            w0, [x1, #0xf]
    // 0xb77024: DecompressPointer r0
    //     0xb77024: add             x0, x0, HEAP, lsl #32
    // 0xb77028: r2 = inline_Allocate_Double()
    //     0xb77028: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xb7702c: add             x2, x2, #0x10
    //     0xb77030: cmp             x3, x2
    //     0xb77034: b.ls            #0xb77308
    //     0xb77038: str             x2, [THR, #0x60]  ; THR::top
    //     0xb7703c: sub             x2, x2, #0xf
    //     0xb77040: mov             x3, #0xe19c
    //     0xb77044: movk            x3, #3, lsl #16
    //     0xb77048: stur            x3, [x2, #-1]
    // 0xb7704c: dmb             ishst
    // 0xb77050: StoreField: r2->field_7 = d1
    //     0xb77050: stur            d1, [x2, #7]
    // 0xb77054: r3 = inline_Allocate_Double()
    //     0xb77054: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xb77058: add             x3, x3, #0x10
    //     0xb7705c: cmp             x4, x3
    //     0xb77060: b.ls            #0xb7732c
    //     0xb77064: str             x3, [THR, #0x60]  ; THR::top
    //     0xb77068: sub             x3, x3, #0xf
    //     0xb7706c: mov             x4, #0xe19c
    //     0xb77070: movk            x4, #3, lsl #16
    //     0xb77074: stur            x4, [x3, #-1]
    // 0xb77078: dmb             ishst
    // 0xb7707c: StoreField: r3->field_7 = d2
    //     0xb7707c: stur            d2, [x3, #7]
    // 0xb77080: ldur            x16, [fp, #-0x28]
    // 0xb77084: stp             x3, x16, [SP, #0x10]
    // 0xb77088: stp             x0, x2, [SP]
    // 0xb7708c: ldur            x0, [fp, #-0x28]
    // 0xb77090: ClosureCall
    //     0xb77090: add             x4, PP, #0xd2, lsl #12  ; [pp+0xd2878] List(11) [0, 0x4, 0x4, 0x1, "color", 0x3, "endFraction", 0x2, "startFraction", 0x1, Null]
    //     0xb77094: ldr             x4, [x4, #0x878]
    //     0xb77098: ldur            x2, [x0, #0x1f]
    //     0xb7709c: blr             x2
    // 0xb770a0: ldur            d1, [fp, #-0x38]
    // 0xb770a4: ldur            d0, [fp, #-0x50]
    // 0xb770a8: fcmp            d0, d1
    // 0xb770ac: b.le            #0xb77184
    // 0xb770b0: d2 = 1.000000
    //     0xb770b0: fmov            d2, #1.00000000
    // 0xb770b4: fcmp            d2, d0
    // 0xb770b8: b.le            #0xb77124
    // 0xb770bc: d3 = 0.000000
    //     0xb770bc: eor             v3.16b, v3.16b, v3.16b
    // 0xb770c0: fsub            d4, d2, d0
    // 0xb770c4: fcmp            d3, d4
    // 0xb770c8: b.le            #0xb770dc
    // 0xb770cc: d3 = 0.000000
    //     0xb770cc: eor             v3.16b, v3.16b, v3.16b
    // 0xb770d0: d2 = 0.010000
    //     0xb770d0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xb770d4: ldr             d2, [x17, #0x398]
    // 0xb770d8: b               #0xb77110
    // 0xb770dc: d2 = 0.010000
    //     0xb770dc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xb770e0: ldr             d2, [x17, #0x398]
    // 0xb770e4: fcmp            d4, d2
    // 0xb770e8: b.le            #0xb770f8
    // 0xb770ec: d3 = 0.010000
    //     0xb770ec: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xb770f0: ldr             d3, [x17, #0x398]
    // 0xb770f4: b               #0xb77110
    // 0xb770f8: fcmp            d4, d4
    // 0xb770fc: b.vc            #0xb7710c
    // 0xb77100: d3 = 0.010000
    //     0xb77100: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xb77104: ldr             d3, [x17, #0x398]
    // 0xb77108: b               #0xb77110
    // 0xb7710c: mov             v3.16b, v4.16b
    // 0xb77110: fmul            d4, d1, d3
    // 0xb77114: fdiv            d1, d4, d2
    // 0xb77118: fsub            d2, d0, d1
    // 0xb7711c: mov             v0.16b, v2.16b
    // 0xb77120: b               #0xb77128
    // 0xb77124: d0 = 1.000000
    //     0xb77124: fmov            d0, #1.00000000
    // 0xb77128: ldur            x0, [fp, #-8]
    // 0xb7712c: LoadField: r1 = r0->field_b
    //     0xb7712c: ldur            w1, [x0, #0xb]
    // 0xb77130: DecompressPointer r1
    //     0xb77130: add             x1, x1, HEAP, lsl #32
    // 0xb77134: r0 = inline_Allocate_Double()
    //     0xb77134: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xb77138: add             x0, x0, #0x10
    //     0xb7713c: cmp             x2, x0
    //     0xb77140: b.ls            #0xb77350
    //     0xb77144: str             x0, [THR, #0x60]  ; THR::top
    //     0xb77148: sub             x0, x0, #0xf
    //     0xb7714c: mov             x2, #0xe19c
    //     0xb77150: movk            x2, #3, lsl #16
    //     0xb77154: stur            x2, [x0, #-1]
    // 0xb77158: dmb             ishst
    // 0xb7715c: StoreField: r0->field_7 = d0
    //     0xb7715c: stur            d0, [x0, #7]
    // 0xb77160: ldur            x16, [fp, #-0x28]
    // 0xb77164: r30 = 0.000000
    //     0xb77164: ldr             lr, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xb77168: stp             lr, x16, [SP, #0x10]
    // 0xb7716c: stp             x1, x0, [SP]
    // 0xb77170: ldur            x0, [fp, #-0x28]
    // 0xb77174: ClosureCall
    //     0xb77174: add             x4, PP, #0xd2, lsl #12  ; [pp+0xd2878] List(11) [0, 0x4, 0x4, 0x1, "color", 0x3, "endFraction", 0x2, "startFraction", 0x1, Null]
    //     0xb77178: ldr             x4, [x4, #0x878]
    //     0xb7717c: ldur            x2, [x0, #0x1f]
    //     0xb77180: blr             x2
    // 0xb77184: r0 = Null
    //     0xb77184: mov             x0, NULL
    // 0xb77188: LeaveFrame
    //     0xb77188: mov             SP, fp
    //     0xb7718c: ldp             fp, lr, [SP], #0x10
    // 0xb77190: ret
    //     0xb77190: ret             
    // 0xb77194: ldur            x0, [fp, #-0x20]
    // 0xb77198: LoadField: r1 = r0->field_f
    //     0xb77198: ldur            w1, [x0, #0xf]
    // 0xb7719c: DecompressPointer r1
    //     0xb7719c: add             x1, x1, HEAP, lsl #32
    // 0xb771a0: LoadField: r0 = r1->field_2b
    //     0xb771a0: ldur            w0, [x1, #0x2b]
    // 0xb771a4: DecompressPointer r0
    //     0xb771a4: add             x0, x0, HEAP, lsl #32
    // 0xb771a8: cmp             w0, NULL
    // 0xb771ac: b.eq            #0xb77368
    // 0xb771b0: r16 = 136
    //     0xb771b0: mov             x16, #0x88
    // 0xb771b4: stp             x16, NULL, [SP]
    // 0xb771b8: r0 = ByteData()
    //     0xb771b8: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb771bc: r0 = Null
    //     0xb771bc: mov             x0, NULL
    // 0xb771c0: cmp             w0, NULL
    // 0xb771c4: b.eq            #0xb7736c
    // 0xb771c8: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xb771c8: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xb771cc: r0 = Throw()
    //     0xb771cc: bl              #0x13ddb2c  ; ThrowStub
    // 0xb771d0: brk             #0
    // 0xb771d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb771d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb771d8: b               #0xb76a48
    // 0xb771dc: stp             q2, q3, [SP, #-0x20]!
    // 0xb771e0: stp             q0, q1, [SP, #-0x20]!
    // 0xb771e4: stp             x1, x2, [SP, #-0x10]!
    // 0xb771e8: r0 = AllocateDouble()
    //     0xb771e8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb771ec: ldp             x1, x2, [SP], #0x10
    // 0xb771f0: ldp             q0, q1, [SP], #0x20
    // 0xb771f4: ldp             q2, q3, [SP], #0x20
    // 0xb771f8: b               #0xb76b44
    // 0xb771fc: stp             q1, q3, [SP, #-0x20]!
    // 0xb77200: SaveReg d0
    //     0xb77200: str             q0, [SP, #-0x10]!
    // 0xb77204: stp             x2, x3, [SP, #-0x10]!
    // 0xb77208: SaveReg r1
    //     0xb77208: str             x1, [SP, #-8]!
    // 0xb7720c: r0 = AllocateDouble()
    //     0xb7720c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb77210: RestoreReg r1
    //     0xb77210: ldr             x1, [SP], #8
    // 0xb77214: ldp             x2, x3, [SP], #0x10
    // 0xb77218: RestoreReg d0
    //     0xb77218: ldr             q0, [SP], #0x10
    // 0xb7721c: ldp             q1, q3, [SP], #0x20
    // 0xb77220: b               #0xb76bf0
    // 0xb77224: stp             q5, q6, [SP, #-0x20]!
    // 0xb77228: stp             q3, q4, [SP, #-0x20]!
    // 0xb7722c: stp             q1, q2, [SP, #-0x20]!
    // 0xb77230: SaveReg d0
    //     0xb77230: str             q0, [SP, #-0x10]!
    // 0xb77234: stp             x0, x1, [SP, #-0x10]!
    // 0xb77238: r0 = AllocateDouble()
    //     0xb77238: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb7723c: mov             x2, x0
    // 0xb77240: ldp             x0, x1, [SP], #0x10
    // 0xb77244: RestoreReg d0
    //     0xb77244: ldr             q0, [SP], #0x10
    // 0xb77248: ldp             q1, q2, [SP], #0x20
    // 0xb7724c: ldp             q3, q4, [SP], #0x20
    // 0xb77250: ldp             q5, q6, [SP], #0x20
    // 0xb77254: b               #0xb76dd8
    // 0xb77258: stp             q1, q2, [SP, #-0x20]!
    // 0xb7725c: SaveReg d0
    //     0xb7725c: str             q0, [SP, #-0x10]!
    // 0xb77260: stp             x0, x1, [SP, #-0x10]!
    // 0xb77264: r0 = AllocateDouble()
    //     0xb77264: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb77268: mov             x2, x0
    // 0xb7726c: ldp             x0, x1, [SP], #0x10
    // 0xb77270: RestoreReg d0
    //     0xb77270: ldr             q0, [SP], #0x10
    // 0xb77274: ldp             q1, q2, [SP], #0x20
    // 0xb77278: b               #0xb76e4c
    // 0xb7727c: stp             q1, q2, [SP, #-0x20]!
    // 0xb77280: stp             x1, x2, [SP, #-0x10]!
    // 0xb77284: SaveReg r0
    //     0xb77284: str             x0, [SP, #-8]!
    // 0xb77288: r0 = AllocateDouble()
    //     0xb77288: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb7728c: mov             x3, x0
    // 0xb77290: RestoreReg r0
    //     0xb77290: ldr             x0, [SP], #8
    // 0xb77294: ldp             x1, x2, [SP], #0x10
    // 0xb77298: ldp             q1, q2, [SP], #0x20
    // 0xb7729c: b               #0xb76e78
    // 0xb772a0: stp             q5, q6, [SP, #-0x20]!
    // 0xb772a4: stp             q3, q4, [SP, #-0x20]!
    // 0xb772a8: stp             q1, q2, [SP, #-0x20]!
    // 0xb772ac: SaveReg d0
    //     0xb772ac: str             q0, [SP, #-0x10]!
    // 0xb772b0: stp             x0, x1, [SP, #-0x10]!
    // 0xb772b4: r0 = AllocateDouble()
    //     0xb772b4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb772b8: mov             x2, x0
    // 0xb772bc: ldp             x0, x1, [SP], #0x10
    // 0xb772c0: RestoreReg d0
    //     0xb772c0: ldr             q0, [SP], #0x10
    // 0xb772c4: ldp             q1, q2, [SP], #0x20
    // 0xb772c8: ldp             q3, q4, [SP], #0x20
    // 0xb772cc: ldp             q5, q6, [SP], #0x20
    // 0xb772d0: b               #0xb76fb4
    // 0xb772d4: stp             q4, q5, [SP, #-0x20]!
    // 0xb772d8: stp             q2, q3, [SP, #-0x20]!
    // 0xb772dc: stp             q0, q1, [SP, #-0x20]!
    // 0xb772e0: stp             x1, x2, [SP, #-0x10]!
    // 0xb772e4: SaveReg r0
    //     0xb772e4: str             x0, [SP, #-8]!
    // 0xb772e8: r0 = AllocateDouble()
    //     0xb772e8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb772ec: mov             x3, x0
    // 0xb772f0: RestoreReg r0
    //     0xb772f0: ldr             x0, [SP], #8
    // 0xb772f4: ldp             x1, x2, [SP], #0x10
    // 0xb772f8: ldp             q0, q1, [SP], #0x20
    // 0xb772fc: ldp             q2, q3, [SP], #0x20
    // 0xb77300: ldp             q4, q5, [SP], #0x20
    // 0xb77304: b               #0xb76fe0
    // 0xb77308: stp             q1, q2, [SP, #-0x20]!
    // 0xb7730c: SaveReg d0
    //     0xb7730c: str             q0, [SP, #-0x10]!
    // 0xb77310: stp             x0, x1, [SP, #-0x10]!
    // 0xb77314: r0 = AllocateDouble()
    //     0xb77314: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb77318: mov             x2, x0
    // 0xb7731c: ldp             x0, x1, [SP], #0x10
    // 0xb77320: RestoreReg d0
    //     0xb77320: ldr             q0, [SP], #0x10
    // 0xb77324: ldp             q1, q2, [SP], #0x20
    // 0xb77328: b               #0xb77050
    // 0xb7732c: stp             q0, q2, [SP, #-0x20]!
    // 0xb77330: stp             x1, x2, [SP, #-0x10]!
    // 0xb77334: SaveReg r0
    //     0xb77334: str             x0, [SP, #-8]!
    // 0xb77338: r0 = AllocateDouble()
    //     0xb77338: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb7733c: mov             x3, x0
    // 0xb77340: RestoreReg r0
    //     0xb77340: ldr             x0, [SP], #8
    // 0xb77344: ldp             x1, x2, [SP], #0x10
    // 0xb77348: ldp             q0, q2, [SP], #0x20
    // 0xb7734c: b               #0xb7707c
    // 0xb77350: SaveReg d0
    //     0xb77350: str             q0, [SP, #-0x10]!
    // 0xb77354: SaveReg r1
    //     0xb77354: str             x1, [SP, #-8]!
    // 0xb77358: r0 = AllocateDouble()
    //     0xb77358: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb7735c: RestoreReg r1
    //     0xb7735c: ldr             x1, [SP], #8
    // 0xb77360: RestoreReg d0
    //     0xb77360: ldr             q0, [SP], #0x10
    // 0xb77364: b               #0xb7715c
    // 0xb77368: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb77368: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb7736c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb7736c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void drawLinearIndicator(dynamic, {required Color color, required double endFraction, required double startFraction}) {
    // ** addr: 0xb77370, size: 0x2ec
    // 0xb77370: EnterFrame
    //     0xb77370: stp             fp, lr, [SP, #-0x10]!
    //     0xb77374: mov             fp, SP
    // 0xb77378: AllocStack(0x60)
    //     0xb77378: sub             SP, SP, #0x60
    // 0xb7737c: SetupParameters(_LinearProgressIndicatorPainter this /* r2 */, {dynamic required /* r1, fp-0x10 */, dynamic required /* r3 */, dynamic required /* r0 */})
    //     0xb7737c: eor             v0.16b, v0.16b, v0.16b
    //     0xb77380: ldur            w0, [x4, #0x13]
    //     0xb77384: sub             x1, x0, #2
    //     0xb77388: add             x2, fp, w1, sxtw #2
    //     0xb7738c: ldr             x2, [x2, #0x10]
    //     0xb77390: ldur            w1, [x4, #0x23]
    //     0xb77394: add             x1, x1, HEAP, lsl #32
    //     0xb77398: sub             w3, w0, w1
    //     0xb7739c: add             x1, fp, w3, sxtw #2
    //     0xb773a0: ldr             x1, [x1, #8]
    //     0xb773a4: stur            x1, [fp, #-0x10]
    //     0xb773a8: ldur            w3, [x4, #0x2b]
    //     0xb773ac: add             x3, x3, HEAP, lsl #32
    //     0xb773b0: sub             w5, w0, w3
    //     0xb773b4: add             x3, fp, w5, sxtw #2
    //     0xb773b8: ldr             x3, [x3, #8]
    //     0xb773bc: ldur            w5, [x4, #0x33]
    //     0xb773c0: add             x5, x5, HEAP, lsl #32
    //     0xb773c4: sub             w4, w0, w5
    //     0xb773c8: add             x0, fp, w4, sxtw #2
    //     0xb773cc: ldr             x0, [x0, #8]
    //     0xb773d0: ldur            w4, [x2, #0x17]
    //     0xb773d4: add             x4, x4, HEAP, lsl #32
    //     0xb773d8: stur            x4, [fp, #-8]
    // 0xb7737c: d0 = 0.000000
    // 0xb773dc: CheckStackOverflow
    //     0xb773dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb773e0: cmp             SP, x16
    //     0xb773e4: b.ls            #0xb77654
    // 0xb773e8: LoadField: d1 = r3->field_7
    //     0xb773e8: ldur            d1, [x3, #7]
    // 0xb773ec: LoadField: d2 = r0->field_7
    //     0xb773ec: ldur            d2, [x0, #7]
    // 0xb773f0: fsub            d3, d1, d2
    // 0xb773f4: fcmp            d0, d3
    // 0xb773f8: b.lt            #0xb7740c
    // 0xb773fc: r0 = Null
    //     0xb773fc: mov             x0, NULL
    // 0xb77400: LeaveFrame
    //     0xb77400: mov             SP, fp
    //     0xb77404: ldp             fp, lr, [SP], #0x10
    // 0xb77408: ret
    //     0xb77408: ret             
    // 0xb7740c: LoadField: r0 = r4->field_f
    //     0xb7740c: ldur            w0, [x4, #0xf]
    // 0xb77410: DecompressPointer r0
    //     0xb77410: add             x0, x0, HEAP, lsl #32
    // 0xb77414: LoadField: r2 = r0->field_1f
    //     0xb77414: ldur            w2, [x0, #0x1f]
    // 0xb77418: DecompressPointer r2
    //     0xb77418: add             x2, x2, HEAP, lsl #32
    // 0xb7741c: r16 = Instance_TextDirection
    //     0xb7741c: ldr             x16, [PP, #0x25b0]  ; [pp+0x25b0] Obj!TextDirection@12c73a1
    // 0xb77420: cmp             w2, w16
    // 0xb77424: r16 = true
    //     0xb77424: add             x16, NULL, #0x20  ; true
    // 0xb77428: r17 = false
    //     0xb77428: add             x17, NULL, #0x30  ; false
    // 0xb7742c: csel            x0, x16, x17, eq
    // 0xb77430: tbnz            w0, #4, #0xb77440
    // 0xb77434: mov             v3.16b, v2.16b
    // 0xb77438: d0 = 1.000000
    //     0xb77438: fmov            d0, #1.00000000
    // 0xb7743c: b               #0xb77448
    // 0xb77440: d0 = 1.000000
    //     0xb77440: fmov            d0, #1.00000000
    // 0xb77444: fsub            d3, d0, d1
    // 0xb77448: ArrayLoad: r2 = r4[0]  ; List_4
    //     0xb77448: ldur            w2, [x4, #0x17]
    // 0xb7744c: DecompressPointer r2
    //     0xb7744c: add             x2, x2, HEAP, lsl #32
    // 0xb77450: LoadField: d4 = r2->field_7
    //     0xb77450: ldur            d4, [x2, #7]
    // 0xb77454: fmul            d5, d3, d4
    // 0xb77458: stur            d5, [fp, #-0x50]
    // 0xb7745c: tbnz            w0, #4, #0xb77468
    // 0xb77460: mov             v0.16b, v1.16b
    // 0xb77464: b               #0xb77470
    // 0xb77468: fsub            d1, d0, d2
    // 0xb7746c: mov             v0.16b, v1.16b
    // 0xb77470: fmul            d1, d0, d4
    // 0xb77474: stur            d1, [fp, #-0x48]
    // 0xb77478: LoadField: d0 = r2->field_f
    //     0xb77478: ldur            d0, [x2, #0xf]
    // 0xb7747c: stur            d0, [fp, #-0x40]
    // 0xb77480: r0 = Rect()
    //     0xb77480: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xb77484: ldur            d0, [fp, #-0x50]
    // 0xb77488: stur            x0, [fp, #-0x18]
    // 0xb7748c: StoreField: r0->field_7 = d0
    //     0xb7748c: stur            d0, [x0, #7]
    // 0xb77490: StoreField: r0->field_f = rZR
    //     0xb77490: stur            xzr, [x0, #0xf]
    // 0xb77494: ldur            d0, [fp, #-0x48]
    // 0xb77498: ArrayStore: r0[0] = d0  ; List_8
    //     0xb77498: stur            d0, [x0, #0x17]
    // 0xb7749c: ldur            d0, [fp, #-0x40]
    // 0xb774a0: StoreField: r0->field_1f = d0
    //     0xb774a0: stur            d0, [x0, #0x1f]
    // 0xb774a4: r16 = 136
    //     0xb774a4: mov             x16, #0x88
    // 0xb774a8: stp             x16, NULL, [SP]
    // 0xb774ac: r0 = ByteData()
    //     0xb774ac: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb774b0: stur            x0, [fp, #-0x20]
    // 0xb774b4: r0 = Paint()
    //     0xb774b4: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb774b8: mov             x3, x0
    // 0xb774bc: ldur            x0, [fp, #-0x20]
    // 0xb774c0: stur            x3, [fp, #-0x28]
    // 0xb774c4: StoreField: r3->field_7 = r0
    //     0xb774c4: stur            w0, [x3, #7]
    // 0xb774c8: mov             x1, x3
    // 0xb774cc: ldur            x2, [fp, #-0x10]
    // 0xb774d0: r0 = color=()
    //     0xb774d0: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb774d4: ldur            x0, [fp, #-8]
    // 0xb774d8: LoadField: r1 = r0->field_f
    //     0xb774d8: ldur            w1, [x0, #0xf]
    // 0xb774dc: DecompressPointer r1
    //     0xb774dc: add             x1, x1, HEAP, lsl #32
    // 0xb774e0: LoadField: r2 = r1->field_23
    //     0xb774e0: ldur            w2, [x1, #0x23]
    // 0xb774e4: DecompressPointer r2
    //     0xb774e4: add             x2, x2, HEAP, lsl #32
    // 0xb774e8: cmp             w2, NULL
    // 0xb774ec: b.eq            #0xb77630
    // 0xb774f0: LoadField: r3 = r1->field_1f
    //     0xb774f0: ldur            w3, [x1, #0x1f]
    // 0xb774f4: DecompressPointer r3
    //     0xb774f4: add             x3, x3, HEAP, lsl #32
    // 0xb774f8: r1 = LoadClassIdInstr(r2)
    //     0xb774f8: ldur            x1, [x2, #-1]
    //     0xb774fc: ubfx            x1, x1, #0xc, #0x14
    // 0xb77500: cmp             x1, #0xb88
    // 0xb77504: b.ne            #0xb775cc
    // 0xb77508: LoadField: r1 = r3->field_7
    //     0xb77508: ldur            x1, [x3, #7]
    // 0xb7750c: cmp             x1, #0
    // 0xb77510: b.gt            #0xb77570
    // 0xb77514: LoadField: r1 = r2->field_b
    //     0xb77514: ldur            w1, [x2, #0xb]
    // 0xb77518: DecompressPointer r1
    //     0xb77518: add             x1, x1, HEAP, lsl #32
    // 0xb7751c: stur            x1, [fp, #-0x38]
    // 0xb77520: LoadField: r3 = r2->field_7
    //     0xb77520: ldur            w3, [x2, #7]
    // 0xb77524: DecompressPointer r3
    //     0xb77524: add             x3, x3, HEAP, lsl #32
    // 0xb77528: stur            x3, [fp, #-0x30]
    // 0xb7752c: LoadField: r4 = r2->field_13
    //     0xb7752c: ldur            w4, [x2, #0x13]
    // 0xb77530: DecompressPointer r4
    //     0xb77530: add             x4, x4, HEAP, lsl #32
    // 0xb77534: stur            x4, [fp, #-0x20]
    // 0xb77538: LoadField: r5 = r2->field_f
    //     0xb77538: ldur            w5, [x2, #0xf]
    // 0xb7753c: DecompressPointer r5
    //     0xb7753c: add             x5, x5, HEAP, lsl #32
    // 0xb77540: stur            x5, [fp, #-0x10]
    // 0xb77544: r0 = BorderRadius()
    //     0xb77544: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xb77548: mov             x1, x0
    // 0xb7754c: ldur            x0, [fp, #-0x38]
    // 0xb77550: StoreField: r1->field_7 = r0
    //     0xb77550: stur            w0, [x1, #7]
    // 0xb77554: ldur            x0, [fp, #-0x30]
    // 0xb77558: StoreField: r1->field_b = r0
    //     0xb77558: stur            w0, [x1, #0xb]
    // 0xb7755c: ldur            x0, [fp, #-0x20]
    // 0xb77560: StoreField: r1->field_f = r0
    //     0xb77560: stur            w0, [x1, #0xf]
    // 0xb77564: ldur            x0, [fp, #-0x10]
    // 0xb77568: StoreField: r1->field_13 = r0
    //     0xb77568: stur            w0, [x1, #0x13]
    // 0xb7756c: b               #0xb775fc
    // 0xb77570: LoadField: r0 = r2->field_7
    //     0xb77570: ldur            w0, [x2, #7]
    // 0xb77574: DecompressPointer r0
    //     0xb77574: add             x0, x0, HEAP, lsl #32
    // 0xb77578: stur            x0, [fp, #-0x38]
    // 0xb7757c: LoadField: r1 = r2->field_b
    //     0xb7757c: ldur            w1, [x2, #0xb]
    // 0xb77580: DecompressPointer r1
    //     0xb77580: add             x1, x1, HEAP, lsl #32
    // 0xb77584: stur            x1, [fp, #-0x30]
    // 0xb77588: LoadField: r3 = r2->field_f
    //     0xb77588: ldur            w3, [x2, #0xf]
    // 0xb7758c: DecompressPointer r3
    //     0xb7758c: add             x3, x3, HEAP, lsl #32
    // 0xb77590: stur            x3, [fp, #-0x20]
    // 0xb77594: LoadField: r4 = r2->field_13
    //     0xb77594: ldur            w4, [x2, #0x13]
    // 0xb77598: DecompressPointer r4
    //     0xb77598: add             x4, x4, HEAP, lsl #32
    // 0xb7759c: stur            x4, [fp, #-0x10]
    // 0xb775a0: r0 = BorderRadius()
    //     0xb775a0: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xb775a4: mov             x1, x0
    // 0xb775a8: ldur            x0, [fp, #-0x38]
    // 0xb775ac: StoreField: r1->field_7 = r0
    //     0xb775ac: stur            w0, [x1, #7]
    // 0xb775b0: ldur            x0, [fp, #-0x30]
    // 0xb775b4: StoreField: r1->field_b = r0
    //     0xb775b4: stur            w0, [x1, #0xb]
    // 0xb775b8: ldur            x0, [fp, #-0x20]
    // 0xb775bc: StoreField: r1->field_f = r0
    //     0xb775bc: stur            w0, [x1, #0xf]
    // 0xb775c0: ldur            x0, [fp, #-0x10]
    // 0xb775c4: StoreField: r1->field_13 = r0
    //     0xb775c4: stur            w0, [x1, #0x13]
    // 0xb775c8: b               #0xb775fc
    // 0xb775cc: cmp             x1, #0xb89
    // 0xb775d0: b.ne            #0xb775dc
    // 0xb775d4: mov             x1, x2
    // 0xb775d8: b               #0xb775fc
    // 0xb775dc: r0 = LoadClassIdInstr(r2)
    //     0xb775dc: ldur            x0, [x2, #-1]
    //     0xb775e0: ubfx            x0, x0, #0xc, #0x14
    // 0xb775e4: mov             x1, x2
    // 0xb775e8: mov             x2, x3
    // 0xb775ec: r0 = GDT[cid_x0 + -0x1000]()
    //     0xb775ec: sub             lr, x0, #1, lsl #12
    //     0xb775f0: ldr             lr, [x21, lr, lsl #3]
    //     0xb775f4: blr             lr
    // 0xb775f8: mov             x1, x0
    // 0xb775fc: ldur            x0, [fp, #-8]
    // 0xb77600: ldur            x2, [fp, #-0x18]
    // 0xb77604: r0 = toRRect()
    //     0xb77604: bl              #0xb77a10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xb77608: mov             x1, x0
    // 0xb7760c: ldur            x0, [fp, #-8]
    // 0xb77610: LoadField: r2 = r0->field_13
    //     0xb77610: ldur            w2, [x0, #0x13]
    // 0xb77614: DecompressPointer r2
    //     0xb77614: add             x2, x2, HEAP, lsl #32
    // 0xb77618: mov             x16, x1
    // 0xb7761c: mov             x1, x2
    // 0xb77620: mov             x2, x16
    // 0xb77624: ldur            x3, [fp, #-0x28]
    // 0xb77628: r0 = drawRRect()
    //     0xb77628: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0xb7762c: b               #0xb77644
    // 0xb77630: LoadField: r1 = r0->field_13
    //     0xb77630: ldur            w1, [x0, #0x13]
    // 0xb77634: DecompressPointer r1
    //     0xb77634: add             x1, x1, HEAP, lsl #32
    // 0xb77638: ldur            x2, [fp, #-0x18]
    // 0xb7763c: ldur            x3, [fp, #-0x28]
    // 0xb77640: r0 = drawRect()
    //     0xb77640: bl              #0xb704c8  ; [dart:ui] _NativeCanvas::drawRect
    // 0xb77644: r0 = Null
    //     0xb77644: mov             x0, NULL
    // 0xb77648: LeaveFrame
    //     0xb77648: mov             SP, fp
    //     0xb7764c: ldp             fp, lr, [SP], #0x10
    // 0xb77650: ret
    //     0xb77650: ret             
    // 0xb77654: r0 = StackOverflowSharedWithFPURegs()
    //     0xb77654: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb77658: b               #0xb773e8
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xb93748, size: 0x1fc
    // 0xb93748: EnterFrame
    //     0xb93748: stp             fp, lr, [SP, #-0x10]!
    //     0xb9374c: mov             fp, SP
    // 0xb93750: AllocStack(0x20)
    //     0xb93750: sub             SP, SP, #0x20
    // 0xb93754: SetupParameters(_LinearProgressIndicatorPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xb93754: mov             x4, x1
    //     0xb93758: mov             x3, x2
    //     0xb9375c: stur            x1, [fp, #-8]
    //     0xb93760: stur            x2, [fp, #-0x10]
    // 0xb93764: CheckStackOverflow
    //     0xb93764: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb93768: cmp             SP, x16
    //     0xb9376c: b.ls            #0xb9393c
    // 0xb93770: mov             x0, x3
    // 0xb93774: r2 = Null
    //     0xb93774: mov             x2, NULL
    // 0xb93778: r1 = Null
    //     0xb93778: mov             x1, NULL
    // 0xb9377c: r4 = 60
    //     0xb9377c: mov             x4, #0x3c
    // 0xb93780: branchIfSmi(r0, 0xb9378c)
    //     0xb93780: tbz             w0, #0, #0xb9378c
    // 0xb93784: r4 = LoadClassIdInstr(r0)
    //     0xb93784: ldur            x4, [x0, #-1]
    //     0xb93788: ubfx            x4, x4, #0xc, #0x14
    // 0xb9378c: r17 = 4335
    //     0xb9378c: mov             x17, #0x10ef
    // 0xb93790: cmp             x4, x17
    // 0xb93794: b.eq            #0xb937ac
    // 0xb93798: r8 = _LinearProgressIndicatorPainter
    //     0xb93798: add             x8, PP, #0xd2, lsl #12  ; [pp+0xd2858] Type: _LinearProgressIndicatorPainter
    //     0xb9379c: ldr             x8, [x8, #0x858]
    // 0xb937a0: r3 = Null
    //     0xb937a0: add             x3, PP, #0xd2, lsl #12  ; [pp+0xd2860] Null
    //     0xb937a4: ldr             x3, [x3, #0x860]
    // 0xb937a8: r0 = DefaultTypeTest()
    //     0xb937a8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb937ac: ldur            x1, [fp, #-0x10]
    // 0xb937b0: LoadField: r0 = r1->field_b
    //     0xb937b0: ldur            w0, [x1, #0xb]
    // 0xb937b4: DecompressPointer r0
    //     0xb937b4: add             x0, x0, HEAP, lsl #32
    // 0xb937b8: ldur            x2, [fp, #-8]
    // 0xb937bc: LoadField: r3 = r2->field_b
    //     0xb937bc: ldur            w3, [x2, #0xb]
    // 0xb937c0: DecompressPointer r3
    //     0xb937c0: add             x3, x3, HEAP, lsl #32
    // 0xb937c4: r4 = LoadClassIdInstr(r0)
    //     0xb937c4: ldur            x4, [x0, #-1]
    //     0xb937c8: ubfx            x4, x4, #0xc, #0x14
    // 0xb937cc: stp             x3, x0, [SP]
    // 0xb937d0: mov             x0, x4
    // 0xb937d4: mov             lr, x0
    // 0xb937d8: ldr             lr, [x21, lr, lsl #3]
    // 0xb937dc: blr             lr
    // 0xb937e0: tbnz            w0, #4, #0xb938ec
    // 0xb937e4: ldur            x2, [fp, #-8]
    // 0xb937e8: ldur            x1, [fp, #-0x10]
    // 0xb937ec: LoadField: r0 = r1->field_f
    //     0xb937ec: ldur            w0, [x1, #0xf]
    // 0xb937f0: DecompressPointer r0
    //     0xb937f0: add             x0, x0, HEAP, lsl #32
    // 0xb937f4: LoadField: r3 = r2->field_f
    //     0xb937f4: ldur            w3, [x2, #0xf]
    // 0xb937f8: DecompressPointer r3
    //     0xb937f8: add             x3, x3, HEAP, lsl #32
    // 0xb937fc: r4 = LoadClassIdInstr(r0)
    //     0xb937fc: ldur            x4, [x0, #-1]
    //     0xb93800: ubfx            x4, x4, #0xc, #0x14
    // 0xb93804: stp             x3, x0, [SP]
    // 0xb93808: mov             x0, x4
    // 0xb9380c: mov             lr, x0
    // 0xb93810: ldr             lr, [x21, lr, lsl #3]
    // 0xb93814: blr             lr
    // 0xb93818: tbnz            w0, #4, #0xb938ec
    // 0xb9381c: ldur            x2, [fp, #-8]
    // 0xb93820: ldur            x1, [fp, #-0x10]
    // 0xb93824: LoadField: r0 = r1->field_13
    //     0xb93824: ldur            w0, [x1, #0x13]
    // 0xb93828: DecompressPointer r0
    //     0xb93828: add             x0, x0, HEAP, lsl #32
    // 0xb9382c: LoadField: r3 = r2->field_13
    //     0xb9382c: ldur            w3, [x2, #0x13]
    // 0xb93830: DecompressPointer r3
    //     0xb93830: add             x3, x3, HEAP, lsl #32
    // 0xb93834: r4 = LoadClassIdInstr(r0)
    //     0xb93834: ldur            x4, [x0, #-1]
    //     0xb93838: ubfx            x4, x4, #0xc, #0x14
    // 0xb9383c: stp             x3, x0, [SP]
    // 0xb93840: mov             x0, x4
    // 0xb93844: mov             lr, x0
    // 0xb93848: ldr             lr, [x21, lr, lsl #3]
    // 0xb9384c: blr             lr
    // 0xb93850: tbnz            w0, #4, #0xb938ec
    // 0xb93854: ldur            x2, [fp, #-8]
    // 0xb93858: ldur            x1, [fp, #-0x10]
    // 0xb9385c: ArrayLoad: d0 = r1[0]  ; List_8
    //     0xb9385c: ldur            d0, [x1, #0x17]
    // 0xb93860: ArrayLoad: d1 = r2[0]  ; List_8
    //     0xb93860: ldur            d1, [x2, #0x17]
    // 0xb93864: fcmp            d0, d1
    // 0xb93868: b.ne            #0xb938ec
    // 0xb9386c: LoadField: r0 = r1->field_1f
    //     0xb9386c: ldur            w0, [x1, #0x1f]
    // 0xb93870: DecompressPointer r0
    //     0xb93870: add             x0, x0, HEAP, lsl #32
    // 0xb93874: LoadField: r3 = r2->field_1f
    //     0xb93874: ldur            w3, [x2, #0x1f]
    // 0xb93878: DecompressPointer r3
    //     0xb93878: add             x3, x3, HEAP, lsl #32
    // 0xb9387c: cmp             w0, w3
    // 0xb93880: b.ne            #0xb938ec
    // 0xb93884: LoadField: r0 = r1->field_23
    //     0xb93884: ldur            w0, [x1, #0x23]
    // 0xb93888: DecompressPointer r0
    //     0xb93888: add             x0, x0, HEAP, lsl #32
    // 0xb9388c: LoadField: r3 = r2->field_23
    //     0xb9388c: ldur            w3, [x2, #0x23]
    // 0xb93890: DecompressPointer r3
    //     0xb93890: add             x3, x3, HEAP, lsl #32
    // 0xb93894: r4 = LoadClassIdInstr(r0)
    //     0xb93894: ldur            x4, [x0, #-1]
    //     0xb93898: ubfx            x4, x4, #0xc, #0x14
    // 0xb9389c: stp             x3, x0, [SP]
    // 0xb938a0: mov             x0, x4
    // 0xb938a4: mov             lr, x0
    // 0xb938a8: ldr             lr, [x21, lr, lsl #3]
    // 0xb938ac: blr             lr
    // 0xb938b0: tbnz            w0, #4, #0xb938ec
    // 0xb938b4: ldur            x2, [fp, #-8]
    // 0xb938b8: ldur            x1, [fp, #-0x10]
    // 0xb938bc: LoadField: r0 = r1->field_2b
    //     0xb938bc: ldur            w0, [x1, #0x2b]
    // 0xb938c0: DecompressPointer r0
    //     0xb938c0: add             x0, x0, HEAP, lsl #32
    // 0xb938c4: LoadField: r3 = r2->field_2b
    //     0xb938c4: ldur            w3, [x2, #0x2b]
    // 0xb938c8: DecompressPointer r3
    //     0xb938c8: add             x3, x3, HEAP, lsl #32
    // 0xb938cc: r4 = LoadClassIdInstr(r0)
    //     0xb938cc: ldur            x4, [x0, #-1]
    //     0xb938d0: ubfx            x4, x4, #0xc, #0x14
    // 0xb938d4: stp             x3, x0, [SP]
    // 0xb938d8: mov             x0, x4
    // 0xb938dc: mov             lr, x0
    // 0xb938e0: ldr             lr, [x21, lr, lsl #3]
    // 0xb938e4: blr             lr
    // 0xb938e8: tbz             w0, #4, #0xb938f4
    // 0xb938ec: r0 = true
    //     0xb938ec: add             x0, NULL, #0x20  ; true
    // 0xb938f0: b               #0xb93930
    // 0xb938f4: ldur            x1, [fp, #-8]
    // 0xb938f8: ldur            x0, [fp, #-0x10]
    // 0xb938fc: LoadField: r2 = r0->field_2f
    //     0xb938fc: ldur            w2, [x0, #0x2f]
    // 0xb93900: DecompressPointer r2
    //     0xb93900: add             x2, x2, HEAP, lsl #32
    // 0xb93904: LoadField: r0 = r1->field_2f
    //     0xb93904: ldur            w0, [x1, #0x2f]
    // 0xb93908: DecompressPointer r0
    //     0xb93908: add             x0, x0, HEAP, lsl #32
    // 0xb9390c: r1 = LoadClassIdInstr(r2)
    //     0xb9390c: ldur            x1, [x2, #-1]
    //     0xb93910: ubfx            x1, x1, #0xc, #0x14
    // 0xb93914: stp             x0, x2, [SP]
    // 0xb93918: mov             x0, x1
    // 0xb9391c: mov             lr, x0
    // 0xb93920: ldr             lr, [x21, lr, lsl #3]
    // 0xb93924: blr             lr
    // 0xb93928: eor             x1, x0, #0x10
    // 0xb9392c: mov             x0, x1
    // 0xb93930: LeaveFrame
    //     0xb93930: mov             SP, fp
    //     0xb93934: ldp             fp, lr, [SP], #0x10
    // 0xb93938: ret
    //     0xb93938: ret             
    // 0xb9393c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9393c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb93940: b               #0xb93770
  }
}

// class id: 5125, size: 0x50, field offset: 0x48
class _LinearProgressIndicatorDefaultsM3Year2023 extends ProgressIndicatorThemeData {

  late final ColorScheme _colors; // offset: 0x4c

  get _ linearTrackColor(/* No info */) {
    // ** addr: 0x121b150, size: 0x6c
    // 0x121b150: EnterFrame
    //     0x121b150: stp             fp, lr, [SP, #-0x10]!
    //     0x121b154: mov             fp, SP
    // 0x121b158: CheckStackOverflow
    //     0x121b158: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121b15c: cmp             SP, x16
    //     0x121b160: b.ls            #0x121b1b4
    // 0x121b164: LoadField: r0 = r1->field_4b
    //     0x121b164: ldur            w0, [x1, #0x4b]
    // 0x121b168: DecompressPointer r0
    //     0x121b168: add             x0, x0, HEAP, lsl #32
    // 0x121b16c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x121b170: cmp             w0, w16
    // 0x121b174: b.ne            #0x121b184
    // 0x121b178: r2 = _colors
    //     0x121b178: add             x2, PP, #0xd2, lsl #12  ; [pp+0xd2848] Field <_LinearProgressIndicatorDefaultsM3Year2023@115243954._colors@115243954>: late final (offset: 0x4c)
    //     0x121b17c: ldr             x2, [x2, #0x848]
    // 0x121b180: r0 = InitLateFinalInstanceField()
    //     0x121b180: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x121b184: LoadField: r1 = r0->field_33
    //     0x121b184: ldur            w1, [x0, #0x33]
    // 0x121b188: DecompressPointer r1
    //     0x121b188: add             x1, x1, HEAP, lsl #32
    // 0x121b18c: cmp             w1, NULL
    // 0x121b190: b.ne            #0x121b1a4
    // 0x121b194: LoadField: r2 = r0->field_2b
    //     0x121b194: ldur            w2, [x0, #0x2b]
    // 0x121b198: DecompressPointer r2
    //     0x121b198: add             x2, x2, HEAP, lsl #32
    // 0x121b19c: mov             x0, x2
    // 0x121b1a0: b               #0x121b1a8
    // 0x121b1a4: mov             x0, x1
    // 0x121b1a8: LeaveFrame
    //     0x121b1a8: mov             SP, fp
    //     0x121b1ac: ldp             fp, lr, [SP], #0x10
    // 0x121b1b0: ret
    //     0x121b1b0: ret             
    // 0x121b1b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121b1b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121b1b8: b               #0x121b164
  }
  get _ color(/* No info */) {
    // ** addr: 0x1249564, size: 0x54
    // 0x1249564: EnterFrame
    //     0x1249564: stp             fp, lr, [SP, #-0x10]!
    //     0x1249568: mov             fp, SP
    // 0x124956c: CheckStackOverflow
    //     0x124956c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1249570: cmp             SP, x16
    //     0x1249574: b.ls            #0x12495b0
    // 0x1249578: LoadField: r0 = r1->field_4b
    //     0x1249578: ldur            w0, [x1, #0x4b]
    // 0x124957c: DecompressPointer r0
    //     0x124957c: add             x0, x0, HEAP, lsl #32
    // 0x1249580: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1249584: cmp             w0, w16
    // 0x1249588: b.ne            #0x1249598
    // 0x124958c: r2 = _colors
    //     0x124958c: add             x2, PP, #0xd2, lsl #12  ; [pp+0xd2848] Field <_LinearProgressIndicatorDefaultsM3Year2023@115243954._colors@115243954>: late final (offset: 0x4c)
    //     0x1249590: ldr             x2, [x2, #0x848]
    // 0x1249594: r0 = InitLateFinalInstanceField()
    //     0x1249594: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1249598: LoadField: r1 = r0->field_b
    //     0x1249598: ldur            w1, [x0, #0xb]
    // 0x124959c: DecompressPointer r1
    //     0x124959c: add             x1, x1, HEAP, lsl #32
    // 0x12495a0: mov             x0, x1
    // 0x12495a4: LeaveFrame
    //     0x12495a4: mov             SP, fp
    //     0x12495a8: ldp             fp, lr, [SP], #0x10
    // 0x12495ac: ret
    //     0x12495ac: ret             
    // 0x12495b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12495b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12495b4: b               #0x1249578
  }
}

// class id: 5126, size: 0x50, field offset: 0x48
class _CircularProgressIndicatorDefaultsM3Year2023 extends ProgressIndicatorThemeData {

  late final ColorScheme _colors; // offset: 0x4c

  get _ constraints(/* No info */) {
    // ** addr: 0x123f96c, size: 0xc
    // 0x123f96c: r0 = Instance_BoxConstraints
    //     0x123f96c: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8fb80] Obj!BoxConstraints@129c261
    //     0x123f970: ldr             x0, [x0, #0xb80]
    // 0x123f974: ret
    //     0x123f974: ret             
  }
  get _ color(/* No info */) {
    // ** addr: 0x1249510, size: 0x54
    // 0x1249510: EnterFrame
    //     0x1249510: stp             fp, lr, [SP, #-0x10]!
    //     0x1249514: mov             fp, SP
    // 0x1249518: CheckStackOverflow
    //     0x1249518: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124951c: cmp             SP, x16
    //     0x1249520: b.ls            #0x124955c
    // 0x1249524: LoadField: r0 = r1->field_4b
    //     0x1249524: ldur            w0, [x1, #0x4b]
    // 0x1249528: DecompressPointer r0
    //     0x1249528: add             x0, x0, HEAP, lsl #32
    // 0x124952c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1249530: cmp             w0, w16
    // 0x1249534: b.ne            #0x1249544
    // 0x1249538: r2 = _colors
    //     0x1249538: add             x2, PP, #0x99, lsl #12  ; [pp+0x99060] Field <_CircularProgressIndicatorDefaultsM3Year2023@115243954._colors@115243954>: late final (offset: 0x4c)
    //     0x124953c: ldr             x2, [x2, #0x60]
    // 0x1249540: r0 = InitLateFinalInstanceField()
    //     0x1249540: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1249544: LoadField: r1 = r0->field_b
    //     0x1249544: ldur            w1, [x0, #0xb]
    // 0x1249548: DecompressPointer r1
    //     0x1249548: add             x1, x1, HEAP, lsl #32
    // 0x124954c: mov             x0, x1
    // 0x1249550: LeaveFrame
    //     0x1249550: mov             SP, fp
    //     0x1249554: ldp             fp, lr, [SP], #0x10
    // 0x1249558: ret
    //     0x1249558: ret             
    // 0x124955c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124955c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1249560: b               #0x1249524
  }
  get _ strokeWidth(/* No info */) {
    // ** addr: 0x12495b8, size: 0xc
    // 0x12495b8: r0 = 4.000000
    //     0x12495b8: add             x0, PP, #0x19, lsl #12  ; [pp+0x19e28] 4
    //     0x12495bc: ldr             x0, [x0, #0xe28]
    // 0x12495c0: ret
    //     0x12495c0: ret             
  }
}

// class id: 5127, size: 0x50, field offset: 0x48
class _LinearProgressIndicatorDefaultsM2 extends ProgressIndicatorThemeData {

  late final ColorScheme _colors; // offset: 0x4c

  get _ linearTrackColor(/* No info */) {
    // ** addr: 0x121b0b8, size: 0x54
    // 0x121b0b8: EnterFrame
    //     0x121b0b8: stp             fp, lr, [SP, #-0x10]!
    //     0x121b0bc: mov             fp, SP
    // 0x121b0c0: CheckStackOverflow
    //     0x121b0c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121b0c4: cmp             SP, x16
    //     0x121b0c8: b.ls            #0x121b104
    // 0x121b0cc: LoadField: r0 = r1->field_4b
    //     0x121b0cc: ldur            w0, [x1, #0x4b]
    // 0x121b0d0: DecompressPointer r0
    //     0x121b0d0: add             x0, x0, HEAP, lsl #32
    // 0x121b0d4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x121b0d8: cmp             w0, w16
    // 0x121b0dc: b.ne            #0x121b0ec
    // 0x121b0e0: r2 = _colors
    //     0x121b0e0: add             x2, PP, #0xd2, lsl #12  ; [pp+0xd2850] Field <_LinearProgressIndicatorDefaultsM2@115243954._colors@115243954>: late final (offset: 0x4c)
    //     0x121b0e4: ldr             x2, [x2, #0x850]
    // 0x121b0e8: r0 = InitLateFinalInstanceField()
    //     0x121b0e8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x121b0ec: LoadField: r1 = r0->field_c7
    //     0x121b0ec: ldur            w1, [x0, #0xc7]
    // 0x121b0f0: DecompressPointer r1
    //     0x121b0f0: add             x1, x1, HEAP, lsl #32
    // 0x121b0f4: mov             x0, x1
    // 0x121b0f8: LeaveFrame
    //     0x121b0f8: mov             SP, fp
    //     0x121b0fc: ldp             fp, lr, [SP], #0x10
    // 0x121b100: ret
    //     0x121b100: ret             
    // 0x121b104: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121b104: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121b108: b               #0x121b0cc
  }
  get _ color(/* No info */) {
    // ** addr: 0x12494bc, size: 0x54
    // 0x12494bc: EnterFrame
    //     0x12494bc: stp             fp, lr, [SP, #-0x10]!
    //     0x12494c0: mov             fp, SP
    // 0x12494c4: CheckStackOverflow
    //     0x12494c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12494c8: cmp             SP, x16
    //     0x12494cc: b.ls            #0x1249508
    // 0x12494d0: LoadField: r0 = r1->field_4b
    //     0x12494d0: ldur            w0, [x1, #0x4b]
    // 0x12494d4: DecompressPointer r0
    //     0x12494d4: add             x0, x0, HEAP, lsl #32
    // 0x12494d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12494dc: cmp             w0, w16
    // 0x12494e0: b.ne            #0x12494f0
    // 0x12494e4: r2 = _colors
    //     0x12494e4: add             x2, PP, #0xd2, lsl #12  ; [pp+0xd2850] Field <_LinearProgressIndicatorDefaultsM2@115243954._colors@115243954>: late final (offset: 0x4c)
    //     0x12494e8: ldr             x2, [x2, #0x850]
    // 0x12494ec: r0 = InitLateFinalInstanceField()
    //     0x12494ec: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12494f0: LoadField: r1 = r0->field_b
    //     0x12494f0: ldur            w1, [x0, #0xb]
    // 0x12494f4: DecompressPointer r1
    //     0x12494f4: add             x1, x1, HEAP, lsl #32
    // 0x12494f8: mov             x0, x1
    // 0x12494fc: LeaveFrame
    //     0x12494fc: mov             SP, fp
    //     0x1249500: ldp             fp, lr, [SP], #0x10
    // 0x1249504: ret
    //     0x1249504: ret             
    // 0x1249508: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1249508: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124950c: b               #0x12494d0
  }
}

// class id: 5128, size: 0x50, field offset: 0x48
class _CircularProgressIndicatorDefaultsM2 extends ProgressIndicatorThemeData {

  late final ColorScheme _colors; // offset: 0x4c

  ColorScheme _colors(_CircularProgressIndicatorDefaultsM2) {
    // ** addr: 0x121b10c, size: 0x44
    // 0x121b10c: EnterFrame
    //     0x121b10c: stp             fp, lr, [SP, #-0x10]!
    //     0x121b110: mov             fp, SP
    // 0x121b114: CheckStackOverflow
    //     0x121b114: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121b118: cmp             SP, x16
    //     0x121b11c: b.ls            #0x121b148
    // 0x121b120: ldr             x0, [fp, #0x10]
    // 0x121b124: LoadField: r1 = r0->field_47
    //     0x121b124: ldur            w1, [x0, #0x47]
    // 0x121b128: DecompressPointer r1
    //     0x121b128: add             x1, x1, HEAP, lsl #32
    // 0x121b12c: r0 = of()
    //     0x121b12c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x121b130: LoadField: r1 = r0->field_3f
    //     0x121b130: ldur            w1, [x0, #0x3f]
    // 0x121b134: DecompressPointer r1
    //     0x121b134: add             x1, x1, HEAP, lsl #32
    // 0x121b138: mov             x0, x1
    // 0x121b13c: LeaveFrame
    //     0x121b13c: mov             SP, fp
    //     0x121b140: ldp             fp, lr, [SP], #0x10
    // 0x121b144: ret
    //     0x121b144: ret             
    // 0x121b148: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121b148: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121b14c: b               #0x121b120
  }
  get _ color(/* No info */) {
    // ** addr: 0x1249468, size: 0x54
    // 0x1249468: EnterFrame
    //     0x1249468: stp             fp, lr, [SP, #-0x10]!
    //     0x124946c: mov             fp, SP
    // 0x1249470: CheckStackOverflow
    //     0x1249470: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1249474: cmp             SP, x16
    //     0x1249478: b.ls            #0x12494b4
    // 0x124947c: LoadField: r0 = r1->field_4b
    //     0x124947c: ldur            w0, [x1, #0x4b]
    // 0x1249480: DecompressPointer r0
    //     0x1249480: add             x0, x0, HEAP, lsl #32
    // 0x1249484: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1249488: cmp             w0, w16
    // 0x124948c: b.ne            #0x124949c
    // 0x1249490: r2 = _colors
    //     0x1249490: add             x2, PP, #0x99, lsl #12  ; [pp+0x99058] Field <_CircularProgressIndicatorDefaultsM2@115243954._colors@115243954>: late final (offset: 0x4c)
    //     0x1249494: ldr             x2, [x2, #0x58]
    // 0x1249498: r0 = InitLateFinalInstanceField()
    //     0x1249498: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x124949c: LoadField: r1 = r0->field_b
    //     0x124949c: ldur            w1, [x0, #0xb]
    // 0x12494a0: DecompressPointer r1
    //     0x12494a0: add             x1, x1, HEAP, lsl #32
    // 0x12494a4: mov             x0, x1
    // 0x12494a8: LeaveFrame
    //     0x12494a8: mov             SP, fp
    //     0x12494ac: ldp             fp, lr, [SP], #0x10
    // 0x12494b0: ret
    //     0x12494b0: ret             
    // 0x12494b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12494b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12494b8: b               #0x124947c
  }
}

// class id: 5720, size: 0x20, field offset: 0x1c
class _CircularProgressIndicatorState extends _MixinApplication92&State&SingleTickerProviderStateMixin {

  static late final Animatable<double> _strokeHeadTween; // offset: 0x768
  static late final Animatable<double> _strokeTailTween; // offset: 0x76c
  static late final Animatable<double> _offsetTween; // offset: 0x770
  static late final Animatable<double> _rotationTween; // offset: 0x774
  late final AnimationController _internalController; // offset: 0x1c

  static Animatable<double> _rotationTween() {
    // ** addr: 0xd31f98, size: 0x28
    // 0xd31f98: EnterFrame
    //     0xd31f98: stp             fp, lr, [SP, #-0x10]!
    //     0xd31f9c: mov             fp, SP
    // 0xd31fa0: r1 = <double>
    //     0xd31fa0: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd31fa4: r0 = CurveTween()
    //     0xd31fa4: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xd31fa8: r1 = Instance_SawTooth
    //     0xd31fa8: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8fb20] Obj!SawTooth@129feb1
    //     0xd31fac: ldr             x1, [x1, #0xb20]
    // 0xd31fb0: StoreField: r0->field_b = r1
    //     0xd31fb0: stur            w1, [x0, #0xb]
    // 0xd31fb4: LeaveFrame
    //     0xd31fb4: mov             SP, fp
    //     0xd31fb8: ldp             fp, lr, [SP], #0x10
    // 0xd31fbc: ret
    //     0xd31fbc: ret             
  }
  static Animatable<double> _offsetTween() {
    // ** addr: 0xd31fc0, size: 0x28
    // 0xd31fc0: EnterFrame
    //     0xd31fc0: stp             fp, lr, [SP, #-0x10]!
    //     0xd31fc4: mov             fp, SP
    // 0xd31fc8: r1 = <double>
    //     0xd31fc8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd31fcc: r0 = CurveTween()
    //     0xd31fcc: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xd31fd0: r1 = Instance_SawTooth
    //     0xd31fd0: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8fb28] Obj!SawTooth@129fed1
    //     0xd31fd4: ldr             x1, [x1, #0xb28]
    // 0xd31fd8: StoreField: r0->field_b = r1
    //     0xd31fd8: stur            w1, [x0, #0xb]
    // 0xd31fdc: LeaveFrame
    //     0xd31fdc: mov             SP, fp
    //     0xd31fe0: ldp             fp, lr, [SP], #0x10
    // 0xd31fe4: ret
    //     0xd31fe4: ret             
  }
  static Animatable<double> _strokeTailTween() {
    // ** addr: 0xd31fe8, size: 0x6c
    // 0xd31fe8: EnterFrame
    //     0xd31fe8: stp             fp, lr, [SP, #-0x10]!
    //     0xd31fec: mov             fp, SP
    // 0xd31ff0: AllocStack(0x8)
    //     0xd31ff0: sub             SP, SP, #8
    // 0xd31ff4: CheckStackOverflow
    //     0xd31ff4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd31ff8: cmp             SP, x16
    //     0xd31ffc: b.ls            #0xd3204c
    // 0xd32000: r1 = <double>
    //     0xd32000: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd32004: r0 = CurveTween()
    //     0xd32004: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xd32008: mov             x2, x0
    // 0xd3200c: r0 = Instance_Interval
    //     0xd3200c: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8fb30] Obj!Interval@129fa31
    //     0xd32010: ldr             x0, [x0, #0xb30]
    // 0xd32014: stur            x2, [fp, #-8]
    // 0xd32018: StoreField: r2->field_b = r0
    //     0xd32018: stur            w0, [x2, #0xb]
    // 0xd3201c: r1 = <double>
    //     0xd3201c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd32020: r0 = CurveTween()
    //     0xd32020: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xd32024: mov             x1, x0
    // 0xd32028: r0 = Instance_SawTooth
    //     0xd32028: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8fb28] Obj!SawTooth@129fed1
    //     0xd3202c: ldr             x0, [x0, #0xb28]
    // 0xd32030: StoreField: r1->field_b = r0
    //     0xd32030: stur            w0, [x1, #0xb]
    // 0xd32034: mov             x2, x1
    // 0xd32038: ldur            x1, [fp, #-8]
    // 0xd3203c: r0 = chain()
    //     0xd3203c: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xd32040: LeaveFrame
    //     0xd32040: mov             SP, fp
    //     0xd32044: ldp             fp, lr, [SP], #0x10
    // 0xd32048: ret
    //     0xd32048: ret             
    // 0xd3204c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd3204c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd32050: b               #0xd32000
  }
  static Animatable<double> _strokeHeadTween() {
    // ** addr: 0xd32054, size: 0x6c
    // 0xd32054: EnterFrame
    //     0xd32054: stp             fp, lr, [SP, #-0x10]!
    //     0xd32058: mov             fp, SP
    // 0xd3205c: AllocStack(0x8)
    //     0xd3205c: sub             SP, SP, #8
    // 0xd32060: CheckStackOverflow
    //     0xd32060: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd32064: cmp             SP, x16
    //     0xd32068: b.ls            #0xd320b8
    // 0xd3206c: r1 = <double>
    //     0xd3206c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd32070: r0 = CurveTween()
    //     0xd32070: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xd32074: mov             x2, x0
    // 0xd32078: r0 = Instance_Interval
    //     0xd32078: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8fb38] Obj!Interval@129fa51
    //     0xd3207c: ldr             x0, [x0, #0xb38]
    // 0xd32080: stur            x2, [fp, #-8]
    // 0xd32084: StoreField: r2->field_b = r0
    //     0xd32084: stur            w0, [x2, #0xb]
    // 0xd32088: r1 = <double>
    //     0xd32088: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd3208c: r0 = CurveTween()
    //     0xd3208c: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xd32090: mov             x1, x0
    // 0xd32094: r0 = Instance_SawTooth
    //     0xd32094: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8fb28] Obj!SawTooth@129fed1
    //     0xd32098: ldr             x0, [x0, #0xb28]
    // 0xd3209c: StoreField: r1->field_b = r0
    //     0xd3209c: stur            w0, [x1, #0xb]
    // 0xd320a0: mov             x2, x1
    // 0xd320a4: ldur            x1, [fp, #-8]
    // 0xd320a8: r0 = chain()
    //     0xd320a8: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xd320ac: LeaveFrame
    //     0xd320ac: mov             SP, fp
    //     0xd320b0: ldp             fp, lr, [SP], #0x10
    // 0xd320b4: ret
    //     0xd320b4: ret             
    // 0xd320b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd320b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd320bc: b               #0xd3206c
  }
  get _ _controller(/* No info */) {
    // ** addr: 0xd320c0, size: 0x124
    // 0xd320c0: EnterFrame
    //     0xd320c0: stp             fp, lr, [SP, #-0x10]!
    //     0xd320c4: mov             fp, SP
    // 0xd320c8: AllocStack(0x18)
    //     0xd320c8: sub             SP, SP, #0x18
    // 0xd320cc: SetupParameters(_CircularProgressIndicatorState this /* r1 => r3, fp-0x8 */)
    //     0xd320cc: mov             x3, x1
    //     0xd320d0: stur            x1, [fp, #-8]
    // 0xd320d4: CheckStackOverflow
    //     0xd320d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd320d8: cmp             SP, x16
    //     0xd320dc: b.ls            #0xd321c0
    // 0xd320e0: r0 = LoadClassIdInstr(r3)
    //     0xd320e0: ldur            x0, [x3, #-1]
    //     0xd320e4: ubfx            x0, x0, #0xc, #0x14
    // 0xd320e8: r17 = 5720
    //     0xd320e8: mov             x17, #0x1658
    // 0xd320ec: cmp             x0, x17
    // 0xd320f0: b.ne            #0xd3210c
    // 0xd320f4: LoadField: r0 = r3->field_b
    //     0xd320f4: ldur            w0, [x3, #0xb]
    // 0xd320f8: DecompressPointer r0
    //     0xd320f8: add             x0, x0, HEAP, lsl #32
    // 0xd320fc: cmp             w0, NULL
    // 0xd32100: b.eq            #0xd321c8
    // 0xd32104: mov             x0, x3
    // 0xd32108: b               #0xd32150
    // 0xd3210c: LoadField: r0 = r3->field_b
    //     0xd3210c: ldur            w0, [x3, #0xb]
    // 0xd32110: DecompressPointer r0
    //     0xd32110: add             x0, x0, HEAP, lsl #32
    // 0xd32114: cmp             w0, NULL
    // 0xd32118: b.eq            #0xd321cc
    // 0xd3211c: r2 = Null
    //     0xd3211c: mov             x2, NULL
    // 0xd32120: r1 = Null
    //     0xd32120: mov             x1, NULL
    // 0xd32124: r4 = LoadClassIdInstr(r0)
    //     0xd32124: ldur            x4, [x0, #-1]
    //     0xd32128: ubfx            x4, x4, #0xc, #0x14
    // 0xd3212c: r17 = 6446
    //     0xd3212c: mov             x17, #0x192e
    // 0xd32130: cmp             x4, x17
    // 0xd32134: b.eq            #0xd3214c
    // 0xd32138: r8 = RefreshProgressIndicator
    //     0xd32138: add             x8, PP, #0x8f, lsl #12  ; [pp+0x8fb40] Type: RefreshProgressIndicator
    //     0xd3213c: ldr             x8, [x8, #0xb40]
    // 0xd32140: r3 = Null
    //     0xd32140: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8fb48] Null
    //     0xd32144: ldr             x3, [x3, #0xb48]
    // 0xd32148: r0 = DefaultTypeTest()
    //     0xd32148: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xd3214c: ldur            x0, [fp, #-8]
    // 0xd32150: LoadField: r1 = r0->field_f
    //     0xd32150: ldur            w1, [x0, #0xf]
    // 0xd32154: DecompressPointer r1
    //     0xd32154: add             x1, x1, HEAP, lsl #32
    // 0xd32158: cmp             w1, NULL
    // 0xd3215c: b.eq            #0xd321d0
    // 0xd32160: r16 = <ProgressIndicatorTheme>
    //     0xd32160: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fb58] TypeArguments: <ProgressIndicatorTheme>
    //     0xd32164: ldr             x16, [x16, #0xb58]
    // 0xd32168: stp             x1, x16, [SP]
    // 0xd3216c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd3216c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd32170: r0 = getInheritedWidgetOfExactType()
    //     0xd32170: bl              #0x843618  ; [package:flutter/src/widgets/framework.dart] Element::getInheritedWidgetOfExactType
    // 0xd32174: ldur            x0, [fp, #-8]
    // 0xd32178: LoadField: r1 = r0->field_f
    //     0xd32178: ldur            w1, [x0, #0xf]
    // 0xd3217c: DecompressPointer r1
    //     0xd3217c: add             x1, x1, HEAP, lsl #32
    // 0xd32180: cmp             w1, NULL
    // 0xd32184: b.eq            #0xd321d4
    // 0xd32188: r16 = <Theme>
    //     0xd32188: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fb60] TypeArguments: <Theme>
    //     0xd3218c: ldr             x16, [x16, #0xb60]
    // 0xd32190: stp             x1, x16, [SP]
    // 0xd32194: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd32194: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd32198: r0 = findAncestorWidgetOfExactType()
    //     0xd32198: bl              #0x86c300  ; [package:flutter/src/widgets/framework.dart] Element::findAncestorWidgetOfExactType
    // 0xd3219c: ldur            x1, [fp, #-8]
    // 0xd321a0: LoadField: r0 = r1->field_1b
    //     0xd321a0: ldur            w0, [x1, #0x1b]
    // 0xd321a4: DecompressPointer r0
    //     0xd321a4: add             x0, x0, HEAP, lsl #32
    // 0xd321a8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd321ac: cmp             w0, w16
    // 0xd321b0: b.eq            #0xd321d8
    // 0xd321b4: LeaveFrame
    //     0xd321b4: mov             SP, fp
    //     0xd321b8: ldp             fp, lr, [SP], #0x10
    // 0xd321bc: ret
    //     0xd321bc: ret             
    // 0xd321c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd321c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd321c4: b               #0xd320e0
    // 0xd321c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd321c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd321cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd321cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd321d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd321d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd321d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd321d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd321d8: r9 = _internalController
    //     0xd321d8: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8fb68] Field <_CircularProgressIndicatorState@115243954._internalController@115243954>: late final (offset: 0x1c)
    //     0xd321dc: ldr             x9, [x9, #0xb68]
    // 0xd321e0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd321e0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0xd3220c, size: 0x50
    // 0xd3220c: EnterFrame
    //     0xd3220c: stp             fp, lr, [SP, #-0x10]!
    //     0xd32210: mov             fp, SP
    // 0xd32214: AllocStack(0x8)
    //     0xd32214: sub             SP, SP, #8
    // 0xd32218: SetupParameters(_CircularProgressIndicatorState this /* r1 => r1, fp-0x8 */)
    //     0xd32218: stur            x1, [fp, #-8]
    // 0xd3221c: r1 = 1
    //     0xd3221c: mov             x1, #1
    // 0xd32220: r0 = AllocateContext()
    //     0xd32220: bl              #0x13de838  ; AllocateContextStub
    // 0xd32224: mov             x1, x0
    // 0xd32228: ldur            x0, [fp, #-8]
    // 0xd3222c: StoreField: r1->field_f = r0
    //     0xd3222c: stur            w0, [x1, #0xf]
    // 0xd32230: mov             x2, x1
    // 0xd32234: r1 = Function '<anonymous closure>':.
    //     0xd32234: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8faf0] AnonymousClosure: (0xd3225c), in [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::build (0xd3220c)
    //     0xd32238: ldr             x1, [x1, #0xaf0]
    // 0xd3223c: r0 = AllocateClosure()
    //     0xd3223c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd32240: stur            x0, [fp, #-8]
    // 0xd32244: r0 = Builder()
    //     0xd32244: bl              #0x858774  ; AllocateBuilderStub -> Builder (size=0x10)
    // 0xd32248: ldur            x1, [fp, #-8]
    // 0xd3224c: StoreField: r0->field_b = r1
    //     0xd3224c: stur            w1, [x0, #0xb]
    // 0xd32250: LeaveFrame
    //     0xd32250: mov             SP, fp
    //     0xd32254: ldp             fp, lr, [SP], #0x10
    // 0xd32258: ret
    //     0xd32258: ret             
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xd3225c, size: 0x198
    // 0xd3225c: EnterFrame
    //     0xd3225c: stp             fp, lr, [SP, #-0x10]!
    //     0xd32260: mov             fp, SP
    // 0xd32264: AllocStack(0x8)
    //     0xd32264: sub             SP, SP, #8
    // 0xd32268: SetupParameters([dynamic _ /* r0 */])
    //     0xd32268: ldr             x0, [fp, #0x18]
    //     0xd3226c: ldur            w2, [x0, #0x17]
    //     0xd32270: add             x2, x2, HEAP, lsl #32
    //     0xd32274: stur            x2, [fp, #-8]
    // 0xd32278: CheckStackOverflow
    //     0xd32278: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3227c: cmp             SP, x16
    //     0xd32280: b.ls            #0xd323e4
    // 0xd32284: LoadField: r0 = r2->field_f
    //     0xd32284: ldur            w0, [x2, #0xf]
    // 0xd32288: DecompressPointer r0
    //     0xd32288: add             x0, x0, HEAP, lsl #32
    // 0xd3228c: LoadField: r1 = r0->field_b
    //     0xd3228c: ldur            w1, [x0, #0xb]
    // 0xd32290: DecompressPointer r1
    //     0xd32290: add             x1, x1, HEAP, lsl #32
    // 0xd32294: cmp             w1, NULL
    // 0xd32298: b.eq            #0xd323ec
    // 0xd3229c: LoadField: r0 = r1->field_23
    //     0xd3229c: ldur            w0, [x1, #0x23]
    // 0xd322a0: DecompressPointer r0
    //     0xd322a0: add             x0, x0, HEAP, lsl #32
    // 0xd322a4: LoadField: r3 = r0->field_7
    //     0xd322a4: ldur            x3, [x0, #7]
    // 0xd322a8: cmp             x3, #0
    // 0xd322ac: b.gt            #0xd32308
    // 0xd322b0: r0 = _effectiveValue()
    //     0xd322b0: bl              #0xd30d4c  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_effectiveValue
    // 0xd322b4: cmp             w0, NULL
    // 0xd322b8: b.eq            #0xd322ec
    // 0xd322bc: ldur            x0, [fp, #-8]
    // 0xd322c0: LoadField: r1 = r0->field_f
    //     0xd322c0: ldur            w1, [x0, #0xf]
    // 0xd322c4: DecompressPointer r1
    //     0xd322c4: add             x1, x1, HEAP, lsl #32
    // 0xd322c8: ldr             x2, [fp, #0x10]
    // 0xd322cc: d0 = 0.000000
    //     0xd322cc: eor             v0.16b, v0.16b, v0.16b
    // 0xd322d0: d1 = 0.000000
    //     0xd322d0: eor             v1.16b, v1.16b, v1.16b
    // 0xd322d4: d2 = 0.000000
    //     0xd322d4: eor             v2.16b, v2.16b, v2.16b
    // 0xd322d8: d3 = 0.000000
    //     0xd322d8: eor             v3.16b, v3.16b, v3.16b
    // 0xd322dc: r0 = _buildMaterialIndicator()
    //     0xd322dc: bl              #0xd3274c  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_buildMaterialIndicator
    // 0xd322e0: LeaveFrame
    //     0xd322e0: mov             SP, fp
    //     0xd322e4: ldp             fp, lr, [SP], #0x10
    // 0xd322e8: ret
    //     0xd322e8: ret             
    // 0xd322ec: ldur            x0, [fp, #-8]
    // 0xd322f0: LoadField: r1 = r0->field_f
    //     0xd322f0: ldur            w1, [x0, #0xf]
    // 0xd322f4: DecompressPointer r1
    //     0xd322f4: add             x1, x1, HEAP, lsl #32
    // 0xd322f8: r0 = _buildAnimation()
    //     0xd322f8: bl              #0xd32548  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_buildAnimation
    // 0xd322fc: LeaveFrame
    //     0xd322fc: mov             SP, fp
    //     0xd32300: ldp             fp, lr, [SP], #0x10
    // 0xd32304: ret
    //     0xd32304: ret             
    // 0xd32308: mov             x0, x2
    // 0xd3230c: ldr             x1, [fp, #0x10]
    // 0xd32310: r0 = of()
    //     0xd32310: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd32314: LoadField: r1 = r0->field_23
    //     0xd32314: ldur            w1, [x0, #0x23]
    // 0xd32318: DecompressPointer r1
    //     0xd32318: add             x1, x1, HEAP, lsl #32
    // 0xd3231c: LoadField: r0 = r1->field_7
    //     0xd3231c: ldur            x0, [x1, #7]
    // 0xd32320: cmp             x0, #2
    // 0xd32324: b.gt            #0xd32338
    // 0xd32328: cmp             x0, #1
    // 0xd3232c: b.gt            #0xd32350
    // 0xd32330: ldur            x0, [fp, #-8]
    // 0xd32334: b               #0xd32370
    // 0xd32338: cmp             x0, #4
    // 0xd3233c: b.gt            #0xd3236c
    // 0xd32340: cmp             x0, #3
    // 0xd32344: b.gt            #0xd32350
    // 0xd32348: ldur            x0, [fp, #-8]
    // 0xd3234c: b               #0xd32370
    // 0xd32350: ldur            x0, [fp, #-8]
    // 0xd32354: LoadField: r1 = r0->field_f
    //     0xd32354: ldur            w1, [x0, #0xf]
    // 0xd32358: DecompressPointer r1
    //     0xd32358: add             x1, x1, HEAP, lsl #32
    // 0xd3235c: r0 = _buildCupertinoIndicator()
    //     0xd3235c: bl              #0xd323f4  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_buildCupertinoIndicator
    // 0xd32360: LeaveFrame
    //     0xd32360: mov             SP, fp
    //     0xd32364: ldp             fp, lr, [SP], #0x10
    // 0xd32368: ret
    //     0xd32368: ret             
    // 0xd3236c: ldur            x0, [fp, #-8]
    // 0xd32370: LoadField: r1 = r0->field_f
    //     0xd32370: ldur            w1, [x0, #0xf]
    // 0xd32374: DecompressPointer r1
    //     0xd32374: add             x1, x1, HEAP, lsl #32
    // 0xd32378: LoadField: r2 = r1->field_b
    //     0xd32378: ldur            w2, [x1, #0xb]
    // 0xd3237c: DecompressPointer r2
    //     0xd3237c: add             x2, x2, HEAP, lsl #32
    // 0xd32380: cmp             w2, NULL
    // 0xd32384: b.eq            #0xd323f0
    // 0xd32388: mov             x1, x2
    // 0xd3238c: r0 = _effectiveValue()
    //     0xd3238c: bl              #0xd30d4c  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_effectiveValue
    // 0xd32390: cmp             w0, NULL
    // 0xd32394: b.eq            #0xd323c8
    // 0xd32398: ldur            x0, [fp, #-8]
    // 0xd3239c: LoadField: r1 = r0->field_f
    //     0xd3239c: ldur            w1, [x0, #0xf]
    // 0xd323a0: DecompressPointer r1
    //     0xd323a0: add             x1, x1, HEAP, lsl #32
    // 0xd323a4: ldr             x2, [fp, #0x10]
    // 0xd323a8: d0 = 0.000000
    //     0xd323a8: eor             v0.16b, v0.16b, v0.16b
    // 0xd323ac: d1 = 0.000000
    //     0xd323ac: eor             v1.16b, v1.16b, v1.16b
    // 0xd323b0: d2 = 0.000000
    //     0xd323b0: eor             v2.16b, v2.16b, v2.16b
    // 0xd323b4: d3 = 0.000000
    //     0xd323b4: eor             v3.16b, v3.16b, v3.16b
    // 0xd323b8: r0 = _buildMaterialIndicator()
    //     0xd323b8: bl              #0xd3274c  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_buildMaterialIndicator
    // 0xd323bc: LeaveFrame
    //     0xd323bc: mov             SP, fp
    //     0xd323c0: ldp             fp, lr, [SP], #0x10
    // 0xd323c4: ret
    //     0xd323c4: ret             
    // 0xd323c8: ldur            x0, [fp, #-8]
    // 0xd323cc: LoadField: r1 = r0->field_f
    //     0xd323cc: ldur            w1, [x0, #0xf]
    // 0xd323d0: DecompressPointer r1
    //     0xd323d0: add             x1, x1, HEAP, lsl #32
    // 0xd323d4: r0 = _buildAnimation()
    //     0xd323d4: bl              #0xd32548  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_buildAnimation
    // 0xd323d8: LeaveFrame
    //     0xd323d8: mov             SP, fp
    //     0xd323dc: ldp             fp, lr, [SP], #0x10
    // 0xd323e0: ret
    //     0xd323e0: ret             
    // 0xd323e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd323e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd323e8: b               #0xd32284
    // 0xd323ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd323ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd323f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd323f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildCupertinoIndicator(/* No info */) {
    // ** addr: 0xd323f4, size: 0x148
    // 0xd323f4: EnterFrame
    //     0xd323f4: stp             fp, lr, [SP, #-0x10]!
    //     0xd323f8: mov             fp, SP
    // 0xd323fc: AllocStack(0x20)
    //     0xd323fc: sub             SP, SP, #0x20
    // 0xd32400: SetupParameters(_CircularProgressIndicatorState this /* r1 => r2, fp-0x8 */)
    //     0xd32400: mov             x2, x1
    //     0xd32404: stur            x1, [fp, #-8]
    // 0xd32408: CheckStackOverflow
    //     0xd32408: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3240c: cmp             SP, x16
    //     0xd32410: b.ls            #0xd32524
    // 0xd32414: LoadField: r1 = r2->field_b
    //     0xd32414: ldur            w1, [x2, #0xb]
    // 0xd32418: DecompressPointer r1
    //     0xd32418: add             x1, x1, HEAP, lsl #32
    // 0xd3241c: cmp             w1, NULL
    // 0xd32420: b.eq            #0xd3252c
    // 0xd32424: r0 = LoadClassIdInstr(r1)
    //     0xd32424: ldur            x0, [x1, #-1]
    //     0xd32428: ubfx            x0, x0, #0xc, #0x14
    // 0xd3242c: r0 = GDT[cid_x0 + 0x989]()
    //     0xd3242c: add             lr, x0, #0x989
    //     0xd32430: ldr             lr, [x21, lr, lsl #3]
    //     0xd32434: blr             lr
    // 0xd32438: mov             x2, x0
    // 0xd3243c: ldur            x0, [fp, #-8]
    // 0xd32440: stur            x2, [fp, #-0x10]
    // 0xd32444: LoadField: r1 = r0->field_b
    //     0xd32444: ldur            w1, [x0, #0xb]
    // 0xd32448: DecompressPointer r1
    //     0xd32448: add             x1, x1, HEAP, lsl #32
    // 0xd3244c: cmp             w1, NULL
    // 0xd32450: b.eq            #0xd32530
    // 0xd32454: r0 = _effectiveValue()
    //     0xd32454: bl              #0xd30d4c  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_effectiveValue
    // 0xd32458: stur            x0, [fp, #-0x20]
    // 0xd3245c: cmp             w0, NULL
    // 0xd32460: b.ne            #0xd324c0
    // 0xd32464: ldur            x1, [fp, #-8]
    // 0xd32468: ldur            x0, [fp, #-0x10]
    // 0xd3246c: LoadField: r2 = r1->field_b
    //     0xd3246c: ldur            w2, [x1, #0xb]
    // 0xd32470: DecompressPointer r2
    //     0xd32470: add             x2, x2, HEAP, lsl #32
    // 0xd32474: cmp             w2, NULL
    // 0xd32478: b.eq            #0xd32534
    // 0xd3247c: LoadField: r1 = r2->field_7
    //     0xd3247c: ldur            w1, [x2, #7]
    // 0xd32480: DecompressPointer r1
    //     0xd32480: add             x1, x1, HEAP, lsl #32
    // 0xd32484: stur            x1, [fp, #-0x18]
    // 0xd32488: r0 = CupertinoActivityIndicator()
    //     0xd32488: bl              #0xd3253c  ; AllocateCupertinoActivityIndicatorStub -> CupertinoActivityIndicator (size=0x24)
    // 0xd3248c: ldur            x2, [fp, #-0x10]
    // 0xd32490: StoreField: r0->field_b = r2
    //     0xd32490: stur            w2, [x0, #0xb]
    // 0xd32494: r1 = true
    //     0xd32494: add             x1, NULL, #0x20  ; true
    // 0xd32498: StoreField: r0->field_f = r1
    //     0xd32498: stur            w1, [x0, #0xf]
    // 0xd3249c: d0 = 10.000000
    //     0xd3249c: fmov            d0, #10.00000000
    // 0xd324a0: StoreField: r0->field_13 = d0
    //     0xd324a0: stur            d0, [x0, #0x13]
    // 0xd324a4: d0 = 1.000000
    //     0xd324a4: fmov            d0, #1.00000000
    // 0xd324a8: StoreField: r0->field_1b = d0
    //     0xd324a8: stur            d0, [x0, #0x1b]
    // 0xd324ac: ldur            x1, [fp, #-0x18]
    // 0xd324b0: StoreField: r0->field_7 = r1
    //     0xd324b0: stur            w1, [x0, #7]
    // 0xd324b4: LeaveFrame
    //     0xd324b4: mov             SP, fp
    //     0xd324b8: ldp             fp, lr, [SP], #0x10
    // 0xd324bc: ret
    //     0xd324bc: ret             
    // 0xd324c0: ldur            x1, [fp, #-8]
    // 0xd324c4: ldur            x2, [fp, #-0x10]
    // 0xd324c8: d0 = 10.000000
    //     0xd324c8: fmov            d0, #10.00000000
    // 0xd324cc: LoadField: r3 = r1->field_b
    //     0xd324cc: ldur            w3, [x1, #0xb]
    // 0xd324d0: DecompressPointer r3
    //     0xd324d0: add             x3, x3, HEAP, lsl #32
    // 0xd324d4: cmp             w3, NULL
    // 0xd324d8: b.eq            #0xd32538
    // 0xd324dc: LoadField: r1 = r3->field_7
    //     0xd324dc: ldur            w1, [x3, #7]
    // 0xd324e0: DecompressPointer r1
    //     0xd324e0: add             x1, x1, HEAP, lsl #32
    // 0xd324e4: stur            x1, [fp, #-8]
    // 0xd324e8: r0 = CupertinoActivityIndicator()
    //     0xd324e8: bl              #0xd3253c  ; AllocateCupertinoActivityIndicatorStub -> CupertinoActivityIndicator (size=0x24)
    // 0xd324ec: ldur            x1, [fp, #-0x10]
    // 0xd324f0: StoreField: r0->field_b = r1
    //     0xd324f0: stur            w1, [x0, #0xb]
    // 0xd324f4: d0 = 10.000000
    //     0xd324f4: fmov            d0, #10.00000000
    // 0xd324f8: StoreField: r0->field_13 = d0
    //     0xd324f8: stur            d0, [x0, #0x13]
    // 0xd324fc: ldur            x1, [fp, #-0x20]
    // 0xd32500: LoadField: d0 = r1->field_7
    //     0xd32500: ldur            d0, [x1, #7]
    // 0xd32504: StoreField: r0->field_1b = d0
    //     0xd32504: stur            d0, [x0, #0x1b]
    // 0xd32508: r1 = false
    //     0xd32508: add             x1, NULL, #0x30  ; false
    // 0xd3250c: StoreField: r0->field_f = r1
    //     0xd3250c: stur            w1, [x0, #0xf]
    // 0xd32510: ldur            x1, [fp, #-8]
    // 0xd32514: StoreField: r0->field_7 = r1
    //     0xd32514: stur            w1, [x0, #7]
    // 0xd32518: LeaveFrame
    //     0xd32518: mov             SP, fp
    //     0xd3251c: ldp             fp, lr, [SP], #0x10
    // 0xd32520: ret
    //     0xd32520: ret             
    // 0xd32524: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd32524: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd32528: b               #0xd32414
    // 0xd3252c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3252c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd32530: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd32530: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd32534: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd32534: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd32538: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd32538: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _buildAnimation(/* No info */) {
    // ** addr: 0xd32548, size: 0x74
    // 0xd32548: EnterFrame
    //     0xd32548: stp             fp, lr, [SP, #-0x10]!
    //     0xd3254c: mov             fp, SP
    // 0xd32550: AllocStack(0x10)
    //     0xd32550: sub             SP, SP, #0x10
    // 0xd32554: SetupParameters(_CircularProgressIndicatorState this /* r1 => r1, fp-0x8 */)
    //     0xd32554: stur            x1, [fp, #-8]
    // 0xd32558: CheckStackOverflow
    //     0xd32558: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3255c: cmp             SP, x16
    //     0xd32560: b.ls            #0xd325b4
    // 0xd32564: r1 = 1
    //     0xd32564: mov             x1, #1
    // 0xd32568: r0 = AllocateContext()
    //     0xd32568: bl              #0x13de838  ; AllocateContextStub
    // 0xd3256c: ldur            x1, [fp, #-8]
    // 0xd32570: stur            x0, [fp, #-0x10]
    // 0xd32574: StoreField: r0->field_f = r1
    //     0xd32574: stur            w1, [x0, #0xf]
    // 0xd32578: r0 = _controller()
    //     0xd32578: bl              #0xd320c0  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_controller
    // 0xd3257c: ldur            x2, [fp, #-0x10]
    // 0xd32580: r1 = Function '<anonymous closure>':.
    //     0xd32580: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8faf8] AnonymousClosure: (0xd325bc), in [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_buildAnimation (0xd32548)
    //     0xd32584: ldr             x1, [x1, #0xaf8]
    // 0xd32588: stur            x0, [fp, #-8]
    // 0xd3258c: r0 = AllocateClosure()
    //     0xd3258c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd32590: stur            x0, [fp, #-0x10]
    // 0xd32594: r0 = AnimatedBuilder()
    //     0xd32594: bl              #0x918e2c  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0xd32598: ldur            x1, [fp, #-0x10]
    // 0xd3259c: StoreField: r0->field_f = r1
    //     0xd3259c: stur            w1, [x0, #0xf]
    // 0xd325a0: ldur            x1, [fp, #-8]
    // 0xd325a4: StoreField: r0->field_b = r1
    //     0xd325a4: stur            w1, [x0, #0xb]
    // 0xd325a8: LeaveFrame
    //     0xd325a8: mov             SP, fp
    //     0xd325ac: ldp             fp, lr, [SP], #0x10
    // 0xd325b0: ret
    //     0xd325b0: ret             
    // 0xd325b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd325b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd325b8: b               #0xd32564
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0xd325bc, size: 0x190
    // 0xd325bc: EnterFrame
    //     0xd325bc: stp             fp, lr, [SP, #-0x10]!
    //     0xd325c0: mov             fp, SP
    // 0xd325c4: AllocStack(0x30)
    //     0xd325c4: sub             SP, SP, #0x30
    // 0xd325c8: SetupParameters([dynamic _ /* r0 */])
    //     0xd325c8: ldr             x0, [fp, #0x20]
    //     0xd325cc: ldur            w1, [x0, #0x17]
    //     0xd325d0: add             x1, x1, HEAP, lsl #32
    //     0xd325d4: stur            x1, [fp, #-0x10]
    // 0xd325d8: CheckStackOverflow
    //     0xd325d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd325dc: cmp             SP, x16
    //     0xd325e0: b.ls            #0xd32744
    // 0xd325e4: LoadField: r0 = r1->field_f
    //     0xd325e4: ldur            w0, [x1, #0xf]
    // 0xd325e8: DecompressPointer r0
    //     0xd325e8: add             x0, x0, HEAP, lsl #32
    // 0xd325ec: stur            x0, [fp, #-8]
    // 0xd325f0: r0 = LoadStaticField(0x768)
    //     0xd325f0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd325f4: ldr             x0, [x0, #0xed0]
    // 0xd325f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd325fc: cmp             w0, w16
    // 0xd32600: b.ne            #0xd32610
    // 0xd32604: r2 = _strokeHeadTween
    //     0xd32604: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fb00] Field <_CircularProgressIndicatorState@115243954._strokeHeadTween@115243954>: static late final (offset: 0x768)
    //     0xd32608: ldr             x2, [x2, #0xb00]
    // 0xd3260c: r0 = InitLateFinalStaticField()
    //     0xd3260c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd32610: mov             x2, x0
    // 0xd32614: ldur            x0, [fp, #-0x10]
    // 0xd32618: stur            x2, [fp, #-0x18]
    // 0xd3261c: LoadField: r1 = r0->field_f
    //     0xd3261c: ldur            w1, [x0, #0xf]
    // 0xd32620: DecompressPointer r1
    //     0xd32620: add             x1, x1, HEAP, lsl #32
    // 0xd32624: r0 = _controller()
    //     0xd32624: bl              #0xd320c0  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_controller
    // 0xd32628: ldur            x1, [fp, #-0x18]
    // 0xd3262c: mov             x2, x0
    // 0xd32630: r0 = evaluate()
    //     0xd32630: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xd32634: stur            x0, [fp, #-0x18]
    // 0xd32638: r0 = LoadStaticField(0x76c)
    //     0xd32638: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd3263c: ldr             x0, [x0, #0xed8]
    // 0xd32640: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd32644: cmp             w0, w16
    // 0xd32648: b.ne            #0xd32658
    // 0xd3264c: r2 = _strokeTailTween
    //     0xd3264c: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fb08] Field <_CircularProgressIndicatorState@115243954._strokeTailTween@115243954>: static late final (offset: 0x76c)
    //     0xd32650: ldr             x2, [x2, #0xb08]
    // 0xd32654: r0 = InitLateFinalStaticField()
    //     0xd32654: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd32658: mov             x2, x0
    // 0xd3265c: ldur            x0, [fp, #-0x10]
    // 0xd32660: stur            x2, [fp, #-0x20]
    // 0xd32664: LoadField: r1 = r0->field_f
    //     0xd32664: ldur            w1, [x0, #0xf]
    // 0xd32668: DecompressPointer r1
    //     0xd32668: add             x1, x1, HEAP, lsl #32
    // 0xd3266c: r0 = _controller()
    //     0xd3266c: bl              #0xd320c0  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_controller
    // 0xd32670: ldur            x1, [fp, #-0x20]
    // 0xd32674: mov             x2, x0
    // 0xd32678: r0 = evaluate()
    //     0xd32678: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xd3267c: stur            x0, [fp, #-0x20]
    // 0xd32680: r0 = LoadStaticField(0x770)
    //     0xd32680: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd32684: ldr             x0, [x0, #0xee0]
    // 0xd32688: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3268c: cmp             w0, w16
    // 0xd32690: b.ne            #0xd326a0
    // 0xd32694: r2 = _offsetTween
    //     0xd32694: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fb10] Field <_CircularProgressIndicatorState@115243954._offsetTween@115243954>: static late final (offset: 0x770)
    //     0xd32698: ldr             x2, [x2, #0xb10]
    // 0xd3269c: r0 = InitLateFinalStaticField()
    //     0xd3269c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd326a0: mov             x2, x0
    // 0xd326a4: ldur            x0, [fp, #-0x10]
    // 0xd326a8: stur            x2, [fp, #-0x28]
    // 0xd326ac: LoadField: r1 = r0->field_f
    //     0xd326ac: ldur            w1, [x0, #0xf]
    // 0xd326b0: DecompressPointer r1
    //     0xd326b0: add             x1, x1, HEAP, lsl #32
    // 0xd326b4: r0 = _controller()
    //     0xd326b4: bl              #0xd320c0  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_controller
    // 0xd326b8: ldur            x1, [fp, #-0x28]
    // 0xd326bc: mov             x2, x0
    // 0xd326c0: r0 = evaluate()
    //     0xd326c0: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xd326c4: stur            x0, [fp, #-0x28]
    // 0xd326c8: r0 = LoadStaticField(0x774)
    //     0xd326c8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd326cc: ldr             x0, [x0, #0xee8]
    // 0xd326d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd326d4: cmp             w0, w16
    // 0xd326d8: b.ne            #0xd326e8
    // 0xd326dc: r2 = _rotationTween
    //     0xd326dc: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fb18] Field <_CircularProgressIndicatorState@115243954._rotationTween@115243954>: static late final (offset: 0x774)
    //     0xd326e0: ldr             x2, [x2, #0xb18]
    // 0xd326e4: r0 = InitLateFinalStaticField()
    //     0xd326e4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd326e8: mov             x2, x0
    // 0xd326ec: ldur            x0, [fp, #-0x10]
    // 0xd326f0: stur            x2, [fp, #-0x30]
    // 0xd326f4: LoadField: r1 = r0->field_f
    //     0xd326f4: ldur            w1, [x0, #0xf]
    // 0xd326f8: DecompressPointer r1
    //     0xd326f8: add             x1, x1, HEAP, lsl #32
    // 0xd326fc: r0 = _controller()
    //     0xd326fc: bl              #0xd320c0  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_controller
    // 0xd32700: ldur            x1, [fp, #-0x30]
    // 0xd32704: mov             x2, x0
    // 0xd32708: r0 = evaluate()
    //     0xd32708: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xd3270c: mov             x1, x0
    // 0xd32710: ldur            x0, [fp, #-0x18]
    // 0xd32714: LoadField: d0 = r0->field_7
    //     0xd32714: ldur            d0, [x0, #7]
    // 0xd32718: ldur            x0, [fp, #-0x20]
    // 0xd3271c: LoadField: d1 = r0->field_7
    //     0xd3271c: ldur            d1, [x0, #7]
    // 0xd32720: ldur            x0, [fp, #-0x28]
    // 0xd32724: LoadField: d2 = r0->field_7
    //     0xd32724: ldur            d2, [x0, #7]
    // 0xd32728: LoadField: d3 = r1->field_7
    //     0xd32728: ldur            d3, [x1, #7]
    // 0xd3272c: ldur            x1, [fp, #-8]
    // 0xd32730: ldr             x2, [fp, #0x18]
    // 0xd32734: r0 = _buildMaterialIndicator()
    //     0xd32734: bl              #0xd3274c  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_buildMaterialIndicator
    // 0xd32738: LeaveFrame
    //     0xd32738: mov             SP, fp
    //     0xd3273c: ldp             fp, lr, [SP], #0x10
    // 0xd32740: ret
    //     0xd32740: ret             
    // 0xd32744: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd32744: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd32748: b               #0xd325e4
  }
  _ _buildMaterialIndicator(/* No info */) {
    // ** addr: 0xd3274c, size: 0x398
    // 0xd3274c: EnterFrame
    //     0xd3274c: stp             fp, lr, [SP, #-0x10]!
    //     0xd32750: mov             fp, SP
    // 0xd32754: AllocStack(0x70)
    //     0xd32754: sub             SP, SP, #0x70
    // 0xd32758: SetupParameters(_CircularProgressIndicatorState this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x30 */, dynamic _ /* d1 => d5, fp-0x38 */, dynamic _ /* d2 => d1, fp-0x40 */, dynamic _ /* d3 => d2, fp-0x48 */)
    //     0xd32758: mov             x0, x2
    //     0xd3275c: stur            x2, [fp, #-0x10]
    //     0xd32760: mov             x2, x1
    //     0xd32764: mov             v5.16b, v1.16b
    //     0xd32768: stur            d1, [fp, #-0x38]
    //     0xd3276c: mov             v1.16b, v2.16b
    //     0xd32770: stur            d2, [fp, #-0x40]
    //     0xd32774: mov             v2.16b, v3.16b
    //     0xd32778: stur            x1, [fp, #-8]
    //     0xd3277c: stur            d0, [fp, #-0x30]
    //     0xd32780: stur            d3, [fp, #-0x48]
    // 0xd32784: CheckStackOverflow
    //     0xd32784: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd32788: cmp             SP, x16
    //     0xd3278c: b.ls            #0xd32ab4
    // 0xd32790: mov             x1, x0
    // 0xd32794: r0 = of()
    //     0xd32794: bl              #0xd30c34  ; [package:flutter/src/material/progress_indicator_theme.dart] ProgressIndicatorTheme::of
    // 0xd32798: mov             x2, x0
    // 0xd3279c: ldur            x0, [fp, #-8]
    // 0xd327a0: stur            x2, [fp, #-0x18]
    // 0xd327a4: LoadField: r1 = r0->field_b
    //     0xd327a4: ldur            w1, [x0, #0xb]
    // 0xd327a8: DecompressPointer r1
    //     0xd327a8: add             x1, x1, HEAP, lsl #32
    // 0xd327ac: cmp             w1, NULL
    // 0xd327b0: b.eq            #0xd32abc
    // 0xd327b4: ldur            x1, [fp, #-0x10]
    // 0xd327b8: r0 = of()
    //     0xd327b8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd327bc: LoadField: r1 = r0->field_2f
    //     0xd327bc: ldur            w1, [x0, #0x2f]
    // 0xd327c0: DecompressPointer r1
    //     0xd327c0: add             x1, x1, HEAP, lsl #32
    // 0xd327c4: tbnz            w1, #4, #0xd32804
    // 0xd327c8: ldur            x0, [fp, #-8]
    // 0xd327cc: ldur            x2, [fp, #-0x10]
    // 0xd327d0: LoadField: r1 = r0->field_b
    //     0xd327d0: ldur            w1, [x0, #0xb]
    // 0xd327d4: DecompressPointer r1
    //     0xd327d4: add             x1, x1, HEAP, lsl #32
    // 0xd327d8: cmp             w1, NULL
    // 0xd327dc: b.eq            #0xd32ac0
    // 0xd327e0: r0 = _effectiveValue()
    //     0xd327e0: bl              #0xd30d4c  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_effectiveValue
    // 0xd327e4: r0 = _CircularProgressIndicatorDefaultsM3Year2023()
    //     0xd327e4: bl              #0xd31e64  ; Allocate_CircularProgressIndicatorDefaultsM3Year2023Stub -> _CircularProgressIndicatorDefaultsM3Year2023 (size=0x50)
    // 0xd327e8: mov             x1, x0
    // 0xd327ec: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd327f0: StoreField: r1->field_4b = r0
    //     0xd327f0: stur            w0, [x1, #0x4b]
    // 0xd327f4: ldur            x2, [fp, #-0x10]
    // 0xd327f8: StoreField: r1->field_47 = r2
    //     0xd327f8: stur            w2, [x1, #0x47]
    // 0xd327fc: mov             x4, x1
    // 0xd32800: b               #0xd32840
    // 0xd32804: ldur            x3, [fp, #-8]
    // 0xd32808: ldur            x2, [fp, #-0x10]
    // 0xd3280c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd32810: LoadField: r1 = r3->field_b
    //     0xd32810: ldur            w1, [x3, #0xb]
    // 0xd32814: DecompressPointer r1
    //     0xd32814: add             x1, x1, HEAP, lsl #32
    // 0xd32818: cmp             w1, NULL
    // 0xd3281c: b.eq            #0xd32ac4
    // 0xd32820: r0 = _effectiveValue()
    //     0xd32820: bl              #0xd30d4c  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_effectiveValue
    // 0xd32824: r0 = _CircularProgressIndicatorDefaultsM2()
    //     0xd32824: bl              #0xd31e58  ; Allocate_CircularProgressIndicatorDefaultsM2Stub -> _CircularProgressIndicatorDefaultsM2 (size=0x50)
    // 0xd32828: mov             x1, x0
    // 0xd3282c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd32830: StoreField: r1->field_4b = r0
    //     0xd32830: stur            w0, [x1, #0x4b]
    // 0xd32834: ldur            x2, [fp, #-0x10]
    // 0xd32838: StoreField: r1->field_47 = r2
    //     0xd32838: stur            w2, [x1, #0x47]
    // 0xd3283c: mov             x4, x1
    // 0xd32840: ldur            x3, [fp, #-8]
    // 0xd32844: stur            x4, [fp, #-0x20]
    // 0xd32848: LoadField: r1 = r3->field_b
    //     0xd32848: ldur            w1, [x3, #0xb]
    // 0xd3284c: DecompressPointer r1
    //     0xd3284c: add             x1, x1, HEAP, lsl #32
    // 0xd32850: cmp             w1, NULL
    // 0xd32854: b.eq            #0xd32ac8
    // 0xd32858: r0 = LoadClassIdInstr(r1)
    //     0xd32858: ldur            x0, [x1, #-1]
    //     0xd3285c: ubfx            x0, x0, #0xc, #0x14
    // 0xd32860: r0 = GDT[cid_x0 + 0x989]()
    //     0xd32860: add             lr, x0, #0x989
    //     0xd32864: ldr             lr, [x21, lr, lsl #3]
    //     0xd32868: blr             lr
    // 0xd3286c: cmp             w0, NULL
    // 0xd32870: b.ne            #0xd32878
    // 0xd32874: r0 = Null
    //     0xd32874: mov             x0, NULL
    // 0xd32878: cmp             w0, NULL
    // 0xd3287c: b.ne            #0xd32888
    // 0xd32880: r3 = Null
    //     0xd32880: mov             x3, NULL
    // 0xd32884: b               #0xd3288c
    // 0xd32888: mov             x3, x0
    // 0xd3288c: ldur            x2, [fp, #-8]
    // 0xd32890: stur            x3, [fp, #-0x28]
    // 0xd32894: LoadField: r0 = r2->field_b
    //     0xd32894: ldur            w0, [x2, #0xb]
    // 0xd32898: DecompressPointer r0
    //     0xd32898: add             x0, x0, HEAP, lsl #32
    // 0xd3289c: cmp             w0, NULL
    // 0xd328a0: b.eq            #0xd32acc
    // 0xd328a4: LoadField: r1 = r0->field_27
    //     0xd328a4: ldur            w1, [x0, #0x27]
    // 0xd328a8: DecompressPointer r1
    //     0xd328a8: add             x1, x1, HEAP, lsl #32
    // 0xd328ac: cmp             w1, NULL
    // 0xd328b0: b.ne            #0xd328c4
    // 0xd328b4: ldur            x4, [fp, #-0x18]
    // 0xd328b8: LoadField: r0 = r4->field_27
    //     0xd328b8: ldur            w0, [x4, #0x27]
    // 0xd328bc: DecompressPointer r0
    //     0xd328bc: add             x0, x0, HEAP, lsl #32
    // 0xd328c0: b               #0xd328cc
    // 0xd328c4: ldur            x4, [fp, #-0x18]
    // 0xd328c8: mov             x0, x1
    // 0xd328cc: cmp             w0, NULL
    // 0xd328d0: b.ne            #0xd328f8
    // 0xd328d4: ldur            x5, [fp, #-0x20]
    // 0xd328d8: r0 = LoadClassIdInstr(r5)
    //     0xd328d8: ldur            x0, [x5, #-1]
    //     0xd328dc: ubfx            x0, x0, #0xc, #0x14
    // 0xd328e0: mov             x1, x5
    // 0xd328e4: r0 = GDT[cid_x0 + 0xebf]()
    //     0xd328e4: add             lr, x0, #0xebf
    //     0xd328e8: ldr             lr, [x21, lr, lsl #3]
    //     0xd328ec: blr             lr
    // 0xd328f0: d4 = 4.000000
    //     0xd328f0: fmov            d4, #4.00000000
    // 0xd328f4: b               #0xd32900
    // 0xd328f8: LoadField: d0 = r0->field_7
    //     0xd328f8: ldur            d0, [x0, #7]
    // 0xd328fc: mov             v4.16b, v0.16b
    // 0xd32900: ldur            x2, [fp, #-8]
    // 0xd32904: ldur            x0, [fp, #-0x18]
    // 0xd32908: stur            d4, [fp, #-0x50]
    // 0xd3290c: LoadField: r1 = r2->field_b
    //     0xd3290c: ldur            w1, [x2, #0xb]
    // 0xd32910: DecompressPointer r1
    //     0xd32910: add             x1, x1, HEAP, lsl #32
    // 0xd32914: cmp             w1, NULL
    // 0xd32918: b.eq            #0xd32ad0
    // 0xd3291c: LoadField: r1 = r0->field_2b
    //     0xd3291c: ldur            w1, [x0, #0x2b]
    // 0xd32920: DecompressPointer r1
    //     0xd32920: add             x1, x1, HEAP, lsl #32
    // 0xd32924: cmp             w1, NULL
    // 0xd32928: b.ne            #0xd32950
    // 0xd3292c: ldur            x3, [fp, #-0x20]
    // 0xd32930: r0 = LoadClassIdInstr(r3)
    //     0xd32930: ldur            x0, [x3, #-1]
    //     0xd32934: ubfx            x0, x0, #0xc, #0x14
    // 0xd32938: mov             x1, x3
    // 0xd3293c: r0 = GDT[cid_x0 + 0xeb8]()
    //     0xd3293c: add             lr, x0, #0xeb8
    //     0xd32940: ldr             lr, [x21, lr, lsl #3]
    //     0xd32944: blr             lr
    // 0xd32948: d3 = 0.000000
    //     0xd32948: eor             v3.16b, v3.16b, v3.16b
    // 0xd3294c: b               #0xd32958
    // 0xd32950: LoadField: d0 = r1->field_7
    //     0xd32950: ldur            d0, [x1, #7]
    // 0xd32954: mov             v3.16b, v0.16b
    // 0xd32958: ldur            x2, [fp, #-8]
    // 0xd3295c: ldur            x3, [fp, #-0x20]
    // 0xd32960: stur            d3, [fp, #-0x58]
    // 0xd32964: LoadField: r0 = r2->field_b
    //     0xd32964: ldur            w0, [x2, #0xb]
    // 0xd32968: DecompressPointer r0
    //     0xd32968: add             x0, x0, HEAP, lsl #32
    // 0xd3296c: cmp             w0, NULL
    // 0xd32970: b.eq            #0xd32ad4
    // 0xd32974: r0 = LoadClassIdInstr(r3)
    //     0xd32974: ldur            x0, [x3, #-1]
    //     0xd32978: ubfx            x0, x0, #0xc, #0x14
    // 0xd3297c: mov             x1, x3
    // 0xd32980: r0 = GDT[cid_x0 + 0xfed]()
    //     0xd32980: add             lr, x0, #0xfed
    //     0xd32984: ldr             lr, [x21, lr, lsl #3]
    //     0xd32988: blr             lr
    // 0xd3298c: ldur            x2, [fp, #-8]
    // 0xd32990: LoadField: r3 = r2->field_b
    //     0xd32990: ldur            w3, [x2, #0xb]
    // 0xd32994: DecompressPointer r3
    //     0xd32994: add             x3, x3, HEAP, lsl #32
    // 0xd32998: stur            x3, [fp, #-0x18]
    // 0xd3299c: cmp             w3, NULL
    // 0xd329a0: b.eq            #0xd32ad8
    // 0xd329a4: ldur            x1, [fp, #-0x20]
    // 0xd329a8: r0 = LoadClassIdInstr(r1)
    //     0xd329a8: ldur            x0, [x1, #-1]
    //     0xd329ac: ubfx            x0, x0, #0xc, #0x14
    // 0xd329b0: r0 = GDT[cid_x0 + 0xec6]()
    //     0xd329b0: add             lr, x0, #0xec6
    //     0xd329b4: ldr             lr, [x21, lr, lsl #3]
    //     0xd329b8: blr             lr
    // 0xd329bc: str             x0, [SP]
    // 0xd329c0: ldur            x1, [fp, #-0x18]
    // 0xd329c4: ldur            x2, [fp, #-0x10]
    // 0xd329c8: r4 = const [0, 0x3, 0x1, 0x2, defaultColor, 0x2, null]
    //     0xd329c8: add             x4, PP, #0x8f, lsl #12  ; [pp+0x8fb70] List(7) [0, 0x3, 0x1, 0x2, "defaultColor", 0x2, Null]
    //     0xd329cc: ldr             x4, [x4, #0xb70]
    // 0xd329d0: r0 = _getValueColor()
    //     0xd329d0: bl              #0xd30b14  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_getValueColor
    // 0xd329d4: mov             x2, x0
    // 0xd329d8: ldur            x0, [fp, #-8]
    // 0xd329dc: stur            x2, [fp, #-0x10]
    // 0xd329e0: LoadField: r1 = r0->field_b
    //     0xd329e0: ldur            w1, [x0, #0xb]
    // 0xd329e4: DecompressPointer r1
    //     0xd329e4: add             x1, x1, HEAP, lsl #32
    // 0xd329e8: cmp             w1, NULL
    // 0xd329ec: b.eq            #0xd32adc
    // 0xd329f0: r0 = _effectiveValue()
    //     0xd329f0: bl              #0xd30d4c  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_effectiveValue
    // 0xd329f4: stur            x0, [fp, #-0x18]
    // 0xd329f8: r0 = _CircularProgressIndicatorPainter()
    //     0xd329f8: bl              #0xd32ae4  ; Allocate_CircularProgressIndicatorPainterStub -> _CircularProgressIndicatorPainter (size=0x64)
    // 0xd329fc: stur            x0, [fp, #-0x20]
    // 0xd32a00: ldur            x16, [fp, #-0x28]
    // 0xd32a04: stp             NULL, x16, [SP, #8]
    // 0xd32a08: r16 = true
    //     0xd32a08: add             x16, NULL, #0x20  ; true
    // 0xd32a0c: str             x16, [SP]
    // 0xd32a10: mov             x1, x0
    // 0xd32a14: ldur            d0, [fp, #-0x30]
    // 0xd32a18: ldur            d1, [fp, #-0x40]
    // 0xd32a1c: ldur            d2, [fp, #-0x48]
    // 0xd32a20: ldur            d3, [fp, #-0x58]
    // 0xd32a24: ldur            d4, [fp, #-0x50]
    // 0xd32a28: ldur            d5, [fp, #-0x38]
    // 0xd32a2c: ldur            x2, [fp, #-0x18]
    // 0xd32a30: ldur            x3, [fp, #-0x10]
    // 0xd32a34: r4 = const [0, 0xc, 0x3, 0x9, trackColor, 0x9, trackGap, 0xa, year2023, 0xb, null]
    //     0xd32a34: add             x4, PP, #0x8f, lsl #12  ; [pp+0x8fb78] List(11) [0, 0xc, 0x3, 0x9, "trackColor", 0x9, "trackGap", 0xa, "year2023", 0xb, Null]
    //     0xd32a38: ldr             x4, [x4, #0xb78]
    // 0xd32a3c: r0 = _CircularProgressIndicatorPainter()
    //     0xd32a3c: bl              #0xd31bb4  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorPainter::_CircularProgressIndicatorPainter
    // 0xd32a40: r0 = CustomPaint()
    //     0xd32a40: bl              #0xd0a594  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0xd32a44: mov             x1, x0
    // 0xd32a48: ldur            x0, [fp, #-0x20]
    // 0xd32a4c: stur            x1, [fp, #-0x10]
    // 0xd32a50: StoreField: r1->field_f = r0
    //     0xd32a50: stur            w0, [x1, #0xf]
    // 0xd32a54: r0 = Instance_Size
    //     0xd32a54: ldr             x0, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xd32a58: ArrayStore: r1[0] = r0  ; List_4
    //     0xd32a58: stur            w0, [x1, #0x17]
    // 0xd32a5c: r0 = false
    //     0xd32a5c: add             x0, NULL, #0x30  ; false
    // 0xd32a60: StoreField: r1->field_1b = r0
    //     0xd32a60: stur            w0, [x1, #0x1b]
    // 0xd32a64: StoreField: r1->field_1f = r0
    //     0xd32a64: stur            w0, [x1, #0x1f]
    // 0xd32a68: r0 = ConstrainedBox()
    //     0xd32a68: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xd32a6c: mov             x1, x0
    // 0xd32a70: r0 = Instance_BoxConstraints
    //     0xd32a70: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8fb80] Obj!BoxConstraints@129c261
    //     0xd32a74: ldr             x0, [x0, #0xb80]
    // 0xd32a78: StoreField: r1->field_f = r0
    //     0xd32a78: stur            w0, [x1, #0xf]
    // 0xd32a7c: ldur            x0, [fp, #-0x10]
    // 0xd32a80: StoreField: r1->field_b = r0
    //     0xd32a80: stur            w0, [x1, #0xb]
    // 0xd32a84: ldur            x0, [fp, #-8]
    // 0xd32a88: LoadField: r2 = r0->field_b
    //     0xd32a88: ldur            w2, [x0, #0xb]
    // 0xd32a8c: DecompressPointer r2
    //     0xd32a8c: add             x2, x2, HEAP, lsl #32
    // 0xd32a90: cmp             w2, NULL
    // 0xd32a94: b.eq            #0xd32ae0
    // 0xd32a98: mov             x16, x1
    // 0xd32a9c: mov             x1, x2
    // 0xd32aa0: mov             x2, x16
    // 0xd32aa4: r0 = _buildSemanticsWrapper()
    //     0xd32aa4: bl              #0xd30974  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_buildSemanticsWrapper
    // 0xd32aa8: LeaveFrame
    //     0xd32aa8: mov             SP, fp
    //     0xd32aac: ldp             fp, lr, [SP], #0x10
    // 0xd32ab0: ret
    //     0xd32ab0: ret             
    // 0xd32ab4: r0 = StackOverflowSharedWithFPURegs()
    //     0xd32ab4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd32ab8: b               #0xd32790
    // 0xd32abc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd32abc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd32ac0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd32ac0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd32ac4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd32ac4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd32ac8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd32ac8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd32acc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd32acc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd32ad0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd32ad0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd32ad4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd32ad4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd32ad8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd32ad8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd32adc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd32adc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd32ae0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd32ae0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf3c138, size: 0xc4
    // 0xf3c138: EnterFrame
    //     0xf3c138: stp             fp, lr, [SP, #-0x10]!
    //     0xf3c13c: mov             fp, SP
    // 0xf3c140: AllocStack(0x10)
    //     0xf3c140: sub             SP, SP, #0x10
    // 0xf3c144: SetupParameters(_CircularProgressIndicatorState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf3c144: mov             x4, x1
    //     0xf3c148: mov             x3, x2
    //     0xf3c14c: stur            x1, [fp, #-8]
    //     0xf3c150: stur            x2, [fp, #-0x10]
    // 0xf3c154: CheckStackOverflow
    //     0xf3c154: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3c158: cmp             SP, x16
    //     0xf3c15c: b.ls            #0xf3c1f4
    // 0xf3c160: mov             x0, x3
    // 0xf3c164: r2 = Null
    //     0xf3c164: mov             x2, NULL
    // 0xf3c168: r1 = Null
    //     0xf3c168: mov             x1, NULL
    // 0xf3c16c: r4 = 60
    //     0xf3c16c: mov             x4, #0x3c
    // 0xf3c170: branchIfSmi(r0, 0xf3c17c)
    //     0xf3c170: tbz             w0, #0, #0xf3c17c
    // 0xf3c174: r4 = LoadClassIdInstr(r0)
    //     0xf3c174: ldur            x4, [x0, #-1]
    //     0xf3c178: ubfx            x4, x4, #0xc, #0x14
    // 0xf3c17c: r17 = -6445
    //     0xf3c17c: mov             x17, #-0x192d
    // 0xf3c180: add             x4, x4, x17
    // 0xf3c184: cmp             x4, #1
    // 0xf3c188: b.ls            #0xf3c1a0
    // 0xf3c18c: r8 = CircularProgressIndicator
    //     0xf3c18c: add             x8, PP, #0x8f, lsl #12  ; [pp+0x8fbd0] Type: CircularProgressIndicator
    //     0xf3c190: ldr             x8, [x8, #0xbd0]
    // 0xf3c194: r3 = Null
    //     0xf3c194: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8fbd8] Null
    //     0xf3c198: ldr             x3, [x3, #0xbd8]
    // 0xf3c19c: r0 = CircularProgressIndicator()
    //     0xf3c19c: bl              #0xacf9fc  ; IsType_CircularProgressIndicator_Stub
    // 0xf3c1a0: ldur            x3, [fp, #-8]
    // 0xf3c1a4: LoadField: r2 = r3->field_7
    //     0xf3c1a4: ldur            w2, [x3, #7]
    // 0xf3c1a8: DecompressPointer r2
    //     0xf3c1a8: add             x2, x2, HEAP, lsl #32
    // 0xf3c1ac: ldur            x0, [fp, #-0x10]
    // 0xf3c1b0: r1 = Null
    //     0xf3c1b0: mov             x1, NULL
    // 0xf3c1b4: cmp             w2, NULL
    // 0xf3c1b8: b.eq            #0xf3c1dc
    // 0xf3c1bc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf3c1bc: ldur            w4, [x2, #0x17]
    // 0xf3c1c0: DecompressPointer r4
    //     0xf3c1c0: add             x4, x4, HEAP, lsl #32
    // 0xf3c1c4: r8 = X0 bound StatefulWidget
    //     0xf3c1c4: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf3c1c8: ldr             x8, [x8, #0x498]
    // 0xf3c1cc: LoadField: r9 = r4->field_7
    //     0xf3c1cc: ldur            x9, [x4, #7]
    // 0xf3c1d0: r3 = Null
    //     0xf3c1d0: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8fbe8] Null
    //     0xf3c1d4: ldr             x3, [x3, #0xbe8]
    // 0xf3c1d8: blr             x9
    // 0xf3c1dc: ldur            x1, [fp, #-8]
    // 0xf3c1e0: r0 = _updateControllerAnimatingStatus()
    //     0xf3c1e0: bl              #0xf3c1fc  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_updateControllerAnimatingStatus
    // 0xf3c1e4: r0 = Null
    //     0xf3c1e4: mov             x0, NULL
    // 0xf3c1e8: LeaveFrame
    //     0xf3c1e8: mov             SP, fp
    //     0xf3c1ec: ldp             fp, lr, [SP], #0x10
    // 0xf3c1f0: ret
    //     0xf3c1f0: ret             
    // 0xf3c1f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3c1f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3c1f8: b               #0xf3c160
  }
  _ _updateControllerAnimatingStatus(/* No info */) {
    // ** addr: 0xf3c1fc, size: 0x1f0
    // 0xf3c1fc: EnterFrame
    //     0xf3c1fc: stp             fp, lr, [SP, #-0x10]!
    //     0xf3c200: mov             fp, SP
    // 0xf3c204: AllocStack(0x18)
    //     0xf3c204: sub             SP, SP, #0x18
    // 0xf3c208: SetupParameters(_CircularProgressIndicatorState this /* r1 => r3, fp-0x18 */)
    //     0xf3c208: mov             x3, x1
    //     0xf3c20c: stur            x1, [fp, #-0x18]
    // 0xf3c210: CheckStackOverflow
    //     0xf3c210: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3c214: cmp             SP, x16
    //     0xf3c218: b.ls            #0xf3c3bc
    // 0xf3c21c: r4 = LoadClassIdInstr(r3)
    //     0xf3c21c: ldur            x4, [x3, #-1]
    //     0xf3c220: ubfx            x4, x4, #0xc, #0x14
    // 0xf3c224: stur            x4, [fp, #-0x10]
    // 0xf3c228: r17 = 5720
    //     0xf3c228: mov             x17, #0x1658
    // 0xf3c22c: cmp             x4, x17
    // 0xf3c230: b.ne            #0xf3c24c
    // 0xf3c234: LoadField: r0 = r3->field_b
    //     0xf3c234: ldur            w0, [x3, #0xb]
    // 0xf3c238: DecompressPointer r0
    //     0xf3c238: add             x0, x0, HEAP, lsl #32
    // 0xf3c23c: cmp             w0, NULL
    // 0xf3c240: b.eq            #0xf3c3c4
    // 0xf3c244: mov             x1, x0
    // 0xf3c248: b               #0xf3c298
    // 0xf3c24c: LoadField: r5 = r3->field_b
    //     0xf3c24c: ldur            w5, [x3, #0xb]
    // 0xf3c250: DecompressPointer r5
    //     0xf3c250: add             x5, x5, HEAP, lsl #32
    // 0xf3c254: stur            x5, [fp, #-8]
    // 0xf3c258: cmp             w5, NULL
    // 0xf3c25c: b.eq            #0xf3c3c8
    // 0xf3c260: mov             x0, x5
    // 0xf3c264: r2 = Null
    //     0xf3c264: mov             x2, NULL
    // 0xf3c268: r1 = Null
    //     0xf3c268: mov             x1, NULL
    // 0xf3c26c: r4 = LoadClassIdInstr(r0)
    //     0xf3c26c: ldur            x4, [x0, #-1]
    //     0xf3c270: ubfx            x4, x4, #0xc, #0x14
    // 0xf3c274: r17 = 6446
    //     0xf3c274: mov             x17, #0x192e
    // 0xf3c278: cmp             x4, x17
    // 0xf3c27c: b.eq            #0xf3c294
    // 0xf3c280: r8 = RefreshProgressIndicator
    //     0xf3c280: add             x8, PP, #0x8f, lsl #12  ; [pp+0x8fb40] Type: RefreshProgressIndicator
    //     0xf3c284: ldr             x8, [x8, #0xb40]
    // 0xf3c288: r3 = Null
    //     0xf3c288: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8fbf8] Null
    //     0xf3c28c: ldr             x3, [x3, #0xbf8]
    // 0xf3c290: r0 = DefaultTypeTest()
    //     0xf3c290: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xf3c294: ldur            x1, [fp, #-8]
    // 0xf3c298: r0 = _effectiveValue()
    //     0xf3c298: bl              #0xd30d4c  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_effectiveValue
    // 0xf3c29c: cmp             w0, NULL
    // 0xf3c2a0: b.ne            #0xf3c2e8
    // 0xf3c2a4: ldur            x3, [fp, #-0x18]
    // 0xf3c2a8: LoadField: r1 = r3->field_1b
    //     0xf3c2a8: ldur            w1, [x3, #0x1b]
    // 0xf3c2ac: DecompressPointer r1
    //     0xf3c2ac: add             x1, x1, HEAP, lsl #32
    // 0xf3c2b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3c2b4: cmp             w1, w16
    // 0xf3c2b8: b.eq            #0xf3c3cc
    // 0xf3c2bc: LoadField: r0 = r1->field_2f
    //     0xf3c2bc: ldur            w0, [x1, #0x2f]
    // 0xf3c2c0: DecompressPointer r0
    //     0xf3c2c0: add             x0, x0, HEAP, lsl #32
    // 0xf3c2c4: cmp             w0, NULL
    // 0xf3c2c8: b.eq            #0xf3c2dc
    // 0xf3c2cc: LoadField: r2 = r0->field_7
    //     0xf3c2cc: ldur            w2, [x0, #7]
    // 0xf3c2d0: DecompressPointer r2
    //     0xf3c2d0: add             x2, x2, HEAP, lsl #32
    // 0xf3c2d4: cmp             w2, NULL
    // 0xf3c2d8: b.ne            #0xf3c2ec
    // 0xf3c2dc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf3c2dc: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf3c2e0: r0 = repeat()
    //     0xf3c2e0: bl              #0xf3bd88  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0xf3c2e4: b               #0xf3c3ac
    // 0xf3c2e8: ldur            x3, [fp, #-0x18]
    // 0xf3c2ec: ldur            x0, [fp, #-0x10]
    // 0xf3c2f0: r17 = 5720
    //     0xf3c2f0: mov             x17, #0x1658
    // 0xf3c2f4: cmp             x0, x17
    // 0xf3c2f8: b.ne            #0xf3c314
    // 0xf3c2fc: LoadField: r0 = r3->field_b
    //     0xf3c2fc: ldur            w0, [x3, #0xb]
    // 0xf3c300: DecompressPointer r0
    //     0xf3c300: add             x0, x0, HEAP, lsl #32
    // 0xf3c304: cmp             w0, NULL
    // 0xf3c308: b.eq            #0xf3c3d8
    // 0xf3c30c: mov             x1, x0
    // 0xf3c310: b               #0xf3c360
    // 0xf3c314: LoadField: r4 = r3->field_b
    //     0xf3c314: ldur            w4, [x3, #0xb]
    // 0xf3c318: DecompressPointer r4
    //     0xf3c318: add             x4, x4, HEAP, lsl #32
    // 0xf3c31c: stur            x4, [fp, #-8]
    // 0xf3c320: cmp             w4, NULL
    // 0xf3c324: b.eq            #0xf3c3dc
    // 0xf3c328: mov             x0, x4
    // 0xf3c32c: r2 = Null
    //     0xf3c32c: mov             x2, NULL
    // 0xf3c330: r1 = Null
    //     0xf3c330: mov             x1, NULL
    // 0xf3c334: r4 = LoadClassIdInstr(r0)
    //     0xf3c334: ldur            x4, [x0, #-1]
    //     0xf3c338: ubfx            x4, x4, #0xc, #0x14
    // 0xf3c33c: r17 = 6446
    //     0xf3c33c: mov             x17, #0x192e
    // 0xf3c340: cmp             x4, x17
    // 0xf3c344: b.eq            #0xf3c35c
    // 0xf3c348: r8 = RefreshProgressIndicator
    //     0xf3c348: add             x8, PP, #0x8f, lsl #12  ; [pp+0x8fb40] Type: RefreshProgressIndicator
    //     0xf3c34c: ldr             x8, [x8, #0xb40]
    // 0xf3c350: r3 = Null
    //     0xf3c350: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8fc08] Null
    //     0xf3c354: ldr             x3, [x3, #0xc08]
    // 0xf3c358: r0 = DefaultTypeTest()
    //     0xf3c358: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xf3c35c: ldur            x1, [fp, #-8]
    // 0xf3c360: r0 = _effectiveValue()
    //     0xf3c360: bl              #0xd30d4c  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_effectiveValue
    // 0xf3c364: cmp             w0, NULL
    // 0xf3c368: b.eq            #0xf3c3ac
    // 0xf3c36c: ldur            x0, [fp, #-0x18]
    // 0xf3c370: LoadField: r1 = r0->field_1b
    //     0xf3c370: ldur            w1, [x0, #0x1b]
    // 0xf3c374: DecompressPointer r1
    //     0xf3c374: add             x1, x1, HEAP, lsl #32
    // 0xf3c378: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3c37c: cmp             w1, w16
    // 0xf3c380: b.eq            #0xf3c3e0
    // 0xf3c384: LoadField: r0 = r1->field_2f
    //     0xf3c384: ldur            w0, [x1, #0x2f]
    // 0xf3c388: DecompressPointer r0
    //     0xf3c388: add             x0, x0, HEAP, lsl #32
    // 0xf3c38c: cmp             w0, NULL
    // 0xf3c390: b.eq            #0xf3c3ac
    // 0xf3c394: LoadField: r2 = r0->field_7
    //     0xf3c394: ldur            w2, [x0, #7]
    // 0xf3c398: DecompressPointer r2
    //     0xf3c398: add             x2, x2, HEAP, lsl #32
    // 0xf3c39c: cmp             w2, NULL
    // 0xf3c3a0: b.eq            #0xf3c3ac
    // 0xf3c3a4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf3c3a4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf3c3a8: r0 = stop()
    //     0xf3c3a8: bl              #0x82eb24  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0xf3c3ac: r0 = Null
    //     0xf3c3ac: mov             x0, NULL
    // 0xf3c3b0: LeaveFrame
    //     0xf3c3b0: mov             SP, fp
    //     0xf3c3b4: ldp             fp, lr, [SP], #0x10
    // 0xf3c3b8: ret
    //     0xf3c3b8: ret             
    // 0xf3c3bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3c3bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3c3c0: b               #0xf3c21c
    // 0xf3c3c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3c3c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3c3c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3c3c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3c3cc: r9 = _internalController
    //     0xf3c3cc: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8fb68] Field <_CircularProgressIndicatorState@115243954._internalController@115243954>: late final (offset: 0x1c)
    //     0xf3c3d0: ldr             x9, [x9, #0xb68]
    // 0xf3c3d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3c3d4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf3c3d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3c3d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3c3dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3c3dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3c3e0: r9 = _internalController
    //     0xf3c3e0: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8fb68] Field <_CircularProgressIndicatorState@115243954._internalController@115243954>: late final (offset: 0x1c)
    //     0xf3c3e4: ldr             x9, [x9, #0xb68]
    // 0xf3c3e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3c3e8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf7b030, size: 0xb4
    // 0xf7b030: EnterFrame
    //     0xf7b030: stp             fp, lr, [SP, #-0x10]!
    //     0xf7b034: mov             fp, SP
    // 0xf7b038: AllocStack(0x18)
    //     0xf7b038: sub             SP, SP, #0x18
    // 0xf7b03c: SetupParameters(_CircularProgressIndicatorState this /* r1 => r2, fp-0x8 */)
    //     0xf7b03c: mov             x2, x1
    //     0xf7b040: stur            x1, [fp, #-8]
    // 0xf7b044: CheckStackOverflow
    //     0xf7b044: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7b048: cmp             SP, x16
    //     0xf7b04c: b.ls            #0xf7b0dc
    // 0xf7b050: r1 = <double>
    //     0xf7b050: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf7b054: r0 = AnimationController()
    //     0xf7b054: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf7b058: stur            x0, [fp, #-0x10]
    // 0xf7b05c: r16 = Instance_Duration
    //     0xf7b05c: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fc18] Obj!Duration@12c8c11
    //     0xf7b060: ldr             x16, [x16, #0xc18]
    // 0xf7b064: str             x16, [SP]
    // 0xf7b068: mov             x1, x0
    // 0xf7b06c: ldur            x2, [fp, #-8]
    // 0xf7b070: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xf7b070: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xf7b074: ldr             x4, [x4, #0x5a0]
    // 0xf7b078: r0 = AnimationController()
    //     0xf7b078: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf7b07c: ldur            x1, [fp, #-8]
    // 0xf7b080: LoadField: r0 = r1->field_1b
    //     0xf7b080: ldur            w0, [x1, #0x1b]
    // 0xf7b084: DecompressPointer r0
    //     0xf7b084: add             x0, x0, HEAP, lsl #32
    // 0xf7b088: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7b08c: cmp             w0, w16
    // 0xf7b090: b.ne            #0xf7b0c8
    // 0xf7b094: ldur            x0, [fp, #-0x10]
    // 0xf7b098: StoreField: r1->field_1b = r0
    //     0xf7b098: stur            w0, [x1, #0x1b]
    //     0xf7b09c: ldurb           w16, [x1, #-1]
    //     0xf7b0a0: ldurb           w17, [x0, #-1]
    //     0xf7b0a4: and             x16, x17, x16, lsr #2
    //     0xf7b0a8: tst             x16, HEAP, lsr #32
    //     0xf7b0ac: b.eq            #0xf7b0b4
    //     0xf7b0b0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf7b0b4: r0 = _updateControllerAnimatingStatus()
    //     0xf7b0b4: bl              #0xf3c1fc  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_updateControllerAnimatingStatus
    // 0xf7b0b8: r0 = Null
    //     0xf7b0b8: mov             x0, NULL
    // 0xf7b0bc: LeaveFrame
    //     0xf7b0bc: mov             SP, fp
    //     0xf7b0c0: ldp             fp, lr, [SP], #0x10
    // 0xf7b0c4: ret
    //     0xf7b0c4: ret             
    // 0xf7b0c8: r16 = "_internalController@115243954"
    //     0xf7b0c8: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fc20] "_internalController@115243954"
    //     0xf7b0cc: ldr             x16, [x16, #0xc20]
    // 0xf7b0d0: str             x16, [SP]
    // 0xf7b0d4: r0 = _throwFieldAlreadyInitialized()
    //     0xf7b0d4: bl              #0x82b720  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0xf7b0d8: brk             #0
    // 0xf7b0dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7b0dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7b0e0: b               #0xf7b050
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10dd798, size: 0x64
    // 0x10dd798: EnterFrame
    //     0x10dd798: stp             fp, lr, [SP, #-0x10]!
    //     0x10dd79c: mov             fp, SP
    // 0x10dd7a0: AllocStack(0x8)
    //     0x10dd7a0: sub             SP, SP, #8
    // 0x10dd7a4: SetupParameters(_CircularProgressIndicatorState this /* r1 => r0, fp-0x8 */)
    //     0x10dd7a4: mov             x0, x1
    //     0x10dd7a8: stur            x1, [fp, #-8]
    // 0x10dd7ac: CheckStackOverflow
    //     0x10dd7ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10dd7b0: cmp             SP, x16
    //     0x10dd7b4: b.ls            #0x10dd7e8
    // 0x10dd7b8: LoadField: r1 = r0->field_1b
    //     0x10dd7b8: ldur            w1, [x0, #0x1b]
    // 0x10dd7bc: DecompressPointer r1
    //     0x10dd7bc: add             x1, x1, HEAP, lsl #32
    // 0x10dd7c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10dd7c4: cmp             w1, w16
    // 0x10dd7c8: b.eq            #0x10dd7f0
    // 0x10dd7cc: r0 = dispose()
    //     0x10dd7cc: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10dd7d0: ldur            x1, [fp, #-8]
    // 0x10dd7d4: r0 = dispose()
    //     0x10dd7d4: bl              #0x10dd7fc  ; [dart:mixin_deduplication] _MixinApplication92&State&SingleTickerProviderStateMixin::dispose
    // 0x10dd7d8: r0 = Null
    //     0x10dd7d8: mov             x0, NULL
    // 0x10dd7dc: LeaveFrame
    //     0x10dd7dc: mov             SP, fp
    //     0x10dd7e0: ldp             fp, lr, [SP], #0x10
    // 0x10dd7e4: ret
    //     0x10dd7e4: ret             
    // 0x10dd7e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dd7e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dd7ec: b               #0x10dd7b8
    // 0x10dd7f0: r9 = _internalController
    //     0x10dd7f0: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8fb68] Field <_CircularProgressIndicatorState@115243954._internalController@115243954>: late final (offset: 0x1c)
    //     0x10dd7f4: ldr             x9, [x9, #0xb68]
    // 0x10dd7f8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10dd7f8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 5721, size: 0x2c, field offset: 0x20
class _RefreshProgressIndicatorState extends _CircularProgressIndicatorState {

  late final Animatable<double> _convertTween; // offset: 0x20
  late final Animatable<double> _additionalRotationTween; // offset: 0x24

  _ build(/* No info */) {
    // ** addr: 0xd30e84, size: 0x15c
    // 0xd30e84: EnterFrame
    //     0xd30e84: stp             fp, lr, [SP, #-0x10]!
    //     0xd30e88: mov             fp, SP
    // 0xd30e8c: AllocStack(0x18)
    //     0xd30e8c: sub             SP, SP, #0x18
    // 0xd30e90: SetupParameters(_RefreshProgressIndicatorState this /* r1 => r3, fp-0x10 */)
    //     0xd30e90: mov             x3, x1
    //     0xd30e94: stur            x1, [fp, #-0x10]
    // 0xd30e98: CheckStackOverflow
    //     0xd30e98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd30e9c: cmp             SP, x16
    //     0xd30ea0: b.ls            #0xd30fc0
    // 0xd30ea4: LoadField: r4 = r3->field_b
    //     0xd30ea4: ldur            w4, [x3, #0xb]
    // 0xd30ea8: DecompressPointer r4
    //     0xd30ea8: add             x4, x4, HEAP, lsl #32
    // 0xd30eac: stur            x4, [fp, #-8]
    // 0xd30eb0: cmp             w4, NULL
    // 0xd30eb4: b.eq            #0xd30fc8
    // 0xd30eb8: mov             x0, x4
    // 0xd30ebc: r2 = Null
    //     0xd30ebc: mov             x2, NULL
    // 0xd30ec0: r1 = Null
    //     0xd30ec0: mov             x1, NULL
    // 0xd30ec4: r4 = LoadClassIdInstr(r0)
    //     0xd30ec4: ldur            x4, [x0, #-1]
    //     0xd30ec8: ubfx            x4, x4, #0xc, #0x14
    // 0xd30ecc: r17 = 6446
    //     0xd30ecc: mov             x17, #0x192e
    // 0xd30ed0: cmp             x4, x17
    // 0xd30ed4: b.eq            #0xd30eec
    // 0xd30ed8: r8 = RefreshProgressIndicator
    //     0xd30ed8: add             x8, PP, #0x8f, lsl #12  ; [pp+0x8fb40] Type: RefreshProgressIndicator
    //     0xd30edc: ldr             x8, [x8, #0xb40]
    // 0xd30ee0: r3 = Null
    //     0xd30ee0: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa37c0] Null
    //     0xd30ee4: ldr             x3, [x3, #0x7c0]
    // 0xd30ee8: r0 = DefaultTypeTest()
    //     0xd30ee8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xd30eec: ldur            x1, [fp, #-8]
    // 0xd30ef0: r0 = _effectiveValue()
    //     0xd30ef0: bl              #0xd30d4c  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_effectiveValue
    // 0xd30ef4: mov             x2, x0
    // 0xd30ef8: stur            x2, [fp, #-8]
    // 0xd30efc: cmp             w2, NULL
    // 0xd30f00: b.eq            #0xd30fac
    // 0xd30f04: ldur            x3, [fp, #-0x10]
    // 0xd30f08: mov             x0, x2
    // 0xd30f0c: StoreField: r3->field_27 = r0
    //     0xd30f0c: stur            w0, [x3, #0x27]
    //     0xd30f10: ldurb           w16, [x3, #-1]
    //     0xd30f14: ldurb           w17, [x0, #-1]
    //     0xd30f18: and             x16, x17, x16, lsr #2
    //     0xd30f1c: tst             x16, HEAP, lsr #32
    //     0xd30f20: b.eq            #0xd30f28
    //     0xd30f24: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd30f28: mov             x1, x3
    // 0xd30f2c: r0 = _controller()
    //     0xd30f2c: bl              #0xd320c0  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_controller
    // 0xd30f30: ldur            x1, [fp, #-0x10]
    // 0xd30f34: stur            x0, [fp, #-0x18]
    // 0xd30f38: LoadField: r0 = r1->field_1f
    //     0xd30f38: ldur            w0, [x1, #0x1f]
    // 0xd30f3c: DecompressPointer r0
    //     0xd30f3c: add             x0, x0, HEAP, lsl #32
    // 0xd30f40: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd30f44: cmp             w0, w16
    // 0xd30f48: b.ne            #0xd30f58
    // 0xd30f4c: r2 = _convertTween
    //     0xd30f4c: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa37d0] Field <_RefreshProgressIndicatorState@115243954._convertTween@115243954>: late final (offset: 0x20)
    //     0xd30f50: ldr             x2, [x2, #0x7d0]
    // 0xd30f54: r0 = InitLateFinalInstanceField()
    //     0xd30f54: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd30f58: mov             x1, x0
    // 0xd30f5c: ldur            x0, [fp, #-8]
    // 0xd30f60: LoadField: d0 = r0->field_7
    //     0xd30f60: ldur            d0, [x0, #7]
    // 0xd30f64: r0 = transform()
    //     0xd30f64: bl              #0x1103c04  ; [package:flutter/src/animation/tween.dart] CurveTween::transform
    // 0xd30f68: LoadField: d0 = r0->field_7
    //     0xd30f68: ldur            d0, [x0, #7]
    // 0xd30f6c: d1 = 0.000225
    //     0xd30f6c: add             x17, PP, #0xa3, lsl #12  ; [pp+0xa37d8] IMM: double(0.000225022502250225) from 0x3f2d7e80937882e1
    //     0xd30f70: ldr             d1, [x17, #0x7d8]
    // 0xd30f74: fmul            d2, d0, d1
    // 0xd30f78: r2 = inline_Allocate_Double()
    //     0xd30f78: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xd30f7c: add             x2, x2, #0x10
    //     0xd30f80: cmp             x0, x2
    //     0xd30f84: b.ls            #0xd30fcc
    //     0xd30f88: str             x2, [THR, #0x60]  ; THR::top
    //     0xd30f8c: sub             x2, x2, #0xf
    //     0xd30f90: mov             x0, #0xe19c
    //     0xd30f94: movk            x0, #3, lsl #16
    //     0xd30f98: stur            x0, [x2, #-1]
    // 0xd30f9c: dmb             ishst
    // 0xd30fa0: StoreField: r2->field_7 = d2
    //     0xd30fa0: stur            d2, [x2, #7]
    // 0xd30fa4: ldur            x1, [fp, #-0x18]
    // 0xd30fa8: r0 = value=()
    //     0xd30fa8: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xd30fac: ldur            x1, [fp, #-0x10]
    // 0xd30fb0: r0 = _buildAnimation()
    //     0xd30fb0: bl              #0xd30fe0  ; [package:flutter/src/material/progress_indicator.dart] _RefreshProgressIndicatorState::_buildAnimation
    // 0xd30fb4: LeaveFrame
    //     0xd30fb4: mov             SP, fp
    //     0xd30fb8: ldp             fp, lr, [SP], #0x10
    // 0xd30fbc: ret
    //     0xd30fbc: ret             
    // 0xd30fc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd30fc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd30fc4: b               #0xd30ea4
    // 0xd30fc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd30fc8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd30fcc: SaveReg d2
    //     0xd30fcc: str             q2, [SP, #-0x10]!
    // 0xd30fd0: r0 = AllocateDouble()
    //     0xd30fd0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd30fd4: mov             x2, x0
    // 0xd30fd8: RestoreReg d2
    //     0xd30fd8: ldr             q2, [SP], #0x10
    // 0xd30fdc: b               #0xd30fa0
  }
  _ _buildAnimation(/* No info */) {
    // ** addr: 0xd30fe0, size: 0x74
    // 0xd30fe0: EnterFrame
    //     0xd30fe0: stp             fp, lr, [SP, #-0x10]!
    //     0xd30fe4: mov             fp, SP
    // 0xd30fe8: AllocStack(0x10)
    //     0xd30fe8: sub             SP, SP, #0x10
    // 0xd30fec: SetupParameters(_RefreshProgressIndicatorState this /* r1 => r1, fp-0x8 */)
    //     0xd30fec: stur            x1, [fp, #-8]
    // 0xd30ff0: CheckStackOverflow
    //     0xd30ff0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd30ff4: cmp             SP, x16
    //     0xd30ff8: b.ls            #0xd3104c
    // 0xd30ffc: r1 = 1
    //     0xd30ffc: mov             x1, #1
    // 0xd31000: r0 = AllocateContext()
    //     0xd31000: bl              #0x13de838  ; AllocateContextStub
    // 0xd31004: ldur            x1, [fp, #-8]
    // 0xd31008: stur            x0, [fp, #-0x10]
    // 0xd3100c: StoreField: r0->field_f = r1
    //     0xd3100c: stur            w1, [x0, #0xf]
    // 0xd31010: r0 = _controller()
    //     0xd31010: bl              #0xd320c0  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_controller
    // 0xd31014: ldur            x2, [fp, #-0x10]
    // 0xd31018: r1 = Function '<anonymous closure>':.
    //     0xd31018: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa37e8] AnonymousClosure: (0xd31054), in [package:flutter/src/material/progress_indicator.dart] _RefreshProgressIndicatorState::_buildAnimation (0xd30fe0)
    //     0xd3101c: ldr             x1, [x1, #0x7e8]
    // 0xd31020: stur            x0, [fp, #-8]
    // 0xd31024: r0 = AllocateClosure()
    //     0xd31024: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd31028: stur            x0, [fp, #-0x10]
    // 0xd3102c: r0 = AnimatedBuilder()
    //     0xd3102c: bl              #0x918e2c  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0xd31030: ldur            x1, [fp, #-0x10]
    // 0xd31034: StoreField: r0->field_f = r1
    //     0xd31034: stur            w1, [x0, #0xf]
    // 0xd31038: ldur            x1, [fp, #-8]
    // 0xd3103c: StoreField: r0->field_b = r1
    //     0xd3103c: stur            w1, [x0, #0xb]
    // 0xd31040: LeaveFrame
    //     0xd31040: mov             SP, fp
    //     0xd31044: ldp             fp, lr, [SP], #0x10
    // 0xd31048: ret
    //     0xd31048: ret             
    // 0xd3104c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd3104c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd31050: b               #0xd30ffc
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0xd31054, size: 0x20c
    // 0xd31054: EnterFrame
    //     0xd31054: stp             fp, lr, [SP, #-0x10]!
    //     0xd31058: mov             fp, SP
    // 0xd3105c: AllocStack(0x30)
    //     0xd3105c: sub             SP, SP, #0x30
    // 0xd31060: SetupParameters([dynamic _ /* r0 */])
    //     0xd31060: ldr             x0, [fp, #0x20]
    //     0xd31064: ldur            w1, [x0, #0x17]
    //     0xd31068: add             x1, x1, HEAP, lsl #32
    //     0xd3106c: stur            x1, [fp, #-0x10]
    // 0xd31070: CheckStackOverflow
    //     0xd31070: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd31074: cmp             SP, x16
    //     0xd31078: b.ls            #0xd31238
    // 0xd3107c: LoadField: r0 = r1->field_f
    //     0xd3107c: ldur            w0, [x1, #0xf]
    // 0xd31080: DecompressPointer r0
    //     0xd31080: add             x0, x0, HEAP, lsl #32
    // 0xd31084: stur            x0, [fp, #-8]
    // 0xd31088: r0 = LoadStaticField(0x768)
    //     0xd31088: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd3108c: ldr             x0, [x0, #0xed0]
    // 0xd31090: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd31094: cmp             w0, w16
    // 0xd31098: b.ne            #0xd310a8
    // 0xd3109c: r2 = _strokeHeadTween
    //     0xd3109c: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fb00] Field <_CircularProgressIndicatorState@115243954._strokeHeadTween@115243954>: static late final (offset: 0x768)
    //     0xd310a0: ldr             x2, [x2, #0xb00]
    // 0xd310a4: r0 = InitLateFinalStaticField()
    //     0xd310a4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd310a8: mov             x2, x0
    // 0xd310ac: ldur            x0, [fp, #-0x10]
    // 0xd310b0: stur            x2, [fp, #-0x18]
    // 0xd310b4: LoadField: r1 = r0->field_f
    //     0xd310b4: ldur            w1, [x0, #0xf]
    // 0xd310b8: DecompressPointer r1
    //     0xd310b8: add             x1, x1, HEAP, lsl #32
    // 0xd310bc: r0 = _controller()
    //     0xd310bc: bl              #0xd320c0  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_controller
    // 0xd310c0: LoadField: r1 = r0->field_37
    //     0xd310c0: ldur            w1, [x0, #0x37]
    // 0xd310c4: DecompressPointer r1
    //     0xd310c4: add             x1, x1, HEAP, lsl #32
    // 0xd310c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd310cc: cmp             w1, w16
    // 0xd310d0: b.eq            #0xd31240
    // 0xd310d4: LoadField: d0 = r1->field_7
    //     0xd310d4: ldur            d0, [x1, #7]
    // 0xd310d8: ldur            x1, [fp, #-0x18]
    // 0xd310dc: r0 = transform()
    //     0xd310dc: bl              #0x1103a74  ; [package:flutter/src/animation/tween.dart] _ChainedEvaluation::transform
    // 0xd310e0: LoadField: d0 = r0->field_7
    //     0xd310e0: ldur            d0, [x0, #7]
    // 0xd310e4: d1 = 1.050000
    //     0xd310e4: add             x17, PP, #0x8c, lsl #12  ; [pp+0x8cc58] IMM: double(1.05) from 0x3ff0cccccccccccd
    //     0xd310e8: ldr             d1, [x17, #0xc58]
    // 0xd310ec: fmul            d2, d0, d1
    // 0xd310f0: stur            d2, [fp, #-0x30]
    // 0xd310f4: r0 = LoadStaticField(0x76c)
    //     0xd310f4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd310f8: ldr             x0, [x0, #0xed8]
    // 0xd310fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd31100: cmp             w0, w16
    // 0xd31104: b.ne            #0xd31114
    // 0xd31108: r2 = _strokeTailTween
    //     0xd31108: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fb08] Field <_CircularProgressIndicatorState@115243954._strokeTailTween@115243954>: static late final (offset: 0x76c)
    //     0xd3110c: ldr             x2, [x2, #0xb08]
    // 0xd31110: r0 = InitLateFinalStaticField()
    //     0xd31110: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd31114: mov             x2, x0
    // 0xd31118: ldur            x0, [fp, #-0x10]
    // 0xd3111c: stur            x2, [fp, #-0x18]
    // 0xd31120: LoadField: r1 = r0->field_f
    //     0xd31120: ldur            w1, [x0, #0xf]
    // 0xd31124: DecompressPointer r1
    //     0xd31124: add             x1, x1, HEAP, lsl #32
    // 0xd31128: r0 = _controller()
    //     0xd31128: bl              #0xd320c0  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_controller
    // 0xd3112c: LoadField: r1 = r0->field_37
    //     0xd3112c: ldur            w1, [x0, #0x37]
    // 0xd31130: DecompressPointer r1
    //     0xd31130: add             x1, x1, HEAP, lsl #32
    // 0xd31134: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd31138: cmp             w1, w16
    // 0xd3113c: b.eq            #0xd31248
    // 0xd31140: LoadField: d0 = r1->field_7
    //     0xd31140: ldur            d0, [x1, #7]
    // 0xd31144: ldur            x1, [fp, #-0x18]
    // 0xd31148: r0 = transform()
    //     0xd31148: bl              #0x1103a74  ; [package:flutter/src/animation/tween.dart] _ChainedEvaluation::transform
    // 0xd3114c: stur            x0, [fp, #-0x18]
    // 0xd31150: r0 = LoadStaticField(0x770)
    //     0xd31150: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd31154: ldr             x0, [x0, #0xee0]
    // 0xd31158: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3115c: cmp             w0, w16
    // 0xd31160: b.ne            #0xd31170
    // 0xd31164: r2 = _offsetTween
    //     0xd31164: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fb10] Field <_CircularProgressIndicatorState@115243954._offsetTween@115243954>: static late final (offset: 0x770)
    //     0xd31168: ldr             x2, [x2, #0xb10]
    // 0xd3116c: r0 = InitLateFinalStaticField()
    //     0xd3116c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd31170: mov             x2, x0
    // 0xd31174: ldur            x0, [fp, #-0x10]
    // 0xd31178: stur            x2, [fp, #-0x20]
    // 0xd3117c: LoadField: r1 = r0->field_f
    //     0xd3117c: ldur            w1, [x0, #0xf]
    // 0xd31180: DecompressPointer r1
    //     0xd31180: add             x1, x1, HEAP, lsl #32
    // 0xd31184: r0 = _controller()
    //     0xd31184: bl              #0xd320c0  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_controller
    // 0xd31188: LoadField: r1 = r0->field_37
    //     0xd31188: ldur            w1, [x0, #0x37]
    // 0xd3118c: DecompressPointer r1
    //     0xd3118c: add             x1, x1, HEAP, lsl #32
    // 0xd31190: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd31194: cmp             w1, w16
    // 0xd31198: b.eq            #0xd31250
    // 0xd3119c: LoadField: d0 = r1->field_7
    //     0xd3119c: ldur            d0, [x1, #7]
    // 0xd311a0: ldur            x1, [fp, #-0x20]
    // 0xd311a4: r0 = transform()
    //     0xd311a4: bl              #0x1103c04  ; [package:flutter/src/animation/tween.dart] CurveTween::transform
    // 0xd311a8: stur            x0, [fp, #-0x20]
    // 0xd311ac: r0 = LoadStaticField(0x774)
    //     0xd311ac: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd311b0: ldr             x0, [x0, #0xee8]
    // 0xd311b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd311b8: cmp             w0, w16
    // 0xd311bc: b.ne            #0xd311cc
    // 0xd311c0: r2 = _rotationTween
    //     0xd311c0: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fb18] Field <_CircularProgressIndicatorState@115243954._rotationTween@115243954>: static late final (offset: 0x774)
    //     0xd311c4: ldr             x2, [x2, #0xb18]
    // 0xd311c8: r0 = InitLateFinalStaticField()
    //     0xd311c8: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd311cc: mov             x2, x0
    // 0xd311d0: ldur            x0, [fp, #-0x10]
    // 0xd311d4: stur            x2, [fp, #-0x28]
    // 0xd311d8: LoadField: r1 = r0->field_f
    //     0xd311d8: ldur            w1, [x0, #0xf]
    // 0xd311dc: DecompressPointer r1
    //     0xd311dc: add             x1, x1, HEAP, lsl #32
    // 0xd311e0: r0 = _controller()
    //     0xd311e0: bl              #0xd320c0  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_controller
    // 0xd311e4: LoadField: r1 = r0->field_37
    //     0xd311e4: ldur            w1, [x0, #0x37]
    // 0xd311e8: DecompressPointer r1
    //     0xd311e8: add             x1, x1, HEAP, lsl #32
    // 0xd311ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd311f0: cmp             w1, w16
    // 0xd311f4: b.eq            #0xd31258
    // 0xd311f8: LoadField: d0 = r1->field_7
    //     0xd311f8: ldur            d0, [x1, #7]
    // 0xd311fc: ldur            x1, [fp, #-0x28]
    // 0xd31200: r0 = transform()
    //     0xd31200: bl              #0x1103c04  ; [package:flutter/src/animation/tween.dart] CurveTween::transform
    // 0xd31204: mov             x1, x0
    // 0xd31208: ldur            x0, [fp, #-0x18]
    // 0xd3120c: LoadField: d1 = r0->field_7
    //     0xd3120c: ldur            d1, [x0, #7]
    // 0xd31210: ldur            x0, [fp, #-0x20]
    // 0xd31214: LoadField: d2 = r0->field_7
    //     0xd31214: ldur            d2, [x0, #7]
    // 0xd31218: LoadField: d3 = r1->field_7
    //     0xd31218: ldur            d3, [x1, #7]
    // 0xd3121c: ldur            x1, [fp, #-8]
    // 0xd31220: ldr             x2, [fp, #0x18]
    // 0xd31224: ldur            d0, [fp, #-0x30]
    // 0xd31228: r0 = _buildMaterialIndicator()
    //     0xd31228: bl              #0xd31260  ; [package:flutter/src/material/progress_indicator.dart] _RefreshProgressIndicatorState::_buildMaterialIndicator
    // 0xd3122c: LeaveFrame
    //     0xd3122c: mov             SP, fp
    //     0xd31230: ldp             fp, lr, [SP], #0x10
    // 0xd31234: ret
    //     0xd31234: ret             
    // 0xd31238: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd31238: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd3123c: b               #0xd3107c
    // 0xd31240: r9 = _value
    //     0xd31240: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xd31244: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd31244: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd31248: r9 = _value
    //     0xd31248: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xd3124c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd3124c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd31250: r9 = _value
    //     0xd31250: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xd31254: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd31254: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd31258: r9 = _value
    //     0xd31258: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xd3125c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd3125c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildMaterialIndicator(/* No info */) {
    // ** addr: 0xd31260, size: 0x710
    // 0xd31260: EnterFrame
    //     0xd31260: stp             fp, lr, [SP, #-0x10]!
    //     0xd31264: mov             fp, SP
    // 0xd31268: AllocStack(0x80)
    //     0xd31268: sub             SP, SP, #0x80
    // 0xd3126c: SetupParameters(_RefreshProgressIndicatorState this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x38 */, dynamic _ /* d1 => d1, fp-0x40 */, dynamic _ /* d2 => d2, fp-0x48 */, dynamic _ /* d3 => d3, fp-0x50 */)
    //     0xd3126c: mov             x4, x1
    //     0xd31270: mov             x3, x2
    //     0xd31274: stur            x1, [fp, #-0x10]
    //     0xd31278: stur            x2, [fp, #-0x18]
    //     0xd3127c: stur            d0, [fp, #-0x38]
    //     0xd31280: stur            d1, [fp, #-0x40]
    //     0xd31284: stur            d2, [fp, #-0x48]
    //     0xd31288: stur            d3, [fp, #-0x50]
    // 0xd3128c: CheckStackOverflow
    //     0xd3128c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd31290: cmp             SP, x16
    //     0xd31294: b.ls            #0xd31918
    // 0xd31298: LoadField: r5 = r4->field_b
    //     0xd31298: ldur            w5, [x4, #0xb]
    // 0xd3129c: DecompressPointer r5
    //     0xd3129c: add             x5, x5, HEAP, lsl #32
    // 0xd312a0: stur            x5, [fp, #-8]
    // 0xd312a4: cmp             w5, NULL
    // 0xd312a8: b.eq            #0xd31920
    // 0xd312ac: mov             x0, x5
    // 0xd312b0: r2 = Null
    //     0xd312b0: mov             x2, NULL
    // 0xd312b4: r1 = Null
    //     0xd312b4: mov             x1, NULL
    // 0xd312b8: r4 = LoadClassIdInstr(r0)
    //     0xd312b8: ldur            x4, [x0, #-1]
    //     0xd312bc: ubfx            x4, x4, #0xc, #0x14
    // 0xd312c0: r17 = 6446
    //     0xd312c0: mov             x17, #0x192e
    // 0xd312c4: cmp             x4, x17
    // 0xd312c8: b.eq            #0xd312e0
    // 0xd312cc: r8 = RefreshProgressIndicator
    //     0xd312cc: add             x8, PP, #0x8f, lsl #12  ; [pp+0x8fb40] Type: RefreshProgressIndicator
    //     0xd312d0: ldr             x8, [x8, #0xb40]
    // 0xd312d4: r3 = Null
    //     0xd312d4: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa37f0] Null
    //     0xd312d8: ldr             x3, [x3, #0x7f0]
    // 0xd312dc: r0 = DefaultTypeTest()
    //     0xd312dc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xd312e0: ldur            x1, [fp, #-8]
    // 0xd312e4: r0 = _effectiveValue()
    //     0xd312e4: bl              #0xd30d4c  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_effectiveValue
    // 0xd312e8: stur            x0, [fp, #-8]
    // 0xd312ec: cmp             w0, NULL
    // 0xd312f0: b.ne            #0xd312fc
    // 0xd312f4: d0 = 0.000000
    //     0xd312f4: eor             v0.16b, v0.16b, v0.16b
    // 0xd312f8: b               #0xd31310
    // 0xd312fc: LoadField: d0 = r0->field_7
    //     0xd312fc: ldur            d0, [x0, #7]
    // 0xd31300: r1 = Instance_Interval
    //     0xd31300: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa37e0] Obj!Interval@129fa11
    //     0xd31304: ldr             x1, [x1, #0x7e0]
    // 0xd31308: r0 = transform()
    //     0xd31308: bl              #0x12f4dac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0xd3130c: ldur            x0, [fp, #-8]
    // 0xd31310: stur            d0, [fp, #-0x58]
    // 0xd31314: cmp             w0, NULL
    // 0xd31318: b.ne            #0xd3133c
    // 0xd3131c: ldur            x2, [fp, #-0x10]
    // 0xd31320: LoadField: r1 = r2->field_27
    //     0xd31320: ldur            w1, [x2, #0x27]
    // 0xd31324: DecompressPointer r1
    //     0xd31324: add             x1, x1, HEAP, lsl #32
    // 0xd31328: cmp             w1, NULL
    // 0xd3132c: b.ne            #0xd31340
    // 0xd31330: mov             x3, x2
    // 0xd31334: d0 = 0.000000
    //     0xd31334: eor             v0.16b, v0.16b, v0.16b
    // 0xd31338: b               #0xd313b4
    // 0xd3133c: ldur            x2, [fp, #-0x10]
    // 0xd31340: mov             x1, x2
    // 0xd31344: LoadField: r0 = r1->field_23
    //     0xd31344: ldur            w0, [x1, #0x23]
    // 0xd31348: DecompressPointer r0
    //     0xd31348: add             x0, x0, HEAP, lsl #32
    // 0xd3134c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd31350: cmp             w0, w16
    // 0xd31354: b.ne            #0xd31364
    // 0xd31358: r2 = _additionalRotationTween
    //     0xd31358: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3800] Field <_RefreshProgressIndicatorState@115243954._additionalRotationTween@115243954>: late final (offset: 0x24)
    //     0xd3135c: ldr             x2, [x2, #0x800]
    // 0xd31360: r0 = InitLateFinalInstanceField()
    //     0xd31360: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd31364: mov             x1, x0
    // 0xd31368: ldur            x0, [fp, #-8]
    // 0xd3136c: cmp             w0, NULL
    // 0xd31370: b.ne            #0xd31390
    // 0xd31374: ldur            x2, [fp, #-0x10]
    // 0xd31378: LoadField: r0 = r2->field_27
    //     0xd31378: ldur            w0, [x2, #0x27]
    // 0xd3137c: DecompressPointer r0
    //     0xd3137c: add             x0, x0, HEAP, lsl #32
    // 0xd31380: cmp             w0, NULL
    // 0xd31384: b.eq            #0xd31924
    // 0xd31388: LoadField: d0 = r0->field_7
    //     0xd31388: ldur            d0, [x0, #7]
    // 0xd3138c: b               #0xd31398
    // 0xd31390: ldur            x2, [fp, #-0x10]
    // 0xd31394: LoadField: d0 = r0->field_7
    //     0xd31394: ldur            d0, [x0, #7]
    // 0xd31398: r0 = transform()
    //     0xd31398: bl              #0x1103cd8  ; [package:flutter/src/animation/tween_sequence.dart] TweenSequence::transform
    // 0xd3139c: LoadField: d0 = r0->field_7
    //     0xd3139c: ldur            d0, [x0, #7]
    // 0xd313a0: d1 = 3.141593
    //     0xd313a0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13178] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0xd313a4: ldr             d1, [x17, #0x178]
    // 0xd313a8: fmul            d2, d0, d1
    // 0xd313ac: mov             v0.16b, v2.16b
    // 0xd313b0: ldur            x3, [fp, #-0x10]
    // 0xd313b4: stur            d0, [fp, #-0x60]
    // 0xd313b8: LoadField: r4 = r3->field_b
    //     0xd313b8: ldur            w4, [x3, #0xb]
    // 0xd313bc: DecompressPointer r4
    //     0xd313bc: add             x4, x4, HEAP, lsl #32
    // 0xd313c0: stur            x4, [fp, #-8]
    // 0xd313c4: cmp             w4, NULL
    // 0xd313c8: b.eq            #0xd31928
    // 0xd313cc: mov             x0, x4
    // 0xd313d0: r2 = Null
    //     0xd313d0: mov             x2, NULL
    // 0xd313d4: r1 = Null
    //     0xd313d4: mov             x1, NULL
    // 0xd313d8: r4 = LoadClassIdInstr(r0)
    //     0xd313d8: ldur            x4, [x0, #-1]
    //     0xd313dc: ubfx            x4, x4, #0xc, #0x14
    // 0xd313e0: r17 = 6446
    //     0xd313e0: mov             x17, #0x192e
    // 0xd313e4: cmp             x4, x17
    // 0xd313e8: b.eq            #0xd31400
    // 0xd313ec: r8 = RefreshProgressIndicator
    //     0xd313ec: add             x8, PP, #0x8f, lsl #12  ; [pp+0x8fb40] Type: RefreshProgressIndicator
    //     0xd313f0: ldr             x8, [x8, #0xb40]
    // 0xd313f4: r3 = Null
    //     0xd313f4: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3808] Null
    //     0xd313f8: ldr             x3, [x3, #0x808]
    // 0xd313fc: r0 = DefaultTypeTest()
    //     0xd313fc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xd31400: ldur            x1, [fp, #-8]
    // 0xd31404: ldur            x2, [fp, #-0x18]
    // 0xd31408: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xd31408: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xd3140c: r0 = _getValueColor()
    //     0xd3140c: bl              #0xd30b14  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_getValueColor
    // 0xd31410: mov             x2, x0
    // 0xd31414: stur            x2, [fp, #-8]
    // 0xd31418: r0 = LoadClassIdInstr(r2)
    //     0xd31418: ldur            x0, [x2, #-1]
    //     0xd3141c: ubfx            x0, x0, #0xc, #0x14
    // 0xd31420: mov             x1, x2
    // 0xd31424: r0 = GDT[cid_x0 + -0xfab]()
    //     0xd31424: sub             lr, x0, #0xfab
    //     0xd31428: ldr             lr, [x21, lr, lsl #3]
    //     0xd3142c: blr             lr
    // 0xd31430: mov             v1.16b, v0.16b
    // 0xd31434: ldur            x1, [fp, #-8]
    // 0xd31438: stur            d1, [fp, #-0x68]
    // 0xd3143c: r0 = LoadClassIdInstr(r1)
    //     0xd3143c: ldur            x0, [x1, #-1]
    //     0xd31440: ubfx            x0, x0, #0xc, #0x14
    // 0xd31444: d0 = 1.000000
    //     0xd31444: fmov            d0, #1.00000000
    // 0xd31448: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd31448: sub             lr, x0, #1, lsl #12
    //     0xd3144c: ldr             lr, [x21, lr, lsl #3]
    //     0xd31450: blr             lr
    // 0xd31454: ldur            x1, [fp, #-0x18]
    // 0xd31458: stur            x0, [fp, #-8]
    // 0xd3145c: r0 = of()
    //     0xd3145c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd31460: LoadField: r1 = r0->field_2f
    //     0xd31460: ldur            w1, [x0, #0x2f]
    // 0xd31464: DecompressPointer r1
    //     0xd31464: add             x1, x1, HEAP, lsl #32
    // 0xd31468: tbnz            w1, #4, #0xd31494
    // 0xd3146c: ldur            x1, [fp, #-0x18]
    // 0xd31470: r0 = _CircularProgressIndicatorDefaultsM3Year2023()
    //     0xd31470: bl              #0xd31e64  ; Allocate_CircularProgressIndicatorDefaultsM3Year2023Stub -> _CircularProgressIndicatorDefaultsM3Year2023 (size=0x50)
    // 0xd31474: mov             x1, x0
    // 0xd31478: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3147c: StoreField: r1->field_4b = r0
    //     0xd3147c: stur            w0, [x1, #0x4b]
    // 0xd31480: ldur            x2, [fp, #-0x18]
    // 0xd31484: StoreField: r1->field_47 = r2
    //     0xd31484: stur            w2, [x1, #0x47]
    // 0xd31488: mov             x3, x1
    // 0xd3148c: mov             x0, x2
    // 0xd31490: b               #0xd314b8
    // 0xd31494: ldur            x2, [fp, #-0x18]
    // 0xd31498: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3149c: r0 = _CircularProgressIndicatorDefaultsM2()
    //     0xd3149c: bl              #0xd31e58  ; Allocate_CircularProgressIndicatorDefaultsM2Stub -> _CircularProgressIndicatorDefaultsM2 (size=0x50)
    // 0xd314a0: mov             x1, x0
    // 0xd314a4: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd314a8: StoreField: r1->field_4b = r0
    //     0xd314a8: stur            w0, [x1, #0x4b]
    // 0xd314ac: ldur            x0, [fp, #-0x18]
    // 0xd314b0: StoreField: r1->field_47 = r0
    //     0xd314b0: stur            w0, [x1, #0x47]
    // 0xd314b4: mov             x3, x1
    // 0xd314b8: ldur            x2, [fp, #-0x10]
    // 0xd314bc: mov             x1, x0
    // 0xd314c0: stur            x3, [fp, #-0x20]
    // 0xd314c4: r0 = of()
    //     0xd314c4: bl              #0xd30c34  ; [package:flutter/src/material/progress_indicator_theme.dart] ProgressIndicatorTheme::of
    // 0xd314c8: mov             x4, x0
    // 0xd314cc: ldur            x3, [fp, #-0x10]
    // 0xd314d0: stur            x4, [fp, #-0x30]
    // 0xd314d4: LoadField: r5 = r3->field_b
    //     0xd314d4: ldur            w5, [x3, #0xb]
    // 0xd314d8: DecompressPointer r5
    //     0xd314d8: add             x5, x5, HEAP, lsl #32
    // 0xd314dc: stur            x5, [fp, #-0x28]
    // 0xd314e0: cmp             w5, NULL
    // 0xd314e4: b.eq            #0xd3192c
    // 0xd314e8: mov             x0, x5
    // 0xd314ec: r2 = Null
    //     0xd314ec: mov             x2, NULL
    // 0xd314f0: r1 = Null
    //     0xd314f0: mov             x1, NULL
    // 0xd314f4: r4 = LoadClassIdInstr(r0)
    //     0xd314f4: ldur            x4, [x0, #-1]
    //     0xd314f8: ubfx            x4, x4, #0xc, #0x14
    // 0xd314fc: r17 = 6446
    //     0xd314fc: mov             x17, #0x192e
    // 0xd31500: cmp             x4, x17
    // 0xd31504: b.eq            #0xd3151c
    // 0xd31508: r8 = RefreshProgressIndicator
    //     0xd31508: add             x8, PP, #0x8f, lsl #12  ; [pp+0x8fb40] Type: RefreshProgressIndicator
    //     0xd3150c: ldr             x8, [x8, #0xb40]
    // 0xd31510: r3 = Null
    //     0xd31510: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3818] Null
    //     0xd31514: ldr             x3, [x3, #0x818]
    // 0xd31518: r0 = DefaultTypeTest()
    //     0xd31518: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xd3151c: ldur            x0, [fp, #-0x28]
    // 0xd31520: LoadField: r1 = r0->field_f
    //     0xd31520: ldur            w1, [x0, #0xf]
    // 0xd31524: DecompressPointer r1
    //     0xd31524: add             x1, x1, HEAP, lsl #32
    // 0xd31528: cmp             w1, NULL
    // 0xd3152c: b.ne            #0xd31538
    // 0xd31530: r0 = Null
    //     0xd31530: mov             x0, NULL
    // 0xd31534: b               #0xd3153c
    // 0xd31538: mov             x0, x1
    // 0xd3153c: cmp             w0, NULL
    // 0xd31540: b.ne            #0xd3155c
    // 0xd31544: ldur            x1, [fp, #-0x18]
    // 0xd31548: r0 = of()
    //     0xd31548: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd3154c: LoadField: r1 = r0->field_37
    //     0xd3154c: ldur            w1, [x0, #0x37]
    // 0xd31550: DecompressPointer r1
    //     0xd31550: add             x1, x1, HEAP, lsl #32
    // 0xd31554: mov             x4, x1
    // 0xd31558: b               #0xd31560
    // 0xd3155c: mov             x4, x0
    // 0xd31560: ldur            x3, [fp, #-0x10]
    // 0xd31564: stur            x4, [fp, #-0x28]
    // 0xd31568: LoadField: r5 = r3->field_b
    //     0xd31568: ldur            w5, [x3, #0xb]
    // 0xd3156c: DecompressPointer r5
    //     0xd3156c: add             x5, x5, HEAP, lsl #32
    // 0xd31570: stur            x5, [fp, #-0x18]
    // 0xd31574: cmp             w5, NULL
    // 0xd31578: b.eq            #0xd31930
    // 0xd3157c: mov             x0, x5
    // 0xd31580: r2 = Null
    //     0xd31580: mov             x2, NULL
    // 0xd31584: r1 = Null
    //     0xd31584: mov             x1, NULL
    // 0xd31588: r4 = LoadClassIdInstr(r0)
    //     0xd31588: ldur            x4, [x0, #-1]
    //     0xd3158c: ubfx            x4, x4, #0xc, #0x14
    // 0xd31590: r17 = 6446
    //     0xd31590: mov             x17, #0x192e
    // 0xd31594: cmp             x4, x17
    // 0xd31598: b.eq            #0xd315b0
    // 0xd3159c: r8 = RefreshProgressIndicator
    //     0xd3159c: add             x8, PP, #0x8f, lsl #12  ; [pp+0x8fb40] Type: RefreshProgressIndicator
    //     0xd315a0: ldr             x8, [x8, #0xb40]
    // 0xd315a4: r3 = Null
    //     0xd315a4: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3828] Null
    //     0xd315a8: ldr             x3, [x3, #0x828]
    // 0xd315ac: r0 = DefaultTypeTest()
    //     0xd315ac: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xd315b0: ldur            x0, [fp, #-0x18]
    // 0xd315b4: LoadField: r1 = r0->field_27
    //     0xd315b4: ldur            w1, [x0, #0x27]
    // 0xd315b8: DecompressPointer r1
    //     0xd315b8: add             x1, x1, HEAP, lsl #32
    // 0xd315bc: cmp             w1, NULL
    // 0xd315c0: b.ne            #0xd315d4
    // 0xd315c4: ldur            x2, [fp, #-0x30]
    // 0xd315c8: LoadField: r0 = r2->field_27
    //     0xd315c8: ldur            w0, [x2, #0x27]
    // 0xd315cc: DecompressPointer r0
    //     0xd315cc: add             x0, x0, HEAP, lsl #32
    // 0xd315d0: b               #0xd315dc
    // 0xd315d4: ldur            x2, [fp, #-0x30]
    // 0xd315d8: mov             x0, x1
    // 0xd315dc: cmp             w0, NULL
    // 0xd315e0: b.ne            #0xd31608
    // 0xd315e4: ldur            x3, [fp, #-0x20]
    // 0xd315e8: r0 = LoadClassIdInstr(r3)
    //     0xd315e8: ldur            x0, [x3, #-1]
    //     0xd315ec: ubfx            x0, x0, #0xc, #0x14
    // 0xd315f0: mov             x1, x3
    // 0xd315f4: r0 = GDT[cid_x0 + 0xebf]()
    //     0xd315f4: add             lr, x0, #0xebf
    //     0xd315f8: ldr             lr, [x21, lr, lsl #3]
    //     0xd315fc: blr             lr
    // 0xd31600: d5 = 4.000000
    //     0xd31600: fmov            d5, #4.00000000
    // 0xd31604: b               #0xd31610
    // 0xd31608: LoadField: d0 = r0->field_7
    //     0xd31608: ldur            d0, [x0, #7]
    // 0xd3160c: mov             v5.16b, v0.16b
    // 0xd31610: ldur            x4, [fp, #-0x10]
    // 0xd31614: ldur            x3, [fp, #-0x30]
    // 0xd31618: stur            d5, [fp, #-0x70]
    // 0xd3161c: LoadField: r0 = r4->field_b
    //     0xd3161c: ldur            w0, [x4, #0xb]
    // 0xd31620: DecompressPointer r0
    //     0xd31620: add             x0, x0, HEAP, lsl #32
    // 0xd31624: cmp             w0, NULL
    // 0xd31628: b.eq            #0xd31934
    // 0xd3162c: r2 = Null
    //     0xd3162c: mov             x2, NULL
    // 0xd31630: r1 = Null
    //     0xd31630: mov             x1, NULL
    // 0xd31634: r4 = LoadClassIdInstr(r0)
    //     0xd31634: ldur            x4, [x0, #-1]
    //     0xd31638: ubfx            x4, x4, #0xc, #0x14
    // 0xd3163c: r17 = 6446
    //     0xd3163c: mov             x17, #0x192e
    // 0xd31640: cmp             x4, x17
    // 0xd31644: b.eq            #0xd3165c
    // 0xd31648: r8 = RefreshProgressIndicator
    //     0xd31648: add             x8, PP, #0x8f, lsl #12  ; [pp+0x8fb40] Type: RefreshProgressIndicator
    //     0xd3164c: ldr             x8, [x8, #0xb40]
    // 0xd31650: r3 = Null
    //     0xd31650: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3838] Null
    //     0xd31654: ldr             x3, [x3, #0x838]
    // 0xd31658: r0 = DefaultTypeTest()
    //     0xd31658: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xd3165c: ldur            x0, [fp, #-0x30]
    // 0xd31660: LoadField: r1 = r0->field_2b
    //     0xd31660: ldur            w1, [x0, #0x2b]
    // 0xd31664: DecompressPointer r1
    //     0xd31664: add             x1, x1, HEAP, lsl #32
    // 0xd31668: cmp             w1, NULL
    // 0xd3166c: b.ne            #0xd31690
    // 0xd31670: ldur            x1, [fp, #-0x20]
    // 0xd31674: r0 = LoadClassIdInstr(r1)
    //     0xd31674: ldur            x0, [x1, #-1]
    //     0xd31678: ubfx            x0, x0, #0xc, #0x14
    // 0xd3167c: r0 = GDT[cid_x0 + 0xeb8]()
    //     0xd3167c: add             lr, x0, #0xeb8
    //     0xd31680: ldr             lr, [x21, lr, lsl #3]
    //     0xd31684: blr             lr
    // 0xd31688: d4 = 0.000000
    //     0xd31688: eor             v4.16b, v4.16b, v4.16b
    // 0xd3168c: b               #0xd31698
    // 0xd31690: LoadField: d0 = r1->field_7
    //     0xd31690: ldur            d0, [x1, #7]
    // 0xd31694: mov             v4.16b, v0.16b
    // 0xd31698: ldur            x0, [fp, #-0x10]
    // 0xd3169c: ldur            d1, [fp, #-0x40]
    // 0xd316a0: ldur            d0, [fp, #-0x68]
    // 0xd316a4: ldur            x3, [fp, #-0x28]
    // 0xd316a8: stur            d4, [fp, #-0x78]
    // 0xd316ac: LoadField: r4 = r0->field_b
    //     0xd316ac: ldur            w4, [x0, #0xb]
    // 0xd316b0: DecompressPointer r4
    //     0xd316b0: add             x4, x4, HEAP, lsl #32
    // 0xd316b4: stur            x4, [fp, #-0x18]
    // 0xd316b8: cmp             w4, NULL
    // 0xd316bc: b.eq            #0xd31938
    // 0xd316c0: mov             x0, x4
    // 0xd316c4: r2 = Null
    //     0xd316c4: mov             x2, NULL
    // 0xd316c8: r1 = Null
    //     0xd316c8: mov             x1, NULL
    // 0xd316cc: r4 = LoadClassIdInstr(r0)
    //     0xd316cc: ldur            x4, [x0, #-1]
    //     0xd316d0: ubfx            x4, x4, #0xc, #0x14
    // 0xd316d4: r17 = 6446
    //     0xd316d4: mov             x17, #0x192e
    // 0xd316d8: cmp             x4, x17
    // 0xd316dc: b.eq            #0xd316f4
    // 0xd316e0: r8 = RefreshProgressIndicator
    //     0xd316e0: add             x8, PP, #0x8f, lsl #12  ; [pp+0x8fb40] Type: RefreshProgressIndicator
    //     0xd316e4: ldr             x8, [x8, #0xb40]
    // 0xd316e8: r3 = Null
    //     0xd316e8: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3848] Null
    //     0xd316ec: ldr             x3, [x3, #0x848]
    // 0xd316f0: r0 = DefaultTypeTest()
    //     0xd316f0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xd316f4: r0 = _RefreshProgressIndicatorPainter()
    //     0xd316f4: bl              #0xd31e4c  ; Allocate_RefreshProgressIndicatorPainterStub -> _RefreshProgressIndicatorPainter (size=0x6c)
    // 0xd316f8: ldur            d0, [fp, #-0x40]
    // 0xd316fc: stur            x0, [fp, #-0x10]
    // 0xd31700: str             d0, [SP]
    // 0xd31704: mov             x1, x0
    // 0xd31708: ldur            d0, [fp, #-0x58]
    // 0xd3170c: ldur            d1, [fp, #-0x38]
    // 0xd31710: ldur            d2, [fp, #-0x48]
    // 0xd31714: ldur            d3, [fp, #-0x50]
    // 0xd31718: ldur            d4, [fp, #-0x78]
    // 0xd3171c: ldur            d5, [fp, #-0x70]
    // 0xd31720: ldur            x2, [fp, #-8]
    // 0xd31724: r0 = _RefreshProgressIndicatorPainter()
    //     0xd31724: bl              #0xd31b30  ; [package:flutter/src/material/progress_indicator.dart] _RefreshProgressIndicatorPainter::_RefreshProgressIndicatorPainter
    // 0xd31728: r0 = CustomPaint()
    //     0xd31728: bl              #0xd0a594  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0xd3172c: mov             x1, x0
    // 0xd31730: ldur            x0, [fp, #-0x10]
    // 0xd31734: stur            x1, [fp, #-8]
    // 0xd31738: StoreField: r1->field_f = r0
    //     0xd31738: stur            w0, [x1, #0xf]
    // 0xd3173c: r0 = Instance_Size
    //     0xd3173c: ldr             x0, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xd31740: ArrayStore: r1[0] = r0  ; List_4
    //     0xd31740: stur            w0, [x1, #0x17]
    // 0xd31744: r0 = false
    //     0xd31744: add             x0, NULL, #0x30  ; false
    // 0xd31748: StoreField: r1->field_1b = r0
    //     0xd31748: stur            w0, [x1, #0x1b]
    // 0xd3174c: StoreField: r1->field_1f = r0
    //     0xd3174c: stur            w0, [x1, #0x1f]
    // 0xd31750: r0 = Transform()
    //     0xd31750: bl              #0xd30150  ; AllocateTransformStub -> Transform (size=0x24)
    // 0xd31754: mov             x1, x0
    // 0xd31758: r0 = Instance_Alignment
    //     0xd31758: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xd3175c: ldr             x0, [x0, #0xb80]
    // 0xd31760: stur            x1, [fp, #-0x10]
    // 0xd31764: ArrayStore: r1[0] = r0  ; List_4
    //     0xd31764: stur            w0, [x1, #0x17]
    // 0xd31768: r0 = true
    //     0xd31768: add             x0, NULL, #0x20  ; true
    // 0xd3176c: StoreField: r1->field_1b = r0
    //     0xd3176c: stur            w0, [x1, #0x1b]
    // 0xd31770: ldur            d0, [fp, #-0x60]
    // 0xd31774: r0 = _computeRotation()
    //     0xd31774: bl              #0xd31970  ; [package:flutter/src/widgets/basic.dart] Transform::_computeRotation
    // 0xd31778: ldur            x1, [fp, #-0x10]
    // 0xd3177c: StoreField: r1->field_f = r0
    //     0xd3177c: stur            w0, [x1, #0xf]
    //     0xd31780: ldurb           w16, [x1, #-1]
    //     0xd31784: ldurb           w17, [x0, #-1]
    //     0xd31788: and             x16, x17, x16, lsr #2
    //     0xd3178c: tst             x16, HEAP, lsr #32
    //     0xd31790: b.eq            #0xd31798
    //     0xd31794: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd31798: ldur            x0, [fp, #-8]
    // 0xd3179c: StoreField: r1->field_b = r0
    //     0xd3179c: stur            w0, [x1, #0xb]
    //     0xd317a0: ldurb           w16, [x1, #-1]
    //     0xd317a4: ldurb           w17, [x0, #-1]
    //     0xd317a8: and             x16, x17, x16, lsr #2
    //     0xd317ac: tst             x16, HEAP, lsr #32
    //     0xd317b0: b.eq            #0xd317b8
    //     0xd317b4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd317b8: r0 = Opacity()
    //     0xd317b8: bl              #0xd3015c  ; AllocateOpacityStub -> Opacity (size=0x1c)
    // 0xd317bc: ldur            d0, [fp, #-0x68]
    // 0xd317c0: stur            x0, [fp, #-8]
    // 0xd317c4: StoreField: r0->field_f = d0
    //     0xd317c4: stur            d0, [x0, #0xf]
    // 0xd317c8: r1 = false
    //     0xd317c8: add             x1, NULL, #0x30  ; false
    // 0xd317cc: ArrayStore: r0[0] = r1  ; List_4
    //     0xd317cc: stur            w1, [x0, #0x17]
    // 0xd317d0: ldur            x2, [fp, #-0x10]
    // 0xd317d4: StoreField: r0->field_b = r2
    //     0xd317d4: stur            w2, [x0, #0xb]
    // 0xd317d8: r0 = Padding()
    //     0xd317d8: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xd317dc: mov             x1, x0
    // 0xd317e0: r0 = Instance_EdgeInsets
    //     0xd317e0: add             x0, PP, #0x7b, lsl #12  ; [pp+0x7b208] Obj!EdgeInsets@129ce11
    //     0xd317e4: ldr             x0, [x0, #0x208]
    // 0xd317e8: stur            x1, [fp, #-0x10]
    // 0xd317ec: StoreField: r1->field_f = r0
    //     0xd317ec: stur            w0, [x1, #0xf]
    // 0xd317f0: ldur            x0, [fp, #-8]
    // 0xd317f4: StoreField: r1->field_b = r0
    //     0xd317f4: stur            w0, [x1, #0xb]
    // 0xd317f8: r0 = Material()
    //     0xd317f8: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xd317fc: mov             x1, x0
    // 0xd31800: r0 = Instance_MaterialType
    //     0xd31800: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8fcb0] Obj!MaterialType@12c53a1
    //     0xd31804: ldr             x0, [x0, #0xcb0]
    // 0xd31808: stur            x1, [fp, #-0x20]
    // 0xd3180c: StoreField: r1->field_f = r0
    //     0xd3180c: stur            w0, [x1, #0xf]
    // 0xd31810: d0 = 2.000000
    //     0xd31810: fmov            d0, #2.00000000
    // 0xd31814: ArrayStore: r1[0] = d0  ; List_8
    //     0xd31814: stur            d0, [x1, #0x17]
    // 0xd31818: ldur            x0, [fp, #-0x28]
    // 0xd3181c: StoreField: r1->field_1f = r0
    //     0xd3181c: stur            w0, [x1, #0x1f]
    // 0xd31820: r0 = true
    //     0xd31820: add             x0, NULL, #0x20  ; true
    // 0xd31824: StoreField: r1->field_33 = r0
    //     0xd31824: stur            w0, [x1, #0x33]
    // 0xd31828: r0 = Instance_Clip
    //     0xd31828: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xd3182c: ldr             x0, [x0, #0x840]
    // 0xd31830: StoreField: r1->field_37 = r0
    //     0xd31830: stur            w0, [x1, #0x37]
    // 0xd31834: r0 = Instance_Duration
    //     0xd31834: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xd31838: ldr             x0, [x0, #0x318]
    // 0xd3183c: StoreField: r1->field_3b = r0
    //     0xd3183c: stur            w0, [x1, #0x3b]
    // 0xd31840: ldur            x0, [fp, #-0x10]
    // 0xd31844: StoreField: r1->field_b = r0
    //     0xd31844: stur            w0, [x1, #0xb]
    // 0xd31848: r0 = false
    //     0xd31848: add             x0, NULL, #0x30  ; false
    // 0xd3184c: StoreField: r1->field_13 = r0
    //     0xd3184c: stur            w0, [x1, #0x13]
    // 0xd31850: r0 = Instance_Size
    //     0xd31850: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3858] Obj!Size@12a76b1
    //     0xd31854: ldr             x0, [x0, #0x858]
    // 0xd31858: LoadField: d0 = r0->field_7
    //     0xd31858: ldur            d0, [x0, #7]
    // 0xd3185c: r2 = inline_Allocate_Double()
    //     0xd3185c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xd31860: add             x2, x2, #0x10
    //     0xd31864: cmp             x3, x2
    //     0xd31868: b.ls            #0xd3193c
    //     0xd3186c: str             x2, [THR, #0x60]  ; THR::top
    //     0xd31870: sub             x2, x2, #0xf
    //     0xd31874: mov             x3, #0xe19c
    //     0xd31878: movk            x3, #3, lsl #16
    //     0xd3187c: stur            x3, [x2, #-1]
    // 0xd31880: dmb             ishst
    // 0xd31884: StoreField: r2->field_7 = d0
    //     0xd31884: stur            d0, [x2, #7]
    // 0xd31888: stur            x2, [fp, #-8]
    // 0xd3188c: r0 = SizedBox()
    //     0xd3188c: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xd31890: mov             x1, x0
    // 0xd31894: ldur            x0, [fp, #-8]
    // 0xd31898: stur            x1, [fp, #-0x10]
    // 0xd3189c: StoreField: r1->field_f = r0
    //     0xd3189c: stur            w0, [x1, #0xf]
    // 0xd318a0: r0 = Instance_Size
    //     0xd318a0: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3858] Obj!Size@12a76b1
    //     0xd318a4: ldr             x0, [x0, #0x858]
    // 0xd318a8: LoadField: d0 = r0->field_f
    //     0xd318a8: ldur            d0, [x0, #0xf]
    // 0xd318ac: r0 = inline_Allocate_Double()
    //     0xd318ac: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xd318b0: add             x0, x0, #0x10
    //     0xd318b4: cmp             x2, x0
    //     0xd318b8: b.ls            #0xd31958
    //     0xd318bc: str             x0, [THR, #0x60]  ; THR::top
    //     0xd318c0: sub             x0, x0, #0xf
    //     0xd318c4: mov             x2, #0xe19c
    //     0xd318c8: movk            x2, #3, lsl #16
    //     0xd318cc: stur            x2, [x0, #-1]
    // 0xd318d0: dmb             ishst
    // 0xd318d4: StoreField: r0->field_7 = d0
    //     0xd318d4: stur            d0, [x0, #7]
    // 0xd318d8: StoreField: r1->field_13 = r0
    //     0xd318d8: stur            w0, [x1, #0x13]
    // 0xd318dc: ldur            x0, [fp, #-0x20]
    // 0xd318e0: StoreField: r1->field_b = r0
    //     0xd318e0: stur            w0, [x1, #0xb]
    // 0xd318e4: r0 = Padding()
    //     0xd318e4: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xd318e8: mov             x1, x0
    // 0xd318ec: r0 = Instance_EdgeInsets
    //     0xd318ec: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8c9b0] Obj!EdgeInsets@129cde1
    //     0xd318f0: ldr             x0, [x0, #0x9b0]
    // 0xd318f4: StoreField: r1->field_f = r0
    //     0xd318f4: stur            w0, [x1, #0xf]
    // 0xd318f8: ldur            x0, [fp, #-0x10]
    // 0xd318fc: StoreField: r1->field_b = r0
    //     0xd318fc: stur            w0, [x1, #0xb]
    // 0xd31900: mov             x2, x1
    // 0xd31904: ldur            x1, [fp, #-0x18]
    // 0xd31908: r0 = _buildSemanticsWrapper()
    //     0xd31908: bl              #0xd30974  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_buildSemanticsWrapper
    // 0xd3190c: LeaveFrame
    //     0xd3190c: mov             SP, fp
    //     0xd31910: ldp             fp, lr, [SP], #0x10
    // 0xd31914: ret
    //     0xd31914: ret             
    // 0xd31918: r0 = StackOverflowSharedWithFPURegs()
    //     0xd31918: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd3191c: b               #0xd31298
    // 0xd31920: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd31920: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd31924: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd31924: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd31928: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd31928: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd3192c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3192c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd31930: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd31930: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd31934: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd31934: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd31938: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd31938: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd3193c: SaveReg d0
    //     0xd3193c: str             q0, [SP, #-0x10]!
    // 0xd31940: stp             x0, x1, [SP, #-0x10]!
    // 0xd31944: r0 = AllocateDouble()
    //     0xd31944: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd31948: mov             x2, x0
    // 0xd3194c: ldp             x0, x1, [SP], #0x10
    // 0xd31950: RestoreReg d0
    //     0xd31950: ldr             q0, [SP], #0x10
    // 0xd31954: b               #0xd31884
    // 0xd31958: SaveReg d0
    //     0xd31958: str             q0, [SP, #-0x10]!
    // 0xd3195c: SaveReg r1
    //     0xd3195c: str             x1, [SP, #-8]!
    // 0xd31960: r0 = AllocateDouble()
    //     0xd31960: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd31964: RestoreReg r1
    //     0xd31964: ldr             x1, [SP], #8
    // 0xd31968: RestoreReg d0
    //     0xd31968: ldr             q0, [SP], #0x10
    // 0xd3196c: b               #0xd318d4
  }
  Animatable<double> _additionalRotationTween(_RefreshProgressIndicatorState) {
    // ** addr: 0xd31e70, size: 0x128
    // 0xd31e70: EnterFrame
    //     0xd31e70: stp             fp, lr, [SP, #-0x10]!
    //     0xd31e74: mov             fp, SP
    // 0xd31e78: AllocStack(0x18)
    //     0xd31e78: sub             SP, SP, #0x18
    // 0xd31e7c: CheckStackOverflow
    //     0xd31e7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd31e80: cmp             SP, x16
    //     0xd31e84: b.ls            #0xd31f90
    // 0xd31e88: r1 = <double>
    //     0xd31e88: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd31e8c: r0 = Tween()
    //     0xd31e8c: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xd31e90: mov             x2, x0
    // 0xd31e94: r0 = -0.100000
    //     0xd31e94: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3860] -0.1
    //     0xd31e98: ldr             x0, [x0, #0x860]
    // 0xd31e9c: stur            x2, [fp, #-8]
    // 0xd31ea0: StoreField: r2->field_b = r0
    //     0xd31ea0: stur            w0, [x2, #0xb]
    // 0xd31ea4: r0 = -0.200000
    //     0xd31ea4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28680] -0.2
    //     0xd31ea8: ldr             x0, [x0, #0x680]
    // 0xd31eac: StoreField: r2->field_f = r0
    //     0xd31eac: stur            w0, [x2, #0xf]
    // 0xd31eb0: r1 = <double>
    //     0xd31eb0: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd31eb4: r0 = TweenSequenceItem()
    //     0xd31eb4: bl              #0xb6f82c  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0xd31eb8: mov             x2, x0
    // 0xd31ebc: ldur            x0, [fp, #-8]
    // 0xd31ec0: stur            x2, [fp, #-0x10]
    // 0xd31ec4: StoreField: r2->field_b = r0
    //     0xd31ec4: stur            w0, [x2, #0xb]
    // 0xd31ec8: d0 = 0.330000
    //     0xd31ec8: add             x17, PP, #0xa3, lsl #12  ; [pp+0xa3868] IMM: double(0.33) from 0x3fd51eb851eb851f
    //     0xd31ecc: ldr             d0, [x17, #0x868]
    // 0xd31ed0: StoreField: r2->field_f = d0
    //     0xd31ed0: stur            d0, [x2, #0xf]
    // 0xd31ed4: r1 = <double>
    //     0xd31ed4: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd31ed8: r0 = Tween()
    //     0xd31ed8: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xd31edc: mov             x2, x0
    // 0xd31ee0: r0 = -0.200000
    //     0xd31ee0: add             x0, PP, #0x28, lsl #12  ; [pp+0x28680] -0.2
    //     0xd31ee4: ldr             x0, [x0, #0x680]
    // 0xd31ee8: stur            x2, [fp, #-8]
    // 0xd31eec: StoreField: r2->field_b = r0
    //     0xd31eec: stur            w0, [x2, #0xb]
    // 0xd31ef0: r0 = 1.350000
    //     0xd31ef0: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3870] 1.35
    //     0xd31ef4: ldr             x0, [x0, #0x870]
    // 0xd31ef8: StoreField: r2->field_f = r0
    //     0xd31ef8: stur            w0, [x2, #0xf]
    // 0xd31efc: r1 = <double>
    //     0xd31efc: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd31f00: r0 = TweenSequenceItem()
    //     0xd31f00: bl              #0xb6f82c  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0xd31f04: mov             x3, x0
    // 0xd31f08: ldur            x0, [fp, #-8]
    // 0xd31f0c: stur            x3, [fp, #-0x18]
    // 0xd31f10: StoreField: r3->field_b = r0
    //     0xd31f10: stur            w0, [x3, #0xb]
    // 0xd31f14: d0 = 0.670000
    //     0xd31f14: add             x17, PP, #0xa3, lsl #12  ; [pp+0xa3878] IMM: double(0.6699999999999999) from 0x3fe570a3d70a3d70
    //     0xd31f18: ldr             d0, [x17, #0x878]
    // 0xd31f1c: StoreField: r3->field_f = d0
    //     0xd31f1c: stur            d0, [x3, #0xf]
    // 0xd31f20: r1 = Null
    //     0xd31f20: mov             x1, NULL
    // 0xd31f24: r2 = 4
    //     0xd31f24: mov             x2, #4
    // 0xd31f28: r0 = AllocateArray()
    //     0xd31f28: bl              #0x13df928  ; AllocateArrayStub
    // 0xd31f2c: mov             x2, x0
    // 0xd31f30: ldur            x0, [fp, #-0x10]
    // 0xd31f34: stur            x2, [fp, #-8]
    // 0xd31f38: StoreField: r2->field_f = r0
    //     0xd31f38: stur            w0, [x2, #0xf]
    // 0xd31f3c: ldur            x0, [fp, #-0x18]
    // 0xd31f40: StoreField: r2->field_13 = r0
    //     0xd31f40: stur            w0, [x2, #0x13]
    // 0xd31f44: r1 = <TweenSequenceItem<double>>
    //     0xd31f44: add             x1, PP, #0x99, lsl #12  ; [pp+0x995e0] TypeArguments: <TweenSequenceItem<double>>
    //     0xd31f48: ldr             x1, [x1, #0x5e0]
    // 0xd31f4c: r0 = AllocateGrowableArray()
    //     0xd31f4c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd31f50: mov             x2, x0
    // 0xd31f54: ldur            x0, [fp, #-8]
    // 0xd31f58: stur            x2, [fp, #-0x10]
    // 0xd31f5c: StoreField: r2->field_f = r0
    //     0xd31f5c: stur            w0, [x2, #0xf]
    // 0xd31f60: r0 = 4
    //     0xd31f60: mov             x0, #4
    // 0xd31f64: StoreField: r2->field_b = r0
    //     0xd31f64: stur            w0, [x2, #0xb]
    // 0xd31f68: r1 = <double>
    //     0xd31f68: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd31f6c: r0 = TweenSequence()
    //     0xd31f6c: bl              #0xb6f808  ; AllocateTweenSequenceStub -> TweenSequence<X0> (size=0x14)
    // 0xd31f70: mov             x1, x0
    // 0xd31f74: ldur            x2, [fp, #-0x10]
    // 0xd31f78: stur            x0, [fp, #-8]
    // 0xd31f7c: r0 = TweenSequence()
    //     0xd31f7c: bl              #0xb6f43c  ; [package:flutter/src/animation/tween_sequence.dart] TweenSequence::TweenSequence
    // 0xd31f80: ldur            x0, [fp, #-8]
    // 0xd31f84: LeaveFrame
    //     0xd31f84: mov             SP, fp
    //     0xd31f88: ldp             fp, lr, [SP], #0x10
    // 0xd31f8c: ret
    //     0xd31f8c: ret             
    // 0xd31f90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd31f90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd31f94: b               #0xd31e88
  }
  Animatable<double> _convertTween(_RefreshProgressIndicatorState) {
    // ** addr: 0xd321e4, size: 0x28
    // 0xd321e4: EnterFrame
    //     0xd321e4: stp             fp, lr, [SP, #-0x10]!
    //     0xd321e8: mov             fp, SP
    // 0xd321ec: r1 = <double>
    //     0xd321ec: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd321f0: r0 = CurveTween()
    //     0xd321f0: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xd321f4: r1 = Instance_Interval
    //     0xd321f4: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa37e0] Obj!Interval@129fa11
    //     0xd321f8: ldr             x1, [x1, #0x7e0]
    // 0xd321fc: StoreField: r0->field_b = r1
    //     0xd321fc: stur            w1, [x0, #0xb]
    // 0xd32200: LeaveFrame
    //     0xd32200: mov             SP, fp
    //     0xd32204: ldp             fp, lr, [SP], #0x10
    // 0xd32208: ret
    //     0xd32208: ret             
  }
  get _ widget(/* No info */) {
    // ** addr: 0xf9fd48, size: 0x68
    // 0xf9fd48: EnterFrame
    //     0xf9fd48: stp             fp, lr, [SP, #-0x10]!
    //     0xf9fd4c: mov             fp, SP
    // 0xf9fd50: AllocStack(0x8)
    //     0xf9fd50: sub             SP, SP, #8
    // 0xf9fd54: LoadField: r3 = r1->field_b
    //     0xf9fd54: ldur            w3, [x1, #0xb]
    // 0xf9fd58: DecompressPointer r3
    //     0xf9fd58: add             x3, x3, HEAP, lsl #32
    // 0xf9fd5c: stur            x3, [fp, #-8]
    // 0xf9fd60: cmp             w3, NULL
    // 0xf9fd64: b.eq            #0xf9fdac
    // 0xf9fd68: mov             x0, x3
    // 0xf9fd6c: r2 = Null
    //     0xf9fd6c: mov             x2, NULL
    // 0xf9fd70: r1 = Null
    //     0xf9fd70: mov             x1, NULL
    // 0xf9fd74: r4 = LoadClassIdInstr(r0)
    //     0xf9fd74: ldur            x4, [x0, #-1]
    //     0xf9fd78: ubfx            x4, x4, #0xc, #0x14
    // 0xf9fd7c: r17 = 6446
    //     0xf9fd7c: mov             x17, #0x192e
    // 0xf9fd80: cmp             x4, x17
    // 0xf9fd84: b.eq            #0xf9fd9c
    // 0xf9fd88: r8 = RefreshProgressIndicator
    //     0xf9fd88: add             x8, PP, #0x8f, lsl #12  ; [pp+0x8fb40] Type: RefreshProgressIndicator
    //     0xf9fd8c: ldr             x8, [x8, #0xb40]
    // 0xf9fd90: r3 = Null
    //     0xf9fd90: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3888] Null
    //     0xf9fd94: ldr             x3, [x3, #0x888]
    // 0xf9fd98: r0 = DefaultTypeTest()
    //     0xf9fd98: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xf9fd9c: ldur            x0, [fp, #-8]
    // 0xf9fda0: LeaveFrame
    //     0xf9fda0: mov             SP, fp
    //     0xf9fda4: ldp             fp, lr, [SP], #0x10
    // 0xf9fda8: ret
    //     0xf9fda8: ret             
    // 0xf9fdac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf9fdac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5723, size: 0x20, field offset: 0x1c
class _LinearProgressIndicatorState extends _MixinApplication91&State&SingleTickerProviderStateMixin {

  late final AnimationController _internalController; // offset: 0x1c

  _ build(/* No info */) {
    // ** addr: 0xd304dc, size: 0x120
    // 0xd304dc: EnterFrame
    //     0xd304dc: stp             fp, lr, [SP, #-0x10]!
    //     0xd304e0: mov             fp, SP
    // 0xd304e4: AllocStack(0x20)
    //     0xd304e4: sub             SP, SP, #0x20
    // 0xd304e8: SetupParameters(_LinearProgressIndicatorState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd304e8: mov             x0, x1
    //     0xd304ec: stur            x1, [fp, #-8]
    //     0xd304f0: mov             x1, x2
    //     0xd304f4: stur            x2, [fp, #-0x10]
    // 0xd304f8: CheckStackOverflow
    //     0xd304f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd304fc: cmp             SP, x16
    //     0xd30500: b.ls            #0xd305e8
    // 0xd30504: r1 = 2
    //     0xd30504: mov             x1, #2
    // 0xd30508: r0 = AllocateContext()
    //     0xd30508: bl              #0x13de838  ; AllocateContextStub
    // 0xd3050c: mov             x2, x0
    // 0xd30510: ldur            x0, [fp, #-8]
    // 0xd30514: stur            x2, [fp, #-0x18]
    // 0xd30518: StoreField: r2->field_f = r0
    //     0xd30518: stur            w0, [x2, #0xf]
    // 0xd3051c: ldur            x1, [fp, #-0x10]
    // 0xd30520: r0 = of()
    //     0xd30520: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xd30524: mov             x3, x0
    // 0xd30528: ldur            x2, [fp, #-0x18]
    // 0xd3052c: stur            x3, [fp, #-0x20]
    // 0xd30530: StoreField: r2->field_13 = r0
    //     0xd30530: stur            w0, [x2, #0x13]
    //     0xd30534: ldurb           w16, [x2, #-1]
    //     0xd30538: ldurb           w17, [x0, #-1]
    //     0xd3053c: and             x16, x17, x16, lsr #2
    //     0xd30540: tst             x16, HEAP, lsr #32
    //     0xd30544: b.eq            #0xd3054c
    //     0xd30548: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd3054c: ldur            x0, [fp, #-8]
    // 0xd30550: LoadField: r1 = r0->field_b
    //     0xd30550: ldur            w1, [x0, #0xb]
    // 0xd30554: DecompressPointer r1
    //     0xd30554: add             x1, x1, HEAP, lsl #32
    // 0xd30558: cmp             w1, NULL
    // 0xd3055c: b.eq            #0xd305f0
    // 0xd30560: r0 = _effectiveValue()
    //     0xd30560: bl              #0xd30d4c  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_effectiveValue
    // 0xd30564: cmp             w0, NULL
    // 0xd30568: b.eq            #0xd305a8
    // 0xd3056c: ldur            x1, [fp, #-8]
    // 0xd30570: r0 = _controller()
    //     0xd30570: bl              #0xd30c90  ; [package:flutter/src/material/progress_indicator.dart] _LinearProgressIndicatorState::_controller
    // 0xd30574: LoadField: r1 = r0->field_37
    //     0xd30574: ldur            w1, [x0, #0x37]
    // 0xd30578: DecompressPointer r1
    //     0xd30578: add             x1, x1, HEAP, lsl #32
    // 0xd3057c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd30580: cmp             w1, w16
    // 0xd30584: b.eq            #0xd305f4
    // 0xd30588: LoadField: d0 = r1->field_7
    //     0xd30588: ldur            d0, [x1, #7]
    // 0xd3058c: ldur            x1, [fp, #-8]
    // 0xd30590: ldur            x2, [fp, #-0x10]
    // 0xd30594: ldur            x3, [fp, #-0x20]
    // 0xd30598: r0 = _buildIndicator()
    //     0xd30598: bl              #0xd305fc  ; [package:flutter/src/material/progress_indicator.dart] _LinearProgressIndicatorState::_buildIndicator
    // 0xd3059c: LeaveFrame
    //     0xd3059c: mov             SP, fp
    //     0xd305a0: ldp             fp, lr, [SP], #0x10
    // 0xd305a4: ret
    //     0xd305a4: ret             
    // 0xd305a8: ldur            x1, [fp, #-8]
    // 0xd305ac: r0 = _controller()
    //     0xd305ac: bl              #0xd30c90  ; [package:flutter/src/material/progress_indicator.dart] _LinearProgressIndicatorState::_controller
    // 0xd305b0: ldur            x2, [fp, #-0x18]
    // 0xd305b4: r1 = Function '<anonymous closure>':.
    //     0xd305b4: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1c98] AnonymousClosure: (0xd30dfc), in [package:flutter/src/material/progress_indicator.dart] _LinearProgressIndicatorState::build (0xd304dc)
    //     0xd305b8: ldr             x1, [x1, #0xc98]
    // 0xd305bc: stur            x0, [fp, #-8]
    // 0xd305c0: r0 = AllocateClosure()
    //     0xd305c0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd305c4: stur            x0, [fp, #-0x10]
    // 0xd305c8: r0 = AnimatedBuilder()
    //     0xd305c8: bl              #0x918e2c  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0xd305cc: ldur            x1, [fp, #-0x10]
    // 0xd305d0: StoreField: r0->field_f = r1
    //     0xd305d0: stur            w1, [x0, #0xf]
    // 0xd305d4: ldur            x1, [fp, #-8]
    // 0xd305d8: StoreField: r0->field_b = r1
    //     0xd305d8: stur            w1, [x0, #0xb]
    // 0xd305dc: LeaveFrame
    //     0xd305dc: mov             SP, fp
    //     0xd305e0: ldp             fp, lr, [SP], #0x10
    // 0xd305e4: ret
    //     0xd305e4: ret             
    // 0xd305e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd305e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd305ec: b               #0xd30504
    // 0xd305f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd305f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd305f4: r9 = _value
    //     0xd305f4: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xd305f8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd305f8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildIndicator(/* No info */) {
    // ** addr: 0xd305fc, size: 0x378
    // 0xd305fc: EnterFrame
    //     0xd305fc: stp             fp, lr, [SP, #-0x10]!
    //     0xd30600: mov             fp, SP
    // 0xd30604: AllocStack(0x58)
    //     0xd30604: sub             SP, SP, #0x58
    // 0xd30608: SetupParameters(_LinearProgressIndicatorState this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x48 */)
    //     0xd30608: mov             x0, x2
    //     0xd3060c: stur            x2, [fp, #-0x10]
    //     0xd30610: mov             x2, x1
    //     0xd30614: stur            x1, [fp, #-8]
    //     0xd30618: stur            x3, [fp, #-0x18]
    //     0xd3061c: stur            d0, [fp, #-0x48]
    // 0xd30620: CheckStackOverflow
    //     0xd30620: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd30624: cmp             SP, x16
    //     0xd30628: b.ls            #0xd30950
    // 0xd3062c: mov             x1, x0
    // 0xd30630: r0 = of()
    //     0xd30630: bl              #0xd30c34  ; [package:flutter/src/material/progress_indicator_theme.dart] ProgressIndicatorTheme::of
    // 0xd30634: mov             x2, x0
    // 0xd30638: ldur            x0, [fp, #-8]
    // 0xd3063c: stur            x2, [fp, #-0x20]
    // 0xd30640: LoadField: r1 = r0->field_b
    //     0xd30640: ldur            w1, [x0, #0xb]
    // 0xd30644: DecompressPointer r1
    //     0xd30644: add             x1, x1, HEAP, lsl #32
    // 0xd30648: cmp             w1, NULL
    // 0xd3064c: b.eq            #0xd30958
    // 0xd30650: ldur            x1, [fp, #-0x10]
    // 0xd30654: r0 = of()
    //     0xd30654: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd30658: LoadField: r1 = r0->field_2f
    //     0xd30658: ldur            w1, [x0, #0x2f]
    // 0xd3065c: DecompressPointer r1
    //     0xd3065c: add             x1, x1, HEAP, lsl #32
    // 0xd30660: tbnz            w1, #4, #0xd30688
    // 0xd30664: ldur            x2, [fp, #-0x10]
    // 0xd30668: r0 = _LinearProgressIndicatorDefaultsM3Year2023()
    //     0xd30668: bl              #0xd30c28  ; Allocate_LinearProgressIndicatorDefaultsM3Year2023Stub -> _LinearProgressIndicatorDefaultsM3Year2023 (size=0x50)
    // 0xd3066c: mov             x1, x0
    // 0xd30670: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd30674: StoreField: r1->field_4b = r0
    //     0xd30674: stur            w0, [x1, #0x4b]
    // 0xd30678: ldur            x2, [fp, #-0x10]
    // 0xd3067c: StoreField: r1->field_47 = r2
    //     0xd3067c: stur            w2, [x1, #0x47]
    // 0xd30680: mov             x4, x1
    // 0xd30684: b               #0xd306ac
    // 0xd30688: ldur            x2, [fp, #-0x10]
    // 0xd3068c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd30690: r0 = _LinearProgressIndicatorDefaultsM2()
    //     0xd30690: bl              #0xd30c1c  ; Allocate_LinearProgressIndicatorDefaultsM2Stub -> _LinearProgressIndicatorDefaultsM2 (size=0x50)
    // 0xd30694: mov             x1, x0
    // 0xd30698: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3069c: StoreField: r1->field_4b = r0
    //     0xd3069c: stur            w0, [x1, #0x4b]
    // 0xd306a0: ldur            x2, [fp, #-0x10]
    // 0xd306a4: StoreField: r1->field_47 = r2
    //     0xd306a4: stur            w2, [x1, #0x47]
    // 0xd306a8: mov             x4, x1
    // 0xd306ac: ldur            x3, [fp, #-8]
    // 0xd306b0: stur            x4, [fp, #-0x28]
    // 0xd306b4: LoadField: r0 = r3->field_b
    //     0xd306b4: ldur            w0, [x3, #0xb]
    // 0xd306b8: DecompressPointer r0
    //     0xd306b8: add             x0, x0, HEAP, lsl #32
    // 0xd306bc: cmp             w0, NULL
    // 0xd306c0: b.eq            #0xd3095c
    // 0xd306c4: LoadField: r1 = r0->field_f
    //     0xd306c4: ldur            w1, [x0, #0xf]
    // 0xd306c8: DecompressPointer r1
    //     0xd306c8: add             x1, x1, HEAP, lsl #32
    // 0xd306cc: cmp             w1, NULL
    // 0xd306d0: b.ne            #0xd306dc
    // 0xd306d4: r0 = Null
    //     0xd306d4: mov             x0, NULL
    // 0xd306d8: b               #0xd306e0
    // 0xd306dc: mov             x0, x1
    // 0xd306e0: cmp             w0, NULL
    // 0xd306e4: b.ne            #0xd3070c
    // 0xd306e8: r0 = LoadClassIdInstr(r4)
    //     0xd306e8: ldur            x0, [x4, #-1]
    //     0xd306ec: ubfx            x0, x0, #0xc, #0x14
    // 0xd306f0: mov             x1, x4
    // 0xd306f4: r0 = GDT[cid_x0 + 0x1458]()
    //     0xd306f4: mov             x17, #0x1458
    //     0xd306f8: add             lr, x0, x17
    //     0xd306fc: ldr             lr, [x21, lr, lsl #3]
    //     0xd30700: blr             lr
    // 0xd30704: mov             x4, x0
    // 0xd30708: b               #0xd30710
    // 0xd3070c: mov             x4, x0
    // 0xd30710: ldur            x2, [fp, #-8]
    // 0xd30714: ldur            x3, [fp, #-0x20]
    // 0xd30718: stur            x4, [fp, #-0x30]
    // 0xd3071c: LoadField: r0 = r2->field_b
    //     0xd3071c: ldur            w0, [x2, #0xb]
    // 0xd30720: DecompressPointer r0
    //     0xd30720: add             x0, x0, HEAP, lsl #32
    // 0xd30724: cmp             w0, NULL
    // 0xd30728: b.eq            #0xd30960
    // 0xd3072c: LoadField: r0 = r3->field_f
    //     0xd3072c: ldur            w0, [x3, #0xf]
    // 0xd30730: DecompressPointer r0
    //     0xd30730: add             x0, x0, HEAP, lsl #32
    // 0xd30734: cmp             w0, NULL
    // 0xd30738: b.ne            #0xd30764
    // 0xd3073c: ldur            x5, [fp, #-0x28]
    // 0xd30740: r0 = LoadClassIdInstr(r5)
    //     0xd30740: ldur            x0, [x5, #-1]
    //     0xd30744: ubfx            x0, x0, #0xc, #0x14
    // 0xd30748: mov             x1, x5
    // 0xd3074c: r0 = GDT[cid_x0 + 0x167f]()
    //     0xd3074c: mov             x17, #0x167f
    //     0xd30750: add             lr, x0, x17
    //     0xd30754: ldr             lr, [x21, lr, lsl #3]
    //     0xd30758: blr             lr
    // 0xd3075c: d0 = 4.000000
    //     0xd3075c: fmov            d0, #4.00000000
    // 0xd30760: b               #0xd30768
    // 0xd30764: LoadField: d0 = r0->field_7
    //     0xd30764: ldur            d0, [x0, #7]
    // 0xd30768: ldur            x0, [fp, #-8]
    // 0xd3076c: ldur            x1, [fp, #-0x20]
    // 0xd30770: stur            d0, [fp, #-0x50]
    // 0xd30774: LoadField: r2 = r0->field_b
    //     0xd30774: ldur            w2, [x0, #0xb]
    // 0xd30778: DecompressPointer r2
    //     0xd30778: add             x2, x2, HEAP, lsl #32
    // 0xd3077c: stur            x2, [fp, #-0x38]
    // 0xd30780: cmp             w2, NULL
    // 0xd30784: b.eq            #0xd30964
    // 0xd30788: LoadField: r3 = r1->field_1b
    //     0xd30788: ldur            w3, [x1, #0x1b]
    // 0xd3078c: DecompressPointer r3
    //     0xd3078c: add             x3, x3, HEAP, lsl #32
    // 0xd30790: cmp             w3, NULL
    // 0xd30794: b.ne            #0xd307ac
    // 0xd30798: ldur            x1, [fp, #-0x28]
    // 0xd3079c: LoadField: r3 = r1->field_1b
    //     0xd3079c: ldur            w3, [x1, #0x1b]
    // 0xd307a0: DecompressPointer r3
    //     0xd307a0: add             x3, x3, HEAP, lsl #32
    // 0xd307a4: mov             x5, x3
    // 0xd307a8: b               #0xd307b4
    // 0xd307ac: ldur            x1, [fp, #-0x28]
    // 0xd307b0: mov             x5, x3
    // 0xd307b4: ldur            d1, [fp, #-0x48]
    // 0xd307b8: ldur            x4, [fp, #-0x18]
    // 0xd307bc: ldur            x3, [fp, #-0x30]
    // 0xd307c0: stur            x5, [fp, #-0x20]
    // 0xd307c4: r0 = BoxConstraints()
    //     0xd307c4: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xd307c8: mov             x2, x0
    // 0xd307cc: d0 = inf
    //     0xd307cc: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xd307d0: stur            x2, [fp, #-0x40]
    // 0xd307d4: StoreField: r2->field_7 = d0
    //     0xd307d4: stur            d0, [x2, #7]
    // 0xd307d8: StoreField: r2->field_f = d0
    //     0xd307d8: stur            d0, [x2, #0xf]
    // 0xd307dc: ldur            d1, [fp, #-0x50]
    // 0xd307e0: ArrayStore: r2[0] = d1  ; List_8
    //     0xd307e0: stur            d1, [x2, #0x17]
    // 0xd307e4: StoreField: r2->field_1f = d0
    //     0xd307e4: stur            d0, [x2, #0x1f]
    // 0xd307e8: ldur            x1, [fp, #-0x28]
    // 0xd307ec: r0 = LoadClassIdInstr(r1)
    //     0xd307ec: ldur            x0, [x1, #-1]
    //     0xd307f0: ubfx            x0, x0, #0xc, #0x14
    // 0xd307f4: r0 = GDT[cid_x0 + 0xec6]()
    //     0xd307f4: add             lr, x0, #0xec6
    //     0xd307f8: ldr             lr, [x21, lr, lsl #3]
    //     0xd307fc: blr             lr
    // 0xd30800: str             x0, [SP]
    // 0xd30804: ldur            x1, [fp, #-0x38]
    // 0xd30808: ldur            x2, [fp, #-0x10]
    // 0xd3080c: r4 = const [0, 0x3, 0x1, 0x2, defaultColor, 0x2, null]
    //     0xd3080c: add             x4, PP, #0x8f, lsl #12  ; [pp+0x8fb70] List(7) [0, 0x3, 0x1, 0x2, "defaultColor", 0x2, Null]
    //     0xd30810: ldr             x4, [x4, #0xb70]
    // 0xd30814: r0 = _getValueColor()
    //     0xd30814: bl              #0xd30b14  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_getValueColor
    // 0xd30818: mov             x2, x0
    // 0xd3081c: ldur            x0, [fp, #-8]
    // 0xd30820: stur            x2, [fp, #-0x10]
    // 0xd30824: LoadField: r1 = r0->field_b
    //     0xd30824: ldur            w1, [x0, #0xb]
    // 0xd30828: DecompressPointer r1
    //     0xd30828: add             x1, x1, HEAP, lsl #32
    // 0xd3082c: cmp             w1, NULL
    // 0xd30830: b.eq            #0xd30968
    // 0xd30834: r0 = _effectiveValue()
    //     0xd30834: bl              #0xd30d4c  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_effectiveValue
    // 0xd30838: stur            x0, [fp, #-0x28]
    // 0xd3083c: r0 = _LinearProgressIndicatorPainter()
    //     0xd3083c: bl              #0xd30b08  ; Allocate_LinearProgressIndicatorPainterStub -> _LinearProgressIndicatorPainter (size=0x34)
    // 0xd30840: mov             x1, x0
    // 0xd30844: ldur            x0, [fp, #-0x30]
    // 0xd30848: stur            x1, [fp, #-0x38]
    // 0xd3084c: StoreField: r1->field_b = r0
    //     0xd3084c: stur            w0, [x1, #0xb]
    // 0xd30850: ldur            x0, [fp, #-0x10]
    // 0xd30854: StoreField: r1->field_f = r0
    //     0xd30854: stur            w0, [x1, #0xf]
    // 0xd30858: ldur            x0, [fp, #-0x28]
    // 0xd3085c: StoreField: r1->field_13 = r0
    //     0xd3085c: stur            w0, [x1, #0x13]
    // 0xd30860: ldur            d0, [fp, #-0x48]
    // 0xd30864: ArrayStore: r1[0] = d0  ; List_8
    //     0xd30864: stur            d0, [x1, #0x17]
    // 0xd30868: ldur            x0, [fp, #-0x18]
    // 0xd3086c: StoreField: r1->field_1f = r0
    //     0xd3086c: stur            w0, [x1, #0x1f]
    // 0xd30870: ldur            x0, [fp, #-0x20]
    // 0xd30874: StoreField: r1->field_23 = r0
    //     0xd30874: stur            w0, [x1, #0x23]
    // 0xd30878: r0 = CustomPaint()
    //     0xd30878: bl              #0xd0a594  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0xd3087c: mov             x1, x0
    // 0xd30880: ldur            x0, [fp, #-0x38]
    // 0xd30884: stur            x1, [fp, #-0x10]
    // 0xd30888: StoreField: r1->field_f = r0
    //     0xd30888: stur            w0, [x1, #0xf]
    // 0xd3088c: r0 = Instance_Size
    //     0xd3088c: ldr             x0, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xd30890: ArrayStore: r1[0] = r0  ; List_4
    //     0xd30890: stur            w0, [x1, #0x17]
    // 0xd30894: r0 = false
    //     0xd30894: add             x0, NULL, #0x30  ; false
    // 0xd30898: StoreField: r1->field_1b = r0
    //     0xd30898: stur            w0, [x1, #0x1b]
    // 0xd3089c: StoreField: r1->field_1f = r0
    //     0xd3089c: stur            w0, [x1, #0x1f]
    // 0xd308a0: r0 = ConstrainedBox()
    //     0xd308a0: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xd308a4: mov             x2, x0
    // 0xd308a8: ldur            x0, [fp, #-0x40]
    // 0xd308ac: stur            x2, [fp, #-0x18]
    // 0xd308b0: StoreField: r2->field_f = r0
    //     0xd308b0: stur            w0, [x2, #0xf]
    // 0xd308b4: ldur            x0, [fp, #-0x10]
    // 0xd308b8: StoreField: r2->field_b = r0
    //     0xd308b8: stur            w0, [x2, #0xb]
    // 0xd308bc: ldur            x0, [fp, #-0x20]
    // 0xd308c0: cmp             w0, NULL
    // 0xd308c4: b.eq            #0xd30924
    // 0xd308c8: ldur            x3, [fp, #-8]
    // 0xd308cc: LoadField: r1 = r3->field_b
    //     0xd308cc: ldur            w1, [x3, #0xb]
    // 0xd308d0: DecompressPointer r1
    //     0xd308d0: add             x1, x1, HEAP, lsl #32
    // 0xd308d4: cmp             w1, NULL
    // 0xd308d8: b.eq            #0xd3096c
    // 0xd308dc: r0 = _effectiveValue()
    //     0xd308dc: bl              #0xd30d4c  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_effectiveValue
    // 0xd308e0: cmp             w0, NULL
    // 0xd308e4: b.ne            #0xd3091c
    // 0xd308e8: ldur            x1, [fp, #-0x20]
    // 0xd308ec: ldur            x0, [fp, #-0x18]
    // 0xd308f0: r0 = ClipRRect()
    //     0xd308f0: bl              #0xd30168  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0xd308f4: mov             x1, x0
    // 0xd308f8: ldur            x0, [fp, #-0x20]
    // 0xd308fc: StoreField: r1->field_f = r0
    //     0xd308fc: stur            w0, [x1, #0xf]
    // 0xd30900: r0 = Instance_Clip
    //     0xd30900: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e6f0] Obj!Clip@12c8101
    //     0xd30904: ldr             x0, [x0, #0x6f0]
    // 0xd30908: ArrayStore: r1[0] = r0  ; List_4
    //     0xd30908: stur            w0, [x1, #0x17]
    // 0xd3090c: ldur            x0, [fp, #-0x18]
    // 0xd30910: StoreField: r1->field_b = r0
    //     0xd30910: stur            w0, [x1, #0xb]
    // 0xd30914: mov             x2, x1
    // 0xd30918: b               #0xd3092c
    // 0xd3091c: ldur            x0, [fp, #-0x18]
    // 0xd30920: b               #0xd30928
    // 0xd30924: mov             x0, x2
    // 0xd30928: mov             x2, x0
    // 0xd3092c: ldur            x0, [fp, #-8]
    // 0xd30930: LoadField: r1 = r0->field_b
    //     0xd30930: ldur            w1, [x0, #0xb]
    // 0xd30934: DecompressPointer r1
    //     0xd30934: add             x1, x1, HEAP, lsl #32
    // 0xd30938: cmp             w1, NULL
    // 0xd3093c: b.eq            #0xd30970
    // 0xd30940: r0 = _buildSemanticsWrapper()
    //     0xd30940: bl              #0xd30974  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_buildSemanticsWrapper
    // 0xd30944: LeaveFrame
    //     0xd30944: mov             SP, fp
    //     0xd30948: ldp             fp, lr, [SP], #0x10
    // 0xd3094c: ret
    //     0xd3094c: ret             
    // 0xd30950: r0 = StackOverflowSharedWithFPURegs()
    //     0xd30950: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd30954: b               #0xd3062c
    // 0xd30958: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd30958: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3095c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3095c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd30960: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd30960: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd30964: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd30964: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd30968: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd30968: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3096c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3096c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd30970: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd30970: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _controller(/* No info */) {
    // ** addr: 0xd30c90, size: 0xbc
    // 0xd30c90: EnterFrame
    //     0xd30c90: stp             fp, lr, [SP, #-0x10]!
    //     0xd30c94: mov             fp, SP
    // 0xd30c98: AllocStack(0x18)
    //     0xd30c98: sub             SP, SP, #0x18
    // 0xd30c9c: SetupParameters(_LinearProgressIndicatorState this /* r1 => r1, fp-0x8 */)
    //     0xd30c9c: stur            x1, [fp, #-8]
    // 0xd30ca0: CheckStackOverflow
    //     0xd30ca0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd30ca4: cmp             SP, x16
    //     0xd30ca8: b.ls            #0xd30d2c
    // 0xd30cac: LoadField: r0 = r1->field_b
    //     0xd30cac: ldur            w0, [x1, #0xb]
    // 0xd30cb0: DecompressPointer r0
    //     0xd30cb0: add             x0, x0, HEAP, lsl #32
    // 0xd30cb4: cmp             w0, NULL
    // 0xd30cb8: b.eq            #0xd30d34
    // 0xd30cbc: LoadField: r0 = r1->field_f
    //     0xd30cbc: ldur            w0, [x1, #0xf]
    // 0xd30cc0: DecompressPointer r0
    //     0xd30cc0: add             x0, x0, HEAP, lsl #32
    // 0xd30cc4: cmp             w0, NULL
    // 0xd30cc8: b.eq            #0xd30d38
    // 0xd30ccc: r16 = <ProgressIndicatorTheme>
    //     0xd30ccc: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fb58] TypeArguments: <ProgressIndicatorTheme>
    //     0xd30cd0: ldr             x16, [x16, #0xb58]
    // 0xd30cd4: stp             x0, x16, [SP]
    // 0xd30cd8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd30cd8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd30cdc: r0 = getInheritedWidgetOfExactType()
    //     0xd30cdc: bl              #0x843618  ; [package:flutter/src/widgets/framework.dart] Element::getInheritedWidgetOfExactType
    // 0xd30ce0: ldur            x0, [fp, #-8]
    // 0xd30ce4: LoadField: r1 = r0->field_f
    //     0xd30ce4: ldur            w1, [x0, #0xf]
    // 0xd30ce8: DecompressPointer r1
    //     0xd30ce8: add             x1, x1, HEAP, lsl #32
    // 0xd30cec: cmp             w1, NULL
    // 0xd30cf0: b.eq            #0xd30d3c
    // 0xd30cf4: r16 = <Theme>
    //     0xd30cf4: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fb60] TypeArguments: <Theme>
    //     0xd30cf8: ldr             x16, [x16, #0xb60]
    // 0xd30cfc: stp             x1, x16, [SP]
    // 0xd30d00: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd30d00: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd30d04: r0 = findAncestorWidgetOfExactType()
    //     0xd30d04: bl              #0x86c300  ; [package:flutter/src/widgets/framework.dart] Element::findAncestorWidgetOfExactType
    // 0xd30d08: ldur            x1, [fp, #-8]
    // 0xd30d0c: LoadField: r0 = r1->field_1b
    //     0xd30d0c: ldur            w0, [x1, #0x1b]
    // 0xd30d10: DecompressPointer r0
    //     0xd30d10: add             x0, x0, HEAP, lsl #32
    // 0xd30d14: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd30d18: cmp             w0, w16
    // 0xd30d1c: b.eq            #0xd30d40
    // 0xd30d20: LeaveFrame
    //     0xd30d20: mov             SP, fp
    //     0xd30d24: ldp             fp, lr, [SP], #0x10
    // 0xd30d28: ret
    //     0xd30d28: ret             
    // 0xd30d2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd30d2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd30d30: b               #0xd30cac
    // 0xd30d34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd30d34: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd30d38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd30d38: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd30d3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd30d3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd30d40: r9 = _internalController
    //     0xd30d40: add             x9, PP, #0xd1, lsl #12  ; [pp+0xd1ca0] Field <_LinearProgressIndicatorState@115243954._internalController@115243954>: late final (offset: 0x1c)
    //     0xd30d44: ldr             x9, [x9, #0xca0]
    // 0xd30d48: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd30d48: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0xd30dfc, size: 0x88
    // 0xd30dfc: EnterFrame
    //     0xd30dfc: stp             fp, lr, [SP, #-0x10]!
    //     0xd30e00: mov             fp, SP
    // 0xd30e04: AllocStack(0x10)
    //     0xd30e04: sub             SP, SP, #0x10
    // 0xd30e08: SetupParameters([dynamic _ /* r0 */])
    //     0xd30e08: ldr             x0, [fp, #0x20]
    //     0xd30e0c: ldur            w2, [x0, #0x17]
    //     0xd30e10: add             x2, x2, HEAP, lsl #32
    //     0xd30e14: stur            x2, [fp, #-0x10]
    // 0xd30e18: CheckStackOverflow
    //     0xd30e18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd30e1c: cmp             SP, x16
    //     0xd30e20: b.ls            #0xd30e74
    // 0xd30e24: LoadField: r0 = r2->field_f
    //     0xd30e24: ldur            w0, [x2, #0xf]
    // 0xd30e28: DecompressPointer r0
    //     0xd30e28: add             x0, x0, HEAP, lsl #32
    // 0xd30e2c: mov             x1, x0
    // 0xd30e30: stur            x0, [fp, #-8]
    // 0xd30e34: r0 = _controller()
    //     0xd30e34: bl              #0xd30c90  ; [package:flutter/src/material/progress_indicator.dart] _LinearProgressIndicatorState::_controller
    // 0xd30e38: LoadField: r1 = r0->field_37
    //     0xd30e38: ldur            w1, [x0, #0x37]
    // 0xd30e3c: DecompressPointer r1
    //     0xd30e3c: add             x1, x1, HEAP, lsl #32
    // 0xd30e40: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd30e44: cmp             w1, w16
    // 0xd30e48: b.eq            #0xd30e7c
    // 0xd30e4c: ldur            x0, [fp, #-0x10]
    // 0xd30e50: LoadField: r3 = r0->field_13
    //     0xd30e50: ldur            w3, [x0, #0x13]
    // 0xd30e54: DecompressPointer r3
    //     0xd30e54: add             x3, x3, HEAP, lsl #32
    // 0xd30e58: LoadField: d0 = r1->field_7
    //     0xd30e58: ldur            d0, [x1, #7]
    // 0xd30e5c: ldur            x1, [fp, #-8]
    // 0xd30e60: ldr             x2, [fp, #0x18]
    // 0xd30e64: r0 = _buildIndicator()
    //     0xd30e64: bl              #0xd305fc  ; [package:flutter/src/material/progress_indicator.dart] _LinearProgressIndicatorState::_buildIndicator
    // 0xd30e68: LeaveFrame
    //     0xd30e68: mov             SP, fp
    //     0xd30e6c: ldp             fp, lr, [SP], #0x10
    // 0xd30e70: ret
    //     0xd30e70: ret             
    // 0xd30e74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd30e74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd30e78: b               #0xd30e24
    // 0xd30e7c: r9 = _value
    //     0xd30e7c: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xd30e80: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd30e80: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf3bbb0, size: 0xc0
    // 0xf3bbb0: EnterFrame
    //     0xf3bbb0: stp             fp, lr, [SP, #-0x10]!
    //     0xf3bbb4: mov             fp, SP
    // 0xf3bbb8: AllocStack(0x10)
    //     0xf3bbb8: sub             SP, SP, #0x10
    // 0xf3bbbc: SetupParameters(_LinearProgressIndicatorState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf3bbbc: mov             x4, x1
    //     0xf3bbc0: mov             x3, x2
    //     0xf3bbc4: stur            x1, [fp, #-8]
    //     0xf3bbc8: stur            x2, [fp, #-0x10]
    // 0xf3bbcc: CheckStackOverflow
    //     0xf3bbcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3bbd0: cmp             SP, x16
    //     0xf3bbd4: b.ls            #0xf3bc68
    // 0xf3bbd8: mov             x0, x3
    // 0xf3bbdc: r2 = Null
    //     0xf3bbdc: mov             x2, NULL
    // 0xf3bbe0: r1 = Null
    //     0xf3bbe0: mov             x1, NULL
    // 0xf3bbe4: r4 = 60
    //     0xf3bbe4: mov             x4, #0x3c
    // 0xf3bbe8: branchIfSmi(r0, 0xf3bbf4)
    //     0xf3bbe8: tbz             w0, #0, #0xf3bbf4
    // 0xf3bbec: r4 = LoadClassIdInstr(r0)
    //     0xf3bbec: ldur            x4, [x0, #-1]
    //     0xf3bbf0: ubfx            x4, x4, #0xc, #0x14
    // 0xf3bbf4: r17 = 6447
    //     0xf3bbf4: mov             x17, #0x192f
    // 0xf3bbf8: cmp             x4, x17
    // 0xf3bbfc: b.eq            #0xf3bc14
    // 0xf3bc00: r8 = LinearProgressIndicator
    //     0xf3bc00: add             x8, PP, #0xd1, lsl #12  ; [pp+0xd1ca8] Type: LinearProgressIndicator
    //     0xf3bc04: ldr             x8, [x8, #0xca8]
    // 0xf3bc08: r3 = Null
    //     0xf3bc08: add             x3, PP, #0xd1, lsl #12  ; [pp+0xd1cb0] Null
    //     0xf3bc0c: ldr             x3, [x3, #0xcb0]
    // 0xf3bc10: r0 = LinearProgressIndicator()
    //     0xf3bc10: bl              #0xacf7e0  ; IsType_LinearProgressIndicator_Stub
    // 0xf3bc14: ldur            x3, [fp, #-8]
    // 0xf3bc18: LoadField: r2 = r3->field_7
    //     0xf3bc18: ldur            w2, [x3, #7]
    // 0xf3bc1c: DecompressPointer r2
    //     0xf3bc1c: add             x2, x2, HEAP, lsl #32
    // 0xf3bc20: ldur            x0, [fp, #-0x10]
    // 0xf3bc24: r1 = Null
    //     0xf3bc24: mov             x1, NULL
    // 0xf3bc28: cmp             w2, NULL
    // 0xf3bc2c: b.eq            #0xf3bc50
    // 0xf3bc30: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf3bc30: ldur            w4, [x2, #0x17]
    // 0xf3bc34: DecompressPointer r4
    //     0xf3bc34: add             x4, x4, HEAP, lsl #32
    // 0xf3bc38: r8 = X0 bound StatefulWidget
    //     0xf3bc38: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf3bc3c: ldr             x8, [x8, #0x498]
    // 0xf3bc40: LoadField: r9 = r4->field_7
    //     0xf3bc40: ldur            x9, [x4, #7]
    // 0xf3bc44: r3 = Null
    //     0xf3bc44: add             x3, PP, #0xd1, lsl #12  ; [pp+0xd1cc0] Null
    //     0xf3bc48: ldr             x3, [x3, #0xcc0]
    // 0xf3bc4c: blr             x9
    // 0xf3bc50: ldur            x1, [fp, #-8]
    // 0xf3bc54: r0 = _updateControllerAnimatingStatus()
    //     0xf3bc54: bl              #0xf3bc70  ; [package:flutter/src/material/progress_indicator.dart] _LinearProgressIndicatorState::_updateControllerAnimatingStatus
    // 0xf3bc58: r0 = Null
    //     0xf3bc58: mov             x0, NULL
    // 0xf3bc5c: LeaveFrame
    //     0xf3bc5c: mov             SP, fp
    //     0xf3bc60: ldp             fp, lr, [SP], #0x10
    // 0xf3bc64: ret
    //     0xf3bc64: ret             
    // 0xf3bc68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3bc68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3bc6c: b               #0xf3bbd8
  }
  _ _updateControllerAnimatingStatus(/* No info */) {
    // ** addr: 0xf3bc70, size: 0x118
    // 0xf3bc70: EnterFrame
    //     0xf3bc70: stp             fp, lr, [SP, #-0x10]!
    //     0xf3bc74: mov             fp, SP
    // 0xf3bc78: AllocStack(0x8)
    //     0xf3bc78: sub             SP, SP, #8
    // 0xf3bc7c: SetupParameters(_LinearProgressIndicatorState this /* r1 => r0, fp-0x8 */)
    //     0xf3bc7c: mov             x0, x1
    //     0xf3bc80: stur            x1, [fp, #-8]
    // 0xf3bc84: CheckStackOverflow
    //     0xf3bc84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3bc88: cmp             SP, x16
    //     0xf3bc8c: b.ls            #0xf3bd60
    // 0xf3bc90: LoadField: r1 = r0->field_b
    //     0xf3bc90: ldur            w1, [x0, #0xb]
    // 0xf3bc94: DecompressPointer r1
    //     0xf3bc94: add             x1, x1, HEAP, lsl #32
    // 0xf3bc98: cmp             w1, NULL
    // 0xf3bc9c: b.eq            #0xf3bd68
    // 0xf3bca0: r0 = _effectiveValue()
    //     0xf3bca0: bl              #0xd30d4c  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_effectiveValue
    // 0xf3bca4: cmp             w0, NULL
    // 0xf3bca8: b.ne            #0xf3bcf0
    // 0xf3bcac: ldur            x0, [fp, #-8]
    // 0xf3bcb0: LoadField: r1 = r0->field_1b
    //     0xf3bcb0: ldur            w1, [x0, #0x1b]
    // 0xf3bcb4: DecompressPointer r1
    //     0xf3bcb4: add             x1, x1, HEAP, lsl #32
    // 0xf3bcb8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3bcbc: cmp             w1, w16
    // 0xf3bcc0: b.eq            #0xf3bd6c
    // 0xf3bcc4: LoadField: r2 = r1->field_2f
    //     0xf3bcc4: ldur            w2, [x1, #0x2f]
    // 0xf3bcc8: DecompressPointer r2
    //     0xf3bcc8: add             x2, x2, HEAP, lsl #32
    // 0xf3bccc: cmp             w2, NULL
    // 0xf3bcd0: b.eq            #0xf3bce4
    // 0xf3bcd4: LoadField: r3 = r2->field_7
    //     0xf3bcd4: ldur            w3, [x2, #7]
    // 0xf3bcd8: DecompressPointer r3
    //     0xf3bcd8: add             x3, x3, HEAP, lsl #32
    // 0xf3bcdc: cmp             w3, NULL
    // 0xf3bce0: b.ne            #0xf3bcf4
    // 0xf3bce4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf3bce4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf3bce8: r0 = repeat()
    //     0xf3bce8: bl              #0xf3bd88  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0xf3bcec: b               #0xf3bd50
    // 0xf3bcf0: ldur            x0, [fp, #-8]
    // 0xf3bcf4: LoadField: r1 = r0->field_b
    //     0xf3bcf4: ldur            w1, [x0, #0xb]
    // 0xf3bcf8: DecompressPointer r1
    //     0xf3bcf8: add             x1, x1, HEAP, lsl #32
    // 0xf3bcfc: cmp             w1, NULL
    // 0xf3bd00: b.eq            #0xf3bd78
    // 0xf3bd04: r0 = _effectiveValue()
    //     0xf3bd04: bl              #0xd30d4c  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_effectiveValue
    // 0xf3bd08: cmp             w0, NULL
    // 0xf3bd0c: b.eq            #0xf3bd50
    // 0xf3bd10: ldur            x0, [fp, #-8]
    // 0xf3bd14: LoadField: r1 = r0->field_1b
    //     0xf3bd14: ldur            w1, [x0, #0x1b]
    // 0xf3bd18: DecompressPointer r1
    //     0xf3bd18: add             x1, x1, HEAP, lsl #32
    // 0xf3bd1c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3bd20: cmp             w1, w16
    // 0xf3bd24: b.eq            #0xf3bd7c
    // 0xf3bd28: LoadField: r0 = r1->field_2f
    //     0xf3bd28: ldur            w0, [x1, #0x2f]
    // 0xf3bd2c: DecompressPointer r0
    //     0xf3bd2c: add             x0, x0, HEAP, lsl #32
    // 0xf3bd30: cmp             w0, NULL
    // 0xf3bd34: b.eq            #0xf3bd50
    // 0xf3bd38: LoadField: r2 = r0->field_7
    //     0xf3bd38: ldur            w2, [x0, #7]
    // 0xf3bd3c: DecompressPointer r2
    //     0xf3bd3c: add             x2, x2, HEAP, lsl #32
    // 0xf3bd40: cmp             w2, NULL
    // 0xf3bd44: b.eq            #0xf3bd50
    // 0xf3bd48: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf3bd48: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf3bd4c: r0 = stop()
    //     0xf3bd4c: bl              #0x82eb24  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0xf3bd50: r0 = Null
    //     0xf3bd50: mov             x0, NULL
    // 0xf3bd54: LeaveFrame
    //     0xf3bd54: mov             SP, fp
    //     0xf3bd58: ldp             fp, lr, [SP], #0x10
    // 0xf3bd5c: ret
    //     0xf3bd5c: ret             
    // 0xf3bd60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3bd60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3bd64: b               #0xf3bc90
    // 0xf3bd68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3bd68: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3bd6c: r9 = _internalController
    //     0xf3bd6c: add             x9, PP, #0xd1, lsl #12  ; [pp+0xd1ca0] Field <_LinearProgressIndicatorState@115243954._internalController@115243954>: late final (offset: 0x1c)
    //     0xf3bd70: ldr             x9, [x9, #0xca0]
    // 0xf3bd74: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3bd74: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf3bd78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3bd78: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3bd7c: r9 = _internalController
    //     0xf3bd7c: add             x9, PP, #0xd1, lsl #12  ; [pp+0xd1ca0] Field <_LinearProgressIndicatorState@115243954._internalController@115243954>: late final (offset: 0x1c)
    //     0xf3bd80: ldr             x9, [x9, #0xca0]
    // 0xf3bd84: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3bd84: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf7af7c, size: 0xb4
    // 0xf7af7c: EnterFrame
    //     0xf7af7c: stp             fp, lr, [SP, #-0x10]!
    //     0xf7af80: mov             fp, SP
    // 0xf7af84: AllocStack(0x18)
    //     0xf7af84: sub             SP, SP, #0x18
    // 0xf7af88: SetupParameters(_LinearProgressIndicatorState this /* r1 => r2, fp-0x8 */)
    //     0xf7af88: mov             x2, x1
    //     0xf7af8c: stur            x1, [fp, #-8]
    // 0xf7af90: CheckStackOverflow
    //     0xf7af90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7af94: cmp             SP, x16
    //     0xf7af98: b.ls            #0xf7b028
    // 0xf7af9c: r1 = <double>
    //     0xf7af9c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf7afa0: r0 = AnimationController()
    //     0xf7afa0: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf7afa4: stur            x0, [fp, #-0x10]
    // 0xf7afa8: r16 = Instance_Duration
    //     0xf7afa8: add             x16, PP, #0x94, lsl #12  ; [pp+0x94c08] Obj!Duration@12c8b61
    //     0xf7afac: ldr             x16, [x16, #0xc08]
    // 0xf7afb0: str             x16, [SP]
    // 0xf7afb4: mov             x1, x0
    // 0xf7afb8: ldur            x2, [fp, #-8]
    // 0xf7afbc: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xf7afbc: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xf7afc0: ldr             x4, [x4, #0x5a0]
    // 0xf7afc4: r0 = AnimationController()
    //     0xf7afc4: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf7afc8: ldur            x1, [fp, #-8]
    // 0xf7afcc: LoadField: r0 = r1->field_1b
    //     0xf7afcc: ldur            w0, [x1, #0x1b]
    // 0xf7afd0: DecompressPointer r0
    //     0xf7afd0: add             x0, x0, HEAP, lsl #32
    // 0xf7afd4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7afd8: cmp             w0, w16
    // 0xf7afdc: b.ne            #0xf7b014
    // 0xf7afe0: ldur            x0, [fp, #-0x10]
    // 0xf7afe4: StoreField: r1->field_1b = r0
    //     0xf7afe4: stur            w0, [x1, #0x1b]
    //     0xf7afe8: ldurb           w16, [x1, #-1]
    //     0xf7afec: ldurb           w17, [x0, #-1]
    //     0xf7aff0: and             x16, x17, x16, lsr #2
    //     0xf7aff4: tst             x16, HEAP, lsr #32
    //     0xf7aff8: b.eq            #0xf7b000
    //     0xf7affc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf7b000: r0 = _updateControllerAnimatingStatus()
    //     0xf7b000: bl              #0xf3bc70  ; [package:flutter/src/material/progress_indicator.dart] _LinearProgressIndicatorState::_updateControllerAnimatingStatus
    // 0xf7b004: r0 = Null
    //     0xf7b004: mov             x0, NULL
    // 0xf7b008: LeaveFrame
    //     0xf7b008: mov             SP, fp
    //     0xf7b00c: ldp             fp, lr, [SP], #0x10
    // 0xf7b010: ret
    //     0xf7b010: ret             
    // 0xf7b014: r16 = "_internalController@115243954"
    //     0xf7b014: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fc20] "_internalController@115243954"
    //     0xf7b018: ldr             x16, [x16, #0xc20]
    // 0xf7b01c: str             x16, [SP]
    // 0xf7b020: r0 = _throwFieldAlreadyInitialized()
    //     0xf7b020: bl              #0x82b720  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0xf7b024: brk             #0
    // 0xf7b028: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7b028: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7b02c: b               #0xf7af9c
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10dd6a0, size: 0x64
    // 0x10dd6a0: EnterFrame
    //     0x10dd6a0: stp             fp, lr, [SP, #-0x10]!
    //     0x10dd6a4: mov             fp, SP
    // 0x10dd6a8: AllocStack(0x8)
    //     0x10dd6a8: sub             SP, SP, #8
    // 0x10dd6ac: SetupParameters(_LinearProgressIndicatorState this /* r1 => r0, fp-0x8 */)
    //     0x10dd6ac: mov             x0, x1
    //     0x10dd6b0: stur            x1, [fp, #-8]
    // 0x10dd6b4: CheckStackOverflow
    //     0x10dd6b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10dd6b8: cmp             SP, x16
    //     0x10dd6bc: b.ls            #0x10dd6f0
    // 0x10dd6c0: LoadField: r1 = r0->field_1b
    //     0x10dd6c0: ldur            w1, [x0, #0x1b]
    // 0x10dd6c4: DecompressPointer r1
    //     0x10dd6c4: add             x1, x1, HEAP, lsl #32
    // 0x10dd6c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10dd6cc: cmp             w1, w16
    // 0x10dd6d0: b.eq            #0x10dd6f8
    // 0x10dd6d4: r0 = dispose()
    //     0x10dd6d4: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10dd6d8: ldur            x1, [fp, #-8]
    // 0x10dd6dc: r0 = dispose()
    //     0x10dd6dc: bl              #0x10dd704  ; [dart:mixin_deduplication] _MixinApplication91&State&SingleTickerProviderStateMixin::dispose
    // 0x10dd6e0: r0 = Null
    //     0x10dd6e0: mov             x0, NULL
    // 0x10dd6e4: LeaveFrame
    //     0x10dd6e4: mov             SP, fp
    //     0x10dd6e8: ldp             fp, lr, [SP], #0x10
    // 0x10dd6ec: ret
    //     0x10dd6ec: ret             
    // 0x10dd6f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dd6f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dd6f4: b               #0x10dd6c0
    // 0x10dd6f8: r9 = _internalController
    //     0x10dd6f8: add             x9, PP, #0xd1, lsl #12  ; [pp+0xd1ca0] Field <_LinearProgressIndicatorState@115243954._internalController@115243954>: late final (offset: 0x1c)
    //     0x10dd6fc: ldr             x9, [x9, #0xca0]
    // 0x10dd700: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10dd700: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 6444, size: 0x24, field offset: 0xc
//   const constructor, 
abstract class ProgressIndicator extends StatefulWidget {

  _ _buildSemanticsWrapper(/* No info */) {
    // ** addr: 0xd30974, size: 0x194
    // 0xd30974: EnterFrame
    //     0xd30974: stp             fp, lr, [SP, #-0x10]!
    //     0xd30978: mov             fp, SP
    // 0xd3097c: AllocStack(0x68)
    //     0xd3097c: sub             SP, SP, #0x68
    // 0xd30980: SetupParameters(ProgressIndicator this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd30980: mov             x0, x1
    //     0xd30984: stur            x1, [fp, #-8]
    //     0xd30988: stur            x2, [fp, #-0x10]
    // 0xd3098c: CheckStackOverflow
    //     0xd3098c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd30990: cmp             SP, x16
    //     0xd30994: b.ls            #0xd30ae0
    // 0xd30998: LoadField: r1 = r0->field_b
    //     0xd30998: ldur            w1, [x0, #0xb]
    // 0xd3099c: DecompressPointer r1
    //     0xd3099c: add             x1, x1, HEAP, lsl #32
    // 0xd309a0: cmp             w1, NULL
    // 0xd309a4: b.eq            #0xd30a30
    // 0xd309a8: mov             x1, x0
    // 0xd309ac: r0 = _effectiveValue()
    //     0xd309ac: bl              #0xd30d4c  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_effectiveValue
    // 0xd309b0: cmp             w0, NULL
    // 0xd309b4: b.eq            #0xd30ae8
    // 0xd309b8: LoadField: d0 = r0->field_7
    //     0xd309b8: ldur            d0, [x0, #7]
    // 0xd309bc: d1 = 100.000000
    //     0xd309bc: add             x17, PP, #0x13, lsl #12  ; [pp+0x130a8] IMM: double(100) from 0x4059000000000000
    //     0xd309c0: ldr             d1, [x17, #0xa8]
    // 0xd309c4: fmul            d2, d0, d1
    // 0xd309c8: mov             v0.16b, v2.16b
    // 0xd309cc: stp             fp, lr, [SP, #-0x10]!
    // 0xd309d0: mov             fp, SP
    // 0xd309d4: CallRuntime_LibcRound(double) -> double
    //     0xd309d4: and             SP, SP, #0xfffffffffffffff0
    //     0xd309d8: mov             sp, SP
    //     0xd309dc: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0xd309e0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd309e4: blr             x16
    //     0xd309e8: mov             x16, #8
    //     0xd309ec: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd309f0: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xd309f4: sub             sp, x16, #1, lsl #12
    //     0xd309f8: mov             SP, fp
    //     0xd309fc: ldp             fp, lr, [SP], #0x10
    // 0xd30a00: fcmp            d0, d0
    // 0xd30a04: b.vs            #0xd30aec
    // 0xd30a08: fcvtzs          x0, d0
    // 0xd30a0c: asr             x16, x0, #0x1e
    // 0xd30a10: cmp             x16, x0, asr #63
    // 0xd30a14: b.ne            #0xd30aec
    // 0xd30a18: lsl             x0, x0, #1
    // 0xd30a1c: str             x0, [SP]
    // 0xd30a20: r0 = _interpolateSingle()
    //     0xd30a20: bl              #0x7e237c  ; [dart:core] _StringBase::_interpolateSingle
    // 0xd30a24: mov             x1, x0
    // 0xd30a28: r2 = true
    //     0xd30a28: add             x2, NULL, #0x20  ; true
    // 0xd30a2c: b               #0xd30a38
    // 0xd30a30: r2 = false
    //     0xd30a30: add             x2, NULL, #0x30  ; false
    // 0xd30a34: r1 = Null
    //     0xd30a34: mov             x1, NULL
    // 0xd30a38: ldur            x0, [fp, #-8]
    // 0xd30a3c: stur            x1, [fp, #-0x30]
    // 0xd30a40: LoadField: r3 = r0->field_1b
    //     0xd30a40: ldur            w3, [x0, #0x1b]
    // 0xd30a44: DecompressPointer r3
    //     0xd30a44: add             x3, x3, HEAP, lsl #32
    // 0xd30a48: stur            x3, [fp, #-0x28]
    // 0xd30a4c: tbnz            w2, #4, #0xd30a5c
    // 0xd30a50: r0 = Instance_SemanticsRole
    //     0xd30a50: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8fb88] Obj!SemanticsRole@12c7901
    //     0xd30a54: ldr             x0, [x0, #0xb88]
    // 0xd30a58: b               #0xd30a64
    // 0xd30a5c: r0 = Instance_SemanticsRole
    //     0xd30a5c: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8fb90] Obj!SemanticsRole@12c78e1
    //     0xd30a60: ldr             x0, [x0, #0xb90]
    // 0xd30a64: stur            x0, [fp, #-0x20]
    // 0xd30a68: tbnz            w2, #4, #0xd30a74
    // 0xd30a6c: r4 = "0"
    //     0xd30a6c: ldr             x4, [PP, #0x47e8]  ; [pp+0x47e8] "0"
    // 0xd30a70: b               #0xd30a78
    // 0xd30a74: r4 = Null
    //     0xd30a74: mov             x4, NULL
    // 0xd30a78: stur            x4, [fp, #-0x18]
    // 0xd30a7c: tbnz            w2, #4, #0xd30a8c
    // 0xd30a80: r2 = "100"
    //     0xd30a80: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fb98] "100"
    //     0xd30a84: ldr             x2, [x2, #0xb98]
    // 0xd30a88: b               #0xd30a90
    // 0xd30a8c: r2 = Null
    //     0xd30a8c: mov             x2, NULL
    // 0xd30a90: stur            x2, [fp, #-8]
    // 0xd30a94: r0 = Semantics()
    //     0xd30a94: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xd30a98: stur            x0, [fp, #-0x38]
    // 0xd30a9c: ldur            x16, [fp, #-0x28]
    // 0xd30aa0: ldur            lr, [fp, #-0x20]
    // 0xd30aa4: stp             lr, x16, [SP, #0x20]
    // 0xd30aa8: ldur            x16, [fp, #-0x18]
    // 0xd30aac: ldur            lr, [fp, #-8]
    // 0xd30ab0: stp             lr, x16, [SP, #0x10]
    // 0xd30ab4: ldur            x16, [fp, #-0x30]
    // 0xd30ab8: ldur            lr, [fp, #-0x10]
    // 0xd30abc: stp             lr, x16, [SP]
    // 0xd30ac0: mov             x1, x0
    // 0xd30ac4: r4 = const [0, 0x7, 0x6, 0x1, child, 0x6, label, 0x1, maxValue, 0x4, minValue, 0x3, role, 0x2, value, 0x5, null]
    //     0xd30ac4: add             x4, PP, #0x8f, lsl #12  ; [pp+0x8fba0] List(17) [0, 0x7, 0x6, 0x1, "child", 0x6, "label", 0x1, "maxValue", 0x4, "minValue", 0x3, "role", 0x2, "value", 0x5, Null]
    //     0xd30ac8: ldr             x4, [x4, #0xba0]
    // 0xd30acc: r0 = Semantics()
    //     0xd30acc: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xd30ad0: ldur            x0, [fp, #-0x38]
    // 0xd30ad4: LeaveFrame
    //     0xd30ad4: mov             SP, fp
    //     0xd30ad8: ldp             fp, lr, [SP], #0x10
    // 0xd30adc: ret
    //     0xd30adc: ret             
    // 0xd30ae0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd30ae0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd30ae4: b               #0xd30998
    // 0xd30ae8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd30ae8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd30aec: SaveReg d0
    //     0xd30aec: str             q0, [SP, #-0x10]!
    // 0xd30af0: r0 = 76
    //     0xd30af0: mov             x0, #0x4c
    // 0xd30af4: r30 = DoubleToIntegerStub
    //     0xd30af4: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xd30af8: LoadField: r30 = r30->field_7
    //     0xd30af8: ldur            lr, [lr, #7]
    // 0xd30afc: blr             lr
    // 0xd30b00: RestoreReg d0
    //     0xd30b00: ldr             q0, [SP], #0x10
    // 0xd30b04: b               #0xd30a1c
  }
  _ _getValueColor(/* No info */) {
    // ** addr: 0xd30b14, size: 0x108
    // 0xd30b14: EnterFrame
    //     0xd30b14: stp             fp, lr, [SP, #-0x10]!
    //     0xd30b18: mov             fp, SP
    // 0xd30b1c: AllocStack(0x18)
    //     0xd30b1c: sub             SP, SP, #0x18
    // 0xd30b20: SetupParameters(ProgressIndicator this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, {dynamic defaultColor = Null /* r4, fp-0x8 */})
    //     0xd30b20: mov             x3, x1
    //     0xd30b24: stur            x1, [fp, #-0x10]
    //     0xd30b28: stur            x2, [fp, #-0x18]
    //     0xd30b2c: ldur            w0, [x4, #0x13]
    //     0xd30b30: ldur            w1, [x4, #0x1f]
    //     0xd30b34: add             x1, x1, HEAP, lsl #32
    //     0xd30b38: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fbc8] "defaultColor"
    //     0xd30b3c: ldr             x16, [x16, #0xbc8]
    //     0xd30b40: cmp             w1, w16
    //     0xd30b44: b.ne            #0xd30b64
    //     0xd30b48: ldur            w1, [x4, #0x23]
    //     0xd30b4c: add             x1, x1, HEAP, lsl #32
    //     0xd30b50: sub             w4, w0, w1
    //     0xd30b54: add             x0, fp, w4, sxtw #2
    //     0xd30b58: ldr             x0, [x0, #8]
    //     0xd30b5c: mov             x4, x0
    //     0xd30b60: b               #0xd30b68
    //     0xd30b64: mov             x4, NULL
    //     0xd30b68: stur            x4, [fp, #-8]
    // 0xd30b6c: CheckStackOverflow
    //     0xd30b6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd30b70: cmp             SP, x16
    //     0xd30b74: b.ls            #0xd30c14
    // 0xd30b78: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xd30b78: ldur            w1, [x3, #0x17]
    // 0xd30b7c: DecompressPointer r1
    //     0xd30b7c: add             x1, x1, HEAP, lsl #32
    // 0xd30b80: cmp             w1, NULL
    // 0xd30b84: b.ne            #0xd30b90
    // 0xd30b88: r0 = Null
    //     0xd30b88: mov             x0, NULL
    // 0xd30b8c: b               #0xd30bac
    // 0xd30b90: r0 = LoadClassIdInstr(r1)
    //     0xd30b90: ldur            x0, [x1, #-1]
    //     0xd30b94: ubfx            x0, x0, #0xc, #0x14
    // 0xd30b98: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xd30b98: mov             x17, #0x4e2e
    //     0xd30b9c: movk            x17, #1, lsl #16
    //     0xd30ba0: add             lr, x0, x17
    //     0xd30ba4: ldr             lr, [x21, lr, lsl #3]
    //     0xd30ba8: blr             lr
    // 0xd30bac: cmp             w0, NULL
    // 0xd30bb0: b.ne            #0xd30bc4
    // 0xd30bb4: ldur            x0, [fp, #-0x10]
    // 0xd30bb8: LoadField: r1 = r0->field_13
    //     0xd30bb8: ldur            w1, [x0, #0x13]
    // 0xd30bbc: DecompressPointer r1
    //     0xd30bbc: add             x1, x1, HEAP, lsl #32
    // 0xd30bc0: mov             x0, x1
    // 0xd30bc4: cmp             w0, NULL
    // 0xd30bc8: b.ne            #0xd30bd8
    // 0xd30bcc: ldur            x1, [fp, #-0x18]
    // 0xd30bd0: r0 = of()
    //     0xd30bd0: bl              #0xd30c34  ; [package:flutter/src/material/progress_indicator_theme.dart] ProgressIndicatorTheme::of
    // 0xd30bd4: r0 = Null
    //     0xd30bd4: mov             x0, NULL
    // 0xd30bd8: cmp             w0, NULL
    // 0xd30bdc: b.ne            #0xd30be4
    // 0xd30be0: ldur            x0, [fp, #-8]
    // 0xd30be4: cmp             w0, NULL
    // 0xd30be8: b.ne            #0xd30c08
    // 0xd30bec: ldur            x1, [fp, #-0x18]
    // 0xd30bf0: r0 = of()
    //     0xd30bf0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd30bf4: LoadField: r1 = r0->field_3f
    //     0xd30bf4: ldur            w1, [x0, #0x3f]
    // 0xd30bf8: DecompressPointer r1
    //     0xd30bf8: add             x1, x1, HEAP, lsl #32
    // 0xd30bfc: LoadField: r2 = r1->field_b
    //     0xd30bfc: ldur            w2, [x1, #0xb]
    // 0xd30c00: DecompressPointer r2
    //     0xd30c00: add             x2, x2, HEAP, lsl #32
    // 0xd30c04: mov             x0, x2
    // 0xd30c08: LeaveFrame
    //     0xd30c08: mov             SP, fp
    //     0xd30c0c: ldp             fp, lr, [SP], #0x10
    // 0xd30c10: ret
    //     0xd30c10: ret             
    // 0xd30c14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd30c14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd30c18: b               #0xd30b78
  }
  double? _effectiveValue(ProgressIndicator) {
    // ** addr: 0xd30d4c, size: 0xb0
    // 0xd30d4c: EnterFrame
    //     0xd30d4c: stp             fp, lr, [SP, #-0x10]!
    //     0xd30d50: mov             fp, SP
    // 0xd30d54: LoadField: r2 = r1->field_b
    //     0xd30d54: ldur            w2, [x1, #0xb]
    // 0xd30d58: DecompressPointer r2
    //     0xd30d58: add             x2, x2, HEAP, lsl #32
    // 0xd30d5c: cmp             w2, NULL
    // 0xd30d60: b.ne            #0xd30d6c
    // 0xd30d64: r0 = Null
    //     0xd30d64: mov             x0, NULL
    // 0xd30d68: b               #0xd30ddc
    // 0xd30d6c: d0 = 0.000000
    //     0xd30d6c: eor             v0.16b, v0.16b, v0.16b
    // 0xd30d70: LoadField: d1 = r2->field_7
    //     0xd30d70: ldur            d1, [x2, #7]
    // 0xd30d74: fcmp            d0, d1
    // 0xd30d78: b.le            #0xd30d84
    // 0xd30d7c: d0 = 0.000000
    //     0xd30d7c: eor             v0.16b, v0.16b, v0.16b
    // 0xd30d80: b               #0xd30dac
    // 0xd30d84: d0 = 1.000000
    //     0xd30d84: fmov            d0, #1.00000000
    // 0xd30d88: fcmp            d1, d0
    // 0xd30d8c: b.le            #0xd30d98
    // 0xd30d90: d0 = 1.000000
    //     0xd30d90: fmov            d0, #1.00000000
    // 0xd30d94: b               #0xd30dac
    // 0xd30d98: fcmp            d1, d1
    // 0xd30d9c: b.vc            #0xd30da8
    // 0xd30da0: d0 = 1.000000
    //     0xd30da0: fmov            d0, #1.00000000
    // 0xd30da4: b               #0xd30dac
    // 0xd30da8: mov             v0.16b, v1.16b
    // 0xd30dac: r1 = inline_Allocate_Double()
    //     0xd30dac: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xd30db0: add             x1, x1, #0x10
    //     0xd30db4: cmp             x2, x1
    //     0xd30db8: b.ls            #0xd30de8
    //     0xd30dbc: str             x1, [THR, #0x60]  ; THR::top
    //     0xd30dc0: sub             x1, x1, #0xf
    //     0xd30dc4: mov             x2, #0xe19c
    //     0xd30dc8: movk            x2, #3, lsl #16
    //     0xd30dcc: stur            x2, [x1, #-1]
    // 0xd30dd0: dmb             ishst
    // 0xd30dd4: StoreField: r1->field_7 = d0
    //     0xd30dd4: stur            d0, [x1, #7]
    // 0xd30dd8: mov             x0, x1
    // 0xd30ddc: LeaveFrame
    //     0xd30ddc: mov             SP, fp
    //     0xd30de0: ldp             fp, lr, [SP], #0x10
    // 0xd30de4: ret
    //     0xd30de4: ret             
    // 0xd30de8: SaveReg d0
    //     0xd30de8: str             q0, [SP, #-0x10]!
    // 0xd30dec: r0 = AllocateDouble()
    //     0xd30dec: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd30df0: mov             x1, x0
    // 0xd30df4: RestoreReg d0
    //     0xd30df4: ldr             q0, [SP], #0x10
    // 0xd30df8: b               #0xd30dd4
  }
}

// class id: 6445, size: 0x48, field offset: 0x24
//   const constructor, 
class CircularProgressIndicator extends ProgressIndicator {

  _ActivityIndicatorType field_24;
  AlwaysStoppedAnimation<Color> field_18;
  _Double field_28;
  Color field_14;

  _ createState(/* No info */) {
    // ** addr: 0xfa2670, size: 0x2c
    // 0xfa2670: EnterFrame
    //     0xfa2670: stp             fp, lr, [SP, #-0x10]!
    //     0xfa2674: mov             fp, SP
    // 0xfa2678: mov             x0, x1
    // 0xfa267c: r1 = <CircularProgressIndicator>
    //     0xfa267c: add             x1, PP, #0x84, lsl #12  ; [pp+0x84968] TypeArguments: <CircularProgressIndicator>
    //     0xfa2680: ldr             x1, [x1, #0x968]
    // 0xfa2684: r0 = _CircularProgressIndicatorState()
    //     0xfa2684: bl              #0xfa269c  ; Allocate_CircularProgressIndicatorStateStub -> _CircularProgressIndicatorState (size=0x20)
    // 0xfa2688: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa268c: StoreField: r0->field_1b = r1
    //     0xfa268c: stur            w1, [x0, #0x1b]
    // 0xfa2690: LeaveFrame
    //     0xfa2690: mov             SP, fp
    //     0xfa2694: ldp             fp, lr, [SP], #0x10
    // 0xfa2698: ret
    //     0xfa2698: ret             
  }
}

// class id: 6446, size: 0x58, field offset: 0x48
//   const constructor, 
class RefreshProgressIndicator extends CircularProgressIndicator {

  _ createState(/* No info */) {
    // ** addr: 0xfa2630, size: 0x34
    // 0xfa2630: EnterFrame
    //     0xfa2630: stp             fp, lr, [SP, #-0x10]!
    //     0xfa2634: mov             fp, SP
    // 0xfa2638: mov             x0, x1
    // 0xfa263c: r1 = <CircularProgressIndicator>
    //     0xfa263c: add             x1, PP, #0x84, lsl #12  ; [pp+0x84968] TypeArguments: <CircularProgressIndicator>
    //     0xfa2640: ldr             x1, [x1, #0x968]
    // 0xfa2644: r0 = _RefreshProgressIndicatorState()
    //     0xfa2644: bl              #0xfa2664  ; Allocate_RefreshProgressIndicatorStateStub -> _RefreshProgressIndicatorState (size=0x2c)
    // 0xfa2648: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa264c: StoreField: r0->field_1f = r1
    //     0xfa264c: stur            w1, [x0, #0x1f]
    // 0xfa2650: StoreField: r0->field_23 = r1
    //     0xfa2650: stur            w1, [x0, #0x23]
    // 0xfa2654: StoreField: r0->field_1b = r1
    //     0xfa2654: stur            w1, [x0, #0x1b]
    // 0xfa2658: LeaveFrame
    //     0xfa2658: mov             SP, fp
    //     0xfa265c: ldp             fp, lr, [SP], #0x10
    // 0xfa2660: ret
    //     0xfa2660: ret             
  }
}

// class id: 6447, size: 0x40, field offset: 0x24
//   const constructor, 
class LinearProgressIndicator extends ProgressIndicator {

  _ createState(/* No info */) {
    // ** addr: 0xfa25f8, size: 0x2c
    // 0xfa25f8: EnterFrame
    //     0xfa25f8: stp             fp, lr, [SP, #-0x10]!
    //     0xfa25fc: mov             fp, SP
    // 0xfa2600: mov             x0, x1
    // 0xfa2604: r1 = <LinearProgressIndicator>
    //     0xfa2604: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd0490] TypeArguments: <LinearProgressIndicator>
    //     0xfa2608: ldr             x1, [x1, #0x490]
    // 0xfa260c: r0 = _LinearProgressIndicatorState()
    //     0xfa260c: bl              #0xfa2624  ; Allocate_LinearProgressIndicatorStateStub -> _LinearProgressIndicatorState (size=0x20)
    // 0xfa2610: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa2614: StoreField: r0->field_1b = r1
    //     0xfa2614: stur            w1, [x0, #0x1b]
    // 0xfa2618: LeaveFrame
    //     0xfa2618: mov             SP, fp
    //     0xfa261c: ldp             fp, lr, [SP], #0x10
    // 0xfa2620: ret
    //     0xfa2620: ret             
  }
}

// class id: 8274, size: 0x14, field offset: 0x14
enum _ActivityIndicatorType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa4e0, size: 0x64
    // 0x11aa4e0: EnterFrame
    //     0x11aa4e0: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa4e4: mov             fp, SP
    // 0x11aa4e8: AllocStack(0x10)
    //     0x11aa4e8: sub             SP, SP, #0x10
    // 0x11aa4ec: SetupParameters(_ActivityIndicatorType this /* r1 => r0, fp-0x8 */)
    //     0x11aa4ec: mov             x0, x1
    //     0x11aa4f0: stur            x1, [fp, #-8]
    // 0x11aa4f4: CheckStackOverflow
    //     0x11aa4f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa4f8: cmp             SP, x16
    //     0x11aa4fc: b.ls            #0x11aa53c
    // 0x11aa500: r1 = Null
    //     0x11aa500: mov             x1, NULL
    // 0x11aa504: r2 = 4
    //     0x11aa504: mov             x2, #4
    // 0x11aa508: r0 = AllocateArray()
    //     0x11aa508: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa50c: r16 = "_ActivityIndicatorType."
    //     0x11aa50c: add             x16, PP, #0x84, lsl #12  ; [pp+0x84960] "_ActivityIndicatorType."
    //     0x11aa510: ldr             x16, [x16, #0x960]
    // 0x11aa514: StoreField: r0->field_f = r16
    //     0x11aa514: stur            w16, [x0, #0xf]
    // 0x11aa518: ldur            x1, [fp, #-8]
    // 0x11aa51c: LoadField: r2 = r1->field_f
    //     0x11aa51c: ldur            w2, [x1, #0xf]
    // 0x11aa520: DecompressPointer r2
    //     0x11aa520: add             x2, x2, HEAP, lsl #32
    // 0x11aa524: StoreField: r0->field_13 = r2
    //     0x11aa524: stur            w2, [x0, #0x13]
    // 0x11aa528: str             x0, [SP]
    // 0x11aa52c: r0 = _interpolate()
    //     0x11aa52c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa530: LeaveFrame
    //     0x11aa530: mov             SP, fp
    //     0x11aa534: ldp             fp, lr, [SP], #0x10
    // 0x11aa538: ret
    //     0x11aa538: ret             
    // 0x11aa53c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa53c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa540: b               #0x11aa500
  }
}
