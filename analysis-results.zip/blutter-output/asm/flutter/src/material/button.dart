// lib: , url: package:flutter/src/material/button.dart

// class id: 1048855, size: 0x8
class :: {
}

// class id: 4880, size: 0x58, field offset: 0x54
class _RenderInputPadding extends RenderShiftedBox {

  _ hitTest(/* No info */) {
    // ** addr: 0xaf969c, size: 0xf4
    // 0xaf969c: EnterFrame
    //     0xaf969c: stp             fp, lr, [SP, #-0x10]!
    //     0xaf96a0: mov             fp, SP
    // 0xaf96a4: AllocStack(0x20)
    //     0xaf96a4: sub             SP, SP, #0x20
    // 0xaf96a8: SetupParameters(_RenderInputPadding this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xaf96a8: stur            x1, [fp, #-8]
    //     0xaf96ac: stur            x2, [fp, #-0x10]
    //     0xaf96b0: stur            x3, [fp, #-0x18]
    // 0xaf96b4: CheckStackOverflow
    //     0xaf96b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf96b8: cmp             SP, x16
    //     0xaf96bc: b.ls            #0xaf9784
    // 0xaf96c0: r1 = 2
    //     0xaf96c0: mov             x1, #2
    // 0xaf96c4: r0 = AllocateContext()
    //     0xaf96c4: bl              #0x13de838  ; AllocateContextStub
    // 0xaf96c8: mov             x4, x0
    // 0xaf96cc: ldur            x0, [fp, #-8]
    // 0xaf96d0: stur            x4, [fp, #-0x20]
    // 0xaf96d4: StoreField: r4->field_f = r0
    //     0xaf96d4: stur            w0, [x4, #0xf]
    // 0xaf96d8: mov             x1, x0
    // 0xaf96dc: ldur            x2, [fp, #-0x10]
    // 0xaf96e0: ldur            x3, [fp, #-0x18]
    // 0xaf96e4: r0 = hitTest()
    //     0xaf96e4: bl              #0xafb454  ; [package:flutter/src/rendering/box.dart] RenderBox::hitTest
    // 0xaf96e8: tbnz            w0, #4, #0xaf96fc
    // 0xaf96ec: r0 = true
    //     0xaf96ec: add             x0, NULL, #0x20  ; true
    // 0xaf96f0: LeaveFrame
    //     0xaf96f0: mov             SP, fp
    //     0xaf96f4: ldp             fp, lr, [SP], #0x10
    // 0xaf96f8: ret
    //     0xaf96f8: ret             
    // 0xaf96fc: ldur            x0, [fp, #-8]
    // 0xaf9700: ldur            x2, [fp, #-0x20]
    // 0xaf9704: LoadField: r1 = r0->field_4f
    //     0xaf9704: ldur            w1, [x0, #0x4f]
    // 0xaf9708: DecompressPointer r1
    //     0xaf9708: add             x1, x1, HEAP, lsl #32
    // 0xaf970c: cmp             w1, NULL
    // 0xaf9710: b.eq            #0xaf978c
    // 0xaf9714: r0 = size()
    //     0xaf9714: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xaf9718: mov             x1, x0
    // 0xaf971c: r0 = center()
    //     0xaf971c: bl              #0xaf9a1c  ; [dart:ui] Size::center
    // 0xaf9720: mov             x3, x0
    // 0xaf9724: ldur            x2, [fp, #-0x20]
    // 0xaf9728: stur            x3, [fp, #-8]
    // 0xaf972c: StoreField: r2->field_13 = r0
    //     0xaf972c: stur            w0, [x2, #0x13]
    //     0xaf9730: ldurb           w16, [x2, #-1]
    //     0xaf9734: ldurb           w17, [x0, #-1]
    //     0xaf9738: and             x16, x17, x16, lsr #2
    //     0xaf973c: tst             x16, HEAP, lsr #32
    //     0xaf9740: b.eq            #0xaf9748
    //     0xaf9744: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xaf9748: mov             x1, x3
    // 0xaf974c: r0 = forceToPoint()
    //     0xaf974c: bl              #0xaf99c4  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::forceToPoint
    // 0xaf9750: ldur            x2, [fp, #-0x20]
    // 0xaf9754: r1 = Function '<anonymous closure>':.
    //     0xaf9754: add             x1, PP, #0xad, lsl #12  ; [pp+0xadff0] AnonymousClosure: (0xaf9a78), in [package:flutter/src/material/button_style_button.dart] _RenderInputPadding::hitTest (0xaf9af4)
    //     0xaf9758: ldr             x1, [x1, #0xff0]
    // 0xaf975c: stur            x0, [fp, #-0x18]
    // 0xaf9760: r0 = AllocateClosure()
    //     0xaf9760: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xaf9764: ldur            x1, [fp, #-0x10]
    // 0xaf9768: mov             x2, x0
    // 0xaf976c: ldur            x3, [fp, #-8]
    // 0xaf9770: ldur            x5, [fp, #-0x18]
    // 0xaf9774: r0 = addWithRawTransform()
    //     0xaf9774: bl              #0xaf9790  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithRawTransform
    // 0xaf9778: LeaveFrame
    //     0xaf9778: mov             SP, fp
    //     0xaf977c: ldp             fp, lr, [SP], #0x10
    // 0xaf9780: ret
    //     0xaf9780: ret             
    // 0xaf9784: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf9784: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf9788: b               #0xaf96c0
    // 0xaf978c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaf978c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb16f60, size: 0x24
    // 0xb16f60: EnterFrame
    //     0xb16f60: stp             fp, lr, [SP, #-0x10]!
    //     0xb16f64: mov             fp, SP
    // 0xb16f68: ldr             x2, [fp, #0x10]
    // 0xb16f6c: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb16f6c: add             x1, PP, #0xad, lsl #12  ; [pp+0xadfe8] AnonymousClosure: (0xb16f84), in [package:flutter/src/material/button.dart] _RenderInputPadding::computeMinIntrinsicWidth (0xb16ffc)
    //     0xb16f70: ldr             x1, [x1, #0xfe8]
    // 0xb16f74: r0 = AllocateClosure()
    //     0xb16f74: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb16f78: LeaveFrame
    //     0xb16f78: mov             SP, fp
    //     0xb16f7c: ldp             fp, lr, [SP], #0x10
    // 0xb16f80: ret
    //     0xb16f80: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb16f84, size: 0x78
    // 0xb16f84: EnterFrame
    //     0xb16f84: stp             fp, lr, [SP, #-0x10]!
    //     0xb16f88: mov             fp, SP
    // 0xb16f8c: ldr             x0, [fp, #0x18]
    // 0xb16f90: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb16f90: ldur            w1, [x0, #0x17]
    // 0xb16f94: DecompressPointer r1
    //     0xb16f94: add             x1, x1, HEAP, lsl #32
    // 0xb16f98: CheckStackOverflow
    //     0xb16f98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb16f9c: cmp             SP, x16
    //     0xb16fa0: b.ls            #0xb16fe4
    // 0xb16fa4: ldr             x2, [fp, #0x10]
    // 0xb16fa8: r0 = computeMinIntrinsicWidth()
    //     0xb16fa8: bl              #0xb16ffc  ; [package:flutter/src/material/button.dart] _RenderInputPadding::computeMinIntrinsicWidth
    // 0xb16fac: r0 = inline_Allocate_Double()
    //     0xb16fac: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb16fb0: add             x0, x0, #0x10
    //     0xb16fb4: cmp             x1, x0
    //     0xb16fb8: b.ls            #0xb16fec
    //     0xb16fbc: str             x0, [THR, #0x60]  ; THR::top
    //     0xb16fc0: sub             x0, x0, #0xf
    //     0xb16fc4: mov             x1, #0xe19c
    //     0xb16fc8: movk            x1, #3, lsl #16
    //     0xb16fcc: stur            x1, [x0, #-1]
    // 0xb16fd0: dmb             ishst
    // 0xb16fd4: StoreField: r0->field_7 = d0
    //     0xb16fd4: stur            d0, [x0, #7]
    // 0xb16fd8: LeaveFrame
    //     0xb16fd8: mov             SP, fp
    //     0xb16fdc: ldp             fp, lr, [SP], #0x10
    // 0xb16fe0: ret
    //     0xb16fe0: ret             
    // 0xb16fe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16fe4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16fe8: b               #0xb16fa4
    // 0xb16fec: SaveReg d0
    //     0xb16fec: str             q0, [SP, #-0x10]!
    // 0xb16ff0: r0 = AllocateDouble()
    //     0xb16ff0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb16ff4: RestoreReg d0
    //     0xb16ff4: ldr             q0, [SP], #0x10
    // 0xb16ff8: b               #0xb16fd4
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0xb16ffc, size: 0x74
    // 0xb16ffc: EnterFrame
    //     0xb16ffc: stp             fp, lr, [SP, #-0x10]!
    //     0xb17000: mov             fp, SP
    // 0xb17004: AllocStack(0x8)
    //     0xb17004: sub             SP, SP, #8
    // 0xb17008: SetupParameters(_RenderInputPadding this /* r1 => r0, fp-0x8 */)
    //     0xb17008: mov             x0, x1
    //     0xb1700c: stur            x1, [fp, #-8]
    // 0xb17010: CheckStackOverflow
    //     0xb17010: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb17014: cmp             SP, x16
    //     0xb17018: b.ls            #0xb17068
    // 0xb1701c: LoadField: r1 = r0->field_4f
    //     0xb1701c: ldur            w1, [x0, #0x4f]
    // 0xb17020: DecompressPointer r1
    //     0xb17020: add             x1, x1, HEAP, lsl #32
    // 0xb17024: cmp             w1, NULL
    // 0xb17028: b.eq            #0xb17058
    // 0xb1702c: LoadField: d0 = r2->field_7
    //     0xb1702c: ldur            d0, [x2, #7]
    // 0xb17030: r0 = getMinIntrinsicWidth()
    //     0xb17030: bl              #0xb1628c  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0xb17034: ldur            x0, [fp, #-8]
    // 0xb17038: LoadField: r1 = r0->field_53
    //     0xb17038: ldur            w1, [x0, #0x53]
    // 0xb1703c: DecompressPointer r1
    //     0xb1703c: add             x1, x1, HEAP, lsl #32
    // 0xb17040: LoadField: d1 = r1->field_7
    //     0xb17040: ldur            d1, [x1, #7]
    // 0xb17044: fmax            v2.2d, v0.2d, v1.2d
    // 0xb17048: mov             v0.16b, v2.16b
    // 0xb1704c: LeaveFrame
    //     0xb1704c: mov             SP, fp
    //     0xb17050: ldp             fp, lr, [SP], #0x10
    // 0xb17054: ret
    //     0xb17054: ret             
    // 0xb17058: d0 = 0.000000
    //     0xb17058: eor             v0.16b, v0.16b, v0.16b
    // 0xb1705c: LeaveFrame
    //     0xb1705c: mov             SP, fp
    //     0xb17060: ldp             fp, lr, [SP], #0x10
    // 0xb17064: ret
    //     0xb17064: ret             
    // 0xb17068: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb17068: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1706c: b               #0xb1701c
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4d7b4, size: 0x34
    // 0xb4d7b4: EnterFrame
    //     0xb4d7b4: stp             fp, lr, [SP, #-0x10]!
    //     0xb4d7b8: mov             fp, SP
    // 0xb4d7bc: CheckStackOverflow
    //     0xb4d7bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4d7c0: cmp             SP, x16
    //     0xb4d7c4: b.ls            #0xb4d7e0
    // 0xb4d7c8: r3 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xb4d7c8: add             x3, PP, #0x90, lsl #12  ; [pp+0x90700] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7f2adaa12214)
    //     0xb4d7cc: ldr             x3, [x3, #0x700]
    // 0xb4d7d0: r0 = _computeSize()
    //     0xb4d7d0: bl              #0xb4d7e8  ; [package:flutter/src/material/button.dart] _RenderInputPadding::_computeSize
    // 0xb4d7d4: LeaveFrame
    //     0xb4d7d4: mov             SP, fp
    //     0xb4d7d8: ldp             fp, lr, [SP], #0x10
    // 0xb4d7dc: ret
    //     0xb4d7dc: ret             
    // 0xb4d7e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4d7e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4d7e4: b               #0xb4d7c8
  }
  _ _computeSize(/* No info */) {
    // ** addr: 0xb4d7e8, size: 0xc4
    // 0xb4d7e8: EnterFrame
    //     0xb4d7e8: stp             fp, lr, [SP, #-0x10]!
    //     0xb4d7ec: mov             fp, SP
    // 0xb4d7f0: AllocStack(0x38)
    //     0xb4d7f0: sub             SP, SP, #0x38
    // 0xb4d7f4: SetupParameters(_RenderInputPadding this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xb4d7f4: stur            x1, [fp, #-8]
    //     0xb4d7f8: mov             x16, x2
    //     0xb4d7fc: mov             x2, x1
    //     0xb4d800: mov             x1, x16
    //     0xb4d804: mov             x0, x3
    //     0xb4d808: stur            x1, [fp, #-0x10]
    // 0xb4d80c: CheckStackOverflow
    //     0xb4d80c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4d810: cmp             SP, x16
    //     0xb4d814: b.ls            #0xb4d8a4
    // 0xb4d818: LoadField: r3 = r2->field_4f
    //     0xb4d818: ldur            w3, [x2, #0x4f]
    // 0xb4d81c: DecompressPointer r3
    //     0xb4d81c: add             x3, x3, HEAP, lsl #32
    // 0xb4d820: cmp             w3, NULL
    // 0xb4d824: b.eq            #0xb4d894
    // 0xb4d828: stp             x3, x0, [SP, #8]
    // 0xb4d82c: str             x1, [SP]
    // 0xb4d830: ClosureCall
    //     0xb4d830: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb4d834: ldur            x2, [x0, #0x1f]
    //     0xb4d838: blr             x2
    // 0xb4d83c: LoadField: d0 = r0->field_7
    //     0xb4d83c: ldur            d0, [x0, #7]
    // 0xb4d840: ldur            x1, [fp, #-8]
    // 0xb4d844: LoadField: r2 = r1->field_53
    //     0xb4d844: ldur            w2, [x1, #0x53]
    // 0xb4d848: DecompressPointer r2
    //     0xb4d848: add             x2, x2, HEAP, lsl #32
    // 0xb4d84c: LoadField: d1 = r2->field_7
    //     0xb4d84c: ldur            d1, [x2, #7]
    // 0xb4d850: fmax            v2.2d, v0.2d, v1.2d
    // 0xb4d854: stur            d2, [fp, #-0x20]
    // 0xb4d858: LoadField: d0 = r0->field_f
    //     0xb4d858: ldur            d0, [x0, #0xf]
    // 0xb4d85c: LoadField: d1 = r2->field_f
    //     0xb4d85c: ldur            d1, [x2, #0xf]
    // 0xb4d860: fmax            v3.2d, v0.2d, v1.2d
    // 0xb4d864: stur            d3, [fp, #-0x18]
    // 0xb4d868: r0 = Size()
    //     0xb4d868: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb4d86c: ldur            d0, [fp, #-0x20]
    // 0xb4d870: StoreField: r0->field_7 = d0
    //     0xb4d870: stur            d0, [x0, #7]
    // 0xb4d874: ldur            d0, [fp, #-0x18]
    // 0xb4d878: StoreField: r0->field_f = d0
    //     0xb4d878: stur            d0, [x0, #0xf]
    // 0xb4d87c: ldur            x1, [fp, #-0x10]
    // 0xb4d880: mov             x2, x0
    // 0xb4d884: r0 = constrain()
    //     0xb4d884: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb4d888: LeaveFrame
    //     0xb4d888: mov             SP, fp
    //     0xb4d88c: ldp             fp, lr, [SP], #0x10
    // 0xb4d890: ret
    //     0xb4d890: ret             
    // 0xb4d894: r0 = Instance_Size
    //     0xb4d894: ldr             x0, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xb4d898: LeaveFrame
    //     0xb4d898: mov             SP, fp
    //     0xb4d89c: ldp             fp, lr, [SP], #0x10
    // 0xb4d8a0: ret
    //     0xb4d8a0: ret             
    // 0xb4d8a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4d8a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4d8a8: b               #0xb4d818
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb58300, size: 0x24
    // 0xb58300: EnterFrame
    //     0xb58300: stp             fp, lr, [SP, #-0x10]!
    //     0xb58304: mov             fp, SP
    // 0xb58308: ldr             x2, [fp, #0x10]
    // 0xb5830c: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb5830c: add             x1, PP, #0xad, lsl #12  ; [pp+0xadfd8] AnonymousClosure: (0xb58324), in [package:flutter/src/material/button_style_button.dart] _RenderInputPadding::computeMaxIntrinsicWidth (0xb2d2e4)
    //     0xb58310: ldr             x1, [x1, #0xfd8]
    // 0xb58314: r0 = AllocateClosure()
    //     0xb58314: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb58318: LeaveFrame
    //     0xb58318: mov             SP, fp
    //     0xb5831c: ldp             fp, lr, [SP], #0x10
    // 0xb58320: ret
    //     0xb58320: ret             
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb58324, size: 0x78
    // 0xb58324: EnterFrame
    //     0xb58324: stp             fp, lr, [SP, #-0x10]!
    //     0xb58328: mov             fp, SP
    // 0xb5832c: ldr             x0, [fp, #0x18]
    // 0xb58330: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb58330: ldur            w1, [x0, #0x17]
    // 0xb58334: DecompressPointer r1
    //     0xb58334: add             x1, x1, HEAP, lsl #32
    // 0xb58338: CheckStackOverflow
    //     0xb58338: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5833c: cmp             SP, x16
    //     0xb58340: b.ls            #0xb58384
    // 0xb58344: ldr             x2, [fp, #0x10]
    // 0xb58348: r0 = computeMaxIntrinsicWidth()
    //     0xb58348: bl              #0xb2d2e4  ; [package:flutter/src/material/button_style_button.dart] _RenderInputPadding::computeMaxIntrinsicWidth
    // 0xb5834c: r0 = inline_Allocate_Double()
    //     0xb5834c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb58350: add             x0, x0, #0x10
    //     0xb58354: cmp             x1, x0
    //     0xb58358: b.ls            #0xb5838c
    //     0xb5835c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb58360: sub             x0, x0, #0xf
    //     0xb58364: mov             x1, #0xe19c
    //     0xb58368: movk            x1, #3, lsl #16
    //     0xb5836c: stur            x1, [x0, #-1]
    // 0xb58370: dmb             ishst
    // 0xb58374: StoreField: r0->field_7 = d0
    //     0xb58374: stur            d0, [x0, #7]
    // 0xb58378: LeaveFrame
    //     0xb58378: mov             SP, fp
    //     0xb5837c: ldp             fp, lr, [SP], #0x10
    // 0xb58380: ret
    //     0xb58380: ret             
    // 0xb58384: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb58384: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb58388: b               #0xb58344
    // 0xb5838c: SaveReg d0
    //     0xb5838c: str             q0, [SP, #-0x10]!
    // 0xb58390: r0 = AllocateDouble()
    //     0xb58390: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb58394: RestoreReg d0
    //     0xb58394: ldr             q0, [SP], #0x10
    // 0xb58398: b               #0xb58374
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e488, size: 0x24
    // 0xb5e488: EnterFrame
    //     0xb5e488: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e48c: mov             fp, SP
    // 0xb5e490: ldr             x2, [fp, #0x10]
    // 0xb5e494: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e494: add             x1, PP, #0xad, lsl #12  ; [pp+0xadfd0] AnonymousClosure: (0xb5e4ac), in [package:flutter/src/material/button_style_button.dart] _RenderInputPadding::computeMaxIntrinsicHeight (0xb29eb8)
    //     0xb5e498: ldr             x1, [x1, #0xfd0]
    // 0xb5e49c: r0 = AllocateClosure()
    //     0xb5e49c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e4a0: LeaveFrame
    //     0xb5e4a0: mov             SP, fp
    //     0xb5e4a4: ldp             fp, lr, [SP], #0x10
    // 0xb5e4a8: ret
    //     0xb5e4a8: ret             
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb5e4ac, size: 0x78
    // 0xb5e4ac: EnterFrame
    //     0xb5e4ac: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e4b0: mov             fp, SP
    // 0xb5e4b4: ldr             x0, [fp, #0x18]
    // 0xb5e4b8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb5e4b8: ldur            w1, [x0, #0x17]
    // 0xb5e4bc: DecompressPointer r1
    //     0xb5e4bc: add             x1, x1, HEAP, lsl #32
    // 0xb5e4c0: CheckStackOverflow
    //     0xb5e4c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5e4c4: cmp             SP, x16
    //     0xb5e4c8: b.ls            #0xb5e50c
    // 0xb5e4cc: ldr             x2, [fp, #0x10]
    // 0xb5e4d0: r0 = computeMaxIntrinsicHeight()
    //     0xb5e4d0: bl              #0xb29eb8  ; [package:flutter/src/material/button_style_button.dart] _RenderInputPadding::computeMaxIntrinsicHeight
    // 0xb5e4d4: r0 = inline_Allocate_Double()
    //     0xb5e4d4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb5e4d8: add             x0, x0, #0x10
    //     0xb5e4dc: cmp             x1, x0
    //     0xb5e4e0: b.ls            #0xb5e514
    //     0xb5e4e4: str             x0, [THR, #0x60]  ; THR::top
    //     0xb5e4e8: sub             x0, x0, #0xf
    //     0xb5e4ec: mov             x1, #0xe19c
    //     0xb5e4f0: movk            x1, #3, lsl #16
    //     0xb5e4f4: stur            x1, [x0, #-1]
    // 0xb5e4f8: dmb             ishst
    // 0xb5e4fc: StoreField: r0->field_7 = d0
    //     0xb5e4fc: stur            d0, [x0, #7]
    // 0xb5e500: LeaveFrame
    //     0xb5e500: mov             SP, fp
    //     0xb5e504: ldp             fp, lr, [SP], #0x10
    // 0xb5e508: ret
    //     0xb5e508: ret             
    // 0xb5e50c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5e50c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5e510: b               #0xb5e4cc
    // 0xb5e514: SaveReg d0
    //     0xb5e514: str             q0, [SP, #-0x10]!
    // 0xb5e518: r0 = AllocateDouble()
    //     0xb5e518: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb5e51c: RestoreReg d0
    //     0xb5e51c: ldr             q0, [SP], #0x10
    // 0xb5e520: b               #0xb5e4fc
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb60c34, size: 0x150
    // 0xb60c34: EnterFrame
    //     0xb60c34: stp             fp, lr, [SP, #-0x10]!
    //     0xb60c38: mov             fp, SP
    // 0xb60c3c: AllocStack(0x20)
    //     0xb60c3c: sub             SP, SP, #0x20
    // 0xb60c40: SetupParameters(_RenderInputPadding this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb60c40: mov             x5, x1
    //     0xb60c44: mov             x4, x2
    //     0xb60c48: stur            x1, [fp, #-8]
    //     0xb60c4c: stur            x2, [fp, #-0x10]
    //     0xb60c50: stur            x3, [fp, #-0x18]
    // 0xb60c54: CheckStackOverflow
    //     0xb60c54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb60c58: cmp             SP, x16
    //     0xb60c5c: b.ls            #0xb60d6c
    // 0xb60c60: mov             x0, x4
    // 0xb60c64: r2 = Null
    //     0xb60c64: mov             x2, NULL
    // 0xb60c68: r1 = Null
    //     0xb60c68: mov             x1, NULL
    // 0xb60c6c: r4 = 60
    //     0xb60c6c: mov             x4, #0x3c
    // 0xb60c70: branchIfSmi(r0, 0xb60c7c)
    //     0xb60c70: tbz             w0, #0, #0xb60c7c
    // 0xb60c74: r4 = LoadClassIdInstr(r0)
    //     0xb60c74: ldur            x4, [x0, #-1]
    //     0xb60c78: ubfx            x4, x4, #0xc, #0x14
    // 0xb60c7c: sub             x4, x4, #0xb46
    // 0xb60c80: cmp             x4, #1
    // 0xb60c84: b.ls            #0xb60c98
    // 0xb60c88: r8 = BoxConstraints
    //     0xb60c88: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb60c8c: r3 = Null
    //     0xb60c8c: add             x3, PP, #0xae, lsl #12  ; [pp+0xae018] Null
    //     0xb60c90: ldr             x3, [x3, #0x18]
    // 0xb60c94: r0 = BoxConstraints()
    //     0xb60c94: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb60c98: ldur            x0, [fp, #-8]
    // 0xb60c9c: LoadField: r4 = r0->field_4f
    //     0xb60c9c: ldur            w4, [x0, #0x4f]
    // 0xb60ca0: DecompressPointer r4
    //     0xb60ca0: add             x4, x4, HEAP, lsl #32
    // 0xb60ca4: stur            x4, [fp, #-0x20]
    // 0xb60ca8: cmp             w4, NULL
    // 0xb60cac: b.ne            #0xb60cc0
    // 0xb60cb0: r0 = Null
    //     0xb60cb0: mov             x0, NULL
    // 0xb60cb4: LeaveFrame
    //     0xb60cb4: mov             SP, fp
    //     0xb60cb8: ldp             fp, lr, [SP], #0x10
    // 0xb60cbc: ret
    //     0xb60cbc: ret             
    // 0xb60cc0: mov             x1, x4
    // 0xb60cc4: ldur            x2, [fp, #-0x10]
    // 0xb60cc8: ldur            x3, [fp, #-0x18]
    // 0xb60ccc: r0 = getDryBaseline()
    //     0xb60ccc: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb60cd0: stur            x0, [fp, #-0x18]
    // 0xb60cd4: cmp             w0, NULL
    // 0xb60cd8: b.ne            #0xb60cec
    // 0xb60cdc: r0 = Null
    //     0xb60cdc: mov             x0, NULL
    // 0xb60ce0: LeaveFrame
    //     0xb60ce0: mov             SP, fp
    //     0xb60ce4: ldp             fp, lr, [SP], #0x10
    // 0xb60ce8: ret
    //     0xb60ce8: ret             
    // 0xb60cec: ldur            x1, [fp, #-0x20]
    // 0xb60cf0: ldur            x2, [fp, #-0x10]
    // 0xb60cf4: r0 = getDryLayout()
    //     0xb60cf4: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb60cf8: ldur            x1, [fp, #-8]
    // 0xb60cfc: ldur            x2, [fp, #-0x10]
    // 0xb60d00: stur            x0, [fp, #-8]
    // 0xb60d04: r0 = getDryLayout()
    //     0xb60d04: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb60d08: mov             x1, x0
    // 0xb60d0c: ldur            x2, [fp, #-8]
    // 0xb60d10: r0 = -()
    //     0xb60d10: bl              #0x81d2c0  ; [dart:ui] Size::-
    // 0xb60d14: mov             x2, x0
    // 0xb60d18: r1 = Instance_Alignment
    //     0xb60d18: add             x1, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xb60d1c: ldr             x1, [x1, #0xb80]
    // 0xb60d20: r0 = alongOffset()
    //     0xb60d20: bl              #0xb5f054  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0xb60d24: LoadField: d0 = r0->field_f
    //     0xb60d24: ldur            d0, [x0, #0xf]
    // 0xb60d28: ldur            x1, [fp, #-0x18]
    // 0xb60d2c: LoadField: d1 = r1->field_7
    //     0xb60d2c: ldur            d1, [x1, #7]
    // 0xb60d30: fadd            d2, d1, d0
    // 0xb60d34: r0 = inline_Allocate_Double()
    //     0xb60d34: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb60d38: add             x0, x0, #0x10
    //     0xb60d3c: cmp             x1, x0
    //     0xb60d40: b.ls            #0xb60d74
    //     0xb60d44: str             x0, [THR, #0x60]  ; THR::top
    //     0xb60d48: sub             x0, x0, #0xf
    //     0xb60d4c: mov             x1, #0xe19c
    //     0xb60d50: movk            x1, #3, lsl #16
    //     0xb60d54: stur            x1, [x0, #-1]
    // 0xb60d58: dmb             ishst
    // 0xb60d5c: StoreField: r0->field_7 = d2
    //     0xb60d5c: stur            d2, [x0, #7]
    // 0xb60d60: LeaveFrame
    //     0xb60d60: mov             SP, fp
    //     0xb60d64: ldp             fp, lr, [SP], #0x10
    // 0xb60d68: ret
    //     0xb60d68: ret             
    // 0xb60d6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb60d6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb60d70: b               #0xb60c60
    // 0xb60d74: SaveReg d2
    //     0xb60d74: str             q2, [SP, #-0x10]!
    // 0xb60d78: r0 = AllocateDouble()
    //     0xb60d78: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb60d7c: RestoreReg d2
    //     0xb60d7c: ldr             q2, [SP], #0x10
    // 0xb60d80: b               #0xb60d5c
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbbc8dc, size: 0x194
    // 0xbbc8dc: EnterFrame
    //     0xbbc8dc: stp             fp, lr, [SP, #-0x10]!
    //     0xbbc8e0: mov             fp, SP
    // 0xbbc8e4: AllocStack(0x18)
    //     0xbbc8e4: sub             SP, SP, #0x18
    // 0xbbc8e8: SetupParameters(_RenderInputPadding this /* r1 => r3, fp-0x10 */)
    //     0xbbc8e8: mov             x3, x1
    //     0xbbc8ec: stur            x1, [fp, #-0x10]
    // 0xbbc8f0: CheckStackOverflow
    //     0xbbc8f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbc8f4: cmp             SP, x16
    //     0xbbc8f8: b.ls            #0xbbca60
    // 0xbbc8fc: LoadField: r4 = r3->field_27
    //     0xbbc8fc: ldur            w4, [x3, #0x27]
    // 0xbbc900: DecompressPointer r4
    //     0xbbc900: add             x4, x4, HEAP, lsl #32
    // 0xbbc904: stur            x4, [fp, #-8]
    // 0xbbc908: cmp             w4, NULL
    // 0xbbc90c: b.eq            #0xbbca44
    // 0xbbc910: mov             x0, x4
    // 0xbbc914: r2 = Null
    //     0xbbc914: mov             x2, NULL
    // 0xbbc918: r1 = Null
    //     0xbbc918: mov             x1, NULL
    // 0xbbc91c: r4 = LoadClassIdInstr(r0)
    //     0xbbc91c: ldur            x4, [x0, #-1]
    //     0xbbc920: ubfx            x4, x4, #0xc, #0x14
    // 0xbbc924: sub             x4, x4, #0xb46
    // 0xbbc928: cmp             x4, #1
    // 0xbbc92c: b.ls            #0xbbc940
    // 0xbbc930: r8 = BoxConstraints
    //     0xbbc930: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbc934: r3 = Null
    //     0xbbc934: add             x3, PP, #0xad, lsl #12  ; [pp+0xadff8] Null
    //     0xbbc938: ldr             x3, [x3, #0xff8]
    // 0xbbc93c: r0 = BoxConstraints()
    //     0xbbc93c: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbc940: ldur            x1, [fp, #-0x10]
    // 0xbbc944: ldur            x2, [fp, #-8]
    // 0xbbc948: r3 = Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static.
    //     0xbbc948: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e4f8] Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static. (0x7f2adaa34e18)
    //     0xbbc94c: ldr             x3, [x3, #0x4f8]
    // 0xbbc950: r0 = _computeSize()
    //     0xbbc950: bl              #0xb4d7e8  ; [package:flutter/src/material/button.dart] _RenderInputPadding::_computeSize
    // 0xbbc954: ldur            x3, [fp, #-0x10]
    // 0xbbc958: StoreField: r3->field_4b = r0
    //     0xbbc958: stur            w0, [x3, #0x4b]
    //     0xbbc95c: ldurb           w16, [x3, #-1]
    //     0xbbc960: ldurb           w17, [x0, #-1]
    //     0xbbc964: and             x16, x17, x16, lsr #2
    //     0xbbc968: tst             x16, HEAP, lsr #32
    //     0xbbc96c: b.eq            #0xbbc974
    //     0xbbc970: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbbc974: LoadField: r0 = r3->field_4f
    //     0xbbc974: ldur            w0, [x3, #0x4f]
    // 0xbbc978: DecompressPointer r0
    //     0xbbc978: add             x0, x0, HEAP, lsl #32
    // 0xbbc97c: cmp             w0, NULL
    // 0xbbc980: b.eq            #0xbbca34
    // 0xbbc984: LoadField: r4 = r0->field_7
    //     0xbbc984: ldur            w4, [x0, #7]
    // 0xbbc988: DecompressPointer r4
    //     0xbbc988: add             x4, x4, HEAP, lsl #32
    // 0xbbc98c: stur            x4, [fp, #-8]
    // 0xbbc990: cmp             w4, NULL
    // 0xbbc994: b.eq            #0xbbca68
    // 0xbbc998: mov             x0, x4
    // 0xbbc99c: r2 = Null
    //     0xbbc99c: mov             x2, NULL
    // 0xbbc9a0: r1 = Null
    //     0xbbc9a0: mov             x1, NULL
    // 0xbbc9a4: r4 = LoadClassIdInstr(r0)
    //     0xbbc9a4: ldur            x4, [x0, #-1]
    //     0xbbc9a8: ubfx            x4, x4, #0xc, #0x14
    // 0xbbc9ac: r17 = -4190
    //     0xbbc9ac: mov             x17, #-0x105e
    // 0xbbc9b0: add             x4, x4, x17
    // 0xbbc9b4: cmp             x4, #0x17
    // 0xbbc9b8: b.ls            #0xbbc9d0
    // 0xbbc9bc: r8 = BoxParentData
    //     0xbbc9bc: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0xbbc9c0: ldr             x8, [x8, #0x5e8]
    // 0xbbc9c4: r3 = Null
    //     0xbbc9c4: add             x3, PP, #0xae, lsl #12  ; [pp+0xae008] Null
    //     0xbbc9c8: ldr             x3, [x3, #8]
    // 0xbbc9cc: r0 = DefaultTypeTest()
    //     0xbbc9cc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbbc9d0: ldur            x1, [fp, #-0x10]
    // 0xbbc9d4: r0 = size()
    //     0xbbc9d4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbc9d8: mov             x2, x0
    // 0xbbc9dc: ldur            x0, [fp, #-0x10]
    // 0xbbc9e0: stur            x2, [fp, #-0x18]
    // 0xbbc9e4: LoadField: r1 = r0->field_4f
    //     0xbbc9e4: ldur            w1, [x0, #0x4f]
    // 0xbbc9e8: DecompressPointer r1
    //     0xbbc9e8: add             x1, x1, HEAP, lsl #32
    // 0xbbc9ec: cmp             w1, NULL
    // 0xbbc9f0: b.eq            #0xbbca6c
    // 0xbbc9f4: r0 = size()
    //     0xbbc9f4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbc9f8: ldur            x1, [fp, #-0x18]
    // 0xbbc9fc: mov             x2, x0
    // 0xbbca00: r0 = -()
    //     0xbbca00: bl              #0x81d2c0  ; [dart:ui] Size::-
    // 0xbbca04: mov             x2, x0
    // 0xbbca08: r1 = Instance_Alignment
    //     0xbbca08: add             x1, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xbbca0c: ldr             x1, [x1, #0xb80]
    // 0xbbca10: r0 = alongOffset()
    //     0xbbca10: bl              #0xb5f054  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0xbbca14: ldur            x1, [fp, #-8]
    // 0xbbca18: StoreField: r1->field_7 = r0
    //     0xbbca18: stur            w0, [x1, #7]
    //     0xbbca1c: ldurb           w16, [x1, #-1]
    //     0xbbca20: ldurb           w17, [x0, #-1]
    //     0xbbca24: and             x16, x17, x16, lsr #2
    //     0xbbca28: tst             x16, HEAP, lsr #32
    //     0xbbca2c: b.eq            #0xbbca34
    //     0xbbca30: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbca34: r0 = Null
    //     0xbbca34: mov             x0, NULL
    // 0xbbca38: LeaveFrame
    //     0xbbca38: mov             SP, fp
    //     0xbbca3c: ldp             fp, lr, [SP], #0x10
    // 0xbbca40: ret
    //     0xbbca40: ret             
    // 0xbbca44: r0 = StateError()
    //     0xbbca44: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbca48: mov             x1, x0
    // 0xbbca4c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbca4c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbca50: StoreField: r1->field_b = r0
    //     0xbbca50: stur            w0, [x1, #0xb]
    // 0xbbca54: mov             x0, x1
    // 0xbbca58: r0 = Throw()
    //     0xbbca58: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbca5c: brk             #0
    // 0xbbca60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbca60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbca64: b               #0xbbc8fc
    // 0xbbca68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbca68: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbca6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbca6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ minSize=(/* No info */) {
    // ** addr: 0xcf4938, size: 0x88
    // 0xcf4938: EnterFrame
    //     0xcf4938: stp             fp, lr, [SP, #-0x10]!
    //     0xcf493c: mov             fp, SP
    // 0xcf4940: mov             x0, x2
    // 0xcf4944: CheckStackOverflow
    //     0xcf4944: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf4948: cmp             SP, x16
    //     0xcf494c: b.ls            #0xcf49b8
    // 0xcf4950: LoadField: r2 = r1->field_53
    //     0xcf4950: ldur            w2, [x1, #0x53]
    // 0xcf4954: DecompressPointer r2
    //     0xcf4954: add             x2, x2, HEAP, lsl #32
    // 0xcf4958: LoadField: d0 = r0->field_7
    //     0xcf4958: ldur            d0, [x0, #7]
    // 0xcf495c: LoadField: d1 = r2->field_7
    //     0xcf495c: ldur            d1, [x2, #7]
    // 0xcf4960: fcmp            d0, d1
    // 0xcf4964: b.ne            #0xcf4988
    // 0xcf4968: LoadField: d0 = r0->field_f
    //     0xcf4968: ldur            d0, [x0, #0xf]
    // 0xcf496c: LoadField: d1 = r2->field_f
    //     0xcf496c: ldur            d1, [x2, #0xf]
    // 0xcf4970: fcmp            d0, d1
    // 0xcf4974: b.ne            #0xcf4988
    // 0xcf4978: r0 = Null
    //     0xcf4978: mov             x0, NULL
    // 0xcf497c: LeaveFrame
    //     0xcf497c: mov             SP, fp
    //     0xcf4980: ldp             fp, lr, [SP], #0x10
    // 0xcf4984: ret
    //     0xcf4984: ret             
    // 0xcf4988: StoreField: r1->field_53 = r0
    //     0xcf4988: stur            w0, [x1, #0x53]
    //     0xcf498c: ldurb           w16, [x1, #-1]
    //     0xcf4990: ldurb           w17, [x0, #-1]
    //     0xcf4994: and             x16, x17, x16, lsr #2
    //     0xcf4998: tst             x16, HEAP, lsr #32
    //     0xcf499c: b.eq            #0xcf49a4
    //     0xcf49a0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf49a4: r0 = markNeedsLayout()
    //     0xcf49a4: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf49a8: r0 = Null
    //     0xcf49a8: mov             x0, NULL
    // 0xcf49ac: LeaveFrame
    //     0xcf49ac: mov             SP, fp
    //     0xcf49b0: ldp             fp, lr, [SP], #0x10
    // 0xcf49b4: ret
    //     0xcf49b4: ret             
    // 0xcf49b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf49b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf49bc: b               #0xcf4950
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10efc94, size: 0x24
    // 0x10efc94: EnterFrame
    //     0x10efc94: stp             fp, lr, [SP, #-0x10]!
    //     0x10efc98: mov             fp, SP
    // 0x10efc9c: ldr             x2, [fp, #0x10]
    // 0x10efca0: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10efca0: add             x1, PP, #0xad, lsl #12  ; [pp+0xadfe0] AnonymousClosure: (0x10efcb8), in [package:flutter/src/material/button_style_button.dart] _RenderInputPadding::computeMinIntrinsicHeight (0xb2328c)
    //     0x10efca4: ldr             x1, [x1, #0xfe0]
    // 0x10efca8: r0 = AllocateClosure()
    //     0x10efca8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10efcac: LeaveFrame
    //     0x10efcac: mov             SP, fp
    //     0x10efcb0: ldp             fp, lr, [SP], #0x10
    // 0x10efcb4: ret
    //     0x10efcb4: ret             
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x10efcb8, size: 0x78
    // 0x10efcb8: EnterFrame
    //     0x10efcb8: stp             fp, lr, [SP, #-0x10]!
    //     0x10efcbc: mov             fp, SP
    // 0x10efcc0: ldr             x0, [fp, #0x18]
    // 0x10efcc4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10efcc4: ldur            w1, [x0, #0x17]
    // 0x10efcc8: DecompressPointer r1
    //     0x10efcc8: add             x1, x1, HEAP, lsl #32
    // 0x10efccc: CheckStackOverflow
    //     0x10efccc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10efcd0: cmp             SP, x16
    //     0x10efcd4: b.ls            #0x10efd18
    // 0x10efcd8: ldr             x2, [fp, #0x10]
    // 0x10efcdc: r0 = computeMinIntrinsicHeight()
    //     0x10efcdc: bl              #0xb2328c  ; [package:flutter/src/material/button_style_button.dart] _RenderInputPadding::computeMinIntrinsicHeight
    // 0x10efce0: r0 = inline_Allocate_Double()
    //     0x10efce0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x10efce4: add             x0, x0, #0x10
    //     0x10efce8: cmp             x1, x0
    //     0x10efcec: b.ls            #0x10efd20
    //     0x10efcf0: str             x0, [THR, #0x60]  ; THR::top
    //     0x10efcf4: sub             x0, x0, #0xf
    //     0x10efcf8: mov             x1, #0xe19c
    //     0x10efcfc: movk            x1, #3, lsl #16
    //     0x10efd00: stur            x1, [x0, #-1]
    // 0x10efd04: dmb             ishst
    // 0x10efd08: StoreField: r0->field_7 = d0
    //     0x10efd08: stur            d0, [x0, #7]
    // 0x10efd0c: LeaveFrame
    //     0x10efd0c: mov             SP, fp
    //     0x10efd10: ldp             fp, lr, [SP], #0x10
    // 0x10efd14: ret
    //     0x10efd14: ret             
    // 0x10efd18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10efd18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10efd1c: b               #0x10efcd8
    // 0x10efd20: SaveReg d0
    //     0x10efd20: str             q0, [SP, #-0x10]!
    // 0x10efd24: r0 = AllocateDouble()
    //     0x10efd24: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10efd28: RestoreReg d0
    //     0x10efd28: ldr             q0, [SP], #0x10
    // 0x10efd2c: b               #0x10efd08
  }
}

// class id: 5778, size: 0x18, field offset: 0x18
class _RawMaterialButtonState extends _MixinApplication13&State&MaterialStateMixin {

  _ build(/* No info */) {
    // ** addr: 0xd0bf24, size: 0x628
    // 0xd0bf24: EnterFrame
    //     0xd0bf24: stp             fp, lr, [SP, #-0x10]!
    //     0xd0bf28: mov             fp, SP
    // 0xd0bf2c: AllocStack(0xd0)
    //     0xd0bf2c: sub             SP, SP, #0xd0
    // 0xd0bf30: SetupParameters(_RawMaterialButtonState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd0bf30: mov             x0, x1
    //     0xd0bf34: stur            x1, [fp, #-8]
    //     0xd0bf38: mov             x1, x2
    //     0xd0bf3c: stur            x2, [fp, #-0x10]
    // 0xd0bf40: CheckStackOverflow
    //     0xd0bf40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0bf44: cmp             SP, x16
    //     0xd0bf48: b.ls            #0xd0c51c
    // 0xd0bf4c: LoadField: r2 = r0->field_b
    //     0xd0bf4c: ldur            w2, [x0, #0xb]
    // 0xd0bf50: DecompressPointer r2
    //     0xd0bf50: add             x2, x2, HEAP, lsl #32
    // 0xd0bf54: cmp             w2, NULL
    // 0xd0bf58: b.eq            #0xd0c524
    // 0xd0bf5c: LoadField: r3 = r2->field_1b
    //     0xd0bf5c: ldur            w3, [x2, #0x1b]
    // 0xd0bf60: DecompressPointer r3
    //     0xd0bf60: add             x3, x3, HEAP, lsl #32
    // 0xd0bf64: cmp             w3, NULL
    // 0xd0bf68: b.ne            #0xd0bf74
    // 0xd0bf6c: r2 = Null
    //     0xd0bf6c: mov             x2, NULL
    // 0xd0bf70: b               #0xd0bf7c
    // 0xd0bf74: LoadField: r2 = r3->field_b
    //     0xd0bf74: ldur            w2, [x3, #0xb]
    // 0xd0bf78: DecompressPointer r2
    //     0xd0bf78: add             x2, x2, HEAP, lsl #32
    // 0xd0bf7c: LoadField: r3 = r0->field_13
    //     0xd0bf7c: ldur            w3, [x0, #0x13]
    // 0xd0bf80: DecompressPointer r3
    //     0xd0bf80: add             x3, x3, HEAP, lsl #32
    // 0xd0bf84: r16 = <Color?>
    //     0xd0bf84: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd0bf88: ldr             x16, [x16, #0xa40]
    // 0xd0bf8c: stp             x2, x16, [SP, #8]
    // 0xd0bf90: str             x3, [SP]
    // 0xd0bf94: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd0bf94: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd0bf98: r0 = resolveAs()
    //     0xd0bf98: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xd0bf9c: ldur            x1, [fp, #-8]
    // 0xd0bfa0: stur            x0, [fp, #-0x18]
    // 0xd0bfa4: LoadField: r2 = r1->field_b
    //     0xd0bfa4: ldur            w2, [x1, #0xb]
    // 0xd0bfa8: DecompressPointer r2
    //     0xd0bfa8: add             x2, x2, HEAP, lsl #32
    // 0xd0bfac: cmp             w2, NULL
    // 0xd0bfb0: b.eq            #0xd0c528
    // 0xd0bfb4: LoadField: r3 = r2->field_67
    //     0xd0bfb4: ldur            w3, [x2, #0x67]
    // 0xd0bfb8: DecompressPointer r3
    //     0xd0bfb8: add             x3, x3, HEAP, lsl #32
    // 0xd0bfbc: LoadField: r2 = r1->field_13
    //     0xd0bfbc: ldur            w2, [x1, #0x13]
    // 0xd0bfc0: DecompressPointer r2
    //     0xd0bfc0: add             x2, x2, HEAP, lsl #32
    // 0xd0bfc4: r16 = <ShapeBorder?>
    //     0xd0bfc4: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c960] TypeArguments: <ShapeBorder?>
    //     0xd0bfc8: ldr             x16, [x16, #0x960]
    // 0xd0bfcc: stp             x3, x16, [SP, #8]
    // 0xd0bfd0: str             x2, [SP]
    // 0xd0bfd4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd0bfd4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd0bfd8: r0 = resolveAs()
    //     0xd0bfd8: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xd0bfdc: mov             x2, x0
    // 0xd0bfe0: ldur            x0, [fp, #-8]
    // 0xd0bfe4: stur            x2, [fp, #-0x20]
    // 0xd0bfe8: LoadField: r1 = r0->field_b
    //     0xd0bfe8: ldur            w1, [x0, #0xb]
    // 0xd0bfec: DecompressPointer r1
    //     0xd0bfec: add             x1, x1, HEAP, lsl #32
    // 0xd0bff0: cmp             w1, NULL
    // 0xd0bff4: b.eq            #0xd0c52c
    // 0xd0bff8: r1 = Instance_VisualDensity
    //     0xd0bff8: add             x1, PP, #0x12, lsl #12  ; [pp+0x12ef0] Obj!VisualDensity@12b1d61
    //     0xd0bffc: ldr             x1, [x1, #0xef0]
    // 0xd0c000: r0 = baseSizeAdjustment()
    //     0xd0c000: bl              #0xb2496c  ; [package:flutter/src/material/theme_data.dart] VisualDensity::baseSizeAdjustment
    // 0xd0c004: mov             x3, x0
    // 0xd0c008: ldur            x0, [fp, #-8]
    // 0xd0c00c: stur            x3, [fp, #-0x28]
    // 0xd0c010: LoadField: r1 = r0->field_b
    //     0xd0c010: ldur            w1, [x0, #0xb]
    // 0xd0c014: DecompressPointer r1
    //     0xd0c014: add             x1, x1, HEAP, lsl #32
    // 0xd0c018: cmp             w1, NULL
    // 0xd0c01c: b.eq            #0xd0c530
    // 0xd0c020: LoadField: r2 = r1->field_63
    //     0xd0c020: ldur            w2, [x1, #0x63]
    // 0xd0c024: DecompressPointer r2
    //     0xd0c024: add             x2, x2, HEAP, lsl #32
    // 0xd0c028: r1 = Instance_VisualDensity
    //     0xd0c028: add             x1, PP, #0x12, lsl #12  ; [pp+0x12ef0] Obj!VisualDensity@12b1d61
    //     0xd0c02c: ldr             x1, [x1, #0xef0]
    // 0xd0c030: r0 = effectiveConstraints()
    //     0xd0c030: bl              #0xd0cad0  ; [package:flutter/src/material/theme_data.dart] VisualDensity::effectiveConstraints
    // 0xd0c034: ldur            x1, [fp, #-8]
    // 0xd0c038: stur            x0, [fp, #-0x30]
    // 0xd0c03c: LoadField: r2 = r1->field_b
    //     0xd0c03c: ldur            w2, [x1, #0xb]
    // 0xd0c040: DecompressPointer r2
    //     0xd0c040: add             x2, x2, HEAP, lsl #32
    // 0xd0c044: cmp             w2, NULL
    // 0xd0c048: b.eq            #0xd0c534
    // 0xd0c04c: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xd0c04c: ldur            w3, [x2, #0x17]
    // 0xd0c050: DecompressPointer r3
    //     0xd0c050: add             x3, x3, HEAP, lsl #32
    // 0xd0c054: cmp             w3, NULL
    // 0xd0c058: b.ne            #0xd0c064
    // 0xd0c05c: r3 = Instance__WidgetStateMouseCursor
    //     0xd0c05c: add             x3, PP, #0x80, lsl #12  ; [pp+0x80c18] Obj!_WidgetStateMouseCursor@12b3251
    //     0xd0c060: ldr             x3, [x3, #0xc18]
    // 0xd0c064: ldur            x2, [fp, #-0x28]
    // 0xd0c068: LoadField: r4 = r1->field_13
    //     0xd0c068: ldur            w4, [x1, #0x13]
    // 0xd0c06c: DecompressPointer r4
    //     0xd0c06c: add             x4, x4, HEAP, lsl #32
    // 0xd0c070: r16 = <MouseCursor?>
    //     0xd0c070: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ab8] TypeArguments: <MouseCursor?>
    //     0xd0c074: ldr             x16, [x16, #0xab8]
    // 0xd0c078: stp             x3, x16, [SP, #8]
    // 0xd0c07c: str             x4, [SP]
    // 0xd0c080: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd0c080: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd0c084: r0 = resolveAs()
    //     0xd0c084: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xd0c088: ldur            x1, [fp, #-8]
    // 0xd0c08c: stur            x0, [fp, #-0x38]
    // 0xd0c090: LoadField: r2 = r1->field_b
    //     0xd0c090: ldur            w2, [x1, #0xb]
    // 0xd0c094: DecompressPointer r2
    //     0xd0c094: add             x2, x2, HEAP, lsl #32
    // 0xd0c098: cmp             w2, NULL
    // 0xd0c09c: b.eq            #0xd0c538
    // 0xd0c0a0: ldur            x2, [fp, #-0x28]
    // 0xd0c0a4: LoadField: d0 = r2->field_7
    //     0xd0c0a4: ldur            d0, [x2, #7]
    // 0xd0c0a8: stur            d0, [fp, #-0xa8]
    // 0xd0c0ac: LoadField: d1 = r2->field_f
    //     0xd0c0ac: ldur            d1, [x2, #0xf]
    // 0xd0c0b0: stur            d1, [fp, #-0xa0]
    // 0xd0c0b4: r0 = EdgeInsets()
    //     0xd0c0b4: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xd0c0b8: ldur            d0, [fp, #-0xa8]
    // 0xd0c0bc: StoreField: r0->field_7 = d0
    //     0xd0c0bc: stur            d0, [x0, #7]
    // 0xd0c0c0: ldur            d1, [fp, #-0xa0]
    // 0xd0c0c4: StoreField: r0->field_f = d1
    //     0xd0c0c4: stur            d1, [x0, #0xf]
    // 0xd0c0c8: ArrayStore: r0[0] = d0  ; List_8
    //     0xd0c0c8: stur            d0, [x0, #0x17]
    // 0xd0c0cc: StoreField: r0->field_1f = d1
    //     0xd0c0cc: stur            d1, [x0, #0x1f]
    // 0xd0c0d0: mov             x2, x0
    // 0xd0c0d4: r1 = Instance_EdgeInsets
    //     0xd0c0d4: ldr             x1, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xd0c0d8: r0 = +()
    //     0xd0c0d8: bl              #0x8584ec  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::+
    // 0xd0c0dc: mov             x1, x0
    // 0xd0c0e0: r0 = clamp()
    //     0xd0c0e0: bl              #0x1300ff4  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::clamp
    // 0xd0c0e4: ldur            x1, [fp, #-8]
    // 0xd0c0e8: stur            x0, [fp, #-0x28]
    // 0xd0c0ec: r0 = _effectiveElevation()
    //     0xd0c0ec: bl              #0xd0c8a4  ; [package:flutter/src/material/button.dart] _RawMaterialButtonState::_effectiveElevation
    // 0xd0c0f0: ldur            x0, [fp, #-8]
    // 0xd0c0f4: stur            d0, [fp, #-0xb0]
    // 0xd0c0f8: LoadField: r1 = r0->field_b
    //     0xd0c0f8: ldur            w1, [x0, #0xb]
    // 0xd0c0fc: DecompressPointer r1
    //     0xd0c0fc: add             x1, x1, HEAP, lsl #32
    // 0xd0c100: cmp             w1, NULL
    // 0xd0c104: b.eq            #0xd0c53c
    // 0xd0c108: LoadField: r2 = r1->field_1b
    //     0xd0c108: ldur            w2, [x1, #0x1b]
    // 0xd0c10c: DecompressPointer r2
    //     0xd0c10c: add             x2, x2, HEAP, lsl #32
    // 0xd0c110: cmp             w2, NULL
    // 0xd0c114: b.ne            #0xd0c120
    // 0xd0c118: r2 = Null
    //     0xd0c118: mov             x2, NULL
    // 0xd0c11c: b               #0xd0c140
    // 0xd0c120: ldur            x16, [fp, #-0x18]
    // 0xd0c124: str             x16, [SP]
    // 0xd0c128: mov             x1, x2
    // 0xd0c12c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xd0c12c: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xd0c130: ldr             x4, [x4, #0x7f0]
    // 0xd0c134: r0 = copyWith()
    //     0xd0c134: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xd0c138: mov             x2, x0
    // 0xd0c13c: ldur            x0, [fp, #-8]
    // 0xd0c140: stur            x2, [fp, #-0x48]
    // 0xd0c144: LoadField: r1 = r0->field_b
    //     0xd0c144: ldur            w1, [x0, #0xb]
    // 0xd0c148: DecompressPointer r1
    //     0xd0c148: add             x1, x1, HEAP, lsl #32
    // 0xd0c14c: cmp             w1, NULL
    // 0xd0c150: b.eq            #0xd0c540
    // 0xd0c154: LoadField: r3 = r1->field_1f
    //     0xd0c154: ldur            w3, [x1, #0x1f]
    // 0xd0c158: DecompressPointer r3
    //     0xd0c158: add             x3, x3, HEAP, lsl #32
    // 0xd0c15c: ldur            x1, [fp, #-0x10]
    // 0xd0c160: stur            x3, [fp, #-0x40]
    // 0xd0c164: r0 = of()
    //     0xd0c164: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd0c168: LoadField: r1 = r0->field_2f
    //     0xd0c168: ldur            w1, [x0, #0x2f]
    // 0xd0c16c: DecompressPointer r1
    //     0xd0c16c: add             x1, x1, HEAP, lsl #32
    // 0xd0c170: tbnz            w1, #4, #0xd0c188
    // 0xd0c174: ldur            x1, [fp, #-0x10]
    // 0xd0c178: r0 = of()
    //     0xd0c178: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd0c17c: LoadField: r1 = r0->field_6f
    //     0xd0c17c: ldur            w1, [x0, #0x6f]
    // 0xd0c180: DecompressPointer r1
    //     0xd0c180: add             x1, x1, HEAP, lsl #32
    // 0xd0c184: b               #0xd0c18c
    // 0xd0c188: r1 = Null
    //     0xd0c188: mov             x1, NULL
    // 0xd0c18c: ldur            x0, [fp, #-8]
    // 0xd0c190: stur            x1, [fp, #-0x58]
    // 0xd0c194: LoadField: r2 = r0->field_b
    //     0xd0c194: ldur            w2, [x0, #0xb]
    // 0xd0c198: DecompressPointer r2
    //     0xd0c198: add             x2, x2, HEAP, lsl #32
    // 0xd0c19c: stur            x2, [fp, #-0x50]
    // 0xd0c1a0: cmp             w2, NULL
    // 0xd0c1a4: b.eq            #0xd0c544
    // 0xd0c1a8: LoadField: r3 = r2->field_1f
    //     0xd0c1a8: ldur            w3, [x2, #0x1f]
    // 0xd0c1ac: DecompressPointer r3
    //     0xd0c1ac: add             x3, x3, HEAP, lsl #32
    // 0xd0c1b0: cmp             w3, NULL
    // 0xd0c1b4: b.ne            #0xd0c1c4
    // 0xd0c1b8: r10 = Instance_MaterialType
    //     0xd0c1b8: add             x10, PP, #0x8c, lsl #12  ; [pp+0x8c618] Obj!MaterialType@12c5361
    //     0xd0c1bc: ldr             x10, [x10, #0x618]
    // 0xd0c1c0: b               #0xd0c1cc
    // 0xd0c1c4: r10 = Instance_MaterialType
    //     0xd0c1c4: add             x10, PP, #0x8f, lsl #12  ; [pp+0x8fca8] Obj!MaterialType@12c5381
    //     0xd0c1c8: ldr             x10, [x10, #0xca8]
    // 0xd0c1cc: ldur            x9, [fp, #-0x18]
    // 0xd0c1d0: ldur            x8, [fp, #-0x20]
    // 0xd0c1d4: ldur            x7, [fp, #-0x30]
    // 0xd0c1d8: ldur            x6, [fp, #-0x38]
    // 0xd0c1dc: ldur            x5, [fp, #-0x28]
    // 0xd0c1e0: ldur            d0, [fp, #-0xb0]
    // 0xd0c1e4: ldur            x3, [fp, #-0x48]
    // 0xd0c1e8: ldur            x4, [fp, #-0x40]
    // 0xd0c1ec: stur            x10, [fp, #-0x10]
    // 0xd0c1f0: r1 = 2
    //     0xd0c1f0: mov             x1, #2
    // 0xd0c1f4: r0 = AllocateContext()
    //     0xd0c1f4: bl              #0x13de838  ; AllocateContextStub
    // 0xd0c1f8: mov             x1, x0
    // 0xd0c1fc: ldur            x0, [fp, #-8]
    // 0xd0c200: stur            x1, [fp, #-0x60]
    // 0xd0c204: StoreField: r1->field_f = r0
    //     0xd0c204: stur            w0, [x1, #0xf]
    // 0xd0c208: r2 = Instance_WidgetState
    //     0xd0c208: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd0c20c: ldr             x2, [x2, #0xa60]
    // 0xd0c210: StoreField: r1->field_13 = r2
    //     0xd0c210: stur            w2, [x1, #0x13]
    // 0xd0c214: r1 = 2
    //     0xd0c214: mov             x1, #2
    // 0xd0c218: r0 = AllocateContext()
    //     0xd0c218: bl              #0x13de838  ; AllocateContextStub
    // 0xd0c21c: mov             x1, x0
    // 0xd0c220: ldur            x0, [fp, #-8]
    // 0xd0c224: stur            x1, [fp, #-0x80]
    // 0xd0c228: StoreField: r1->field_f = r0
    //     0xd0c228: stur            w0, [x1, #0xf]
    // 0xd0c22c: r2 = Instance_WidgetState
    //     0xd0c22c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd0c230: ldr             x2, [x2, #0xa48]
    // 0xd0c234: StoreField: r1->field_13 = r2
    //     0xd0c234: stur            w2, [x1, #0x13]
    // 0xd0c238: ldur            x2, [fp, #-0x50]
    // 0xd0c23c: LoadField: r3 = r2->field_2f
    //     0xd0c23c: ldur            w3, [x2, #0x2f]
    // 0xd0c240: DecompressPointer r3
    //     0xd0c240: add             x3, x3, HEAP, lsl #32
    // 0xd0c244: stur            x3, [fp, #-0x78]
    // 0xd0c248: LoadField: r4 = r2->field_23
    //     0xd0c248: ldur            w4, [x2, #0x23]
    // 0xd0c24c: DecompressPointer r4
    //     0xd0c24c: add             x4, x4, HEAP, lsl #32
    // 0xd0c250: stur            x4, [fp, #-0x70]
    // 0xd0c254: LoadField: r5 = r2->field_27
    //     0xd0c254: ldur            w5, [x2, #0x27]
    // 0xd0c258: DecompressPointer r5
    //     0xd0c258: add             x5, x5, HEAP, lsl #32
    // 0xd0c25c: stur            x5, [fp, #-0x68]
    // 0xd0c260: r1 = 2
    //     0xd0c260: mov             x1, #2
    // 0xd0c264: r0 = AllocateContext()
    //     0xd0c264: bl              #0x13de838  ; AllocateContextStub
    // 0xd0c268: mov             x1, x0
    // 0xd0c26c: ldur            x0, [fp, #-8]
    // 0xd0c270: stur            x1, [fp, #-0x90]
    // 0xd0c274: StoreField: r1->field_f = r0
    //     0xd0c274: stur            w0, [x1, #0xf]
    // 0xd0c278: r2 = Instance_WidgetState
    //     0xd0c278: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd0c27c: ldr             x2, [x2, #0xa50]
    // 0xd0c280: StoreField: r1->field_13 = r2
    //     0xd0c280: stur            w2, [x1, #0x13]
    // 0xd0c284: ldur            x2, [fp, #-0x50]
    // 0xd0c288: LoadField: r3 = r2->field_b
    //     0xd0c288: ldur            w3, [x2, #0xb]
    // 0xd0c28c: DecompressPointer r3
    //     0xd0c28c: add             x3, x3, HEAP, lsl #32
    // 0xd0c290: stur            x3, [fp, #-0x88]
    // 0xd0c294: r0 = IconThemeData()
    //     0xd0c294: bl              #0x8ac78c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0xd0c298: mov             x1, x0
    // 0xd0c29c: ldur            x0, [fp, #-0x18]
    // 0xd0c2a0: stur            x1, [fp, #-0x98]
    // 0xd0c2a4: StoreField: r1->field_1b = r0
    //     0xd0c2a4: stur            w0, [x1, #0x1b]
    // 0xd0c2a8: ldur            x0, [fp, #-0x50]
    // 0xd0c2ac: LoadField: r2 = r0->field_6f
    //     0xd0c2ac: ldur            w2, [x0, #0x6f]
    // 0xd0c2b0: DecompressPointer r2
    //     0xd0c2b0: add             x2, x2, HEAP, lsl #32
    // 0xd0c2b4: stur            x2, [fp, #-0x18]
    // 0xd0c2b8: r0 = Center()
    //     0xd0c2b8: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xd0c2bc: mov             x1, x0
    // 0xd0c2c0: r0 = Instance_Alignment
    //     0xd0c2c0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xd0c2c4: ldr             x0, [x0, #0xb80]
    // 0xd0c2c8: stur            x1, [fp, #-0x50]
    // 0xd0c2cc: StoreField: r1->field_f = r0
    //     0xd0c2cc: stur            w0, [x1, #0xf]
    // 0xd0c2d0: r0 = 1.000000
    //     0xd0c2d0: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xd0c2d4: StoreField: r1->field_13 = r0
    //     0xd0c2d4: stur            w0, [x1, #0x13]
    // 0xd0c2d8: ArrayStore: r1[0] = r0  ; List_4
    //     0xd0c2d8: stur            w0, [x1, #0x17]
    // 0xd0c2dc: ldur            x0, [fp, #-0x18]
    // 0xd0c2e0: StoreField: r1->field_b = r0
    //     0xd0c2e0: stur            w0, [x1, #0xb]
    // 0xd0c2e4: r0 = Padding()
    //     0xd0c2e4: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xd0c2e8: mov             x1, x0
    // 0xd0c2ec: ldur            x0, [fp, #-0x28]
    // 0xd0c2f0: StoreField: r1->field_f = r0
    //     0xd0c2f0: stur            w0, [x1, #0xf]
    // 0xd0c2f4: ldur            x0, [fp, #-0x50]
    // 0xd0c2f8: StoreField: r1->field_b = r0
    //     0xd0c2f8: stur            w0, [x1, #0xb]
    // 0xd0c2fc: ldur            x2, [fp, #-0x98]
    // 0xd0c300: r0 = merge()
    //     0xd0c300: bl              #0xd0c588  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::merge
    // 0xd0c304: stur            x0, [fp, #-0x18]
    // 0xd0c308: r0 = InkWell()
    //     0xd0c308: bl              #0xd0c57c  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0xd0c30c: mov             x3, x0
    // 0xd0c310: ldur            x0, [fp, #-0x18]
    // 0xd0c314: stur            x3, [fp, #-0x28]
    // 0xd0c318: StoreField: r3->field_b = r0
    //     0xd0c318: stur            w0, [x3, #0xb]
    // 0xd0c31c: ldur            x0, [fp, #-0x88]
    // 0xd0c320: StoreField: r3->field_f = r0
    //     0xd0c320: stur            w0, [x3, #0xf]
    // 0xd0c324: ldur            x2, [fp, #-0x80]
    // 0xd0c328: r1 = Function '<anonymous closure>':.
    //     0xd0c328: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a350] AnonymousClosure: (0xd0cc58), of [dart:mixin_deduplication] _MixinApplication13&State&MaterialStateMixin
    //     0xd0c32c: ldr             x1, [x1, #0x350]
    // 0xd0c330: r0 = AllocateClosure()
    //     0xd0c330: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0c334: mov             x1, x0
    // 0xd0c338: ldur            x0, [fp, #-0x28]
    // 0xd0c33c: StoreField: r0->field_3b = r1
    //     0xd0c33c: stur            w1, [x0, #0x3b]
    // 0xd0c340: ldur            x2, [fp, #-0x90]
    // 0xd0c344: r1 = Function '<anonymous closure>':.
    //     0xd0c344: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a350] AnonymousClosure: (0xd0cc58), of [dart:mixin_deduplication] _MixinApplication13&State&MaterialStateMixin
    //     0xd0c348: ldr             x1, [x1, #0x350]
    // 0xd0c34c: r0 = AllocateClosure()
    //     0xd0c34c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0c350: mov             x1, x0
    // 0xd0c354: ldur            x0, [fp, #-0x28]
    // 0xd0c358: StoreField: r0->field_3f = r1
    //     0xd0c358: stur            w1, [x0, #0x3f]
    // 0xd0c35c: ldur            x1, [fp, #-0x38]
    // 0xd0c360: StoreField: r0->field_43 = r1
    //     0xd0c360: stur            w1, [x0, #0x43]
    // 0xd0c364: r3 = true
    //     0xd0c364: add             x3, NULL, #0x20  ; true
    // 0xd0c368: StoreField: r0->field_47 = r3
    //     0xd0c368: stur            w3, [x0, #0x47]
    // 0xd0c36c: r1 = Instance_BoxShape
    //     0xd0c36c: add             x1, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xd0c370: ldr             x1, [x1, #0x1f8]
    // 0xd0c374: StoreField: r0->field_4b = r1
    //     0xd0c374: stur            w1, [x0, #0x4b]
    // 0xd0c378: ldur            x4, [fp, #-0x20]
    // 0xd0c37c: StoreField: r0->field_57 = r4
    //     0xd0c37c: stur            w4, [x0, #0x57]
    // 0xd0c380: ldur            x1, [fp, #-0x70]
    // 0xd0c384: StoreField: r0->field_5b = r1
    //     0xd0c384: stur            w1, [x0, #0x5b]
    // 0xd0c388: ldur            x1, [fp, #-0x68]
    // 0xd0c38c: StoreField: r0->field_5f = r1
    //     0xd0c38c: stur            w1, [x0, #0x5f]
    // 0xd0c390: ldur            x1, [fp, #-0x78]
    // 0xd0c394: StoreField: r0->field_6b = r1
    //     0xd0c394: stur            w1, [x0, #0x6b]
    // 0xd0c398: StoreField: r0->field_73 = r3
    //     0xd0c398: stur            w3, [x0, #0x73]
    // 0xd0c39c: r5 = false
    //     0xd0c39c: add             x5, NULL, #0x30  ; false
    // 0xd0c3a0: StoreField: r0->field_77 = r5
    //     0xd0c3a0: stur            w5, [x0, #0x77]
    // 0xd0c3a4: StoreField: r0->field_87 = r3
    //     0xd0c3a4: stur            w3, [x0, #0x87]
    // 0xd0c3a8: ldur            x2, [fp, #-0x60]
    // 0xd0c3ac: r1 = Function '<anonymous closure>':.
    //     0xd0c3ac: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a350] AnonymousClosure: (0xd0cc58), of [dart:mixin_deduplication] _MixinApplication13&State&MaterialStateMixin
    //     0xd0c3b0: ldr             x1, [x1, #0x350]
    // 0xd0c3b4: r0 = AllocateClosure()
    //     0xd0c3b4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd0c3b8: mov             x1, x0
    // 0xd0c3bc: ldur            x0, [fp, #-0x28]
    // 0xd0c3c0: StoreField: r0->field_7b = r1
    //     0xd0c3c0: stur            w1, [x0, #0x7b]
    // 0xd0c3c4: r1 = false
    //     0xd0c3c4: add             x1, NULL, #0x30  ; false
    // 0xd0c3c8: StoreField: r0->field_7f = r1
    //     0xd0c3c8: stur            w1, [x0, #0x7f]
    // 0xd0c3cc: r0 = Material()
    //     0xd0c3cc: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xd0c3d0: mov             x1, x0
    // 0xd0c3d4: ldur            x0, [fp, #-0x10]
    // 0xd0c3d8: stur            x1, [fp, #-0x18]
    // 0xd0c3dc: StoreField: r1->field_f = r0
    //     0xd0c3dc: stur            w0, [x1, #0xf]
    // 0xd0c3e0: ldur            d0, [fp, #-0xb0]
    // 0xd0c3e4: ArrayStore: r1[0] = d0  ; List_8
    //     0xd0c3e4: stur            d0, [x1, #0x17]
    // 0xd0c3e8: ldur            x0, [fp, #-0x40]
    // 0xd0c3ec: StoreField: r1->field_1f = r0
    //     0xd0c3ec: stur            w0, [x1, #0x1f]
    // 0xd0c3f0: ldur            x0, [fp, #-0x58]
    // 0xd0c3f4: StoreField: r1->field_23 = r0
    //     0xd0c3f4: stur            w0, [x1, #0x23]
    // 0xd0c3f8: ldur            x0, [fp, #-0x48]
    // 0xd0c3fc: StoreField: r1->field_2b = r0
    //     0xd0c3fc: stur            w0, [x1, #0x2b]
    // 0xd0c400: ldur            x0, [fp, #-0x20]
    // 0xd0c404: StoreField: r1->field_2f = r0
    //     0xd0c404: stur            w0, [x1, #0x2f]
    // 0xd0c408: r0 = true
    //     0xd0c408: add             x0, NULL, #0x20  ; true
    // 0xd0c40c: StoreField: r1->field_33 = r0
    //     0xd0c40c: stur            w0, [x1, #0x33]
    // 0xd0c410: r0 = Instance_Clip
    //     0xd0c410: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xd0c414: ldr             x0, [x0, #0x840]
    // 0xd0c418: StoreField: r1->field_37 = r0
    //     0xd0c418: stur            w0, [x1, #0x37]
    // 0xd0c41c: r0 = Instance_Duration
    //     0xd0c41c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xd0c420: ldr             x0, [x0, #0x318]
    // 0xd0c424: StoreField: r1->field_3b = r0
    //     0xd0c424: stur            w0, [x1, #0x3b]
    // 0xd0c428: ldur            x0, [fp, #-0x28]
    // 0xd0c42c: StoreField: r1->field_b = r0
    //     0xd0c42c: stur            w0, [x1, #0xb]
    // 0xd0c430: r0 = false
    //     0xd0c430: add             x0, NULL, #0x30  ; false
    // 0xd0c434: StoreField: r1->field_13 = r0
    //     0xd0c434: stur            w0, [x1, #0x13]
    // 0xd0c438: r0 = ConstrainedBox()
    //     0xd0c438: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xd0c43c: mov             x1, x0
    // 0xd0c440: ldur            x0, [fp, #-0x30]
    // 0xd0c444: stur            x1, [fp, #-0x10]
    // 0xd0c448: StoreField: r1->field_f = r0
    //     0xd0c448: stur            w0, [x1, #0xf]
    // 0xd0c44c: ldur            x0, [fp, #-0x18]
    // 0xd0c450: StoreField: r1->field_b = r0
    //     0xd0c450: stur            w0, [x1, #0xb]
    // 0xd0c454: ldur            x0, [fp, #-8]
    // 0xd0c458: LoadField: r2 = r0->field_b
    //     0xd0c458: ldur            w2, [x0, #0xb]
    // 0xd0c45c: DecompressPointer r2
    //     0xd0c45c: add             x2, x2, HEAP, lsl #32
    // 0xd0c460: cmp             w2, NULL
    // 0xd0c464: b.eq            #0xd0c548
    // 0xd0c468: LoadField: r0 = r2->field_73
    //     0xd0c468: ldur            w0, [x2, #0x73]
    // 0xd0c46c: DecompressPointer r0
    //     0xd0c46c: add             x0, x0, HEAP, lsl #32
    // 0xd0c470: LoadField: r2 = r0->field_7
    //     0xd0c470: ldur            x2, [x0, #7]
    // 0xd0c474: cmp             x2, #0
    // 0xd0c478: b.gt            #0xd0c4b4
    // 0xd0c47c: ldur            d0, [fp, #-0xa8]
    // 0xd0c480: ldur            d1, [fp, #-0xa0]
    // 0xd0c484: d2 = 48.000000
    //     0xd0c484: ldr             d2, [PP, #0x5650]  ; [pp+0x5650] IMM: double(48) from 0x4048000000000000
    // 0xd0c488: fadd            d3, d0, d2
    // 0xd0c48c: stur            d3, [fp, #-0xb0]
    // 0xd0c490: fadd            d0, d1, d2
    // 0xd0c494: stur            d0, [fp, #-0xa8]
    // 0xd0c498: r0 = Size()
    //     0xd0c498: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xd0c49c: ldur            d0, [fp, #-0xb0]
    // 0xd0c4a0: StoreField: r0->field_7 = d0
    //     0xd0c4a0: stur            d0, [x0, #7]
    // 0xd0c4a4: ldur            d0, [fp, #-0xa8]
    // 0xd0c4a8: StoreField: r0->field_f = d0
    //     0xd0c4a8: stur            d0, [x0, #0xf]
    // 0xd0c4ac: mov             x1, x0
    // 0xd0c4b0: b               #0xd0c4b8
    // 0xd0c4b4: r1 = Instance_Size
    //     0xd0c4b4: ldr             x1, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xd0c4b8: ldur            x0, [fp, #-0x10]
    // 0xd0c4bc: stur            x1, [fp, #-8]
    // 0xd0c4c0: r0 = _InputPadding()
    //     0xd0c4c0: bl              #0xd0c570  ; Allocate_InputPaddingStub -> _InputPadding (size=0x14)
    // 0xd0c4c4: mov             x1, x0
    // 0xd0c4c8: ldur            x0, [fp, #-8]
    // 0xd0c4cc: stur            x1, [fp, #-0x18]
    // 0xd0c4d0: StoreField: r1->field_f = r0
    //     0xd0c4d0: stur            w0, [x1, #0xf]
    // 0xd0c4d4: ldur            x0, [fp, #-0x10]
    // 0xd0c4d8: StoreField: r1->field_b = r0
    //     0xd0c4d8: stur            w0, [x1, #0xb]
    // 0xd0c4dc: r0 = Semantics()
    //     0xd0c4dc: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xd0c4e0: stur            x0, [fp, #-8]
    // 0xd0c4e4: r16 = true
    //     0xd0c4e4: add             x16, NULL, #0x20  ; true
    // 0xd0c4e8: r30 = true
    //     0xd0c4e8: add             lr, NULL, #0x20  ; true
    // 0xd0c4ec: stp             lr, x16, [SP, #0x10]
    // 0xd0c4f0: r16 = true
    //     0xd0c4f0: add             x16, NULL, #0x20  ; true
    // 0xd0c4f4: ldur            lr, [fp, #-0x18]
    // 0xd0c4f8: stp             lr, x16, [SP]
    // 0xd0c4fc: mov             x1, x0
    // 0xd0c500: r4 = const [0, 0x5, 0x4, 0x1, button, 0x2, child, 0x4, container, 0x1, enabled, 0x3, null]
    //     0xd0c500: add             x4, PP, #0x90, lsl #12  ; [pp+0x90628] List(13) [0, 0x5, 0x4, 0x1, "button", 0x2, "child", 0x4, "container", 0x1, "enabled", 0x3, Null]
    //     0xd0c504: ldr             x4, [x4, #0x628]
    // 0xd0c508: r0 = Semantics()
    //     0xd0c508: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xd0c50c: ldur            x0, [fp, #-8]
    // 0xd0c510: LeaveFrame
    //     0xd0c510: mov             SP, fp
    //     0xd0c514: ldp             fp, lr, [SP], #0x10
    // 0xd0c518: ret
    //     0xd0c518: ret             
    // 0xd0c51c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0c51c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0c520: b               #0xd0bf4c
    // 0xd0c524: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0c524: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0c528: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0c528: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0c52c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0c52c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0c530: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0c530: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0c534: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0c534: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0c538: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0c538: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0c53c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd0c53c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd0c540: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0c540: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0c544: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0c544: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0c548: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0c548: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _effectiveElevation(/* No info */) {
    // ** addr: 0xd0c8a4, size: 0x12c
    // 0xd0c8a4: EnterFrame
    //     0xd0c8a4: stp             fp, lr, [SP, #-0x10]!
    //     0xd0c8a8: mov             fp, SP
    // 0xd0c8ac: AllocStack(0x8)
    //     0xd0c8ac: sub             SP, SP, #8
    // 0xd0c8b0: SetupParameters(_RawMaterialButtonState this /* r1 => r0, fp-0x8 */)
    //     0xd0c8b0: mov             x0, x1
    //     0xd0c8b4: stur            x1, [fp, #-8]
    // 0xd0c8b8: CheckStackOverflow
    //     0xd0c8b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0c8bc: cmp             SP, x16
    //     0xd0c8c0: b.ls            #0xd0c9b4
    // 0xd0c8c4: mov             x1, x0
    // 0xd0c8c8: r0 = isDisabled()
    //     0xd0c8c8: bl              #0xd0ca90  ; [dart:mixin_deduplication] _MixinApplication13&State&MaterialStateMixin::isDisabled
    // 0xd0c8cc: tbnz            w0, #4, #0xd0c8f4
    // 0xd0c8d0: ldur            x0, [fp, #-8]
    // 0xd0c8d4: LoadField: r1 = r0->field_b
    //     0xd0c8d4: ldur            w1, [x0, #0xb]
    // 0xd0c8d8: DecompressPointer r1
    //     0xd0c8d8: add             x1, x1, HEAP, lsl #32
    // 0xd0c8dc: cmp             w1, NULL
    // 0xd0c8e0: b.eq            #0xd0c9bc
    // 0xd0c8e4: LoadField: d0 = r1->field_53
    //     0xd0c8e4: ldur            d0, [x1, #0x53]
    // 0xd0c8e8: LeaveFrame
    //     0xd0c8e8: mov             SP, fp
    //     0xd0c8ec: ldp             fp, lr, [SP], #0x10
    // 0xd0c8f0: ret
    //     0xd0c8f0: ret             
    // 0xd0c8f4: ldur            x0, [fp, #-8]
    // 0xd0c8f8: mov             x1, x0
    // 0xd0c8fc: r0 = isPressed()
    //     0xd0c8fc: bl              #0xd0ca50  ; [dart:mixin_deduplication] _MixinApplication13&State&MaterialStateMixin::isPressed
    // 0xd0c900: tbnz            w0, #4, #0xd0c928
    // 0xd0c904: ldur            x0, [fp, #-8]
    // 0xd0c908: LoadField: r1 = r0->field_b
    //     0xd0c908: ldur            w1, [x0, #0xb]
    // 0xd0c90c: DecompressPointer r1
    //     0xd0c90c: add             x1, x1, HEAP, lsl #32
    // 0xd0c910: cmp             w1, NULL
    // 0xd0c914: b.eq            #0xd0c9c0
    // 0xd0c918: LoadField: d0 = r1->field_4b
    //     0xd0c918: ldur            d0, [x1, #0x4b]
    // 0xd0c91c: LeaveFrame
    //     0xd0c91c: mov             SP, fp
    //     0xd0c920: ldp             fp, lr, [SP], #0x10
    // 0xd0c924: ret
    //     0xd0c924: ret             
    // 0xd0c928: ldur            x0, [fp, #-8]
    // 0xd0c92c: mov             x1, x0
    // 0xd0c930: r0 = isHovered()
    //     0xd0c930: bl              #0xd0ca10  ; [dart:mixin_deduplication] _MixinApplication13&State&MaterialStateMixin::isHovered
    // 0xd0c934: tbnz            w0, #4, #0xd0c95c
    // 0xd0c938: ldur            x0, [fp, #-8]
    // 0xd0c93c: LoadField: r1 = r0->field_b
    //     0xd0c93c: ldur            w1, [x0, #0xb]
    // 0xd0c940: DecompressPointer r1
    //     0xd0c940: add             x1, x1, HEAP, lsl #32
    // 0xd0c944: cmp             w1, NULL
    // 0xd0c948: b.eq            #0xd0c9c4
    // 0xd0c94c: LoadField: d0 = r1->field_3b
    //     0xd0c94c: ldur            d0, [x1, #0x3b]
    // 0xd0c950: LeaveFrame
    //     0xd0c950: mov             SP, fp
    //     0xd0c954: ldp             fp, lr, [SP], #0x10
    // 0xd0c958: ret
    //     0xd0c958: ret             
    // 0xd0c95c: ldur            x0, [fp, #-8]
    // 0xd0c960: mov             x1, x0
    // 0xd0c964: r0 = isFocused()
    //     0xd0c964: bl              #0xd0c9d0  ; [dart:mixin_deduplication] _MixinApplication13&State&MaterialStateMixin::isFocused
    // 0xd0c968: tbnz            w0, #4, #0xd0c990
    // 0xd0c96c: ldur            x0, [fp, #-8]
    // 0xd0c970: LoadField: r1 = r0->field_b
    //     0xd0c970: ldur            w1, [x0, #0xb]
    // 0xd0c974: DecompressPointer r1
    //     0xd0c974: add             x1, x1, HEAP, lsl #32
    // 0xd0c978: cmp             w1, NULL
    // 0xd0c97c: b.eq            #0xd0c9c8
    // 0xd0c980: LoadField: d0 = r1->field_43
    //     0xd0c980: ldur            d0, [x1, #0x43]
    // 0xd0c984: LeaveFrame
    //     0xd0c984: mov             SP, fp
    //     0xd0c988: ldp             fp, lr, [SP], #0x10
    // 0xd0c98c: ret
    //     0xd0c98c: ret             
    // 0xd0c990: ldur            x0, [fp, #-8]
    // 0xd0c994: LoadField: r1 = r0->field_b
    //     0xd0c994: ldur            w1, [x0, #0xb]
    // 0xd0c998: DecompressPointer r1
    //     0xd0c998: add             x1, x1, HEAP, lsl #32
    // 0xd0c99c: cmp             w1, NULL
    // 0xd0c9a0: b.eq            #0xd0c9cc
    // 0xd0c9a4: LoadField: d0 = r1->field_33
    //     0xd0c9a4: ldur            d0, [x1, #0x33]
    // 0xd0c9a8: LeaveFrame
    //     0xd0c9a8: mov             SP, fp
    //     0xd0c9ac: ldp             fp, lr, [SP], #0x10
    // 0xd0c9b0: ret
    //     0xd0c9b0: ret             
    // 0xd0c9b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0c9b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0c9b8: b               #0xd0c8c4
    // 0xd0c9bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0c9bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0c9c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0c9c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0c9c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0c9c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0c9c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0c9c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0c9cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0c9cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf373e4, size: 0x12c
    // 0xf373e4: EnterFrame
    //     0xf373e4: stp             fp, lr, [SP, #-0x10]!
    //     0xf373e8: mov             fp, SP
    // 0xf373ec: AllocStack(0x10)
    //     0xf373ec: sub             SP, SP, #0x10
    // 0xf373f0: SetupParameters(_RawMaterialButtonState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf373f0: mov             x4, x1
    //     0xf373f4: mov             x3, x2
    //     0xf373f8: stur            x1, [fp, #-8]
    //     0xf373fc: stur            x2, [fp, #-0x10]
    // 0xf37400: CheckStackOverflow
    //     0xf37400: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf37404: cmp             SP, x16
    //     0xf37408: b.ls            #0xf37504
    // 0xf3740c: mov             x0, x3
    // 0xf37410: r2 = Null
    //     0xf37410: mov             x2, NULL
    // 0xf37414: r1 = Null
    //     0xf37414: mov             x1, NULL
    // 0xf37418: r4 = 60
    //     0xf37418: mov             x4, #0x3c
    // 0xf3741c: branchIfSmi(r0, 0xf37428)
    //     0xf3741c: tbz             w0, #0, #0xf37428
    // 0xf37420: r4 = LoadClassIdInstr(r0)
    //     0xf37420: ldur            x4, [x0, #-1]
    //     0xf37424: ubfx            x4, x4, #0xc, #0x14
    // 0xf37428: r17 = 6499
    //     0xf37428: mov             x17, #0x1963
    // 0xf3742c: cmp             x4, x17
    // 0xf37430: b.eq            #0xf37448
    // 0xf37434: r8 = RawMaterialButton
    //     0xf37434: add             x8, PP, #0x9a, lsl #12  ; [pp+0x9a368] Type: RawMaterialButton
    //     0xf37438: ldr             x8, [x8, #0x368]
    // 0xf3743c: r3 = Null
    //     0xf3743c: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a370] Null
    //     0xf37440: ldr             x3, [x3, #0x370]
    // 0xf37444: r0 = RawMaterialButton()
    //     0xf37444: bl              #0xd0c54c  ; IsType_RawMaterialButton_Stub
    // 0xf37448: ldur            x3, [fp, #-8]
    // 0xf3744c: LoadField: r2 = r3->field_7
    //     0xf3744c: ldur            w2, [x3, #7]
    // 0xf37450: DecompressPointer r2
    //     0xf37450: add             x2, x2, HEAP, lsl #32
    // 0xf37454: ldur            x0, [fp, #-0x10]
    // 0xf37458: r1 = Null
    //     0xf37458: mov             x1, NULL
    // 0xf3745c: cmp             w2, NULL
    // 0xf37460: b.eq            #0xf37484
    // 0xf37464: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf37464: ldur            w4, [x2, #0x17]
    // 0xf37468: DecompressPointer r4
    //     0xf37468: add             x4, x4, HEAP, lsl #32
    // 0xf3746c: r8 = X0 bound StatefulWidget
    //     0xf3746c: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf37470: ldr             x8, [x8, #0x498]
    // 0xf37474: LoadField: r9 = r4->field_7
    //     0xf37474: ldur            x9, [x4, #7]
    // 0xf37478: r3 = Null
    //     0xf37478: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a380] Null
    //     0xf3747c: ldr             x3, [x3, #0x380]
    // 0xf37480: blr             x9
    // 0xf37484: ldur            x0, [fp, #-8]
    // 0xf37488: LoadField: r1 = r0->field_b
    //     0xf37488: ldur            w1, [x0, #0xb]
    // 0xf3748c: DecompressPointer r1
    //     0xf3748c: add             x1, x1, HEAP, lsl #32
    // 0xf37490: cmp             w1, NULL
    // 0xf37494: b.eq            #0xf3750c
    // 0xf37498: mov             x1, x0
    // 0xf3749c: r2 = Instance_WidgetState
    //     0xf3749c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xf374a0: ldr             x2, [x2, #0xa70]
    // 0xf374a4: r3 = false
    //     0xf374a4: add             x3, NULL, #0x30  ; false
    // 0xf374a8: r0 = setMaterialState()
    //     0xf374a8: bl              #0xd0cce8  ; [dart:mixin_deduplication] _MixinApplication13&State&MaterialStateMixin::setMaterialState
    // 0xf374ac: ldur            x0, [fp, #-8]
    // 0xf374b0: LoadField: r1 = r0->field_13
    //     0xf374b0: ldur            w1, [x0, #0x13]
    // 0xf374b4: DecompressPointer r1
    //     0xf374b4: add             x1, x1, HEAP, lsl #32
    // 0xf374b8: r2 = Instance_WidgetState
    //     0xf374b8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xf374bc: ldr             x2, [x2, #0xa70]
    // 0xf374c0: r0 = contains()
    //     0xf374c0: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xf374c4: tbnz            w0, #4, #0xf374f4
    // 0xf374c8: ldur            x0, [fp, #-8]
    // 0xf374cc: LoadField: r1 = r0->field_13
    //     0xf374cc: ldur            w1, [x0, #0x13]
    // 0xf374d0: DecompressPointer r1
    //     0xf374d0: add             x1, x1, HEAP, lsl #32
    // 0xf374d4: r2 = Instance_WidgetState
    //     0xf374d4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xf374d8: ldr             x2, [x2, #0xa48]
    // 0xf374dc: r0 = contains()
    //     0xf374dc: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xf374e0: tbnz            w0, #4, #0xf374f4
    // 0xf374e4: ldur            x1, [fp, #-8]
    // 0xf374e8: r2 = Instance_WidgetState
    //     0xf374e8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xf374ec: ldr             x2, [x2, #0xa48]
    // 0xf374f0: r0 = removeMaterialState()
    //     0xf374f0: bl              #0xd0cd24  ; [dart:mixin_deduplication] _MixinApplication13&State&MaterialStateMixin::removeMaterialState
    // 0xf374f4: r0 = Null
    //     0xf374f4: mov             x0, NULL
    // 0xf374f8: LeaveFrame
    //     0xf374f8: mov             SP, fp
    //     0xf374fc: ldp             fp, lr, [SP], #0x10
    // 0xf37500: ret
    //     0xf37500: ret             
    // 0xf37504: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf37504: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf37508: b               #0xf3740c
    // 0xf3750c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3750c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf79194, size: 0x50
    // 0xf79194: EnterFrame
    //     0xf79194: stp             fp, lr, [SP, #-0x10]!
    //     0xf79198: mov             fp, SP
    // 0xf7919c: CheckStackOverflow
    //     0xf7919c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf791a0: cmp             SP, x16
    //     0xf791a4: b.ls            #0xf791d8
    // 0xf791a8: LoadField: r0 = r1->field_b
    //     0xf791a8: ldur            w0, [x1, #0xb]
    // 0xf791ac: DecompressPointer r0
    //     0xf791ac: add             x0, x0, HEAP, lsl #32
    // 0xf791b0: cmp             w0, NULL
    // 0xf791b4: b.eq            #0xf791e0
    // 0xf791b8: r2 = Instance_WidgetState
    //     0xf791b8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xf791bc: ldr             x2, [x2, #0xa70]
    // 0xf791c0: r3 = false
    //     0xf791c0: add             x3, NULL, #0x30  ; false
    // 0xf791c4: r0 = setMaterialState()
    //     0xf791c4: bl              #0xd0cce8  ; [dart:mixin_deduplication] _MixinApplication13&State&MaterialStateMixin::setMaterialState
    // 0xf791c8: r0 = Null
    //     0xf791c8: mov             x0, NULL
    // 0xf791cc: LeaveFrame
    //     0xf791cc: mov             SP, fp
    //     0xf791d0: ldp             fp, lr, [SP], #0x10
    // 0xf791d4: ret
    //     0xf791d4: ret             
    // 0xf791d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf791d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf791dc: b               #0xf791a8
    // 0xf791e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf791e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _RawMaterialButtonState(/* No info */) {
    // ** addr: 0xfa0dac, size: 0x90
    // 0xfa0dac: EnterFrame
    //     0xfa0dac: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0db0: mov             fp, SP
    // 0xfa0db4: AllocStack(0x10)
    //     0xfa0db4: sub             SP, SP, #0x10
    // 0xfa0db8: SetupParameters(_RawMaterialButtonState this /* r1 => r0, fp-0x8 */)
    //     0xfa0db8: mov             x0, x1
    //     0xfa0dbc: stur            x1, [fp, #-8]
    // 0xfa0dc0: CheckStackOverflow
    //     0xfa0dc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa0dc4: cmp             SP, x16
    //     0xfa0dc8: b.ls            #0xfa0e34
    // 0xfa0dcc: r1 = <WidgetState>
    //     0xfa0dcc: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a10] TypeArguments: <WidgetState>
    //     0xfa0dd0: ldr             x1, [x1, #0xa10]
    // 0xfa0dd4: r0 = _Set()
    //     0xfa0dd4: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xfa0dd8: mov             x1, x0
    // 0xfa0ddc: stur            x0, [fp, #-0x10]
    // 0xfa0de0: r0 = Shader._()
    //     0xfa0de0: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xfa0de4: ldur            x0, [fp, #-0x10]
    // 0xfa0de8: r1 = _Uint32List
    //     0xfa0de8: ldr             x1, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0xfa0dec: StoreField: r0->field_1b = r1
    //     0xfa0dec: stur            w1, [x0, #0x1b]
    // 0xfa0df0: StoreField: r0->field_b = rZR
    //     0xfa0df0: stur            wzr, [x0, #0xb]
    // 0xfa0df4: r1 = const []
    //     0xfa0df4: ldr             x1, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0xfa0df8: StoreField: r0->field_f = r1
    //     0xfa0df8: stur            w1, [x0, #0xf]
    // 0xfa0dfc: StoreField: r0->field_13 = rZR
    //     0xfa0dfc: stur            wzr, [x0, #0x13]
    // 0xfa0e00: ArrayStore: r0[0] = rZR  ; List_4
    //     0xfa0e00: stur            wzr, [x0, #0x17]
    // 0xfa0e04: ldur            x1, [fp, #-8]
    // 0xfa0e08: StoreField: r1->field_13 = r0
    //     0xfa0e08: stur            w0, [x1, #0x13]
    //     0xfa0e0c: ldurb           w16, [x1, #-1]
    //     0xfa0e10: ldurb           w17, [x0, #-1]
    //     0xfa0e14: and             x16, x17, x16, lsr #2
    //     0xfa0e18: tst             x16, HEAP, lsr #32
    //     0xfa0e1c: b.eq            #0xfa0e24
    //     0xfa0e20: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa0e24: r0 = Null
    //     0xfa0e24: mov             x0, NULL
    // 0xfa0e28: LeaveFrame
    //     0xfa0e28: mov             SP, fp
    //     0xfa0e2c: ldp             fp, lr, [SP], #0x10
    // 0xfa0e30: ret
    //     0xfa0e30: ret             
    // 0xfa0e34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa0e34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa0e38: b               #0xfa0dcc
  }
}

// class id: 6499, size: 0x88, field offset: 0xc
//   const constructor, 
class RawMaterialButton extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa0d64, size: 0x48
    // 0xfa0d64: EnterFrame
    //     0xfa0d64: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0d68: mov             fp, SP
    // 0xfa0d6c: AllocStack(0x8)
    //     0xfa0d6c: sub             SP, SP, #8
    // 0xfa0d70: CheckStackOverflow
    //     0xfa0d70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa0d74: cmp             SP, x16
    //     0xfa0d78: b.ls            #0xfa0da4
    // 0xfa0d7c: r1 = <RawMaterialButton>
    //     0xfa0d7c: add             x1, PP, #0x90, lsl #12  ; [pp+0x90880] TypeArguments: <RawMaterialButton>
    //     0xfa0d80: ldr             x1, [x1, #0x880]
    // 0xfa0d84: r0 = _RawMaterialButtonState()
    //     0xfa0d84: bl              #0xfa0e3c  ; Allocate_RawMaterialButtonStateStub -> _RawMaterialButtonState (size=0x18)
    // 0xfa0d88: mov             x1, x0
    // 0xfa0d8c: stur            x0, [fp, #-8]
    // 0xfa0d90: r0 = _RawMaterialButtonState()
    //     0xfa0d90: bl              #0xfa0dac  ; [package:flutter/src/material/button.dart] _RawMaterialButtonState::_RawMaterialButtonState
    // 0xfa0d94: ldur            x0, [fp, #-8]
    // 0xfa0d98: LeaveFrame
    //     0xfa0d98: mov             SP, fp
    //     0xfa0d9c: ldp             fp, lr, [SP], #0x10
    // 0xfa0da0: ret
    //     0xfa0da0: ret             
    // 0xfa0da4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa0da4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa0da8: b               #0xfa0d7c
  }
}

// class id: 6656, size: 0x14, field offset: 0x10
//   const constructor, 
class _InputPadding extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf48ac, size: 0x8c
    // 0xcf48ac: EnterFrame
    //     0xcf48ac: stp             fp, lr, [SP, #-0x10]!
    //     0xcf48b0: mov             fp, SP
    // 0xcf48b4: AllocStack(0x10)
    //     0xcf48b4: sub             SP, SP, #0x10
    // 0xcf48b8: SetupParameters(_InputPadding this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf48b8: mov             x4, x1
    //     0xcf48bc: stur            x1, [fp, #-8]
    //     0xcf48c0: stur            x3, [fp, #-0x10]
    // 0xcf48c4: CheckStackOverflow
    //     0xcf48c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf48c8: cmp             SP, x16
    //     0xcf48cc: b.ls            #0xcf4930
    // 0xcf48d0: mov             x0, x3
    // 0xcf48d4: r2 = Null
    //     0xcf48d4: mov             x2, NULL
    // 0xcf48d8: r1 = Null
    //     0xcf48d8: mov             x1, NULL
    // 0xcf48dc: r4 = 60
    //     0xcf48dc: mov             x4, #0x3c
    // 0xcf48e0: branchIfSmi(r0, 0xcf48ec)
    //     0xcf48e0: tbz             w0, #0, #0xcf48ec
    // 0xcf48e4: r4 = LoadClassIdInstr(r0)
    //     0xcf48e4: ldur            x4, [x0, #-1]
    //     0xcf48e8: ubfx            x4, x4, #0xc, #0x14
    // 0xcf48ec: r17 = 4880
    //     0xcf48ec: mov             x17, #0x1310
    // 0xcf48f0: cmp             x4, x17
    // 0xcf48f4: b.eq            #0xcf490c
    // 0xcf48f8: r8 = _RenderInputPadding
    //     0xcf48f8: add             x8, PP, #0xa4, lsl #12  ; [pp+0xa4238] Type: _RenderInputPadding
    //     0xcf48fc: ldr             x8, [x8, #0x238]
    // 0xcf4900: r3 = Null
    //     0xcf4900: add             x3, PP, #0xa4, lsl #12  ; [pp+0xa4240] Null
    //     0xcf4904: ldr             x3, [x3, #0x240]
    // 0xcf4908: r0 = DefaultTypeTest()
    //     0xcf4908: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf490c: ldur            x0, [fp, #-8]
    // 0xcf4910: LoadField: r2 = r0->field_f
    //     0xcf4910: ldur            w2, [x0, #0xf]
    // 0xcf4914: DecompressPointer r2
    //     0xcf4914: add             x2, x2, HEAP, lsl #32
    // 0xcf4918: ldur            x1, [fp, #-0x10]
    // 0xcf491c: r0 = minSize=()
    //     0xcf491c: bl              #0xcf4938  ; [package:flutter/src/material/button.dart] _RenderInputPadding::minSize=
    // 0xcf4920: r0 = Null
    //     0xcf4920: mov             x0, NULL
    // 0xcf4924: LeaveFrame
    //     0xcf4924: mov             SP, fp
    //     0xcf4928: ldp             fp, lr, [SP], #0x10
    // 0xcf492c: ret
    //     0xcf492c: ret             
    // 0xcf4930: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf4930: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf4934: b               #0xcf48d0
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11cf894, size: 0x74
    // 0x11cf894: EnterFrame
    //     0x11cf894: stp             fp, lr, [SP, #-0x10]!
    //     0x11cf898: mov             fp, SP
    // 0x11cf89c: AllocStack(0x10)
    //     0x11cf89c: sub             SP, SP, #0x10
    // 0x11cf8a0: CheckStackOverflow
    //     0x11cf8a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cf8a4: cmp             SP, x16
    //     0x11cf8a8: b.ls            #0x11cf900
    // 0x11cf8ac: LoadField: r0 = r1->field_f
    //     0x11cf8ac: ldur            w0, [x1, #0xf]
    // 0x11cf8b0: DecompressPointer r0
    //     0x11cf8b0: add             x0, x0, HEAP, lsl #32
    // 0x11cf8b4: stur            x0, [fp, #-8]
    // 0x11cf8b8: r0 = _RenderInputPadding()
    //     0x11cf8b8: bl              #0x11cf908  ; Allocate_RenderInputPaddingStub -> _RenderInputPadding (size=0x58)
    // 0x11cf8bc: mov             x1, x0
    // 0x11cf8c0: ldur            x0, [fp, #-8]
    // 0x11cf8c4: stur            x1, [fp, #-0x10]
    // 0x11cf8c8: StoreField: r1->field_53 = r0
    //     0x11cf8c8: stur            w0, [x1, #0x53]
    // 0x11cf8cc: r0 = _LayoutCacheStorage()
    //     0x11cf8cc: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11cf8d0: mov             x1, x0
    // 0x11cf8d4: ldur            x0, [fp, #-0x10]
    // 0x11cf8d8: StoreField: r0->field_47 = r1
    //     0x11cf8d8: stur            w1, [x0, #0x47]
    // 0x11cf8dc: mov             x1, x0
    // 0x11cf8e0: r0 = RenderObject()
    //     0x11cf8e0: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11cf8e4: ldur            x1, [fp, #-0x10]
    // 0x11cf8e8: r2 = Null
    //     0x11cf8e8: mov             x2, NULL
    // 0x11cf8ec: r0 = child=()
    //     0x11cf8ec: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11cf8f0: ldur            x0, [fp, #-0x10]
    // 0x11cf8f4: LeaveFrame
    //     0x11cf8f4: mov             SP, fp
    //     0x11cf8f8: ldp             fp, lr, [SP], #0x10
    // 0x11cf8fc: ret
    //     0x11cf8fc: ret             
    // 0x11cf900: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cf900: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cf904: b               #0x11cf8ac
  }
}
