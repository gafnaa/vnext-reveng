// lib: , url: package:flutter/src/material/bottom_sheet.dart

// class id: 1048853, size: 0x8
class :: {

  static _ showModalBottomSheet(/* No info */) {
    // ** addr: 0xdd5dfc, size: 0x4e4
    // 0xdd5dfc: EnterFrame
    //     0xdd5dfc: stp             fp, lr, [SP, #-0x10]!
    //     0xdd5e00: mov             fp, SP
    // 0xdd5e04: AllocStack(0xb0)
    //     0xdd5e04: sub             SP, SP, #0xb0
    // 0xdd5e08: SetupParameters(dynamic _ /* r6, fp-0x58 */, dynamic _ /* r2, fp-0x50 */, {dynamic backgroundColor = Null /* r3, fp-0x48 */, dynamic enableDrag = true /* r5, fp-0x40 */, dynamic isDismissible = true /* r7, fp-0x38 */, dynamic isScrollControlled = false /* r8, fp-0x30 */, dynamic routeSettings = Null /* r9, fp-0x28 */, dynamic sheetAnimationStyle = Null /* r10, fp-0x20 */, dynamic showDragHandle = Null /* r11, fp-0x18 */, dynamic useRootNavigator = false /* r12 */, dynamic useSafeArea = false /* r0, fp-0x10 */})
    //     0xdd5e08: ldur            w0, [x4, #0x13]
    //     0xdd5e0c: sub             x1, x0, #4
    //     0xdd5e10: add             x6, fp, w1, sxtw #2
    //     0xdd5e14: ldr             x6, [x6, #0x18]
    //     0xdd5e18: stur            x6, [fp, #-0x58]
    //     0xdd5e1c: add             x2, fp, w1, sxtw #2
    //     0xdd5e20: ldr             x2, [x2, #0x10]
    //     0xdd5e24: stur            x2, [fp, #-0x50]
    //     0xdd5e28: ldur            w1, [x4, #0x1f]
    //     0xdd5e2c: add             x1, x1, HEAP, lsl #32
    //     0xdd5e30: add             x16, PP, #0x12, lsl #12  ; [pp+0x12958] "backgroundColor"
    //     0xdd5e34: ldr             x16, [x16, #0x958]
    //     0xdd5e38: cmp             w1, w16
    //     0xdd5e3c: b.ne            #0xdd5e60
    //     0xdd5e40: ldur            w1, [x4, #0x23]
    //     0xdd5e44: add             x1, x1, HEAP, lsl #32
    //     0xdd5e48: sub             w3, w0, w1
    //     0xdd5e4c: add             x1, fp, w3, sxtw #2
    //     0xdd5e50: ldr             x1, [x1, #8]
    //     0xdd5e54: mov             x3, x1
    //     0xdd5e58: mov             x1, #1
    //     0xdd5e5c: b               #0xdd5e68
    //     0xdd5e60: mov             x3, NULL
    //     0xdd5e64: mov             x1, #0
    //     0xdd5e68: stur            x3, [fp, #-0x48]
    //     0xdd5e6c: lsl             x5, x1, #1
    //     0xdd5e70: lsl             w7, w5, #1
    //     0xdd5e74: add             w8, w7, #8
    //     0xdd5e78: add             x16, x4, w8, sxtw #1
    //     0xdd5e7c: ldur            w9, [x16, #0xf]
    //     0xdd5e80: add             x9, x9, HEAP, lsl #32
    //     0xdd5e84: add             x16, PP, #0x19, lsl #12  ; [pp+0x19cd0] "enableDrag"
    //     0xdd5e88: ldr             x16, [x16, #0xcd0]
    //     0xdd5e8c: cmp             w9, w16
    //     0xdd5e90: b.ne            #0xdd5ec4
    //     0xdd5e94: add             w1, w7, #0xa
    //     0xdd5e98: add             x16, x4, w1, sxtw #1
    //     0xdd5e9c: ldur            w7, [x16, #0xf]
    //     0xdd5ea0: add             x7, x7, HEAP, lsl #32
    //     0xdd5ea4: sub             w1, w0, w7
    //     0xdd5ea8: add             x7, fp, w1, sxtw #2
    //     0xdd5eac: ldr             x7, [x7, #8]
    //     0xdd5eb0: add             w1, w5, #2
    //     0xdd5eb4: sbfx            x5, x1, #1, #0x1f
    //     0xdd5eb8: mov             x1, x5
    //     0xdd5ebc: mov             x5, x7
    //     0xdd5ec0: b               #0xdd5ec8
    //     0xdd5ec4: add             x5, NULL, #0x20  ; true
    //     0xdd5ec8: stur            x5, [fp, #-0x40]
    //     0xdd5ecc: lsl             x7, x1, #1
    //     0xdd5ed0: lsl             w8, w7, #1
    //     0xdd5ed4: add             w9, w8, #8
    //     0xdd5ed8: add             x16, x4, w9, sxtw #1
    //     0xdd5edc: ldur            w10, [x16, #0xf]
    //     0xdd5ee0: add             x10, x10, HEAP, lsl #32
    //     0xdd5ee4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16d18] "isDismissible"
    //     0xdd5ee8: ldr             x16, [x16, #0xd18]
    //     0xdd5eec: cmp             w10, w16
    //     0xdd5ef0: b.ne            #0xdd5f24
    //     0xdd5ef4: add             w1, w8, #0xa
    //     0xdd5ef8: add             x16, x4, w1, sxtw #1
    //     0xdd5efc: ldur            w8, [x16, #0xf]
    //     0xdd5f00: add             x8, x8, HEAP, lsl #32
    //     0xdd5f04: sub             w1, w0, w8
    //     0xdd5f08: add             x8, fp, w1, sxtw #2
    //     0xdd5f0c: ldr             x8, [x8, #8]
    //     0xdd5f10: add             w1, w7, #2
    //     0xdd5f14: sbfx            x7, x1, #1, #0x1f
    //     0xdd5f18: mov             x1, x7
    //     0xdd5f1c: mov             x7, x8
    //     0xdd5f20: b               #0xdd5f28
    //     0xdd5f24: add             x7, NULL, #0x20  ; true
    //     0xdd5f28: stur            x7, [fp, #-0x38]
    //     0xdd5f2c: lsl             x8, x1, #1
    //     0xdd5f30: lsl             w9, w8, #1
    //     0xdd5f34: add             w10, w9, #8
    //     0xdd5f38: add             x16, x4, w10, sxtw #1
    //     0xdd5f3c: ldur            w11, [x16, #0xf]
    //     0xdd5f40: add             x11, x11, HEAP, lsl #32
    //     0xdd5f44: add             x16, PP, #0x19, lsl #12  ; [pp+0x19cd8] "isScrollControlled"
    //     0xdd5f48: ldr             x16, [x16, #0xcd8]
    //     0xdd5f4c: cmp             w11, w16
    //     0xdd5f50: b.ne            #0xdd5f84
    //     0xdd5f54: add             w1, w9, #0xa
    //     0xdd5f58: add             x16, x4, w1, sxtw #1
    //     0xdd5f5c: ldur            w9, [x16, #0xf]
    //     0xdd5f60: add             x9, x9, HEAP, lsl #32
    //     0xdd5f64: sub             w1, w0, w9
    //     0xdd5f68: add             x9, fp, w1, sxtw #2
    //     0xdd5f6c: ldr             x9, [x9, #8]
    //     0xdd5f70: add             w1, w8, #2
    //     0xdd5f74: sbfx            x8, x1, #1, #0x1f
    //     0xdd5f78: mov             x1, x8
    //     0xdd5f7c: mov             x8, x9
    //     0xdd5f80: b               #0xdd5f88
    //     0xdd5f84: add             x8, NULL, #0x30  ; false
    //     0xdd5f88: stur            x8, [fp, #-0x30]
    //     0xdd5f8c: lsl             x9, x1, #1
    //     0xdd5f90: lsl             w10, w9, #1
    //     0xdd5f94: add             w11, w10, #8
    //     0xdd5f98: add             x16, x4, w11, sxtw #1
    //     0xdd5f9c: ldur            w12, [x16, #0xf]
    //     0xdd5fa0: add             x12, x12, HEAP, lsl #32
    //     0xdd5fa4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15098] "routeSettings"
    //     0xdd5fa8: ldr             x16, [x16, #0x98]
    //     0xdd5fac: cmp             w12, w16
    //     0xdd5fb0: b.ne            #0xdd5fe4
    //     0xdd5fb4: add             w1, w10, #0xa
    //     0xdd5fb8: add             x16, x4, w1, sxtw #1
    //     0xdd5fbc: ldur            w10, [x16, #0xf]
    //     0xdd5fc0: add             x10, x10, HEAP, lsl #32
    //     0xdd5fc4: sub             w1, w0, w10
    //     0xdd5fc8: add             x10, fp, w1, sxtw #2
    //     0xdd5fcc: ldr             x10, [x10, #8]
    //     0xdd5fd0: add             w1, w9, #2
    //     0xdd5fd4: sbfx            x9, x1, #1, #0x1f
    //     0xdd5fd8: mov             x1, x9
    //     0xdd5fdc: mov             x9, x10
    //     0xdd5fe0: b               #0xdd5fe8
    //     0xdd5fe4: mov             x9, NULL
    //     0xdd5fe8: stur            x9, [fp, #-0x28]
    //     0xdd5fec: lsl             x10, x1, #1
    //     0xdd5ff0: lsl             w11, w10, #1
    //     0xdd5ff4: add             w12, w11, #8
    //     0xdd5ff8: add             x16, x4, w12, sxtw #1
    //     0xdd5ffc: ldur            w13, [x16, #0xf]
    //     0xdd6000: add             x13, x13, HEAP, lsl #32
    //     0xdd6004: add             x16, PP, #0x19, lsl #12  ; [pp+0x19ce0] "sheetAnimationStyle"
    //     0xdd6008: ldr             x16, [x16, #0xce0]
    //     0xdd600c: cmp             w13, w16
    //     0xdd6010: b.ne            #0xdd6044
    //     0xdd6014: add             w1, w11, #0xa
    //     0xdd6018: add             x16, x4, w1, sxtw #1
    //     0xdd601c: ldur            w11, [x16, #0xf]
    //     0xdd6020: add             x11, x11, HEAP, lsl #32
    //     0xdd6024: sub             w1, w0, w11
    //     0xdd6028: add             x11, fp, w1, sxtw #2
    //     0xdd602c: ldr             x11, [x11, #8]
    //     0xdd6030: add             w1, w10, #2
    //     0xdd6034: sbfx            x10, x1, #1, #0x1f
    //     0xdd6038: mov             x1, x10
    //     0xdd603c: mov             x10, x11
    //     0xdd6040: b               #0xdd6048
    //     0xdd6044: mov             x10, NULL
    //     0xdd6048: stur            x10, [fp, #-0x20]
    //     0xdd604c: lsl             x11, x1, #1
    //     0xdd6050: lsl             w12, w11, #1
    //     0xdd6054: add             w13, w12, #8
    //     0xdd6058: add             x16, x4, w13, sxtw #1
    //     0xdd605c: ldur            w14, [x16, #0xf]
    //     0xdd6060: add             x14, x14, HEAP, lsl #32
    //     0xdd6064: add             x16, PP, #0x19, lsl #12  ; [pp+0x19ce8] "showDragHandle"
    //     0xdd6068: ldr             x16, [x16, #0xce8]
    //     0xdd606c: cmp             w14, w16
    //     0xdd6070: b.ne            #0xdd60a4
    //     0xdd6074: add             w1, w12, #0xa
    //     0xdd6078: add             x16, x4, w1, sxtw #1
    //     0xdd607c: ldur            w12, [x16, #0xf]
    //     0xdd6080: add             x12, x12, HEAP, lsl #32
    //     0xdd6084: sub             w1, w0, w12
    //     0xdd6088: add             x12, fp, w1, sxtw #2
    //     0xdd608c: ldr             x12, [x12, #8]
    //     0xdd6090: add             w1, w11, #2
    //     0xdd6094: sbfx            x11, x1, #1, #0x1f
    //     0xdd6098: mov             x1, x11
    //     0xdd609c: mov             x11, x12
    //     0xdd60a0: b               #0xdd60a8
    //     0xdd60a4: mov             x11, NULL
    //     0xdd60a8: stur            x11, [fp, #-0x18]
    //     0xdd60ac: lsl             x12, x1, #1
    //     0xdd60b0: lsl             w13, w12, #1
    //     0xdd60b4: add             w14, w13, #8
    //     0xdd60b8: add             x16, x4, w14, sxtw #1
    //     0xdd60bc: ldur            w19, [x16, #0xf]
    //     0xdd60c0: add             x19, x19, HEAP, lsl #32
    //     0xdd60c4: add             x16, PP, #0x19, lsl #12  ; [pp+0x19cf0] "useRootNavigator"
    //     0xdd60c8: ldr             x16, [x16, #0xcf0]
    //     0xdd60cc: cmp             w19, w16
    //     0xdd60d0: b.ne            #0xdd6104
    //     0xdd60d4: add             w1, w13, #0xa
    //     0xdd60d8: add             x16, x4, w1, sxtw #1
    //     0xdd60dc: ldur            w13, [x16, #0xf]
    //     0xdd60e0: add             x13, x13, HEAP, lsl #32
    //     0xdd60e4: sub             w1, w0, w13
    //     0xdd60e8: add             x13, fp, w1, sxtw #2
    //     0xdd60ec: ldr             x13, [x13, #8]
    //     0xdd60f0: add             w1, w12, #2
    //     0xdd60f4: sbfx            x12, x1, #1, #0x1f
    //     0xdd60f8: mov             x1, x12
    //     0xdd60fc: mov             x12, x13
    //     0xdd6100: b               #0xdd6108
    //     0xdd6104: add             x12, NULL, #0x30  ; false
    //     0xdd6108: lsl             x13, x1, #1
    //     0xdd610c: lsl             w1, w13, #1
    //     0xdd6110: add             w13, w1, #8
    //     0xdd6114: add             x16, x4, w13, sxtw #1
    //     0xdd6118: ldur            w14, [x16, #0xf]
    //     0xdd611c: add             x14, x14, HEAP, lsl #32
    //     0xdd6120: add             x16, PP, #0x19, lsl #12  ; [pp+0x19cf8] "useSafeArea"
    //     0xdd6124: ldr             x16, [x16, #0xcf8]
    //     0xdd6128: cmp             w14, w16
    //     0xdd612c: b.ne            #0xdd6150
    //     0xdd6130: add             w13, w1, #0xa
    //     0xdd6134: add             x16, x4, w13, sxtw #1
    //     0xdd6138: ldur            w1, [x16, #0xf]
    //     0xdd613c: add             x1, x1, HEAP, lsl #32
    //     0xdd6140: sub             w13, w0, w1
    //     0xdd6144: add             x0, fp, w13, sxtw #2
    //     0xdd6148: ldr             x0, [x0, #8]
    //     0xdd614c: b               #0xdd6154
    //     0xdd6150: add             x0, NULL, #0x30  ; false
    //     0xdd6154: stur            x0, [fp, #-0x10]
    //     0xdd6158: ldur            w1, [x4, #0xf]
    //     0xdd615c: cbnz            w1, #0xdd6168
    //     0xdd6160: mov             x4, NULL
    //     0xdd6164: b               #0xdd6174
    //     0xdd6168: ldur            w1, [x4, #0x17]
    //     0xdd616c: add             x4, fp, w1, sxtw #2
    //     0xdd6170: ldr             x4, [x4, #0x10]
    //     0xdd6174: stur            x4, [fp, #-8]
    // 0xdd6178: CheckStackOverflow
    //     0xdd6178: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd617c: cmp             SP, x16
    //     0xdd6180: b.ls            #0xdd62d4
    // 0xdd6184: str             x12, [SP]
    // 0xdd6188: mov             x1, x2
    // 0xdd618c: r4 = const [0, 0x2, 0x1, 0x1, rootNavigator, 0x1, null]
    //     0xdd618c: add             x4, PP, #0x15, lsl #12  ; [pp+0x150a0] List(7) [0, 0x2, 0x1, 0x1, "rootNavigator", 0x1, Null]
    //     0xdd6190: ldr             x4, [x4, #0xa0]
    // 0xdd6194: r0 = of()
    //     0xdd6194: bl              #0xb35e68  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0xdd6198: ldur            x1, [fp, #-0x50]
    // 0xdd619c: stur            x0, [fp, #-0x60]
    // 0xdd61a0: r0 = of()
    //     0xdd61a0: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xdd61a4: mov             x3, x0
    // 0xdd61a8: ldur            x0, [fp, #-0x60]
    // 0xdd61ac: stur            x3, [fp, #-0x68]
    // 0xdd61b0: LoadField: r2 = r0->field_f
    //     0xdd61b0: ldur            w2, [x0, #0xf]
    // 0xdd61b4: DecompressPointer r2
    //     0xdd61b4: add             x2, x2, HEAP, lsl #32
    // 0xdd61b8: cmp             w2, NULL
    // 0xdd61bc: b.eq            #0xdd62dc
    // 0xdd61c0: ldur            x1, [fp, #-0x50]
    // 0xdd61c4: r0 = capture()
    //     0xdd61c4: bl              #0x8556d4  ; [package:flutter/src/widgets/inherited_theme.dart] InheritedTheme::capture
    // 0xdd61c8: mov             x3, x0
    // 0xdd61cc: ldur            x2, [fp, #-0x68]
    // 0xdd61d0: stur            x3, [fp, #-0x70]
    // 0xdd61d4: r0 = LoadClassIdInstr(r2)
    //     0xdd61d4: ldur            x0, [x2, #-1]
    //     0xdd61d8: ubfx            x0, x0, #0xc, #0x14
    // 0xdd61dc: mov             x1, x2
    // 0xdd61e0: r0 = GDT[cid_x0 + 0x1650d]()
    //     0xdd61e0: mov             x17, #0x650d
    //     0xdd61e4: movk            x17, #1, lsl #16
    //     0xdd61e8: add             lr, x0, x17
    //     0xdd61ec: ldr             lr, [x21, lr, lsl #3]
    //     0xdd61f0: blr             lr
    // 0xdd61f4: mov             x3, x0
    // 0xdd61f8: ldur            x2, [fp, #-0x68]
    // 0xdd61fc: stur            x3, [fp, #-0x78]
    // 0xdd6200: r0 = LoadClassIdInstr(r2)
    //     0xdd6200: ldur            x0, [x2, #-1]
    //     0xdd6204: ubfx            x0, x0, #0xc, #0x14
    // 0xdd6208: mov             x1, x2
    // 0xdd620c: r0 = GDT[cid_x0 + 0x16915]()
    //     0xdd620c: mov             x17, #0x6915
    //     0xdd6210: movk            x17, #1, lsl #16
    //     0xdd6214: add             lr, x0, x17
    //     0xdd6218: ldr             lr, [x21, lr, lsl #3]
    //     0xdd621c: blr             lr
    // 0xdd6220: ldur            x1, [fp, #-0x68]
    // 0xdd6224: r2 = LoadClassIdInstr(r1)
    //     0xdd6224: ldur            x2, [x1, #-1]
    //     0xdd6228: ubfx            x2, x2, #0xc, #0x14
    // 0xdd622c: mov             x16, x0
    // 0xdd6230: mov             x0, x2
    // 0xdd6234: mov             x2, x16
    // 0xdd6238: r0 = GDT[cid_x0 + 0x1698c]()
    //     0xdd6238: mov             x17, #0x698c
    //     0xdd623c: movk            x17, #1, lsl #16
    //     0xdd6240: add             lr, x0, x17
    //     0xdd6244: ldr             lr, [x21, lr, lsl #3]
    //     0xdd6248: blr             lr
    // 0xdd624c: ldur            x1, [fp, #-0x50]
    // 0xdd6250: stur            x0, [fp, #-0x50]
    // 0xdd6254: r0 = of()
    //     0xdd6254: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdd6258: ldur            x1, [fp, #-8]
    // 0xdd625c: r0 = ModalBottomSheetRoute()
    //     0xdd625c: bl              #0xdd64ac  ; AllocateModalBottomSheetRouteStub -> ModalBottomSheetRoute<X0> (size=0xf0)
    // 0xdd6260: stur            x0, [fp, #-0x68]
    // 0xdd6264: ldur            x16, [fp, #-0x40]
    // 0xdd6268: ldur            lr, [fp, #-0x38]
    // 0xdd626c: stp             lr, x16, [SP, #0x28]
    // 0xdd6270: ldur            x16, [fp, #-0x30]
    // 0xdd6274: ldur            lr, [fp, #-0x28]
    // 0xdd6278: stp             lr, x16, [SP, #0x18]
    // 0xdd627c: ldur            x16, [fp, #-0x20]
    // 0xdd6280: ldur            lr, [fp, #-0x18]
    // 0xdd6284: stp             lr, x16, [SP, #8]
    // 0xdd6288: ldur            x16, [fp, #-0x10]
    // 0xdd628c: str             x16, [SP]
    // 0xdd6290: mov             x1, x0
    // 0xdd6294: ldur            x2, [fp, #-0x48]
    // 0xdd6298: ldur            x3, [fp, #-0x78]
    // 0xdd629c: ldur            x5, [fp, #-0x50]
    // 0xdd62a0: ldur            x6, [fp, #-0x58]
    // 0xdd62a4: ldur            x7, [fp, #-0x70]
    // 0xdd62a8: r0 = ModalBottomSheetRoute()
    //     0xdd62a8: bl              #0xdd62e0  ; [package:flutter/src/material/bottom_sheet.dart] ModalBottomSheetRoute::ModalBottomSheetRoute
    // 0xdd62ac: ldur            x16, [fp, #-8]
    // 0xdd62b0: ldur            lr, [fp, #-0x60]
    // 0xdd62b4: stp             lr, x16, [SP, #8]
    // 0xdd62b8: ldur            x16, [fp, #-0x68]
    // 0xdd62bc: str             x16, [SP]
    // 0xdd62c0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xdd62c0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xdd62c4: r0 = push()
    //     0xdd62c4: bl              #0x9ec7a0  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::push
    // 0xdd62c8: LeaveFrame
    //     0xdd62c8: mov             SP, fp
    //     0xdd62cc: ldp             fp, lr, [SP], #0x10
    // 0xdd62d0: ret
    //     0xdd62d0: ret             
    // 0xdd62d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd62d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd62d8: b               #0xdd6184
    // 0xdd62dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdd62dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2646, size: 0xf0, field offset: 0x98
class ModalBottomSheetRoute<X0> extends PopupRoute<X0> {

  _ dispose(/* No info */) {
    // ** addr: 0xbb1078, size: 0x4c
    // 0xbb1078: EnterFrame
    //     0xbb1078: stp             fp, lr, [SP, #-0x10]!
    //     0xbb107c: mov             fp, SP
    // 0xbb1080: AllocStack(0x8)
    //     0xbb1080: sub             SP, SP, #8
    // 0xbb1084: SetupParameters(ModalBottomSheetRoute<X0> this /* r1 => r0, fp-0x8 */)
    //     0xbb1084: mov             x0, x1
    //     0xbb1088: stur            x1, [fp, #-8]
    // 0xbb108c: CheckStackOverflow
    //     0xbb108c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb1090: cmp             SP, x16
    //     0xbb1094: b.ls            #0xbb10bc
    // 0xbb1098: LoadField: r1 = r0->field_e3
    //     0xbb1098: ldur            w1, [x0, #0xe3]
    // 0xbb109c: DecompressPointer r1
    //     0xbb109c: add             x1, x1, HEAP, lsl #32
    // 0xbb10a0: r0 = dispose()
    //     0xbb10a0: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0xbb10a4: ldur            x1, [fp, #-8]
    // 0xbb10a8: r0 = dispose()
    //     0xbb10a8: bl              #0xbb10c4  ; [package:flutter/src/widgets/routes.dart] TransitionRoute::dispose
    // 0xbb10ac: r0 = Null
    //     0xbb10ac: mov             x0, NULL
    // 0xbb10b0: LeaveFrame
    //     0xbb10b0: mov             SP, fp
    //     0xbb10b4: ldp             fp, lr, [SP], #0x10
    // 0xbb10b8: ret
    //     0xbb10b8: ret             
    // 0xbb10bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb10bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb10c0: b               #0xbb1098
  }
  _ buildModalBarrier(/* No info */) {
    // ** addr: 0xbb5a64, size: 0x1fc
    // 0xbb5a64: EnterFrame
    //     0xbb5a64: stp             fp, lr, [SP, #-0x10]!
    //     0xbb5a68: mov             fp, SP
    // 0xbb5a6c: AllocStack(0x38)
    //     0xbb5a6c: sub             SP, SP, #0x38
    // 0xbb5a70: r0 = Instance_Color
    //     0xbb5a70: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c78] Obj!Color@12a1741
    //     0xbb5a74: ldr             x0, [x0, #0xc78]
    // 0xbb5a78: d0 = 0.000000
    //     0xbb5a78: eor             v0.16b, v0.16b, v0.16b
    // 0xbb5a7c: mov             x2, x1
    // 0xbb5a80: stur            x1, [fp, #-0x10]
    // 0xbb5a84: CheckStackOverflow
    //     0xbb5a84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb5a88: cmp             SP, x16
    //     0xbb5a8c: b.ls            #0xbb5c54
    // 0xbb5a90: LoadField: d1 = r0->field_7
    //     0xbb5a90: ldur            d1, [x0, #7]
    // 0xbb5a94: fcmp            d1, d0
    // 0xbb5a98: b.eq            #0xbb5be4
    // 0xbb5a9c: LoadField: r1 = r2->field_6b
    //     0xbb5a9c: ldur            w1, [x2, #0x6b]
    // 0xbb5aa0: DecompressPointer r1
    //     0xbb5aa0: add             x1, x1, HEAP, lsl #32
    // 0xbb5aa4: tbz             w1, #4, #0xbb5bd8
    // 0xbb5aa8: LoadField: r3 = r2->field_6f
    //     0xbb5aa8: ldur            w3, [x2, #0x6f]
    // 0xbb5aac: DecompressPointer r3
    //     0xbb5aac: add             x3, x3, HEAP, lsl #32
    // 0xbb5ab0: stur            x3, [fp, #-8]
    // 0xbb5ab4: cmp             w3, NULL
    // 0xbb5ab8: b.eq            #0xbb5c5c
    // 0xbb5abc: r16 = 0.000000
    //     0xbb5abc: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbb5ac0: str             x16, [SP]
    // 0xbb5ac4: mov             x1, x0
    // 0xbb5ac8: r4 = const [0, 0x2, 0x1, 0x1, alpha, 0x1, null]
    //     0xbb5ac8: add             x4, PP, #0x28, lsl #12  ; [pp+0x28640] List(7) [0, 0x2, 0x1, 0x1, "alpha", 0x1, Null]
    //     0xbb5acc: ldr             x4, [x4, #0x640]
    // 0xbb5ad0: r0 = withValues()
    //     0xbb5ad0: bl              #0x12d8818  ; [dart:ui] Color::withValues
    // 0xbb5ad4: r1 = <Color?>
    //     0xbb5ad4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xbb5ad8: ldr             x1, [x1, #0xa40]
    // 0xbb5adc: stur            x0, [fp, #-0x18]
    // 0xbb5ae0: r0 = ColorTween()
    //     0xbb5ae0: bl              #0x915f2c  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0xbb5ae4: mov             x2, x0
    // 0xbb5ae8: ldur            x0, [fp, #-0x18]
    // 0xbb5aec: stur            x2, [fp, #-0x20]
    // 0xbb5af0: StoreField: r2->field_b = r0
    //     0xbb5af0: stur            w0, [x2, #0xb]
    // 0xbb5af4: r0 = Instance_Color
    //     0xbb5af4: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c78] Obj!Color@12a1741
    //     0xbb5af8: ldr             x0, [x0, #0xc78]
    // 0xbb5afc: StoreField: r2->field_f = r0
    //     0xbb5afc: stur            w0, [x2, #0xf]
    // 0xbb5b00: r1 = <double>
    //     0xbb5b00: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xbb5b04: r0 = CurveTween()
    //     0xbb5b04: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xbb5b08: mov             x1, x0
    // 0xbb5b0c: r0 = Instance_Cubic
    //     0xbb5b0c: ldr             x0, [PP, #0x53e8]  ; [pp+0x53e8] Obj!Cubic@129f421
    // 0xbb5b10: StoreField: r1->field_b = r0
    //     0xbb5b10: stur            w0, [x1, #0xb]
    // 0xbb5b14: mov             x2, x1
    // 0xbb5b18: ldur            x1, [fp, #-0x20]
    // 0xbb5b1c: r0 = chain()
    //     0xbb5b1c: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xbb5b20: mov             x3, x0
    // 0xbb5b24: ldur            x0, [fp, #-8]
    // 0xbb5b28: r2 = Null
    //     0xbb5b28: mov             x2, NULL
    // 0xbb5b2c: r1 = Null
    //     0xbb5b2c: mov             x1, NULL
    // 0xbb5b30: stur            x3, [fp, #-0x18]
    // 0xbb5b34: r8 = Animation<double>
    //     0xbb5b34: add             x8, PP, #0x80, lsl #12  ; [pp+0x809a8] Type: Animation<double>
    //     0xbb5b38: ldr             x8, [x8, #0x9a8]
    // 0xbb5b3c: r3 = Null
    //     0xbb5b3c: add             x3, PP, #0x80, lsl #12  ; [pp+0x809b0] Null
    //     0xbb5b40: ldr             x3, [x3, #0x9b0]
    // 0xbb5b44: r0 = Animation<double>()
    //     0xbb5b44: bl              #0x829684  ; IsType_Animation<double>_Stub
    // 0xbb5b48: ldur            x1, [fp, #-0x18]
    // 0xbb5b4c: ldur            x2, [fp, #-8]
    // 0xbb5b50: r0 = animate()
    //     0xbb5b50: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xbb5b54: mov             x1, x0
    // 0xbb5b58: ldur            x0, [fp, #-0x10]
    // 0xbb5b5c: stur            x1, [fp, #-0x30]
    // 0xbb5b60: LoadField: r2 = r0->field_c3
    //     0xbb5b60: ldur            w2, [x0, #0xc3]
    // 0xbb5b64: DecompressPointer r2
    //     0xbb5b64: add             x2, x2, HEAP, lsl #32
    // 0xbb5b68: stur            x2, [fp, #-0x28]
    // 0xbb5b6c: LoadField: r3 = r0->field_e7
    //     0xbb5b6c: ldur            w3, [x0, #0xe7]
    // 0xbb5b70: DecompressPointer r3
    //     0xbb5b70: add             x3, x3, HEAP, lsl #32
    // 0xbb5b74: stur            x3, [fp, #-0x20]
    // 0xbb5b78: LoadField: r4 = r0->field_e3
    //     0xbb5b78: ldur            w4, [x0, #0xe3]
    // 0xbb5b7c: DecompressPointer r4
    //     0xbb5b7c: add             x4, x4, HEAP, lsl #32
    // 0xbb5b80: stur            x4, [fp, #-0x18]
    // 0xbb5b84: LoadField: r5 = r0->field_df
    //     0xbb5b84: ldur            w5, [x0, #0xdf]
    // 0xbb5b88: DecompressPointer r5
    //     0xbb5b88: add             x5, x5, HEAP, lsl #32
    // 0xbb5b8c: stur            x5, [fp, #-8]
    // 0xbb5b90: r0 = AnimatedModalBarrier()
    //     0xbb5b90: bl              #0xbb5c6c  ; AllocateAnimatedModalBarrierStub -> AnimatedModalBarrier (size=0x28)
    // 0xbb5b94: mov             x1, x0
    // 0xbb5b98: ldur            x0, [fp, #-0x28]
    // 0xbb5b9c: StoreField: r1->field_f = r0
    //     0xbb5b9c: stur            w0, [x1, #0xf]
    // 0xbb5ba0: ldur            x0, [fp, #-0x20]
    // 0xbb5ba4: StoreField: r1->field_13 = r0
    //     0xbb5ba4: stur            w0, [x1, #0x13]
    // 0xbb5ba8: r2 = true
    //     0xbb5ba8: add             x2, NULL, #0x20  ; true
    // 0xbb5bac: ArrayStore: r1[0] = r2  ; List_4
    //     0xbb5bac: stur            w2, [x1, #0x17]
    // 0xbb5bb0: ldur            x0, [fp, #-0x18]
    // 0xbb5bb4: StoreField: r1->field_1f = r0
    //     0xbb5bb4: stur            w0, [x1, #0x1f]
    // 0xbb5bb8: ldur            x0, [fp, #-8]
    // 0xbb5bbc: StoreField: r1->field_23 = r0
    //     0xbb5bbc: stur            w0, [x1, #0x23]
    // 0xbb5bc0: ldur            x0, [fp, #-0x30]
    // 0xbb5bc4: StoreField: r1->field_b = r0
    //     0xbb5bc4: stur            w0, [x1, #0xb]
    // 0xbb5bc8: mov             x0, x1
    // 0xbb5bcc: LeaveFrame
    //     0xbb5bcc: mov             SP, fp
    //     0xbb5bd0: ldp             fp, lr, [SP], #0x10
    // 0xbb5bd4: ret
    //     0xbb5bd4: ret             
    // 0xbb5bd8: mov             x0, x2
    // 0xbb5bdc: r2 = true
    //     0xbb5bdc: add             x2, NULL, #0x20  ; true
    // 0xbb5be0: b               #0xbb5bec
    // 0xbb5be4: mov             x0, x2
    // 0xbb5be8: r2 = true
    //     0xbb5be8: add             x2, NULL, #0x20  ; true
    // 0xbb5bec: LoadField: r1 = r0->field_c3
    //     0xbb5bec: ldur            w1, [x0, #0xc3]
    // 0xbb5bf0: DecompressPointer r1
    //     0xbb5bf0: add             x1, x1, HEAP, lsl #32
    // 0xbb5bf4: stur            x1, [fp, #-0x28]
    // 0xbb5bf8: LoadField: r3 = r0->field_e7
    //     0xbb5bf8: ldur            w3, [x0, #0xe7]
    // 0xbb5bfc: DecompressPointer r3
    //     0xbb5bfc: add             x3, x3, HEAP, lsl #32
    // 0xbb5c00: stur            x3, [fp, #-0x20]
    // 0xbb5c04: LoadField: r4 = r0->field_e3
    //     0xbb5c04: ldur            w4, [x0, #0xe3]
    // 0xbb5c08: DecompressPointer r4
    //     0xbb5c08: add             x4, x4, HEAP, lsl #32
    // 0xbb5c0c: stur            x4, [fp, #-0x18]
    // 0xbb5c10: LoadField: r5 = r0->field_df
    //     0xbb5c10: ldur            w5, [x0, #0xdf]
    // 0xbb5c14: DecompressPointer r5
    //     0xbb5c14: add             x5, x5, HEAP, lsl #32
    // 0xbb5c18: stur            x5, [fp, #-8]
    // 0xbb5c1c: r0 = ModalBarrier()
    //     0xbb5c1c: bl              #0xbb5c60  ; AllocateModalBarrierStub -> ModalBarrier (size=0x28)
    // 0xbb5c20: ldur            x1, [fp, #-0x28]
    // 0xbb5c24: StoreField: r0->field_f = r1
    //     0xbb5c24: stur            w1, [x0, #0xf]
    // 0xbb5c28: ldur            x1, [fp, #-0x20]
    // 0xbb5c2c: StoreField: r0->field_1b = r1
    //     0xbb5c2c: stur            w1, [x0, #0x1b]
    // 0xbb5c30: r1 = true
    //     0xbb5c30: add             x1, NULL, #0x20  ; true
    // 0xbb5c34: ArrayStore: r0[0] = r1  ; List_4
    //     0xbb5c34: stur            w1, [x0, #0x17]
    // 0xbb5c38: ldur            x1, [fp, #-0x18]
    // 0xbb5c3c: StoreField: r0->field_1f = r1
    //     0xbb5c3c: stur            w1, [x0, #0x1f]
    // 0xbb5c40: ldur            x1, [fp, #-8]
    // 0xbb5c44: StoreField: r0->field_23 = r1
    //     0xbb5c44: stur            w1, [x0, #0x23]
    // 0xbb5c48: LeaveFrame
    //     0xbb5c48: mov             SP, fp
    //     0xbb5c4c: ldp             fp, lr, [SP], #0x10
    // 0xbb5c50: ret
    //     0xbb5c50: ret             
    // 0xbb5c54: r0 = StackOverflowSharedWithFPURegs()
    //     0xbb5c54: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbb5c58: b               #0xbb5a90
    // 0xbb5c5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbb5c5c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ ModalBottomSheetRoute(/* No info */) {
    // ** addr: 0xdd62e0, size: 0x1cc
    // 0xdd62e0: EnterFrame
    //     0xdd62e0: stp             fp, lr, [SP, #-0x10]!
    //     0xdd62e4: mov             fp, SP
    // 0xdd62e8: AllocStack(0x38)
    //     0xdd62e8: sub             SP, SP, #0x38
    // 0xdd62ec: SetupParameters(ModalBottomSheetRoute<X0> this /* r1 => r6, fp-0x8 */, dynamic _ /* r2 => r5, fp-0x10 */, dynamic _ /* r3 => r4, fp-0x18 */, dynamic _ /* r5 => r3, fp-0x20 */, dynamic _ /* r6 => r2, fp-0x28 */, dynamic _ /* r7 => r0, fp-0x30 */)
    //     0xdd62ec: mov             x4, x3
    //     0xdd62f0: stur            x3, [fp, #-0x18]
    //     0xdd62f4: mov             x3, x5
    //     0xdd62f8: stur            x5, [fp, #-0x20]
    //     0xdd62fc: mov             x5, x2
    //     0xdd6300: stur            x2, [fp, #-0x10]
    //     0xdd6304: mov             x2, x6
    //     0xdd6308: stur            x6, [fp, #-0x28]
    //     0xdd630c: mov             x6, x1
    //     0xdd6310: mov             x0, x7
    //     0xdd6314: stur            x1, [fp, #-8]
    //     0xdd6318: stur            x7, [fp, #-0x30]
    // 0xdd631c: CheckStackOverflow
    //     0xdd631c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdd6320: cmp             SP, x16
    //     0xdd6324: b.ls            #0xdd64a4
    // 0xdd6328: r1 = <EdgeInsets>
    //     0xdd6328: add             x1, PP, #0x19, lsl #12  ; [pp+0x19d00] TypeArguments: <EdgeInsets>
    //     0xdd632c: ldr             x1, [x1, #0xd00]
    // 0xdd6330: r0 = ValueNotifier()
    //     0xdd6330: bl              #0x89f884  ; AllocateValueNotifierStub -> ValueNotifier<X0> (size=0x2c)
    // 0xdd6334: mov             x1, x0
    // 0xdd6338: r0 = Instance_EdgeInsets
    //     0xdd6338: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xdd633c: stur            x1, [fp, #-0x38]
    // 0xdd6340: StoreField: r1->field_27 = r0
    //     0xdd6340: stur            w0, [x1, #0x27]
    // 0xdd6344: StoreField: r1->field_7 = rZR
    //     0xdd6344: stur            xzr, [x1, #7]
    // 0xdd6348: StoreField: r1->field_13 = rZR
    //     0xdd6348: stur            xzr, [x1, #0x13]
    // 0xdd634c: StoreField: r1->field_1b = rZR
    //     0xdd634c: stur            xzr, [x1, #0x1b]
    // 0xdd6350: r0 = LoadStaticField(0x45c)
    //     0xdd6350: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xdd6354: ldr             x0, [x0, #0x8b8]
    // 0xdd6358: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdd635c: cmp             w0, w16
    // 0xdd6360: b.ne            #0xdd636c
    // 0xdd6364: r2 = _emptyListeners
    //     0xdd6364: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xdd6368: r0 = InitLateFinalStaticField()
    //     0xdd6368: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xdd636c: mov             x1, x0
    // 0xdd6370: ldur            x0, [fp, #-0x38]
    // 0xdd6374: StoreField: r0->field_f = r1
    //     0xdd6374: stur            w1, [x0, #0xf]
    // 0xdd6378: ldur            x1, [fp, #-8]
    // 0xdd637c: StoreField: r1->field_e3 = r0
    //     0xdd637c: stur            w0, [x1, #0xe3]
    //     0xdd6380: ldurb           w16, [x1, #-1]
    //     0xdd6384: ldurb           w17, [x0, #-1]
    //     0xdd6388: and             x16, x17, x16, lsr #2
    //     0xdd638c: tst             x16, HEAP, lsr #32
    //     0xdd6390: b.eq            #0xdd6398
    //     0xdd6394: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdd6398: ldur            x0, [fp, #-0x28]
    // 0xdd639c: StoreField: r1->field_97 = r0
    //     0xdd639c: stur            w0, [x1, #0x97]
    //     0xdd63a0: ldurb           w16, [x1, #-1]
    //     0xdd63a4: ldurb           w17, [x0, #-1]
    //     0xdd63a8: and             x16, x17, x16, lsr #2
    //     0xdd63ac: tst             x16, HEAP, lsr #32
    //     0xdd63b0: b.eq            #0xdd63b8
    //     0xdd63b4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdd63b8: ldur            x0, [fp, #-0x30]
    // 0xdd63bc: StoreField: r1->field_9b = r0
    //     0xdd63bc: stur            w0, [x1, #0x9b]
    //     0xdd63c0: ldurb           w16, [x1, #-1]
    //     0xdd63c4: ldurb           w17, [x0, #-1]
    //     0xdd63c8: and             x16, x17, x16, lsr #2
    //     0xdd63cc: tst             x16, HEAP, lsr #32
    //     0xdd63d0: b.eq            #0xdd63d8
    //     0xdd63d4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdd63d8: ldur            x0, [fp, #-0x18]
    // 0xdd63dc: StoreField: r1->field_e7 = r0
    //     0xdd63dc: stur            w0, [x1, #0xe7]
    //     0xdd63e0: ldurb           w16, [x1, #-1]
    //     0xdd63e4: ldurb           w17, [x0, #-1]
    //     0xdd63e8: and             x16, x17, x16, lsr #2
    //     0xdd63ec: tst             x16, HEAP, lsr #32
    //     0xdd63f0: b.eq            #0xdd63f8
    //     0xdd63f4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdd63f8: ldur            x0, [fp, #-0x20]
    // 0xdd63fc: StoreField: r1->field_df = r0
    //     0xdd63fc: stur            w0, [x1, #0xdf]
    //     0xdd6400: ldurb           w16, [x1, #-1]
    //     0xdd6404: ldurb           w17, [x0, #-1]
    //     0xdd6408: and             x16, x17, x16, lsr #2
    //     0xdd640c: tst             x16, HEAP, lsr #32
    //     0xdd6410: b.eq            #0xdd6418
    //     0xdd6414: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdd6418: ldur            x0, [fp, #-0x10]
    // 0xdd641c: StoreField: r1->field_ab = r0
    //     0xdd641c: stur            w0, [x1, #0xab]
    //     0xdd6420: ldurb           w16, [x1, #-1]
    //     0xdd6424: ldurb           w17, [x0, #-1]
    //     0xdd6428: and             x16, x17, x16, lsr #2
    //     0xdd642c: tst             x16, HEAP, lsr #32
    //     0xdd6430: b.eq            #0xdd6438
    //     0xdd6434: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdd6438: ldr             x0, [fp, #0x38]
    // 0xdd643c: StoreField: r1->field_c3 = r0
    //     0xdd643c: stur            w0, [x1, #0xc3]
    // 0xdd6440: ldr             x0, [fp, #0x40]
    // 0xdd6444: StoreField: r1->field_c7 = r0
    //     0xdd6444: stur            w0, [x1, #0xc7]
    // 0xdd6448: ldr             x0, [fp, #0x18]
    // 0xdd644c: StoreField: r1->field_cb = r0
    //     0xdd644c: stur            w0, [x1, #0xcb]
    // 0xdd6450: ldr             x0, [fp, #0x30]
    // 0xdd6454: StoreField: r1->field_9f = r0
    //     0xdd6454: stur            w0, [x1, #0x9f]
    // 0xdd6458: d0 = 0.562500
    //     0xdd6458: fmov            d0, #0.56250000
    // 0xdd645c: StoreField: r1->field_a3 = d0
    //     0xdd645c: stur            d0, [x1, #0xa3]
    // 0xdd6460: ldr             x0, [fp, #0x10]
    // 0xdd6464: StoreField: r1->field_d7 = r0
    //     0xdd6464: stur            w0, [x1, #0xd7]
    // 0xdd6468: ldr             x0, [fp, #0x20]
    // 0xdd646c: StoreField: r1->field_db = r0
    //     0xdd646c: stur            w0, [x1, #0xdb]
    //     0xdd6470: ldurb           w16, [x1, #-1]
    //     0xdd6474: ldurb           w17, [x0, #-1]
    //     0xdd6478: and             x16, x17, x16, lsr #2
    //     0xdd647c: tst             x16, HEAP, lsr #32
    //     0xdd6480: b.eq            #0xdd6488
    //     0xdd6484: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdd6488: ldr             x2, [fp, #0x28]
    // 0xdd648c: r3 = Null
    //     0xdd648c: mov             x3, NULL
    // 0xdd6490: r0 = ModalRoute()
    //     0xdd6490: bl              #0x8e04e0  ; [package:flutter/src/widgets/routes.dart] ModalRoute::ModalRoute
    // 0xdd6494: r0 = Null
    //     0xdd6494: mov             x0, NULL
    // 0xdd6498: LeaveFrame
    //     0xdd6498: mov             SP, fp
    //     0xdd649c: ldp             fp, lr, [SP], #0x10
    // 0xdd64a0: ret
    //     0xdd64a0: ret             
    // 0xdd64a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdd64a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdd64a8: b               #0xdd6328
  }
  _ _didChangeBarrierSemanticsClip(/* No info */) {
    // ** addr: 0xdec39c, size: 0x70
    // 0xdec39c: EnterFrame
    //     0xdec39c: stp             fp, lr, [SP, #-0x10]!
    //     0xdec3a0: mov             fp, SP
    // 0xdec3a4: AllocStack(0x20)
    //     0xdec3a4: sub             SP, SP, #0x20
    // 0xdec3a8: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdec3a8: stur            x2, [fp, #-0x10]
    // 0xdec3ac: CheckStackOverflow
    //     0xdec3ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdec3b0: cmp             SP, x16
    //     0xdec3b4: b.ls            #0xdec404
    // 0xdec3b8: LoadField: r0 = r1->field_e3
    //     0xdec3b8: ldur            w0, [x1, #0xe3]
    // 0xdec3bc: DecompressPointer r0
    //     0xdec3bc: add             x0, x0, HEAP, lsl #32
    // 0xdec3c0: stur            x0, [fp, #-8]
    // 0xdec3c4: LoadField: r1 = r0->field_27
    //     0xdec3c4: ldur            w1, [x0, #0x27]
    // 0xdec3c8: DecompressPointer r1
    //     0xdec3c8: add             x1, x1, HEAP, lsl #32
    // 0xdec3cc: stp             x2, x1, [SP]
    // 0xdec3d0: r0 = ==()
    //     0xdec3d0: bl              #0x1298c8c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::==
    // 0xdec3d4: tbnz            w0, #4, #0xdec3e8
    // 0xdec3d8: r0 = false
    //     0xdec3d8: add             x0, NULL, #0x30  ; false
    // 0xdec3dc: LeaveFrame
    //     0xdec3dc: mov             SP, fp
    //     0xdec3e0: ldp             fp, lr, [SP], #0x10
    // 0xdec3e4: ret
    //     0xdec3e4: ret             
    // 0xdec3e8: ldur            x1, [fp, #-8]
    // 0xdec3ec: ldur            x2, [fp, #-0x10]
    // 0xdec3f0: r0 = value=()
    //     0xdec3f0: bl              #0xb68ce8  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0xdec3f4: r0 = true
    //     0xdec3f4: add             x0, NULL, #0x20  ; true
    // 0xdec3f8: LeaveFrame
    //     0xdec3f8: mov             SP, fp
    //     0xdec3fc: ldp             fp, lr, [SP], #0x10
    // 0xdec400: ret
    //     0xdec400: ret             
    // 0xdec404: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdec404: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdec408: b               #0xdec3b8
  }
  _ createAnimationController(/* No info */) {
    // ** addr: 0x10f421c, size: 0x88
    // 0x10f421c: EnterFrame
    //     0x10f421c: stp             fp, lr, [SP, #-0x10]!
    //     0x10f4220: mov             fp, SP
    // 0x10f4224: AllocStack(0x10)
    //     0x10f4224: sub             SP, SP, #0x10
    // 0x10f4228: SetupParameters(ModalBottomSheetRoute<X0> this /* r1 => r0, fp-0x8 */)
    //     0x10f4228: mov             x0, x1
    //     0x10f422c: stur            x1, [fp, #-8]
    // 0x10f4230: CheckStackOverflow
    //     0x10f4230: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f4234: cmp             SP, x16
    //     0x10f4238: b.ls            #0x10f4298
    // 0x10f423c: LoadField: r1 = r0->field_f
    //     0x10f423c: ldur            w1, [x0, #0xf]
    // 0x10f4240: DecompressPointer r1
    //     0x10f4240: add             x1, x1, HEAP, lsl #32
    // 0x10f4244: cmp             w1, NULL
    // 0x10f4248: b.eq            #0x10f42a0
    // 0x10f424c: LoadField: r2 = r0->field_db
    //     0x10f424c: ldur            w2, [x0, #0xdb]
    // 0x10f4250: DecompressPointer r2
    //     0x10f4250: add             x2, x2, HEAP, lsl #32
    // 0x10f4254: str             x2, [SP]
    // 0x10f4258: r4 = const [0, 0x2, 0x1, 0x1, sheetAnimationStyle, 0x1, null]
    //     0x10f4258: add             x4, PP, #0x80, lsl #12  ; [pp+0x809c0] List(7) [0, 0x2, 0x1, 0x1, "sheetAnimationStyle", 0x1, Null]
    //     0x10f425c: ldr             x4, [x4, #0x9c0]
    // 0x10f4260: r0 = createAnimationController()
    //     0x10f4260: bl              #0xeee668  ; [package:flutter/src/material/bottom_sheet.dart] BottomSheet::createAnimationController
    // 0x10f4264: mov             x2, x0
    // 0x10f4268: ldur            x1, [fp, #-8]
    // 0x10f426c: StoreField: r1->field_eb = r0
    //     0x10f426c: stur            w0, [x1, #0xeb]
    //     0x10f4270: ldurb           w16, [x1, #-1]
    //     0x10f4274: ldurb           w17, [x0, #-1]
    //     0x10f4278: and             x16, x17, x16, lsr #2
    //     0x10f427c: tst             x16, HEAP, lsr #32
    //     0x10f4280: b.eq            #0x10f4288
    //     0x10f4284: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x10f4288: mov             x0, x2
    // 0x10f428c: LeaveFrame
    //     0x10f428c: mov             SP, fp
    //     0x10f4290: ldp             fp, lr, [SP], #0x10
    // 0x10f4294: ret
    //     0x10f4294: ret             
    // 0x10f4298: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f4298: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f429c: b               #0x10f423c
    // 0x10f42a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10f42a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ buildPage(/* No info */) {
    // ** addr: 0x11030d0, size: 0x154
    // 0x11030d0: EnterFrame
    //     0x11030d0: stp             fp, lr, [SP, #-0x10]!
    //     0x11030d4: mov             fp, SP
    // 0x11030d8: AllocStack(0x30)
    //     0x11030d8: sub             SP, SP, #0x30
    // 0x11030dc: SetupParameters(ModalBottomSheetRoute<X0> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x11030dc: mov             x0, x2
    //     0x11030e0: stur            x1, [fp, #-8]
    //     0x11030e4: stur            x2, [fp, #-0x10]
    // 0x11030e8: CheckStackOverflow
    //     0x11030e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11030ec: cmp             SP, x16
    //     0x11030f0: b.ls            #0x110321c
    // 0x11030f4: r1 = 1
    //     0x11030f4: mov             x1, #1
    // 0x11030f8: r0 = AllocateContext()
    //     0x11030f8: bl              #0x13de838  ; AllocateContextStub
    // 0x11030fc: mov             x1, x0
    // 0x1103100: ldur            x0, [fp, #-8]
    // 0x1103104: StoreField: r1->field_f = r0
    //     0x1103104: stur            w0, [x1, #0xf]
    // 0x1103108: LoadField: r3 = r0->field_7
    //     0x1103108: ldur            w3, [x0, #7]
    // 0x110310c: DecompressPointer r3
    //     0x110310c: add             x3, x3, HEAP, lsl #32
    // 0x1103110: mov             x2, x1
    // 0x1103114: r1 = Function '<anonymous closure>':.
    //     0x1103114: add             x1, PP, #0x95, lsl #12  ; [pp+0x95e60] AnonymousClosure: (0x1103224), in [package:flutter/src/material/bottom_sheet.dart] ModalBottomSheetRoute::buildPage (0x11030d0)
    //     0x1103118: ldr             x1, [x1, #0xe60]
    // 0x110311c: r0 = AllocateClosureTA()
    //     0x110311c: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0x1103120: stur            x0, [fp, #-0x18]
    // 0x1103124: r0 = Builder()
    //     0x1103124: bl              #0x858774  ; AllocateBuilderStub -> Builder (size=0x10)
    // 0x1103128: mov             x1, x0
    // 0x110312c: ldur            x0, [fp, #-0x18]
    // 0x1103130: stur            x1, [fp, #-0x20]
    // 0x1103134: StoreField: r1->field_b = r0
    //     0x1103134: stur            w0, [x1, #0xb]
    // 0x1103138: r0 = DisplayFeatureSubScreen()
    //     0x1103138: bl              #0x1103034  ; AllocateDisplayFeatureSubScreenStub -> DisplayFeatureSubScreen (size=0x14)
    // 0x110313c: mov             x1, x0
    // 0x1103140: ldur            x0, [fp, #-0x20]
    // 0x1103144: stur            x1, [fp, #-0x18]
    // 0x1103148: StoreField: r1->field_f = r0
    //     0x1103148: stur            w0, [x1, #0xf]
    // 0x110314c: ldur            x0, [fp, #-8]
    // 0x1103150: LoadField: r2 = r0->field_d7
    //     0x1103150: ldur            w2, [x0, #0xd7]
    // 0x1103154: DecompressPointer r2
    //     0x1103154: add             x2, x2, HEAP, lsl #32
    // 0x1103158: tbnz            w2, #4, #0x1103194
    // 0x110315c: r0 = SafeArea()
    //     0x110315c: bl              #0xd73100  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x1103160: mov             x1, x0
    // 0x1103164: r0 = true
    //     0x1103164: add             x0, NULL, #0x20  ; true
    // 0x1103168: StoreField: r1->field_b = r0
    //     0x1103168: stur            w0, [x1, #0xb]
    // 0x110316c: StoreField: r1->field_f = r0
    //     0x110316c: stur            w0, [x1, #0xf]
    // 0x1103170: StoreField: r1->field_13 = r0
    //     0x1103170: stur            w0, [x1, #0x13]
    // 0x1103174: r0 = false
    //     0x1103174: add             x0, NULL, #0x30  ; false
    // 0x1103178: ArrayStore: r1[0] = r0  ; List_4
    //     0x1103178: stur            w0, [x1, #0x17]
    // 0x110317c: r2 = Instance_EdgeInsets
    //     0x110317c: ldr             x2, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0x1103180: StoreField: r1->field_1b = r2
    //     0x1103180: stur            w2, [x1, #0x1b]
    // 0x1103184: StoreField: r1->field_1f = r0
    //     0x1103184: stur            w0, [x1, #0x1f]
    // 0x1103188: ldur            x2, [fp, #-0x18]
    // 0x110318c: StoreField: r1->field_23 = r2
    //     0x110318c: stur            w2, [x1, #0x23]
    // 0x1103190: b               #0x11031cc
    // 0x1103194: mov             x2, x1
    // 0x1103198: r1 = <_MediaQueryAspect>
    //     0x1103198: add             x1, PP, #0x12, lsl #12  ; [pp+0x12828] TypeArguments: <_MediaQueryAspect>
    //     0x110319c: ldr             x1, [x1, #0x828]
    // 0x11031a0: r0 = MediaQuery()
    //     0x11031a0: bl              #0xd0af24  ; AllocateMediaQueryStub -> MediaQuery (size=0x18)
    // 0x11031a4: stur            x0, [fp, #-0x20]
    // 0x11031a8: r16 = true
    //     0x11031a8: add             x16, NULL, #0x20  ; true
    // 0x11031ac: str             x16, [SP]
    // 0x11031b0: mov             x1, x0
    // 0x11031b4: ldur            x2, [fp, #-0x18]
    // 0x11031b8: ldur            x3, [fp, #-0x10]
    // 0x11031bc: r4 = const [0, 0x4, 0x1, 0x3, removeTop, 0x3, null]
    //     0x11031bc: add             x4, PP, #0x93, lsl #12  ; [pp+0x934f8] List(7) [0, 0x4, 0x1, 0x3, "removeTop", 0x3, Null]
    //     0x11031c0: ldr             x4, [x4, #0x4f8]
    // 0x11031c4: r0 = MediaQuery.removePadding()
    //     0x11031c4: bl              #0xd0a5a0  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::MediaQuery.removePadding
    // 0x11031c8: ldur            x1, [fp, #-0x20]
    // 0x11031cc: ldur            x0, [fp, #-8]
    // 0x11031d0: stur            x1, [fp, #-0x10]
    // 0x11031d4: r0 = Semantics()
    //     0x11031d4: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0x11031d8: stur            x0, [fp, #-0x18]
    // 0x11031dc: r16 = Instance_SemanticsHitTestBehavior
    //     0x11031dc: add             x16, PP, #0x15, lsl #12  ; [pp+0x150e0] Obj!SemanticsHitTestBehavior@12c7681
    //     0x11031e0: ldr             x16, [x16, #0xe0]
    // 0x11031e4: ldur            lr, [fp, #-0x10]
    // 0x11031e8: stp             lr, x16, [SP]
    // 0x11031ec: mov             x1, x0
    // 0x11031f0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, hitTestBehavior, 0x1, null]
    //     0x11031f0: add             x4, PP, #0x15, lsl #12  ; [pp+0x150e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "hitTestBehavior", 0x1, Null]
    //     0x11031f4: ldr             x4, [x4, #0xe8]
    // 0x11031f8: r0 = Semantics()
    //     0x11031f8: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x11031fc: ldur            x0, [fp, #-8]
    // 0x1103200: LoadField: r1 = r0->field_9b
    //     0x1103200: ldur            w1, [x0, #0x9b]
    // 0x1103204: DecompressPointer r1
    //     0x1103204: add             x1, x1, HEAP, lsl #32
    // 0x1103208: ldur            x2, [fp, #-0x18]
    // 0x110320c: r0 = wrap()
    //     0x110320c: bl              #0x856110  ; [package:flutter/src/widgets/inherited_theme.dart] CapturedThemes::wrap
    // 0x1103210: LeaveFrame
    //     0x1103210: mov             SP, fp
    //     0x1103214: ldp             fp, lr, [SP], #0x10
    // 0x1103218: ret
    //     0x1103218: ret             
    // 0x110321c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x110321c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1103220: b               #0x11030f4
  }
  [closure] _ModalBottomSheet<X0> <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x1103224, size: 0x260
    // 0x1103224: EnterFrame
    //     0x1103224: stp             fp, lr, [SP, #-0x10]!
    //     0x1103228: mov             fp, SP
    // 0x110322c: AllocStack(0x38)
    //     0x110322c: sub             SP, SP, #0x38
    // 0x1103230: SetupParameters([dynamic _ /* r0 */])
    //     0x1103230: ldr             x0, [fp, #0x18]
    //     0x1103234: ldur            w2, [x0, #0x17]
    //     0x1103238: add             x2, x2, HEAP, lsl #32
    //     0x110323c: stur            x2, [fp, #-8]
    // 0x1103240: CheckStackOverflow
    //     0x1103240: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1103244: cmp             SP, x16
    //     0x1103248: b.ls            #0x110347c
    // 0x110324c: ldr             x1, [fp, #0x10]
    // 0x1103250: r0 = of()
    //     0x1103250: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1103254: LoadField: r2 = r0->field_a7
    //     0x1103254: ldur            w2, [x0, #0xa7]
    // 0x1103258: DecompressPointer r2
    //     0x1103258: add             x2, x2, HEAP, lsl #32
    // 0x110325c: ldr             x1, [fp, #0x10]
    // 0x1103260: stur            x2, [fp, #-0x10]
    // 0x1103264: r0 = of()
    //     0x1103264: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1103268: LoadField: r1 = r0->field_2f
    //     0x1103268: ldur            w1, [x0, #0x2f]
    // 0x110326c: DecompressPointer r1
    //     0x110326c: add             x1, x1, HEAP, lsl #32
    // 0x1103270: tbnz            w1, #4, #0x11032bc
    // 0x1103274: ldr             x0, [fp, #0x10]
    // 0x1103278: r0 = _BottomSheetDefaultsM3()
    //     0x1103278: bl              #0xdeb54c  ; Allocate_BottomSheetDefaultsM3Stub -> _BottomSheetDefaultsM3 (size=0x44)
    // 0x110327c: mov             x1, x0
    // 0x1103280: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x1103284: StoreField: r1->field_3f = r0
    //     0x1103284: stur            w0, [x1, #0x3f]
    // 0x1103288: ldr             x0, [fp, #0x10]
    // 0x110328c: StoreField: r1->field_3b = r0
    //     0x110328c: stur            w0, [x1, #0x3b]
    // 0x1103290: r0 = 1.000000
    //     0x1103290: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x1103294: StoreField: r1->field_f = r0
    //     0x1103294: stur            w0, [x1, #0xf]
    // 0x1103298: StoreField: r1->field_1f = r0
    //     0x1103298: stur            w0, [x1, #0x1f]
    // 0x110329c: r0 = Instance_RoundedRectangleBorder
    //     0x110329c: add             x0, PP, #0x95, lsl #12  ; [pp+0x95e68] Obj!RoundedRectangleBorder@129ec71
    //     0x11032a0: ldr             x0, [x0, #0xe68]
    // 0x11032a4: StoreField: r1->field_23 = r0
    //     0x11032a4: stur            w0, [x1, #0x23]
    // 0x11032a8: r0 = Instance_BoxConstraints
    //     0x11032a8: add             x0, PP, #0x26, lsl #12  ; [pp+0x26560] Obj!BoxConstraints@129c321
    //     0x11032ac: ldr             x0, [x0, #0x560]
    // 0x11032b0: StoreField: r1->field_37 = r0
    //     0x11032b0: stur            w0, [x1, #0x37]
    // 0x11032b4: mov             x2, x1
    // 0x11032b8: b               #0x11032c4
    // 0x11032bc: r2 = Instance_BottomSheetThemeData
    //     0x11032bc: add             x2, PP, #0x12, lsl #12  ; [pp+0x12d40] Obj!BottomSheetThemeData@12b32b1
    //     0x11032c0: ldr             x2, [x2, #0xd40]
    // 0x11032c4: ldur            x0, [fp, #-8]
    // 0x11032c8: stur            x2, [fp, #-0x20]
    // 0x11032cc: LoadField: r1 = r0->field_f
    //     0x11032cc: ldur            w1, [x0, #0xf]
    // 0x11032d0: DecompressPointer r1
    //     0x11032d0: add             x1, x1, HEAP, lsl #32
    // 0x11032d4: LoadField: r3 = r1->field_db
    //     0x11032d4: ldur            w3, [x1, #0xdb]
    // 0x11032d8: DecompressPointer r3
    //     0x11032d8: add             x3, x3, HEAP, lsl #32
    // 0x11032dc: stur            x3, [fp, #-0x18]
    // 0x11032e0: LoadField: r4 = r1->field_ab
    //     0x11032e0: ldur            w4, [x1, #0xab]
    // 0x11032e4: DecompressPointer r4
    //     0x11032e4: add             x4, x4, HEAP, lsl #32
    // 0x11032e8: cmp             w4, NULL
    // 0x11032ec: b.ne            #0x11032f8
    // 0x11032f0: r1 = Null
    //     0x11032f0: mov             x1, NULL
    // 0x11032f4: b               #0x11032fc
    // 0x11032f8: mov             x1, x4
    // 0x11032fc: cmp             w1, NULL
    // 0x1103300: b.ne            #0x1103308
    // 0x1103304: r1 = Null
    //     0x1103304: mov             x1, NULL
    // 0x1103308: cmp             w1, NULL
    // 0x110330c: b.ne            #0x1103384
    // 0x1103310: r1 = LoadClassIdInstr(r2)
    //     0x1103310: ldur            x1, [x2, #-1]
    //     0x1103314: ubfx            x1, x1, #0xc, #0x14
    // 0x1103318: r17 = 5201
    //     0x1103318: mov             x17, #0x1451
    // 0x110331c: cmp             x1, x17
    // 0x1103320: b.ne            #0x1103334
    // 0x1103324: LoadField: r1 = r2->field_7
    //     0x1103324: ldur            w1, [x2, #7]
    // 0x1103328: DecompressPointer r1
    //     0x1103328: add             x1, x1, HEAP, lsl #32
    // 0x110332c: mov             x0, x1
    // 0x1103330: b               #0x110337c
    // 0x1103334: mov             x1, x2
    // 0x1103338: LoadField: r0 = r1->field_3f
    //     0x1103338: ldur            w0, [x1, #0x3f]
    // 0x110333c: DecompressPointer r0
    //     0x110333c: add             x0, x0, HEAP, lsl #32
    // 0x1103340: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1103344: cmp             w0, w16
    // 0x1103348: b.ne            #0x1103358
    // 0x110334c: r2 = _colors
    //     0x110334c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26550] Field <_BottomSheetDefaultsM3@726001611._colors@726001611>: late final (offset: 0x40)
    //     0x1103350: ldr             x2, [x2, #0x550]
    // 0x1103354: r0 = InitLateFinalInstanceField()
    //     0x1103354: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1103358: LoadField: r1 = r0->field_93
    //     0x1103358: ldur            w1, [x0, #0x93]
    // 0x110335c: DecompressPointer r1
    //     0x110335c: add             x1, x1, HEAP, lsl #32
    // 0x1103360: cmp             w1, NULL
    // 0x1103364: b.ne            #0x1103378
    // 0x1103368: LoadField: r1 = r0->field_7b
    //     0x1103368: ldur            w1, [x0, #0x7b]
    // 0x110336c: DecompressPointer r1
    //     0x110336c: add             x1, x1, HEAP, lsl #32
    // 0x1103370: mov             x0, x1
    // 0x1103374: b               #0x110337c
    // 0x1103378: mov             x0, x1
    // 0x110337c: mov             x2, x0
    // 0x1103380: b               #0x1103388
    // 0x1103384: mov             x2, x1
    // 0x1103388: ldur            x0, [fp, #-0x10]
    // 0x110338c: stur            x2, [fp, #-0x38]
    // 0x1103390: LoadField: r1 = r0->field_1f
    //     0x1103390: ldur            w1, [x0, #0x1f]
    // 0x1103394: DecompressPointer r1
    //     0x1103394: add             x1, x1, HEAP, lsl #32
    // 0x1103398: cmp             w1, NULL
    // 0x110339c: b.ne            #0x11033b0
    // 0x11033a0: LoadField: r1 = r0->field_f
    //     0x11033a0: ldur            w1, [x0, #0xf]
    // 0x11033a4: DecompressPointer r1
    //     0x11033a4: add             x1, x1, HEAP, lsl #32
    // 0x11033a8: mov             x0, x1
    // 0x11033ac: b               #0x11033b4
    // 0x11033b0: mov             x0, x1
    // 0x11033b4: cmp             w0, NULL
    // 0x11033b8: b.ne            #0x11033d0
    // 0x11033bc: ldur            x0, [fp, #-0x20]
    // 0x11033c0: LoadField: r1 = r0->field_1f
    //     0x11033c0: ldur            w1, [x0, #0x1f]
    // 0x11033c4: DecompressPointer r1
    //     0x11033c4: add             x1, x1, HEAP, lsl #32
    // 0x11033c8: mov             x3, x1
    // 0x11033cc: b               #0x11033d4
    // 0x11033d0: mov             x3, x0
    // 0x11033d4: ldur            x0, [fp, #-8]
    // 0x11033d8: stur            x3, [fp, #-0x30]
    // 0x11033dc: LoadField: r4 = r0->field_f
    //     0x11033dc: ldur            w4, [x0, #0xf]
    // 0x11033e0: DecompressPointer r4
    //     0x11033e0: add             x4, x4, HEAP, lsl #32
    // 0x11033e4: stur            x4, [fp, #-0x28]
    // 0x11033e8: LoadField: r0 = r4->field_9f
    //     0x11033e8: ldur            w0, [x4, #0x9f]
    // 0x11033ec: DecompressPointer r0
    //     0x11033ec: add             x0, x0, HEAP, lsl #32
    // 0x11033f0: stur            x0, [fp, #-0x20]
    // 0x11033f4: LoadField: r5 = r4->field_c7
    //     0x11033f4: ldur            w5, [x4, #0xc7]
    // 0x11033f8: DecompressPointer r5
    //     0x11033f8: add             x5, x5, HEAP, lsl #32
    // 0x11033fc: stur            x5, [fp, #-0x10]
    // 0x1103400: LoadField: r1 = r4->field_cb
    //     0x1103400: ldur            w1, [x4, #0xcb]
    // 0x1103404: DecompressPointer r1
    //     0x1103404: add             x1, x1, HEAP, lsl #32
    // 0x1103408: cmp             w1, NULL
    // 0x110340c: b.ne            #0x1103418
    // 0x1103410: r7 = false
    //     0x1103410: add             x7, NULL, #0x30  ; false
    // 0x1103414: b               #0x110341c
    // 0x1103418: mov             x7, x1
    // 0x110341c: ldur            x6, [fp, #-0x18]
    // 0x1103420: stur            x7, [fp, #-8]
    // 0x1103424: LoadField: r1 = r4->field_7
    //     0x1103424: ldur            w1, [x4, #7]
    // 0x1103428: DecompressPointer r1
    //     0x1103428: add             x1, x1, HEAP, lsl #32
    // 0x110342c: r0 = _ModalBottomSheet()
    //     0x110342c: bl              #0x1103484  ; Allocate_ModalBottomSheetStub -> _ModalBottomSheet<X0> (size=0x40)
    // 0x1103430: ldur            x1, [fp, #-0x28]
    // 0x1103434: StoreField: r0->field_f = r1
    //     0x1103434: stur            w1, [x0, #0xf]
    // 0x1103438: ldur            x1, [fp, #-0x38]
    // 0x110343c: StoreField: r0->field_1f = r1
    //     0x110343c: stur            w1, [x0, #0x1f]
    // 0x1103440: ldur            x1, [fp, #-0x30]
    // 0x1103444: StoreField: r0->field_23 = r1
    //     0x1103444: stur            w1, [x0, #0x23]
    // 0x1103448: ldur            x1, [fp, #-0x20]
    // 0x110344c: StoreField: r0->field_13 = r1
    //     0x110344c: stur            w1, [x0, #0x13]
    // 0x1103450: d0 = 0.562500
    //     0x1103450: fmov            d0, #0.56250000
    // 0x1103454: ArrayStore: r0[0] = d0  ; List_8
    //     0x1103454: stur            d0, [x0, #0x17]
    // 0x1103458: ldur            x1, [fp, #-0x10]
    // 0x110345c: StoreField: r0->field_33 = r1
    //     0x110345c: stur            w1, [x0, #0x33]
    // 0x1103460: ldur            x1, [fp, #-8]
    // 0x1103464: StoreField: r0->field_37 = r1
    //     0x1103464: stur            w1, [x0, #0x37]
    // 0x1103468: ldur            x1, [fp, #-0x18]
    // 0x110346c: StoreField: r0->field_3b = r1
    //     0x110346c: stur            w1, [x0, #0x3b]
    // 0x1103470: LeaveFrame
    //     0x1103470: mov             SP, fp
    //     0x1103474: ldp             fp, lr, [SP], #0x10
    // 0x1103478: ret
    //     0x1103478: ret             
    // 0x110347c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x110347c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1103480: b               #0x110324c
  }
}

// class id: 4881, size: 0x70, field offset: 0x54
class _RenderBottomSheetLayoutWithSizeListener extends RenderShiftedBox {

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb16f3c, size: 0x24
    // 0xb16f3c: EnterFrame
    //     0xb16f3c: stp             fp, lr, [SP, #-0x10]!
    //     0xb16f40: mov             fp, SP
    // 0xb16f44: ldr             x2, [fp, #0x10]
    // 0xb16f48: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb16f48: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf7d8] AnonymousClosure: static (0x12ffab4), in [package:material_color_utilities/dynamiccolor/material_dynamic_colors.dart] MaterialDynamicColors::scrim (0x8b98ec)
    //     0xb16f4c: ldr             x1, [x1, #0x7d8]
    // 0xb16f50: r0 = AllocateClosure()
    //     0xb16f50: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb16f54: LeaveFrame
    //     0xb16f54: mov             SP, fp
    //     0xb16f58: ldp             fp, lr, [SP], #0x10
    // 0xb16f5c: ret
    //     0xb16f5c: ret             
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb582dc, size: 0x24
    // 0xb582dc: EnterFrame
    //     0xb582dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb582e0: mov             fp, SP
    // 0xb582e4: ldr             x2, [fp, #0x10]
    // 0xb582e8: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb582e8: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf7d0] AnonymousClosure: static (0x12ffab4), in [package:material_color_utilities/dynamiccolor/material_dynamic_colors.dart] MaterialDynamicColors::scrim (0x8b98ec)
    //     0xb582ec: ldr             x1, [x1, #0x7d0]
    // 0xb582f0: r0 = AllocateClosure()
    //     0xb582f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb582f4: LeaveFrame
    //     0xb582f4: mov             SP, fp
    //     0xb582f8: ldp             fp, lr, [SP], #0x10
    // 0xb582fc: ret
    //     0xb582fc: ret             
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e464, size: 0x24
    // 0xb5e464: EnterFrame
    //     0xb5e464: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e468: mov             fp, SP
    // 0xb5e46c: ldr             x2, [fp, #0x10]
    // 0xb5e470: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e470: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf7c0] AnonymousClosure: static (0x12ffab4), in [package:material_color_utilities/dynamiccolor/material_dynamic_colors.dart] MaterialDynamicColors::scrim (0x8b98ec)
    //     0xb5e474: ldr             x1, [x1, #0x7c0]
    // 0xb5e478: r0 = AllocateClosure()
    //     0xb5e478: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e47c: LeaveFrame
    //     0xb5e47c: mov             SP, fp
    //     0xb5e480: ldp             fp, lr, [SP], #0x10
    // 0xb5e484: ret
    //     0xb5e484: ret             
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb609dc, size: 0x1b4
    // 0xb609dc: EnterFrame
    //     0xb609dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb609e0: mov             fp, SP
    // 0xb609e4: AllocStack(0x38)
    //     0xb609e4: sub             SP, SP, #0x38
    // 0xb609e8: SetupParameters(_RenderBottomSheetLayoutWithSizeListener this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb609e8: mov             x5, x1
    //     0xb609ec: mov             x4, x2
    //     0xb609f0: stur            x1, [fp, #-8]
    //     0xb609f4: stur            x2, [fp, #-0x10]
    //     0xb609f8: stur            x3, [fp, #-0x18]
    // 0xb609fc: CheckStackOverflow
    //     0xb609fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb60a00: cmp             SP, x16
    //     0xb60a04: b.ls            #0xb60b78
    // 0xb60a08: mov             x0, x4
    // 0xb60a0c: r2 = Null
    //     0xb60a0c: mov             x2, NULL
    // 0xb60a10: r1 = Null
    //     0xb60a10: mov             x1, NULL
    // 0xb60a14: r4 = 60
    //     0xb60a14: mov             x4, #0x3c
    // 0xb60a18: branchIfSmi(r0, 0xb60a24)
    //     0xb60a18: tbz             w0, #0, #0xb60a24
    // 0xb60a1c: r4 = LoadClassIdInstr(r0)
    //     0xb60a1c: ldur            x4, [x0, #-1]
    //     0xb60a20: ubfx            x4, x4, #0xc, #0x14
    // 0xb60a24: sub             x4, x4, #0xb46
    // 0xb60a28: cmp             x4, #1
    // 0xb60a2c: b.ls            #0xb60a40
    // 0xb60a30: r8 = BoxConstraints
    //     0xb60a30: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb60a34: r3 = Null
    //     0xb60a34: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf810] Null
    //     0xb60a38: ldr             x3, [x3, #0x810]
    // 0xb60a3c: r0 = BoxConstraints()
    //     0xb60a3c: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb60a40: ldur            x0, [fp, #-8]
    // 0xb60a44: LoadField: r3 = r0->field_4f
    //     0xb60a44: ldur            w3, [x0, #0x4f]
    // 0xb60a48: DecompressPointer r3
    //     0xb60a48: add             x3, x3, HEAP, lsl #32
    // 0xb60a4c: stur            x3, [fp, #-0x20]
    // 0xb60a50: cmp             w3, NULL
    // 0xb60a54: b.ne            #0xb60a68
    // 0xb60a58: r0 = Null
    //     0xb60a58: mov             x0, NULL
    // 0xb60a5c: LeaveFrame
    //     0xb60a5c: mov             SP, fp
    //     0xb60a60: ldp             fp, lr, [SP], #0x10
    // 0xb60a64: ret
    //     0xb60a64: ret             
    // 0xb60a68: mov             x1, x0
    // 0xb60a6c: ldur            x2, [fp, #-0x10]
    // 0xb60a70: r0 = _getConstraintsForChild()
    //     0xb60a70: bl              #0xb60bd0  ; [package:flutter/src/material/bottom_sheet.dart] _RenderBottomSheetLayoutWithSizeListener::_getConstraintsForChild
    // 0xb60a74: ldur            x1, [fp, #-0x20]
    // 0xb60a78: mov             x2, x0
    // 0xb60a7c: ldur            x3, [fp, #-0x18]
    // 0xb60a80: stur            x0, [fp, #-0x18]
    // 0xb60a84: r0 = getDryBaseline()
    //     0xb60a84: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb60a88: stur            x0, [fp, #-0x28]
    // 0xb60a8c: cmp             w0, NULL
    // 0xb60a90: b.ne            #0xb60aa4
    // 0xb60a94: r0 = Null
    //     0xb60a94: mov             x0, NULL
    // 0xb60a98: LeaveFrame
    //     0xb60a98: mov             SP, fp
    //     0xb60a9c: ldp             fp, lr, [SP], #0x10
    // 0xb60aa0: ret
    //     0xb60aa0: ret             
    // 0xb60aa4: ldur            x1, [fp, #-0x18]
    // 0xb60aa8: LoadField: d0 = r1->field_7
    //     0xb60aa8: ldur            d0, [x1, #7]
    // 0xb60aac: LoadField: d1 = r1->field_f
    //     0xb60aac: ldur            d1, [x1, #0xf]
    // 0xb60ab0: fcmp            d0, d1
    // 0xb60ab4: b.lt            #0xb60ad4
    // 0xb60ab8: ArrayLoad: d0 = r1[0]  ; List_8
    //     0xb60ab8: ldur            d0, [x1, #0x17]
    // 0xb60abc: LoadField: d1 = r1->field_1f
    //     0xb60abc: ldur            d1, [x1, #0x1f]
    // 0xb60ac0: fcmp            d0, d1
    // 0xb60ac4: b.lt            #0xb60ad4
    // 0xb60ac8: r0 = smallest()
    //     0xb60ac8: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xb60acc: mov             x3, x0
    // 0xb60ad0: b               #0xb60ae4
    // 0xb60ad4: mov             x2, x1
    // 0xb60ad8: ldur            x1, [fp, #-0x20]
    // 0xb60adc: r0 = getDryLayout()
    //     0xb60adc: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb60ae0: mov             x3, x0
    // 0xb60ae4: ldur            x0, [fp, #-0x28]
    // 0xb60ae8: ldur            x1, [fp, #-0x10]
    // 0xb60aec: stur            x3, [fp, #-0x18]
    // 0xb60af0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb60af0: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb60af4: r0 = constrainWidth()
    //     0xb60af4: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xb60af8: ldur            x1, [fp, #-0x10]
    // 0xb60afc: stur            d0, [fp, #-0x30]
    // 0xb60b00: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb60b00: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb60b04: r0 = constrainHeight()
    //     0xb60b04: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xb60b08: stur            d0, [fp, #-0x38]
    // 0xb60b0c: r0 = Size()
    //     0xb60b0c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb60b10: ldur            d0, [fp, #-0x30]
    // 0xb60b14: StoreField: r0->field_7 = d0
    //     0xb60b14: stur            d0, [x0, #7]
    // 0xb60b18: ldur            d0, [fp, #-0x38]
    // 0xb60b1c: StoreField: r0->field_f = d0
    //     0xb60b1c: stur            d0, [x0, #0xf]
    // 0xb60b20: ldur            x1, [fp, #-8]
    // 0xb60b24: mov             x2, x0
    // 0xb60b28: ldur            x3, [fp, #-0x18]
    // 0xb60b2c: r0 = _getPositionForChild()
    //     0xb60b2c: bl              #0xb60b90  ; [package:flutter/src/material/bottom_sheet.dart] _RenderBottomSheetLayoutWithSizeListener::_getPositionForChild
    // 0xb60b30: LoadField: d0 = r0->field_f
    //     0xb60b30: ldur            d0, [x0, #0xf]
    // 0xb60b34: ldur            x1, [fp, #-0x28]
    // 0xb60b38: LoadField: d1 = r1->field_7
    //     0xb60b38: ldur            d1, [x1, #7]
    // 0xb60b3c: fadd            d2, d1, d0
    // 0xb60b40: r0 = inline_Allocate_Double()
    //     0xb60b40: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb60b44: add             x0, x0, #0x10
    //     0xb60b48: cmp             x1, x0
    //     0xb60b4c: b.ls            #0xb60b80
    //     0xb60b50: str             x0, [THR, #0x60]  ; THR::top
    //     0xb60b54: sub             x0, x0, #0xf
    //     0xb60b58: mov             x1, #0xe19c
    //     0xb60b5c: movk            x1, #3, lsl #16
    //     0xb60b60: stur            x1, [x0, #-1]
    // 0xb60b64: dmb             ishst
    // 0xb60b68: StoreField: r0->field_7 = d2
    //     0xb60b68: stur            d2, [x0, #7]
    // 0xb60b6c: LeaveFrame
    //     0xb60b6c: mov             SP, fp
    //     0xb60b70: ldp             fp, lr, [SP], #0x10
    // 0xb60b74: ret
    //     0xb60b74: ret             
    // 0xb60b78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb60b78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb60b7c: b               #0xb60a08
    // 0xb60b80: SaveReg d2
    //     0xb60b80: str             q2, [SP, #-0x10]!
    // 0xb60b84: r0 = AllocateDouble()
    //     0xb60b84: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb60b88: RestoreReg d2
    //     0xb60b88: ldr             q2, [SP], #0x10
    // 0xb60b8c: b               #0xb60b68
  }
  _ _getPositionForChild(/* No info */) {
    // ** addr: 0xb60b90, size: 0x40
    // 0xb60b90: EnterFrame
    //     0xb60b90: stp             fp, lr, [SP, #-0x10]!
    //     0xb60b94: mov             fp, SP
    // 0xb60b98: AllocStack(0x8)
    //     0xb60b98: sub             SP, SP, #8
    // 0xb60b9c: LoadField: d0 = r2->field_f
    //     0xb60b9c: ldur            d0, [x2, #0xf]
    // 0xb60ba0: LoadField: d1 = r3->field_f
    //     0xb60ba0: ldur            d1, [x3, #0xf]
    // 0xb60ba4: LoadField: d2 = r1->field_5b
    //     0xb60ba4: ldur            d2, [x1, #0x5b]
    // 0xb60ba8: fmul            d3, d1, d2
    // 0xb60bac: fsub            d1, d0, d3
    // 0xb60bb0: stur            d1, [fp, #-8]
    // 0xb60bb4: r0 = Offset()
    //     0xb60bb4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb60bb8: StoreField: r0->field_7 = rZR
    //     0xb60bb8: stur            xzr, [x0, #7]
    // 0xb60bbc: ldur            d0, [fp, #-8]
    // 0xb60bc0: StoreField: r0->field_f = d0
    //     0xb60bc0: stur            d0, [x0, #0xf]
    // 0xb60bc4: LeaveFrame
    //     0xb60bc4: mov             SP, fp
    //     0xb60bc8: ldp             fp, lr, [SP], #0x10
    // 0xb60bcc: ret
    //     0xb60bcc: ret             
  }
  _ _getConstraintsForChild(/* No info */) {
    // ** addr: 0xb60bd0, size: 0x64
    // 0xb60bd0: EnterFrame
    //     0xb60bd0: stp             fp, lr, [SP, #-0x10]!
    //     0xb60bd4: mov             fp, SP
    // 0xb60bd8: AllocStack(0x10)
    //     0xb60bd8: sub             SP, SP, #0x10
    // 0xb60bdc: LoadField: d0 = r2->field_f
    //     0xb60bdc: ldur            d0, [x2, #0xf]
    // 0xb60be0: stur            d0, [fp, #-0x10]
    // 0xb60be4: LoadField: r0 = r1->field_63
    //     0xb60be4: ldur            w0, [x1, #0x63]
    // 0xb60be8: DecompressPointer r0
    //     0xb60be8: add             x0, x0, HEAP, lsl #32
    // 0xb60bec: tbnz            w0, #4, #0xb60bf8
    // 0xb60bf0: LoadField: d1 = r2->field_1f
    //     0xb60bf0: ldur            d1, [x2, #0x1f]
    // 0xb60bf4: b               #0xb60c08
    // 0xb60bf8: d1 = 0.562500
    //     0xb60bf8: fmov            d1, #0.56250000
    // 0xb60bfc: LoadField: d2 = r2->field_1f
    //     0xb60bfc: ldur            d2, [x2, #0x1f]
    // 0xb60c00: fmul            d3, d2, d1
    // 0xb60c04: mov             v1.16b, v3.16b
    // 0xb60c08: stur            d1, [fp, #-8]
    // 0xb60c0c: r0 = BoxConstraints()
    //     0xb60c0c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb60c10: ldur            d0, [fp, #-0x10]
    // 0xb60c14: StoreField: r0->field_7 = d0
    //     0xb60c14: stur            d0, [x0, #7]
    // 0xb60c18: StoreField: r0->field_f = d0
    //     0xb60c18: stur            d0, [x0, #0xf]
    // 0xb60c1c: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb60c1c: stur            xzr, [x0, #0x17]
    // 0xb60c20: ldur            d0, [fp, #-8]
    // 0xb60c24: StoreField: r0->field_1f = d0
    //     0xb60c24: stur            d0, [x0, #0x1f]
    // 0xb60c28: LeaveFrame
    //     0xb60c28: mov             SP, fp
    //     0xb60c2c: ldp             fp, lr, [SP], #0x10
    // 0xb60c30: ret
    //     0xb60c30: ret             
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbbc5ac, size: 0x330
    // 0xbbc5ac: EnterFrame
    //     0xbbc5ac: stp             fp, lr, [SP, #-0x10]!
    //     0xbbc5b0: mov             fp, SP
    // 0xbbc5b4: AllocStack(0x40)
    //     0xbbc5b4: sub             SP, SP, #0x40
    // 0xbbc5b8: SetupParameters(_RenderBottomSheetLayoutWithSizeListener this /* r1 => r3, fp-0x10 */)
    //     0xbbc5b8: mov             x3, x1
    //     0xbbc5bc: stur            x1, [fp, #-0x10]
    // 0xbbc5c0: CheckStackOverflow
    //     0xbbc5c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbc5c4: cmp             SP, x16
    //     0xbbc5c8: b.ls            #0xbbc8d0
    // 0xbbc5cc: LoadField: r4 = r3->field_27
    //     0xbbc5cc: ldur            w4, [x3, #0x27]
    // 0xbbc5d0: DecompressPointer r4
    //     0xbbc5d0: add             x4, x4, HEAP, lsl #32
    // 0xbbc5d4: stur            x4, [fp, #-8]
    // 0xbbc5d8: cmp             w4, NULL
    // 0xbbc5dc: b.eq            #0xbbc894
    // 0xbbc5e0: mov             x0, x4
    // 0xbbc5e4: r2 = Null
    //     0xbbc5e4: mov             x2, NULL
    // 0xbbc5e8: r1 = Null
    //     0xbbc5e8: mov             x1, NULL
    // 0xbbc5ec: r4 = LoadClassIdInstr(r0)
    //     0xbbc5ec: ldur            x4, [x0, #-1]
    //     0xbbc5f0: ubfx            x4, x4, #0xc, #0x14
    // 0xbbc5f4: sub             x4, x4, #0xb46
    // 0xbbc5f8: cmp             x4, #1
    // 0xbbc5fc: b.ls            #0xbbc610
    // 0xbbc600: r8 = BoxConstraints
    //     0xbbc600: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbc604: r3 = Null
    //     0xbbc604: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf7e0] Null
    //     0xbbc608: ldr             x3, [x3, #0x7e0]
    // 0xbbc60c: r0 = BoxConstraints()
    //     0xbbc60c: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbc610: ldur            x1, [fp, #-8]
    // 0xbbc614: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xbbc614: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xbbc618: r0 = constrainWidth()
    //     0xbbc618: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xbbc61c: ldur            x1, [fp, #-8]
    // 0xbbc620: stur            d0, [fp, #-0x28]
    // 0xbbc624: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xbbc624: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xbbc628: r0 = constrainHeight()
    //     0xbbc628: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xbbc62c: stur            d0, [fp, #-0x30]
    // 0xbbc630: r0 = Size()
    //     0xbbc630: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbbc634: ldur            d0, [fp, #-0x28]
    // 0xbbc638: StoreField: r0->field_7 = d0
    //     0xbbc638: stur            d0, [x0, #7]
    // 0xbbc63c: ldur            d0, [fp, #-0x30]
    // 0xbbc640: StoreField: r0->field_f = d0
    //     0xbbc640: stur            d0, [x0, #0xf]
    // 0xbbc644: ldur            x3, [fp, #-0x10]
    // 0xbbc648: StoreField: r3->field_4b = r0
    //     0xbbc648: stur            w0, [x3, #0x4b]
    //     0xbbc64c: ldurb           w16, [x3, #-1]
    //     0xbbc650: ldurb           w17, [x0, #-1]
    //     0xbbc654: and             x16, x17, x16, lsr #2
    //     0xbbc658: tst             x16, HEAP, lsr #32
    //     0xbbc65c: b.eq            #0xbbc664
    //     0xbbc660: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbbc664: LoadField: r4 = r3->field_4f
    //     0xbbc664: ldur            w4, [x3, #0x4f]
    // 0xbbc668: DecompressPointer r4
    //     0xbbc668: add             x4, x4, HEAP, lsl #32
    // 0xbbc66c: stur            x4, [fp, #-0x18]
    // 0xbbc670: cmp             w4, NULL
    // 0xbbc674: b.ne            #0xbbc688
    // 0xbbc678: r0 = Null
    //     0xbbc678: mov             x0, NULL
    // 0xbbc67c: LeaveFrame
    //     0xbbc67c: mov             SP, fp
    //     0xbbc680: ldp             fp, lr, [SP], #0x10
    // 0xbbc684: ret
    //     0xbbc684: ret             
    // 0xbbc688: LoadField: r5 = r3->field_27
    //     0xbbc688: ldur            w5, [x3, #0x27]
    // 0xbbc68c: DecompressPointer r5
    //     0xbbc68c: add             x5, x5, HEAP, lsl #32
    // 0xbbc690: stur            x5, [fp, #-8]
    // 0xbbc694: cmp             w5, NULL
    // 0xbbc698: b.eq            #0xbbc8b0
    // 0xbbc69c: mov             x0, x5
    // 0xbbc6a0: r2 = Null
    //     0xbbc6a0: mov             x2, NULL
    // 0xbbc6a4: r1 = Null
    //     0xbbc6a4: mov             x1, NULL
    // 0xbbc6a8: r4 = LoadClassIdInstr(r0)
    //     0xbbc6a8: ldur            x4, [x0, #-1]
    //     0xbbc6ac: ubfx            x4, x4, #0xc, #0x14
    // 0xbbc6b0: sub             x4, x4, #0xb46
    // 0xbbc6b4: cmp             x4, #1
    // 0xbbc6b8: b.ls            #0xbbc6cc
    // 0xbbc6bc: r8 = BoxConstraints
    //     0xbbc6bc: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbc6c0: r3 = Null
    //     0xbbc6c0: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf7f0] Null
    //     0xbbc6c4: ldr             x3, [x3, #0x7f0]
    // 0xbbc6c8: r0 = BoxConstraints()
    //     0xbbc6c8: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbc6cc: ldur            x1, [fp, #-0x10]
    // 0xbbc6d0: ldur            x2, [fp, #-8]
    // 0xbbc6d4: r0 = _getConstraintsForChild()
    //     0xbbc6d4: bl              #0xb60bd0  ; [package:flutter/src/material/bottom_sheet.dart] _RenderBottomSheetLayoutWithSizeListener::_getConstraintsForChild
    // 0xbbc6d8: mov             x3, x0
    // 0xbbc6dc: stur            x3, [fp, #-8]
    // 0xbbc6e0: LoadField: d0 = r3->field_7
    //     0xbbc6e0: ldur            d0, [x3, #7]
    // 0xbbc6e4: stur            d0, [fp, #-0x30]
    // 0xbbc6e8: LoadField: d1 = r3->field_f
    //     0xbbc6e8: ldur            d1, [x3, #0xf]
    // 0xbbc6ec: stur            d1, [fp, #-0x28]
    // 0xbbc6f0: fcmp            d0, d1
    // 0xbbc6f4: b.lt            #0xbbc714
    // 0xbbc6f8: ArrayLoad: d2 = r3[0]  ; List_8
    //     0xbbc6f8: ldur            d2, [x3, #0x17]
    // 0xbbc6fc: LoadField: d3 = r3->field_1f
    //     0xbbc6fc: ldur            d3, [x3, #0x1f]
    // 0xbbc700: fcmp            d2, d3
    // 0xbbc704: r16 = true
    //     0xbbc704: add             x16, NULL, #0x20  ; true
    // 0xbbc708: r17 = false
    //     0xbbc708: add             x17, NULL, #0x30  ; false
    // 0xbbc70c: csel            x0, x16, x17, ge
    // 0xbbc710: b               #0xbbc718
    // 0xbbc714: r0 = false
    //     0xbbc714: add             x0, NULL, #0x30  ; false
    // 0xbbc718: ldur            x4, [fp, #-0x18]
    // 0xbbc71c: eor             x1, x0, #0x10
    // 0xbbc720: r0 = LoadClassIdInstr(r4)
    //     0xbbc720: ldur            x0, [x4, #-1]
    //     0xbbc724: ubfx            x0, x0, #0xc, #0x14
    // 0xbbc728: str             x1, [SP]
    // 0xbbc72c: mov             x1, x4
    // 0xbbc730: mov             x2, x3
    // 0xbbc734: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbbc734: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbbc738: ldr             x4, [x4, #0xed0]
    // 0xbbc73c: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbbc73c: mov             x17, #0xe6b9
    //     0xbbc740: add             lr, x0, x17
    //     0xbbc744: ldr             lr, [x21, lr, lsl #3]
    //     0xbbc748: blr             lr
    // 0xbbc74c: ldur            x3, [fp, #-0x18]
    // 0xbbc750: LoadField: r4 = r3->field_7
    //     0xbbc750: ldur            w4, [x3, #7]
    // 0xbbc754: DecompressPointer r4
    //     0xbbc754: add             x4, x4, HEAP, lsl #32
    // 0xbbc758: stur            x4, [fp, #-0x20]
    // 0xbbc75c: cmp             w4, NULL
    // 0xbbc760: b.eq            #0xbbc8d8
    // 0xbbc764: mov             x0, x4
    // 0xbbc768: r2 = Null
    //     0xbbc768: mov             x2, NULL
    // 0xbbc76c: r1 = Null
    //     0xbbc76c: mov             x1, NULL
    // 0xbbc770: r4 = LoadClassIdInstr(r0)
    //     0xbbc770: ldur            x4, [x0, #-1]
    //     0xbbc774: ubfx            x4, x4, #0xc, #0x14
    // 0xbbc778: r17 = -4190
    //     0xbbc778: mov             x17, #-0x105e
    // 0xbbc77c: add             x4, x4, x17
    // 0xbbc780: cmp             x4, #0x17
    // 0xbbc784: b.ls            #0xbbc79c
    // 0xbbc788: r8 = BoxParentData
    //     0xbbc788: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0xbbc78c: ldr             x8, [x8, #0x5e8]
    // 0xbbc790: r3 = Null
    //     0xbbc790: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf800] Null
    //     0xbbc794: ldr             x3, [x3, #0x800]
    // 0xbbc798: r0 = DefaultTypeTest()
    //     0xbbc798: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbbc79c: ldur            d0, [fp, #-0x30]
    // 0xbbc7a0: ldur            d1, [fp, #-0x28]
    // 0xbbc7a4: fcmp            d0, d1
    // 0xbbc7a8: b.lt            #0xbbc7cc
    // 0xbbc7ac: ldur            x1, [fp, #-8]
    // 0xbbc7b0: ArrayLoad: d0 = r1[0]  ; List_8
    //     0xbbc7b0: ldur            d0, [x1, #0x17]
    // 0xbbc7b4: LoadField: d1 = r1->field_1f
    //     0xbbc7b4: ldur            d1, [x1, #0x1f]
    // 0xbbc7b8: fcmp            d0, d1
    // 0xbbc7bc: b.lt            #0xbbc7cc
    // 0xbbc7c0: r0 = smallest()
    //     0xbbc7c0: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xbbc7c4: mov             x3, x0
    // 0xbbc7c8: b               #0xbbc7d8
    // 0xbbc7cc: ldur            x1, [fp, #-0x18]
    // 0xbbc7d0: r0 = size()
    //     0xbbc7d0: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbc7d4: mov             x3, x0
    // 0xbbc7d8: ldur            x2, [fp, #-0x10]
    // 0xbbc7dc: ldur            x0, [fp, #-0x20]
    // 0xbbc7e0: mov             x1, x2
    // 0xbbc7e4: stur            x3, [fp, #-8]
    // 0xbbc7e8: r0 = size()
    //     0xbbc7e8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbc7ec: ldur            x1, [fp, #-0x10]
    // 0xbbc7f0: mov             x2, x0
    // 0xbbc7f4: ldur            x3, [fp, #-8]
    // 0xbbc7f8: r0 = _getPositionForChild()
    //     0xbbc7f8: bl              #0xb60b90  ; [package:flutter/src/material/bottom_sheet.dart] _RenderBottomSheetLayoutWithSizeListener::_getPositionForChild
    // 0xbbc7fc: ldur            x1, [fp, #-0x20]
    // 0xbbc800: StoreField: r1->field_7 = r0
    //     0xbbc800: stur            w0, [x1, #7]
    //     0xbbc804: ldurb           w16, [x1, #-1]
    //     0xbbc808: ldurb           w17, [x0, #-1]
    //     0xbbc80c: and             x16, x17, x16, lsr #2
    //     0xbbc810: tst             x16, HEAP, lsr #32
    //     0xbbc814: b.eq            #0xbbc81c
    //     0xbbc818: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbc81c: ldur            x1, [fp, #-0x10]
    // 0xbbc820: LoadField: r0 = r1->field_53
    //     0xbbc820: ldur            w0, [x1, #0x53]
    // 0xbbc824: DecompressPointer r0
    //     0xbbc824: add             x0, x0, HEAP, lsl #32
    // 0xbbc828: ldur            x2, [fp, #-8]
    // 0xbbc82c: LoadField: d0 = r2->field_7
    //     0xbbc82c: ldur            d0, [x2, #7]
    // 0xbbc830: LoadField: d1 = r0->field_7
    //     0xbbc830: ldur            d1, [x0, #7]
    // 0xbbc834: fcmp            d0, d1
    // 0xbbc838: b.ne            #0xbbc84c
    // 0xbbc83c: LoadField: d0 = r2->field_f
    //     0xbbc83c: ldur            d0, [x2, #0xf]
    // 0xbbc840: LoadField: d1 = r0->field_f
    //     0xbbc840: ldur            d1, [x0, #0xf]
    // 0xbbc844: fcmp            d0, d1
    // 0xbbc848: b.eq            #0xbbc884
    // 0xbbc84c: mov             x0, x2
    // 0xbbc850: StoreField: r1->field_53 = r0
    //     0xbbc850: stur            w0, [x1, #0x53]
    //     0xbbc854: ldurb           w16, [x1, #-1]
    //     0xbbc858: ldurb           w17, [x0, #-1]
    //     0xbbc85c: and             x16, x17, x16, lsr #2
    //     0xbbc860: tst             x16, HEAP, lsr #32
    //     0xbbc864: b.eq            #0xbbc86c
    //     0xbbc868: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbc86c: LoadField: r0 = r1->field_57
    //     0xbbc86c: ldur            w0, [x1, #0x57]
    // 0xbbc870: DecompressPointer r0
    //     0xbbc870: add             x0, x0, HEAP, lsl #32
    // 0xbbc874: stp             x2, x0, [SP]
    // 0xbbc878: ClosureCall
    //     0xbbc878: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbbc87c: ldur            x2, [x0, #0x1f]
    //     0xbbc880: blr             x2
    // 0xbbc884: r0 = Null
    //     0xbbc884: mov             x0, NULL
    // 0xbbc888: LeaveFrame
    //     0xbbc888: mov             SP, fp
    //     0xbbc88c: ldp             fp, lr, [SP], #0x10
    // 0xbbc890: ret
    //     0xbbc890: ret             
    // 0xbbc894: r0 = StateError()
    //     0xbbc894: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbc898: mov             x1, x0
    // 0xbbc89c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbc89c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbc8a0: StoreField: r1->field_b = r0
    //     0xbbc8a0: stur            w0, [x1, #0xb]
    // 0xbbc8a4: mov             x0, x1
    // 0xbbc8a8: r0 = Throw()
    //     0xbbc8a8: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbc8ac: brk             #0
    // 0xbbc8b0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbc8b0: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbc8b4: r0 = StateError()
    //     0xbbc8b4: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbc8b8: mov             x1, x0
    // 0xbbc8bc: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbc8bc: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbc8c0: StoreField: r1->field_b = r0
    //     0xbbc8c0: stur            w0, [x1, #0xb]
    // 0xbbc8c4: mov             x0, x1
    // 0xbbc8c8: r0 = Throw()
    //     0xbbc8c8: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbc8cc: brk             #0
    // 0xbbc8d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbc8d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbc8d4: b               #0xbbc5cc
    // 0xbbc8d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbc8d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ scrollControlDisabledMaxHeightRatio=(/* No info */) {
    // ** addr: 0xcf4730, size: 0x50
    // 0xcf4730: EnterFrame
    //     0xcf4730: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4734: mov             fp, SP
    // 0xcf4738: d1 = 0.562500
    //     0xcf4738: fmov            d1, #0.56250000
    // 0xcf473c: CheckStackOverflow
    //     0xcf473c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf4740: cmp             SP, x16
    //     0xcf4744: b.ls            #0xcf4778
    // 0xcf4748: fcmp            d1, d1
    // 0xcf474c: b.ne            #0xcf4760
    // 0xcf4750: r0 = Null
    //     0xcf4750: mov             x0, NULL
    // 0xcf4754: LeaveFrame
    //     0xcf4754: mov             SP, fp
    //     0xcf4758: ldp             fp, lr, [SP], #0x10
    // 0xcf475c: ret
    //     0xcf475c: ret             
    // 0xcf4760: StoreField: r1->field_67 = d1
    //     0xcf4760: stur            d1, [x1, #0x67]
    // 0xcf4764: r0 = markNeedsLayout()
    //     0xcf4764: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf4768: r0 = Null
    //     0xcf4768: mov             x0, NULL
    // 0xcf476c: LeaveFrame
    //     0xcf476c: mov             SP, fp
    //     0xcf4770: ldp             fp, lr, [SP], #0x10
    // 0xcf4774: ret
    //     0xcf4774: ret             
    // 0xcf4778: r0 = StackOverflowSharedWithFPURegs()
    //     0xcf4778: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xcf477c: b               #0xcf4748
  }
  set _ isScrollControlled=(/* No info */) {
    // ** addr: 0xcf4780, size: 0x54
    // 0xcf4780: EnterFrame
    //     0xcf4780: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4784: mov             fp, SP
    // 0xcf4788: CheckStackOverflow
    //     0xcf4788: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf478c: cmp             SP, x16
    //     0xcf4790: b.ls            #0xcf47cc
    // 0xcf4794: LoadField: r0 = r1->field_63
    //     0xcf4794: ldur            w0, [x1, #0x63]
    // 0xcf4798: DecompressPointer r0
    //     0xcf4798: add             x0, x0, HEAP, lsl #32
    // 0xcf479c: cmp             w0, w2
    // 0xcf47a0: b.ne            #0xcf47b4
    // 0xcf47a4: r0 = Null
    //     0xcf47a4: mov             x0, NULL
    // 0xcf47a8: LeaveFrame
    //     0xcf47a8: mov             SP, fp
    //     0xcf47ac: ldp             fp, lr, [SP], #0x10
    // 0xcf47b0: ret
    //     0xcf47b0: ret             
    // 0xcf47b4: StoreField: r1->field_63 = r2
    //     0xcf47b4: stur            w2, [x1, #0x63]
    // 0xcf47b8: r0 = markNeedsLayout()
    //     0xcf47b8: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf47bc: r0 = Null
    //     0xcf47bc: mov             x0, NULL
    // 0xcf47c0: LeaveFrame
    //     0xcf47c0: mov             SP, fp
    //     0xcf47c4: ldp             fp, lr, [SP], #0x10
    // 0xcf47c8: ret
    //     0xcf47c8: ret             
    // 0xcf47cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf47cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf47d0: b               #0xcf4794
  }
  set _ onChildSizeChanged=(/* No info */) {
    // ** addr: 0xcf4824, size: 0x88
    // 0xcf4824: EnterFrame
    //     0xcf4824: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4828: mov             fp, SP
    // 0xcf482c: AllocStack(0x20)
    //     0xcf482c: sub             SP, SP, #0x20
    // 0xcf4830: SetupParameters(_RenderBottomSheetLayoutWithSizeListener this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xcf4830: mov             x0, x2
    //     0xcf4834: stur            x1, [fp, #-8]
    //     0xcf4838: stur            x2, [fp, #-0x10]
    // 0xcf483c: CheckStackOverflow
    //     0xcf483c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf4840: cmp             SP, x16
    //     0xcf4844: b.ls            #0xcf48a4
    // 0xcf4848: LoadField: r2 = r1->field_57
    //     0xcf4848: ldur            w2, [x1, #0x57]
    // 0xcf484c: DecompressPointer r2
    //     0xcf484c: add             x2, x2, HEAP, lsl #32
    // 0xcf4850: stp             x0, x2, [SP]
    // 0xcf4854: r0 = ==()
    //     0xcf4854: bl              #0x12b7e74  ; [dart:core] _Closure::==
    // 0xcf4858: tbnz            w0, #4, #0xcf486c
    // 0xcf485c: r0 = Null
    //     0xcf485c: mov             x0, NULL
    // 0xcf4860: LeaveFrame
    //     0xcf4860: mov             SP, fp
    //     0xcf4864: ldp             fp, lr, [SP], #0x10
    // 0xcf4868: ret
    //     0xcf4868: ret             
    // 0xcf486c: ldur            x1, [fp, #-8]
    // 0xcf4870: ldur            x0, [fp, #-0x10]
    // 0xcf4874: StoreField: r1->field_57 = r0
    //     0xcf4874: stur            w0, [x1, #0x57]
    //     0xcf4878: ldurb           w16, [x1, #-1]
    //     0xcf487c: ldurb           w17, [x0, #-1]
    //     0xcf4880: and             x16, x17, x16, lsr #2
    //     0xcf4884: tst             x16, HEAP, lsr #32
    //     0xcf4888: b.eq            #0xcf4890
    //     0xcf488c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf4890: r0 = markNeedsLayout()
    //     0xcf4890: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf4894: r0 = Null
    //     0xcf4894: mov             x0, NULL
    // 0xcf4898: LeaveFrame
    //     0xcf4898: mov             SP, fp
    //     0xcf489c: ldp             fp, lr, [SP], #0x10
    // 0xcf48a0: ret
    //     0xcf48a0: ret             
    // 0xcf48a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf48a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf48a8: b               #0xcf4848
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10efc70, size: 0x24
    // 0x10efc70: EnterFrame
    //     0x10efc70: stp             fp, lr, [SP, #-0x10]!
    //     0x10efc74: mov             fp, SP
    // 0x10efc78: ldr             x2, [fp, #0x10]
    // 0x10efc7c: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10efc7c: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf7c8] AnonymousClosure: static (0x12ffab4), in [package:material_color_utilities/dynamiccolor/material_dynamic_colors.dart] MaterialDynamicColors::scrim (0x8b98ec)
    //     0x10efc80: ldr             x1, [x1, #0x7c8]
    // 0x10efc84: r0 = AllocateClosure()
    //     0x10efc84: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10efc88: LeaveFrame
    //     0x10efc88: mov             SP, fp
    //     0x10efc8c: ldp             fp, lr, [SP], #0x10
    // 0x10efc90: ret
    //     0x10efc90: ret             
  }
  _ _RenderBottomSheetLayoutWithSizeListener(/* No info */) {
    // ** addr: 0x11cf7d8, size: 0xb0
    // 0x11cf7d8: EnterFrame
    //     0x11cf7d8: stp             fp, lr, [SP, #-0x10]!
    //     0x11cf7dc: mov             fp, SP
    // 0x11cf7e0: AllocStack(0x8)
    //     0x11cf7e0: sub             SP, SP, #8
    // 0x11cf7e4: r0 = Instance_Size
    //     0x11cf7e4: ldr             x0, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0x11cf7e8: d1 = 0.562500
    //     0x11cf7e8: fmov            d1, #0.56250000
    // 0x11cf7ec: stur            x1, [fp, #-8]
    // 0x11cf7f0: mov             x16, x3
    // 0x11cf7f4: mov             x3, x1
    // 0x11cf7f8: mov             x1, x16
    // 0x11cf7fc: CheckStackOverflow
    //     0x11cf7fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cf800: cmp             SP, x16
    //     0x11cf804: b.ls            #0x11cf880
    // 0x11cf808: StoreField: r3->field_53 = r0
    //     0x11cf808: stur            w0, [x3, #0x53]
    // 0x11cf80c: mov             x0, x1
    // 0x11cf810: StoreField: r3->field_57 = r0
    //     0x11cf810: stur            w0, [x3, #0x57]
    //     0x11cf814: ldurb           w16, [x3, #-1]
    //     0x11cf818: ldurb           w17, [x0, #-1]
    //     0x11cf81c: and             x16, x17, x16, lsr #2
    //     0x11cf820: tst             x16, HEAP, lsr #32
    //     0x11cf824: b.eq            #0x11cf82c
    //     0x11cf828: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11cf82c: StoreField: r3->field_5b = d0
    //     0x11cf82c: stur            d0, [x3, #0x5b]
    // 0x11cf830: StoreField: r3->field_63 = r2
    //     0x11cf830: stur            w2, [x3, #0x63]
    // 0x11cf834: StoreField: r3->field_67 = d1
    //     0x11cf834: stur            d1, [x3, #0x67]
    // 0x11cf838: r0 = _LayoutCacheStorage()
    //     0x11cf838: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11cf83c: ldur            x2, [fp, #-8]
    // 0x11cf840: StoreField: r2->field_47 = r0
    //     0x11cf840: stur            w0, [x2, #0x47]
    //     0x11cf844: ldurb           w16, [x2, #-1]
    //     0x11cf848: ldurb           w17, [x0, #-1]
    //     0x11cf84c: and             x16, x17, x16, lsr #2
    //     0x11cf850: tst             x16, HEAP, lsr #32
    //     0x11cf854: b.eq            #0x11cf85c
    //     0x11cf858: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11cf85c: mov             x1, x2
    // 0x11cf860: r0 = RenderObject()
    //     0x11cf860: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11cf864: ldur            x1, [fp, #-8]
    // 0x11cf868: r2 = Null
    //     0x11cf868: mov             x2, NULL
    // 0x11cf86c: r0 = child=()
    //     0x11cf86c: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11cf870: r0 = Null
    //     0x11cf870: mov             x0, NULL
    // 0x11cf874: LeaveFrame
    //     0x11cf874: mov             SP, fp
    //     0x11cf878: ldp             fp, lr, [SP], #0x10
    // 0x11cf87c: ret
    //     0x11cf87c: ret             
    // 0x11cf880: r0 = StackOverflowSharedWithFPURegs()
    //     0x11cf880: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11cf884: b               #0x11cf808
  }
}

// class id: 5202, size: 0x44, field offset: 0x3c
class _BottomSheetDefaultsM3 extends BottomSheetThemeData {

  late final ColorScheme _colors; // offset: 0x40

  ColorScheme _colors(_BottomSheetDefaultsM3) {
    // ** addr: 0xdebe74, size: 0x44
    // 0xdebe74: EnterFrame
    //     0xdebe74: stp             fp, lr, [SP, #-0x10]!
    //     0xdebe78: mov             fp, SP
    // 0xdebe7c: CheckStackOverflow
    //     0xdebe7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdebe80: cmp             SP, x16
    //     0xdebe84: b.ls            #0xdebeb0
    // 0xdebe88: ldr             x0, [fp, #0x10]
    // 0xdebe8c: LoadField: r1 = r0->field_3b
    //     0xdebe8c: ldur            w1, [x0, #0x3b]
    // 0xdebe90: DecompressPointer r1
    //     0xdebe90: add             x1, x1, HEAP, lsl #32
    // 0xdebe94: r0 = of()
    //     0xdebe94: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdebe98: LoadField: r1 = r0->field_3f
    //     0xdebe98: ldur            w1, [x0, #0x3f]
    // 0xdebe9c: DecompressPointer r1
    //     0xdebe9c: add             x1, x1, HEAP, lsl #32
    // 0xdebea0: mov             x0, x1
    // 0xdebea4: LeaveFrame
    //     0xdebea4: mov             SP, fp
    //     0xdebea8: ldp             fp, lr, [SP], #0x10
    // 0xdebeac: ret
    //     0xdebeac: ret             
    // 0xdebeb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdebeb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdebeb4: b               #0xdebe88
  }
}

// class id: 5477, size: 0x1c, field offset: 0x14
class _ModalBottomSheetState<C1X0> extends State<C1X0> {

  late final ProxyAnimation _sheetAnimation; // offset: 0x14
  late final CurvedAnimation _curvedSheetAnimation; // offset: 0x18

  _ build(/* No info */) {
    // ** addr: 0xdebeb8, size: 0x1d8
    // 0xdebeb8: EnterFrame
    //     0xdebeb8: stp             fp, lr, [SP, #-0x10]!
    //     0xdebebc: mov             fp, SP
    // 0xdebec0: AllocStack(0x50)
    //     0xdebec0: sub             SP, SP, #0x50
    // 0xdebec4: SetupParameters(_ModalBottomSheetState<C1X0> this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xdebec4: mov             x0, x1
    //     0xdebec8: stur            x1, [fp, #-8]
    //     0xdebecc: mov             x1, x2
    //     0xdebed0: stur            x2, [fp, #-0x10]
    // 0xdebed4: CheckStackOverflow
    //     0xdebed4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdebed8: cmp             SP, x16
    //     0xdebedc: b.ls            #0xdec078
    // 0xdebee0: r1 = 3
    //     0xdebee0: mov             x1, #3
    // 0xdebee4: r0 = AllocateContext()
    //     0xdebee4: bl              #0x13de838  ; AllocateContextStub
    // 0xdebee8: mov             x2, x0
    // 0xdebeec: ldur            x0, [fp, #-8]
    // 0xdebef0: stur            x2, [fp, #-0x18]
    // 0xdebef4: StoreField: r2->field_f = r0
    //     0xdebef4: stur            w0, [x2, #0xf]
    // 0xdebef8: ldur            x1, [fp, #-0x10]
    // 0xdebefc: StoreField: r2->field_13 = r1
    //     0xdebefc: stur            w1, [x2, #0x13]
    // 0xdebf00: r0 = of()
    //     0xdebf00: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xdebf04: ldur            x1, [fp, #-8]
    // 0xdebf08: mov             x2, x0
    // 0xdebf0c: r0 = _getRouteLabel()
    //     0xdebf0c: bl              #0xdec180  ; [package:flutter/src/material/bottom_sheet.dart] _ModalBottomSheetState::_getRouteLabel
    // 0xdebf10: ldur            x2, [fp, #-0x18]
    // 0xdebf14: ArrayStore: r2[0] = r0  ; List_4
    //     0xdebf14: stur            w0, [x2, #0x17]
    //     0xdebf18: ldurb           w16, [x2, #-1]
    //     0xdebf1c: ldurb           w17, [x0, #-1]
    //     0xdebf20: and             x16, x17, x16, lsr #2
    //     0xdebf24: tst             x16, HEAP, lsr #32
    //     0xdebf28: b.eq            #0xdebf30
    //     0xdebf2c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xdebf30: ldur            x0, [fp, #-8]
    // 0xdebf34: LoadField: r1 = r0->field_13
    //     0xdebf34: ldur            w1, [x0, #0x13]
    // 0xdebf38: DecompressPointer r1
    //     0xdebf38: add             x1, x1, HEAP, lsl #32
    // 0xdebf3c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdebf40: cmp             w1, w16
    // 0xdebf44: b.eq            #0xdec080
    // 0xdebf48: stur            x1, [fp, #-0x48]
    // 0xdebf4c: LoadField: r3 = r0->field_b
    //     0xdebf4c: ldur            w3, [x0, #0xb]
    // 0xdebf50: DecompressPointer r3
    //     0xdebf50: add             x3, x3, HEAP, lsl #32
    // 0xdebf54: cmp             w3, NULL
    // 0xdebf58: b.eq            #0xdec08c
    // 0xdebf5c: LoadField: r4 = r3->field_f
    //     0xdebf5c: ldur            w4, [x3, #0xf]
    // 0xdebf60: DecompressPointer r4
    //     0xdebf60: add             x4, x4, HEAP, lsl #32
    // 0xdebf64: LoadField: r5 = r4->field_eb
    //     0xdebf64: ldur            w5, [x4, #0xeb]
    // 0xdebf68: DecompressPointer r5
    //     0xdebf68: add             x5, x5, HEAP, lsl #32
    // 0xdebf6c: stur            x5, [fp, #-0x40]
    // 0xdebf70: LoadField: r6 = r4->field_97
    //     0xdebf70: ldur            w6, [x4, #0x97]
    // 0xdebf74: DecompressPointer r6
    //     0xdebf74: add             x6, x6, HEAP, lsl #32
    // 0xdebf78: stur            x6, [fp, #-0x38]
    // 0xdebf7c: LoadField: r4 = r3->field_1f
    //     0xdebf7c: ldur            w4, [x3, #0x1f]
    // 0xdebf80: DecompressPointer r4
    //     0xdebf80: add             x4, x4, HEAP, lsl #32
    // 0xdebf84: stur            x4, [fp, #-0x30]
    // 0xdebf88: LoadField: r7 = r3->field_23
    //     0xdebf88: ldur            w7, [x3, #0x23]
    // 0xdebf8c: DecompressPointer r7
    //     0xdebf8c: add             x7, x7, HEAP, lsl #32
    // 0xdebf90: stur            x7, [fp, #-0x28]
    // 0xdebf94: LoadField: r8 = r3->field_33
    //     0xdebf94: ldur            w8, [x3, #0x33]
    // 0xdebf98: DecompressPointer r8
    //     0xdebf98: add             x8, x8, HEAP, lsl #32
    // 0xdebf9c: stur            x8, [fp, #-0x20]
    // 0xdebfa0: LoadField: r9 = r3->field_37
    //     0xdebfa0: ldur            w9, [x3, #0x37]
    // 0xdebfa4: DecompressPointer r9
    //     0xdebfa4: add             x9, x9, HEAP, lsl #32
    // 0xdebfa8: stur            x9, [fp, #-0x10]
    // 0xdebfac: r0 = BottomSheet()
    //     0xdebfac: bl              #0xdec174  ; AllocateBottomSheetStub -> BottomSheet (size=0x48)
    // 0xdebfb0: mov             x3, x0
    // 0xdebfb4: ldur            x0, [fp, #-0x40]
    // 0xdebfb8: stur            x3, [fp, #-0x50]
    // 0xdebfbc: StoreField: r3->field_b = r0
    //     0xdebfbc: stur            w0, [x3, #0xb]
    // 0xdebfc0: ldur            x0, [fp, #-0x20]
    // 0xdebfc4: ArrayStore: r3[0] = r0  ; List_4
    //     0xdebfc4: stur            w0, [x3, #0x17]
    // 0xdebfc8: ldur            x0, [fp, #-0x10]
    // 0xdebfcc: StoreField: r3->field_1b = r0
    //     0xdebfcc: stur            w0, [x3, #0x1b]
    // 0xdebfd0: ldur            x2, [fp, #-8]
    // 0xdebfd4: r1 = Function 'handleDragStart':.
    //     0xdebfd4: add             x1, PP, #0xab, lsl #12  ; [pp+0xab188] AnonymousClosure: (0xdec700), in [package:flutter/src/material/bottom_sheet.dart] _ModalBottomSheetState::handleDragStart (0xdec73c)
    //     0xdebfd8: ldr             x1, [x1, #0x188]
    // 0xdebfdc: r0 = AllocateClosure()
    //     0xdebfdc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdebfe0: mov             x1, x0
    // 0xdebfe4: ldur            x0, [fp, #-0x50]
    // 0xdebfe8: StoreField: r0->field_27 = r1
    //     0xdebfe8: stur            w1, [x0, #0x27]
    // 0xdebfec: ldur            x2, [fp, #-8]
    // 0xdebff0: r1 = Function 'handleDragEnd':.
    //     0xdebff0: add             x1, PP, #0xab, lsl #12  ; [pp+0xab190] AnonymousClosure: (0xdec4d0), in [package:flutter/src/material/bottom_sheet.dart] _ModalBottomSheetState::handleDragEnd (0xdec564)
    //     0xdebff4: ldr             x1, [x1, #0x190]
    // 0xdebff8: r0 = AllocateClosure()
    //     0xdebff8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdebffc: mov             x1, x0
    // 0xdec000: ldur            x0, [fp, #-0x50]
    // 0xdec004: StoreField: r0->field_2b = r1
    //     0xdec004: stur            w1, [x0, #0x2b]
    // 0xdec008: ldur            x1, [fp, #-0x30]
    // 0xdec00c: StoreField: r0->field_2f = r1
    //     0xdec00c: stur            w1, [x0, #0x2f]
    // 0xdec010: ldur            x1, [fp, #-0x28]
    // 0xdec014: StoreField: r0->field_37 = r1
    //     0xdec014: stur            w1, [x0, #0x37]
    // 0xdec018: ldur            x2, [fp, #-0x18]
    // 0xdec01c: r1 = Function '<anonymous closure>':.
    //     0xdec01c: add             x1, PP, #0xab, lsl #12  ; [pp+0xab198] AnonymousClosure: (0xdec444), in [package:flutter/src/material/bottom_sheet.dart] _ModalBottomSheetState::build (0xdebeb8)
    //     0xdec020: ldr             x1, [x1, #0x198]
    // 0xdec024: r0 = AllocateClosure()
    //     0xdec024: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdec028: mov             x1, x0
    // 0xdec02c: ldur            x0, [fp, #-0x50]
    // 0xdec030: StoreField: r0->field_f = r1
    //     0xdec030: stur            w1, [x0, #0xf]
    // 0xdec034: ldur            x1, [fp, #-0x38]
    // 0xdec038: StoreField: r0->field_13 = r1
    //     0xdec038: stur            w1, [x0, #0x13]
    // 0xdec03c: ldur            x2, [fp, #-0x18]
    // 0xdec040: r1 = Function '<anonymous closure>':.
    //     0xdec040: add             x1, PP, #0xab, lsl #12  ; [pp+0xab1a0] AnonymousClosure: (0xdec1cc), in [package:flutter/src/material/bottom_sheet.dart] _ModalBottomSheetState::build (0xdebeb8)
    //     0xdec044: ldr             x1, [x1, #0x1a0]
    // 0xdec048: r0 = AllocateClosure()
    //     0xdec048: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdec04c: stur            x0, [fp, #-8]
    // 0xdec050: r0 = AnimatedBuilder()
    //     0xdec050: bl              #0x918e2c  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0xdec054: ldur            x1, [fp, #-8]
    // 0xdec058: StoreField: r0->field_f = r1
    //     0xdec058: stur            w1, [x0, #0xf]
    // 0xdec05c: ldur            x1, [fp, #-0x50]
    // 0xdec060: StoreField: r0->field_13 = r1
    //     0xdec060: stur            w1, [x0, #0x13]
    // 0xdec064: ldur            x1, [fp, #-0x48]
    // 0xdec068: StoreField: r0->field_b = r1
    //     0xdec068: stur            w1, [x0, #0xb]
    // 0xdec06c: LeaveFrame
    //     0xdec06c: mov             SP, fp
    //     0xdec070: ldp             fp, lr, [SP], #0x10
    // 0xdec074: ret
    //     0xdec074: ret             
    // 0xdec078: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdec078: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdec07c: b               #0xdebee0
    // 0xdec080: r9 = _sheetAnimation
    //     0xdec080: add             x9, PP, #0xab, lsl #12  ; [pp+0xab1a8] Field <_ModalBottomSheetState@726001611._sheetAnimation@726001611>: late final (offset: 0x14)
    //     0xdec084: ldr             x9, [x9, #0x1a8]
    // 0xdec088: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdec088: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdec08c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdec08c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getRouteLabel(/* No info */) {
    // ** addr: 0xdec180, size: 0x4c
    // 0xdec180: EnterFrame
    //     0xdec180: stp             fp, lr, [SP, #-0x10]!
    //     0xdec184: mov             fp, SP
    // 0xdec188: mov             x0, x1
    // 0xdec18c: mov             x1, x2
    // 0xdec190: CheckStackOverflow
    //     0xdec190: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdec194: cmp             SP, x16
    //     0xdec198: b.ls            #0xdec1c4
    // 0xdec19c: r0 = LoadClassIdInstr(r1)
    //     0xdec19c: ldur            x0, [x1, #-1]
    //     0xdec1a0: ubfx            x0, x0, #0xc, #0x14
    // 0xdec1a4: r0 = GDT[cid_x0 + 0x15f29]()
    //     0xdec1a4: mov             x17, #0x5f29
    //     0xdec1a8: movk            x17, #1, lsl #16
    //     0xdec1ac: add             lr, x0, x17
    //     0xdec1b0: ldr             lr, [x21, lr, lsl #3]
    //     0xdec1b4: blr             lr
    // 0xdec1b8: LeaveFrame
    //     0xdec1b8: mov             SP, fp
    //     0xdec1bc: ldp             fp, lr, [SP], #0x10
    // 0xdec1c0: ret
    //     0xdec1c0: ret             
    // 0xdec1c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdec1c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdec1c8: b               #0xdec19c
  }
  [closure] Semantics <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0xdec1cc, size: 0x148
    // 0xdec1cc: EnterFrame
    //     0xdec1cc: stp             fp, lr, [SP, #-0x10]!
    //     0xdec1d0: mov             fp, SP
    // 0xdec1d4: AllocStack(0x50)
    //     0xdec1d4: sub             SP, SP, #0x50
    // 0xdec1d8: SetupParameters([dynamic _ /* r0 */])
    //     0xdec1d8: ldr             x0, [fp, #0x20]
    //     0xdec1dc: ldur            w2, [x0, #0x17]
    //     0xdec1e0: add             x2, x2, HEAP, lsl #32
    //     0xdec1e4: stur            x2, [fp, #-8]
    // 0xdec1e8: CheckStackOverflow
    //     0xdec1e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdec1ec: cmp             SP, x16
    //     0xdec1f0: b.ls            #0xdec2fc
    // 0xdec1f4: LoadField: r0 = r2->field_f
    //     0xdec1f4: ldur            w0, [x2, #0xf]
    // 0xdec1f8: DecompressPointer r0
    //     0xdec1f8: add             x0, x0, HEAP, lsl #32
    // 0xdec1fc: LoadField: r1 = r0->field_13
    //     0xdec1fc: ldur            w1, [x0, #0x13]
    // 0xdec200: DecompressPointer r1
    //     0xdec200: add             x1, x1, HEAP, lsl #32
    // 0xdec204: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdec208: cmp             w1, w16
    // 0xdec20c: b.eq            #0xdec304
    // 0xdec210: r0 = value()
    //     0xdec210: bl              #0xae66fc  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::value
    // 0xdec214: ldur            x2, [fp, #-8]
    // 0xdec218: stur            x0, [fp, #-0x20]
    // 0xdec21c: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xdec21c: ldur            w3, [x2, #0x17]
    // 0xdec220: DecompressPointer r3
    //     0xdec220: add             x3, x3, HEAP, lsl #32
    // 0xdec224: stur            x3, [fp, #-0x18]
    // 0xdec228: LoadField: r1 = r2->field_f
    //     0xdec228: ldur            w1, [x2, #0xf]
    // 0xdec22c: DecompressPointer r1
    //     0xdec22c: add             x1, x1, HEAP, lsl #32
    // 0xdec230: LoadField: r4 = r1->field_b
    //     0xdec230: ldur            w4, [x1, #0xb]
    // 0xdec234: DecompressPointer r4
    //     0xdec234: add             x4, x4, HEAP, lsl #32
    // 0xdec238: cmp             w4, NULL
    // 0xdec23c: b.eq            #0xdec310
    // 0xdec240: LoadField: r5 = r4->field_13
    //     0xdec240: ldur            w5, [x4, #0x13]
    // 0xdec244: DecompressPointer r5
    //     0xdec244: add             x5, x5, HEAP, lsl #32
    // 0xdec248: stur            x5, [fp, #-0x10]
    // 0xdec24c: r1 = Function '<anonymous closure>':.
    //     0xdec24c: add             x1, PP, #0xab, lsl #12  ; [pp+0xab1b0] AnonymousClosure: (0xdec320), in [package:flutter/src/material/bottom_sheet.dart] _ModalBottomSheetState::build (0xdebeb8)
    //     0xdec250: ldr             x1, [x1, #0x1b0]
    // 0xdec254: r0 = AllocateClosure()
    //     0xdec254: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdec258: stur            x0, [fp, #-8]
    // 0xdec25c: r0 = _BottomSheetLayoutWithSizeListener()
    //     0xdec25c: bl              #0xdec314  ; Allocate_BottomSheetLayoutWithSizeListenerStub -> _BottomSheetLayoutWithSizeListener (size=0x28)
    // 0xdec260: mov             x1, x0
    // 0xdec264: ldur            x0, [fp, #-8]
    // 0xdec268: stur            x1, [fp, #-0x28]
    // 0xdec26c: StoreField: r1->field_f = r0
    //     0xdec26c: stur            w0, [x1, #0xf]
    // 0xdec270: ldur            x0, [fp, #-0x20]
    // 0xdec274: LoadField: d0 = r0->field_7
    //     0xdec274: ldur            d0, [x0, #7]
    // 0xdec278: StoreField: r1->field_13 = d0
    //     0xdec278: stur            d0, [x1, #0x13]
    // 0xdec27c: ldur            x0, [fp, #-0x10]
    // 0xdec280: StoreField: r1->field_1b = r0
    //     0xdec280: stur            w0, [x1, #0x1b]
    // 0xdec284: d0 = 0.562500
    //     0xdec284: fmov            d0, #0.56250000
    // 0xdec288: StoreField: r1->field_1f = d0
    //     0xdec288: stur            d0, [x1, #0x1f]
    // 0xdec28c: ldr             x0, [fp, #0x10]
    // 0xdec290: StoreField: r1->field_b = r0
    //     0xdec290: stur            w0, [x1, #0xb]
    // 0xdec294: r0 = ClipRect()
    //     0xdec294: bl              #0xd5c118  ; AllocateClipRectStub -> ClipRect (size=0x18)
    // 0xdec298: mov             x1, x0
    // 0xdec29c: r0 = Instance_Clip
    //     0xdec29c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xdec2a0: ldr             x0, [x0, #0x850]
    // 0xdec2a4: stur            x1, [fp, #-8]
    // 0xdec2a8: StoreField: r1->field_13 = r0
    //     0xdec2a8: stur            w0, [x1, #0x13]
    // 0xdec2ac: ldur            x0, [fp, #-0x28]
    // 0xdec2b0: StoreField: r1->field_b = r0
    //     0xdec2b0: stur            w0, [x1, #0xb]
    // 0xdec2b4: r0 = Semantics()
    //     0xdec2b4: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xdec2b8: stur            x0, [fp, #-0x10]
    // 0xdec2bc: r16 = true
    //     0xdec2bc: add             x16, NULL, #0x20  ; true
    // 0xdec2c0: r30 = true
    //     0xdec2c0: add             lr, NULL, #0x20  ; true
    // 0xdec2c4: stp             lr, x16, [SP, #0x18]
    // 0xdec2c8: ldur            x16, [fp, #-0x18]
    // 0xdec2cc: r30 = true
    //     0xdec2cc: add             lr, NULL, #0x20  ; true
    // 0xdec2d0: stp             lr, x16, [SP, #8]
    // 0xdec2d4: ldur            x16, [fp, #-8]
    // 0xdec2d8: str             x16, [SP]
    // 0xdec2dc: mov             x1, x0
    // 0xdec2e0: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, explicitChildNodes, 0x4, label, 0x3, namesRoute, 0x2, scopesRoute, 0x1, null]
    //     0xdec2e0: add             x4, PP, #0xa6, lsl #12  ; [pp+0xa65d8] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "explicitChildNodes", 0x4, "label", 0x3, "namesRoute", 0x2, "scopesRoute", 0x1, Null]
    //     0xdec2e4: ldr             x4, [x4, #0x5d8]
    // 0xdec2e8: r0 = Semantics()
    //     0xdec2e8: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xdec2ec: ldur            x0, [fp, #-0x10]
    // 0xdec2f0: LeaveFrame
    //     0xdec2f0: mov             SP, fp
    //     0xdec2f4: ldp             fp, lr, [SP], #0x10
    // 0xdec2f8: ret
    //     0xdec2f8: ret             
    // 0xdec2fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdec2fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdec300: b               #0xdec1f4
    // 0xdec304: r9 = _sheetAnimation
    //     0xdec304: add             x9, PP, #0xab, lsl #12  ; [pp+0xab1a8] Field <_ModalBottomSheetState@726001611._sheetAnimation@726001611>: late final (offset: 0x14)
    //     0xdec308: ldr             x9, [x9, #0x1a8]
    // 0xdec30c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdec30c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdec310: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdec310: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Size) {
    // ** addr: 0xdec320, size: 0x7c
    // 0xdec320: EnterFrame
    //     0xdec320: stp             fp, lr, [SP, #-0x10]!
    //     0xdec324: mov             fp, SP
    // 0xdec328: AllocStack(0x8)
    //     0xdec328: sub             SP, SP, #8
    // 0xdec32c: SetupParameters([dynamic _ /* r0 */])
    //     0xdec32c: ldr             x0, [fp, #0x18]
    //     0xdec330: ldur            w1, [x0, #0x17]
    //     0xdec334: add             x1, x1, HEAP, lsl #32
    // 0xdec338: CheckStackOverflow
    //     0xdec338: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdec33c: cmp             SP, x16
    //     0xdec340: b.ls            #0xdec390
    // 0xdec344: LoadField: r0 = r1->field_f
    //     0xdec344: ldur            w0, [x1, #0xf]
    // 0xdec348: DecompressPointer r0
    //     0xdec348: add             x0, x0, HEAP, lsl #32
    // 0xdec34c: LoadField: r1 = r0->field_b
    //     0xdec34c: ldur            w1, [x0, #0xb]
    // 0xdec350: DecompressPointer r1
    //     0xdec350: add             x1, x1, HEAP, lsl #32
    // 0xdec354: cmp             w1, NULL
    // 0xdec358: b.eq            #0xdec398
    // 0xdec35c: LoadField: r3 = r1->field_f
    //     0xdec35c: ldur            w3, [x1, #0xf]
    // 0xdec360: DecompressPointer r3
    //     0xdec360: add             x3, x3, HEAP, lsl #32
    // 0xdec364: mov             x1, x0
    // 0xdec368: ldr             x2, [fp, #0x10]
    // 0xdec36c: stur            x3, [fp, #-8]
    // 0xdec370: r0 = _getNewClipDetails()
    //     0xdec370: bl              #0xdec40c  ; [package:flutter/src/material/bottom_sheet.dart] _ModalBottomSheetState::_getNewClipDetails
    // 0xdec374: ldur            x1, [fp, #-8]
    // 0xdec378: mov             x2, x0
    // 0xdec37c: r0 = _didChangeBarrierSemanticsClip()
    //     0xdec37c: bl              #0xdec39c  ; [package:flutter/src/material/bottom_sheet.dart] ModalBottomSheetRoute::_didChangeBarrierSemanticsClip
    // 0xdec380: r0 = Null
    //     0xdec380: mov             x0, NULL
    // 0xdec384: LeaveFrame
    //     0xdec384: mov             SP, fp
    //     0xdec388: ldp             fp, lr, [SP], #0x10
    // 0xdec38c: ret
    //     0xdec38c: ret             
    // 0xdec390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdec390: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdec394: b               #0xdec344
    // 0xdec398: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdec398: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getNewClipDetails(/* No info */) {
    // ** addr: 0xdec40c, size: 0x38
    // 0xdec40c: EnterFrame
    //     0xdec40c: stp             fp, lr, [SP, #-0x10]!
    //     0xdec410: mov             fp, SP
    // 0xdec414: AllocStack(0x8)
    //     0xdec414: sub             SP, SP, #8
    // 0xdec418: LoadField: d0 = r2->field_f
    //     0xdec418: ldur            d0, [x2, #0xf]
    // 0xdec41c: stur            d0, [fp, #-8]
    // 0xdec420: r0 = EdgeInsets()
    //     0xdec420: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xdec424: StoreField: r0->field_7 = rZR
    //     0xdec424: stur            xzr, [x0, #7]
    // 0xdec428: StoreField: r0->field_f = rZR
    //     0xdec428: stur            xzr, [x0, #0xf]
    // 0xdec42c: ArrayStore: r0[0] = rZR  ; List_8
    //     0xdec42c: stur            xzr, [x0, #0x17]
    // 0xdec430: ldur            d0, [fp, #-8]
    // 0xdec434: StoreField: r0->field_1f = d0
    //     0xdec434: stur            d0, [x0, #0x1f]
    // 0xdec438: LeaveFrame
    //     0xdec438: mov             SP, fp
    //     0xdec43c: ldp             fp, lr, [SP], #0x10
    // 0xdec440: ret
    //     0xdec440: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdec444, size: 0x8c
    // 0xdec444: EnterFrame
    //     0xdec444: stp             fp, lr, [SP, #-0x10]!
    //     0xdec448: mov             fp, SP
    // 0xdec44c: AllocStack(0x18)
    //     0xdec44c: sub             SP, SP, #0x18
    // 0xdec450: SetupParameters([dynamic _ /* r0 */])
    //     0xdec450: ldr             x0, [fp, #0x10]
    //     0xdec454: ldur            w2, [x0, #0x17]
    //     0xdec458: add             x2, x2, HEAP, lsl #32
    //     0xdec45c: stur            x2, [fp, #-8]
    // 0xdec460: CheckStackOverflow
    //     0xdec460: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdec464: cmp             SP, x16
    //     0xdec468: b.ls            #0xdec4c4
    // 0xdec46c: LoadField: r0 = r2->field_f
    //     0xdec46c: ldur            w0, [x2, #0xf]
    // 0xdec470: DecompressPointer r0
    //     0xdec470: add             x0, x0, HEAP, lsl #32
    // 0xdec474: LoadField: r1 = r0->field_b
    //     0xdec474: ldur            w1, [x0, #0xb]
    // 0xdec478: DecompressPointer r1
    //     0xdec478: add             x1, x1, HEAP, lsl #32
    // 0xdec47c: cmp             w1, NULL
    // 0xdec480: b.eq            #0xdec4cc
    // 0xdec484: LoadField: r0 = r1->field_f
    //     0xdec484: ldur            w0, [x1, #0xf]
    // 0xdec488: DecompressPointer r0
    //     0xdec488: add             x0, x0, HEAP, lsl #32
    // 0xdec48c: mov             x1, x0
    // 0xdec490: r0 = isCurrent()
    //     0xdec490: bl              #0x82eeb4  ; [package:flutter/src/widgets/navigator.dart] Route::isCurrent
    // 0xdec494: tbnz            w0, #4, #0xdec4b4
    // 0xdec498: ldur            x0, [fp, #-8]
    // 0xdec49c: LoadField: r1 = r0->field_13
    //     0xdec49c: ldur            w1, [x0, #0x13]
    // 0xdec4a0: DecompressPointer r1
    //     0xdec4a0: add             x1, x1, HEAP, lsl #32
    // 0xdec4a4: r16 = <Object?>
    //     0xdec4a4: ldr             x16, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0xdec4a8: stp             x1, x16, [SP]
    // 0xdec4ac: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdec4ac: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdec4b0: r0 = pop()
    //     0xdec4b0: bl              #0xd190ec  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0xdec4b4: r0 = Null
    //     0xdec4b4: mov             x0, NULL
    // 0xdec4b8: LeaveFrame
    //     0xdec4b8: mov             SP, fp
    //     0xdec4bc: ldp             fp, lr, [SP], #0x10
    // 0xdec4c0: ret
    //     0xdec4c0: ret             
    // 0xdec4c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdec4c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdec4c8: b               #0xdec46c
    // 0xdec4cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdec4cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleDragEnd(dynamic, DragEndDetails, {bool? isClosing}) {
    // ** addr: 0xdec4d0, size: 0x94
    // 0xdec4d0: EnterFrame
    //     0xdec4d0: stp             fp, lr, [SP, #-0x10]!
    //     0xdec4d4: mov             fp, SP
    // 0xdec4d8: AllocStack(0x8)
    //     0xdec4d8: sub             SP, SP, #8
    // 0xdec4dc: SetupParameters(_ModalBottomSheetState<C1X0> this /* r2 */, dynamic _ /* r3 */, {dynamic isClosing = Null /* r0 */})
    //     0xdec4dc: ldur            w0, [x4, #0x13]
    //     0xdec4e0: sub             x1, x0, #4
    //     0xdec4e4: add             x2, fp, w1, sxtw #2
    //     0xdec4e8: ldr             x2, [x2, #0x18]
    //     0xdec4ec: add             x3, fp, w1, sxtw #2
    //     0xdec4f0: ldr             x3, [x3, #0x10]
    //     0xdec4f4: ldur            w1, [x4, #0x1f]
    //     0xdec4f8: add             x1, x1, HEAP, lsl #32
    //     0xdec4fc: add             x16, PP, #0x99, lsl #12  ; [pp+0x99748] "isClosing"
    //     0xdec500: ldr             x16, [x16, #0x748]
    //     0xdec504: cmp             w1, w16
    //     0xdec508: b.ne            #0xdec524
    //     0xdec50c: ldur            w1, [x4, #0x23]
    //     0xdec510: add             x1, x1, HEAP, lsl #32
    //     0xdec514: sub             w4, w0, w1
    //     0xdec518: add             x0, fp, w4, sxtw #2
    //     0xdec51c: ldr             x0, [x0, #8]
    //     0xdec520: b               #0xdec528
    //     0xdec524: mov             x0, NULL
    //     0xdec528: ldur            w1, [x2, #0x17]
    //     0xdec52c: add             x1, x1, HEAP, lsl #32
    // 0xdec530: CheckStackOverflow
    //     0xdec530: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdec534: cmp             SP, x16
    //     0xdec538: b.ls            #0xdec55c
    // 0xdec53c: str             x0, [SP]
    // 0xdec540: mov             x2, x3
    // 0xdec544: r4 = const [0, 0x3, 0x1, 0x2, isClosing, 0x2, null]
    //     0xdec544: add             x4, PP, #0x99, lsl #12  ; [pp+0x99750] List(7) [0, 0x3, 0x1, 0x2, "isClosing", 0x2, Null]
    //     0xdec548: ldr             x4, [x4, #0x750]
    // 0xdec54c: r0 = handleDragEnd()
    //     0xdec54c: bl              #0xdec564  ; [package:flutter/src/material/bottom_sheet.dart] _ModalBottomSheetState::handleDragEnd
    // 0xdec550: LeaveFrame
    //     0xdec550: mov             SP, fp
    //     0xdec554: ldp             fp, lr, [SP], #0x10
    // 0xdec558: ret
    //     0xdec558: ret             
    // 0xdec55c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdec55c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdec560: b               #0xdec53c
  }
  _ handleDragEnd(/* No info */) {
    // ** addr: 0xdec564, size: 0x190
    // 0xdec564: EnterFrame
    //     0xdec564: stp             fp, lr, [SP, #-0x10]!
    //     0xdec568: mov             fp, SP
    // 0xdec56c: AllocStack(0x38)
    //     0xdec56c: sub             SP, SP, #0x38
    // 0xdec570: SetupParameters(_ModalBottomSheetState<C1X0> this /* r1 => r0, fp-0x8 */)
    //     0xdec570: mov             x0, x1
    //     0xdec574: stur            x1, [fp, #-8]
    // 0xdec578: CheckStackOverflow
    //     0xdec578: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdec57c: cmp             SP, x16
    //     0xdec580: b.ls            #0xdec6d0
    // 0xdec584: LoadField: r1 = r0->field_b
    //     0xdec584: ldur            w1, [x0, #0xb]
    // 0xdec588: DecompressPointer r1
    //     0xdec588: add             x1, x1, HEAP, lsl #32
    // 0xdec58c: cmp             w1, NULL
    // 0xdec590: b.eq            #0xdec6d8
    // 0xdec594: LoadField: r2 = r1->field_f
    //     0xdec594: ldur            w2, [x1, #0xf]
    // 0xdec598: DecompressPointer r2
    //     0xdec598: add             x2, x2, HEAP, lsl #32
    // 0xdec59c: LoadField: r1 = r2->field_6f
    //     0xdec59c: ldur            w1, [x2, #0x6f]
    // 0xdec5a0: DecompressPointer r1
    //     0xdec5a0: add             x1, x1, HEAP, lsl #32
    // 0xdec5a4: cmp             w1, NULL
    // 0xdec5a8: b.eq            #0xdec6dc
    // 0xdec5ac: r0 = value()
    //     0xdec5ac: bl              #0xae66fc  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::value
    // 0xdec5b0: mov             x1, x0
    // 0xdec5b4: ldur            x0, [fp, #-8]
    // 0xdec5b8: LoadField: r2 = r0->field_13
    //     0xdec5b8: ldur            w2, [x0, #0x13]
    // 0xdec5bc: DecompressPointer r2
    //     0xdec5bc: add             x2, x2, HEAP, lsl #32
    // 0xdec5c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdec5c4: cmp             w2, w16
    // 0xdec5c8: b.eq            #0xdec6e0
    // 0xdec5cc: stur            x2, [fp, #-0x18]
    // 0xdec5d0: LoadField: r3 = r0->field_b
    //     0xdec5d0: ldur            w3, [x0, #0xb]
    // 0xdec5d4: DecompressPointer r3
    //     0xdec5d4: add             x3, x3, HEAP, lsl #32
    // 0xdec5d8: cmp             w3, NULL
    // 0xdec5dc: b.eq            #0xdec6ec
    // 0xdec5e0: LoadField: r0 = r3->field_f
    //     0xdec5e0: ldur            w0, [x3, #0xf]
    // 0xdec5e4: DecompressPointer r0
    //     0xdec5e4: add             x0, x0, HEAP, lsl #32
    // 0xdec5e8: LoadField: r4 = r0->field_6f
    //     0xdec5e8: ldur            w4, [x0, #0x6f]
    // 0xdec5ec: DecompressPointer r4
    //     0xdec5ec: add             x4, x4, HEAP, lsl #32
    // 0xdec5f0: stur            x4, [fp, #-0x10]
    // 0xdec5f4: cmp             w4, NULL
    // 0xdec5f8: b.eq            #0xdec6f0
    // 0xdec5fc: LoadField: r0 = r3->field_3b
    //     0xdec5fc: ldur            w0, [x3, #0x3b]
    // 0xdec600: DecompressPointer r0
    //     0xdec600: add             x0, x0, HEAP, lsl #32
    // 0xdec604: cmp             w0, NULL
    // 0xdec608: b.ne            #0xdec614
    // 0xdec60c: r0 = Null
    //     0xdec60c: mov             x0, NULL
    // 0xdec610: b               #0xdec620
    // 0xdec614: LoadField: r3 = r0->field_7
    //     0xdec614: ldur            w3, [x0, #7]
    // 0xdec618: DecompressPointer r3
    //     0xdec618: add             x3, x3, HEAP, lsl #32
    // 0xdec61c: mov             x0, x3
    // 0xdec620: cmp             w0, NULL
    // 0xdec624: b.ne            #0xdec630
    // 0xdec628: r0 = Instance_Cubic
    //     0xdec628: add             x0, PP, #0xab, lsl #12  ; [pp+0xab1b8] Obj!Cubic@129f6f1
    //     0xdec62c: ldr             x0, [x0, #0x1b8]
    // 0xdec630: stur            x0, [fp, #-8]
    // 0xdec634: LoadField: d0 = r1->field_7
    //     0xdec634: ldur            d0, [x1, #7]
    // 0xdec638: stur            d0, [fp, #-0x30]
    // 0xdec63c: r1 = <double>
    //     0xdec63c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdec640: r0 = Split()
    //     0xdec640: bl              #0xdec6f4  ; AllocateSplitStub -> Split (size=0x1c)
    // 0xdec644: ldur            d0, [fp, #-0x30]
    // 0xdec648: stur            x0, [fp, #-0x20]
    // 0xdec64c: StoreField: r0->field_b = d0
    //     0xdec64c: stur            d0, [x0, #0xb]
    // 0xdec650: r2 = Instance__Linear
    //     0xdec650: ldr             x2, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xdec654: StoreField: r0->field_13 = r2
    //     0xdec654: stur            w2, [x0, #0x13]
    // 0xdec658: ldur            x1, [fp, #-8]
    // 0xdec65c: ArrayStore: r0[0] = r1  ; List_4
    //     0xdec65c: stur            w1, [x0, #0x17]
    // 0xdec660: r1 = <double>
    //     0xdec660: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdec664: r0 = Split()
    //     0xdec664: bl              #0xdec6f4  ; AllocateSplitStub -> Split (size=0x1c)
    // 0xdec668: ldur            d0, [fp, #-0x30]
    // 0xdec66c: stur            x0, [fp, #-8]
    // 0xdec670: StoreField: r0->field_b = d0
    //     0xdec670: stur            d0, [x0, #0xb]
    // 0xdec674: r1 = Instance__Linear
    //     0xdec674: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xdec678: StoreField: r0->field_13 = r1
    //     0xdec678: stur            w1, [x0, #0x13]
    // 0xdec67c: r1 = Instance_Cubic
    //     0xdec67c: add             x1, PP, #0xab, lsl #12  ; [pp+0xab1b8] Obj!Cubic@129f6f1
    //     0xdec680: ldr             x1, [x1, #0x1b8]
    // 0xdec684: ArrayStore: r0[0] = r1  ; List_4
    //     0xdec684: stur            w1, [x0, #0x17]
    // 0xdec688: r1 = <double>
    //     0xdec688: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdec68c: r0 = CurvedAnimation()
    //     0xdec68c: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xdec690: stur            x0, [fp, #-0x28]
    // 0xdec694: ldur            x16, [fp, #-8]
    // 0xdec698: str             x16, [SP]
    // 0xdec69c: mov             x1, x0
    // 0xdec6a0: ldur            x2, [fp, #-0x20]
    // 0xdec6a4: ldur            x3, [fp, #-0x10]
    // 0xdec6a8: r4 = const [0, 0x4, 0x1, 0x3, reverseCurve, 0x3, null]
    //     0xdec6a8: add             x4, PP, #0x16, lsl #12  ; [pp+0x16dc0] List(7) [0, 0x4, 0x1, 0x3, "reverseCurve", 0x3, Null]
    //     0xdec6ac: ldr             x4, [x4, #0xdc0]
    // 0xdec6b0: r0 = CurvedAnimation()
    //     0xdec6b0: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xdec6b4: ldur            x1, [fp, #-0x18]
    // 0xdec6b8: ldur            x2, [fp, #-0x28]
    // 0xdec6bc: r0 = parent=()
    //     0xdec6bc: bl              #0xb72d4c  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::parent=
    // 0xdec6c0: r0 = Null
    //     0xdec6c0: mov             x0, NULL
    // 0xdec6c4: LeaveFrame
    //     0xdec6c4: mov             SP, fp
    //     0xdec6c8: ldp             fp, lr, [SP], #0x10
    // 0xdec6cc: ret
    //     0xdec6cc: ret             
    // 0xdec6d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdec6d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdec6d4: b               #0xdec584
    // 0xdec6d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdec6d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdec6dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdec6dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdec6e0: r9 = _sheetAnimation
    //     0xdec6e0: add             x9, PP, #0xab, lsl #12  ; [pp+0xab1a8] Field <_ModalBottomSheetState@726001611._sheetAnimation@726001611>: late final (offset: 0x14)
    //     0xdec6e4: ldr             x9, [x9, #0x1a8]
    // 0xdec6e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdec6e8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdec6ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdec6ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdec6f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdec6f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleDragStart(dynamic, DragStartDetails) {
    // ** addr: 0xdec700, size: 0x3c
    // 0xdec700: EnterFrame
    //     0xdec700: stp             fp, lr, [SP, #-0x10]!
    //     0xdec704: mov             fp, SP
    // 0xdec708: ldr             x0, [fp, #0x18]
    // 0xdec70c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdec70c: ldur            w1, [x0, #0x17]
    // 0xdec710: DecompressPointer r1
    //     0xdec710: add             x1, x1, HEAP, lsl #32
    // 0xdec714: CheckStackOverflow
    //     0xdec714: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdec718: cmp             SP, x16
    //     0xdec71c: b.ls            #0xdec734
    // 0xdec720: ldr             x2, [fp, #0x10]
    // 0xdec724: r0 = handleDragStart()
    //     0xdec724: bl              #0xdec73c  ; [package:flutter/src/material/bottom_sheet.dart] _ModalBottomSheetState::handleDragStart
    // 0xdec728: LeaveFrame
    //     0xdec728: mov             SP, fp
    //     0xdec72c: ldp             fp, lr, [SP], #0x10
    // 0xdec730: ret
    //     0xdec730: ret             
    // 0xdec734: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdec734: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdec738: b               #0xdec720
  }
  _ handleDragStart(/* No info */) {
    // ** addr: 0xdec73c, size: 0x78
    // 0xdec73c: EnterFrame
    //     0xdec73c: stp             fp, lr, [SP, #-0x10]!
    //     0xdec740: mov             fp, SP
    // 0xdec744: CheckStackOverflow
    //     0xdec744: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdec748: cmp             SP, x16
    //     0xdec74c: b.ls            #0xdec79c
    // 0xdec750: LoadField: r0 = r1->field_13
    //     0xdec750: ldur            w0, [x1, #0x13]
    // 0xdec754: DecompressPointer r0
    //     0xdec754: add             x0, x0, HEAP, lsl #32
    // 0xdec758: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdec75c: cmp             w0, w16
    // 0xdec760: b.eq            #0xdec7a4
    // 0xdec764: LoadField: r2 = r1->field_b
    //     0xdec764: ldur            w2, [x1, #0xb]
    // 0xdec768: DecompressPointer r2
    //     0xdec768: add             x2, x2, HEAP, lsl #32
    // 0xdec76c: cmp             w2, NULL
    // 0xdec770: b.eq            #0xdec7b0
    // 0xdec774: LoadField: r1 = r2->field_f
    //     0xdec774: ldur            w1, [x2, #0xf]
    // 0xdec778: DecompressPointer r1
    //     0xdec778: add             x1, x1, HEAP, lsl #32
    // 0xdec77c: LoadField: r2 = r1->field_6f
    //     0xdec77c: ldur            w2, [x1, #0x6f]
    // 0xdec780: DecompressPointer r2
    //     0xdec780: add             x2, x2, HEAP, lsl #32
    // 0xdec784: mov             x1, x0
    // 0xdec788: r0 = parent=()
    //     0xdec788: bl              #0xb72d4c  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::parent=
    // 0xdec78c: r0 = Null
    //     0xdec78c: mov             x0, NULL
    // 0xdec790: LeaveFrame
    //     0xdec790: mov             SP, fp
    //     0xdec794: ldp             fp, lr, [SP], #0x10
    // 0xdec798: ret
    //     0xdec798: ret             
    // 0xdec79c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdec79c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdec7a0: b               #0xdec750
    // 0xdec7a4: r9 = _sheetAnimation
    //     0xdec7a4: add             x9, PP, #0xab, lsl #12  ; [pp+0xab1a8] Field <_ModalBottomSheetState@726001611._sheetAnimation@726001611>: late final (offset: 0x14)
    //     0xdec7a8: ldr             x9, [x9, #0x1a8]
    // 0xdec7ac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdec7ac: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdec7b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdec7b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf6d1c8, size: 0x88
    // 0xf6d1c8: EnterFrame
    //     0xf6d1c8: stp             fp, lr, [SP, #-0x10]!
    //     0xf6d1cc: mov             fp, SP
    // 0xf6d1d0: AllocStack(0x10)
    //     0xf6d1d0: sub             SP, SP, #0x10
    // 0xf6d1d4: SetupParameters(dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf6d1d4: mov             x3, x2
    //     0xf6d1d8: stur            x2, [fp, #-0x10]
    // 0xf6d1dc: LoadField: r4 = r1->field_7
    //     0xf6d1dc: ldur            w4, [x1, #7]
    // 0xf6d1e0: DecompressPointer r4
    //     0xf6d1e0: add             x4, x4, HEAP, lsl #32
    // 0xf6d1e4: mov             x0, x3
    // 0xf6d1e8: mov             x2, x4
    // 0xf6d1ec: stur            x4, [fp, #-8]
    // 0xf6d1f0: r1 = Null
    //     0xf6d1f0: mov             x1, NULL
    // 0xf6d1f4: r8 = _ModalBottomSheet<C1X0>
    //     0xf6d1f4: add             x8, PP, #0xab, lsl #12  ; [pp+0xab1c8] Type: _ModalBottomSheet<C1X0>
    //     0xf6d1f8: ldr             x8, [x8, #0x1c8]
    // 0xf6d1fc: LoadField: r9 = r8->field_7
    //     0xf6d1fc: ldur            x9, [x8, #7]
    // 0xf6d200: r3 = Null
    //     0xf6d200: add             x3, PP, #0xab, lsl #12  ; [pp+0xab1d0] Null
    //     0xf6d204: ldr             x3, [x3, #0x1d0]
    // 0xf6d208: blr             x9
    // 0xf6d20c: ldur            x0, [fp, #-0x10]
    // 0xf6d210: ldur            x2, [fp, #-8]
    // 0xf6d214: r1 = Null
    //     0xf6d214: mov             x1, NULL
    // 0xf6d218: cmp             w2, NULL
    // 0xf6d21c: b.eq            #0xf6d240
    // 0xf6d220: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6d220: ldur            w4, [x2, #0x17]
    // 0xf6d224: DecompressPointer r4
    //     0xf6d224: add             x4, x4, HEAP, lsl #32
    // 0xf6d228: r8 = X0 bound StatefulWidget
    //     0xf6d228: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf6d22c: ldr             x8, [x8, #0x498]
    // 0xf6d230: LoadField: r9 = r4->field_7
    //     0xf6d230: ldur            x9, [x4, #7]
    // 0xf6d234: r3 = Null
    //     0xf6d234: add             x3, PP, #0xab, lsl #12  ; [pp+0xab1e0] Null
    //     0xf6d238: ldr             x3, [x3, #0x1e0]
    // 0xf6d23c: blr             x9
    // 0xf6d240: r0 = Null
    //     0xf6d240: mov             x0, NULL
    // 0xf6d244: LeaveFrame
    //     0xf6d244: mov             SP, fp
    //     0xf6d248: ldp             fp, lr, [SP], #0x10
    // 0xf6d24c: ret
    //     0xf6d24c: ret             
  }
  _ initState(/* No info */) {
    // ** addr: 0xf8f774, size: 0x190
    // 0xf8f774: EnterFrame
    //     0xf8f774: stp             fp, lr, [SP, #-0x10]!
    //     0xf8f778: mov             fp, SP
    // 0xf8f77c: AllocStack(0x28)
    //     0xf8f77c: sub             SP, SP, #0x28
    // 0xf8f780: SetupParameters(_ModalBottomSheetState<C1X0> this /* r1 => r0, fp-0x18 */)
    //     0xf8f780: mov             x0, x1
    //     0xf8f784: stur            x1, [fp, #-0x18]
    // 0xf8f788: CheckStackOverflow
    //     0xf8f788: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8f78c: cmp             SP, x16
    //     0xf8f790: b.ls            #0xf8f8f4
    // 0xf8f794: LoadField: r1 = r0->field_b
    //     0xf8f794: ldur            w1, [x0, #0xb]
    // 0xf8f798: DecompressPointer r1
    //     0xf8f798: add             x1, x1, HEAP, lsl #32
    // 0xf8f79c: cmp             w1, NULL
    // 0xf8f7a0: b.eq            #0xf8f8fc
    // 0xf8f7a4: LoadField: r2 = r1->field_f
    //     0xf8f7a4: ldur            w2, [x1, #0xf]
    // 0xf8f7a8: DecompressPointer r2
    //     0xf8f7a8: add             x2, x2, HEAP, lsl #32
    // 0xf8f7ac: LoadField: r3 = r2->field_6f
    //     0xf8f7ac: ldur            w3, [x2, #0x6f]
    // 0xf8f7b0: DecompressPointer r3
    //     0xf8f7b0: add             x3, x3, HEAP, lsl #32
    // 0xf8f7b4: stur            x3, [fp, #-0x10]
    // 0xf8f7b8: cmp             w3, NULL
    // 0xf8f7bc: b.eq            #0xf8f900
    // 0xf8f7c0: LoadField: r2 = r1->field_3b
    //     0xf8f7c0: ldur            w2, [x1, #0x3b]
    // 0xf8f7c4: DecompressPointer r2
    //     0xf8f7c4: add             x2, x2, HEAP, lsl #32
    // 0xf8f7c8: cmp             w2, NULL
    // 0xf8f7cc: b.ne            #0xf8f7d8
    // 0xf8f7d0: r1 = Null
    //     0xf8f7d0: mov             x1, NULL
    // 0xf8f7d4: b               #0xf8f7e0
    // 0xf8f7d8: LoadField: r1 = r2->field_7
    //     0xf8f7d8: ldur            w1, [x2, #7]
    // 0xf8f7dc: DecompressPointer r1
    //     0xf8f7dc: add             x1, x1, HEAP, lsl #32
    // 0xf8f7e0: cmp             w1, NULL
    // 0xf8f7e4: b.ne            #0xf8f7f4
    // 0xf8f7e8: r2 = Instance_Cubic
    //     0xf8f7e8: add             x2, PP, #0xab, lsl #12  ; [pp+0xab1b8] Obj!Cubic@129f6f1
    //     0xf8f7ec: ldr             x2, [x2, #0x1b8]
    // 0xf8f7f0: b               #0xf8f7f8
    // 0xf8f7f4: mov             x2, x1
    // 0xf8f7f8: stur            x2, [fp, #-8]
    // 0xf8f7fc: r1 = <double>
    //     0xf8f7fc: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf8f800: r0 = CurvedAnimation()
    //     0xf8f800: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xf8f804: stur            x0, [fp, #-0x20]
    // 0xf8f808: r16 = Instance_Cubic
    //     0xf8f808: add             x16, PP, #0xab, lsl #12  ; [pp+0xab1b8] Obj!Cubic@129f6f1
    //     0xf8f80c: ldr             x16, [x16, #0x1b8]
    // 0xf8f810: str             x16, [SP]
    // 0xf8f814: mov             x1, x0
    // 0xf8f818: ldur            x2, [fp, #-8]
    // 0xf8f81c: ldur            x3, [fp, #-0x10]
    // 0xf8f820: r4 = const [0, 0x4, 0x1, 0x3, reverseCurve, 0x3, null]
    //     0xf8f820: add             x4, PP, #0x16, lsl #12  ; [pp+0x16dc0] List(7) [0, 0x4, 0x1, 0x3, "reverseCurve", 0x3, Null]
    //     0xf8f824: ldr             x4, [x4, #0xdc0]
    // 0xf8f828: r0 = CurvedAnimation()
    //     0xf8f828: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xf8f82c: ldur            x2, [fp, #-0x18]
    // 0xf8f830: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xf8f830: ldur            w0, [x2, #0x17]
    // 0xf8f834: DecompressPointer r0
    //     0xf8f834: add             x0, x0, HEAP, lsl #32
    // 0xf8f838: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf8f83c: cmp             w0, w16
    // 0xf8f840: b.ne            #0xf8f8e0
    // 0xf8f844: ldur            x0, [fp, #-0x20]
    // 0xf8f848: ArrayStore: r2[0] = r0  ; List_4
    //     0xf8f848: stur            w0, [x2, #0x17]
    //     0xf8f84c: ldurb           w16, [x2, #-1]
    //     0xf8f850: ldurb           w17, [x0, #-1]
    //     0xf8f854: and             x16, x17, x16, lsr #2
    //     0xf8f858: tst             x16, HEAP, lsr #32
    //     0xf8f85c: b.eq            #0xf8f864
    //     0xf8f860: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf8f864: r1 = <double>
    //     0xf8f864: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf8f868: r0 = ProxyAnimation()
    //     0xf8f868: bl              #0x8e0ba8  ; AllocateProxyAnimationStub -> ProxyAnimation (size=0x28)
    // 0xf8f86c: stur            x0, [fp, #-8]
    // 0xf8f870: ldur            x16, [fp, #-0x20]
    // 0xf8f874: str             x16, [SP]
    // 0xf8f878: mov             x1, x0
    // 0xf8f87c: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xf8f87c: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xf8f880: r0 = ProxyAnimation()
    //     0xf8f880: bl              #0x8e09cc  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::ProxyAnimation
    // 0xf8f884: ldur            x1, [fp, #-0x18]
    // 0xf8f888: LoadField: r0 = r1->field_13
    //     0xf8f888: ldur            w0, [x1, #0x13]
    // 0xf8f88c: DecompressPointer r0
    //     0xf8f88c: add             x0, x0, HEAP, lsl #32
    // 0xf8f890: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf8f894: cmp             w0, w16
    // 0xf8f898: b.ne            #0xf8f8cc
    // 0xf8f89c: ldur            x0, [fp, #-8]
    // 0xf8f8a0: StoreField: r1->field_13 = r0
    //     0xf8f8a0: stur            w0, [x1, #0x13]
    //     0xf8f8a4: ldurb           w16, [x1, #-1]
    //     0xf8f8a8: ldurb           w17, [x0, #-1]
    //     0xf8f8ac: and             x16, x17, x16, lsr #2
    //     0xf8f8b0: tst             x16, HEAP, lsr #32
    //     0xf8f8b4: b.eq            #0xf8f8bc
    //     0xf8f8b8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf8f8bc: r0 = Null
    //     0xf8f8bc: mov             x0, NULL
    // 0xf8f8c0: LeaveFrame
    //     0xf8f8c0: mov             SP, fp
    //     0xf8f8c4: ldp             fp, lr, [SP], #0x10
    // 0xf8f8c8: ret
    //     0xf8f8c8: ret             
    // 0xf8f8cc: r16 = "_sheetAnimation@726001611"
    //     0xf8f8cc: add             x16, PP, #0xab, lsl #12  ; [pp+0xab1f0] "_sheetAnimation@726001611"
    //     0xf8f8d0: ldr             x16, [x16, #0x1f0]
    // 0xf8f8d4: str             x16, [SP]
    // 0xf8f8d8: r0 = _throwFieldAlreadyInitialized()
    //     0xf8f8d8: bl              #0x82b720  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0xf8f8dc: brk             #0
    // 0xf8f8e0: r16 = "_curvedSheetAnimation@726001611"
    //     0xf8f8e0: add             x16, PP, #0xab, lsl #12  ; [pp+0xab1f8] "_curvedSheetAnimation@726001611"
    //     0xf8f8e4: ldr             x16, [x16, #0x1f8]
    // 0xf8f8e8: str             x16, [SP]
    // 0xf8f8ec: r0 = _throwFieldAlreadyInitialized()
    //     0xf8f8ec: bl              #0x82b720  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0xf8f8f0: brk             #0
    // 0xf8f8f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8f8f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8f8f8: b               #0xf8f794
    // 0xf8f8fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf8f8fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf8f900: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf8f900: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e583c, size: 0x8c
    // 0x10e583c: EnterFrame
    //     0x10e583c: stp             fp, lr, [SP, #-0x10]!
    //     0x10e5840: mov             fp, SP
    // 0x10e5844: AllocStack(0x8)
    //     0x10e5844: sub             SP, SP, #8
    // 0x10e5848: SetupParameters(_ModalBottomSheetState<C1X0> this /* r1 => r0, fp-0x8 */)
    //     0x10e5848: mov             x0, x1
    //     0x10e584c: stur            x1, [fp, #-8]
    // 0x10e5850: CheckStackOverflow
    //     0x10e5850: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e5854: cmp             SP, x16
    //     0x10e5858: b.ls            #0x10e58a8
    // 0x10e585c: LoadField: r1 = r0->field_13
    //     0x10e585c: ldur            w1, [x0, #0x13]
    // 0x10e5860: DecompressPointer r1
    //     0x10e5860: add             x1, x1, HEAP, lsl #32
    // 0x10e5864: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10e5868: cmp             w1, w16
    // 0x10e586c: b.eq            #0x10e58b0
    // 0x10e5870: r2 = Instance__AlwaysDismissedAnimation
    //     0x10e5870: add             x2, PP, #0x14, lsl #12  ; [pp+0x14e60] Obj!_AlwaysDismissedAnimation@12aa3e1
    //     0x10e5874: ldr             x2, [x2, #0xe60]
    // 0x10e5878: r0 = parent=()
    //     0x10e5878: bl              #0xb72d4c  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::parent=
    // 0x10e587c: ldur            x0, [fp, #-8]
    // 0x10e5880: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10e5880: ldur            w1, [x0, #0x17]
    // 0x10e5884: DecompressPointer r1
    //     0x10e5884: add             x1, x1, HEAP, lsl #32
    // 0x10e5888: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10e588c: cmp             w1, w16
    // 0x10e5890: b.eq            #0x10e58bc
    // 0x10e5894: r0 = dispose()
    //     0x10e5894: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0x10e5898: r0 = Null
    //     0x10e5898: mov             x0, NULL
    // 0x10e589c: LeaveFrame
    //     0x10e589c: mov             SP, fp
    //     0x10e58a0: ldp             fp, lr, [SP], #0x10
    // 0x10e58a4: ret
    //     0x10e58a4: ret             
    // 0x10e58a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e58a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e58ac: b               #0x10e585c
    // 0x10e58b0: r9 = _sheetAnimation
    //     0x10e58b0: add             x9, PP, #0xab, lsl #12  ; [pp+0xab1a8] Field <_ModalBottomSheetState@726001611._sheetAnimation@726001611>: late final (offset: 0x14)
    //     0x10e58b4: ldr             x9, [x9, #0x1a8]
    // 0x10e58b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10e58b8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x10e58bc: r9 = _curvedSheetAnimation
    //     0x10e58bc: add             x9, PP, #0xab, lsl #12  ; [pp+0xab1c0] Field <_ModalBottomSheetState@726001611._curvedSheetAnimation@726001611>: late final (offset: 0x18)
    //     0x10e58c0: ldr             x9, [x9, #0x1c0]
    // 0x10e58c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10e58c4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 5478, size: 0x1c, field offset: 0x14
class _BottomSheetState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xdeaeb8, size: 0x658
    // 0xdeaeb8: EnterFrame
    //     0xdeaeb8: stp             fp, lr, [SP, #-0x10]!
    //     0xdeaebc: mov             fp, SP
    // 0xdeaec0: AllocStack(0x78)
    //     0xdeaec0: sub             SP, SP, #0x78
    // 0xdeaec4: SetupParameters(_BottomSheetState this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xdeaec4: mov             x0, x2
    //     0xdeaec8: stur            x2, [fp, #-0x10]
    //     0xdeaecc: mov             x2, x1
    //     0xdeaed0: stur            x1, [fp, #-8]
    // 0xdeaed4: CheckStackOverflow
    //     0xdeaed4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdeaed8: cmp             SP, x16
    //     0xdeaedc: b.ls            #0xdeb4f8
    // 0xdeaee0: mov             x1, x0
    // 0xdeaee4: r0 = of()
    //     0xdeaee4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdeaee8: LoadField: r2 = r0->field_a7
    //     0xdeaee8: ldur            w2, [x0, #0xa7]
    // 0xdeaeec: DecompressPointer r2
    //     0xdeaeec: add             x2, x2, HEAP, lsl #32
    // 0xdeaef0: ldur            x1, [fp, #-0x10]
    // 0xdeaef4: stur            x2, [fp, #-0x18]
    // 0xdeaef8: r0 = of()
    //     0xdeaef8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdeaefc: LoadField: r1 = r0->field_2f
    //     0xdeaefc: ldur            w1, [x0, #0x2f]
    // 0xdeaf00: DecompressPointer r1
    //     0xdeaf00: add             x1, x1, HEAP, lsl #32
    // 0xdeaf04: tbnz            w1, #4, #0xdeaf50
    // 0xdeaf08: ldur            x0, [fp, #-0x10]
    // 0xdeaf0c: r0 = _BottomSheetDefaultsM3()
    //     0xdeaf0c: bl              #0xdeb54c  ; Allocate_BottomSheetDefaultsM3Stub -> _BottomSheetDefaultsM3 (size=0x44)
    // 0xdeaf10: mov             x1, x0
    // 0xdeaf14: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xdeaf18: StoreField: r1->field_3f = r0
    //     0xdeaf18: stur            w0, [x1, #0x3f]
    // 0xdeaf1c: ldur            x0, [fp, #-0x10]
    // 0xdeaf20: StoreField: r1->field_3b = r0
    //     0xdeaf20: stur            w0, [x1, #0x3b]
    // 0xdeaf24: r2 = 1.000000
    //     0xdeaf24: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xdeaf28: StoreField: r1->field_f = r2
    //     0xdeaf28: stur            w2, [x1, #0xf]
    // 0xdeaf2c: StoreField: r1->field_1f = r2
    //     0xdeaf2c: stur            w2, [x1, #0x1f]
    // 0xdeaf30: r3 = Instance_RoundedRectangleBorder
    //     0xdeaf30: add             x3, PP, #0x95, lsl #12  ; [pp+0x95e68] Obj!RoundedRectangleBorder@129ec71
    //     0xdeaf34: ldr             x3, [x3, #0xe68]
    // 0xdeaf38: StoreField: r1->field_23 = r3
    //     0xdeaf38: stur            w3, [x1, #0x23]
    // 0xdeaf3c: r3 = Instance_BoxConstraints
    //     0xdeaf3c: add             x3, PP, #0x26, lsl #12  ; [pp+0x26560] Obj!BoxConstraints@129c321
    //     0xdeaf40: ldr             x3, [x3, #0x560]
    // 0xdeaf44: StoreField: r1->field_37 = r3
    //     0xdeaf44: stur            w3, [x1, #0x37]
    // 0xdeaf48: mov             x5, x1
    // 0xdeaf4c: b               #0xdeaf60
    // 0xdeaf50: ldur            x0, [fp, #-0x10]
    // 0xdeaf54: r2 = 1.000000
    //     0xdeaf54: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xdeaf58: r5 = Instance_BottomSheetThemeData
    //     0xdeaf58: add             x5, PP, #0x12, lsl #12  ; [pp+0x12d40] Obj!BottomSheetThemeData@12b32b1
    //     0xdeaf5c: ldr             x5, [x5, #0xd40]
    // 0xdeaf60: ldur            x4, [fp, #-8]
    // 0xdeaf64: ldur            x3, [fp, #-0x18]
    // 0xdeaf68: stur            x5, [fp, #-0x28]
    // 0xdeaf6c: LoadField: r1 = r4->field_b
    //     0xdeaf6c: ldur            w1, [x4, #0xb]
    // 0xdeaf70: DecompressPointer r1
    //     0xdeaf70: add             x1, x1, HEAP, lsl #32
    // 0xdeaf74: cmp             w1, NULL
    // 0xdeaf78: b.eq            #0xdeb500
    // 0xdeaf7c: LoadField: r6 = r3->field_37
    //     0xdeaf7c: ldur            w6, [x3, #0x37]
    // 0xdeaf80: DecompressPointer r6
    //     0xdeaf80: add             x6, x6, HEAP, lsl #32
    // 0xdeaf84: cmp             w6, NULL
    // 0xdeaf88: b.ne            #0xdeafb4
    // 0xdeaf8c: r6 = LoadClassIdInstr(r5)
    //     0xdeaf8c: ldur            x6, [x5, #-1]
    //     0xdeaf90: ubfx            x6, x6, #0xc, #0x14
    // 0xdeaf94: r17 = 5201
    //     0xdeaf94: mov             x17, #0x1451
    // 0xdeaf98: cmp             x6, x17
    // 0xdeaf9c: b.ne            #0xdeafac
    // 0xdeafa0: LoadField: r6 = r5->field_37
    //     0xdeafa0: ldur            w6, [x5, #0x37]
    // 0xdeafa4: DecompressPointer r6
    //     0xdeafa4: add             x6, x6, HEAP, lsl #32
    // 0xdeafa8: b               #0xdeafb4
    // 0xdeafac: r6 = Instance_BoxConstraints
    //     0xdeafac: add             x6, PP, #0x26, lsl #12  ; [pp+0x26560] Obj!BoxConstraints@129c321
    //     0xdeafb0: ldr             x6, [x6, #0x560]
    // 0xdeafb4: stur            x6, [fp, #-0x20]
    // 0xdeafb8: LoadField: r7 = r1->field_2f
    //     0xdeafb8: ldur            w7, [x1, #0x2f]
    // 0xdeafbc: DecompressPointer r7
    //     0xdeafbc: add             x7, x7, HEAP, lsl #32
    // 0xdeafc0: cmp             w7, NULL
    // 0xdeafc4: b.ne            #0xdeafd0
    // 0xdeafc8: r1 = Null
    //     0xdeafc8: mov             x1, NULL
    // 0xdeafcc: b               #0xdeafd4
    // 0xdeafd0: mov             x1, x7
    // 0xdeafd4: cmp             w1, NULL
    // 0xdeafd8: b.ne            #0xdeb04c
    // 0xdeafdc: r1 = LoadClassIdInstr(r5)
    //     0xdeafdc: ldur            x1, [x5, #-1]
    //     0xdeafe0: ubfx            x1, x1, #0xc, #0x14
    // 0xdeafe4: r17 = 5201
    //     0xdeafe4: mov             x17, #0x1451
    // 0xdeafe8: cmp             x1, x17
    // 0xdeafec: b.ne            #0xdeb000
    // 0xdeaff0: LoadField: r1 = r5->field_7
    //     0xdeaff0: ldur            w1, [x5, #7]
    // 0xdeaff4: DecompressPointer r1
    //     0xdeaff4: add             x1, x1, HEAP, lsl #32
    // 0xdeaff8: mov             x0, x1
    // 0xdeaffc: b               #0xdeb048
    // 0xdeb000: mov             x1, x5
    // 0xdeb004: LoadField: r0 = r1->field_3f
    //     0xdeb004: ldur            w0, [x1, #0x3f]
    // 0xdeb008: DecompressPointer r0
    //     0xdeb008: add             x0, x0, HEAP, lsl #32
    // 0xdeb00c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdeb010: cmp             w0, w16
    // 0xdeb014: b.ne            #0xdeb024
    // 0xdeb018: r2 = _colors
    //     0xdeb018: add             x2, PP, #0x26, lsl #12  ; [pp+0x26550] Field <_BottomSheetDefaultsM3@726001611._colors@726001611>: late final (offset: 0x40)
    //     0xdeb01c: ldr             x2, [x2, #0x550]
    // 0xdeb020: r0 = InitLateFinalInstanceField()
    //     0xdeb020: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdeb024: LoadField: r1 = r0->field_93
    //     0xdeb024: ldur            w1, [x0, #0x93]
    // 0xdeb028: DecompressPointer r1
    //     0xdeb028: add             x1, x1, HEAP, lsl #32
    // 0xdeb02c: cmp             w1, NULL
    // 0xdeb030: b.ne            #0xdeb044
    // 0xdeb034: LoadField: r1 = r0->field_7b
    //     0xdeb034: ldur            w1, [x0, #0x7b]
    // 0xdeb038: DecompressPointer r1
    //     0xdeb038: add             x1, x1, HEAP, lsl #32
    // 0xdeb03c: mov             x0, x1
    // 0xdeb040: b               #0xdeb048
    // 0xdeb044: mov             x0, x1
    // 0xdeb048: mov             x1, x0
    // 0xdeb04c: ldur            x0, [fp, #-0x28]
    // 0xdeb050: stur            x1, [fp, #-0x58]
    // 0xdeb054: r2 = LoadClassIdInstr(r0)
    //     0xdeb054: ldur            x2, [x0, #-1]
    //     0xdeb058: ubfx            x2, x2, #0xc, #0x14
    // 0xdeb05c: r17 = 5201
    //     0xdeb05c: mov             x17, #0x1451
    // 0xdeb060: cmp             x2, x17
    // 0xdeb064: b.ne            #0xdeb078
    // 0xdeb068: LoadField: r3 = r0->field_b
    //     0xdeb068: ldur            w3, [x0, #0xb]
    // 0xdeb06c: DecompressPointer r3
    //     0xdeb06c: add             x3, x3, HEAP, lsl #32
    // 0xdeb070: mov             x4, x3
    // 0xdeb074: b               #0xdeb080
    // 0xdeb078: r4 = Instance_Color
    //     0xdeb078: add             x4, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdeb07c: ldr             x4, [x4, #0x810]
    // 0xdeb080: ldur            x3, [fp, #-8]
    // 0xdeb084: stur            x4, [fp, #-0x50]
    // 0xdeb088: LoadField: r5 = r3->field_b
    //     0xdeb088: ldur            w5, [x3, #0xb]
    // 0xdeb08c: DecompressPointer r5
    //     0xdeb08c: add             x5, x5, HEAP, lsl #32
    // 0xdeb090: stur            x5, [fp, #-0x48]
    // 0xdeb094: cmp             w5, NULL
    // 0xdeb098: b.eq            #0xdeb504
    // 0xdeb09c: r17 = 5201
    //     0xdeb09c: mov             x17, #0x1451
    // 0xdeb0a0: cmp             x2, x17
    // 0xdeb0a4: b.ne            #0xdeb0b4
    // 0xdeb0a8: LoadField: r2 = r0->field_1b
    //     0xdeb0a8: ldur            w2, [x0, #0x1b]
    // 0xdeb0ac: DecompressPointer r2
    //     0xdeb0ac: add             x2, x2, HEAP, lsl #32
    // 0xdeb0b0: b               #0xdeb0bc
    // 0xdeb0b4: r2 = Instance_Color
    //     0xdeb0b4: add             x2, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdeb0b8: ldr             x2, [x2, #0x810]
    // 0xdeb0bc: stur            x2, [fp, #-0x40]
    // 0xdeb0c0: LoadField: r6 = r5->field_37
    //     0xdeb0c0: ldur            w6, [x5, #0x37]
    // 0xdeb0c4: DecompressPointer r6
    //     0xdeb0c4: add             x6, x6, HEAP, lsl #32
    // 0xdeb0c8: cmp             w6, NULL
    // 0xdeb0cc: b.ne            #0xdeb0e0
    // 0xdeb0d0: ldur            x7, [fp, #-0x18]
    // 0xdeb0d4: LoadField: r6 = r7->field_f
    //     0xdeb0d4: ldur            w6, [x7, #0xf]
    // 0xdeb0d8: DecompressPointer r6
    //     0xdeb0d8: add             x6, x6, HEAP, lsl #32
    // 0xdeb0dc: b               #0xdeb0e4
    // 0xdeb0e0: ldur            x7, [fp, #-0x18]
    // 0xdeb0e4: cmp             w6, NULL
    // 0xdeb0e8: b.ne            #0xdeb0f4
    // 0xdeb0ec: LoadField: r6 = r0->field_f
    //     0xdeb0ec: ldur            w6, [x0, #0xf]
    // 0xdeb0f0: DecompressPointer r6
    //     0xdeb0f0: add             x6, x6, HEAP, lsl #32
    // 0xdeb0f4: cmp             w6, NULL
    // 0xdeb0f8: b.ne            #0xdeb104
    // 0xdeb0fc: d0 = 0.000000
    //     0xdeb0fc: eor             v0.16b, v0.16b, v0.16b
    // 0xdeb100: b               #0xdeb108
    // 0xdeb104: LoadField: d0 = r6->field_7
    //     0xdeb104: ldur            d0, [x6, #7]
    // 0xdeb108: stur            d0, [fp, #-0x68]
    // 0xdeb10c: LoadField: r6 = r7->field_23
    //     0xdeb10c: ldur            w6, [x7, #0x23]
    // 0xdeb110: DecompressPointer r6
    //     0xdeb110: add             x6, x6, HEAP, lsl #32
    // 0xdeb114: cmp             w6, NULL
    // 0xdeb118: b.ne            #0xdeb12c
    // 0xdeb11c: LoadField: r6 = r0->field_23
    //     0xdeb11c: ldur            w6, [x0, #0x23]
    // 0xdeb120: DecompressPointer r6
    //     0xdeb120: add             x6, x6, HEAP, lsl #32
    // 0xdeb124: mov             x0, x6
    // 0xdeb128: b               #0xdeb130
    // 0xdeb12c: mov             x0, x6
    // 0xdeb130: stur            x0, [fp, #-0x38]
    // 0xdeb134: LoadField: r6 = r5->field_1b
    //     0xdeb134: ldur            w6, [x5, #0x1b]
    // 0xdeb138: DecompressPointer r6
    //     0xdeb138: add             x6, x6, HEAP, lsl #32
    // 0xdeb13c: cmp             w6, NULL
    // 0xdeb140: b.ne            #0xdeb148
    // 0xdeb144: r6 = false
    //     0xdeb144: add             x6, NULL, #0x30  ; false
    // 0xdeb148: stur            x6, [fp, #-0x30]
    // 0xdeb14c: tbnz            w6, #4, #0xdeb220
    // 0xdeb150: LoadField: r7 = r5->field_f
    //     0xdeb150: ldur            w7, [x5, #0xf]
    // 0xdeb154: DecompressPointer r7
    //     0xdeb154: add             x7, x7, HEAP, lsl #32
    // 0xdeb158: stur            x7, [fp, #-0x28]
    // 0xdeb15c: ArrayLoad: r8 = r3[0]  ; List_4
    //     0xdeb15c: ldur            w8, [x3, #0x17]
    // 0xdeb160: DecompressPointer r8
    //     0xdeb160: add             x8, x8, HEAP, lsl #32
    // 0xdeb164: stur            x8, [fp, #-0x18]
    // 0xdeb168: r0 = _DragHandle()
    //     0xdeb168: bl              #0xdeb540  ; Allocate_DragHandleStub -> _DragHandle (size=0x20)
    // 0xdeb16c: mov             x3, x0
    // 0xdeb170: ldur            x0, [fp, #-0x28]
    // 0xdeb174: stur            x3, [fp, #-0x60]
    // 0xdeb178: StoreField: r3->field_b = r0
    //     0xdeb178: stur            w0, [x3, #0xb]
    // 0xdeb17c: ldur            x2, [fp, #-8]
    // 0xdeb180: r1 = Function '_handleDragHandleHover@726001611':.
    //     0xdeb180: add             x1, PP, #0xab, lsl #12  ; [pp+0xab200] AnonymousClosure: (0xdebd20), in [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragHandleHover (0xdebd5c)
    //     0xdeb184: ldr             x1, [x1, #0x200]
    // 0xdeb188: r0 = AllocateClosure()
    //     0xdeb188: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdeb18c: mov             x1, x0
    // 0xdeb190: ldur            x0, [fp, #-0x60]
    // 0xdeb194: StoreField: r0->field_f = r1
    //     0xdeb194: stur            w1, [x0, #0xf]
    // 0xdeb198: ldur            x1, [fp, #-0x18]
    // 0xdeb19c: StoreField: r0->field_13 = r1
    //     0xdeb19c: stur            w1, [x0, #0x13]
    // 0xdeb1a0: ldur            x1, [fp, #-0x48]
    // 0xdeb1a4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xdeb1a4: ldur            w2, [x1, #0x17]
    // 0xdeb1a8: DecompressPointer r2
    //     0xdeb1a8: add             x2, x2, HEAP, lsl #32
    // 0xdeb1ac: tbz             w2, #4, #0xdeb218
    // 0xdeb1b0: r0 = _BottomSheetGestureDetector()
    //     0xdeb1b0: bl              #0xdeb534  ; Allocate_BottomSheetGestureDetectorStub -> _BottomSheetGestureDetector (size=0x1c)
    // 0xdeb1b4: mov             x3, x0
    // 0xdeb1b8: ldur            x0, [fp, #-0x60]
    // 0xdeb1bc: stur            x3, [fp, #-0x18]
    // 0xdeb1c0: StoreField: r3->field_b = r0
    //     0xdeb1c0: stur            w0, [x3, #0xb]
    // 0xdeb1c4: ldur            x2, [fp, #-8]
    // 0xdeb1c8: r1 = Function '_handleDragStart@726001611':.
    //     0xdeb1c8: add             x1, PP, #0xab, lsl #12  ; [pp+0xab208] AnonymousClosure: (0xdebbec), in [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragStart (0xdebc28)
    //     0xdeb1cc: ldr             x1, [x1, #0x208]
    // 0xdeb1d0: r0 = AllocateClosure()
    //     0xdeb1d0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdeb1d4: mov             x1, x0
    // 0xdeb1d8: ldur            x0, [fp, #-0x18]
    // 0xdeb1dc: StoreField: r0->field_f = r1
    //     0xdeb1dc: stur            w1, [x0, #0xf]
    // 0xdeb1e0: ldur            x2, [fp, #-8]
    // 0xdeb1e4: r1 = Function '_handleDragUpdate@726001611':.
    //     0xdeb1e4: add             x1, PP, #0xab, lsl #12  ; [pp+0xab210] AnonymousClosure: (0xdeba80), in [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragUpdate (0xdebabc)
    //     0xdeb1e8: ldr             x1, [x1, #0x210]
    // 0xdeb1ec: r0 = AllocateClosure()
    //     0xdeb1ec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdeb1f0: mov             x1, x0
    // 0xdeb1f4: ldur            x0, [fp, #-0x18]
    // 0xdeb1f8: StoreField: r0->field_13 = r1
    //     0xdeb1f8: stur            w1, [x0, #0x13]
    // 0xdeb1fc: ldur            x2, [fp, #-8]
    // 0xdeb200: r1 = Function '_handleDragEnd@726001611':.
    //     0xdeb200: add             x1, PP, #0xab, lsl #12  ; [pp+0xab218] AnonymousClosure: (0xdeb608), in [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragEnd (0xdeb644)
    //     0xdeb204: ldr             x1, [x1, #0x218]
    // 0xdeb208: r0 = AllocateClosure()
    //     0xdeb208: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdeb20c: mov             x1, x0
    // 0xdeb210: ldur            x0, [fp, #-0x18]
    // 0xdeb214: ArrayStore: r0[0] = r1  ; List_4
    //     0xdeb214: stur            w1, [x0, #0x17]
    // 0xdeb218: mov             x1, x0
    // 0xdeb21c: b               #0xdeb224
    // 0xdeb220: r1 = Null
    //     0xdeb220: mov             x1, NULL
    // 0xdeb224: ldur            x2, [fp, #-8]
    // 0xdeb228: ldur            x0, [fp, #-0x30]
    // 0xdeb22c: stur            x1, [fp, #-0x28]
    // 0xdeb230: LoadField: r3 = r2->field_13
    //     0xdeb230: ldur            w3, [x2, #0x13]
    // 0xdeb234: DecompressPointer r3
    //     0xdeb234: add             x3, x3, HEAP, lsl #32
    // 0xdeb238: stur            x3, [fp, #-0x18]
    // 0xdeb23c: tbz             w0, #4, #0xdeb26c
    // 0xdeb240: ldur            x0, [fp, #-0x48]
    // 0xdeb244: LoadField: r1 = r0->field_13
    //     0xdeb244: ldur            w1, [x0, #0x13]
    // 0xdeb248: DecompressPointer r1
    //     0xdeb248: add             x1, x1, HEAP, lsl #32
    // 0xdeb24c: ldur            x16, [fp, #-0x10]
    // 0xdeb250: stp             x16, x1, [SP]
    // 0xdeb254: mov             x0, x1
    // 0xdeb258: ClosureCall
    //     0xdeb258: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xdeb25c: ldur            x2, [x0, #0x1f]
    //     0xdeb260: blr             x2
    // 0xdeb264: mov             x8, x0
    // 0xdeb268: b               #0xdeb338
    // 0xdeb26c: ldur            x0, [fp, #-0x48]
    // 0xdeb270: cmp             w1, NULL
    // 0xdeb274: b.eq            #0xdeb508
    // 0xdeb278: LoadField: r2 = r0->field_13
    //     0xdeb278: ldur            w2, [x0, #0x13]
    // 0xdeb27c: DecompressPointer r2
    //     0xdeb27c: add             x2, x2, HEAP, lsl #32
    // 0xdeb280: ldur            x16, [fp, #-0x10]
    // 0xdeb284: stp             x16, x2, [SP]
    // 0xdeb288: mov             x0, x2
    // 0xdeb28c: ClosureCall
    //     0xdeb28c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xdeb290: ldur            x2, [x0, #0x1f]
    //     0xdeb294: blr             x2
    // 0xdeb298: stur            x0, [fp, #-0x10]
    // 0xdeb29c: r0 = Padding()
    //     0xdeb29c: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xdeb2a0: mov             x3, x0
    // 0xdeb2a4: r0 = Instance_EdgeInsets
    //     0xdeb2a4: add             x0, PP, #0xab, lsl #12  ; [pp+0xab220] Obj!EdgeInsets@129d591
    //     0xdeb2a8: ldr             x0, [x0, #0x220]
    // 0xdeb2ac: stur            x3, [fp, #-0x30]
    // 0xdeb2b0: StoreField: r3->field_f = r0
    //     0xdeb2b0: stur            w0, [x3, #0xf]
    // 0xdeb2b4: ldur            x0, [fp, #-0x10]
    // 0xdeb2b8: StoreField: r3->field_b = r0
    //     0xdeb2b8: stur            w0, [x3, #0xb]
    // 0xdeb2bc: r1 = Null
    //     0xdeb2bc: mov             x1, NULL
    // 0xdeb2c0: r2 = 4
    //     0xdeb2c0: mov             x2, #4
    // 0xdeb2c4: r0 = AllocateArray()
    //     0xdeb2c4: bl              #0x13df928  ; AllocateArrayStub
    // 0xdeb2c8: mov             x2, x0
    // 0xdeb2cc: ldur            x0, [fp, #-0x28]
    // 0xdeb2d0: stur            x2, [fp, #-0x10]
    // 0xdeb2d4: StoreField: r2->field_f = r0
    //     0xdeb2d4: stur            w0, [x2, #0xf]
    // 0xdeb2d8: ldur            x0, [fp, #-0x30]
    // 0xdeb2dc: StoreField: r2->field_13 = r0
    //     0xdeb2dc: stur            w0, [x2, #0x13]
    // 0xdeb2e0: r1 = <Widget>
    //     0xdeb2e0: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdeb2e4: r0 = AllocateGrowableArray()
    //     0xdeb2e4: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xdeb2e8: mov             x1, x0
    // 0xdeb2ec: ldur            x0, [fp, #-0x10]
    // 0xdeb2f0: stur            x1, [fp, #-0x28]
    // 0xdeb2f4: StoreField: r1->field_f = r0
    //     0xdeb2f4: stur            w0, [x1, #0xf]
    // 0xdeb2f8: r0 = 4
    //     0xdeb2f8: mov             x0, #4
    // 0xdeb2fc: StoreField: r1->field_b = r0
    //     0xdeb2fc: stur            w0, [x1, #0xb]
    // 0xdeb300: r0 = Stack()
    //     0xdeb300: bl              #0xd1a854  ; AllocateStackStub -> Stack (size=0x20)
    // 0xdeb304: mov             x1, x0
    // 0xdeb308: r0 = Instance_Alignment
    //     0xdeb308: add             x0, PP, #0x19, lsl #12  ; [pp+0x197a8] Obj!Alignment@129e7d1
    //     0xdeb30c: ldr             x0, [x0, #0x7a8]
    // 0xdeb310: StoreField: r1->field_f = r0
    //     0xdeb310: stur            w0, [x1, #0xf]
    // 0xdeb314: r0 = Instance_StackFit
    //     0xdeb314: add             x0, PP, #0x15, lsl #12  ; [pp+0x158e0] Obj!StackFit@12c4221
    //     0xdeb318: ldr             x0, [x0, #0x8e0]
    // 0xdeb31c: ArrayStore: r1[0] = r0  ; List_4
    //     0xdeb31c: stur            w0, [x1, #0x17]
    // 0xdeb320: r0 = Instance_Clip
    //     0xdeb320: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xdeb324: ldr             x0, [x0, #0x850]
    // 0xdeb328: StoreField: r1->field_1b = r0
    //     0xdeb328: stur            w0, [x1, #0x1b]
    // 0xdeb32c: ldur            x0, [fp, #-0x28]
    // 0xdeb330: StoreField: r1->field_b = r0
    //     0xdeb330: stur            w0, [x1, #0xb]
    // 0xdeb334: mov             x8, x1
    // 0xdeb338: ldur            x7, [fp, #-0x20]
    // 0xdeb33c: ldur            x3, [fp, #-0x58]
    // 0xdeb340: ldur            d0, [fp, #-0x68]
    // 0xdeb344: ldur            x6, [fp, #-0x38]
    // 0xdeb348: ldur            x0, [fp, #-0x18]
    // 0xdeb34c: ldur            x5, [fp, #-0x40]
    // 0xdeb350: ldur            x4, [fp, #-0x50]
    // 0xdeb354: ldur            x2, [fp, #-8]
    // 0xdeb358: stur            x8, [fp, #-0x10]
    // 0xdeb35c: r1 = Function 'extentChanged':.
    //     0xdeb35c: add             x1, PP, #0xab, lsl #12  ; [pp+0xab228] AnonymousClosure: (0xdeb558), in [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::extentChanged (0xdeb594)
    //     0xdeb360: ldr             x1, [x1, #0x228]
    // 0xdeb364: r0 = AllocateClosure()
    //     0xdeb364: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdeb368: r1 = <DraggableScrollableNotification>
    //     0xdeb368: add             x1, PP, #0x84, lsl #12  ; [pp+0x84c20] TypeArguments: <DraggableScrollableNotification>
    //     0xdeb36c: ldr             x1, [x1, #0xc20]
    // 0xdeb370: stur            x0, [fp, #-0x28]
    // 0xdeb374: r0 = NotificationListener()
    //     0xdeb374: bl              #0xd2ea9c  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0xdeb378: mov             x1, x0
    // 0xdeb37c: ldur            x0, [fp, #-0x28]
    // 0xdeb380: stur            x1, [fp, #-0x30]
    // 0xdeb384: StoreField: r1->field_13 = r0
    //     0xdeb384: stur            w0, [x1, #0x13]
    // 0xdeb388: ldur            x0, [fp, #-0x10]
    // 0xdeb38c: StoreField: r1->field_b = r0
    //     0xdeb38c: stur            w0, [x1, #0xb]
    // 0xdeb390: r0 = Material()
    //     0xdeb390: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xdeb394: mov             x1, x0
    // 0xdeb398: r0 = Instance_MaterialType
    //     0xdeb398: add             x0, PP, #0x17, lsl #12  ; [pp+0x17210] Obj!MaterialType@12c5341
    //     0xdeb39c: ldr             x0, [x0, #0x210]
    // 0xdeb3a0: stur            x1, [fp, #-0x10]
    // 0xdeb3a4: StoreField: r1->field_f = r0
    //     0xdeb3a4: stur            w0, [x1, #0xf]
    // 0xdeb3a8: ldur            d0, [fp, #-0x68]
    // 0xdeb3ac: ArrayStore: r1[0] = d0  ; List_8
    //     0xdeb3ac: stur            d0, [x1, #0x17]
    // 0xdeb3b0: ldur            x0, [fp, #-0x58]
    // 0xdeb3b4: StoreField: r1->field_1f = r0
    //     0xdeb3b4: stur            w0, [x1, #0x1f]
    // 0xdeb3b8: ldur            x0, [fp, #-0x40]
    // 0xdeb3bc: StoreField: r1->field_23 = r0
    //     0xdeb3bc: stur            w0, [x1, #0x23]
    // 0xdeb3c0: ldur            x0, [fp, #-0x50]
    // 0xdeb3c4: StoreField: r1->field_27 = r0
    //     0xdeb3c4: stur            w0, [x1, #0x27]
    // 0xdeb3c8: ldur            x0, [fp, #-0x38]
    // 0xdeb3cc: StoreField: r1->field_2f = r0
    //     0xdeb3cc: stur            w0, [x1, #0x2f]
    // 0xdeb3d0: r0 = true
    //     0xdeb3d0: add             x0, NULL, #0x20  ; true
    // 0xdeb3d4: StoreField: r1->field_33 = r0
    //     0xdeb3d4: stur            w0, [x1, #0x33]
    // 0xdeb3d8: r0 = Instance_Clip
    //     0xdeb3d8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdeb3dc: ldr             x0, [x0, #0x840]
    // 0xdeb3e0: StoreField: r1->field_37 = r0
    //     0xdeb3e0: stur            w0, [x1, #0x37]
    // 0xdeb3e4: r0 = Instance_Duration
    //     0xdeb3e4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xdeb3e8: ldr             x0, [x0, #0x318]
    // 0xdeb3ec: StoreField: r1->field_3b = r0
    //     0xdeb3ec: stur            w0, [x1, #0x3b]
    // 0xdeb3f0: ldur            x0, [fp, #-0x30]
    // 0xdeb3f4: StoreField: r1->field_b = r0
    //     0xdeb3f4: stur            w0, [x1, #0xb]
    // 0xdeb3f8: r0 = false
    //     0xdeb3f8: add             x0, NULL, #0x30  ; false
    // 0xdeb3fc: StoreField: r1->field_13 = r0
    //     0xdeb3fc: stur            w0, [x1, #0x13]
    // 0xdeb400: ldur            x0, [fp, #-0x18]
    // 0xdeb404: StoreField: r1->field_7 = r0
    //     0xdeb404: stur            w0, [x1, #7]
    // 0xdeb408: ldur            x0, [fp, #-0x20]
    // 0xdeb40c: cmp             w0, NULL
    // 0xdeb410: b.eq            #0xdeb45c
    // 0xdeb414: r0 = ConstrainedBox()
    //     0xdeb414: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xdeb418: mov             x1, x0
    // 0xdeb41c: ldur            x0, [fp, #-0x20]
    // 0xdeb420: stur            x1, [fp, #-0x18]
    // 0xdeb424: StoreField: r1->field_f = r0
    //     0xdeb424: stur            w0, [x1, #0xf]
    // 0xdeb428: ldur            x0, [fp, #-0x10]
    // 0xdeb42c: StoreField: r1->field_b = r0
    //     0xdeb42c: stur            w0, [x1, #0xb]
    // 0xdeb430: r0 = Align()
    //     0xdeb430: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xdeb434: mov             x1, x0
    // 0xdeb438: r0 = Instance_Alignment
    //     0xdeb438: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1b8] Obj!Alignment@129e6f1
    //     0xdeb43c: ldr             x0, [x0, #0x1b8]
    // 0xdeb440: StoreField: r1->field_f = r0
    //     0xdeb440: stur            w0, [x1, #0xf]
    // 0xdeb444: r0 = 1.000000
    //     0xdeb444: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xdeb448: ArrayStore: r1[0] = r0  ; List_4
    //     0xdeb448: stur            w0, [x1, #0x17]
    // 0xdeb44c: ldur            x0, [fp, #-0x18]
    // 0xdeb450: StoreField: r1->field_b = r0
    //     0xdeb450: stur            w0, [x1, #0xb]
    // 0xdeb454: mov             x0, x1
    // 0xdeb458: b               #0xdeb460
    // 0xdeb45c: mov             x0, x1
    // 0xdeb460: ldur            x2, [fp, #-8]
    // 0xdeb464: stur            x0, [fp, #-0x10]
    // 0xdeb468: LoadField: r1 = r2->field_b
    //     0xdeb468: ldur            w1, [x2, #0xb]
    // 0xdeb46c: DecompressPointer r1
    //     0xdeb46c: add             x1, x1, HEAP, lsl #32
    // 0xdeb470: cmp             w1, NULL
    // 0xdeb474: b.eq            #0xdeb50c
    // 0xdeb478: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xdeb478: ldur            w3, [x1, #0x17]
    // 0xdeb47c: DecompressPointer r3
    //     0xdeb47c: add             x3, x3, HEAP, lsl #32
    // 0xdeb480: tbnz            w3, #4, #0xdeb4ec
    // 0xdeb484: r0 = _BottomSheetGestureDetector()
    //     0xdeb484: bl              #0xdeb534  ; Allocate_BottomSheetGestureDetectorStub -> _BottomSheetGestureDetector (size=0x1c)
    // 0xdeb488: mov             x3, x0
    // 0xdeb48c: ldur            x0, [fp, #-0x10]
    // 0xdeb490: stur            x3, [fp, #-0x18]
    // 0xdeb494: StoreField: r3->field_b = r0
    //     0xdeb494: stur            w0, [x3, #0xb]
    // 0xdeb498: ldur            x2, [fp, #-8]
    // 0xdeb49c: r1 = Function '_handleDragStart@726001611':.
    //     0xdeb49c: add             x1, PP, #0xab, lsl #12  ; [pp+0xab208] AnonymousClosure: (0xdebbec), in [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragStart (0xdebc28)
    //     0xdeb4a0: ldr             x1, [x1, #0x208]
    // 0xdeb4a4: r0 = AllocateClosure()
    //     0xdeb4a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdeb4a8: mov             x1, x0
    // 0xdeb4ac: ldur            x0, [fp, #-0x18]
    // 0xdeb4b0: StoreField: r0->field_f = r1
    //     0xdeb4b0: stur            w1, [x0, #0xf]
    // 0xdeb4b4: ldur            x2, [fp, #-8]
    // 0xdeb4b8: r1 = Function '_handleDragUpdate@726001611':.
    //     0xdeb4b8: add             x1, PP, #0xab, lsl #12  ; [pp+0xab210] AnonymousClosure: (0xdeba80), in [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragUpdate (0xdebabc)
    //     0xdeb4bc: ldr             x1, [x1, #0x210]
    // 0xdeb4c0: r0 = AllocateClosure()
    //     0xdeb4c0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdeb4c4: mov             x1, x0
    // 0xdeb4c8: ldur            x0, [fp, #-0x18]
    // 0xdeb4cc: StoreField: r0->field_13 = r1
    //     0xdeb4cc: stur            w1, [x0, #0x13]
    // 0xdeb4d0: ldur            x2, [fp, #-8]
    // 0xdeb4d4: r1 = Function '_handleDragEnd@726001611':.
    //     0xdeb4d4: add             x1, PP, #0xab, lsl #12  ; [pp+0xab218] AnonymousClosure: (0xdeb608), in [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragEnd (0xdeb644)
    //     0xdeb4d8: ldr             x1, [x1, #0x218]
    // 0xdeb4dc: r0 = AllocateClosure()
    //     0xdeb4dc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdeb4e0: ldur            x1, [fp, #-0x18]
    // 0xdeb4e4: ArrayStore: r1[0] = r0  ; List_4
    //     0xdeb4e4: stur            w0, [x1, #0x17]
    // 0xdeb4e8: mov             x0, x1
    // 0xdeb4ec: LeaveFrame
    //     0xdeb4ec: mov             SP, fp
    //     0xdeb4f0: ldp             fp, lr, [SP], #0x10
    // 0xdeb4f4: ret
    //     0xdeb4f4: ret             
    // 0xdeb4f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdeb4f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdeb4fc: b               #0xdeaee0
    // 0xdeb500: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeb500: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdeb504: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeb504: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdeb508: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeb508: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdeb50c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeb50c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool extentChanged(dynamic, DraggableScrollableNotification) {
    // ** addr: 0xdeb558, size: 0x3c
    // 0xdeb558: EnterFrame
    //     0xdeb558: stp             fp, lr, [SP, #-0x10]!
    //     0xdeb55c: mov             fp, SP
    // 0xdeb560: ldr             x0, [fp, #0x18]
    // 0xdeb564: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdeb564: ldur            w1, [x0, #0x17]
    // 0xdeb568: DecompressPointer r1
    //     0xdeb568: add             x1, x1, HEAP, lsl #32
    // 0xdeb56c: CheckStackOverflow
    //     0xdeb56c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdeb570: cmp             SP, x16
    //     0xdeb574: b.ls            #0xdeb58c
    // 0xdeb578: ldr             x2, [fp, #0x10]
    // 0xdeb57c: r0 = extentChanged()
    //     0xdeb57c: bl              #0xdeb594  ; [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::extentChanged
    // 0xdeb580: LeaveFrame
    //     0xdeb580: mov             SP, fp
    //     0xdeb584: ldp             fp, lr, [SP], #0x10
    // 0xdeb588: ret
    //     0xdeb588: ret             
    // 0xdeb58c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdeb58c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdeb590: b               #0xdeb578
  }
  _ extentChanged(/* No info */) {
    // ** addr: 0xdeb594, size: 0x74
    // 0xdeb594: EnterFrame
    //     0xdeb594: stp             fp, lr, [SP, #-0x10]!
    //     0xdeb598: mov             fp, SP
    // 0xdeb59c: AllocStack(0x8)
    //     0xdeb59c: sub             SP, SP, #8
    // 0xdeb5a0: d0 = 0.200000
    //     0xdeb5a0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13230] IMM: double(0.2) from 0x3fc999999999999a
    //     0xdeb5a4: ldr             d0, [x17, #0x230]
    // 0xdeb5a8: CheckStackOverflow
    //     0xdeb5a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdeb5ac: cmp             SP, x16
    //     0xdeb5b0: b.ls            #0xdeb5fc
    // 0xdeb5b4: LoadField: d1 = r2->field_f
    //     0xdeb5b4: ldur            d1, [x2, #0xf]
    // 0xdeb5b8: fcmp            d1, d0
    // 0xdeb5bc: b.ne            #0xdeb5ec
    // 0xdeb5c0: LoadField: r0 = r1->field_b
    //     0xdeb5c0: ldur            w0, [x1, #0xb]
    // 0xdeb5c4: DecompressPointer r0
    //     0xdeb5c4: add             x0, x0, HEAP, lsl #32
    // 0xdeb5c8: cmp             w0, NULL
    // 0xdeb5cc: b.eq            #0xdeb604
    // 0xdeb5d0: LoadField: r1 = r0->field_f
    //     0xdeb5d0: ldur            w1, [x0, #0xf]
    // 0xdeb5d4: DecompressPointer r1
    //     0xdeb5d4: add             x1, x1, HEAP, lsl #32
    // 0xdeb5d8: str             x1, [SP]
    // 0xdeb5dc: mov             x0, x1
    // 0xdeb5e0: ClosureCall
    //     0xdeb5e0: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xdeb5e4: ldur            x2, [x0, #0x1f]
    //     0xdeb5e8: blr             x2
    // 0xdeb5ec: r0 = false
    //     0xdeb5ec: add             x0, NULL, #0x30  ; false
    // 0xdeb5f0: LeaveFrame
    //     0xdeb5f0: mov             SP, fp
    //     0xdeb5f4: ldp             fp, lr, [SP], #0x10
    // 0xdeb5f8: ret
    //     0xdeb5f8: ret             
    // 0xdeb5fc: r0 = StackOverflowSharedWithFPURegs()
    //     0xdeb5fc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xdeb600: b               #0xdeb5b4
    // 0xdeb604: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeb604: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleDragEnd(dynamic, DragEndDetails) {
    // ** addr: 0xdeb608, size: 0x3c
    // 0xdeb608: EnterFrame
    //     0xdeb608: stp             fp, lr, [SP, #-0x10]!
    //     0xdeb60c: mov             fp, SP
    // 0xdeb610: ldr             x0, [fp, #0x18]
    // 0xdeb614: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdeb614: ldur            w1, [x0, #0x17]
    // 0xdeb618: DecompressPointer r1
    //     0xdeb618: add             x1, x1, HEAP, lsl #32
    // 0xdeb61c: CheckStackOverflow
    //     0xdeb61c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdeb620: cmp             SP, x16
    //     0xdeb624: b.ls            #0xdeb63c
    // 0xdeb628: ldr             x2, [fp, #0x10]
    // 0xdeb62c: r0 = _handleDragEnd()
    //     0xdeb62c: bl              #0xdeb644  ; [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragEnd
    // 0xdeb630: LeaveFrame
    //     0xdeb630: mov             SP, fp
    //     0xdeb634: ldp             fp, lr, [SP], #0x10
    // 0xdeb638: ret
    //     0xdeb638: ret             
    // 0xdeb63c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdeb63c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdeb640: b               #0xdeb628
  }
  _ _handleDragEnd(/* No info */) {
    // ** addr: 0xdeb644, size: 0x2d8
    // 0xdeb644: EnterFrame
    //     0xdeb644: stp             fp, lr, [SP, #-0x10]!
    //     0xdeb648: mov             fp, SP
    // 0xdeb64c: AllocStack(0x40)
    //     0xdeb64c: sub             SP, SP, #0x40
    // 0xdeb650: SetupParameters(_BottomSheetState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdeb650: stur            x1, [fp, #-8]
    //     0xdeb654: stur            x2, [fp, #-0x10]
    // 0xdeb658: CheckStackOverflow
    //     0xdeb658: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdeb65c: cmp             SP, x16
    //     0xdeb660: b.ls            #0xdeb8d0
    // 0xdeb664: r1 = 1
    //     0xdeb664: mov             x1, #1
    // 0xdeb668: r0 = AllocateContext()
    //     0xdeb668: bl              #0x13de838  ; AllocateContextStub
    // 0xdeb66c: mov             x2, x0
    // 0xdeb670: ldur            x0, [fp, #-8]
    // 0xdeb674: stur            x2, [fp, #-0x18]
    // 0xdeb678: StoreField: r2->field_f = r0
    //     0xdeb678: stur            w0, [x2, #0xf]
    // 0xdeb67c: mov             x1, x0
    // 0xdeb680: r0 = _dismissUnderway()
    //     0xdeb680: bl              #0xdeb9c0  ; [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_dismissUnderway
    // 0xdeb684: tbnz            w0, #4, #0xdeb698
    // 0xdeb688: r0 = Null
    //     0xdeb688: mov             x0, NULL
    // 0xdeb68c: LeaveFrame
    //     0xdeb68c: mov             SP, fp
    //     0xdeb690: ldp             fp, lr, [SP], #0x10
    // 0xdeb694: ret
    //     0xdeb694: ret             
    // 0xdeb698: ldur            x0, [fp, #-0x10]
    // 0xdeb69c: ldur            x2, [fp, #-0x18]
    // 0xdeb6a0: r1 = Function '<anonymous closure>':.
    //     0xdeb6a0: add             x1, PP, #0xab, lsl #12  ; [pp+0xab230] AnonymousClosure: (0xdeba2c), in [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragEnd (0xdeb644)
    //     0xdeb6a4: ldr             x1, [x1, #0x230]
    // 0xdeb6a8: r0 = AllocateClosure()
    //     0xdeb6a8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdeb6ac: ldur            x1, [fp, #-8]
    // 0xdeb6b0: mov             x2, x0
    // 0xdeb6b4: r0 = setState()
    //     0xdeb6b4: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdeb6b8: ldur            x0, [fp, #-0x10]
    // 0xdeb6bc: LoadField: r1 = r0->field_b
    //     0xdeb6bc: ldur            w1, [x0, #0xb]
    // 0xdeb6c0: DecompressPointer r1
    //     0xdeb6c0: add             x1, x1, HEAP, lsl #32
    // 0xdeb6c4: LoadField: r2 = r1->field_7
    //     0xdeb6c4: ldur            w2, [x1, #7]
    // 0xdeb6c8: DecompressPointer r2
    //     0xdeb6c8: add             x2, x2, HEAP, lsl #32
    // 0xdeb6cc: LoadField: d0 = r2->field_f
    //     0xdeb6cc: ldur            d0, [x2, #0xf]
    // 0xdeb6d0: d1 = 700.000000
    //     0xdeb6d0: add             x17, PP, #0x8f, lsl #12  ; [pp+0x8f240] IMM: double(700) from 0x4085e00000000000
    //     0xdeb6d4: ldr             d1, [x17, #0x240]
    // 0xdeb6d8: fcmp            d0, d1
    // 0xdeb6dc: b.le            #0xdeb7b0
    // 0xdeb6e0: ldur            x2, [fp, #-8]
    // 0xdeb6e4: fneg            d1, d0
    // 0xdeb6e8: mov             x1, x2
    // 0xdeb6ec: stur            d1, [fp, #-0x20]
    // 0xdeb6f0: r0 = _childHeight()
    //     0xdeb6f0: bl              #0xdeb91c  ; [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_childHeight
    // 0xdeb6f4: mov             v1.16b, v0.16b
    // 0xdeb6f8: ldur            d0, [fp, #-0x20]
    // 0xdeb6fc: fdiv            d2, d0, d1
    // 0xdeb700: ldur            x0, [fp, #-8]
    // 0xdeb704: stur            d2, [fp, #-0x28]
    // 0xdeb708: LoadField: r1 = r0->field_b
    //     0xdeb708: ldur            w1, [x0, #0xb]
    // 0xdeb70c: DecompressPointer r1
    //     0xdeb70c: add             x1, x1, HEAP, lsl #32
    // 0xdeb710: cmp             w1, NULL
    // 0xdeb714: b.eq            #0xdeb8d8
    // 0xdeb718: LoadField: r2 = r1->field_b
    //     0xdeb718: ldur            w2, [x1, #0xb]
    // 0xdeb71c: DecompressPointer r2
    //     0xdeb71c: add             x2, x2, HEAP, lsl #32
    // 0xdeb720: cmp             w2, NULL
    // 0xdeb724: b.eq            #0xdeb8dc
    // 0xdeb728: LoadField: r1 = r2->field_37
    //     0xdeb728: ldur            w1, [x2, #0x37]
    // 0xdeb72c: DecompressPointer r1
    //     0xdeb72c: add             x1, x1, HEAP, lsl #32
    // 0xdeb730: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdeb734: cmp             w1, w16
    // 0xdeb738: b.eq            #0xdeb8e0
    // 0xdeb73c: LoadField: d0 = r1->field_7
    //     0xdeb73c: ldur            d0, [x1, #7]
    // 0xdeb740: d1 = 0.000000
    //     0xdeb740: eor             v1.16b, v1.16b, v1.16b
    // 0xdeb744: fcmp            d0, d1
    // 0xdeb748: b.le            #0xdeb78c
    // 0xdeb74c: r1 = inline_Allocate_Double()
    //     0xdeb74c: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0xdeb750: add             x1, x1, #0x10
    //     0xdeb754: cmp             x3, x1
    //     0xdeb758: b.ls            #0xdeb8e8
    //     0xdeb75c: str             x1, [THR, #0x60]  ; THR::top
    //     0xdeb760: sub             x1, x1, #0xf
    //     0xdeb764: mov             x3, #0xe19c
    //     0xdeb768: movk            x3, #3, lsl #16
    //     0xdeb76c: stur            x3, [x1, #-1]
    // 0xdeb770: dmb             ishst
    // 0xdeb774: StoreField: r1->field_7 = d2
    //     0xdeb774: stur            d2, [x1, #7]
    // 0xdeb778: str             x1, [SP]
    // 0xdeb77c: mov             x1, x2
    // 0xdeb780: r4 = const [0, 0x2, 0x1, 0x1, velocity, 0x1, null]
    //     0xdeb780: add             x4, PP, #0x83, lsl #12  ; [pp+0x83820] List(7) [0, 0x2, 0x1, 0x1, "velocity", 0x1, Null]
    //     0xdeb784: ldr             x4, [x4, #0x820]
    // 0xdeb788: r0 = fling()
    //     0xdeb788: bl              #0xb34edc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::fling
    // 0xdeb78c: ldur            d0, [fp, #-0x28]
    // 0xdeb790: d1 = 0.000000
    //     0xdeb790: eor             v1.16b, v1.16b, v1.16b
    // 0xdeb794: fcmp            d1, d0
    // 0xdeb798: b.le            #0xdeb7a4
    // 0xdeb79c: r0 = true
    //     0xdeb79c: add             x0, NULL, #0x20  ; true
    // 0xdeb7a0: b               #0xdeb7a8
    // 0xdeb7a4: r0 = false
    //     0xdeb7a4: add             x0, NULL, #0x30  ; false
    // 0xdeb7a8: mov             x2, x0
    // 0xdeb7ac: b               #0xdeb83c
    // 0xdeb7b0: ldur            x0, [fp, #-8]
    // 0xdeb7b4: d1 = 0.000000
    //     0xdeb7b4: eor             v1.16b, v1.16b, v1.16b
    // 0xdeb7b8: d0 = 0.500000
    //     0xdeb7b8: fmov            d0, #0.50000000
    // 0xdeb7bc: LoadField: r1 = r0->field_b
    //     0xdeb7bc: ldur            w1, [x0, #0xb]
    // 0xdeb7c0: DecompressPointer r1
    //     0xdeb7c0: add             x1, x1, HEAP, lsl #32
    // 0xdeb7c4: cmp             w1, NULL
    // 0xdeb7c8: b.eq            #0xdeb904
    // 0xdeb7cc: LoadField: r2 = r1->field_b
    //     0xdeb7cc: ldur            w2, [x1, #0xb]
    // 0xdeb7d0: DecompressPointer r2
    //     0xdeb7d0: add             x2, x2, HEAP, lsl #32
    // 0xdeb7d4: cmp             w2, NULL
    // 0xdeb7d8: b.eq            #0xdeb908
    // 0xdeb7dc: LoadField: r1 = r2->field_37
    //     0xdeb7dc: ldur            w1, [x2, #0x37]
    // 0xdeb7e0: DecompressPointer r1
    //     0xdeb7e0: add             x1, x1, HEAP, lsl #32
    // 0xdeb7e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdeb7e8: cmp             w1, w16
    // 0xdeb7ec: b.eq            #0xdeb90c
    // 0xdeb7f0: LoadField: d2 = r1->field_7
    //     0xdeb7f0: ldur            d2, [x1, #7]
    // 0xdeb7f4: fcmp            d0, d2
    // 0xdeb7f8: b.le            #0xdeb828
    // 0xdeb7fc: fcmp            d2, d1
    // 0xdeb800: b.le            #0xdeb820
    // 0xdeb804: r16 = -1.000000
    //     0xdeb804: add             x16, PP, #0x13, lsl #12  ; [pp+0x132a8] -1
    //     0xdeb808: ldr             x16, [x16, #0x2a8]
    // 0xdeb80c: str             x16, [SP]
    // 0xdeb810: mov             x1, x2
    // 0xdeb814: r4 = const [0, 0x2, 0x1, 0x1, velocity, 0x1, null]
    //     0xdeb814: add             x4, PP, #0x83, lsl #12  ; [pp+0x83820] List(7) [0, 0x2, 0x1, 0x1, "velocity", 0x1, Null]
    //     0xdeb818: ldr             x4, [x4, #0x820]
    // 0xdeb81c: r0 = fling()
    //     0xdeb81c: bl              #0xb34edc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::fling
    // 0xdeb820: r0 = true
    //     0xdeb820: add             x0, NULL, #0x20  ; true
    // 0xdeb824: b               #0xdeb838
    // 0xdeb828: mov             x1, x2
    // 0xdeb82c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xdeb82c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xdeb830: r0 = forward()
    //     0xdeb830: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xdeb834: r0 = false
    //     0xdeb834: add             x0, NULL, #0x30  ; false
    // 0xdeb838: mov             x2, x0
    // 0xdeb83c: ldur            x1, [fp, #-8]
    // 0xdeb840: stur            x2, [fp, #-0x18]
    // 0xdeb844: LoadField: r0 = r1->field_b
    //     0xdeb844: ldur            w0, [x1, #0xb]
    // 0xdeb848: DecompressPointer r0
    //     0xdeb848: add             x0, x0, HEAP, lsl #32
    // 0xdeb84c: cmp             w0, NULL
    // 0xdeb850: b.eq            #0xdeb914
    // 0xdeb854: LoadField: r3 = r0->field_2b
    //     0xdeb854: ldur            w3, [x0, #0x2b]
    // 0xdeb858: DecompressPointer r3
    //     0xdeb858: add             x3, x3, HEAP, lsl #32
    // 0xdeb85c: cmp             w3, NULL
    // 0xdeb860: b.ne            #0xdeb86c
    // 0xdeb864: mov             x0, x2
    // 0xdeb868: b               #0xdeb890
    // 0xdeb86c: ldur            x16, [fp, #-0x10]
    // 0xdeb870: stp             x16, x3, [SP, #8]
    // 0xdeb874: str             x2, [SP]
    // 0xdeb878: mov             x0, x3
    // 0xdeb87c: ClosureCall
    //     0xdeb87c: add             x4, PP, #0xab, lsl #12  ; [pp+0xab238] List(7) [0, 0x3, 0x3, 0x2, "isClosing", 0x2, Null]
    //     0xdeb880: ldr             x4, [x4, #0x238]
    //     0xdeb884: ldur            x2, [x0, #0x1f]
    //     0xdeb888: blr             x2
    // 0xdeb88c: ldur            x0, [fp, #-0x18]
    // 0xdeb890: tbnz            w0, #4, #0xdeb8c0
    // 0xdeb894: ldur            x0, [fp, #-8]
    // 0xdeb898: LoadField: r1 = r0->field_b
    //     0xdeb898: ldur            w1, [x0, #0xb]
    // 0xdeb89c: DecompressPointer r1
    //     0xdeb89c: add             x1, x1, HEAP, lsl #32
    // 0xdeb8a0: cmp             w1, NULL
    // 0xdeb8a4: b.eq            #0xdeb918
    // 0xdeb8a8: LoadField: r0 = r1->field_f
    //     0xdeb8a8: ldur            w0, [x1, #0xf]
    // 0xdeb8ac: DecompressPointer r0
    //     0xdeb8ac: add             x0, x0, HEAP, lsl #32
    // 0xdeb8b0: str             x0, [SP]
    // 0xdeb8b4: ClosureCall
    //     0xdeb8b4: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xdeb8b8: ldur            x2, [x0, #0x1f]
    //     0xdeb8bc: blr             x2
    // 0xdeb8c0: r0 = Null
    //     0xdeb8c0: mov             x0, NULL
    // 0xdeb8c4: LeaveFrame
    //     0xdeb8c4: mov             SP, fp
    //     0xdeb8c8: ldp             fp, lr, [SP], #0x10
    // 0xdeb8cc: ret
    //     0xdeb8cc: ret             
    // 0xdeb8d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdeb8d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdeb8d4: b               #0xdeb664
    // 0xdeb8d8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xdeb8d8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xdeb8dc: r0 = NullCastErrorSharedWithFPURegs()
    //     0xdeb8dc: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xdeb8e0: r9 = _value
    //     0xdeb8e0: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xdeb8e4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xdeb8e4: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xdeb8e8: stp             q1, q2, [SP, #-0x20]!
    // 0xdeb8ec: stp             x0, x2, [SP, #-0x10]!
    // 0xdeb8f0: r0 = AllocateDouble()
    //     0xdeb8f0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdeb8f4: mov             x1, x0
    // 0xdeb8f8: ldp             x0, x2, [SP], #0x10
    // 0xdeb8fc: ldp             q1, q2, [SP], #0x20
    // 0xdeb900: b               #0xdeb774
    // 0xdeb904: r0 = NullCastErrorSharedWithFPURegs()
    //     0xdeb904: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xdeb908: r0 = NullCastErrorSharedWithFPURegs()
    //     0xdeb908: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xdeb90c: r9 = _value
    //     0xdeb90c: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xdeb910: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xdeb910: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xdeb914: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeb914: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdeb918: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeb918: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _childHeight(/* No info */) {
    // ** addr: 0xdeb91c, size: 0xa4
    // 0xdeb91c: EnterFrame
    //     0xdeb91c: stp             fp, lr, [SP, #-0x10]!
    //     0xdeb920: mov             fp, SP
    // 0xdeb924: AllocStack(0x8)
    //     0xdeb924: sub             SP, SP, #8
    // 0xdeb928: CheckStackOverflow
    //     0xdeb928: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdeb92c: cmp             SP, x16
    //     0xdeb930: b.ls            #0xdeb9b0
    // 0xdeb934: LoadField: r0 = r1->field_13
    //     0xdeb934: ldur            w0, [x1, #0x13]
    // 0xdeb938: DecompressPointer r0
    //     0xdeb938: add             x0, x0, HEAP, lsl #32
    // 0xdeb93c: mov             x1, x0
    // 0xdeb940: r0 = _currentElement()
    //     0xdeb940: bl              #0x859318  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0xdeb944: cmp             w0, NULL
    // 0xdeb948: b.eq            #0xdeb9b8
    // 0xdeb94c: mov             x1, x0
    // 0xdeb950: r0 = findRenderObject()
    //     0xdeb950: bl              #0x8418fc  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0xdeb954: mov             x3, x0
    // 0xdeb958: stur            x3, [fp, #-8]
    // 0xdeb95c: cmp             w3, NULL
    // 0xdeb960: b.eq            #0xdeb9bc
    // 0xdeb964: mov             x0, x3
    // 0xdeb968: r2 = Null
    //     0xdeb968: mov             x2, NULL
    // 0xdeb96c: r1 = Null
    //     0xdeb96c: mov             x1, NULL
    // 0xdeb970: r4 = LoadClassIdInstr(r0)
    //     0xdeb970: ldur            x4, [x0, #-1]
    //     0xdeb974: ubfx            x4, x4, #0xc, #0x14
    // 0xdeb978: r17 = -4710
    //     0xdeb978: mov             x17, #-0x1266
    // 0xdeb97c: add             x4, x4, x17
    // 0xdeb980: cmp             x4, #0x109
    // 0xdeb984: b.ls            #0xdeb998
    // 0xdeb988: r8 = RenderBox
    //     0xdeb988: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xdeb98c: r3 = Null
    //     0xdeb98c: add             x3, PP, #0xab, lsl #12  ; [pp+0xab240] Null
    //     0xdeb990: ldr             x3, [x3, #0x240]
    // 0xdeb994: r0 = RenderBox()
    //     0xdeb994: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xdeb998: ldur            x1, [fp, #-8]
    // 0xdeb99c: r0 = size()
    //     0xdeb99c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xdeb9a0: LoadField: d0 = r0->field_f
    //     0xdeb9a0: ldur            d0, [x0, #0xf]
    // 0xdeb9a4: LeaveFrame
    //     0xdeb9a4: mov             SP, fp
    //     0xdeb9a8: ldp             fp, lr, [SP], #0x10
    // 0xdeb9ac: ret
    //     0xdeb9ac: ret             
    // 0xdeb9b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdeb9b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdeb9b4: b               #0xdeb934
    // 0xdeb9b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeb9b8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdeb9bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeb9bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _dismissUnderway(/* No info */) {
    // ** addr: 0xdeb9c0, size: 0x6c
    // 0xdeb9c0: EnterFrame
    //     0xdeb9c0: stp             fp, lr, [SP, #-0x10]!
    //     0xdeb9c4: mov             fp, SP
    // 0xdeb9c8: LoadField: r2 = r1->field_b
    //     0xdeb9c8: ldur            w2, [x1, #0xb]
    // 0xdeb9cc: DecompressPointer r2
    //     0xdeb9cc: add             x2, x2, HEAP, lsl #32
    // 0xdeb9d0: cmp             w2, NULL
    // 0xdeb9d4: b.eq            #0xdeba1c
    // 0xdeb9d8: LoadField: r1 = r2->field_b
    //     0xdeb9d8: ldur            w1, [x2, #0xb]
    // 0xdeb9dc: DecompressPointer r1
    //     0xdeb9dc: add             x1, x1, HEAP, lsl #32
    // 0xdeb9e0: cmp             w1, NULL
    // 0xdeb9e4: b.eq            #0xdeba20
    // 0xdeb9e8: LoadField: r2 = r1->field_43
    //     0xdeb9e8: ldur            w2, [x1, #0x43]
    // 0xdeb9ec: DecompressPointer r2
    //     0xdeb9ec: add             x2, x2, HEAP, lsl #32
    // 0xdeb9f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdeb9f4: cmp             w2, w16
    // 0xdeb9f8: b.eq            #0xdeba24
    // 0xdeb9fc: r16 = Instance_AnimationStatus
    //     0xdeb9fc: ldr             x16, [PP, #0x51c0]  ; [pp+0x51c0] Obj!AnimationStatus@12c6161
    // 0xdeba00: cmp             w2, w16
    // 0xdeba04: r16 = true
    //     0xdeba04: add             x16, NULL, #0x20  ; true
    // 0xdeba08: r17 = false
    //     0xdeba08: add             x17, NULL, #0x30  ; false
    // 0xdeba0c: csel            x0, x16, x17, eq
    // 0xdeba10: LeaveFrame
    //     0xdeba10: mov             SP, fp
    //     0xdeba14: ldp             fp, lr, [SP], #0x10
    // 0xdeba18: ret
    //     0xdeba18: ret             
    // 0xdeba1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeba1c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdeba20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeba20: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdeba24: r9 = _status
    //     0xdeba24: ldr             x9, [PP, #0x51e8]  ; [pp+0x51e8] Field <AnimationController._status@62066280>: late (offset: 0x44)
    // 0xdeba28: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdeba28: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdeba2c, size: 0x54
    // 0xdeba2c: EnterFrame
    //     0xdeba2c: stp             fp, lr, [SP, #-0x10]!
    //     0xdeba30: mov             fp, SP
    // 0xdeba34: ldr             x0, [fp, #0x10]
    // 0xdeba38: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdeba38: ldur            w1, [x0, #0x17]
    // 0xdeba3c: DecompressPointer r1
    //     0xdeba3c: add             x1, x1, HEAP, lsl #32
    // 0xdeba40: CheckStackOverflow
    //     0xdeba40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdeba44: cmp             SP, x16
    //     0xdeba48: b.ls            #0xdeba78
    // 0xdeba4c: LoadField: r0 = r1->field_f
    //     0xdeba4c: ldur            w0, [x1, #0xf]
    // 0xdeba50: DecompressPointer r0
    //     0xdeba50: add             x0, x0, HEAP, lsl #32
    // 0xdeba54: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdeba54: ldur            w1, [x0, #0x17]
    // 0xdeba58: DecompressPointer r1
    //     0xdeba58: add             x1, x1, HEAP, lsl #32
    // 0xdeba5c: r2 = Instance_WidgetState
    //     0xdeba5c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ad0] Obj!WidgetState@12c87a1
    //     0xdeba60: ldr             x2, [x2, #0xad0]
    // 0xdeba64: r0 = remove()
    //     0xdeba64: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0xdeba68: r0 = Null
    //     0xdeba68: mov             x0, NULL
    // 0xdeba6c: LeaveFrame
    //     0xdeba6c: mov             SP, fp
    //     0xdeba70: ldp             fp, lr, [SP], #0x10
    // 0xdeba74: ret
    //     0xdeba74: ret             
    // 0xdeba78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdeba78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdeba7c: b               #0xdeba4c
  }
  [closure] void _handleDragUpdate(dynamic, DragUpdateDetails) {
    // ** addr: 0xdeba80, size: 0x3c
    // 0xdeba80: EnterFrame
    //     0xdeba80: stp             fp, lr, [SP, #-0x10]!
    //     0xdeba84: mov             fp, SP
    // 0xdeba88: ldr             x0, [fp, #0x18]
    // 0xdeba8c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdeba8c: ldur            w1, [x0, #0x17]
    // 0xdeba90: DecompressPointer r1
    //     0xdeba90: add             x1, x1, HEAP, lsl #32
    // 0xdeba94: CheckStackOverflow
    //     0xdeba94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdeba98: cmp             SP, x16
    //     0xdeba9c: b.ls            #0xdebab4
    // 0xdebaa0: ldr             x2, [fp, #0x10]
    // 0xdebaa4: r0 = _handleDragUpdate()
    //     0xdebaa4: bl              #0xdebabc  ; [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragUpdate
    // 0xdebaa8: LeaveFrame
    //     0xdebaa8: mov             SP, fp
    //     0xdebaac: ldp             fp, lr, [SP], #0x10
    // 0xdebab0: ret
    //     0xdebab0: ret             
    // 0xdebab4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdebab4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdebab8: b               #0xdebaa0
  }
  _ _handleDragUpdate(/* No info */) {
    // ** addr: 0xdebabc, size: 0x130
    // 0xdebabc: EnterFrame
    //     0xdebabc: stp             fp, lr, [SP, #-0x10]!
    //     0xdebac0: mov             fp, SP
    // 0xdebac4: AllocStack(0x18)
    //     0xdebac4: sub             SP, SP, #0x18
    // 0xdebac8: CheckStackOverflow
    //     0xdebac8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdebacc: cmp             SP, x16
    //     0xdebad0: b.ls            #0xdebbb4
    // 0xdebad4: LoadField: r0 = r1->field_b
    //     0xdebad4: ldur            w0, [x1, #0xb]
    // 0xdebad8: DecompressPointer r0
    //     0xdebad8: add             x0, x0, HEAP, lsl #32
    // 0xdebadc: cmp             w0, NULL
    // 0xdebae0: b.eq            #0xdebbbc
    // 0xdebae4: LoadField: r3 = r0->field_b
    //     0xdebae4: ldur            w3, [x0, #0xb]
    // 0xdebae8: DecompressPointer r3
    //     0xdebae8: add             x3, x3, HEAP, lsl #32
    // 0xdebaec: stur            x3, [fp, #-0x18]
    // 0xdebaf0: cmp             w3, NULL
    // 0xdebaf4: b.eq            #0xdebbc0
    // 0xdebaf8: LoadField: r0 = r3->field_43
    //     0xdebaf8: ldur            w0, [x3, #0x43]
    // 0xdebafc: DecompressPointer r0
    //     0xdebafc: add             x0, x0, HEAP, lsl #32
    // 0xdebb00: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdebb04: cmp             w0, w16
    // 0xdebb08: b.eq            #0xdebbc4
    // 0xdebb0c: r16 = Instance_AnimationStatus
    //     0xdebb0c: ldr             x16, [PP, #0x51c0]  ; [pp+0x51c0] Obj!AnimationStatus@12c6161
    // 0xdebb10: cmp             w0, w16
    // 0xdebb14: b.ne            #0xdebb28
    // 0xdebb18: r0 = Null
    //     0xdebb18: mov             x0, NULL
    // 0xdebb1c: LeaveFrame
    //     0xdebb1c: mov             SP, fp
    //     0xdebb20: ldp             fp, lr, [SP], #0x10
    // 0xdebb24: ret
    //     0xdebb24: ret             
    // 0xdebb28: LoadField: r0 = r3->field_37
    //     0xdebb28: ldur            w0, [x3, #0x37]
    // 0xdebb2c: DecompressPointer r0
    //     0xdebb2c: add             x0, x0, HEAP, lsl #32
    // 0xdebb30: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdebb34: cmp             w0, w16
    // 0xdebb38: b.eq            #0xdebbcc
    // 0xdebb3c: stur            x0, [fp, #-0x10]
    // 0xdebb40: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xdebb40: ldur            w4, [x2, #0x17]
    // 0xdebb44: DecompressPointer r4
    //     0xdebb44: add             x4, x4, HEAP, lsl #32
    // 0xdebb48: stur            x4, [fp, #-8]
    // 0xdebb4c: cmp             w4, NULL
    // 0xdebb50: b.eq            #0xdebbd4
    // 0xdebb54: r0 = _childHeight()
    //     0xdebb54: bl              #0xdeb91c  ; [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_childHeight
    // 0xdebb58: ldur            x0, [fp, #-8]
    // 0xdebb5c: LoadField: d1 = r0->field_7
    //     0xdebb5c: ldur            d1, [x0, #7]
    // 0xdebb60: fdiv            d2, d1, d0
    // 0xdebb64: ldur            x0, [fp, #-0x10]
    // 0xdebb68: LoadField: d0 = r0->field_7
    //     0xdebb68: ldur            d0, [x0, #7]
    // 0xdebb6c: fsub            d1, d0, d2
    // 0xdebb70: r2 = inline_Allocate_Double()
    //     0xdebb70: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xdebb74: add             x2, x2, #0x10
    //     0xdebb78: cmp             x0, x2
    //     0xdebb7c: b.ls            #0xdebbd8
    //     0xdebb80: str             x2, [THR, #0x60]  ; THR::top
    //     0xdebb84: sub             x2, x2, #0xf
    //     0xdebb88: mov             x0, #0xe19c
    //     0xdebb8c: movk            x0, #3, lsl #16
    //     0xdebb90: stur            x0, [x2, #-1]
    // 0xdebb94: dmb             ishst
    // 0xdebb98: StoreField: r2->field_7 = d1
    //     0xdebb98: stur            d1, [x2, #7]
    // 0xdebb9c: ldur            x1, [fp, #-0x18]
    // 0xdebba0: r0 = value=()
    //     0xdebba0: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xdebba4: r0 = Null
    //     0xdebba4: mov             x0, NULL
    // 0xdebba8: LeaveFrame
    //     0xdebba8: mov             SP, fp
    //     0xdebbac: ldp             fp, lr, [SP], #0x10
    // 0xdebbb0: ret
    //     0xdebbb0: ret             
    // 0xdebbb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdebbb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdebbb8: b               #0xdebad4
    // 0xdebbbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdebbbc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdebbc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdebbc0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdebbc4: r9 = _status
    //     0xdebbc4: ldr             x9, [PP, #0x51e8]  ; [pp+0x51e8] Field <AnimationController._status@62066280>: late (offset: 0x44)
    // 0xdebbc8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdebbc8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdebbcc: r9 = _value
    //     0xdebbcc: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xdebbd0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdebbd0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdebbd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdebbd4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdebbd8: SaveReg d1
    //     0xdebbd8: str             q1, [SP, #-0x10]!
    // 0xdebbdc: r0 = AllocateDouble()
    //     0xdebbdc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdebbe0: mov             x2, x0
    // 0xdebbe4: RestoreReg d1
    //     0xdebbe4: ldr             q1, [SP], #0x10
    // 0xdebbe8: b               #0xdebb98
  }
  [closure] void _handleDragStart(dynamic, DragStartDetails) {
    // ** addr: 0xdebbec, size: 0x3c
    // 0xdebbec: EnterFrame
    //     0xdebbec: stp             fp, lr, [SP, #-0x10]!
    //     0xdebbf0: mov             fp, SP
    // 0xdebbf4: ldr             x0, [fp, #0x18]
    // 0xdebbf8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdebbf8: ldur            w1, [x0, #0x17]
    // 0xdebbfc: DecompressPointer r1
    //     0xdebbfc: add             x1, x1, HEAP, lsl #32
    // 0xdebc00: CheckStackOverflow
    //     0xdebc00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdebc04: cmp             SP, x16
    //     0xdebc08: b.ls            #0xdebc20
    // 0xdebc0c: ldr             x2, [fp, #0x10]
    // 0xdebc10: r0 = _handleDragStart()
    //     0xdebc10: bl              #0xdebc28  ; [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragStart
    // 0xdebc14: LeaveFrame
    //     0xdebc14: mov             SP, fp
    //     0xdebc18: ldp             fp, lr, [SP], #0x10
    // 0xdebc1c: ret
    //     0xdebc1c: ret             
    // 0xdebc20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdebc20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdebc24: b               #0xdebc0c
  }
  _ _handleDragStart(/* No info */) {
    // ** addr: 0xdebc28, size: 0xa4
    // 0xdebc28: EnterFrame
    //     0xdebc28: stp             fp, lr, [SP, #-0x10]!
    //     0xdebc2c: mov             fp, SP
    // 0xdebc30: AllocStack(0x20)
    //     0xdebc30: sub             SP, SP, #0x20
    // 0xdebc34: SetupParameters(_BottomSheetState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdebc34: stur            x1, [fp, #-8]
    //     0xdebc38: stur            x2, [fp, #-0x10]
    // 0xdebc3c: CheckStackOverflow
    //     0xdebc3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdebc40: cmp             SP, x16
    //     0xdebc44: b.ls            #0xdebcc0
    // 0xdebc48: r1 = 1
    //     0xdebc48: mov             x1, #1
    // 0xdebc4c: r0 = AllocateContext()
    //     0xdebc4c: bl              #0x13de838  ; AllocateContextStub
    // 0xdebc50: mov             x1, x0
    // 0xdebc54: ldur            x0, [fp, #-8]
    // 0xdebc58: StoreField: r1->field_f = r0
    //     0xdebc58: stur            w0, [x1, #0xf]
    // 0xdebc5c: mov             x2, x1
    // 0xdebc60: r1 = Function '<anonymous closure>':.
    //     0xdebc60: add             x1, PP, #0xab, lsl #12  ; [pp+0xab250] AnonymousClosure: (0xdebccc), in [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragStart (0xdebc28)
    //     0xdebc64: ldr             x1, [x1, #0x250]
    // 0xdebc68: r0 = AllocateClosure()
    //     0xdebc68: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdebc6c: ldur            x1, [fp, #-8]
    // 0xdebc70: mov             x2, x0
    // 0xdebc74: r0 = setState()
    //     0xdebc74: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdebc78: ldur            x0, [fp, #-8]
    // 0xdebc7c: LoadField: r1 = r0->field_b
    //     0xdebc7c: ldur            w1, [x0, #0xb]
    // 0xdebc80: DecompressPointer r1
    //     0xdebc80: add             x1, x1, HEAP, lsl #32
    // 0xdebc84: cmp             w1, NULL
    // 0xdebc88: b.eq            #0xdebcc8
    // 0xdebc8c: LoadField: r0 = r1->field_27
    //     0xdebc8c: ldur            w0, [x1, #0x27]
    // 0xdebc90: DecompressPointer r0
    //     0xdebc90: add             x0, x0, HEAP, lsl #32
    // 0xdebc94: cmp             w0, NULL
    // 0xdebc98: b.eq            #0xdebcb0
    // 0xdebc9c: ldur            x16, [fp, #-0x10]
    // 0xdebca0: stp             x16, x0, [SP]
    // 0xdebca4: ClosureCall
    //     0xdebca4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xdebca8: ldur            x2, [x0, #0x1f]
    //     0xdebcac: blr             x2
    // 0xdebcb0: r0 = Null
    //     0xdebcb0: mov             x0, NULL
    // 0xdebcb4: LeaveFrame
    //     0xdebcb4: mov             SP, fp
    //     0xdebcb8: ldp             fp, lr, [SP], #0x10
    // 0xdebcbc: ret
    //     0xdebcbc: ret             
    // 0xdebcc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdebcc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdebcc4: b               #0xdebc48
    // 0xdebcc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdebcc8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdebccc, size: 0x54
    // 0xdebccc: EnterFrame
    //     0xdebccc: stp             fp, lr, [SP, #-0x10]!
    //     0xdebcd0: mov             fp, SP
    // 0xdebcd4: ldr             x0, [fp, #0x10]
    // 0xdebcd8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdebcd8: ldur            w1, [x0, #0x17]
    // 0xdebcdc: DecompressPointer r1
    //     0xdebcdc: add             x1, x1, HEAP, lsl #32
    // 0xdebce0: CheckStackOverflow
    //     0xdebce0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdebce4: cmp             SP, x16
    //     0xdebce8: b.ls            #0xdebd18
    // 0xdebcec: LoadField: r0 = r1->field_f
    //     0xdebcec: ldur            w0, [x1, #0xf]
    // 0xdebcf0: DecompressPointer r0
    //     0xdebcf0: add             x0, x0, HEAP, lsl #32
    // 0xdebcf4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdebcf4: ldur            w1, [x0, #0x17]
    // 0xdebcf8: DecompressPointer r1
    //     0xdebcf8: add             x1, x1, HEAP, lsl #32
    // 0xdebcfc: r2 = Instance_WidgetState
    //     0xdebcfc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ad0] Obj!WidgetState@12c87a1
    //     0xdebd00: ldr             x2, [x2, #0xad0]
    // 0xdebd04: r0 = add()
    //     0xdebd04: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xdebd08: r0 = Null
    //     0xdebd08: mov             x0, NULL
    // 0xdebd0c: LeaveFrame
    //     0xdebd0c: mov             SP, fp
    //     0xdebd10: ldp             fp, lr, [SP], #0x10
    // 0xdebd14: ret
    //     0xdebd14: ret             
    // 0xdebd18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdebd18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdebd1c: b               #0xdebcec
  }
  [closure] void _handleDragHandleHover(dynamic, bool) {
    // ** addr: 0xdebd20, size: 0x3c
    // 0xdebd20: EnterFrame
    //     0xdebd20: stp             fp, lr, [SP, #-0x10]!
    //     0xdebd24: mov             fp, SP
    // 0xdebd28: ldr             x0, [fp, #0x18]
    // 0xdebd2c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdebd2c: ldur            w1, [x0, #0x17]
    // 0xdebd30: DecompressPointer r1
    //     0xdebd30: add             x1, x1, HEAP, lsl #32
    // 0xdebd34: CheckStackOverflow
    //     0xdebd34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdebd38: cmp             SP, x16
    //     0xdebd3c: b.ls            #0xdebd54
    // 0xdebd40: ldr             x2, [fp, #0x10]
    // 0xdebd44: r0 = _handleDragHandleHover()
    //     0xdebd44: bl              #0xdebd5c  ; [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragHandleHover
    // 0xdebd48: LeaveFrame
    //     0xdebd48: mov             SP, fp
    //     0xdebd4c: ldp             fp, lr, [SP], #0x10
    // 0xdebd50: ret
    //     0xdebd50: ret             
    // 0xdebd54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdebd54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdebd58: b               #0xdebd40
  }
  _ _handleDragHandleHover(/* No info */) {
    // ** addr: 0xdebd5c, size: 0x98
    // 0xdebd5c: EnterFrame
    //     0xdebd5c: stp             fp, lr, [SP, #-0x10]!
    //     0xdebd60: mov             fp, SP
    // 0xdebd64: AllocStack(0x18)
    //     0xdebd64: sub             SP, SP, #0x18
    // 0xdebd68: SetupParameters(_BottomSheetState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdebd68: stur            x1, [fp, #-8]
    //     0xdebd6c: stur            x2, [fp, #-0x10]
    // 0xdebd70: CheckStackOverflow
    //     0xdebd70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdebd74: cmp             SP, x16
    //     0xdebd78: b.ls            #0xdebdec
    // 0xdebd7c: r1 = 2
    //     0xdebd7c: mov             x1, #2
    // 0xdebd80: r0 = AllocateContext()
    //     0xdebd80: bl              #0x13de838  ; AllocateContextStub
    // 0xdebd84: mov             x3, x0
    // 0xdebd88: ldur            x0, [fp, #-8]
    // 0xdebd8c: stur            x3, [fp, #-0x18]
    // 0xdebd90: StoreField: r3->field_f = r0
    //     0xdebd90: stur            w0, [x3, #0xf]
    // 0xdebd94: ldur            x4, [fp, #-0x10]
    // 0xdebd98: StoreField: r3->field_13 = r4
    //     0xdebd98: stur            w4, [x3, #0x13]
    // 0xdebd9c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdebd9c: ldur            w1, [x0, #0x17]
    // 0xdebda0: DecompressPointer r1
    //     0xdebda0: add             x1, x1, HEAP, lsl #32
    // 0xdebda4: r2 = Instance_WidgetState
    //     0xdebda4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xdebda8: ldr             x2, [x2, #0xa50]
    // 0xdebdac: r0 = contains()
    //     0xdebdac: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xdebdb0: mov             x1, x0
    // 0xdebdb4: ldur            x0, [fp, #-0x10]
    // 0xdebdb8: cmp             w0, w1
    // 0xdebdbc: b.eq            #0xdebddc
    // 0xdebdc0: ldur            x2, [fp, #-0x18]
    // 0xdebdc4: r1 = Function '<anonymous closure>':.
    //     0xdebdc4: add             x1, PP, #0xab, lsl #12  ; [pp+0xab258] AnonymousClosure: (0xdebdf4), in [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragHandleHover (0xdebd5c)
    //     0xdebdc8: ldr             x1, [x1, #0x258]
    // 0xdebdcc: r0 = AllocateClosure()
    //     0xdebdcc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdebdd0: ldur            x1, [fp, #-8]
    // 0xdebdd4: mov             x2, x0
    // 0xdebdd8: r0 = setState()
    //     0xdebdd8: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdebddc: r0 = Null
    //     0xdebddc: mov             x0, NULL
    // 0xdebde0: LeaveFrame
    //     0xdebde0: mov             SP, fp
    //     0xdebde4: ldp             fp, lr, [SP], #0x10
    // 0xdebde8: ret
    //     0xdebde8: ret             
    // 0xdebdec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdebdec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdebdf0: b               #0xdebd7c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdebdf4, size: 0x80
    // 0xdebdf4: EnterFrame
    //     0xdebdf4: stp             fp, lr, [SP, #-0x10]!
    //     0xdebdf8: mov             fp, SP
    // 0xdebdfc: ldr             x0, [fp, #0x10]
    // 0xdebe00: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdebe00: ldur            w1, [x0, #0x17]
    // 0xdebe04: DecompressPointer r1
    //     0xdebe04: add             x1, x1, HEAP, lsl #32
    // 0xdebe08: CheckStackOverflow
    //     0xdebe08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdebe0c: cmp             SP, x16
    //     0xdebe10: b.ls            #0xdebe6c
    // 0xdebe14: LoadField: r0 = r1->field_13
    //     0xdebe14: ldur            w0, [x1, #0x13]
    // 0xdebe18: DecompressPointer r0
    //     0xdebe18: add             x0, x0, HEAP, lsl #32
    // 0xdebe1c: tbnz            w0, #4, #0xdebe40
    // 0xdebe20: LoadField: r0 = r1->field_f
    //     0xdebe20: ldur            w0, [x1, #0xf]
    // 0xdebe24: DecompressPointer r0
    //     0xdebe24: add             x0, x0, HEAP, lsl #32
    // 0xdebe28: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdebe28: ldur            w1, [x0, #0x17]
    // 0xdebe2c: DecompressPointer r1
    //     0xdebe2c: add             x1, x1, HEAP, lsl #32
    // 0xdebe30: r2 = Instance_WidgetState
    //     0xdebe30: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xdebe34: ldr             x2, [x2, #0xa50]
    // 0xdebe38: r0 = add()
    //     0xdebe38: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xdebe3c: b               #0xdebe5c
    // 0xdebe40: LoadField: r0 = r1->field_f
    //     0xdebe40: ldur            w0, [x1, #0xf]
    // 0xdebe44: DecompressPointer r0
    //     0xdebe44: add             x0, x0, HEAP, lsl #32
    // 0xdebe48: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdebe48: ldur            w1, [x0, #0x17]
    // 0xdebe4c: DecompressPointer r1
    //     0xdebe4c: add             x1, x1, HEAP, lsl #32
    // 0xdebe50: r2 = Instance_WidgetState
    //     0xdebe50: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xdebe54: ldr             x2, [x2, #0xa50]
    // 0xdebe58: r0 = remove()
    //     0xdebe58: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0xdebe5c: r0 = Null
    //     0xdebe5c: mov             x0, NULL
    // 0xdebe60: LeaveFrame
    //     0xdebe60: mov             SP, fp
    //     0xdebe64: ldp             fp, lr, [SP], #0x10
    // 0xdebe68: ret
    //     0xdebe68: ret             
    // 0xdebe6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdebe6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdebe70: b               #0xdebe14
  }
  _ _BottomSheetState(/* No info */) {
    // ** addr: 0xfa0c5c, size: 0xa8
    // 0xfa0c5c: EnterFrame
    //     0xfa0c5c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0c60: mov             fp, SP
    // 0xfa0c64: AllocStack(0x8)
    //     0xfa0c64: sub             SP, SP, #8
    // 0xfa0c68: SetupParameters(_BottomSheetState this /* r1 => r0, fp-0x8 */)
    //     0xfa0c68: mov             x0, x1
    //     0xfa0c6c: stur            x1, [fp, #-8]
    // 0xfa0c70: r1 = <State<StatefulWidget>>
    //     0xfa0c70: ldr             x1, [PP, #0x4df8]  ; [pp+0x4df8] TypeArguments: <State<StatefulWidget>>
    // 0xfa0c74: r0 = LabeledGlobalKey()
    //     0xfa0c74: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa0c78: mov             x1, x0
    // 0xfa0c7c: r0 = "BottomSheet child"
    //     0xfa0c7c: add             x0, PP, #0xa0, lsl #12  ; [pp+0xa0f38] "BottomSheet child"
    //     0xfa0c80: ldr             x0, [x0, #0xf38]
    // 0xfa0c84: StoreField: r1->field_b = r0
    //     0xfa0c84: stur            w0, [x1, #0xb]
    // 0xfa0c88: mov             x0, x1
    // 0xfa0c8c: ldur            x2, [fp, #-8]
    // 0xfa0c90: StoreField: r2->field_13 = r0
    //     0xfa0c90: stur            w0, [x2, #0x13]
    //     0xfa0c94: ldurb           w16, [x2, #-1]
    //     0xfa0c98: ldurb           w17, [x0, #-1]
    //     0xfa0c9c: and             x16, x17, x16, lsr #2
    //     0xfa0ca0: tst             x16, HEAP, lsr #32
    //     0xfa0ca4: b.eq            #0xfa0cac
    //     0xfa0ca8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfa0cac: r1 = <WidgetState>
    //     0xfa0cac: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a10] TypeArguments: <WidgetState>
    //     0xfa0cb0: ldr             x1, [x1, #0xa10]
    // 0xfa0cb4: r0 = _Set()
    //     0xfa0cb4: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xfa0cb8: r1 = _Uint32List
    //     0xfa0cb8: ldr             x1, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0xfa0cbc: StoreField: r0->field_1b = r1
    //     0xfa0cbc: stur            w1, [x0, #0x1b]
    // 0xfa0cc0: StoreField: r0->field_b = rZR
    //     0xfa0cc0: stur            wzr, [x0, #0xb]
    // 0xfa0cc4: r1 = const []
    //     0xfa0cc4: ldr             x1, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0xfa0cc8: StoreField: r0->field_f = r1
    //     0xfa0cc8: stur            w1, [x0, #0xf]
    // 0xfa0ccc: StoreField: r0->field_13 = rZR
    //     0xfa0ccc: stur            wzr, [x0, #0x13]
    // 0xfa0cd0: ArrayStore: r0[0] = rZR  ; List_4
    //     0xfa0cd0: stur            wzr, [x0, #0x17]
    // 0xfa0cd4: ldur            x1, [fp, #-8]
    // 0xfa0cd8: ArrayStore: r1[0] = r0  ; List_4
    //     0xfa0cd8: stur            w0, [x1, #0x17]
    //     0xfa0cdc: ldurb           w16, [x1, #-1]
    //     0xfa0ce0: ldurb           w17, [x0, #-1]
    //     0xfa0ce4: and             x16, x17, x16, lsr #2
    //     0xfa0ce8: tst             x16, HEAP, lsr #32
    //     0xfa0cec: b.eq            #0xfa0cf4
    //     0xfa0cf0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa0cf4: r0 = Null
    //     0xfa0cf4: mov             x0, NULL
    // 0xfa0cf8: LeaveFrame
    //     0xfa0cf8: mov             SP, fp
    //     0xfa0cfc: ldp             fp, lr, [SP], #0x10
    // 0xfa0d00: ret
    //     0xfa0d00: ret             
  }
}

// class id: 6177, size: 0x1c, field offset: 0xc
//   const constructor, 
class _BottomSheetGestureDetector extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfb310c, size: 0xf8
    // 0xfb310c: EnterFrame
    //     0xfb310c: stp             fp, lr, [SP, #-0x10]!
    //     0xfb3110: mov             fp, SP
    // 0xfb3114: AllocStack(0x30)
    //     0xfb3114: sub             SP, SP, #0x30
    // 0xfb3118: SetupParameters(_BottomSheetGestureDetector this /* r1 => r1, fp-0x8 */)
    //     0xfb3118: stur            x1, [fp, #-8]
    // 0xfb311c: CheckStackOverflow
    //     0xfb311c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb3120: cmp             SP, x16
    //     0xfb3124: b.ls            #0xfb31fc
    // 0xfb3128: r1 = 1
    //     0xfb3128: mov             x1, #1
    // 0xfb312c: r0 = AllocateContext()
    //     0xfb312c: bl              #0x13de838  ; AllocateContextStub
    // 0xfb3130: mov             x3, x0
    // 0xfb3134: ldur            x0, [fp, #-8]
    // 0xfb3138: stur            x3, [fp, #-0x10]
    // 0xfb313c: StoreField: r3->field_f = r0
    //     0xfb313c: stur            w0, [x3, #0xf]
    // 0xfb3140: r1 = Null
    //     0xfb3140: mov             x1, NULL
    // 0xfb3144: r2 = 4
    //     0xfb3144: mov             x2, #4
    // 0xfb3148: r0 = AllocateArray()
    //     0xfb3148: bl              #0x13df928  ; AllocateArrayStub
    // 0xfb314c: stur            x0, [fp, #-0x18]
    // 0xfb3150: r16 = VerticalDragGestureRecognizer
    //     0xfb3150: add             x16, PP, #0x84, lsl #12  ; [pp+0x84dc8] Type: VerticalDragGestureRecognizer
    //     0xfb3154: ldr             x16, [x16, #0xdc8]
    // 0xfb3158: StoreField: r0->field_f = r16
    //     0xfb3158: stur            w16, [x0, #0xf]
    // 0xfb315c: r1 = <VerticalDragGestureRecognizer>
    //     0xfb315c: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cd50] TypeArguments: <VerticalDragGestureRecognizer>
    //     0xfb3160: ldr             x1, [x1, #0xd50]
    // 0xfb3164: r0 = GestureRecognizerFactoryWithHandlers()
    //     0xfb3164: bl              #0xd37854  ; AllocateGestureRecognizerFactoryWithHandlersStub -> GestureRecognizerFactoryWithHandlers<X0 bound GestureRecognizer> (size=0x14)
    // 0xfb3168: r1 = Function '<anonymous closure>':.
    //     0xfb3168: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb0890] AnonymousClosure: (0xfb32a8), in [package:simaster_ugm/app/modules/lapor/views/lapor_view.dart] LaporView::build (0x10140e4)
    //     0xfb316c: ldr             x1, [x1, #0x890]
    // 0xfb3170: r2 = Null
    //     0xfb3170: mov             x2, NULL
    // 0xfb3174: stur            x0, [fp, #-0x20]
    // 0xfb3178: r0 = AllocateClosure()
    //     0xfb3178: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfb317c: mov             x1, x0
    // 0xfb3180: ldur            x0, [fp, #-0x20]
    // 0xfb3184: StoreField: r0->field_b = r1
    //     0xfb3184: stur            w1, [x0, #0xb]
    // 0xfb3188: ldur            x2, [fp, #-0x10]
    // 0xfb318c: r1 = Function '<anonymous closure>':.
    //     0xfb318c: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb0898] AnonymousClosure: (0xfb3204), in [package:flutter/src/material/bottom_sheet.dart] _BottomSheetGestureDetector::build (0xfb310c)
    //     0xfb3190: ldr             x1, [x1, #0x898]
    // 0xfb3194: r0 = AllocateClosure()
    //     0xfb3194: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfb3198: mov             x1, x0
    // 0xfb319c: ldur            x0, [fp, #-0x20]
    // 0xfb31a0: StoreField: r0->field_f = r1
    //     0xfb31a0: stur            w1, [x0, #0xf]
    // 0xfb31a4: ldur            x1, [fp, #-0x18]
    // 0xfb31a8: StoreField: r1->field_13 = r0
    //     0xfb31a8: stur            w0, [x1, #0x13]
    // 0xfb31ac: r16 = <Type, GestureRecognizerFactory<GestureRecognizer>>
    //     0xfb31ac: add             x16, PP, #0x15, lsl #12  ; [pp+0x15500] TypeArguments: <Type, GestureRecognizerFactory<GestureRecognizer>>
    //     0xfb31b0: ldr             x16, [x16, #0x500]
    // 0xfb31b4: stp             x1, x16, [SP]
    // 0xfb31b8: r0 = Map._fromLiteral()
    //     0xfb31b8: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xfb31bc: mov             x1, x0
    // 0xfb31c0: ldur            x0, [fp, #-8]
    // 0xfb31c4: stur            x1, [fp, #-0x18]
    // 0xfb31c8: LoadField: r2 = r0->field_b
    //     0xfb31c8: ldur            w2, [x0, #0xb]
    // 0xfb31cc: DecompressPointer r2
    //     0xfb31cc: add             x2, x2, HEAP, lsl #32
    // 0xfb31d0: stur            x2, [fp, #-0x10]
    // 0xfb31d4: r0 = RawGestureDetector()
    //     0xfb31d4: bl              #0xd37630  ; AllocateRawGestureDetectorStub -> RawGestureDetector (size=0x20)
    // 0xfb31d8: ldur            x1, [fp, #-0x10]
    // 0xfb31dc: StoreField: r0->field_b = r1
    //     0xfb31dc: stur            w1, [x0, #0xb]
    // 0xfb31e0: ldur            x1, [fp, #-0x18]
    // 0xfb31e4: StoreField: r0->field_f = r1
    //     0xfb31e4: stur            w1, [x0, #0xf]
    // 0xfb31e8: r1 = true
    //     0xfb31e8: add             x1, NULL, #0x20  ; true
    // 0xfb31ec: ArrayStore: r0[0] = r1  ; List_4
    //     0xfb31ec: stur            w1, [x0, #0x17]
    // 0xfb31f0: LeaveFrame
    //     0xfb31f0: mov             SP, fp
    //     0xfb31f4: ldp             fp, lr, [SP], #0x10
    // 0xfb31f8: ret
    //     0xfb31f8: ret             
    // 0xfb31fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb31fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb3200: b               #0xfb3128
  }
  [closure] void <anonymous closure>(dynamic, VerticalDragGestureRecognizer) {
    // ** addr: 0xfb3204, size: 0xa4
    // 0xfb3204: EnterFrame
    //     0xfb3204: stp             fp, lr, [SP, #-0x10]!
    //     0xfb3208: mov             fp, SP
    // 0xfb320c: r1 = true
    //     0xfb320c: add             x1, NULL, #0x20  ; true
    // 0xfb3210: ldr             x2, [fp, #0x18]
    // 0xfb3214: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xfb3214: ldur            w3, [x2, #0x17]
    // 0xfb3218: DecompressPointer r3
    //     0xfb3218: add             x3, x3, HEAP, lsl #32
    // 0xfb321c: LoadField: r2 = r3->field_f
    //     0xfb321c: ldur            w2, [x3, #0xf]
    // 0xfb3220: DecompressPointer r2
    //     0xfb3220: add             x2, x2, HEAP, lsl #32
    // 0xfb3224: LoadField: r0 = r2->field_f
    //     0xfb3224: ldur            w0, [x2, #0xf]
    // 0xfb3228: DecompressPointer r0
    //     0xfb3228: add             x0, x0, HEAP, lsl #32
    // 0xfb322c: ldr             x3, [fp, #0x10]
    // 0xfb3230: StoreField: r3->field_2f = r0
    //     0xfb3230: stur            w0, [x3, #0x2f]
    //     0xfb3234: ldurb           w16, [x3, #-1]
    //     0xfb3238: ldurb           w17, [x0, #-1]
    //     0xfb323c: and             x16, x17, x16, lsr #2
    //     0xfb3240: tst             x16, HEAP, lsr #32
    //     0xfb3244: b.eq            #0xfb324c
    //     0xfb3248: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xfb324c: LoadField: r0 = r2->field_13
    //     0xfb324c: ldur            w0, [x2, #0x13]
    // 0xfb3250: DecompressPointer r0
    //     0xfb3250: add             x0, x0, HEAP, lsl #32
    // 0xfb3254: StoreField: r3->field_33 = r0
    //     0xfb3254: stur            w0, [x3, #0x33]
    //     0xfb3258: ldurb           w16, [x3, #-1]
    //     0xfb325c: ldurb           w17, [x0, #-1]
    //     0xfb3260: and             x16, x17, x16, lsr #2
    //     0xfb3264: tst             x16, HEAP, lsr #32
    //     0xfb3268: b.eq            #0xfb3270
    //     0xfb326c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xfb3270: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xfb3270: ldur            w0, [x2, #0x17]
    // 0xfb3274: DecompressPointer r0
    //     0xfb3274: add             x0, x0, HEAP, lsl #32
    // 0xfb3278: StoreField: r3->field_37 = r0
    //     0xfb3278: stur            w0, [x3, #0x37]
    //     0xfb327c: ldurb           w16, [x3, #-1]
    //     0xfb3280: ldurb           w17, [x0, #-1]
    //     0xfb3284: and             x16, x17, x16, lsr #2
    //     0xfb3288: tst             x16, HEAP, lsr #32
    //     0xfb328c: b.eq            #0xfb3294
    //     0xfb3290: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xfb3294: StoreField: r3->field_4b = r1
    //     0xfb3294: stur            w1, [x3, #0x4b]
    // 0xfb3298: r0 = Null
    //     0xfb3298: mov             x0, NULL
    // 0xfb329c: LeaveFrame
    //     0xfb329c: mov             SP, fp
    //     0xfb32a0: ldp             fp, lr, [SP], #0x10
    // 0xfb32a4: ret
    //     0xfb32a4: ret             
  }
}

// class id: 6178, size: 0x20, field offset: 0xc
//   const constructor, 
class _DragHandle extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfb2c24, size: 0x430
    // 0xfb2c24: EnterFrame
    //     0xfb2c24: stp             fp, lr, [SP, #-0x10]!
    //     0xfb2c28: mov             fp, SP
    // 0xfb2c2c: AllocStack(0x80)
    //     0xfb2c2c: sub             SP, SP, #0x80
    // 0xfb2c30: SetupParameters(_DragHandle this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xfb2c30: mov             x0, x1
    //     0xfb2c34: stur            x1, [fp, #-8]
    //     0xfb2c38: mov             x1, x2
    //     0xfb2c3c: stur            x2, [fp, #-0x10]
    // 0xfb2c40: CheckStackOverflow
    //     0xfb2c40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb2c44: cmp             SP, x16
    //     0xfb2c48: b.ls            #0xfb2fe8
    // 0xfb2c4c: r1 = 1
    //     0xfb2c4c: mov             x1, #1
    // 0xfb2c50: r0 = AllocateContext()
    //     0xfb2c50: bl              #0x13de838  ; AllocateContextStub
    // 0xfb2c54: mov             x2, x0
    // 0xfb2c58: ldur            x0, [fp, #-8]
    // 0xfb2c5c: stur            x2, [fp, #-0x18]
    // 0xfb2c60: StoreField: r2->field_f = r0
    //     0xfb2c60: stur            w0, [x2, #0xf]
    // 0xfb2c64: ldur            x1, [fp, #-0x10]
    // 0xfb2c68: r0 = of()
    //     0xfb2c68: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb2c6c: r0 = _BottomSheetDefaultsM3()
    //     0xfb2c6c: bl              #0xdeb54c  ; Allocate_BottomSheetDefaultsM3Stub -> _BottomSheetDefaultsM3 (size=0x44)
    // 0xfb2c70: mov             x2, x0
    // 0xfb2c74: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb2c78: stur            x2, [fp, #-0x20]
    // 0xfb2c7c: StoreField: r2->field_3f = r0
    //     0xfb2c7c: stur            w0, [x2, #0x3f]
    // 0xfb2c80: ldur            x1, [fp, #-0x10]
    // 0xfb2c84: StoreField: r2->field_3b = r1
    //     0xfb2c84: stur            w1, [x2, #0x3b]
    // 0xfb2c88: r0 = 1.000000
    //     0xfb2c88: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xfb2c8c: StoreField: r2->field_f = r0
    //     0xfb2c8c: stur            w0, [x2, #0xf]
    // 0xfb2c90: StoreField: r2->field_1f = r0
    //     0xfb2c90: stur            w0, [x2, #0x1f]
    // 0xfb2c94: r0 = Instance_RoundedRectangleBorder
    //     0xfb2c94: add             x0, PP, #0x95, lsl #12  ; [pp+0x95e68] Obj!RoundedRectangleBorder@129ec71
    //     0xfb2c98: ldr             x0, [x0, #0xe68]
    // 0xfb2c9c: StoreField: r2->field_23 = r0
    //     0xfb2c9c: stur            w0, [x2, #0x23]
    // 0xfb2ca0: r0 = Instance_BoxConstraints
    //     0xfb2ca0: add             x0, PP, #0x26, lsl #12  ; [pp+0x26560] Obj!BoxConstraints@129c321
    //     0xfb2ca4: ldr             x0, [x0, #0x560]
    // 0xfb2ca8: StoreField: r2->field_37 = r0
    //     0xfb2ca8: stur            w0, [x2, #0x37]
    // 0xfb2cac: r0 = of()
    //     0xfb2cac: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xfb2cb0: r1 = LoadClassIdInstr(r0)
    //     0xfb2cb0: ldur            x1, [x0, #-1]
    //     0xfb2cb4: ubfx            x1, x1, #0xc, #0x14
    // 0xfb2cb8: mov             x16, x0
    // 0xfb2cbc: mov             x0, x1
    // 0xfb2cc0: mov             x1, x16
    // 0xfb2cc4: r0 = GDT[cid_x0 + 0x173c8]()
    //     0xfb2cc4: mov             x17, #0x73c8
    //     0xfb2cc8: movk            x17, #1, lsl #16
    //     0xfb2ccc: add             lr, x0, x17
    //     0xfb2cd0: ldr             lr, [x21, lr, lsl #3]
    //     0xfb2cd4: blr             lr
    // 0xfb2cd8: mov             x1, x0
    // 0xfb2cdc: ldur            x0, [fp, #-8]
    // 0xfb2ce0: stur            x1, [fp, #-0x28]
    // 0xfb2ce4: LoadField: r2 = r0->field_b
    //     0xfb2ce4: ldur            w2, [x0, #0xb]
    // 0xfb2ce8: DecompressPointer r2
    //     0xfb2ce8: add             x2, x2, HEAP, lsl #32
    // 0xfb2cec: stur            x2, [fp, #-0x10]
    // 0xfb2cf0: r3 = Instance_Size
    //     0xfb2cf0: add             x3, PP, #0x26, lsl #12  ; [pp+0x26558] Obj!Size@12a7871
    //     0xfb2cf4: ldr             x3, [x3, #0x558]
    // 0xfb2cf8: LoadField: d0 = r3->field_7
    //     0xfb2cf8: ldur            d0, [x3, #7]
    // 0xfb2cfc: stur            d0, [fp, #-0x58]
    // 0xfb2d00: d1 = 48.000000
    //     0xfb2d00: ldr             d1, [PP, #0x5650]  ; [pp+0x5650] IMM: double(48) from 0x4048000000000000
    // 0xfb2d04: fmax            v2.2d, v0.2d, v1.2d
    // 0xfb2d08: stur            d2, [fp, #-0x50]
    // 0xfb2d0c: LoadField: d3 = r3->field_f
    //     0xfb2d0c: ldur            d3, [x3, #0xf]
    // 0xfb2d10: stur            d3, [fp, #-0x48]
    // 0xfb2d14: fmax            v4.2d, v3.2d, v1.2d
    // 0xfb2d18: stur            d4, [fp, #-0x40]
    // 0xfb2d1c: r0 = Radius()
    //     0xfb2d1c: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xfb2d20: d0 = 2.000000
    //     0xfb2d20: fmov            d0, #2.00000000
    // 0xfb2d24: stur            x0, [fp, #-0x30]
    // 0xfb2d28: StoreField: r0->field_7 = d0
    //     0xfb2d28: stur            d0, [x0, #7]
    // 0xfb2d2c: StoreField: r0->field_f = d0
    //     0xfb2d2c: stur            d0, [x0, #0xf]
    // 0xfb2d30: r0 = BorderRadius()
    //     0xfb2d30: bl              #0x8a73c8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xfb2d34: mov             x1, x0
    // 0xfb2d38: ldur            x0, [fp, #-0x30]
    // 0xfb2d3c: stur            x1, [fp, #-0x38]
    // 0xfb2d40: StoreField: r1->field_7 = r0
    //     0xfb2d40: stur            w0, [x1, #7]
    // 0xfb2d44: StoreField: r1->field_b = r0
    //     0xfb2d44: stur            w0, [x1, #0xb]
    // 0xfb2d48: StoreField: r1->field_f = r0
    //     0xfb2d48: stur            w0, [x1, #0xf]
    // 0xfb2d4c: StoreField: r1->field_13 = r0
    //     0xfb2d4c: stur            w0, [x1, #0x13]
    // 0xfb2d50: ldur            x0, [fp, #-8]
    // 0xfb2d54: LoadField: r2 = r0->field_13
    //     0xfb2d54: ldur            w2, [x0, #0x13]
    // 0xfb2d58: DecompressPointer r2
    //     0xfb2d58: add             x2, x2, HEAP, lsl #32
    // 0xfb2d5c: stur            x2, [fp, #-0x30]
    // 0xfb2d60: r16 = <Color?>
    //     0xfb2d60: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xfb2d64: ldr             x16, [x16, #0xa40]
    // 0xfb2d68: stp             NULL, x16, [SP, #8]
    // 0xfb2d6c: str             x2, [SP]
    // 0xfb2d70: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xfb2d70: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xfb2d74: r0 = resolveAs()
    //     0xfb2d74: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xfb2d78: r16 = <Color?>
    //     0xfb2d78: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xfb2d7c: ldr             x16, [x16, #0xa40]
    // 0xfb2d80: stp             NULL, x16, [SP, #8]
    // 0xfb2d84: ldur            x16, [fp, #-0x30]
    // 0xfb2d88: str             x16, [SP]
    // 0xfb2d8c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xfb2d8c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xfb2d90: r0 = resolveAs()
    //     0xfb2d90: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xfb2d94: ldur            x1, [fp, #-0x20]
    // 0xfb2d98: LoadField: r0 = r1->field_3f
    //     0xfb2d98: ldur            w0, [x1, #0x3f]
    // 0xfb2d9c: DecompressPointer r0
    //     0xfb2d9c: add             x0, x0, HEAP, lsl #32
    // 0xfb2da0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb2da4: cmp             w0, w16
    // 0xfb2da8: b.ne            #0xfb2db8
    // 0xfb2dac: r2 = _colors
    //     0xfb2dac: add             x2, PP, #0x26, lsl #12  ; [pp+0x26550] Field <_BottomSheetDefaultsM3@726001611._colors@726001611>: late final (offset: 0x40)
    //     0xfb2db0: ldr             x2, [x2, #0x550]
    // 0xfb2db4: r0 = InitLateFinalInstanceField()
    //     0xfb2db4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfb2db8: LoadField: r1 = r0->field_a3
    //     0xfb2db8: ldur            w1, [x0, #0xa3]
    // 0xfb2dbc: DecompressPointer r1
    //     0xfb2dbc: add             x1, x1, HEAP, lsl #32
    // 0xfb2dc0: cmp             w1, NULL
    // 0xfb2dc4: b.ne            #0xfb2dd0
    // 0xfb2dc8: LoadField: r1 = r0->field_7f
    //     0xfb2dc8: ldur            w1, [x0, #0x7f]
    // 0xfb2dcc: DecompressPointer r1
    //     0xfb2dcc: add             x1, x1, HEAP, lsl #32
    // 0xfb2dd0: ldur            x0, [fp, #-0x38]
    // 0xfb2dd4: ldur            d1, [fp, #-0x50]
    // 0xfb2dd8: ldur            d3, [fp, #-0x40]
    // 0xfb2ddc: ldur            d0, [fp, #-0x58]
    // 0xfb2de0: ldur            d2, [fp, #-0x48]
    // 0xfb2de4: stur            x1, [fp, #-8]
    // 0xfb2de8: r0 = BoxDecoration()
    //     0xfb2de8: bl              #0x8a721c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xfb2dec: mov             x1, x0
    // 0xfb2df0: ldur            x0, [fp, #-8]
    // 0xfb2df4: stur            x1, [fp, #-0x30]
    // 0xfb2df8: StoreField: r1->field_7 = r0
    //     0xfb2df8: stur            w0, [x1, #7]
    // 0xfb2dfc: ldur            x0, [fp, #-0x38]
    // 0xfb2e00: StoreField: r1->field_13 = r0
    //     0xfb2e00: stur            w0, [x1, #0x13]
    // 0xfb2e04: r0 = Instance_BoxShape
    //     0xfb2e04: add             x0, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xfb2e08: ldr             x0, [x0, #0x1f8]
    // 0xfb2e0c: StoreField: r1->field_23 = r0
    //     0xfb2e0c: stur            w0, [x1, #0x23]
    // 0xfb2e10: ldur            d0, [fp, #-0x48]
    // 0xfb2e14: r0 = inline_Allocate_Double()
    //     0xfb2e14: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xfb2e18: add             x0, x0, #0x10
    //     0xfb2e1c: cmp             x2, x0
    //     0xfb2e20: b.ls            #0xfb2ff0
    //     0xfb2e24: str             x0, [THR, #0x60]  ; THR::top
    //     0xfb2e28: sub             x0, x0, #0xf
    //     0xfb2e2c: mov             x2, #0xe19c
    //     0xfb2e30: movk            x2, #3, lsl #16
    //     0xfb2e34: stur            x2, [x0, #-1]
    // 0xfb2e38: dmb             ishst
    // 0xfb2e3c: StoreField: r0->field_7 = d0
    //     0xfb2e3c: stur            d0, [x0, #7]
    // 0xfb2e40: ldur            d0, [fp, #-0x58]
    // 0xfb2e44: stur            x0, [fp, #-0x20]
    // 0xfb2e48: r2 = inline_Allocate_Double()
    //     0xfb2e48: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xfb2e4c: add             x2, x2, #0x10
    //     0xfb2e50: cmp             x3, x2
    //     0xfb2e54: b.ls            #0xfb3008
    //     0xfb2e58: str             x2, [THR, #0x60]  ; THR::top
    //     0xfb2e5c: sub             x2, x2, #0xf
    //     0xfb2e60: mov             x3, #0xe19c
    //     0xfb2e64: movk            x3, #3, lsl #16
    //     0xfb2e68: stur            x3, [x2, #-1]
    // 0xfb2e6c: dmb             ishst
    // 0xfb2e70: StoreField: r2->field_7 = d0
    //     0xfb2e70: stur            d0, [x2, #7]
    // 0xfb2e74: stur            x2, [fp, #-8]
    // 0xfb2e78: r0 = Container()
    //     0xfb2e78: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xfb2e7c: stur            x0, [fp, #-0x38]
    // 0xfb2e80: ldur            x16, [fp, #-0x20]
    // 0xfb2e84: ldur            lr, [fp, #-8]
    // 0xfb2e88: stp             lr, x16, [SP, #8]
    // 0xfb2e8c: ldur            x16, [fp, #-0x30]
    // 0xfb2e90: str             x16, [SP]
    // 0xfb2e94: mov             x1, x0
    // 0xfb2e98: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x1, width, 0x2, null]
    //     0xfb2e98: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1e1a8] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0xfb2e9c: ldr             x4, [x4, #0x1a8]
    // 0xfb2ea0: r0 = Container()
    //     0xfb2ea0: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xfb2ea4: r0 = Center()
    //     0xfb2ea4: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xfb2ea8: mov             x1, x0
    // 0xfb2eac: r0 = Instance_Alignment
    //     0xfb2eac: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfb2eb0: ldr             x0, [x0, #0xb80]
    // 0xfb2eb4: stur            x1, [fp, #-0x20]
    // 0xfb2eb8: StoreField: r1->field_f = r0
    //     0xfb2eb8: stur            w0, [x1, #0xf]
    // 0xfb2ebc: ldur            x0, [fp, #-0x38]
    // 0xfb2ec0: StoreField: r1->field_b = r0
    //     0xfb2ec0: stur            w0, [x1, #0xb]
    // 0xfb2ec4: ldur            d0, [fp, #-0x50]
    // 0xfb2ec8: r0 = inline_Allocate_Double()
    //     0xfb2ec8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xfb2ecc: add             x0, x0, #0x10
    //     0xfb2ed0: cmp             x2, x0
    //     0xfb2ed4: b.ls            #0xfb3024
    //     0xfb2ed8: str             x0, [THR, #0x60]  ; THR::top
    //     0xfb2edc: sub             x0, x0, #0xf
    //     0xfb2ee0: mov             x2, #0xe19c
    //     0xfb2ee4: movk            x2, #3, lsl #16
    //     0xfb2ee8: stur            x2, [x0, #-1]
    // 0xfb2eec: dmb             ishst
    // 0xfb2ef0: StoreField: r0->field_7 = d0
    //     0xfb2ef0: stur            d0, [x0, #7]
    // 0xfb2ef4: stur            x0, [fp, #-8]
    // 0xfb2ef8: r0 = SizedBox()
    //     0xfb2ef8: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xfb2efc: mov             x1, x0
    // 0xfb2f00: ldur            x0, [fp, #-8]
    // 0xfb2f04: stur            x1, [fp, #-0x30]
    // 0xfb2f08: StoreField: r1->field_f = r0
    //     0xfb2f08: stur            w0, [x1, #0xf]
    // 0xfb2f0c: ldur            d0, [fp, #-0x40]
    // 0xfb2f10: r0 = inline_Allocate_Double()
    //     0xfb2f10: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xfb2f14: add             x0, x0, #0x10
    //     0xfb2f18: cmp             x2, x0
    //     0xfb2f1c: b.ls            #0xfb303c
    //     0xfb2f20: str             x0, [THR, #0x60]  ; THR::top
    //     0xfb2f24: sub             x0, x0, #0xf
    //     0xfb2f28: mov             x2, #0xe19c
    //     0xfb2f2c: movk            x2, #3, lsl #16
    //     0xfb2f30: stur            x2, [x0, #-1]
    // 0xfb2f34: dmb             ishst
    // 0xfb2f38: StoreField: r0->field_7 = d0
    //     0xfb2f38: stur            d0, [x0, #7]
    // 0xfb2f3c: StoreField: r1->field_13 = r0
    //     0xfb2f3c: stur            w0, [x1, #0x13]
    // 0xfb2f40: ldur            x0, [fp, #-0x20]
    // 0xfb2f44: StoreField: r1->field_b = r0
    //     0xfb2f44: stur            w0, [x1, #0xb]
    // 0xfb2f48: r0 = Semantics()
    //     0xfb2f48: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xfb2f4c: stur            x0, [fp, #-8]
    // 0xfb2f50: ldur            x16, [fp, #-0x28]
    // 0xfb2f54: r30 = true
    //     0xfb2f54: add             lr, NULL, #0x20  ; true
    // 0xfb2f58: stp             lr, x16, [SP, #0x18]
    // 0xfb2f5c: r16 = true
    //     0xfb2f5c: add             x16, NULL, #0x20  ; true
    // 0xfb2f60: ldur            lr, [fp, #-0x10]
    // 0xfb2f64: stp             lr, x16, [SP, #8]
    // 0xfb2f68: ldur            x16, [fp, #-0x30]
    // 0xfb2f6c: str             x16, [SP]
    // 0xfb2f70: mov             x1, x0
    // 0xfb2f74: r4 = const [0, 0x6, 0x5, 0x1, button, 0x3, child, 0x5, container, 0x2, label, 0x1, onTap, 0x4, null]
    //     0xfb2f74: add             x4, PP, #0xb0, lsl #12  ; [pp+0xb08b8] List(15) [0, 0x6, 0x5, 0x1, "button", 0x3, "child", 0x5, "container", 0x2, "label", 0x1, "onTap", 0x4, Null]
    //     0xfb2f78: ldr             x4, [x4, #0x8b8]
    // 0xfb2f7c: r0 = Semantics()
    //     0xfb2f7c: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xfb2f80: ldur            x2, [fp, #-0x18]
    // 0xfb2f84: r1 = Function '<anonymous closure>':.
    //     0xfb2f84: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb08c0] AnonymousClosure: (0xfb30b0), in [package:flutter/src/material/bottom_sheet.dart] _DragHandle::build (0xfb2c24)
    //     0xfb2f88: ldr             x1, [x1, #0x8c0]
    // 0xfb2f8c: r0 = AllocateClosure()
    //     0xfb2f8c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfb2f90: stur            x0, [fp, #-0x10]
    // 0xfb2f94: r0 = MouseRegion()
    //     0xfb2f94: bl              #0xd1c8fc  ; AllocateMouseRegionStub -> MouseRegion (size=0x28)
    // 0xfb2f98: mov             x3, x0
    // 0xfb2f9c: ldur            x0, [fp, #-0x10]
    // 0xfb2fa0: stur            x3, [fp, #-0x20]
    // 0xfb2fa4: StoreField: r3->field_f = r0
    //     0xfb2fa4: stur            w0, [x3, #0xf]
    // 0xfb2fa8: ldur            x2, [fp, #-0x18]
    // 0xfb2fac: r1 = Function '<anonymous closure>':.
    //     0xfb2fac: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb08c8] AnonymousClosure: (0xfb3054), in [package:flutter/src/material/bottom_sheet.dart] _DragHandle::build (0xfb2c24)
    //     0xfb2fb0: ldr             x1, [x1, #0x8c8]
    // 0xfb2fb4: r0 = AllocateClosure()
    //     0xfb2fb4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfb2fb8: mov             x1, x0
    // 0xfb2fbc: ldur            x0, [fp, #-0x20]
    // 0xfb2fc0: ArrayStore: r0[0] = r1  ; List_4
    //     0xfb2fc0: stur            w1, [x0, #0x17]
    // 0xfb2fc4: r1 = Instance__DeferringMouseCursor
    //     0xfb2fc4: ldr             x1, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0xfb2fc8: StoreField: r0->field_1b = r1
    //     0xfb2fc8: stur            w1, [x0, #0x1b]
    // 0xfb2fcc: r1 = true
    //     0xfb2fcc: add             x1, NULL, #0x20  ; true
    // 0xfb2fd0: StoreField: r0->field_1f = r1
    //     0xfb2fd0: stur            w1, [x0, #0x1f]
    // 0xfb2fd4: ldur            x1, [fp, #-8]
    // 0xfb2fd8: StoreField: r0->field_b = r1
    //     0xfb2fd8: stur            w1, [x0, #0xb]
    // 0xfb2fdc: LeaveFrame
    //     0xfb2fdc: mov             SP, fp
    //     0xfb2fe0: ldp             fp, lr, [SP], #0x10
    // 0xfb2fe4: ret
    //     0xfb2fe4: ret             
    // 0xfb2fe8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb2fe8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb2fec: b               #0xfb2c4c
    // 0xfb2ff0: SaveReg d0
    //     0xfb2ff0: str             q0, [SP, #-0x10]!
    // 0xfb2ff4: SaveReg r1
    //     0xfb2ff4: str             x1, [SP, #-8]!
    // 0xfb2ff8: r0 = AllocateDouble()
    //     0xfb2ff8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfb2ffc: RestoreReg r1
    //     0xfb2ffc: ldr             x1, [SP], #8
    // 0xfb3000: RestoreReg d0
    //     0xfb3000: ldr             q0, [SP], #0x10
    // 0xfb3004: b               #0xfb2e3c
    // 0xfb3008: SaveReg d0
    //     0xfb3008: str             q0, [SP, #-0x10]!
    // 0xfb300c: stp             x0, x1, [SP, #-0x10]!
    // 0xfb3010: r0 = AllocateDouble()
    //     0xfb3010: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfb3014: mov             x2, x0
    // 0xfb3018: ldp             x0, x1, [SP], #0x10
    // 0xfb301c: RestoreReg d0
    //     0xfb301c: ldr             q0, [SP], #0x10
    // 0xfb3020: b               #0xfb2e70
    // 0xfb3024: SaveReg d0
    //     0xfb3024: str             q0, [SP, #-0x10]!
    // 0xfb3028: SaveReg r1
    //     0xfb3028: str             x1, [SP, #-8]!
    // 0xfb302c: r0 = AllocateDouble()
    //     0xfb302c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfb3030: RestoreReg r1
    //     0xfb3030: ldr             x1, [SP], #8
    // 0xfb3034: RestoreReg d0
    //     0xfb3034: ldr             q0, [SP], #0x10
    // 0xfb3038: b               #0xfb2ef0
    // 0xfb303c: SaveReg d0
    //     0xfb303c: str             q0, [SP, #-0x10]!
    // 0xfb3040: SaveReg r1
    //     0xfb3040: str             x1, [SP, #-8]!
    // 0xfb3044: r0 = AllocateDouble()
    //     0xfb3044: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfb3048: RestoreReg r1
    //     0xfb3048: ldr             x1, [SP], #8
    // 0xfb304c: RestoreReg d0
    //     0xfb304c: ldr             q0, [SP], #0x10
    // 0xfb3050: b               #0xfb2f38
  }
  [closure] void <anonymous closure>(dynamic, PointerExitEvent) {
    // ** addr: 0xfb3054, size: 0x5c
    // 0xfb3054: EnterFrame
    //     0xfb3054: stp             fp, lr, [SP, #-0x10]!
    //     0xfb3058: mov             fp, SP
    // 0xfb305c: ldr             x0, [fp, #0x18]
    // 0xfb3060: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xfb3060: ldur            w1, [x0, #0x17]
    // 0xfb3064: DecompressPointer r1
    //     0xfb3064: add             x1, x1, HEAP, lsl #32
    // 0xfb3068: CheckStackOverflow
    //     0xfb3068: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb306c: cmp             SP, x16
    //     0xfb3070: b.ls            #0xfb30a8
    // 0xfb3074: LoadField: r0 = r1->field_f
    //     0xfb3074: ldur            w0, [x1, #0xf]
    // 0xfb3078: DecompressPointer r0
    //     0xfb3078: add             x0, x0, HEAP, lsl #32
    // 0xfb307c: LoadField: r1 = r0->field_f
    //     0xfb307c: ldur            w1, [x0, #0xf]
    // 0xfb3080: DecompressPointer r1
    //     0xfb3080: add             x1, x1, HEAP, lsl #32
    // 0xfb3084: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xfb3084: ldur            w0, [x1, #0x17]
    // 0xfb3088: DecompressPointer r0
    //     0xfb3088: add             x0, x0, HEAP, lsl #32
    // 0xfb308c: mov             x1, x0
    // 0xfb3090: r2 = false
    //     0xfb3090: add             x2, NULL, #0x30  ; false
    // 0xfb3094: r0 = _handleDragHandleHover()
    //     0xfb3094: bl              #0xdebd5c  ; [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragHandleHover
    // 0xfb3098: r0 = Null
    //     0xfb3098: mov             x0, NULL
    // 0xfb309c: LeaveFrame
    //     0xfb309c: mov             SP, fp
    //     0xfb30a0: ldp             fp, lr, [SP], #0x10
    // 0xfb30a4: ret
    //     0xfb30a4: ret             
    // 0xfb30a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb30a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb30ac: b               #0xfb3074
  }
  [closure] void <anonymous closure>(dynamic, PointerEnterEvent) {
    // ** addr: 0xfb30b0, size: 0x5c
    // 0xfb30b0: EnterFrame
    //     0xfb30b0: stp             fp, lr, [SP, #-0x10]!
    //     0xfb30b4: mov             fp, SP
    // 0xfb30b8: ldr             x0, [fp, #0x18]
    // 0xfb30bc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xfb30bc: ldur            w1, [x0, #0x17]
    // 0xfb30c0: DecompressPointer r1
    //     0xfb30c0: add             x1, x1, HEAP, lsl #32
    // 0xfb30c4: CheckStackOverflow
    //     0xfb30c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb30c8: cmp             SP, x16
    //     0xfb30cc: b.ls            #0xfb3104
    // 0xfb30d0: LoadField: r0 = r1->field_f
    //     0xfb30d0: ldur            w0, [x1, #0xf]
    // 0xfb30d4: DecompressPointer r0
    //     0xfb30d4: add             x0, x0, HEAP, lsl #32
    // 0xfb30d8: LoadField: r1 = r0->field_f
    //     0xfb30d8: ldur            w1, [x0, #0xf]
    // 0xfb30dc: DecompressPointer r1
    //     0xfb30dc: add             x1, x1, HEAP, lsl #32
    // 0xfb30e0: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xfb30e0: ldur            w0, [x1, #0x17]
    // 0xfb30e4: DecompressPointer r0
    //     0xfb30e4: add             x0, x0, HEAP, lsl #32
    // 0xfb30e8: mov             x1, x0
    // 0xfb30ec: r2 = true
    //     0xfb30ec: add             x2, NULL, #0x20  ; true
    // 0xfb30f0: r0 = _handleDragHandleHover()
    //     0xfb30f0: bl              #0xdebd5c  ; [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragHandleHover
    // 0xfb30f4: r0 = Null
    //     0xfb30f4: mov             x0, NULL
    // 0xfb30f8: LeaveFrame
    //     0xfb30f8: mov             SP, fp
    //     0xfb30fc: ldp             fp, lr, [SP], #0x10
    // 0xfb3100: ret
    //     0xfb3100: ret             
    // 0xfb3104: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb3104: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb3108: b               #0xfb30d0
  }
}

// class id: 6500, size: 0x40, field offset: 0xc
//   const constructor, 
class _ModalBottomSheet<X0> extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa0d10, size: 0x48
    // 0xfa0d10: EnterFrame
    //     0xfa0d10: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0d14: mov             fp, SP
    // 0xfa0d18: LoadField: r2 = r1->field_b
    //     0xfa0d18: ldur            w2, [x1, #0xb]
    // 0xfa0d1c: DecompressPointer r2
    //     0xfa0d1c: add             x2, x2, HEAP, lsl #32
    // 0xfa0d20: r1 = Null
    //     0xfa0d20: mov             x1, NULL
    // 0xfa0d24: r3 = <_ModalBottomSheet<X0>, X0>
    //     0xfa0d24: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0f28] TypeArguments: <_ModalBottomSheet<X0>, X0>
    //     0xfa0d28: ldr             x3, [x3, #0xf28]
    // 0xfa0d2c: r30 = InstantiateTypeArgumentsStub
    //     0xfa0d2c: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xfa0d30: LoadField: r30 = r30->field_7
    //     0xfa0d30: ldur            lr, [lr, #7]
    // 0xfa0d34: blr             lr
    // 0xfa0d38: mov             x1, x0
    // 0xfa0d3c: r0 = _ModalBottomSheetState()
    //     0xfa0d3c: bl              #0xfa0d58  ; Allocate_ModalBottomSheetStateStub -> _ModalBottomSheetState<C1X0> (size=0x1c)
    // 0xfa0d40: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa0d44: StoreField: r0->field_13 = r1
    //     0xfa0d44: stur            w1, [x0, #0x13]
    // 0xfa0d48: ArrayStore: r0[0] = r1  ; List_4
    //     0xfa0d48: stur            w1, [x0, #0x17]
    // 0xfa0d4c: LeaveFrame
    //     0xfa0d4c: mov             SP, fp
    //     0xfa0d50: ldp             fp, lr, [SP], #0x10
    // 0xfa0d54: ret
    //     0xfa0d54: ret             
  }
}

// class id: 6501, size: 0x48, field offset: 0xc
//   const constructor, 
class BottomSheet extends StatefulWidget {

  static _ createAnimationController(/* No info */) {
    // ** addr: 0xeee668, size: 0x100
    // 0xeee668: EnterFrame
    //     0xeee668: stp             fp, lr, [SP, #-0x10]!
    //     0xeee66c: mov             fp, SP
    // 0xeee670: AllocStack(0x30)
    //     0xeee670: sub             SP, SP, #0x30
    // 0xeee674: SetupParameters(dynamic _ /* r1 => r2, fp-0x18 */, {dynamic sheetAnimationStyle = Null /* r0 */})
    //     0xeee674: mov             x2, x1
    //     0xeee678: stur            x1, [fp, #-0x18]
    //     0xeee67c: ldur            w0, [x4, #0x13]
    //     0xeee680: ldur            w1, [x4, #0x1f]
    //     0xeee684: add             x1, x1, HEAP, lsl #32
    //     0xeee688: add             x16, PP, #0x19, lsl #12  ; [pp+0x19ce0] "sheetAnimationStyle"
    //     0xeee68c: ldr             x16, [x16, #0xce0]
    //     0xeee690: cmp             w1, w16
    //     0xeee694: b.ne            #0xeee6b0
    //     0xeee698: ldur            w1, [x4, #0x23]
    //     0xeee69c: add             x1, x1, HEAP, lsl #32
    //     0xeee6a0: sub             w3, w0, w1
    //     0xeee6a4: add             x0, fp, w3, sxtw #2
    //     0xeee6a8: ldr             x0, [x0, #8]
    //     0xeee6ac: b               #0xeee6b4
    //     0xeee6b0: mov             x0, NULL
    // 0xeee6b4: CheckStackOverflow
    //     0xeee6b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeee6b8: cmp             SP, x16
    //     0xeee6bc: b.ls            #0xeee760
    // 0xeee6c0: cmp             w0, NULL
    // 0xeee6c4: b.ne            #0xeee6d0
    // 0xeee6c8: r1 = Null
    //     0xeee6c8: mov             x1, NULL
    // 0xeee6cc: b               #0xeee6d8
    // 0xeee6d0: LoadField: r1 = r0->field_b
    //     0xeee6d0: ldur            w1, [x0, #0xb]
    // 0xeee6d4: DecompressPointer r1
    //     0xeee6d4: add             x1, x1, HEAP, lsl #32
    // 0xeee6d8: cmp             w1, NULL
    // 0xeee6dc: b.ne            #0xeee6ec
    // 0xeee6e0: r3 = Instance_Duration
    //     0xeee6e0: add             x3, PP, #0xc, lsl #12  ; [pp+0xc920] Obj!Duration@12c89c1
    //     0xeee6e4: ldr             x3, [x3, #0x920]
    // 0xeee6e8: b               #0xeee6f0
    // 0xeee6ec: mov             x3, x1
    // 0xeee6f0: stur            x3, [fp, #-0x10]
    // 0xeee6f4: cmp             w0, NULL
    // 0xeee6f8: b.ne            #0xeee704
    // 0xeee6fc: r0 = Null
    //     0xeee6fc: mov             x0, NULL
    // 0xeee700: b               #0xeee710
    // 0xeee704: LoadField: r1 = r0->field_13
    //     0xeee704: ldur            w1, [x0, #0x13]
    // 0xeee708: DecompressPointer r1
    //     0xeee708: add             x1, x1, HEAP, lsl #32
    // 0xeee70c: mov             x0, x1
    // 0xeee710: cmp             w0, NULL
    // 0xeee714: b.ne            #0xeee720
    // 0xeee718: r0 = Instance_Duration
    //     0xeee718: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xeee71c: ldr             x0, [x0, #0x318]
    // 0xeee720: stur            x0, [fp, #-8]
    // 0xeee724: r1 = <double>
    //     0xeee724: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xeee728: r0 = AnimationController()
    //     0xeee728: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xeee72c: stur            x0, [fp, #-0x20]
    // 0xeee730: ldur            x16, [fp, #-0x10]
    // 0xeee734: ldur            lr, [fp, #-8]
    // 0xeee738: stp             lr, x16, [SP]
    // 0xeee73c: mov             x1, x0
    // 0xeee740: ldur            x2, [fp, #-0x18]
    // 0xeee744: r4 = const [0, 0x4, 0x2, 0x2, duration, 0x2, reverseDuration, 0x3, null]
    //     0xeee744: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1e860] List(9) [0, 0x4, 0x2, 0x2, "duration", 0x2, "reverseDuration", 0x3, Null]
    //     0xeee748: ldr             x4, [x4, #0x860]
    // 0xeee74c: r0 = AnimationController()
    //     0xeee74c: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xeee750: ldur            x0, [fp, #-0x20]
    // 0xeee754: LeaveFrame
    //     0xeee754: mov             SP, fp
    //     0xeee758: ldp             fp, lr, [SP], #0x10
    // 0xeee75c: ret
    //     0xeee75c: ret             
    // 0xeee760: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeee760: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeee764: b               #0xeee6c0
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa0c14, size: 0x48
    // 0xfa0c14: EnterFrame
    //     0xfa0c14: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0c18: mov             fp, SP
    // 0xfa0c1c: AllocStack(0x8)
    //     0xfa0c1c: sub             SP, SP, #8
    // 0xfa0c20: CheckStackOverflow
    //     0xfa0c20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa0c24: cmp             SP, x16
    //     0xfa0c28: b.ls            #0xfa0c54
    // 0xfa0c2c: r1 = <BottomSheet>
    //     0xfa0c2c: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0f30] TypeArguments: <BottomSheet>
    //     0xfa0c30: ldr             x1, [x1, #0xf30]
    // 0xfa0c34: r0 = _BottomSheetState()
    //     0xfa0c34: bl              #0xfa0d04  ; Allocate_BottomSheetStateStub -> _BottomSheetState (size=0x1c)
    // 0xfa0c38: mov             x1, x0
    // 0xfa0c3c: stur            x0, [fp, #-8]
    // 0xfa0c40: r0 = _BottomSheetState()
    //     0xfa0c40: bl              #0xfa0c5c  ; [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_BottomSheetState
    // 0xfa0c44: ldur            x0, [fp, #-8]
    // 0xfa0c48: LeaveFrame
    //     0xfa0c48: mov             SP, fp
    //     0xfa0c4c: ldp             fp, lr, [SP], #0x10
    // 0xfa0c50: ret
    //     0xfa0c50: ret             
    // 0xfa0c54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa0c54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa0c58: b               #0xfa0c2c
  }
}

// class id: 6657, size: 0x28, field offset: 0x10
//   const constructor, 
class _BottomSheetLayoutWithSizeListener extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf4674, size: 0xbc
    // 0xcf4674: EnterFrame
    //     0xcf4674: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4678: mov             fp, SP
    // 0xcf467c: AllocStack(0x10)
    //     0xcf467c: sub             SP, SP, #0x10
    // 0xcf4680: SetupParameters(_BottomSheetLayoutWithSizeListener this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf4680: mov             x4, x1
    //     0xcf4684: stur            x1, [fp, #-8]
    //     0xcf4688: stur            x3, [fp, #-0x10]
    // 0xcf468c: CheckStackOverflow
    //     0xcf468c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf4690: cmp             SP, x16
    //     0xcf4694: b.ls            #0xcf4728
    // 0xcf4698: mov             x0, x3
    // 0xcf469c: r2 = Null
    //     0xcf469c: mov             x2, NULL
    // 0xcf46a0: r1 = Null
    //     0xcf46a0: mov             x1, NULL
    // 0xcf46a4: r4 = 60
    //     0xcf46a4: mov             x4, #0x3c
    // 0xcf46a8: branchIfSmi(r0, 0xcf46b4)
    //     0xcf46a8: tbz             w0, #0, #0xcf46b4
    // 0xcf46ac: r4 = LoadClassIdInstr(r0)
    //     0xcf46ac: ldur            x4, [x0, #-1]
    //     0xcf46b0: ubfx            x4, x4, #0xc, #0x14
    // 0xcf46b4: r17 = 4881
    //     0xcf46b4: mov             x17, #0x1311
    // 0xcf46b8: cmp             x4, x17
    // 0xcf46bc: b.eq            #0xcf46d4
    // 0xcf46c0: r8 = _RenderBottomSheetLayoutWithSizeListener
    //     0xcf46c0: add             x8, PP, #0xb0, lsl #12  ; [pp+0xb08a0] Type: _RenderBottomSheetLayoutWithSizeListener
    //     0xcf46c4: ldr             x8, [x8, #0x8a0]
    // 0xcf46c8: r3 = Null
    //     0xcf46c8: add             x3, PP, #0xb0, lsl #12  ; [pp+0xb08a8] Null
    //     0xcf46cc: ldr             x3, [x3, #0x8a8]
    // 0xcf46d0: r0 = DefaultTypeTest()
    //     0xcf46d0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf46d4: ldur            x0, [fp, #-8]
    // 0xcf46d8: LoadField: r2 = r0->field_f
    //     0xcf46d8: ldur            w2, [x0, #0xf]
    // 0xcf46dc: DecompressPointer r2
    //     0xcf46dc: add             x2, x2, HEAP, lsl #32
    // 0xcf46e0: ldur            x1, [fp, #-0x10]
    // 0xcf46e4: r0 = onChildSizeChanged=()
    //     0xcf46e4: bl              #0xcf4824  ; [package:flutter/src/material/bottom_sheet.dart] _RenderBottomSheetLayoutWithSizeListener::onChildSizeChanged=
    // 0xcf46e8: ldur            x0, [fp, #-8]
    // 0xcf46ec: LoadField: d0 = r0->field_13
    //     0xcf46ec: ldur            d0, [x0, #0x13]
    // 0xcf46f0: ldur            x1, [fp, #-0x10]
    // 0xcf46f4: r0 = maxHeight=()
    //     0xcf46f4: bl              #0xcf47d4  ; [package:flutter/src/rendering/proxy_box.dart] RenderLimitedBox::maxHeight=
    // 0xcf46f8: ldur            x0, [fp, #-8]
    // 0xcf46fc: LoadField: r2 = r0->field_1b
    //     0xcf46fc: ldur            w2, [x0, #0x1b]
    // 0xcf4700: DecompressPointer r2
    //     0xcf4700: add             x2, x2, HEAP, lsl #32
    // 0xcf4704: ldur            x1, [fp, #-0x10]
    // 0xcf4708: r0 = isScrollControlled=()
    //     0xcf4708: bl              #0xcf4780  ; [package:flutter/src/material/bottom_sheet.dart] _RenderBottomSheetLayoutWithSizeListener::isScrollControlled=
    // 0xcf470c: ldur            x1, [fp, #-0x10]
    // 0xcf4710: d0 = 0.562500
    //     0xcf4710: fmov            d0, #0.56250000
    // 0xcf4714: r0 = scrollControlDisabledMaxHeightRatio=()
    //     0xcf4714: bl              #0xcf4730  ; [package:flutter/src/material/bottom_sheet.dart] _RenderBottomSheetLayoutWithSizeListener::scrollControlDisabledMaxHeightRatio=
    // 0xcf4718: r0 = Null
    //     0xcf4718: mov             x0, NULL
    // 0xcf471c: LeaveFrame
    //     0xcf471c: mov             SP, fp
    //     0xcf4720: ldp             fp, lr, [SP], #0x10
    // 0xcf4724: ret
    //     0xcf4724: ret             
    // 0xcf4728: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf4728: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf472c: b               #0xcf4698
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11cf76c, size: 0x6c
    // 0x11cf76c: EnterFrame
    //     0x11cf76c: stp             fp, lr, [SP, #-0x10]!
    //     0x11cf770: mov             fp, SP
    // 0x11cf774: AllocStack(0x18)
    //     0x11cf774: sub             SP, SP, #0x18
    // 0x11cf778: CheckStackOverflow
    //     0x11cf778: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cf77c: cmp             SP, x16
    //     0x11cf780: b.ls            #0x11cf7d0
    // 0x11cf784: LoadField: r3 = r1->field_f
    //     0x11cf784: ldur            w3, [x1, #0xf]
    // 0x11cf788: DecompressPointer r3
    //     0x11cf788: add             x3, x3, HEAP, lsl #32
    // 0x11cf78c: stur            x3, [fp, #-0x10]
    // 0x11cf790: LoadField: d0 = r1->field_13
    //     0x11cf790: ldur            d0, [x1, #0x13]
    // 0x11cf794: stur            d0, [fp, #-0x18]
    // 0x11cf798: LoadField: r2 = r1->field_1b
    //     0x11cf798: ldur            w2, [x1, #0x1b]
    // 0x11cf79c: DecompressPointer r2
    //     0x11cf79c: add             x2, x2, HEAP, lsl #32
    // 0x11cf7a0: stur            x2, [fp, #-8]
    // 0x11cf7a4: r0 = _RenderBottomSheetLayoutWithSizeListener()
    //     0x11cf7a4: bl              #0x11cf888  ; Allocate_RenderBottomSheetLayoutWithSizeListenerStub -> _RenderBottomSheetLayoutWithSizeListener (size=0x70)
    // 0x11cf7a8: mov             x1, x0
    // 0x11cf7ac: ldur            d0, [fp, #-0x18]
    // 0x11cf7b0: ldur            x2, [fp, #-8]
    // 0x11cf7b4: ldur            x3, [fp, #-0x10]
    // 0x11cf7b8: stur            x0, [fp, #-8]
    // 0x11cf7bc: r0 = _RenderBottomSheetLayoutWithSizeListener()
    //     0x11cf7bc: bl              #0x11cf7d8  ; [package:flutter/src/material/bottom_sheet.dart] _RenderBottomSheetLayoutWithSizeListener::_RenderBottomSheetLayoutWithSizeListener
    // 0x11cf7c0: ldur            x0, [fp, #-8]
    // 0x11cf7c4: LeaveFrame
    //     0x11cf7c4: mov             SP, fp
    //     0x11cf7c8: ldp             fp, lr, [SP], #0x10
    // 0x11cf7cc: ret
    //     0x11cf7cc: ret             
    // 0x11cf7d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cf7d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cf7d4: b               #0x11cf784
  }
}
