// lib: , url: package:flutter/src/material/app_bar_theme.dart

// class id: 1048844, size: 0x8
class :: {
}

// class id: 5209, size: 0x4c, field offset: 0x8
//   const constructor, 
class AppBarThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x112e650, size: 0x5dc
    // 0x112e650: EnterFrame
    //     0x112e650: stp             fp, lr, [SP, #-0x10]!
    //     0x112e654: mov             fp, SP
    // 0x112e658: AllocStack(0xe0)
    //     0x112e658: sub             SP, SP, #0xe0
    // 0x112e65c: CheckStackOverflow
    //     0x112e65c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112e660: cmp             SP, x16
    //     0x112e664: b.ls            #0x112ec24
    // 0x112e668: ldr             x0, [fp, #0x10]
    // 0x112e66c: r2 = LoadClassIdInstr(r0)
    //     0x112e66c: ldur            x2, [x0, #-1]
    //     0x112e670: ubfx            x2, x2, #0xc, #0x14
    // 0x112e674: stur            x2, [fp, #-8]
    // 0x112e678: r17 = 5209
    //     0x112e678: mov             x17, #0x1459
    // 0x112e67c: cmp             x2, x17
    // 0x112e680: b.ne            #0x112e698
    // 0x112e684: LoadField: r1 = r0->field_7
    //     0x112e684: ldur            w1, [x0, #7]
    // 0x112e688: DecompressPointer r1
    //     0x112e688: add             x1, x1, HEAP, lsl #32
    // 0x112e68c: mov             x0, x2
    // 0x112e690: mov             x2, x1
    // 0x112e694: b               #0x112e738
    // 0x112e698: r17 = 5210
    //     0x112e698: mov             x17, #0x145a
    // 0x112e69c: cmp             x2, x17
    // 0x112e6a0: b.ne            #0x112e6dc
    // 0x112e6a4: mov             x1, x0
    // 0x112e6a8: LoadField: r0 = r1->field_53
    //     0x112e6a8: ldur            w0, [x1, #0x53]
    // 0x112e6ac: DecompressPointer r0
    //     0x112e6ac: add             x0, x0, HEAP, lsl #32
    // 0x112e6b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x112e6b4: cmp             w0, w16
    // 0x112e6b8: b.ne            #0x112e6c8
    // 0x112e6bc: r2 = _colors
    //     0x112e6bc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26588] Field <_AppBarDefaultsM3@25187611._colors@25187611>: late final (offset: 0x54)
    //     0x112e6c0: ldr             x2, [x2, #0x588]
    // 0x112e6c4: r0 = InitLateFinalInstanceField()
    //     0x112e6c4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x112e6c8: LoadField: r1 = r0->field_7b
    //     0x112e6c8: ldur            w1, [x0, #0x7b]
    // 0x112e6cc: DecompressPointer r1
    //     0x112e6cc: add             x1, x1, HEAP, lsl #32
    // 0x112e6d0: mov             x2, x1
    // 0x112e6d4: ldur            x0, [fp, #-8]
    // 0x112e6d8: b               #0x112e738
    // 0x112e6dc: ldr             x1, [fp, #0x10]
    // 0x112e6e0: LoadField: r0 = r1->field_53
    //     0x112e6e0: ldur            w0, [x1, #0x53]
    // 0x112e6e4: DecompressPointer r0
    //     0x112e6e4: add             x0, x0, HEAP, lsl #32
    // 0x112e6e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x112e6ec: cmp             w0, w16
    // 0x112e6f0: b.ne            #0x112e700
    // 0x112e6f4: r2 = _colors
    //     0x112e6f4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26590] Field <_AppBarDefaultsM2@25187611._colors@25187611>: late final (offset: 0x54)
    //     0x112e6f8: ldr             x2, [x2, #0x590]
    // 0x112e6fc: r0 = InitLateFinalInstanceField()
    //     0x112e6fc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x112e700: LoadField: r1 = r0->field_7
    //     0x112e700: ldur            w1, [x0, #7]
    // 0x112e704: DecompressPointer r1
    //     0x112e704: add             x1, x1, HEAP, lsl #32
    // 0x112e708: r16 = Instance_Brightness
    //     0x112e708: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x112e70c: cmp             w1, w16
    // 0x112e710: b.ne            #0x112e724
    // 0x112e714: LoadField: r1 = r0->field_7b
    //     0x112e714: ldur            w1, [x0, #0x7b]
    // 0x112e718: DecompressPointer r1
    //     0x112e718: add             x1, x1, HEAP, lsl #32
    // 0x112e71c: mov             x0, x1
    // 0x112e720: b               #0x112e730
    // 0x112e724: LoadField: r1 = r0->field_b
    //     0x112e724: ldur            w1, [x0, #0xb]
    // 0x112e728: DecompressPointer r1
    //     0x112e728: add             x1, x1, HEAP, lsl #32
    // 0x112e72c: mov             x0, x1
    // 0x112e730: mov             x2, x0
    // 0x112e734: ldur            x0, [fp, #-8]
    // 0x112e738: stur            x2, [fp, #-0x10]
    // 0x112e73c: r17 = 5209
    //     0x112e73c: mov             x17, #0x1459
    // 0x112e740: cmp             x0, x17
    // 0x112e744: b.ne            #0x112e760
    // 0x112e748: ldr             x3, [fp, #0x10]
    // 0x112e74c: LoadField: r1 = r3->field_b
    //     0x112e74c: ldur            w1, [x3, #0xb]
    // 0x112e750: DecompressPointer r1
    //     0x112e750: add             x1, x1, HEAP, lsl #32
    // 0x112e754: mov             x2, x3
    // 0x112e758: mov             x3, x1
    // 0x112e75c: b               #0x112e80c
    // 0x112e760: ldr             x3, [fp, #0x10]
    // 0x112e764: r17 = 5210
    //     0x112e764: mov             x17, #0x145a
    // 0x112e768: cmp             x0, x17
    // 0x112e76c: b.ne            #0x112e7ac
    // 0x112e770: mov             x1, x3
    // 0x112e774: LoadField: r0 = r1->field_53
    //     0x112e774: ldur            w0, [x1, #0x53]
    // 0x112e778: DecompressPointer r0
    //     0x112e778: add             x0, x0, HEAP, lsl #32
    // 0x112e77c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x112e780: cmp             w0, w16
    // 0x112e784: b.ne            #0x112e794
    // 0x112e788: r2 = _colors
    //     0x112e788: add             x2, PP, #0x26, lsl #12  ; [pp+0x26588] Field <_AppBarDefaultsM3@25187611._colors@25187611>: late final (offset: 0x54)
    //     0x112e78c: ldr             x2, [x2, #0x588]
    // 0x112e790: r0 = InitLateFinalInstanceField()
    //     0x112e790: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x112e794: LoadField: r1 = r0->field_7f
    //     0x112e794: ldur            w1, [x0, #0x7f]
    // 0x112e798: DecompressPointer r1
    //     0x112e798: add             x1, x1, HEAP, lsl #32
    // 0x112e79c: mov             x3, x1
    // 0x112e7a0: ldr             x2, [fp, #0x10]
    // 0x112e7a4: ldur            x0, [fp, #-8]
    // 0x112e7a8: b               #0x112e80c
    // 0x112e7ac: ldr             x1, [fp, #0x10]
    // 0x112e7b0: LoadField: r0 = r1->field_53
    //     0x112e7b0: ldur            w0, [x1, #0x53]
    // 0x112e7b4: DecompressPointer r0
    //     0x112e7b4: add             x0, x0, HEAP, lsl #32
    // 0x112e7b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x112e7bc: cmp             w0, w16
    // 0x112e7c0: b.ne            #0x112e7d0
    // 0x112e7c4: r2 = _colors
    //     0x112e7c4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26590] Field <_AppBarDefaultsM2@25187611._colors@25187611>: late final (offset: 0x54)
    //     0x112e7c8: ldr             x2, [x2, #0x590]
    // 0x112e7cc: r0 = InitLateFinalInstanceField()
    //     0x112e7cc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x112e7d0: LoadField: r1 = r0->field_7
    //     0x112e7d0: ldur            w1, [x0, #7]
    // 0x112e7d4: DecompressPointer r1
    //     0x112e7d4: add             x1, x1, HEAP, lsl #32
    // 0x112e7d8: r16 = Instance_Brightness
    //     0x112e7d8: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x112e7dc: cmp             w1, w16
    // 0x112e7e0: b.ne            #0x112e7f4
    // 0x112e7e4: LoadField: r1 = r0->field_7f
    //     0x112e7e4: ldur            w1, [x0, #0x7f]
    // 0x112e7e8: DecompressPointer r1
    //     0x112e7e8: add             x1, x1, HEAP, lsl #32
    // 0x112e7ec: mov             x0, x1
    // 0x112e7f0: b               #0x112e800
    // 0x112e7f4: LoadField: r1 = r0->field_f
    //     0x112e7f4: ldur            w1, [x0, #0xf]
    // 0x112e7f8: DecompressPointer r1
    //     0x112e7f8: add             x1, x1, HEAP, lsl #32
    // 0x112e7fc: mov             x0, x1
    // 0x112e800: mov             x3, x0
    // 0x112e804: ldr             x2, [fp, #0x10]
    // 0x112e808: ldur            x0, [fp, #-8]
    // 0x112e80c: stur            x3, [fp, #-0x38]
    // 0x112e810: LoadField: r4 = r2->field_f
    //     0x112e810: ldur            w4, [x2, #0xf]
    // 0x112e814: DecompressPointer r4
    //     0x112e814: add             x4, x4, HEAP, lsl #32
    // 0x112e818: stur            x4, [fp, #-0x30]
    // 0x112e81c: LoadField: r5 = r2->field_13
    //     0x112e81c: ldur            w5, [x2, #0x13]
    // 0x112e820: DecompressPointer r5
    //     0x112e820: add             x5, x5, HEAP, lsl #32
    // 0x112e824: stur            x5, [fp, #-0x28]
    // 0x112e828: r17 = 5209
    //     0x112e828: mov             x17, #0x1459
    // 0x112e82c: cmp             x0, x17
    // 0x112e830: b.eq            #0x112e84c
    // 0x112e834: r17 = 5210
    //     0x112e834: mov             x17, #0x145a
    // 0x112e838: cmp             x0, x17
    // 0x112e83c: b.ne            #0x112e84c
    // 0x112e840: r6 = Instance_Color
    //     0x112e840: add             x6, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x112e844: ldr             x6, [x6, #0x810]
    // 0x112e848: b               #0x112e858
    // 0x112e84c: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x112e84c: ldur            w1, [x2, #0x17]
    // 0x112e850: DecompressPointer r1
    //     0x112e850: add             x1, x1, HEAP, lsl #32
    // 0x112e854: mov             x6, x1
    // 0x112e858: stur            x6, [fp, #-0x20]
    // 0x112e85c: r17 = 5209
    //     0x112e85c: mov             x17, #0x1459
    // 0x112e860: cmp             x0, x17
    // 0x112e864: b.eq            #0x112e880
    // 0x112e868: r17 = 5210
    //     0x112e868: mov             x17, #0x145a
    // 0x112e86c: cmp             x0, x17
    // 0x112e870: b.ne            #0x112e880
    // 0x112e874: r7 = Instance_Color
    //     0x112e874: add             x7, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x112e878: ldr             x7, [x7, #0x810]
    // 0x112e87c: b               #0x112e88c
    // 0x112e880: LoadField: r1 = r2->field_1b
    //     0x112e880: ldur            w1, [x2, #0x1b]
    // 0x112e884: DecompressPointer r1
    //     0x112e884: add             x1, x1, HEAP, lsl #32
    // 0x112e888: mov             x7, x1
    // 0x112e88c: stur            x7, [fp, #-0x18]
    // 0x112e890: r17 = 5209
    //     0x112e890: mov             x17, #0x1459
    // 0x112e894: cmp             x0, x17
    // 0x112e898: b.ne            #0x112e8ac
    // 0x112e89c: LoadField: r1 = r2->field_23
    //     0x112e89c: ldur            w1, [x2, #0x23]
    // 0x112e8a0: DecompressPointer r1
    //     0x112e8a0: add             x1, x1, HEAP, lsl #32
    // 0x112e8a4: mov             x2, x1
    // 0x112e8a8: b               #0x112e94c
    // 0x112e8ac: r17 = 5210
    //     0x112e8ac: mov             x17, #0x145a
    // 0x112e8b0: cmp             x0, x17
    // 0x112e8b4: b.ne            #0x112e910
    // 0x112e8b8: mov             x1, x2
    // 0x112e8bc: LoadField: r0 = r1->field_53
    //     0x112e8bc: ldur            w0, [x1, #0x53]
    // 0x112e8c0: DecompressPointer r0
    //     0x112e8c0: add             x0, x0, HEAP, lsl #32
    // 0x112e8c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x112e8c8: cmp             w0, w16
    // 0x112e8cc: b.ne            #0x112e8dc
    // 0x112e8d0: r2 = _colors
    //     0x112e8d0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26588] Field <_AppBarDefaultsM3@25187611._colors@25187611>: late final (offset: 0x54)
    //     0x112e8d4: ldr             x2, [x2, #0x588]
    // 0x112e8d8: r0 = InitLateFinalInstanceField()
    //     0x112e8d8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x112e8dc: LoadField: r1 = r0->field_7f
    //     0x112e8dc: ldur            w1, [x0, #0x7f]
    // 0x112e8e0: DecompressPointer r1
    //     0x112e8e0: add             x1, x1, HEAP, lsl #32
    // 0x112e8e4: stur            x1, [fp, #-0x40]
    // 0x112e8e8: r0 = IconThemeData()
    //     0x112e8e8: bl              #0x8ac78c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0x112e8ec: mov             x1, x0
    // 0x112e8f0: r0 = 24.000000
    //     0x112e8f0: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0x112e8f4: ldr             x0, [x0, #0x4d0]
    // 0x112e8f8: StoreField: r1->field_7 = r0
    //     0x112e8f8: stur            w0, [x1, #7]
    // 0x112e8fc: ldur            x2, [fp, #-0x40]
    // 0x112e900: StoreField: r1->field_1b = r2
    //     0x112e900: stur            w2, [x1, #0x1b]
    // 0x112e904: mov             x2, x1
    // 0x112e908: ldur            x0, [fp, #-8]
    // 0x112e90c: b               #0x112e94c
    // 0x112e910: r0 = 24.000000
    //     0x112e910: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0x112e914: ldr             x0, [x0, #0x4d0]
    // 0x112e918: ldr             x1, [fp, #0x10]
    // 0x112e91c: LoadField: r0 = r1->field_4f
    //     0x112e91c: ldur            w0, [x1, #0x4f]
    // 0x112e920: DecompressPointer r0
    //     0x112e920: add             x0, x0, HEAP, lsl #32
    // 0x112e924: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x112e928: cmp             w0, w16
    // 0x112e92c: b.ne            #0x112e93c
    // 0x112e930: r2 = _theme
    //     0x112e930: add             x2, PP, #0x26, lsl #12  ; [pp+0x26598] Field <_AppBarDefaultsM2@25187611._theme@25187611>: late final (offset: 0x50)
    //     0x112e934: ldr             x2, [x2, #0x598]
    // 0x112e938: r0 = InitLateFinalInstanceField()
    //     0x112e938: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x112e93c: LoadField: r1 = r0->field_7b
    //     0x112e93c: ldur            w1, [x0, #0x7b]
    // 0x112e940: DecompressPointer r1
    //     0x112e940: add             x1, x1, HEAP, lsl #32
    // 0x112e944: mov             x2, x1
    // 0x112e948: ldur            x0, [fp, #-8]
    // 0x112e94c: stur            x2, [fp, #-0x40]
    // 0x112e950: r17 = 5209
    //     0x112e950: mov             x17, #0x1459
    // 0x112e954: cmp             x0, x17
    // 0x112e958: b.eq            #0x112e9dc
    // 0x112e95c: r17 = 5210
    //     0x112e95c: mov             x17, #0x145a
    // 0x112e960: cmp             x0, x17
    // 0x112e964: b.ne            #0x112e9dc
    // 0x112e968: ldr             x1, [fp, #0x10]
    // 0x112e96c: LoadField: r0 = r1->field_53
    //     0x112e96c: ldur            w0, [x1, #0x53]
    // 0x112e970: DecompressPointer r0
    //     0x112e970: add             x0, x0, HEAP, lsl #32
    // 0x112e974: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x112e978: cmp             w0, w16
    // 0x112e97c: b.ne            #0x112e98c
    // 0x112e980: r2 = _colors
    //     0x112e980: add             x2, PP, #0x26, lsl #12  ; [pp+0x26588] Field <_AppBarDefaultsM3@25187611._colors@25187611>: late final (offset: 0x54)
    //     0x112e984: ldr             x2, [x2, #0x588]
    // 0x112e988: r0 = InitLateFinalInstanceField()
    //     0x112e988: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x112e98c: LoadField: r1 = r0->field_a3
    //     0x112e98c: ldur            w1, [x0, #0xa3]
    // 0x112e990: DecompressPointer r1
    //     0x112e990: add             x1, x1, HEAP, lsl #32
    // 0x112e994: cmp             w1, NULL
    // 0x112e998: b.ne            #0x112e9ac
    // 0x112e99c: LoadField: r1 = r0->field_7f
    //     0x112e99c: ldur            w1, [x0, #0x7f]
    // 0x112e9a0: DecompressPointer r1
    //     0x112e9a0: add             x1, x1, HEAP, lsl #32
    // 0x112e9a4: mov             x0, x1
    // 0x112e9a8: b               #0x112e9b0
    // 0x112e9ac: mov             x0, x1
    // 0x112e9b0: stur            x0, [fp, #-0x48]
    // 0x112e9b4: r0 = IconThemeData()
    //     0x112e9b4: bl              #0x8ac78c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0x112e9b8: mov             x1, x0
    // 0x112e9bc: r0 = 24.000000
    //     0x112e9bc: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0x112e9c0: ldr             x0, [x0, #0x4d0]
    // 0x112e9c4: StoreField: r1->field_7 = r0
    //     0x112e9c4: stur            w0, [x1, #7]
    // 0x112e9c8: ldur            x0, [fp, #-0x48]
    // 0x112e9cc: StoreField: r1->field_1b = r0
    //     0x112e9cc: stur            w0, [x1, #0x1b]
    // 0x112e9d0: mov             x3, x1
    // 0x112e9d4: ldr             x0, [fp, #0x10]
    // 0x112e9d8: b               #0x112e9ec
    // 0x112e9dc: ldr             x0, [fp, #0x10]
    // 0x112e9e0: LoadField: r1 = r0->field_27
    //     0x112e9e0: ldur            w1, [x0, #0x27]
    // 0x112e9e4: DecompressPointer r1
    //     0x112e9e4: add             x1, x1, HEAP, lsl #32
    // 0x112e9e8: mov             x3, x1
    // 0x112e9ec: ldur            x2, [fp, #-8]
    // 0x112e9f0: stur            x3, [fp, #-0x60]
    // 0x112e9f4: LoadField: r4 = r0->field_2f
    //     0x112e9f4: ldur            w4, [x0, #0x2f]
    // 0x112e9f8: DecompressPointer r4
    //     0x112e9f8: add             x4, x4, HEAP, lsl #32
    // 0x112e9fc: stur            x4, [fp, #-0x58]
    // 0x112ea00: LoadField: r5 = r0->field_33
    //     0x112ea00: ldur            w5, [x0, #0x33]
    // 0x112ea04: DecompressPointer r5
    //     0x112ea04: add             x5, x5, HEAP, lsl #32
    // 0x112ea08: stur            x5, [fp, #-0x50]
    // 0x112ea0c: LoadField: r6 = r0->field_37
    //     0x112ea0c: ldur            w6, [x0, #0x37]
    // 0x112ea10: DecompressPointer r6
    //     0x112ea10: add             x6, x6, HEAP, lsl #32
    // 0x112ea14: stur            x6, [fp, #-0x48]
    // 0x112ea18: r17 = 5209
    //     0x112ea18: mov             x17, #0x1459
    // 0x112ea1c: cmp             x2, x17
    // 0x112ea20: b.ne            #0x112ea38
    // 0x112ea24: LoadField: r1 = r0->field_3b
    //     0x112ea24: ldur            w1, [x0, #0x3b]
    // 0x112ea28: DecompressPointer r1
    //     0x112ea28: add             x1, x1, HEAP, lsl #32
    // 0x112ea2c: mov             x0, x2
    // 0x112ea30: mov             x2, x1
    // 0x112ea34: b               #0x112eab8
    // 0x112ea38: r17 = 5210
    //     0x112ea38: mov             x17, #0x145a
    // 0x112ea3c: cmp             x2, x17
    // 0x112ea40: b.ne            #0x112ea7c
    // 0x112ea44: mov             x1, x0
    // 0x112ea48: LoadField: r0 = r1->field_57
    //     0x112ea48: ldur            w0, [x1, #0x57]
    // 0x112ea4c: DecompressPointer r0
    //     0x112ea4c: add             x0, x0, HEAP, lsl #32
    // 0x112ea50: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x112ea54: cmp             w0, w16
    // 0x112ea58: b.ne            #0x112ea68
    // 0x112ea5c: r2 = _textTheme
    //     0x112ea5c: add             x2, PP, #0x26, lsl #12  ; [pp+0x265a0] Field <_AppBarDefaultsM3@25187611._textTheme@25187611>: late final (offset: 0x58)
    //     0x112ea60: ldr             x2, [x2, #0x5a0]
    // 0x112ea64: r0 = InitLateFinalInstanceField()
    //     0x112ea64: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x112ea68: LoadField: r1 = r0->field_2f
    //     0x112ea68: ldur            w1, [x0, #0x2f]
    // 0x112ea6c: DecompressPointer r1
    //     0x112ea6c: add             x1, x1, HEAP, lsl #32
    // 0x112ea70: mov             x2, x1
    // 0x112ea74: ldur            x0, [fp, #-8]
    // 0x112ea78: b               #0x112eab8
    // 0x112ea7c: ldr             x1, [fp, #0x10]
    // 0x112ea80: LoadField: r0 = r1->field_4f
    //     0x112ea80: ldur            w0, [x1, #0x4f]
    // 0x112ea84: DecompressPointer r0
    //     0x112ea84: add             x0, x0, HEAP, lsl #32
    // 0x112ea88: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x112ea8c: cmp             w0, w16
    // 0x112ea90: b.ne            #0x112eaa0
    // 0x112ea94: r2 = _theme
    //     0x112ea94: add             x2, PP, #0x26, lsl #12  ; [pp+0x26598] Field <_AppBarDefaultsM2@25187611._theme@25187611>: late final (offset: 0x50)
    //     0x112ea98: ldr             x2, [x2, #0x598]
    // 0x112ea9c: r0 = InitLateFinalInstanceField()
    //     0x112ea9c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x112eaa0: LoadField: r1 = r0->field_87
    //     0x112eaa0: ldur            w1, [x0, #0x87]
    // 0x112eaa4: DecompressPointer r1
    //     0x112eaa4: add             x1, x1, HEAP, lsl #32
    // 0x112eaa8: LoadField: r0 = r1->field_2f
    //     0x112eaa8: ldur            w0, [x1, #0x2f]
    // 0x112eaac: DecompressPointer r0
    //     0x112eaac: add             x0, x0, HEAP, lsl #32
    // 0x112eab0: mov             x2, x0
    // 0x112eab4: ldur            x0, [fp, #-8]
    // 0x112eab8: stur            x2, [fp, #-0x68]
    // 0x112eabc: r17 = 5209
    //     0x112eabc: mov             x17, #0x1459
    // 0x112eac0: cmp             x0, x17
    // 0x112eac4: b.ne            #0x112eae0
    // 0x112eac8: ldr             x3, [fp, #0x10]
    // 0x112eacc: LoadField: r1 = r3->field_3f
    //     0x112eacc: ldur            w1, [x3, #0x3f]
    // 0x112ead0: DecompressPointer r1
    //     0x112ead0: add             x1, x1, HEAP, lsl #32
    // 0x112ead4: mov             x2, x1
    // 0x112ead8: mov             x1, x3
    // 0x112eadc: b               #0x112eb6c
    // 0x112eae0: ldr             x3, [fp, #0x10]
    // 0x112eae4: r17 = 5210
    //     0x112eae4: mov             x17, #0x145a
    // 0x112eae8: cmp             x0, x17
    // 0x112eaec: b.ne            #0x112eb2c
    // 0x112eaf0: mov             x1, x3
    // 0x112eaf4: LoadField: r0 = r1->field_57
    //     0x112eaf4: ldur            w0, [x1, #0x57]
    // 0x112eaf8: DecompressPointer r0
    //     0x112eaf8: add             x0, x0, HEAP, lsl #32
    // 0x112eafc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x112eb00: cmp             w0, w16
    // 0x112eb04: b.ne            #0x112eb14
    // 0x112eb08: r2 = _textTheme
    //     0x112eb08: add             x2, PP, #0x26, lsl #12  ; [pp+0x265a0] Field <_AppBarDefaultsM3@25187611._textTheme@25187611>: late final (offset: 0x58)
    //     0x112eb0c: ldr             x2, [x2, #0x5a0]
    // 0x112eb10: r0 = InitLateFinalInstanceField()
    //     0x112eb10: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x112eb14: LoadField: r1 = r0->field_1f
    //     0x112eb14: ldur            w1, [x0, #0x1f]
    // 0x112eb18: DecompressPointer r1
    //     0x112eb18: add             x1, x1, HEAP, lsl #32
    // 0x112eb1c: mov             x2, x1
    // 0x112eb20: ldr             x1, [fp, #0x10]
    // 0x112eb24: ldur            x0, [fp, #-8]
    // 0x112eb28: b               #0x112eb6c
    // 0x112eb2c: ldr             x1, [fp, #0x10]
    // 0x112eb30: LoadField: r0 = r1->field_4f
    //     0x112eb30: ldur            w0, [x1, #0x4f]
    // 0x112eb34: DecompressPointer r0
    //     0x112eb34: add             x0, x0, HEAP, lsl #32
    // 0x112eb38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x112eb3c: cmp             w0, w16
    // 0x112eb40: b.ne            #0x112eb50
    // 0x112eb44: r2 = _theme
    //     0x112eb44: add             x2, PP, #0x26, lsl #12  ; [pp+0x26598] Field <_AppBarDefaultsM2@25187611._theme@25187611>: late final (offset: 0x50)
    //     0x112eb48: ldr             x2, [x2, #0x598]
    // 0x112eb4c: r0 = InitLateFinalInstanceField()
    //     0x112eb4c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x112eb50: LoadField: r1 = r0->field_87
    //     0x112eb50: ldur            w1, [x0, #0x87]
    // 0x112eb54: DecompressPointer r1
    //     0x112eb54: add             x1, x1, HEAP, lsl #32
    // 0x112eb58: LoadField: r0 = r1->field_1f
    //     0x112eb58: ldur            w0, [x1, #0x1f]
    // 0x112eb5c: DecompressPointer r0
    //     0x112eb5c: add             x0, x0, HEAP, lsl #32
    // 0x112eb60: mov             x2, x0
    // 0x112eb64: ldr             x1, [fp, #0x10]
    // 0x112eb68: ldur            x0, [fp, #-8]
    // 0x112eb6c: LoadField: r3 = r1->field_43
    //     0x112eb6c: ldur            w3, [x1, #0x43]
    // 0x112eb70: DecompressPointer r3
    //     0x112eb70: add             x3, x3, HEAP, lsl #32
    // 0x112eb74: r17 = 5209
    //     0x112eb74: mov             x17, #0x1459
    // 0x112eb78: cmp             x0, x17
    // 0x112eb7c: b.ne            #0x112eb8c
    // 0x112eb80: LoadField: r0 = r1->field_47
    //     0x112eb80: ldur            w0, [x1, #0x47]
    // 0x112eb84: DecompressPointer r0
    //     0x112eb84: add             x0, x0, HEAP, lsl #32
    // 0x112eb88: b               #0x112eba4
    // 0x112eb8c: r17 = 5210
    //     0x112eb8c: mov             x17, #0x145a
    // 0x112eb90: cmp             x0, x17
    // 0x112eb94: b.ne            #0x112eba0
    // 0x112eb98: r0 = Instance_EdgeInsets
    //     0x112eb98: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0x112eb9c: b               #0x112eba4
    // 0x112eba0: r0 = Instance_EdgeInsets
    //     0x112eba0: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0x112eba4: ldur            x16, [fp, #-0x30]
    // 0x112eba8: ldur            lr, [fp, #-0x28]
    // 0x112ebac: stp             lr, x16, [SP, #0x68]
    // 0x112ebb0: ldur            x16, [fp, #-0x20]
    // 0x112ebb4: ldur            lr, [fp, #-0x18]
    // 0x112ebb8: stp             lr, x16, [SP, #0x58]
    // 0x112ebbc: ldur            x16, [fp, #-0x40]
    // 0x112ebc0: stp             x16, NULL, [SP, #0x48]
    // 0x112ebc4: ldur            x16, [fp, #-0x60]
    // 0x112ebc8: stp             NULL, x16, [SP, #0x38]
    // 0x112ebcc: ldur            x16, [fp, #-0x58]
    // 0x112ebd0: ldur            lr, [fp, #-0x50]
    // 0x112ebd4: stp             lr, x16, [SP, #0x28]
    // 0x112ebd8: ldur            x16, [fp, #-0x48]
    // 0x112ebdc: ldur            lr, [fp, #-0x68]
    // 0x112ebe0: stp             lr, x16, [SP, #0x18]
    // 0x112ebe4: stp             x3, x2, [SP, #8]
    // 0x112ebe8: str             x0, [SP]
    // 0x112ebec: ldur            x1, [fp, #-0x10]
    // 0x112ebf0: ldur            x2, [fp, #-0x38]
    // 0x112ebf4: r4 = const [0, 0x11, 0xf, 0x11, null]
    //     0x112ebf4: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbd0] List(5) [0, 0x11, 0xf, 0x11, Null]
    //     0x112ebf8: ldr             x4, [x4, #0xbd0]
    // 0x112ebfc: r0 = hash()
    //     0x112ebfc: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x112ec00: mov             x2, x0
    // 0x112ec04: r0 = BoxInt64Instr(r2)
    //     0x112ec04: sbfiz           x0, x2, #1, #0x1f
    //     0x112ec08: cmp             x2, x0, asr #1
    //     0x112ec0c: b.eq            #0x112ec18
    //     0x112ec10: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x112ec14: stur            x2, [x0, #7]
    // 0x112ec18: LeaveFrame
    //     0x112ec18: mov             SP, fp
    //     0x112ec1c: ldp             fp, lr, [SP], #0x10
    // 0x112ec20: ret
    //     0x112ec20: ret             
    // 0x112ec24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112ec24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112ec28: b               #0x112e668
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1168e98, size: 0x32c
    // 0x1168e98: EnterFrame
    //     0x1168e98: stp             fp, lr, [SP, #-0x10]!
    //     0x1168e9c: mov             fp, SP
    // 0x1168ea0: AllocStack(0x70)
    //     0x1168ea0: sub             SP, SP, #0x70
    // 0x1168ea4: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x70 */)
    //     0x1168ea4: mov             x4, x1
    //     0x1168ea8: mov             x0, x2
    //     0x1168eac: stur            x1, [fp, #-0x10]
    //     0x1168eb0: stur            x2, [fp, #-0x18]
    //     0x1168eb4: stur            d0, [fp, #-0x70]
    // 0x1168eb8: CheckStackOverflow
    //     0x1168eb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1168ebc: cmp             SP, x16
    //     0x1168ec0: b.ls            #0x1169198
    // 0x1168ec4: cmp             w4, w0
    // 0x1168ec8: b.ne            #0x1168edc
    // 0x1168ecc: mov             x0, x4
    // 0x1168ed0: LeaveFrame
    //     0x1168ed0: mov             SP, fp
    //     0x1168ed4: ldp             fp, lr, [SP], #0x10
    // 0x1168ed8: ret
    //     0x1168ed8: ret             
    // 0x1168edc: LoadField: r1 = r4->field_7
    //     0x1168edc: ldur            w1, [x4, #7]
    // 0x1168ee0: DecompressPointer r1
    //     0x1168ee0: add             x1, x1, HEAP, lsl #32
    // 0x1168ee4: LoadField: r2 = r0->field_7
    //     0x1168ee4: ldur            w2, [x0, #7]
    // 0x1168ee8: DecompressPointer r2
    //     0x1168ee8: add             x2, x2, HEAP, lsl #32
    // 0x1168eec: r5 = inline_Allocate_Double()
    //     0x1168eec: ldp             x5, x3, [THR, #0x60]  ; THR::top
    //     0x1168ef0: add             x5, x5, #0x10
    //     0x1168ef4: cmp             x3, x5
    //     0x1168ef8: b.ls            #0x11691a0
    //     0x1168efc: str             x5, [THR, #0x60]  ; THR::top
    //     0x1168f00: sub             x5, x5, #0xf
    //     0x1168f04: mov             x3, #0xe19c
    //     0x1168f08: movk            x3, #3, lsl #16
    //     0x1168f0c: stur            x3, [x5, #-1]
    // 0x1168f10: dmb             ishst
    // 0x1168f14: StoreField: r5->field_7 = d0
    //     0x1168f14: stur            d0, [x5, #7]
    // 0x1168f18: mov             x3, x5
    // 0x1168f1c: stur            x5, [fp, #-8]
    // 0x1168f20: r0 = lerp()
    //     0x1168f20: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168f24: ldur            x3, [fp, #-8]
    // 0x1168f28: r1 = Null
    //     0x1168f28: mov             x1, NULL
    // 0x1168f2c: r2 = Null
    //     0x1168f2c: mov             x2, NULL
    // 0x1168f30: stur            x0, [fp, #-0x20]
    // 0x1168f34: r0 = lerp()
    //     0x1168f34: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168f38: ldur            x0, [fp, #-0x10]
    // 0x1168f3c: LoadField: r1 = r0->field_f
    //     0x1168f3c: ldur            w1, [x0, #0xf]
    // 0x1168f40: DecompressPointer r1
    //     0x1168f40: add             x1, x1, HEAP, lsl #32
    // 0x1168f44: ldur            x4, [fp, #-0x18]
    // 0x1168f48: LoadField: r2 = r4->field_f
    //     0x1168f48: ldur            w2, [x4, #0xf]
    // 0x1168f4c: DecompressPointer r2
    //     0x1168f4c: add             x2, x2, HEAP, lsl #32
    // 0x1168f50: ldur            x3, [fp, #-8]
    // 0x1168f54: r0 = lerpDouble()
    //     0x1168f54: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1168f58: mov             x4, x0
    // 0x1168f5c: ldur            x0, [fp, #-0x10]
    // 0x1168f60: stur            x4, [fp, #-0x28]
    // 0x1168f64: LoadField: r1 = r0->field_13
    //     0x1168f64: ldur            w1, [x0, #0x13]
    // 0x1168f68: DecompressPointer r1
    //     0x1168f68: add             x1, x1, HEAP, lsl #32
    // 0x1168f6c: ldur            x5, [fp, #-0x18]
    // 0x1168f70: LoadField: r2 = r5->field_13
    //     0x1168f70: ldur            w2, [x5, #0x13]
    // 0x1168f74: DecompressPointer r2
    //     0x1168f74: add             x2, x2, HEAP, lsl #32
    // 0x1168f78: ldur            x3, [fp, #-8]
    // 0x1168f7c: r0 = lerpDouble()
    //     0x1168f7c: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1168f80: mov             x4, x0
    // 0x1168f84: ldur            x0, [fp, #-0x10]
    // 0x1168f88: stur            x4, [fp, #-0x30]
    // 0x1168f8c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1168f8c: ldur            w1, [x0, #0x17]
    // 0x1168f90: DecompressPointer r1
    //     0x1168f90: add             x1, x1, HEAP, lsl #32
    // 0x1168f94: ldur            x5, [fp, #-0x18]
    // 0x1168f98: ArrayLoad: r2 = r5[0]  ; List_4
    //     0x1168f98: ldur            w2, [x5, #0x17]
    // 0x1168f9c: DecompressPointer r2
    //     0x1168f9c: add             x2, x2, HEAP, lsl #32
    // 0x1168fa0: ldur            x3, [fp, #-8]
    // 0x1168fa4: r0 = lerp()
    //     0x1168fa4: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168fa8: ldur            x3, [fp, #-8]
    // 0x1168fac: r1 = Null
    //     0x1168fac: mov             x1, NULL
    // 0x1168fb0: r2 = Null
    //     0x1168fb0: mov             x2, NULL
    // 0x1168fb4: stur            x0, [fp, #-0x38]
    // 0x1168fb8: r0 = lerp()
    //     0x1168fb8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168fbc: ldur            d0, [fp, #-0x70]
    // 0x1168fc0: r1 = Null
    //     0x1168fc0: mov             x1, NULL
    // 0x1168fc4: r2 = Null
    //     0x1168fc4: mov             x2, NULL
    // 0x1168fc8: r0 = lerp()
    //     0x1168fc8: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x1168fcc: ldur            x0, [fp, #-0x10]
    // 0x1168fd0: LoadField: r1 = r0->field_23
    //     0x1168fd0: ldur            w1, [x0, #0x23]
    // 0x1168fd4: DecompressPointer r1
    //     0x1168fd4: add             x1, x1, HEAP, lsl #32
    // 0x1168fd8: ldur            x4, [fp, #-0x18]
    // 0x1168fdc: LoadField: r2 = r4->field_23
    //     0x1168fdc: ldur            w2, [x4, #0x23]
    // 0x1168fe0: DecompressPointer r2
    //     0x1168fe0: add             x2, x2, HEAP, lsl #32
    // 0x1168fe4: ldur            x3, [fp, #-8]
    // 0x1168fe8: r0 = lerp()
    //     0x1168fe8: bl              #0xfb012c  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::lerp
    // 0x1168fec: mov             x4, x0
    // 0x1168ff0: ldur            x0, [fp, #-0x10]
    // 0x1168ff4: stur            x4, [fp, #-0x40]
    // 0x1168ff8: LoadField: r1 = r0->field_27
    //     0x1168ff8: ldur            w1, [x0, #0x27]
    // 0x1168ffc: DecompressPointer r1
    //     0x1168ffc: add             x1, x1, HEAP, lsl #32
    // 0x1169000: ldur            x5, [fp, #-0x18]
    // 0x1169004: LoadField: r2 = r5->field_27
    //     0x1169004: ldur            w2, [x5, #0x27]
    // 0x1169008: DecompressPointer r2
    //     0x1169008: add             x2, x2, HEAP, lsl #32
    // 0x116900c: ldur            x3, [fp, #-8]
    // 0x1169010: r0 = lerp()
    //     0x1169010: bl              #0xfb012c  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::lerp
    // 0x1169014: mov             x4, x0
    // 0x1169018: ldur            x0, [fp, #-0x10]
    // 0x116901c: stur            x4, [fp, #-0x48]
    // 0x1169020: LoadField: r1 = r0->field_2f
    //     0x1169020: ldur            w1, [x0, #0x2f]
    // 0x1169024: DecompressPointer r1
    //     0x1169024: add             x1, x1, HEAP, lsl #32
    // 0x1169028: ldur            x5, [fp, #-0x18]
    // 0x116902c: LoadField: r2 = r5->field_2f
    //     0x116902c: ldur            w2, [x5, #0x2f]
    // 0x1169030: DecompressPointer r2
    //     0x1169030: add             x2, x2, HEAP, lsl #32
    // 0x1169034: ldur            x3, [fp, #-8]
    // 0x1169038: r0 = lerpDouble()
    //     0x1169038: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x116903c: mov             x4, x0
    // 0x1169040: ldur            x0, [fp, #-0x10]
    // 0x1169044: stur            x4, [fp, #-0x50]
    // 0x1169048: LoadField: r1 = r0->field_33
    //     0x1169048: ldur            w1, [x0, #0x33]
    // 0x116904c: DecompressPointer r1
    //     0x116904c: add             x1, x1, HEAP, lsl #32
    // 0x1169050: ldur            x5, [fp, #-0x18]
    // 0x1169054: LoadField: r2 = r5->field_33
    //     0x1169054: ldur            w2, [x5, #0x33]
    // 0x1169058: DecompressPointer r2
    //     0x1169058: add             x2, x2, HEAP, lsl #32
    // 0x116905c: ldur            x3, [fp, #-8]
    // 0x1169060: r0 = lerpDouble()
    //     0x1169060: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1169064: mov             x4, x0
    // 0x1169068: ldur            x0, [fp, #-0x10]
    // 0x116906c: stur            x4, [fp, #-0x58]
    // 0x1169070: LoadField: r1 = r0->field_37
    //     0x1169070: ldur            w1, [x0, #0x37]
    // 0x1169074: DecompressPointer r1
    //     0x1169074: add             x1, x1, HEAP, lsl #32
    // 0x1169078: ldur            x5, [fp, #-0x18]
    // 0x116907c: LoadField: r2 = r5->field_37
    //     0x116907c: ldur            w2, [x5, #0x37]
    // 0x1169080: DecompressPointer r2
    //     0x1169080: add             x2, x2, HEAP, lsl #32
    // 0x1169084: ldur            x3, [fp, #-8]
    // 0x1169088: r0 = lerpDouble()
    //     0x1169088: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x116908c: ldur            x3, [fp, #-8]
    // 0x1169090: r1 = Null
    //     0x1169090: mov             x1, NULL
    // 0x1169094: r2 = Null
    //     0x1169094: mov             x2, NULL
    // 0x1169098: stur            x0, [fp, #-0x60]
    // 0x116909c: r0 = lerp()
    //     0x116909c: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x11690a0: ldur            x0, [fp, #-0x10]
    // 0x11690a4: LoadField: r1 = r0->field_3f
    //     0x11690a4: ldur            w1, [x0, #0x3f]
    // 0x11690a8: DecompressPointer r1
    //     0x11690a8: add             x1, x1, HEAP, lsl #32
    // 0x11690ac: ldur            x4, [fp, #-0x18]
    // 0x11690b0: LoadField: r2 = r4->field_3f
    //     0x11690b0: ldur            w2, [x4, #0x3f]
    // 0x11690b4: DecompressPointer r2
    //     0x11690b4: add             x2, x2, HEAP, lsl #32
    // 0x11690b8: ldur            x3, [fp, #-8]
    // 0x11690bc: r0 = lerp()
    //     0x11690bc: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x11690c0: ldur            d0, [fp, #-0x70]
    // 0x11690c4: d1 = 0.500000
    //     0x11690c4: fmov            d1, #0.50000000
    // 0x11690c8: stur            x0, [fp, #-0x68]
    // 0x11690cc: fcmp            d1, d0
    // 0x11690d0: b.le            #0x11690e8
    // 0x11690d4: ldur            x1, [fp, #-0x10]
    // 0x11690d8: LoadField: r2 = r1->field_43
    //     0x11690d8: ldur            w2, [x1, #0x43]
    // 0x11690dc: DecompressPointer r2
    //     0x11690dc: add             x2, x2, HEAP, lsl #32
    // 0x11690e0: mov             x13, x2
    // 0x11690e4: b               #0x11690f8
    // 0x11690e8: ldur            x1, [fp, #-0x18]
    // 0x11690ec: LoadField: r2 = r1->field_43
    //     0x11690ec: ldur            w2, [x1, #0x43]
    // 0x11690f0: DecompressPointer r2
    //     0x11690f0: add             x2, x2, HEAP, lsl #32
    // 0x11690f4: mov             x13, x2
    // 0x11690f8: ldur            x12, [fp, #-0x20]
    // 0x11690fc: ldur            x11, [fp, #-0x28]
    // 0x1169100: ldur            x10, [fp, #-0x30]
    // 0x1169104: ldur            x9, [fp, #-0x38]
    // 0x1169108: ldur            x8, [fp, #-0x40]
    // 0x116910c: ldur            x7, [fp, #-0x48]
    // 0x1169110: ldur            x6, [fp, #-0x50]
    // 0x1169114: ldur            x5, [fp, #-0x58]
    // 0x1169118: ldur            x4, [fp, #-0x60]
    // 0x116911c: ldur            x3, [fp, #-8]
    // 0x1169120: stur            x13, [fp, #-0x10]
    // 0x1169124: r1 = Null
    //     0x1169124: mov             x1, NULL
    // 0x1169128: r2 = Null
    //     0x1169128: mov             x2, NULL
    // 0x116912c: r0 = lerp()
    //     0x116912c: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x1169130: r0 = AppBarThemeData()
    //     0x1169130: bl              #0x8ac780  ; AllocateAppBarThemeDataStub -> AppBarThemeData (size=0x4c)
    // 0x1169134: ldur            x1, [fp, #-0x20]
    // 0x1169138: StoreField: r0->field_7 = r1
    //     0x1169138: stur            w1, [x0, #7]
    // 0x116913c: ldur            x1, [fp, #-0x28]
    // 0x1169140: StoreField: r0->field_f = r1
    //     0x1169140: stur            w1, [x0, #0xf]
    // 0x1169144: ldur            x1, [fp, #-0x30]
    // 0x1169148: StoreField: r0->field_13 = r1
    //     0x1169148: stur            w1, [x0, #0x13]
    // 0x116914c: ldur            x1, [fp, #-0x38]
    // 0x1169150: ArrayStore: r0[0] = r1  ; List_4
    //     0x1169150: stur            w1, [x0, #0x17]
    // 0x1169154: ldur            x1, [fp, #-0x40]
    // 0x1169158: StoreField: r0->field_23 = r1
    //     0x1169158: stur            w1, [x0, #0x23]
    // 0x116915c: ldur            x1, [fp, #-0x48]
    // 0x1169160: StoreField: r0->field_27 = r1
    //     0x1169160: stur            w1, [x0, #0x27]
    // 0x1169164: ldur            x1, [fp, #-0x50]
    // 0x1169168: StoreField: r0->field_2f = r1
    //     0x1169168: stur            w1, [x0, #0x2f]
    // 0x116916c: ldur            x1, [fp, #-0x58]
    // 0x1169170: StoreField: r0->field_33 = r1
    //     0x1169170: stur            w1, [x0, #0x33]
    // 0x1169174: ldur            x1, [fp, #-0x60]
    // 0x1169178: StoreField: r0->field_37 = r1
    //     0x1169178: stur            w1, [x0, #0x37]
    // 0x116917c: ldur            x1, [fp, #-0x68]
    // 0x1169180: StoreField: r0->field_3f = r1
    //     0x1169180: stur            w1, [x0, #0x3f]
    // 0x1169184: ldur            x1, [fp, #-0x10]
    // 0x1169188: StoreField: r0->field_43 = r1
    //     0x1169188: stur            w1, [x0, #0x43]
    // 0x116918c: LeaveFrame
    //     0x116918c: mov             SP, fp
    //     0x1169190: ldp             fp, lr, [SP], #0x10
    // 0x1169194: ret
    //     0x1169194: ret             
    // 0x1169198: r0 = StackOverflowSharedWithFPURegs()
    //     0x1169198: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x116919c: b               #0x1168ec4
    // 0x11691a0: SaveReg d0
    //     0x11691a0: str             q0, [SP, #-0x10]!
    // 0x11691a4: stp             x2, x4, [SP, #-0x10]!
    // 0x11691a8: stp             x0, x1, [SP, #-0x10]!
    // 0x11691ac: r0 = AllocateDouble()
    //     0x11691ac: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11691b0: mov             x5, x0
    // 0x11691b4: ldp             x0, x1, [SP], #0x10
    // 0x11691b8: ldp             x2, x4, [SP], #0x10
    // 0x11691bc: RestoreReg d0
    //     0x11691bc: ldr             q0, [SP], #0x10
    // 0x11691c0: b               #0x1168f14
  }
  _ ==(/* No info */) {
    // ** addr: 0x126324c, size: 0xce8
    // 0x126324c: EnterFrame
    //     0x126324c: stp             fp, lr, [SP, #-0x10]!
    //     0x1263250: mov             fp, SP
    // 0x1263254: AllocStack(0x30)
    //     0x1263254: sub             SP, SP, #0x30
    // 0x1263258: CheckStackOverflow
    //     0x1263258: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x126325c: cmp             SP, x16
    //     0x1263260: b.ls            #0x1263f2c
    // 0x1263264: ldr             x1, [fp, #0x10]
    // 0x1263268: cmp             w1, NULL
    // 0x126326c: b.ne            #0x1263280
    // 0x1263270: r0 = false
    //     0x1263270: add             x0, NULL, #0x30  ; false
    // 0x1263274: LeaveFrame
    //     0x1263274: mov             SP, fp
    //     0x1263278: ldp             fp, lr, [SP], #0x10
    // 0x126327c: ret
    //     0x126327c: ret             
    // 0x1263280: ldr             x0, [fp, #0x18]
    // 0x1263284: cmp             w0, w1
    // 0x1263288: b.ne            #0x126329c
    // 0x126328c: r0 = true
    //     0x126328c: add             x0, NULL, #0x20  ; true
    // 0x1263290: LeaveFrame
    //     0x1263290: mov             SP, fp
    //     0x1263294: ldp             fp, lr, [SP], #0x10
    // 0x1263298: ret
    //     0x1263298: ret             
    // 0x126329c: stp             x0, x1, [SP]
    // 0x12632a0: r0 = _haveSameRuntimeType()
    //     0x12632a0: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x12632a4: tbz             w0, #4, #0x12632b8
    // 0x12632a8: r0 = false
    //     0x12632a8: add             x0, NULL, #0x30  ; false
    // 0x12632ac: LeaveFrame
    //     0x12632ac: mov             SP, fp
    //     0x12632b0: ldp             fp, lr, [SP], #0x10
    // 0x12632b4: ret
    //     0x12632b4: ret             
    // 0x12632b8: ldr             x0, [fp, #0x10]
    // 0x12632bc: r2 = 60
    //     0x12632bc: mov             x2, #0x3c
    // 0x12632c0: branchIfSmi(r0, 0x12632cc)
    //     0x12632c0: tbz             w0, #0, #0x12632cc
    // 0x12632c4: r2 = LoadClassIdInstr(r0)
    //     0x12632c4: ldur            x2, [x0, #-1]
    //     0x12632c8: ubfx            x2, x2, #0xc, #0x14
    // 0x12632cc: stur            x2, [fp, #-8]
    // 0x12632d0: r17 = -5209
    //     0x12632d0: mov             x17, #-0x1459
    // 0x12632d4: add             x16, x2, x17
    // 0x12632d8: cmp             x16, #2
    // 0x12632dc: b.hi            #0x1263f1c
    // 0x12632e0: r17 = 5209
    //     0x12632e0: mov             x17, #0x1459
    // 0x12632e4: cmp             x2, x17
    // 0x12632e8: b.ne            #0x12632fc
    // 0x12632ec: LoadField: r1 = r0->field_7
    //     0x12632ec: ldur            w1, [x0, #7]
    // 0x12632f0: DecompressPointer r1
    //     0x12632f0: add             x1, x1, HEAP, lsl #32
    // 0x12632f4: mov             x2, x1
    // 0x12632f8: b               #0x1263394
    // 0x12632fc: r17 = 5210
    //     0x12632fc: mov             x17, #0x145a
    // 0x1263300: cmp             x2, x17
    // 0x1263304: b.ne            #0x126333c
    // 0x1263308: mov             x1, x0
    // 0x126330c: LoadField: r0 = r1->field_53
    //     0x126330c: ldur            w0, [x1, #0x53]
    // 0x1263310: DecompressPointer r0
    //     0x1263310: add             x0, x0, HEAP, lsl #32
    // 0x1263314: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1263318: cmp             w0, w16
    // 0x126331c: b.ne            #0x126332c
    // 0x1263320: r2 = _colors
    //     0x1263320: add             x2, PP, #0x26, lsl #12  ; [pp+0x26588] Field <_AppBarDefaultsM3@25187611._colors@25187611>: late final (offset: 0x54)
    //     0x1263324: ldr             x2, [x2, #0x588]
    // 0x1263328: r0 = InitLateFinalInstanceField()
    //     0x1263328: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126332c: LoadField: r1 = r0->field_7b
    //     0x126332c: ldur            w1, [x0, #0x7b]
    // 0x1263330: DecompressPointer r1
    //     0x1263330: add             x1, x1, HEAP, lsl #32
    // 0x1263334: mov             x2, x1
    // 0x1263338: b               #0x1263394
    // 0x126333c: ldr             x1, [fp, #0x10]
    // 0x1263340: LoadField: r0 = r1->field_53
    //     0x1263340: ldur            w0, [x1, #0x53]
    // 0x1263344: DecompressPointer r0
    //     0x1263344: add             x0, x0, HEAP, lsl #32
    // 0x1263348: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126334c: cmp             w0, w16
    // 0x1263350: b.ne            #0x1263360
    // 0x1263354: r2 = _colors
    //     0x1263354: add             x2, PP, #0x26, lsl #12  ; [pp+0x26590] Field <_AppBarDefaultsM2@25187611._colors@25187611>: late final (offset: 0x54)
    //     0x1263358: ldr             x2, [x2, #0x590]
    // 0x126335c: r0 = InitLateFinalInstanceField()
    //     0x126335c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1263360: LoadField: r1 = r0->field_7
    //     0x1263360: ldur            w1, [x0, #7]
    // 0x1263364: DecompressPointer r1
    //     0x1263364: add             x1, x1, HEAP, lsl #32
    // 0x1263368: r16 = Instance_Brightness
    //     0x1263368: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x126336c: cmp             w1, w16
    // 0x1263370: b.ne            #0x1263384
    // 0x1263374: LoadField: r1 = r0->field_7b
    //     0x1263374: ldur            w1, [x0, #0x7b]
    // 0x1263378: DecompressPointer r1
    //     0x1263378: add             x1, x1, HEAP, lsl #32
    // 0x126337c: mov             x0, x1
    // 0x1263380: b               #0x1263390
    // 0x1263384: LoadField: r1 = r0->field_b
    //     0x1263384: ldur            w1, [x0, #0xb]
    // 0x1263388: DecompressPointer r1
    //     0x1263388: add             x1, x1, HEAP, lsl #32
    // 0x126338c: mov             x0, x1
    // 0x1263390: mov             x2, x0
    // 0x1263394: ldr             x0, [fp, #0x18]
    // 0x1263398: stur            x2, [fp, #-0x18]
    // 0x126339c: r3 = LoadClassIdInstr(r0)
    //     0x126339c: ldur            x3, [x0, #-1]
    //     0x12633a0: ubfx            x3, x3, #0xc, #0x14
    // 0x12633a4: stur            x3, [fp, #-0x10]
    // 0x12633a8: r17 = 5209
    //     0x12633a8: mov             x17, #0x1459
    // 0x12633ac: cmp             x3, x17
    // 0x12633b0: b.ne            #0x12633c4
    // 0x12633b4: LoadField: r1 = r0->field_7
    //     0x12633b4: ldur            w1, [x0, #7]
    // 0x12633b8: DecompressPointer r1
    //     0x12633b8: add             x1, x1, HEAP, lsl #32
    // 0x12633bc: mov             x0, x2
    // 0x12633c0: b               #0x1263460
    // 0x12633c4: r17 = 5210
    //     0x12633c4: mov             x17, #0x145a
    // 0x12633c8: cmp             x3, x17
    // 0x12633cc: b.ne            #0x1263404
    // 0x12633d0: mov             x1, x0
    // 0x12633d4: LoadField: r0 = r1->field_53
    //     0x12633d4: ldur            w0, [x1, #0x53]
    // 0x12633d8: DecompressPointer r0
    //     0x12633d8: add             x0, x0, HEAP, lsl #32
    // 0x12633dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12633e0: cmp             w0, w16
    // 0x12633e4: b.ne            #0x12633f4
    // 0x12633e8: r2 = _colors
    //     0x12633e8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26588] Field <_AppBarDefaultsM3@25187611._colors@25187611>: late final (offset: 0x54)
    //     0x12633ec: ldr             x2, [x2, #0x588]
    // 0x12633f0: r0 = InitLateFinalInstanceField()
    //     0x12633f0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12633f4: LoadField: r1 = r0->field_7b
    //     0x12633f4: ldur            w1, [x0, #0x7b]
    // 0x12633f8: DecompressPointer r1
    //     0x12633f8: add             x1, x1, HEAP, lsl #32
    // 0x12633fc: ldur            x0, [fp, #-0x18]
    // 0x1263400: b               #0x1263460
    // 0x1263404: ldr             x1, [fp, #0x18]
    // 0x1263408: LoadField: r0 = r1->field_53
    //     0x1263408: ldur            w0, [x1, #0x53]
    // 0x126340c: DecompressPointer r0
    //     0x126340c: add             x0, x0, HEAP, lsl #32
    // 0x1263410: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1263414: cmp             w0, w16
    // 0x1263418: b.ne            #0x1263428
    // 0x126341c: r2 = _colors
    //     0x126341c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26590] Field <_AppBarDefaultsM2@25187611._colors@25187611>: late final (offset: 0x54)
    //     0x1263420: ldr             x2, [x2, #0x590]
    // 0x1263424: r0 = InitLateFinalInstanceField()
    //     0x1263424: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1263428: LoadField: r1 = r0->field_7
    //     0x1263428: ldur            w1, [x0, #7]
    // 0x126342c: DecompressPointer r1
    //     0x126342c: add             x1, x1, HEAP, lsl #32
    // 0x1263430: r16 = Instance_Brightness
    //     0x1263430: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x1263434: cmp             w1, w16
    // 0x1263438: b.ne            #0x126344c
    // 0x126343c: LoadField: r1 = r0->field_7b
    //     0x126343c: ldur            w1, [x0, #0x7b]
    // 0x1263440: DecompressPointer r1
    //     0x1263440: add             x1, x1, HEAP, lsl #32
    // 0x1263444: mov             x0, x1
    // 0x1263448: b               #0x1263458
    // 0x126344c: LoadField: r1 = r0->field_b
    //     0x126344c: ldur            w1, [x0, #0xb]
    // 0x1263450: DecompressPointer r1
    //     0x1263450: add             x1, x1, HEAP, lsl #32
    // 0x1263454: mov             x0, x1
    // 0x1263458: mov             x1, x0
    // 0x126345c: ldur            x0, [fp, #-0x18]
    // 0x1263460: r2 = LoadClassIdInstr(r0)
    //     0x1263460: ldur            x2, [x0, #-1]
    //     0x1263464: ubfx            x2, x2, #0xc, #0x14
    // 0x1263468: stp             x1, x0, [SP]
    // 0x126346c: mov             x0, x2
    // 0x1263470: mov             lr, x0
    // 0x1263474: ldr             lr, [x21, lr, lsl #3]
    // 0x1263478: blr             lr
    // 0x126347c: tbnz            w0, #4, #0x1263f1c
    // 0x1263480: ldur            x0, [fp, #-8]
    // 0x1263484: r17 = 5209
    //     0x1263484: mov             x17, #0x1459
    // 0x1263488: cmp             x0, x17
    // 0x126348c: b.ne            #0x12634a4
    // 0x1263490: ldr             x2, [fp, #0x10]
    // 0x1263494: LoadField: r1 = r2->field_b
    //     0x1263494: ldur            w1, [x2, #0xb]
    // 0x1263498: DecompressPointer r1
    //     0x1263498: add             x1, x1, HEAP, lsl #32
    // 0x126349c: mov             x2, x1
    // 0x12634a0: b               #0x1263540
    // 0x12634a4: ldr             x2, [fp, #0x10]
    // 0x12634a8: r17 = 5210
    //     0x12634a8: mov             x17, #0x145a
    // 0x12634ac: cmp             x0, x17
    // 0x12634b0: b.ne            #0x12634e8
    // 0x12634b4: mov             x1, x2
    // 0x12634b8: LoadField: r0 = r1->field_53
    //     0x12634b8: ldur            w0, [x1, #0x53]
    // 0x12634bc: DecompressPointer r0
    //     0x12634bc: add             x0, x0, HEAP, lsl #32
    // 0x12634c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12634c4: cmp             w0, w16
    // 0x12634c8: b.ne            #0x12634d8
    // 0x12634cc: r2 = _colors
    //     0x12634cc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26588] Field <_AppBarDefaultsM3@25187611._colors@25187611>: late final (offset: 0x54)
    //     0x12634d0: ldr             x2, [x2, #0x588]
    // 0x12634d4: r0 = InitLateFinalInstanceField()
    //     0x12634d4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12634d8: LoadField: r1 = r0->field_7f
    //     0x12634d8: ldur            w1, [x0, #0x7f]
    // 0x12634dc: DecompressPointer r1
    //     0x12634dc: add             x1, x1, HEAP, lsl #32
    // 0x12634e0: mov             x2, x1
    // 0x12634e4: b               #0x1263540
    // 0x12634e8: ldr             x1, [fp, #0x10]
    // 0x12634ec: LoadField: r0 = r1->field_53
    //     0x12634ec: ldur            w0, [x1, #0x53]
    // 0x12634f0: DecompressPointer r0
    //     0x12634f0: add             x0, x0, HEAP, lsl #32
    // 0x12634f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12634f8: cmp             w0, w16
    // 0x12634fc: b.ne            #0x126350c
    // 0x1263500: r2 = _colors
    //     0x1263500: add             x2, PP, #0x26, lsl #12  ; [pp+0x26590] Field <_AppBarDefaultsM2@25187611._colors@25187611>: late final (offset: 0x54)
    //     0x1263504: ldr             x2, [x2, #0x590]
    // 0x1263508: r0 = InitLateFinalInstanceField()
    //     0x1263508: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126350c: LoadField: r1 = r0->field_7
    //     0x126350c: ldur            w1, [x0, #7]
    // 0x1263510: DecompressPointer r1
    //     0x1263510: add             x1, x1, HEAP, lsl #32
    // 0x1263514: r16 = Instance_Brightness
    //     0x1263514: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x1263518: cmp             w1, w16
    // 0x126351c: b.ne            #0x1263530
    // 0x1263520: LoadField: r1 = r0->field_7f
    //     0x1263520: ldur            w1, [x0, #0x7f]
    // 0x1263524: DecompressPointer r1
    //     0x1263524: add             x1, x1, HEAP, lsl #32
    // 0x1263528: mov             x0, x1
    // 0x126352c: b               #0x126353c
    // 0x1263530: LoadField: r1 = r0->field_f
    //     0x1263530: ldur            w1, [x0, #0xf]
    // 0x1263534: DecompressPointer r1
    //     0x1263534: add             x1, x1, HEAP, lsl #32
    // 0x1263538: mov             x0, x1
    // 0x126353c: mov             x2, x0
    // 0x1263540: ldur            x0, [fp, #-0x10]
    // 0x1263544: stur            x2, [fp, #-0x18]
    // 0x1263548: r17 = 5209
    //     0x1263548: mov             x17, #0x1459
    // 0x126354c: cmp             x0, x17
    // 0x1263550: b.ne            #0x1263568
    // 0x1263554: ldr             x3, [fp, #0x18]
    // 0x1263558: LoadField: r1 = r3->field_b
    //     0x1263558: ldur            w1, [x3, #0xb]
    // 0x126355c: DecompressPointer r1
    //     0x126355c: add             x1, x1, HEAP, lsl #32
    // 0x1263560: mov             x0, x2
    // 0x1263564: b               #0x1263608
    // 0x1263568: ldr             x3, [fp, #0x18]
    // 0x126356c: r17 = 5210
    //     0x126356c: mov             x17, #0x145a
    // 0x1263570: cmp             x0, x17
    // 0x1263574: b.ne            #0x12635ac
    // 0x1263578: mov             x1, x3
    // 0x126357c: LoadField: r0 = r1->field_53
    //     0x126357c: ldur            w0, [x1, #0x53]
    // 0x1263580: DecompressPointer r0
    //     0x1263580: add             x0, x0, HEAP, lsl #32
    // 0x1263584: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1263588: cmp             w0, w16
    // 0x126358c: b.ne            #0x126359c
    // 0x1263590: r2 = _colors
    //     0x1263590: add             x2, PP, #0x26, lsl #12  ; [pp+0x26588] Field <_AppBarDefaultsM3@25187611._colors@25187611>: late final (offset: 0x54)
    //     0x1263594: ldr             x2, [x2, #0x588]
    // 0x1263598: r0 = InitLateFinalInstanceField()
    //     0x1263598: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126359c: LoadField: r1 = r0->field_7f
    //     0x126359c: ldur            w1, [x0, #0x7f]
    // 0x12635a0: DecompressPointer r1
    //     0x12635a0: add             x1, x1, HEAP, lsl #32
    // 0x12635a4: ldur            x0, [fp, #-0x18]
    // 0x12635a8: b               #0x1263608
    // 0x12635ac: ldr             x1, [fp, #0x18]
    // 0x12635b0: LoadField: r0 = r1->field_53
    //     0x12635b0: ldur            w0, [x1, #0x53]
    // 0x12635b4: DecompressPointer r0
    //     0x12635b4: add             x0, x0, HEAP, lsl #32
    // 0x12635b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12635bc: cmp             w0, w16
    // 0x12635c0: b.ne            #0x12635d0
    // 0x12635c4: r2 = _colors
    //     0x12635c4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26590] Field <_AppBarDefaultsM2@25187611._colors@25187611>: late final (offset: 0x54)
    //     0x12635c8: ldr             x2, [x2, #0x590]
    // 0x12635cc: r0 = InitLateFinalInstanceField()
    //     0x12635cc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12635d0: LoadField: r1 = r0->field_7
    //     0x12635d0: ldur            w1, [x0, #7]
    // 0x12635d4: DecompressPointer r1
    //     0x12635d4: add             x1, x1, HEAP, lsl #32
    // 0x12635d8: r16 = Instance_Brightness
    //     0x12635d8: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x12635dc: cmp             w1, w16
    // 0x12635e0: b.ne            #0x12635f4
    // 0x12635e4: LoadField: r1 = r0->field_7f
    //     0x12635e4: ldur            w1, [x0, #0x7f]
    // 0x12635e8: DecompressPointer r1
    //     0x12635e8: add             x1, x1, HEAP, lsl #32
    // 0x12635ec: mov             x0, x1
    // 0x12635f0: b               #0x1263600
    // 0x12635f4: LoadField: r1 = r0->field_f
    //     0x12635f4: ldur            w1, [x0, #0xf]
    // 0x12635f8: DecompressPointer r1
    //     0x12635f8: add             x1, x1, HEAP, lsl #32
    // 0x12635fc: mov             x0, x1
    // 0x1263600: mov             x1, x0
    // 0x1263604: ldur            x0, [fp, #-0x18]
    // 0x1263608: r2 = LoadClassIdInstr(r0)
    //     0x1263608: ldur            x2, [x0, #-1]
    //     0x126360c: ubfx            x2, x2, #0xc, #0x14
    // 0x1263610: stp             x1, x0, [SP]
    // 0x1263614: mov             x0, x2
    // 0x1263618: mov             lr, x0
    // 0x126361c: ldr             lr, [x21, lr, lsl #3]
    // 0x1263620: blr             lr
    // 0x1263624: tbnz            w0, #4, #0x1263f1c
    // 0x1263628: ldr             x1, [fp, #0x18]
    // 0x126362c: ldr             x2, [fp, #0x10]
    // 0x1263630: LoadField: r0 = r2->field_f
    //     0x1263630: ldur            w0, [x2, #0xf]
    // 0x1263634: DecompressPointer r0
    //     0x1263634: add             x0, x0, HEAP, lsl #32
    // 0x1263638: LoadField: r3 = r1->field_f
    //     0x1263638: ldur            w3, [x1, #0xf]
    // 0x126363c: DecompressPointer r3
    //     0x126363c: add             x3, x3, HEAP, lsl #32
    // 0x1263640: r4 = LoadClassIdInstr(r0)
    //     0x1263640: ldur            x4, [x0, #-1]
    //     0x1263644: ubfx            x4, x4, #0xc, #0x14
    // 0x1263648: stp             x3, x0, [SP]
    // 0x126364c: mov             x0, x4
    // 0x1263650: mov             lr, x0
    // 0x1263654: ldr             lr, [x21, lr, lsl #3]
    // 0x1263658: blr             lr
    // 0x126365c: tbnz            w0, #4, #0x1263f1c
    // 0x1263660: ldr             x1, [fp, #0x18]
    // 0x1263664: ldr             x2, [fp, #0x10]
    // 0x1263668: LoadField: r0 = r2->field_13
    //     0x1263668: ldur            w0, [x2, #0x13]
    // 0x126366c: DecompressPointer r0
    //     0x126366c: add             x0, x0, HEAP, lsl #32
    // 0x1263670: LoadField: r3 = r1->field_13
    //     0x1263670: ldur            w3, [x1, #0x13]
    // 0x1263674: DecompressPointer r3
    //     0x1263674: add             x3, x3, HEAP, lsl #32
    // 0x1263678: r4 = LoadClassIdInstr(r0)
    //     0x1263678: ldur            x4, [x0, #-1]
    //     0x126367c: ubfx            x4, x4, #0xc, #0x14
    // 0x1263680: stp             x3, x0, [SP]
    // 0x1263684: mov             x0, x4
    // 0x1263688: mov             lr, x0
    // 0x126368c: ldr             lr, [x21, lr, lsl #3]
    // 0x1263690: blr             lr
    // 0x1263694: tbnz            w0, #4, #0x1263f1c
    // 0x1263698: ldur            x1, [fp, #-8]
    // 0x126369c: r17 = 5209
    //     0x126369c: mov             x17, #0x1459
    // 0x12636a0: cmp             x1, x17
    // 0x12636a4: b.eq            #0x12636c4
    // 0x12636a8: r17 = 5210
    //     0x12636a8: mov             x17, #0x145a
    // 0x12636ac: cmp             x1, x17
    // 0x12636b0: b.ne            #0x12636c4
    // 0x12636b4: ldr             x2, [fp, #0x10]
    // 0x12636b8: r0 = Instance_Color
    //     0x12636b8: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x12636bc: ldr             x0, [x0, #0x810]
    // 0x12636c0: b               #0x12636d0
    // 0x12636c4: ldr             x2, [fp, #0x10]
    // 0x12636c8: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x12636c8: ldur            w0, [x2, #0x17]
    // 0x12636cc: DecompressPointer r0
    //     0x12636cc: add             x0, x0, HEAP, lsl #32
    // 0x12636d0: ldur            x3, [fp, #-0x10]
    // 0x12636d4: r17 = 5209
    //     0x12636d4: mov             x17, #0x1459
    // 0x12636d8: cmp             x3, x17
    // 0x12636dc: b.eq            #0x12636fc
    // 0x12636e0: r17 = 5210
    //     0x12636e0: mov             x17, #0x145a
    // 0x12636e4: cmp             x3, x17
    // 0x12636e8: b.ne            #0x12636fc
    // 0x12636ec: ldr             x4, [fp, #0x18]
    // 0x12636f0: r5 = Instance_Color
    //     0x12636f0: add             x5, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x12636f4: ldr             x5, [x5, #0x810]
    // 0x12636f8: b               #0x1263708
    // 0x12636fc: ldr             x4, [fp, #0x18]
    // 0x1263700: ArrayLoad: r5 = r4[0]  ; List_4
    //     0x1263700: ldur            w5, [x4, #0x17]
    // 0x1263704: DecompressPointer r5
    //     0x1263704: add             x5, x5, HEAP, lsl #32
    // 0x1263708: r6 = LoadClassIdInstr(r0)
    //     0x1263708: ldur            x6, [x0, #-1]
    //     0x126370c: ubfx            x6, x6, #0xc, #0x14
    // 0x1263710: stp             x5, x0, [SP]
    // 0x1263714: mov             x0, x6
    // 0x1263718: mov             lr, x0
    // 0x126371c: ldr             lr, [x21, lr, lsl #3]
    // 0x1263720: blr             lr
    // 0x1263724: tbnz            w0, #4, #0x1263f1c
    // 0x1263728: ldur            x1, [fp, #-8]
    // 0x126372c: r17 = 5209
    //     0x126372c: mov             x17, #0x1459
    // 0x1263730: cmp             x1, x17
    // 0x1263734: b.eq            #0x1263754
    // 0x1263738: r17 = 5210
    //     0x1263738: mov             x17, #0x145a
    // 0x126373c: cmp             x1, x17
    // 0x1263740: b.ne            #0x1263754
    // 0x1263744: ldr             x2, [fp, #0x10]
    // 0x1263748: r0 = Instance_Color
    //     0x1263748: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x126374c: ldr             x0, [x0, #0x810]
    // 0x1263750: b               #0x1263760
    // 0x1263754: ldr             x2, [fp, #0x10]
    // 0x1263758: LoadField: r0 = r2->field_1b
    //     0x1263758: ldur            w0, [x2, #0x1b]
    // 0x126375c: DecompressPointer r0
    //     0x126375c: add             x0, x0, HEAP, lsl #32
    // 0x1263760: ldur            x3, [fp, #-0x10]
    // 0x1263764: r17 = 5209
    //     0x1263764: mov             x17, #0x1459
    // 0x1263768: cmp             x3, x17
    // 0x126376c: b.eq            #0x126378c
    // 0x1263770: r17 = 5210
    //     0x1263770: mov             x17, #0x145a
    // 0x1263774: cmp             x3, x17
    // 0x1263778: b.ne            #0x126378c
    // 0x126377c: ldr             x4, [fp, #0x18]
    // 0x1263780: r5 = Instance_Color
    //     0x1263780: add             x5, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1263784: ldr             x5, [x5, #0x810]
    // 0x1263788: b               #0x1263798
    // 0x126378c: ldr             x4, [fp, #0x18]
    // 0x1263790: LoadField: r5 = r4->field_1b
    //     0x1263790: ldur            w5, [x4, #0x1b]
    // 0x1263794: DecompressPointer r5
    //     0x1263794: add             x5, x5, HEAP, lsl #32
    // 0x1263798: r6 = LoadClassIdInstr(r0)
    //     0x1263798: ldur            x6, [x0, #-1]
    //     0x126379c: ubfx            x6, x6, #0xc, #0x14
    // 0x12637a0: stp             x5, x0, [SP]
    // 0x12637a4: mov             x0, x6
    // 0x12637a8: mov             lr, x0
    // 0x12637ac: ldr             lr, [x21, lr, lsl #3]
    // 0x12637b0: blr             lr
    // 0x12637b4: tbnz            w0, #4, #0x1263f1c
    // 0x12637b8: ldur            x0, [fp, #-8]
    // 0x12637bc: r17 = 5209
    //     0x12637bc: mov             x17, #0x1459
    // 0x12637c0: cmp             x0, x17
    // 0x12637c4: b.ne            #0x12637dc
    // 0x12637c8: ldr             x2, [fp, #0x10]
    // 0x12637cc: LoadField: r1 = r2->field_23
    //     0x12637cc: ldur            w1, [x2, #0x23]
    // 0x12637d0: DecompressPointer r1
    //     0x12637d0: add             x1, x1, HEAP, lsl #32
    // 0x12637d4: mov             x2, x1
    // 0x12637d8: b               #0x1263878
    // 0x12637dc: ldr             x2, [fp, #0x10]
    // 0x12637e0: r17 = 5210
    //     0x12637e0: mov             x17, #0x145a
    // 0x12637e4: cmp             x0, x17
    // 0x12637e8: b.ne            #0x1263840
    // 0x12637ec: mov             x1, x2
    // 0x12637f0: LoadField: r0 = r1->field_53
    //     0x12637f0: ldur            w0, [x1, #0x53]
    // 0x12637f4: DecompressPointer r0
    //     0x12637f4: add             x0, x0, HEAP, lsl #32
    // 0x12637f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12637fc: cmp             w0, w16
    // 0x1263800: b.ne            #0x1263810
    // 0x1263804: r2 = _colors
    //     0x1263804: add             x2, PP, #0x26, lsl #12  ; [pp+0x26588] Field <_AppBarDefaultsM3@25187611._colors@25187611>: late final (offset: 0x54)
    //     0x1263808: ldr             x2, [x2, #0x588]
    // 0x126380c: r0 = InitLateFinalInstanceField()
    //     0x126380c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1263810: LoadField: r1 = r0->field_7f
    //     0x1263810: ldur            w1, [x0, #0x7f]
    // 0x1263814: DecompressPointer r1
    //     0x1263814: add             x1, x1, HEAP, lsl #32
    // 0x1263818: stur            x1, [fp, #-0x18]
    // 0x126381c: r0 = IconThemeData()
    //     0x126381c: bl              #0x8ac78c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0x1263820: mov             x1, x0
    // 0x1263824: r0 = 24.000000
    //     0x1263824: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0x1263828: ldr             x0, [x0, #0x4d0]
    // 0x126382c: StoreField: r1->field_7 = r0
    //     0x126382c: stur            w0, [x1, #7]
    // 0x1263830: ldur            x2, [fp, #-0x18]
    // 0x1263834: StoreField: r1->field_1b = r2
    //     0x1263834: stur            w2, [x1, #0x1b]
    // 0x1263838: mov             x2, x1
    // 0x126383c: b               #0x1263878
    // 0x1263840: r0 = 24.000000
    //     0x1263840: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0x1263844: ldr             x0, [x0, #0x4d0]
    // 0x1263848: ldr             x1, [fp, #0x10]
    // 0x126384c: LoadField: r0 = r1->field_4f
    //     0x126384c: ldur            w0, [x1, #0x4f]
    // 0x1263850: DecompressPointer r0
    //     0x1263850: add             x0, x0, HEAP, lsl #32
    // 0x1263854: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1263858: cmp             w0, w16
    // 0x126385c: b.ne            #0x126386c
    // 0x1263860: r2 = _theme
    //     0x1263860: add             x2, PP, #0x26, lsl #12  ; [pp+0x26598] Field <_AppBarDefaultsM2@25187611._theme@25187611>: late final (offset: 0x50)
    //     0x1263864: ldr             x2, [x2, #0x598]
    // 0x1263868: r0 = InitLateFinalInstanceField()
    //     0x1263868: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126386c: LoadField: r1 = r0->field_7b
    //     0x126386c: ldur            w1, [x0, #0x7b]
    // 0x1263870: DecompressPointer r1
    //     0x1263870: add             x1, x1, HEAP, lsl #32
    // 0x1263874: mov             x2, x1
    // 0x1263878: ldur            x0, [fp, #-0x10]
    // 0x126387c: stur            x2, [fp, #-0x18]
    // 0x1263880: r17 = 5209
    //     0x1263880: mov             x17, #0x1459
    // 0x1263884: cmp             x0, x17
    // 0x1263888: b.ne            #0x12638a0
    // 0x126388c: ldr             x3, [fp, #0x18]
    // 0x1263890: LoadField: r1 = r3->field_23
    //     0x1263890: ldur            w1, [x3, #0x23]
    // 0x1263894: DecompressPointer r1
    //     0x1263894: add             x1, x1, HEAP, lsl #32
    // 0x1263898: mov             x0, x2
    // 0x126389c: b               #0x126393c
    // 0x12638a0: ldr             x3, [fp, #0x18]
    // 0x12638a4: r17 = 5210
    //     0x12638a4: mov             x17, #0x145a
    // 0x12638a8: cmp             x0, x17
    // 0x12638ac: b.ne            #0x1263904
    // 0x12638b0: mov             x1, x3
    // 0x12638b4: LoadField: r0 = r1->field_53
    //     0x12638b4: ldur            w0, [x1, #0x53]
    // 0x12638b8: DecompressPointer r0
    //     0x12638b8: add             x0, x0, HEAP, lsl #32
    // 0x12638bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12638c0: cmp             w0, w16
    // 0x12638c4: b.ne            #0x12638d4
    // 0x12638c8: r2 = _colors
    //     0x12638c8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26588] Field <_AppBarDefaultsM3@25187611._colors@25187611>: late final (offset: 0x54)
    //     0x12638cc: ldr             x2, [x2, #0x588]
    // 0x12638d0: r0 = InitLateFinalInstanceField()
    //     0x12638d0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12638d4: LoadField: r1 = r0->field_7f
    //     0x12638d4: ldur            w1, [x0, #0x7f]
    // 0x12638d8: DecompressPointer r1
    //     0x12638d8: add             x1, x1, HEAP, lsl #32
    // 0x12638dc: stur            x1, [fp, #-0x20]
    // 0x12638e0: r0 = IconThemeData()
    //     0x12638e0: bl              #0x8ac78c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0x12638e4: mov             x1, x0
    // 0x12638e8: r0 = 24.000000
    //     0x12638e8: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0x12638ec: ldr             x0, [x0, #0x4d0]
    // 0x12638f0: StoreField: r1->field_7 = r0
    //     0x12638f0: stur            w0, [x1, #7]
    // 0x12638f4: ldur            x2, [fp, #-0x20]
    // 0x12638f8: StoreField: r1->field_1b = r2
    //     0x12638f8: stur            w2, [x1, #0x1b]
    // 0x12638fc: ldur            x0, [fp, #-0x18]
    // 0x1263900: b               #0x126393c
    // 0x1263904: r0 = 24.000000
    //     0x1263904: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0x1263908: ldr             x0, [x0, #0x4d0]
    // 0x126390c: ldr             x1, [fp, #0x18]
    // 0x1263910: LoadField: r0 = r1->field_4f
    //     0x1263910: ldur            w0, [x1, #0x4f]
    // 0x1263914: DecompressPointer r0
    //     0x1263914: add             x0, x0, HEAP, lsl #32
    // 0x1263918: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126391c: cmp             w0, w16
    // 0x1263920: b.ne            #0x1263930
    // 0x1263924: r2 = _theme
    //     0x1263924: add             x2, PP, #0x26, lsl #12  ; [pp+0x26598] Field <_AppBarDefaultsM2@25187611._theme@25187611>: late final (offset: 0x50)
    //     0x1263928: ldr             x2, [x2, #0x598]
    // 0x126392c: r0 = InitLateFinalInstanceField()
    //     0x126392c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1263930: LoadField: r1 = r0->field_7b
    //     0x1263930: ldur            w1, [x0, #0x7b]
    // 0x1263934: DecompressPointer r1
    //     0x1263934: add             x1, x1, HEAP, lsl #32
    // 0x1263938: ldur            x0, [fp, #-0x18]
    // 0x126393c: r2 = LoadClassIdInstr(r0)
    //     0x126393c: ldur            x2, [x0, #-1]
    //     0x1263940: ubfx            x2, x2, #0xc, #0x14
    // 0x1263944: stp             x1, x0, [SP]
    // 0x1263948: mov             x0, x2
    // 0x126394c: mov             lr, x0
    // 0x1263950: ldr             lr, [x21, lr, lsl #3]
    // 0x1263954: blr             lr
    // 0x1263958: tbnz            w0, #4, #0x1263f1c
    // 0x126395c: ldur            x0, [fp, #-8]
    // 0x1263960: r17 = 5209
    //     0x1263960: mov             x17, #0x1459
    // 0x1263964: cmp             x0, x17
    // 0x1263968: b.ne            #0x1263978
    // 0x126396c: r0 = 24.000000
    //     0x126396c: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0x1263970: ldr             x0, [x0, #0x4d0]
    // 0x1263974: b               #0x1263a00
    // 0x1263978: r17 = 5210
    //     0x1263978: mov             x17, #0x145a
    // 0x126397c: cmp             x0, x17
    // 0x1263980: b.ne            #0x12639f8
    // 0x1263984: ldr             x1, [fp, #0x10]
    // 0x1263988: LoadField: r0 = r1->field_53
    //     0x1263988: ldur            w0, [x1, #0x53]
    // 0x126398c: DecompressPointer r0
    //     0x126398c: add             x0, x0, HEAP, lsl #32
    // 0x1263990: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1263994: cmp             w0, w16
    // 0x1263998: b.ne            #0x12639a8
    // 0x126399c: r2 = _colors
    //     0x126399c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26588] Field <_AppBarDefaultsM3@25187611._colors@25187611>: late final (offset: 0x54)
    //     0x12639a0: ldr             x2, [x2, #0x588]
    // 0x12639a4: r0 = InitLateFinalInstanceField()
    //     0x12639a4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12639a8: LoadField: r1 = r0->field_a3
    //     0x12639a8: ldur            w1, [x0, #0xa3]
    // 0x12639ac: DecompressPointer r1
    //     0x12639ac: add             x1, x1, HEAP, lsl #32
    // 0x12639b0: cmp             w1, NULL
    // 0x12639b4: b.ne            #0x12639c8
    // 0x12639b8: LoadField: r1 = r0->field_7f
    //     0x12639b8: ldur            w1, [x0, #0x7f]
    // 0x12639bc: DecompressPointer r1
    //     0x12639bc: add             x1, x1, HEAP, lsl #32
    // 0x12639c0: mov             x0, x1
    // 0x12639c4: b               #0x12639cc
    // 0x12639c8: mov             x0, x1
    // 0x12639cc: stur            x0, [fp, #-0x18]
    // 0x12639d0: r0 = IconThemeData()
    //     0x12639d0: bl              #0x8ac78c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0x12639d4: mov             x1, x0
    // 0x12639d8: r0 = 24.000000
    //     0x12639d8: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0x12639dc: ldr             x0, [x0, #0x4d0]
    // 0x12639e0: StoreField: r1->field_7 = r0
    //     0x12639e0: stur            w0, [x1, #7]
    // 0x12639e4: ldur            x2, [fp, #-0x18]
    // 0x12639e8: StoreField: r1->field_1b = r2
    //     0x12639e8: stur            w2, [x1, #0x1b]
    // 0x12639ec: mov             x4, x1
    // 0x12639f0: ldr             x2, [fp, #0x10]
    // 0x12639f4: b               #0x1263a10
    // 0x12639f8: r0 = 24.000000
    //     0x12639f8: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0x12639fc: ldr             x0, [x0, #0x4d0]
    // 0x1263a00: ldr             x2, [fp, #0x10]
    // 0x1263a04: LoadField: r1 = r2->field_27
    //     0x1263a04: ldur            w1, [x2, #0x27]
    // 0x1263a08: DecompressPointer r1
    //     0x1263a08: add             x1, x1, HEAP, lsl #32
    // 0x1263a0c: mov             x4, x1
    // 0x1263a10: ldur            x3, [fp, #-0x10]
    // 0x1263a14: stur            x4, [fp, #-0x18]
    // 0x1263a18: r17 = 5209
    //     0x1263a18: mov             x17, #0x1459
    // 0x1263a1c: cmp             x3, x17
    // 0x1263a20: b.eq            #0x1263aa4
    // 0x1263a24: r17 = 5210
    //     0x1263a24: mov             x17, #0x145a
    // 0x1263a28: cmp             x3, x17
    // 0x1263a2c: b.ne            #0x1263aa4
    // 0x1263a30: ldr             x1, [fp, #0x18]
    // 0x1263a34: LoadField: r0 = r1->field_53
    //     0x1263a34: ldur            w0, [x1, #0x53]
    // 0x1263a38: DecompressPointer r0
    //     0x1263a38: add             x0, x0, HEAP, lsl #32
    // 0x1263a3c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1263a40: cmp             w0, w16
    // 0x1263a44: b.ne            #0x1263a54
    // 0x1263a48: r2 = _colors
    //     0x1263a48: add             x2, PP, #0x26, lsl #12  ; [pp+0x26588] Field <_AppBarDefaultsM3@25187611._colors@25187611>: late final (offset: 0x54)
    //     0x1263a4c: ldr             x2, [x2, #0x588]
    // 0x1263a50: r0 = InitLateFinalInstanceField()
    //     0x1263a50: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1263a54: LoadField: r1 = r0->field_a3
    //     0x1263a54: ldur            w1, [x0, #0xa3]
    // 0x1263a58: DecompressPointer r1
    //     0x1263a58: add             x1, x1, HEAP, lsl #32
    // 0x1263a5c: cmp             w1, NULL
    // 0x1263a60: b.ne            #0x1263a74
    // 0x1263a64: LoadField: r1 = r0->field_7f
    //     0x1263a64: ldur            w1, [x0, #0x7f]
    // 0x1263a68: DecompressPointer r1
    //     0x1263a68: add             x1, x1, HEAP, lsl #32
    // 0x1263a6c: mov             x0, x1
    // 0x1263a70: b               #0x1263a78
    // 0x1263a74: mov             x0, x1
    // 0x1263a78: stur            x0, [fp, #-0x20]
    // 0x1263a7c: r0 = IconThemeData()
    //     0x1263a7c: bl              #0x8ac78c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0x1263a80: mov             x1, x0
    // 0x1263a84: r0 = 24.000000
    //     0x1263a84: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0x1263a88: ldr             x0, [x0, #0x4d0]
    // 0x1263a8c: StoreField: r1->field_7 = r0
    //     0x1263a8c: stur            w0, [x1, #7]
    // 0x1263a90: ldur            x0, [fp, #-0x20]
    // 0x1263a94: StoreField: r1->field_1b = r0
    //     0x1263a94: stur            w0, [x1, #0x1b]
    // 0x1263a98: mov             x2, x1
    // 0x1263a9c: ldr             x1, [fp, #0x18]
    // 0x1263aa0: b               #0x1263ab4
    // 0x1263aa4: ldr             x1, [fp, #0x18]
    // 0x1263aa8: LoadField: r0 = r1->field_27
    //     0x1263aa8: ldur            w0, [x1, #0x27]
    // 0x1263aac: DecompressPointer r0
    //     0x1263aac: add             x0, x0, HEAP, lsl #32
    // 0x1263ab0: mov             x2, x0
    // 0x1263ab4: ldur            x0, [fp, #-0x18]
    // 0x1263ab8: r3 = LoadClassIdInstr(r0)
    //     0x1263ab8: ldur            x3, [x0, #-1]
    //     0x1263abc: ubfx            x3, x3, #0xc, #0x14
    // 0x1263ac0: stp             x2, x0, [SP]
    // 0x1263ac4: mov             x0, x3
    // 0x1263ac8: mov             lr, x0
    // 0x1263acc: ldr             lr, [x21, lr, lsl #3]
    // 0x1263ad0: blr             lr
    // 0x1263ad4: tbnz            w0, #4, #0x1263f1c
    // 0x1263ad8: ldr             x1, [fp, #0x18]
    // 0x1263adc: ldr             x2, [fp, #0x10]
    // 0x1263ae0: LoadField: r0 = r2->field_2f
    //     0x1263ae0: ldur            w0, [x2, #0x2f]
    // 0x1263ae4: DecompressPointer r0
    //     0x1263ae4: add             x0, x0, HEAP, lsl #32
    // 0x1263ae8: LoadField: r3 = r1->field_2f
    //     0x1263ae8: ldur            w3, [x1, #0x2f]
    // 0x1263aec: DecompressPointer r3
    //     0x1263aec: add             x3, x3, HEAP, lsl #32
    // 0x1263af0: r4 = LoadClassIdInstr(r0)
    //     0x1263af0: ldur            x4, [x0, #-1]
    //     0x1263af4: ubfx            x4, x4, #0xc, #0x14
    // 0x1263af8: stp             x3, x0, [SP]
    // 0x1263afc: mov             x0, x4
    // 0x1263b00: mov             lr, x0
    // 0x1263b04: ldr             lr, [x21, lr, lsl #3]
    // 0x1263b08: blr             lr
    // 0x1263b0c: tbnz            w0, #4, #0x1263f1c
    // 0x1263b10: ldr             x1, [fp, #0x18]
    // 0x1263b14: ldr             x2, [fp, #0x10]
    // 0x1263b18: LoadField: r0 = r2->field_33
    //     0x1263b18: ldur            w0, [x2, #0x33]
    // 0x1263b1c: DecompressPointer r0
    //     0x1263b1c: add             x0, x0, HEAP, lsl #32
    // 0x1263b20: LoadField: r3 = r1->field_33
    //     0x1263b20: ldur            w3, [x1, #0x33]
    // 0x1263b24: DecompressPointer r3
    //     0x1263b24: add             x3, x3, HEAP, lsl #32
    // 0x1263b28: r4 = LoadClassIdInstr(r0)
    //     0x1263b28: ldur            x4, [x0, #-1]
    //     0x1263b2c: ubfx            x4, x4, #0xc, #0x14
    // 0x1263b30: stp             x3, x0, [SP]
    // 0x1263b34: mov             x0, x4
    // 0x1263b38: mov             lr, x0
    // 0x1263b3c: ldr             lr, [x21, lr, lsl #3]
    // 0x1263b40: blr             lr
    // 0x1263b44: tbnz            w0, #4, #0x1263f1c
    // 0x1263b48: ldr             x1, [fp, #0x18]
    // 0x1263b4c: ldr             x2, [fp, #0x10]
    // 0x1263b50: LoadField: r0 = r2->field_37
    //     0x1263b50: ldur            w0, [x2, #0x37]
    // 0x1263b54: DecompressPointer r0
    //     0x1263b54: add             x0, x0, HEAP, lsl #32
    // 0x1263b58: LoadField: r3 = r1->field_37
    //     0x1263b58: ldur            w3, [x1, #0x37]
    // 0x1263b5c: DecompressPointer r3
    //     0x1263b5c: add             x3, x3, HEAP, lsl #32
    // 0x1263b60: r4 = LoadClassIdInstr(r0)
    //     0x1263b60: ldur            x4, [x0, #-1]
    //     0x1263b64: ubfx            x4, x4, #0xc, #0x14
    // 0x1263b68: stp             x3, x0, [SP]
    // 0x1263b6c: mov             x0, x4
    // 0x1263b70: mov             lr, x0
    // 0x1263b74: ldr             lr, [x21, lr, lsl #3]
    // 0x1263b78: blr             lr
    // 0x1263b7c: tbnz            w0, #4, #0x1263f1c
    // 0x1263b80: ldur            x0, [fp, #-8]
    // 0x1263b84: r17 = 5209
    //     0x1263b84: mov             x17, #0x1459
    // 0x1263b88: cmp             x0, x17
    // 0x1263b8c: b.ne            #0x1263ba4
    // 0x1263b90: ldr             x2, [fp, #0x10]
    // 0x1263b94: LoadField: r1 = r2->field_3b
    //     0x1263b94: ldur            w1, [x2, #0x3b]
    // 0x1263b98: DecompressPointer r1
    //     0x1263b98: add             x1, x1, HEAP, lsl #32
    // 0x1263b9c: mov             x2, x1
    // 0x1263ba0: b               #0x1263c20
    // 0x1263ba4: ldr             x2, [fp, #0x10]
    // 0x1263ba8: r17 = 5210
    //     0x1263ba8: mov             x17, #0x145a
    // 0x1263bac: cmp             x0, x17
    // 0x1263bb0: b.ne            #0x1263be8
    // 0x1263bb4: mov             x1, x2
    // 0x1263bb8: LoadField: r0 = r1->field_57
    //     0x1263bb8: ldur            w0, [x1, #0x57]
    // 0x1263bbc: DecompressPointer r0
    //     0x1263bbc: add             x0, x0, HEAP, lsl #32
    // 0x1263bc0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1263bc4: cmp             w0, w16
    // 0x1263bc8: b.ne            #0x1263bd8
    // 0x1263bcc: r2 = _textTheme
    //     0x1263bcc: add             x2, PP, #0x26, lsl #12  ; [pp+0x265a0] Field <_AppBarDefaultsM3@25187611._textTheme@25187611>: late final (offset: 0x58)
    //     0x1263bd0: ldr             x2, [x2, #0x5a0]
    // 0x1263bd4: r0 = InitLateFinalInstanceField()
    //     0x1263bd4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1263bd8: LoadField: r1 = r0->field_2f
    //     0x1263bd8: ldur            w1, [x0, #0x2f]
    // 0x1263bdc: DecompressPointer r1
    //     0x1263bdc: add             x1, x1, HEAP, lsl #32
    // 0x1263be0: mov             x2, x1
    // 0x1263be4: b               #0x1263c20
    // 0x1263be8: ldr             x1, [fp, #0x10]
    // 0x1263bec: LoadField: r0 = r1->field_4f
    //     0x1263bec: ldur            w0, [x1, #0x4f]
    // 0x1263bf0: DecompressPointer r0
    //     0x1263bf0: add             x0, x0, HEAP, lsl #32
    // 0x1263bf4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1263bf8: cmp             w0, w16
    // 0x1263bfc: b.ne            #0x1263c0c
    // 0x1263c00: r2 = _theme
    //     0x1263c00: add             x2, PP, #0x26, lsl #12  ; [pp+0x26598] Field <_AppBarDefaultsM2@25187611._theme@25187611>: late final (offset: 0x50)
    //     0x1263c04: ldr             x2, [x2, #0x598]
    // 0x1263c08: r0 = InitLateFinalInstanceField()
    //     0x1263c08: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1263c0c: LoadField: r1 = r0->field_87
    //     0x1263c0c: ldur            w1, [x0, #0x87]
    // 0x1263c10: DecompressPointer r1
    //     0x1263c10: add             x1, x1, HEAP, lsl #32
    // 0x1263c14: LoadField: r0 = r1->field_2f
    //     0x1263c14: ldur            w0, [x1, #0x2f]
    // 0x1263c18: DecompressPointer r0
    //     0x1263c18: add             x0, x0, HEAP, lsl #32
    // 0x1263c1c: mov             x2, x0
    // 0x1263c20: ldur            x0, [fp, #-0x10]
    // 0x1263c24: stur            x2, [fp, #-0x18]
    // 0x1263c28: r17 = 5209
    //     0x1263c28: mov             x17, #0x1459
    // 0x1263c2c: cmp             x0, x17
    // 0x1263c30: b.ne            #0x1263c48
    // 0x1263c34: ldr             x3, [fp, #0x18]
    // 0x1263c38: LoadField: r1 = r3->field_3b
    //     0x1263c38: ldur            w1, [x3, #0x3b]
    // 0x1263c3c: DecompressPointer r1
    //     0x1263c3c: add             x1, x1, HEAP, lsl #32
    // 0x1263c40: mov             x0, x2
    // 0x1263c44: b               #0x1263cc8
    // 0x1263c48: ldr             x3, [fp, #0x18]
    // 0x1263c4c: r17 = 5210
    //     0x1263c4c: mov             x17, #0x145a
    // 0x1263c50: cmp             x0, x17
    // 0x1263c54: b.ne            #0x1263c8c
    // 0x1263c58: mov             x1, x3
    // 0x1263c5c: LoadField: r0 = r1->field_57
    //     0x1263c5c: ldur            w0, [x1, #0x57]
    // 0x1263c60: DecompressPointer r0
    //     0x1263c60: add             x0, x0, HEAP, lsl #32
    // 0x1263c64: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1263c68: cmp             w0, w16
    // 0x1263c6c: b.ne            #0x1263c7c
    // 0x1263c70: r2 = _textTheme
    //     0x1263c70: add             x2, PP, #0x26, lsl #12  ; [pp+0x265a0] Field <_AppBarDefaultsM3@25187611._textTheme@25187611>: late final (offset: 0x58)
    //     0x1263c74: ldr             x2, [x2, #0x5a0]
    // 0x1263c78: r0 = InitLateFinalInstanceField()
    //     0x1263c78: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1263c7c: LoadField: r1 = r0->field_2f
    //     0x1263c7c: ldur            w1, [x0, #0x2f]
    // 0x1263c80: DecompressPointer r1
    //     0x1263c80: add             x1, x1, HEAP, lsl #32
    // 0x1263c84: ldur            x0, [fp, #-0x18]
    // 0x1263c88: b               #0x1263cc8
    // 0x1263c8c: ldr             x1, [fp, #0x18]
    // 0x1263c90: LoadField: r0 = r1->field_4f
    //     0x1263c90: ldur            w0, [x1, #0x4f]
    // 0x1263c94: DecompressPointer r0
    //     0x1263c94: add             x0, x0, HEAP, lsl #32
    // 0x1263c98: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1263c9c: cmp             w0, w16
    // 0x1263ca0: b.ne            #0x1263cb0
    // 0x1263ca4: r2 = _theme
    //     0x1263ca4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26598] Field <_AppBarDefaultsM2@25187611._theme@25187611>: late final (offset: 0x50)
    //     0x1263ca8: ldr             x2, [x2, #0x598]
    // 0x1263cac: r0 = InitLateFinalInstanceField()
    //     0x1263cac: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1263cb0: LoadField: r1 = r0->field_87
    //     0x1263cb0: ldur            w1, [x0, #0x87]
    // 0x1263cb4: DecompressPointer r1
    //     0x1263cb4: add             x1, x1, HEAP, lsl #32
    // 0x1263cb8: LoadField: r0 = r1->field_2f
    //     0x1263cb8: ldur            w0, [x1, #0x2f]
    // 0x1263cbc: DecompressPointer r0
    //     0x1263cbc: add             x0, x0, HEAP, lsl #32
    // 0x1263cc0: mov             x1, x0
    // 0x1263cc4: ldur            x0, [fp, #-0x18]
    // 0x1263cc8: r2 = LoadClassIdInstr(r0)
    //     0x1263cc8: ldur            x2, [x0, #-1]
    //     0x1263ccc: ubfx            x2, x2, #0xc, #0x14
    // 0x1263cd0: stp             x1, x0, [SP]
    // 0x1263cd4: mov             x0, x2
    // 0x1263cd8: mov             lr, x0
    // 0x1263cdc: ldr             lr, [x21, lr, lsl #3]
    // 0x1263ce0: blr             lr
    // 0x1263ce4: tbnz            w0, #4, #0x1263f1c
    // 0x1263ce8: ldur            x0, [fp, #-8]
    // 0x1263cec: r17 = 5209
    //     0x1263cec: mov             x17, #0x1459
    // 0x1263cf0: cmp             x0, x17
    // 0x1263cf4: b.ne            #0x1263d0c
    // 0x1263cf8: ldr             x2, [fp, #0x10]
    // 0x1263cfc: LoadField: r1 = r2->field_3f
    //     0x1263cfc: ldur            w1, [x2, #0x3f]
    // 0x1263d00: DecompressPointer r1
    //     0x1263d00: add             x1, x1, HEAP, lsl #32
    // 0x1263d04: mov             x2, x1
    // 0x1263d08: b               #0x1263d88
    // 0x1263d0c: ldr             x2, [fp, #0x10]
    // 0x1263d10: r17 = 5210
    //     0x1263d10: mov             x17, #0x145a
    // 0x1263d14: cmp             x0, x17
    // 0x1263d18: b.ne            #0x1263d50
    // 0x1263d1c: mov             x1, x2
    // 0x1263d20: LoadField: r0 = r1->field_57
    //     0x1263d20: ldur            w0, [x1, #0x57]
    // 0x1263d24: DecompressPointer r0
    //     0x1263d24: add             x0, x0, HEAP, lsl #32
    // 0x1263d28: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1263d2c: cmp             w0, w16
    // 0x1263d30: b.ne            #0x1263d40
    // 0x1263d34: r2 = _textTheme
    //     0x1263d34: add             x2, PP, #0x26, lsl #12  ; [pp+0x265a0] Field <_AppBarDefaultsM3@25187611._textTheme@25187611>: late final (offset: 0x58)
    //     0x1263d38: ldr             x2, [x2, #0x5a0]
    // 0x1263d3c: r0 = InitLateFinalInstanceField()
    //     0x1263d3c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1263d40: LoadField: r1 = r0->field_1f
    //     0x1263d40: ldur            w1, [x0, #0x1f]
    // 0x1263d44: DecompressPointer r1
    //     0x1263d44: add             x1, x1, HEAP, lsl #32
    // 0x1263d48: mov             x2, x1
    // 0x1263d4c: b               #0x1263d88
    // 0x1263d50: ldr             x1, [fp, #0x10]
    // 0x1263d54: LoadField: r0 = r1->field_4f
    //     0x1263d54: ldur            w0, [x1, #0x4f]
    // 0x1263d58: DecompressPointer r0
    //     0x1263d58: add             x0, x0, HEAP, lsl #32
    // 0x1263d5c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1263d60: cmp             w0, w16
    // 0x1263d64: b.ne            #0x1263d74
    // 0x1263d68: r2 = _theme
    //     0x1263d68: add             x2, PP, #0x26, lsl #12  ; [pp+0x26598] Field <_AppBarDefaultsM2@25187611._theme@25187611>: late final (offset: 0x50)
    //     0x1263d6c: ldr             x2, [x2, #0x598]
    // 0x1263d70: r0 = InitLateFinalInstanceField()
    //     0x1263d70: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1263d74: LoadField: r1 = r0->field_87
    //     0x1263d74: ldur            w1, [x0, #0x87]
    // 0x1263d78: DecompressPointer r1
    //     0x1263d78: add             x1, x1, HEAP, lsl #32
    // 0x1263d7c: LoadField: r0 = r1->field_1f
    //     0x1263d7c: ldur            w0, [x1, #0x1f]
    // 0x1263d80: DecompressPointer r0
    //     0x1263d80: add             x0, x0, HEAP, lsl #32
    // 0x1263d84: mov             x2, x0
    // 0x1263d88: ldur            x0, [fp, #-0x10]
    // 0x1263d8c: stur            x2, [fp, #-0x18]
    // 0x1263d90: r17 = 5209
    //     0x1263d90: mov             x17, #0x1459
    // 0x1263d94: cmp             x0, x17
    // 0x1263d98: b.ne            #0x1263db0
    // 0x1263d9c: ldr             x3, [fp, #0x18]
    // 0x1263da0: LoadField: r1 = r3->field_3f
    //     0x1263da0: ldur            w1, [x3, #0x3f]
    // 0x1263da4: DecompressPointer r1
    //     0x1263da4: add             x1, x1, HEAP, lsl #32
    // 0x1263da8: mov             x0, x2
    // 0x1263dac: b               #0x1263e30
    // 0x1263db0: ldr             x3, [fp, #0x18]
    // 0x1263db4: r17 = 5210
    //     0x1263db4: mov             x17, #0x145a
    // 0x1263db8: cmp             x0, x17
    // 0x1263dbc: b.ne            #0x1263df4
    // 0x1263dc0: mov             x1, x3
    // 0x1263dc4: LoadField: r0 = r1->field_57
    //     0x1263dc4: ldur            w0, [x1, #0x57]
    // 0x1263dc8: DecompressPointer r0
    //     0x1263dc8: add             x0, x0, HEAP, lsl #32
    // 0x1263dcc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1263dd0: cmp             w0, w16
    // 0x1263dd4: b.ne            #0x1263de4
    // 0x1263dd8: r2 = _textTheme
    //     0x1263dd8: add             x2, PP, #0x26, lsl #12  ; [pp+0x265a0] Field <_AppBarDefaultsM3@25187611._textTheme@25187611>: late final (offset: 0x58)
    //     0x1263ddc: ldr             x2, [x2, #0x5a0]
    // 0x1263de0: r0 = InitLateFinalInstanceField()
    //     0x1263de0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1263de4: LoadField: r1 = r0->field_1f
    //     0x1263de4: ldur            w1, [x0, #0x1f]
    // 0x1263de8: DecompressPointer r1
    //     0x1263de8: add             x1, x1, HEAP, lsl #32
    // 0x1263dec: ldur            x0, [fp, #-0x18]
    // 0x1263df0: b               #0x1263e30
    // 0x1263df4: ldr             x1, [fp, #0x18]
    // 0x1263df8: LoadField: r0 = r1->field_4f
    //     0x1263df8: ldur            w0, [x1, #0x4f]
    // 0x1263dfc: DecompressPointer r0
    //     0x1263dfc: add             x0, x0, HEAP, lsl #32
    // 0x1263e00: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1263e04: cmp             w0, w16
    // 0x1263e08: b.ne            #0x1263e18
    // 0x1263e0c: r2 = _theme
    //     0x1263e0c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26598] Field <_AppBarDefaultsM2@25187611._theme@25187611>: late final (offset: 0x50)
    //     0x1263e10: ldr             x2, [x2, #0x598]
    // 0x1263e14: r0 = InitLateFinalInstanceField()
    //     0x1263e14: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1263e18: LoadField: r1 = r0->field_87
    //     0x1263e18: ldur            w1, [x0, #0x87]
    // 0x1263e1c: DecompressPointer r1
    //     0x1263e1c: add             x1, x1, HEAP, lsl #32
    // 0x1263e20: LoadField: r0 = r1->field_1f
    //     0x1263e20: ldur            w0, [x1, #0x1f]
    // 0x1263e24: DecompressPointer r0
    //     0x1263e24: add             x0, x0, HEAP, lsl #32
    // 0x1263e28: mov             x1, x0
    // 0x1263e2c: ldur            x0, [fp, #-0x18]
    // 0x1263e30: r2 = LoadClassIdInstr(r0)
    //     0x1263e30: ldur            x2, [x0, #-1]
    //     0x1263e34: ubfx            x2, x2, #0xc, #0x14
    // 0x1263e38: stp             x1, x0, [SP]
    // 0x1263e3c: mov             x0, x2
    // 0x1263e40: mov             lr, x0
    // 0x1263e44: ldr             lr, [x21, lr, lsl #3]
    // 0x1263e48: blr             lr
    // 0x1263e4c: tbnz            w0, #4, #0x1263f1c
    // 0x1263e50: ldr             x1, [fp, #0x18]
    // 0x1263e54: ldr             x2, [fp, #0x10]
    // 0x1263e58: LoadField: r0 = r2->field_43
    //     0x1263e58: ldur            w0, [x2, #0x43]
    // 0x1263e5c: DecompressPointer r0
    //     0x1263e5c: add             x0, x0, HEAP, lsl #32
    // 0x1263e60: LoadField: r3 = r1->field_43
    //     0x1263e60: ldur            w3, [x1, #0x43]
    // 0x1263e64: DecompressPointer r3
    //     0x1263e64: add             x3, x3, HEAP, lsl #32
    // 0x1263e68: r4 = LoadClassIdInstr(r0)
    //     0x1263e68: ldur            x4, [x0, #-1]
    //     0x1263e6c: ubfx            x4, x4, #0xc, #0x14
    // 0x1263e70: stp             x3, x0, [SP]
    // 0x1263e74: mov             x0, x4
    // 0x1263e78: mov             lr, x0
    // 0x1263e7c: ldr             lr, [x21, lr, lsl #3]
    // 0x1263e80: blr             lr
    // 0x1263e84: tbnz            w0, #4, #0x1263f1c
    // 0x1263e88: ldur            x0, [fp, #-8]
    // 0x1263e8c: r17 = 5209
    //     0x1263e8c: mov             x17, #0x1459
    // 0x1263e90: cmp             x0, x17
    // 0x1263e94: b.ne            #0x1263ea8
    // 0x1263e98: ldr             x0, [fp, #0x10]
    // 0x1263e9c: LoadField: r1 = r0->field_47
    //     0x1263e9c: ldur            w1, [x0, #0x47]
    // 0x1263ea0: DecompressPointer r1
    //     0x1263ea0: add             x1, x1, HEAP, lsl #32
    // 0x1263ea4: b               #0x1263ec0
    // 0x1263ea8: r17 = 5210
    //     0x1263ea8: mov             x17, #0x145a
    // 0x1263eac: cmp             x0, x17
    // 0x1263eb0: b.ne            #0x1263ebc
    // 0x1263eb4: r1 = Instance_EdgeInsets
    //     0x1263eb4: ldr             x1, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0x1263eb8: b               #0x1263ec0
    // 0x1263ebc: r1 = Instance_EdgeInsets
    //     0x1263ebc: ldr             x1, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0x1263ec0: ldur            x0, [fp, #-0x10]
    // 0x1263ec4: r17 = 5209
    //     0x1263ec4: mov             x17, #0x1459
    // 0x1263ec8: cmp             x0, x17
    // 0x1263ecc: b.ne            #0x1263ee4
    // 0x1263ed0: ldr             x0, [fp, #0x18]
    // 0x1263ed4: LoadField: r2 = r0->field_47
    //     0x1263ed4: ldur            w2, [x0, #0x47]
    // 0x1263ed8: DecompressPointer r2
    //     0x1263ed8: add             x2, x2, HEAP, lsl #32
    // 0x1263edc: mov             x0, x2
    // 0x1263ee0: b               #0x1263efc
    // 0x1263ee4: r17 = 5210
    //     0x1263ee4: mov             x17, #0x145a
    // 0x1263ee8: cmp             x0, x17
    // 0x1263eec: b.ne            #0x1263ef8
    // 0x1263ef0: r0 = Instance_EdgeInsets
    //     0x1263ef0: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0x1263ef4: b               #0x1263efc
    // 0x1263ef8: r0 = Instance_EdgeInsets
    //     0x1263ef8: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0x1263efc: r2 = LoadClassIdInstr(r1)
    //     0x1263efc: ldur            x2, [x1, #-1]
    //     0x1263f00: ubfx            x2, x2, #0xc, #0x14
    // 0x1263f04: stp             x0, x1, [SP]
    // 0x1263f08: mov             x0, x2
    // 0x1263f0c: mov             lr, x0
    // 0x1263f10: ldr             lr, [x21, lr, lsl #3]
    // 0x1263f14: blr             lr
    // 0x1263f18: b               #0x1263f20
    // 0x1263f1c: r0 = false
    //     0x1263f1c: add             x0, NULL, #0x30  ; false
    // 0x1263f20: LeaveFrame
    //     0x1263f20: mov             SP, fp
    //     0x1263f24: ldp             fp, lr, [SP], #0x10
    // 0x1263f28: ret
    //     0x1263f28: ret             
    // 0x1263f2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1263f2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1263f30: b               #0x1263264
  }
}

// class id: 6860, size: 0x58, field offset: 0x10
//   const constructor, 
class AppBarTheme extends _MixinApplication8&InheritedTheme&Diagnosticable {

  get _ data(/* No info */) {
    // ** addr: 0x8ac6dc, size: 0xa4
    // 0x8ac6dc: EnterFrame
    //     0x8ac6dc: stp             fp, lr, [SP, #-0x10]!
    //     0x8ac6e0: mov             fp, SP
    // 0x8ac6e4: AllocStack(0x30)
    //     0x8ac6e4: sub             SP, SP, #0x30
    // 0x8ac6e8: LoadField: r0 = r1->field_f
    //     0x8ac6e8: ldur            w0, [x1, #0xf]
    // 0x8ac6ec: DecompressPointer r0
    //     0x8ac6ec: add             x0, x0, HEAP, lsl #32
    // 0x8ac6f0: cmp             w0, NULL
    // 0x8ac6f4: b.ne            #0x8ac774
    // 0x8ac6f8: LoadField: r0 = r1->field_13
    //     0x8ac6f8: ldur            w0, [x1, #0x13]
    // 0x8ac6fc: DecompressPointer r0
    //     0x8ac6fc: add             x0, x0, HEAP, lsl #32
    // 0x8ac700: stur            x0, [fp, #-0x30]
    // 0x8ac704: LoadField: r2 = r1->field_1b
    //     0x8ac704: ldur            w2, [x1, #0x1b]
    // 0x8ac708: DecompressPointer r2
    //     0x8ac708: add             x2, x2, HEAP, lsl #32
    // 0x8ac70c: stur            x2, [fp, #-0x28]
    // 0x8ac710: LoadField: r3 = r1->field_2f
    //     0x8ac710: ldur            w3, [x1, #0x2f]
    // 0x8ac714: DecompressPointer r3
    //     0x8ac714: add             x3, x3, HEAP, lsl #32
    // 0x8ac718: stur            x3, [fp, #-0x20]
    // 0x8ac71c: LoadField: r4 = r1->field_43
    //     0x8ac71c: ldur            w4, [x1, #0x43]
    // 0x8ac720: DecompressPointer r4
    //     0x8ac720: add             x4, x4, HEAP, lsl #32
    // 0x8ac724: stur            x4, [fp, #-0x18]
    // 0x8ac728: LoadField: r5 = r1->field_4b
    //     0x8ac728: ldur            w5, [x1, #0x4b]
    // 0x8ac72c: DecompressPointer r5
    //     0x8ac72c: add             x5, x5, HEAP, lsl #32
    // 0x8ac730: stur            x5, [fp, #-0x10]
    // 0x8ac734: LoadField: r6 = r1->field_4f
    //     0x8ac734: ldur            w6, [x1, #0x4f]
    // 0x8ac738: DecompressPointer r6
    //     0x8ac738: add             x6, x6, HEAP, lsl #32
    // 0x8ac73c: stur            x6, [fp, #-8]
    // 0x8ac740: r0 = AppBarThemeData()
    //     0x8ac740: bl              #0x8ac780  ; AllocateAppBarThemeDataStub -> AppBarThemeData (size=0x4c)
    // 0x8ac744: ldur            x1, [fp, #-0x30]
    // 0x8ac748: StoreField: r0->field_7 = r1
    //     0x8ac748: stur            w1, [x0, #7]
    // 0x8ac74c: ldur            x1, [fp, #-0x28]
    // 0x8ac750: StoreField: r0->field_f = r1
    //     0x8ac750: stur            w1, [x0, #0xf]
    // 0x8ac754: ldur            x1, [fp, #-0x20]
    // 0x8ac758: StoreField: r0->field_23 = r1
    //     0x8ac758: stur            w1, [x0, #0x23]
    // 0x8ac75c: ldur            x1, [fp, #-0x18]
    // 0x8ac760: StoreField: r0->field_37 = r1
    //     0x8ac760: stur            w1, [x0, #0x37]
    // 0x8ac764: ldur            x1, [fp, #-0x10]
    // 0x8ac768: StoreField: r0->field_3f = r1
    //     0x8ac768: stur            w1, [x0, #0x3f]
    // 0x8ac76c: ldur            x1, [fp, #-8]
    // 0x8ac770: StoreField: r0->field_43 = r1
    //     0x8ac770: stur            w1, [x0, #0x43]
    // 0x8ac774: LeaveFrame
    //     0x8ac774: mov             SP, fp
    //     0x8ac778: ldp             fp, lr, [SP], #0x10
    // 0x8ac77c: ret
    //     0x8ac77c: ret             
  }
  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xc00100, size: 0xa0
    // 0xc00100: EnterFrame
    //     0xc00100: stp             fp, lr, [SP, #-0x10]!
    //     0xc00104: mov             fp, SP
    // 0xc00108: AllocStack(0x20)
    //     0xc00108: sub             SP, SP, #0x20
    // 0xc0010c: SetupParameters(AppBarTheme this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xc0010c: mov             x4, x1
    //     0xc00110: mov             x3, x2
    //     0xc00114: stur            x1, [fp, #-8]
    //     0xc00118: stur            x2, [fp, #-0x10]
    // 0xc0011c: CheckStackOverflow
    //     0xc0011c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc00120: cmp             SP, x16
    //     0xc00124: b.ls            #0xc00198
    // 0xc00128: mov             x0, x3
    // 0xc0012c: r2 = Null
    //     0xc0012c: mov             x2, NULL
    // 0xc00130: r1 = Null
    //     0xc00130: mov             x1, NULL
    // 0xc00134: r4 = 60
    //     0xc00134: mov             x4, #0x3c
    // 0xc00138: branchIfSmi(r0, 0xc00144)
    //     0xc00138: tbz             w0, #0, #0xc00144
    // 0xc0013c: r4 = LoadClassIdInstr(r0)
    //     0xc0013c: ldur            x4, [x0, #-1]
    //     0xc00140: ubfx            x4, x4, #0xc, #0x14
    // 0xc00144: r17 = 6860
    //     0xc00144: mov             x17, #0x1acc
    // 0xc00148: cmp             x4, x17
    // 0xc0014c: b.eq            #0xc00164
    // 0xc00150: r8 = AppBarTheme
    //     0xc00150: add             x8, PP, #0x95, lsl #12  ; [pp+0x95f40] Type: AppBarTheme
    //     0xc00154: ldr             x8, [x8, #0xf40]
    // 0xc00158: r3 = Null
    //     0xc00158: add             x3, PP, #0x95, lsl #12  ; [pp+0x95f48] Null
    //     0xc0015c: ldr             x3, [x3, #0xf48]
    // 0xc00160: r0 = DefaultTypeTest()
    //     0xc00160: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc00164: ldur            x1, [fp, #-8]
    // 0xc00168: r0 = data()
    //     0xc00168: bl              #0x8ac6dc  ; [package:flutter/src/material/app_bar_theme.dart] AppBarTheme::data
    // 0xc0016c: ldur            x1, [fp, #-0x10]
    // 0xc00170: stur            x0, [fp, #-8]
    // 0xc00174: r0 = data()
    //     0xc00174: bl              #0x8ac6dc  ; [package:flutter/src/material/app_bar_theme.dart] AppBarTheme::data
    // 0xc00178: ldur            x16, [fp, #-8]
    // 0xc0017c: stp             x0, x16, [SP]
    // 0xc00180: r0 = ==()
    //     0xc00180: bl              #0x126324c  ; [package:flutter/src/material/app_bar_theme.dart] AppBarThemeData::==
    // 0xc00184: eor             x1, x0, #0x10
    // 0xc00188: mov             x0, x1
    // 0xc0018c: LeaveFrame
    //     0xc0018c: mov             SP, fp
    //     0xc00190: ldp             fp, lr, [SP], #0x10
    // 0xc00194: ret
    //     0xc00194: ret             
    // 0xc00198: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc00198: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0019c: b               #0xc00128
  }
  static _ of(/* No info */) {
    // ** addr: 0xd366b0, size: 0x78
    // 0xd366b0: EnterFrame
    //     0xd366b0: stp             fp, lr, [SP, #-0x10]!
    //     0xd366b4: mov             fp, SP
    // 0xd366b8: AllocStack(0x18)
    //     0xd366b8: sub             SP, SP, #0x18
    // 0xd366bc: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xd366bc: stur            x1, [fp, #-8]
    // 0xd366c0: CheckStackOverflow
    //     0xd366c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd366c4: cmp             SP, x16
    //     0xd366c8: b.ls            #0xd36720
    // 0xd366cc: r16 = <AppBarTheme>
    //     0xd366cc: add             x16, PP, #0x84, lsl #12  ; [pp+0x84bd8] TypeArguments: <AppBarTheme>
    //     0xd366d0: ldr             x16, [x16, #0xbd8]
    // 0xd366d4: stp             x1, x16, [SP]
    // 0xd366d8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd366d8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd366dc: r0 = dependOnInheritedWidgetOfExactType()
    //     0xd366dc: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xd366e0: cmp             w0, NULL
    // 0xd366e4: b.ne            #0xd366f0
    // 0xd366e8: r0 = Null
    //     0xd366e8: mov             x0, NULL
    // 0xd366ec: b               #0xd366f8
    // 0xd366f0: mov             x1, x0
    // 0xd366f4: r0 = data()
    //     0xd366f4: bl              #0x8ac6dc  ; [package:flutter/src/material/app_bar_theme.dart] AppBarTheme::data
    // 0xd366f8: cmp             w0, NULL
    // 0xd366fc: b.ne            #0xd36714
    // 0xd36700: ldur            x1, [fp, #-8]
    // 0xd36704: r0 = of()
    //     0xd36704: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd36708: LoadField: r1 = r0->field_93
    //     0xd36708: ldur            w1, [x0, #0x93]
    // 0xd3670c: DecompressPointer r1
    //     0xd3670c: add             x1, x1, HEAP, lsl #32
    // 0xd36710: mov             x0, x1
    // 0xd36714: LeaveFrame
    //     0xd36714: mov             SP, fp
    //     0xd36718: ldp             fp, lr, [SP], #0x10
    // 0xd3671c: ret
    //     0xd3671c: ret             
    // 0xd36720: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd36720: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd36724: b               #0xd366cc
  }
  _ wrap(/* No info */) {
    // ** addr: 0x1200664, size: 0x60
    // 0x1200664: EnterFrame
    //     0x1200664: stp             fp, lr, [SP, #-0x10]!
    //     0x1200668: mov             fp, SP
    // 0x120066c: AllocStack(0x18)
    //     0x120066c: sub             SP, SP, #0x18
    // 0x1200670: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x1200670: stur            x2, [fp, #-8]
    // 0x1200674: CheckStackOverflow
    //     0x1200674: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1200678: cmp             SP, x16
    //     0x120067c: b.ls            #0x12006bc
    // 0x1200680: r0 = data()
    //     0x1200680: bl              #0x8ac6dc  ; [package:flutter/src/material/app_bar_theme.dart] AppBarTheme::data
    // 0x1200684: stur            x0, [fp, #-0x10]
    // 0x1200688: r0 = AppBarTheme()
    //     0x1200688: bl              #0xeb477c  ; AllocateAppBarThemeStub -> AppBarTheme (size=0x58)
    // 0x120068c: mov             x2, x0
    // 0x1200690: ldur            x0, [fp, #-0x10]
    // 0x1200694: stur            x2, [fp, #-0x18]
    // 0x1200698: StoreField: r2->field_f = r0
    //     0x1200698: stur            w0, [x2, #0xf]
    // 0x120069c: ldur            x0, [fp, #-8]
    // 0x12006a0: StoreField: r2->field_b = r0
    //     0x12006a0: stur            w0, [x2, #0xb]
    // 0x12006a4: mov             x1, x2
    // 0x12006a8: r0 = Shader._()
    //     0x12006a8: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0x12006ac: ldur            x0, [fp, #-0x18]
    // 0x12006b0: LeaveFrame
    //     0x12006b0: mov             SP, fp
    //     0x12006b4: ldp             fp, lr, [SP], #0x10
    // 0x12006b8: ret
    //     0x12006b8: ret             
    // 0x12006bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12006bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12006c0: b               #0x1200680
  }
}
