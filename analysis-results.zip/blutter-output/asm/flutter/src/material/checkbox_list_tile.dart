// lib: , url: package:flutter/src/material/checkbox_list_tile.dart

// class id: 1048865, size: 0x8
class :: {
}

// class id: 6175, size: 0xb4, field offset: 0xc
//   const constructor, 
class CheckboxListTile extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfb3d84, size: 0x268
    // 0xfb3d84: EnterFrame
    //     0xfb3d84: stp             fp, lr, [SP, #-0x10]!
    //     0xfb3d88: mov             fp, SP
    // 0xfb3d8c: AllocStack(0x38)
    //     0xfb3d8c: sub             SP, SP, #0x38
    // 0xfb3d90: SetupParameters(CheckboxListTile this /* r1 => r2, fp-0x18 */, dynamic _ /* r2 => r1, fp-0x20 */)
    //     0xfb3d90: stur            x1, [fp, #-0x18]
    //     0xfb3d94: mov             x16, x2
    //     0xfb3d98: mov             x2, x1
    //     0xfb3d9c: mov             x1, x16
    //     0xfb3da0: stur            x1, [fp, #-0x20]
    // 0xfb3da4: CheckStackOverflow
    //     0xfb3da4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb3da8: cmp             SP, x16
    //     0xfb3dac: b.ls            #0xfb3fe4
    // 0xfb3db0: LoadField: r0 = r2->field_af
    //     0xfb3db0: ldur            w0, [x2, #0xaf]
    // 0xfb3db4: DecompressPointer r0
    //     0xfb3db4: add             x0, x0, HEAP, lsl #32
    // 0xfb3db8: LoadField: r3 = r0->field_7
    //     0xfb3db8: ldur            x3, [x0, #7]
    // 0xfb3dbc: cmp             x3, #0
    // 0xfb3dc0: b.gt            #0xfb3e40
    // 0xfb3dc4: LoadField: r0 = r2->field_b
    //     0xfb3dc4: ldur            w0, [x2, #0xb]
    // 0xfb3dc8: DecompressPointer r0
    //     0xfb3dc8: add             x0, x0, HEAP, lsl #32
    // 0xfb3dcc: stur            x0, [fp, #-0x10]
    // 0xfb3dd0: LoadField: r3 = r2->field_f
    //     0xfb3dd0: ldur            w3, [x2, #0xf]
    // 0xfb3dd4: DecompressPointer r3
    //     0xfb3dd4: add             x3, x3, HEAP, lsl #32
    // 0xfb3dd8: stur            x3, [fp, #-8]
    // 0xfb3ddc: r0 = Checkbox()
    //     0xfb3ddc: bl              #0xfb3fec  ; AllocateCheckboxStub -> Checkbox (size=0x5c)
    // 0xfb3de0: mov             x1, x0
    // 0xfb3de4: ldur            x0, [fp, #-0x10]
    // 0xfb3de8: stur            x1, [fp, #-0x28]
    // 0xfb3dec: StoreField: r1->field_b = r0
    //     0xfb3dec: stur            w0, [x1, #0xb]
    // 0xfb3df0: r0 = false
    //     0xfb3df0: add             x0, NULL, #0x30  ; false
    // 0xfb3df4: StoreField: r1->field_23 = r0
    //     0xfb3df4: stur            w0, [x1, #0x23]
    // 0xfb3df8: ldur            x2, [fp, #-8]
    // 0xfb3dfc: StoreField: r1->field_f = r2
    //     0xfb3dfc: stur            w2, [x1, #0xf]
    // 0xfb3e00: r2 = Instance_MaterialTapTargetSize
    //     0xfb3e00: add             x2, PP, #0x18, lsl #12  ; [pp+0x18318] Obj!MaterialTapTargetSize@12c4ba1
    //     0xfb3e04: ldr             x2, [x2, #0x318]
    // 0xfb3e08: StoreField: r1->field_27 = r2
    //     0xfb3e08: stur            w2, [x1, #0x27]
    // 0xfb3e0c: StoreField: r1->field_43 = r0
    //     0xfb3e0c: stur            w0, [x1, #0x43]
    // 0xfb3e10: StoreField: r1->field_4f = r0
    //     0xfb3e10: stur            w0, [x1, #0x4f]
    // 0xfb3e14: r2 = Instance__CheckboxType
    //     0xfb3e14: add             x2, PP, #0x15, lsl #12  ; [pp+0x15868] Obj!_CheckboxType@12c5921
    //     0xfb3e18: ldr             x2, [x2, #0x868]
    // 0xfb3e1c: StoreField: r1->field_57 = r2
    //     0xfb3e1c: stur            w2, [x1, #0x57]
    // 0xfb3e20: r0 = ExcludeFocus()
    //     0xfb3e20: bl              #0xd3302c  ; AllocateExcludeFocusStub -> ExcludeFocus (size=0x14)
    // 0xfb3e24: mov             x1, x0
    // 0xfb3e28: r0 = true
    //     0xfb3e28: add             x0, NULL, #0x20  ; true
    // 0xfb3e2c: StoreField: r1->field_b = r0
    //     0xfb3e2c: stur            w0, [x1, #0xb]
    // 0xfb3e30: ldur            x2, [fp, #-0x28]
    // 0xfb3e34: StoreField: r1->field_f = r2
    //     0xfb3e34: stur            w2, [x1, #0xf]
    // 0xfb3e38: mov             x2, x1
    // 0xfb3e3c: b               #0xfb3ec8
    // 0xfb3e40: mov             x1, x2
    // 0xfb3e44: r0 = true
    //     0xfb3e44: add             x0, NULL, #0x20  ; true
    // 0xfb3e48: r2 = Instance_MaterialTapTargetSize
    //     0xfb3e48: add             x2, PP, #0x18, lsl #12  ; [pp+0x18318] Obj!MaterialTapTargetSize@12c4ba1
    //     0xfb3e4c: ldr             x2, [x2, #0x318]
    // 0xfb3e50: LoadField: r3 = r1->field_b
    //     0xfb3e50: ldur            w3, [x1, #0xb]
    // 0xfb3e54: DecompressPointer r3
    //     0xfb3e54: add             x3, x3, HEAP, lsl #32
    // 0xfb3e58: stur            x3, [fp, #-0x10]
    // 0xfb3e5c: LoadField: r4 = r1->field_f
    //     0xfb3e5c: ldur            w4, [x1, #0xf]
    // 0xfb3e60: DecompressPointer r4
    //     0xfb3e60: add             x4, x4, HEAP, lsl #32
    // 0xfb3e64: stur            x4, [fp, #-8]
    // 0xfb3e68: r0 = Checkbox()
    //     0xfb3e68: bl              #0xfb3fec  ; AllocateCheckboxStub -> Checkbox (size=0x5c)
    // 0xfb3e6c: mov             x1, x0
    // 0xfb3e70: ldur            x0, [fp, #-0x10]
    // 0xfb3e74: stur            x1, [fp, #-0x28]
    // 0xfb3e78: StoreField: r1->field_b = r0
    //     0xfb3e78: stur            w0, [x1, #0xb]
    // 0xfb3e7c: r0 = false
    //     0xfb3e7c: add             x0, NULL, #0x30  ; false
    // 0xfb3e80: StoreField: r1->field_23 = r0
    //     0xfb3e80: stur            w0, [x1, #0x23]
    // 0xfb3e84: ldur            x2, [fp, #-8]
    // 0xfb3e88: StoreField: r1->field_f = r2
    //     0xfb3e88: stur            w2, [x1, #0xf]
    // 0xfb3e8c: r2 = Instance_MaterialTapTargetSize
    //     0xfb3e8c: add             x2, PP, #0x18, lsl #12  ; [pp+0x18318] Obj!MaterialTapTargetSize@12c4ba1
    //     0xfb3e90: ldr             x2, [x2, #0x318]
    // 0xfb3e94: StoreField: r1->field_27 = r2
    //     0xfb3e94: stur            w2, [x1, #0x27]
    // 0xfb3e98: StoreField: r1->field_43 = r0
    //     0xfb3e98: stur            w0, [x1, #0x43]
    // 0xfb3e9c: StoreField: r1->field_4f = r0
    //     0xfb3e9c: stur            w0, [x1, #0x4f]
    // 0xfb3ea0: r2 = Instance__CheckboxType
    //     0xfb3ea0: add             x2, PP, #0xd3, lsl #12  ; [pp+0xd3c78] Obj!_CheckboxType@12c5901
    //     0xfb3ea4: ldr             x2, [x2, #0xc78]
    // 0xfb3ea8: StoreField: r1->field_57 = r2
    //     0xfb3ea8: stur            w2, [x1, #0x57]
    // 0xfb3eac: r0 = ExcludeFocus()
    //     0xfb3eac: bl              #0xd3302c  ; AllocateExcludeFocusStub -> ExcludeFocus (size=0x14)
    // 0xfb3eb0: mov             x1, x0
    // 0xfb3eb4: r0 = true
    //     0xfb3eb4: add             x0, NULL, #0x20  ; true
    // 0xfb3eb8: StoreField: r1->field_b = r0
    //     0xfb3eb8: stur            w0, [x1, #0xb]
    // 0xfb3ebc: ldur            x2, [fp, #-0x28]
    // 0xfb3ec0: StoreField: r1->field_f = r2
    //     0xfb3ec0: stur            w2, [x1, #0xf]
    // 0xfb3ec4: mov             x2, x1
    // 0xfb3ec8: d0 = 1.000000
    //     0xfb3ec8: fmov            d0, #1.00000000
    // 0xfb3ecc: stur            x2, [fp, #-8]
    // 0xfb3ed0: fcmp            d0, d0
    // 0xfb3ed4: b.eq            #0xfb3efc
    // 0xfb3ed8: r0 = Transform()
    //     0xfb3ed8: bl              #0xd30150  ; AllocateTransformStub -> Transform (size=0x24)
    // 0xfb3edc: mov             x1, x0
    // 0xfb3ee0: ldur            x2, [fp, #-8]
    // 0xfb3ee4: d0 = 1.000000
    //     0xfb3ee4: fmov            d0, #1.00000000
    // 0xfb3ee8: stur            x0, [fp, #-0x10]
    // 0xfb3eec: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xfb3eec: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xfb3ef0: r0 = Transform.scale()
    //     0xfb3ef0: bl              #0xd2ffac  ; [package:flutter/src/widgets/basic.dart] Transform::Transform.scale
    // 0xfb3ef4: ldur            x0, [fp, #-0x10]
    // 0xfb3ef8: b               #0xfb3f00
    // 0xfb3efc: ldur            x0, [fp, #-8]
    // 0xfb3f00: ldur            x2, [fp, #-0x18]
    // 0xfb3f04: ldur            x1, [fp, #-0x20]
    // 0xfb3f08: stur            x0, [fp, #-8]
    // 0xfb3f0c: r0 = of()
    //     0xfb3f0c: bl              #0xd1a0e4  ; [package:flutter/src/material/list_tile_theme.dart] ListTileTheme::of
    // 0xfb3f10: ldur            x1, [fp, #-0x20]
    // 0xfb3f14: r0 = of()
    //     0xfb3f14: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb3f18: ldur            x1, [fp, #-0x20]
    // 0xfb3f1c: stur            x0, [fp, #-0x10]
    // 0xfb3f20: r0 = of()
    //     0xfb3f20: bl              #0xd13360  ; [package:flutter/src/material/checkbox_theme.dart] CheckboxTheme::of
    // 0xfb3f24: ldur            x0, [fp, #-0x10]
    // 0xfb3f28: LoadField: r1 = r0->field_3f
    //     0xfb3f28: ldur            w1, [x0, #0x3f]
    // 0xfb3f2c: DecompressPointer r1
    //     0xfb3f2c: add             x1, x1, HEAP, lsl #32
    // 0xfb3f30: LoadField: r0 = r1->field_2b
    //     0xfb3f30: ldur            w0, [x1, #0x2b]
    // 0xfb3f34: DecompressPointer r0
    //     0xfb3f34: add             x0, x0, HEAP, lsl #32
    // 0xfb3f38: ldur            x2, [fp, #-0x18]
    // 0xfb3f3c: stur            x0, [fp, #-0x30]
    // 0xfb3f40: LoadField: r1 = r2->field_53
    //     0xfb3f40: ldur            w1, [x2, #0x53]
    // 0xfb3f44: DecompressPointer r1
    //     0xfb3f44: add             x1, x1, HEAP, lsl #32
    // 0xfb3f48: stur            x1, [fp, #-0x28]
    // 0xfb3f4c: LoadField: r3 = r2->field_6f
    //     0xfb3f4c: ldur            w3, [x2, #0x6f]
    // 0xfb3f50: DecompressPointer r3
    //     0xfb3f50: add             x3, x3, HEAP, lsl #32
    // 0xfb3f54: stur            x3, [fp, #-0x20]
    // 0xfb3f58: LoadField: r4 = r2->field_43
    //     0xfb3f58: ldur            w4, [x2, #0x43]
    // 0xfb3f5c: DecompressPointer r4
    //     0xfb3f5c: add             x4, x4, HEAP, lsl #32
    // 0xfb3f60: stur            x4, [fp, #-0x10]
    // 0xfb3f64: r0 = ListTile()
    //     0xfb3f64: bl              #0xd32f8c  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0xfb3f68: mov             x3, x0
    // 0xfb3f6c: ldur            x0, [fp, #-8]
    // 0xfb3f70: stur            x3, [fp, #-0x38]
    // 0xfb3f74: StoreField: r3->field_b = r0
    //     0xfb3f74: stur            w0, [x3, #0xb]
    // 0xfb3f78: ldur            x0, [fp, #-0x28]
    // 0xfb3f7c: StoreField: r3->field_f = r0
    //     0xfb3f7c: stur            w0, [x3, #0xf]
    // 0xfb3f80: ldur            x0, [fp, #-0x10]
    // 0xfb3f84: StoreField: r3->field_27 = r0
    //     0xfb3f84: stur            w0, [x3, #0x27]
    // 0xfb3f88: ldur            x0, [fp, #-0x30]
    // 0xfb3f8c: StoreField: r3->field_2b = r0
    //     0xfb3f8c: stur            w0, [x3, #0x2b]
    // 0xfb3f90: ldur            x0, [fp, #-0x20]
    // 0xfb3f94: StoreField: r3->field_47 = r0
    //     0xfb3f94: stur            w0, [x3, #0x47]
    // 0xfb3f98: r0 = true
    //     0xfb3f98: add             x0, NULL, #0x20  ; true
    // 0xfb3f9c: StoreField: r3->field_4b = r0
    //     0xfb3f9c: stur            w0, [x3, #0x4b]
    // 0xfb3fa0: ldur            x2, [fp, #-0x18]
    // 0xfb3fa4: r1 = Function '_handleValueChange@733134056':.
    //     0xfb3fa4: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3c80] AnonymousClosure: (0xfb3ff8), in [package:flutter/src/material/checkbox_list_tile.dart] CheckboxListTile::_handleValueChange (0xfb4030)
    //     0xfb3fa8: ldr             x1, [x1, #0xc80]
    // 0xfb3fac: r0 = AllocateClosure()
    //     0xfb3fac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfb3fb0: mov             x1, x0
    // 0xfb3fb4: ldur            x0, [fp, #-0x38]
    // 0xfb3fb8: StoreField: r0->field_4f = r1
    //     0xfb3fb8: stur            w1, [x0, #0x4f]
    // 0xfb3fbc: r1 = false
    //     0xfb3fbc: add             x1, NULL, #0x30  ; false
    // 0xfb3fc0: StoreField: r0->field_5f = r1
    //     0xfb3fc0: stur            w1, [x0, #0x5f]
    // 0xfb3fc4: StoreField: r0->field_73 = r1
    //     0xfb3fc4: stur            w1, [x0, #0x73]
    // 0xfb3fc8: StoreField: r0->field_97 = r1
    //     0xfb3fc8: stur            w1, [x0, #0x97]
    // 0xfb3fcc: r0 = MergeSemantics()
    //     0xfb3fcc: bl              #0xd32f80  ; AllocateMergeSemanticsStub -> MergeSemantics (size=0x10)
    // 0xfb3fd0: ldur            x1, [fp, #-0x38]
    // 0xfb3fd4: StoreField: r0->field_b = r1
    //     0xfb3fd4: stur            w1, [x0, #0xb]
    // 0xfb3fd8: LeaveFrame
    //     0xfb3fd8: mov             SP, fp
    //     0xfb3fdc: ldp             fp, lr, [SP], #0x10
    // 0xfb3fe0: ret
    //     0xfb3fe0: ret             
    // 0xfb3fe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb3fe4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb3fe8: b               #0xfb3db0
  }
  [closure] void _handleValueChange(dynamic) {
    // ** addr: 0xfb3ff8, size: 0x38
    // 0xfb3ff8: EnterFrame
    //     0xfb3ff8: stp             fp, lr, [SP, #-0x10]!
    //     0xfb3ffc: mov             fp, SP
    // 0xfb4000: ldr             x0, [fp, #0x10]
    // 0xfb4004: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xfb4004: ldur            w1, [x0, #0x17]
    // 0xfb4008: DecompressPointer r1
    //     0xfb4008: add             x1, x1, HEAP, lsl #32
    // 0xfb400c: CheckStackOverflow
    //     0xfb400c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb4010: cmp             SP, x16
    //     0xfb4014: b.ls            #0xfb4028
    // 0xfb4018: r0 = _handleValueChange()
    //     0xfb4018: bl              #0xfb4030  ; [package:flutter/src/material/checkbox_list_tile.dart] CheckboxListTile::_handleValueChange
    // 0xfb401c: LeaveFrame
    //     0xfb401c: mov             SP, fp
    //     0xfb4020: ldp             fp, lr, [SP], #0x10
    // 0xfb4024: ret
    //     0xfb4024: ret             
    // 0xfb4028: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb4028: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb402c: b               #0xfb4018
  }
  _ _handleValueChange(/* No info */) {
    // ** addr: 0xfb4030, size: 0x90
    // 0xfb4030: EnterFrame
    //     0xfb4030: stp             fp, lr, [SP, #-0x10]!
    //     0xfb4034: mov             fp, SP
    // 0xfb4038: AllocStack(0x10)
    //     0xfb4038: sub             SP, SP, #0x10
    // 0xfb403c: CheckStackOverflow
    //     0xfb403c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb4040: cmp             SP, x16
    //     0xfb4044: b.ls            #0xfb40b0
    // 0xfb4048: LoadField: r0 = r1->field_b
    //     0xfb4048: ldur            w0, [x1, #0xb]
    // 0xfb404c: DecompressPointer r0
    //     0xfb404c: add             x0, x0, HEAP, lsl #32
    // 0xfb4050: tbz             w0, #4, #0xfb407c
    // 0xfb4054: LoadField: r0 = r1->field_f
    //     0xfb4054: ldur            w0, [x1, #0xf]
    // 0xfb4058: DecompressPointer r0
    //     0xfb4058: add             x0, x0, HEAP, lsl #32
    // 0xfb405c: cmp             w0, NULL
    // 0xfb4060: b.eq            #0xfb40b8
    // 0xfb4064: r16 = true
    //     0xfb4064: add             x16, NULL, #0x20  ; true
    // 0xfb4068: stp             x16, x0, [SP]
    // 0xfb406c: ClosureCall
    //     0xfb406c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xfb4070: ldur            x2, [x0, #0x1f]
    //     0xfb4074: blr             x2
    // 0xfb4078: b               #0xfb40a0
    // 0xfb407c: LoadField: r0 = r1->field_f
    //     0xfb407c: ldur            w0, [x1, #0xf]
    // 0xfb4080: DecompressPointer r0
    //     0xfb4080: add             x0, x0, HEAP, lsl #32
    // 0xfb4084: cmp             w0, NULL
    // 0xfb4088: b.eq            #0xfb40bc
    // 0xfb408c: r16 = false
    //     0xfb408c: add             x16, NULL, #0x30  ; false
    // 0xfb4090: stp             x16, x0, [SP]
    // 0xfb4094: ClosureCall
    //     0xfb4094: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xfb4098: ldur            x2, [x0, #0x1f]
    //     0xfb409c: blr             x2
    // 0xfb40a0: r0 = Null
    //     0xfb40a0: mov             x0, NULL
    // 0xfb40a4: LeaveFrame
    //     0xfb40a4: mov             SP, fp
    //     0xfb40a8: ldp             fp, lr, [SP], #0x10
    // 0xfb40ac: ret
    //     0xfb40ac: ret             
    // 0xfb40b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb40b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb40b4: b               #0xfb4048
    // 0xfb40b8: r0 = NullErrorSharedWithoutFPURegs()
    //     0xfb40b8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xfb40bc: r0 = NullErrorSharedWithoutFPURegs()
    //     0xfb40bc: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 8293, size: 0x14, field offset: 0x14
enum _CheckboxType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9f04, size: 0x64
    // 0x11a9f04: EnterFrame
    //     0x11a9f04: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9f08: mov             fp, SP
    // 0x11a9f0c: AllocStack(0x10)
    //     0x11a9f0c: sub             SP, SP, #0x10
    // 0x11a9f10: SetupParameters(_CheckboxType this /* r1 => r0, fp-0x8 */)
    //     0x11a9f10: mov             x0, x1
    //     0x11a9f14: stur            x1, [fp, #-8]
    // 0x11a9f18: CheckStackOverflow
    //     0x11a9f18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9f1c: cmp             SP, x16
    //     0x11a9f20: b.ls            #0x11a9f60
    // 0x11a9f24: r1 = Null
    //     0x11a9f24: mov             x1, NULL
    // 0x11a9f28: r2 = 4
    //     0x11a9f28: mov             x2, #4
    // 0x11a9f2c: r0 = AllocateArray()
    //     0x11a9f2c: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9f30: r16 = "_CheckboxType."
    //     0x11a9f30: add             x16, PP, #0x85, lsl #12  ; [pp+0x851b0] "_CheckboxType."
    //     0x11a9f34: ldr             x16, [x16, #0x1b0]
    // 0x11a9f38: StoreField: r0->field_f = r16
    //     0x11a9f38: stur            w16, [x0, #0xf]
    // 0x11a9f3c: ldur            x1, [fp, #-8]
    // 0x11a9f40: LoadField: r2 = r1->field_f
    //     0x11a9f40: ldur            w2, [x1, #0xf]
    // 0x11a9f44: DecompressPointer r2
    //     0x11a9f44: add             x2, x2, HEAP, lsl #32
    // 0x11a9f48: StoreField: r0->field_13 = r2
    //     0x11a9f48: stur            w2, [x0, #0x13]
    // 0x11a9f4c: str             x0, [SP]
    // 0x11a9f50: r0 = _interpolate()
    //     0x11a9f50: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9f54: LeaveFrame
    //     0x11a9f54: mov             SP, fp
    //     0x11a9f58: ldp             fp, lr, [SP], #0x10
    // 0x11a9f5c: ret
    //     0x11a9f5c: ret             
    // 0x11a9f60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9f60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9f64: b               #0x11a9f24
  }
}
