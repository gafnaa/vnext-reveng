// lib: , url: package:flutter/src/material/expansion_tile.dart

// class id: 1048891, size: 0x8
class :: {
}

// class id: 5153, size: 0x48, field offset: 0x3c
class _ExpansionTileDefaultsM3 extends ExpansionTileThemeData {

  late final ColorScheme _colors; // offset: 0x44
  late final ThemeData _theme; // offset: 0x40

  ColorScheme _colors(_ExpansionTileDefaultsM3) {
    // ** addr: 0xef4b6c, size: 0x58
    // 0xef4b6c: EnterFrame
    //     0xef4b6c: stp             fp, lr, [SP, #-0x10]!
    //     0xef4b70: mov             fp, SP
    // 0xef4b74: CheckStackOverflow
    //     0xef4b74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef4b78: cmp             SP, x16
    //     0xef4b7c: b.ls            #0xef4bbc
    // 0xef4b80: ldr             x1, [fp, #0x10]
    // 0xef4b84: LoadField: r0 = r1->field_3f
    //     0xef4b84: ldur            w0, [x1, #0x3f]
    // 0xef4b88: DecompressPointer r0
    //     0xef4b88: add             x0, x0, HEAP, lsl #32
    // 0xef4b8c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef4b90: cmp             w0, w16
    // 0xef4b94: b.ne            #0xef4ba4
    // 0xef4b98: r2 = _theme
    //     0xef4b98: add             x2, PP, #0x26, lsl #12  ; [pp+0x263a8] Field <_ExpansionTileDefaultsM3@747392950._theme@747392950>: late final (offset: 0x40)
    //     0xef4b9c: ldr             x2, [x2, #0x3a8]
    // 0xef4ba0: r0 = InitLateFinalInstanceField()
    //     0xef4ba0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xef4ba4: LoadField: r1 = r0->field_3f
    //     0xef4ba4: ldur            w1, [x0, #0x3f]
    // 0xef4ba8: DecompressPointer r1
    //     0xef4ba8: add             x1, x1, HEAP, lsl #32
    // 0xef4bac: mov             x0, x1
    // 0xef4bb0: LeaveFrame
    //     0xef4bb0: mov             SP, fp
    //     0xef4bb4: ldp             fp, lr, [SP], #0x10
    // 0xef4bb8: ret
    //     0xef4bb8: ret             
    // 0xef4bbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef4bbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef4bc0: b               #0xef4b80
  }
}

// class id: 5154, size: 0x48, field offset: 0x3c
class _ExpansionTileDefaultsM2 extends ExpansionTileThemeData {

  late final ColorScheme _colorScheme; // offset: 0x44
  late final ThemeData _theme; // offset: 0x40

  ColorScheme _colorScheme(_ExpansionTileDefaultsM2) {
    // ** addr: 0xef4b14, size: 0x58
    // 0xef4b14: EnterFrame
    //     0xef4b14: stp             fp, lr, [SP, #-0x10]!
    //     0xef4b18: mov             fp, SP
    // 0xef4b1c: CheckStackOverflow
    //     0xef4b1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef4b20: cmp             SP, x16
    //     0xef4b24: b.ls            #0xef4b64
    // 0xef4b28: ldr             x1, [fp, #0x10]
    // 0xef4b2c: LoadField: r0 = r1->field_3f
    //     0xef4b2c: ldur            w0, [x1, #0x3f]
    // 0xef4b30: DecompressPointer r0
    //     0xef4b30: add             x0, x0, HEAP, lsl #32
    // 0xef4b34: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef4b38: cmp             w0, w16
    // 0xef4b3c: b.ne            #0xef4b4c
    // 0xef4b40: r2 = _theme
    //     0xef4b40: add             x2, PP, #0x26, lsl #12  ; [pp+0x263a0] Field <_ExpansionTileDefaultsM2@747392950._theme@747392950>: late final (offset: 0x40)
    //     0xef4b44: ldr             x2, [x2, #0x3a0]
    // 0xef4b48: r0 = InitLateFinalInstanceField()
    //     0xef4b48: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xef4b4c: LoadField: r1 = r0->field_3f
    //     0xef4b4c: ldur            w1, [x0, #0x3f]
    // 0xef4b50: DecompressPointer r1
    //     0xef4b50: add             x1, x1, HEAP, lsl #32
    // 0xef4b54: mov             x0, x1
    // 0xef4b58: LeaveFrame
    //     0xef4b58: mov             SP, fp
    //     0xef4b5c: ldp             fp, lr, [SP], #0x10
    // 0xef4b60: ret
    //     0xef4b60: ret             
    // 0xef4b64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef4b64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef4b68: b               #0xef4b28
  }
}

// class id: 5468, size: 0x50, field offset: 0x14
class _ExpansionTileState extends State<dynamic> {

  late ExpansibleController _tileController; // offset: 0x3c
  late Curve _curve; // offset: 0x44
  late Duration _duration; // offset: 0x4c
  late Curve? _reverseCurve; // offset: 0x48
  static late final Animatable<double> _easeOutTween; // offset: 0xc98
  late ExpansionTileThemeData _expansionTileTheme; // offset: 0x38
  static late final Animatable<double> _easeInTween; // offset: 0xc94
  static late final Animatable<double> _halfTween; // offset: 0xc9c

  [closure] Widget _buildBody(dynamic, BuildContext, Animation<double>) {
    // ** addr: 0xd65bd0, size: 0x40
    // 0xd65bd0: EnterFrame
    //     0xd65bd0: stp             fp, lr, [SP, #-0x10]!
    //     0xd65bd4: mov             fp, SP
    // 0xd65bd8: ldr             x0, [fp, #0x20]
    // 0xd65bdc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd65bdc: ldur            w1, [x0, #0x17]
    // 0xd65be0: DecompressPointer r1
    //     0xd65be0: add             x1, x1, HEAP, lsl #32
    // 0xd65be4: CheckStackOverflow
    //     0xd65be4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd65be8: cmp             SP, x16
    //     0xd65bec: b.ls            #0xd65c08
    // 0xd65bf0: ldr             x2, [fp, #0x18]
    // 0xd65bf4: ldr             x3, [fp, #0x10]
    // 0xd65bf8: r0 = _buildBody()
    //     0xd65bf8: bl              #0xd65c40  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_buildBody
    // 0xd65bfc: LeaveFrame
    //     0xd65bfc: mov             SP, fp
    //     0xd65c00: ldp             fp, lr, [SP], #0x10
    // 0xd65c04: ret
    //     0xd65c04: ret             
    // 0xd65c08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd65c08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd65c0c: b               #0xd65bf0
  }
  _ _buildBody(/* No info */) {
    // ** addr: 0xd65c40, size: 0x12c
    // 0xd65c40: EnterFrame
    //     0xd65c40: stp             fp, lr, [SP, #-0x10]!
    //     0xd65c44: mov             fp, SP
    // 0xd65c48: AllocStack(0x18)
    //     0xd65c48: sub             SP, SP, #0x18
    // 0xd65c4c: LoadField: r0 = r1->field_b
    //     0xd65c4c: ldur            w0, [x1, #0xb]
    // 0xd65c50: DecompressPointer r0
    //     0xd65c50: add             x0, x0, HEAP, lsl #32
    // 0xd65c54: cmp             w0, NULL
    // 0xd65c58: b.eq            #0xd65d50
    // 0xd65c5c: LoadField: r2 = r0->field_3b
    //     0xd65c5c: ldur            w2, [x0, #0x3b]
    // 0xd65c60: DecompressPointer r2
    //     0xd65c60: add             x2, x2, HEAP, lsl #32
    // 0xd65c64: cmp             w2, NULL
    // 0xd65c68: b.ne            #0xd65c84
    // 0xd65c6c: LoadField: r2 = r1->field_37
    //     0xd65c6c: ldur            w2, [x1, #0x37]
    // 0xd65c70: DecompressPointer r2
    //     0xd65c70: add             x2, x2, HEAP, lsl #32
    // 0xd65c74: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd65c78: cmp             w2, w16
    // 0xd65c7c: b.eq            #0xd65d54
    // 0xd65c80: r2 = Null
    //     0xd65c80: mov             x2, NULL
    // 0xd65c84: cmp             w2, NULL
    // 0xd65c88: b.ne            #0xd65c94
    // 0xd65c8c: r2 = Instance_Alignment
    //     0xd65c8c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xd65c90: ldr             x2, [x2, #0xb80]
    // 0xd65c94: stur            x2, [fp, #-0x10]
    // 0xd65c98: LoadField: r3 = r1->field_37
    //     0xd65c98: ldur            w3, [x1, #0x37]
    // 0xd65c9c: DecompressPointer r3
    //     0xd65c9c: add             x3, x3, HEAP, lsl #32
    // 0xd65ca0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd65ca4: cmp             w3, w16
    // 0xd65ca8: b.eq            #0xd65d60
    // 0xd65cac: LoadField: r1 = r0->field_1b
    //     0xd65cac: ldur            w1, [x0, #0x1b]
    // 0xd65cb0: DecompressPointer r1
    //     0xd65cb0: add             x1, x1, HEAP, lsl #32
    // 0xd65cb4: stur            x1, [fp, #-8]
    // 0xd65cb8: r0 = Column()
    //     0xd65cb8: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xd65cbc: mov             x1, x0
    // 0xd65cc0: r0 = Instance_Axis
    //     0xd65cc0: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xd65cc4: stur            x1, [fp, #-0x18]
    // 0xd65cc8: StoreField: r1->field_f = r0
    //     0xd65cc8: stur            w0, [x1, #0xf]
    // 0xd65ccc: r0 = Instance_MainAxisAlignment
    //     0xd65ccc: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xd65cd0: ldr             x0, [x0, #0x820]
    // 0xd65cd4: StoreField: r1->field_13 = r0
    //     0xd65cd4: stur            w0, [x1, #0x13]
    // 0xd65cd8: r0 = Instance_MainAxisSize
    //     0xd65cd8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xd65cdc: ldr             x0, [x0, #0x828]
    // 0xd65ce0: ArrayStore: r1[0] = r0  ; List_4
    //     0xd65ce0: stur            w0, [x1, #0x17]
    // 0xd65ce4: r0 = Instance_CrossAxisAlignment
    //     0xd65ce4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xd65ce8: ldr             x0, [x0, #0x888]
    // 0xd65cec: StoreField: r1->field_1b = r0
    //     0xd65cec: stur            w0, [x1, #0x1b]
    // 0xd65cf0: r0 = Instance_VerticalDirection
    //     0xd65cf0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xd65cf4: ldr             x0, [x0, #0x838]
    // 0xd65cf8: StoreField: r1->field_23 = r0
    //     0xd65cf8: stur            w0, [x1, #0x23]
    // 0xd65cfc: r0 = Instance_Clip
    //     0xd65cfc: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xd65d00: ldr             x0, [x0, #0x840]
    // 0xd65d04: StoreField: r1->field_2b = r0
    //     0xd65d04: stur            w0, [x1, #0x2b]
    // 0xd65d08: StoreField: r1->field_2f = rZR
    //     0xd65d08: stur            xzr, [x1, #0x2f]
    // 0xd65d0c: ldur            x0, [fp, #-8]
    // 0xd65d10: StoreField: r1->field_b = r0
    //     0xd65d10: stur            w0, [x1, #0xb]
    // 0xd65d14: r0 = Padding()
    //     0xd65d14: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xd65d18: mov             x1, x0
    // 0xd65d1c: r0 = Instance_EdgeInsets
    //     0xd65d1c: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xd65d20: stur            x1, [fp, #-8]
    // 0xd65d24: StoreField: r1->field_f = r0
    //     0xd65d24: stur            w0, [x1, #0xf]
    // 0xd65d28: ldur            x0, [fp, #-0x18]
    // 0xd65d2c: StoreField: r1->field_b = r0
    //     0xd65d2c: stur            w0, [x1, #0xb]
    // 0xd65d30: r0 = Align()
    //     0xd65d30: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xd65d34: ldur            x1, [fp, #-0x10]
    // 0xd65d38: StoreField: r0->field_f = r1
    //     0xd65d38: stur            w1, [x0, #0xf]
    // 0xd65d3c: ldur            x1, [fp, #-8]
    // 0xd65d40: StoreField: r0->field_b = r1
    //     0xd65d40: stur            w1, [x0, #0xb]
    // 0xd65d44: LeaveFrame
    //     0xd65d44: mov             SP, fp
    //     0xd65d48: ldp             fp, lr, [SP], #0x10
    // 0xd65d4c: ret
    //     0xd65d4c: ret             
    // 0xd65d50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd65d50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd65d54: r9 = _expansionTileTheme
    //     0xd65d54: add             x9, PP, #0x95, lsl #12  ; [pp+0x95ce0] Field <_ExpansionTileState@747392950._expansionTileTheme@747392950>: late (offset: 0x38)
    //     0xd65d58: ldr             x9, [x9, #0xce0]
    // 0xd65d5c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd65d5c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd65d60: r9 = _expansionTileTheme
    //     0xd65d60: add             x9, PP, #0x95, lsl #12  ; [pp+0x95ce0] Field <_ExpansionTileState@747392950._expansionTileTheme@747392950>: late (offset: 0x38)
    //     0xd65d64: ldr             x9, [x9, #0xce0]
    // 0xd65d68: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd65d68: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Widget _buildExpansible(dynamic, BuildContext, Widget, Widget, Animation<double>) {
    // ** addr: 0xd65ee4, size: 0x48
    // 0xd65ee4: EnterFrame
    //     0xd65ee4: stp             fp, lr, [SP, #-0x10]!
    //     0xd65ee8: mov             fp, SP
    // 0xd65eec: ldr             x0, [fp, #0x30]
    // 0xd65ef0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd65ef0: ldur            w1, [x0, #0x17]
    // 0xd65ef4: DecompressPointer r1
    //     0xd65ef4: add             x1, x1, HEAP, lsl #32
    // 0xd65ef8: CheckStackOverflow
    //     0xd65ef8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd65efc: cmp             SP, x16
    //     0xd65f00: b.ls            #0xd65f24
    // 0xd65f04: ldr             x2, [fp, #0x28]
    // 0xd65f08: ldr             x3, [fp, #0x20]
    // 0xd65f0c: ldr             x5, [fp, #0x18]
    // 0xd65f10: ldr             x6, [fp, #0x10]
    // 0xd65f14: r0 = _buildExpansible()
    //     0xd65f14: bl              #0xd65f6c  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_buildExpansible
    // 0xd65f18: LeaveFrame
    //     0xd65f18: mov             SP, fp
    //     0xd65f1c: ldp             fp, lr, [SP], #0x10
    // 0xd65f20: ret
    //     0xd65f20: ret             
    // 0xd65f24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd65f24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd65f28: b               #0xd65f04
  }
  [closure] Widget _buildHeader(dynamic, BuildContext, Animation<double>) {
    // ** addr: 0xd65f2c, size: 0x40
    // 0xd65f2c: EnterFrame
    //     0xd65f2c: stp             fp, lr, [SP, #-0x10]!
    //     0xd65f30: mov             fp, SP
    // 0xd65f34: ldr             x0, [fp, #0x20]
    // 0xd65f38: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd65f38: ldur            w1, [x0, #0x17]
    // 0xd65f3c: DecompressPointer r1
    //     0xd65f3c: add             x1, x1, HEAP, lsl #32
    // 0xd65f40: CheckStackOverflow
    //     0xd65f40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd65f44: cmp             SP, x16
    //     0xd65f48: b.ls            #0xd65f64
    // 0xd65f4c: ldr             x2, [fp, #0x18]
    // 0xd65f50: ldr             x3, [fp, #0x10]
    // 0xd65f54: r0 = _buildHeader()
    //     0xd65f54: bl              #0xd6634c  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_buildHeader
    // 0xd65f58: LeaveFrame
    //     0xd65f58: mov             SP, fp
    //     0xd65f5c: ldp             fp, lr, [SP], #0x10
    // 0xd65f60: ret
    //     0xd65f60: ret             
    // 0xd65f64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd65f64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd65f68: b               #0xd65f4c
  }
  _ _buildExpansible(/* No info */) {
    // ** addr: 0xd65f6c, size: 0x3ac
    // 0xd65f6c: EnterFrame
    //     0xd65f6c: stp             fp, lr, [SP, #-0x10]!
    //     0xd65f70: mov             fp, SP
    // 0xd65f74: AllocStack(0x38)
    //     0xd65f74: sub             SP, SP, #0x38
    // 0xd65f78: SetupParameters(_ExpansionTileState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r2, fp-0x28 */)
    //     0xd65f78: mov             x0, x2
    //     0xd65f7c: mov             x2, x6
    //     0xd65f80: stur            x1, [fp, #-0x10]
    //     0xd65f84: stur            x3, [fp, #-0x18]
    //     0xd65f88: stur            x5, [fp, #-0x20]
    //     0xd65f8c: stur            x6, [fp, #-0x28]
    // 0xd65f90: CheckStackOverflow
    //     0xd65f90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd65f94: cmp             SP, x16
    //     0xd65f98: b.ls            #0xd662f0
    // 0xd65f9c: LoadField: r0 = r1->field_1f
    //     0xd65f9c: ldur            w0, [x1, #0x1f]
    // 0xd65fa0: DecompressPointer r0
    //     0xd65fa0: add             x0, x0, HEAP, lsl #32
    // 0xd65fa4: stur            x0, [fp, #-8]
    // 0xd65fa8: r0 = LoadStaticField(0xc98)
    //     0xd65fa8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd65fac: ldr             x0, [x0, #0x1930]
    // 0xd65fb0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd65fb4: cmp             w0, w16
    // 0xd65fb8: b.ne            #0xd65fc8
    // 0xd65fbc: r2 = _easeOutTween
    //     0xd65fbc: add             x2, PP, #0x95, lsl #12  ; [pp+0x95cd0] Field <_ExpansionTileState@747392950._easeOutTween@747392950>: static late final (offset: 0xc98)
    //     0xd65fc0: ldr             x2, [x2, #0xcd0]
    // 0xd65fc4: r0 = InitLateFinalStaticField()
    //     0xd65fc4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd65fc8: ldur            x1, [fp, #-8]
    // 0xd65fcc: mov             x2, x0
    // 0xd65fd0: stur            x0, [fp, #-8]
    // 0xd65fd4: r0 = chain()
    //     0xd65fd4: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xd65fd8: mov             x1, x0
    // 0xd65fdc: ldur            x2, [fp, #-0x28]
    // 0xd65fe0: r0 = animate()
    //     0xd65fe0: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xd65fe4: ldur            x3, [fp, #-0x10]
    // 0xd65fe8: StoreField: r3->field_33 = r0
    //     0xd65fe8: stur            w0, [x3, #0x33]
    //     0xd65fec: ldurb           w16, [x3, #-1]
    //     0xd65ff0: ldurb           w17, [x0, #-1]
    //     0xd65ff4: and             x16, x17, x16, lsr #2
    //     0xd65ff8: tst             x16, HEAP, lsr #32
    //     0xd65ffc: b.eq            #0xd66004
    //     0xd66000: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd66004: LoadField: r1 = r3->field_13
    //     0xd66004: ldur            w1, [x3, #0x13]
    // 0xd66008: DecompressPointer r1
    //     0xd66008: add             x1, x1, HEAP, lsl #32
    // 0xd6600c: ldur            x2, [fp, #-8]
    // 0xd66010: r0 = chain()
    //     0xd66010: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xd66014: mov             x1, x0
    // 0xd66018: ldur            x2, [fp, #-0x28]
    // 0xd6601c: r0 = animate()
    //     0xd6601c: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xd66020: ldur            x3, [fp, #-0x10]
    // 0xd66024: StoreField: r3->field_27 = r0
    //     0xd66024: stur            w0, [x3, #0x27]
    //     0xd66028: ldurb           w16, [x3, #-1]
    //     0xd6602c: ldurb           w17, [x0, #-1]
    //     0xd66030: and             x16, x17, x16, lsr #2
    //     0xd66034: tst             x16, HEAP, lsr #32
    //     0xd66038: b.eq            #0xd66040
    //     0xd6603c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd66040: LoadField: r0 = r3->field_33
    //     0xd66040: ldur            w0, [x3, #0x33]
    // 0xd66044: DecompressPointer r0
    //     0xd66044: add             x0, x0, HEAP, lsl #32
    // 0xd66048: LoadField: r1 = r0->field_f
    //     0xd66048: ldur            w1, [x0, #0xf]
    // 0xd6604c: DecompressPointer r1
    //     0xd6604c: add             x1, x1, HEAP, lsl #32
    // 0xd66050: LoadField: r2 = r0->field_b
    //     0xd66050: ldur            w2, [x0, #0xb]
    // 0xd66054: DecompressPointer r2
    //     0xd66054: add             x2, x2, HEAP, lsl #32
    // 0xd66058: r0 = LoadClassIdInstr(r1)
    //     0xd66058: ldur            x0, [x1, #-1]
    //     0xd6605c: ubfx            x0, x0, #0xc, #0x14
    // 0xd66060: r0 = GDT[cid_x0 + 0x80ed]()
    //     0xd66060: mov             x17, #0x80ed
    //     0xd66064: add             lr, x0, x17
    //     0xd66068: ldr             lr, [x21, lr, lsl #3]
    //     0xd6606c: blr             lr
    // 0xd66070: cmp             w0, NULL
    // 0xd66074: b.ne            #0xd66098
    // 0xd66078: ldur            x3, [fp, #-0x10]
    // 0xd6607c: LoadField: r0 = r3->field_37
    //     0xd6607c: ldur            w0, [x3, #0x37]
    // 0xd66080: DecompressPointer r0
    //     0xd66080: add             x0, x0, HEAP, lsl #32
    // 0xd66084: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd66088: cmp             w0, w16
    // 0xd6608c: b.eq            #0xd662f8
    // 0xd66090: r0 = Null
    //     0xd66090: mov             x0, NULL
    // 0xd66094: b               #0xd6609c
    // 0xd66098: ldur            x3, [fp, #-0x10]
    // 0xd6609c: cmp             w0, NULL
    // 0xd660a0: b.ne            #0xd660b0
    // 0xd660a4: r4 = Instance_Color
    //     0xd660a4: add             x4, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xd660a8: ldr             x4, [x4, #0x810]
    // 0xd660ac: b               #0xd660b4
    // 0xd660b0: mov             x4, x0
    // 0xd660b4: stur            x4, [fp, #-8]
    // 0xd660b8: LoadField: r0 = r3->field_27
    //     0xd660b8: ldur            w0, [x3, #0x27]
    // 0xd660bc: DecompressPointer r0
    //     0xd660bc: add             x0, x0, HEAP, lsl #32
    // 0xd660c0: LoadField: r1 = r0->field_f
    //     0xd660c0: ldur            w1, [x0, #0xf]
    // 0xd660c4: DecompressPointer r1
    //     0xd660c4: add             x1, x1, HEAP, lsl #32
    // 0xd660c8: LoadField: r2 = r0->field_b
    //     0xd660c8: ldur            w2, [x0, #0xb]
    // 0xd660cc: DecompressPointer r2
    //     0xd660cc: add             x2, x2, HEAP, lsl #32
    // 0xd660d0: r0 = LoadClassIdInstr(r1)
    //     0xd660d0: ldur            x0, [x1, #-1]
    //     0xd660d4: ubfx            x0, x0, #0xc, #0x14
    // 0xd660d8: r0 = GDT[cid_x0 + 0x80ed]()
    //     0xd660d8: mov             x17, #0x80ed
    //     0xd660dc: add             lr, x0, x17
    //     0xd660e0: ldr             lr, [x21, lr, lsl #3]
    //     0xd660e4: blr             lr
    // 0xd660e8: cmp             w0, NULL
    // 0xd660ec: b.ne            #0xd660fc
    // 0xd660f0: r4 = Instance_Border
    //     0xd660f0: add             x4, PP, #0x95, lsl #12  ; [pp+0x95cd8] Obj!Border@129eb61
    //     0xd660f4: ldr             x4, [x4, #0xcd8]
    // 0xd660f8: b               #0xd66100
    // 0xd660fc: mov             x4, x0
    // 0xd66100: ldur            x0, [fp, #-0x10]
    // 0xd66104: ldur            x3, [fp, #-0x18]
    // 0xd66108: ldur            x2, [fp, #-0x20]
    // 0xd6610c: ldur            x1, [fp, #-8]
    // 0xd66110: stur            x4, [fp, #-0x28]
    // 0xd66114: LoadField: r5 = r0->field_b
    //     0xd66114: ldur            w5, [x0, #0xb]
    // 0xd66118: DecompressPointer r5
    //     0xd66118: add             x5, x5, HEAP, lsl #32
    // 0xd6611c: cmp             w5, NULL
    // 0xd66120: b.eq            #0xd66304
    // 0xd66124: LoadField: r5 = r0->field_37
    //     0xd66124: ldur            w5, [x0, #0x37]
    // 0xd66128: DecompressPointer r5
    //     0xd66128: add             x5, x5, HEAP, lsl #32
    // 0xd6612c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd66130: cmp             w5, w16
    // 0xd66134: b.eq            #0xd66308
    // 0xd66138: r0 = ShapeDecoration()
    //     0xd66138: bl              #0xb6e288  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0xd6613c: mov             x3, x0
    // 0xd66140: ldur            x2, [fp, #-8]
    // 0xd66144: stur            x3, [fp, #-0x30]
    // 0xd66148: StoreField: r3->field_7 = r2
    //     0xd66148: stur            w2, [x3, #7]
    // 0xd6614c: ldur            x1, [fp, #-0x28]
    // 0xd66150: ArrayStore: r3[0] = r1  ; List_4
    //     0xd66150: stur            w1, [x3, #0x17]
    // 0xd66154: r0 = LoadClassIdInstr(r1)
    //     0xd66154: ldur            x0, [x1, #-1]
    //     0xd66158: ubfx            x0, x0, #0xc, #0x14
    // 0xd6615c: r0 = GDT[cid_x0 + -0xee7]()
    //     0xd6615c: sub             lr, x0, #0xee7
    //     0xd66160: ldr             lr, [x21, lr, lsl #3]
    //     0xd66164: blr             lr
    // 0xd66168: r1 = Null
    //     0xd66168: mov             x1, NULL
    // 0xd6616c: r2 = 4
    //     0xd6616c: mov             x2, #4
    // 0xd66170: stur            x0, [fp, #-0x28]
    // 0xd66174: r0 = AllocateArray()
    //     0xd66174: bl              #0x13df928  ; AllocateArrayStub
    // 0xd66178: mov             x2, x0
    // 0xd6617c: ldur            x0, [fp, #-0x18]
    // 0xd66180: stur            x2, [fp, #-0x38]
    // 0xd66184: StoreField: r2->field_f = r0
    //     0xd66184: stur            w0, [x2, #0xf]
    // 0xd66188: ldur            x0, [fp, #-0x20]
    // 0xd6618c: StoreField: r2->field_13 = r0
    //     0xd6618c: stur            w0, [x2, #0x13]
    // 0xd66190: r1 = <Widget>
    //     0xd66190: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd66194: r0 = AllocateGrowableArray()
    //     0xd66194: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd66198: mov             x1, x0
    // 0xd6619c: ldur            x0, [fp, #-0x38]
    // 0xd661a0: stur            x1, [fp, #-0x18]
    // 0xd661a4: StoreField: r1->field_f = r0
    //     0xd661a4: stur            w0, [x1, #0xf]
    // 0xd661a8: r0 = 4
    //     0xd661a8: mov             x0, #4
    // 0xd661ac: StoreField: r1->field_b = r0
    //     0xd661ac: stur            w0, [x1, #0xb]
    // 0xd661b0: r0 = Column()
    //     0xd661b0: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xd661b4: mov             x1, x0
    // 0xd661b8: r0 = Instance_Axis
    //     0xd661b8: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xd661bc: stur            x1, [fp, #-0x20]
    // 0xd661c0: StoreField: r1->field_f = r0
    //     0xd661c0: stur            w0, [x1, #0xf]
    // 0xd661c4: r0 = Instance_MainAxisAlignment
    //     0xd661c4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xd661c8: ldr             x0, [x0, #0x820]
    // 0xd661cc: StoreField: r1->field_13 = r0
    //     0xd661cc: stur            w0, [x1, #0x13]
    // 0xd661d0: r0 = Instance_MainAxisSize
    //     0xd661d0: add             x0, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xd661d4: ldr             x0, [x0, #0x200]
    // 0xd661d8: ArrayStore: r1[0] = r0  ; List_4
    //     0xd661d8: stur            w0, [x1, #0x17]
    // 0xd661dc: r0 = Instance_CrossAxisAlignment
    //     0xd661dc: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xd661e0: ldr             x0, [x0, #0x888]
    // 0xd661e4: StoreField: r1->field_1b = r0
    //     0xd661e4: stur            w0, [x1, #0x1b]
    // 0xd661e8: r0 = Instance_VerticalDirection
    //     0xd661e8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xd661ec: ldr             x0, [x0, #0x838]
    // 0xd661f0: StoreField: r1->field_23 = r0
    //     0xd661f0: stur            w0, [x1, #0x23]
    // 0xd661f4: r0 = Instance_Clip
    //     0xd661f4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xd661f8: ldr             x0, [x0, #0x840]
    // 0xd661fc: StoreField: r1->field_2b = r0
    //     0xd661fc: stur            w0, [x1, #0x2b]
    // 0xd66200: StoreField: r1->field_2f = rZR
    //     0xd66200: stur            xzr, [x1, #0x2f]
    // 0xd66204: ldur            x2, [fp, #-0x18]
    // 0xd66208: StoreField: r1->field_b = r2
    //     0xd66208: stur            w2, [x1, #0xb]
    // 0xd6620c: r0 = Padding()
    //     0xd6620c: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xd66210: mov             x2, x0
    // 0xd66214: ldur            x0, [fp, #-0x28]
    // 0xd66218: stur            x2, [fp, #-0x18]
    // 0xd6621c: StoreField: r2->field_f = r0
    //     0xd6621c: stur            w0, [x2, #0xf]
    // 0xd66220: ldur            x0, [fp, #-0x20]
    // 0xd66224: StoreField: r2->field_b = r0
    //     0xd66224: stur            w0, [x2, #0xb]
    // 0xd66228: ldur            x0, [fp, #-0x10]
    // 0xd6622c: LoadField: r1 = r0->field_b
    //     0xd6622c: ldur            w1, [x0, #0xb]
    // 0xd66230: DecompressPointer r1
    //     0xd66230: add             x1, x1, HEAP, lsl #32
    // 0xd66234: cmp             w1, NULL
    // 0xd66238: b.eq            #0xd66314
    // 0xd6623c: ldur            x1, [fp, #-8]
    // 0xd66240: r0 = LoadClassIdInstr(r1)
    //     0xd66240: ldur            x0, [x1, #-1]
    //     0xd66244: ubfx            x0, x0, #0xc, #0x14
    // 0xd66248: r0 = GDT[cid_x0 + -0xfe4]()
    //     0xd66248: sub             lr, x0, #0xfe4
    //     0xd6624c: ldr             lr, [x21, lr, lsl #3]
    //     0xd66250: blr             lr
    // 0xd66254: mov             v1.16b, v0.16b
    // 0xd66258: d0 = 0.000000
    //     0xd66258: eor             v0.16b, v0.16b, v0.16b
    // 0xd6625c: fcmp            d1, d0
    // 0xd66260: b.le            #0xd662b4
    // 0xd66264: ldur            x0, [fp, #-0x18]
    // 0xd66268: r0 = Material()
    //     0xd66268: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xd6626c: mov             x1, x0
    // 0xd66270: r0 = Instance_MaterialType
    //     0xd66270: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8c618] Obj!MaterialType@12c5361
    //     0xd66274: ldr             x0, [x0, #0x618]
    // 0xd66278: StoreField: r1->field_f = r0
    //     0xd66278: stur            w0, [x1, #0xf]
    // 0xd6627c: ArrayStore: r1[0] = rZR  ; List_8
    //     0xd6627c: stur            xzr, [x1, #0x17]
    // 0xd66280: r0 = true
    //     0xd66280: add             x0, NULL, #0x20  ; true
    // 0xd66284: StoreField: r1->field_33 = r0
    //     0xd66284: stur            w0, [x1, #0x33]
    // 0xd66288: r0 = Instance_Clip
    //     0xd66288: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xd6628c: ldr             x0, [x0, #0x840]
    // 0xd66290: StoreField: r1->field_37 = r0
    //     0xd66290: stur            w0, [x1, #0x37]
    // 0xd66294: r0 = Instance_Duration
    //     0xd66294: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xd66298: ldr             x0, [x0, #0x318]
    // 0xd6629c: StoreField: r1->field_3b = r0
    //     0xd6629c: stur            w0, [x1, #0x3b]
    // 0xd662a0: ldur            x0, [fp, #-0x18]
    // 0xd662a4: StoreField: r1->field_b = r0
    //     0xd662a4: stur            w0, [x1, #0xb]
    // 0xd662a8: r0 = false
    //     0xd662a8: add             x0, NULL, #0x30  ; false
    // 0xd662ac: StoreField: r1->field_13 = r0
    //     0xd662ac: stur            w0, [x1, #0x13]
    // 0xd662b0: b               #0xd662bc
    // 0xd662b4: ldur            x0, [fp, #-0x18]
    // 0xd662b8: mov             x1, x0
    // 0xd662bc: ldur            x0, [fp, #-0x30]
    // 0xd662c0: stur            x1, [fp, #-8]
    // 0xd662c4: r0 = DecoratedBox()
    //     0xd662c4: bl              #0xd66318  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0xd662c8: ldur            x1, [fp, #-0x30]
    // 0xd662cc: StoreField: r0->field_f = r1
    //     0xd662cc: stur            w1, [x0, #0xf]
    // 0xd662d0: r1 = Instance_DecorationPosition
    //     0xd662d0: add             x1, PP, #0x80, lsl #12  ; [pp+0x80ef0] Obj!DecorationPosition@12c4381
    //     0xd662d4: ldr             x1, [x1, #0xef0]
    // 0xd662d8: StoreField: r0->field_13 = r1
    //     0xd662d8: stur            w1, [x0, #0x13]
    // 0xd662dc: ldur            x1, [fp, #-8]
    // 0xd662e0: StoreField: r0->field_b = r1
    //     0xd662e0: stur            w1, [x0, #0xb]
    // 0xd662e4: LeaveFrame
    //     0xd662e4: mov             SP, fp
    //     0xd662e8: ldp             fp, lr, [SP], #0x10
    // 0xd662ec: ret
    //     0xd662ec: ret             
    // 0xd662f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd662f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd662f4: b               #0xd65f9c
    // 0xd662f8: r9 = _expansionTileTheme
    //     0xd662f8: add             x9, PP, #0x95, lsl #12  ; [pp+0x95ce0] Field <_ExpansionTileState@747392950._expansionTileTheme@747392950>: late (offset: 0x38)
    //     0xd662fc: ldr             x9, [x9, #0xce0]
    // 0xd66300: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd66300: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd66304: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd66304: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd66308: r9 = _expansionTileTheme
    //     0xd66308: add             x9, PP, #0x95, lsl #12  ; [pp+0x95ce0] Field <_ExpansionTileState@747392950._expansionTileTheme@747392950>: late (offset: 0x38)
    //     0xd6630c: ldr             x9, [x9, #0xce0]
    // 0xd66310: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd66310: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd66314: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd66314: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static Animatable<double> _easeOutTween() {
    // ** addr: 0xd66324, size: 0x28
    // 0xd66324: EnterFrame
    //     0xd66324: stp             fp, lr, [SP, #-0x10]!
    //     0xd66328: mov             fp, SP
    // 0xd6632c: r1 = <double>
    //     0xd6632c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd66330: r0 = CurveTween()
    //     0xd66330: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xd66334: r1 = Instance_Cubic
    //     0xd66334: add             x1, PP, #0x15, lsl #12  ; [pp+0x158f0] Obj!Cubic@129f571
    //     0xd66338: ldr             x1, [x1, #0x8f0]
    // 0xd6633c: StoreField: r0->field_b = r1
    //     0xd6633c: stur            w1, [x0, #0xb]
    // 0xd66340: LeaveFrame
    //     0xd66340: mov             SP, fp
    //     0xd66344: ldp             fp, lr, [SP], #0x10
    // 0xd66348: ret
    //     0xd66348: ret             
  }
  _ _buildHeader(/* No info */) {
    // ** addr: 0xd6634c, size: 0x49c
    // 0xd6634c: EnterFrame
    //     0xd6634c: stp             fp, lr, [SP, #-0x10]!
    //     0xd66350: mov             fp, SP
    // 0xd66354: AllocStack(0x70)
    //     0xd66354: sub             SP, SP, #0x70
    // 0xd66358: SetupParameters(_ExpansionTileState this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r1, fp-0x18 */, dynamic _ /* r3 => r2, fp-0x20 */)
    //     0xd66358: mov             x0, x1
    //     0xd6635c: stur            x1, [fp, #-0x10]
    //     0xd66360: mov             x1, x2
    //     0xd66364: stur            x2, [fp, #-0x18]
    //     0xd66368: mov             x2, x3
    //     0xd6636c: stur            x3, [fp, #-0x20]
    // 0xd66370: CheckStackOverflow
    //     0xd66370: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd66374: cmp             SP, x16
    //     0xd66378: b.ls            #0xd667b0
    // 0xd6637c: LoadField: r3 = r0->field_1b
    //     0xd6637c: ldur            w3, [x0, #0x1b]
    // 0xd66380: DecompressPointer r3
    //     0xd66380: add             x3, x3, HEAP, lsl #32
    // 0xd66384: stur            x3, [fp, #-8]
    // 0xd66388: r0 = LoadStaticField(0xc94)
    //     0xd66388: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd6638c: ldr             x0, [x0, #0x1928]
    // 0xd66390: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd66394: cmp             w0, w16
    // 0xd66398: b.ne            #0xd663a8
    // 0xd6639c: r2 = _easeInTween
    //     0xd6639c: add             x2, PP, #0x95, lsl #12  ; [pp+0x95ce8] Field <_ExpansionTileState@747392950._easeInTween@747392950>: static late final (offset: 0xc94)
    //     0xd663a0: ldr             x2, [x2, #0xce8]
    // 0xd663a4: r0 = InitLateFinalStaticField()
    //     0xd663a4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd663a8: ldur            x1, [fp, #-8]
    // 0xd663ac: mov             x2, x0
    // 0xd663b0: stur            x0, [fp, #-8]
    // 0xd663b4: r0 = chain()
    //     0xd663b4: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xd663b8: mov             x1, x0
    // 0xd663bc: ldur            x2, [fp, #-0x20]
    // 0xd663c0: r0 = animate()
    //     0xd663c0: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xd663c4: ldur            x3, [fp, #-0x10]
    // 0xd663c8: StoreField: r3->field_2f = r0
    //     0xd663c8: stur            w0, [x3, #0x2f]
    //     0xd663cc: ldurb           w16, [x3, #-1]
    //     0xd663d0: ldurb           w17, [x0, #-1]
    //     0xd663d4: and             x16, x17, x16, lsr #2
    //     0xd663d8: tst             x16, HEAP, lsr #32
    //     0xd663dc: b.eq            #0xd663e4
    //     0xd663e0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd663e4: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xd663e4: ldur            w1, [x3, #0x17]
    // 0xd663e8: DecompressPointer r1
    //     0xd663e8: add             x1, x1, HEAP, lsl #32
    // 0xd663ec: ldur            x2, [fp, #-8]
    // 0xd663f0: r0 = chain()
    //     0xd663f0: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xd663f4: mov             x1, x0
    // 0xd663f8: ldur            x2, [fp, #-0x20]
    // 0xd663fc: r0 = animate()
    //     0xd663fc: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xd66400: ldur            x2, [fp, #-0x10]
    // 0xd66404: StoreField: r2->field_2b = r0
    //     0xd66404: stur            w0, [x2, #0x2b]
    //     0xd66408: ldurb           w16, [x2, #-1]
    //     0xd6640c: ldurb           w17, [x0, #-1]
    //     0xd66410: and             x16, x17, x16, lsr #2
    //     0xd66414: tst             x16, HEAP, lsr #32
    //     0xd66418: b.eq            #0xd66420
    //     0xd6641c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd66420: ldur            x1, [fp, #-0x18]
    // 0xd66424: r0 = of()
    //     0xd66424: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xd66428: mov             x3, x0
    // 0xd6642c: ldur            x2, [fp, #-0x10]
    // 0xd66430: stur            x3, [fp, #-8]
    // 0xd66434: LoadField: r0 = r2->field_3b
    //     0xd66434: ldur            w0, [x2, #0x3b]
    // 0xd66438: DecompressPointer r0
    //     0xd66438: add             x0, x0, HEAP, lsl #32
    // 0xd6643c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd66440: cmp             w0, w16
    // 0xd66444: b.eq            #0xd667b8
    // 0xd66448: LoadField: r1 = r0->field_23
    //     0xd66448: ldur            w1, [x0, #0x23]
    // 0xd6644c: DecompressPointer r1
    //     0xd6644c: add             x1, x1, HEAP, lsl #32
    // 0xd66450: tbnz            w1, #4, #0xd66478
    // 0xd66454: r0 = LoadClassIdInstr(r3)
    //     0xd66454: ldur            x0, [x3, #-1]
    //     0xd66458: ubfx            x0, x0, #0xc, #0x14
    // 0xd6645c: mov             x1, x3
    // 0xd66460: r0 = GDT[cid_x0 + 0xe89f]()
    //     0xd66460: mov             x17, #0xe89f
    //     0xd66464: add             lr, x0, x17
    //     0xd66468: ldr             lr, [x21, lr, lsl #3]
    //     0xd6646c: blr             lr
    // 0xd66470: mov             x3, x0
    // 0xd66474: b               #0xd664a0
    // 0xd66478: mov             x2, x3
    // 0xd6647c: r0 = LoadClassIdInstr(r2)
    //     0xd6647c: ldur            x0, [x2, #-1]
    //     0xd66480: ubfx            x0, x0, #0xc, #0x14
    // 0xd66484: mov             x1, x2
    // 0xd66488: r0 = GDT[cid_x0 + 0x148b6]()
    //     0xd66488: mov             x17, #0x48b6
    //     0xd6648c: movk            x17, #1, lsl #16
    //     0xd66490: add             lr, x0, x17
    //     0xd66494: ldr             lr, [x21, lr, lsl #3]
    //     0xd66498: blr             lr
    // 0xd6649c: mov             x3, x0
    // 0xd664a0: ldur            x2, [fp, #-0x10]
    // 0xd664a4: stur            x3, [fp, #-0x18]
    // 0xd664a8: LoadField: r0 = r2->field_3b
    //     0xd664a8: ldur            w0, [x2, #0x3b]
    // 0xd664ac: DecompressPointer r0
    //     0xd664ac: add             x0, x0, HEAP, lsl #32
    // 0xd664b0: LoadField: r1 = r0->field_23
    //     0xd664b0: ldur            w1, [x0, #0x23]
    // 0xd664b4: DecompressPointer r1
    //     0xd664b4: add             x1, x1, HEAP, lsl #32
    // 0xd664b8: tbnz            w1, #4, #0xd664e4
    // 0xd664bc: ldur            x1, [fp, #-8]
    // 0xd664c0: r0 = LoadClassIdInstr(r1)
    //     0xd664c0: ldur            x0, [x1, #-1]
    //     0xd664c4: ubfx            x0, x0, #0xc, #0x14
    // 0xd664c8: r0 = GDT[cid_x0 + 0x17037]()
    //     0xd664c8: mov             x17, #0x7037
    //     0xd664cc: movk            x17, #1, lsl #16
    //     0xd664d0: add             lr, x0, x17
    //     0xd664d4: ldr             lr, [x21, lr, lsl #3]
    //     0xd664d8: blr             lr
    // 0xd664dc: mov             x4, x0
    // 0xd664e0: b               #0xd66508
    // 0xd664e4: ldur            x1, [fp, #-8]
    // 0xd664e8: r0 = LoadClassIdInstr(r1)
    //     0xd664e8: ldur            x0, [x1, #-1]
    //     0xd664ec: ubfx            x0, x0, #0xc, #0x14
    // 0xd664f0: r0 = GDT[cid_x0 + 0x16e72]()
    //     0xd664f0: mov             x17, #0x6e72
    //     0xd664f4: movk            x17, #1, lsl #16
    //     0xd664f8: add             lr, x0, x17
    //     0xd664fc: ldr             lr, [x21, lr, lsl #3]
    //     0xd66500: blr             lr
    // 0xd66504: mov             x4, x0
    // 0xd66508: ldur            x3, [fp, #-0x10]
    // 0xd6650c: stur            x4, [fp, #-8]
    // 0xd66510: LoadField: r0 = r3->field_2f
    //     0xd66510: ldur            w0, [x3, #0x2f]
    // 0xd66514: DecompressPointer r0
    //     0xd66514: add             x0, x0, HEAP, lsl #32
    // 0xd66518: LoadField: r1 = r0->field_f
    //     0xd66518: ldur            w1, [x0, #0xf]
    // 0xd6651c: DecompressPointer r1
    //     0xd6651c: add             x1, x1, HEAP, lsl #32
    // 0xd66520: LoadField: r2 = r0->field_b
    //     0xd66520: ldur            w2, [x0, #0xb]
    // 0xd66524: DecompressPointer r2
    //     0xd66524: add             x2, x2, HEAP, lsl #32
    // 0xd66528: r0 = LoadClassIdInstr(r1)
    //     0xd66528: ldur            x0, [x1, #-1]
    //     0xd6652c: ubfx            x0, x0, #0xc, #0x14
    // 0xd66530: r0 = GDT[cid_x0 + 0x80ed]()
    //     0xd66530: mov             x17, #0x80ed
    //     0xd66534: add             lr, x0, x17
    //     0xd66538: ldr             lr, [x21, lr, lsl #3]
    //     0xd6653c: blr             lr
    // 0xd66540: cmp             w0, NULL
    // 0xd66544: b.ne            #0xd66568
    // 0xd66548: ldur            x3, [fp, #-0x10]
    // 0xd6654c: LoadField: r0 = r3->field_37
    //     0xd6654c: ldur            w0, [x3, #0x37]
    // 0xd66550: DecompressPointer r0
    //     0xd66550: add             x0, x0, HEAP, lsl #32
    // 0xd66554: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd66558: cmp             w0, w16
    // 0xd6655c: b.eq            #0xd667c4
    // 0xd66560: r4 = Null
    //     0xd66560: mov             x4, NULL
    // 0xd66564: b               #0xd66570
    // 0xd66568: ldur            x3, [fp, #-0x10]
    // 0xd6656c: mov             x4, x0
    // 0xd66570: stur            x4, [fp, #-0x28]
    // 0xd66574: LoadField: r0 = r3->field_2b
    //     0xd66574: ldur            w0, [x3, #0x2b]
    // 0xd66578: DecompressPointer r0
    //     0xd66578: add             x0, x0, HEAP, lsl #32
    // 0xd6657c: LoadField: r1 = r0->field_f
    //     0xd6657c: ldur            w1, [x0, #0xf]
    // 0xd66580: DecompressPointer r1
    //     0xd66580: add             x1, x1, HEAP, lsl #32
    // 0xd66584: LoadField: r2 = r0->field_b
    //     0xd66584: ldur            w2, [x0, #0xb]
    // 0xd66588: DecompressPointer r2
    //     0xd66588: add             x2, x2, HEAP, lsl #32
    // 0xd6658c: r0 = LoadClassIdInstr(r1)
    //     0xd6658c: ldur            x0, [x1, #-1]
    //     0xd66590: ubfx            x0, x0, #0xc, #0x14
    // 0xd66594: r0 = GDT[cid_x0 + 0x80ed]()
    //     0xd66594: mov             x17, #0x80ed
    //     0xd66598: add             lr, x0, x17
    //     0xd6659c: ldr             lr, [x21, lr, lsl #3]
    //     0xd665a0: blr             lr
    // 0xd665a4: mov             x3, x0
    // 0xd665a8: ldur            x0, [fp, #-0x10]
    // 0xd665ac: stur            x3, [fp, #-0x38]
    // 0xd665b0: LoadField: r4 = r0->field_b
    //     0xd665b0: ldur            w4, [x0, #0xb]
    // 0xd665b4: DecompressPointer r4
    //     0xd665b4: add             x4, x4, HEAP, lsl #32
    // 0xd665b8: stur            x4, [fp, #-0x30]
    // 0xd665bc: cmp             w4, NULL
    // 0xd665c0: b.eq            #0xd667d0
    // 0xd665c4: LoadField: r2 = r0->field_3b
    //     0xd665c4: ldur            w2, [x0, #0x3b]
    // 0xd665c8: DecompressPointer r2
    //     0xd665c8: add             x2, x2, HEAP, lsl #32
    // 0xd665cc: LoadField: r1 = r2->field_23
    //     0xd665cc: ldur            w1, [x2, #0x23]
    // 0xd665d0: DecompressPointer r1
    //     0xd665d0: add             x1, x1, HEAP, lsl #32
    // 0xd665d4: tbnz            w1, #4, #0xd665ec
    // 0xd665d8: r1 = Function 'collapse':.
    //     0xd665d8: add             x1, PP, #0x95, lsl #12  ; [pp+0x95cf0] AnonymousClosure: (0xd66af0), in [package:flutter/src/widgets/expansible.dart] ExpansibleController::collapse (0xd66b28)
    //     0xd665dc: ldr             x1, [x1, #0xcf0]
    // 0xd665e0: r0 = AllocateClosure()
    //     0xd665e0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd665e4: mov             x3, x0
    // 0xd665e8: b               #0xd665fc
    // 0xd665ec: r1 = Function 'expand':.
    //     0xd665ec: add             x1, PP, #0x95, lsl #12  ; [pp+0x95cf8] AnonymousClosure: (0xd66a40), in [package:flutter/src/widgets/expansible.dart] ExpansibleController::expand (0xd66a78)
    //     0xd665f0: ldr             x1, [x1, #0xcf8]
    // 0xd665f4: r0 = AllocateClosure()
    //     0xd665f4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd665f8: mov             x3, x0
    // 0xd665fc: ldur            x0, [fp, #-0x30]
    // 0xd66600: stur            x3, [fp, #-0x48]
    // 0xd66604: LoadField: r1 = r0->field_37
    //     0xd66604: ldur            w1, [x0, #0x37]
    // 0xd66608: DecompressPointer r1
    //     0xd66608: add             x1, x1, HEAP, lsl #32
    // 0xd6660c: cmp             w1, NULL
    // 0xd66610: b.ne            #0xd66634
    // 0xd66614: ldur            x4, [fp, #-0x10]
    // 0xd66618: LoadField: r1 = r4->field_37
    //     0xd66618: ldur            w1, [x4, #0x37]
    // 0xd6661c: DecompressPointer r1
    //     0xd6661c: add             x1, x1, HEAP, lsl #32
    // 0xd66620: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd66624: cmp             w1, w16
    // 0xd66628: b.eq            #0xd667d4
    // 0xd6662c: r5 = Null
    //     0xd6662c: mov             x5, NULL
    // 0xd66630: b               #0xd6663c
    // 0xd66634: ldur            x4, [fp, #-0x10]
    // 0xd66638: mov             x5, x1
    // 0xd6663c: stur            x5, [fp, #-0x40]
    // 0xd66640: LoadField: r1 = r0->field_b
    //     0xd66640: ldur            w1, [x0, #0xb]
    // 0xd66644: DecompressPointer r1
    //     0xd66644: add             x1, x1, HEAP, lsl #32
    // 0xd66648: cmp             w1, NULL
    // 0xd6664c: b.ne            #0xd66664
    // 0xd66650: mov             x1, x4
    // 0xd66654: ldur            x2, [fp, #-0x20]
    // 0xd66658: r0 = _buildLeadingIcon()
    //     0xd66658: bl              #0xd669d4  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_buildLeadingIcon
    // 0xd6665c: mov             x3, x0
    // 0xd66660: b               #0xd66668
    // 0xd66664: mov             x3, x1
    // 0xd66668: ldur            x0, [fp, #-0x10]
    // 0xd6666c: stur            x3, [fp, #-0x50]
    // 0xd66670: LoadField: r1 = r0->field_b
    //     0xd66670: ldur            w1, [x0, #0xb]
    // 0xd66674: DecompressPointer r1
    //     0xd66674: add             x1, x1, HEAP, lsl #32
    // 0xd66678: cmp             w1, NULL
    // 0xd6667c: b.eq            #0xd667e0
    // 0xd66680: LoadField: r4 = r1->field_f
    //     0xd66680: ldur            w4, [x1, #0xf]
    // 0xd66684: DecompressPointer r4
    //     0xd66684: add             x4, x4, HEAP, lsl #32
    // 0xd66688: stur            x4, [fp, #-0x30]
    // 0xd6668c: LoadField: r2 = r1->field_27
    //     0xd6668c: ldur            w2, [x1, #0x27]
    // 0xd66690: DecompressPointer r2
    //     0xd66690: add             x2, x2, HEAP, lsl #32
    // 0xd66694: cmp             w2, NULL
    // 0xd66698: b.ne            #0xd666b0
    // 0xd6669c: mov             x1, x0
    // 0xd666a0: ldur            x2, [fp, #-0x20]
    // 0xd666a4: r0 = _buildTrailingIcon()
    //     0xd666a4: bl              #0xd667e8  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_buildTrailingIcon
    // 0xd666a8: mov             x5, x0
    // 0xd666ac: b               #0xd666b4
    // 0xd666b0: mov             x5, x2
    // 0xd666b4: ldur            x0, [fp, #-0x10]
    // 0xd666b8: ldur            x3, [fp, #-0x48]
    // 0xd666bc: ldur            x4, [fp, #-0x40]
    // 0xd666c0: ldur            x1, [fp, #-0x50]
    // 0xd666c4: ldur            x2, [fp, #-0x30]
    // 0xd666c8: stur            x5, [fp, #-0x20]
    // 0xd666cc: LoadField: r6 = r0->field_b
    //     0xd666cc: ldur            w6, [x0, #0xb]
    // 0xd666d0: DecompressPointer r6
    //     0xd666d0: add             x6, x6, HEAP, lsl #32
    // 0xd666d4: cmp             w6, NULL
    // 0xd666d8: b.eq            #0xd667e4
    // 0xd666dc: r0 = ListTile()
    //     0xd666dc: bl              #0xd32f8c  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0xd666e0: mov             x1, x0
    // 0xd666e4: ldur            x0, [fp, #-0x50]
    // 0xd666e8: StoreField: r1->field_b = r0
    //     0xd666e8: stur            w0, [x1, #0xb]
    // 0xd666ec: ldur            x0, [fp, #-0x30]
    // 0xd666f0: StoreField: r1->field_f = r0
    //     0xd666f0: stur            w0, [x1, #0xf]
    // 0xd666f4: ldur            x0, [fp, #-0x20]
    // 0xd666f8: ArrayStore: r1[0] = r0  ; List_4
    //     0xd666f8: stur            w0, [x1, #0x17]
    // 0xd666fc: ldur            x0, [fp, #-0x40]
    // 0xd66700: StoreField: r1->field_47 = r0
    //     0xd66700: stur            w0, [x1, #0x47]
    // 0xd66704: r0 = true
    //     0xd66704: add             x0, NULL, #0x20  ; true
    // 0xd66708: StoreField: r1->field_4b = r0
    //     0xd66708: stur            w0, [x1, #0x4b]
    // 0xd6670c: ldur            x2, [fp, #-0x48]
    // 0xd66710: StoreField: r1->field_4f = r2
    //     0xd66710: stur            w2, [x1, #0x4f]
    // 0xd66714: r2 = false
    //     0xd66714: add             x2, NULL, #0x30  ; false
    // 0xd66718: StoreField: r1->field_5f = r2
    //     0xd66718: stur            w2, [x1, #0x5f]
    // 0xd6671c: StoreField: r1->field_73 = r2
    //     0xd6671c: stur            w2, [x1, #0x73]
    // 0xd66720: StoreField: r1->field_7f = r0
    //     0xd66720: stur            w0, [x1, #0x7f]
    // 0xd66724: StoreField: r1->field_97 = r2
    //     0xd66724: stur            w2, [x1, #0x97]
    // 0xd66728: ldur            x16, [fp, #-0x28]
    // 0xd6672c: ldur            lr, [fp, #-0x38]
    // 0xd66730: stp             lr, x16, [SP]
    // 0xd66734: r4 = const [0, 0x3, 0x2, 0x1, iconColor, 0x1, textColor, 0x2, null]
    //     0xd66734: add             x4, PP, #0x95, lsl #12  ; [pp+0x95d00] List(9) [0, 0x3, 0x2, 0x1, "iconColor", 0x1, "textColor", 0x2, Null]
    //     0xd66738: ldr             x4, [x4, #0xd00]
    // 0xd6673c: r0 = merge()
    //     0xd6673c: bl              #0xd19d10  ; [package:flutter/src/material/list_tile_theme.dart] ListTileTheme::merge
    // 0xd66740: stur            x0, [fp, #-0x10]
    // 0xd66744: r0 = Semantics()
    //     0xd66744: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xd66748: stur            x0, [fp, #-0x20]
    // 0xd6674c: ldur            x16, [fp, #-8]
    // 0xd66750: ldur            lr, [fp, #-0x18]
    // 0xd66754: stp             lr, x16, [SP, #8]
    // 0xd66758: ldur            x16, [fp, #-0x10]
    // 0xd6675c: str             x16, [SP]
    // 0xd66760: mov             x1, x0
    // 0xd66764: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, hint, 0x1, onTapHint, 0x2, null]
    //     0xd66764: add             x4, PP, #0x95, lsl #12  ; [pp+0x95d08] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "hint", 0x1, "onTapHint", 0x2, Null]
    //     0xd66768: ldr             x4, [x4, #0xd08]
    // 0xd6676c: r0 = Semantics()
    //     0xd6676c: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xd66770: r0 = Semantics()
    //     0xd66770: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xd66774: stur            x0, [fp, #-0x10]
    // 0xd66778: ldur            x16, [fp, #-8]
    // 0xd6677c: r30 = true
    //     0xd6677c: add             lr, NULL, #0x20  ; true
    // 0xd66780: stp             lr, x16, [SP, #0x10]
    // 0xd66784: r16 = Instance_AccessibilityFocusBlockType
    //     0xd66784: ldr             x16, [PP, #0x2a88]  ; [pp+0x2a88] Obj!AccessibilityFocusBlockType@12c3ee1
    // 0xd66788: ldur            lr, [fp, #-0x20]
    // 0xd6678c: stp             lr, x16, [SP]
    // 0xd66790: mov             x1, x0
    // 0xd66794: r4 = const [0, 0x5, 0x4, 0x1, accessibilityFocusBlockType, 0x3, child, 0x4, label, 0x1, liveRegion, 0x2, null]
    //     0xd66794: add             x4, PP, #0x95, lsl #12  ; [pp+0x95d10] List(13) [0, 0x5, 0x4, 0x1, "accessibilityFocusBlockType", 0x3, "child", 0x4, "label", 0x1, "liveRegion", 0x2, Null]
    //     0xd66798: ldr             x4, [x4, #0xd10]
    // 0xd6679c: r0 = Semantics()
    //     0xd6679c: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xd667a0: ldur            x0, [fp, #-0x10]
    // 0xd667a4: LeaveFrame
    //     0xd667a4: mov             SP, fp
    //     0xd667a8: ldp             fp, lr, [SP], #0x10
    // 0xd667ac: ret
    //     0xd667ac: ret             
    // 0xd667b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd667b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd667b4: b               #0xd6637c
    // 0xd667b8: r9 = _tileController
    //     0xd667b8: add             x9, PP, #0x95, lsl #12  ; [pp+0x95cb0] Field <_ExpansionTileState@747392950._tileController@747392950>: late (offset: 0x3c)
    //     0xd667bc: ldr             x9, [x9, #0xcb0]
    // 0xd667c0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd667c0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd667c4: r9 = _expansionTileTheme
    //     0xd667c4: add             x9, PP, #0x95, lsl #12  ; [pp+0x95ce0] Field <_ExpansionTileState@747392950._expansionTileTheme@747392950>: late (offset: 0x38)
    //     0xd667c8: ldr             x9, [x9, #0xce0]
    // 0xd667cc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd667cc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd667d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd667d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd667d4: r9 = _expansionTileTheme
    //     0xd667d4: add             x9, PP, #0x95, lsl #12  ; [pp+0x95ce0] Field <_ExpansionTileState@747392950._expansionTileTheme@747392950>: late (offset: 0x38)
    //     0xd667d8: ldr             x9, [x9, #0xce0]
    // 0xd667dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd667dc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd667e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd667e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd667e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd667e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildTrailingIcon(/* No info */) {
    // ** addr: 0xd667e8, size: 0x6c
    // 0xd667e8: EnterFrame
    //     0xd667e8: stp             fp, lr, [SP, #-0x10]!
    //     0xd667ec: mov             fp, SP
    // 0xd667f0: AllocStack(0x10)
    //     0xd667f0: sub             SP, SP, #0x10
    // 0xd667f4: SetupParameters(_ExpansionTileState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd667f4: mov             x0, x1
    //     0xd667f8: stur            x1, [fp, #-8]
    //     0xd667fc: stur            x2, [fp, #-0x10]
    // 0xd66800: CheckStackOverflow
    //     0xd66800: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd66804: cmp             SP, x16
    //     0xd66808: b.ls            #0xd6684c
    // 0xd6680c: mov             x1, x0
    // 0xd66810: r0 = _effectiveAffinity()
    //     0xd66810: bl              #0xd66968  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_effectiveAffinity
    // 0xd66814: r16 = Instance_ListTileControlAffinity
    //     0xd66814: add             x16, PP, #0x95, lsl #12  ; [pp+0x95d20] Obj!ListTileControlAffinity@12c5501
    //     0xd66818: ldr             x16, [x16, #0xd20]
    // 0xd6681c: cmp             w0, w16
    // 0xd66820: b.eq            #0xd66834
    // 0xd66824: r0 = Null
    //     0xd66824: mov             x0, NULL
    // 0xd66828: LeaveFrame
    //     0xd66828: mov             SP, fp
    //     0xd6682c: ldp             fp, lr, [SP], #0x10
    // 0xd66830: ret
    //     0xd66830: ret             
    // 0xd66834: ldur            x1, [fp, #-8]
    // 0xd66838: ldur            x2, [fp, #-0x10]
    // 0xd6683c: r0 = _buildIcon()
    //     0xd6683c: bl              #0xd66854  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_buildIcon
    // 0xd66840: LeaveFrame
    //     0xd66840: mov             SP, fp
    //     0xd66844: ldp             fp, lr, [SP], #0x10
    // 0xd66848: ret
    //     0xd66848: ret             
    // 0xd6684c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd6684c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd66850: b               #0xd6680c
  }
  _ _buildIcon(/* No info */) {
    // ** addr: 0xd66854, size: 0xe8
    // 0xd66854: EnterFrame
    //     0xd66854: stp             fp, lr, [SP, #-0x10]!
    //     0xd66858: mov             fp, SP
    // 0xd6685c: AllocStack(0x18)
    //     0xd6685c: sub             SP, SP, #0x18
    // 0xd66860: SetupParameters(_ExpansionTileState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd66860: stur            x1, [fp, #-8]
    //     0xd66864: stur            x2, [fp, #-0x10]
    // 0xd66868: CheckStackOverflow
    //     0xd66868: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd6686c: cmp             SP, x16
    //     0xd66870: b.ls            #0xd66934
    // 0xd66874: r0 = LoadStaticField(0xc9c)
    //     0xd66874: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd66878: ldr             x0, [x0, #0x1938]
    // 0xd6687c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd66880: cmp             w0, w16
    // 0xd66884: b.ne            #0xd66894
    // 0xd66888: r2 = _halfTween
    //     0xd66888: add             x2, PP, #0x95, lsl #12  ; [pp+0x95d28] Field <_ExpansionTileState@747392950._halfTween@747392950>: static late final (offset: 0xc9c)
    //     0xd6688c: ldr             x2, [x2, #0xd28]
    // 0xd66890: r0 = InitLateFinalStaticField()
    //     0xd66890: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd66894: stur            x0, [fp, #-0x18]
    // 0xd66898: r0 = LoadStaticField(0xc94)
    //     0xd66898: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd6689c: ldr             x0, [x0, #0x1928]
    // 0xd668a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd668a4: cmp             w0, w16
    // 0xd668a8: b.ne            #0xd668b8
    // 0xd668ac: r2 = _easeInTween
    //     0xd668ac: add             x2, PP, #0x95, lsl #12  ; [pp+0x95ce8] Field <_ExpansionTileState@747392950._easeInTween@747392950>: static late final (offset: 0xc94)
    //     0xd668b0: ldr             x2, [x2, #0xce8]
    // 0xd668b4: r0 = InitLateFinalStaticField()
    //     0xd668b4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd668b8: ldur            x1, [fp, #-0x18]
    // 0xd668bc: mov             x2, x0
    // 0xd668c0: r0 = chain()
    //     0xd668c0: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xd668c4: mov             x1, x0
    // 0xd668c8: ldur            x2, [fp, #-0x10]
    // 0xd668cc: r0 = animate()
    //     0xd668cc: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xd668d0: mov             x2, x0
    // 0xd668d4: ldur            x1, [fp, #-8]
    // 0xd668d8: stur            x2, [fp, #-0x10]
    // 0xd668dc: StoreField: r1->field_23 = r0
    //     0xd668dc: stur            w0, [x1, #0x23]
    //     0xd668e0: ldurb           w16, [x1, #-1]
    //     0xd668e4: ldurb           w17, [x0, #-1]
    //     0xd668e8: and             x16, x17, x16, lsr #2
    //     0xd668ec: tst             x16, HEAP, lsr #32
    //     0xd668f0: b.eq            #0xd668f8
    //     0xd668f4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd668f8: r0 = RotationTransition()
    //     0xd668f8: bl              #0xd0fd50  ; AllocateRotationTransitionStub -> RotationTransition (size=0x20)
    // 0xd668fc: r1 = Closure: (double) => Matrix4 from Function '_handleTurnsMatrix@589170175': static.
    //     0xd668fc: add             x1, PP, #0x95, lsl #12  ; [pp+0x95d30] Closure: (double) => Matrix4 from Function '_handleTurnsMatrix@589170175': static. (0x7f2adabf7000)
    //     0xd66900: ldr             x1, [x1, #0xd30]
    // 0xd66904: StoreField: r0->field_f = r1
    //     0xd66904: stur            w1, [x0, #0xf]
    // 0xd66908: r1 = Instance_Alignment
    //     0xd66908: add             x1, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xd6690c: ldr             x1, [x1, #0xb80]
    // 0xd66910: StoreField: r0->field_13 = r1
    //     0xd66910: stur            w1, [x0, #0x13]
    // 0xd66914: r1 = Instance_Icon
    //     0xd66914: add             x1, PP, #0x95, lsl #12  ; [pp+0x95d38] Obj!Icon@12b5da1
    //     0xd66918: ldr             x1, [x1, #0xd38]
    // 0xd6691c: StoreField: r0->field_1b = r1
    //     0xd6691c: stur            w1, [x0, #0x1b]
    // 0xd66920: ldur            x1, [fp, #-0x10]
    // 0xd66924: StoreField: r0->field_b = r1
    //     0xd66924: stur            w1, [x0, #0xb]
    // 0xd66928: LeaveFrame
    //     0xd66928: mov             SP, fp
    //     0xd6692c: ldp             fp, lr, [SP], #0x10
    // 0xd66930: ret
    //     0xd66930: ret             
    // 0xd66934: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd66934: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd66938: b               #0xd66874
  }
  static Animatable<double> _halfTween() {
    // ** addr: 0xd6693c, size: 0x2c
    // 0xd6693c: EnterFrame
    //     0xd6693c: stp             fp, lr, [SP, #-0x10]!
    //     0xd66940: mov             fp, SP
    // 0xd66944: r1 = <double>
    //     0xd66944: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd66948: r0 = Tween()
    //     0xd66948: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xd6694c: r1 = 0.000000
    //     0xd6694c: ldr             x1, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd66950: StoreField: r0->field_b = r1
    //     0xd66950: stur            w1, [x0, #0xb]
    // 0xd66954: r1 = 0.500000
    //     0xd66954: ldr             x1, [PP, #0x4c70]  ; [pp+0x4c70] 0.5
    // 0xd66958: StoreField: r0->field_f = r1
    //     0xd66958: stur            w1, [x0, #0xf]
    // 0xd6695c: LeaveFrame
    //     0xd6695c: mov             SP, fp
    //     0xd66960: ldp             fp, lr, [SP], #0x10
    // 0xd66964: ret
    //     0xd66964: ret             
  }
  _ _effectiveAffinity(/* No info */) {
    // ** addr: 0xd66968, size: 0x6c
    // 0xd66968: EnterFrame
    //     0xd66968: stp             fp, lr, [SP, #-0x10]!
    //     0xd6696c: mov             fp, SP
    // 0xd66970: AllocStack(0x8)
    //     0xd66970: sub             SP, SP, #8
    // 0xd66974: SetupParameters(_ExpansionTileState this /* r1 => r0, fp-0x8 */)
    //     0xd66974: mov             x0, x1
    //     0xd66978: stur            x1, [fp, #-8]
    // 0xd6697c: CheckStackOverflow
    //     0xd6697c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd66980: cmp             SP, x16
    //     0xd66984: b.ls            #0xd669c4
    // 0xd66988: LoadField: r1 = r0->field_f
    //     0xd66988: ldur            w1, [x0, #0xf]
    // 0xd6698c: DecompressPointer r1
    //     0xd6698c: add             x1, x1, HEAP, lsl #32
    // 0xd66990: cmp             w1, NULL
    // 0xd66994: b.eq            #0xd669cc
    // 0xd66998: r0 = of()
    //     0xd66998: bl              #0xd1a0e4  ; [package:flutter/src/material/list_tile_theme.dart] ListTileTheme::of
    // 0xd6699c: ldur            x1, [fp, #-8]
    // 0xd669a0: LoadField: r2 = r1->field_b
    //     0xd669a0: ldur            w2, [x1, #0xb]
    // 0xd669a4: DecompressPointer r2
    //     0xd669a4: add             x2, x2, HEAP, lsl #32
    // 0xd669a8: cmp             w2, NULL
    // 0xd669ac: b.eq            #0xd669d0
    // 0xd669b0: r0 = Instance_ListTileControlAffinity
    //     0xd669b0: add             x0, PP, #0x95, lsl #12  ; [pp+0x95d20] Obj!ListTileControlAffinity@12c5501
    //     0xd669b4: ldr             x0, [x0, #0xd20]
    // 0xd669b8: LeaveFrame
    //     0xd669b8: mov             SP, fp
    //     0xd669bc: ldp             fp, lr, [SP], #0x10
    // 0xd669c0: ret
    //     0xd669c0: ret             
    // 0xd669c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd669c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd669c8: b               #0xd66988
    // 0xd669cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd669cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd669d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd669d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildLeadingIcon(/* No info */) {
    // ** addr: 0xd669d4, size: 0x6c
    // 0xd669d4: EnterFrame
    //     0xd669d4: stp             fp, lr, [SP, #-0x10]!
    //     0xd669d8: mov             fp, SP
    // 0xd669dc: AllocStack(0x10)
    //     0xd669dc: sub             SP, SP, #0x10
    // 0xd669e0: SetupParameters(_ExpansionTileState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd669e0: mov             x0, x1
    //     0xd669e4: stur            x1, [fp, #-8]
    //     0xd669e8: stur            x2, [fp, #-0x10]
    // 0xd669ec: CheckStackOverflow
    //     0xd669ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd669f0: cmp             SP, x16
    //     0xd669f4: b.ls            #0xd66a38
    // 0xd669f8: mov             x1, x0
    // 0xd669fc: r0 = _effectiveAffinity()
    //     0xd669fc: bl              #0xd66968  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_effectiveAffinity
    // 0xd66a00: r16 = Instance_ListTileControlAffinity
    //     0xd66a00: add             x16, PP, #0x95, lsl #12  ; [pp+0x95d40] Obj!ListTileControlAffinity@12c5521
    //     0xd66a04: ldr             x16, [x16, #0xd40]
    // 0xd66a08: cmp             w0, w16
    // 0xd66a0c: b.eq            #0xd66a20
    // 0xd66a10: r0 = Null
    //     0xd66a10: mov             x0, NULL
    // 0xd66a14: LeaveFrame
    //     0xd66a14: mov             SP, fp
    //     0xd66a18: ldp             fp, lr, [SP], #0x10
    // 0xd66a1c: ret
    //     0xd66a1c: ret             
    // 0xd66a20: ldur            x1, [fp, #-8]
    // 0xd66a24: ldur            x2, [fp, #-0x10]
    // 0xd66a28: r0 = _buildIcon()
    //     0xd66a28: bl              #0xd66854  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_buildIcon
    // 0xd66a2c: LeaveFrame
    //     0xd66a2c: mov             SP, fp
    //     0xd66a30: ldp             fp, lr, [SP], #0x10
    // 0xd66a34: ret
    //     0xd66a34: ret             
    // 0xd66a38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd66a38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd66a3c: b               #0xd669f8
  }
  _ build(/* No info */) {
    // ** addr: 0xdf6930, size: 0x140
    // 0xdf6930: EnterFrame
    //     0xdf6930: stp             fp, lr, [SP, #-0x10]!
    //     0xdf6934: mov             fp, SP
    // 0xdf6938: AllocStack(0x20)
    //     0xdf6938: sub             SP, SP, #0x20
    // 0xdf693c: SetupParameters(_ExpansionTileState this /* r1 => r0, fp-0x10 */)
    //     0xdf693c: mov             x0, x1
    //     0xdf6940: stur            x1, [fp, #-0x10]
    // 0xdf6944: LoadField: r3 = r0->field_3b
    //     0xdf6944: ldur            w3, [x0, #0x3b]
    // 0xdf6948: DecompressPointer r3
    //     0xdf6948: add             x3, x3, HEAP, lsl #32
    // 0xdf694c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf6950: cmp             w3, w16
    // 0xdf6954: b.eq            #0xdf6a3c
    // 0xdf6958: stur            x3, [fp, #-8]
    // 0xdf695c: LoadField: r1 = r0->field_43
    //     0xdf695c: ldur            w1, [x0, #0x43]
    // 0xdf6960: DecompressPointer r1
    //     0xdf6960: add             x1, x1, HEAP, lsl #32
    // 0xdf6964: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf6968: cmp             w1, w16
    // 0xdf696c: b.eq            #0xdf6a48
    // 0xdf6970: LoadField: r1 = r0->field_4b
    //     0xdf6970: ldur            w1, [x0, #0x4b]
    // 0xdf6974: DecompressPointer r1
    //     0xdf6974: add             x1, x1, HEAP, lsl #32
    // 0xdf6978: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf697c: cmp             w1, w16
    // 0xdf6980: b.eq            #0xdf6a54
    // 0xdf6984: LoadField: r1 = r0->field_47
    //     0xdf6984: ldur            w1, [x0, #0x47]
    // 0xdf6988: DecompressPointer r1
    //     0xdf6988: add             x1, x1, HEAP, lsl #32
    // 0xdf698c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf6990: cmp             w1, w16
    // 0xdf6994: b.eq            #0xdf6a60
    // 0xdf6998: LoadField: r1 = r0->field_b
    //     0xdf6998: ldur            w1, [x0, #0xb]
    // 0xdf699c: DecompressPointer r1
    //     0xdf699c: add             x1, x1, HEAP, lsl #32
    // 0xdf69a0: cmp             w1, NULL
    // 0xdf69a4: b.eq            #0xdf6a6c
    // 0xdf69a8: mov             x2, x0
    // 0xdf69ac: r1 = Function '_buildHeader@747392950':.
    //     0xdf69ac: add             x1, PP, #0x95, lsl #12  ; [pp+0x95c98] AnonymousClosure: (0xd65f2c), in [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_buildHeader (0xd6634c)
    //     0xdf69b0: ldr             x1, [x1, #0xc98]
    // 0xdf69b4: r0 = AllocateClosure()
    //     0xdf69b4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf69b8: stur            x0, [fp, #-0x18]
    // 0xdf69bc: r0 = Expansible()
    //     0xdf69bc: bl              #0xdf6a70  ; AllocateExpansibleStub -> Expansible (size=0x30)
    // 0xdf69c0: mov             x3, x0
    // 0xdf69c4: ldur            x0, [fp, #-0x18]
    // 0xdf69c8: stur            x3, [fp, #-0x20]
    // 0xdf69cc: StoreField: r3->field_f = r0
    //     0xdf69cc: stur            w0, [x3, #0xf]
    // 0xdf69d0: ldur            x2, [fp, #-0x10]
    // 0xdf69d4: r1 = Function '_buildBody@747392950':.
    //     0xdf69d4: add             x1, PP, #0x95, lsl #12  ; [pp+0x95ca0] AnonymousClosure: (0xd65bd0), in [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_buildBody (0xd65c40)
    //     0xdf69d8: ldr             x1, [x1, #0xca0]
    // 0xdf69dc: r0 = AllocateClosure()
    //     0xdf69dc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf69e0: mov             x1, x0
    // 0xdf69e4: ldur            x0, [fp, #-0x20]
    // 0xdf69e8: StoreField: r0->field_13 = r1
    //     0xdf69e8: stur            w1, [x0, #0x13]
    // 0xdf69ec: ldur            x1, [fp, #-8]
    // 0xdf69f0: StoreField: r0->field_b = r1
    //     0xdf69f0: stur            w1, [x0, #0xb]
    // 0xdf69f4: ldur            x2, [fp, #-0x10]
    // 0xdf69f8: r1 = Function '_buildExpansible@747392950':.
    //     0xdf69f8: add             x1, PP, #0x95, lsl #12  ; [pp+0x95ca8] AnonymousClosure: (0xd65ee4), in [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_buildExpansible (0xd65f6c)
    //     0xdf69fc: ldr             x1, [x1, #0xca8]
    // 0xdf6a00: r0 = AllocateClosure()
    //     0xdf6a00: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf6a04: mov             x1, x0
    // 0xdf6a08: ldur            x0, [fp, #-0x20]
    // 0xdf6a0c: StoreField: r0->field_2b = r1
    //     0xdf6a0c: stur            w1, [x0, #0x2b]
    // 0xdf6a10: r1 = Instance_Duration
    //     0xdf6a10: add             x1, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xdf6a14: ldr             x1, [x1, #0x318]
    // 0xdf6a18: StoreField: r0->field_1b = r1
    //     0xdf6a18: stur            w1, [x0, #0x1b]
    // 0xdf6a1c: r1 = Instance_Cubic
    //     0xdf6a1c: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e970] Obj!Cubic@129f541
    //     0xdf6a20: ldr             x1, [x1, #0x970]
    // 0xdf6a24: StoreField: r0->field_1f = r1
    //     0xdf6a24: stur            w1, [x0, #0x1f]
    // 0xdf6a28: r1 = false
    //     0xdf6a28: add             x1, NULL, #0x30  ; false
    // 0xdf6a2c: StoreField: r0->field_27 = r1
    //     0xdf6a2c: stur            w1, [x0, #0x27]
    // 0xdf6a30: LeaveFrame
    //     0xdf6a30: mov             SP, fp
    //     0xdf6a34: ldp             fp, lr, [SP], #0x10
    // 0xdf6a38: ret
    //     0xdf6a38: ret             
    // 0xdf6a3c: r9 = _tileController
    //     0xdf6a3c: add             x9, PP, #0x95, lsl #12  ; [pp+0x95cb0] Field <_ExpansionTileState@747392950._tileController@747392950>: late (offset: 0x3c)
    //     0xdf6a40: ldr             x9, [x9, #0xcb0]
    // 0xdf6a44: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdf6a44: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdf6a48: r9 = _curve
    //     0xdf6a48: add             x9, PP, #0x95, lsl #12  ; [pp+0x95cb8] Field <_ExpansionTileState@747392950._curve@747392950>: late (offset: 0x44)
    //     0xdf6a4c: ldr             x9, [x9, #0xcb8]
    // 0xdf6a50: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdf6a50: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdf6a54: r9 = _duration
    //     0xdf6a54: add             x9, PP, #0x95, lsl #12  ; [pp+0x95cc0] Field <_ExpansionTileState@747392950._duration@747392950>: late (offset: 0x4c)
    //     0xdf6a58: ldr             x9, [x9, #0xcc0]
    // 0xdf6a5c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdf6a5c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdf6a60: r9 = _reverseCurve
    //     0xdf6a60: add             x9, PP, #0x95, lsl #12  ; [pp+0x95cc8] Field <_ExpansionTileState@747392950._reverseCurve@747392950>: late (offset: 0x48)
    //     0xdf6a64: ldr             x9, [x9, #0xcc8]
    // 0xdf6a68: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdf6a68: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdf6a6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf6a6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xef44a0, size: 0x15c
    // 0xef44a0: EnterFrame
    //     0xef44a0: stp             fp, lr, [SP, #-0x10]!
    //     0xef44a4: mov             fp, SP
    // 0xef44a8: AllocStack(0x18)
    //     0xef44a8: sub             SP, SP, #0x18
    // 0xef44ac: SetupParameters(_ExpansionTileState this /* r1 => r0, fp-0x8 */)
    //     0xef44ac: mov             x0, x1
    //     0xef44b0: stur            x1, [fp, #-8]
    // 0xef44b4: CheckStackOverflow
    //     0xef44b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef44b8: cmp             SP, x16
    //     0xef44bc: b.ls            #0xef45e4
    // 0xef44c0: LoadField: r1 = r0->field_f
    //     0xef44c0: ldur            w1, [x0, #0xf]
    // 0xef44c4: DecompressPointer r1
    //     0xef44c4: add             x1, x1, HEAP, lsl #32
    // 0xef44c8: cmp             w1, NULL
    // 0xef44cc: b.eq            #0xef45ec
    // 0xef44d0: r0 = of()
    //     0xef44d0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xef44d4: mov             x2, x0
    // 0xef44d8: ldur            x0, [fp, #-8]
    // 0xef44dc: stur            x2, [fp, #-0x10]
    // 0xef44e0: LoadField: r1 = r0->field_f
    //     0xef44e0: ldur            w1, [x0, #0xf]
    // 0xef44e4: DecompressPointer r1
    //     0xef44e4: add             x1, x1, HEAP, lsl #32
    // 0xef44e8: cmp             w1, NULL
    // 0xef44ec: b.eq            #0xef45f0
    // 0xef44f0: r0 = of()
    //     0xef44f0: bl              #0xef50b8  ; [package:flutter/src/material/expansion_tile_theme.dart] ExpansionTileTheme::of
    // 0xef44f4: ldur            x1, [fp, #-8]
    // 0xef44f8: StoreField: r1->field_37 = r0
    //     0xef44f8: stur            w0, [x1, #0x37]
    //     0xef44fc: ldurb           w16, [x1, #-1]
    //     0xef4500: ldurb           w17, [x0, #-1]
    //     0xef4504: and             x16, x17, x16, lsr #2
    //     0xef4508: tst             x16, HEAP, lsr #32
    //     0xef450c: b.eq            #0xef4514
    //     0xef4510: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef4514: ldur            x2, [fp, #-0x10]
    // 0xef4518: LoadField: r0 = r2->field_2f
    //     0xef4518: ldur            w0, [x2, #0x2f]
    // 0xef451c: DecompressPointer r0
    //     0xef451c: add             x0, x0, HEAP, lsl #32
    // 0xef4520: tbnz            w0, #4, #0xef455c
    // 0xef4524: LoadField: r0 = r1->field_f
    //     0xef4524: ldur            w0, [x1, #0xf]
    // 0xef4528: DecompressPointer r0
    //     0xef4528: add             x0, x0, HEAP, lsl #32
    // 0xef452c: stur            x0, [fp, #-0x18]
    // 0xef4530: cmp             w0, NULL
    // 0xef4534: b.eq            #0xef45f4
    // 0xef4538: r0 = _ExpansionTileDefaultsM3()
    //     0xef4538: bl              #0xef50ac  ; Allocate_ExpansionTileDefaultsM3Stub -> _ExpansionTileDefaultsM3 (size=0x48)
    // 0xef453c: mov             x1, x0
    // 0xef4540: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xef4544: StoreField: r1->field_3f = r0
    //     0xef4544: stur            w0, [x1, #0x3f]
    // 0xef4548: StoreField: r1->field_43 = r0
    //     0xef4548: stur            w0, [x1, #0x43]
    // 0xef454c: ldur            x0, [fp, #-0x18]
    // 0xef4550: StoreField: r1->field_3b = r0
    //     0xef4550: stur            w0, [x1, #0x3b]
    // 0xef4554: mov             x2, x1
    // 0xef4558: b               #0xef4594
    // 0xef455c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xef4560: LoadField: r2 = r1->field_f
    //     0xef4560: ldur            w2, [x1, #0xf]
    // 0xef4564: DecompressPointer r2
    //     0xef4564: add             x2, x2, HEAP, lsl #32
    // 0xef4568: stur            x2, [fp, #-0x18]
    // 0xef456c: cmp             w2, NULL
    // 0xef4570: b.eq            #0xef45f8
    // 0xef4574: r0 = _ExpansionTileDefaultsM2()
    //     0xef4574: bl              #0xef50a0  ; Allocate_ExpansionTileDefaultsM2Stub -> _ExpansionTileDefaultsM2 (size=0x48)
    // 0xef4578: mov             x1, x0
    // 0xef457c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xef4580: StoreField: r1->field_3f = r0
    //     0xef4580: stur            w0, [x1, #0x3f]
    // 0xef4584: StoreField: r1->field_43 = r0
    //     0xef4584: stur            w0, [x1, #0x43]
    // 0xef4588: ldur            x0, [fp, #-0x18]
    // 0xef458c: StoreField: r1->field_3b = r0
    //     0xef458c: stur            w0, [x1, #0x3b]
    // 0xef4590: mov             x2, x1
    // 0xef4594: ldur            x1, [fp, #-8]
    // 0xef4598: stur            x2, [fp, #-0x18]
    // 0xef459c: r0 = _updateAnimationDuration()
    //     0xef459c: bl              #0xef5048  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_updateAnimationDuration
    // 0xef45a0: ldur            x1, [fp, #-8]
    // 0xef45a4: ldur            x2, [fp, #-0x10]
    // 0xef45a8: r0 = _updateShapeBorder()
    //     0xef45a8: bl              #0xef4e90  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_updateShapeBorder
    // 0xef45ac: ldur            x1, [fp, #-8]
    // 0xef45b0: ldur            x2, [fp, #-0x18]
    // 0xef45b4: r0 = _updateHeaderColor()
    //     0xef45b4: bl              #0xef4bc4  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_updateHeaderColor
    // 0xef45b8: ldur            x1, [fp, #-8]
    // 0xef45bc: ldur            x2, [fp, #-0x18]
    // 0xef45c0: r0 = _updateIconColor()
    //     0xef45c0: bl              #0xef47ec  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_updateIconColor
    // 0xef45c4: ldur            x1, [fp, #-8]
    // 0xef45c8: r0 = _updateBackgroundColor()
    //     0xef45c8: bl              #0xef4658  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_updateBackgroundColor
    // 0xef45cc: ldur            x1, [fp, #-8]
    // 0xef45d0: r0 = _updateHeightFactorCurve()
    //     0xef45d0: bl              #0xef45fc  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_updateHeightFactorCurve
    // 0xef45d4: r0 = Null
    //     0xef45d4: mov             x0, NULL
    // 0xef45d8: LeaveFrame
    //     0xef45d8: mov             SP, fp
    //     0xef45dc: ldp             fp, lr, [SP], #0x10
    // 0xef45e0: ret
    //     0xef45e0: ret             
    // 0xef45e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef45e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef45e8: b               #0xef44c0
    // 0xef45ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef45ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef45f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef45f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef45f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef45f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef45f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef45f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateHeightFactorCurve(/* No info */) {
    // ** addr: 0xef45fc, size: 0x5c
    // 0xef45fc: EnterFrame
    //     0xef45fc: stp             fp, lr, [SP, #-0x10]!
    //     0xef4600: mov             fp, SP
    // 0xef4604: r2 = Instance_Cubic
    //     0xef4604: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e970] Obj!Cubic@129f541
    //     0xef4608: ldr             x2, [x2, #0x970]
    // 0xef460c: LoadField: r3 = r1->field_b
    //     0xef460c: ldur            w3, [x1, #0xb]
    // 0xef4610: DecompressPointer r3
    //     0xef4610: add             x3, x3, HEAP, lsl #32
    // 0xef4614: cmp             w3, NULL
    // 0xef4618: b.eq            #0xef4648
    // 0xef461c: LoadField: r3 = r1->field_37
    //     0xef461c: ldur            w3, [x1, #0x37]
    // 0xef4620: DecompressPointer r3
    //     0xef4620: add             x3, x3, HEAP, lsl #32
    // 0xef4624: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef4628: cmp             w3, w16
    // 0xef462c: b.eq            #0xef464c
    // 0xef4630: StoreField: r1->field_43 = r2
    //     0xef4630: stur            w2, [x1, #0x43]
    // 0xef4634: StoreField: r1->field_47 = rNULL
    //     0xef4634: stur            NULL, [x1, #0x47]
    // 0xef4638: r0 = Null
    //     0xef4638: mov             x0, NULL
    // 0xef463c: LeaveFrame
    //     0xef463c: mov             SP, fp
    //     0xef4640: ldp             fp, lr, [SP], #0x10
    // 0xef4644: ret
    //     0xef4644: ret             
    // 0xef4648: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef4648: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef464c: r9 = _expansionTileTheme
    //     0xef464c: add             x9, PP, #0x95, lsl #12  ; [pp+0x95ce0] Field <_ExpansionTileState@747392950._expansionTileTheme@747392950>: late (offset: 0x38)
    //     0xef4650: ldr             x9, [x9, #0xce0]
    // 0xef4654: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef4654: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _updateBackgroundColor(/* No info */) {
    // ** addr: 0xef4658, size: 0x194
    // 0xef4658: EnterFrame
    //     0xef4658: stp             fp, lr, [SP, #-0x10]!
    //     0xef465c: mov             fp, SP
    // 0xef4660: AllocStack(0x28)
    //     0xef4660: sub             SP, SP, #0x28
    // 0xef4664: SetupParameters(_ExpansionTileState this /* r1 => r3, fp-0x28 */)
    //     0xef4664: mov             x3, x1
    //     0xef4668: stur            x1, [fp, #-0x28]
    // 0xef466c: LoadField: r4 = r3->field_1f
    //     0xef466c: ldur            w4, [x3, #0x1f]
    // 0xef4670: DecompressPointer r4
    //     0xef4670: add             x4, x4, HEAP, lsl #32
    // 0xef4674: stur            x4, [fp, #-0x20]
    // 0xef4678: LoadField: r5 = r3->field_b
    //     0xef4678: ldur            w5, [x3, #0xb]
    // 0xef467c: DecompressPointer r5
    //     0xef467c: add             x5, x5, HEAP, lsl #32
    // 0xef4680: stur            x5, [fp, #-0x18]
    // 0xef4684: cmp             w5, NULL
    // 0xef4688: b.eq            #0xef47d0
    // 0xef468c: LoadField: r0 = r5->field_23
    //     0xef468c: ldur            w0, [x5, #0x23]
    // 0xef4690: DecompressPointer r0
    //     0xef4690: add             x0, x0, HEAP, lsl #32
    // 0xef4694: cmp             w0, NULL
    // 0xef4698: b.ne            #0xef46b8
    // 0xef469c: LoadField: r0 = r3->field_37
    //     0xef469c: ldur            w0, [x3, #0x37]
    // 0xef46a0: DecompressPointer r0
    //     0xef46a0: add             x0, x0, HEAP, lsl #32
    // 0xef46a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef46a8: cmp             w0, w16
    // 0xef46ac: b.eq            #0xef47d4
    // 0xef46b0: r6 = Null
    //     0xef46b0: mov             x6, NULL
    // 0xef46b4: b               #0xef46bc
    // 0xef46b8: mov             x6, x0
    // 0xef46bc: stur            x6, [fp, #-0x10]
    // 0xef46c0: LoadField: r7 = r4->field_7
    //     0xef46c0: ldur            w7, [x4, #7]
    // 0xef46c4: DecompressPointer r7
    //     0xef46c4: add             x7, x7, HEAP, lsl #32
    // 0xef46c8: mov             x0, x6
    // 0xef46cc: mov             x2, x7
    // 0xef46d0: stur            x7, [fp, #-8]
    // 0xef46d4: r1 = Null
    //     0xef46d4: mov             x1, NULL
    // 0xef46d8: cmp             w0, NULL
    // 0xef46dc: b.eq            #0xef4704
    // 0xef46e0: cmp             w2, NULL
    // 0xef46e4: b.eq            #0xef4704
    // 0xef46e8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xef46e8: ldur            w4, [x2, #0x17]
    // 0xef46ec: DecompressPointer r4
    //     0xef46ec: add             x4, x4, HEAP, lsl #32
    // 0xef46f0: r8 = X0?
    //     0xef46f0: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0xef46f4: LoadField: r9 = r4->field_7
    //     0xef46f4: ldur            x9, [x4, #7]
    // 0xef46f8: r3 = Null
    //     0xef46f8: add             x3, PP, #0x95, lsl #12  ; [pp+0x95d48] Null
    //     0xef46fc: ldr             x3, [x3, #0xd48]
    // 0xef4700: blr             x9
    // 0xef4704: ldur            x0, [fp, #-0x10]
    // 0xef4708: ldur            x3, [fp, #-0x20]
    // 0xef470c: StoreField: r3->field_b = r0
    //     0xef470c: stur            w0, [x3, #0xb]
    //     0xef4710: ldurb           w16, [x3, #-1]
    //     0xef4714: ldurb           w17, [x0, #-1]
    //     0xef4718: and             x16, x17, x16, lsr #2
    //     0xef471c: tst             x16, HEAP, lsr #32
    //     0xef4720: b.eq            #0xef4728
    //     0xef4724: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xef4728: ldur            x0, [fp, #-0x18]
    // 0xef472c: LoadField: r1 = r0->field_1f
    //     0xef472c: ldur            w1, [x0, #0x1f]
    // 0xef4730: DecompressPointer r1
    //     0xef4730: add             x1, x1, HEAP, lsl #32
    // 0xef4734: cmp             w1, NULL
    // 0xef4738: b.ne            #0xef475c
    // 0xef473c: ldur            x0, [fp, #-0x28]
    // 0xef4740: LoadField: r1 = r0->field_37
    //     0xef4740: ldur            w1, [x0, #0x37]
    // 0xef4744: DecompressPointer r1
    //     0xef4744: add             x1, x1, HEAP, lsl #32
    // 0xef4748: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef474c: cmp             w1, w16
    // 0xef4750: b.eq            #0xef47e0
    // 0xef4754: r4 = Null
    //     0xef4754: mov             x4, NULL
    // 0xef4758: b               #0xef4760
    // 0xef475c: mov             x4, x1
    // 0xef4760: mov             x0, x4
    // 0xef4764: ldur            x2, [fp, #-8]
    // 0xef4768: stur            x4, [fp, #-0x10]
    // 0xef476c: r1 = Null
    //     0xef476c: mov             x1, NULL
    // 0xef4770: cmp             w0, NULL
    // 0xef4774: b.eq            #0xef479c
    // 0xef4778: cmp             w2, NULL
    // 0xef477c: b.eq            #0xef479c
    // 0xef4780: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xef4780: ldur            w4, [x2, #0x17]
    // 0xef4784: DecompressPointer r4
    //     0xef4784: add             x4, x4, HEAP, lsl #32
    // 0xef4788: r8 = X0?
    //     0xef4788: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0xef478c: LoadField: r9 = r4->field_7
    //     0xef478c: ldur            x9, [x4, #7]
    // 0xef4790: r3 = Null
    //     0xef4790: add             x3, PP, #0x95, lsl #12  ; [pp+0x95d58] Null
    //     0xef4794: ldr             x3, [x3, #0xd58]
    // 0xef4798: blr             x9
    // 0xef479c: ldur            x0, [fp, #-0x10]
    // 0xef47a0: ldur            x1, [fp, #-0x20]
    // 0xef47a4: StoreField: r1->field_f = r0
    //     0xef47a4: stur            w0, [x1, #0xf]
    //     0xef47a8: ldurb           w16, [x1, #-1]
    //     0xef47ac: ldurb           w17, [x0, #-1]
    //     0xef47b0: and             x16, x17, x16, lsr #2
    //     0xef47b4: tst             x16, HEAP, lsr #32
    //     0xef47b8: b.eq            #0xef47c0
    //     0xef47bc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef47c0: r0 = Null
    //     0xef47c0: mov             x0, NULL
    // 0xef47c4: LeaveFrame
    //     0xef47c4: mov             SP, fp
    //     0xef47c8: ldp             fp, lr, [SP], #0x10
    // 0xef47cc: ret
    //     0xef47cc: ret             
    // 0xef47d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef47d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef47d4: r9 = _expansionTileTheme
    //     0xef47d4: add             x9, PP, #0x95, lsl #12  ; [pp+0x95ce0] Field <_ExpansionTileState@747392950._expansionTileTheme@747392950>: late (offset: 0x38)
    //     0xef47d8: ldr             x9, [x9, #0xce0]
    // 0xef47dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef47dc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xef47e0: r9 = _expansionTileTheme
    //     0xef47e0: add             x9, PP, #0x95, lsl #12  ; [pp+0x95ce0] Field <_ExpansionTileState@747392950._expansionTileTheme@747392950>: late (offset: 0x38)
    //     0xef47e4: ldr             x9, [x9, #0xce0]
    // 0xef47e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef47e8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _updateIconColor(/* No info */) {
    // ** addr: 0xef47ec, size: 0x328
    // 0xef47ec: EnterFrame
    //     0xef47ec: stp             fp, lr, [SP, #-0x10]!
    //     0xef47f0: mov             fp, SP
    // 0xef47f4: AllocStack(0x28)
    //     0xef47f4: sub             SP, SP, #0x28
    // 0xef47f8: SetupParameters(_ExpansionTileState this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xef47f8: mov             x0, x2
    //     0xef47fc: stur            x2, [fp, #-0x18]
    //     0xef4800: mov             x2, x1
    //     0xef4804: stur            x1, [fp, #-0x10]
    // 0xef4808: CheckStackOverflow
    //     0xef4808: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef480c: cmp             SP, x16
    //     0xef4810: b.ls            #0xef4aec
    // 0xef4814: LoadField: r3 = r2->field_1b
    //     0xef4814: ldur            w3, [x2, #0x1b]
    // 0xef4818: DecompressPointer r3
    //     0xef4818: add             x3, x3, HEAP, lsl #32
    // 0xef481c: stur            x3, [fp, #-8]
    // 0xef4820: LoadField: r1 = r2->field_b
    //     0xef4820: ldur            w1, [x2, #0xb]
    // 0xef4824: DecompressPointer r1
    //     0xef4824: add             x1, x1, HEAP, lsl #32
    // 0xef4828: cmp             w1, NULL
    // 0xef482c: b.eq            #0xef4af4
    // 0xef4830: LoadField: r4 = r1->field_4b
    //     0xef4830: ldur            w4, [x1, #0x4b]
    // 0xef4834: DecompressPointer r4
    //     0xef4834: add             x4, x4, HEAP, lsl #32
    // 0xef4838: cmp             w4, NULL
    // 0xef483c: b.ne            #0xef485c
    // 0xef4840: LoadField: r1 = r2->field_37
    //     0xef4840: ldur            w1, [x2, #0x37]
    // 0xef4844: DecompressPointer r1
    //     0xef4844: add             x1, x1, HEAP, lsl #32
    // 0xef4848: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef484c: cmp             w1, w16
    // 0xef4850: b.eq            #0xef4af8
    // 0xef4854: r1 = Null
    //     0xef4854: mov             x1, NULL
    // 0xef4858: b               #0xef4860
    // 0xef485c: mov             x1, x4
    // 0xef4860: cmp             w1, NULL
    // 0xef4864: b.ne            #0xef491c
    // 0xef4868: r1 = LoadClassIdInstr(r0)
    //     0xef4868: ldur            x1, [x0, #-1]
    //     0xef486c: ubfx            x1, x1, #0xc, #0x14
    // 0xef4870: r17 = 5152
    //     0xef4870: mov             x17, #0x1420
    // 0xef4874: cmp             x1, x17
    // 0xef4878: b.ne            #0xef488c
    // 0xef487c: LoadField: r1 = r0->field_1f
    //     0xef487c: ldur            w1, [x0, #0x1f]
    // 0xef4880: DecompressPointer r1
    //     0xef4880: add             x1, x1, HEAP, lsl #32
    // 0xef4884: mov             x0, x1
    // 0xef4888: b               #0xef4914
    // 0xef488c: r17 = 5153
    //     0xef488c: mov             x17, #0x1421
    // 0xef4890: cmp             x1, x17
    // 0xef4894: b.ne            #0xef48e4
    // 0xef4898: mov             x1, x0
    // 0xef489c: LoadField: r0 = r1->field_43
    //     0xef489c: ldur            w0, [x1, #0x43]
    // 0xef48a0: DecompressPointer r0
    //     0xef48a0: add             x0, x0, HEAP, lsl #32
    // 0xef48a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef48a8: cmp             w0, w16
    // 0xef48ac: b.ne            #0xef48bc
    // 0xef48b0: r2 = _colors
    //     0xef48b0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26390] Field <_ExpansionTileDefaultsM3@747392950._colors@747392950>: late final (offset: 0x44)
    //     0xef48b4: ldr             x2, [x2, #0x390]
    // 0xef48b8: r0 = InitLateFinalInstanceField()
    //     0xef48b8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xef48bc: LoadField: r1 = r0->field_a3
    //     0xef48bc: ldur            w1, [x0, #0xa3]
    // 0xef48c0: DecompressPointer r1
    //     0xef48c0: add             x1, x1, HEAP, lsl #32
    // 0xef48c4: cmp             w1, NULL
    // 0xef48c8: b.ne            #0xef48dc
    // 0xef48cc: LoadField: r1 = r0->field_7f
    //     0xef48cc: ldur            w1, [x0, #0x7f]
    // 0xef48d0: DecompressPointer r1
    //     0xef48d0: add             x1, x1, HEAP, lsl #32
    // 0xef48d4: mov             x0, x1
    // 0xef48d8: b               #0xef4914
    // 0xef48dc: mov             x0, x1
    // 0xef48e0: b               #0xef4914
    // 0xef48e4: ldur            x1, [fp, #-0x18]
    // 0xef48e8: LoadField: r0 = r1->field_3f
    //     0xef48e8: ldur            w0, [x1, #0x3f]
    // 0xef48ec: DecompressPointer r0
    //     0xef48ec: add             x0, x0, HEAP, lsl #32
    // 0xef48f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef48f4: cmp             w0, w16
    // 0xef48f8: b.ne            #0xef4908
    // 0xef48fc: r2 = _theme
    //     0xef48fc: add             x2, PP, #0x26, lsl #12  ; [pp+0x263a0] Field <_ExpansionTileDefaultsM2@747392950._theme@747392950>: late final (offset: 0x40)
    //     0xef4900: ldr             x2, [x2, #0x3a0]
    // 0xef4904: r0 = InitLateFinalInstanceField()
    //     0xef4904: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xef4908: LoadField: r1 = r0->field_77
    //     0xef4908: ldur            w1, [x0, #0x77]
    // 0xef490c: DecompressPointer r1
    //     0xef490c: add             x1, x1, HEAP, lsl #32
    // 0xef4910: mov             x0, x1
    // 0xef4914: mov             x5, x0
    // 0xef4918: b               #0xef4920
    // 0xef491c: mov             x5, x1
    // 0xef4920: ldur            x3, [fp, #-0x10]
    // 0xef4924: ldur            x4, [fp, #-8]
    // 0xef4928: stur            x5, [fp, #-0x28]
    // 0xef492c: LoadField: r6 = r4->field_7
    //     0xef492c: ldur            w6, [x4, #7]
    // 0xef4930: DecompressPointer r6
    //     0xef4930: add             x6, x6, HEAP, lsl #32
    // 0xef4934: mov             x0, x5
    // 0xef4938: mov             x2, x6
    // 0xef493c: stur            x6, [fp, #-0x20]
    // 0xef4940: r1 = Null
    //     0xef4940: mov             x1, NULL
    // 0xef4944: cmp             w0, NULL
    // 0xef4948: b.eq            #0xef4970
    // 0xef494c: cmp             w2, NULL
    // 0xef4950: b.eq            #0xef4970
    // 0xef4954: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xef4954: ldur            w4, [x2, #0x17]
    // 0xef4958: DecompressPointer r4
    //     0xef4958: add             x4, x4, HEAP, lsl #32
    // 0xef495c: r8 = X0?
    //     0xef495c: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0xef4960: LoadField: r9 = r4->field_7
    //     0xef4960: ldur            x9, [x4, #7]
    // 0xef4964: r3 = Null
    //     0xef4964: add             x3, PP, #0x95, lsl #12  ; [pp+0x95d68] Null
    //     0xef4968: ldr             x3, [x3, #0xd68]
    // 0xef496c: blr             x9
    // 0xef4970: ldur            x0, [fp, #-0x28]
    // 0xef4974: ldur            x2, [fp, #-8]
    // 0xef4978: StoreField: r2->field_b = r0
    //     0xef4978: stur            w0, [x2, #0xb]
    //     0xef497c: ldurb           w16, [x2, #-1]
    //     0xef4980: ldurb           w17, [x0, #-1]
    //     0xef4984: and             x16, x17, x16, lsr #2
    //     0xef4988: tst             x16, HEAP, lsr #32
    //     0xef498c: b.eq            #0xef4994
    //     0xef4990: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xef4994: ldur            x0, [fp, #-0x10]
    // 0xef4998: LoadField: r1 = r0->field_b
    //     0xef4998: ldur            w1, [x0, #0xb]
    // 0xef499c: DecompressPointer r1
    //     0xef499c: add             x1, x1, HEAP, lsl #32
    // 0xef49a0: cmp             w1, NULL
    // 0xef49a4: b.eq            #0xef4b04
    // 0xef49a8: LoadField: r3 = r1->field_47
    //     0xef49a8: ldur            w3, [x1, #0x47]
    // 0xef49ac: DecompressPointer r3
    //     0xef49ac: add             x3, x3, HEAP, lsl #32
    // 0xef49b0: cmp             w3, NULL
    // 0xef49b4: b.ne            #0xef49d4
    // 0xef49b8: LoadField: r1 = r0->field_37
    //     0xef49b8: ldur            w1, [x0, #0x37]
    // 0xef49bc: DecompressPointer r1
    //     0xef49bc: add             x1, x1, HEAP, lsl #32
    // 0xef49c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef49c4: cmp             w1, w16
    // 0xef49c8: b.eq            #0xef4b08
    // 0xef49cc: r0 = Null
    //     0xef49cc: mov             x0, NULL
    // 0xef49d0: b               #0xef49d8
    // 0xef49d4: mov             x0, x3
    // 0xef49d8: cmp             w0, NULL
    // 0xef49dc: b.ne            #0xef4a74
    // 0xef49e0: ldur            x1, [fp, #-0x18]
    // 0xef49e4: r0 = LoadClassIdInstr(r1)
    //     0xef49e4: ldur            x0, [x1, #-1]
    //     0xef49e8: ubfx            x0, x0, #0xc, #0x14
    // 0xef49ec: r17 = 5152
    //     0xef49ec: mov             x17, #0x1420
    // 0xef49f0: cmp             x0, x17
    // 0xef49f4: b.ne            #0xef4a04
    // 0xef49f8: LoadField: r0 = r1->field_1b
    //     0xef49f8: ldur            w0, [x1, #0x1b]
    // 0xef49fc: DecompressPointer r0
    //     0xef49fc: add             x0, x0, HEAP, lsl #32
    // 0xef4a00: b               #0xef4a6c
    // 0xef4a04: r17 = 5153
    //     0xef4a04: mov             x17, #0x1421
    // 0xef4a08: cmp             x0, x17
    // 0xef4a0c: b.ne            #0xef4a40
    // 0xef4a10: LoadField: r0 = r1->field_43
    //     0xef4a10: ldur            w0, [x1, #0x43]
    // 0xef4a14: DecompressPointer r0
    //     0xef4a14: add             x0, x0, HEAP, lsl #32
    // 0xef4a18: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef4a1c: cmp             w0, w16
    // 0xef4a20: b.ne            #0xef4a30
    // 0xef4a24: r2 = _colors
    //     0xef4a24: add             x2, PP, #0x26, lsl #12  ; [pp+0x26390] Field <_ExpansionTileDefaultsM3@747392950._colors@747392950>: late final (offset: 0x44)
    //     0xef4a28: ldr             x2, [x2, #0x390]
    // 0xef4a2c: r0 = InitLateFinalInstanceField()
    //     0xef4a2c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xef4a30: LoadField: r1 = r0->field_b
    //     0xef4a30: ldur            w1, [x0, #0xb]
    // 0xef4a34: DecompressPointer r1
    //     0xef4a34: add             x1, x1, HEAP, lsl #32
    // 0xef4a38: mov             x0, x1
    // 0xef4a3c: b               #0xef4a6c
    // 0xef4a40: LoadField: r0 = r1->field_43
    //     0xef4a40: ldur            w0, [x1, #0x43]
    // 0xef4a44: DecompressPointer r0
    //     0xef4a44: add             x0, x0, HEAP, lsl #32
    // 0xef4a48: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef4a4c: cmp             w0, w16
    // 0xef4a50: b.ne            #0xef4a60
    // 0xef4a54: r2 = _colorScheme
    //     0xef4a54: add             x2, PP, #0x26, lsl #12  ; [pp+0x26398] Field <_ExpansionTileDefaultsM2@747392950._colorScheme@747392950>: late final (offset: 0x44)
    //     0xef4a58: ldr             x2, [x2, #0x398]
    // 0xef4a5c: r0 = InitLateFinalInstanceField()
    //     0xef4a5c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xef4a60: LoadField: r1 = r0->field_b
    //     0xef4a60: ldur            w1, [x0, #0xb]
    // 0xef4a64: DecompressPointer r1
    //     0xef4a64: add             x1, x1, HEAP, lsl #32
    // 0xef4a68: mov             x0, x1
    // 0xef4a6c: mov             x4, x0
    // 0xef4a70: b               #0xef4a78
    // 0xef4a74: mov             x4, x0
    // 0xef4a78: ldur            x3, [fp, #-8]
    // 0xef4a7c: mov             x0, x4
    // 0xef4a80: ldur            x2, [fp, #-0x20]
    // 0xef4a84: stur            x4, [fp, #-0x10]
    // 0xef4a88: r1 = Null
    //     0xef4a88: mov             x1, NULL
    // 0xef4a8c: cmp             w0, NULL
    // 0xef4a90: b.eq            #0xef4ab8
    // 0xef4a94: cmp             w2, NULL
    // 0xef4a98: b.eq            #0xef4ab8
    // 0xef4a9c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xef4a9c: ldur            w4, [x2, #0x17]
    // 0xef4aa0: DecompressPointer r4
    //     0xef4aa0: add             x4, x4, HEAP, lsl #32
    // 0xef4aa4: r8 = X0?
    //     0xef4aa4: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0xef4aa8: LoadField: r9 = r4->field_7
    //     0xef4aa8: ldur            x9, [x4, #7]
    // 0xef4aac: r3 = Null
    //     0xef4aac: add             x3, PP, #0x95, lsl #12  ; [pp+0x95d78] Null
    //     0xef4ab0: ldr             x3, [x3, #0xd78]
    // 0xef4ab4: blr             x9
    // 0xef4ab8: ldur            x0, [fp, #-0x10]
    // 0xef4abc: ldur            x1, [fp, #-8]
    // 0xef4ac0: StoreField: r1->field_f = r0
    //     0xef4ac0: stur            w0, [x1, #0xf]
    //     0xef4ac4: ldurb           w16, [x1, #-1]
    //     0xef4ac8: ldurb           w17, [x0, #-1]
    //     0xef4acc: and             x16, x17, x16, lsr #2
    //     0xef4ad0: tst             x16, HEAP, lsr #32
    //     0xef4ad4: b.eq            #0xef4adc
    //     0xef4ad8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef4adc: r0 = Null
    //     0xef4adc: mov             x0, NULL
    // 0xef4ae0: LeaveFrame
    //     0xef4ae0: mov             SP, fp
    //     0xef4ae4: ldp             fp, lr, [SP], #0x10
    // 0xef4ae8: ret
    //     0xef4ae8: ret             
    // 0xef4aec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef4aec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef4af0: b               #0xef4814
    // 0xef4af4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef4af4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef4af8: r9 = _expansionTileTheme
    //     0xef4af8: add             x9, PP, #0x95, lsl #12  ; [pp+0x95ce0] Field <_ExpansionTileState@747392950._expansionTileTheme@747392950>: late (offset: 0x38)
    //     0xef4afc: ldr             x9, [x9, #0xce0]
    // 0xef4b00: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef4b00: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xef4b04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef4b04: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef4b08: r9 = _expansionTileTheme
    //     0xef4b08: add             x9, PP, #0x95, lsl #12  ; [pp+0x95ce0] Field <_ExpansionTileState@747392950._expansionTileTheme@747392950>: late (offset: 0x38)
    //     0xef4b0c: ldr             x9, [x9, #0xce0]
    // 0xef4b10: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef4b10: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _updateHeaderColor(/* No info */) {
    // ** addr: 0xef4bc4, size: 0x2cc
    // 0xef4bc4: EnterFrame
    //     0xef4bc4: stp             fp, lr, [SP, #-0x10]!
    //     0xef4bc8: mov             fp, SP
    // 0xef4bcc: AllocStack(0x30)
    //     0xef4bcc: sub             SP, SP, #0x30
    // 0xef4bd0: SetupParameters(_ExpansionTileState this /* r1 => r2, fp-0x18 */, dynamic _ /* r2 => r0, fp-0x20 */)
    //     0xef4bd0: mov             x0, x2
    //     0xef4bd4: stur            x2, [fp, #-0x20]
    //     0xef4bd8: mov             x2, x1
    //     0xef4bdc: stur            x1, [fp, #-0x18]
    // 0xef4be0: CheckStackOverflow
    //     0xef4be0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef4be4: cmp             SP, x16
    //     0xef4be8: b.ls            #0xef4e74
    // 0xef4bec: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xef4bec: ldur            w3, [x2, #0x17]
    // 0xef4bf0: DecompressPointer r3
    //     0xef4bf0: add             x3, x3, HEAP, lsl #32
    // 0xef4bf4: stur            x3, [fp, #-0x10]
    // 0xef4bf8: LoadField: r1 = r2->field_b
    //     0xef4bf8: ldur            w1, [x2, #0xb]
    // 0xef4bfc: DecompressPointer r1
    //     0xef4bfc: add             x1, x1, HEAP, lsl #32
    // 0xef4c00: cmp             w1, NULL
    // 0xef4c04: b.eq            #0xef4e7c
    // 0xef4c08: LoadField: r1 = r2->field_37
    //     0xef4c08: ldur            w1, [x2, #0x37]
    // 0xef4c0c: DecompressPointer r1
    //     0xef4c0c: add             x1, x1, HEAP, lsl #32
    // 0xef4c10: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef4c14: cmp             w1, w16
    // 0xef4c18: b.eq            #0xef4e80
    // 0xef4c1c: r4 = LoadClassIdInstr(r0)
    //     0xef4c1c: ldur            x4, [x0, #-1]
    //     0xef4c20: ubfx            x4, x4, #0xc, #0x14
    // 0xef4c24: stur            x4, [fp, #-8]
    // 0xef4c28: r17 = 5152
    //     0xef4c28: mov             x17, #0x1420
    // 0xef4c2c: cmp             x4, x17
    // 0xef4c30: b.ne            #0xef4c50
    // 0xef4c34: LoadField: r1 = r0->field_27
    //     0xef4c34: ldur            w1, [x0, #0x27]
    // 0xef4c38: DecompressPointer r1
    //     0xef4c38: add             x1, x1, HEAP, lsl #32
    // 0xef4c3c: mov             x6, x1
    // 0xef4c40: mov             x5, x4
    // 0xef4c44: mov             x4, x3
    // 0xef4c48: mov             x3, x2
    // 0xef4c4c: b               #0xef4ce8
    // 0xef4c50: r17 = 5153
    //     0xef4c50: mov             x17, #0x1421
    // 0xef4c54: cmp             x4, x17
    // 0xef4c58: b.ne            #0xef4c9c
    // 0xef4c5c: mov             x1, x0
    // 0xef4c60: LoadField: r0 = r1->field_43
    //     0xef4c60: ldur            w0, [x1, #0x43]
    // 0xef4c64: DecompressPointer r0
    //     0xef4c64: add             x0, x0, HEAP, lsl #32
    // 0xef4c68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef4c6c: cmp             w0, w16
    // 0xef4c70: b.ne            #0xef4c80
    // 0xef4c74: r2 = _colors
    //     0xef4c74: add             x2, PP, #0x26, lsl #12  ; [pp+0x26390] Field <_ExpansionTileDefaultsM3@747392950._colors@747392950>: late final (offset: 0x44)
    //     0xef4c78: ldr             x2, [x2, #0x390]
    // 0xef4c7c: r0 = InitLateFinalInstanceField()
    //     0xef4c7c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xef4c80: LoadField: r1 = r0->field_7f
    //     0xef4c80: ldur            w1, [x0, #0x7f]
    // 0xef4c84: DecompressPointer r1
    //     0xef4c84: add             x1, x1, HEAP, lsl #32
    // 0xef4c88: mov             x6, x1
    // 0xef4c8c: ldur            x3, [fp, #-0x18]
    // 0xef4c90: ldur            x4, [fp, #-0x10]
    // 0xef4c94: ldur            x5, [fp, #-8]
    // 0xef4c98: b               #0xef4ce8
    // 0xef4c9c: ldur            x1, [fp, #-0x20]
    // 0xef4ca0: LoadField: r0 = r1->field_3f
    //     0xef4ca0: ldur            w0, [x1, #0x3f]
    // 0xef4ca4: DecompressPointer r0
    //     0xef4ca4: add             x0, x0, HEAP, lsl #32
    // 0xef4ca8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef4cac: cmp             w0, w16
    // 0xef4cb0: b.ne            #0xef4cc0
    // 0xef4cb4: r2 = _theme
    //     0xef4cb4: add             x2, PP, #0x26, lsl #12  ; [pp+0x263a0] Field <_ExpansionTileDefaultsM2@747392950._theme@747392950>: late final (offset: 0x40)
    //     0xef4cb8: ldr             x2, [x2, #0x3a0]
    // 0xef4cbc: r0 = InitLateFinalInstanceField()
    //     0xef4cbc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xef4cc0: LoadField: r1 = r0->field_87
    //     0xef4cc0: ldur            w1, [x0, #0x87]
    // 0xef4cc4: DecompressPointer r1
    //     0xef4cc4: add             x1, x1, HEAP, lsl #32
    // 0xef4cc8: LoadField: r0 = r1->field_23
    //     0xef4cc8: ldur            w0, [x1, #0x23]
    // 0xef4ccc: DecompressPointer r0
    //     0xef4ccc: add             x0, x0, HEAP, lsl #32
    // 0xef4cd0: LoadField: r1 = r0->field_b
    //     0xef4cd0: ldur            w1, [x0, #0xb]
    // 0xef4cd4: DecompressPointer r1
    //     0xef4cd4: add             x1, x1, HEAP, lsl #32
    // 0xef4cd8: mov             x6, x1
    // 0xef4cdc: ldur            x3, [fp, #-0x18]
    // 0xef4ce0: ldur            x4, [fp, #-0x10]
    // 0xef4ce4: ldur            x5, [fp, #-8]
    // 0xef4ce8: stur            x6, [fp, #-0x30]
    // 0xef4cec: LoadField: r7 = r4->field_7
    //     0xef4cec: ldur            w7, [x4, #7]
    // 0xef4cf0: DecompressPointer r7
    //     0xef4cf0: add             x7, x7, HEAP, lsl #32
    // 0xef4cf4: mov             x0, x6
    // 0xef4cf8: mov             x2, x7
    // 0xef4cfc: stur            x7, [fp, #-0x28]
    // 0xef4d00: r1 = Null
    //     0xef4d00: mov             x1, NULL
    // 0xef4d04: cmp             w0, NULL
    // 0xef4d08: b.eq            #0xef4d30
    // 0xef4d0c: cmp             w2, NULL
    // 0xef4d10: b.eq            #0xef4d30
    // 0xef4d14: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xef4d14: ldur            w4, [x2, #0x17]
    // 0xef4d18: DecompressPointer r4
    //     0xef4d18: add             x4, x4, HEAP, lsl #32
    // 0xef4d1c: r8 = X0?
    //     0xef4d1c: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0xef4d20: LoadField: r9 = r4->field_7
    //     0xef4d20: ldur            x9, [x4, #7]
    // 0xef4d24: r3 = Null
    //     0xef4d24: add             x3, PP, #0x95, lsl #12  ; [pp+0x95d88] Null
    //     0xef4d28: ldr             x3, [x3, #0xd88]
    // 0xef4d2c: blr             x9
    // 0xef4d30: ldur            x0, [fp, #-0x30]
    // 0xef4d34: ldur            x2, [fp, #-0x10]
    // 0xef4d38: StoreField: r2->field_b = r0
    //     0xef4d38: stur            w0, [x2, #0xb]
    //     0xef4d3c: ldurb           w16, [x2, #-1]
    //     0xef4d40: ldurb           w17, [x0, #-1]
    //     0xef4d44: and             x16, x17, x16, lsr #2
    //     0xef4d48: tst             x16, HEAP, lsr #32
    //     0xef4d4c: b.eq            #0xef4d54
    //     0xef4d50: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xef4d54: ldur            x0, [fp, #-0x18]
    // 0xef4d58: LoadField: r1 = r0->field_b
    //     0xef4d58: ldur            w1, [x0, #0xb]
    // 0xef4d5c: DecompressPointer r1
    //     0xef4d5c: add             x1, x1, HEAP, lsl #32
    // 0xef4d60: cmp             w1, NULL
    // 0xef4d64: b.eq            #0xef4e8c
    // 0xef4d68: ldur            x0, [fp, #-8]
    // 0xef4d6c: r17 = 5152
    //     0xef4d6c: mov             x17, #0x1420
    // 0xef4d70: cmp             x0, x17
    // 0xef4d74: b.ne            #0xef4d90
    // 0xef4d78: ldur            x1, [fp, #-0x20]
    // 0xef4d7c: LoadField: r0 = r1->field_23
    //     0xef4d7c: ldur            w0, [x1, #0x23]
    // 0xef4d80: DecompressPointer r0
    //     0xef4d80: add             x0, x0, HEAP, lsl #32
    // 0xef4d84: mov             x4, x0
    // 0xef4d88: mov             x3, x2
    // 0xef4d8c: b               #0xef4e04
    // 0xef4d90: ldur            x1, [fp, #-0x20]
    // 0xef4d94: r17 = 5153
    //     0xef4d94: mov             x17, #0x1421
    // 0xef4d98: cmp             x0, x17
    // 0xef4d9c: b.ne            #0xef4dd4
    // 0xef4da0: LoadField: r0 = r1->field_43
    //     0xef4da0: ldur            w0, [x1, #0x43]
    // 0xef4da4: DecompressPointer r0
    //     0xef4da4: add             x0, x0, HEAP, lsl #32
    // 0xef4da8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef4dac: cmp             w0, w16
    // 0xef4db0: b.ne            #0xef4dc0
    // 0xef4db4: r2 = _colors
    //     0xef4db4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26390] Field <_ExpansionTileDefaultsM3@747392950._colors@747392950>: late final (offset: 0x44)
    //     0xef4db8: ldr             x2, [x2, #0x390]
    // 0xef4dbc: r0 = InitLateFinalInstanceField()
    //     0xef4dbc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xef4dc0: LoadField: r1 = r0->field_7f
    //     0xef4dc0: ldur            w1, [x0, #0x7f]
    // 0xef4dc4: DecompressPointer r1
    //     0xef4dc4: add             x1, x1, HEAP, lsl #32
    // 0xef4dc8: mov             x4, x1
    // 0xef4dcc: ldur            x3, [fp, #-0x10]
    // 0xef4dd0: b               #0xef4e04
    // 0xef4dd4: LoadField: r0 = r1->field_43
    //     0xef4dd4: ldur            w0, [x1, #0x43]
    // 0xef4dd8: DecompressPointer r0
    //     0xef4dd8: add             x0, x0, HEAP, lsl #32
    // 0xef4ddc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef4de0: cmp             w0, w16
    // 0xef4de4: b.ne            #0xef4df4
    // 0xef4de8: r2 = _colorScheme
    //     0xef4de8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26398] Field <_ExpansionTileDefaultsM2@747392950._colorScheme@747392950>: late final (offset: 0x44)
    //     0xef4dec: ldr             x2, [x2, #0x398]
    // 0xef4df0: r0 = InitLateFinalInstanceField()
    //     0xef4df0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xef4df4: LoadField: r1 = r0->field_b
    //     0xef4df4: ldur            w1, [x0, #0xb]
    // 0xef4df8: DecompressPointer r1
    //     0xef4df8: add             x1, x1, HEAP, lsl #32
    // 0xef4dfc: mov             x4, x1
    // 0xef4e00: ldur            x3, [fp, #-0x10]
    // 0xef4e04: mov             x0, x4
    // 0xef4e08: ldur            x2, [fp, #-0x28]
    // 0xef4e0c: stur            x4, [fp, #-0x18]
    // 0xef4e10: r1 = Null
    //     0xef4e10: mov             x1, NULL
    // 0xef4e14: cmp             w0, NULL
    // 0xef4e18: b.eq            #0xef4e40
    // 0xef4e1c: cmp             w2, NULL
    // 0xef4e20: b.eq            #0xef4e40
    // 0xef4e24: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xef4e24: ldur            w4, [x2, #0x17]
    // 0xef4e28: DecompressPointer r4
    //     0xef4e28: add             x4, x4, HEAP, lsl #32
    // 0xef4e2c: r8 = X0?
    //     0xef4e2c: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0xef4e30: LoadField: r9 = r4->field_7
    //     0xef4e30: ldur            x9, [x4, #7]
    // 0xef4e34: r3 = Null
    //     0xef4e34: add             x3, PP, #0x95, lsl #12  ; [pp+0x95d98] Null
    //     0xef4e38: ldr             x3, [x3, #0xd98]
    // 0xef4e3c: blr             x9
    // 0xef4e40: ldur            x0, [fp, #-0x18]
    // 0xef4e44: ldur            x1, [fp, #-0x10]
    // 0xef4e48: StoreField: r1->field_f = r0
    //     0xef4e48: stur            w0, [x1, #0xf]
    //     0xef4e4c: ldurb           w16, [x1, #-1]
    //     0xef4e50: ldurb           w17, [x0, #-1]
    //     0xef4e54: and             x16, x17, x16, lsr #2
    //     0xef4e58: tst             x16, HEAP, lsr #32
    //     0xef4e5c: b.eq            #0xef4e64
    //     0xef4e60: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef4e64: r0 = Null
    //     0xef4e64: mov             x0, NULL
    // 0xef4e68: LeaveFrame
    //     0xef4e68: mov             SP, fp
    //     0xef4e6c: ldp             fp, lr, [SP], #0x10
    // 0xef4e70: ret
    //     0xef4e70: ret             
    // 0xef4e74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef4e74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef4e78: b               #0xef4bec
    // 0xef4e7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef4e7c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef4e80: r9 = _expansionTileTheme
    //     0xef4e80: add             x9, PP, #0x95, lsl #12  ; [pp+0x95ce0] Field <_ExpansionTileState@747392950._expansionTileTheme@747392950>: late (offset: 0x38)
    //     0xef4e84: ldr             x9, [x9, #0xce0]
    // 0xef4e88: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef4e88: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xef4e8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef4e8c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateShapeBorder(/* No info */) {
    // ** addr: 0xef4e90, size: 0x1b8
    // 0xef4e90: EnterFrame
    //     0xef4e90: stp             fp, lr, [SP, #-0x10]!
    //     0xef4e94: mov             fp, SP
    // 0xef4e98: AllocStack(0x28)
    //     0xef4e98: sub             SP, SP, #0x28
    // 0xef4e9c: r3 = Instance_Border
    //     0xef4e9c: add             x3, PP, #0x95, lsl #12  ; [pp+0x95cd8] Obj!Border@129eb61
    //     0xef4ea0: ldr             x3, [x3, #0xcd8]
    // 0xef4ea4: mov             x4, x2
    // 0xef4ea8: stur            x2, [fp, #-0x18]
    // 0xef4eac: LoadField: r5 = r1->field_13
    //     0xef4eac: ldur            w5, [x1, #0x13]
    // 0xef4eb0: DecompressPointer r5
    //     0xef4eb0: add             x5, x5, HEAP, lsl #32
    // 0xef4eb4: stur            x5, [fp, #-0x10]
    // 0xef4eb8: LoadField: r0 = r1->field_b
    //     0xef4eb8: ldur            w0, [x1, #0xb]
    // 0xef4ebc: DecompressPointer r0
    //     0xef4ebc: add             x0, x0, HEAP, lsl #32
    // 0xef4ec0: cmp             w0, NULL
    // 0xef4ec4: b.eq            #0xef5038
    // 0xef4ec8: LoadField: r0 = r1->field_37
    //     0xef4ec8: ldur            w0, [x1, #0x37]
    // 0xef4ecc: DecompressPointer r0
    //     0xef4ecc: add             x0, x0, HEAP, lsl #32
    // 0xef4ed0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef4ed4: cmp             w0, w16
    // 0xef4ed8: b.eq            #0xef503c
    // 0xef4edc: LoadField: r6 = r5->field_7
    //     0xef4edc: ldur            w6, [x5, #7]
    // 0xef4ee0: DecompressPointer r6
    //     0xef4ee0: add             x6, x6, HEAP, lsl #32
    // 0xef4ee4: mov             x0, x3
    // 0xef4ee8: mov             x2, x6
    // 0xef4eec: stur            x6, [fp, #-8]
    // 0xef4ef0: r1 = Null
    //     0xef4ef0: mov             x1, NULL
    // 0xef4ef4: cmp             w0, NULL
    // 0xef4ef8: b.eq            #0xef4f20
    // 0xef4efc: cmp             w2, NULL
    // 0xef4f00: b.eq            #0xef4f20
    // 0xef4f04: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xef4f04: ldur            w4, [x2, #0x17]
    // 0xef4f08: DecompressPointer r4
    //     0xef4f08: add             x4, x4, HEAP, lsl #32
    // 0xef4f0c: r8 = X0?
    //     0xef4f0c: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0xef4f10: LoadField: r9 = r4->field_7
    //     0xef4f10: ldur            x9, [x4, #7]
    // 0xef4f14: r3 = Null
    //     0xef4f14: add             x3, PP, #0x95, lsl #12  ; [pp+0x95da8] Null
    //     0xef4f18: ldr             x3, [x3, #0xda8]
    // 0xef4f1c: blr             x9
    // 0xef4f20: ldur            x1, [fp, #-0x10]
    // 0xef4f24: r0 = Instance_Border
    //     0xef4f24: add             x0, PP, #0x95, lsl #12  ; [pp+0x95cd8] Obj!Border@129eb61
    //     0xef4f28: ldr             x0, [x0, #0xcd8]
    // 0xef4f2c: StoreField: r1->field_b = r0
    //     0xef4f2c: stur            w0, [x1, #0xb]
    // 0xef4f30: ldur            x0, [fp, #-0x18]
    // 0xef4f34: LoadField: r2 = r0->field_47
    //     0xef4f34: ldur            w2, [x0, #0x47]
    // 0xef4f38: DecompressPointer r2
    //     0xef4f38: add             x2, x2, HEAP, lsl #32
    // 0xef4f3c: stur            x2, [fp, #-0x20]
    // 0xef4f40: r0 = BorderSide()
    //     0xef4f40: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xef4f44: mov             x1, x0
    // 0xef4f48: ldur            x0, [fp, #-0x20]
    // 0xef4f4c: stur            x1, [fp, #-0x18]
    // 0xef4f50: StoreField: r1->field_7 = r0
    //     0xef4f50: stur            w0, [x1, #7]
    // 0xef4f54: d0 = 1.000000
    //     0xef4f54: fmov            d0, #1.00000000
    // 0xef4f58: StoreField: r1->field_b = d0
    //     0xef4f58: stur            d0, [x1, #0xb]
    // 0xef4f5c: r2 = Instance_BorderStyle
    //     0xef4f5c: add             x2, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xef4f60: ldr             x2, [x2, #0xdc8]
    // 0xef4f64: StoreField: r1->field_13 = r2
    //     0xef4f64: stur            w2, [x1, #0x13]
    // 0xef4f68: d1 = -1.000000
    //     0xef4f68: fmov            d1, #-1.00000000
    // 0xef4f6c: ArrayStore: r1[0] = d1  ; List_8
    //     0xef4f6c: stur            d1, [x1, #0x17]
    // 0xef4f70: r0 = BorderSide()
    //     0xef4f70: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xef4f74: mov             x1, x0
    // 0xef4f78: ldur            x0, [fp, #-0x20]
    // 0xef4f7c: stur            x1, [fp, #-0x28]
    // 0xef4f80: StoreField: r1->field_7 = r0
    //     0xef4f80: stur            w0, [x1, #7]
    // 0xef4f84: d0 = 1.000000
    //     0xef4f84: fmov            d0, #1.00000000
    // 0xef4f88: StoreField: r1->field_b = d0
    //     0xef4f88: stur            d0, [x1, #0xb]
    // 0xef4f8c: r0 = Instance_BorderStyle
    //     0xef4f8c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xef4f90: ldr             x0, [x0, #0xdc8]
    // 0xef4f94: StoreField: r1->field_13 = r0
    //     0xef4f94: stur            w0, [x1, #0x13]
    // 0xef4f98: d0 = -1.000000
    //     0xef4f98: fmov            d0, #-1.00000000
    // 0xef4f9c: ArrayStore: r1[0] = d0  ; List_8
    //     0xef4f9c: stur            d0, [x1, #0x17]
    // 0xef4fa0: r0 = Border()
    //     0xef4fa0: bl              #0x8a73b0  ; AllocateBorderStub -> Border (size=0x18)
    // 0xef4fa4: mov             x3, x0
    // 0xef4fa8: ldur            x0, [fp, #-0x18]
    // 0xef4fac: stur            x3, [fp, #-0x20]
    // 0xef4fb0: StoreField: r3->field_7 = r0
    //     0xef4fb0: stur            w0, [x3, #7]
    // 0xef4fb4: r0 = Instance_BorderSide
    //     0xef4fb4: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0xef4fb8: ldr             x0, [x0, #0x310]
    // 0xef4fbc: StoreField: r3->field_b = r0
    //     0xef4fbc: stur            w0, [x3, #0xb]
    // 0xef4fc0: ldur            x1, [fp, #-0x28]
    // 0xef4fc4: StoreField: r3->field_f = r1
    //     0xef4fc4: stur            w1, [x3, #0xf]
    // 0xef4fc8: StoreField: r3->field_13 = r0
    //     0xef4fc8: stur            w0, [x3, #0x13]
    // 0xef4fcc: mov             x0, x3
    // 0xef4fd0: ldur            x2, [fp, #-8]
    // 0xef4fd4: r1 = Null
    //     0xef4fd4: mov             x1, NULL
    // 0xef4fd8: cmp             w0, NULL
    // 0xef4fdc: b.eq            #0xef5004
    // 0xef4fe0: cmp             w2, NULL
    // 0xef4fe4: b.eq            #0xef5004
    // 0xef4fe8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xef4fe8: ldur            w4, [x2, #0x17]
    // 0xef4fec: DecompressPointer r4
    //     0xef4fec: add             x4, x4, HEAP, lsl #32
    // 0xef4ff0: r8 = X0?
    //     0xef4ff0: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0xef4ff4: LoadField: r9 = r4->field_7
    //     0xef4ff4: ldur            x9, [x4, #7]
    // 0xef4ff8: r3 = Null
    //     0xef4ff8: add             x3, PP, #0x95, lsl #12  ; [pp+0x95db8] Null
    //     0xef4ffc: ldr             x3, [x3, #0xdb8]
    // 0xef5000: blr             x9
    // 0xef5004: ldur            x0, [fp, #-0x20]
    // 0xef5008: ldur            x1, [fp, #-0x10]
    // 0xef500c: StoreField: r1->field_f = r0
    //     0xef500c: stur            w0, [x1, #0xf]
    //     0xef5010: ldurb           w16, [x1, #-1]
    //     0xef5014: ldurb           w17, [x0, #-1]
    //     0xef5018: and             x16, x17, x16, lsr #2
    //     0xef501c: tst             x16, HEAP, lsr #32
    //     0xef5020: b.eq            #0xef5028
    //     0xef5024: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef5028: r0 = Null
    //     0xef5028: mov             x0, NULL
    // 0xef502c: LeaveFrame
    //     0xef502c: mov             SP, fp
    //     0xef5030: ldp             fp, lr, [SP], #0x10
    // 0xef5034: ret
    //     0xef5034: ret             
    // 0xef5038: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef5038: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef503c: r9 = _expansionTileTheme
    //     0xef503c: add             x9, PP, #0x95, lsl #12  ; [pp+0x95ce0] Field <_ExpansionTileState@747392950._expansionTileTheme@747392950>: late (offset: 0x38)
    //     0xef5040: ldr             x9, [x9, #0xce0]
    // 0xef5044: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef5044: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _updateAnimationDuration(/* No info */) {
    // ** addr: 0xef5048, size: 0x58
    // 0xef5048: EnterFrame
    //     0xef5048: stp             fp, lr, [SP, #-0x10]!
    //     0xef504c: mov             fp, SP
    // 0xef5050: r2 = Instance_Duration
    //     0xef5050: add             x2, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xef5054: ldr             x2, [x2, #0x318]
    // 0xef5058: LoadField: r3 = r1->field_b
    //     0xef5058: ldur            w3, [x1, #0xb]
    // 0xef505c: DecompressPointer r3
    //     0xef505c: add             x3, x3, HEAP, lsl #32
    // 0xef5060: cmp             w3, NULL
    // 0xef5064: b.eq            #0xef5090
    // 0xef5068: LoadField: r3 = r1->field_37
    //     0xef5068: ldur            w3, [x1, #0x37]
    // 0xef506c: DecompressPointer r3
    //     0xef506c: add             x3, x3, HEAP, lsl #32
    // 0xef5070: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xef5074: cmp             w3, w16
    // 0xef5078: b.eq            #0xef5094
    // 0xef507c: StoreField: r1->field_4b = r2
    //     0xef507c: stur            w2, [x1, #0x4b]
    // 0xef5080: r0 = Null
    //     0xef5080: mov             x0, NULL
    // 0xef5084: LeaveFrame
    //     0xef5084: mov             SP, fp
    //     0xef5088: ldp             fp, lr, [SP], #0x10
    // 0xef508c: ret
    //     0xef508c: ret             
    // 0xef5090: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef5090: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef5094: r9 = _expansionTileTheme
    //     0xef5094: add             x9, PP, #0x95, lsl #12  ; [pp+0x95ce0] Field <_ExpansionTileState@747392950._expansionTileTheme@747392950>: late (offset: 0x38)
    //     0xef5098: ldr             x9, [x9, #0xce0]
    // 0xef509c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xef509c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf6d7ec, size: 0x2fc
    // 0xf6d7ec: EnterFrame
    //     0xf6d7ec: stp             fp, lr, [SP, #-0x10]!
    //     0xf6d7f0: mov             fp, SP
    // 0xf6d7f4: AllocStack(0x28)
    //     0xf6d7f4: sub             SP, SP, #0x28
    // 0xf6d7f8: SetupParameters(_ExpansionTileState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf6d7f8: mov             x4, x1
    //     0xf6d7fc: mov             x3, x2
    //     0xf6d800: stur            x1, [fp, #-8]
    //     0xf6d804: stur            x2, [fp, #-0x10]
    // 0xf6d808: CheckStackOverflow
    //     0xf6d808: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6d80c: cmp             SP, x16
    //     0xf6d810: b.ls            #0xf6dabc
    // 0xf6d814: mov             x0, x3
    // 0xf6d818: r2 = Null
    //     0xf6d818: mov             x2, NULL
    // 0xf6d81c: r1 = Null
    //     0xf6d81c: mov             x1, NULL
    // 0xf6d820: r4 = 60
    //     0xf6d820: mov             x4, #0x3c
    // 0xf6d824: branchIfSmi(r0, 0xf6d830)
    //     0xf6d824: tbz             w0, #0, #0xf6d830
    // 0xf6d828: r4 = LoadClassIdInstr(r0)
    //     0xf6d828: ldur            x4, [x0, #-1]
    //     0xf6d82c: ubfx            x4, x4, #0xc, #0x14
    // 0xf6d830: r17 = 6476
    //     0xf6d830: mov             x17, #0x194c
    // 0xf6d834: cmp             x4, x17
    // 0xf6d838: b.eq            #0xf6d850
    // 0xf6d83c: r8 = ExpansionTile
    //     0xf6d83c: add             x8, PP, #0x95, lsl #12  ; [pp+0x95dd0] Type: ExpansionTile
    //     0xf6d840: ldr             x8, [x8, #0xdd0]
    // 0xf6d844: r3 = Null
    //     0xf6d844: add             x3, PP, #0x95, lsl #12  ; [pp+0x95dd8] Null
    //     0xf6d848: ldr             x3, [x3, #0xdd8]
    // 0xf6d84c: r0 = ExpansionTile()
    //     0xf6d84c: bl              #0xd65c10  ; IsType_ExpansionTile_Stub
    // 0xf6d850: ldur            x3, [fp, #-8]
    // 0xf6d854: LoadField: r2 = r3->field_7
    //     0xf6d854: ldur            w2, [x3, #7]
    // 0xf6d858: DecompressPointer r2
    //     0xf6d858: add             x2, x2, HEAP, lsl #32
    // 0xf6d85c: ldur            x0, [fp, #-0x10]
    // 0xf6d860: r1 = Null
    //     0xf6d860: mov             x1, NULL
    // 0xf6d864: cmp             w2, NULL
    // 0xf6d868: b.eq            #0xf6d88c
    // 0xf6d86c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6d86c: ldur            w4, [x2, #0x17]
    // 0xf6d870: DecompressPointer r4
    //     0xf6d870: add             x4, x4, HEAP, lsl #32
    // 0xf6d874: r8 = X0 bound StatefulWidget
    //     0xf6d874: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf6d878: ldr             x8, [x8, #0x498]
    // 0xf6d87c: LoadField: r9 = r4->field_7
    //     0xf6d87c: ldur            x9, [x4, #7]
    // 0xf6d880: r3 = Null
    //     0xf6d880: add             x3, PP, #0x95, lsl #12  ; [pp+0x95de8] Null
    //     0xf6d884: ldr             x3, [x3, #0xde8]
    // 0xf6d888: blr             x9
    // 0xf6d88c: ldur            x0, [fp, #-8]
    // 0xf6d890: LoadField: r1 = r0->field_f
    //     0xf6d890: ldur            w1, [x0, #0xf]
    // 0xf6d894: DecompressPointer r1
    //     0xf6d894: add             x1, x1, HEAP, lsl #32
    // 0xf6d898: cmp             w1, NULL
    // 0xf6d89c: b.eq            #0xf6dac4
    // 0xf6d8a0: r0 = of()
    //     0xf6d8a0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xf6d8a4: mov             x2, x0
    // 0xf6d8a8: ldur            x0, [fp, #-8]
    // 0xf6d8ac: stur            x2, [fp, #-0x18]
    // 0xf6d8b0: LoadField: r1 = r0->field_f
    //     0xf6d8b0: ldur            w1, [x0, #0xf]
    // 0xf6d8b4: DecompressPointer r1
    //     0xf6d8b4: add             x1, x1, HEAP, lsl #32
    // 0xf6d8b8: cmp             w1, NULL
    // 0xf6d8bc: b.eq            #0xf6dac8
    // 0xf6d8c0: r0 = of()
    //     0xf6d8c0: bl              #0xef50b8  ; [package:flutter/src/material/expansion_tile_theme.dart] ExpansionTileTheme::of
    // 0xf6d8c4: ldur            x1, [fp, #-8]
    // 0xf6d8c8: StoreField: r1->field_37 = r0
    //     0xf6d8c8: stur            w0, [x1, #0x37]
    //     0xf6d8cc: ldurb           w16, [x1, #-1]
    //     0xf6d8d0: ldurb           w17, [x0, #-1]
    //     0xf6d8d4: and             x16, x17, x16, lsr #2
    //     0xf6d8d8: tst             x16, HEAP, lsr #32
    //     0xf6d8dc: b.eq            #0xf6d8e4
    //     0xf6d8e0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf6d8e4: ldur            x0, [fp, #-0x18]
    // 0xf6d8e8: LoadField: r2 = r0->field_2f
    //     0xf6d8e8: ldur            w2, [x0, #0x2f]
    // 0xf6d8ec: DecompressPointer r2
    //     0xf6d8ec: add             x2, x2, HEAP, lsl #32
    // 0xf6d8f0: tbnz            w2, #4, #0xf6d92c
    // 0xf6d8f4: LoadField: r0 = r1->field_f
    //     0xf6d8f4: ldur            w0, [x1, #0xf]
    // 0xf6d8f8: DecompressPointer r0
    //     0xf6d8f8: add             x0, x0, HEAP, lsl #32
    // 0xf6d8fc: stur            x0, [fp, #-0x18]
    // 0xf6d900: cmp             w0, NULL
    // 0xf6d904: b.eq            #0xf6dacc
    // 0xf6d908: r0 = _ExpansionTileDefaultsM3()
    //     0xf6d908: bl              #0xef50ac  ; Allocate_ExpansionTileDefaultsM3Stub -> _ExpansionTileDefaultsM3 (size=0x48)
    // 0xf6d90c: mov             x1, x0
    // 0xf6d910: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xf6d914: StoreField: r1->field_3f = r0
    //     0xf6d914: stur            w0, [x1, #0x3f]
    // 0xf6d918: StoreField: r1->field_43 = r0
    //     0xf6d918: stur            w0, [x1, #0x43]
    // 0xf6d91c: ldur            x0, [fp, #-0x18]
    // 0xf6d920: StoreField: r1->field_3b = r0
    //     0xf6d920: stur            w0, [x1, #0x3b]
    // 0xf6d924: mov             x3, x1
    // 0xf6d928: b               #0xf6d964
    // 0xf6d92c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xf6d930: LoadField: r2 = r1->field_f
    //     0xf6d930: ldur            w2, [x1, #0xf]
    // 0xf6d934: DecompressPointer r2
    //     0xf6d934: add             x2, x2, HEAP, lsl #32
    // 0xf6d938: stur            x2, [fp, #-0x18]
    // 0xf6d93c: cmp             w2, NULL
    // 0xf6d940: b.eq            #0xf6dad0
    // 0xf6d944: r0 = _ExpansionTileDefaultsM2()
    //     0xf6d944: bl              #0xef50a0  ; Allocate_ExpansionTileDefaultsM2Stub -> _ExpansionTileDefaultsM2 (size=0x48)
    // 0xf6d948: mov             x1, x0
    // 0xf6d94c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xf6d950: StoreField: r1->field_3f = r0
    //     0xf6d950: stur            w0, [x1, #0x3f]
    // 0xf6d954: StoreField: r1->field_43 = r0
    //     0xf6d954: stur            w0, [x1, #0x43]
    // 0xf6d958: ldur            x0, [fp, #-0x18]
    // 0xf6d95c: StoreField: r1->field_3b = r0
    //     0xf6d95c: stur            w0, [x1, #0x3b]
    // 0xf6d960: mov             x3, x1
    // 0xf6d964: ldur            x1, [fp, #-8]
    // 0xf6d968: ldur            x2, [fp, #-0x10]
    // 0xf6d96c: stur            x3, [fp, #-0x18]
    // 0xf6d970: LoadField: r0 = r1->field_b
    //     0xf6d970: ldur            w0, [x1, #0xb]
    // 0xf6d974: DecompressPointer r0
    //     0xf6d974: add             x0, x0, HEAP, lsl #32
    // 0xf6d978: cmp             w0, NULL
    // 0xf6d97c: b.eq            #0xf6dad4
    // 0xf6d980: LoadField: r4 = r0->field_4b
    //     0xf6d980: ldur            w4, [x0, #0x4b]
    // 0xf6d984: DecompressPointer r4
    //     0xf6d984: add             x4, x4, HEAP, lsl #32
    // 0xf6d988: LoadField: r0 = r2->field_4b
    //     0xf6d988: ldur            w0, [x2, #0x4b]
    // 0xf6d98c: DecompressPointer r0
    //     0xf6d98c: add             x0, x0, HEAP, lsl #32
    // 0xf6d990: r5 = LoadClassIdInstr(r4)
    //     0xf6d990: ldur            x5, [x4, #-1]
    //     0xf6d994: ubfx            x5, x5, #0xc, #0x14
    // 0xf6d998: stp             x0, x4, [SP]
    // 0xf6d99c: mov             x0, x5
    // 0xf6d9a0: mov             lr, x0
    // 0xf6d9a4: ldr             lr, [x21, lr, lsl #3]
    // 0xf6d9a8: blr             lr
    // 0xf6d9ac: tbnz            w0, #4, #0xf6d9f8
    // 0xf6d9b0: ldur            x1, [fp, #-8]
    // 0xf6d9b4: ldur            x2, [fp, #-0x10]
    // 0xf6d9b8: LoadField: r0 = r1->field_b
    //     0xf6d9b8: ldur            w0, [x1, #0xb]
    // 0xf6d9bc: DecompressPointer r0
    //     0xf6d9bc: add             x0, x0, HEAP, lsl #32
    // 0xf6d9c0: cmp             w0, NULL
    // 0xf6d9c4: b.eq            #0xf6dad8
    // 0xf6d9c8: LoadField: r3 = r0->field_47
    //     0xf6d9c8: ldur            w3, [x0, #0x47]
    // 0xf6d9cc: DecompressPointer r3
    //     0xf6d9cc: add             x3, x3, HEAP, lsl #32
    // 0xf6d9d0: LoadField: r0 = r2->field_47
    //     0xf6d9d0: ldur            w0, [x2, #0x47]
    // 0xf6d9d4: DecompressPointer r0
    //     0xf6d9d4: add             x0, x0, HEAP, lsl #32
    // 0xf6d9d8: r4 = LoadClassIdInstr(r3)
    //     0xf6d9d8: ldur            x4, [x3, #-1]
    //     0xf6d9dc: ubfx            x4, x4, #0xc, #0x14
    // 0xf6d9e0: stp             x0, x3, [SP]
    // 0xf6d9e4: mov             x0, x4
    // 0xf6d9e8: mov             lr, x0
    // 0xf6d9ec: ldr             lr, [x21, lr, lsl #3]
    // 0xf6d9f0: blr             lr
    // 0xf6d9f4: tbz             w0, #4, #0xf6da04
    // 0xf6d9f8: ldur            x1, [fp, #-8]
    // 0xf6d9fc: ldur            x2, [fp, #-0x18]
    // 0xf6da00: r0 = _updateIconColor()
    //     0xf6da00: bl              #0xef47ec  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_updateIconColor
    // 0xf6da04: ldur            x1, [fp, #-8]
    // 0xf6da08: ldur            x2, [fp, #-0x10]
    // 0xf6da0c: LoadField: r0 = r1->field_b
    //     0xf6da0c: ldur            w0, [x1, #0xb]
    // 0xf6da10: DecompressPointer r0
    //     0xf6da10: add             x0, x0, HEAP, lsl #32
    // 0xf6da14: cmp             w0, NULL
    // 0xf6da18: b.eq            #0xf6dadc
    // 0xf6da1c: LoadField: r3 = r0->field_1f
    //     0xf6da1c: ldur            w3, [x0, #0x1f]
    // 0xf6da20: DecompressPointer r3
    //     0xf6da20: add             x3, x3, HEAP, lsl #32
    // 0xf6da24: LoadField: r0 = r2->field_1f
    //     0xf6da24: ldur            w0, [x2, #0x1f]
    // 0xf6da28: DecompressPointer r0
    //     0xf6da28: add             x0, x0, HEAP, lsl #32
    // 0xf6da2c: r4 = LoadClassIdInstr(r3)
    //     0xf6da2c: ldur            x4, [x3, #-1]
    //     0xf6da30: ubfx            x4, x4, #0xc, #0x14
    // 0xf6da34: stp             x0, x3, [SP]
    // 0xf6da38: mov             x0, x4
    // 0xf6da3c: mov             lr, x0
    // 0xf6da40: ldr             lr, [x21, lr, lsl #3]
    // 0xf6da44: blr             lr
    // 0xf6da48: tbnz            w0, #4, #0xf6da90
    // 0xf6da4c: ldur            x1, [fp, #-8]
    // 0xf6da50: ldur            x0, [fp, #-0x10]
    // 0xf6da54: LoadField: r2 = r1->field_b
    //     0xf6da54: ldur            w2, [x1, #0xb]
    // 0xf6da58: DecompressPointer r2
    //     0xf6da58: add             x2, x2, HEAP, lsl #32
    // 0xf6da5c: cmp             w2, NULL
    // 0xf6da60: b.eq            #0xf6dae0
    // 0xf6da64: LoadField: r3 = r2->field_23
    //     0xf6da64: ldur            w3, [x2, #0x23]
    // 0xf6da68: DecompressPointer r3
    //     0xf6da68: add             x3, x3, HEAP, lsl #32
    // 0xf6da6c: LoadField: r2 = r0->field_23
    //     0xf6da6c: ldur            w2, [x0, #0x23]
    // 0xf6da70: DecompressPointer r2
    //     0xf6da70: add             x2, x2, HEAP, lsl #32
    // 0xf6da74: r0 = LoadClassIdInstr(r3)
    //     0xf6da74: ldur            x0, [x3, #-1]
    //     0xf6da78: ubfx            x0, x0, #0xc, #0x14
    // 0xf6da7c: stp             x2, x3, [SP]
    // 0xf6da80: mov             lr, x0
    // 0xf6da84: ldr             lr, [x21, lr, lsl #3]
    // 0xf6da88: blr             lr
    // 0xf6da8c: tbz             w0, #4, #0xf6da98
    // 0xf6da90: ldur            x1, [fp, #-8]
    // 0xf6da94: r0 = _updateBackgroundColor()
    //     0xf6da94: bl              #0xef4658  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_updateBackgroundColor
    // 0xf6da98: ldur            x1, [fp, #-8]
    // 0xf6da9c: LoadField: r2 = r1->field_b
    //     0xf6da9c: ldur            w2, [x1, #0xb]
    // 0xf6daa0: DecompressPointer r2
    //     0xf6daa0: add             x2, x2, HEAP, lsl #32
    // 0xf6daa4: cmp             w2, NULL
    // 0xf6daa8: b.eq            #0xf6dae4
    // 0xf6daac: r0 = Null
    //     0xf6daac: mov             x0, NULL
    // 0xf6dab0: LeaveFrame
    //     0xf6dab0: mov             SP, fp
    //     0xf6dab4: ldp             fp, lr, [SP], #0x10
    // 0xf6dab8: ret
    //     0xf6dab8: ret             
    // 0xf6dabc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6dabc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6dac0: b               #0xf6d814
    // 0xf6dac4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6dac4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6dac8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6dac8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6dacc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6dacc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6dad0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6dad0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6dad4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6dad4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6dad8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6dad8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6dadc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6dadc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6dae0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6dae0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6dae4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6dae4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf90b98, size: 0x114
    // 0xf90b98: EnterFrame
    //     0xf90b98: stp             fp, lr, [SP, #-0x10]!
    //     0xf90b9c: mov             fp, SP
    // 0xf90ba0: AllocStack(0x10)
    //     0xf90ba0: sub             SP, SP, #0x10
    // 0xf90ba4: r2 = Instance_Cubic
    //     0xf90ba4: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e970] Obj!Cubic@129f541
    //     0xf90ba8: ldr             x2, [x2, #0x970]
    // 0xf90bac: r0 = Instance_Duration
    //     0xf90bac: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xf90bb0: ldr             x0, [x0, #0x318]
    // 0xf90bb4: stur            x1, [fp, #-8]
    // 0xf90bb8: CheckStackOverflow
    //     0xf90bb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf90bbc: cmp             SP, x16
    //     0xf90bc0: b.ls            #0xf90c9c
    // 0xf90bc4: StoreField: r1->field_43 = r2
    //     0xf90bc4: stur            w2, [x1, #0x43]
    // 0xf90bc8: StoreField: r1->field_4b = r0
    //     0xf90bc8: stur            w0, [x1, #0x4b]
    // 0xf90bcc: LoadField: r0 = r1->field_b
    //     0xf90bcc: ldur            w0, [x1, #0xb]
    // 0xf90bd0: DecompressPointer r0
    //     0xf90bd0: add             x0, x0, HEAP, lsl #32
    // 0xf90bd4: cmp             w0, NULL
    // 0xf90bd8: b.eq            #0xf90ca4
    // 0xf90bdc: r0 = ExpansibleController()
    //     0xf90bdc: bl              #0xf90cac  ; AllocateExpansibleControllerStub -> ExpansibleController (size=0x28)
    // 0xf90be0: mov             x1, x0
    // 0xf90be4: r0 = false
    //     0xf90be4: add             x0, NULL, #0x30  ; false
    // 0xf90be8: stur            x1, [fp, #-0x10]
    // 0xf90bec: StoreField: r1->field_23 = r0
    //     0xf90bec: stur            w0, [x1, #0x23]
    // 0xf90bf0: StoreField: r1->field_7 = rZR
    //     0xf90bf0: stur            xzr, [x1, #7]
    // 0xf90bf4: StoreField: r1->field_13 = rZR
    //     0xf90bf4: stur            xzr, [x1, #0x13]
    // 0xf90bf8: StoreField: r1->field_1b = rZR
    //     0xf90bf8: stur            xzr, [x1, #0x1b]
    // 0xf90bfc: r0 = LoadStaticField(0x45c)
    //     0xf90bfc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf90c00: ldr             x0, [x0, #0x8b8]
    // 0xf90c04: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf90c08: cmp             w0, w16
    // 0xf90c0c: b.ne            #0xf90c18
    // 0xf90c10: r2 = _emptyListeners
    //     0xf90c10: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xf90c14: r0 = InitLateFinalStaticField()
    //     0xf90c14: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf90c18: ldur            x1, [fp, #-0x10]
    // 0xf90c1c: StoreField: r1->field_f = r0
    //     0xf90c1c: stur            w0, [x1, #0xf]
    // 0xf90c20: mov             x0, x1
    // 0xf90c24: ldur            x2, [fp, #-8]
    // 0xf90c28: StoreField: r2->field_3b = r0
    //     0xf90c28: stur            w0, [x2, #0x3b]
    //     0xf90c2c: ldurb           w16, [x2, #-1]
    //     0xf90c30: ldurb           w17, [x0, #-1]
    //     0xf90c34: and             x16, x17, x16, lsr #2
    //     0xf90c38: tst             x16, HEAP, lsr #32
    //     0xf90c3c: b.eq            #0xf90c44
    //     0xf90c40: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf90c44: LoadField: r0 = r2->field_b
    //     0xf90c44: ldur            w0, [x2, #0xb]
    // 0xf90c48: DecompressPointer r0
    //     0xf90c48: add             x0, x0, HEAP, lsl #32
    // 0xf90c4c: cmp             w0, NULL
    // 0xf90c50: b.eq            #0xf90ca8
    // 0xf90c54: LoadField: r3 = r0->field_2f
    //     0xf90c54: ldur            w3, [x0, #0x2f]
    // 0xf90c58: DecompressPointer r3
    //     0xf90c58: add             x3, x3, HEAP, lsl #32
    // 0xf90c5c: tbnz            w3, #4, #0xf90c64
    // 0xf90c60: r0 = expand()
    //     0xf90c60: bl              #0xd66a78  ; [package:flutter/src/widgets/expansible.dart] ExpansibleController::expand
    // 0xf90c64: ldur            x2, [fp, #-8]
    // 0xf90c68: LoadField: r0 = r2->field_3b
    //     0xf90c68: ldur            w0, [x2, #0x3b]
    // 0xf90c6c: DecompressPointer r0
    //     0xf90c6c: add             x0, x0, HEAP, lsl #32
    // 0xf90c70: stur            x0, [fp, #-0x10]
    // 0xf90c74: r1 = Function '_onExpansionChanged@747392950':.
    //     0xf90c74: add             x1, PP, #0x95, lsl #12  ; [pp+0x95df8] AnonymousClosure: (0xf90cb8), in [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_onExpansionChanged (0xf90cf0)
    //     0xf90c78: ldr             x1, [x1, #0xdf8]
    // 0xf90c7c: r0 = AllocateClosure()
    //     0xf90c7c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf90c80: ldur            x1, [fp, #-0x10]
    // 0xf90c84: mov             x2, x0
    // 0xf90c88: r0 = addListener()
    //     0xf90c88: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xf90c8c: r0 = Null
    //     0xf90c8c: mov             x0, NULL
    // 0xf90c90: LeaveFrame
    //     0xf90c90: mov             SP, fp
    //     0xf90c94: ldp             fp, lr, [SP], #0x10
    // 0xf90c98: ret
    //     0xf90c98: ret             
    // 0xf90c9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf90c9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf90ca0: b               #0xf90bc4
    // 0xf90ca4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf90ca4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf90ca8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf90ca8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _onExpansionChanged(dynamic) {
    // ** addr: 0xf90cb8, size: 0x38
    // 0xf90cb8: EnterFrame
    //     0xf90cb8: stp             fp, lr, [SP, #-0x10]!
    //     0xf90cbc: mov             fp, SP
    // 0xf90cc0: ldr             x0, [fp, #0x10]
    // 0xf90cc4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf90cc4: ldur            w1, [x0, #0x17]
    // 0xf90cc8: DecompressPointer r1
    //     0xf90cc8: add             x1, x1, HEAP, lsl #32
    // 0xf90ccc: CheckStackOverflow
    //     0xf90ccc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf90cd0: cmp             SP, x16
    //     0xf90cd4: b.ls            #0xf90ce8
    // 0xf90cd8: r0 = _onExpansionChanged()
    //     0xf90cd8: bl              #0xf90cf0  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_onExpansionChanged
    // 0xf90cdc: LeaveFrame
    //     0xf90cdc: mov             SP, fp
    //     0xf90ce0: ldp             fp, lr, [SP], #0x10
    // 0xf90ce4: ret
    //     0xf90ce4: ret             
    // 0xf90ce8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf90ce8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf90cec: b               #0xf90cd8
  }
  _ _onExpansionChanged(/* No info */) {
    // ** addr: 0xf90cf0, size: 0x164
    // 0xf90cf0: EnterFrame
    //     0xf90cf0: stp             fp, lr, [SP, #-0x10]!
    //     0xf90cf4: mov             fp, SP
    // 0xf90cf8: AllocStack(0x18)
    //     0xf90cf8: sub             SP, SP, #0x18
    // 0xf90cfc: SetupParameters(_ExpansionTileState this /* r1 => r0, fp-0x8 */)
    //     0xf90cfc: mov             x0, x1
    //     0xf90d00: stur            x1, [fp, #-8]
    // 0xf90d04: CheckStackOverflow
    //     0xf90d04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf90d08: cmp             SP, x16
    //     0xf90d0c: b.ls            #0xf90e34
    // 0xf90d10: LoadField: r1 = r0->field_f
    //     0xf90d10: ldur            w1, [x0, #0xf]
    // 0xf90d14: DecompressPointer r1
    //     0xf90d14: add             x1, x1, HEAP, lsl #32
    // 0xf90d18: cmp             w1, NULL
    // 0xf90d1c: b.eq            #0xf90e3c
    // 0xf90d20: r0 = of()
    //     0xf90d20: bl              #0xe0f8c0  ; [package:flutter/src/widgets/localizations.dart] WidgetsLocalizations::of
    // 0xf90d24: r1 = LoadClassIdInstr(r0)
    //     0xf90d24: ldur            x1, [x0, #-1]
    //     0xf90d28: ubfx            x1, x1, #0xc, #0x14
    // 0xf90d2c: mov             x16, x0
    // 0xf90d30: mov             x0, x1
    // 0xf90d34: mov             x1, x16
    // 0xf90d38: r0 = GDT[cid_x0 + 0x13af6]()
    //     0xf90d38: mov             x17, #0x3af6
    //     0xf90d3c: movk            x17, #1, lsl #16
    //     0xf90d40: add             lr, x0, x17
    //     0xf90d44: ldr             lr, [x21, lr, lsl #3]
    //     0xf90d48: blr             lr
    // 0xf90d4c: ldur            x0, [fp, #-8]
    // 0xf90d50: LoadField: r1 = r0->field_f
    //     0xf90d50: ldur            w1, [x0, #0xf]
    // 0xf90d54: DecompressPointer r1
    //     0xf90d54: add             x1, x1, HEAP, lsl #32
    // 0xf90d58: cmp             w1, NULL
    // 0xf90d5c: b.eq            #0xf90e40
    // 0xf90d60: r0 = of()
    //     0xf90d60: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xf90d64: ldur            x2, [fp, #-8]
    // 0xf90d68: LoadField: r1 = r2->field_3b
    //     0xf90d68: ldur            w1, [x2, #0x3b]
    // 0xf90d6c: DecompressPointer r1
    //     0xf90d6c: add             x1, x1, HEAP, lsl #32
    // 0xf90d70: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf90d74: cmp             w1, w16
    // 0xf90d78: b.eq            #0xf90e44
    // 0xf90d7c: LoadField: r3 = r1->field_23
    //     0xf90d7c: ldur            w3, [x1, #0x23]
    // 0xf90d80: DecompressPointer r3
    //     0xf90d80: add             x3, x3, HEAP, lsl #32
    // 0xf90d84: tbnz            w3, #4, #0xf90db4
    // 0xf90d88: r1 = LoadClassIdInstr(r0)
    //     0xf90d88: ldur            x1, [x0, #-1]
    //     0xf90d8c: ubfx            x1, x1, #0xc, #0x14
    // 0xf90d90: mov             x16, x0
    // 0xf90d94: mov             x0, x1
    // 0xf90d98: mov             x1, x16
    // 0xf90d9c: r0 = GDT[cid_x0 + 0x17037]()
    //     0xf90d9c: mov             x17, #0x7037
    //     0xf90da0: movk            x17, #1, lsl #16
    //     0xf90da4: add             lr, x0, x17
    //     0xf90da8: ldr             lr, [x21, lr, lsl #3]
    //     0xf90dac: blr             lr
    // 0xf90db0: b               #0xf90ddc
    // 0xf90db4: r1 = LoadClassIdInstr(r0)
    //     0xf90db4: ldur            x1, [x0, #-1]
    //     0xf90db8: ubfx            x1, x1, #0xc, #0x14
    // 0xf90dbc: mov             x16, x0
    // 0xf90dc0: mov             x0, x1
    // 0xf90dc4: mov             x1, x16
    // 0xf90dc8: r0 = GDT[cid_x0 + 0x16e72]()
    //     0xf90dc8: mov             x17, #0x6e72
    //     0xf90dcc: movk            x17, #1, lsl #16
    //     0xf90dd0: add             lr, x0, x17
    //     0xf90dd4: ldr             lr, [x21, lr, lsl #3]
    //     0xf90dd8: blr             lr
    // 0xf90ddc: ldur            x0, [fp, #-8]
    // 0xf90de0: LoadField: r1 = r0->field_b
    //     0xf90de0: ldur            w1, [x0, #0xb]
    // 0xf90de4: DecompressPointer r1
    //     0xf90de4: add             x1, x1, HEAP, lsl #32
    // 0xf90de8: cmp             w1, NULL
    // 0xf90dec: b.eq            #0xf90e50
    // 0xf90df0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xf90df0: ldur            w2, [x1, #0x17]
    // 0xf90df4: DecompressPointer r2
    //     0xf90df4: add             x2, x2, HEAP, lsl #32
    // 0xf90df8: cmp             w2, NULL
    // 0xf90dfc: b.eq            #0xf90e24
    // 0xf90e00: LoadField: r1 = r0->field_3b
    //     0xf90e00: ldur            w1, [x0, #0x3b]
    // 0xf90e04: DecompressPointer r1
    //     0xf90e04: add             x1, x1, HEAP, lsl #32
    // 0xf90e08: LoadField: r0 = r1->field_23
    //     0xf90e08: ldur            w0, [x1, #0x23]
    // 0xf90e0c: DecompressPointer r0
    //     0xf90e0c: add             x0, x0, HEAP, lsl #32
    // 0xf90e10: stp             x0, x2, [SP]
    // 0xf90e14: mov             x0, x2
    // 0xf90e18: ClosureCall
    //     0xf90e18: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xf90e1c: ldur            x2, [x0, #0x1f]
    //     0xf90e20: blr             x2
    // 0xf90e24: r0 = Null
    //     0xf90e24: mov             x0, NULL
    // 0xf90e28: LeaveFrame
    //     0xf90e28: mov             SP, fp
    //     0xf90e2c: ldp             fp, lr, [SP], #0x10
    // 0xf90e30: ret
    //     0xf90e30: ret             
    // 0xf90e34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf90e34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf90e38: b               #0xf90d10
    // 0xf90e3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf90e3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf90e40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf90e40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf90e44: r9 = _tileController
    //     0xf90e44: add             x9, PP, #0x95, lsl #12  ; [pp+0x95cb0] Field <_ExpansionTileState@747392950._tileController@747392950>: late (offset: 0x3c)
    //     0xf90e48: ldr             x9, [x9, #0xcb0]
    // 0xf90e4c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf90e4c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf90e50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf90e50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _ExpansionTileState(/* No info */) {
    // ** addr: 0xfa18bc, size: 0x100
    // 0xfa18bc: EnterFrame
    //     0xfa18bc: stp             fp, lr, [SP, #-0x10]!
    //     0xfa18c0: mov             fp, SP
    // 0xfa18c4: AllocStack(0x8)
    //     0xfa18c4: sub             SP, SP, #8
    // 0xfa18c8: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa18cc: mov             x2, x1
    // 0xfa18d0: stur            x1, [fp, #-8]
    // 0xfa18d4: StoreField: r2->field_23 = r0
    //     0xfa18d4: stur            w0, [x2, #0x23]
    // 0xfa18d8: StoreField: r2->field_27 = r0
    //     0xfa18d8: stur            w0, [x2, #0x27]
    // 0xfa18dc: StoreField: r2->field_2b = r0
    //     0xfa18dc: stur            w0, [x2, #0x2b]
    // 0xfa18e0: StoreField: r2->field_2f = r0
    //     0xfa18e0: stur            w0, [x2, #0x2f]
    // 0xfa18e4: StoreField: r2->field_33 = r0
    //     0xfa18e4: stur            w0, [x2, #0x33]
    // 0xfa18e8: StoreField: r2->field_37 = r0
    //     0xfa18e8: stur            w0, [x2, #0x37]
    // 0xfa18ec: StoreField: r2->field_3b = r0
    //     0xfa18ec: stur            w0, [x2, #0x3b]
    // 0xfa18f0: StoreField: r2->field_43 = r0
    //     0xfa18f0: stur            w0, [x2, #0x43]
    // 0xfa18f4: StoreField: r2->field_47 = r0
    //     0xfa18f4: stur            w0, [x2, #0x47]
    // 0xfa18f8: StoreField: r2->field_4b = r0
    //     0xfa18f8: stur            w0, [x2, #0x4b]
    // 0xfa18fc: r1 = <ShapeBorder?>
    //     0xfa18fc: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c960] TypeArguments: <ShapeBorder?>
    //     0xfa1900: ldr             x1, [x1, #0x960]
    // 0xfa1904: r0 = ShapeBorderTween()
    //     0xfa1904: bl              #0xfa19bc  ; AllocateShapeBorderTweenStub -> ShapeBorderTween (size=0x14)
    // 0xfa1908: ldur            x2, [fp, #-8]
    // 0xfa190c: StoreField: r2->field_13 = r0
    //     0xfa190c: stur            w0, [x2, #0x13]
    //     0xfa1910: ldurb           w16, [x2, #-1]
    //     0xfa1914: ldurb           w17, [x0, #-1]
    //     0xfa1918: and             x16, x17, x16, lsr #2
    //     0xfa191c: tst             x16, HEAP, lsr #32
    //     0xfa1920: b.eq            #0xfa1928
    //     0xfa1924: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfa1928: r1 = <Color?>
    //     0xfa1928: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xfa192c: ldr             x1, [x1, #0xa40]
    // 0xfa1930: r0 = ColorTween()
    //     0xfa1930: bl              #0x915f2c  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0xfa1934: ldur            x2, [fp, #-8]
    // 0xfa1938: ArrayStore: r2[0] = r0  ; List_4
    //     0xfa1938: stur            w0, [x2, #0x17]
    //     0xfa193c: ldurb           w16, [x2, #-1]
    //     0xfa1940: ldurb           w17, [x0, #-1]
    //     0xfa1944: and             x16, x17, x16, lsr #2
    //     0xfa1948: tst             x16, HEAP, lsr #32
    //     0xfa194c: b.eq            #0xfa1954
    //     0xfa1950: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfa1954: r1 = <Color?>
    //     0xfa1954: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xfa1958: ldr             x1, [x1, #0xa40]
    // 0xfa195c: r0 = ColorTween()
    //     0xfa195c: bl              #0x915f2c  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0xfa1960: ldur            x2, [fp, #-8]
    // 0xfa1964: StoreField: r2->field_1b = r0
    //     0xfa1964: stur            w0, [x2, #0x1b]
    //     0xfa1968: ldurb           w16, [x2, #-1]
    //     0xfa196c: ldurb           w17, [x0, #-1]
    //     0xfa1970: and             x16, x17, x16, lsr #2
    //     0xfa1974: tst             x16, HEAP, lsr #32
    //     0xfa1978: b.eq            #0xfa1980
    //     0xfa197c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfa1980: r1 = <Color?>
    //     0xfa1980: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xfa1984: ldr             x1, [x1, #0xa40]
    // 0xfa1988: r0 = ColorTween()
    //     0xfa1988: bl              #0x915f2c  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0xfa198c: ldur            x1, [fp, #-8]
    // 0xfa1990: StoreField: r1->field_1f = r0
    //     0xfa1990: stur            w0, [x1, #0x1f]
    //     0xfa1994: ldurb           w16, [x1, #-1]
    //     0xfa1998: ldurb           w17, [x0, #-1]
    //     0xfa199c: and             x16, x17, x16, lsr #2
    //     0xfa19a0: tst             x16, HEAP, lsr #32
    //     0xfa19a4: b.eq            #0xfa19ac
    //     0xfa19a8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa19ac: r0 = Null
    //     0xfa19ac: mov             x0, NULL
    // 0xfa19b0: LeaveFrame
    //     0xfa19b0: mov             SP, fp
    //     0xfa19b4: ldp             fp, lr, [SP], #0x10
    // 0xfa19b8: ret
    //     0xfa19b8: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e5bcc, size: 0xc4
    // 0x10e5bcc: EnterFrame
    //     0x10e5bcc: stp             fp, lr, [SP, #-0x10]!
    //     0x10e5bd0: mov             fp, SP
    // 0x10e5bd4: AllocStack(0x10)
    //     0x10e5bd4: sub             SP, SP, #0x10
    // 0x10e5bd8: SetupParameters(_ExpansionTileState this /* r1 => r0, fp-0x10 */)
    //     0x10e5bd8: mov             x0, x1
    //     0x10e5bdc: stur            x1, [fp, #-0x10]
    // 0x10e5be0: CheckStackOverflow
    //     0x10e5be0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e5be4: cmp             SP, x16
    //     0x10e5be8: b.ls            #0x10e5c78
    // 0x10e5bec: LoadField: r3 = r0->field_3b
    //     0x10e5bec: ldur            w3, [x0, #0x3b]
    // 0x10e5bf0: DecompressPointer r3
    //     0x10e5bf0: add             x3, x3, HEAP, lsl #32
    // 0x10e5bf4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10e5bf8: cmp             w3, w16
    // 0x10e5bfc: b.eq            #0x10e5c80
    // 0x10e5c00: mov             x2, x0
    // 0x10e5c04: stur            x3, [fp, #-8]
    // 0x10e5c08: r1 = Function '_onExpansionChanged@747392950':.
    //     0x10e5c08: add             x1, PP, #0x95, lsl #12  ; [pp+0x95df8] AnonymousClosure: (0xf90cb8), in [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_onExpansionChanged (0xf90cf0)
    //     0x10e5c0c: ldr             x1, [x1, #0xdf8]
    // 0x10e5c10: r0 = AllocateClosure()
    //     0x10e5c10: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e5c14: ldur            x1, [fp, #-8]
    // 0x10e5c18: mov             x2, x0
    // 0x10e5c1c: r0 = removeListener()
    //     0x10e5c1c: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x10e5c20: ldur            x0, [fp, #-0x10]
    // 0x10e5c24: LoadField: r1 = r0->field_b
    //     0x10e5c24: ldur            w1, [x0, #0xb]
    // 0x10e5c28: DecompressPointer r1
    //     0x10e5c28: add             x1, x1, HEAP, lsl #32
    // 0x10e5c2c: cmp             w1, NULL
    // 0x10e5c30: b.eq            #0x10e5c8c
    // 0x10e5c34: LoadField: r1 = r0->field_3b
    //     0x10e5c34: ldur            w1, [x0, #0x3b]
    // 0x10e5c38: DecompressPointer r1
    //     0x10e5c38: add             x1, x1, HEAP, lsl #32
    // 0x10e5c3c: r0 = dispose()
    //     0x10e5c3c: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0x10e5c40: ldur            x0, [fp, #-0x10]
    // 0x10e5c44: LoadField: r1 = r0->field_3f
    //     0x10e5c44: ldur            w1, [x0, #0x3f]
    // 0x10e5c48: DecompressPointer r1
    //     0x10e5c48: add             x1, x1, HEAP, lsl #32
    // 0x10e5c4c: cmp             w1, NULL
    // 0x10e5c50: b.ne            #0x10e5c5c
    // 0x10e5c54: mov             x1, x0
    // 0x10e5c58: b               #0x10e5c64
    // 0x10e5c5c: r0 = cancel()
    //     0x10e5c5c: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0x10e5c60: ldur            x1, [fp, #-0x10]
    // 0x10e5c64: StoreField: r1->field_3f = rNULL
    //     0x10e5c64: stur            NULL, [x1, #0x3f]
    // 0x10e5c68: r0 = Null
    //     0x10e5c68: mov             x0, NULL
    // 0x10e5c6c: LeaveFrame
    //     0x10e5c6c: mov             SP, fp
    //     0x10e5c70: ldp             fp, lr, [SP], #0x10
    // 0x10e5c74: ret
    //     0x10e5c74: ret             
    // 0x10e5c78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e5c78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e5c7c: b               #0x10e5bec
    // 0x10e5c80: r9 = _tileController
    //     0x10e5c80: add             x9, PP, #0x95, lsl #12  ; [pp+0x95cb0] Field <_ExpansionTileState@747392950._tileController@747392950>: late (offset: 0x3c)
    //     0x10e5c84: ldr             x9, [x9, #0xcb0]
    // 0x10e5c88: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10e5c88: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x10e5c8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e5c8c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6476, size: 0x90, field offset: 0xc
//   const constructor, 
class ExpansionTile extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa1874, size: 0x48
    // 0xfa1874: EnterFrame
    //     0xfa1874: stp             fp, lr, [SP, #-0x10]!
    //     0xfa1878: mov             fp, SP
    // 0xfa187c: AllocStack(0x8)
    //     0xfa187c: sub             SP, SP, #8
    // 0xfa1880: CheckStackOverflow
    //     0xfa1880: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa1884: cmp             SP, x16
    //     0xfa1888: b.ls            #0xfa18b4
    // 0xfa188c: r1 = <ExpansionTile>
    //     0xfa188c: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c958] TypeArguments: <ExpansionTile>
    //     0xfa1890: ldr             x1, [x1, #0x958]
    // 0xfa1894: r0 = _ExpansionTileState()
    //     0xfa1894: bl              #0xfa19c8  ; Allocate_ExpansionTileStateStub -> _ExpansionTileState (size=0x50)
    // 0xfa1898: mov             x1, x0
    // 0xfa189c: stur            x0, [fp, #-8]
    // 0xfa18a0: r0 = _ExpansionTileState()
    //     0xfa18a0: bl              #0xfa18bc  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_ExpansionTileState
    // 0xfa18a4: ldur            x0, [fp, #-8]
    // 0xfa18a8: LeaveFrame
    //     0xfa18a8: mov             SP, fp
    //     0xfa18ac: ldp             fp, lr, [SP], #0x10
    // 0xfa18b0: ret
    //     0xfa18b0: ret             
    // 0xfa18b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa18b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa18b8: b               #0xfa188c
  }
}
