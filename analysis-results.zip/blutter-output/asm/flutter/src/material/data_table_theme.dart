// lib: , url: package:flutter/src/material/data_table_theme.dart

// class id: 1048873, size: 0x8
class :: {
}

// class id: 5170, size: 0x44, field offset: 0x8
//   const constructor, 
class DataTableThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x113096c, size: 0xb0
    // 0x113096c: EnterFrame
    //     0x113096c: stp             fp, lr, [SP, #-0x10]!
    //     0x1130970: mov             fp, SP
    // 0x1130974: AllocStack(0x68)
    //     0x1130974: sub             SP, SP, #0x68
    // 0x1130978: CheckStackOverflow
    //     0x1130978: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x113097c: cmp             SP, x16
    //     0x1130980: b.ls            #0x1130a14
    // 0x1130984: ldr             x0, [fp, #0x10]
    // 0x1130988: LoadField: r1 = r0->field_f
    //     0x1130988: ldur            w1, [x0, #0xf]
    // 0x113098c: DecompressPointer r1
    //     0x113098c: add             x1, x1, HEAP, lsl #32
    // 0x1130990: LoadField: r2 = r0->field_13
    //     0x1130990: ldur            w2, [x0, #0x13]
    // 0x1130994: DecompressPointer r2
    //     0x1130994: add             x2, x2, HEAP, lsl #32
    // 0x1130998: LoadField: r3 = r0->field_1f
    //     0x1130998: ldur            w3, [x0, #0x1f]
    // 0x113099c: DecompressPointer r3
    //     0x113099c: add             x3, x3, HEAP, lsl #32
    // 0x11309a0: LoadField: r4 = r0->field_27
    //     0x11309a0: ldur            w4, [x0, #0x27]
    // 0x11309a4: DecompressPointer r4
    //     0x11309a4: add             x4, x4, HEAP, lsl #32
    // 0x11309a8: LoadField: r5 = r0->field_2b
    //     0x11309a8: ldur            w5, [x0, #0x2b]
    // 0x11309ac: DecompressPointer r5
    //     0x11309ac: add             x5, x5, HEAP, lsl #32
    // 0x11309b0: LoadField: r6 = r0->field_2f
    //     0x11309b0: ldur            w6, [x0, #0x2f]
    // 0x11309b4: DecompressPointer r6
    //     0x11309b4: add             x6, x6, HEAP, lsl #32
    // 0x11309b8: LoadField: r7 = r0->field_33
    //     0x11309b8: ldur            w7, [x0, #0x33]
    // 0x11309bc: DecompressPointer r7
    //     0x11309bc: add             x7, x7, HEAP, lsl #32
    // 0x11309c0: stp             x2, x1, [SP, #0x58]
    // 0x11309c4: stp             NULL, NULL, [SP, #0x48]
    // 0x11309c8: stp             NULL, x3, [SP, #0x38]
    // 0x11309cc: stp             x5, x4, [SP, #0x28]
    // 0x11309d0: stp             x7, x6, [SP, #0x18]
    // 0x11309d4: stp             NULL, NULL, [SP, #8]
    // 0x11309d8: str             NULL, [SP]
    // 0x11309dc: r1 = Null
    //     0x11309dc: mov             x1, NULL
    // 0x11309e0: r2 = Null
    //     0x11309e0: mov             x2, NULL
    // 0x11309e4: r4 = const [0, 0xf, 0xd, 0xf, null]
    //     0x11309e4: add             x4, PP, #0xd, lsl #12  ; [pp+0xdf18] List(5) [0, 0xf, 0xd, 0xf, Null]
    //     0x11309e8: ldr             x4, [x4, #0xf18]
    // 0x11309ec: r0 = hash()
    //     0x11309ec: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x11309f0: mov             x2, x0
    // 0x11309f4: r0 = BoxInt64Instr(r2)
    //     0x11309f4: sbfiz           x0, x2, #1, #0x1f
    //     0x11309f8: cmp             x2, x0, asr #1
    //     0x11309fc: b.eq            #0x1130a08
    //     0x1130a00: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1130a04: stur            x2, [x0, #7]
    // 0x1130a08: LeaveFrame
    //     0x1130a08: mov             SP, fp
    //     0x1130a0c: ldp             fp, lr, [SP], #0x10
    // 0x1130a10: ret
    //     0x1130a10: ret             
    // 0x1130a14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1130a14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1130a18: b               #0x1130984
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1167f14, size: 0x22c
    // 0x1167f14: EnterFrame
    //     0x1167f14: stp             fp, lr, [SP, #-0x10]!
    //     0x1167f18: mov             fp, SP
    // 0x1167f1c: AllocStack(0x50)
    //     0x1167f1c: sub             SP, SP, #0x50
    // 0x1167f20: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x50 */)
    //     0x1167f20: mov             x3, x1
    //     0x1167f24: mov             x0, x2
    //     0x1167f28: mov             v1.16b, v0.16b
    //     0x1167f2c: stur            x1, [fp, #-8]
    //     0x1167f30: stur            x2, [fp, #-0x10]
    //     0x1167f34: stur            d0, [fp, #-0x50]
    // 0x1167f38: CheckStackOverflow
    //     0x1167f38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1167f3c: cmp             SP, x16
    //     0x1167f40: b.ls            #0x1168114
    // 0x1167f44: cmp             w3, w0
    // 0x1167f48: b.ne            #0x1167f5c
    // 0x1167f4c: mov             x0, x3
    // 0x1167f50: LeaveFrame
    //     0x1167f50: mov             SP, fp
    //     0x1167f54: ldp             fp, lr, [SP], #0x10
    // 0x1167f58: ret
    //     0x1167f58: ret             
    // 0x1167f5c: mov             v0.16b, v1.16b
    // 0x1167f60: r1 = Null
    //     0x1167f60: mov             x1, NULL
    // 0x1167f64: r2 = Null
    //     0x1167f64: mov             x2, NULL
    // 0x1167f68: r0 = lerp()
    //     0x1167f68: bl              #0x115f65c  ; [package:flutter/src/painting/decoration.dart] Decoration::lerp
    // 0x1167f6c: ldur            x0, [fp, #-8]
    // 0x1167f70: LoadField: r1 = r0->field_f
    //     0x1167f70: ldur            w1, [x0, #0xf]
    // 0x1167f74: DecompressPointer r1
    //     0x1167f74: add             x1, x1, HEAP, lsl #32
    // 0x1167f78: ldur            x4, [fp, #-0x10]
    // 0x1167f7c: LoadField: r2 = r4->field_f
    //     0x1167f7c: ldur            w2, [x4, #0xf]
    // 0x1167f80: DecompressPointer r2
    //     0x1167f80: add             x2, x2, HEAP, lsl #32
    // 0x1167f84: ldur            d0, [fp, #-0x50]
    // 0x1167f88: r5 = inline_Allocate_Double()
    //     0x1167f88: ldp             x5, x3, [THR, #0x60]  ; THR::top
    //     0x1167f8c: add             x5, x5, #0x10
    //     0x1167f90: cmp             x3, x5
    //     0x1167f94: b.ls            #0x116811c
    //     0x1167f98: str             x5, [THR, #0x60]  ; THR::top
    //     0x1167f9c: sub             x5, x5, #0xf
    //     0x1167fa0: mov             x3, #0xe19c
    //     0x1167fa4: movk            x3, #3, lsl #16
    //     0x1167fa8: stur            x3, [x5, #-1]
    // 0x1167fac: dmb             ishst
    // 0x1167fb0: StoreField: r5->field_7 = d0
    //     0x1167fb0: stur            d0, [x5, #7]
    // 0x1167fb4: mov             x3, x5
    // 0x1167fb8: stur            x5, [fp, #-0x18]
    // 0x1167fbc: r0 = lerpDouble()
    //     0x1167fbc: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1167fc0: mov             x4, x0
    // 0x1167fc4: ldur            x0, [fp, #-8]
    // 0x1167fc8: stur            x4, [fp, #-0x20]
    // 0x1167fcc: LoadField: r1 = r0->field_13
    //     0x1167fcc: ldur            w1, [x0, #0x13]
    // 0x1167fd0: DecompressPointer r1
    //     0x1167fd0: add             x1, x1, HEAP, lsl #32
    // 0x1167fd4: ldur            x5, [fp, #-0x10]
    // 0x1167fd8: LoadField: r2 = r5->field_13
    //     0x1167fd8: ldur            w2, [x5, #0x13]
    // 0x1167fdc: DecompressPointer r2
    //     0x1167fdc: add             x2, x2, HEAP, lsl #32
    // 0x1167fe0: ldur            x3, [fp, #-0x18]
    // 0x1167fe4: r0 = lerpDouble()
    //     0x1167fe4: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1167fe8: ldur            x3, [fp, #-0x18]
    // 0x1167fec: r1 = Null
    //     0x1167fec: mov             x1, NULL
    // 0x1167ff0: r2 = Null
    //     0x1167ff0: mov             x2, NULL
    // 0x1167ff4: stur            x0, [fp, #-0x28]
    // 0x1167ff8: r0 = lerp()
    //     0x1167ff8: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1167ffc: ldur            x0, [fp, #-8]
    // 0x1168000: LoadField: r1 = r0->field_1f
    //     0x1168000: ldur            w1, [x0, #0x1f]
    // 0x1168004: DecompressPointer r1
    //     0x1168004: add             x1, x1, HEAP, lsl #32
    // 0x1168008: ldur            x4, [fp, #-0x10]
    // 0x116800c: LoadField: r2 = r4->field_1f
    //     0x116800c: ldur            w2, [x4, #0x1f]
    // 0x1168010: DecompressPointer r2
    //     0x1168010: add             x2, x2, HEAP, lsl #32
    // 0x1168014: ldur            x3, [fp, #-0x18]
    // 0x1168018: r0 = lerpDouble()
    //     0x1168018: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x116801c: ldur            x3, [fp, #-0x18]
    // 0x1168020: r1 = Null
    //     0x1168020: mov             x1, NULL
    // 0x1168024: r2 = Null
    //     0x1168024: mov             x2, NULL
    // 0x1168028: stur            x0, [fp, #-0x30]
    // 0x116802c: r0 = lerp()
    //     0x116802c: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1168030: ldur            x0, [fp, #-8]
    // 0x1168034: LoadField: r1 = r0->field_27
    //     0x1168034: ldur            w1, [x0, #0x27]
    // 0x1168038: DecompressPointer r1
    //     0x1168038: add             x1, x1, HEAP, lsl #32
    // 0x116803c: ldur            x4, [fp, #-0x10]
    // 0x1168040: LoadField: r2 = r4->field_27
    //     0x1168040: ldur            w2, [x4, #0x27]
    // 0x1168044: DecompressPointer r2
    //     0x1168044: add             x2, x2, HEAP, lsl #32
    // 0x1168048: ldur            x3, [fp, #-0x18]
    // 0x116804c: r0 = lerpDouble()
    //     0x116804c: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1168050: mov             x4, x0
    // 0x1168054: ldur            x0, [fp, #-8]
    // 0x1168058: stur            x4, [fp, #-0x38]
    // 0x116805c: LoadField: r1 = r0->field_2b
    //     0x116805c: ldur            w1, [x0, #0x2b]
    // 0x1168060: DecompressPointer r1
    //     0x1168060: add             x1, x1, HEAP, lsl #32
    // 0x1168064: ldur            x5, [fp, #-0x10]
    // 0x1168068: LoadField: r2 = r5->field_2b
    //     0x1168068: ldur            w2, [x5, #0x2b]
    // 0x116806c: DecompressPointer r2
    //     0x116806c: add             x2, x2, HEAP, lsl #32
    // 0x1168070: ldur            x3, [fp, #-0x18]
    // 0x1168074: r0 = lerpDouble()
    //     0x1168074: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1168078: mov             x4, x0
    // 0x116807c: ldur            x0, [fp, #-8]
    // 0x1168080: stur            x4, [fp, #-0x40]
    // 0x1168084: LoadField: r1 = r0->field_2f
    //     0x1168084: ldur            w1, [x0, #0x2f]
    // 0x1168088: DecompressPointer r1
    //     0x1168088: add             x1, x1, HEAP, lsl #32
    // 0x116808c: ldur            x5, [fp, #-0x10]
    // 0x1168090: LoadField: r2 = r5->field_2f
    //     0x1168090: ldur            w2, [x5, #0x2f]
    // 0x1168094: DecompressPointer r2
    //     0x1168094: add             x2, x2, HEAP, lsl #32
    // 0x1168098: ldur            x3, [fp, #-0x18]
    // 0x116809c: r0 = lerpDouble()
    //     0x116809c: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x11680a0: mov             x4, x0
    // 0x11680a4: ldur            x0, [fp, #-8]
    // 0x11680a8: stur            x4, [fp, #-0x48]
    // 0x11680ac: LoadField: r1 = r0->field_33
    //     0x11680ac: ldur            w1, [x0, #0x33]
    // 0x11680b0: DecompressPointer r1
    //     0x11680b0: add             x1, x1, HEAP, lsl #32
    // 0x11680b4: ldur            x0, [fp, #-0x10]
    // 0x11680b8: LoadField: r2 = r0->field_33
    //     0x11680b8: ldur            w2, [x0, #0x33]
    // 0x11680bc: DecompressPointer r2
    //     0x11680bc: add             x2, x2, HEAP, lsl #32
    // 0x11680c0: ldur            x3, [fp, #-0x18]
    // 0x11680c4: r0 = lerpDouble()
    //     0x11680c4: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x11680c8: stur            x0, [fp, #-8]
    // 0x11680cc: r0 = DataTableThemeData()
    //     0x11680cc: bl              #0x1168140  ; AllocateDataTableThemeDataStub -> DataTableThemeData (size=0x44)
    // 0x11680d0: ldur            x1, [fp, #-0x30]
    // 0x11680d4: StoreField: r0->field_1f = r1
    //     0x11680d4: stur            w1, [x0, #0x1f]
    // 0x11680d8: ldur            x1, [fp, #-0x38]
    // 0x11680dc: StoreField: r0->field_27 = r1
    //     0x11680dc: stur            w1, [x0, #0x27]
    // 0x11680e0: ldur            x1, [fp, #-0x40]
    // 0x11680e4: StoreField: r0->field_2b = r1
    //     0x11680e4: stur            w1, [x0, #0x2b]
    // 0x11680e8: ldur            x1, [fp, #-0x48]
    // 0x11680ec: StoreField: r0->field_2f = r1
    //     0x11680ec: stur            w1, [x0, #0x2f]
    // 0x11680f0: ldur            x1, [fp, #-8]
    // 0x11680f4: StoreField: r0->field_33 = r1
    //     0x11680f4: stur            w1, [x0, #0x33]
    // 0x11680f8: ldur            x1, [fp, #-0x20]
    // 0x11680fc: StoreField: r0->field_f = r1
    //     0x11680fc: stur            w1, [x0, #0xf]
    // 0x1168100: ldur            x1, [fp, #-0x28]
    // 0x1168104: StoreField: r0->field_13 = r1
    //     0x1168104: stur            w1, [x0, #0x13]
    // 0x1168108: LeaveFrame
    //     0x1168108: mov             SP, fp
    //     0x116810c: ldp             fp, lr, [SP], #0x10
    // 0x1168110: ret
    //     0x1168110: ret             
    // 0x1168114: r0 = StackOverflowSharedWithFPURegs()
    //     0x1168114: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1168118: b               #0x1167f44
    // 0x116811c: SaveReg d0
    //     0x116811c: str             q0, [SP, #-0x10]!
    // 0x1168120: stp             x2, x4, [SP, #-0x10]!
    // 0x1168124: stp             x0, x1, [SP, #-0x10]!
    // 0x1168128: r0 = AllocateDouble()
    //     0x1168128: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116812c: mov             x5, x0
    // 0x1168130: ldp             x0, x1, [SP], #0x10
    // 0x1168134: ldp             x2, x4, [SP], #0x10
    // 0x1168138: RestoreReg d0
    //     0x1168138: ldr             q0, [SP], #0x10
    // 0x116813c: b               #0x1167fb0
  }
  _ ==(/* No info */) {
    // ** addr: 0x126791c, size: 0x254
    // 0x126791c: EnterFrame
    //     0x126791c: stp             fp, lr, [SP, #-0x10]!
    //     0x1267920: mov             fp, SP
    // 0x1267924: AllocStack(0x10)
    //     0x1267924: sub             SP, SP, #0x10
    // 0x1267928: CheckStackOverflow
    //     0x1267928: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x126792c: cmp             SP, x16
    //     0x1267930: b.ls            #0x1267b68
    // 0x1267934: ldr             x0, [fp, #0x10]
    // 0x1267938: cmp             w0, NULL
    // 0x126793c: b.ne            #0x1267950
    // 0x1267940: r0 = false
    //     0x1267940: add             x0, NULL, #0x30  ; false
    // 0x1267944: LeaveFrame
    //     0x1267944: mov             SP, fp
    //     0x1267948: ldp             fp, lr, [SP], #0x10
    // 0x126794c: ret
    //     0x126794c: ret             
    // 0x1267950: ldr             x1, [fp, #0x18]
    // 0x1267954: cmp             w1, w0
    // 0x1267958: b.ne            #0x126796c
    // 0x126795c: r0 = true
    //     0x126795c: add             x0, NULL, #0x20  ; true
    // 0x1267960: LeaveFrame
    //     0x1267960: mov             SP, fp
    //     0x1267964: ldp             fp, lr, [SP], #0x10
    // 0x1267968: ret
    //     0x1267968: ret             
    // 0x126796c: str             x0, [SP]
    // 0x1267970: r0 = runtimeType()
    //     0x1267970: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1267974: r1 = LoadClassIdInstr(r0)
    //     0x1267974: ldur            x1, [x0, #-1]
    //     0x1267978: ubfx            x1, x1, #0xc, #0x14
    // 0x126797c: r16 = DataTableThemeData
    //     0x126797c: add             x16, PP, #0x26, lsl #12  ; [pp+0x264a0] Type: DataTableThemeData
    //     0x1267980: ldr             x16, [x16, #0x4a0]
    // 0x1267984: stp             x16, x0, [SP]
    // 0x1267988: mov             x0, x1
    // 0x126798c: mov             lr, x0
    // 0x1267990: ldr             lr, [x21, lr, lsl #3]
    // 0x1267994: blr             lr
    // 0x1267998: tbz             w0, #4, #0x12679ac
    // 0x126799c: r0 = false
    //     0x126799c: add             x0, NULL, #0x30  ; false
    // 0x12679a0: LeaveFrame
    //     0x12679a0: mov             SP, fp
    //     0x12679a4: ldp             fp, lr, [SP], #0x10
    // 0x12679a8: ret
    //     0x12679a8: ret             
    // 0x12679ac: ldr             x1, [fp, #0x10]
    // 0x12679b0: r0 = 60
    //     0x12679b0: mov             x0, #0x3c
    // 0x12679b4: branchIfSmi(r1, 0x12679c0)
    //     0x12679b4: tbz             w1, #0, #0x12679c0
    // 0x12679b8: r0 = LoadClassIdInstr(r1)
    //     0x12679b8: ldur            x0, [x1, #-1]
    //     0x12679bc: ubfx            x0, x0, #0xc, #0x14
    // 0x12679c0: r17 = 5170
    //     0x12679c0: mov             x17, #0x1432
    // 0x12679c4: cmp             x0, x17
    // 0x12679c8: b.ne            #0x1267b58
    // 0x12679cc: ldr             x2, [fp, #0x18]
    // 0x12679d0: LoadField: r0 = r1->field_f
    //     0x12679d0: ldur            w0, [x1, #0xf]
    // 0x12679d4: DecompressPointer r0
    //     0x12679d4: add             x0, x0, HEAP, lsl #32
    // 0x12679d8: LoadField: r3 = r2->field_f
    //     0x12679d8: ldur            w3, [x2, #0xf]
    // 0x12679dc: DecompressPointer r3
    //     0x12679dc: add             x3, x3, HEAP, lsl #32
    // 0x12679e0: r4 = LoadClassIdInstr(r0)
    //     0x12679e0: ldur            x4, [x0, #-1]
    //     0x12679e4: ubfx            x4, x4, #0xc, #0x14
    // 0x12679e8: stp             x3, x0, [SP]
    // 0x12679ec: mov             x0, x4
    // 0x12679f0: mov             lr, x0
    // 0x12679f4: ldr             lr, [x21, lr, lsl #3]
    // 0x12679f8: blr             lr
    // 0x12679fc: tbnz            w0, #4, #0x1267b58
    // 0x1267a00: ldr             x2, [fp, #0x18]
    // 0x1267a04: ldr             x1, [fp, #0x10]
    // 0x1267a08: LoadField: r0 = r1->field_13
    //     0x1267a08: ldur            w0, [x1, #0x13]
    // 0x1267a0c: DecompressPointer r0
    //     0x1267a0c: add             x0, x0, HEAP, lsl #32
    // 0x1267a10: LoadField: r3 = r2->field_13
    //     0x1267a10: ldur            w3, [x2, #0x13]
    // 0x1267a14: DecompressPointer r3
    //     0x1267a14: add             x3, x3, HEAP, lsl #32
    // 0x1267a18: r4 = LoadClassIdInstr(r0)
    //     0x1267a18: ldur            x4, [x0, #-1]
    //     0x1267a1c: ubfx            x4, x4, #0xc, #0x14
    // 0x1267a20: stp             x3, x0, [SP]
    // 0x1267a24: mov             x0, x4
    // 0x1267a28: mov             lr, x0
    // 0x1267a2c: ldr             lr, [x21, lr, lsl #3]
    // 0x1267a30: blr             lr
    // 0x1267a34: tbnz            w0, #4, #0x1267b58
    // 0x1267a38: ldr             x2, [fp, #0x18]
    // 0x1267a3c: ldr             x1, [fp, #0x10]
    // 0x1267a40: LoadField: r0 = r1->field_1f
    //     0x1267a40: ldur            w0, [x1, #0x1f]
    // 0x1267a44: DecompressPointer r0
    //     0x1267a44: add             x0, x0, HEAP, lsl #32
    // 0x1267a48: LoadField: r3 = r2->field_1f
    //     0x1267a48: ldur            w3, [x2, #0x1f]
    // 0x1267a4c: DecompressPointer r3
    //     0x1267a4c: add             x3, x3, HEAP, lsl #32
    // 0x1267a50: r4 = LoadClassIdInstr(r0)
    //     0x1267a50: ldur            x4, [x0, #-1]
    //     0x1267a54: ubfx            x4, x4, #0xc, #0x14
    // 0x1267a58: stp             x3, x0, [SP]
    // 0x1267a5c: mov             x0, x4
    // 0x1267a60: mov             lr, x0
    // 0x1267a64: ldr             lr, [x21, lr, lsl #3]
    // 0x1267a68: blr             lr
    // 0x1267a6c: tbnz            w0, #4, #0x1267b58
    // 0x1267a70: ldr             x2, [fp, #0x18]
    // 0x1267a74: ldr             x1, [fp, #0x10]
    // 0x1267a78: LoadField: r0 = r1->field_27
    //     0x1267a78: ldur            w0, [x1, #0x27]
    // 0x1267a7c: DecompressPointer r0
    //     0x1267a7c: add             x0, x0, HEAP, lsl #32
    // 0x1267a80: LoadField: r3 = r2->field_27
    //     0x1267a80: ldur            w3, [x2, #0x27]
    // 0x1267a84: DecompressPointer r3
    //     0x1267a84: add             x3, x3, HEAP, lsl #32
    // 0x1267a88: r4 = LoadClassIdInstr(r0)
    //     0x1267a88: ldur            x4, [x0, #-1]
    //     0x1267a8c: ubfx            x4, x4, #0xc, #0x14
    // 0x1267a90: stp             x3, x0, [SP]
    // 0x1267a94: mov             x0, x4
    // 0x1267a98: mov             lr, x0
    // 0x1267a9c: ldr             lr, [x21, lr, lsl #3]
    // 0x1267aa0: blr             lr
    // 0x1267aa4: tbnz            w0, #4, #0x1267b58
    // 0x1267aa8: ldr             x2, [fp, #0x18]
    // 0x1267aac: ldr             x1, [fp, #0x10]
    // 0x1267ab0: LoadField: r0 = r1->field_2b
    //     0x1267ab0: ldur            w0, [x1, #0x2b]
    // 0x1267ab4: DecompressPointer r0
    //     0x1267ab4: add             x0, x0, HEAP, lsl #32
    // 0x1267ab8: LoadField: r3 = r2->field_2b
    //     0x1267ab8: ldur            w3, [x2, #0x2b]
    // 0x1267abc: DecompressPointer r3
    //     0x1267abc: add             x3, x3, HEAP, lsl #32
    // 0x1267ac0: r4 = LoadClassIdInstr(r0)
    //     0x1267ac0: ldur            x4, [x0, #-1]
    //     0x1267ac4: ubfx            x4, x4, #0xc, #0x14
    // 0x1267ac8: stp             x3, x0, [SP]
    // 0x1267acc: mov             x0, x4
    // 0x1267ad0: mov             lr, x0
    // 0x1267ad4: ldr             lr, [x21, lr, lsl #3]
    // 0x1267ad8: blr             lr
    // 0x1267adc: tbnz            w0, #4, #0x1267b58
    // 0x1267ae0: ldr             x2, [fp, #0x18]
    // 0x1267ae4: ldr             x1, [fp, #0x10]
    // 0x1267ae8: LoadField: r0 = r1->field_2f
    //     0x1267ae8: ldur            w0, [x1, #0x2f]
    // 0x1267aec: DecompressPointer r0
    //     0x1267aec: add             x0, x0, HEAP, lsl #32
    // 0x1267af0: LoadField: r3 = r2->field_2f
    //     0x1267af0: ldur            w3, [x2, #0x2f]
    // 0x1267af4: DecompressPointer r3
    //     0x1267af4: add             x3, x3, HEAP, lsl #32
    // 0x1267af8: r4 = LoadClassIdInstr(r0)
    //     0x1267af8: ldur            x4, [x0, #-1]
    //     0x1267afc: ubfx            x4, x4, #0xc, #0x14
    // 0x1267b00: stp             x3, x0, [SP]
    // 0x1267b04: mov             x0, x4
    // 0x1267b08: mov             lr, x0
    // 0x1267b0c: ldr             lr, [x21, lr, lsl #3]
    // 0x1267b10: blr             lr
    // 0x1267b14: tbnz            w0, #4, #0x1267b58
    // 0x1267b18: ldr             x1, [fp, #0x18]
    // 0x1267b1c: ldr             x0, [fp, #0x10]
    // 0x1267b20: LoadField: r2 = r0->field_33
    //     0x1267b20: ldur            w2, [x0, #0x33]
    // 0x1267b24: DecompressPointer r2
    //     0x1267b24: add             x2, x2, HEAP, lsl #32
    // 0x1267b28: LoadField: r0 = r1->field_33
    //     0x1267b28: ldur            w0, [x1, #0x33]
    // 0x1267b2c: DecompressPointer r0
    //     0x1267b2c: add             x0, x0, HEAP, lsl #32
    // 0x1267b30: r1 = LoadClassIdInstr(r2)
    //     0x1267b30: ldur            x1, [x2, #-1]
    //     0x1267b34: ubfx            x1, x1, #0xc, #0x14
    // 0x1267b38: stp             x0, x2, [SP]
    // 0x1267b3c: mov             x0, x1
    // 0x1267b40: mov             lr, x0
    // 0x1267b44: ldr             lr, [x21, lr, lsl #3]
    // 0x1267b48: blr             lr
    // 0x1267b4c: tbnz            w0, #4, #0x1267b58
    // 0x1267b50: r0 = true
    //     0x1267b50: add             x0, NULL, #0x20  ; true
    // 0x1267b54: b               #0x1267b5c
    // 0x1267b58: r0 = false
    //     0x1267b58: add             x0, NULL, #0x30  ; false
    // 0x1267b5c: LeaveFrame
    //     0x1267b5c: mov             SP, fp
    //     0x1267b60: ldp             fp, lr, [SP], #0x10
    // 0x1267b64: ret
    //     0x1267b64: ret             
    // 0x1267b68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1267b68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1267b6c: b               #0x1267934
  }
}

// class id: 6816, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class DataTableTheme extends InheritedWidget {

  static _ of(/* No info */) {
    // ** addr: 0xfb561c, size: 0x58
    // 0xfb561c: EnterFrame
    //     0xfb561c: stp             fp, lr, [SP, #-0x10]!
    //     0xfb5620: mov             fp, SP
    // 0xfb5624: AllocStack(0x18)
    //     0xfb5624: sub             SP, SP, #0x18
    // 0xfb5628: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xfb5628: stur            x1, [fp, #-8]
    // 0xfb562c: CheckStackOverflow
    //     0xfb562c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb5630: cmp             SP, x16
    //     0xfb5634: b.ls            #0xfb566c
    // 0xfb5638: r16 = <DataTableTheme>
    //     0xfb5638: add             x16, PP, #0x90, lsl #12  ; [pp+0x90008] TypeArguments: <DataTableTheme>
    //     0xfb563c: ldr             x16, [x16, #8]
    // 0xfb5640: stp             x1, x16, [SP]
    // 0xfb5644: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xfb5644: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xfb5648: r0 = dependOnInheritedWidgetOfExactType()
    //     0xfb5648: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xfb564c: ldur            x1, [fp, #-8]
    // 0xfb5650: r0 = of()
    //     0xfb5650: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb5654: LoadField: r1 = r0->field_bf
    //     0xfb5654: ldur            w1, [x0, #0xbf]
    // 0xfb5658: DecompressPointer r1
    //     0xfb5658: add             x1, x1, HEAP, lsl #32
    // 0xfb565c: mov             x0, x1
    // 0xfb5660: LeaveFrame
    //     0xfb5660: mov             SP, fp
    //     0xfb5664: ldp             fp, lr, [SP], #0x10
    // 0xfb5668: ret
    //     0xfb5668: ret             
    // 0xfb566c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb566c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb5670: b               #0xfb5638
  }
}
