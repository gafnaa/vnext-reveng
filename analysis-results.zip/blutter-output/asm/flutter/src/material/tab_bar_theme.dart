// lib: , url: package:flutter/src/material/tab_bar_theme.dart

// class id: 1048955, size: 0x8
class :: {
}

// class id: 5058, size: 0x4c, field offset: 0x8
//   const constructor, 
class TabBarThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x1137fb0, size: 0x814
    // 0x1137fb0: EnterFrame
    //     0x1137fb0: stp             fp, lr, [SP, #-0x10]!
    //     0x1137fb4: mov             fp, SP
    // 0x1137fb8: AllocStack(0xd0)
    //     0x1137fb8: sub             SP, SP, #0xd0
    // 0x1137fbc: CheckStackOverflow
    //     0x1137fbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1137fc0: cmp             SP, x16
    //     0x1137fc4: b.ls            #0x11387b8
    // 0x1137fc8: ldr             x0, [fp, #0x10]
    // 0x1137fcc: LoadField: r2 = r0->field_7
    //     0x1137fcc: ldur            w2, [x0, #7]
    // 0x1137fd0: DecompressPointer r2
    //     0x1137fd0: add             x2, x2, HEAP, lsl #32
    // 0x1137fd4: stur            x2, [fp, #-0x10]
    // 0x1137fd8: r3 = LoadClassIdInstr(r0)
    //     0x1137fd8: ldur            x3, [x0, #-1]
    //     0x1137fdc: ubfx            x3, x3, #0xc, #0x14
    // 0x1137fe0: stur            x3, [fp, #-8]
    // 0x1137fe4: r17 = 5058
    //     0x1137fe4: mov             x17, #0x13c2
    // 0x1137fe8: cmp             x3, x17
    // 0x1137fec: b.ne            #0x1138004
    // 0x1137ff0: LoadField: r1 = r0->field_b
    //     0x1137ff0: ldur            w1, [x0, #0xb]
    // 0x1137ff4: DecompressPointer r1
    //     0x1137ff4: add             x1, x1, HEAP, lsl #32
    // 0x1137ff8: mov             x2, x3
    // 0x1137ffc: mov             x3, x1
    // 0x1138000: b               #0x1138104
    // 0x1138004: r17 = 5059
    //     0x1138004: mov             x17, #0x13c3
    // 0x1138008: cmp             x3, x17
    // 0x113800c: b.eq            #0x1138674
    // 0x1138010: r17 = 5060
    //     0x1138010: mov             x17, #0x13c4
    // 0x1138014: cmp             x3, x17
    // 0x1138018: b.ne            #0x1138058
    // 0x113801c: mov             x1, x0
    // 0x1138020: LoadField: r0 = r1->field_4f
    //     0x1138020: ldur            w0, [x1, #0x4f]
    // 0x1138024: DecompressPointer r0
    //     0x1138024: add             x0, x0, HEAP, lsl #32
    // 0x1138028: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x113802c: cmp             w0, w16
    // 0x1138030: b.ne            #0x1138040
    // 0x1138034: r2 = _colors
    //     0x1138034: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x1138038: ldr             x2, [x2, #0xb0]
    // 0x113803c: r0 = InitLateFinalInstanceField()
    //     0x113803c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1138040: LoadField: r1 = r0->field_b
    //     0x1138040: ldur            w1, [x0, #0xb]
    // 0x1138044: DecompressPointer r1
    //     0x1138044: add             x1, x1, HEAP, lsl #32
    // 0x1138048: mov             x3, x1
    // 0x113804c: ldr             x0, [fp, #0x10]
    // 0x1138050: ldur            x2, [fp, #-8]
    // 0x1138054: b               #0x1138104
    // 0x1138058: ldr             x1, [fp, #0x10]
    // 0x113805c: LoadField: r0 = r1->field_4f
    //     0x113805c: ldur            w0, [x1, #0x4f]
    // 0x1138060: DecompressPointer r0
    //     0x1138060: add             x0, x0, HEAP, lsl #32
    // 0x1138064: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1138068: cmp             w0, w16
    // 0x113806c: b.ne            #0x113807c
    // 0x1138070: r2 = _colors
    //     0x1138070: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b8] Field <_TabsDefaultsM2@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x1138074: ldr             x2, [x2, #0xb8]
    // 0x1138078: r0 = InitLateFinalInstanceField()
    //     0x1138078: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113807c: LoadField: r2 = r0->field_2b
    //     0x113807c: ldur            w2, [x0, #0x2b]
    // 0x1138080: DecompressPointer r2
    //     0x1138080: add             x2, x2, HEAP, lsl #32
    // 0x1138084: ldr             x1, [fp, #0x10]
    // 0x1138088: stur            x2, [fp, #-0x18]
    // 0x113808c: LoadField: r0 = r1->field_57
    //     0x113808c: ldur            w0, [x1, #0x57]
    // 0x1138090: DecompressPointer r0
    //     0x1138090: add             x0, x0, HEAP, lsl #32
    // 0x1138094: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1138098: cmp             w0, w16
    // 0x113809c: b.ne            #0x11380ac
    // 0x11380a0: r2 = primaryColor
    //     0x11380a0: add             x2, PP, #0x26, lsl #12  ; [pp+0x260c0] Field <_TabsDefaultsM2@780014024.primaryColor>: late final (offset: 0x58)
    //     0x11380a4: ldr             x2, [x2, #0xc0]
    // 0x11380a8: r0 = InitLateFinalInstanceField()
    //     0x11380a8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11380ac: mov             x1, x0
    // 0x11380b0: ldur            x0, [fp, #-0x18]
    // 0x11380b4: r2 = LoadClassIdInstr(r0)
    //     0x11380b4: ldur            x2, [x0, #-1]
    //     0x11380b8: ubfx            x2, x2, #0xc, #0x14
    // 0x11380bc: stp             x1, x0, [SP]
    // 0x11380c0: mov             x0, x2
    // 0x11380c4: mov             lr, x0
    // 0x11380c8: ldr             lr, [x21, lr, lsl #3]
    // 0x11380cc: blr             lr
    // 0x11380d0: tbnz            w0, #4, #0x11380e4
    // 0x11380d4: ldr             x0, [fp, #0x10]
    // 0x11380d8: r1 = Instance_Color
    //     0x11380d8: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x11380dc: ldr             x1, [x1, #0xc38]
    // 0x11380e0: b               #0x11380fc
    // 0x11380e4: ldr             x0, [fp, #0x10]
    // 0x11380e8: LoadField: r1 = r0->field_4f
    //     0x11380e8: ldur            w1, [x0, #0x4f]
    // 0x11380ec: DecompressPointer r1
    //     0x11380ec: add             x1, x1, HEAP, lsl #32
    // 0x11380f0: LoadField: r2 = r1->field_2b
    //     0x11380f0: ldur            w2, [x1, #0x2b]
    // 0x11380f4: DecompressPointer r2
    //     0x11380f4: add             x2, x2, HEAP, lsl #32
    // 0x11380f8: mov             x1, x2
    // 0x11380fc: mov             x3, x1
    // 0x1138100: ldur            x2, [fp, #-8]
    // 0x1138104: stur            x3, [fp, #-0x20]
    // 0x1138108: LoadField: r4 = r0->field_f
    //     0x1138108: ldur            w4, [x0, #0xf]
    // 0x113810c: DecompressPointer r4
    //     0x113810c: add             x4, x4, HEAP, lsl #32
    // 0x1138110: stur            x4, [fp, #-0x18]
    // 0x1138114: r17 = 5058
    //     0x1138114: mov             x17, #0x13c2
    // 0x1138118: cmp             x2, x17
    // 0x113811c: b.eq            #0x1138190
    // 0x1138120: r17 = 5059
    //     0x1138120: mov             x17, #0x13c3
    // 0x1138124: cmp             x2, x17
    // 0x1138128: b.eq            #0x11386a8
    // 0x113812c: r17 = 5060
    //     0x113812c: mov             x17, #0x13c4
    // 0x1138130: cmp             x2, x17
    // 0x1138134: b.ne            #0x113818c
    // 0x1138138: mov             x1, x0
    // 0x113813c: LoadField: r0 = r1->field_4f
    //     0x113813c: ldur            w0, [x1, #0x4f]
    // 0x1138140: DecompressPointer r0
    //     0x1138140: add             x0, x0, HEAP, lsl #32
    // 0x1138144: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1138148: cmp             w0, w16
    // 0x113814c: b.ne            #0x113815c
    // 0x1138150: r2 = _colors
    //     0x1138150: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x1138154: ldr             x2, [x2, #0xb0]
    // 0x1138158: r0 = InitLateFinalInstanceField()
    //     0x1138158: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113815c: LoadField: r1 = r0->field_ab
    //     0x113815c: ldur            w1, [x0, #0xab]
    // 0x1138160: DecompressPointer r1
    //     0x1138160: add             x1, x1, HEAP, lsl #32
    // 0x1138164: cmp             w1, NULL
    // 0x1138168: b.ne            #0x113817c
    // 0x113816c: LoadField: r1 = r0->field_cb
    //     0x113816c: ldur            w1, [x0, #0xcb]
    // 0x1138170: DecompressPointer r1
    //     0x1138170: add             x1, x1, HEAP, lsl #32
    // 0x1138174: mov             x0, x1
    // 0x1138178: b               #0x1138180
    // 0x113817c: mov             x0, x1
    // 0x1138180: mov             x3, x0
    // 0x1138184: ldr             x0, [fp, #0x10]
    // 0x1138188: b               #0x113819c
    // 0x113818c: ldr             x0, [fp, #0x10]
    // 0x1138190: LoadField: r1 = r0->field_13
    //     0x1138190: ldur            w1, [x0, #0x13]
    // 0x1138194: DecompressPointer r1
    //     0x1138194: add             x1, x1, HEAP, lsl #32
    // 0x1138198: mov             x3, x1
    // 0x113819c: ldur            x2, [fp, #-8]
    // 0x11381a0: stur            x3, [fp, #-0x30]
    // 0x11381a4: r17 = 5058
    //     0x11381a4: mov             x17, #0x13c2
    // 0x11381a8: cmp             x2, x17
    // 0x11381ac: b.eq            #0x11381d8
    // 0x11381b0: r17 = 5059
    //     0x11381b0: mov             x17, #0x13c3
    // 0x11381b4: cmp             x2, x17
    // 0x11381b8: b.ne            #0x11381c4
    // 0x11381bc: r4 = 1.000000
    //     0x11381bc: ldr             x4, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x11381c0: b               #0x11381e4
    // 0x11381c4: r17 = 5060
    //     0x11381c4: mov             x17, #0x13c4
    // 0x11381c8: cmp             x2, x17
    // 0x11381cc: b.ne            #0x11381d8
    // 0x11381d0: r4 = 1.000000
    //     0x11381d0: ldr             x4, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x11381d4: b               #0x11381e4
    // 0x11381d8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11381d8: ldur            w1, [x0, #0x17]
    // 0x11381dc: DecompressPointer r1
    //     0x11381dc: add             x1, x1, HEAP, lsl #32
    // 0x11381e0: mov             x4, x1
    // 0x11381e4: stur            x4, [fp, #-0x28]
    // 0x11381e8: r17 = 5058
    //     0x11381e8: mov             x17, #0x13c2
    // 0x11381ec: cmp             x2, x17
    // 0x11381f0: b.ne            #0x1138208
    // 0x11381f4: LoadField: r1 = r0->field_1b
    //     0x11381f4: ldur            w1, [x0, #0x1b]
    // 0x11381f8: DecompressPointer r1
    //     0x11381f8: add             x1, x1, HEAP, lsl #32
    // 0x11381fc: mov             x0, x2
    // 0x1138200: mov             x2, x1
    // 0x1138204: b               #0x113828c
    // 0x1138208: r17 = 5059
    //     0x1138208: mov             x17, #0x13c3
    // 0x113820c: cmp             x2, x17
    // 0x1138210: b.eq            #0x11386dc
    // 0x1138214: r17 = 5060
    //     0x1138214: mov             x17, #0x13c4
    // 0x1138218: cmp             x2, x17
    // 0x113821c: b.ne            #0x1138258
    // 0x1138220: mov             x1, x0
    // 0x1138224: LoadField: r0 = r1->field_4f
    //     0x1138224: ldur            w0, [x1, #0x4f]
    // 0x1138228: DecompressPointer r0
    //     0x1138228: add             x0, x0, HEAP, lsl #32
    // 0x113822c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1138230: cmp             w0, w16
    // 0x1138234: b.ne            #0x1138244
    // 0x1138238: r2 = _colors
    //     0x1138238: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x113823c: ldr             x2, [x2, #0xb0]
    // 0x1138240: r0 = InitLateFinalInstanceField()
    //     0x1138240: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1138244: LoadField: r1 = r0->field_b
    //     0x1138244: ldur            w1, [x0, #0xb]
    // 0x1138248: DecompressPointer r1
    //     0x1138248: add             x1, x1, HEAP, lsl #32
    // 0x113824c: mov             x2, x1
    // 0x1138250: ldur            x0, [fp, #-8]
    // 0x1138254: b               #0x113828c
    // 0x1138258: LoadField: r1 = r0->field_4b
    //     0x1138258: ldur            w1, [x0, #0x4b]
    // 0x113825c: DecompressPointer r1
    //     0x113825c: add             x1, x1, HEAP, lsl #32
    // 0x1138260: r0 = of()
    //     0x1138260: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1138264: LoadField: r1 = r0->field_83
    //     0x1138264: ldur            w1, [x0, #0x83]
    // 0x1138268: DecompressPointer r1
    //     0x1138268: add             x1, x1, HEAP, lsl #32
    // 0x113826c: LoadField: r0 = r1->field_2b
    //     0x113826c: ldur            w0, [x1, #0x2b]
    // 0x1138270: DecompressPointer r0
    //     0x1138270: add             x0, x0, HEAP, lsl #32
    // 0x1138274: LoadField: r1 = r0->field_b
    //     0x1138274: ldur            w1, [x0, #0xb]
    // 0x1138278: DecompressPointer r1
    //     0x1138278: add             x1, x1, HEAP, lsl #32
    // 0x113827c: cmp             w1, NULL
    // 0x1138280: b.eq            #0x11387c0
    // 0x1138284: mov             x2, x1
    // 0x1138288: ldur            x0, [fp, #-8]
    // 0x113828c: stur            x2, [fp, #-0x38]
    // 0x1138290: r17 = 5058
    //     0x1138290: mov             x17, #0x13c2
    // 0x1138294: cmp             x0, x17
    // 0x1138298: b.ne            #0x11382b0
    // 0x113829c: ldr             x3, [fp, #0x10]
    // 0x11382a0: LoadField: r1 = r3->field_23
    //     0x11382a0: ldur            w1, [x3, #0x23]
    // 0x11382a4: DecompressPointer r1
    //     0x11382a4: add             x1, x1, HEAP, lsl #32
    // 0x11382a8: mov             x2, x1
    // 0x11382ac: b               #0x113832c
    // 0x11382b0: ldr             x3, [fp, #0x10]
    // 0x11382b4: r17 = 5059
    //     0x11382b4: mov             x17, #0x13c3
    // 0x11382b8: cmp             x0, x17
    // 0x11382bc: b.eq            #0x1138710
    // 0x11382c0: r17 = 5060
    //     0x11382c0: mov             x17, #0x13c4
    // 0x11382c4: cmp             x0, x17
    // 0x11382c8: b.ne            #0x1138304
    // 0x11382cc: mov             x1, x3
    // 0x11382d0: LoadField: r0 = r1->field_53
    //     0x11382d0: ldur            w0, [x1, #0x53]
    // 0x11382d4: DecompressPointer r0
    //     0x11382d4: add             x0, x0, HEAP, lsl #32
    // 0x11382d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11382dc: cmp             w0, w16
    // 0x11382e0: b.ne            #0x11382f0
    // 0x11382e4: r2 = _textTheme
    //     0x11382e4: add             x2, PP, #0x26, lsl #12  ; [pp+0x260c8] Field <_TabsPrimaryDefaultsM3@780014024._textTheme@780014024>: late final (offset: 0x54)
    //     0x11382e8: ldr             x2, [x2, #0xc8]
    // 0x11382ec: r0 = InitLateFinalInstanceField()
    //     0x11382ec: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11382f0: LoadField: r1 = r0->field_27
    //     0x11382f0: ldur            w1, [x0, #0x27]
    // 0x11382f4: DecompressPointer r1
    //     0x11382f4: add             x1, x1, HEAP, lsl #32
    // 0x11382f8: mov             x2, x1
    // 0x11382fc: ldur            x0, [fp, #-8]
    // 0x1138300: b               #0x113832c
    // 0x1138304: mov             x0, x3
    // 0x1138308: LoadField: r1 = r0->field_4b
    //     0x1138308: ldur            w1, [x0, #0x4b]
    // 0x113830c: DecompressPointer r1
    //     0x113830c: add             x1, x1, HEAP, lsl #32
    // 0x1138310: r0 = of()
    //     0x1138310: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1138314: LoadField: r1 = r0->field_83
    //     0x1138314: ldur            w1, [x0, #0x83]
    // 0x1138318: DecompressPointer r1
    //     0x1138318: add             x1, x1, HEAP, lsl #32
    // 0x113831c: LoadField: r0 = r1->field_2b
    //     0x113831c: ldur            w0, [x1, #0x2b]
    // 0x1138320: DecompressPointer r0
    //     0x1138320: add             x0, x0, HEAP, lsl #32
    // 0x1138324: mov             x2, x0
    // 0x1138328: ldur            x0, [fp, #-8]
    // 0x113832c: stur            x2, [fp, #-0x40]
    // 0x1138330: r17 = 5058
    //     0x1138330: mov             x17, #0x13c2
    // 0x1138334: cmp             x0, x17
    // 0x1138338: b.eq            #0x11383a8
    // 0x113833c: r17 = 5059
    //     0x113833c: mov             x17, #0x13c3
    // 0x1138340: cmp             x0, x17
    // 0x1138344: b.eq            #0x1138744
    // 0x1138348: r17 = 5060
    //     0x1138348: mov             x17, #0x13c4
    // 0x113834c: cmp             x0, x17
    // 0x1138350: b.ne            #0x11383a8
    // 0x1138354: ldr             x1, [fp, #0x10]
    // 0x1138358: LoadField: r0 = r1->field_4f
    //     0x1138358: ldur            w0, [x1, #0x4f]
    // 0x113835c: DecompressPointer r0
    //     0x113835c: add             x0, x0, HEAP, lsl #32
    // 0x1138360: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1138364: cmp             w0, w16
    // 0x1138368: b.ne            #0x1138378
    // 0x113836c: r2 = _colors
    //     0x113836c: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x1138370: ldr             x2, [x2, #0xb0]
    // 0x1138374: r0 = InitLateFinalInstanceField()
    //     0x1138374: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1138378: LoadField: r1 = r0->field_a3
    //     0x1138378: ldur            w1, [x0, #0xa3]
    // 0x113837c: DecompressPointer r1
    //     0x113837c: add             x1, x1, HEAP, lsl #32
    // 0x1138380: cmp             w1, NULL
    // 0x1138384: b.ne            #0x1138398
    // 0x1138388: LoadField: r1 = r0->field_7f
    //     0x1138388: ldur            w1, [x0, #0x7f]
    // 0x113838c: DecompressPointer r1
    //     0x113838c: add             x1, x1, HEAP, lsl #32
    // 0x1138390: mov             x0, x1
    // 0x1138394: b               #0x113839c
    // 0x1138398: mov             x0, x1
    // 0x113839c: mov             x3, x0
    // 0x11383a0: ldr             x0, [fp, #0x10]
    // 0x11383a4: b               #0x11383b8
    // 0x11383a8: ldr             x0, [fp, #0x10]
    // 0x11383ac: LoadField: r1 = r0->field_27
    //     0x11383ac: ldur            w1, [x0, #0x27]
    // 0x11383b0: DecompressPointer r1
    //     0x11383b0: add             x1, x1, HEAP, lsl #32
    // 0x11383b4: mov             x3, x1
    // 0x11383b8: ldur            x2, [fp, #-8]
    // 0x11383bc: stur            x3, [fp, #-0x48]
    // 0x11383c0: r17 = 5058
    //     0x11383c0: mov             x17, #0x13c2
    // 0x11383c4: cmp             x2, x17
    // 0x11383c8: b.ne            #0x11383dc
    // 0x11383cc: LoadField: r1 = r0->field_2b
    //     0x11383cc: ldur            w1, [x0, #0x2b]
    // 0x11383d0: DecompressPointer r1
    //     0x11383d0: add             x1, x1, HEAP, lsl #32
    // 0x11383d4: mov             x0, x2
    // 0x11383d8: b               #0x113844c
    // 0x11383dc: r17 = 5059
    //     0x11383dc: mov             x17, #0x13c3
    // 0x11383e0: cmp             x2, x17
    // 0x11383e4: b.eq            #0x1138778
    // 0x11383e8: r17 = 5060
    //     0x11383e8: mov             x17, #0x13c4
    // 0x11383ec: cmp             x2, x17
    // 0x11383f0: b.ne            #0x1138428
    // 0x11383f4: mov             x1, x0
    // 0x11383f8: LoadField: r0 = r1->field_53
    //     0x11383f8: ldur            w0, [x1, #0x53]
    // 0x11383fc: DecompressPointer r0
    //     0x11383fc: add             x0, x0, HEAP, lsl #32
    // 0x1138400: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1138404: cmp             w0, w16
    // 0x1138408: b.ne            #0x1138418
    // 0x113840c: r2 = _textTheme
    //     0x113840c: add             x2, PP, #0x26, lsl #12  ; [pp+0x260c8] Field <_TabsPrimaryDefaultsM3@780014024._textTheme@780014024>: late final (offset: 0x54)
    //     0x1138410: ldr             x2, [x2, #0xc8]
    // 0x1138414: r0 = InitLateFinalInstanceField()
    //     0x1138414: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1138418: LoadField: r1 = r0->field_27
    //     0x1138418: ldur            w1, [x0, #0x27]
    // 0x113841c: DecompressPointer r1
    //     0x113841c: add             x1, x1, HEAP, lsl #32
    // 0x1138420: ldur            x0, [fp, #-8]
    // 0x1138424: b               #0x113844c
    // 0x1138428: LoadField: r1 = r0->field_4b
    //     0x1138428: ldur            w1, [x0, #0x4b]
    // 0x113842c: DecompressPointer r1
    //     0x113842c: add             x1, x1, HEAP, lsl #32
    // 0x1138430: r0 = of()
    //     0x1138430: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1138434: LoadField: r1 = r0->field_83
    //     0x1138434: ldur            w1, [x0, #0x83]
    // 0x1138438: DecompressPointer r1
    //     0x1138438: add             x1, x1, HEAP, lsl #32
    // 0x113843c: LoadField: r0 = r1->field_2b
    //     0x113843c: ldur            w0, [x1, #0x2b]
    // 0x1138440: DecompressPointer r0
    //     0x1138440: add             x0, x0, HEAP, lsl #32
    // 0x1138444: mov             x1, x0
    // 0x1138448: ldur            x0, [fp, #-8]
    // 0x113844c: stur            x1, [fp, #-0x50]
    // 0x1138450: r17 = 5058
    //     0x1138450: mov             x17, #0x13c2
    // 0x1138454: cmp             x0, x17
    // 0x1138458: b.eq            #0x1138504
    // 0x113845c: r17 = 5059
    //     0x113845c: mov             x17, #0x13c3
    // 0x1138460: cmp             x0, x17
    // 0x1138464: b.ne            #0x11384b0
    // 0x1138468: ldr             x2, [fp, #0x10]
    // 0x113846c: r1 = 1
    //     0x113846c: mov             x1, #1
    // 0x1138470: r0 = AllocateContext()
    //     0x1138470: bl              #0x13de838  ; AllocateContextStub
    // 0x1138474: mov             x1, x0
    // 0x1138478: ldr             x0, [fp, #0x10]
    // 0x113847c: StoreField: r1->field_f = r0
    //     0x113847c: stur            w0, [x1, #0xf]
    // 0x1138480: mov             x2, x1
    // 0x1138484: r1 = Function '<anonymous closure>':.
    //     0x1138484: add             x1, PP, #0x26, lsl #12  ; [pp+0x260d0] AnonymousClosure: (0xe005e0), of [package:flutter/src/material/tabs.dart] _TabsSecondaryDefaultsM3
    //     0x1138488: ldr             x1, [x1, #0xd0]
    // 0x113848c: r0 = AllocateClosure()
    //     0x113848c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1138490: r16 = <Color?>
    //     0x1138490: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1138494: ldr             x16, [x16, #0xa40]
    // 0x1138498: stp             x0, x16, [SP]
    // 0x113849c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x113849c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x11384a0: r0 = resolveWith()
    //     0x11384a0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x11384a4: mov             x3, x0
    // 0x11384a8: ldr             x0, [fp, #0x10]
    // 0x11384ac: b               #0x1138514
    // 0x11384b0: r17 = 5060
    //     0x11384b0: mov             x17, #0x13c4
    // 0x11384b4: cmp             x0, x17
    // 0x11384b8: b.ne            #0x1138504
    // 0x11384bc: ldr             x1, [fp, #0x10]
    // 0x11384c0: r1 = 1
    //     0x11384c0: mov             x1, #1
    // 0x11384c4: r0 = AllocateContext()
    //     0x11384c4: bl              #0x13de838  ; AllocateContextStub
    // 0x11384c8: mov             x1, x0
    // 0x11384cc: ldr             x0, [fp, #0x10]
    // 0x11384d0: StoreField: r1->field_f = r0
    //     0x11384d0: stur            w0, [x1, #0xf]
    // 0x11384d4: mov             x2, x1
    // 0x11384d8: r1 = Function '<anonymous closure>':.
    //     0x11384d8: add             x1, PP, #0x26, lsl #12  ; [pp+0x260d8] AnonymousClosure: (0xe00204), of [package:flutter/src/material/tabs.dart] _TabsPrimaryDefaultsM3
    //     0x11384dc: ldr             x1, [x1, #0xd8]
    // 0x11384e0: r0 = AllocateClosure()
    //     0x11384e0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11384e4: r16 = <Color?>
    //     0x11384e4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x11384e8: ldr             x16, [x16, #0xa40]
    // 0x11384ec: stp             x0, x16, [SP]
    // 0x11384f0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x11384f0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x11384f4: r0 = resolveWith()
    //     0x11384f4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x11384f8: mov             x3, x0
    // 0x11384fc: ldr             x0, [fp, #0x10]
    // 0x1138500: b               #0x1138514
    // 0x1138504: ldr             x0, [fp, #0x10]
    // 0x1138508: LoadField: r1 = r0->field_2f
    //     0x1138508: ldur            w1, [x0, #0x2f]
    // 0x113850c: DecompressPointer r1
    //     0x113850c: add             x1, x1, HEAP, lsl #32
    // 0x1138510: mov             x3, x1
    // 0x1138514: ldur            x2, [fp, #-8]
    // 0x1138518: stur            x3, [fp, #-0x58]
    // 0x113851c: r17 = 5058
    //     0x113851c: mov             x17, #0x13c2
    // 0x1138520: cmp             x2, x17
    // 0x1138524: b.ne            #0x1138538
    // 0x1138528: LoadField: r1 = r0->field_33
    //     0x1138528: ldur            w1, [x0, #0x33]
    // 0x113852c: DecompressPointer r1
    //     0x113852c: add             x1, x1, HEAP, lsl #32
    // 0x1138530: mov             x0, x2
    // 0x1138534: b               #0x1138584
    // 0x1138538: r17 = 5059
    //     0x1138538: mov             x17, #0x13c3
    // 0x113853c: cmp             x2, x17
    // 0x1138540: b.eq            #0x11387ac
    // 0x1138544: r17 = 5060
    //     0x1138544: mov             x17, #0x13c4
    // 0x1138548: cmp             x2, x17
    // 0x113854c: b.ne            #0x113856c
    // 0x1138550: LoadField: r1 = r0->field_4b
    //     0x1138550: ldur            w1, [x0, #0x4b]
    // 0x1138554: DecompressPointer r1
    //     0x1138554: add             x1, x1, HEAP, lsl #32
    // 0x1138558: r0 = of()
    //     0x1138558: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x113855c: LoadField: r1 = r0->field_2b
    //     0x113855c: ldur            w1, [x0, #0x2b]
    // 0x1138560: DecompressPointer r1
    //     0x1138560: add             x1, x1, HEAP, lsl #32
    // 0x1138564: ldur            x0, [fp, #-8]
    // 0x1138568: b               #0x1138584
    // 0x113856c: LoadField: r1 = r0->field_4b
    //     0x113856c: ldur            w1, [x0, #0x4b]
    // 0x1138570: DecompressPointer r1
    //     0x1138570: add             x1, x1, HEAP, lsl #32
    // 0x1138574: r0 = of()
    //     0x1138574: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1138578: LoadField: r1 = r0->field_2b
    //     0x1138578: ldur            w1, [x0, #0x2b]
    // 0x113857c: DecompressPointer r1
    //     0x113857c: add             x1, x1, HEAP, lsl #32
    // 0x1138580: ldur            x0, [fp, #-8]
    // 0x1138584: r17 = 5058
    //     0x1138584: mov             x17, #0x13c2
    // 0x1138588: cmp             x0, x17
    // 0x113858c: b.ne            #0x11385a0
    // 0x1138590: ldr             x2, [fp, #0x10]
    // 0x1138594: LoadField: r0 = r2->field_3b
    //     0x1138594: ldur            w0, [x2, #0x3b]
    // 0x1138598: DecompressPointer r0
    //     0x1138598: add             x0, x0, HEAP, lsl #32
    // 0x113859c: b               #0x11385fc
    // 0x11385a0: ldr             x2, [fp, #0x10]
    // 0x11385a4: r17 = 5059
    //     0x11385a4: mov             x17, #0x13c3
    // 0x11385a8: cmp             x0, x17
    // 0x11385ac: b.ne            #0x11385dc
    // 0x11385b0: LoadField: r0 = r2->field_57
    //     0x11385b0: ldur            w0, [x2, #0x57]
    // 0x11385b4: DecompressPointer r0
    //     0x11385b4: add             x0, x0, HEAP, lsl #32
    // 0x11385b8: r16 = true
    //     0x11385b8: add             x16, NULL, #0x20  ; true
    // 0x11385bc: cmp             w0, w16
    // 0x11385c0: b.ne            #0x11385d0
    // 0x11385c4: r0 = Instance_TabAlignment
    //     0x11385c4: add             x0, PP, #0x26, lsl #12  ; [pp+0x260e0] Obj!TabAlignment@12c4cc1
    //     0x11385c8: ldr             x0, [x0, #0xe0]
    // 0x11385cc: b               #0x11385fc
    // 0x11385d0: r0 = Instance_TabAlignment
    //     0x11385d0: add             x0, PP, #0x26, lsl #12  ; [pp+0x260e8] Obj!TabAlignment@12c4c81
    //     0x11385d4: ldr             x0, [x0, #0xe8]
    // 0x11385d8: b               #0x11385fc
    // 0x11385dc: r17 = 5060
    //     0x11385dc: mov             x17, #0x13c4
    // 0x11385e0: cmp             x0, x17
    // 0x11385e4: b.ne            #0x11385f4
    // 0x11385e8: r0 = Instance_TabAlignment
    //     0x11385e8: add             x0, PP, #0x26, lsl #12  ; [pp+0x260e8] Obj!TabAlignment@12c4c81
    //     0x11385ec: ldr             x0, [x0, #0xe8]
    // 0x11385f0: b               #0x11385fc
    // 0x11385f4: r0 = Instance_TabAlignment
    //     0x11385f4: add             x0, PP, #0x26, lsl #12  ; [pp+0x260e8] Obj!TabAlignment@12c4c81
    //     0x11385f8: ldr             x0, [x0, #0xe8]
    // 0x11385fc: ldur            x16, [fp, #-0x18]
    // 0x1138600: ldur            lr, [fp, #-0x30]
    // 0x1138604: stp             lr, x16, [SP, #0x68]
    // 0x1138608: ldur            x16, [fp, #-0x28]
    // 0x113860c: ldur            lr, [fp, #-0x38]
    // 0x1138610: stp             lr, x16, [SP, #0x58]
    // 0x1138614: ldur            x16, [fp, #-0x40]
    // 0x1138618: stp             x16, NULL, [SP, #0x48]
    // 0x113861c: ldur            x16, [fp, #-0x48]
    // 0x1138620: ldur            lr, [fp, #-0x50]
    // 0x1138624: stp             lr, x16, [SP, #0x38]
    // 0x1138628: ldur            x16, [fp, #-0x58]
    // 0x113862c: stp             x1, x16, [SP, #0x28]
    // 0x1138630: stp             x0, NULL, [SP, #0x18]
    // 0x1138634: stp             NULL, NULL, [SP, #8]
    // 0x1138638: str             NULL, [SP]
    // 0x113863c: ldur            x1, [fp, #-0x10]
    // 0x1138640: ldur            x2, [fp, #-0x20]
    // 0x1138644: r4 = const [0, 0x11, 0xf, 0x11, null]
    //     0x1138644: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbd0] List(5) [0, 0x11, 0xf, 0x11, Null]
    //     0x1138648: ldr             x4, [x4, #0xbd0]
    // 0x113864c: r0 = hash()
    //     0x113864c: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1138650: mov             x2, x0
    // 0x1138654: r0 = BoxInt64Instr(r2)
    //     0x1138654: sbfiz           x0, x2, #1, #0x1f
    //     0x1138658: cmp             x2, x0, asr #1
    //     0x113865c: b.eq            #0x1138668
    //     0x1138660: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1138664: stur            x2, [x0, #7]
    // 0x1138668: LeaveFrame
    //     0x1138668: mov             SP, fp
    //     0x113866c: ldp             fp, lr, [SP], #0x10
    // 0x1138670: ret
    //     0x1138670: ret             
    // 0x1138674: mov             x2, x0
    // 0x1138678: mov             x1, x2
    // 0x113867c: LoadField: r0 = r1->field_4f
    //     0x113867c: ldur            w0, [x1, #0x4f]
    // 0x1138680: DecompressPointer r0
    //     0x1138680: add             x0, x0, HEAP, lsl #32
    // 0x1138684: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1138688: cmp             w0, w16
    // 0x113868c: b.ne            #0x113869c
    // 0x1138690: r2 = _colors
    //     0x1138690: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x1138694: ldr             x2, [x2, #0xf0]
    // 0x1138698: r0 = InitLateFinalInstanceField()
    //     0x1138698: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113869c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x113869c: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x11386a0: r0 = Throw()
    //     0x11386a0: bl              #0x13ddb2c  ; ThrowStub
    // 0x11386a4: brk             #0
    // 0x11386a8: mov             x2, x0
    // 0x11386ac: mov             x1, x2
    // 0x11386b0: LoadField: r0 = r1->field_4f
    //     0x11386b0: ldur            w0, [x1, #0x4f]
    // 0x11386b4: DecompressPointer r0
    //     0x11386b4: add             x0, x0, HEAP, lsl #32
    // 0x11386b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11386bc: cmp             w0, w16
    // 0x11386c0: b.ne            #0x11386d0
    // 0x11386c4: r2 = _colors
    //     0x11386c4: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x11386c8: ldr             x2, [x2, #0xf0]
    // 0x11386cc: r0 = InitLateFinalInstanceField()
    //     0x11386cc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11386d0: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x11386d0: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x11386d4: r0 = Throw()
    //     0x11386d4: bl              #0x13ddb2c  ; ThrowStub
    // 0x11386d8: brk             #0
    // 0x11386dc: mov             x2, x0
    // 0x11386e0: mov             x1, x2
    // 0x11386e4: LoadField: r0 = r1->field_4f
    //     0x11386e4: ldur            w0, [x1, #0x4f]
    // 0x11386e8: DecompressPointer r0
    //     0x11386e8: add             x0, x0, HEAP, lsl #32
    // 0x11386ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11386f0: cmp             w0, w16
    // 0x11386f4: b.ne            #0x1138704
    // 0x11386f8: r2 = _colors
    //     0x11386f8: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x11386fc: ldr             x2, [x2, #0xf0]
    // 0x1138700: r0 = InitLateFinalInstanceField()
    //     0x1138700: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1138704: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1138704: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1138708: r0 = Throw()
    //     0x1138708: bl              #0x13ddb2c  ; ThrowStub
    // 0x113870c: brk             #0
    // 0x1138710: mov             x2, x3
    // 0x1138714: mov             x1, x2
    // 0x1138718: LoadField: r0 = r1->field_53
    //     0x1138718: ldur            w0, [x1, #0x53]
    // 0x113871c: DecompressPointer r0
    //     0x113871c: add             x0, x0, HEAP, lsl #32
    // 0x1138720: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1138724: cmp             w0, w16
    // 0x1138728: b.ne            #0x1138738
    // 0x113872c: r2 = _textTheme
    //     0x113872c: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f8] Field <_TabsSecondaryDefaultsM3@780014024._textTheme@780014024>: late final (offset: 0x54)
    //     0x1138730: ldr             x2, [x2, #0xf8]
    // 0x1138734: r0 = InitLateFinalInstanceField()
    //     0x1138734: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1138738: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1138738: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x113873c: r0 = Throw()
    //     0x113873c: bl              #0x13ddb2c  ; ThrowStub
    // 0x1138740: brk             #0
    // 0x1138744: ldr             x2, [fp, #0x10]
    // 0x1138748: mov             x1, x2
    // 0x113874c: LoadField: r0 = r1->field_4f
    //     0x113874c: ldur            w0, [x1, #0x4f]
    // 0x1138750: DecompressPointer r0
    //     0x1138750: add             x0, x0, HEAP, lsl #32
    // 0x1138754: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1138758: cmp             w0, w16
    // 0x113875c: b.ne            #0x113876c
    // 0x1138760: r2 = _colors
    //     0x1138760: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x1138764: ldr             x2, [x2, #0xf0]
    // 0x1138768: r0 = InitLateFinalInstanceField()
    //     0x1138768: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113876c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x113876c: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1138770: r0 = Throw()
    //     0x1138770: bl              #0x13ddb2c  ; ThrowStub
    // 0x1138774: brk             #0
    // 0x1138778: mov             x2, x0
    // 0x113877c: mov             x1, x2
    // 0x1138780: LoadField: r0 = r1->field_53
    //     0x1138780: ldur            w0, [x1, #0x53]
    // 0x1138784: DecompressPointer r0
    //     0x1138784: add             x0, x0, HEAP, lsl #32
    // 0x1138788: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x113878c: cmp             w0, w16
    // 0x1138790: b.ne            #0x11387a0
    // 0x1138794: r2 = _textTheme
    //     0x1138794: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f8] Field <_TabsSecondaryDefaultsM3@780014024._textTheme@780014024>: late final (offset: 0x54)
    //     0x1138798: ldr             x2, [x2, #0xf8]
    // 0x113879c: r0 = InitLateFinalInstanceField()
    //     0x113879c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11387a0: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x11387a0: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x11387a4: r0 = Throw()
    //     0x11387a4: bl              #0x13ddb2c  ; ThrowStub
    // 0x11387a8: brk             #0
    // 0x11387ac: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x11387ac: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x11387b0: r0 = Throw()
    //     0x11387b0: bl              #0x13ddb2c  ; ThrowStub
    // 0x11387b4: brk             #0
    // 0x11387b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11387b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11387bc: b               #0x1137fc8
    // 0x11387c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11387c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x116539c, size: 0x198
    // 0x116539c: EnterFrame
    //     0x116539c: stp             fp, lr, [SP, #-0x10]!
    //     0x11653a0: mov             fp, SP
    // 0x11653a4: AllocStack(0x28)
    //     0x11653a4: sub             SP, SP, #0x28
    // 0x11653a8: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x28 */)
    //     0x11653a8: mov             x3, x1
    //     0x11653ac: mov             x0, x2
    //     0x11653b0: mov             v1.16b, v0.16b
    //     0x11653b4: stur            x1, [fp, #-8]
    //     0x11653b8: stur            x2, [fp, #-0x10]
    //     0x11653bc: stur            d0, [fp, #-0x28]
    // 0x11653c0: CheckStackOverflow
    //     0x11653c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11653c4: cmp             SP, x16
    //     0x11653c8: b.ls            #0x1165510
    // 0x11653cc: cmp             w3, w0
    // 0x11653d0: b.ne            #0x11653e4
    // 0x11653d4: mov             x0, x3
    // 0x11653d8: LeaveFrame
    //     0x11653d8: mov             SP, fp
    //     0x11653dc: ldp             fp, lr, [SP], #0x10
    // 0x11653e0: ret
    //     0x11653e0: ret             
    // 0x11653e4: LoadField: r1 = r3->field_7
    //     0x11653e4: ldur            w1, [x3, #7]
    // 0x11653e8: DecompressPointer r1
    //     0x11653e8: add             x1, x1, HEAP, lsl #32
    // 0x11653ec: LoadField: r2 = r0->field_7
    //     0x11653ec: ldur            w2, [x0, #7]
    // 0x11653f0: DecompressPointer r2
    //     0x11653f0: add             x2, x2, HEAP, lsl #32
    // 0x11653f4: mov             v0.16b, v1.16b
    // 0x11653f8: r0 = lerp()
    //     0x11653f8: bl              #0x115f65c  ; [package:flutter/src/painting/decoration.dart] Decoration::lerp
    // 0x11653fc: ldur            d0, [fp, #-0x28]
    // 0x1165400: stur            x0, [fp, #-0x20]
    // 0x1165404: r4 = inline_Allocate_Double()
    //     0x1165404: ldp             x4, x1, [THR, #0x60]  ; THR::top
    //     0x1165408: add             x4, x4, #0x10
    //     0x116540c: cmp             x1, x4
    //     0x1165410: b.ls            #0x1165518
    //     0x1165414: str             x4, [THR, #0x60]  ; THR::top
    //     0x1165418: sub             x4, x4, #0xf
    //     0x116541c: mov             x1, #0xe19c
    //     0x1165420: movk            x1, #3, lsl #16
    //     0x1165424: stur            x1, [x4, #-1]
    // 0x1165428: dmb             ishst
    // 0x116542c: StoreField: r4->field_7 = d0
    //     0x116542c: stur            d0, [x4, #7]
    // 0x1165430: mov             x3, x4
    // 0x1165434: stur            x4, [fp, #-0x18]
    // 0x1165438: r1 = Null
    //     0x1165438: mov             x1, NULL
    // 0x116543c: r2 = Null
    //     0x116543c: mov             x2, NULL
    // 0x1165440: r0 = lerp()
    //     0x1165440: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1165444: ldur            d0, [fp, #-0x28]
    // 0x1165448: d1 = 0.500000
    //     0x1165448: fmov            d1, #0.50000000
    // 0x116544c: fcmp            d1, d0
    // 0x1165450: b.le            #0x1165468
    // 0x1165454: ldur            x0, [fp, #-8]
    // 0x1165458: LoadField: r1 = r0->field_f
    //     0x1165458: ldur            w1, [x0, #0xf]
    // 0x116545c: DecompressPointer r1
    //     0x116545c: add             x1, x1, HEAP, lsl #32
    // 0x1165460: mov             x4, x1
    // 0x1165464: b               #0x1165478
    // 0x1165468: ldur            x0, [fp, #-0x10]
    // 0x116546c: LoadField: r1 = r0->field_f
    //     0x116546c: ldur            w1, [x0, #0xf]
    // 0x1165470: DecompressPointer r1
    //     0x1165470: add             x1, x1, HEAP, lsl #32
    // 0x1165474: mov             x4, x1
    // 0x1165478: ldur            x0, [fp, #-0x20]
    // 0x116547c: ldur            x3, [fp, #-0x18]
    // 0x1165480: stur            x4, [fp, #-8]
    // 0x1165484: r1 = Null
    //     0x1165484: mov             x1, NULL
    // 0x1165488: r2 = Null
    //     0x1165488: mov             x2, NULL
    // 0x116548c: r0 = lerp()
    //     0x116548c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1165490: ldur            x3, [fp, #-0x18]
    // 0x1165494: r1 = Null
    //     0x1165494: mov             x1, NULL
    // 0x1165498: r2 = Null
    //     0x1165498: mov             x2, NULL
    // 0x116549c: r0 = lerp()
    //     0x116549c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11654a0: ldur            x3, [fp, #-0x18]
    // 0x11654a4: r1 = Null
    //     0x11654a4: mov             x1, NULL
    // 0x11654a8: r2 = Null
    //     0x11654a8: mov             x2, NULL
    // 0x11654ac: r0 = lerp()
    //     0x11654ac: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x11654b0: ldur            x3, [fp, #-0x18]
    // 0x11654b4: r1 = Null
    //     0x11654b4: mov             x1, NULL
    // 0x11654b8: r2 = Null
    //     0x11654b8: mov             x2, NULL
    // 0x11654bc: r0 = lerp()
    //     0x11654bc: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x11654c0: ldur            x3, [fp, #-0x18]
    // 0x11654c4: r1 = Null
    //     0x11654c4: mov             x1, NULL
    // 0x11654c8: r2 = Null
    //     0x11654c8: mov             x2, NULL
    // 0x11654cc: r0 = lerp()
    //     0x11654cc: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11654d0: ldur            x3, [fp, #-0x18]
    // 0x11654d4: r1 = Null
    //     0x11654d4: mov             x1, NULL
    // 0x11654d8: r2 = Null
    //     0x11654d8: mov             x2, NULL
    // 0x11654dc: r0 = lerp()
    //     0x11654dc: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x11654e0: ldur            d0, [fp, #-0x28]
    // 0x11654e4: r1 = Null
    //     0x11654e4: mov             x1, NULL
    // 0x11654e8: r2 = Null
    //     0x11654e8: mov             x2, NULL
    // 0x11654ec: r0 = lerp()
    //     0x11654ec: bl              #0xbfea10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::lerp
    // 0x11654f0: r0 = TabBarThemeData()
    //     0x11654f0: bl              #0xeb4764  ; AllocateTabBarThemeDataStub -> TabBarThemeData (size=0x4c)
    // 0x11654f4: ldur            x1, [fp, #-0x20]
    // 0x11654f8: StoreField: r0->field_7 = r1
    //     0x11654f8: stur            w1, [x0, #7]
    // 0x11654fc: ldur            x1, [fp, #-8]
    // 0x1165500: StoreField: r0->field_f = r1
    //     0x1165500: stur            w1, [x0, #0xf]
    // 0x1165504: LeaveFrame
    //     0x1165504: mov             SP, fp
    //     0x1165508: ldp             fp, lr, [SP], #0x10
    // 0x116550c: ret
    //     0x116550c: ret             
    // 0x1165510: r0 = StackOverflowSharedWithFPURegs()
    //     0x1165510: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1165514: b               #0x11653cc
    // 0x1165518: SaveReg d0
    //     0x1165518: str             q0, [SP, #-0x10]!
    // 0x116551c: SaveReg r0
    //     0x116551c: str             x0, [SP, #-8]!
    // 0x1165520: r0 = AllocateDouble()
    //     0x1165520: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1165524: mov             x4, x0
    // 0x1165528: RestoreReg r0
    //     0x1165528: ldr             x0, [SP], #8
    // 0x116552c: RestoreReg d0
    //     0x116552c: ldr             q0, [SP], #0x10
    // 0x1165530: b               #0x116542c
  }
  _ ==(/* No info */) {
    // ** addr: 0x1275e30, size: 0x10fc
    // 0x1275e30: EnterFrame
    //     0x1275e30: stp             fp, lr, [SP, #-0x10]!
    //     0x1275e34: mov             fp, SP
    // 0x1275e38: AllocStack(0x30)
    //     0x1275e38: sub             SP, SP, #0x30
    // 0x1275e3c: CheckStackOverflow
    //     0x1275e3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1275e40: cmp             SP, x16
    //     0x1275e44: b.ls            #0x1276f1c
    // 0x1275e48: ldr             x1, [fp, #0x10]
    // 0x1275e4c: cmp             w1, NULL
    // 0x1275e50: b.ne            #0x1275e64
    // 0x1275e54: r0 = false
    //     0x1275e54: add             x0, NULL, #0x30  ; false
    // 0x1275e58: LeaveFrame
    //     0x1275e58: mov             SP, fp
    //     0x1275e5c: ldp             fp, lr, [SP], #0x10
    // 0x1275e60: ret
    //     0x1275e60: ret             
    // 0x1275e64: ldr             x0, [fp, #0x18]
    // 0x1275e68: cmp             w0, w1
    // 0x1275e6c: b.ne            #0x1275e80
    // 0x1275e70: r0 = true
    //     0x1275e70: add             x0, NULL, #0x20  ; true
    // 0x1275e74: LeaveFrame
    //     0x1275e74: mov             SP, fp
    //     0x1275e78: ldp             fp, lr, [SP], #0x10
    // 0x1275e7c: ret
    //     0x1275e7c: ret             
    // 0x1275e80: stp             x0, x1, [SP]
    // 0x1275e84: r0 = _haveSameRuntimeType()
    //     0x1275e84: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x1275e88: tbz             w0, #4, #0x1275e9c
    // 0x1275e8c: r0 = false
    //     0x1275e8c: add             x0, NULL, #0x30  ; false
    // 0x1275e90: LeaveFrame
    //     0x1275e90: mov             SP, fp
    //     0x1275e94: ldp             fp, lr, [SP], #0x10
    // 0x1275e98: ret
    //     0x1275e98: ret             
    // 0x1275e9c: ldr             x0, [fp, #0x10]
    // 0x1275ea0: r2 = 60
    //     0x1275ea0: mov             x2, #0x3c
    // 0x1275ea4: branchIfSmi(r0, 0x1275eb0)
    //     0x1275ea4: tbz             w0, #0, #0x1275eb0
    // 0x1275ea8: r2 = LoadClassIdInstr(r0)
    //     0x1275ea8: ldur            x2, [x0, #-1]
    //     0x1275eac: ubfx            x2, x2, #0xc, #0x14
    // 0x1275eb0: stur            x2, [fp, #-8]
    // 0x1275eb4: r17 = -5058
    //     0x1275eb4: mov             x17, #-0x13c2
    // 0x1275eb8: add             x16, x2, x17
    // 0x1275ebc: cmp             x16, #3
    // 0x1275ec0: b.hi            #0x1276ca0
    // 0x1275ec4: ldr             x3, [fp, #0x18]
    // 0x1275ec8: LoadField: r1 = r0->field_7
    //     0x1275ec8: ldur            w1, [x0, #7]
    // 0x1275ecc: DecompressPointer r1
    //     0x1275ecc: add             x1, x1, HEAP, lsl #32
    // 0x1275ed0: LoadField: r4 = r3->field_7
    //     0x1275ed0: ldur            w4, [x3, #7]
    // 0x1275ed4: DecompressPointer r4
    //     0x1275ed4: add             x4, x4, HEAP, lsl #32
    // 0x1275ed8: cmp             w1, w4
    // 0x1275edc: b.ne            #0x1276ca0
    // 0x1275ee0: r17 = 5058
    //     0x1275ee0: mov             x17, #0x13c2
    // 0x1275ee4: cmp             x2, x17
    // 0x1275ee8: b.ne            #0x1275f00
    // 0x1275eec: LoadField: r1 = r0->field_b
    //     0x1275eec: ldur            w1, [x0, #0xb]
    // 0x1275ef0: DecompressPointer r1
    //     0x1275ef0: add             x1, x1, HEAP, lsl #32
    // 0x1275ef4: mov             x2, x3
    // 0x1275ef8: mov             x3, x1
    // 0x1275efc: b               #0x1276000
    // 0x1275f00: r17 = 5059
    //     0x1275f00: mov             x17, #0x13c3
    // 0x1275f04: cmp             x2, x17
    // 0x1275f08: b.eq            #0x1276cb0
    // 0x1275f0c: r17 = 5060
    //     0x1275f0c: mov             x17, #0x13c4
    // 0x1275f10: cmp             x2, x17
    // 0x1275f14: b.ne            #0x1275f54
    // 0x1275f18: mov             x1, x0
    // 0x1275f1c: LoadField: r0 = r1->field_4f
    //     0x1275f1c: ldur            w0, [x1, #0x4f]
    // 0x1275f20: DecompressPointer r0
    //     0x1275f20: add             x0, x0, HEAP, lsl #32
    // 0x1275f24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1275f28: cmp             w0, w16
    // 0x1275f2c: b.ne            #0x1275f3c
    // 0x1275f30: r2 = _colors
    //     0x1275f30: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x1275f34: ldr             x2, [x2, #0xb0]
    // 0x1275f38: r0 = InitLateFinalInstanceField()
    //     0x1275f38: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1275f3c: LoadField: r1 = r0->field_b
    //     0x1275f3c: ldur            w1, [x0, #0xb]
    // 0x1275f40: DecompressPointer r1
    //     0x1275f40: add             x1, x1, HEAP, lsl #32
    // 0x1275f44: mov             x3, x1
    // 0x1275f48: ldr             x2, [fp, #0x18]
    // 0x1275f4c: ldr             x0, [fp, #0x10]
    // 0x1275f50: b               #0x1276000
    // 0x1275f54: ldr             x1, [fp, #0x10]
    // 0x1275f58: LoadField: r0 = r1->field_4f
    //     0x1275f58: ldur            w0, [x1, #0x4f]
    // 0x1275f5c: DecompressPointer r0
    //     0x1275f5c: add             x0, x0, HEAP, lsl #32
    // 0x1275f60: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1275f64: cmp             w0, w16
    // 0x1275f68: b.ne            #0x1275f78
    // 0x1275f6c: r2 = _colors
    //     0x1275f6c: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b8] Field <_TabsDefaultsM2@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x1275f70: ldr             x2, [x2, #0xb8]
    // 0x1275f74: r0 = InitLateFinalInstanceField()
    //     0x1275f74: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1275f78: LoadField: r2 = r0->field_2b
    //     0x1275f78: ldur            w2, [x0, #0x2b]
    // 0x1275f7c: DecompressPointer r2
    //     0x1275f7c: add             x2, x2, HEAP, lsl #32
    // 0x1275f80: ldr             x1, [fp, #0x10]
    // 0x1275f84: stur            x2, [fp, #-0x10]
    // 0x1275f88: LoadField: r0 = r1->field_57
    //     0x1275f88: ldur            w0, [x1, #0x57]
    // 0x1275f8c: DecompressPointer r0
    //     0x1275f8c: add             x0, x0, HEAP, lsl #32
    // 0x1275f90: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1275f94: cmp             w0, w16
    // 0x1275f98: b.ne            #0x1275fa8
    // 0x1275f9c: r2 = primaryColor
    //     0x1275f9c: add             x2, PP, #0x26, lsl #12  ; [pp+0x260c0] Field <_TabsDefaultsM2@780014024.primaryColor>: late final (offset: 0x58)
    //     0x1275fa0: ldr             x2, [x2, #0xc0]
    // 0x1275fa4: r0 = InitLateFinalInstanceField()
    //     0x1275fa4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1275fa8: mov             x1, x0
    // 0x1275fac: ldur            x0, [fp, #-0x10]
    // 0x1275fb0: r2 = LoadClassIdInstr(r0)
    //     0x1275fb0: ldur            x2, [x0, #-1]
    //     0x1275fb4: ubfx            x2, x2, #0xc, #0x14
    // 0x1275fb8: stp             x1, x0, [SP]
    // 0x1275fbc: mov             x0, x2
    // 0x1275fc0: mov             lr, x0
    // 0x1275fc4: ldr             lr, [x21, lr, lsl #3]
    // 0x1275fc8: blr             lr
    // 0x1275fcc: tbnz            w0, #4, #0x1275fe0
    // 0x1275fd0: ldr             x0, [fp, #0x10]
    // 0x1275fd4: r1 = Instance_Color
    //     0x1275fd4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x1275fd8: ldr             x1, [x1, #0xc38]
    // 0x1275fdc: b               #0x1275ff8
    // 0x1275fe0: ldr             x0, [fp, #0x10]
    // 0x1275fe4: LoadField: r1 = r0->field_4f
    //     0x1275fe4: ldur            w1, [x0, #0x4f]
    // 0x1275fe8: DecompressPointer r1
    //     0x1275fe8: add             x1, x1, HEAP, lsl #32
    // 0x1275fec: LoadField: r2 = r1->field_2b
    //     0x1275fec: ldur            w2, [x1, #0x2b]
    // 0x1275ff0: DecompressPointer r2
    //     0x1275ff0: add             x2, x2, HEAP, lsl #32
    // 0x1275ff4: mov             x1, x2
    // 0x1275ff8: mov             x3, x1
    // 0x1275ffc: ldr             x2, [fp, #0x18]
    // 0x1276000: stur            x3, [fp, #-0x10]
    // 0x1276004: r4 = LoadClassIdInstr(r2)
    //     0x1276004: ldur            x4, [x2, #-1]
    //     0x1276008: ubfx            x4, x4, #0xc, #0x14
    // 0x127600c: stur            x4, [fp, #-0x18]
    // 0x1276010: r17 = 5058
    //     0x1276010: mov             x17, #0x13c2
    // 0x1276014: cmp             x4, x17
    // 0x1276018: b.ne            #0x1276038
    // 0x127601c: LoadField: r1 = r2->field_b
    //     0x127601c: ldur            w1, [x2, #0xb]
    // 0x1276020: DecompressPointer r1
    //     0x1276020: add             x1, x1, HEAP, lsl #32
    // 0x1276024: mov             x16, x2
    // 0x1276028: mov             x2, x1
    // 0x127602c: mov             x1, x16
    // 0x1276030: mov             x0, x3
    // 0x1276034: b               #0x1276138
    // 0x1276038: r17 = 5059
    //     0x1276038: mov             x17, #0x13c3
    // 0x127603c: cmp             x4, x17
    // 0x1276040: b.eq            #0x1276ce0
    // 0x1276044: r17 = 5060
    //     0x1276044: mov             x17, #0x13c4
    // 0x1276048: cmp             x4, x17
    // 0x127604c: b.ne            #0x127608c
    // 0x1276050: mov             x1, x2
    // 0x1276054: LoadField: r0 = r1->field_4f
    //     0x1276054: ldur            w0, [x1, #0x4f]
    // 0x1276058: DecompressPointer r0
    //     0x1276058: add             x0, x0, HEAP, lsl #32
    // 0x127605c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1276060: cmp             w0, w16
    // 0x1276064: b.ne            #0x1276074
    // 0x1276068: r2 = _colors
    //     0x1276068: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x127606c: ldr             x2, [x2, #0xb0]
    // 0x1276070: r0 = InitLateFinalInstanceField()
    //     0x1276070: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1276074: LoadField: r1 = r0->field_b
    //     0x1276074: ldur            w1, [x0, #0xb]
    // 0x1276078: DecompressPointer r1
    //     0x1276078: add             x1, x1, HEAP, lsl #32
    // 0x127607c: mov             x2, x1
    // 0x1276080: ldr             x1, [fp, #0x18]
    // 0x1276084: ldur            x0, [fp, #-0x10]
    // 0x1276088: b               #0x1276138
    // 0x127608c: ldr             x1, [fp, #0x18]
    // 0x1276090: LoadField: r0 = r1->field_4f
    //     0x1276090: ldur            w0, [x1, #0x4f]
    // 0x1276094: DecompressPointer r0
    //     0x1276094: add             x0, x0, HEAP, lsl #32
    // 0x1276098: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x127609c: cmp             w0, w16
    // 0x12760a0: b.ne            #0x12760b0
    // 0x12760a4: r2 = _colors
    //     0x12760a4: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b8] Field <_TabsDefaultsM2@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x12760a8: ldr             x2, [x2, #0xb8]
    // 0x12760ac: r0 = InitLateFinalInstanceField()
    //     0x12760ac: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12760b0: LoadField: r2 = r0->field_2b
    //     0x12760b0: ldur            w2, [x0, #0x2b]
    // 0x12760b4: DecompressPointer r2
    //     0x12760b4: add             x2, x2, HEAP, lsl #32
    // 0x12760b8: ldr             x1, [fp, #0x18]
    // 0x12760bc: stur            x2, [fp, #-0x20]
    // 0x12760c0: LoadField: r0 = r1->field_57
    //     0x12760c0: ldur            w0, [x1, #0x57]
    // 0x12760c4: DecompressPointer r0
    //     0x12760c4: add             x0, x0, HEAP, lsl #32
    // 0x12760c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12760cc: cmp             w0, w16
    // 0x12760d0: b.ne            #0x12760e0
    // 0x12760d4: r2 = primaryColor
    //     0x12760d4: add             x2, PP, #0x26, lsl #12  ; [pp+0x260c0] Field <_TabsDefaultsM2@780014024.primaryColor>: late final (offset: 0x58)
    //     0x12760d8: ldr             x2, [x2, #0xc0]
    // 0x12760dc: r0 = InitLateFinalInstanceField()
    //     0x12760dc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12760e0: mov             x1, x0
    // 0x12760e4: ldur            x0, [fp, #-0x20]
    // 0x12760e8: r2 = LoadClassIdInstr(r0)
    //     0x12760e8: ldur            x2, [x0, #-1]
    //     0x12760ec: ubfx            x2, x2, #0xc, #0x14
    // 0x12760f0: stp             x1, x0, [SP]
    // 0x12760f4: mov             x0, x2
    // 0x12760f8: mov             lr, x0
    // 0x12760fc: ldr             lr, [x21, lr, lsl #3]
    // 0x1276100: blr             lr
    // 0x1276104: tbnz            w0, #4, #0x1276118
    // 0x1276108: ldr             x1, [fp, #0x18]
    // 0x127610c: r0 = Instance_Color
    //     0x127610c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x1276110: ldr             x0, [x0, #0xc38]
    // 0x1276114: b               #0x1276130
    // 0x1276118: ldr             x1, [fp, #0x18]
    // 0x127611c: LoadField: r0 = r1->field_4f
    //     0x127611c: ldur            w0, [x1, #0x4f]
    // 0x1276120: DecompressPointer r0
    //     0x1276120: add             x0, x0, HEAP, lsl #32
    // 0x1276124: LoadField: r2 = r0->field_2b
    //     0x1276124: ldur            w2, [x0, #0x2b]
    // 0x1276128: DecompressPointer r2
    //     0x1276128: add             x2, x2, HEAP, lsl #32
    // 0x127612c: mov             x0, x2
    // 0x1276130: mov             x2, x0
    // 0x1276134: ldur            x0, [fp, #-0x10]
    // 0x1276138: r3 = LoadClassIdInstr(r0)
    //     0x1276138: ldur            x3, [x0, #-1]
    //     0x127613c: ubfx            x3, x3, #0xc, #0x14
    // 0x1276140: stp             x2, x0, [SP]
    // 0x1276144: mov             x0, x3
    // 0x1276148: mov             lr, x0
    // 0x127614c: ldr             lr, [x21, lr, lsl #3]
    // 0x1276150: blr             lr
    // 0x1276154: tbnz            w0, #4, #0x1276ca0
    // 0x1276158: ldr             x0, [fp, #0x18]
    // 0x127615c: ldr             x2, [fp, #0x10]
    // 0x1276160: LoadField: r1 = r2->field_f
    //     0x1276160: ldur            w1, [x2, #0xf]
    // 0x1276164: DecompressPointer r1
    //     0x1276164: add             x1, x1, HEAP, lsl #32
    // 0x1276168: LoadField: r3 = r0->field_f
    //     0x1276168: ldur            w3, [x0, #0xf]
    // 0x127616c: DecompressPointer r3
    //     0x127616c: add             x3, x3, HEAP, lsl #32
    // 0x1276170: cmp             w1, w3
    // 0x1276174: b.ne            #0x1276ca0
    // 0x1276178: ldur            x3, [fp, #-8]
    // 0x127617c: r17 = 5058
    //     0x127617c: mov             x17, #0x13c2
    // 0x1276180: cmp             x3, x17
    // 0x1276184: b.ne            #0x1276190
    // 0x1276188: mov             x0, x2
    // 0x127618c: b               #0x1276200
    // 0x1276190: r17 = 5059
    //     0x1276190: mov             x17, #0x13c3
    // 0x1276194: cmp             x3, x17
    // 0x1276198: b.eq            #0x1276d10
    // 0x127619c: r17 = 5060
    //     0x127619c: mov             x17, #0x13c4
    // 0x12761a0: cmp             x3, x17
    // 0x12761a4: b.ne            #0x12761fc
    // 0x12761a8: mov             x1, x2
    // 0x12761ac: LoadField: r0 = r1->field_4f
    //     0x12761ac: ldur            w0, [x1, #0x4f]
    // 0x12761b0: DecompressPointer r0
    //     0x12761b0: add             x0, x0, HEAP, lsl #32
    // 0x12761b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12761b8: cmp             w0, w16
    // 0x12761bc: b.ne            #0x12761cc
    // 0x12761c0: r2 = _colors
    //     0x12761c0: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x12761c4: ldr             x2, [x2, #0xb0]
    // 0x12761c8: r0 = InitLateFinalInstanceField()
    //     0x12761c8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12761cc: LoadField: r1 = r0->field_ab
    //     0x12761cc: ldur            w1, [x0, #0xab]
    // 0x12761d0: DecompressPointer r1
    //     0x12761d0: add             x1, x1, HEAP, lsl #32
    // 0x12761d4: cmp             w1, NULL
    // 0x12761d8: b.ne            #0x12761ec
    // 0x12761dc: LoadField: r1 = r0->field_cb
    //     0x12761dc: ldur            w1, [x0, #0xcb]
    // 0x12761e0: DecompressPointer r1
    //     0x12761e0: add             x1, x1, HEAP, lsl #32
    // 0x12761e4: mov             x0, x1
    // 0x12761e8: b               #0x12761f0
    // 0x12761ec: mov             x0, x1
    // 0x12761f0: mov             x3, x0
    // 0x12761f4: ldr             x0, [fp, #0x10]
    // 0x12761f8: b               #0x127620c
    // 0x12761fc: ldr             x0, [fp, #0x10]
    // 0x1276200: LoadField: r1 = r0->field_13
    //     0x1276200: ldur            w1, [x0, #0x13]
    // 0x1276204: DecompressPointer r1
    //     0x1276204: add             x1, x1, HEAP, lsl #32
    // 0x1276208: mov             x3, x1
    // 0x127620c: ldur            x2, [fp, #-0x18]
    // 0x1276210: stur            x3, [fp, #-0x10]
    // 0x1276214: r17 = 5058
    //     0x1276214: mov             x17, #0x13c2
    // 0x1276218: cmp             x2, x17
    // 0x127621c: b.eq            #0x127628c
    // 0x1276220: r17 = 5059
    //     0x1276220: mov             x17, #0x13c3
    // 0x1276224: cmp             x2, x17
    // 0x1276228: b.eq            #0x1276d40
    // 0x127622c: r17 = 5060
    //     0x127622c: mov             x17, #0x13c4
    // 0x1276230: cmp             x2, x17
    // 0x1276234: b.ne            #0x127628c
    // 0x1276238: ldr             x1, [fp, #0x18]
    // 0x127623c: LoadField: r0 = r1->field_4f
    //     0x127623c: ldur            w0, [x1, #0x4f]
    // 0x1276240: DecompressPointer r0
    //     0x1276240: add             x0, x0, HEAP, lsl #32
    // 0x1276244: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1276248: cmp             w0, w16
    // 0x127624c: b.ne            #0x127625c
    // 0x1276250: r2 = _colors
    //     0x1276250: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x1276254: ldr             x2, [x2, #0xb0]
    // 0x1276258: r0 = InitLateFinalInstanceField()
    //     0x1276258: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x127625c: LoadField: r1 = r0->field_ab
    //     0x127625c: ldur            w1, [x0, #0xab]
    // 0x1276260: DecompressPointer r1
    //     0x1276260: add             x1, x1, HEAP, lsl #32
    // 0x1276264: cmp             w1, NULL
    // 0x1276268: b.ne            #0x127627c
    // 0x127626c: LoadField: r1 = r0->field_cb
    //     0x127626c: ldur            w1, [x0, #0xcb]
    // 0x1276270: DecompressPointer r1
    //     0x1276270: add             x1, x1, HEAP, lsl #32
    // 0x1276274: mov             x0, x1
    // 0x1276278: b               #0x1276280
    // 0x127627c: mov             x0, x1
    // 0x1276280: mov             x2, x0
    // 0x1276284: ldr             x1, [fp, #0x18]
    // 0x1276288: b               #0x127629c
    // 0x127628c: ldr             x1, [fp, #0x18]
    // 0x1276290: LoadField: r0 = r1->field_13
    //     0x1276290: ldur            w0, [x1, #0x13]
    // 0x1276294: DecompressPointer r0
    //     0x1276294: add             x0, x0, HEAP, lsl #32
    // 0x1276298: mov             x2, x0
    // 0x127629c: ldur            x0, [fp, #-0x10]
    // 0x12762a0: r3 = LoadClassIdInstr(r0)
    //     0x12762a0: ldur            x3, [x0, #-1]
    //     0x12762a4: ubfx            x3, x3, #0xc, #0x14
    // 0x12762a8: stp             x2, x0, [SP]
    // 0x12762ac: mov             x0, x3
    // 0x12762b0: mov             lr, x0
    // 0x12762b4: ldr             lr, [x21, lr, lsl #3]
    // 0x12762b8: blr             lr
    // 0x12762bc: tbnz            w0, #4, #0x1276ca0
    // 0x12762c0: ldur            x1, [fp, #-8]
    // 0x12762c4: r17 = 5058
    //     0x12762c4: mov             x17, #0x13c2
    // 0x12762c8: cmp             x1, x17
    // 0x12762cc: b.eq            #0x1276300
    // 0x12762d0: r17 = 5059
    //     0x12762d0: mov             x17, #0x13c3
    // 0x12762d4: cmp             x1, x17
    // 0x12762d8: b.ne            #0x12762e8
    // 0x12762dc: ldr             x2, [fp, #0x10]
    // 0x12762e0: r0 = 1.000000
    //     0x12762e0: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x12762e4: b               #0x127630c
    // 0x12762e8: r17 = 5060
    //     0x12762e8: mov             x17, #0x13c4
    // 0x12762ec: cmp             x1, x17
    // 0x12762f0: b.ne            #0x1276300
    // 0x12762f4: ldr             x2, [fp, #0x10]
    // 0x12762f8: r0 = 1.000000
    //     0x12762f8: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x12762fc: b               #0x127630c
    // 0x1276300: ldr             x2, [fp, #0x10]
    // 0x1276304: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x1276304: ldur            w0, [x2, #0x17]
    // 0x1276308: DecompressPointer r0
    //     0x1276308: add             x0, x0, HEAP, lsl #32
    // 0x127630c: ldur            x3, [fp, #-0x18]
    // 0x1276310: r17 = 5058
    //     0x1276310: mov             x17, #0x13c2
    // 0x1276314: cmp             x3, x17
    // 0x1276318: b.eq            #0x127634c
    // 0x127631c: r17 = 5059
    //     0x127631c: mov             x17, #0x13c3
    // 0x1276320: cmp             x3, x17
    // 0x1276324: b.ne            #0x1276334
    // 0x1276328: ldr             x4, [fp, #0x18]
    // 0x127632c: r5 = 1.000000
    //     0x127632c: ldr             x5, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x1276330: b               #0x1276358
    // 0x1276334: r17 = 5060
    //     0x1276334: mov             x17, #0x13c4
    // 0x1276338: cmp             x3, x17
    // 0x127633c: b.ne            #0x127634c
    // 0x1276340: ldr             x4, [fp, #0x18]
    // 0x1276344: r5 = 1.000000
    //     0x1276344: ldr             x5, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x1276348: b               #0x1276358
    // 0x127634c: ldr             x4, [fp, #0x18]
    // 0x1276350: ArrayLoad: r5 = r4[0]  ; List_4
    //     0x1276350: ldur            w5, [x4, #0x17]
    // 0x1276354: DecompressPointer r5
    //     0x1276354: add             x5, x5, HEAP, lsl #32
    // 0x1276358: r6 = LoadClassIdInstr(r0)
    //     0x1276358: ldur            x6, [x0, #-1]
    //     0x127635c: ubfx            x6, x6, #0xc, #0x14
    // 0x1276360: stp             x5, x0, [SP]
    // 0x1276364: mov             x0, x6
    // 0x1276368: mov             lr, x0
    // 0x127636c: ldr             lr, [x21, lr, lsl #3]
    // 0x1276370: blr             lr
    // 0x1276374: tbnz            w0, #4, #0x1276ca0
    // 0x1276378: ldur            x0, [fp, #-8]
    // 0x127637c: r17 = 5058
    //     0x127637c: mov             x17, #0x13c2
    // 0x1276380: cmp             x0, x17
    // 0x1276384: b.ne            #0x127639c
    // 0x1276388: ldr             x2, [fp, #0x10]
    // 0x127638c: LoadField: r1 = r2->field_1b
    //     0x127638c: ldur            w1, [x2, #0x1b]
    // 0x1276390: DecompressPointer r1
    //     0x1276390: add             x1, x1, HEAP, lsl #32
    // 0x1276394: mov             x2, x1
    // 0x1276398: b               #0x1276420
    // 0x127639c: ldr             x2, [fp, #0x10]
    // 0x12763a0: r17 = 5059
    //     0x12763a0: mov             x17, #0x13c3
    // 0x12763a4: cmp             x0, x17
    // 0x12763a8: b.eq            #0x1276d74
    // 0x12763ac: r17 = 5060
    //     0x12763ac: mov             x17, #0x13c4
    // 0x12763b0: cmp             x0, x17
    // 0x12763b4: b.ne            #0x12763ec
    // 0x12763b8: mov             x1, x2
    // 0x12763bc: LoadField: r0 = r1->field_4f
    //     0x12763bc: ldur            w0, [x1, #0x4f]
    // 0x12763c0: DecompressPointer r0
    //     0x12763c0: add             x0, x0, HEAP, lsl #32
    // 0x12763c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12763c8: cmp             w0, w16
    // 0x12763cc: b.ne            #0x12763dc
    // 0x12763d0: r2 = _colors
    //     0x12763d0: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x12763d4: ldr             x2, [x2, #0xb0]
    // 0x12763d8: r0 = InitLateFinalInstanceField()
    //     0x12763d8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12763dc: LoadField: r1 = r0->field_b
    //     0x12763dc: ldur            w1, [x0, #0xb]
    // 0x12763e0: DecompressPointer r1
    //     0x12763e0: add             x1, x1, HEAP, lsl #32
    // 0x12763e4: mov             x2, x1
    // 0x12763e8: b               #0x1276420
    // 0x12763ec: mov             x0, x2
    // 0x12763f0: LoadField: r1 = r0->field_4b
    //     0x12763f0: ldur            w1, [x0, #0x4b]
    // 0x12763f4: DecompressPointer r1
    //     0x12763f4: add             x1, x1, HEAP, lsl #32
    // 0x12763f8: r0 = of()
    //     0x12763f8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x12763fc: LoadField: r1 = r0->field_83
    //     0x12763fc: ldur            w1, [x0, #0x83]
    // 0x1276400: DecompressPointer r1
    //     0x1276400: add             x1, x1, HEAP, lsl #32
    // 0x1276404: LoadField: r0 = r1->field_2b
    //     0x1276404: ldur            w0, [x1, #0x2b]
    // 0x1276408: DecompressPointer r0
    //     0x1276408: add             x0, x0, HEAP, lsl #32
    // 0x127640c: LoadField: r1 = r0->field_b
    //     0x127640c: ldur            w1, [x0, #0xb]
    // 0x1276410: DecompressPointer r1
    //     0x1276410: add             x1, x1, HEAP, lsl #32
    // 0x1276414: cmp             w1, NULL
    // 0x1276418: b.eq            #0x1276f24
    // 0x127641c: mov             x2, x1
    // 0x1276420: ldur            x0, [fp, #-0x18]
    // 0x1276424: stur            x2, [fp, #-0x10]
    // 0x1276428: r17 = 5058
    //     0x1276428: mov             x17, #0x13c2
    // 0x127642c: cmp             x0, x17
    // 0x1276430: b.ne            #0x1276448
    // 0x1276434: ldr             x3, [fp, #0x18]
    // 0x1276438: LoadField: r1 = r3->field_1b
    //     0x1276438: ldur            w1, [x3, #0x1b]
    // 0x127643c: DecompressPointer r1
    //     0x127643c: add             x1, x1, HEAP, lsl #32
    // 0x1276440: mov             x0, x2
    // 0x1276444: b               #0x12764cc
    // 0x1276448: ldr             x3, [fp, #0x18]
    // 0x127644c: r17 = 5059
    //     0x127644c: mov             x17, #0x13c3
    // 0x1276450: cmp             x0, x17
    // 0x1276454: b.eq            #0x1276da4
    // 0x1276458: r17 = 5060
    //     0x1276458: mov             x17, #0x13c4
    // 0x127645c: cmp             x0, x17
    // 0x1276460: b.ne            #0x1276498
    // 0x1276464: mov             x1, x3
    // 0x1276468: LoadField: r0 = r1->field_4f
    //     0x1276468: ldur            w0, [x1, #0x4f]
    // 0x127646c: DecompressPointer r0
    //     0x127646c: add             x0, x0, HEAP, lsl #32
    // 0x1276470: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1276474: cmp             w0, w16
    // 0x1276478: b.ne            #0x1276488
    // 0x127647c: r2 = _colors
    //     0x127647c: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x1276480: ldr             x2, [x2, #0xb0]
    // 0x1276484: r0 = InitLateFinalInstanceField()
    //     0x1276484: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1276488: LoadField: r1 = r0->field_b
    //     0x1276488: ldur            w1, [x0, #0xb]
    // 0x127648c: DecompressPointer r1
    //     0x127648c: add             x1, x1, HEAP, lsl #32
    // 0x1276490: ldur            x0, [fp, #-0x10]
    // 0x1276494: b               #0x12764cc
    // 0x1276498: mov             x0, x3
    // 0x127649c: LoadField: r1 = r0->field_4b
    //     0x127649c: ldur            w1, [x0, #0x4b]
    // 0x12764a0: DecompressPointer r1
    //     0x12764a0: add             x1, x1, HEAP, lsl #32
    // 0x12764a4: r0 = of()
    //     0x12764a4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x12764a8: LoadField: r1 = r0->field_83
    //     0x12764a8: ldur            w1, [x0, #0x83]
    // 0x12764ac: DecompressPointer r1
    //     0x12764ac: add             x1, x1, HEAP, lsl #32
    // 0x12764b0: LoadField: r0 = r1->field_2b
    //     0x12764b0: ldur            w0, [x1, #0x2b]
    // 0x12764b4: DecompressPointer r0
    //     0x12764b4: add             x0, x0, HEAP, lsl #32
    // 0x12764b8: LoadField: r1 = r0->field_b
    //     0x12764b8: ldur            w1, [x0, #0xb]
    // 0x12764bc: DecompressPointer r1
    //     0x12764bc: add             x1, x1, HEAP, lsl #32
    // 0x12764c0: cmp             w1, NULL
    // 0x12764c4: b.eq            #0x1276f28
    // 0x12764c8: ldur            x0, [fp, #-0x10]
    // 0x12764cc: r2 = LoadClassIdInstr(r0)
    //     0x12764cc: ldur            x2, [x0, #-1]
    //     0x12764d0: ubfx            x2, x2, #0xc, #0x14
    // 0x12764d4: stp             x1, x0, [SP]
    // 0x12764d8: mov             x0, x2
    // 0x12764dc: mov             lr, x0
    // 0x12764e0: ldr             lr, [x21, lr, lsl #3]
    // 0x12764e4: blr             lr
    // 0x12764e8: tbnz            w0, #4, #0x1276ca0
    // 0x12764ec: ldur            x0, [fp, #-8]
    // 0x12764f0: r17 = 5058
    //     0x12764f0: mov             x17, #0x13c2
    // 0x12764f4: cmp             x0, x17
    // 0x12764f8: b.ne            #0x1276510
    // 0x12764fc: ldr             x2, [fp, #0x10]
    // 0x1276500: LoadField: r1 = r2->field_23
    //     0x1276500: ldur            w1, [x2, #0x23]
    // 0x1276504: DecompressPointer r1
    //     0x1276504: add             x1, x1, HEAP, lsl #32
    // 0x1276508: mov             x2, x1
    // 0x127650c: b               #0x1276584
    // 0x1276510: ldr             x2, [fp, #0x10]
    // 0x1276514: r17 = 5059
    //     0x1276514: mov             x17, #0x13c3
    // 0x1276518: cmp             x0, x17
    // 0x127651c: b.eq            #0x1276dd8
    // 0x1276520: r17 = 5060
    //     0x1276520: mov             x17, #0x13c4
    // 0x1276524: cmp             x0, x17
    // 0x1276528: b.ne            #0x1276560
    // 0x127652c: mov             x1, x2
    // 0x1276530: LoadField: r0 = r1->field_53
    //     0x1276530: ldur            w0, [x1, #0x53]
    // 0x1276534: DecompressPointer r0
    //     0x1276534: add             x0, x0, HEAP, lsl #32
    // 0x1276538: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x127653c: cmp             w0, w16
    // 0x1276540: b.ne            #0x1276550
    // 0x1276544: r2 = _textTheme
    //     0x1276544: add             x2, PP, #0x26, lsl #12  ; [pp+0x260c8] Field <_TabsPrimaryDefaultsM3@780014024._textTheme@780014024>: late final (offset: 0x54)
    //     0x1276548: ldr             x2, [x2, #0xc8]
    // 0x127654c: r0 = InitLateFinalInstanceField()
    //     0x127654c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1276550: LoadField: r1 = r0->field_27
    //     0x1276550: ldur            w1, [x0, #0x27]
    // 0x1276554: DecompressPointer r1
    //     0x1276554: add             x1, x1, HEAP, lsl #32
    // 0x1276558: mov             x2, x1
    // 0x127655c: b               #0x1276584
    // 0x1276560: mov             x0, x2
    // 0x1276564: LoadField: r1 = r0->field_4b
    //     0x1276564: ldur            w1, [x0, #0x4b]
    // 0x1276568: DecompressPointer r1
    //     0x1276568: add             x1, x1, HEAP, lsl #32
    // 0x127656c: r0 = of()
    //     0x127656c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1276570: LoadField: r1 = r0->field_83
    //     0x1276570: ldur            w1, [x0, #0x83]
    // 0x1276574: DecompressPointer r1
    //     0x1276574: add             x1, x1, HEAP, lsl #32
    // 0x1276578: LoadField: r0 = r1->field_2b
    //     0x1276578: ldur            w0, [x1, #0x2b]
    // 0x127657c: DecompressPointer r0
    //     0x127657c: add             x0, x0, HEAP, lsl #32
    // 0x1276580: mov             x2, x0
    // 0x1276584: ldur            x0, [fp, #-0x18]
    // 0x1276588: stur            x2, [fp, #-0x10]
    // 0x127658c: r17 = 5058
    //     0x127658c: mov             x17, #0x13c2
    // 0x1276590: cmp             x0, x17
    // 0x1276594: b.ne            #0x12765ac
    // 0x1276598: ldr             x3, [fp, #0x18]
    // 0x127659c: LoadField: r1 = r3->field_23
    //     0x127659c: ldur            w1, [x3, #0x23]
    // 0x12765a0: DecompressPointer r1
    //     0x12765a0: add             x1, x1, HEAP, lsl #32
    // 0x12765a4: mov             x0, x2
    // 0x12765a8: b               #0x1276624
    // 0x12765ac: ldr             x3, [fp, #0x18]
    // 0x12765b0: r17 = 5059
    //     0x12765b0: mov             x17, #0x13c3
    // 0x12765b4: cmp             x0, x17
    // 0x12765b8: b.eq            #0x1276e08
    // 0x12765bc: r17 = 5060
    //     0x12765bc: mov             x17, #0x13c4
    // 0x12765c0: cmp             x0, x17
    // 0x12765c4: b.ne            #0x12765fc
    // 0x12765c8: mov             x1, x3
    // 0x12765cc: LoadField: r0 = r1->field_53
    //     0x12765cc: ldur            w0, [x1, #0x53]
    // 0x12765d0: DecompressPointer r0
    //     0x12765d0: add             x0, x0, HEAP, lsl #32
    // 0x12765d4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12765d8: cmp             w0, w16
    // 0x12765dc: b.ne            #0x12765ec
    // 0x12765e0: r2 = _textTheme
    //     0x12765e0: add             x2, PP, #0x26, lsl #12  ; [pp+0x260c8] Field <_TabsPrimaryDefaultsM3@780014024._textTheme@780014024>: late final (offset: 0x54)
    //     0x12765e4: ldr             x2, [x2, #0xc8]
    // 0x12765e8: r0 = InitLateFinalInstanceField()
    //     0x12765e8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12765ec: LoadField: r1 = r0->field_27
    //     0x12765ec: ldur            w1, [x0, #0x27]
    // 0x12765f0: DecompressPointer r1
    //     0x12765f0: add             x1, x1, HEAP, lsl #32
    // 0x12765f4: ldur            x0, [fp, #-0x10]
    // 0x12765f8: b               #0x1276624
    // 0x12765fc: mov             x0, x3
    // 0x1276600: LoadField: r1 = r0->field_4b
    //     0x1276600: ldur            w1, [x0, #0x4b]
    // 0x1276604: DecompressPointer r1
    //     0x1276604: add             x1, x1, HEAP, lsl #32
    // 0x1276608: r0 = of()
    //     0x1276608: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x127660c: LoadField: r1 = r0->field_83
    //     0x127660c: ldur            w1, [x0, #0x83]
    // 0x1276610: DecompressPointer r1
    //     0x1276610: add             x1, x1, HEAP, lsl #32
    // 0x1276614: LoadField: r0 = r1->field_2b
    //     0x1276614: ldur            w0, [x1, #0x2b]
    // 0x1276618: DecompressPointer r0
    //     0x1276618: add             x0, x0, HEAP, lsl #32
    // 0x127661c: mov             x1, x0
    // 0x1276620: ldur            x0, [fp, #-0x10]
    // 0x1276624: r2 = LoadClassIdInstr(r0)
    //     0x1276624: ldur            x2, [x0, #-1]
    //     0x1276628: ubfx            x2, x2, #0xc, #0x14
    // 0x127662c: stp             x1, x0, [SP]
    // 0x1276630: mov             x0, x2
    // 0x1276634: mov             lr, x0
    // 0x1276638: ldr             lr, [x21, lr, lsl #3]
    // 0x127663c: blr             lr
    // 0x1276640: tbnz            w0, #4, #0x1276ca0
    // 0x1276644: ldur            x0, [fp, #-8]
    // 0x1276648: r17 = 5058
    //     0x1276648: mov             x17, #0x13c2
    // 0x127664c: cmp             x0, x17
    // 0x1276650: b.eq            #0x12766c0
    // 0x1276654: r17 = 5059
    //     0x1276654: mov             x17, #0x13c3
    // 0x1276658: cmp             x0, x17
    // 0x127665c: b.eq            #0x1276e3c
    // 0x1276660: r17 = 5060
    //     0x1276660: mov             x17, #0x13c4
    // 0x1276664: cmp             x0, x17
    // 0x1276668: b.ne            #0x12766c0
    // 0x127666c: ldr             x1, [fp, #0x10]
    // 0x1276670: LoadField: r0 = r1->field_4f
    //     0x1276670: ldur            w0, [x1, #0x4f]
    // 0x1276674: DecompressPointer r0
    //     0x1276674: add             x0, x0, HEAP, lsl #32
    // 0x1276678: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x127667c: cmp             w0, w16
    // 0x1276680: b.ne            #0x1276690
    // 0x1276684: r2 = _colors
    //     0x1276684: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x1276688: ldr             x2, [x2, #0xb0]
    // 0x127668c: r0 = InitLateFinalInstanceField()
    //     0x127668c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1276690: LoadField: r1 = r0->field_a3
    //     0x1276690: ldur            w1, [x0, #0xa3]
    // 0x1276694: DecompressPointer r1
    //     0x1276694: add             x1, x1, HEAP, lsl #32
    // 0x1276698: cmp             w1, NULL
    // 0x127669c: b.ne            #0x12766b0
    // 0x12766a0: LoadField: r1 = r0->field_7f
    //     0x12766a0: ldur            w1, [x0, #0x7f]
    // 0x12766a4: DecompressPointer r1
    //     0x12766a4: add             x1, x1, HEAP, lsl #32
    // 0x12766a8: mov             x0, x1
    // 0x12766ac: b               #0x12766b4
    // 0x12766b0: mov             x0, x1
    // 0x12766b4: mov             x3, x0
    // 0x12766b8: ldr             x0, [fp, #0x10]
    // 0x12766bc: b               #0x12766d0
    // 0x12766c0: ldr             x0, [fp, #0x10]
    // 0x12766c4: LoadField: r1 = r0->field_27
    //     0x12766c4: ldur            w1, [x0, #0x27]
    // 0x12766c8: DecompressPointer r1
    //     0x12766c8: add             x1, x1, HEAP, lsl #32
    // 0x12766cc: mov             x3, x1
    // 0x12766d0: ldur            x2, [fp, #-0x18]
    // 0x12766d4: stur            x3, [fp, #-0x10]
    // 0x12766d8: r17 = 5058
    //     0x12766d8: mov             x17, #0x13c2
    // 0x12766dc: cmp             x2, x17
    // 0x12766e0: b.eq            #0x1276750
    // 0x12766e4: r17 = 5059
    //     0x12766e4: mov             x17, #0x13c3
    // 0x12766e8: cmp             x2, x17
    // 0x12766ec: b.eq            #0x1276e6c
    // 0x12766f0: r17 = 5060
    //     0x12766f0: mov             x17, #0x13c4
    // 0x12766f4: cmp             x2, x17
    // 0x12766f8: b.ne            #0x1276750
    // 0x12766fc: ldr             x1, [fp, #0x18]
    // 0x1276700: LoadField: r0 = r1->field_4f
    //     0x1276700: ldur            w0, [x1, #0x4f]
    // 0x1276704: DecompressPointer r0
    //     0x1276704: add             x0, x0, HEAP, lsl #32
    // 0x1276708: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x127670c: cmp             w0, w16
    // 0x1276710: b.ne            #0x1276720
    // 0x1276714: r2 = _colors
    //     0x1276714: add             x2, PP, #0x26, lsl #12  ; [pp+0x260b0] Field <_TabsPrimaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x1276718: ldr             x2, [x2, #0xb0]
    // 0x127671c: r0 = InitLateFinalInstanceField()
    //     0x127671c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1276720: LoadField: r1 = r0->field_a3
    //     0x1276720: ldur            w1, [x0, #0xa3]
    // 0x1276724: DecompressPointer r1
    //     0x1276724: add             x1, x1, HEAP, lsl #32
    // 0x1276728: cmp             w1, NULL
    // 0x127672c: b.ne            #0x1276740
    // 0x1276730: LoadField: r1 = r0->field_7f
    //     0x1276730: ldur            w1, [x0, #0x7f]
    // 0x1276734: DecompressPointer r1
    //     0x1276734: add             x1, x1, HEAP, lsl #32
    // 0x1276738: mov             x0, x1
    // 0x127673c: b               #0x1276744
    // 0x1276740: mov             x0, x1
    // 0x1276744: mov             x2, x0
    // 0x1276748: ldr             x1, [fp, #0x18]
    // 0x127674c: b               #0x1276760
    // 0x1276750: ldr             x1, [fp, #0x18]
    // 0x1276754: LoadField: r0 = r1->field_27
    //     0x1276754: ldur            w0, [x1, #0x27]
    // 0x1276758: DecompressPointer r0
    //     0x1276758: add             x0, x0, HEAP, lsl #32
    // 0x127675c: mov             x2, x0
    // 0x1276760: ldur            x0, [fp, #-0x10]
    // 0x1276764: r3 = LoadClassIdInstr(r0)
    //     0x1276764: ldur            x3, [x0, #-1]
    //     0x1276768: ubfx            x3, x3, #0xc, #0x14
    // 0x127676c: stp             x2, x0, [SP]
    // 0x1276770: mov             x0, x3
    // 0x1276774: mov             lr, x0
    // 0x1276778: ldr             lr, [x21, lr, lsl #3]
    // 0x127677c: blr             lr
    // 0x1276780: tbnz            w0, #4, #0x1276ca0
    // 0x1276784: ldur            x0, [fp, #-8]
    // 0x1276788: r17 = 5058
    //     0x1276788: mov             x17, #0x13c2
    // 0x127678c: cmp             x0, x17
    // 0x1276790: b.ne            #0x12767a8
    // 0x1276794: ldr             x2, [fp, #0x10]
    // 0x1276798: LoadField: r1 = r2->field_2b
    //     0x1276798: ldur            w1, [x2, #0x2b]
    // 0x127679c: DecompressPointer r1
    //     0x127679c: add             x1, x1, HEAP, lsl #32
    // 0x12767a0: mov             x2, x1
    // 0x12767a4: b               #0x127681c
    // 0x12767a8: ldr             x2, [fp, #0x10]
    // 0x12767ac: r17 = 5059
    //     0x12767ac: mov             x17, #0x13c3
    // 0x12767b0: cmp             x0, x17
    // 0x12767b4: b.eq            #0x1276ea0
    // 0x12767b8: r17 = 5060
    //     0x12767b8: mov             x17, #0x13c4
    // 0x12767bc: cmp             x0, x17
    // 0x12767c0: b.ne            #0x12767f8
    // 0x12767c4: mov             x1, x2
    // 0x12767c8: LoadField: r0 = r1->field_53
    //     0x12767c8: ldur            w0, [x1, #0x53]
    // 0x12767cc: DecompressPointer r0
    //     0x12767cc: add             x0, x0, HEAP, lsl #32
    // 0x12767d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12767d4: cmp             w0, w16
    // 0x12767d8: b.ne            #0x12767e8
    // 0x12767dc: r2 = _textTheme
    //     0x12767dc: add             x2, PP, #0x26, lsl #12  ; [pp+0x260c8] Field <_TabsPrimaryDefaultsM3@780014024._textTheme@780014024>: late final (offset: 0x54)
    //     0x12767e0: ldr             x2, [x2, #0xc8]
    // 0x12767e4: r0 = InitLateFinalInstanceField()
    //     0x12767e4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12767e8: LoadField: r1 = r0->field_27
    //     0x12767e8: ldur            w1, [x0, #0x27]
    // 0x12767ec: DecompressPointer r1
    //     0x12767ec: add             x1, x1, HEAP, lsl #32
    // 0x12767f0: mov             x2, x1
    // 0x12767f4: b               #0x127681c
    // 0x12767f8: mov             x0, x2
    // 0x12767fc: LoadField: r1 = r0->field_4b
    //     0x12767fc: ldur            w1, [x0, #0x4b]
    // 0x1276800: DecompressPointer r1
    //     0x1276800: add             x1, x1, HEAP, lsl #32
    // 0x1276804: r0 = of()
    //     0x1276804: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1276808: LoadField: r1 = r0->field_83
    //     0x1276808: ldur            w1, [x0, #0x83]
    // 0x127680c: DecompressPointer r1
    //     0x127680c: add             x1, x1, HEAP, lsl #32
    // 0x1276810: LoadField: r0 = r1->field_2b
    //     0x1276810: ldur            w0, [x1, #0x2b]
    // 0x1276814: DecompressPointer r0
    //     0x1276814: add             x0, x0, HEAP, lsl #32
    // 0x1276818: mov             x2, x0
    // 0x127681c: ldur            x0, [fp, #-0x18]
    // 0x1276820: stur            x2, [fp, #-0x10]
    // 0x1276824: r17 = 5058
    //     0x1276824: mov             x17, #0x13c2
    // 0x1276828: cmp             x0, x17
    // 0x127682c: b.ne            #0x1276844
    // 0x1276830: ldr             x3, [fp, #0x18]
    // 0x1276834: LoadField: r1 = r3->field_2b
    //     0x1276834: ldur            w1, [x3, #0x2b]
    // 0x1276838: DecompressPointer r1
    //     0x1276838: add             x1, x1, HEAP, lsl #32
    // 0x127683c: mov             x0, x2
    // 0x1276840: b               #0x12768bc
    // 0x1276844: ldr             x3, [fp, #0x18]
    // 0x1276848: r17 = 5059
    //     0x1276848: mov             x17, #0x13c3
    // 0x127684c: cmp             x0, x17
    // 0x1276850: b.eq            #0x1276ed0
    // 0x1276854: r17 = 5060
    //     0x1276854: mov             x17, #0x13c4
    // 0x1276858: cmp             x0, x17
    // 0x127685c: b.ne            #0x1276894
    // 0x1276860: mov             x1, x3
    // 0x1276864: LoadField: r0 = r1->field_53
    //     0x1276864: ldur            w0, [x1, #0x53]
    // 0x1276868: DecompressPointer r0
    //     0x1276868: add             x0, x0, HEAP, lsl #32
    // 0x127686c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1276870: cmp             w0, w16
    // 0x1276874: b.ne            #0x1276884
    // 0x1276878: r2 = _textTheme
    //     0x1276878: add             x2, PP, #0x26, lsl #12  ; [pp+0x260c8] Field <_TabsPrimaryDefaultsM3@780014024._textTheme@780014024>: late final (offset: 0x54)
    //     0x127687c: ldr             x2, [x2, #0xc8]
    // 0x1276880: r0 = InitLateFinalInstanceField()
    //     0x1276880: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1276884: LoadField: r1 = r0->field_27
    //     0x1276884: ldur            w1, [x0, #0x27]
    // 0x1276888: DecompressPointer r1
    //     0x1276888: add             x1, x1, HEAP, lsl #32
    // 0x127688c: ldur            x0, [fp, #-0x10]
    // 0x1276890: b               #0x12768bc
    // 0x1276894: mov             x0, x3
    // 0x1276898: LoadField: r1 = r0->field_4b
    //     0x1276898: ldur            w1, [x0, #0x4b]
    // 0x127689c: DecompressPointer r1
    //     0x127689c: add             x1, x1, HEAP, lsl #32
    // 0x12768a0: r0 = of()
    //     0x12768a0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x12768a4: LoadField: r1 = r0->field_83
    //     0x12768a4: ldur            w1, [x0, #0x83]
    // 0x12768a8: DecompressPointer r1
    //     0x12768a8: add             x1, x1, HEAP, lsl #32
    // 0x12768ac: LoadField: r0 = r1->field_2b
    //     0x12768ac: ldur            w0, [x1, #0x2b]
    // 0x12768b0: DecompressPointer r0
    //     0x12768b0: add             x0, x0, HEAP, lsl #32
    // 0x12768b4: mov             x1, x0
    // 0x12768b8: ldur            x0, [fp, #-0x10]
    // 0x12768bc: r2 = LoadClassIdInstr(r0)
    //     0x12768bc: ldur            x2, [x0, #-1]
    //     0x12768c0: ubfx            x2, x2, #0xc, #0x14
    // 0x12768c4: stp             x1, x0, [SP]
    // 0x12768c8: mov             x0, x2
    // 0x12768cc: mov             lr, x0
    // 0x12768d0: ldr             lr, [x21, lr, lsl #3]
    // 0x12768d4: blr             lr
    // 0x12768d8: tbnz            w0, #4, #0x1276ca0
    // 0x12768dc: ldur            x0, [fp, #-8]
    // 0x12768e0: r17 = 5058
    //     0x12768e0: mov             x17, #0x13c2
    // 0x12768e4: cmp             x0, x17
    // 0x12768e8: b.eq            #0x1276994
    // 0x12768ec: r17 = 5059
    //     0x12768ec: mov             x17, #0x13c3
    // 0x12768f0: cmp             x0, x17
    // 0x12768f4: b.ne            #0x1276940
    // 0x12768f8: ldr             x1, [fp, #0x10]
    // 0x12768fc: r1 = 1
    //     0x12768fc: mov             x1, #1
    // 0x1276900: r0 = AllocateContext()
    //     0x1276900: bl              #0x13de838  ; AllocateContextStub
    // 0x1276904: mov             x1, x0
    // 0x1276908: ldr             x0, [fp, #0x10]
    // 0x127690c: StoreField: r1->field_f = r0
    //     0x127690c: stur            w0, [x1, #0xf]
    // 0x1276910: mov             x2, x1
    // 0x1276914: r1 = Function '<anonymous closure>':.
    //     0x1276914: add             x1, PP, #0x26, lsl #12  ; [pp+0x260d0] AnonymousClosure: (0xe005e0), of [package:flutter/src/material/tabs.dart] _TabsSecondaryDefaultsM3
    //     0x1276918: ldr             x1, [x1, #0xd0]
    // 0x127691c: r0 = AllocateClosure()
    //     0x127691c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1276920: r16 = <Color?>
    //     0x1276920: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1276924: ldr             x16, [x16, #0xa40]
    // 0x1276928: stp             x0, x16, [SP]
    // 0x127692c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x127692c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1276930: r0 = resolveWith()
    //     0x1276930: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1276934: mov             x2, x0
    // 0x1276938: ldr             x1, [fp, #0x10]
    // 0x127693c: b               #0x12769a4
    // 0x1276940: r17 = 5060
    //     0x1276940: mov             x17, #0x13c4
    // 0x1276944: cmp             x0, x17
    // 0x1276948: b.ne            #0x1276994
    // 0x127694c: ldr             x1, [fp, #0x10]
    // 0x1276950: r1 = 1
    //     0x1276950: mov             x1, #1
    // 0x1276954: r0 = AllocateContext()
    //     0x1276954: bl              #0x13de838  ; AllocateContextStub
    // 0x1276958: mov             x1, x0
    // 0x127695c: ldr             x0, [fp, #0x10]
    // 0x1276960: StoreField: r1->field_f = r0
    //     0x1276960: stur            w0, [x1, #0xf]
    // 0x1276964: mov             x2, x1
    // 0x1276968: r1 = Function '<anonymous closure>':.
    //     0x1276968: add             x1, PP, #0x26, lsl #12  ; [pp+0x260d8] AnonymousClosure: (0xe00204), of [package:flutter/src/material/tabs.dart] _TabsPrimaryDefaultsM3
    //     0x127696c: ldr             x1, [x1, #0xd8]
    // 0x1276970: r0 = AllocateClosure()
    //     0x1276970: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1276974: r16 = <Color?>
    //     0x1276974: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1276978: ldr             x16, [x16, #0xa40]
    // 0x127697c: stp             x0, x16, [SP]
    // 0x1276980: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1276980: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1276984: r0 = resolveWith()
    //     0x1276984: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1276988: mov             x2, x0
    // 0x127698c: ldr             x1, [fp, #0x10]
    // 0x1276990: b               #0x12769a4
    // 0x1276994: ldr             x1, [fp, #0x10]
    // 0x1276998: LoadField: r0 = r1->field_2f
    //     0x1276998: ldur            w0, [x1, #0x2f]
    // 0x127699c: DecompressPointer r0
    //     0x127699c: add             x0, x0, HEAP, lsl #32
    // 0x12769a0: mov             x2, x0
    // 0x12769a4: ldur            x0, [fp, #-0x18]
    // 0x12769a8: stur            x2, [fp, #-0x10]
    // 0x12769ac: r17 = 5058
    //     0x12769ac: mov             x17, #0x13c2
    // 0x12769b0: cmp             x0, x17
    // 0x12769b4: b.eq            #0x1276a60
    // 0x12769b8: r17 = 5059
    //     0x12769b8: mov             x17, #0x13c3
    // 0x12769bc: cmp             x0, x17
    // 0x12769c0: b.ne            #0x1276a0c
    // 0x12769c4: ldr             x3, [fp, #0x18]
    // 0x12769c8: r1 = 1
    //     0x12769c8: mov             x1, #1
    // 0x12769cc: r0 = AllocateContext()
    //     0x12769cc: bl              #0x13de838  ; AllocateContextStub
    // 0x12769d0: mov             x1, x0
    // 0x12769d4: ldr             x0, [fp, #0x18]
    // 0x12769d8: StoreField: r1->field_f = r0
    //     0x12769d8: stur            w0, [x1, #0xf]
    // 0x12769dc: mov             x2, x1
    // 0x12769e0: r1 = Function '<anonymous closure>':.
    //     0x12769e0: add             x1, PP, #0x26, lsl #12  ; [pp+0x260d0] AnonymousClosure: (0xe005e0), of [package:flutter/src/material/tabs.dart] _TabsSecondaryDefaultsM3
    //     0x12769e4: ldr             x1, [x1, #0xd0]
    // 0x12769e8: r0 = AllocateClosure()
    //     0x12769e8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12769ec: r16 = <Color?>
    //     0x12769ec: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x12769f0: ldr             x16, [x16, #0xa40]
    // 0x12769f4: stp             x0, x16, [SP]
    // 0x12769f8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12769f8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12769fc: r0 = resolveWith()
    //     0x12769fc: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1276a00: mov             x2, x0
    // 0x1276a04: ldr             x0, [fp, #0x18]
    // 0x1276a08: b               #0x1276a70
    // 0x1276a0c: r17 = 5060
    //     0x1276a0c: mov             x17, #0x13c4
    // 0x1276a10: cmp             x0, x17
    // 0x1276a14: b.ne            #0x1276a60
    // 0x1276a18: ldr             x1, [fp, #0x18]
    // 0x1276a1c: r1 = 1
    //     0x1276a1c: mov             x1, #1
    // 0x1276a20: r0 = AllocateContext()
    //     0x1276a20: bl              #0x13de838  ; AllocateContextStub
    // 0x1276a24: mov             x1, x0
    // 0x1276a28: ldr             x0, [fp, #0x18]
    // 0x1276a2c: StoreField: r1->field_f = r0
    //     0x1276a2c: stur            w0, [x1, #0xf]
    // 0x1276a30: mov             x2, x1
    // 0x1276a34: r1 = Function '<anonymous closure>':.
    //     0x1276a34: add             x1, PP, #0x26, lsl #12  ; [pp+0x260d8] AnonymousClosure: (0xe00204), of [package:flutter/src/material/tabs.dart] _TabsPrimaryDefaultsM3
    //     0x1276a38: ldr             x1, [x1, #0xd8]
    // 0x1276a3c: r0 = AllocateClosure()
    //     0x1276a3c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1276a40: r16 = <Color?>
    //     0x1276a40: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1276a44: ldr             x16, [x16, #0xa40]
    // 0x1276a48: stp             x0, x16, [SP]
    // 0x1276a4c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1276a4c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1276a50: r0 = resolveWith()
    //     0x1276a50: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1276a54: mov             x2, x0
    // 0x1276a58: ldr             x0, [fp, #0x18]
    // 0x1276a5c: b               #0x1276a70
    // 0x1276a60: ldr             x0, [fp, #0x18]
    // 0x1276a64: LoadField: r1 = r0->field_2f
    //     0x1276a64: ldur            w1, [x0, #0x2f]
    // 0x1276a68: DecompressPointer r1
    //     0x1276a68: add             x1, x1, HEAP, lsl #32
    // 0x1276a6c: mov             x2, x1
    // 0x1276a70: ldur            x1, [fp, #-0x10]
    // 0x1276a74: cmp             w1, w2
    // 0x1276a78: b.ne            #0x1276ca0
    // 0x1276a7c: ldur            x2, [fp, #-8]
    // 0x1276a80: r17 = 5058
    //     0x1276a80: mov             x17, #0x13c2
    // 0x1276a84: cmp             x2, x17
    // 0x1276a88: b.ne            #0x1276aa0
    // 0x1276a8c: ldr             x3, [fp, #0x10]
    // 0x1276a90: LoadField: r1 = r3->field_33
    //     0x1276a90: ldur            w1, [x3, #0x33]
    // 0x1276a94: DecompressPointer r1
    //     0x1276a94: add             x1, x1, HEAP, lsl #32
    // 0x1276a98: mov             x2, x1
    // 0x1276a9c: b               #0x1276af4
    // 0x1276aa0: ldr             x3, [fp, #0x10]
    // 0x1276aa4: r17 = 5059
    //     0x1276aa4: mov             x17, #0x13c3
    // 0x1276aa8: cmp             x2, x17
    // 0x1276aac: b.eq            #0x1276f04
    // 0x1276ab0: r17 = 5060
    //     0x1276ab0: mov             x17, #0x13c4
    // 0x1276ab4: cmp             x2, x17
    // 0x1276ab8: b.ne            #0x1276ad8
    // 0x1276abc: LoadField: r1 = r3->field_4b
    //     0x1276abc: ldur            w1, [x3, #0x4b]
    // 0x1276ac0: DecompressPointer r1
    //     0x1276ac0: add             x1, x1, HEAP, lsl #32
    // 0x1276ac4: r0 = of()
    //     0x1276ac4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1276ac8: LoadField: r1 = r0->field_2b
    //     0x1276ac8: ldur            w1, [x0, #0x2b]
    // 0x1276acc: DecompressPointer r1
    //     0x1276acc: add             x1, x1, HEAP, lsl #32
    // 0x1276ad0: mov             x2, x1
    // 0x1276ad4: b               #0x1276af4
    // 0x1276ad8: mov             x0, x3
    // 0x1276adc: LoadField: r1 = r0->field_4b
    //     0x1276adc: ldur            w1, [x0, #0x4b]
    // 0x1276ae0: DecompressPointer r1
    //     0x1276ae0: add             x1, x1, HEAP, lsl #32
    // 0x1276ae4: r0 = of()
    //     0x1276ae4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1276ae8: LoadField: r1 = r0->field_2b
    //     0x1276ae8: ldur            w1, [x0, #0x2b]
    // 0x1276aec: DecompressPointer r1
    //     0x1276aec: add             x1, x1, HEAP, lsl #32
    // 0x1276af0: mov             x2, x1
    // 0x1276af4: ldur            x0, [fp, #-0x18]
    // 0x1276af8: stur            x2, [fp, #-0x10]
    // 0x1276afc: r17 = 5058
    //     0x1276afc: mov             x17, #0x13c2
    // 0x1276b00: cmp             x0, x17
    // 0x1276b04: b.ne            #0x1276b1c
    // 0x1276b08: ldr             x3, [fp, #0x18]
    // 0x1276b0c: LoadField: r1 = r3->field_33
    //     0x1276b0c: ldur            w1, [x3, #0x33]
    // 0x1276b10: DecompressPointer r1
    //     0x1276b10: add             x1, x1, HEAP, lsl #32
    // 0x1276b14: mov             x0, x2
    // 0x1276b18: b               #0x1276b70
    // 0x1276b1c: ldr             x3, [fp, #0x18]
    // 0x1276b20: r17 = 5059
    //     0x1276b20: mov             x17, #0x13c3
    // 0x1276b24: cmp             x0, x17
    // 0x1276b28: b.eq            #0x1276f10
    // 0x1276b2c: r17 = 5060
    //     0x1276b2c: mov             x17, #0x13c4
    // 0x1276b30: cmp             x0, x17
    // 0x1276b34: b.ne            #0x1276b54
    // 0x1276b38: LoadField: r1 = r3->field_4b
    //     0x1276b38: ldur            w1, [x3, #0x4b]
    // 0x1276b3c: DecompressPointer r1
    //     0x1276b3c: add             x1, x1, HEAP, lsl #32
    // 0x1276b40: r0 = of()
    //     0x1276b40: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1276b44: LoadField: r1 = r0->field_2b
    //     0x1276b44: ldur            w1, [x0, #0x2b]
    // 0x1276b48: DecompressPointer r1
    //     0x1276b48: add             x1, x1, HEAP, lsl #32
    // 0x1276b4c: ldur            x0, [fp, #-0x10]
    // 0x1276b50: b               #0x1276b70
    // 0x1276b54: mov             x0, x3
    // 0x1276b58: LoadField: r1 = r0->field_4b
    //     0x1276b58: ldur            w1, [x0, #0x4b]
    // 0x1276b5c: DecompressPointer r1
    //     0x1276b5c: add             x1, x1, HEAP, lsl #32
    // 0x1276b60: r0 = of()
    //     0x1276b60: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1276b64: LoadField: r1 = r0->field_2b
    //     0x1276b64: ldur            w1, [x0, #0x2b]
    // 0x1276b68: DecompressPointer r1
    //     0x1276b68: add             x1, x1, HEAP, lsl #32
    // 0x1276b6c: ldur            x0, [fp, #-0x10]
    // 0x1276b70: r2 = LoadClassIdInstr(r0)
    //     0x1276b70: ldur            x2, [x0, #-1]
    //     0x1276b74: ubfx            x2, x2, #0xc, #0x14
    // 0x1276b78: stp             x1, x0, [SP]
    // 0x1276b7c: mov             x0, x2
    // 0x1276b80: mov             lr, x0
    // 0x1276b84: ldr             lr, [x21, lr, lsl #3]
    // 0x1276b88: blr             lr
    // 0x1276b8c: tbnz            w0, #4, #0x1276ca0
    // 0x1276b90: ldur            x0, [fp, #-8]
    // 0x1276b94: r17 = 5058
    //     0x1276b94: mov             x17, #0x13c2
    // 0x1276b98: cmp             x0, x17
    // 0x1276b9c: b.ne            #0x1276bb4
    // 0x1276ba0: ldr             x1, [fp, #0x10]
    // 0x1276ba4: LoadField: r0 = r1->field_3b
    //     0x1276ba4: ldur            w0, [x1, #0x3b]
    // 0x1276ba8: DecompressPointer r0
    //     0x1276ba8: add             x0, x0, HEAP, lsl #32
    // 0x1276bac: mov             x1, x0
    // 0x1276bb0: b               #0x1276c14
    // 0x1276bb4: ldr             x1, [fp, #0x10]
    // 0x1276bb8: r17 = 5059
    //     0x1276bb8: mov             x17, #0x13c3
    // 0x1276bbc: cmp             x0, x17
    // 0x1276bc0: b.ne            #0x1276bf4
    // 0x1276bc4: LoadField: r0 = r1->field_57
    //     0x1276bc4: ldur            w0, [x1, #0x57]
    // 0x1276bc8: DecompressPointer r0
    //     0x1276bc8: add             x0, x0, HEAP, lsl #32
    // 0x1276bcc: r16 = true
    //     0x1276bcc: add             x16, NULL, #0x20  ; true
    // 0x1276bd0: cmp             w0, w16
    // 0x1276bd4: b.ne            #0x1276be4
    // 0x1276bd8: r0 = Instance_TabAlignment
    //     0x1276bd8: add             x0, PP, #0x26, lsl #12  ; [pp+0x260e0] Obj!TabAlignment@12c4cc1
    //     0x1276bdc: ldr             x0, [x0, #0xe0]
    // 0x1276be0: b               #0x1276bec
    // 0x1276be4: r0 = Instance_TabAlignment
    //     0x1276be4: add             x0, PP, #0x26, lsl #12  ; [pp+0x260e8] Obj!TabAlignment@12c4c81
    //     0x1276be8: ldr             x0, [x0, #0xe8]
    // 0x1276bec: mov             x1, x0
    // 0x1276bf0: b               #0x1276c14
    // 0x1276bf4: r17 = 5060
    //     0x1276bf4: mov             x17, #0x13c4
    // 0x1276bf8: cmp             x0, x17
    // 0x1276bfc: b.ne            #0x1276c0c
    // 0x1276c00: r1 = Instance_TabAlignment
    //     0x1276c00: add             x1, PP, #0x26, lsl #12  ; [pp+0x260e8] Obj!TabAlignment@12c4c81
    //     0x1276c04: ldr             x1, [x1, #0xe8]
    // 0x1276c08: b               #0x1276c14
    // 0x1276c0c: r1 = Instance_TabAlignment
    //     0x1276c0c: add             x1, PP, #0x26, lsl #12  ; [pp+0x260e8] Obj!TabAlignment@12c4c81
    //     0x1276c10: ldr             x1, [x1, #0xe8]
    // 0x1276c14: ldur            x0, [fp, #-0x18]
    // 0x1276c18: r17 = 5058
    //     0x1276c18: mov             x17, #0x13c2
    // 0x1276c1c: cmp             x0, x17
    // 0x1276c20: b.ne            #0x1276c34
    // 0x1276c24: ldr             x2, [fp, #0x18]
    // 0x1276c28: LoadField: r0 = r2->field_3b
    //     0x1276c28: ldur            w0, [x2, #0x3b]
    // 0x1276c2c: DecompressPointer r0
    //     0x1276c2c: add             x0, x0, HEAP, lsl #32
    // 0x1276c30: b               #0x1276c90
    // 0x1276c34: ldr             x2, [fp, #0x18]
    // 0x1276c38: r17 = 5059
    //     0x1276c38: mov             x17, #0x13c3
    // 0x1276c3c: cmp             x0, x17
    // 0x1276c40: b.ne            #0x1276c70
    // 0x1276c44: LoadField: r0 = r2->field_57
    //     0x1276c44: ldur            w0, [x2, #0x57]
    // 0x1276c48: DecompressPointer r0
    //     0x1276c48: add             x0, x0, HEAP, lsl #32
    // 0x1276c4c: r16 = true
    //     0x1276c4c: add             x16, NULL, #0x20  ; true
    // 0x1276c50: cmp             w0, w16
    // 0x1276c54: b.ne            #0x1276c64
    // 0x1276c58: r0 = Instance_TabAlignment
    //     0x1276c58: add             x0, PP, #0x26, lsl #12  ; [pp+0x260e0] Obj!TabAlignment@12c4cc1
    //     0x1276c5c: ldr             x0, [x0, #0xe0]
    // 0x1276c60: b               #0x1276c90
    // 0x1276c64: r0 = Instance_TabAlignment
    //     0x1276c64: add             x0, PP, #0x26, lsl #12  ; [pp+0x260e8] Obj!TabAlignment@12c4c81
    //     0x1276c68: ldr             x0, [x0, #0xe8]
    // 0x1276c6c: b               #0x1276c90
    // 0x1276c70: r17 = 5060
    //     0x1276c70: mov             x17, #0x13c4
    // 0x1276c74: cmp             x0, x17
    // 0x1276c78: b.ne            #0x1276c88
    // 0x1276c7c: r0 = Instance_TabAlignment
    //     0x1276c7c: add             x0, PP, #0x26, lsl #12  ; [pp+0x260e8] Obj!TabAlignment@12c4c81
    //     0x1276c80: ldr             x0, [x0, #0xe8]
    // 0x1276c84: b               #0x1276c90
    // 0x1276c88: r0 = Instance_TabAlignment
    //     0x1276c88: add             x0, PP, #0x26, lsl #12  ; [pp+0x260e8] Obj!TabAlignment@12c4c81
    //     0x1276c8c: ldr             x0, [x0, #0xe8]
    // 0x1276c90: cmp             w1, w0
    // 0x1276c94: b.ne            #0x1276ca0
    // 0x1276c98: r0 = true
    //     0x1276c98: add             x0, NULL, #0x20  ; true
    // 0x1276c9c: b               #0x1276ca4
    // 0x1276ca0: r0 = false
    //     0x1276ca0: add             x0, NULL, #0x30  ; false
    // 0x1276ca4: LeaveFrame
    //     0x1276ca4: mov             SP, fp
    //     0x1276ca8: ldp             fp, lr, [SP], #0x10
    // 0x1276cac: ret
    //     0x1276cac: ret             
    // 0x1276cb0: mov             x1, x0
    // 0x1276cb4: LoadField: r0 = r1->field_4f
    //     0x1276cb4: ldur            w0, [x1, #0x4f]
    // 0x1276cb8: DecompressPointer r0
    //     0x1276cb8: add             x0, x0, HEAP, lsl #32
    // 0x1276cbc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1276cc0: cmp             w0, w16
    // 0x1276cc4: b.ne            #0x1276cd4
    // 0x1276cc8: r2 = _colors
    //     0x1276cc8: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x1276ccc: ldr             x2, [x2, #0xf0]
    // 0x1276cd0: r0 = InitLateFinalInstanceField()
    //     0x1276cd0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1276cd4: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1276cd4: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1276cd8: r0 = Throw()
    //     0x1276cd8: bl              #0x13ddb2c  ; ThrowStub
    // 0x1276cdc: brk             #0
    // 0x1276ce0: mov             x1, x2
    // 0x1276ce4: LoadField: r0 = r1->field_4f
    //     0x1276ce4: ldur            w0, [x1, #0x4f]
    // 0x1276ce8: DecompressPointer r0
    //     0x1276ce8: add             x0, x0, HEAP, lsl #32
    // 0x1276cec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1276cf0: cmp             w0, w16
    // 0x1276cf4: b.ne            #0x1276d04
    // 0x1276cf8: r2 = _colors
    //     0x1276cf8: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x1276cfc: ldr             x2, [x2, #0xf0]
    // 0x1276d00: r0 = InitLateFinalInstanceField()
    //     0x1276d00: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1276d04: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1276d04: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1276d08: r0 = Throw()
    //     0x1276d08: bl              #0x13ddb2c  ; ThrowStub
    // 0x1276d0c: brk             #0
    // 0x1276d10: mov             x1, x2
    // 0x1276d14: LoadField: r0 = r1->field_4f
    //     0x1276d14: ldur            w0, [x1, #0x4f]
    // 0x1276d18: DecompressPointer r0
    //     0x1276d18: add             x0, x0, HEAP, lsl #32
    // 0x1276d1c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1276d20: cmp             w0, w16
    // 0x1276d24: b.ne            #0x1276d34
    // 0x1276d28: r2 = _colors
    //     0x1276d28: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x1276d2c: ldr             x2, [x2, #0xf0]
    // 0x1276d30: r0 = InitLateFinalInstanceField()
    //     0x1276d30: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1276d34: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1276d34: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1276d38: r0 = Throw()
    //     0x1276d38: bl              #0x13ddb2c  ; ThrowStub
    // 0x1276d3c: brk             #0
    // 0x1276d40: ldr             x2, [fp, #0x18]
    // 0x1276d44: mov             x1, x2
    // 0x1276d48: LoadField: r0 = r1->field_4f
    //     0x1276d48: ldur            w0, [x1, #0x4f]
    // 0x1276d4c: DecompressPointer r0
    //     0x1276d4c: add             x0, x0, HEAP, lsl #32
    // 0x1276d50: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1276d54: cmp             w0, w16
    // 0x1276d58: b.ne            #0x1276d68
    // 0x1276d5c: r2 = _colors
    //     0x1276d5c: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x1276d60: ldr             x2, [x2, #0xf0]
    // 0x1276d64: r0 = InitLateFinalInstanceField()
    //     0x1276d64: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1276d68: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1276d68: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1276d6c: r0 = Throw()
    //     0x1276d6c: bl              #0x13ddb2c  ; ThrowStub
    // 0x1276d70: brk             #0
    // 0x1276d74: mov             x1, x2
    // 0x1276d78: LoadField: r0 = r1->field_4f
    //     0x1276d78: ldur            w0, [x1, #0x4f]
    // 0x1276d7c: DecompressPointer r0
    //     0x1276d7c: add             x0, x0, HEAP, lsl #32
    // 0x1276d80: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1276d84: cmp             w0, w16
    // 0x1276d88: b.ne            #0x1276d98
    // 0x1276d8c: r2 = _colors
    //     0x1276d8c: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x1276d90: ldr             x2, [x2, #0xf0]
    // 0x1276d94: r0 = InitLateFinalInstanceField()
    //     0x1276d94: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1276d98: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1276d98: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1276d9c: r0 = Throw()
    //     0x1276d9c: bl              #0x13ddb2c  ; ThrowStub
    // 0x1276da0: brk             #0
    // 0x1276da4: mov             x2, x3
    // 0x1276da8: mov             x1, x2
    // 0x1276dac: LoadField: r0 = r1->field_4f
    //     0x1276dac: ldur            w0, [x1, #0x4f]
    // 0x1276db0: DecompressPointer r0
    //     0x1276db0: add             x0, x0, HEAP, lsl #32
    // 0x1276db4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1276db8: cmp             w0, w16
    // 0x1276dbc: b.ne            #0x1276dcc
    // 0x1276dc0: r2 = _colors
    //     0x1276dc0: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x1276dc4: ldr             x2, [x2, #0xf0]
    // 0x1276dc8: r0 = InitLateFinalInstanceField()
    //     0x1276dc8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1276dcc: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1276dcc: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1276dd0: r0 = Throw()
    //     0x1276dd0: bl              #0x13ddb2c  ; ThrowStub
    // 0x1276dd4: brk             #0
    // 0x1276dd8: mov             x1, x2
    // 0x1276ddc: LoadField: r0 = r1->field_53
    //     0x1276ddc: ldur            w0, [x1, #0x53]
    // 0x1276de0: DecompressPointer r0
    //     0x1276de0: add             x0, x0, HEAP, lsl #32
    // 0x1276de4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1276de8: cmp             w0, w16
    // 0x1276dec: b.ne            #0x1276dfc
    // 0x1276df0: r2 = _textTheme
    //     0x1276df0: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f8] Field <_TabsSecondaryDefaultsM3@780014024._textTheme@780014024>: late final (offset: 0x54)
    //     0x1276df4: ldr             x2, [x2, #0xf8]
    // 0x1276df8: r0 = InitLateFinalInstanceField()
    //     0x1276df8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1276dfc: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1276dfc: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1276e00: r0 = Throw()
    //     0x1276e00: bl              #0x13ddb2c  ; ThrowStub
    // 0x1276e04: brk             #0
    // 0x1276e08: mov             x2, x3
    // 0x1276e0c: mov             x1, x2
    // 0x1276e10: LoadField: r0 = r1->field_53
    //     0x1276e10: ldur            w0, [x1, #0x53]
    // 0x1276e14: DecompressPointer r0
    //     0x1276e14: add             x0, x0, HEAP, lsl #32
    // 0x1276e18: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1276e1c: cmp             w0, w16
    // 0x1276e20: b.ne            #0x1276e30
    // 0x1276e24: r2 = _textTheme
    //     0x1276e24: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f8] Field <_TabsSecondaryDefaultsM3@780014024._textTheme@780014024>: late final (offset: 0x54)
    //     0x1276e28: ldr             x2, [x2, #0xf8]
    // 0x1276e2c: r0 = InitLateFinalInstanceField()
    //     0x1276e2c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1276e30: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1276e30: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1276e34: r0 = Throw()
    //     0x1276e34: bl              #0x13ddb2c  ; ThrowStub
    // 0x1276e38: brk             #0
    // 0x1276e3c: ldr             x1, [fp, #0x10]
    // 0x1276e40: LoadField: r0 = r1->field_4f
    //     0x1276e40: ldur            w0, [x1, #0x4f]
    // 0x1276e44: DecompressPointer r0
    //     0x1276e44: add             x0, x0, HEAP, lsl #32
    // 0x1276e48: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1276e4c: cmp             w0, w16
    // 0x1276e50: b.ne            #0x1276e60
    // 0x1276e54: r2 = _colors
    //     0x1276e54: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x1276e58: ldr             x2, [x2, #0xf0]
    // 0x1276e5c: r0 = InitLateFinalInstanceField()
    //     0x1276e5c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1276e60: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1276e60: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1276e64: r0 = Throw()
    //     0x1276e64: bl              #0x13ddb2c  ; ThrowStub
    // 0x1276e68: brk             #0
    // 0x1276e6c: ldr             x2, [fp, #0x18]
    // 0x1276e70: mov             x1, x2
    // 0x1276e74: LoadField: r0 = r1->field_4f
    //     0x1276e74: ldur            w0, [x1, #0x4f]
    // 0x1276e78: DecompressPointer r0
    //     0x1276e78: add             x0, x0, HEAP, lsl #32
    // 0x1276e7c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1276e80: cmp             w0, w16
    // 0x1276e84: b.ne            #0x1276e94
    // 0x1276e88: r2 = _colors
    //     0x1276e88: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f0] Field <_TabsSecondaryDefaultsM3@780014024._colors@780014024>: late final (offset: 0x50)
    //     0x1276e8c: ldr             x2, [x2, #0xf0]
    // 0x1276e90: r0 = InitLateFinalInstanceField()
    //     0x1276e90: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1276e94: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1276e94: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1276e98: r0 = Throw()
    //     0x1276e98: bl              #0x13ddb2c  ; ThrowStub
    // 0x1276e9c: brk             #0
    // 0x1276ea0: mov             x1, x2
    // 0x1276ea4: LoadField: r0 = r1->field_53
    //     0x1276ea4: ldur            w0, [x1, #0x53]
    // 0x1276ea8: DecompressPointer r0
    //     0x1276ea8: add             x0, x0, HEAP, lsl #32
    // 0x1276eac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1276eb0: cmp             w0, w16
    // 0x1276eb4: b.ne            #0x1276ec4
    // 0x1276eb8: r2 = _textTheme
    //     0x1276eb8: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f8] Field <_TabsSecondaryDefaultsM3@780014024._textTheme@780014024>: late final (offset: 0x54)
    //     0x1276ebc: ldr             x2, [x2, #0xf8]
    // 0x1276ec0: r0 = InitLateFinalInstanceField()
    //     0x1276ec0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1276ec4: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1276ec4: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1276ec8: r0 = Throw()
    //     0x1276ec8: bl              #0x13ddb2c  ; ThrowStub
    // 0x1276ecc: brk             #0
    // 0x1276ed0: mov             x2, x3
    // 0x1276ed4: mov             x1, x2
    // 0x1276ed8: LoadField: r0 = r1->field_53
    //     0x1276ed8: ldur            w0, [x1, #0x53]
    // 0x1276edc: DecompressPointer r0
    //     0x1276edc: add             x0, x0, HEAP, lsl #32
    // 0x1276ee0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1276ee4: cmp             w0, w16
    // 0x1276ee8: b.ne            #0x1276ef8
    // 0x1276eec: r2 = _textTheme
    //     0x1276eec: add             x2, PP, #0x26, lsl #12  ; [pp+0x260f8] Field <_TabsSecondaryDefaultsM3@780014024._textTheme@780014024>: late final (offset: 0x54)
    //     0x1276ef0: ldr             x2, [x2, #0xf8]
    // 0x1276ef4: r0 = InitLateFinalInstanceField()
    //     0x1276ef4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1276ef8: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1276ef8: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1276efc: r0 = Throw()
    //     0x1276efc: bl              #0x13ddb2c  ; ThrowStub
    // 0x1276f00: brk             #0
    // 0x1276f04: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1276f04: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1276f08: r0 = Throw()
    //     0x1276f08: bl              #0x13ddb2c  ; ThrowStub
    // 0x1276f0c: brk             #0
    // 0x1276f10: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1276f10: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1276f14: r0 = Throw()
    //     0x1276f14: bl              #0x13ddb2c  ; ThrowStub
    // 0x1276f18: brk             #0
    // 0x1276f1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1276f1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1276f20: b               #0x1275e48
    // 0x1276f24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1276f24: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1276f28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1276f28: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6856, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class TabBarTheme extends _MixinApplication8&InheritedTheme&Diagnosticable {

  static _ of(/* No info */) {
    // ** addr: 0xdffc38, size: 0x5c
    // 0xdffc38: EnterFrame
    //     0xdffc38: stp             fp, lr, [SP, #-0x10]!
    //     0xdffc3c: mov             fp, SP
    // 0xdffc40: AllocStack(0x18)
    //     0xdffc40: sub             SP, SP, #0x18
    // 0xdffc44: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xdffc44: stur            x1, [fp, #-8]
    // 0xdffc48: CheckStackOverflow
    //     0xdffc48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdffc4c: cmp             SP, x16
    //     0xdffc50: b.ls            #0xdffc8c
    // 0xdffc54: r16 = <TabBarTheme>
    //     0xdffc54: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c678] TypeArguments: <TabBarTheme>
    //     0xdffc58: ldr             x16, [x16, #0x678]
    // 0xdffc5c: stp             x1, x16, [SP]
    // 0xdffc60: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdffc60: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdffc64: r0 = dependOnInheritedWidgetOfExactType()
    //     0xdffc64: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xdffc68: ldur            x1, [fp, #-8]
    // 0xdffc6c: r0 = of()
    //     0xdffc6c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdffc70: r17 = 303
    //     0xdffc70: mov             x17, #0x12f
    // 0xdffc74: ldr             w1, [x0, x17]
    // 0xdffc78: DecompressPointer r1
    //     0xdffc78: add             x1, x1, HEAP, lsl #32
    // 0xdffc7c: mov             x0, x1
    // 0xdffc80: LeaveFrame
    //     0xdffc80: mov             SP, fp
    //     0xdffc84: ldp             fp, lr, [SP], #0x10
    // 0xdffc88: ret
    //     0xdffc88: ret             
    // 0xdffc8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdffc8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdffc90: b               #0xdffc54
  }
}
