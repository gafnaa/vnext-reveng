// lib: , url: package:flutter/src/material/material.dart

// class id: 1048912, size: 0x8
class :: {
}

// class id: 3003, size: 0x8, field offset: 0x8
abstract class MaterialInkController extends Object {
}

// class id: 3036, size: 0x14, field offset: 0x8
abstract class InkFeature extends Object {

  static _ _getPaintTransform(/* No info */) {
    // ** addr: 0xc17b7c, size: 0x500
    // 0xc17b7c: EnterFrame
    //     0xc17b7c: stp             fp, lr, [SP, #-0x10]!
    //     0xc17b80: mov             fp, SP
    // 0xc17b84: AllocStack(0x40)
    //     0xc17b84: sub             SP, SP, #0x40
    // 0xc17b88: r0 = 2
    //     0xc17b88: mov             x0, #2
    // 0xc17b8c: mov             x4, x1
    // 0xc17b90: mov             x3, x2
    // 0xc17b94: stur            x1, [fp, #-8]
    // 0xc17b98: stur            x2, [fp, #-0x10]
    // 0xc17b9c: CheckStackOverflow
    //     0xc17b9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc17ba0: cmp             SP, x16
    //     0xc17ba4: b.ls            #0xc1804c
    // 0xc17ba8: mov             x2, x0
    // 0xc17bac: r1 = Null
    //     0xc17bac: mov             x1, NULL
    // 0xc17bb0: r0 = AllocateArray()
    //     0xc17bb0: bl              #0x13df928  ; AllocateArrayStub
    // 0xc17bb4: mov             x2, x0
    // 0xc17bb8: ldur            x0, [fp, #-8]
    // 0xc17bbc: stur            x2, [fp, #-0x18]
    // 0xc17bc0: StoreField: r2->field_f = r0
    //     0xc17bc0: stur            w0, [x2, #0xf]
    // 0xc17bc4: r1 = <RenderObject>
    //     0xc17bc4: ldr             x1, [PP, #0x2a40]  ; [pp+0x2a40] TypeArguments: <RenderObject>
    // 0xc17bc8: r0 = AllocateGrowableArray()
    //     0xc17bc8: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xc17bcc: mov             x3, x0
    // 0xc17bd0: ldur            x0, [fp, #-0x18]
    // 0xc17bd4: stur            x3, [fp, #-0x20]
    // 0xc17bd8: StoreField: r3->field_f = r0
    //     0xc17bd8: stur            w0, [x3, #0xf]
    // 0xc17bdc: r0 = 2
    //     0xc17bdc: mov             x0, #2
    // 0xc17be0: StoreField: r3->field_b = r0
    //     0xc17be0: stur            w0, [x3, #0xb]
    // 0xc17be4: mov             x2, x0
    // 0xc17be8: r1 = Null
    //     0xc17be8: mov             x1, NULL
    // 0xc17bec: r0 = AllocateArray()
    //     0xc17bec: bl              #0x13df928  ; AllocateArrayStub
    // 0xc17bf0: mov             x2, x0
    // 0xc17bf4: ldur            x0, [fp, #-0x10]
    // 0xc17bf8: stur            x2, [fp, #-0x18]
    // 0xc17bfc: StoreField: r2->field_f = r0
    //     0xc17bfc: stur            w0, [x2, #0xf]
    // 0xc17c00: r1 = <RenderObject>
    //     0xc17c00: ldr             x1, [PP, #0x2a40]  ; [pp+0x2a40] TypeArguments: <RenderObject>
    // 0xc17c04: r0 = AllocateGrowableArray()
    //     0xc17c04: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xc17c08: mov             x2, x0
    // 0xc17c0c: ldur            x0, [fp, #-0x18]
    // 0xc17c10: stur            x2, [fp, #-0x38]
    // 0xc17c14: StoreField: r2->field_f = r0
    //     0xc17c14: stur            w0, [x2, #0xf]
    // 0xc17c18: r0 = 2
    //     0xc17c18: mov             x0, #2
    // 0xc17c1c: StoreField: r2->field_b = r0
    //     0xc17c1c: stur            w0, [x2, #0xb]
    // 0xc17c20: ldur            x5, [fp, #-8]
    // 0xc17c24: ldur            x4, [fp, #-0x10]
    // 0xc17c28: ldur            x3, [fp, #-0x20]
    // 0xc17c2c: stur            x5, [fp, #-8]
    // 0xc17c30: stur            x4, [fp, #-0x10]
    // 0xc17c34: CheckStackOverflow
    //     0xc17c34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc17c38: cmp             SP, x16
    //     0xc17c3c: b.ls            #0xc18054
    // 0xc17c40: cmp             w5, w4
    // 0xc17c44: b.eq            #0xc17e78
    // 0xc17c48: LoadField: r6 = r5->field_b
    //     0xc17c48: ldur            x6, [x5, #0xb]
    // 0xc17c4c: stur            x6, [fp, #-0x30]
    // 0xc17c50: LoadField: r7 = r4->field_b
    //     0xc17c50: ldur            x7, [x4, #0xb]
    // 0xc17c54: stur            x7, [fp, #-0x28]
    // 0xc17c58: cmp             x6, x7
    // 0xc17c5c: b.lt            #0xc17d54
    // 0xc17c60: r0 = LoadClassIdInstr(r5)
    //     0xc17c60: ldur            x0, [x5, #-1]
    //     0xc17c64: ubfx            x0, x0, #0xc, #0x14
    // 0xc17c68: mov             x1, x5
    // 0xc17c6c: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0xc17c6c: mov             x17, #0xfc0
    //     0xc17c70: movk            x17, #1, lsl #16
    //     0xc17c74: add             lr, x0, x17
    //     0xc17c78: ldr             lr, [x21, lr, lsl #3]
    //     0xc17c7c: blr             lr
    // 0xc17c80: mov             x3, x0
    // 0xc17c84: stur            x3, [fp, #-0x18]
    // 0xc17c88: r0 = LoadClassIdInstr(r3)
    //     0xc17c88: ldur            x0, [x3, #-1]
    //     0xc17c8c: ubfx            x0, x0, #0xc, #0x14
    // 0xc17c90: r17 = -4679
    //     0xc17c90: mov             x17, #-0x1247
    // 0xc17c94: add             x16, x0, x17
    // 0xc17c98: cmp             x16, #0x128
    // 0xc17c9c: b.hi            #0xc17d44
    // 0xc17ca0: r0 = LoadClassIdInstr(r3)
    //     0xc17ca0: ldur            x0, [x3, #-1]
    //     0xc17ca4: ubfx            x0, x0, #0xc, #0x14
    // 0xc17ca8: mov             x1, x3
    // 0xc17cac: ldur            x2, [fp, #-8]
    // 0xc17cb0: r0 = GDT[cid_x0 + 0xffd6]()
    //     0xc17cb0: mov             x17, #0xffd6
    //     0xc17cb4: add             lr, x0, x17
    //     0xc17cb8: ldr             lr, [x21, lr, lsl #3]
    //     0xc17cbc: blr             lr
    // 0xc17cc0: tbnz            w0, #4, #0xc17d44
    // 0xc17cc4: ldur            x0, [fp, #-0x20]
    // 0xc17cc8: LoadField: r1 = r0->field_b
    //     0xc17cc8: ldur            w1, [x0, #0xb]
    // 0xc17ccc: LoadField: r2 = r0->field_f
    //     0xc17ccc: ldur            w2, [x0, #0xf]
    // 0xc17cd0: DecompressPointer r2
    //     0xc17cd0: add             x2, x2, HEAP, lsl #32
    // 0xc17cd4: LoadField: r3 = r2->field_b
    //     0xc17cd4: ldur            w3, [x2, #0xb]
    // 0xc17cd8: r2 = LoadInt32Instr(r1)
    //     0xc17cd8: sbfx            x2, x1, #1, #0x1f
    // 0xc17cdc: stur            x2, [fp, #-0x40]
    // 0xc17ce0: r1 = LoadInt32Instr(r3)
    //     0xc17ce0: sbfx            x1, x3, #1, #0x1f
    // 0xc17ce4: cmp             x2, x1
    // 0xc17ce8: b.ne            #0xc17cf4
    // 0xc17cec: mov             x1, x0
    // 0xc17cf0: r0 = _growToNextCapacity()
    //     0xc17cf0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xc17cf4: ldur            x2, [fp, #-0x20]
    // 0xc17cf8: ldur            x3, [fp, #-0x40]
    // 0xc17cfc: add             x0, x3, #1
    // 0xc17d00: lsl             x1, x0, #1
    // 0xc17d04: StoreField: r2->field_b = r1
    //     0xc17d04: stur            w1, [x2, #0xb]
    // 0xc17d08: LoadField: r1 = r2->field_f
    //     0xc17d08: ldur            w1, [x2, #0xf]
    // 0xc17d0c: DecompressPointer r1
    //     0xc17d0c: add             x1, x1, HEAP, lsl #32
    // 0xc17d10: ldur            x0, [fp, #-0x18]
    // 0xc17d14: ArrayStore: r1[r3] = r0  ; List_4
    //     0xc17d14: add             x25, x1, x3, lsl #2
    //     0xc17d18: add             x25, x25, #0xf
    //     0xc17d1c: str             w0, [x25]
    //     0xc17d20: tbz             w0, #0, #0xc17d3c
    //     0xc17d24: ldurb           w16, [x1, #-1]
    //     0xc17d28: ldurb           w17, [x0, #-1]
    //     0xc17d2c: and             x16, x17, x16, lsr #2
    //     0xc17d30: tst             x16, HEAP, lsr #32
    //     0xc17d34: b.eq            #0xc17d3c
    //     0xc17d38: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xc17d3c: ldur            x5, [fp, #-0x18]
    // 0xc17d40: b               #0xc17d5c
    // 0xc17d44: r0 = Null
    //     0xc17d44: mov             x0, NULL
    // 0xc17d48: LeaveFrame
    //     0xc17d48: mov             SP, fp
    //     0xc17d4c: ldp             fp, lr, [SP], #0x10
    // 0xc17d50: ret
    //     0xc17d50: ret             
    // 0xc17d54: mov             x2, x3
    // 0xc17d58: ldur            x5, [fp, #-8]
    // 0xc17d5c: ldur            x0, [fp, #-0x30]
    // 0xc17d60: ldur            x1, [fp, #-0x28]
    // 0xc17d64: stur            x5, [fp, #-8]
    // 0xc17d68: cmp             x0, x1
    // 0xc17d6c: b.gt            #0xc17e68
    // 0xc17d70: ldur            x3, [fp, #-0x10]
    // 0xc17d74: r0 = LoadClassIdInstr(r3)
    //     0xc17d74: ldur            x0, [x3, #-1]
    //     0xc17d78: ubfx            x0, x0, #0xc, #0x14
    // 0xc17d7c: mov             x1, x3
    // 0xc17d80: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0xc17d80: mov             x17, #0xfc0
    //     0xc17d84: movk            x17, #1, lsl #16
    //     0xc17d88: add             lr, x0, x17
    //     0xc17d8c: ldr             lr, [x21, lr, lsl #3]
    //     0xc17d90: blr             lr
    // 0xc17d94: mov             x3, x0
    // 0xc17d98: stur            x3, [fp, #-0x18]
    // 0xc17d9c: r0 = LoadClassIdInstr(r3)
    //     0xc17d9c: ldur            x0, [x3, #-1]
    //     0xc17da0: ubfx            x0, x0, #0xc, #0x14
    // 0xc17da4: r17 = -4679
    //     0xc17da4: mov             x17, #-0x1247
    // 0xc17da8: add             x16, x0, x17
    // 0xc17dac: cmp             x16, #0x128
    // 0xc17db0: b.hi            #0xc17e58
    // 0xc17db4: r0 = LoadClassIdInstr(r3)
    //     0xc17db4: ldur            x0, [x3, #-1]
    //     0xc17db8: ubfx            x0, x0, #0xc, #0x14
    // 0xc17dbc: mov             x1, x3
    // 0xc17dc0: ldur            x2, [fp, #-0x10]
    // 0xc17dc4: r0 = GDT[cid_x0 + 0xffd6]()
    //     0xc17dc4: mov             x17, #0xffd6
    //     0xc17dc8: add             lr, x0, x17
    //     0xc17dcc: ldr             lr, [x21, lr, lsl #3]
    //     0xc17dd0: blr             lr
    // 0xc17dd4: tbnz            w0, #4, #0xc17e58
    // 0xc17dd8: ldur            x0, [fp, #-0x38]
    // 0xc17ddc: LoadField: r1 = r0->field_b
    //     0xc17ddc: ldur            w1, [x0, #0xb]
    // 0xc17de0: LoadField: r2 = r0->field_f
    //     0xc17de0: ldur            w2, [x0, #0xf]
    // 0xc17de4: DecompressPointer r2
    //     0xc17de4: add             x2, x2, HEAP, lsl #32
    // 0xc17de8: LoadField: r3 = r2->field_b
    //     0xc17de8: ldur            w3, [x2, #0xb]
    // 0xc17dec: r2 = LoadInt32Instr(r1)
    //     0xc17dec: sbfx            x2, x1, #1, #0x1f
    // 0xc17df0: stur            x2, [fp, #-0x28]
    // 0xc17df4: r1 = LoadInt32Instr(r3)
    //     0xc17df4: sbfx            x1, x3, #1, #0x1f
    // 0xc17df8: cmp             x2, x1
    // 0xc17dfc: b.ne            #0xc17e08
    // 0xc17e00: mov             x1, x0
    // 0xc17e04: r0 = _growToNextCapacity()
    //     0xc17e04: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xc17e08: ldur            x2, [fp, #-0x38]
    // 0xc17e0c: ldur            x3, [fp, #-0x28]
    // 0xc17e10: add             x0, x3, #1
    // 0xc17e14: lsl             x1, x0, #1
    // 0xc17e18: StoreField: r2->field_b = r1
    //     0xc17e18: stur            w1, [x2, #0xb]
    // 0xc17e1c: LoadField: r1 = r2->field_f
    //     0xc17e1c: ldur            w1, [x2, #0xf]
    // 0xc17e20: DecompressPointer r1
    //     0xc17e20: add             x1, x1, HEAP, lsl #32
    // 0xc17e24: ldur            x0, [fp, #-0x18]
    // 0xc17e28: ArrayStore: r1[r3] = r0  ; List_4
    //     0xc17e28: add             x25, x1, x3, lsl #2
    //     0xc17e2c: add             x25, x25, #0xf
    //     0xc17e30: str             w0, [x25]
    //     0xc17e34: tbz             w0, #0, #0xc17e50
    //     0xc17e38: ldurb           w16, [x1, #-1]
    //     0xc17e3c: ldurb           w17, [x0, #-1]
    //     0xc17e40: and             x16, x17, x16, lsr #2
    //     0xc17e44: tst             x16, HEAP, lsr #32
    //     0xc17e48: b.eq            #0xc17e50
    //     0xc17e4c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xc17e50: ldur            x4, [fp, #-0x18]
    // 0xc17e54: b               #0xc17e70
    // 0xc17e58: r0 = Null
    //     0xc17e58: mov             x0, NULL
    // 0xc17e5c: LeaveFrame
    //     0xc17e5c: mov             SP, fp
    //     0xc17e60: ldp             fp, lr, [SP], #0x10
    // 0xc17e64: ret
    //     0xc17e64: ret             
    // 0xc17e68: ldur            x2, [fp, #-0x38]
    // 0xc17e6c: ldur            x4, [fp, #-0x10]
    // 0xc17e70: ldur            x5, [fp, #-8]
    // 0xc17e74: b               #0xc17c28
    // 0xc17e78: r0 = Matrix4()
    //     0xc17e78: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xc17e7c: r4 = 32
    //     0xc17e7c: mov             x4, #0x20
    // 0xc17e80: stur            x0, [fp, #-8]
    // 0xc17e84: r0 = AllocateFloat64Array()
    //     0xc17e84: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0xc17e88: mov             x1, x0
    // 0xc17e8c: ldur            x0, [fp, #-8]
    // 0xc17e90: StoreField: r0->field_7 = r1
    //     0xc17e90: stur            w1, [x0, #7]
    // 0xc17e94: mov             x1, x0
    // 0xc17e98: r0 = setIdentity()
    //     0xc17e98: bl              #0x836d10  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0xc17e9c: r0 = Matrix4()
    //     0xc17e9c: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xc17ea0: r4 = 32
    //     0xc17ea0: mov             x4, #0x20
    // 0xc17ea4: stur            x0, [fp, #-0x10]
    // 0xc17ea8: r0 = AllocateFloat64Array()
    //     0xc17ea8: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0xc17eac: mov             x1, x0
    // 0xc17eb0: ldur            x0, [fp, #-0x10]
    // 0xc17eb4: StoreField: r0->field_7 = r1
    //     0xc17eb4: stur            w1, [x0, #7]
    // 0xc17eb8: mov             x1, x0
    // 0xc17ebc: r0 = setIdentity()
    //     0xc17ebc: bl              #0x836d10  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0xc17ec0: ldur            x4, [fp, #-0x38]
    // 0xc17ec4: LoadField: r0 = r4->field_b
    //     0xc17ec4: ldur            w0, [x4, #0xb]
    // 0xc17ec8: r1 = LoadInt32Instr(r0)
    //     0xc17ec8: sbfx            x1, x0, #1, #0x1f
    // 0xc17ecc: sub             x0, x1, #1
    // 0xc17ed0: mov             x2, x0
    // 0xc17ed4: CheckStackOverflow
    //     0xc17ed4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc17ed8: cmp             SP, x16
    //     0xc17edc: b.ls            #0xc1805c
    // 0xc17ee0: cmp             x2, #0
    // 0xc17ee4: b.le            #0xc17f68
    // 0xc17ee8: LoadField: r0 = r4->field_b
    //     0xc17ee8: ldur            w0, [x4, #0xb]
    // 0xc17eec: r3 = LoadInt32Instr(r0)
    //     0xc17eec: sbfx            x3, x0, #1, #0x1f
    // 0xc17ef0: mov             x0, x3
    // 0xc17ef4: mov             x1, x2
    // 0xc17ef8: cmp             x1, x0
    // 0xc17efc: b.hs            #0xc18064
    // 0xc17f00: LoadField: r5 = r4->field_f
    //     0xc17f00: ldur            w5, [x4, #0xf]
    // 0xc17f04: DecompressPointer r5
    //     0xc17f04: add             x5, x5, HEAP, lsl #32
    // 0xc17f08: ArrayLoad: r6 = r5[r2]  ; Unknown_4
    //     0xc17f08: add             x16, x5, x2, lsl #2
    //     0xc17f0c: ldur            w6, [x16, #0xf]
    // 0xc17f10: DecompressPointer r6
    //     0xc17f10: add             x6, x6, HEAP, lsl #32
    // 0xc17f14: sub             x7, x2, #1
    // 0xc17f18: mov             x0, x3
    // 0xc17f1c: mov             x1, x7
    // 0xc17f20: stur            x7, [fp, #-0x28]
    // 0xc17f24: cmp             x1, x0
    // 0xc17f28: b.hs            #0xc18068
    // 0xc17f2c: ArrayLoad: r2 = r5[r7]  ; Unknown_4
    //     0xc17f2c: add             x16, x5, x7, lsl #2
    //     0xc17f30: ldur            w2, [x16, #0xf]
    // 0xc17f34: DecompressPointer r2
    //     0xc17f34: add             x2, x2, HEAP, lsl #32
    // 0xc17f38: r0 = LoadClassIdInstr(r6)
    //     0xc17f38: ldur            x0, [x6, #-1]
    //     0xc17f3c: ubfx            x0, x0, #0xc, #0x14
    // 0xc17f40: mov             x1, x6
    // 0xc17f44: ldur            x3, [fp, #-8]
    // 0xc17f48: r0 = GDT[cid_x0 + 0x10462]()
    //     0xc17f48: mov             x17, #0x462
    //     0xc17f4c: movk            x17, #1, lsl #16
    //     0xc17f50: add             lr, x0, x17
    //     0xc17f54: ldr             lr, [x21, lr, lsl #3]
    //     0xc17f58: blr             lr
    // 0xc17f5c: ldur            x2, [fp, #-0x28]
    // 0xc17f60: ldur            x4, [fp, #-0x38]
    // 0xc17f64: b               #0xc17ed4
    // 0xc17f68: ldur            x4, [fp, #-0x20]
    // 0xc17f6c: LoadField: r0 = r4->field_b
    //     0xc17f6c: ldur            w0, [x4, #0xb]
    // 0xc17f70: r1 = LoadInt32Instr(r0)
    //     0xc17f70: sbfx            x1, x0, #1, #0x1f
    // 0xc17f74: sub             x0, x1, #1
    // 0xc17f78: mov             x2, x0
    // 0xc17f7c: CheckStackOverflow
    //     0xc17f7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc17f80: cmp             SP, x16
    //     0xc17f84: b.ls            #0xc1806c
    // 0xc17f88: cmp             x2, #0
    // 0xc17f8c: b.le            #0xc18010
    // 0xc17f90: LoadField: r0 = r4->field_b
    //     0xc17f90: ldur            w0, [x4, #0xb]
    // 0xc17f94: r3 = LoadInt32Instr(r0)
    //     0xc17f94: sbfx            x3, x0, #1, #0x1f
    // 0xc17f98: mov             x0, x3
    // 0xc17f9c: mov             x1, x2
    // 0xc17fa0: cmp             x1, x0
    // 0xc17fa4: b.hs            #0xc18074
    // 0xc17fa8: LoadField: r5 = r4->field_f
    //     0xc17fa8: ldur            w5, [x4, #0xf]
    // 0xc17fac: DecompressPointer r5
    //     0xc17fac: add             x5, x5, HEAP, lsl #32
    // 0xc17fb0: ArrayLoad: r6 = r5[r2]  ; Unknown_4
    //     0xc17fb0: add             x16, x5, x2, lsl #2
    //     0xc17fb4: ldur            w6, [x16, #0xf]
    // 0xc17fb8: DecompressPointer r6
    //     0xc17fb8: add             x6, x6, HEAP, lsl #32
    // 0xc17fbc: sub             x7, x2, #1
    // 0xc17fc0: mov             x0, x3
    // 0xc17fc4: mov             x1, x7
    // 0xc17fc8: stur            x7, [fp, #-0x28]
    // 0xc17fcc: cmp             x1, x0
    // 0xc17fd0: b.hs            #0xc18078
    // 0xc17fd4: ArrayLoad: r2 = r5[r7]  ; Unknown_4
    //     0xc17fd4: add             x16, x5, x7, lsl #2
    //     0xc17fd8: ldur            w2, [x16, #0xf]
    // 0xc17fdc: DecompressPointer r2
    //     0xc17fdc: add             x2, x2, HEAP, lsl #32
    // 0xc17fe0: r0 = LoadClassIdInstr(r6)
    //     0xc17fe0: ldur            x0, [x6, #-1]
    //     0xc17fe4: ubfx            x0, x0, #0xc, #0x14
    // 0xc17fe8: mov             x1, x6
    // 0xc17fec: ldur            x3, [fp, #-0x10]
    // 0xc17ff0: r0 = GDT[cid_x0 + 0x10462]()
    //     0xc17ff0: mov             x17, #0x462
    //     0xc17ff4: movk            x17, #1, lsl #16
    //     0xc17ff8: add             lr, x0, x17
    //     0xc17ffc: ldr             lr, [x21, lr, lsl #3]
    //     0xc18000: blr             lr
    // 0xc18004: ldur            x2, [fp, #-0x28]
    // 0xc18008: ldur            x4, [fp, #-0x20]
    // 0xc1800c: b               #0xc17f7c
    // 0xc18010: ldur            x1, [fp, #-0x10]
    // 0xc18014: r0 = invert()
    //     0xc18014: bl              #0x857b2c  ; [package:vector_math/vector_math_64.dart] Matrix4::invert
    // 0xc18018: mov             v1.16b, v0.16b
    // 0xc1801c: d0 = 0.000000
    //     0xc1801c: eor             v0.16b, v0.16b, v0.16b
    // 0xc18020: fcmp            d1, d0
    // 0xc18024: b.eq            #0xc1803c
    // 0xc18028: ldur            x1, [fp, #-0x10]
    // 0xc1802c: ldur            x2, [fp, #-8]
    // 0xc18030: r0 = multiply()
    //     0xc18030: bl              #0x857738  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0xc18034: ldur            x0, [fp, #-0x10]
    // 0xc18038: b               #0xc18040
    // 0xc1803c: r0 = Null
    //     0xc1803c: mov             x0, NULL
    // 0xc18040: LeaveFrame
    //     0xc18040: mov             SP, fp
    //     0xc18044: ldp             fp, lr, [SP], #0x10
    // 0xc18048: ret
    //     0xc18048: ret             
    // 0xc1804c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1804c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc18050: b               #0xc17ba8
    // 0xc18054: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc18054: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc18058: b               #0xc17c40
    // 0xc1805c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1805c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc18060: b               #0xc17ee0
    // 0xc18064: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc18064: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xc18068: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc18068: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xc1806c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1806c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc18070: b               #0xc17f88
    // 0xc18074: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc18074: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xc18078: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc18078: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0xf786a8, size: 0x74
    // 0xf786a8: EnterFrame
    //     0xf786a8: stp             fp, lr, [SP, #-0x10]!
    //     0xf786ac: mov             fp, SP
    // 0xf786b0: AllocStack(0x10)
    //     0xf786b0: sub             SP, SP, #0x10
    // 0xf786b4: SetupParameters(InkFeature this /* r1 => r0, fp-0x8 */)
    //     0xf786b4: mov             x0, x1
    //     0xf786b8: stur            x1, [fp, #-8]
    // 0xf786bc: CheckStackOverflow
    //     0xf786bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf786c0: cmp             SP, x16
    //     0xf786c4: b.ls            #0xf78710
    // 0xf786c8: LoadField: r1 = r0->field_7
    //     0xf786c8: ldur            w1, [x0, #7]
    // 0xf786cc: DecompressPointer r1
    //     0xf786cc: add             x1, x1, HEAP, lsl #32
    // 0xf786d0: mov             x2, x0
    // 0xf786d4: r0 = _removeFeature()
    //     0xf786d4: bl              #0xf7871c  ; [package:flutter/src/material/material.dart] _RenderInkFeatures::_removeFeature
    // 0xf786d8: ldur            x0, [fp, #-8]
    // 0xf786dc: LoadField: r1 = r0->field_f
    //     0xf786dc: ldur            w1, [x0, #0xf]
    // 0xf786e0: DecompressPointer r1
    //     0xf786e0: add             x1, x1, HEAP, lsl #32
    // 0xf786e4: cmp             w1, NULL
    // 0xf786e8: b.eq            #0xf78718
    // 0xf786ec: str             x1, [SP]
    // 0xf786f0: mov             x0, x1
    // 0xf786f4: ClosureCall
    //     0xf786f4: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xf786f8: ldur            x2, [x0, #0x1f]
    //     0xf786fc: blr             x2
    // 0xf78700: r0 = Null
    //     0xf78700: mov             x0, NULL
    // 0xf78704: LeaveFrame
    //     0xf78704: mov             SP, fp
    //     0xf78708: ldp             fp, lr, [SP], #0x10
    // 0xf7870c: ret
    //     0xf7870c: ret             
    // 0xf78710: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf78710: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf78714: b               #0xf786c8
    // 0xf78718: r0 = NullErrorSharedWithoutFPURegs()
    //     0xf78718: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 3309, size: 0x14, field offset: 0x14
class ShapeBorderTween extends Tween<dynamic> {

  _ lerp(/* No info */) {
    // ** addr: 0x115dfc0, size: 0x40
    // 0x115dfc0: EnterFrame
    //     0x115dfc0: stp             fp, lr, [SP, #-0x10]!
    //     0x115dfc4: mov             fp, SP
    // 0x115dfc8: CheckStackOverflow
    //     0x115dfc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115dfcc: cmp             SP, x16
    //     0x115dfd0: b.ls            #0x115dff8
    // 0x115dfd4: LoadField: r0 = r1->field_b
    //     0x115dfd4: ldur            w0, [x1, #0xb]
    // 0x115dfd8: DecompressPointer r0
    //     0x115dfd8: add             x0, x0, HEAP, lsl #32
    // 0x115dfdc: LoadField: r2 = r1->field_f
    //     0x115dfdc: ldur            w2, [x1, #0xf]
    // 0x115dfe0: DecompressPointer r2
    //     0x115dfe0: add             x2, x2, HEAP, lsl #32
    // 0x115dfe4: mov             x1, x0
    // 0x115dfe8: r0 = lerp()
    //     0x115dfe8: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x115dfec: LeaveFrame
    //     0x115dfec: mov             SP, fp
    //     0x115dff0: ldp             fp, lr, [SP], #0x10
    // 0x115dff4: ret
    //     0x115dff4: ret             
    // 0x115dff8: r0 = StackOverflowSharedWithFPURegs()
    //     0x115dff8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x115dffc: b               #0x115dfd4
  }
}

// class id: 4336, size: 0x14, field offset: 0xc
class _ShapeBorderPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0xb7697c, size: 0xa8
    // 0xb7697c: EnterFrame
    //     0xb7697c: stp             fp, lr, [SP, #-0x10]!
    //     0xb76980: mov             fp, SP
    // 0xb76984: AllocStack(0x20)
    //     0xb76984: sub             SP, SP, #0x20
    // 0xb76988: SetupParameters(_ShapeBorderPainter this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* r3 => r2 */)
    //     0xb76988: mov             x0, x2
    //     0xb7698c: stur            x2, [fp, #-0x18]
    //     0xb76990: mov             x2, x3
    //     0xb76994: mov             x3, x1
    //     0xb76998: stur            x1, [fp, #-0x10]
    // 0xb7699c: CheckStackOverflow
    //     0xb7699c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb769a0: cmp             SP, x16
    //     0xb769a4: b.ls            #0xb76a1c
    // 0xb769a8: LoadField: r4 = r3->field_b
    //     0xb769a8: ldur            w4, [x3, #0xb]
    // 0xb769ac: DecompressPointer r4
    //     0xb769ac: add             x4, x4, HEAP, lsl #32
    // 0xb769b0: stur            x4, [fp, #-8]
    // 0xb769b4: r1 = Instance_Offset
    //     0xb769b4: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xb769b8: r0 = &()
    //     0xb769b8: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xb769bc: mov             x1, x0
    // 0xb769c0: ldur            x0, [fp, #-0x10]
    // 0xb769c4: LoadField: r2 = r0->field_f
    //     0xb769c4: ldur            w2, [x0, #0xf]
    // 0xb769c8: DecompressPointer r2
    //     0xb769c8: add             x2, x2, HEAP, lsl #32
    // 0xb769cc: ldur            x0, [fp, #-8]
    // 0xb769d0: r3 = LoadClassIdInstr(r0)
    //     0xb769d0: ldur            x3, [x0, #-1]
    //     0xb769d4: ubfx            x3, x3, #0xc, #0x14
    // 0xb769d8: str             x2, [SP]
    // 0xb769dc: mov             x16, x1
    // 0xb769e0: mov             x1, x3
    // 0xb769e4: mov             x3, x16
    // 0xb769e8: mov             x16, x0
    // 0xb769ec: mov             x0, x1
    // 0xb769f0: mov             x1, x16
    // 0xb769f4: ldur            x2, [fp, #-0x18]
    // 0xb769f8: r4 = const [0, 0x4, 0x1, 0x3, textDirection, 0x3, null]
    //     0xb769f8: add             x4, PP, #0xa0, lsl #12  ; [pp+0xa0cb8] List(7) [0, 0x4, 0x1, 0x3, "textDirection", 0x3, Null]
    //     0xb769fc: ldr             x4, [x4, #0xcb8]
    // 0xb76a00: r0 = GDT[cid_x0 + -0xe4f]()
    //     0xb76a00: sub             lr, x0, #0xe4f
    //     0xb76a04: ldr             lr, [x21, lr, lsl #3]
    //     0xb76a08: blr             lr
    // 0xb76a0c: r0 = Null
    //     0xb76a0c: mov             x0, NULL
    // 0xb76a10: LeaveFrame
    //     0xb76a10: mov             SP, fp
    //     0xb76a14: ldp             fp, lr, [SP], #0x10
    // 0xb76a18: ret
    //     0xb76a18: ret             
    // 0xb76a1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb76a1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb76a20: b               #0xb769a8
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xb93698, size: 0xb0
    // 0xb93698: EnterFrame
    //     0xb93698: stp             fp, lr, [SP, #-0x10]!
    //     0xb9369c: mov             fp, SP
    // 0xb936a0: AllocStack(0x20)
    //     0xb936a0: sub             SP, SP, #0x20
    // 0xb936a4: SetupParameters(_ShapeBorderPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xb936a4: mov             x4, x1
    //     0xb936a8: mov             x3, x2
    //     0xb936ac: stur            x1, [fp, #-8]
    //     0xb936b0: stur            x2, [fp, #-0x10]
    // 0xb936b4: CheckStackOverflow
    //     0xb936b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb936b8: cmp             SP, x16
    //     0xb936bc: b.ls            #0xb93740
    // 0xb936c0: mov             x0, x3
    // 0xb936c4: r2 = Null
    //     0xb936c4: mov             x2, NULL
    // 0xb936c8: r1 = Null
    //     0xb936c8: mov             x1, NULL
    // 0xb936cc: r4 = 60
    //     0xb936cc: mov             x4, #0x3c
    // 0xb936d0: branchIfSmi(r0, 0xb936dc)
    //     0xb936d0: tbz             w0, #0, #0xb936dc
    // 0xb936d4: r4 = LoadClassIdInstr(r0)
    //     0xb936d4: ldur            x4, [x0, #-1]
    //     0xb936d8: ubfx            x4, x4, #0xc, #0x14
    // 0xb936dc: r17 = 4336
    //     0xb936dc: mov             x17, #0x10f0
    // 0xb936e0: cmp             x4, x17
    // 0xb936e4: b.eq            #0xb936fc
    // 0xb936e8: r8 = _ShapeBorderPainter
    //     0xb936e8: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3ac8] Type: _ShapeBorderPainter
    //     0xb936ec: ldr             x8, [x8, #0xac8]
    // 0xb936f0: r3 = Null
    //     0xb936f0: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3ad0] Null
    //     0xb936f4: ldr             x3, [x3, #0xad0]
    // 0xb936f8: r0 = DefaultTypeTest()
    //     0xb936f8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb936fc: ldur            x0, [fp, #-0x10]
    // 0xb93700: LoadField: r1 = r0->field_b
    //     0xb93700: ldur            w1, [x0, #0xb]
    // 0xb93704: DecompressPointer r1
    //     0xb93704: add             x1, x1, HEAP, lsl #32
    // 0xb93708: ldur            x0, [fp, #-8]
    // 0xb9370c: LoadField: r2 = r0->field_b
    //     0xb9370c: ldur            w2, [x0, #0xb]
    // 0xb93710: DecompressPointer r2
    //     0xb93710: add             x2, x2, HEAP, lsl #32
    // 0xb93714: r0 = LoadClassIdInstr(r1)
    //     0xb93714: ldur            x0, [x1, #-1]
    //     0xb93718: ubfx            x0, x0, #0xc, #0x14
    // 0xb9371c: stp             x2, x1, [SP]
    // 0xb93720: mov             lr, x0
    // 0xb93724: ldr             lr, [x21, lr, lsl #3]
    // 0xb93728: blr             lr
    // 0xb9372c: eor             x1, x0, #0x10
    // 0xb93730: mov             x0, x1
    // 0xb93734: LeaveFrame
    //     0xb93734: mov             SP, fp
    //     0xb93738: ldp             fp, lr, [SP], #0x10
    // 0xb9373c: ret
    //     0xb9373c: ret             
    // 0xb93740: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb93740: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb93744: b               #0xb936c0
  }
}

// class id: 4958, size: 0x64, field offset: 0x54
class _RenderInkFeatures extends RenderProxyBox
    implements MaterialInkController {

  _ paint(/* No info */) {
    // ** addr: 0xc178a8, size: 0x2d4
    // 0xc178a8: EnterFrame
    //     0xc178a8: stp             fp, lr, [SP, #-0x10]!
    //     0xc178ac: mov             fp, SP
    // 0xc178b0: AllocStack(0x58)
    //     0xc178b0: sub             SP, SP, #0x58
    // 0xc178b4: SetupParameters(_RenderInkFeatures this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0xc178b4: mov             x0, x2
    //     0xc178b8: stur            x2, [fp, #-0x18]
    //     0xc178bc: mov             x2, x1
    //     0xc178c0: stur            x1, [fp, #-0x10]
    //     0xc178c4: stur            x3, [fp, #-0x20]
    // 0xc178c8: CheckStackOverflow
    //     0xc178c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc178cc: cmp             SP, x16
    //     0xc178d0: b.ls            #0xc17b60
    // 0xc178d4: LoadField: r4 = r2->field_5f
    //     0xc178d4: ldur            w4, [x2, #0x5f]
    // 0xc178d8: DecompressPointer r4
    //     0xc178d8: add             x4, x4, HEAP, lsl #32
    // 0xc178dc: stur            x4, [fp, #-8]
    // 0xc178e0: cmp             w4, NULL
    // 0xc178e4: b.eq            #0xc17af0
    // 0xc178e8: LoadField: r1 = r4->field_b
    //     0xc178e8: ldur            w1, [x4, #0xb]
    // 0xc178ec: cbz             w1, #0xc17af0
    // 0xc178f0: mov             x1, x0
    // 0xc178f4: r0 = canvas()
    //     0xc178f4: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc178f8: stur            x0, [fp, #-0x30]
    // 0xc178fc: LoadField: r1 = r0->field_7
    //     0xc178fc: ldur            w1, [x0, #7]
    // 0xc17900: DecompressPointer r1
    //     0xc17900: add             x1, x1, HEAP, lsl #32
    // 0xc17904: cmp             w1, NULL
    // 0xc17908: b.eq            #0xc17b68
    // 0xc1790c: LoadField: r2 = r1->field_7
    //     0xc1790c: ldur            x2, [x1, #7]
    // 0xc17910: ldr             x1, [x2]
    // 0xc17914: cbz             x1, #0xc17b10
    // 0xc17918: ldur            x3, [fp, #-0x20]
    // 0xc1791c: mov             x2, x1
    // 0xc17920: stur            x2, [fp, #-0x28]
    // 0xc17924: r1 = <Never>
    //     0xc17924: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc17928: r0 = Pointer()
    //     0xc17928: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc1792c: mov             x1, x0
    // 0xc17930: ldur            x0, [fp, #-0x28]
    // 0xc17934: StoreField: r1->field_7 = r0
    //     0xc17934: stur            x0, [x1, #7]
    // 0xc17938: r0 = _save$Method$FfiNative()
    //     0xc17938: bl              #0xb74adc  ; [dart:ui] _NativeCanvas::_save$Method$FfiNative
    // 0xc1793c: ldur            x3, [fp, #-0x20]
    // 0xc17940: LoadField: d0 = r3->field_7
    //     0xc17940: ldur            d0, [x3, #7]
    // 0xc17944: stur            d0, [fp, #-0x50]
    // 0xc17948: LoadField: d1 = r3->field_f
    //     0xc17948: ldur            d1, [x3, #0xf]
    // 0xc1794c: ldur            x0, [fp, #-0x30]
    // 0xc17950: stur            d1, [fp, #-0x48]
    // 0xc17954: LoadField: r1 = r0->field_7
    //     0xc17954: ldur            w1, [x0, #7]
    // 0xc17958: DecompressPointer r1
    //     0xc17958: add             x1, x1, HEAP, lsl #32
    // 0xc1795c: cmp             w1, NULL
    // 0xc17960: b.eq            #0xc17b6c
    // 0xc17964: LoadField: r2 = r1->field_7
    //     0xc17964: ldur            x2, [x1, #7]
    // 0xc17968: ldr             x1, [x2]
    // 0xc1796c: cbz             x1, #0xc17b20
    // 0xc17970: ldur            x2, [fp, #-8]
    // 0xc17974: mov             x4, x1
    // 0xc17978: stur            x4, [fp, #-0x28]
    // 0xc1797c: r1 = <Never>
    //     0xc1797c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc17980: r0 = Pointer()
    //     0xc17980: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc17984: mov             x1, x0
    // 0xc17988: ldur            x0, [fp, #-0x28]
    // 0xc1798c: StoreField: r1->field_7 = r0
    //     0xc1798c: stur            x0, [x1, #7]
    // 0xc17990: ldur            d0, [fp, #-0x50]
    // 0xc17994: ldur            d1, [fp, #-0x48]
    // 0xc17998: r0 = _translate$Method$FfiNative()
    //     0xc17998: bl              #0xb74a38  ; [dart:ui] _NativeCanvas::_translate$Method$FfiNative
    // 0xc1799c: ldur            x1, [fp, #-0x10]
    // 0xc179a0: r0 = size()
    //     0xc179a0: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc179a4: mov             x2, x0
    // 0xc179a8: r1 = Instance_Offset
    //     0xc179a8: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc179ac: r0 = &()
    //     0xc179ac: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc179b0: ldur            x1, [fp, #-0x30]
    // 0xc179b4: mov             x2, x0
    // 0xc179b8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc179b8: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc179bc: r0 = clipRect()
    //     0xc179bc: bl              #0xb7b380  ; [dart:ui] _NativeCanvas::clipRect
    // 0xc179c0: ldur            x3, [fp, #-8]
    // 0xc179c4: LoadField: r0 = r3->field_b
    //     0xc179c4: ldur            w0, [x3, #0xb]
    // 0xc179c8: r4 = LoadInt32Instr(r0)
    //     0xc179c8: sbfx            x4, x0, #1, #0x1f
    // 0xc179cc: stur            x4, [fp, #-0x40]
    // 0xc179d0: r0 = 0
    //     0xc179d0: mov             x0, #0
    // 0xc179d4: CheckStackOverflow
    //     0xc179d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc179d8: cmp             SP, x16
    //     0xc179dc: b.ls            #0xc17b70
    // 0xc179e0: LoadField: r1 = r3->field_b
    //     0xc179e0: ldur            w1, [x3, #0xb]
    // 0xc179e4: r2 = LoadInt32Instr(r1)
    //     0xc179e4: sbfx            x2, x1, #1, #0x1f
    // 0xc179e8: cmp             x4, x2
    // 0xc179ec: b.ne            #0xc17b40
    // 0xc179f0: cmp             x0, x2
    // 0xc179f4: b.ge            #0xc17ab0
    // 0xc179f8: LoadField: r1 = r3->field_f
    //     0xc179f8: ldur            w1, [x3, #0xf]
    // 0xc179fc: DecompressPointer r1
    //     0xc179fc: add             x1, x1, HEAP, lsl #32
    // 0xc17a00: ArrayLoad: r5 = r1[r0]  ; Unknown_4
    //     0xc17a00: add             x16, x1, x0, lsl #2
    //     0xc17a04: ldur            w5, [x16, #0xf]
    // 0xc17a08: DecompressPointer r5
    //     0xc17a08: add             x5, x5, HEAP, lsl #32
    // 0xc17a0c: stur            x5, [fp, #-0x38]
    // 0xc17a10: add             x6, x0, #1
    // 0xc17a14: stur            x6, [fp, #-0x28]
    // 0xc17a18: cmp             w5, NULL
    // 0xc17a1c: b.ne            #0xc17a5c
    // 0xc17a20: mov             x0, x5
    // 0xc17a24: r2 = Null
    //     0xc17a24: mov             x2, NULL
    // 0xc17a28: r1 = Null
    //     0xc17a28: mov             x1, NULL
    // 0xc17a2c: r4 = 60
    //     0xc17a2c: mov             x4, #0x3c
    // 0xc17a30: branchIfSmi(r0, 0xc17a3c)
    //     0xc17a30: tbz             w0, #0, #0xc17a3c
    // 0xc17a34: r4 = LoadClassIdInstr(r0)
    //     0xc17a34: ldur            x4, [x0, #-1]
    //     0xc17a38: ubfx            x4, x4, #0xc, #0x14
    // 0xc17a3c: sub             x4, x4, #0xbde
    // 0xc17a40: cmp             x4, #4
    // 0xc17a44: b.ls            #0xc17a5c
    // 0xc17a48: r8 = InkFeature
    //     0xc17a48: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3ab0] Type: InkFeature
    //     0xc17a4c: ldr             x8, [x8, #0xab0]
    // 0xc17a50: r3 = Null
    //     0xc17a50: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3ab8] Null
    //     0xc17a54: ldr             x3, [x3, #0xab8]
    // 0xc17a58: r0 = InkFeature()
    //     0xc17a58: bl              #0xc1807c  ; IsType_InkFeature_Stub
    // 0xc17a5c: ldur            x0, [fp, #-0x38]
    // 0xc17a60: LoadField: r1 = r0->field_7
    //     0xc17a60: ldur            w1, [x0, #7]
    // 0xc17a64: DecompressPointer r1
    //     0xc17a64: add             x1, x1, HEAP, lsl #32
    // 0xc17a68: LoadField: r2 = r0->field_b
    //     0xc17a68: ldur            w2, [x0, #0xb]
    // 0xc17a6c: DecompressPointer r2
    //     0xc17a6c: add             x2, x2, HEAP, lsl #32
    // 0xc17a70: r0 = _getPaintTransform()
    //     0xc17a70: bl              #0xc17b7c  ; [package:flutter/src/material/material.dart] InkFeature::_getPaintTransform
    // 0xc17a74: cmp             w0, NULL
    // 0xc17a78: b.eq            #0xc17aa0
    // 0xc17a7c: ldur            x1, [fp, #-0x38]
    // 0xc17a80: r2 = LoadClassIdInstr(r1)
    //     0xc17a80: ldur            x2, [x1, #-1]
    //     0xc17a84: ubfx            x2, x2, #0xc, #0x14
    // 0xc17a88: mov             x3, x0
    // 0xc17a8c: mov             x0, x2
    // 0xc17a90: ldur            x2, [fp, #-0x30]
    // 0xc17a94: r0 = GDT[cid_x0 + -0xd2c]()
    //     0xc17a94: sub             lr, x0, #0xd2c
    //     0xc17a98: ldr             lr, [x21, lr, lsl #3]
    //     0xc17a9c: blr             lr
    // 0xc17aa0: ldur            x0, [fp, #-0x28]
    // 0xc17aa4: ldur            x3, [fp, #-8]
    // 0xc17aa8: ldur            x4, [fp, #-0x40]
    // 0xc17aac: b               #0xc179d4
    // 0xc17ab0: ldur            x0, [fp, #-0x30]
    // 0xc17ab4: LoadField: r1 = r0->field_7
    //     0xc17ab4: ldur            w1, [x0, #7]
    // 0xc17ab8: DecompressPointer r1
    //     0xc17ab8: add             x1, x1, HEAP, lsl #32
    // 0xc17abc: cmp             w1, NULL
    // 0xc17ac0: b.eq            #0xc17b78
    // 0xc17ac4: LoadField: r2 = r1->field_7
    //     0xc17ac4: ldur            x2, [x1, #7]
    // 0xc17ac8: ldr             x1, [x2]
    // 0xc17acc: cbz             x1, #0xc17b30
    // 0xc17ad0: mov             x2, x1
    // 0xc17ad4: stur            x2, [fp, #-0x28]
    // 0xc17ad8: r1 = <Never>
    //     0xc17ad8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc17adc: r0 = Pointer()
    //     0xc17adc: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc17ae0: mov             x1, x0
    // 0xc17ae4: ldur            x0, [fp, #-0x28]
    // 0xc17ae8: StoreField: r1->field_7 = r0
    //     0xc17ae8: stur            x0, [x1, #7]
    // 0xc17aec: r0 = _restore$Method$FfiNative()
    //     0xc17aec: bl              #0xb74908  ; [dart:ui] _NativeCanvas::_restore$Method$FfiNative
    // 0xc17af0: ldur            x1, [fp, #-0x10]
    // 0xc17af4: ldur            x2, [fp, #-0x18]
    // 0xc17af8: ldur            x3, [fp, #-0x20]
    // 0xc17afc: r0 = paint()
    //     0xc17afc: bl              #0xc1faf0  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint
    // 0xc17b00: r0 = Null
    //     0xc17b00: mov             x0, NULL
    // 0xc17b04: LeaveFrame
    //     0xc17b04: mov             SP, fp
    //     0xc17b08: ldp             fp, lr, [SP], #0x10
    // 0xc17b0c: ret
    //     0xc17b0c: ret             
    // 0xc17b10: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc17b10: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc17b14: str             x16, [SP]
    // 0xc17b18: r0 = _throwNew()
    //     0xc17b18: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc17b1c: brk             #0
    // 0xc17b20: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc17b20: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc17b24: str             x16, [SP]
    // 0xc17b28: r0 = _throwNew()
    //     0xc17b28: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc17b2c: brk             #0
    // 0xc17b30: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc17b30: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc17b34: str             x16, [SP]
    // 0xc17b38: r0 = _throwNew()
    //     0xc17b38: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc17b3c: brk             #0
    // 0xc17b40: mov             x0, x3
    // 0xc17b44: r0 = ConcurrentModificationError()
    //     0xc17b44: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xc17b48: mov             x1, x0
    // 0xc17b4c: ldur            x0, [fp, #-8]
    // 0xc17b50: StoreField: r1->field_b = r0
    //     0xc17b50: stur            w0, [x1, #0xb]
    // 0xc17b54: mov             x0, x1
    // 0xc17b58: r0 = Throw()
    //     0xc17b58: bl              #0x13ddb2c  ; ThrowStub
    // 0xc17b5c: brk             #0
    // 0xc17b60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc17b60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc17b64: b               #0xc178d4
    // 0xc17b68: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc17b68: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xc17b6c: r0 = NullErrorSharedWithFPURegs()
    //     0xc17b6c: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xc17b70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc17b70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc17b74: b               #0xc179e0
    // 0xc17b78: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc17b78: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ addInkFeature(/* No info */) {
    // ** addr: 0xd21c40, size: 0x114
    // 0xd21c40: EnterFrame
    //     0xd21c40: stp             fp, lr, [SP, #-0x10]!
    //     0xd21c44: mov             fp, SP
    // 0xd21c48: AllocStack(0x20)
    //     0xd21c48: sub             SP, SP, #0x20
    // 0xd21c4c: SetupParameters(_RenderInkFeatures this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xd21c4c: mov             x3, x1
    //     0xd21c50: mov             x0, x2
    //     0xd21c54: stur            x1, [fp, #-8]
    //     0xd21c58: stur            x2, [fp, #-0x10]
    // 0xd21c5c: CheckStackOverflow
    //     0xd21c5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd21c60: cmp             SP, x16
    //     0xd21c64: b.ls            #0xd21d4c
    // 0xd21c68: LoadField: r1 = r3->field_5f
    //     0xd21c68: ldur            w1, [x3, #0x5f]
    // 0xd21c6c: DecompressPointer r1
    //     0xd21c6c: add             x1, x1, HEAP, lsl #32
    // 0xd21c70: cmp             w1, NULL
    // 0xd21c74: b.ne            #0xd21cb4
    // 0xd21c78: r1 = <InkFeature>
    //     0xd21c78: add             x1, PP, #0x97, lsl #12  ; [pp+0x97688] TypeArguments: <InkFeature>
    //     0xd21c7c: ldr             x1, [x1, #0x688]
    // 0xd21c80: r2 = 0
    //     0xd21c80: mov             x2, #0
    // 0xd21c84: r0 = _GrowableList()
    //     0xd21c84: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd21c88: mov             x1, x0
    // 0xd21c8c: ldur            x2, [fp, #-8]
    // 0xd21c90: StoreField: r2->field_5f = r0
    //     0xd21c90: stur            w0, [x2, #0x5f]
    //     0xd21c94: ldurb           w16, [x2, #-1]
    //     0xd21c98: ldurb           w17, [x0, #-1]
    //     0xd21c9c: and             x16, x17, x16, lsr #2
    //     0xd21ca0: tst             x16, HEAP, lsr #32
    //     0xd21ca4: b.eq            #0xd21cac
    //     0xd21ca8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd21cac: mov             x0, x1
    // 0xd21cb0: b               #0xd21cbc
    // 0xd21cb4: mov             x2, x3
    // 0xd21cb8: mov             x0, x1
    // 0xd21cbc: stur            x0, [fp, #-0x20]
    // 0xd21cc0: LoadField: r1 = r0->field_b
    //     0xd21cc0: ldur            w1, [x0, #0xb]
    // 0xd21cc4: LoadField: r3 = r0->field_f
    //     0xd21cc4: ldur            w3, [x0, #0xf]
    // 0xd21cc8: DecompressPointer r3
    //     0xd21cc8: add             x3, x3, HEAP, lsl #32
    // 0xd21ccc: LoadField: r4 = r3->field_b
    //     0xd21ccc: ldur            w4, [x3, #0xb]
    // 0xd21cd0: r3 = LoadInt32Instr(r1)
    //     0xd21cd0: sbfx            x3, x1, #1, #0x1f
    // 0xd21cd4: stur            x3, [fp, #-0x18]
    // 0xd21cd8: r1 = LoadInt32Instr(r4)
    //     0xd21cd8: sbfx            x1, x4, #1, #0x1f
    // 0xd21cdc: cmp             x3, x1
    // 0xd21ce0: b.ne            #0xd21cec
    // 0xd21ce4: mov             x1, x0
    // 0xd21ce8: r0 = _growToNextCapacity()
    //     0xd21ce8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd21cec: ldur            x2, [fp, #-0x18]
    // 0xd21cf0: ldur            x0, [fp, #-0x20]
    // 0xd21cf4: add             x1, x2, #1
    // 0xd21cf8: lsl             x3, x1, #1
    // 0xd21cfc: StoreField: r0->field_b = r3
    //     0xd21cfc: stur            w3, [x0, #0xb]
    // 0xd21d00: LoadField: r1 = r0->field_f
    //     0xd21d00: ldur            w1, [x0, #0xf]
    // 0xd21d04: DecompressPointer r1
    //     0xd21d04: add             x1, x1, HEAP, lsl #32
    // 0xd21d08: ldur            x0, [fp, #-0x10]
    // 0xd21d0c: ArrayStore: r1[r2] = r0  ; List_4
    //     0xd21d0c: add             x25, x1, x2, lsl #2
    //     0xd21d10: add             x25, x25, #0xf
    //     0xd21d14: str             w0, [x25]
    //     0xd21d18: tbz             w0, #0, #0xd21d34
    //     0xd21d1c: ldurb           w16, [x1, #-1]
    //     0xd21d20: ldurb           w17, [x0, #-1]
    //     0xd21d24: and             x16, x17, x16, lsr #2
    //     0xd21d28: tst             x16, HEAP, lsr #32
    //     0xd21d2c: b.eq            #0xd21d34
    //     0xd21d30: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd21d34: ldur            x1, [fp, #-8]
    // 0xd21d38: r0 = markNeedsPaint()
    //     0xd21d38: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xd21d3c: r0 = Null
    //     0xd21d3c: mov             x0, NULL
    // 0xd21d40: LeaveFrame
    //     0xd21d40: mov             SP, fp
    //     0xd21d44: ldp             fp, lr, [SP], #0x10
    // 0xd21d48: ret
    //     0xd21d48: ret             
    // 0xd21d4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd21d4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd21d50: b               #0xd21c68
  }
  _ _didChangeLayout(/* No info */) {
    // ** addr: 0xd2eb68, size: 0x68
    // 0xd2eb68: EnterFrame
    //     0xd2eb68: stp             fp, lr, [SP, #-0x10]!
    //     0xd2eb6c: mov             fp, SP
    // 0xd2eb70: CheckStackOverflow
    //     0xd2eb70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd2eb74: cmp             SP, x16
    //     0xd2eb78: b.ls            #0xd2ebc8
    // 0xd2eb7c: LoadField: r0 = r1->field_5f
    //     0xd2eb7c: ldur            w0, [x1, #0x5f]
    // 0xd2eb80: DecompressPointer r0
    //     0xd2eb80: add             x0, x0, HEAP, lsl #32
    // 0xd2eb84: cmp             w0, NULL
    // 0xd2eb88: b.ne            #0xd2eb94
    // 0xd2eb8c: r0 = Null
    //     0xd2eb8c: mov             x0, NULL
    // 0xd2eb90: b               #0xd2eba8
    // 0xd2eb94: LoadField: r2 = r0->field_b
    //     0xd2eb94: ldur            w2, [x0, #0xb]
    // 0xd2eb98: cbnz            w2, #0xd2eba4
    // 0xd2eb9c: r0 = false
    //     0xd2eb9c: add             x0, NULL, #0x30  ; false
    // 0xd2eba0: b               #0xd2eba8
    // 0xd2eba4: r0 = true
    //     0xd2eba4: add             x0, NULL, #0x20  ; true
    // 0xd2eba8: cmp             w0, NULL
    // 0xd2ebac: b.eq            #0xd2ebb8
    // 0xd2ebb0: tbnz            w0, #4, #0xd2ebb8
    // 0xd2ebb4: r0 = markNeedsPaint()
    //     0xd2ebb4: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xd2ebb8: r0 = Null
    //     0xd2ebb8: mov             x0, NULL
    // 0xd2ebbc: LeaveFrame
    //     0xd2ebbc: mov             SP, fp
    //     0xd2ebc0: ldp             fp, lr, [SP], #0x10
    // 0xd2ebc4: ret
    //     0xd2ebc4: ret             
    // 0xd2ebc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd2ebc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd2ebcc: b               #0xd2eb7c
  }
  _ _removeFeature(/* No info */) {
    // ** addr: 0xf7871c, size: 0x58
    // 0xf7871c: EnterFrame
    //     0xf7871c: stp             fp, lr, [SP, #-0x10]!
    //     0xf78720: mov             fp, SP
    // 0xf78724: AllocStack(0x8)
    //     0xf78724: sub             SP, SP, #8
    // 0xf78728: SetupParameters(_RenderInkFeatures this /* r1 => r0, fp-0x8 */)
    //     0xf78728: mov             x0, x1
    //     0xf7872c: stur            x1, [fp, #-8]
    // 0xf78730: CheckStackOverflow
    //     0xf78730: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf78734: cmp             SP, x16
    //     0xf78738: b.ls            #0xf78768
    // 0xf7873c: LoadField: r1 = r0->field_5f
    //     0xf7873c: ldur            w1, [x0, #0x5f]
    // 0xf78740: DecompressPointer r1
    //     0xf78740: add             x1, x1, HEAP, lsl #32
    // 0xf78744: cmp             w1, NULL
    // 0xf78748: b.eq            #0xf78770
    // 0xf7874c: r0 = remove()
    //     0xf7874c: bl              #0xa10a64  ; [dart:core] _GrowableList::remove
    // 0xf78750: ldur            x1, [fp, #-8]
    // 0xf78754: r0 = markNeedsPaint()
    //     0xf78754: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xf78758: r0 = Null
    //     0xf78758: mov             x0, NULL
    // 0xf7875c: LeaveFrame
    //     0xf7875c: mov             SP, fp
    //     0xf78760: ldp             fp, lr, [SP], #0x10
    // 0xf78764: ret
    //     0xf78764: ret             
    // 0xf78768: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf78768: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7876c: b               #0xf7873c
    // 0xf78770: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf78770: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _RenderInkFeatures(/* No info */) {
    // ** addr: 0x11cfac0, size: 0xbc
    // 0x11cfac0: EnterFrame
    //     0x11cfac0: stp             fp, lr, [SP, #-0x10]!
    //     0x11cfac4: mov             fp, SP
    // 0x11cfac8: AllocStack(0x8)
    //     0x11cfac8: sub             SP, SP, #8
    // 0x11cfacc: SetupParameters(_RenderInkFeatures this /* r1 => r3, fp-0x8 */, dynamic _ /* r3 => r1 */)
    //     0x11cfacc: stur            x1, [fp, #-8]
    //     0x11cfad0: mov             x16, x3
    //     0x11cfad4: mov             x3, x1
    //     0x11cfad8: mov             x1, x16
    //     0x11cfadc: mov             x0, x5
    // 0x11cfae0: CheckStackOverflow
    //     0x11cfae0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cfae4: cmp             SP, x16
    //     0x11cfae8: b.ls            #0x11cfb74
    // 0x11cfaec: StoreField: r3->field_53 = r0
    //     0x11cfaec: stur            w0, [x3, #0x53]
    //     0x11cfaf0: ldurb           w16, [x3, #-1]
    //     0x11cfaf4: ldurb           w17, [x0, #-1]
    //     0x11cfaf8: and             x16, x17, x16, lsr #2
    //     0x11cfafc: tst             x16, HEAP, lsr #32
    //     0x11cfb00: b.eq            #0x11cfb08
    //     0x11cfb04: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11cfb08: StoreField: r3->field_5b = r2
    //     0x11cfb08: stur            w2, [x3, #0x5b]
    // 0x11cfb0c: mov             x0, x1
    // 0x11cfb10: StoreField: r3->field_57 = r0
    //     0x11cfb10: stur            w0, [x3, #0x57]
    //     0x11cfb14: ldurb           w16, [x3, #-1]
    //     0x11cfb18: ldurb           w17, [x0, #-1]
    //     0x11cfb1c: and             x16, x17, x16, lsr #2
    //     0x11cfb20: tst             x16, HEAP, lsr #32
    //     0x11cfb24: b.eq            #0x11cfb2c
    //     0x11cfb28: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11cfb2c: r0 = _LayoutCacheStorage()
    //     0x11cfb2c: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11cfb30: ldur            x2, [fp, #-8]
    // 0x11cfb34: StoreField: r2->field_47 = r0
    //     0x11cfb34: stur            w0, [x2, #0x47]
    //     0x11cfb38: ldurb           w16, [x2, #-1]
    //     0x11cfb3c: ldurb           w17, [x0, #-1]
    //     0x11cfb40: and             x16, x17, x16, lsr #2
    //     0x11cfb44: tst             x16, HEAP, lsr #32
    //     0x11cfb48: b.eq            #0x11cfb50
    //     0x11cfb4c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11cfb50: mov             x1, x2
    // 0x11cfb54: r0 = RenderObject()
    //     0x11cfb54: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11cfb58: ldur            x1, [fp, #-8]
    // 0x11cfb5c: r2 = Null
    //     0x11cfb5c: mov             x2, NULL
    // 0x11cfb60: r0 = child=()
    //     0x11cfb60: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11cfb64: r0 = Null
    //     0x11cfb64: mov             x0, NULL
    // 0x11cfb68: LeaveFrame
    //     0x11cfb68: mov             SP, fp
    //     0x11cfb6c: ldp             fp, lr, [SP], #0x10
    // 0x11cfb70: ret
    //     0x11cfb70: ret             
    // 0x11cfb74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cfb74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cfb78: b               #0x11cfaec
  }
}

// class id: 5744, size: 0x34, field offset: 0x24
class _MaterialInteriorState extends AnimatedWidgetBaseState<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xd2ebd0, size: 0x270
    // 0xd2ebd0: EnterFrame
    //     0xd2ebd0: stp             fp, lr, [SP, #-0x10]!
    //     0xd2ebd4: mov             fp, SP
    // 0xd2ebd8: AllocStack(0x48)
    //     0xd2ebd8: sub             SP, SP, #0x48
    // 0xd2ebdc: SetupParameters(_MaterialInteriorState this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xd2ebdc: mov             x0, x2
    //     0xd2ebe0: stur            x2, [fp, #-0x18]
    //     0xd2ebe4: mov             x2, x1
    //     0xd2ebe8: stur            x1, [fp, #-0x10]
    // 0xd2ebec: CheckStackOverflow
    //     0xd2ebec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd2ebf0: cmp             SP, x16
    //     0xd2ebf4: b.ls            #0xd2ee18
    // 0xd2ebf8: LoadField: r3 = r2->field_2f
    //     0xd2ebf8: ldur            w3, [x2, #0x2f]
    // 0xd2ebfc: DecompressPointer r3
    //     0xd2ebfc: add             x3, x3, HEAP, lsl #32
    // 0xd2ec00: stur            x3, [fp, #-8]
    // 0xd2ec04: cmp             w3, NULL
    // 0xd2ec08: b.eq            #0xd2ee20
    // 0xd2ec0c: mov             x1, x2
    // 0xd2ec10: LoadField: r0 = r1->field_1f
    //     0xd2ec10: ldur            w0, [x1, #0x1f]
    // 0xd2ec14: DecompressPointer r0
    //     0xd2ec14: add             x0, x0, HEAP, lsl #32
    // 0xd2ec18: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd2ec1c: cmp             w0, w16
    // 0xd2ec20: b.ne            #0xd2ec30
    // 0xd2ec24: r2 = _animation
    //     0xd2ec24: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fc38] Field <ImplicitlyAnimatedWidgetState._animation@99443363>: late (offset: 0x20)
    //     0xd2ec28: ldr             x2, [x2, #0xc38]
    // 0xd2ec2c: r0 = InitLateInstanceField()
    //     0xd2ec2c: bl              #0x13dd948  ; InitLateInstanceFieldStub
    // 0xd2ec30: ldur            x1, [fp, #-8]
    // 0xd2ec34: mov             x2, x0
    // 0xd2ec38: r0 = evaluate()
    //     0xd2ec38: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xd2ec3c: stur            x0, [fp, #-8]
    // 0xd2ec40: cmp             w0, NULL
    // 0xd2ec44: b.eq            #0xd2ee24
    // 0xd2ec48: ldur            x3, [fp, #-0x10]
    // 0xd2ec4c: LoadField: r1 = r3->field_23
    //     0xd2ec4c: ldur            w1, [x3, #0x23]
    // 0xd2ec50: DecompressPointer r1
    //     0xd2ec50: add             x1, x1, HEAP, lsl #32
    // 0xd2ec54: cmp             w1, NULL
    // 0xd2ec58: b.eq            #0xd2ee28
    // 0xd2ec5c: LoadField: r2 = r3->field_1f
    //     0xd2ec5c: ldur            w2, [x3, #0x1f]
    // 0xd2ec60: DecompressPointer r2
    //     0xd2ec60: add             x2, x2, HEAP, lsl #32
    // 0xd2ec64: r0 = evaluate()
    //     0xd2ec64: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xd2ec68: ldur            x1, [fp, #-0x18]
    // 0xd2ec6c: stur            x0, [fp, #-0x20]
    // 0xd2ec70: r0 = of()
    //     0xd2ec70: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd2ec74: LoadField: r1 = r0->field_2f
    //     0xd2ec74: ldur            w1, [x0, #0x2f]
    // 0xd2ec78: DecompressPointer r1
    //     0xd2ec78: add             x1, x1, HEAP, lsl #32
    // 0xd2ec7c: tbnz            w1, #4, #0xd2ece0
    // 0xd2ec80: ldur            x0, [fp, #-0x10]
    // 0xd2ec84: LoadField: r1 = r0->field_b
    //     0xd2ec84: ldur            w1, [x0, #0xb]
    // 0xd2ec88: DecompressPointer r1
    //     0xd2ec88: add             x1, x1, HEAP, lsl #32
    // 0xd2ec8c: cmp             w1, NULL
    // 0xd2ec90: b.eq            #0xd2ee2c
    // 0xd2ec94: LoadField: r3 = r1->field_2f
    //     0xd2ec94: ldur            w3, [x1, #0x2f]
    // 0xd2ec98: DecompressPointer r3
    //     0xd2ec98: add             x3, x3, HEAP, lsl #32
    // 0xd2ec9c: stur            x3, [fp, #-0x28]
    // 0xd2eca0: LoadField: r1 = r0->field_27
    //     0xd2eca0: ldur            w1, [x0, #0x27]
    // 0xd2eca4: DecompressPointer r1
    //     0xd2eca4: add             x1, x1, HEAP, lsl #32
    // 0xd2eca8: cmp             w1, NULL
    // 0xd2ecac: b.ne            #0xd2ecb8
    // 0xd2ecb0: r2 = Null
    //     0xd2ecb0: mov             x2, NULL
    // 0xd2ecb4: b               #0xd2ecc8
    // 0xd2ecb8: LoadField: r2 = r0->field_1f
    //     0xd2ecb8: ldur            w2, [x0, #0x1f]
    // 0xd2ecbc: DecompressPointer r2
    //     0xd2ecbc: add             x2, x2, HEAP, lsl #32
    // 0xd2ecc0: r0 = evaluate()
    //     0xd2ecc0: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xd2ecc4: mov             x2, x0
    // 0xd2ecc8: ldur            x0, [fp, #-0x20]
    // 0xd2eccc: LoadField: d0 = r0->field_7
    //     0xd2eccc: ldur            d0, [x0, #7]
    // 0xd2ecd0: ldur            x1, [fp, #-0x28]
    // 0xd2ecd4: r0 = applySurfaceTint()
    //     0xd2ecd4: bl              #0xd2e910  ; [package:flutter/src/material/elevation_overlay.dart] ElevationOverlay::applySurfaceTint
    // 0xd2ecd8: mov             x5, x0
    // 0xd2ecdc: b               #0xd2ed10
    // 0xd2ece0: ldur            x3, [fp, #-0x10]
    // 0xd2ece4: ldur            x0, [fp, #-0x20]
    // 0xd2ece8: LoadField: r1 = r3->field_b
    //     0xd2ece8: ldur            w1, [x3, #0xb]
    // 0xd2ecec: DecompressPointer r1
    //     0xd2ecec: add             x1, x1, HEAP, lsl #32
    // 0xd2ecf0: cmp             w1, NULL
    // 0xd2ecf4: b.eq            #0xd2ee30
    // 0xd2ecf8: LoadField: r2 = r1->field_2f
    //     0xd2ecf8: ldur            w2, [x1, #0x2f]
    // 0xd2ecfc: DecompressPointer r2
    //     0xd2ecfc: add             x2, x2, HEAP, lsl #32
    // 0xd2ed00: LoadField: d0 = r0->field_7
    //     0xd2ed00: ldur            d0, [x0, #7]
    // 0xd2ed04: ldur            x1, [fp, #-0x18]
    // 0xd2ed08: r0 = applyOverlay()
    //     0xd2ed08: bl              #0xd2e708  ; [package:flutter/src/material/elevation_overlay.dart] ElevationOverlay::applyOverlay
    // 0xd2ed0c: mov             x5, x0
    // 0xd2ed10: ldur            x3, [fp, #-0x10]
    // 0xd2ed14: ldur            x4, [fp, #-8]
    // 0xd2ed18: ldur            x0, [fp, #-0x20]
    // 0xd2ed1c: stur            x5, [fp, #-0x28]
    // 0xd2ed20: LoadField: r1 = r3->field_2b
    //     0xd2ed20: ldur            w1, [x3, #0x2b]
    // 0xd2ed24: DecompressPointer r1
    //     0xd2ed24: add             x1, x1, HEAP, lsl #32
    // 0xd2ed28: cmp             w1, NULL
    // 0xd2ed2c: b.eq            #0xd2ee34
    // 0xd2ed30: LoadField: r2 = r3->field_1f
    //     0xd2ed30: ldur            w2, [x3, #0x1f]
    // 0xd2ed34: DecompressPointer r2
    //     0xd2ed34: add             x2, x2, HEAP, lsl #32
    // 0xd2ed38: r0 = evaluate()
    //     0xd2ed38: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xd2ed3c: stur            x0, [fp, #-0x30]
    // 0xd2ed40: cmp             w0, NULL
    // 0xd2ed44: b.eq            #0xd2ee38
    // 0xd2ed48: ldur            x1, [fp, #-0x18]
    // 0xd2ed4c: r0 = maybeOf()
    //     0xd2ed4c: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xd2ed50: r1 = <Path>
    //     0xd2ed50: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a60] TypeArguments: <Path>
    //     0xd2ed54: ldr             x1, [x1, #0xa60]
    // 0xd2ed58: stur            x0, [fp, #-0x18]
    // 0xd2ed5c: r0 = ShapeBorderClipper()
    //     0xd2ed5c: bl              #0xd2e6cc  ; AllocateShapeBorderClipperStub -> ShapeBorderClipper (size=0x18)
    // 0xd2ed60: mov             x1, x0
    // 0xd2ed64: ldur            x0, [fp, #-8]
    // 0xd2ed68: stur            x1, [fp, #-0x40]
    // 0xd2ed6c: StoreField: r1->field_f = r0
    //     0xd2ed6c: stur            w0, [x1, #0xf]
    // 0xd2ed70: ldur            x2, [fp, #-0x18]
    // 0xd2ed74: StoreField: r1->field_13 = r2
    //     0xd2ed74: stur            w2, [x1, #0x13]
    // 0xd2ed78: ldur            x2, [fp, #-0x10]
    // 0xd2ed7c: LoadField: r3 = r2->field_b
    //     0xd2ed7c: ldur            w3, [x2, #0xb]
    // 0xd2ed80: DecompressPointer r3
    //     0xd2ed80: add             x3, x3, HEAP, lsl #32
    // 0xd2ed84: cmp             w3, NULL
    // 0xd2ed88: b.eq            #0xd2ee3c
    // 0xd2ed8c: LoadField: r2 = r3->field_23
    //     0xd2ed8c: ldur            w2, [x3, #0x23]
    // 0xd2ed90: DecompressPointer r2
    //     0xd2ed90: add             x2, x2, HEAP, lsl #32
    // 0xd2ed94: stur            x2, [fp, #-0x38]
    // 0xd2ed98: LoadField: r4 = r3->field_1f
    //     0xd2ed98: ldur            w4, [x3, #0x1f]
    // 0xd2ed9c: DecompressPointer r4
    //     0xd2ed9c: add             x4, x4, HEAP, lsl #32
    // 0xd2eda0: stur            x4, [fp, #-0x18]
    // 0xd2eda4: ArrayLoad: r5 = r3[0]  ; List_4
    //     0xd2eda4: ldur            w5, [x3, #0x17]
    // 0xd2eda8: DecompressPointer r5
    //     0xd2eda8: add             x5, x5, HEAP, lsl #32
    // 0xd2edac: stur            x5, [fp, #-0x10]
    // 0xd2edb0: r0 = _ShapeBorderPaint()
    //     0xd2edb0: bl              #0xd2e6c0  ; Allocate_ShapeBorderPaintStub -> _ShapeBorderPaint (size=0x18)
    // 0xd2edb4: mov             x1, x0
    // 0xd2edb8: ldur            x0, [fp, #-0x10]
    // 0xd2edbc: stur            x1, [fp, #-0x48]
    // 0xd2edc0: StoreField: r1->field_b = r0
    //     0xd2edc0: stur            w0, [x1, #0xb]
    // 0xd2edc4: ldur            x0, [fp, #-8]
    // 0xd2edc8: StoreField: r1->field_f = r0
    //     0xd2edc8: stur            w0, [x1, #0xf]
    // 0xd2edcc: ldur            x0, [fp, #-0x18]
    // 0xd2edd0: StoreField: r1->field_13 = r0
    //     0xd2edd0: stur            w0, [x1, #0x13]
    // 0xd2edd4: r0 = PhysicalShape()
    //     0xd2edd4: bl              #0xd2ee40  ; AllocatePhysicalShapeStub -> PhysicalShape (size=0x28)
    // 0xd2edd8: ldur            x1, [fp, #-0x40]
    // 0xd2eddc: StoreField: r0->field_f = r1
    //     0xd2eddc: stur            w1, [x0, #0xf]
    // 0xd2ede0: ldur            x1, [fp, #-0x38]
    // 0xd2ede4: StoreField: r0->field_13 = r1
    //     0xd2ede4: stur            w1, [x0, #0x13]
    // 0xd2ede8: ldur            x1, [fp, #-0x20]
    // 0xd2edec: LoadField: d0 = r1->field_7
    //     0xd2edec: ldur            d0, [x1, #7]
    // 0xd2edf0: ArrayStore: r0[0] = d0  ; List_8
    //     0xd2edf0: stur            d0, [x0, #0x17]
    // 0xd2edf4: ldur            x1, [fp, #-0x28]
    // 0xd2edf8: StoreField: r0->field_1f = r1
    //     0xd2edf8: stur            w1, [x0, #0x1f]
    // 0xd2edfc: ldur            x1, [fp, #-0x30]
    // 0xd2ee00: StoreField: r0->field_23 = r1
    //     0xd2ee00: stur            w1, [x0, #0x23]
    // 0xd2ee04: ldur            x1, [fp, #-0x48]
    // 0xd2ee08: StoreField: r0->field_b = r1
    //     0xd2ee08: stur            w1, [x0, #0xb]
    // 0xd2ee0c: LeaveFrame
    //     0xd2ee0c: mov             SP, fp
    //     0xd2ee10: ldp             fp, lr, [SP], #0x10
    // 0xd2ee14: ret
    //     0xd2ee14: ret             
    // 0xd2ee18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd2ee18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd2ee1c: b               #0xd2ebf8
    // 0xd2ee20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2ee20: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2ee24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2ee24: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2ee28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2ee28: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2ee2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2ee2c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2ee30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2ee30: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2ee34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2ee34: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2ee38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2ee38: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2ee3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2ee3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ forEachTween(/* No info */) {
    // ** addr: 0x11937e0, size: 0x29c
    // 0x11937e0: EnterFrame
    //     0x11937e0: stp             fp, lr, [SP, #-0x10]!
    //     0x11937e4: mov             fp, SP
    // 0x11937e8: AllocStack(0x40)
    //     0x11937e8: sub             SP, SP, #0x40
    // 0x11937ec: SetupParameters(_MaterialInteriorState this /* r1 => r3, fp-0x18 */, dynamic _ /* r2 => r0, fp-0x20 */)
    //     0x11937ec: mov             x3, x1
    //     0x11937f0: mov             x0, x2
    //     0x11937f4: stur            x1, [fp, #-0x18]
    //     0x11937f8: stur            x2, [fp, #-0x20]
    // 0x11937fc: CheckStackOverflow
    //     0x11937fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1193800: cmp             SP, x16
    //     0x1193804: b.ls            #0x1193a40
    // 0x1193808: LoadField: r4 = r3->field_23
    //     0x1193808: ldur            w4, [x3, #0x23]
    // 0x119380c: DecompressPointer r4
    //     0x119380c: add             x4, x4, HEAP, lsl #32
    // 0x1193810: stur            x4, [fp, #-0x10]
    // 0x1193814: LoadField: r1 = r3->field_b
    //     0x1193814: ldur            w1, [x3, #0xb]
    // 0x1193818: DecompressPointer r1
    //     0x1193818: add             x1, x1, HEAP, lsl #32
    // 0x119381c: cmp             w1, NULL
    // 0x1193820: b.eq            #0x1193a48
    // 0x1193824: LoadField: d0 = r1->field_27
    //     0x1193824: ldur            d0, [x1, #0x27]
    // 0x1193828: r5 = inline_Allocate_Double()
    //     0x1193828: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x119382c: add             x5, x5, #0x10
    //     0x1193830: cmp             x1, x5
    //     0x1193834: b.ls            #0x1193a4c
    //     0x1193838: str             x5, [THR, #0x60]  ; THR::top
    //     0x119383c: sub             x5, x5, #0xf
    //     0x1193840: mov             x1, #0xe19c
    //     0x1193844: movk            x1, #3, lsl #16
    //     0x1193848: stur            x1, [x5, #-1]
    // 0x119384c: dmb             ishst
    // 0x1193850: StoreField: r5->field_7 = d0
    //     0x1193850: stur            d0, [x5, #7]
    // 0x1193854: stur            x5, [fp, #-8]
    // 0x1193858: r1 = Function '<anonymous closure>':.
    //     0x1193858: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3ae0] AnonymousClosure: (0x1193bb8), in [package:flutter/src/material/material.dart] _MaterialInteriorState::forEachTween (0x11937e0)
    //     0x119385c: ldr             x1, [x1, #0xae0]
    // 0x1193860: r2 = Null
    //     0x1193860: mov             x2, NULL
    // 0x1193864: r0 = AllocateClosure()
    //     0x1193864: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1193868: ldur            x16, [fp, #-0x20]
    // 0x119386c: ldur            lr, [fp, #-0x10]
    // 0x1193870: stp             lr, x16, [SP, #0x10]
    // 0x1193874: ldur            x16, [fp, #-8]
    // 0x1193878: stp             x0, x16, [SP]
    // 0x119387c: ldur            x0, [fp, #-0x20]
    // 0x1193880: ClosureCall
    //     0x1193880: ldr             x4, [PP, #0x9d0]  ; [pp+0x9d0] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0x1193884: ldur            x2, [x0, #0x1f]
    //     0x1193888: blr             x2
    // 0x119388c: ldur            x3, [fp, #-0x18]
    // 0x1193890: StoreField: r3->field_23 = r0
    //     0x1193890: stur            w0, [x3, #0x23]
    //     0x1193894: ldurb           w16, [x3, #-1]
    //     0x1193898: ldurb           w17, [x0, #-1]
    //     0x119389c: and             x16, x17, x16, lsr #2
    //     0x11938a0: tst             x16, HEAP, lsr #32
    //     0x11938a4: b.eq            #0x11938ac
    //     0x11938a8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11938ac: LoadField: r0 = r3->field_2b
    //     0x11938ac: ldur            w0, [x3, #0x2b]
    // 0x11938b0: DecompressPointer r0
    //     0x11938b0: add             x0, x0, HEAP, lsl #32
    // 0x11938b4: stur            x0, [fp, #-0x10]
    // 0x11938b8: LoadField: r1 = r3->field_b
    //     0x11938b8: ldur            w1, [x3, #0xb]
    // 0x11938bc: DecompressPointer r1
    //     0x11938bc: add             x1, x1, HEAP, lsl #32
    // 0x11938c0: cmp             w1, NULL
    // 0x11938c4: b.eq            #0x1193a70
    // 0x11938c8: LoadField: r4 = r1->field_33
    //     0x11938c8: ldur            w4, [x1, #0x33]
    // 0x11938cc: DecompressPointer r4
    //     0x11938cc: add             x4, x4, HEAP, lsl #32
    // 0x11938d0: stur            x4, [fp, #-8]
    // 0x11938d4: r1 = Function '<anonymous closure>':.
    //     0x11938d4: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3ae8] AnonymousClosure: (0x1193b4c), in [package:flutter/src/material/material.dart] _MaterialInteriorState::forEachTween (0x11937e0)
    //     0x11938d8: ldr             x1, [x1, #0xae8]
    // 0x11938dc: r2 = Null
    //     0x11938dc: mov             x2, NULL
    // 0x11938e0: r0 = AllocateClosure()
    //     0x11938e0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11938e4: ldur            x16, [fp, #-0x20]
    // 0x11938e8: ldur            lr, [fp, #-0x10]
    // 0x11938ec: stp             lr, x16, [SP, #0x10]
    // 0x11938f0: ldur            x16, [fp, #-8]
    // 0x11938f4: stp             x0, x16, [SP]
    // 0x11938f8: ldur            x0, [fp, #-0x20]
    // 0x11938fc: ClosureCall
    //     0x11938fc: ldr             x4, [PP, #0x9d0]  ; [pp+0x9d0] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0x1193900: ldur            x2, [x0, #0x1f]
    //     0x1193904: blr             x2
    // 0x1193908: ldur            x3, [fp, #-0x18]
    // 0x119390c: StoreField: r3->field_2b = r0
    //     0x119390c: stur            w0, [x3, #0x2b]
    //     0x1193910: ldurb           w16, [x3, #-1]
    //     0x1193914: ldurb           w17, [x0, #-1]
    //     0x1193918: and             x16, x17, x16, lsr #2
    //     0x119391c: tst             x16, HEAP, lsr #32
    //     0x1193920: b.eq            #0x1193928
    //     0x1193924: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x1193928: LoadField: r0 = r3->field_b
    //     0x1193928: ldur            w0, [x3, #0xb]
    // 0x119392c: DecompressPointer r0
    //     0x119392c: add             x0, x0, HEAP, lsl #32
    // 0x1193930: cmp             w0, NULL
    // 0x1193934: b.eq            #0x1193a74
    // 0x1193938: LoadField: r4 = r0->field_37
    //     0x1193938: ldur            w4, [x0, #0x37]
    // 0x119393c: DecompressPointer r4
    //     0x119393c: add             x4, x4, HEAP, lsl #32
    // 0x1193940: stur            x4, [fp, #-0x10]
    // 0x1193944: cmp             w4, NULL
    // 0x1193948: b.eq            #0x1193990
    // 0x119394c: LoadField: r0 = r3->field_27
    //     0x119394c: ldur            w0, [x3, #0x27]
    // 0x1193950: DecompressPointer r0
    //     0x1193950: add             x0, x0, HEAP, lsl #32
    // 0x1193954: stur            x0, [fp, #-8]
    // 0x1193958: r1 = Function '<anonymous closure>':.
    //     0x1193958: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3af0] AnonymousClosure: (0x1193ae0), in [package:flutter/src/material/material.dart] _MaterialInteriorState::forEachTween (0x11937e0)
    //     0x119395c: ldr             x1, [x1, #0xaf0]
    // 0x1193960: r2 = Null
    //     0x1193960: mov             x2, NULL
    // 0x1193964: r0 = AllocateClosure()
    //     0x1193964: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1193968: ldur            x16, [fp, #-0x20]
    // 0x119396c: ldur            lr, [fp, #-8]
    // 0x1193970: stp             lr, x16, [SP, #0x10]
    // 0x1193974: ldur            x16, [fp, #-0x10]
    // 0x1193978: stp             x0, x16, [SP]
    // 0x119397c: ldur            x0, [fp, #-0x20]
    // 0x1193980: ClosureCall
    //     0x1193980: ldr             x4, [PP, #0x9d0]  ; [pp+0x9d0] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0x1193984: ldur            x2, [x0, #0x1f]
    //     0x1193988: blr             x2
    // 0x119398c: b               #0x1193994
    // 0x1193990: r0 = Null
    //     0x1193990: mov             x0, NULL
    // 0x1193994: ldur            x3, [fp, #-0x18]
    // 0x1193998: StoreField: r3->field_27 = r0
    //     0x1193998: stur            w0, [x3, #0x27]
    //     0x119399c: ldurb           w16, [x3, #-1]
    //     0x11939a0: ldurb           w17, [x0, #-1]
    //     0x11939a4: and             x16, x17, x16, lsr #2
    //     0x11939a8: tst             x16, HEAP, lsr #32
    //     0x11939ac: b.eq            #0x11939b4
    //     0x11939b0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11939b4: LoadField: r0 = r3->field_2f
    //     0x11939b4: ldur            w0, [x3, #0x2f]
    // 0x11939b8: DecompressPointer r0
    //     0x11939b8: add             x0, x0, HEAP, lsl #32
    // 0x11939bc: stur            x0, [fp, #-0x10]
    // 0x11939c0: LoadField: r1 = r3->field_b
    //     0x11939c0: ldur            w1, [x3, #0xb]
    // 0x11939c4: DecompressPointer r1
    //     0x11939c4: add             x1, x1, HEAP, lsl #32
    // 0x11939c8: cmp             w1, NULL
    // 0x11939cc: b.eq            #0x1193a78
    // 0x11939d0: LoadField: r4 = r1->field_1b
    //     0x11939d0: ldur            w4, [x1, #0x1b]
    // 0x11939d4: DecompressPointer r4
    //     0x11939d4: add             x4, x4, HEAP, lsl #32
    // 0x11939d8: stur            x4, [fp, #-8]
    // 0x11939dc: r1 = Function '<anonymous closure>':.
    //     0x11939dc: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3af8] AnonymousClosure: (0x1193a7c), in [package:flutter/src/material/material.dart] _MaterialInteriorState::forEachTween (0x11937e0)
    //     0x11939e0: ldr             x1, [x1, #0xaf8]
    // 0x11939e4: r2 = Null
    //     0x11939e4: mov             x2, NULL
    // 0x11939e8: r0 = AllocateClosure()
    //     0x11939e8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11939ec: ldur            x16, [fp, #-0x20]
    // 0x11939f0: ldur            lr, [fp, #-0x10]
    // 0x11939f4: stp             lr, x16, [SP, #0x10]
    // 0x11939f8: ldur            x16, [fp, #-8]
    // 0x11939fc: stp             x0, x16, [SP]
    // 0x1193a00: ldur            x0, [fp, #-0x20]
    // 0x1193a04: ClosureCall
    //     0x1193a04: ldr             x4, [PP, #0x9d0]  ; [pp+0x9d0] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0x1193a08: ldur            x2, [x0, #0x1f]
    //     0x1193a0c: blr             x2
    // 0x1193a10: ldur            x1, [fp, #-0x18]
    // 0x1193a14: StoreField: r1->field_2f = r0
    //     0x1193a14: stur            w0, [x1, #0x2f]
    //     0x1193a18: ldurb           w16, [x1, #-1]
    //     0x1193a1c: ldurb           w17, [x0, #-1]
    //     0x1193a20: and             x16, x17, x16, lsr #2
    //     0x1193a24: tst             x16, HEAP, lsr #32
    //     0x1193a28: b.eq            #0x1193a30
    //     0x1193a2c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1193a30: r0 = Null
    //     0x1193a30: mov             x0, NULL
    // 0x1193a34: LeaveFrame
    //     0x1193a34: mov             SP, fp
    //     0x1193a38: ldp             fp, lr, [SP], #0x10
    // 0x1193a3c: ret
    //     0x1193a3c: ret             
    // 0x1193a40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1193a40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1193a44: b               #0x1193808
    // 0x1193a48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1193a48: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1193a4c: SaveReg d0
    //     0x1193a4c: str             q0, [SP, #-0x10]!
    // 0x1193a50: stp             x3, x4, [SP, #-0x10]!
    // 0x1193a54: SaveReg r0
    //     0x1193a54: str             x0, [SP, #-8]!
    // 0x1193a58: r0 = AllocateDouble()
    //     0x1193a58: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1193a5c: mov             x5, x0
    // 0x1193a60: RestoreReg r0
    //     0x1193a60: ldr             x0, [SP], #8
    // 0x1193a64: ldp             x3, x4, [SP], #0x10
    // 0x1193a68: RestoreReg d0
    //     0x1193a68: ldr             q0, [SP], #0x10
    // 0x1193a6c: b               #0x1193850
    // 0x1193a70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1193a70: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1193a74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1193a74: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1193a78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1193a78: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] ShapeBorderTween <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x1193a7c, size: 0x64
    // 0x1193a7c: EnterFrame
    //     0x1193a7c: stp             fp, lr, [SP, #-0x10]!
    //     0x1193a80: mov             fp, SP
    // 0x1193a84: ldr             x0, [fp, #0x10]
    // 0x1193a88: r2 = Null
    //     0x1193a88: mov             x2, NULL
    // 0x1193a8c: r1 = Null
    //     0x1193a8c: mov             x1, NULL
    // 0x1193a90: r4 = 60
    //     0x1193a90: mov             x4, #0x3c
    // 0x1193a94: branchIfSmi(r0, 0x1193aa0)
    //     0x1193a94: tbz             w0, #0, #0x1193aa0
    // 0x1193a98: r4 = LoadClassIdInstr(r0)
    //     0x1193a98: ldur            x4, [x0, #-1]
    //     0x1193a9c: ubfx            x4, x4, #0xc, #0x14
    // 0x1193aa0: sub             x4, x4, #0xbc4
    // 0x1193aa4: cmp             x4, #0x11
    // 0x1193aa8: b.ls            #0x1193ac0
    // 0x1193aac: r8 = ShapeBorder
    //     0x1193aac: add             x8, PP, #0x8e, lsl #12  ; [pp+0x8ee78] Type: ShapeBorder
    //     0x1193ab0: ldr             x8, [x8, #0xe78]
    // 0x1193ab4: r3 = Null
    //     0x1193ab4: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3b00] Null
    //     0x1193ab8: ldr             x3, [x3, #0xb00]
    // 0x1193abc: r0 = DefaultTypeTest()
    //     0x1193abc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x1193ac0: r1 = <ShapeBorder?>
    //     0x1193ac0: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c960] TypeArguments: <ShapeBorder?>
    //     0x1193ac4: ldr             x1, [x1, #0x960]
    // 0x1193ac8: r0 = ShapeBorderTween()
    //     0x1193ac8: bl              #0xfa19bc  ; AllocateShapeBorderTweenStub -> ShapeBorderTween (size=0x14)
    // 0x1193acc: ldr             x1, [fp, #0x10]
    // 0x1193ad0: StoreField: r0->field_b = r1
    //     0x1193ad0: stur            w1, [x0, #0xb]
    // 0x1193ad4: LeaveFrame
    //     0x1193ad4: mov             SP, fp
    //     0x1193ad8: ldp             fp, lr, [SP], #0x10
    // 0x1193adc: ret
    //     0x1193adc: ret             
  }
  [closure] ColorTween <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x1193ae0, size: 0x6c
    // 0x1193ae0: EnterFrame
    //     0x1193ae0: stp             fp, lr, [SP, #-0x10]!
    //     0x1193ae4: mov             fp, SP
    // 0x1193ae8: ldr             x0, [fp, #0x10]
    // 0x1193aec: r2 = Null
    //     0x1193aec: mov             x2, NULL
    // 0x1193af0: r1 = Null
    //     0x1193af0: mov             x1, NULL
    // 0x1193af4: r4 = 60
    //     0x1193af4: mov             x4, #0x3c
    // 0x1193af8: branchIfSmi(r0, 0x1193b04)
    //     0x1193af8: tbz             w0, #0, #0x1193b04
    // 0x1193afc: r4 = LoadClassIdInstr(r0)
    //     0x1193afc: ldur            x4, [x0, #-1]
    //     0x1193b00: ubfx            x4, x4, #0xc, #0x14
    // 0x1193b04: sub             x4, x4, #0xecc
    // 0x1193b08: cmp             x4, #5
    // 0x1193b0c: b.ls            #0x1193b2c
    // 0x1193b10: cmp             x4, #0x5ad
    // 0x1193b14: b.eq            #0x1193b2c
    // 0x1193b18: r8 = Color
    //     0x1193b18: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3a30] Type: Color
    //     0x1193b1c: ldr             x8, [x8, #0xa30]
    // 0x1193b20: r3 = Null
    //     0x1193b20: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3b10] Null
    //     0x1193b24: ldr             x3, [x3, #0xb10]
    // 0x1193b28: r0 = Color()
    //     0x1193b28: bl              #0x8996a8  ; IsType_Color_Stub
    // 0x1193b2c: r1 = <Color?>
    //     0x1193b2c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1193b30: ldr             x1, [x1, #0xa40]
    // 0x1193b34: r0 = ColorTween()
    //     0x1193b34: bl              #0x915f2c  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0x1193b38: ldr             x1, [fp, #0x10]
    // 0x1193b3c: StoreField: r0->field_b = r1
    //     0x1193b3c: stur            w1, [x0, #0xb]
    // 0x1193b40: LeaveFrame
    //     0x1193b40: mov             SP, fp
    //     0x1193b44: ldp             fp, lr, [SP], #0x10
    // 0x1193b48: ret
    //     0x1193b48: ret             
  }
  [closure] ColorTween <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x1193b4c, size: 0x6c
    // 0x1193b4c: EnterFrame
    //     0x1193b4c: stp             fp, lr, [SP, #-0x10]!
    //     0x1193b50: mov             fp, SP
    // 0x1193b54: ldr             x0, [fp, #0x10]
    // 0x1193b58: r2 = Null
    //     0x1193b58: mov             x2, NULL
    // 0x1193b5c: r1 = Null
    //     0x1193b5c: mov             x1, NULL
    // 0x1193b60: r4 = 60
    //     0x1193b60: mov             x4, #0x3c
    // 0x1193b64: branchIfSmi(r0, 0x1193b70)
    //     0x1193b64: tbz             w0, #0, #0x1193b70
    // 0x1193b68: r4 = LoadClassIdInstr(r0)
    //     0x1193b68: ldur            x4, [x0, #-1]
    //     0x1193b6c: ubfx            x4, x4, #0xc, #0x14
    // 0x1193b70: sub             x4, x4, #0xecc
    // 0x1193b74: cmp             x4, #5
    // 0x1193b78: b.ls            #0x1193b98
    // 0x1193b7c: cmp             x4, #0x5ad
    // 0x1193b80: b.eq            #0x1193b98
    // 0x1193b84: r8 = Color
    //     0x1193b84: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3a30] Type: Color
    //     0x1193b88: ldr             x8, [x8, #0xa30]
    // 0x1193b8c: r3 = Null
    //     0x1193b8c: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3b20] Null
    //     0x1193b90: ldr             x3, [x3, #0xb20]
    // 0x1193b94: r0 = Color()
    //     0x1193b94: bl              #0x8996a8  ; IsType_Color_Stub
    // 0x1193b98: r1 = <Color?>
    //     0x1193b98: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1193b9c: ldr             x1, [x1, #0xa40]
    // 0x1193ba0: r0 = ColorTween()
    //     0x1193ba0: bl              #0x915f2c  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0x1193ba4: ldr             x1, [fp, #0x10]
    // 0x1193ba8: StoreField: r0->field_b = r1
    //     0x1193ba8: stur            w1, [x0, #0xb]
    // 0x1193bac: LeaveFrame
    //     0x1193bac: mov             SP, fp
    //     0x1193bb0: ldp             fp, lr, [SP], #0x10
    // 0x1193bb4: ret
    //     0x1193bb4: ret             
  }
  [closure] Tween<double> <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x1193bb8, size: 0x58
    // 0x1193bb8: EnterFrame
    //     0x1193bb8: stp             fp, lr, [SP, #-0x10]!
    //     0x1193bbc: mov             fp, SP
    // 0x1193bc0: ldr             x0, [fp, #0x10]
    // 0x1193bc4: r2 = Null
    //     0x1193bc4: mov             x2, NULL
    // 0x1193bc8: r1 = Null
    //     0x1193bc8: mov             x1, NULL
    // 0x1193bcc: r4 = 60
    //     0x1193bcc: mov             x4, #0x3c
    // 0x1193bd0: branchIfSmi(r0, 0x1193bdc)
    //     0x1193bd0: tbz             w0, #0, #0x1193bdc
    // 0x1193bd4: r4 = LoadClassIdInstr(r0)
    //     0x1193bd4: ldur            x4, [x0, #-1]
    //     0x1193bd8: ubfx            x4, x4, #0xc, #0x14
    // 0x1193bdc: cmp             x4, #0x3e
    // 0x1193be0: b.eq            #0x1193bf4
    // 0x1193be4: r8 = double
    //     0x1193be4: ldr             x8, [PP, #0x6e90]  ; [pp+0x6e90] Type: double
    // 0x1193be8: r3 = Null
    //     0x1193be8: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3b30] Null
    //     0x1193bec: ldr             x3, [x3, #0xb30]
    // 0x1193bf0: r0 = double()
    //     0x1193bf0: bl              #0x13ee3d0  ; IsType_double_Stub
    // 0x1193bf4: r1 = <double>
    //     0x1193bf4: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x1193bf8: r0 = Tween()
    //     0x1193bf8: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x1193bfc: ldr             x1, [fp, #0x10]
    // 0x1193c00: StoreField: r0->field_b = r1
    //     0x1193c00: stur            w1, [x0, #0xb]
    // 0x1193c04: LeaveFrame
    //     0x1193c04: mov             SP, fp
    //     0x1193c08: ldp             fp, lr, [SP], #0x10
    // 0x1193c0c: ret
    //     0x1193c0c: ret             
  }
}

// class id: 5746, size: 0x20, field offset: 0x1c
class _MaterialState extends _MixinApplication76&State&TickerProviderStateMixin {

  _ build(/* No info */) {
    // ** addr: 0xd2e020, size: 0x670
    // 0xd2e020: EnterFrame
    //     0xd2e020: stp             fp, lr, [SP, #-0x10]!
    //     0xd2e024: mov             fp, SP
    // 0xd2e028: AllocStack(0x68)
    //     0xd2e028: sub             SP, SP, #0x68
    // 0xd2e02c: SetupParameters(_MaterialState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd2e02c: mov             x0, x1
    //     0xd2e030: stur            x1, [fp, #-8]
    //     0xd2e034: mov             x1, x2
    //     0xd2e038: stur            x2, [fp, #-0x10]
    // 0xd2e03c: CheckStackOverflow
    //     0xd2e03c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd2e040: cmp             SP, x16
    //     0xd2e044: b.ls            #0xd2e668
    // 0xd2e048: r1 = 1
    //     0xd2e048: mov             x1, #1
    // 0xd2e04c: r0 = AllocateContext()
    //     0xd2e04c: bl              #0x13de838  ; AllocateContextStub
    // 0xd2e050: mov             x2, x0
    // 0xd2e054: ldur            x0, [fp, #-8]
    // 0xd2e058: stur            x2, [fp, #-0x18]
    // 0xd2e05c: StoreField: r2->field_f = r0
    //     0xd2e05c: stur            w0, [x2, #0xf]
    // 0xd2e060: ldur            x1, [fp, #-0x10]
    // 0xd2e064: r0 = of()
    //     0xd2e064: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd2e068: mov             x2, x0
    // 0xd2e06c: ldur            x0, [fp, #-8]
    // 0xd2e070: stur            x2, [fp, #-0x38]
    // 0xd2e074: LoadField: r1 = r0->field_b
    //     0xd2e074: ldur            w1, [x0, #0xb]
    // 0xd2e078: DecompressPointer r1
    //     0xd2e078: add             x1, x1, HEAP, lsl #32
    // 0xd2e07c: cmp             w1, NULL
    // 0xd2e080: b.eq            #0xd2e670
    // 0xd2e084: LoadField: r3 = r1->field_1f
    //     0xd2e084: ldur            w3, [x1, #0x1f]
    // 0xd2e088: DecompressPointer r3
    //     0xd2e088: add             x3, x3, HEAP, lsl #32
    // 0xd2e08c: cmp             w3, NULL
    // 0xd2e090: b.ne            #0xd2e110
    // 0xd2e094: LoadField: r3 = r1->field_f
    //     0xd2e094: ldur            w3, [x1, #0xf]
    // 0xd2e098: DecompressPointer r3
    //     0xd2e098: add             x3, x3, HEAP, lsl #32
    // 0xd2e09c: r16 = Instance_MaterialType
    //     0xd2e09c: add             x16, PP, #0x17, lsl #12  ; [pp+0x17210] Obj!MaterialType@12c5341
    //     0xd2e0a0: ldr             x16, [x16, #0x210]
    // 0xd2e0a4: cmp             w3, w16
    // 0xd2e0a8: b.ne            #0xd2e0b8
    // 0xd2e0ac: LoadField: r3 = r2->field_37
    //     0xd2e0ac: ldur            w3, [x2, #0x37]
    // 0xd2e0b0: DecompressPointer r3
    //     0xd2e0b0: add             x3, x3, HEAP, lsl #32
    // 0xd2e0b4: b               #0xd2e110
    // 0xd2e0b8: r16 = Instance_MaterialType
    //     0xd2e0b8: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c988] Obj!MaterialType@12c53c1
    //     0xd2e0bc: ldr             x16, [x16, #0x988]
    // 0xd2e0c0: cmp             w3, w16
    // 0xd2e0c4: b.ne            #0xd2e0d4
    // 0xd2e0c8: LoadField: r3 = r2->field_3b
    //     0xd2e0c8: ldur            w3, [x2, #0x3b]
    // 0xd2e0cc: DecompressPointer r3
    //     0xd2e0cc: add             x3, x3, HEAP, lsl #32
    // 0xd2e0d0: b               #0xd2e110
    // 0xd2e0d4: r16 = Instance_MaterialType
    //     0xd2e0d4: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fca8] Obj!MaterialType@12c5381
    //     0xd2e0d8: ldr             x16, [x16, #0xca8]
    // 0xd2e0dc: cmp             w3, w16
    // 0xd2e0e0: b.eq            #0xd2e104
    // 0xd2e0e4: r16 = Instance_MaterialType
    //     0xd2e0e4: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fcb0] Obj!MaterialType@12c53a1
    //     0xd2e0e8: ldr             x16, [x16, #0xcb0]
    // 0xd2e0ec: cmp             w3, w16
    // 0xd2e0f0: b.eq            #0xd2e104
    // 0xd2e0f4: r16 = Instance_MaterialType
    //     0xd2e0f4: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c618] Obj!MaterialType@12c5361
    //     0xd2e0f8: ldr             x16, [x16, #0x618]
    // 0xd2e0fc: cmp             w3, w16
    // 0xd2e100: b.ne            #0xd2e10c
    // 0xd2e104: r3 = Null
    //     0xd2e104: mov             x3, NULL
    // 0xd2e108: b               #0xd2e110
    // 0xd2e10c: r3 = Null
    //     0xd2e10c: mov             x3, NULL
    // 0xd2e110: stur            x3, [fp, #-0x30]
    // 0xd2e114: LoadField: r4 = r1->field_23
    //     0xd2e114: ldur            w4, [x1, #0x23]
    // 0xd2e118: DecompressPointer r4
    //     0xd2e118: add             x4, x4, HEAP, lsl #32
    // 0xd2e11c: cmp             w4, NULL
    // 0xd2e120: b.ne            #0xd2e164
    // 0xd2e124: LoadField: r4 = r2->field_2f
    //     0xd2e124: ldur            w4, [x2, #0x2f]
    // 0xd2e128: DecompressPointer r4
    //     0xd2e128: add             x4, x4, HEAP, lsl #32
    // 0xd2e12c: tbnz            w4, #4, #0xd2e15c
    // 0xd2e130: LoadField: r4 = r2->field_3f
    //     0xd2e130: ldur            w4, [x2, #0x3f]
    // 0xd2e134: DecompressPointer r4
    //     0xd2e134: add             x4, x4, HEAP, lsl #32
    // 0xd2e138: LoadField: r5 = r4->field_af
    //     0xd2e138: ldur            w5, [x4, #0xaf]
    // 0xd2e13c: DecompressPointer r5
    //     0xd2e13c: add             x5, x5, HEAP, lsl #32
    // 0xd2e140: cmp             w5, NULL
    // 0xd2e144: b.ne            #0xd2e154
    // 0xd2e148: r4 = Instance_Color
    //     0xd2e148: add             x4, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0xd2e14c: ldr             x4, [x4, #0x948]
    // 0xd2e150: b               #0xd2e164
    // 0xd2e154: mov             x4, x5
    // 0xd2e158: b               #0xd2e164
    // 0xd2e15c: LoadField: r4 = r2->field_6f
    //     0xd2e15c: ldur            w4, [x2, #0x6f]
    // 0xd2e160: DecompressPointer r4
    //     0xd2e160: add             x4, x4, HEAP, lsl #32
    // 0xd2e164: stur            x4, [fp, #-0x28]
    // 0xd2e168: LoadField: r5 = r1->field_b
    //     0xd2e168: ldur            w5, [x1, #0xb]
    // 0xd2e16c: DecompressPointer r5
    //     0xd2e16c: add             x5, x5, HEAP, lsl #32
    // 0xd2e170: stur            x5, [fp, #-0x20]
    // 0xd2e174: cmp             w5, NULL
    // 0xd2e178: b.eq            #0xd2e230
    // 0xd2e17c: LoadField: r6 = r1->field_2b
    //     0xd2e17c: ldur            w6, [x1, #0x2b]
    // 0xd2e180: DecompressPointer r6
    //     0xd2e180: add             x6, x6, HEAP, lsl #32
    // 0xd2e184: cmp             w6, NULL
    // 0xd2e188: b.ne            #0xd2e1b4
    // 0xd2e18c: ldur            x1, [fp, #-0x10]
    // 0xd2e190: r0 = of()
    //     0xd2e190: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd2e194: LoadField: r1 = r0->field_87
    //     0xd2e194: ldur            w1, [x0, #0x87]
    // 0xd2e198: DecompressPointer r1
    //     0xd2e198: add             x1, x1, HEAP, lsl #32
    // 0xd2e19c: LoadField: r0 = r1->field_2f
    //     0xd2e19c: ldur            w0, [x1, #0x2f]
    // 0xd2e1a0: DecompressPointer r0
    //     0xd2e1a0: add             x0, x0, HEAP, lsl #32
    // 0xd2e1a4: cmp             w0, NULL
    // 0xd2e1a8: b.eq            #0xd2e674
    // 0xd2e1ac: mov             x2, x0
    // 0xd2e1b0: b               #0xd2e1b8
    // 0xd2e1b4: mov             x2, x6
    // 0xd2e1b8: ldur            x0, [fp, #-8]
    // 0xd2e1bc: ldur            x1, [fp, #-0x20]
    // 0xd2e1c0: stur            x2, [fp, #-0x48]
    // 0xd2e1c4: LoadField: r3 = r0->field_b
    //     0xd2e1c4: ldur            w3, [x0, #0xb]
    // 0xd2e1c8: DecompressPointer r3
    //     0xd2e1c8: add             x3, x3, HEAP, lsl #32
    // 0xd2e1cc: stur            x3, [fp, #-0x40]
    // 0xd2e1d0: cmp             w3, NULL
    // 0xd2e1d4: b.eq            #0xd2e678
    // 0xd2e1d8: r0 = AnimatedDefaultTextStyle()
    //     0xd2e1d8: bl              #0xd2ad90  ; AllocateAnimatedDefaultTextStyleStub -> AnimatedDefaultTextStyle (size=0x38)
    // 0xd2e1dc: mov             x1, x0
    // 0xd2e1e0: ldur            x0, [fp, #-0x20]
    // 0xd2e1e4: ArrayStore: r1[0] = r0  ; List_4
    //     0xd2e1e4: stur            w0, [x1, #0x17]
    // 0xd2e1e8: ldur            x0, [fp, #-0x48]
    // 0xd2e1ec: StoreField: r1->field_1b = r0
    //     0xd2e1ec: stur            w0, [x1, #0x1b]
    // 0xd2e1f0: r2 = true
    //     0xd2e1f0: add             x2, NULL, #0x20  ; true
    // 0xd2e1f4: StoreField: r1->field_23 = r2
    //     0xd2e1f4: stur            w2, [x1, #0x23]
    // 0xd2e1f8: r0 = Instance_TextOverflow
    //     0xd2e1f8: add             x0, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xd2e1fc: ldr             x0, [x0, #0x108]
    // 0xd2e200: StoreField: r1->field_27 = r0
    //     0xd2e200: stur            w0, [x1, #0x27]
    // 0xd2e204: r0 = Instance_TextWidthBasis
    //     0xd2e204: add             x0, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xd2e208: ldr             x0, [x0, #0x110]
    // 0xd2e20c: StoreField: r1->field_2f = r0
    //     0xd2e20c: stur            w0, [x1, #0x2f]
    // 0xd2e210: r0 = Instance__Linear
    //     0xd2e210: ldr             x0, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xd2e214: StoreField: r1->field_b = r0
    //     0xd2e214: stur            w0, [x1, #0xb]
    // 0xd2e218: r3 = Instance_Duration
    //     0xd2e218: add             x3, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xd2e21c: ldr             x3, [x3, #0x318]
    // 0xd2e220: StoreField: r1->field_f = r3
    //     0xd2e220: stur            w3, [x1, #0xf]
    // 0xd2e224: mov             x5, x1
    // 0xd2e228: ldur            x4, [fp, #-0x40]
    // 0xd2e22c: b               #0xd2e248
    // 0xd2e230: mov             x0, x5
    // 0xd2e234: r2 = true
    //     0xd2e234: add             x2, NULL, #0x20  ; true
    // 0xd2e238: r3 = Instance_Duration
    //     0xd2e238: add             x3, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xd2e23c: ldr             x3, [x3, #0x318]
    // 0xd2e240: mov             x5, x0
    // 0xd2e244: mov             x4, x1
    // 0xd2e248: ldur            x0, [fp, #-8]
    // 0xd2e24c: ldur            x1, [fp, #-0x30]
    // 0xd2e250: stur            x5, [fp, #-0x50]
    // 0xd2e254: stur            x4, [fp, #-0x58]
    // 0xd2e258: LoadField: r6 = r0->field_1b
    //     0xd2e258: ldur            w6, [x0, #0x1b]
    // 0xd2e25c: DecompressPointer r6
    //     0xd2e25c: add             x6, x6, HEAP, lsl #32
    // 0xd2e260: stur            x6, [fp, #-0x48]
    // 0xd2e264: LoadField: r7 = r4->field_f
    //     0xd2e264: ldur            w7, [x4, #0xf]
    // 0xd2e268: DecompressPointer r7
    //     0xd2e268: add             x7, x7, HEAP, lsl #32
    // 0xd2e26c: stur            x7, [fp, #-0x40]
    // 0xd2e270: r16 = Instance_MaterialType
    //     0xd2e270: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c618] Obj!MaterialType@12c5361
    //     0xd2e274: ldr             x16, [x16, #0x618]
    // 0xd2e278: cmp             w7, w16
    // 0xd2e27c: r16 = true
    //     0xd2e27c: add             x16, NULL, #0x20  ; true
    // 0xd2e280: r17 = false
    //     0xd2e280: add             x17, NULL, #0x30  ; false
    // 0xd2e284: csel            x8, x16, x17, ne
    // 0xd2e288: stur            x8, [fp, #-0x20]
    // 0xd2e28c: r0 = _InkFeatures()
    //     0xd2e28c: bl              #0xd2eaa8  ; Allocate_InkFeaturesStub -> _InkFeatures (size=0x1c)
    // 0xd2e290: mov             x3, x0
    // 0xd2e294: ldur            x0, [fp, #-0x30]
    // 0xd2e298: stur            x3, [fp, #-0x60]
    // 0xd2e29c: StoreField: r3->field_f = r0
    //     0xd2e29c: stur            w0, [x3, #0xf]
    // 0xd2e2a0: ldur            x4, [fp, #-8]
    // 0xd2e2a4: StoreField: r3->field_13 = r4
    //     0xd2e2a4: stur            w4, [x3, #0x13]
    // 0xd2e2a8: ldur            x1, [fp, #-0x20]
    // 0xd2e2ac: ArrayStore: r3[0] = r1  ; List_4
    //     0xd2e2ac: stur            w1, [x3, #0x17]
    // 0xd2e2b0: ldur            x1, [fp, #-0x50]
    // 0xd2e2b4: StoreField: r3->field_b = r1
    //     0xd2e2b4: stur            w1, [x3, #0xb]
    // 0xd2e2b8: ldur            x1, [fp, #-0x48]
    // 0xd2e2bc: StoreField: r3->field_7 = r1
    //     0xd2e2bc: stur            w1, [x3, #7]
    // 0xd2e2c0: ldur            x2, [fp, #-0x18]
    // 0xd2e2c4: r1 = Function '<anonymous closure>':.
    //     0xd2e2c4: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8fcb8] AnonymousClosure: (0xd2eab4), in [package:flutter/src/material/material.dart] _MaterialState::build (0xd2e020)
    //     0xd2e2c8: ldr             x1, [x1, #0xcb8]
    // 0xd2e2cc: r0 = AllocateClosure()
    //     0xd2e2cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd2e2d0: r1 = <LayoutChangedNotification>
    //     0xd2e2d0: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8fcc0] TypeArguments: <LayoutChangedNotification>
    //     0xd2e2d4: ldr             x1, [x1, #0xcc0]
    // 0xd2e2d8: stur            x0, [fp, #-0x18]
    // 0xd2e2dc: r0 = NotificationListener()
    //     0xd2e2dc: bl              #0xd2ea9c  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0xd2e2e0: mov             x1, x0
    // 0xd2e2e4: ldur            x0, [fp, #-0x18]
    // 0xd2e2e8: stur            x1, [fp, #-0x20]
    // 0xd2e2ec: StoreField: r1->field_13 = r0
    //     0xd2e2ec: stur            w0, [x1, #0x13]
    // 0xd2e2f0: ldur            x0, [fp, #-0x60]
    // 0xd2e2f4: StoreField: r1->field_b = r0
    //     0xd2e2f4: stur            w0, [x1, #0xb]
    // 0xd2e2f8: ldur            x0, [fp, #-0x58]
    // 0xd2e2fc: LoadField: r2 = r0->field_3f
    //     0xd2e2fc: ldur            w2, [x0, #0x3f]
    // 0xd2e300: DecompressPointer r2
    //     0xd2e300: add             x2, x2, HEAP, lsl #32
    // 0xd2e304: stur            x2, [fp, #-0x18]
    // 0xd2e308: cmp             w2, NULL
    // 0xd2e30c: b.eq            #0xd2e338
    // 0xd2e310: r0 = RoundedRectangleBorder()
    //     0xd2e310: bl              #0xd2ea90  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0xd2e314: mov             x1, x0
    // 0xd2e318: ldur            x0, [fp, #-0x18]
    // 0xd2e31c: StoreField: r1->field_b = r0
    //     0xd2e31c: stur            w0, [x1, #0xb]
    // 0xd2e320: r0 = Instance_BorderSide
    //     0xd2e320: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0xd2e324: ldr             x0, [x0, #0x310]
    // 0xd2e328: StoreField: r1->field_7 = r0
    //     0xd2e328: stur            w0, [x1, #7]
    // 0xd2e32c: mov             x2, x1
    // 0xd2e330: ldur            x0, [fp, #-0x58]
    // 0xd2e334: b               #0xd2e344
    // 0xd2e338: LoadField: r1 = r0->field_2f
    //     0xd2e338: ldur            w1, [x0, #0x2f]
    // 0xd2e33c: DecompressPointer r1
    //     0xd2e33c: add             x1, x1, HEAP, lsl #32
    // 0xd2e340: mov             x2, x1
    // 0xd2e344: ldur            x1, [fp, #-0x40]
    // 0xd2e348: r16 = Instance_MaterialType
    //     0xd2e348: add             x16, PP, #0x17, lsl #12  ; [pp+0x17210] Obj!MaterialType@12c5341
    //     0xd2e34c: ldr             x16, [x16, #0x210]
    // 0xd2e350: cmp             w1, w16
    // 0xd2e354: b.ne            #0xd2e478
    // 0xd2e358: cmp             w2, NULL
    // 0xd2e35c: b.ne            #0xd2e454
    // 0xd2e360: ldur            x1, [fp, #-0x38]
    // 0xd2e364: LoadField: r2 = r1->field_2f
    //     0xd2e364: ldur            w2, [x1, #0x2f]
    // 0xd2e368: DecompressPointer r2
    //     0xd2e368: add             x2, x2, HEAP, lsl #32
    // 0xd2e36c: tbnz            w2, #4, #0xd2e398
    // 0xd2e370: ldur            x3, [fp, #-0x30]
    // 0xd2e374: cmp             w3, NULL
    // 0xd2e378: b.eq            #0xd2e67c
    // 0xd2e37c: LoadField: r2 = r0->field_27
    //     0xd2e37c: ldur            w2, [x0, #0x27]
    // 0xd2e380: DecompressPointer r2
    //     0xd2e380: add             x2, x2, HEAP, lsl #32
    // 0xd2e384: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xd2e384: ldur            d0, [x0, #0x17]
    // 0xd2e388: mov             x1, x3
    // 0xd2e38c: r0 = applySurfaceTint()
    //     0xd2e38c: bl              #0xd2e910  ; [package:flutter/src/material/elevation_overlay.dart] ElevationOverlay::applySurfaceTint
    // 0xd2e390: mov             x2, x0
    // 0xd2e394: b               #0xd2e3b8
    // 0xd2e398: ldur            x3, [fp, #-0x30]
    // 0xd2e39c: cmp             w3, NULL
    // 0xd2e3a0: b.eq            #0xd2e680
    // 0xd2e3a4: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xd2e3a4: ldur            d0, [x0, #0x17]
    // 0xd2e3a8: ldur            x1, [fp, #-0x10]
    // 0xd2e3ac: mov             x2, x3
    // 0xd2e3b0: r0 = applyOverlay()
    //     0xd2e3b0: bl              #0xd2e708  ; [package:flutter/src/material/elevation_overlay.dart] ElevationOverlay::applyOverlay
    // 0xd2e3b4: mov             x2, x0
    // 0xd2e3b8: ldur            x4, [fp, #-8]
    // 0xd2e3bc: ldur            x1, [fp, #-0x28]
    // 0xd2e3c0: ldur            x0, [fp, #-0x20]
    // 0xd2e3c4: stur            x2, [fp, #-0x38]
    // 0xd2e3c8: LoadField: r3 = r4->field_b
    //     0xd2e3c8: ldur            w3, [x4, #0xb]
    // 0xd2e3cc: DecompressPointer r3
    //     0xd2e3cc: add             x3, x3, HEAP, lsl #32
    // 0xd2e3d0: cmp             w3, NULL
    // 0xd2e3d4: b.eq            #0xd2e684
    // 0xd2e3d8: LoadField: r4 = r3->field_37
    //     0xd2e3d8: ldur            w4, [x3, #0x37]
    // 0xd2e3dc: DecompressPointer r4
    //     0xd2e3dc: add             x4, x4, HEAP, lsl #32
    // 0xd2e3e0: stur            x4, [fp, #-0x18]
    // 0xd2e3e4: ArrayLoad: d0 = r3[0]  ; List_8
    //     0xd2e3e4: ldur            d0, [x3, #0x17]
    // 0xd2e3e8: stur            d0, [fp, #-0x68]
    // 0xd2e3ec: r0 = AnimatedPhysicalModel()
    //     0xd2e3ec: bl              #0xd2e6d8  ; AllocateAnimatedPhysicalModelStub -> AnimatedPhysicalModel (size=0x40)
    // 0xd2e3f0: ldur            x5, [fp, #-0x20]
    // 0xd2e3f4: ArrayStore: r0[0] = r5  ; List_4
    //     0xd2e3f4: stur            w5, [x0, #0x17]
    // 0xd2e3f8: r1 = Instance_BoxShape
    //     0xd2e3f8: add             x1, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xd2e3fc: ldr             x1, [x1, #0x1f8]
    // 0xd2e400: StoreField: r0->field_1b = r1
    //     0xd2e400: stur            w1, [x0, #0x1b]
    // 0xd2e404: ldur            x1, [fp, #-0x18]
    // 0xd2e408: StoreField: r0->field_1f = r1
    //     0xd2e408: stur            w1, [x0, #0x1f]
    // 0xd2e40c: ldur            d0, [fp, #-0x68]
    // 0xd2e410: StoreField: r0->field_27 = d0
    //     0xd2e410: stur            d0, [x0, #0x27]
    // 0xd2e414: ldur            x1, [fp, #-0x38]
    // 0xd2e418: StoreField: r0->field_2f = r1
    //     0xd2e418: stur            w1, [x0, #0x2f]
    // 0xd2e41c: r1 = false
    //     0xd2e41c: add             x1, NULL, #0x30  ; false
    // 0xd2e420: StoreField: r0->field_33 = r1
    //     0xd2e420: stur            w1, [x0, #0x33]
    // 0xd2e424: ldur            x6, [fp, #-0x28]
    // 0xd2e428: StoreField: r0->field_37 = r6
    //     0xd2e428: stur            w6, [x0, #0x37]
    // 0xd2e42c: r7 = true
    //     0xd2e42c: add             x7, NULL, #0x20  ; true
    // 0xd2e430: StoreField: r0->field_3b = r7
    //     0xd2e430: stur            w7, [x0, #0x3b]
    // 0xd2e434: r8 = Instance_Cubic
    //     0xd2e434: ldr             x8, [PP, #0x5660]  ; [pp+0x5660] Obj!Cubic@129f451
    // 0xd2e438: StoreField: r0->field_b = r8
    //     0xd2e438: stur            w8, [x0, #0xb]
    // 0xd2e43c: r9 = Instance_Duration
    //     0xd2e43c: add             x9, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xd2e440: ldr             x9, [x9, #0x318]
    // 0xd2e444: StoreField: r0->field_f = r9
    //     0xd2e444: stur            w9, [x0, #0xf]
    // 0xd2e448: LeaveFrame
    //     0xd2e448: mov             SP, fp
    //     0xd2e44c: ldp             fp, lr, [SP], #0x10
    // 0xd2e450: ret
    //     0xd2e450: ret             
    // 0xd2e454: ldur            x4, [fp, #-8]
    // 0xd2e458: ldur            x3, [fp, #-0x30]
    // 0xd2e45c: ldur            x6, [fp, #-0x28]
    // 0xd2e460: ldur            x5, [fp, #-0x20]
    // 0xd2e464: r7 = true
    //     0xd2e464: add             x7, NULL, #0x20  ; true
    // 0xd2e468: r9 = Instance_Duration
    //     0xd2e468: add             x9, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xd2e46c: ldr             x9, [x9, #0x318]
    // 0xd2e470: r8 = Instance_Cubic
    //     0xd2e470: ldr             x8, [PP, #0x5660]  ; [pp+0x5660] Obj!Cubic@129f451
    // 0xd2e474: b               #0xd2e498
    // 0xd2e478: ldur            x4, [fp, #-8]
    // 0xd2e47c: ldur            x3, [fp, #-0x30]
    // 0xd2e480: ldur            x6, [fp, #-0x28]
    // 0xd2e484: ldur            x5, [fp, #-0x20]
    // 0xd2e488: r7 = true
    //     0xd2e488: add             x7, NULL, #0x20  ; true
    // 0xd2e48c: r9 = Instance_Duration
    //     0xd2e48c: add             x9, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xd2e490: ldr             x9, [x9, #0x318]
    // 0xd2e494: r8 = Instance_Cubic
    //     0xd2e494: ldr             x8, [PP, #0x5660]  ; [pp+0x5660] Obj!Cubic@129f451
    // 0xd2e498: cmp             w2, NULL
    // 0xd2e49c: b.ne            #0xd2e518
    // 0xd2e4a0: r16 = Instance_MaterialType
    //     0xd2e4a0: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fcb0] Obj!MaterialType@12c53a1
    //     0xd2e4a4: ldr             x16, [x16, #0xcb0]
    // 0xd2e4a8: cmp             w1, w16
    // 0xd2e4ac: b.ne            #0xd2e4bc
    // 0xd2e4b0: r2 = Instance_CircleBorder
    //     0xd2e4b0: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1c318] Obj!CircleBorder@129ebf1
    //     0xd2e4b4: ldr             x2, [x2, #0x318]
    // 0xd2e4b8: b               #0xd2e518
    // 0xd2e4bc: r16 = Instance_MaterialType
    //     0xd2e4bc: add             x16, PP, #0x17, lsl #12  ; [pp+0x17210] Obj!MaterialType@12c5341
    //     0xd2e4c0: ldr             x16, [x16, #0x210]
    // 0xd2e4c4: cmp             w1, w16
    // 0xd2e4c8: b.eq            #0xd2e4dc
    // 0xd2e4cc: r16 = Instance_MaterialType
    //     0xd2e4cc: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c618] Obj!MaterialType@12c5361
    //     0xd2e4d0: ldr             x16, [x16, #0x618]
    // 0xd2e4d4: cmp             w1, w16
    // 0xd2e4d8: b.ne            #0xd2e4e8
    // 0xd2e4dc: r2 = Instance_RoundedRectangleBorder
    //     0xd2e4dc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26600] Obj!RoundedRectangleBorder@129ec31
    //     0xd2e4e0: ldr             x2, [x2, #0x600]
    // 0xd2e4e4: b               #0xd2e518
    // 0xd2e4e8: r16 = Instance_MaterialType
    //     0xd2e4e8: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c988] Obj!MaterialType@12c53c1
    //     0xd2e4ec: ldr             x16, [x16, #0x988]
    // 0xd2e4f0: cmp             w1, w16
    // 0xd2e4f4: b.eq            #0xd2e508
    // 0xd2e4f8: r16 = Instance_MaterialType
    //     0xd2e4f8: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fca8] Obj!MaterialType@12c5381
    //     0xd2e4fc: ldr             x16, [x16, #0xca8]
    // 0xd2e500: cmp             w1, w16
    // 0xd2e504: b.ne            #0xd2e514
    // 0xd2e508: r2 = Instance_RoundedRectangleBorder
    //     0xd2e508: add             x2, PP, #0x26, lsl #12  ; [pp+0x264d0] Obj!RoundedRectangleBorder@129ec61
    //     0xd2e50c: ldr             x2, [x2, #0x4d0]
    // 0xd2e510: b               #0xd2e518
    // 0xd2e514: r2 = Null
    //     0xd2e514: mov             x2, NULL
    // 0xd2e518: stur            x2, [fp, #-0x18]
    // 0xd2e51c: r16 = Instance_MaterialType
    //     0xd2e51c: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c618] Obj!MaterialType@12c5361
    //     0xd2e520: ldr             x16, [x16, #0x618]
    // 0xd2e524: cmp             w1, w16
    // 0xd2e528: b.ne            #0xd2e5cc
    // 0xd2e52c: ldur            x1, [fp, #-0x10]
    // 0xd2e530: r0 = maybeOf()
    //     0xd2e530: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xd2e534: r1 = <Path>
    //     0xd2e534: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a60] TypeArguments: <Path>
    //     0xd2e538: ldr             x1, [x1, #0xa60]
    // 0xd2e53c: stur            x0, [fp, #-0x10]
    // 0xd2e540: r0 = ShapeBorderClipper()
    //     0xd2e540: bl              #0xd2e6cc  ; AllocateShapeBorderClipperStub -> ShapeBorderClipper (size=0x18)
    // 0xd2e544: mov             x1, x0
    // 0xd2e548: ldur            x0, [fp, #-0x18]
    // 0xd2e54c: stur            x1, [fp, #-0x38]
    // 0xd2e550: StoreField: r1->field_f = r0
    //     0xd2e550: stur            w0, [x1, #0xf]
    // 0xd2e554: ldur            x2, [fp, #-0x10]
    // 0xd2e558: StoreField: r1->field_13 = r2
    //     0xd2e558: stur            w2, [x1, #0x13]
    // 0xd2e55c: ldur            x2, [fp, #-8]
    // 0xd2e560: LoadField: r3 = r2->field_b
    //     0xd2e560: ldur            w3, [x2, #0xb]
    // 0xd2e564: DecompressPointer r3
    //     0xd2e564: add             x3, x3, HEAP, lsl #32
    // 0xd2e568: cmp             w3, NULL
    // 0xd2e56c: b.eq            #0xd2e688
    // 0xd2e570: LoadField: r2 = r3->field_37
    //     0xd2e570: ldur            w2, [x3, #0x37]
    // 0xd2e574: DecompressPointer r2
    //     0xd2e574: add             x2, x2, HEAP, lsl #32
    // 0xd2e578: stur            x2, [fp, #-8]
    // 0xd2e57c: r0 = _ShapeBorderPaint()
    //     0xd2e57c: bl              #0xd2e6c0  ; Allocate_ShapeBorderPaintStub -> _ShapeBorderPaint (size=0x18)
    // 0xd2e580: ldur            x1, [fp, #-0x20]
    // 0xd2e584: stur            x0, [fp, #-0x10]
    // 0xd2e588: StoreField: r0->field_b = r1
    //     0xd2e588: stur            w1, [x0, #0xb]
    // 0xd2e58c: ldur            x2, [fp, #-0x18]
    // 0xd2e590: StoreField: r0->field_f = r2
    //     0xd2e590: stur            w2, [x0, #0xf]
    // 0xd2e594: r1 = true
    //     0xd2e594: add             x1, NULL, #0x20  ; true
    // 0xd2e598: StoreField: r0->field_13 = r1
    //     0xd2e598: stur            w1, [x0, #0x13]
    // 0xd2e59c: r0 = ClipPath()
    //     0xd2e59c: bl              #0xb27f2c  ; AllocateClipPathStub -> ClipPath (size=0x18)
    // 0xd2e5a0: mov             x1, x0
    // 0xd2e5a4: ldur            x0, [fp, #-0x38]
    // 0xd2e5a8: StoreField: r1->field_f = r0
    //     0xd2e5a8: stur            w0, [x1, #0xf]
    // 0xd2e5ac: ldur            x0, [fp, #-8]
    // 0xd2e5b0: StoreField: r1->field_13 = r0
    //     0xd2e5b0: stur            w0, [x1, #0x13]
    // 0xd2e5b4: ldur            x0, [fp, #-0x10]
    // 0xd2e5b8: StoreField: r1->field_b = r0
    //     0xd2e5b8: stur            w0, [x1, #0xb]
    // 0xd2e5bc: mov             x0, x1
    // 0xd2e5c0: LeaveFrame
    //     0xd2e5c0: mov             SP, fp
    //     0xd2e5c4: ldp             fp, lr, [SP], #0x10
    // 0xd2e5c8: ret
    //     0xd2e5c8: ret             
    // 0xd2e5cc: mov             x1, x5
    // 0xd2e5d0: LoadField: r4 = r0->field_33
    //     0xd2e5d0: ldur            w4, [x0, #0x33]
    // 0xd2e5d4: DecompressPointer r4
    //     0xd2e5d4: add             x4, x4, HEAP, lsl #32
    // 0xd2e5d8: stur            x4, [fp, #-0x38]
    // 0xd2e5dc: LoadField: r5 = r0->field_37
    //     0xd2e5dc: ldur            w5, [x0, #0x37]
    // 0xd2e5e0: DecompressPointer r5
    //     0xd2e5e0: add             x5, x5, HEAP, lsl #32
    // 0xd2e5e4: stur            x5, [fp, #-0x10]
    // 0xd2e5e8: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xd2e5e8: ldur            d0, [x0, #0x17]
    // 0xd2e5ec: stur            d0, [fp, #-0x68]
    // 0xd2e5f0: cmp             w3, NULL
    // 0xd2e5f4: b.eq            #0xd2e68c
    // 0xd2e5f8: LoadField: r7 = r0->field_27
    //     0xd2e5f8: ldur            w7, [x0, #0x27]
    // 0xd2e5fc: DecompressPointer r7
    //     0xd2e5fc: add             x7, x7, HEAP, lsl #32
    // 0xd2e600: stur            x7, [fp, #-8]
    // 0xd2e604: r0 = _MaterialInterior()
    //     0xd2e604: bl              #0xd2e690  ; Allocate_MaterialInteriorStub -> _MaterialInterior (size=0x3c)
    // 0xd2e608: ldur            x1, [fp, #-0x20]
    // 0xd2e60c: ArrayStore: r0[0] = r1  ; List_4
    //     0xd2e60c: stur            w1, [x0, #0x17]
    // 0xd2e610: ldur            x1, [fp, #-0x18]
    // 0xd2e614: StoreField: r0->field_1b = r1
    //     0xd2e614: stur            w1, [x0, #0x1b]
    // 0xd2e618: ldur            x1, [fp, #-0x38]
    // 0xd2e61c: StoreField: r0->field_1f = r1
    //     0xd2e61c: stur            w1, [x0, #0x1f]
    // 0xd2e620: ldur            x1, [fp, #-0x10]
    // 0xd2e624: StoreField: r0->field_23 = r1
    //     0xd2e624: stur            w1, [x0, #0x23]
    // 0xd2e628: ldur            d0, [fp, #-0x68]
    // 0xd2e62c: StoreField: r0->field_27 = d0
    //     0xd2e62c: stur            d0, [x0, #0x27]
    // 0xd2e630: ldur            x1, [fp, #-0x30]
    // 0xd2e634: StoreField: r0->field_2f = r1
    //     0xd2e634: stur            w1, [x0, #0x2f]
    // 0xd2e638: ldur            x1, [fp, #-0x28]
    // 0xd2e63c: StoreField: r0->field_33 = r1
    //     0xd2e63c: stur            w1, [x0, #0x33]
    // 0xd2e640: ldur            x1, [fp, #-8]
    // 0xd2e644: StoreField: r0->field_37 = r1
    //     0xd2e644: stur            w1, [x0, #0x37]
    // 0xd2e648: r1 = Instance_Cubic
    //     0xd2e648: ldr             x1, [PP, #0x5660]  ; [pp+0x5660] Obj!Cubic@129f451
    // 0xd2e64c: StoreField: r0->field_b = r1
    //     0xd2e64c: stur            w1, [x0, #0xb]
    // 0xd2e650: r1 = Instance_Duration
    //     0xd2e650: add             x1, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xd2e654: ldr             x1, [x1, #0x318]
    // 0xd2e658: StoreField: r0->field_f = r1
    //     0xd2e658: stur            w1, [x0, #0xf]
    // 0xd2e65c: LeaveFrame
    //     0xd2e65c: mov             SP, fp
    //     0xd2e660: ldp             fp, lr, [SP], #0x10
    // 0xd2e664: ret
    //     0xd2e664: ret             
    // 0xd2e668: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd2e668: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd2e66c: b               #0xd2e048
    // 0xd2e670: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2e670: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2e674: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2e674: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2e678: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2e678: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2e67c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2e67c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2e680: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2e680: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2e684: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2e684: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2e688: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2e688: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2e68c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd2e68c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, LayoutChangedNotification) {
    // ** addr: 0xd2eab4, size: 0xb4
    // 0xd2eab4: EnterFrame
    //     0xd2eab4: stp             fp, lr, [SP, #-0x10]!
    //     0xd2eab8: mov             fp, SP
    // 0xd2eabc: AllocStack(0x8)
    //     0xd2eabc: sub             SP, SP, #8
    // 0xd2eac0: SetupParameters([dynamic _ /* r0 */])
    //     0xd2eac0: ldr             x0, [fp, #0x18]
    //     0xd2eac4: ldur            w1, [x0, #0x17]
    //     0xd2eac8: add             x1, x1, HEAP, lsl #32
    // 0xd2eacc: CheckStackOverflow
    //     0xd2eacc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd2ead0: cmp             SP, x16
    //     0xd2ead4: b.ls            #0xd2eb58
    // 0xd2ead8: LoadField: r0 = r1->field_f
    //     0xd2ead8: ldur            w0, [x1, #0xf]
    // 0xd2eadc: DecompressPointer r0
    //     0xd2eadc: add             x0, x0, HEAP, lsl #32
    // 0xd2eae0: LoadField: r1 = r0->field_1b
    //     0xd2eae0: ldur            w1, [x0, #0x1b]
    // 0xd2eae4: DecompressPointer r1
    //     0xd2eae4: add             x1, x1, HEAP, lsl #32
    // 0xd2eae8: r0 = _currentElement()
    //     0xd2eae8: bl              #0x859318  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0xd2eaec: cmp             w0, NULL
    // 0xd2eaf0: b.eq            #0xd2eb60
    // 0xd2eaf4: mov             x1, x0
    // 0xd2eaf8: r0 = findRenderObject()
    //     0xd2eaf8: bl              #0x8418fc  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0xd2eafc: mov             x3, x0
    // 0xd2eb00: stur            x3, [fp, #-8]
    // 0xd2eb04: cmp             w3, NULL
    // 0xd2eb08: b.eq            #0xd2eb64
    // 0xd2eb0c: mov             x0, x3
    // 0xd2eb10: r2 = Null
    //     0xd2eb10: mov             x2, NULL
    // 0xd2eb14: r1 = Null
    //     0xd2eb14: mov             x1, NULL
    // 0xd2eb18: r4 = LoadClassIdInstr(r0)
    //     0xd2eb18: ldur            x4, [x0, #-1]
    //     0xd2eb1c: ubfx            x4, x4, #0xc, #0x14
    // 0xd2eb20: r17 = 4958
    //     0xd2eb20: mov             x17, #0x135e
    // 0xd2eb24: cmp             x4, x17
    // 0xd2eb28: b.eq            #0xd2eb40
    // 0xd2eb2c: r8 = _RenderInkFeatures
    //     0xd2eb2c: add             x8, PP, #0x8f, lsl #12  ; [pp+0x8fcc8] Type: _RenderInkFeatures
    //     0xd2eb30: ldr             x8, [x8, #0xcc8]
    // 0xd2eb34: r3 = Null
    //     0xd2eb34: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8fcd0] Null
    //     0xd2eb38: ldr             x3, [x3, #0xcd0]
    // 0xd2eb3c: r0 = DefaultTypeTest()
    //     0xd2eb3c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xd2eb40: ldur            x1, [fp, #-8]
    // 0xd2eb44: r0 = _didChangeLayout()
    //     0xd2eb44: bl              #0xd2eb68  ; [package:flutter/src/material/material.dart] _RenderInkFeatures::_didChangeLayout
    // 0xd2eb48: r0 = false
    //     0xd2eb48: add             x0, NULL, #0x30  ; false
    // 0xd2eb4c: LeaveFrame
    //     0xd2eb4c: mov             SP, fp
    //     0xd2eb50: ldp             fp, lr, [SP], #0x10
    // 0xd2eb54: ret
    //     0xd2eb54: ret             
    // 0xd2eb58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd2eb58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd2eb5c: b               #0xd2ead8
    // 0xd2eb60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2eb60: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2eb64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2eb64: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6151, size: 0x18, field offset: 0xc
//   const constructor, 
class _ShapeBorderPaint extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfbcea0, size: 0x120
    // 0xfbcea0: EnterFrame
    //     0xfbcea0: stp             fp, lr, [SP, #-0x10]!
    //     0xfbcea4: mov             fp, SP
    // 0xfbcea8: AllocStack(0x28)
    //     0xfbcea8: sub             SP, SP, #0x28
    // 0xfbceac: SetupParameters(_ShapeBorderPaint this /* r1 => r2, fp-0x18 */, dynamic _ /* r2 => r0, fp-0x20 */)
    //     0xfbceac: mov             x0, x2
    //     0xfbceb0: stur            x2, [fp, #-0x20]
    //     0xfbceb4: mov             x2, x1
    //     0xfbceb8: stur            x1, [fp, #-0x18]
    // 0xfbcebc: CheckStackOverflow
    //     0xfbcebc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbcec0: cmp             SP, x16
    //     0xfbcec4: b.ls            #0xfbcfb8
    // 0xfbcec8: LoadField: r3 = r2->field_13
    //     0xfbcec8: ldur            w3, [x2, #0x13]
    // 0xfbcecc: DecompressPointer r3
    //     0xfbcecc: add             x3, x3, HEAP, lsl #32
    // 0xfbced0: stur            x3, [fp, #-0x10]
    // 0xfbced4: tbnz            w3, #4, #0xfbcee4
    // 0xfbced8: mov             x0, x3
    // 0xfbcedc: r2 = Null
    //     0xfbcedc: mov             x2, NULL
    // 0xfbcee0: b               #0xfbcf1c
    // 0xfbcee4: LoadField: r4 = r2->field_f
    //     0xfbcee4: ldur            w4, [x2, #0xf]
    // 0xfbcee8: DecompressPointer r4
    //     0xfbcee8: add             x4, x4, HEAP, lsl #32
    // 0xfbceec: mov             x1, x0
    // 0xfbcef0: stur            x4, [fp, #-8]
    // 0xfbcef4: r0 = maybeOf()
    //     0xfbcef4: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xfbcef8: stur            x0, [fp, #-0x28]
    // 0xfbcefc: r0 = _ShapeBorderPainter()
    //     0xfbcefc: bl              #0xfbcfc0  ; Allocate_ShapeBorderPainterStub -> _ShapeBorderPainter (size=0x14)
    // 0xfbcf00: mov             x1, x0
    // 0xfbcf04: ldur            x0, [fp, #-8]
    // 0xfbcf08: StoreField: r1->field_b = r0
    //     0xfbcf08: stur            w0, [x1, #0xb]
    // 0xfbcf0c: ldur            x0, [fp, #-0x28]
    // 0xfbcf10: StoreField: r1->field_f = r0
    //     0xfbcf10: stur            w0, [x1, #0xf]
    // 0xfbcf14: mov             x2, x1
    // 0xfbcf18: ldur            x0, [fp, #-0x10]
    // 0xfbcf1c: stur            x2, [fp, #-0x28]
    // 0xfbcf20: tbnz            w0, #4, #0xfbcf60
    // 0xfbcf24: ldur            x0, [fp, #-0x18]
    // 0xfbcf28: LoadField: r3 = r0->field_f
    //     0xfbcf28: ldur            w3, [x0, #0xf]
    // 0xfbcf2c: DecompressPointer r3
    //     0xfbcf2c: add             x3, x3, HEAP, lsl #32
    // 0xfbcf30: ldur            x1, [fp, #-0x20]
    // 0xfbcf34: stur            x3, [fp, #-8]
    // 0xfbcf38: r0 = maybeOf()
    //     0xfbcf38: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xfbcf3c: stur            x0, [fp, #-0x10]
    // 0xfbcf40: r0 = _ShapeBorderPainter()
    //     0xfbcf40: bl              #0xfbcfc0  ; Allocate_ShapeBorderPainterStub -> _ShapeBorderPainter (size=0x14)
    // 0xfbcf44: mov             x1, x0
    // 0xfbcf48: ldur            x0, [fp, #-8]
    // 0xfbcf4c: StoreField: r1->field_b = r0
    //     0xfbcf4c: stur            w0, [x1, #0xb]
    // 0xfbcf50: ldur            x0, [fp, #-0x10]
    // 0xfbcf54: StoreField: r1->field_f = r0
    //     0xfbcf54: stur            w0, [x1, #0xf]
    // 0xfbcf58: mov             x2, x1
    // 0xfbcf5c: b               #0xfbcf64
    // 0xfbcf60: r2 = Null
    //     0xfbcf60: mov             x2, NULL
    // 0xfbcf64: ldur            x1, [fp, #-0x18]
    // 0xfbcf68: ldur            x0, [fp, #-0x28]
    // 0xfbcf6c: stur            x2, [fp, #-0x10]
    // 0xfbcf70: LoadField: r3 = r1->field_b
    //     0xfbcf70: ldur            w3, [x1, #0xb]
    // 0xfbcf74: DecompressPointer r3
    //     0xfbcf74: add             x3, x3, HEAP, lsl #32
    // 0xfbcf78: stur            x3, [fp, #-8]
    // 0xfbcf7c: r0 = CustomPaint()
    //     0xfbcf7c: bl              #0xd0a594  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0xfbcf80: ldur            x1, [fp, #-0x28]
    // 0xfbcf84: StoreField: r0->field_f = r1
    //     0xfbcf84: stur            w1, [x0, #0xf]
    // 0xfbcf88: ldur            x1, [fp, #-0x10]
    // 0xfbcf8c: StoreField: r0->field_13 = r1
    //     0xfbcf8c: stur            w1, [x0, #0x13]
    // 0xfbcf90: r1 = Instance_Size
    //     0xfbcf90: ldr             x1, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xfbcf94: ArrayStore: r0[0] = r1  ; List_4
    //     0xfbcf94: stur            w1, [x0, #0x17]
    // 0xfbcf98: r1 = false
    //     0xfbcf98: add             x1, NULL, #0x30  ; false
    // 0xfbcf9c: StoreField: r0->field_1b = r1
    //     0xfbcf9c: stur            w1, [x0, #0x1b]
    // 0xfbcfa0: StoreField: r0->field_1f = r1
    //     0xfbcfa0: stur            w1, [x0, #0x1f]
    // 0xfbcfa4: ldur            x1, [fp, #-8]
    // 0xfbcfa8: StoreField: r0->field_b = r1
    //     0xfbcfa8: stur            w1, [x0, #0xb]
    // 0xfbcfac: LeaveFrame
    //     0xfbcfac: mov             SP, fp
    //     0xfbcfb0: ldp             fp, lr, [SP], #0x10
    // 0xfbcfb4: ret
    //     0xfbcfb4: ret             
    // 0xfbcfb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbcfb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbcfbc: b               #0xfbcec8
  }
}

// class id: 6466, size: 0x3c, field offset: 0x18
//   const constructor, 
class _MaterialInterior extends ImplicitlyAnimatedWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa1e50, size: 0x30
    // 0xfa1e50: EnterFrame
    //     0xfa1e50: stp             fp, lr, [SP, #-0x10]!
    //     0xfa1e54: mov             fp, SP
    // 0xfa1e58: mov             x0, x1
    // 0xfa1e5c: r1 = <_MaterialInterior>
    //     0xfa1e5c: add             x1, PP, #0x99, lsl #12  ; [pp+0x992b0] TypeArguments: <_MaterialInterior>
    //     0xfa1e60: ldr             x1, [x1, #0x2b0]
    // 0xfa1e64: r0 = _MaterialInteriorState()
    //     0xfa1e64: bl              #0xfa1e80  ; Allocate_MaterialInteriorStateStub -> _MaterialInteriorState (size=0x34)
    // 0xfa1e68: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa1e6c: StoreField: r0->field_1b = r1
    //     0xfa1e6c: stur            w1, [x0, #0x1b]
    // 0xfa1e70: StoreField: r0->field_1f = r1
    //     0xfa1e70: stur            w1, [x0, #0x1f]
    // 0xfa1e74: LeaveFrame
    //     0xfa1e74: mov             SP, fp
    //     0xfa1e78: ldp             fp, lr, [SP], #0x10
    // 0xfa1e7c: ret
    //     0xfa1e7c: ret             
  }
}

// class id: 6467, size: 0x44, field offset: 0xc
//   const constructor, 
class Material extends StatefulWidget {

  MaterialType field_10;
  bool field_14;
  _Mint field_18;
  bool field_34;
  Clip field_38;
  Duration field_3c;

  static _ of(/* No info */) {
    // ** addr: 0xd21e38, size: 0x38
    // 0xd21e38: EnterFrame
    //     0xd21e38: stp             fp, lr, [SP, #-0x10]!
    //     0xd21e3c: mov             fp, SP
    // 0xd21e40: CheckStackOverflow
    //     0xd21e40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd21e44: cmp             SP, x16
    //     0xd21e48: b.ls            #0xd21e64
    // 0xd21e4c: r0 = maybeOf()
    //     0xd21e4c: bl              #0xd21e70  ; [package:flutter/src/material/material.dart] Material::maybeOf
    // 0xd21e50: cmp             w0, NULL
    // 0xd21e54: b.eq            #0xd21e6c
    // 0xd21e58: LeaveFrame
    //     0xd21e58: mov             SP, fp
    //     0xd21e5c: ldp             fp, lr, [SP], #0x10
    // 0xd21e60: ret
    //     0xd21e60: ret             
    // 0xd21e64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd21e64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd21e68: b               #0xd21e4c
    // 0xd21e6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd21e6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ maybeOf(/* No info */) {
    // ** addr: 0xd21e70, size: 0x40
    // 0xd21e70: EnterFrame
    //     0xd21e70: stp             fp, lr, [SP, #-0x10]!
    //     0xd21e74: mov             fp, SP
    // 0xd21e78: AllocStack(0x10)
    //     0xd21e78: sub             SP, SP, #0x10
    // 0xd21e7c: CheckStackOverflow
    //     0xd21e7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd21e80: cmp             SP, x16
    //     0xd21e84: b.ls            #0xd21ea8
    // 0xd21e88: r16 = <_RenderInkFeatures>
    //     0xd21e88: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c6e0] TypeArguments: <_RenderInkFeatures>
    //     0xd21e8c: ldr             x16, [x16, #0x6e0]
    // 0xd21e90: stp             x1, x16, [SP]
    // 0xd21e94: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd21e94: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd21e98: r0 = findAncestorRenderObjectOfType()
    //     0xd21e98: bl              #0xd21eb0  ; [package:flutter/src/widgets/lookup_boundary.dart] LookupBoundary::findAncestorRenderObjectOfType
    // 0xd21e9c: LeaveFrame
    //     0xd21e9c: mov             SP, fp
    //     0xd21ea0: ldp             fp, lr, [SP], #0x10
    // 0xd21ea4: ret
    //     0xd21ea4: ret             
    // 0xd21ea8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd21ea8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd21eac: b               #0xd21e88
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa1df8, size: 0x4c
    // 0xfa1df8: EnterFrame
    //     0xfa1df8: stp             fp, lr, [SP, #-0x10]!
    //     0xfa1dfc: mov             fp, SP
    // 0xfa1e00: AllocStack(0x8)
    //     0xfa1e00: sub             SP, SP, #8
    // 0xfa1e04: SetupParameters(Material this /* r1 => r0 */)
    //     0xfa1e04: mov             x0, x1
    // 0xfa1e08: r1 = <State<StatefulWidget>>
    //     0xfa1e08: ldr             x1, [PP, #0x4df8]  ; [pp+0x4df8] TypeArguments: <State<StatefulWidget>>
    // 0xfa1e0c: r0 = LabeledGlobalKey()
    //     0xfa1e0c: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa1e10: mov             x2, x0
    // 0xfa1e14: r0 = "ink renderer"
    //     0xfa1e14: add             x0, PP, #0x84, lsl #12  ; [pp+0x849e0] "ink renderer"
    //     0xfa1e18: ldr             x0, [x0, #0x9e0]
    // 0xfa1e1c: stur            x2, [fp, #-8]
    // 0xfa1e20: StoreField: r2->field_b = r0
    //     0xfa1e20: stur            w0, [x2, #0xb]
    // 0xfa1e24: r1 = <Material>
    //     0xfa1e24: add             x1, PP, #0x84, lsl #12  ; [pp+0x849e8] TypeArguments: <Material>
    //     0xfa1e28: ldr             x1, [x1, #0x9e8]
    // 0xfa1e2c: r0 = _MaterialState()
    //     0xfa1e2c: bl              #0xfa1e44  ; Allocate_MaterialStateStub -> _MaterialState (size=0x20)
    // 0xfa1e30: ldur            x1, [fp, #-8]
    // 0xfa1e34: StoreField: r0->field_1b = r1
    //     0xfa1e34: stur            w1, [x0, #0x1b]
    // 0xfa1e38: LeaveFrame
    //     0xfa1e38: mov             SP, fp
    //     0xfa1e3c: ldp             fp, lr, [SP], #0x10
    // 0xfa1e40: ret
    //     0xfa1e40: ret             
  }
}

// class id: 6652, size: 0x1c, field offset: 0x10
//   const constructor, 
class _InkFeatures extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf4b94, size: 0xa0
    // 0xcf4b94: EnterFrame
    //     0xcf4b94: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4b98: mov             fp, SP
    // 0xcf4b9c: AllocStack(0x10)
    //     0xcf4b9c: sub             SP, SP, #0x10
    // 0xcf4ba0: SetupParameters(_InkFeatures this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4 */, dynamic _ /* r3 => r0, fp-0x10 */)
    //     0xcf4ba0: mov             x0, x3
    //     0xcf4ba4: mov             x5, x1
    //     0xcf4ba8: mov             x4, x2
    //     0xcf4bac: stur            x1, [fp, #-8]
    //     0xcf4bb0: stur            x3, [fp, #-0x10]
    // 0xcf4bb4: r2 = Null
    //     0xcf4bb4: mov             x2, NULL
    // 0xcf4bb8: r1 = Null
    //     0xcf4bb8: mov             x1, NULL
    // 0xcf4bbc: r4 = 60
    //     0xcf4bbc: mov             x4, #0x3c
    // 0xcf4bc0: branchIfSmi(r0, 0xcf4bcc)
    //     0xcf4bc0: tbz             w0, #0, #0xcf4bcc
    // 0xcf4bc4: r4 = LoadClassIdInstr(r0)
    //     0xcf4bc4: ldur            x4, [x0, #-1]
    //     0xcf4bc8: ubfx            x4, x4, #0xc, #0x14
    // 0xcf4bcc: r17 = 4958
    //     0xcf4bcc: mov             x17, #0x135e
    // 0xcf4bd0: cmp             x4, x17
    // 0xcf4bd4: b.eq            #0xcf4bec
    // 0xcf4bd8: r8 = _RenderInkFeatures
    //     0xcf4bd8: add             x8, PP, #0x8f, lsl #12  ; [pp+0x8fcc8] Type: _RenderInkFeatures
    //     0xcf4bdc: ldr             x8, [x8, #0xcc8]
    // 0xcf4be0: r3 = Null
    //     0xcf4be0: add             x3, PP, #0x99, lsl #12  ; [pp+0x992b8] Null
    //     0xcf4be4: ldr             x3, [x3, #0x2b8]
    // 0xcf4be8: r0 = DefaultTypeTest()
    //     0xcf4be8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf4bec: ldur            x1, [fp, #-8]
    // 0xcf4bf0: LoadField: r0 = r1->field_f
    //     0xcf4bf0: ldur            w0, [x1, #0xf]
    // 0xcf4bf4: DecompressPointer r0
    //     0xcf4bf4: add             x0, x0, HEAP, lsl #32
    // 0xcf4bf8: ldur            x2, [fp, #-0x10]
    // 0xcf4bfc: StoreField: r2->field_57 = r0
    //     0xcf4bfc: stur            w0, [x2, #0x57]
    //     0xcf4c00: ldurb           w16, [x2, #-1]
    //     0xcf4c04: ldurb           w17, [x0, #-1]
    //     0xcf4c08: and             x16, x17, x16, lsr #2
    //     0xcf4c0c: tst             x16, HEAP, lsr #32
    //     0xcf4c10: b.eq            #0xcf4c18
    //     0xcf4c14: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf4c18: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xcf4c18: ldur            w3, [x1, #0x17]
    // 0xcf4c1c: DecompressPointer r3
    //     0xcf4c1c: add             x3, x3, HEAP, lsl #32
    // 0xcf4c20: StoreField: r2->field_5b = r3
    //     0xcf4c20: stur            w3, [x2, #0x5b]
    // 0xcf4c24: r0 = Null
    //     0xcf4c24: mov             x0, NULL
    // 0xcf4c28: LeaveFrame
    //     0xcf4c28: mov             SP, fp
    //     0xcf4c2c: ldp             fp, lr, [SP], #0x10
    // 0xcf4c30: ret
    //     0xcf4c30: ret             
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11cfa50, size: 0x70
    // 0x11cfa50: EnterFrame
    //     0x11cfa50: stp             fp, lr, [SP, #-0x10]!
    //     0x11cfa54: mov             fp, SP
    // 0x11cfa58: AllocStack(0x18)
    //     0x11cfa58: sub             SP, SP, #0x18
    // 0x11cfa5c: CheckStackOverflow
    //     0x11cfa5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cfa60: cmp             SP, x16
    //     0x11cfa64: b.ls            #0x11cfab8
    // 0x11cfa68: LoadField: r3 = r1->field_f
    //     0x11cfa68: ldur            w3, [x1, #0xf]
    // 0x11cfa6c: DecompressPointer r3
    //     0x11cfa6c: add             x3, x3, HEAP, lsl #32
    // 0x11cfa70: stur            x3, [fp, #-0x18]
    // 0x11cfa74: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x11cfa74: ldur            w2, [x1, #0x17]
    // 0x11cfa78: DecompressPointer r2
    //     0x11cfa78: add             x2, x2, HEAP, lsl #32
    // 0x11cfa7c: stur            x2, [fp, #-0x10]
    // 0x11cfa80: LoadField: r5 = r1->field_13
    //     0x11cfa80: ldur            w5, [x1, #0x13]
    // 0x11cfa84: DecompressPointer r5
    //     0x11cfa84: add             x5, x5, HEAP, lsl #32
    // 0x11cfa88: stur            x5, [fp, #-8]
    // 0x11cfa8c: r0 = _RenderInkFeatures()
    //     0x11cfa8c: bl              #0x11cfb7c  ; Allocate_RenderInkFeaturesStub -> _RenderInkFeatures (size=0x64)
    // 0x11cfa90: mov             x1, x0
    // 0x11cfa94: ldur            x2, [fp, #-0x10]
    // 0x11cfa98: ldur            x3, [fp, #-0x18]
    // 0x11cfa9c: ldur            x5, [fp, #-8]
    // 0x11cfaa0: stur            x0, [fp, #-8]
    // 0x11cfaa4: r0 = _RenderInkFeatures()
    //     0x11cfaa4: bl              #0x11cfac0  ; [package:flutter/src/material/material.dart] _RenderInkFeatures::_RenderInkFeatures
    // 0x11cfaa8: ldur            x0, [fp, #-8]
    // 0x11cfaac: LeaveFrame
    //     0x11cfaac: mov             SP, fp
    //     0x11cfab0: ldp             fp, lr, [SP], #0x10
    // 0x11cfab4: ret
    //     0x11cfab4: ret             
    // 0x11cfab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cfab8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cfabc: b               #0x11cfa68
  }
}

// class id: 8279, size: 0x14, field offset: 0x14
enum MaterialType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa418, size: 0x64
    // 0x11aa418: EnterFrame
    //     0x11aa418: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa41c: mov             fp, SP
    // 0x11aa420: AllocStack(0x10)
    //     0x11aa420: sub             SP, SP, #0x10
    // 0x11aa424: SetupParameters(MaterialType this /* r1 => r0, fp-0x8 */)
    //     0x11aa424: mov             x0, x1
    //     0x11aa428: stur            x1, [fp, #-8]
    // 0x11aa42c: CheckStackOverflow
    //     0x11aa42c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa430: cmp             SP, x16
    //     0x11aa434: b.ls            #0x11aa474
    // 0x11aa438: r1 = Null
    //     0x11aa438: mov             x1, NULL
    // 0x11aa43c: r2 = 4
    //     0x11aa43c: mov             x2, #4
    // 0x11aa440: r0 = AllocateArray()
    //     0x11aa440: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa444: r16 = "MaterialType."
    //     0x11aa444: add             x16, PP, #0x84, lsl #12  ; [pp+0x849f0] "MaterialType."
    //     0x11aa448: ldr             x16, [x16, #0x9f0]
    // 0x11aa44c: StoreField: r0->field_f = r16
    //     0x11aa44c: stur            w16, [x0, #0xf]
    // 0x11aa450: ldur            x1, [fp, #-8]
    // 0x11aa454: LoadField: r2 = r1->field_f
    //     0x11aa454: ldur            w2, [x1, #0xf]
    // 0x11aa458: DecompressPointer r2
    //     0x11aa458: add             x2, x2, HEAP, lsl #32
    // 0x11aa45c: StoreField: r0->field_13 = r2
    //     0x11aa45c: stur            w2, [x0, #0x13]
    // 0x11aa460: str             x0, [SP]
    // 0x11aa464: r0 = _interpolate()
    //     0x11aa464: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa468: LeaveFrame
    //     0x11aa468: mov             SP, fp
    //     0x11aa46c: ldp             fp, lr, [SP], #0x10
    // 0x11aa470: ret
    //     0x11aa470: ret             
    // 0x11aa474: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa474: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa478: b               #0x11aa438
  }
}
