// lib: , url: package:flutter/src/material/card.dart

// class id: 1048861, size: 0x8
class :: {
}

// class id: 5178, size: 0x2c, field offset: 0x24
class _OutlinedCardDefaultsM3 extends CardThemeData {

  late final ColorScheme _colors; // offset: 0x28

  get _ shape(/* No info */) {
    // ** addr: 0x124a69c, size: 0xb4
    // 0x124a69c: EnterFrame
    //     0x124a69c: stp             fp, lr, [SP, #-0x10]!
    //     0x124a6a0: mov             fp, SP
    // 0x124a6a4: AllocStack(0x8)
    //     0x124a6a4: sub             SP, SP, #8
    // 0x124a6a8: CheckStackOverflow
    //     0x124a6a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124a6ac: cmp             SP, x16
    //     0x124a6b0: b.ls            #0x124a748
    // 0x124a6b4: LoadField: r0 = r1->field_27
    //     0x124a6b4: ldur            w0, [x1, #0x27]
    // 0x124a6b8: DecompressPointer r0
    //     0x124a6b8: add             x0, x0, HEAP, lsl #32
    // 0x124a6bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124a6c0: cmp             w0, w16
    // 0x124a6c4: b.ne            #0x124a6d4
    // 0x124a6c8: r2 = _colors
    //     0x124a6c8: add             x2, PP, #0x95, lsl #12  ; [pp+0x95e30] Field <_OutlinedCardDefaultsM3@730090606._colors@730090606>: late final (offset: 0x28)
    //     0x124a6cc: ldr             x2, [x2, #0xe30]
    // 0x124a6d0: r0 = InitLateFinalInstanceField()
    //     0x124a6d0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x124a6d4: LoadField: r1 = r0->field_ab
    //     0x124a6d4: ldur            w1, [x0, #0xab]
    // 0x124a6d8: DecompressPointer r1
    //     0x124a6d8: add             x1, x1, HEAP, lsl #32
    // 0x124a6dc: cmp             w1, NULL
    // 0x124a6e0: b.ne            #0x124a6f4
    // 0x124a6e4: LoadField: r1 = r0->field_cb
    //     0x124a6e4: ldur            w1, [x0, #0xcb]
    // 0x124a6e8: DecompressPointer r1
    //     0x124a6e8: add             x1, x1, HEAP, lsl #32
    // 0x124a6ec: mov             x0, x1
    // 0x124a6f0: b               #0x124a6f8
    // 0x124a6f4: mov             x0, x1
    // 0x124a6f8: stur            x0, [fp, #-8]
    // 0x124a6fc: r0 = BorderSide()
    //     0x124a6fc: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x124a700: mov             x1, x0
    // 0x124a704: ldur            x0, [fp, #-8]
    // 0x124a708: StoreField: r1->field_7 = r0
    //     0x124a708: stur            w0, [x1, #7]
    // 0x124a70c: d0 = 1.000000
    //     0x124a70c: fmov            d0, #1.00000000
    // 0x124a710: StoreField: r1->field_b = d0
    //     0x124a710: stur            d0, [x1, #0xb]
    // 0x124a714: r0 = Instance_BorderStyle
    //     0x124a714: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x124a718: ldr             x0, [x0, #0xdc8]
    // 0x124a71c: StoreField: r1->field_13 = r0
    //     0x124a71c: stur            w0, [x1, #0x13]
    // 0x124a720: d0 = -1.000000
    //     0x124a720: fmov            d0, #-1.00000000
    // 0x124a724: ArrayStore: r1[0] = d0  ; List_8
    //     0x124a724: stur            d0, [x1, #0x17]
    // 0x124a728: mov             x2, x1
    // 0x124a72c: r1 = Instance_RoundedRectangleBorder
    //     0x124a72c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26368] Obj!RoundedRectangleBorder@129ec81
    //     0x124a730: ldr             x1, [x1, #0x368]
    // 0x124a734: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x124a734: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x124a738: r0 = copyWith()
    //     0x124a738: bl              #0x1301674  ; [package:flutter/src/painting/rounded_rectangle_border.dart] RoundedRectangleBorder::copyWith
    // 0x124a73c: LeaveFrame
    //     0x124a73c: mov             SP, fp
    //     0x124a740: ldp             fp, lr, [SP], #0x10
    // 0x124a744: ret
    //     0x124a744: ret             
    // 0x124a748: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124a748: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124a74c: b               #0x124a6b4
  }
  get _ color(/* No info */) {
    // ** addr: 0x124aa34, size: 0x54
    // 0x124aa34: EnterFrame
    //     0x124aa34: stp             fp, lr, [SP, #-0x10]!
    //     0x124aa38: mov             fp, SP
    // 0x124aa3c: CheckStackOverflow
    //     0x124aa3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124aa40: cmp             SP, x16
    //     0x124aa44: b.ls            #0x124aa80
    // 0x124aa48: LoadField: r0 = r1->field_27
    //     0x124aa48: ldur            w0, [x1, #0x27]
    // 0x124aa4c: DecompressPointer r0
    //     0x124aa4c: add             x0, x0, HEAP, lsl #32
    // 0x124aa50: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124aa54: cmp             w0, w16
    // 0x124aa58: b.ne            #0x124aa68
    // 0x124aa5c: r2 = _colors
    //     0x124aa5c: add             x2, PP, #0x95, lsl #12  ; [pp+0x95e30] Field <_OutlinedCardDefaultsM3@730090606._colors@730090606>: late final (offset: 0x28)
    //     0x124aa60: ldr             x2, [x2, #0xe30]
    // 0x124aa64: r0 = InitLateFinalInstanceField()
    //     0x124aa64: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x124aa68: LoadField: r1 = r0->field_7b
    //     0x124aa68: ldur            w1, [x0, #0x7b]
    // 0x124aa6c: DecompressPointer r1
    //     0x124aa6c: add             x1, x1, HEAP, lsl #32
    // 0x124aa70: mov             x0, x1
    // 0x124aa74: LeaveFrame
    //     0x124aa74: mov             SP, fp
    //     0x124aa78: ldp             fp, lr, [SP], #0x10
    // 0x124aa7c: ret
    //     0x124aa7c: ret             
    // 0x124aa80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124aa80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124aa84: b               #0x124aa48
  }
  get _ shadowColor(/* No info */) {
    // ** addr: 0x124ab9c, size: 0x68
    // 0x124ab9c: EnterFrame
    //     0x124ab9c: stp             fp, lr, [SP, #-0x10]!
    //     0x124aba0: mov             fp, SP
    // 0x124aba4: CheckStackOverflow
    //     0x124aba4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124aba8: cmp             SP, x16
    //     0x124abac: b.ls            #0x124abfc
    // 0x124abb0: LoadField: r0 = r1->field_27
    //     0x124abb0: ldur            w0, [x1, #0x27]
    // 0x124abb4: DecompressPointer r0
    //     0x124abb4: add             x0, x0, HEAP, lsl #32
    // 0x124abb8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124abbc: cmp             w0, w16
    // 0x124abc0: b.ne            #0x124abd0
    // 0x124abc4: r2 = _colors
    //     0x124abc4: add             x2, PP, #0x95, lsl #12  ; [pp+0x95e30] Field <_OutlinedCardDefaultsM3@730090606._colors@730090606>: late final (offset: 0x28)
    //     0x124abc8: ldr             x2, [x2, #0xe30]
    // 0x124abcc: r0 = InitLateFinalInstanceField()
    //     0x124abcc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x124abd0: LoadField: r1 = r0->field_af
    //     0x124abd0: ldur            w1, [x0, #0xaf]
    // 0x124abd4: DecompressPointer r1
    //     0x124abd4: add             x1, x1, HEAP, lsl #32
    // 0x124abd8: cmp             w1, NULL
    // 0x124abdc: b.ne            #0x124abec
    // 0x124abe0: r0 = Instance_Color
    //     0x124abe0: add             x0, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x124abe4: ldr             x0, [x0, #0x948]
    // 0x124abe8: b               #0x124abf0
    // 0x124abec: mov             x0, x1
    // 0x124abf0: LeaveFrame
    //     0x124abf0: mov             SP, fp
    //     0x124abf4: ldp             fp, lr, [SP], #0x10
    // 0x124abf8: ret
    //     0x124abf8: ret             
    // 0x124abfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124abfc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124ac00: b               #0x124abb0
  }
}

// class id: 5179, size: 0x2c, field offset: 0x24
class _FilledCardDefaultsM3 extends CardThemeData {

  late final ColorScheme _colors; // offset: 0x28

  get _ shape(/* No info */) {
    // ** addr: 0x124a690, size: 0xc
    // 0x124a690: r0 = Instance_RoundedRectangleBorder
    //     0x124a690: add             x0, PP, #0x26, lsl #12  ; [pp+0x26368] Obj!RoundedRectangleBorder@129ec81
    //     0x124a694: ldr             x0, [x0, #0x368]
    // 0x124a698: ret
    //     0x124a698: ret             
  }
  get _ color(/* No info */) {
    // ** addr: 0x124a9c8, size: 0x6c
    // 0x124a9c8: EnterFrame
    //     0x124a9c8: stp             fp, lr, [SP, #-0x10]!
    //     0x124a9cc: mov             fp, SP
    // 0x124a9d0: CheckStackOverflow
    //     0x124a9d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124a9d4: cmp             SP, x16
    //     0x124a9d8: b.ls            #0x124aa2c
    // 0x124a9dc: LoadField: r0 = r1->field_27
    //     0x124a9dc: ldur            w0, [x1, #0x27]
    // 0x124a9e0: DecompressPointer r0
    //     0x124a9e0: add             x0, x0, HEAP, lsl #32
    // 0x124a9e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124a9e8: cmp             w0, w16
    // 0x124a9ec: b.ne            #0x124a9fc
    // 0x124a9f0: r2 = _colors
    //     0x124a9f0: add             x2, PP, #0x95, lsl #12  ; [pp+0x95e40] Field <_FilledCardDefaultsM3@730090606._colors@730090606>: late final (offset: 0x28)
    //     0x124a9f4: ldr             x2, [x2, #0xe40]
    // 0x124a9f8: r0 = InitLateFinalInstanceField()
    //     0x124a9f8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x124a9fc: LoadField: r1 = r0->field_9f
    //     0x124a9fc: ldur            w1, [x0, #0x9f]
    // 0x124aa00: DecompressPointer r1
    //     0x124aa00: add             x1, x1, HEAP, lsl #32
    // 0x124aa04: cmp             w1, NULL
    // 0x124aa08: b.ne            #0x124aa1c
    // 0x124aa0c: LoadField: r2 = r0->field_7b
    //     0x124aa0c: ldur            w2, [x0, #0x7b]
    // 0x124aa10: DecompressPointer r2
    //     0x124aa10: add             x2, x2, HEAP, lsl #32
    // 0x124aa14: mov             x0, x2
    // 0x124aa18: b               #0x124aa20
    // 0x124aa1c: mov             x0, x1
    // 0x124aa20: LeaveFrame
    //     0x124aa20: mov             SP, fp
    //     0x124aa24: ldp             fp, lr, [SP], #0x10
    // 0x124aa28: ret
    //     0x124aa28: ret             
    // 0x124aa2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124aa2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124aa30: b               #0x124a9dc
  }
  get _ shadowColor(/* No info */) {
    // ** addr: 0x124ab34, size: 0x68
    // 0x124ab34: EnterFrame
    //     0x124ab34: stp             fp, lr, [SP, #-0x10]!
    //     0x124ab38: mov             fp, SP
    // 0x124ab3c: CheckStackOverflow
    //     0x124ab3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124ab40: cmp             SP, x16
    //     0x124ab44: b.ls            #0x124ab94
    // 0x124ab48: LoadField: r0 = r1->field_27
    //     0x124ab48: ldur            w0, [x1, #0x27]
    // 0x124ab4c: DecompressPointer r0
    //     0x124ab4c: add             x0, x0, HEAP, lsl #32
    // 0x124ab50: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124ab54: cmp             w0, w16
    // 0x124ab58: b.ne            #0x124ab68
    // 0x124ab5c: r2 = _colors
    //     0x124ab5c: add             x2, PP, #0x95, lsl #12  ; [pp+0x95e40] Field <_FilledCardDefaultsM3@730090606._colors@730090606>: late final (offset: 0x28)
    //     0x124ab60: ldr             x2, [x2, #0xe40]
    // 0x124ab64: r0 = InitLateFinalInstanceField()
    //     0x124ab64: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x124ab68: LoadField: r1 = r0->field_af
    //     0x124ab68: ldur            w1, [x0, #0xaf]
    // 0x124ab6c: DecompressPointer r1
    //     0x124ab6c: add             x1, x1, HEAP, lsl #32
    // 0x124ab70: cmp             w1, NULL
    // 0x124ab74: b.ne            #0x124ab84
    // 0x124ab78: r0 = Instance_Color
    //     0x124ab78: add             x0, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x124ab7c: ldr             x0, [x0, #0x948]
    // 0x124ab80: b               #0x124ab88
    // 0x124ab84: mov             x0, x1
    // 0x124ab88: LeaveFrame
    //     0x124ab88: mov             SP, fp
    //     0x124ab8c: ldp             fp, lr, [SP], #0x10
    // 0x124ab90: ret
    //     0x124ab90: ret             
    // 0x124ab94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124ab94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124ab98: b               #0x124ab48
  }
}

// class id: 5180, size: 0x2c, field offset: 0x24
class _CardDefaultsM3 extends CardThemeData {

  late final ColorScheme _colors; // offset: 0x28

  get _ color(/* No info */) {
    // ** addr: 0x124a95c, size: 0x6c
    // 0x124a95c: EnterFrame
    //     0x124a95c: stp             fp, lr, [SP, #-0x10]!
    //     0x124a960: mov             fp, SP
    // 0x124a964: CheckStackOverflow
    //     0x124a964: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124a968: cmp             SP, x16
    //     0x124a96c: b.ls            #0x124a9c0
    // 0x124a970: LoadField: r0 = r1->field_27
    //     0x124a970: ldur            w0, [x1, #0x27]
    // 0x124a974: DecompressPointer r0
    //     0x124a974: add             x0, x0, HEAP, lsl #32
    // 0x124a978: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124a97c: cmp             w0, w16
    // 0x124a980: b.ne            #0x124a990
    // 0x124a984: r2 = _colors
    //     0x124a984: add             x2, PP, #0x95, lsl #12  ; [pp+0x95e38] Field <_CardDefaultsM3@730090606._colors@730090606>: late final (offset: 0x28)
    //     0x124a988: ldr             x2, [x2, #0xe38]
    // 0x124a98c: r0 = InitLateFinalInstanceField()
    //     0x124a98c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x124a990: LoadField: r1 = r0->field_93
    //     0x124a990: ldur            w1, [x0, #0x93]
    // 0x124a994: DecompressPointer r1
    //     0x124a994: add             x1, x1, HEAP, lsl #32
    // 0x124a998: cmp             w1, NULL
    // 0x124a99c: b.ne            #0x124a9b0
    // 0x124a9a0: LoadField: r2 = r0->field_7b
    //     0x124a9a0: ldur            w2, [x0, #0x7b]
    // 0x124a9a4: DecompressPointer r2
    //     0x124a9a4: add             x2, x2, HEAP, lsl #32
    // 0x124a9a8: mov             x0, x2
    // 0x124a9ac: b               #0x124a9b4
    // 0x124a9b0: mov             x0, x1
    // 0x124a9b4: LeaveFrame
    //     0x124a9b4: mov             SP, fp
    //     0x124a9b8: ldp             fp, lr, [SP], #0x10
    // 0x124a9bc: ret
    //     0x124a9bc: ret             
    // 0x124a9c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124a9c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124a9c4: b               #0x124a970
  }
  get _ shadowColor(/* No info */) {
    // ** addr: 0x124aacc, size: 0x68
    // 0x124aacc: EnterFrame
    //     0x124aacc: stp             fp, lr, [SP, #-0x10]!
    //     0x124aad0: mov             fp, SP
    // 0x124aad4: CheckStackOverflow
    //     0x124aad4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124aad8: cmp             SP, x16
    //     0x124aadc: b.ls            #0x124ab2c
    // 0x124aae0: LoadField: r0 = r1->field_27
    //     0x124aae0: ldur            w0, [x1, #0x27]
    // 0x124aae4: DecompressPointer r0
    //     0x124aae4: add             x0, x0, HEAP, lsl #32
    // 0x124aae8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124aaec: cmp             w0, w16
    // 0x124aaf0: b.ne            #0x124ab00
    // 0x124aaf4: r2 = _colors
    //     0x124aaf4: add             x2, PP, #0x95, lsl #12  ; [pp+0x95e38] Field <_CardDefaultsM3@730090606._colors@730090606>: late final (offset: 0x28)
    //     0x124aaf8: ldr             x2, [x2, #0xe38]
    // 0x124aafc: r0 = InitLateFinalInstanceField()
    //     0x124aafc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x124ab00: LoadField: r1 = r0->field_af
    //     0x124ab00: ldur            w1, [x0, #0xaf]
    // 0x124ab04: DecompressPointer r1
    //     0x124ab04: add             x1, x1, HEAP, lsl #32
    // 0x124ab08: cmp             w1, NULL
    // 0x124ab0c: b.ne            #0x124ab1c
    // 0x124ab10: r0 = Instance_Color
    //     0x124ab10: add             x0, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x124ab14: ldr             x0, [x0, #0x948]
    // 0x124ab18: b               #0x124ab20
    // 0x124ab1c: mov             x0, x1
    // 0x124ab20: LeaveFrame
    //     0x124ab20: mov             SP, fp
    //     0x124ab24: ldp             fp, lr, [SP], #0x10
    // 0x124ab28: ret
    //     0x124ab28: ret             
    // 0x124ab2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124ab2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124ab30: b               #0x124aae0
  }
}

// class id: 5181, size: 0x28, field offset: 0x24
//   const constructor, 
class _CardDefaultsM2 extends CardThemeData {

  get _ color(/* No info */) {
    // ** addr: 0x124a918, size: 0x44
    // 0x124a918: EnterFrame
    //     0x124a918: stp             fp, lr, [SP, #-0x10]!
    //     0x124a91c: mov             fp, SP
    // 0x124a920: CheckStackOverflow
    //     0x124a920: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124a924: cmp             SP, x16
    //     0x124a928: b.ls            #0x124a954
    // 0x124a92c: LoadField: r0 = r1->field_23
    //     0x124a92c: ldur            w0, [x1, #0x23]
    // 0x124a930: DecompressPointer r0
    //     0x124a930: add             x0, x0, HEAP, lsl #32
    // 0x124a934: mov             x1, x0
    // 0x124a938: r0 = of()
    //     0x124a938: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x124a93c: LoadField: r1 = r0->field_3b
    //     0x124a93c: ldur            w1, [x0, #0x3b]
    // 0x124a940: DecompressPointer r1
    //     0x124a940: add             x1, x1, HEAP, lsl #32
    // 0x124a944: mov             x0, x1
    // 0x124a948: LeaveFrame
    //     0x124a948: mov             SP, fp
    //     0x124a94c: ldp             fp, lr, [SP], #0x10
    // 0x124a950: ret
    //     0x124a950: ret             
    // 0x124a954: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124a954: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124a958: b               #0x124a92c
  }
  get _ shadowColor(/* No info */) {
    // ** addr: 0x124aa88, size: 0x44
    // 0x124aa88: EnterFrame
    //     0x124aa88: stp             fp, lr, [SP, #-0x10]!
    //     0x124aa8c: mov             fp, SP
    // 0x124aa90: CheckStackOverflow
    //     0x124aa90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124aa94: cmp             SP, x16
    //     0x124aa98: b.ls            #0x124aac4
    // 0x124aa9c: LoadField: r0 = r1->field_23
    //     0x124aa9c: ldur            w0, [x1, #0x23]
    // 0x124aaa0: DecompressPointer r0
    //     0x124aaa0: add             x0, x0, HEAP, lsl #32
    // 0x124aaa4: mov             x1, x0
    // 0x124aaa8: r0 = of()
    //     0x124aaa8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x124aaac: LoadField: r1 = r0->field_6f
    //     0x124aaac: ldur            w1, [x0, #0x6f]
    // 0x124aab0: DecompressPointer r1
    //     0x124aab0: add             x1, x1, HEAP, lsl #32
    // 0x124aab4: mov             x0, x1
    // 0x124aab8: LeaveFrame
    //     0x124aab8: mov             SP, fp
    //     0x124aabc: ldp             fp, lr, [SP], #0x10
    // 0x124aac0: ret
    //     0x124aac0: ret             
    // 0x124aac4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124aac4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124aac8: b               #0x124aa9c
  }
}

// class id: 6176, size: 0x38, field offset: 0xc
//   const constructor, 
class Card extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfb3870, size: 0x48c
    // 0xfb3870: EnterFrame
    //     0xfb3870: stp             fp, lr, [SP, #-0x10]!
    //     0xfb3874: mov             fp, SP
    // 0xfb3878: AllocStack(0x58)
    //     0xfb3878: sub             SP, SP, #0x58
    // 0xfb387c: SetupParameters(Card this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfb387c: mov             x0, x2
    //     0xfb3880: stur            x2, [fp, #-0x10]
    //     0xfb3884: mov             x2, x1
    //     0xfb3888: stur            x1, [fp, #-8]
    // 0xfb388c: CheckStackOverflow
    //     0xfb388c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb3890: cmp             SP, x16
    //     0xfb3894: b.ls            #0xfb3cf4
    // 0xfb3898: mov             x1, x0
    // 0xfb389c: r0 = of()
    //     0xfb389c: bl              #0xfb3d2c  ; [package:flutter/src/material/card_theme.dart] CardTheme::of
    // 0xfb38a0: ldur            x1, [fp, #-0x10]
    // 0xfb38a4: stur            x0, [fp, #-0x18]
    // 0xfb38a8: r0 = of()
    //     0xfb38a8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb38ac: LoadField: r1 = r0->field_2f
    //     0xfb38ac: ldur            w1, [x0, #0x2f]
    // 0xfb38b0: DecompressPointer r1
    //     0xfb38b0: add             x1, x1, HEAP, lsl #32
    // 0xfb38b4: tbnz            w1, #4, #0xfb39e0
    // 0xfb38b8: ldur            x0, [fp, #-8]
    // 0xfb38bc: LoadField: r1 = r0->field_33
    //     0xfb38bc: ldur            w1, [x0, #0x33]
    // 0xfb38c0: DecompressPointer r1
    //     0xfb38c0: add             x1, x1, HEAP, lsl #32
    // 0xfb38c4: LoadField: r2 = r1->field_7
    //     0xfb38c4: ldur            x2, [x1, #7]
    // 0xfb38c8: cmp             x2, #1
    // 0xfb38cc: b.gt            #0xfb397c
    // 0xfb38d0: cmp             x2, #0
    // 0xfb38d4: b.gt            #0xfb3920
    // 0xfb38d8: ldur            x1, [fp, #-0x10]
    // 0xfb38dc: r0 = _CardDefaultsM3()
    //     0xfb38dc: bl              #0xfb3d20  ; Allocate_CardDefaultsM3Stub -> _CardDefaultsM3 (size=0x2c)
    // 0xfb38e0: mov             x1, x0
    // 0xfb38e4: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb38e8: StoreField: r1->field_27 = r0
    //     0xfb38e8: stur            w0, [x1, #0x27]
    // 0xfb38ec: ldur            x2, [fp, #-0x10]
    // 0xfb38f0: StoreField: r1->field_23 = r2
    //     0xfb38f0: stur            w2, [x1, #0x23]
    // 0xfb38f4: r3 = Instance_Clip
    //     0xfb38f4: add             x3, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb38f8: ldr             x3, [x3, #0x840]
    // 0xfb38fc: StoreField: r1->field_7 = r3
    //     0xfb38fc: stur            w3, [x1, #7]
    // 0xfb3900: r0 = 1.000000
    //     0xfb3900: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xfb3904: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb3904: stur            w0, [x1, #0x17]
    // 0xfb3908: r4 = Instance_EdgeInsets
    //     0xfb3908: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8c9b0] Obj!EdgeInsets@129cde1
    //     0xfb390c: ldr             x4, [x4, #0x9b0]
    // 0xfb3910: StoreField: r1->field_1b = r4
    //     0xfb3910: stur            w4, [x1, #0x1b]
    // 0xfb3914: mov             x0, x1
    // 0xfb3918: d0 = 1.000000
    //     0xfb3918: fmov            d0, #1.00000000
    // 0xfb391c: b               #0xfb39d8
    // 0xfb3920: ldur            x2, [fp, #-0x10]
    // 0xfb3924: r3 = Instance_Clip
    //     0xfb3924: add             x3, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb3928: ldr             x3, [x3, #0x840]
    // 0xfb392c: r4 = Instance_EdgeInsets
    //     0xfb392c: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8c9b0] Obj!EdgeInsets@129cde1
    //     0xfb3930: ldr             x4, [x4, #0x9b0]
    // 0xfb3934: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb3938: r0 = _FilledCardDefaultsM3()
    //     0xfb3938: bl              #0xfb3d14  ; Allocate_FilledCardDefaultsM3Stub -> _FilledCardDefaultsM3 (size=0x2c)
    // 0xfb393c: mov             x1, x0
    // 0xfb3940: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb3944: StoreField: r1->field_27 = r0
    //     0xfb3944: stur            w0, [x1, #0x27]
    // 0xfb3948: ldur            x2, [fp, #-0x10]
    // 0xfb394c: StoreField: r1->field_23 = r2
    //     0xfb394c: stur            w2, [x1, #0x23]
    // 0xfb3950: r3 = Instance_Clip
    //     0xfb3950: add             x3, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb3954: ldr             x3, [x3, #0x840]
    // 0xfb3958: StoreField: r1->field_7 = r3
    //     0xfb3958: stur            w3, [x1, #7]
    // 0xfb395c: r4 = 0.000000
    //     0xfb395c: ldr             x4, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfb3960: ArrayStore: r1[0] = r4  ; List_4
    //     0xfb3960: stur            w4, [x1, #0x17]
    // 0xfb3964: r5 = Instance_EdgeInsets
    //     0xfb3964: add             x5, PP, #0x8c, lsl #12  ; [pp+0x8c9b0] Obj!EdgeInsets@129cde1
    //     0xfb3968: ldr             x5, [x5, #0x9b0]
    // 0xfb396c: StoreField: r1->field_1b = r5
    //     0xfb396c: stur            w5, [x1, #0x1b]
    // 0xfb3970: mov             x0, x1
    // 0xfb3974: d0 = 0.000000
    //     0xfb3974: eor             v0.16b, v0.16b, v0.16b
    // 0xfb3978: b               #0xfb39d8
    // 0xfb397c: ldur            x2, [fp, #-0x10]
    // 0xfb3980: r3 = Instance_Clip
    //     0xfb3980: add             x3, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb3984: ldr             x3, [x3, #0x840]
    // 0xfb3988: r5 = Instance_EdgeInsets
    //     0xfb3988: add             x5, PP, #0x8c, lsl #12  ; [pp+0x8c9b0] Obj!EdgeInsets@129cde1
    //     0xfb398c: ldr             x5, [x5, #0x9b0]
    // 0xfb3990: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb3994: r4 = 0.000000
    //     0xfb3994: ldr             x4, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfb3998: r0 = _OutlinedCardDefaultsM3()
    //     0xfb3998: bl              #0xfb3d08  ; Allocate_OutlinedCardDefaultsM3Stub -> _OutlinedCardDefaultsM3 (size=0x2c)
    // 0xfb399c: mov             x1, x0
    // 0xfb39a0: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb39a4: StoreField: r1->field_27 = r0
    //     0xfb39a4: stur            w0, [x1, #0x27]
    // 0xfb39a8: ldur            x2, [fp, #-0x10]
    // 0xfb39ac: StoreField: r1->field_23 = r2
    //     0xfb39ac: stur            w2, [x1, #0x23]
    // 0xfb39b0: r3 = Instance_Clip
    //     0xfb39b0: add             x3, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb39b4: ldr             x3, [x3, #0x840]
    // 0xfb39b8: StoreField: r1->field_7 = r3
    //     0xfb39b8: stur            w3, [x1, #7]
    // 0xfb39bc: r0 = 0.000000
    //     0xfb39bc: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfb39c0: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb39c0: stur            w0, [x1, #0x17]
    // 0xfb39c4: r4 = Instance_EdgeInsets
    //     0xfb39c4: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8c9b0] Obj!EdgeInsets@129cde1
    //     0xfb39c8: ldr             x4, [x4, #0x9b0]
    // 0xfb39cc: StoreField: r1->field_1b = r4
    //     0xfb39cc: stur            w4, [x1, #0x1b]
    // 0xfb39d0: mov             x0, x1
    // 0xfb39d4: d0 = 0.000000
    //     0xfb39d4: eor             v0.16b, v0.16b, v0.16b
    // 0xfb39d8: mov             x3, x0
    // 0xfb39dc: b               #0xfb3a3c
    // 0xfb39e0: ldur            x2, [fp, #-0x10]
    // 0xfb39e4: r3 = Instance_Clip
    //     0xfb39e4: add             x3, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb39e8: ldr             x3, [x3, #0x840]
    // 0xfb39ec: r0 = 1.000000
    //     0xfb39ec: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xfb39f0: r4 = Instance_EdgeInsets
    //     0xfb39f0: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8c9b0] Obj!EdgeInsets@129cde1
    //     0xfb39f4: ldr             x4, [x4, #0x9b0]
    // 0xfb39f8: r0 = _CardDefaultsM2()
    //     0xfb39f8: bl              #0xfb3cfc  ; Allocate_CardDefaultsM2Stub -> _CardDefaultsM2 (size=0x28)
    // 0xfb39fc: mov             x1, x0
    // 0xfb3a00: ldur            x0, [fp, #-0x10]
    // 0xfb3a04: StoreField: r1->field_23 = r0
    //     0xfb3a04: stur            w0, [x1, #0x23]
    // 0xfb3a08: r0 = Instance_Clip
    //     0xfb3a08: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb3a0c: ldr             x0, [x0, #0x840]
    // 0xfb3a10: StoreField: r1->field_7 = r0
    //     0xfb3a10: stur            w0, [x1, #7]
    // 0xfb3a14: r0 = 1.000000
    //     0xfb3a14: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xfb3a18: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb3a18: stur            w0, [x1, #0x17]
    // 0xfb3a1c: r0 = Instance_EdgeInsets
    //     0xfb3a1c: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8c9b0] Obj!EdgeInsets@129cde1
    //     0xfb3a20: ldr             x0, [x0, #0x9b0]
    // 0xfb3a24: StoreField: r1->field_1b = r0
    //     0xfb3a24: stur            w0, [x1, #0x1b]
    // 0xfb3a28: r0 = Instance_RoundedRectangleBorder
    //     0xfb3a28: add             x0, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0xfb3a2c: ldr             x0, [x0, #0x218]
    // 0xfb3a30: StoreField: r1->field_1f = r0
    //     0xfb3a30: stur            w0, [x1, #0x1f]
    // 0xfb3a34: mov             x3, x1
    // 0xfb3a38: d0 = 1.000000
    //     0xfb3a38: fmov            d0, #1.00000000
    // 0xfb3a3c: ldur            x2, [fp, #-8]
    // 0xfb3a40: stur            x3, [fp, #-0x20]
    // 0xfb3a44: stur            d0, [fp, #-0x48]
    // 0xfb3a48: LoadField: r0 = r2->field_27
    //     0xfb3a48: ldur            w0, [x2, #0x27]
    // 0xfb3a4c: DecompressPointer r0
    //     0xfb3a4c: add             x0, x0, HEAP, lsl #32
    // 0xfb3a50: cmp             w0, NULL
    // 0xfb3a54: b.ne            #0xfb3a68
    // 0xfb3a58: ldur            x4, [fp, #-0x18]
    // 0xfb3a5c: LoadField: r0 = r4->field_1b
    //     0xfb3a5c: ldur            w0, [x4, #0x1b]
    // 0xfb3a60: DecompressPointer r0
    //     0xfb3a60: add             x0, x0, HEAP, lsl #32
    // 0xfb3a64: b               #0xfb3a6c
    // 0xfb3a68: ldur            x4, [fp, #-0x18]
    // 0xfb3a6c: cmp             w0, NULL
    // 0xfb3a70: b.ne            #0xfb3a80
    // 0xfb3a74: r5 = Instance_EdgeInsets
    //     0xfb3a74: add             x5, PP, #0x8c, lsl #12  ; [pp+0x8c9b0] Obj!EdgeInsets@129cde1
    //     0xfb3a78: ldr             x5, [x5, #0x9b0]
    // 0xfb3a7c: b               #0xfb3a84
    // 0xfb3a80: mov             x5, x0
    // 0xfb3a84: stur            x5, [fp, #-0x10]
    // 0xfb3a88: LoadField: r0 = r2->field_b
    //     0xfb3a88: ldur            w0, [x2, #0xb]
    // 0xfb3a8c: DecompressPointer r0
    //     0xfb3a8c: add             x0, x0, HEAP, lsl #32
    // 0xfb3a90: cmp             w0, NULL
    // 0xfb3a94: b.ne            #0xfb3a9c
    // 0xfb3a98: r0 = Null
    //     0xfb3a98: mov             x0, NULL
    // 0xfb3a9c: cmp             w0, NULL
    // 0xfb3aa0: b.ne            #0xfb3ac4
    // 0xfb3aa4: r0 = LoadClassIdInstr(r3)
    //     0xfb3aa4: ldur            x0, [x3, #-1]
    //     0xfb3aa8: ubfx            x0, x0, #0xc, #0x14
    // 0xfb3aac: mov             x1, x3
    // 0xfb3ab0: r0 = GDT[cid_x0 + 0xe20]()
    //     0xfb3ab0: add             lr, x0, #0xe20
    //     0xfb3ab4: ldr             lr, [x21, lr, lsl #3]
    //     0xfb3ab8: blr             lr
    // 0xfb3abc: mov             x3, x0
    // 0xfb3ac0: b               #0xfb3ac8
    // 0xfb3ac4: mov             x3, x0
    // 0xfb3ac8: ldur            x2, [fp, #-8]
    // 0xfb3acc: stur            x3, [fp, #-0x28]
    // 0xfb3ad0: LoadField: r0 = r2->field_f
    //     0xfb3ad0: ldur            w0, [x2, #0xf]
    // 0xfb3ad4: DecompressPointer r0
    //     0xfb3ad4: add             x0, x0, HEAP, lsl #32
    // 0xfb3ad8: cmp             w0, NULL
    // 0xfb3adc: b.ne            #0xfb3ae4
    // 0xfb3ae0: r0 = Null
    //     0xfb3ae0: mov             x0, NULL
    // 0xfb3ae4: cmp             w0, NULL
    // 0xfb3ae8: b.ne            #0xfb3b10
    // 0xfb3aec: ldur            x4, [fp, #-0x20]
    // 0xfb3af0: r0 = LoadClassIdInstr(r4)
    //     0xfb3af0: ldur            x0, [x4, #-1]
    //     0xfb3af4: ubfx            x0, x0, #0xc, #0x14
    // 0xfb3af8: mov             x1, x4
    // 0xfb3afc: r0 = GDT[cid_x0 + 0xe1b]()
    //     0xfb3afc: add             lr, x0, #0xe1b
    //     0xfb3b00: ldr             lr, [x21, lr, lsl #3]
    //     0xfb3b04: blr             lr
    // 0xfb3b08: mov             x4, x0
    // 0xfb3b0c: b               #0xfb3b14
    // 0xfb3b10: mov             x4, x0
    // 0xfb3b14: ldur            x2, [fp, #-8]
    // 0xfb3b18: ldur            x3, [fp, #-0x20]
    // 0xfb3b1c: stur            x4, [fp, #-0x30]
    // 0xfb3b20: r0 = LoadClassIdInstr(r3)
    //     0xfb3b20: ldur            x0, [x3, #-1]
    //     0xfb3b24: ubfx            x0, x0, #0xc, #0x14
    // 0xfb3b28: mov             x1, x3
    // 0xfb3b2c: r0 = GDT[cid_x0 + 0xdfc]()
    //     0xfb3b2c: add             lr, x0, #0xdfc
    //     0xfb3b30: ldr             lr, [x21, lr, lsl #3]
    //     0xfb3b34: blr             lr
    // 0xfb3b38: mov             x3, x0
    // 0xfb3b3c: ldur            x2, [fp, #-8]
    // 0xfb3b40: stur            x3, [fp, #-0x38]
    // 0xfb3b44: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xfb3b44: ldur            w0, [x2, #0x17]
    // 0xfb3b48: DecompressPointer r0
    //     0xfb3b48: add             x0, x0, HEAP, lsl #32
    // 0xfb3b4c: cmp             w0, NULL
    // 0xfb3b50: b.ne            #0xfb3b64
    // 0xfb3b54: ldur            x4, [fp, #-0x18]
    // 0xfb3b58: ArrayLoad: r0 = r4[0]  ; List_4
    //     0xfb3b58: ldur            w0, [x4, #0x17]
    // 0xfb3b5c: DecompressPointer r0
    //     0xfb3b5c: add             x0, x0, HEAP, lsl #32
    // 0xfb3b60: b               #0xfb3b68
    // 0xfb3b64: ldur            x4, [fp, #-0x18]
    // 0xfb3b68: cmp             w0, NULL
    // 0xfb3b6c: b.ne            #0xfb3b78
    // 0xfb3b70: ldur            d0, [fp, #-0x48]
    // 0xfb3b74: b               #0xfb3b7c
    // 0xfb3b78: LoadField: d0 = r0->field_7
    //     0xfb3b78: ldur            d0, [x0, #7]
    // 0xfb3b7c: stur            d0, [fp, #-0x48]
    // 0xfb3b80: LoadField: r0 = r2->field_1b
    //     0xfb3b80: ldur            w0, [x2, #0x1b]
    // 0xfb3b84: DecompressPointer r0
    //     0xfb3b84: add             x0, x0, HEAP, lsl #32
    // 0xfb3b88: cmp             w0, NULL
    // 0xfb3b8c: b.ne            #0xfb3b98
    // 0xfb3b90: LoadField: r0 = r4->field_1f
    //     0xfb3b90: ldur            w0, [x4, #0x1f]
    // 0xfb3b94: DecompressPointer r0
    //     0xfb3b94: add             x0, x0, HEAP, lsl #32
    // 0xfb3b98: cmp             w0, NULL
    // 0xfb3b9c: b.ne            #0xfb3bc0
    // 0xfb3ba0: ldur            x1, [fp, #-0x20]
    // 0xfb3ba4: r0 = LoadClassIdInstr(r1)
    //     0xfb3ba4: ldur            x0, [x1, #-1]
    //     0xfb3ba8: ubfx            x0, x0, #0xc, #0x14
    // 0xfb3bac: r0 = GDT[cid_x0 + 0xe51]()
    //     0xfb3bac: add             lr, x0, #0xe51
    //     0xfb3bb0: ldr             lr, [x21, lr, lsl #3]
    //     0xfb3bb4: blr             lr
    // 0xfb3bb8: mov             x1, x0
    // 0xfb3bbc: b               #0xfb3bc4
    // 0xfb3bc0: mov             x1, x0
    // 0xfb3bc4: ldur            x0, [fp, #-0x18]
    // 0xfb3bc8: stur            x1, [fp, #-0x40]
    // 0xfb3bcc: LoadField: r2 = r0->field_7
    //     0xfb3bcc: ldur            w2, [x0, #7]
    // 0xfb3bd0: DecompressPointer r2
    //     0xfb3bd0: add             x2, x2, HEAP, lsl #32
    // 0xfb3bd4: cmp             w2, NULL
    // 0xfb3bd8: b.ne            #0xfb3be8
    // 0xfb3bdc: r6 = Instance_Clip
    //     0xfb3bdc: add             x6, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb3be0: ldr             x6, [x6, #0x840]
    // 0xfb3be4: b               #0xfb3bec
    // 0xfb3be8: mov             x6, x2
    // 0xfb3bec: ldur            x0, [fp, #-8]
    // 0xfb3bf0: ldur            x5, [fp, #-0x10]
    // 0xfb3bf4: ldur            x4, [fp, #-0x28]
    // 0xfb3bf8: ldur            x3, [fp, #-0x30]
    // 0xfb3bfc: ldur            d0, [fp, #-0x48]
    // 0xfb3c00: ldur            x2, [fp, #-0x38]
    // 0xfb3c04: stur            x6, [fp, #-0x20]
    // 0xfb3c08: LoadField: r7 = r0->field_2f
    //     0xfb3c08: ldur            w7, [x0, #0x2f]
    // 0xfb3c0c: DecompressPointer r7
    //     0xfb3c0c: add             x7, x7, HEAP, lsl #32
    // 0xfb3c10: stur            x7, [fp, #-0x18]
    // 0xfb3c14: r0 = Semantics()
    //     0xfb3c14: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xfb3c18: stur            x0, [fp, #-8]
    // 0xfb3c1c: r16 = false
    //     0xfb3c1c: add             x16, NULL, #0x30  ; false
    // 0xfb3c20: ldur            lr, [fp, #-0x18]
    // 0xfb3c24: stp             lr, x16, [SP]
    // 0xfb3c28: mov             x1, x0
    // 0xfb3c2c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, explicitChildNodes, 0x1, null]
    //     0xfb3c2c: add             x4, PP, #0x80, lsl #12  ; [pp+0x80e48] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "explicitChildNodes", 0x1, Null]
    //     0xfb3c30: ldr             x4, [x4, #0xe48]
    // 0xfb3c34: r0 = Semantics()
    //     0xfb3c34: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xfb3c38: r0 = Material()
    //     0xfb3c38: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xfb3c3c: mov             x1, x0
    // 0xfb3c40: r0 = Instance_MaterialType
    //     0xfb3c40: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8c988] Obj!MaterialType@12c53c1
    //     0xfb3c44: ldr             x0, [x0, #0x988]
    // 0xfb3c48: stur            x1, [fp, #-0x18]
    // 0xfb3c4c: StoreField: r1->field_f = r0
    //     0xfb3c4c: stur            w0, [x1, #0xf]
    // 0xfb3c50: ldur            d0, [fp, #-0x48]
    // 0xfb3c54: ArrayStore: r1[0] = d0  ; List_8
    //     0xfb3c54: stur            d0, [x1, #0x17]
    // 0xfb3c58: ldur            x0, [fp, #-0x28]
    // 0xfb3c5c: StoreField: r1->field_1f = r0
    //     0xfb3c5c: stur            w0, [x1, #0x1f]
    // 0xfb3c60: ldur            x0, [fp, #-0x30]
    // 0xfb3c64: StoreField: r1->field_23 = r0
    //     0xfb3c64: stur            w0, [x1, #0x23]
    // 0xfb3c68: ldur            x0, [fp, #-0x38]
    // 0xfb3c6c: StoreField: r1->field_27 = r0
    //     0xfb3c6c: stur            w0, [x1, #0x27]
    // 0xfb3c70: ldur            x0, [fp, #-0x40]
    // 0xfb3c74: StoreField: r1->field_2f = r0
    //     0xfb3c74: stur            w0, [x1, #0x2f]
    // 0xfb3c78: r0 = true
    //     0xfb3c78: add             x0, NULL, #0x20  ; true
    // 0xfb3c7c: StoreField: r1->field_33 = r0
    //     0xfb3c7c: stur            w0, [x1, #0x33]
    // 0xfb3c80: ldur            x0, [fp, #-0x20]
    // 0xfb3c84: StoreField: r1->field_37 = r0
    //     0xfb3c84: stur            w0, [x1, #0x37]
    // 0xfb3c88: r0 = Instance_Duration
    //     0xfb3c88: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xfb3c8c: ldr             x0, [x0, #0x318]
    // 0xfb3c90: StoreField: r1->field_3b = r0
    //     0xfb3c90: stur            w0, [x1, #0x3b]
    // 0xfb3c94: ldur            x0, [fp, #-8]
    // 0xfb3c98: StoreField: r1->field_b = r0
    //     0xfb3c98: stur            w0, [x1, #0xb]
    // 0xfb3c9c: r0 = false
    //     0xfb3c9c: add             x0, NULL, #0x30  ; false
    // 0xfb3ca0: StoreField: r1->field_13 = r0
    //     0xfb3ca0: stur            w0, [x1, #0x13]
    // 0xfb3ca4: r0 = Padding()
    //     0xfb3ca4: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xfb3ca8: mov             x1, x0
    // 0xfb3cac: ldur            x0, [fp, #-0x10]
    // 0xfb3cb0: stur            x1, [fp, #-8]
    // 0xfb3cb4: StoreField: r1->field_f = r0
    //     0xfb3cb4: stur            w0, [x1, #0xf]
    // 0xfb3cb8: ldur            x0, [fp, #-0x18]
    // 0xfb3cbc: StoreField: r1->field_b = r0
    //     0xfb3cbc: stur            w0, [x1, #0xb]
    // 0xfb3cc0: r0 = Semantics()
    //     0xfb3cc0: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xfb3cc4: stur            x0, [fp, #-0x10]
    // 0xfb3cc8: r16 = true
    //     0xfb3cc8: add             x16, NULL, #0x20  ; true
    // 0xfb3ccc: ldur            lr, [fp, #-8]
    // 0xfb3cd0: stp             lr, x16, [SP]
    // 0xfb3cd4: mov             x1, x0
    // 0xfb3cd8: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, container, 0x1, null]
    //     0xfb3cd8: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8c9b8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "container", 0x1, Null]
    //     0xfb3cdc: ldr             x4, [x4, #0x9b8]
    // 0xfb3ce0: r0 = Semantics()
    //     0xfb3ce0: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xfb3ce4: ldur            x0, [fp, #-0x10]
    // 0xfb3ce8: LeaveFrame
    //     0xfb3ce8: mov             SP, fp
    //     0xfb3cec: ldp             fp, lr, [SP], #0x10
    // 0xfb3cf0: ret
    //     0xfb3cf0: ret             
    // 0xfb3cf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb3cf4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb3cf8: b               #0xfb3898
  }
}

// class id: 8295, size: 0x14, field offset: 0x14
enum _CardVariant extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9ea0, size: 0x64
    // 0x11a9ea0: EnterFrame
    //     0x11a9ea0: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9ea4: mov             fp, SP
    // 0x11a9ea8: AllocStack(0x10)
    //     0x11a9ea8: sub             SP, SP, #0x10
    // 0x11a9eac: SetupParameters(_CardVariant this /* r1 => r0, fp-0x8 */)
    //     0x11a9eac: mov             x0, x1
    //     0x11a9eb0: stur            x1, [fp, #-8]
    // 0x11a9eb4: CheckStackOverflow
    //     0x11a9eb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9eb8: cmp             SP, x16
    //     0x11a9ebc: b.ls            #0x11a9efc
    // 0x11a9ec0: r1 = Null
    //     0x11a9ec0: mov             x1, NULL
    // 0x11a9ec4: r2 = 4
    //     0x11a9ec4: mov             x2, #4
    // 0x11a9ec8: r0 = AllocateArray()
    //     0x11a9ec8: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9ecc: r16 = "_CardVariant."
    //     0x11a9ecc: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c9c8] "_CardVariant."
    //     0x11a9ed0: ldr             x16, [x16, #0x9c8]
    // 0x11a9ed4: StoreField: r0->field_f = r16
    //     0x11a9ed4: stur            w16, [x0, #0xf]
    // 0x11a9ed8: ldur            x1, [fp, #-8]
    // 0x11a9edc: LoadField: r2 = r1->field_f
    //     0x11a9edc: ldur            w2, [x1, #0xf]
    // 0x11a9ee0: DecompressPointer r2
    //     0x11a9ee0: add             x2, x2, HEAP, lsl #32
    // 0x11a9ee4: StoreField: r0->field_13 = r2
    //     0x11a9ee4: stur            w2, [x0, #0x13]
    // 0x11a9ee8: str             x0, [SP]
    // 0x11a9eec: r0 = _interpolate()
    //     0x11a9eec: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9ef0: LeaveFrame
    //     0x11a9ef0: mov             SP, fp
    //     0x11a9ef4: ldp             fp, lr, [SP], #0x10
    // 0x11a9ef8: ret
    //     0x11a9ef8: ret             
    // 0x11a9efc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9efc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9f00: b               #0x11a9ec0
  }
}
