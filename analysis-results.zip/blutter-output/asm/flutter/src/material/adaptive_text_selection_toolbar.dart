// lib: , url: package:flutter/src/material/adaptive_text_selection_toolbar.dart

// class id: 1048840, size: 0x8
class :: {
}

// class id: 6187, size: 0x18, field offset: 0xc
//   const constructor, 
class AdaptiveTextSelectionToolbar extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfaed78, size: 0x23c
    // 0xfaed78: EnterFrame
    //     0xfaed78: stp             fp, lr, [SP, #-0x10]!
    //     0xfaed7c: mov             fp, SP
    // 0xfaed80: AllocStack(0x20)
    //     0xfaed80: sub             SP, SP, #0x20
    // 0xfaed84: SetupParameters(AdaptiveTextSelectionToolbar this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfaed84: mov             x3, x1
    //     0xfaed88: mov             x0, x2
    //     0xfaed8c: stur            x1, [fp, #-8]
    //     0xfaed90: stur            x2, [fp, #-0x10]
    // 0xfaed94: CheckStackOverflow
    //     0xfaed94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaed98: cmp             SP, x16
    //     0xfaed9c: b.ls            #0xfaefac
    // 0xfaeda0: LoadField: r2 = r3->field_b
    //     0xfaeda0: ldur            w2, [x3, #0xb]
    // 0xfaeda4: DecompressPointer r2
    //     0xfaeda4: add             x2, x2, HEAP, lsl #32
    // 0xfaeda8: LoadField: r1 = r2->field_b
    //     0xfaeda8: ldur            w1, [x2, #0xb]
    // 0xfaedac: cbnz            w1, #0xfaedc0
    // 0xfaedb0: r0 = Instance_SizedBox
    //     0xfaedb0: ldr             x0, [PP, #0x4f58]  ; [pp+0x4f58] Obj!SizedBox@12b70e1
    // 0xfaedb4: LeaveFrame
    //     0xfaedb4: mov             SP, fp
    //     0xfaedb8: ldp             fp, lr, [SP], #0x10
    // 0xfaedbc: ret
    //     0xfaedbc: ret             
    // 0xfaedc0: mov             x1, x0
    // 0xfaedc4: r0 = getAdaptiveButtons()
    //     0xfaedc4: bl              #0xfaefe4  ; [package:flutter/src/material/adaptive_text_selection_toolbar.dart] AdaptiveTextSelectionToolbar::getAdaptiveButtons
    // 0xfaedc8: r1 = LoadClassIdInstr(r0)
    //     0xfaedc8: ldur            x1, [x0, #-1]
    //     0xfaedcc: ubfx            x1, x1, #0xc, #0x14
    // 0xfaedd0: mov             x16, x0
    // 0xfaedd4: mov             x0, x1
    // 0xfaedd8: mov             x1, x16
    // 0xfaeddc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xfaeddc: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xfaede0: r0 = GDT[cid_x0 + 0x126dc]()
    //     0xfaede0: mov             x17, #0x26dc
    //     0xfaede4: movk            x17, #1, lsl #16
    //     0xfaede8: add             lr, x0, x17
    //     0xfaedec: ldr             lr, [x21, lr, lsl #3]
    //     0xfaedf0: blr             lr
    // 0xfaedf4: ldur            x1, [fp, #-0x10]
    // 0xfaedf8: stur            x0, [fp, #-0x10]
    // 0xfaedfc: r0 = of()
    //     0xfaedfc: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfaee00: LoadField: r1 = r0->field_23
    //     0xfaee00: ldur            w1, [x0, #0x23]
    // 0xfaee04: DecompressPointer r1
    //     0xfaee04: add             x1, x1, HEAP, lsl #32
    // 0xfaee08: LoadField: r0 = r1->field_7
    //     0xfaee08: ldur            x0, [x1, #7]
    // 0xfaee0c: cmp             x0, #2
    // 0xfaee10: b.gt            #0xfaef18
    // 0xfaee14: cmp             x0, #1
    // 0xfaee18: b.gt            #0xfaeea0
    // 0xfaee1c: cmp             x0, #0
    // 0xfaee20: b.gt            #0xfaee94
    // 0xfaee24: ldur            x1, [fp, #-8]
    // 0xfaee28: LoadField: r0 = r1->field_13
    //     0xfaee28: ldur            w0, [x1, #0x13]
    // 0xfaee2c: DecompressPointer r0
    //     0xfaee2c: add             x0, x0, HEAP, lsl #32
    // 0xfaee30: LoadField: r1 = r0->field_7
    //     0xfaee30: ldur            w1, [x0, #7]
    // 0xfaee34: DecompressPointer r1
    //     0xfaee34: add             x1, x1, HEAP, lsl #32
    // 0xfaee38: stur            x1, [fp, #-0x20]
    // 0xfaee3c: LoadField: r2 = r0->field_b
    //     0xfaee3c: ldur            w2, [x0, #0xb]
    // 0xfaee40: DecompressPointer r2
    //     0xfaee40: add             x2, x2, HEAP, lsl #32
    // 0xfaee44: cmp             w2, NULL
    // 0xfaee48: b.ne            #0xfaee50
    // 0xfaee4c: mov             x2, x1
    // 0xfaee50: ldur            x0, [fp, #-0x10]
    // 0xfaee54: stur            x2, [fp, #-0x18]
    // 0xfaee58: r0 = TextSelectionToolbar()
    //     0xfaee58: bl              #0xfaefd8  ; AllocateTextSelectionToolbarStub -> TextSelectionToolbar (size=0x1c)
    // 0xfaee5c: mov             x1, x0
    // 0xfaee60: ldur            x0, [fp, #-0x20]
    // 0xfaee64: StoreField: r1->field_b = r0
    //     0xfaee64: stur            w0, [x1, #0xb]
    // 0xfaee68: ldur            x0, [fp, #-0x18]
    // 0xfaee6c: StoreField: r1->field_f = r0
    //     0xfaee6c: stur            w0, [x1, #0xf]
    // 0xfaee70: r0 = Closure: (BuildContext, Widget) => Widget from Function '_defaultToolbarBuilder@132142888': static.
    //     0xfaee70: add             x0, PP, #0x80, lsl #12  ; [pp+0x809d0] Closure: (BuildContext, Widget) => Widget from Function '_defaultToolbarBuilder@132142888': static. (0x7f2adac31a3c)
    //     0xfaee74: ldr             x0, [x0, #0x9d0]
    // 0xfaee78: ArrayStore: r1[0] = r0  ; List_4
    //     0xfaee78: stur            w0, [x1, #0x17]
    // 0xfaee7c: ldur            x0, [fp, #-0x10]
    // 0xfaee80: StoreField: r1->field_13 = r0
    //     0xfaee80: stur            w0, [x1, #0x13]
    // 0xfaee84: mov             x0, x1
    // 0xfaee88: LeaveFrame
    //     0xfaee88: mov             SP, fp
    //     0xfaee8c: ldp             fp, lr, [SP], #0x10
    // 0xfaee90: ret
    //     0xfaee90: ret             
    // 0xfaee94: ldur            x1, [fp, #-8]
    // 0xfaee98: ldur            x0, [fp, #-0x10]
    // 0xfaee9c: b               #0xfaef78
    // 0xfaeea0: ldur            x1, [fp, #-8]
    // 0xfaeea4: ldur            x0, [fp, #-0x10]
    // 0xfaeea8: LoadField: r2 = r1->field_13
    //     0xfaeea8: ldur            w2, [x1, #0x13]
    // 0xfaeeac: DecompressPointer r2
    //     0xfaeeac: add             x2, x2, HEAP, lsl #32
    // 0xfaeeb0: LoadField: r1 = r2->field_7
    //     0xfaeeb0: ldur            w1, [x2, #7]
    // 0xfaeeb4: DecompressPointer r1
    //     0xfaeeb4: add             x1, x1, HEAP, lsl #32
    // 0xfaeeb8: stur            x1, [fp, #-0x20]
    // 0xfaeebc: LoadField: r3 = r2->field_b
    //     0xfaeebc: ldur            w3, [x2, #0xb]
    // 0xfaeec0: DecompressPointer r3
    //     0xfaeec0: add             x3, x3, HEAP, lsl #32
    // 0xfaeec4: cmp             w3, NULL
    // 0xfaeec8: b.ne            #0xfaeed4
    // 0xfaeecc: mov             x2, x1
    // 0xfaeed0: b               #0xfaeed8
    // 0xfaeed4: mov             x2, x3
    // 0xfaeed8: stur            x2, [fp, #-0x18]
    // 0xfaeedc: r0 = CupertinoTextSelectionToolbar()
    //     0xfaeedc: bl              #0xfaefcc  ; AllocateCupertinoTextSelectionToolbarStub -> CupertinoTextSelectionToolbar (size=0x1c)
    // 0xfaeee0: mov             x1, x0
    // 0xfaeee4: ldur            x0, [fp, #-0x20]
    // 0xfaeee8: StoreField: r1->field_b = r0
    //     0xfaeee8: stur            w0, [x1, #0xb]
    // 0xfaeeec: ldur            x0, [fp, #-0x18]
    // 0xfaeef0: StoreField: r1->field_f = r0
    //     0xfaeef0: stur            w0, [x1, #0xf]
    // 0xfaeef4: ldur            x2, [fp, #-0x10]
    // 0xfaeef8: StoreField: r1->field_13 = r2
    //     0xfaeef8: stur            w2, [x1, #0x13]
    // 0xfaeefc: r0 = Closure: (BuildContext, Offset, Offset, Widget) => Widget from Function '_defaultToolbarBuilder@298408280': static.
    //     0xfaeefc: add             x0, PP, #0x80, lsl #12  ; [pp+0x809d8] Closure: (BuildContext, Offset, Offset, Widget) => Widget from Function '_defaultToolbarBuilder@298408280': static. (0x7f2adac5e5d0)
    //     0xfaef00: ldr             x0, [x0, #0x9d8]
    // 0xfaef04: ArrayStore: r1[0] = r0  ; List_4
    //     0xfaef04: stur            w0, [x1, #0x17]
    // 0xfaef08: mov             x0, x1
    // 0xfaef0c: LeaveFrame
    //     0xfaef0c: mov             SP, fp
    //     0xfaef10: ldp             fp, lr, [SP], #0x10
    // 0xfaef14: ret
    //     0xfaef14: ret             
    // 0xfaef18: ldur            x1, [fp, #-8]
    // 0xfaef1c: ldur            x2, [fp, #-0x10]
    // 0xfaef20: cmp             x0, #4
    // 0xfaef24: b.gt            #0xfaef74
    // 0xfaef28: cmp             x0, #3
    // 0xfaef2c: b.gt            #0xfaef38
    // 0xfaef30: mov             x0, x2
    // 0xfaef34: b               #0xfaef78
    // 0xfaef38: LoadField: r0 = r1->field_13
    //     0xfaef38: ldur            w0, [x1, #0x13]
    // 0xfaef3c: DecompressPointer r0
    //     0xfaef3c: add             x0, x0, HEAP, lsl #32
    // 0xfaef40: LoadField: r1 = r0->field_7
    //     0xfaef40: ldur            w1, [x0, #7]
    // 0xfaef44: DecompressPointer r1
    //     0xfaef44: add             x1, x1, HEAP, lsl #32
    // 0xfaef48: stur            x1, [fp, #-0x18]
    // 0xfaef4c: r0 = CupertinoDesktopTextSelectionToolbar()
    //     0xfaef4c: bl              #0xfaefc0  ; AllocateCupertinoDesktopTextSelectionToolbarStub -> CupertinoDesktopTextSelectionToolbar (size=0x14)
    // 0xfaef50: mov             x1, x0
    // 0xfaef54: ldur            x0, [fp, #-0x18]
    // 0xfaef58: StoreField: r1->field_b = r0
    //     0xfaef58: stur            w0, [x1, #0xb]
    // 0xfaef5c: ldur            x0, [fp, #-0x10]
    // 0xfaef60: StoreField: r1->field_f = r0
    //     0xfaef60: stur            w0, [x1, #0xf]
    // 0xfaef64: mov             x0, x1
    // 0xfaef68: LeaveFrame
    //     0xfaef68: mov             SP, fp
    //     0xfaef6c: ldp             fp, lr, [SP], #0x10
    // 0xfaef70: ret
    //     0xfaef70: ret             
    // 0xfaef74: mov             x0, x2
    // 0xfaef78: LoadField: r2 = r1->field_13
    //     0xfaef78: ldur            w2, [x1, #0x13]
    // 0xfaef7c: DecompressPointer r2
    //     0xfaef7c: add             x2, x2, HEAP, lsl #32
    // 0xfaef80: LoadField: r1 = r2->field_7
    //     0xfaef80: ldur            w1, [x2, #7]
    // 0xfaef84: DecompressPointer r1
    //     0xfaef84: add             x1, x1, HEAP, lsl #32
    // 0xfaef88: stur            x1, [fp, #-8]
    // 0xfaef8c: r0 = DesktopTextSelectionToolbar()
    //     0xfaef8c: bl              #0xfaefb4  ; AllocateDesktopTextSelectionToolbarStub -> DesktopTextSelectionToolbar (size=0x14)
    // 0xfaef90: ldur            x1, [fp, #-8]
    // 0xfaef94: StoreField: r0->field_b = r1
    //     0xfaef94: stur            w1, [x0, #0xb]
    // 0xfaef98: ldur            x1, [fp, #-0x10]
    // 0xfaef9c: StoreField: r0->field_f = r1
    //     0xfaef9c: stur            w1, [x0, #0xf]
    // 0xfaefa0: LeaveFrame
    //     0xfaefa0: mov             SP, fp
    //     0xfaefa4: ldp             fp, lr, [SP], #0x10
    // 0xfaefa8: ret
    //     0xfaefa8: ret             
    // 0xfaefac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaefac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaefb0: b               #0xfaeda0
  }
  static _ getAdaptiveButtons(/* No info */) {
    // ** addr: 0xfaefe4, size: 0x32c
    // 0xfaefe4: EnterFrame
    //     0xfaefe4: stp             fp, lr, [SP, #-0x10]!
    //     0xfaefe8: mov             fp, SP
    // 0xfaefec: AllocStack(0x70)
    //     0xfaefec: sub             SP, SP, #0x70
    // 0xfaeff0: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xfaeff0: stur            x1, [fp, #-8]
    //     0xfaeff4: stur            x2, [fp, #-0x10]
    // 0xfaeff8: CheckStackOverflow
    //     0xfaeff8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaeffc: cmp             SP, x16
    //     0xfaf000: b.ls            #0xfaf300
    // 0xfaf004: r1 = 1
    //     0xfaf004: mov             x1, #1
    // 0xfaf008: r0 = AllocateContext()
    //     0xfaf008: bl              #0x13de838  ; AllocateContextStub
    // 0xfaf00c: ldur            x1, [fp, #-8]
    // 0xfaf010: stur            x0, [fp, #-0x18]
    // 0xfaf014: StoreField: r0->field_f = r1
    //     0xfaf014: stur            w1, [x0, #0xf]
    // 0xfaf018: r0 = of()
    //     0xfaf018: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfaf01c: LoadField: r1 = r0->field_23
    //     0xfaf01c: ldur            w1, [x0, #0x23]
    // 0xfaf020: DecompressPointer r1
    //     0xfaf020: add             x1, x1, HEAP, lsl #32
    // 0xfaf024: LoadField: r0 = r1->field_7
    //     0xfaf024: ldur            x0, [x1, #7]
    // 0xfaf028: cmp             x0, #2
    // 0xfaf02c: b.gt            #0xfaf288
    // 0xfaf030: cmp             x0, #1
    // 0xfaf034: b.gt            #0xfaf254
    // 0xfaf038: r1 = <Widget>
    //     0xfaf038: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfaf03c: r2 = 0
    //     0xfaf03c: mov             x2, #0
    // 0xfaf040: r0 = _GrowableList()
    //     0xfaf040: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfaf044: stur            x0, [fp, #-0x28]
    // 0xfaf048: r3 = 0
    //     0xfaf048: mov             x3, #0
    // 0xfaf04c: ldur            x1, [fp, #-0x10]
    // 0xfaf050: ldur            x2, [fp, #-0x18]
    // 0xfaf054: stur            x3, [fp, #-0x20]
    // 0xfaf058: CheckStackOverflow
    //     0xfaf058: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaf05c: cmp             SP, x16
    //     0xfaf060: b.ls            #0xfaf308
    // 0xfaf064: LoadField: r4 = r1->field_b
    //     0xfaf064: ldur            w4, [x1, #0xb]
    // 0xfaf068: r5 = LoadInt32Instr(r4)
    //     0xfaf068: sbfx            x5, x4, #1, #0x1f
    // 0xfaf06c: cmp             x3, x5
    // 0xfaf070: b.ge            #0xfaf240
    // 0xfaf074: LoadField: r4 = r1->field_f
    //     0xfaf074: ldur            w4, [x1, #0xf]
    // 0xfaf078: DecompressPointer r4
    //     0xfaf078: add             x4, x4, HEAP, lsl #32
    // 0xfaf07c: ArrayLoad: r6 = r4[r3]  ; Unknown_4
    //     0xfaf07c: add             x16, x4, x3, lsl #2
    //     0xfaf080: ldur            w6, [x16, #0xf]
    // 0xfaf084: DecompressPointer r6
    //     0xfaf084: add             x6, x6, HEAP, lsl #32
    // 0xfaf088: stur            x6, [fp, #-8]
    // 0xfaf08c: cbnz            x3, #0xfaf0b0
    // 0xfaf090: cmp             x5, #1
    // 0xfaf094: b.ne            #0xfaf0a4
    // 0xfaf098: r4 = Instance__TextSelectionToolbarItemPosition
    //     0xfaf098: add             x4, PP, #0x80, lsl #12  ; [pp+0x809e8] Obj!_TextSelectionToolbarItemPosition@12c4c21
    //     0xfaf09c: ldr             x4, [x4, #0x9e8]
    // 0xfaf0a0: b               #0xfaf0d0
    // 0xfaf0a4: r4 = Instance__TextSelectionToolbarItemPosition
    //     0xfaf0a4: add             x4, PP, #0x80, lsl #12  ; [pp+0x809f0] Obj!_TextSelectionToolbarItemPosition@12c4c01
    //     0xfaf0a8: ldr             x4, [x4, #0x9f0]
    // 0xfaf0ac: b               #0xfaf0d0
    // 0xfaf0b0: sub             x4, x5, #1
    // 0xfaf0b4: cmp             x3, x4
    // 0xfaf0b8: b.ne            #0xfaf0c8
    // 0xfaf0bc: r4 = Instance__TextSelectionToolbarItemPosition
    //     0xfaf0bc: add             x4, PP, #0x80, lsl #12  ; [pp+0x809f8] Obj!_TextSelectionToolbarItemPosition@12c4be1
    //     0xfaf0c0: ldr             x4, [x4, #0x9f8]
    // 0xfaf0c4: b               #0xfaf0d0
    // 0xfaf0c8: r4 = Instance__TextSelectionToolbarItemPosition
    //     0xfaf0c8: add             x4, PP, #0x80, lsl #12  ; [pp+0x80a00] Obj!_TextSelectionToolbarItemPosition@12c4bc1
    //     0xfaf0cc: ldr             x4, [x4, #0xa00]
    // 0xfaf0d0: r16 = Instance__TextSelectionToolbarItemPosition
    //     0xfaf0d0: add             x16, PP, #0x80, lsl #12  ; [pp+0x809f0] Obj!_TextSelectionToolbarItemPosition@12c4c01
    //     0xfaf0d4: ldr             x16, [x16, #0x9f0]
    // 0xfaf0d8: cmp             w4, w16
    // 0xfaf0dc: b.eq            #0xfaf0f0
    // 0xfaf0e0: r16 = Instance__TextSelectionToolbarItemPosition
    //     0xfaf0e0: add             x16, PP, #0x80, lsl #12  ; [pp+0x809e8] Obj!_TextSelectionToolbarItemPosition@12c4c21
    //     0xfaf0e4: ldr             x16, [x16, #0x9e8]
    // 0xfaf0e8: cmp             w4, w16
    // 0xfaf0ec: b.ne            #0xfaf0f8
    // 0xfaf0f0: d0 = 14.500000
    //     0xfaf0f0: fmov            d0, #14.50000000
    // 0xfaf0f4: b               #0xfaf0fc
    // 0xfaf0f8: d0 = 9.500000
    //     0xfaf0f8: fmov            d0, #9.50000000
    // 0xfaf0fc: stur            d0, [fp, #-0x58]
    // 0xfaf100: r16 = Instance__TextSelectionToolbarItemPosition
    //     0xfaf100: add             x16, PP, #0x80, lsl #12  ; [pp+0x809f8] Obj!_TextSelectionToolbarItemPosition@12c4be1
    //     0xfaf104: ldr             x16, [x16, #0x9f8]
    // 0xfaf108: cmp             w4, w16
    // 0xfaf10c: b.eq            #0xfaf120
    // 0xfaf110: r16 = Instance__TextSelectionToolbarItemPosition
    //     0xfaf110: add             x16, PP, #0x80, lsl #12  ; [pp+0x809e8] Obj!_TextSelectionToolbarItemPosition@12c4c21
    //     0xfaf114: ldr             x16, [x16, #0x9e8]
    // 0xfaf118: cmp             w4, w16
    // 0xfaf11c: b.ne            #0xfaf128
    // 0xfaf120: d1 = 14.500000
    //     0xfaf120: fmov            d1, #14.50000000
    // 0xfaf124: b               #0xfaf12c
    // 0xfaf128: d1 = 9.500000
    //     0xfaf128: fmov            d1, #9.50000000
    // 0xfaf12c: stur            d1, [fp, #-0x50]
    // 0xfaf130: r0 = EdgeInsetsDirectional()
    //     0xfaf130: bl              #0xb50060  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xfaf134: ldur            d0, [fp, #-0x58]
    // 0xfaf138: stur            x0, [fp, #-0x38]
    // 0xfaf13c: StoreField: r0->field_7 = d0
    //     0xfaf13c: stur            d0, [x0, #7]
    // 0xfaf140: StoreField: r0->field_f = rZR
    //     0xfaf140: stur            xzr, [x0, #0xf]
    // 0xfaf144: ldur            d0, [fp, #-0x50]
    // 0xfaf148: ArrayStore: r0[0] = d0  ; List_8
    //     0xfaf148: stur            d0, [x0, #0x17]
    // 0xfaf14c: StoreField: r0->field_1f = rZR
    //     0xfaf14c: stur            xzr, [x0, #0x1f]
    // 0xfaf150: ldur            x2, [fp, #-8]
    // 0xfaf154: LoadField: r3 = r2->field_7
    //     0xfaf154: ldur            w3, [x2, #7]
    // 0xfaf158: DecompressPointer r3
    //     0xfaf158: add             x3, x3, HEAP, lsl #32
    // 0xfaf15c: ldur            x4, [fp, #-0x18]
    // 0xfaf160: stur            x3, [fp, #-0x30]
    // 0xfaf164: LoadField: r1 = r4->field_f
    //     0xfaf164: ldur            w1, [x4, #0xf]
    // 0xfaf168: DecompressPointer r1
    //     0xfaf168: add             x1, x1, HEAP, lsl #32
    // 0xfaf16c: r0 = getButtonLabel()
    //     0xfaf16c: bl              #0xfaf31c  ; [package:flutter/src/material/adaptive_text_selection_toolbar.dart] AdaptiveTextSelectionToolbar::getButtonLabel
    // 0xfaf170: stur            x0, [fp, #-8]
    // 0xfaf174: r0 = Text()
    //     0xfaf174: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xfaf178: mov             x1, x0
    // 0xfaf17c: ldur            x0, [fp, #-8]
    // 0xfaf180: stur            x1, [fp, #-0x40]
    // 0xfaf184: StoreField: r1->field_b = r0
    //     0xfaf184: stur            w0, [x1, #0xb]
    // 0xfaf188: r0 = TextSelectionToolbarTextButton()
    //     0xfaf188: bl              #0xfaf310  ; AllocateTextSelectionToolbarTextButtonStub -> TextSelectionToolbarTextButton (size=0x1c)
    // 0xfaf18c: mov             x2, x0
    // 0xfaf190: ldur            x0, [fp, #-0x40]
    // 0xfaf194: stur            x2, [fp, #-8]
    // 0xfaf198: StoreField: r2->field_b = r0
    //     0xfaf198: stur            w0, [x2, #0xb]
    // 0xfaf19c: ldur            x0, [fp, #-0x38]
    // 0xfaf1a0: StoreField: r2->field_13 = r0
    //     0xfaf1a0: stur            w0, [x2, #0x13]
    // 0xfaf1a4: ldur            x0, [fp, #-0x30]
    // 0xfaf1a8: StoreField: r2->field_f = r0
    //     0xfaf1a8: stur            w0, [x2, #0xf]
    // 0xfaf1ac: r0 = Instance_AlignmentDirectional
    //     0xfaf1ac: add             x0, PP, #0x28, lsl #12  ; [pp+0x28258] Obj!AlignmentDirectional@129e651
    //     0xfaf1b0: ldr             x0, [x0, #0x258]
    // 0xfaf1b4: ArrayStore: r2[0] = r0  ; List_4
    //     0xfaf1b4: stur            w0, [x2, #0x17]
    // 0xfaf1b8: ldur            x3, [fp, #-0x28]
    // 0xfaf1bc: LoadField: r1 = r3->field_b
    //     0xfaf1bc: ldur            w1, [x3, #0xb]
    // 0xfaf1c0: LoadField: r4 = r3->field_f
    //     0xfaf1c0: ldur            w4, [x3, #0xf]
    // 0xfaf1c4: DecompressPointer r4
    //     0xfaf1c4: add             x4, x4, HEAP, lsl #32
    // 0xfaf1c8: LoadField: r5 = r4->field_b
    //     0xfaf1c8: ldur            w5, [x4, #0xb]
    // 0xfaf1cc: r4 = LoadInt32Instr(r1)
    //     0xfaf1cc: sbfx            x4, x1, #1, #0x1f
    // 0xfaf1d0: stur            x4, [fp, #-0x48]
    // 0xfaf1d4: r1 = LoadInt32Instr(r5)
    //     0xfaf1d4: sbfx            x1, x5, #1, #0x1f
    // 0xfaf1d8: cmp             x4, x1
    // 0xfaf1dc: b.ne            #0xfaf1e8
    // 0xfaf1e0: mov             x1, x3
    // 0xfaf1e4: r0 = _growToNextCapacity()
    //     0xfaf1e4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfaf1e8: ldur            x2, [fp, #-0x28]
    // 0xfaf1ec: ldur            x4, [fp, #-0x20]
    // 0xfaf1f0: ldur            x3, [fp, #-0x48]
    // 0xfaf1f4: add             x0, x3, #1
    // 0xfaf1f8: lsl             x1, x0, #1
    // 0xfaf1fc: StoreField: r2->field_b = r1
    //     0xfaf1fc: stur            w1, [x2, #0xb]
    // 0xfaf200: LoadField: r1 = r2->field_f
    //     0xfaf200: ldur            w1, [x2, #0xf]
    // 0xfaf204: DecompressPointer r1
    //     0xfaf204: add             x1, x1, HEAP, lsl #32
    // 0xfaf208: ldur            x0, [fp, #-8]
    // 0xfaf20c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfaf20c: add             x25, x1, x3, lsl #2
    //     0xfaf210: add             x25, x25, #0xf
    //     0xfaf214: str             w0, [x25]
    //     0xfaf218: tbz             w0, #0, #0xfaf234
    //     0xfaf21c: ldurb           w16, [x1, #-1]
    //     0xfaf220: ldurb           w17, [x0, #-1]
    //     0xfaf224: and             x16, x17, x16, lsr #2
    //     0xfaf228: tst             x16, HEAP, lsr #32
    //     0xfaf22c: b.eq            #0xfaf234
    //     0xfaf230: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfaf234: add             x3, x4, #1
    // 0xfaf238: mov             x0, x2
    // 0xfaf23c: b               #0xfaf04c
    // 0xfaf240: mov             x2, x0
    // 0xfaf244: mov             x0, x2
    // 0xfaf248: LeaveFrame
    //     0xfaf248: mov             SP, fp
    //     0xfaf24c: ldp             fp, lr, [SP], #0x10
    // 0xfaf250: ret
    //     0xfaf250: ret             
    // 0xfaf254: r1 = Function '<anonymous closure>': static.
    //     0xfaf254: add             x1, PP, #0x80, lsl #12  ; [pp+0x80a08] AnonymousClosure: static (0xfaf770), in [package:flutter/src/material/adaptive_text_selection_toolbar.dart] AdaptiveTextSelectionToolbar::getAdaptiveButtons (0xfaefe4)
    //     0xfaf258: ldr             x1, [x1, #0xa08]
    // 0xfaf25c: r2 = Null
    //     0xfaf25c: mov             x2, NULL
    // 0xfaf260: r0 = AllocateClosure()
    //     0xfaf260: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfaf264: r16 = <Widget>
    //     0xfaf264: ldr             x16, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfaf268: ldur            lr, [fp, #-0x10]
    // 0xfaf26c: stp             lr, x16, [SP, #8]
    // 0xfaf270: str             x0, [SP]
    // 0xfaf274: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xfaf274: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xfaf278: r0 = map()
    //     0xfaf278: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0xfaf27c: LeaveFrame
    //     0xfaf27c: mov             SP, fp
    //     0xfaf280: ldp             fp, lr, [SP], #0x10
    // 0xfaf284: ret
    //     0xfaf284: ret             
    // 0xfaf288: cmp             x0, #4
    // 0xfaf28c: b.gt            #0xfaf2cc
    // 0xfaf290: cmp             x0, #3
    // 0xfaf294: b.le            #0xfaf2cc
    // 0xfaf298: ldur            x2, [fp, #-0x18]
    // 0xfaf29c: r1 = Function '<anonymous closure>': static.
    //     0xfaf29c: add             x1, PP, #0x80, lsl #12  ; [pp+0x80a10] AnonymousClosure: static (0xfaf6f4), in [package:flutter/src/material/adaptive_text_selection_toolbar.dart] AdaptiveTextSelectionToolbar::getAdaptiveButtons (0xfaefe4)
    //     0xfaf2a0: ldr             x1, [x1, #0xa10]
    // 0xfaf2a4: r0 = AllocateClosure()
    //     0xfaf2a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfaf2a8: r16 = <Widget>
    //     0xfaf2a8: ldr             x16, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfaf2ac: ldur            lr, [fp, #-0x10]
    // 0xfaf2b0: stp             lr, x16, [SP, #8]
    // 0xfaf2b4: str             x0, [SP]
    // 0xfaf2b8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xfaf2b8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xfaf2bc: r0 = map()
    //     0xfaf2bc: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0xfaf2c0: LeaveFrame
    //     0xfaf2c0: mov             SP, fp
    //     0xfaf2c4: ldp             fp, lr, [SP], #0x10
    // 0xfaf2c8: ret
    //     0xfaf2c8: ret             
    // 0xfaf2cc: ldur            x2, [fp, #-0x18]
    // 0xfaf2d0: r1 = Function '<anonymous closure>': static.
    //     0xfaf2d0: add             x1, PP, #0x80, lsl #12  ; [pp+0x80a18] AnonymousClosure: static (0xfaf56c), in [package:flutter/src/material/adaptive_text_selection_toolbar.dart] AdaptiveTextSelectionToolbar::getAdaptiveButtons (0xfaefe4)
    //     0xfaf2d4: ldr             x1, [x1, #0xa18]
    // 0xfaf2d8: r0 = AllocateClosure()
    //     0xfaf2d8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfaf2dc: r16 = <Widget>
    //     0xfaf2dc: ldr             x16, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfaf2e0: ldur            lr, [fp, #-0x10]
    // 0xfaf2e4: stp             lr, x16, [SP, #8]
    // 0xfaf2e8: str             x0, [SP]
    // 0xfaf2ec: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xfaf2ec: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xfaf2f0: r0 = map()
    //     0xfaf2f0: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0xfaf2f4: LeaveFrame
    //     0xfaf2f4: mov             SP, fp
    //     0xfaf2f8: ldp             fp, lr, [SP], #0x10
    // 0xfaf2fc: ret
    //     0xfaf2fc: ret             
    // 0xfaf300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaf300: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaf304: b               #0xfaf004
    // 0xfaf308: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaf308: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaf30c: b               #0xfaf064
  }
  static _ getButtonLabel(/* No info */) {
    // ** addr: 0xfaf31c, size: 0x250
    // 0xfaf31c: EnterFrame
    //     0xfaf31c: stp             fp, lr, [SP, #-0x10]!
    //     0xfaf320: mov             fp, SP
    // 0xfaf324: AllocStack(0x18)
    //     0xfaf324: sub             SP, SP, #0x18
    // 0xfaf328: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xfaf328: mov             x0, x1
    //     0xfaf32c: stur            x1, [fp, #-8]
    //     0xfaf330: stur            x2, [fp, #-0x10]
    // 0xfaf334: CheckStackOverflow
    //     0xfaf334: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaf338: cmp             SP, x16
    //     0xfaf33c: b.ls            #0xfaf564
    // 0xfaf340: LoadField: r1 = r2->field_f
    //     0xfaf340: ldur            w1, [x2, #0xf]
    // 0xfaf344: DecompressPointer r1
    //     0xfaf344: add             x1, x1, HEAP, lsl #32
    // 0xfaf348: cmp             w1, NULL
    // 0xfaf34c: b.eq            #0xfaf360
    // 0xfaf350: mov             x0, x1
    // 0xfaf354: LeaveFrame
    //     0xfaf354: mov             SP, fp
    //     0xfaf358: ldp             fp, lr, [SP], #0x10
    // 0xfaf35c: ret
    //     0xfaf35c: ret             
    // 0xfaf360: mov             x1, x0
    // 0xfaf364: r0 = of()
    //     0xfaf364: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfaf368: LoadField: r1 = r0->field_23
    //     0xfaf368: ldur            w1, [x0, #0x23]
    // 0xfaf36c: DecompressPointer r1
    //     0xfaf36c: add             x1, x1, HEAP, lsl #32
    // 0xfaf370: LoadField: r0 = r1->field_7
    //     0xfaf370: ldur            x0, [x1, #7]
    // 0xfaf374: cmp             x0, #2
    // 0xfaf378: b.gt            #0xfaf388
    // 0xfaf37c: cmp             x0, #1
    // 0xfaf380: b.gt            #0xfaf398
    // 0xfaf384: b               #0xfaf3b0
    // 0xfaf388: cmp             x0, #4
    // 0xfaf38c: b.gt            #0xfaf3b0
    // 0xfaf390: cmp             x0, #3
    // 0xfaf394: b.le            #0xfaf3b0
    // 0xfaf398: ldur            x1, [fp, #-8]
    // 0xfaf39c: ldur            x2, [fp, #-0x10]
    // 0xfaf3a0: r0 = getButtonLabel()
    //     0xfaf3a0: bl              #0xde7748  ; [package:flutter/src/cupertino/text_selection_toolbar_button.dart] CupertinoTextSelectionToolbarButton::getButtonLabel
    // 0xfaf3a4: LeaveFrame
    //     0xfaf3a4: mov             SP, fp
    //     0xfaf3a8: ldp             fp, lr, [SP], #0x10
    // 0xfaf3ac: ret
    //     0xfaf3ac: ret             
    // 0xfaf3b0: ldur            x0, [fp, #-0x10]
    // 0xfaf3b4: ldur            x1, [fp, #-8]
    // 0xfaf3b8: r0 = of()
    //     0xfaf3b8: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xfaf3bc: mov             x1, x0
    // 0xfaf3c0: ldur            x0, [fp, #-0x10]
    // 0xfaf3c4: LoadField: r2 = r0->field_b
    //     0xfaf3c4: ldur            w2, [x0, #0xb]
    // 0xfaf3c8: DecompressPointer r2
    //     0xfaf3c8: add             x2, x2, HEAP, lsl #32
    // 0xfaf3cc: LoadField: r0 = r2->field_7
    //     0xfaf3cc: ldur            x0, [x2, #7]
    // 0xfaf3d0: cmp             x0, #4
    // 0xfaf3d4: b.gt            #0xfaf4b4
    // 0xfaf3d8: cmp             x0, #2
    // 0xfaf3dc: b.gt            #0xfaf450
    // 0xfaf3e0: cmp             x0, #1
    // 0xfaf3e4: b.gt            #0xfaf430
    // 0xfaf3e8: cmp             x0, #0
    // 0xfaf3ec: b.gt            #0xfaf410
    // 0xfaf3f0: r0 = LoadClassIdInstr(r1)
    //     0xfaf3f0: ldur            x0, [x1, #-1]
    //     0xfaf3f4: ubfx            x0, x0, #0xc, #0x14
    // 0xfaf3f8: r0 = GDT[cid_x0 + 0x14f1b]()
    //     0xfaf3f8: mov             x17, #0x4f1b
    //     0xfaf3fc: movk            x17, #1, lsl #16
    //     0xfaf400: add             lr, x0, x17
    //     0xfaf404: ldr             lr, [x21, lr, lsl #3]
    //     0xfaf408: blr             lr
    // 0xfaf40c: b               #0xfaf558
    // 0xfaf410: r0 = LoadClassIdInstr(r1)
    //     0xfaf410: ldur            x0, [x1, #-1]
    //     0xfaf414: ubfx            x0, x0, #0xc, #0x14
    // 0xfaf418: r0 = GDT[cid_x0 + 0x14ea4]()
    //     0xfaf418: mov             x17, #0x4ea4
    //     0xfaf41c: movk            x17, #1, lsl #16
    //     0xfaf420: add             lr, x0, x17
    //     0xfaf424: ldr             lr, [x21, lr, lsl #3]
    //     0xfaf428: blr             lr
    // 0xfaf42c: b               #0xfaf558
    // 0xfaf430: r0 = LoadClassIdInstr(r1)
    //     0xfaf430: ldur            x0, [x1, #-1]
    //     0xfaf434: ubfx            x0, x0, #0xc, #0x14
    // 0xfaf438: r0 = GDT[cid_x0 + 0x15492]()
    //     0xfaf438: mov             x17, #0x5492
    //     0xfaf43c: movk            x17, #1, lsl #16
    //     0xfaf440: add             lr, x0, x17
    //     0xfaf444: ldr             lr, [x21, lr, lsl #3]
    //     0xfaf448: blr             lr
    // 0xfaf44c: b               #0xfaf558
    // 0xfaf450: cmp             x0, #3
    // 0xfaf454: b.gt            #0xfaf478
    // 0xfaf458: r0 = LoadClassIdInstr(r1)
    //     0xfaf458: ldur            x0, [x1, #-1]
    //     0xfaf45c: ubfx            x0, x0, #0xc, #0x14
    // 0xfaf460: r0 = GDT[cid_x0 + 0x14e2d]()
    //     0xfaf460: mov             x17, #0x4e2d
    //     0xfaf464: movk            x17, #1, lsl #16
    //     0xfaf468: add             lr, x0, x17
    //     0xfaf46c: ldr             lr, [x21, lr, lsl #3]
    //     0xfaf470: blr             lr
    // 0xfaf474: b               #0xfaf558
    // 0xfaf478: r0 = LoadClassIdInstr(r1)
    //     0xfaf478: ldur            x0, [x1, #-1]
    //     0xfaf47c: ubfx            x0, x0, #0xc, #0x14
    // 0xfaf480: r0 = GDT[cid_x0 + 0x14a9c]()
    //     0xfaf480: mov             x17, #0x4a9c
    //     0xfaf484: movk            x17, #1, lsl #16
    //     0xfaf488: add             lr, x0, x17
    //     0xfaf48c: ldr             lr, [x21, lr, lsl #3]
    //     0xfaf490: blr             lr
    // 0xfaf494: r1 = LoadClassIdInstr(r0)
    //     0xfaf494: ldur            x1, [x0, #-1]
    //     0xfaf498: ubfx            x1, x1, #0xc, #0x14
    // 0xfaf49c: str             x0, [SP]
    // 0xfaf4a0: mov             x0, x1
    // 0xfaf4a4: r0 = GDT[cid_x0 + -0xff8]()
    //     0xfaf4a4: sub             lr, x0, #0xff8
    //     0xfaf4a8: ldr             lr, [x21, lr, lsl #3]
    //     0xfaf4ac: blr             lr
    // 0xfaf4b0: b               #0xfaf558
    // 0xfaf4b4: cmp             x0, #7
    // 0xfaf4b8: b.gt            #0xfaf52c
    // 0xfaf4bc: cmp             x0, #6
    // 0xfaf4c0: b.gt            #0xfaf50c
    // 0xfaf4c4: cmp             x0, #5
    // 0xfaf4c8: b.gt            #0xfaf4ec
    // 0xfaf4cc: r0 = LoadClassIdInstr(r1)
    //     0xfaf4cc: ldur            x0, [x1, #-1]
    //     0xfaf4d0: ubfx            x0, x0, #0xc, #0x14
    // 0xfaf4d4: r0 = GDT[cid_x0 + 0x157e0]()
    //     0xfaf4d4: mov             x17, #0x57e0
    //     0xfaf4d8: movk            x17, #1, lsl #16
    //     0xfaf4dc: add             lr, x0, x17
    //     0xfaf4e0: ldr             lr, [x21, lr, lsl #3]
    //     0xfaf4e4: blr             lr
    // 0xfaf4e8: b               #0xfaf558
    // 0xfaf4ec: r0 = LoadClassIdInstr(r1)
    //     0xfaf4ec: ldur            x0, [x1, #-1]
    //     0xfaf4f0: ubfx            x0, x0, #0xc, #0x14
    // 0xfaf4f4: r0 = GDT[cid_x0 + 0x15857]()
    //     0xfaf4f4: mov             x17, #0x5857
    //     0xfaf4f8: movk            x17, #1, lsl #16
    //     0xfaf4fc: add             lr, x0, x17
    //     0xfaf500: ldr             lr, [x21, lr, lsl #3]
    //     0xfaf504: blr             lr
    // 0xfaf508: b               #0xfaf558
    // 0xfaf50c: r0 = LoadClassIdInstr(r1)
    //     0xfaf50c: ldur            x0, [x1, #-1]
    //     0xfaf510: ubfx            x0, x0, #0xc, #0x14
    // 0xfaf514: r0 = GDT[cid_x0 + 0x158ce]()
    //     0xfaf514: mov             x17, #0x58ce
    //     0xfaf518: movk            x17, #1, lsl #16
    //     0xfaf51c: add             lr, x0, x17
    //     0xfaf520: ldr             lr, [x21, lr, lsl #3]
    //     0xfaf524: blr             lr
    // 0xfaf528: b               #0xfaf558
    // 0xfaf52c: cmp             x0, #8
    // 0xfaf530: b.gt            #0xfaf554
    // 0xfaf534: r0 = LoadClassIdInstr(r1)
    //     0xfaf534: ldur            x0, [x1, #-1]
    //     0xfaf538: ubfx            x0, x0, #0xc, #0x14
    // 0xfaf53c: r0 = GDT[cid_x0 + 0x152ac]()
    //     0xfaf53c: mov             x17, #0x52ac
    //     0xfaf540: movk            x17, #1, lsl #16
    //     0xfaf544: add             lr, x0, x17
    //     0xfaf548: ldr             lr, [x21, lr, lsl #3]
    //     0xfaf54c: blr             lr
    // 0xfaf550: b               #0xfaf558
    // 0xfaf554: r0 = ""
    //     0xfaf554: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0xfaf558: LeaveFrame
    //     0xfaf558: mov             SP, fp
    //     0xfaf55c: ldp             fp, lr, [SP], #0x10
    // 0xfaf560: ret
    //     0xfaf560: ret             
    // 0xfaf564: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaf564: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaf568: b               #0xfaf340
  }
  [closure] static DesktopTextSelectionToolbarButton <anonymous closure>(dynamic, ContextMenuButtonItem) {
    // ** addr: 0xfaf56c, size: 0x80
    // 0xfaf56c: EnterFrame
    //     0xfaf56c: stp             fp, lr, [SP, #-0x10]!
    //     0xfaf570: mov             fp, SP
    // 0xfaf574: AllocStack(0x18)
    //     0xfaf574: sub             SP, SP, #0x18
    // 0xfaf578: SetupParameters([dynamic _ /* r0 */])
    //     0xfaf578: ldr             x0, [fp, #0x18]
    //     0xfaf57c: ldur            w1, [x0, #0x17]
    //     0xfaf580: add             x1, x1, HEAP, lsl #32
    // 0xfaf584: CheckStackOverflow
    //     0xfaf584: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaf588: cmp             SP, x16
    //     0xfaf58c: b.ls            #0xfaf5e4
    // 0xfaf590: LoadField: r0 = r1->field_f
    //     0xfaf590: ldur            w0, [x1, #0xf]
    // 0xfaf594: DecompressPointer r0
    //     0xfaf594: add             x0, x0, HEAP, lsl #32
    // 0xfaf598: ldr             x2, [fp, #0x10]
    // 0xfaf59c: stur            x0, [fp, #-0x10]
    // 0xfaf5a0: LoadField: r3 = r2->field_7
    //     0xfaf5a0: ldur            w3, [x2, #7]
    // 0xfaf5a4: DecompressPointer r3
    //     0xfaf5a4: add             x3, x3, HEAP, lsl #32
    // 0xfaf5a8: mov             x1, x0
    // 0xfaf5ac: stur            x3, [fp, #-8]
    // 0xfaf5b0: r0 = getButtonLabel()
    //     0xfaf5b0: bl              #0xfaf31c  ; [package:flutter/src/material/adaptive_text_selection_toolbar.dart] AdaptiveTextSelectionToolbar::getButtonLabel
    // 0xfaf5b4: stur            x0, [fp, #-0x18]
    // 0xfaf5b8: r0 = DesktopTextSelectionToolbarButton()
    //     0xfaf5b8: bl              #0xfaf6e8  ; AllocateDesktopTextSelectionToolbarButtonStub -> DesktopTextSelectionToolbarButton (size=0x14)
    // 0xfaf5bc: mov             x1, x0
    // 0xfaf5c0: ldur            x2, [fp, #-0x10]
    // 0xfaf5c4: ldur            x3, [fp, #-8]
    // 0xfaf5c8: ldur            x5, [fp, #-0x18]
    // 0xfaf5cc: stur            x0, [fp, #-8]
    // 0xfaf5d0: r0 = DesktopTextSelectionToolbarButton.text()
    //     0xfaf5d0: bl              #0xfaf5ec  ; [package:flutter/src/material/desktop_text_selection_toolbar_button.dart] DesktopTextSelectionToolbarButton::DesktopTextSelectionToolbarButton.text
    // 0xfaf5d4: ldur            x0, [fp, #-8]
    // 0xfaf5d8: LeaveFrame
    //     0xfaf5d8: mov             SP, fp
    //     0xfaf5dc: ldp             fp, lr, [SP], #0x10
    // 0xfaf5e0: ret
    //     0xfaf5e0: ret             
    // 0xfaf5e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaf5e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaf5e8: b               #0xfaf590
  }
  [closure] static CupertinoDesktopTextSelectionToolbarButton <anonymous closure>(dynamic, ContextMenuButtonItem) {
    // ** addr: 0xfaf6f4, size: 0x70
    // 0xfaf6f4: EnterFrame
    //     0xfaf6f4: stp             fp, lr, [SP, #-0x10]!
    //     0xfaf6f8: mov             fp, SP
    // 0xfaf6fc: AllocStack(0x10)
    //     0xfaf6fc: sub             SP, SP, #0x10
    // 0xfaf700: SetupParameters([dynamic _ /* r0 */])
    //     0xfaf700: ldr             x0, [fp, #0x18]
    //     0xfaf704: ldur            w1, [x0, #0x17]
    //     0xfaf708: add             x1, x1, HEAP, lsl #32
    // 0xfaf70c: CheckStackOverflow
    //     0xfaf70c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaf710: cmp             SP, x16
    //     0xfaf714: b.ls            #0xfaf75c
    // 0xfaf718: ldr             x2, [fp, #0x10]
    // 0xfaf71c: LoadField: r0 = r2->field_7
    //     0xfaf71c: ldur            w0, [x2, #7]
    // 0xfaf720: DecompressPointer r0
    //     0xfaf720: add             x0, x0, HEAP, lsl #32
    // 0xfaf724: stur            x0, [fp, #-8]
    // 0xfaf728: LoadField: r3 = r1->field_f
    //     0xfaf728: ldur            w3, [x1, #0xf]
    // 0xfaf72c: DecompressPointer r3
    //     0xfaf72c: add             x3, x3, HEAP, lsl #32
    // 0xfaf730: mov             x1, x3
    // 0xfaf734: r0 = getButtonLabel()
    //     0xfaf734: bl              #0xfaf31c  ; [package:flutter/src/material/adaptive_text_selection_toolbar.dart] AdaptiveTextSelectionToolbar::getButtonLabel
    // 0xfaf738: stur            x0, [fp, #-0x10]
    // 0xfaf73c: r0 = CupertinoDesktopTextSelectionToolbarButton()
    //     0xfaf73c: bl              #0xfaf764  ; AllocateCupertinoDesktopTextSelectionToolbarButtonStub -> CupertinoDesktopTextSelectionToolbarButton (size=0x18)
    // 0xfaf740: ldur            x1, [fp, #-8]
    // 0xfaf744: StoreField: r0->field_f = r1
    //     0xfaf744: stur            w1, [x0, #0xf]
    // 0xfaf748: ldur            x1, [fp, #-0x10]
    // 0xfaf74c: StoreField: r0->field_b = r1
    //     0xfaf74c: stur            w1, [x0, #0xb]
    // 0xfaf750: LeaveFrame
    //     0xfaf750: mov             SP, fp
    //     0xfaf754: ldp             fp, lr, [SP], #0x10
    // 0xfaf758: ret
    //     0xfaf758: ret             
    // 0xfaf75c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaf75c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaf760: b               #0xfaf718
  }
  [closure] static CupertinoTextSelectionToolbarButton <anonymous closure>(dynamic, ContextMenuButtonItem) {
    // ** addr: 0xfaf770, size: 0x2c
    // 0xfaf770: EnterFrame
    //     0xfaf770: stp             fp, lr, [SP, #-0x10]!
    //     0xfaf774: mov             fp, SP
    // 0xfaf778: r0 = CupertinoTextSelectionToolbarButton()
    //     0xfaf778: bl              #0xd777a0  ; AllocateCupertinoTextSelectionToolbarButtonStub -> CupertinoTextSelectionToolbarButton (size=0x1c)
    // 0xfaf77c: ldr             x1, [fp, #0x10]
    // 0xfaf780: StoreField: r0->field_f = r1
    //     0xfaf780: stur            w1, [x0, #0xf]
    // 0xfaf784: LoadField: r2 = r1->field_7
    //     0xfaf784: ldur            w2, [x1, #7]
    // 0xfaf788: DecompressPointer r2
    //     0xfaf788: add             x2, x2, HEAP, lsl #32
    // 0xfaf78c: ArrayStore: r0[0] = r2  ; List_4
    //     0xfaf78c: stur            w2, [x0, #0x17]
    // 0xfaf790: LeaveFrame
    //     0xfaf790: mov             SP, fp
    //     0xfaf794: ldp             fp, lr, [SP], #0x10
    // 0xfaf798: ret
    //     0xfaf798: ret             
  }
}
