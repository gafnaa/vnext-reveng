// lib: material_animated_icons, url: package:flutter/src/material/animated_icons.dart

// class id: 1048841, size: 0x8
class :: {

  static _ _interpolate(/* No info */) {
    // ** addr: 0xb760f0, size: 0x218
    // 0xb760f0: EnterFrame
    //     0xb760f0: stp             fp, lr, [SP, #-0x10]!
    //     0xb760f4: mov             fp, SP
    // 0xb760f8: AllocStack(0x28)
    //     0xb760f8: sub             SP, SP, #0x28
    // 0xb760fc: CheckStackOverflow
    //     0xb760fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb76100: cmp             SP, x16
    //     0xb76104: b.ls            #0xb76270
    // 0xb76108: ldr             x4, [fp, #0x20]
    // 0xb7610c: LoadField: r0 = r4->field_b
    //     0xb7610c: ldur            w0, [x4, #0xb]
    // 0xb76110: r5 = LoadInt32Instr(r0)
    //     0xb76110: sbfx            x5, x0, #1, #0x1f
    // 0xb76114: stur            x5, [fp, #-8]
    // 0xb76118: cmp             x5, #1
    // 0xb7611c: b.ne            #0xb76144
    // 0xb76120: mov             x0, x5
    // 0xb76124: r1 = 0
    //     0xb76124: mov             x1, #0
    // 0xb76128: cmp             x1, x0
    // 0xb7612c: b.hs            #0xb76278
    // 0xb76130: LoadField: r0 = r4->field_f
    //     0xb76130: ldur            w0, [x4, #0xf]
    // 0xb76134: DecompressPointer r0
    //     0xb76134: add             x0, x0, HEAP, lsl #32
    // 0xb76138: LeaveFrame
    //     0xb76138: mov             SP, fp
    //     0xb7613c: ldp             fp, lr, [SP], #0x10
    // 0xb76140: ret
    //     0xb76140: ret             
    // 0xb76144: ldr             d0, [fp, #0x18]
    // 0xb76148: sub             x0, x5, #1
    // 0xb7614c: r3 = inline_Allocate_Double()
    //     0xb7614c: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0xb76150: add             x3, x3, #0x10
    //     0xb76154: cmp             x1, x3
    //     0xb76158: b.ls            #0xb7627c
    //     0xb7615c: str             x3, [THR, #0x60]  ; THR::top
    //     0xb76160: sub             x3, x3, #0xf
    //     0xb76164: mov             x1, #0xe19c
    //     0xb76168: movk            x1, #3, lsl #16
    //     0xb7616c: stur            x1, [x3, #-1]
    // 0xb76170: dmb             ishst
    // 0xb76174: StoreField: r3->field_7 = d0
    //     0xb76174: stur            d0, [x3, #7]
    // 0xb76178: lsl             x2, x0, #1
    // 0xb7617c: r1 = 0
    //     0xb7617c: mov             x1, #0
    // 0xb76180: r0 = lerpDouble()
    //     0xb76180: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xb76184: LoadField: d0 = r0->field_7
    //     0xb76184: ldur            d0, [x0, #7]
    // 0xb76188: fcmp            d0, d0
    // 0xb7618c: b.vs            #0xb762a0
    // 0xb76190: fcvtms          x0, d0
    // 0xb76194: asr             x16, x0, #0x1e
    // 0xb76198: cmp             x16, x0, asr #63
    // 0xb7619c: b.ne            #0xb762a0
    // 0xb761a0: lsl             x0, x0, #1
    // 0xb761a4: fcmp            d0, d0
    // 0xb761a8: b.vs            #0xb762bc
    // 0xb761ac: fcvtps          x2, d0
    // 0xb761b0: asr             x16, x2, #0x1e
    // 0xb761b4: cmp             x16, x2, asr #63
    // 0xb761b8: b.ne            #0xb762bc
    // 0xb761bc: lsl             x2, x2, #1
    // 0xb761c0: r3 = LoadInt32Instr(r0)
    //     0xb761c0: sbfx            x3, x0, #1, #0x1f
    //     0xb761c4: tbz             w0, #0, #0xb761cc
    //     0xb761c8: ldur            x3, [x0, #7]
    // 0xb761cc: scvtf           d1, x3
    // 0xb761d0: fsub            d2, d0, d1
    // 0xb761d4: ldur            x0, [fp, #-8]
    // 0xb761d8: mov             x1, x3
    // 0xb761dc: cmp             x1, x0
    // 0xb761e0: b.hs            #0xb762e4
    // 0xb761e4: ldr             x4, [fp, #0x20]
    // 0xb761e8: ArrayLoad: r5 = r4[r3]  ; Unknown_4
    //     0xb761e8: add             x16, x4, x3, lsl #2
    //     0xb761ec: ldur            w5, [x16, #0xf]
    // 0xb761f0: DecompressPointer r5
    //     0xb761f0: add             x5, x5, HEAP, lsl #32
    // 0xb761f4: r3 = LoadInt32Instr(r2)
    //     0xb761f4: sbfx            x3, x2, #1, #0x1f
    //     0xb761f8: tbz             w2, #0, #0xb76200
    //     0xb761fc: ldur            x3, [x2, #7]
    // 0xb76200: ldur            x0, [fp, #-8]
    // 0xb76204: mov             x1, x3
    // 0xb76208: cmp             x1, x0
    // 0xb7620c: b.hs            #0xb762e8
    // 0xb76210: ArrayLoad: r0 = r4[r3]  ; Unknown_4
    //     0xb76210: add             x16, x4, x3, lsl #2
    //     0xb76214: ldur            w0, [x16, #0xf]
    // 0xb76218: DecompressPointer r0
    //     0xb76218: add             x0, x0, HEAP, lsl #32
    // 0xb7621c: r1 = inline_Allocate_Double()
    //     0xb7621c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb76220: add             x1, x1, #0x10
    //     0xb76224: cmp             x2, x1
    //     0xb76228: b.ls            #0xb762ec
    //     0xb7622c: str             x1, [THR, #0x60]  ; THR::top
    //     0xb76230: sub             x1, x1, #0xf
    //     0xb76234: mov             x2, #0xe19c
    //     0xb76238: movk            x2, #3, lsl #16
    //     0xb7623c: stur            x2, [x1, #-1]
    // 0xb76240: dmb             ishst
    // 0xb76244: StoreField: r1->field_7 = d2
    //     0xb76244: stur            d2, [x1, #7]
    // 0xb76248: ldr             x16, [fp, #0x10]
    // 0xb7624c: stp             x5, x16, [SP, #0x10]
    // 0xb76250: stp             x1, x0, [SP]
    // 0xb76254: ldr             x0, [fp, #0x10]
    // 0xb76258: ClosureCall
    //     0xb76258: ldr             x4, [PP, #0x9d0]  ; [pp+0x9d0] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0xb7625c: ldur            x2, [x0, #0x1f]
    //     0xb76260: blr             x2
    // 0xb76264: LeaveFrame
    //     0xb76264: mov             SP, fp
    //     0xb76268: ldp             fp, lr, [SP], #0x10
    // 0xb7626c: ret
    //     0xb7626c: ret             
    // 0xb76270: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb76270: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb76274: b               #0xb76108
    // 0xb76278: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb76278: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb7627c: SaveReg d0
    //     0xb7627c: str             q0, [SP, #-0x10]!
    // 0xb76280: stp             x4, x5, [SP, #-0x10]!
    // 0xb76284: SaveReg r0
    //     0xb76284: str             x0, [SP, #-8]!
    // 0xb76288: r0 = AllocateDouble()
    //     0xb76288: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb7628c: mov             x3, x0
    // 0xb76290: RestoreReg r0
    //     0xb76290: ldr             x0, [SP], #8
    // 0xb76294: ldp             x4, x5, [SP], #0x10
    // 0xb76298: RestoreReg d0
    //     0xb76298: ldr             q0, [SP], #0x10
    // 0xb7629c: b               #0xb76174
    // 0xb762a0: SaveReg d0
    //     0xb762a0: str             q0, [SP, #-0x10]!
    // 0xb762a4: r0 = 70
    //     0xb762a4: mov             x0, #0x46
    // 0xb762a8: r30 = DoubleToIntegerStub
    //     0xb762a8: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xb762ac: LoadField: r30 = r30->field_7
    //     0xb762ac: ldur            lr, [lr, #7]
    // 0xb762b0: blr             lr
    // 0xb762b4: RestoreReg d0
    //     0xb762b4: ldr             q0, [SP], #0x10
    // 0xb762b8: b               #0xb761a4
    // 0xb762bc: SaveReg d0
    //     0xb762bc: str             q0, [SP, #-0x10]!
    // 0xb762c0: SaveReg r0
    //     0xb762c0: str             x0, [SP, #-8]!
    // 0xb762c4: r0 = 66
    //     0xb762c4: mov             x0, #0x42
    // 0xb762c8: r30 = DoubleToIntegerStub
    //     0xb762c8: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xb762cc: LoadField: r30 = r30->field_7
    //     0xb762cc: ldur            lr, [lr, #7]
    // 0xb762d0: blr             lr
    // 0xb762d4: mov             x2, x0
    // 0xb762d8: RestoreReg r0
    //     0xb762d8: ldr             x0, [SP], #8
    // 0xb762dc: RestoreReg d0
    //     0xb762dc: ldr             q0, [SP], #0x10
    // 0xb762e0: b               #0xb761c0
    // 0xb762e4: r0 = RangeErrorSharedWithFPURegs()
    //     0xb762e4: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xb762e8: r0 = RangeErrorSharedWithFPURegs()
    //     0xb762e8: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xb762ec: SaveReg d2
    //     0xb762ec: str             q2, [SP, #-0x10]!
    // 0xb762f0: stp             x0, x5, [SP, #-0x10]!
    // 0xb762f4: r0 = AllocateDouble()
    //     0xb762f4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb762f8: mov             x1, x0
    // 0xb762fc: ldp             x0, x5, [SP], #0x10
    // 0xb76300: RestoreReg d2
    //     0xb76300: ldr             q2, [SP], #0x10
    // 0xb76304: b               #0xb76244
  }
}

// class id: 3137, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class AnimatedIconData extends Object {
}

// class id: 3138, size: 0x14, field offset: 0x8
//   const constructor, 
class _AnimatedIconData extends AnimatedIconData {

  Size field_8;
  _ImmutableList<_PathFrames> field_c;
  bool field_10;
}

// class id: 3139, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class _PathCommand extends Object {
}

// class id: 3140, size: 0x8, field offset: 0x8
//   const constructor, 
class _PathClose extends _PathCommand {

  _ apply(/* No info */) {
    // ** addr: 0x12f4b48, size: 0x80
    // 0x12f4b48: EnterFrame
    //     0x12f4b48: stp             fp, lr, [SP, #-0x10]!
    //     0x12f4b4c: mov             fp, SP
    // 0x12f4b50: AllocStack(0x18)
    //     0x12f4b50: sub             SP, SP, #0x18
    // 0x12f4b54: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x12f4b54: stur            x2, [fp, #-0x10]
    // 0x12f4b58: CheckStackOverflow
    //     0x12f4b58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f4b5c: cmp             SP, x16
    //     0x12f4b60: b.ls            #0x12f4bbc
    // 0x12f4b64: LoadField: r0 = r2->field_7
    //     0x12f4b64: ldur            w0, [x2, #7]
    // 0x12f4b68: DecompressPointer r0
    //     0x12f4b68: add             x0, x0, HEAP, lsl #32
    // 0x12f4b6c: cmp             w0, NULL
    // 0x12f4b70: b.eq            #0x12f4bc4
    // 0x12f4b74: LoadField: r1 = r0->field_7
    //     0x12f4b74: ldur            x1, [x0, #7]
    // 0x12f4b78: ldr             x0, [x1]
    // 0x12f4b7c: cbz             x0, #0x12f4bac
    // 0x12f4b80: stur            x0, [fp, #-8]
    // 0x12f4b84: r1 = <Never>
    //     0x12f4b84: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f4b88: r0 = Pointer()
    //     0x12f4b88: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f4b8c: mov             x1, x0
    // 0x12f4b90: ldur            x0, [fp, #-8]
    // 0x12f4b94: StoreField: r1->field_7 = r0
    //     0x12f4b94: stur            x0, [x1, #7]
    // 0x12f4b98: r0 = _close$Method$FfiNative()
    //     0x12f4b98: bl              #0xb78188  ; [dart:ui] _NativePath::_close$Method$FfiNative
    // 0x12f4b9c: r0 = Null
    //     0x12f4b9c: mov             x0, NULL
    // 0x12f4ba0: LeaveFrame
    //     0x12f4ba0: mov             SP, fp
    //     0x12f4ba4: ldp             fp, lr, [SP], #0x10
    // 0x12f4ba8: ret
    //     0x12f4ba8: ret             
    // 0x12f4bac: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f4bac: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f4bb0: str             x16, [SP]
    // 0x12f4bb4: r0 = _throwNew()
    //     0x12f4bb4: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f4bb8: brk             #0
    // 0x12f4bbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f4bbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f4bc0: b               #0x12f4b64
    // 0x12f4bc4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12f4bc4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 3141, size: 0x14, field offset: 0x8
//   const constructor, 
class _PathCubicTo extends _PathCommand {

  _ImmutableList<Offset> field_8;
  _ImmutableList<Offset> field_c;
  _ImmutableList<Offset> field_10;

  _ apply(/* No info */) {
    // ** addr: 0x12f49a8, size: 0x1a0
    // 0x12f49a8: EnterFrame
    //     0x12f49a8: stp             fp, lr, [SP, #-0x10]!
    //     0x12f49ac: mov             fp, SP
    // 0x12f49b0: AllocStack(0x78)
    //     0x12f49b0: sub             SP, SP, #0x78
    // 0x12f49b4: SetupParameters(_PathCubicTo this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x30 */)
    //     0x12f49b4: stur            x1, [fp, #-8]
    //     0x12f49b8: stur            x2, [fp, #-0x10]
    //     0x12f49bc: stur            d0, [fp, #-0x30]
    // 0x12f49c0: CheckStackOverflow
    //     0x12f49c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f49c4: cmp             SP, x16
    //     0x12f49c8: b.ls            #0x12f4b30
    // 0x12f49cc: LoadField: r0 = r1->field_b
    //     0x12f49cc: ldur            w0, [x1, #0xb]
    // 0x12f49d0: DecompressPointer r0
    //     0x12f49d0: add             x0, x0, HEAP, lsl #32
    // 0x12f49d4: r16 = <Offset?>
    //     0x12f49d4: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd4fa8] TypeArguments: <Offset?>
    //     0x12f49d8: ldr             x16, [x16, #0xfa8]
    // 0x12f49dc: stp             x0, x16, [SP, #0x10]
    // 0x12f49e0: str             d0, [SP, #8]
    // 0x12f49e4: r16 = Closure: (Offset?, Offset?, double) => Offset? from Function 'lerp': static.
    //     0x12f49e4: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd4fb0] Closure: (Offset?, Offset?, double) => Offset? from Function 'lerp': static. (0x7f2adaa52d68)
    //     0x12f49e8: ldr             x16, [x16, #0xfb0]
    // 0x12f49ec: str             x16, [SP]
    // 0x12f49f0: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x12f49f0: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x12f49f4: r0 = _interpolate()
    //     0x12f49f4: bl              #0xb760f0  ; [package:flutter/src/material/animated_icons.dart] ::_interpolate
    // 0x12f49f8: stur            x0, [fp, #-0x18]
    // 0x12f49fc: cmp             w0, NULL
    // 0x12f4a00: b.eq            #0x12f4b38
    // 0x12f4a04: ldur            x1, [fp, #-8]
    // 0x12f4a08: LoadField: r2 = r1->field_7
    //     0x12f4a08: ldur            w2, [x1, #7]
    // 0x12f4a0c: DecompressPointer r2
    //     0x12f4a0c: add             x2, x2, HEAP, lsl #32
    // 0x12f4a10: r16 = <Offset?>
    //     0x12f4a10: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd4fa8] TypeArguments: <Offset?>
    //     0x12f4a14: ldr             x16, [x16, #0xfa8]
    // 0x12f4a18: stp             x2, x16, [SP, #0x10]
    // 0x12f4a1c: ldur            d0, [fp, #-0x30]
    // 0x12f4a20: str             d0, [SP, #8]
    // 0x12f4a24: r16 = Closure: (Offset?, Offset?, double) => Offset? from Function 'lerp': static.
    //     0x12f4a24: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd4fb0] Closure: (Offset?, Offset?, double) => Offset? from Function 'lerp': static. (0x7f2adaa52d68)
    //     0x12f4a28: ldr             x16, [x16, #0xfb0]
    // 0x12f4a2c: str             x16, [SP]
    // 0x12f4a30: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x12f4a30: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x12f4a34: r0 = _interpolate()
    //     0x12f4a34: bl              #0xb760f0  ; [package:flutter/src/material/animated_icons.dart] ::_interpolate
    // 0x12f4a38: stur            x0, [fp, #-0x20]
    // 0x12f4a3c: cmp             w0, NULL
    // 0x12f4a40: b.eq            #0x12f4b3c
    // 0x12f4a44: ldur            x1, [fp, #-8]
    // 0x12f4a48: LoadField: r2 = r1->field_f
    //     0x12f4a48: ldur            w2, [x1, #0xf]
    // 0x12f4a4c: DecompressPointer r2
    //     0x12f4a4c: add             x2, x2, HEAP, lsl #32
    // 0x12f4a50: r16 = <Offset?>
    //     0x12f4a50: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd4fa8] TypeArguments: <Offset?>
    //     0x12f4a54: ldr             x16, [x16, #0xfa8]
    // 0x12f4a58: stp             x2, x16, [SP, #0x10]
    // 0x12f4a5c: ldur            d0, [fp, #-0x30]
    // 0x12f4a60: str             d0, [SP, #8]
    // 0x12f4a64: r16 = Closure: (Offset?, Offset?, double) => Offset? from Function 'lerp': static.
    //     0x12f4a64: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd4fb0] Closure: (Offset?, Offset?, double) => Offset? from Function 'lerp': static. (0x7f2adaa52d68)
    //     0x12f4a68: ldr             x16, [x16, #0xfb0]
    // 0x12f4a6c: str             x16, [SP]
    // 0x12f4a70: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x12f4a70: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x12f4a74: r0 = _interpolate()
    //     0x12f4a74: bl              #0xb760f0  ; [package:flutter/src/material/animated_icons.dart] ::_interpolate
    // 0x12f4a78: cmp             w0, NULL
    // 0x12f4a7c: b.eq            #0x12f4b40
    // 0x12f4a80: ldur            x1, [fp, #-0x18]
    // 0x12f4a84: LoadField: d0 = r1->field_7
    //     0x12f4a84: ldur            d0, [x1, #7]
    // 0x12f4a88: stur            d0, [fp, #-0x58]
    // 0x12f4a8c: LoadField: d1 = r1->field_f
    //     0x12f4a8c: ldur            d1, [x1, #0xf]
    // 0x12f4a90: ldur            x1, [fp, #-0x20]
    // 0x12f4a94: stur            d1, [fp, #-0x50]
    // 0x12f4a98: LoadField: d2 = r1->field_7
    //     0x12f4a98: ldur            d2, [x1, #7]
    // 0x12f4a9c: stur            d2, [fp, #-0x48]
    // 0x12f4aa0: LoadField: d3 = r1->field_f
    //     0x12f4aa0: ldur            d3, [x1, #0xf]
    // 0x12f4aa4: stur            d3, [fp, #-0x40]
    // 0x12f4aa8: LoadField: d4 = r0->field_7
    //     0x12f4aa8: ldur            d4, [x0, #7]
    // 0x12f4aac: stur            d4, [fp, #-0x38]
    // 0x12f4ab0: LoadField: d5 = r0->field_f
    //     0x12f4ab0: ldur            d5, [x0, #0xf]
    // 0x12f4ab4: ldur            x0, [fp, #-0x10]
    // 0x12f4ab8: stur            d5, [fp, #-0x30]
    // 0x12f4abc: LoadField: r1 = r0->field_7
    //     0x12f4abc: ldur            w1, [x0, #7]
    // 0x12f4ac0: DecompressPointer r1
    //     0x12f4ac0: add             x1, x1, HEAP, lsl #32
    // 0x12f4ac4: cmp             w1, NULL
    // 0x12f4ac8: b.eq            #0x12f4b44
    // 0x12f4acc: LoadField: r2 = r1->field_7
    //     0x12f4acc: ldur            x2, [x1, #7]
    // 0x12f4ad0: ldr             x1, [x2]
    // 0x12f4ad4: cbz             x1, #0x12f4b20
    // 0x12f4ad8: mov             x2, x1
    // 0x12f4adc: stur            x2, [fp, #-0x28]
    // 0x12f4ae0: r1 = <Never>
    //     0x12f4ae0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f4ae4: r0 = Pointer()
    //     0x12f4ae4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f4ae8: mov             x1, x0
    // 0x12f4aec: ldur            x0, [fp, #-0x28]
    // 0x12f4af0: StoreField: r1->field_7 = r0
    //     0x12f4af0: stur            x0, [x1, #7]
    // 0x12f4af4: ldur            d0, [fp, #-0x58]
    // 0x12f4af8: ldur            d1, [fp, #-0x50]
    // 0x12f4afc: ldur            d2, [fp, #-0x48]
    // 0x12f4b00: ldur            d3, [fp, #-0x40]
    // 0x12f4b04: ldur            d4, [fp, #-0x38]
    // 0x12f4b08: ldur            d5, [fp, #-0x30]
    // 0x12f4b0c: r0 = _cubicTo$Method$FfiNative()
    //     0x12f4b0c: bl              #0xc33360  ; [dart:ui] _NativePath::_cubicTo$Method$FfiNative
    // 0x12f4b10: r0 = Null
    //     0x12f4b10: mov             x0, NULL
    // 0x12f4b14: LeaveFrame
    //     0x12f4b14: mov             SP, fp
    //     0x12f4b18: ldp             fp, lr, [SP], #0x10
    // 0x12f4b1c: ret
    //     0x12f4b1c: ret             
    // 0x12f4b20: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f4b20: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f4b24: str             x16, [SP]
    // 0x12f4b28: r0 = _throwNew()
    //     0x12f4b28: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f4b2c: brk             #0
    // 0x12f4b30: r0 = StackOverflowSharedWithFPURegs()
    //     0x12f4b30: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12f4b34: b               #0x12f49cc
    // 0x12f4b38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f4b38: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12f4b3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f4b3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12f4b40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f4b40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12f4b44: r0 = NullErrorSharedWithFPURegs()
    //     0x12f4b44: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
}

// class id: 3142, size: 0xc, field offset: 0x8
//   const constructor, 
class _PathMoveTo extends _PathCommand {

  _ImmutableList<Offset> field_8;

  _ apply(/* No info */) {
    // ** addr: 0x12f48d0, size: 0xd8
    // 0x12f48d0: EnterFrame
    //     0x12f48d0: stp             fp, lr, [SP, #-0x10]!
    //     0x12f48d4: mov             fp, SP
    // 0x12f48d8: AllocStack(0x40)
    //     0x12f48d8: sub             SP, SP, #0x40
    // 0x12f48dc: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x12f48dc: stur            x2, [fp, #-8]
    // 0x12f48e0: CheckStackOverflow
    //     0x12f48e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f48e4: cmp             SP, x16
    //     0x12f48e8: b.ls            #0x12f4998
    // 0x12f48ec: LoadField: r0 = r1->field_7
    //     0x12f48ec: ldur            w0, [x1, #7]
    // 0x12f48f0: DecompressPointer r0
    //     0x12f48f0: add             x0, x0, HEAP, lsl #32
    // 0x12f48f4: r16 = <Offset?>
    //     0x12f48f4: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd4fa8] TypeArguments: <Offset?>
    //     0x12f48f8: ldr             x16, [x16, #0xfa8]
    // 0x12f48fc: stp             x0, x16, [SP, #0x10]
    // 0x12f4900: str             d0, [SP, #8]
    // 0x12f4904: r16 = Closure: (Offset?, Offset?, double) => Offset? from Function 'lerp': static.
    //     0x12f4904: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd4fb0] Closure: (Offset?, Offset?, double) => Offset? from Function 'lerp': static. (0x7f2adaa52d68)
    //     0x12f4908: ldr             x16, [x16, #0xfb0]
    // 0x12f490c: str             x16, [SP]
    // 0x12f4910: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x12f4910: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x12f4914: r0 = _interpolate()
    //     0x12f4914: bl              #0xb760f0  ; [package:flutter/src/material/animated_icons.dart] ::_interpolate
    // 0x12f4918: cmp             w0, NULL
    // 0x12f491c: b.eq            #0x12f49a0
    // 0x12f4920: LoadField: d0 = r0->field_7
    //     0x12f4920: ldur            d0, [x0, #7]
    // 0x12f4924: stur            d0, [fp, #-0x20]
    // 0x12f4928: LoadField: d1 = r0->field_f
    //     0x12f4928: ldur            d1, [x0, #0xf]
    // 0x12f492c: ldur            x0, [fp, #-8]
    // 0x12f4930: stur            d1, [fp, #-0x18]
    // 0x12f4934: LoadField: r1 = r0->field_7
    //     0x12f4934: ldur            w1, [x0, #7]
    // 0x12f4938: DecompressPointer r1
    //     0x12f4938: add             x1, x1, HEAP, lsl #32
    // 0x12f493c: cmp             w1, NULL
    // 0x12f4940: b.eq            #0x12f49a4
    // 0x12f4944: LoadField: r2 = r1->field_7
    //     0x12f4944: ldur            x2, [x1, #7]
    // 0x12f4948: ldr             x1, [x2]
    // 0x12f494c: cbz             x1, #0x12f4988
    // 0x12f4950: mov             x2, x1
    // 0x12f4954: stur            x2, [fp, #-0x10]
    // 0x12f4958: r1 = <Never>
    //     0x12f4958: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12f495c: r0 = Pointer()
    //     0x12f495c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12f4960: mov             x1, x0
    // 0x12f4964: ldur            x0, [fp, #-0x10]
    // 0x12f4968: StoreField: r1->field_7 = r0
    //     0x12f4968: stur            x0, [x1, #7]
    // 0x12f496c: ldur            d0, [fp, #-0x20]
    // 0x12f4970: ldur            d1, [fp, #-0x18]
    // 0x12f4974: r0 = _moveTo$Method$FfiNative()
    //     0x12f4974: bl              #0xb69c74  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x12f4978: r0 = Null
    //     0x12f4978: mov             x0, NULL
    // 0x12f497c: LeaveFrame
    //     0x12f497c: mov             SP, fp
    //     0x12f4980: ldp             fp, lr, [SP], #0x10
    // 0x12f4984: ret
    //     0x12f4984: ret             
    // 0x12f4988: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12f4988: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12f498c: str             x16, [SP]
    // 0x12f4990: r0 = _throwNew()
    //     0x12f4990: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12f4994: brk             #0
    // 0x12f4998: r0 = StackOverflowSharedWithFPURegs()
    //     0x12f4998: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12f499c: b               #0x12f48ec
    // 0x12f49a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12f49a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12f49a4: r0 = NullErrorSharedWithFPURegs()
    //     0x12f49a4: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
}

// class id: 3143, size: 0x10, field offset: 0x8
//   const constructor, 
class _PathFrames extends Object {

  _ImmutableList<_PathCommand> field_8;
  _ImmutableList<double> field_c;

  _ paint(/* No info */) {
    // ** addr: 0xb75e64, size: 0x220
    // 0xb75e64: EnterFrame
    //     0xb75e64: stp             fp, lr, [SP, #-0x10]!
    //     0xb75e68: mov             fp, SP
    // 0xb75e6c: AllocStack(0x68)
    //     0xb75e6c: sub             SP, SP, #0x68
    // 0xb75e70: SetupParameters(_PathFrames this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r1, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x48 */)
    //     0xb75e70: mov             x0, x1
    //     0xb75e74: stur            x1, [fp, #-8]
    //     0xb75e78: mov             x1, x3
    //     0xb75e7c: stur            x2, [fp, #-0x10]
    //     0xb75e80: stur            x3, [fp, #-0x18]
    //     0xb75e84: stur            d0, [fp, #-0x48]
    // 0xb75e88: CheckStackOverflow
    //     0xb75e88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb75e8c: cmp             SP, x16
    //     0xb75e90: b.ls            #0xb76068
    // 0xb75e94: LoadField: r3 = r0->field_b
    //     0xb75e94: ldur            w3, [x0, #0xb]
    // 0xb75e98: DecompressPointer r3
    //     0xb75e98: add             x3, x3, HEAP, lsl #32
    // 0xb75e9c: r16 = <double?>
    //     0xb75e9c: add             x16, PP, #0x7a, lsl #12  ; [pp+0x7aba8] TypeArguments: <double?>
    //     0xb75ea0: ldr             x16, [x16, #0xba8]
    // 0xb75ea4: stp             x3, x16, [SP, #0x10]
    // 0xb75ea8: str             d0, [SP, #8]
    // 0xb75eac: r16 = Closure: (num?, num?, double) => double? from Function 'lerpDouble': static.
    //     0xb75eac: add             x16, PP, #0xad, lsl #12  ; [pp+0xadd00] Closure: (num?, num?, double) => double? from Function 'lerpDouble': static. (0x7f2ada74fcc8)
    //     0xb75eb0: ldr             x16, [x16, #0xd00]
    // 0xb75eb4: str             x16, [SP]
    // 0xb75eb8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xb75eb8: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xb75ebc: r0 = _interpolate()
    //     0xb75ebc: bl              #0xb760f0  ; [package:flutter/src/material/animated_icons.dart] ::_interpolate
    // 0xb75ec0: stur            x0, [fp, #-0x20]
    // 0xb75ec4: cmp             w0, NULL
    // 0xb75ec8: b.eq            #0xb76070
    // 0xb75ecc: r16 = 136
    //     0xb75ecc: mov             x16, #0x88
    // 0xb75ed0: stp             x16, NULL, [SP]
    // 0xb75ed4: r0 = ByteData()
    //     0xb75ed4: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb75ed8: stur            x0, [fp, #-0x28]
    // 0xb75edc: r0 = Paint()
    //     0xb75edc: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb75ee0: ldur            x5, [fp, #-0x28]
    // 0xb75ee4: stur            x0, [fp, #-0x30]
    // 0xb75ee8: StoreField: r0->field_7 = r5
    //     0xb75ee8: stur            w5, [x0, #7]
    // 0xb75eec: ArrayLoad: r1 = r5[0]  ; List_4
    //     0xb75eec: ldur            w1, [x5, #0x17]
    // 0xb75ef0: DecompressPointer r1
    //     0xb75ef0: add             x1, x1, HEAP, lsl #32
    // 0xb75ef4: LoadField: r2 = r1->field_7
    //     0xb75ef4: ldur            x2, [x1, #7]
    // 0xb75ef8: str             wzr, [x2, #0x1c]
    // 0xb75efc: ldur            x1, [fp, #-0x18]
    // 0xb75f00: r0 = opacity()
    //     0xb75f00: bl              #0x12d8430  ; [dart:ui] Color::opacity
    // 0xb75f04: ldur            x0, [fp, #-0x20]
    // 0xb75f08: LoadField: d1 = r0->field_7
    //     0xb75f08: ldur            d1, [x0, #7]
    // 0xb75f0c: fmul            d2, d0, d1
    // 0xb75f10: ldur            x1, [fp, #-0x18]
    // 0xb75f14: mov             v0.16b, v2.16b
    // 0xb75f18: r0 = withOpacity()
    //     0xb75f18: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xb75f1c: ldur            x1, [fp, #-0x30]
    // 0xb75f20: mov             x2, x0
    // 0xb75f24: r0 = color=()
    //     0xb75f24: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb75f28: r0 = _pathFactory()
    //     0xb75f28: bl              #0xb760b0  ; [package:flutter/src/material/animated_icons.dart] AnimatedIcon::_pathFactory
    // 0xb75f2c: mov             x3, x0
    // 0xb75f30: ldur            x0, [fp, #-8]
    // 0xb75f34: stur            x3, [fp, #-0x20]
    // 0xb75f38: LoadField: r4 = r0->field_7
    //     0xb75f38: ldur            w4, [x0, #7]
    // 0xb75f3c: DecompressPointer r4
    //     0xb75f3c: add             x4, x4, HEAP, lsl #32
    // 0xb75f40: stur            x4, [fp, #-0x18]
    // 0xb75f44: LoadField: r0 = r4->field_b
    //     0xb75f44: ldur            w0, [x4, #0xb]
    // 0xb75f48: r5 = LoadInt32Instr(r0)
    //     0xb75f48: sbfx            x5, x0, #1, #0x1f
    // 0xb75f4c: stur            x5, [fp, #-0x40]
    // 0xb75f50: r0 = 0
    //     0xb75f50: mov             x0, #0
    // 0xb75f54: CheckStackOverflow
    //     0xb75f54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb75f58: cmp             SP, x16
    //     0xb75f5c: b.ls            #0xb76074
    // 0xb75f60: cmp             x0, x5
    // 0xb75f64: b.ge            #0xb75fac
    // 0xb75f68: ArrayLoad: r1 = r4[r0]  ; Unknown_4
    //     0xb75f68: add             x16, x4, x0, lsl #2
    //     0xb75f6c: ldur            w1, [x16, #0xf]
    // 0xb75f70: DecompressPointer r1
    //     0xb75f70: add             x1, x1, HEAP, lsl #32
    // 0xb75f74: add             x6, x0, #1
    // 0xb75f78: stur            x6, [fp, #-0x38]
    // 0xb75f7c: r0 = LoadClassIdInstr(r1)
    //     0xb75f7c: ldur            x0, [x1, #-1]
    //     0xb75f80: ubfx            x0, x0, #0xc, #0x14
    // 0xb75f84: mov             x2, x3
    // 0xb75f88: ldur            d0, [fp, #-0x48]
    // 0xb75f8c: r0 = GDT[cid_x0 + -0xf3d]()
    //     0xb75f8c: sub             lr, x0, #0xf3d
    //     0xb75f90: ldr             lr, [x21, lr, lsl #3]
    //     0xb75f94: blr             lr
    // 0xb75f98: ldur            x0, [fp, #-0x38]
    // 0xb75f9c: ldur            x4, [fp, #-0x18]
    // 0xb75fa0: ldur            x3, [fp, #-0x20]
    // 0xb75fa4: ldur            x5, [fp, #-0x40]
    // 0xb75fa8: b               #0xb75f54
    // 0xb75fac: ldur            x2, [fp, #-0x10]
    // 0xb75fb0: ldur            x0, [fp, #-0x30]
    // 0xb75fb4: LoadField: r3 = r0->field_b
    //     0xb75fb4: ldur            w3, [x0, #0xb]
    // 0xb75fb8: DecompressPointer r3
    //     0xb75fb8: add             x3, x3, HEAP, lsl #32
    // 0xb75fbc: stur            x3, [fp, #-8]
    // 0xb75fc0: LoadField: r0 = r2->field_7
    //     0xb75fc0: ldur            w0, [x2, #7]
    // 0xb75fc4: DecompressPointer r0
    //     0xb75fc4: add             x0, x0, HEAP, lsl #32
    // 0xb75fc8: cmp             w0, NULL
    // 0xb75fcc: b.eq            #0xb7607c
    // 0xb75fd0: LoadField: r1 = r0->field_7
    //     0xb75fd0: ldur            x1, [x0, #7]
    // 0xb75fd4: ldr             x0, [x1]
    // 0xb75fd8: cbz             x0, #0xb76058
    // 0xb75fdc: ldur            x4, [fp, #-0x20]
    // 0xb75fe0: stur            x0, [fp, #-0x38]
    // 0xb75fe4: r1 = <Never>
    //     0xb75fe4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb75fe8: r0 = Pointer()
    //     0xb75fe8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb75fec: mov             x2, x0
    // 0xb75ff0: ldur            x0, [fp, #-0x38]
    // 0xb75ff4: stur            x2, [fp, #-0x18]
    // 0xb75ff8: StoreField: r2->field_7 = r0
    //     0xb75ff8: stur            x0, [x2, #7]
    // 0xb75ffc: ldur            x0, [fp, #-0x20]
    // 0xb76000: LoadField: r1 = r0->field_7
    //     0xb76000: ldur            w1, [x0, #7]
    // 0xb76004: DecompressPointer r1
    //     0xb76004: add             x1, x1, HEAP, lsl #32
    // 0xb76008: cmp             w1, NULL
    // 0xb7600c: b.eq            #0xb76080
    // 0xb76010: LoadField: r3 = r1->field_7
    //     0xb76010: ldur            x3, [x1, #7]
    // 0xb76014: ldr             x1, [x3]
    // 0xb76018: mov             x3, x1
    // 0xb7601c: stur            x3, [fp, #-0x38]
    // 0xb76020: r1 = <Never>
    //     0xb76020: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb76024: r0 = Pointer()
    //     0xb76024: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb76028: mov             x1, x0
    // 0xb7602c: ldur            x0, [fp, #-0x38]
    // 0xb76030: StoreField: r1->field_7 = r0
    //     0xb76030: stur            x0, [x1, #7]
    // 0xb76034: mov             x2, x1
    // 0xb76038: ldur            x1, [fp, #-0x18]
    // 0xb7603c: ldur            x3, [fp, #-8]
    // 0xb76040: ldur            x5, [fp, #-0x28]
    // 0xb76044: r0 = __drawPath$Method$FfiNative()
    //     0xb76044: bl              #0xb69a00  ; [dart:ui] _NativeCanvas::__drawPath$Method$FfiNative
    // 0xb76048: r0 = Null
    //     0xb76048: mov             x0, NULL
    // 0xb7604c: LeaveFrame
    //     0xb7604c: mov             SP, fp
    //     0xb76050: ldp             fp, lr, [SP], #0x10
    // 0xb76054: ret
    //     0xb76054: ret             
    // 0xb76058: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb76058: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb7605c: str             x16, [SP]
    // 0xb76060: r0 = _throwNew()
    //     0xb76060: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb76064: brk             #0
    // 0xb76068: r0 = StackOverflowSharedWithFPURegs()
    //     0xb76068: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb7606c: b               #0xb75e94
    // 0xb76070: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb76070: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb76074: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb76074: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb76078: b               #0xb75f60
    // 0xb7607c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb7607c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb76080: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb76080: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 4340, size: 0x28, field offset: 0xc
class _AnimatedIconPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0xb75b78, size: 0x258
    // 0xb75b78: EnterFrame
    //     0xb75b78: stp             fp, lr, [SP, #-0x10]!
    //     0xb75b7c: mov             fp, SP
    // 0xb75b80: AllocStack(0x38)
    //     0xb75b80: sub             SP, SP, #0x38
    // 0xb75b84: SetupParameters(_AnimatedIconPainter this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0xb75b84: mov             x0, x1
    //     0xb75b88: stur            x1, [fp, #-0x10]
    //     0xb75b8c: stur            x2, [fp, #-0x18]
    //     0xb75b90: stur            x3, [fp, #-0x20]
    // 0xb75b94: CheckStackOverflow
    //     0xb75b94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb75b98: cmp             SP, x16
    //     0xb75b9c: b.ls            #0xb75dac
    // 0xb75ba0: LoadField: r1 = r0->field_1f
    //     0xb75ba0: ldur            w1, [x0, #0x1f]
    // 0xb75ba4: DecompressPointer r1
    //     0xb75ba4: add             x1, x1, HEAP, lsl #32
    // 0xb75ba8: tbnz            w1, #4, #0xb75c50
    // 0xb75bac: LoadField: r1 = r2->field_7
    //     0xb75bac: ldur            w1, [x2, #7]
    // 0xb75bb0: DecompressPointer r1
    //     0xb75bb0: add             x1, x1, HEAP, lsl #32
    // 0xb75bb4: cmp             w1, NULL
    // 0xb75bb8: b.eq            #0xb75db4
    // 0xb75bbc: LoadField: r4 = r1->field_7
    //     0xb75bbc: ldur            x4, [x1, #7]
    // 0xb75bc0: ldr             x1, [x4]
    // 0xb75bc4: cbz             x1, #0xb75d7c
    // 0xb75bc8: mov             x4, x1
    // 0xb75bcc: stur            x4, [fp, #-8]
    // 0xb75bd0: r1 = <Never>
    //     0xb75bd0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb75bd4: r0 = Pointer()
    //     0xb75bd4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb75bd8: mov             x1, x0
    // 0xb75bdc: ldur            x0, [fp, #-8]
    // 0xb75be0: StoreField: r1->field_7 = r0
    //     0xb75be0: stur            x0, [x1, #7]
    // 0xb75be4: d0 = 3.141593
    //     0xb75be4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13178] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0xb75be8: ldr             d0, [x17, #0x178]
    // 0xb75bec: r0 = _rotate$Method$FfiNative()
    //     0xb75bec: bl              #0xb7499c  ; [dart:ui] _NativeCanvas::_rotate$Method$FfiNative
    // 0xb75bf0: ldur            x0, [fp, #-0x20]
    // 0xb75bf4: LoadField: d0 = r0->field_7
    //     0xb75bf4: ldur            d0, [x0, #7]
    // 0xb75bf8: fneg            d1, d0
    // 0xb75bfc: stur            d1, [fp, #-0x30]
    // 0xb75c00: LoadField: d0 = r0->field_f
    //     0xb75c00: ldur            d0, [x0, #0xf]
    // 0xb75c04: fneg            d2, d0
    // 0xb75c08: ldur            x2, [fp, #-0x18]
    // 0xb75c0c: stur            d2, [fp, #-0x28]
    // 0xb75c10: LoadField: r0 = r2->field_7
    //     0xb75c10: ldur            w0, [x2, #7]
    // 0xb75c14: DecompressPointer r0
    //     0xb75c14: add             x0, x0, HEAP, lsl #32
    // 0xb75c18: cmp             w0, NULL
    // 0xb75c1c: b.eq            #0xb75db8
    // 0xb75c20: LoadField: r1 = r0->field_7
    //     0xb75c20: ldur            x1, [x0, #7]
    // 0xb75c24: ldr             x0, [x1]
    // 0xb75c28: cbz             x0, #0xb75d8c
    // 0xb75c2c: stur            x0, [fp, #-8]
    // 0xb75c30: r1 = <Never>
    //     0xb75c30: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb75c34: r0 = Pointer()
    //     0xb75c34: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb75c38: mov             x1, x0
    // 0xb75c3c: ldur            x0, [fp, #-8]
    // 0xb75c40: StoreField: r1->field_7 = r0
    //     0xb75c40: stur            x0, [x1, #7]
    // 0xb75c44: ldur            d0, [fp, #-0x30]
    // 0xb75c48: ldur            d1, [fp, #-0x28]
    // 0xb75c4c: r0 = _translate$Method$FfiNative()
    //     0xb75c4c: bl              #0xb74a38  ; [dart:ui] _NativeCanvas::_translate$Method$FfiNative
    // 0xb75c50: ldur            x0, [fp, #-0x10]
    // 0xb75c54: ldur            x2, [fp, #-0x18]
    // 0xb75c58: ArrayLoad: d1 = r0[0]  ; List_8
    //     0xb75c58: ldur            d1, [x0, #0x17]
    // 0xb75c5c: stur            d1, [fp, #-0x28]
    // 0xb75c60: LoadField: r1 = r2->field_7
    //     0xb75c60: ldur            w1, [x2, #7]
    // 0xb75c64: DecompressPointer r1
    //     0xb75c64: add             x1, x1, HEAP, lsl #32
    // 0xb75c68: cmp             w1, NULL
    // 0xb75c6c: b.eq            #0xb75dbc
    // 0xb75c70: LoadField: r3 = r1->field_7
    //     0xb75c70: ldur            x3, [x1, #7]
    // 0xb75c74: ldr             x1, [x3]
    // 0xb75c78: cbz             x1, #0xb75d9c
    // 0xb75c7c: mov             x3, x1
    // 0xb75c80: stur            x3, [fp, #-8]
    // 0xb75c84: r1 = <Never>
    //     0xb75c84: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb75c88: r0 = Pointer()
    //     0xb75c88: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb75c8c: mov             x1, x0
    // 0xb75c90: ldur            x0, [fp, #-8]
    // 0xb75c94: StoreField: r1->field_7 = r0
    //     0xb75c94: stur            x0, [x1, #7]
    // 0xb75c98: ldur            d0, [fp, #-0x28]
    // 0xb75c9c: ldur            d1, [fp, #-0x28]
    // 0xb75ca0: r0 = __scale$Method$FfiNative()
    //     0xb75ca0: bl              #0xb76308  ; [dart:ui] _NativeCanvas::__scale$Method$FfiNative
    // 0xb75ca4: ldur            x0, [fp, #-0x10]
    // 0xb75ca8: LoadField: r1 = r0->field_f
    //     0xb75ca8: ldur            w1, [x0, #0xf]
    // 0xb75cac: DecompressPointer r1
    //     0xb75cac: add             x1, x1, HEAP, lsl #32
    // 0xb75cb0: LoadField: r2 = r1->field_37
    //     0xb75cb0: ldur            w2, [x1, #0x37]
    // 0xb75cb4: DecompressPointer r2
    //     0xb75cb4: add             x2, x2, HEAP, lsl #32
    // 0xb75cb8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb75cbc: cmp             w2, w16
    // 0xb75cc0: b.eq            #0xb75dc0
    // 0xb75cc4: LoadField: d0 = r2->field_7
    //     0xb75cc4: ldur            d0, [x2, #7]
    // 0xb75cc8: d1 = 0.000000
    //     0xb75cc8: eor             v1.16b, v1.16b, v1.16b
    // 0xb75ccc: fcmp            d1, d0
    // 0xb75cd0: b.le            #0xb75cdc
    // 0xb75cd4: d1 = 0.000000
    //     0xb75cd4: eor             v1.16b, v1.16b, v1.16b
    // 0xb75cd8: b               #0xb75d04
    // 0xb75cdc: d1 = 1.000000
    //     0xb75cdc: fmov            d1, #1.00000000
    // 0xb75ce0: fcmp            d0, d1
    // 0xb75ce4: b.le            #0xb75cf0
    // 0xb75ce8: d1 = 1.000000
    //     0xb75ce8: fmov            d1, #1.00000000
    // 0xb75cec: b               #0xb75d04
    // 0xb75cf0: fcmp            d0, d0
    // 0xb75cf4: b.vc            #0xb75d00
    // 0xb75cf8: d1 = 1.000000
    //     0xb75cf8: fmov            d1, #1.00000000
    // 0xb75cfc: b               #0xb75d04
    // 0xb75d00: mov             v1.16b, v0.16b
    // 0xb75d04: stur            d1, [fp, #-0x28]
    // 0xb75d08: LoadField: r4 = r0->field_13
    //     0xb75d08: ldur            w4, [x0, #0x13]
    // 0xb75d0c: DecompressPointer r4
    //     0xb75d0c: add             x4, x4, HEAP, lsl #32
    // 0xb75d10: stur            x4, [fp, #-0x20]
    // 0xb75d14: r1 = 0
    //     0xb75d14: mov             x1, #0
    // 0xb75d18: r0 = const [Instance of '_PathFrames', Instance of '_PathFrames', Instance of '_PathFrames']
    //     0xb75d18: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4d78] List<_PathFrames>(3)
    //     0xb75d1c: ldr             x0, [x0, #0xd78]
    // 0xb75d20: CheckStackOverflow
    //     0xb75d20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb75d24: cmp             SP, x16
    //     0xb75d28: b.ls            #0xb75dc8
    // 0xb75d2c: cmp             x1, #3
    // 0xb75d30: b.ge            #0xb75d6c
    // 0xb75d34: ArrayLoad: r2 = r0[r1]  ; Unknown_4
    //     0xb75d34: add             x16, x0, x1, lsl #2
    //     0xb75d38: ldur            w2, [x16, #0xf]
    // 0xb75d3c: DecompressPointer r2
    //     0xb75d3c: add             x2, x2, HEAP, lsl #32
    // 0xb75d40: add             x5, x1, #1
    // 0xb75d44: mov             x1, x2
    // 0xb75d48: ldur            x2, [fp, #-0x18]
    // 0xb75d4c: mov             x3, x4
    // 0xb75d50: mov             v0.16b, v1.16b
    // 0xb75d54: stur            x5, [fp, #-8]
    // 0xb75d58: r0 = paint()
    //     0xb75d58: bl              #0xb75e64  ; [package:flutter/src/material/animated_icons.dart] _PathFrames::paint
    // 0xb75d5c: ldur            x1, [fp, #-8]
    // 0xb75d60: ldur            x4, [fp, #-0x20]
    // 0xb75d64: ldur            d1, [fp, #-0x28]
    // 0xb75d68: b               #0xb75d18
    // 0xb75d6c: r0 = Null
    //     0xb75d6c: mov             x0, NULL
    // 0xb75d70: LeaveFrame
    //     0xb75d70: mov             SP, fp
    //     0xb75d74: ldp             fp, lr, [SP], #0x10
    // 0xb75d78: ret
    //     0xb75d78: ret             
    // 0xb75d7c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb75d7c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb75d80: str             x16, [SP]
    // 0xb75d84: r0 = _throwNew()
    //     0xb75d84: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb75d88: brk             #0
    // 0xb75d8c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb75d8c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb75d90: str             x16, [SP]
    // 0xb75d94: r0 = _throwNew()
    //     0xb75d94: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb75d98: brk             #0
    // 0xb75d9c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb75d9c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb75da0: str             x16, [SP]
    // 0xb75da4: r0 = _throwNew()
    //     0xb75da4: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb75da8: brk             #0
    // 0xb75dac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb75dac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb75db0: b               #0xb75ba0
    // 0xb75db4: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb75db4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb75db8: r0 = NullErrorSharedWithFPURegs()
    //     0xb75db8: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb75dbc: r0 = NullErrorSharedWithFPURegs()
    //     0xb75dbc: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb75dc0: r9 = _value
    //     0xb75dc0: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xb75dc4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb75dc4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xb75dc8: r0 = StackOverflowSharedWithFPURegs()
    //     0xb75dc8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb75dcc: b               #0xb75d2c
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xb931d8, size: 0x134
    // 0xb931d8: EnterFrame
    //     0xb931d8: stp             fp, lr, [SP, #-0x10]!
    //     0xb931dc: mov             fp, SP
    // 0xb931e0: AllocStack(0x20)
    //     0xb931e0: sub             SP, SP, #0x20
    // 0xb931e4: SetupParameters(_AnimatedIconPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xb931e4: mov             x4, x1
    //     0xb931e8: mov             x3, x2
    //     0xb931ec: stur            x1, [fp, #-8]
    //     0xb931f0: stur            x2, [fp, #-0x10]
    // 0xb931f4: CheckStackOverflow
    //     0xb931f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb931f8: cmp             SP, x16
    //     0xb931fc: b.ls            #0xb932f4
    // 0xb93200: mov             x0, x3
    // 0xb93204: r2 = Null
    //     0xb93204: mov             x2, NULL
    // 0xb93208: r1 = Null
    //     0xb93208: mov             x1, NULL
    // 0xb9320c: r4 = 60
    //     0xb9320c: mov             x4, #0x3c
    // 0xb93210: branchIfSmi(r0, 0xb9321c)
    //     0xb93210: tbz             w0, #0, #0xb9321c
    // 0xb93214: r4 = LoadClassIdInstr(r0)
    //     0xb93214: ldur            x4, [x0, #-1]
    //     0xb93218: ubfx            x4, x4, #0xc, #0x14
    // 0xb9321c: r17 = 4340
    //     0xb9321c: mov             x17, #0x10f4
    // 0xb93220: cmp             x4, x17
    // 0xb93224: b.eq            #0xb9323c
    // 0xb93228: r8 = _AnimatedIconPainter
    //     0xb93228: add             x8, PP, #0xd4, lsl #12  ; [pp+0xd4ec0] Type: _AnimatedIconPainter
    //     0xb9322c: ldr             x8, [x8, #0xec0]
    // 0xb93230: r3 = Null
    //     0xb93230: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4ec8] Null
    //     0xb93234: ldr             x3, [x3, #0xec8]
    // 0xb93238: r0 = DefaultTypeTest()
    //     0xb93238: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb9323c: ldur            x0, [fp, #-0x10]
    // 0xb93240: LoadField: r1 = r0->field_f
    //     0xb93240: ldur            w1, [x0, #0xf]
    // 0xb93244: DecompressPointer r1
    //     0xb93244: add             x1, x1, HEAP, lsl #32
    // 0xb93248: LoadField: r2 = r1->field_37
    //     0xb93248: ldur            w2, [x1, #0x37]
    // 0xb9324c: DecompressPointer r2
    //     0xb9324c: add             x2, x2, HEAP, lsl #32
    // 0xb93250: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb93254: cmp             w2, w16
    // 0xb93258: b.eq            #0xb932fc
    // 0xb9325c: ldur            x1, [fp, #-8]
    // 0xb93260: LoadField: r3 = r1->field_f
    //     0xb93260: ldur            w3, [x1, #0xf]
    // 0xb93264: DecompressPointer r3
    //     0xb93264: add             x3, x3, HEAP, lsl #32
    // 0xb93268: LoadField: r4 = r3->field_37
    //     0xb93268: ldur            w4, [x3, #0x37]
    // 0xb9326c: DecompressPointer r4
    //     0xb9326c: add             x4, x4, HEAP, lsl #32
    // 0xb93270: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb93274: cmp             w4, w16
    // 0xb93278: b.eq            #0xb93304
    // 0xb9327c: LoadField: d0 = r2->field_7
    //     0xb9327c: ldur            d0, [x2, #7]
    // 0xb93280: LoadField: d1 = r4->field_7
    //     0xb93280: ldur            d1, [x4, #7]
    // 0xb93284: fcmp            d0, d1
    // 0xb93288: b.ne            #0xb932c0
    // 0xb9328c: LoadField: r2 = r0->field_13
    //     0xb9328c: ldur            w2, [x0, #0x13]
    // 0xb93290: DecompressPointer r2
    //     0xb93290: add             x2, x2, HEAP, lsl #32
    // 0xb93294: LoadField: r3 = r1->field_13
    //     0xb93294: ldur            w3, [x1, #0x13]
    // 0xb93298: DecompressPointer r3
    //     0xb93298: add             x3, x3, HEAP, lsl #32
    // 0xb9329c: stp             x3, x2, [SP]
    // 0xb932a0: r0 = ==()
    //     0xb932a0: bl              #0x128cb50  ; [dart:ui] Color::==
    // 0xb932a4: tbnz            w0, #4, #0xb932c0
    // 0xb932a8: ldur            x1, [fp, #-8]
    // 0xb932ac: ldur            x0, [fp, #-0x10]
    // 0xb932b0: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xb932b0: ldur            d0, [x0, #0x17]
    // 0xb932b4: ArrayLoad: d1 = r1[0]  ; List_8
    //     0xb932b4: ldur            d1, [x1, #0x17]
    // 0xb932b8: fcmp            d0, d1
    // 0xb932bc: b.eq            #0xb932c8
    // 0xb932c0: r0 = true
    //     0xb932c0: add             x0, NULL, #0x20  ; true
    // 0xb932c4: b               #0xb932e8
    // 0xb932c8: r16 = Closure: () => Path from Function '_pathFactory@716273627': static.
    //     0xb932c8: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd4d80] Closure: () => Path from Function '_pathFactory@716273627': static. (0x7f2adaa5d084)
    //     0xb932cc: ldr             x16, [x16, #0xd80]
    // 0xb932d0: r30 = Closure: () => Path from Function '_pathFactory@716273627': static.
    //     0xb932d0: add             lr, PP, #0xd4, lsl #12  ; [pp+0xd4d80] Closure: () => Path from Function '_pathFactory@716273627': static. (0x7f2adaa5d084)
    //     0xb932d4: ldr             lr, [lr, #0xd80]
    // 0xb932d8: stp             lr, x16, [SP]
    // 0xb932dc: r0 = ==()
    //     0xb932dc: bl              #0x12b7e74  ; [dart:core] _Closure::==
    // 0xb932e0: eor             x1, x0, #0x10
    // 0xb932e4: mov             x0, x1
    // 0xb932e8: LeaveFrame
    //     0xb932e8: mov             SP, fp
    //     0xb932ec: ldp             fp, lr, [SP], #0x10
    // 0xb932f0: ret
    //     0xb932f0: ret             
    // 0xb932f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb932f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb932f8: b               #0xb93200
    // 0xb932fc: r9 = _value
    //     0xb932fc: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xb93300: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb93300: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xb93304: r9 = _value
    //     0xb93304: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xb93308: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb93308: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 6186, size: 0x24, field offset: 0xc
//   const constructor, 
class AnimatedIcon extends StatelessWidget {

  [closure] static Path _pathFactory(dynamic) {
    // ** addr: 0xb76084, size: 0x2c
    // 0xb76084: EnterFrame
    //     0xb76084: stp             fp, lr, [SP, #-0x10]!
    //     0xb76088: mov             fp, SP
    // 0xb7608c: CheckStackOverflow
    //     0xb7608c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb76090: cmp             SP, x16
    //     0xb76094: b.ls            #0xb760a8
    // 0xb76098: r0 = _pathFactory()
    //     0xb76098: bl              #0xb760b0  ; [package:flutter/src/material/animated_icons.dart] AnimatedIcon::_pathFactory
    // 0xb7609c: LeaveFrame
    //     0xb7609c: mov             SP, fp
    //     0xb760a0: ldp             fp, lr, [SP], #0x10
    // 0xb760a4: ret
    //     0xb760a4: ret             
    // 0xb760a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb760a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb760ac: b               #0xb76098
  }
  static _ _pathFactory(/* No info */) {
    // ** addr: 0xb760b0, size: 0x40
    // 0xb760b0: EnterFrame
    //     0xb760b0: stp             fp, lr, [SP, #-0x10]!
    //     0xb760b4: mov             fp, SP
    // 0xb760b8: AllocStack(0x8)
    //     0xb760b8: sub             SP, SP, #8
    // 0xb760bc: CheckStackOverflow
    //     0xb760bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb760c0: cmp             SP, x16
    //     0xb760c4: b.ls            #0xb760e8
    // 0xb760c8: r0 = _NativePath()
    //     0xb760c8: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xb760cc: mov             x1, x0
    // 0xb760d0: stur            x0, [fp, #-8]
    // 0xb760d4: r0 = __constructor$Method$FfiNative()
    //     0xb760d4: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xb760d8: ldur            x0, [fp, #-8]
    // 0xb760dc: LeaveFrame
    //     0xb760dc: mov             SP, fp
    //     0xb760e0: ldp             fp, lr, [SP], #0x10
    // 0xb760e4: ret
    //     0xb760e4: ret             
    // 0xb760e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb760e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb760ec: b               #0xb760c8
  }
  _ build(/* No info */) {
    // ** addr: 0xfaf79c, size: 0x1c8
    // 0xfaf79c: EnterFrame
    //     0xfaf79c: stp             fp, lr, [SP, #-0x10]!
    //     0xfaf7a0: mov             fp, SP
    // 0xfaf7a4: AllocStack(0x40)
    //     0xfaf7a4: sub             SP, SP, #0x40
    // 0xfaf7a8: SetupParameters(AnimatedIcon this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfaf7a8: mov             x0, x2
    //     0xfaf7ac: stur            x2, [fp, #-0x10]
    //     0xfaf7b0: mov             x2, x1
    //     0xfaf7b4: stur            x1, [fp, #-8]
    // 0xfaf7b8: CheckStackOverflow
    //     0xfaf7b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaf7bc: cmp             SP, x16
    //     0xfaf7c0: b.ls            #0xfaf954
    // 0xfaf7c4: mov             x1, x0
    // 0xfaf7c8: r0 = of()
    //     0xfaf7c8: bl              #0xd0e004  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::of
    // 0xfaf7cc: mov             x2, x0
    // 0xfaf7d0: ldur            x0, [fp, #-8]
    // 0xfaf7d4: stur            x2, [fp, #-0x18]
    // 0xfaf7d8: LoadField: r1 = r0->field_13
    //     0xfaf7d8: ldur            w1, [x0, #0x13]
    // 0xfaf7dc: DecompressPointer r1
    //     0xfaf7dc: add             x1, x1, HEAP, lsl #32
    // 0xfaf7e0: cmp             w1, NULL
    // 0xfaf7e4: b.ne            #0xfaf800
    // 0xfaf7e8: LoadField: r1 = r2->field_7
    //     0xfaf7e8: ldur            w1, [x2, #7]
    // 0xfaf7ec: DecompressPointer r1
    //     0xfaf7ec: add             x1, x1, HEAP, lsl #32
    // 0xfaf7f0: cmp             w1, NULL
    // 0xfaf7f4: b.eq            #0xfaf95c
    // 0xfaf7f8: LoadField: d0 = r1->field_7
    //     0xfaf7f8: ldur            d0, [x1, #7]
    // 0xfaf7fc: b               #0xfaf804
    // 0xfaf800: LoadField: d0 = r1->field_7
    //     0xfaf800: ldur            d0, [x1, #7]
    // 0xfaf804: ldur            x1, [fp, #-0x10]
    // 0xfaf808: stur            d0, [fp, #-0x28]
    // 0xfaf80c: r0 = of()
    //     0xfaf80c: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xfaf810: ldur            x1, [fp, #-0x18]
    // 0xfaf814: r0 = opacity()
    //     0xfaf814: bl              #0xd0c778  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::opacity
    // 0xfaf818: cmp             w0, NULL
    // 0xfaf81c: b.eq            #0xfaf960
    // 0xfaf820: ldur            x2, [fp, #-8]
    // 0xfaf824: LoadField: r3 = r2->field_f
    //     0xfaf824: ldur            w3, [x2, #0xf]
    // 0xfaf828: DecompressPointer r3
    //     0xfaf828: add             x3, x3, HEAP, lsl #32
    // 0xfaf82c: stur            x3, [fp, #-0x10]
    // 0xfaf830: LoadField: d0 = r0->field_7
    //     0xfaf830: ldur            d0, [x0, #7]
    // 0xfaf834: stur            d0, [fp, #-0x30]
    // 0xfaf838: d1 = 1.000000
    //     0xfaf838: fmov            d1, #1.00000000
    // 0xfaf83c: fcmp            d0, d1
    // 0xfaf840: b.eq            #0xfaf86c
    // 0xfaf844: mov             x1, x3
    // 0xfaf848: r0 = opacity()
    //     0xfaf848: bl              #0x12d8430  ; [dart:ui] Color::opacity
    // 0xfaf84c: mov             v1.16b, v0.16b
    // 0xfaf850: ldur            d0, [fp, #-0x30]
    // 0xfaf854: fmul            d2, d1, d0
    // 0xfaf858: ldur            x1, [fp, #-0x10]
    // 0xfaf85c: mov             v0.16b, v2.16b
    // 0xfaf860: r0 = withOpacity()
    //     0xfaf860: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xfaf864: mov             x1, x0
    // 0xfaf868: b               #0xfaf870
    // 0xfaf86c: ldur            x1, [fp, #-0x10]
    // 0xfaf870: ldur            x0, [fp, #-8]
    // 0xfaf874: ldur            d0, [fp, #-0x28]
    // 0xfaf878: stur            x1, [fp, #-0x10]
    // 0xfaf87c: r0 = Size()
    //     0xfaf87c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xfaf880: ldur            d0, [fp, #-0x28]
    // 0xfaf884: stur            x0, [fp, #-0x20]
    // 0xfaf888: StoreField: r0->field_7 = d0
    //     0xfaf888: stur            d0, [x0, #7]
    // 0xfaf88c: StoreField: r0->field_f = d0
    //     0xfaf88c: stur            d0, [x0, #0xf]
    // 0xfaf890: ldur            x1, [fp, #-8]
    // 0xfaf894: LoadField: r2 = r1->field_b
    //     0xfaf894: ldur            w2, [x1, #0xb]
    // 0xfaf898: DecompressPointer r2
    //     0xfaf898: add             x2, x2, HEAP, lsl #32
    // 0xfaf89c: stur            x2, [fp, #-0x18]
    // 0xfaf8a0: r1 = Instance_Size
    //     0xfaf8a0: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c588] Obj!Size@12a75d1
    //     0xfaf8a4: ldr             x1, [x1, #0x588]
    // 0xfaf8a8: LoadField: d1 = r1->field_7
    //     0xfaf8a8: ldur            d1, [x1, #7]
    // 0xfaf8ac: fdiv            d2, d0, d1
    // 0xfaf8b0: stur            d2, [fp, #-0x30]
    // 0xfaf8b4: r0 = _AnimatedIconPainter()
    //     0xfaf8b4: bl              #0xfaf964  ; Allocate_AnimatedIconPainterStub -> _AnimatedIconPainter (size=0x28)
    // 0xfaf8b8: mov             x1, x0
    // 0xfaf8bc: r0 = const [Instance of '_PathFrames', Instance of '_PathFrames', Instance of '_PathFrames']
    //     0xfaf8bc: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4d78] List<_PathFrames>(3)
    //     0xfaf8c0: ldr             x0, [x0, #0xd78]
    // 0xfaf8c4: stur            x1, [fp, #-8]
    // 0xfaf8c8: StoreField: r1->field_b = r0
    //     0xfaf8c8: stur            w0, [x1, #0xb]
    // 0xfaf8cc: ldur            x0, [fp, #-0x18]
    // 0xfaf8d0: StoreField: r1->field_f = r0
    //     0xfaf8d0: stur            w0, [x1, #0xf]
    // 0xfaf8d4: ldur            x2, [fp, #-0x10]
    // 0xfaf8d8: StoreField: r1->field_13 = r2
    //     0xfaf8d8: stur            w2, [x1, #0x13]
    // 0xfaf8dc: ldur            d0, [fp, #-0x30]
    // 0xfaf8e0: ArrayStore: r1[0] = d0  ; List_8
    //     0xfaf8e0: stur            d0, [x1, #0x17]
    // 0xfaf8e4: r2 = false
    //     0xfaf8e4: add             x2, NULL, #0x30  ; false
    // 0xfaf8e8: StoreField: r1->field_1f = r2
    //     0xfaf8e8: stur            w2, [x1, #0x1f]
    // 0xfaf8ec: r3 = Closure: () => Path from Function '_pathFactory@716273627': static.
    //     0xfaf8ec: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4d80] Closure: () => Path from Function '_pathFactory@716273627': static. (0x7f2adaa5d084)
    //     0xfaf8f0: ldr             x3, [x3, #0xd80]
    // 0xfaf8f4: StoreField: r1->field_23 = r3
    //     0xfaf8f4: stur            w3, [x1, #0x23]
    // 0xfaf8f8: StoreField: r1->field_7 = r0
    //     0xfaf8f8: stur            w0, [x1, #7]
    // 0xfaf8fc: r0 = CustomPaint()
    //     0xfaf8fc: bl              #0xd0a594  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0xfaf900: mov             x1, x0
    // 0xfaf904: ldur            x0, [fp, #-8]
    // 0xfaf908: stur            x1, [fp, #-0x10]
    // 0xfaf90c: StoreField: r1->field_f = r0
    //     0xfaf90c: stur            w0, [x1, #0xf]
    // 0xfaf910: ldur            x0, [fp, #-0x20]
    // 0xfaf914: ArrayStore: r1[0] = r0  ; List_4
    //     0xfaf914: stur            w0, [x1, #0x17]
    // 0xfaf918: r0 = false
    //     0xfaf918: add             x0, NULL, #0x30  ; false
    // 0xfaf91c: StoreField: r1->field_1b = r0
    //     0xfaf91c: stur            w0, [x1, #0x1b]
    // 0xfaf920: StoreField: r1->field_1f = r0
    //     0xfaf920: stur            w0, [x1, #0x1f]
    // 0xfaf924: r0 = Semantics()
    //     0xfaf924: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xfaf928: stur            x0, [fp, #-8]
    // 0xfaf92c: ldur            x16, [fp, #-0x10]
    // 0xfaf930: stp             x16, NULL, [SP]
    // 0xfaf934: mov             x1, x0
    // 0xfaf938: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, label, 0x1, null]
    //     0xfaf938: add             x4, PP, #0x80, lsl #12  ; [pp+0x80e10] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "label", 0x1, Null]
    //     0xfaf93c: ldr             x4, [x4, #0xe10]
    // 0xfaf940: r0 = Semantics()
    //     0xfaf940: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xfaf944: ldur            x0, [fp, #-8]
    // 0xfaf948: LeaveFrame
    //     0xfaf948: mov             SP, fp
    //     0xfaf94c: ldp             fp, lr, [SP], #0x10
    // 0xfaf950: ret
    //     0xfaf950: ret             
    // 0xfaf954: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaf954: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaf958: b               #0xfaf7c4
    // 0xfaf95c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfaf95c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xfaf960: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfaf960: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}
