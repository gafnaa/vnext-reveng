// lib: , url: package:flutter/src/material/bottom_app_bar_theme.dart

// class id: 1048850, size: 0x8
class :: {
}

// class id: 5204, size: 0x24, field offset: 0x8
//   const constructor, 
class BottomAppBarThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x112ed14, size: 0x21c
    // 0x112ed14: EnterFrame
    //     0x112ed14: stp             fp, lr, [SP, #-0x10]!
    //     0x112ed18: mov             fp, SP
    // 0x112ed1c: AllocStack(0x50)
    //     0x112ed1c: sub             SP, SP, #0x50
    // 0x112ed20: CheckStackOverflow
    //     0x112ed20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112ed24: cmp             SP, x16
    //     0x112ed28: b.ls            #0x112ef24
    // 0x112ed2c: ldr             x0, [fp, #0x10]
    // 0x112ed30: r2 = LoadClassIdInstr(r0)
    //     0x112ed30: ldur            x2, [x0, #-1]
    //     0x112ed34: ubfx            x2, x2, #0xc, #0x14
    // 0x112ed38: stur            x2, [fp, #-8]
    // 0x112ed3c: r17 = 5204
    //     0x112ed3c: mov             x17, #0x1454
    // 0x112ed40: cmp             x2, x17
    // 0x112ed44: b.ne            #0x112ed58
    // 0x112ed48: LoadField: r1 = r0->field_7
    //     0x112ed48: ldur            w1, [x0, #7]
    // 0x112ed4c: DecompressPointer r1
    //     0x112ed4c: add             x1, x1, HEAP, lsl #32
    // 0x112ed50: mov             x3, x1
    // 0x112ed54: b               #0x112ee04
    // 0x112ed58: r17 = 5205
    //     0x112ed58: mov             x17, #0x1455
    // 0x112ed5c: cmp             x2, x17
    // 0x112ed60: b.ne            #0x112edbc
    // 0x112ed64: mov             x1, x0
    // 0x112ed68: LoadField: r0 = r1->field_27
    //     0x112ed68: ldur            w0, [x1, #0x27]
    // 0x112ed6c: DecompressPointer r0
    //     0x112ed6c: add             x0, x0, HEAP, lsl #32
    // 0x112ed70: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x112ed74: cmp             w0, w16
    // 0x112ed78: b.ne            #0x112ed88
    // 0x112ed7c: r2 = _colors
    //     0x112ed7c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26570] Field <_BottomAppBarDefaultsM3@723408488._colors@723408488>: late final (offset: 0x28)
    //     0x112ed80: ldr             x2, [x2, #0x570]
    // 0x112ed84: r0 = InitLateFinalInstanceField()
    //     0x112ed84: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x112ed88: LoadField: r1 = r0->field_97
    //     0x112ed88: ldur            w1, [x0, #0x97]
    // 0x112ed8c: DecompressPointer r1
    //     0x112ed8c: add             x1, x1, HEAP, lsl #32
    // 0x112ed90: cmp             w1, NULL
    // 0x112ed94: b.ne            #0x112eda8
    // 0x112ed98: LoadField: r1 = r0->field_7b
    //     0x112ed98: ldur            w1, [x0, #0x7b]
    // 0x112ed9c: DecompressPointer r1
    //     0x112ed9c: add             x1, x1, HEAP, lsl #32
    // 0x112eda0: mov             x0, x1
    // 0x112eda4: b               #0x112edac
    // 0x112eda8: mov             x0, x1
    // 0x112edac: mov             x3, x0
    // 0x112edb0: ldr             x0, [fp, #0x10]
    // 0x112edb4: ldur            x2, [fp, #-8]
    // 0x112edb8: b               #0x112ee04
    // 0x112edbc: LoadField: r1 = r0->field_23
    //     0x112edbc: ldur            w1, [x0, #0x23]
    // 0x112edc0: DecompressPointer r1
    //     0x112edc0: add             x1, x1, HEAP, lsl #32
    // 0x112edc4: r0 = brightnessOf()
    //     0x112edc4: bl              #0xd1e4dc  ; [package:flutter/src/material/theme.dart] Theme::brightnessOf
    // 0x112edc8: r16 = Instance_Brightness
    //     0x112edc8: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x112edcc: cmp             w0, w16
    // 0x112edd0: b.ne            #0x112edf0
    // 0x112edd4: r1 = _ConstMap len:12
    //     0x112edd4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c20] Map<int, Color>(12)
    //     0x112edd8: ldr             x1, [x1, #0xc20]
    // 0x112eddc: r2 = 1600
    //     0x112eddc: mov             x2, #0x640
    // 0x112ede0: r0 = []()
    //     0x112ede0: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x112ede4: cmp             w0, NULL
    // 0x112ede8: b.eq            #0x112ef2c
    // 0x112edec: b               #0x112edf8
    // 0x112edf0: r0 = Instance_Color
    //     0x112edf0: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x112edf4: ldr             x0, [x0, #0xc38]
    // 0x112edf8: mov             x3, x0
    // 0x112edfc: ldr             x0, [fp, #0x10]
    // 0x112ee00: ldur            x2, [fp, #-8]
    // 0x112ee04: stur            x3, [fp, #-0x28]
    // 0x112ee08: LoadField: r4 = r0->field_b
    //     0x112ee08: ldur            w4, [x0, #0xb]
    // 0x112ee0c: DecompressPointer r4
    //     0x112ee0c: add             x4, x4, HEAP, lsl #32
    // 0x112ee10: stur            x4, [fp, #-0x20]
    // 0x112ee14: LoadField: r5 = r0->field_f
    //     0x112ee14: ldur            w5, [x0, #0xf]
    // 0x112ee18: DecompressPointer r5
    //     0x112ee18: add             x5, x5, HEAP, lsl #32
    // 0x112ee1c: stur            x5, [fp, #-0x18]
    // 0x112ee20: LoadField: r6 = r0->field_13
    //     0x112ee20: ldur            w6, [x0, #0x13]
    // 0x112ee24: DecompressPointer r6
    //     0x112ee24: add             x6, x6, HEAP, lsl #32
    // 0x112ee28: stur            x6, [fp, #-0x10]
    // 0x112ee2c: r17 = 5204
    //     0x112ee2c: mov             x17, #0x1454
    // 0x112ee30: cmp             x2, x17
    // 0x112ee34: b.ne            #0x112ee48
    // 0x112ee38: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x112ee38: ldur            w1, [x0, #0x17]
    // 0x112ee3c: DecompressPointer r1
    //     0x112ee3c: add             x1, x1, HEAP, lsl #32
    // 0x112ee40: mov             x0, x2
    // 0x112ee44: b               #0x112ee98
    // 0x112ee48: r17 = 5205
    //     0x112ee48: mov             x17, #0x1455
    // 0x112ee4c: cmp             x2, x17
    // 0x112ee50: b.ne            #0x112ee64
    // 0x112ee54: mov             x0, x2
    // 0x112ee58: r1 = Instance_Color
    //     0x112ee58: add             x1, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x112ee5c: ldr             x1, [x1, #0x810]
    // 0x112ee60: b               #0x112ee98
    // 0x112ee64: LoadField: r1 = r0->field_23
    //     0x112ee64: ldur            w1, [x0, #0x23]
    // 0x112ee68: DecompressPointer r1
    //     0x112ee68: add             x1, x1, HEAP, lsl #32
    // 0x112ee6c: r0 = of()
    //     0x112ee6c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x112ee70: LoadField: r1 = r0->field_3f
    //     0x112ee70: ldur            w1, [x0, #0x3f]
    // 0x112ee74: DecompressPointer r1
    //     0x112ee74: add             x1, x1, HEAP, lsl #32
    // 0x112ee78: LoadField: r0 = r1->field_c3
    //     0x112ee78: ldur            w0, [x1, #0xc3]
    // 0x112ee7c: DecompressPointer r0
    //     0x112ee7c: add             x0, x0, HEAP, lsl #32
    // 0x112ee80: cmp             w0, NULL
    // 0x112ee84: b.ne            #0x112ee90
    // 0x112ee88: LoadField: r0 = r1->field_b
    //     0x112ee88: ldur            w0, [x1, #0xb]
    // 0x112ee8c: DecompressPointer r0
    //     0x112ee8c: add             x0, x0, HEAP, lsl #32
    // 0x112ee90: mov             x1, x0
    // 0x112ee94: ldur            x0, [fp, #-8]
    // 0x112ee98: r17 = 5204
    //     0x112ee98: mov             x17, #0x1454
    // 0x112ee9c: cmp             x0, x17
    // 0x112eea0: b.ne            #0x112eeb8
    // 0x112eea4: ldr             x0, [fp, #0x10]
    // 0x112eea8: LoadField: r2 = r0->field_1b
    //     0x112eea8: ldur            w2, [x0, #0x1b]
    // 0x112eeac: DecompressPointer r2
    //     0x112eeac: add             x2, x2, HEAP, lsl #32
    // 0x112eeb0: mov             x0, x2
    // 0x112eeb4: b               #0x112eed8
    // 0x112eeb8: r17 = 5205
    //     0x112eeb8: mov             x17, #0x1455
    // 0x112eebc: cmp             x0, x17
    // 0x112eec0: b.ne            #0x112eed0
    // 0x112eec4: r0 = Instance_Color
    //     0x112eec4: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x112eec8: ldr             x0, [x0, #0x810]
    // 0x112eecc: b               #0x112eed8
    // 0x112eed0: r0 = Instance_Color
    //     0x112eed0: add             x0, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x112eed4: ldr             x0, [x0, #0x948]
    // 0x112eed8: ldur            x16, [fp, #-0x18]
    // 0x112eedc: ldur            lr, [fp, #-0x10]
    // 0x112eee0: stp             lr, x16, [SP, #0x18]
    // 0x112eee4: stp             x0, x1, [SP, #8]
    // 0x112eee8: str             NULL, [SP]
    // 0x112eeec: ldur            x1, [fp, #-0x28]
    // 0x112eef0: ldur            x2, [fp, #-0x20]
    // 0x112eef4: r4 = const [0, 0x7, 0x5, 0x7, null]
    //     0x112eef4: add             x4, PP, #0xd, lsl #12  ; [pp+0xd8a0] List(5) [0, 0x7, 0x5, 0x7, Null]
    //     0x112eef8: ldr             x4, [x4, #0x8a0]
    // 0x112eefc: r0 = hash()
    //     0x112eefc: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x112ef00: mov             x2, x0
    // 0x112ef04: r0 = BoxInt64Instr(r2)
    //     0x112ef04: sbfiz           x0, x2, #1, #0x1f
    //     0x112ef08: cmp             x2, x0, asr #1
    //     0x112ef0c: b.eq            #0x112ef18
    //     0x112ef10: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x112ef14: stur            x2, [x0, #7]
    // 0x112ef18: LeaveFrame
    //     0x112ef18: mov             SP, fp
    //     0x112ef1c: ldp             fp, lr, [SP], #0x10
    // 0x112ef20: ret
    //     0x112ef20: ret             
    // 0x112ef24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112ef24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112ef28: b               #0x112ed2c
    // 0x112ef2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x112ef2c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1168a70, size: 0x188
    // 0x1168a70: EnterFrame
    //     0x1168a70: stp             fp, lr, [SP, #-0x10]!
    //     0x1168a74: mov             fp, SP
    // 0x1168a78: AllocStack(0x30)
    //     0x1168a78: sub             SP, SP, #0x30
    // 0x1168a7c: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x30 */)
    //     0x1168a7c: mov             x4, x1
    //     0x1168a80: mov             x0, x2
    //     0x1168a84: stur            x1, [fp, #-0x10]
    //     0x1168a88: stur            x2, [fp, #-0x18]
    //     0x1168a8c: stur            d0, [fp, #-0x30]
    // 0x1168a90: CheckStackOverflow
    //     0x1168a90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1168a94: cmp             SP, x16
    //     0x1168a98: b.ls            #0x1168bd4
    // 0x1168a9c: cmp             w4, w0
    // 0x1168aa0: b.ne            #0x1168ab4
    // 0x1168aa4: mov             x0, x4
    // 0x1168aa8: LeaveFrame
    //     0x1168aa8: mov             SP, fp
    //     0x1168aac: ldp             fp, lr, [SP], #0x10
    // 0x1168ab0: ret
    //     0x1168ab0: ret             
    // 0x1168ab4: r5 = inline_Allocate_Double()
    //     0x1168ab4: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x1168ab8: add             x5, x5, #0x10
    //     0x1168abc: cmp             x1, x5
    //     0x1168ac0: b.ls            #0x1168bdc
    //     0x1168ac4: str             x5, [THR, #0x60]  ; THR::top
    //     0x1168ac8: sub             x5, x5, #0xf
    //     0x1168acc: mov             x1, #0xe19c
    //     0x1168ad0: movk            x1, #3, lsl #16
    //     0x1168ad4: stur            x1, [x5, #-1]
    // 0x1168ad8: dmb             ishst
    // 0x1168adc: StoreField: r5->field_7 = d0
    //     0x1168adc: stur            d0, [x5, #7]
    // 0x1168ae0: mov             x3, x5
    // 0x1168ae4: stur            x5, [fp, #-8]
    // 0x1168ae8: r1 = Null
    //     0x1168ae8: mov             x1, NULL
    // 0x1168aec: r2 = Null
    //     0x1168aec: mov             x2, NULL
    // 0x1168af0: r0 = lerp()
    //     0x1168af0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168af4: ldur            x0, [fp, #-0x10]
    // 0x1168af8: LoadField: r1 = r0->field_b
    //     0x1168af8: ldur            w1, [x0, #0xb]
    // 0x1168afc: DecompressPointer r1
    //     0x1168afc: add             x1, x1, HEAP, lsl #32
    // 0x1168b00: ldur            x4, [fp, #-0x18]
    // 0x1168b04: LoadField: r2 = r4->field_b
    //     0x1168b04: ldur            w2, [x4, #0xb]
    // 0x1168b08: DecompressPointer r2
    //     0x1168b08: add             x2, x2, HEAP, lsl #32
    // 0x1168b0c: ldur            x3, [fp, #-8]
    // 0x1168b10: r0 = lerpDouble()
    //     0x1168b10: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1168b14: ldur            d0, [fp, #-0x30]
    // 0x1168b18: d1 = 0.500000
    //     0x1168b18: fmov            d1, #0.50000000
    // 0x1168b1c: stur            x0, [fp, #-0x28]
    // 0x1168b20: fcmp            d1, d0
    // 0x1168b24: b.le            #0x1168b40
    // 0x1168b28: ldur            x1, [fp, #-0x10]
    // 0x1168b2c: LoadField: r2 = r1->field_f
    //     0x1168b2c: ldur            w2, [x1, #0xf]
    // 0x1168b30: DecompressPointer r2
    //     0x1168b30: add             x2, x2, HEAP, lsl #32
    // 0x1168b34: mov             x4, x2
    // 0x1168b38: ldur            x2, [fp, #-0x18]
    // 0x1168b3c: b               #0x1168b54
    // 0x1168b40: ldur            x1, [fp, #-0x10]
    // 0x1168b44: ldur            x2, [fp, #-0x18]
    // 0x1168b48: LoadField: r3 = r2->field_f
    //     0x1168b48: ldur            w3, [x2, #0xf]
    // 0x1168b4c: DecompressPointer r3
    //     0x1168b4c: add             x3, x3, HEAP, lsl #32
    // 0x1168b50: mov             x4, x3
    // 0x1168b54: stur            x4, [fp, #-0x20]
    // 0x1168b58: LoadField: r3 = r1->field_13
    //     0x1168b58: ldur            w3, [x1, #0x13]
    // 0x1168b5c: DecompressPointer r3
    //     0x1168b5c: add             x3, x3, HEAP, lsl #32
    // 0x1168b60: LoadField: r1 = r2->field_13
    //     0x1168b60: ldur            w1, [x2, #0x13]
    // 0x1168b64: DecompressPointer r1
    //     0x1168b64: add             x1, x1, HEAP, lsl #32
    // 0x1168b68: mov             x2, x1
    // 0x1168b6c: mov             x1, x3
    // 0x1168b70: ldur            x3, [fp, #-8]
    // 0x1168b74: r0 = lerpDouble()
    //     0x1168b74: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1168b78: ldur            x3, [fp, #-8]
    // 0x1168b7c: r1 = Null
    //     0x1168b7c: mov             x1, NULL
    // 0x1168b80: r2 = Null
    //     0x1168b80: mov             x2, NULL
    // 0x1168b84: stur            x0, [fp, #-0x10]
    // 0x1168b88: r0 = lerp()
    //     0x1168b88: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168b8c: ldur            x3, [fp, #-8]
    // 0x1168b90: r1 = Null
    //     0x1168b90: mov             x1, NULL
    // 0x1168b94: r2 = Null
    //     0x1168b94: mov             x2, NULL
    // 0x1168b98: r0 = lerp()
    //     0x1168b98: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168b9c: ldur            x3, [fp, #-8]
    // 0x1168ba0: r1 = Null
    //     0x1168ba0: mov             x1, NULL
    // 0x1168ba4: r2 = Null
    //     0x1168ba4: mov             x2, NULL
    // 0x1168ba8: r0 = lerp()
    //     0x1168ba8: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x1168bac: r0 = BottomAppBarThemeData()
    //     0x1168bac: bl              #0x1168bf8  ; AllocateBottomAppBarThemeDataStub -> BottomAppBarThemeData (size=0x24)
    // 0x1168bb0: ldur            x1, [fp, #-0x28]
    // 0x1168bb4: StoreField: r0->field_b = r1
    //     0x1168bb4: stur            w1, [x0, #0xb]
    // 0x1168bb8: ldur            x1, [fp, #-0x20]
    // 0x1168bbc: StoreField: r0->field_f = r1
    //     0x1168bbc: stur            w1, [x0, #0xf]
    // 0x1168bc0: ldur            x1, [fp, #-0x10]
    // 0x1168bc4: StoreField: r0->field_13 = r1
    //     0x1168bc4: stur            w1, [x0, #0x13]
    // 0x1168bc8: LeaveFrame
    //     0x1168bc8: mov             SP, fp
    //     0x1168bcc: ldp             fp, lr, [SP], #0x10
    // 0x1168bd0: ret
    //     0x1168bd0: ret             
    // 0x1168bd4: r0 = StackOverflowSharedWithFPURegs()
    //     0x1168bd4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1168bd8: b               #0x1168a9c
    // 0x1168bdc: SaveReg d0
    //     0x1168bdc: str             q0, [SP, #-0x10]!
    // 0x1168be0: stp             x0, x4, [SP, #-0x10]!
    // 0x1168be4: r0 = AllocateDouble()
    //     0x1168be4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1168be8: mov             x5, x0
    // 0x1168bec: ldp             x0, x4, [SP], #0x10
    // 0x1168bf0: RestoreReg d0
    //     0x1168bf0: ldr             q0, [SP], #0x10
    // 0x1168bf4: b               #0x1168adc
  }
  _ ==(/* No info */) {
    // ** addr: 0x1264174, size: 0x4a0
    // 0x1264174: EnterFrame
    //     0x1264174: stp             fp, lr, [SP, #-0x10]!
    //     0x1264178: mov             fp, SP
    // 0x126417c: AllocStack(0x28)
    //     0x126417c: sub             SP, SP, #0x28
    // 0x1264180: CheckStackOverflow
    //     0x1264180: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1264184: cmp             SP, x16
    //     0x1264188: b.ls            #0x1264604
    // 0x126418c: ldr             x1, [fp, #0x10]
    // 0x1264190: cmp             w1, NULL
    // 0x1264194: b.ne            #0x12641a8
    // 0x1264198: r0 = false
    //     0x1264198: add             x0, NULL, #0x30  ; false
    // 0x126419c: LeaveFrame
    //     0x126419c: mov             SP, fp
    //     0x12641a0: ldp             fp, lr, [SP], #0x10
    // 0x12641a4: ret
    //     0x12641a4: ret             
    // 0x12641a8: ldr             x0, [fp, #0x18]
    // 0x12641ac: cmp             w0, w1
    // 0x12641b0: b.ne            #0x12641c4
    // 0x12641b4: r0 = true
    //     0x12641b4: add             x0, NULL, #0x20  ; true
    // 0x12641b8: LeaveFrame
    //     0x12641b8: mov             SP, fp
    //     0x12641bc: ldp             fp, lr, [SP], #0x10
    // 0x12641c0: ret
    //     0x12641c0: ret             
    // 0x12641c4: stp             x0, x1, [SP]
    // 0x12641c8: r0 = _haveSameRuntimeType()
    //     0x12641c8: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x12641cc: tbz             w0, #4, #0x12641e0
    // 0x12641d0: r0 = false
    //     0x12641d0: add             x0, NULL, #0x30  ; false
    // 0x12641d4: LeaveFrame
    //     0x12641d4: mov             SP, fp
    //     0x12641d8: ldp             fp, lr, [SP], #0x10
    // 0x12641dc: ret
    //     0x12641dc: ret             
    // 0x12641e0: ldr             x0, [fp, #0x10]
    // 0x12641e4: r2 = 60
    //     0x12641e4: mov             x2, #0x3c
    // 0x12641e8: branchIfSmi(r0, 0x12641f4)
    //     0x12641e8: tbz             w0, #0, #0x12641f4
    // 0x12641ec: r2 = LoadClassIdInstr(r0)
    //     0x12641ec: ldur            x2, [x0, #-1]
    //     0x12641f0: ubfx            x2, x2, #0xc, #0x14
    // 0x12641f4: stur            x2, [fp, #-8]
    // 0x12641f8: r17 = -5204
    //     0x12641f8: mov             x17, #-0x1454
    // 0x12641fc: add             x16, x2, x17
    // 0x1264200: cmp             x16, #2
    // 0x1264204: b.hi            #0x12645f4
    // 0x1264208: r17 = 5204
    //     0x1264208: mov             x17, #0x1454
    // 0x126420c: cmp             x2, x17
    // 0x1264210: b.ne            #0x1264224
    // 0x1264214: LoadField: r1 = r0->field_7
    //     0x1264214: ldur            w1, [x0, #7]
    // 0x1264218: DecompressPointer r1
    //     0x1264218: add             x1, x1, HEAP, lsl #32
    // 0x126421c: mov             x2, x1
    // 0x1264220: b               #0x12642c0
    // 0x1264224: r17 = 5205
    //     0x1264224: mov             x17, #0x1455
    // 0x1264228: cmp             x2, x17
    // 0x126422c: b.ne            #0x1264280
    // 0x1264230: mov             x1, x0
    // 0x1264234: LoadField: r0 = r1->field_27
    //     0x1264234: ldur            w0, [x1, #0x27]
    // 0x1264238: DecompressPointer r0
    //     0x1264238: add             x0, x0, HEAP, lsl #32
    // 0x126423c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1264240: cmp             w0, w16
    // 0x1264244: b.ne            #0x1264254
    // 0x1264248: r2 = _colors
    //     0x1264248: add             x2, PP, #0x26, lsl #12  ; [pp+0x26570] Field <_BottomAppBarDefaultsM3@723408488._colors@723408488>: late final (offset: 0x28)
    //     0x126424c: ldr             x2, [x2, #0x570]
    // 0x1264250: r0 = InitLateFinalInstanceField()
    //     0x1264250: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1264254: LoadField: r1 = r0->field_97
    //     0x1264254: ldur            w1, [x0, #0x97]
    // 0x1264258: DecompressPointer r1
    //     0x1264258: add             x1, x1, HEAP, lsl #32
    // 0x126425c: cmp             w1, NULL
    // 0x1264260: b.ne            #0x1264274
    // 0x1264264: LoadField: r1 = r0->field_7b
    //     0x1264264: ldur            w1, [x0, #0x7b]
    // 0x1264268: DecompressPointer r1
    //     0x1264268: add             x1, x1, HEAP, lsl #32
    // 0x126426c: mov             x0, x1
    // 0x1264270: b               #0x1264278
    // 0x1264274: mov             x0, x1
    // 0x1264278: mov             x2, x0
    // 0x126427c: b               #0x12642c0
    // 0x1264280: LoadField: r1 = r0->field_23
    //     0x1264280: ldur            w1, [x0, #0x23]
    // 0x1264284: DecompressPointer r1
    //     0x1264284: add             x1, x1, HEAP, lsl #32
    // 0x1264288: r0 = brightnessOf()
    //     0x1264288: bl              #0xd1e4dc  ; [package:flutter/src/material/theme.dart] Theme::brightnessOf
    // 0x126428c: r16 = Instance_Brightness
    //     0x126428c: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x1264290: cmp             w0, w16
    // 0x1264294: b.ne            #0x12642b4
    // 0x1264298: r1 = _ConstMap len:12
    //     0x1264298: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c20] Map<int, Color>(12)
    //     0x126429c: ldr             x1, [x1, #0xc20]
    // 0x12642a0: r2 = 1600
    //     0x12642a0: mov             x2, #0x640
    // 0x12642a4: r0 = []()
    //     0x12642a4: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x12642a8: cmp             w0, NULL
    // 0x12642ac: b.eq            #0x126460c
    // 0x12642b0: b               #0x12642bc
    // 0x12642b4: r0 = Instance_Color
    //     0x12642b4: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x12642b8: ldr             x0, [x0, #0xc38]
    // 0x12642bc: mov             x2, x0
    // 0x12642c0: ldr             x0, [fp, #0x18]
    // 0x12642c4: stur            x2, [fp, #-0x18]
    // 0x12642c8: r3 = LoadClassIdInstr(r0)
    //     0x12642c8: ldur            x3, [x0, #-1]
    //     0x12642cc: ubfx            x3, x3, #0xc, #0x14
    // 0x12642d0: stur            x3, [fp, #-0x10]
    // 0x12642d4: r17 = 5204
    //     0x12642d4: mov             x17, #0x1454
    // 0x12642d8: cmp             x3, x17
    // 0x12642dc: b.ne            #0x12642f0
    // 0x12642e0: LoadField: r1 = r0->field_7
    //     0x12642e0: ldur            w1, [x0, #7]
    // 0x12642e4: DecompressPointer r1
    //     0x12642e4: add             x1, x1, HEAP, lsl #32
    // 0x12642e8: mov             x0, x2
    // 0x12642ec: b               #0x1264394
    // 0x12642f0: r17 = 5205
    //     0x12642f0: mov             x17, #0x1455
    // 0x12642f4: cmp             x3, x17
    // 0x12642f8: b.ne            #0x1264350
    // 0x12642fc: mov             x1, x0
    // 0x1264300: LoadField: r0 = r1->field_27
    //     0x1264300: ldur            w0, [x1, #0x27]
    // 0x1264304: DecompressPointer r0
    //     0x1264304: add             x0, x0, HEAP, lsl #32
    // 0x1264308: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126430c: cmp             w0, w16
    // 0x1264310: b.ne            #0x1264320
    // 0x1264314: r2 = _colors
    //     0x1264314: add             x2, PP, #0x26, lsl #12  ; [pp+0x26570] Field <_BottomAppBarDefaultsM3@723408488._colors@723408488>: late final (offset: 0x28)
    //     0x1264318: ldr             x2, [x2, #0x570]
    // 0x126431c: r0 = InitLateFinalInstanceField()
    //     0x126431c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1264320: LoadField: r1 = r0->field_97
    //     0x1264320: ldur            w1, [x0, #0x97]
    // 0x1264324: DecompressPointer r1
    //     0x1264324: add             x1, x1, HEAP, lsl #32
    // 0x1264328: cmp             w1, NULL
    // 0x126432c: b.ne            #0x1264340
    // 0x1264330: LoadField: r1 = r0->field_7b
    //     0x1264330: ldur            w1, [x0, #0x7b]
    // 0x1264334: DecompressPointer r1
    //     0x1264334: add             x1, x1, HEAP, lsl #32
    // 0x1264338: mov             x0, x1
    // 0x126433c: b               #0x1264344
    // 0x1264340: mov             x0, x1
    // 0x1264344: mov             x1, x0
    // 0x1264348: ldur            x0, [fp, #-0x18]
    // 0x126434c: b               #0x1264394
    // 0x1264350: LoadField: r1 = r0->field_23
    //     0x1264350: ldur            w1, [x0, #0x23]
    // 0x1264354: DecompressPointer r1
    //     0x1264354: add             x1, x1, HEAP, lsl #32
    // 0x1264358: r0 = brightnessOf()
    //     0x1264358: bl              #0xd1e4dc  ; [package:flutter/src/material/theme.dart] Theme::brightnessOf
    // 0x126435c: r16 = Instance_Brightness
    //     0x126435c: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x1264360: cmp             w0, w16
    // 0x1264364: b.ne            #0x1264384
    // 0x1264368: r1 = _ConstMap len:12
    //     0x1264368: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c20] Map<int, Color>(12)
    //     0x126436c: ldr             x1, [x1, #0xc20]
    // 0x1264370: r2 = 1600
    //     0x1264370: mov             x2, #0x640
    // 0x1264374: r0 = []()
    //     0x1264374: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x1264378: cmp             w0, NULL
    // 0x126437c: b.eq            #0x1264610
    // 0x1264380: b               #0x126438c
    // 0x1264384: r0 = Instance_Color
    //     0x1264384: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x1264388: ldr             x0, [x0, #0xc38]
    // 0x126438c: mov             x1, x0
    // 0x1264390: ldur            x0, [fp, #-0x18]
    // 0x1264394: r2 = LoadClassIdInstr(r0)
    //     0x1264394: ldur            x2, [x0, #-1]
    //     0x1264398: ubfx            x2, x2, #0xc, #0x14
    // 0x126439c: stp             x1, x0, [SP]
    // 0x12643a0: mov             x0, x2
    // 0x12643a4: mov             lr, x0
    // 0x12643a8: ldr             lr, [x21, lr, lsl #3]
    // 0x12643ac: blr             lr
    // 0x12643b0: tbnz            w0, #4, #0x12645f4
    // 0x12643b4: ldr             x1, [fp, #0x18]
    // 0x12643b8: ldr             x2, [fp, #0x10]
    // 0x12643bc: LoadField: r0 = r2->field_b
    //     0x12643bc: ldur            w0, [x2, #0xb]
    // 0x12643c0: DecompressPointer r0
    //     0x12643c0: add             x0, x0, HEAP, lsl #32
    // 0x12643c4: LoadField: r3 = r1->field_b
    //     0x12643c4: ldur            w3, [x1, #0xb]
    // 0x12643c8: DecompressPointer r3
    //     0x12643c8: add             x3, x3, HEAP, lsl #32
    // 0x12643cc: r4 = LoadClassIdInstr(r0)
    //     0x12643cc: ldur            x4, [x0, #-1]
    //     0x12643d0: ubfx            x4, x4, #0xc, #0x14
    // 0x12643d4: stp             x3, x0, [SP]
    // 0x12643d8: mov             x0, x4
    // 0x12643dc: mov             lr, x0
    // 0x12643e0: ldr             lr, [x21, lr, lsl #3]
    // 0x12643e4: blr             lr
    // 0x12643e8: tbnz            w0, #4, #0x12645f4
    // 0x12643ec: ldr             x1, [fp, #0x18]
    // 0x12643f0: ldr             x2, [fp, #0x10]
    // 0x12643f4: LoadField: r0 = r2->field_f
    //     0x12643f4: ldur            w0, [x2, #0xf]
    // 0x12643f8: DecompressPointer r0
    //     0x12643f8: add             x0, x0, HEAP, lsl #32
    // 0x12643fc: LoadField: r3 = r1->field_f
    //     0x12643fc: ldur            w3, [x1, #0xf]
    // 0x1264400: DecompressPointer r3
    //     0x1264400: add             x3, x3, HEAP, lsl #32
    // 0x1264404: cmp             w0, w3
    // 0x1264408: b.ne            #0x12645f4
    // 0x126440c: LoadField: r0 = r2->field_13
    //     0x126440c: ldur            w0, [x2, #0x13]
    // 0x1264410: DecompressPointer r0
    //     0x1264410: add             x0, x0, HEAP, lsl #32
    // 0x1264414: LoadField: r3 = r1->field_13
    //     0x1264414: ldur            w3, [x1, #0x13]
    // 0x1264418: DecompressPointer r3
    //     0x1264418: add             x3, x3, HEAP, lsl #32
    // 0x126441c: r4 = LoadClassIdInstr(r0)
    //     0x126441c: ldur            x4, [x0, #-1]
    //     0x1264420: ubfx            x4, x4, #0xc, #0x14
    // 0x1264424: stp             x3, x0, [SP]
    // 0x1264428: mov             x0, x4
    // 0x126442c: mov             lr, x0
    // 0x1264430: ldr             lr, [x21, lr, lsl #3]
    // 0x1264434: blr             lr
    // 0x1264438: tbnz            w0, #4, #0x12645f4
    // 0x126443c: ldur            x0, [fp, #-8]
    // 0x1264440: r17 = 5204
    //     0x1264440: mov             x17, #0x1454
    // 0x1264444: cmp             x0, x17
    // 0x1264448: b.ne            #0x1264460
    // 0x126444c: ldr             x2, [fp, #0x10]
    // 0x1264450: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x1264450: ldur            w1, [x2, #0x17]
    // 0x1264454: DecompressPointer r1
    //     0x1264454: add             x1, x1, HEAP, lsl #32
    // 0x1264458: mov             x2, x1
    // 0x126445c: b               #0x12644ac
    // 0x1264460: ldr             x2, [fp, #0x10]
    // 0x1264464: r17 = 5205
    //     0x1264464: mov             x17, #0x1455
    // 0x1264468: cmp             x0, x17
    // 0x126446c: b.ne            #0x126447c
    // 0x1264470: r2 = Instance_Color
    //     0x1264470: add             x2, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1264474: ldr             x2, [x2, #0x810]
    // 0x1264478: b               #0x12644ac
    // 0x126447c: LoadField: r1 = r2->field_23
    //     0x126447c: ldur            w1, [x2, #0x23]
    // 0x1264480: DecompressPointer r1
    //     0x1264480: add             x1, x1, HEAP, lsl #32
    // 0x1264484: r0 = of()
    //     0x1264484: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1264488: LoadField: r1 = r0->field_3f
    //     0x1264488: ldur            w1, [x0, #0x3f]
    // 0x126448c: DecompressPointer r1
    //     0x126448c: add             x1, x1, HEAP, lsl #32
    // 0x1264490: LoadField: r0 = r1->field_c3
    //     0x1264490: ldur            w0, [x1, #0xc3]
    // 0x1264494: DecompressPointer r0
    //     0x1264494: add             x0, x0, HEAP, lsl #32
    // 0x1264498: cmp             w0, NULL
    // 0x126449c: b.ne            #0x12644a8
    // 0x12644a0: LoadField: r0 = r1->field_b
    //     0x12644a0: ldur            w0, [x1, #0xb]
    // 0x12644a4: DecompressPointer r0
    //     0x12644a4: add             x0, x0, HEAP, lsl #32
    // 0x12644a8: mov             x2, x0
    // 0x12644ac: ldur            x0, [fp, #-0x10]
    // 0x12644b0: stur            x2, [fp, #-0x18]
    // 0x12644b4: r17 = 5204
    //     0x12644b4: mov             x17, #0x1454
    // 0x12644b8: cmp             x0, x17
    // 0x12644bc: b.ne            #0x12644d4
    // 0x12644c0: ldr             x3, [fp, #0x18]
    // 0x12644c4: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x12644c4: ldur            w1, [x3, #0x17]
    // 0x12644c8: DecompressPointer r1
    //     0x12644c8: add             x1, x1, HEAP, lsl #32
    // 0x12644cc: mov             x0, x2
    // 0x12644d0: b               #0x1264528
    // 0x12644d4: ldr             x3, [fp, #0x18]
    // 0x12644d8: r17 = 5205
    //     0x12644d8: mov             x17, #0x1455
    // 0x12644dc: cmp             x0, x17
    // 0x12644e0: b.ne            #0x12644f4
    // 0x12644e4: mov             x0, x2
    // 0x12644e8: r1 = Instance_Color
    //     0x12644e8: add             x1, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x12644ec: ldr             x1, [x1, #0x810]
    // 0x12644f0: b               #0x1264528
    // 0x12644f4: LoadField: r1 = r3->field_23
    //     0x12644f4: ldur            w1, [x3, #0x23]
    // 0x12644f8: DecompressPointer r1
    //     0x12644f8: add             x1, x1, HEAP, lsl #32
    // 0x12644fc: r0 = of()
    //     0x12644fc: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1264500: LoadField: r1 = r0->field_3f
    //     0x1264500: ldur            w1, [x0, #0x3f]
    // 0x1264504: DecompressPointer r1
    //     0x1264504: add             x1, x1, HEAP, lsl #32
    // 0x1264508: LoadField: r0 = r1->field_c3
    //     0x1264508: ldur            w0, [x1, #0xc3]
    // 0x126450c: DecompressPointer r0
    //     0x126450c: add             x0, x0, HEAP, lsl #32
    // 0x1264510: cmp             w0, NULL
    // 0x1264514: b.ne            #0x1264520
    // 0x1264518: LoadField: r0 = r1->field_b
    //     0x1264518: ldur            w0, [x1, #0xb]
    // 0x126451c: DecompressPointer r0
    //     0x126451c: add             x0, x0, HEAP, lsl #32
    // 0x1264520: mov             x1, x0
    // 0x1264524: ldur            x0, [fp, #-0x18]
    // 0x1264528: r2 = LoadClassIdInstr(r0)
    //     0x1264528: ldur            x2, [x0, #-1]
    //     0x126452c: ubfx            x2, x2, #0xc, #0x14
    // 0x1264530: stp             x1, x0, [SP]
    // 0x1264534: mov             x0, x2
    // 0x1264538: mov             lr, x0
    // 0x126453c: ldr             lr, [x21, lr, lsl #3]
    // 0x1264540: blr             lr
    // 0x1264544: tbnz            w0, #4, #0x12645f4
    // 0x1264548: ldur            x0, [fp, #-8]
    // 0x126454c: r17 = 5204
    //     0x126454c: mov             x17, #0x1454
    // 0x1264550: cmp             x0, x17
    // 0x1264554: b.ne            #0x1264568
    // 0x1264558: ldr             x0, [fp, #0x10]
    // 0x126455c: LoadField: r1 = r0->field_1b
    //     0x126455c: ldur            w1, [x0, #0x1b]
    // 0x1264560: DecompressPointer r1
    //     0x1264560: add             x1, x1, HEAP, lsl #32
    // 0x1264564: b               #0x1264588
    // 0x1264568: r17 = 5205
    //     0x1264568: mov             x17, #0x1455
    // 0x126456c: cmp             x0, x17
    // 0x1264570: b.ne            #0x1264580
    // 0x1264574: r1 = Instance_Color
    //     0x1264574: add             x1, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1264578: ldr             x1, [x1, #0x810]
    // 0x126457c: b               #0x1264588
    // 0x1264580: r1 = Instance_Color
    //     0x1264580: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x1264584: ldr             x1, [x1, #0x948]
    // 0x1264588: ldur            x0, [fp, #-0x10]
    // 0x126458c: r17 = 5204
    //     0x126458c: mov             x17, #0x1454
    // 0x1264590: cmp             x0, x17
    // 0x1264594: b.ne            #0x12645ac
    // 0x1264598: ldr             x0, [fp, #0x18]
    // 0x126459c: LoadField: r2 = r0->field_1b
    //     0x126459c: ldur            w2, [x0, #0x1b]
    // 0x12645a0: DecompressPointer r2
    //     0x12645a0: add             x2, x2, HEAP, lsl #32
    // 0x12645a4: mov             x0, x2
    // 0x12645a8: b               #0x12645cc
    // 0x12645ac: r17 = 5205
    //     0x12645ac: mov             x17, #0x1455
    // 0x12645b0: cmp             x0, x17
    // 0x12645b4: b.ne            #0x12645c4
    // 0x12645b8: r0 = Instance_Color
    //     0x12645b8: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x12645bc: ldr             x0, [x0, #0x810]
    // 0x12645c0: b               #0x12645cc
    // 0x12645c4: r0 = Instance_Color
    //     0x12645c4: add             x0, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x12645c8: ldr             x0, [x0, #0x948]
    // 0x12645cc: r2 = LoadClassIdInstr(r1)
    //     0x12645cc: ldur            x2, [x1, #-1]
    //     0x12645d0: ubfx            x2, x2, #0xc, #0x14
    // 0x12645d4: stp             x0, x1, [SP]
    // 0x12645d8: mov             x0, x2
    // 0x12645dc: mov             lr, x0
    // 0x12645e0: ldr             lr, [x21, lr, lsl #3]
    // 0x12645e4: blr             lr
    // 0x12645e8: tbnz            w0, #4, #0x12645f4
    // 0x12645ec: r0 = true
    //     0x12645ec: add             x0, NULL, #0x20  ; true
    // 0x12645f0: b               #0x12645f8
    // 0x12645f4: r0 = false
    //     0x12645f4: add             x0, NULL, #0x30  ; false
    // 0x12645f8: LeaveFrame
    //     0x12645f8: mov             SP, fp
    //     0x12645fc: ldp             fp, lr, [SP], #0x10
    // 0x1264600: ret
    //     0x1264600: ret             
    // 0x1264604: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1264604: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1264608: b               #0x126418c
    // 0x126460c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x126460c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1264610: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1264610: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6859, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class BottomAppBarTheme extends _MixinApplication8&InheritedTheme&Diagnosticable {

  static _ of(/* No info */) {
    // ** addr: 0xdeae60, size: 0x58
    // 0xdeae60: EnterFrame
    //     0xdeae60: stp             fp, lr, [SP, #-0x10]!
    //     0xdeae64: mov             fp, SP
    // 0xdeae68: AllocStack(0x18)
    //     0xdeae68: sub             SP, SP, #0x18
    // 0xdeae6c: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xdeae6c: stur            x1, [fp, #-8]
    // 0xdeae70: CheckStackOverflow
    //     0xdeae70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdeae74: cmp             SP, x16
    //     0xdeae78: b.ls            #0xdeaeb0
    // 0xdeae7c: r16 = <BottomAppBarTheme>
    //     0xdeae7c: add             x16, PP, #0x95, lsl #12  ; [pp+0x95e88] TypeArguments: <BottomAppBarTheme>
    //     0xdeae80: ldr             x16, [x16, #0xe88]
    // 0xdeae84: stp             x1, x16, [SP]
    // 0xdeae88: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdeae88: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdeae8c: r0 = dependOnInheritedWidgetOfExactType()
    //     0xdeae8c: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xdeae90: ldur            x1, [fp, #-8]
    // 0xdeae94: r0 = of()
    //     0xdeae94: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdeae98: LoadField: r1 = r0->field_9f
    //     0xdeae98: ldur            w1, [x0, #0x9f]
    // 0xdeae9c: DecompressPointer r1
    //     0xdeae9c: add             x1, x1, HEAP, lsl #32
    // 0xdeaea0: mov             x0, x1
    // 0xdeaea4: LeaveFrame
    //     0xdeaea4: mov             SP, fp
    //     0xdeaea8: ldp             fp, lr, [SP], #0x10
    // 0xdeaeac: ret
    //     0xdeaeac: ret             
    // 0xdeaeb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdeaeb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdeaeb4: b               #0xdeae7c
  }
}
