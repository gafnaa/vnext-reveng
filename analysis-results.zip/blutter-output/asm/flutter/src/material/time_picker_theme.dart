// lib: , url: package:flutter/src/material/time_picker_theme.dart

// class id: 1048970, size: 0x8
class :: {
}

// class id: 5052, size: 0x68, field offset: 0x8
//   const constructor, 
class TimePickerThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x113af60, size: 0x19c
    // 0x113af60: EnterFrame
    //     0x113af60: stp             fp, lr, [SP, #-0x10]!
    //     0x113af64: mov             fp, SP
    // 0x113af68: AllocStack(0x10)
    //     0x113af68: sub             SP, SP, #0x10
    // 0x113af6c: r0 = 48
    //     0x113af6c: mov             x0, #0x30
    // 0x113af70: CheckStackOverflow
    //     0x113af70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x113af74: cmp             SP, x16
    //     0x113af78: b.ls            #0x113b0f4
    // 0x113af7c: ldr             x3, [fp, #0x10]
    // 0x113af80: LoadField: r4 = r3->field_7
    //     0x113af80: ldur            w4, [x3, #7]
    // 0x113af84: DecompressPointer r4
    //     0x113af84: add             x4, x4, HEAP, lsl #32
    // 0x113af88: mov             x2, x0
    // 0x113af8c: stur            x4, [fp, #-8]
    // 0x113af90: r1 = <Object?>
    //     0x113af90: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x113af94: r0 = AllocateArray()
    //     0x113af94: bl              #0x13df928  ; AllocateArrayStub
    // 0x113af98: mov             x2, x0
    // 0x113af9c: ldur            x0, [fp, #-8]
    // 0x113afa0: stur            x2, [fp, #-0x10]
    // 0x113afa4: StoreField: r2->field_f = r0
    //     0x113afa4: stur            w0, [x2, #0xf]
    // 0x113afa8: ldr             x0, [fp, #0x10]
    // 0x113afac: LoadField: r1 = r0->field_b
    //     0x113afac: ldur            w1, [x0, #0xb]
    // 0x113afb0: DecompressPointer r1
    //     0x113afb0: add             x1, x1, HEAP, lsl #32
    // 0x113afb4: StoreField: r2->field_13 = r1
    //     0x113afb4: stur            w1, [x2, #0x13]
    // 0x113afb8: LoadField: r1 = r0->field_f
    //     0x113afb8: ldur            w1, [x0, #0xf]
    // 0x113afbc: DecompressPointer r1
    //     0x113afbc: add             x1, x1, HEAP, lsl #32
    // 0x113afc0: ArrayStore: r2[0] = r1  ; List_4
    //     0x113afc0: stur            w1, [x2, #0x17]
    // 0x113afc4: LoadField: r1 = r0->field_13
    //     0x113afc4: ldur            w1, [x0, #0x13]
    // 0x113afc8: DecompressPointer r1
    //     0x113afc8: add             x1, x1, HEAP, lsl #32
    // 0x113afcc: StoreField: r2->field_1b = r1
    //     0x113afcc: stur            w1, [x2, #0x1b]
    // 0x113afd0: StoreField: r2->field_1f = rNULL
    //     0x113afd0: stur            NULL, [x2, #0x1f]
    // 0x113afd4: LoadField: r1 = r0->field_1b
    //     0x113afd4: ldur            w1, [x0, #0x1b]
    // 0x113afd8: DecompressPointer r1
    //     0x113afd8: add             x1, x1, HEAP, lsl #32
    // 0x113afdc: StoreField: r2->field_23 = r1
    //     0x113afdc: stur            w1, [x2, #0x23]
    // 0x113afe0: LoadField: r1 = r0->field_1f
    //     0x113afe0: ldur            w1, [x0, #0x1f]
    // 0x113afe4: DecompressPointer r1
    //     0x113afe4: add             x1, x1, HEAP, lsl #32
    // 0x113afe8: StoreField: r2->field_27 = r1
    //     0x113afe8: stur            w1, [x2, #0x27]
    // 0x113afec: LoadField: r1 = r0->field_23
    //     0x113afec: ldur            w1, [x0, #0x23]
    // 0x113aff0: DecompressPointer r1
    //     0x113aff0: add             x1, x1, HEAP, lsl #32
    // 0x113aff4: StoreField: r2->field_2b = r1
    //     0x113aff4: stur            w1, [x2, #0x2b]
    // 0x113aff8: LoadField: r1 = r0->field_27
    //     0x113aff8: ldur            w1, [x0, #0x27]
    // 0x113affc: DecompressPointer r1
    //     0x113affc: add             x1, x1, HEAP, lsl #32
    // 0x113b000: StoreField: r2->field_2f = r1
    //     0x113b000: stur            w1, [x2, #0x2f]
    // 0x113b004: LoadField: r1 = r0->field_2b
    //     0x113b004: ldur            w1, [x0, #0x2b]
    // 0x113b008: DecompressPointer r1
    //     0x113b008: add             x1, x1, HEAP, lsl #32
    // 0x113b00c: StoreField: r2->field_33 = r1
    //     0x113b00c: stur            w1, [x2, #0x33]
    // 0x113b010: LoadField: r1 = r0->field_2f
    //     0x113b010: ldur            w1, [x0, #0x2f]
    // 0x113b014: DecompressPointer r1
    //     0x113b014: add             x1, x1, HEAP, lsl #32
    // 0x113b018: StoreField: r2->field_37 = r1
    //     0x113b018: stur            w1, [x2, #0x37]
    // 0x113b01c: LoadField: r1 = r0->field_33
    //     0x113b01c: ldur            w1, [x0, #0x33]
    // 0x113b020: DecompressPointer r1
    //     0x113b020: add             x1, x1, HEAP, lsl #32
    // 0x113b024: StoreField: r2->field_3b = r1
    //     0x113b024: stur            w1, [x2, #0x3b]
    // 0x113b028: LoadField: r1 = r0->field_37
    //     0x113b028: ldur            w1, [x0, #0x37]
    // 0x113b02c: DecompressPointer r1
    //     0x113b02c: add             x1, x1, HEAP, lsl #32
    // 0x113b030: StoreField: r2->field_3f = r1
    //     0x113b030: stur            w1, [x2, #0x3f]
    // 0x113b034: LoadField: r1 = r0->field_3b
    //     0x113b034: ldur            w1, [x0, #0x3b]
    // 0x113b038: DecompressPointer r1
    //     0x113b038: add             x1, x1, HEAP, lsl #32
    // 0x113b03c: StoreField: r2->field_43 = r1
    //     0x113b03c: stur            w1, [x2, #0x43]
    // 0x113b040: LoadField: r1 = r0->field_3f
    //     0x113b040: ldur            w1, [x0, #0x3f]
    // 0x113b044: DecompressPointer r1
    //     0x113b044: add             x1, x1, HEAP, lsl #32
    // 0x113b048: StoreField: r2->field_47 = r1
    //     0x113b048: stur            w1, [x2, #0x47]
    // 0x113b04c: LoadField: r1 = r0->field_43
    //     0x113b04c: ldur            w1, [x0, #0x43]
    // 0x113b050: DecompressPointer r1
    //     0x113b050: add             x1, x1, HEAP, lsl #32
    // 0x113b054: StoreField: r2->field_4b = r1
    //     0x113b054: stur            w1, [x2, #0x4b]
    // 0x113b058: LoadField: r1 = r0->field_47
    //     0x113b058: ldur            w1, [x0, #0x47]
    // 0x113b05c: DecompressPointer r1
    //     0x113b05c: add             x1, x1, HEAP, lsl #32
    // 0x113b060: StoreField: r2->field_4f = r1
    //     0x113b060: stur            w1, [x2, #0x4f]
    // 0x113b064: LoadField: r1 = r0->field_4b
    //     0x113b064: ldur            w1, [x0, #0x4b]
    // 0x113b068: DecompressPointer r1
    //     0x113b068: add             x1, x1, HEAP, lsl #32
    // 0x113b06c: StoreField: r2->field_53 = r1
    //     0x113b06c: stur            w1, [x2, #0x53]
    // 0x113b070: LoadField: r1 = r0->field_4f
    //     0x113b070: ldur            w1, [x0, #0x4f]
    // 0x113b074: DecompressPointer r1
    //     0x113b074: add             x1, x1, HEAP, lsl #32
    // 0x113b078: StoreField: r2->field_57 = r1
    //     0x113b078: stur            w1, [x2, #0x57]
    // 0x113b07c: StoreField: r2->field_5b = rNULL
    //     0x113b07c: stur            NULL, [x2, #0x5b]
    // 0x113b080: LoadField: r1 = r0->field_57
    //     0x113b080: ldur            w1, [x0, #0x57]
    // 0x113b084: DecompressPointer r1
    //     0x113b084: add             x1, x1, HEAP, lsl #32
    // 0x113b088: StoreField: r2->field_5f = r1
    //     0x113b088: stur            w1, [x2, #0x5f]
    // 0x113b08c: LoadField: r1 = r0->field_5b
    //     0x113b08c: ldur            w1, [x0, #0x5b]
    // 0x113b090: DecompressPointer r1
    //     0x113b090: add             x1, x1, HEAP, lsl #32
    // 0x113b094: StoreField: r2->field_63 = r1
    //     0x113b094: stur            w1, [x2, #0x63]
    // 0x113b098: LoadField: r1 = r0->field_5f
    //     0x113b098: ldur            w1, [x0, #0x5f]
    // 0x113b09c: DecompressPointer r1
    //     0x113b09c: add             x1, x1, HEAP, lsl #32
    // 0x113b0a0: StoreField: r2->field_67 = r1
    //     0x113b0a0: stur            w1, [x2, #0x67]
    // 0x113b0a4: LoadField: r1 = r0->field_63
    //     0x113b0a4: ldur            w1, [x0, #0x63]
    // 0x113b0a8: DecompressPointer r1
    //     0x113b0a8: add             x1, x1, HEAP, lsl #32
    // 0x113b0ac: StoreField: r2->field_6b = r1
    //     0x113b0ac: stur            w1, [x2, #0x6b]
    // 0x113b0b0: r1 = <Object?>
    //     0x113b0b0: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x113b0b4: r0 = AllocateGrowableArray()
    //     0x113b0b4: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x113b0b8: mov             x1, x0
    // 0x113b0bc: ldur            x0, [fp, #-0x10]
    // 0x113b0c0: StoreField: r1->field_f = r0
    //     0x113b0c0: stur            w0, [x1, #0xf]
    // 0x113b0c4: r0 = 48
    //     0x113b0c4: mov             x0, #0x30
    // 0x113b0c8: StoreField: r1->field_b = r0
    //     0x113b0c8: stur            w0, [x1, #0xb]
    // 0x113b0cc: r0 = hashAll()
    //     0x113b0cc: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x113b0d0: mov             x2, x0
    // 0x113b0d4: r0 = BoxInt64Instr(r2)
    //     0x113b0d4: sbfiz           x0, x2, #1, #0x1f
    //     0x113b0d8: cmp             x2, x0, asr #1
    //     0x113b0dc: b.eq            #0x113b0e8
    //     0x113b0e0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113b0e4: stur            x2, [x0, #7]
    // 0x113b0e8: LeaveFrame
    //     0x113b0e8: mov             SP, fp
    //     0x113b0ec: ldp             fp, lr, [SP], #0x10
    // 0x113b0f0: ret
    //     0x113b0f0: ret             
    // 0x113b0f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x113b0f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x113b0f8: b               #0x113af7c
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x11643f8, size: 0x240
    // 0x11643f8: EnterFrame
    //     0x11643f8: stp             fp, lr, [SP, #-0x10]!
    //     0x11643fc: mov             fp, SP
    // 0x1164400: AllocStack(0x30)
    //     0x1164400: sub             SP, SP, #0x30
    // 0x1164404: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x30 */)
    //     0x1164404: mov             x4, x1
    //     0x1164408: mov             x0, x2
    //     0x116440c: stur            x1, [fp, #-0x10]
    //     0x1164410: stur            x2, [fp, #-0x18]
    //     0x1164414: stur            d0, [fp, #-0x30]
    // 0x1164418: CheckStackOverflow
    //     0x1164418: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116441c: cmp             SP, x16
    //     0x1164420: b.ls            #0x1164614
    // 0x1164424: cmp             w4, w0
    // 0x1164428: b.ne            #0x116443c
    // 0x116442c: mov             x0, x4
    // 0x1164430: LeaveFrame
    //     0x1164430: mov             SP, fp
    //     0x1164434: ldp             fp, lr, [SP], #0x10
    // 0x1164438: ret
    //     0x1164438: ret             
    // 0x116443c: r5 = inline_Allocate_Double()
    //     0x116443c: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x1164440: add             x5, x5, #0x10
    //     0x1164444: cmp             x1, x5
    //     0x1164448: b.ls            #0x116461c
    //     0x116444c: str             x5, [THR, #0x60]  ; THR::top
    //     0x1164450: sub             x5, x5, #0xf
    //     0x1164454: mov             x1, #0xe19c
    //     0x1164458: movk            x1, #3, lsl #16
    //     0x116445c: stur            x1, [x5, #-1]
    // 0x1164460: dmb             ishst
    // 0x1164464: StoreField: r5->field_7 = d0
    //     0x1164464: stur            d0, [x5, #7]
    // 0x1164468: mov             x3, x5
    // 0x116446c: stur            x5, [fp, #-8]
    // 0x1164470: r1 = Null
    //     0x1164470: mov             x1, NULL
    // 0x1164474: r2 = Null
    //     0x1164474: mov             x2, NULL
    // 0x1164478: r0 = lerp()
    //     0x1164478: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116447c: ldur            x0, [fp, #-0x10]
    // 0x1164480: LoadField: r1 = r0->field_b
    //     0x1164480: ldur            w1, [x0, #0xb]
    // 0x1164484: DecompressPointer r1
    //     0x1164484: add             x1, x1, HEAP, lsl #32
    // 0x1164488: ldur            x3, [fp, #-0x18]
    // 0x116448c: LoadField: r2 = r3->field_b
    //     0x116448c: ldur            w2, [x3, #0xb]
    // 0x1164490: DecompressPointer r2
    //     0x1164490: add             x2, x2, HEAP, lsl #32
    // 0x1164494: ldur            d0, [fp, #-0x30]
    // 0x1164498: r0 = lerp()
    //     0x1164498: bl              #0x1164644  ; [package:flutter/src/material/button_style.dart] ButtonStyle::lerp
    // 0x116449c: mov             x3, x0
    // 0x11644a0: ldur            x0, [fp, #-0x10]
    // 0x11644a4: stur            x3, [fp, #-0x20]
    // 0x11644a8: LoadField: r1 = r0->field_f
    //     0x11644a8: ldur            w1, [x0, #0xf]
    // 0x11644ac: DecompressPointer r1
    //     0x11644ac: add             x1, x1, HEAP, lsl #32
    // 0x11644b0: ldur            x4, [fp, #-0x18]
    // 0x11644b4: LoadField: r2 = r4->field_f
    //     0x11644b4: ldur            w2, [x4, #0xf]
    // 0x11644b8: DecompressPointer r2
    //     0x11644b8: add             x2, x2, HEAP, lsl #32
    // 0x11644bc: ldur            d0, [fp, #-0x30]
    // 0x11644c0: r0 = lerp()
    //     0x11644c0: bl              #0x1164644  ; [package:flutter/src/material/button_style.dart] ButtonStyle::lerp
    // 0x11644c4: ldur            x3, [fp, #-8]
    // 0x11644c8: r1 = Null
    //     0x11644c8: mov             x1, NULL
    // 0x11644cc: r2 = Null
    //     0x11644cc: mov             x2, NULL
    // 0x11644d0: stur            x0, [fp, #-0x28]
    // 0x11644d4: r0 = lerp()
    //     0x11644d4: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11644d8: ldur            d0, [fp, #-0x30]
    // 0x11644dc: r1 = Null
    //     0x11644dc: mov             x1, NULL
    // 0x11644e0: r2 = Null
    //     0x11644e0: mov             x2, NULL
    // 0x11644e4: r0 = lerp()
    //     0x11644e4: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x11644e8: ldur            x3, [fp, #-8]
    // 0x11644ec: r1 = Null
    //     0x11644ec: mov             x1, NULL
    // 0x11644f0: r2 = Null
    //     0x11644f0: mov             x2, NULL
    // 0x11644f4: r0 = lerp()
    //     0x11644f4: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11644f8: ldur            x3, [fp, #-8]
    // 0x11644fc: r1 = Null
    //     0x11644fc: mov             x1, NULL
    // 0x1164500: r2 = Null
    //     0x1164500: mov             x2, NULL
    // 0x1164504: r0 = lerp()
    //     0x1164504: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1164508: ldur            x3, [fp, #-8]
    // 0x116450c: r1 = Null
    //     0x116450c: mov             x1, NULL
    // 0x1164510: r2 = Null
    //     0x1164510: mov             x2, NULL
    // 0x1164514: r0 = lerp()
    //     0x1164514: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1164518: ldur            x3, [fp, #-8]
    // 0x116451c: r1 = Null
    //     0x116451c: mov             x1, NULL
    // 0x1164520: r2 = Null
    //     0x1164520: mov             x2, NULL
    // 0x1164524: r0 = lerp()
    //     0x1164524: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1164528: ldur            x3, [fp, #-8]
    // 0x116452c: r1 = Null
    //     0x116452c: mov             x1, NULL
    // 0x1164530: r2 = Null
    //     0x1164530: mov             x2, NULL
    // 0x1164534: r0 = lerp()
    //     0x1164534: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1164538: ldur            x3, [fp, #-8]
    // 0x116453c: r1 = Null
    //     0x116453c: mov             x1, NULL
    // 0x1164540: r2 = Null
    //     0x1164540: mov             x2, NULL
    // 0x1164544: r0 = lerp()
    //     0x1164544: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1164548: ldur            x0, [fp, #-0x10]
    // 0x116454c: LoadField: r1 = r0->field_37
    //     0x116454c: ldur            w1, [x0, #0x37]
    // 0x1164550: DecompressPointer r1
    //     0x1164550: add             x1, x1, HEAP, lsl #32
    // 0x1164554: ldur            x0, [fp, #-0x18]
    // 0x1164558: LoadField: r2 = r0->field_37
    //     0x1164558: ldur            w2, [x0, #0x37]
    // 0x116455c: DecompressPointer r2
    //     0x116455c: add             x2, x2, HEAP, lsl #32
    // 0x1164560: ldur            x3, [fp, #-8]
    // 0x1164564: r0 = lerpDouble()
    //     0x1164564: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1164568: ldur            x3, [fp, #-8]
    // 0x116456c: r1 = Null
    //     0x116456c: mov             x1, NULL
    // 0x1164570: r2 = Null
    //     0x1164570: mov             x2, NULL
    // 0x1164574: stur            x0, [fp, #-0x10]
    // 0x1164578: r0 = lerp()
    //     0x1164578: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116457c: ldur            x3, [fp, #-8]
    // 0x1164580: r1 = Null
    //     0x1164580: mov             x1, NULL
    // 0x1164584: r2 = Null
    //     0x1164584: mov             x2, NULL
    // 0x1164588: r0 = lerp()
    //     0x1164588: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x116458c: ldur            x3, [fp, #-8]
    // 0x1164590: r1 = Null
    //     0x1164590: mov             x1, NULL
    // 0x1164594: r2 = Null
    //     0x1164594: mov             x2, NULL
    // 0x1164598: r0 = lerp()
    //     0x1164598: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116459c: ldur            d0, [fp, #-0x30]
    // 0x11645a0: r1 = Null
    //     0x11645a0: mov             x1, NULL
    // 0x11645a4: r2 = Null
    //     0x11645a4: mov             x2, NULL
    // 0x11645a8: r0 = lerp()
    //     0x11645a8: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x11645ac: ldur            x3, [fp, #-8]
    // 0x11645b0: r1 = Null
    //     0x11645b0: mov             x1, NULL
    // 0x11645b4: r2 = Null
    //     0x11645b4: mov             x2, NULL
    // 0x11645b8: r0 = lerp()
    //     0x11645b8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11645bc: ldur            x3, [fp, #-8]
    // 0x11645c0: r1 = Null
    //     0x11645c0: mov             x1, NULL
    // 0x11645c4: r2 = Null
    //     0x11645c4: mov             x2, NULL
    // 0x11645c8: r0 = lerp()
    //     0x11645c8: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x11645cc: ldur            x3, [fp, #-8]
    // 0x11645d0: r1 = Null
    //     0x11645d0: mov             x1, NULL
    // 0x11645d4: r2 = Null
    //     0x11645d4: mov             x2, NULL
    // 0x11645d8: r0 = lerp()
    //     0x11645d8: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x11645dc: ldur            d0, [fp, #-0x30]
    // 0x11645e0: r1 = Null
    //     0x11645e0: mov             x1, NULL
    // 0x11645e4: r2 = Null
    //     0x11645e4: mov             x2, NULL
    // 0x11645e8: r0 = lerp()
    //     0x11645e8: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x11645ec: r0 = TimePickerThemeData()
    //     0x11645ec: bl              #0x1164638  ; AllocateTimePickerThemeDataStub -> TimePickerThemeData (size=0x68)
    // 0x11645f0: ldur            x1, [fp, #-0x20]
    // 0x11645f4: StoreField: r0->field_b = r1
    //     0x11645f4: stur            w1, [x0, #0xb]
    // 0x11645f8: ldur            x1, [fp, #-0x28]
    // 0x11645fc: StoreField: r0->field_f = r1
    //     0x11645fc: stur            w1, [x0, #0xf]
    // 0x1164600: ldur            x1, [fp, #-0x10]
    // 0x1164604: StoreField: r0->field_37 = r1
    //     0x1164604: stur            w1, [x0, #0x37]
    // 0x1164608: LeaveFrame
    //     0x1164608: mov             SP, fp
    //     0x116460c: ldp             fp, lr, [SP], #0x10
    // 0x1164610: ret
    //     0x1164610: ret             
    // 0x1164614: r0 = StackOverflowSharedWithFPURegs()
    //     0x1164614: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1164618: b               #0x1164424
    // 0x116461c: SaveReg d0
    //     0x116461c: str             q0, [SP, #-0x10]!
    // 0x1164620: stp             x0, x4, [SP, #-0x10]!
    // 0x1164624: r0 = AllocateDouble()
    //     0x1164624: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1164628: mov             x5, x0
    // 0x116462c: ldp             x0, x4, [SP], #0x10
    // 0x1164630: RestoreReg d0
    //     0x1164630: ldr             q0, [SP], #0x10
    // 0x1164634: b               #0x1164464
  }
  _ ==(/* No info */) {
    // ** addr: 0x1278330, size: 0x174
    // 0x1278330: EnterFrame
    //     0x1278330: stp             fp, lr, [SP, #-0x10]!
    //     0x1278334: mov             fp, SP
    // 0x1278338: AllocStack(0x10)
    //     0x1278338: sub             SP, SP, #0x10
    // 0x127833c: CheckStackOverflow
    //     0x127833c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1278340: cmp             SP, x16
    //     0x1278344: b.ls            #0x127849c
    // 0x1278348: ldr             x0, [fp, #0x10]
    // 0x127834c: cmp             w0, NULL
    // 0x1278350: b.ne            #0x1278364
    // 0x1278354: r0 = false
    //     0x1278354: add             x0, NULL, #0x30  ; false
    // 0x1278358: LeaveFrame
    //     0x1278358: mov             SP, fp
    //     0x127835c: ldp             fp, lr, [SP], #0x10
    // 0x1278360: ret
    //     0x1278360: ret             
    // 0x1278364: ldr             x1, [fp, #0x18]
    // 0x1278368: cmp             w1, w0
    // 0x127836c: b.ne            #0x1278380
    // 0x1278370: r0 = true
    //     0x1278370: add             x0, NULL, #0x20  ; true
    // 0x1278374: LeaveFrame
    //     0x1278374: mov             SP, fp
    //     0x1278378: ldp             fp, lr, [SP], #0x10
    // 0x127837c: ret
    //     0x127837c: ret             
    // 0x1278380: str             x0, [SP]
    // 0x1278384: r0 = runtimeType()
    //     0x1278384: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1278388: r1 = LoadClassIdInstr(r0)
    //     0x1278388: ldur            x1, [x0, #-1]
    //     0x127838c: ubfx            x1, x1, #0xc, #0x14
    // 0x1278390: r16 = TimePickerThemeData
    //     0x1278390: add             x16, PP, #0x26, lsl #12  ; [pp+0x265b0] Type: TimePickerThemeData
    //     0x1278394: ldr             x16, [x16, #0x5b0]
    // 0x1278398: stp             x16, x0, [SP]
    // 0x127839c: mov             x0, x1
    // 0x12783a0: mov             lr, x0
    // 0x12783a4: ldr             lr, [x21, lr, lsl #3]
    // 0x12783a8: blr             lr
    // 0x12783ac: tbz             w0, #4, #0x12783c0
    // 0x12783b0: r0 = false
    //     0x12783b0: add             x0, NULL, #0x30  ; false
    // 0x12783b4: LeaveFrame
    //     0x12783b4: mov             SP, fp
    //     0x12783b8: ldp             fp, lr, [SP], #0x10
    // 0x12783bc: ret
    //     0x12783bc: ret             
    // 0x12783c0: ldr             x1, [fp, #0x10]
    // 0x12783c4: r0 = 60
    //     0x12783c4: mov             x0, #0x3c
    // 0x12783c8: branchIfSmi(r1, 0x12783d4)
    //     0x12783c8: tbz             w1, #0, #0x12783d4
    // 0x12783cc: r0 = LoadClassIdInstr(r1)
    //     0x12783cc: ldur            x0, [x1, #-1]
    //     0x12783d0: ubfx            x0, x0, #0xc, #0x14
    // 0x12783d4: r17 = 5052
    //     0x12783d4: mov             x17, #0x13bc
    // 0x12783d8: cmp             x0, x17
    // 0x12783dc: b.ne            #0x127848c
    // 0x12783e0: ldr             x2, [fp, #0x18]
    // 0x12783e4: LoadField: r0 = r1->field_b
    //     0x12783e4: ldur            w0, [x1, #0xb]
    // 0x12783e8: DecompressPointer r0
    //     0x12783e8: add             x0, x0, HEAP, lsl #32
    // 0x12783ec: LoadField: r3 = r2->field_b
    //     0x12783ec: ldur            w3, [x2, #0xb]
    // 0x12783f0: DecompressPointer r3
    //     0x12783f0: add             x3, x3, HEAP, lsl #32
    // 0x12783f4: r4 = LoadClassIdInstr(r0)
    //     0x12783f4: ldur            x4, [x0, #-1]
    //     0x12783f8: ubfx            x4, x4, #0xc, #0x14
    // 0x12783fc: stp             x3, x0, [SP]
    // 0x1278400: mov             x0, x4
    // 0x1278404: mov             lr, x0
    // 0x1278408: ldr             lr, [x21, lr, lsl #3]
    // 0x127840c: blr             lr
    // 0x1278410: tbnz            w0, #4, #0x127848c
    // 0x1278414: ldr             x2, [fp, #0x18]
    // 0x1278418: ldr             x1, [fp, #0x10]
    // 0x127841c: LoadField: r0 = r1->field_f
    //     0x127841c: ldur            w0, [x1, #0xf]
    // 0x1278420: DecompressPointer r0
    //     0x1278420: add             x0, x0, HEAP, lsl #32
    // 0x1278424: LoadField: r3 = r2->field_f
    //     0x1278424: ldur            w3, [x2, #0xf]
    // 0x1278428: DecompressPointer r3
    //     0x1278428: add             x3, x3, HEAP, lsl #32
    // 0x127842c: r4 = LoadClassIdInstr(r0)
    //     0x127842c: ldur            x4, [x0, #-1]
    //     0x1278430: ubfx            x4, x4, #0xc, #0x14
    // 0x1278434: stp             x3, x0, [SP]
    // 0x1278438: mov             x0, x4
    // 0x127843c: mov             lr, x0
    // 0x1278440: ldr             lr, [x21, lr, lsl #3]
    // 0x1278444: blr             lr
    // 0x1278448: tbnz            w0, #4, #0x127848c
    // 0x127844c: ldr             x1, [fp, #0x18]
    // 0x1278450: ldr             x0, [fp, #0x10]
    // 0x1278454: LoadField: r2 = r0->field_37
    //     0x1278454: ldur            w2, [x0, #0x37]
    // 0x1278458: DecompressPointer r2
    //     0x1278458: add             x2, x2, HEAP, lsl #32
    // 0x127845c: LoadField: r0 = r1->field_37
    //     0x127845c: ldur            w0, [x1, #0x37]
    // 0x1278460: DecompressPointer r0
    //     0x1278460: add             x0, x0, HEAP, lsl #32
    // 0x1278464: r1 = LoadClassIdInstr(r2)
    //     0x1278464: ldur            x1, [x2, #-1]
    //     0x1278468: ubfx            x1, x1, #0xc, #0x14
    // 0x127846c: stp             x0, x2, [SP]
    // 0x1278470: mov             x0, x1
    // 0x1278474: mov             lr, x0
    // 0x1278478: ldr             lr, [x21, lr, lsl #3]
    // 0x127847c: blr             lr
    // 0x1278480: tbnz            w0, #4, #0x127848c
    // 0x1278484: r0 = true
    //     0x1278484: add             x0, NULL, #0x20  ; true
    // 0x1278488: b               #0x1278490
    // 0x127848c: r0 = false
    //     0x127848c: add             x0, NULL, #0x30  ; false
    // 0x1278490: LeaveFrame
    //     0x1278490: mov             SP, fp
    //     0x1278494: ldp             fp, lr, [SP], #0x10
    // 0x1278498: ret
    //     0x1278498: ret             
    // 0x127849c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x127849c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12784a0: b               #0x1278348
  }
}
