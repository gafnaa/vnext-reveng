// lib: , url: package:flutter/src/material/text_selection.dart

// class id: 1048963, size: 0x8
class :: {

  static late final TextSelectionControls materialTextSelectionHandleControls; // offset: 0x7b8

  static TextSelectionControls materialTextSelectionHandleControls() {
    // ** addr: 0xd4a740, size: 0x18
    // 0xd4a740: EnterFrame
    //     0xd4a740: stp             fp, lr, [SP, #-0x10]!
    //     0xd4a744: mov             fp, SP
    // 0xd4a748: r0 = MaterialTextSelectionHandleControls()
    //     0xd4a748: bl              #0xd4a758  ; AllocateMaterialTextSelectionHandleControlsStub -> MaterialTextSelectionHandleControls (size=0x8)
    // 0xd4a74c: LeaveFrame
    //     0xd4a74c: mov             SP, fp
    //     0xd4a750: ldp             fp, lr, [SP], #0x10
    // 0xd4a754: ret
    //     0xd4a754: ret             
  }
}

// class id: 3284, size: 0x8, field offset: 0x8
abstract class MaterialTextSelectionControls extends TextSelectionControls {

  _ buildHandle(/* No info */) {
    // ** addr: 0x12e3d58, size: 0x208
    // 0x12e3d58: EnterFrame
    //     0x12e3d58: stp             fp, lr, [SP, #-0x10]!
    //     0x12e3d5c: mov             fp, SP
    // 0x12e3d60: AllocStack(0x30)
    //     0x12e3d60: sub             SP, SP, #0x30
    // 0x12e3d64: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */)
    //     0x12e3d64: mov             x0, x2
    //     0x12e3d68: stur            x2, [fp, #-8]
    //     0x12e3d6c: stur            x3, [fp, #-0x10]
    //     0x12e3d70: stur            x5, [fp, #-0x18]
    // 0x12e3d74: CheckStackOverflow
    //     0x12e3d74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e3d78: cmp             SP, x16
    //     0x12e3d7c: b.ls            #0x12e3f58
    // 0x12e3d80: mov             x1, x0
    // 0x12e3d84: r0 = of()
    //     0x12e3d84: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x12e3d88: ldur            x1, [fp, #-8]
    // 0x12e3d8c: stur            x0, [fp, #-8]
    // 0x12e3d90: r0 = of()
    //     0x12e3d90: bl              #0xccc478  ; [package:flutter/src/material/text_selection_theme.dart] TextSelectionTheme::of
    // 0x12e3d94: ldur            x0, [fp, #-8]
    // 0x12e3d98: LoadField: r1 = r0->field_3f
    //     0x12e3d98: ldur            w1, [x0, #0x3f]
    // 0x12e3d9c: DecompressPointer r1
    //     0x12e3d9c: add             x1, x1, HEAP, lsl #32
    // 0x12e3da0: LoadField: r0 = r1->field_b
    //     0x12e3da0: ldur            w0, [x1, #0xb]
    // 0x12e3da4: DecompressPointer r0
    //     0x12e3da4: add             x0, x0, HEAP, lsl #32
    // 0x12e3da8: stur            x0, [fp, #-8]
    // 0x12e3dac: r0 = _TextSelectionHandlePainter()
    //     0x12e3dac: bl              #0x12e3f60  ; Allocate_TextSelectionHandlePainterStub -> _TextSelectionHandlePainter (size=0x10)
    // 0x12e3db0: mov             x1, x0
    // 0x12e3db4: ldur            x0, [fp, #-8]
    // 0x12e3db8: stur            x1, [fp, #-0x20]
    // 0x12e3dbc: StoreField: r1->field_b = r0
    //     0x12e3dbc: stur            w0, [x1, #0xb]
    // 0x12e3dc0: r0 = GestureDetector()
    //     0x12e3dc0: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x12e3dc4: stur            x0, [fp, #-8]
    // 0x12e3dc8: ldur            x16, [fp, #-0x18]
    // 0x12e3dcc: r30 = Instance_HitTestBehavior
    //     0x12e3dcc: add             lr, PP, #0x15, lsl #12  ; [pp+0x15508] Obj!HitTestBehavior@12c43e1
    //     0x12e3dd0: ldr             lr, [lr, #0x508]
    // 0x12e3dd4: stp             lr, x16, [SP]
    // 0x12e3dd8: mov             x1, x0
    // 0x12e3ddc: r4 = const [0, 0x3, 0x2, 0x1, behavior, 0x2, onTap, 0x1, null]
    //     0x12e3ddc: add             x4, PP, #0x98, lsl #12  ; [pp+0x98e68] List(9) [0, 0x3, 0x2, 0x1, "behavior", 0x2, "onTap", 0x1, Null]
    //     0x12e3de0: ldr             x4, [x4, #0xe68]
    // 0x12e3de4: r0 = GestureDetector()
    //     0x12e3de4: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x12e3de8: r0 = CustomPaint()
    //     0x12e3de8: bl              #0xd0a594  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x12e3dec: mov             x1, x0
    // 0x12e3df0: ldur            x0, [fp, #-0x20]
    // 0x12e3df4: stur            x1, [fp, #-0x18]
    // 0x12e3df8: StoreField: r1->field_f = r0
    //     0x12e3df8: stur            w0, [x1, #0xf]
    // 0x12e3dfc: r0 = Instance_Size
    //     0x12e3dfc: ldr             x0, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0x12e3e00: ArrayStore: r1[0] = r0  ; List_4
    //     0x12e3e00: stur            w0, [x1, #0x17]
    // 0x12e3e04: r0 = false
    //     0x12e3e04: add             x0, NULL, #0x30  ; false
    // 0x12e3e08: StoreField: r1->field_1b = r0
    //     0x12e3e08: stur            w0, [x1, #0x1b]
    // 0x12e3e0c: StoreField: r1->field_1f = r0
    //     0x12e3e0c: stur            w0, [x1, #0x1f]
    // 0x12e3e10: ldur            x0, [fp, #-8]
    // 0x12e3e14: StoreField: r1->field_b = r0
    //     0x12e3e14: stur            w0, [x1, #0xb]
    // 0x12e3e18: r0 = SizedBox()
    //     0x12e3e18: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x12e3e1c: mov             x1, x0
    // 0x12e3e20: r0 = 22.000000
    //     0x12e3e20: add             x0, PP, #0x7b, lsl #12  ; [pp+0x7b568] 22
    //     0x12e3e24: ldr             x0, [x0, #0x568]
    // 0x12e3e28: stur            x1, [fp, #-8]
    // 0x12e3e2c: StoreField: r1->field_f = r0
    //     0x12e3e2c: stur            w0, [x1, #0xf]
    // 0x12e3e30: StoreField: r1->field_13 = r0
    //     0x12e3e30: stur            w0, [x1, #0x13]
    // 0x12e3e34: ldur            x0, [fp, #-0x18]
    // 0x12e3e38: StoreField: r1->field_b = r0
    //     0x12e3e38: stur            w0, [x1, #0xb]
    // 0x12e3e3c: ldur            x0, [fp, #-0x10]
    // 0x12e3e40: LoadField: r2 = r0->field_7
    //     0x12e3e40: ldur            x2, [x0, #7]
    // 0x12e3e44: cmp             x2, #1
    // 0x12e3e48: b.gt            #0x12e3ed0
    // 0x12e3e4c: cmp             x2, #0
    // 0x12e3e50: b.gt            #0x12e3ec8
    // 0x12e3e54: r0 = Transform()
    //     0x12e3e54: bl              #0xd30150  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x12e3e58: mov             x1, x0
    // 0x12e3e5c: r0 = Instance_Alignment
    //     0x12e3e5c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0x12e3e60: ldr             x0, [x0, #0xb80]
    // 0x12e3e64: stur            x1, [fp, #-0x10]
    // 0x12e3e68: ArrayStore: r1[0] = r0  ; List_4
    //     0x12e3e68: stur            w0, [x1, #0x17]
    // 0x12e3e6c: r2 = true
    //     0x12e3e6c: add             x2, NULL, #0x20  ; true
    // 0x12e3e70: StoreField: r1->field_1b = r2
    //     0x12e3e70: stur            w2, [x1, #0x1b]
    // 0x12e3e74: d0 = 1.570796
    //     0x12e3e74: add             x17, PP, #0x95, lsl #12  ; [pp+0x95ed8] IMM: double(1.5707963267948966) from 0x3ff921fb54442d18
    //     0x12e3e78: ldr             d0, [x17, #0xed8]
    // 0x12e3e7c: r0 = _computeRotation()
    //     0x12e3e7c: bl              #0xd31970  ; [package:flutter/src/widgets/basic.dart] Transform::_computeRotation
    // 0x12e3e80: ldur            x1, [fp, #-0x10]
    // 0x12e3e84: StoreField: r1->field_f = r0
    //     0x12e3e84: stur            w0, [x1, #0xf]
    //     0x12e3e88: ldurb           w16, [x1, #-1]
    //     0x12e3e8c: ldurb           w17, [x0, #-1]
    //     0x12e3e90: and             x16, x17, x16, lsr #2
    //     0x12e3e94: tst             x16, HEAP, lsr #32
    //     0x12e3e98: b.eq            #0x12e3ea0
    //     0x12e3e9c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12e3ea0: ldur            x0, [fp, #-8]
    // 0x12e3ea4: StoreField: r1->field_b = r0
    //     0x12e3ea4: stur            w0, [x1, #0xb]
    //     0x12e3ea8: ldurb           w16, [x1, #-1]
    //     0x12e3eac: ldurb           w17, [x0, #-1]
    //     0x12e3eb0: and             x16, x17, x16, lsr #2
    //     0x12e3eb4: tst             x16, HEAP, lsr #32
    //     0x12e3eb8: b.eq            #0x12e3ec0
    //     0x12e3ebc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12e3ec0: mov             x0, x1
    // 0x12e3ec4: b               #0x12e3f4c
    // 0x12e3ec8: ldur            x0, [fp, #-8]
    // 0x12e3ecc: b               #0x12e3f4c
    // 0x12e3ed0: r2 = true
    //     0x12e3ed0: add             x2, NULL, #0x20  ; true
    // 0x12e3ed4: r0 = Instance_Alignment
    //     0x12e3ed4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0x12e3ed8: ldr             x0, [x0, #0xb80]
    // 0x12e3edc: r0 = Transform()
    //     0x12e3edc: bl              #0xd30150  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x12e3ee0: mov             x1, x0
    // 0x12e3ee4: r0 = Instance_Alignment
    //     0x12e3ee4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0x12e3ee8: ldr             x0, [x0, #0xb80]
    // 0x12e3eec: stur            x1, [fp, #-0x10]
    // 0x12e3ef0: ArrayStore: r1[0] = r0  ; List_4
    //     0x12e3ef0: stur            w0, [x1, #0x17]
    // 0x12e3ef4: r0 = true
    //     0x12e3ef4: add             x0, NULL, #0x20  ; true
    // 0x12e3ef8: StoreField: r1->field_1b = r0
    //     0x12e3ef8: stur            w0, [x1, #0x1b]
    // 0x12e3efc: d0 = 0.785398
    //     0x12e3efc: add             x17, PP, #0x98, lsl #12  ; [pp+0x98e70] IMM: double(0.7853981633974483) from 0x3fe921fb54442d18
    //     0x12e3f00: ldr             d0, [x17, #0xe70]
    // 0x12e3f04: r0 = _computeRotation()
    //     0x12e3f04: bl              #0xd31970  ; [package:flutter/src/widgets/basic.dart] Transform::_computeRotation
    // 0x12e3f08: ldur            x1, [fp, #-0x10]
    // 0x12e3f0c: StoreField: r1->field_f = r0
    //     0x12e3f0c: stur            w0, [x1, #0xf]
    //     0x12e3f10: ldurb           w16, [x1, #-1]
    //     0x12e3f14: ldurb           w17, [x0, #-1]
    //     0x12e3f18: and             x16, x17, x16, lsr #2
    //     0x12e3f1c: tst             x16, HEAP, lsr #32
    //     0x12e3f20: b.eq            #0x12e3f28
    //     0x12e3f24: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12e3f28: ldur            x0, [fp, #-8]
    // 0x12e3f2c: StoreField: r1->field_b = r0
    //     0x12e3f2c: stur            w0, [x1, #0xb]
    //     0x12e3f30: ldurb           w16, [x1, #-1]
    //     0x12e3f34: ldurb           w17, [x0, #-1]
    //     0x12e3f38: and             x16, x17, x16, lsr #2
    //     0x12e3f3c: tst             x16, HEAP, lsr #32
    //     0x12e3f40: b.eq            #0x12e3f48
    //     0x12e3f44: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12e3f48: mov             x0, x1
    // 0x12e3f4c: LeaveFrame
    //     0x12e3f4c: mov             SP, fp
    //     0x12e3f50: ldp             fp, lr, [SP], #0x10
    // 0x12e3f54: ret
    //     0x12e3f54: ret             
    // 0x12e3f58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e3f58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e3f5c: b               #0x12e3d80
  }
  _ getHandleSize(/* No info */) {
    // ** addr: 0x12f5798, size: 0xc
    // 0x12f5798: r0 = Instance_Size
    //     0x12f5798: add             x0, PP, #0x98, lsl #12  ; [pp+0x98e80] Obj!Size@12a7a71
    //     0x12f579c: ldr             x0, [x0, #0xe80]
    // 0x12f57a0: ret
    //     0x12f57a0: ret             
  }
  _ getHandleAnchor(/* No info */) {
    // ** addr: 0x12f57a4, size: 0x34
    // 0x12f57a4: LoadField: r1 = r2->field_7
    //     0x12f57a4: ldur            x1, [x2, #7]
    // 0x12f57a8: cmp             x1, #1
    // 0x12f57ac: b.gt            #0x12f57cc
    // 0x12f57b0: cmp             x1, #0
    // 0x12f57b4: b.gt            #0x12f57c4
    // 0x12f57b8: r0 = Instance_Offset
    //     0x12f57b8: add             x0, PP, #0x98, lsl #12  ; [pp+0x98e58] Obj!Offset@12aa191
    //     0x12f57bc: ldr             x0, [x0, #0xe58]
    // 0x12f57c0: b               #0x12f57d4
    // 0x12f57c4: r0 = Instance_Offset
    //     0x12f57c4: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x12f57c8: b               #0x12f57d4
    // 0x12f57cc: r0 = Instance_Offset
    //     0x12f57cc: add             x0, PP, #0x98, lsl #12  ; [pp+0x98e60] Obj!Offset@12aa171
    //     0x12f57d0: ldr             x0, [x0, #0xe60]
    // 0x12f57d4: ret
    //     0x12f57d4: ret             
  }
}

// class id: 3286, size: 0x8, field offset: 0x8
class MaterialTextSelectionHandleControls extends _MixinApplication115&MaterialTextSelectionControls&TextSelectionHandleControls {
}

// class id: 4330, size: 0x10, field offset: 0xc
class _TextSelectionHandlePainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0xb7a70c, size: 0x28c
    // 0xb7a70c: EnterFrame
    //     0xb7a70c: stp             fp, lr, [SP, #-0x10]!
    //     0xb7a710: mov             fp, SP
    // 0xb7a714: AllocStack(0x68)
    //     0xb7a714: sub             SP, SP, #0x68
    // 0xb7a718: SetupParameters(_TextSelectionHandlePainter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb7a718: stur            x1, [fp, #-8]
    //     0xb7a71c: stur            x2, [fp, #-0x10]
    //     0xb7a720: stur            x3, [fp, #-0x18]
    // 0xb7a724: CheckStackOverflow
    //     0xb7a724: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb7a728: cmp             SP, x16
    //     0xb7a72c: b.ls            #0xb7a980
    // 0xb7a730: r16 = 136
    //     0xb7a730: mov             x16, #0x88
    // 0xb7a734: stp             x16, NULL, [SP]
    // 0xb7a738: r0 = ByteData()
    //     0xb7a738: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb7a73c: stur            x0, [fp, #-0x20]
    // 0xb7a740: r0 = Paint()
    //     0xb7a740: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb7a744: ldur            x5, [fp, #-0x20]
    // 0xb7a748: stur            x0, [fp, #-0x28]
    // 0xb7a74c: StoreField: r0->field_7 = r5
    //     0xb7a74c: stur            w5, [x0, #7]
    // 0xb7a750: ldur            x1, [fp, #-8]
    // 0xb7a754: LoadField: r2 = r1->field_b
    //     0xb7a754: ldur            w2, [x1, #0xb]
    // 0xb7a758: DecompressPointer r2
    //     0xb7a758: add             x2, x2, HEAP, lsl #32
    // 0xb7a75c: mov             x1, x0
    // 0xb7a760: r0 = color=()
    //     0xb7a760: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb7a764: ldur            x0, [fp, #-0x18]
    // 0xb7a768: LoadField: d0 = r0->field_7
    //     0xb7a768: ldur            d0, [x0, #7]
    // 0xb7a76c: d1 = 2.000000
    //     0xb7a76c: fmov            d1, #2.00000000
    // 0xb7a770: fdiv            d2, d0, d1
    // 0xb7a774: stur            d2, [fp, #-0x38]
    // 0xb7a778: r0 = Offset()
    //     0xb7a778: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb7a77c: ldur            d0, [fp, #-0x38]
    // 0xb7a780: stur            x0, [fp, #-8]
    // 0xb7a784: StoreField: r0->field_7 = d0
    //     0xb7a784: stur            d0, [x0, #7]
    // 0xb7a788: StoreField: r0->field_f = d0
    //     0xb7a788: stur            d0, [x0, #0xf]
    // 0xb7a78c: d1 = 2.000000
    //     0xb7a78c: fmov            d1, #2.00000000
    // 0xb7a790: fmul            d2, d0, d1
    // 0xb7a794: stur            d2, [fp, #-0x40]
    // 0xb7a798: r0 = Rect()
    //     0xb7a798: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xb7a79c: mov             x1, x0
    // 0xb7a7a0: ldur            x2, [fp, #-8]
    // 0xb7a7a4: ldur            d0, [fp, #-0x40]
    // 0xb7a7a8: ldur            d1, [fp, #-0x40]
    // 0xb7a7ac: stur            x0, [fp, #-8]
    // 0xb7a7b0: r0 = Rect.fromCenter()
    //     0xb7a7b0: bl              #0x86ddc8  ; [dart:ui] Rect::Rect.fromCenter
    // 0xb7a7b4: ldur            d0, [fp, #-0x38]
    // 0xb7a7b8: d1 = 0.000000
    //     0xb7a7b8: eor             v1.16b, v1.16b, v1.16b
    // 0xb7a7bc: fadd            d3, d0, d1
    // 0xb7a7c0: stur            d3, [fp, #-0x40]
    // 0xb7a7c4: r0 = _NativePath()
    //     0xb7a7c4: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xb7a7c8: mov             x1, x0
    // 0xb7a7cc: stur            x0, [fp, #-0x18]
    // 0xb7a7d0: r0 = __constructor$Method$FfiNative()
    //     0xb7a7d0: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xb7a7d4: ldur            x0, [fp, #-8]
    // 0xb7a7d8: LoadField: d0 = r0->field_7
    //     0xb7a7d8: ldur            d0, [x0, #7]
    // 0xb7a7dc: stur            d0, [fp, #-0x58]
    // 0xb7a7e0: LoadField: d1 = r0->field_f
    //     0xb7a7e0: ldur            d1, [x0, #0xf]
    // 0xb7a7e4: stur            d1, [fp, #-0x50]
    // 0xb7a7e8: ArrayLoad: d2 = r0[0]  ; List_8
    //     0xb7a7e8: ldur            d2, [x0, #0x17]
    // 0xb7a7ec: stur            d2, [fp, #-0x48]
    // 0xb7a7f0: LoadField: d3 = r0->field_1f
    //     0xb7a7f0: ldur            d3, [x0, #0x1f]
    // 0xb7a7f4: ldur            x0, [fp, #-0x18]
    // 0xb7a7f8: stur            d3, [fp, #-0x38]
    // 0xb7a7fc: LoadField: r1 = r0->field_7
    //     0xb7a7fc: ldur            w1, [x0, #7]
    // 0xb7a800: DecompressPointer r1
    //     0xb7a800: add             x1, x1, HEAP, lsl #32
    // 0xb7a804: cmp             w1, NULL
    // 0xb7a808: b.eq            #0xb7a988
    // 0xb7a80c: LoadField: r2 = r1->field_7
    //     0xb7a80c: ldur            x2, [x1, #7]
    // 0xb7a810: ldr             x1, [x2]
    // 0xb7a814: cbz             x1, #0xb7a950
    // 0xb7a818: mov             x2, x1
    // 0xb7a81c: stur            x2, [fp, #-0x30]
    // 0xb7a820: r1 = <Never>
    //     0xb7a820: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb7a824: r0 = Pointer()
    //     0xb7a824: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb7a828: mov             x1, x0
    // 0xb7a82c: ldur            x0, [fp, #-0x30]
    // 0xb7a830: StoreField: r1->field_7 = r0
    //     0xb7a830: stur            x0, [x1, #7]
    // 0xb7a834: ldur            d0, [fp, #-0x58]
    // 0xb7a838: ldur            d1, [fp, #-0x50]
    // 0xb7a83c: ldur            d2, [fp, #-0x48]
    // 0xb7a840: ldur            d3, [fp, #-0x38]
    // 0xb7a844: r0 = __addOval$Method$FfiNative()
    //     0xb7a844: bl              #0xb6b218  ; [dart:ui] _NativePath::__addOval$Method$FfiNative
    // 0xb7a848: ldur            x0, [fp, #-0x18]
    // 0xb7a84c: LoadField: r1 = r0->field_7
    //     0xb7a84c: ldur            w1, [x0, #7]
    // 0xb7a850: DecompressPointer r1
    //     0xb7a850: add             x1, x1, HEAP, lsl #32
    // 0xb7a854: cmp             w1, NULL
    // 0xb7a858: b.eq            #0xb7a98c
    // 0xb7a85c: LoadField: r2 = r1->field_7
    //     0xb7a85c: ldur            x2, [x1, #7]
    // 0xb7a860: ldr             x1, [x2]
    // 0xb7a864: cbz             x1, #0xb7a960
    // 0xb7a868: ldur            x3, [fp, #-0x10]
    // 0xb7a86c: ldur            x2, [fp, #-0x28]
    // 0xb7a870: mov             x4, x1
    // 0xb7a874: stur            x4, [fp, #-0x30]
    // 0xb7a878: r1 = <Never>
    //     0xb7a878: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb7a87c: r0 = Pointer()
    //     0xb7a87c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb7a880: mov             x1, x0
    // 0xb7a884: ldur            x0, [fp, #-0x30]
    // 0xb7a888: StoreField: r1->field_7 = r0
    //     0xb7a888: stur            x0, [x1, #7]
    // 0xb7a88c: ldur            d2, [fp, #-0x40]
    // 0xb7a890: ldur            d3, [fp, #-0x40]
    // 0xb7a894: d0 = 0.000000
    //     0xb7a894: eor             v0.16b, v0.16b, v0.16b
    // 0xb7a898: d1 = 0.000000
    //     0xb7a898: eor             v1.16b, v1.16b, v1.16b
    // 0xb7a89c: r0 = __addRect$Method$FfiNative()
    //     0xb7a89c: bl              #0xb74e24  ; [dart:ui] _NativePath::__addRect$Method$FfiNative
    // 0xb7a8a0: ldur            x0, [fp, #-0x28]
    // 0xb7a8a4: LoadField: r3 = r0->field_b
    //     0xb7a8a4: ldur            w3, [x0, #0xb]
    // 0xb7a8a8: DecompressPointer r3
    //     0xb7a8a8: add             x3, x3, HEAP, lsl #32
    // 0xb7a8ac: ldur            x0, [fp, #-0x10]
    // 0xb7a8b0: stur            x3, [fp, #-8]
    // 0xb7a8b4: LoadField: r1 = r0->field_7
    //     0xb7a8b4: ldur            w1, [x0, #7]
    // 0xb7a8b8: DecompressPointer r1
    //     0xb7a8b8: add             x1, x1, HEAP, lsl #32
    // 0xb7a8bc: cmp             w1, NULL
    // 0xb7a8c0: b.eq            #0xb7a990
    // 0xb7a8c4: LoadField: r2 = r1->field_7
    //     0xb7a8c4: ldur            x2, [x1, #7]
    // 0xb7a8c8: ldr             x1, [x2]
    // 0xb7a8cc: cbz             x1, #0xb7a970
    // 0xb7a8d0: ldur            x2, [fp, #-0x18]
    // 0xb7a8d4: mov             x4, x1
    // 0xb7a8d8: stur            x4, [fp, #-0x30]
    // 0xb7a8dc: r1 = <Never>
    //     0xb7a8dc: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb7a8e0: r0 = Pointer()
    //     0xb7a8e0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb7a8e4: mov             x2, x0
    // 0xb7a8e8: ldur            x0, [fp, #-0x30]
    // 0xb7a8ec: stur            x2, [fp, #-0x28]
    // 0xb7a8f0: StoreField: r2->field_7 = r0
    //     0xb7a8f0: stur            x0, [x2, #7]
    // 0xb7a8f4: ldur            x0, [fp, #-0x18]
    // 0xb7a8f8: LoadField: r1 = r0->field_7
    //     0xb7a8f8: ldur            w1, [x0, #7]
    // 0xb7a8fc: DecompressPointer r1
    //     0xb7a8fc: add             x1, x1, HEAP, lsl #32
    // 0xb7a900: cmp             w1, NULL
    // 0xb7a904: b.eq            #0xb7a994
    // 0xb7a908: LoadField: r3 = r1->field_7
    //     0xb7a908: ldur            x3, [x1, #7]
    // 0xb7a90c: ldr             x1, [x3]
    // 0xb7a910: mov             x3, x1
    // 0xb7a914: stur            x3, [fp, #-0x30]
    // 0xb7a918: r1 = <Never>
    //     0xb7a918: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb7a91c: r0 = Pointer()
    //     0xb7a91c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb7a920: mov             x1, x0
    // 0xb7a924: ldur            x0, [fp, #-0x30]
    // 0xb7a928: StoreField: r1->field_7 = r0
    //     0xb7a928: stur            x0, [x1, #7]
    // 0xb7a92c: mov             x2, x1
    // 0xb7a930: ldur            x1, [fp, #-0x28]
    // 0xb7a934: ldur            x3, [fp, #-8]
    // 0xb7a938: ldur            x5, [fp, #-0x20]
    // 0xb7a93c: r0 = __drawPath$Method$FfiNative()
    //     0xb7a93c: bl              #0xb69a00  ; [dart:ui] _NativeCanvas::__drawPath$Method$FfiNative
    // 0xb7a940: r0 = Null
    //     0xb7a940: mov             x0, NULL
    // 0xb7a944: LeaveFrame
    //     0xb7a944: mov             SP, fp
    //     0xb7a948: ldp             fp, lr, [SP], #0x10
    // 0xb7a94c: ret
    //     0xb7a94c: ret             
    // 0xb7a950: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb7a950: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb7a954: str             x16, [SP]
    // 0xb7a958: r0 = _throwNew()
    //     0xb7a958: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb7a95c: brk             #0
    // 0xb7a960: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb7a960: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb7a964: str             x16, [SP]
    // 0xb7a968: r0 = _throwNew()
    //     0xb7a968: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb7a96c: brk             #0
    // 0xb7a970: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb7a970: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb7a974: str             x16, [SP]
    // 0xb7a978: r0 = _throwNew()
    //     0xb7a978: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb7a97c: brk             #0
    // 0xb7a980: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7a980: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7a984: b               #0xb7a730
    // 0xb7a988: r0 = NullErrorSharedWithFPURegs()
    //     0xb7a988: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb7a98c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb7a98c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb7a990: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb7a990: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb7a994: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb7a994: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xb93d50, size: 0xb0
    // 0xb93d50: EnterFrame
    //     0xb93d50: stp             fp, lr, [SP, #-0x10]!
    //     0xb93d54: mov             fp, SP
    // 0xb93d58: AllocStack(0x20)
    //     0xb93d58: sub             SP, SP, #0x20
    // 0xb93d5c: SetupParameters(_TextSelectionHandlePainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xb93d5c: mov             x4, x1
    //     0xb93d60: mov             x3, x2
    //     0xb93d64: stur            x1, [fp, #-8]
    //     0xb93d68: stur            x2, [fp, #-0x10]
    // 0xb93d6c: CheckStackOverflow
    //     0xb93d6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb93d70: cmp             SP, x16
    //     0xb93d74: b.ls            #0xb93df8
    // 0xb93d78: mov             x0, x3
    // 0xb93d7c: r2 = Null
    //     0xb93d7c: mov             x2, NULL
    // 0xb93d80: r1 = Null
    //     0xb93d80: mov             x1, NULL
    // 0xb93d84: r4 = 60
    //     0xb93d84: mov             x4, #0x3c
    // 0xb93d88: branchIfSmi(r0, 0xb93d94)
    //     0xb93d88: tbz             w0, #0, #0xb93d94
    // 0xb93d8c: r4 = LoadClassIdInstr(r0)
    //     0xb93d8c: ldur            x4, [x0, #-1]
    //     0xb93d90: ubfx            x4, x4, #0xc, #0x14
    // 0xb93d94: r17 = 4330
    //     0xb93d94: mov             x17, #0x10ea
    // 0xb93d98: cmp             x4, x17
    // 0xb93d9c: b.eq            #0xb93db4
    // 0xb93da0: r8 = _TextSelectionHandlePainter
    //     0xb93da0: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3530] Type: _TextSelectionHandlePainter
    //     0xb93da4: ldr             x8, [x8, #0x530]
    // 0xb93da8: r3 = Null
    //     0xb93da8: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3538] Null
    //     0xb93dac: ldr             x3, [x3, #0x538]
    // 0xb93db0: r0 = DefaultTypeTest()
    //     0xb93db0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb93db4: ldur            x0, [fp, #-8]
    // 0xb93db8: LoadField: r1 = r0->field_b
    //     0xb93db8: ldur            w1, [x0, #0xb]
    // 0xb93dbc: DecompressPointer r1
    //     0xb93dbc: add             x1, x1, HEAP, lsl #32
    // 0xb93dc0: ldur            x0, [fp, #-0x10]
    // 0xb93dc4: LoadField: r2 = r0->field_b
    //     0xb93dc4: ldur            w2, [x0, #0xb]
    // 0xb93dc8: DecompressPointer r2
    //     0xb93dc8: add             x2, x2, HEAP, lsl #32
    // 0xb93dcc: r0 = LoadClassIdInstr(r1)
    //     0xb93dcc: ldur            x0, [x1, #-1]
    //     0xb93dd0: ubfx            x0, x0, #0xc, #0x14
    // 0xb93dd4: stp             x2, x1, [SP]
    // 0xb93dd8: mov             lr, x0
    // 0xb93ddc: ldr             lr, [x21, lr, lsl #3]
    // 0xb93de0: blr             lr
    // 0xb93de4: eor             x1, x0, #0x10
    // 0xb93de8: mov             x0, x1
    // 0xb93dec: LeaveFrame
    //     0xb93dec: mov             SP, fp
    //     0xb93df0: ldp             fp, lr, [SP], #0x10
    // 0xb93df4: ret
    //     0xb93df4: ret             
    // 0xb93df8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb93df8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb93dfc: b               #0xb93d78
  }
}
