// lib: , url: package:flutter/src/material/menu_bar_theme.dart

// class id: 1048915, size: 0x8
class :: {
}

// class id: 5140, size: 0x10, field offset: 0x10
//   const constructor, 
class MenuBarThemeData extends MenuThemeData {

  static _ lerp(/* No info */) {
    // ** addr: 0x1166a90, size: 0x6c
    // 0x1166a90: EnterFrame
    //     0x1166a90: stp             fp, lr, [SP, #-0x10]!
    //     0x1166a94: mov             fp, SP
    // 0x1166a98: AllocStack(0x8)
    //     0x1166a98: sub             SP, SP, #8
    // 0x1166a9c: SetupParameters(dynamic _ /* r1 => r0 */)
    //     0x1166a9c: mov             x0, x1
    // 0x1166aa0: CheckStackOverflow
    //     0x1166aa0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1166aa4: cmp             SP, x16
    //     0x1166aa8: b.ls            #0x1166af4
    // 0x1166aac: cmp             w0, w2
    // 0x1166ab0: b.ne            #0x1166ac0
    // 0x1166ab4: LeaveFrame
    //     0x1166ab4: mov             SP, fp
    //     0x1166ab8: ldp             fp, lr, [SP], #0x10
    // 0x1166abc: ret
    //     0x1166abc: ret             
    // 0x1166ac0: LoadField: r1 = r0->field_7
    //     0x1166ac0: ldur            w1, [x0, #7]
    // 0x1166ac4: DecompressPointer r1
    //     0x1166ac4: add             x1, x1, HEAP, lsl #32
    // 0x1166ac8: LoadField: r0 = r2->field_7
    //     0x1166ac8: ldur            w0, [x2, #7]
    // 0x1166acc: DecompressPointer r0
    //     0x1166acc: add             x0, x0, HEAP, lsl #32
    // 0x1166ad0: mov             x2, x0
    // 0x1166ad4: r0 = lerp()
    //     0x1166ad4: bl              #0x11669bc  ; [package:flutter/src/material/menu_style.dart] MenuStyle::lerp
    // 0x1166ad8: stur            x0, [fp, #-8]
    // 0x1166adc: r0 = MenuBarThemeData()
    //     0x1166adc: bl              #0x1166afc  ; AllocateMenuBarThemeDataStub -> MenuBarThemeData (size=0x10)
    // 0x1166ae0: ldur            x1, [fp, #-8]
    // 0x1166ae4: StoreField: r0->field_7 = r1
    //     0x1166ae4: stur            w1, [x0, #7]
    // 0x1166ae8: LeaveFrame
    //     0x1166ae8: mov             SP, fp
    //     0x1166aec: ldp             fp, lr, [SP], #0x10
    // 0x1166af0: ret
    //     0x1166af0: ret             
    // 0x1166af4: r0 = StackOverflowSharedWithFPURegs()
    //     0x1166af4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1166af8: b               #0x1166aac
  }
}
