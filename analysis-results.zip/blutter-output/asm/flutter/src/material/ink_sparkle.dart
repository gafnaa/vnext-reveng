// lib: , url: package:flutter/src/material/ink_sparkle.dart

// class id: 1048903, size: 0x8
class :: {
}

// class id: 3034, size: 0xc, field offset: 0x8
//   const constructor, 
class _InkSparkleFactory extends InteractiveInkFeatureFactory {

  static void initializeShader() {
    // ** addr: 0xd24f74, size: 0x80
    // 0xd24f74: EnterFrame
    //     0xd24f74: stp             fp, lr, [SP, #-0x10]!
    //     0xd24f78: mov             fp, SP
    // 0xd24f7c: AllocStack(0x20)
    //     0xd24f7c: sub             SP, SP, #0x20
    // 0xd24f80: CheckStackOverflow
    //     0xd24f80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd24f84: cmp             SP, x16
    //     0xd24f88: b.ls            #0xd24fec
    // 0xd24f8c: r0 = LoadStaticField(0xcac)
    //     0xd24f8c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd24f90: ldr             x0, [x0, #0x1958]
    // 0xd24f94: tbz             w0, #4, #0xd24fdc
    // 0xd24f98: r1 = "shaders/ink_sparkle.frag"
    //     0xd24f98: add             x1, PP, #0x99, lsl #12  ; [pp+0x99610] "shaders/ink_sparkle.frag"
    //     0xd24f9c: ldr             x1, [x1, #0x610]
    // 0xd24fa0: r0 = fromAsset()
    //     0xd24fa0: bl              #0xd24ff4  ; [dart:ui] FragmentProgram::fromAsset
    // 0xd24fa4: r1 = Function '<anonymous closure>': static.
    //     0xd24fa4: add             x1, PP, #0x99, lsl #12  ; [pp+0x99618] AnonymousClosure: static (0xd25354), in [package:flutter/src/material/ink_sparkle.dart] _InkSparkleFactory::initializeShader (0xd24f74)
    //     0xd24fa8: ldr             x1, [x1, #0x618]
    // 0xd24fac: r2 = Null
    //     0xd24fac: mov             x2, NULL
    // 0xd24fb0: stur            x0, [fp, #-8]
    // 0xd24fb4: r0 = AllocateClosure()
    //     0xd24fb4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd24fb8: r16 = <Null?>
    //     0xd24fb8: ldr             x16, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0xd24fbc: ldur            lr, [fp, #-8]
    // 0xd24fc0: stp             lr, x16, [SP, #8]
    // 0xd24fc4: str             x0, [SP]
    // 0xd24fc8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd24fc8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd24fcc: r0 = then()
    //     0xd24fcc: bl              #0x1293070  ; [dart:async] _Future::then
    // 0xd24fd0: r2 = true
    //     0xd24fd0: add             x2, NULL, #0x20  ; true
    // 0xd24fd4: StoreStaticField(0xcac, r2)
    //     0xd24fd4: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0xd24fd8: str             x2, [x1, #0x1958]
    // 0xd24fdc: r0 = Null
    //     0xd24fdc: mov             x0, NULL
    // 0xd24fe0: LeaveFrame
    //     0xd24fe0: mov             SP, fp
    //     0xd24fe4: ldp             fp, lr, [SP], #0x10
    // 0xd24fe8: ret
    //     0xd24fe8: ret             
    // 0xd24fec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd24fec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd24ff0: b               #0xd24f8c
  }
  [closure] static Null <anonymous closure>(dynamic, FragmentProgram) {
    // ** addr: 0xd25354, size: 0x14
    // 0xd25354: ldr             x2, [SP]
    // 0xd25358: StoreStaticField(0xcb0, r2)
    //     0xd25358: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0xd2535c: str             x2, [x1, #0x1960]
    // 0xd25360: r0 = Null
    //     0xd25360: mov             x0, NULL
    // 0xd25364: ret
    //     0xd25364: ret             
  }
}

// class id: 3039, size: 0x58, field offset: 0x1c
class InkSparkle extends InteractiveInkFeature {

  late AnimationController _animationController; // offset: 0x1c
  late final FragmentShader _fragmentShader; // offset: 0x50
  late double _turbulenceSeed; // offset: 0x30
  late Animation<double> _radiusScale; // offset: 0x24
  late Animation<double> _alpha; // offset: 0x28
  late Animation<double> _sparkleAlpha; // offset: 0x2c
  late Animation<Vector2> _center; // offset: 0x20

  _ InkSparkle(/* No info */) {
    // ** addr: 0xd23dc8, size: 0xaa4
    // 0xd23dc8: EnterFrame
    //     0xd23dc8: stp             fp, lr, [SP, #-0x10]!
    //     0xd23dcc: mov             fp, SP
    // 0xd23dd0: AllocStack(0x40)
    //     0xd23dd0: sub             SP, SP, #0x40
    // 0xd23dd4: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0xd23dd8: r0 = false
    //     0xd23dd8: add             x0, NULL, #0x30  ; false
    // 0xd23ddc: mov             x8, x1
    // 0xd23de0: stur            x3, [fp, #-0x10]
    // 0xd23de4: mov             x16, x7
    // 0xd23de8: mov             x7, x3
    // 0xd23dec: mov             x3, x16
    // 0xd23df0: stur            x5, [fp, #-0x18]
    // 0xd23df4: mov             x16, x6
    // 0xd23df8: mov             x6, x5
    // 0xd23dfc: mov             x5, x16
    // 0xd23e00: stur            x1, [fp, #-8]
    // 0xd23e04: stur            x5, [fp, #-0x20]
    // 0xd23e08: stur            x3, [fp, #-0x28]
    // 0xd23e0c: CheckStackOverflow
    //     0xd23e0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd23e10: cmp             SP, x16
    //     0xd23e14: b.ls            #0xd247fc
    // 0xd23e18: StoreField: r8->field_1b = r4
    //     0xd23e18: stur            w4, [x8, #0x1b]
    // 0xd23e1c: StoreField: r8->field_1f = r4
    //     0xd23e1c: stur            w4, [x8, #0x1f]
    // 0xd23e20: StoreField: r8->field_23 = r4
    //     0xd23e20: stur            w4, [x8, #0x23]
    // 0xd23e24: StoreField: r8->field_27 = r4
    //     0xd23e24: stur            w4, [x8, #0x27]
    // 0xd23e28: StoreField: r8->field_2b = r4
    //     0xd23e28: stur            w4, [x8, #0x2b]
    // 0xd23e2c: StoreField: r8->field_2f = r4
    //     0xd23e2c: stur            w4, [x8, #0x2f]
    // 0xd23e30: StoreField: r8->field_4f = r4
    //     0xd23e30: stur            w4, [x8, #0x4f]
    // 0xd23e34: StoreField: r8->field_53 = r0
    //     0xd23e34: stur            w0, [x8, #0x53]
    // 0xd23e38: mov             x0, x7
    // 0xd23e3c: StoreField: r8->field_33 = r0
    //     0xd23e3c: stur            w0, [x8, #0x33]
    //     0xd23e40: ldurb           w16, [x8, #-1]
    //     0xd23e44: ldurb           w17, [x0, #-1]
    //     0xd23e48: and             x16, x17, x16, lsr #2
    //     0xd23e4c: tst             x16, HEAP, lsr #32
    //     0xd23e50: b.eq            #0xd23e58
    //     0xd23e54: bl              #0x13de074  ; WriteBarrierWrappersStub
    // 0xd23e58: ldr             x0, [fp, #0x30]
    // 0xd23e5c: StoreField: r8->field_37 = r0
    //     0xd23e5c: stur            w0, [x8, #0x37]
    //     0xd23e60: ldurb           w16, [x8, #-1]
    //     0xd23e64: ldurb           w17, [x0, #-1]
    //     0xd23e68: and             x16, x17, x16, lsr #2
    //     0xd23e6c: tst             x16, HEAP, lsr #32
    //     0xd23e70: b.eq            #0xd23e78
    //     0xd23e74: bl              #0x13de074  ; WriteBarrierWrappersStub
    // 0xd23e78: cmp             w2, NULL
    // 0xd23e7c: b.ne            #0xd23e8c
    // 0xd23e80: r0 = Instance_BorderRadius
    //     0xd23e80: add             x0, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0xd23e84: ldr             x0, [x0, #0x508]
    // 0xd23e88: b               #0xd23e90
    // 0xd23e8c: mov             x0, x2
    // 0xd23e90: ldr             x1, [fp, #0x28]
    // 0xd23e94: StoreField: r8->field_3b = r0
    //     0xd23e94: stur            w0, [x8, #0x3b]
    //     0xd23e98: ldurb           w16, [x8, #-1]
    //     0xd23e9c: ldurb           w17, [x0, #-1]
    //     0xd23ea0: and             x16, x17, x16, lsr #2
    //     0xd23ea4: tst             x16, HEAP, lsr #32
    //     0xd23ea8: b.eq            #0xd23eb0
    //     0xd23eac: bl              #0x13de074  ; WriteBarrierWrappersStub
    // 0xd23eb0: ldr             x0, [fp, #0x10]
    // 0xd23eb4: StoreField: r8->field_4b = r0
    //     0xd23eb4: stur            w0, [x8, #0x4b]
    //     0xd23eb8: ldurb           w16, [x8, #-1]
    //     0xd23ebc: ldurb           w17, [x0, #-1]
    //     0xd23ec0: and             x16, x17, x16, lsr #2
    //     0xd23ec4: tst             x16, HEAP, lsr #32
    //     0xd23ec8: b.eq            #0xd23ed0
    //     0xd23ecc: bl              #0x13de074  ; WriteBarrierWrappersStub
    // 0xd23ed0: cmp             w1, NULL
    // 0xd23ed4: b.ne            #0xd23eec
    // 0xd23ed8: ldr             x1, [fp, #0x18]
    // 0xd23edc: ldr             x2, [fp, #0x20]
    // 0xd23ee0: r0 = _getTargetRadius()
    //     0xd23ee0: bl              #0xd23b50  ; [package:flutter/src/material/ink_ripple.dart] ::_getTargetRadius
    // 0xd23ee4: mov             v1.16b, v0.16b
    // 0xd23ee8: b               #0xd23ef4
    // 0xd23eec: LoadField: d0 = r1->field_7
    //     0xd23eec: ldur            d0, [x1, #7]
    // 0xd23ef0: mov             v1.16b, v0.16b
    // 0xd23ef4: ldur            x2, [fp, #-8]
    // 0xd23ef8: ldr             x1, [fp, #0x20]
    // 0xd23efc: ldr             x0, [fp, #0x18]
    // 0xd23f00: d0 = 2.300000
    //     0xd23f00: add             x17, PP, #0x1c, lsl #12  ; [pp+0x1cca0] IMM: double(2.3) from 0x4002666666666666
    //     0xd23f04: ldr             d0, [x17, #0xca0]
    // 0xd23f08: fmul            d2, d1, d0
    // 0xd23f0c: StoreField: r2->field_3f = d2
    //     0xd23f0c: stur            d2, [x2, #0x3f]
    // 0xd23f10: r1 = 1
    //     0xd23f10: mov             x1, #1
    // 0xd23f14: r0 = AllocateContext()
    //     0xd23f14: bl              #0x13de838  ; AllocateContextStub
    // 0xd23f18: mov             x1, x0
    // 0xd23f1c: ldr             x0, [fp, #0x18]
    // 0xd23f20: StoreField: r1->field_f = r0
    //     0xd23f20: stur            w0, [x1, #0xf]
    // 0xd23f24: ldr             x2, [fp, #0x20]
    // 0xd23f28: cmp             w2, NULL
    // 0xd23f2c: b.eq            #0xd23f38
    // 0xd23f30: mov             x0, x2
    // 0xd23f34: b               #0xd23f58
    // 0xd23f38: ldur            x2, [fp, #-0x18]
    // 0xd23f3c: tbnz            w2, #4, #0xd23f54
    // 0xd23f40: mov             x2, x1
    // 0xd23f44: r1 = Function '<anonymous closure>': static.
    //     0xd23f44: add             x1, PP, #0x99, lsl #12  ; [pp+0x995c8] AnonymousClosure: static (0xd23d6c), of [package:flutter/src/material/ink_ripple.dart] 
    //     0xd23f48: ldr             x1, [x1, #0x5c8]
    // 0xd23f4c: r0 = AllocateClosure()
    //     0xd23f4c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd23f50: b               #0xd23f58
    // 0xd23f54: r0 = Null
    //     0xd23f54: mov             x0, NULL
    // 0xd23f58: ldur            x2, [fp, #-8]
    // 0xd23f5c: ldur            x1, [fp, #-0x20]
    // 0xd23f60: ldr             x3, [fp, #0x30]
    // 0xd23f64: StoreField: r2->field_47 = r0
    //     0xd23f64: stur            w0, [x2, #0x47]
    //     0xd23f68: tbz             w0, #0, #0xd23f84
    //     0xd23f6c: ldurb           w16, [x2, #-1]
    //     0xd23f70: ldurb           w17, [x0, #-1]
    //     0xd23f74: and             x16, x17, x16, lsr #2
    //     0xd23f78: tst             x16, HEAP, lsr #32
    //     0xd23f7c: b.eq            #0xd23f84
    //     0xd23f80: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd23f84: ldur            x0, [fp, #-0x10]
    // 0xd23f88: StoreField: r2->field_13 = r0
    //     0xd23f88: stur            w0, [x2, #0x13]
    //     0xd23f8c: ldurb           w16, [x2, #-1]
    //     0xd23f90: ldurb           w17, [x0, #-1]
    //     0xd23f94: and             x16, x17, x16, lsr #2
    //     0xd23f98: tst             x16, HEAP, lsr #32
    //     0xd23f9c: b.eq            #0xd23fa4
    //     0xd23fa0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd23fa4: ldur            x0, [fp, #-0x28]
    // 0xd23fa8: ArrayStore: r2[0] = r0  ; List_4
    //     0xd23fa8: stur            w0, [x2, #0x17]
    //     0xd23fac: ldurb           w16, [x2, #-1]
    //     0xd23fb0: ldurb           w17, [x0, #-1]
    //     0xd23fb4: and             x16, x17, x16, lsr #2
    //     0xd23fb8: tst             x16, HEAP, lsr #32
    //     0xd23fbc: b.eq            #0xd23fc4
    //     0xd23fc0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd23fc4: ldr             x0, [fp, #0x18]
    // 0xd23fc8: StoreField: r2->field_b = r0
    //     0xd23fc8: stur            w0, [x2, #0xb]
    //     0xd23fcc: ldurb           w16, [x2, #-1]
    //     0xd23fd0: ldurb           w17, [x0, #-1]
    //     0xd23fd4: and             x16, x17, x16, lsr #2
    //     0xd23fd8: tst             x16, HEAP, lsr #32
    //     0xd23fdc: b.eq            #0xd23fe4
    //     0xd23fe0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd23fe4: ldr             x0, [fp, #0x38]
    // 0xd23fe8: StoreField: r2->field_f = r0
    //     0xd23fe8: stur            w0, [x2, #0xf]
    //     0xd23fec: ldurb           w16, [x2, #-1]
    //     0xd23ff0: ldurb           w17, [x0, #-1]
    //     0xd23ff4: and             x16, x17, x16, lsr #2
    //     0xd23ff8: tst             x16, HEAP, lsr #32
    //     0xd23ffc: b.eq            #0xd24004
    //     0xd24000: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd24004: mov             x0, x1
    // 0xd24008: StoreField: r2->field_7 = r0
    //     0xd24008: stur            w0, [x2, #7]
    //     0xd2400c: ldurb           w16, [x2, #-1]
    //     0xd24010: ldurb           w17, [x0, #-1]
    //     0xd24014: and             x16, x17, x16, lsr #2
    //     0xd24018: tst             x16, HEAP, lsr #32
    //     0xd2401c: b.eq            #0xd24024
    //     0xd24020: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd24024: r0 = initializeShader()
    //     0xd24024: bl              #0xd24f74  ; [package:flutter/src/material/ink_sparkle.dart] _InkSparkleFactory::initializeShader
    // 0xd24028: ldur            x1, [fp, #-0x20]
    // 0xd2402c: ldur            x2, [fp, #-8]
    // 0xd24030: r0 = addInkFeature()
    //     0xd24030: bl              #0xd21c40  ; [package:flutter/src/material/material.dart] _RenderInkFeatures::addInkFeature
    // 0xd24034: ldur            x2, [fp, #-0x20]
    // 0xd24038: LoadField: r0 = r2->field_53
    //     0xd24038: ldur            w0, [x2, #0x53]
    // 0xd2403c: DecompressPointer r0
    //     0xd2403c: add             x0, x0, HEAP, lsl #32
    // 0xd24040: stur            x0, [fp, #-0x10]
    // 0xd24044: r1 = <double>
    //     0xd24044: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd24048: r0 = AnimationController()
    //     0xd24048: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xd2404c: stur            x0, [fp, #-0x18]
    // 0xd24050: r16 = Instance_Duration
    //     0xd24050: add             x16, PP, #0x99, lsl #12  ; [pp+0x995d0] Obj!Duration@12c8aa1
    //     0xd24054: ldr             x16, [x16, #0x5d0]
    // 0xd24058: str             x16, [SP]
    // 0xd2405c: mov             x1, x0
    // 0xd24060: ldur            x2, [fp, #-0x10]
    // 0xd24064: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xd24064: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xd24068: ldr             x4, [x4, #0x5a0]
    // 0xd2406c: r0 = AnimationController()
    //     0xd2406c: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xd24070: ldur            x2, [fp, #-0x20]
    // 0xd24074: r1 = Function 'markNeedsPaint':.
    //     0xd24074: add             x1, PP, #0x90, lsl #12  ; [pp+0x901f0] AnonymousClosure: (0xbf0a50), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0xbf0858)
    //     0xd24078: ldr             x1, [x1, #0x1f0]
    // 0xd2407c: r0 = AllocateClosure()
    //     0xd2407c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd24080: ldur            x1, [fp, #-0x18]
    // 0xd24084: mov             x2, x0
    // 0xd24088: r0 = addListener()
    //     0xd24088: bl              #0xd0440c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::addListener
    // 0xd2408c: ldur            x2, [fp, #-8]
    // 0xd24090: r1 = Function '_handleStatusChanged@756321118':.
    //     0xd24090: add             x1, PP, #0x99, lsl #12  ; [pp+0x995d8] AnonymousClosure: (0xd253e8), in [package:flutter/src/material/ink_sparkle.dart] InkSparkle::_handleStatusChanged (0xd25424)
    //     0xd24094: ldr             x1, [x1, #0x5d8]
    // 0xd24098: r0 = AllocateClosure()
    //     0xd24098: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd2409c: ldur            x1, [fp, #-0x18]
    // 0xd240a0: mov             x2, x0
    // 0xd240a4: r0 = addStatusListener()
    //     0xd240a4: bl              #0x1254cc0  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0xd240a8: ldur            x1, [fp, #-0x18]
    // 0xd240ac: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd240ac: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd240b0: r0 = forward()
    //     0xd240b0: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xd240b4: ldur            x0, [fp, #-0x18]
    // 0xd240b8: ldur            x2, [fp, #-8]
    // 0xd240bc: StoreField: r2->field_1b = r0
    //     0xd240bc: stur            w0, [x2, #0x1b]
    //     0xd240c0: ldurb           w16, [x2, #-1]
    //     0xd240c4: ldurb           w17, [x0, #-1]
    //     0xd240c8: and             x16, x17, x16, lsr #2
    //     0xd240cc: tst             x16, HEAP, lsr #32
    //     0xd240d0: b.eq            #0xd240d8
    //     0xd240d4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd240d8: r1 = <double>
    //     0xd240d8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd240dc: r0 = CurveTween()
    //     0xd240dc: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xd240e0: mov             x2, x0
    // 0xd240e4: r0 = Instance_Cubic
    //     0xd240e4: ldr             x0, [PP, #0x5660]  ; [pp+0x5660] Obj!Cubic@129f451
    // 0xd240e8: stur            x2, [fp, #-0x10]
    // 0xd240ec: StoreField: r2->field_b = r0
    //     0xd240ec: stur            w0, [x2, #0xb]
    // 0xd240f0: r1 = <double>
    //     0xd240f0: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd240f4: r0 = TweenSequenceItem()
    //     0xd240f4: bl              #0xb6f82c  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0xd240f8: mov             x2, x0
    // 0xd240fc: ldur            x0, [fp, #-0x10]
    // 0xd24100: stur            x2, [fp, #-0x18]
    // 0xd24104: StoreField: r2->field_b = r0
    //     0xd24104: stur            w0, [x2, #0xb]
    // 0xd24108: d0 = 75.000000
    //     0xd24108: add             x17, PP, #0x13, lsl #12  ; [pp+0x135e0] IMM: double(75) from 0x4052c00000000000
    //     0xd2410c: ldr             d0, [x17, #0x5e0]
    // 0xd24110: StoreField: r2->field_f = d0
    //     0xd24110: stur            d0, [x2, #0xf]
    // 0xd24114: r1 = <double>
    //     0xd24114: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd24118: r0 = ConstantTween()
    //     0xd24118: bl              #0xb6f820  ; AllocateConstantTweenStub -> ConstantTween<X0> (size=0x14)
    // 0xd2411c: mov             x2, x0
    // 0xd24120: r0 = 1.000000
    //     0xd24120: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xd24124: stur            x2, [fp, #-0x10]
    // 0xd24128: StoreField: r2->field_b = r0
    //     0xd24128: stur            w0, [x2, #0xb]
    // 0xd2412c: StoreField: r2->field_f = r0
    //     0xd2412c: stur            w0, [x2, #0xf]
    // 0xd24130: r1 = <double>
    //     0xd24130: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd24134: r0 = TweenSequenceItem()
    //     0xd24134: bl              #0xb6f82c  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0xd24138: mov             x3, x0
    // 0xd2413c: ldur            x0, [fp, #-0x10]
    // 0xd24140: stur            x3, [fp, #-0x20]
    // 0xd24144: StoreField: r3->field_b = r0
    //     0xd24144: stur            w0, [x3, #0xb]
    // 0xd24148: d0 = 25.000000
    //     0xd24148: fmov            d0, #25.00000000
    // 0xd2414c: StoreField: r3->field_f = d0
    //     0xd2414c: stur            d0, [x3, #0xf]
    // 0xd24150: r1 = Null
    //     0xd24150: mov             x1, NULL
    // 0xd24154: r2 = 4
    //     0xd24154: mov             x2, #4
    // 0xd24158: r0 = AllocateArray()
    //     0xd24158: bl              #0x13df928  ; AllocateArrayStub
    // 0xd2415c: mov             x2, x0
    // 0xd24160: ldur            x0, [fp, #-0x18]
    // 0xd24164: stur            x2, [fp, #-0x10]
    // 0xd24168: StoreField: r2->field_f = r0
    //     0xd24168: stur            w0, [x2, #0xf]
    // 0xd2416c: ldur            x0, [fp, #-0x20]
    // 0xd24170: StoreField: r2->field_13 = r0
    //     0xd24170: stur            w0, [x2, #0x13]
    // 0xd24174: r1 = <TweenSequenceItem<double>>
    //     0xd24174: add             x1, PP, #0x99, lsl #12  ; [pp+0x995e0] TypeArguments: <TweenSequenceItem<double>>
    //     0xd24178: ldr             x1, [x1, #0x5e0]
    // 0xd2417c: r0 = AllocateGrowableArray()
    //     0xd2417c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd24180: mov             x2, x0
    // 0xd24184: ldur            x0, [fp, #-0x10]
    // 0xd24188: stur            x2, [fp, #-0x18]
    // 0xd2418c: StoreField: r2->field_f = r0
    //     0xd2418c: stur            w0, [x2, #0xf]
    // 0xd24190: r0 = 4
    //     0xd24190: mov             x0, #4
    // 0xd24194: StoreField: r2->field_b = r0
    //     0xd24194: stur            w0, [x2, #0xb]
    // 0xd24198: r1 = <double>
    //     0xd24198: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd2419c: r0 = TweenSequence()
    //     0xd2419c: bl              #0xb6f808  ; AllocateTweenSequenceStub -> TweenSequence<X0> (size=0x14)
    // 0xd241a0: mov             x1, x0
    // 0xd241a4: ldur            x2, [fp, #-0x18]
    // 0xd241a8: stur            x0, [fp, #-0x10]
    // 0xd241ac: r0 = TweenSequence()
    //     0xd241ac: bl              #0xb6f43c  ; [package:flutter/src/animation/tween_sequence.dart] TweenSequence::TweenSequence
    // 0xd241b0: ldur            x0, [fp, #-8]
    // 0xd241b4: LoadField: r2 = r0->field_1b
    //     0xd241b4: ldur            w2, [x0, #0x1b]
    // 0xd241b8: DecompressPointer r2
    //     0xd241b8: add             x2, x2, HEAP, lsl #32
    // 0xd241bc: ldur            x1, [fp, #-0x10]
    // 0xd241c0: r0 = animate()
    //     0xd241c0: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xd241c4: ldur            x3, [fp, #-8]
    // 0xd241c8: StoreField: r3->field_23 = r0
    //     0xd241c8: stur            w0, [x3, #0x23]
    //     0xd241cc: ldurb           w16, [x3, #-1]
    //     0xd241d0: ldurb           w17, [x0, #-1]
    //     0xd241d4: and             x16, x17, x16, lsr #2
    //     0xd241d8: tst             x16, HEAP, lsr #32
    //     0xd241dc: b.eq            #0xd241e4
    //     0xd241e0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd241e4: ldr             x0, [fp, #0x30]
    // 0xd241e8: LoadField: d0 = r0->field_7
    //     0xd241e8: ldur            d0, [x0, #7]
    // 0xd241ec: LoadField: d1 = r0->field_f
    //     0xd241ec: ldur            d1, [x0, #0xf]
    // 0xd241f0: stur            d1, [fp, #-0x30]
    // 0xd241f4: r0 = inline_Allocate_Double()
    //     0xd241f4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd241f8: add             x0, x0, #0x10
    //     0xd241fc: cmp             x1, x0
    //     0xd24200: b.ls            #0xd24804
    //     0xd24204: str             x0, [THR, #0x60]  ; THR::top
    //     0xd24208: sub             x0, x0, #0xf
    //     0xd2420c: mov             x1, #0xe19c
    //     0xd24210: movk            x1, #3, lsl #16
    //     0xd24214: stur            x1, [x0, #-1]
    // 0xd24218: dmb             ishst
    // 0xd2421c: StoreField: r0->field_7 = d0
    //     0xd2421c: stur            d0, [x0, #7]
    // 0xd24220: stur            x0, [fp, #-0x10]
    // 0xd24224: r1 = Null
    //     0xd24224: mov             x1, NULL
    // 0xd24228: r2 = 4
    //     0xd24228: mov             x2, #4
    // 0xd2422c: r0 = AllocateArray()
    //     0xd2422c: bl              #0x13df928  ; AllocateArrayStub
    // 0xd24230: mov             x2, x0
    // 0xd24234: ldur            x0, [fp, #-0x10]
    // 0xd24238: stur            x2, [fp, #-0x18]
    // 0xd2423c: StoreField: r2->field_f = r0
    //     0xd2423c: stur            w0, [x2, #0xf]
    // 0xd24240: ldur            d0, [fp, #-0x30]
    // 0xd24244: r0 = inline_Allocate_Double()
    //     0xd24244: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd24248: add             x0, x0, #0x10
    //     0xd2424c: cmp             x1, x0
    //     0xd24250: b.ls            #0xd2481c
    //     0xd24254: str             x0, [THR, #0x60]  ; THR::top
    //     0xd24258: sub             x0, x0, #0xf
    //     0xd2425c: mov             x1, #0xe19c
    //     0xd24260: movk            x1, #3, lsl #16
    //     0xd24264: stur            x1, [x0, #-1]
    // 0xd24268: dmb             ishst
    // 0xd2426c: StoreField: r0->field_7 = d0
    //     0xd2426c: stur            d0, [x0, #7]
    // 0xd24270: StoreField: r2->field_13 = r0
    //     0xd24270: stur            w0, [x2, #0x13]
    // 0xd24274: r1 = <double>
    //     0xd24274: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd24278: r0 = AllocateGrowableArray()
    //     0xd24278: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd2427c: mov             x1, x0
    // 0xd24280: ldur            x0, [fp, #-0x18]
    // 0xd24284: StoreField: r1->field_f = r0
    //     0xd24284: stur            w0, [x1, #0xf]
    // 0xd24288: r0 = 4
    //     0xd24288: mov             x0, #4
    // 0xd2428c: StoreField: r1->field_b = r0
    //     0xd2428c: stur            w0, [x1, #0xb]
    // 0xd24290: mov             x2, x1
    // 0xd24294: r1 = Null
    //     0xd24294: mov             x1, NULL
    // 0xd24298: r0 = Vector2.array()
    //     0xd24298: bl              #0xd248e0  ; [package:vector_math/vector_math_64.dart] Vector2::Vector2.array
    // 0xd2429c: ldr             x1, [fp, #0x18]
    // 0xd242a0: stur            x0, [fp, #-0x10]
    // 0xd242a4: r0 = size()
    //     0xd242a4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xd242a8: LoadField: d0 = r0->field_7
    //     0xd242a8: ldur            d0, [x0, #7]
    // 0xd242ac: d1 = 2.000000
    //     0xd242ac: fmov            d1, #2.00000000
    // 0xd242b0: fdiv            d2, d0, d1
    // 0xd242b4: ldr             x1, [fp, #0x18]
    // 0xd242b8: stur            d2, [fp, #-0x30]
    // 0xd242bc: r0 = size()
    //     0xd242bc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xd242c0: LoadField: d0 = r0->field_f
    //     0xd242c0: ldur            d0, [x0, #0xf]
    // 0xd242c4: d1 = 2.000000
    //     0xd242c4: fmov            d1, #2.00000000
    // 0xd242c8: fdiv            d2, d0, d1
    // 0xd242cc: ldur            d0, [fp, #-0x30]
    // 0xd242d0: stur            d2, [fp, #-0x38]
    // 0xd242d4: r0 = inline_Allocate_Double()
    //     0xd242d4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd242d8: add             x0, x0, #0x10
    //     0xd242dc: cmp             x1, x0
    //     0xd242e0: b.ls            #0xd24834
    //     0xd242e4: str             x0, [THR, #0x60]  ; THR::top
    //     0xd242e8: sub             x0, x0, #0xf
    //     0xd242ec: mov             x1, #0xe19c
    //     0xd242f0: movk            x1, #3, lsl #16
    //     0xd242f4: stur            x1, [x0, #-1]
    // 0xd242f8: dmb             ishst
    // 0xd242fc: StoreField: r0->field_7 = d0
    //     0xd242fc: stur            d0, [x0, #7]
    // 0xd24300: stur            x0, [fp, #-0x18]
    // 0xd24304: r1 = Null
    //     0xd24304: mov             x1, NULL
    // 0xd24308: r2 = 4
    //     0xd24308: mov             x2, #4
    // 0xd2430c: r0 = AllocateArray()
    //     0xd2430c: bl              #0x13df928  ; AllocateArrayStub
    // 0xd24310: mov             x2, x0
    // 0xd24314: ldur            x0, [fp, #-0x18]
    // 0xd24318: stur            x2, [fp, #-0x20]
    // 0xd2431c: StoreField: r2->field_f = r0
    //     0xd2431c: stur            w0, [x2, #0xf]
    // 0xd24320: ldur            d0, [fp, #-0x38]
    // 0xd24324: r0 = inline_Allocate_Double()
    //     0xd24324: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd24328: add             x0, x0, #0x10
    //     0xd2432c: cmp             x1, x0
    //     0xd24330: b.ls            #0xd24844
    //     0xd24334: str             x0, [THR, #0x60]  ; THR::top
    //     0xd24338: sub             x0, x0, #0xf
    //     0xd2433c: mov             x1, #0xe19c
    //     0xd24340: movk            x1, #3, lsl #16
    //     0xd24344: stur            x1, [x0, #-1]
    // 0xd24348: dmb             ishst
    // 0xd2434c: StoreField: r0->field_7 = d0
    //     0xd2434c: stur            d0, [x0, #7]
    // 0xd24350: StoreField: r2->field_13 = r0
    //     0xd24350: stur            w0, [x2, #0x13]
    // 0xd24354: r1 = <double>
    //     0xd24354: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd24358: r0 = AllocateGrowableArray()
    //     0xd24358: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd2435c: mov             x1, x0
    // 0xd24360: ldur            x0, [fp, #-0x20]
    // 0xd24364: StoreField: r1->field_f = r0
    //     0xd24364: stur            w0, [x1, #0xf]
    // 0xd24368: r0 = 4
    //     0xd24368: mov             x0, #4
    // 0xd2436c: StoreField: r1->field_b = r0
    //     0xd2436c: stur            w0, [x1, #0xb]
    // 0xd24370: mov             x2, x1
    // 0xd24374: r1 = Null
    //     0xd24374: mov             x1, NULL
    // 0xd24378: r0 = Vector2.array()
    //     0xd24378: bl              #0xd248e0  ; [package:vector_math/vector_math_64.dart] Vector2::Vector2.array
    // 0xd2437c: r1 = <Vector2>
    //     0xd2437c: add             x1, PP, #0x99, lsl #12  ; [pp+0x995e8] TypeArguments: <Vector2>
    //     0xd24380: ldr             x1, [x1, #0x5e8]
    // 0xd24384: stur            x0, [fp, #-0x18]
    // 0xd24388: r0 = Tween()
    //     0xd24388: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xd2438c: mov             x2, x0
    // 0xd24390: ldur            x0, [fp, #-0x10]
    // 0xd24394: stur            x2, [fp, #-0x20]
    // 0xd24398: StoreField: r2->field_b = r0
    //     0xd24398: stur            w0, [x2, #0xb]
    // 0xd2439c: ldur            x0, [fp, #-0x18]
    // 0xd243a0: StoreField: r2->field_f = r0
    //     0xd243a0: stur            w0, [x2, #0xf]
    // 0xd243a4: r1 = <double>
    //     0xd243a4: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd243a8: r0 = Tween()
    //     0xd243a8: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xd243ac: mov             x2, x0
    // 0xd243b0: r0 = 0.000000
    //     0xd243b0: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd243b4: stur            x2, [fp, #-0x10]
    // 0xd243b8: StoreField: r2->field_b = r0
    //     0xd243b8: stur            w0, [x2, #0xb]
    // 0xd243bc: r3 = 1.000000
    //     0xd243bc: ldr             x3, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xd243c0: StoreField: r2->field_f = r3
    //     0xd243c0: stur            w3, [x2, #0xf]
    // 0xd243c4: r1 = <double>
    //     0xd243c4: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd243c8: r0 = TweenSequenceItem()
    //     0xd243c8: bl              #0xb6f82c  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0xd243cc: mov             x2, x0
    // 0xd243d0: ldur            x0, [fp, #-0x10]
    // 0xd243d4: stur            x2, [fp, #-0x18]
    // 0xd243d8: StoreField: r2->field_b = r0
    //     0xd243d8: stur            w0, [x2, #0xb]
    // 0xd243dc: d0 = 50.000000
    //     0xd243dc: add             x17, PP, #0x13, lsl #12  ; [pp+0x131d0] IMM: double(50) from 0x4049000000000000
    //     0xd243e0: ldr             d0, [x17, #0x1d0]
    // 0xd243e4: StoreField: r2->field_f = d0
    //     0xd243e4: stur            d0, [x2, #0xf]
    // 0xd243e8: r1 = <double>
    //     0xd243e8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd243ec: r0 = ConstantTween()
    //     0xd243ec: bl              #0xb6f820  ; AllocateConstantTweenStub -> ConstantTween<X0> (size=0x14)
    // 0xd243f0: mov             x2, x0
    // 0xd243f4: r0 = 1.000000
    //     0xd243f4: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xd243f8: stur            x2, [fp, #-0x10]
    // 0xd243fc: StoreField: r2->field_b = r0
    //     0xd243fc: stur            w0, [x2, #0xb]
    // 0xd24400: StoreField: r2->field_f = r0
    //     0xd24400: stur            w0, [x2, #0xf]
    // 0xd24404: r1 = <double>
    //     0xd24404: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd24408: r0 = TweenSequenceItem()
    //     0xd24408: bl              #0xb6f82c  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0xd2440c: mov             x3, x0
    // 0xd24410: ldur            x0, [fp, #-0x10]
    // 0xd24414: stur            x3, [fp, #-0x28]
    // 0xd24418: StoreField: r3->field_b = r0
    //     0xd24418: stur            w0, [x3, #0xb]
    // 0xd2441c: d0 = 50.000000
    //     0xd2441c: add             x17, PP, #0x13, lsl #12  ; [pp+0x131d0] IMM: double(50) from 0x4049000000000000
    //     0xd24420: ldr             d0, [x17, #0x1d0]
    // 0xd24424: StoreField: r3->field_f = d0
    //     0xd24424: stur            d0, [x3, #0xf]
    // 0xd24428: r1 = Null
    //     0xd24428: mov             x1, NULL
    // 0xd2442c: r2 = 4
    //     0xd2442c: mov             x2, #4
    // 0xd24430: r0 = AllocateArray()
    //     0xd24430: bl              #0x13df928  ; AllocateArrayStub
    // 0xd24434: mov             x2, x0
    // 0xd24438: ldur            x0, [fp, #-0x18]
    // 0xd2443c: stur            x2, [fp, #-0x10]
    // 0xd24440: StoreField: r2->field_f = r0
    //     0xd24440: stur            w0, [x2, #0xf]
    // 0xd24444: ldur            x0, [fp, #-0x28]
    // 0xd24448: StoreField: r2->field_13 = r0
    //     0xd24448: stur            w0, [x2, #0x13]
    // 0xd2444c: r1 = <TweenSequenceItem<double>>
    //     0xd2444c: add             x1, PP, #0x99, lsl #12  ; [pp+0x995e0] TypeArguments: <TweenSequenceItem<double>>
    //     0xd24450: ldr             x1, [x1, #0x5e0]
    // 0xd24454: r0 = AllocateGrowableArray()
    //     0xd24454: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd24458: mov             x2, x0
    // 0xd2445c: ldur            x0, [fp, #-0x10]
    // 0xd24460: stur            x2, [fp, #-0x18]
    // 0xd24464: StoreField: r2->field_f = r0
    //     0xd24464: stur            w0, [x2, #0xf]
    // 0xd24468: r0 = 4
    //     0xd24468: mov             x0, #4
    // 0xd2446c: StoreField: r2->field_b = r0
    //     0xd2446c: stur            w0, [x2, #0xb]
    // 0xd24470: r1 = <double>
    //     0xd24470: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd24474: r0 = TweenSequence()
    //     0xd24474: bl              #0xb6f808  ; AllocateTweenSequenceStub -> TweenSequence<X0> (size=0x14)
    // 0xd24478: mov             x1, x0
    // 0xd2447c: ldur            x2, [fp, #-0x18]
    // 0xd24480: stur            x0, [fp, #-0x10]
    // 0xd24484: r0 = TweenSequence()
    //     0xd24484: bl              #0xb6f43c  ; [package:flutter/src/animation/tween_sequence.dart] TweenSequence::TweenSequence
    // 0xd24488: ldur            x0, [fp, #-8]
    // 0xd2448c: LoadField: r2 = r0->field_23
    //     0xd2448c: ldur            w2, [x0, #0x23]
    // 0xd24490: DecompressPointer r2
    //     0xd24490: add             x2, x2, HEAP, lsl #32
    // 0xd24494: ldur            x1, [fp, #-0x10]
    // 0xd24498: r0 = animate()
    //     0xd24498: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xd2449c: ldur            x1, [fp, #-0x20]
    // 0xd244a0: mov             x2, x0
    // 0xd244a4: r0 = animate()
    //     0xd244a4: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xd244a8: ldur            x2, [fp, #-8]
    // 0xd244ac: StoreField: r2->field_1f = r0
    //     0xd244ac: stur            w0, [x2, #0x1f]
    //     0xd244b0: ldurb           w16, [x2, #-1]
    //     0xd244b4: ldurb           w17, [x0, #-1]
    //     0xd244b8: and             x16, x17, x16, lsr #2
    //     0xd244bc: tst             x16, HEAP, lsr #32
    //     0xd244c0: b.eq            #0xd244c8
    //     0xd244c4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd244c8: r1 = <double>
    //     0xd244c8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd244cc: r0 = Tween()
    //     0xd244cc: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xd244d0: mov             x2, x0
    // 0xd244d4: r0 = 0.000000
    //     0xd244d4: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd244d8: stur            x2, [fp, #-0x10]
    // 0xd244dc: StoreField: r2->field_b = r0
    //     0xd244dc: stur            w0, [x2, #0xb]
    // 0xd244e0: r3 = 1.000000
    //     0xd244e0: ldr             x3, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xd244e4: StoreField: r2->field_f = r3
    //     0xd244e4: stur            w3, [x2, #0xf]
    // 0xd244e8: r1 = <double>
    //     0xd244e8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd244ec: r0 = TweenSequenceItem()
    //     0xd244ec: bl              #0xb6f82c  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0xd244f0: mov             x2, x0
    // 0xd244f4: ldur            x0, [fp, #-0x10]
    // 0xd244f8: stur            x2, [fp, #-0x18]
    // 0xd244fc: StoreField: r2->field_b = r0
    //     0xd244fc: stur            w0, [x2, #0xb]
    // 0xd24500: d0 = 13.000000
    //     0xd24500: fmov            d0, #13.00000000
    // 0xd24504: StoreField: r2->field_f = d0
    //     0xd24504: stur            d0, [x2, #0xf]
    // 0xd24508: r1 = <double>
    //     0xd24508: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd2450c: r0 = ConstantTween()
    //     0xd2450c: bl              #0xb6f820  ; AllocateConstantTweenStub -> ConstantTween<X0> (size=0x14)
    // 0xd24510: mov             x2, x0
    // 0xd24514: r0 = 1.000000
    //     0xd24514: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xd24518: stur            x2, [fp, #-0x10]
    // 0xd2451c: StoreField: r2->field_b = r0
    //     0xd2451c: stur            w0, [x2, #0xb]
    // 0xd24520: StoreField: r2->field_f = r0
    //     0xd24520: stur            w0, [x2, #0xf]
    // 0xd24524: r1 = <double>
    //     0xd24524: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd24528: r0 = TweenSequenceItem()
    //     0xd24528: bl              #0xb6f82c  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0xd2452c: mov             x2, x0
    // 0xd24530: ldur            x0, [fp, #-0x10]
    // 0xd24534: stur            x2, [fp, #-0x20]
    // 0xd24538: StoreField: r2->field_b = r0
    //     0xd24538: stur            w0, [x2, #0xb]
    // 0xd2453c: d0 = 27.000000
    //     0xd2453c: fmov            d0, #27.00000000
    // 0xd24540: StoreField: r2->field_f = d0
    //     0xd24540: stur            d0, [x2, #0xf]
    // 0xd24544: r1 = <double>
    //     0xd24544: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd24548: r0 = Tween()
    //     0xd24548: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xd2454c: mov             x2, x0
    // 0xd24550: r0 = 1.000000
    //     0xd24550: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xd24554: stur            x2, [fp, #-0x10]
    // 0xd24558: StoreField: r2->field_b = r0
    //     0xd24558: stur            w0, [x2, #0xb]
    // 0xd2455c: r3 = 0.000000
    //     0xd2455c: ldr             x3, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd24560: StoreField: r2->field_f = r3
    //     0xd24560: stur            w3, [x2, #0xf]
    // 0xd24564: r1 = <double>
    //     0xd24564: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd24568: r0 = TweenSequenceItem()
    //     0xd24568: bl              #0xb6f82c  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0xd2456c: mov             x3, x0
    // 0xd24570: ldur            x0, [fp, #-0x10]
    // 0xd24574: stur            x3, [fp, #-0x28]
    // 0xd24578: StoreField: r3->field_b = r0
    //     0xd24578: stur            w0, [x3, #0xb]
    // 0xd2457c: d0 = 60.000000
    //     0xd2457c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13358] IMM: double(60) from 0x404e000000000000
    //     0xd24580: ldr             d0, [x17, #0x358]
    // 0xd24584: StoreField: r3->field_f = d0
    //     0xd24584: stur            d0, [x3, #0xf]
    // 0xd24588: r1 = Null
    //     0xd24588: mov             x1, NULL
    // 0xd2458c: r2 = 6
    //     0xd2458c: mov             x2, #6
    // 0xd24590: r0 = AllocateArray()
    //     0xd24590: bl              #0x13df928  ; AllocateArrayStub
    // 0xd24594: mov             x2, x0
    // 0xd24598: ldur            x0, [fp, #-0x18]
    // 0xd2459c: stur            x2, [fp, #-0x10]
    // 0xd245a0: StoreField: r2->field_f = r0
    //     0xd245a0: stur            w0, [x2, #0xf]
    // 0xd245a4: ldur            x0, [fp, #-0x20]
    // 0xd245a8: StoreField: r2->field_13 = r0
    //     0xd245a8: stur            w0, [x2, #0x13]
    // 0xd245ac: ldur            x0, [fp, #-0x28]
    // 0xd245b0: ArrayStore: r2[0] = r0  ; List_4
    //     0xd245b0: stur            w0, [x2, #0x17]
    // 0xd245b4: r1 = <TweenSequenceItem<double>>
    //     0xd245b4: add             x1, PP, #0x99, lsl #12  ; [pp+0x995e0] TypeArguments: <TweenSequenceItem<double>>
    //     0xd245b8: ldr             x1, [x1, #0x5e0]
    // 0xd245bc: r0 = AllocateGrowableArray()
    //     0xd245bc: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd245c0: mov             x2, x0
    // 0xd245c4: ldur            x0, [fp, #-0x10]
    // 0xd245c8: stur            x2, [fp, #-0x18]
    // 0xd245cc: StoreField: r2->field_f = r0
    //     0xd245cc: stur            w0, [x2, #0xf]
    // 0xd245d0: r0 = 6
    //     0xd245d0: mov             x0, #6
    // 0xd245d4: StoreField: r2->field_b = r0
    //     0xd245d4: stur            w0, [x2, #0xb]
    // 0xd245d8: r1 = <double>
    //     0xd245d8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd245dc: r0 = TweenSequence()
    //     0xd245dc: bl              #0xb6f808  ; AllocateTweenSequenceStub -> TweenSequence<X0> (size=0x14)
    // 0xd245e0: mov             x1, x0
    // 0xd245e4: ldur            x2, [fp, #-0x18]
    // 0xd245e8: stur            x0, [fp, #-0x10]
    // 0xd245ec: r0 = TweenSequence()
    //     0xd245ec: bl              #0xb6f43c  ; [package:flutter/src/animation/tween_sequence.dart] TweenSequence::TweenSequence
    // 0xd245f0: ldur            x0, [fp, #-8]
    // 0xd245f4: LoadField: r2 = r0->field_1b
    //     0xd245f4: ldur            w2, [x0, #0x1b]
    // 0xd245f8: DecompressPointer r2
    //     0xd245f8: add             x2, x2, HEAP, lsl #32
    // 0xd245fc: ldur            x1, [fp, #-0x10]
    // 0xd24600: r0 = animate()
    //     0xd24600: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xd24604: ldur            x2, [fp, #-8]
    // 0xd24608: StoreField: r2->field_27 = r0
    //     0xd24608: stur            w0, [x2, #0x27]
    //     0xd2460c: ldurb           w16, [x2, #-1]
    //     0xd24610: ldurb           w17, [x0, #-1]
    //     0xd24614: and             x16, x17, x16, lsr #2
    //     0xd24618: tst             x16, HEAP, lsr #32
    //     0xd2461c: b.eq            #0xd24624
    //     0xd24620: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd24624: r1 = <double>
    //     0xd24624: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd24628: r0 = Tween()
    //     0xd24628: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xd2462c: mov             x2, x0
    // 0xd24630: r0 = 0.000000
    //     0xd24630: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd24634: stur            x2, [fp, #-0x10]
    // 0xd24638: StoreField: r2->field_b = r0
    //     0xd24638: stur            w0, [x2, #0xb]
    // 0xd2463c: r3 = 1.000000
    //     0xd2463c: ldr             x3, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xd24640: StoreField: r2->field_f = r3
    //     0xd24640: stur            w3, [x2, #0xf]
    // 0xd24644: r1 = <double>
    //     0xd24644: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd24648: r0 = TweenSequenceItem()
    //     0xd24648: bl              #0xb6f82c  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0xd2464c: mov             x2, x0
    // 0xd24650: ldur            x0, [fp, #-0x10]
    // 0xd24654: stur            x2, [fp, #-0x18]
    // 0xd24658: StoreField: r2->field_b = r0
    //     0xd24658: stur            w0, [x2, #0xb]
    // 0xd2465c: d0 = 13.000000
    //     0xd2465c: fmov            d0, #13.00000000
    // 0xd24660: StoreField: r2->field_f = d0
    //     0xd24660: stur            d0, [x2, #0xf]
    // 0xd24664: r1 = <double>
    //     0xd24664: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd24668: r0 = ConstantTween()
    //     0xd24668: bl              #0xb6f820  ; AllocateConstantTweenStub -> ConstantTween<X0> (size=0x14)
    // 0xd2466c: mov             x2, x0
    // 0xd24670: r0 = 1.000000
    //     0xd24670: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xd24674: stur            x2, [fp, #-0x10]
    // 0xd24678: StoreField: r2->field_b = r0
    //     0xd24678: stur            w0, [x2, #0xb]
    // 0xd2467c: StoreField: r2->field_f = r0
    //     0xd2467c: stur            w0, [x2, #0xf]
    // 0xd24680: r1 = <double>
    //     0xd24680: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd24684: r0 = TweenSequenceItem()
    //     0xd24684: bl              #0xb6f82c  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0xd24688: mov             x2, x0
    // 0xd2468c: ldur            x0, [fp, #-0x10]
    // 0xd24690: stur            x2, [fp, #-0x20]
    // 0xd24694: StoreField: r2->field_b = r0
    //     0xd24694: stur            w0, [x2, #0xb]
    // 0xd24698: d0 = 27.000000
    //     0xd24698: fmov            d0, #27.00000000
    // 0xd2469c: StoreField: r2->field_f = d0
    //     0xd2469c: stur            d0, [x2, #0xf]
    // 0xd246a0: r1 = <double>
    //     0xd246a0: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd246a4: r0 = Tween()
    //     0xd246a4: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xd246a8: mov             x2, x0
    // 0xd246ac: r0 = 1.000000
    //     0xd246ac: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xd246b0: stur            x2, [fp, #-0x10]
    // 0xd246b4: StoreField: r2->field_b = r0
    //     0xd246b4: stur            w0, [x2, #0xb]
    // 0xd246b8: r0 = 0.000000
    //     0xd246b8: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd246bc: StoreField: r2->field_f = r0
    //     0xd246bc: stur            w0, [x2, #0xf]
    // 0xd246c0: r1 = <double>
    //     0xd246c0: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd246c4: r0 = TweenSequenceItem()
    //     0xd246c4: bl              #0xb6f82c  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0xd246c8: mov             x3, x0
    // 0xd246cc: ldur            x0, [fp, #-0x10]
    // 0xd246d0: stur            x3, [fp, #-0x28]
    // 0xd246d4: StoreField: r3->field_b = r0
    //     0xd246d4: stur            w0, [x3, #0xb]
    // 0xd246d8: d0 = 50.000000
    //     0xd246d8: add             x17, PP, #0x13, lsl #12  ; [pp+0x131d0] IMM: double(50) from 0x4049000000000000
    //     0xd246dc: ldr             d0, [x17, #0x1d0]
    // 0xd246e0: StoreField: r3->field_f = d0
    //     0xd246e0: stur            d0, [x3, #0xf]
    // 0xd246e4: r1 = Null
    //     0xd246e4: mov             x1, NULL
    // 0xd246e8: r2 = 6
    //     0xd246e8: mov             x2, #6
    // 0xd246ec: r0 = AllocateArray()
    //     0xd246ec: bl              #0x13df928  ; AllocateArrayStub
    // 0xd246f0: mov             x2, x0
    // 0xd246f4: ldur            x0, [fp, #-0x18]
    // 0xd246f8: stur            x2, [fp, #-0x10]
    // 0xd246fc: StoreField: r2->field_f = r0
    //     0xd246fc: stur            w0, [x2, #0xf]
    // 0xd24700: ldur            x0, [fp, #-0x20]
    // 0xd24704: StoreField: r2->field_13 = r0
    //     0xd24704: stur            w0, [x2, #0x13]
    // 0xd24708: ldur            x0, [fp, #-0x28]
    // 0xd2470c: ArrayStore: r2[0] = r0  ; List_4
    //     0xd2470c: stur            w0, [x2, #0x17]
    // 0xd24710: r1 = <TweenSequenceItem<double>>
    //     0xd24710: add             x1, PP, #0x99, lsl #12  ; [pp+0x995e0] TypeArguments: <TweenSequenceItem<double>>
    //     0xd24714: ldr             x1, [x1, #0x5e0]
    // 0xd24718: r0 = AllocateGrowableArray()
    //     0xd24718: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd2471c: mov             x2, x0
    // 0xd24720: ldur            x0, [fp, #-0x10]
    // 0xd24724: stur            x2, [fp, #-0x18]
    // 0xd24728: StoreField: r2->field_f = r0
    //     0xd24728: stur            w0, [x2, #0xf]
    // 0xd2472c: r0 = 6
    //     0xd2472c: mov             x0, #6
    // 0xd24730: StoreField: r2->field_b = r0
    //     0xd24730: stur            w0, [x2, #0xb]
    // 0xd24734: r1 = <double>
    //     0xd24734: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd24738: r0 = TweenSequence()
    //     0xd24738: bl              #0xb6f808  ; AllocateTweenSequenceStub -> TweenSequence<X0> (size=0x14)
    // 0xd2473c: mov             x1, x0
    // 0xd24740: ldur            x2, [fp, #-0x18]
    // 0xd24744: stur            x0, [fp, #-0x10]
    // 0xd24748: r0 = TweenSequence()
    //     0xd24748: bl              #0xb6f43c  ; [package:flutter/src/animation/tween_sequence.dart] TweenSequence::TweenSequence
    // 0xd2474c: ldur            x0, [fp, #-8]
    // 0xd24750: LoadField: r2 = r0->field_1b
    //     0xd24750: ldur            w2, [x0, #0x1b]
    // 0xd24754: DecompressPointer r2
    //     0xd24754: add             x2, x2, HEAP, lsl #32
    // 0xd24758: ldur            x1, [fp, #-0x10]
    // 0xd2475c: r0 = animate()
    //     0xd2475c: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xd24760: ldur            x2, [fp, #-8]
    // 0xd24764: StoreField: r2->field_2b = r0
    //     0xd24764: stur            w0, [x2, #0x2b]
    //     0xd24768: ldurb           w16, [x2, #-1]
    //     0xd2476c: ldurb           w17, [x0, #-1]
    //     0xd24770: and             x16, x17, x16, lsr #2
    //     0xd24774: tst             x16, HEAP, lsr #32
    //     0xd24778: b.eq            #0xd24780
    //     0xd2477c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd24780: r1 = Null
    //     0xd24780: mov             x1, NULL
    // 0xd24784: r0 = Random()
    //     0xd24784: bl              #0x912154  ; [dart:math] Random::Random
    // 0xd24788: mov             x1, x0
    // 0xd2478c: r0 = nextDouble()
    //     0xd2478c: bl              #0xd2486c  ; [dart:math] _Random::nextDouble
    // 0xd24790: mov             v1.16b, v0.16b
    // 0xd24794: d0 = 1000.000000
    //     0xd24794: add             x17, PP, #0x16, lsl #12  ; [pp+0x16a58] IMM: double(1000) from 0x408f400000000000
    //     0xd24798: ldr             d0, [x17, #0xa58]
    // 0xd2479c: fmul            d2, d1, d0
    // 0xd247a0: r0 = inline_Allocate_Double()
    //     0xd247a0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd247a4: add             x0, x0, #0x10
    //     0xd247a8: cmp             x1, x0
    //     0xd247ac: b.ls            #0xd2485c
    //     0xd247b0: str             x0, [THR, #0x60]  ; THR::top
    //     0xd247b4: sub             x0, x0, #0xf
    //     0xd247b8: mov             x1, #0xe19c
    //     0xd247bc: movk            x1, #3, lsl #16
    //     0xd247c0: stur            x1, [x0, #-1]
    // 0xd247c4: dmb             ishst
    // 0xd247c8: StoreField: r0->field_7 = d2
    //     0xd247c8: stur            d2, [x0, #7]
    // 0xd247cc: ldur            x1, [fp, #-8]
    // 0xd247d0: StoreField: r1->field_2f = r0
    //     0xd247d0: stur            w0, [x1, #0x2f]
    //     0xd247d4: ldurb           w16, [x1, #-1]
    //     0xd247d8: ldurb           w17, [x0, #-1]
    //     0xd247dc: and             x16, x17, x16, lsr #2
    //     0xd247e0: tst             x16, HEAP, lsr #32
    //     0xd247e4: b.eq            #0xd247ec
    //     0xd247e8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd247ec: r0 = Null
    //     0xd247ec: mov             x0, NULL
    // 0xd247f0: LeaveFrame
    //     0xd247f0: mov             SP, fp
    //     0xd247f4: ldp             fp, lr, [SP], #0x10
    // 0xd247f8: ret
    //     0xd247f8: ret             
    // 0xd247fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd247fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd24800: b               #0xd23e18
    // 0xd24804: stp             q0, q1, [SP, #-0x20]!
    // 0xd24808: SaveReg r3
    //     0xd24808: str             x3, [SP, #-8]!
    // 0xd2480c: r0 = AllocateDouble()
    //     0xd2480c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd24810: RestoreReg r3
    //     0xd24810: ldr             x3, [SP], #8
    // 0xd24814: ldp             q0, q1, [SP], #0x20
    // 0xd24818: b               #0xd2421c
    // 0xd2481c: SaveReg d0
    //     0xd2481c: str             q0, [SP, #-0x10]!
    // 0xd24820: SaveReg r2
    //     0xd24820: str             x2, [SP, #-8]!
    // 0xd24824: r0 = AllocateDouble()
    //     0xd24824: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd24828: RestoreReg r2
    //     0xd24828: ldr             x2, [SP], #8
    // 0xd2482c: RestoreReg d0
    //     0xd2482c: ldr             q0, [SP], #0x10
    // 0xd24830: b               #0xd2426c
    // 0xd24834: stp             q0, q2, [SP, #-0x20]!
    // 0xd24838: r0 = AllocateDouble()
    //     0xd24838: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd2483c: ldp             q0, q2, [SP], #0x20
    // 0xd24840: b               #0xd242fc
    // 0xd24844: SaveReg d0
    //     0xd24844: str             q0, [SP, #-0x10]!
    // 0xd24848: SaveReg r2
    //     0xd24848: str             x2, [SP, #-8]!
    // 0xd2484c: r0 = AllocateDouble()
    //     0xd2484c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd24850: RestoreReg r2
    //     0xd24850: ldr             x2, [SP], #8
    // 0xd24854: RestoreReg d0
    //     0xd24854: ldr             q0, [SP], #0x10
    // 0xd24858: b               #0xd2434c
    // 0xd2485c: SaveReg d2
    //     0xd2485c: str             q2, [SP, #-0x10]!
    // 0xd24860: r0 = AllocateDouble()
    //     0xd24860: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd24864: RestoreReg d2
    //     0xd24864: ldr             q2, [SP], #0x10
    // 0xd24868: b               #0xd247c8
  }
  [closure] void _handleStatusChanged(dynamic, AnimationStatus) {
    // ** addr: 0xd253e8, size: 0x3c
    // 0xd253e8: EnterFrame
    //     0xd253e8: stp             fp, lr, [SP, #-0x10]!
    //     0xd253ec: mov             fp, SP
    // 0xd253f0: ldr             x0, [fp, #0x18]
    // 0xd253f4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd253f4: ldur            w1, [x0, #0x17]
    // 0xd253f8: DecompressPointer r1
    //     0xd253f8: add             x1, x1, HEAP, lsl #32
    // 0xd253fc: CheckStackOverflow
    //     0xd253fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd25400: cmp             SP, x16
    //     0xd25404: b.ls            #0xd2541c
    // 0xd25408: ldr             x2, [fp, #0x10]
    // 0xd2540c: r0 = _handleStatusChanged()
    //     0xd2540c: bl              #0xd25424  ; [package:flutter/src/material/ink_sparkle.dart] InkSparkle::_handleStatusChanged
    // 0xd25410: LeaveFrame
    //     0xd25410: mov             SP, fp
    //     0xd25414: ldp             fp, lr, [SP], #0x10
    // 0xd25418: ret
    //     0xd25418: ret             
    // 0xd2541c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd2541c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd25420: b               #0xd25408
  }
  _ _handleStatusChanged(/* No info */) {
    // ** addr: 0xd25424, size: 0x3c
    // 0xd25424: EnterFrame
    //     0xd25424: stp             fp, lr, [SP, #-0x10]!
    //     0xd25428: mov             fp, SP
    // 0xd2542c: CheckStackOverflow
    //     0xd2542c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd25430: cmp             SP, x16
    //     0xd25434: b.ls            #0xd25458
    // 0xd25438: r16 = Instance_AnimationStatus
    //     0xd25438: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0xd2543c: cmp             w2, w16
    // 0xd25440: b.ne            #0xd25448
    // 0xd25444: r0 = dispose()
    //     0xd25444: bl              #0x119e87c  ; [package:flutter/src/material/ink_sparkle.dart] InkSparkle::dispose
    // 0xd25448: r0 = Null
    //     0xd25448: mov             x0, NULL
    // 0xd2544c: LeaveFrame
    //     0xd2544c: mov             SP, fp
    //     0xd25450: ldp             fp, lr, [SP], #0x10
    // 0xd25454: ret
    //     0xd25454: ret             
    // 0xd25458: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd25458: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd2545c: b               #0xd25438
  }
  _ dispose(/* No info */) {
    // ** addr: 0x119e87c, size: 0xac
    // 0x119e87c: EnterFrame
    //     0x119e87c: stp             fp, lr, [SP, #-0x10]!
    //     0x119e880: mov             fp, SP
    // 0x119e884: AllocStack(0x8)
    //     0x119e884: sub             SP, SP, #8
    // 0x119e888: SetupParameters(InkSparkle this /* r1 => r0, fp-0x8 */)
    //     0x119e888: mov             x0, x1
    //     0x119e88c: stur            x1, [fp, #-8]
    // 0x119e890: CheckStackOverflow
    //     0x119e890: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119e894: cmp             SP, x16
    //     0x119e898: b.ls            #0x119e908
    // 0x119e89c: LoadField: r1 = r0->field_1b
    //     0x119e89c: ldur            w1, [x0, #0x1b]
    // 0x119e8a0: DecompressPointer r1
    //     0x119e8a0: add             x1, x1, HEAP, lsl #32
    // 0x119e8a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x119e8a8: cmp             w1, w16
    // 0x119e8ac: b.eq            #0x119e910
    // 0x119e8b0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x119e8b0: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x119e8b4: r0 = stop()
    //     0x119e8b4: bl              #0x82eb24  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x119e8b8: ldur            x0, [fp, #-8]
    // 0x119e8bc: LoadField: r1 = r0->field_1b
    //     0x119e8bc: ldur            w1, [x0, #0x1b]
    // 0x119e8c0: DecompressPointer r1
    //     0x119e8c0: add             x1, x1, HEAP, lsl #32
    // 0x119e8c4: r0 = dispose()
    //     0x119e8c4: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x119e8c8: ldur            x0, [fp, #-8]
    // 0x119e8cc: LoadField: r1 = r0->field_53
    //     0x119e8cc: ldur            w1, [x0, #0x53]
    // 0x119e8d0: DecompressPointer r1
    //     0x119e8d0: add             x1, x1, HEAP, lsl #32
    // 0x119e8d4: tbnz            w1, #4, #0x119e8f0
    // 0x119e8d8: LoadField: r1 = r0->field_4f
    //     0x119e8d8: ldur            w1, [x0, #0x4f]
    // 0x119e8dc: DecompressPointer r1
    //     0x119e8dc: add             x1, x1, HEAP, lsl #32
    // 0x119e8e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x119e8e4: cmp             w1, w16
    // 0x119e8e8: b.eq            #0x119e91c
    // 0x119e8ec: r0 = dispose()
    //     0x119e8ec: bl              #0x1241d7c  ; [dart:ui] FragmentShader::dispose
    // 0x119e8f0: ldur            x1, [fp, #-8]
    // 0x119e8f4: r0 = dispose()
    //     0x119e8f4: bl              #0xf786a8  ; [package:flutter/src/material/material.dart] InkFeature::dispose
    // 0x119e8f8: r0 = Null
    //     0x119e8f8: mov             x0, NULL
    // 0x119e8fc: LeaveFrame
    //     0x119e8fc: mov             SP, fp
    //     0x119e900: ldp             fp, lr, [SP], #0x10
    // 0x119e904: ret
    //     0x119e904: ret             
    // 0x119e908: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119e908: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119e90c: b               #0x119e89c
    // 0x119e910: r9 = _animationController
    //     0x119e910: add             x9, PP, #0x99, lsl #12  ; [pp+0x995f0] Field <InkSparkle._animationController@756321118>: late (offset: 0x1c)
    //     0x119e914: ldr             x9, [x9, #0x5f0]
    // 0x119e918: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x119e918: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x119e91c: r9 = _fragmentShader
    //     0x119e91c: add             x9, PP, #0x99, lsl #12  ; [pp+0x995f8] Field <InkSparkle._fragmentShader@756321118>: late final (offset: 0x50)
    //     0x119e920: ldr             x9, [x9, #0x5f8]
    // 0x119e924: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x119e924: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ paintFeature(/* No info */) {
    // ** addr: 0x12db064, size: 0x2e4
    // 0x12db064: EnterFrame
    //     0x12db064: stp             fp, lr, [SP, #-0x10]!
    //     0x12db068: mov             fp, SP
    // 0x12db06c: AllocStack(0x50)
    //     0x12db06c: sub             SP, SP, #0x50
    // 0x12db070: SetupParameters(InkSparkle this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x12db070: mov             x0, x1
    //     0x12db074: stur            x1, [fp, #-8]
    //     0x12db078: stur            x2, [fp, #-0x10]
    //     0x12db07c: stur            x3, [fp, #-0x18]
    // 0x12db080: CheckStackOverflow
    //     0x12db080: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12db084: cmp             SP, x16
    //     0x12db088: b.ls            #0x12db328
    // 0x12db08c: r1 = LoadStaticField(0xcb0)
    //     0x12db08c: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x12db090: ldr             x1, [x1, #0x1960]
    // 0x12db094: cmp             w1, NULL
    // 0x12db098: b.ne            #0x12db0ac
    // 0x12db09c: r0 = Null
    //     0x12db09c: mov             x0, NULL
    // 0x12db0a0: LeaveFrame
    //     0x12db0a0: mov             SP, fp
    //     0x12db0a4: ldp             fp, lr, [SP], #0x10
    // 0x12db0a8: ret
    //     0x12db0a8: ret             
    // 0x12db0ac: LoadField: r4 = r0->field_53
    //     0x12db0ac: ldur            w4, [x0, #0x53]
    // 0x12db0b0: DecompressPointer r4
    //     0x12db0b0: add             x4, x4, HEAP, lsl #32
    // 0x12db0b4: tbz             w4, #4, #0x12db0fc
    // 0x12db0b8: r0 = fragmentShader()
    //     0x12db0b8: bl              #0xe0ea54  ; [dart:ui] FragmentProgram::fragmentShader
    // 0x12db0bc: ldur            x2, [fp, #-8]
    // 0x12db0c0: LoadField: r1 = r2->field_4f
    //     0x12db0c0: ldur            w1, [x2, #0x4f]
    // 0x12db0c4: DecompressPointer r1
    //     0x12db0c4: add             x1, x1, HEAP, lsl #32
    // 0x12db0c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12db0cc: cmp             w1, w16
    // 0x12db0d0: b.ne            #0x12db2e4
    // 0x12db0d4: r1 = true
    //     0x12db0d4: add             x1, NULL, #0x20  ; true
    // 0x12db0d8: StoreField: r2->field_4f = r0
    //     0x12db0d8: stur            w0, [x2, #0x4f]
    //     0x12db0dc: ldurb           w16, [x2, #-1]
    //     0x12db0e0: ldurb           w17, [x0, #-1]
    //     0x12db0e4: and             x16, x17, x16, lsr #2
    //     0x12db0e8: tst             x16, HEAP, lsr #32
    //     0x12db0ec: b.eq            #0x12db0f4
    //     0x12db0f0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x12db0f4: StoreField: r2->field_53 = r1
    //     0x12db0f4: stur            w1, [x2, #0x53]
    // 0x12db0f8: b               #0x12db100
    // 0x12db0fc: mov             x2, x0
    // 0x12db100: ldur            x0, [fp, #-0x10]
    // 0x12db104: LoadField: r1 = r0->field_7
    //     0x12db104: ldur            w1, [x0, #7]
    // 0x12db108: DecompressPointer r1
    //     0x12db108: add             x1, x1, HEAP, lsl #32
    // 0x12db10c: cmp             w1, NULL
    // 0x12db110: b.eq            #0x12db330
    // 0x12db114: LoadField: r3 = r1->field_7
    //     0x12db114: ldur            x3, [x1, #7]
    // 0x12db118: ldr             x1, [x3]
    // 0x12db11c: cbz             x1, #0x12db2f8
    // 0x12db120: mov             x3, x1
    // 0x12db124: stur            x3, [fp, #-0x20]
    // 0x12db128: r1 = <Never>
    //     0x12db128: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12db12c: r0 = Pointer()
    //     0x12db12c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12db130: mov             x1, x0
    // 0x12db134: ldur            x0, [fp, #-0x20]
    // 0x12db138: StoreField: r1->field_7 = r0
    //     0x12db138: stur            x0, [x1, #7]
    // 0x12db13c: r0 = _save$Method$FfiNative()
    //     0x12db13c: bl              #0xb74adc  ; [dart:ui] _NativeCanvas::_save$Method$FfiNative
    // 0x12db140: ldur            x1, [fp, #-8]
    // 0x12db144: ldur            x2, [fp, #-0x10]
    // 0x12db148: ldur            x3, [fp, #-0x18]
    // 0x12db14c: r0 = _transformCanvas()
    //     0x12db14c: bl              #0x12dbf84  ; [package:flutter/src/material/ink_sparkle.dart] InkSparkle::_transformCanvas
    // 0x12db150: ldur            x0, [fp, #-8]
    // 0x12db154: LoadField: r4 = r0->field_47
    //     0x12db154: ldur            w4, [x0, #0x47]
    // 0x12db158: DecompressPointer r4
    //     0x12db158: add             x4, x4, HEAP, lsl #32
    // 0x12db15c: stur            x4, [fp, #-0x18]
    // 0x12db160: cmp             w4, NULL
    // 0x12db164: b.eq            #0x12db190
    // 0x12db168: LoadField: r7 = r0->field_4b
    //     0x12db168: ldur            w7, [x0, #0x4b]
    // 0x12db16c: DecompressPointer r7
    //     0x12db16c: add             x7, x7, HEAP, lsl #32
    // 0x12db170: ArrayLoad: r6 = r0[0]  ; List_4
    //     0x12db170: ldur            w6, [x0, #0x17]
    // 0x12db174: DecompressPointer r6
    //     0x12db174: add             x6, x6, HEAP, lsl #32
    // 0x12db178: LoadField: r2 = r0->field_3b
    //     0x12db178: ldur            w2, [x0, #0x3b]
    // 0x12db17c: DecompressPointer r2
    //     0x12db17c: add             x2, x2, HEAP, lsl #32
    // 0x12db180: mov             x1, x0
    // 0x12db184: ldur            x3, [fp, #-0x10]
    // 0x12db188: mov             x5, x4
    // 0x12db18c: r0 = _clipCanvas()
    //     0x12db18c: bl              #0x12dbc94  ; [package:flutter/src/material/ink_sparkle.dart] InkSparkle::_clipCanvas
    // 0x12db190: ldur            x0, [fp, #-8]
    // 0x12db194: ldur            x2, [fp, #-0x18]
    // 0x12db198: mov             x1, x0
    // 0x12db19c: r0 = _updateFragmentShader()
    //     0x12db19c: bl              #0x12db348  ; [package:flutter/src/material/ink_sparkle.dart] InkSparkle::_updateFragmentShader
    // 0x12db1a0: r16 = 136
    //     0x12db1a0: mov             x16, #0x88
    // 0x12db1a4: stp             x16, NULL, [SP]
    // 0x12db1a8: r0 = ByteData()
    //     0x12db1a8: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x12db1ac: stur            x0, [fp, #-0x28]
    // 0x12db1b0: r0 = Paint()
    //     0x12db1b0: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x12db1b4: ldur            x3, [fp, #-0x28]
    // 0x12db1b8: stur            x0, [fp, #-0x38]
    // 0x12db1bc: StoreField: r0->field_7 = r3
    //     0x12db1bc: stur            w3, [x0, #7]
    // 0x12db1c0: ldur            x1, [fp, #-8]
    // 0x12db1c4: LoadField: r2 = r1->field_4f
    //     0x12db1c4: ldur            w2, [x1, #0x4f]
    // 0x12db1c8: DecompressPointer r2
    //     0x12db1c8: add             x2, x2, HEAP, lsl #32
    // 0x12db1cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12db1d0: cmp             w2, w16
    // 0x12db1d4: b.eq            #0x12db334
    // 0x12db1d8: mov             x1, x0
    // 0x12db1dc: stur            x2, [fp, #-0x30]
    // 0x12db1e0: r0 = _ensureObjectsInitialized()
    //     0x12db1e0: bl              #0xaf5568  ; [dart:ui] Paint::_ensureObjectsInitialized
    // 0x12db1e4: r1 = LoadClassIdInstr(r0)
    //     0x12db1e4: ldur            x1, [x0, #-1]
    //     0x12db1e8: ubfx            x1, x1, #0xc, #0x14
    // 0x12db1ec: stp             xzr, x0, [SP, #8]
    // 0x12db1f0: ldur            x16, [fp, #-0x30]
    // 0x12db1f4: str             x16, [SP]
    // 0x12db1f8: mov             x0, x1
    // 0x12db1fc: r0 = GDT[cid_x0 + 0x18dc8]()
    //     0x12db1fc: mov             x17, #0x8dc8
    //     0x12db200: movk            x17, #1, lsl #16
    //     0x12db204: add             lr, x0, x17
    //     0x12db208: ldr             lr, [x21, lr, lsl #3]
    //     0x12db20c: blr             lr
    // 0x12db210: ldur            x0, [fp, #-0x18]
    // 0x12db214: cmp             w0, NULL
    // 0x12db218: b.eq            #0x12db240
    // 0x12db21c: str             x0, [SP]
    // 0x12db220: ClosureCall
    //     0x12db220: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x12db224: ldur            x2, [x0, #0x1f]
    //     0x12db228: blr             x2
    // 0x12db22c: ldur            x1, [fp, #-0x10]
    // 0x12db230: mov             x2, x0
    // 0x12db234: ldur            x3, [fp, #-0x38]
    // 0x12db238: r0 = drawRect()
    //     0x12db238: bl              #0xb704c8  ; [dart:ui] _NativeCanvas::drawRect
    // 0x12db23c: b               #0x12db294
    // 0x12db240: ldur            x2, [fp, #-0x10]
    // 0x12db244: ldur            x0, [fp, #-0x38]
    // 0x12db248: LoadField: r3 = r0->field_b
    //     0x12db248: ldur            w3, [x0, #0xb]
    // 0x12db24c: DecompressPointer r3
    //     0x12db24c: add             x3, x3, HEAP, lsl #32
    // 0x12db250: stur            x3, [fp, #-8]
    // 0x12db254: LoadField: r0 = r2->field_7
    //     0x12db254: ldur            w0, [x2, #7]
    // 0x12db258: DecompressPointer r0
    //     0x12db258: add             x0, x0, HEAP, lsl #32
    // 0x12db25c: cmp             w0, NULL
    // 0x12db260: b.eq            #0x12db340
    // 0x12db264: LoadField: r1 = r0->field_7
    //     0x12db264: ldur            x1, [x0, #7]
    // 0x12db268: ldr             x0, [x1]
    // 0x12db26c: cbz             x0, #0x12db308
    // 0x12db270: stur            x0, [fp, #-0x20]
    // 0x12db274: r1 = <Never>
    //     0x12db274: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12db278: r0 = Pointer()
    //     0x12db278: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12db27c: mov             x1, x0
    // 0x12db280: ldur            x0, [fp, #-0x20]
    // 0x12db284: StoreField: r1->field_7 = r0
    //     0x12db284: stur            x0, [x1, #7]
    // 0x12db288: ldur            x2, [fp, #-8]
    // 0x12db28c: ldur            x3, [fp, #-0x28]
    // 0x12db290: r0 = __drawPaint$Method$FfiNative()
    //     0x12db290: bl              #0xc1b7ac  ; [dart:ui] _NativeCanvas::__drawPaint$Method$FfiNative
    // 0x12db294: ldur            x0, [fp, #-0x10]
    // 0x12db298: LoadField: r1 = r0->field_7
    //     0x12db298: ldur            w1, [x0, #7]
    // 0x12db29c: DecompressPointer r1
    //     0x12db29c: add             x1, x1, HEAP, lsl #32
    // 0x12db2a0: cmp             w1, NULL
    // 0x12db2a4: b.eq            #0x12db344
    // 0x12db2a8: LoadField: r2 = r1->field_7
    //     0x12db2a8: ldur            x2, [x1, #7]
    // 0x12db2ac: ldr             x1, [x2]
    // 0x12db2b0: cbz             x1, #0x12db318
    // 0x12db2b4: mov             x2, x1
    // 0x12db2b8: stur            x2, [fp, #-0x20]
    // 0x12db2bc: r1 = <Never>
    //     0x12db2bc: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12db2c0: r0 = Pointer()
    //     0x12db2c0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12db2c4: mov             x1, x0
    // 0x12db2c8: ldur            x0, [fp, #-0x20]
    // 0x12db2cc: StoreField: r1->field_7 = r0
    //     0x12db2cc: stur            x0, [x1, #7]
    // 0x12db2d0: r0 = _restore$Method$FfiNative()
    //     0x12db2d0: bl              #0xb74908  ; [dart:ui] _NativeCanvas::_restore$Method$FfiNative
    // 0x12db2d4: r0 = Null
    //     0x12db2d4: mov             x0, NULL
    // 0x12db2d8: LeaveFrame
    //     0x12db2d8: mov             SP, fp
    //     0x12db2dc: ldp             fp, lr, [SP], #0x10
    // 0x12db2e0: ret
    //     0x12db2e0: ret             
    // 0x12db2e4: r16 = "_fragmentShader@756321118"
    //     0x12db2e4: add             x16, PP, #0xab, lsl #12  ; [pp+0xab0a8] "_fragmentShader@756321118"
    //     0x12db2e8: ldr             x16, [x16, #0xa8]
    // 0x12db2ec: str             x16, [SP]
    // 0x12db2f0: r0 = _throwFieldAlreadyInitialized()
    //     0x12db2f0: bl              #0x82b720  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x12db2f4: brk             #0
    // 0x12db2f8: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12db2f8: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12db2fc: str             x16, [SP]
    // 0x12db300: r0 = _throwNew()
    //     0x12db300: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12db304: brk             #0
    // 0x12db308: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12db308: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12db30c: str             x16, [SP]
    // 0x12db310: r0 = _throwNew()
    //     0x12db310: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12db314: brk             #0
    // 0x12db318: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12db318: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12db31c: str             x16, [SP]
    // 0x12db320: r0 = _throwNew()
    //     0x12db320: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12db324: brk             #0
    // 0x12db328: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12db328: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12db32c: b               #0x12db08c
    // 0x12db330: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12db330: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12db334: r9 = _fragmentShader
    //     0x12db334: add             x9, PP, #0x99, lsl #12  ; [pp+0x995f8] Field <InkSparkle._fragmentShader@756321118>: late final (offset: 0x50)
    //     0x12db338: ldr             x9, [x9, #0x5f8]
    // 0x12db33c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12db33c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12db340: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12db340: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12db344: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12db344: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _updateFragmentShader(/* No info */) {
    // ** addr: 0x12db348, size: 0x8d4
    // 0x12db348: EnterFrame
    //     0x12db348: stp             fp, lr, [SP, #-0x10]!
    //     0x12db34c: mov             fp, SP
    // 0x12db350: AllocStack(0x40)
    //     0x12db350: sub             SP, SP, #0x40
    // 0x12db354: SetupParameters(InkSparkle this /* r1 => r3, fp-0x10 */)
    //     0x12db354: mov             x3, x1
    //     0x12db358: stur            x1, [fp, #-0x10]
    // 0x12db35c: CheckStackOverflow
    //     0x12db35c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12db360: cmp             SP, x16
    //     0x12db364: b.ls            #0x12dbbc4
    // 0x12db368: LoadField: r4 = r3->field_2f
    //     0x12db368: ldur            w4, [x3, #0x2f]
    // 0x12db36c: DecompressPointer r4
    //     0x12db36c: add             x4, x4, HEAP, lsl #32
    // 0x12db370: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12db374: cmp             w4, w16
    // 0x12db378: b.eq            #0x12dbbcc
    // 0x12db37c: stur            x4, [fp, #-8]
    // 0x12db380: LoadField: r0 = r3->field_23
    //     0x12db380: ldur            w0, [x3, #0x23]
    // 0x12db384: DecompressPointer r0
    //     0x12db384: add             x0, x0, HEAP, lsl #32
    // 0x12db388: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12db38c: cmp             w0, w16
    // 0x12db390: b.eq            #0x12dbbd8
    // 0x12db394: LoadField: r1 = r0->field_f
    //     0x12db394: ldur            w1, [x0, #0xf]
    // 0x12db398: DecompressPointer r1
    //     0x12db398: add             x1, x1, HEAP, lsl #32
    // 0x12db39c: LoadField: r2 = r0->field_b
    //     0x12db39c: ldur            w2, [x0, #0xb]
    // 0x12db3a0: DecompressPointer r2
    //     0x12db3a0: add             x2, x2, HEAP, lsl #32
    // 0x12db3a4: r0 = LoadClassIdInstr(r1)
    //     0x12db3a4: ldur            x0, [x1, #-1]
    //     0x12db3a8: ubfx            x0, x0, #0xc, #0x14
    // 0x12db3ac: r0 = GDT[cid_x0 + 0x80ed]()
    //     0x12db3ac: mov             x17, #0x80ed
    //     0x12db3b0: add             lr, x0, x17
    //     0x12db3b4: ldr             lr, [x21, lr, lsl #3]
    //     0x12db3b8: blr             lr
    // 0x12db3bc: mov             x1, x0
    // 0x12db3c0: ldur            x0, [fp, #-8]
    // 0x12db3c4: LoadField: d0 = r0->field_7
    //     0x12db3c4: ldur            d0, [x0, #7]
    // 0x12db3c8: LoadField: d1 = r1->field_7
    //     0x12db3c8: ldur            d1, [x1, #7]
    // 0x12db3cc: fadd            d2, d0, d1
    // 0x12db3d0: stur            d2, [fp, #-0x38]
    // 0x12db3d4: d0 = 0.024544
    //     0x12db3d4: add             x17, PP, #0xab, lsl #12  ; [pp+0xab0c0] IMM: double(0.02454369260617026) from 0x3f9921fb54442d18
    //     0x12db3d8: ldr             d0, [x17, #0xc0]
    // 0x12db3dc: fmul            d1, d2, d0
    // 0x12db3e0: d0 = 5.340708
    //     0x12db3e0: add             x17, PP, #0xab, lsl #12  ; [pp+0xab0c8] IMM: double(5.340707511102648) from 0x40155ce26e06bfee
    //     0x12db3e4: ldr             d0, [x17, #0xc8]
    // 0x12db3e8: fadd            d3, d1, d0
    // 0x12db3ec: stur            d3, [fp, #-0x30]
    // 0x12db3f0: d0 = -0.024544
    //     0x12db3f0: add             x17, PP, #0xab, lsl #12  ; [pp+0xab0d0] IMM: double(-0.02454369260617026) from 0xbf9921fb54442d18
    //     0x12db3f4: ldr             d0, [x17, #0xd0]
    // 0x12db3f8: fmul            d4, d2, d0
    // 0x12db3fc: d0 = 6.283185
    //     0x12db3fc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13298] IMM: double(6.283185307179586) from 0x401921fb54442d18
    //     0x12db400: ldr             d0, [x17, #0x298]
    // 0x12db404: fadd            d5, d4, d0
    // 0x12db408: stur            d5, [fp, #-0x28]
    // 0x12db40c: d0 = 8.639380
    //     0x12db40c: add             x17, PP, #0xab, lsl #12  ; [pp+0xab0d8] IMM: double(8.63937979737193) from 0x4021475cc9eedf00
    //     0x12db410: ldr             d0, [x17, #0xd8]
    // 0x12db414: fadd            d4, d1, d0
    // 0x12db418: ldur            x2, [fp, #-0x10]
    // 0x12db41c: stur            d4, [fp, #-0x20]
    // 0x12db420: LoadField: r3 = r2->field_4f
    //     0x12db420: ldur            w3, [x2, #0x4f]
    // 0x12db424: DecompressPointer r3
    //     0x12db424: add             x3, x3, HEAP, lsl #32
    // 0x12db428: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12db42c: cmp             w3, w16
    // 0x12db430: b.eq            #0x12dbbe4
    // 0x12db434: stur            x3, [fp, #-0x18]
    // 0x12db438: LoadField: r4 = r2->field_33
    //     0x12db438: ldur            w4, [x2, #0x33]
    // 0x12db43c: DecompressPointer r4
    //     0x12db43c: add             x4, x4, HEAP, lsl #32
    // 0x12db440: stur            x4, [fp, #-8]
    // 0x12db444: r0 = LoadClassIdInstr(r4)
    //     0x12db444: ldur            x0, [x4, #-1]
    //     0x12db448: ubfx            x0, x0, #0xc, #0x14
    // 0x12db44c: mov             x1, x4
    // 0x12db450: r0 = GDT[cid_x0 + 0x30c2]()
    //     0x12db450: mov             x17, #0x30c2
    //     0x12db454: add             lr, x0, x17
    //     0x12db458: ldr             lr, [x21, lr, lsl #3]
    //     0x12db45c: blr             lr
    // 0x12db460: scvtf           d0, x0
    // 0x12db464: d1 = 255.000000
    //     0x12db464: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x12db468: fdiv            d2, d0, d1
    // 0x12db46c: ldur            x1, [fp, #-0x18]
    // 0x12db470: mov             v0.16b, v2.16b
    // 0x12db474: r2 = 0
    //     0x12db474: mov             x2, #0
    // 0x12db478: r0 = setFloat()
    //     0x12db478: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12db47c: ldur            x2, [fp, #-8]
    // 0x12db480: r0 = LoadClassIdInstr(r2)
    //     0x12db480: ldur            x0, [x2, #-1]
    //     0x12db484: ubfx            x0, x0, #0xc, #0x14
    // 0x12db488: mov             x1, x2
    // 0x12db48c: r0 = GDT[cid_x0 + 0x343f]()
    //     0x12db48c: mov             x17, #0x343f
    //     0x12db490: add             lr, x0, x17
    //     0x12db494: ldr             lr, [x21, lr, lsl #3]
    //     0x12db498: blr             lr
    // 0x12db49c: scvtf           d0, x0
    // 0x12db4a0: d1 = 255.000000
    //     0x12db4a0: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x12db4a4: fdiv            d2, d0, d1
    // 0x12db4a8: ldur            x1, [fp, #-0x18]
    // 0x12db4ac: mov             v0.16b, v2.16b
    // 0x12db4b0: r2 = 1
    //     0x12db4b0: mov             x2, #1
    // 0x12db4b4: r0 = setFloat()
    //     0x12db4b4: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12db4b8: ldur            x2, [fp, #-8]
    // 0x12db4bc: r0 = LoadClassIdInstr(r2)
    //     0x12db4bc: ldur            x0, [x2, #-1]
    //     0x12db4c0: ubfx            x0, x0, #0xc, #0x14
    // 0x12db4c4: mov             x1, x2
    // 0x12db4c8: r0 = GDT[cid_x0 + 0x362a]()
    //     0x12db4c8: mov             x17, #0x362a
    //     0x12db4cc: add             lr, x0, x17
    //     0x12db4d0: ldr             lr, [x21, lr, lsl #3]
    //     0x12db4d4: blr             lr
    // 0x12db4d8: scvtf           d0, x0
    // 0x12db4dc: d1 = 255.000000
    //     0x12db4dc: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x12db4e0: fdiv            d2, d0, d1
    // 0x12db4e4: ldur            x1, [fp, #-0x18]
    // 0x12db4e8: mov             v0.16b, v2.16b
    // 0x12db4ec: r2 = 2
    //     0x12db4ec: mov             x2, #2
    // 0x12db4f0: r0 = setFloat()
    //     0x12db4f0: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12db4f4: ldur            x1, [fp, #-8]
    // 0x12db4f8: r0 = LoadClassIdInstr(r1)
    //     0x12db4f8: ldur            x0, [x1, #-1]
    //     0x12db4fc: ubfx            x0, x0, #0xc, #0x14
    // 0x12db500: r0 = GDT[cid_x0 + -0xfc0]()
    //     0x12db500: sub             lr, x0, #0xfc0
    //     0x12db504: ldr             lr, [x21, lr, lsl #3]
    //     0x12db508: blr             lr
    // 0x12db50c: scvtf           d0, x0
    // 0x12db510: d1 = 255.000000
    //     0x12db510: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x12db514: fdiv            d2, d0, d1
    // 0x12db518: ldur            x1, [fp, #-0x18]
    // 0x12db51c: mov             v0.16b, v2.16b
    // 0x12db520: r2 = 3
    //     0x12db520: mov             x2, #3
    // 0x12db524: r0 = setFloat()
    //     0x12db524: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12db528: ldur            x3, [fp, #-0x10]
    // 0x12db52c: LoadField: r0 = r3->field_27
    //     0x12db52c: ldur            w0, [x3, #0x27]
    // 0x12db530: DecompressPointer r0
    //     0x12db530: add             x0, x0, HEAP, lsl #32
    // 0x12db534: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12db538: cmp             w0, w16
    // 0x12db53c: b.eq            #0x12dbbf0
    // 0x12db540: LoadField: r1 = r0->field_f
    //     0x12db540: ldur            w1, [x0, #0xf]
    // 0x12db544: DecompressPointer r1
    //     0x12db544: add             x1, x1, HEAP, lsl #32
    // 0x12db548: LoadField: r2 = r0->field_b
    //     0x12db548: ldur            w2, [x0, #0xb]
    // 0x12db54c: DecompressPointer r2
    //     0x12db54c: add             x2, x2, HEAP, lsl #32
    // 0x12db550: r0 = LoadClassIdInstr(r1)
    //     0x12db550: ldur            x0, [x1, #-1]
    //     0x12db554: ubfx            x0, x0, #0xc, #0x14
    // 0x12db558: r0 = GDT[cid_x0 + 0x80ed]()
    //     0x12db558: mov             x17, #0x80ed
    //     0x12db55c: add             lr, x0, x17
    //     0x12db560: ldr             lr, [x21, lr, lsl #3]
    //     0x12db564: blr             lr
    // 0x12db568: LoadField: d0 = r0->field_7
    //     0x12db568: ldur            d0, [x0, #7]
    // 0x12db56c: ldur            x1, [fp, #-0x18]
    // 0x12db570: r2 = 4
    //     0x12db570: mov             x2, #4
    // 0x12db574: r0 = setFloat()
    //     0x12db574: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12db578: ldur            x3, [fp, #-0x10]
    // 0x12db57c: LoadField: r0 = r3->field_2b
    //     0x12db57c: ldur            w0, [x3, #0x2b]
    // 0x12db580: DecompressPointer r0
    //     0x12db580: add             x0, x0, HEAP, lsl #32
    // 0x12db584: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12db588: cmp             w0, w16
    // 0x12db58c: b.eq            #0x12dbbfc
    // 0x12db590: LoadField: r1 = r0->field_f
    //     0x12db590: ldur            w1, [x0, #0xf]
    // 0x12db594: DecompressPointer r1
    //     0x12db594: add             x1, x1, HEAP, lsl #32
    // 0x12db598: LoadField: r2 = r0->field_b
    //     0x12db598: ldur            w2, [x0, #0xb]
    // 0x12db59c: DecompressPointer r2
    //     0x12db59c: add             x2, x2, HEAP, lsl #32
    // 0x12db5a0: r0 = LoadClassIdInstr(r1)
    //     0x12db5a0: ldur            x0, [x1, #-1]
    //     0x12db5a4: ubfx            x0, x0, #0xc, #0x14
    // 0x12db5a8: r0 = GDT[cid_x0 + 0x80ed]()
    //     0x12db5a8: mov             x17, #0x80ed
    //     0x12db5ac: add             lr, x0, x17
    //     0x12db5b0: ldr             lr, [x21, lr, lsl #3]
    //     0x12db5b4: blr             lr
    // 0x12db5b8: LoadField: d0 = r0->field_7
    //     0x12db5b8: ldur            d0, [x0, #7]
    // 0x12db5bc: ldur            x1, [fp, #-0x18]
    // 0x12db5c0: r2 = 5
    //     0x12db5c0: mov             x2, #5
    // 0x12db5c4: r0 = setFloat()
    //     0x12db5c4: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12db5c8: ldur            x1, [fp, #-0x18]
    // 0x12db5cc: r2 = 6
    //     0x12db5cc: mov             x2, #6
    // 0x12db5d0: d0 = 1.000000
    //     0x12db5d0: fmov            d0, #1.00000000
    // 0x12db5d4: r0 = setFloat()
    //     0x12db5d4: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12db5d8: ldur            x3, [fp, #-0x10]
    // 0x12db5dc: LoadField: r0 = r3->field_23
    //     0x12db5dc: ldur            w0, [x3, #0x23]
    // 0x12db5e0: DecompressPointer r0
    //     0x12db5e0: add             x0, x0, HEAP, lsl #32
    // 0x12db5e4: LoadField: r1 = r0->field_f
    //     0x12db5e4: ldur            w1, [x0, #0xf]
    // 0x12db5e8: DecompressPointer r1
    //     0x12db5e8: add             x1, x1, HEAP, lsl #32
    // 0x12db5ec: LoadField: r2 = r0->field_b
    //     0x12db5ec: ldur            w2, [x0, #0xb]
    // 0x12db5f0: DecompressPointer r2
    //     0x12db5f0: add             x2, x2, HEAP, lsl #32
    // 0x12db5f4: r0 = LoadClassIdInstr(r1)
    //     0x12db5f4: ldur            x0, [x1, #-1]
    //     0x12db5f8: ubfx            x0, x0, #0xc, #0x14
    // 0x12db5fc: r0 = GDT[cid_x0 + 0x80ed]()
    //     0x12db5fc: mov             x17, #0x80ed
    //     0x12db600: add             lr, x0, x17
    //     0x12db604: ldr             lr, [x21, lr, lsl #3]
    //     0x12db608: blr             lr
    // 0x12db60c: LoadField: d0 = r0->field_7
    //     0x12db60c: ldur            d0, [x0, #7]
    // 0x12db610: ldur            x1, [fp, #-0x18]
    // 0x12db614: r2 = 7
    //     0x12db614: mov             x2, #7
    // 0x12db618: r0 = setFloat()
    //     0x12db618: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12db61c: ldur            x3, [fp, #-0x10]
    // 0x12db620: LoadField: r0 = r3->field_1f
    //     0x12db620: ldur            w0, [x3, #0x1f]
    // 0x12db624: DecompressPointer r0
    //     0x12db624: add             x0, x0, HEAP, lsl #32
    // 0x12db628: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12db62c: cmp             w0, w16
    // 0x12db630: b.eq            #0x12dbc08
    // 0x12db634: LoadField: r1 = r0->field_f
    //     0x12db634: ldur            w1, [x0, #0xf]
    // 0x12db638: DecompressPointer r1
    //     0x12db638: add             x1, x1, HEAP, lsl #32
    // 0x12db63c: LoadField: r2 = r0->field_b
    //     0x12db63c: ldur            w2, [x0, #0xb]
    // 0x12db640: DecompressPointer r2
    //     0x12db640: add             x2, x2, HEAP, lsl #32
    // 0x12db644: r0 = LoadClassIdInstr(r1)
    //     0x12db644: ldur            x0, [x1, #-1]
    //     0x12db648: ubfx            x0, x0, #0xc, #0x14
    // 0x12db64c: r0 = GDT[cid_x0 + 0x80ed]()
    //     0x12db64c: mov             x17, #0x80ed
    //     0x12db650: add             lr, x0, x17
    //     0x12db654: ldr             lr, [x21, lr, lsl #3]
    //     0x12db658: blr             lr
    // 0x12db65c: LoadField: r2 = r0->field_7
    //     0x12db65c: ldur            w2, [x0, #7]
    // 0x12db660: DecompressPointer r2
    //     0x12db660: add             x2, x2, HEAP, lsl #32
    // 0x12db664: LoadField: r0 = r2->field_13
    //     0x12db664: ldur            w0, [x2, #0x13]
    // 0x12db668: r1 = LoadInt32Instr(r0)
    //     0x12db668: sbfx            x1, x0, #1, #0x1f
    // 0x12db66c: mov             x0, x1
    // 0x12db670: r1 = 0
    //     0x12db670: mov             x1, #0
    // 0x12db674: cmp             x1, x0
    // 0x12db678: b.hs            #0x12dbc14
    // 0x12db67c: ArrayLoad: d0 = r2[0]  ; List_8
    //     0x12db67c: ldur            d0, [x2, #0x17]
    // 0x12db680: ldur            x1, [fp, #-0x18]
    // 0x12db684: r2 = 8
    //     0x12db684: mov             x2, #8
    // 0x12db688: r0 = setFloat()
    //     0x12db688: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12db68c: ldur            x3, [fp, #-0x10]
    // 0x12db690: LoadField: r0 = r3->field_1f
    //     0x12db690: ldur            w0, [x3, #0x1f]
    // 0x12db694: DecompressPointer r0
    //     0x12db694: add             x0, x0, HEAP, lsl #32
    // 0x12db698: LoadField: r1 = r0->field_f
    //     0x12db698: ldur            w1, [x0, #0xf]
    // 0x12db69c: DecompressPointer r1
    //     0x12db69c: add             x1, x1, HEAP, lsl #32
    // 0x12db6a0: LoadField: r2 = r0->field_b
    //     0x12db6a0: ldur            w2, [x0, #0xb]
    // 0x12db6a4: DecompressPointer r2
    //     0x12db6a4: add             x2, x2, HEAP, lsl #32
    // 0x12db6a8: r0 = LoadClassIdInstr(r1)
    //     0x12db6a8: ldur            x0, [x1, #-1]
    //     0x12db6ac: ubfx            x0, x0, #0xc, #0x14
    // 0x12db6b0: r0 = GDT[cid_x0 + 0x80ed]()
    //     0x12db6b0: mov             x17, #0x80ed
    //     0x12db6b4: add             lr, x0, x17
    //     0x12db6b8: ldr             lr, [x21, lr, lsl #3]
    //     0x12db6bc: blr             lr
    // 0x12db6c0: LoadField: r2 = r0->field_7
    //     0x12db6c0: ldur            w2, [x0, #7]
    // 0x12db6c4: DecompressPointer r2
    //     0x12db6c4: add             x2, x2, HEAP, lsl #32
    // 0x12db6c8: LoadField: r0 = r2->field_13
    //     0x12db6c8: ldur            w0, [x2, #0x13]
    // 0x12db6cc: r1 = LoadInt32Instr(r0)
    //     0x12db6cc: sbfx            x1, x0, #1, #0x1f
    // 0x12db6d0: mov             x0, x1
    // 0x12db6d4: r1 = 1
    //     0x12db6d4: mov             x1, #1
    // 0x12db6d8: cmp             x1, x0
    // 0x12db6dc: b.hs            #0x12dbc18
    // 0x12db6e0: LoadField: d0 = r2->field_1f
    //     0x12db6e0: ldur            d0, [x2, #0x1f]
    // 0x12db6e4: ldur            x1, [fp, #-0x18]
    // 0x12db6e8: r2 = 9
    //     0x12db6e8: mov             x2, #9
    // 0x12db6ec: r0 = setFloat()
    //     0x12db6ec: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12db6f0: ldur            x0, [fp, #-0x10]
    // 0x12db6f4: LoadField: d0 = r0->field_3f
    //     0x12db6f4: ldur            d0, [x0, #0x3f]
    // 0x12db6f8: ldur            x1, [fp, #-0x18]
    // 0x12db6fc: r2 = 10
    //     0x12db6fc: mov             x2, #0xa
    // 0x12db700: r0 = setFloat()
    //     0x12db700: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12db704: ldur            x1, [fp, #-0x10]
    // 0x12db708: r0 = _width()
    //     0x12db708: bl              #0x12dbc58  ; [package:flutter/src/material/ink_sparkle.dart] InkSparkle::_width
    // 0x12db70c: d1 = 1.000000
    //     0x12db70c: fmov            d1, #1.00000000
    // 0x12db710: fdiv            d2, d1, d0
    // 0x12db714: ldur            x1, [fp, #-0x18]
    // 0x12db718: mov             v0.16b, v2.16b
    // 0x12db71c: r2 = 11
    //     0x12db71c: mov             x2, #0xb
    // 0x12db720: r0 = setFloat()
    //     0x12db720: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12db724: ldur            x1, [fp, #-0x10]
    // 0x12db728: r0 = _height()
    //     0x12db728: bl              #0x12dbc1c  ; [package:flutter/src/material/ink_sparkle.dart] InkSparkle::_height
    // 0x12db72c: mov             v1.16b, v0.16b
    // 0x12db730: d0 = 1.000000
    //     0x12db730: fmov            d0, #1.00000000
    // 0x12db734: fdiv            d2, d0, d1
    // 0x12db738: ldur            x1, [fp, #-0x18]
    // 0x12db73c: mov             v0.16b, v2.16b
    // 0x12db740: r2 = 12
    //     0x12db740: mov             x2, #0xc
    // 0x12db744: r0 = setFloat()
    //     0x12db744: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12db748: ldur            x0, [fp, #-0x10]
    // 0x12db74c: LoadField: r2 = r0->field_b
    //     0x12db74c: ldur            w2, [x0, #0xb]
    // 0x12db750: DecompressPointer r2
    //     0x12db750: add             x2, x2, HEAP, lsl #32
    // 0x12db754: mov             x1, x2
    // 0x12db758: stur            x2, [fp, #-8]
    // 0x12db75c: r0 = size()
    //     0x12db75c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x12db760: LoadField: d0 = r0->field_7
    //     0x12db760: ldur            d0, [x0, #7]
    // 0x12db764: d1 = 2.100000
    //     0x12db764: add             x17, PP, #0xab, lsl #12  ; [pp+0xab0e0] IMM: double(2.1) from 0x4000cccccccccccd
    //     0x12db768: ldr             d1, [x17, #0xe0]
    // 0x12db76c: fdiv            d2, d1, d0
    // 0x12db770: ldur            x1, [fp, #-0x18]
    // 0x12db774: mov             v0.16b, v2.16b
    // 0x12db778: r2 = 13
    //     0x12db778: mov             x2, #0xd
    // 0x12db77c: r0 = setFloat()
    //     0x12db77c: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12db780: ldur            x1, [fp, #-8]
    // 0x12db784: r0 = size()
    //     0x12db784: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x12db788: LoadField: d0 = r0->field_f
    //     0x12db788: ldur            d0, [x0, #0xf]
    // 0x12db78c: d1 = 2.100000
    //     0x12db78c: add             x17, PP, #0xab, lsl #12  ; [pp+0xab0e0] IMM: double(2.1) from 0x4000cccccccccccd
    //     0x12db790: ldr             d1, [x17, #0xe0]
    // 0x12db794: fdiv            d2, d1, d0
    // 0x12db798: ldur            x1, [fp, #-0x18]
    // 0x12db79c: mov             v0.16b, v2.16b
    // 0x12db7a0: r2 = 14
    //     0x12db7a0: mov             x2, #0xe
    // 0x12db7a4: r0 = setFloat()
    //     0x12db7a4: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12db7a8: ldur            d1, [fp, #-0x38]
    // 0x12db7ac: d0 = 1000.000000
    //     0x12db7ac: add             x17, PP, #0x16, lsl #12  ; [pp+0x16a58] IMM: double(1000) from 0x408f400000000000
    //     0x12db7b0: ldr             d0, [x17, #0xa58]
    // 0x12db7b4: fdiv            d2, d1, d0
    // 0x12db7b8: ldur            x1, [fp, #-0x18]
    // 0x12db7bc: mov             v0.16b, v2.16b
    // 0x12db7c0: r2 = 15
    //     0x12db7c0: mov             x2, #0xf
    // 0x12db7c4: r0 = setFloat()
    //     0x12db7c4: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12db7c8: ldur            d1, [fp, #-0x38]
    // 0x12db7cc: d0 = 0.010000
    //     0x12db7cc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13398] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0x12db7d0: ldr             d0, [x17, #0x398]
    // 0x12db7d4: fmul            d2, d1, d0
    // 0x12db7d8: stur            d2, [fp, #-0x40]
    // 0x12db7dc: d0 = 0.825000
    //     0x12db7dc: add             x17, PP, #0xab, lsl #12  ; [pp+0xab0e8] IMM: double(0.8250000000000001) from 0x3fea666666666667
    //     0x12db7e0: ldr             d0, [x17, #0xe8]
    // 0x12db7e4: stp             fp, lr, [SP, #-0x10]!
    // 0x12db7e8: mov             fp, SP
    // 0x12db7ec: CallRuntime_LibcCos(double) -> double
    //     0x12db7ec: and             SP, SP, #0xfffffffffffffff0
    //     0x12db7f0: mov             sp, SP
    //     0x12db7f4: ldr             x16, [THR, #0x778]  ; THR::LibcCos
    //     0x12db7f8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12db7fc: blr             x16
    //     0x12db800: mov             x16, #8
    //     0x12db804: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12db808: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x12db80c: sub             sp, x16, #1, lsl #12
    //     0x12db810: mov             SP, fp
    //     0x12db814: ldp             fp, lr, [SP], #0x10
    // 0x12db818: ldur            d1, [fp, #-0x40]
    // 0x12db81c: fmul            d2, d1, d0
    // 0x12db820: d3 = 0.750000
    //     0x12db820: fmov            d3, #0.75000000
    // 0x12db824: fadd            d0, d2, d3
    // 0x12db828: ldur            x1, [fp, #-0x18]
    // 0x12db82c: r2 = 16
    //     0x12db82c: mov             x2, #0x10
    // 0x12db830: r0 = setFloat()
    //     0x12db830: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12db834: d0 = 0.825000
    //     0x12db834: add             x17, PP, #0xab, lsl #12  ; [pp+0xab0e8] IMM: double(0.8250000000000001) from 0x3fea666666666667
    //     0x12db838: ldr             d0, [x17, #0xe8]
    // 0x12db83c: stp             fp, lr, [SP, #-0x10]!
    // 0x12db840: mov             fp, SP
    // 0x12db844: CallRuntime_LibcSin(double) -> double
    //     0x12db844: and             SP, SP, #0xfffffffffffffff0
    //     0x12db848: mov             sp, SP
    //     0x12db84c: ldr             x16, [THR, #0x780]  ; THR::LibcSin
    //     0x12db850: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12db854: blr             x16
    //     0x12db858: mov             x16, #8
    //     0x12db85c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12db860: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x12db864: sub             sp, x16, #1, lsl #12
    //     0x12db868: mov             SP, fp
    //     0x12db86c: ldp             fp, lr, [SP], #0x10
    // 0x12db870: mov             v1.16b, v0.16b
    // 0x12db874: ldur            d0, [fp, #-0x40]
    // 0x12db878: fmul            d2, d0, d1
    // 0x12db87c: d0 = 0.750000
    //     0x12db87c: fmov            d0, #0.75000000
    // 0x12db880: fadd            d1, d2, d0
    // 0x12db884: ldur            x1, [fp, #-0x18]
    // 0x12db888: mov             v0.16b, v1.16b
    // 0x12db88c: r2 = 17
    //     0x12db88c: mov             x2, #0x11
    // 0x12db890: r0 = setFloat()
    //     0x12db890: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12db894: ldur            d0, [fp, #-0x38]
    // 0x12db898: d1 = -0.006600
    //     0x12db898: add             x17, PP, #0xab, lsl #12  ; [pp+0xab0f0] IMM: double(-0.0066) from 0xbf7b089a02752546
    //     0x12db89c: ldr             d1, [x17, #0xf0]
    // 0x12db8a0: fmul            d2, d0, d1
    // 0x12db8a4: stur            d2, [fp, #-0x40]
    // 0x12db8a8: d0 = 0.675000
    //     0x12db8a8: add             x17, PP, #0xab, lsl #12  ; [pp+0xab0f8] IMM: double(0.675) from 0x3fe599999999999a
    //     0x12db8ac: ldr             d0, [x17, #0xf8]
    // 0x12db8b0: stp             fp, lr, [SP, #-0x10]!
    // 0x12db8b4: mov             fp, SP
    // 0x12db8b8: CallRuntime_LibcCos(double) -> double
    //     0x12db8b8: and             SP, SP, #0xfffffffffffffff0
    //     0x12db8bc: mov             sp, SP
    //     0x12db8c0: ldr             x16, [THR, #0x778]  ; THR::LibcCos
    //     0x12db8c4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12db8c8: blr             x16
    //     0x12db8cc: mov             x16, #8
    //     0x12db8d0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12db8d4: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x12db8d8: sub             sp, x16, #1, lsl #12
    //     0x12db8dc: mov             SP, fp
    //     0x12db8e0: ldp             fp, lr, [SP], #0x10
    // 0x12db8e4: ldur            d1, [fp, #-0x40]
    // 0x12db8e8: fmul            d2, d1, d0
    // 0x12db8ec: d3 = 0.300000
    //     0x12db8ec: add             x17, PP, #0xab, lsl #12  ; [pp+0xab100] IMM: double(0.30000000000000004) from 0x3fd3333333333334
    //     0x12db8f0: ldr             d3, [x17, #0x100]
    // 0x12db8f4: fadd            d0, d2, d3
    // 0x12db8f8: ldur            x1, [fp, #-0x18]
    // 0x12db8fc: r2 = 18
    //     0x12db8fc: mov             x2, #0x12
    // 0x12db900: r0 = setFloat()
    //     0x12db900: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12db904: d0 = 0.675000
    //     0x12db904: add             x17, PP, #0xab, lsl #12  ; [pp+0xab0f8] IMM: double(0.675) from 0x3fe599999999999a
    //     0x12db908: ldr             d0, [x17, #0xf8]
    // 0x12db90c: stp             fp, lr, [SP, #-0x10]!
    // 0x12db910: mov             fp, SP
    // 0x12db914: CallRuntime_LibcSin(double) -> double
    //     0x12db914: and             SP, SP, #0xfffffffffffffff0
    //     0x12db918: mov             sp, SP
    //     0x12db91c: ldr             x16, [THR, #0x780]  ; THR::LibcSin
    //     0x12db920: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12db924: blr             x16
    //     0x12db928: mov             x16, #8
    //     0x12db92c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12db930: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x12db934: sub             sp, x16, #1, lsl #12
    //     0x12db938: mov             SP, fp
    //     0x12db93c: ldp             fp, lr, [SP], #0x10
    // 0x12db940: ldur            d1, [fp, #-0x40]
    // 0x12db944: fmul            d2, d1, d0
    // 0x12db948: d0 = 0.300000
    //     0x12db948: add             x17, PP, #0xab, lsl #12  ; [pp+0xab100] IMM: double(0.30000000000000004) from 0x3fd3333333333334
    //     0x12db94c: ldr             d0, [x17, #0x100]
    // 0x12db950: fadd            d3, d2, d0
    // 0x12db954: ldur            x1, [fp, #-0x18]
    // 0x12db958: mov             v0.16b, v3.16b
    // 0x12db95c: r2 = 19
    //     0x12db95c: mov             x2, #0x13
    // 0x12db960: r0 = setFloat()
    //     0x12db960: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12db964: d0 = 0.525000
    //     0x12db964: add             x17, PP, #0xab, lsl #12  ; [pp+0xab108] IMM: double(0.5249999999999999) from 0x3fe0cccccccccccc
    //     0x12db968: ldr             d0, [x17, #0x108]
    // 0x12db96c: stp             fp, lr, [SP, #-0x10]!
    // 0x12db970: mov             fp, SP
    // 0x12db974: CallRuntime_LibcCos(double) -> double
    //     0x12db974: and             SP, SP, #0xfffffffffffffff0
    //     0x12db978: mov             sp, SP
    //     0x12db97c: ldr             x16, [THR, #0x778]  ; THR::LibcCos
    //     0x12db980: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12db984: blr             x16
    //     0x12db988: mov             x16, #8
    //     0x12db98c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12db990: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x12db994: sub             sp, x16, #1, lsl #12
    //     0x12db998: mov             SP, fp
    //     0x12db99c: ldp             fp, lr, [SP], #0x10
    // 0x12db9a0: ldur            d1, [fp, #-0x40]
    // 0x12db9a4: fmul            d2, d1, d0
    // 0x12db9a8: d3 = 1.500000
    //     0x12db9a8: fmov            d3, #1.50000000
    // 0x12db9ac: fadd            d0, d2, d3
    // 0x12db9b0: ldur            x1, [fp, #-0x18]
    // 0x12db9b4: r2 = 20
    //     0x12db9b4: mov             x2, #0x14
    // 0x12db9b8: r0 = setFloat()
    //     0x12db9b8: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12db9bc: d0 = 0.525000
    //     0x12db9bc: add             x17, PP, #0xab, lsl #12  ; [pp+0xab108] IMM: double(0.5249999999999999) from 0x3fe0cccccccccccc
    //     0x12db9c0: ldr             d0, [x17, #0x108]
    // 0x12db9c4: stp             fp, lr, [SP, #-0x10]!
    // 0x12db9c8: mov             fp, SP
    // 0x12db9cc: CallRuntime_LibcSin(double) -> double
    //     0x12db9cc: and             SP, SP, #0xfffffffffffffff0
    //     0x12db9d0: mov             sp, SP
    //     0x12db9d4: ldr             x16, [THR, #0x780]  ; THR::LibcSin
    //     0x12db9d8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12db9dc: blr             x16
    //     0x12db9e0: mov             x16, #8
    //     0x12db9e4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12db9e8: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x12db9ec: sub             sp, x16, #1, lsl #12
    //     0x12db9f0: mov             SP, fp
    //     0x12db9f4: ldp             fp, lr, [SP], #0x10
    // 0x12db9f8: mov             v1.16b, v0.16b
    // 0x12db9fc: ldur            d0, [fp, #-0x40]
    // 0x12dba00: fmul            d2, d0, d1
    // 0x12dba04: d0 = 1.500000
    //     0x12dba04: fmov            d0, #1.50000000
    // 0x12dba08: fadd            d1, d2, d0
    // 0x12dba0c: ldur            x1, [fp, #-0x18]
    // 0x12dba10: mov             v0.16b, v1.16b
    // 0x12dba14: r2 = 21
    //     0x12dba14: mov             x2, #0x15
    // 0x12dba18: r0 = setFloat()
    //     0x12dba18: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12dba1c: ldur            d0, [fp, #-0x30]
    // 0x12dba20: stp             fp, lr, [SP, #-0x10]!
    // 0x12dba24: mov             fp, SP
    // 0x12dba28: CallRuntime_LibcCos(double) -> double
    //     0x12dba28: and             SP, SP, #0xfffffffffffffff0
    //     0x12dba2c: mov             sp, SP
    //     0x12dba30: ldr             x16, [THR, #0x778]  ; THR::LibcCos
    //     0x12dba34: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12dba38: blr             x16
    //     0x12dba3c: mov             x16, #8
    //     0x12dba40: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12dba44: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x12dba48: sub             sp, x16, #1, lsl #12
    //     0x12dba4c: mov             SP, fp
    //     0x12dba50: ldp             fp, lr, [SP], #0x10
    // 0x12dba54: ldur            x1, [fp, #-0x18]
    // 0x12dba58: r2 = 22
    //     0x12dba58: mov             x2, #0x16
    // 0x12dba5c: r0 = setFloat()
    //     0x12dba5c: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12dba60: ldur            d0, [fp, #-0x30]
    // 0x12dba64: stp             fp, lr, [SP, #-0x10]!
    // 0x12dba68: mov             fp, SP
    // 0x12dba6c: CallRuntime_LibcSin(double) -> double
    //     0x12dba6c: and             SP, SP, #0xfffffffffffffff0
    //     0x12dba70: mov             sp, SP
    //     0x12dba74: ldr             x16, [THR, #0x780]  ; THR::LibcSin
    //     0x12dba78: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12dba7c: blr             x16
    //     0x12dba80: mov             x16, #8
    //     0x12dba84: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12dba88: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x12dba8c: sub             sp, x16, #1, lsl #12
    //     0x12dba90: mov             SP, fp
    //     0x12dba94: ldp             fp, lr, [SP], #0x10
    // 0x12dba98: ldur            x1, [fp, #-0x18]
    // 0x12dba9c: r2 = 23
    //     0x12dba9c: mov             x2, #0x17
    // 0x12dbaa0: r0 = setFloat()
    //     0x12dbaa0: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12dbaa4: ldur            d0, [fp, #-0x28]
    // 0x12dbaa8: stp             fp, lr, [SP, #-0x10]!
    // 0x12dbaac: mov             fp, SP
    // 0x12dbab0: CallRuntime_LibcCos(double) -> double
    //     0x12dbab0: and             SP, SP, #0xfffffffffffffff0
    //     0x12dbab4: mov             sp, SP
    //     0x12dbab8: ldr             x16, [THR, #0x778]  ; THR::LibcCos
    //     0x12dbabc: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12dbac0: blr             x16
    //     0x12dbac4: mov             x16, #8
    //     0x12dbac8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12dbacc: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x12dbad0: sub             sp, x16, #1, lsl #12
    //     0x12dbad4: mov             SP, fp
    //     0x12dbad8: ldp             fp, lr, [SP], #0x10
    // 0x12dbadc: ldur            x1, [fp, #-0x18]
    // 0x12dbae0: r2 = 24
    //     0x12dbae0: mov             x2, #0x18
    // 0x12dbae4: r0 = setFloat()
    //     0x12dbae4: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12dbae8: ldur            d0, [fp, #-0x28]
    // 0x12dbaec: stp             fp, lr, [SP, #-0x10]!
    // 0x12dbaf0: mov             fp, SP
    // 0x12dbaf4: CallRuntime_LibcSin(double) -> double
    //     0x12dbaf4: and             SP, SP, #0xfffffffffffffff0
    //     0x12dbaf8: mov             sp, SP
    //     0x12dbafc: ldr             x16, [THR, #0x780]  ; THR::LibcSin
    //     0x12dbb00: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12dbb04: blr             x16
    //     0x12dbb08: mov             x16, #8
    //     0x12dbb0c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12dbb10: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x12dbb14: sub             sp, x16, #1, lsl #12
    //     0x12dbb18: mov             SP, fp
    //     0x12dbb1c: ldp             fp, lr, [SP], #0x10
    // 0x12dbb20: ldur            x1, [fp, #-0x18]
    // 0x12dbb24: r2 = 25
    //     0x12dbb24: mov             x2, #0x19
    // 0x12dbb28: r0 = setFloat()
    //     0x12dbb28: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12dbb2c: ldur            d0, [fp, #-0x20]
    // 0x12dbb30: stp             fp, lr, [SP, #-0x10]!
    // 0x12dbb34: mov             fp, SP
    // 0x12dbb38: CallRuntime_LibcCos(double) -> double
    //     0x12dbb38: and             SP, SP, #0xfffffffffffffff0
    //     0x12dbb3c: mov             sp, SP
    //     0x12dbb40: ldr             x16, [THR, #0x778]  ; THR::LibcCos
    //     0x12dbb44: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12dbb48: blr             x16
    //     0x12dbb4c: mov             x16, #8
    //     0x12dbb50: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12dbb54: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x12dbb58: sub             sp, x16, #1, lsl #12
    //     0x12dbb5c: mov             SP, fp
    //     0x12dbb60: ldp             fp, lr, [SP], #0x10
    // 0x12dbb64: ldur            x1, [fp, #-0x18]
    // 0x12dbb68: r2 = 26
    //     0x12dbb68: mov             x2, #0x1a
    // 0x12dbb6c: r0 = setFloat()
    //     0x12dbb6c: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12dbb70: ldur            d0, [fp, #-0x20]
    // 0x12dbb74: stp             fp, lr, [SP, #-0x10]!
    // 0x12dbb78: mov             fp, SP
    // 0x12dbb7c: CallRuntime_LibcSin(double) -> double
    //     0x12dbb7c: and             SP, SP, #0xfffffffffffffff0
    //     0x12dbb80: mov             sp, SP
    //     0x12dbb84: ldr             x16, [THR, #0x780]  ; THR::LibcSin
    //     0x12dbb88: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12dbb8c: blr             x16
    //     0x12dbb90: mov             x16, #8
    //     0x12dbb94: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12dbb98: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x12dbb9c: sub             sp, x16, #1, lsl #12
    //     0x12dbba0: mov             SP, fp
    //     0x12dbba4: ldp             fp, lr, [SP], #0x10
    // 0x12dbba8: ldur            x1, [fp, #-0x18]
    // 0x12dbbac: r2 = 27
    //     0x12dbbac: mov             x2, #0x1b
    // 0x12dbbb0: r0 = setFloat()
    //     0x12dbbb0: bl              #0xe0e9d8  ; [dart:ui] FragmentShader::setFloat
    // 0x12dbbb4: r0 = Null
    //     0x12dbbb4: mov             x0, NULL
    // 0x12dbbb8: LeaveFrame
    //     0x12dbbb8: mov             SP, fp
    //     0x12dbbbc: ldp             fp, lr, [SP], #0x10
    // 0x12dbbc0: ret
    //     0x12dbbc0: ret             
    // 0x12dbbc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12dbbc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12dbbc8: b               #0x12db368
    // 0x12dbbcc: r9 = _turbulenceSeed
    //     0x12dbbcc: add             x9, PP, #0xab, lsl #12  ; [pp+0xab110] Field <InkSparkle._turbulenceSeed@756321118>: late (offset: 0x30)
    //     0x12dbbd0: ldr             x9, [x9, #0x110]
    // 0x12dbbd4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12dbbd4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12dbbd8: r9 = _radiusScale
    //     0x12dbbd8: add             x9, PP, #0xab, lsl #12  ; [pp+0xab118] Field <InkSparkle._radiusScale@756321118>: late (offset: 0x24)
    //     0x12dbbdc: ldr             x9, [x9, #0x118]
    // 0x12dbbe0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12dbbe0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12dbbe4: r9 = _fragmentShader
    //     0x12dbbe4: add             x9, PP, #0x99, lsl #12  ; [pp+0x995f8] Field <InkSparkle._fragmentShader@756321118>: late final (offset: 0x50)
    //     0x12dbbe8: ldr             x9, [x9, #0x5f8]
    // 0x12dbbec: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x12dbbec: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x12dbbf0: r9 = _alpha
    //     0x12dbbf0: add             x9, PP, #0xab, lsl #12  ; [pp+0xab120] Field <InkSparkle._alpha@756321118>: late (offset: 0x28)
    //     0x12dbbf4: ldr             x9, [x9, #0x120]
    // 0x12dbbf8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12dbbf8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12dbbfc: r9 = _sparkleAlpha
    //     0x12dbbfc: add             x9, PP, #0xab, lsl #12  ; [pp+0xab128] Field <InkSparkle._sparkleAlpha@756321118>: late (offset: 0x2c)
    //     0x12dbc00: ldr             x9, [x9, #0x128]
    // 0x12dbc04: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12dbc04: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12dbc08: r9 = _center
    //     0x12dbc08: add             x9, PP, #0xab, lsl #12  ; [pp+0xab130] Field <InkSparkle._center@756321118>: late (offset: 0x20)
    //     0x12dbc0c: ldr             x9, [x9, #0x130]
    // 0x12dbc10: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12dbc10: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12dbc14: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12dbc14: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x12dbc18: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12dbc18: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ _height(/* No info */) {
    // ** addr: 0x12dbc1c, size: 0x3c
    // 0x12dbc1c: EnterFrame
    //     0x12dbc1c: stp             fp, lr, [SP, #-0x10]!
    //     0x12dbc20: mov             fp, SP
    // 0x12dbc24: CheckStackOverflow
    //     0x12dbc24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12dbc28: cmp             SP, x16
    //     0x12dbc2c: b.ls            #0x12dbc50
    // 0x12dbc30: LoadField: r0 = r1->field_b
    //     0x12dbc30: ldur            w0, [x1, #0xb]
    // 0x12dbc34: DecompressPointer r0
    //     0x12dbc34: add             x0, x0, HEAP, lsl #32
    // 0x12dbc38: mov             x1, x0
    // 0x12dbc3c: r0 = size()
    //     0x12dbc3c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x12dbc40: LoadField: d0 = r0->field_f
    //     0x12dbc40: ldur            d0, [x0, #0xf]
    // 0x12dbc44: LeaveFrame
    //     0x12dbc44: mov             SP, fp
    //     0x12dbc48: ldp             fp, lr, [SP], #0x10
    // 0x12dbc4c: ret
    //     0x12dbc4c: ret             
    // 0x12dbc50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12dbc50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12dbc54: b               #0x12dbc30
  }
  get _ _width(/* No info */) {
    // ** addr: 0x12dbc58, size: 0x3c
    // 0x12dbc58: EnterFrame
    //     0x12dbc58: stp             fp, lr, [SP, #-0x10]!
    //     0x12dbc5c: mov             fp, SP
    // 0x12dbc60: CheckStackOverflow
    //     0x12dbc60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12dbc64: cmp             SP, x16
    //     0x12dbc68: b.ls            #0x12dbc8c
    // 0x12dbc6c: LoadField: r0 = r1->field_b
    //     0x12dbc6c: ldur            w0, [x1, #0xb]
    // 0x12dbc70: DecompressPointer r0
    //     0x12dbc70: add             x0, x0, HEAP, lsl #32
    // 0x12dbc74: mov             x1, x0
    // 0x12dbc78: r0 = size()
    //     0x12dbc78: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x12dbc7c: LoadField: d0 = r0->field_7
    //     0x12dbc7c: ldur            d0, [x0, #7]
    // 0x12dbc80: LeaveFrame
    //     0x12dbc80: mov             SP, fp
    //     0x12dbc84: ldp             fp, lr, [SP], #0x10
    // 0x12dbc88: ret
    //     0x12dbc88: ret             
    // 0x12dbc8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12dbc8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12dbc90: b               #0x12dbc6c
  }
  _ _clipCanvas(/* No info */) {
    // ** addr: 0x12dbc94, size: 0x2f0
    // 0x12dbc94: EnterFrame
    //     0x12dbc94: stp             fp, lr, [SP, #-0x10]!
    //     0x12dbc98: mov             fp, SP
    // 0x12dbc9c: AllocStack(0x58)
    //     0x12dbc9c: sub             SP, SP, #0x58
    // 0x12dbca0: SetupParameters(InkSparkle this /* r1 => r4 */, dynamic _ /* r2 => r3, fp-0x18 */, dynamic _ /* r3 => r2, fp-0x20 */)
    //     0x12dbca0: mov             x4, x1
    //     0x12dbca4: stur            x2, [fp, #-8]
    //     0x12dbca8: mov             x16, x3
    //     0x12dbcac: mov             x3, x2
    //     0x12dbcb0: mov             x2, x16
    //     0x12dbcb4: mov             x0, x5
    //     0x12dbcb8: mov             x1, x6
    //     0x12dbcbc: stur            x2, [fp, #-0x10]
    //     0x12dbcc0: stur            x6, [fp, #-0x18]
    //     0x12dbcc4: stur            x7, [fp, #-0x20]
    // 0x12dbcc8: CheckStackOverflow
    //     0x12dbcc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12dbccc: cmp             SP, x16
    //     0x12dbcd0: b.ls            #0x12dbf70
    // 0x12dbcd4: str             x0, [SP]
    // 0x12dbcd8: ClosureCall
    //     0x12dbcd8: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x12dbcdc: ldur            x2, [x0, #0x1f]
    //     0x12dbce0: blr             x2
    // 0x12dbce4: ldur            x1, [fp, #-0x18]
    // 0x12dbce8: stur            x0, [fp, #-0x30]
    // 0x12dbcec: cmp             w1, NULL
    // 0x12dbcf0: b.eq            #0x12dbdbc
    // 0x12dbcf4: ldur            x3, [fp, #-0x10]
    // 0x12dbcf8: r2 = LoadClassIdInstr(r1)
    //     0x12dbcf8: ldur            x2, [x1, #-1]
    //     0x12dbcfc: ubfx            x2, x2, #0xc, #0x14
    // 0x12dbd00: ldur            x16, [fp, #-0x20]
    // 0x12dbd04: str             x16, [SP]
    // 0x12dbd08: mov             x16, x0
    // 0x12dbd0c: mov             x0, x2
    // 0x12dbd10: mov             x2, x16
    // 0x12dbd14: r4 = const [0, 0x3, 0x1, 0x2, textDirection, 0x2, null]
    //     0x12dbd14: add             x4, PP, #0x97, lsl #12  ; [pp+0x97638] List(7) [0, 0x3, 0x1, 0x2, "textDirection", 0x2, Null]
    //     0x12dbd18: ldr             x4, [x4, #0x638]
    // 0x12dbd1c: r0 = GDT[cid_x0 + -0xfc1]()
    //     0x12dbd1c: sub             lr, x0, #0xfc1
    //     0x12dbd20: ldr             lr, [x21, lr, lsl #3]
    //     0x12dbd24: blr             lr
    // 0x12dbd28: mov             x2, x0
    // 0x12dbd2c: ldur            x0, [fp, #-0x10]
    // 0x12dbd30: stur            x2, [fp, #-0x18]
    // 0x12dbd34: LoadField: r1 = r0->field_7
    //     0x12dbd34: ldur            w1, [x0, #7]
    // 0x12dbd38: DecompressPointer r1
    //     0x12dbd38: add             x1, x1, HEAP, lsl #32
    // 0x12dbd3c: cmp             w1, NULL
    // 0x12dbd40: b.eq            #0x12dbf78
    // 0x12dbd44: LoadField: r3 = r1->field_7
    //     0x12dbd44: ldur            x3, [x1, #7]
    // 0x12dbd48: ldr             x1, [x3]
    // 0x12dbd4c: cbz             x1, #0x12dbf50
    // 0x12dbd50: mov             x3, x1
    // 0x12dbd54: stur            x3, [fp, #-0x28]
    // 0x12dbd58: r1 = <Never>
    //     0x12dbd58: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12dbd5c: r0 = Pointer()
    //     0x12dbd5c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12dbd60: mov             x2, x0
    // 0x12dbd64: ldur            x0, [fp, #-0x28]
    // 0x12dbd68: stur            x2, [fp, #-0x20]
    // 0x12dbd6c: StoreField: r2->field_7 = r0
    //     0x12dbd6c: stur            x0, [x2, #7]
    // 0x12dbd70: ldur            x0, [fp, #-0x18]
    // 0x12dbd74: LoadField: r1 = r0->field_7
    //     0x12dbd74: ldur            w1, [x0, #7]
    // 0x12dbd78: DecompressPointer r1
    //     0x12dbd78: add             x1, x1, HEAP, lsl #32
    // 0x12dbd7c: cmp             w1, NULL
    // 0x12dbd80: b.eq            #0x12dbf7c
    // 0x12dbd84: LoadField: r3 = r1->field_7
    //     0x12dbd84: ldur            x3, [x1, #7]
    // 0x12dbd88: ldr             x1, [x3]
    // 0x12dbd8c: mov             x3, x1
    // 0x12dbd90: stur            x3, [fp, #-0x28]
    // 0x12dbd94: r1 = <Never>
    //     0x12dbd94: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12dbd98: r0 = Pointer()
    //     0x12dbd98: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12dbd9c: mov             x1, x0
    // 0x12dbda0: ldur            x0, [fp, #-0x28]
    // 0x12dbda4: StoreField: r1->field_7 = r0
    //     0x12dbda4: stur            x0, [x1, #7]
    // 0x12dbda8: mov             x2, x1
    // 0x12dbdac: ldur            x1, [fp, #-0x20]
    // 0x12dbdb0: r3 = true
    //     0x12dbdb0: add             x3, NULL, #0x20  ; true
    // 0x12dbdb4: r0 = __clipPath$Method$FfiNative()
    //     0x12dbdb4: bl              #0xc1ac40  ; [dart:ui] _NativeCanvas::__clipPath$Method$FfiNative
    // 0x12dbdb8: b               #0x12dbf40
    // 0x12dbdbc: ldur            x16, [fp, #-8]
    // 0x12dbdc0: r30 = Instance_BorderRadius
    //     0x12dbdc0: add             lr, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0x12dbdc4: ldr             lr, [lr, #0x508]
    // 0x12dbdc8: stp             lr, x16, [SP]
    // 0x12dbdcc: r0 = ==()
    //     0x12dbdcc: bl              #0x1298058  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x12dbdd0: tbz             w0, #4, #0x12dbf30
    // 0x12dbdd4: ldur            x1, [fp, #-8]
    // 0x12dbdd8: ldur            x0, [fp, #-0x10]
    // 0x12dbddc: LoadField: r6 = r1->field_7
    //     0x12dbddc: ldur            w6, [x1, #7]
    // 0x12dbde0: DecompressPointer r6
    //     0x12dbde0: add             x6, x6, HEAP, lsl #32
    // 0x12dbde4: stur            x6, [fp, #-0x40]
    // 0x12dbde8: LoadField: r7 = r1->field_b
    //     0x12dbde8: ldur            w7, [x1, #0xb]
    // 0x12dbdec: DecompressPointer r7
    //     0x12dbdec: add             x7, x7, HEAP, lsl #32
    // 0x12dbdf0: stur            x7, [fp, #-0x38]
    // 0x12dbdf4: LoadField: r3 = r1->field_f
    //     0x12dbdf4: ldur            w3, [x1, #0xf]
    // 0x12dbdf8: DecompressPointer r3
    //     0x12dbdf8: add             x3, x3, HEAP, lsl #32
    // 0x12dbdfc: stur            x3, [fp, #-0x20]
    // 0x12dbe00: LoadField: r5 = r1->field_13
    //     0x12dbe00: ldur            w5, [x1, #0x13]
    // 0x12dbe04: DecompressPointer r5
    //     0x12dbe04: add             x5, x5, HEAP, lsl #32
    // 0x12dbe08: stur            x5, [fp, #-0x18]
    // 0x12dbe0c: r1 = <RRect>
    //     0x12dbe0c: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0x12dbe10: ldr             x1, [x1, #0x108]
    // 0x12dbe14: r0 = RRect()
    //     0x12dbe14: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0x12dbe18: mov             x1, x0
    // 0x12dbe1c: ldur            x2, [fp, #-0x30]
    // 0x12dbe20: ldur            x3, [fp, #-0x20]
    // 0x12dbe24: ldur            x5, [fp, #-0x18]
    // 0x12dbe28: ldur            x6, [fp, #-0x40]
    // 0x12dbe2c: ldur            x7, [fp, #-0x38]
    // 0x12dbe30: stur            x0, [fp, #-8]
    // 0x12dbe34: r0 = RSuperellipse.fromRectAndCorners()
    //     0x12dbe34: bl              #0xb77b20  ; [dart:ui] RSuperellipse::RSuperellipse.fromRectAndCorners
    // 0x12dbe38: ldur            x0, [fp, #-8]
    // 0x12dbe3c: LoadField: d0 = r0->field_b
    //     0x12dbe3c: ldur            d0, [x0, #0xb]
    // 0x12dbe40: fcvt            s1, d0
    // 0x12dbe44: stur            d1, [fp, #-0x48]
    // 0x12dbe48: r4 = 24
    //     0x12dbe48: mov             x4, #0x18
    // 0x12dbe4c: r0 = AllocateFloat32Array()
    //     0x12dbe4c: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0x12dbe50: ldur            d0, [fp, #-0x48]
    // 0x12dbe54: stur            x0, [fp, #-0x18]
    // 0x12dbe58: ArrayStore: r0[0] = d0  ; List_8
    //     0x12dbe58: stur            s0, [x0, #0x17]
    // 0x12dbe5c: ldur            x1, [fp, #-8]
    // 0x12dbe60: LoadField: d0 = r1->field_13
    //     0x12dbe60: ldur            d0, [x1, #0x13]
    // 0x12dbe64: fcvt            s1, d0
    // 0x12dbe68: StoreField: r0->field_1b = d1
    //     0x12dbe68: stur            s1, [x0, #0x1b]
    // 0x12dbe6c: LoadField: d0 = r1->field_1b
    //     0x12dbe6c: ldur            d0, [x1, #0x1b]
    // 0x12dbe70: fcvt            s1, d0
    // 0x12dbe74: StoreField: r0->field_1f = d1
    //     0x12dbe74: stur            s1, [x0, #0x1f]
    // 0x12dbe78: LoadField: d0 = r1->field_23
    //     0x12dbe78: ldur            d0, [x1, #0x23]
    // 0x12dbe7c: fcvt            s1, d0
    // 0x12dbe80: StoreField: r0->field_23 = d1
    //     0x12dbe80: stur            s1, [x0, #0x23]
    // 0x12dbe84: LoadField: d0 = r1->field_2b
    //     0x12dbe84: ldur            d0, [x1, #0x2b]
    // 0x12dbe88: fcvt            s1, d0
    // 0x12dbe8c: StoreField: r0->field_27 = d1
    //     0x12dbe8c: stur            s1, [x0, #0x27]
    // 0x12dbe90: LoadField: d0 = r1->field_33
    //     0x12dbe90: ldur            d0, [x1, #0x33]
    // 0x12dbe94: fcvt            s1, d0
    // 0x12dbe98: StoreField: r0->field_2b = d1
    //     0x12dbe98: stur            s1, [x0, #0x2b]
    // 0x12dbe9c: LoadField: d0 = r1->field_3b
    //     0x12dbe9c: ldur            d0, [x1, #0x3b]
    // 0x12dbea0: fcvt            s1, d0
    // 0x12dbea4: StoreField: r0->field_2f = d1
    //     0x12dbea4: stur            s1, [x0, #0x2f]
    // 0x12dbea8: LoadField: d0 = r1->field_43
    //     0x12dbea8: ldur            d0, [x1, #0x43]
    // 0x12dbeac: fcvt            s1, d0
    // 0x12dbeb0: StoreField: r0->field_33 = d1
    //     0x12dbeb0: stur            s1, [x0, #0x33]
    // 0x12dbeb4: LoadField: d0 = r1->field_4b
    //     0x12dbeb4: ldur            d0, [x1, #0x4b]
    // 0x12dbeb8: fcvt            s1, d0
    // 0x12dbebc: StoreField: r0->field_37 = d1
    //     0x12dbebc: stur            s1, [x0, #0x37]
    // 0x12dbec0: LoadField: d0 = r1->field_53
    //     0x12dbec0: ldur            d0, [x1, #0x53]
    // 0x12dbec4: fcvt            s1, d0
    // 0x12dbec8: StoreField: r0->field_3b = d1
    //     0x12dbec8: stur            s1, [x0, #0x3b]
    // 0x12dbecc: LoadField: d0 = r1->field_5b
    //     0x12dbecc: ldur            d0, [x1, #0x5b]
    // 0x12dbed0: fcvt            s1, d0
    // 0x12dbed4: StoreField: r0->field_3f = d1
    //     0x12dbed4: stur            s1, [x0, #0x3f]
    // 0x12dbed8: LoadField: d0 = r1->field_63
    //     0x12dbed8: ldur            d0, [x1, #0x63]
    // 0x12dbedc: fcvt            s1, d0
    // 0x12dbee0: StoreField: r0->field_43 = d1
    //     0x12dbee0: stur            s1, [x0, #0x43]
    // 0x12dbee4: ldur            x2, [fp, #-0x10]
    // 0x12dbee8: LoadField: r1 = r2->field_7
    //     0x12dbee8: ldur            w1, [x2, #7]
    // 0x12dbeec: DecompressPointer r1
    //     0x12dbeec: add             x1, x1, HEAP, lsl #32
    // 0x12dbef0: cmp             w1, NULL
    // 0x12dbef4: b.eq            #0x12dbf80
    // 0x12dbef8: LoadField: r3 = r1->field_7
    //     0x12dbef8: ldur            x3, [x1, #7]
    // 0x12dbefc: ldr             x1, [x3]
    // 0x12dbf00: cbz             x1, #0x12dbf60
    // 0x12dbf04: mov             x3, x1
    // 0x12dbf08: stur            x3, [fp, #-0x28]
    // 0x12dbf0c: r1 = <Never>
    //     0x12dbf0c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12dbf10: r0 = Pointer()
    //     0x12dbf10: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12dbf14: mov             x1, x0
    // 0x12dbf18: ldur            x0, [fp, #-0x28]
    // 0x12dbf1c: StoreField: r1->field_7 = r0
    //     0x12dbf1c: stur            x0, [x1, #7]
    // 0x12dbf20: ldur            x2, [fp, #-0x18]
    // 0x12dbf24: r3 = true
    //     0x12dbf24: add             x3, NULL, #0x20  ; true
    // 0x12dbf28: r0 = __clipRRect$Method$FfiNative()
    //     0x12dbf28: bl              #0xb6e74c  ; [dart:ui] _NativeCanvas::__clipRRect$Method$FfiNative
    // 0x12dbf2c: b               #0x12dbf40
    // 0x12dbf30: ldur            x1, [fp, #-0x10]
    // 0x12dbf34: ldur            x2, [fp, #-0x30]
    // 0x12dbf38: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x12dbf38: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x12dbf3c: r0 = clipRect()
    //     0x12dbf3c: bl              #0xb7b380  ; [dart:ui] _NativeCanvas::clipRect
    // 0x12dbf40: r0 = Null
    //     0x12dbf40: mov             x0, NULL
    // 0x12dbf44: LeaveFrame
    //     0x12dbf44: mov             SP, fp
    //     0x12dbf48: ldp             fp, lr, [SP], #0x10
    // 0x12dbf4c: ret
    //     0x12dbf4c: ret             
    // 0x12dbf50: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12dbf50: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12dbf54: str             x16, [SP]
    // 0x12dbf58: r0 = _throwNew()
    //     0x12dbf58: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12dbf5c: brk             #0
    // 0x12dbf60: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12dbf60: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12dbf64: str             x16, [SP]
    // 0x12dbf68: r0 = _throwNew()
    //     0x12dbf68: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12dbf6c: brk             #0
    // 0x12dbf70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12dbf70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12dbf74: b               #0x12dbcd4
    // 0x12dbf78: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12dbf78: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12dbf7c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12dbf7c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12dbf80: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12dbf80: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _transformCanvas(/* No info */) {
    // ** addr: 0x12dbf84, size: 0xcc
    // 0x12dbf84: EnterFrame
    //     0x12dbf84: stp             fp, lr, [SP, #-0x10]!
    //     0x12dbf88: mov             fp, SP
    // 0x12dbf8c: AllocStack(0x30)
    //     0x12dbf8c: sub             SP, SP, #0x30
    // 0x12dbf90: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r0, fp-0x10 */)
    //     0x12dbf90: mov             x0, x3
    //     0x12dbf94: stur            x2, [fp, #-8]
    //     0x12dbf98: stur            x3, [fp, #-0x10]
    // 0x12dbf9c: CheckStackOverflow
    //     0x12dbf9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12dbfa0: cmp             SP, x16
    //     0x12dbfa4: b.ls            #0x12dc044
    // 0x12dbfa8: mov             x1, x0
    // 0x12dbfac: r0 = getAsTranslation()
    //     0x12dbfac: bl              #0xc155c4  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::getAsTranslation
    // 0x12dbfb0: cmp             w0, NULL
    // 0x12dbfb4: b.ne            #0x12dbfd0
    // 0x12dbfb8: ldur            x0, [fp, #-0x10]
    // 0x12dbfbc: LoadField: r2 = r0->field_7
    //     0x12dbfbc: ldur            w2, [x0, #7]
    // 0x12dbfc0: DecompressPointer r2
    //     0x12dbfc0: add             x2, x2, HEAP, lsl #32
    // 0x12dbfc4: ldur            x1, [fp, #-8]
    // 0x12dbfc8: r0 = transform()
    //     0x12dbfc8: bl              #0xb755c4  ; [dart:ui] _NativeCanvas::transform
    // 0x12dbfcc: b               #0x12dc024
    // 0x12dbfd0: ldur            x2, [fp, #-8]
    // 0x12dbfd4: LoadField: d0 = r0->field_7
    //     0x12dbfd4: ldur            d0, [x0, #7]
    // 0x12dbfd8: stur            d0, [fp, #-0x28]
    // 0x12dbfdc: LoadField: d1 = r0->field_f
    //     0x12dbfdc: ldur            d1, [x0, #0xf]
    // 0x12dbfe0: stur            d1, [fp, #-0x20]
    // 0x12dbfe4: LoadField: r0 = r2->field_7
    //     0x12dbfe4: ldur            w0, [x2, #7]
    // 0x12dbfe8: DecompressPointer r0
    //     0x12dbfe8: add             x0, x0, HEAP, lsl #32
    // 0x12dbfec: cmp             w0, NULL
    // 0x12dbff0: b.eq            #0x12dc04c
    // 0x12dbff4: LoadField: r1 = r0->field_7
    //     0x12dbff4: ldur            x1, [x0, #7]
    // 0x12dbff8: ldr             x0, [x1]
    // 0x12dbffc: cbz             x0, #0x12dc034
    // 0x12dc000: stur            x0, [fp, #-0x18]
    // 0x12dc004: r1 = <Never>
    //     0x12dc004: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12dc008: r0 = Pointer()
    //     0x12dc008: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12dc00c: mov             x1, x0
    // 0x12dc010: ldur            x0, [fp, #-0x18]
    // 0x12dc014: StoreField: r1->field_7 = r0
    //     0x12dc014: stur            x0, [x1, #7]
    // 0x12dc018: ldur            d0, [fp, #-0x28]
    // 0x12dc01c: ldur            d1, [fp, #-0x20]
    // 0x12dc020: r0 = _translate$Method$FfiNative()
    //     0x12dc020: bl              #0xb74a38  ; [dart:ui] _NativeCanvas::_translate$Method$FfiNative
    // 0x12dc024: r0 = Null
    //     0x12dc024: mov             x0, NULL
    // 0x12dc028: LeaveFrame
    //     0x12dc028: mov             SP, fp
    //     0x12dc02c: ldp             fp, lr, [SP], #0x10
    // 0x12dc030: ret
    //     0x12dc030: ret             
    // 0x12dc034: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12dc034: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12dc038: str             x16, [SP]
    // 0x12dc03c: r0 = _throwNew()
    //     0x12dc03c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12dc040: brk             #0
    // 0x12dc044: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12dc044: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12dc048: b               #0x12dbfa8
    // 0x12dc04c: r0 = NullErrorSharedWithFPURegs()
    //     0x12dc04c: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
}
