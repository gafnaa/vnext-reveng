// lib: , url: package:flutter/src/material/ink_highlight.dart

// class id: 1048901, size: 0x8
class :: {
}

// class id: 3041, size: 0x3c, field offset: 0x1c
class InkHighlight extends InteractiveInkFeature {

  late AnimationController _alphaController; // offset: 0x34
  late Animation<int> _alpha; // offset: 0x30

  _ deactivate(/* No info */) {
    // ** addr: 0xd217d8, size: 0x60
    // 0xd217d8: EnterFrame
    //     0xd217d8: stp             fp, lr, [SP, #-0x10]!
    //     0xd217dc: mov             fp, SP
    // 0xd217e0: r0 = false
    //     0xd217e0: add             x0, NULL, #0x30  ; false
    // 0xd217e4: CheckStackOverflow
    //     0xd217e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd217e8: cmp             SP, x16
    //     0xd217ec: b.ls            #0xd21824
    // 0xd217f0: StoreField: r1->field_37 = r0
    //     0xd217f0: stur            w0, [x1, #0x37]
    // 0xd217f4: LoadField: r0 = r1->field_33
    //     0xd217f4: ldur            w0, [x1, #0x33]
    // 0xd217f8: DecompressPointer r0
    //     0xd217f8: add             x0, x0, HEAP, lsl #32
    // 0xd217fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd21800: cmp             w0, w16
    // 0xd21804: b.eq            #0xd2182c
    // 0xd21808: mov             x1, x0
    // 0xd2180c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd2180c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd21810: r0 = reverse()
    //     0xd21810: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xd21814: r0 = Null
    //     0xd21814: mov             x0, NULL
    // 0xd21818: LeaveFrame
    //     0xd21818: mov             SP, fp
    //     0xd2181c: ldp             fp, lr, [SP], #0x10
    // 0xd21820: ret
    //     0xd21820: ret             
    // 0xd21824: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd21824: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd21828: b               #0xd217f0
    // 0xd2182c: r9 = _alphaController
    //     0xd2182c: add             x9, PP, #0x99, lsl #12  ; [pp+0x994f0] Field <InkHighlight._alphaController@754209331>: late (offset: 0x34)
    //     0xd21830: ldr             x9, [x9, #0x4f0]
    // 0xd21834: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd21834: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ activate(/* No info */) {
    // ** addr: 0xd21838, size: 0x60
    // 0xd21838: EnterFrame
    //     0xd21838: stp             fp, lr, [SP, #-0x10]!
    //     0xd2183c: mov             fp, SP
    // 0xd21840: r0 = true
    //     0xd21840: add             x0, NULL, #0x20  ; true
    // 0xd21844: CheckStackOverflow
    //     0xd21844: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd21848: cmp             SP, x16
    //     0xd2184c: b.ls            #0xd21884
    // 0xd21850: StoreField: r1->field_37 = r0
    //     0xd21850: stur            w0, [x1, #0x37]
    // 0xd21854: LoadField: r0 = r1->field_33
    //     0xd21854: ldur            w0, [x1, #0x33]
    // 0xd21858: DecompressPointer r0
    //     0xd21858: add             x0, x0, HEAP, lsl #32
    // 0xd2185c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd21860: cmp             w0, w16
    // 0xd21864: b.eq            #0xd2188c
    // 0xd21868: mov             x1, x0
    // 0xd2186c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd2186c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd21870: r0 = forward()
    //     0xd21870: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xd21874: r0 = Null
    //     0xd21874: mov             x0, NULL
    // 0xd21878: LeaveFrame
    //     0xd21878: mov             SP, fp
    //     0xd2187c: ldp             fp, lr, [SP], #0x10
    // 0xd21880: ret
    //     0xd21880: ret             
    // 0xd21884: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd21884: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd21888: b               #0xd21850
    // 0xd2188c: r9 = _alphaController
    //     0xd2188c: add             x9, PP, #0x99, lsl #12  ; [pp+0x994f0] Field <InkHighlight._alphaController@754209331>: late (offset: 0x34)
    //     0xd21890: ldr             x9, [x9, #0x4f0]
    // 0xd21894: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd21894: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ InkHighlight(/* No info */) {
    // ** addr: 0xd21968, size: 0x2d8
    // 0xd21968: EnterFrame
    //     0xd21968: stp             fp, lr, [SP, #-0x10]!
    //     0xd2196c: mov             fp, SP
    // 0xd21970: AllocStack(0x38)
    //     0xd21970: sub             SP, SP, #0x38
    // 0xd21974: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0xd21978: r0 = true
    //     0xd21978: add             x0, NULL, #0x20  ; true
    // 0xd2197c: stur            x1, [fp, #-0x10]
    // 0xd21980: mov             x16, x6
    // 0xd21984: mov             x6, x1
    // 0xd21988: mov             x1, x16
    // 0xd2198c: mov             x16, x5
    // 0xd21990: mov             x5, x2
    // 0xd21994: mov             x2, x16
    // 0xd21998: stur            x2, [fp, #-0x18]
    // 0xd2199c: stur            x7, [fp, #-0x20]
    // 0xd219a0: CheckStackOverflow
    //     0xd219a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd219a4: cmp             SP, x16
    //     0xd219a8: b.ls            #0xd21c38
    // 0xd219ac: StoreField: r6->field_2f = r4
    //     0xd219ac: stur            w4, [x6, #0x2f]
    // 0xd219b0: StoreField: r6->field_33 = r4
    //     0xd219b0: stur            w4, [x6, #0x33]
    // 0xd219b4: StoreField: r6->field_37 = r0
    //     0xd219b4: stur            w0, [x6, #0x37]
    // 0xd219b8: ldr             x0, [fp, #0x18]
    // 0xd219bc: StoreField: r6->field_1b = r0
    //     0xd219bc: stur            w0, [x6, #0x1b]
    //     0xd219c0: ldurb           w16, [x6, #-1]
    //     0xd219c4: ldurb           w17, [x0, #-1]
    //     0xd219c8: and             x16, x17, x16, lsr #2
    //     0xd219cc: tst             x16, HEAP, lsr #32
    //     0xd219d0: b.eq            #0xd219d8
    //     0xd219d4: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xd219d8: ldr             x0, [fp, #0x30]
    // 0xd219dc: StoreField: r6->field_1f = r0
    //     0xd219dc: stur            w0, [x6, #0x1f]
    //     0xd219e0: ldurb           w16, [x6, #-1]
    //     0xd219e4: ldurb           w17, [x0, #-1]
    //     0xd219e8: and             x16, x17, x16, lsr #2
    //     0xd219ec: tst             x16, HEAP, lsr #32
    //     0xd219f0: b.eq            #0xd219f8
    //     0xd219f4: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xd219f8: cmp             w5, NULL
    // 0xd219fc: b.ne            #0xd21a0c
    // 0xd21a00: r0 = Instance_BorderRadius
    //     0xd21a00: add             x0, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0xd21a04: ldr             x0, [x0, #0x508]
    // 0xd21a08: b               #0xd21a10
    // 0xd21a0c: mov             x0, x5
    // 0xd21a10: StoreField: r6->field_23 = r0
    //     0xd21a10: stur            w0, [x6, #0x23]
    //     0xd21a14: ldurb           w16, [x6, #-1]
    //     0xd21a18: ldurb           w17, [x0, #-1]
    //     0xd21a1c: and             x16, x17, x16, lsr #2
    //     0xd21a20: tst             x16, HEAP, lsr #32
    //     0xd21a24: b.eq            #0xd21a2c
    //     0xd21a28: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xd21a2c: ldr             x0, [fp, #0x10]
    // 0xd21a30: StoreField: r6->field_2b = r0
    //     0xd21a30: stur            w0, [x6, #0x2b]
    //     0xd21a34: ldurb           w16, [x6, #-1]
    //     0xd21a38: ldurb           w17, [x0, #-1]
    //     0xd21a3c: and             x16, x17, x16, lsr #2
    //     0xd21a40: tst             x16, HEAP, lsr #32
    //     0xd21a44: b.eq            #0xd21a4c
    //     0xd21a48: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xd21a4c: ldr             x0, [fp, #0x28]
    // 0xd21a50: StoreField: r6->field_27 = r0
    //     0xd21a50: stur            w0, [x6, #0x27]
    //     0xd21a54: ldurb           w16, [x6, #-1]
    //     0xd21a58: ldurb           w17, [x0, #-1]
    //     0xd21a5c: and             x16, x17, x16, lsr #2
    //     0xd21a60: tst             x16, HEAP, lsr #32
    //     0xd21a64: b.eq            #0xd21a6c
    //     0xd21a68: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xd21a6c: mov             x0, x3
    // 0xd21a70: StoreField: r6->field_13 = r0
    //     0xd21a70: stur            w0, [x6, #0x13]
    //     0xd21a74: ldurb           w16, [x6, #-1]
    //     0xd21a78: ldurb           w17, [x0, #-1]
    //     0xd21a7c: and             x16, x17, x16, lsr #2
    //     0xd21a80: tst             x16, HEAP, lsr #32
    //     0xd21a84: b.eq            #0xd21a8c
    //     0xd21a88: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xd21a8c: mov             x0, x1
    // 0xd21a90: ArrayStore: r6[0] = r0  ; List_4
    //     0xd21a90: stur            w0, [x6, #0x17]
    //     0xd21a94: ldurb           w16, [x6, #-1]
    //     0xd21a98: ldurb           w17, [x0, #-1]
    //     0xd21a9c: and             x16, x17, x16, lsr #2
    //     0xd21aa0: tst             x16, HEAP, lsr #32
    //     0xd21aa4: b.eq            #0xd21aac
    //     0xd21aa8: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xd21aac: ldr             x0, [fp, #0x20]
    // 0xd21ab0: StoreField: r6->field_b = r0
    //     0xd21ab0: stur            w0, [x6, #0xb]
    //     0xd21ab4: ldurb           w16, [x6, #-1]
    //     0xd21ab8: ldurb           w17, [x0, #-1]
    //     0xd21abc: and             x16, x17, x16, lsr #2
    //     0xd21ac0: tst             x16, HEAP, lsr #32
    //     0xd21ac4: b.eq            #0xd21acc
    //     0xd21ac8: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xd21acc: ldr             x0, [fp, #0x38]
    // 0xd21ad0: StoreField: r6->field_f = r0
    //     0xd21ad0: stur            w0, [x6, #0xf]
    //     0xd21ad4: ldurb           w16, [x6, #-1]
    //     0xd21ad8: ldurb           w17, [x0, #-1]
    //     0xd21adc: and             x16, x17, x16, lsr #2
    //     0xd21ae0: tst             x16, HEAP, lsr #32
    //     0xd21ae4: b.eq            #0xd21aec
    //     0xd21ae8: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xd21aec: mov             x0, x2
    // 0xd21af0: StoreField: r6->field_7 = r0
    //     0xd21af0: stur            w0, [x6, #7]
    //     0xd21af4: ldurb           w16, [x6, #-1]
    //     0xd21af8: ldurb           w17, [x0, #-1]
    //     0xd21afc: and             x16, x17, x16, lsr #2
    //     0xd21b00: tst             x16, HEAP, lsr #32
    //     0xd21b04: b.eq            #0xd21b0c
    //     0xd21b08: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xd21b0c: LoadField: r0 = r2->field_53
    //     0xd21b0c: ldur            w0, [x2, #0x53]
    // 0xd21b10: DecompressPointer r0
    //     0xd21b10: add             x0, x0, HEAP, lsl #32
    // 0xd21b14: stur            x0, [fp, #-8]
    // 0xd21b18: r1 = <double>
    //     0xd21b18: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd21b1c: r0 = AnimationController()
    //     0xd21b1c: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xd21b20: stur            x0, [fp, #-0x28]
    // 0xd21b24: ldur            x16, [fp, #-0x20]
    // 0xd21b28: str             x16, [SP]
    // 0xd21b2c: mov             x1, x0
    // 0xd21b30: ldur            x2, [fp, #-8]
    // 0xd21b34: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xd21b34: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xd21b38: ldr             x4, [x4, #0x5a0]
    // 0xd21b3c: r0 = AnimationController()
    //     0xd21b3c: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xd21b40: ldur            x2, [fp, #-0x18]
    // 0xd21b44: r1 = Function 'markNeedsPaint':.
    //     0xd21b44: add             x1, PP, #0x90, lsl #12  ; [pp+0x901f0] AnonymousClosure: (0xbf0a50), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0xbf0858)
    //     0xd21b48: ldr             x1, [x1, #0x1f0]
    // 0xd21b4c: r0 = AllocateClosure()
    //     0xd21b4c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd21b50: ldur            x1, [fp, #-0x28]
    // 0xd21b54: mov             x2, x0
    // 0xd21b58: r0 = addListener()
    //     0xd21b58: bl              #0xd0440c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::addListener
    // 0xd21b5c: ldur            x2, [fp, #-0x10]
    // 0xd21b60: r1 = Function '_handleAlphaStatusChanged@754209331':.
    //     0xd21b60: add             x1, PP, #0x99, lsl #12  ; [pp+0x99510] AnonymousClosure: (0xd21d60), in [package:flutter/src/material/ink_highlight.dart] InkHighlight::_handleAlphaStatusChanged (0xd21d9c)
    //     0xd21b64: ldr             x1, [x1, #0x510]
    // 0xd21b68: r0 = AllocateClosure()
    //     0xd21b68: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd21b6c: ldur            x1, [fp, #-0x28]
    // 0xd21b70: mov             x2, x0
    // 0xd21b74: r0 = addStatusListener()
    //     0xd21b74: bl              #0x1254cc0  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0xd21b78: ldur            x1, [fp, #-0x28]
    // 0xd21b7c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd21b7c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd21b80: r0 = forward()
    //     0xd21b80: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xd21b84: ldur            x0, [fp, #-0x28]
    // 0xd21b88: ldur            x2, [fp, #-0x10]
    // 0xd21b8c: StoreField: r2->field_33 = r0
    //     0xd21b8c: stur            w0, [x2, #0x33]
    //     0xd21b90: ldurb           w16, [x2, #-1]
    //     0xd21b94: ldurb           w17, [x0, #-1]
    //     0xd21b98: and             x16, x17, x16, lsr #2
    //     0xd21b9c: tst             x16, HEAP, lsr #32
    //     0xd21ba0: b.eq            #0xd21ba8
    //     0xd21ba4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd21ba8: LoadField: r1 = r2->field_13
    //     0xd21ba8: ldur            w1, [x2, #0x13]
    // 0xd21bac: DecompressPointer r1
    //     0xd21bac: add             x1, x1, HEAP, lsl #32
    // 0xd21bb0: r0 = LoadClassIdInstr(r1)
    //     0xd21bb0: ldur            x0, [x1, #-1]
    //     0xd21bb4: ubfx            x0, x0, #0xc, #0x14
    // 0xd21bb8: r0 = GDT[cid_x0 + -0xfc0]()
    //     0xd21bb8: sub             lr, x0, #0xfc0
    //     0xd21bbc: ldr             lr, [x21, lr, lsl #3]
    //     0xd21bc0: blr             lr
    // 0xd21bc4: r1 = <int>
    //     0xd21bc4: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0xd21bc8: stur            x0, [fp, #-0x30]
    // 0xd21bcc: r0 = IntTween()
    //     0xd21bcc: bl              #0xd21d54  ; AllocateIntTweenStub -> IntTween (size=0x14)
    // 0xd21bd0: mov             x2, x0
    // 0xd21bd4: StoreField: r2->field_b = rZR
    //     0xd21bd4: stur            wzr, [x2, #0xb]
    // 0xd21bd8: ldur            x3, [fp, #-0x30]
    // 0xd21bdc: r0 = BoxInt64Instr(r3)
    //     0xd21bdc: sbfiz           x0, x3, #1, #0x1f
    //     0xd21be0: cmp             x3, x0, asr #1
    //     0xd21be4: b.eq            #0xd21bf0
    //     0xd21be8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xd21bec: stur            x3, [x0, #7]
    // 0xd21bf0: StoreField: r2->field_f = r0
    //     0xd21bf0: stur            w0, [x2, #0xf]
    // 0xd21bf4: mov             x1, x2
    // 0xd21bf8: ldur            x2, [fp, #-0x28]
    // 0xd21bfc: r0 = animate()
    //     0xd21bfc: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xd21c00: ldur            x2, [fp, #-0x10]
    // 0xd21c04: StoreField: r2->field_2f = r0
    //     0xd21c04: stur            w0, [x2, #0x2f]
    //     0xd21c08: ldurb           w16, [x2, #-1]
    //     0xd21c0c: ldurb           w17, [x0, #-1]
    //     0xd21c10: and             x16, x17, x16, lsr #2
    //     0xd21c14: tst             x16, HEAP, lsr #32
    //     0xd21c18: b.eq            #0xd21c20
    //     0xd21c1c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd21c20: ldur            x1, [fp, #-0x18]
    // 0xd21c24: r0 = addInkFeature()
    //     0xd21c24: bl              #0xd21c40  ; [package:flutter/src/material/material.dart] _RenderInkFeatures::addInkFeature
    // 0xd21c28: r0 = Null
    //     0xd21c28: mov             x0, NULL
    // 0xd21c2c: LeaveFrame
    //     0xd21c2c: mov             SP, fp
    //     0xd21c30: ldp             fp, lr, [SP], #0x10
    // 0xd21c34: ret
    //     0xd21c34: ret             
    // 0xd21c38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd21c38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd21c3c: b               #0xd219ac
  }
  [closure] void _handleAlphaStatusChanged(dynamic, AnimationStatus) {
    // ** addr: 0xd21d60, size: 0x3c
    // 0xd21d60: EnterFrame
    //     0xd21d60: stp             fp, lr, [SP, #-0x10]!
    //     0xd21d64: mov             fp, SP
    // 0xd21d68: ldr             x0, [fp, #0x18]
    // 0xd21d6c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd21d6c: ldur            w1, [x0, #0x17]
    // 0xd21d70: DecompressPointer r1
    //     0xd21d70: add             x1, x1, HEAP, lsl #32
    // 0xd21d74: CheckStackOverflow
    //     0xd21d74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd21d78: cmp             SP, x16
    //     0xd21d7c: b.ls            #0xd21d94
    // 0xd21d80: ldr             x2, [fp, #0x10]
    // 0xd21d84: r0 = _handleAlphaStatusChanged()
    //     0xd21d84: bl              #0xd21d9c  ; [package:flutter/src/material/ink_highlight.dart] InkHighlight::_handleAlphaStatusChanged
    // 0xd21d88: LeaveFrame
    //     0xd21d88: mov             SP, fp
    //     0xd21d8c: ldp             fp, lr, [SP], #0x10
    // 0xd21d90: ret
    //     0xd21d90: ret             
    // 0xd21d94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd21d94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd21d98: b               #0xd21d80
  }
  _ _handleAlphaStatusChanged(/* No info */) {
    // ** addr: 0xd21d9c, size: 0x48
    // 0xd21d9c: EnterFrame
    //     0xd21d9c: stp             fp, lr, [SP, #-0x10]!
    //     0xd21da0: mov             fp, SP
    // 0xd21da4: CheckStackOverflow
    //     0xd21da4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd21da8: cmp             SP, x16
    //     0xd21dac: b.ls            #0xd21ddc
    // 0xd21db0: r16 = Instance_AnimationStatus
    //     0xd21db0: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xd21db4: cmp             w2, w16
    // 0xd21db8: b.ne            #0xd21dcc
    // 0xd21dbc: LoadField: r0 = r1->field_37
    //     0xd21dbc: ldur            w0, [x1, #0x37]
    // 0xd21dc0: DecompressPointer r0
    //     0xd21dc0: add             x0, x0, HEAP, lsl #32
    // 0xd21dc4: tbz             w0, #4, #0xd21dcc
    // 0xd21dc8: r0 = dispose()
    //     0xd21dc8: bl              #0x119e764  ; [package:flutter/src/material/ink_highlight.dart] InkHighlight::dispose
    // 0xd21dcc: r0 = Null
    //     0xd21dcc: mov             x0, NULL
    // 0xd21dd0: LeaveFrame
    //     0xd21dd0: mov             SP, fp
    //     0xd21dd4: ldp             fp, lr, [SP], #0x10
    // 0xd21dd8: ret
    //     0xd21dd8: ret             
    // 0xd21ddc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd21ddc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd21de0: b               #0xd21db0
  }
  _ dispose(/* No info */) {
    // ** addr: 0x119e764, size: 0x64
    // 0x119e764: EnterFrame
    //     0x119e764: stp             fp, lr, [SP, #-0x10]!
    //     0x119e768: mov             fp, SP
    // 0x119e76c: AllocStack(0x8)
    //     0x119e76c: sub             SP, SP, #8
    // 0x119e770: SetupParameters(InkHighlight this /* r1 => r0, fp-0x8 */)
    //     0x119e770: mov             x0, x1
    //     0x119e774: stur            x1, [fp, #-8]
    // 0x119e778: CheckStackOverflow
    //     0x119e778: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119e77c: cmp             SP, x16
    //     0x119e780: b.ls            #0x119e7b4
    // 0x119e784: LoadField: r1 = r0->field_33
    //     0x119e784: ldur            w1, [x0, #0x33]
    // 0x119e788: DecompressPointer r1
    //     0x119e788: add             x1, x1, HEAP, lsl #32
    // 0x119e78c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x119e790: cmp             w1, w16
    // 0x119e794: b.eq            #0x119e7bc
    // 0x119e798: r0 = dispose()
    //     0x119e798: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x119e79c: ldur            x1, [fp, #-8]
    // 0x119e7a0: r0 = dispose()
    //     0x119e7a0: bl              #0xf786a8  ; [package:flutter/src/material/material.dart] InkFeature::dispose
    // 0x119e7a4: r0 = Null
    //     0x119e7a4: mov             x0, NULL
    // 0x119e7a8: LeaveFrame
    //     0x119e7a8: mov             SP, fp
    //     0x119e7ac: ldp             fp, lr, [SP], #0x10
    // 0x119e7b0: ret
    //     0x119e7b0: ret             
    // 0x119e7b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119e7b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119e7b8: b               #0x119e784
    // 0x119e7bc: r9 = _alphaController
    //     0x119e7bc: add             x9, PP, #0x99, lsl #12  ; [pp+0x994f0] Field <InkHighlight._alphaController@754209331>: late (offset: 0x34)
    //     0x119e7c0: ldr             x9, [x9, #0x4f0]
    // 0x119e7c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x119e7c4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ paintFeature(/* No info */) {
    // ** addr: 0x12da388, size: 0x250
    // 0x12da388: EnterFrame
    //     0x12da388: stp             fp, lr, [SP, #-0x10]!
    //     0x12da38c: mov             fp, SP
    // 0x12da390: AllocStack(0x48)
    //     0x12da390: sub             SP, SP, #0x48
    // 0x12da394: SetupParameters(InkHighlight this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r1, fp-0x18 */)
    //     0x12da394: mov             x0, x2
    //     0x12da398: stur            x2, [fp, #-0x10]
    //     0x12da39c: mov             x2, x1
    //     0x12da3a0: stur            x1, [fp, #-8]
    //     0x12da3a4: mov             x1, x3
    //     0x12da3a8: stur            x3, [fp, #-0x18]
    // 0x12da3ac: CheckStackOverflow
    //     0x12da3ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12da3b0: cmp             SP, x16
    //     0x12da3b4: b.ls            #0x12da5bc
    // 0x12da3b8: r16 = 136
    //     0x12da3b8: mov             x16, #0x88
    // 0x12da3bc: stp             x16, NULL, [SP]
    // 0x12da3c0: r0 = ByteData()
    //     0x12da3c0: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x12da3c4: stur            x0, [fp, #-0x20]
    // 0x12da3c8: r0 = Paint()
    //     0x12da3c8: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x12da3cc: mov             x3, x0
    // 0x12da3d0: ldur            x0, [fp, #-0x20]
    // 0x12da3d4: stur            x3, [fp, #-0x28]
    // 0x12da3d8: StoreField: r3->field_7 = r0
    //     0x12da3d8: stur            w0, [x3, #7]
    // 0x12da3dc: ldur            x4, [fp, #-8]
    // 0x12da3e0: LoadField: r5 = r4->field_13
    //     0x12da3e0: ldur            w5, [x4, #0x13]
    // 0x12da3e4: DecompressPointer r5
    //     0x12da3e4: add             x5, x5, HEAP, lsl #32
    // 0x12da3e8: stur            x5, [fp, #-0x20]
    // 0x12da3ec: LoadField: r0 = r4->field_2f
    //     0x12da3ec: ldur            w0, [x4, #0x2f]
    // 0x12da3f0: DecompressPointer r0
    //     0x12da3f0: add             x0, x0, HEAP, lsl #32
    // 0x12da3f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12da3f8: cmp             w0, w16
    // 0x12da3fc: b.eq            #0x12da5c4
    // 0x12da400: LoadField: r1 = r0->field_f
    //     0x12da400: ldur            w1, [x0, #0xf]
    // 0x12da404: DecompressPointer r1
    //     0x12da404: add             x1, x1, HEAP, lsl #32
    // 0x12da408: LoadField: r2 = r0->field_b
    //     0x12da408: ldur            w2, [x0, #0xb]
    // 0x12da40c: DecompressPointer r2
    //     0x12da40c: add             x2, x2, HEAP, lsl #32
    // 0x12da410: r0 = LoadClassIdInstr(r1)
    //     0x12da410: ldur            x0, [x1, #-1]
    //     0x12da414: ubfx            x0, x0, #0xc, #0x14
    // 0x12da418: r0 = GDT[cid_x0 + 0x80ed]()
    //     0x12da418: mov             x17, #0x80ed
    //     0x12da41c: add             lr, x0, x17
    //     0x12da420: ldr             lr, [x21, lr, lsl #3]
    //     0x12da424: blr             lr
    // 0x12da428: r2 = LoadInt32Instr(r0)
    //     0x12da428: sbfx            x2, x0, #1, #0x1f
    //     0x12da42c: tbz             w0, #0, #0x12da434
    //     0x12da430: ldur            x2, [x0, #7]
    // 0x12da434: ldur            x1, [fp, #-0x20]
    // 0x12da438: r0 = LoadClassIdInstr(r1)
    //     0x12da438: ldur            x0, [x1, #-1]
    //     0x12da43c: ubfx            x0, x0, #0xc, #0x14
    // 0x12da440: r0 = GDT[cid_x0 + -0xff4]()
    //     0x12da440: sub             lr, x0, #0xff4
    //     0x12da444: ldr             lr, [x21, lr, lsl #3]
    //     0x12da448: blr             lr
    // 0x12da44c: ldur            x1, [fp, #-0x28]
    // 0x12da450: mov             x2, x0
    // 0x12da454: r0 = color=()
    //     0x12da454: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x12da458: ldur            x1, [fp, #-0x18]
    // 0x12da45c: r0 = getAsTranslation()
    //     0x12da45c: bl              #0xc155c4  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::getAsTranslation
    // 0x12da460: mov             x2, x0
    // 0x12da464: ldur            x1, [fp, #-8]
    // 0x12da468: stur            x2, [fp, #-0x20]
    // 0x12da46c: LoadField: r0 = r1->field_27
    //     0x12da46c: ldur            w0, [x1, #0x27]
    // 0x12da470: DecompressPointer r0
    //     0x12da470: add             x0, x0, HEAP, lsl #32
    // 0x12da474: cmp             w0, NULL
    // 0x12da478: b.eq            #0x12da494
    // 0x12da47c: str             x0, [SP]
    // 0x12da480: ClosureCall
    //     0x12da480: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x12da484: ldur            x2, [x0, #0x1f]
    //     0x12da488: blr             x2
    // 0x12da48c: mov             x3, x0
    // 0x12da490: b               #0x12da4b4
    // 0x12da494: mov             x0, x1
    // 0x12da498: LoadField: r1 = r0->field_b
    //     0x12da498: ldur            w1, [x0, #0xb]
    // 0x12da49c: DecompressPointer r1
    //     0x12da49c: add             x1, x1, HEAP, lsl #32
    // 0x12da4a0: r0 = size()
    //     0x12da4a0: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x12da4a4: mov             x2, x0
    // 0x12da4a8: r1 = Instance_Offset
    //     0x12da4a8: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x12da4ac: r0 = &()
    //     0x12da4ac: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x12da4b0: mov             x3, x0
    // 0x12da4b4: ldur            x2, [fp, #-0x20]
    // 0x12da4b8: stur            x3, [fp, #-0x38]
    // 0x12da4bc: cmp             w2, NULL
    // 0x12da4c0: b.ne            #0x12da570
    // 0x12da4c4: ldur            x0, [fp, #-0x10]
    // 0x12da4c8: LoadField: r1 = r0->field_7
    //     0x12da4c8: ldur            w1, [x0, #7]
    // 0x12da4cc: DecompressPointer r1
    //     0x12da4cc: add             x1, x1, HEAP, lsl #32
    // 0x12da4d0: cmp             w1, NULL
    // 0x12da4d4: b.eq            #0x12da5d0
    // 0x12da4d8: LoadField: r2 = r1->field_7
    //     0x12da4d8: ldur            x2, [x1, #7]
    // 0x12da4dc: ldr             x1, [x2]
    // 0x12da4e0: cbz             x1, #0x12da59c
    // 0x12da4e4: ldur            x2, [fp, #-0x18]
    // 0x12da4e8: mov             x4, x1
    // 0x12da4ec: stur            x4, [fp, #-0x30]
    // 0x12da4f0: r1 = <Never>
    //     0x12da4f0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12da4f4: r0 = Pointer()
    //     0x12da4f4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12da4f8: mov             x1, x0
    // 0x12da4fc: ldur            x0, [fp, #-0x30]
    // 0x12da500: StoreField: r1->field_7 = r0
    //     0x12da500: stur            x0, [x1, #7]
    // 0x12da504: r0 = _save$Method$FfiNative()
    //     0x12da504: bl              #0xb74adc  ; [dart:ui] _NativeCanvas::_save$Method$FfiNative
    // 0x12da508: ldur            x0, [fp, #-0x18]
    // 0x12da50c: LoadField: r2 = r0->field_7
    //     0x12da50c: ldur            w2, [x0, #7]
    // 0x12da510: DecompressPointer r2
    //     0x12da510: add             x2, x2, HEAP, lsl #32
    // 0x12da514: ldur            x1, [fp, #-0x10]
    // 0x12da518: r0 = transform()
    //     0x12da518: bl              #0xb755c4  ; [dart:ui] _NativeCanvas::transform
    // 0x12da51c: ldur            x1, [fp, #-8]
    // 0x12da520: ldur            x2, [fp, #-0x10]
    // 0x12da524: ldur            x3, [fp, #-0x38]
    // 0x12da528: ldur            x5, [fp, #-0x28]
    // 0x12da52c: r0 = _paintHighlight()
    //     0x12da52c: bl              #0x12da5d8  ; [package:flutter/src/material/ink_highlight.dart] InkHighlight::_paintHighlight
    // 0x12da530: ldur            x2, [fp, #-0x10]
    // 0x12da534: LoadField: r0 = r2->field_7
    //     0x12da534: ldur            w0, [x2, #7]
    // 0x12da538: DecompressPointer r0
    //     0x12da538: add             x0, x0, HEAP, lsl #32
    // 0x12da53c: cmp             w0, NULL
    // 0x12da540: b.eq            #0x12da5d4
    // 0x12da544: LoadField: r1 = r0->field_7
    //     0x12da544: ldur            x1, [x0, #7]
    // 0x12da548: ldr             x0, [x1]
    // 0x12da54c: cbz             x0, #0x12da5ac
    // 0x12da550: stur            x0, [fp, #-0x30]
    // 0x12da554: r1 = <Never>
    //     0x12da554: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12da558: r0 = Pointer()
    //     0x12da558: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12da55c: mov             x1, x0
    // 0x12da560: ldur            x0, [fp, #-0x30]
    // 0x12da564: StoreField: r1->field_7 = r0
    //     0x12da564: stur            x0, [x1, #7]
    // 0x12da568: r0 = _restore$Method$FfiNative()
    //     0x12da568: bl              #0xb74908  ; [dart:ui] _NativeCanvas::_restore$Method$FfiNative
    // 0x12da56c: b               #0x12da58c
    // 0x12da570: ldur            x1, [fp, #-0x38]
    // 0x12da574: r0 = shift()
    //     0x12da574: bl              #0x8610a4  ; [dart:ui] Rect::shift
    // 0x12da578: ldur            x1, [fp, #-8]
    // 0x12da57c: ldur            x2, [fp, #-0x10]
    // 0x12da580: mov             x3, x0
    // 0x12da584: ldur            x5, [fp, #-0x28]
    // 0x12da588: r0 = _paintHighlight()
    //     0x12da588: bl              #0x12da5d8  ; [package:flutter/src/material/ink_highlight.dart] InkHighlight::_paintHighlight
    // 0x12da58c: r0 = Null
    //     0x12da58c: mov             x0, NULL
    // 0x12da590: LeaveFrame
    //     0x12da590: mov             SP, fp
    //     0x12da594: ldp             fp, lr, [SP], #0x10
    // 0x12da598: ret
    //     0x12da598: ret             
    // 0x12da59c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12da59c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12da5a0: str             x16, [SP]
    // 0x12da5a4: r0 = _throwNew()
    //     0x12da5a4: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12da5a8: brk             #0
    // 0x12da5ac: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12da5ac: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12da5b0: str             x16, [SP]
    // 0x12da5b4: r0 = _throwNew()
    //     0x12da5b4: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12da5b8: brk             #0
    // 0x12da5bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12da5bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12da5c0: b               #0x12da3b8
    // 0x12da5c4: r9 = _alpha
    //     0x12da5c4: add             x9, PP, #0xab, lsl #12  ; [pp+0xab180] Field <InkHighlight._alpha@754209331>: late (offset: 0x30)
    //     0x12da5c8: ldr             x9, [x9, #0x180]
    // 0x12da5cc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12da5cc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12da5d0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12da5d0: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12da5d4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12da5d4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _paintHighlight(/* No info */) {
    // ** addr: 0x12da5d8, size: 0x2e4
    // 0x12da5d8: EnterFrame
    //     0x12da5d8: stp             fp, lr, [SP, #-0x10]!
    //     0x12da5dc: mov             fp, SP
    // 0x12da5e0: AllocStack(0x60)
    //     0x12da5e0: sub             SP, SP, #0x60
    // 0x12da5e4: SetupParameters(InkHighlight this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* r3 => r2, fp-0x20 */, dynamic _ /* r5 => r3, fp-0x28 */)
    //     0x12da5e4: mov             x4, x1
    //     0x12da5e8: mov             x0, x2
    //     0x12da5ec: stur            x2, [fp, #-0x18]
    //     0x12da5f0: mov             x2, x3
    //     0x12da5f4: stur            x3, [fp, #-0x20]
    //     0x12da5f8: mov             x3, x5
    //     0x12da5fc: stur            x1, [fp, #-0x10]
    //     0x12da600: stur            x5, [fp, #-0x28]
    // 0x12da604: CheckStackOverflow
    //     0x12da604: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12da608: cmp             SP, x16
    //     0x12da60c: b.ls            #0x12da8a4
    // 0x12da610: LoadField: r1 = r0->field_7
    //     0x12da610: ldur            w1, [x0, #7]
    // 0x12da614: DecompressPointer r1
    //     0x12da614: add             x1, x1, HEAP, lsl #32
    // 0x12da618: cmp             w1, NULL
    // 0x12da61c: b.eq            #0x12da8ac
    // 0x12da620: LoadField: r5 = r1->field_7
    //     0x12da620: ldur            x5, [x1, #7]
    // 0x12da624: ldr             x1, [x5]
    // 0x12da628: cbz             x1, #0x12da874
    // 0x12da62c: mov             x5, x1
    // 0x12da630: stur            x5, [fp, #-8]
    // 0x12da634: r1 = <Never>
    //     0x12da634: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12da638: r0 = Pointer()
    //     0x12da638: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12da63c: mov             x1, x0
    // 0x12da640: ldur            x0, [fp, #-8]
    // 0x12da644: StoreField: r1->field_7 = r0
    //     0x12da644: stur            x0, [x1, #7]
    // 0x12da648: r0 = _save$Method$FfiNative()
    //     0x12da648: bl              #0xb74adc  ; [dart:ui] _NativeCanvas::_save$Method$FfiNative
    // 0x12da64c: ldur            x3, [fp, #-0x10]
    // 0x12da650: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x12da650: ldur            w1, [x3, #0x17]
    // 0x12da654: DecompressPointer r1
    //     0x12da654: add             x1, x1, HEAP, lsl #32
    // 0x12da658: cmp             w1, NULL
    // 0x12da65c: b.eq            #0x12da724
    // 0x12da660: ldur            x4, [fp, #-0x18]
    // 0x12da664: LoadField: r0 = r3->field_2b
    //     0x12da664: ldur            w0, [x3, #0x2b]
    // 0x12da668: DecompressPointer r0
    //     0x12da668: add             x0, x0, HEAP, lsl #32
    // 0x12da66c: r2 = LoadClassIdInstr(r1)
    //     0x12da66c: ldur            x2, [x1, #-1]
    //     0x12da670: ubfx            x2, x2, #0xc, #0x14
    // 0x12da674: str             x0, [SP]
    // 0x12da678: mov             x0, x2
    // 0x12da67c: ldur            x2, [fp, #-0x20]
    // 0x12da680: r4 = const [0, 0x3, 0x1, 0x2, textDirection, 0x2, null]
    //     0x12da680: add             x4, PP, #0x97, lsl #12  ; [pp+0x97638] List(7) [0, 0x3, 0x1, 0x2, "textDirection", 0x2, Null]
    //     0x12da684: ldr             x4, [x4, #0x638]
    // 0x12da688: r0 = GDT[cid_x0 + -0xfc1]()
    //     0x12da688: sub             lr, x0, #0xfc1
    //     0x12da68c: ldr             lr, [x21, lr, lsl #3]
    //     0x12da690: blr             lr
    // 0x12da694: mov             x2, x0
    // 0x12da698: ldur            x0, [fp, #-0x18]
    // 0x12da69c: stur            x2, [fp, #-0x30]
    // 0x12da6a0: LoadField: r1 = r0->field_7
    //     0x12da6a0: ldur            w1, [x0, #7]
    // 0x12da6a4: DecompressPointer r1
    //     0x12da6a4: add             x1, x1, HEAP, lsl #32
    // 0x12da6a8: cmp             w1, NULL
    // 0x12da6ac: b.eq            #0x12da8b0
    // 0x12da6b0: LoadField: r3 = r1->field_7
    //     0x12da6b0: ldur            x3, [x1, #7]
    // 0x12da6b4: ldr             x1, [x3]
    // 0x12da6b8: cbz             x1, #0x12da884
    // 0x12da6bc: mov             x3, x1
    // 0x12da6c0: stur            x3, [fp, #-8]
    // 0x12da6c4: r1 = <Never>
    //     0x12da6c4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12da6c8: r0 = Pointer()
    //     0x12da6c8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12da6cc: mov             x2, x0
    // 0x12da6d0: ldur            x0, [fp, #-8]
    // 0x12da6d4: stur            x2, [fp, #-0x38]
    // 0x12da6d8: StoreField: r2->field_7 = r0
    //     0x12da6d8: stur            x0, [x2, #7]
    // 0x12da6dc: ldur            x0, [fp, #-0x30]
    // 0x12da6e0: LoadField: r1 = r0->field_7
    //     0x12da6e0: ldur            w1, [x0, #7]
    // 0x12da6e4: DecompressPointer r1
    //     0x12da6e4: add             x1, x1, HEAP, lsl #32
    // 0x12da6e8: cmp             w1, NULL
    // 0x12da6ec: b.eq            #0x12da8b4
    // 0x12da6f0: LoadField: r3 = r1->field_7
    //     0x12da6f0: ldur            x3, [x1, #7]
    // 0x12da6f4: ldr             x1, [x3]
    // 0x12da6f8: mov             x3, x1
    // 0x12da6fc: stur            x3, [fp, #-8]
    // 0x12da700: r1 = <Never>
    //     0x12da700: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12da704: r0 = Pointer()
    //     0x12da704: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12da708: mov             x1, x0
    // 0x12da70c: ldur            x0, [fp, #-8]
    // 0x12da710: StoreField: r1->field_7 = r0
    //     0x12da710: stur            x0, [x1, #7]
    // 0x12da714: mov             x2, x1
    // 0x12da718: ldur            x1, [fp, #-0x38]
    // 0x12da71c: r3 = true
    //     0x12da71c: add             x3, NULL, #0x20  ; true
    // 0x12da720: r0 = __clipPath$Method$FfiNative()
    //     0x12da720: bl              #0xc1ac40  ; [dart:ui] _NativeCanvas::__clipPath$Method$FfiNative
    // 0x12da724: ldur            x0, [fp, #-0x10]
    // 0x12da728: LoadField: r1 = r0->field_1b
    //     0x12da728: ldur            w1, [x0, #0x1b]
    // 0x12da72c: DecompressPointer r1
    //     0x12da72c: add             x1, x1, HEAP, lsl #32
    // 0x12da730: LoadField: r2 = r1->field_7
    //     0x12da730: ldur            x2, [x1, #7]
    // 0x12da734: cmp             x2, #0
    // 0x12da738: b.gt            #0x12da7e4
    // 0x12da73c: LoadField: r1 = r0->field_23
    //     0x12da73c: ldur            w1, [x0, #0x23]
    // 0x12da740: DecompressPointer r1
    //     0x12da740: add             x1, x1, HEAP, lsl #32
    // 0x12da744: stur            x1, [fp, #-0x30]
    // 0x12da748: r16 = Instance_BorderRadius
    //     0x12da748: add             x16, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0x12da74c: ldr             x16, [x16, #0x508]
    // 0x12da750: stp             x16, x1, [SP]
    // 0x12da754: r0 = ==()
    //     0x12da754: bl              #0x1298058  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x12da758: tbz             w0, #4, #0x12da7d0
    // 0x12da75c: ldur            x0, [fp, #-0x30]
    // 0x12da760: LoadField: r6 = r0->field_7
    //     0x12da760: ldur            w6, [x0, #7]
    // 0x12da764: DecompressPointer r6
    //     0x12da764: add             x6, x6, HEAP, lsl #32
    // 0x12da768: stur            x6, [fp, #-0x50]
    // 0x12da76c: LoadField: r7 = r0->field_b
    //     0x12da76c: ldur            w7, [x0, #0xb]
    // 0x12da770: DecompressPointer r7
    //     0x12da770: add             x7, x7, HEAP, lsl #32
    // 0x12da774: stur            x7, [fp, #-0x48]
    // 0x12da778: LoadField: r3 = r0->field_f
    //     0x12da778: ldur            w3, [x0, #0xf]
    // 0x12da77c: DecompressPointer r3
    //     0x12da77c: add             x3, x3, HEAP, lsl #32
    // 0x12da780: stur            x3, [fp, #-0x40]
    // 0x12da784: LoadField: r5 = r0->field_13
    //     0x12da784: ldur            w5, [x0, #0x13]
    // 0x12da788: DecompressPointer r5
    //     0x12da788: add             x5, x5, HEAP, lsl #32
    // 0x12da78c: stur            x5, [fp, #-0x38]
    // 0x12da790: r1 = <RRect>
    //     0x12da790: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0x12da794: ldr             x1, [x1, #0x108]
    // 0x12da798: r0 = RRect()
    //     0x12da798: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0x12da79c: mov             x1, x0
    // 0x12da7a0: ldur            x2, [fp, #-0x20]
    // 0x12da7a4: ldur            x3, [fp, #-0x40]
    // 0x12da7a8: ldur            x5, [fp, #-0x38]
    // 0x12da7ac: ldur            x6, [fp, #-0x50]
    // 0x12da7b0: ldur            x7, [fp, #-0x48]
    // 0x12da7b4: stur            x0, [fp, #-0x30]
    // 0x12da7b8: r0 = RSuperellipse.fromRectAndCorners()
    //     0x12da7b8: bl              #0xb77b20  ; [dart:ui] RSuperellipse::RSuperellipse.fromRectAndCorners
    // 0x12da7bc: ldur            x1, [fp, #-0x18]
    // 0x12da7c0: ldur            x2, [fp, #-0x30]
    // 0x12da7c4: ldur            x3, [fp, #-0x28]
    // 0x12da7c8: r0 = drawRRect()
    //     0x12da7c8: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0x12da7cc: b               #0x12da824
    // 0x12da7d0: ldur            x1, [fp, #-0x18]
    // 0x12da7d4: ldur            x2, [fp, #-0x20]
    // 0x12da7d8: ldur            x3, [fp, #-0x28]
    // 0x12da7dc: r0 = drawRect()
    //     0x12da7dc: bl              #0xb704c8  ; [dart:ui] _NativeCanvas::drawRect
    // 0x12da7e0: b               #0x12da824
    // 0x12da7e4: ldur            x1, [fp, #-0x20]
    // 0x12da7e8: r0 = center()
    //     0x12da7e8: bl              #0x869350  ; [dart:ui] Rect::center
    // 0x12da7ec: mov             x1, x0
    // 0x12da7f0: ldur            x0, [fp, #-0x10]
    // 0x12da7f4: LoadField: r2 = r0->field_1f
    //     0x12da7f4: ldur            w2, [x0, #0x1f]
    // 0x12da7f8: DecompressPointer r2
    //     0x12da7f8: add             x2, x2, HEAP, lsl #32
    // 0x12da7fc: cmp             w2, NULL
    // 0x12da800: b.ne            #0x12da810
    // 0x12da804: d0 = 35.000000
    //     0x12da804: add             x17, PP, #0x80, lsl #12  ; [pp+0x80c28] IMM: double(35) from 0x4041800000000000
    //     0x12da808: ldr             d0, [x17, #0xc28]
    // 0x12da80c: b               #0x12da814
    // 0x12da810: LoadField: d0 = r2->field_7
    //     0x12da810: ldur            d0, [x2, #7]
    // 0x12da814: mov             x2, x1
    // 0x12da818: ldur            x1, [fp, #-0x18]
    // 0x12da81c: ldur            x3, [fp, #-0x28]
    // 0x12da820: r0 = drawCircle()
    //     0x12da820: bl              #0xb6acd4  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x12da824: ldur            x0, [fp, #-0x18]
    // 0x12da828: LoadField: r1 = r0->field_7
    //     0x12da828: ldur            w1, [x0, #7]
    // 0x12da82c: DecompressPointer r1
    //     0x12da82c: add             x1, x1, HEAP, lsl #32
    // 0x12da830: cmp             w1, NULL
    // 0x12da834: b.eq            #0x12da8b8
    // 0x12da838: LoadField: r2 = r1->field_7
    //     0x12da838: ldur            x2, [x1, #7]
    // 0x12da83c: ldr             x1, [x2]
    // 0x12da840: cbz             x1, #0x12da894
    // 0x12da844: mov             x2, x1
    // 0x12da848: stur            x2, [fp, #-8]
    // 0x12da84c: r1 = <Never>
    //     0x12da84c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12da850: r0 = Pointer()
    //     0x12da850: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12da854: mov             x1, x0
    // 0x12da858: ldur            x0, [fp, #-8]
    // 0x12da85c: StoreField: r1->field_7 = r0
    //     0x12da85c: stur            x0, [x1, #7]
    // 0x12da860: r0 = _restore$Method$FfiNative()
    //     0x12da860: bl              #0xb74908  ; [dart:ui] _NativeCanvas::_restore$Method$FfiNative
    // 0x12da864: r0 = Null
    //     0x12da864: mov             x0, NULL
    // 0x12da868: LeaveFrame
    //     0x12da868: mov             SP, fp
    //     0x12da86c: ldp             fp, lr, [SP], #0x10
    // 0x12da870: ret
    //     0x12da870: ret             
    // 0x12da874: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12da874: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12da878: str             x16, [SP]
    // 0x12da87c: r0 = _throwNew()
    //     0x12da87c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12da880: brk             #0
    // 0x12da884: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12da884: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12da888: str             x16, [SP]
    // 0x12da88c: r0 = _throwNew()
    //     0x12da88c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12da890: brk             #0
    // 0x12da894: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12da894: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12da898: str             x16, [SP]
    // 0x12da89c: r0 = _throwNew()
    //     0x12da89c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12da8a0: brk             #0
    // 0x12da8a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12da8a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12da8a8: b               #0x12da610
    // 0x12da8ac: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12da8ac: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12da8b0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12da8b0: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12da8b4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12da8b4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12da8b8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12da8b8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
}
