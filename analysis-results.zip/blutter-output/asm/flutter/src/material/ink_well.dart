// lib: , url: package:flutter/src/material/ink_well.dart

// class id: 1048905, size: 0x8
class :: {
}

// class id: 3031, size: 0x8, field offset: 0x8
abstract class _ParentInkResponseState extends Object {
}

// class id: 3032, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class InteractiveInkFeatureFactory extends Object {
}

// class id: 3037, size: 0x1c, field offset: 0x14
abstract class InteractiveInkFeature extends InkFeature {

  set _ color=(/* No info */) {
    // ** addr: 0xd20c24, size: 0xb0
    // 0xd20c24: EnterFrame
    //     0xd20c24: stp             fp, lr, [SP, #-0x10]!
    //     0xd20c28: mov             fp, SP
    // 0xd20c2c: AllocStack(0x20)
    //     0xd20c2c: sub             SP, SP, #0x20
    // 0xd20c30: SetupParameters(InteractiveInkFeature this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd20c30: stur            x1, [fp, #-8]
    //     0xd20c34: mov             x16, x2
    //     0xd20c38: mov             x2, x1
    //     0xd20c3c: mov             x1, x16
    //     0xd20c40: stur            x1, [fp, #-0x10]
    // 0xd20c44: CheckStackOverflow
    //     0xd20c44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd20c48: cmp             SP, x16
    //     0xd20c4c: b.ls            #0xd20ccc
    // 0xd20c50: LoadField: r0 = r2->field_13
    //     0xd20c50: ldur            w0, [x2, #0x13]
    // 0xd20c54: DecompressPointer r0
    //     0xd20c54: add             x0, x0, HEAP, lsl #32
    // 0xd20c58: r3 = LoadClassIdInstr(r1)
    //     0xd20c58: ldur            x3, [x1, #-1]
    //     0xd20c5c: ubfx            x3, x3, #0xc, #0x14
    // 0xd20c60: stp             x0, x1, [SP]
    // 0xd20c64: mov             x0, x3
    // 0xd20c68: mov             lr, x0
    // 0xd20c6c: ldr             lr, [x21, lr, lsl #3]
    // 0xd20c70: blr             lr
    // 0xd20c74: tbnz            w0, #4, #0xd20c88
    // 0xd20c78: r0 = Null
    //     0xd20c78: mov             x0, NULL
    // 0xd20c7c: LeaveFrame
    //     0xd20c7c: mov             SP, fp
    //     0xd20c80: ldp             fp, lr, [SP], #0x10
    // 0xd20c84: ret
    //     0xd20c84: ret             
    // 0xd20c88: ldur            x1, [fp, #-8]
    // 0xd20c8c: ldur            x0, [fp, #-0x10]
    // 0xd20c90: StoreField: r1->field_13 = r0
    //     0xd20c90: stur            w0, [x1, #0x13]
    //     0xd20c94: ldurb           w16, [x1, #-1]
    //     0xd20c98: ldurb           w17, [x0, #-1]
    //     0xd20c9c: and             x16, x17, x16, lsr #2
    //     0xd20ca0: tst             x16, HEAP, lsr #32
    //     0xd20ca4: b.eq            #0xd20cac
    //     0xd20ca8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd20cac: LoadField: r0 = r1->field_7
    //     0xd20cac: ldur            w0, [x1, #7]
    // 0xd20cb0: DecompressPointer r0
    //     0xd20cb0: add             x0, x0, HEAP, lsl #32
    // 0xd20cb4: mov             x1, x0
    // 0xd20cb8: r0 = markNeedsPaint()
    //     0xd20cb8: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xd20cbc: r0 = Null
    //     0xd20cbc: mov             x0, NULL
    // 0xd20cc0: LeaveFrame
    //     0xd20cc0: mov             SP, fp
    //     0xd20cc4: ldp             fp, lr, [SP], #0x10
    // 0xd20cc8: ret
    //     0xd20cc8: ret             
    // 0xd20ccc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd20ccc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd20cd0: b               #0xd20c50
  }
  set _ customBorder=(/* No info */) {
    // ** addr: 0xf39194, size: 0xb0
    // 0xf39194: EnterFrame
    //     0xf39194: stp             fp, lr, [SP, #-0x10]!
    //     0xf39198: mov             fp, SP
    // 0xf3919c: AllocStack(0x20)
    //     0xf3919c: sub             SP, SP, #0x20
    // 0xf391a0: SetupParameters(InteractiveInkFeature this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xf391a0: stur            x1, [fp, #-8]
    //     0xf391a4: mov             x16, x2
    //     0xf391a8: mov             x2, x1
    //     0xf391ac: mov             x1, x16
    //     0xf391b0: stur            x1, [fp, #-0x10]
    // 0xf391b4: CheckStackOverflow
    //     0xf391b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf391b8: cmp             SP, x16
    //     0xf391bc: b.ls            #0xf3923c
    // 0xf391c0: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xf391c0: ldur            w0, [x2, #0x17]
    // 0xf391c4: DecompressPointer r0
    //     0xf391c4: add             x0, x0, HEAP, lsl #32
    // 0xf391c8: r3 = LoadClassIdInstr(r1)
    //     0xf391c8: ldur            x3, [x1, #-1]
    //     0xf391cc: ubfx            x3, x3, #0xc, #0x14
    // 0xf391d0: stp             x0, x1, [SP]
    // 0xf391d4: mov             x0, x3
    // 0xf391d8: mov             lr, x0
    // 0xf391dc: ldr             lr, [x21, lr, lsl #3]
    // 0xf391e0: blr             lr
    // 0xf391e4: tbnz            w0, #4, #0xf391f8
    // 0xf391e8: r0 = Null
    //     0xf391e8: mov             x0, NULL
    // 0xf391ec: LeaveFrame
    //     0xf391ec: mov             SP, fp
    //     0xf391f0: ldp             fp, lr, [SP], #0x10
    // 0xf391f4: ret
    //     0xf391f4: ret             
    // 0xf391f8: ldur            x1, [fp, #-8]
    // 0xf391fc: ldur            x0, [fp, #-0x10]
    // 0xf39200: ArrayStore: r1[0] = r0  ; List_4
    //     0xf39200: stur            w0, [x1, #0x17]
    //     0xf39204: ldurb           w16, [x1, #-1]
    //     0xf39208: ldurb           w17, [x0, #-1]
    //     0xf3920c: and             x16, x17, x16, lsr #2
    //     0xf39210: tst             x16, HEAP, lsr #32
    //     0xf39214: b.eq            #0xf3921c
    //     0xf39218: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf3921c: LoadField: r0 = r1->field_7
    //     0xf3921c: ldur            w0, [x1, #7]
    // 0xf39220: DecompressPointer r0
    //     0xf39220: add             x0, x0, HEAP, lsl #32
    // 0xf39224: mov             x1, x0
    // 0xf39228: r0 = markNeedsPaint()
    //     0xf39228: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xf3922c: r0 = Null
    //     0xf3922c: mov             x0, NULL
    // 0xf39230: LeaveFrame
    //     0xf39230: mov             SP, fp
    //     0xf39234: ldp             fp, lr, [SP], #0x10
    // 0xf39238: ret
    //     0xf39238: ret             
    // 0xf3923c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3923c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf39240: b               #0xf391c0
  }
  _ paintInkCircle(/* No info */) {
    // ** addr: 0x12dac04, size: 0x460
    // 0x12dac04: EnterFrame
    //     0x12dac04: stp             fp, lr, [SP, #-0x10]!
    //     0x12dac08: mov             fp, SP
    // 0x12dac0c: AllocStack(0x70)
    //     0x12dac0c: sub             SP, SP, #0x70
    // 0x12dac10: SetupParameters(dynamic _ /* r2 => r5, fp-0x8 */, dynamic _ /* r3 => r4, fp-0x10 */, dynamic _ /* r5 => r3, fp-0x18 */, dynamic _ /* r6 => r2, fp-0x20 */, dynamic _ /* r7 => r0, fp-0x28 */, dynamic _ /* d0 => d0, fp-0x50 */)
    //     0x12dac10: mov             x4, x3
    //     0x12dac14: stur            x3, [fp, #-0x10]
    //     0x12dac18: mov             x3, x5
    //     0x12dac1c: stur            x5, [fp, #-0x18]
    //     0x12dac20: mov             x5, x2
    //     0x12dac24: stur            x2, [fp, #-8]
    //     0x12dac28: mov             x2, x6
    //     0x12dac2c: mov             x0, x7
    //     0x12dac30: stur            x6, [fp, #-0x20]
    //     0x12dac34: stur            x7, [fp, #-0x28]
    //     0x12dac38: stur            d0, [fp, #-0x50]
    // 0x12dac3c: CheckStackOverflow
    //     0x12dac3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12dac40: cmp             SP, x16
    //     0x12dac44: b.ls            #0x12db044
    // 0x12dac48: ldr             x1, [fp, #0x10]
    // 0x12dac4c: r0 = getAsTranslation()
    //     0x12dac4c: bl              #0xc155c4  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::getAsTranslation
    // 0x12dac50: mov             x2, x0
    // 0x12dac54: ldur            x0, [fp, #-0x10]
    // 0x12dac58: stur            x2, [fp, #-0x38]
    // 0x12dac5c: LoadField: r1 = r0->field_7
    //     0x12dac5c: ldur            w1, [x0, #7]
    // 0x12dac60: DecompressPointer r1
    //     0x12dac60: add             x1, x1, HEAP, lsl #32
    // 0x12dac64: cmp             w1, NULL
    // 0x12dac68: b.eq            #0x12db04c
    // 0x12dac6c: LoadField: r3 = r1->field_7
    //     0x12dac6c: ldur            x3, [x1, #7]
    // 0x12dac70: ldr             x1, [x3]
    // 0x12dac74: cbz             x1, #0x12daff4
    // 0x12dac78: mov             x3, x1
    // 0x12dac7c: stur            x3, [fp, #-0x30]
    // 0x12dac80: r1 = <Never>
    //     0x12dac80: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12dac84: r0 = Pointer()
    //     0x12dac84: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12dac88: mov             x1, x0
    // 0x12dac8c: ldur            x0, [fp, #-0x30]
    // 0x12dac90: StoreField: r1->field_7 = r0
    //     0x12dac90: stur            x0, [x1, #7]
    // 0x12dac94: r0 = _save$Method$FfiNative()
    //     0x12dac94: bl              #0xb74adc  ; [dart:ui] _NativeCanvas::_save$Method$FfiNative
    // 0x12dac98: ldur            x0, [fp, #-0x38]
    // 0x12dac9c: cmp             w0, NULL
    // 0x12daca0: b.ne            #0x12dacbc
    // 0x12daca4: ldr             x0, [fp, #0x10]
    // 0x12daca8: LoadField: r2 = r0->field_7
    //     0x12daca8: ldur            w2, [x0, #7]
    // 0x12dacac: DecompressPointer r2
    //     0x12dacac: add             x2, x2, HEAP, lsl #32
    // 0x12dacb0: ldur            x1, [fp, #-0x10]
    // 0x12dacb4: r0 = transform()
    //     0x12dacb4: bl              #0xb755c4  ; [dart:ui] _NativeCanvas::transform
    // 0x12dacb8: b               #0x12dad10
    // 0x12dacbc: ldur            x2, [fp, #-0x10]
    // 0x12dacc0: LoadField: d0 = r0->field_7
    //     0x12dacc0: ldur            d0, [x0, #7]
    // 0x12dacc4: stur            d0, [fp, #-0x60]
    // 0x12dacc8: LoadField: d1 = r0->field_f
    //     0x12dacc8: ldur            d1, [x0, #0xf]
    // 0x12daccc: stur            d1, [fp, #-0x58]
    // 0x12dacd0: LoadField: r0 = r2->field_7
    //     0x12dacd0: ldur            w0, [x2, #7]
    // 0x12dacd4: DecompressPointer r0
    //     0x12dacd4: add             x0, x0, HEAP, lsl #32
    // 0x12dacd8: cmp             w0, NULL
    // 0x12dacdc: b.eq            #0x12db050
    // 0x12dace0: LoadField: r1 = r0->field_7
    //     0x12dace0: ldur            x1, [x0, #7]
    // 0x12dace4: ldr             x0, [x1]
    // 0x12dace8: cbz             x0, #0x12db004
    // 0x12dacec: stur            x0, [fp, #-0x30]
    // 0x12dacf0: r1 = <Never>
    //     0x12dacf0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12dacf4: r0 = Pointer()
    //     0x12dacf4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12dacf8: mov             x1, x0
    // 0x12dacfc: ldur            x0, [fp, #-0x30]
    // 0x12dad00: StoreField: r1->field_7 = r0
    //     0x12dad00: stur            x0, [x1, #7]
    // 0x12dad04: ldur            d0, [fp, #-0x60]
    // 0x12dad08: ldur            d1, [fp, #-0x58]
    // 0x12dad0c: r0 = _translate$Method$FfiNative()
    //     0x12dad0c: bl              #0xb74a38  ; [dart:ui] _NativeCanvas::_translate$Method$FfiNative
    // 0x12dad10: ldur            x0, [fp, #-0x20]
    // 0x12dad14: cmp             w0, NULL
    // 0x12dad18: b.eq            #0x12daf8c
    // 0x12dad1c: ldur            x1, [fp, #-0x28]
    // 0x12dad20: str             x0, [SP]
    // 0x12dad24: ClosureCall
    //     0x12dad24: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x12dad28: ldur            x2, [x0, #0x1f]
    //     0x12dad2c: blr             x2
    // 0x12dad30: ldur            x1, [fp, #-0x28]
    // 0x12dad34: stur            x0, [fp, #-0x38]
    // 0x12dad38: cmp             w1, NULL
    // 0x12dad3c: b.eq            #0x12dae08
    // 0x12dad40: ldur            x3, [fp, #-0x10]
    // 0x12dad44: r2 = LoadClassIdInstr(r1)
    //     0x12dad44: ldur            x2, [x1, #-1]
    //     0x12dad48: ubfx            x2, x2, #0xc, #0x14
    // 0x12dad4c: ldr             x16, [fp, #0x18]
    // 0x12dad50: str             x16, [SP]
    // 0x12dad54: mov             x16, x0
    // 0x12dad58: mov             x0, x2
    // 0x12dad5c: mov             x2, x16
    // 0x12dad60: r4 = const [0, 0x3, 0x1, 0x2, textDirection, 0x2, null]
    //     0x12dad60: add             x4, PP, #0x97, lsl #12  ; [pp+0x97638] List(7) [0, 0x3, 0x1, 0x2, "textDirection", 0x2, Null]
    //     0x12dad64: ldr             x4, [x4, #0x638]
    // 0x12dad68: r0 = GDT[cid_x0 + -0xfc1]()
    //     0x12dad68: sub             lr, x0, #0xfc1
    //     0x12dad6c: ldr             lr, [x21, lr, lsl #3]
    //     0x12dad70: blr             lr
    // 0x12dad74: mov             x2, x0
    // 0x12dad78: ldur            x0, [fp, #-0x10]
    // 0x12dad7c: stur            x2, [fp, #-0x20]
    // 0x12dad80: LoadField: r1 = r0->field_7
    //     0x12dad80: ldur            w1, [x0, #7]
    // 0x12dad84: DecompressPointer r1
    //     0x12dad84: add             x1, x1, HEAP, lsl #32
    // 0x12dad88: cmp             w1, NULL
    // 0x12dad8c: b.eq            #0x12db054
    // 0x12dad90: LoadField: r3 = r1->field_7
    //     0x12dad90: ldur            x3, [x1, #7]
    // 0x12dad94: ldr             x1, [x3]
    // 0x12dad98: cbz             x1, #0x12db014
    // 0x12dad9c: mov             x3, x1
    // 0x12dada0: stur            x3, [fp, #-0x30]
    // 0x12dada4: r1 = <Never>
    //     0x12dada4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12dada8: r0 = Pointer()
    //     0x12dada8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12dadac: mov             x2, x0
    // 0x12dadb0: ldur            x0, [fp, #-0x30]
    // 0x12dadb4: stur            x2, [fp, #-0x28]
    // 0x12dadb8: StoreField: r2->field_7 = r0
    //     0x12dadb8: stur            x0, [x2, #7]
    // 0x12dadbc: ldur            x0, [fp, #-0x20]
    // 0x12dadc0: LoadField: r1 = r0->field_7
    //     0x12dadc0: ldur            w1, [x0, #7]
    // 0x12dadc4: DecompressPointer r1
    //     0x12dadc4: add             x1, x1, HEAP, lsl #32
    // 0x12dadc8: cmp             w1, NULL
    // 0x12dadcc: b.eq            #0x12db058
    // 0x12dadd0: LoadField: r3 = r1->field_7
    //     0x12dadd0: ldur            x3, [x1, #7]
    // 0x12dadd4: ldr             x1, [x3]
    // 0x12dadd8: mov             x3, x1
    // 0x12daddc: stur            x3, [fp, #-0x30]
    // 0x12dade0: r1 = <Never>
    //     0x12dade0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12dade4: r0 = Pointer()
    //     0x12dade4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12dade8: mov             x1, x0
    // 0x12dadec: ldur            x0, [fp, #-0x30]
    // 0x12dadf0: StoreField: r1->field_7 = r0
    //     0x12dadf0: stur            x0, [x1, #7]
    // 0x12dadf4: mov             x2, x1
    // 0x12dadf8: ldur            x1, [fp, #-0x28]
    // 0x12dadfc: r3 = true
    //     0x12dadfc: add             x3, NULL, #0x20  ; true
    // 0x12dae00: r0 = __clipPath$Method$FfiNative()
    //     0x12dae00: bl              #0xc1ac40  ; [dart:ui] _NativeCanvas::__clipPath$Method$FfiNative
    // 0x12dae04: b               #0x12daf8c
    // 0x12dae08: ldur            x16, [fp, #-8]
    // 0x12dae0c: r30 = Instance_BorderRadius
    //     0x12dae0c: add             lr, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0x12dae10: ldr             lr, [lr, #0x508]
    // 0x12dae14: stp             lr, x16, [SP]
    // 0x12dae18: r0 = ==()
    //     0x12dae18: bl              #0x1298058  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x12dae1c: tbz             w0, #4, #0x12daf7c
    // 0x12dae20: ldur            x1, [fp, #-8]
    // 0x12dae24: ldur            x0, [fp, #-0x10]
    // 0x12dae28: LoadField: r6 = r1->field_7
    //     0x12dae28: ldur            w6, [x1, #7]
    // 0x12dae2c: DecompressPointer r6
    //     0x12dae2c: add             x6, x6, HEAP, lsl #32
    // 0x12dae30: stur            x6, [fp, #-0x48]
    // 0x12dae34: LoadField: r7 = r1->field_b
    //     0x12dae34: ldur            w7, [x1, #0xb]
    // 0x12dae38: DecompressPointer r7
    //     0x12dae38: add             x7, x7, HEAP, lsl #32
    // 0x12dae3c: stur            x7, [fp, #-0x40]
    // 0x12dae40: LoadField: r3 = r1->field_f
    //     0x12dae40: ldur            w3, [x1, #0xf]
    // 0x12dae44: DecompressPointer r3
    //     0x12dae44: add             x3, x3, HEAP, lsl #32
    // 0x12dae48: stur            x3, [fp, #-0x28]
    // 0x12dae4c: LoadField: r5 = r1->field_13
    //     0x12dae4c: ldur            w5, [x1, #0x13]
    // 0x12dae50: DecompressPointer r5
    //     0x12dae50: add             x5, x5, HEAP, lsl #32
    // 0x12dae54: stur            x5, [fp, #-0x20]
    // 0x12dae58: r1 = <RRect>
    //     0x12dae58: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0x12dae5c: ldr             x1, [x1, #0x108]
    // 0x12dae60: r0 = RRect()
    //     0x12dae60: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0x12dae64: mov             x1, x0
    // 0x12dae68: ldur            x2, [fp, #-0x38]
    // 0x12dae6c: ldur            x3, [fp, #-0x28]
    // 0x12dae70: ldur            x5, [fp, #-0x20]
    // 0x12dae74: ldur            x6, [fp, #-0x48]
    // 0x12dae78: ldur            x7, [fp, #-0x40]
    // 0x12dae7c: stur            x0, [fp, #-8]
    // 0x12dae80: r0 = RSuperellipse.fromRectAndCorners()
    //     0x12dae80: bl              #0xb77b20  ; [dart:ui] RSuperellipse::RSuperellipse.fromRectAndCorners
    // 0x12dae84: ldur            x0, [fp, #-8]
    // 0x12dae88: LoadField: d0 = r0->field_b
    //     0x12dae88: ldur            d0, [x0, #0xb]
    // 0x12dae8c: fcvt            s1, d0
    // 0x12dae90: stur            d1, [fp, #-0x58]
    // 0x12dae94: r4 = 24
    //     0x12dae94: mov             x4, #0x18
    // 0x12dae98: r0 = AllocateFloat32Array()
    //     0x12dae98: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0x12dae9c: ldur            d0, [fp, #-0x58]
    // 0x12daea0: stur            x0, [fp, #-0x20]
    // 0x12daea4: ArrayStore: r0[0] = d0  ; List_8
    //     0x12daea4: stur            s0, [x0, #0x17]
    // 0x12daea8: ldur            x1, [fp, #-8]
    // 0x12daeac: LoadField: d0 = r1->field_13
    //     0x12daeac: ldur            d0, [x1, #0x13]
    // 0x12daeb0: fcvt            s1, d0
    // 0x12daeb4: StoreField: r0->field_1b = d1
    //     0x12daeb4: stur            s1, [x0, #0x1b]
    // 0x12daeb8: LoadField: d0 = r1->field_1b
    //     0x12daeb8: ldur            d0, [x1, #0x1b]
    // 0x12daebc: fcvt            s1, d0
    // 0x12daec0: StoreField: r0->field_1f = d1
    //     0x12daec0: stur            s1, [x0, #0x1f]
    // 0x12daec4: LoadField: d0 = r1->field_23
    //     0x12daec4: ldur            d0, [x1, #0x23]
    // 0x12daec8: fcvt            s1, d0
    // 0x12daecc: StoreField: r0->field_23 = d1
    //     0x12daecc: stur            s1, [x0, #0x23]
    // 0x12daed0: LoadField: d0 = r1->field_2b
    //     0x12daed0: ldur            d0, [x1, #0x2b]
    // 0x12daed4: fcvt            s1, d0
    // 0x12daed8: StoreField: r0->field_27 = d1
    //     0x12daed8: stur            s1, [x0, #0x27]
    // 0x12daedc: LoadField: d0 = r1->field_33
    //     0x12daedc: ldur            d0, [x1, #0x33]
    // 0x12daee0: fcvt            s1, d0
    // 0x12daee4: StoreField: r0->field_2b = d1
    //     0x12daee4: stur            s1, [x0, #0x2b]
    // 0x12daee8: LoadField: d0 = r1->field_3b
    //     0x12daee8: ldur            d0, [x1, #0x3b]
    // 0x12daeec: fcvt            s1, d0
    // 0x12daef0: StoreField: r0->field_2f = d1
    //     0x12daef0: stur            s1, [x0, #0x2f]
    // 0x12daef4: LoadField: d0 = r1->field_43
    //     0x12daef4: ldur            d0, [x1, #0x43]
    // 0x12daef8: fcvt            s1, d0
    // 0x12daefc: StoreField: r0->field_33 = d1
    //     0x12daefc: stur            s1, [x0, #0x33]
    // 0x12daf00: LoadField: d0 = r1->field_4b
    //     0x12daf00: ldur            d0, [x1, #0x4b]
    // 0x12daf04: fcvt            s1, d0
    // 0x12daf08: StoreField: r0->field_37 = d1
    //     0x12daf08: stur            s1, [x0, #0x37]
    // 0x12daf0c: LoadField: d0 = r1->field_53
    //     0x12daf0c: ldur            d0, [x1, #0x53]
    // 0x12daf10: fcvt            s1, d0
    // 0x12daf14: StoreField: r0->field_3b = d1
    //     0x12daf14: stur            s1, [x0, #0x3b]
    // 0x12daf18: LoadField: d0 = r1->field_5b
    //     0x12daf18: ldur            d0, [x1, #0x5b]
    // 0x12daf1c: fcvt            s1, d0
    // 0x12daf20: StoreField: r0->field_3f = d1
    //     0x12daf20: stur            s1, [x0, #0x3f]
    // 0x12daf24: LoadField: d0 = r1->field_63
    //     0x12daf24: ldur            d0, [x1, #0x63]
    // 0x12daf28: fcvt            s1, d0
    // 0x12daf2c: StoreField: r0->field_43 = d1
    //     0x12daf2c: stur            s1, [x0, #0x43]
    // 0x12daf30: ldur            x2, [fp, #-0x10]
    // 0x12daf34: LoadField: r1 = r2->field_7
    //     0x12daf34: ldur            w1, [x2, #7]
    // 0x12daf38: DecompressPointer r1
    //     0x12daf38: add             x1, x1, HEAP, lsl #32
    // 0x12daf3c: cmp             w1, NULL
    // 0x12daf40: b.eq            #0x12db05c
    // 0x12daf44: LoadField: r3 = r1->field_7
    //     0x12daf44: ldur            x3, [x1, #7]
    // 0x12daf48: ldr             x1, [x3]
    // 0x12daf4c: cbz             x1, #0x12db024
    // 0x12daf50: mov             x3, x1
    // 0x12daf54: stur            x3, [fp, #-0x30]
    // 0x12daf58: r1 = <Never>
    //     0x12daf58: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12daf5c: r0 = Pointer()
    //     0x12daf5c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12daf60: mov             x1, x0
    // 0x12daf64: ldur            x0, [fp, #-0x30]
    // 0x12daf68: StoreField: r1->field_7 = r0
    //     0x12daf68: stur            x0, [x1, #7]
    // 0x12daf6c: ldur            x2, [fp, #-0x20]
    // 0x12daf70: r3 = true
    //     0x12daf70: add             x3, NULL, #0x20  ; true
    // 0x12daf74: r0 = __clipRRect$Method$FfiNative()
    //     0x12daf74: bl              #0xb6e74c  ; [dart:ui] _NativeCanvas::__clipRRect$Method$FfiNative
    // 0x12daf78: b               #0x12daf8c
    // 0x12daf7c: ldur            x1, [fp, #-0x10]
    // 0x12daf80: ldur            x2, [fp, #-0x38]
    // 0x12daf84: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x12daf84: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x12daf88: r0 = clipRect()
    //     0x12daf88: bl              #0xb7b380  ; [dart:ui] _NativeCanvas::clipRect
    // 0x12daf8c: ldur            x0, [fp, #-0x10]
    // 0x12daf90: mov             x1, x0
    // 0x12daf94: ldur            x2, [fp, #-0x18]
    // 0x12daf98: ldur            d0, [fp, #-0x50]
    // 0x12daf9c: ldr             x3, [fp, #0x20]
    // 0x12dafa0: r0 = drawCircle()
    //     0x12dafa0: bl              #0xb6acd4  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x12dafa4: ldur            x0, [fp, #-0x10]
    // 0x12dafa8: LoadField: r1 = r0->field_7
    //     0x12dafa8: ldur            w1, [x0, #7]
    // 0x12dafac: DecompressPointer r1
    //     0x12dafac: add             x1, x1, HEAP, lsl #32
    // 0x12dafb0: cmp             w1, NULL
    // 0x12dafb4: b.eq            #0x12db060
    // 0x12dafb8: LoadField: r2 = r1->field_7
    //     0x12dafb8: ldur            x2, [x1, #7]
    // 0x12dafbc: ldr             x1, [x2]
    // 0x12dafc0: cbz             x1, #0x12db034
    // 0x12dafc4: mov             x2, x1
    // 0x12dafc8: stur            x2, [fp, #-0x30]
    // 0x12dafcc: r1 = <Never>
    //     0x12dafcc: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12dafd0: r0 = Pointer()
    //     0x12dafd0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12dafd4: mov             x1, x0
    // 0x12dafd8: ldur            x0, [fp, #-0x30]
    // 0x12dafdc: StoreField: r1->field_7 = r0
    //     0x12dafdc: stur            x0, [x1, #7]
    // 0x12dafe0: r0 = _restore$Method$FfiNative()
    //     0x12dafe0: bl              #0xb74908  ; [dart:ui] _NativeCanvas::_restore$Method$FfiNative
    // 0x12dafe4: r0 = Null
    //     0x12dafe4: mov             x0, NULL
    // 0x12dafe8: LeaveFrame
    //     0x12dafe8: mov             SP, fp
    //     0x12dafec: ldp             fp, lr, [SP], #0x10
    // 0x12daff0: ret
    //     0x12daff0: ret             
    // 0x12daff4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12daff4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12daff8: str             x16, [SP]
    // 0x12daffc: r0 = _throwNew()
    //     0x12daffc: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12db000: brk             #0
    // 0x12db004: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12db004: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12db008: str             x16, [SP]
    // 0x12db00c: r0 = _throwNew()
    //     0x12db00c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12db010: brk             #0
    // 0x12db014: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12db014: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12db018: str             x16, [SP]
    // 0x12db01c: r0 = _throwNew()
    //     0x12db01c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12db020: brk             #0
    // 0x12db024: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12db024: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12db028: str             x16, [SP]
    // 0x12db02c: r0 = _throwNew()
    //     0x12db02c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12db030: brk             #0
    // 0x12db034: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12db034: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12db038: str             x16, [SP]
    // 0x12db03c: r0 = _throwNew()
    //     0x12db03c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12db040: brk             #0
    // 0x12db044: r0 = StackOverflowSharedWithFPURegs()
    //     0x12db044: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12db048: b               #0x12dac48
    // 0x12db04c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12db04c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12db050: r0 = NullErrorSharedWithFPURegs()
    //     0x12db050: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12db054: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12db054: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12db058: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12db058: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12db05c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12db05c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12db060: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12db060: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 5754, size: 0x3c, field offset: 0x18
class _InkResponseState extends _MixinApplication70&State&AutomaticKeepAliveClientMixin
    implements _ParentInkResponseState {

  late final Map<Type, Action<Intent>> _actionMap; // offset: 0x28

  _ build(/* No info */) {
    // ** addr: 0xd1ffa4, size: 0x84c
    // 0xd1ffa4: EnterFrame
    //     0xd1ffa4: stp             fp, lr, [SP, #-0x10]!
    //     0xd1ffa8: mov             fp, SP
    // 0xd1ffac: AllocStack(0xb0)
    //     0xd1ffac: sub             SP, SP, #0xb0
    // 0xd1ffb0: SetupParameters(_InkResponseState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd1ffb0: stur            x1, [fp, #-8]
    //     0xd1ffb4: stur            x2, [fp, #-0x10]
    // 0xd1ffb8: CheckStackOverflow
    //     0xd1ffb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1ffbc: cmp             SP, x16
    //     0xd1ffc0: b.ls            #0xd207b8
    // 0xd1ffc4: r1 = 5
    //     0xd1ffc4: mov             x1, #5
    // 0xd1ffc8: r0 = AllocateContext()
    //     0xd1ffc8: bl              #0x13de838  ; AllocateContextStub
    // 0xd1ffcc: mov             x3, x0
    // 0xd1ffd0: ldur            x0, [fp, #-8]
    // 0xd1ffd4: stur            x3, [fp, #-0x18]
    // 0xd1ffd8: StoreField: r3->field_f = r0
    //     0xd1ffd8: stur            w0, [x3, #0xf]
    // 0xd1ffdc: mov             x1, x0
    // 0xd1ffe0: ldur            x2, [fp, #-0x10]
    // 0xd1ffe4: r0 = build()
    //     0xd1ffe4: bl              #0xd20cd4  ; [dart:mixin_deduplication] _MixinApplication70&State&AutomaticKeepAliveClientMixin::build
    // 0xd1ffe8: ldur            x1, [fp, #-0x10]
    // 0xd1ffec: r0 = of()
    //     0xd1ffec: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd1fff0: ldur            x3, [fp, #-0x18]
    // 0xd1fff4: StoreField: r3->field_13 = r0
    //     0xd1fff4: stur            w0, [x3, #0x13]
    //     0xd1fff8: ldurb           w16, [x3, #-1]
    //     0xd1fffc: ldurb           w17, [x0, #-1]
    //     0xd20000: and             x16, x17, x16, lsr #2
    //     0xd20004: tst             x16, HEAP, lsr #32
    //     0xd20008: b.eq            #0xd20010
    //     0xd2000c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd20010: ldur            x4, [fp, #-8]
    // 0xd20014: LoadField: r0 = r4->field_b
    //     0xd20014: ldur            w0, [x4, #0xb]
    // 0xd20018: DecompressPointer r0
    //     0xd20018: add             x0, x0, HEAP, lsl #32
    // 0xd2001c: cmp             w0, NULL
    // 0xd20020: b.eq            #0xd207c0
    // 0xd20024: LoadField: r1 = r0->field_8f
    //     0xd20024: ldur            w1, [x0, #0x8f]
    // 0xd20028: DecompressPointer r1
    //     0xd20028: add             x1, x1, HEAP, lsl #32
    // 0xd2002c: cmp             w1, NULL
    // 0xd20030: b.ne            #0xd20048
    // 0xd20034: LoadField: r0 = r4->field_2b
    //     0xd20034: ldur            w0, [x4, #0x2b]
    // 0xd20038: DecompressPointer r0
    //     0xd20038: add             x0, x0, HEAP, lsl #32
    // 0xd2003c: cmp             w0, NULL
    // 0xd20040: b.eq            #0xd207c4
    // 0xd20044: b               #0xd2004c
    // 0xd20048: mov             x0, x1
    // 0xd2004c: LoadField: r1 = r0->field_27
    //     0xd2004c: ldur            w1, [x0, #0x27]
    // 0xd20050: DecompressPointer r1
    //     0xd20050: add             x1, x1, HEAP, lsl #32
    // 0xd20054: r0 = LoadClassIdInstr(r1)
    //     0xd20054: ldur            x0, [x1, #-1]
    //     0xd20058: ubfx            x0, x0, #0xc, #0x14
    // 0xd2005c: r2 = _ConstSet len:3
    //     0xd2005c: add             x2, PP, #0x99, lsl #12  ; [pp+0x99450] Set<WidgetState>(3)
    //     0xd20060: ldr             x2, [x2, #0x450]
    // 0xd20064: r0 = GDT[cid_x0 + 0x834a]()
    //     0xd20064: mov             x17, #0x834a
    //     0xd20068: add             lr, x0, x17
    //     0xd2006c: ldr             lr, [x21, lr, lsl #3]
    //     0xd20070: blr             lr
    // 0xd20074: mov             x2, x0
    // 0xd20078: r1 = <WidgetState>
    //     0xd20078: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a10] TypeArguments: <WidgetState>
    //     0xd2007c: ldr             x1, [x1, #0xa10]
    // 0xd20080: stur            x0, [fp, #-0x20]
    // 0xd20084: r0 = LinkedHashSet.of()
    //     0xd20084: bl              #0x83a460  ; [dart:collection] LinkedHashSet::LinkedHashSet.of
    // 0xd20088: mov             x1, x0
    // 0xd2008c: r2 = Instance_WidgetState
    //     0xd2008c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd20090: ldr             x2, [x2, #0xa48]
    // 0xd20094: stur            x0, [fp, #-0x28]
    // 0xd20098: r0 = add()
    //     0xd20098: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xd2009c: ldur            x0, [fp, #-0x28]
    // 0xd200a0: ldur            x3, [fp, #-0x18]
    // 0xd200a4: ArrayStore: r3[0] = r0  ; List_4
    //     0xd200a4: stur            w0, [x3, #0x17]
    //     0xd200a8: ldurb           w16, [x3, #-1]
    //     0xd200ac: ldurb           w17, [x0, #-1]
    //     0xd200b0: and             x16, x17, x16, lsr #2
    //     0xd200b4: tst             x16, HEAP, lsr #32
    //     0xd200b8: b.eq            #0xd200c0
    //     0xd200bc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd200c0: ldur            x2, [fp, #-0x20]
    // 0xd200c4: r1 = <WidgetState>
    //     0xd200c4: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a10] TypeArguments: <WidgetState>
    //     0xd200c8: ldr             x1, [x1, #0xa10]
    // 0xd200cc: r0 = LinkedHashSet.of()
    //     0xd200cc: bl              #0x83a460  ; [dart:collection] LinkedHashSet::LinkedHashSet.of
    // 0xd200d0: mov             x1, x0
    // 0xd200d4: r2 = Instance_WidgetState
    //     0xd200d4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd200d8: ldr             x2, [x2, #0xa60]
    // 0xd200dc: stur            x0, [fp, #-0x28]
    // 0xd200e0: r0 = add()
    //     0xd200e0: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xd200e4: ldur            x0, [fp, #-0x28]
    // 0xd200e8: ldur            x3, [fp, #-0x18]
    // 0xd200ec: StoreField: r3->field_1b = r0
    //     0xd200ec: stur            w0, [x3, #0x1b]
    //     0xd200f0: ldurb           w16, [x3, #-1]
    //     0xd200f4: ldurb           w17, [x0, #-1]
    //     0xd200f8: and             x16, x17, x16, lsr #2
    //     0xd200fc: tst             x16, HEAP, lsr #32
    //     0xd20100: b.eq            #0xd20108
    //     0xd20104: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd20108: ldur            x2, [fp, #-0x20]
    // 0xd2010c: r1 = <WidgetState>
    //     0xd2010c: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a10] TypeArguments: <WidgetState>
    //     0xd20110: ldr             x1, [x1, #0xa10]
    // 0xd20114: r0 = LinkedHashSet.of()
    //     0xd20114: bl              #0x83a460  ; [dart:collection] LinkedHashSet::LinkedHashSet.of
    // 0xd20118: mov             x1, x0
    // 0xd2011c: r2 = Instance_WidgetState
    //     0xd2011c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd20120: ldr             x2, [x2, #0xa50]
    // 0xd20124: stur            x0, [fp, #-0x20]
    // 0xd20128: r0 = add()
    //     0xd20128: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xd2012c: ldur            x0, [fp, #-0x20]
    // 0xd20130: ldur            x2, [fp, #-0x18]
    // 0xd20134: StoreField: r2->field_1f = r0
    //     0xd20134: stur            w0, [x2, #0x1f]
    //     0xd20138: ldurb           w16, [x2, #-1]
    //     0xd2013c: ldurb           w17, [x0, #-1]
    //     0xd20140: and             x16, x17, x16, lsr #2
    //     0xd20144: tst             x16, HEAP, lsr #32
    //     0xd20148: b.eq            #0xd20150
    //     0xd2014c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd20150: r1 = Function 'getHighlightColorForType':.
    //     0xd20150: add             x1, PP, #0x99, lsl #12  ; [pp+0x99458] AnonymousClosure: (0xd25f7c), in [package:flutter/src/material/ink_well.dart] _InkResponseState::build (0xd1ffa4)
    //     0xd20154: ldr             x1, [x1, #0x458]
    // 0xd20158: r0 = AllocateClosure()
    //     0xd20158: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd2015c: mov             x2, x0
    // 0xd20160: ldur            x0, [fp, #-8]
    // 0xd20164: stur            x2, [fp, #-0x20]
    // 0xd20168: LoadField: r3 = r0->field_23
    //     0xd20168: ldur            w3, [x0, #0x23]
    // 0xd2016c: DecompressPointer r3
    //     0xd2016c: add             x3, x3, HEAP, lsl #32
    // 0xd20170: stur            x3, [fp, #-0x18]
    // 0xd20174: r1 = <_HighlightType, InkHighlight?>
    //     0xd20174: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8fd38] TypeArguments: <_HighlightType, InkHighlight?>
    //     0xd20178: ldr             x1, [x1, #0xd38]
    // 0xd2017c: r0 = _CompactKeysIterable()
    //     0xd2017c: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0xd20180: mov             x1, x0
    // 0xd20184: ldur            x0, [fp, #-0x18]
    // 0xd20188: StoreField: r1->field_b = r0
    //     0xd20188: stur            w0, [x1, #0xb]
    // 0xd2018c: r0 = iterator()
    //     0xd2018c: bl              #0xb09a64  ; [dart:_compact_hash] _CompactKeysIterable::iterator
    // 0xd20190: stur            x0, [fp, #-0x30]
    // 0xd20194: LoadField: r2 = r0->field_7
    //     0xd20194: ldur            w2, [x0, #7]
    // 0xd20198: DecompressPointer r2
    //     0xd20198: add             x2, x2, HEAP, lsl #32
    // 0xd2019c: stur            x2, [fp, #-0x28]
    // 0xd201a0: ldur            x3, [fp, #-0x18]
    // 0xd201a4: CheckStackOverflow
    //     0xd201a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd201a8: cmp             SP, x16
    //     0xd201ac: b.ls            #0xd207c8
    // 0xd201b0: mov             x1, x0
    // 0xd201b4: r0 = moveNext()
    //     0xd201b4: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xd201b8: tbnz            w0, #4, #0xd202d0
    // 0xd201bc: ldur            x3, [fp, #-0x30]
    // 0xd201c0: LoadField: r4 = r3->field_33
    //     0xd201c0: ldur            w4, [x3, #0x33]
    // 0xd201c4: DecompressPointer r4
    //     0xd201c4: add             x4, x4, HEAP, lsl #32
    // 0xd201c8: stur            x4, [fp, #-0x38]
    // 0xd201cc: cmp             w4, NULL
    // 0xd201d0: b.ne            #0xd20204
    // 0xd201d4: mov             x0, x4
    // 0xd201d8: ldur            x2, [fp, #-0x28]
    // 0xd201dc: r1 = Null
    //     0xd201dc: mov             x1, NULL
    // 0xd201e0: cmp             w2, NULL
    // 0xd201e4: b.eq            #0xd20204
    // 0xd201e8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd201e8: ldur            w4, [x2, #0x17]
    // 0xd201ec: DecompressPointer r4
    //     0xd201ec: add             x4, x4, HEAP, lsl #32
    // 0xd201f0: r8 = X0
    //     0xd201f0: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd201f4: LoadField: r9 = r4->field_7
    //     0xd201f4: ldur            x9, [x4, #7]
    // 0xd201f8: r3 = Null
    //     0xd201f8: add             x3, PP, #0x99, lsl #12  ; [pp+0x99460] Null
    //     0xd201fc: ldr             x3, [x3, #0x460]
    // 0xd20200: blr             x9
    // 0xd20204: ldur            x0, [fp, #-0x18]
    // 0xd20208: mov             x1, x0
    // 0xd2020c: ldur            x2, [fp, #-0x38]
    // 0xd20210: r0 = _getValueOrData()
    //     0xd20210: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xd20214: ldur            x1, [fp, #-0x18]
    // 0xd20218: LoadField: r2 = r1->field_f
    //     0xd20218: ldur            w2, [x1, #0xf]
    // 0xd2021c: DecompressPointer r2
    //     0xd2021c: add             x2, x2, HEAP, lsl #32
    // 0xd20220: cmp             w2, w0
    // 0xd20224: b.ne            #0xd20230
    // 0xd20228: r2 = Null
    //     0xd20228: mov             x2, NULL
    // 0xd2022c: b               #0xd20234
    // 0xd20230: mov             x2, x0
    // 0xd20234: stur            x2, [fp, #-0x40]
    // 0xd20238: cmp             w2, NULL
    // 0xd2023c: b.eq            #0xd202c4
    // 0xd20240: ldur            x16, [fp, #-0x20]
    // 0xd20244: ldur            lr, [fp, #-0x38]
    // 0xd20248: stp             lr, x16, [SP]
    // 0xd2024c: ldur            x0, [fp, #-0x20]
    // 0xd20250: ClosureCall
    //     0xd20250: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd20254: ldur            x2, [x0, #0x1f]
    //     0xd20258: blr             x2
    // 0xd2025c: mov             x2, x0
    // 0xd20260: ldur            x1, [fp, #-0x40]
    // 0xd20264: stur            x2, [fp, #-0x38]
    // 0xd20268: LoadField: r0 = r1->field_13
    //     0xd20268: ldur            w0, [x1, #0x13]
    // 0xd2026c: DecompressPointer r0
    //     0xd2026c: add             x0, x0, HEAP, lsl #32
    // 0xd20270: r3 = LoadClassIdInstr(r2)
    //     0xd20270: ldur            x3, [x2, #-1]
    //     0xd20274: ubfx            x3, x3, #0xc, #0x14
    // 0xd20278: stp             x0, x2, [SP]
    // 0xd2027c: mov             x0, x3
    // 0xd20280: mov             lr, x0
    // 0xd20284: ldr             lr, [x21, lr, lsl #3]
    // 0xd20288: blr             lr
    // 0xd2028c: tbz             w0, #4, #0xd202c4
    // 0xd20290: ldur            x1, [fp, #-0x40]
    // 0xd20294: ldur            x0, [fp, #-0x38]
    // 0xd20298: StoreField: r1->field_13 = r0
    //     0xd20298: stur            w0, [x1, #0x13]
    //     0xd2029c: ldurb           w16, [x1, #-1]
    //     0xd202a0: ldurb           w17, [x0, #-1]
    //     0xd202a4: and             x16, x17, x16, lsr #2
    //     0xd202a8: tst             x16, HEAP, lsr #32
    //     0xd202ac: b.eq            #0xd202b4
    //     0xd202b0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd202b4: LoadField: r0 = r1->field_7
    //     0xd202b4: ldur            w0, [x1, #7]
    // 0xd202b8: DecompressPointer r0
    //     0xd202b8: add             x0, x0, HEAP, lsl #32
    // 0xd202bc: mov             x1, x0
    // 0xd202c0: r0 = markNeedsPaint()
    //     0xd202c0: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xd202c4: ldur            x0, [fp, #-0x30]
    // 0xd202c8: ldur            x2, [fp, #-0x28]
    // 0xd202cc: b               #0xd201a0
    // 0xd202d0: ldur            x3, [fp, #-8]
    // 0xd202d4: LoadField: r4 = r3->field_1b
    //     0xd202d4: ldur            w4, [x3, #0x1b]
    // 0xd202d8: DecompressPointer r4
    //     0xd202d8: add             x4, x4, HEAP, lsl #32
    // 0xd202dc: stur            x4, [fp, #-0x18]
    // 0xd202e0: cmp             w4, NULL
    // 0xd202e4: b.ne            #0xd202f0
    // 0xd202e8: mov             x0, x3
    // 0xd202ec: b               #0xd203c4
    // 0xd202f0: LoadField: r0 = r3->field_b
    //     0xd202f0: ldur            w0, [x3, #0xb]
    // 0xd202f4: DecompressPointer r0
    //     0xd202f4: add             x0, x0, HEAP, lsl #32
    // 0xd202f8: cmp             w0, NULL
    // 0xd202fc: b.eq            #0xd207d0
    // 0xd20300: LoadField: r1 = r0->field_63
    //     0xd20300: ldur            w1, [x0, #0x63]
    // 0xd20304: DecompressPointer r1
    //     0xd20304: add             x1, x1, HEAP, lsl #32
    // 0xd20308: cmp             w1, NULL
    // 0xd2030c: b.ne            #0xd20318
    // 0xd20310: r0 = Null
    //     0xd20310: mov             x0, NULL
    // 0xd20314: b               #0xd20364
    // 0xd20318: LoadField: r2 = r0->field_8f
    //     0xd20318: ldur            w2, [x0, #0x8f]
    // 0xd2031c: DecompressPointer r2
    //     0xd2031c: add             x2, x2, HEAP, lsl #32
    // 0xd20320: cmp             w2, NULL
    // 0xd20324: b.ne            #0xd2033c
    // 0xd20328: LoadField: r0 = r3->field_2b
    //     0xd20328: ldur            w0, [x3, #0x2b]
    // 0xd2032c: DecompressPointer r0
    //     0xd2032c: add             x0, x0, HEAP, lsl #32
    // 0xd20330: cmp             w0, NULL
    // 0xd20334: b.eq            #0xd207d4
    // 0xd20338: b               #0xd20340
    // 0xd2033c: mov             x0, x2
    // 0xd20340: LoadField: r2 = r0->field_27
    //     0xd20340: ldur            w2, [x0, #0x27]
    // 0xd20344: DecompressPointer r2
    //     0xd20344: add             x2, x2, HEAP, lsl #32
    // 0xd20348: r0 = LoadClassIdInstr(r1)
    //     0xd20348: ldur            x0, [x1, #-1]
    //     0xd2034c: ubfx            x0, x0, #0xc, #0x14
    // 0xd20350: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd20350: mov             x17, #0x7c77
    //     0xd20354: movk            x17, #1, lsl #16
    //     0xd20358: add             lr, x0, x17
    //     0xd2035c: ldr             lr, [x21, lr, lsl #3]
    //     0xd20360: blr             lr
    // 0xd20364: cmp             w0, NULL
    // 0xd20368: b.ne            #0xd20390
    // 0xd2036c: ldur            x2, [fp, #-8]
    // 0xd20370: LoadField: r0 = r2->field_b
    //     0xd20370: ldur            w0, [x2, #0xb]
    // 0xd20374: DecompressPointer r0
    //     0xd20374: add             x0, x0, HEAP, lsl #32
    // 0xd20378: cmp             w0, NULL
    // 0xd2037c: b.eq            #0xd207d8
    // 0xd20380: LoadField: r1 = r0->field_67
    //     0xd20380: ldur            w1, [x0, #0x67]
    // 0xd20384: DecompressPointer r1
    //     0xd20384: add             x1, x1, HEAP, lsl #32
    // 0xd20388: mov             x0, x1
    // 0xd2038c: b               #0xd20394
    // 0xd20390: ldur            x2, [fp, #-8]
    // 0xd20394: cmp             w0, NULL
    // 0xd20398: b.ne            #0xd203b4
    // 0xd2039c: ldur            x1, [fp, #-0x10]
    // 0xd203a0: r0 = of()
    //     0xd203a0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd203a4: LoadField: r1 = r0->field_73
    //     0xd203a4: ldur            w1, [x0, #0x73]
    // 0xd203a8: DecompressPointer r1
    //     0xd203a8: add             x1, x1, HEAP, lsl #32
    // 0xd203ac: mov             x2, x1
    // 0xd203b0: b               #0xd203b8
    // 0xd203b4: mov             x2, x0
    // 0xd203b8: ldur            x1, [fp, #-0x18]
    // 0xd203bc: r0 = color=()
    //     0xd203bc: bl              #0xd20c24  ; [package:flutter/src/material/ink_well.dart] InteractiveInkFeature::color=
    // 0xd203c0: ldur            x0, [fp, #-8]
    // 0xd203c4: LoadField: r1 = r0->field_b
    //     0xd203c4: ldur            w1, [x0, #0xb]
    // 0xd203c8: DecompressPointer r1
    //     0xd203c8: add             x1, x1, HEAP, lsl #32
    // 0xd203cc: cmp             w1, NULL
    // 0xd203d0: b.eq            #0xd207dc
    // 0xd203d4: LoadField: r2 = r1->field_3f
    //     0xd203d4: ldur            w2, [x1, #0x3f]
    // 0xd203d8: DecompressPointer r2
    //     0xd203d8: add             x2, x2, HEAP, lsl #32
    // 0xd203dc: cmp             w2, NULL
    // 0xd203e0: b.ne            #0xd203ec
    // 0xd203e4: r2 = Instance__WidgetStateMouseCursor
    //     0xd203e4: add             x2, PP, #0x80, lsl #12  ; [pp+0x80c18] Obj!_WidgetStateMouseCursor@12b3251
    //     0xd203e8: ldr             x2, [x2, #0xc18]
    // 0xd203ec: mov             x1, x0
    // 0xd203f0: stur            x2, [fp, #-0x10]
    // 0xd203f4: r0 = statesController()
    //     0xd203f4: bl              #0xd20bcc  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::statesController
    // 0xd203f8: LoadField: r1 = r0->field_27
    //     0xd203f8: ldur            w1, [x0, #0x27]
    // 0xd203fc: DecompressPointer r1
    //     0xd203fc: add             x1, x1, HEAP, lsl #32
    // 0xd20400: r16 = <MouseCursor>
    //     0xd20400: ldr             x16, [PP, #0x21a8]  ; [pp+0x21a8] TypeArguments: <MouseCursor>
    // 0xd20404: ldur            lr, [fp, #-0x10]
    // 0xd20408: stp             lr, x16, [SP, #8]
    // 0xd2040c: str             x1, [SP]
    // 0xd20410: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd20410: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd20414: r0 = resolveAs()
    //     0xd20414: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xd20418: ldur            x1, [fp, #-8]
    // 0xd2041c: stur            x0, [fp, #-0x10]
    // 0xd20420: LoadField: r0 = r1->field_27
    //     0xd20420: ldur            w0, [x1, #0x27]
    // 0xd20424: DecompressPointer r0
    //     0xd20424: add             x0, x0, HEAP, lsl #32
    // 0xd20428: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd2042c: cmp             w0, w16
    // 0xd20430: b.ne            #0xd20440
    // 0xd20434: r2 = _actionMap
    //     0xd20434: add             x2, PP, #0x99, lsl #12  ; [pp+0x99470] Field <_InkResponseState@93059085._actionMap@93059085>: late final (offset: 0x28)
    //     0xd20438: ldr             x2, [x2, #0x470]
    // 0xd2043c: r0 = InitLateFinalInstanceField()
    //     0xd2043c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd20440: mov             x2, x0
    // 0xd20444: ldur            x0, [fp, #-8]
    // 0xd20448: stur            x2, [fp, #-0x20]
    // 0xd2044c: LoadField: r1 = r0->field_b
    //     0xd2044c: ldur            w1, [x0, #0xb]
    // 0xd20450: DecompressPointer r1
    //     0xd20450: add             x1, x1, HEAP, lsl #32
    // 0xd20454: cmp             w1, NULL
    // 0xd20458: b.eq            #0xd207e0
    // 0xd2045c: LoadField: r3 = r1->field_7f
    //     0xd2045c: ldur            w3, [x1, #0x7f]
    // 0xd20460: DecompressPointer r3
    //     0xd20460: add             x3, x3, HEAP, lsl #32
    // 0xd20464: mov             x1, x0
    // 0xd20468: stur            x3, [fp, #-0x18]
    // 0xd2046c: r0 = _canRequestFocus()
    //     0xd2046c: bl              #0xd20a20  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::_canRequestFocus
    // 0xd20470: mov             x3, x0
    // 0xd20474: ldur            x0, [fp, #-8]
    // 0xd20478: stur            x3, [fp, #-0x40]
    // 0xd2047c: LoadField: r4 = r0->field_b
    //     0xd2047c: ldur            w4, [x0, #0xb]
    // 0xd20480: DecompressPointer r4
    //     0xd20480: add             x4, x4, HEAP, lsl #32
    // 0xd20484: stur            x4, [fp, #-0x38]
    // 0xd20488: cmp             w4, NULL
    // 0xd2048c: b.eq            #0xd207e4
    // 0xd20490: LoadField: r5 = r4->field_7b
    //     0xd20490: ldur            w5, [x4, #0x7b]
    // 0xd20494: DecompressPointer r5
    //     0xd20494: add             x5, x5, HEAP, lsl #32
    // 0xd20498: stur            x5, [fp, #-0x30]
    // 0xd2049c: LoadField: r6 = r4->field_f
    //     0xd2049c: ldur            w6, [x4, #0xf]
    // 0xd204a0: DecompressPointer r6
    //     0xd204a0: add             x6, x6, HEAP, lsl #32
    // 0xd204a4: stur            x6, [fp, #-0x28]
    // 0xd204a8: cmp             w6, NULL
    // 0xd204ac: b.ne            #0xd204bc
    // 0xd204b0: mov             x0, x6
    // 0xd204b4: r3 = Null
    //     0xd204b4: mov             x3, NULL
    // 0xd204b8: b               #0xd204d4
    // 0xd204bc: mov             x2, x0
    // 0xd204c0: r1 = Function 'simulateTap':.
    //     0xd204c0: add             x1, PP, #0x99, lsl #12  ; [pp+0x99478] AnonymousClosure: (0xd25c44), in [package:flutter/src/material/ink_well.dart] _InkResponseState::simulateTap (0xd25cb4)
    //     0xd204c4: ldr             x1, [x1, #0x478]
    // 0xd204c8: r0 = AllocateClosure()
    //     0xd204c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd204cc: mov             x3, x0
    // 0xd204d0: ldur            x0, [fp, #-0x28]
    // 0xd204d4: stur            x3, [fp, #-0x48]
    // 0xd204d8: cmp             w0, NULL
    // 0xd204dc: b.eq            #0xd204e8
    // 0xd204e0: ldur            x4, [fp, #-0x38]
    // 0xd204e4: b               #0xd2050c
    // 0xd204e8: ldur            x4, [fp, #-0x38]
    // 0xd204ec: ArrayLoad: r1 = r4[0]  ; List_4
    //     0xd204ec: ldur            w1, [x4, #0x17]
    // 0xd204f0: DecompressPointer r1
    //     0xd204f0: add             x1, x1, HEAP, lsl #32
    // 0xd204f4: cmp             w1, NULL
    // 0xd204f8: b.ne            #0xd2050c
    // 0xd204fc: LoadField: r1 = r4->field_13
    //     0xd204fc: ldur            w1, [x4, #0x13]
    // 0xd20500: DecompressPointer r1
    //     0xd20500: add             x1, x1, HEAP, lsl #32
    // 0xd20504: cmp             w1, NULL
    // 0xd20508: b.eq            #0xd20524
    // 0xd2050c: ldur            x2, [fp, #-8]
    // 0xd20510: r1 = Function 'handleTapDown':.
    //     0xd20510: add             x1, PP, #0x99, lsl #12  ; [pp+0x99480] AnonymousClosure: (0xd22c1c), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleTapDown (0xd22c58)
    //     0xd20514: ldr             x1, [x1, #0x480]
    // 0xd20518: r0 = AllocateClosure()
    //     0xd20518: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd2051c: mov             x3, x0
    // 0xd20520: b               #0xd20528
    // 0xd20524: r3 = Null
    //     0xd20524: mov             x3, NULL
    // 0xd20528: ldur            x0, [fp, #-0x28]
    // 0xd2052c: stur            x3, [fp, #-0x50]
    // 0xd20530: cmp             w0, NULL
    // 0xd20534: b.eq            #0xd20540
    // 0xd20538: ldur            x4, [fp, #-0x38]
    // 0xd2053c: b               #0xd20564
    // 0xd20540: ldur            x4, [fp, #-0x38]
    // 0xd20544: ArrayLoad: r1 = r4[0]  ; List_4
    //     0xd20544: ldur            w1, [x4, #0x17]
    // 0xd20548: DecompressPointer r1
    //     0xd20548: add             x1, x1, HEAP, lsl #32
    // 0xd2054c: cmp             w1, NULL
    // 0xd20550: b.ne            #0xd20564
    // 0xd20554: LoadField: r1 = r4->field_13
    //     0xd20554: ldur            w1, [x4, #0x13]
    // 0xd20558: DecompressPointer r1
    //     0xd20558: add             x1, x1, HEAP, lsl #32
    // 0xd2055c: cmp             w1, NULL
    // 0xd20560: b.eq            #0xd2057c
    // 0xd20564: ldur            x2, [fp, #-8]
    // 0xd20568: r1 = Function 'handleTapUp':.
    //     0xd20568: add             x1, PP, #0x99, lsl #12  ; [pp+0x99488] AnonymousClosure: (0xd22b78), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleTapUp (0xd22bb4)
    //     0xd2056c: ldr             x1, [x1, #0x488]
    // 0xd20570: r0 = AllocateClosure()
    //     0xd20570: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd20574: mov             x3, x0
    // 0xd20578: b               #0xd20580
    // 0xd2057c: r3 = Null
    //     0xd2057c: mov             x3, NULL
    // 0xd20580: ldur            x0, [fp, #-0x28]
    // 0xd20584: stur            x3, [fp, #-0x58]
    // 0xd20588: cmp             w0, NULL
    // 0xd2058c: b.ne            #0xd205b4
    // 0xd20590: ldur            x0, [fp, #-0x38]
    // 0xd20594: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd20594: ldur            w1, [x0, #0x17]
    // 0xd20598: DecompressPointer r1
    //     0xd20598: add             x1, x1, HEAP, lsl #32
    // 0xd2059c: cmp             w1, NULL
    // 0xd205a0: b.ne            #0xd205b4
    // 0xd205a4: LoadField: r1 = r0->field_13
    //     0xd205a4: ldur            w1, [x0, #0x13]
    // 0xd205a8: DecompressPointer r1
    //     0xd205a8: add             x1, x1, HEAP, lsl #32
    // 0xd205ac: cmp             w1, NULL
    // 0xd205b0: b.eq            #0xd205c8
    // 0xd205b4: ldur            x2, [fp, #-8]
    // 0xd205b8: r1 = Function 'handleTap':.
    //     0xd205b8: add             x1, PP, #0x99, lsl #12  ; [pp+0x99490] AnonymousClosure: (0xd227c4), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleTap (0xd227fc)
    //     0xd205bc: ldr             x1, [x1, #0x490]
    // 0xd205c0: r0 = AllocateClosure()
    //     0xd205c0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd205c4: b               #0xd205cc
    // 0xd205c8: r0 = Null
    //     0xd205c8: mov             x0, NULL
    // 0xd205cc: ldur            x1, [fp, #-8]
    // 0xd205d0: stur            x0, [fp, #-0x28]
    // 0xd205d4: r0 = _primaryEnabled()
    //     0xd205d4: bl              #0xd209bc  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::_primaryEnabled
    // 0xd205d8: tbnz            w0, #4, #0xd205f4
    // 0xd205dc: ldur            x2, [fp, #-8]
    // 0xd205e0: r1 = Function 'handleTapCancel':.
    //     0xd205e0: add             x1, PP, #0x99, lsl #12  ; [pp+0x99498] AnonymousClosure: (0xd225cc), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleTapCancel (0xd22604)
    //     0xd205e4: ldr             x1, [x1, #0x498]
    // 0xd205e8: r0 = AllocateClosure()
    //     0xd205e8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd205ec: mov             x7, x0
    // 0xd205f0: b               #0xd205f8
    // 0xd205f4: r7 = Null
    //     0xd205f4: mov             x7, NULL
    // 0xd205f8: ldur            x0, [fp, #-8]
    // 0xd205fc: ldur            x6, [fp, #-0x10]
    // 0xd20600: ldur            x5, [fp, #-0x18]
    // 0xd20604: ldur            x2, [fp, #-0x40]
    // 0xd20608: ldur            x3, [fp, #-0x30]
    // 0xd2060c: ldur            x4, [fp, #-0x20]
    // 0xd20610: stur            x7, [fp, #-0x38]
    // 0xd20614: LoadField: r1 = r0->field_b
    //     0xd20614: ldur            w1, [x0, #0xb]
    // 0xd20618: DecompressPointer r1
    //     0xd20618: add             x1, x1, HEAP, lsl #32
    // 0xd2061c: cmp             w1, NULL
    // 0xd20620: b.eq            #0xd207e8
    // 0xd20624: mov             x1, x0
    // 0xd20628: r0 = tristate()
    //     0xd20628: bl              #0x11a1528  ; [package:flutter/src/widgets/raw_radio.dart] _RawRadioState::tristate
    // 0xd2062c: ldur            x2, [fp, #-8]
    // 0xd20630: LoadField: r0 = r2->field_b
    //     0xd20630: ldur            w0, [x2, #0xb]
    // 0xd20634: DecompressPointer r0
    //     0xd20634: add             x0, x0, HEAP, lsl #32
    // 0xd20638: cmp             w0, NULL
    // 0xd2063c: b.eq            #0xd207ec
    // 0xd20640: LoadField: r1 = r0->field_b
    //     0xd20640: ldur            w1, [x0, #0xb]
    // 0xd20644: DecompressPointer r1
    //     0xd20644: add             x1, x1, HEAP, lsl #32
    // 0xd20648: stur            x1, [fp, #-0x60]
    // 0xd2064c: r0 = GestureDetector()
    //     0xd2064c: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xd20650: stur            x0, [fp, #-0x68]
    // 0xd20654: ldur            x16, [fp, #-0x50]
    // 0xd20658: ldur            lr, [fp, #-0x58]
    // 0xd2065c: stp             lr, x16, [SP, #0x38]
    // 0xd20660: ldur            x16, [fp, #-0x28]
    // 0xd20664: ldur            lr, [fp, #-0x38]
    // 0xd20668: stp             lr, x16, [SP, #0x28]
    // 0xd2066c: stp             NULL, NULL, [SP, #0x18]
    // 0xd20670: r16 = Instance_HitTestBehavior
    //     0xd20670: add             x16, PP, #0x15, lsl #12  ; [pp+0x155c0] Obj!HitTestBehavior@12c43c1
    //     0xd20674: ldr             x16, [x16, #0x5c0]
    // 0xd20678: r30 = true
    //     0xd20678: add             lr, NULL, #0x20  ; true
    // 0xd2067c: stp             lr, x16, [SP, #8]
    // 0xd20680: ldur            x16, [fp, #-0x60]
    // 0xd20684: str             x16, [SP]
    // 0xd20688: mov             x1, x0
    // 0xd2068c: r4 = const [0, 0xa, 0x9, 0x1, behavior, 0x7, child, 0x9, excludeFromSemantics, 0x8, onDoubleTap, 0x5, onLongPress, 0x6, onTap, 0x3, onTapCancel, 0x4, onTapDown, 0x1, onTapUp, 0x2, null]
    //     0xd2068c: add             x4, PP, #0x99, lsl #12  ; [pp+0x994a0] List(23) [0, 0xa, 0x9, 0x1, "behavior", 0x7, "child", 0x9, "excludeFromSemantics", 0x8, "onDoubleTap", 0x5, "onLongPress", 0x6, "onTap", 0x3, "onTapCancel", 0x4, "onTapDown", 0x1, "onTapUp", 0x2, Null]
    //     0xd20690: ldr             x4, [x4, #0x4a0]
    // 0xd20694: r0 = GestureDetector()
    //     0xd20694: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xd20698: r0 = Semantics()
    //     0xd20698: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xd2069c: stur            x0, [fp, #-0x28]
    // 0xd206a0: ldur            x16, [fp, #-0x48]
    // 0xd206a4: stp             NULL, x16, [SP, #8]
    // 0xd206a8: ldur            x16, [fp, #-0x68]
    // 0xd206ac: str             x16, [SP]
    // 0xd206b0: mov             x1, x0
    // 0xd206b4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, onLongPress, 0x2, onTap, 0x1, null]
    //     0xd206b4: add             x4, PP, #0x7d, lsl #12  ; [pp+0x7d468] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "onLongPress", 0x2, "onTap", 0x1, Null]
    //     0xd206b8: ldr             x4, [x4, #0x468]
    // 0xd206bc: r0 = Semantics()
    //     0xd206bc: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xd206c0: ldur            x1, [fp, #-0x28]
    // 0xd206c4: ldur            x2, [fp, #-0x10]
    // 0xd206c8: r0 = merge()
    //     0xd206c8: bl              #0xd20868  ; [package:flutter/src/widgets/default_selection_style.dart] DefaultSelectionStyle::merge
    // 0xd206cc: ldur            x2, [fp, #-8]
    // 0xd206d0: r1 = Function 'handleMouseEnter':.
    //     0xd206d0: add             x1, PP, #0x99, lsl #12  ; [pp+0x994a8] AnonymousClosure: (0xd22528), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleMouseEnter (0xd22564)
    //     0xd206d4: ldr             x1, [x1, #0x4a8]
    // 0xd206d8: stur            x0, [fp, #-0x28]
    // 0xd206dc: r0 = AllocateClosure()
    //     0xd206dc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd206e0: stur            x0, [fp, #-0x38]
    // 0xd206e4: r0 = MouseRegion()
    //     0xd206e4: bl              #0xd1c8fc  ; AllocateMouseRegionStub -> MouseRegion (size=0x28)
    // 0xd206e8: mov             x3, x0
    // 0xd206ec: ldur            x0, [fp, #-0x38]
    // 0xd206f0: stur            x3, [fp, #-0x48]
    // 0xd206f4: StoreField: r3->field_f = r0
    //     0xd206f4: stur            w0, [x3, #0xf]
    // 0xd206f8: ldur            x2, [fp, #-8]
    // 0xd206fc: r1 = Function 'handleMouseExit':.
    //     0xd206fc: add             x1, PP, #0x99, lsl #12  ; [pp+0x994b0] AnonymousClosure: (0xd22470), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleMouseExit (0xd224ac)
    //     0xd20700: ldr             x1, [x1, #0x4b0]
    // 0xd20704: r0 = AllocateClosure()
    //     0xd20704: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd20708: mov             x1, x0
    // 0xd2070c: ldur            x0, [fp, #-0x48]
    // 0xd20710: ArrayStore: r0[0] = r1  ; List_4
    //     0xd20710: stur            w1, [x0, #0x17]
    // 0xd20714: ldur            x1, [fp, #-0x10]
    // 0xd20718: StoreField: r0->field_1b = r1
    //     0xd20718: stur            w1, [x0, #0x1b]
    // 0xd2071c: r1 = true
    //     0xd2071c: add             x1, NULL, #0x20  ; true
    // 0xd20720: StoreField: r0->field_1f = r1
    //     0xd20720: stur            w1, [x0, #0x1f]
    // 0xd20724: ldur            x2, [fp, #-0x28]
    // 0xd20728: StoreField: r0->field_b = r2
    //     0xd20728: stur            w2, [x0, #0xb]
    // 0xd2072c: r0 = Focus()
    //     0xd2072c: bl              #0xd1c8f0  ; AllocateFocusStub -> Focus (size=0x40)
    // 0xd20730: mov             x3, x0
    // 0xd20734: ldur            x0, [fp, #-0x48]
    // 0xd20738: stur            x3, [fp, #-0x10]
    // 0xd2073c: StoreField: r3->field_f = r0
    //     0xd2073c: stur            w0, [x3, #0xf]
    // 0xd20740: ldur            x0, [fp, #-0x18]
    // 0xd20744: StoreField: r3->field_13 = r0
    //     0xd20744: stur            w0, [x3, #0x13]
    // 0xd20748: ldur            x0, [fp, #-0x30]
    // 0xd2074c: ArrayStore: r3[0] = r0  ; List_4
    //     0xd2074c: stur            w0, [x3, #0x17]
    // 0xd20750: ldur            x2, [fp, #-8]
    // 0xd20754: r1 = Function 'handleFocusUpdate':.
    //     0xd20754: add             x1, PP, #0x99, lsl #12  ; [pp+0x994b8] AnonymousClosure: (0xd20f64), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleFocusUpdate (0xd20fa0)
    //     0xd20758: ldr             x1, [x1, #0x4b8]
    // 0xd2075c: r0 = AllocateClosure()
    //     0xd2075c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd20760: mov             x1, x0
    // 0xd20764: ldur            x0, [fp, #-0x10]
    // 0xd20768: StoreField: r0->field_1b = r1
    //     0xd20768: stur            w1, [x0, #0x1b]
    // 0xd2076c: r1 = true
    //     0xd2076c: add             x1, NULL, #0x20  ; true
    // 0xd20770: StoreField: r0->field_37 = r1
    //     0xd20770: stur            w1, [x0, #0x37]
    // 0xd20774: ldur            x1, [fp, #-0x40]
    // 0xd20778: StoreField: r0->field_27 = r1
    //     0xd20778: stur            w1, [x0, #0x27]
    // 0xd2077c: r0 = Actions()
    //     0xd2077c: bl              #0xd1c8a8  ; AllocateActionsStub -> Actions (size=0x18)
    // 0xd20780: mov             x1, x0
    // 0xd20784: ldur            x0, [fp, #-0x20]
    // 0xd20788: stur            x1, [fp, #-0x18]
    // 0xd2078c: StoreField: r1->field_f = r0
    //     0xd2078c: stur            w0, [x1, #0xf]
    // 0xd20790: ldur            x0, [fp, #-0x10]
    // 0xd20794: StoreField: r1->field_13 = r0
    //     0xd20794: stur            w0, [x1, #0x13]
    // 0xd20798: r0 = _ParentInkResponseProvider()
    //     0xd20798: bl              #0xd2085c  ; Allocate_ParentInkResponseProviderStub -> _ParentInkResponseProvider (size=0x14)
    // 0xd2079c: ldur            x1, [fp, #-8]
    // 0xd207a0: StoreField: r0->field_f = r1
    //     0xd207a0: stur            w1, [x0, #0xf]
    // 0xd207a4: ldur            x1, [fp, #-0x18]
    // 0xd207a8: StoreField: r0->field_b = r1
    //     0xd207a8: stur            w1, [x0, #0xb]
    // 0xd207ac: LeaveFrame
    //     0xd207ac: mov             SP, fp
    //     0xd207b0: ldp             fp, lr, [SP], #0x10
    // 0xd207b4: ret
    //     0xd207b4: ret             
    // 0xd207b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd207b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd207bc: b               #0xd1ffc4
    // 0xd207c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd207c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd207c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd207c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd207c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd207c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd207cc: b               #0xd201b0
    // 0xd207d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd207d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd207d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd207d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd207d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd207d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd207dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd207dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd207e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd207e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd207e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd207e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd207e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd207e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd207ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd207ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _primaryEnabled(/* No info */) {
    // ** addr: 0xd209bc, size: 0x64
    // 0xd209bc: LoadField: r2 = r1->field_b
    //     0xd209bc: ldur            w2, [x1, #0xb]
    // 0xd209c0: DecompressPointer r2
    //     0xd209c0: add             x2, x2, HEAP, lsl #32
    // 0xd209c4: cmp             w2, NULL
    // 0xd209c8: b.eq            #0xd20a14
    // 0xd209cc: LoadField: r1 = r2->field_f
    //     0xd209cc: ldur            w1, [x2, #0xf]
    // 0xd209d0: DecompressPointer r1
    //     0xd209d0: add             x1, x1, HEAP, lsl #32
    // 0xd209d4: cmp             w1, NULL
    // 0xd209d8: b.ne            #0xd209ec
    // 0xd209dc: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd209dc: ldur            w1, [x2, #0x17]
    // 0xd209e0: DecompressPointer r1
    //     0xd209e0: add             x1, x1, HEAP, lsl #32
    // 0xd209e4: cmp             w1, NULL
    // 0xd209e8: b.eq            #0xd209f4
    // 0xd209ec: r0 = true
    //     0xd209ec: add             x0, NULL, #0x20  ; true
    // 0xd209f0: b               #0xd20a10
    // 0xd209f4: LoadField: r1 = r2->field_13
    //     0xd209f4: ldur            w1, [x2, #0x13]
    // 0xd209f8: DecompressPointer r1
    //     0xd209f8: add             x1, x1, HEAP, lsl #32
    // 0xd209fc: cmp             w1, NULL
    // 0xd20a00: r16 = true
    //     0xd20a00: add             x16, NULL, #0x20  ; true
    // 0xd20a04: r17 = false
    //     0xd20a04: add             x17, NULL, #0x30  ; false
    // 0xd20a08: csel            x2, x16, x17, ne
    // 0xd20a0c: mov             x0, x2
    // 0xd20a10: ret
    //     0xd20a10: ret             
    // 0xd20a14: EnterFrame
    //     0xd20a14: stp             fp, lr, [SP, #-0x10]!
    //     0xd20a18: mov             fp, SP
    // 0xd20a1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd20a1c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _canRequestFocus(/* No info */) {
    // ** addr: 0xd20a20, size: 0xd4
    // 0xd20a20: EnterFrame
    //     0xd20a20: stp             fp, lr, [SP, #-0x10]!
    //     0xd20a24: mov             fp, SP
    // 0xd20a28: AllocStack(0x8)
    //     0xd20a28: sub             SP, SP, #8
    // 0xd20a2c: SetupParameters(_InkResponseState this /* r1 => r0, fp-0x8 */)
    //     0xd20a2c: mov             x0, x1
    //     0xd20a30: stur            x1, [fp, #-8]
    // 0xd20a34: CheckStackOverflow
    //     0xd20a34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd20a38: cmp             SP, x16
    //     0xd20a3c: b.ls            #0xd20ae0
    // 0xd20a40: LoadField: r1 = r0->field_f
    //     0xd20a40: ldur            w1, [x0, #0xf]
    // 0xd20a44: DecompressPointer r1
    //     0xd20a44: add             x1, x1, HEAP, lsl #32
    // 0xd20a48: cmp             w1, NULL
    // 0xd20a4c: b.eq            #0xd20ae8
    // 0xd20a50: r0 = maybeNavigationModeOf()
    //     0xd20a50: bl              #0xd20b74  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeNavigationModeOf
    // 0xd20a54: r16 = Instance_NavigationMode
    //     0xd20a54: add             x16, PP, #0x12, lsl #12  ; [pp+0x12858] Obj!NavigationMode@12c2ba1
    //     0xd20a58: ldr             x16, [x16, #0x858]
    // 0xd20a5c: cmp             w0, w16
    // 0xd20a60: b.eq            #0xd20a6c
    // 0xd20a64: cmp             w0, NULL
    // 0xd20a68: b.ne            #0xd20ab8
    // 0xd20a6c: ldur            x0, [fp, #-8]
    // 0xd20a70: LoadField: r2 = r0->field_b
    //     0xd20a70: ldur            w2, [x0, #0xb]
    // 0xd20a74: DecompressPointer r2
    //     0xd20a74: add             x2, x2, HEAP, lsl #32
    // 0xd20a78: cmp             w2, NULL
    // 0xd20a7c: b.eq            #0xd20aec
    // 0xd20a80: mov             x1, x0
    // 0xd20a84: r0 = isWidgetEnabled()
    //     0xd20a84: bl              #0xd20b34  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::isWidgetEnabled
    // 0xd20a88: tbnz            w0, #4, #0xd20aac
    // 0xd20a8c: ldur            x1, [fp, #-8]
    // 0xd20a90: LoadField: r2 = r1->field_b
    //     0xd20a90: ldur            w2, [x1, #0xb]
    // 0xd20a94: DecompressPointer r2
    //     0xd20a94: add             x2, x2, HEAP, lsl #32
    // 0xd20a98: cmp             w2, NULL
    // 0xd20a9c: b.eq            #0xd20af0
    // 0xd20aa0: LoadField: r1 = r2->field_83
    //     0xd20aa0: ldur            w1, [x2, #0x83]
    // 0xd20aa4: DecompressPointer r1
    //     0xd20aa4: add             x1, x1, HEAP, lsl #32
    // 0xd20aa8: b               #0xd20ab0
    // 0xd20aac: r1 = false
    //     0xd20aac: add             x1, NULL, #0x30  ; false
    // 0xd20ab0: mov             x0, x1
    // 0xd20ab4: b               #0xd20ad4
    // 0xd20ab8: r16 = Instance_NavigationMode
    //     0xd20ab8: add             x16, PP, #0x99, lsl #12  ; [pp+0x99518] Obj!NavigationMode@12c2bc1
    //     0xd20abc: ldr             x16, [x16, #0x518]
    // 0xd20ac0: cmp             w0, w16
    // 0xd20ac4: b.ne            #0xd20ad0
    // 0xd20ac8: r0 = true
    //     0xd20ac8: add             x0, NULL, #0x20  ; true
    // 0xd20acc: b               #0xd20ad4
    // 0xd20ad0: r0 = Null
    //     0xd20ad0: mov             x0, NULL
    // 0xd20ad4: LeaveFrame
    //     0xd20ad4: mov             SP, fp
    //     0xd20ad8: ldp             fp, lr, [SP], #0x10
    // 0xd20adc: ret
    //     0xd20adc: ret             
    // 0xd20ae0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd20ae0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd20ae4: b               #0xd20a40
    // 0xd20ae8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd20ae8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd20aec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd20aec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd20af0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd20af0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ enabled(/* No info */) {
    // ** addr: 0xd20af4, size: 0x40
    // 0xd20af4: EnterFrame
    //     0xd20af4: stp             fp, lr, [SP, #-0x10]!
    //     0xd20af8: mov             fp, SP
    // 0xd20afc: CheckStackOverflow
    //     0xd20afc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd20b00: cmp             SP, x16
    //     0xd20b04: b.ls            #0xd20b28
    // 0xd20b08: LoadField: r2 = r1->field_b
    //     0xd20b08: ldur            w2, [x1, #0xb]
    // 0xd20b0c: DecompressPointer r2
    //     0xd20b0c: add             x2, x2, HEAP, lsl #32
    // 0xd20b10: cmp             w2, NULL
    // 0xd20b14: b.eq            #0xd20b30
    // 0xd20b18: r0 = isWidgetEnabled()
    //     0xd20b18: bl              #0xd20b34  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::isWidgetEnabled
    // 0xd20b1c: LeaveFrame
    //     0xd20b1c: mov             SP, fp
    //     0xd20b20: ldp             fp, lr, [SP], #0x10
    // 0xd20b24: ret
    //     0xd20b24: ret             
    // 0xd20b28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd20b28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd20b2c: b               #0xd20b08
    // 0xd20b30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd20b30: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ isWidgetEnabled(/* No info */) {
    // ** addr: 0xd20b34, size: 0x40
    // 0xd20b34: LoadField: r1 = r2->field_f
    //     0xd20b34: ldur            w1, [x2, #0xf]
    // 0xd20b38: DecompressPointer r1
    //     0xd20b38: add             x1, x1, HEAP, lsl #32
    // 0xd20b3c: cmp             w1, NULL
    // 0xd20b40: b.ne            #0xd20b64
    // 0xd20b44: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd20b44: ldur            w1, [x2, #0x17]
    // 0xd20b48: DecompressPointer r1
    //     0xd20b48: add             x1, x1, HEAP, lsl #32
    // 0xd20b4c: cmp             w1, NULL
    // 0xd20b50: b.ne            #0xd20b64
    // 0xd20b54: LoadField: r1 = r2->field_13
    //     0xd20b54: ldur            w1, [x2, #0x13]
    // 0xd20b58: DecompressPointer r1
    //     0xd20b58: add             x1, x1, HEAP, lsl #32
    // 0xd20b5c: cmp             w1, NULL
    // 0xd20b60: b.eq            #0xd20b6c
    // 0xd20b64: r0 = true
    //     0xd20b64: add             x0, NULL, #0x20  ; true
    // 0xd20b68: b               #0xd20b70
    // 0xd20b6c: r0 = false
    //     0xd20b6c: add             x0, NULL, #0x30  ; false
    // 0xd20b70: ret
    //     0xd20b70: ret             
  }
  get _ statesController(/* No info */) {
    // ** addr: 0xd20bcc, size: 0x58
    // 0xd20bcc: EnterFrame
    //     0xd20bcc: stp             fp, lr, [SP, #-0x10]!
    //     0xd20bd0: mov             fp, SP
    // 0xd20bd4: LoadField: r2 = r1->field_b
    //     0xd20bd4: ldur            w2, [x1, #0xb]
    // 0xd20bd8: DecompressPointer r2
    //     0xd20bd8: add             x2, x2, HEAP, lsl #32
    // 0xd20bdc: cmp             w2, NULL
    // 0xd20be0: b.eq            #0xd20c1c
    // 0xd20be4: LoadField: r3 = r2->field_8f
    //     0xd20be4: ldur            w3, [x2, #0x8f]
    // 0xd20be8: DecompressPointer r3
    //     0xd20be8: add             x3, x3, HEAP, lsl #32
    // 0xd20bec: cmp             w3, NULL
    // 0xd20bf0: b.ne            #0xd20c0c
    // 0xd20bf4: LoadField: r2 = r1->field_2b
    //     0xd20bf4: ldur            w2, [x1, #0x2b]
    // 0xd20bf8: DecompressPointer r2
    //     0xd20bf8: add             x2, x2, HEAP, lsl #32
    // 0xd20bfc: cmp             w2, NULL
    // 0xd20c00: b.eq            #0xd20c20
    // 0xd20c04: mov             x0, x2
    // 0xd20c08: b               #0xd20c10
    // 0xd20c0c: mov             x0, x3
    // 0xd20c10: LeaveFrame
    //     0xd20c10: mov             SP, fp
    //     0xd20c14: ldp             fp, lr, [SP], #0x10
    // 0xd20c18: ret
    //     0xd20c18: ret             
    // 0xd20c1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd20c1c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd20c20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd20c20: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ wantKeepAlive(/* No info */) {
    // ** addr: 0xd20e14, size: 0x7c
    // 0xd20e14: EnterFrame
    //     0xd20e14: stp             fp, lr, [SP, #-0x10]!
    //     0xd20e18: mov             fp, SP
    // 0xd20e1c: AllocStack(0x8)
    //     0xd20e1c: sub             SP, SP, #8
    // 0xd20e20: SetupParameters(_InkResponseState this /* r1 => r0, fp-0x8 */)
    //     0xd20e20: mov             x0, x1
    //     0xd20e24: stur            x1, [fp, #-8]
    // 0xd20e28: CheckStackOverflow
    //     0xd20e28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd20e2c: cmp             SP, x16
    //     0xd20e30: b.ls            #0xd20e88
    // 0xd20e34: mov             x1, x0
    // 0xd20e38: r0 = highlightsExist()
    //     0xd20e38: bl              #0xd20e90  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::highlightsExist
    // 0xd20e3c: tbnz            w0, #4, #0xd20e48
    // 0xd20e40: r0 = true
    //     0xd20e40: add             x0, NULL, #0x20  ; true
    // 0xd20e44: b               #0xd20e7c
    // 0xd20e48: ldur            x1, [fp, #-8]
    // 0xd20e4c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xd20e4c: ldur            w2, [x1, #0x17]
    // 0xd20e50: DecompressPointer r2
    //     0xd20e50: add             x2, x2, HEAP, lsl #32
    // 0xd20e54: cmp             w2, NULL
    // 0xd20e58: b.eq            #0xd20e78
    // 0xd20e5c: LoadField: r1 = r2->field_f
    //     0xd20e5c: ldur            x1, [x2, #0xf]
    // 0xd20e60: cbnz            x1, #0xd20e6c
    // 0xd20e64: r2 = false
    //     0xd20e64: add             x2, NULL, #0x30  ; false
    // 0xd20e68: b               #0xd20e70
    // 0xd20e6c: r2 = true
    //     0xd20e6c: add             x2, NULL, #0x20  ; true
    // 0xd20e70: mov             x0, x2
    // 0xd20e74: b               #0xd20e7c
    // 0xd20e78: r0 = false
    //     0xd20e78: add             x0, NULL, #0x30  ; false
    // 0xd20e7c: LeaveFrame
    //     0xd20e7c: mov             SP, fp
    //     0xd20e80: ldp             fp, lr, [SP], #0x10
    // 0xd20e84: ret
    //     0xd20e84: ret             
    // 0xd20e88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd20e88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd20e8c: b               #0xd20e34
  }
  get _ highlightsExist(/* No info */) {
    // ** addr: 0xd20e90, size: 0xa8
    // 0xd20e90: EnterFrame
    //     0xd20e90: stp             fp, lr, [SP, #-0x10]!
    //     0xd20e94: mov             fp, SP
    // 0xd20e98: AllocStack(0x10)
    //     0xd20e98: sub             SP, SP, #0x10
    // 0xd20e9c: CheckStackOverflow
    //     0xd20e9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd20ea0: cmp             SP, x16
    //     0xd20ea4: b.ls            #0xd20f30
    // 0xd20ea8: LoadField: r0 = r1->field_23
    //     0xd20ea8: ldur            w0, [x1, #0x23]
    // 0xd20eac: DecompressPointer r0
    //     0xd20eac: add             x0, x0, HEAP, lsl #32
    // 0xd20eb0: stur            x0, [fp, #-8]
    // 0xd20eb4: r1 = <InkHighlight?>
    //     0xd20eb4: add             x1, PP, #0x99, lsl #12  ; [pp+0x994f8] TypeArguments: <InkHighlight?>
    //     0xd20eb8: ldr             x1, [x1, #0x4f8]
    // 0xd20ebc: r0 = _CompactValuesIterable()
    //     0xd20ebc: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xd20ec0: mov             x3, x0
    // 0xd20ec4: ldur            x0, [fp, #-8]
    // 0xd20ec8: stur            x3, [fp, #-0x10]
    // 0xd20ecc: StoreField: r3->field_b = r0
    //     0xd20ecc: stur            w0, [x3, #0xb]
    // 0xd20ed0: r1 = Function '<anonymous closure>':.
    //     0xd20ed0: add             x1, PP, #0x99, lsl #12  ; [pp+0x99500] AnonymousClosure: (0x9e9804), in [package:simaster_ugm/app/modules/bimbingan/service/bimbingan_service.dart] BimbinganService::listBimbinganWithDosenProfile (0x9e981c)
    //     0xd20ed4: ldr             x1, [x1, #0x500]
    // 0xd20ed8: r2 = Null
    //     0xd20ed8: mov             x2, NULL
    // 0xd20edc: r0 = AllocateClosure()
    //     0xd20edc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd20ee0: ldur            x1, [fp, #-0x10]
    // 0xd20ee4: mov             x2, x0
    // 0xd20ee8: r0 = where()
    //     0xd20ee8: bl              #0xb92e4c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0xd20eec: mov             x1, x0
    // 0xd20ef0: r0 = iterator()
    //     0xd20ef0: bl              #0xb0a104  ; [dart:_internal] WhereIterable::iterator
    // 0xd20ef4: r1 = LoadClassIdInstr(r0)
    //     0xd20ef4: ldur            x1, [x0, #-1]
    //     0xd20ef8: ubfx            x1, x1, #0xc, #0x14
    // 0xd20efc: mov             x16, x0
    // 0xd20f00: mov             x0, x1
    // 0xd20f04: mov             x1, x16
    // 0xd20f08: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xd20f08: mov             x17, #0x845b
    //     0xd20f0c: movk            x17, #1, lsl #16
    //     0xd20f10: add             lr, x0, x17
    //     0xd20f14: ldr             lr, [x21, lr, lsl #3]
    //     0xd20f18: blr             lr
    // 0xd20f1c: eor             x1, x0, #0x10
    // 0xd20f20: eor             x0, x1, #0x10
    // 0xd20f24: LeaveFrame
    //     0xd20f24: mov             SP, fp
    //     0xd20f28: ldp             fp, lr, [SP], #0x10
    // 0xd20f2c: ret
    //     0xd20f2c: ret             
    // 0xd20f30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd20f30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd20f34: b               #0xd20ea8
  }
  [closure] void handleFocusUpdate(dynamic, bool) {
    // ** addr: 0xd20f64, size: 0x3c
    // 0xd20f64: EnterFrame
    //     0xd20f64: stp             fp, lr, [SP, #-0x10]!
    //     0xd20f68: mov             fp, SP
    // 0xd20f6c: ldr             x0, [fp, #0x18]
    // 0xd20f70: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd20f70: ldur            w1, [x0, #0x17]
    // 0xd20f74: DecompressPointer r1
    //     0xd20f74: add             x1, x1, HEAP, lsl #32
    // 0xd20f78: CheckStackOverflow
    //     0xd20f78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd20f7c: cmp             SP, x16
    //     0xd20f80: b.ls            #0xd20f98
    // 0xd20f84: ldr             x2, [fp, #0x10]
    // 0xd20f88: r0 = handleFocusUpdate()
    //     0xd20f88: bl              #0xd20fa0  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleFocusUpdate
    // 0xd20f8c: LeaveFrame
    //     0xd20f8c: mov             SP, fp
    //     0xd20f90: ldp             fp, lr, [SP], #0x10
    // 0xd20f94: ret
    //     0xd20f94: ret             
    // 0xd20f98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd20f98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd20f9c: b               #0xd20f84
  }
  _ handleFocusUpdate(/* No info */) {
    // ** addr: 0xd20fa0, size: 0xd8
    // 0xd20fa0: EnterFrame
    //     0xd20fa0: stp             fp, lr, [SP, #-0x10]!
    //     0xd20fa4: mov             fp, SP
    // 0xd20fa8: AllocStack(0x20)
    //     0xd20fa8: sub             SP, SP, #0x20
    // 0xd20fac: SetupParameters(_InkResponseState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xd20fac: mov             x4, x1
    //     0xd20fb0: mov             x0, x2
    //     0xd20fb4: stur            x1, [fp, #-8]
    //     0xd20fb8: stur            x2, [fp, #-0x10]
    // 0xd20fbc: CheckStackOverflow
    //     0xd20fbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd20fc0: cmp             SP, x16
    //     0xd20fc4: b.ls            #0xd21064
    // 0xd20fc8: StoreField: r4->field_37 = r0
    //     0xd20fc8: stur            w0, [x4, #0x37]
    // 0xd20fcc: LoadField: r1 = r4->field_b
    //     0xd20fcc: ldur            w1, [x4, #0xb]
    // 0xd20fd0: DecompressPointer r1
    //     0xd20fd0: add             x1, x1, HEAP, lsl #32
    // 0xd20fd4: cmp             w1, NULL
    // 0xd20fd8: b.eq            #0xd2106c
    // 0xd20fdc: LoadField: r2 = r1->field_8f
    //     0xd20fdc: ldur            w2, [x1, #0x8f]
    // 0xd20fe0: DecompressPointer r2
    //     0xd20fe0: add             x2, x2, HEAP, lsl #32
    // 0xd20fe4: cmp             w2, NULL
    // 0xd20fe8: b.ne            #0xd21000
    // 0xd20fec: LoadField: r1 = r4->field_2b
    //     0xd20fec: ldur            w1, [x4, #0x2b]
    // 0xd20ff0: DecompressPointer r1
    //     0xd20ff0: add             x1, x1, HEAP, lsl #32
    // 0xd20ff4: cmp             w1, NULL
    // 0xd20ff8: b.eq            #0xd21070
    // 0xd20ffc: b               #0xd21004
    // 0xd21000: mov             x1, x2
    // 0xd21004: mov             x3, x0
    // 0xd21008: r2 = Instance_WidgetState
    //     0xd21008: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd2100c: ldr             x2, [x2, #0xa60]
    // 0xd21010: r0 = update()
    //     0xd21010: bl              #0xd223e0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::update
    // 0xd21014: ldur            x1, [fp, #-8]
    // 0xd21018: r0 = updateFocusHighlights()
    //     0xd21018: bl              #0xd21078  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::updateFocusHighlights
    // 0xd2101c: ldur            x0, [fp, #-8]
    // 0xd21020: LoadField: r1 = r0->field_b
    //     0xd21020: ldur            w1, [x0, #0xb]
    // 0xd21024: DecompressPointer r1
    //     0xd21024: add             x1, x1, HEAP, lsl #32
    // 0xd21028: cmp             w1, NULL
    // 0xd2102c: b.eq            #0xd21074
    // 0xd21030: LoadField: r0 = r1->field_77
    //     0xd21030: ldur            w0, [x1, #0x77]
    // 0xd21034: DecompressPointer r0
    //     0xd21034: add             x0, x0, HEAP, lsl #32
    // 0xd21038: cmp             w0, NULL
    // 0xd2103c: b.eq            #0xd21054
    // 0xd21040: ldur            x16, [fp, #-0x10]
    // 0xd21044: stp             x16, x0, [SP]
    // 0xd21048: ClosureCall
    //     0xd21048: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd2104c: ldur            x2, [x0, #0x1f]
    //     0xd21050: blr             x2
    // 0xd21054: r0 = Null
    //     0xd21054: mov             x0, NULL
    // 0xd21058: LeaveFrame
    //     0xd21058: mov             SP, fp
    //     0xd2105c: ldp             fp, lr, [SP], #0x10
    // 0xd21060: ret
    //     0xd21060: ret             
    // 0xd21064: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd21064: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd21068: b               #0xd20fc8
    // 0xd2106c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2106c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd21070: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd21070: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd21074: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd21074: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ updateFocusHighlights(/* No info */) {
    // ** addr: 0xd21078, size: 0xa0
    // 0xd21078: EnterFrame
    //     0xd21078: stp             fp, lr, [SP, #-0x10]!
    //     0xd2107c: mov             fp, SP
    // 0xd21080: AllocStack(0x8)
    //     0xd21080: sub             SP, SP, #8
    // 0xd21084: SetupParameters(_InkResponseState this /* r1 => r0, fp-0x8 */)
    //     0xd21084: mov             x0, x1
    //     0xd21088: stur            x1, [fp, #-8]
    // 0xd2108c: CheckStackOverflow
    //     0xd2108c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd21090: cmp             SP, x16
    //     0xd21094: b.ls            #0xd21108
    // 0xd21098: r1 = LoadStaticField(0x6a0)
    //     0xd21098: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0xd2109c: ldr             x1, [x1, #0xd40]
    // 0xd210a0: cmp             w1, NULL
    // 0xd210a4: b.eq            #0xd21110
    // 0xd210a8: LoadField: r2 = r1->field_ef
    //     0xd210a8: ldur            w2, [x1, #0xef]
    // 0xd210ac: DecompressPointer r2
    //     0xd210ac: add             x2, x2, HEAP, lsl #32
    // 0xd210b0: cmp             w2, NULL
    // 0xd210b4: b.eq            #0xd21114
    // 0xd210b8: LoadField: r1 = r2->field_13
    //     0xd210b8: ldur            w1, [x2, #0x13]
    // 0xd210bc: DecompressPointer r1
    //     0xd210bc: add             x1, x1, HEAP, lsl #32
    // 0xd210c0: r0 = highlightMode()
    //     0xd210c0: bl              #0xd223a8  ; [package:flutter/src/widgets/focus_manager.dart] FocusManager::highlightMode
    // 0xd210c4: LoadField: r1 = r0->field_7
    //     0xd210c4: ldur            x1, [x0, #7]
    // 0xd210c8: cmp             x1, #0
    // 0xd210cc: b.gt            #0xd210d8
    // 0xd210d0: r3 = false
    //     0xd210d0: add             x3, NULL, #0x30  ; false
    // 0xd210d4: b               #0xd210e4
    // 0xd210d8: ldur            x1, [fp, #-8]
    // 0xd210dc: r0 = _shouldShowFocus()
    //     0xd210dc: bl              #0xd222dc  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::_shouldShowFocus
    // 0xd210e0: mov             x3, x0
    // 0xd210e4: ldur            x1, [fp, #-8]
    // 0xd210e8: r2 = Instance__HighlightType
    //     0xd210e8: add             x2, PP, #0x99, lsl #12  ; [pp+0x994c0] Obj!_HighlightType@12c5761
    //     0xd210ec: ldr             x2, [x2, #0x4c0]
    // 0xd210f0: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xd210f0: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xd210f4: r0 = updateHighlight()
    //     0xd210f4: bl              #0xd21118  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::updateHighlight
    // 0xd210f8: r0 = Null
    //     0xd210f8: mov             x0, NULL
    // 0xd210fc: LeaveFrame
    //     0xd210fc: mov             SP, fp
    //     0xd21100: ldp             fp, lr, [SP], #0x10
    // 0xd21104: ret
    //     0xd21104: ret             
    // 0xd21108: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd21108: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd2110c: b               #0xd21098
    // 0xd21110: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd21110: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd21114: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd21114: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ updateHighlight(/* No info */) {
    // ** addr: 0xd21118, size: 0x6c0
    // 0xd21118: EnterFrame
    //     0xd21118: stp             fp, lr, [SP, #-0x10]!
    //     0xd2111c: mov             fp, SP
    // 0xd21120: AllocStack(0xc8)
    //     0xd21120: sub             SP, SP, #0xc8
    // 0xd21124: SetupParameters(_InkResponseState this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */, {dynamic callOnHover = true /* r1, fp-0x8 */})
    //     0xd21124: mov             x0, x1
    //     0xd21128: stur            x1, [fp, #-0x10]
    //     0xd2112c: stur            x2, [fp, #-0x18]
    //     0xd21130: stur            x3, [fp, #-0x20]
    //     0xd21134: ldur            w1, [x4, #0x13]
    //     0xd21138: ldur            w5, [x4, #0x1f]
    //     0xd2113c: add             x5, x5, HEAP, lsl #32
    //     0xd21140: add             x16, PP, #0x99, lsl #12  ; [pp+0x994c8] "callOnHover"
    //     0xd21144: ldr             x16, [x16, #0x4c8]
    //     0xd21148: cmp             w5, w16
    //     0xd2114c: b.ne            #0xd21168
    //     0xd21150: ldur            w5, [x4, #0x23]
    //     0xd21154: add             x5, x5, HEAP, lsl #32
    //     0xd21158: sub             w4, w1, w5
    //     0xd2115c: add             x1, fp, w4, sxtw #2
    //     0xd21160: ldr             x1, [x1, #8]
    //     0xd21164: b               #0xd2116c
    //     0xd21168: add             x1, NULL, #0x20  ; true
    //     0xd2116c: stur            x1, [fp, #-8]
    // 0xd21170: CheckStackOverflow
    //     0xd21170: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd21174: cmp             SP, x16
    //     0xd21178: b.ls            #0xd21778
    // 0xd2117c: r1 = 2
    //     0xd2117c: mov             x1, #2
    // 0xd21180: r0 = AllocateContext()
    //     0xd21180: bl              #0x13de838  ; AllocateContextStub
    // 0xd21184: mov             x3, x0
    // 0xd21188: ldur            x0, [fp, #-0x10]
    // 0xd2118c: stur            x3, [fp, #-0x30]
    // 0xd21190: StoreField: r3->field_f = r0
    //     0xd21190: stur            w0, [x3, #0xf]
    // 0xd21194: ldur            x2, [fp, #-0x18]
    // 0xd21198: StoreField: r3->field_13 = r2
    //     0xd21198: stur            w2, [x3, #0x13]
    // 0xd2119c: LoadField: r4 = r0->field_23
    //     0xd2119c: ldur            w4, [x0, #0x23]
    // 0xd211a0: DecompressPointer r4
    //     0xd211a0: add             x4, x4, HEAP, lsl #32
    // 0xd211a4: mov             x1, x4
    // 0xd211a8: stur            x4, [fp, #-0x28]
    // 0xd211ac: r0 = _getValueOrData()
    //     0xd211ac: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xd211b0: mov             x1, x0
    // 0xd211b4: ldur            x0, [fp, #-0x28]
    // 0xd211b8: LoadField: r2 = r0->field_f
    //     0xd211b8: ldur            w2, [x0, #0xf]
    // 0xd211bc: DecompressPointer r2
    //     0xd211bc: add             x2, x2, HEAP, lsl #32
    // 0xd211c0: cmp             w2, w1
    // 0xd211c4: b.ne            #0xd211d0
    // 0xd211c8: r5 = Null
    //     0xd211c8: mov             x5, NULL
    // 0xd211cc: b               #0xd211d4
    // 0xd211d0: mov             x5, x1
    // 0xd211d4: ldur            x4, [fp, #-0x30]
    // 0xd211d8: stur            x5, [fp, #-0x18]
    // 0xd211dc: LoadField: r1 = r4->field_13
    //     0xd211dc: ldur            w1, [x4, #0x13]
    // 0xd211e0: DecompressPointer r1
    //     0xd211e0: add             x1, x1, HEAP, lsl #32
    // 0xd211e4: LoadField: r2 = r1->field_7
    //     0xd211e4: ldur            x2, [x1, #7]
    // 0xd211e8: cmp             x2, #1
    // 0xd211ec: b.gt            #0xd2129c
    // 0xd211f0: cmp             x2, #0
    // 0xd211f4: b.gt            #0xd21248
    // 0xd211f8: ldur            x6, [fp, #-0x10]
    // 0xd211fc: LoadField: r1 = r6->field_b
    //     0xd211fc: ldur            w1, [x6, #0xb]
    // 0xd21200: DecompressPointer r1
    //     0xd21200: add             x1, x1, HEAP, lsl #32
    // 0xd21204: cmp             w1, NULL
    // 0xd21208: b.eq            #0xd21780
    // 0xd2120c: LoadField: r2 = r1->field_8f
    //     0xd2120c: ldur            w2, [x1, #0x8f]
    // 0xd21210: DecompressPointer r2
    //     0xd21210: add             x2, x2, HEAP, lsl #32
    // 0xd21214: cmp             w2, NULL
    // 0xd21218: b.ne            #0xd21230
    // 0xd2121c: LoadField: r1 = r6->field_2b
    //     0xd2121c: ldur            w1, [x6, #0x2b]
    // 0xd21220: DecompressPointer r1
    //     0xd21220: add             x1, x1, HEAP, lsl #32
    // 0xd21224: cmp             w1, NULL
    // 0xd21228: b.eq            #0xd21784
    // 0xd2122c: b               #0xd21234
    // 0xd21230: mov             x1, x2
    // 0xd21234: ldur            x3, [fp, #-0x20]
    // 0xd21238: r2 = Instance_WidgetState
    //     0xd21238: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd2123c: ldr             x2, [x2, #0xa48]
    // 0xd21240: r0 = update()
    //     0xd21240: bl              #0xd223e0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::update
    // 0xd21244: b               #0xd2129c
    // 0xd21248: ldur            x0, [fp, #-8]
    // 0xd2124c: tbnz            w0, #4, #0xd2129c
    // 0xd21250: ldur            x4, [fp, #-0x10]
    // 0xd21254: LoadField: r1 = r4->field_b
    //     0xd21254: ldur            w1, [x4, #0xb]
    // 0xd21258: DecompressPointer r1
    //     0xd21258: add             x1, x1, HEAP, lsl #32
    // 0xd2125c: cmp             w1, NULL
    // 0xd21260: b.eq            #0xd21788
    // 0xd21264: LoadField: r2 = r1->field_8f
    //     0xd21264: ldur            w2, [x1, #0x8f]
    // 0xd21268: DecompressPointer r2
    //     0xd21268: add             x2, x2, HEAP, lsl #32
    // 0xd2126c: cmp             w2, NULL
    // 0xd21270: b.ne            #0xd21288
    // 0xd21274: LoadField: r1 = r4->field_2b
    //     0xd21274: ldur            w1, [x4, #0x2b]
    // 0xd21278: DecompressPointer r1
    //     0xd21278: add             x1, x1, HEAP, lsl #32
    // 0xd2127c: cmp             w1, NULL
    // 0xd21280: b.eq            #0xd2178c
    // 0xd21284: b               #0xd2128c
    // 0xd21288: mov             x1, x2
    // 0xd2128c: ldur            x3, [fp, #-0x20]
    // 0xd21290: r2 = Instance_WidgetState
    //     0xd21290: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd21294: ldr             x2, [x2, #0xa50]
    // 0xd21298: r0 = update()
    //     0xd21298: bl              #0xd223e0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::update
    // 0xd2129c: ldur            x0, [fp, #-0x30]
    // 0xd212a0: LoadField: r1 = r0->field_13
    //     0xd212a0: ldur            w1, [x0, #0x13]
    // 0xd212a4: DecompressPointer r1
    //     0xd212a4: add             x1, x1, HEAP, lsl #32
    // 0xd212a8: r16 = Instance__HighlightType
    //     0xd212a8: add             x16, PP, #0x99, lsl #12  ; [pp+0x994d0] Obj!_HighlightType@12c5741
    //     0xd212ac: ldr             x16, [x16, #0x4d0]
    // 0xd212b0: cmp             w1, w16
    // 0xd212b4: b.ne            #0xd212ec
    // 0xd212b8: ldur            x4, [fp, #-0x10]
    // 0xd212bc: LoadField: r1 = r4->field_b
    //     0xd212bc: ldur            w1, [x4, #0xb]
    // 0xd212c0: DecompressPointer r1
    //     0xd212c0: add             x1, x1, HEAP, lsl #32
    // 0xd212c4: cmp             w1, NULL
    // 0xd212c8: b.eq            #0xd21790
    // 0xd212cc: LoadField: r2 = r1->field_87
    //     0xd212cc: ldur            w2, [x1, #0x87]
    // 0xd212d0: DecompressPointer r2
    //     0xd212d0: add             x2, x2, HEAP, lsl #32
    // 0xd212d4: cmp             w2, NULL
    // 0xd212d8: b.eq            #0xd212ec
    // 0xd212dc: mov             x1, x2
    // 0xd212e0: mov             x2, x4
    // 0xd212e4: ldur            x3, [fp, #-0x20]
    // 0xd212e8: r0 = markChildInkResponsePressed()
    //     0xd212e8: bl              #0xd2215c  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::markChildInkResponsePressed
    // 0xd212ec: ldur            x1, [fp, #-0x18]
    // 0xd212f0: cmp             w1, NULL
    // 0xd212f4: b.eq            #0xd21304
    // 0xd212f8: LoadField: r0 = r1->field_37
    //     0xd212f8: ldur            w0, [x1, #0x37]
    // 0xd212fc: DecompressPointer r0
    //     0xd212fc: add             x0, x0, HEAP, lsl #32
    // 0xd21300: b               #0xd21308
    // 0xd21304: r0 = false
    //     0xd21304: add             x0, NULL, #0x30  ; false
    // 0xd21308: ldur            x3, [fp, #-0x20]
    // 0xd2130c: cmp             w3, w0
    // 0xd21310: b.ne            #0xd21324
    // 0xd21314: r0 = Null
    //     0xd21314: mov             x0, NULL
    // 0xd21318: LeaveFrame
    //     0xd21318: mov             SP, fp
    //     0xd2131c: ldp             fp, lr, [SP], #0x10
    // 0xd21320: ret
    //     0xd21320: ret             
    // 0xd21324: tbnz            w3, #4, #0xd216c0
    // 0xd21328: cmp             w1, NULL
    // 0xd2132c: b.ne            #0xd216b8
    // 0xd21330: ldur            x4, [fp, #-0x10]
    // 0xd21334: LoadField: r0 = r4->field_b
    //     0xd21334: ldur            w0, [x4, #0xb]
    // 0xd21338: DecompressPointer r0
    //     0xd21338: add             x0, x0, HEAP, lsl #32
    // 0xd2133c: cmp             w0, NULL
    // 0xd21340: b.eq            #0xd21794
    // 0xd21344: LoadField: r1 = r0->field_63
    //     0xd21344: ldur            w1, [x0, #0x63]
    // 0xd21348: DecompressPointer r1
    //     0xd21348: add             x1, x1, HEAP, lsl #32
    // 0xd2134c: cmp             w1, NULL
    // 0xd21350: b.ne            #0xd2135c
    // 0xd21354: r0 = Null
    //     0xd21354: mov             x0, NULL
    // 0xd21358: b               #0xd213a8
    // 0xd2135c: LoadField: r2 = r0->field_8f
    //     0xd2135c: ldur            w2, [x0, #0x8f]
    // 0xd21360: DecompressPointer r2
    //     0xd21360: add             x2, x2, HEAP, lsl #32
    // 0xd21364: cmp             w2, NULL
    // 0xd21368: b.ne            #0xd21380
    // 0xd2136c: LoadField: r0 = r4->field_2b
    //     0xd2136c: ldur            w0, [x4, #0x2b]
    // 0xd21370: DecompressPointer r0
    //     0xd21370: add             x0, x0, HEAP, lsl #32
    // 0xd21374: cmp             w0, NULL
    // 0xd21378: b.eq            #0xd21798
    // 0xd2137c: b               #0xd21384
    // 0xd21380: mov             x0, x2
    // 0xd21384: LoadField: r2 = r0->field_27
    //     0xd21384: ldur            w2, [x0, #0x27]
    // 0xd21388: DecompressPointer r2
    //     0xd21388: add             x2, x2, HEAP, lsl #32
    // 0xd2138c: r0 = LoadClassIdInstr(r1)
    //     0xd2138c: ldur            x0, [x1, #-1]
    //     0xd21390: ubfx            x0, x0, #0xc, #0x14
    // 0xd21394: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd21394: mov             x17, #0x7c77
    //     0xd21398: movk            x17, #1, lsl #16
    //     0xd2139c: add             lr, x0, x17
    //     0xd213a0: ldr             lr, [x21, lr, lsl #3]
    //     0xd213a4: blr             lr
    // 0xd213a8: cmp             w0, NULL
    // 0xd213ac: b.ne            #0xd214c4
    // 0xd213b0: ldur            x2, [fp, #-0x30]
    // 0xd213b4: LoadField: r0 = r2->field_13
    //     0xd213b4: ldur            w0, [x2, #0x13]
    // 0xd213b8: DecompressPointer r0
    //     0xd213b8: add             x0, x0, HEAP, lsl #32
    // 0xd213bc: LoadField: r1 = r0->field_7
    //     0xd213bc: ldur            x1, [x0, #7]
    // 0xd213c0: cmp             x1, #1
    // 0xd213c4: b.gt            #0xd21470
    // 0xd213c8: cmp             x1, #0
    // 0xd213cc: b.gt            #0xd21420
    // 0xd213d0: ldur            x0, [fp, #-0x10]
    // 0xd213d4: LoadField: r1 = r0->field_b
    //     0xd213d4: ldur            w1, [x0, #0xb]
    // 0xd213d8: DecompressPointer r1
    //     0xd213d8: add             x1, x1, HEAP, lsl #32
    // 0xd213dc: cmp             w1, NULL
    // 0xd213e0: b.eq            #0xd2179c
    // 0xd213e4: LoadField: r3 = r1->field_5f
    //     0xd213e4: ldur            w3, [x1, #0x5f]
    // 0xd213e8: DecompressPointer r3
    //     0xd213e8: add             x3, x3, HEAP, lsl #32
    // 0xd213ec: cmp             w3, NULL
    // 0xd213f0: b.ne            #0xd21418
    // 0xd213f4: LoadField: r1 = r0->field_f
    //     0xd213f4: ldur            w1, [x0, #0xf]
    // 0xd213f8: DecompressPointer r1
    //     0xd213f8: add             x1, x1, HEAP, lsl #32
    // 0xd213fc: cmp             w1, NULL
    // 0xd21400: b.eq            #0xd217a0
    // 0xd21404: r0 = of()
    //     0xd21404: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd21408: LoadField: r1 = r0->field_4f
    //     0xd21408: ldur            w1, [x0, #0x4f]
    // 0xd2140c: DecompressPointer r1
    //     0xd2140c: add             x1, x1, HEAP, lsl #32
    // 0xd21410: mov             x0, x1
    // 0xd21414: b               #0xd214bc
    // 0xd21418: mov             x0, x3
    // 0xd2141c: b               #0xd214bc
    // 0xd21420: ldur            x0, [fp, #-0x10]
    // 0xd21424: LoadField: r1 = r0->field_b
    //     0xd21424: ldur            w1, [x0, #0xb]
    // 0xd21428: DecompressPointer r1
    //     0xd21428: add             x1, x1, HEAP, lsl #32
    // 0xd2142c: cmp             w1, NULL
    // 0xd21430: b.eq            #0xd217a4
    // 0xd21434: LoadField: r2 = r1->field_5b
    //     0xd21434: ldur            w2, [x1, #0x5b]
    // 0xd21438: DecompressPointer r2
    //     0xd21438: add             x2, x2, HEAP, lsl #32
    // 0xd2143c: cmp             w2, NULL
    // 0xd21440: b.ne            #0xd21468
    // 0xd21444: LoadField: r1 = r0->field_f
    //     0xd21444: ldur            w1, [x0, #0xf]
    // 0xd21448: DecompressPointer r1
    //     0xd21448: add             x1, x1, HEAP, lsl #32
    // 0xd2144c: cmp             w1, NULL
    // 0xd21450: b.eq            #0xd217a8
    // 0xd21454: r0 = of()
    //     0xd21454: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd21458: LoadField: r1 = r0->field_57
    //     0xd21458: ldur            w1, [x0, #0x57]
    // 0xd2145c: DecompressPointer r1
    //     0xd2145c: add             x1, x1, HEAP, lsl #32
    // 0xd21460: mov             x0, x1
    // 0xd21464: b               #0xd214bc
    // 0xd21468: mov             x0, x2
    // 0xd2146c: b               #0xd214bc
    // 0xd21470: ldur            x0, [fp, #-0x10]
    // 0xd21474: LoadField: r1 = r0->field_b
    //     0xd21474: ldur            w1, [x0, #0xb]
    // 0xd21478: DecompressPointer r1
    //     0xd21478: add             x1, x1, HEAP, lsl #32
    // 0xd2147c: cmp             w1, NULL
    // 0xd21480: b.eq            #0xd217ac
    // 0xd21484: LoadField: r2 = r1->field_57
    //     0xd21484: ldur            w2, [x1, #0x57]
    // 0xd21488: DecompressPointer r2
    //     0xd21488: add             x2, x2, HEAP, lsl #32
    // 0xd2148c: cmp             w2, NULL
    // 0xd21490: b.ne            #0xd214b8
    // 0xd21494: LoadField: r1 = r0->field_f
    //     0xd21494: ldur            w1, [x0, #0xf]
    // 0xd21498: DecompressPointer r1
    //     0xd21498: add             x1, x1, HEAP, lsl #32
    // 0xd2149c: cmp             w1, NULL
    // 0xd214a0: b.eq            #0xd217b0
    // 0xd214a4: r0 = of()
    //     0xd214a4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd214a8: LoadField: r1 = r0->field_4b
    //     0xd214a8: ldur            w1, [x0, #0x4b]
    // 0xd214ac: DecompressPointer r1
    //     0xd214ac: add             x1, x1, HEAP, lsl #32
    // 0xd214b0: mov             x0, x1
    // 0xd214b4: b               #0xd214bc
    // 0xd214b8: mov             x0, x2
    // 0xd214bc: mov             x3, x0
    // 0xd214c0: b               #0xd214c8
    // 0xd214c4: mov             x3, x0
    // 0xd214c8: ldur            x0, [fp, #-0x10]
    // 0xd214cc: ldur            x2, [fp, #-0x30]
    // 0xd214d0: stur            x3, [fp, #-0x38]
    // 0xd214d4: LoadField: r1 = r0->field_f
    //     0xd214d4: ldur            w1, [x0, #0xf]
    // 0xd214d8: DecompressPointer r1
    //     0xd214d8: add             x1, x1, HEAP, lsl #32
    // 0xd214dc: cmp             w1, NULL
    // 0xd214e0: b.eq            #0xd217b4
    // 0xd214e4: r0 = renderObject()
    //     0xd214e4: bl              #0x123f10c  ; [package:flutter/src/widgets/framework.dart] Element::renderObject
    // 0xd214e8: mov             x3, x0
    // 0xd214ec: stur            x3, [fp, #-0x40]
    // 0xd214f0: cmp             w3, NULL
    // 0xd214f4: b.eq            #0xd217b8
    // 0xd214f8: mov             x0, x3
    // 0xd214fc: r2 = Null
    //     0xd214fc: mov             x2, NULL
    // 0xd21500: r1 = Null
    //     0xd21500: mov             x1, NULL
    // 0xd21504: r4 = LoadClassIdInstr(r0)
    //     0xd21504: ldur            x4, [x0, #-1]
    //     0xd21508: ubfx            x4, x4, #0xc, #0x14
    // 0xd2150c: r17 = -4710
    //     0xd2150c: mov             x17, #-0x1266
    // 0xd21510: add             x4, x4, x17
    // 0xd21514: cmp             x4, #0x109
    // 0xd21518: b.ls            #0xd2152c
    // 0xd2151c: r8 = RenderBox
    //     0xd2151c: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xd21520: r3 = Null
    //     0xd21520: add             x3, PP, #0x99, lsl #12  ; [pp+0x994d8] Null
    //     0xd21524: ldr             x3, [x3, #0x4d8]
    // 0xd21528: r0 = RenderBox()
    //     0xd21528: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xd2152c: ldur            x2, [fp, #-0x30]
    // 0xd21530: LoadField: r0 = r2->field_13
    //     0xd21530: ldur            w0, [x2, #0x13]
    // 0xd21534: DecompressPointer r0
    //     0xd21534: add             x0, x0, HEAP, lsl #32
    // 0xd21538: ldur            x3, [fp, #-0x10]
    // 0xd2153c: stur            x0, [fp, #-0x48]
    // 0xd21540: LoadField: r1 = r3->field_f
    //     0xd21540: ldur            w1, [x3, #0xf]
    // 0xd21544: DecompressPointer r1
    //     0xd21544: add             x1, x1, HEAP, lsl #32
    // 0xd21548: cmp             w1, NULL
    // 0xd2154c: b.eq            #0xd217bc
    // 0xd21550: r0 = of()
    //     0xd21550: bl              #0xd21e38  ; [package:flutter/src/material/material.dart] Material::of
    // 0xd21554: ldur            x1, [fp, #-0x10]
    // 0xd21558: stur            x0, [fp, #-0x50]
    // 0xd2155c: r0 = enabled()
    //     0xd2155c: bl              #0xd20af4  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::enabled
    // 0xd21560: tbnz            w0, #4, #0xd2156c
    // 0xd21564: ldur            x3, [fp, #-0x38]
    // 0xd21568: b               #0xd2158c
    // 0xd2156c: ldur            x1, [fp, #-0x38]
    // 0xd21570: r0 = LoadClassIdInstr(r1)
    //     0xd21570: ldur            x0, [x1, #-1]
    //     0xd21574: ubfx            x0, x0, #0xc, #0x14
    // 0xd21578: r2 = 0
    //     0xd21578: mov             x2, #0
    // 0xd2157c: r0 = GDT[cid_x0 + -0xff4]()
    //     0xd2157c: sub             lr, x0, #0xff4
    //     0xd21580: ldr             lr, [x21, lr, lsl #3]
    //     0xd21584: blr             lr
    // 0xd21588: mov             x3, x0
    // 0xd2158c: ldur            x1, [fp, #-0x10]
    // 0xd21590: ldur            x2, [fp, #-0x30]
    // 0xd21594: stur            x3, [fp, #-0x70]
    // 0xd21598: LoadField: r0 = r1->field_b
    //     0xd21598: ldur            w0, [x1, #0xb]
    // 0xd2159c: DecompressPointer r0
    //     0xd2159c: add             x0, x0, HEAP, lsl #32
    // 0xd215a0: cmp             w0, NULL
    // 0xd215a4: b.eq            #0xd217c0
    // 0xd215a8: LoadField: r4 = r0->field_47
    //     0xd215a8: ldur            w4, [x0, #0x47]
    // 0xd215ac: DecompressPointer r4
    //     0xd215ac: add             x4, x4, HEAP, lsl #32
    // 0xd215b0: stur            x4, [fp, #-0x68]
    // 0xd215b4: LoadField: r5 = r0->field_4b
    //     0xd215b4: ldur            w5, [x0, #0x4b]
    // 0xd215b8: DecompressPointer r5
    //     0xd215b8: add             x5, x5, HEAP, lsl #32
    // 0xd215bc: stur            x5, [fp, #-0x60]
    // 0xd215c0: LoadField: r6 = r0->field_4f
    //     0xd215c0: ldur            w6, [x0, #0x4f]
    // 0xd215c4: DecompressPointer r6
    //     0xd215c4: add             x6, x6, HEAP, lsl #32
    // 0xd215c8: stur            x6, [fp, #-0x58]
    // 0xd215cc: LoadField: r7 = r0->field_53
    //     0xd215cc: ldur            w7, [x0, #0x53]
    // 0xd215d0: DecompressPointer r7
    //     0xd215d0: add             x7, x7, HEAP, lsl #32
    // 0xd215d4: stur            x7, [fp, #-0x38]
    // 0xd215d8: LoadField: r8 = r0->field_8b
    //     0xd215d8: ldur            w8, [x0, #0x8b]
    // 0xd215dc: DecompressPointer r8
    //     0xd215dc: add             x8, x8, HEAP, lsl #32
    // 0xd215e0: cmp             w8, NULL
    // 0xd215e4: b.eq            #0xd217c4
    // 0xd215e8: ldur            x16, [fp, #-0x40]
    // 0xd215ec: stp             x16, x8, [SP]
    // 0xd215f0: mov             x0, x8
    // 0xd215f4: ClosureCall
    //     0xd215f4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd215f8: ldur            x2, [x0, #0x1f]
    //     0xd215fc: blr             x2
    // 0xd21600: mov             x2, x0
    // 0xd21604: ldur            x0, [fp, #-0x10]
    // 0xd21608: stur            x2, [fp, #-0x78]
    // 0xd2160c: LoadField: r1 = r0->field_f
    //     0xd2160c: ldur            w1, [x0, #0xf]
    // 0xd21610: DecompressPointer r1
    //     0xd21610: add             x1, x1, HEAP, lsl #32
    // 0xd21614: cmp             w1, NULL
    // 0xd21618: b.eq            #0xd217c8
    // 0xd2161c: r0 = of()
    //     0xd2161c: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xd21620: mov             x3, x0
    // 0xd21624: ldur            x0, [fp, #-0x30]
    // 0xd21628: stur            x3, [fp, #-0x80]
    // 0xd2162c: LoadField: r2 = r0->field_13
    //     0xd2162c: ldur            w2, [x0, #0x13]
    // 0xd21630: DecompressPointer r2
    //     0xd21630: add             x2, x2, HEAP, lsl #32
    // 0xd21634: ldur            x1, [fp, #-0x10]
    // 0xd21638: r0 = getFadeDurationForType()
    //     0xd21638: bl              #0xd21df0  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::getFadeDurationForType
    // 0xd2163c: ldur            x2, [fp, #-0x30]
    // 0xd21640: r1 = Function 'handleInkRemoval':.
    //     0xd21640: add             x1, PP, #0x99, lsl #12  ; [pp+0x994e8] AnonymousClosure: (0xd22248), in [package:flutter/src/material/ink_well.dart] _InkResponseState::updateHighlight (0xd21118)
    //     0xd21644: ldr             x1, [x1, #0x4e8]
    // 0xd21648: stur            x0, [fp, #-0x88]
    // 0xd2164c: r0 = AllocateClosure()
    //     0xd2164c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd21650: stur            x0, [fp, #-0x90]
    // 0xd21654: r0 = InkHighlight()
    //     0xd21654: bl              #0xd21de4  ; AllocateInkHighlightStub -> InkHighlight (size=0x3c)
    // 0xd21658: stur            x0, [fp, #-0x98]
    // 0xd2165c: ldur            x16, [fp, #-0x90]
    // 0xd21660: ldur            lr, [fp, #-0x60]
    // 0xd21664: stp             lr, x16, [SP, #0x20]
    // 0xd21668: ldur            x16, [fp, #-0x78]
    // 0xd2166c: ldur            lr, [fp, #-0x40]
    // 0xd21670: stp             lr, x16, [SP, #0x10]
    // 0xd21674: ldur            x16, [fp, #-0x68]
    // 0xd21678: ldur            lr, [fp, #-0x80]
    // 0xd2167c: stp             lr, x16, [SP]
    // 0xd21680: mov             x1, x0
    // 0xd21684: ldur            x2, [fp, #-0x58]
    // 0xd21688: ldur            x3, [fp, #-0x70]
    // 0xd2168c: ldur            x5, [fp, #-0x50]
    // 0xd21690: ldur            x6, [fp, #-0x38]
    // 0xd21694: ldur            x7, [fp, #-0x88]
    // 0xd21698: r0 = InkHighlight()
    //     0xd21698: bl              #0xd21968  ; [package:flutter/src/material/ink_highlight.dart] InkHighlight::InkHighlight
    // 0xd2169c: ldur            x1, [fp, #-0x28]
    // 0xd216a0: ldur            x2, [fp, #-0x48]
    // 0xd216a4: ldur            x3, [fp, #-0x98]
    // 0xd216a8: r0 = []=()
    //     0xd216a8: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xd216ac: ldur            x1, [fp, #-0x10]
    // 0xd216b0: r0 = updateKeepAlive()
    //     0xd216b0: bl              #0xd21898  ; [dart:mixin_deduplication] _MixinApplication70&State&AutomaticKeepAliveClientMixin::updateKeepAlive
    // 0xd216b4: b               #0xd216cc
    // 0xd216b8: r0 = activate()
    //     0xd216b8: bl              #0xd21838  ; [package:flutter/src/material/ink_highlight.dart] InkHighlight::activate
    // 0xd216bc: b               #0xd216cc
    // 0xd216c0: cmp             w1, NULL
    // 0xd216c4: b.eq            #0xd217cc
    // 0xd216c8: r0 = deactivate()
    //     0xd216c8: bl              #0xd217d8  ; [package:flutter/src/material/ink_highlight.dart] InkHighlight::deactivate
    // 0xd216cc: ldur            x0, [fp, #-0x30]
    // 0xd216d0: LoadField: r1 = r0->field_13
    //     0xd216d0: ldur            w1, [x0, #0x13]
    // 0xd216d4: DecompressPointer r1
    //     0xd216d4: add             x1, x1, HEAP, lsl #32
    // 0xd216d8: LoadField: r0 = r1->field_7
    //     0xd216d8: ldur            x0, [x1, #7]
    // 0xd216dc: cmp             x0, #1
    // 0xd216e0: b.gt            #0xd21768
    // 0xd216e4: cmp             x0, #0
    // 0xd216e8: b.gt            #0xd21728
    // 0xd216ec: ldur            x0, [fp, #-0x10]
    // 0xd216f0: LoadField: r1 = r0->field_b
    //     0xd216f0: ldur            w1, [x0, #0xb]
    // 0xd216f4: DecompressPointer r1
    //     0xd216f4: add             x1, x1, HEAP, lsl #32
    // 0xd216f8: cmp             w1, NULL
    // 0xd216fc: b.eq            #0xd217d0
    // 0xd21700: LoadField: r0 = r1->field_37
    //     0xd21700: ldur            w0, [x1, #0x37]
    // 0xd21704: DecompressPointer r0
    //     0xd21704: add             x0, x0, HEAP, lsl #32
    // 0xd21708: cmp             w0, NULL
    // 0xd2170c: b.eq            #0xd21768
    // 0xd21710: ldur            x16, [fp, #-0x20]
    // 0xd21714: stp             x16, x0, [SP]
    // 0xd21718: ClosureCall
    //     0xd21718: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd2171c: ldur            x2, [x0, #0x1f]
    //     0xd21720: blr             x2
    // 0xd21724: b               #0xd21768
    // 0xd21728: ldur            x0, [fp, #-0x10]
    // 0xd2172c: ldur            x1, [fp, #-8]
    // 0xd21730: tbnz            w1, #4, #0xd21768
    // 0xd21734: LoadField: r1 = r0->field_b
    //     0xd21734: ldur            w1, [x0, #0xb]
    // 0xd21738: DecompressPointer r1
    //     0xd21738: add             x1, x1, HEAP, lsl #32
    // 0xd2173c: cmp             w1, NULL
    // 0xd21740: b.eq            #0xd217d4
    // 0xd21744: LoadField: r0 = r1->field_3b
    //     0xd21744: ldur            w0, [x1, #0x3b]
    // 0xd21748: DecompressPointer r0
    //     0xd21748: add             x0, x0, HEAP, lsl #32
    // 0xd2174c: cmp             w0, NULL
    // 0xd21750: b.eq            #0xd21768
    // 0xd21754: ldur            x16, [fp, #-0x20]
    // 0xd21758: stp             x16, x0, [SP]
    // 0xd2175c: ClosureCall
    //     0xd2175c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd21760: ldur            x2, [x0, #0x1f]
    //     0xd21764: blr             x2
    // 0xd21768: r0 = Null
    //     0xd21768: mov             x0, NULL
    // 0xd2176c: LeaveFrame
    //     0xd2176c: mov             SP, fp
    //     0xd21770: ldp             fp, lr, [SP], #0x10
    // 0xd21774: ret
    //     0xd21774: ret             
    // 0xd21778: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd21778: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd2177c: b               #0xd2117c
    // 0xd21780: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd21780: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd21784: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd21784: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd21788: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd21788: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2178c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2178c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd21790: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd21790: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd21794: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd21794: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd21798: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd21798: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2179c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2179c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd217a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd217a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd217a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd217a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd217a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd217a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd217ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd217ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd217b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd217b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd217b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd217b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd217b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd217b8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd217bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd217bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd217c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd217c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd217c4: r0 = NullErrorSharedWithoutFPURegs()
    //     0xd217c4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xd217c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd217c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd217cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd217cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd217d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd217d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd217d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd217d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getFadeDurationForType(/* No info */) {
    // ** addr: 0xd21df0, size: 0x48
    // 0xd21df0: LoadField: r3 = r2->field_7
    //     0xd21df0: ldur            x3, [x2, #7]
    // 0xd21df4: cmp             x3, #1
    // 0xd21df8: b.gt            #0xd21e10
    // 0xd21dfc: cmp             x3, #0
    // 0xd21e00: b.gt            #0xd21e10
    // 0xd21e04: r0 = Instance_Duration
    //     0xd21e04: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xd21e08: ldr             x0, [x0, #0x318]
    // 0xd21e0c: ret
    //     0xd21e0c: ret             
    // 0xd21e10: LoadField: r2 = r1->field_b
    //     0xd21e10: ldur            w2, [x1, #0xb]
    // 0xd21e14: DecompressPointer r2
    //     0xd21e14: add             x2, x2, HEAP, lsl #32
    // 0xd21e18: cmp             w2, NULL
    // 0xd21e1c: b.eq            #0xd21e2c
    // 0xd21e20: r0 = Instance_Duration
    //     0xd21e20: add             x0, PP, #0x91, lsl #12  ; [pp+0x91218] Obj!Duration@12c8a71
    //     0xd21e24: ldr             x0, [x0, #0x218]
    // 0xd21e28: ret
    //     0xd21e28: ret             
    // 0xd21e2c: EnterFrame
    //     0xd21e2c: stp             fp, lr, [SP, #-0x10]!
    //     0xd21e30: mov             fp, SP
    // 0xd21e34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd21e34: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ markChildInkResponsePressed(/* No info */) {
    // ** addr: 0xd2215c, size: 0xc4
    // 0xd2215c: EnterFrame
    //     0xd2215c: stp             fp, lr, [SP, #-0x10]!
    //     0xd22160: mov             fp, SP
    // 0xd22164: AllocStack(0x10)
    //     0xd22164: sub             SP, SP, #0x10
    // 0xd22168: SetupParameters(_InkResponseState this /* r1 => r0, fp-0x10 */)
    //     0xd22168: mov             x0, x1
    //     0xd2216c: stur            x1, [fp, #-0x10]
    // 0xd22170: CheckStackOverflow
    //     0xd22170: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd22174: cmp             SP, x16
    //     0xd22178: b.ls            #0xd22214
    // 0xd2217c: LoadField: r1 = r0->field_2f
    //     0xd2217c: ldur            w1, [x0, #0x2f]
    // 0xd22180: DecompressPointer r1
    //     0xd22180: add             x1, x1, HEAP, lsl #32
    // 0xd22184: LoadField: r4 = r1->field_b
    //     0xd22184: ldur            w4, [x1, #0xb]
    // 0xd22188: DecompressPointer r4
    //     0xd22188: add             x4, x4, HEAP, lsl #32
    // 0xd2218c: LoadField: r5 = r4->field_b
    //     0xd2218c: ldur            w5, [x4, #0xb]
    // 0xd22190: cbnz            w5, #0xd2219c
    // 0xd22194: r4 = false
    //     0xd22194: add             x4, NULL, #0x30  ; false
    // 0xd22198: b               #0xd221a0
    // 0xd2219c: r4 = true
    //     0xd2219c: add             x4, NULL, #0x20  ; true
    // 0xd221a0: stur            x4, [fp, #-8]
    // 0xd221a4: tbnz            w3, #4, #0xd221b0
    // 0xd221a8: r0 = add()
    //     0xd221a8: bl              #0x83b5e8  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::add
    // 0xd221ac: b               #0xd221b4
    // 0xd221b0: r0 = remove()
    //     0xd221b0: bl              #0xb57a2c  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::remove
    // 0xd221b4: ldur            x0, [fp, #-8]
    // 0xd221b8: ldur            x1, [fp, #-0x10]
    // 0xd221bc: r0 = _anyChildInkResponsePressed()
    //     0xd221bc: bl              #0xd22220  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::_anyChildInkResponsePressed
    // 0xd221c0: mov             x1, x0
    // 0xd221c4: ldur            x0, [fp, #-8]
    // 0xd221c8: cmp             w1, w0
    // 0xd221cc: b.eq            #0xd22204
    // 0xd221d0: ldur            x2, [fp, #-0x10]
    // 0xd221d4: LoadField: r0 = r2->field_b
    //     0xd221d4: ldur            w0, [x2, #0xb]
    // 0xd221d8: DecompressPointer r0
    //     0xd221d8: add             x0, x0, HEAP, lsl #32
    // 0xd221dc: cmp             w0, NULL
    // 0xd221e0: b.eq            #0xd2221c
    // 0xd221e4: LoadField: r3 = r0->field_87
    //     0xd221e4: ldur            w3, [x0, #0x87]
    // 0xd221e8: DecompressPointer r3
    //     0xd221e8: add             x3, x3, HEAP, lsl #32
    // 0xd221ec: cmp             w3, NULL
    // 0xd221f0: b.eq            #0xd22204
    // 0xd221f4: mov             x16, x1
    // 0xd221f8: mov             x1, x3
    // 0xd221fc: mov             x3, x16
    // 0xd22200: r0 = markChildInkResponsePressed()
    //     0xd22200: bl              #0xd2215c  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::markChildInkResponsePressed
    // 0xd22204: r0 = Null
    //     0xd22204: mov             x0, NULL
    // 0xd22208: LeaveFrame
    //     0xd22208: mov             SP, fp
    //     0xd2220c: ldp             fp, lr, [SP], #0x10
    // 0xd22210: ret
    //     0xd22210: ret             
    // 0xd22214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd22214: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd22218: b               #0xd2217c
    // 0xd2221c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2221c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _anyChildInkResponsePressed(/* No info */) {
    // ** addr: 0xd22220, size: 0x28
    // 0xd22220: LoadField: r2 = r1->field_2f
    //     0xd22220: ldur            w2, [x1, #0x2f]
    // 0xd22224: DecompressPointer r2
    //     0xd22224: add             x2, x2, HEAP, lsl #32
    // 0xd22228: LoadField: r1 = r2->field_b
    //     0xd22228: ldur            w1, [x2, #0xb]
    // 0xd2222c: DecompressPointer r1
    //     0xd2222c: add             x1, x1, HEAP, lsl #32
    // 0xd22230: LoadField: r2 = r1->field_b
    //     0xd22230: ldur            w2, [x1, #0xb]
    // 0xd22234: cbnz            w2, #0xd22240
    // 0xd22238: r0 = false
    //     0xd22238: add             x0, NULL, #0x30  ; false
    // 0xd2223c: b               #0xd22244
    // 0xd22240: r0 = true
    //     0xd22240: add             x0, NULL, #0x20  ; true
    // 0xd22244: ret
    //     0xd22244: ret             
  }
  [closure] void handleInkRemoval(dynamic) {
    // ** addr: 0xd22248, size: 0x70
    // 0xd22248: EnterFrame
    //     0xd22248: stp             fp, lr, [SP, #-0x10]!
    //     0xd2224c: mov             fp, SP
    // 0xd22250: AllocStack(0x8)
    //     0xd22250: sub             SP, SP, #8
    // 0xd22254: SetupParameters([dynamic _ /* r0 */])
    //     0xd22254: ldr             x0, [fp, #0x10]
    //     0xd22258: ldur            w4, [x0, #0x17]
    //     0xd2225c: add             x4, x4, HEAP, lsl #32
    //     0xd22260: stur            x4, [fp, #-8]
    // 0xd22264: CheckStackOverflow
    //     0xd22264: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd22268: cmp             SP, x16
    //     0xd2226c: b.ls            #0xd222b0
    // 0xd22270: LoadField: r0 = r4->field_f
    //     0xd22270: ldur            w0, [x4, #0xf]
    // 0xd22274: DecompressPointer r0
    //     0xd22274: add             x0, x0, HEAP, lsl #32
    // 0xd22278: LoadField: r1 = r0->field_23
    //     0xd22278: ldur            w1, [x0, #0x23]
    // 0xd2227c: DecompressPointer r1
    //     0xd2227c: add             x1, x1, HEAP, lsl #32
    // 0xd22280: LoadField: r2 = r4->field_13
    //     0xd22280: ldur            w2, [x4, #0x13]
    // 0xd22284: DecompressPointer r2
    //     0xd22284: add             x2, x2, HEAP, lsl #32
    // 0xd22288: r3 = Null
    //     0xd22288: mov             x3, NULL
    // 0xd2228c: r0 = []=()
    //     0xd2228c: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xd22290: ldur            x0, [fp, #-8]
    // 0xd22294: LoadField: r1 = r0->field_f
    //     0xd22294: ldur            w1, [x0, #0xf]
    // 0xd22298: DecompressPointer r1
    //     0xd22298: add             x1, x1, HEAP, lsl #32
    // 0xd2229c: r0 = updateKeepAlive()
    //     0xd2229c: bl              #0xd21898  ; [dart:mixin_deduplication] _MixinApplication70&State&AutomaticKeepAliveClientMixin::updateKeepAlive
    // 0xd222a0: r0 = Null
    //     0xd222a0: mov             x0, NULL
    // 0xd222a4: LeaveFrame
    //     0xd222a4: mov             SP, fp
    //     0xd222a8: ldp             fp, lr, [SP], #0x10
    // 0xd222ac: ret
    //     0xd222ac: ret             
    // 0xd222b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd222b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd222b4: b               #0xd22270
  }
  get _ _shouldShowFocus(/* No info */) {
    // ** addr: 0xd222dc, size: 0xcc
    // 0xd222dc: EnterFrame
    //     0xd222dc: stp             fp, lr, [SP, #-0x10]!
    //     0xd222e0: mov             fp, SP
    // 0xd222e4: AllocStack(0x8)
    //     0xd222e4: sub             SP, SP, #8
    // 0xd222e8: SetupParameters(_InkResponseState this /* r1 => r0, fp-0x8 */)
    //     0xd222e8: mov             x0, x1
    //     0xd222ec: stur            x1, [fp, #-8]
    // 0xd222f0: CheckStackOverflow
    //     0xd222f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd222f4: cmp             SP, x16
    //     0xd222f8: b.ls            #0xd22398
    // 0xd222fc: LoadField: r1 = r0->field_f
    //     0xd222fc: ldur            w1, [x0, #0xf]
    // 0xd22300: DecompressPointer r1
    //     0xd22300: add             x1, x1, HEAP, lsl #32
    // 0xd22304: cmp             w1, NULL
    // 0xd22308: b.eq            #0xd223a0
    // 0xd2230c: r0 = maybeNavigationModeOf()
    //     0xd2230c: bl              #0xd20b74  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeNavigationModeOf
    // 0xd22310: r16 = Instance_NavigationMode
    //     0xd22310: add             x16, PP, #0x12, lsl #12  ; [pp+0x12858] Obj!NavigationMode@12c2ba1
    //     0xd22314: ldr             x16, [x16, #0x858]
    // 0xd22318: cmp             w0, w16
    // 0xd2231c: b.eq            #0xd22328
    // 0xd22320: cmp             w0, NULL
    // 0xd22324: b.ne            #0xd22364
    // 0xd22328: ldur            x0, [fp, #-8]
    // 0xd2232c: LoadField: r2 = r0->field_b
    //     0xd2232c: ldur            w2, [x0, #0xb]
    // 0xd22330: DecompressPointer r2
    //     0xd22330: add             x2, x2, HEAP, lsl #32
    // 0xd22334: cmp             w2, NULL
    // 0xd22338: b.eq            #0xd223a4
    // 0xd2233c: mov             x1, x0
    // 0xd22340: r0 = isWidgetEnabled()
    //     0xd22340: bl              #0xd20b34  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::isWidgetEnabled
    // 0xd22344: tbnz            w0, #4, #0xd22358
    // 0xd22348: ldur            x1, [fp, #-8]
    // 0xd2234c: LoadField: r2 = r1->field_37
    //     0xd2234c: ldur            w2, [x1, #0x37]
    // 0xd22350: DecompressPointer r2
    //     0xd22350: add             x2, x2, HEAP, lsl #32
    // 0xd22354: b               #0xd2235c
    // 0xd22358: r2 = false
    //     0xd22358: add             x2, NULL, #0x30  ; false
    // 0xd2235c: mov             x0, x2
    // 0xd22360: b               #0xd2238c
    // 0xd22364: ldur            x1, [fp, #-8]
    // 0xd22368: r16 = Instance_NavigationMode
    //     0xd22368: add             x16, PP, #0x99, lsl #12  ; [pp+0x99518] Obj!NavigationMode@12c2bc1
    //     0xd2236c: ldr             x16, [x16, #0x518]
    // 0xd22370: cmp             w0, w16
    // 0xd22374: b.ne            #0xd22388
    // 0xd22378: LoadField: r2 = r1->field_37
    //     0xd22378: ldur            w2, [x1, #0x37]
    // 0xd2237c: DecompressPointer r2
    //     0xd2237c: add             x2, x2, HEAP, lsl #32
    // 0xd22380: mov             x0, x2
    // 0xd22384: b               #0xd2238c
    // 0xd22388: r0 = Null
    //     0xd22388: mov             x0, NULL
    // 0xd2238c: LeaveFrame
    //     0xd2238c: mov             SP, fp
    //     0xd22390: ldp             fp, lr, [SP], #0x10
    // 0xd22394: ret
    //     0xd22394: ret             
    // 0xd22398: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd22398: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd2239c: b               #0xd222fc
    // 0xd223a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd223a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd223a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd223a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleMouseExit(dynamic, PointerExitEvent) {
    // ** addr: 0xd22470, size: 0x3c
    // 0xd22470: EnterFrame
    //     0xd22470: stp             fp, lr, [SP, #-0x10]!
    //     0xd22474: mov             fp, SP
    // 0xd22478: ldr             x0, [fp, #0x18]
    // 0xd2247c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd2247c: ldur            w1, [x0, #0x17]
    // 0xd22480: DecompressPointer r1
    //     0xd22480: add             x1, x1, HEAP, lsl #32
    // 0xd22484: CheckStackOverflow
    //     0xd22484: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd22488: cmp             SP, x16
    //     0xd2248c: b.ls            #0xd224a4
    // 0xd22490: ldr             x2, [fp, #0x10]
    // 0xd22494: r0 = handleMouseExit()
    //     0xd22494: bl              #0xd224ac  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleMouseExit
    // 0xd22498: LeaveFrame
    //     0xd22498: mov             SP, fp
    //     0xd2249c: ldp             fp, lr, [SP], #0x10
    // 0xd224a0: ret
    //     0xd224a0: ret             
    // 0xd224a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd224a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd224a8: b               #0xd22490
  }
  _ handleMouseExit(/* No info */) {
    // ** addr: 0xd224ac, size: 0x38
    // 0xd224ac: EnterFrame
    //     0xd224ac: stp             fp, lr, [SP, #-0x10]!
    //     0xd224b0: mov             fp, SP
    // 0xd224b4: r0 = false
    //     0xd224b4: add             x0, NULL, #0x30  ; false
    // 0xd224b8: CheckStackOverflow
    //     0xd224b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd224bc: cmp             SP, x16
    //     0xd224c0: b.ls            #0xd224dc
    // 0xd224c4: StoreField: r1->field_1f = r0
    //     0xd224c4: stur            w0, [x1, #0x1f]
    // 0xd224c8: r0 = handleHoverChange()
    //     0xd224c8: bl              #0xd224e4  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleHoverChange
    // 0xd224cc: r0 = Null
    //     0xd224cc: mov             x0, NULL
    // 0xd224d0: LeaveFrame
    //     0xd224d0: mov             SP, fp
    //     0xd224d4: ldp             fp, lr, [SP], #0x10
    // 0xd224d8: ret
    //     0xd224d8: ret             
    // 0xd224dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd224dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd224e0: b               #0xd224c4
  }
  _ handleHoverChange(/* No info */) {
    // ** addr: 0xd224e4, size: 0x44
    // 0xd224e4: EnterFrame
    //     0xd224e4: stp             fp, lr, [SP, #-0x10]!
    //     0xd224e8: mov             fp, SP
    // 0xd224ec: CheckStackOverflow
    //     0xd224ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd224f0: cmp             SP, x16
    //     0xd224f4: b.ls            #0xd22520
    // 0xd224f8: LoadField: r3 = r1->field_1f
    //     0xd224f8: ldur            w3, [x1, #0x1f]
    // 0xd224fc: DecompressPointer r3
    //     0xd224fc: add             x3, x3, HEAP, lsl #32
    // 0xd22500: r2 = Instance__HighlightType
    //     0xd22500: add             x2, PP, #0x99, lsl #12  ; [pp+0x99520] Obj!_HighlightType@12c5781
    //     0xd22504: ldr             x2, [x2, #0x520]
    // 0xd22508: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xd22508: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xd2250c: r0 = updateHighlight()
    //     0xd2250c: bl              #0xd21118  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::updateHighlight
    // 0xd22510: r0 = Null
    //     0xd22510: mov             x0, NULL
    // 0xd22514: LeaveFrame
    //     0xd22514: mov             SP, fp
    //     0xd22518: ldp             fp, lr, [SP], #0x10
    // 0xd2251c: ret
    //     0xd2251c: ret             
    // 0xd22520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd22520: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd22524: b               #0xd224f8
  }
  [closure] void handleMouseEnter(dynamic, PointerEnterEvent) {
    // ** addr: 0xd22528, size: 0x3c
    // 0xd22528: EnterFrame
    //     0xd22528: stp             fp, lr, [SP, #-0x10]!
    //     0xd2252c: mov             fp, SP
    // 0xd22530: ldr             x0, [fp, #0x18]
    // 0xd22534: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd22534: ldur            w1, [x0, #0x17]
    // 0xd22538: DecompressPointer r1
    //     0xd22538: add             x1, x1, HEAP, lsl #32
    // 0xd2253c: CheckStackOverflow
    //     0xd2253c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd22540: cmp             SP, x16
    //     0xd22544: b.ls            #0xd2255c
    // 0xd22548: ldr             x2, [fp, #0x10]
    // 0xd2254c: r0 = handleMouseEnter()
    //     0xd2254c: bl              #0xd22564  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleMouseEnter
    // 0xd22550: LeaveFrame
    //     0xd22550: mov             SP, fp
    //     0xd22554: ldp             fp, lr, [SP], #0x10
    // 0xd22558: ret
    //     0xd22558: ret             
    // 0xd2255c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd2255c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd22560: b               #0xd22548
  }
  _ handleMouseEnter(/* No info */) {
    // ** addr: 0xd22564, size: 0x68
    // 0xd22564: EnterFrame
    //     0xd22564: stp             fp, lr, [SP, #-0x10]!
    //     0xd22568: mov             fp, SP
    // 0xd2256c: AllocStack(0x8)
    //     0xd2256c: sub             SP, SP, #8
    // 0xd22570: r0 = true
    //     0xd22570: add             x0, NULL, #0x20  ; true
    // 0xd22574: mov             x3, x1
    // 0xd22578: stur            x1, [fp, #-8]
    // 0xd2257c: CheckStackOverflow
    //     0xd2257c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd22580: cmp             SP, x16
    //     0xd22584: b.ls            #0xd225c0
    // 0xd22588: StoreField: r3->field_1f = r0
    //     0xd22588: stur            w0, [x3, #0x1f]
    // 0xd2258c: LoadField: r2 = r3->field_b
    //     0xd2258c: ldur            w2, [x3, #0xb]
    // 0xd22590: DecompressPointer r2
    //     0xd22590: add             x2, x2, HEAP, lsl #32
    // 0xd22594: cmp             w2, NULL
    // 0xd22598: b.eq            #0xd225c8
    // 0xd2259c: mov             x1, x3
    // 0xd225a0: r0 = isWidgetEnabled()
    //     0xd225a0: bl              #0xd20b34  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::isWidgetEnabled
    // 0xd225a4: tbnz            w0, #4, #0xd225b0
    // 0xd225a8: ldur            x1, [fp, #-8]
    // 0xd225ac: r0 = handleHoverChange()
    //     0xd225ac: bl              #0xd224e4  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleHoverChange
    // 0xd225b0: r0 = Null
    //     0xd225b0: mov             x0, NULL
    // 0xd225b4: LeaveFrame
    //     0xd225b4: mov             SP, fp
    //     0xd225b8: ldp             fp, lr, [SP], #0x10
    // 0xd225bc: ret
    //     0xd225bc: ret             
    // 0xd225c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd225c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd225c4: b               #0xd22588
    // 0xd225c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd225c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleTapCancel(dynamic) {
    // ** addr: 0xd225cc, size: 0x38
    // 0xd225cc: EnterFrame
    //     0xd225cc: stp             fp, lr, [SP, #-0x10]!
    //     0xd225d0: mov             fp, SP
    // 0xd225d4: ldr             x0, [fp, #0x10]
    // 0xd225d8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd225d8: ldur            w1, [x0, #0x17]
    // 0xd225dc: DecompressPointer r1
    //     0xd225dc: add             x1, x1, HEAP, lsl #32
    // 0xd225e0: CheckStackOverflow
    //     0xd225e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd225e4: cmp             SP, x16
    //     0xd225e8: b.ls            #0xd225fc
    // 0xd225ec: r0 = handleTapCancel()
    //     0xd225ec: bl              #0xd22604  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleTapCancel
    // 0xd225f0: LeaveFrame
    //     0xd225f0: mov             SP, fp
    //     0xd225f4: ldp             fp, lr, [SP], #0x10
    // 0xd225f8: ret
    //     0xd225f8: ret             
    // 0xd225fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd225fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd22600: b               #0xd225ec
  }
  _ handleTapCancel(/* No info */) {
    // ** addr: 0xd22604, size: 0x1c0
    // 0xd22604: EnterFrame
    //     0xd22604: stp             fp, lr, [SP, #-0x10]!
    //     0xd22608: mov             fp, SP
    // 0xd2260c: AllocStack(0x20)
    //     0xd2260c: sub             SP, SP, #0x20
    // 0xd22610: SetupParameters(_InkResponseState this /* r1 => r0, fp-0x8 */)
    //     0xd22610: mov             x0, x1
    //     0xd22614: stur            x1, [fp, #-8]
    // 0xd22618: CheckStackOverflow
    //     0xd22618: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd2261c: cmp             SP, x16
    //     0xd22620: b.ls            #0xd2277c
    // 0xd22624: LoadField: r2 = r0->field_1b
    //     0xd22624: ldur            w2, [x0, #0x1b]
    // 0xd22628: DecompressPointer r2
    //     0xd22628: add             x2, x2, HEAP, lsl #32
    // 0xd2262c: stur            x2, [fp, #-0x10]
    // 0xd22630: cmp             w2, NULL
    // 0xd22634: b.ne            #0xd22640
    // 0xd22638: mov             x1, x0
    // 0xd2263c: b               #0xd22744
    // 0xd22640: r1 = LoadClassIdInstr(r2)
    //     0xd22640: ldur            x1, [x2, #-1]
    //     0xd22644: ubfx            x1, x1, #0xc, #0x14
    // 0xd22648: cmp             x1, #0xbde
    // 0xd2264c: b.ne            #0xd2266c
    // 0xd22650: LoadField: r1 = r2->field_43
    //     0xd22650: ldur            w1, [x2, #0x43]
    // 0xd22654: DecompressPointer r1
    //     0xd22654: add             x1, x1, HEAP, lsl #32
    // 0xd22658: cmp             w1, NULL
    // 0xd2265c: b.eq            #0xd22740
    // 0xd22660: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd22660: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd22664: r0 = forward()
    //     0xd22664: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xd22668: b               #0xd22740
    // 0xd2266c: cmp             x1, #0xbdf
    // 0xd22670: b.eq            #0xd22740
    // 0xd22674: cmp             x1, #0xbe0
    // 0xd22678: b.ne            #0xd22740
    // 0xd2267c: LoadField: r1 = r2->field_3f
    //     0xd2267c: ldur            w1, [x2, #0x3f]
    // 0xd22680: DecompressPointer r1
    //     0xd22680: add             x1, x1, HEAP, lsl #32
    // 0xd22684: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd22688: cmp             w1, w16
    // 0xd2268c: b.eq            #0xd22784
    // 0xd22690: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd22690: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd22694: r0 = stop()
    //     0xd22694: bl              #0x82eb24  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0xd22698: ldur            x0, [fp, #-0x10]
    // 0xd2269c: LoadField: r1 = r0->field_3f
    //     0xd2269c: ldur            w1, [x0, #0x3f]
    // 0xd226a0: DecompressPointer r1
    //     0xd226a0: add             x1, x1, HEAP, lsl #32
    // 0xd226a4: LoadField: r2 = r1->field_37
    //     0xd226a4: ldur            w2, [x1, #0x37]
    // 0xd226a8: DecompressPointer r2
    //     0xd226a8: add             x2, x2, HEAP, lsl #32
    // 0xd226ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd226b0: cmp             w2, w16
    // 0xd226b4: b.eq            #0xd22790
    // 0xd226b8: LoadField: d0 = r2->field_7
    //     0xd226b8: ldur            d0, [x2, #7]
    // 0xd226bc: d1 = 1.000000
    //     0xd226bc: fmov            d1, #1.00000000
    // 0xd226c0: fsub            d2, d1, d0
    // 0xd226c4: stur            d2, [fp, #-0x18]
    // 0xd226c8: LoadField: r1 = r0->field_47
    //     0xd226c8: ldur            w1, [x0, #0x47]
    // 0xd226cc: DecompressPointer r1
    //     0xd226cc: add             x1, x1, HEAP, lsl #32
    // 0xd226d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd226d4: cmp             w1, w16
    // 0xd226d8: b.eq            #0xd22798
    // 0xd226dc: r2 = inline_Allocate_Double()
    //     0xd226dc: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xd226e0: add             x2, x2, #0x10
    //     0xd226e4: cmp             x3, x2
    //     0xd226e8: b.ls            #0xd227a4
    //     0xd226ec: str             x2, [THR, #0x60]  ; THR::top
    //     0xd226f0: sub             x2, x2, #0xf
    //     0xd226f4: mov             x3, #0xe19c
    //     0xd226f8: movk            x3, #3, lsl #16
    //     0xd226fc: stur            x3, [x2, #-1]
    // 0xd22700: dmb             ishst
    // 0xd22704: StoreField: r2->field_7 = d2
    //     0xd22704: stur            d2, [x2, #7]
    // 0xd22708: r0 = value=()
    //     0xd22708: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xd2270c: ldur            d1, [fp, #-0x18]
    // 0xd22710: d0 = 1.000000
    //     0xd22710: fmov            d0, #1.00000000
    // 0xd22714: fcmp            d0, d1
    // 0xd22718: b.le            #0xd22740
    // 0xd2271c: ldur            x0, [fp, #-0x10]
    // 0xd22720: LoadField: r1 = r0->field_47
    //     0xd22720: ldur            w1, [x0, #0x47]
    // 0xd22724: DecompressPointer r1
    //     0xd22724: add             x1, x1, HEAP, lsl #32
    // 0xd22728: r16 = Instance_Duration
    //     0xd22728: add             x16, PP, #0x84, lsl #12  ; [pp+0x84f20] Obj!Duration@12c8a11
    //     0xd2272c: ldr             x16, [x16, #0xf20]
    // 0xd22730: str             x16, [SP]
    // 0xd22734: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xd22734: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xd22738: ldr             x4, [x4, #0x5a0]
    // 0xd2273c: r0 = animateTo()
    //     0xd2273c: bl              #0x866084  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateTo
    // 0xd22740: ldur            x1, [fp, #-8]
    // 0xd22744: StoreField: r1->field_1b = rNULL
    //     0xd22744: stur            NULL, [x1, #0x1b]
    // 0xd22748: LoadField: r0 = r1->field_b
    //     0xd22748: ldur            w0, [x1, #0xb]
    // 0xd2274c: DecompressPointer r0
    //     0xd2274c: add             x0, x0, HEAP, lsl #32
    // 0xd22750: cmp             w0, NULL
    // 0xd22754: b.eq            #0xd227c0
    // 0xd22758: r2 = Instance__HighlightType
    //     0xd22758: add             x2, PP, #0x99, lsl #12  ; [pp+0x994d0] Obj!_HighlightType@12c5741
    //     0xd2275c: ldr             x2, [x2, #0x4d0]
    // 0xd22760: r3 = false
    //     0xd22760: add             x3, NULL, #0x30  ; false
    // 0xd22764: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xd22764: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xd22768: r0 = updateHighlight()
    //     0xd22768: bl              #0xd21118  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::updateHighlight
    // 0xd2276c: r0 = Null
    //     0xd2276c: mov             x0, NULL
    // 0xd22770: LeaveFrame
    //     0xd22770: mov             SP, fp
    //     0xd22774: ldp             fp, lr, [SP], #0x10
    // 0xd22778: ret
    //     0xd22778: ret             
    // 0xd2277c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd2277c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd22780: b               #0xd22624
    // 0xd22784: r9 = _fadeInController
    //     0xd22784: add             x9, PP, #0x99, lsl #12  ; [pp+0x99528] Field <InkRipple._fadeInController@755110234>: late (offset: 0x40)
    //     0xd22788: ldr             x9, [x9, #0x528]
    // 0xd2278c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd2278c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd22790: r9 = _value
    //     0xd22790: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xd22794: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd22794: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd22798: r9 = _fadeOutController
    //     0xd22798: add             x9, PP, #0x99, lsl #12  ; [pp+0x99530] Field <InkRipple._fadeOutController@755110234>: late (offset: 0x48)
    //     0xd2279c: ldr             x9, [x9, #0x530]
    // 0xd227a0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xd227a0: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xd227a4: stp             q1, q2, [SP, #-0x20]!
    // 0xd227a8: stp             x0, x1, [SP, #-0x10]!
    // 0xd227ac: r0 = AllocateDouble()
    //     0xd227ac: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd227b0: mov             x2, x0
    // 0xd227b4: ldp             x0, x1, [SP], #0x10
    // 0xd227b8: ldp             q1, q2, [SP], #0x20
    // 0xd227bc: b               #0xd22704
    // 0xd227c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd227c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleTap(dynamic) {
    // ** addr: 0xd227c4, size: 0x38
    // 0xd227c4: EnterFrame
    //     0xd227c4: stp             fp, lr, [SP, #-0x10]!
    //     0xd227c8: mov             fp, SP
    // 0xd227cc: ldr             x0, [fp, #0x10]
    // 0xd227d0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd227d0: ldur            w1, [x0, #0x17]
    // 0xd227d4: DecompressPointer r1
    //     0xd227d4: add             x1, x1, HEAP, lsl #32
    // 0xd227d8: CheckStackOverflow
    //     0xd227d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd227dc: cmp             SP, x16
    //     0xd227e0: b.ls            #0xd227f4
    // 0xd227e4: r0 = handleTap()
    //     0xd227e4: bl              #0xd227fc  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleTap
    // 0xd227e8: LeaveFrame
    //     0xd227e8: mov             SP, fp
    //     0xd227ec: ldp             fp, lr, [SP], #0x10
    // 0xd227f0: ret
    //     0xd227f0: ret             
    // 0xd227f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd227f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd227f8: b               #0xd227e4
  }
  _ handleTap(/* No info */) {
    // ** addr: 0xd227fc, size: 0x2ac
    // 0xd227fc: EnterFrame
    //     0xd227fc: stp             fp, lr, [SP, #-0x10]!
    //     0xd22800: mov             fp, SP
    // 0xd22804: AllocStack(0x28)
    //     0xd22804: sub             SP, SP, #0x28
    // 0xd22808: SetupParameters(_InkResponseState this /* r1 => r1, fp-0x20 */)
    //     0xd22808: stur            x1, [fp, #-0x20]
    // 0xd2280c: CheckStackOverflow
    //     0xd2280c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd22810: cmp             SP, x16
    //     0xd22814: b.ls            #0xd22a34
    // 0xd22818: LoadField: r0 = r1->field_1b
    //     0xd22818: ldur            w0, [x1, #0x1b]
    // 0xd2281c: DecompressPointer r0
    //     0xd2281c: add             x0, x0, HEAP, lsl #32
    // 0xd22820: stur            x0, [fp, #-0x18]
    // 0xd22824: cmp             w0, NULL
    // 0xd22828: b.ne            #0xd22834
    // 0xd2282c: mov             x0, x1
    // 0xd22830: b               #0xd22990
    // 0xd22834: r2 = LoadClassIdInstr(r0)
    //     0xd22834: ldur            x2, [x0, #-1]
    //     0xd22838: ubfx            x2, x2, #0xc, #0x14
    // 0xd2283c: cmp             x2, #0xbde
    // 0xd22840: b.ne            #0xd228f8
    // 0xd22844: d0 = 1.000000
    //     0xd22844: fmov            d0, #1.00000000
    // 0xd22848: LoadField: d1 = r0->field_23
    //     0xd22848: ldur            d1, [x0, #0x23]
    // 0xd2284c: fdiv            d2, d1, d0
    // 0xd22850: fcmp            d2, d2
    // 0xd22854: b.vs            #0xd22a3c
    // 0xd22858: fcvtms          x2, d2
    // 0xd2285c: asr             x16, x2, #0x1e
    // 0xd22860: cmp             x16, x2, asr #63
    // 0xd22864: b.ne            #0xd22a3c
    // 0xd22868: lsl             x2, x2, #1
    // 0xd2286c: LoadField: r3 = r0->field_3b
    //     0xd2286c: ldur            w3, [x0, #0x3b]
    // 0xd22870: DecompressPointer r3
    //     0xd22870: add             x3, x3, HEAP, lsl #32
    // 0xd22874: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd22878: cmp             w3, w16
    // 0xd2287c: b.eq            #0xd22a68
    // 0xd22880: stur            x3, [fp, #-0x10]
    // 0xd22884: r4 = LoadInt32Instr(r2)
    //     0xd22884: sbfx            x4, x2, #1, #0x1f
    //     0xd22888: tbz             w2, #0, #0xd22890
    //     0xd2288c: ldur            x4, [x2, #7]
    // 0xd22890: r16 = 1000
    //     0xd22890: mov             x16, #0x3e8
    // 0xd22894: mul             x2, x4, x16
    // 0xd22898: stur            x2, [fp, #-8]
    // 0xd2289c: r0 = Duration()
    //     0xd2289c: bl              #0x7dd0d0  ; AllocateDurationStub -> Duration (size=0x10)
    // 0xd228a0: mov             x1, x0
    // 0xd228a4: ldur            x0, [fp, #-8]
    // 0xd228a8: StoreField: r1->field_7 = r0
    //     0xd228a8: stur            x0, [x1, #7]
    // 0xd228ac: mov             x0, x1
    // 0xd228b0: ldur            x1, [fp, #-0x10]
    // 0xd228b4: StoreField: r1->field_27 = r0
    //     0xd228b4: stur            w0, [x1, #0x27]
    //     0xd228b8: ldurb           w16, [x1, #-1]
    //     0xd228bc: ldurb           w17, [x0, #-1]
    //     0xd228c0: and             x16, x17, x16, lsr #2
    //     0xd228c4: tst             x16, HEAP, lsr #32
    //     0xd228c8: b.eq            #0xd228d0
    //     0xd228cc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd228d0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd228d0: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd228d4: r0 = forward()
    //     0xd228d4: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xd228d8: ldur            x0, [fp, #-0x18]
    // 0xd228dc: LoadField: r1 = r0->field_43
    //     0xd228dc: ldur            w1, [x0, #0x43]
    // 0xd228e0: DecompressPointer r1
    //     0xd228e0: add             x1, x1, HEAP, lsl #32
    // 0xd228e4: cmp             w1, NULL
    // 0xd228e8: b.eq            #0xd22a74
    // 0xd228ec: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd228ec: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd228f0: r0 = forward()
    //     0xd228f0: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xd228f4: b               #0xd2298c
    // 0xd228f8: d0 = 1.000000
    //     0xd228f8: fmov            d0, #1.00000000
    // 0xd228fc: cmp             x2, #0xbdf
    // 0xd22900: b.eq            #0xd2298c
    // 0xd22904: cmp             x2, #0xbe0
    // 0xd22908: b.ne            #0xd2298c
    // 0xd2290c: r1 = Instance_Duration
    //     0xd2290c: add             x1, PP, #0x99, lsl #12  ; [pp+0x99538] Obj!Duration@12c8a91
    //     0xd22910: ldr             x1, [x1, #0x538]
    // 0xd22914: LoadField: r2 = r0->field_37
    //     0xd22914: ldur            w2, [x0, #0x37]
    // 0xd22918: DecompressPointer r2
    //     0xd22918: add             x2, x2, HEAP, lsl #32
    // 0xd2291c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd22920: cmp             w2, w16
    // 0xd22924: b.eq            #0xd22a78
    // 0xd22928: StoreField: r2->field_27 = r1
    //     0xd22928: stur            w1, [x2, #0x27]
    // 0xd2292c: mov             x1, x2
    // 0xd22930: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd22930: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd22934: r0 = forward()
    //     0xd22934: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xd22938: ldur            x0, [fp, #-0x18]
    // 0xd2293c: LoadField: r1 = r0->field_3f
    //     0xd2293c: ldur            w1, [x0, #0x3f]
    // 0xd22940: DecompressPointer r1
    //     0xd22940: add             x1, x1, HEAP, lsl #32
    // 0xd22944: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd22948: cmp             w1, w16
    // 0xd2294c: b.eq            #0xd22a84
    // 0xd22950: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd22950: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd22954: r0 = forward()
    //     0xd22954: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xd22958: ldur            x0, [fp, #-0x18]
    // 0xd2295c: LoadField: r1 = r0->field_47
    //     0xd2295c: ldur            w1, [x0, #0x47]
    // 0xd22960: DecompressPointer r1
    //     0xd22960: add             x1, x1, HEAP, lsl #32
    // 0xd22964: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd22968: cmp             w1, w16
    // 0xd2296c: b.eq            #0xd22a90
    // 0xd22970: r16 = Instance_Duration
    //     0xd22970: add             x16, PP, #0x99, lsl #12  ; [pp+0x99540] Obj!Duration@12c8a81
    //     0xd22974: ldr             x16, [x16, #0x540]
    // 0xd22978: str             x16, [SP]
    // 0xd2297c: d0 = 1.000000
    //     0xd2297c: fmov            d0, #1.00000000
    // 0xd22980: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xd22980: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xd22984: ldr             x4, [x4, #0x5a0]
    // 0xd22988: r0 = animateTo()
    //     0xd22988: bl              #0x866084  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateTo
    // 0xd2298c: ldur            x0, [fp, #-0x20]
    // 0xd22990: StoreField: r0->field_1b = rNULL
    //     0xd22990: stur            NULL, [x0, #0x1b]
    // 0xd22994: mov             x1, x0
    // 0xd22998: r2 = Instance__HighlightType
    //     0xd22998: add             x2, PP, #0x99, lsl #12  ; [pp+0x994d0] Obj!_HighlightType@12c5741
    //     0xd2299c: ldr             x2, [x2, #0x4d0]
    // 0xd229a0: r3 = false
    //     0xd229a0: add             x3, NULL, #0x30  ; false
    // 0xd229a4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xd229a4: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xd229a8: r0 = updateHighlight()
    //     0xd229a8: bl              #0xd21118  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::updateHighlight
    // 0xd229ac: ldur            x0, [fp, #-0x20]
    // 0xd229b0: LoadField: r1 = r0->field_b
    //     0xd229b0: ldur            w1, [x0, #0xb]
    // 0xd229b4: DecompressPointer r1
    //     0xd229b4: add             x1, x1, HEAP, lsl #32
    // 0xd229b8: cmp             w1, NULL
    // 0xd229bc: b.eq            #0xd22a9c
    // 0xd229c0: LoadField: r2 = r1->field_f
    //     0xd229c0: ldur            w2, [x1, #0xf]
    // 0xd229c4: DecompressPointer r2
    //     0xd229c4: add             x2, x2, HEAP, lsl #32
    // 0xd229c8: cmp             w2, NULL
    // 0xd229cc: b.eq            #0xd22a24
    // 0xd229d0: LoadField: r2 = r1->field_6f
    //     0xd229d0: ldur            w2, [x1, #0x6f]
    // 0xd229d4: DecompressPointer r2
    //     0xd229d4: add             x2, x2, HEAP, lsl #32
    // 0xd229d8: tbnz            w2, #4, #0xd229f0
    // 0xd229dc: LoadField: r1 = r0->field_f
    //     0xd229dc: ldur            w1, [x0, #0xf]
    // 0xd229e0: DecompressPointer r1
    //     0xd229e0: add             x1, x1, HEAP, lsl #32
    // 0xd229e4: cmp             w1, NULL
    // 0xd229e8: b.eq            #0xd22aa0
    // 0xd229ec: r0 = forTap()
    //     0xd229ec: bl              #0xd22aa8  ; [package:flutter/src/widgets/feedback.dart] Feedback::forTap
    // 0xd229f0: ldur            x0, [fp, #-0x20]
    // 0xd229f4: LoadField: r1 = r0->field_b
    //     0xd229f4: ldur            w1, [x0, #0xb]
    // 0xd229f8: DecompressPointer r1
    //     0xd229f8: add             x1, x1, HEAP, lsl #32
    // 0xd229fc: cmp             w1, NULL
    // 0xd22a00: b.eq            #0xd22aa4
    // 0xd22a04: LoadField: r0 = r1->field_f
    //     0xd22a04: ldur            w0, [x1, #0xf]
    // 0xd22a08: DecompressPointer r0
    //     0xd22a08: add             x0, x0, HEAP, lsl #32
    // 0xd22a0c: cmp             w0, NULL
    // 0xd22a10: b.eq            #0xd22a24
    // 0xd22a14: str             x0, [SP]
    // 0xd22a18: ClosureCall
    //     0xd22a18: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xd22a1c: ldur            x2, [x0, #0x1f]
    //     0xd22a20: blr             x2
    // 0xd22a24: r0 = Null
    //     0xd22a24: mov             x0, NULL
    // 0xd22a28: LeaveFrame
    //     0xd22a28: mov             SP, fp
    //     0xd22a2c: ldp             fp, lr, [SP], #0x10
    // 0xd22a30: ret
    //     0xd22a30: ret             
    // 0xd22a34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd22a34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd22a38: b               #0xd22818
    // 0xd22a3c: SaveReg d2
    //     0xd22a3c: str             q2, [SP, #-0x10]!
    // 0xd22a40: stp             x0, x1, [SP, #-0x10]!
    // 0xd22a44: d0 = 0.000000
    //     0xd22a44: fmov            d0, d2
    // 0xd22a48: r0 = 70
    //     0xd22a48: mov             x0, #0x46
    // 0xd22a4c: r30 = DoubleToIntegerStub
    //     0xd22a4c: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xd22a50: LoadField: r30 = r30->field_7
    //     0xd22a50: ldur            lr, [lr, #7]
    // 0xd22a54: blr             lr
    // 0xd22a58: mov             x2, x0
    // 0xd22a5c: ldp             x0, x1, [SP], #0x10
    // 0xd22a60: RestoreReg d2
    //     0xd22a60: ldr             q2, [SP], #0x10
    // 0xd22a64: b               #0xd2286c
    // 0xd22a68: r9 = _radiusController
    //     0xd22a68: add             x9, PP, #0x99, lsl #12  ; [pp+0x99548] Field <InkSplash._radiusController@757036029>: late (offset: 0x3c)
    //     0xd22a6c: ldr             x9, [x9, #0x548]
    // 0xd22a70: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd22a70: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd22a74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd22a74: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd22a78: r9 = _radiusController
    //     0xd22a78: add             x9, PP, #0x99, lsl #12  ; [pp+0x99550] Field <InkRipple._radiusController@755110234>: late (offset: 0x38)
    //     0xd22a7c: ldr             x9, [x9, #0x550]
    // 0xd22a80: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xd22a80: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xd22a84: r9 = _fadeInController
    //     0xd22a84: add             x9, PP, #0x99, lsl #12  ; [pp+0x99528] Field <InkRipple._fadeInController@755110234>: late (offset: 0x40)
    //     0xd22a88: ldr             x9, [x9, #0x528]
    // 0xd22a8c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd22a8c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd22a90: r9 = _fadeOutController
    //     0xd22a90: add             x9, PP, #0x99, lsl #12  ; [pp+0x99530] Field <InkRipple._fadeOutController@755110234>: late (offset: 0x48)
    //     0xd22a94: ldr             x9, [x9, #0x530]
    // 0xd22a98: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd22a98: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd22a9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd22a9c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd22aa0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd22aa0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd22aa4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd22aa4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleTapUp(dynamic, TapUpDetails) {
    // ** addr: 0xd22b78, size: 0x3c
    // 0xd22b78: EnterFrame
    //     0xd22b78: stp             fp, lr, [SP, #-0x10]!
    //     0xd22b7c: mov             fp, SP
    // 0xd22b80: ldr             x0, [fp, #0x18]
    // 0xd22b84: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd22b84: ldur            w1, [x0, #0x17]
    // 0xd22b88: DecompressPointer r1
    //     0xd22b88: add             x1, x1, HEAP, lsl #32
    // 0xd22b8c: CheckStackOverflow
    //     0xd22b8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd22b90: cmp             SP, x16
    //     0xd22b94: b.ls            #0xd22bac
    // 0xd22b98: ldr             x2, [fp, #0x10]
    // 0xd22b9c: r0 = handleTapUp()
    //     0xd22b9c: bl              #0xd22bb4  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleTapUp
    // 0xd22ba0: LeaveFrame
    //     0xd22ba0: mov             SP, fp
    //     0xd22ba4: ldp             fp, lr, [SP], #0x10
    // 0xd22ba8: ret
    //     0xd22ba8: ret             
    // 0xd22bac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd22bac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd22bb0: b               #0xd22b98
  }
  _ handleTapUp(/* No info */) {
    // ** addr: 0xd22bb4, size: 0x68
    // 0xd22bb4: EnterFrame
    //     0xd22bb4: stp             fp, lr, [SP, #-0x10]!
    //     0xd22bb8: mov             fp, SP
    // 0xd22bbc: AllocStack(0x10)
    //     0xd22bbc: sub             SP, SP, #0x10
    // 0xd22bc0: CheckStackOverflow
    //     0xd22bc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd22bc4: cmp             SP, x16
    //     0xd22bc8: b.ls            #0xd22c10
    // 0xd22bcc: LoadField: r0 = r1->field_b
    //     0xd22bcc: ldur            w0, [x1, #0xb]
    // 0xd22bd0: DecompressPointer r0
    //     0xd22bd0: add             x0, x0, HEAP, lsl #32
    // 0xd22bd4: cmp             w0, NULL
    // 0xd22bd8: b.eq            #0xd22c18
    // 0xd22bdc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd22bdc: ldur            w1, [x0, #0x17]
    // 0xd22be0: DecompressPointer r1
    //     0xd22be0: add             x1, x1, HEAP, lsl #32
    // 0xd22be4: cmp             w1, NULL
    // 0xd22be8: b.eq            #0xd22c00
    // 0xd22bec: stp             x2, x1, [SP]
    // 0xd22bf0: mov             x0, x1
    // 0xd22bf4: ClosureCall
    //     0xd22bf4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd22bf8: ldur            x2, [x0, #0x1f]
    //     0xd22bfc: blr             x2
    // 0xd22c00: r0 = Null
    //     0xd22c00: mov             x0, NULL
    // 0xd22c04: LeaveFrame
    //     0xd22c04: mov             SP, fp
    //     0xd22c08: ldp             fp, lr, [SP], #0x10
    // 0xd22c0c: ret
    //     0xd22c0c: ret             
    // 0xd22c10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd22c10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd22c14: b               #0xd22bcc
    // 0xd22c18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd22c18: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleTapDown(dynamic, TapDownDetails) {
    // ** addr: 0xd22c1c, size: 0x3c
    // 0xd22c1c: EnterFrame
    //     0xd22c1c: stp             fp, lr, [SP, #-0x10]!
    //     0xd22c20: mov             fp, SP
    // 0xd22c24: ldr             x0, [fp, #0x18]
    // 0xd22c28: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd22c28: ldur            w1, [x0, #0x17]
    // 0xd22c2c: DecompressPointer r1
    //     0xd22c2c: add             x1, x1, HEAP, lsl #32
    // 0xd22c30: CheckStackOverflow
    //     0xd22c30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd22c34: cmp             SP, x16
    //     0xd22c38: b.ls            #0xd22c50
    // 0xd22c3c: ldr             x2, [fp, #0x10]
    // 0xd22c40: r0 = handleTapDown()
    //     0xd22c40: bl              #0xd22c58  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleTapDown
    // 0xd22c44: LeaveFrame
    //     0xd22c44: mov             SP, fp
    //     0xd22c48: ldp             fp, lr, [SP], #0x10
    // 0xd22c4c: ret
    //     0xd22c4c: ret             
    // 0xd22c50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd22c50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd22c54: b               #0xd22c3c
  }
  _ handleTapDown(/* No info */) {
    // ** addr: 0xd22c58, size: 0x88
    // 0xd22c58: EnterFrame
    //     0xd22c58: stp             fp, lr, [SP, #-0x10]!
    //     0xd22c5c: mov             fp, SP
    // 0xd22c60: AllocStack(0x20)
    //     0xd22c60: sub             SP, SP, #0x20
    // 0xd22c64: SetupParameters(_InkResponseState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xd22c64: mov             x3, x1
    //     0xd22c68: mov             x0, x2
    //     0xd22c6c: stur            x1, [fp, #-8]
    //     0xd22c70: stur            x2, [fp, #-0x10]
    // 0xd22c74: CheckStackOverflow
    //     0xd22c74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd22c78: cmp             SP, x16
    //     0xd22c7c: b.ls            #0xd22cd4
    // 0xd22c80: mov             x1, x3
    // 0xd22c84: mov             x2, x0
    // 0xd22c88: r0 = handleAnyTapDown()
    //     0xd22c88: bl              #0xd22ce0  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleAnyTapDown
    // 0xd22c8c: ldur            x0, [fp, #-8]
    // 0xd22c90: LoadField: r1 = r0->field_b
    //     0xd22c90: ldur            w1, [x0, #0xb]
    // 0xd22c94: DecompressPointer r1
    //     0xd22c94: add             x1, x1, HEAP, lsl #32
    // 0xd22c98: cmp             w1, NULL
    // 0xd22c9c: b.eq            #0xd22cdc
    // 0xd22ca0: LoadField: r0 = r1->field_13
    //     0xd22ca0: ldur            w0, [x1, #0x13]
    // 0xd22ca4: DecompressPointer r0
    //     0xd22ca4: add             x0, x0, HEAP, lsl #32
    // 0xd22ca8: cmp             w0, NULL
    // 0xd22cac: b.eq            #0xd22cc4
    // 0xd22cb0: ldur            x16, [fp, #-0x10]
    // 0xd22cb4: stp             x16, x0, [SP]
    // 0xd22cb8: ClosureCall
    //     0xd22cb8: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd22cbc: ldur            x2, [x0, #0x1f]
    //     0xd22cc0: blr             x2
    // 0xd22cc4: r0 = Null
    //     0xd22cc4: mov             x0, NULL
    // 0xd22cc8: LeaveFrame
    //     0xd22cc8: mov             SP, fp
    //     0xd22ccc: ldp             fp, lr, [SP], #0x10
    // 0xd22cd0: ret
    //     0xd22cd0: ret             
    // 0xd22cd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd22cd4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd22cd8: b               #0xd22c80
    // 0xd22cdc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd22cdc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ handleAnyTapDown(/* No info */) {
    // ** addr: 0xd22ce0, size: 0x68
    // 0xd22ce0: EnterFrame
    //     0xd22ce0: stp             fp, lr, [SP, #-0x10]!
    //     0xd22ce4: mov             fp, SP
    // 0xd22ce8: AllocStack(0x8)
    //     0xd22ce8: sub             SP, SP, #8
    // 0xd22cec: CheckStackOverflow
    //     0xd22cec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd22cf0: cmp             SP, x16
    //     0xd22cf4: b.ls            #0xd22d40
    // 0xd22cf8: LoadField: r0 = r1->field_2f
    //     0xd22cf8: ldur            w0, [x1, #0x2f]
    // 0xd22cfc: DecompressPointer r0
    //     0xd22cfc: add             x0, x0, HEAP, lsl #32
    // 0xd22d00: LoadField: r3 = r0->field_b
    //     0xd22d00: ldur            w3, [x0, #0xb]
    // 0xd22d04: DecompressPointer r3
    //     0xd22d04: add             x3, x3, HEAP, lsl #32
    // 0xd22d08: LoadField: r0 = r3->field_b
    //     0xd22d08: ldur            w0, [x3, #0xb]
    // 0xd22d0c: cbz             w0, #0xd22d20
    // 0xd22d10: r0 = Null
    //     0xd22d10: mov             x0, NULL
    // 0xd22d14: LeaveFrame
    //     0xd22d14: mov             SP, fp
    //     0xd22d18: ldp             fp, lr, [SP], #0x10
    // 0xd22d1c: ret
    //     0xd22d1c: ret             
    // 0xd22d20: str             x2, [SP]
    // 0xd22d24: r4 = const [0, 0x2, 0x1, 0x1, details, 0x1, null]
    //     0xd22d24: add             x4, PP, #0x99, lsl #12  ; [pp+0x99560] List(7) [0, 0x2, 0x1, 0x1, "details", 0x1, Null]
    //     0xd22d28: ldr             x4, [x4, #0x560]
    // 0xd22d2c: r0 = _startNewSplash()
    //     0xd22d2c: bl              #0xd22d48  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::_startNewSplash
    // 0xd22d30: r0 = Null
    //     0xd22d30: mov             x0, NULL
    // 0xd22d34: LeaveFrame
    //     0xd22d34: mov             SP, fp
    //     0xd22d38: ldp             fp, lr, [SP], #0x10
    // 0xd22d3c: ret
    //     0xd22d3c: ret             
    // 0xd22d40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd22d40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd22d44: b               #0xd22cf8
  }
  _ _startNewSplash(/* No info */) {
    // ** addr: 0xd22d48, size: 0x3e0
    // 0xd22d48: EnterFrame
    //     0xd22d48: stp             fp, lr, [SP, #-0x10]!
    //     0xd22d4c: mov             fp, SP
    // 0xd22d50: AllocStack(0x28)
    //     0xd22d50: sub             SP, SP, #0x28
    // 0xd22d54: SetupParameters(_InkResponseState this /* r1 => r0, fp-0x8 */, {dynamic context = Null /* r3 */, dynamic details = Null /* r1 */})
    //     0xd22d54: mov             x0, x1
    //     0xd22d58: stur            x1, [fp, #-8]
    //     0xd22d5c: ldur            w1, [x4, #0x13]
    //     0xd22d60: ldur            w2, [x4, #0x1f]
    //     0xd22d64: add             x2, x2, HEAP, lsl #32
    //     0xd22d68: ldr             x16, [PP, #0x4f18]  ; [pp+0x4f18] "context"
    //     0xd22d6c: cmp             w2, w16
    //     0xd22d70: b.ne            #0xd22d94
    //     0xd22d74: ldur            w2, [x4, #0x23]
    //     0xd22d78: add             x2, x2, HEAP, lsl #32
    //     0xd22d7c: sub             w3, w1, w2
    //     0xd22d80: add             x2, fp, w3, sxtw #2
    //     0xd22d84: ldr             x2, [x2, #8]
    //     0xd22d88: mov             x3, x2
    //     0xd22d8c: mov             x2, #1
    //     0xd22d90: b               #0xd22d9c
    //     0xd22d94: mov             x3, NULL
    //     0xd22d98: mov             x2, #0
    //     0xd22d9c: lsl             x5, x2, #1
    //     0xd22da0: lsl             w2, w5, #1
    //     0xd22da4: add             w5, w2, #8
    //     0xd22da8: add             x16, x4, w5, sxtw #1
    //     0xd22dac: ldur            w6, [x16, #0xf]
    //     0xd22db0: add             x6, x6, HEAP, lsl #32
    //     0xd22db4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] "details"
    //     0xd22db8: ldr             x16, [x16, #0xf78]
    //     0xd22dbc: cmp             w6, w16
    //     0xd22dc0: b.ne            #0xd22de4
    //     0xd22dc4: add             w5, w2, #0xa
    //     0xd22dc8: add             x16, x4, w5, sxtw #1
    //     0xd22dcc: ldur            w2, [x16, #0xf]
    //     0xd22dd0: add             x2, x2, HEAP, lsl #32
    //     0xd22dd4: sub             w4, w1, w2
    //     0xd22dd8: add             x1, fp, w4, sxtw #2
    //     0xd22ddc: ldr             x1, [x1, #8]
    //     0xd22de0: b               #0xd22de8
    //     0xd22de4: mov             x1, NULL
    // 0xd22de8: CheckStackOverflow
    //     0xd22de8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd22dec: cmp             SP, x16
    //     0xd22df0: b.ls            #0xd230d8
    // 0xd22df4: cmp             w3, NULL
    // 0xd22df8: b.eq            #0xd22e7c
    // 0xd22dfc: mov             x1, x3
    // 0xd22e00: r0 = findRenderObject()
    //     0xd22e00: bl              #0x8418fc  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0xd22e04: mov             x3, x0
    // 0xd22e08: stur            x3, [fp, #-0x10]
    // 0xd22e0c: cmp             w3, NULL
    // 0xd22e10: b.eq            #0xd230e0
    // 0xd22e14: mov             x0, x3
    // 0xd22e18: r2 = Null
    //     0xd22e18: mov             x2, NULL
    // 0xd22e1c: r1 = Null
    //     0xd22e1c: mov             x1, NULL
    // 0xd22e20: r4 = LoadClassIdInstr(r0)
    //     0xd22e20: ldur            x4, [x0, #-1]
    //     0xd22e24: ubfx            x4, x4, #0xc, #0x14
    // 0xd22e28: r17 = -4710
    //     0xd22e28: mov             x17, #-0x1266
    // 0xd22e2c: add             x4, x4, x17
    // 0xd22e30: cmp             x4, #0x109
    // 0xd22e34: b.ls            #0xd22e48
    // 0xd22e38: r8 = RenderBox
    //     0xd22e38: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xd22e3c: r3 = Null
    //     0xd22e3c: add             x3, PP, #0x99, lsl #12  ; [pp+0x99568] Null
    //     0xd22e40: ldr             x3, [x3, #0x568]
    // 0xd22e44: r0 = RenderBox()
    //     0xd22e44: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xd22e48: ldur            x1, [fp, #-0x10]
    // 0xd22e4c: r0 = size()
    //     0xd22e4c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xd22e50: mov             x2, x0
    // 0xd22e54: r1 = Instance_Offset
    //     0xd22e54: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xd22e58: r0 = &()
    //     0xd22e58: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xd22e5c: mov             x1, x0
    // 0xd22e60: r0 = center()
    //     0xd22e60: bl              #0x869350  ; [dart:ui] Rect::center
    // 0xd22e64: ldur            x1, [fp, #-0x10]
    // 0xd22e68: mov             x2, x0
    // 0xd22e6c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xd22e6c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xd22e70: r0 = localToGlobal()
    //     0xd22e70: bl              #0x856eb0  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0xd22e74: mov             x4, x0
    // 0xd22e78: b               #0xd22e88
    // 0xd22e7c: LoadField: r0 = r1->field_7
    //     0xd22e7c: ldur            w0, [x1, #7]
    // 0xd22e80: DecompressPointer r0
    //     0xd22e80: add             x0, x0, HEAP, lsl #32
    // 0xd22e84: mov             x4, x0
    // 0xd22e88: ldur            x0, [fp, #-8]
    // 0xd22e8c: stur            x4, [fp, #-0x10]
    // 0xd22e90: LoadField: r1 = r0->field_b
    //     0xd22e90: ldur            w1, [x0, #0xb]
    // 0xd22e94: DecompressPointer r1
    //     0xd22e94: add             x1, x1, HEAP, lsl #32
    // 0xd22e98: cmp             w1, NULL
    // 0xd22e9c: b.eq            #0xd230e4
    // 0xd22ea0: LoadField: r2 = r1->field_8f
    //     0xd22ea0: ldur            w2, [x1, #0x8f]
    // 0xd22ea4: DecompressPointer r2
    //     0xd22ea4: add             x2, x2, HEAP, lsl #32
    // 0xd22ea8: cmp             w2, NULL
    // 0xd22eac: b.ne            #0xd22ec4
    // 0xd22eb0: LoadField: r1 = r0->field_2b
    //     0xd22eb0: ldur            w1, [x0, #0x2b]
    // 0xd22eb4: DecompressPointer r1
    //     0xd22eb4: add             x1, x1, HEAP, lsl #32
    // 0xd22eb8: cmp             w1, NULL
    // 0xd22ebc: b.eq            #0xd230e8
    // 0xd22ec0: b               #0xd22ec8
    // 0xd22ec4: mov             x1, x2
    // 0xd22ec8: r2 = Instance_WidgetState
    //     0xd22ec8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd22ecc: ldr             x2, [x2, #0xa48]
    // 0xd22ed0: r3 = true
    //     0xd22ed0: add             x3, NULL, #0x20  ; true
    // 0xd22ed4: r0 = update()
    //     0xd22ed4: bl              #0xd223e0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::update
    // 0xd22ed8: ldur            x1, [fp, #-8]
    // 0xd22edc: ldur            x2, [fp, #-0x10]
    // 0xd22ee0: r0 = _createSplash()
    //     0xd22ee0: bl              #0xd23128  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::_createSplash
    // 0xd22ee4: mov             x2, x0
    // 0xd22ee8: ldur            x0, [fp, #-8]
    // 0xd22eec: stur            x2, [fp, #-0x10]
    // 0xd22ef0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd22ef0: ldur            w1, [x0, #0x17]
    // 0xd22ef4: DecompressPointer r1
    //     0xd22ef4: add             x1, x1, HEAP, lsl #32
    // 0xd22ef8: cmp             w1, NULL
    // 0xd22efc: b.ne            #0xd22f58
    // 0xd22f00: r1 = <InteractiveInkFeature>
    //     0xd22f00: add             x1, PP, #0x99, lsl #12  ; [pp+0x99578] TypeArguments: <InteractiveInkFeature>
    //     0xd22f04: ldr             x1, [x1, #0x578]
    // 0xd22f08: r0 = _HashSet()
    //     0xd22f08: bl              #0x89f6f0  ; Allocate_HashSetStub -> _HashSet<X0> (size=0x20)
    // 0xd22f0c: stur            x0, [fp, #-0x18]
    // 0xd22f10: StoreField: r0->field_f = rZR
    //     0xd22f10: stur            xzr, [x0, #0xf]
    // 0xd22f14: ArrayStore: r0[0] = rZR  ; List_8
    //     0xd22f14: stur            xzr, [x0, #0x17]
    // 0xd22f18: r1 = <_HashSetEntry<InteractiveInkFeature>?>
    //     0xd22f18: add             x1, PP, #0x99, lsl #12  ; [pp+0x99580] TypeArguments: <_HashSetEntry<InteractiveInkFeature>?>
    //     0xd22f1c: ldr             x1, [x1, #0x580]
    // 0xd22f20: r2 = 16
    //     0xd22f20: mov             x2, #0x10
    // 0xd22f24: r0 = AllocateArray()
    //     0xd22f24: bl              #0x13df928  ; AllocateArrayStub
    // 0xd22f28: ldur            x1, [fp, #-0x18]
    // 0xd22f2c: StoreField: r1->field_b = r0
    //     0xd22f2c: stur            w0, [x1, #0xb]
    // 0xd22f30: mov             x0, x1
    // 0xd22f34: ldur            x3, [fp, #-8]
    // 0xd22f38: ArrayStore: r3[0] = r0  ; List_4
    //     0xd22f38: stur            w0, [x3, #0x17]
    //     0xd22f3c: ldurb           w16, [x3, #-1]
    //     0xd22f40: ldurb           w17, [x0, #-1]
    //     0xd22f44: and             x16, x17, x16, lsr #2
    //     0xd22f48: tst             x16, HEAP, lsr #32
    //     0xd22f4c: b.eq            #0xd22f54
    //     0xd22f50: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd22f54: b               #0xd22f5c
    // 0xd22f58: mov             x3, x0
    // 0xd22f5c: ldur            x2, [fp, #-0x10]
    // 0xd22f60: r0 = add()
    //     0xd22f60: bl              #0x1259a30  ; [dart:collection] _HashSet::add
    // 0xd22f64: ldur            x0, [fp, #-8]
    // 0xd22f68: LoadField: r2 = r0->field_1b
    //     0xd22f68: ldur            w2, [x0, #0x1b]
    // 0xd22f6c: DecompressPointer r2
    //     0xd22f6c: add             x2, x2, HEAP, lsl #32
    // 0xd22f70: stur            x2, [fp, #-0x18]
    // 0xd22f74: cmp             w2, NULL
    // 0xd22f78: b.ne            #0xd22f84
    // 0xd22f7c: mov             x2, x0
    // 0xd22f80: b               #0xd23088
    // 0xd22f84: r1 = LoadClassIdInstr(r2)
    //     0xd22f84: ldur            x1, [x2, #-1]
    //     0xd22f88: ubfx            x1, x1, #0xc, #0x14
    // 0xd22f8c: cmp             x1, #0xbde
    // 0xd22f90: b.ne            #0xd22fb0
    // 0xd22f94: LoadField: r1 = r2->field_43
    //     0xd22f94: ldur            w1, [x2, #0x43]
    // 0xd22f98: DecompressPointer r1
    //     0xd22f98: add             x1, x1, HEAP, lsl #32
    // 0xd22f9c: cmp             w1, NULL
    // 0xd22fa0: b.eq            #0xd23084
    // 0xd22fa4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd22fa4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd22fa8: r0 = forward()
    //     0xd22fa8: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xd22fac: b               #0xd23084
    // 0xd22fb0: cmp             x1, #0xbdf
    // 0xd22fb4: b.eq            #0xd23084
    // 0xd22fb8: cmp             x1, #0xbe0
    // 0xd22fbc: b.ne            #0xd23084
    // 0xd22fc0: LoadField: r1 = r2->field_3f
    //     0xd22fc0: ldur            w1, [x2, #0x3f]
    // 0xd22fc4: DecompressPointer r1
    //     0xd22fc4: add             x1, x1, HEAP, lsl #32
    // 0xd22fc8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd22fcc: cmp             w1, w16
    // 0xd22fd0: b.eq            #0xd230ec
    // 0xd22fd4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd22fd4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd22fd8: r0 = stop()
    //     0xd22fd8: bl              #0x82eb24  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0xd22fdc: ldur            x0, [fp, #-0x18]
    // 0xd22fe0: LoadField: r1 = r0->field_3f
    //     0xd22fe0: ldur            w1, [x0, #0x3f]
    // 0xd22fe4: DecompressPointer r1
    //     0xd22fe4: add             x1, x1, HEAP, lsl #32
    // 0xd22fe8: LoadField: r2 = r1->field_37
    //     0xd22fe8: ldur            w2, [x1, #0x37]
    // 0xd22fec: DecompressPointer r2
    //     0xd22fec: add             x2, x2, HEAP, lsl #32
    // 0xd22ff0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd22ff4: cmp             w2, w16
    // 0xd22ff8: b.eq            #0xd230f8
    // 0xd22ffc: LoadField: d0 = r2->field_7
    //     0xd22ffc: ldur            d0, [x2, #7]
    // 0xd23000: d1 = 1.000000
    //     0xd23000: fmov            d1, #1.00000000
    // 0xd23004: fsub            d2, d1, d0
    // 0xd23008: stur            d2, [fp, #-0x20]
    // 0xd2300c: LoadField: r1 = r0->field_47
    //     0xd2300c: ldur            w1, [x0, #0x47]
    // 0xd23010: DecompressPointer r1
    //     0xd23010: add             x1, x1, HEAP, lsl #32
    // 0xd23014: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd23018: cmp             w1, w16
    // 0xd2301c: b.eq            #0xd23100
    // 0xd23020: r2 = inline_Allocate_Double()
    //     0xd23020: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xd23024: add             x2, x2, #0x10
    //     0xd23028: cmp             x3, x2
    //     0xd2302c: b.ls            #0xd2310c
    //     0xd23030: str             x2, [THR, #0x60]  ; THR::top
    //     0xd23034: sub             x2, x2, #0xf
    //     0xd23038: mov             x3, #0xe19c
    //     0xd2303c: movk            x3, #3, lsl #16
    //     0xd23040: stur            x3, [x2, #-1]
    // 0xd23044: dmb             ishst
    // 0xd23048: StoreField: r2->field_7 = d2
    //     0xd23048: stur            d2, [x2, #7]
    // 0xd2304c: r0 = value=()
    //     0xd2304c: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xd23050: ldur            d1, [fp, #-0x20]
    // 0xd23054: d0 = 1.000000
    //     0xd23054: fmov            d0, #1.00000000
    // 0xd23058: fcmp            d0, d1
    // 0xd2305c: b.le            #0xd23084
    // 0xd23060: ldur            x0, [fp, #-0x18]
    // 0xd23064: LoadField: r1 = r0->field_47
    //     0xd23064: ldur            w1, [x0, #0x47]
    // 0xd23068: DecompressPointer r1
    //     0xd23068: add             x1, x1, HEAP, lsl #32
    // 0xd2306c: r16 = Instance_Duration
    //     0xd2306c: add             x16, PP, #0x84, lsl #12  ; [pp+0x84f20] Obj!Duration@12c8a11
    //     0xd23070: ldr             x16, [x16, #0xf20]
    // 0xd23074: str             x16, [SP]
    // 0xd23078: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xd23078: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xd2307c: ldr             x4, [x4, #0x5a0]
    // 0xd23080: r0 = animateTo()
    //     0xd23080: bl              #0x866084  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateTo
    // 0xd23084: ldur            x2, [fp, #-8]
    // 0xd23088: ldur            x0, [fp, #-0x10]
    // 0xd2308c: StoreField: r2->field_1b = r0
    //     0xd2308c: stur            w0, [x2, #0x1b]
    //     0xd23090: ldurb           w16, [x2, #-1]
    //     0xd23094: ldurb           w17, [x0, #-1]
    //     0xd23098: and             x16, x17, x16, lsr #2
    //     0xd2309c: tst             x16, HEAP, lsr #32
    //     0xd230a0: b.eq            #0xd230a8
    //     0xd230a4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd230a8: mov             x1, x2
    // 0xd230ac: r0 = updateKeepAlive()
    //     0xd230ac: bl              #0xd21898  ; [dart:mixin_deduplication] _MixinApplication70&State&AutomaticKeepAliveClientMixin::updateKeepAlive
    // 0xd230b0: ldur            x1, [fp, #-8]
    // 0xd230b4: r2 = Instance__HighlightType
    //     0xd230b4: add             x2, PP, #0x99, lsl #12  ; [pp+0x994d0] Obj!_HighlightType@12c5741
    //     0xd230b8: ldr             x2, [x2, #0x4d0]
    // 0xd230bc: r3 = true
    //     0xd230bc: add             x3, NULL, #0x20  ; true
    // 0xd230c0: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xd230c0: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xd230c4: r0 = updateHighlight()
    //     0xd230c4: bl              #0xd21118  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::updateHighlight
    // 0xd230c8: r0 = Null
    //     0xd230c8: mov             x0, NULL
    // 0xd230cc: LeaveFrame
    //     0xd230cc: mov             SP, fp
    //     0xd230d0: ldp             fp, lr, [SP], #0x10
    // 0xd230d4: ret
    //     0xd230d4: ret             
    // 0xd230d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd230d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd230dc: b               #0xd22df4
    // 0xd230e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd230e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd230e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd230e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd230e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd230e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd230ec: r9 = _fadeInController
    //     0xd230ec: add             x9, PP, #0x99, lsl #12  ; [pp+0x99528] Field <InkRipple._fadeInController@755110234>: late (offset: 0x40)
    //     0xd230f0: ldr             x9, [x9, #0x528]
    // 0xd230f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd230f4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd230f8: r9 = _value
    //     0xd230f8: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xd230fc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd230fc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd23100: r9 = _fadeOutController
    //     0xd23100: add             x9, PP, #0x99, lsl #12  ; [pp+0x99530] Field <InkRipple._fadeOutController@755110234>: late (offset: 0x48)
    //     0xd23104: ldr             x9, [x9, #0x530]
    // 0xd23108: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xd23108: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xd2310c: stp             q1, q2, [SP, #-0x20]!
    // 0xd23110: stp             x0, x1, [SP, #-0x10]!
    // 0xd23114: r0 = AllocateDouble()
    //     0xd23114: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd23118: mov             x2, x0
    // 0xd2311c: ldp             x0, x1, [SP], #0x10
    // 0xd23120: ldp             q1, q2, [SP], #0x20
    // 0xd23124: b               #0xd23048
  }
  _ _createSplash(/* No info */) {
    // ** addr: 0xd23128, size: 0x44c
    // 0xd23128: EnterFrame
    //     0xd23128: stp             fp, lr, [SP, #-0x10]!
    //     0xd2312c: mov             fp, SP
    // 0xd23130: AllocStack(0x98)
    //     0xd23130: sub             SP, SP, #0x98
    // 0xd23134: SetupParameters(_InkResponseState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd23134: stur            x1, [fp, #-8]
    //     0xd23138: stur            x2, [fp, #-0x10]
    // 0xd2313c: CheckStackOverflow
    //     0xd2313c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd23140: cmp             SP, x16
    //     0xd23144: b.ls            #0xd23538
    // 0xd23148: r1 = 2
    //     0xd23148: mov             x1, #2
    // 0xd2314c: r0 = AllocateContext()
    //     0xd2314c: bl              #0x13de838  ; AllocateContextStub
    // 0xd23150: mov             x2, x0
    // 0xd23154: ldur            x0, [fp, #-8]
    // 0xd23158: stur            x2, [fp, #-0x18]
    // 0xd2315c: StoreField: r2->field_f = r0
    //     0xd2315c: stur            w0, [x2, #0xf]
    // 0xd23160: LoadField: r1 = r0->field_f
    //     0xd23160: ldur            w1, [x0, #0xf]
    // 0xd23164: DecompressPointer r1
    //     0xd23164: add             x1, x1, HEAP, lsl #32
    // 0xd23168: cmp             w1, NULL
    // 0xd2316c: b.eq            #0xd23540
    // 0xd23170: r0 = of()
    //     0xd23170: bl              #0xd21e38  ; [package:flutter/src/material/material.dart] Material::of
    // 0xd23174: mov             x2, x0
    // 0xd23178: ldur            x0, [fp, #-8]
    // 0xd2317c: stur            x2, [fp, #-0x20]
    // 0xd23180: LoadField: r1 = r0->field_f
    //     0xd23180: ldur            w1, [x0, #0xf]
    // 0xd23184: DecompressPointer r1
    //     0xd23184: add             x1, x1, HEAP, lsl #32
    // 0xd23188: cmp             w1, NULL
    // 0xd2318c: b.eq            #0xd23544
    // 0xd23190: r0 = renderObject()
    //     0xd23190: bl              #0x123f10c  ; [package:flutter/src/widgets/framework.dart] Element::renderObject
    // 0xd23194: mov             x3, x0
    // 0xd23198: stur            x3, [fp, #-0x28]
    // 0xd2319c: cmp             w3, NULL
    // 0xd231a0: b.eq            #0xd23548
    // 0xd231a4: mov             x0, x3
    // 0xd231a8: r2 = Null
    //     0xd231a8: mov             x2, NULL
    // 0xd231ac: r1 = Null
    //     0xd231ac: mov             x1, NULL
    // 0xd231b0: r4 = LoadClassIdInstr(r0)
    //     0xd231b0: ldur            x4, [x0, #-1]
    //     0xd231b4: ubfx            x4, x4, #0xc, #0x14
    // 0xd231b8: r17 = -4710
    //     0xd231b8: mov             x17, #-0x1266
    // 0xd231bc: add             x4, x4, x17
    // 0xd231c0: cmp             x4, #0x109
    // 0xd231c4: b.ls            #0xd231d8
    // 0xd231c8: r8 = RenderBox
    //     0xd231c8: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xd231cc: r3 = Null
    //     0xd231cc: add             x3, PP, #0x99, lsl #12  ; [pp+0x99588] Null
    //     0xd231d0: ldr             x3, [x3, #0x588]
    // 0xd231d4: r0 = RenderBox()
    //     0xd231d4: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xd231d8: ldur            x1, [fp, #-0x28]
    // 0xd231dc: ldur            x2, [fp, #-0x10]
    // 0xd231e0: r0 = globalToLocal()
    //     0xd231e0: bl              #0x867840  ; [package:flutter/src/rendering/box.dart] RenderBox::globalToLocal
    // 0xd231e4: mov             x4, x0
    // 0xd231e8: ldur            x3, [fp, #-8]
    // 0xd231ec: stur            x4, [fp, #-0x10]
    // 0xd231f0: LoadField: r0 = r3->field_b
    //     0xd231f0: ldur            w0, [x3, #0xb]
    // 0xd231f4: DecompressPointer r0
    //     0xd231f4: add             x0, x0, HEAP, lsl #32
    // 0xd231f8: cmp             w0, NULL
    // 0xd231fc: b.eq            #0xd2354c
    // 0xd23200: LoadField: r1 = r0->field_63
    //     0xd23200: ldur            w1, [x0, #0x63]
    // 0xd23204: DecompressPointer r1
    //     0xd23204: add             x1, x1, HEAP, lsl #32
    // 0xd23208: cmp             w1, NULL
    // 0xd2320c: b.ne            #0xd23218
    // 0xd23210: r0 = Null
    //     0xd23210: mov             x0, NULL
    // 0xd23214: b               #0xd23264
    // 0xd23218: LoadField: r2 = r0->field_8f
    //     0xd23218: ldur            w2, [x0, #0x8f]
    // 0xd2321c: DecompressPointer r2
    //     0xd2321c: add             x2, x2, HEAP, lsl #32
    // 0xd23220: cmp             w2, NULL
    // 0xd23224: b.ne            #0xd2323c
    // 0xd23228: LoadField: r0 = r3->field_2b
    //     0xd23228: ldur            w0, [x3, #0x2b]
    // 0xd2322c: DecompressPointer r0
    //     0xd2322c: add             x0, x0, HEAP, lsl #32
    // 0xd23230: cmp             w0, NULL
    // 0xd23234: b.eq            #0xd23550
    // 0xd23238: b               #0xd23240
    // 0xd2323c: mov             x0, x2
    // 0xd23240: LoadField: r2 = r0->field_27
    //     0xd23240: ldur            w2, [x0, #0x27]
    // 0xd23244: DecompressPointer r2
    //     0xd23244: add             x2, x2, HEAP, lsl #32
    // 0xd23248: r0 = LoadClassIdInstr(r1)
    //     0xd23248: ldur            x0, [x1, #-1]
    //     0xd2324c: ubfx            x0, x0, #0xc, #0x14
    // 0xd23250: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd23250: mov             x17, #0x7c77
    //     0xd23254: movk            x17, #1, lsl #16
    //     0xd23258: add             lr, x0, x17
    //     0xd2325c: ldr             lr, [x21, lr, lsl #3]
    //     0xd23260: blr             lr
    // 0xd23264: cmp             w0, NULL
    // 0xd23268: b.ne            #0xd23290
    // 0xd2326c: ldur            x2, [fp, #-8]
    // 0xd23270: LoadField: r0 = r2->field_b
    //     0xd23270: ldur            w0, [x2, #0xb]
    // 0xd23274: DecompressPointer r0
    //     0xd23274: add             x0, x0, HEAP, lsl #32
    // 0xd23278: cmp             w0, NULL
    // 0xd2327c: b.eq            #0xd23554
    // 0xd23280: LoadField: r1 = r0->field_67
    //     0xd23280: ldur            w1, [x0, #0x67]
    // 0xd23284: DecompressPointer r1
    //     0xd23284: add             x1, x1, HEAP, lsl #32
    // 0xd23288: mov             x0, x1
    // 0xd2328c: b               #0xd23294
    // 0xd23290: ldur            x2, [fp, #-8]
    // 0xd23294: cmp             w0, NULL
    // 0xd23298: b.ne            #0xd232c0
    // 0xd2329c: LoadField: r1 = r2->field_f
    //     0xd2329c: ldur            w1, [x2, #0xf]
    // 0xd232a0: DecompressPointer r1
    //     0xd232a0: add             x1, x1, HEAP, lsl #32
    // 0xd232a4: cmp             w1, NULL
    // 0xd232a8: b.eq            #0xd23558
    // 0xd232ac: r0 = of()
    //     0xd232ac: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd232b0: LoadField: r1 = r0->field_73
    //     0xd232b0: ldur            w1, [x0, #0x73]
    // 0xd232b4: DecompressPointer r1
    //     0xd232b4: add             x1, x1, HEAP, lsl #32
    // 0xd232b8: mov             x3, x1
    // 0xd232bc: b               #0xd232c4
    // 0xd232c0: mov             x3, x0
    // 0xd232c4: ldur            x1, [fp, #-8]
    // 0xd232c8: stur            x3, [fp, #-0x30]
    // 0xd232cc: LoadField: r0 = r1->field_b
    //     0xd232cc: ldur            w0, [x1, #0xb]
    // 0xd232d0: DecompressPointer r0
    //     0xd232d0: add             x0, x0, HEAP, lsl #32
    // 0xd232d4: cmp             w0, NULL
    // 0xd232d8: b.eq            #0xd2355c
    // 0xd232dc: LoadField: r2 = r0->field_43
    //     0xd232dc: ldur            w2, [x0, #0x43]
    // 0xd232e0: DecompressPointer r2
    //     0xd232e0: add             x2, x2, HEAP, lsl #32
    // 0xd232e4: tbnz            w2, #4, #0xd23318
    // 0xd232e8: LoadField: r2 = r0->field_8b
    //     0xd232e8: ldur            w2, [x0, #0x8b]
    // 0xd232ec: DecompressPointer r2
    //     0xd232ec: add             x2, x2, HEAP, lsl #32
    // 0xd232f0: cmp             w2, NULL
    // 0xd232f4: b.eq            #0xd23560
    // 0xd232f8: ldur            x16, [fp, #-0x28]
    // 0xd232fc: stp             x16, x2, [SP]
    // 0xd23300: mov             x0, x2
    // 0xd23304: ClosureCall
    //     0xd23304: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd23308: ldur            x2, [x0, #0x1f]
    //     0xd2330c: blr             x2
    // 0xd23310: mov             x4, x0
    // 0xd23314: b               #0xd2331c
    // 0xd23318: r4 = Null
    //     0xd23318: mov             x4, NULL
    // 0xd2331c: ldur            x0, [fp, #-8]
    // 0xd23320: ldur            x3, [fp, #-0x18]
    // 0xd23324: stur            x4, [fp, #-0x50]
    // 0xd23328: LoadField: r5 = r0->field_b
    //     0xd23328: ldur            w5, [x0, #0xb]
    // 0xd2332c: DecompressPointer r5
    //     0xd2332c: add             x5, x5, HEAP, lsl #32
    // 0xd23330: stur            x5, [fp, #-0x48]
    // 0xd23334: cmp             w5, NULL
    // 0xd23338: b.eq            #0xd23564
    // 0xd2333c: LoadField: r6 = r5->field_4f
    //     0xd2333c: ldur            w6, [x5, #0x4f]
    // 0xd23340: DecompressPointer r6
    //     0xd23340: add             x6, x6, HEAP, lsl #32
    // 0xd23344: stur            x6, [fp, #-0x40]
    // 0xd23348: LoadField: r7 = r5->field_53
    //     0xd23348: ldur            w7, [x5, #0x53]
    // 0xd2334c: DecompressPointer r7
    //     0xd2334c: add             x7, x7, HEAP, lsl #32
    // 0xd23350: stur            x7, [fp, #-0x38]
    // 0xd23354: StoreField: r3->field_13 = rNULL
    //     0xd23354: stur            NULL, [x3, #0x13]
    // 0xd23358: mov             x2, x3
    // 0xd2335c: r1 = Function 'onRemoved':.
    //     0xd2335c: add             x1, PP, #0x99, lsl #12  ; [pp+0x99598] AnonymousClosure: (0xd25af8), in [package:flutter/src/material/ink_well.dart] _InkResponseState::_createSplash (0xd23128)
    //     0xd23360: ldr             x1, [x1, #0x598]
    // 0xd23364: r0 = AllocateClosure()
    //     0xd23364: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd23368: mov             x2, x0
    // 0xd2336c: ldur            x0, [fp, #-0x48]
    // 0xd23370: stur            x2, [fp, #-0x58]
    // 0xd23374: LoadField: r1 = r0->field_6b
    //     0xd23374: ldur            w1, [x0, #0x6b]
    // 0xd23378: DecompressPointer r1
    //     0xd23378: add             x1, x1, HEAP, lsl #32
    // 0xd2337c: cmp             w1, NULL
    // 0xd23380: b.ne            #0xd233ac
    // 0xd23384: ldur            x0, [fp, #-8]
    // 0xd23388: LoadField: r1 = r0->field_f
    //     0xd23388: ldur            w1, [x0, #0xf]
    // 0xd2338c: DecompressPointer r1
    //     0xd2338c: add             x1, x1, HEAP, lsl #32
    // 0xd23390: cmp             w1, NULL
    // 0xd23394: b.eq            #0xd23568
    // 0xd23398: r0 = of()
    //     0xd23398: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd2339c: LoadField: r1 = r0->field_2b
    //     0xd2339c: ldur            w1, [x0, #0x2b]
    // 0xd233a0: DecompressPointer r1
    //     0xd233a0: add             x1, x1, HEAP, lsl #32
    // 0xd233a4: mov             x2, x1
    // 0xd233a8: b               #0xd233b0
    // 0xd233ac: mov             x2, x1
    // 0xd233b0: ldur            x0, [fp, #-8]
    // 0xd233b4: stur            x2, [fp, #-0x68]
    // 0xd233b8: LoadField: r1 = r0->field_b
    //     0xd233b8: ldur            w1, [x0, #0xb]
    // 0xd233bc: DecompressPointer r1
    //     0xd233bc: add             x1, x1, HEAP, lsl #32
    // 0xd233c0: cmp             w1, NULL
    // 0xd233c4: b.eq            #0xd2356c
    // 0xd233c8: LoadField: r5 = r1->field_43
    //     0xd233c8: ldur            w5, [x1, #0x43]
    // 0xd233cc: DecompressPointer r5
    //     0xd233cc: add             x5, x5, HEAP, lsl #32
    // 0xd233d0: stur            x5, [fp, #-0x60]
    // 0xd233d4: LoadField: r3 = r1->field_4b
    //     0xd233d4: ldur            w3, [x1, #0x4b]
    // 0xd233d8: DecompressPointer r3
    //     0xd233d8: add             x3, x3, HEAP, lsl #32
    // 0xd233dc: stur            x3, [fp, #-0x48]
    // 0xd233e0: LoadField: r1 = r0->field_f
    //     0xd233e0: ldur            w1, [x0, #0xf]
    // 0xd233e4: DecompressPointer r1
    //     0xd233e4: add             x1, x1, HEAP, lsl #32
    // 0xd233e8: cmp             w1, NULL
    // 0xd233ec: b.eq            #0xd23570
    // 0xd233f0: r0 = of()
    //     0xd233f0: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xd233f4: mov             x1, x0
    // 0xd233f8: ldur            x0, [fp, #-0x68]
    // 0xd233fc: stur            x1, [fp, #-8]
    // 0xd23400: r2 = LoadClassIdInstr(r0)
    //     0xd23400: ldur            x2, [x0, #-1]
    //     0xd23404: ubfx            x2, x2, #0xc, #0x14
    // 0xd23408: cmp             x2, #0xbd9
    // 0xd2340c: b.ne            #0xd23460
    // 0xd23410: r0 = InkSplash()
    //     0xd23410: bl              #0xd25aec  ; AllocateInkSplashStub -> InkSplash (size=0x48)
    // 0xd23414: stur            x0, [fp, #-0x68]
    // 0xd23418: ldur            x16, [fp, #-0x58]
    // 0xd2341c: ldur            lr, [fp, #-0x10]
    // 0xd23420: stp             lr, x16, [SP, #0x20]
    // 0xd23424: ldur            x16, [fp, #-0x48]
    // 0xd23428: ldur            lr, [fp, #-0x50]
    // 0xd2342c: stp             lr, x16, [SP, #0x10]
    // 0xd23430: ldur            x16, [fp, #-0x28]
    // 0xd23434: ldur            lr, [fp, #-8]
    // 0xd23438: stp             lr, x16, [SP]
    // 0xd2343c: mov             x1, x0
    // 0xd23440: ldur            x2, [fp, #-0x40]
    // 0xd23444: ldur            x3, [fp, #-0x30]
    // 0xd23448: ldur            x5, [fp, #-0x60]
    // 0xd2344c: ldur            x6, [fp, #-0x20]
    // 0xd23450: ldur            x7, [fp, #-0x38]
    // 0xd23454: r0 = InkSplash()
    //     0xd23454: bl              #0xd2546c  ; [package:flutter/src/material/ink_splash.dart] InkSplash::InkSplash
    // 0xd23458: ldur            x2, [fp, #-0x68]
    // 0xd2345c: b               #0xd23504
    // 0xd23460: cmp             x2, #0xbda
    // 0xd23464: b.ne            #0xd234b8
    // 0xd23468: r0 = InkSparkle()
    //     0xd23468: bl              #0xd25460  ; AllocateInkSparkleStub -> InkSparkle (size=0x58)
    // 0xd2346c: stur            x0, [fp, #-0x68]
    // 0xd23470: ldur            x16, [fp, #-0x58]
    // 0xd23474: ldur            lr, [fp, #-0x10]
    // 0xd23478: stp             lr, x16, [SP, #0x20]
    // 0xd2347c: ldur            x16, [fp, #-0x48]
    // 0xd23480: ldur            lr, [fp, #-0x50]
    // 0xd23484: stp             lr, x16, [SP, #0x10]
    // 0xd23488: ldur            x16, [fp, #-0x28]
    // 0xd2348c: ldur            lr, [fp, #-8]
    // 0xd23490: stp             lr, x16, [SP]
    // 0xd23494: mov             x1, x0
    // 0xd23498: ldur            x2, [fp, #-0x40]
    // 0xd2349c: ldur            x3, [fp, #-0x30]
    // 0xd234a0: ldur            x5, [fp, #-0x60]
    // 0xd234a4: ldur            x6, [fp, #-0x20]
    // 0xd234a8: ldur            x7, [fp, #-0x38]
    // 0xd234ac: r0 = InkSparkle()
    //     0xd234ac: bl              #0xd23dc8  ; [package:flutter/src/material/ink_sparkle.dart] InkSparkle::InkSparkle
    // 0xd234b0: ldur            x2, [fp, #-0x68]
    // 0xd234b4: b               #0xd23504
    // 0xd234b8: r0 = InkRipple()
    //     0xd234b8: bl              #0xd23dbc  ; AllocateInkRippleStub -> InkRipple (size=0x4c)
    // 0xd234bc: stur            x0, [fp, #-0x68]
    // 0xd234c0: ldur            x16, [fp, #-0x58]
    // 0xd234c4: ldur            lr, [fp, #-0x10]
    // 0xd234c8: stp             lr, x16, [SP, #0x20]
    // 0xd234cc: ldur            x16, [fp, #-0x48]
    // 0xd234d0: ldur            lr, [fp, #-0x50]
    // 0xd234d4: stp             lr, x16, [SP, #0x10]
    // 0xd234d8: ldur            x16, [fp, #-0x28]
    // 0xd234dc: ldur            lr, [fp, #-8]
    // 0xd234e0: stp             lr, x16, [SP]
    // 0xd234e4: mov             x1, x0
    // 0xd234e8: ldur            x2, [fp, #-0x40]
    // 0xd234ec: ldur            x3, [fp, #-0x30]
    // 0xd234f0: ldur            x5, [fp, #-0x60]
    // 0xd234f4: ldur            x6, [fp, #-0x20]
    // 0xd234f8: ldur            x7, [fp, #-0x38]
    // 0xd234fc: r0 = InkRipple()
    //     0xd234fc: bl              #0xd23574  ; [package:flutter/src/material/ink_ripple.dart] InkRipple::InkRipple
    // 0xd23500: ldur            x2, [fp, #-0x68]
    // 0xd23504: ldur            x1, [fp, #-0x18]
    // 0xd23508: mov             x0, x2
    // 0xd2350c: StoreField: r1->field_13 = r0
    //     0xd2350c: stur            w0, [x1, #0x13]
    //     0xd23510: ldurb           w16, [x1, #-1]
    //     0xd23514: ldurb           w17, [x0, #-1]
    //     0xd23518: and             x16, x17, x16, lsr #2
    //     0xd2351c: tst             x16, HEAP, lsr #32
    //     0xd23520: b.eq            #0xd23528
    //     0xd23524: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd23528: mov             x0, x2
    // 0xd2352c: LeaveFrame
    //     0xd2352c: mov             SP, fp
    //     0xd23530: ldp             fp, lr, [SP], #0x10
    // 0xd23534: ret
    //     0xd23534: ret             
    // 0xd23538: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd23538: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd2353c: b               #0xd23148
    // 0xd23540: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd23540: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd23544: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd23544: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd23548: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd23548: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2354c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2354c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd23550: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd23550: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd23554: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd23554: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd23558: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd23558: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2355c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2355c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd23560: r0 = NullErrorSharedWithoutFPURegs()
    //     0xd23560: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xd23564: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd23564: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd23568: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd23568: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd2356c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd2356c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd23570: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd23570: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void onRemoved(dynamic) {
    // ** addr: 0xd25af8, size: 0xc4
    // 0xd25af8: EnterFrame
    //     0xd25af8: stp             fp, lr, [SP, #-0x10]!
    //     0xd25afc: mov             fp, SP
    // 0xd25b00: AllocStack(0x18)
    //     0xd25b00: sub             SP, SP, #0x18
    // 0xd25b04: SetupParameters([dynamic _ /* r0 */])
    //     0xd25b04: ldr             x0, [fp, #0x10]
    //     0xd25b08: ldur            w3, [x0, #0x17]
    //     0xd25b0c: add             x3, x3, HEAP, lsl #32
    //     0xd25b10: stur            x3, [fp, #-8]
    // 0xd25b14: CheckStackOverflow
    //     0xd25b14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd25b18: cmp             SP, x16
    //     0xd25b1c: b.ls            #0xd25bb4
    // 0xd25b20: LoadField: r0 = r3->field_f
    //     0xd25b20: ldur            w0, [x3, #0xf]
    // 0xd25b24: DecompressPointer r0
    //     0xd25b24: add             x0, x0, HEAP, lsl #32
    // 0xd25b28: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd25b28: ldur            w1, [x0, #0x17]
    // 0xd25b2c: DecompressPointer r1
    //     0xd25b2c: add             x1, x1, HEAP, lsl #32
    // 0xd25b30: cmp             w1, NULL
    // 0xd25b34: b.eq            #0xd25ba4
    // 0xd25b38: LoadField: r2 = r3->field_13
    //     0xd25b38: ldur            w2, [x3, #0x13]
    // 0xd25b3c: DecompressPointer r2
    //     0xd25b3c: add             x2, x2, HEAP, lsl #32
    // 0xd25b40: r0 = remove()
    //     0xd25b40: bl              #0x1148f1c  ; [dart:collection] _HashSet::remove
    // 0xd25b44: ldur            x1, [fp, #-8]
    // 0xd25b48: LoadField: r0 = r1->field_f
    //     0xd25b48: ldur            w0, [x1, #0xf]
    // 0xd25b4c: DecompressPointer r0
    //     0xd25b4c: add             x0, x0, HEAP, lsl #32
    // 0xd25b50: LoadField: r2 = r0->field_1b
    //     0xd25b50: ldur            w2, [x0, #0x1b]
    // 0xd25b54: DecompressPointer r2
    //     0xd25b54: add             x2, x2, HEAP, lsl #32
    // 0xd25b58: LoadField: r0 = r1->field_13
    //     0xd25b58: ldur            w0, [x1, #0x13]
    // 0xd25b5c: DecompressPointer r0
    //     0xd25b5c: add             x0, x0, HEAP, lsl #32
    // 0xd25b60: r3 = LoadClassIdInstr(r2)
    //     0xd25b60: ldur            x3, [x2, #-1]
    //     0xd25b64: ubfx            x3, x3, #0xc, #0x14
    // 0xd25b68: stp             x0, x2, [SP]
    // 0xd25b6c: mov             x0, x3
    // 0xd25b70: mov             lr, x0
    // 0xd25b74: ldr             lr, [x21, lr, lsl #3]
    // 0xd25b78: blr             lr
    // 0xd25b7c: tbnz            w0, #4, #0xd25b94
    // 0xd25b80: ldur            x0, [fp, #-8]
    // 0xd25b84: LoadField: r1 = r0->field_f
    //     0xd25b84: ldur            w1, [x0, #0xf]
    // 0xd25b88: DecompressPointer r1
    //     0xd25b88: add             x1, x1, HEAP, lsl #32
    // 0xd25b8c: StoreField: r1->field_1b = rNULL
    //     0xd25b8c: stur            NULL, [x1, #0x1b]
    // 0xd25b90: b               #0xd25b98
    // 0xd25b94: ldur            x0, [fp, #-8]
    // 0xd25b98: LoadField: r1 = r0->field_f
    //     0xd25b98: ldur            w1, [x0, #0xf]
    // 0xd25b9c: DecompressPointer r1
    //     0xd25b9c: add             x1, x1, HEAP, lsl #32
    // 0xd25ba0: r0 = updateKeepAlive()
    //     0xd25ba0: bl              #0xd21898  ; [dart:mixin_deduplication] _MixinApplication70&State&AutomaticKeepAliveClientMixin::updateKeepAlive
    // 0xd25ba4: r0 = Null
    //     0xd25ba4: mov             x0, NULL
    // 0xd25ba8: LeaveFrame
    //     0xd25ba8: mov             SP, fp
    //     0xd25bac: ldp             fp, lr, [SP], #0x10
    // 0xd25bb0: ret
    //     0xd25bb0: ret             
    // 0xd25bb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd25bb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd25bb8: b               #0xd25b20
  }
  [closure] void simulateTap(dynamic, [Intent?]) {
    // ** addr: 0xd25c44, size: 0x70
    // 0xd25c44: EnterFrame
    //     0xd25c44: stp             fp, lr, [SP, #-0x10]!
    //     0xd25c48: mov             fp, SP
    // 0xd25c4c: AllocStack(0x8)
    //     0xd25c4c: sub             SP, SP, #8
    // 0xd25c50: SetupParameters(_InkResponseState this /* r0 */, [dynamic _ = Null /* r1 */])
    //     0xd25c50: ldur            w0, [x4, #0x13]
    //     0xd25c54: sub             x1, x0, #2
    //     0xd25c58: add             x0, fp, w1, sxtw #2
    //     0xd25c5c: ldr             x0, [x0, #0x10]
    //     0xd25c60: cmp             w1, #2
    //     0xd25c64: b.lt            #0xd25c78
    //     0xd25c68: add             x2, fp, w1, sxtw #2
    //     0xd25c6c: ldr             x2, [x2, #8]
    //     0xd25c70: mov             x1, x2
    //     0xd25c74: b               #0xd25c7c
    //     0xd25c78: mov             x1, NULL
    //     0xd25c7c: ldur            w2, [x0, #0x17]
    //     0xd25c80: add             x2, x2, HEAP, lsl #32
    // 0xd25c84: CheckStackOverflow
    //     0xd25c84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd25c88: cmp             SP, x16
    //     0xd25c8c: b.ls            #0xd25cac
    // 0xd25c90: str             x1, [SP]
    // 0xd25c94: mov             x1, x2
    // 0xd25c98: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xd25c98: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xd25c9c: r0 = simulateTap()
    //     0xd25c9c: bl              #0xd25cb4  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::simulateTap
    // 0xd25ca0: LeaveFrame
    //     0xd25ca0: mov             SP, fp
    //     0xd25ca4: ldp             fp, lr, [SP], #0x10
    // 0xd25ca8: ret
    //     0xd25ca8: ret             
    // 0xd25cac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd25cac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd25cb0: b               #0xd25c90
  }
  _ simulateTap(/* No info */) {
    // ** addr: 0xd25cb4, size: 0x68
    // 0xd25cb4: EnterFrame
    //     0xd25cb4: stp             fp, lr, [SP, #-0x10]!
    //     0xd25cb8: mov             fp, SP
    // 0xd25cbc: AllocStack(0x10)
    //     0xd25cbc: sub             SP, SP, #0x10
    // 0xd25cc0: SetupParameters(_InkResponseState this /* r1 => r0, fp-0x8 */)
    //     0xd25cc0: mov             x0, x1
    //     0xd25cc4: stur            x1, [fp, #-8]
    // 0xd25cc8: CheckStackOverflow
    //     0xd25cc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd25ccc: cmp             SP, x16
    //     0xd25cd0: b.ls            #0xd25d10
    // 0xd25cd4: LoadField: r1 = r0->field_f
    //     0xd25cd4: ldur            w1, [x0, #0xf]
    // 0xd25cd8: DecompressPointer r1
    //     0xd25cd8: add             x1, x1, HEAP, lsl #32
    // 0xd25cdc: cmp             w1, NULL
    // 0xd25ce0: b.eq            #0xd25d18
    // 0xd25ce4: str             x1, [SP]
    // 0xd25ce8: mov             x1, x0
    // 0xd25cec: r4 = const [0, 0x2, 0x1, 0x1, context, 0x1, null]
    //     0xd25cec: add             x4, PP, #0x92, lsl #12  ; [pp+0x92418] List(7) [0, 0x2, 0x1, 0x1, "context", 0x1, Null]
    //     0xd25cf0: ldr             x4, [x4, #0x418]
    // 0xd25cf4: r0 = _startNewSplash()
    //     0xd25cf4: bl              #0xd22d48  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::_startNewSplash
    // 0xd25cf8: ldur            x1, [fp, #-8]
    // 0xd25cfc: r0 = handleTap()
    //     0xd25cfc: bl              #0xd227fc  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleTap
    // 0xd25d00: r0 = Null
    //     0xd25d00: mov             x0, NULL
    // 0xd25d04: LeaveFrame
    //     0xd25d04: mov             SP, fp
    //     0xd25d08: ldp             fp, lr, [SP], #0x10
    // 0xd25d0c: ret
    //     0xd25d0c: ret             
    // 0xd25d10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd25d10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd25d14: b               #0xd25cd4
    // 0xd25d18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd25d18: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  Map<Type, Action<Intent>> _actionMap(_InkResponseState) {
    // ** addr: 0xd25d1c, size: 0x244
    // 0xd25d1c: EnterFrame
    //     0xd25d1c: stp             fp, lr, [SP, #-0x10]!
    //     0xd25d20: mov             fp, SP
    // 0xd25d24: AllocStack(0x28)
    //     0xd25d24: sub             SP, SP, #0x28
    // 0xd25d28: CheckStackOverflow
    //     0xd25d28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd25d2c: cmp             SP, x16
    //     0xd25d30: b.ls            #0xd25f58
    // 0xd25d34: r1 = Null
    //     0xd25d34: mov             x1, NULL
    // 0xd25d38: r2 = 8
    //     0xd25d38: mov             x2, #8
    // 0xd25d3c: r0 = AllocateArray()
    //     0xd25d3c: bl              #0x13df928  ; AllocateArrayStub
    // 0xd25d40: mov             x1, x0
    // 0xd25d44: stur            x1, [fp, #-8]
    // 0xd25d48: r16 = ActivateIntent
    //     0xd25d48: add             x16, PP, #0x90, lsl #12  ; [pp+0x904d0] Type: ActivateIntent
    //     0xd25d4c: ldr             x16, [x16, #0x4d0]
    // 0xd25d50: StoreField: r1->field_f = r16
    //     0xd25d50: stur            w16, [x1, #0xf]
    // 0xd25d54: ldr             x2, [fp, #0x10]
    // 0xd25d58: r0 = 60
    //     0xd25d58: mov             x0, #0x3c
    // 0xd25d5c: branchIfSmi(r2, 0xd25d68)
    //     0xd25d5c: tbz             w2, #0, #0xd25d68
    // 0xd25d60: r0 = LoadClassIdInstr(r2)
    //     0xd25d60: ldur            x0, [x2, #-1]
    //     0xd25d64: ubfx            x0, x0, #0xc, #0x14
    // 0xd25d68: str             x2, [SP]
    // 0xd25d6c: r0 = GDT[cid_x0 + -0xefd]()
    //     0xd25d6c: sub             lr, x0, #0xefd
    //     0xd25d70: ldr             lr, [x21, lr, lsl #3]
    //     0xd25d74: blr             lr
    // 0xd25d78: r1 = <ActivateIntent>
    //     0xd25d78: add             x1, PP, #0x90, lsl #12  ; [pp+0x904d8] TypeArguments: <ActivateIntent>
    //     0xd25d7c: ldr             x1, [x1, #0x4d8]
    // 0xd25d80: stur            x0, [fp, #-0x10]
    // 0xd25d84: r0 = CallbackAction()
    //     0xd25d84: bl              #0xd126e8  ; AllocateCallbackActionStub -> CallbackAction<X0 bound Intent> (size=0x18)
    // 0xd25d88: mov             x2, x0
    // 0xd25d8c: ldur            x0, [fp, #-0x10]
    // 0xd25d90: stur            x2, [fp, #-0x18]
    // 0xd25d94: StoreField: r2->field_13 = r0
    //     0xd25d94: stur            w0, [x2, #0x13]
    // 0xd25d98: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd25d98: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd25d9c: ldr             x1, [x1, #0x7a0]
    // 0xd25da0: r0 = ObserverList()
    //     0xd25da0: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xd25da4: mov             x3, x0
    // 0xd25da8: r0 = false
    //     0xd25da8: add             x0, NULL, #0x30  ; false
    // 0xd25dac: stur            x3, [fp, #-0x10]
    // 0xd25db0: StoreField: r3->field_f = r0
    //     0xd25db0: stur            w0, [x3, #0xf]
    // 0xd25db4: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0xd25db8: StoreField: r3->field_13 = r4
    //     0xd25db8: stur            w4, [x3, #0x13]
    // 0xd25dbc: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd25dbc: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd25dc0: ldr             x1, [x1, #0x7a0]
    // 0xd25dc4: r2 = 0
    //     0xd25dc4: mov             x2, #0
    // 0xd25dc8: r0 = _GrowableList()
    //     0xd25dc8: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd25dcc: ldur            x1, [fp, #-0x10]
    // 0xd25dd0: StoreField: r1->field_b = r0
    //     0xd25dd0: stur            w0, [x1, #0xb]
    //     0xd25dd4: ldurb           w16, [x1, #-1]
    //     0xd25dd8: ldurb           w17, [x0, #-1]
    //     0xd25ddc: and             x16, x17, x16, lsr #2
    //     0xd25de0: tst             x16, HEAP, lsr #32
    //     0xd25de4: b.eq            #0xd25dec
    //     0xd25de8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd25dec: mov             x0, x1
    // 0xd25df0: ldur            x1, [fp, #-0x18]
    // 0xd25df4: StoreField: r1->field_b = r0
    //     0xd25df4: stur            w0, [x1, #0xb]
    //     0xd25df8: ldurb           w16, [x1, #-1]
    //     0xd25dfc: ldurb           w17, [x0, #-1]
    //     0xd25e00: and             x16, x17, x16, lsr #2
    //     0xd25e04: tst             x16, HEAP, lsr #32
    //     0xd25e08: b.eq            #0xd25e10
    //     0xd25e0c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd25e10: mov             x0, x1
    // 0xd25e14: ldur            x1, [fp, #-8]
    // 0xd25e18: ArrayStore: r1[1] = r0  ; List_4
    //     0xd25e18: add             x25, x1, #0x13
    //     0xd25e1c: str             w0, [x25]
    //     0xd25e20: tbz             w0, #0, #0xd25e3c
    //     0xd25e24: ldurb           w16, [x1, #-1]
    //     0xd25e28: ldurb           w17, [x0, #-1]
    //     0xd25e2c: and             x16, x17, x16, lsr #2
    //     0xd25e30: tst             x16, HEAP, lsr #32
    //     0xd25e34: b.eq            #0xd25e3c
    //     0xd25e38: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd25e3c: ldur            x1, [fp, #-8]
    // 0xd25e40: r16 = ButtonActivateIntent
    //     0xd25e40: add             x16, PP, #0x99, lsl #12  ; [pp+0x99658] Type: ButtonActivateIntent
    //     0xd25e44: ldr             x16, [x16, #0x658]
    // 0xd25e48: ArrayStore: r1[0] = r16  ; List_4
    //     0xd25e48: stur            w16, [x1, #0x17]
    // 0xd25e4c: ldr             x0, [fp, #0x10]
    // 0xd25e50: r2 = 60
    //     0xd25e50: mov             x2, #0x3c
    // 0xd25e54: branchIfSmi(r0, 0xd25e60)
    //     0xd25e54: tbz             w0, #0, #0xd25e60
    // 0xd25e58: r2 = LoadClassIdInstr(r0)
    //     0xd25e58: ldur            x2, [x0, #-1]
    //     0xd25e5c: ubfx            x2, x2, #0xc, #0x14
    // 0xd25e60: str             x0, [SP]
    // 0xd25e64: mov             x0, x2
    // 0xd25e68: r0 = GDT[cid_x0 + -0xefd]()
    //     0xd25e68: sub             lr, x0, #0xefd
    //     0xd25e6c: ldr             lr, [x21, lr, lsl #3]
    //     0xd25e70: blr             lr
    // 0xd25e74: r1 = <ButtonActivateIntent>
    //     0xd25e74: add             x1, PP, #0x99, lsl #12  ; [pp+0x99660] TypeArguments: <ButtonActivateIntent>
    //     0xd25e78: ldr             x1, [x1, #0x660]
    // 0xd25e7c: stur            x0, [fp, #-0x10]
    // 0xd25e80: r0 = CallbackAction()
    //     0xd25e80: bl              #0xd126e8  ; AllocateCallbackActionStub -> CallbackAction<X0 bound Intent> (size=0x18)
    // 0xd25e84: mov             x2, x0
    // 0xd25e88: ldur            x0, [fp, #-0x10]
    // 0xd25e8c: stur            x2, [fp, #-0x18]
    // 0xd25e90: StoreField: r2->field_13 = r0
    //     0xd25e90: stur            w0, [x2, #0x13]
    // 0xd25e94: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd25e94: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd25e98: ldr             x1, [x1, #0x7a0]
    // 0xd25e9c: r0 = ObserverList()
    //     0xd25e9c: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xd25ea0: mov             x3, x0
    // 0xd25ea4: r0 = false
    //     0xd25ea4: add             x0, NULL, #0x30  ; false
    // 0xd25ea8: stur            x3, [fp, #-0x10]
    // 0xd25eac: StoreField: r3->field_f = r0
    //     0xd25eac: stur            w0, [x3, #0xf]
    // 0xd25eb0: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd25eb4: StoreField: r3->field_13 = r0
    //     0xd25eb4: stur            w0, [x3, #0x13]
    // 0xd25eb8: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd25eb8: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd25ebc: ldr             x1, [x1, #0x7a0]
    // 0xd25ec0: r2 = 0
    //     0xd25ec0: mov             x2, #0
    // 0xd25ec4: r0 = _GrowableList()
    //     0xd25ec4: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd25ec8: ldur            x1, [fp, #-0x10]
    // 0xd25ecc: StoreField: r1->field_b = r0
    //     0xd25ecc: stur            w0, [x1, #0xb]
    //     0xd25ed0: ldurb           w16, [x1, #-1]
    //     0xd25ed4: ldurb           w17, [x0, #-1]
    //     0xd25ed8: and             x16, x17, x16, lsr #2
    //     0xd25edc: tst             x16, HEAP, lsr #32
    //     0xd25ee0: b.eq            #0xd25ee8
    //     0xd25ee4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd25ee8: mov             x0, x1
    // 0xd25eec: ldur            x1, [fp, #-0x18]
    // 0xd25ef0: StoreField: r1->field_b = r0
    //     0xd25ef0: stur            w0, [x1, #0xb]
    //     0xd25ef4: ldurb           w16, [x1, #-1]
    //     0xd25ef8: ldurb           w17, [x0, #-1]
    //     0xd25efc: and             x16, x17, x16, lsr #2
    //     0xd25f00: tst             x16, HEAP, lsr #32
    //     0xd25f04: b.eq            #0xd25f0c
    //     0xd25f08: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd25f0c: mov             x0, x1
    // 0xd25f10: ldur            x1, [fp, #-8]
    // 0xd25f14: ArrayStore: r1[3] = r0  ; List_4
    //     0xd25f14: add             x25, x1, #0x1b
    //     0xd25f18: str             w0, [x25]
    //     0xd25f1c: tbz             w0, #0, #0xd25f38
    //     0xd25f20: ldurb           w16, [x1, #-1]
    //     0xd25f24: ldurb           w17, [x0, #-1]
    //     0xd25f28: and             x16, x17, x16, lsr #2
    //     0xd25f2c: tst             x16, HEAP, lsr #32
    //     0xd25f30: b.eq            #0xd25f38
    //     0xd25f34: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd25f38: r16 = <Type, Action<Intent>>
    //     0xd25f38: add             x16, PP, #0x84, lsl #12  ; [pp+0x84b80] TypeArguments: <Type, Action<Intent>>
    //     0xd25f3c: ldr             x16, [x16, #0xb80]
    // 0xd25f40: ldur            lr, [fp, #-8]
    // 0xd25f44: stp             lr, x16, [SP]
    // 0xd25f48: r0 = Map._fromLiteral()
    //     0xd25f48: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xd25f4c: LeaveFrame
    //     0xd25f4c: mov             SP, fp
    //     0xd25f50: ldp             fp, lr, [SP], #0x10
    // 0xd25f54: ret
    //     0xd25f54: ret             
    // 0xd25f58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd25f58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd25f5c: b               #0xd25d34
  }
  [closure] Color getHighlightColorForType(dynamic, _HighlightType) {
    // ** addr: 0xd25f7c, size: 0x290
    // 0xd25f7c: EnterFrame
    //     0xd25f7c: stp             fp, lr, [SP, #-0x10]!
    //     0xd25f80: mov             fp, SP
    // 0xd25f84: AllocStack(0x8)
    //     0xd25f84: sub             SP, SP, #8
    // 0xd25f88: SetupParameters([dynamic _ /* r0 */])
    //     0xd25f88: ldr             x0, [fp, #0x18]
    //     0xd25f8c: ldur            w3, [x0, #0x17]
    //     0xd25f90: add             x3, x3, HEAP, lsl #32
    //     0xd25f94: stur            x3, [fp, #-8]
    // 0xd25f98: CheckStackOverflow
    //     0xd25f98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd25f9c: cmp             SP, x16
    //     0xd25fa0: b.ls            #0xd261ec
    // 0xd25fa4: ldr             x0, [fp, #0x10]
    // 0xd25fa8: LoadField: r1 = r0->field_7
    //     0xd25fa8: ldur            x1, [x0, #7]
    // 0xd25fac: cmp             x1, #1
    // 0xd25fb0: b.gt            #0xd26124
    // 0xd25fb4: cmp             x1, #0
    // 0xd25fb8: b.gt            #0xd26070
    // 0xd25fbc: LoadField: r0 = r3->field_f
    //     0xd25fbc: ldur            w0, [x3, #0xf]
    // 0xd25fc0: DecompressPointer r0
    //     0xd25fc0: add             x0, x0, HEAP, lsl #32
    // 0xd25fc4: LoadField: r1 = r0->field_b
    //     0xd25fc4: ldur            w1, [x0, #0xb]
    // 0xd25fc8: DecompressPointer r1
    //     0xd25fc8: add             x1, x1, HEAP, lsl #32
    // 0xd25fcc: cmp             w1, NULL
    // 0xd25fd0: b.eq            #0xd261f4
    // 0xd25fd4: LoadField: r0 = r1->field_63
    //     0xd25fd4: ldur            w0, [x1, #0x63]
    // 0xd25fd8: DecompressPointer r0
    //     0xd25fd8: add             x0, x0, HEAP, lsl #32
    // 0xd25fdc: cmp             w0, NULL
    // 0xd25fe0: b.ne            #0xd25fec
    // 0xd25fe4: r0 = Null
    //     0xd25fe4: mov             x0, NULL
    // 0xd25fe8: b               #0xd2601c
    // 0xd25fec: ArrayLoad: r2 = r3[0]  ; List_4
    //     0xd25fec: ldur            w2, [x3, #0x17]
    // 0xd25ff0: DecompressPointer r2
    //     0xd25ff0: add             x2, x2, HEAP, lsl #32
    // 0xd25ff4: r1 = LoadClassIdInstr(r0)
    //     0xd25ff4: ldur            x1, [x0, #-1]
    //     0xd25ff8: ubfx            x1, x1, #0xc, #0x14
    // 0xd25ffc: mov             x16, x0
    // 0xd26000: mov             x0, x1
    // 0xd26004: mov             x1, x16
    // 0xd26008: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd26008: mov             x17, #0x7c77
    //     0xd2600c: movk            x17, #1, lsl #16
    //     0xd26010: add             lr, x0, x17
    //     0xd26014: ldr             lr, [x21, lr, lsl #3]
    //     0xd26018: blr             lr
    // 0xd2601c: cmp             w0, NULL
    // 0xd26020: b.ne            #0xd2604c
    // 0xd26024: ldur            x3, [fp, #-8]
    // 0xd26028: LoadField: r0 = r3->field_f
    //     0xd26028: ldur            w0, [x3, #0xf]
    // 0xd2602c: DecompressPointer r0
    //     0xd2602c: add             x0, x0, HEAP, lsl #32
    // 0xd26030: LoadField: r1 = r0->field_b
    //     0xd26030: ldur            w1, [x0, #0xb]
    // 0xd26034: DecompressPointer r1
    //     0xd26034: add             x1, x1, HEAP, lsl #32
    // 0xd26038: cmp             w1, NULL
    // 0xd2603c: b.eq            #0xd261f8
    // 0xd26040: LoadField: r0 = r1->field_5f
    //     0xd26040: ldur            w0, [x1, #0x5f]
    // 0xd26044: DecompressPointer r0
    //     0xd26044: add             x0, x0, HEAP, lsl #32
    // 0xd26048: b               #0xd26050
    // 0xd2604c: ldur            x3, [fp, #-8]
    // 0xd26050: cmp             w0, NULL
    // 0xd26054: b.ne            #0xd261e0
    // 0xd26058: LoadField: r0 = r3->field_13
    //     0xd26058: ldur            w0, [x3, #0x13]
    // 0xd2605c: DecompressPointer r0
    //     0xd2605c: add             x0, x0, HEAP, lsl #32
    // 0xd26060: LoadField: r1 = r0->field_4f
    //     0xd26060: ldur            w1, [x0, #0x4f]
    // 0xd26064: DecompressPointer r1
    //     0xd26064: add             x1, x1, HEAP, lsl #32
    // 0xd26068: mov             x0, x1
    // 0xd2606c: b               #0xd261e0
    // 0xd26070: LoadField: r0 = r3->field_f
    //     0xd26070: ldur            w0, [x3, #0xf]
    // 0xd26074: DecompressPointer r0
    //     0xd26074: add             x0, x0, HEAP, lsl #32
    // 0xd26078: LoadField: r1 = r0->field_b
    //     0xd26078: ldur            w1, [x0, #0xb]
    // 0xd2607c: DecompressPointer r1
    //     0xd2607c: add             x1, x1, HEAP, lsl #32
    // 0xd26080: cmp             w1, NULL
    // 0xd26084: b.eq            #0xd261fc
    // 0xd26088: LoadField: r0 = r1->field_63
    //     0xd26088: ldur            w0, [x1, #0x63]
    // 0xd2608c: DecompressPointer r0
    //     0xd2608c: add             x0, x0, HEAP, lsl #32
    // 0xd26090: cmp             w0, NULL
    // 0xd26094: b.ne            #0xd260a0
    // 0xd26098: r0 = Null
    //     0xd26098: mov             x0, NULL
    // 0xd2609c: b               #0xd260d0
    // 0xd260a0: LoadField: r2 = r3->field_1f
    //     0xd260a0: ldur            w2, [x3, #0x1f]
    // 0xd260a4: DecompressPointer r2
    //     0xd260a4: add             x2, x2, HEAP, lsl #32
    // 0xd260a8: r1 = LoadClassIdInstr(r0)
    //     0xd260a8: ldur            x1, [x0, #-1]
    //     0xd260ac: ubfx            x1, x1, #0xc, #0x14
    // 0xd260b0: mov             x16, x0
    // 0xd260b4: mov             x0, x1
    // 0xd260b8: mov             x1, x16
    // 0xd260bc: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd260bc: mov             x17, #0x7c77
    //     0xd260c0: movk            x17, #1, lsl #16
    //     0xd260c4: add             lr, x0, x17
    //     0xd260c8: ldr             lr, [x21, lr, lsl #3]
    //     0xd260cc: blr             lr
    // 0xd260d0: cmp             w0, NULL
    // 0xd260d4: b.ne            #0xd26100
    // 0xd260d8: ldur            x3, [fp, #-8]
    // 0xd260dc: LoadField: r0 = r3->field_f
    //     0xd260dc: ldur            w0, [x3, #0xf]
    // 0xd260e0: DecompressPointer r0
    //     0xd260e0: add             x0, x0, HEAP, lsl #32
    // 0xd260e4: LoadField: r1 = r0->field_b
    //     0xd260e4: ldur            w1, [x0, #0xb]
    // 0xd260e8: DecompressPointer r1
    //     0xd260e8: add             x1, x1, HEAP, lsl #32
    // 0xd260ec: cmp             w1, NULL
    // 0xd260f0: b.eq            #0xd26200
    // 0xd260f4: LoadField: r0 = r1->field_5b
    //     0xd260f4: ldur            w0, [x1, #0x5b]
    // 0xd260f8: DecompressPointer r0
    //     0xd260f8: add             x0, x0, HEAP, lsl #32
    // 0xd260fc: b               #0xd26104
    // 0xd26100: ldur            x3, [fp, #-8]
    // 0xd26104: cmp             w0, NULL
    // 0xd26108: b.ne            #0xd261e0
    // 0xd2610c: LoadField: r0 = r3->field_13
    //     0xd2610c: ldur            w0, [x3, #0x13]
    // 0xd26110: DecompressPointer r0
    //     0xd26110: add             x0, x0, HEAP, lsl #32
    // 0xd26114: LoadField: r1 = r0->field_57
    //     0xd26114: ldur            w1, [x0, #0x57]
    // 0xd26118: DecompressPointer r1
    //     0xd26118: add             x1, x1, HEAP, lsl #32
    // 0xd2611c: mov             x0, x1
    // 0xd26120: b               #0xd261e0
    // 0xd26124: LoadField: r0 = r3->field_f
    //     0xd26124: ldur            w0, [x3, #0xf]
    // 0xd26128: DecompressPointer r0
    //     0xd26128: add             x0, x0, HEAP, lsl #32
    // 0xd2612c: LoadField: r1 = r0->field_b
    //     0xd2612c: ldur            w1, [x0, #0xb]
    // 0xd26130: DecompressPointer r1
    //     0xd26130: add             x1, x1, HEAP, lsl #32
    // 0xd26134: cmp             w1, NULL
    // 0xd26138: b.eq            #0xd26204
    // 0xd2613c: LoadField: r0 = r1->field_63
    //     0xd2613c: ldur            w0, [x1, #0x63]
    // 0xd26140: DecompressPointer r0
    //     0xd26140: add             x0, x0, HEAP, lsl #32
    // 0xd26144: cmp             w0, NULL
    // 0xd26148: b.ne            #0xd26154
    // 0xd2614c: r1 = Null
    //     0xd2614c: mov             x1, NULL
    // 0xd26150: b               #0xd26188
    // 0xd26154: LoadField: r2 = r3->field_1b
    //     0xd26154: ldur            w2, [x3, #0x1b]
    // 0xd26158: DecompressPointer r2
    //     0xd26158: add             x2, x2, HEAP, lsl #32
    // 0xd2615c: r1 = LoadClassIdInstr(r0)
    //     0xd2615c: ldur            x1, [x0, #-1]
    //     0xd26160: ubfx            x1, x1, #0xc, #0x14
    // 0xd26164: mov             x16, x0
    // 0xd26168: mov             x0, x1
    // 0xd2616c: mov             x1, x16
    // 0xd26170: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xd26170: mov             x17, #0x7c77
    //     0xd26174: movk            x17, #1, lsl #16
    //     0xd26178: add             lr, x0, x17
    //     0xd2617c: ldr             lr, [x21, lr, lsl #3]
    //     0xd26180: blr             lr
    // 0xd26184: mov             x1, x0
    // 0xd26188: cmp             w1, NULL
    // 0xd2618c: b.ne            #0xd261bc
    // 0xd26190: ldur            x2, [fp, #-8]
    // 0xd26194: LoadField: r3 = r2->field_f
    //     0xd26194: ldur            w3, [x2, #0xf]
    // 0xd26198: DecompressPointer r3
    //     0xd26198: add             x3, x3, HEAP, lsl #32
    // 0xd2619c: LoadField: r4 = r3->field_b
    //     0xd2619c: ldur            w4, [x3, #0xb]
    // 0xd261a0: DecompressPointer r4
    //     0xd261a0: add             x4, x4, HEAP, lsl #32
    // 0xd261a4: cmp             w4, NULL
    // 0xd261a8: b.eq            #0xd26208
    // 0xd261ac: LoadField: r3 = r4->field_57
    //     0xd261ac: ldur            w3, [x4, #0x57]
    // 0xd261b0: DecompressPointer r3
    //     0xd261b0: add             x3, x3, HEAP, lsl #32
    // 0xd261b4: mov             x1, x3
    // 0xd261b8: b               #0xd261c0
    // 0xd261bc: ldur            x2, [fp, #-8]
    // 0xd261c0: cmp             w1, NULL
    // 0xd261c4: b.ne            #0xd261dc
    // 0xd261c8: LoadField: r3 = r2->field_13
    //     0xd261c8: ldur            w3, [x2, #0x13]
    // 0xd261cc: DecompressPointer r3
    //     0xd261cc: add             x3, x3, HEAP, lsl #32
    // 0xd261d0: LoadField: r2 = r3->field_4b
    //     0xd261d0: ldur            w2, [x3, #0x4b]
    // 0xd261d4: DecompressPointer r2
    //     0xd261d4: add             x2, x2, HEAP, lsl #32
    // 0xd261d8: mov             x1, x2
    // 0xd261dc: mov             x0, x1
    // 0xd261e0: LeaveFrame
    //     0xd261e0: mov             SP, fp
    //     0xd261e4: ldp             fp, lr, [SP], #0x10
    // 0xd261e8: ret
    //     0xd261e8: ret             
    // 0xd261ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd261ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd261f0: b               #0xd25fa4
    // 0xd261f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd261f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd261f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd261f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd261fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd261fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd26200: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd26200: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd26204: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd26204: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd26208: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd26208: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf389dc, size: 0x4c4
    // 0xf389dc: EnterFrame
    //     0xf389dc: stp             fp, lr, [SP, #-0x10]!
    //     0xf389e0: mov             fp, SP
    // 0xf389e4: AllocStack(0x28)
    //     0xf389e4: sub             SP, SP, #0x28
    // 0xf389e8: SetupParameters(_InkResponseState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf389e8: mov             x4, x1
    //     0xf389ec: mov             x3, x2
    //     0xf389f0: stur            x1, [fp, #-8]
    //     0xf389f4: stur            x2, [fp, #-0x10]
    // 0xf389f8: CheckStackOverflow
    //     0xf389f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf389fc: cmp             SP, x16
    //     0xf38a00: b.ls            #0xf38e6c
    // 0xf38a04: mov             x0, x3
    // 0xf38a08: r2 = Null
    //     0xf38a08: mov             x2, NULL
    // 0xf38a0c: r1 = Null
    //     0xf38a0c: mov             x1, NULL
    // 0xf38a10: r4 = 60
    //     0xf38a10: mov             x4, #0x3c
    // 0xf38a14: branchIfSmi(r0, 0xf38a20)
    //     0xf38a14: tbz             w0, #0, #0xf38a20
    // 0xf38a18: r4 = LoadClassIdInstr(r0)
    //     0xf38a18: ldur            x4, [x0, #-1]
    //     0xf38a1c: ubfx            x4, x4, #0xc, #0x14
    // 0xf38a20: r17 = 6473
    //     0xf38a20: mov             x17, #0x1949
    // 0xf38a24: cmp             x4, x17
    // 0xf38a28: b.eq            #0xf38a40
    // 0xf38a2c: r8 = _InkResponseStateWidget
    //     0xf38a2c: add             x8, PP, #0x99, lsl #12  ; [pp+0x996b8] Type: _InkResponseStateWidget
    //     0xf38a30: ldr             x8, [x8, #0x6b8]
    // 0xf38a34: r3 = Null
    //     0xf38a34: add             x3, PP, #0x99, lsl #12  ; [pp+0x996c0] Null
    //     0xf38a38: ldr             x3, [x3, #0x6c0]
    // 0xf38a3c: r0 = _InkResponseStateWidget()
    //     0xf38a3c: bl              #0xd207f0  ; IsType__InkResponseStateWidget_Stub
    // 0xf38a40: ldur            x3, [fp, #-8]
    // 0xf38a44: LoadField: r2 = r3->field_7
    //     0xf38a44: ldur            w2, [x3, #7]
    // 0xf38a48: DecompressPointer r2
    //     0xf38a48: add             x2, x2, HEAP, lsl #32
    // 0xf38a4c: ldur            x0, [fp, #-0x10]
    // 0xf38a50: r1 = Null
    //     0xf38a50: mov             x1, NULL
    // 0xf38a54: cmp             w2, NULL
    // 0xf38a58: b.eq            #0xf38a7c
    // 0xf38a5c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf38a5c: ldur            w4, [x2, #0x17]
    // 0xf38a60: DecompressPointer r4
    //     0xf38a60: add             x4, x4, HEAP, lsl #32
    // 0xf38a64: r8 = X0 bound StatefulWidget
    //     0xf38a64: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf38a68: ldr             x8, [x8, #0x498]
    // 0xf38a6c: LoadField: r9 = r4->field_7
    //     0xf38a6c: ldur            x9, [x4, #7]
    // 0xf38a70: r3 = Null
    //     0xf38a70: add             x3, PP, #0x99, lsl #12  ; [pp+0x996d0] Null
    //     0xf38a74: ldr             x3, [x3, #0x6d0]
    // 0xf38a78: blr             x9
    // 0xf38a7c: ldur            x0, [fp, #-8]
    // 0xf38a80: LoadField: r1 = r0->field_b
    //     0xf38a80: ldur            w1, [x0, #0xb]
    // 0xf38a84: DecompressPointer r1
    //     0xf38a84: add             x1, x1, HEAP, lsl #32
    // 0xf38a88: cmp             w1, NULL
    // 0xf38a8c: b.eq            #0xf38e74
    // 0xf38a90: LoadField: r2 = r1->field_8f
    //     0xf38a90: ldur            w2, [x1, #0x8f]
    // 0xf38a94: DecompressPointer r2
    //     0xf38a94: add             x2, x2, HEAP, lsl #32
    // 0xf38a98: ldur            x3, [fp, #-0x10]
    // 0xf38a9c: LoadField: r4 = r3->field_8f
    //     0xf38a9c: ldur            w4, [x3, #0x8f]
    // 0xf38aa0: DecompressPointer r4
    //     0xf38aa0: add             x4, x4, HEAP, lsl #32
    // 0xf38aa4: stur            x4, [fp, #-0x18]
    // 0xf38aa8: cmp             w2, w4
    // 0xf38aac: b.eq            #0xf38b1c
    // 0xf38ab0: cmp             w4, NULL
    // 0xf38ab4: b.eq            #0xf38ad8
    // 0xf38ab8: mov             x2, x0
    // 0xf38abc: r1 = Function 'handleStatesControllerChange':.
    //     0xf38abc: add             x1, PP, #0x99, lsl #12  ; [pp+0x996a0] AnonymousClosure: (0xf3939c), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleStatesControllerChange (0xf393d4)
    //     0xf38ac0: ldr             x1, [x1, #0x6a0]
    // 0xf38ac4: r0 = AllocateClosure()
    //     0xf38ac4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf38ac8: ldur            x1, [fp, #-0x18]
    // 0xf38acc: mov             x2, x0
    // 0xf38ad0: r0 = removeListener()
    //     0xf38ad0: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xf38ad4: ldur            x0, [fp, #-8]
    // 0xf38ad8: LoadField: r1 = r0->field_b
    //     0xf38ad8: ldur            w1, [x0, #0xb]
    // 0xf38adc: DecompressPointer r1
    //     0xf38adc: add             x1, x1, HEAP, lsl #32
    // 0xf38ae0: cmp             w1, NULL
    // 0xf38ae4: b.eq            #0xf38e78
    // 0xf38ae8: LoadField: r2 = r1->field_8f
    //     0xf38ae8: ldur            w2, [x1, #0x8f]
    // 0xf38aec: DecompressPointer r2
    //     0xf38aec: add             x2, x2, HEAP, lsl #32
    // 0xf38af0: cmp             w2, NULL
    // 0xf38af4: b.eq            #0xf38b14
    // 0xf38af8: LoadField: r1 = r0->field_2b
    //     0xf38af8: ldur            w1, [x0, #0x2b]
    // 0xf38afc: DecompressPointer r1
    //     0xf38afc: add             x1, x1, HEAP, lsl #32
    // 0xf38b00: cmp             w1, NULL
    // 0xf38b04: b.eq            #0xf38b10
    // 0xf38b08: r0 = dispose()
    //     0xf38b08: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0xf38b0c: ldur            x0, [fp, #-8]
    // 0xf38b10: StoreField: r0->field_2b = rNULL
    //     0xf38b10: stur            NULL, [x0, #0x2b]
    // 0xf38b14: mov             x1, x0
    // 0xf38b18: r0 = initStatesController()
    //     0xf38b18: bl              #0xf39244  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::initStatesController
    // 0xf38b1c: ldur            x1, [fp, #-8]
    // 0xf38b20: ldur            x2, [fp, #-0x10]
    // 0xf38b24: LoadField: r0 = r1->field_b
    //     0xf38b24: ldur            w0, [x1, #0xb]
    // 0xf38b28: DecompressPointer r0
    //     0xf38b28: add             x0, x0, HEAP, lsl #32
    // 0xf38b2c: cmp             w0, NULL
    // 0xf38b30: b.eq            #0xf38e7c
    // 0xf38b34: LoadField: r3 = r0->field_4b
    //     0xf38b34: ldur            w3, [x0, #0x4b]
    // 0xf38b38: DecompressPointer r3
    //     0xf38b38: add             x3, x3, HEAP, lsl #32
    // 0xf38b3c: LoadField: r0 = r2->field_4b
    //     0xf38b3c: ldur            w0, [x2, #0x4b]
    // 0xf38b40: DecompressPointer r0
    //     0xf38b40: add             x0, x0, HEAP, lsl #32
    // 0xf38b44: r4 = LoadClassIdInstr(r3)
    //     0xf38b44: ldur            x4, [x3, #-1]
    //     0xf38b48: ubfx            x4, x4, #0xc, #0x14
    // 0xf38b4c: stp             x0, x3, [SP]
    // 0xf38b50: mov             x0, x4
    // 0xf38b54: mov             lr, x0
    // 0xf38b58: ldr             lr, [x21, lr, lsl #3]
    // 0xf38b5c: blr             lr
    // 0xf38b60: tbz             w0, #4, #0xf38b6c
    // 0xf38b64: ldur            x0, [fp, #-8]
    // 0xf38b68: b               #0xf38bd8
    // 0xf38b6c: ldur            x1, [fp, #-8]
    // 0xf38b70: ldur            x2, [fp, #-0x10]
    // 0xf38b74: LoadField: r0 = r1->field_b
    //     0xf38b74: ldur            w0, [x1, #0xb]
    // 0xf38b78: DecompressPointer r0
    //     0xf38b78: add             x0, x0, HEAP, lsl #32
    // 0xf38b7c: cmp             w0, NULL
    // 0xf38b80: b.eq            #0xf38e80
    // 0xf38b84: LoadField: r3 = r0->field_47
    //     0xf38b84: ldur            w3, [x0, #0x47]
    // 0xf38b88: DecompressPointer r3
    //     0xf38b88: add             x3, x3, HEAP, lsl #32
    // 0xf38b8c: LoadField: r4 = r2->field_47
    //     0xf38b8c: ldur            w4, [x2, #0x47]
    // 0xf38b90: DecompressPointer r4
    //     0xf38b90: add             x4, x4, HEAP, lsl #32
    // 0xf38b94: cmp             w3, w4
    // 0xf38b98: b.eq            #0xf38ba4
    // 0xf38b9c: mov             x0, x1
    // 0xf38ba0: b               #0xf38bd8
    // 0xf38ba4: LoadField: r3 = r0->field_4f
    //     0xf38ba4: ldur            w3, [x0, #0x4f]
    // 0xf38ba8: DecompressPointer r3
    //     0xf38ba8: add             x3, x3, HEAP, lsl #32
    // 0xf38bac: LoadField: r0 = r2->field_4f
    //     0xf38bac: ldur            w0, [x2, #0x4f]
    // 0xf38bb0: DecompressPointer r0
    //     0xf38bb0: add             x0, x0, HEAP, lsl #32
    // 0xf38bb4: r4 = LoadClassIdInstr(r3)
    //     0xf38bb4: ldur            x4, [x3, #-1]
    //     0xf38bb8: ubfx            x4, x4, #0xc, #0x14
    // 0xf38bbc: stp             x0, x3, [SP]
    // 0xf38bc0: mov             x0, x4
    // 0xf38bc4: mov             lr, x0
    // 0xf38bc8: ldr             lr, [x21, lr, lsl #3]
    // 0xf38bcc: blr             lr
    // 0xf38bd0: tbz             w0, #4, #0xf38c88
    // 0xf38bd4: ldur            x0, [fp, #-8]
    // 0xf38bd8: LoadField: r3 = r0->field_23
    //     0xf38bd8: ldur            w3, [x0, #0x23]
    // 0xf38bdc: DecompressPointer r3
    //     0xf38bdc: add             x3, x3, HEAP, lsl #32
    // 0xf38be0: mov             x1, x3
    // 0xf38be4: stur            x3, [fp, #-0x18]
    // 0xf38be8: r2 = Instance__HighlightType
    //     0xf38be8: add             x2, PP, #0x99, lsl #12  ; [pp+0x99520] Obj!_HighlightType@12c5781
    //     0xf38bec: ldr             x2, [x2, #0x520]
    // 0xf38bf0: r0 = _getValueOrData()
    //     0xf38bf0: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xf38bf4: mov             x1, x0
    // 0xf38bf8: ldur            x0, [fp, #-0x18]
    // 0xf38bfc: LoadField: r2 = r0->field_f
    //     0xf38bfc: ldur            w2, [x0, #0xf]
    // 0xf38c00: DecompressPointer r2
    //     0xf38c00: add             x2, x2, HEAP, lsl #32
    // 0xf38c04: cmp             w2, w1
    // 0xf38c08: b.ne            #0xf38c10
    // 0xf38c0c: r1 = Null
    //     0xf38c0c: mov             x1, NULL
    // 0xf38c10: cmp             w1, NULL
    // 0xf38c14: b.eq            #0xf38c4c
    // 0xf38c18: ldur            x2, [fp, #-8]
    // 0xf38c1c: r0 = dispose()
    //     0xf38c1c: bl              #0x119e764  ; [package:flutter/src/material/ink_highlight.dart] InkHighlight::dispose
    // 0xf38c20: ldur            x0, [fp, #-8]
    // 0xf38c24: LoadField: r3 = r0->field_1f
    //     0xf38c24: ldur            w3, [x0, #0x1f]
    // 0xf38c28: DecompressPointer r3
    //     0xf38c28: add             x3, x3, HEAP, lsl #32
    // 0xf38c2c: r16 = false
    //     0xf38c2c: add             x16, NULL, #0x30  ; false
    // 0xf38c30: str             x16, [SP]
    // 0xf38c34: mov             x1, x0
    // 0xf38c38: r2 = Instance__HighlightType
    //     0xf38c38: add             x2, PP, #0x99, lsl #12  ; [pp+0x99520] Obj!_HighlightType@12c5781
    //     0xf38c3c: ldr             x2, [x2, #0x520]
    // 0xf38c40: r4 = const [0, 0x4, 0x1, 0x3, callOnHover, 0x3, null]
    //     0xf38c40: add             x4, PP, #0x99, lsl #12  ; [pp+0x996e0] List(7) [0, 0x4, 0x1, 0x3, "callOnHover", 0x3, Null]
    //     0xf38c44: ldr             x4, [x4, #0x6e0]
    // 0xf38c48: r0 = updateHighlight()
    //     0xf38c48: bl              #0xd21118  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::updateHighlight
    // 0xf38c4c: ldur            x0, [fp, #-0x18]
    // 0xf38c50: mov             x1, x0
    // 0xf38c54: r2 = Instance__HighlightType
    //     0xf38c54: add             x2, PP, #0x99, lsl #12  ; [pp+0x994c0] Obj!_HighlightType@12c5761
    //     0xf38c58: ldr             x2, [x2, #0x4c0]
    // 0xf38c5c: r0 = _getValueOrData()
    //     0xf38c5c: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xf38c60: mov             x1, x0
    // 0xf38c64: ldur            x0, [fp, #-0x18]
    // 0xf38c68: LoadField: r2 = r0->field_f
    //     0xf38c68: ldur            w2, [x0, #0xf]
    // 0xf38c6c: DecompressPointer r2
    //     0xf38c6c: add             x2, x2, HEAP, lsl #32
    // 0xf38c70: cmp             w2, w1
    // 0xf38c74: b.ne            #0xf38c7c
    // 0xf38c78: r1 = Null
    //     0xf38c78: mov             x1, NULL
    // 0xf38c7c: cmp             w1, NULL
    // 0xf38c80: b.eq            #0xf38c88
    // 0xf38c84: r0 = dispose()
    //     0xf38c84: bl              #0x119e764  ; [package:flutter/src/material/ink_highlight.dart] InkHighlight::dispose
    // 0xf38c88: ldur            x1, [fp, #-8]
    // 0xf38c8c: ldur            x2, [fp, #-0x10]
    // 0xf38c90: LoadField: r0 = r1->field_b
    //     0xf38c90: ldur            w0, [x1, #0xb]
    // 0xf38c94: DecompressPointer r0
    //     0xf38c94: add             x0, x0, HEAP, lsl #32
    // 0xf38c98: cmp             w0, NULL
    // 0xf38c9c: b.eq            #0xf38e84
    // 0xf38ca0: LoadField: r3 = r0->field_53
    //     0xf38ca0: ldur            w3, [x0, #0x53]
    // 0xf38ca4: DecompressPointer r3
    //     0xf38ca4: add             x3, x3, HEAP, lsl #32
    // 0xf38ca8: LoadField: r0 = r2->field_53
    //     0xf38ca8: ldur            w0, [x2, #0x53]
    // 0xf38cac: DecompressPointer r0
    //     0xf38cac: add             x0, x0, HEAP, lsl #32
    // 0xf38cb0: r4 = LoadClassIdInstr(r3)
    //     0xf38cb0: ldur            x4, [x3, #-1]
    //     0xf38cb4: ubfx            x4, x4, #0xc, #0x14
    // 0xf38cb8: stp             x0, x3, [SP]
    // 0xf38cbc: mov             x0, x4
    // 0xf38cc0: mov             lr, x0
    // 0xf38cc4: ldr             lr, [x21, lr, lsl #3]
    // 0xf38cc8: blr             lr
    // 0xf38ccc: tbz             w0, #4, #0xf38cd8
    // 0xf38cd0: ldur            x1, [fp, #-8]
    // 0xf38cd4: r0 = _updateHighlightsAndSplashes()
    //     0xf38cd4: bl              #0xf38ea0  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::_updateHighlightsAndSplashes
    // 0xf38cd8: ldur            x0, [fp, #-8]
    // 0xf38cdc: LoadField: r2 = r0->field_b
    //     0xf38cdc: ldur            w2, [x0, #0xb]
    // 0xf38ce0: DecompressPointer r2
    //     0xf38ce0: add             x2, x2, HEAP, lsl #32
    // 0xf38ce4: cmp             w2, NULL
    // 0xf38ce8: b.eq            #0xf38e88
    // 0xf38cec: mov             x1, x0
    // 0xf38cf0: r0 = isWidgetEnabled()
    //     0xf38cf0: bl              #0xd20b34  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::isWidgetEnabled
    // 0xf38cf4: ldur            x1, [fp, #-8]
    // 0xf38cf8: ldur            x2, [fp, #-0x10]
    // 0xf38cfc: stur            x0, [fp, #-0x10]
    // 0xf38d00: r0 = isWidgetEnabled()
    //     0xf38d00: bl              #0xd20b34  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::isWidgetEnabled
    // 0xf38d04: mov             x1, x0
    // 0xf38d08: ldur            x0, [fp, #-0x10]
    // 0xf38d0c: cmp             w0, w1
    // 0xf38d10: b.eq            #0xf38e54
    // 0xf38d14: ldur            x0, [fp, #-8]
    // 0xf38d18: LoadField: r2 = r0->field_b
    //     0xf38d18: ldur            w2, [x0, #0xb]
    // 0xf38d1c: DecompressPointer r2
    //     0xf38d1c: add             x2, x2, HEAP, lsl #32
    // 0xf38d20: cmp             w2, NULL
    // 0xf38d24: b.eq            #0xf38e8c
    // 0xf38d28: LoadField: r1 = r2->field_8f
    //     0xf38d28: ldur            w1, [x2, #0x8f]
    // 0xf38d2c: DecompressPointer r1
    //     0xf38d2c: add             x1, x1, HEAP, lsl #32
    // 0xf38d30: cmp             w1, NULL
    // 0xf38d34: b.ne            #0xf38d50
    // 0xf38d38: LoadField: r1 = r0->field_2b
    //     0xf38d38: ldur            w1, [x0, #0x2b]
    // 0xf38d3c: DecompressPointer r1
    //     0xf38d3c: add             x1, x1, HEAP, lsl #32
    // 0xf38d40: cmp             w1, NULL
    // 0xf38d44: b.eq            #0xf38e90
    // 0xf38d48: mov             x3, x1
    // 0xf38d4c: b               #0xf38d54
    // 0xf38d50: mov             x3, x1
    // 0xf38d54: mov             x1, x0
    // 0xf38d58: stur            x3, [fp, #-0x10]
    // 0xf38d5c: r0 = isWidgetEnabled()
    //     0xf38d5c: bl              #0xd20b34  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::isWidgetEnabled
    // 0xf38d60: eor             x3, x0, #0x10
    // 0xf38d64: ldur            x1, [fp, #-0x10]
    // 0xf38d68: r2 = Instance_WidgetState
    //     0xf38d68: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xf38d6c: ldr             x2, [x2, #0xa70]
    // 0xf38d70: r0 = update()
    //     0xf38d70: bl              #0xd223e0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::update
    // 0xf38d74: ldur            x0, [fp, #-8]
    // 0xf38d78: LoadField: r2 = r0->field_b
    //     0xf38d78: ldur            w2, [x0, #0xb]
    // 0xf38d7c: DecompressPointer r2
    //     0xf38d7c: add             x2, x2, HEAP, lsl #32
    // 0xf38d80: cmp             w2, NULL
    // 0xf38d84: b.eq            #0xf38e94
    // 0xf38d88: mov             x1, x0
    // 0xf38d8c: r0 = isWidgetEnabled()
    //     0xf38d8c: bl              #0xd20b34  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::isWidgetEnabled
    // 0xf38d90: tbz             w0, #4, #0xf38e28
    // 0xf38d94: ldur            x0, [fp, #-8]
    // 0xf38d98: LoadField: r1 = r0->field_b
    //     0xf38d98: ldur            w1, [x0, #0xb]
    // 0xf38d9c: DecompressPointer r1
    //     0xf38d9c: add             x1, x1, HEAP, lsl #32
    // 0xf38da0: cmp             w1, NULL
    // 0xf38da4: b.eq            #0xf38e98
    // 0xf38da8: LoadField: r2 = r1->field_8f
    //     0xf38da8: ldur            w2, [x1, #0x8f]
    // 0xf38dac: DecompressPointer r2
    //     0xf38dac: add             x2, x2, HEAP, lsl #32
    // 0xf38db0: cmp             w2, NULL
    // 0xf38db4: b.ne            #0xf38dcc
    // 0xf38db8: LoadField: r1 = r0->field_2b
    //     0xf38db8: ldur            w1, [x0, #0x2b]
    // 0xf38dbc: DecompressPointer r1
    //     0xf38dbc: add             x1, x1, HEAP, lsl #32
    // 0xf38dc0: cmp             w1, NULL
    // 0xf38dc4: b.eq            #0xf38e9c
    // 0xf38dc8: b               #0xf38dd0
    // 0xf38dcc: mov             x1, x2
    // 0xf38dd0: r2 = Instance_WidgetState
    //     0xf38dd0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xf38dd4: ldr             x2, [x2, #0xa48]
    // 0xf38dd8: r3 = false
    //     0xf38dd8: add             x3, NULL, #0x30  ; false
    // 0xf38ddc: r0 = update()
    //     0xf38ddc: bl              #0xd223e0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::update
    // 0xf38de0: ldur            x0, [fp, #-8]
    // 0xf38de4: LoadField: r3 = r0->field_23
    //     0xf38de4: ldur            w3, [x0, #0x23]
    // 0xf38de8: DecompressPointer r3
    //     0xf38de8: add             x3, x3, HEAP, lsl #32
    // 0xf38dec: mov             x1, x3
    // 0xf38df0: stur            x3, [fp, #-0x10]
    // 0xf38df4: r2 = Instance__HighlightType
    //     0xf38df4: add             x2, PP, #0x99, lsl #12  ; [pp+0x99520] Obj!_HighlightType@12c5781
    //     0xf38df8: ldr             x2, [x2, #0x520]
    // 0xf38dfc: r0 = _getValueOrData()
    //     0xf38dfc: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xf38e00: mov             x1, x0
    // 0xf38e04: ldur            x0, [fp, #-0x10]
    // 0xf38e08: LoadField: r2 = r0->field_f
    //     0xf38e08: ldur            w2, [x0, #0xf]
    // 0xf38e0c: DecompressPointer r2
    //     0xf38e0c: add             x2, x2, HEAP, lsl #32
    // 0xf38e10: cmp             w2, w1
    // 0xf38e14: b.ne            #0xf38e1c
    // 0xf38e18: r1 = Null
    //     0xf38e18: mov             x1, NULL
    // 0xf38e1c: cmp             w1, NULL
    // 0xf38e20: b.eq            #0xf38e28
    // 0xf38e24: r0 = dispose()
    //     0xf38e24: bl              #0x119e764  ; [package:flutter/src/material/ink_highlight.dart] InkHighlight::dispose
    // 0xf38e28: ldur            x0, [fp, #-8]
    // 0xf38e2c: LoadField: r3 = r0->field_1f
    //     0xf38e2c: ldur            w3, [x0, #0x1f]
    // 0xf38e30: DecompressPointer r3
    //     0xf38e30: add             x3, x3, HEAP, lsl #32
    // 0xf38e34: r16 = false
    //     0xf38e34: add             x16, NULL, #0x30  ; false
    // 0xf38e38: str             x16, [SP]
    // 0xf38e3c: mov             x1, x0
    // 0xf38e40: r2 = Instance__HighlightType
    //     0xf38e40: add             x2, PP, #0x99, lsl #12  ; [pp+0x99520] Obj!_HighlightType@12c5781
    //     0xf38e44: ldr             x2, [x2, #0x520]
    // 0xf38e48: r4 = const [0, 0x4, 0x1, 0x3, callOnHover, 0x3, null]
    //     0xf38e48: add             x4, PP, #0x99, lsl #12  ; [pp+0x996e0] List(7) [0, 0x4, 0x1, 0x3, "callOnHover", 0x3, Null]
    //     0xf38e4c: ldr             x4, [x4, #0x6e0]
    // 0xf38e50: r0 = updateHighlight()
    //     0xf38e50: bl              #0xd21118  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::updateHighlight
    // 0xf38e54: ldur            x1, [fp, #-8]
    // 0xf38e58: r0 = updateFocusHighlights()
    //     0xf38e58: bl              #0xd21078  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::updateFocusHighlights
    // 0xf38e5c: r0 = Null
    //     0xf38e5c: mov             x0, NULL
    // 0xf38e60: LeaveFrame
    //     0xf38e60: mov             SP, fp
    //     0xf38e64: ldp             fp, lr, [SP], #0x10
    // 0xf38e68: ret
    //     0xf38e68: ret             
    // 0xf38e6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf38e6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf38e70: b               #0xf38a04
    // 0xf38e74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf38e74: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf38e78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf38e78: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf38e7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf38e7c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf38e80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf38e80: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf38e84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf38e84: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf38e88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf38e88: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf38e8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf38e8c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf38e90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf38e90: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf38e94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf38e94: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf38e98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf38e98: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf38e9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf38e9c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateHighlightsAndSplashes(/* No info */) {
    // ** addr: 0xf38ea0, size: 0x2f4
    // 0xf38ea0: EnterFrame
    //     0xf38ea0: stp             fp, lr, [SP, #-0x10]!
    //     0xf38ea4: mov             fp, SP
    // 0xf38ea8: AllocStack(0x38)
    //     0xf38ea8: sub             SP, SP, #0x38
    // 0xf38eac: SetupParameters(_InkResponseState this /* r1 => r0, fp-0x10 */)
    //     0xf38eac: mov             x0, x1
    //     0xf38eb0: stur            x1, [fp, #-0x10]
    // 0xf38eb4: CheckStackOverflow
    //     0xf38eb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf38eb8: cmp             SP, x16
    //     0xf38ebc: b.ls            #0xf39170
    // 0xf38ec0: LoadField: r2 = r0->field_23
    //     0xf38ec0: ldur            w2, [x0, #0x23]
    // 0xf38ec4: DecompressPointer r2
    //     0xf38ec4: add             x2, x2, HEAP, lsl #32
    // 0xf38ec8: stur            x2, [fp, #-8]
    // 0xf38ecc: r1 = <InkHighlight?>
    //     0xf38ecc: add             x1, PP, #0x99, lsl #12  ; [pp+0x994f8] TypeArguments: <InkHighlight?>
    //     0xf38ed0: ldr             x1, [x1, #0x4f8]
    // 0xf38ed4: r0 = _CompactValuesIterable()
    //     0xf38ed4: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xf38ed8: mov             x1, x0
    // 0xf38edc: ldur            x0, [fp, #-8]
    // 0xf38ee0: StoreField: r1->field_b = r0
    //     0xf38ee0: stur            w0, [x1, #0xb]
    // 0xf38ee4: r0 = iterator()
    //     0xf38ee4: bl              #0xb09b20  ; [dart:_compact_hash] _CompactValuesIterable::iterator
    // 0xf38ee8: stur            x0, [fp, #-0x18]
    // 0xf38eec: LoadField: r2 = r0->field_7
    //     0xf38eec: ldur            w2, [x0, #7]
    // 0xf38ef0: DecompressPointer r2
    //     0xf38ef0: add             x2, x2, HEAP, lsl #32
    // 0xf38ef4: stur            x2, [fp, #-8]
    // 0xf38ef8: ldur            x3, [fp, #-0x10]
    // 0xf38efc: CheckStackOverflow
    //     0xf38efc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf38f00: cmp             SP, x16
    //     0xf38f04: b.ls            #0xf39178
    // 0xf38f08: mov             x1, x0
    // 0xf38f0c: r0 = moveNext()
    //     0xf38f0c: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xf38f10: tbnz            w0, #4, #0xf38ff0
    // 0xf38f14: ldur            x3, [fp, #-0x18]
    // 0xf38f18: LoadField: r4 = r3->field_33
    //     0xf38f18: ldur            w4, [x3, #0x33]
    // 0xf38f1c: DecompressPointer r4
    //     0xf38f1c: add             x4, x4, HEAP, lsl #32
    // 0xf38f20: stur            x4, [fp, #-0x20]
    // 0xf38f24: cmp             w4, NULL
    // 0xf38f28: b.ne            #0xf38f5c
    // 0xf38f2c: mov             x0, x4
    // 0xf38f30: ldur            x2, [fp, #-8]
    // 0xf38f34: r1 = Null
    //     0xf38f34: mov             x1, NULL
    // 0xf38f38: cmp             w2, NULL
    // 0xf38f3c: b.eq            #0xf38f5c
    // 0xf38f40: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf38f40: ldur            w4, [x2, #0x17]
    // 0xf38f44: DecompressPointer r4
    //     0xf38f44: add             x4, x4, HEAP, lsl #32
    // 0xf38f48: r8 = X0
    //     0xf38f48: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xf38f4c: LoadField: r9 = r4->field_7
    //     0xf38f4c: ldur            x9, [x4, #7]
    // 0xf38f50: r3 = Null
    //     0xf38f50: add             x3, PP, #0x99, lsl #12  ; [pp+0x996e8] Null
    //     0xf38f54: ldr             x3, [x3, #0x6e8]
    // 0xf38f58: blr             x9
    // 0xf38f5c: ldur            x1, [fp, #-0x20]
    // 0xf38f60: cmp             w1, NULL
    // 0xf38f64: b.eq            #0xf38fe4
    // 0xf38f68: ldur            x2, [fp, #-0x10]
    // 0xf38f6c: LoadField: r0 = r2->field_b
    //     0xf38f6c: ldur            w0, [x2, #0xb]
    // 0xf38f70: DecompressPointer r0
    //     0xf38f70: add             x0, x0, HEAP, lsl #32
    // 0xf38f74: cmp             w0, NULL
    // 0xf38f78: b.eq            #0xf39180
    // 0xf38f7c: LoadField: r3 = r0->field_53
    //     0xf38f7c: ldur            w3, [x0, #0x53]
    // 0xf38f80: DecompressPointer r3
    //     0xf38f80: add             x3, x3, HEAP, lsl #32
    // 0xf38f84: stur            x3, [fp, #-0x28]
    // 0xf38f88: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xf38f88: ldur            w0, [x1, #0x17]
    // 0xf38f8c: DecompressPointer r0
    //     0xf38f8c: add             x0, x0, HEAP, lsl #32
    // 0xf38f90: r4 = LoadClassIdInstr(r3)
    //     0xf38f90: ldur            x4, [x3, #-1]
    //     0xf38f94: ubfx            x4, x4, #0xc, #0x14
    // 0xf38f98: stp             x0, x3, [SP]
    // 0xf38f9c: mov             x0, x4
    // 0xf38fa0: mov             lr, x0
    // 0xf38fa4: ldr             lr, [x21, lr, lsl #3]
    // 0xf38fa8: blr             lr
    // 0xf38fac: tbz             w0, #4, #0xf38fe4
    // 0xf38fb0: ldur            x1, [fp, #-0x20]
    // 0xf38fb4: ldur            x0, [fp, #-0x28]
    // 0xf38fb8: ArrayStore: r1[0] = r0  ; List_4
    //     0xf38fb8: stur            w0, [x1, #0x17]
    //     0xf38fbc: ldurb           w16, [x1, #-1]
    //     0xf38fc0: ldurb           w17, [x0, #-1]
    //     0xf38fc4: and             x16, x17, x16, lsr #2
    //     0xf38fc8: tst             x16, HEAP, lsr #32
    //     0xf38fcc: b.eq            #0xf38fd4
    //     0xf38fd0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf38fd4: LoadField: r0 = r1->field_7
    //     0xf38fd4: ldur            w0, [x1, #7]
    // 0xf38fd8: DecompressPointer r0
    //     0xf38fd8: add             x0, x0, HEAP, lsl #32
    // 0xf38fdc: mov             x1, x0
    // 0xf38fe0: r0 = markNeedsPaint()
    //     0xf38fe0: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xf38fe4: ldur            x0, [fp, #-0x18]
    // 0xf38fe8: ldur            x2, [fp, #-8]
    // 0xf38fec: b               #0xf38ef8
    // 0xf38ff0: ldur            x0, [fp, #-0x10]
    // 0xf38ff4: LoadField: r1 = r0->field_1b
    //     0xf38ff4: ldur            w1, [x0, #0x1b]
    // 0xf38ff8: DecompressPointer r1
    //     0xf38ff8: add             x1, x1, HEAP, lsl #32
    // 0xf38ffc: cmp             w1, NULL
    // 0xf39000: b.eq            #0xf39028
    // 0xf39004: LoadField: r2 = r0->field_b
    //     0xf39004: ldur            w2, [x0, #0xb]
    // 0xf39008: DecompressPointer r2
    //     0xf39008: add             x2, x2, HEAP, lsl #32
    // 0xf3900c: cmp             w2, NULL
    // 0xf39010: b.eq            #0xf39184
    // 0xf39014: LoadField: r3 = r2->field_53
    //     0xf39014: ldur            w3, [x2, #0x53]
    // 0xf39018: DecompressPointer r3
    //     0xf39018: add             x3, x3, HEAP, lsl #32
    // 0xf3901c: mov             x2, x3
    // 0xf39020: r0 = customBorder=()
    //     0xf39020: bl              #0xf39194  ; [package:flutter/src/material/ink_well.dart] InteractiveInkFeature::customBorder=
    // 0xf39024: ldur            x0, [fp, #-0x10]
    // 0xf39028: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xf39028: ldur            w2, [x0, #0x17]
    // 0xf3902c: DecompressPointer r2
    //     0xf3902c: add             x2, x2, HEAP, lsl #32
    // 0xf39030: stur            x2, [fp, #-8]
    // 0xf39034: cmp             w2, NULL
    // 0xf39038: b.eq            #0xf39160
    // 0xf3903c: LoadField: r1 = r2->field_f
    //     0xf3903c: ldur            x1, [x2, #0xf]
    // 0xf39040: cbz             x1, #0xf39160
    // 0xf39044: r1 = <InteractiveInkFeature>
    //     0xf39044: add             x1, PP, #0x99, lsl #12  ; [pp+0x99578] TypeArguments: <InteractiveInkFeature>
    //     0xf39048: ldr             x1, [x1, #0x578]
    // 0xf3904c: r0 = _HashSetIterator()
    //     0xf3904c: bl              #0x90dac0  ; Allocate_HashSetIteratorStub -> _HashSetIterator<X0> (size=0x28)
    // 0xf39050: stur            x0, [fp, #-0x18]
    // 0xf39054: ArrayStore: r0[0] = rZR  ; List_8
    //     0xf39054: stur            xzr, [x0, #0x17]
    // 0xf39058: ldur            x1, [fp, #-8]
    // 0xf3905c: StoreField: r0->field_b = r1
    //     0xf3905c: stur            w1, [x0, #0xb]
    // 0xf39060: ArrayLoad: r2 = r1[0]  ; List_8
    //     0xf39060: ldur            x2, [x1, #0x17]
    // 0xf39064: StoreField: r0->field_f = r2
    //     0xf39064: stur            x2, [x0, #0xf]
    // 0xf39068: ldur            x2, [fp, #-0x10]
    // 0xf3906c: CheckStackOverflow
    //     0xf3906c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf39070: cmp             SP, x16
    //     0xf39074: b.ls            #0xf39188
    // 0xf39078: mov             x1, x0
    // 0xf3907c: r0 = moveNext()
    //     0xf3907c: bl              #0x804abc  ; [dart:collection] _HashSetIterator::moveNext
    // 0xf39080: tbnz            w0, #4, #0xf39160
    // 0xf39084: ldur            x3, [fp, #-0x18]
    // 0xf39088: LoadField: r4 = r3->field_23
    //     0xf39088: ldur            w4, [x3, #0x23]
    // 0xf3908c: DecompressPointer r4
    //     0xf3908c: add             x4, x4, HEAP, lsl #32
    // 0xf39090: stur            x4, [fp, #-8]
    // 0xf39094: cmp             w4, NULL
    // 0xf39098: b.ne            #0xf390d8
    // 0xf3909c: mov             x0, x4
    // 0xf390a0: r2 = Null
    //     0xf390a0: mov             x2, NULL
    // 0xf390a4: r1 = Null
    //     0xf390a4: mov             x1, NULL
    // 0xf390a8: r4 = 60
    //     0xf390a8: mov             x4, #0x3c
    // 0xf390ac: branchIfSmi(r0, 0xf390b8)
    //     0xf390ac: tbz             w0, #0, #0xf390b8
    // 0xf390b0: r4 = LoadClassIdInstr(r0)
    //     0xf390b0: ldur            x4, [x0, #-1]
    //     0xf390b4: ubfx            x4, x4, #0xc, #0x14
    // 0xf390b8: sub             x4, x4, #0xbde
    // 0xf390bc: cmp             x4, #3
    // 0xf390c0: b.ls            #0xf390d8
    // 0xf390c4: r8 = InteractiveInkFeature
    //     0xf390c4: add             x8, PP, #0x99, lsl #12  ; [pp+0x99670] Type: InteractiveInkFeature
    //     0xf390c8: ldr             x8, [x8, #0x670]
    // 0xf390cc: r3 = Null
    //     0xf390cc: add             x3, PP, #0x99, lsl #12  ; [pp+0x996f8] Null
    //     0xf390d0: ldr             x3, [x3, #0x6f8]
    // 0xf390d4: r0 = InteractiveInkFeature()
    //     0xf390d4: bl              #0xd20838  ; IsType_InteractiveInkFeature_Stub
    // 0xf390d8: ldur            x2, [fp, #-0x10]
    // 0xf390dc: ldur            x1, [fp, #-8]
    // 0xf390e0: LoadField: r0 = r2->field_b
    //     0xf390e0: ldur            w0, [x2, #0xb]
    // 0xf390e4: DecompressPointer r0
    //     0xf390e4: add             x0, x0, HEAP, lsl #32
    // 0xf390e8: cmp             w0, NULL
    // 0xf390ec: b.eq            #0xf39190
    // 0xf390f0: LoadField: r3 = r0->field_53
    //     0xf390f0: ldur            w3, [x0, #0x53]
    // 0xf390f4: DecompressPointer r3
    //     0xf390f4: add             x3, x3, HEAP, lsl #32
    // 0xf390f8: stur            x3, [fp, #-0x20]
    // 0xf390fc: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xf390fc: ldur            w0, [x1, #0x17]
    // 0xf39100: DecompressPointer r0
    //     0xf39100: add             x0, x0, HEAP, lsl #32
    // 0xf39104: r4 = LoadClassIdInstr(r3)
    //     0xf39104: ldur            x4, [x3, #-1]
    //     0xf39108: ubfx            x4, x4, #0xc, #0x14
    // 0xf3910c: stp             x0, x3, [SP]
    // 0xf39110: mov             x0, x4
    // 0xf39114: mov             lr, x0
    // 0xf39118: ldr             lr, [x21, lr, lsl #3]
    // 0xf3911c: blr             lr
    // 0xf39120: tbz             w0, #4, #0xf39158
    // 0xf39124: ldur            x1, [fp, #-8]
    // 0xf39128: ldur            x0, [fp, #-0x20]
    // 0xf3912c: ArrayStore: r1[0] = r0  ; List_4
    //     0xf3912c: stur            w0, [x1, #0x17]
    //     0xf39130: ldurb           w16, [x1, #-1]
    //     0xf39134: ldurb           w17, [x0, #-1]
    //     0xf39138: and             x16, x17, x16, lsr #2
    //     0xf3913c: tst             x16, HEAP, lsr #32
    //     0xf39140: b.eq            #0xf39148
    //     0xf39144: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf39148: LoadField: r0 = r1->field_7
    //     0xf39148: ldur            w0, [x1, #7]
    // 0xf3914c: DecompressPointer r0
    //     0xf3914c: add             x0, x0, HEAP, lsl #32
    // 0xf39150: mov             x1, x0
    // 0xf39154: r0 = markNeedsPaint()
    //     0xf39154: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xf39158: ldur            x0, [fp, #-0x18]
    // 0xf3915c: b               #0xf39068
    // 0xf39160: r0 = Null
    //     0xf39160: mov             x0, NULL
    // 0xf39164: LeaveFrame
    //     0xf39164: mov             SP, fp
    //     0xf39168: ldp             fp, lr, [SP], #0x10
    // 0xf3916c: ret
    //     0xf3916c: ret             
    // 0xf39170: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf39170: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf39174: b               #0xf38ec0
    // 0xf39178: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf39178: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3917c: b               #0xf38f08
    // 0xf39180: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf39180: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf39184: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf39184: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf39188: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf39188: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3918c: b               #0xf39078
    // 0xf39190: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf39190: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initStatesController(/* No info */) {
    // ** addr: 0xf39244, size: 0x158
    // 0xf39244: EnterFrame
    //     0xf39244: stp             fp, lr, [SP, #-0x10]!
    //     0xf39248: mov             fp, SP
    // 0xf3924c: AllocStack(0x10)
    //     0xf3924c: sub             SP, SP, #0x10
    // 0xf39250: SetupParameters(_InkResponseState this /* r1 => r0, fp-0x8 */)
    //     0xf39250: mov             x0, x1
    //     0xf39254: stur            x1, [fp, #-8]
    // 0xf39258: CheckStackOverflow
    //     0xf39258: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3925c: cmp             SP, x16
    //     0xf39260: b.ls            #0xf39380
    // 0xf39264: LoadField: r1 = r0->field_b
    //     0xf39264: ldur            w1, [x0, #0xb]
    // 0xf39268: DecompressPointer r1
    //     0xf39268: add             x1, x1, HEAP, lsl #32
    // 0xf3926c: cmp             w1, NULL
    // 0xf39270: b.eq            #0xf39388
    // 0xf39274: LoadField: r2 = r1->field_8f
    //     0xf39274: ldur            w2, [x1, #0x8f]
    // 0xf39278: DecompressPointer r2
    //     0xf39278: add             x2, x2, HEAP, lsl #32
    // 0xf3927c: cmp             w2, NULL
    // 0xf39280: b.ne            #0xf392c4
    // 0xf39284: r1 = <Set<WidgetState>>
    //     0xf39284: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f978] TypeArguments: <Set<WidgetState>>
    //     0xf39288: ldr             x1, [x1, #0x978]
    // 0xf3928c: r0 = WidgetStatesController()
    //     0xf3928c: bl              #0xf379b8  ; AllocateWidgetStatesControllerStub -> WidgetStatesController (size=0x2c)
    // 0xf39290: mov             x1, x0
    // 0xf39294: stur            x0, [fp, #-0x10]
    // 0xf39298: r0 = WidgetStatesController()
    //     0xf39298: bl              #0xf378e8  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::WidgetStatesController
    // 0xf3929c: ldur            x0, [fp, #-0x10]
    // 0xf392a0: ldur            x3, [fp, #-8]
    // 0xf392a4: StoreField: r3->field_2b = r0
    //     0xf392a4: stur            w0, [x3, #0x2b]
    //     0xf392a8: ldurb           w16, [x3, #-1]
    //     0xf392ac: ldurb           w17, [x0, #-1]
    //     0xf392b0: and             x16, x17, x16, lsr #2
    //     0xf392b4: tst             x16, HEAP, lsr #32
    //     0xf392b8: b.eq            #0xf392c0
    //     0xf392bc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf392c0: b               #0xf392c8
    // 0xf392c4: mov             x3, x0
    // 0xf392c8: LoadField: r2 = r3->field_b
    //     0xf392c8: ldur            w2, [x3, #0xb]
    // 0xf392cc: DecompressPointer r2
    //     0xf392cc: add             x2, x2, HEAP, lsl #32
    // 0xf392d0: cmp             w2, NULL
    // 0xf392d4: b.eq            #0xf3938c
    // 0xf392d8: LoadField: r0 = r2->field_8f
    //     0xf392d8: ldur            w0, [x2, #0x8f]
    // 0xf392dc: DecompressPointer r0
    //     0xf392dc: add             x0, x0, HEAP, lsl #32
    // 0xf392e0: cmp             w0, NULL
    // 0xf392e4: b.ne            #0xf392f8
    // 0xf392e8: LoadField: r0 = r3->field_2b
    //     0xf392e8: ldur            w0, [x3, #0x2b]
    // 0xf392ec: DecompressPointer r0
    //     0xf392ec: add             x0, x0, HEAP, lsl #32
    // 0xf392f0: cmp             w0, NULL
    // 0xf392f4: b.eq            #0xf39390
    // 0xf392f8: mov             x1, x3
    // 0xf392fc: stur            x0, [fp, #-0x10]
    // 0xf39300: r0 = isWidgetEnabled()
    //     0xf39300: bl              #0xd20b34  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::isWidgetEnabled
    // 0xf39304: eor             x3, x0, #0x10
    // 0xf39308: ldur            x1, [fp, #-0x10]
    // 0xf3930c: r2 = Instance_WidgetState
    //     0xf3930c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xf39310: ldr             x2, [x2, #0xa70]
    // 0xf39314: r0 = update()
    //     0xf39314: bl              #0xd223e0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::update
    // 0xf39318: ldur            x2, [fp, #-8]
    // 0xf3931c: LoadField: r0 = r2->field_b
    //     0xf3931c: ldur            w0, [x2, #0xb]
    // 0xf39320: DecompressPointer r0
    //     0xf39320: add             x0, x0, HEAP, lsl #32
    // 0xf39324: cmp             w0, NULL
    // 0xf39328: b.eq            #0xf39394
    // 0xf3932c: LoadField: r1 = r0->field_8f
    //     0xf3932c: ldur            w1, [x0, #0x8f]
    // 0xf39330: DecompressPointer r1
    //     0xf39330: add             x1, x1, HEAP, lsl #32
    // 0xf39334: cmp             w1, NULL
    // 0xf39338: b.ne            #0xf39350
    // 0xf3933c: LoadField: r0 = r2->field_2b
    //     0xf3933c: ldur            w0, [x2, #0x2b]
    // 0xf39340: DecompressPointer r0
    //     0xf39340: add             x0, x0, HEAP, lsl #32
    // 0xf39344: cmp             w0, NULL
    // 0xf39348: b.eq            #0xf39398
    // 0xf3934c: b               #0xf39354
    // 0xf39350: mov             x0, x1
    // 0xf39354: stur            x0, [fp, #-0x10]
    // 0xf39358: r1 = Function 'handleStatesControllerChange':.
    //     0xf39358: add             x1, PP, #0x99, lsl #12  ; [pp+0x996a0] AnonymousClosure: (0xf3939c), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleStatesControllerChange (0xf393d4)
    //     0xf3935c: ldr             x1, [x1, #0x6a0]
    // 0xf39360: r0 = AllocateClosure()
    //     0xf39360: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf39364: ldur            x1, [fp, #-0x10]
    // 0xf39368: mov             x2, x0
    // 0xf3936c: r0 = addListener()
    //     0xf3936c: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xf39370: r0 = Null
    //     0xf39370: mov             x0, NULL
    // 0xf39374: LeaveFrame
    //     0xf39374: mov             SP, fp
    //     0xf39378: ldp             fp, lr, [SP], #0x10
    // 0xf3937c: ret
    //     0xf3937c: ret             
    // 0xf39380: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf39380: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf39384: b               #0xf39264
    // 0xf39388: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf39388: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3938c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3938c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf39390: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf39390: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf39394: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf39394: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf39398: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf39398: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleStatesControllerChange(dynamic) {
    // ** addr: 0xf3939c, size: 0x38
    // 0xf3939c: EnterFrame
    //     0xf3939c: stp             fp, lr, [SP, #-0x10]!
    //     0xf393a0: mov             fp, SP
    // 0xf393a4: ldr             x0, [fp, #0x10]
    // 0xf393a8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf393a8: ldur            w1, [x0, #0x17]
    // 0xf393ac: DecompressPointer r1
    //     0xf393ac: add             x1, x1, HEAP, lsl #32
    // 0xf393b0: CheckStackOverflow
    //     0xf393b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf393b4: cmp             SP, x16
    //     0xf393b8: b.ls            #0xf393cc
    // 0xf393bc: r0 = handleStatesControllerChange()
    //     0xf393bc: bl              #0xf393d4  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleStatesControllerChange
    // 0xf393c0: LeaveFrame
    //     0xf393c0: mov             SP, fp
    //     0xf393c4: ldp             fp, lr, [SP], #0x10
    // 0xf393c8: ret
    //     0xf393c8: ret             
    // 0xf393cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf393cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf393d0: b               #0xf393bc
  }
  _ handleStatesControllerChange(/* No info */) {
    // ** addr: 0xf393d4, size: 0x54
    // 0xf393d4: EnterFrame
    //     0xf393d4: stp             fp, lr, [SP, #-0x10]!
    //     0xf393d8: mov             fp, SP
    // 0xf393dc: AllocStack(0x8)
    //     0xf393dc: sub             SP, SP, #8
    // 0xf393e0: SetupParameters(_InkResponseState this /* r1 => r0, fp-0x8 */)
    //     0xf393e0: mov             x0, x1
    //     0xf393e4: stur            x1, [fp, #-8]
    // 0xf393e8: CheckStackOverflow
    //     0xf393e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf393ec: cmp             SP, x16
    //     0xf393f0: b.ls            #0xf39420
    // 0xf393f4: r1 = Function '<anonymous closure>':.
    //     0xf393f4: add             x1, PP, #0x99, lsl #12  ; [pp+0x996a8] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xf393f8: ldr             x1, [x1, #0x6a8]
    // 0xf393fc: r2 = Null
    //     0xf393fc: mov             x2, NULL
    // 0xf39400: r0 = AllocateClosure()
    //     0xf39400: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf39404: ldur            x1, [fp, #-8]
    // 0xf39408: mov             x2, x0
    // 0xf3940c: r0 = setState()
    //     0xf3940c: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf39410: r0 = Null
    //     0xf39410: mov             x0, NULL
    // 0xf39414: LeaveFrame
    //     0xf39414: mov             SP, fp
    //     0xf39418: ldp             fp, lr, [SP], #0x10
    // 0xf3941c: ret
    //     0xf3941c: ret             
    // 0xf39420: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf39420: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf39424: b               #0xf393f4
  }
  _ deactivate(/* No info */) {
    // ** addr: 0xf783d8, size: 0x290
    // 0xf783d8: EnterFrame
    //     0xf783d8: stp             fp, lr, [SP, #-0x10]!
    //     0xf783dc: mov             fp, SP
    // 0xf783e0: AllocStack(0x38)
    //     0xf783e0: sub             SP, SP, #0x38
    // 0xf783e4: SetupParameters(_InkResponseState this /* r1 => r2, fp-0x10 */)
    //     0xf783e4: mov             x2, x1
    //     0xf783e8: stur            x1, [fp, #-0x10]
    // 0xf783ec: CheckStackOverflow
    //     0xf783ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf783f0: cmp             SP, x16
    //     0xf783f4: b.ls            #0xf78640
    // 0xf783f8: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xf783f8: ldur            w0, [x2, #0x17]
    // 0xf783fc: DecompressPointer r0
    //     0xf783fc: add             x0, x0, HEAP, lsl #32
    // 0xf78400: stur            x0, [fp, #-8]
    // 0xf78404: cmp             w0, NULL
    // 0xf78408: b.eq            #0xf784cc
    // 0xf7840c: ArrayStore: r2[0] = rNULL  ; List_4
    //     0xf7840c: stur            NULL, [x2, #0x17]
    // 0xf78410: r1 = <InteractiveInkFeature>
    //     0xf78410: add             x1, PP, #0x99, lsl #12  ; [pp+0x99578] TypeArguments: <InteractiveInkFeature>
    //     0xf78414: ldr             x1, [x1, #0x578]
    // 0xf78418: r0 = _HashSetIterator()
    //     0xf78418: bl              #0x90dac0  ; Allocate_HashSetIteratorStub -> _HashSetIterator<X0> (size=0x28)
    // 0xf7841c: stur            x0, [fp, #-0x18]
    // 0xf78420: ArrayStore: r0[0] = rZR  ; List_8
    //     0xf78420: stur            xzr, [x0, #0x17]
    // 0xf78424: ldur            x1, [fp, #-8]
    // 0xf78428: StoreField: r0->field_b = r1
    //     0xf78428: stur            w1, [x0, #0xb]
    // 0xf7842c: ArrayLoad: r2 = r1[0]  ; List_8
    //     0xf7842c: ldur            x2, [x1, #0x17]
    // 0xf78430: StoreField: r0->field_f = r2
    //     0xf78430: stur            x2, [x0, #0xf]
    // 0xf78434: CheckStackOverflow
    //     0xf78434: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf78438: cmp             SP, x16
    //     0xf7843c: b.ls            #0xf78648
    // 0xf78440: mov             x1, x0
    // 0xf78444: r0 = moveNext()
    //     0xf78444: bl              #0x804abc  ; [dart:collection] _HashSetIterator::moveNext
    // 0xf78448: tbnz            w0, #4, #0xf784c4
    // 0xf7844c: ldur            x3, [fp, #-0x18]
    // 0xf78450: LoadField: r4 = r3->field_23
    //     0xf78450: ldur            w4, [x3, #0x23]
    // 0xf78454: DecompressPointer r4
    //     0xf78454: add             x4, x4, HEAP, lsl #32
    // 0xf78458: stur            x4, [fp, #-8]
    // 0xf7845c: cmp             w4, NULL
    // 0xf78460: b.ne            #0xf784a0
    // 0xf78464: mov             x0, x4
    // 0xf78468: r2 = Null
    //     0xf78468: mov             x2, NULL
    // 0xf7846c: r1 = Null
    //     0xf7846c: mov             x1, NULL
    // 0xf78470: r4 = 60
    //     0xf78470: mov             x4, #0x3c
    // 0xf78474: branchIfSmi(r0, 0xf78480)
    //     0xf78474: tbz             w0, #0, #0xf78480
    // 0xf78478: r4 = LoadClassIdInstr(r0)
    //     0xf78478: ldur            x4, [x0, #-1]
    //     0xf7847c: ubfx            x4, x4, #0xc, #0x14
    // 0xf78480: sub             x4, x4, #0xbde
    // 0xf78484: cmp             x4, #3
    // 0xf78488: b.ls            #0xf784a0
    // 0xf7848c: r8 = InteractiveInkFeature
    //     0xf7848c: add             x8, PP, #0x99, lsl #12  ; [pp+0x99670] Type: InteractiveInkFeature
    //     0xf78490: ldr             x8, [x8, #0x670]
    // 0xf78494: r3 = Null
    //     0xf78494: add             x3, PP, #0x99, lsl #12  ; [pp+0x99678] Null
    //     0xf78498: ldr             x3, [x3, #0x678]
    // 0xf7849c: r0 = InteractiveInkFeature()
    //     0xf7849c: bl              #0xd20838  ; IsType_InteractiveInkFeature_Stub
    // 0xf784a0: ldur            x1, [fp, #-8]
    // 0xf784a4: r0 = LoadClassIdInstr(r1)
    //     0xf784a4: ldur            x0, [x1, #-1]
    //     0xf784a8: ubfx            x0, x0, #0xc, #0x14
    // 0xf784ac: r0 = GDT[cid_x0 + 0x2f22]()
    //     0xf784ac: mov             x17, #0x2f22
    //     0xf784b0: add             lr, x0, x17
    //     0xf784b4: ldr             lr, [x21, lr, lsl #3]
    //     0xf784b8: blr             lr
    // 0xf784bc: ldur            x0, [fp, #-0x18]
    // 0xf784c0: b               #0xf78434
    // 0xf784c4: ldur            x2, [fp, #-0x10]
    // 0xf784c8: StoreField: r2->field_1b = rNULL
    //     0xf784c8: stur            NULL, [x2, #0x1b]
    // 0xf784cc: LoadField: r0 = r2->field_23
    //     0xf784cc: ldur            w0, [x2, #0x23]
    // 0xf784d0: DecompressPointer r0
    //     0xf784d0: add             x0, x0, HEAP, lsl #32
    // 0xf784d4: stur            x0, [fp, #-8]
    // 0xf784d8: r1 = <_HighlightType, InkHighlight?>
    //     0xf784d8: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8fd38] TypeArguments: <_HighlightType, InkHighlight?>
    //     0xf784dc: ldr             x1, [x1, #0xd38]
    // 0xf784e0: r0 = _CompactKeysIterable()
    //     0xf784e0: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0xf784e4: mov             x1, x0
    // 0xf784e8: ldur            x0, [fp, #-8]
    // 0xf784ec: StoreField: r1->field_b = r0
    //     0xf784ec: stur            w0, [x1, #0xb]
    // 0xf784f0: r0 = iterator()
    //     0xf784f0: bl              #0xb09a64  ; [dart:_compact_hash] _CompactKeysIterable::iterator
    // 0xf784f4: stur            x0, [fp, #-0x20]
    // 0xf784f8: LoadField: r2 = r0->field_7
    //     0xf784f8: ldur            w2, [x0, #7]
    // 0xf784fc: DecompressPointer r2
    //     0xf784fc: add             x2, x2, HEAP, lsl #32
    // 0xf78500: stur            x2, [fp, #-0x18]
    // 0xf78504: ldur            x3, [fp, #-8]
    // 0xf78508: CheckStackOverflow
    //     0xf78508: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7850c: cmp             SP, x16
    //     0xf78510: b.ls            #0xf78650
    // 0xf78514: mov             x1, x0
    // 0xf78518: r0 = moveNext()
    //     0xf78518: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xf7851c: tbnz            w0, #4, #0xf785f4
    // 0xf78520: ldur            x3, [fp, #-0x20]
    // 0xf78524: LoadField: r4 = r3->field_33
    //     0xf78524: ldur            w4, [x3, #0x33]
    // 0xf78528: DecompressPointer r4
    //     0xf78528: add             x4, x4, HEAP, lsl #32
    // 0xf7852c: stur            x4, [fp, #-0x28]
    // 0xf78530: cmp             w4, NULL
    // 0xf78534: b.ne            #0xf78568
    // 0xf78538: mov             x0, x4
    // 0xf7853c: ldur            x2, [fp, #-0x18]
    // 0xf78540: r1 = Null
    //     0xf78540: mov             x1, NULL
    // 0xf78544: cmp             w2, NULL
    // 0xf78548: b.eq            #0xf78568
    // 0xf7854c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf7854c: ldur            w4, [x2, #0x17]
    // 0xf78550: DecompressPointer r4
    //     0xf78550: add             x4, x4, HEAP, lsl #32
    // 0xf78554: r8 = X0
    //     0xf78554: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xf78558: LoadField: r9 = r4->field_7
    //     0xf78558: ldur            x9, [x4, #7]
    // 0xf7855c: r3 = Null
    //     0xf7855c: add             x3, PP, #0x99, lsl #12  ; [pp+0x99688] Null
    //     0xf78560: ldr             x3, [x3, #0x688]
    // 0xf78564: blr             x9
    // 0xf78568: ldur            x0, [fp, #-8]
    // 0xf7856c: mov             x1, x0
    // 0xf78570: ldur            x2, [fp, #-0x28]
    // 0xf78574: r0 = _getValueOrData()
    //     0xf78574: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xf78578: mov             x1, x0
    // 0xf7857c: ldur            x0, [fp, #-8]
    // 0xf78580: LoadField: r2 = r0->field_f
    //     0xf78580: ldur            w2, [x0, #0xf]
    // 0xf78584: DecompressPointer r2
    //     0xf78584: add             x2, x2, HEAP, lsl #32
    // 0xf78588: cmp             w2, w1
    // 0xf7858c: b.ne            #0xf78598
    // 0xf78590: r2 = Null
    //     0xf78590: mov             x2, NULL
    // 0xf78594: b               #0xf7859c
    // 0xf78598: mov             x2, x1
    // 0xf7859c: stur            x2, [fp, #-0x30]
    // 0xf785a0: cmp             w2, NULL
    // 0xf785a4: b.eq            #0xf785c8
    // 0xf785a8: LoadField: r1 = r2->field_33
    //     0xf785a8: ldur            w1, [x2, #0x33]
    // 0xf785ac: DecompressPointer r1
    //     0xf785ac: add             x1, x1, HEAP, lsl #32
    // 0xf785b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf785b4: cmp             w1, w16
    // 0xf785b8: b.eq            #0xf78658
    // 0xf785bc: r0 = dispose()
    //     0xf785bc: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xf785c0: ldur            x1, [fp, #-0x30]
    // 0xf785c4: r0 = dispose()
    //     0xf785c4: bl              #0xf786a8  ; [package:flutter/src/material/material.dart] InkFeature::dispose
    // 0xf785c8: ldur            x16, [fp, #-0x28]
    // 0xf785cc: str             x16, [SP]
    // 0xf785d0: r0 = _getHash()
    //     0xf785d0: bl              #0x84c644  ; [dart:core] ::_getHash
    // 0xf785d4: ldur            x1, [fp, #-8]
    // 0xf785d8: ldur            x2, [fp, #-0x28]
    // 0xf785dc: mov             x5, x0
    // 0xf785e0: r3 = Null
    //     0xf785e0: mov             x3, NULL
    // 0xf785e4: r0 = _set()
    //     0xf785e4: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0xf785e8: ldur            x0, [fp, #-0x20]
    // 0xf785ec: ldur            x2, [fp, #-0x18]
    // 0xf785f0: b               #0xf78504
    // 0xf785f4: ldur            x0, [fp, #-0x10]
    // 0xf785f8: LoadField: r1 = r0->field_b
    //     0xf785f8: ldur            w1, [x0, #0xb]
    // 0xf785fc: DecompressPointer r1
    //     0xf785fc: add             x1, x1, HEAP, lsl #32
    // 0xf78600: cmp             w1, NULL
    // 0xf78604: b.eq            #0xf78664
    // 0xf78608: LoadField: r2 = r1->field_87
    //     0xf78608: ldur            w2, [x1, #0x87]
    // 0xf7860c: DecompressPointer r2
    //     0xf7860c: add             x2, x2, HEAP, lsl #32
    // 0xf78610: cmp             w2, NULL
    // 0xf78614: b.eq            #0xf78628
    // 0xf78618: mov             x1, x2
    // 0xf7861c: mov             x2, x0
    // 0xf78620: r3 = false
    //     0xf78620: add             x3, NULL, #0x30  ; false
    // 0xf78624: r0 = markChildInkResponsePressed()
    //     0xf78624: bl              #0xd2215c  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::markChildInkResponsePressed
    // 0xf78628: ldur            x1, [fp, #-0x10]
    // 0xf7862c: r0 = deactivate()
    //     0xf7862c: bl              #0xf78668  ; [dart:mixin_deduplication] _MixinApplication70&State&AutomaticKeepAliveClientMixin::deactivate
    // 0xf78630: r0 = Null
    //     0xf78630: mov             x0, NULL
    // 0xf78634: LeaveFrame
    //     0xf78634: mov             SP, fp
    //     0xf78638: ldp             fp, lr, [SP], #0x10
    // 0xf7863c: ret
    //     0xf7863c: ret             
    // 0xf78640: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf78640: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf78644: b               #0xf783f8
    // 0xf78648: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf78648: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7864c: b               #0xf78440
    // 0xf78650: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf78650: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf78654: b               #0xf78514
    // 0xf78658: r9 = _alphaController
    //     0xf78658: add             x9, PP, #0x99, lsl #12  ; [pp+0x994f0] Field <InkHighlight._alphaController@754209331>: late (offset: 0x34)
    //     0xf7865c: ldr             x9, [x9, #0x4f0]
    // 0xf78660: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf78660: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf78664: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf78664: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf7a198, size: 0x98
    // 0xf7a198: EnterFrame
    //     0xf7a198: stp             fp, lr, [SP, #-0x10]!
    //     0xf7a19c: mov             fp, SP
    // 0xf7a1a0: AllocStack(0x10)
    //     0xf7a1a0: sub             SP, SP, #0x10
    // 0xf7a1a4: SetupParameters(_InkResponseState this /* r1 => r0, fp-0x8 */)
    //     0xf7a1a4: mov             x0, x1
    //     0xf7a1a8: stur            x1, [fp, #-8]
    // 0xf7a1ac: CheckStackOverflow
    //     0xf7a1ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7a1b0: cmp             SP, x16
    //     0xf7a1b4: b.ls            #0xf7a220
    // 0xf7a1b8: mov             x1, x0
    // 0xf7a1bc: r0 = initState()
    //     0xf7a1bc: bl              #0xf7a2a8  ; [dart:mixin_deduplication] _MixinApplication70&State&AutomaticKeepAliveClientMixin::initState
    // 0xf7a1c0: ldur            x1, [fp, #-8]
    // 0xf7a1c4: r0 = initStatesController()
    //     0xf7a1c4: bl              #0xf39244  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::initStatesController
    // 0xf7a1c8: r0 = LoadStaticField(0x6a0)
    //     0xf7a1c8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf7a1cc: ldr             x0, [x0, #0xd40]
    // 0xf7a1d0: cmp             w0, NULL
    // 0xf7a1d4: b.eq            #0xf7a228
    // 0xf7a1d8: LoadField: r1 = r0->field_ef
    //     0xf7a1d8: ldur            w1, [x0, #0xef]
    // 0xf7a1dc: DecompressPointer r1
    //     0xf7a1dc: add             x1, x1, HEAP, lsl #32
    // 0xf7a1e0: cmp             w1, NULL
    // 0xf7a1e4: b.eq            #0xf7a22c
    // 0xf7a1e8: LoadField: r0 = r1->field_13
    //     0xf7a1e8: ldur            w0, [x1, #0x13]
    // 0xf7a1ec: DecompressPointer r0
    //     0xf7a1ec: add             x0, x0, HEAP, lsl #32
    // 0xf7a1f0: ldur            x2, [fp, #-8]
    // 0xf7a1f4: stur            x0, [fp, #-0x10]
    // 0xf7a1f8: r1 = Function 'handleFocusHighlightModeChange':.
    //     0xf7a1f8: add             x1, PP, #0x99, lsl #12  ; [pp+0x99698] AnonymousClosure: (0xf7a2f4), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleFocusHighlightModeChange (0xf7a330)
    //     0xf7a1fc: ldr             x1, [x1, #0x698]
    // 0xf7a200: r0 = AllocateClosure()
    //     0xf7a200: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf7a204: ldur            x1, [fp, #-0x10]
    // 0xf7a208: mov             x2, x0
    // 0xf7a20c: r0 = addHighlightModeListener()
    //     0xf7a20c: bl              #0xf7a230  ; [package:flutter/src/widgets/focus_manager.dart] FocusManager::addHighlightModeListener
    // 0xf7a210: r0 = Null
    //     0xf7a210: mov             x0, NULL
    // 0xf7a214: LeaveFrame
    //     0xf7a214: mov             SP, fp
    //     0xf7a218: ldp             fp, lr, [SP], #0x10
    // 0xf7a21c: ret
    //     0xf7a21c: ret             
    // 0xf7a220: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7a220: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7a224: b               #0xf7a1b8
    // 0xf7a228: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7a228: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7a22c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7a22c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleFocusHighlightModeChange(dynamic, FocusHighlightMode) {
    // ** addr: 0xf7a2f4, size: 0x3c
    // 0xf7a2f4: EnterFrame
    //     0xf7a2f4: stp             fp, lr, [SP, #-0x10]!
    //     0xf7a2f8: mov             fp, SP
    // 0xf7a2fc: ldr             x0, [fp, #0x18]
    // 0xf7a300: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf7a300: ldur            w1, [x0, #0x17]
    // 0xf7a304: DecompressPointer r1
    //     0xf7a304: add             x1, x1, HEAP, lsl #32
    // 0xf7a308: CheckStackOverflow
    //     0xf7a308: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7a30c: cmp             SP, x16
    //     0xf7a310: b.ls            #0xf7a328
    // 0xf7a314: ldr             x2, [fp, #0x10]
    // 0xf7a318: r0 = handleFocusHighlightModeChange()
    //     0xf7a318: bl              #0xf7a330  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleFocusHighlightModeChange
    // 0xf7a31c: LeaveFrame
    //     0xf7a31c: mov             SP, fp
    //     0xf7a320: ldp             fp, lr, [SP], #0x10
    // 0xf7a324: ret
    //     0xf7a324: ret             
    // 0xf7a328: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7a328: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7a32c: b               #0xf7a314
  }
  _ handleFocusHighlightModeChange(/* No info */) {
    // ** addr: 0xf7a330, size: 0x84
    // 0xf7a330: EnterFrame
    //     0xf7a330: stp             fp, lr, [SP, #-0x10]!
    //     0xf7a334: mov             fp, SP
    // 0xf7a338: AllocStack(0x8)
    //     0xf7a338: sub             SP, SP, #8
    // 0xf7a33c: SetupParameters(_InkResponseState this /* r1 => r1, fp-0x8 */)
    //     0xf7a33c: stur            x1, [fp, #-8]
    // 0xf7a340: CheckStackOverflow
    //     0xf7a340: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7a344: cmp             SP, x16
    //     0xf7a348: b.ls            #0xf7a3ac
    // 0xf7a34c: r1 = 1
    //     0xf7a34c: mov             x1, #1
    // 0xf7a350: r0 = AllocateContext()
    //     0xf7a350: bl              #0x13de838  ; AllocateContextStub
    // 0xf7a354: mov             x1, x0
    // 0xf7a358: ldur            x0, [fp, #-8]
    // 0xf7a35c: StoreField: r1->field_f = r0
    //     0xf7a35c: stur            w0, [x1, #0xf]
    // 0xf7a360: LoadField: r2 = r0->field_f
    //     0xf7a360: ldur            w2, [x0, #0xf]
    // 0xf7a364: DecompressPointer r2
    //     0xf7a364: add             x2, x2, HEAP, lsl #32
    // 0xf7a368: cmp             w2, NULL
    // 0xf7a36c: b.ne            #0xf7a380
    // 0xf7a370: r0 = Null
    //     0xf7a370: mov             x0, NULL
    // 0xf7a374: LeaveFrame
    //     0xf7a374: mov             SP, fp
    //     0xf7a378: ldp             fp, lr, [SP], #0x10
    // 0xf7a37c: ret
    //     0xf7a37c: ret             
    // 0xf7a380: mov             x2, x1
    // 0xf7a384: r1 = Function '<anonymous closure>':.
    //     0xf7a384: add             x1, PP, #0x99, lsl #12  ; [pp+0x996b0] AnonymousClosure: (0xf7a3b4), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleFocusHighlightModeChange (0xf7a330)
    //     0xf7a388: ldr             x1, [x1, #0x6b0]
    // 0xf7a38c: r0 = AllocateClosure()
    //     0xf7a38c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf7a390: ldur            x1, [fp, #-8]
    // 0xf7a394: mov             x2, x0
    // 0xf7a398: r0 = setState()
    //     0xf7a398: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf7a39c: r0 = Null
    //     0xf7a39c: mov             x0, NULL
    // 0xf7a3a0: LeaveFrame
    //     0xf7a3a0: mov             SP, fp
    //     0xf7a3a4: ldp             fp, lr, [SP], #0x10
    // 0xf7a3a8: ret
    //     0xf7a3a8: ret             
    // 0xf7a3ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7a3ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7a3b0: b               #0xf7a34c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf7a3b4, size: 0x48
    // 0xf7a3b4: EnterFrame
    //     0xf7a3b4: stp             fp, lr, [SP, #-0x10]!
    //     0xf7a3b8: mov             fp, SP
    // 0xf7a3bc: ldr             x0, [fp, #0x10]
    // 0xf7a3c0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf7a3c0: ldur            w1, [x0, #0x17]
    // 0xf7a3c4: DecompressPointer r1
    //     0xf7a3c4: add             x1, x1, HEAP, lsl #32
    // 0xf7a3c8: CheckStackOverflow
    //     0xf7a3c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7a3cc: cmp             SP, x16
    //     0xf7a3d0: b.ls            #0xf7a3f4
    // 0xf7a3d4: LoadField: r0 = r1->field_f
    //     0xf7a3d4: ldur            w0, [x1, #0xf]
    // 0xf7a3d8: DecompressPointer r0
    //     0xf7a3d8: add             x0, x0, HEAP, lsl #32
    // 0xf7a3dc: mov             x1, x0
    // 0xf7a3e0: r0 = updateFocusHighlights()
    //     0xf7a3e0: bl              #0xd21078  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::updateFocusHighlights
    // 0xf7a3e4: r0 = Null
    //     0xf7a3e4: mov             x0, NULL
    // 0xf7a3e8: LeaveFrame
    //     0xf7a3e8: mov             SP, fp
    //     0xf7a3ec: ldp             fp, lr, [SP], #0x10
    // 0xf7a3f0: ret
    //     0xf7a3f0: ret             
    // 0xf7a3f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7a3f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7a3f8: b               #0xf7a3d4
  }
  _ _InkResponseState(/* No info */) {
    // ** addr: 0xfa1a98, size: 0xf4
    // 0xfa1a98: EnterFrame
    //     0xfa1a98: stp             fp, lr, [SP, #-0x10]!
    //     0xfa1a9c: mov             fp, SP
    // 0xfa1aa0: AllocStack(0x20)
    //     0xfa1aa0: sub             SP, SP, #0x20
    // 0xfa1aa4: r2 = false
    //     0xfa1aa4: add             x2, NULL, #0x30  ; false
    // 0xfa1aa8: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa1aac: stur            x1, [fp, #-8]
    // 0xfa1ab0: CheckStackOverflow
    //     0xfa1ab0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa1ab4: cmp             SP, x16
    //     0xfa1ab8: b.ls            #0xfa1b84
    // 0xfa1abc: StoreField: r1->field_1f = r2
    //     0xfa1abc: stur            w2, [x1, #0x1f]
    // 0xfa1ac0: StoreField: r1->field_27 = r0
    //     0xfa1ac0: stur            w0, [x1, #0x27]
    // 0xfa1ac4: StoreField: r1->field_37 = r2
    //     0xfa1ac4: stur            w2, [x1, #0x37]
    // 0xfa1ac8: r16 = <_HighlightType, InkHighlight?>
    //     0xfa1ac8: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fd38] TypeArguments: <_HighlightType, InkHighlight?>
    //     0xfa1acc: ldr             x16, [x16, #0xd38]
    // 0xfa1ad0: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xfa1ad4: stp             lr, x16, [SP]
    // 0xfa1ad8: r0 = Map._fromLiteral()
    //     0xfa1ad8: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xfa1adc: ldur            x2, [fp, #-8]
    // 0xfa1ae0: StoreField: r2->field_23 = r0
    //     0xfa1ae0: stur            w0, [x2, #0x23]
    //     0xfa1ae4: ldurb           w16, [x2, #-1]
    //     0xfa1ae8: ldurb           w17, [x0, #-1]
    //     0xfa1aec: and             x16, x17, x16, lsr #2
    //     0xfa1af0: tst             x16, HEAP, lsr #32
    //     0xfa1af4: b.eq            #0xfa1afc
    //     0xfa1af8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfa1afc: r1 = <_ParentInkResponseState>
    //     0xfa1afc: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8fd40] TypeArguments: <_ParentInkResponseState>
    //     0xfa1b00: ldr             x1, [x1, #0xd40]
    // 0xfa1b04: r0 = ObserverList()
    //     0xfa1b04: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xfa1b08: mov             x3, x0
    // 0xfa1b0c: r0 = false
    //     0xfa1b0c: add             x0, NULL, #0x30  ; false
    // 0xfa1b10: stur            x3, [fp, #-0x10]
    // 0xfa1b14: StoreField: r3->field_f = r0
    //     0xfa1b14: stur            w0, [x3, #0xf]
    // 0xfa1b18: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa1b1c: StoreField: r3->field_13 = r0
    //     0xfa1b1c: stur            w0, [x3, #0x13]
    // 0xfa1b20: r1 = <_ParentInkResponseState>
    //     0xfa1b20: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8fd40] TypeArguments: <_ParentInkResponseState>
    //     0xfa1b24: ldr             x1, [x1, #0xd40]
    // 0xfa1b28: r2 = 0
    //     0xfa1b28: mov             x2, #0
    // 0xfa1b2c: r0 = _GrowableList()
    //     0xfa1b2c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfa1b30: ldur            x1, [fp, #-0x10]
    // 0xfa1b34: StoreField: r1->field_b = r0
    //     0xfa1b34: stur            w0, [x1, #0xb]
    //     0xfa1b38: ldurb           w16, [x1, #-1]
    //     0xfa1b3c: ldurb           w17, [x0, #-1]
    //     0xfa1b40: and             x16, x17, x16, lsr #2
    //     0xfa1b44: tst             x16, HEAP, lsr #32
    //     0xfa1b48: b.eq            #0xfa1b50
    //     0xfa1b4c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa1b50: mov             x0, x1
    // 0xfa1b54: ldur            x1, [fp, #-8]
    // 0xfa1b58: StoreField: r1->field_2f = r0
    //     0xfa1b58: stur            w0, [x1, #0x2f]
    //     0xfa1b5c: ldurb           w16, [x1, #-1]
    //     0xfa1b60: ldurb           w17, [x0, #-1]
    //     0xfa1b64: and             x16, x17, x16, lsr #2
    //     0xfa1b68: tst             x16, HEAP, lsr #32
    //     0xfa1b6c: b.eq            #0xfa1b74
    //     0xfa1b70: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa1b74: r0 = Null
    //     0xfa1b74: mov             x0, NULL
    // 0xfa1b78: LeaveFrame
    //     0xfa1b78: mov             SP, fp
    //     0xfa1b7c: ldp             fp, lr, [SP], #0x10
    // 0xfa1b80: ret
    //     0xfa1b80: ret             
    // 0xfa1b84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa1b84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa1b88: b               #0xfa1abc
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10dcc30, size: 0x130
    // 0x10dcc30: EnterFrame
    //     0x10dcc30: stp             fp, lr, [SP, #-0x10]!
    //     0x10dcc34: mov             fp, SP
    // 0x10dcc38: AllocStack(0x10)
    //     0x10dcc38: sub             SP, SP, #0x10
    // 0x10dcc3c: SetupParameters(_InkResponseState this /* r1 => r0, fp-0x10 */)
    //     0x10dcc3c: mov             x0, x1
    //     0x10dcc40: stur            x1, [fp, #-0x10]
    // 0x10dcc44: CheckStackOverflow
    //     0x10dcc44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10dcc48: cmp             SP, x16
    //     0x10dcc4c: b.ls            #0x10dcd48
    // 0x10dcc50: r1 = LoadStaticField(0x6a0)
    //     0x10dcc50: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x10dcc54: ldr             x1, [x1, #0xd40]
    // 0x10dcc58: cmp             w1, NULL
    // 0x10dcc5c: b.eq            #0x10dcd50
    // 0x10dcc60: LoadField: r2 = r1->field_ef
    //     0x10dcc60: ldur            w2, [x1, #0xef]
    // 0x10dcc64: DecompressPointer r2
    //     0x10dcc64: add             x2, x2, HEAP, lsl #32
    // 0x10dcc68: cmp             w2, NULL
    // 0x10dcc6c: b.eq            #0x10dcd54
    // 0x10dcc70: LoadField: r3 = r2->field_13
    //     0x10dcc70: ldur            w3, [x2, #0x13]
    // 0x10dcc74: DecompressPointer r3
    //     0x10dcc74: add             x3, x3, HEAP, lsl #32
    // 0x10dcc78: mov             x2, x0
    // 0x10dcc7c: stur            x3, [fp, #-8]
    // 0x10dcc80: r1 = Function 'handleFocusHighlightModeChange':.
    //     0x10dcc80: add             x1, PP, #0x99, lsl #12  ; [pp+0x99698] AnonymousClosure: (0xf7a2f4), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleFocusHighlightModeChange (0xf7a330)
    //     0x10dcc84: ldr             x1, [x1, #0x698]
    // 0x10dcc88: r0 = AllocateClosure()
    //     0x10dcc88: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10dcc8c: ldur            x1, [fp, #-8]
    // 0x10dcc90: mov             x2, x0
    // 0x10dcc94: r0 = removeHighlightModeListener()
    //     0x10dcc94: bl              #0x10dcd60  ; [package:flutter/src/widgets/focus_manager.dart] FocusManager::removeHighlightModeListener
    // 0x10dcc98: ldur            x0, [fp, #-0x10]
    // 0x10dcc9c: LoadField: r1 = r0->field_b
    //     0x10dcc9c: ldur            w1, [x0, #0xb]
    // 0x10dcca0: DecompressPointer r1
    //     0x10dcca0: add             x1, x1, HEAP, lsl #32
    // 0x10dcca4: cmp             w1, NULL
    // 0x10dcca8: b.eq            #0x10dcd58
    // 0x10dccac: LoadField: r2 = r1->field_8f
    //     0x10dccac: ldur            w2, [x1, #0x8f]
    // 0x10dccb0: DecompressPointer r2
    //     0x10dccb0: add             x2, x2, HEAP, lsl #32
    // 0x10dccb4: cmp             w2, NULL
    // 0x10dccb8: b.ne            #0x10dccd4
    // 0x10dccbc: LoadField: r1 = r0->field_2b
    //     0x10dccbc: ldur            w1, [x0, #0x2b]
    // 0x10dccc0: DecompressPointer r1
    //     0x10dccc0: add             x1, x1, HEAP, lsl #32
    // 0x10dccc4: cmp             w1, NULL
    // 0x10dccc8: b.eq            #0x10dcd5c
    // 0x10dcccc: mov             x3, x1
    // 0x10dccd0: b               #0x10dccd8
    // 0x10dccd4: mov             x3, x2
    // 0x10dccd8: mov             x2, x0
    // 0x10dccdc: stur            x3, [fp, #-8]
    // 0x10dcce0: r1 = Function 'handleStatesControllerChange':.
    //     0x10dcce0: add             x1, PP, #0x99, lsl #12  ; [pp+0x996a0] AnonymousClosure: (0xf3939c), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleStatesControllerChange (0xf393d4)
    //     0x10dcce4: ldr             x1, [x1, #0x6a0]
    // 0x10dcce8: r0 = AllocateClosure()
    //     0x10dcce8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10dccec: ldur            x1, [fp, #-8]
    // 0x10dccf0: mov             x2, x0
    // 0x10dccf4: r0 = removeListener()
    //     0x10dccf4: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x10dccf8: ldur            x0, [fp, #-0x10]
    // 0x10dccfc: LoadField: r1 = r0->field_2b
    //     0x10dccfc: ldur            w1, [x0, #0x2b]
    // 0x10dcd00: DecompressPointer r1
    //     0x10dcd00: add             x1, x1, HEAP, lsl #32
    // 0x10dcd04: cmp             w1, NULL
    // 0x10dcd08: b.eq            #0x10dcd14
    // 0x10dcd0c: r0 = dispose()
    //     0x10dcd0c: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0x10dcd10: ldur            x0, [fp, #-0x10]
    // 0x10dcd14: LoadField: r1 = r0->field_33
    //     0x10dcd14: ldur            w1, [x0, #0x33]
    // 0x10dcd18: DecompressPointer r1
    //     0x10dcd18: add             x1, x1, HEAP, lsl #32
    // 0x10dcd1c: cmp             w1, NULL
    // 0x10dcd20: b.ne            #0x10dcd2c
    // 0x10dcd24: mov             x1, x0
    // 0x10dcd28: b               #0x10dcd34
    // 0x10dcd2c: r0 = cancel()
    //     0x10dcd2c: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0x10dcd30: ldur            x1, [fp, #-0x10]
    // 0x10dcd34: StoreField: r1->field_33 = rNULL
    //     0x10dcd34: stur            NULL, [x1, #0x33]
    // 0x10dcd38: r0 = Null
    //     0x10dcd38: mov             x0, NULL
    // 0x10dcd3c: LeaveFrame
    //     0x10dcd3c: mov             SP, fp
    //     0x10dcd40: ldp             fp, lr, [SP], #0x10
    // 0x10dcd44: ret
    //     0x10dcd44: ret             
    // 0x10dcd48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dcd48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dcd4c: b               #0x10dcc50
    // 0x10dcd50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10dcd50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10dcd54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10dcd54: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10dcd58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10dcd58: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10dcd5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10dcd5c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic activateOnIntent(dynamic) {
    // ** addr: 0x12a0330, size: 0x24
    // 0x12a0330: EnterFrame
    //     0x12a0330: stp             fp, lr, [SP, #-0x10]!
    //     0x12a0334: mov             fp, SP
    // 0x12a0338: ldr             x2, [fp, #0x10]
    // 0x12a033c: r1 = Function 'activateOnIntent':.
    //     0x12a033c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3cc8] AnonymousClosure: (0x12a0354), in [package:flutter/src/material/ink_well.dart] _InkResponseState::activateOnIntent (0x12a0390)
    //     0x12a0340: ldr             x1, [x1, #0xcc8]
    // 0x12a0344: r0 = AllocateClosure()
    //     0x12a0344: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12a0348: LeaveFrame
    //     0x12a0348: mov             SP, fp
    //     0x12a034c: ldp             fp, lr, [SP], #0x10
    // 0x12a0350: ret
    //     0x12a0350: ret             
  }
  [closure] void activateOnIntent(dynamic, Intent?) {
    // ** addr: 0x12a0354, size: 0x3c
    // 0x12a0354: EnterFrame
    //     0x12a0354: stp             fp, lr, [SP, #-0x10]!
    //     0x12a0358: mov             fp, SP
    // 0x12a035c: ldr             x0, [fp, #0x18]
    // 0x12a0360: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x12a0360: ldur            w1, [x0, #0x17]
    // 0x12a0364: DecompressPointer r1
    //     0x12a0364: add             x1, x1, HEAP, lsl #32
    // 0x12a0368: CheckStackOverflow
    //     0x12a0368: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12a036c: cmp             SP, x16
    //     0x12a0370: b.ls            #0x12a0388
    // 0x12a0374: ldr             x2, [fp, #0x10]
    // 0x12a0378: r0 = activateOnIntent()
    //     0x12a0378: bl              #0x12a0390  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::activateOnIntent
    // 0x12a037c: LeaveFrame
    //     0x12a037c: mov             SP, fp
    //     0x12a0380: ldp             fp, lr, [SP], #0x10
    // 0x12a0384: ret
    //     0x12a0384: ret             
    // 0x12a0388: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12a0388: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12a038c: b               #0x12a0374
  }
  _ activateOnIntent(/* No info */) {
    // ** addr: 0x12a0390, size: 0x334
    // 0x12a0390: EnterFrame
    //     0x12a0390: stp             fp, lr, [SP, #-0x10]!
    //     0x12a0394: mov             fp, SP
    // 0x12a0398: AllocStack(0x30)
    //     0x12a0398: sub             SP, SP, #0x30
    // 0x12a039c: SetupParameters(_InkResponseState this /* r1 => r1, fp-0x8 */)
    //     0x12a039c: stur            x1, [fp, #-8]
    // 0x12a03a0: CheckStackOverflow
    //     0x12a03a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12a03a4: cmp             SP, x16
    //     0x12a03a8: b.ls            #0x12a064c
    // 0x12a03ac: r1 = 1
    //     0x12a03ac: mov             x1, #1
    // 0x12a03b0: r0 = AllocateContext()
    //     0x12a03b0: bl              #0x13de838  ; AllocateContextStub
    // 0x12a03b4: mov             x2, x0
    // 0x12a03b8: ldur            x0, [fp, #-8]
    // 0x12a03bc: stur            x2, [fp, #-0x10]
    // 0x12a03c0: StoreField: r2->field_f = r0
    //     0x12a03c0: stur            w0, [x2, #0xf]
    // 0x12a03c4: LoadField: r1 = r0->field_33
    //     0x12a03c4: ldur            w1, [x0, #0x33]
    // 0x12a03c8: DecompressPointer r1
    //     0x12a03c8: add             x1, x1, HEAP, lsl #32
    // 0x12a03cc: cmp             w1, NULL
    // 0x12a03d0: b.eq            #0x12a03dc
    // 0x12a03d4: r0 = cancel()
    //     0x12a03d4: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0x12a03d8: ldur            x0, [fp, #-8]
    // 0x12a03dc: StoreField: r0->field_33 = rNULL
    //     0x12a03dc: stur            NULL, [x0, #0x33]
    // 0x12a03e0: LoadField: r1 = r0->field_f
    //     0x12a03e0: ldur            w1, [x0, #0xf]
    // 0x12a03e4: DecompressPointer r1
    //     0x12a03e4: add             x1, x1, HEAP, lsl #32
    // 0x12a03e8: cmp             w1, NULL
    // 0x12a03ec: b.eq            #0x12a0654
    // 0x12a03f0: str             x1, [SP]
    // 0x12a03f4: mov             x1, x0
    // 0x12a03f8: r4 = const [0, 0x2, 0x1, 0x1, context, 0x1, null]
    //     0x12a03f8: add             x4, PP, #0x92, lsl #12  ; [pp+0x92418] List(7) [0, 0x2, 0x1, 0x1, "context", 0x1, Null]
    //     0x12a03fc: ldr             x4, [x4, #0x418]
    // 0x12a0400: r0 = _startNewSplash()
    //     0x12a0400: bl              #0xd22d48  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::_startNewSplash
    // 0x12a0404: ldur            x0, [fp, #-8]
    // 0x12a0408: LoadField: r1 = r0->field_1b
    //     0x12a0408: ldur            w1, [x0, #0x1b]
    // 0x12a040c: DecompressPointer r1
    //     0x12a040c: add             x1, x1, HEAP, lsl #32
    // 0x12a0410: stur            x1, [fp, #-0x28]
    // 0x12a0414: cmp             w1, NULL
    // 0x12a0418: b.eq            #0x12a057c
    // 0x12a041c: r2 = LoadClassIdInstr(r1)
    //     0x12a041c: ldur            x2, [x1, #-1]
    //     0x12a0420: ubfx            x2, x2, #0xc, #0x14
    // 0x12a0424: cmp             x2, #0xbde
    // 0x12a0428: b.ne            #0x12a04e0
    // 0x12a042c: d0 = 1.000000
    //     0x12a042c: fmov            d0, #1.00000000
    // 0x12a0430: LoadField: d1 = r1->field_23
    //     0x12a0430: ldur            d1, [x1, #0x23]
    // 0x12a0434: fdiv            d2, d1, d0
    // 0x12a0438: fcmp            d2, d2
    // 0x12a043c: b.vs            #0x12a0658
    // 0x12a0440: fcvtms          x2, d2
    // 0x12a0444: asr             x16, x2, #0x1e
    // 0x12a0448: cmp             x16, x2, asr #63
    // 0x12a044c: b.ne            #0x12a0658
    // 0x12a0450: lsl             x2, x2, #1
    // 0x12a0454: LoadField: r3 = r1->field_3b
    //     0x12a0454: ldur            w3, [x1, #0x3b]
    // 0x12a0458: DecompressPointer r3
    //     0x12a0458: add             x3, x3, HEAP, lsl #32
    // 0x12a045c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12a0460: cmp             w3, w16
    // 0x12a0464: b.eq            #0x12a0684
    // 0x12a0468: stur            x3, [fp, #-0x20]
    // 0x12a046c: r4 = LoadInt32Instr(r2)
    //     0x12a046c: sbfx            x4, x2, #1, #0x1f
    //     0x12a0470: tbz             w2, #0, #0x12a0478
    //     0x12a0474: ldur            x4, [x2, #7]
    // 0x12a0478: r16 = 1000
    //     0x12a0478: mov             x16, #0x3e8
    // 0x12a047c: mul             x2, x4, x16
    // 0x12a0480: stur            x2, [fp, #-0x18]
    // 0x12a0484: r0 = Duration()
    //     0x12a0484: bl              #0x7dd0d0  ; AllocateDurationStub -> Duration (size=0x10)
    // 0x12a0488: mov             x1, x0
    // 0x12a048c: ldur            x0, [fp, #-0x18]
    // 0x12a0490: StoreField: r1->field_7 = r0
    //     0x12a0490: stur            x0, [x1, #7]
    // 0x12a0494: mov             x0, x1
    // 0x12a0498: ldur            x1, [fp, #-0x20]
    // 0x12a049c: StoreField: r1->field_27 = r0
    //     0x12a049c: stur            w0, [x1, #0x27]
    //     0x12a04a0: ldurb           w16, [x1, #-1]
    //     0x12a04a4: ldurb           w17, [x0, #-1]
    //     0x12a04a8: and             x16, x17, x16, lsr #2
    //     0x12a04ac: tst             x16, HEAP, lsr #32
    //     0x12a04b0: b.eq            #0x12a04b8
    //     0x12a04b4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12a04b8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x12a04b8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x12a04bc: r0 = forward()
    //     0x12a04bc: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x12a04c0: ldur            x0, [fp, #-0x28]
    // 0x12a04c4: LoadField: r1 = r0->field_43
    //     0x12a04c4: ldur            w1, [x0, #0x43]
    // 0x12a04c8: DecompressPointer r1
    //     0x12a04c8: add             x1, x1, HEAP, lsl #32
    // 0x12a04cc: cmp             w1, NULL
    // 0x12a04d0: b.eq            #0x12a0690
    // 0x12a04d4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x12a04d4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x12a04d8: r0 = forward()
    //     0x12a04d8: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x12a04dc: b               #0x12a0578
    // 0x12a04e0: mov             x0, x1
    // 0x12a04e4: d0 = 1.000000
    //     0x12a04e4: fmov            d0, #1.00000000
    // 0x12a04e8: cmp             x2, #0xbdf
    // 0x12a04ec: b.eq            #0x12a0578
    // 0x12a04f0: cmp             x2, #0xbe0
    // 0x12a04f4: b.ne            #0x12a0578
    // 0x12a04f8: r1 = Instance_Duration
    //     0x12a04f8: add             x1, PP, #0x99, lsl #12  ; [pp+0x99538] Obj!Duration@12c8a91
    //     0x12a04fc: ldr             x1, [x1, #0x538]
    // 0x12a0500: LoadField: r2 = r0->field_37
    //     0x12a0500: ldur            w2, [x0, #0x37]
    // 0x12a0504: DecompressPointer r2
    //     0x12a0504: add             x2, x2, HEAP, lsl #32
    // 0x12a0508: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12a050c: cmp             w2, w16
    // 0x12a0510: b.eq            #0x12a0694
    // 0x12a0514: StoreField: r2->field_27 = r1
    //     0x12a0514: stur            w1, [x2, #0x27]
    // 0x12a0518: mov             x1, x2
    // 0x12a051c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x12a051c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x12a0520: r0 = forward()
    //     0x12a0520: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x12a0524: ldur            x0, [fp, #-0x28]
    // 0x12a0528: LoadField: r1 = r0->field_3f
    //     0x12a0528: ldur            w1, [x0, #0x3f]
    // 0x12a052c: DecompressPointer r1
    //     0x12a052c: add             x1, x1, HEAP, lsl #32
    // 0x12a0530: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12a0534: cmp             w1, w16
    // 0x12a0538: b.eq            #0x12a06a0
    // 0x12a053c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x12a053c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x12a0540: r0 = forward()
    //     0x12a0540: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x12a0544: ldur            x0, [fp, #-0x28]
    // 0x12a0548: LoadField: r1 = r0->field_47
    //     0x12a0548: ldur            w1, [x0, #0x47]
    // 0x12a054c: DecompressPointer r1
    //     0x12a054c: add             x1, x1, HEAP, lsl #32
    // 0x12a0550: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12a0554: cmp             w1, w16
    // 0x12a0558: b.eq            #0x12a06ac
    // 0x12a055c: r16 = Instance_Duration
    //     0x12a055c: add             x16, PP, #0x99, lsl #12  ; [pp+0x99540] Obj!Duration@12c8a81
    //     0x12a0560: ldr             x16, [x16, #0x540]
    // 0x12a0564: str             x16, [SP]
    // 0x12a0568: d0 = 1.000000
    //     0x12a0568: fmov            d0, #1.00000000
    // 0x12a056c: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x12a056c: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x12a0570: ldr             x4, [x4, #0x5a0]
    // 0x12a0574: r0 = animateTo()
    //     0x12a0574: bl              #0x866084  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateTo
    // 0x12a0578: ldur            x0, [fp, #-8]
    // 0x12a057c: StoreField: r0->field_1b = rNULL
    //     0x12a057c: stur            NULL, [x0, #0x1b]
    // 0x12a0580: LoadField: r1 = r0->field_b
    //     0x12a0580: ldur            w1, [x0, #0xb]
    // 0x12a0584: DecompressPointer r1
    //     0x12a0584: add             x1, x1, HEAP, lsl #32
    // 0x12a0588: cmp             w1, NULL
    // 0x12a058c: b.eq            #0x12a06b8
    // 0x12a0590: LoadField: r2 = r1->field_f
    //     0x12a0590: ldur            w2, [x1, #0xf]
    // 0x12a0594: DecompressPointer r2
    //     0x12a0594: add             x2, x2, HEAP, lsl #32
    // 0x12a0598: cmp             w2, NULL
    // 0x12a059c: b.eq            #0x12a05f8
    // 0x12a05a0: LoadField: r2 = r1->field_6f
    //     0x12a05a0: ldur            w2, [x1, #0x6f]
    // 0x12a05a4: DecompressPointer r2
    //     0x12a05a4: add             x2, x2, HEAP, lsl #32
    // 0x12a05a8: tbnz            w2, #4, #0x12a05c0
    // 0x12a05ac: LoadField: r1 = r0->field_f
    //     0x12a05ac: ldur            w1, [x0, #0xf]
    // 0x12a05b0: DecompressPointer r1
    //     0x12a05b0: add             x1, x1, HEAP, lsl #32
    // 0x12a05b4: cmp             w1, NULL
    // 0x12a05b8: b.eq            #0x12a06bc
    // 0x12a05bc: r0 = forTap()
    //     0x12a05bc: bl              #0xd22aa8  ; [package:flutter/src/widgets/feedback.dart] Feedback::forTap
    // 0x12a05c0: ldur            x1, [fp, #-8]
    // 0x12a05c4: LoadField: r0 = r1->field_b
    //     0x12a05c4: ldur            w0, [x1, #0xb]
    // 0x12a05c8: DecompressPointer r0
    //     0x12a05c8: add             x0, x0, HEAP, lsl #32
    // 0x12a05cc: cmp             w0, NULL
    // 0x12a05d0: b.eq            #0x12a06c0
    // 0x12a05d4: LoadField: r2 = r0->field_f
    //     0x12a05d4: ldur            w2, [x0, #0xf]
    // 0x12a05d8: DecompressPointer r2
    //     0x12a05d8: add             x2, x2, HEAP, lsl #32
    // 0x12a05dc: cmp             w2, NULL
    // 0x12a05e0: b.eq            #0x12a05f8
    // 0x12a05e4: str             x2, [SP]
    // 0x12a05e8: mov             x0, x2
    // 0x12a05ec: ClosureCall
    //     0x12a05ec: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x12a05f0: ldur            x2, [x0, #0x1f]
    //     0x12a05f4: blr             x2
    // 0x12a05f8: ldur            x0, [fp, #-8]
    // 0x12a05fc: ldur            x2, [fp, #-0x10]
    // 0x12a0600: r1 = Function '<anonymous closure>':.
    //     0x12a0600: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3cd0] AnonymousClosure: (0x12a06c4), in [package:flutter/src/material/ink_well.dart] _InkResponseState::activateOnIntent (0x12a0390)
    //     0x12a0604: ldr             x1, [x1, #0xcd0]
    // 0x12a0608: r0 = AllocateClosure()
    //     0x12a0608: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12a060c: mov             x3, x0
    // 0x12a0610: r1 = Null
    //     0x12a0610: mov             x1, NULL
    // 0x12a0614: r2 = Instance_Duration
    //     0x12a0614: ldr             x2, [PP, #0x5668]  ; [pp+0x5668] Obj!Duration@12c8941
    // 0x12a0618: r0 = Timer()
    //     0x12a0618: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0x12a061c: ldur            x1, [fp, #-8]
    // 0x12a0620: StoreField: r1->field_33 = r0
    //     0x12a0620: stur            w0, [x1, #0x33]
    //     0x12a0624: ldurb           w16, [x1, #-1]
    //     0x12a0628: ldurb           w17, [x0, #-1]
    //     0x12a062c: and             x16, x17, x16, lsr #2
    //     0x12a0630: tst             x16, HEAP, lsr #32
    //     0x12a0634: b.eq            #0x12a063c
    //     0x12a0638: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12a063c: r0 = Null
    //     0x12a063c: mov             x0, NULL
    // 0x12a0640: LeaveFrame
    //     0x12a0640: mov             SP, fp
    //     0x12a0644: ldp             fp, lr, [SP], #0x10
    // 0x12a0648: ret
    //     0x12a0648: ret             
    // 0x12a064c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12a064c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12a0650: b               #0x12a03ac
    // 0x12a0654: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12a0654: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12a0658: SaveReg d2
    //     0x12a0658: str             q2, [SP, #-0x10]!
    // 0x12a065c: stp             x0, x1, [SP, #-0x10]!
    // 0x12a0660: d0 = 0.000000
    //     0x12a0660: fmov            d0, d2
    // 0x12a0664: r0 = 70
    //     0x12a0664: mov             x0, #0x46
    // 0x12a0668: r30 = DoubleToIntegerStub
    //     0x12a0668: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0x12a066c: LoadField: r30 = r30->field_7
    //     0x12a066c: ldur            lr, [lr, #7]
    // 0x12a0670: blr             lr
    // 0x12a0674: mov             x2, x0
    // 0x12a0678: ldp             x0, x1, [SP], #0x10
    // 0x12a067c: RestoreReg d2
    //     0x12a067c: ldr             q2, [SP], #0x10
    // 0x12a0680: b               #0x12a0454
    // 0x12a0684: r9 = _radiusController
    //     0x12a0684: add             x9, PP, #0x99, lsl #12  ; [pp+0x99548] Field <InkSplash._radiusController@757036029>: late (offset: 0x3c)
    //     0x12a0688: ldr             x9, [x9, #0x548]
    // 0x12a068c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12a068c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12a0690: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12a0690: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12a0694: r9 = _radiusController
    //     0x12a0694: add             x9, PP, #0x99, lsl #12  ; [pp+0x99550] Field <InkRipple._radiusController@755110234>: late (offset: 0x38)
    //     0x12a0698: ldr             x9, [x9, #0x550]
    // 0x12a069c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x12a069c: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x12a06a0: r9 = _fadeInController
    //     0x12a06a0: add             x9, PP, #0x99, lsl #12  ; [pp+0x99528] Field <InkRipple._fadeInController@755110234>: late (offset: 0x40)
    //     0x12a06a4: ldr             x9, [x9, #0x528]
    // 0x12a06a8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12a06a8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12a06ac: r9 = _fadeOutController
    //     0x12a06ac: add             x9, PP, #0x99, lsl #12  ; [pp+0x99530] Field <InkRipple._fadeOutController@755110234>: late (offset: 0x48)
    //     0x12a06b0: ldr             x9, [x9, #0x530]
    // 0x12a06b4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12a06b4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12a06b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12a06b8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12a06bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12a06bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12a06c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12a06c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x12a06c4, size: 0x58
    // 0x12a06c4: EnterFrame
    //     0x12a06c4: stp             fp, lr, [SP, #-0x10]!
    //     0x12a06c8: mov             fp, SP
    // 0x12a06cc: ldr             x0, [fp, #0x10]
    // 0x12a06d0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x12a06d0: ldur            w1, [x0, #0x17]
    // 0x12a06d4: DecompressPointer r1
    //     0x12a06d4: add             x1, x1, HEAP, lsl #32
    // 0x12a06d8: CheckStackOverflow
    //     0x12a06d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12a06dc: cmp             SP, x16
    //     0x12a06e0: b.ls            #0x12a0714
    // 0x12a06e4: LoadField: r0 = r1->field_f
    //     0x12a06e4: ldur            w0, [x1, #0xf]
    // 0x12a06e8: DecompressPointer r0
    //     0x12a06e8: add             x0, x0, HEAP, lsl #32
    // 0x12a06ec: mov             x1, x0
    // 0x12a06f0: r2 = Instance__HighlightType
    //     0x12a06f0: add             x2, PP, #0x99, lsl #12  ; [pp+0x994d0] Obj!_HighlightType@12c5741
    //     0x12a06f4: ldr             x2, [x2, #0x4d0]
    // 0x12a06f8: r3 = false
    //     0x12a06f8: add             x3, NULL, #0x30  ; false
    // 0x12a06fc: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x12a06fc: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x12a0700: r0 = updateHighlight()
    //     0x12a0700: bl              #0xd21118  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::updateHighlight
    // 0x12a0704: r0 = Null
    //     0x12a0704: mov             x0, NULL
    // 0x12a0708: LeaveFrame
    //     0x12a0708: mov             SP, fp
    //     0x12a070c: ldp             fp, lr, [SP], #0x10
    // 0x12a0710: ret
    //     0x12a0710: ret             
    // 0x12a0714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12a0714: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12a0718: b               #0x12a06e4
  }
}

// class id: 6170, size: 0x94, field offset: 0xc
//   const constructor, 
class InkResponse extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfb5ce0, size: 0x2f8
    // 0xfb5ce0: EnterFrame
    //     0xfb5ce0: stp             fp, lr, [SP, #-0x10]!
    //     0xfb5ce4: mov             fp, SP
    // 0xfb5ce8: AllocStack(0xd8)
    //     0xfb5ce8: sub             SP, SP, #0xd8
    // 0xfb5cec: SetupParameters(InkResponse this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xfb5cec: stur            x1, [fp, #-8]
    //     0xfb5cf0: mov             x16, x2
    //     0xfb5cf4: mov             x2, x1
    //     0xfb5cf8: mov             x1, x16
    // 0xfb5cfc: CheckStackOverflow
    //     0xfb5cfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb5d00: cmp             SP, x16
    //     0xfb5d04: b.ls            #0xfb5fd0
    // 0xfb5d08: r0 = maybeOf()
    //     0xfb5d08: bl              #0xfb5fe4  ; [package:flutter/src/material/ink_well.dart] _ParentInkResponseProvider::maybeOf
    // 0xfb5d0c: mov             x3, x0
    // 0xfb5d10: ldur            x0, [fp, #-8]
    // 0xfb5d14: stur            x3, [fp, #-0x10]
    // 0xfb5d18: LoadField: r4 = r0->field_f
    //     0xfb5d18: ldur            w4, [x0, #0xf]
    // 0xfb5d1c: DecompressPointer r4
    //     0xfb5d1c: add             x4, x4, HEAP, lsl #32
    // 0xfb5d20: stur            x4, [fp, #-0x18]
    // 0xfb5d24: LoadField: r5 = r0->field_13
    //     0xfb5d24: ldur            w5, [x0, #0x13]
    // 0xfb5d28: DecompressPointer r5
    //     0xfb5d28: add             x5, x5, HEAP, lsl #32
    // 0xfb5d2c: stur            x5, [fp, #-0x20]
    // 0xfb5d30: ArrayLoad: r6 = r0[0]  ; List_4
    //     0xfb5d30: ldur            w6, [x0, #0x17]
    // 0xfb5d34: DecompressPointer r6
    //     0xfb5d34: add             x6, x6, HEAP, lsl #32
    // 0xfb5d38: stur            x6, [fp, #-0x28]
    // 0xfb5d3c: LoadField: r7 = r0->field_3b
    //     0xfb5d3c: ldur            w7, [x0, #0x3b]
    // 0xfb5d40: DecompressPointer r7
    //     0xfb5d40: add             x7, x7, HEAP, lsl #32
    // 0xfb5d44: stur            x7, [fp, #-0x30]
    // 0xfb5d48: LoadField: r8 = r0->field_3f
    //     0xfb5d48: ldur            w8, [x0, #0x3f]
    // 0xfb5d4c: DecompressPointer r8
    //     0xfb5d4c: add             x8, x8, HEAP, lsl #32
    // 0xfb5d50: stur            x8, [fp, #-0xc0]
    // 0xfb5d54: LoadField: r9 = r0->field_43
    //     0xfb5d54: ldur            w9, [x0, #0x43]
    // 0xfb5d58: DecompressPointer r9
    //     0xfb5d58: add             x9, x9, HEAP, lsl #32
    // 0xfb5d5c: stur            x9, [fp, #-0xb8]
    // 0xfb5d60: LoadField: r10 = r0->field_47
    //     0xfb5d60: ldur            w10, [x0, #0x47]
    // 0xfb5d64: DecompressPointer r10
    //     0xfb5d64: add             x10, x10, HEAP, lsl #32
    // 0xfb5d68: stur            x10, [fp, #-0xb0]
    // 0xfb5d6c: LoadField: r11 = r0->field_4b
    //     0xfb5d6c: ldur            w11, [x0, #0x4b]
    // 0xfb5d70: DecompressPointer r11
    //     0xfb5d70: add             x11, x11, HEAP, lsl #32
    // 0xfb5d74: stur            x11, [fp, #-0xa8]
    // 0xfb5d78: LoadField: r12 = r0->field_4f
    //     0xfb5d78: ldur            w12, [x0, #0x4f]
    // 0xfb5d7c: DecompressPointer r12
    //     0xfb5d7c: add             x12, x12, HEAP, lsl #32
    // 0xfb5d80: stur            x12, [fp, #-0xa0]
    // 0xfb5d84: LoadField: r13 = r0->field_53
    //     0xfb5d84: ldur            w13, [x0, #0x53]
    // 0xfb5d88: DecompressPointer r13
    //     0xfb5d88: add             x13, x13, HEAP, lsl #32
    // 0xfb5d8c: stur            x13, [fp, #-0x98]
    // 0xfb5d90: LoadField: r14 = r0->field_57
    //     0xfb5d90: ldur            w14, [x0, #0x57]
    // 0xfb5d94: DecompressPointer r14
    //     0xfb5d94: add             x14, x14, HEAP, lsl #32
    // 0xfb5d98: stur            x14, [fp, #-0x90]
    // 0xfb5d9c: LoadField: r19 = r0->field_5b
    //     0xfb5d9c: ldur            w19, [x0, #0x5b]
    // 0xfb5da0: DecompressPointer r19
    //     0xfb5da0: add             x19, x19, HEAP, lsl #32
    // 0xfb5da4: stur            x19, [fp, #-0x88]
    // 0xfb5da8: LoadField: r20 = r0->field_5f
    //     0xfb5da8: ldur            w20, [x0, #0x5f]
    // 0xfb5dac: DecompressPointer r20
    //     0xfb5dac: add             x20, x20, HEAP, lsl #32
    // 0xfb5db0: stur            x20, [fp, #-0x80]
    // 0xfb5db4: LoadField: r23 = r0->field_63
    //     0xfb5db4: ldur            w23, [x0, #0x63]
    // 0xfb5db8: DecompressPointer r23
    //     0xfb5db8: add             x23, x23, HEAP, lsl #32
    // 0xfb5dbc: stur            x23, [fp, #-0x78]
    // 0xfb5dc0: LoadField: r24 = r0->field_67
    //     0xfb5dc0: ldur            w24, [x0, #0x67]
    // 0xfb5dc4: DecompressPointer r24
    //     0xfb5dc4: add             x24, x24, HEAP, lsl #32
    // 0xfb5dc8: stur            x24, [fp, #-0x70]
    // 0xfb5dcc: LoadField: r25 = r0->field_6b
    //     0xfb5dcc: ldur            w25, [x0, #0x6b]
    // 0xfb5dd0: DecompressPointer r25
    //     0xfb5dd0: add             x25, x25, HEAP, lsl #32
    // 0xfb5dd4: stur            x25, [fp, #-0x68]
    // 0xfb5dd8: LoadField: r1 = r0->field_6f
    //     0xfb5dd8: ldur            w1, [x0, #0x6f]
    // 0xfb5ddc: DecompressPointer r1
    //     0xfb5ddc: add             x1, x1, HEAP, lsl #32
    // 0xfb5de0: stur            x1, [fp, #-0x38]
    // 0xfb5de4: LoadField: r2 = r0->field_73
    //     0xfb5de4: ldur            w2, [x0, #0x73]
    // 0xfb5de8: DecompressPointer r2
    //     0xfb5de8: add             x2, x2, HEAP, lsl #32
    // 0xfb5dec: stur            x2, [fp, #-0x40]
    // 0xfb5df0: LoadField: r3 = r0->field_83
    //     0xfb5df0: ldur            w3, [x0, #0x83]
    // 0xfb5df4: DecompressPointer r3
    //     0xfb5df4: add             x3, x3, HEAP, lsl #32
    // 0xfb5df8: stur            x3, [fp, #-0x48]
    // 0xfb5dfc: LoadField: r4 = r0->field_87
    //     0xfb5dfc: ldur            w4, [x0, #0x87]
    // 0xfb5e00: DecompressPointer r4
    //     0xfb5e00: add             x4, x4, HEAP, lsl #32
    // 0xfb5e04: stur            x4, [fp, #-0x50]
    // 0xfb5e08: LoadField: r5 = r0->field_7b
    //     0xfb5e08: ldur            w5, [x0, #0x7b]
    // 0xfb5e0c: DecompressPointer r5
    //     0xfb5e0c: add             x5, x5, HEAP, lsl #32
    // 0xfb5e10: stur            x5, [fp, #-0x58]
    // 0xfb5e14: LoadField: r6 = r0->field_7f
    //     0xfb5e14: ldur            w6, [x0, #0x7f]
    // 0xfb5e18: DecompressPointer r6
    //     0xfb5e18: add             x6, x6, HEAP, lsl #32
    // 0xfb5e1c: stur            x6, [fp, #-0x60]
    // 0xfb5e20: r7 = LoadClassIdInstr(r0)
    //     0xfb5e20: ldur            x7, [x0, #-1]
    //     0xfb5e24: ubfx            x7, x7, #0xc, #0x14
    // 0xfb5e28: r17 = -6170
    //     0xfb5e28: mov             x17, #-0x181a
    // 0xfb5e2c: add             x16, x7, x17
    // 0xfb5e30: cmp             x16, #1
    // 0xfb5e34: b.hi            #0xfb5e6c
    // 0xfb5e38: mov             x16, x6
    // 0xfb5e3c: mov             x6, x3
    // 0xfb5e40: mov             x3, x16
    // 0xfb5e44: mov             x16, x5
    // 0xfb5e48: mov             x5, x4
    // 0xfb5e4c: mov             x4, x16
    // 0xfb5e50: mov             x7, x2
    // 0xfb5e54: mov             x2, x0
    // 0xfb5e58: r1 = Function 'getRectCallback':.
    //     0xfb5e58: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a80] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xfb5e5c: ldr             x1, [x1, #0xa80]
    // 0xfb5e60: r0 = AllocateClosure()
    //     0xfb5e60: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfb5e64: stur            x0, [fp, #-0xc8]
    // 0xfb5e68: b               #0xfb5e80
    // 0xfb5e6c: ldur            x2, [fp, #-8]
    // 0xfb5e70: r1 = Function 'getRectCallback':.
    //     0xfb5e70: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a88] AnonymousClosure: (0xfb6040), of [package:flutter/src/material/data_table.dart] TableRowInkWell
    //     0xfb5e74: ldr             x1, [x1, #0xa88]
    // 0xfb5e78: r0 = AllocateClosure()
    //     0xfb5e78: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfb5e7c: stur            x0, [fp, #-0xc8]
    // 0xfb5e80: ldur            x0, [fp, #-8]
    // 0xfb5e84: ldur            x1, [fp, #-0x10]
    // 0xfb5e88: ldur            x2, [fp, #-0x18]
    // 0xfb5e8c: ldur            x3, [fp, #-0x20]
    // 0xfb5e90: ldur            x4, [fp, #-0x28]
    // 0xfb5e94: ldur            x5, [fp, #-0x30]
    // 0xfb5e98: ldur            x6, [fp, #-0xc0]
    // 0xfb5e9c: ldur            x7, [fp, #-0xb8]
    // 0xfb5ea0: ldur            x8, [fp, #-0xb0]
    // 0xfb5ea4: ldur            x9, [fp, #-0xa8]
    // 0xfb5ea8: ldur            x10, [fp, #-0xa0]
    // 0xfb5eac: ldur            x11, [fp, #-0x98]
    // 0xfb5eb0: ldur            x12, [fp, #-0x90]
    // 0xfb5eb4: ldur            x13, [fp, #-0x88]
    // 0xfb5eb8: ldur            x14, [fp, #-0x80]
    // 0xfb5ebc: ldur            x19, [fp, #-0x78]
    // 0xfb5ec0: ldur            x20, [fp, #-0x70]
    // 0xfb5ec4: ldur            x23, [fp, #-0x68]
    // 0xfb5ec8: ldur            x25, [fp, #-0x58]
    // 0xfb5ecc: ldur            x24, [fp, #-0x60]
    // 0xfb5ed0: LoadField: r1 = r0->field_8b
    //     0xfb5ed0: ldur            w1, [x0, #0x8b]
    // 0xfb5ed4: DecompressPointer r1
    //     0xfb5ed4: add             x1, x1, HEAP, lsl #32
    // 0xfb5ed8: stur            x1, [fp, #-0xd0]
    // 0xfb5edc: LoadField: r2 = r0->field_b
    //     0xfb5edc: ldur            w2, [x0, #0xb]
    // 0xfb5ee0: DecompressPointer r2
    //     0xfb5ee0: add             x2, x2, HEAP, lsl #32
    // 0xfb5ee4: stur            x2, [fp, #-0xd8]
    // 0xfb5ee8: r0 = _InkResponseStateWidget()
    //     0xfb5ee8: bl              #0xfb5fd8  ; Allocate_InkResponseStateWidgetStub -> _InkResponseStateWidget (size=0x98)
    // 0xfb5eec: ldur            x1, [fp, #-0xd8]
    // 0xfb5ef0: StoreField: r0->field_b = r1
    //     0xfb5ef0: stur            w1, [x0, #0xb]
    // 0xfb5ef4: ldur            x1, [fp, #-0x18]
    // 0xfb5ef8: StoreField: r0->field_f = r1
    //     0xfb5ef8: stur            w1, [x0, #0xf]
    // 0xfb5efc: ldur            x1, [fp, #-0x20]
    // 0xfb5f00: StoreField: r0->field_13 = r1
    //     0xfb5f00: stur            w1, [x0, #0x13]
    // 0xfb5f04: ldur            x1, [fp, #-0x28]
    // 0xfb5f08: ArrayStore: r0[0] = r1  ; List_4
    //     0xfb5f08: stur            w1, [x0, #0x17]
    // 0xfb5f0c: ldur            x1, [fp, #-0x30]
    // 0xfb5f10: StoreField: r0->field_37 = r1
    //     0xfb5f10: stur            w1, [x0, #0x37]
    // 0xfb5f14: ldur            x1, [fp, #-0xc0]
    // 0xfb5f18: StoreField: r0->field_3b = r1
    //     0xfb5f18: stur            w1, [x0, #0x3b]
    // 0xfb5f1c: ldur            x1, [fp, #-0xb8]
    // 0xfb5f20: StoreField: r0->field_3f = r1
    //     0xfb5f20: stur            w1, [x0, #0x3f]
    // 0xfb5f24: ldur            x1, [fp, #-0xb0]
    // 0xfb5f28: StoreField: r0->field_43 = r1
    //     0xfb5f28: stur            w1, [x0, #0x43]
    // 0xfb5f2c: ldur            x1, [fp, #-0xa8]
    // 0xfb5f30: StoreField: r0->field_47 = r1
    //     0xfb5f30: stur            w1, [x0, #0x47]
    // 0xfb5f34: ldur            x1, [fp, #-0xa0]
    // 0xfb5f38: StoreField: r0->field_4b = r1
    //     0xfb5f38: stur            w1, [x0, #0x4b]
    // 0xfb5f3c: ldur            x1, [fp, #-0x98]
    // 0xfb5f40: StoreField: r0->field_4f = r1
    //     0xfb5f40: stur            w1, [x0, #0x4f]
    // 0xfb5f44: ldur            x1, [fp, #-0x90]
    // 0xfb5f48: StoreField: r0->field_53 = r1
    //     0xfb5f48: stur            w1, [x0, #0x53]
    // 0xfb5f4c: ldur            x1, [fp, #-0x88]
    // 0xfb5f50: StoreField: r0->field_57 = r1
    //     0xfb5f50: stur            w1, [x0, #0x57]
    // 0xfb5f54: ldur            x1, [fp, #-0x80]
    // 0xfb5f58: StoreField: r0->field_5b = r1
    //     0xfb5f58: stur            w1, [x0, #0x5b]
    // 0xfb5f5c: ldur            x1, [fp, #-0x78]
    // 0xfb5f60: StoreField: r0->field_5f = r1
    //     0xfb5f60: stur            w1, [x0, #0x5f]
    // 0xfb5f64: ldur            x1, [fp, #-0x70]
    // 0xfb5f68: StoreField: r0->field_63 = r1
    //     0xfb5f68: stur            w1, [x0, #0x63]
    // 0xfb5f6c: ldur            x1, [fp, #-0x68]
    // 0xfb5f70: StoreField: r0->field_67 = r1
    //     0xfb5f70: stur            w1, [x0, #0x67]
    // 0xfb5f74: ldur            x1, [fp, #-0x38]
    // 0xfb5f78: StoreField: r0->field_6b = r1
    //     0xfb5f78: stur            w1, [x0, #0x6b]
    // 0xfb5f7c: ldur            x1, [fp, #-0x40]
    // 0xfb5f80: StoreField: r0->field_6f = r1
    //     0xfb5f80: stur            w1, [x0, #0x6f]
    // 0xfb5f84: r1 = false
    //     0xfb5f84: add             x1, NULL, #0x30  ; false
    // 0xfb5f88: StoreField: r0->field_73 = r1
    //     0xfb5f88: stur            w1, [x0, #0x73]
    // 0xfb5f8c: ldur            x1, [fp, #-0x48]
    // 0xfb5f90: StoreField: r0->field_7f = r1
    //     0xfb5f90: stur            w1, [x0, #0x7f]
    // 0xfb5f94: ldur            x1, [fp, #-0x50]
    // 0xfb5f98: StoreField: r0->field_83 = r1
    //     0xfb5f98: stur            w1, [x0, #0x83]
    // 0xfb5f9c: ldur            x1, [fp, #-0x58]
    // 0xfb5fa0: StoreField: r0->field_77 = r1
    //     0xfb5fa0: stur            w1, [x0, #0x77]
    // 0xfb5fa4: ldur            x1, [fp, #-0x60]
    // 0xfb5fa8: StoreField: r0->field_7b = r1
    //     0xfb5fa8: stur            w1, [x0, #0x7b]
    // 0xfb5fac: ldur            x1, [fp, #-0x10]
    // 0xfb5fb0: StoreField: r0->field_87 = r1
    //     0xfb5fb0: stur            w1, [x0, #0x87]
    // 0xfb5fb4: ldur            x1, [fp, #-0xc8]
    // 0xfb5fb8: StoreField: r0->field_8b = r1
    //     0xfb5fb8: stur            w1, [x0, #0x8b]
    // 0xfb5fbc: ldur            x1, [fp, #-0xd0]
    // 0xfb5fc0: StoreField: r0->field_8f = r1
    //     0xfb5fc0: stur            w1, [x0, #0x8f]
    // 0xfb5fc4: LeaveFrame
    //     0xfb5fc4: mov             SP, fp
    //     0xfb5fc8: ldp             fp, lr, [SP], #0x10
    // 0xfb5fcc: ret
    //     0xfb5fcc: ret             
    // 0xfb5fd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb5fd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb5fd4: b               #0xfb5d08
  }
}

// class id: 6171, size: 0x94, field offset: 0x94
//   const constructor, 
class InkWell extends InkResponse {
}

// class id: 6473, size: 0x98, field offset: 0xc
//   const constructor, 
class _InkResponseStateWidget extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa1a50, size: 0x48
    // 0xfa1a50: EnterFrame
    //     0xfa1a50: stp             fp, lr, [SP, #-0x10]!
    //     0xfa1a54: mov             fp, SP
    // 0xfa1a58: AllocStack(0x8)
    //     0xfa1a58: sub             SP, SP, #8
    // 0xfa1a5c: CheckStackOverflow
    //     0xfa1a5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa1a60: cmp             SP, x16
    //     0xfa1a64: b.ls            #0xfa1a90
    // 0xfa1a68: r1 = <_InkResponseStateWidget>
    //     0xfa1a68: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8fd30] TypeArguments: <_InkResponseStateWidget>
    //     0xfa1a6c: ldr             x1, [x1, #0xd30]
    // 0xfa1a70: r0 = _InkResponseState()
    //     0xfa1a70: bl              #0xfa1b8c  ; Allocate_InkResponseStateStub -> _InkResponseState (size=0x3c)
    // 0xfa1a74: mov             x1, x0
    // 0xfa1a78: stur            x0, [fp, #-8]
    // 0xfa1a7c: r0 = _InkResponseState()
    //     0xfa1a7c: bl              #0xfa1a98  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::_InkResponseState
    // 0xfa1a80: ldur            x0, [fp, #-8]
    // 0xfa1a84: LeaveFrame
    //     0xfa1a84: mov             SP, fp
    //     0xfa1a88: ldp             fp, lr, [SP], #0x10
    // 0xfa1a8c: ret
    //     0xfa1a8c: ret             
    // 0xfa1a90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa1a90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa1a94: b               #0xfa1a68
  }
}

// class id: 6812, size: 0x14, field offset: 0x10
//   const constructor, 
class _ParentInkResponseProvider extends InheritedWidget {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xc00fe8, size: 0x8c
    // 0xc00fe8: EnterFrame
    //     0xc00fe8: stp             fp, lr, [SP, #-0x10]!
    //     0xc00fec: mov             fp, SP
    // 0xc00ff0: AllocStack(0x10)
    //     0xc00ff0: sub             SP, SP, #0x10
    // 0xc00ff4: SetupParameters(_ParentInkResponseProvider this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc00ff4: mov             x0, x2
    //     0xc00ff8: mov             x4, x1
    //     0xc00ffc: mov             x3, x2
    //     0xc01000: stur            x1, [fp, #-8]
    //     0xc01004: stur            x2, [fp, #-0x10]
    // 0xc01008: r2 = Null
    //     0xc01008: mov             x2, NULL
    // 0xc0100c: r1 = Null
    //     0xc0100c: mov             x1, NULL
    // 0xc01010: r4 = 60
    //     0xc01010: mov             x4, #0x3c
    // 0xc01014: branchIfSmi(r0, 0xc01020)
    //     0xc01014: tbz             w0, #0, #0xc01020
    // 0xc01018: r4 = LoadClassIdInstr(r0)
    //     0xc01018: ldur            x4, [x0, #-1]
    //     0xc0101c: ubfx            x4, x4, #0xc, #0x14
    // 0xc01020: r17 = 6812
    //     0xc01020: mov             x17, #0x1a9c
    // 0xc01024: cmp             x4, x17
    // 0xc01028: b.eq            #0xc01040
    // 0xc0102c: r8 = _ParentInkResponseProvider
    //     0xc0102c: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3ce0] Type: _ParentInkResponseProvider
    //     0xc01030: ldr             x8, [x8, #0xce0]
    // 0xc01034: r3 = Null
    //     0xc01034: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3ce8] Null
    //     0xc01038: ldr             x3, [x3, #0xce8]
    // 0xc0103c: r0 = DefaultTypeTest()
    //     0xc0103c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc01040: ldur            x1, [fp, #-8]
    // 0xc01044: LoadField: r2 = r1->field_f
    //     0xc01044: ldur            w2, [x1, #0xf]
    // 0xc01048: DecompressPointer r2
    //     0xc01048: add             x2, x2, HEAP, lsl #32
    // 0xc0104c: ldur            x1, [fp, #-0x10]
    // 0xc01050: LoadField: r3 = r1->field_f
    //     0xc01050: ldur            w3, [x1, #0xf]
    // 0xc01054: DecompressPointer r3
    //     0xc01054: add             x3, x3, HEAP, lsl #32
    // 0xc01058: cmp             w2, w3
    // 0xc0105c: r16 = true
    //     0xc0105c: add             x16, NULL, #0x20  ; true
    // 0xc01060: r17 = false
    //     0xc01060: add             x17, NULL, #0x30  ; false
    // 0xc01064: csel            x0, x16, x17, ne
    // 0xc01068: LeaveFrame
    //     0xc01068: mov             SP, fp
    //     0xc0106c: ldp             fp, lr, [SP], #0x10
    // 0xc01070: ret
    //     0xc01070: ret             
  }
  static _ maybeOf(/* No info */) {
    // ** addr: 0xfb5fe4, size: 0x5c
    // 0xfb5fe4: EnterFrame
    //     0xfb5fe4: stp             fp, lr, [SP, #-0x10]!
    //     0xfb5fe8: mov             fp, SP
    // 0xfb5fec: AllocStack(0x10)
    //     0xfb5fec: sub             SP, SP, #0x10
    // 0xfb5ff0: CheckStackOverflow
    //     0xfb5ff0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb5ff4: cmp             SP, x16
    //     0xfb5ff8: b.ls            #0xfb6038
    // 0xfb5ffc: r16 = <_ParentInkResponseProvider>
    //     0xfb5ffc: add             x16, PP, #0x84, lsl #12  ; [pp+0x84ab0] TypeArguments: <_ParentInkResponseProvider>
    //     0xfb6000: ldr             x16, [x16, #0xab0]
    // 0xfb6004: stp             x1, x16, [SP]
    // 0xfb6008: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xfb6008: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xfb600c: r0 = dependOnInheritedWidgetOfExactType()
    //     0xfb600c: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xfb6010: cmp             w0, NULL
    // 0xfb6014: b.ne            #0xfb6020
    // 0xfb6018: r0 = Null
    //     0xfb6018: mov             x0, NULL
    // 0xfb601c: b               #0xfb602c
    // 0xfb6020: LoadField: r1 = r0->field_f
    //     0xfb6020: ldur            w1, [x0, #0xf]
    // 0xfb6024: DecompressPointer r1
    //     0xfb6024: add             x1, x1, HEAP, lsl #32
    // 0xfb6028: mov             x0, x1
    // 0xfb602c: LeaveFrame
    //     0xfb602c: mov             SP, fp
    //     0xfb6030: ldp             fp, lr, [SP], #0x10
    // 0xfb6034: ret
    //     0xfb6034: ret             
    // 0xfb6038: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb6038: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb603c: b               #0xfb5ffc
  }
}

// class id: 8286, size: 0x14, field offset: 0x14
enum _HighlightType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa15c, size: 0x64
    // 0x11aa15c: EnterFrame
    //     0x11aa15c: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa160: mov             fp, SP
    // 0x11aa164: AllocStack(0x10)
    //     0x11aa164: sub             SP, SP, #0x10
    // 0x11aa168: SetupParameters(_HighlightType this /* r1 => r0, fp-0x8 */)
    //     0x11aa168: mov             x0, x1
    //     0x11aa16c: stur            x1, [fp, #-8]
    // 0x11aa170: CheckStackOverflow
    //     0x11aa170: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa174: cmp             SP, x16
    //     0x11aa178: b.ls            #0x11aa1b8
    // 0x11aa17c: r1 = Null
    //     0x11aa17c: mov             x1, NULL
    // 0x11aa180: r2 = 4
    //     0x11aa180: mov             x2, #4
    // 0x11aa184: r0 = AllocateArray()
    //     0x11aa184: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa188: r16 = "_HighlightType."
    //     0x11aa188: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3cd8] "_HighlightType."
    //     0x11aa18c: ldr             x16, [x16, #0xcd8]
    // 0x11aa190: StoreField: r0->field_f = r16
    //     0x11aa190: stur            w16, [x0, #0xf]
    // 0x11aa194: ldur            x1, [fp, #-8]
    // 0x11aa198: LoadField: r2 = r1->field_f
    //     0x11aa198: ldur            w2, [x1, #0xf]
    // 0x11aa19c: DecompressPointer r2
    //     0x11aa19c: add             x2, x2, HEAP, lsl #32
    // 0x11aa1a0: StoreField: r0->field_13 = r2
    //     0x11aa1a0: stur            w2, [x0, #0x13]
    // 0x11aa1a4: str             x0, [SP]
    // 0x11aa1a8: r0 = _interpolate()
    //     0x11aa1a8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa1ac: LeaveFrame
    //     0x11aa1ac: mov             SP, fp
    //     0x11aa1b0: ldp             fp, lr, [SP], #0x10
    // 0x11aa1b4: ret
    //     0x11aa1b4: ret             
    // 0x11aa1b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa1b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa1bc: b               #0x11aa17c
  }
}
