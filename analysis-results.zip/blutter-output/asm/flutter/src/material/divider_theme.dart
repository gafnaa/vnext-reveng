// lib: , url: package:flutter/src/material/divider_theme.dart

// class id: 1048883, size: 0x8
class :: {
}

// class id: 5160, size: 0x20, field offset: 0x8
//   const constructor, 
class DividerThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x1132d6c, size: 0x100
    // 0x1132d6c: EnterFrame
    //     0x1132d6c: stp             fp, lr, [SP, #-0x10]!
    //     0x1132d70: mov             fp, SP
    // 0x1132d74: AllocStack(0x20)
    //     0x1132d74: sub             SP, SP, #0x20
    // 0x1132d78: CheckStackOverflow
    //     0x1132d78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1132d7c: cmp             SP, x16
    //     0x1132d80: b.ls            #0x1132e64
    // 0x1132d84: ldr             x0, [fp, #0x10]
    // 0x1132d88: r1 = LoadClassIdInstr(r0)
    //     0x1132d88: ldur            x1, [x0, #-1]
    //     0x1132d8c: ubfx            x1, x1, #0xc, #0x14
    // 0x1132d90: r17 = 5160
    //     0x1132d90: mov             x17, #0x1428
    // 0x1132d94: cmp             x1, x17
    // 0x1132d98: b.ne            #0x1132da8
    // 0x1132d9c: LoadField: r1 = r0->field_7
    //     0x1132d9c: ldur            w1, [x0, #7]
    // 0x1132da0: DecompressPointer r1
    //     0x1132da0: add             x1, x1, HEAP, lsl #32
    // 0x1132da4: b               #0x1132e04
    // 0x1132da8: r17 = 5161
    //     0x1132da8: mov             x17, #0x1429
    // 0x1132dac: cmp             x1, x17
    // 0x1132db0: b.ne            #0x1132dec
    // 0x1132db4: LoadField: r1 = r0->field_1f
    //     0x1132db4: ldur            w1, [x0, #0x1f]
    // 0x1132db8: DecompressPointer r1
    //     0x1132db8: add             x1, x1, HEAP, lsl #32
    // 0x1132dbc: r0 = of()
    //     0x1132dbc: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1132dc0: LoadField: r1 = r0->field_3f
    //     0x1132dc0: ldur            w1, [x0, #0x3f]
    // 0x1132dc4: DecompressPointer r1
    //     0x1132dc4: add             x1, x1, HEAP, lsl #32
    // 0x1132dc8: LoadField: r0 = r1->field_ab
    //     0x1132dc8: ldur            w0, [x1, #0xab]
    // 0x1132dcc: DecompressPointer r0
    //     0x1132dcc: add             x0, x0, HEAP, lsl #32
    // 0x1132dd0: cmp             w0, NULL
    // 0x1132dd4: b.ne            #0x1132de0
    // 0x1132dd8: LoadField: r0 = r1->field_cb
    //     0x1132dd8: ldur            w0, [x1, #0xcb]
    // 0x1132ddc: DecompressPointer r0
    //     0x1132ddc: add             x0, x0, HEAP, lsl #32
    // 0x1132de0: mov             x1, x0
    // 0x1132de4: ldr             x0, [fp, #0x10]
    // 0x1132de8: b               #0x1132e04
    // 0x1132dec: LoadField: r1 = r0->field_1f
    //     0x1132dec: ldur            w1, [x0, #0x1f]
    // 0x1132df0: DecompressPointer r1
    //     0x1132df0: add             x1, x1, HEAP, lsl #32
    // 0x1132df4: r0 = of()
    //     0x1132df4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1132df8: LoadField: r1 = r0->field_47
    //     0x1132df8: ldur            w1, [x0, #0x47]
    // 0x1132dfc: DecompressPointer r1
    //     0x1132dfc: add             x1, x1, HEAP, lsl #32
    // 0x1132e00: ldr             x0, [fp, #0x10]
    // 0x1132e04: LoadField: r2 = r0->field_b
    //     0x1132e04: ldur            w2, [x0, #0xb]
    // 0x1132e08: DecompressPointer r2
    //     0x1132e08: add             x2, x2, HEAP, lsl #32
    // 0x1132e0c: LoadField: r3 = r0->field_f
    //     0x1132e0c: ldur            w3, [x0, #0xf]
    // 0x1132e10: DecompressPointer r3
    //     0x1132e10: add             x3, x3, HEAP, lsl #32
    // 0x1132e14: LoadField: r4 = r0->field_13
    //     0x1132e14: ldur            w4, [x0, #0x13]
    // 0x1132e18: DecompressPointer r4
    //     0x1132e18: add             x4, x4, HEAP, lsl #32
    // 0x1132e1c: ArrayLoad: r5 = r0[0]  ; List_4
    //     0x1132e1c: ldur            w5, [x0, #0x17]
    // 0x1132e20: DecompressPointer r5
    //     0x1132e20: add             x5, x5, HEAP, lsl #32
    // 0x1132e24: LoadField: r6 = r0->field_1b
    //     0x1132e24: ldur            w6, [x0, #0x1b]
    // 0x1132e28: DecompressPointer r6
    //     0x1132e28: add             x6, x6, HEAP, lsl #32
    // 0x1132e2c: stp             x4, x3, [SP, #0x10]
    // 0x1132e30: stp             x6, x5, [SP]
    // 0x1132e34: r4 = const [0, 0x6, 0x4, 0x6, null]
    //     0x1132e34: add             x4, PP, #0xd, lsl #12  ; [pp+0xdd28] List(5) [0, 0x6, 0x4, 0x6, Null]
    //     0x1132e38: ldr             x4, [x4, #0xd28]
    // 0x1132e3c: r0 = hash()
    //     0x1132e3c: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1132e40: mov             x2, x0
    // 0x1132e44: r0 = BoxInt64Instr(r2)
    //     0x1132e44: sbfiz           x0, x2, #1, #0x1f
    //     0x1132e48: cmp             x2, x0, asr #1
    //     0x1132e4c: b.eq            #0x1132e58
    //     0x1132e50: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1132e54: stur            x2, [x0, #7]
    // 0x1132e58: LeaveFrame
    //     0x1132e58: mov             SP, fp
    //     0x1132e5c: ldp             fp, lr, [SP], #0x10
    // 0x1132e60: ret
    //     0x1132e60: ret             
    // 0x1132e64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1132e64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1132e68: b               #0x1132d84
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x116770c, size: 0x1a4
    // 0x116770c: EnterFrame
    //     0x116770c: stp             fp, lr, [SP, #-0x10]!
    //     0x1167710: mov             fp, SP
    // 0x1167714: AllocStack(0x38)
    //     0x1167714: sub             SP, SP, #0x38
    // 0x1167718: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x38 */)
    //     0x1167718: mov             x4, x1
    //     0x116771c: mov             x0, x2
    //     0x1167720: stur            x1, [fp, #-0x10]
    //     0x1167724: stur            x2, [fp, #-0x18]
    //     0x1167728: stur            d0, [fp, #-0x38]
    // 0x116772c: CheckStackOverflow
    //     0x116772c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1167730: cmp             SP, x16
    //     0x1167734: b.ls            #0x116788c
    // 0x1167738: cmp             w4, w0
    // 0x116773c: b.ne            #0x1167750
    // 0x1167740: mov             x0, x4
    // 0x1167744: LeaveFrame
    //     0x1167744: mov             SP, fp
    //     0x1167748: ldp             fp, lr, [SP], #0x10
    // 0x116774c: ret
    //     0x116774c: ret             
    // 0x1167750: r5 = inline_Allocate_Double()
    //     0x1167750: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x1167754: add             x5, x5, #0x10
    //     0x1167758: cmp             x1, x5
    //     0x116775c: b.ls            #0x1167894
    //     0x1167760: str             x5, [THR, #0x60]  ; THR::top
    //     0x1167764: sub             x5, x5, #0xf
    //     0x1167768: mov             x1, #0xe19c
    //     0x116776c: movk            x1, #3, lsl #16
    //     0x1167770: stur            x1, [x5, #-1]
    // 0x1167774: dmb             ishst
    // 0x1167778: StoreField: r5->field_7 = d0
    //     0x1167778: stur            d0, [x5, #7]
    // 0x116777c: mov             x3, x5
    // 0x1167780: stur            x5, [fp, #-8]
    // 0x1167784: r1 = Null
    //     0x1167784: mov             x1, NULL
    // 0x1167788: r2 = Null
    //     0x1167788: mov             x2, NULL
    // 0x116778c: r0 = lerp()
    //     0x116778c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167790: ldur            x0, [fp, #-0x10]
    // 0x1167794: LoadField: r1 = r0->field_b
    //     0x1167794: ldur            w1, [x0, #0xb]
    // 0x1167798: DecompressPointer r1
    //     0x1167798: add             x1, x1, HEAP, lsl #32
    // 0x116779c: ldur            x4, [fp, #-0x18]
    // 0x11677a0: LoadField: r2 = r4->field_b
    //     0x11677a0: ldur            w2, [x4, #0xb]
    // 0x11677a4: DecompressPointer r2
    //     0x11677a4: add             x2, x2, HEAP, lsl #32
    // 0x11677a8: ldur            x3, [fp, #-8]
    // 0x11677ac: r0 = lerpDouble()
    //     0x11677ac: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x11677b0: mov             x4, x0
    // 0x11677b4: ldur            x0, [fp, #-0x10]
    // 0x11677b8: stur            x4, [fp, #-0x20]
    // 0x11677bc: LoadField: r1 = r0->field_f
    //     0x11677bc: ldur            w1, [x0, #0xf]
    // 0x11677c0: DecompressPointer r1
    //     0x11677c0: add             x1, x1, HEAP, lsl #32
    // 0x11677c4: ldur            x5, [fp, #-0x18]
    // 0x11677c8: LoadField: r2 = r5->field_f
    //     0x11677c8: ldur            w2, [x5, #0xf]
    // 0x11677cc: DecompressPointer r2
    //     0x11677cc: add             x2, x2, HEAP, lsl #32
    // 0x11677d0: ldur            x3, [fp, #-8]
    // 0x11677d4: r0 = lerpDouble()
    //     0x11677d4: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x11677d8: mov             x4, x0
    // 0x11677dc: ldur            x0, [fp, #-0x10]
    // 0x11677e0: stur            x4, [fp, #-0x28]
    // 0x11677e4: LoadField: r1 = r0->field_13
    //     0x11677e4: ldur            w1, [x0, #0x13]
    // 0x11677e8: DecompressPointer r1
    //     0x11677e8: add             x1, x1, HEAP, lsl #32
    // 0x11677ec: ldur            x5, [fp, #-0x18]
    // 0x11677f0: LoadField: r2 = r5->field_13
    //     0x11677f0: ldur            w2, [x5, #0x13]
    // 0x11677f4: DecompressPointer r2
    //     0x11677f4: add             x2, x2, HEAP, lsl #32
    // 0x11677f8: ldur            x3, [fp, #-8]
    // 0x11677fc: r0 = lerpDouble()
    //     0x11677fc: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1167800: mov             x4, x0
    // 0x1167804: ldur            x0, [fp, #-0x10]
    // 0x1167808: stur            x4, [fp, #-0x30]
    // 0x116780c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x116780c: ldur            w1, [x0, #0x17]
    // 0x1167810: DecompressPointer r1
    //     0x1167810: add             x1, x1, HEAP, lsl #32
    // 0x1167814: ldur            x5, [fp, #-0x18]
    // 0x1167818: ArrayLoad: r2 = r5[0]  ; List_4
    //     0x1167818: ldur            w2, [x5, #0x17]
    // 0x116781c: DecompressPointer r2
    //     0x116781c: add             x2, x2, HEAP, lsl #32
    // 0x1167820: ldur            x3, [fp, #-8]
    // 0x1167824: r0 = lerpDouble()
    //     0x1167824: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1167828: mov             x3, x0
    // 0x116782c: ldur            x0, [fp, #-0x10]
    // 0x1167830: stur            x3, [fp, #-8]
    // 0x1167834: LoadField: r1 = r0->field_1b
    //     0x1167834: ldur            w1, [x0, #0x1b]
    // 0x1167838: DecompressPointer r1
    //     0x1167838: add             x1, x1, HEAP, lsl #32
    // 0x116783c: ldur            x0, [fp, #-0x18]
    // 0x1167840: LoadField: r2 = r0->field_1b
    //     0x1167840: ldur            w2, [x0, #0x1b]
    // 0x1167844: DecompressPointer r2
    //     0x1167844: add             x2, x2, HEAP, lsl #32
    // 0x1167848: ldur            d0, [fp, #-0x38]
    // 0x116784c: r0 = lerp()
    //     0x116784c: bl              #0xbff804  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x1167850: stur            x0, [fp, #-0x10]
    // 0x1167854: r0 = DividerThemeData()
    //     0x1167854: bl              #0x11678b0  ; AllocateDividerThemeDataStub -> DividerThemeData (size=0x20)
    // 0x1167858: ldur            x1, [fp, #-0x20]
    // 0x116785c: StoreField: r0->field_b = r1
    //     0x116785c: stur            w1, [x0, #0xb]
    // 0x1167860: ldur            x1, [fp, #-0x28]
    // 0x1167864: StoreField: r0->field_f = r1
    //     0x1167864: stur            w1, [x0, #0xf]
    // 0x1167868: ldur            x1, [fp, #-0x30]
    // 0x116786c: StoreField: r0->field_13 = r1
    //     0x116786c: stur            w1, [x0, #0x13]
    // 0x1167870: ldur            x1, [fp, #-8]
    // 0x1167874: ArrayStore: r0[0] = r1  ; List_4
    //     0x1167874: stur            w1, [x0, #0x17]
    // 0x1167878: ldur            x1, [fp, #-0x10]
    // 0x116787c: StoreField: r0->field_1b = r1
    //     0x116787c: stur            w1, [x0, #0x1b]
    // 0x1167880: LeaveFrame
    //     0x1167880: mov             SP, fp
    //     0x1167884: ldp             fp, lr, [SP], #0x10
    // 0x1167888: ret
    //     0x1167888: ret             
    // 0x116788c: r0 = StackOverflowSharedWithFPURegs()
    //     0x116788c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1167890: b               #0x1167738
    // 0x1167894: SaveReg d0
    //     0x1167894: str             q0, [SP, #-0x10]!
    // 0x1167898: stp             x0, x4, [SP, #-0x10]!
    // 0x116789c: r0 = AllocateDouble()
    //     0x116789c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11678a0: mov             x5, x0
    // 0x11678a4: ldp             x0, x4, [SP], #0x10
    // 0x11678a8: RestoreReg d0
    //     0x11678a8: ldr             q0, [SP], #0x10
    // 0x11678ac: b               #0x1167778
  }
  _ ==(/* No info */) {
    // ** addr: 0x126b5b0, size: 0x2d8
    // 0x126b5b0: EnterFrame
    //     0x126b5b0: stp             fp, lr, [SP, #-0x10]!
    //     0x126b5b4: mov             fp, SP
    // 0x126b5b8: AllocStack(0x18)
    //     0x126b5b8: sub             SP, SP, #0x18
    // 0x126b5bc: CheckStackOverflow
    //     0x126b5bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x126b5c0: cmp             SP, x16
    //     0x126b5c4: b.ls            #0x126b880
    // 0x126b5c8: ldr             x0, [fp, #0x10]
    // 0x126b5cc: cmp             w0, NULL
    // 0x126b5d0: b.ne            #0x126b5e4
    // 0x126b5d4: r0 = false
    //     0x126b5d4: add             x0, NULL, #0x30  ; false
    // 0x126b5d8: LeaveFrame
    //     0x126b5d8: mov             SP, fp
    //     0x126b5dc: ldp             fp, lr, [SP], #0x10
    // 0x126b5e0: ret
    //     0x126b5e0: ret             
    // 0x126b5e4: ldr             x1, [fp, #0x18]
    // 0x126b5e8: cmp             w1, w0
    // 0x126b5ec: b.ne            #0x126b600
    // 0x126b5f0: r0 = true
    //     0x126b5f0: add             x0, NULL, #0x20  ; true
    // 0x126b5f4: LeaveFrame
    //     0x126b5f4: mov             SP, fp
    //     0x126b5f8: ldp             fp, lr, [SP], #0x10
    // 0x126b5fc: ret
    //     0x126b5fc: ret             
    // 0x126b600: stp             x1, x0, [SP]
    // 0x126b604: r0 = _haveSameRuntimeType()
    //     0x126b604: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x126b608: tbz             w0, #4, #0x126b61c
    // 0x126b60c: r0 = false
    //     0x126b60c: add             x0, NULL, #0x30  ; false
    // 0x126b610: LeaveFrame
    //     0x126b610: mov             SP, fp
    //     0x126b614: ldp             fp, lr, [SP], #0x10
    // 0x126b618: ret
    //     0x126b618: ret             
    // 0x126b61c: ldr             x0, [fp, #0x10]
    // 0x126b620: r1 = 60
    //     0x126b620: mov             x1, #0x3c
    // 0x126b624: branchIfSmi(r0, 0x126b630)
    //     0x126b624: tbz             w0, #0, #0x126b630
    // 0x126b628: r1 = LoadClassIdInstr(r0)
    //     0x126b628: ldur            x1, [x0, #-1]
    //     0x126b62c: ubfx            x1, x1, #0xc, #0x14
    // 0x126b630: r17 = -5160
    //     0x126b630: mov             x17, #-0x1428
    // 0x126b634: add             x16, x1, x17
    // 0x126b638: cmp             x16, #2
    // 0x126b63c: b.hi            #0x126b870
    // 0x126b640: r17 = 5160
    //     0x126b640: mov             x17, #0x1428
    // 0x126b644: cmp             x1, x17
    // 0x126b648: b.ne            #0x126b65c
    // 0x126b64c: LoadField: r1 = r0->field_7
    //     0x126b64c: ldur            w1, [x0, #7]
    // 0x126b650: DecompressPointer r1
    //     0x126b650: add             x1, x1, HEAP, lsl #32
    // 0x126b654: mov             x2, x1
    // 0x126b658: b               #0x126b6b4
    // 0x126b65c: r17 = 5161
    //     0x126b65c: mov             x17, #0x1429
    // 0x126b660: cmp             x1, x17
    // 0x126b664: b.ne            #0x126b69c
    // 0x126b668: LoadField: r1 = r0->field_1f
    //     0x126b668: ldur            w1, [x0, #0x1f]
    // 0x126b66c: DecompressPointer r1
    //     0x126b66c: add             x1, x1, HEAP, lsl #32
    // 0x126b670: r0 = of()
    //     0x126b670: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x126b674: LoadField: r1 = r0->field_3f
    //     0x126b674: ldur            w1, [x0, #0x3f]
    // 0x126b678: DecompressPointer r1
    //     0x126b678: add             x1, x1, HEAP, lsl #32
    // 0x126b67c: LoadField: r0 = r1->field_ab
    //     0x126b67c: ldur            w0, [x1, #0xab]
    // 0x126b680: DecompressPointer r0
    //     0x126b680: add             x0, x0, HEAP, lsl #32
    // 0x126b684: cmp             w0, NULL
    // 0x126b688: b.ne            #0x126b694
    // 0x126b68c: LoadField: r0 = r1->field_cb
    //     0x126b68c: ldur            w0, [x1, #0xcb]
    // 0x126b690: DecompressPointer r0
    //     0x126b690: add             x0, x0, HEAP, lsl #32
    // 0x126b694: mov             x2, x0
    // 0x126b698: b               #0x126b6b4
    // 0x126b69c: LoadField: r1 = r0->field_1f
    //     0x126b69c: ldur            w1, [x0, #0x1f]
    // 0x126b6a0: DecompressPointer r1
    //     0x126b6a0: add             x1, x1, HEAP, lsl #32
    // 0x126b6a4: r0 = of()
    //     0x126b6a4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x126b6a8: LoadField: r1 = r0->field_47
    //     0x126b6a8: ldur            w1, [x0, #0x47]
    // 0x126b6ac: DecompressPointer r1
    //     0x126b6ac: add             x1, x1, HEAP, lsl #32
    // 0x126b6b0: mov             x2, x1
    // 0x126b6b4: ldr             x0, [fp, #0x18]
    // 0x126b6b8: stur            x2, [fp, #-8]
    // 0x126b6bc: r1 = LoadClassIdInstr(r0)
    //     0x126b6bc: ldur            x1, [x0, #-1]
    //     0x126b6c0: ubfx            x1, x1, #0xc, #0x14
    // 0x126b6c4: r17 = 5160
    //     0x126b6c4: mov             x17, #0x1428
    // 0x126b6c8: cmp             x1, x17
    // 0x126b6cc: b.ne            #0x126b6e0
    // 0x126b6d0: LoadField: r1 = r0->field_7
    //     0x126b6d0: ldur            w1, [x0, #7]
    // 0x126b6d4: DecompressPointer r1
    //     0x126b6d4: add             x1, x1, HEAP, lsl #32
    // 0x126b6d8: mov             x0, x2
    // 0x126b6dc: b               #0x126b73c
    // 0x126b6e0: r17 = 5161
    //     0x126b6e0: mov             x17, #0x1429
    // 0x126b6e4: cmp             x1, x17
    // 0x126b6e8: b.ne            #0x126b724
    // 0x126b6ec: LoadField: r1 = r0->field_1f
    //     0x126b6ec: ldur            w1, [x0, #0x1f]
    // 0x126b6f0: DecompressPointer r1
    //     0x126b6f0: add             x1, x1, HEAP, lsl #32
    // 0x126b6f4: r0 = of()
    //     0x126b6f4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x126b6f8: LoadField: r1 = r0->field_3f
    //     0x126b6f8: ldur            w1, [x0, #0x3f]
    // 0x126b6fc: DecompressPointer r1
    //     0x126b6fc: add             x1, x1, HEAP, lsl #32
    // 0x126b700: LoadField: r0 = r1->field_ab
    //     0x126b700: ldur            w0, [x1, #0xab]
    // 0x126b704: DecompressPointer r0
    //     0x126b704: add             x0, x0, HEAP, lsl #32
    // 0x126b708: cmp             w0, NULL
    // 0x126b70c: b.ne            #0x126b718
    // 0x126b710: LoadField: r0 = r1->field_cb
    //     0x126b710: ldur            w0, [x1, #0xcb]
    // 0x126b714: DecompressPointer r0
    //     0x126b714: add             x0, x0, HEAP, lsl #32
    // 0x126b718: mov             x1, x0
    // 0x126b71c: ldur            x0, [fp, #-8]
    // 0x126b720: b               #0x126b73c
    // 0x126b724: LoadField: r1 = r0->field_1f
    //     0x126b724: ldur            w1, [x0, #0x1f]
    // 0x126b728: DecompressPointer r1
    //     0x126b728: add             x1, x1, HEAP, lsl #32
    // 0x126b72c: r0 = of()
    //     0x126b72c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x126b730: LoadField: r1 = r0->field_47
    //     0x126b730: ldur            w1, [x0, #0x47]
    // 0x126b734: DecompressPointer r1
    //     0x126b734: add             x1, x1, HEAP, lsl #32
    // 0x126b738: ldur            x0, [fp, #-8]
    // 0x126b73c: r2 = LoadClassIdInstr(r0)
    //     0x126b73c: ldur            x2, [x0, #-1]
    //     0x126b740: ubfx            x2, x2, #0xc, #0x14
    // 0x126b744: stp             x1, x0, [SP]
    // 0x126b748: mov             x0, x2
    // 0x126b74c: mov             lr, x0
    // 0x126b750: ldr             lr, [x21, lr, lsl #3]
    // 0x126b754: blr             lr
    // 0x126b758: tbnz            w0, #4, #0x126b870
    // 0x126b75c: ldr             x1, [fp, #0x18]
    // 0x126b760: ldr             x2, [fp, #0x10]
    // 0x126b764: LoadField: r0 = r2->field_b
    //     0x126b764: ldur            w0, [x2, #0xb]
    // 0x126b768: DecompressPointer r0
    //     0x126b768: add             x0, x0, HEAP, lsl #32
    // 0x126b76c: LoadField: r3 = r1->field_b
    //     0x126b76c: ldur            w3, [x1, #0xb]
    // 0x126b770: DecompressPointer r3
    //     0x126b770: add             x3, x3, HEAP, lsl #32
    // 0x126b774: r4 = LoadClassIdInstr(r0)
    //     0x126b774: ldur            x4, [x0, #-1]
    //     0x126b778: ubfx            x4, x4, #0xc, #0x14
    // 0x126b77c: stp             x3, x0, [SP]
    // 0x126b780: mov             x0, x4
    // 0x126b784: mov             lr, x0
    // 0x126b788: ldr             lr, [x21, lr, lsl #3]
    // 0x126b78c: blr             lr
    // 0x126b790: tbnz            w0, #4, #0x126b870
    // 0x126b794: ldr             x1, [fp, #0x18]
    // 0x126b798: ldr             x2, [fp, #0x10]
    // 0x126b79c: LoadField: r0 = r2->field_f
    //     0x126b79c: ldur            w0, [x2, #0xf]
    // 0x126b7a0: DecompressPointer r0
    //     0x126b7a0: add             x0, x0, HEAP, lsl #32
    // 0x126b7a4: LoadField: r3 = r1->field_f
    //     0x126b7a4: ldur            w3, [x1, #0xf]
    // 0x126b7a8: DecompressPointer r3
    //     0x126b7a8: add             x3, x3, HEAP, lsl #32
    // 0x126b7ac: r4 = LoadClassIdInstr(r0)
    //     0x126b7ac: ldur            x4, [x0, #-1]
    //     0x126b7b0: ubfx            x4, x4, #0xc, #0x14
    // 0x126b7b4: stp             x3, x0, [SP]
    // 0x126b7b8: mov             x0, x4
    // 0x126b7bc: mov             lr, x0
    // 0x126b7c0: ldr             lr, [x21, lr, lsl #3]
    // 0x126b7c4: blr             lr
    // 0x126b7c8: tbnz            w0, #4, #0x126b870
    // 0x126b7cc: ldr             x1, [fp, #0x18]
    // 0x126b7d0: ldr             x2, [fp, #0x10]
    // 0x126b7d4: LoadField: r0 = r2->field_13
    //     0x126b7d4: ldur            w0, [x2, #0x13]
    // 0x126b7d8: DecompressPointer r0
    //     0x126b7d8: add             x0, x0, HEAP, lsl #32
    // 0x126b7dc: LoadField: r3 = r1->field_13
    //     0x126b7dc: ldur            w3, [x1, #0x13]
    // 0x126b7e0: DecompressPointer r3
    //     0x126b7e0: add             x3, x3, HEAP, lsl #32
    // 0x126b7e4: r4 = LoadClassIdInstr(r0)
    //     0x126b7e4: ldur            x4, [x0, #-1]
    //     0x126b7e8: ubfx            x4, x4, #0xc, #0x14
    // 0x126b7ec: stp             x3, x0, [SP]
    // 0x126b7f0: mov             x0, x4
    // 0x126b7f4: mov             lr, x0
    // 0x126b7f8: ldr             lr, [x21, lr, lsl #3]
    // 0x126b7fc: blr             lr
    // 0x126b800: tbnz            w0, #4, #0x126b870
    // 0x126b804: ldr             x1, [fp, #0x18]
    // 0x126b808: ldr             x2, [fp, #0x10]
    // 0x126b80c: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x126b80c: ldur            w0, [x2, #0x17]
    // 0x126b810: DecompressPointer r0
    //     0x126b810: add             x0, x0, HEAP, lsl #32
    // 0x126b814: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x126b814: ldur            w3, [x1, #0x17]
    // 0x126b818: DecompressPointer r3
    //     0x126b818: add             x3, x3, HEAP, lsl #32
    // 0x126b81c: r4 = LoadClassIdInstr(r0)
    //     0x126b81c: ldur            x4, [x0, #-1]
    //     0x126b820: ubfx            x4, x4, #0xc, #0x14
    // 0x126b824: stp             x3, x0, [SP]
    // 0x126b828: mov             x0, x4
    // 0x126b82c: mov             lr, x0
    // 0x126b830: ldr             lr, [x21, lr, lsl #3]
    // 0x126b834: blr             lr
    // 0x126b838: tbnz            w0, #4, #0x126b870
    // 0x126b83c: ldr             x0, [fp, #0x18]
    // 0x126b840: ldr             x1, [fp, #0x10]
    // 0x126b844: LoadField: r2 = r1->field_1b
    //     0x126b844: ldur            w2, [x1, #0x1b]
    // 0x126b848: DecompressPointer r2
    //     0x126b848: add             x2, x2, HEAP, lsl #32
    // 0x126b84c: LoadField: r1 = r0->field_1b
    //     0x126b84c: ldur            w1, [x0, #0x1b]
    // 0x126b850: DecompressPointer r1
    //     0x126b850: add             x1, x1, HEAP, lsl #32
    // 0x126b854: r0 = LoadClassIdInstr(r2)
    //     0x126b854: ldur            x0, [x2, #-1]
    //     0x126b858: ubfx            x0, x0, #0xc, #0x14
    // 0x126b85c: stp             x1, x2, [SP]
    // 0x126b860: mov             lr, x0
    // 0x126b864: ldr             lr, [x21, lr, lsl #3]
    // 0x126b868: blr             lr
    // 0x126b86c: b               #0x126b874
    // 0x126b870: r0 = false
    //     0x126b870: add             x0, NULL, #0x30  ; false
    // 0x126b874: LeaveFrame
    //     0x126b874: mov             SP, fp
    //     0x126b878: ldp             fp, lr, [SP], #0x10
    // 0x126b87c: ret
    //     0x126b87c: ret             
    // 0x126b880: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x126b880: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x126b884: b               #0x126b5c8
  }
}

// class id: 6849, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class DividerTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xfb5bb0, size: 0x58
    // 0xfb5bb0: EnterFrame
    //     0xfb5bb0: stp             fp, lr, [SP, #-0x10]!
    //     0xfb5bb4: mov             fp, SP
    // 0xfb5bb8: AllocStack(0x18)
    //     0xfb5bb8: sub             SP, SP, #0x18
    // 0xfb5bbc: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xfb5bbc: stur            x1, [fp, #-8]
    // 0xfb5bc0: CheckStackOverflow
    //     0xfb5bc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb5bc4: cmp             SP, x16
    //     0xfb5bc8: b.ls            #0xfb5c00
    // 0xfb5bcc: r16 = <DividerTheme>
    //     0xfb5bcc: add             x16, PP, #0x80, lsl #12  ; [pp+0x80be0] TypeArguments: <DividerTheme>
    //     0xfb5bd0: ldr             x16, [x16, #0xbe0]
    // 0xfb5bd4: stp             x1, x16, [SP]
    // 0xfb5bd8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xfb5bd8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xfb5bdc: r0 = dependOnInheritedWidgetOfExactType()
    //     0xfb5bdc: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xfb5be0: ldur            x1, [fp, #-8]
    // 0xfb5be4: r0 = of()
    //     0xfb5be4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb5be8: LoadField: r1 = r0->field_cb
    //     0xfb5be8: ldur            w1, [x0, #0xcb]
    // 0xfb5bec: DecompressPointer r1
    //     0xfb5bec: add             x1, x1, HEAP, lsl #32
    // 0xfb5bf0: mov             x0, x1
    // 0xfb5bf4: LeaveFrame
    //     0xfb5bf4: mov             SP, fp
    //     0xfb5bf8: ldp             fp, lr, [SP], #0x10
    // 0xfb5bfc: ret
    //     0xfb5bfc: ret             
    // 0xfb5c00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb5c00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb5c04: b               #0xfb5bcc
  }
}
