// lib: , url: package:flutter/src/material/menu_theme.dart

// class id: 1048918, size: 0x8
class :: {
}

// class id: 5139, size: 0x10, field offset: 0x8
//   const constructor, 
class MenuThemeData extends _MixinApplication3&Object&Diagnosticable {

  static _ lerp(/* No info */) {
    // ** addr: 0x1166944, size: 0x6c
    // 0x1166944: EnterFrame
    //     0x1166944: stp             fp, lr, [SP, #-0x10]!
    //     0x1166948: mov             fp, SP
    // 0x116694c: AllocStack(0x8)
    //     0x116694c: sub             SP, SP, #8
    // 0x1166950: SetupParameters(dynamic _ /* r1 => r0 */)
    //     0x1166950: mov             x0, x1
    // 0x1166954: CheckStackOverflow
    //     0x1166954: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1166958: cmp             SP, x16
    //     0x116695c: b.ls            #0x11669a8
    // 0x1166960: cmp             w0, w2
    // 0x1166964: b.ne            #0x1166974
    // 0x1166968: LeaveFrame
    //     0x1166968: mov             SP, fp
    //     0x116696c: ldp             fp, lr, [SP], #0x10
    // 0x1166970: ret
    //     0x1166970: ret             
    // 0x1166974: LoadField: r1 = r0->field_7
    //     0x1166974: ldur            w1, [x0, #7]
    // 0x1166978: DecompressPointer r1
    //     0x1166978: add             x1, x1, HEAP, lsl #32
    // 0x116697c: LoadField: r0 = r2->field_7
    //     0x116697c: ldur            w0, [x2, #7]
    // 0x1166980: DecompressPointer r0
    //     0x1166980: add             x0, x0, HEAP, lsl #32
    // 0x1166984: mov             x2, x0
    // 0x1166988: r0 = lerp()
    //     0x1166988: bl              #0x11669bc  ; [package:flutter/src/material/menu_style.dart] MenuStyle::lerp
    // 0x116698c: stur            x0, [fp, #-8]
    // 0x1166990: r0 = MenuThemeData()
    //     0x1166990: bl              #0x11669b0  ; AllocateMenuThemeDataStub -> MenuThemeData (size=0x10)
    // 0x1166994: ldur            x1, [fp, #-8]
    // 0x1166998: StoreField: r0->field_7 = r1
    //     0x1166998: stur            w1, [x0, #7]
    // 0x116699c: LeaveFrame
    //     0x116699c: mov             SP, fp
    //     0x11669a0: ldp             fp, lr, [SP], #0x10
    // 0x11669a4: ret
    //     0x11669a4: ret             
    // 0x11669a8: r0 = StackOverflowSharedWithFPURegs()
    //     0x11669a8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11669ac: b               #0x1166960
  }
  _ ==(/* No info */) {
    // ** addr: 0x126fa34, size: 0xe4
    // 0x126fa34: EnterFrame
    //     0x126fa34: stp             fp, lr, [SP, #-0x10]!
    //     0x126fa38: mov             fp, SP
    // 0x126fa3c: AllocStack(0x10)
    //     0x126fa3c: sub             SP, SP, #0x10
    // 0x126fa40: CheckStackOverflow
    //     0x126fa40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x126fa44: cmp             SP, x16
    //     0x126fa48: b.ls            #0x126fb10
    // 0x126fa4c: ldr             x0, [fp, #0x10]
    // 0x126fa50: cmp             w0, NULL
    // 0x126fa54: b.ne            #0x126fa68
    // 0x126fa58: r0 = false
    //     0x126fa58: add             x0, NULL, #0x30  ; false
    // 0x126fa5c: LeaveFrame
    //     0x126fa5c: mov             SP, fp
    //     0x126fa60: ldp             fp, lr, [SP], #0x10
    // 0x126fa64: ret
    //     0x126fa64: ret             
    // 0x126fa68: ldr             x1, [fp, #0x18]
    // 0x126fa6c: cmp             w1, w0
    // 0x126fa70: b.ne            #0x126fa84
    // 0x126fa74: r0 = true
    //     0x126fa74: add             x0, NULL, #0x20  ; true
    // 0x126fa78: LeaveFrame
    //     0x126fa78: mov             SP, fp
    //     0x126fa7c: ldp             fp, lr, [SP], #0x10
    // 0x126fa80: ret
    //     0x126fa80: ret             
    // 0x126fa84: stp             x1, x0, [SP]
    // 0x126fa88: r0 = _haveSameRuntimeType()
    //     0x126fa88: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x126fa8c: tbz             w0, #4, #0x126faa0
    // 0x126fa90: r0 = false
    //     0x126fa90: add             x0, NULL, #0x30  ; false
    // 0x126fa94: LeaveFrame
    //     0x126fa94: mov             SP, fp
    //     0x126fa98: ldp             fp, lr, [SP], #0x10
    // 0x126fa9c: ret
    //     0x126fa9c: ret             
    // 0x126faa0: ldr             x0, [fp, #0x10]
    // 0x126faa4: r1 = 60
    //     0x126faa4: mov             x1, #0x3c
    // 0x126faa8: branchIfSmi(r0, 0x126fab4)
    //     0x126faa8: tbz             w0, #0, #0x126fab4
    // 0x126faac: r1 = LoadClassIdInstr(r0)
    //     0x126faac: ldur            x1, [x0, #-1]
    //     0x126fab0: ubfx            x1, x1, #0xc, #0x14
    // 0x126fab4: r17 = -5139
    //     0x126fab4: mov             x17, #-0x1413
    // 0x126fab8: add             x16, x1, x17
    // 0x126fabc: cmp             x16, #1
    // 0x126fac0: b.hi            #0x126fb00
    // 0x126fac4: ldr             x1, [fp, #0x18]
    // 0x126fac8: LoadField: r2 = r0->field_7
    //     0x126fac8: ldur            w2, [x0, #7]
    // 0x126facc: DecompressPointer r2
    //     0x126facc: add             x2, x2, HEAP, lsl #32
    // 0x126fad0: LoadField: r0 = r1->field_7
    //     0x126fad0: ldur            w0, [x1, #7]
    // 0x126fad4: DecompressPointer r0
    //     0x126fad4: add             x0, x0, HEAP, lsl #32
    // 0x126fad8: r1 = LoadClassIdInstr(r2)
    //     0x126fad8: ldur            x1, [x2, #-1]
    //     0x126fadc: ubfx            x1, x1, #0xc, #0x14
    // 0x126fae0: stp             x0, x2, [SP]
    // 0x126fae4: mov             x0, x1
    // 0x126fae8: mov             lr, x0
    // 0x126faec: ldr             lr, [x21, lr, lsl #3]
    // 0x126faf0: blr             lr
    // 0x126faf4: tbnz            w0, #4, #0x126fb00
    // 0x126faf8: r0 = true
    //     0x126faf8: add             x0, NULL, #0x20  ; true
    // 0x126fafc: b               #0x126fb04
    // 0x126fb00: r0 = false
    //     0x126fb00: add             x0, NULL, #0x30  ; false
    // 0x126fb04: LeaveFrame
    //     0x126fb04: mov             SP, fp
    //     0x126fb08: ldp             fp, lr, [SP], #0x10
    // 0x126fb0c: ret
    //     0x126fb0c: ret             
    // 0x126fb10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x126fb10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x126fb14: b               #0x126fa4c
  }
}
