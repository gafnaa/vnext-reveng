// lib: , url: package:flutter/src/material/dialog_theme.dart

// class id: 1048881, size: 0x8
class :: {
}

// class id: 5163, size: 0x40, field offset: 0x8
//   const constructor, 
class DialogThemeData extends _MixinApplication3&Object&Diagnosticable {

  _ copyWith(/* No info */) {
    // ** addr: 0xfb8a68, size: 0x70
    // 0xfb8a68: EnterFrame
    //     0xfb8a68: stp             fp, lr, [SP, #-0x10]!
    //     0xfb8a6c: mov             fp, SP
    // 0xfb8a70: AllocStack(0x10)
    //     0xfb8a70: sub             SP, SP, #0x10
    // 0xfb8a74: LoadField: r0 = r1->field_b
    //     0xfb8a74: ldur            w0, [x1, #0xb]
    // 0xfb8a78: DecompressPointer r0
    //     0xfb8a78: add             x0, x0, HEAP, lsl #32
    // 0xfb8a7c: stur            x0, [fp, #-0x10]
    // 0xfb8a80: LoadField: r2 = r1->field_37
    //     0xfb8a80: ldur            w2, [x1, #0x37]
    // 0xfb8a84: DecompressPointer r2
    //     0xfb8a84: add             x2, x2, HEAP, lsl #32
    // 0xfb8a88: stur            x2, [fp, #-8]
    // 0xfb8a8c: r0 = DialogThemeData()
    //     0xfb8a8c: bl              #0xfb8ad8  ; AllocateDialogThemeDataStub -> DialogThemeData (size=0x40)
    // 0xfb8a90: ldur            x1, [fp, #-0x10]
    // 0xfb8a94: StoreField: r0->field_b = r1
    //     0xfb8a94: stur            w1, [x0, #0xb]
    // 0xfb8a98: r1 = Instance_RoundedRectangleBorder
    //     0xfb8a98: add             x1, PP, #0x26, lsl #12  ; [pp+0x26600] Obj!RoundedRectangleBorder@129ec31
    //     0xfb8a9c: ldr             x1, [x1, #0x600]
    // 0xfb8aa0: ArrayStore: r0[0] = r1  ; List_4
    //     0xfb8aa0: stur            w1, [x0, #0x17]
    // 0xfb8aa4: r1 = Instance_Alignment
    //     0xfb8aa4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15510] Obj!Alignment@129e7b1
    //     0xfb8aa8: ldr             x1, [x1, #0x510]
    // 0xfb8aac: StoreField: r0->field_1b = r1
    //     0xfb8aac: stur            w1, [x0, #0x1b]
    // 0xfb8ab0: r1 = Instance_EdgeInsets
    //     0xfb8ab0: ldr             x1, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xfb8ab4: StoreField: r0->field_33 = r1
    //     0xfb8ab4: stur            w1, [x0, #0x33]
    // 0xfb8ab8: ldur            x1, [fp, #-8]
    // 0xfb8abc: StoreField: r0->field_37 = r1
    //     0xfb8abc: stur            w1, [x0, #0x37]
    // 0xfb8ac0: r1 = Instance_BoxConstraints
    //     0xfb8ac0: add             x1, PP, #0x16, lsl #12  ; [pp+0x16ea8] Obj!BoxConstraints@129c1a1
    //     0xfb8ac4: ldr             x1, [x1, #0xea8]
    // 0xfb8ac8: StoreField: r0->field_3b = r1
    //     0xfb8ac8: stur            w1, [x0, #0x3b]
    // 0xfb8acc: LeaveFrame
    //     0xfb8acc: mov             SP, fp
    //     0xfb8ad0: ldp             fp, lr, [SP], #0x10
    // 0xfb8ad4: ret
    //     0xfb8ad4: ret             
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x1132638, size: 0x6dc
    // 0x1132638: EnterFrame
    //     0x1132638: stp             fp, lr, [SP, #-0x10]!
    //     0x113263c: mov             fp, SP
    // 0x1132640: AllocStack(0x18)
    //     0x1132640: sub             SP, SP, #0x18
    // 0x1132644: CheckStackOverflow
    //     0x1132644: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1132648: cmp             SP, x16
    //     0x113264c: b.ls            #0x1132d08
    // 0x1132650: ldr             x0, [fp, #0x10]
    // 0x1132654: r2 = LoadClassIdInstr(r0)
    //     0x1132654: ldur            x2, [x0, #-1]
    //     0x1132658: ubfx            x2, x2, #0xc, #0x14
    // 0x113265c: stur            x2, [fp, #-8]
    // 0x1132660: r17 = 5163
    //     0x1132660: mov             x17, #0x142b
    // 0x1132664: cmp             x2, x17
    // 0x1132668: b.ne            #0x1132684
    // 0x113266c: LoadField: r1 = r0->field_7
    //     0x113266c: ldur            w1, [x0, #7]
    // 0x1132670: DecompressPointer r1
    //     0x1132670: add             x1, x1, HEAP, lsl #32
    // 0x1132674: mov             x4, x1
    // 0x1132678: mov             x3, x0
    // 0x113267c: mov             x0, x2
    // 0x1132680: b               #0x1132768
    // 0x1132684: r17 = 5164
    //     0x1132684: mov             x17, #0x142c
    // 0x1132688: cmp             x2, x17
    // 0x113268c: b.ne            #0x11326e8
    // 0x1132690: mov             x1, x0
    // 0x1132694: LoadField: r0 = r1->field_43
    //     0x1132694: ldur            w0, [x1, #0x43]
    // 0x1132698: DecompressPointer r0
    //     0x1132698: add             x0, x0, HEAP, lsl #32
    // 0x113269c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11326a0: cmp             w0, w16
    // 0x11326a4: b.ne            #0x11326b4
    // 0x11326a8: r2 = _colors
    //     0x11326a8: add             x2, PP, #0x26, lsl #12  ; [pp+0x263d0] Field <_DialogDefaultsM3@664506021._colors@664506021>: late final (offset: 0x44)
    //     0x11326ac: ldr             x2, [x2, #0x3d0]
    // 0x11326b0: r0 = InitLateFinalInstanceField()
    //     0x11326b0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11326b4: LoadField: r1 = r0->field_9b
    //     0x11326b4: ldur            w1, [x0, #0x9b]
    // 0x11326b8: DecompressPointer r1
    //     0x11326b8: add             x1, x1, HEAP, lsl #32
    // 0x11326bc: cmp             w1, NULL
    // 0x11326c0: b.ne            #0x11326d4
    // 0x11326c4: LoadField: r1 = r0->field_7b
    //     0x11326c4: ldur            w1, [x0, #0x7b]
    // 0x11326c8: DecompressPointer r1
    //     0x11326c8: add             x1, x1, HEAP, lsl #32
    // 0x11326cc: mov             x0, x1
    // 0x11326d0: b               #0x11326d8
    // 0x11326d4: mov             x0, x1
    // 0x11326d8: mov             x4, x0
    // 0x11326dc: ldr             x3, [fp, #0x10]
    // 0x11326e0: ldur            x0, [fp, #-8]
    // 0x11326e4: b               #0x1132768
    // 0x11326e8: mov             x0, x2
    // 0x11326ec: r17 = 5165
    //     0x11326ec: mov             x17, #0x142d
    // 0x11326f0: cmp             x0, x17
    // 0x11326f4: b.eq            #0x1132cfc
    // 0x11326f8: ldr             x1, [fp, #0x10]
    // 0x11326fc: LoadField: r0 = r1->field_43
    //     0x11326fc: ldur            w0, [x1, #0x43]
    // 0x1132700: DecompressPointer r0
    //     0x1132700: add             x0, x0, HEAP, lsl #32
    // 0x1132704: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1132708: cmp             w0, w16
    // 0x113270c: b.ne            #0x113271c
    // 0x1132710: r2 = theme
    //     0x1132710: add             x2, PP, #0x26, lsl #12  ; [pp+0x263d8] Field <_DialogDefaultsM2@664506021.theme>: late final (offset: 0x44)
    //     0x1132714: ldr             x2, [x2, #0x3d8]
    // 0x1132718: r0 = InitLateFinalInstanceField()
    //     0x1132718: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113271c: LoadField: r1 = r0->field_3f
    //     0x113271c: ldur            w1, [x0, #0x3f]
    // 0x1132720: DecompressPointer r1
    //     0x1132720: add             x1, x1, HEAP, lsl #32
    // 0x1132724: LoadField: r0 = r1->field_7
    //     0x1132724: ldur            w0, [x1, #7]
    // 0x1132728: DecompressPointer r0
    //     0x1132728: add             x0, x0, HEAP, lsl #32
    // 0x113272c: r16 = Instance_Brightness
    //     0x113272c: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x1132730: cmp             w0, w16
    // 0x1132734: b.ne            #0x1132754
    // 0x1132738: r1 = _ConstMap len:12
    //     0x1132738: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c20] Map<int, Color>(12)
    //     0x113273c: ldr             x1, [x1, #0xc20]
    // 0x1132740: r2 = 1600
    //     0x1132740: mov             x2, #0x640
    // 0x1132744: r0 = []()
    //     0x1132744: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x1132748: cmp             w0, NULL
    // 0x113274c: b.eq            #0x1132d10
    // 0x1132750: b               #0x113275c
    // 0x1132754: r0 = Instance_Color
    //     0x1132754: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x1132758: ldr             x0, [x0, #0xc38]
    // 0x113275c: mov             x4, x0
    // 0x1132760: ldr             x3, [fp, #0x10]
    // 0x1132764: ldur            x0, [fp, #-8]
    // 0x1132768: stur            x4, [fp, #-0x10]
    // 0x113276c: r1 = <Object?>
    //     0x113276c: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x1132770: r2 = 28
    //     0x1132770: mov             x2, #0x1c
    // 0x1132774: r0 = AllocateArray()
    //     0x1132774: bl              #0x13df928  ; AllocateArrayStub
    // 0x1132778: mov             x2, x0
    // 0x113277c: ldur            x0, [fp, #-0x10]
    // 0x1132780: stur            x2, [fp, #-0x18]
    // 0x1132784: StoreField: r2->field_f = r0
    //     0x1132784: stur            w0, [x2, #0xf]
    // 0x1132788: ldr             x0, [fp, #0x10]
    // 0x113278c: LoadField: r1 = r0->field_b
    //     0x113278c: ldur            w1, [x0, #0xb]
    // 0x1132790: DecompressPointer r1
    //     0x1132790: add             x1, x1, HEAP, lsl #32
    // 0x1132794: StoreField: r2->field_13 = r1
    //     0x1132794: stur            w1, [x2, #0x13]
    // 0x1132798: ldur            x3, [fp, #-8]
    // 0x113279c: r17 = 5163
    //     0x113279c: mov             x17, #0x142b
    // 0x11327a0: cmp             x3, x17
    // 0x11327a4: b.eq            #0x11327d0
    // 0x11327a8: r17 = 5164
    //     0x11327a8: mov             x17, #0x142c
    // 0x11327ac: cmp             x3, x17
    // 0x11327b0: b.ne            #0x11327c4
    // 0x11327b4: mov             x2, x3
    // 0x11327b8: r0 = Instance_Color
    //     0x11327b8: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x11327bc: ldr             x0, [x0, #0x810]
    // 0x11327c0: b               #0x1132818
    // 0x11327c4: r17 = 5165
    //     0x11327c4: mov             x17, #0x142d
    // 0x11327c8: cmp             x3, x17
    // 0x11327cc: b.ne            #0x11327e4
    // 0x11327d0: LoadField: r1 = r0->field_f
    //     0x11327d0: ldur            w1, [x0, #0xf]
    // 0x11327d4: DecompressPointer r1
    //     0x11327d4: add             x1, x1, HEAP, lsl #32
    // 0x11327d8: mov             x0, x1
    // 0x11327dc: mov             x2, x3
    // 0x11327e0: b               #0x1132818
    // 0x11327e4: mov             x1, x0
    // 0x11327e8: LoadField: r0 = r1->field_43
    //     0x11327e8: ldur            w0, [x1, #0x43]
    // 0x11327ec: DecompressPointer r0
    //     0x11327ec: add             x0, x0, HEAP, lsl #32
    // 0x11327f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11327f4: cmp             w0, w16
    // 0x11327f8: b.ne            #0x1132808
    // 0x11327fc: r2 = theme
    //     0x11327fc: add             x2, PP, #0x26, lsl #12  ; [pp+0x263d8] Field <_DialogDefaultsM2@664506021.theme>: late final (offset: 0x44)
    //     0x1132800: ldr             x2, [x2, #0x3d8]
    // 0x1132804: r0 = InitLateFinalInstanceField()
    //     0x1132804: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1132808: LoadField: r1 = r0->field_6f
    //     0x1132808: ldur            w1, [x0, #0x6f]
    // 0x113280c: DecompressPointer r1
    //     0x113280c: add             x1, x1, HEAP, lsl #32
    // 0x1132810: mov             x0, x1
    // 0x1132814: ldur            x2, [fp, #-8]
    // 0x1132818: ldur            x1, [fp, #-0x18]
    // 0x113281c: ArrayStore: r1[2] = r0  ; List_4
    //     0x113281c: add             x25, x1, #0x17
    //     0x1132820: str             w0, [x25]
    //     0x1132824: tbz             w0, #0, #0x1132840
    //     0x1132828: ldurb           w16, [x1, #-1]
    //     0x113282c: ldurb           w17, [x0, #-1]
    //     0x1132830: and             x16, x17, x16, lsr #2
    //     0x1132834: tst             x16, HEAP, lsr #32
    //     0x1132838: b.eq            #0x1132840
    //     0x113283c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1132840: r17 = -5165
    //     0x1132840: mov             x17, #-0x142d
    // 0x1132844: add             x16, x2, x17
    // 0x1132848: cmp             x16, #1
    // 0x113284c: b.ls            #0x113285c
    // 0x1132850: r17 = 5163
    //     0x1132850: mov             x17, #0x142b
    // 0x1132854: cmp             x2, x17
    // 0x1132858: b.ne            #0x113286c
    // 0x113285c: ldr             x3, [fp, #0x10]
    // 0x1132860: LoadField: r0 = r3->field_13
    //     0x1132860: ldur            w0, [x3, #0x13]
    // 0x1132864: DecompressPointer r0
    //     0x1132864: add             x0, x0, HEAP, lsl #32
    // 0x1132868: b               #0x1132878
    // 0x113286c: ldr             x3, [fp, #0x10]
    // 0x1132870: r0 = Instance_Color
    //     0x1132870: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1132874: ldr             x0, [x0, #0x810]
    // 0x1132878: ldur            x1, [fp, #-0x18]
    // 0x113287c: ArrayStore: r1[3] = r0  ; List_4
    //     0x113287c: add             x25, x1, #0x1b
    //     0x1132880: str             w0, [x25]
    //     0x1132884: tbz             w0, #0, #0x11328a0
    //     0x1132888: ldurb           w16, [x1, #-1]
    //     0x113288c: ldurb           w17, [x0, #-1]
    //     0x1132890: and             x16, x17, x16, lsr #2
    //     0x1132894: tst             x16, HEAP, lsr #32
    //     0x1132898: b.eq            #0x11328a0
    //     0x113289c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11328a0: ArrayLoad: r0 = r3[0]  ; List_4
    //     0x11328a0: ldur            w0, [x3, #0x17]
    // 0x11328a4: DecompressPointer r0
    //     0x11328a4: add             x0, x0, HEAP, lsl #32
    // 0x11328a8: ldur            x1, [fp, #-0x18]
    // 0x11328ac: ArrayStore: r1[4] = r0  ; List_4
    //     0x11328ac: add             x25, x1, #0x1f
    //     0x11328b0: str             w0, [x25]
    //     0x11328b4: tbz             w0, #0, #0x11328d0
    //     0x11328b8: ldurb           w16, [x1, #-1]
    //     0x11328bc: ldurb           w17, [x0, #-1]
    //     0x11328c0: and             x16, x17, x16, lsr #2
    //     0x11328c4: tst             x16, HEAP, lsr #32
    //     0x11328c8: b.eq            #0x11328d0
    //     0x11328cc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11328d0: LoadField: r0 = r3->field_1b
    //     0x11328d0: ldur            w0, [x3, #0x1b]
    // 0x11328d4: DecompressPointer r0
    //     0x11328d4: add             x0, x0, HEAP, lsl #32
    // 0x11328d8: ldur            x1, [fp, #-0x18]
    // 0x11328dc: ArrayStore: r1[5] = r0  ; List_4
    //     0x11328dc: add             x25, x1, #0x23
    //     0x11328e0: str             w0, [x25]
    //     0x11328e4: tbz             w0, #0, #0x1132900
    //     0x11328e8: ldurb           w16, [x1, #-1]
    //     0x11328ec: ldurb           w17, [x0, #-1]
    //     0x11328f0: and             x16, x17, x16, lsr #2
    //     0x11328f4: tst             x16, HEAP, lsr #32
    //     0x11328f8: b.eq            #0x1132900
    //     0x11328fc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1132900: r17 = 5163
    //     0x1132900: mov             x17, #0x142b
    // 0x1132904: cmp             x2, x17
    // 0x1132908: b.ne            #0x1132918
    // 0x113290c: mov             x0, x2
    // 0x1132910: mov             x2, x3
    // 0x1132914: b               #0x1132970
    // 0x1132918: r17 = 5164
    //     0x1132918: mov             x17, #0x142c
    // 0x113291c: cmp             x2, x17
    // 0x1132920: b.ne            #0x113295c
    // 0x1132924: mov             x1, x3
    // 0x1132928: LoadField: r0 = r1->field_43
    //     0x1132928: ldur            w0, [x1, #0x43]
    // 0x113292c: DecompressPointer r0
    //     0x113292c: add             x0, x0, HEAP, lsl #32
    // 0x1132930: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1132934: cmp             w0, w16
    // 0x1132938: b.ne            #0x1132948
    // 0x113293c: r2 = _colors
    //     0x113293c: add             x2, PP, #0x26, lsl #12  ; [pp+0x263d0] Field <_DialogDefaultsM3@664506021._colors@664506021>: late final (offset: 0x44)
    //     0x1132940: ldr             x2, [x2, #0x3d0]
    // 0x1132944: r0 = InitLateFinalInstanceField()
    //     0x1132944: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1132948: LoadField: r1 = r0->field_2b
    //     0x1132948: ldur            w1, [x0, #0x2b]
    // 0x113294c: DecompressPointer r1
    //     0x113294c: add             x1, x1, HEAP, lsl #32
    // 0x1132950: mov             x0, x1
    // 0x1132954: ldur            x2, [fp, #-8]
    // 0x1132958: b               #0x11329bc
    // 0x113295c: mov             x0, x2
    // 0x1132960: r17 = 5165
    //     0x1132960: mov             x17, #0x142d
    // 0x1132964: cmp             x0, x17
    // 0x1132968: b.ne            #0x1132984
    // 0x113296c: ldr             x2, [fp, #0x10]
    // 0x1132970: LoadField: r1 = r2->field_2b
    //     0x1132970: ldur            w1, [x2, #0x2b]
    // 0x1132974: DecompressPointer r1
    //     0x1132974: add             x1, x1, HEAP, lsl #32
    // 0x1132978: mov             x2, x0
    // 0x113297c: mov             x0, x1
    // 0x1132980: b               #0x11329bc
    // 0x1132984: ldr             x2, [fp, #0x10]
    // 0x1132988: mov             x1, x2
    // 0x113298c: LoadField: r0 = r1->field_4b
    //     0x113298c: ldur            w0, [x1, #0x4b]
    // 0x1132990: DecompressPointer r0
    //     0x1132990: add             x0, x0, HEAP, lsl #32
    // 0x1132994: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1132998: cmp             w0, w16
    // 0x113299c: b.ne            #0x11329ac
    // 0x11329a0: r2 = iconTheme
    //     0x11329a0: add             x2, PP, #0x26, lsl #12  ; [pp+0x263e0] Field <_DialogDefaultsM2@664506021.iconTheme>: late final (offset: 0x4c)
    //     0x11329a4: ldr             x2, [x2, #0x3e0]
    // 0x11329a8: r0 = InitLateFinalInstanceField()
    //     0x11329a8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11329ac: LoadField: r1 = r0->field_1b
    //     0x11329ac: ldur            w1, [x0, #0x1b]
    // 0x11329b0: DecompressPointer r1
    //     0x11329b0: add             x1, x1, HEAP, lsl #32
    // 0x11329b4: mov             x0, x1
    // 0x11329b8: ldur            x2, [fp, #-8]
    // 0x11329bc: ldur            x1, [fp, #-0x18]
    // 0x11329c0: ArrayStore: r1[6] = r0  ; List_4
    //     0x11329c0: add             x25, x1, #0x27
    //     0x11329c4: str             w0, [x25]
    //     0x11329c8: tbz             w0, #0, #0x11329e4
    //     0x11329cc: ldurb           w16, [x1, #-1]
    //     0x11329d0: ldurb           w17, [x0, #-1]
    //     0x11329d4: and             x16, x17, x16, lsr #2
    //     0x11329d8: tst             x16, HEAP, lsr #32
    //     0x11329dc: b.eq            #0x11329e4
    //     0x11329e0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11329e4: r17 = 5163
    //     0x11329e4: mov             x17, #0x142b
    // 0x11329e8: cmp             x2, x17
    // 0x11329ec: b.ne            #0x11329f8
    // 0x11329f0: mov             x0, x2
    // 0x11329f4: b               #0x1132a4c
    // 0x11329f8: r17 = 5164
    //     0x11329f8: mov             x17, #0x142c
    // 0x11329fc: cmp             x2, x17
    // 0x1132a00: b.ne            #0x1132a3c
    // 0x1132a04: ldr             x1, [fp, #0x10]
    // 0x1132a08: LoadField: r0 = r1->field_47
    //     0x1132a08: ldur            w0, [x1, #0x47]
    // 0x1132a0c: DecompressPointer r0
    //     0x1132a0c: add             x0, x0, HEAP, lsl #32
    // 0x1132a10: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1132a14: cmp             w0, w16
    // 0x1132a18: b.ne            #0x1132a28
    // 0x1132a1c: r2 = _textTheme
    //     0x1132a1c: add             x2, PP, #0x26, lsl #12  ; [pp+0x263e8] Field <_DialogDefaultsM3@664506021._textTheme@664506021>: late final (offset: 0x48)
    //     0x1132a20: ldr             x2, [x2, #0x3e8]
    // 0x1132a24: r0 = InitLateFinalInstanceField()
    //     0x1132a24: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1132a28: LoadField: r1 = r0->field_1b
    //     0x1132a28: ldur            w1, [x0, #0x1b]
    // 0x1132a2c: DecompressPointer r1
    //     0x1132a2c: add             x1, x1, HEAP, lsl #32
    // 0x1132a30: mov             x0, x1
    // 0x1132a34: ldur            x2, [fp, #-8]
    // 0x1132a38: b               #0x1132a9c
    // 0x1132a3c: mov             x0, x2
    // 0x1132a40: r17 = 5165
    //     0x1132a40: mov             x17, #0x142d
    // 0x1132a44: cmp             x0, x17
    // 0x1132a48: b.ne            #0x1132a64
    // 0x1132a4c: ldr             x2, [fp, #0x10]
    // 0x1132a50: LoadField: r1 = r2->field_1f
    //     0x1132a50: ldur            w1, [x2, #0x1f]
    // 0x1132a54: DecompressPointer r1
    //     0x1132a54: add             x1, x1, HEAP, lsl #32
    // 0x1132a58: mov             x2, x0
    // 0x1132a5c: mov             x0, x1
    // 0x1132a60: b               #0x1132a9c
    // 0x1132a64: ldr             x2, [fp, #0x10]
    // 0x1132a68: mov             x1, x2
    // 0x1132a6c: LoadField: r0 = r1->field_47
    //     0x1132a6c: ldur            w0, [x1, #0x47]
    // 0x1132a70: DecompressPointer r0
    //     0x1132a70: add             x0, x0, HEAP, lsl #32
    // 0x1132a74: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1132a78: cmp             w0, w16
    // 0x1132a7c: b.ne            #0x1132a8c
    // 0x1132a80: r2 = textTheme
    //     0x1132a80: add             x2, PP, #0x26, lsl #12  ; [pp+0x263f0] Field <_DialogDefaultsM2@664506021.textTheme>: late final (offset: 0x48)
    //     0x1132a84: ldr             x2, [x2, #0x3f0]
    // 0x1132a88: r0 = InitLateFinalInstanceField()
    //     0x1132a88: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1132a8c: LoadField: r1 = r0->field_1f
    //     0x1132a8c: ldur            w1, [x0, #0x1f]
    // 0x1132a90: DecompressPointer r1
    //     0x1132a90: add             x1, x1, HEAP, lsl #32
    // 0x1132a94: mov             x0, x1
    // 0x1132a98: ldur            x2, [fp, #-8]
    // 0x1132a9c: ldur            x1, [fp, #-0x18]
    // 0x1132aa0: ArrayStore: r1[7] = r0  ; List_4
    //     0x1132aa0: add             x25, x1, #0x2b
    //     0x1132aa4: str             w0, [x25]
    //     0x1132aa8: tbz             w0, #0, #0x1132ac4
    //     0x1132aac: ldurb           w16, [x1, #-1]
    //     0x1132ab0: ldurb           w17, [x0, #-1]
    //     0x1132ab4: and             x16, x17, x16, lsr #2
    //     0x1132ab8: tst             x16, HEAP, lsr #32
    //     0x1132abc: b.eq            #0x1132ac4
    //     0x1132ac0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1132ac4: r17 = 5163
    //     0x1132ac4: mov             x17, #0x142b
    // 0x1132ac8: cmp             x2, x17
    // 0x1132acc: b.ne            #0x1132ad8
    // 0x1132ad0: mov             x0, x2
    // 0x1132ad4: b               #0x1132b2c
    // 0x1132ad8: r17 = 5164
    //     0x1132ad8: mov             x17, #0x142c
    // 0x1132adc: cmp             x2, x17
    // 0x1132ae0: b.ne            #0x1132b1c
    // 0x1132ae4: ldr             x1, [fp, #0x10]
    // 0x1132ae8: LoadField: r0 = r1->field_47
    //     0x1132ae8: ldur            w0, [x1, #0x47]
    // 0x1132aec: DecompressPointer r0
    //     0x1132aec: add             x0, x0, HEAP, lsl #32
    // 0x1132af0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1132af4: cmp             w0, w16
    // 0x1132af8: b.ne            #0x1132b08
    // 0x1132afc: r2 = _textTheme
    //     0x1132afc: add             x2, PP, #0x26, lsl #12  ; [pp+0x263e8] Field <_DialogDefaultsM3@664506021._textTheme@664506021>: late final (offset: 0x48)
    //     0x1132b00: ldr             x2, [x2, #0x3e8]
    // 0x1132b04: r0 = InitLateFinalInstanceField()
    //     0x1132b04: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1132b08: LoadField: r1 = r0->field_2f
    //     0x1132b08: ldur            w1, [x0, #0x2f]
    // 0x1132b0c: DecompressPointer r1
    //     0x1132b0c: add             x1, x1, HEAP, lsl #32
    // 0x1132b10: mov             x0, x1
    // 0x1132b14: ldur            x2, [fp, #-8]
    // 0x1132b18: b               #0x1132b7c
    // 0x1132b1c: mov             x0, x2
    // 0x1132b20: r17 = 5165
    //     0x1132b20: mov             x17, #0x142d
    // 0x1132b24: cmp             x0, x17
    // 0x1132b28: b.ne            #0x1132b44
    // 0x1132b2c: ldr             x2, [fp, #0x10]
    // 0x1132b30: LoadField: r1 = r2->field_23
    //     0x1132b30: ldur            w1, [x2, #0x23]
    // 0x1132b34: DecompressPointer r1
    //     0x1132b34: add             x1, x1, HEAP, lsl #32
    // 0x1132b38: mov             x2, x0
    // 0x1132b3c: mov             x0, x1
    // 0x1132b40: b               #0x1132b7c
    // 0x1132b44: ldr             x2, [fp, #0x10]
    // 0x1132b48: mov             x1, x2
    // 0x1132b4c: LoadField: r0 = r1->field_47
    //     0x1132b4c: ldur            w0, [x1, #0x47]
    // 0x1132b50: DecompressPointer r0
    //     0x1132b50: add             x0, x0, HEAP, lsl #32
    // 0x1132b54: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1132b58: cmp             w0, w16
    // 0x1132b5c: b.ne            #0x1132b6c
    // 0x1132b60: r2 = textTheme
    //     0x1132b60: add             x2, PP, #0x26, lsl #12  ; [pp+0x263f0] Field <_DialogDefaultsM2@664506021.textTheme>: late final (offset: 0x48)
    //     0x1132b64: ldr             x2, [x2, #0x3f0]
    // 0x1132b68: r0 = InitLateFinalInstanceField()
    //     0x1132b68: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1132b6c: LoadField: r1 = r0->field_23
    //     0x1132b6c: ldur            w1, [x0, #0x23]
    // 0x1132b70: DecompressPointer r1
    //     0x1132b70: add             x1, x1, HEAP, lsl #32
    // 0x1132b74: mov             x0, x1
    // 0x1132b78: ldur            x2, [fp, #-8]
    // 0x1132b7c: ldur            x1, [fp, #-0x18]
    // 0x1132b80: ArrayStore: r1[8] = r0  ; List_4
    //     0x1132b80: add             x25, x1, #0x2f
    //     0x1132b84: str             w0, [x25]
    //     0x1132b88: tbz             w0, #0, #0x1132ba4
    //     0x1132b8c: ldurb           w16, [x1, #-1]
    //     0x1132b90: ldurb           w17, [x0, #-1]
    //     0x1132b94: and             x16, x17, x16, lsr #2
    //     0x1132b98: tst             x16, HEAP, lsr #32
    //     0x1132b9c: b.eq            #0x1132ba4
    //     0x1132ba0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1132ba4: r17 = 5163
    //     0x1132ba4: mov             x17, #0x142b
    // 0x1132ba8: cmp             x2, x17
    // 0x1132bac: b.eq            #0x1132bd8
    // 0x1132bb0: r17 = 5164
    //     0x1132bb0: mov             x17, #0x142c
    // 0x1132bb4: cmp             x2, x17
    // 0x1132bb8: b.ne            #0x1132bcc
    // 0x1132bbc: ldr             x2, [fp, #0x10]
    // 0x1132bc0: r0 = Instance_EdgeInsets
    //     0x1132bc0: add             x0, PP, #0x26, lsl #12  ; [pp+0x263f8] Obj!EdgeInsets@129d9e1
    //     0x1132bc4: ldr             x0, [x0, #0x3f8]
    // 0x1132bc8: b               #0x1132bf0
    // 0x1132bcc: r17 = 5165
    //     0x1132bcc: mov             x17, #0x142d
    // 0x1132bd0: cmp             x2, x17
    // 0x1132bd4: b.ne            #0x1132be8
    // 0x1132bd8: ldr             x2, [fp, #0x10]
    // 0x1132bdc: LoadField: r0 = r2->field_27
    //     0x1132bdc: ldur            w0, [x2, #0x27]
    // 0x1132be0: DecompressPointer r0
    //     0x1132be0: add             x0, x0, HEAP, lsl #32
    // 0x1132be4: b               #0x1132bf0
    // 0x1132be8: ldr             x2, [fp, #0x10]
    // 0x1132bec: r0 = Instance_EdgeInsets
    //     0x1132bec: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0x1132bf0: ldur            x3, [fp, #-0x18]
    // 0x1132bf4: mov             x1, x3
    // 0x1132bf8: ArrayStore: r1[9] = r0  ; List_4
    //     0x1132bf8: add             x25, x1, #0x33
    //     0x1132bfc: str             w0, [x25]
    //     0x1132c00: tbz             w0, #0, #0x1132c1c
    //     0x1132c04: ldurb           w16, [x1, #-1]
    //     0x1132c08: ldurb           w17, [x0, #-1]
    //     0x1132c0c: and             x16, x17, x16, lsr #2
    //     0x1132c10: tst             x16, HEAP, lsr #32
    //     0x1132c14: b.eq            #0x1132c1c
    //     0x1132c18: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1132c1c: LoadField: r0 = r2->field_2f
    //     0x1132c1c: ldur            w0, [x2, #0x2f]
    // 0x1132c20: DecompressPointer r0
    //     0x1132c20: add             x0, x0, HEAP, lsl #32
    // 0x1132c24: StoreField: r3->field_37 = r0
    //     0x1132c24: stur            w0, [x3, #0x37]
    // 0x1132c28: LoadField: r0 = r2->field_33
    //     0x1132c28: ldur            w0, [x2, #0x33]
    // 0x1132c2c: DecompressPointer r0
    //     0x1132c2c: add             x0, x0, HEAP, lsl #32
    // 0x1132c30: mov             x1, x3
    // 0x1132c34: ArrayStore: r1[11] = r0  ; List_4
    //     0x1132c34: add             x25, x1, #0x3b
    //     0x1132c38: str             w0, [x25]
    //     0x1132c3c: tbz             w0, #0, #0x1132c58
    //     0x1132c40: ldurb           w16, [x1, #-1]
    //     0x1132c44: ldurb           w17, [x0, #-1]
    //     0x1132c48: and             x16, x17, x16, lsr #2
    //     0x1132c4c: tst             x16, HEAP, lsr #32
    //     0x1132c50: b.eq            #0x1132c58
    //     0x1132c54: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1132c58: LoadField: r0 = r2->field_37
    //     0x1132c58: ldur            w0, [x2, #0x37]
    // 0x1132c5c: DecompressPointer r0
    //     0x1132c5c: add             x0, x0, HEAP, lsl #32
    // 0x1132c60: mov             x1, x3
    // 0x1132c64: ArrayStore: r1[12] = r0  ; List_4
    //     0x1132c64: add             x25, x1, #0x3f
    //     0x1132c68: str             w0, [x25]
    //     0x1132c6c: tbz             w0, #0, #0x1132c88
    //     0x1132c70: ldurb           w16, [x1, #-1]
    //     0x1132c74: ldurb           w17, [x0, #-1]
    //     0x1132c78: and             x16, x17, x16, lsr #2
    //     0x1132c7c: tst             x16, HEAP, lsr #32
    //     0x1132c80: b.eq            #0x1132c88
    //     0x1132c84: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1132c88: LoadField: r0 = r2->field_3b
    //     0x1132c88: ldur            w0, [x2, #0x3b]
    // 0x1132c8c: DecompressPointer r0
    //     0x1132c8c: add             x0, x0, HEAP, lsl #32
    // 0x1132c90: mov             x1, x3
    // 0x1132c94: ArrayStore: r1[13] = r0  ; List_4
    //     0x1132c94: add             x25, x1, #0x43
    //     0x1132c98: str             w0, [x25]
    //     0x1132c9c: tbz             w0, #0, #0x1132cb8
    //     0x1132ca0: ldurb           w16, [x1, #-1]
    //     0x1132ca4: ldurb           w17, [x0, #-1]
    //     0x1132ca8: and             x16, x17, x16, lsr #2
    //     0x1132cac: tst             x16, HEAP, lsr #32
    //     0x1132cb0: b.eq            #0x1132cb8
    //     0x1132cb4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1132cb8: r1 = <Object?>
    //     0x1132cb8: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x1132cbc: r0 = AllocateGrowableArray()
    //     0x1132cbc: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x1132cc0: mov             x1, x0
    // 0x1132cc4: ldur            x0, [fp, #-0x18]
    // 0x1132cc8: StoreField: r1->field_f = r0
    //     0x1132cc8: stur            w0, [x1, #0xf]
    // 0x1132ccc: r0 = 28
    //     0x1132ccc: mov             x0, #0x1c
    // 0x1132cd0: StoreField: r1->field_b = r0
    //     0x1132cd0: stur            w0, [x1, #0xb]
    // 0x1132cd4: r0 = hashAll()
    //     0x1132cd4: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x1132cd8: mov             x2, x0
    // 0x1132cdc: r0 = BoxInt64Instr(r2)
    //     0x1132cdc: sbfiz           x0, x2, #1, #0x1f
    //     0x1132ce0: cmp             x2, x0, asr #1
    //     0x1132ce4: b.eq            #0x1132cf0
    //     0x1132ce8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1132cec: stur            x2, [x0, #7]
    // 0x1132cf0: LeaveFrame
    //     0x1132cf0: mov             SP, fp
    //     0x1132cf4: ldp             fp, lr, [SP], #0x10
    // 0x1132cf8: ret
    //     0x1132cf8: ret             
    // 0x1132cfc: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x1132cfc: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x1132d00: r0 = Throw()
    //     0x1132d00: bl              #0x13ddb2c  ; ThrowStub
    // 0x1132d04: brk             #0
    // 0x1132d08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1132d08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1132d0c: b               #0x1132650
    // 0x1132d10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1132d10: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x11678bc, size: 0x258
    // 0x11678bc: EnterFrame
    //     0x11678bc: stp             fp, lr, [SP, #-0x10]!
    //     0x11678c0: mov             fp, SP
    // 0x11678c4: AllocStack(0x40)
    //     0x11678c4: sub             SP, SP, #0x40
    // 0x11678c8: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x40 */)
    //     0x11678c8: mov             x4, x1
    //     0x11678cc: mov             x0, x2
    //     0x11678d0: stur            x1, [fp, #-0x10]
    //     0x11678d4: stur            x2, [fp, #-0x18]
    //     0x11678d8: stur            d0, [fp, #-0x40]
    // 0x11678dc: CheckStackOverflow
    //     0x11678dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11678e0: cmp             SP, x16
    //     0x11678e4: b.ls            #0x1167af0
    // 0x11678e8: cmp             w4, w0
    // 0x11678ec: b.ne            #0x1167900
    // 0x11678f0: mov             x0, x4
    // 0x11678f4: LeaveFrame
    //     0x11678f4: mov             SP, fp
    //     0x11678f8: ldp             fp, lr, [SP], #0x10
    // 0x11678fc: ret
    //     0x11678fc: ret             
    // 0x1167900: r5 = inline_Allocate_Double()
    //     0x1167900: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x1167904: add             x5, x5, #0x10
    //     0x1167908: cmp             x1, x5
    //     0x116790c: b.ls            #0x1167af8
    //     0x1167910: str             x5, [THR, #0x60]  ; THR::top
    //     0x1167914: sub             x5, x5, #0xf
    //     0x1167918: mov             x1, #0xe19c
    //     0x116791c: movk            x1, #3, lsl #16
    //     0x1167920: stur            x1, [x5, #-1]
    // 0x1167924: dmb             ishst
    // 0x1167928: StoreField: r5->field_7 = d0
    //     0x1167928: stur            d0, [x5, #7]
    // 0x116792c: mov             x3, x5
    // 0x1167930: stur            x5, [fp, #-8]
    // 0x1167934: r1 = Null
    //     0x1167934: mov             x1, NULL
    // 0x1167938: r2 = Null
    //     0x1167938: mov             x2, NULL
    // 0x116793c: r0 = lerp()
    //     0x116793c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167940: ldur            x0, [fp, #-0x10]
    // 0x1167944: LoadField: r1 = r0->field_b
    //     0x1167944: ldur            w1, [x0, #0xb]
    // 0x1167948: DecompressPointer r1
    //     0x1167948: add             x1, x1, HEAP, lsl #32
    // 0x116794c: ldur            x4, [fp, #-0x18]
    // 0x1167950: LoadField: r2 = r4->field_b
    //     0x1167950: ldur            w2, [x4, #0xb]
    // 0x1167954: DecompressPointer r2
    //     0x1167954: add             x2, x2, HEAP, lsl #32
    // 0x1167958: ldur            x3, [fp, #-8]
    // 0x116795c: r0 = lerpDouble()
    //     0x116795c: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1167960: ldur            x3, [fp, #-8]
    // 0x1167964: r1 = Null
    //     0x1167964: mov             x1, NULL
    // 0x1167968: r2 = Null
    //     0x1167968: mov             x2, NULL
    // 0x116796c: stur            x0, [fp, #-0x20]
    // 0x1167970: r0 = lerp()
    //     0x1167970: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167974: ldur            x3, [fp, #-8]
    // 0x1167978: r1 = Null
    //     0x1167978: mov             x1, NULL
    // 0x116797c: r2 = Null
    //     0x116797c: mov             x2, NULL
    // 0x1167980: r0 = lerp()
    //     0x1167980: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167984: ldur            x0, [fp, #-0x10]
    // 0x1167988: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1167988: ldur            w1, [x0, #0x17]
    // 0x116798c: DecompressPointer r1
    //     0x116798c: add             x1, x1, HEAP, lsl #32
    // 0x1167990: ldur            x3, [fp, #-0x18]
    // 0x1167994: ArrayLoad: r2 = r3[0]  ; List_4
    //     0x1167994: ldur            w2, [x3, #0x17]
    // 0x1167998: DecompressPointer r2
    //     0x1167998: add             x2, x2, HEAP, lsl #32
    // 0x116799c: ldur            d0, [fp, #-0x40]
    // 0x11679a0: r0 = lerp()
    //     0x11679a0: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x11679a4: mov             x3, x0
    // 0x11679a8: ldur            x0, [fp, #-0x10]
    // 0x11679ac: stur            x3, [fp, #-0x28]
    // 0x11679b0: LoadField: r1 = r0->field_1b
    //     0x11679b0: ldur            w1, [x0, #0x1b]
    // 0x11679b4: DecompressPointer r1
    //     0x11679b4: add             x1, x1, HEAP, lsl #32
    // 0x11679b8: ldur            x4, [fp, #-0x18]
    // 0x11679bc: LoadField: r2 = r4->field_1b
    //     0x11679bc: ldur            w2, [x4, #0x1b]
    // 0x11679c0: DecompressPointer r2
    //     0x11679c0: add             x2, x2, HEAP, lsl #32
    // 0x11679c4: ldur            d0, [fp, #-0x40]
    // 0x11679c8: r0 = lerp()
    //     0x11679c8: bl              #0x1160c48  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::lerp
    // 0x11679cc: ldur            x3, [fp, #-8]
    // 0x11679d0: r1 = Null
    //     0x11679d0: mov             x1, NULL
    // 0x11679d4: r2 = Null
    //     0x11679d4: mov             x2, NULL
    // 0x11679d8: stur            x0, [fp, #-0x30]
    // 0x11679dc: r0 = lerp()
    //     0x11679dc: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11679e0: ldur            x3, [fp, #-8]
    // 0x11679e4: r1 = Null
    //     0x11679e4: mov             x1, NULL
    // 0x11679e8: r2 = Null
    //     0x11679e8: mov             x2, NULL
    // 0x11679ec: r0 = lerp()
    //     0x11679ec: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x11679f0: ldur            x3, [fp, #-8]
    // 0x11679f4: r1 = Null
    //     0x11679f4: mov             x1, NULL
    // 0x11679f8: r2 = Null
    //     0x11679f8: mov             x2, NULL
    // 0x11679fc: r0 = lerp()
    //     0x11679fc: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1167a00: ldur            x3, [fp, #-8]
    // 0x1167a04: r1 = Null
    //     0x1167a04: mov             x1, NULL
    // 0x1167a08: r2 = Null
    //     0x1167a08: mov             x2, NULL
    // 0x1167a0c: r0 = lerp()
    //     0x1167a0c: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x1167a10: ldur            x3, [fp, #-8]
    // 0x1167a14: r1 = Null
    //     0x1167a14: mov             x1, NULL
    // 0x1167a18: r2 = Null
    //     0x1167a18: mov             x2, NULL
    // 0x1167a1c: r0 = lerp()
    //     0x1167a1c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167a20: ldur            x0, [fp, #-0x10]
    // 0x1167a24: LoadField: r1 = r0->field_33
    //     0x1167a24: ldur            w1, [x0, #0x33]
    // 0x1167a28: DecompressPointer r1
    //     0x1167a28: add             x1, x1, HEAP, lsl #32
    // 0x1167a2c: ldur            x3, [fp, #-0x18]
    // 0x1167a30: LoadField: r2 = r3->field_33
    //     0x1167a30: ldur            w2, [x3, #0x33]
    // 0x1167a34: DecompressPointer r2
    //     0x1167a34: add             x2, x2, HEAP, lsl #32
    // 0x1167a38: ldur            d0, [fp, #-0x40]
    // 0x1167a3c: r0 = lerp()
    //     0x1167a3c: bl              #0x868640  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::lerp
    // 0x1167a40: ldur            d0, [fp, #-0x40]
    // 0x1167a44: d1 = 0.500000
    //     0x1167a44: fmov            d1, #0.50000000
    // 0x1167a48: stur            x0, [fp, #-0x38]
    // 0x1167a4c: fcmp            d1, d0
    // 0x1167a50: b.le            #0x1167a6c
    // 0x1167a54: ldur            x1, [fp, #-0x10]
    // 0x1167a58: LoadField: r2 = r1->field_37
    //     0x1167a58: ldur            w2, [x1, #0x37]
    // 0x1167a5c: DecompressPointer r2
    //     0x1167a5c: add             x2, x2, HEAP, lsl #32
    // 0x1167a60: mov             x6, x2
    // 0x1167a64: ldur            x2, [fp, #-0x18]
    // 0x1167a68: b               #0x1167a80
    // 0x1167a6c: ldur            x1, [fp, #-0x10]
    // 0x1167a70: ldur            x2, [fp, #-0x18]
    // 0x1167a74: LoadField: r3 = r2->field_37
    //     0x1167a74: ldur            w3, [x2, #0x37]
    // 0x1167a78: DecompressPointer r3
    //     0x1167a78: add             x3, x3, HEAP, lsl #32
    // 0x1167a7c: mov             x6, x3
    // 0x1167a80: ldur            x5, [fp, #-0x20]
    // 0x1167a84: ldur            x4, [fp, #-0x28]
    // 0x1167a88: ldur            x3, [fp, #-0x30]
    // 0x1167a8c: stur            x6, [fp, #-8]
    // 0x1167a90: LoadField: r7 = r1->field_3b
    //     0x1167a90: ldur            w7, [x1, #0x3b]
    // 0x1167a94: DecompressPointer r7
    //     0x1167a94: add             x7, x7, HEAP, lsl #32
    // 0x1167a98: LoadField: r1 = r2->field_3b
    //     0x1167a98: ldur            w1, [x2, #0x3b]
    // 0x1167a9c: DecompressPointer r1
    //     0x1167a9c: add             x1, x1, HEAP, lsl #32
    // 0x1167aa0: mov             x2, x1
    // 0x1167aa4: mov             x1, x7
    // 0x1167aa8: r0 = lerp()
    //     0x1167aa8: bl              #0x1163c14  ; [package:flutter/src/rendering/box.dart] BoxConstraints::lerp
    // 0x1167aac: stur            x0, [fp, #-0x10]
    // 0x1167ab0: r0 = DialogThemeData()
    //     0x1167ab0: bl              #0xfb8ad8  ; AllocateDialogThemeDataStub -> DialogThemeData (size=0x40)
    // 0x1167ab4: ldur            x1, [fp, #-0x20]
    // 0x1167ab8: StoreField: r0->field_b = r1
    //     0x1167ab8: stur            w1, [x0, #0xb]
    // 0x1167abc: ldur            x1, [fp, #-0x28]
    // 0x1167ac0: ArrayStore: r0[0] = r1  ; List_4
    //     0x1167ac0: stur            w1, [x0, #0x17]
    // 0x1167ac4: ldur            x1, [fp, #-0x30]
    // 0x1167ac8: StoreField: r0->field_1b = r1
    //     0x1167ac8: stur            w1, [x0, #0x1b]
    // 0x1167acc: ldur            x1, [fp, #-0x38]
    // 0x1167ad0: StoreField: r0->field_33 = r1
    //     0x1167ad0: stur            w1, [x0, #0x33]
    // 0x1167ad4: ldur            x1, [fp, #-8]
    // 0x1167ad8: StoreField: r0->field_37 = r1
    //     0x1167ad8: stur            w1, [x0, #0x37]
    // 0x1167adc: ldur            x1, [fp, #-0x10]
    // 0x1167ae0: StoreField: r0->field_3b = r1
    //     0x1167ae0: stur            w1, [x0, #0x3b]
    // 0x1167ae4: LeaveFrame
    //     0x1167ae4: mov             SP, fp
    //     0x1167ae8: ldp             fp, lr, [SP], #0x10
    // 0x1167aec: ret
    //     0x1167aec: ret             
    // 0x1167af0: r0 = StackOverflowSharedWithFPURegs()
    //     0x1167af0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1167af4: b               #0x11678e8
    // 0x1167af8: SaveReg d0
    //     0x1167af8: str             q0, [SP, #-0x10]!
    // 0x1167afc: stp             x0, x4, [SP, #-0x10]!
    // 0x1167b00: r0 = AllocateDouble()
    //     0x1167b00: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1167b04: mov             x5, x0
    // 0x1167b08: ldp             x0, x4, [SP], #0x10
    // 0x1167b0c: RestoreReg d0
    //     0x1167b0c: ldr             q0, [SP], #0x10
    // 0x1167b10: b               #0x1167928
  }
  _ ==(/* No info */) {
    // ** addr: 0x126aaf0, size: 0xac0
    // 0x126aaf0: EnterFrame
    //     0x126aaf0: stp             fp, lr, [SP, #-0x10]!
    //     0x126aaf4: mov             fp, SP
    // 0x126aaf8: AllocStack(0x28)
    //     0x126aaf8: sub             SP, SP, #0x28
    // 0x126aafc: CheckStackOverflow
    //     0x126aafc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x126ab00: cmp             SP, x16
    //     0x126ab04: b.ls            #0x126b5a0
    // 0x126ab08: ldr             x1, [fp, #0x10]
    // 0x126ab0c: cmp             w1, NULL
    // 0x126ab10: b.ne            #0x126ab24
    // 0x126ab14: r0 = false
    //     0x126ab14: add             x0, NULL, #0x30  ; false
    // 0x126ab18: LeaveFrame
    //     0x126ab18: mov             SP, fp
    //     0x126ab1c: ldp             fp, lr, [SP], #0x10
    // 0x126ab20: ret
    //     0x126ab20: ret             
    // 0x126ab24: ldr             x0, [fp, #0x18]
    // 0x126ab28: cmp             w0, w1
    // 0x126ab2c: b.ne            #0x126ab40
    // 0x126ab30: r0 = true
    //     0x126ab30: add             x0, NULL, #0x20  ; true
    // 0x126ab34: LeaveFrame
    //     0x126ab34: mov             SP, fp
    //     0x126ab38: ldp             fp, lr, [SP], #0x10
    // 0x126ab3c: ret
    //     0x126ab3c: ret             
    // 0x126ab40: stp             x0, x1, [SP]
    // 0x126ab44: r0 = _haveSameRuntimeType()
    //     0x126ab44: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x126ab48: tbz             w0, #4, #0x126ab5c
    // 0x126ab4c: r0 = false
    //     0x126ab4c: add             x0, NULL, #0x30  ; false
    // 0x126ab50: LeaveFrame
    //     0x126ab50: mov             SP, fp
    //     0x126ab54: ldp             fp, lr, [SP], #0x10
    // 0x126ab58: ret
    //     0x126ab58: ret             
    // 0x126ab5c: ldr             x0, [fp, #0x10]
    // 0x126ab60: r2 = 60
    //     0x126ab60: mov             x2, #0x3c
    // 0x126ab64: branchIfSmi(r0, 0x126ab70)
    //     0x126ab64: tbz             w0, #0, #0x126ab70
    // 0x126ab68: r2 = LoadClassIdInstr(r0)
    //     0x126ab68: ldur            x2, [x0, #-1]
    //     0x126ab6c: ubfx            x2, x2, #0xc, #0x14
    // 0x126ab70: stur            x2, [fp, #-8]
    // 0x126ab74: r17 = -5163
    //     0x126ab74: mov             x17, #-0x142b
    // 0x126ab78: add             x16, x2, x17
    // 0x126ab7c: cmp             x16, #3
    // 0x126ab80: b.hi            #0x126b578
    // 0x126ab84: r17 = 5163
    //     0x126ab84: mov             x17, #0x142b
    // 0x126ab88: cmp             x2, x17
    // 0x126ab8c: b.ne            #0x126aba0
    // 0x126ab90: LoadField: r1 = r0->field_7
    //     0x126ab90: ldur            w1, [x0, #7]
    // 0x126ab94: DecompressPointer r1
    //     0x126ab94: add             x1, x1, HEAP, lsl #32
    // 0x126ab98: mov             x2, x1
    // 0x126ab9c: b               #0x126ac74
    // 0x126aba0: r17 = 5164
    //     0x126aba0: mov             x17, #0x142c
    // 0x126aba4: cmp             x2, x17
    // 0x126aba8: b.ne            #0x126abfc
    // 0x126abac: mov             x1, x0
    // 0x126abb0: LoadField: r0 = r1->field_43
    //     0x126abb0: ldur            w0, [x1, #0x43]
    // 0x126abb4: DecompressPointer r0
    //     0x126abb4: add             x0, x0, HEAP, lsl #32
    // 0x126abb8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126abbc: cmp             w0, w16
    // 0x126abc0: b.ne            #0x126abd0
    // 0x126abc4: r2 = _colors
    //     0x126abc4: add             x2, PP, #0x26, lsl #12  ; [pp+0x263d0] Field <_DialogDefaultsM3@664506021._colors@664506021>: late final (offset: 0x44)
    //     0x126abc8: ldr             x2, [x2, #0x3d0]
    // 0x126abcc: r0 = InitLateFinalInstanceField()
    //     0x126abcc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126abd0: LoadField: r1 = r0->field_9b
    //     0x126abd0: ldur            w1, [x0, #0x9b]
    // 0x126abd4: DecompressPointer r1
    //     0x126abd4: add             x1, x1, HEAP, lsl #32
    // 0x126abd8: cmp             w1, NULL
    // 0x126abdc: b.ne            #0x126abf0
    // 0x126abe0: LoadField: r1 = r0->field_7b
    //     0x126abe0: ldur            w1, [x0, #0x7b]
    // 0x126abe4: DecompressPointer r1
    //     0x126abe4: add             x1, x1, HEAP, lsl #32
    // 0x126abe8: mov             x0, x1
    // 0x126abec: b               #0x126abf4
    // 0x126abf0: mov             x0, x1
    // 0x126abf4: mov             x2, x0
    // 0x126abf8: b               #0x126ac74
    // 0x126abfc: mov             x0, x2
    // 0x126ac00: r17 = 5165
    //     0x126ac00: mov             x17, #0x142d
    // 0x126ac04: cmp             x0, x17
    // 0x126ac08: b.eq            #0x126b588
    // 0x126ac0c: ldr             x1, [fp, #0x10]
    // 0x126ac10: LoadField: r0 = r1->field_43
    //     0x126ac10: ldur            w0, [x1, #0x43]
    // 0x126ac14: DecompressPointer r0
    //     0x126ac14: add             x0, x0, HEAP, lsl #32
    // 0x126ac18: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126ac1c: cmp             w0, w16
    // 0x126ac20: b.ne            #0x126ac30
    // 0x126ac24: r2 = theme
    //     0x126ac24: add             x2, PP, #0x26, lsl #12  ; [pp+0x263d8] Field <_DialogDefaultsM2@664506021.theme>: late final (offset: 0x44)
    //     0x126ac28: ldr             x2, [x2, #0x3d8]
    // 0x126ac2c: r0 = InitLateFinalInstanceField()
    //     0x126ac2c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126ac30: LoadField: r1 = r0->field_3f
    //     0x126ac30: ldur            w1, [x0, #0x3f]
    // 0x126ac34: DecompressPointer r1
    //     0x126ac34: add             x1, x1, HEAP, lsl #32
    // 0x126ac38: LoadField: r0 = r1->field_7
    //     0x126ac38: ldur            w0, [x1, #7]
    // 0x126ac3c: DecompressPointer r0
    //     0x126ac3c: add             x0, x0, HEAP, lsl #32
    // 0x126ac40: r16 = Instance_Brightness
    //     0x126ac40: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x126ac44: cmp             w0, w16
    // 0x126ac48: b.ne            #0x126ac68
    // 0x126ac4c: r1 = _ConstMap len:12
    //     0x126ac4c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c20] Map<int, Color>(12)
    //     0x126ac50: ldr             x1, [x1, #0xc20]
    // 0x126ac54: r2 = 1600
    //     0x126ac54: mov             x2, #0x640
    // 0x126ac58: r0 = []()
    //     0x126ac58: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x126ac5c: cmp             w0, NULL
    // 0x126ac60: b.eq            #0x126b5a8
    // 0x126ac64: b               #0x126ac70
    // 0x126ac68: r0 = Instance_Color
    //     0x126ac68: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x126ac6c: ldr             x0, [x0, #0xc38]
    // 0x126ac70: mov             x2, x0
    // 0x126ac74: ldr             x0, [fp, #0x18]
    // 0x126ac78: stur            x2, [fp, #-0x18]
    // 0x126ac7c: r3 = LoadClassIdInstr(r0)
    //     0x126ac7c: ldur            x3, [x0, #-1]
    //     0x126ac80: ubfx            x3, x3, #0xc, #0x14
    // 0x126ac84: stur            x3, [fp, #-0x10]
    // 0x126ac88: r17 = 5163
    //     0x126ac88: mov             x17, #0x142b
    // 0x126ac8c: cmp             x3, x17
    // 0x126ac90: b.ne            #0x126aca4
    // 0x126ac94: LoadField: r1 = r0->field_7
    //     0x126ac94: ldur            w1, [x0, #7]
    // 0x126ac98: DecompressPointer r1
    //     0x126ac98: add             x1, x1, HEAP, lsl #32
    // 0x126ac9c: mov             x0, x2
    // 0x126aca0: b               #0x126ad80
    // 0x126aca4: r17 = 5164
    //     0x126aca4: mov             x17, #0x142c
    // 0x126aca8: cmp             x3, x17
    // 0x126acac: b.ne            #0x126ad04
    // 0x126acb0: mov             x1, x0
    // 0x126acb4: LoadField: r0 = r1->field_43
    //     0x126acb4: ldur            w0, [x1, #0x43]
    // 0x126acb8: DecompressPointer r0
    //     0x126acb8: add             x0, x0, HEAP, lsl #32
    // 0x126acbc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126acc0: cmp             w0, w16
    // 0x126acc4: b.ne            #0x126acd4
    // 0x126acc8: r2 = _colors
    //     0x126acc8: add             x2, PP, #0x26, lsl #12  ; [pp+0x263d0] Field <_DialogDefaultsM3@664506021._colors@664506021>: late final (offset: 0x44)
    //     0x126accc: ldr             x2, [x2, #0x3d0]
    // 0x126acd0: r0 = InitLateFinalInstanceField()
    //     0x126acd0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126acd4: LoadField: r1 = r0->field_9b
    //     0x126acd4: ldur            w1, [x0, #0x9b]
    // 0x126acd8: DecompressPointer r1
    //     0x126acd8: add             x1, x1, HEAP, lsl #32
    // 0x126acdc: cmp             w1, NULL
    // 0x126ace0: b.ne            #0x126acf4
    // 0x126ace4: LoadField: r1 = r0->field_7b
    //     0x126ace4: ldur            w1, [x0, #0x7b]
    // 0x126ace8: DecompressPointer r1
    //     0x126ace8: add             x1, x1, HEAP, lsl #32
    // 0x126acec: mov             x0, x1
    // 0x126acf0: b               #0x126acf8
    // 0x126acf4: mov             x0, x1
    // 0x126acf8: mov             x1, x0
    // 0x126acfc: ldur            x0, [fp, #-0x18]
    // 0x126ad00: b               #0x126ad80
    // 0x126ad04: mov             x0, x3
    // 0x126ad08: r17 = 5165
    //     0x126ad08: mov             x17, #0x142d
    // 0x126ad0c: cmp             x0, x17
    // 0x126ad10: b.eq            #0x126b594
    // 0x126ad14: ldr             x1, [fp, #0x18]
    // 0x126ad18: LoadField: r0 = r1->field_43
    //     0x126ad18: ldur            w0, [x1, #0x43]
    // 0x126ad1c: DecompressPointer r0
    //     0x126ad1c: add             x0, x0, HEAP, lsl #32
    // 0x126ad20: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126ad24: cmp             w0, w16
    // 0x126ad28: b.ne            #0x126ad38
    // 0x126ad2c: r2 = theme
    //     0x126ad2c: add             x2, PP, #0x26, lsl #12  ; [pp+0x263d8] Field <_DialogDefaultsM2@664506021.theme>: late final (offset: 0x44)
    //     0x126ad30: ldr             x2, [x2, #0x3d8]
    // 0x126ad34: r0 = InitLateFinalInstanceField()
    //     0x126ad34: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126ad38: LoadField: r1 = r0->field_3f
    //     0x126ad38: ldur            w1, [x0, #0x3f]
    // 0x126ad3c: DecompressPointer r1
    //     0x126ad3c: add             x1, x1, HEAP, lsl #32
    // 0x126ad40: LoadField: r0 = r1->field_7
    //     0x126ad40: ldur            w0, [x1, #7]
    // 0x126ad44: DecompressPointer r0
    //     0x126ad44: add             x0, x0, HEAP, lsl #32
    // 0x126ad48: r16 = Instance_Brightness
    //     0x126ad48: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x126ad4c: cmp             w0, w16
    // 0x126ad50: b.ne            #0x126ad70
    // 0x126ad54: r1 = _ConstMap len:12
    //     0x126ad54: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c20] Map<int, Color>(12)
    //     0x126ad58: ldr             x1, [x1, #0xc20]
    // 0x126ad5c: r2 = 1600
    //     0x126ad5c: mov             x2, #0x640
    // 0x126ad60: r0 = []()
    //     0x126ad60: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x126ad64: cmp             w0, NULL
    // 0x126ad68: b.eq            #0x126b5ac
    // 0x126ad6c: b               #0x126ad78
    // 0x126ad70: r0 = Instance_Color
    //     0x126ad70: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x126ad74: ldr             x0, [x0, #0xc38]
    // 0x126ad78: mov             x1, x0
    // 0x126ad7c: ldur            x0, [fp, #-0x18]
    // 0x126ad80: r2 = LoadClassIdInstr(r0)
    //     0x126ad80: ldur            x2, [x0, #-1]
    //     0x126ad84: ubfx            x2, x2, #0xc, #0x14
    // 0x126ad88: stp             x1, x0, [SP]
    // 0x126ad8c: mov             x0, x2
    // 0x126ad90: mov             lr, x0
    // 0x126ad94: ldr             lr, [x21, lr, lsl #3]
    // 0x126ad98: blr             lr
    // 0x126ad9c: tbnz            w0, #4, #0x126b578
    // 0x126ada0: ldr             x1, [fp, #0x18]
    // 0x126ada4: ldr             x2, [fp, #0x10]
    // 0x126ada8: LoadField: r0 = r2->field_b
    //     0x126ada8: ldur            w0, [x2, #0xb]
    // 0x126adac: DecompressPointer r0
    //     0x126adac: add             x0, x0, HEAP, lsl #32
    // 0x126adb0: LoadField: r3 = r1->field_b
    //     0x126adb0: ldur            w3, [x1, #0xb]
    // 0x126adb4: DecompressPointer r3
    //     0x126adb4: add             x3, x3, HEAP, lsl #32
    // 0x126adb8: r4 = LoadClassIdInstr(r0)
    //     0x126adb8: ldur            x4, [x0, #-1]
    //     0x126adbc: ubfx            x4, x4, #0xc, #0x14
    // 0x126adc0: stp             x3, x0, [SP]
    // 0x126adc4: mov             x0, x4
    // 0x126adc8: mov             lr, x0
    // 0x126adcc: ldr             lr, [x21, lr, lsl #3]
    // 0x126add0: blr             lr
    // 0x126add4: tbnz            w0, #4, #0x126b578
    // 0x126add8: ldur            x0, [fp, #-8]
    // 0x126addc: r17 = 5163
    //     0x126addc: mov             x17, #0x142b
    // 0x126ade0: cmp             x0, x17
    // 0x126ade4: b.eq            #0x126ae0c
    // 0x126ade8: r17 = 5164
    //     0x126ade8: mov             x17, #0x142c
    // 0x126adec: cmp             x0, x17
    // 0x126adf0: b.ne            #0x126ae00
    // 0x126adf4: r2 = Instance_Color
    //     0x126adf4: add             x2, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x126adf8: ldr             x2, [x2, #0x810]
    // 0x126adfc: b               #0x126ae54
    // 0x126ae00: r17 = 5165
    //     0x126ae00: mov             x17, #0x142d
    // 0x126ae04: cmp             x0, x17
    // 0x126ae08: b.ne            #0x126ae20
    // 0x126ae0c: ldr             x2, [fp, #0x10]
    // 0x126ae10: LoadField: r1 = r2->field_f
    //     0x126ae10: ldur            w1, [x2, #0xf]
    // 0x126ae14: DecompressPointer r1
    //     0x126ae14: add             x1, x1, HEAP, lsl #32
    // 0x126ae18: mov             x2, x1
    // 0x126ae1c: b               #0x126ae54
    // 0x126ae20: ldr             x2, [fp, #0x10]
    // 0x126ae24: mov             x1, x2
    // 0x126ae28: LoadField: r0 = r1->field_43
    //     0x126ae28: ldur            w0, [x1, #0x43]
    // 0x126ae2c: DecompressPointer r0
    //     0x126ae2c: add             x0, x0, HEAP, lsl #32
    // 0x126ae30: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126ae34: cmp             w0, w16
    // 0x126ae38: b.ne            #0x126ae48
    // 0x126ae3c: r2 = theme
    //     0x126ae3c: add             x2, PP, #0x26, lsl #12  ; [pp+0x263d8] Field <_DialogDefaultsM2@664506021.theme>: late final (offset: 0x44)
    //     0x126ae40: ldr             x2, [x2, #0x3d8]
    // 0x126ae44: r0 = InitLateFinalInstanceField()
    //     0x126ae44: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126ae48: LoadField: r1 = r0->field_6f
    //     0x126ae48: ldur            w1, [x0, #0x6f]
    // 0x126ae4c: DecompressPointer r1
    //     0x126ae4c: add             x1, x1, HEAP, lsl #32
    // 0x126ae50: mov             x2, x1
    // 0x126ae54: ldur            x0, [fp, #-0x10]
    // 0x126ae58: stur            x2, [fp, #-0x18]
    // 0x126ae5c: r17 = 5163
    //     0x126ae5c: mov             x17, #0x142b
    // 0x126ae60: cmp             x0, x17
    // 0x126ae64: b.eq            #0x126ae90
    // 0x126ae68: r17 = 5164
    //     0x126ae68: mov             x17, #0x142c
    // 0x126ae6c: cmp             x0, x17
    // 0x126ae70: b.ne            #0x126ae84
    // 0x126ae74: mov             x0, x2
    // 0x126ae78: r1 = Instance_Color
    //     0x126ae78: add             x1, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x126ae7c: ldr             x1, [x1, #0x810]
    // 0x126ae80: b               #0x126aed8
    // 0x126ae84: r17 = 5165
    //     0x126ae84: mov             x17, #0x142d
    // 0x126ae88: cmp             x0, x17
    // 0x126ae8c: b.ne            #0x126aea4
    // 0x126ae90: ldr             x3, [fp, #0x18]
    // 0x126ae94: LoadField: r1 = r3->field_f
    //     0x126ae94: ldur            w1, [x3, #0xf]
    // 0x126ae98: DecompressPointer r1
    //     0x126ae98: add             x1, x1, HEAP, lsl #32
    // 0x126ae9c: mov             x0, x2
    // 0x126aea0: b               #0x126aed8
    // 0x126aea4: ldr             x3, [fp, #0x18]
    // 0x126aea8: mov             x1, x3
    // 0x126aeac: LoadField: r0 = r1->field_43
    //     0x126aeac: ldur            w0, [x1, #0x43]
    // 0x126aeb0: DecompressPointer r0
    //     0x126aeb0: add             x0, x0, HEAP, lsl #32
    // 0x126aeb4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126aeb8: cmp             w0, w16
    // 0x126aebc: b.ne            #0x126aecc
    // 0x126aec0: r2 = theme
    //     0x126aec0: add             x2, PP, #0x26, lsl #12  ; [pp+0x263d8] Field <_DialogDefaultsM2@664506021.theme>: late final (offset: 0x44)
    //     0x126aec4: ldr             x2, [x2, #0x3d8]
    // 0x126aec8: r0 = InitLateFinalInstanceField()
    //     0x126aec8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126aecc: LoadField: r1 = r0->field_6f
    //     0x126aecc: ldur            w1, [x0, #0x6f]
    // 0x126aed0: DecompressPointer r1
    //     0x126aed0: add             x1, x1, HEAP, lsl #32
    // 0x126aed4: ldur            x0, [fp, #-0x18]
    // 0x126aed8: r2 = LoadClassIdInstr(r0)
    //     0x126aed8: ldur            x2, [x0, #-1]
    //     0x126aedc: ubfx            x2, x2, #0xc, #0x14
    // 0x126aee0: stp             x1, x0, [SP]
    // 0x126aee4: mov             x0, x2
    // 0x126aee8: mov             lr, x0
    // 0x126aeec: ldr             lr, [x21, lr, lsl #3]
    // 0x126aef0: blr             lr
    // 0x126aef4: tbnz            w0, #4, #0x126b578
    // 0x126aef8: ldur            x1, [fp, #-8]
    // 0x126aefc: r17 = -5165
    //     0x126aefc: mov             x17, #-0x142d
    // 0x126af00: add             x16, x1, x17
    // 0x126af04: cmp             x16, #1
    // 0x126af08: b.ls            #0x126af18
    // 0x126af0c: r17 = 5163
    //     0x126af0c: mov             x17, #0x142b
    // 0x126af10: cmp             x1, x17
    // 0x126af14: b.ne            #0x126af28
    // 0x126af18: ldr             x2, [fp, #0x10]
    // 0x126af1c: LoadField: r0 = r2->field_13
    //     0x126af1c: ldur            w0, [x2, #0x13]
    // 0x126af20: DecompressPointer r0
    //     0x126af20: add             x0, x0, HEAP, lsl #32
    // 0x126af24: b               #0x126af34
    // 0x126af28: ldr             x2, [fp, #0x10]
    // 0x126af2c: r0 = Instance_Color
    //     0x126af2c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x126af30: ldr             x0, [x0, #0x810]
    // 0x126af34: ldur            x3, [fp, #-0x10]
    // 0x126af38: r17 = -5165
    //     0x126af38: mov             x17, #-0x142d
    // 0x126af3c: add             x16, x3, x17
    // 0x126af40: cmp             x16, #1
    // 0x126af44: b.ls            #0x126af54
    // 0x126af48: r17 = 5163
    //     0x126af48: mov             x17, #0x142b
    // 0x126af4c: cmp             x3, x17
    // 0x126af50: b.ne            #0x126af64
    // 0x126af54: ldr             x4, [fp, #0x18]
    // 0x126af58: LoadField: r5 = r4->field_13
    //     0x126af58: ldur            w5, [x4, #0x13]
    // 0x126af5c: DecompressPointer r5
    //     0x126af5c: add             x5, x5, HEAP, lsl #32
    // 0x126af60: b               #0x126af70
    // 0x126af64: ldr             x4, [fp, #0x18]
    // 0x126af68: r5 = Instance_Color
    //     0x126af68: add             x5, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x126af6c: ldr             x5, [x5, #0x810]
    // 0x126af70: r6 = LoadClassIdInstr(r0)
    //     0x126af70: ldur            x6, [x0, #-1]
    //     0x126af74: ubfx            x6, x6, #0xc, #0x14
    // 0x126af78: stp             x5, x0, [SP]
    // 0x126af7c: mov             x0, x6
    // 0x126af80: mov             lr, x0
    // 0x126af84: ldr             lr, [x21, lr, lsl #3]
    // 0x126af88: blr             lr
    // 0x126af8c: tbnz            w0, #4, #0x126b578
    // 0x126af90: ldr             x2, [fp, #0x18]
    // 0x126af94: ldr             x1, [fp, #0x10]
    // 0x126af98: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x126af98: ldur            w0, [x1, #0x17]
    // 0x126af9c: DecompressPointer r0
    //     0x126af9c: add             x0, x0, HEAP, lsl #32
    // 0x126afa0: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x126afa0: ldur            w3, [x2, #0x17]
    // 0x126afa4: DecompressPointer r3
    //     0x126afa4: add             x3, x3, HEAP, lsl #32
    // 0x126afa8: r4 = LoadClassIdInstr(r0)
    //     0x126afa8: ldur            x4, [x0, #-1]
    //     0x126afac: ubfx            x4, x4, #0xc, #0x14
    // 0x126afb0: stp             x3, x0, [SP]
    // 0x126afb4: mov             x0, x4
    // 0x126afb8: mov             lr, x0
    // 0x126afbc: ldr             lr, [x21, lr, lsl #3]
    // 0x126afc0: blr             lr
    // 0x126afc4: tbnz            w0, #4, #0x126b578
    // 0x126afc8: ldr             x2, [fp, #0x18]
    // 0x126afcc: ldr             x1, [fp, #0x10]
    // 0x126afd0: LoadField: r0 = r1->field_1b
    //     0x126afd0: ldur            w0, [x1, #0x1b]
    // 0x126afd4: DecompressPointer r0
    //     0x126afd4: add             x0, x0, HEAP, lsl #32
    // 0x126afd8: LoadField: r3 = r2->field_1b
    //     0x126afd8: ldur            w3, [x2, #0x1b]
    // 0x126afdc: DecompressPointer r3
    //     0x126afdc: add             x3, x3, HEAP, lsl #32
    // 0x126afe0: r4 = LoadClassIdInstr(r0)
    //     0x126afe0: ldur            x4, [x0, #-1]
    //     0x126afe4: ubfx            x4, x4, #0xc, #0x14
    // 0x126afe8: stp             x3, x0, [SP]
    // 0x126afec: mov             x0, x4
    // 0x126aff0: mov             lr, x0
    // 0x126aff4: ldr             lr, [x21, lr, lsl #3]
    // 0x126aff8: blr             lr
    // 0x126affc: tbnz            w0, #4, #0x126b578
    // 0x126b000: ldur            x0, [fp, #-8]
    // 0x126b004: r17 = 5163
    //     0x126b004: mov             x17, #0x142b
    // 0x126b008: cmp             x0, x17
    // 0x126b00c: b.eq            #0x126b05c
    // 0x126b010: r17 = 5164
    //     0x126b010: mov             x17, #0x142c
    // 0x126b014: cmp             x0, x17
    // 0x126b018: b.ne            #0x126b050
    // 0x126b01c: ldr             x1, [fp, #0x10]
    // 0x126b020: LoadField: r0 = r1->field_43
    //     0x126b020: ldur            w0, [x1, #0x43]
    // 0x126b024: DecompressPointer r0
    //     0x126b024: add             x0, x0, HEAP, lsl #32
    // 0x126b028: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126b02c: cmp             w0, w16
    // 0x126b030: b.ne            #0x126b040
    // 0x126b034: r2 = _colors
    //     0x126b034: add             x2, PP, #0x26, lsl #12  ; [pp+0x263d0] Field <_DialogDefaultsM3@664506021._colors@664506021>: late final (offset: 0x44)
    //     0x126b038: ldr             x2, [x2, #0x3d0]
    // 0x126b03c: r0 = InitLateFinalInstanceField()
    //     0x126b03c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126b040: LoadField: r1 = r0->field_2b
    //     0x126b040: ldur            w1, [x0, #0x2b]
    // 0x126b044: DecompressPointer r1
    //     0x126b044: add             x1, x1, HEAP, lsl #32
    // 0x126b048: mov             x2, x1
    // 0x126b04c: b               #0x126b0a4
    // 0x126b050: r17 = 5165
    //     0x126b050: mov             x17, #0x142d
    // 0x126b054: cmp             x0, x17
    // 0x126b058: b.ne            #0x126b070
    // 0x126b05c: ldr             x2, [fp, #0x10]
    // 0x126b060: LoadField: r1 = r2->field_2b
    //     0x126b060: ldur            w1, [x2, #0x2b]
    // 0x126b064: DecompressPointer r1
    //     0x126b064: add             x1, x1, HEAP, lsl #32
    // 0x126b068: mov             x2, x1
    // 0x126b06c: b               #0x126b0a4
    // 0x126b070: ldr             x2, [fp, #0x10]
    // 0x126b074: mov             x1, x2
    // 0x126b078: LoadField: r0 = r1->field_4b
    //     0x126b078: ldur            w0, [x1, #0x4b]
    // 0x126b07c: DecompressPointer r0
    //     0x126b07c: add             x0, x0, HEAP, lsl #32
    // 0x126b080: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126b084: cmp             w0, w16
    // 0x126b088: b.ne            #0x126b098
    // 0x126b08c: r2 = iconTheme
    //     0x126b08c: add             x2, PP, #0x26, lsl #12  ; [pp+0x263e0] Field <_DialogDefaultsM2@664506021.iconTheme>: late final (offset: 0x4c)
    //     0x126b090: ldr             x2, [x2, #0x3e0]
    // 0x126b094: r0 = InitLateFinalInstanceField()
    //     0x126b094: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126b098: LoadField: r1 = r0->field_1b
    //     0x126b098: ldur            w1, [x0, #0x1b]
    // 0x126b09c: DecompressPointer r1
    //     0x126b09c: add             x1, x1, HEAP, lsl #32
    // 0x126b0a0: mov             x2, x1
    // 0x126b0a4: ldur            x0, [fp, #-0x10]
    // 0x126b0a8: stur            x2, [fp, #-0x18]
    // 0x126b0ac: r17 = 5163
    //     0x126b0ac: mov             x17, #0x142b
    // 0x126b0b0: cmp             x0, x17
    // 0x126b0b4: b.eq            #0x126b100
    // 0x126b0b8: r17 = 5164
    //     0x126b0b8: mov             x17, #0x142c
    // 0x126b0bc: cmp             x0, x17
    // 0x126b0c0: b.ne            #0x126b0f4
    // 0x126b0c4: ldr             x1, [fp, #0x18]
    // 0x126b0c8: LoadField: r0 = r1->field_43
    //     0x126b0c8: ldur            w0, [x1, #0x43]
    // 0x126b0cc: DecompressPointer r0
    //     0x126b0cc: add             x0, x0, HEAP, lsl #32
    // 0x126b0d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126b0d4: cmp             w0, w16
    // 0x126b0d8: b.ne            #0x126b0e8
    // 0x126b0dc: r2 = _colors
    //     0x126b0dc: add             x2, PP, #0x26, lsl #12  ; [pp+0x263d0] Field <_DialogDefaultsM3@664506021._colors@664506021>: late final (offset: 0x44)
    //     0x126b0e0: ldr             x2, [x2, #0x3d0]
    // 0x126b0e4: r0 = InitLateFinalInstanceField()
    //     0x126b0e4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126b0e8: LoadField: r1 = r0->field_2b
    //     0x126b0e8: ldur            w1, [x0, #0x2b]
    // 0x126b0ec: DecompressPointer r1
    //     0x126b0ec: add             x1, x1, HEAP, lsl #32
    // 0x126b0f0: b               #0x126b140
    // 0x126b0f4: r17 = 5165
    //     0x126b0f4: mov             x17, #0x142d
    // 0x126b0f8: cmp             x0, x17
    // 0x126b0fc: b.ne            #0x126b110
    // 0x126b100: ldr             x2, [fp, #0x18]
    // 0x126b104: LoadField: r1 = r2->field_2b
    //     0x126b104: ldur            w1, [x2, #0x2b]
    // 0x126b108: DecompressPointer r1
    //     0x126b108: add             x1, x1, HEAP, lsl #32
    // 0x126b10c: b               #0x126b140
    // 0x126b110: ldr             x2, [fp, #0x18]
    // 0x126b114: mov             x1, x2
    // 0x126b118: LoadField: r0 = r1->field_4b
    //     0x126b118: ldur            w0, [x1, #0x4b]
    // 0x126b11c: DecompressPointer r0
    //     0x126b11c: add             x0, x0, HEAP, lsl #32
    // 0x126b120: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126b124: cmp             w0, w16
    // 0x126b128: b.ne            #0x126b138
    // 0x126b12c: r2 = iconTheme
    //     0x126b12c: add             x2, PP, #0x26, lsl #12  ; [pp+0x263e0] Field <_DialogDefaultsM2@664506021.iconTheme>: late final (offset: 0x4c)
    //     0x126b130: ldr             x2, [x2, #0x3e0]
    // 0x126b134: r0 = InitLateFinalInstanceField()
    //     0x126b134: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126b138: LoadField: r1 = r0->field_1b
    //     0x126b138: ldur            w1, [x0, #0x1b]
    // 0x126b13c: DecompressPointer r1
    //     0x126b13c: add             x1, x1, HEAP, lsl #32
    // 0x126b140: ldur            x0, [fp, #-0x18]
    // 0x126b144: r2 = LoadClassIdInstr(r0)
    //     0x126b144: ldur            x2, [x0, #-1]
    //     0x126b148: ubfx            x2, x2, #0xc, #0x14
    // 0x126b14c: stp             x1, x0, [SP]
    // 0x126b150: mov             x0, x2
    // 0x126b154: mov             lr, x0
    // 0x126b158: ldr             lr, [x21, lr, lsl #3]
    // 0x126b15c: blr             lr
    // 0x126b160: tbnz            w0, #4, #0x126b578
    // 0x126b164: ldur            x0, [fp, #-8]
    // 0x126b168: r17 = 5163
    //     0x126b168: mov             x17, #0x142b
    // 0x126b16c: cmp             x0, x17
    // 0x126b170: b.eq            #0x126b1c0
    // 0x126b174: r17 = 5164
    //     0x126b174: mov             x17, #0x142c
    // 0x126b178: cmp             x0, x17
    // 0x126b17c: b.ne            #0x126b1b4
    // 0x126b180: ldr             x1, [fp, #0x10]
    // 0x126b184: LoadField: r0 = r1->field_47
    //     0x126b184: ldur            w0, [x1, #0x47]
    // 0x126b188: DecompressPointer r0
    //     0x126b188: add             x0, x0, HEAP, lsl #32
    // 0x126b18c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126b190: cmp             w0, w16
    // 0x126b194: b.ne            #0x126b1a4
    // 0x126b198: r2 = _textTheme
    //     0x126b198: add             x2, PP, #0x26, lsl #12  ; [pp+0x263e8] Field <_DialogDefaultsM3@664506021._textTheme@664506021>: late final (offset: 0x48)
    //     0x126b19c: ldr             x2, [x2, #0x3e8]
    // 0x126b1a0: r0 = InitLateFinalInstanceField()
    //     0x126b1a0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126b1a4: LoadField: r1 = r0->field_1b
    //     0x126b1a4: ldur            w1, [x0, #0x1b]
    // 0x126b1a8: DecompressPointer r1
    //     0x126b1a8: add             x1, x1, HEAP, lsl #32
    // 0x126b1ac: mov             x2, x1
    // 0x126b1b0: b               #0x126b208
    // 0x126b1b4: r17 = 5165
    //     0x126b1b4: mov             x17, #0x142d
    // 0x126b1b8: cmp             x0, x17
    // 0x126b1bc: b.ne            #0x126b1d4
    // 0x126b1c0: ldr             x2, [fp, #0x10]
    // 0x126b1c4: LoadField: r1 = r2->field_1f
    //     0x126b1c4: ldur            w1, [x2, #0x1f]
    // 0x126b1c8: DecompressPointer r1
    //     0x126b1c8: add             x1, x1, HEAP, lsl #32
    // 0x126b1cc: mov             x2, x1
    // 0x126b1d0: b               #0x126b208
    // 0x126b1d4: ldr             x2, [fp, #0x10]
    // 0x126b1d8: mov             x1, x2
    // 0x126b1dc: LoadField: r0 = r1->field_47
    //     0x126b1dc: ldur            w0, [x1, #0x47]
    // 0x126b1e0: DecompressPointer r0
    //     0x126b1e0: add             x0, x0, HEAP, lsl #32
    // 0x126b1e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126b1e8: cmp             w0, w16
    // 0x126b1ec: b.ne            #0x126b1fc
    // 0x126b1f0: r2 = textTheme
    //     0x126b1f0: add             x2, PP, #0x26, lsl #12  ; [pp+0x263f0] Field <_DialogDefaultsM2@664506021.textTheme>: late final (offset: 0x48)
    //     0x126b1f4: ldr             x2, [x2, #0x3f0]
    // 0x126b1f8: r0 = InitLateFinalInstanceField()
    //     0x126b1f8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126b1fc: LoadField: r1 = r0->field_1f
    //     0x126b1fc: ldur            w1, [x0, #0x1f]
    // 0x126b200: DecompressPointer r1
    //     0x126b200: add             x1, x1, HEAP, lsl #32
    // 0x126b204: mov             x2, x1
    // 0x126b208: ldur            x0, [fp, #-0x10]
    // 0x126b20c: stur            x2, [fp, #-0x18]
    // 0x126b210: r17 = 5163
    //     0x126b210: mov             x17, #0x142b
    // 0x126b214: cmp             x0, x17
    // 0x126b218: b.eq            #0x126b264
    // 0x126b21c: r17 = 5164
    //     0x126b21c: mov             x17, #0x142c
    // 0x126b220: cmp             x0, x17
    // 0x126b224: b.ne            #0x126b258
    // 0x126b228: ldr             x1, [fp, #0x18]
    // 0x126b22c: LoadField: r0 = r1->field_47
    //     0x126b22c: ldur            w0, [x1, #0x47]
    // 0x126b230: DecompressPointer r0
    //     0x126b230: add             x0, x0, HEAP, lsl #32
    // 0x126b234: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126b238: cmp             w0, w16
    // 0x126b23c: b.ne            #0x126b24c
    // 0x126b240: r2 = _textTheme
    //     0x126b240: add             x2, PP, #0x26, lsl #12  ; [pp+0x263e8] Field <_DialogDefaultsM3@664506021._textTheme@664506021>: late final (offset: 0x48)
    //     0x126b244: ldr             x2, [x2, #0x3e8]
    // 0x126b248: r0 = InitLateFinalInstanceField()
    //     0x126b248: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126b24c: LoadField: r1 = r0->field_1b
    //     0x126b24c: ldur            w1, [x0, #0x1b]
    // 0x126b250: DecompressPointer r1
    //     0x126b250: add             x1, x1, HEAP, lsl #32
    // 0x126b254: b               #0x126b2a4
    // 0x126b258: r17 = 5165
    //     0x126b258: mov             x17, #0x142d
    // 0x126b25c: cmp             x0, x17
    // 0x126b260: b.ne            #0x126b274
    // 0x126b264: ldr             x2, [fp, #0x18]
    // 0x126b268: LoadField: r1 = r2->field_1f
    //     0x126b268: ldur            w1, [x2, #0x1f]
    // 0x126b26c: DecompressPointer r1
    //     0x126b26c: add             x1, x1, HEAP, lsl #32
    // 0x126b270: b               #0x126b2a4
    // 0x126b274: ldr             x2, [fp, #0x18]
    // 0x126b278: mov             x1, x2
    // 0x126b27c: LoadField: r0 = r1->field_47
    //     0x126b27c: ldur            w0, [x1, #0x47]
    // 0x126b280: DecompressPointer r0
    //     0x126b280: add             x0, x0, HEAP, lsl #32
    // 0x126b284: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126b288: cmp             w0, w16
    // 0x126b28c: b.ne            #0x126b29c
    // 0x126b290: r2 = textTheme
    //     0x126b290: add             x2, PP, #0x26, lsl #12  ; [pp+0x263f0] Field <_DialogDefaultsM2@664506021.textTheme>: late final (offset: 0x48)
    //     0x126b294: ldr             x2, [x2, #0x3f0]
    // 0x126b298: r0 = InitLateFinalInstanceField()
    //     0x126b298: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126b29c: LoadField: r1 = r0->field_1f
    //     0x126b29c: ldur            w1, [x0, #0x1f]
    // 0x126b2a0: DecompressPointer r1
    //     0x126b2a0: add             x1, x1, HEAP, lsl #32
    // 0x126b2a4: ldur            x0, [fp, #-0x18]
    // 0x126b2a8: r2 = LoadClassIdInstr(r0)
    //     0x126b2a8: ldur            x2, [x0, #-1]
    //     0x126b2ac: ubfx            x2, x2, #0xc, #0x14
    // 0x126b2b0: stp             x1, x0, [SP]
    // 0x126b2b4: mov             x0, x2
    // 0x126b2b8: mov             lr, x0
    // 0x126b2bc: ldr             lr, [x21, lr, lsl #3]
    // 0x126b2c0: blr             lr
    // 0x126b2c4: tbnz            w0, #4, #0x126b578
    // 0x126b2c8: ldur            x0, [fp, #-8]
    // 0x126b2cc: r17 = 5163
    //     0x126b2cc: mov             x17, #0x142b
    // 0x126b2d0: cmp             x0, x17
    // 0x126b2d4: b.eq            #0x126b324
    // 0x126b2d8: r17 = 5164
    //     0x126b2d8: mov             x17, #0x142c
    // 0x126b2dc: cmp             x0, x17
    // 0x126b2e0: b.ne            #0x126b318
    // 0x126b2e4: ldr             x1, [fp, #0x10]
    // 0x126b2e8: LoadField: r0 = r1->field_47
    //     0x126b2e8: ldur            w0, [x1, #0x47]
    // 0x126b2ec: DecompressPointer r0
    //     0x126b2ec: add             x0, x0, HEAP, lsl #32
    // 0x126b2f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126b2f4: cmp             w0, w16
    // 0x126b2f8: b.ne            #0x126b308
    // 0x126b2fc: r2 = _textTheme
    //     0x126b2fc: add             x2, PP, #0x26, lsl #12  ; [pp+0x263e8] Field <_DialogDefaultsM3@664506021._textTheme@664506021>: late final (offset: 0x48)
    //     0x126b300: ldr             x2, [x2, #0x3e8]
    // 0x126b304: r0 = InitLateFinalInstanceField()
    //     0x126b304: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126b308: LoadField: r1 = r0->field_2f
    //     0x126b308: ldur            w1, [x0, #0x2f]
    // 0x126b30c: DecompressPointer r1
    //     0x126b30c: add             x1, x1, HEAP, lsl #32
    // 0x126b310: mov             x2, x1
    // 0x126b314: b               #0x126b36c
    // 0x126b318: r17 = 5165
    //     0x126b318: mov             x17, #0x142d
    // 0x126b31c: cmp             x0, x17
    // 0x126b320: b.ne            #0x126b338
    // 0x126b324: ldr             x2, [fp, #0x10]
    // 0x126b328: LoadField: r1 = r2->field_23
    //     0x126b328: ldur            w1, [x2, #0x23]
    // 0x126b32c: DecompressPointer r1
    //     0x126b32c: add             x1, x1, HEAP, lsl #32
    // 0x126b330: mov             x2, x1
    // 0x126b334: b               #0x126b36c
    // 0x126b338: ldr             x2, [fp, #0x10]
    // 0x126b33c: mov             x1, x2
    // 0x126b340: LoadField: r0 = r1->field_47
    //     0x126b340: ldur            w0, [x1, #0x47]
    // 0x126b344: DecompressPointer r0
    //     0x126b344: add             x0, x0, HEAP, lsl #32
    // 0x126b348: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126b34c: cmp             w0, w16
    // 0x126b350: b.ne            #0x126b360
    // 0x126b354: r2 = textTheme
    //     0x126b354: add             x2, PP, #0x26, lsl #12  ; [pp+0x263f0] Field <_DialogDefaultsM2@664506021.textTheme>: late final (offset: 0x48)
    //     0x126b358: ldr             x2, [x2, #0x3f0]
    // 0x126b35c: r0 = InitLateFinalInstanceField()
    //     0x126b35c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126b360: LoadField: r1 = r0->field_23
    //     0x126b360: ldur            w1, [x0, #0x23]
    // 0x126b364: DecompressPointer r1
    //     0x126b364: add             x1, x1, HEAP, lsl #32
    // 0x126b368: mov             x2, x1
    // 0x126b36c: ldur            x0, [fp, #-0x10]
    // 0x126b370: stur            x2, [fp, #-0x18]
    // 0x126b374: r17 = 5163
    //     0x126b374: mov             x17, #0x142b
    // 0x126b378: cmp             x0, x17
    // 0x126b37c: b.eq            #0x126b3c8
    // 0x126b380: r17 = 5164
    //     0x126b380: mov             x17, #0x142c
    // 0x126b384: cmp             x0, x17
    // 0x126b388: b.ne            #0x126b3bc
    // 0x126b38c: ldr             x1, [fp, #0x18]
    // 0x126b390: LoadField: r0 = r1->field_47
    //     0x126b390: ldur            w0, [x1, #0x47]
    // 0x126b394: DecompressPointer r0
    //     0x126b394: add             x0, x0, HEAP, lsl #32
    // 0x126b398: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126b39c: cmp             w0, w16
    // 0x126b3a0: b.ne            #0x126b3b0
    // 0x126b3a4: r2 = _textTheme
    //     0x126b3a4: add             x2, PP, #0x26, lsl #12  ; [pp+0x263e8] Field <_DialogDefaultsM3@664506021._textTheme@664506021>: late final (offset: 0x48)
    //     0x126b3a8: ldr             x2, [x2, #0x3e8]
    // 0x126b3ac: r0 = InitLateFinalInstanceField()
    //     0x126b3ac: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126b3b0: LoadField: r1 = r0->field_2f
    //     0x126b3b0: ldur            w1, [x0, #0x2f]
    // 0x126b3b4: DecompressPointer r1
    //     0x126b3b4: add             x1, x1, HEAP, lsl #32
    // 0x126b3b8: b               #0x126b408
    // 0x126b3bc: r17 = 5165
    //     0x126b3bc: mov             x17, #0x142d
    // 0x126b3c0: cmp             x0, x17
    // 0x126b3c4: b.ne            #0x126b3d8
    // 0x126b3c8: ldr             x2, [fp, #0x18]
    // 0x126b3cc: LoadField: r1 = r2->field_23
    //     0x126b3cc: ldur            w1, [x2, #0x23]
    // 0x126b3d0: DecompressPointer r1
    //     0x126b3d0: add             x1, x1, HEAP, lsl #32
    // 0x126b3d4: b               #0x126b408
    // 0x126b3d8: ldr             x2, [fp, #0x18]
    // 0x126b3dc: mov             x1, x2
    // 0x126b3e0: LoadField: r0 = r1->field_47
    //     0x126b3e0: ldur            w0, [x1, #0x47]
    // 0x126b3e4: DecompressPointer r0
    //     0x126b3e4: add             x0, x0, HEAP, lsl #32
    // 0x126b3e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126b3ec: cmp             w0, w16
    // 0x126b3f0: b.ne            #0x126b400
    // 0x126b3f4: r2 = textTheme
    //     0x126b3f4: add             x2, PP, #0x26, lsl #12  ; [pp+0x263f0] Field <_DialogDefaultsM2@664506021.textTheme>: late final (offset: 0x48)
    //     0x126b3f8: ldr             x2, [x2, #0x3f0]
    // 0x126b3fc: r0 = InitLateFinalInstanceField()
    //     0x126b3fc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126b400: LoadField: r1 = r0->field_23
    //     0x126b400: ldur            w1, [x0, #0x23]
    // 0x126b404: DecompressPointer r1
    //     0x126b404: add             x1, x1, HEAP, lsl #32
    // 0x126b408: ldur            x0, [fp, #-0x18]
    // 0x126b40c: r2 = LoadClassIdInstr(r0)
    //     0x126b40c: ldur            x2, [x0, #-1]
    //     0x126b410: ubfx            x2, x2, #0xc, #0x14
    // 0x126b414: stp             x1, x0, [SP]
    // 0x126b418: mov             x0, x2
    // 0x126b41c: mov             lr, x0
    // 0x126b420: ldr             lr, [x21, lr, lsl #3]
    // 0x126b424: blr             lr
    // 0x126b428: tbnz            w0, #4, #0x126b578
    // 0x126b42c: ldur            x0, [fp, #-8]
    // 0x126b430: r17 = 5163
    //     0x126b430: mov             x17, #0x142b
    // 0x126b434: cmp             x0, x17
    // 0x126b438: b.eq            #0x126b464
    // 0x126b43c: r17 = 5164
    //     0x126b43c: mov             x17, #0x142c
    // 0x126b440: cmp             x0, x17
    // 0x126b444: b.ne            #0x126b458
    // 0x126b448: ldr             x1, [fp, #0x10]
    // 0x126b44c: r2 = Instance_EdgeInsets
    //     0x126b44c: add             x2, PP, #0x26, lsl #12  ; [pp+0x263f8] Obj!EdgeInsets@129d9e1
    //     0x126b450: ldr             x2, [x2, #0x3f8]
    // 0x126b454: b               #0x126b480
    // 0x126b458: r17 = 5165
    //     0x126b458: mov             x17, #0x142d
    // 0x126b45c: cmp             x0, x17
    // 0x126b460: b.ne            #0x126b478
    // 0x126b464: ldr             x1, [fp, #0x10]
    // 0x126b468: LoadField: r0 = r1->field_27
    //     0x126b468: ldur            w0, [x1, #0x27]
    // 0x126b46c: DecompressPointer r0
    //     0x126b46c: add             x0, x0, HEAP, lsl #32
    // 0x126b470: mov             x2, x0
    // 0x126b474: b               #0x126b480
    // 0x126b478: ldr             x1, [fp, #0x10]
    // 0x126b47c: r2 = Instance_EdgeInsets
    //     0x126b47c: ldr             x2, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0x126b480: ldur            x0, [fp, #-0x10]
    // 0x126b484: r17 = 5163
    //     0x126b484: mov             x17, #0x142b
    // 0x126b488: cmp             x0, x17
    // 0x126b48c: b.eq            #0x126b4b8
    // 0x126b490: r17 = 5164
    //     0x126b490: mov             x17, #0x142c
    // 0x126b494: cmp             x0, x17
    // 0x126b498: b.ne            #0x126b4ac
    // 0x126b49c: ldr             x3, [fp, #0x18]
    // 0x126b4a0: r0 = Instance_EdgeInsets
    //     0x126b4a0: add             x0, PP, #0x26, lsl #12  ; [pp+0x263f8] Obj!EdgeInsets@129d9e1
    //     0x126b4a4: ldr             x0, [x0, #0x3f8]
    // 0x126b4a8: b               #0x126b4d0
    // 0x126b4ac: r17 = 5165
    //     0x126b4ac: mov             x17, #0x142d
    // 0x126b4b0: cmp             x0, x17
    // 0x126b4b4: b.ne            #0x126b4c8
    // 0x126b4b8: ldr             x3, [fp, #0x18]
    // 0x126b4bc: LoadField: r0 = r3->field_27
    //     0x126b4bc: ldur            w0, [x3, #0x27]
    // 0x126b4c0: DecompressPointer r0
    //     0x126b4c0: add             x0, x0, HEAP, lsl #32
    // 0x126b4c4: b               #0x126b4d0
    // 0x126b4c8: ldr             x3, [fp, #0x18]
    // 0x126b4cc: r0 = Instance_EdgeInsets
    //     0x126b4cc: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0x126b4d0: r4 = LoadClassIdInstr(r2)
    //     0x126b4d0: ldur            x4, [x2, #-1]
    //     0x126b4d4: ubfx            x4, x4, #0xc, #0x14
    // 0x126b4d8: stp             x0, x2, [SP]
    // 0x126b4dc: mov             x0, x4
    // 0x126b4e0: mov             lr, x0
    // 0x126b4e4: ldr             lr, [x21, lr, lsl #3]
    // 0x126b4e8: blr             lr
    // 0x126b4ec: tbnz            w0, #4, #0x126b578
    // 0x126b4f0: ldr             x2, [fp, #0x18]
    // 0x126b4f4: ldr             x1, [fp, #0x10]
    // 0x126b4f8: LoadField: r0 = r1->field_33
    //     0x126b4f8: ldur            w0, [x1, #0x33]
    // 0x126b4fc: DecompressPointer r0
    //     0x126b4fc: add             x0, x0, HEAP, lsl #32
    // 0x126b500: LoadField: r3 = r2->field_33
    //     0x126b500: ldur            w3, [x2, #0x33]
    // 0x126b504: DecompressPointer r3
    //     0x126b504: add             x3, x3, HEAP, lsl #32
    // 0x126b508: r4 = LoadClassIdInstr(r0)
    //     0x126b508: ldur            x4, [x0, #-1]
    //     0x126b50c: ubfx            x4, x4, #0xc, #0x14
    // 0x126b510: stp             x3, x0, [SP]
    // 0x126b514: mov             x0, x4
    // 0x126b518: mov             lr, x0
    // 0x126b51c: ldr             lr, [x21, lr, lsl #3]
    // 0x126b520: blr             lr
    // 0x126b524: tbnz            w0, #4, #0x126b578
    // 0x126b528: ldr             x1, [fp, #0x18]
    // 0x126b52c: ldr             x0, [fp, #0x10]
    // 0x126b530: LoadField: r2 = r0->field_37
    //     0x126b530: ldur            w2, [x0, #0x37]
    // 0x126b534: DecompressPointer r2
    //     0x126b534: add             x2, x2, HEAP, lsl #32
    // 0x126b538: LoadField: r3 = r1->field_37
    //     0x126b538: ldur            w3, [x1, #0x37]
    // 0x126b53c: DecompressPointer r3
    //     0x126b53c: add             x3, x3, HEAP, lsl #32
    // 0x126b540: cmp             w2, w3
    // 0x126b544: b.ne            #0x126b578
    // 0x126b548: LoadField: r2 = r0->field_3b
    //     0x126b548: ldur            w2, [x0, #0x3b]
    // 0x126b54c: DecompressPointer r2
    //     0x126b54c: add             x2, x2, HEAP, lsl #32
    // 0x126b550: LoadField: r0 = r1->field_3b
    //     0x126b550: ldur            w0, [x1, #0x3b]
    // 0x126b554: DecompressPointer r0
    //     0x126b554: add             x0, x0, HEAP, lsl #32
    // 0x126b558: r1 = LoadClassIdInstr(r2)
    //     0x126b558: ldur            x1, [x2, #-1]
    //     0x126b55c: ubfx            x1, x1, #0xc, #0x14
    // 0x126b560: stp             x0, x2, [SP]
    // 0x126b564: mov             x0, x1
    // 0x126b568: mov             lr, x0
    // 0x126b56c: ldr             lr, [x21, lr, lsl #3]
    // 0x126b570: blr             lr
    // 0x126b574: b               #0x126b57c
    // 0x126b578: r0 = false
    //     0x126b578: add             x0, NULL, #0x30  ; false
    // 0x126b57c: LeaveFrame
    //     0x126b57c: mov             SP, fp
    //     0x126b580: ldp             fp, lr, [SP], #0x10
    // 0x126b584: ret
    //     0x126b584: ret             
    // 0x126b588: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x126b588: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x126b58c: r0 = Throw()
    //     0x126b58c: bl              #0x13ddb2c  ; ThrowStub
    // 0x126b590: brk             #0
    // 0x126b594: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x126b594: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x126b598: r0 = Throw()
    //     0x126b598: bl              #0x13ddb2c  ; ThrowStub
    // 0x126b59c: brk             #0
    // 0x126b5a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x126b5a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x126b5a4: b               #0x126ab08
    // 0x126b5a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x126b5a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x126b5ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x126b5ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6858, size: 0x14, field offset: 0x10
//   const constructor, 
class DialogTheme extends _MixinApplication8&InheritedTheme&Diagnosticable {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xc001a0, size: 0xa0
    // 0xc001a0: EnterFrame
    //     0xc001a0: stp             fp, lr, [SP, #-0x10]!
    //     0xc001a4: mov             fp, SP
    // 0xc001a8: AllocStack(0x20)
    //     0xc001a8: sub             SP, SP, #0x20
    // 0xc001ac: SetupParameters(DialogTheme this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xc001ac: mov             x4, x1
    //     0xc001b0: mov             x3, x2
    //     0xc001b4: stur            x1, [fp, #-8]
    //     0xc001b8: stur            x2, [fp, #-0x10]
    // 0xc001bc: CheckStackOverflow
    //     0xc001bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc001c0: cmp             SP, x16
    //     0xc001c4: b.ls            #0xc00238
    // 0xc001c8: mov             x0, x3
    // 0xc001cc: r2 = Null
    //     0xc001cc: mov             x2, NULL
    // 0xc001d0: r1 = Null
    //     0xc001d0: mov             x1, NULL
    // 0xc001d4: r4 = 60
    //     0xc001d4: mov             x4, #0x3c
    // 0xc001d8: branchIfSmi(r0, 0xc001e4)
    //     0xc001d8: tbz             w0, #0, #0xc001e4
    // 0xc001dc: r4 = LoadClassIdInstr(r0)
    //     0xc001dc: ldur            x4, [x0, #-1]
    //     0xc001e0: ubfx            x4, x4, #0xc, #0x14
    // 0xc001e4: r17 = 6858
    //     0xc001e4: mov             x17, #0x1aca
    // 0xc001e8: cmp             x4, x17
    // 0xc001ec: b.eq            #0xc00204
    // 0xc001f0: r8 = DialogTheme
    //     0xc001f0: add             x8, PP, #0x95, lsl #12  ; [pp+0x95e18] Type: DialogTheme
    //     0xc001f4: ldr             x8, [x8, #0xe18]
    // 0xc001f8: r3 = Null
    //     0xc001f8: add             x3, PP, #0x95, lsl #12  ; [pp+0x95e20] Null
    //     0xc001fc: ldr             x3, [x3, #0xe20]
    // 0xc00200: r0 = DefaultTypeTest()
    //     0xc00200: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc00204: ldur            x0, [fp, #-8]
    // 0xc00208: LoadField: r1 = r0->field_f
    //     0xc00208: ldur            w1, [x0, #0xf]
    // 0xc0020c: DecompressPointer r1
    //     0xc0020c: add             x1, x1, HEAP, lsl #32
    // 0xc00210: ldur            x0, [fp, #-0x10]
    // 0xc00214: LoadField: r2 = r0->field_f
    //     0xc00214: ldur            w2, [x0, #0xf]
    // 0xc00218: DecompressPointer r2
    //     0xc00218: add             x2, x2, HEAP, lsl #32
    // 0xc0021c: stp             x2, x1, [SP]
    // 0xc00220: r0 = ==()
    //     0xc00220: bl              #0x126aaf0  ; [package:flutter/src/material/dialog_theme.dart] DialogThemeData::==
    // 0xc00224: eor             x1, x0, #0x10
    // 0xc00228: mov             x0, x1
    // 0xc0022c: LeaveFrame
    //     0xc0022c: mov             SP, fp
    //     0xc00230: ldp             fp, lr, [SP], #0x10
    // 0xc00234: ret
    //     0xc00234: ret             
    // 0xc00238: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc00238: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0023c: b               #0xc001c8
  }
  static _ of(/* No info */) {
    // ** addr: 0xd95ca0, size: 0x7c
    // 0xd95ca0: EnterFrame
    //     0xd95ca0: stp             fp, lr, [SP, #-0x10]!
    //     0xd95ca4: mov             fp, SP
    // 0xd95ca8: AllocStack(0x18)
    //     0xd95ca8: sub             SP, SP, #0x18
    // 0xd95cac: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xd95cac: stur            x1, [fp, #-8]
    // 0xd95cb0: CheckStackOverflow
    //     0xd95cb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd95cb4: cmp             SP, x16
    //     0xd95cb8: b.ls            #0xd95d14
    // 0xd95cbc: r16 = <DialogTheme>
    //     0xd95cbc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15248] TypeArguments: <DialogTheme>
    //     0xd95cc0: ldr             x16, [x16, #0x248]
    // 0xd95cc4: stp             x1, x16, [SP]
    // 0xd95cc8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd95cc8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd95ccc: r0 = dependOnInheritedWidgetOfExactType()
    //     0xd95ccc: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xd95cd0: cmp             w0, NULL
    // 0xd95cd4: b.ne            #0xd95ce0
    // 0xd95cd8: r0 = Null
    //     0xd95cd8: mov             x0, NULL
    // 0xd95cdc: b               #0xd95cec
    // 0xd95ce0: LoadField: r1 = r0->field_f
    //     0xd95ce0: ldur            w1, [x0, #0xf]
    // 0xd95ce4: DecompressPointer r1
    //     0xd95ce4: add             x1, x1, HEAP, lsl #32
    // 0xd95ce8: mov             x0, x1
    // 0xd95cec: cmp             w0, NULL
    // 0xd95cf0: b.ne            #0xd95d08
    // 0xd95cf4: ldur            x1, [fp, #-8]
    // 0xd95cf8: r0 = of()
    //     0xd95cf8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd95cfc: LoadField: r1 = r0->field_c7
    //     0xd95cfc: ldur            w1, [x0, #0xc7]
    // 0xd95d00: DecompressPointer r1
    //     0xd95d00: add             x1, x1, HEAP, lsl #32
    // 0xd95d04: mov             x0, x1
    // 0xd95d08: LeaveFrame
    //     0xd95d08: mov             SP, fp
    //     0xd95d0c: ldp             fp, lr, [SP], #0x10
    // 0xd95d10: ret
    //     0xd95d10: ret             
    // 0xd95d14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd95d14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd95d18: b               #0xd95cbc
  }
  _ wrap(/* No info */) {
    // ** addr: 0x12006c4, size: 0x64
    // 0x12006c4: EnterFrame
    //     0x12006c4: stp             fp, lr, [SP, #-0x10]!
    //     0x12006c8: mov             fp, SP
    // 0x12006cc: AllocStack(0x18)
    //     0x12006cc: sub             SP, SP, #0x18
    // 0x12006d0: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x12006d0: stur            x2, [fp, #-0x10]
    // 0x12006d4: CheckStackOverflow
    //     0x12006d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12006d8: cmp             SP, x16
    //     0x12006dc: b.ls            #0x1200720
    // 0x12006e0: LoadField: r0 = r1->field_f
    //     0x12006e0: ldur            w0, [x1, #0xf]
    // 0x12006e4: DecompressPointer r0
    //     0x12006e4: add             x0, x0, HEAP, lsl #32
    // 0x12006e8: stur            x0, [fp, #-8]
    // 0x12006ec: r0 = DialogTheme()
    //     0x12006ec: bl              #0xfb89ac  ; AllocateDialogThemeStub -> DialogTheme (size=0x14)
    // 0x12006f0: mov             x2, x0
    // 0x12006f4: ldur            x0, [fp, #-8]
    // 0x12006f8: stur            x2, [fp, #-0x18]
    // 0x12006fc: StoreField: r2->field_f = r0
    //     0x12006fc: stur            w0, [x2, #0xf]
    // 0x1200700: ldur            x0, [fp, #-0x10]
    // 0x1200704: StoreField: r2->field_b = r0
    //     0x1200704: stur            w0, [x2, #0xb]
    // 0x1200708: mov             x1, x2
    // 0x120070c: r0 = Shader._()
    //     0x120070c: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0x1200710: ldur            x0, [fp, #-0x18]
    // 0x1200714: LeaveFrame
    //     0x1200714: mov             SP, fp
    //     0x1200718: ldp             fp, lr, [SP], #0x10
    // 0x120071c: ret
    //     0x120071c: ret             
    // 0x1200720: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1200720: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1200724: b               #0x12006e0
  }
}
