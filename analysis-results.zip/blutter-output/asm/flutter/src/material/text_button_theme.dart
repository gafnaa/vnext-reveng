// lib: , url: package:flutter/src/material/text_button_theme.dart

// class id: 1048960, size: 0x8
class :: {
}

// class id: 5057, size: 0xc, field offset: 0x8
//   const constructor, 
class TextButtonThemeData extends _MixinApplication3&Object&Diagnosticable {

  static _ lerp(/* No info */) {
    // ** addr: 0x1165324, size: 0x6c
    // 0x1165324: EnterFrame
    //     0x1165324: stp             fp, lr, [SP, #-0x10]!
    //     0x1165328: mov             fp, SP
    // 0x116532c: AllocStack(0x8)
    //     0x116532c: sub             SP, SP, #8
    // 0x1165330: SetupParameters(dynamic _ /* r1 => r0 */)
    //     0x1165330: mov             x0, x1
    // 0x1165334: CheckStackOverflow
    //     0x1165334: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1165338: cmp             SP, x16
    //     0x116533c: b.ls            #0x1165388
    // 0x1165340: cmp             w0, w2
    // 0x1165344: b.ne            #0x1165354
    // 0x1165348: LeaveFrame
    //     0x1165348: mov             SP, fp
    //     0x116534c: ldp             fp, lr, [SP], #0x10
    // 0x1165350: ret
    //     0x1165350: ret             
    // 0x1165354: LoadField: r1 = r0->field_7
    //     0x1165354: ldur            w1, [x0, #7]
    // 0x1165358: DecompressPointer r1
    //     0x1165358: add             x1, x1, HEAP, lsl #32
    // 0x116535c: LoadField: r0 = r2->field_7
    //     0x116535c: ldur            w0, [x2, #7]
    // 0x1165360: DecompressPointer r0
    //     0x1165360: add             x0, x0, HEAP, lsl #32
    // 0x1165364: mov             x2, x0
    // 0x1165368: r0 = lerp()
    //     0x1165368: bl              #0x1164644  ; [package:flutter/src/material/button_style.dart] ButtonStyle::lerp
    // 0x116536c: stur            x0, [fp, #-8]
    // 0x1165370: r0 = TextButtonThemeData()
    //     0x1165370: bl              #0x1165390  ; AllocateTextButtonThemeDataStub -> TextButtonThemeData (size=0xc)
    // 0x1165374: ldur            x1, [fp, #-8]
    // 0x1165378: StoreField: r0->field_7 = r1
    //     0x1165378: stur            w1, [x0, #7]
    // 0x116537c: LeaveFrame
    //     0x116537c: mov             SP, fp
    //     0x1165380: ldp             fp, lr, [SP], #0x10
    // 0x1165384: ret
    //     0x1165384: ret             
    // 0x1165388: r0 = StackOverflowSharedWithFPURegs()
    //     0x1165388: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x116538c: b               #0x1165340
  }
  _ ==(/* No info */) {
    // ** addr: 0x1276f2c, size: 0xfc
    // 0x1276f2c: EnterFrame
    //     0x1276f2c: stp             fp, lr, [SP, #-0x10]!
    //     0x1276f30: mov             fp, SP
    // 0x1276f34: AllocStack(0x10)
    //     0x1276f34: sub             SP, SP, #0x10
    // 0x1276f38: CheckStackOverflow
    //     0x1276f38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1276f3c: cmp             SP, x16
    //     0x1276f40: b.ls            #0x1277020
    // 0x1276f44: ldr             x0, [fp, #0x10]
    // 0x1276f48: cmp             w0, NULL
    // 0x1276f4c: b.ne            #0x1276f60
    // 0x1276f50: r0 = false
    //     0x1276f50: add             x0, NULL, #0x30  ; false
    // 0x1276f54: LeaveFrame
    //     0x1276f54: mov             SP, fp
    //     0x1276f58: ldp             fp, lr, [SP], #0x10
    // 0x1276f5c: ret
    //     0x1276f5c: ret             
    // 0x1276f60: ldr             x1, [fp, #0x18]
    // 0x1276f64: cmp             w1, w0
    // 0x1276f68: b.ne            #0x1276f7c
    // 0x1276f6c: r0 = true
    //     0x1276f6c: add             x0, NULL, #0x20  ; true
    // 0x1276f70: LeaveFrame
    //     0x1276f70: mov             SP, fp
    //     0x1276f74: ldp             fp, lr, [SP], #0x10
    // 0x1276f78: ret
    //     0x1276f78: ret             
    // 0x1276f7c: str             x0, [SP]
    // 0x1276f80: r0 = runtimeType()
    //     0x1276f80: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1276f84: r1 = LoadClassIdInstr(r0)
    //     0x1276f84: ldur            x1, [x0, #-1]
    //     0x1276f88: ubfx            x1, x1, #0xc, #0x14
    // 0x1276f8c: r16 = TextButtonThemeData
    //     0x1276f8c: add             x16, PP, #0x26, lsl #12  ; [pp+0x260a8] Type: TextButtonThemeData
    //     0x1276f90: ldr             x16, [x16, #0xa8]
    // 0x1276f94: stp             x16, x0, [SP]
    // 0x1276f98: mov             x0, x1
    // 0x1276f9c: mov             lr, x0
    // 0x1276fa0: ldr             lr, [x21, lr, lsl #3]
    // 0x1276fa4: blr             lr
    // 0x1276fa8: tbz             w0, #4, #0x1276fbc
    // 0x1276fac: r0 = false
    //     0x1276fac: add             x0, NULL, #0x30  ; false
    // 0x1276fb0: LeaveFrame
    //     0x1276fb0: mov             SP, fp
    //     0x1276fb4: ldp             fp, lr, [SP], #0x10
    // 0x1276fb8: ret
    //     0x1276fb8: ret             
    // 0x1276fbc: ldr             x0, [fp, #0x10]
    // 0x1276fc0: r1 = 60
    //     0x1276fc0: mov             x1, #0x3c
    // 0x1276fc4: branchIfSmi(r0, 0x1276fd0)
    //     0x1276fc4: tbz             w0, #0, #0x1276fd0
    // 0x1276fc8: r1 = LoadClassIdInstr(r0)
    //     0x1276fc8: ldur            x1, [x0, #-1]
    //     0x1276fcc: ubfx            x1, x1, #0xc, #0x14
    // 0x1276fd0: r17 = 5057
    //     0x1276fd0: mov             x17, #0x13c1
    // 0x1276fd4: cmp             x1, x17
    // 0x1276fd8: b.ne            #0x1277010
    // 0x1276fdc: ldr             x1, [fp, #0x18]
    // 0x1276fe0: LoadField: r2 = r0->field_7
    //     0x1276fe0: ldur            w2, [x0, #7]
    // 0x1276fe4: DecompressPointer r2
    //     0x1276fe4: add             x2, x2, HEAP, lsl #32
    // 0x1276fe8: LoadField: r0 = r1->field_7
    //     0x1276fe8: ldur            w0, [x1, #7]
    // 0x1276fec: DecompressPointer r0
    //     0x1276fec: add             x0, x0, HEAP, lsl #32
    // 0x1276ff0: r1 = LoadClassIdInstr(r2)
    //     0x1276ff0: ldur            x1, [x2, #-1]
    //     0x1276ff4: ubfx            x1, x1, #0xc, #0x14
    // 0x1276ff8: stp             x0, x2, [SP]
    // 0x1276ffc: mov             x0, x1
    // 0x1277000: mov             lr, x0
    // 0x1277004: ldr             lr, [x21, lr, lsl #3]
    // 0x1277008: blr             lr
    // 0x127700c: b               #0x1277014
    // 0x1277010: r0 = false
    //     0x1277010: add             x0, NULL, #0x30  ; false
    // 0x1277014: LeaveFrame
    //     0x1277014: mov             SP, fp
    //     0x1277018: ldp             fp, lr, [SP], #0x10
    // 0x127701c: ret
    //     0x127701c: ret             
    // 0x1277020: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1277020: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1277024: b               #0x1276f44
  }
}

// class id: 6836, size: 0x14, field offset: 0x10
//   const constructor, 
class TextButtonTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xfbe86c, size: 0x5c
    // 0xfbe86c: EnterFrame
    //     0xfbe86c: stp             fp, lr, [SP, #-0x10]!
    //     0xfbe870: mov             fp, SP
    // 0xfbe874: AllocStack(0x18)
    //     0xfbe874: sub             SP, SP, #0x18
    // 0xfbe878: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xfbe878: stur            x1, [fp, #-8]
    // 0xfbe87c: CheckStackOverflow
    //     0xfbe87c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbe880: cmp             SP, x16
    //     0xfbe884: b.ls            #0xfbe8c0
    // 0xfbe888: r16 = <TextButtonTheme>
    //     0xfbe888: add             x16, PP, #0x80, lsl #12  ; [pp+0x80bf0] TypeArguments: <TextButtonTheme>
    //     0xfbe88c: ldr             x16, [x16, #0xbf0]
    // 0xfbe890: stp             x1, x16, [SP]
    // 0xfbe894: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xfbe894: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xfbe898: r0 = dependOnInheritedWidgetOfExactType()
    //     0xfbe898: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xfbe89c: ldur            x1, [fp, #-8]
    // 0xfbe8a0: r0 = of()
    //     0xfbe8a0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfbe8a4: r17 = 307
    //     0xfbe8a4: mov             x17, #0x133
    // 0xfbe8a8: ldr             w1, [x0, x17]
    // 0xfbe8ac: DecompressPointer r1
    //     0xfbe8ac: add             x1, x1, HEAP, lsl #32
    // 0xfbe8b0: mov             x0, x1
    // 0xfbe8b4: LeaveFrame
    //     0xfbe8b4: mov             SP, fp
    //     0xfbe8b8: ldp             fp, lr, [SP], #0x10
    // 0xfbe8bc: ret
    //     0xfbe8bc: ret             
    // 0xfbe8c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbe8c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbe8c4: b               #0xfbe888
  }
}
